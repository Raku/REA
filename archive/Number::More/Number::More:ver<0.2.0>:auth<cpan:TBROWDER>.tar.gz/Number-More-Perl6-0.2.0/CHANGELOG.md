# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [v0.2.0] - 2017-10-05
# Changed
- updated META6 keys and values

## [v0.1.0] - 2017-03-12
### Added
- initial release
