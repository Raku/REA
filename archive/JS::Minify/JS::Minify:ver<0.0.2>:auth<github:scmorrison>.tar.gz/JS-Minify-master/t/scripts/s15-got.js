function(s){alert("Foo");}
