// missing semi-colons
function () {
  var x = 21
  var y = 33
  []
}