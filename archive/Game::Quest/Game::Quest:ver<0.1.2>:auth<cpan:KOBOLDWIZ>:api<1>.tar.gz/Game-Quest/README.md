# Quest Game Kit 

For writing e.g. old Sierra-On-Line adventure games such as Space Quest
