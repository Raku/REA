NAME
====

IO::Path::XDG

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.0.0

Description
===========

Convenience functions for working with the XDG Base Directory Specification

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install IO::Path::XDG
```

License
=======

This module is distributed under the terms of the AGPL-3.0.

