# XML::Canonical

    use XML::Canonical;

    my $xml-string = canonical($xml);
    my $xml-string = canonical($xml, :subset('/a/b/c'));
