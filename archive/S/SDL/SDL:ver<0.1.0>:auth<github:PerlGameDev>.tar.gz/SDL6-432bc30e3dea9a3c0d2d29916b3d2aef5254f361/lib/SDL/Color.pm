
unit class SDL::Color is repr('CStruct');

#~ has uint8 $.r;
#~ has uint8 $.g;
#~ has uint8 $.b;
#~ has uint8 $.unused;
has int8 $.r;
has int8 $.g;
has int8 $.b;
has int8 $.unused;
