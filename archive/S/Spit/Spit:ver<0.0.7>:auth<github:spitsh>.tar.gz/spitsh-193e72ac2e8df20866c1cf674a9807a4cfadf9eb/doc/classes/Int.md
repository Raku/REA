# Int
 Int is the primitive type for integers in the shell.
## Bool
>method Bool( ⟶ [Bool](./Bool.md))


 Ints are true in Bool context if they are not equal to 0
