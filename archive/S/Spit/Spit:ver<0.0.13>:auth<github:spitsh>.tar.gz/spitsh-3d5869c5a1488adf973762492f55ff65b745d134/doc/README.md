# Spit Documentation

What you see is what you get here. Most of what's here is auto
generated from the Spit source, so don't submit PRs to change the
`.md` files. What isn't auto-generated is
in [doc-staging](../doc-staging). Contrubutions very welcome.

TODO:

- description of the language syntax
- description of basic constructs
- basic tutorial
- writing modules testing modules
- the spec
