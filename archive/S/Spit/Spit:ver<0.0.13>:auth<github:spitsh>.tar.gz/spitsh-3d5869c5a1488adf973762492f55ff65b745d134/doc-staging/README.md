A place to put snippets .md files before they're moved to /docs with `gen-docs.p6`
