# Locale
 A (probably tempoary) palce to put locale related functions
## encoding
>method encoding( ⟶ [Str](./Str.md))


 Gets the encoding the current terminal is using.
```perl6
if Local.encoding eq 'UTF-8' {
    say "\c[GHOST] \c[RIGHT-TO-LEFT OVERRIDE] \c[GHOST] llehs ni eht koops a";
}
```
