# PID
 The PID class represents an integer process ID.
## Bool
>method Bool( ⟶ [Bool](./Bool.md))


 In Bool context the PID returns the result of `.exists`
## exists
>method exists( ⟶ [Bool](./Bool.md))


 Returns true if the process exists on the system.
