# Int
 Int is the primitive type for integers in the shell.
## ACCEPTS
>method ACCEPTS([Int](./Int.md) **$b** ⟶ [Bool](./Bool.md))


 Returns true if the argument is an Int and equal to the invocant.
## Bool
>method Bool( ⟶ [Bool](./Bool.md))


 Ints are true in Bool context if they are not equal to 0
