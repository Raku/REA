# Regex
 Regex is the type for POSIX extended regex (ERE).
## ACCEPTS
>method ACCEPTS([Str](./Str.md) **$b** ⟶ [Bool](./Bool.md))

 Returns the value of calling .match on the argument with the invocant regex as the argument.
