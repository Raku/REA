Change log for the Shell-Capture Perl 6 module
==============================================

0.1.1 (not yet)
---------------

- also test against the 2016.07.1 and 2016.08.1 Rakudo releases on
  Travis CI

0.1.0
-----

- first public release
