raku -MSparrow6::DSL -c ci.raku
