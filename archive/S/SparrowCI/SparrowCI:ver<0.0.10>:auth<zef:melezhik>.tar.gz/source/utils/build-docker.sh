docker build Dockerfiles/ -f Dockerfiles/sparrow.alpine -t melezhik/sparrow:alpine

