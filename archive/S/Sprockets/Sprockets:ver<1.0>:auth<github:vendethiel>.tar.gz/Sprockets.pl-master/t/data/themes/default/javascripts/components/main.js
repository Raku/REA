// Main component
class Component {};
//= require relative
//= require ../parent