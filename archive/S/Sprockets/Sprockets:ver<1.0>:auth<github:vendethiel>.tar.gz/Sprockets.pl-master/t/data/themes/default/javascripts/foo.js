foo;
//= require components/main