Sprockets
=========

Perl6 version of Sprockets

### Usage


### Syntax

```js
# application.js
/*
 *= require a
 *= require "b"
 */
```