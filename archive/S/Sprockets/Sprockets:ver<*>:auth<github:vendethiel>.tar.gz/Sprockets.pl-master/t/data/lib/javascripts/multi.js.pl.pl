say q:to/PL/;
  print 'perl();'
  PL
