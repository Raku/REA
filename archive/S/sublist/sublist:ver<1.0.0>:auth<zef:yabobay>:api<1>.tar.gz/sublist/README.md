sublist::index
==============

determines whether one list can be found inside another. if it can, it
returns the location where it was found. otherwise, returns `Nil`.

```raku
use sublist;
say sublist::index(<d e f>, <a b c d e f g>); # should print 3
```
enjoy!!!
