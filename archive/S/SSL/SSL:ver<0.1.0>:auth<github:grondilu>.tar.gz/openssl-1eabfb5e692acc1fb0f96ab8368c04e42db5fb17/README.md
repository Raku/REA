Perl6 interface to OpenSSL.  So far only digests.

TODO:
* make it work with binary strings (characters above 128) ;
