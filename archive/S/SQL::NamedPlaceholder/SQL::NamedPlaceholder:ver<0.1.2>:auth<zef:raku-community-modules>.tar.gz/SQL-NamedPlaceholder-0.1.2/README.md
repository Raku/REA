[![Actions Status](https://github.com/raku-community-modules/SQL-NamedPlaceholder/actions/workflows/linux.yml/badge.svg)](https://github.com/raku-community-modules/SQL-NamedPlaceholder/actions) [![Actions Status](https://github.com/raku-community-modules/SQL-NamedPlaceholder/actions/workflows/macos.yml/badge.svg)](https://github.com/raku-community-modules/SQL-NamedPlaceholder/actions) [![Actions Status](https://github.com/raku-community-modules/SQL-NamedPlaceholder/actions/workflows/windows.yml/badge.svg)](https://github.com/raku-community-modules/SQL-NamedPlaceholder/actions)

NAME
====

SQL::NamedPlaceholder - extension of placeholder

SYNOPSIS
========

```raku
use SQL::NamedPlaceholder;

my ($sql, $bind) = bind-named(q[
  SELECT *
  FROM entry
  WHERE
      user_id = :user_id
], {
  user_id => $user_id
});

$dbh.prepare($sql).execute(|$bind);
```

DESCRIPTION
===========

SQL::NamedPlaceholder is extension of placeholder. This enable more readable and robust code.

SUBROUTINES
===========

bind-named($sql, $hash)
-----------------------

```raku
[$sql, $bind] = bind-named($sql, $hash);
```

The $sql parameter is SQL string which contains named placeholders. The $hash parameter is map of bind parameters.

The returned $sql is new SQL string which contains normal placeholders ('?'), and $bind is List of bind parameters.

SYNTAX
======

:foobar
-------

Replace as placeholder which uses value from $hash{foobar}.

    foobar = ?, foobar > ?, foobar < ?, foobar <> ?, etc.

This is same as 'foobar (op.) :foobar'.

AUTHOR
======

Asato Wakisaka

ORIGINAL AUTHOR
===============

This module is a port of [SQL::NamedPlaceholder in Perl](https://metacpan.org/pod/SQL::NamedPlaceholder).

Author of original SQL::NamedPlaceholder in Perl is cho45.

COPYRIGHT AND LICENSE
=====================

Copyright 2016 - 2018 Asato Wakisaka

Copyright 2024 Raku Community

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

Original Perl's SQL::NamedPlaceholder is licensed under following terms:

This library is free software; you can redistribute it and/or modify it under the same terms as Perl itself.

