set_stdout $(bash_rocks)
