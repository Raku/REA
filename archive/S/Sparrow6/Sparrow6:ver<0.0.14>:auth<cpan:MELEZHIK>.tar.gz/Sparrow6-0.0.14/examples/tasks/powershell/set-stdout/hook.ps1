set_stdout("hello from powershell")
