set_stdout "main.foo: #{config['main']['foo']}"

