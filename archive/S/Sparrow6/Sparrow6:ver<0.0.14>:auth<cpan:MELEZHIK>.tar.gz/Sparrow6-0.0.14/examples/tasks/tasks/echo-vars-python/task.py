from sparrow6lib import *
print "foo: " + task_var('foo')
print "bar: " + task_var('bar')
