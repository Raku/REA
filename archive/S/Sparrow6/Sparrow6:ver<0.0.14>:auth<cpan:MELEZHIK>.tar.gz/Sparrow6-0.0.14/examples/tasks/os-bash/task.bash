echo OS - $os
