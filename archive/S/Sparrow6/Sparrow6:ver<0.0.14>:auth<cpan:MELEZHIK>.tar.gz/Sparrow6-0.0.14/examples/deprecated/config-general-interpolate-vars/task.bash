echo $(config base.logdir)


