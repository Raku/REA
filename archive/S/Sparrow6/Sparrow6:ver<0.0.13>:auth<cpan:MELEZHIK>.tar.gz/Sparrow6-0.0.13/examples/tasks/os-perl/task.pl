print "OS - ", os(), "\n";

