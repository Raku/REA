puts config['main']['foo']

