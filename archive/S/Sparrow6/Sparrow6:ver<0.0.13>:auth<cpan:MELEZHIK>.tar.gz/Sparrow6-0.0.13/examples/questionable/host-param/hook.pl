set_stdout("host: ".host());
