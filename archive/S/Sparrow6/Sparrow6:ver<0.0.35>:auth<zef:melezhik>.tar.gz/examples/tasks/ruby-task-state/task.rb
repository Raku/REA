puts get_state()['foo']

