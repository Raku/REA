my $foo = config()->{main}{foo};
my $bar = config()->{main}{bar};

set_stdout("foo: $foo");
set_stdout("bar: $bar");


