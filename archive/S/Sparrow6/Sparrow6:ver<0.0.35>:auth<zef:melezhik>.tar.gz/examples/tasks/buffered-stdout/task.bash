echo "here we go, and sleep for 10";
sleep 10
echo "here we go, and sleep for 10";
sleep 10
echo "done"
