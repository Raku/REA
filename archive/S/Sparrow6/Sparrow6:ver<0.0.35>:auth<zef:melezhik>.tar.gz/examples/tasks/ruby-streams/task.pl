print <<HERE;

  foo
    1
    2
    3
  foo

  foo
    a
    b
    c
  foo

  foo
    aa
    bb
    cc
  foo

HERE
