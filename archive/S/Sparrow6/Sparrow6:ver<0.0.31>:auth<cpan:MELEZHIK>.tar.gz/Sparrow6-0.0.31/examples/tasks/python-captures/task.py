print("1a")
print("2b")
print("3c")
