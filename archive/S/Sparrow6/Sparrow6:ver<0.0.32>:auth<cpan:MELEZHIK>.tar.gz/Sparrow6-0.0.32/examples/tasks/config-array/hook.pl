use Data::Dumper;

set_stdout("item1=[".(config()->{item}->[0])."]");
set_stdout("item2=[".(config()->{item}->[1])."]");
set_stdout("item3=[".(config()->{item}->[2])."]");
set_stdout("item4=[".(config()->{item}->[3])."]");
