print <<HERE;

  foo
      a1
      a2
      a3
      a1
  bar

  foo
      b1
      b2
  bar

  foo
      c1
      c2
      c3
  bar

HERE

