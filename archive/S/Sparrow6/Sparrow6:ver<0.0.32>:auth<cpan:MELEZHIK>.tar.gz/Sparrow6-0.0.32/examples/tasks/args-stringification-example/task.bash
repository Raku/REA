set -e
args=$(config args)
set -x
echo "["$args"]"
