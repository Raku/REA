#echo OK
#set_stdout OK
