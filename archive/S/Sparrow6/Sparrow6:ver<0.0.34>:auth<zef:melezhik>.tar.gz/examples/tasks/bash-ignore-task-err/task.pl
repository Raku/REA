print "so good so far\n";
die "upsss";
