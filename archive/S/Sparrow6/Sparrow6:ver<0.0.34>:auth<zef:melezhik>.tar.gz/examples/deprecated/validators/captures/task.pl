print<<HERE;
1 red
2 green
3 blue

HERE
