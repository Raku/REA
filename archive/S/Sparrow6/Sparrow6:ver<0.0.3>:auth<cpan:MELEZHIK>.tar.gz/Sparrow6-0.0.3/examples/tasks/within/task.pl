print<<"HERE";

Colors: red,green,blue
Digits: one,two,tree,one-1,one-2,one-3,one-11,one-12,one-13

HERE
