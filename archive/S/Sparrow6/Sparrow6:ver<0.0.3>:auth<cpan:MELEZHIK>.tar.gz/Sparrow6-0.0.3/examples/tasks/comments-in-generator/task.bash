echo  foo value
echo  bar value

