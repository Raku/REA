$main = config('main')

$foo = $main.foo

Write-Host "value={$foo}"

