from sparrow6lib import *
print 'main.foo: ' + config()['main']['foo'] 
