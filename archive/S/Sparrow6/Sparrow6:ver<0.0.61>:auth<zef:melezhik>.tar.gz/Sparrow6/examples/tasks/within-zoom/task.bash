echo "hello my name is Sparrow"

echo "bye my name is Sparrow"

echo "hello my name was Sparrow"