cat $root_dir/sysctl.conf
