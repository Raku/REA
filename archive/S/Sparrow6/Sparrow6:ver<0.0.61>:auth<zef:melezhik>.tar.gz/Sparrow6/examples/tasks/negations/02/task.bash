echo "["
echo "A"
echo "B"
echo "C"
echo "]"


echo "["
echo "A"
echo "B"
echo "D"
echo "]"

echo "A B C D"

