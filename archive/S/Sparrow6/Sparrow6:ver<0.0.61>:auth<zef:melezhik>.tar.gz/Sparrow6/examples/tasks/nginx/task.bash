cat $root_dir/nginx.conf.default
