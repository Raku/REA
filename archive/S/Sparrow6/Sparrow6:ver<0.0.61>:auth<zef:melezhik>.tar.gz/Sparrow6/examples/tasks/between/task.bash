echo "
start 100 end

start
    0
    3
    4
    5
end

start
    6   
    7
    8
    9
    10
    11
    12
end

    1
    2
    73
"



