echo "

  {
    A
    B
    C
  }

  {
    a
    b
    c
  }

  {
    aa
    bb
    cc
  }

"
