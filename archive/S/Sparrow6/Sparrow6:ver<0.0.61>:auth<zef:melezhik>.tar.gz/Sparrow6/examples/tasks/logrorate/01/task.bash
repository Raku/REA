cat $root_dir/conf
