echo OK
echo HELLO
echo OK
echo DONE
echo BYE!
