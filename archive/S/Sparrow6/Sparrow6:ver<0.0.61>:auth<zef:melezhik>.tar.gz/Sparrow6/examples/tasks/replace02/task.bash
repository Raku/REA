cat << HERE > $cache_root_dir/file.txt
OK
HELLO 1
DONE
HERE

cat $cache_root_dir/file.txt

