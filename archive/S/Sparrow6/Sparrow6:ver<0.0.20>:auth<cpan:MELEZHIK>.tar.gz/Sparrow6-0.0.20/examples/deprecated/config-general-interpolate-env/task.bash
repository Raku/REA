echo '{' $(config user) '}'


