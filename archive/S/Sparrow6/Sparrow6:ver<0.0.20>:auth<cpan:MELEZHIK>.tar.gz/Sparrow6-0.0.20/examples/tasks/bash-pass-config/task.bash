echo $(config main.foo)


