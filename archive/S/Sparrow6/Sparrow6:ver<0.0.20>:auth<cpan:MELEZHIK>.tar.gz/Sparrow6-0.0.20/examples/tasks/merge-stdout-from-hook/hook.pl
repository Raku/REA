set_stdout("hook says A");
set_stdout("hook says B");
