print <<HERE;
hello
world
jan
julia
alex

hello
world
Alex

a1a2a3a4
b1b2b3b4
a1a2a3a4
b1b2b3b4
HERE
