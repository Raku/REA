echo "
foo
1
2
3
bar

foo
a
b
c
bar

foo
A
B
C
bar"
