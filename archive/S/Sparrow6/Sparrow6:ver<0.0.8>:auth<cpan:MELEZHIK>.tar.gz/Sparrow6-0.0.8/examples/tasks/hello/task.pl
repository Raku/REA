print "hello\n";
print config()->{main}->{foo};
