print "
    foo
        0
    bar

    foo
        2
        4
        6
        8
    bar

    foo
        1
        3
    bar
"

