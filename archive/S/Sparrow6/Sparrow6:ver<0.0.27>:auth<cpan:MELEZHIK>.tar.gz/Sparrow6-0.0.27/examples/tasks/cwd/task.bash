echo '['$(pwd)']'
