echo "hello world from Bash"

