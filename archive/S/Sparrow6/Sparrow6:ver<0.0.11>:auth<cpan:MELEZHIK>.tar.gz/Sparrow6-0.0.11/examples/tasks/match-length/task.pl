print "\n";
print  'A'x99;
print "\n";
