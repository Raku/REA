print <<HERE;

hello
world
jan

hello
worlld
Jan

hello2
world2
jan2

HERE
