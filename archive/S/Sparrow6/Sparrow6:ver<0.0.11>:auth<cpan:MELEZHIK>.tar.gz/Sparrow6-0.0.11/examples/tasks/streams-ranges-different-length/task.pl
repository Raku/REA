print <<HERE;

  foo
      2
      4
      6
      8
  bar

  foo
      1
      3
  bar

  foo
      0
      0
      0
  bar

HERE

