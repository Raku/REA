echo I AM OK
