print "
foo
    1
    1
    2
    2
    11
    11
    22
    22
bar
foo
    1
    1
    2
    2
    11
    11
    22
    22
bar
"

