from sparrow6lib import *
ignore_error()
