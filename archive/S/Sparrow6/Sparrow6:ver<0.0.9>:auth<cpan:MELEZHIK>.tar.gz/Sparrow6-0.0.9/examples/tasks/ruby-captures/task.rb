puts 1
puts 2
puts 3

