from sparrow6lib import *
set_stdout('WHITE RABBIT');
