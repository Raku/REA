from sparrow6lib import *
run_task('00');
run_task('01', { 'foo' : 'python says foo!!!' });
