print "hello world\n";
print "/hello/\n";
