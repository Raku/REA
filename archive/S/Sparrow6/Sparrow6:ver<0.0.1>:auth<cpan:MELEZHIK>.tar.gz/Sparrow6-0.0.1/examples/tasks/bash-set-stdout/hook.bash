set_stdout 'OK2'


