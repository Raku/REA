print "foo: ".task_var("foo")."\n";
