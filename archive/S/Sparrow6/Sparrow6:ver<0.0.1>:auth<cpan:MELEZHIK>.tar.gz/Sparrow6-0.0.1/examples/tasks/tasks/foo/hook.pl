push our @foo, "foo was here";
