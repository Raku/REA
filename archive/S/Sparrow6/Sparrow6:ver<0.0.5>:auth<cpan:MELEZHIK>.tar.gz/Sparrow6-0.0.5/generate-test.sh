find  examples/migration/powershell  -mindepth 1 -type d |grep -v modules | perl -n generate-test.pl

