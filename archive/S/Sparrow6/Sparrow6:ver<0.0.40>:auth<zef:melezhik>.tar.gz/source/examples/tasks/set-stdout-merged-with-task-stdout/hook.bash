set_stdout Black Coffee 
