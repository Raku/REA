echo cat say $word once
echo cat say $(task_var word) again

