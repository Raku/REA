echo "HELLO"
echo "HELLO WORLD"
echo "My birth day is: 1977-04-16"

