set_Foo
echo $FOO

