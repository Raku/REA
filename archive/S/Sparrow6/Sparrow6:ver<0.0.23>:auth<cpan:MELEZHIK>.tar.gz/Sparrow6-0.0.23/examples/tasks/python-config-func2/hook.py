from sparrow6lib import *
set_stdout('main.foo: ' + config()['main']['foo']);

