print <<HERE;
        id              
        title           
        body            
        userId          
HERE
