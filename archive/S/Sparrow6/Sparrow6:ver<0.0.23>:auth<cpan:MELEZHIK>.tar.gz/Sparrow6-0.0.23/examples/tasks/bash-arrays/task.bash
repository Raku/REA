echo $(config item)

declare -a items=$(config item)

echo item1 = ${items[0]}
echo item2 = ${items[1]}
echo item3 = ${items[2]}
echo item4 = ${items[3]}
