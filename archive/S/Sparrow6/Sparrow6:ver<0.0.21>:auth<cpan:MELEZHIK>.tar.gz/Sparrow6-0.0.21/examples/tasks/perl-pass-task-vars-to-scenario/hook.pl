run_task '01', { foo => 'HELLO WORLD!!!' };
set_stdout('done');
