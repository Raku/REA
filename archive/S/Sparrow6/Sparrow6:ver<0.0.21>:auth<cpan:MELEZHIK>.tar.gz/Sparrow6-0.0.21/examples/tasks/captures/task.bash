echo    1 - for one
echo    2 - for two
echo    3 - for three

