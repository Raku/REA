set_stdout(ruby_rocks())
