echo I am ok
