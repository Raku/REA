echo A
echo 1
echo 2
echo 3
echo Z


echo
echo

echo A
echo 4
echo 5
echo 6
echo Z

echo
echo


echo A
echo 1
echo 2
echo 6
echo Z



