use v6.d;
use Test;
use Cro::TCP;

unit module Test::Util;

#| In-memory stand-in for $*ERR. Tests that deliberately drive a failure path
#| can use it to keep expected diagnostics out of DistTest output while still
#| being able to assert on the text that was emitted.
class CaptureHandle {
    has Str $.text is rw = '';

    method print(*@parts) { $!text ~= @parts.map(*.Str).join }
    method say(*@parts)   { self.print(@parts.map(*.Str).join ~ "\n") }
    method put(*@parts)   { self.say(|@parts) }
    method write(Blob $blob) { $!text ~= $blob.decode('utf8-c8') }
    method flush(--> Nil) { }
    method close(--> Nil) { }
}

#| A before-parse transform for plain-HTTP test servers. HTTPS fallback tests
#| deliberately point an https:// URL at a plain HTTP listener; without this,
#| Cro's request parser logs a "Malformed request line" backtrace for the TLS
#| ClientHello. Closing the connection on the first TLS record produces the
#| same "socket closed during negotiation" error without the noisy parser
#| exception.
class RejectTLSHandshake does Cro::Transform {
    method consumes() { Cro::TCP::Message }
    method produces() { Cro::TCP::Message }

    method transformer(Supply $incoming --> Supply) {
        supply {
            whenever $incoming -> $message {
                my $data = $message.data;
                if $data.elems >= 2 && $data[0] == 0x16 && $data[1] == 0x03 {
                    try $message.connection.close;
                }
                else {
                    emit $message;
                }
            }
        }
    }
}

sub reject-tls-handshake() is export {
    RejectTLSHandshake.new
}

sub wait-for-port(Int $port, Real $timeout = 5) is export {
    my $deadline = now + $timeout;
    loop {
        my $sock = try IO::Socket::INET.new(:host('127.0.0.1'), :port($port));
        with $sock { .close; return }
        die "test server did not start listening on port $port" if now > $deadline;
        sleep 0.05;
    }
}

#| Cro's request parser throws (and the scheduler prints a backtrace) when a
#| test deliberately sends TLS bytes to a plain-HTTP listener or otherwise
#| malformed input. Only these exact parser messages are filtered; anything
#| else still reaches the real stderr.
sub is-expected-cro-noise(Str $message --> Bool) {
    so $message.contains('Malformed request line')
        || $message.contains('Unsupported method ')
        || $message.contains('Unsupported HTTP version')
        || $message.contains('Malformed header');
}

#| Run &block with $*ERR captured and a narrowly filtered uncaught handler.
#| Without :capture, returns the block's value. With :capture, returns a Hash
#| with `value` (the block's value) and `err` (captured stderr text).
sub quiet-diagnostics(&block, Bool :$capture = False) is export {
    my $real-err = $*ERR;
    my $sink = CaptureHandle.new;

    my $old-handler = $*SCHEDULER.uncaught_handler;
    $*SCHEDULER.uncaught_handler = -> $ex {
        my $message = (try { $ex.message } // $ex.Str // '').Str;
        if is-expected-cro-noise($message) {
            $sink.say("Suppressed expected Cro diagnostic: $message");
        }
        else {
            # Keep genuine failures visible instead of silently swallowing
            # them along with the expected noise.
            $real-err.say("Unhandled exception in test: $message");
            my $backtrace = try { $ex.backtrace.Str };
            $real-err.say($backtrace) if $backtrace;
        }
    };
    LEAVE { $*SCHEDULER.uncaught_handler = $old-handler }

    # The dynamic override lives in this inner scope so the original $*ERR
    # above is still the real process stderr for unexpected exceptions.
    my $result;
    {
        my $*ERR = $sink;
        $result = block();
    }
    $capture ?? { value => $result, err => $sink.text } !! $result
}

#| Drop-in replacement for `subtest 'name' => { ... }` that quiets expected
#| negative-path diagnostics for that subtest only.
sub quiet-subtest(Pair $spec) is export {
    my ($name, $body) = $spec.kv;
    subtest $name => { quiet-diagnostics($body) }
}
