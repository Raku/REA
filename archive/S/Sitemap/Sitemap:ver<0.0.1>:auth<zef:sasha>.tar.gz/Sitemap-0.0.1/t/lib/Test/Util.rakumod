use v6.d;

unit module Test::Util;

sub wait-for-port(Int $port, Real $timeout = 5) is export {
    my $deadline = now + $timeout;
    loop {
        my $sock = try IO::Socket::INET.new(:host('127.0.0.1'), :port($port));
        with $sock { .close; return }
        die "test server did not start listening on port $port" if now > $deadline;
        sleep 0.05;
    }
}