use v6.d;

unit module Sitemap;

use Sitemap::Item;
use Sitemap::Builder;
use Sitemap::SiteTree;
use Sitemap::Parser;
use Sitemap::Crawler;
use Sitemap::DirScanner;
use Sitemap::Config;

our $VERSION = $Sitemap::Config::VERSION;

=begin pod

=head1 NAME

Sitemap - Sitemap generator for Raku

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap;

# Generate XML from URL list
my $builder = Sitemap::Builder.new;
$builder.add-item('https://example.com/page1', :lastmod(DateTime.now), :priority(0.8));
$builder.add-item('https://example.com/page2');
$builder.write: 'sitemap.xml';

# Or crawl a website
my $crawler = Sitemap::Crawler.new(url => 'https://example.com');
$crawler.on-add: -> $url { say "Found: $url" };
$crawler.on-done: -> @urls { say "Total: @urls.elems()" };
$crawler.start;

# Fetch sitemap from server (with auto-discovery)
use Sitemap::Fetcher;
my $xml = fetch('https://example.com', :ssl-verify(False));
# Recursive fetch for sitemap indexes (downloads all child sitemaps)
my %result = fetch-recursive(
    'https://example.com/sitemap.xml',
    :format<xml>,
    :verbose
);

=end code

=head1 DESCRIPTION

Sitemap is a Raku module for generating XML sitemaps, crawling websites, and fetching sitemaps from servers.
It supports:

=item Generate standard XML sitemaps (sitemap.org protocol)
=item Sitemap index files for large sites (>50k URLs)
=item Parse existing sitemaps (including recursive parsing of indexes)
=item Fetch sitemaps from remote servers (with recursive support)
=item Automatic gzip decompression of .gz sitemaps
=item Automatic sitemap discovery (robots.txt + /sitemap.xml fallback)
=item Recursive fetch creates descriptive directories (e.g., example-com-sitemap/)
=item Child sitemaps named with path context (e.g., sitemap-blog.xml)
=item Build hierarchical site trees with depth-inferred priorities
=item Crawl websites to discover URLs
=item Respect robots.txt rules
=item Output in multiple formats (XML, HTML, TXT, RSS, Atom, mRSS)

=head2 Sitemap::SiteTree

Define your site as a tree of URL stubs with automatic priority
computation:

=begin code :lang<raku>

use Sitemap::SiteTree;

my $root = Sitemap::SiteTree.new;
my $blog = $root.add-child('blog');
$blog.add-child('first-post');
$blog.add-child('second-post');

my $builder = $root.to-builder('https://example.com');
$builder.write: 'sitemap.xml';  # priorities: 1.0, 0.8, 0.6, 0.6

=end code

Also supports flat-list wiring via C<wire-parents> and JSON import
via the C<sitemap tree> CLI command.

=head2 Sitemap::Fetcher

The C<Sitemap::Fetcher> module provides functions for fetching sitemaps:

=item C<fetch($url, :$ssl-verify, :$verbose)> - Fetch a single sitemap with automatic gzip decompression
=item C<fetch-recursive($url, :$format, :$output, :$force, :$ssl-verify, :$verbose, :$concurrency, :$follow-foreign-children, :$max-children)> - Fetch sitemap index and all child sitemaps
=item C<discover-sitemap($domain, :$ssl-verify, :$verbose)> - Auto-discover sitemap (robots.txt + /sitemap.xml fallback)
=item C<output-filename($input, :$format, :$output-override)> - Generate filename with path context
=item C<format-output(@items, $fmt, $title, $link, :$pretty)> - Format items to various output formats

=head1 AUTHOR

Sasha Abbott

=head1 COPYRIGHT AND LICENSE

Copyright 2026 Sasha Abbott

This library is free software; you can redistribute it and/or modify it under the CC0 1.0 Universal license.

=end pod
