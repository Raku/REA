use v6.d;

#| Supplier-backed event subscriptions shared by the Crawler and DirScanner.
#| A class that does this role owns the suppliers (declared here, so both
#| consuming classes can also read $!add-supplier/... from their own emit
#| sites) and registers handlers via on-add / on-ignore / on-error / on-done.
#|
#| Subscriber exceptions are caught at the tap site, not at the emit site: a
#| throw from a tap both propagates out of Supplier.emit synchronously and
#| fails the tap's Promise, which would otherwise surface as an unhandled
#| failure at the next await and abort the whole scan/crawl. Sandboxing the
#| callback keeps one subscriber's bug from leaking counts or killing the run.
#| The statement-form try (not a try{}CATCH block, which re-raises) keeps $!
#| recoverable.
role Sitemap::Subscribable {
    has Supplier $!add-supplier = Supplier.new;
    has Supplier $!ignore-supplier = Supplier.new;
    has Supplier $!error-supplier = Supplier.new;
    has Supplier $!done-supplier = Supplier.new;

    method on-add(&code) {
        $!add-supplier.Supply.tap(-> $url {
            try &code($url);
            note "Error in on-add handler: {$!.message}" if $!;
        });
    }

    method on-ignore(&code) {
        # The supplier emits a 2-element List (url, reason). tap() passes that
        # List as a single argument, which can't bind to a -> $url, $reason
        # signature, so flatten it with | before calling the user callback.
        $!ignore-supplier.Supply.tap(-> $payload {
            try &code(|$payload);
            note "Error in on-ignore handler: {$!.message}" if $!;
        });
    }

    method on-error(&code) {
        # Both Crawler and DirScanner emit an Associative payload
        # {url, status, error}; pass it through untouched so the
        # subscriber's callback can bind the fields it needs.
        $!error-supplier.Supply.tap(-> $payload {
            try &code($payload);
            note "Error in on-error handler: {$!.message}" if $!;
        });
    }

    method on-done(&code) {
        $!done-supplier.Supply.tap(-> $items {
            try &code($items);
            note "Error in on-done handler: {$!.message}" if $!;
        });
    }

    method close-suppliers() {
        .done for $!add-supplier, $!ignore-supplier, $!error-supplier, $!done-supplier;
    }
}

=begin pod

=head1 NAME

Sitemap::Subscribable - Supplier-backed event subscriptions

=head1 DESCRIPTION

Provides C<on-add>, C<on-ignore>, C<on-error>, C<on-done> tap methods
and C<close-suppliers> for explicit cleanup.  Suppliers are deliberately
left open after C<close()> so a second C<crawl()> on the same instance
does not crash on emit.  Call C<close-suppliers()> when the Crawler or
DirScanner instance is no longer needed.

=end pod
