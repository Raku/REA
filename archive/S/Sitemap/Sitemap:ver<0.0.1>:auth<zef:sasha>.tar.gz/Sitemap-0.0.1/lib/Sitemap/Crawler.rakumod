use v6.d;

use URI;
use Cro::HTTP::Client;
use Sitemap::Builder;
use Sitemap::Item;
use Sitemap::Config;
use Sitemap::Grammar::RobotsTxt;
use Sitemap::Grammar::LinkExtract;
use Sitemap::JsonLd;
use Sitemap::Extraction;
use Sitemap::Subscribable;
use Syndicate::Utils;

class Sitemap::Crawler does Sitemap::Subscribable {
    has Str $.url is required;
    has Str $.user-agent = "Raku-Sitemap/{$Sitemap::Config::VERSION}";
    has Int $.max-depth = 0;
    has Int $.max-urls = 0;
    has Int $.timeout = 30;
    has Int $.concurrency = 20;
    has Bool $.respect-robots = True;
    has Bool $.ignore-amp = True;
    has Bool $.verify-ssl = True;
    has Bool $.allow-http-fallback = False;
    has Bool $.verbose = False;
    has Bool $.debug = False;
    has %.exclude-extensions = %(
        'ico' => True, 'css' => True, 'js' => True, 'woff' => True, 'woff2' => True,
        'ttf' => True, 'eot' => True, 'zip' => True, 'tar' => True,
        'gz' => True, 'pdf' => True, 'doc' => True, 'docx' => True,
        'rss' => True, 'atom' => True, 'xml' => True,
    );
    has %.extra-exclude-extensions = %();  # Merges with defaults
    has Str @.exclude-dirs = [];
    has Int $.max-images = 1000;
    has Int $.max-videos = 100;
    has Bool $.follow-links = True;
    has Bool $.extract-images = True;
    has Bool $.extract-hreflang = True;
    has Bool $.extract-videos = False;
    has Bool $.extract-news = False;
    has Bool $.extract-lastmod = True;
    has Bool $.calculate-priority = True;
    # Redirect hops are capped like the Fetcher's (Fetcher.rakumod:47): a
    # server serving endlessly-unique 3xx Locations must not be followed
    # forever. Redirect loops already terminate via mark-queued dedup; this
    # cap bounds the never-repeating chains max-urls cannot catch (each hop
    # releases its url-count slot, so the cap check never trips on them).
    has Int $.max-redirects = 5;

    has Sitemap::Builder $!builder;
    has Sitemap::Builder $!news-builder;
    has Cro::HTTP::Client $!http;

    # FIFO-bounded visited set so a huge crawl cannot grow this hash without
    # limit; once it passes the cap the oldest URLs are forgotten again.
    has Int $.queued-cap = 100_000;
    has %!queued-urls-map;
    has @!queued-order;

    # Authoritative set of URLs already handed to the builder. Unlike the FIFO
    # map above it is never evicted, so a URL forgotten by the cap and later
    # rediscovered cannot be added to the sitemap twice. Memory is proportional
    # to the actual output, which the builder's items array already holds.
    has %!added-urls;

    # Cache URL string → canonical origin to avoid repeated URI.new()
    # parsing. The canonical-origin function is deterministic (same URL
    # always yields the same origin), so no invalidation is needed. This
    # avoids ~4ms per URI.new() call in the hot crawl loops.
    has %!origin-cache;
    has @!origin-order;

    has atomicint $!url-count = 0;
    has atomicint $!stale-news-count = 0;

    # robots.txt state is kept per origin: a foreign host reached via a
    # cross-origin <base href> must be checked against its own robots.txt, not
    # the seed origin's rules. %!robots maps origin => Actions (or Nil when the
    # fetch failed / there is no robots.txt, which means allow-all).
    has %!robots;
    has %!crawl-delay;
    has %!last-request-time;

    has %!fallback-attempted;
    has Channel $!queue;
    has atomicint $!pending-count = 0;
    has Lock $!url-lock = Lock.new;
    has Lock $!robots-lock = Lock.new;
    # One lock per origin: robots.txt fetches are serialized per origin (two
    # workers must not fetch the same origin twice) but not globally, so a
    # slow robots.txt on one host does not stall pages on unrelated hosts.
    has Lock %!robots-locks;
    # One lock per origin for crawl-delay spacing. The delay applies only to
    # the origin that served the robots.txt, so the sleep happens inside the
    # origin's own lock (same-origin requests must stay `delay` seconds apart)
    # but never inside a global lock that would serialize unrelated hosts.
    has Lock %!delay-locks;

    submethod TWEAK(Str :$url) {
        # Clamp queued-cap: a zero or negative cap would prevent any URL from
        # ever being queued, silently crawling nothing.
        $!queued-cap = max(1, $!queued-cap);
        # Normalize --exclude-dirs: accept comma-separated and/or repeated
        # values and strip leading/trailing slashes so later comparisons are
        # simple. A bare "/" (or "") becomes the catch-all prefix ''.
        @!exclude-dirs = @!exclude-dirs
            .map(*.split(',')).flat
            .map(*.trim)
            .grep(*.chars)
            .map({ $_.subst(/^ \/ + /, '').subst(/ \/ + $/, '') });

        my $normalized = try { self!normalize-url($!url) };
        # Reject an empty result too: normalize-url returns '' (defined, so
        # `// die` alone would miss it) for fragment-only or empty input, which
        # would otherwise be accepted and silently crawl nothing.
        die "Crawler: invalid start URL '$!url': could not parse as a URI"
            unless $normalized.defined && $normalized.chars;
        # Reject a non-http(s) seed outright. normalize-url happily normalizes
        # ftp://, file://, etc., but !crawl-page only ever fetches http(s), so
        # an exotic seed would otherwise be accepted and then silently crawl
        # zero URLs with no error or event. The CLI already gates this via
        # is-valid-crawl-url, but the library API must too.
        die "Crawler: start URL must be http:// or https:// (got '$normalized')"
            unless $normalized ~~ /^ :i https? \: \/\//;
        $!url = $normalized;
        $!builder = Sitemap::Builder.new;
        $!news-builder = Sitemap::Builder.new if $!extract-news;
        $!http = self!create-http-client;
    }

    method !reset-state() {
        $!url-count⚛= 0;
        $!stale-news-count⚛= 0;
        %!queued-urls-map = ();
        @!queued-order = ();
        %!added-urls = ();
        %!origin-cache = ();
        @!origin-order = ();
        %!robots = ();
        %!robots-locks = ();
        %!delay-locks = ();
        %!crawl-delay = ();
        %!last-request-time = ();
        %!fallback-attempted = ();
        $!builder.clear;
        if $!extract-news {
            # Builder.clear() returns the (now emptied) sitemap list Array, not
            # the builder, so it must be called as a statement -- assigning its
            # return value to this typed Sitemap::Builder attribute would raise
            # X::TypeCheck on every start()/crawl() with extract-news on.
            if $!news-builder.defined { $!news-builder.clear }
            else                      { $!news-builder = Sitemap::Builder.new }
        }
        $!queue = Channel.new;
        # INVARIANT: $!queue must stay an unbounded Channel. The workers are
        # both the consumers AND the producers of this queue (each worker
        # enqueues child links from inside $!url-lock, see !queue-child-links),
        # so a bounded channel could let all workers block on send while nobody
        # receives -- a deadlock. Never pass a :size here.
        $!pending-count⚛= 0;
    }

    #| Mark a URL as queued (dedupe set with a FIFO cap). Returns True if the
    #| URL was newly added, False if it was already known. Callers hold
    #| $!url-lock when invoking this.
    method !mark-queued(Str $url --> Bool) {
        return False if %!queued-urls-map{$url}:exists;
        %!queued-urls-map{$url} = True;
        @!queued-order.push: $url;
        if @!queued-order.elems > $.queued-cap {
            # Raku hashes iterate in insertion order, so the head of
            # @!queued-order is the oldest URLs: evict them in bulk (a fixed
            # batch rather than exactly the overshoot) so the Array head is
            # shifted only every ~cap/16 pushes instead of once per push,
            # amortizing the cost while keeping the set bounded around the cap.
            # Evicted URLs are forgotten by the map, so a re-discovery
            # re-queues them.
            Sitemap::Config::fifo-evict(%!queued-urls-map, @!queued-order, :cap($.queued-cap));
        }
        True;
    }

    #| Decrement the outstanding-url counter. Every path that consumes a queued
    #| page without adding it to the builder must call this exactly once, or
    #| $!url-count (the "found" total) drifts from reality. The atomic
    #| decrement is thread-safe without the lock; callers never hold
    #| $!url-lock when invoking this, so no deadlock risk.
    method !url-finished() {
        $!url-count⚛--;
    }

    #| Debug tracing: every crawl-time debug message funnels through here so
    #| the "[thread] DEBUG" prefix and the $.debug gate live in one place
    #| instead of ~45 inline say statements. Callers keep a short
    #| area prefix in the message ("CP: ...", "PQ: ...").
    method !dbg(Str $msg) {
        # try: a broken stdout (EPIPE from `crawler --debug | head`, journald
        # rotation) throws X::IO::Print; an escaping diagnostic must not take
        # down a worker and abort the whole crawl mid-run.
        try { say "DEBUG $msg" if $.debug };
    }

    #| Report a page-level failure and release its slot in $!url-count. All page
    #| errors share one Hash shape ({ url, status, error }) so on-error
    #| subscribers can rely on a consistent payload.
    method !report-page-error(Str $url, Int $status, Str $msg) {
        $!error-supplier.emit({ url => $url, status => $status, error => $msg });
        self!url-finished;
    }

    method !create-http-client() {
        # Share the process-wide client pool: the crawler's identity (UA,
        # ssl-verify, timeouts, no-follow) is part of the cache key, so its
        # fetches get a dedicated pooled client without duplicating connection
        # machinery. Redirects are NOT auto-followed: every 3xx surfaces in
        # !process-page and its target is re-enqueued through !crawl-page, so
        # robots.txt / crawl-delay / same-origin rules apply to the redirect
        # target exactly as they would to an ordinary URL.
        cached-client(
            :ssl-verify($!verify-ssl),
            timeout => { connection => $!timeout, body => $!timeout },
            :user-agent($!user-agent),
            :follow(False),
        );
    }

    method !switch-to-http(Str $origin) {
        return if %!fallback-attempted{$origin};
        %!fallback-attempted{$origin} = True;
        $!url = $!url.subst: /^ https \: \/\//, 'http://';
        # Cro only applies TLS to https URLs, so the same client serves
        # plain-http fetches after the scheme swap; no new client is needed.
    }

    #| Release crawl resources (the worker queue). The Cro HTTP client pool has
    #| no public close, so it is left for GC; call this from a LEAVE in
    #| long-lived callers so the channel cannot linger after an early error
    #| exit. The event suppliers are deliberately left open: they hold no
    #| resources and finishing them would make a second crawl() on the same
    #| instance crash on emit, so close() must not be terminal.
    method close() {
        if $!queue.defined {
            try $!queue.close;
            $!queue = Nil;
        }
    }

    # on-add/on-ignore/on-error/on-done come from Sitemap::Subscribable; the
    # emit sites below write straight to the role-owned suppliers.

    method news-builder( --> Sitemap::Builder) { $!news-builder }

    method start() {
        self!dbg("start() called") if $.debug;
        # Each start() begins a fresh crawl: without this, a second
        # start()/crawl() on the same instance reuses visited/queued state
        # and silently returns the previous run's results.
        self!reset-state;
        self!fetch-robots;
        self!dbg("robots fetch done, seeding queue") if $.debug;
        $!url-lock.protect: { self!mark-queued($!url) };
        $!queue.send([$!url, 0, 0]);
        $!pending-count⚛++;
        self!process-queue;
        $!done-supplier.emit($!builder.get-items);
        self!dbg("start() done") if $.debug;
    }

    method crawl( --> Sitemap::Builder) {
        self!dbg("crawl() entered") if $.debug;
        my $done = False;
        until $done {
            my $err;
            my $start-ok = try {
                self!dbg("crawl() calling start") if $.debug;
                self.start;
                True;
            };
            # A failed `try` returns Nil; recover the exception from $! right
            # after it. (On current Rakudo a successful statement-level try also
            # clears $!, so gating on the return value is a defensive pattern
            # that stays correct even if the $!-clearing behavior changes.)
            $err = $start-ok ?? Nil !! $!;
            if $err {
                my $err-msg = $err.message;
                self!dbg("crawl() caught: $err-msg") if $.debug;
                # Case-insensitive so 'ssl', 'TLS', 'certificate', 'negotiation'
                # all trigger the https→http fallback.
                if self!is-ssl-error($err-msg) {
                    if $!allow-http-fallback && $.url.starts-with('https://') {
                        my $start-origin = self!fallback-key($.url);
                        if !%!fallback-attempted{$start-origin} {
                            self!switch-to-http($start-origin);
                            self!reset-state;
                            note "HTTPS failed, retrying with HTTP...";
                            next;
                        }
                        $!error-supplier.emit({ url => $!url, status => Nil, error => $err-msg });
                        $done = True;
                    }
                    else {
                        $!error-supplier.emit({ url => $!url, status => Nil, error => $err-msg });
                        $done = True;
                    }
                }
                else {
                    $!error-supplier.emit({ url => $!url, status => Nil, error => $err-msg });
                    $done = True;
                }
            }
            else {
                $done = True;
            }
        }
        self!dbg("crawl() returning builder") if $.debug;
        $!builder;
    }

    method !process-queue() {
        my $workers = max(1, $.concurrency);

        my @workers = (^$workers).map: {
            start {
                # If any task throws outside its guarded try (a non-catchable
                # runtime failure), this worker would die leaving the rest
                # blocked in receive on a channel nobody closes. Closing here —
                # surviving workers get Nil and exit — keeps await @workers from
                # hanging and lets the error surface instead of deadlocking.
                LEAVE { try $!queue.close }
                loop {
                    my $task = try $!queue.receive;
                    last unless $task.defined;
                    my ($url, $depth, $hops) = $task;
                    self!dbg("PQ: worker got $url (depth=$depth hops=$hops)") if $.debug;

                    my $page-ok = try {
                        self!crawl-page($url, $depth, $hops);
                        True;
                    };
                    unless $page-ok {
                        # try: the same stdout-robustness reasoning as !dbg —
                        # a failed diagnostic must not kill the worker.
                        try {
                            note "Crawl error for $url: {$!.message}" if $.verbose;
                            if $.debug {
                                # Iterate the Backtrace's frame objects directly:
                                # `.full` returns a flat Str, so iterating it would
                                # call .subname/.file/.line on individual characters
                                # and crash the worker.
                                for $!.backtrace {
                                    note "  {.subname} at {.file}:{.line}";
                                }
                            }
                        }
                    }

                    # Closing the queue when the count drops to zero wakes any
                    # workers still blocked in receive (they get Nil and exit).
                    # The decrement and the close decision run under $!url-lock,
                    # the same lock every $!queue.send takes, so a send can never
                    # race a drain close and leave a URL marked queued but lost
                    # Every send site increments $!pending-count and every
                    # task decrements it exactly once, so the count reaching zero
                    # means every task finished and no send is in flight.
                    $!url-lock.protect: {
                        if --⚛$!pending-count == 0 {
                            self!dbg("PQ: pending exhausted, closing queue") if $.debug;
                            try $!queue.close;
                        }
                    }
                }
            }
        };

        self!dbg("PQ: awaiting $workers workers") if $.debug;
        await @workers;
    }

    method !fetch-robots() {
        return unless $.respect-robots;
        my $origin = self!origin-of($.url);
        # The seed fetch completes before any worker starts, so it cannot race
        # today, but running it under the origin's own lock means every
        # %!robots / %!crawl-delay access is serialized by the same per-origin
        # lock the worker path uses (writes under it in !ensure-robots, reads
        # under it for the crawl-delay check).
        my $lock = $!robots-lock.protect: { %!robots-locks{$origin} //= Lock.new };
        $lock.protect: { self!ensure-robots($origin) };
    }

    #| Ensure robots rules are known for an origin, fetching its robots.txt once
    #| per origin. Failures (network error, non-200, unparseable body) are cached
    #| as allow-all so a 404 host is not refetched for every page. Callers hold
    #| $!robots-lock so concurrent workers fetch each origin exactly once; the
    #| double-checked :exists guard keeps repeat calls lock-free at the call
    #| site, but every writer runs under the lock.
    method !ensure-robots(Str $origin) {
        return unless $.respect-robots;
        return if %!robots{$origin}:exists;

        my $robots-url = $origin ~ '/robots.txt';
        self!dbg("fetching robots.txt from $robots-url") if $.debug;
        my ($actions, $fetch-error) = fetch-robots(
            $robots-url,
            $!http,
            :debug(-> Str $m {
                self!dbg("$m") if $.debug;
            })
        );

        if $actions {
            %!robots{$origin} = $actions;
            %!crawl-delay{$origin} = $actions.get-crawl-delay($.user-agent) // 0;
            self!dbg("crawl-delay = %!crawl-delay{$origin}") if $.debug;
        }
        elsif $fetch-error {
            # Informational (the message ends in "(ignored)"), so it belongs
            # on stderr and only when tracing: robots fetch failures are
            # routine (404s, network blips) and must not pollute stdout,
            # which breaks `sitemap ... > file` pipelines.
            note $fetch-error if $.verbose;
            %!robots{$origin} = Nil;
        }
        else {
            # Non-200 or unparseable robots.txt: ignore (allow-all), but still
            # cache so the origin is not refetched on every page.
            note "Ignoring unobtainable robots.txt at $robots-url (allow-all)" if $.verbose;
            %!robots{$origin} = Nil;
        }
    }

    method !crawl-page(Str $url, Int $depth, Int $hops = 0) {
        self!dbg("CP ENTER: $url depth=$depth") if $.debug;
        return if $.max-depth && $depth > $.max-depth;

        return unless $url ~~ /^ :i https? \: \/\//;

        # Skip excluded file extensions. Children never reach this check (they
        # are filtered in !resolve-url before enqueueing), so the only page that
        # can land here is the start URL; report that via on-ignore instead of
        # silently returning an empty crawl.
        if self!is-excluded-extension($url) {
            $!ignore-supplier.emit(($url, 'excluded extension')) if $depth == 0;
            return;
        }

        # Same for --exclude-dirs: children are pre-filtered in !queue-child-links,
        # so a page reaching this check is the start URL. Mirror the extension
        # handling so an excluded start URL is reported rather than silently
        # crawling nothing.
        if self!is-excluded-dir($url) {
            $!ignore-supplier.emit(($url, 'excluded dir')) if $depth == 0;
            return;
        }

        # Cap check first: once max-urls is reached a newly discovered URL is
        # dropped immediately -- before the origin parse, any robots fetch and
        # any crawl-delay sleep -- so those paths never run for a URL that is
        # about to be dropped uncounted. The URL stays marked queued
        # (the %!queued-urls-map FIFO evicts old entries, so it can be
        # re-discovered later), but the re-run is now just this cheap check.
        return if $.max-urls && ⚛$!url-count >= $.max-urls;

        # The origin is computed once per page and shared by the robots check,
        # the crawl-delay enforcement and any later consumers, so a page is
        # never URI-parsed more than once.
        my $origin = self!origin-of($url);

        # Resolve the per-origin robots and crawl-delay locks in a single
        # global critical section, so every page costs exactly one
        # $!robots-lock acquire (the map lookups are the only globally shared
        # state). The per-origin locks themselves serialize only same-origin
        # robots fetches and delay spacing -- never the whole crawl.
        my ($origin-lock, $delay-lock);
        $!robots-lock.protect: {
            $origin-lock = %!robots-locks{$origin} //= Lock.new;
            $delay-lock = %!delay-locks{$origin} //= Lock.new;
        };

        if $.respect-robots {
            # Check each page against its own origin's robots.txt. The seed
            # origin is pre-fetched by start(); foreign origins reached via a
            # cross-origin <base href> are fetched lazily here, exactly once.
            # The fetch runs under the origin's own lock (per-origin locks,
            # created under $!robots-lock) so two workers never fetch the same
            # origin twice, but one origin's slow robots.txt does not block
            # unrelated origins.
            my $rules;
            $origin-lock.protect: {
                self!ensure-robots($origin);
                $rules = %!robots{$origin};
            }
            if $rules {
                unless $rules.allowed($url, $.user-agent) {
                    self!dbg("CP: robots excluded $url") if $.debug;
                    # Only the start URL (depth 0) is surfaced: disallowed children
                    # are dropped silently, as that is the robots contract.
                    $!ignore-supplier.emit(($url, 'robots disallow')) if $depth == 0;
                    return;
                }
            }
        }

        my $should-add = False;
        $!url-lock.protect: {
            if $.max-urls && ⚛$!url-count >= $.max-urls {
                self!dbg("CP: max-urls reached ($url)") if $.debug;
            }
            elsif %!added-urls{$url}:exists {
                # %!queued-urls-map is FIFO-bounded, so a URL forgotten
                # by the cap can be re-queued and reach !crawl-page again.
                # %!added-urls records every URL actually added to the builder,
                # so a repeat pass is detected here instead of duplicating items.
                self!dbg("CP: already added, skipping ($url)") if $.debug;
            }
            else {
                $!url-count⚛++;
                $should-add = True;
                self!dbg("CP: count++ → " ~ ⚛$!url-count) if $.debug;
            }
        }
        return unless $should-add;

        # Every page that passed the guards above was counted in $!url-count.
        # The fetch/handle logic in !process-page releases that slot via
        # !url-finished on the noindex/AMP/error paths and keeps it on the add
        # path; any unexpected exception there must release it too, or "urls
        # found" leaks past the items actually added. $count-handled tracks
        # whether the slot is already balanced, so the guard below releases
        # exactly once and never after a successful add-item.
        my Bool $count-handled = False;
        my $page-ok = try {
            self!process-page($url, $depth, $hops, $origin, $origin-lock, $delay-lock, $count-handled);
            $count-handled = True;
            True;
        }
        unless $page-ok {
            self!url-finished unless $count-handled;
            my $guard-error = $!;
            $guard-error.rethrow if $guard-error;
        }
    }

    #| Fetch and process one page (crawl-delay, retried fetch, single-pass tag
    #| scan, noindex/AMP handling, image/hreflang/video/news extraction, the
    #| builder add and child-link queueing). Every handled outcome returns
    #| normally with the $!url-count slot balanced (the add keeps it, the
    #| ignore/error paths called !url-finished); only an unexpected throw
    #| leaves the slot open for !crawl-page's guard to release. $count-handled
    #| is set right after each internal !url-finished so a later throw (e.g. in
    #| !queue-child-links after the noindex/AMP release) cannot make the guard
    #| release the slot a second time.
    method !process-page(Str $url, Int $depth, Int $hops, Str $origin, Lock $origin-lock, Lock $delay-lock, Bool $count-handled is rw) {

        # Enforce the robots crawl-delay only when an HTTP request is actually
        # about to be made: max-depth/excluded-extension/robots/max-urls tasks
        # return above without fetching, so they must not sleep or hold a
        # delay lock. The delay applies per origin (the host that served the
        # robots.txt), so requests to different hosts are spaced independently.
        # The lock protects only the timestamp read+write; the actual sleep
        # runs OUTSIDE the lock so other same-origin workers can compute
        # their own delay (and wait) concurrently instead of blocking on
        # a sleeping holder.
        my $delay = $origin-lock.protect: { min(%!crawl-delay{$origin} // 0, 60) };
        my $sleep-time;
        if $delay > 0 {
            $delay-lock.protect: {
                my $now = now;
                my $last = %!last-request-time{$origin};
                my $next = $last.defined ?? $last + $delay !! $now;
                $sleep-time = $next - $now if $next > $now;
                # Claim the next slot NOW so concurrent workers compute
                # their delay from this claimed time, not from a stale one.
                %!last-request-time{$origin} = $next;
            }
        }
        sleep($sleep-time) if $sleep-time && $sleep-time > 0;

        self!dbg("CP: fetching $url") if $.debug;
        # fetch-ok is a panic net, not a success flag: non-2xx pages come back
        # fetch-ok True with an Error for !handle-fetch-error below. It is only
        # False if !fetch-with-retries itself panics unexpectedly, so a single
        # page's internal failure skips just that page rather than aborting the
        # whole crawl through the rethrow chain in !crawl-page.
        my ($content, $response, $err, $fetch-ok) = self!fetch-with-retries($url);
        unless $fetch-ok {
            my $crawl-error = $err;
            if $crawl-error.defined {
                note "Crawl internal error for $url: {$crawl-error.message}" if $.verbose;
            }
            self!url-finished;
            $count-handled = True;
            return;
        }

        if self!handle-redirect($response, $url, $depth, $hops, $count-handled) { return; }
        if self!handle-fetch-error($url, $content, $response, $err, $depth, $count-handled) { return; }

        self!dbg("CP: HTTP 2xx for $url") if $.debug;
        self!dbg("CP: body {$content.chars} chars for $url") if $.debug;

        # A 200 with an empty body (or one that decompressed to nothing) is a
        # transport-level anomaly, not a page: the Fetcher treats it as an
        # error, so the Crawler must too, or an empty page would be added to
        # the sitemap as a URL with no content to extract.
        if 200 <= $response.status < 300 && !$content.chars {
            self!dbg("CP: empty HTTP {$response.status} body for $url") if $.debug;
            self!report-page-error($url, $response.status, 'Empty response body');
            return;
        }

        # Content-Type gate: the extension filter cannot catch extensionless
        # endpoints (API routes, /avatar/123, generated PDFs), and scanning a
        # binary body as HTML both wastes CPU and can inject garbage links.
        # A missing/empty header is tolerated (misconfigured but often-HTML
        # servers); anything that is not HTML/XHTML is reported via on-ignore.
        my $content-type = lc(($response.header('Content-Type') // '').Str);
        if $content-type.chars
                && $content-type !~~ /^ [ 'text/html' | 'application/xhtml' ]/ {
            my $short = $content-type.split(';')[0].trim;
            self!dbg("CP: non-HTML content type '$short' for $url") if $.debug;
            $!ignore-supplier.emit(($url, "non-HTML content type: $short"));
            self!url-finished;
            $count-handled = True;
            return;
        }

        # Scan the page once for the tag types the rest of this method needs:
        # meta bodies (noindex/og tags), link bodies (AMP + hreflang), anchor
        # bodies (outgoing hrefs), img/source/video bodies (image/video
        # extraction) and base bodies (<base href>) all come from a single pass
        # instead of one full-page scan per consumer.
        self!dbg("CP: extracting meta/link/a/img/source/video/base/html tags for $url") if $.debug;
        # The default @PAGE-SCAN-TAGS set covers every tag this method needs
        # (meta, link, a, img, source, video, base and html for the AMP check)
        # and compares equal to the constant (via .List, see extract-tag-bodies),
        # so the precompiled $PAGE-SCAN-RX fast path is used instead of the
        # general per-tag scan.
        my %tag-bodies = Sitemap::Grammar::LinkExtract::extract-tag-bodies($content);
        my @meta-tags = %tag-bodies<meta>.list;
        my @link-bodies = %tag-bodies<link>.list;
        self!dbg("CP: found {+@meta-tags} meta tags for $url") if $.debug;

        # Per the HTML spec, relative references in a page resolve against its
        # first <base href> (itself resolved against the document URL), not the
        # page URL. Compute that once and use it for link, image, hreflang and
        # video resolution below; the page's own sitemap URL is untouched. The
        # <base> bodies come from the shared scan above, so no second pass.
        my $base-url = Sitemap::Extraction::effective-base($url, $content, :base-bodies(%tag-bodies<base>.list));
        self!dbg("CP: effective base $base-url for $url") if $.debug;

        # Extract lastmod from HTTP Last-Modified header
        my $lastmod;
        if $.extract-lastmod {
            my $last-modified = $response.header('Last-Modified');
            if $last-modified {
                $lastmod = self!parse-http-date($last-modified);
                note "Extracted lastmod for $url: $lastmod" if $.verbose && $lastmod;
            }
        }

        # Check for noindex meta tag - only skip this specific page, not its children
        # Handle content="noindex", content="noindex, follow", etc.
        self!dbg("CP: checking noindex for $url") if $.debug;
        my $is-noindex = self!is-noindex($content, :@meta-tags);
        # The <html> tag body comes from the same single tag-body scan as
        # everything else, so the AMP marker check adds no second strip pass
        # over the document.
        my $is-amp = so $.ignore-amp && self!is-amp(%tag-bodies<html>[0] // '', :@link-bodies);
        self!dbg("CP: noindex=$is-noindex amp=$is-amp for $url") if $.debug;

        # Extract and queue links (do this even for noindex/AMP pages to discover children)

        self!dbg("CP: extracting hrefs for $url") if $.debug;
        my @links = Sitemap::Grammar::LinkExtract::extract-hrefs-from-bodies(%tag-bodies<a>.list);
        self!dbg("CP: found {+@links} hrefs for $url") if $.debug;

        # Run the shared per-page asset pipeline (images, hreflang, videos and
        # the once-per-page JSON-LD parse) — the same code path as the
        # DirScanner — reusing the tag-body scan from above.
        my %assets = Sitemap::Extraction::extract-page-assets($content, $url,
            :provided-base-url($base-url),
            :%tag-bodies,
            :$.extract-images, :$.extract-hreflang, :$.extract-videos, :$.extract-news,
            :$.max-images, :$.max-videos);
        # Hash values are itemized containers, so slip (|) each out to flatten
        # it into the @ variable — without it `@images` would hold one element
        # that is the whole Array, and Builder.add-item would reject it.
        my @images = |%assets<images>;
        my @links-for-sitemap = |%assets<links>;
        my @videos = |%assets<videos>;
        my @jsonld = |%assets<jsonld>;
        self!dbg("CP: extracted {+@images} images, {+@links-for-sitemap} hreflang, {+@videos} videos for $url") if $.debug;

        # Extract news if enabled (JSON-LD only)
        my @news;
        if $.extract-news && $!news-builder {
            self!dbg("CP: extracting news for $url") if $.debug;
            for extract-news-objects($content, @jsonld) -> %n {
                if %n<stale> {
                    $!stale-news-count⚛++;
                    $!error-supplier.emit({ url => $url, status => Nil, error => "NewsArticle '{%n<title>}' is older than 48 hours, skipping" });
                    next;
                }
                @news.push: Sitemap::Item::News.new(
                    publication => %n<publication>,
                    publication-language => %n<language>,
                    title => %n<title>,
                    publication-date => %n<publication-date>,
                );
            }

            if @news.elems > 0 {
                $!url-lock.protect: { $!news-builder.add-item($url, news => @news) };
            }
            self!dbg("CP: found {+@news} news for $url") if $.debug;
        }

        # Calculate priority based on crawl depth
        my $priority;
        if $.calculate-priority {
            $priority = calculate-priority($depth);
        }

        # Skip adding to sitemap for noindex pages, but still discover children
        if $is-noindex {
            $!ignore-supplier.emit(($url, 'noindex meta'));
            self!url-finished;
            $count-handled = True;
            self!dbg("CP: noindex, count-- → " ~ ⚛$!url-count) if $.debug;
        }
        elsif $is-amp {
            $!ignore-supplier.emit(($url, 'AMP page'));
            self!url-finished;
            $count-handled = True;
            self!dbg("CP: AMP, count-- → " ~ ⚛$!url-count) if $.debug;
        }
        else {
            my Bool $duplicate = False;
            $!url-lock.protect: {
                if %!added-urls{$url}:exists {
                    # TOCTOU: %!queued-urls-map entries are removed only by
                    # FIFO eviction (never when a task is pulled), so this URL
                    # could have been evicted mid-fetch, re-queued by a back-
                    # link, and pulled again before this fetch set %!added-urls
                    # below. Drop the duplicate add and release the count slot
                    # that !crawl-page took up front for this second pass.
                    $duplicate = True;
                }
                else {
                    $!builder.add-item($url,
                        images => @images,
                        videos => @videos,
                        links => @links-for-sitemap,
                        |($lastmod.defined ?? (lastmod => $lastmod) !! ()),
                        |($priority.defined ?? (priority => $priority) !! ()),
                    );
                    %!added-urls{$url} = True;
                }
            }
            if $duplicate {
                self!url-finished;
                $count-handled = True;
                self!dbg("CP: duplicate add dropped, count-- → " ~ ⚛$!url-count) if $.debug;
            }
            else {
                $!add-supplier.emit($url);
                $count-handled = True;
                self!dbg("CP: added to sitemap $url") if $.debug;
            }
        }

        # Queue child links (for both noindex and regular pages). --no-follow
        # skips discovery entirely so only the start URL(s) are crawled.
        self!queue-child-links($url, @links, $depth, $base-url) if $.follow-links;
    }

    #| Handle a 3xx redirect response: resolve the Location target, re-enqueue
    #| it at the same depth (with one more redirect hop), and balance the
    #| url-count slot. Returns True when the redirect was fully handled (caller
    #| must return from !process-page).
    #| Any 3xx carrying a Location is followed (300 may choose, 301/302/303/
    #| 307/308 all redirect); a Location-less 3xx (typically 304) falls through
    #| to !handle-fetch-error, which reports it without surfacing as an on-error.
    #| A re-enqueued redirect is refused once the chain exceeds :max-redirects
    #| hops, mirroring the Fetcher's hop cap.
    method !handle-redirect($response, Str $url, Int $depth, Int $hops, Bool $count-handled is rw --> Bool) {
        return False unless $response && 300 <= $response.status < 400;

        my $loc = try { $response.header('Location') } // '';
        return False unless $loc.chars;
        my $status = $response.status;

        my $target = resolve-relative-url($loc, $url);
        unless $target ~~ /^ :i https? \: \/\// {
            self!dbg("CP: redirect to non-http(s) target dropped ($target)") if $.debug;
            $!ignore-supplier.emit(($url, "redirect to non-http(s) target dropped ($target)"));
            self!url-finished;
            $count-handled = True;
            return True;
        }

        # Strip the fragment and normalize (host case, default port, encoding)
        # so the redirect target is the same canonical URL a direct link to the
        # page would enqueue; otherwise the sitemap entry can carry a quote-style
        # "#..." fragment and a link to the fragment-less form dedups as a
        # different URL. The normalizer does an unguarded URI.new, so a
        # server-controlled Location header that normalizes badly must not abort
        # the page: treat it like any other unresolvable target below.
        my ($normalized, $target-origin) = try {
            self!normalize-url-with-origin($target);
        };
        unless $normalized.defined && $normalized.chars && $target-origin {
            $!ignore-supplier.emit(($url, "redirect to unresolvable target dropped ($target)"));
            self!url-finished;
            $count-handled = True;
            return True;
        }
        $target = $normalized;

        # The same-origin gate applies to a redirect target exactly as it does
        # to a page link: a redirect that leaves the scheme/host/port of the
        # redirecting page's origin is refused instead of being crawled and
        # added to a single-site sitemap. (robots.txt, crawl-delay and max-urls
        # still get their normal look at the target when it is re-enqueued.)
        # The redirect-hop cap bounds chains of endlessly-unique Locations,
        # which mark-queued dedup cannot catch (a fresh target is never seen
        # twice) and which max-urls likewise cannot catch (every hop releases
        # its url-count slot when it is re-enqueued).
        my $next-hops = $hops + 1;
        my $enqueued = False;
        my $reason = '';
        if self!origin-of($url) ne $target-origin {
            $reason = "redirect to $target refused (different origin)";
        }
        elsif $.max-redirects && $next-hops > $.max-redirects {
            $reason = "redirect to $target refused (redirect cap of $.max-redirects hops exceeded)";
        }
        else {
            $!url-lock.protect: {
                if self!mark-queued($target) {
                    my $send-ok = try {
                        $!queue.send([$target, $depth, $next-hops]);
                        $!pending-count⚛++;
                        $enqueued = True;
                        True;
                    };
                    unless $send-ok {
                        %!queued-urls-map{$target}:delete;
                        warn "queue.send failed for redirect target $target (dropped): {$!.message}";
                    }
                }
            }
        }
        note "Redirect HTTP $status: $url -> $target" if $.verbose;
        $!ignore-supplier.emit(($url,
            $reason ?? $reason
                    !! $enqueued ?? "redirected to $target"
                                 !! 'redirect loop/cap'));
        self!url-finished;
        $count-handled = True;
        True;
    }

    #| Handle a non-2xx or undecodable response: attempt an HTTPS→HTTP fallback
    #| on SSL errors when allowed, otherwise report the error. Returns True when
    #| the error was fully handled (caller must return from !process-page).
    method !handle-fetch-error(Str $url, $content, $response, $err, Int $depth, Bool $count-handled is rw --> Bool) {
        return False if $response && 200 <= $response.status < 300 && $content.defined;

        # A 304 Not Modified is a valid conditional response, not a server
        # failure: the crawler sends no conditional headers, so a server that
        # answers 304 anyway (aggressive shared cache) must not be surfaced via
        # on-error. 304 has no body and (per RFC) no Location to follow, so it
        # is simply ignored and the slot released.
        if $response && $response.status == 304 {
            $!ignore-supplier.emit(($url, 'HTTP 304 (not modified)'));
            self!url-finished;
            $count-handled = True;
            return True;
        }

        # Cro throws X::Cro::HTTP::Error for non-2xx responses (no $response
        # object), but the exception carries the real status; recover it so
        # on-error subscribers see e.g. 404 instead of a 0 placeholder.
        my $status = $response ?? $response.status
            !! ($err.defined && $err ~~ X::Cro::HTTP::Error ?? $err.response.status !! 0);
        my $msg = $err ?? $err.message
            !! (($response && 200 <= $response.status < 300) ?? 'Unreadable response body' !! "HTTP $status");

        # BUG7: an https page failing with an SSL/TLS/connection error gets
        # one retry over plain HTTP (case-insensitive match), mirroring the
        # start-URL fallback in crawl(). The retry is tracked per origin
        # (%!fallback-attempted), so each distinct host in a multi-origin crawl
        # gets its own single fallback instead of the whole crawl sharing one.
        if $url.starts-with('https://')
                && $!allow-http-fallback
                && self!is-ssl-error($msg) {
            my $origin = self!fallback-key($url);
            my $http-url = $url.subst(/^ 'https:' \/\//, 'http://');
            my $enqueued = False;
            $!url-lock.protect: {
                if !%!fallback-attempted{$origin} && self!mark-queued($http-url) {
                    my $send-ok = try {
                        $!queue.send([$http-url, $depth, 0]);
                        $!pending-count⚛++;
                        $enqueued = True;
                        True;
                    };
                    unless $send-ok {
                        %!queued-urls-map{$http-url}:delete;
                        warn "queue.send failed for $http-url (dropped): {$!.message}";
                    }
                    %!fallback-attempted{$origin} = True if $enqueued;
                }
            }
            if $enqueued {
                note "HTTPS page failed ($msg), retrying $http-url over HTTP...";
                self!url-finished;
                $count-handled = True;
                return True;
            }
        }
        self!dbg("CP: $msg for $url") if $.debug;
        note "Error: $msg for $url" if $.verbose;
        self!report-page-error($url, $status, $msg);
        True;
    }

    #| Fetch a URL with automatic retries on transient errors. Returns
    #| (Content, Response, Error, fetch-ok). fetch-ok is a panic net, NOT a
    #| success flag: ordinary non-2xx outcomes are reported through Error and
    #| handled by the caller's !handle-fetch-error, so fetch-ok is True for
    #| those too. Every fallible operation below is individually try-guarded,
    #| which guarantees fetch-ok is True by construction today; it can only be
    #| False if a future refactor lets an unexpected exception escape the
    #| retry loop, in which case Error captures it and the caller's net skips
    #| just this page instead of the whole crawl failing.
    method !fetch-with-retries(Str $url --> List) {
        my $content;
        my $response;
        my $err;
        my $max-retries = 3;
        my $fetch-ok = try {
            for ^$max-retries -> $try {
                $err = Nil;
                # Reset the content slot too: a 4xx/5xx attempt that returned a
                # readable body must not survive into a retry whose next read
                # fails (bytes truncated, reset). Otherwise the "success" test
                # below ($content.defined) sees the stale error page as a
                # genuine 2xx body and the crawler scans the error page as if
                # it were the real one.
                $content = Nil;
                $response = try await $!http.get($url);
                if $response {
                    $! = Nil;
                    my $blob = try read-bounded-body($url, $response);
                    if $blob.defined {
                        $content = try decompress-content($url, $blob);
                        if $content.defined {
                            $err = Nil;
                        } elsif !($blob.elems >= 2 && $blob[0] == 0x1f && $blob[1] == 0x8b) {
                            $content = decode-text-body($blob);
                            $err = Nil;
                        } else {
                            $err = $!;
                        }
                    } else {
                        $err = $!;
                    }
                } else {
                    $err = $!;
                }
                last if $response && 200 <= $response.status < 300 && $content.defined;
                # Retry on error-level HTTP status (429, 5xx) even if Cro
                # returned a response object instead of throwing — future Cro
                # versions may adopt this behaviour.
                my $retryable = ($err && self!is-retryable-error($err))
                    || ($response && ($response.status == 429 || $response.status >= 500));
                if $retryable {
                    my $retry-delay = $err ~~ X::Cro::HTTP::Error
                        ?? self!retry-after-delay($err.response, $try)
                        !! $response && $response.status == 429
                            ?? self!retry-after-delay($response, $try)
                            !! 2 ** $try + rand * 0.5;
                    note "Retry {$try + 1} for $url ({$err ?? $err.message !! "HTTP $response.status()"}, sleep {$retry-delay.round(0.01)}s)" if $.verbose;
                    sleep $retry-delay if $try < $max-retries - 1;
                } else {
                    last;
                }
            }
            True;
        };
        return ($content, $response, $fetch-ok ?? $err !! ($! // $err), $fetch-ok);
    }

    method !normalize-url(Str $url --> Str) {
        my ($normalized, $origin) = self!normalize-url-with-origin($url);
        $normalized;
    }

    #| Normalize a URL and also return its normalized origin, so callers that
    #| immediately follow with an origin comparison (link queueing) do not have
    #| to re-parse the resolved URL a second time.
    method !normalize-url-with-origin(Str $url --> List) {
        my $clean = $url.subst(/ '#' .* $ /, '');
        return ('', Nil) unless $clean;

        # A bare domain or scheme-relative //host input must not reach URI.new,
        # which would silently mangle it into an empty-scheme URL and crawl
        # nothing. https is the default just like everywhere else.
        $clean = normalize-start-url($clean);

        # Split off the authority (scheme + host[:port]) so IPv6 host brackets
        # like [::1] survive; only the path/query get the bracket-encoding that
        # URI.new needs, otherwise http://[::1]:8080/x would be mangled.
        my $authority-start = '';
        my $authority = '';
        my $rest = $clean;
        if $clean ~~ / ^ (<[a..zA..Z]>+ '://') (<-[/]>+) ( '/' .* )? $ / {
            $authority-start = ~$0;
            $authority = ~$1;
            $rest = ~($2 // '');
        }

        # Raku's URI module rejects raw brackets and braces; percent-encode
        # them so URI.new below, same-origin checks and the later fetch work.
        my $encoded-rest = $rest.subst('[', '%5B', :g).subst(']', '%5D', :g)
                              .subst('{', '%7B', :g).subst('}', '%7D', :g);
        $clean = $authority-start ~ $authority ~ $encoded-rest;

        # Extract the path from the raw URL to preserve encoding
        # (URI.path.Str decodes percent-encoding, e.g. '+' → ' ')
        $clean ~~ / '://' <-[\/]>+ ( '/' <-[?#]>* ) /;
        my $path-capture = $0;

        # Preserve query string
        my $query = '';
        if $clean ~~ / '?' (<-[#]>+) / {
            $query = '?' ~ $0;
        }

        # A bare host ("https://example.com") and a query-only URL
        # ("https://example.com?x=1") both fail the path capture above because
        # <-[\/]>+ eats everything after the authority. Only the bare host may
        # default to "/": per RFC 3986, "example.com?x=1" (empty path) and
        # "example.com/?x=1" (path "/") are distinct URIs, and turning the
        # former into the latter sitemaps a URL that was never fetched.
        my $path = $path-capture // ($query ?? '' !! '/');

        my $origin = self!origin-of($clean);
        ($origin ~ $path ~ $query, $origin);
    }

    method !origin-of(Str $url --> Str) {
        # Cache lookup is under the shared $!url-lock on every call, including
        # cache hits. The lock is necessary: a concurrent miss mutates the hash
        # (insert/FIFO-evict below), so a lock-free read could observe the map
        # in the middle of a rehash. Contention is modest in practice because
        # the hot same-origin per-link path (!fast-same-origin-resolve) returns
        # before reaching here; !origin-of is hit once per page plus per
        # cross-origin link.
        my $cached;
        $!url-lock.protect: { $cached = %!origin-cache{$url} };
        return $cached if $cached.defined;

        # Compute origin outside the lock (slow — URI.new + canonical-origin).
        my $uri = URI.new($url);
        my $origin = Sitemap::Config::canonical-origin($uri);

        # A hostless/corrupt URI (scheme-only, "file:"/bare path) has no HTTP
        # origin; canonical-origin returns Nil rather than a garbage string.
        # Return an unmatchable sentinel so the plain-Str contract holds and
        # non-http seeds fail the later http():// check instead of crashing.
        $origin = '' unless $origin.defined;

        # Cache insert + FIFO eviction (under lock — fast).
        $!url-lock.protect: {
            # Double-check: another worker may have inserted while we computed.
            # Only push the FIFO marker for keys we actually inserted, so a
            # lost race (//= no-op) doesn't push a duplicate and evict live
            # entries early.
            if %!origin-cache{$url}:!exists {
                %!origin-cache{$url} = $origin;
                @!origin-order.push: $url;
                if @!origin-order.elems > 50_000 {
                    Sitemap::Config::fifo-evict(%!origin-cache, @!origin-order, :cap(50_000), :strategy<half>);
                }
            }
        }
        $origin
    }

    #| Scheme-independent host[:port] key for the HTTPS→HTTP fallback tracker.
    #| Unlike !origin-of (which keeps the scheme so https://host and
    #| http://host are distinct origins), the fallback is per SITE: once a
    #| crawl has re-fetched one host over http, an https child pinned to the
    #| same host (e.g. via <base href>) must not trigger a second retry.
    method !fallback-key(Str $url --> Str) {
        self!origin-of($url).subst(/^ <[a..zA..Z0..9+.\-]>+ '://' /, '');
    }

    #| Resolve a link against the page's base URI. $ctx (a
    #| Sitemap::Config::UriContext) and $base-origin are computed once per page
    #| in !queue-child-links, so the per-link resolve does pure string work and
    #| the same-origin check reuses the page origin instead of rebuilding URIs.
    method !resolve-url(Str $link, URI $base, Sitemap::Config::UriContext $ctx, Str $base-origin) {
        return unless $link;

        return Pair.new('non-web scheme' => $link)
            if $link ~~ m/^ :i [ 'javascript:' | 'mailto:' | 'tel:' | 'data:' ] /;

        my $clean-link = $link.subst(/ '#' .* $ /, '');
        return Pair.new('fragment-only' => $link) unless $clean-link;

        return Pair.new('excluded extension' => $link)
            if self!is-excluded-extension($clean-link);

        # Delegate the RFC 3986 merge (query-only/fragment-only refs, scheme- and
        # root-relative refs, dot-segment collapse, userinfo/port preservation)
        # to the shared Config resolver so Crawler, LinkExtract and the Parser
        # cannot disagree about what a link resolves to. Fragment-only refs were
        # already stripped to '' above, so they drop out here.
        my $result = Sitemap::Config::resolve-reference($clean-link, $base, :$ctx);

        return Pair.new('unresolvable reference' => $link) unless $result;

        #| Fast path: every ref except a scheme-relative (//host/...) or absolute
        #| one inherits the base's scheme+host+port, so its normalized origin is
        #| exactly $base-origin. Only take it when the resolved URL actually
        #| starts with the base origin; otherwise (cross-origin refs) fall
        #| through to the normalizer.  Named for greppability and comment
        #| attachment; extracted from the inline block per issue #12.
        my $fast = self!fast-same-origin-resolve($result, $base-origin, $ctx);
        return $fast if $fast;
        self!normalize-url-with-origin($result);
    }

    #| Fast path for same-origin resolved links: when a resolved URL is on the
    #| same origin as the base, normalize it with pure string ops instead of a
    #| full URI parse. Reproduces !normalize-url-with-origin's output
    #| byte-for-byte: bracket/brace-encode the path+query (the authority keeps
    #| its raw [::1] brackets), strip the fragment, drop an empty trailing query
    #| ("?x" survives, a bare "?" does not — the normalizer's query regex
    #| requires at least one char), drop userinfo, lowercase the host (both
    #| already baked into $base-origin) and default a bare origin to "/".
    #| Returns Nil when the link is cross-origin or has an unexpected form so
    #| the caller falls through to the full normalizer.
    method !fast-same-origin-resolve(Str $result, Str $base-origin, Sitemap::Config::UriContext $ctx --> List) {
        return Nil unless $result.starts-with($ctx.origin);
        my $rest = $result.substr($ctx.origin.chars);
        return Nil unless $rest eq '' || $rest.starts-with('/') || $rest.starts-with('?');
        $rest = $rest.subst('[', '%5B', :g).subst(']', '%5D', :g)
                      .subst('{', '%7B', :g).subst('}', '%7D', :g)
                      .subst(/ '#' .* $ /, '').subst(/ \? $ /, '');
        $rest = '/' ~ $rest if $rest eq '';
        ($base-origin ~ $rest, $base-origin);
    }

    #| Follow the links discovered on a page, enqueueing same-origin children.
    #| The page origin is computed once and each resolved URL arrives with its
    #| origin already normalized, so the per-link check rebuilds no URIs.
    #| $base-url is the page's effective base (its <base href> when present,
    #| per the HTML spec); relative links resolve against it, and the
    #| same-origin gate applies to that base's origin.
    method !queue-child-links(Str $url, @links, Int $depth, Str $base-url) {
        my $base-uri = try { URI.new($base-url) };
        return unless $base-uri.defined && $base-uri.host.defined && $base-uri.host.chars;
        my $ctx = Sitemap::Config::uri-context($base-uri);
        my $base-origin = self!origin-of($base-url);
        my $queued = 0;
        for @links -> $link {
            my $resolved-pair = try { self!resolve-url($link, $base-uri, $ctx, $base-origin) };
            my $resolve-err = $!;
            if $resolve-err {
                note "ERROR resolving '$link': {$resolve-err.Str}" if $.verbose;
                next;
            }
            if $resolved-pair ~~ Pair {
                note "Skipping '$link': {$resolved-pair.key}" if $.verbose;
                next;
            }
            unless $resolved-pair {
                note "ERROR resolving '$link': unresolved/unknown" if $.verbose;
                next;
            }

            # Only follow internal links (same scheme, host and effective port,
            # case-insensitive). !resolve-url returns the resolved URL together
            # with its normalized origin, so no re-parsing happens here.
            my ($resolved, $resolved-origin) = $resolved-pair;
            next unless $resolved-origin && $resolved-origin eq $base-origin;

            # Skip URL path prefixes configured via --exclude-dirs
            next if self!is-excluded-dir($resolved);

            # Atomically check-and-queue under lock. The max-depth check runs
            # BEFORE mark-queued: a URL beyond the depth limit must not be marked
            # as queued, or a later link reaching it at a valid depth would be
            # deduped and the page silently dropped (mark-before-send race).
            $!url-lock.protect: {
                unless $.max-depth && $depth + 1 > $.max-depth {
                    if self!mark-queued($resolved) {
                        my $child-send-ok = try {
                            $!queue.send([$resolved, $depth + 1, 0]);
                            $queued++;
                            $!pending-count⚛++;
                            True;
                        };
                        unless $child-send-ok {
                            # Un-mark on failure so the URL can be
                            # re-discovered and re-queued later instead
                            # of being permanently lost.
                            %!queued-urls-map{$resolved}:delete;
                            warn "queue.send failed for $resolved (dropped): {$!.message}";
                        }
                    }
                }
            };
        }
        self!dbg("CP EXIT: $url depth=$depth queued=$queued") if $.debug;
    }

    method !is-excluded-extension(Str $url --> Bool) {
        # Extension lookup considers only the URL's path, never its host: a
        # start URL like https://foo.zip must not be dropped because "zip"
        # happens to be in the exclusion lists (see url-path-extension).
        my $ext = url-path-extension($url);
        return False unless $ext.chars;
        # Check both default and extra exclusion lists
        so %.exclude-extensions{$ext} || %.extra-exclude-extensions{$ext};
    }

    #| True when the URL's path starts with one of the configured exclude
    #| prefixes (--exclude-dirs). Prefixes are normalized at TWEAK (no leading
    #| or trailing slash) and must end at a path segment boundary, so /admin
    #| excludes /admin and /admin/x but not /administrator. The catch-all
    #| prefix '' (from --exclude-dirs "/") excludes every path.
    method !is-excluded-dir(Str $url --> Bool) {
        return False unless @!exclude-dirs.elems;
        my $path = $url ~~ / '://' <-[\/]>+ ( '/' <-[?#]>* ) / ?? ~$0 !! '/';
        for @!exclude-dirs -> $prefix {
            return True if $prefix eq '' && $path ~~ /^ \/ /;
            return True if $path eq '/' ~ $prefix;
            return True if $path.starts-with('/' ~ $prefix ~ '/');
        }
        False;
    }

    method !is-noindex(Str $html, :@meta-tags = [] --> Bool) {
        # The KB size and the timing temporaries exist only for the debug
        # messages below; skip computing them entirely when debug is off.
        self!dbg("noindex: scanning {($html.chars / 1024).Int}KB");
        my $now = $.debug ?? now !! 0;
        # The caller always passes the already-extracted meta tags; re-extracting
        # here on an empty list was wasteful and could disagree with the caller
        # (an empty Array is falsy, so `@meta-tags ?? ...` re-ran the parser).
        for @meta-tags -> $tag-body {
            my %attrs = Sitemap::Grammar::LinkExtract::extract-tag-attrs($tag-body);
            # Word-boundary match so directives like "notnoindex" or
            # "noindexed" are not mistaken for "noindex".
            if %attrs<name>:exists && %attrs<name>.lc eq 'robots' && %attrs<content> ~~ / :i <|w> noindex <|w> / {
                self!dbg("noindex: FOUND (took {now - $now}s)");
                return True;
            }
        }
        self!dbg("noindex: not found");
        False;
    }

    #| Whether the page is an AMP page: a <html ... amp|⚡> document (whitespace
    #| optional before the emoji, so <html⚡> counts too) or a canonical
    #| <link rel="amphtml" href=...>. $html-open is the raw body text between
    #| '<html' and '>' (leading whitespace included), captured by the shared
    #| extract-tag-bodies scan in !crawl-page; the caller no longer re-strips
    #| the whole document for the AMP check. The rel check is scoped to
    #| real <link> tags, so a literal rel="amphtml" in a script or body text
    #| cannot mark a normal page as AMP.
    method !is-amp(Str $html-open, :@link-bodies = [] --> Bool) {
        return True if Sitemap::Grammar::LinkExtract::is-amp-html-open($html-open);
        for @link-bodies -> $tag-body {
            my %attrs = Sitemap::Grammar::LinkExtract::extract-tag-attrs($tag-body);
            # rel may carry multiple space-separated tokens, so match the token
            # set case-insensitively ("amphtml" or "alternate amphtml").
            my $is-amphtml = so (%attrs<rel> // '').lc.split(/\s+/).grep(*.chars).grep(* eq 'amphtml');
            return True if $is-amphtml && (%attrs<href>:exists);
        }
        False;
    }

    method !parse-http-date(Str $date-str) {
        # parse-date(:optional) returns Nil for unparseable Last-Modified headers
        # instead of dying (parse-date throws on bad input, so the old
        # `parse-date($date-str) // Nil` never actually returned Nil).
        parse-date(:optional, $date-str)
    }

    #| Whether a fetch failure warrants a retry: transient HTTP/2 stream errors
    #| (PROTOCOL_ERROR, REFUSED_STREAM, ENHANCE_YOUR_CALM) or an HTTP status the
    #| server asked us to slow down for (429 Too Many Requests, any 5xx). Other
    #| 4xx responses (e.g. 404) are permanent and never retried, so a dead link
    #| is not hammered.
    method !is-retryable-error($err --> Bool) {
        my $msg = $err.defined && $err.message.defined ?? $err.message !! '';
        # Transport-level failures never carry an HTTP status, so they are
        # recognized from the message: header/body timeouts, refused or reset
        # connections, an HTTP/1.1 connection closed before the response, and
        # DNS resolution failures are all transient ("an sitemap generator
        # should not give up on one hiccup"). HTTP/2 transport error names
        # (PROTOCOL_ERROR, REFUSED_STREAM, ENHANCE_YOUR_CALM, GOAWAY) appear
        # literally in the message and are equally retryable. Distinct 4xx
        # responses never match these terms, so a dead link stays dead. The :i
        # adverb wraps the whole alternation (a bare ':i foo|bar' scopes to the
        # first branch only), so 'Connection refused' and 'Timed out' match too.
        return True if $msg ~~ / :i [ 'timeout' | 'timed out' | 'connection refused'
                            | 'connection reset' | 'connection closed'
                            | 'closed before response' | 'reset by peer'
                            | 'name or service not known'
                            | 'temporary failure in name resolution'
                            | 'failed to resolve' | 'unable to resolve' | 'dns'
                            | PROTOCOL_ERROR | REFUSED_STREAM | ENHANCE_YOUR_CALM
                            | GOAWAY ] /;
        return False unless $err ~~ X::Cro::HTTP::Error;
        my $status = $err.response.status;
        so $status == 429 || $status >= 500;
    }

    #| Whether an error message indicates an SSL/TLS transport failure that
    #| warrants an HTTPS→HTTP fallback.  The same pattern appears in crawl()
    #| (start-URL fallback) and !process-page (per-page fallback); keeping it
    #| in one place ensures the regex stays in sync.  Matching is restricted to
    #| TLS-scoped markers: broader terms like 'connection' or 'timeout' also
    #| match "Connection refused"/"Connection reset by peer"/"read timeout",
    #| which are not TLS failures and downgrading for them rarely helps.
    method !is-ssl-error(Str $msg --> Bool) {
        so $msg ~~ / :i 'SSL' | 'TLS' | 'certificate' | 'negotiation' /;
    }

    #| Backoff delay before retrying a failed HTTP request. Honours the
    #| Retry-After header when present (delta seconds, or an HTTP-date), capped
    #| at 60s so a hostile header cannot stall the crawl; otherwise falls back
    #| to the exponential backoff used for transport-level errors.
    method !retry-after-delay($response, Int $try --> Numeric) {
        my $header = try $response.header('Retry-After');
        if $header.defined {
            my $seconds = try { $header.Int };
            if $seconds.defined {
                return min(max($seconds, 0), 60);
            }
            my $when = self!parse-http-date($header);
            if $when.defined {
                return min(max($when.posix - now, 0), 60);
            }
        }
        2 ** $try + rand * 0.5;
    }

    method urls-found( --> Int) {
        ⚛$!url-count;
    }

    method stale-news-count( --> Int) {
        ⚛$!stale-news-count;
    }
}

=begin pod

=head1 NAME

Sitemap::Crawler - Crawl websites to discover URLs

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Crawler;

my $crawler = Sitemap::Crawler.new(url => 'https://example.com');

$crawler.on-add: -> $url { say "Found: $url" };
$crawler.on-ignore: -> $url, $reason { say "Ignored: $url - $reason" };
$crawler.on-error: -> %err { say "Error: %err<url> (%err<status>): %err<error>" };
$crawler.on-done: -> @urls { say "Total: @urls.elems()" };

$crawler.start;

# Or get the sitemap directly
my $builder = $crawler.crawl;
$builder.write: 'sitemap.xml';

# Exclude additional file extensions (merges with defaults)
$crawler = Sitemap::Crawler.new(
    url => 'https://example.com',
    extra-exclude-extensions => %('mp4' => True, 'mp3' => True)
);

=end code

=head1 METHODS

=head2 new(Str :$url, Str :$user-agent, Int :$max-depth, Int :$max-urls, Bool :$respect-robots, Bool :$ignore-amp, Bool :$verify-ssl, Bool :$extract-images, Bool :$extract-hreflang, Bool :$extract-videos, Bool :$extract-news, Bool :$extract-lastmod, Bool :$calculate-priority, Int :$max-redirects, Hash :%exclude-extensions, Hash :%extra-exclude-extensions, Str :@exclude-dirs, Int :$max-images, Int :$max-videos, Bool :$follow-links, Bool :$verbose)

Create a new crawler. C<$url> is the starting URL.

C<:exclude-dirs> takes a list of URL path prefixes to skip (comma-separated
values are accepted too). A prefix matches at a path segment boundary, so
C</admin> excludes C</admin> and C</admin/x> but not C</administrator>.

C<:max-images> caps the number of images extracted per page (default: 1000,
matching Google's limit). C<:follow-links> (default True) controls whether
links discovered on pages are followed; set it False to crawl only the start
URL. C<:max-redirects> caps how many consecutive 3xx redirects a single URL
chain may follow (default: 5, matching the Fetcher); redirect loops are
already stopped by the visited-set dedup, this bounds never-repeating chains.

Extraction flags (all default True unless noted):

=item C<:extract-images> - Extract images from pages.
=item C<:extract-hreflang> - Extract hreflang links.
=item C<:extract-videos> - Extract video metadata from HTML tags and JSON-LD (default: False).
=item C<:extract-news> - Extract NewsArticle JSON-LD into a separate news builder (default: False).
=item C<:extract-lastmod> - Extract lastmod from HTTP Last-Modified headers.
=item C<:calculate-priority> - Calculate priority from crawl depth.
=item C<:max-videos> - Cap the number of videos extracted per page (default: 100).

The C<:extra-exclude-extensions> parameter takes a Hash of extensions (mapping
each extension to True, e.g. C<(mp4 => True, mp3 => True)>) and adds them to the
default exclusion list
(ico, css, js, woff, woff2, ttf, eot, zip, tar, gz, pdf, doc, docx, rss, atom, xml).
Using C<:exclude-extensions> replaces ALL defaults.

=head2 exclude-extensions(--> Hash)

Get or set the excluded extensions hash.

=head2 on-add(&code)

Register a callback for when a URL is added to the sitemap.

=head2 on-ignore(&code)

Register a callback for when a URL is ignored.

=head2 on-error(&code)

Register a callback for errors. The callback receives a Hash with C<url>,
C<status> (HTTP code or Nil for fetch/parse errors), and C<error> (message)
keys.

=head2 on-done(&code)

Register a callback for when crawling is complete.

=head2 start()

Start crawling. Emits events as URLs are discovered.

=head2 crawl( --> Sitemap::Builder)

Start crawling and return the Sitemap::Builder with all discovered URLs.

=head2 news-builder( --> Sitemap::Builder)

Returns the news sitemap builder populated with extracted NewsArticle objects.
Returns C<Nil> if C<extract-news> was not enabled.

=head2 urls-found( --> Int)

Get the number of URLs discovered.

=head2 close()

Release crawl resources (the worker queue). Safe to call in a C<LEAVE> block of
long-lived callers so the channel cannot linger after an early error exit. The
event suppliers are left open, so a subsequent C<crawl()> on the same instance
still works.

=end pod
