use v6.d;

use Sitemap::Item;
use Sitemap::Builder;
use YAMLish;
need Sitemap::Config;

class Sitemap::SiteTree {
    # Global structural-revision counter shared by every node. attach-child /
    # remove-child bump it in O(1) instead of walking (and clearing the caches
    # of) every descendant, which made a deep chain quadratic (A10). Each node
    # records the revision it last computed its segments/depth at and
    # invalidates only when this global counter has moved on.
    #
    # Deliberately shared across ALL instances (not per-tree): a node's
    # segments/depth cache is validated against a revision that must be common
    # to the whole tree, yet a node is created standalone and only later joins
    # a tree via attach-child, so no per-instance epoch can be established at
    # construction. A tree-scoped revision would risk serving stale
    # segments/depth on a node that joined mid-build. The global counter is
    # correct (caches never go stale) at the cost of a harmless cross-tree
    # recompute when independent trees are built adjacently.
    my atomicint $REVISION = 0;

    has Str               $.stub = '';
    has Str               $.parent-stub;
    has Sitemap::SiteTree $.parent is rw;
    has Sitemap::SiteTree @.children;
    # Parallel stub index for @!children: the duplicate check in
    # attach-child would otherwise be a linear scan per wire, making a wide
    # fan-out (a flat root with N children) quadratic.
    has SetHash           $!stub-set = SetHash.new;
    has Sitemap::Item     $.item is rw;
    has List             $!segments-cache;
    has atomicint         $!segments-revision = -1;
    has Int               $!depth-cache;
    has atomicint         $!depth-revision = -1;

    method attach-child(Sitemap::SiteTree $child) {
        die "Duplicate child stub: '{$child.stub}' under '$.stub'"
            if $!stub-set{$child.stub}:exists;
        # Reject attaching an ancestor as a child of its own descendant —
        # this would create a cycle that makes segments/depth/flatten recurse
        # forever (e.g. two wire-parents entries pointing at each other). The
        # walk is only needed when the child is already part of a tree (it has
        # a parent or descendants): a freshly created child of add-child has
        # neither and, having just been allocated, cannot be an ancestor of
        # anything. Guarding on that keeps a linear chain build O(n) instead of
        # O(n²) (walking self's ancestry grows with depth) (A10).
        if $child.parent.defined || $child.children.elems {
            my $ancestor = self;
            while $ancestor.defined {
                die "Cycle detected: cannot attach '{ $child.stub }' as a child of its own descendant '{ $ancestor.stub }'"
                    if $ancestor === $child;
                $ancestor = $ancestor.parent;
            }
        }
        # Reparenting: drop the child from its previous parent's children list
        # so one node cannot appear under two parents (which would make
        # children/flatten walk it twice).
        if $child.parent.defined {
            $child.parent!remove-child($child);
        }
        $child.parent = self;
        # The caches are validated against the shared $REVISION below, so a
        # structural change needs no descendant walk: bump the counter once
        # (O(1)) and every node's segments/depth lazily recomputes on next
        # read. Previously attach-child cleared every descendant's cache, which
        # made building a deep chain quadratic.
        $REVISION⚛++;
        @!children.push: $child;
        $!stub-set{$child.stub} = True;
    }

    method !remove-child(Sitemap::SiteTree $child) {
        @!children = @!children.grep(* !=== $child);
        $!stub-set{$child.stub}:delete;
        $REVISION⚛++;
    }

    method add-child(Str $stub, *%item-args --> Sitemap::SiteTree) {
        # Whitelist the URL-safe charset instead of blacklisting a few bad
        # characters: a query '?' or fragment '#' would be appended verbatim to
        # the URL by full-url, producing a broken loc; '..' or '.': stubs
        # collapse path segments; control characters / slashes / colons would
        # warp the URL or the filesystem tree. Only these characters may
        # be bound programmatically; a user wanting richer paths should pass
        # explicit URLs via the builder.
        die "Invalid stub '$stub': only URL-safe characters a-z, A-Z, 0-9, '.', '_', '-' are allowed"
            unless $stub ~~ /^ <[A..Za..z0..9._-]>+ $/
                && $stub ne '.'
                && $stub ne '..'
                && !$stub.contains('..');

        my %init = :$stub;
        if %item-args {
            my %coerced = %item-args;
            with %coerced<changefreq> {
                if $_ ~~ Str {
                    my $cf = try { coerce-changefreq($_) };
                    $cf.defined
                        ?? (%coerced<changefreq> = $cf)
                        !! (%coerced<changefreq>:delete);
                }
            }
            # Item url defaults to ''; to-builder computes actual URL from tree position
            %init<item> = Sitemap::Item.new(|%coerced);
        }

        my $child = self.new(|%init);
        self.attach-child($child);
        $child;
    }

    method segments (--> List) {
        # Validate the cache against the shared structural revision rather than
        # re-walking unconditionally: a walk only happens after a structural
        # change since this node was last read (A10). `//= do` is gone because
        # a stale (revision-older-) cache must be recomputed even when defined;
        # the empty root list still must be cached (an empty Array is falsy).
        if $!segments-revision != $REVISION || !$!segments-cache.defined {
            my @parts;
            my $node = self;
            while $node.parent.defined {
                @parts.unshift: $node.stub if $node.stub.chars;
                $node = $node.parent;
            }
            $!segments-cache = @parts.List;
            $!segments-revision = $REVISION;
        }
        $!segments-cache;
    }

    method full-url(Str $base-url --> Str) {
        my $path = $.segments.join('/');
        my $base = $base-url ?? $base-url.subst(/\/+ $/, '') !! '';
        $path ?? ($base ?? "$base/$path" !! "/$path") !! $base
    }

    method depth (--> Int) {
        if $!depth-revision != $REVISION || !$!depth-cache.defined {
            my $d = 0;
            my $node = self;
            while $node.parent.defined { $d++; $node = $node.parent }
            $!depth-cache = $d;
            $!depth-revision = $REVISION;
        }
        $!depth-cache;
    }

    method tree(Int $depth = 0 --> Str) {
        ('  ' x $depth) ~ "-$.stub\n" ~
            [.tree($depth + 1) for @!children].join
    }

    method flatten (--> List) {
        self!flatten-with-depth.map(*[0]).List;
    }

    #| Walk the tree once, depth-first, root first, yielding (node, depth)
    #| pairs. to-builder consumes the depth directly instead of calling
    #| .depth on every node, which would otherwise walk each node back up to
    #| its root.
    method !flatten-with-depth (--> List) {
        my @pairs;
        my $walk = sub (Sitemap::SiteTree $node, Int $depth) {
            @pairs.push: ($node, $depth);
            for $node.children -> $child { $walk($child, $depth + 1) }
        }
        $walk(self, 0);
        @pairs;
    }

    method to-builder(Str $base-url, *%opts --> Sitemap::Builder) {
        my $builder = Sitemap::Builder.new(|%opts);

        for self!flatten-with-depth -> ($node, $depth) {
            my $url = $node.full-url($base-url);
            my %item-args;
            with $node.item {
                %item-args<priority> = .priority if .priority.defined;
                %item-args<lastmod> = .lastmod if .lastmod;
                %item-args<changefreq> = .changefreq if .changefreq.defined;
                %item-args<expires> = .expires if .expires;
                %item-args<title> = .title if .title;
                %item-args<android-link> = .android-link if .android-link;
                %item-args<amp-link> = .amp-link if .amp-link;
                %item-args<images> = .images if .images;
                %item-args<videos> = .videos if .videos;
                %item-args<links> = .links if .links;
                %item-args<news> = .news if .news;
            }
            %item-args<priority> //= Sitemap::Config::calculate-priority($depth);

            $builder.add-item($url, |%item-args);
        }

        $builder;
    }

    method wire-parents(Sitemap::SiteTree: @nodes) {
        my %by-stub;
        for @nodes -> $n {
            die "Duplicate stub '{ $n.stub }' in wire-parents node list"
                if %by-stub{$n.stub}:exists;
            %by-stub{$n.stub} = $n;
        }
        for @nodes -> $n {
            with $n.parent-stub -> $ps {
                with %by-stub{$ps} -> $parent {
                    $parent.attach-child($n)
                }
                else {
                    die "Parent stub '$ps' not found"
                }
            }
        }
    }

    method to-hash(--> Hash) {
        my %h = stub => $.stub;
        if $!item.defined {
            %h<item> = $!item.to-hash;
        }
        # The live parent (set by attach-child) is authoritative; parent-stub
        # is only a wire-parents input and can go stale after a reparent, so
        # serialize the actual nesting and keep the stub as a fallback for
        # unattached nodes.
        if $!parent.defined && $!parent.stub.chars {
            %h<parent-stub> = $!parent.stub;
        }
        elsif $!parent-stub.defined {
            %h<parent-stub> = $!parent-stub;
        }
        %h<children> = [@!children.map(*.to-hash)] if @!children;
        %h
    }

    method from-hash(Sitemap::SiteTree: Hash $h --> Sitemap::SiteTree) {
        my $node = self.new(
            stub => $h<stub> // '',
            # parent-stub is Str with a Nil default; pass Nil (not a Str type
            # object) when the hash has no entry, so the attribute stays
            # undefined and .defined/truthiness checks keep working.
            parent-stub => $h<parent-stub>:exists ?? $h<parent-stub> !! Nil,
            # :exists, not truthiness: an item hash may be empty ({ } is falsy)
            # and must still round-trip as a defined (empty) item. Nil (not the
            # Sitemap::Item type object) marks the absence of an item.
            item => $h<item>:exists && $h<item>.defined ??
                # Tree items carry metadata (changefreq/priority/...); their
                # url is derived from the tree position and may be absent, so
                # Item.from-hash's url-is-required check must be relaxed here.
                Sitemap::Item.from-hash($h<item>, :allow-empty-url)
                !! Nil,
        );
        for @($h<children> // []) -> $child-hash {
            $node.attach-child(Sitemap::SiteTree.from-hash($child-hash));
        }
        $node
    }

    method to-yaml(--> Str) {
        save-yaml(self.to-hash)
    }

    method from-yaml(Sitemap::SiteTree: Str $yaml --> Sitemap::SiteTree) {
        my $h = load-yaml($yaml);
        die "YAML root must be a mapping" unless $h ~~ Hash;
        self.from-hash($h)
    }
}

=begin pod

=head1 NAME

Sitemap::SiteTree - Build sitemaps from a hierarchical site tree

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::SiteTree;

# Build a tree programmatically
my $root = Sitemap::SiteTree.new;
my $blog = $root.add-child('blog', :priority(0.8));
$blog.add-child('first-post');

# Generate sitemap with depth-inferred priorities
my $builder = $root.to-builder('https://example.com');
$builder.write: 'sitemap.xml';

# Or wire parents from a flat list (like Air::Base)
my $home  = Sitemap::SiteTree.new(:stub<home>,  :item(Sitemap::Item.new(:url('/'))));
my $about = Sitemap::SiteTree.new(:stub<about>, :parent-stub<home>);
Sitemap::SiteTree.wire-parents([$home, $about]);

# Serialize to/from YAML
my $yaml = $root.to-yaml;
my $reconstructed = Sitemap::SiteTree.from-yaml($yaml);

=end code

=head1 DESCRIPTION

C<Sitemap::SiteTree> models a hierarchical website structure.
Each node represents a URL path segment (C<stub>) with an optional
C<Sitemap::Item> for metadata. URLs are computed from tree position,
so there is no need to specify full URLs — just stubs and parent
relationships.

=head1 PRIORITY BY DEPTH

When generating a sitemap via C<to-builder>, priorities are automatically
inferred from tree depth unless the node's item already has an explicit
priority:

=item Depth 0 (root) — C<1.0>
=item Depth 1 — C<0.8>
=item Depth 2 — C<0.6>
=item Depth 3 — C<0.4>
=item Depth 4 — C<0.2>
=item Depth 5 and deeper — C<0.1> (floored)

=head1 METHODS

=head2 add-child(Str $stub, *%item-args --> Sitemap::SiteTree)

Create and attach a child node. Accepts optional item attributes
(C<:lastmod>, C<:changefreq>, C<:priority>, etc.) which are used to
construct a C<Sitemap::Item>. Dies on duplicate stubs under the same
parent.

=head2 attach-child(Sitemap::SiteTree $child)

Attach an existing node as a child. Sets the child's C<$.parent>.

=head2 segments( --> List)

Returns the list of path segments from root to this node, e.g.
C<("blog", "first-post")>. The root stub is excluded.

=head2 full-url(Str $base-url --> Str)

Returns the full URL by joining C<$base-url> with C<segments>, e.g.
C<https://example.com/blog/first-post>.

=head2 depth( --> Int)

Number of path segments (0 for root).

=head2 tree(Int $depth = 0 --> Str)

Returns a debug tree visualization with indentation.

=head2 flatten( --> List)

Depth-first traversal returning all nodes as a flat list.

=head2 to-builder(Str $base-url, *%opts --> Sitemap::Builder)

Generates a C<Sitemap::Builder> populated with all nodes. URLs are
computed from tree position. Priority uses depth-based defaults
unless the node's item has an explicit priority.

=head2 wire-parents(@nodes)

Class method. Resolves C<$.parent-stub> references across a list of
nodes and attaches children to their parents. Dies if a referenced
parent stub is not found.

=head2 to-hash( --> Hash)

Serialize the tree to a plain hash of native Raku types. Recursively
converts all nodes and their items via C<to-hash>. Parent relationships
are encoded via C<parent-stub> and the nested C<children> array.

=head2 from-hash(Hash $h --> Sitemap::SiteTree)

Class method. Reconstruct a tree from a hash produced by C<to-hash>.
Child nodes are attached recursively via C<attach-child>.

=head2 to-yaml( --> Str)

Serialize the tree to a YAML string. Delegates to L<YAMLish>'s
C<save-yaml> after converting via C<to-hash>.

=begin code :lang<raku>
my $yaml = $root.to-yaml;
"site-tree.yml".IO.spurt: $yaml;
=end code

=head2 from-yaml(Str $yaml --> Sitemap::SiteTree)

Class method. Reconstruct a tree from a YAML string produced by
C<to-yaml>. Delegates to C<load-yaml> then C<from-hash>.

=begin code :lang<raku>
my $yaml = "site-tree.yml".IO.slurp;
my $tree = Sitemap::SiteTree.from-yaml($yaml);
=end code

=head1 AUTHOR

Sasha Abbott

=head1 COPYRIGHT AND LICENSE

Copyright 2026 Sasha Abbott

This library is free software; you can redistribute it and/or modify
it under the CC0 1.0 Universal license.

=end pod
