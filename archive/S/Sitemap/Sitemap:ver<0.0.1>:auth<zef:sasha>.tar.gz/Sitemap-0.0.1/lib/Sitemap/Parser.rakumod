use v6.d;

use LibXML;
use URI;
use Sitemap::Item;
use Sitemap::Config;
use Cro::HTTP::Client;
use Syndicate::Utils;

#| Unified return type for multi-file/recursive parse methods.  Provides
#| attribute access (.items, .errors, .sitemaps, .urls-parsed, .files-parsed)
#| and backward-compatible hash-style access via AT-KEY so existing callers
#| using $result<items> continue to work unchanged.
my class ParseResult {
    has @.items;
    has @.errors;
    has @.sitemaps;
    has Int $.urls-parsed = 0;
    has Int $.files-parsed = 0;

    method AT-KEY(\key) {
        given key {
            when 'items'        { @!items }
            when 'errors'       { @!errors }
            when 'sitemaps'     { @!sitemaps }
            when 'urls-parsed'  { $!urls-parsed }
            when 'files-parsed' { $!files-parsed }
            default             { Nil }
        }
    }

    method EXISTS-KEY(\key --> Bool) {
        so key eq any('items', 'errors', 'sitemaps', 'urls-parsed', 'files-parsed')
    }
}

class Sitemap::Parser {

    #| Parse XML with hardened options: no network access, no DTD loading
    #| (blocks XXE / billion-laughs), no external entities, no XInclude.
    #| $huge relaxes libxml2's hard node/text-size caps; it is only ever
    #| enabled for trusted local files, never for strings or network
    #| content.
    method !parse-doc(Bool :$huge = False, *%args) {
        LibXML.parse(
            |%args,
            :no-network,
            :!expand-entities,
            :!dtd,
            :!load-ext-dtd,
            :huge($huge),
            :!xinclude,
        );
    }

    #| True when the document's root element is <sitemapindex>. Anchored to
    #| the start of the payload (after whitespace, optional BOM, XML
    #| declaration and DOCTYPE) so stray "sitemapindex" text in comments,
    #| CDATA or <loc> values is not mistaken for a sitemap index. The
    #| optional <!DOCTYPE ...> (possibly with an internal subset) is common on
    #| W3C-schema sitemaps and must not hide the root element.
    method is-sitemap-index(Str $xml --> Bool) {
        # Generators routinely emit an XML comment (e.g. a "generator" banner)
        # between the declaration and the root element, so comments are allowed
        # anywhere in the preamble. Detection still anchors on the root element,
        # so an HTML page that merely *mentions* <sitemapindex> in a body
        # comment is not misclassified.
        so $xml ~~ / :i ^ \s* \x[FEFF]?
                        ['<!--' (\N|\n)*? '-->' \s*]*
                        ['<?xml' <-[?]>+ '?>' \s* \x[FEFF]? ['<!--' (\N|\n)*? '-->' \s*]*]?
                        ['<!DOCTYPE' <-[>]>* ('[' <-[\]]>* ']' <-[>]>*)? '>' \s*
                         ['<!--' (\N|\n)*? '-->' \s*]*]?
                        '<sitemapindex' <-[>]>* '>' /;
    }

    method parse-xml-file(IO::Path() $file --> List) {
        # Parse through !load-xml-file, not a direct LibXML `file =>` parse:
        # a .gz sitemap (or one whose low-level traffic is gzip magic) must be
        # decompressed before LibXML, or the parser hits "Start tag expected"
        # on the binary payload. The decode keeps the shared decompression-bomb
        # guard from Sitemap::Config. An undecodable body raises a clear error
        # here (the LibXML-level failure already surfaces via !load-xml-file's
        # unguarded parse).
        my $doc = self!load-xml-file($file);
        die "Failed to decode $file as XML" unless $doc.defined;
        self!parse-document($doc);
    }

    method parse-xml-string(Str $xml --> List) {
        my $doc = self!parse-doc(string => $xml);
        self!parse-document($doc);
    }

    method parse-xml-index-file(IO::Path() $file --> List) {
        my $doc = self!load-xml-file($file);
        die "Failed to decode $file as XML" unless $doc.defined;
        self!parse-index-document($doc);
    }

    method parse-xml-index-string(Str $xml --> List) {
        my $doc = self!parse-doc(string => $xml);
        self!parse-index-document($doc);
    }

    method parse-xml-files(*@files, :$parallel = True) {
        my @items;
        my @errors;

        # A failed `try` returns Any (not a Failure), so the actual exception
        # must be recovered from $! right after the try expression.
        my &parse-one = -> $file {
            $! = Nil;
            my $result = try self.parse-xml-file($file.IO);
            my $message = $! ?? $!.message
                          !! ($result ~~ Failure ?? $result.exception.message !! Str);
            %( result => $result, message => $message );
        };

        my @out;
        if $parallel && @files.elems > 1 {
            # hyper.map preserves input order (unlike race.map), so results
            # align with @files by index — used below for error attribution.
            #
            # Thread-safety: every parse goes through !parse-doc, i.e. the
            # LibXML module's class-level LibXML.parse entry point, which
            # builds a fresh parser context per call — no parser object or
            # document is shared across threads (libxml2's requirement for
            # concurrent use). The remaining precondition is libxml2 itself
            # being built with thread support, which is the default on every
            # supported platform; if a exotic build lacks it, pass
            # :!parallel to run single-threaded.
            @out = @files.hyper.map(&parse-one);
        }
        else {
            @out = @files.map(&parse-one);
        }

        for @out.kv -> $i, %r {
            if %r<result>.defined {
                @items.push: |%r<result>;
            } else {
                @errors.push: {
                    file => @files[$i].Str,
                    error => %r<message> // 'Failed to parse XML'
                };
            }
        }

        return ParseResult.new(:@items, :@errors);
    }

    method parse-xml-url-recursive(Str $url, :$max-depth = 1, :$verify-ssl = True,
            Bool :$follow-foreign-children = False, Int :$max-children = 1000,
            Int :$concurrency = 4) {
        my @items;
        my @errors;
        my @all-sitemaps;
        my Int $enqueued = 0;

        # Handle file:// URLs by reading local files directly. Delegate to
        # parse-xml-file-recursive so a sitemap index is walked (its <loc>
        # children resolved against the index's directory), not served as a
        # single parse that yields no items; this also fixes the second half
        # of the old bug, where an index's empty List made `$result &&` falsy
        # and surfaced a bogus "Failed to parse XML" error.
        if $url.starts-with('file://') {
            my $path = $url.subst(/^ file '://' /, '');
            my $result = self.parse-xml-file-recursive($path.IO, :$max-depth);
            my @items = |$result<items>;
            my @errors = |$result<errors>;
            return ParseResult.new(
                :@items, :@errors,
                :sitemaps(|$result<sitemaps>),
                :urls-parsed($result<files-parsed>),
            );
        }

        my $http = cached-client(:ssl-verify($verify-ssl));

        # Parallel BFS over a shared Channel. Workers enqueue children before
        # decrementing $pending, so it can only reach zero once every reachable
        # sitemap has been enqueued; the final worker then closes the queue to
        # wake the rest.
        my $results-lock = Lock.new;
        my %visited;
        my $queue = Channel.new;
        # INVARIANT: $queue must stay unbounded. The workers are both the
        # consumers and the producers (enqueue() is called from the workers,
        # under $results-lock), so a bounded channel could let all workers
        # block on send with nobody left to receive -- a deadlock.
        my atomicint $pending = 0;

        sub enqueue(Str $queued-url, Int $depth, Bool :$root = False --> Bool) {
            $results-lock.protect: {
                return False if %visited{$queued-url}:exists;
                # The budget caps child sitemaps only, not the root index
                # itself, and only URLs actually enqueued count — so the dedup
                # check above runs first: already-visited children must not
                # consume the $max-children budget.
                return False if !$root && $enqueued >= $max-children;
                %visited{$queued-url} = True;
                $queue.send([$queued-url, $depth]);
                $pending⚛++;
                $enqueued++ if !$root;
            }
            True;
        }

        # Record a failed task and rebalance the pending counter; when the
        # count hits zero the queue is closed so the remaining workers wake
        # Every worker exit path (HTTP/decode/parse errors and the
        # outer fallback) funnels through here so none can skip the close.
        sub finish-task(%err) {
            $results-lock.protect: { @errors.push: %err };
            if --⚛$pending == 0 { try $queue.close; }
        }

        enqueue($url, 0, :root);

        my $worker-count = max(1, $concurrency);
        my @workers = (^$worker-count).map: {
            start {
                loop {
                    my $task = try $queue.receive;
                    last unless $task.defined;
                    my ($current-url, $depth) = $task;

                    # The fetch/parse/resolve branches below are individually
                    # guarded, but anything that still throws here (a LibXML
                    # hiccup, a malformed child <loc>, a bad enqueue) must not
                    # skip the pending-count decrement + queue close at the
                    # bottom of the loop: that would leave the other workers
                    # stuck on $queue.receive forever. So the whole task body
                    # is wrapped in a statement-form try (a try{}CATCH block
                    # would re-raise here, so the error is recovered from $!).
                    my $task-ok = try {
                        my $response = try { await $http.get($current-url) };
                        my $fetch-error = $!;
                        if !$response || $response.status != 200 {
                            # Cro throws X::Cro::HTTP::Error on non-2xx (no $response),
                            # but the exception carries the real status; recover it.
                            my $status = $response ?? $response.status
                                !! ($fetch-error ~~ X::Cro::HTTP::Error ?? $fetch-error.response.status !! 'Failed to fetch');
                            finish-task({ file => $current-url, error => "HTTP error: $status" });
                            next;
                        }
                        my $blob = try read-bounded-body($current-url, $response);
                        if !$blob.defined {
                            my $msg = $! ?? $!.message !! 'Failed to read body';
                            finish-task({ file => $current-url, error => $msg });
                            next;
                        }
                        my $body = try decompress-content($current-url, $blob);
                        if !$body.defined {
                            my $msg = $! ?? $!.message !! 'Failed to decompress body';
                            finish-task({ file => $current-url, error => $msg });
                            next;
                        }
                        my $doc = try self!parse-xml-content($body);
                        if !$doc {
                            my $msg = $! ?? $!.message !! 'Failed to parse XML';
                            finish-task({ file => $current-url, error => "Failed to parse XML: $msg" });
                            next;
                        }
                        my $root = $doc.documentElement;
                        my $root-name = $root.nodeName;
                        if $root-name eq 'sitemapindex' {
                            $results-lock.protect: { @all-sitemaps.push: $current-url; };
                            my $child-sitemaps = self!parse-index-document($doc);
                            my $next-depth = $depth + 1;
                            if $max-depth == 0 || $next-depth <= $max-depth {
                                my @child-urls = $child-sitemaps.map(*<loc>);
                                my $base-uri = try { URI.new($current-url) };
                                my ($ctx, $base-origin);
                                if $base-uri.defined && $base-uri.host.defined && $base-uri.host.chars {
                                    $ctx = uri-context($base-uri);
                                    $base-origin = $ctx.origin;
                                }
                                for @child-urls -> $child-url {
                                    # Resolve relative <loc> children (e.g. "child.xml",
                                    # "/child.xml", "../child.xml") against the index URL
                                    # before comparing origins, otherwise scheme-less
                                    # children are always dropped.
                                    my $resolved-url = $ctx.defined
                                        ?? resolve-relative-url($child-url, $current-url, :$ctx)
                                        !! resolve-relative-url($child-url, $current-url);
                                    # SSRF guard: only follow same-origin (scheme, host and
                                    # effective port) children unless explicitly requested
                                    # otherwise.  Compare origins for equality — a raw
                                    # prefix check would let lookalike hosts through
                                    # (e.g. base http://host:9001 matching
                                    # http://host:9001.attacker.example/).
                                    unless $follow-foreign-children {
                                        if $base-origin.defined {
                                            next unless normalize-origin($resolved-url) eq $base-origin;
                                        } else {
                                            next unless same-origin($current-url, $resolved-url);
                                        }
                                    }
                                    enqueue($resolved-url, $next-depth);
                                }
                            }
                        }
                        elsif $root-name eq 'urlset' {
                            my $parsed-items = self!parse-document($doc);
                            $results-lock.protect: { @items.push: |$parsed-items; };
                        }
                        True;
                    };
                    unless $task-ok {
                        $results-lock.protect: {
                            @errors.push: {
                                file => $current-url,
                                error => "Unexpected error: {$!.message}",
                            };
                        }
                    }

                    if --⚛$pending == 0 { try $queue.close; }
                }
            }
        };
        await @workers;

        return ParseResult.new(
            :@items,
            :@errors,
            :sitemaps(@all-sitemaps),
            :urls-parsed(%visited.elems)
        );
    }

    method parse-xml-file-recursive(IO::Path() $file, :$max-depth = 1) {
        my @items;
        my @errors;
        my @all-sitemaps;
        my %visited;
        my Int $parsed-count = 0;

        my @queue = ({ file => $file, depth => 0 },);
        my $head = 0;

        while $head < @queue.elems {
            my $current = @queue[$head];
            @queue[$head] = Nil;
            $head++;
            # Periodically trim processed entries to reclaim memory.
            # Mirrors the DirScanner sequential-path fix for the same pattern.
            if $head > 1024 {
                @queue = @queue[$head..*];
                $head = 0;
            }
            next unless $current.defined;
            my $current-file = $current<file>;
            my $depth = $current<depth>;
            next unless $current-file.defined && $depth.defined;

            my $path-str = $current-file.Str;
            next if %visited{$path-str};
            %visited{$path-str} = True;

            my $doc = try self!load-xml-file($current-file);
            if !$doc {
                # Surface the real diagnostic instead of a lossy generic message
                # (parse-xml-files and parse-xml-url-recursive already do): a parse
                # failure raises an exception (recover it from $!), while a
                # decode failure returns Nil silently, so the two cases need
                # different recovery. LibXML-structural errors keep their
                # detail (e.g. "Start tag expected"), matching parse-xml-files.
                my $err = $!;
                my $msg = $err && $err.message.defined
                    ?? $err.message
                    !! "Failed to decode $path-str as XML";
                @errors.push: { file => $path-str, error => $msg };
                next;
            }

            my $root = $doc.documentElement;
            my $root-name = $root.nodeName;

            if $root-name eq 'sitemapindex' {
                @all-sitemaps.push: $path-str;
                $parsed-count++;

                my $child-sitemaps = self!parse-index-document($doc);
                my $next-depth = $depth + 1;

                if $max-depth == 0 || $next-depth <= $max-depth {
                    my @child-urls = $child-sitemaps.map(-> $s { $s<loc> }).grep(*.defined).grep(*.chars > 0);
                    my @child-files;
                    for @child-urls -> $url {
                        my $f = self!url-to-local-file($url, $current-file.IO.dirname.Str);
                        # A child that resolves locally but is missing on disk is a
                        # broken index, not something to drop silently: record it so
                        # the failure is visible. Remote (http/file) children resolve
                        # to Nil and are skipped as before.
                        if $f.defined {
                            if $f.IO.f {
                                @child-files.push: $f;
                            } else {
                                @errors.push: { file => $path-str, error => "Child sitemap not found: $url" };
                            }
                        }
                    }

                    for @child-files -> $child-file {
                        my $entry = { file => $child-file, depth => $next-depth };
                        @queue.push($entry);
                    }
                }
            }
            elsif $root-name eq 'urlset' {
                my $parsed-items = self!parse-document($doc);
                @items.push: |$parsed-items;
                $parsed-count++;
            }
        }

        return ParseResult.new(
            :@items,
            :@errors,
            :sitemaps(@all-sitemaps),
            :files-parsed($parsed-count)
        );
    }

    method !load-xml-file(IO::Path $file) {
        my $blob = $file.slurp(:bin);
        my $content = try decompress-content($file.Str, $blob);
        return Nil unless $content.defined;
        self!parse-xml-content($content, :huge);
    }

    method !parse-xml-content(Str $content, Bool :$huge = False --> LibXML::Document) {
        self!parse-doc(string => $content, :$huge);
    }

    method !url-to-local-file(Str $url, Str $base-dir --> IO::Path) {
        return Nil unless $url.defined && $url.chars > 0;

        if $url ~~ /^ :i https? \: \/\// || $url ~~ /^ :i file \: \/\// {
            return Nil;
        }

        # A query string or fragment (child.xml?v=2, child.xml#x) is part of
        # the URL reference, not the file name: strip it so the local file
        # resolves (mirrors !resolve-url's fragment/query cleanup in the
        # Crawler). Without this a real child file is silently missed.
        my $path = $url.subst(/^ \/ +/, '').subst(/ [ '?' | '#' ] \N* $/, '');
        my $base = $base-dir.IO.resolve;
        my $candidate = $base-dir.IO.add($path);
        my $resolved = try $candidate.resolve;
        return Nil unless $resolved.defined;

        # Reject anything that resolves outside the sitemap's directory tree
        my $rel = $resolved.relative($base);
        return Nil if $rel ~~ /^ '..' [ '/' | $ ]/;

        $resolved;
    }

    method !parse-document($doc --> List) {
        my @items;
        my $root = $doc.documentElement;

        for $root.getChildrenByLocalName('url') -> $url-el {
            my $loc = self!get-text($url-el, <loc>);
            next unless $loc;

            my %params = :url($loc);

            if my $lastmod = self!get-text($url-el, <lastmod>) {
                if my $pair = coerce-lastmod-value($lastmod) {
                    %params<lastmod> = $pair.key;
                    %params<lastmod-precision> = $pair.value;
                }
            }

            if my $changefreq = self!get-text($url-el, <changefreq>) {
                if my $cf = self!parse-changefreq($changefreq) {
                    %params<changefreq> = $cf;
                }
            }

            if my $priority = self!get-text($url-el, <priority>) {
                my $parsed = self!to-num($priority);
                if $parsed.defined && 0 <= $parsed <= 1 {
                    %params<priority> = $parsed;
                } elsif $parsed.defined {
                    note "Warning: ignoring out-of-range priority '$priority' for '$loc'";
                }
            }

            if my $expires = self!get-text($url-el, <expires>) {
                %params<expires> = $expires;
            }

            if my $title = self!get-text($url-el, <title>) {
                %params<title> = $title;
            }

            my $item = Sitemap::Item.new(|%params);

            for $url-el.getChildrenByLocalName('image') -> $img-el {
                my $img-url = self!get-text($img-el, <image:loc>);
                if $img-url {
                    $item.add-image(
                        $img-url,
                        caption => self!get-text($img-el, <image:caption>),
                        title => self!get-text($img-el, <image:title>),
                        geo-location => self!get-text($img-el, <image:geo_location>),
                        license => self!get-text($img-el, <image:license>)
                    );
                }
            }

            for $url-el.getChildrenByLocalName('video') -> $vid-el {
                my $thumb = self!get-text($vid-el, <video:thumbnail_loc>);
                if $thumb {
                    my @tags = self!get-all-text($vid-el, <video:tag>).grep(*.chars);
                    my $dur = self!to-int(self!get-text($vid-el, <video:duration>));
                    my $vc = self!to-int(self!get-text($vid-el, <video:view_count>));
                    my $rat = self!to-num(self!get-text($vid-el, <video:rating>));
                    $item.add-video(
                        (self!get-text($vid-el, <video:content_loc>) // ''),
                        title => self!get-text($vid-el, <video:title>),
                        description => self!get-text($vid-el, <video:description>),
                        thumbnail-loc => $thumb,
                        player-loc => self!get-text($vid-el, <video:player_loc>),
                        |($dur.defined ?? (duration => $dur) !! ()),
                        expiration-date => self!get-text($vid-el, <video:expiration_date>),
                        |($vc.defined ?? (view-count => $vc) !! ()),
                        publication-date => self!get-text($vid-el, <video:publication_date>),
                        category => self!get-text($vid-el, <video:category>),
                        restriction => self!get-text($vid-el, <video:restriction>),
                        gallery-loc => self!get-text($vid-el, <video:gallery_loc>),
                        uploader => self!get-text($vid-el, <video:uploader>),
                        |($rat.defined ?? (rating => $rat) !! ()),
                        family-friendly => self!get-bool($vid-el, <video:family_friendly>),
                        requires-subscription => self!get-bool($vid-el, <video:requires_subscription>),
                        live => self!get-bool($vid-el, <video:live>),
                        tags => @tags,
                    );
                }
            }

            for $url-el.getChildrenByLocalName('link') -> $link-el {
                my $href = $link-el.getAttribute('href');
                my $hreflang = $link-el.getAttribute('hreflang');
                my $rel = $link-el.getAttribute('rel');
                # rel may carry multiple tokens ("alternate x-default"); match
                # the token set case-insensitively.
                my $is-alternate = so $rel.split(/\s+/).grep(*.chars).grep(*.lc eq 'alternate');
                if $href && $is-alternate {
                    $item.add-link($href, lang => ($hreflang // ''));
                }
            }

            @items.push: $item;
        }

        @items;
    }

    method !parse-index-document($doc --> List) {
        my @sitemaps;
        my $root = $doc.documentElement;

        for $root.getChildrenByLocalName('sitemap') -> $sm-el {
            my $loc = self!get-text($sm-el, <loc>);
            next unless $loc;

            my %sitemap = :$loc;

            if my $lastmod = self!get-text($sm-el, <lastmod>) {
                # Only record a parseable date: an unparseable one must not
                # store Nil (which would leak an empty <lastmod> into rendered
                # indexes); mirror the urlset handling in !parse-document.
                # Partial W3CDTF dates ("2024", "2024-01") are accepted too.
                if my $pair = coerce-lastmod-value($lastmod) {
                    %sitemap<lastmod> = $pair.key;
                }
            }

            @sitemaps.push: %sitemap;
        }

        @sitemaps;
    }

    method !get-text($el, Str $tag) {
        self!get-all-text($el, $tag).head // '';
    }

    #| Return every child text matching a local tag in the SAME namespace as
    #| the parent element. The single-value !get-text delegates here so both
    #| share the namespace filter: getChildrenByLocalName matches across every
    #| namespace, which would otherwise let a foreign-namespaced child (e.g. a
    #| bare <tag> inside <video:video>) be misread as a sitemap field.
    method !get-all-text($el, Str $tag) {
        my $local = $tag.split(':')[*-1];
        my $parent-ns = $el.namespaceURI;
        $el.getChildrenByLocalName($local)
            .grep({ $parent-ns.defined ?? (($_.namespaceURI // '') eq $parent-ns) !! True })
            .map({ .textContent // '' })
            .List;
    }

    method !get-bool($el, Str $tag) {
        with self!get-text($el, $tag) {
            return Nil unless .chars;
            # Accept yes/true/1 (and their mixed-case variants) as True so
            # common generator spellings like "true" aren't misread.
            so .lc ~~ /^ ( 'yes' | 'true' | '1' ) $/
        }
    }

    method !parse-changefreq(Str $freq) {
        try { coerce-changefreq($freq) }
    }

    method !to-num(Str $text) {
        my $num = try { $text.Num };
        $! = Nil;
        $num;
    }

    method !to-int(Str $text) {
        my $int = try { $text.Int };
        $! = Nil;
        $int;
    }
}

=begin pod

=head1 NAME

Sitemap::Parser - Parse existing XML sitemaps

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Parser;

# Parse from file
my @items = Sitemap::Parser.parse-xml-file('sitemap.xml');
for @items -> $item {
    say $item.url, ' ', $item.lastmod // 'no date';
}

# Parse from string
my $xml = q:to/XML/;
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/page</loc>
    <lastmod>2024-01-01</lastmod>
  </url>
</urlset>
XML

my @items2 = Sitemap::Parser.parse-xml-string($xml);

# Parse sitemap index
my @sitemaps = Sitemap::Parser.parse-xml-index-file('sitemap_index.xml');

=end code

This module parses raw XML sitemaps only. For automatic format detection and
loose formats (RSS, Atom, HTML, TXT) use the C<Sitemap::InputParser> module.

=head1 METHODS

=head2 parse-xml-file(IO::Path $file --> List)

Parse an XML sitemap file and return a list of SitemapItem objects.

=head2 parse-xml-string(Str $xml --> List)

Parse an XML sitemap string and return a list of SitemapItem objects.

=head2 parse-xml-index-file(IO::Path $file --> List)

Parse a sitemap index file and return a list of sitemap URLs.

=head2 parse-xml-index-string(Str $xml --> List)

Parse a sitemap index XML string and return a list of sitemap URLs.

=head2 parse-xml-files(*@files, :$parallel = True)

Parse multiple sitemap files in parallel (or sequentially if C<$parallel> is False).
Returns a C<ParseResult> with C<.items> (list of Sitemap::Item objects) and C<.errors> (list of failures).
Also supports hash-style access: C<$result<items>>, C<$result<errors>>.

=head2 parse-xml-url-recursive(Str $url, :$max-depth, :$verify-ssl)

Recursively parse a sitemap URL. If the URL is a sitemap index, all child sitemaps are fetched
and parsed. Returns a C<ParseResult> with:
C<.items> (all parsed items), C<.errors>, C<.sitemaps> (all sitemap URLs found),
C<.urls-parsed> (count of URLs processed).
Also supports hash-style access: C<$result<items>>, C<$result<errors>>, etc.

=head2 parse-xml-file-recursive(IO::Path $file, :$max-depth)

Recursively parse a local sitemap index file and all referenced child sitemaps.
Returns a C<ParseResult> with:
C<.items>, C<.errors>, C<.sitemaps>, C<.files-parsed> (count of files processed).
Also supports hash-style access: C<$result<items>>, C<$result<errors>>, etc.

=end pod
