use v6.d;

unit module Sitemap::Config;

use Compress::Zlib;
use URI;
use Cro::HTTP::Client;
use Sitemap::Grammar::RobotsTxt;

#| Single source of truth for the package version. Sitemap::$VERSION mirrors
#| this and the CLI/crawler user-agent strings interpolate it, so bumping the
#| version here cannot drift from the module/UA. Not exported so Sitemap's
#| own `our $VERSION` (the public API) does not redeclare an imported symbol.
our $VERSION = '0.0.1';

#| Maximum size (in bytes) of a single fetched document body. Anything larger
#| is treated as an error rather than buffered into memory. The cap applies to
#| the transfer size (see read-bounded-body, which rejects a too-large
#| Content-Length up front and aborts the stream if it grows past the cap) and
#| to the decompressed content size (see decompress-content, which defends
#| against decompression bombs).
#| Lexical: the value is module-private so external code cannot touch it
#| directly. Consumers read it via the exported max-body-size; the
#| set-max-body-size setter is deliberately NOT exported so a loaded module
#| cannot silently raise the decompression-bomb guard. It is an intentional
#| test seam, reachable only by full qualification (Sitemap::Config::
#| set-max-body-size), used by the test suite to lower the cap; production
#| consumers have no public way to alter it.
my $MAX-BODY-SIZE = 50 * 1024 * 1024;

our sub max-body-size(--> Int) is export { $MAX-BODY-SIZE }
our sub set-max-body-size(Int $size) { $MAX-BODY-SIZE = $size }

#| Bounded-map eviction shared by every module that pairs a hash with an
#| insertion-order Array. Raku hashes iterate in insertion order, so the head
#| of @order is the oldest keys: splice them off in bulk (the caller's policy)
#| and delete them from %map. Callers hold their own lock before calling.
#| Strategies: 'batch' (default) drops the overshoot plus cap div 16 in one go
#| so the Array head is shifted only every ~cap/16 pushes; 'half' drops half
#| the table; 'one' drops a single oldest key.
our sub fifo-evict(%map, @order, Int :$cap!, Str :$strategy = 'batch') is export {
    return if @order.elems <= $cap;
    my $drop = do given $strategy {
        when 'half' { @order.elems div 2 }
        when 'one'  { 1 }
        default     { max(@order.elems - $cap, $cap div 16) }
    }
    $drop = @order.elems if $drop > @order.elems;
    my @dropped = @order.splice(0, $drop);
    %map{$_}:delete for @dropped;
}

my $client-lock = Lock.new;
my %clients;
my @client-order;

# Upper bound on cached clients. The cache key includes the user-agent, so an
# unbounded table would grow forever under varying UA strings; FIFO eviction
# caps it while keeping the common fixed-UA cases pooled. A callers still holds
# its own reference to an evicted client, so in-flight requests stay alive.
my constant $MAX-CLIENTS = 32;

#| Shared Cro::HTTP::Client cache. One client per (ssl-verify, timeout, UA,
#| follow) tuple, created lazily under a lock. Every module that fetches over
#| HTTP used to keep its own copy of this lock+state idiom; this is the single
#| one.
#|
#| :$follow controls redirect following, matching Cro's semantics: leave it
#| undefined for Cro's default (auto-follow up to its redirect limit) or pass
#| False / an Int hop count. The Crawler passes False so every 3xx surfaces
#| as a response and redirect targets can be routed through the same robots,
#| crawl-delay and same-origin gates as ordinary URLs.
our sub cached-client(Bool :$ssl-verify = True, :$timeout = { connection => 30, body => 60 }, Str :$user-agent = '', :$follow --> Cro::HTTP::Client) is export {
    # Stable key: all callers pass only 'connection' and 'body' timeout
    # keys, so a fixed-order concatenation avoids the sort+map overhead.
    # The user-agent is part of the identity too: callers that send different
    # UA strings must not share a pooled client, or a server that
    # distinguishes clients by UA would see the wrong one.
    my $key = ($ssl-verify ?? 's' !! 'i') ~ '|'
        ~ ($timeout<connection> // '') ~ ','
        ~ ($timeout<body> // '')
        ~ '|ua=' ~ $user-agent
        ~ '|f=' ~ ($follow.defined ?? ($follow ?? $follow.Str !! 'no') !! 'auto');
    $client-lock.protect: {
        unless %clients{$key}:exists {
            %clients{$key} = Cro::HTTP::Client.new(
                timeout => $timeout,
                tls => $ssl-verify ?? {} !! { :insecure },
                |($user-agent ?? (user-agent => $user-agent) !! Empty),
                |($follow.defined ?? (follow => $follow) !! Empty),
            );
            @client-order.push($key);
            fifo-evict(%clients, @client-order, :cap($MAX-CLIENTS), :strategy<one>);
        }
        %clients{$key};
    }
}

#| Read a full HTTP response body into a Buf, enforcing $MAX-BODY-SIZE both
#| before transfer (via the Content-Length header, when present and numeric)
#| and during transfer (by capping the accumulated byte stream, so an absent
#| or lying Content-Length cannot force an unbounded buffer). Dies on either
#| violation instead of buffering the excess. Only the body is read; callers
#| remain responsible for checking the status code.
our sub read-bounded-body(Str $url, $response --> Buf) is export {
    my $declared = $response.header('Content-Length');
    # Parse the declared length once (it is used by both the too-large check
    # and the truncation check below); Nil when absent or non-numeric.
    my $declared-length = $declared.defined ?? try { $declared.Int } !! Nil;
    if $declared-length.defined && $declared-length > $MAX-BODY-SIZE {
        die "Refusing to process $url: declared body length of $declared-length bytes exceeds the $MAX-BODY-SIZE byte limit";
    }

    my $out = Buf.new;
    my $limit-exceeded;
    react {
        whenever $response.body-byte-stream -> $blob {
            $out.append($blob);
            if $out.elems > $MAX-BODY-SIZE {
                # Abort the download so the connection is freed instead of
                # being drained into the void after we stop listening.
                try $response.cancel;
                $limit-exceeded = "Refusing to process $url: body exceeds the $MAX-BODY-SIZE byte limit";
                done;
            }
        }
    }
    die $limit-exceeded if $limit-exceeded;

    # Reject truncated responses: if the server declared a Content-Length and
    # the connection was closed early, the body is incomplete and downstream
    # parsing would produce confusing errors.
    if $declared-length.defined && $out.elems < $declared-length {
        die "Refusing to process $url: received only {$out.elems} bytes but Content-Length declared $declared-length bytes (truncated response)";
    }

    $out;
}

#| Canonical origin of a parsed URI: "scheme://host", or "scheme://host:port"
#| when the port is non-default, lowercasing scheme and host so that two URLs
#| naming the same origin compare equal. Default ports (80 for http, 443 for
#| https) are dropped, so "http://EXAMPLE.com/" and "http://example.com:80/"
#| are the same origin while "http://example.com:8080/" is not. Unlike
#| origin-with-userinfo (used by URL resolution, which must preserve userinfo
#| and casing), this is the comparison/identity form: robots-tracking keys,
#| crawl-delay locks, same-origin checks and canonical URL building all go
#| through it. Returns Nil for URIs without a usable host (scheme-only, stray
#| "mailto://", a bare path), which never match anything, instead of emitting
#| a meaningless origin like "http://". Callers that hold an unparsed string
#| use normalize-origin, which parses first and returns Nil for non-URLs.
our sub canonical-origin(URI $uri --> Str) is export {
    # URI.host returns "" (not Nil) for hostless input, so guard on .chars:
    # a hostless/corrupt URI must yield Nil (never matchable) rather than a
    # garbage origin string like "http://" or "mailto://".
    my $host = $uri.host;
    return Nil unless $host.defined && $host.chars;
    my $scheme = $uri.scheme.lc;
    my $origin = "$scheme://{$host.lc}";
    my $port = $uri.port;
    if $scheme eq 'http' || $scheme eq 'https' {
        my $default-port = $scheme eq 'https' ?? 443 !! 80;
        $origin ~= ":$port" if $port.defined && $port != $default-port;
    }
    # Non-http(s) schemes have no known default port here, so any explicit
    # port is part of the origin: without this, ftp://host:2121 and
    # ftp://host:22 collapsed to the same origin string.
    elsif $port.defined {
        $origin ~= ":$port";
    }
    $origin;
}

#| Reduce a URL to its origin via canonical-origin, returning Nil for strings
#| that do not resolve to a scheme plus host (e.g. a bare hostname or a
#| malformed URL), which never matches anything.
our sub normalize-origin(Str $url --> Str) is export {
    my $uri = try { URI.new($url) };
    return Nil unless $uri.defined && $uri.scheme.defined && $uri.scheme.chars
                        && $uri.host.defined && $uri.host.chars;
    canonical-origin($uri);
}

#| Whether two URLs share the same origin (scheme, host and effective port).
#| Strings without a resolvable origin are never same-origin.
our sub same-origin(Str $a, Str $b --> Bool) is export {
    my $na = normalize-origin($a);
    my $nb = normalize-origin($b);
    so $na.defined && $nb.defined && $na eq $nb;
}

#| Normalize a user-supplied start URL so it always has a usable scheme:
#| http/https URLs pass through untouched, scheme-relative "//host/..." inputs
#| become https, and a bare domain ("example.com") gets https:// prepended. The
#| raw strings must not be handed to URI.new directly, because a schemeless
#| string produces an empty scheme and a bogus host, which silently mangles the
#| discovery URL into "://.../robots.txt".
our sub normalize-start-url(Str $url --> Str) is export {
    return $url if $url ~~ /^ <[a..zA..Z]>+ '://' /;
    return 'https:' ~ $url if $url.starts-with('//');
    "https://$url";
}

#| Normalize an http(s) URL string: scheme and host are lowercased, an explicit
#| default port (":80" on http, ":443" on https) is dropped, and userinfo,
#| path, query and fragment are preserved verbatim, as is any other scheme.
#| Non-http(s) strings are returned unchanged, so callers such as Item's TWEAK
#| can apply this unconditionally. This is the single normalization home;
#| Item's URL-handling used to keep a private copy of this regex.
our sub normalize-http-url(Str $url --> Str) is export {
    return $url unless $url ~~ /^ (:i https?) '://' (.*?) ( [ '/' | '?' | '#' ] (.*) )? $/;
    # Read every regex capture into lexicals up front: the port check below
    # runs its own (capture-less) match, which would otherwise clobber $0.
    my $scheme = $0.Str.lc;
    my $authority = $1.Str;
    my $rest = ($2 // '').Str;
    my $userinfo = '';
    my $host = $authority;
    my $at = $authority.index('@');
    if $at.defined {
        $userinfo = $authority.substr(0, $at + 1);
        $host = $authority.substr($at + 1);
    }
    # Drop an explicit default port so the two spellings normalize to one URL.
    # IPv6 hosts keep their brackets, so a port colon only counts when
    # it sits after the closing ']'.
    my $port-start = $host.rindex(':');
    if $port-start.defined && $port-start > ($host.rindex(']') // -1) {
        my $port = $host.substr($port-start + 1);
        my $default-port = $scheme eq 'https' ?? 443 !! 80;
        # Compare numerically so zero-padded spellings ("http://h:0080/") also
        # normalize to the portless form; guard on all-digits first, since
        # numeric coercion would happily mangle garbage like "80x" into 80.
        $host = $host.substr(0, $port-start)
            if $port ~~ /^ <[0..9]>+ $/ && $port.Int == $default-port;
    }
    "$scheme://$userinfo" ~ $host.lc ~ $rest;
}

#| Fetch and parse a robots.txt document. Unlike raw $response.body-text, this
#| goes through read-bounded-body and decompress-content like every other body
#| read in the codebase, so a gzip-encoded robots.txt is decompressed instead
#| of being parsed as binary garbage and an oversized body is rejected. Returns
#| a two-element list: (Actions, fetch-error). On success the first element is
#| the parsed Actions (sitemap entries + per-UA rules) and the second is the
#| empty Str; on failure the first is Nil and the second is a human-readable
#| message for the network-level failure (other failures — non-200 status, body
#| read error, parse failure — are reported only through :&debug). An optional
#| :&debug callback receives per-stage diagnostics for callers that trace
#| robots fetching (Crawler's --debug output).
our sub fetch-robots(Str $robots-url, $client, Bool :$verbose = False, :&debug = -> Str $m { note $m if $verbose } --> List) is export {
    my $response = try await $client.get($robots-url);
    my $fetch-err = $!;
    if !$response {
        return (Nil, "robots.txt: {$fetch-err ?? $fetch-err.message !! 'no response'} (ignored)");
    }
    if $response.status != 200 {
        &debug("robots.txt: {$response.status} {$response.status-text // ''} (ignored)");
        return (Nil, '');
    }

    my $blob = try read-bounded-body($robots-url, $response);
    if !$blob.defined {
        &debug("robots.txt body read failed: {$! ?? $!.message !! 'unknown error'}");
        return (Nil, '');
    }

    my $content = try decompress-content($robots-url, $blob);
    if !$content.defined {
        &debug("robots.txt decompress failed: {$! ?? $!.message !! 'unknown error'}");
        return (Nil, '');
    }

    my $actions = Sitemap::Grammar::RobotsTxt::Actions.new;
    my $parsed = Sitemap::Grammar::RobotsTxt.parse($content, :$actions);
    if !$parsed {
        &debug("robots.txt parse failed (ignored)");
        return (Nil, '');
    }
    ($actions, '');
}

#| Discover sitemap URLs from a domain's robots.txt, falling back to
#| /sitemap.xml. Returns a List of absolute sitemap URLs (may be empty).
our sub discover-sitemaps(Str $base-url, Bool :$ssl-verify = True --> List) is export {
    my $url = normalize-start-url($base-url);
    my $uri = URI.new($url);
    my $default-port = $uri.scheme.lc eq 'https' ?? 443 !! 80;
    my $robots-host = $uri.host;
    my $port = $uri.port // $default-port;
    $robots-host ~= ":$port" if $port != $default-port;
    my $robots-url = $uri.scheme ~ '://' ~ $robots-host ~ '/robots.txt';

    my $http = cached-client(:$ssl-verify, timeout => { connection => 30, body => 30 });

    my ($actions, $fetch-error) = fetch-robots($robots-url, $http);
    return () unless $actions;

    # SSRF guard: a robots.txt must not be allowed to point the crawl at a
    # foreign host. Only sitemaps on the same origin (scheme, host, port) as
    # the robots.txt are returned; this mirrors the same-origin guards in
    # Parser::parse-xml-url-recursive and Fetcher::fetch-recursive. Without it, a
    # rogue robots.txt declaring "Sitemap: https://attacker.example/sitemap.xml"
    # would make discover-sitemaps hand back the attacker's URL.
    $actions.get-sitemaps
        .map({ resolve-relative-url($_, $robots-url) })
        .grep({ same-origin($robots-url, $_) })
        .List;
}

#| Origin of a base URI preserving userinfo and casing:
#| "scheme://userinfo@host" or "scheme://userinfo@host:port" when the port is
#| non-default. This is the resolution form (RFC 3986 calls the origin-ish
#| prefix of a resolved target) — unlike canonical-origin it must keep
#| userinfo, because a userinfo-bearing base URL's resolved children inherit
#| the credentials. Host casing is likewise untouched, matching the input URI.
my sub origin-with-userinfo(URI $uri --> Str) {
    my $scheme = $uri.scheme // '';
    my $host   = $uri.host   // '';
    my $userinfo = $uri.userinfo ?? ($uri.userinfo ~ '@') !! '';
    my $port   = $uri.port;
    my $default-port = ($scheme eq 'https') ?? 443 !! (($scheme eq 'http') ?? 80 !! 0);
    my $port-part = ($port && $port != $default-port) ?? ":$port" !! '';
    $scheme ~ '://' ~ $userinfo ~ $host ~ $port-part;
}

#| Collapse "." and ".." path segments (RFC 3986 §5.2.4): ".." pops the previous
#| segment, a leading ".." above the root is dropped, and a trailing slash is
#| kept only when the collapsed path is non-empty.
my sub collapse-path(Str $path --> Str) {
    my $is-root = $path.starts-with('/');
    my $has-trailing-slash = $path.ends-with('/');
    my @parts = $path.split('/', :skip-empty);
    # RFC 3986 §5.2.4 remove_dot_segments: "/a/." normalizes to "/a/" — a
    # trailing "." segment behaves like a trailing slash, not like "/a".
    my $ends-dot = @parts.elems && (@parts[*-1] eq '.' || @parts[*-1] eq '..');
    my @out;
    for @parts -> $part {
        if $part eq '.' { next; }
        elsif $part eq '..' { @out.pop if @out; }
        else { @out.push: $part; }
    }
    my $result = @out.join('/');
    $result = ($is-root ?? '/' !! '') ~ $result;
    $result ~= '/' if ($has-trailing-slash || $ends-dot) && @out;
    $result;
}

#| Decomposed base URI for resolving many references against the same base.
#| Building a context reads each URI accessor exactly once, so a hot loop of
#| resolve-reference calls (every link, image and video on a page) does pure
#| string work instead of ~10 URI accessor reads per call (~1.7ms → ~µs per
#| URL on a page with thousands of links).
class UriContext is export {
    has Str $.scheme;
    has Str $.origin;
    has Str $.path;
    has Str $.query;
    has Str $.dir;
    has Bool $.has-host;
}

#| Build a UriContext from a base URI. The origin matches
#| origin-with-userinfo's output exactly (scheme://userinfo@host[:port],
#| non-default port only), so resolved URLs are byte-identical to what the
#| uncached path produces.
our sub uri-context(URI $base --> UriContext) is export {
    my $scheme   = $base.scheme // '';
    my $host     = $base.host   // '';
    my $has-host = $host.chars > 0;
    my $userinfo = $base.userinfo ?? ($base.userinfo ~ '@') !! '';
    my $port     = $base.port;
    my $default-port = ($scheme eq 'https') ?? 443 !! (($scheme eq 'http') ?? 80 !! 0);
    my $port-part = ($port && $port != $default-port) ?? ":$port" !! '';
    my $path     = ~$base.path;
    my $dir      = ($path eq '/' || $path eq '') ?? '/' !! $path.subst(rx/ \/ <-[\/]>* $ /, '');
    UriContext.new(:$scheme, origin => "$scheme://$userinfo$host$port-part", :$path, query => ~$base.query, :$dir, :$has-host);
}

#| Resolve a possibly-relative reference against a base URI per RFC 3986 §5.2.2.
#| Handles absolute (scheme:...), scheme-relative (//host/...), root-relative
#| (/path), query-only (?q), fragment-only (#f) and dot-segment-relative (./x,
#| ../x) references; a bare reference resolves against the base directory.
#| Query-only refs keep the base path and replace the query; fragment-only refs
#| keep the base path and query and swap the fragment. References that already
#| carry a scheme are returned unchanged. Returns Nil for an empty reference or
#| a base URI without a usable host. This is the single RFC 3986 merge shared by
#| the Parser (Config::resolve-relative-url), the HTML extractors (LinkExtract)
#| and the Crawler. Callers resolving many references against one base (Crawler
#| per page, LinkExtract per page) build a UriContext once via uri-context and
#| pass it as :$ctx to skip all per-call URI accessor reads.
our sub resolve-reference(Str $ref, URI $base, UriContext :$ctx --> Str) is export {
    return Nil unless $ref.defined && $ref.chars;

    my ($scheme, $origin, $path, $query, $dir);
    if $ctx.defined {
        return Nil unless $ctx.has-host;
        $scheme = $ctx.scheme;
        $origin = $ctx.origin;
        $path   = $ctx.path;
        $query  = $ctx.query;
        $dir    = $ctx.dir;
    } else {
        return Nil unless $base.defined && $base.host.defined && $base.host.chars;
        $scheme = $base.scheme // '';
        $origin = origin-with-userinfo($base);
        $path   = ~$base.path;
        $query  = ~$base.query;
        $dir    = ($path eq '/' || $path eq '') ?? '/' !! $path.subst(rx/ \/ <-[\/]>* $ /, '');
    }

    return $ref if $ref ~~ /^ <[a..zA..Z]>+ ':' /;

    return "$scheme:$ref" if $ref.starts-with('//') && $scheme && $scheme.chars;
    return Nil if $ref.starts-with('//');
    if $ref.starts-with('/') {
        # Root-relative refs keep their own path, but dot segments still
        # collapse: "/../img/x.jpg" must not leak a literal ".." above the
        # root (RFC 3986 §5.2.4). Peel the query/fragment at WHICHEVER of
        # '?' or '#' comes first: splitting on '?' unconditionally would cut
        # inside a fragment that itself contains a question mark
        # ("/a/../..#f?q" leaked a literal ".." into the result).
        my $split = min($ref.index('?') // $ref.chars,
                        $ref.index('#') // $ref.chars,
                        $ref.chars);
        my $new-path = collapse-path($ref.substr(0, $split));
        my $suffix = $ref.substr($split);
        return $origin ~ $new-path ~ $suffix;
    }

    if $ref.starts-with('?') {
        return $origin ~ $path ~ $ref;
    }
    if $ref.starts-with('#') {
        my $base-query = $query;
        $base-query = '?' ~ $base-query if $base-query.chars > 0;
        return $origin ~ $path ~ $base-query ~ $ref;
    }

    my $target = $dir ~ '/' ~ $ref;

    # Peel the query/fragment at whichever of '?' or '#' comes FIRST, exactly
    # like the root-relative branch above: a reference such as "z#a/../b?q"
    # splits at the fragment, or the ".." would collapse inside the fragment
    # and relocate the resulting file (/x/y/b?q) instead of keeping it at
    # /x/y/z#a/../b?q.
    my $split = min($target.index('?') // $target.chars,
                    $target.index('#') // $target.chars,
                    $target.chars);
    my $new-path = collapse-path($target.substr(0, $split));
    my $suffix = $target.substr($split);
    $origin ~ $new-path ~ $suffix;
}

#| Resolve a possibly-relative URL reference against a base URL, returning an
#| absolute URL. Handles scheme-relative (//host/path), root-relative (/path),
#| query-only (?q), fragment-only (#f) and directory-relative (./x, ../x)
#| references; a bare reference is resolved against the base URL's directory.
#| References that already carry a scheme are returned unchanged. Falls back to
#| returning the reference as-is when the base cannot be parsed into a URL with
#| a host, so callers can rely on a Str result either way. Delegates the actual
#| merge to resolve-reference, the single RFC 3986 resolver shared with
#| LinkExtract and the Crawler. An optional :$ctx (a UriContext built once per
#| page) skips the per-call URI accessor reads, which is what the hot link/image
#| extraction loops use; LinkExtract used to carry a private adapter for this,
#| now folded into this single signature.
our sub resolve-relative-url(Str $ref, Str() $base, Sitemap::Config::UriContext :$ctx --> Str) is export {
    # A base that cannot be parsed as a URI at all (e.g. "not a url") is not a
    # meaningful resolution target: return Nil so callers treat the loc as
    # unresolvable rather than silently passing the raw reference through,
    # which A2/A3 showed produced garbage like "://missing-scheme".
    my $b = try { URI.new($base) };
    return Nil unless $b.defined;
    # An http(s) base with no host is malformed (scheme-only or scheme-relative
    # "://" input); resolving against it yields nothing usable, so Nil. A
    # hostless NON-http base (e.g. the DirScanner's "file:///dir/" scans) is a
    # legitimate resolution target: preserve the earlier fallback so local
    # file-path references resolve instead of being dropped.
    if !$b.host.defined || !$b.host.chars {
        my $scheme = try { $b.scheme.lc } // '';
        # An http(s) base with no host is malformed (scheme-only or
        # scheme-relative "://" input) and a scheme-less string (bare path) was
        # never a URL: both yield Nil. Only a hostless base with a concrete
        # non-http scheme (e.g. the DirScanner's "file:///dir/" scans) is a
        # legitimate resolution target, and there the earlier fallback is
        # preserved so local file-path references resolve instead of being
        # silently dropped.
        return Nil if $scheme eq '' || $scheme eq 'http' || $scheme eq 'https';
        return $ref;
    }
    resolve-reference($ref, $b, :$ctx) // $ref;
}

#| Decode a fetched/local blob transparently, gunzipping gzip magic bytes or
#| .gz URLs. Defends against decompression bombs with a bounded, incremental
#| inflation: the compressed blob is fed to zlib in small chunks and the
#| accumulated output is checked against $MAX-BODY-SIZE after every chunk, so
#| even a stream whose trailer lies (or that has no trailer at all — note that
#| Compress::Zlib::Stream.deflate never emits a gzip trailer, so an ISIZE-based
#| pre-check would reject perfectly valid data) can only ever allocate on the
#| order of one chunk's expansion past the cap. Set :lenient to decode via the
#| lossless utf8-c8 encoding (never throws; maps invalid UTF-8 to private-use
#| code points) instead of strict UTF-8, for local possibly-non-UTF-8 files.
our sub decompress-content(Str $url, Blob $blob, Bool :$lenient = False --> Str) is export {
    my $magic-gzip = $blob.elems >= 2 && $blob[0] == 0x1f && $blob[1] == 0x8b;
    # A query string (sitemap.xml.gz?v=2) must not hide the .gz suffix; the
    # magic-byte check above still catches real gzip regardless, so this only
    # matters for the branch selecting the gzip decode path.
    my $suffix-gzip = $url ~~ /\.gz [ \? .* ]? $/;

    my $decode = -> Blob $b { $lenient ?? $b.decode('utf8-c8') !! decode-text-body($b) };

    if $magic-gzip || $suffix-gzip {
        my $inflator = Compress::Zlib::Stream.new(:gzip);
        my $out = Buf.new;
        my $ok = True;
        my $step = 16 * 1024;
        my $i = 0;
        while $i < $blob.elems {
            my $res = try $inflator.inflate($blob.subbuf($i, min($step, $blob.elems - $i)));
            if $res.defined {
                $out.append($res);
                if $out.elems > $MAX-BODY-SIZE {
                    die "Refusing to process $url: decompressed body exceeds the $MAX-BODY-SIZE byte limit";
                }
            } else {
                $ok = False;
                last;
            }
            if $inflator.finished {
                # A gzip file may be a concatenation of several members. When a
                # member's trailer is reached, bytes-left is the exact count of
                # input bytes still un-consumed (i.e. the next member), so we
                # continue with a fresh stream at that offset instead of
                # dropping every member after the first.
                my $consumed = $blob.elems - $inflator.bytes-left;
                last if $consumed >= $blob.elems;
                $inflator = Compress::Zlib::Stream.new(:gzip);
                $i = $consumed;
            } else {
                $i += $step;
            }
        }

        # zlib never reported the end-of-stream marker, so the input was cut
        # short (e.g. a truncated download or a missing gzip trailer). Returning
        # the partial prefix would publish half a sitemap, so reject it.
        if $ok && $magic-gzip && !$inflator.finished {
            die "Refusing to process $url: gzip stream is truncated (unexpected end of stream)";
        }

        if $ok {
            return $decode($out);
        }

        # Magic bytes present but the data is not valid gzip: decoding the
        # raw blob would produce mojibake, so treat it as an error. A
        # bare .gz suffix with no magic can still be a plain file named .gz.
        if $magic-gzip {
            die "Refusing to process $url: data starts with gzip magic but is not valid gzip";
        }
    }

    $decode($blob);
}

#| Decode a text body that is expected to be UTF-8 but may be legacy 8-bit
#| (e.g. a Latin-1 HTML page or robots.txt). Strict UTF-8 first so mojibake is
#| not silently produced from valid multi-byte input; on invalid bytes fall
#| back to Latin-1 (every byte maps to a code point), matching the Crawler's
#| page-body handling so all non-UTF-8 decoding is consistent.
our sub decode-text-body(Blob $blob --> Str) is export {
    my $utf8 = try $blob.decode('utf-8');
    $utf8.defined ?? $utf8 !! $blob.decode('latin-1');
}

#| Compute the default priority from crawl depth: 1.0 at depth 0, decreasing
#| by 0.2 per level, clamped to a minimum of 0.1.  Extracted from Crawler and
#| DirScanner which contained identical copies.
our sub calculate-priority(Int $depth --> Real) is export {
    max(0.1, 1.0 - ($depth * 0.2));
}

#| Return the lowercase file extension of $url's PATH, or '' when the URL has
#| no path extension.  Only the portion after scheme://host is considered, so
#| a host that merely looks like a dotted filename (e.g. https://foo.zip)
#| never yields an extension; query strings and fragments are stripped.
#| Extracted from Crawler's inline logic so it can be unit-tested directly.
our sub url-path-extension(Str $url --> Str) is export {
    my $path = $url ~~ / '://' <-[\/?#]>+ ( <-[?#]>+ ) / ?? ~$0 !! '';
    return '' unless $path ~~ / '.' (\w+) $ /;
    return ~$0.lc;
}

#| File extensions that must NOT be treated as bare-domain URLs.  A path like
#| robots.txt or sitemap.xml has a dot but is clearly a local file, not a URL.
#| The denylist covers common document, media, archive, font, source-code and
#| config extensions; it is intentionally conservative so real URLs are not
#| misclassified.  Two-letter ccTLDs that look like extensions (ai, io, tv)
#| are deliberately absent: bare hosts like changelog.io are far more common
#| than files with those extensions.
my constant %NON-URL-EXTENSIONS = (
    'txt' => 1, 'md' => 1, 'html' => 1, 'htm' => 1, 'json' => 1,
    'yaml' => 1, 'yml' => 1, 'xml' => 1, 'csv' => 1, 'pdf' => 1,
    'png' => 1, 'jpg' => 1, 'jpeg' => 1, 'gif' => 1, 'svg' => 1,
    'webp' => 1, 'mp4' => 1, 'mp3' => 1, 'gz' => 1, 'tar' => 1,
    'zip' => 1, 'log' => 1, 'ini' => 1, 'conf' => 1,
    'ico' => 1, 'css' => 1, 'js' => 1,
    'woff' => 1, 'woff2' => 1, 'ttf' => 1, 'eot' => 1,
    'doc' => 1, 'docx' => 1, 'xls' => 1, 'xlsx' => 1,
    'ppt' => 1, 'pptx' => 1,
);

#| Distinguish a local file path from a URL or an unrecognised input.
#| A scheme-qualified URL is always 'url'; an existing path is always 'file'
#| (checked first, so a real file named like a domain wins); otherwise a
#| value that looks like a bare domain with a dot/port is 'url' unless its
#| extension is denylisted; everything else is 'neither'.  Extracted from the
#| duplicated detection blocks in the build and parse subcommands.
our sub detect-input-type(Str $file --> Str) is export {
    return 'url' if $file ~~ /^ <[a..zA..Z]>+ '://' /;
    return 'url' if $file ~~ /^ '//' /;
    # An existing local path is a file regardless of what its "extension"
    # looks like — this check must precede the dot/port heuristic below,
    # or a relative path containing a dot ('t/data/x.txt') would be
    # classified by its suffix instead of by its existence.
    return 'file' if $file && $file.IO.f;
    # Bare-domain URLs with a trailing file extension in the denylist are
    # local-file-looking names, not URLs (e.g. robots.txt, sitemap.xml).
    my $ext = $file ~~ / '.' (<[a..zA..Z]> ** 1..10) $/;
    my $denylisted = $ext && (%NON-URL-EXTENSIONS{$ext[0].lc}:exists);
    my $is-url = $file ~~ /^ <[\w.\-]>+ ( ':' \d+ )? [ '/' | '?' | $ ]/
        && ($file ~~ / \. | ':' \d+ /)
        && !$denylisted;
    $is-url ?? 'url' !! 'neither';
}
