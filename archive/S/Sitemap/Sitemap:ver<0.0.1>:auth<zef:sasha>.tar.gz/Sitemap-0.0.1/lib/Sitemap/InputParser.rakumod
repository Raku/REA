use v6.d;

unit module Sitemap::InputParser;

use LibXML;
use Syndicate::Utils;
use Sitemap::Item;
use Sitemap::Parser;
use Sitemap::Config;
use Sitemap::Grammar::SitemapSniff;
use Sitemap::Grammar::LinkExtract;
use Cro::HTTP::Client;
use Sitemap::Fetcher;

enum InputFormat <XML-Sitemap RSS Atom MRSS HTML TXT Unknown>;

#| Decode a raw file blob, transparently gunzipping gzip magic bytes (with the
#| shared decompression-bomb guard from Sitemap::Config)
sub decode-input-blob(Blob $blob --> Str) {
    decompress-content('', $blob, :lenient);
}

#| Detect input format from file extension and content
sub detect-format(IO::Path $file, Str :$content --> InputFormat) is export {
    my $ext = $file.extension.lc;

    # Without an explicit :$content the raw bytes must be decoded like every
    # other body: gunzip gzip magic (a .gz XML sitemap slurped as text would
    # sniff as TXT, R4) with the shared decompression-bomb guard. '' on a
    # decode failure so detection degrades to the TXT/Unknown fallbacks.
    # Note for direct callers: that decode reads and decompresses the whole
    # file purely for sniffing — pass :$content if you already hold the text,
    # or better call parse-file, which reads and decodes exactly once.
    my sub decode-for-detection(--> Str) {
        my $decoded = try decode-input-blob($file.slurp(:bin));
        $decoded // '';
    }

    given $ext {
        when 'txt'                          { return TXT }
        when 'html' | 'htm'                 { return HTML }
        when 'atom'                         { return Atom }
        when 'rss' | 'mrss'                {
            if $ext eq 'mrss' { return MRSS }
            # The extension says RSS, but the content may be mRSS (a root
            # <rss> declaring xmlns:media). Sniff before committing: otherwise
            # an mRSS feed named foo.rss is parsed as plain RSS and its
            # <media:content> URLs are silently lost to the <link> fallback.
            return detect-format-from-string($content // decode-for-detection()) == MRSS
                ?? MRSS !! RSS;
        }
        when 'xml' | 'gz' | ''              {
            return detect-format-from-string($content // decode-for-detection()) if $file.e && $file.s;
            # Missing/unreadable content: report Unknown consistently with
            # the default branch instead of optimistically claiming XML.
            return Unknown;
        }
        default                             {
            return detect-format-from-string($content // decode-for-detection()) if $file.e && $file.s;
            return Unknown;
        }
    }
}

#| Detect format from string content
sub detect-format-from-string(Str $content --> InputFormat) is export {
    my $trimmed = $content.trim;
    return TXT unless $trimmed;

    my $actions = Sitemap::Grammar::SitemapSniff::Actions.new;
    my $match = Sitemap::Grammar::SitemapSniff.subparse($trimmed, :$actions);
    my $fmt = $match ?? $match.made !! 'txt';

    # Well-formed XML whose root we do not recognise (RSS 1.0 <rdf:RDF>,
    # namespace-prefixed <sm:urlset>, arbitrary XML) must not degrade to TXT:
    # line-splitting an XML document would turn every source line into a
    # bogus "URL".  Report Unknown so callers get an empty result instead of
    # silently corrupted output.
    if !$match && ($trimmed.starts-with('<?xml') || $trimmed.starts-with('<')) {
        return Unknown;
    }

    # MRSS is signalled by the xmlns:media namespace *declared on the <rss>
    # root element* (e.g. <rss xmlns:media="...">). Scanning the whole
    # document for the literal 'xmlns:media =' misclassified a plain RSS 2.0
    # feed whose <description> merely happened to mention it as MRSS (CQ).
    # A well-formed XML document's first <rss ...> tag is the root, so
    # inspect only that open tag.
    if $fmt eq 'rss' {
        my $root-open = $trimmed ~~ m/ '<rss' (<-[>]>*) '>' /;
        if $root-open && ~$root-open[0] ~~ /:i 'xmlns:media' \s* '=' / {
            return MRSS;
        }
    }

    return do given $fmt {
        when 'xml-sitemap' { XML-Sitemap }
        when 'atom'        { Atom }
        when 'rss'         { RSS }
        when 'html'        { HTML }
        default            { TXT }
    }
}

#| Parse a local file and return List of Sitemap::Item
sub parse-file(Str $file, Bool :$verbose = False, Str :$base-url = '' --> List) is export {
    my $path = $file.IO;
    unless $path.e {
        note "Error: File not found: $file" if $verbose;
        return ();
    }

    my $content = try decode-input-blob($path.slurp(:bin));
    unless $content.defined {
        my $why = $! ?? $!.message !! 'unknown decode error';
        note "Error: Cannot decode $file: $why" if $verbose;
        return ();
    }
    my $format = detect-format($path, :$content);
    say "Detected format: $format" if $verbose;

    dispatch-format($content, $format, :$base-url, :$verbose, :context("file $file"));
}

#| Parse a string and return List of Sitemap::Item
sub parse-string(Str $content, Str $format-name = '', Str :$base-url = '' --> List) is export {
    my $format;

    if $format-name {
        $format = do given $format-name.lc {
            when 'xml' | 'sitemap'  { XML-Sitemap }
            when 'rss'               { RSS }
            when 'atom'              { Atom }
            when 'mrss'              { MRSS }
            when 'html' | 'htm'      { HTML }
            when 'txt'               { TXT }
            default                  { detect-format-from-string($content) }
        }
    } else {
        $format = detect-format-from-string($content);
    }

    dispatch-format($content, $format, :$base-url);
}

#| Dispatch parsing to the appropriate format handler.
my sub dispatch-format(Str $content, InputFormat $format, Str :$base-url, Bool :$verbose = False, Str :$context = '' --> List) {
    my $label = $context.chars ?? $context !! 'input';

    if $format ~~ XML-Sitemap {
        my @results = try Sitemap::Parser.parse-xml-string($content);
        unless @results.defined {
            note "Error: XML parse failed: " ~ ($! ?? $!.message !! 'unknown parse error') if $verbose;
            return ();
        }
        return @results;
    }
    elsif $format ~~ RSS {
        my @results = try parse-rss($content, :$base-url);
        unless @results.defined {
            note "Error: RSS parse failed: " ~ ($! ?? $!.message !! 'unknown parse error') if $verbose;
            return ();
        }
        return @results;
    }
    elsif $format ~~ Atom {
        my @results = try parse-atom($content, :$base-url);
        unless @results.defined {
            note "Error: Atom parse failed: " ~ ($! ?? $!.message !! 'unknown parse error') if $verbose;
            return ();
        }
        return @results;
    }
    elsif $format ~~ MRSS {
        my @results = try parse-mrss($content, :$base-url);
        unless @results.defined {
            note "Error: MRSS parse failed: " ~ ($! ?? $!.message !! 'unknown parse error') if $verbose;
            return ();
        }
        return @results;
    }
    elsif $format ~~ HTML { return parse-html-from-string($content, :$base-url) }
    elsif $format ~~ TXT  { return parse-txt-from-string($content, :$base-url) }
    else {
        note "Error: Unknown format for $label" if $verbose;
        return ();
    }
}

#| Fetch and parse a URL
sub parse-url(Str $url, Bool :$ssl-verify = True, Bool :$verbose = False, Str :$base-url = '' --> List) is export {
    my $client = cached-client(:$ssl-verify);
    my $response = try await $client.get($url);
    my $fetch-err = $!;
    unless $response && $response.status == 200 {
        note "Error: Failed to fetch $url" ~ ($fetch-err ?? ": {$fetch-err.message}" !! '') if $verbose;
        return ();
    }

    my $content = try get-decompressed-content($url, $response, :$verbose);
    my $body-err = $!;
    unless $content.defined {
        note "Error: Failed to read body for $url" ~ ($body-err ?? ": {$body-err.message}" !! '') if $verbose;
        return ();
    }

    my $items = try parse-string($content, '', :$base-url);
    my $parse-err = $!;
    unless $items.defined {
        note "Error: Failed to parse $url" ~ ($parse-err ?? ": {$parse-err.message}" !! '') if $verbose;
        return ();
    }
    return $items.List;
}

#| Parse XML with hardened LibXML settings; Nil on malformed input
sub parse-xml-safe(Str $xml) {
    my $doc = try LibXML.parse(string => $xml,
        :no-network, :!expand-entities, :!dtd, :!load-ext-dtd, :!huge, :!xinclude);
    $doc;
}

#| Parse RSS 2.0 content. Relative <link> values are resolved against $base-url
sub parse-rss(Str $xml, Str :$base-url = '' --> List) is export {
    my @items;
    my $doc = parse-xml-safe($xml);
    return @items unless $doc;

    for $doc.documentElement.getChildrenByLocalName('channel') -> $channel {
        for $channel.getChildrenByLocalName('item') -> $item-el {
            my $link = '';
            for $item-el.getChildrenByLocalName('link') -> $candidate {
                # getChildrenByLocalName also matches namespaced <atom:link>
                # (empty text), so prefer the first <link> with real text.
                my $text = ($candidate.textContent // '').trim;
                if $text {
                    $link = $text;
                    last;
                }
            }
            next unless $link;

            my %params = url => $base-url && ($link !~~ /^ :i 'http' /)
                ?? resolve-relative-url($link, $base-url)
                !! $link;

            my $title-el = $item-el.getChildrenByLocalName('title').first;
            if $title-el {
                %params<title> = $title-el.textContent // '';
            }

            my $pub-el = $item-el.getChildrenByLocalName('pubDate').first;
            if $pub-el {
                my $dt = parse-date(:optional, $pub-el.textContent // '');
                %params<lastmod> = $dt if $dt ~~ DateTime;
            }

            @items.push: Sitemap::Item.new(|%params);
        }
    }
    return @items;
}

#| Parse Atom 1.0 content. Relative <link href> values are resolved against $base-url
sub parse-atom(Str $xml, Str :$base-url = '' --> List) is export {
    my @items;
    my $doc = parse-xml-safe($xml);
    return @items unless $doc;

    for $doc.documentElement.getChildrenByLocalName('entry') -> $entry {
        # An entry may carry several <link> elements (self/edit/alternate);
        # getChildrenByLocalName matches namespaced ones too, so prefer the
        # rel="alternate" link and fall back to the first link with an href.
        my $link-el;
        my @link-candidates = $entry.getChildrenByLocalName('link').list;
        for @link-candidates -> $candidate {
            # Compare whole rel tokens, not substrings: rel="alternate-link"
            # must not match while hunting for rel="alternate".
            if $candidate.getAttribute('rel')
                    && so ($candidate.getAttribute('rel') // '')
                            .split(/\s+/).grep(*.lc eq 'alternate') {
                $link-el = $candidate;
                last;
            }
        }
        unless $link-el {
            for @link-candidates -> $candidate {
                if so ($candidate.getAttribute('href') // '') {
                    $link-el = $candidate;
                    last;
                }
            }
        }
        next unless $link-el;

        my $href = $link-el.getAttribute('href');
        next unless $href;

        my %params = url => $base-url && ($href !~~ /^ :i 'http' /)
            ?? resolve-relative-url($href, $base-url)
            !! $href;

        if my $title-el = $entry.getChildrenByLocalName('title').first {
            %params<title> = $title-el.textContent // '';
        }
        if my $updated-el = $entry.getChildrenByLocalName('updated').first {
            my $text = $updated-el.textContent // '';
            if $text {
                my $dt = parse-date(:optional, $text);
                %params<lastmod> = $dt if $dt ~~ DateTime;
            }
        }

        @items.push: Sitemap::Item.new(|%params);
    }
    return @items;
}

#| Parse MRSS content. Relative item URLs are resolved against $base-url
sub parse-mrss(Str $xml, Str :$base-url = '' --> List) is export {
    my @items;
    my $doc = parse-xml-safe($xml);
    return @items unless $doc;

    for $doc.documentElement.getChildrenByLocalName('channel') -> $channel {
        for $channel.getChildrenByLocalName('item') -> $item-el {
            my $url;

            my $media-content = ns-children($item-el, 'http://search.yahoo.com/mrss/', 'content').first;
            if $media-content && $media-content.getAttribute('url') {
                $url = $media-content.getAttribute('url');
            }

            unless $url {
                $url = get-element-text($item-el, 'link');
            }
            next unless $url;

            $url = $base-url && ($url !~~ /^ :i 'http' /)
                ?? resolve-relative-url($url, $base-url)
                !! $url;

            my %params = url => $url;

            if my $title = get-element-text($item-el, 'title') {
                %params<title> = $title;
            }
            if my $pub-date = get-element-text($item-el, 'pubDate') {
                my $dt = parse-date(:optional, $pub-date);
                %params<lastmod> = $dt if $dt ~~ DateTime;
            }

            @items.push: Sitemap::Item.new(|%params);
        }
    }
    return @items;
}

#| Parse HTML content string
sub parse-html-from-string(Str $content, Str :$base-url = '' --> List) is export {
    my %seen;
    my @items;
    for extract-href-only($content) -> $url {
        my $resolved = $base-url ?? resolve-relative-url($url, $base-url) !! $url;
        next unless $resolved ~~ /^ :i 'http' /;
        next if %seen{$resolved}++;
        @items.push: Sitemap::Item.new(url => $resolved);
    }
    @items;
}

#| Parse TXT file (one URL per line). Like every other file input it
#| transparently gunzips gzip magic bytes and guards a missing file, so a
#| gzip'd .txt yields real URLs instead of decoded-binary garbage.
sub parse-txt-file(Str $file, Str :$base-url = '' --> List) is export {
    my $path = $file.IO;
    return () unless $path.e && $path.s;
    my $content = try decode-input-blob($path.slurp(:bin));
    return () unless $content.defined;
    return parse-txt-from-string($content, :$base-url);
}

#| Parse TXT content string. One URL per line per the sitemap TXT profile.
#| Lines that cannot be a URL under any reading — whitespace-containing prose,
#| or tokens with neither scheme, dot, slash nor port ("not a url at all",
#| "@#$%") — are dropped instead of becoming bogus items: this parser also
#| serves as the fallback for sniffed-as-TXT content, and garbage lines used
#| to surface as entries. Schemeless but host-shaped lines ('example.com',
#| 'example.com/blog') are preserved verbatim, because plain URL lists are a
#| first-class input format for `sitemap build`.
sub parse-txt-from-string(Str $content, Str :$base-url = '' --> List) is export {
    my @items;
    for $content.lines -> $line {
        my $url = $line.trim;
        next unless $url && !$url.starts-with('#');
        if $url ~~ /^ :i 'http' s? '://' \S+ $/ {
            # Absolute http(s) URL: the only form the sitemap TXT spec allows.
        }
        # A base URL resolves genuinely-relative refs (a leading path/query/
        # fragment marker) to absolute URLs.
        elsif $base-url && $url !~~ /^ <[a..zA..Z]>+ ':' / && $url ~~ /^ [ '/' | '.' | '?' | '#' ] / {
            $url = resolve-relative-url($url, $base-url);
            next unless $url ~~ /^ :i 'http' s? '://' /;
        }
        else {
            # Schemeless: keep only host-or-path-shaped tokens (no internal
            # whitespace; must contain a dot or an explicit port) plus
            # bracketed IPv6 literals with a port ([::1]:8080/path).
            next if $url ~~ /\s/;
            next unless (
                $url ~~ /^ <[\w.\-~]>+ ( ':' \d+ )? [ '/' | '?' | $ ]/
                || $url ~~ /^ '[' <[0..9 a..f A..F \:]>+ ']' ':' \d+ [ '/' | '?' | $ ]/
            ) && ($url ~~ / '.' | ':' \d+ /);
        }
        @items.push: Sitemap::Item.new(url => $url);
    }
    return @items;
}

#| Helper: get text content of an XML element
#| Return direct children whose local name matches $tag and whose namespace
#| URI matches $ns (e.g. the media: namespace in MRSS).  This avoids
#| getChildrenByLocalName matching both <content> and <media:content>.
my sub ns-children($parent, Str $ns, Str $tag) {
    $parent.getChildrenByLocalName($tag).grep({
        .namespaceURI.defined && .namespaceURI eq $ns
    })
}

sub get-element-text($parent, Str $tag --> Str) {
    my $el = $parent.getChildrenByLocalName($tag).first;
    return '' unless $el;
    return $el.textContent // '';
}

=begin pod

=head1 NAME

Sitemap::InputParser - Detect and parse sitemap input files in various formats

=head1 DESCRIPTION

Automatically detects the format of sitemap input files (XML, RSS, Atom, MRSS, HTML, TXT)
and parses them into a list of C<Sitemap::Item> objects. Detection uses file extension
and content sniffing via C<Sitemap::Grammar::SitemapSniff>.

=head1 SUBS

=head2 detect-format(IO::Path $file, Str :$content --> InputFormat)

Detect the format of a file. Uses the extension first, then falls back to content sniffing
for XML/GZ files. Returns an C<InputFormat> enum value.

=head2 detect-format-from-string(Str $content --> InputFormat)

Detect format from a string using content sniffing.

=head2 parse-file(Str $file, Bool :$verbose, Str :$base-url --> List)

Parse a local file. Auto-detects format and returns a list of C<Sitemap::Item> objects.
C<:base-url> is prepended to relative URLs found in the file.

=head2 parse-string(Str $content, Str $format-name, Str :$base-url --> List)

Parse a string. If C<$format-name> is not provided, auto-detects from content.
C<:base-url> is prepended to relative URLs.

=head2 parse-url(Str $url, Bool :$ssl-verify, Bool :$verbose, Str :$base-url --> List)

Fetch and parse a URL. Uses C<Sitemap::Fetcher> for automatic gzip decompression.
C<:base-url> is prepended to relative URLs.

=head2 parse-rss(Str $xml, Str :$base-url --> List)

Parse RSS 2.0 content. Extracts C<item> entries with C<link>, C<title>, and C<pubDate>.
C<:base-url> is prepended to relative links.

=head2 parse-atom(Str $xml, Str :$base-url --> List)

Parse Atom 1.0 content. Extracts C<entry> elements with C<link href>, C<title>, and C<updated>.
C<:base-url> is prepended to relative links.

=head2 parse-mrss(Str $xml, Str :$base-url --> List)

Parse Media RSS content. Prefers C<media:content url> over C<link> element.
C<:base-url> is prepended to relative URLs.

=head2 parse-html-from-string(Str $content, Str :$base-url --> List)

Parse HTML content and extract C<< <a href> >> links. C<:base-url> is prepended
to relative links.

=head2 parse-txt-file(Str $file, Str :$base-url --> List)

Parse a TXT file (one URL per line). Skips lines starting with C<#>.
C<:base-url> is prepended to relative URLs.

=head2 parse-txt-from-string(Str $content, Str :$base-url --> List)

Parse TXT content string. C<:base-url> is prepended to relative URLs.

=head2 get-element-text($parent, Str $tag --> Str)

Internal helper to get the text content of an XML element. Not part of the
public API; exported parsers call it internally.

=head1 ENUMS

=head2 InputFormat

Enum values: C<XML-Sitemap>, C<RSS>, C<Atom>, C<MRSS>, C<HTML>, C<TXT>, C<Unknown>.

=end pod
