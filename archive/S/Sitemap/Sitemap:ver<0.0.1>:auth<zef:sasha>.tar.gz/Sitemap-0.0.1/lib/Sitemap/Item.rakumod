use v6.d;

use Sitemap::Config;

class Sitemap::Item::Image {
    has Str $.url is required;
    has Str $.caption = '';
    has Str $.title = '';
    has Str $.geo-location = '';
    has Str $.license = '';

    method write-xml($w) {
        $w.startElement('image:image');
        $w.writeElement('image:loc', $.url);
        $w.writeElement('image:caption', $.caption) if $.caption;
        $w.writeElement('image:title', $.title) if $.title;
        $w.writeElement('image:geo_location', $.geo-location) if $.geo-location;
        $w.writeElement('image:license', $.license) if $.license;
        $w.endElement;
    }

    method to-hash(--> Hash) {
        my %h = url => $.url;
        %h<caption> = $.caption if $.caption;
        %h<title> = $.title if $.title;
        %h<geo-location> = $.geo-location if $.geo-location;
        %h<license> = $.license if $.license;
        %h
    }

    method from-hash(Sitemap::Item::Image: Hash $h --> Sitemap::Item::Image) {
        self.new(
            # url is required by the schema; a missing key must not silently
            # build an empty-valued image.
            url => $h<url> // die('Missing url in image hash: cannot build Sitemap::Item::Image'),
            caption => $h<caption> // '',
            title => $h<title> // '',
            geo-location => $h<geo-location> // '',
            license => $h<license> // '',
        )
    }
}

#| Parse a W3CDTF date string, returning canonical form if valid and the
#| original string verbatim otherwise; legal ISO-8601 subsets that DateTime
#| rejects (e.g. month-only "2024-05") pass through as-is.
my sub canonical-date(Str $d --> Str) {
    # Date-only strings (no 'T' time component) must pass through verbatim:
    # DateTime.new("2024-01-15").Str injects timezone ("2024-01-15T00:00:00Z")
    # which would corrupt a date-only lastmod.
    return $d unless $d.contains('T');
    my $dt = try DateTime.new($d);
    # Whole seconds with the timezone offset: the video spec's examples are
    # YYYY-MM-DD or YYYY-MM-DDThh:mm:ss+00:00, so residual fractional seconds
    # ("2024-01-15T10:00:00.5" parsing to "10:00:00.500000Z") are invalid.
    $dt ?? $dt.truncated-to('second').Str !! $d;
}

#| How precisely a <lastmod>/lastmod was originally specified, so output can
#| round-trip a W3CDTF date without coercing "2024-01-15" to
#| "2024-01-15T00:00:00Z" (and without losing that "2024-01" / "2024" were ever
#| given). The sitemaps.org spec allows full datetimes, date-only, year-month
#| and year-only forms.
enum LastmodPrecision <Precise DateOnly YearMonth Year>;

#| Coerce a lastmod value (DateTime or Str) into a DateTime, accepting the
#| full sitemaps.org W3CDTF range: full datetimes, date-only, year-month and
#| year-only. Missing components default to their earliest value (a year-only
#| "2024" becomes 2024-01-01; a year-month "2024-01" becomes 2024-01-01), so
#| valid partial dates neither die (Builder) nor drop the field (Parser).
#| Returns a (DateTime, LastmodPrecision) Pair, or Nil for empty/unparseable
#| input (never throws).
our sub coerce-lastmod-value($value) is export {
    return Nil unless $value.defined;
    return $value => LastmodPrecision::Precise if $value ~~ DateTime;
    my $s = $value.Str.trim;
    return Nil unless $s.chars;
    if $s ~~ /^ (\d ** 4) $/ {
        return DateTime.new(:year(+$0), :month(1), :day(1)) => LastmodPrecision::Year;
    }
    if $s ~~ /^ (\d ** 4) '-' (\d ** 2) $/ {
        return DateTime.new(:year(+$0), :month(+$1), :day(1)) => LastmodPrecision::YearMonth;
    }
    # Date-only (no time component): keep as date precision.
    if $s ~~ /^ (\d ** 4) '-' (\d ** 2) '-' (\d ** 2) $/ {
        return DateTime.new(:year(+$0), :month(+$1), :day(+$2)) => LastmodPrecision::DateOnly;
    }
    my $dt = try { DateTime.new($s) };
    return Nil unless $dt.defined;
    $dt => LastmodPrecision::Precise;
}

class Sitemap::Item::Video {
    has Str $.thumbnail-loc = '';
    has Str $.title = '';
    has Str $.description = '';
    has Str $.content-loc = '';
    has Str $.player-loc = '';
    has Int $.duration;
    has Str $.expiration-date = '';
    has Int $.view-count;
    has Str $.publication-date = '';
    has Str $.category = '';
    has Str $.restriction = '';
    has Str $.gallery-loc = '';
    has Str $.uploader = '';
    has Real $.rating;
    has Bool $.family-friendly;
    has Bool $.requires-subscription;
    has Bool $.live;
    has @.tags;
    # The numeric/bool/date attrs above default to Undefined (Nil): they carry
    # an "absent" state distinct from a legitimate zero, so a missing field in
    # a feed stays absent instead of being coerced to a falsy value. Deferred
    # definitions must never stick a *type object* (e.g. !!Int) into these —
    # Raku's undefined Int/Real type objects are not Nil, so `.defined` checks
    # (and the write-xml range guards below) would silently miss an absent
    # field. Always bind Nil when the hash has no entry.

    method renderable(--> Bool) {
        # Google's video sitemap spec requires thumbnail_loc plus either
        # content_loc or player_loc; an extracted video with a player but no
        # thumbnail/poster is still valid and must not be dropped.
        so ($.thumbnail-loc && ($.content-loc || $.player-loc));
    }

    method write-xml($w --> Bool) {
        return False unless self.renderable;
        $w.startElement('video:video');
        $w.writeElement('video:thumbnail_loc', $.thumbnail-loc);
        $w.writeElement('video:title', $.title) if $.title;
        $w.writeElement('video:description', $.description) if $.description;
        $w.writeElement('video:content_loc', $.content-loc) if $.content-loc;
        $w.writeElement('video:player_loc', $.player-loc) if $.player-loc;
        # Google's spec constrains duration (positive seconds, max 8h),
        # view_count (non-negative) and rating (0.0–5.0); values outside the
        # valid ranges are omitted rather than emitted as invalid XML.
        $w.writeElement('video:duration', ~$.duration)
            if $.duration.defined && 0 < $.duration <= 28800;
        $w.writeElement('video:expiration_date', canonical-date($.expiration-date)) if $.expiration-date;
        $w.writeElement('video:view_count', ~$.view-count)
            if $.view-count.defined && $.view-count >= 0;
        $w.writeElement('video:publication_date', canonical-date($.publication-date)) if $.publication-date;
        $w.writeElement('video:category', $.category) if $.category;
        $w.writeElement('video:restriction', $.restriction) if $.restriction;
        $w.writeElement('video:gallery_loc', $.gallery-loc) if $.gallery-loc;
        $w.writeElement('video:uploader', $.uploader) if $.uploader;
        $w.writeElement('video:rating', ~$.rating)
            if $.rating.defined && 0 <= $.rating <= 5;
        $w.writeElement('video:family_friendly', $.family-friendly ?? 'yes' !! 'no') if defined $.family-friendly;
        $w.writeElement('video:requires_subscription', $.requires-subscription ?? 'yes' !! 'no') if defined $.requires-subscription;
        $w.writeElement('video:live', $.live ?? 'yes' !! 'no') if defined $.live;
        for @.tags -> $tag {
            $w.writeElement('video:tag', $tag);
        }
        $w.endElement;
        return True;
    }

    method to-hash(--> Hash) {
        my %h;
        %h<thumbnail-loc> = $.thumbnail-loc if $.thumbnail-loc;
        %h<title> = $.title if $.title;
        %h<description> = $.description if $.description;
        %h<content-loc> = $.content-loc if $.content-loc;
        %h<player-loc> = $.player-loc if $.player-loc;
        %h<duration> = $.duration if $.duration.defined;
        %h<expiration-date> = $.expiration-date if $.expiration-date;
        %h<view-count> = $.view-count if $.view-count.defined;
        %h<publication-date> = $.publication-date if $.publication-date;
        %h<category> = $.category if $.category;
        %h<restriction> = $.restriction if $.restriction;
        %h<gallery-loc> = $.gallery-loc if $.gallery-loc;
        %h<uploader> = $.uploader if $.uploader;
        %h<rating> = $.rating if $.rating.defined;
        %h<family-friendly> = $.family-friendly if $.family-friendly.defined;
        %h<requires-subscription> = $.requires-subscription if $.requires-subscription.defined;
        %h<live> = $.live if $.live.defined;
        %h<tags> = [@.tags] if @.tags;
        %h
    }

    method from-hash(Sitemap::Item::Video: Hash $h --> Sitemap::Item::Video) {
        self.new(
            thumbnail-loc => $h<thumbnail-loc> // '',
            title => $h<title> // '',
            description => $h<description> // '',
            content-loc => $h<content-loc> // '',
            player-loc => $h<player-loc> // '',
            duration => do { my $n = coerce-numeric($h<duration>); $n.defined && is-finite-numeric($n) ?? $n.floor.Int !! Nil },
            expiration-date => $h<expiration-date> // '',
            view-count => do { my $n = coerce-numeric($h<view-count>); $n.defined && is-finite-numeric($n) ?? $n.floor.Int !! Nil },
            publication-date => $h<publication-date> // '',
            category => $h<category> // '',
            restriction => $h<restriction> // '',
            gallery-loc => $h<gallery-loc> // '',
            uploader => $h<uploader> // '',
            rating => do { my $n = coerce-numeric($h<rating>); $n.defined && is-finite-numeric($n) ?? $n.Real !! Nil },
            family-friendly => $h<family-friendly>:exists ?? coerce-video-bool($h<family-friendly>) !! Nil,
            requires-subscription => $h<requires-subscription>:exists ?? coerce-video-bool($h<requires-subscription>) !! Nil,
            live => $h<live>:exists ?? coerce-video-bool($h<live>) !! Nil,
            tags => @($h<tags> // []),
        )
    }
}

class Sitemap::Item::Link {
    has Str $.lang is required;
    has Str $.url is required;

    method write-xml($w) {
        $w.startElement('xhtml:link');
        $w.writeAttribute('rel', 'alternate');
        $w.writeAttribute('hreflang', $.lang);
        $w.writeAttribute('href', $.url);
        $w.endElement;
    }

    method to-hash(--> Hash) {
        { lang => $.lang, url => $.url }
    }

    method from-hash(Sitemap::Item::Link: Hash $h --> Sitemap::Item::Link) {
        self.new(
            # lang is required; do not build a silently empty link.
            lang => $h<lang> // die('Missing lang in link hash: cannot build Sitemap::Item::Link'),
            url => $h<url> // die('Missing url in link hash: cannot build Sitemap::Item::Link'),
        )
    }
}

class Sitemap::Item::News {
    has Str $.publication is required;
    has Str $.publication-language is required;
    has Str $.title is required;
    has DateTime $.publication-date;
    has Str $.keywords = '';
    has Str $.stock-tickers = '';

    method write-xml($w) {
        $w.startElement('news:news');
        $w.startElement('news:publication');
        $w.writeElement('news:name', $.publication);
        $w.writeElement('news:language', $.publication-language);
        $w.endElement;
        $w.writeElement('news:publication_date', w3cdtf($.publication-date)) if $.publication-date.defined;
        $w.writeElement('news:title', $.title);
        $w.writeElement('news:keywords', $.keywords) if $.keywords;
        $w.writeElement('news:stock_tickers', $.stock-tickers) if $.stock-tickers;
        $w.endElement;
    }

    method to-hash(--> Hash) {
        my %h =
            publication => $.publication,
            publication-language => $.publication-language,
            title => $.title;
        %h<publication-date> = $.publication-date.Str if $.publication-date.defined;
        %h<keywords> = $.keywords if $.keywords;
        %h<stock-tickers> = $.stock-tickers if $.stock-tickers;
        %h
    }

    method from-hash(Sitemap::Item::News: Hash $h --> Sitemap::Item::News) {
        my $pub-date = $h<publication-date>;
        self.new(
            # publication/publication-language/title are required; a missing
            # key must not silently build an empty-valued news item, which
            # would bypass the `is required` declarations.
            publication => $h<publication>
                // die('Missing publication in news hash: cannot build Sitemap::Item::News'),
            publication-language => $h<publication-language>
                // die('Missing publication-language in news hash: cannot build Sitemap::Item::News'),
            title => $h<title>
                // die('Missing title in news hash: cannot build Sitemap::Item::News'),
            publication-date => do {
                if $pub-date ~~ DateTime { $pub-date }
                elsif $pub-date.defined && $pub-date.Str.trim {
                    my $parsed = try { DateTime.new($pub-date) };
                    $parsed // die("Invalid publication-date '$pub-date' in news hash for '$h<title>': cannot parse as DateTime");
                }
                else { Nil }
            },
            keywords => $h<keywords> // '',
            stock-tickers => $h<stock-tickers> // '',
        )
    }
}

enum Changefreq <Always Hourly Daily Weekly Monthly Yearly Never>;

my constant %CHANGEFREQ-MAP = {
    always => Changefreq::Always,
    hourly => Changefreq::Hourly,
    daily => Changefreq::Daily,
    weekly => Changefreq::Weekly,
    monthly => Changefreq::Monthly,
    yearly => Changefreq::Yearly,
    never => Changefreq::Never,
};

#| Coerce a changefreq value to the Changefreq enum, accepting Str, the enum
#| itself, or anything coercible to Str; a non-coercible value (e.g. Int) used
#| to die with a raw type-check error before any field name was mentioned.
sub coerce-changefreq($freq) is export {
    my $result = do given $freq {
        when Changefreq { $_ }
        when Str       { %CHANGEFREQ-MAP{$_.lc} // Nil }
        default {
            my $s = try $freq.Str;
            $s.defined ?? (%CHANGEFREQ-MAP{$s.lc} // Nil) !! Nil
        }
    };
    $result // die "Invalid changefreq '$freq' (expected one of: always, hourly, daily, weekly, monthly, yearly, never)";
}

sub coerce-video-bool($value --> Bool) {
    given $value {
        when Bool { $_ }
        when Str  { so $value ~~ / ^ :i [ 'true' | 'yes' | '1' ] $ / }
        default   { so $value }
    }
}

#| Coerce an arbitrary priority value to Numeric. Accepts numbers and numeric
#| strings; anything else yields Nil (unset), so a junk value cannot crash the
#| constructor with a type-check failure.
sub coerce-numeric($value --> Numeric) {
    return Nil unless $value.defined;
    my $n = try { $value.Numeric };
    $n.defined ?? $n !! Nil;
}

#| True when a coerced numeric is a real finite number. Int and Rat are always
#| finite; only a Num can be Inf/-Inf/NaN (e.g. "Inf", "-Inf", "NaN", "1e400"),
#| and conflating those with a usable duration/view-count/rating — or calling
#| .Int on them — used to blow up from-hash with "Cannot convert Inf to Int".
sub is-finite-numeric($n --> Bool) {
    return False unless $n.defined;
    return True unless $n ~~ Num;
    !$n.isNaN && $n != Inf && $n != -Inf;
}

#| Like coerce-numeric but also enforces the sitemap protocol's 0.0–1.0
#| priority range; out-of-range values yield Nil (unset) or die on junk.
#| Single shared home for priority normalization (Builder delegates here), so
#| range-check and negative-zero handling stay in one place.
sub coerce-priority($value --> Numeric) is export {
    my $n = coerce-numeric($value);
    return Nil unless $n.defined;
    # Normalize Num-level negative zero to positive zero; sitemap
    # validators reject "-0.0" in <priority>.
    $n = 0e0 if $n.isa(Num) && $n == 0;
    0 <= $n <= 1 ?? $n !! die "Invalid priority '$value' (expected a number between 0.0 and 1.0)";
}

#| Format a DateTime per the W3C Datetime profile the sitemap protocol
#| mandates (YYYY-MM-DDThh:mm:ssTZD): whole seconds, timezone offset kept.
#| Raku's DateTime.Str renders fractional seconds, which strict validators
#| reject in <lastmod>/<news:publication_date>.
sub w3cdtf(DateTime $dt --> Str) is export {
    $dt.truncated-to('second').Str
}

#| Coerce a single nested element to a Hash. Raku's hash/composer literals
#| flatten to a List of Pairs when written inline inside an array
#| (e.g. images => [ %(url => ...) ] or [ { url => ... } ]), which would make
#| the sub-item from-hash calls below fail their Hash type check. Accept any
#| of Hash, a single Pair, or a List of Pairs so hand-written nested data works.
sub coerce-element-hash($x --> Hash) {
    return $x if $x ~~ Hash;
    my @pairs = $x ~~ Pair ?? ($x,) !! @($x).list;
    Hash.new(|@pairs);
}

class Sitemap::Item {
    has Str $.url = '';
    has DateTime $.lastmod;
    #| Precision of the original lastmod, so write-xml/to-hash can round-trip a
    #| W3CDTF date-only/year-month/year-only "2024-01-15" without coercing it
    #| to "2024-01-15T00:00:00Z". Set automatically when a Str lastmod passes
    #| through coerce-lastmod-value (Builder/Parser/from-hash). When a
    #| DateTime is given directly it defaults to Precise, and existing
    #| date-only callers that pass a pre-built DateTime (e.g. DateTime.new('2024',
    #| 1, 15)) keep full-datetime output unless they set this explicitly.
    has LastmodPrecision $.lastmod-precision = LastmodPrecision::Precise;
    has Changefreq $.changefreq;
    has Numeric $.priority;
    has Str $.expires = '';
    has Str $.android-link = '';
    has Str $.amp-link = '';
    has Str $.title = '';
    has Bool $.verbose is rw = False;

    has Sitemap::Item::Image @.images;
    has Sitemap::Item::Video @.videos;
    has Sitemap::Item::Link @.links;
    has Sitemap::Item::News @.news;

    submethod TWEAK(Str :$url, |) {
        # Scheme/host case and default ports are normalized centrally; the
        # single home for this logic is Config::normalize-http-url.
        $!url = Sitemap::Config::normalize-http-url($url) if $url.defined;
    }

    method add-image(Str $url, Str :$caption = '', Str :$title = '', Str :$geo-location = '', Str :$license = '') {
        @.images.push: Sitemap::Item::Image.new(
            url => $url,
            caption => ($caption // ''),
            title => ($title // ''),
            geo-location => ($geo-location // ''),
            license => ($license // '')
        );
    }

    method add-video(
        Str $content-loc,
        Str :$title = '',
        Str :$description = '',
        Str :$thumbnail-loc = '',
        Str :$player-loc,
        Int :$duration,
        Str :$expiration-date,
        Int :$view-count,
        Str :$publication-date,
        Str :$category,
        Str :$restriction,
        Str :$gallery-loc,
        Str :$uploader,
        Real :$rating,
        :$family-friendly,
        :$requires-subscription,
        :$live,
        :@tags
    ) {
        @.videos.push: Sitemap::Item::Video.new(
            thumbnail-loc => ($thumbnail-loc // ''),
            title => ($title // ''),
            description => ($description // ''),
            content-loc => ($content-loc // ''),
            player-loc => ($player-loc // ''),
            duration => $duration,
            expiration-date => ($expiration-date // ''),
            view-count => $view-count,
            publication-date => ($publication-date // ''),
            category => ($category // ''),
            restriction => ($restriction // ''),
            gallery-loc => ($gallery-loc // ''),
            uploader => ($uploader // ''),
            rating => $rating,
            family-friendly => $family-friendly.defined ?? coerce-video-bool($family-friendly) !! Nil,
            requires-subscription => $requires-subscription.defined ?? coerce-video-bool($requires-subscription) !! Nil,
            live => $live.defined ?? coerce-video-bool($live) !! Nil,
            :@tags
        );
    }

    method add-link(Str $url, Str :$lang) {
        @.links.push: Sitemap::Item::Link.new(:$url, :$lang);
    }

    method add-news(
        Str :$publication!,
        Str :$publication-language!,
        Str :$title!,
        DateTime :$publication-date,
        Str :$keywords,
        Str :$stock-tickers
    ) {
        @.news.push: Sitemap::Item::News.new(
            :$publication,
            :$publication-language,
            :$title,
            :$publication-date,
            keywords => ($keywords // ''),
            stock-tickers => ($stock-tickers // '')
        );
    }

    #| Serialize the <url> element. :$verbose controls the "dropping video"
    #| warnings; the Builder threads its own verbosity through this instead of
    #| mutating $item.verbose, but the attribute is still honored for
    #| direct callers that set it on the item.
    #| Format $.lastmod per its recorded precision, so a date-only
    #| "2024-01-15" (or year-month "2024-01" / year "2024") lastmod is emitted
    #| in that original form rather than being widened to a full W3CDTF
    #| datetime, which validators accept but which corrupts the round-trip.
    method !format-lastmod(--> Str) {
        my DateTime $dt = $.lastmod;
        given $.lastmod-precision {
            when LastmodPrecision::DateOnly {
                $dt.Date.Str
            }
            when LastmodPrecision::YearMonth {
                sprintf '%04d-%02d', $dt.year, $dt.month
            }
            when LastmodPrecision::Year {
                sprintf '%04d', $dt.year
            }
            default {
                w3cdtf($dt)
            }
        }
    }

    method write-xml($w, Bool :$verbose = False) {
        $w.startElement('url');
        $w.writeElement('loc', $.url);

        $w.writeElement('lastmod', self!format-lastmod) if $.lastmod;
        $w.writeElement('changefreq', $.changefreq.Str.lc) if $.changefreq.defined;
        if $.priority.defined {
            # The sitemaps protocol expects priorities like "0.5"/"1.0"; Raku
            # stringifies a whole 1.0 as "1", so append the decimal when the
            # value has none (0.8 stays "0.8", 0.55 stays "0.55").
            my $priority = ~$.priority;
            if $priority ~~ /<[eE]>/ {
                # Rakudo renders magnitudes below ~1e-4 in scientific
                # notation ("1e-05"), which appending ".0" cannot repair.
                # Expand to a plain decimal instead. The 30-decimal width
                # keeps tiny-but-real priorities (e.g. 1e-11) intact: the
                # former %.10f truncated anything below 1e-10 to "0.0",
                # silently discarding it.
                $priority = $.priority.fmt('%.30f');
                $priority ~~ s/ 0+ $ // if $priority ~~ / '.' /;
                $priority ~= '0' if $priority.ends-with('.');
            }
            $priority ~= '.0' unless $priority ~~ / '.' /;
            $w.writeElement('priority', $priority);
        }
        $w.writeElement('expires', $.expires) if $.expires;
        $w.writeElement('android:link', $.android-link) if $.android-link;
        $w.writeElement('amp:link', $.amp-link) if $.amp-link;
        # Note: no url-level <title> here - it is not part of the sitemaps
        # protocol and validators reject it. Parser still accepts it on input.

        .write-xml($w) for @.images;
        for @.videos -> $v {
            unless $v.write-xml($w) {
                note "Warning: dropping video " ~ ($v.content-loc ?? $v.content-loc !! ($v.player-loc ?? $v.player-loc !! '(no content_loc/player_loc)'))
                    ~ " for item {$.url}: thumbnail_loc plus content_loc or player_loc are required" if $verbose || $.verbose;
            }
        }
        .write-xml($w) for @.links;
        .write-xml($w) for @.news;

        $w.endElement;
    }

    method to-hash(--> Hash) {
        my %h;
        %h<url> = $.url if $.url;
        %h<lastmod> = self!format-lastmod if $.lastmod;
        %h<lastmod-precision> = $.lastmod-precision.key if $.lastmod && $.lastmod-precision != LastmodPrecision::Precise;
        %h<changefreq> = $.changefreq.key if $.changefreq.defined;
        %h<priority> = $.priority if $.priority.defined;
        %h<expires> = $.expires if $.expires;
        %h<android-link> = $.android-link if $.android-link;
        %h<amp-link> = $.amp-link if $.amp-link;
        %h<title> = $.title if $.title;
        %h<images> = [@.images.map(*.to-hash)] if @.images;
        %h<videos> = [@.videos.map(*.to-hash)] if @.videos;
        %h<links> = [@.links.map(*.to-hash)] if @.links;
        %h<news> = [@.news.map(*.to-hash)] if @.news;
        %h
    }

    #| Coerce a date value from a hash into a (DateTime, LastmodPrecision) Pair,
    #| mirroring Builder's handling of add-item dates: a DateTime passes through
    #| with Precise precision, an empty value becomes Nil, and a present-but-
    #| unparseable value dies with a clear, contextual message instead of an
    #| opaque DateTime::... error. Like coerce-lastmod-value it accepts partial
    #| W3CDTF dates ("2024", "2024-01") so a hash round-trip never loses a valid
    #| date-only form.
    method !coerce-date-hash($value, Str $field, Str $context) {
        return Nil unless $value.defined;
        return $value => LastmodPrecision::Precise if $value ~~ DateTime;
        return Nil unless $value.chars;
        my $pair = coerce-lastmod-value($value);
        $pair // die "Invalid $field '$value' in item hash for '$context': cannot parse as DateTime";
        $pair
    }

    #| Resolve a hash-supplied lastmod-precision (string or enum) to the enum;
    #| unknown values fall back to the detected precision rather than dying, so
    #| a stale/typo'd key cannot break a round-trip.
    method !precision-from-hash($value, $detected --> LastmodPrecision) {
        return $detected // LastmodPrecision::Precise unless $value.defined;
        return $value if $value ~~ LastmodPrecision;
        given $value.Str.lc {
            when 'precise'  { LastmodPrecision::Precise }
            when 'dateonly' { LastmodPrecision::DateOnly }
            when 'yearmonth' { LastmodPrecision::YearMonth }
            when 'year'     { LastmodPrecision::Year }
            default         { $detected // LastmodPrecision::Precise }
        }
    }

    #| Build an item from a hash. url is required: a missing key dies
    #| instead of silently producing an empty-valued item. :allow-empty-url is
    #| for Sitemap::SiteTree round-trips, whose item urls are derived from the
    #| tree position (to-builder computes them) and are legitimately absent.
    method from-hash(Sitemap::Item: Hash $h, Bool :$allow-empty-url = False --> Sitemap::Item) {
        my Pair $date = self!coerce-date-hash($h<lastmod>, 'lastmod', $h<url> // '');
        my DateTime $lastmod;
        my LastmodPrecision $detected = LastmodPrecision::Precise;
        if $date.defined && $date ~~ Pair {
            $lastmod = $date.key;
            $detected = $date.value;
        }
        self.new(
            # url is required; a missing key must not silently build an
            # empty-valued item.
            url => $h<url>.defined && $h<url>.Str.trim
                ?? $h<url>
                !! ($allow-empty-url ?? '' !! die('Missing url in item hash: cannot build Sitemap::Item')),
            lastmod => $lastmod,
            lastmod-precision => $h<lastmod-precision>:exists
                ?? self!precision-from-hash($h<lastmod-precision>, $detected)
                !! $detected,
            changefreq => $h<changefreq>:exists ?? coerce-changefreq($h<changefreq>) !! Nil,
            priority => $h<priority>:exists ?? coerce-priority($h<priority>) !! Nil,
            expires => $h<expires> // '',
            android-link => $h<android-link> // '',
            amp-link => $h<amp-link> // '',
            title => $h<title> // '',
            images => @($h<images> // []).map({ Sitemap::Item::Image.from-hash(coerce-element-hash($_)) }),
            videos => @($h<videos> // []).map({ Sitemap::Item::Video.from-hash(coerce-element-hash($_)) }),
            links => @($h<links> // []).map({ Sitemap::Item::Link.from-hash(coerce-element-hash($_)) }),
            news => @($h<news> // []).map({ Sitemap::Item::News.from-hash(coerce-element-hash($_)) }),
        )
    }
}

=begin pod

=head1 NAME

Sitemap::Item - Data class for sitemap URL entries

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Item;

# changefreq takes the Changefreq enum (string coercion happens in
# Sitemap::Builder.add-item and Sitemap::Item.from-hash).
my $item = Sitemap::Item.new(
    url => 'https://example.com/page',
    lastmod => DateTime.now,
    changefreq => Changefreq::Daily,
    priority => 0.8
);

# With images
$item.add-image('https://example.com/image.jpg', :caption<My Image>);

# With videos
$item.add-video('https://example.com/video.mp4', :title<My Video>, :description<A video>);

=end code

=head1 METHODS

=head2 new(Str :$url, DateTime :$lastmod, Changefreq :$changefreq, Numeric :$priority, Str :$expires, Str :$android-link, Str :$amp-link, Str :$title)

Create a new Sitemap::Item. The URL will be automatically normalized.

=head2 add-image(Str $url, Str :$caption, Str :$title, Str :$geo-location, Str :$license)

Add an image to this sitemap item.

=head2 add-video(Str $content-loc, Str :$title, Str :$description, Str :$thumbnail-loc, Str :$player-loc, Int :$duration, Str :$expiration-date, Int :$view-count, Str :$publication-date, Str :$category, Str :$restriction, Str :$gallery-loc, Str :$uploader, Real :$rating, Bool :$family-friendly, Bool :$requires-subscription, Bool :$live, :@tags)

Add a video to this sitemap item. C<$content-loc> is the video file URL (required, positional).
For XML output C<$thumbnail-loc> plus either C<$content-loc> or C<$player-loc> are required;
if they are missing, C<write-xml> skips the video and emits a warning to STDERR (only when
verbose). The boolean flags C<$family-friendly>, C<$requires-subscription>, and C<$live> are
tri-state: an unspecified (C<Nil>) flag omits the corresponding XML element entirely, while
an explicit C<False> writes C<no>. Non-Bool values (C<'yes'>, C<'true'>, C<1>, ...)
are coerced to Bool rather than crashing the constructor.

=head2 add-link(Str $url, Str :$lang)

Add an alternate language link (hreflang).

=head2 add-news(Str :$publication!, Str :$publication-language!, Str :$title!, DateTime :$publication-date, Str :$keywords, Str :$stock-tickers)

Add a news item to this sitemap entry. Used for Google News sitemaps.
C<$publication-date> is optional; when omitted no C<news:publication_date>
element is emitted.

=head2 to-hash( --> Hash)

Serialize the item to a plain hash of native Raku types (strings, numbers, booleans,
arrays, hashes). Suitable for passing to C<save-yaml> or C<to-json>.

=begin code :lang<raku>
my %h = $item.to-hash;
say %h<url>;           # https://example.com/page
say %h<changefreq>;    # Daily
say %h<priority>;      # 0.8
=end code

=head2 from-hash(Hash $h --> Sitemap::Item)

Reconstruct a C<Sitemap::Item> (and any nested images, videos, links, news)
from a hash produced by C<to-hash>. Nested C<images>/C<videos>/C<links>/C<news>
values are arrays of hashes (as C<to-hash> and JSON/YAML round-trips produce),
and may also be a single Hash, a single Pair, or a List of Pairs.

Note: Raku flattens a hash into a list of pairs when it appears in list
context, so C<images => [ %(...) ]> splits each multi-field hash into separate
sub-items. Either write single-attribute elements inline, or itemize the hash
with C<$> to keep it as one element.

=begin code :lang<raku>
my $item = Sitemap::Item.from-hash(%h);

my %img = %( url => 'https://example.com/i.jpg', caption => 'cap' );
my $item2 = Sitemap::Item.from-hash(%( url => 'https://example.com/p', images => [ $%img ] ));
=end code

=head1 INNER CLASSES

=head2 Sitemap::Item::Image

Represents an image in a sitemap entry.

=head3 Attributes

C<$.url> (required) - Image URL.
C<$.caption> - Image caption.
C<$.title> - Image title.
C<$.geo-location> - Geographic location.
C<$.license> - Image license URL.

=head2 Sitemap::Item::Video

Represents a video in a sitemap entry. Follows Google Video Sitemap specification.

=head3 Attributes

C<$.thumbnail-loc> - Thumbnail image URL.
C<$.title> - Video title.
C<$.description> - Video description.
C<$.content-loc> - Video file URL.
C<$.player-loc> - Video player URL.
C<$.duration> - Duration in seconds.
C<$.expiration-date> - Expiration date string.
C<$.view-count> - Number of views.
C<$.publication-date> - Publication date string.
C<$.category> - Video category.
C<$.restriction> - Restriction information.
C<$.gallery-loc> - Gallery location.
C<$.uploader> - Uploader information.
C<$.rating> - Video rating.
C<$.family-friendly> - Whether the video is family-friendly.
C<$.requires-subscription> - Whether a subscription is required.
C<$.live> - Whether the video is live.
C<$.tags> - Array of tags.

=head2 Sitemap::Item::Link

Represents an alternate language link (hreflang).

=head3 Attributes

C<$.lang> (required) - Language code.
C<$.url> (required) - Alternate URL.

=head2 Sitemap::Item::News

Represents a news article in a Google News sitemap.

=head3 Attributes

C<$.publication> (required) - Publication name.
C<$.publication-language> (required) - Publication language code.
C<$.title> (required) - Article headline.
C<$.publication-date> - Publication date.
C<$.keywords> - Comma-separated keywords.
C<$.stock-tickers> - Stock tickers (e.g., "NASDAQ:GOOG").

=head1 ENUMS

=head2 Changefreq

Enum for sitemap change frequency: C<Always>, C<Hourly>, C<Daily>, C<Weekly>, C<Monthly>, C<Yearly>, C<Never>.

=end pod
