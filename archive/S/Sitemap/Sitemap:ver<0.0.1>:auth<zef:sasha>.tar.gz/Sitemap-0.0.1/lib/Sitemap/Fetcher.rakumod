use v6.d;

unit module Sitemap::Fetcher;

use URI;
use Cro::HTTP::Client;
use Sitemap::Parser;
use Sitemap::Builder;
use Sitemap::Config;
use Sitemap::Grammar::SitemapSniff;
use Sitemap::Format::TXT;
use Sitemap::Format::HTML;
use Sitemap::Format::RSS;
use Sitemap::Format::Atom;
use Sitemap::Format::MRSS;

#| Fetch a sitemap from a URL and return its content.
#| Redirects are followed manually and never allowed to leave the origin of
#| the request URL: an auto-following HTTP client would happily chase a 3xx
#| Location to an internal or metadata endpoint (e.g. http://169.254.169.254/)
#| -- a classic SSRF -- so any cross-origin redirect is refused instead. The
#| whole chain is constrained to the original URL's origin.
our sub fetch(Str $url, Bool :$ssl-verify = True, Bool :$verbose = False, Str :$user-agent = '' --> Str) is export {
    # :follow(False) surfaces every 3xx as a response so redirect handling is
    # under our control rather than the client's auto-follow.
    my $http = cached-client(:$ssl-verify, :$user-agent, :follow(False));
    my $redirects = 0;
    my $target = $url;
    loop {
        my $response = try await $http.get($target);

        if !$response || $response.status != 200 {
            # A 3xx (other than 304) with a Location: resolve it and gate it to
            # the original URL's origin before following, up to a hop cap.
            my $status = $response ?? $response.status !! 0;
            if $response && $status ~~ 300..399 && $status != 304 {
                my $loc = $response.header('Location') // Nil;
                unless $loc.defined && $loc.chars {
                    die "Failed to fetch $url (redirect $status without a Location header)";
                }
                my $resolved = Sitemap::Config::resolve-reference($loc, URI.new($target));
                unless $resolved.defined && Sitemap::Config::same-origin($resolved, $url) {
                    die "Failed to fetch $url (redirect $status to '$resolved' crossed the '$url' origin; refusing to follow for SSRF safety)";
                }
                $target = $resolved;
                $redirects++;
                die "Failed to fetch $url (too many redirects)" if $redirects > 5;
                next;
            }

            # Cro raises X::Cro::HTTP::Error on 4xx/5xx, so $response is Nil and
            # the reason lives in $! instead of a status code.
            my $detail = $response ?? "HTTP $status" !! ($! ?? $!.message !! 'no response');
            die "Failed to fetch $url ($detail)";
        }
        return get-decompressed-content($target, $response, :$verbose);
    }
}

#| Decompress content from an HTTP response, handling gzip encoding
our sub get-decompressed-content(Str $url, $response, Bool :$verbose = False --> Str) is export {
    # Cro::HTTP 0.8.x does not decompress Content-Encoding: gzip itself, so
    # reading body-text would return raw gzip bytes. Always read the raw body
    # and detect gzip via the magic number / .gz extension instead.
    my $blob = try read-bounded-body($url, $response);
    unless $blob.defined {
        die "Failed to read body for $url" ~ ($! ?? ': ' ~ $!.message !! '');
    }
    decompress-content($url, $blob);
}

#| Generate output filename from URL, adding path context
our sub output-filename(Str $input, Str :$format, Str :$output-override = '' --> Str) is export {
    return $output-override if $output-override;

    # Scheme matching is case-insensitive: HTTP:// and HTTPS:// are URLs too.
    my $is-url = $input ~~ /^ :i 'http' 's'? '://' /;

    my $stem;
    my $context = '';
    my Bool $host-derived = False;

    if $is-url {
        # Parse as a URI so query strings and fragments never leak into the
        # derived filename.
        my $uri = URI.new($input);
        my @segments = ($uri.path // '').Str.split('/').grep(*.chars > 0);
        if @segments {
            $stem = @segments.pop;
            if @segments.elems > 0 {
                $context = @segments.grep(* !~~ /^ \d+ $/).tail(2).join('-');
            }
        } else {
            # No path segments: derive the stem from the host, e.g.
            # https://example.com/ → example.xml.  A leading www. is stripped
            # first so www.example.com → example.xml, not www.xml.  A
            # multi-part TLD (co.uk, com.au, org.uk) is a short second-level
            # label plus a 2-char TLD on a host with at least three labels;
            # strip both labels in that case, otherwise strip only the final
            # one so example.com keeps the example pair instead of collapsing
            # to nothing.
            $host-derived = True;
            my $host = ($uri.host // '').subst(/^ 'www' \. /, '');
            my $multi-tld = $host ~~ / '.' .+ '.' /
                && $host ~~ / \. <-[.]> ** 2..3 '.' <-[.]> ** 2 $ /;
            $stem = $multi-tld
                ?? $host.subst(/ \. <-[.]> ** 2..3 '.' <-[.]> ** 2 $ /, '')
                !! $host.subst(/ \. <-[.]>+ $ /, '');
            $stem = 'sitemap' if !$stem;
        }
    } else {
        # Local files: write next to the input instead of the CWD, e.g.
        # /tmp/site/my/sitemap.xml → /tmp/site/my/sitemap.txt
        $stem = $input.IO.basename;
    }

    # Strip .gz and any extension. A host-derived stem already had its TLD
    # removed above; stripping an extension off it again would turn
    # https://www.example.com/ into just www, so only path/file-derived stems
    # get their extension stripped here.
    $stem = $stem.subst(/\.gz $/, '');
    $stem = $stem.subst(/ \. <-[.]>+ $/, '') unless $host-derived;
    $stem = 'sitemap' if !$stem;

    # Add the correct extension
    my $basename = "{$stem}{$context ?? "-$context" !! ''}.{$format}";

    # B20 hardening: an empty dirname (IO::Path.dirname of a bare name is ".",
    # but guard anyway) must resolve to "." instead of crashing IO::Path.new.
    my $dir = $input.IO.dirname;
    $dir = '.' unless $dir.chars;

    $is-url ?? $basename !! $dir.IO.add($basename).Str;
}

#| Iteratively remove a directory tree (no IO::Path.rmtree in core).
#| Never follows symlinks: .d follows links to directories, so check .l first.
sub remove-dir(IO::Path $dir) {
    my @stack = $dir;
    my @pending-rmdir;
    while @stack {
        my $current = @stack.pop;
        for $current.dir -> $entry {
            if $entry.l {
                $entry.unlink;
            } elsif $entry.d {
                @stack.push: $entry;
                @pending-rmdir.push: $entry;
            } else {
                $entry.unlink;
            }
        }
    }
    # @pending-rmdir was filled in pre-order (parents before children), so
    # iterate it in reverse: a directory must be empty before rmdir succeeds,
    # and every child directory precedes its ancestors in the reversed list
    # (all files were already unlinked during the traversal above).
    .rmdir for @pending-rmdir.reverse;
    $dir.rmdir;
}

#| Validate output directory: refuse paths outside CWD, resolve symlinks,
#| handle --force deletion, and mkdir.
my sub validate-output-dir(Str $out-dir, Bool :$force, Bool :$verbose) {
    # Refuse to touch anything outside the current directory. The raw-string
    # checks below only catch relative escapes and unexpanded homes; whether
    # the target actually stays inside the real CWD is decided by the .resolve
    # checks further down (which follow symlinks), so a safe absolute path is
    # allowed here but still gated against escaping the CWD later. '\/' in the
    # regex is a literal backslash followed by a slash, which never occurs in a
    # path — compare whole '..' segments with real slashes.
    if $out-dir ~~ / (^ | '/') '..' [ '/' | $ ] / || $out-dir.starts-with('~') {
        die "Error: refusing to use output directory '$out-dir': path must stay inside the current directory";
    }

    # The guards above only inspect the raw string, so a symlink in an
    # intermediate component defeats them: `.l` below checks just the final
    # component, and `b3-link/dir` (with `b3-link -> /elsewhere`) neither
    # contains `..` nor starts with `/`. Resolve the path -- .resolve walks
    # existing symlink components even when the tail does not exist yet -- and
    # require the target to stay inside the real CWD, or --force would
    # recursively delete (and the writes would populate) an outside directory.
    my $cwd-resolved = $*CWD.resolve.Str;
    my $out-resolved = $out-dir.IO.resolve.Str;
    if $out-resolved ne $cwd-resolved && !$out-resolved.starts-with($cwd-resolved ~ '/') {
        die "Error: refusing to use output directory '$out-dir': it resolves to '$out-resolved', outside the current directory";
    }

    # Handle --force: remove existing directory or the regular file that
    # occupies the out-dir slot. Removal is limited to paths that are not '.'
    # and are guaranteed inside the real CWD by the resolve check above; the
    # .. and ~ guards already applied, and a symlink is unlinked (never
    # followed), so --force can never delete anything outside the CWD.
    if $force && $out-dir.IO.e && $out-dir ne '.' {
        if $out-dir.IO.l {
            say "Force: removing symlink $out-dir" if $verbose;
            $out-dir.IO.unlink;
        } elsif $out-dir.IO.d {
            say "Force: removing existing $out-dir/" if $verbose;
            remove-dir($out-dir.IO);
        } else {
            say "Force: removing existing file $out-dir" if $verbose;
            $out-dir.IO.unlink;
        }
    }
    # A regular file in the out-dir slot (and no --force) is not a valid
    # output target: mkdir would be skipped below and child sitemaps would
    # then fail to write into the file path with a confusing IO error. Bail
    # with a clear message instead of proceeding.
    if $out-dir.IO.e && !$out-dir.IO.d && !$out-dir.IO.l {
        die "Error: output directory '$out-dir' is an existing file; use --force to replace it";
    }
    $out-dir.IO.mkdir unless $out-dir.IO.e || $out-dir.IO.l;

    # Re-validate after mkdir: the resolved path may have changed if a
    # symlink was swapped between the pre-check and the mkdir.
    my $post-mkdir-resolved = $out-dir.IO.resolve.Str;
    if $post-mkdir-resolved ne $out-resolved {
        die "Error: output directory '$out-dir' resolved to '$post-mkdir-resolved' after mkdir, "
            ~ "expected '$out-resolved' (symlink swap?)";
    }
}

#| Fetch child sitemaps in parallel, populating @children, @saved, @errors.
my sub fetch-child-sitemaps(
    @entries, $out-dir, @children is raw, @saved is raw, @errors is raw,
    Bool :$ssl-verify, Bool :$verbose, Int :$concurrency
) {
    my @child-urls = @entries.map(*<loc>);
    my @tasks = @child-urls.kv.map(-> $i, $url { %(:$i, :$url) });
    my $next = 0;

    my $lock = Lock.new;
    my %used;
    my $effective-workers = min($concurrency, @tasks.elems);

    my @workers = (^$effective-workers).map: {
        start {
            loop {
                my (%task, $child-file, $url, $i);
                $lock.protect: {
                    if $next < @tasks.elems {
                        %task = @tasks[$next++];
                        $url = %task<url>;
                        $i = %task<i>;
                        my $child-name = output-filename($url, :format<xml>);
                        my $candidate = "$out-dir/$child-name";
                        my $n = 0;
                        while $candidate.IO.e || %used{$candidate} {
                            die "Too many filename collisions for $child-name"
                                if $n > 10_000;
                            $candidate = "$out-dir/" ~ $child-name.subst(/\.xml$/, "-$n.xml");
                            $n++;
                        }
                        %used{$candidate} = True;
                        $child-file = $candidate;
                    }
                };
                last unless %task.elems;

                try { say "Fetching child sitemap: $url" if $verbose; };

                my $child-xml = try {
                    fetch($url, :$ssl-verify, :$verbose);
                }
                my $child-err = $!;

                unless $child-xml.defined && $child-xml.chars {
                    my $err-msg = $child-xml.defined && !$child-xml.chars
                        ?? 'Empty response body'
                        !! ($child-err ?? $child-err.message !! 'Failed to fetch');
                    $lock.protect: { @errors.push: { url => $url, error => $err-msg } };
                    next;
                }

                my $sniff = Sitemap::Grammar::SitemapSniff.subparse(
                    $child-xml, :actions(Sitemap::Grammar::SitemapSniff::Actions.new));
                unless $sniff && ($sniff.made // '') eq 'xml-sitemap' {
                    try { say "Warning: skipping $url: response is not an XML sitemap" if $verbose; };
                    $lock.protect: { @errors.push: { url => $url, error => 'Response is not an XML sitemap' } };
                    next;
                }
                $child-file.IO.spurt($child-xml);
                try { say "Saved: $child-file" if $verbose; };
                $lock.protect: {
                    @children.push: $child-file;
                    @saved[$i] = $child-file;
                };
            }
        }
    }

    await @workers;
}

#| Fetch a sitemap (index or regular) with optional recursive fetching
sub fetch-recursive(
    Str $sitemap-url,
    Str :$format = 'xml',
    Str :$output = '',
    Bool :$force = False,
    Bool :$ssl-verify = True,
    Bool :$verbose = False,
    Int :$concurrency = 10,
    Bool :$follow-foreign-children = False,
    Int :$max-children = 1000,
    --> Hash
) is export {
    my $xml = fetch($sitemap-url, :$ssl-verify, :$verbose);

    # An empty 200 body is not a sitemap; fail loudly instead of writing an
    # empty file and reporting success (a child fetch below treats the same
    # body as an error).
    die "Failed to fetch $sitemap-url: empty response body" unless $xml.chars;

    # Determine output filename
    my $out-file = output-filename($sitemap-url, :$format, :output-override($output));

    # An extensionless -o would make the recursive case derive a child
    # directory identical to the index filename (mkdir then spurt into a
    # directory). Mirror output-filename's own default (which always appends
    # the format extension) so `-o foo` behaves like `-o foo.xml`.
    $out-file = "{$out-file}.{$format}" unless $out-file ~~ / \. <[a..zA..Z0..9]>+ $ /;

    # Check if it's actually a sitemap index (root-anchored, B6)
    unless Sitemap::Parser.is-sitemap-index($xml) {
        # Not an index - just save the sitemap and return
        if $format eq 'xml' {
            $out-file.IO.spurt($xml);
            say "Saved: $out-file" if $verbose;
        } else {
            my @items = try { Sitemap::Parser.parse-xml-string($xml) } // do {
                note "Failed to parse sitemap content as $format: {$! ?? $!.message !! 'unknown error'}" if $verbose;
                ();
            };
            my $content = format-output(@items, $format, $sitemap-url);
            $out-file.IO.spurt($content);
            say "Saved converted: $out-file" if $verbose;
        }

        return %(
            index-file => $out-file,
            dir => '',
            children => [],
        );
    }

    # It IS a sitemap index - proceed with recursive fetch
    my $out-dir = $out-file.subst(/ \. <-[.]>+ $/, '');

    # Make directory name more descriptive by including domain
    if $output eq '' {
        if $sitemap-url ~~ /^^ 'http' 's'? '://' (<-[\/]>+) / {
            my $domain = $0.Str;
            # A host:port authority embeds ':' in the directory name — fine
            # on Linux, hostile on Windows and network shares.
            $out-dir = "{$domain.subst(/<[.:]>/, '-', :g)}-$out-dir";
        }
    }

    # Refuse to touch anything outside the current directory, handle
    # --force deletion, and mkdir.
    validate-output-dir($out-dir, :$force, :$verbose);

    # Save index file
    if $format eq 'xml' {
        $out-file.IO.spurt($xml);
        say "Saved index: $out-file" if $verbose;
    }

    # Parse child URLs from sitemap index
    my @index-entries = Sitemap::Parser.parse-xml-index-string($xml);

    # Keep the parsed metadata (lastmod) alongside each child so the rewritten
    # local index below can preserve it. Locs are resolved against the index
    # URL before origin checks, otherwise scheme-less children are always
    # dropped.
    my @entries = @index-entries.map: -> %e {
        %( loc => resolve-relative-url(%e<loc>, $sitemap-url), lastmod => %e<lastmod> )
    };

    # A child sitemap without a usable <loc> cannot be fetched. The parser
    # normally drops loc-less entries, but guard defensively so a malformed
    # index can never hand a Nil/empty URL to the fetch workers.
    @entries = @entries.grep: -> %e {
        %e<loc>.defined && %e<loc>.chars;
    };

    # SSRF guard: by default only fetch children on the same origin (scheme,
    # host and effective port) as the index. --follow-foreign-children opts
    # into cross-origin children.
    unless $follow-foreign-children {
        @entries = @entries.grep: -> %e {
            same-origin($sitemap-url, %e<loc>);
        };
    }

    # Cap the number of children fetched from a single index.
    if @entries.elems > $max-children {
        say "Warning: sitemap index references {@entries.elems} child sitemaps; capping at $max-children" if $verbose;
        @entries = @entries[^$max-children];
    }

    # index-file names the file that was actually saved for the index. It only
    # exists for the xml format, where the raw index is written above; for a
    # non-xml conversion the raw index is never saved (only an optional
    # converted bundle below), so claiming index-file here would point at a
    # path that does not exist.
    my %results = (
        dir => $out-dir,
        children => [],
        errors => [],
    );
    %results<index-file> = $out-file if $format eq 'xml';

    my (@children, @saved, @errors);
    fetch-child-sitemaps(
        @entries, $out-dir, @children, @saved, @errors,
        :$ssl-verify, :$verbose, :$concurrency);
    %results<children> = @children;
    %results<errors> = @errors;

    # Rewrite the saved index so each <loc> points at the locally saved child
    # file instead of the original remote URL: the mirror must be self-contained
    # and traversable offline. Only children that actually downloaded are
    # referenced (failed ones were reported through %results<errors>), and the
    # paths are relative to the index file so the whole directory stays
    # relocatable. lastmod is carried over from the parsed index entries.
    if $format eq 'xml' && @saved.elems {
        my $index-builder = Sitemap::Builder.new;
        for @entries.kv -> $i, %e {
            next unless @saved[$i].defined;
            my $local = @saved[$i].IO.relative($out-file.IO.parent);
            $index-builder.add-sitemap($local, |(%e<lastmod>.defined ?? (lastmod => %e<lastmod>) !! ()));
        }
        my $local-index = $index-builder.render-index(:allow-relative);
        $out-file.IO.spurt($local-index);
        say "Rewrote index with local child paths: $out-file" if $verbose;
    }

    # If converting to another format, also create converted output. With zero
    # children fetched (an empty index, or every child failed), writing a
    # converted file would silently publish an empty document, so skip it.
    if $format ne 'xml' && @children.elems {
        my $parse-result = Sitemap::Parser.parse-xml-files(@children);
        my $content = format-output($parse-result<items>.list, $format, $sitemap-url);
        $out-file.IO.spurt($content);
        say "Saved converted: $out-file" if $verbose;
        %results<converted> = $out-file;
    }

    %results;
}

#| Format items into the specified format
our sub format-output(@items, Str $fmt, Str $title = '', Str $link = '', :$pretty = True --> Str) is export {
    given $fmt {
        when 'html' { Sitemap::Format::HTML.render-list(@items.List, :$title, :$pretty) }
        when 'txt'  { Sitemap::Format::TXT.render-list(@items.map(*.url).List) }
        # RSS/Atom render() takes the full items so lastmod/title metadata is kept
        when 'rss'  { Sitemap::Format::RSS.render(@items.List, :$title, :$link, :$pretty) }
        when 'atom' { Sitemap::Format::Atom.render(@items.List, :$title, :$link, :$pretty) }
        when 'mrss' { Sitemap::Format::MRSS.render(@items.List, :$title, :$link, :$pretty) }
        default     { die "Unknown output format: $fmt. Supported formats: html, txt, rss, atom, mrss" }
    }
}

#| Discover sitemap URL from a domain (robots.txt, then fallback to /sitemap.xml)
our sub discover-sitemap(Str $domain is copy, Bool :$ssl-verify = True, Bool :$verbose = False --> Str) is export {
    # Normalize a bare domain to https:// so the robots.txt discovery and the
    # /sitemap.xml fallback both have a usable URL instead of failing with an
    # opaque scheme error.
    $domain = normalize-start-url($domain);

    # Try robots.txt first
    my @sitemaps = Sitemap::Config::discover-sitemaps($domain, :$ssl-verify);
    if @sitemaps {
        say "Found sitemap in robots.txt: @sitemaps[0]" if $verbose;
        return @sitemaps[0];
    }

    # Fallback: try domain/sitemap.xml
    say "No sitemaps found in robots.txt, trying $domain/sitemap.xml..." if $verbose;
    my $fallback = $domain.ends-with('/') ?? $domain !! "$domain/";
    $fallback ~= 'sitemap.xml';

    my $http = cached-client(:$ssl-verify, timeout => { connection => 10, body => 30 });
    my $response = try await $http.get($fallback);
    if $response && $response.status == 200 {
        say "Found sitemap: $fallback" if $verbose;
        return $fallback;
    }

    die "No sitemap found at $fallback either";
}

=begin pod

=head1 NAME

Sitemap::Fetcher - Fetch sitemaps from remote servers

=head1 SUBS

=head2 fetch(Str $url, Bool :$ssl-verify, Bool :$verbose, Str :$user-agent --> Str)

Fetch a sitemap from a URL and return its content. Handles automatic gzip decompression.

=head2 get-decompressed-content(Str $url, $response, Bool :$verbose --> Str)

Decompress content from an HTTP response, handling gzip encoding. Checks C<Content-Encoding>
header and gzip magic bytes.

=head2 output-filename(Str $input, Str :$format, Str :$output-override --> Str)

Generate output filename from URL, adding path context (e.g., C<sitemap-blog.xml>
for C<https://example.com/blog/sitemap.xml>).

=item C<:$format> - output extension/format (e.g., C<xml>, C<txt>)
=item C<:$output-override> - explicit output filename; used as-is when non-empty

=head2 fetch-recursive(Str $sitemap-url, Str :$format = 'xml', Str :$output = '', Bool :$force, Bool :$ssl-verify, Bool :$verbose, Int :$concurrency, Bool :$follow-foreign-children, Int :$max-children)

Fetch a sitemap index and all child sitemaps. Creates a descriptive directory with
path-aware filenames.

=item C<:$format> - output format (default: C<xml>)
=item C<:$output> - output filename (default: derived from the URL)
=item C<:$force> - delete existing output directory first
=item C<:$concurrency> - bounds the parallel child fetches (default: 10)
=item C<:$follow-foreign-children> - (default False) allows child sitemaps on other hosts;
leaving it off enforces the same-origin guard (SSRF protection)
=item C<:$max-children> - caps how many child sitemaps are downloaded (default: 1000)

=head2 format-output(@items, Str $fmt, Str $title, Str $link, :$pretty --> Str)

Format sitemap items into the specified format (html, txt, rss, atom, mrss).
Note: C<xml> is not a valid C<$fmt> here — for XML output write the parsed
items via Sitemap::Builder instead.

=head2 discover-sitemap(Str $domain, Bool :$ssl-verify, Bool :$verbose --> Str)

Discover a sitemap URL from a domain. Checks robots.txt first, then falls back to
C</sitemap.xml>. Returns the URL or dies if not found.

=end pod
