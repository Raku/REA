use v6.d;

unit module Sitemap::Extraction;

use Sitemap::Item;
use Sitemap::Config;
use Sitemap::Grammar::LinkExtract;
use Sitemap::JsonLd;
use URI;

#| The effective base URL for resolving relative references in a page: the
#| first <base href> resolved against the document URL (per the HTML spec a
#| base href may itself be relative, so it must resolve against the document
#| URL first), falling back to the page URL when there is no <base> or the
#| resolved value is not a usable http(s) URL. The document's own URL is never
#| replaced by <base> — only sub-resource and link resolution is affected.
#| Callers that already scanned the page's tags (Crawler/DirScanner, via
#| extract-tag-bodies) pass the <base> tag bodies through :@base-bodies so the
#| page is not re-scanned for the base href.
our sub effective-base(Str $page-url, Str $content, :@base-bodies = [] --> Str) {
    my $href = @base-bodies.elems
        ?? (Sitemap::Grammar::LinkExtract::extract-tag-attrs(@base-bodies[0])<href> // '')
        !! Sitemap::Grammar::LinkExtract::extract-base-href($content);
    return $page-url unless $href;
    my $resolved = try Sitemap::Config::resolve-reference($href, URI.new($page-url));
    return $page-url unless $resolved && $resolved ~~ /^ :i https? \: \/\//;
    $resolved;
}

#| The optional $jsonld positional carries already-parsed JSON-LD objects (see
#| extract-jsonld) so the document is not re-parsed; a provided-but-empty list
#| is authoritative. Omitting it parses the document here.
our sub extract-videos-for-item(Str $content, Str $url, $jsonld?, :@meta-tags = [], Bool :$meta-tags-provided = False, :%tag-bodies = {}, Int :$max-videos = 100 --> List) is export {
    my @videos;
    my %seen;

    for Sitemap::Grammar::LinkExtract::extract-videos($content, $url, :@meta-tags, :$meta-tags-provided, :%tag-bodies) -> %v {
        next if %seen{%v<url>}++;
        @videos.push: Sitemap::Item::Video.new(
            content-loc => %v<url>,
            thumbnail-loc => (%v<poster> // ''),
        );
    }

    # JSON-LD blocks are parsed once by the caller (Crawler) and threaded
    # through here so video and news extraction never re-split the HTML.
    for extract-video-objects($content, $jsonld) -> %v {
        # JSON-LD contentUrl/thumbnailUrl may be page-relative; the sitemap
        # protocol requires fully-qualified URLs. Resolve BEFORE the seen
        # check: the HTML/meta loop above dedupes on absolute URLs (its URLs
        # arrive pre-resolved), and deduping a relative JSON-LD URL on its
        # raw form would emit the same video twice when a page advertises it
        # both ways.
        my $v-url = %v<url> ~~ /^ :i https? \: \/\//
            ?? %v<url>
            !! resolve-relative-url(%v<url>, $url);
        next if %seen{$v-url}++;
        my $thumb-raw = %v<thumbnail> // '';
        my $thumb = $thumb-raw ~~ /^ :i https? \: \/\//
            ?? $thumb-raw
            !! resolve-relative-url($thumb-raw, $url);
        @videos.push: Sitemap::Item::Video.new(
            content-loc => $v-url,
            thumbnail-loc => ($thumb // ''),
            title => %v<title> // '',
            description => %v<description> // '',
            duration => %v<duration>,
            publication-date => (%v<pub-date> // ''),
        );
    }

    if @videos.elems > $max-videos {
        @videos = @videos[^$max-videos];
    }

    @videos;
}

#| Run the per-page asset pipeline shared by the Crawler and the DirScanner:
#| image, hreflang and video extraction plus a single JSON-LD parse (shared
#| with news extraction). Takes a pre-computed :%tag-bodies scan (so the page
#| is not re-scanned), reuses it for the <base href>, meta and link bodies,
#| and returns a Hash of the extracted assets plus the parsed @jsonld for the
#| caller's news handling.
our sub extract-page-assets(Str $content, Str $page-url, Str :$provided-base-url = '',
    :%tag-bodies = (),
    Bool :$extract-images = False, Bool :$extract-hreflang = False,
    Bool :$extract-videos = False, Bool :$extract-news = False,
    Int :$max-images = 1000, Int :$max-videos = 100 --> Hash) is export {
    my Bool $meta-tags-provided = $extract-images || $extract-videos;
    my @meta-tags = $meta-tags-provided ?? %tag-bodies<meta>.list !! [];

    # The Crawler computes the effective base once for link resolution and
    # threads it through, so it is not recomputed identically per page here.
    my $base-url = $provided-base-url.chars
        ?? $provided-base-url
        !! effective-base($page-url, $content, :base-bodies(%tag-bodies<base>.list));

    # Issue #11: same-origin guard for asset extraction.  A cross-origin
    # <base href> may intentionally redirect link crawling to another host
    # (and its robots.txt), but relative asset URLs (images, hreflang,
    # videos) should resolve against the page's own origin — a malicious
    # or accidental cross-origin base must not drag relative asset URLs
    # off the page's host.
    my $asset-base-url = $base-url;
    if $page-url && $base-url && $base-url ne $page-url {
        my $page-origin = Sitemap::Config::canonical-origin(URI.new($page-url));
        my $base-origin = Sitemap::Config::canonical-origin(URI.new($base-url));
        $asset-base-url = $page-url unless $page-origin eq $base-origin;
    }

    my @images;
    if $extract-images {
        my @image-urls = Sitemap::Grammar::LinkExtract::extract-images($content, $asset-base-url, :@meta-tags, :$meta-tags-provided, :%tag-bodies);
        # Cap per page (default 1000, Google's limit)
        @image-urls = @image-urls[^$max-images] if @image-urls.elems > $max-images;
        @images = @image-urls.map: -> $img-url {
            Sitemap::Item::Image.new(:url($img-url))
        };
    }

    my @links;
    if $extract-hreflang {
        my @hreflang = Sitemap::Grammar::LinkExtract::extract-hreflang-links($content, $asset-base-url, :link-bodies(%tag-bodies<link>.list));
        @links = @hreflang.map: -> $link {
            Sitemap::Item::Link.new(:lang($link<lang>), :url($link<url>));
        };
    }

    my @jsonld = ($extract-videos || $extract-news)
        ?? extract-jsonld($content)
        !! ();

    my @videos;
    if $extract-videos {
        @videos = extract-videos-for-item($content, $asset-base-url, @jsonld, :@meta-tags, :$meta-tags-provided, :%tag-bodies, :$max-videos);
    }

    { images => @images, links => @links, videos => @videos, jsonld => @jsonld };
}
