use v6.d;

use Sitemap::Item;
use Sitemap::Format::FeedBuilder;
use Syndicate::Builder::Feed;

class Sitemap::Format::MRSS is Sitemap::Format::FeedBuilder {

    method setup-feed($fb, List $entries, Str :$title, Str :$description, Str :$link, DateTime :$now) {
        $fb.title($title);
        $fb.link($link || '');
        $fb.description($description || '');
        $fb.updated($now // DateTime.now);
    }

    #| Per-entry setup. Titles fall back to the URL; optional metadata adds
    #| lastmod plus media:content/media:thumbnail elements for videos and
    #| images.
    method setup-entry($e, $entry, Str $url, Bool :$with-meta) {
        my $title = ($entry ~~ Sitemap::Item && $entry.title.chars) ?? $entry.title !! $url;
        $e.title($title);
        unless $with-meta && $entry ~~ Sitemap::Item {
            return;
        }
        $e.updated($entry.lastmod) if $entry.lastmod;

        for $entry.videos -> $video {
            # media:content must identify the video itself, never the
            # enclosing HTML page: a player-loc-only video used to fall
            # back to $item.url, pointing the media element at the page
            # that embeds it. Prefer content-loc, then player-loc
            # (Google's mRSS profile allows either), and skip the
            # element entirely when a video has neither.
            my $media-url = $video.content-loc.chars ?? $video.content-loc !! $video.player-loc;
            next unless $media-url.chars;
            $e.media-content(
                url => $media-url,
                type => 'video',
                medium => 'video',
                title => $video.title // '',
                description => $video.description // '',
                |($video.duration.defined && $video.duration > 0
                    ?? (duration => $video.duration)
                    !! Empty),
            );
            $e.media-thumbnail(url => $video.thumbnail-loc) if $video.thumbnail-loc;
        }

        for $entry.images -> $image {
            $e.media-content(
                url => $image.url,
                type => 'image',
                medium => 'image',
                title => $image.title // '',
                description => $image.caption // '',
            );
        }
    }

    method serialize($fb, Bool :$pretty) {
        # Match the pre-refactor MRSS output exactly: Syndicate's rss-str is
        # called WITHOUT :pretty, so MRSS has always emitted flat XML and
        # ignored the :pretty flag (unlike RSS/Atom which honor it).
        my $xml = $fb.rss-str;
        # Ensure the media namespace is always declared in MRSS output,
        # even when no media-content elements are present. Scope the lookup to
        # the opening <rss> tag only, so a literal "xmlns:media" inside an
        # element's text/attribute content could never suppress the injection
        # (audit C2). Syndicate emits the whole feed on one line, so capture
        # up to the first '>' of the <rss> tag; a greedy '<rss' <-[\n]>* would
        # swallow the closing '>' and append after </rss>, producing malformed
        # XML.
        my $rss-head = $xml ~~ / '<rss' ( .*? ) '>' / ?? ~$0 !! '';
        unless $rss-head.contains('xmlns:media') {
            $xml .= subst(/ '<rss' ( \s <-[>]>*? )? '>' /, -> $m {
                '<rss' ~ ($m[0] // '') ~ ' xmlns:media="http://search.yahoo.com/mrss/">'
            });
        }
        $xml
    }
}

=begin pod

=head1 NAME

Sitemap::Format::MRSS - Generate Media RSS (mRSS) sitemaps

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Builder;
use Sitemap::Format::MRSS;

my $builder = Sitemap::Builder.new;
$builder.add-item('https://example.com/video1');

my $mrss = Sitemap::Format::MRSS.render($builder.get-items, :title<My Videos>);
$mrss.IO.spurt('mrss.xml');

=end code

=head1 METHODS

=head2 render(List $items, :$title, :$description, :$link)

Render a list of Sitemap::Item objects as Media RSS XML.

=head2 render-list(List $urls, :$title, :$description, :$link)

Render a list of URLs as Media RSS XML.

=end pod
