use v6.d;

use Sitemap::Item;

my sub xml-escape(Str $s --> Str) {
    $s.subst('&', '&amp;', :g)
      .subst('<', '&lt;', :g)
      .subst('>', '&gt;', :g)
      .subst('"', '&quot;', :g)
}

class Sitemap::Format::HTML {

    method render-list(List $urls, Str :$title = 'Sitemap', Str :$lang = 'en', Bool :$pretty = True) {
        my $nl  = $pretty ?? "\n" !! '';
        my $ind = $pretty ?? '  ' !! '';

        my @parts;
        @parts.push: '<!DOCTYPE html>', $nl;
        @parts.push: '<html lang="', xml-escape($lang), '">', $nl;
        @parts.push: '<head>', $nl;
        @parts.push: $ind, '<meta charset="UTF-8">', $nl;
        @parts.push: $ind, '<title>', xml-escape($title), '</title>', $nl;
        @parts.push: '</head>', $nl;
        @parts.push: '<body>', $nl;
        @parts.push: $ind, '<h1>', xml-escape($title), '</h1>', $nl;
        @parts.push: $ind, '<ul>', $nl;
        for @$urls -> $entry {
            my ($url, $lastmod);
            if $entry ~~ Sitemap::Item {
                $url = $entry.url;
                $lastmod = $entry.lastmod;
            } else {
                $url = $entry.Str;
            }
            my $e = xml-escape($url);
            my $li = '<li><a href="' ~ $e ~ '">' ~ $e ~ '</a>';
            if $lastmod.defined {
                $li ~= ' <span class="lastmod">(' ~ xml-escape($lastmod.Str) ~ ')</span>';
            }
            $li ~= '</li>';
            @parts.push: $ind, $ind, $li, $nl;
        }
        @parts.push: $ind, '</ul>', $nl;
        @parts.push: '</body>', $nl;
        @parts.push: '</html>';
        @parts.join('');
    }

    #| Stream the HTML to a writable handle (a plain file handle or a
    #| gzip-streaming adapter), so the CLI write path never holds the full
    #| document string in memory (audit F). Emits exactly the bytes
    #| render-list would join together.
    method render-to($fh, List $urls, Str :$title = 'Sitemap', Str :$lang = 'en', Bool :$pretty = True) {
        my $nl  = $pretty ?? "\n" !! '';
        my $ind = $pretty ?? '  ' !! '';

        $fh.print: '<!DOCTYPE html>', $nl;
        $fh.print: '<html lang="', xml-escape($lang), '">', $nl;
        $fh.print: '<head>', $nl;
        $fh.print: $ind, '<meta charset="UTF-8">', $nl;
        $fh.print: $ind, '<title>', xml-escape($title), '</title>', $nl;
        $fh.print: '</head>', $nl;
        $fh.print: '<body>', $nl;
        $fh.print: $ind, '<h1>', xml-escape($title), '</h1>', $nl;
        $fh.print: $ind, '<ul>', $nl;
        for @$urls -> $entry {
            my ($url, $lastmod);
            if $entry ~~ Sitemap::Item {
                $url = $entry.url;
                $lastmod = $entry.lastmod;
            } else {
                $url = $entry.Str;
            }
            my $e = xml-escape($url);
            my $li = '<li><a href="' ~ $e ~ '">' ~ $e ~ '</a>';
            if $lastmod.defined {
                $li ~= ' <span class="lastmod">(' ~ xml-escape($lastmod.Str) ~ ')</span>';
            }
            $li ~= '</li>';
            $fh.print: $ind, $ind, $li, $nl;
        }
        $fh.print: $ind, '</ul>', $nl;
        $fh.print: '</body>', $nl;
        $fh.print: '</html>';
    }
}

=begin pod

=head1 NAME

Sitemap::Format::HTML - Generate HTML sitemaps

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Builder;
use Sitemap::Format::HTML;

my $builder = Sitemap::Builder.new;
$builder.add-item('https://example.com/page1');
$builder.add-item('https://example.com/page2');

my $html = Sitemap::Format::HTML.render-list($builder.get-items.map(*.url).List, :title<My Site>);
$html.IO.spurt('sitemap.html');

=end code

=head1 METHODS

=head2 render-list(List $urls, Str :$title)

Render a simple list of URLs as HTML.

=head2 render-to($fh, List $urls, Str :$title, Str :$lang, Bool :$pretty)

Stream the HTML to a writable handle C<$fh>, emitting exactly the bytes
C<render-list> would join together without materializing the document in memory.

=end pod
