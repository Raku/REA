use v6.d;

use Sitemap::Item;
use Syndicate::Builder::Feed;

#| Shared base for the Syndicate-backed sitemap feed formats (RSS 2.0, Atom
#| 1.0, Media RSS). Centralizes the render/render-list surface, the fallback
#| URL scan, the feed timestamp and the entry loop, which were duplicated
#| across RSS/Atom/MRSS (audit C1). Each concrete format only overrides the
#| three seams that actually differ:
#|   * setup-feed   — format-level feed fields (title/link/description/id)
#|   * setup-entry  — format-level entry fields (title fallback, ids, media)
#|   * serialize    — which Syndicate string render to use (rss vs atom)
#| The seams are public (not !private) because Raku private methods are never
#| visible to subclasses, so an inheriting format could not call/override them.
#| Output is byte-identical to the pre-refactor per-format assemblers.
class Sitemap::Format::FeedBuilder {

    #| Render a list of Sitemap::Item (with metadata) to the feed's XML.
    method render(List $items, Str :$title = 'Sitemap', Str :$description = '', Str :$link = '', Bool :$pretty = True, DateTime :$now) {
        my $fb = self.build-feed($items, :$title, :$description, :$link, :$now, :with-meta);
        self.serialize($fb, :$pretty)
    }

    #| Render a plain list of URLs (no item metadata) to the feed's XML.
    method render-list(List $urls, Str :$title = 'Sitemap', Str :$description = '', Str :$link = '', Bool :$pretty = True, DateTime :$now) {
        my $fb = self.build-feed($urls, :$title, :$description, :$link, :$now);
        self.serialize($fb, :$pretty)
    }

    #| The first real URL in the entries, or '' when there are none. Formats
    #| apply their own fallback on top (RSS backstops to the title; Atom builds
    #| a tag scheme from the title), preserving the pre-refactor behaviour.
    method fallback-url(List $entries --> Str) {
        for @$entries -> $e {
            my $u = $e ~~ Sitemap::Item ?? $e.url !! $e.Str;
            return $u if $u.chars;
        }
        ''
    }

    #| Template method: build the feed object, call the format's feed-level and
    #| per-entry seams, and return it ready for serialize.
    method build-feed(List $entries, Str :$title, Str :$description, Str :$link, DateTime :$now, Bool :$with-meta = False --> Syndicate::Builder::Feed) {
        my $fb = Syndicate::Builder::Feed.new;
        self.setup-feed($fb, $entries, :$title, :$description, :$link, :$now);

        for @$entries -> $entry {
            my $e = $fb.add-entry;
            my $url = $entry ~~ Sitemap::Item ?? $entry.url !! $entry.Str;
            $e.link($url);
            self.setup-entry($e, $entry, $url, :$with-meta);
        }

        $fb
    }

    #| Feed-level seam. Must set at least title and updated; the format decides
    #| link/description/id fallbacks.
    method setup-feed($fb, List $entries, Str :$title, Str :$description, Str :$link, DateTime :$now) {
        X::NYI.new(feature => 'setup-feed').throw;
    }

    #| Per-entry seam. $url is the resolved item URL; the format fills title
    #| (with its fallback) and any optional metadata/ids/media.
    method setup-entry($e, $entry, Str $url, Bool :$with-meta) {
        X::NYI.new(feature => 'setup-entry').throw;
    }

    #| Serialization seam.
    method serialize($fb, Bool :$pretty) {
        X::NYI.new(feature => 'serialize').throw;
    }
}

=begin pod

=head1 NAME

Sitemap::Format::FeedBuilder - Shared base for the Syndicate-backed feed formats

=head1 SYNOPSIS

Concrete feed formats (RSS, Atom, MRSS) subclass this and override the three
seams C<setup-feed>, C<setup-entry> and C<serialize>. End users call the
public C<render> / C<render-list> methods.

=end pod
