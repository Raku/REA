use v6.d;

use Sitemap::Item;

class Sitemap::Format::TXT {

    method render(List $items) {
        # Identical to render-list; both emit one URL per line.
        self.render-list($items);
    }

    method render-list(List $urls) {
        return '' if $urls.elems == 0;
        $urls.map({ $_ ~~ Sitemap::Item ?? .url !! .Str }).join("\n") ~ "\n";
    }

    #| Stream one URL per line directly to a writable handle (a plain file
    #| handle or a gzip-streaming adapter), never materializing the full output
    #| in memory. This backs the CLI write path for large sitemaps (audit F).
    method render-to($fh, List $urls) {
        for @$urls -> $entry {
            $fh.print($entry ~~ Sitemap::Item ?? $entry.url !! $entry.Str);
            $fh.print("\n");
        }
    }
}

=begin pod

=head1 NAME

Sitemap::Format::TXT - Generate plain text sitemaps

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Builder;
use Sitemap::Format::TXT;

my $builder = Sitemap::Builder.new;
$builder.add-item('https://example.com/page1');
$builder.add-item('https://example.com/page2');

my $txt = Sitemap::Format::TXT.render($builder.get-items);
$txt.IO.spurt('sitemap.txt');

=end code

=head1 METHODS

=head2 render(List $items)

Render a list of SitemapItem objects as plain text (one URL per line).

=head2 render-list(List $urls)

Render a simple list of URLs as plain text.

=head2 render-to($fh, List $urls)

Stream one URL per line to a writable handle C<$fh> (a plain file handle or a
gzip-streaming adapter), never building the full output in memory.

=end pod
