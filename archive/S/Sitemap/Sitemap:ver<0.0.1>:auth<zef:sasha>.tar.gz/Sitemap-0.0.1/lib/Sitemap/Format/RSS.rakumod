use v6.d;

use Sitemap::Item;
use Sitemap::Format::FeedBuilder;

class Sitemap::Format::RSS is Sitemap::Format::FeedBuilder {

    #| Feed-level setup. RSS 2.0 requires channel title, link, and description.
    #| Sitemap-style feeds routinely leave link/description empty, so fall back
    #| to the first entry URL (link) and the feed title (description) instead
    #| of omitting them — Syndicate::Builder::Feed enforces the spec.
    method setup-feed($fb, List $entries, Str :$title, Str :$description, Str :$link, DateTime :$now) {
        my $first-url = self.fallback-url($entries);
        my $fallback-url = $first-url.chars ?? $first-url !! $title;
        $fb.title($title);
        $fb.description($description.chars ?? $description !! $title);
        $fb.link($link.chars ?? $link !! $fallback-url);
        $fb.updated($now // DateTime.now);
        $fb.atom-self-link($link) if $link;
    }

    #| Per-entry setup. RSS 2.0 items require a title; fall back to the URL.
    method setup-entry($e, $entry, Str $url, Bool :$with-meta) {
        my $title = ($with-meta && $entry ~~ Sitemap::Item && $entry.title.chars) ?? $entry.title !! $url;
        $e.title($title);
        $e.updated($entry.lastmod) if $with-meta && $entry ~~ Sitemap::Item && $entry.lastmod;
    }

    method serialize($fb, Bool :$pretty) {
        $fb.rss-str(:$pretty)
    }
}

=begin pod

=head1 NAME

Sitemap::Format::RSS - Generate RSS 2.0 sitemaps

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Builder;
use Sitemap::Format::RSS;

my $builder = Sitemap::Builder.new;
$builder.add-item('https://example.com/page1');

my $rss = Sitemap::Format::RSS.render($builder.get-items, :title<My Site>);
$rss.IO.spurt('sitemap.xml');

=end code

=head1 METHODS

=head2 render(List $items, :$title, :$description, :$link, :$now)

Render a list of Sitemap::Item objects as RSS 2.0 XML.

=over 4

=item C<:$now>

Optional DateTime for the feed-level C<lastBuildDate>. Defaults to
C<DateTime.now> (the wall-clock generation time, which is the intended
semantic for a live feed); pass an explicit C<:$now> for reproducible,
byte-identical output.

=back

=head2 render-list(List $urls, :$title, :$description, :$link, :$now)

Render a list of URLs as RSS 2.0 XML. C<:$now> behaves as for C<render>.

=end pod
