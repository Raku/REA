use v6.d;

use Sitemap::Item;
use Sitemap::Format::FeedBuilder;

class Sitemap::Format::Atom is Sitemap::Format::FeedBuilder {

    #| Atom requires feed <link> and <id>; fall back to the first entry URL
    #| (or a tag scheme built from the title) when the caller left :link empty.
    method setup-feed($fb, List $entries, Str :$title, Str :$description, Str :$link, DateTime :$now) {
        my $fallback-url = self.fallback-url($entries);
        my $resolved-link = $link.chars ?? $link !! ($fallback-url.chars ?? $fallback-url !! "tag:sitemap:{$title}");
        $fb.title($title);
        $fb.description($description) if $description;
        $fb.link($resolved-link);
        $fb.id($resolved-link);
        $fb.updated($now // DateTime.now);
    }

    #| Per-entry setup. Sitemap::Item.title defaults to '' (not Nil), so use
    #| .chars. Atom entries get an id and, with metadata, both updated and
    #| published.
    method setup-entry($e, $entry, Str $url, Bool :$with-meta) {
        my $title = ($entry ~~ Sitemap::Item && $entry.title.chars) ?? $entry.title !! $url;
        $e.title($title);
        if $with-meta && $entry ~~ Sitemap::Item && $entry.lastmod {
            $e.updated($entry.lastmod);
            $e.published($entry.lastmod);
        }
    }

    method serialize($fb, Bool :$pretty) {
        $fb.atom-str(:$pretty)
    }
}

=begin pod

=head1 NAME

Sitemap::Format::Atom - Generate Atom 1.0 sitemaps

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Builder;
use Sitemap::Format::Atom;

my $builder = Sitemap::Builder.new;
$builder.add-item('https://example.com/page1');

my $atom = Sitemap::Format::Atom.render($builder.get-items, :title<My Site>);
$atom.IO.spurt('sitemap.xml');

=end code

=head1 METHODS

=head2 render(List $items, :$title, :$description, :$link, :$now)

Render a list of Sitemap::Item objects as Atom 1.0 XML.

=over 4

=item C<:$now>

Optional DateTime for the feed-level C<updated>. Defaults to
C<DateTime.now> (the wall-clock generation time, which is the intended
semantic for a live feed); pass an explicit C<:$now> for reproducible,
byte-identical output.

=back

=head2 render-list(List $urls, :$title, :$description, :$link, :$now)

Render a list of URLs as Atom 1.0 XML. C<:$now> behaves as for C<render>.

=end pod
