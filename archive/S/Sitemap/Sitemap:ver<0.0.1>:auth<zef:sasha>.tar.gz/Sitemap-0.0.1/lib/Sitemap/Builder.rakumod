use v6.d;

use Sitemap::Item;
use Sitemap::Config;
use LibXML::Writer::Buffer;
use Compress::Zlib;

class Sitemap::Builder {
    has Int $.max-entries is rw = 50000;
    has Bool $.compress is rw = False;
    has Bool $.pretty is rw = True;
    has Bool $.verbose is rw = False;
    has Str $.xsl-url is rw = '';

    has Sitemap::Item @.items;
    has @.sitemaps;

    method TWEAK {
        die "max-entries must be a positive integer, got {$.max-entries}"
            unless $.max-entries > 0;
    }

    my constant $NAMESPACE = 'http://www.sitemaps.org/schemas/sitemap/0.9';
    my constant $IMAGE_NS = 'http://www.google.com/schemas/sitemap-image/1.1';
    my constant $VIDEO_NS = 'http://www.google.com/schemas/sitemap-video/1.1';
    my constant $NEWS_NS = 'http://www.google.com/schemas/sitemap-news/0.9';
    my constant $XHTML_NS = 'http://www.w3.org/1999/xhtml';
    my constant $ANDROID_NS = 'http://schemas.android.com/apk/res/android';
    my constant $AMP_NS = 'http://www.ampproject.org';

    method add-item(Str $url, :$lastmod, :$changefreq, :$priority, :$expires, :$title,
        Str :$android-link, Str :$amp-link,
        :@images = [], :@videos = [], :@links = [], :@news = []) {
        my %params = :$url;
        my $lastmod-precision;
        %params<lastmod> = self!coerce-lastmod($url, $lastmod, $lastmod-precision) if $lastmod.defined;
        %params<changefreq> = self!coerce-changefreq($url, $changefreq) if $changefreq.defined;
        %params<priority> = self!coerce-priority($url, $priority) if $priority.defined;
        %params<expires> = $expires if $expires.defined;
        %params<title> = $title if $title.defined;
        %params<android-link> = $android-link if $android-link.defined;
        %params<amp-link> = $amp-link if $amp-link.defined;
        %params<lastmod-precision> = $lastmod-precision if $lastmod-precision.defined;

        my $item = Sitemap::Item.new(|%params);
        $item.images.push: |self!dedup-by-key(@images, { .url }, 'Sitemap::Item::Image');
        $item.videos.push: |self!dedup-by-key(@videos, { .content-loc || .player-loc || '' }, 'Sitemap::Item::Video', :skip-empty-key);
        # hreflang alternates share one URL across languages: dedup on the
        # (lang, url) pair, not url alone, or every non-default locale but
        # the first is silently dropped. News dedups on publication+title:
        # syndicated copies of the same article under different URLs are
        # duplicates; distinct articles with identical titles in different
        # publications are not.
        $item.links.push: |self!dedup-by-key(@links, { .lang ~ "\x0" ~ .url }, 'Sitemap::Item::Link');
        $item.news.push: |self!dedup-by-key(@news, { (.publication // '') ~ "\x0" ~ .title }, 'Sitemap::Item::News');
        @.items.push: $item;
    }

    method !dedup-by-key(@items, &key-func, Str $type-name, :$skip-empty-key = False --> List) {
        my %seen;
        my @result;
        for |@items -> $obj {
            unless $obj.^name eq $type-name {
                die "add-item: unsupported object type {$obj.^name} "
                    ~ "(expected $type-name)";
            }
            my $key = &key-func($obj);
            if $skip-empty-key && !$key {
                next;
            }
            # Empty keys are never deduped; real keys keep the first
            # occurrence and drop later duplicates.
            if $key {
                next if %seen{$key}:exists;
                %seen{$key} = True;
            }
            @result.push: $obj;
        }
        @result;
    }

    method !coerce-lastmod(Str $url, $value, $precision is rw --> DateTime) {
        my $pair = coerce-lastmod-value($value);
        if $pair.defined {
            $precision = $pair.value;
            return $pair.key;
        }
        $value ~~ DateTime
            ?? $value
            !! die "Invalid lastmod '$value' for item '$url': cannot parse as DateTime";
    }

    method !coerce-changefreq(Str $url, $value --> Changefreq) {
        return $value if $value ~~ Changefreq;
        my $cf = coerce-changefreq(~$value);
        $cf // die "Invalid changefreq '$value' for item '$url' "
                ~ "(expected one of: always, hourly, daily, weekly, monthly, yearly, never)";
    }

    method !coerce-priority(Str $url, $value --> Numeric) {
        # Single shared normalization (range-check + negative-zero) lives in
        # Sitemap::Item::coerce-priority; only the URL-enriched error message
        # is re-issued here so add-item fans callers out in the same wording.
        my $p = try { coerce-priority($value) };
        $p.defined
            ?? $p
            !! die "Invalid priority '$value' for item '$url' (expected a number between 0.0 and 1.0)";
    }

    #| Add a pre-built Sitemap::Item, preserving all fields (lastmod, changefreq,
    #| priority, expires, title, android/amp links, images, videos, links, news)
    method add-item-from(Sitemap::Item $item) {
        # .clone is shallow: native @. arrays (images, videos, links, news)
        # share storage with the original, so a caller mutating the original's
        # arrays after add-item-from would also mutate the builder's copy.
        # set_value replaces the native array container with a fresh clone.
        # Resolve the Attribute descriptors once (^attributes builds a fresh
        # list per call) instead of re-scanning it for every field.
        my $copy = $item.clone;
        my %attrs = $copy.^attributes.map({ .name => $_ });
        # Items built outside add-item (parsers construct Sitemap::Item
        # directly) bypass !coerce-priority, so an out-of-range value used to
        # flow straight into <priority>42.0</priority>. Route through the same
        # validation; $.priority is not rw, so set the attribute directly.
        if $copy.priority.defined {
            %attrs{'$!priority'}.set_value(
                $copy, self!coerce-priority($copy.url, $copy.priority));
        }
        for <images videos links news> -> $attr {
            my $desc = %attrs{"@!$attr"};
            $desc.set_value($copy, $copy."$attr"().Array.clone);
        }
        @.items.push: $copy;
    }

    method add-sitemap(Str $url, :$lastmod) {
        # Accept DateTime or an ISO-8601/W3CDTF string like add-item's :lastmod
        # does; a bare Str used to die with a raw type-check binding error before
        # any validation could explain itself. Partial W3CDTF dates ("2024",
        # "2024-01") were also rejected by DateTime.new even though the spec
        # permits them; they now parse with missing components defaulted to
        # their earliest value (rendered as a full datetime).
        my %sitemap = :$url;
        if $lastmod.defined {
            my $pair = coerce-lastmod-value($lastmod);
            die "Invalid lastmod '$lastmod' for sitemap '$url': cannot parse as DateTime"
                unless $pair.defined;
            %sitemap<lastmod> = $pair.key;
        }
        @.sitemaps.push: %sitemap;
    }

    method !write-stylesheet-pi($w) {
        my $url = $.xsl-url;
        return unless $url;

        # PI data is emitted literally by LibXML::Writer and is not entity-decoded
        # when re-parsed, so characters that could break out of the processing
        # instruction (or be misread as markup) must be neutralized.
        if $url ~~ / '?>' / {
            die "Refusing to render: xsl-url contains '?>', which is not allowed in an XML processing instruction";
        }
        # Raw & and < are legal inside PI data, and because PI data is never
        # entity-decoded, escaping them to &amp;/&lt; would hand consumers a
        # literal wrong URL (browsers would request "...?v=1&amp;t=2"). Only a
        # real " still terminates the href pseudo-attribute, so it alone is
        # escaped.
        my $safe = $url.subst('"', '&quot;', :g);
        $w.writePI('xml-stylesheet', 'type="text/xsl" href="' ~ $safe ~ '"');
    }

    #| Serialize items to XML. $verbose is threaded through to each item's
    #| write-xml (which used to be configured by mutating $item.verbose, leaving
    #| the caller's item object changed after render — Q7). The optional
    #| :@items-to-use lets write() render chunk slices without a separate path.
    method !render-items(@items-to-use, Bool :$verbose = False --> Str) {
        my $w = LibXML::Writer::Buffer.new;

        $w.startDocument(:version('1.0'), :enc('UTF-8'));

        self!write-stylesheet-pi($w);

        $w.setIndented($.pretty ?? 1 !! 0);

        # Namespace declarations must appear on the <urlset> element before
        # any child <url> elements, so we cannot defer detection to the write
        # pass.  The early-exit limits the first pass to at most a few items.
        my ($need-image, $need-video, $need-news, $need-xhtml, $need-android, $need-amp);
        for @items-to-use -> $item {
            $need-image  ||= $item.images.elems > 0;
            $need-video  ||= $item.videos.first({ .renderable }).defined;
            $need-news   ||= $item.news.elems > 0;
            $need-xhtml  ||= $item.links.elems > 0;
            $need-android ||= $item.android-link.defined && $item.android-link.chars > 0;
            $need-amp    ||= $item.amp-link.defined && $item.amp-link.chars > 0;
            last if $need-image && $need-video && $need-news && $need-xhtml && $need-android && $need-amp;
        }

        $w.startElement('urlset');
        $w.writeAttribute('xmlns', $NAMESPACE);
        $w.writeAttribute('xmlns:image', $IMAGE_NS) if $need-image;
        $w.writeAttribute('xmlns:video', $VIDEO_NS) if $need-video;
        $w.writeAttribute('xmlns:news', $NEWS_NS) if $need-news;
        $w.writeAttribute('xmlns:xhtml', $XHTML_NS) if $need-xhtml;
        $w.writeAttribute('xmlns:android', $ANDROID_NS) if $need-android;
        $w.writeAttribute('xmlns:amp', $AMP_NS) if $need-amp;

        for @items-to-use -> $item {
            $item.write-xml($w, :$verbose);
        }

        $w.endElement;
        $w.endDocument;

        $w.Str;
    }

    method render(--> Str) {
        self!render-items(@.items, :verbose($.verbose));
    }

    method render-index(Str :$base-url = '', Bool :$allow-relative = False --> Str) {
        self!render-index-local(@.sitemaps, :$base-url, :$allow-relative);
    }

    #| Write the sitemap(s) to file(s). Returns the list of written file paths
    #| (the chunk files plus the index file, or the single sitemap file).
    #| A path ending in .xml or .gz is normalized (suffix stripped and
    #| re-appended, so `sitemap.xml`/`sitemap.xml.gz` round-trip unchanged) and
    #| a bare stem gains the format extension (`out` -> `out.xml`); any other
    #| explicit extension is respected verbatim, so `-o out.txt` writes exactly
    #| `out.txt` (matching how the non-xml CLI formats write the given path).
    method write(IO::Path() $path!, :$base-url = '') {
        my $stem = $path.IO.basename;
        my $given-ext = '';
        # .gz is a compression marker, never part of the file name: strip it
        # first so "out.txt.gz" re-applies the real .txt extension (instead of
        # mangling it into "out.txt.xml") and a bare "foo.gz" still yields the
        # default format extension. Case-insensitive, like the .xml handling.
        # When compression is off the caller's filename is taken literally, so
        # a .gz suffix is an ordinary part of the name and must be preserved.
        $stem ~~ s:i/\.gz $// if $.compress;
        if $stem ~~ /^ (.+?) (\. <[a..zA..Z0..9]>+) $/ && $1.lc !~~ '.xml' {
            $given-ext = $1;
            $stem = $stem.substr(0, * - $given-ext.chars);
        }
        # Case-insensitive so SITEMAP.XML normalizes like sitemap.xml. Only a
        # name that resolved to the default extension is re-normalized; when a
        # real extension was captured (e.g. an explicit .gz with compression
        # off) the residual stem (which may itself end in .xml) is kept whole.
        $stem ~~ s:i/\.xml $// unless $given-ext;
        $stem ||= 'sitemap';

        my $extension = $given-ext
            ?? $given-ext ~ ($.compress ?? '.gz' !! '')
            !! ($.compress ?? '.xml.gz' !! '.xml');
        my $dir = $path.IO.dirname;
        my $final-path = $dir.IO.add($stem ~ $extension).Str;

        if @.items.elems > $.max-entries || @.sitemaps.elems > 0 {
            return self!write-multi($path, $stem, $base-url, $extension);
        }

        my $xml = self.render();
        if $.compress {
            gzspurt($final-path, $xml);
        } else {
            $final-path.IO.spurt($xml);
        }
        return ($final-path,);
    }

    method !write-multi(IO::Path() $base-path, Str $stem, Str $base-url, Str $extension) {
        # Chunking: process items one by one, writing chunks as they fill up.
        # write() is always called after all items are added, so @.items is
        # stable here and needs no snapshot copy.
        my @files;
        my @written-paths;
        my $count = 1;
        my @current-chunk;
        my $index = 0;
        # When the items fit in a single chunk there is no need for a -1 suffix:
        # the chunk keeps the plain {stem}.xml name so the index references the
        # same file a single-file write would have produced.
        my $single-chunk = @.items.elems <= $.max-entries;

        while $index < @.items.elems {
            @current-chunk.push: @.items[$index];
            $index++;

            # Write chunk when it reaches max-entries or we're at the end
            if @current-chunk.elems >= $.max-entries || $index >= @.items.elems {
                my $part-name = $single-chunk
                    ?? "{$stem}{$extension}"
                    !! "{$stem}-{$count}{$extension}";
                my $part-path = $base-path.IO.dirname.IO.add($part-name).Str;
                my $xml = self!render-items(@current-chunk, :verbose($.verbose));

                if $.compress {
                    gzspurt($part-path, $xml);
                } else {
                    $part-path.IO.spurt($xml);
                }

                @files.push: { :url($part-name), :lastmod(DateTime.now) };
                @written-paths.push: $part-path;
                @current-chunk = ();
                $count++;
            }
        }

        # Add manually added sitemaps to index (merge with auto-generated)
        my @all-sitemaps = @files;
        for @.sitemaps -> %sitemap {
            @all-sitemaps.push: %sitemap;
        }

        # Write index file sequentially
        my $index-name = "{$stem}-index{$extension}";
        my $index-path = $base-path.IO.dirname.IO.add($index-name).Str;
        # Multi-file writes place the chunk files next to the index, so their
        # relative locs are valid references to siblings (allow-relative).
        my $index-xml = self!render-index-local(@all-sitemaps, :$base-url, :allow-relative(True));
        if $.compress {
            gzspurt($index-path, $index-xml);
        } else {
            $index-path.IO.spurt($index-xml);
        }
        @written-paths.push: $index-path;

        return @written-paths;
    }

    method !render-index-local(Array $sitemaps, Str :$base-url = '', Bool :$allow-relative = False --> Str) {
        my $w = LibXML::Writer::Buffer.new;

        $w.startDocument(:version('1.0'), :enc('UTF-8'));

        self!write-stylesheet-pi($w);

        $w.setIndented($.pretty ?? 1 !! 0);

        $w.startElement('sitemapindex');
        $w.writeAttribute('xmlns', $NAMESPACE);

        for @$sitemaps -> %sitemap {
            $w.startElement('sitemap');
            my $loc = %sitemap<url>;
            # Absolute means "has any scheme://" (checked case-insensitively;
            # starts-with('http') would misread HTTPS://... or ftp://... as
            # relative) or is scheme-relative ("//host/path", which is absolute
            # per RFC 3986 and must not get the base URL prepended — B11).  The
            # scheme spelling follows RFC 3986: an ALPHA followed by any
            # ALPHA/DIGIT/"+"/"-"/".".  A narrower "letters only" class would
            # misread valid non-alpha schemes such as "x-scheme://host" or
            # "web+app://host" as relative and prepend the base URL onto them.
            my $is-absolute = $loc ~~ /^ <[a..zA..Z]> <[a..zA..Z0..9+\-.]>* ':' '//' /
                || $loc ~~ /^ '//' /;
            if $base-url && !$is-absolute {
                my $base = $base-url.subst(/ \/ + $ /, '');
                # Root-relative locs ('/sitemaps/x.xml') carry a leading slash
                # of their own; joining verbatim produced 'https://host//...'
                # (and 'https://host//' for a bare '/'). Trim them first — a
                # loc of '/' alone collapses to exactly '$base/'.
                $loc = $base ~ '/' ~ $loc.subst(/^ \/ +/, '');
            }
            elsif !$allow-relative && !$is-absolute {
                # A sitemap index <loc> must be absolute; a bare relative path
                # would be emitted verbatim and rejected by consumers.
                die "Cannot render sitemap index: relative loc '$loc' needs :base-url to become absolute";
            }
            $w.writeElement('loc', $loc);
            # Never emit an empty <lastmod></lastmod>: a Nil or blank value
            # must be skipped entirely.
            if %sitemap<lastmod>:exists && (%sitemap<lastmod> // '').Str.chars {
                my $lastmod = %sitemap<lastmod>;
                # Index entries follow the same W3CDTF profile as item
                # <lastmod>: whole seconds, no fractional part.
                $w.writeElement('lastmod', $lastmod ~~ DateTime ?? $lastmod.truncated-to('second').Str !! $lastmod.Str);
            }
            $w.endElement;
        }

        $w.endElement;
        $w.endDocument;

        $w.Str;
    }

    method get-items( --> List) {
        @.items.List;
    }

    method item-count( --> Int) {
        @.items.elems;
    }

    method clear() {
        @.items = ();
        @.sitemaps = ();
    }

    method discover-sitemap(Str $base-url, Bool :$ssl-verify = True) {
        my @all = Sitemap::Config::discover-sitemaps($base-url, :$ssl-verify);
        return @all ?? @all[0] !! Nil;
    }

    method discover-sitemaps(Str $base-url, Bool :$ssl-verify = True) {
        Sitemap::Config::discover-sitemaps($base-url, :$ssl-verify).List;
    }
}

=begin pod

=head1 NAME

Sitemap::Builder - Build XML sitemaps

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Builder;

my $builder = Sitemap::Builder.new;
$builder.add-item('https://example.com/page1', :lastmod(DateTime.now), :priority(0.8));
$builder.add-item('https://example.com/page2');

# Get XML string
my $xml = $builder.render;

# Write to file (auto-splits at 50k URLs)
$builder.write: 'sitemap.xml';

=end code

=head1 METHODS

=head2 new(Int :$max-entries, Bool :$compress, Bool :$pretty, Str :$xsl-url)

Create a new Builder. 
- $max-entries sets the maximum URLs per sitemap file (default: 50000).
- $compress enables gzip compression of output files.
- $pretty formats the XML output with line breaks.
- $xsl-url adds an XSL stylesheet reference to the XML output.

=head2 add-item(Str $url, :$lastmod, :$changefreq, :$priority, :$expires, :$title, Str :$android-link, Str :$amp-link, :@images, :@videos, :@links, :@news)

Add a URL to the sitemap. Accepts all Sitemap::Item parameters.
C<images>, C<videos>, C<links>, and C<news> can be passed as named array
arguments holding C<Sitemap::Item::Image>, C<Sitemap::Item::Video>,
C<Sitemap::Item::Link>, or C<Sitemap::Item::News> objects, e.g.
C<add-item($url, images => [...], videos => [...])>.

=head2 add-sitemap(Str $url, :$lastmod)

Add a sitemap to a sitemap index. C<$lastmod> accepts a DateTime or an
ISO-8601/W3CDTF date string.

=head2 render(---> Str)

Render the sitemap as an XML string.

Namespace declarations are only emitted when the output actually uses them:
C<xmlns:image> if any item has images, C<xmlns:video> if any item has videos,
C<xmlns:news> if any item has news items, C<xmlns:xhtml> if any item has hreflang links.

=head2 render-index(Str :$base-url = '', Bool :$allow-relative = False --> Str)

Render a sitemap index as an XML string. C<:allow-relative> (used internally by
the multi-file writer) permits path-relative child URLs instead of requiring
absolute ones.

=head2 write(IO::Path $path, Str :$base-url)

Write the sitemap(s) to file(s). If the number of items exceeds $.max-entries,
multiple files will be created along with a sitemap index.

=head2 get-items( --> List)

Get the list of Sitemap::Items.

=head2 item-count( --> Int)

Get the number of items in the sitemap.

=head2 clear()

Clear all items from the builder.

=head2 discover-sitemap(Str $base-url --> Str)

Discover a sitemap URL from the site's robots.txt file.
Returns the first sitemap URL if found, otherwise returns Nil.
For all URLs (robots.txt may contain multiple Sitemap: lines), use C<discover-sitemaps>.

=head2 discover-sitemaps(Str $base-url --> List)

Discover all sitemap URLs from the site's robots.txt file.
Returns a List of sitemap URLs; the List is empty if none are found
(also empty when robots.txt cannot be fetched or parsed).

=end pod
