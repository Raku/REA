use v6.d;

unit module Sitemap::JsonLd;

use JSON::Fast;

my constant @NEWS-TYPES = <
    NewsArticle ReportageNewsArticle OpinionNewsArticle
    ReviewNewsArticle AnalysisNewsArticle BackgroundNewsArticle
>;

my sub extract-jsonld-blocks(Str $html --> List) {
    my @blocks;
    my regex jsonld-script {
        :i
        '<script' \s* <-[>]>*? <!after '-'> 'type' \s* '=' \s*
            [ '"application/ld+json"' | "'application/ld+json'" | 'application/ld+json' ]
            <-[>]>* '>'
    }
    my $pos = 0;
    while $html ~~ m:c($pos) / <&jsonld-script> / {
        my $content-start = $/.to;
        # Find the </script> that TERMINATES this JSON block, skipping any
        # literal "</script>" that occurs inside a JSON string. JSON strings
        # are double-quoted with backslash escapes, so track string state
        # (a '"' not escaped by an odd count of backslashes ends the string).
        my $i = $content-start;
        my $in-string = False;
        my $found = False;
        while $i < $html.chars {
            my $ch = $html.substr($i, 1);
            if $in-string {
                given $ch {
                    when '\\' { $i += 2; next }
                    when '"'  { $in-string = False }
                }
            }
            elsif $ch eq '"' {
                $in-string = True;
            }
            elsif $html.substr($i, 9).lc eq '</script>' {
                my $content = $html.substr($content-start, $i - $content-start).trim;
                @blocks.push: $content if $content;
                $pos = $i + 9;
                $found = True;
                last;
            }
            $i++;
        }
        # A JSON-LD block with no terminating </script> (malformed HTML) must
        # not swallow the rest of the document; bail out.
        last unless $found;
    }
    @blocks;
}

my sub strip-jsonld-comments(Str $json --> Str) {
    # Strip JS single-line comments (// ...) and HTML comment wrappers
    # (<!-- / -->).  '//' is only a comment when it does NOT appear inside a
    # JSON double-quoted string, so protocol-relative URLs like
    # //cdn.example.com/img.jpg inside a string — or a trailing data slash —
    # are never misread as comments. Comments may start mid-line
    # ("key": v, // explain) or on their own line.
    my $result = '';
    for $json.lines -> $line {
        my $trimmed = $line.trim;
        if $trimmed.starts-with('//') || $trimmed.starts-with('<!--') || $trimmed.starts-with('-->') {
            $result ~= "\n";
            next;
        }
        # Scan for the first '//' that lies OUTSIDE a quoted string and cut
        # the line there. JSON strings cannot span lines, so per-line state is
        # enough; backslash escapes keep a '"' from ending the string early.
        my $s = $line;
        my $pos = $s.chars;
        my $i = 0;
        my $in-string = False;
        while $i < $s.chars {
            my $ch = $s.substr($i, 1);
            if $in-string {
                if $ch eq '\\' { $i += 2; next }
                if $ch eq '"'  { $in-string = False }
            }
            elsif $ch eq '"' {
                $in-string = True;
            }
            elsif $ch eq '/' && $i + 1 < $s.chars && $s.substr($i + 1, 1) eq '/' {
                $pos = $i;
                last;
            }
            $i++;
        }
        $result ~= $s.substr(0, $pos) ~ "\n";
    }
    $result;
}

my sub parse-jsonld(Str $content --> List) {
    my $data;
    try { $data = from-json($content) };
    unless $data.defined {
        try { $data = from-json(strip-jsonld-comments($content)) };
    }
    unless $data.defined {
        return ();
    }

    given $data {
        when Array { $data.list }
        when Hash  { ($data,) }
        default    { () }
    }
}

our sub extract-jsonld(Str $html --> List) is export {
    my @results;
    for extract-jsonld-blocks($html) -> $block {
        @results.push: |parse-jsonld($block);
    }
    @results;
}

my sub matches-type(Str $actual, Str $target --> Bool) {
    $actual eq $target
    || $actual eq "schema:$target"
    || $actual eq "http://schema.org/$target"
    || $actual eq "https://schema.org/$target";
}

# Walk a JSON-LD tree iteratively (explicit stack) so that deeply nested
# documents cannot blow the call stack. Visits nodes in the same order as the
# former recursion: for a Hash, @graph children first, then the node's own
# type check, then nested values.
my sub walk(Mu $node, @target-types, @results) {
    my @stack = ($node,);
    while @stack {
        my $current = @stack.pop;
        given $current {
            when Pair {
                if $current.key eq 'TYPE_CHECK' {
                    my $h = $current.value;
                    my $node-type = $h{'@type'};
                    my @node-types = do given $node-type {
                        when Str   { ($node-type,) }
                        when Array { $node-type.list }
                        default    { () }
                    };

                    if @target-types.grep(-> $target {
                        @node-types.grep(-> $t { matches-type($t, $target) })
                    }) {
                        @results.push: $h;
                    }
                }
            }
            when Hash {
                my $h = $current;
                my @graph = $h{'@graph'} ~~ Array ?? $h{'@graph'}.list !! ();
                my @nested = $h.pairs.grep(-> $p { $p.key ne '@graph' && $p.value ~~ Hash|Array })
                                .map(*.value);

                @stack.push: |@nested.reverse;
                # Deferred type-check: push children first, then a sentinel
                # with the hash reference so the parent is checked after
                # all descendants have been visited.
                @stack.push: Pair.new('TYPE_CHECK', $h);
                @stack.push: |@graph.reverse;
            }
            when Array {
                @stack.push: |$_.list.reverse;
            }
        }
    }
}

our sub find-by-type(List $objects, Str $type --> List) is export {
    my @results;
    walk($_, [$type], @results) for $objects.list;
    @results;
}

my sub find-by-types(List $objects, @types --> List) {
    my @results;
    walk($_, @types, @results) for $objects.list;
    @results;
}

our sub parse-iso8601-duration(Str $duration --> Int) is export {
    # Some publishers write a bare non-negative second count ("90", or a JSON
    # number 90) instead of an ISO-8601 duration string ("PT90S"); accept a
    # plain integer as seconds so the video is not silently given duration 0.
    return +$duration if $duration ~~ /^ \d+ $/;

    return 0 unless $duration ~~ /^ 'P' /;

    # ISO 8601 Y/M in the date part are calendar units with no fixed second
    # value (a month is 28-31 days), so they cannot be converted; a duration
    # using them is rejected as invalid (0) instead of silently dropping the
    # components. Minutes are in the time part (after T) and stay
    # supported.
    return 0 if $duration.split('T', 2)[0] ~~ / <[YM]> /;

    # Durations are non-negative in ISO 8601-1; a sign (P-1D, -P1D, PT-1S) is
    # rejected rather than silently parsed as positive.
    return 0 if $duration ~~ / <[-+]> /;

    my $secs = 0;

    # ISO 8601 allows decimal fractions on any component ("PT1.5H"). Match the
    # fraction together with the unit so "1.5H" is not misread as "5H".
    my sub unit-secs(Str $input, Str $unit, Numeric $factor --> Int) {
        my $m = $input ~~ / (\d+) [ '.' (\d+) ]? $unit / or return 0;
        my $frac = $1.defined ?? (+$1) / (10 ** $1.chars) !! 0;
        ((+$0 + $frac) * $factor).Int;
    }

    if $duration ~~ / 'T' $<time>=(.+) $/ {
        my $t = $<time>.Str;
        $secs += unit-secs($t, 'H', 3600);
        $secs += unit-secs($t, 'M', 60);
        $secs += unit-secs($t, 'S', 1);
    }
    $secs += unit-secs($duration, 'D', 86400);
    # ISO 8601 allows a pure week duration "PnW" (which cannot be combined with
    # other fields). P3W4D must still count the weeks, not just the days.
    $secs += unit-secs($duration, 'W', 604800);
    $secs;
}

#| Extract JSON-LD objects from an HTML string, unless pre-parsed objects are
#| supplied. Callers extracting several object types from the same page (video
#| + news) should parse the HTML once and pass the parsed objects through, so
#| the <script> split and JSON parse happen a single time per page.
sub jsonld-objects(Str $html, $jsonld?) {
    # An omitted argument (undefined Any default) means "not parsed yet" ->
    # parse now. A PROVIDED argument -- even an empty list -- means the
    # caller already ran the per-page JSON-LD parse and found nothing (the
    # documented contract of the optional second parameter). The previous
    # @-sigil parameter could not tell the two apart: an omitted optional
    # Array binds a DEFINED empty array, so the .elems fallback re-split and
    # re-decoded the entire document on every page without structured data.
    # The Scalar capture keeps "omitted" observably undefined across calls
    # that merely forward their own optional argument.
    $jsonld.defined ?? @($jsonld) !! extract-jsonld($html);
}

#| Coerce a JSON-LD media URL value to a single Str.  contentUrl may be a
#| plain string, an array of strings (schema.org allowUrls), or an object
#| with a url/contentUrl key; an array picks the first defined element, and
#| anything else passes through as a Str.
my sub coerce-media-url(Mu $value --> Str) {
    # schema.org polymorphism: a URL string, an array of URL strings, or an
    # ImageObject hash (bare or in an array). A Hash element must contribute
    # its url/contentUrl/name — stringifying the whole hash used to publish
    # Pair junk like "url\thttps://…" as the video's content_loc. Elements
    # that yield nothing are skipped so a later sibling can supply the URL.
    my @items = $value ~~ Array ?? $value.list !! ($value,);
    for @items -> $el {
        next unless $el.defined;
        my $s = $el ~~ Hash
            ?? (($el<url> // $el<contentUrl> // $el<name> // '').Str)
            !! $el.Str;
        return $s if $s.chars;
    }
    '';
}

#| schema.org properties are polymorphic: thumbnailUrl may be one URL, an
#| array of URLs/ImageObjects, or an ImageObject with a url key; publisher
#| may be a string or a list of Organizations.  Reduce any of those shapes to
#| the first usable string so downstream Str-typed attributes cannot crash on
#| legal input.
my sub coerce-media-str($value --> Str) {
    return '' unless $value.defined;
    if $value ~~ Array {
        for @$value -> $el {
            my $s = coerce-media-str($el);
            return $s if $s.chars;
        }
        return '';
    }
    if $value ~~ Hash {
        # The URL-bearing key may itself be an array of URLs (schema.org
        # allowUrls) or a nested object; recurse so a single usable string is
        # returned instead of stringifying the whole array ("a b").
        for <url name contentUrl> -> $k {
            next unless $value{$k}.defined;
            my $s = coerce-media-str($value{$k});
            return $s if $s.chars;
        }
        return '';
    }
    $value.Str;
}

our sub extract-video-objects(Str $html, $jsonld? --> List) is export {
    my @objects = find-by-type(jsonld-objects($html, $jsonld), 'VideoObject');

    # A VideoObject may inline the actual playback asset as a nested object
    # (commonly under video/content/associatedMedia). The nested object is the
    # real media URL and the outer object is just the wrapper; merge the two
    # into ONE record instead of publishing the same video twice. Two passes:
    # classify every object first (its own URL vs the nested media URL it
    # consumes), then emit one record per video and suppress the nested
    # object's twin record.
    my @class = @objects.map: -> %obj {
        my $self-url = coerce-media-url(%obj<contentUrl> // %obj<url> // '');
        my $media = %obj<video> // %obj<content> // %obj<associatedMedia>;
        my $nested-url = '';
        my $nested-id  = '';
        if $media.defined {
            my @media = $media ~~ Array ?? $media.list !! ($media,);
            for @media -> $m {
                next unless $m.defined && $m ~~ Hash;
                $nested-url = coerce-media-url($m<contentUrl> // $m<url> // '');
                $nested-id  = $m<@id> // '';
                last if $nested-url.chars;
            }
        }
        %( obj => %obj, self-url => $self-url, nested-url => $nested-url, nested-id => $nested-id );
    };

    my %consumed-urls;
    my %consumed-ids;
    for @class -> $c {
        %consumed-urls{$c<nested-url>} = True if $c<nested-url>.chars;
        %consumed-ids{$c<nested-id>}   = True if $c<nested-id>.chars;
    }

    my @videos;
    # A node reachable both at the top level and inside @graph (same @id) is
    # one node; the walk visits the @graph copy first, so the first wins.
    my %seen-ids;
    # Two @id-less VideoObjects pointing at the same media URL are also the
    # same video (schema.org often repeats a VideoObject across @graph and the
    # top level, or in an array, without an @id). Dedup on the emitted URL too
    # so those collapse instead of double-publishing in the sitemap.
    my %seen-urls;

    for @class -> $c {
        my %obj = $c<obj>;
        my $self-url   = $c<self-url>;
        my $nested-url = $c<nested-url>;
        my $id = %obj<@id> // '';

        # The object is a nested media twin consumed into an outer wrapper:
        # it has no nested asset of its own and its URL was taken by a
        # parent's video/content/associatedMedia merging above.
        next if $nested-url.chars == 0 && $self-url.chars && %consumed-urls{$self-url};

        my $url = $nested-url.chars ?? $nested-url !! $self-url;
        next unless $url.chars;
        next if $id.chars && %seen-ids{$id};
        %seen-ids{$id} = True if $id.chars;
        next if %seen-urls{$url};
        %seen-urls{$url} = True;

        my $thumbnail  = coerce-media-str(%obj<thumbnailUrl> // %obj<thumbnail> // '');
        my $title      = coerce-media-str(%obj<name> // %obj<headline> // '');
        my $description = coerce-media-str(%obj<description>);
        my $duration    = 0;
        if %obj<duration> -> $d {
            $duration = parse-iso8601-duration($d.Str);
        }
        my $pub-date = %obj<uploadDate> // %obj<datePublished> // '';

        @videos.push: {
            url         => $url,
            thumbnail   => $thumbnail,
            title       => $title,
            description => $description,
            duration    => $duration,
            pub-date    => $pub-date,
        };
    }

    @videos;
}

our sub extract-news-objects(Str $html, $jsonld? --> List) is export {
    my @objects = find-by-types(jsonld-objects($html, $jsonld), @NEWS-TYPES);

    my $cutoff = DateTime.now - Duration.new(172800);
    my @results;
    # Same @id reachable via @graph and at the top level is one node, not two
    # articles (see extract-video-objects).
    my %seen-ids;

    for @objects -> %obj {
        my $id = %obj<@id> // '';
        next if $id.chars && %seen-ids{$id};
        %seen-ids{$id} = True if $id.chars;

        my $title = coerce-media-str(%obj<headline> // %obj<name>);
        next unless $title;

        my $pub-date-str = %obj<datePublished> // '';
        my $pub-date = try DateTime.new($pub-date-str);
        next unless $pub-date ~~ DateTime;

        # Publisher may be a string, an Organization object, or a list of
        # either; inLanguage is often an array of BCP-47 tags.  News
        # sitemaps want exactly one publication name and one language.
        my $pub-name = coerce-media-str(%obj<publisher>);
        next unless $pub-name;

        my $lang = coerce-media-str(%obj<inLanguage>) // '';
        $lang = 'en' unless $lang.chars;

        my $is-stale = $pub-date < $cutoff;

        @results.push: {
            publication      => $pub-name,
            language         => $lang,
            title            => $title,
            publication-date => $pub-date,
            stale            => $is-stale,
        };
    }

    @results;
}

=begin pod

=head1 NAME

Sitemap::JsonLd - Extract structured data from JSON-LD in HTML pages

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::JsonLd;

my @objects = extract-jsonld($html);
my @videos = find-by-type(@objects, 'VideoObject');
my @news = find-by-type(@objects, 'NewsArticle');
my @video-objects = extract-video-objects($html);
my @news-objects = extract-news-objects($html);

=end code

=begin comment
Known limitation: JSON-LD blocks are located by matching an application/ld+json
script tag, then the terminating </script> is found by scanning forward while
tracking JSON string state (so a literal "</script>" inside a string does not
truncate the block). The fragment is then parsed with JSON::Fast. This is fast
and dependency-free, but it is not an HTML parser: script blocks whose markup
deviates from the expected shape can be missed. Best-effort extraction, by
design.
=end comment

=head1 SUBS

=head2 extract-jsonld(Str $html --> List)

Extract all JSON-LD objects from HTML C<< <script type="application/ld+json"> >> blocks.
Returns a flat C<List> of C<Hash> objects. Handles arrays within blocks and strips JS/HTML comments.

=head2 find-by-type(List $objects, Str $type --> List)

Find all objects matching the given type. Supports exact match, C<schema:Type>,
C<http://schema.org/Type>, and C<https://schema.org/Type> prefixes.
Unwraps C<@graph> arrays recursively.

=head2 extract-video-objects(Str $html, $jsonld? --> List)

Extract VideoObject JSON-LD from HTML and return a list of Hashes with:
C<url>, C<thumbnail>, C<title>, C<description>, C<duration> (seconds), C<pub-date>.
Requires C<contentUrl> or C<url>; skips objects without one. An optional second
positional argument of already-parsed JSON-LD objects (see C<extract-jsonld>)
skips re-parsing the HTML; a provided-but-empty list is authoritative and the
document is not scanned.

=head2 extract-news-objects(Str $html, $jsonld? --> List)

Extract news article JSON-LD from HTML. Matches C<NewsArticle> and its named subtypes
(C<ReportageNewsArticle>, C<OpinionNewsArticle>, C<ReviewNewsArticle>,
C<AnalysisNewsArticle>, C<BackgroundNewsArticle>). Does NOT match generic C<Article>
or C<BlogPosting>. An optional second positional argument of already-parsed
JSON-LD objects skips re-parsing the HTML.

Returns a list of Hashes with:
C<publication>, C<language>, C<title>, C<publication-date> (DateTime), C<stale> (Bool).
Articles older than 48 hours are marked C<stale => True>.
Requires C<headline> (or C<name>), valid C<datePublished>, and a publisher.

=head2 parse-iso8601-duration(Str $duration --> Int)

Parse ISO 8601 duration strings (e.g., C<PT1H2M3S>) into seconds.
A bare non-negative integer (C<"90"> or C<90>) is treated as seconds.
Returns C<0> for empty or invalid input.

=end pod
