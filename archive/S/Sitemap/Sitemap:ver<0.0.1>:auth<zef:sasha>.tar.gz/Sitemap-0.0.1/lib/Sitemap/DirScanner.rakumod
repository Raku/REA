use v6.d;

use URI;
use Sitemap::Builder;
use Sitemap::Item;
use Sitemap::Config;
use Sitemap::Grammar::RobotsTxt;
use Sitemap::Grammar::LinkExtract;
use Sitemap::JsonLd;
use Sitemap::Extraction;
use Sitemap::Subscribable;

class Sitemap::DirScanner does Sitemap::Subscribable {
    has Str $.dir is required;
    has Str $.base-url = '';
    has Int $.max-depth = 0;
    has Int $.max-urls = 0;
    has Bool $.extract-images = True;
    has Bool $.extract-hreflang = True;
    has Bool $.extract-videos = False;
    has Bool $.extract-news = False;
    has Bool $.calculate-priority = True;
    has Bool $.verbose = False;
    has Int $.concurrency = 1;
    has Int $.max-images = 1000;
    has Int $.max-videos = 100;

    has Sitemap::Builder $!builder;
    has Sitemap::Builder $!news-builder;
    has %!visited;
    # Authoritative set of final URLs already added to the builder. %!visited is
    # keyed on file paths, and a subdirectory with an index.html can be reached
    # both as a dir task (adds dir/) and via a page link to the index file
    # (maps back to dir/), so the two paths can add the same URL twice. This set
    # keys on the final URL to catch that regardless of task ordering.
    has %!added-urls;
    # Int (not atomicint): all mutations are under $!dedup-lock.
    has Int $!url-count = 0;
    has atomicint $!stale-news-count = 0;
    has Str $!effective-base-url;
    # Lock ordering (never acquire in reverse): channel → dedup → builders
    has Lock $!channel-lock;
    has Lock $!dedup-lock;
    has Lock $!builders-lock;

    submethod TWEAK() {
        $!builder = Sitemap::Builder.new;
        $!news-builder = Sitemap::Builder.new if $!extract-news;
        $!channel-lock = Lock.new;
        $!dedup-lock = Lock.new;
        $!builders-lock = Lock.new;
    }

    # on-add/on-error come from Sitemap::Subscribable; the emit sites write
    # straight to the role-owned suppliers.

    #| Emit a standardised error payload to the on-error subscribers.  The
    #| Crawler already emits Hash payloads {url, status, error}; unifying
    #| DirScanner on the same shape lets a single handler cover both sources.
    method !report-error(Str $url, Str $msg) {
        $!error-supplier.emit({ url => $url, status => 0, error => $msg });
    }

    method news-builder( --> Sitemap::Builder) { $!news-builder }

    method stale-news-count( --> Int) { ⚛$!stale-news-count }

    method urls-found( --> Int) { $!url-count }

    #| Reset per-scan state so a scanner can be re-run: without this, a second
    #| scan() would find every path already marked visited and add nothing.
    method !reset-state {
        %!visited = ();
        %!added-urls = ();
        $!url-count = 0;
        $!stale-news-count ⚛= 0;
        $!builder = Sitemap::Builder.new;
        $!news-builder = Sitemap::Builder.new if $!extract-news;
    }

    method scan( --> Sitemap::Builder) {
        self!reset-state;

        my $dir-io = $.dir.IO;
        unless $dir-io.d {
            self!report-error($.dir, "Directory not found: $.dir");
            return $!builder;
        }

        my $resolved-dir = $dir-io.resolve.Str;

        $!effective-base-url = $.base-url || self!derive-base-url($resolved-dir) || 'file:///';

        my $entry = self!find-entry-point($resolved-dir);
        unless $entry {
            self!report-error($.dir, "No HTML files found in: $.dir");
            return $!builder;
        }

        my @seeds = $entry;
        unless ($entry.IO.basename.lc ~~ /:i ^ 'index' '.' [ 'html' | 'htm' ] $/)
            && $entry.IO.parent.resolve.Str eq $resolved-dir {
            # The root has no index file, so the entry point was a single
            # fallback page. Seed the site-root directory task as well:
            # without it the root URL and every root-level page the fallback
            # does not link to are silently dropped from the sitemap
            # (subdirectories without an index already get this expansion).
            @seeds.push: $resolved-dir;
        }

        if $.concurrency > 1 {
            self!scan-parallel(@seeds, $resolved-dir);
        } else {
            self!scan-sequential(@seeds, $resolved-dir);
        }

        $!done-supplier.emit($!builder.get-items);
        $!builder;
    }

    method !scan-sequential(@seeds, Str $resolved-dir) {
        my @queue;
        for @seeds -> $seed {
            %!visited{$seed} = True;
            @queue.push: [$seed, 0];
        }

        my $head = 0;
        while $head < @queue.elems {
            my ($path, $depth) = @queue[$head];
            $head++;
            # Periodically trim processed entries to reclaim memory.
            # Array elements past $head are still reachable but the
            # trimmed prefix is freed; without this, a deep crawl's
            # queue grows monotonically and every Nil slot stays allocated.
            if $head > 1024 {
                @queue = @queue[$head..*];
                $head = 0;
            }
            # Mirror the parallel path's guard: an unreadable subdirectory makes
            # $dir.dir throw X::IO::Dir in !process-dir, which must abort only
            # that task, not the whole sequential scan.
            my @discovered;
            if try { @discovered = self!process-file($path, $depth, $resolved-dir); True } {
                @queue.append(@discovered);
            } else {
                self!report-error($path, "Error processing $path: {$!.message}");
            }
        }
    }

    method !scan-parallel(@seeds, Str $resolved-dir) {
        my $channel = Channel.new;
        # INVARIANT: $channel must stay unbounded. The workers are both the
        # consumers and the producers (each worker sends its discovered
        # children back onto the same channel), so a bounded channel could
        # let all workers block on send with nobody left to receive -- a
        # deadlock.
        my atomicint $active = 0;

        # Sequential scan pre-marks each seed; do the same here so a page
        # that links to itself (./ or / or index.html) isn't re-queued.
        for @seeds -> $seed {
            %!visited{$seed} = True;

            # Count the seed before it is sent so the worker's terminal
            # decrement can never race ahead of the increment (hygiene:
            # workers are started after this, so ordering is moot today, but
            # increment-first matches the counter's intent and removes any
            # dangling-increment window).
            $active⚛++;
            $channel.send([$seed, 0]);
        }

        my $effective-workers = min($.concurrency, 16);
        my @workers = (^$effective-workers).map: {
            start {
                loop {
                    my $item = try $channel.receive;
                    last unless $item.defined;
                    my ($path, $depth) = @$item;

                    # A failing task must still release its active slot and let
                    # the channel drain: if a worker throws (e.g. an unreadable
                    # subdirectory makes $dir.dir throw X::IO::Dir), the
                    # terminal decrement below would be skipped and the other
                    # workers would block on receive forever (await hangs).
                    my @discovered;
                    if try { @discovered = self!process-file($path, $depth, $resolved-dir); True } {
                        # Send + increment under $!channel-lock so they are
                        # atomic with respect to the decrement + close below.
                        # Without this, a send could race a concurrent close:
                        # the channel is closed while a send is in flight and
                        # the discovered child is permanently lost.
                        $!channel-lock.protect: {
                            for @discovered -> $child {
                                if try { $channel.send($child); True } {
                                    $active⚛++;
                                }
                            }
                        }
                    } else {
                        self!report-error($path, "Error processing $path: {$!.message}");
                    }

                    # Decrement + close under the same lock as the sends so
                    # the close decision is serialised against every increment.
                    $!channel-lock.protect: {
                        if --⚛$active == 0 {
                            try $channel.close;
                        }
                    }
                }
            }
        };

        await @workers;
    }

    method !derive-base-url(Str $resolved-dir --> Str) {
        my $robots-path = IO::Path.new($resolved-dir).child('robots.txt');
        return '' unless $robots-path.f;

        my $content = try decode-text-body($robots-path.slurp(:bin));
        return '' unless $content;

        my $actions = Sitemap::Grammar::RobotsTxt::Actions.new;
        Sitemap::Grammar::RobotsTxt.parse($content, :$actions);
        my @sitemaps = $actions.get-sitemaps;
        return '' unless @sitemaps;

        my $url = @sitemaps[0].Str;
        my $uri = try URI.new($url);
        return '' unless $uri;

        # Absolute sitemap URL: extract scheme + authority directly.
        if $uri.scheme && $uri.host {
            my $authority = ~$uri.authority;
            $authority = $authority.subst(/^ <-[\@]>* \@/, '');
            return $uri.scheme ~ '://' ~ $authority ~ '/';
        }

        # Relative sitemap URL (e.g. "Sitemap: /sitemap.xml"): no host is
        # available, so the best site-root base is the scan directory itself
        # as a file:// URL. The old code resolved the sitemap URL then rebuilt
        # a bare scheme://authority/ pair, which threw away the directory path
        # and collapsed every discovered URL onto the filesystem root file:///
        # (CQ). Return the file:// base of the scan dir so URLs stay rooted at
        # the tree instead.
        return 'file://' ~ $resolved-dir ~ '/';
    }

    method !find-entry-point(Str $resolved-dir) {
        # Prefer index.html, then index.htm
        for 'index.html', 'index.htm' -> $name {
            my $path = IO::Path.new($resolved-dir).child($name);
            if $path.f {
                return $path.resolve.Str;
            }
        }

        # Fallback: first .html file at root level only
        # (BFS traversal discovers nested files naturally). An unreadable
        # entry dir must surface as "no entry point" (Nil), not abort scan()
        # with an uncaught X::IO::Dir. IO::Path.dir makes no ordering
        # guarantee, so sort by basename: which file becomes the entry point
        # (and thus the top-priority URL) must not depend on filesystem
        # readdir order.
        my @entries = try IO::Path.new($resolved-dir).dir.grep(*.f).sort(*.basename.lc);
        for @entries -> $entry {
            if $entry.basename.lc ~~ / \. 'html' $ | \. 'htm' $/ {
                return $entry.resolve.Str;
            }
        }

        return Nil;
    }

    method !process-file(Str $path, Int $depth, Str $resolved-dir --> List) {
        my @discovered;

        my $io = IO::Path.new($path);
        return self!process-dir($io, $depth, $resolved-dir) if $io.d;

        # Same size policy as the HTTP path (read-bounded-body): a multi-GB
        # file in the scanned tree must not be slurped whole per worker.
        if $io.s > max-body-size() {
            self!report-error($path, "Cannot read file: $path exceeds the "
                ~ max-body-size() ~ "-byte body size limit");
            return @discovered;
        }

        my $content = try decode-text-body(IO::Path.new($path).slurp(:bin));
        # A decode failure (slurp/decode threw → Nil) is a real read error.
        # A genuinely empty file decodes to '' — that is not an error: it
        # simply yields no links. Reporting "Cannot read file" for an empty
        # page was misleading and spammed on-error (CQ).
        unless $content.defined {
            self!report-error($path, "Cannot read file: $path");
            return @discovered;
        }

        my $page-url = self!path-to-url($path, $resolved-dir);

        my $skip = $!dedup-lock.protect: {
            if %!added-urls{$page-url}:exists {
                # The same final URL was already added via another file path
                # (e.g. dir task + link to its index.html); skip the duplicate.
                True;
            } elsif $.max-urls && $!url-count >= $.max-urls {
                True;
            } else {
                $!url-count++;
                %!added-urls{$page-url} = True;
                False;
            }
        }
        return @discovered if $skip;

        # Scan the page once for every tag type the rest of this method needs:
        # anchor bodies (href discovery), meta bodies (images/videos), link
        # bodies (hreflang), img/source/video bodies (image/video extraction)
        # and base bodies (<base href>) come from a single pass instead of one
        # full-page scan per consumer.
        # The default @PAGE-SCAN-TAGS set covers every tag this method needs
        # (a, meta, link, img, source, video, base) and compares equal to the
        # constant (via .List, see extract-tag-bodies), so the precompiled
        # $PAGE-SCAN-RX fast path is used.
        my %tag-bodies = Sitemap::Grammar::LinkExtract::extract-tag-bodies($content);
        my @links = Sitemap::Grammar::LinkExtract::extract-hrefs-from-bodies(%tag-bodies<a>.list);

        # Relative asset URLs (images/hreflang/videos) resolve against the
        # page's <base href> per the HTML spec, when it is an http(s) URL.
        # Link discovery stays filesystem-based, so a local page pointing at an
        # external base never drags the scan off the local tree. The <base>
        # bodies come from the shared scan above, so no second pass. The shared
        # per-page asset pipeline (same code path as the Crawler) reuses the
        # tag-body scan and returns the once-per-page JSON-LD parse for news.
        my %assets = Sitemap::Extraction::extract-page-assets($content, $page-url,
            :%tag-bodies,
            :$.extract-images, :$.extract-hreflang, :$.extract-videos, :$.extract-news,
            :$.max-images, :$.max-videos);
        # Hash values are itemized containers, so slip (|) each out to flatten
        # it into the @ variable — without it `@images` would hold one element
        # that is the whole Array, and Builder.add-item would reject it.
        my @images = |%assets<images>;
        my @hreflang-links = |%assets<links>;
        my @videos = |%assets<videos>;
        my @jsonld = |%assets<jsonld>;

        my @news;
        if $.extract-news && $!news-builder {
            for extract-news-objects($content, @jsonld) -> %n {
                if %n<stale> {
                    $!stale-news-count⚛++;
                    # Same structured on-error payload the Crawler emits for
                    # stale news, so a shared handler sees both; the note is
                    # additionally gated behind verbose like every other
                    # diagnostic here.
                    self!report-error($path, "NewsArticle '{%n<title>}' in $path is older than 48 hours, skipping");
                    note "Warning: NewsArticle '{%n<title>}' in $path is older than 48 hours, skipping" if $.verbose;
                    next;
                }
                @news.push: Sitemap::Item::News.new(
                    publication => %n<publication>,
                    publication-language => %n<language>,
                    title => %n<title>,
                    publication-date => %n<publication-date>,
                );
            }

            if @news.elems > 0 {
                $!builders-lock.protect: { $!news-builder.add-item($page-url, news => @news) };
            }
        }

        my $priority;
        if $.calculate-priority {
            $priority = calculate-priority($depth);
        }

        $!builders-lock.protect: {
            $!builder.add-item($page-url,
                images => @images,
                videos => @videos,
                links => @hreflang-links,
                |($priority.defined ?? (priority => $priority) !! ()),
            );
        }

        # The callback runs after the lock is released (like the Crawler's
        # on-add): a handler that re-enters the scanner must not deadlock.
        $!add-supplier.emit($page-url);

        for @links -> $link {
            my @new = self!resolve-and-queue($link, $path, $depth, $resolved-dir);
            @discovered.append(@new);
        }

        # The root's index file is the scan's entry point; expand the
        # containing directory just like !process-dir does for every
        # subdirectory-with-an-index, so root-level pages the index does not
        # link to are not silently lost. Subdirectories re-enter through
        # normal link resolution: a directory with an index enqueues only its
        # index file (siblings stay at the next depth, matching a plain page
        # link), while an index-less directory enqueues as an expansion task.
        if $io.basename.lc ~~ /:i ^ 'index' '.' [ 'html' | 'htm' ] $/
            && $io.parent.resolve.Str eq $resolved-dir {
            for $resolved-dir.IO.dir.sort(*.basename.lc) -> $child {
                next if $child.basename.lc ~~ /:i ^ 'index' '.' [ 'html' | 'htm' ] $/;
                # Only sibling files and subdirectories that have an index are
                # swept in. An index-less subdirectory stays reachable only via
                # a link: expanding it here would add every asset subdirectory
                # (e.g. images/) as a bare directory URL.
                next if $child.d
                    && !($child.child('index.html').f || $child.child('index.htm').f);
                my $ref = $child.d ?? $child.basename ~ '/' !! $child.basename;
                @discovered.append(self!resolve-and-queue($ref, $path, $depth, $resolved-dir));
            }
        }

        @discovered;
    }

    #| Process a directory task (a directory without index.html/index.htm).
    #| Adds the directory URL itself (subject to the max-urls cap, unlike the
    #| old unconditional terminal-dir add) and expands it: enqueues its
    #| .html/.htm children and subdirectories so their pages get crawled too.
    method !process-dir(IO::Path $dir, Int $depth, Str $resolved-dir --> List) {
        my @discovered;

        my $dir-url = self!dir-to-url($dir, $resolved-dir);

        my $added = $!dedup-lock.protect: {
            if %!added-urls{$dir-url}:exists {
                # Already added via a page link to this directory's index.html
                # (which maps back to the same dir/ URL). Skip the duplicate.
                False;
            } elsif $.max-urls && $!url-count >= $.max-urls {
                False;
            } else {
                $!url-count++;
                %!added-urls{$dir-url} = True;
                True;
            }
        };
        if $added {
            $!builders-lock.protect: { $!builder.add-item($dir-url) };
        }
        return @discovered unless $added;

        # Callback outside the lock (see !process-file).
        $!add-supplier.emit($dir-url);

        # IO::Path.dir makes no ordering guarantee; sort like the entry-point
        # fallback so which URLs fill a tight max-urls cap (and add order)
        # cannot depend on filesystem readdir order.
        for $dir.dir.sort(*.basename.lc) -> $entry {
            my $child-depth = $depth + 1;
            next if $.max-depth > 0 && $child-depth > $.max-depth;

            my @children;
            if $entry.d {
                my $index = $entry.child('index.html');
                my $index-h = $entry.child('index.htm');
                if $index.f || $index-h.f {
                    # A subdirectory with an index.html/index.htm must be
                    # crawled as its index FILE, not as a bare directory task:
                    # only the file path runs full page extraction
                    # (images/videos/hreflang/priority), while a directory task
                    # adds the dir/ URL with no metadata. Which discovery path
                    # wins used to depend on scan order, silently losing the
                    # metadata. Mirroring !resolve-and-queue's dir handling
                    # keeps both paths identical. The index page's links find
                    # its siblings; the non-index children are enqueued
                    # explicitly so pages the index does not link to are not
                    # lost by switching from dir-task expansion to the file.
                    @children.push: $index.f ?? $index !! $index-h;
                    for $entry.dir.sort(*.basename.lc) -> $grandchild {
                        next unless $grandchild.f && $grandchild.extension.lc ~~ / ^ 'html' $ | ^ 'htm' $/;
                        next if $grandchild.basename.lc ~~ /:i ^ 'index' '.' [ 'html' | 'htm' ] $/;
                        @children.push: $grandchild;
                    }
                } else {
                    # No index: not a terminal URL. The directory task adds the
                    # dir/ URL and expands into its children.
                    @children.push: $entry;
                }
            } elsif $entry.f && $entry.extension.lc ~~ / ^ 'html' $ | ^ 'htm' $/ {
                # An index file of THIS directory maps back to the dir URL
                # already added above; mark it visited so a later link to this
                # directory (or to the index file itself) cannot re-add it.
                if $entry.basename.lc ~~ /:i ^ 'index' '.' [ 'html' | 'htm' ] $/ {
                    $!dedup-lock.protect: { %!visited{$entry.resolve.Str} = True };
                    next;
                }
                @children.push: $entry;
            }

            for @children -> $child {
                my $child-resolved = $child.resolve.Str;
                my $rel = IO::Path.new($child-resolved).relative(IO::Path.new($resolved-dir));
                next if $rel ~~ /^ '..' [ '/' | $ ]/;
                my $seen = $!dedup-lock.protect: {
                    if %!visited{$child-resolved}:exists {
                        True;
                    } else {
                        %!visited{$child-resolved} = True;
                        False;
                    }
                };
                next if $seen;
                @discovered.push: [$child-resolved, $child-depth];
            }
        }

        @discovered;
    }

    method !resolve-and-queue(Str $link, Str $current-file, Int $depth, Str $resolved-dir --> List) {
        my @discovered;

        return @discovered if $link ~~ m/^ :i [ 'http://' | 'https://' | 'javascript:' | 'mailto:' | 'tel:' | 'data:' ] /;
        return @discovered if $link ~~ /^ '#' /;

        my $clean-link = $link.subst(/\/+$/, '').subst(/ [ '#' | '?' ] \N* $/, '');
        # A bare root-relative "/" (or "/#frag", "/?q") loses its leading
        # slash to the trailing-slash strip above and would fall into the
        # relative-file branch, resolving against the current page instead of
        # the site root. Put it back so it still means the root directory.
        $clean-link = '/' if $clean-link eq '' && $link ~~ /^ '/' /;
        my $candidate;

        if $clean-link ~~ /^ '/' / {
            $candidate = IO::Path.new($resolved-dir).child($clean-link.subst(/^\//, ''));
        } else {
            $candidate = IO::Path.new($current-file).parent.child($clean-link);
        }

        my $resolved = try $candidate.resolve;
        unless $resolved {
            self!report-error($link, "Cannot resolve link: $link from $current-file");
            return @discovered;
        }

        my $resolved-str = $resolved.Str;

        # Reject anything that resolves outside the scan root (starts-with has
        # a prefix-collision bug: /root/dir2 would match /root/dir)
        my $rel = $resolved.relative(IO::Path.new($resolved-dir));
        if $rel ~~ /^ '..' [ '/' | $ ]/ {
            self!report-error($link, "Symlink escapes root: $link");
            return @discovered;
        }

        # Classify the target and decide depth eligibility BEFORE the dedup
        # mark. Marking first used to poison the visited-set: with parallel
        # workers (concurrency > 1), a deep discovery could mark a target,
        # then bail on max-depth — and the later, shallower discovery of the
        # same target would see it as visited and never enqueue it, silently
        # dropping the URL from the sitemap. Serial BFS never noticed because
        # the first (shallowest) discovery always won. Same bug class as the
        # Crawler's "max-depth check runs BEFORE mark" fix.
        my $is-dir-link = $link.ends-with('/');
        my $child-depth = $depth + 1;
        my $wants-dir = $resolved.d || $is-dir-link;
        my $ext = $resolved.f ?? $resolved.extension.lc !! '';
        my $wants-page = !$wants-dir && $resolved.f && ($ext eq 'html' || $ext eq 'htm');

        return @discovered unless $wants-dir || $wants-page;
        return @discovered if $.max-depth > 0 && $child-depth > $.max-depth;

        # For directories, resolve index files BEFORE the dedup lock so
        # filesystem I/O (child, .f, .resolve) stays outside the critical
        # section. All three visited-set operations then happen in one
        # lock acquisition to avoid contention.
        my $index-resolved;
        if $wants-dir {
            my $index-html = $resolved.child('index.html');
            my $index-h = $resolved.child('index.htm');
            if $index-html.f {
                $index-resolved = $index-html.resolve.Str;
            }
            elsif $index-h.f {
                $index-resolved = $index-h.resolve.Str;
            }
        }

        $!dedup-lock.protect: {
            return @discovered if %!visited{$resolved-str}:exists;
            %!visited{$resolved-str} = True;
            if $index-resolved.defined {
                return @discovered if %!visited{$index-resolved}:exists;
                %!visited{$index-resolved} = True;
            }
        }

        if $index-resolved.defined {
            @discovered.push: [$index-resolved, $child-depth];
        } elsif $wants-dir {
            # No index.html/index.htm: this is not a terminal URL. Enqueue
            # the directory itself as a task so !process-dir can add the
            # directory URL (respecting the max-urls cap) and expand it —
            # crawling its .html/.htm children and subdirectories.
            @discovered.push: [$resolved-str, $child-depth];
        }
        else {
            @discovered.push: [$resolved-str, $child-depth];
        }

        @discovered;
    }

    method !path-to-url(Str $path, Str $resolved-dir --> Str) {
        my $rel = self!normalize-relative($path, $resolved-dir);
        my $path-io = IO::Path.new($rel);

        # Handle index files → directory URL with trailing slash
        my $basename = $path-io.basename.lc;
        if $basename eq 'index.html' || $basename eq 'index.htm' {
            # Keep directory path, add trailing slash
            $rel = $path-io.dirname;
            $rel = '' if $rel eq '.';  # Root directory
            $rel ~= '/' if $rel;
        }

        return self!join-base($rel);
    }

    method !dir-to-url(IO::Path $dir-path, Str $resolved-dir --> Str) {
        my $rel = self!normalize-relative($dir-path.Str, $resolved-dir);
        # The scan root normalizes to '.'; map it to the empty path so the join
        # yields "$base/" instead of the literal "$base/./".
        $rel = '' if $rel eq '.';
        $rel ~= '/' unless $rel.ends-with('/');
        return self!join-base($rel);
    }

    method !normalize-relative(Str $path, Str $resolved-dir --> Str) {
        my $rel = IO::Path.new($path).relative($resolved-dir);

        # Normalize separators to forward slashes
        $rel = $rel.subst(/ '\\'+ /, '/');

        # Remove leading slash if present
        $rel = $rel.subst(/^\//, '');

        return $rel;
    }

    method !join-base(Str $rel --> Str) {
        my $base = $!effective-base-url.subst(/\/$/, '');
        my $path = $rel.subst(/^\//, '');

        if $path {
            return "$base/$path";
        } else {
            return "$base/";
        }
    }
}

our sub scan-dir(Str $dir, Str :$base-url = '', Int :$max-depth = 0,
    Int :$max-urls = 0, Bool :$extract-images = True,
    Bool :$extract-hreflang = True, Bool :$extract-videos = False,
    Bool :$extract-news = False,
    Bool :$calculate-priority = True,
    Int :$concurrency = 1,
    Int :$max-images = 1000,
    Int :$max-videos = 100,
    Bool :$verbose = False --> Hash) is export
{
    my $scanner = Sitemap::DirScanner.new(
        :$dir, :$base-url, :$max-depth, :$max-urls,
        :$extract-images, :$extract-hreflang, :$extract-videos, :$extract-news,
        :$calculate-priority, :$concurrency, :$max-images, :$max-videos, :$verbose,
    );
    my $builder = $scanner.scan;
    %(
        builder => $builder,
        news-builder => $scanner.news-builder,
        stale-news-count => $scanner.stale-news-count,
    );
}

=begin pod

=head1 NAME

Sitemap::DirScanner - Crawl local directory to discover URLs

=head1 SYNOPSIS

    use Sitemap::DirScanner;

    my %result = scan-dir('./my-site',
        :base-url<https://example.com>,
        :max-depth(3),
        :extract-news,
        :verbose,
    );
    my $builder       = %result<builder>;
    my $news-builder  = %result<news-builder>;

    $builder.write: 'sitemap.xml';
    $news-builder.write: 'sitemap-news.xml' if $news-builder;

=head1 METHODS

=head2 new(Str :$dir!, Str :$base-url, Int :$max-depth, Int :$max-urls, Bool :$extract-images, Bool :$extract-hreflang, Bool :$extract-videos, Bool :$extract-news, Bool :$calculate-priority, Bool :$verbose, Int :$concurrency, Int :$max-images, Int :$max-videos)

Create a new directory scanner. C<$dir> is required. Base URL is
auto-detected from robots.txt, falling back to C<file:///>.

=head2 on-add(&code)

Register a callback for when a URL is discovered.

=head2 on-error(&code)

Register a callback for errors.

=head2 on-done(&code)

Register a callback invoked once with the discovered items when the scan
completes successfully (not fired for early error returns).

=head2 news-builder( --> Sitemap::Builder)

Returns the news sitemap builder, or C<Nil> if C<extract-news> was not enabled.

=head2 stale-news-count( --> Int)

Returns the number of stale (older than 48h) news articles detected.

=head2 urls-found( --> Int)

Returns the number of URLs added to the builder by the scan.

=head2 scan( --> Sitemap::Builder)

Scan the directory tree and return the builder with all discovered URLs.

=head1 SUBS

=head2 scan-dir(Str $dir, Str :$base-url, Int :$max-depth, Int :$max-urls, Bool :$extract-images, Bool :$extract-hreflang, Bool :$extract-videos, Bool :$extract-news, Bool :$calculate-priority, Int :$concurrency, Int :$max-images, Int :$max-videos, Bool :$verbose --> Hash)

Convenience function that creates a scanner, runs the scan, and returns a
Hash with keys C<builder>, C<news-builder>, and C<stale-news-count>.
C<news-builder> is C<Nil> if C<extract-news> was not enabled.

=end pod
