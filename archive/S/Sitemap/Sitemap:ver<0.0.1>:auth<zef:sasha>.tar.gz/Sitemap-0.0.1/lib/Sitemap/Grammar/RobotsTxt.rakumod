use v6.d;

grammar Sitemap::Grammar::RobotsTxt {
    token TOP {
        # A UTF-8 BOM before the first directive must not push that line into
        # the catch-all branch below: the line's rules would then attach to
        # the implicit '*' group (e.g. one site's "Disallow: /" would block
        # every crawler).
        \x[FEFF]?
        <entry>*
    }

    token entry {
        || <user-agent>
        || <disallow>
        || <allow>
        || <crawl-delay>
        || <sitemap>
        || <comment>
        || \r? \n
        # Catch-all for any other line: real-world robots.txt files carry
        # directives the RFC does not standardize (Clean-param, Host,
        # Request-rate, Visit-time, site-maps, ...) and stray indentation.
        # Without this, one such line failed the whole parse and the Crawler
        # silently fell back to allow-all for the origin, discarding both its
        # rules and its Sitemap entries. Ordered (||) so a real directive
        # always wins; \N+ guarantees forward progress at EOF/blank lines.
        || \N+ \r? \n?
    }

    token comment {
        '#' <-[\r\n]>* \r? \n?
    }

    # Trailing horizontal whitespace, an optional inline comment ("# ..."),
    # and the newline that end a directive line. Inline comments must not
    # abort the parse (an unparsed trailing comment used to silently drop
    # every rule in the file).
    token line-end {
        \h* [ '#' <-[\r\n]>* ]? \r? \n?
    }

    token user-agent {
        # \S* rather than \S+ so an empty "User-agent:" directive is not
        # treated as a parse error that silently discards every rule that
        # follows; the actions layer maps an empty value to '*'.
        # The value class also excludes '#' so an inline comment is never
        # captured into the user-agent name.
        :i 'User-agent:' \h* $<value>=[<-[\s#]>*] <line-end>
    }

    token disallow {
        :i 'Disallow:' \h* $<value>=[<-[\r\n#]>*] <line-end>
    }

    token allow {
        :i 'Allow:' \h* $<value>=[<-[\r\n#]>*] <line-end>
    }

    token crawl-delay {
        :i 'Crawl-delay:' \h* $<value>=[<[\d.]>]* <line-end>
    }

    token sitemap {
        :i 'Sitemap:' \h* $<value>=[<-[\s#]>*] <line-end>
    }
}

class UARules {
    has @.allows;
    has @.disallows;
    has $.crawl-delay is rw = Nil;
}

class Sitemap::Grammar::RobotsTxt::Actions {
    # Note: This class is designed for single-use parsing. Each call to
    # .parse creates a new TOP match, and the action method completely
    # replaces %!rules. Do not reuse the same Actions object for
    # multiple parse calls expecting independent results.
    has Str @.sitemaps;
    has %!rules;
    # Memoization for !ua-rules-for: one allowed()/get-crawl-delay call per
    # fetched URL would otherwise re-run the prefix scan every time. Cleared
    # whenever %!rules is replaced (TOP), matching the documented
    # one-parse-per-Actions-object contract.
    has %!ua-lookup;
    has Str $!current-user-agent = '*';

    method TOP($/) {
        $!current-user-agent = '*';
        my @entries = $<entry>.list;
        my %ua-rules;

        for @entries -> $entry {
            if $entry<user-agent> {
                # An empty "User-agent:" value means the wildcard.
                $!current-user-agent = $entry<user-agent><value>.Str.lc;
                $!current-user-agent = '*' unless $!current-user-agent.chars;
                %ua-rules{$!current-user-agent} //= UARules.new;
            }
            elsif $entry<disallow> {
                %ua-rules{$!current-user-agent} //= UARules.new;
                my $path = $entry<disallow><value>.Str.trim;
                %ua-rules{$!current-user-agent}.disallows.push: $path if $path;
            }
            elsif $entry<allow> {
                %ua-rules{$!current-user-agent} //= UARules.new;
                my $path = $entry<allow><value>.Str.trim;
                %ua-rules{$!current-user-agent}.allows.push: $path if $path;
            }
            elsif $entry<crawl-delay> {
                %ua-rules{$!current-user-agent} //= UARules.new;
                my $delay = try $entry<crawl-delay><value>.Str.Num;
                %ua-rules{$!current-user-agent}.crawl-delay = $delay if $delay.defined;
            }
            elsif $entry<sitemap> {
                my $sitemap = $entry<sitemap><value>.Str;
                @.sitemaps.push: $sitemap if $sitemap.chars;
            }
        }

        self!propagate-default-rules(%ua-rules);
        %!rules = %ua-rules;
        %!ua-lookup = ();
    }

    # Per RFC 9309: specific user-agent rules take precedence over wildcard.
    # Only propagate * rules into UAs that have no rules of their own.
    method !propagate-default-rules(%ua-rules) {
        if %ua-rules{'*'}:exists {
            my $default = %ua-rules{'*'};
            for %ua-rules.keys -> $ua {
                next if $ua eq '*';
                my $has-own-rules = %ua-rules{$ua}.allows || %ua-rules{$ua}.disallows;
                unless $has-own-rules {
                    %ua-rules{$ua}.allows.push: |$default.allows;
                    %ua-rules{$ua}.disallows.push: |$default.disallows;
                }
                %ua-rules{$ua}.crawl-delay //= $default.crawl-delay;
            }
        }
    }

    #| Resolve the rule group for a crawler user-agent. Site owners write
    #| the bare product token ('raku-sitemap') while we send a full UA string
    #| ('Raku-Sitemap/0.0.1'); an exact-key-only lookup silently ignored every
    #| site's bot-specific rules and fell back to '*'. RFC 9309 §2.2.1:
    #| match the product token, ignoring any version suffix, preferring the
    #| most specific (longest) matching group before falling back to '*'.
    method !ua-rules-for(Str $user-agent) {
        # A missing group caches an empty UARules (same observable behavior
        # as Nil downstream: no rules → allowed; crawl-delay → Nil).
        if %!ua-lookup{$user-agent}:exists {
            my $cached = %!ua-lookup{$user-agent};
            return $cached;
        }
        my $full = $user-agent.lc.trim;
        my $resolved = %!rules{$full};
        unless $resolved.defined {
            my $token = ($full.split('/')[0] // '').trim;
            $resolved = %!rules{$token} if $token.chars && (%!rules{$token}:exists);
            unless $resolved.defined {
                my @prefixes = %!rules.keys.grep({ $_ ne '*' && $_.chars && $token.starts-with($_) })
                    .sort({ $^b.chars <=> $^a.chars });
                $resolved = @prefixes.elems ?? %!rules{@prefixes[0]} !! %!rules{'*'};
            }
        }
        $resolved //= UARules.new;
        %!ua-lookup{$user-agent} = $resolved;
        $resolved;
    }
    method allowed(Str $url, Str $user-agent = '*' --> Bool) {
        my $path = '/';

        # RFC 9309 compares patterns against path *plus query*: a rule like
        # "Disallow: /search?q=" can never match if the candidate path is
        # truncated at '?'.  Strip only the fragment; keep the query.
        # For bare-domain URLs like http://example.com?q=test the query
        # arrives without a leading slash, so the optional group must also
        # capture '?' to avoid losing the query entirely.
        # 'http'/'https' scheme is case-insensitive per RFC 3986, so ':i'
        # matches HTTP:// / HTTPS:// too; otherwise an uppercase-scheme URL
        # fell through to the default path '/' and silently bypassed rules
        # (CQ). The captured path itself keeps original case.
        if $url ~~ m/ :i 'http' 's'? '://' <-[/?#]>+ ( '/' <-[#]>* | '?' <-[#]>* )? / {
            my $captured = $0 ?? ~$0 !! '';
            $path = $captured.starts-with('/') ?? $captured
                !! $captured.chars ?? '/' ~ $captured
                !! '/';
        }

        my $ua-rules = self!ua-rules-for($user-agent);
        return True unless $ua-rules;

        my @allows = $ua-rules.allows;
        my @disallows = $ua-rules.disallows;

        return True unless @allows || @disallows;

        # RFC 9309 §2.2.2: the most specific rule wins — the one that matched
        # the most path octets; on a tie the disallow rule takes precedence.
        # Track the best match length for each type instead of allocating a
        # hash per pattern, then compare directly.
        my $best-allow-len = -1;
        for @allows -> $pattern {
            next unless $pattern.defined && $pattern.chars;
            my $length = self!match-path($path, $pattern);
            $best-allow-len = $length if $length.defined && $length > $best-allow-len;
        }
        my $best-disallow-len = -1;
        for @disallows -> $pattern {
            next unless $pattern.defined && $pattern.chars;
            my $length = self!match-path($path, $pattern);
            $best-disallow-len = $length if $length.defined && $length > $best-disallow-len;
        }

        return True unless $best-allow-len >= 0 || $best-disallow-len >= 0;

        # Disallow wins ties (same match length → disallow takes precedence).
        return $best-allow-len > $best-disallow-len;
    }

    #| Match a URL path against a robots.txt pattern, returning the number of
    #| path octets the rule matched (RFC 9309 §2.2.2 specificity) or Nil on no
    #| match. A leading '*' splits into an empty first part, which has no
    #| effect on $pos (index of '' at position 0 returns 0). This correctly
    #| implements RFC 9309 unanchored matching for leading wildcards. The
    #| matched length is the end of the match: a trailing '*' (or a '$' end
    #| anchor, which requires the match to reach the end of the path anyway)
    #| consumes through the end of the path, so "Allow: /foo*" on "/foobarxyz"
    #| matches 9 octets and beats "Disallow: /foobar" (7) — the pattern length
    #| is irrelevant (E1).
    method !match-path(Str $path, Str $pattern --> Int) {
        return $path.chars if $pattern eq '';
        return 1 if $pattern eq '/';

        my $end-anchor = $pattern.ends-with('$');
        my $pat = $end-anchor ?? $pattern.chop !! $pattern;

        my @parts = $pat.split('*');
        # RFC 9309 §2.2.2: matching begins at the first path octet unless the
        # pattern starts with '*', so without a leading wildcard the first
        # literal part must sit at position 0 (a "Disallow: /admin" must not
        # also block "/x/admin").
        my $anchored = !$pattern.starts-with('*');
        my $pos = 0;
        for @parts.kv -> $i, $part {
            my $found = $path.index($part, $pos);
            return Nil unless $found.defined;
            return Nil if $anchored && $i == 0 && $found != 0;
            $pos = $found + $part.chars;
        }
        return Nil if $end-anchor && $pos != $path.chars;
        $end-anchor ?? $path.chars
                  !! ($pat.ends-with('*') ?? $path.chars !! $pos);
    }

    method get-crawl-delay(Str $user-agent = '*' --> Numeric) {
        # Same group-resolution as allowed(): exact key → product token with
        # version suffix stripped → longest-prefix group → '*'. The old
        # exact-key lookup meant a site's bot-specific Crawl-delay was
        # invisible to our own versioned UA while allowed() honored it.
        my $ua-rules = self!ua-rules-for($user-agent);
        $ua-rules ?? ($ua-rules.crawl-delay // Nil) !! Nil;
    }

    method get-sitemaps( --> List) {
        @.sitemaps.List;
    }
}

=begin pod

=head1 NAME

Sitemap::Grammar::RobotsTxt - Grammar for parsing robots.txt files

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Grammar::RobotsTxt;

my $actions = Sitemap::Grammar::RobotsTxt::Actions.new;
Sitemap::Grammar::RobotsTxt.parse($robots-txt-content, :actions($actions));

# Check if a URL is allowed
say $actions.allowed('https://example.com/page', 'MyBot');

# Get sitemap URLs from robots.txt
my @sitemaps = $actions.get-sitemaps;

=end code

=head1 DESCRIPTION

The C<RobotsTxt> grammar tokenizes a robots.txt body, and the actions it
drives are collected on the C<Sitemap::Grammar::RobotsTxt::Actions> class.
Only a L<C<parse>|#Grammar> invocation combined with C<:actions> produces
anything useful; the grammar itself exposes no query methods.

=head1 GRAMMAR

=head2 parse(Str $content, :$actions)

Parse robots.txt content into a C<Match>. Pass a freshly created
C<RobotsTxt::Actions> object via C<:actions> to collect the parsed rules.
Unknown or non-standard directives (C<Clean-param:>, C<Host:>, indented
lines, ...) are skipped rather than failing the parse.

=head1 ACTIONS

=head2 allowed(Str $url, Str $user-agent = '*' --> Bool)

Check if a URL is allowed for the given user agent.

=head2 get-crawl-delay(Str $user-agent = '*' --> Numeric)

Get the crawl delay for the given user agent.

=head2 get-sitemaps( --> List)

Get the list of sitemap URLs found in robots.txt.

Note that an C<Actions> object is single-use: it accumulates rules for one
parse call and must not be reused for a second, independent parse.

=end pod
