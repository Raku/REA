use v6.d;

use URI;
use Sitemap::Config;
use Syndicate::Utils;

module Sitemap::Grammar::LinkExtract {

    #| Remove content that must never contribute tags: HTML comments and the
    #| bodies of <script>/<style> elements. A commented-out <a href=...> or a
    #| JS string that happens to contain markup must not be extracted as a real
    #| link, and <script> bodies frequently embed angle brackets that the tag
    #| scanner would otherwise misread. Script/style bodies and comments are
    #| stripped in a single forward pass (index-based) to avoid scanning the
    #| full HTML string three times. Script/style bodies are matched before
    #| comments because a script body may contain "<!--" (e.g. the classic JS
    #| comment-guard) which is not an HTML comment there. Best-effort by
    #| design: an unterminated <script> or <!-- leaves its content in place.
    #| Find the next real '<'~$name start tag at or after $from, rejecting one
    #| whose name merely begins with $name such as <scriptx> or <stylesheet>:
    #| the character right after '<'~$name must not be a word char or '-'
    #| (the same boundary guard as $PAGE-SCAN-RX's <!before <[\w\-]>>). index()
    #| cannot do lookahead, so advance past each false hit; the forward-only
    #| scan keeps the whole pass O(L).
    my sub next-ignorable-tag(Str $low, Str $name, Int $from) {
        my $needle = '<' ~ $name;
        my $hit = $low.index($needle, $from);
        while $hit.defined {
            my $after = $hit + $needle.chars;
            my $boundary-ok = $after >= $low.chars
                || $low.substr($after, 1) !~~ /<[\w\-]>/;
            return $hit if $boundary-ok;
            $hit = $low.index($needle, $after);
        }
        $hit;
    }
    my sub strip-ignorable(Str $html --> Str) {
        # Lowercase the whole document once: downstream index() calls on the
        # lowercased copy only scan from the current offset, so the cost is
        # O(L) overall instead of re-lowercasing the entire remaining suffix
        # per region (which is O(k·L) for k regions).
        my $low = lc($html);
        my @parts;
        my $pos = 0;
        my $len = $html.chars;
        while $pos < $len {
            # Find the earliest ignorable region start.  index() is a native
            # C call and vastly faster than s:g/ with .*? backtracking.
            # index() cannot express the tag-name boundary, so <script>/<style>
            # go through next-ignorable-tag (which only counts a real tag name,
            # not <scriptx>/<stylesheet>); '<!--' needs no boundary.
            my $script-i = next-ignorable-tag($low, 'script', $pos);
            my $style-i  = next-ignorable-tag($low, 'style', $pos);
            my $comment-i = $low.index('<!--', $pos);

            # Pick the earliest start among the three candidates (Nil → ∞).
            my $next-start = $len;
            my $kind = '';
            for ($script-i, '<script'), ($style-i, '<style'), ($comment-i, '<!--') -> ($i, $k) {
                if $i.defined && $i < $next-start {
                    $next-start = $i;
                    $kind = $k;
                }
            }
            last if $next-start == $len;

            @parts.push: $html.substr($pos, $next-start - $pos), ' ';
            my $body-start = $next-start + $kind.chars;

            if $kind eq '<!--' {
                my $end = $low.index('-->', $body-start);
                $pos = $end.defined ?? $end + 3 !! $len;
            } else {
                # Close tags may carry whitespace before the '>' (</script >,
                # </style\n>). index() on the literal '</script>' misses those
                # and would then swallow the rest of the document, dropping
                # every real link that follows (CQ). Precompute the close name
                # into a plain variable and match on the body's tail, allowing
                # optional whitespace before the closer. index() searches
                # forward; a strict :pos anchor would not (it is pinned to the
                # byte that follows the start tag), so search the substring
                # from the body start and re-offset the result.
                my $close-name = $kind.substr(1);
                my $close-rx = rx/ '</' $close-name \s* '>' /;
                my $tail = $low.substr($body-start);
                my $close-m = $tail.match($close-rx);
                $pos = $close-m ?? $body-start + $close-m.to !! $len;
            }
        }
        @parts.push: $html.substr($pos);
        @parts.join;
    }

    #| Split a srcset value on commas, ignoring commas inside balanced
    #| parentheses/brackets (per the HTML spec, URLs containing commas — such
    #| as data URIs — must be parenthesized) and dropping empty parts, so
    #| "https://e.com/a,(b).png 1x, ..." yields whole candidates instead of
    #| garbage.
    my sub split-srcset(Str $srcset --> List) {
        my @parts;
        my $buf = '';
        my $depth = 0;
        for $srcset.comb -> $ch {
            if $ch eq '(' || $ch eq '[' {
                $depth++;
                $buf ~= $ch;
            }
            elsif $ch eq ')' || $ch eq ']' {
                $depth-- if $depth > 0;
                $buf ~= $ch;
            }
            elsif $ch eq ',' && $depth == 0 {
                @parts.push: $buf if $buf.chars;
                $buf = '';
            }
            else {
                $buf ~= $ch;
            }
        }
        @parts.push: $buf if $buf.chars;
        @parts;
    }

    #| Decode a value captured from an attribute-quote alternation. The value is
    #| captured WITH its surrounding quote so the branch is distinguishable: an
    #| unquoted value can never begin with a quote char. Values are kept
    #| verbatim, including a trailing '/', matching the HTML5 tokenizer where
    #| '/' is a legal unquoted attribute-value character and therefore part of
    #| the value: <a href=/foo/> is the URL /foo/, not /foo. The self-closing
    #| '/>' marker is only recognized BETWEEN attributes in HTML (<img src=x />),
    #| never at the end of an unquoted value, so <img src=x/> is likewise the
    #| value x/.
    my sub unquote-value(Str $raw --> Str) {
        my $q = $raw.substr(0, 1);
        my $v = $q eq '"' || $q eq "'"
            ?? $raw.substr(1, $raw.chars - 2)
            !! $raw;
        # HTML entity-decodes attribute values BEFORE any downstream use, so
        # an href written "&amp;" must leave extraction as "&". Without this
        # the crawler enqueued (and published) URLs with a literal "amp;"
        # parameter. Decoded exactly once here at the chokepoint — never in
        # the shared add-url/add-srcset helpers, which also receive values
        # from this path and would double-decode "&amp;amp;". The '&' guard
        # keeps the cost at zero for the overwhelming majority of values.
        $v.contains('&') ?? decode-entities($v) !! $v;
    }

    my sub extract-href-raw(Str $html --> List) {
        my @links;
        # Single regex with alternation for all quote styles, filtering bad protocols.
        # <-[\x3E]>* (not .*?) keeps the match inside the <a ...> tag: a bare
        # <a name="top"> must not let href= swallow forward into the next tag.
        # The `<a` \s+ boundary keeps tags like <abbr> from matching.
        # An empty href="" is deliberately unmatchable: every quoted branch
        # requires at least one char, and the unquoted branch excludes quotes.
        # An empty href resolves to the document-base URL and the crawler
        # already drops empty refs, so skipping it here is the intended no-op.
        my $re = rx/:i '<a' \s+ <-[\x3E]>* \s* 'href' \s* '=' \s*
            $<raw>=( [ '"' <-["]>+ '"' | "'" <-[']>+ "'" | <-[\s"'<>]>+ ] ) / ;
        for strip-ignorable($html).match($re, :g) -> $match {
            # The value is captured with its surrounding quote; unquote-value
            # strips the quote for quoted branches and a swallowed self-closing
            # slash from the unquoted branch only.
            my $url = unquote-value($match<raw>.Str);
            next if $url ~~ m/^ :i [ 'javascript:' | 'mailto:' | 'tel:' | 'data:' | '#' ] / ;
            @links.push: $url if $url;
        }
        @links;
    }

    our sub extract(Str $html, Str $base = '' --> List) is export {
        my @links = extract-href-raw($html);
        return @links unless $base;

        my $base-uri = URI.new($base);
        my $ctx = Sitemap::Config::uri-context($base-uri);
        return @links.map({ Sitemap::Config::resolve-relative-url($_, $base-uri, :$ctx) }).List;
    }

    our sub extract-with-text(Str $html, Str $base = '' --> List) is export {
        my @results;
        my $base-uri = $base ?? URI.new($base) !! Nil;
        my $ctx = $base-uri.defined ?? Sitemap::Config::uri-context($base-uri) !! Nil;

        # :i matches uppercase <A HREF=...> exactly like every other scanner
        # in this module (extract(), $PAGE-SCAN-RX).
        my $re = rx/:i \<a \s+ $<attrs>=(<-[>]>*) \x3E $<text>=(.*?) \x3C\/a\x3E / ;
        for strip-ignorable($html).match($re, :g) -> $match {
            my $attrs = $match<attrs>.Str;
            my $text = $match<text>.Str;

            # :i for the attribute name too — HTML attributes are
            # case-insensitive, so '<A HREF=...>' must resolve like <a href>.
            my $href-re = rx/:i 'href' \s* '=' \s*
                $<raw>=( [ '"' <-["]>+ '"' | "'" <-[']>+ "'" | <-[\s"'<>]>+ ] ) / ;
            if $attrs ~~ $href-re {
                my $url = unquote-value($<raw>.Str);
                next unless $url;
                next if $url ~~ m/^ :i [ 'javascript:' | 'mailto:' | 'tel:' | 'data:' | '#' ] / ;

                if $base-uri && !($url ~~ /^ :i http[s]? \: \/\//) {
                    $url = Sitemap::Config::resolve-relative-url($url, $base-uri, :$ctx);
                }

                @results.push: {
                    url => $url,
                    text => $text,
                };
            }
        }

        @results;
    }

    our sub extract-href-only(Str $html --> List) is export {
        extract-href-raw($html);
    }

    our sub extract-images(Str $html, Str $base = '', :@meta-tags = [], Bool :$meta-tags-provided = False, :%tag-bodies = {}, Str :$html-stripped = '' --> List) is export {
        my @urls;

        # Strip the ignorable regions (script/style/comments) once for every
        # scan this sub performs when running standalone: the <img>/srcset
        # match below and the meta-tag fallback share the same cleaned HTML,
        # so a page is never stripped twice. Callers that pass %tag-bodies
        # have already tokenized the page and skip the strip entirely.
        my $scan-html-clean = $html;

        my sub add-url($u) {
            return unless $u;
            return if $u ~~ m/^ :i [ 'javascript:' | 'mailto:' | 'tel:' | 'data:' ] / ;
            @urls.push: $u;
        }

        my sub add-srcset($srcset) {
            return unless $srcset;
            my $clean = $srcset;
            if ($clean.starts-with('"') && $clean.ends-with('"'))
                || ($clean.starts-with("'") && $clean.ends-with("'")) {
                $clean = $clean.substr(1, *-1);
            }
            for split-srcset($clean) -> $part {
                my $url = $part.words[0];
                # Per the HTML spec the parens around a candidate URL that
                # contains commas are delimiters, not part of the URL, so a
                # "(data:image/png;base64,AAAA) 1x" candidate keeps its commas
                # (split-srcset, B14) and must have the wrappers removed here
                # to be filtered/resolved as the real URL.
                if $url && $url.starts-with('(') && $url.ends-with(')') {
                    $url = $url.substr(1, *-1);
                }
                add-url($url) if $url;
            }
        }

        if %tag-bodies.elems {
            # The caller already tokenized the page once (Crawler/DirScanner):
            # derive every image URL from the <img> and <source> tag bodies with
            # no further scan of the HTML. Keys the caller's :tags set did not
            # include are absent here, so each lookup needs an :exists guard
            # (a missing key is Any on current Rakudo, and (Any,).list would
            # die binding to the Str loop parameter).
            for (%tag-bodies<img>:exists ?? %tag-bodies<img>.list !! ()) -> $body {
                my %attrs = extract-tag-attrs($body);
                add-url(%attrs<src>) if %attrs<src>:exists;
                add-srcset(%attrs<srcset>) if %attrs<srcset>:exists;
            }
            for (%tag-bodies<source>:exists ?? %tag-bodies<source>.list !! ()) -> $body {
                my %attrs = extract-tag-attrs($body);
                add-srcset(%attrs<srcset>) if %attrs<srcset>:exists;
            }
        }
        else {
            # Single pass over the HTML: whole <img ...> tags (so both src and
            # srcset are captured regardless of attribute order) plus standalone
            # srcset= attributes (e.g. <source> inside <video>/<picture>).
            $scan-html-clean = $html-stripped || strip-ignorable($html);
            my $re = rx/ :i
                | '<img' \s+ $<tagbody>=(<-[\x3E]>*) '>'
                | 'srcset=' \s* $<srcset>=[ '"' (<-["]>+) '"' | "'" (<-[']>+) "'" | (<-[\s"'<>\x09\x0A\x0D]>+) ]
            /;
            for $scan-html-clean.match($re, :g) -> $match {
                if $match<tagbody>:exists {
                    my %attrs = extract-tag-attrs($match<tagbody>.Str);
                    add-url(%attrs<src>) if %attrs<src>:exists;
                    add-srcset(%attrs<srcset>) if %attrs<srcset>:exists;
                }
                elsif $match<srcset>:exists {
                    # This capture bypasses unquote-value (it is matched
                    # directly from the cleaned HTML), so entity-decode it
                    # here to match every other attribute path.
                    my $srcset = $match<srcset>.Str;
                    add-srcset($srcset.contains('&') ?? decode-entities($srcset) !! $srcset);
                }
            }
        }

        # Reuse the caller's meta bodies when it tokenized the page already:
        # only fall back to a full meta-tag scan of the HTML when none arrived.
        unless $meta-tags-provided {
            @meta-tags = %tag-bodies<meta>.list if %tag-bodies<meta>:exists;
            @meta-tags = extract-tags($scan-html-clean, 'meta') unless @meta-tags.elems;
        }
        for @meta-tags -> $tag-body {
            my %attrs = extract-tag-attrs($tag-body);
            if %attrs<property> && %attrs<property>.lc eq 'og:image' && %attrs<content> {
                add-url(%attrs<content>);
            }
        }

        if $base {
            my $base-uri = URI.new($base);
            my $ctx = Sitemap::Config::uri-context($base-uri);
            @urls = @urls.map({ Sitemap::Config::resolve-relative-url($_, $base-uri, :$ctx) });
        }

        my %seen;
        @urls = @urls.grep: -> $url {
            %seen{$url}++ ?? False !! True;
        };

        @urls;
    }

    our sub extract-tag-attrs(Str $tag-body --> Hash) is export {
        my %attrs;
        my $re = rx/
            << (\w <[\w\-:]>*) \s* '=' \s*
            $<raw>=( [ '"' <-["]>* '"' | "'" <-[']>* "'" | <-[\s"'<>`]>+ ] )
        /;
        for $tag-body.match($re, :g) -> $m {
            my $name = $m[0].lc;
            # HTML parsers keep the FIRST occurrence of a duplicated
            # attribute and ignore the rest; last-wins diverged from every
            # real parser (and from what a browser would act on).
            %attrs{$name} = unquote-value($m<raw>.Str) unless %attrs{$name}:exists;
        }
        %attrs;
    }

    #| The href of the first <base> element in document order, or '' when the
    #| document has none. Per the HTML spec only the first base element's href
    #| is used; a later <base> is ignored, so returning the first match (even
    #| when it lacks an href, which yields '') is the correct behavior. Callers
    #| resolve the value against the document URL, since a base href may itself
    #| be relative.
    our sub extract-base-href(Str $html --> Str) is export {
        # Comments and script/style bodies are stripped first: a commented-out
        # <base> must never hijack relative-link resolution (extract-html-open
        # scans cleaned HTML for the same reason). The name boundary keeps a
        # tag like <baseboard> from matching, while an attribute-less <base>
        # (empty body) still counts as THE first base element — per the HTML
        # spec it wins over any later <base>, and lacking an href it yields ''.
        my $re = rx/ :i '<base' <!before <[\w\-.]>> (<-[>]>*) '>' /;
        my $m = strip-ignorable($html) ~~ $re;
        return '' unless $m;
        my %attrs = extract-tag-attrs(~$m[0]);
        %attrs<href> // '';
    }

    #| The raw text between '<html' and '>' (including any leading whitespace),
    #| or '' when the document has no <html> tag. Used for the AMP marker check
    #| (<html ... amp|⚡>) without a second full-page scan: the caller gets this
    #| from a cheap leftmost match and hands it to is-amp-html-open.
    our sub extract-html-open(Str $html --> Str) is export {
        my $m = strip-ignorable($html) ~~ / :i '<html' (<-[>]>*) '>' /;
        $m ?? ~$m[0] !! '';
    }

    #| Whether the text between '<html' and '>' marks the page as AMP: a '⚡'
    #| directly after the tag name (whitespace optional), or an 'amp' attribute
    #| anywhere in the tag (so a tag like <htmlamp> is not misread as AMP).
    our sub is-amp-html-open(Str $body --> Bool) is export {
        return True if $body ~~ / ^ \s* '⚡' /;
        so $body ~~ /:i \s 'amp' [ \s | '=' | '>' | '/' | $ ] /;
    }

    #| The href values of a set of <a> tag bodies (as produced by
    #| extract-tag-bodies), filtering the protocols link-following ignores.
    #| Deriving hrefs from already-scanned bodies keeps discovery at one pass
    #| over the page instead of a second full scan.
    our sub extract-hrefs-from-bodies(@a-bodies --> List) is export {
        my @hrefs;
        for @a-bodies -> $body {
            my %attrs = extract-tag-attrs($body);
            my $href = %attrs<href>;
            next unless $href;
            next if $href ~~ m/^ :i [ 'javascript:' | 'mailto:' | 'tel:' | 'data:' | '#' ] /;
            @hrefs.push: $href;
        }
        @hrefs;
    }

    #| Tag names a page extraction needs in a single extract-tag-bodies pass.
    #| html is included so the AMP marker check (<html amp>) rides the same
    #| fast pass instead of forcing callers onto a second scan.
    my constant @PAGE-SCAN-TAGS = <a img source picture video base meta link html>;

    # One regex for every tag type: a name followed by an optional attribute
    # body and an optional self-closing slash. A plain `<-`[>]>* body capture
    # (no \s+ separator) lets attribute-less and self-closing tags like
    # <video>, <img/> and <meta/> match, and keeps any leading whitespace in
    # the body, so "<html amp>" yields " amp" exactly as the historical
    # extract-html-open did — the AMP marker check (is-amp-html-open) depends
    # on that leading space.
    my $all-tag-rx = rx/
        '<' (<[a..zA..Z]> <[\w\-]>*) (<-[>]>*) '>'
    /;

    # Precompiled alternation for the constant default page-scan set: matching
    # only the nine wanted tag names up front skips the per-match %wanted
    # name filter on every unrelated tag (div, span, ...) the page contains.
    # The name filter still guards this path as a safety net, and other tag
    # sets fall back to $all-tag-rx, which behaves identically thanks to that
    # same filter.
    #
    # The <!before <[\w\-]>> name boundary is REQUIRED: without it the shortest
    # branch wins a prefix match, so <article>/<abbr>/<area>/<address> tokenize
    # as tag `a`, <metadata> as `meta`, <baseline> as `base`, <linkage> as
    # `link` and <sourcex> as `source` -- and because those captured names ARE
    # in the wanted set, the %wanted filter below would keep them (it checks
    # the already-wrong captured name). The - is also excluded: without it a
    # tag like <a-class="foo"> matches as tag `a` with body `class="foo">`, and
    # crafted <a- href="evil"> would inject a real link. Do not remove the
    # boundary.
    # The :i adverb keeps <META>/<IMG>... matching like the generic scan.
    my constant $PAGE-SCAN-RX = rx/:i
        '<' (a | img | source | picture | video | base | meta | link | html) <!before <[\w\-]>> (<-[>]>*) '>'
    /;

    #| One-pass tag tokenizer: scan the HTML once and return the raw attribute
    #| body of every start tag whose name is in @tags, keyed by tag name
    #| (attribute-less and self-closing tags are matched too). Callers that
    #| need several tag types (Crawler: meta + link + a + img...) share a
    #| single scan instead of walking the page once per tag type. A single tag
    #| name may be passed as a bare Str (e.g. :tags('meta')) or as a list.
    our sub extract-tag-bodies(Str $html, :$tags = @PAGE-SCAN-TAGS --> Hash) is export {
        # HTML tag names are ASCII case-insensitive, so compare lowercased:
        # <META ...> must match a :tags<meta> request. The result keys are
        # likewise lowercased, so callers can look them up by their (canonical
        # lowercase) tag name regardless of the markup's casing.
        my @tag-list = ($tags ~~ Positional ?? $tags.list !! [$tags]).map(*.lc);
        my %wanted = @tag-list.Set;
        my %out = @tag-list.map(-> $t { $t => [] }).hash;
        # .List (uppercase) coerces the Array to a real List: .list on an
        # Array returns the Array itself, and Array eqv List is always False,
        # which used to silently disable the $PAGE-SCAN-RX fast path for every
        # caller, even the default tag set.
        my $scan-rx = @tag-list.List eqv @PAGE-SCAN-TAGS ?? $PAGE-SCAN-RX !! $all-tag-rx;
        for strip-ignorable($html).match($scan-rx, :g) -> $m {
            my $name = $m[0].Str.lc;
            next unless %wanted{$name};
            %out{$name}.push: $m[1].Str;
        }
        %out;
    }

    sub extract-tags(Str $html, Str $tag-name --> List) {
        # The tokenizer stores each tag's bodies in a Scalar-wrapped Array;
        # .list unwraps it so callers get a flat list of strings.
        extract-tag-bodies($html, :tags([$tag-name])){$tag-name.lc}.list;
    }

    our sub extract-hreflang-links(Str $html, Str $base = '', :@link-bodies = [] --> List) is export {
        my @results;
        my $base-uri = $base ?? URI.new($base) !! Nil;
        my $ctx = $base-uri.defined ?? Sitemap::Config::uri-context($base-uri) !! Nil;

        # Callers that already scanned <link> tags (Crawler, via the shared
        # extract-tag-bodies tokenizer) pass the bodies through so the page is
        # not re-scanned; otherwise fall back to a tag scan here.
        my @links-to-scan = @link-bodies.elems ?? @link-bodies !! extract-tags($html, 'link');

        for @links-to-scan -> $tag-body {
            my %attrs = extract-tag-attrs($tag-body);
            # HTML 'rel' values are ASCII case-insensitive (e.g. rel="ALTERNATE")
            # and may carry multiple space-separated tokens ("alternate x-default"),
            # so match the token set rather than the whole string.
            my $is-alternate = so (%attrs<rel> // '').lc.split(/\s+/).grep(*.chars).grep(* eq 'alternate');
            next unless $is-alternate;
            next unless %attrs<hreflang>:exists;

            my $lang = %attrs<hreflang>;
            my $url = %attrs<href>;
            next unless $url;

            next if $url ~~ m/^ :i [ 'javascript:' | 'mailto:' | 'tel:' | 'data:' | '#' ] / ;

            if $base-uri && !($url ~~ /^ :i http[s]? \: \/\//) {
                $url = Sitemap::Config::resolve-relative-url($url, $base-uri, :$ctx);
            }

            @results.push: {
                lang => $lang,
                url => $url,
            };
        }

        my %seen;
        @results = @results.grep: -> $r {
            my $key = $r<lang> ~ '|' ~ $r<url>;
            %seen{$key}++ ?? False !! True;
        };

        @results;
    }

    our sub extract-videos(Str $html, Str $base = '', :@meta-tags = [], Bool :$meta-tags-provided = False, :%tag-bodies = {}, Str :$html-stripped = '' --> List) is export {
        my @videos;
        my %seen-urls;
        my $base-uri = $base ?? URI.new($base) !! Nil;
        my $ctx = $base-uri.defined ?? Sitemap::Config::uri-context($base-uri) !! Nil;

        # When the caller has already tokenized the page (Crawler/DirScanner),
        # reuse the <img>/<video> bodies instead of re-scanning the HTML. The
        # targeted video-block scan below still runs in that case, but only
        # when there are <video> bodies to pair <source> elements with their
        # enclosing <video> poster; with no video bodies the scan is skipped.
        my $scan-html = !%tag-bodies.elems;
        # Lazy strip: only strip script/style/comments from $html when a scan
        # actually needs the clean text. Callers that tokenized the page
        # (%tag-bodies) already stripped first, so re-stripping the whole page
        # here is dead work unless a <video> block has to be scanned or no
        # meta bodies arrived (meta fallback).
        my @video-bodies = ($scan-html || !(%tag-bodies<video>:exists)) ?? () !! %tag-bodies<video>.list;
        my @img-bodies = ($scan-html || !(%tag-bodies<img>:exists)) ?? () !! %tag-bodies<img>.list;
        unless $meta-tags-provided {
            @meta-tags = %tag-bodies<meta>.list if %tag-bodies<meta>:exists;
        }
        my $scan-html-clean = ($scan-html || @video-bodies.elems || !@meta-tags.elems)
            ?? ($html-stripped || strip-ignorable($html)) !! '';
        @video-bodies = extract-tags($scan-html-clean, 'video') if $scan-html;
        @meta-tags = extract-tags($scan-html-clean, 'meta') unless @meta-tags.elems || $meta-tags-provided;

        my sub resolve-url($u --> Str) {
            return '' unless $u;
            return $u if $u ~~ /^ http[s]? \: \/\//;
            if $base-uri {
                return Sitemap::Config::resolve-relative-url($u, $base-uri, :$ctx);
            }
            $u;
        }

        my sub add-video(Str $url, Str $poster = '') {
            return unless $url;
            return if $url ~~ m/^ :i [ 'javascript:' | 'mailto:' | 'tel:' | 'data:' ] / ;
            return if %seen-urls{$url}:exists;
            %seen-urls{$url} = True;
            @videos.push: { url => $url, poster => $poster };
        }

        # Collect og:image from meta tags for thumbnail fallback
        # (separate pass: og:image may appear anywhere in the meta tags,
        # and must be resolved before processing og:video)
        my $og-image = '';
        for @meta-tags -> $tag-body {
            my %attrs = extract-tag-attrs($tag-body);
            if %attrs<property> && %attrs<property>.lc eq 'og:image' && %attrs<content> {
                $og-image = resolve-url(%attrs<content>);
            }
        }

        # First <img src> as last-resort thumbnail fallback
        my $first-img = '';
        if @img-bodies.elems {
            for @img-bodies -> $body {
                my %attrs = extract-tag-attrs($body);
                if %attrs<src>:exists {
                    $first-img = resolve-url(%attrs<src>);
                    last;
                }
            }
        }
        elsif $scan-html {
            my $img-re = rx/ '<img' .*? 'src=' \s*
                [ | '"' (<-["]>+) '"' | "'" (<-[']>+) "'" | (<-[\s"'<>\x09\x0A\x0D]>+) ] / ;
            if $scan-html-clean ~~ $img-re {
                $first-img = resolve-url(($0 // $1 // $2).Str);
            }
        }

        # Extract from <video> tags — get src and poster from attributes
        for @video-bodies -> $tag-body {
            my %attrs = extract-tag-attrs($tag-body);
            my $src = resolve-url(%attrs<src>);
            my $poster = resolve-url(%attrs<poster>);

            if $src {
                add-video($src, $poster || $og-image || $first-img);
            }
        }

        # Extract from <source src="..."> inside <video> blocks. When the
        # caller tokenized the page, the video-bodies list is authoritative and
        # the block scan runs only if there are <video> tags to look inside;
        # no <video> tags means no blocks to scan, so the pass is skipped.
        my $video-block-re = rx/ '<video' (<-[>]>*) '>' (.*?) '</video' \s* '>' / ;
        my $video-blocks = $scan-html || @video-bodies.elems;
        for $video-blocks ?? $scan-html-clean.match($video-block-re, :i :g) !! () -> $block {
            my $video-attrs = $block[0].Str;
            my $inner = $block[1].Str;

            my %video-attrs = extract-tag-attrs($video-attrs);
            my $poster = resolve-url(%video-attrs<poster>);

            for extract-tags($inner, 'source') -> $source-body {
                my %src-attrs = extract-tag-attrs($source-body);
                my $src = resolve-url(%src-attrs<src>);
                if $src {
                    add-video($src, $poster || $og-image || $first-img);
                }
            }
        }

        # Extract from <meta property="og:video" content="...">
        for @meta-tags -> $tag-body {
            my %attrs = extract-tag-attrs($tag-body);
            my $prop = %attrs<property> // '';
            $prop = $prop.lc;

            next unless $prop eq 'og:video'
                     || $prop eq 'og:video:secure_url'
                     || $prop eq 'og:video:url';

            my $url = resolve-url(%attrs<content>);
            add-video($url, $og-image) if $url;
        }

        @videos;
    }
}

=begin pod

=head1 NAME

Sitemap::Grammar::LinkExtract - Extract links from HTML

=head1 SYNOPSIS

=begin code :lang<raku>

use Sitemap::Grammar::LinkExtract;

my @links = Sitemap::Grammar::LinkExtract.extract($html, $base-url);
my @images = Sitemap::Grammar::LinkExtract.extract-images($html, $base-url);
my @hreflang = Sitemap::Grammar::LinkExtract.extract-hreflang-links($html, $base-url);

=end code

=begin comment
Known limitation: link/image extraction is regex-based (a cache of per-tag
patterns like %TAG-RX) rather than a real HTML parser. It handles the common
cases — well-formed start tags, single- and double-quoted attributes — but can
miss or mis-read attributes on malformed HTML (unbalanced quotes, tags spread
across comments, weird entity encoding). This is a deliberate trade-off to
avoid a full DOM dependency; treat extraction results as best-effort, not as
an authoritative parse of the page.
=end comment

=head1 FUNCTIONS

=head2 extract(Str $html, Str $base = '' --> List)

Extract all href values from anchor tags in HTML. Returns a list of URLs.

=head2 extract-with-text(Str $html, Str $base = '' --> List)

Extract links with their link text. Returns a list of hashrefs with 'url' and 'text' keys.

=head2 extract-href-only(Str $html --> List)

Fast extraction of just href attributes using regex. Returns URLs only.

=head2 extract-images(Str $html, Str $base = '' --> List)

Extract image URLs from HTML. Searches img src, picture/source srcset, and og:image meta tags.
Returns a deduplicated list of image URLs. Resolves relative URLs if $base is provided.

=head2 extract-hreflang-links(Str $html, Str $base = '' --> List)

Extract hreflang links from link tags. Searches for <link rel="alternate" hreflang="xx" href="...">.
Returns a list of hashes with 'lang' and 'url' keys. Resolves relative URLs if $base is provided.

=head2 extract-videos(Str $html, Str $base = '' --> List)

Extract video URLs from HTML. Searches <video src>, <video><source>, and og:video meta tags.
Returns a deduplicated list of hashes with 'url' and 'poster' keys.
Thumbnail resolution priority: poster attribute → og:image → first img src → empty.
Resolves relative URLs if $base is provided.

=head2 extract-base-href(Str $html --> Str)

Return the href of the first C<< <base> >> element in document order, or ''
when there is none. Per the HTML spec only the first base element's href is
used, so a later C<< <base> >> is intentionally ignored. The value may be
relative and must be resolved against the document URL by the caller.

=end pod
