use v6.d;

grammar Sitemap::Grammar::SitemapSniff {
    token TOP {
        \s*
        [ <byte-order-mark> \s* ]?
        # Prolog items may appear in any order and repeat: a generated file
        # can carry comments before and after the XML declaration, a DOCTYPE
        # may sit between them, and the BOM may be followed by a newline
        # (BOM'd template + leading blank line). Requiring one fixed order
        # used to make valid documents unclassifiable, so the BOM is also
        # accepted as an ordinary prolog item.
        [ <xml-decl> | <doctype> | <comment> | <byte-order-mark> ]*
        <root>
    }

    token root {
        | <urlset>
        | <sitemapindex>
        | <atom-feed>
        | <rss>
        | <html>
    }

    # Lazy .*? stops at the first '-->' even when the comment body contains
    # '>', which XML allows.  (A negated '>' class would fail the whole parse
    # on any comment that legitimately contains a greater-than sign.)
    token comment { '<!--' .*? '-->' \s* }

    token urlset         { '<urlset' <-[>]>* '>' }
    token sitemapindex   { '<sitemapindex' <-[>]>* '>' }
    token atom-feed      { '<feed' \s+ <-[>]>*? 'xmlns' [\s* ':' \s* <[a..zA..Z0..9._-]>*]? \s* '=' \s* ['"' | "'"] 'http://www.w3.org/2005/Atom' ['"' | "'"] [\s+ <-[>]>*]? '>' }
    token rss            { '<rss' <-[>]>* '>' }
    token html           { :i [ | '<html' <-[>]>* '>' | '<!DOCTYPE' \s+ 'html' <-[>]>* '>' ] }

    token xml-decl       { '<?xml' <-[?]>+ '?>' \s* }
    # Internal subsets may contain '>' inside entity declarations
    # (<!ENTITY x "y">), so bracketed sections are consumed as units and
    # only a '>' outside them terminates the declaration. HTML documents
    # are excluded: their doctype is the *root* marker handled by the
    # html token, so the prolog must not swallow it.
    token doctype        { :i '<!doctype' \h+ <!before html> [ <-[>\[]> | '[' ~ ']' <-[\]]>* ]* '>' \s* }
    token byte-order-mark { \x[FEFF] }
}

class Sitemap::Grammar::SitemapSniff::Actions {
    method urlset($/)         { make 'xml-sitemap' }
    method sitemapindex($/)   { make 'xml-sitemap' }
    method atom-feed($/)      { make 'atom' }
    method rss($/)            { make 'rss' }
    method html($/)           { make 'html' }
    method root($/)           { make $/.values[0].made }
    method xml-decl($/)       { }
    method doctype($/)        { }
    method byte-order-mark($) { }
    method TOP($/)            { make $<root>.made // 'txt' }
}
