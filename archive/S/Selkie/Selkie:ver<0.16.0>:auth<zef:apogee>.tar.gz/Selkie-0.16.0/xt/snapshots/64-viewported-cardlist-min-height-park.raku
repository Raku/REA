use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::ViewportedCardList;
use Selkie::Widget::Border;
use Selkie::Widget::Text;
use Selkie::Sizing;

# Row-scrolled cards of 6 rows in a 10-row viewport, scrolled 3 rows
# into card 0. Card 0 has 3 rows left above the fold, below its
# declared min-display-height of 5, so it is parked: its band of the
# viewport stays empty instead of showing a bottom border with no top
# and half a body. Cards 1 and 2 render normally underneath. Compare
# with 65, which is the same layout at the default threshold.
my $cards = Selkie::Widget::ViewportedCardList.new(sizing => Sizing.flex);

for <alpha beta gamma> -> $label {
    my $text   = Selkie::Widget::Text.new(text => $label, sizing => Sizing.flex);
    my $border = Selkie::Widget::Border.new(sizing => Sizing.flex);
    $border.set-content($text);
    $cards.add-item($text, root => $border, height => 6, :$border,
                    min-display-height => 5);
}

$cards.scroll-to(3);

print render-to-string($cards, rows => 10, cols => 20);
