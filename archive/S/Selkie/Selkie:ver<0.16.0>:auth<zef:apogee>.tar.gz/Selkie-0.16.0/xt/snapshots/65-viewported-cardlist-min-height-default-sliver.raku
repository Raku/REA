use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::ViewportedCardList;
use Selkie::Widget::Border;
use Selkie::Widget::Text;
use Selkie::Sizing;

# The control for 64: identical geometry at the default
# min-display-height of 1, where every positive sliver renders. The
# top of the viewport shows card 0's last three rows — body row,
# blank row, bottom border — exactly as it did before
# min-display-height was honoured.
my $cards = Selkie::Widget::ViewportedCardList.new(sizing => Sizing.flex);

for <alpha beta gamma> -> $label {
    my $text   = Selkie::Widget::Text.new(text => $label, sizing => Sizing.flex);
    my $border = Selkie::Widget::Border.new(sizing => Sizing.flex);
    $border.set-content($text);
    $cards.add-item($text, root => $border, height => 6, :$border);
}

$cards.scroll-to(3);

print render-to-string($cards, rows => 10, cols => 20);
