NAME
====

Selkie::App::Internal::FocusTree - internal focus and tree-state role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.focus`, `Selkie::App.focused`, `Selkie::App.focus-next`, `Selkie::App.focus-prev`, and `Selkie::App.widget-attached` from application code.

Every path here — first-focusable, the Tab cycle, the per-frame invariant, and per-screen focus memory — decides what focus may land on through `Selkie::App.focus-eligible`, which is the one place the rule lives. See "Focus eligibility" in [Selkie::App](Selkie--App.md).

