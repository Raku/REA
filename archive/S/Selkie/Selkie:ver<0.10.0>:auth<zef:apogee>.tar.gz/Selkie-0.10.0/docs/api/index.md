# Selkie API reference

Auto-generated from Pod6 declarator comments and pod blocks in each module. See the main [Readme](../../README.md) for narrative docs, synopsis examples, and design philosophy.

## Core

- [Selkie](Selkie.md)
- [Selkie::App](Selkie--App.md)
- [Selkie::Widget](Selkie--Widget.md)
- [Selkie::Container](Selkie--Container.md)
- [Selkie::Store](Selkie--Store.md)
- [Selkie::ScreenManager](Selkie--ScreenManager.md)
- [Selkie::Event](Selkie--Event.md)
- [Selkie::EffectiveBounds](Selkie--EffectiveBounds.md)
- [Selkie::Sizing](Selkie--Sizing.md)
- [Selkie::Style](Selkie--Style.md)
- [Selkie::Theme](Selkie--Theme.md)
- [Selkie::Trace](Selkie--Trace.md)
- [Selkie::Tree](Selkie--Tree.md)

## Internal implementation

- [Selkie::App::Internal::Dispatch](Selkie--App--Internal--Dispatch.md)
- [Selkie::App::Internal::ErrorLog](Selkie--App--Internal--ErrorLog.md)
- [Selkie::App::Internal::FocusTree](Selkie--App--Internal--FocusTree.md)
- [Selkie::App::Internal::HitTest](Selkie--App--Internal--HitTest.md)
- [Selkie::App::Internal::IdleBudget](Selkie--App--Internal--IdleBudget.md)
- [Selkie::App::Internal::OverlayTree](Selkie--App--Internal--OverlayTree.md)
- [Selkie::App::Internal::RenderLoop](Selkie--App--Internal--RenderLoop.md)
- [Selkie::App::Internal::ScreenModalLifecycle](Selkie--App--Internal--ScreenModalLifecycle.md)
- [Selkie::App::Internal::Terminal](Selkie--App--Internal--Terminal.md)
- [Selkie::App::Internal::TerminalSequences](Selkie--App--Internal--TerminalSequences.md)

## Layouts

- [Selkie::Layout::Allocate](Selkie--Layout--Allocate.md)
- [Selkie::Layout::VBox](Selkie--Layout--VBox.md)
- [Selkie::Layout::HBox](Selkie--Layout--HBox.md)
- [Selkie::Layout::Split](Selkie--Layout--Split.md)

## Display widgets

- [Selkie::Widget::Text](Selkie--Widget--Text.md)
- [Selkie::Widget::RichText](Selkie--Widget--RichText.md)
- [Selkie::Widget::RichText::Span](Selkie--Widget--RichText--Span.md)
- [Selkie::Widget::TextStream](Selkie--Widget--TextStream.md)
- [Selkie::Widget::Image](Selkie--Widget--Image.md)
- [Selkie::Widget::ProgressBar](Selkie--Widget--ProgressBar.md)
- [Selkie::Widget::Spinner](Selkie--Widget--Spinner.md)

## Input widgets

- [Selkie::Widget::TextInput](Selkie--Widget--TextInput.md)
- [Selkie::Widget::MultiLineInput](Selkie--Widget--MultiLineInput.md)
- [Selkie::Widget::Button](Selkie--Widget--Button.md)
- [Selkie::Widget::Checkbox](Selkie--Widget--Checkbox.md)
- [Selkie::Widget::RadioGroup](Selkie--Widget--RadioGroup.md)
- [Selkie::Widget::Select](Selkie--Widget--Select.md)
- [Selkie::Widget::PasswordStrength](Selkie--Widget--PasswordStrength.md)

## List widgets

- [Selkie::Widget::ListView](Selkie--Widget--ListView.md)
- [Selkie::Widget::CardList](Selkie--Widget--CardList.md)
- [Selkie::Widget::ViewportedCardList](Selkie--Widget--ViewportedCardList.md)
- [Selkie::Widget::ScrollView](Selkie--Widget--ScrollView.md)
- [Selkie::Widget::Table](Selkie--Widget--Table.md)

## Chrome / overlays

- [Selkie::Widget::Border](Selkie--Widget--Border.md)
- [Selkie::Widget::Modal](Selkie--Widget--Modal.md)
- [Selkie::Widget::ConfirmModal](Selkie--Widget--ConfirmModal.md)
- [Selkie::Widget::FileBrowser](Selkie--Widget--FileBrowser.md)
- [Selkie::Widget::HelpOverlay](Selkie--Widget--HelpOverlay.md)
- [Selkie::Widget::Toast](Selkie--Widget--Toast.md)
- [Selkie::Widget::TabBar](Selkie--Widget--TabBar.md)
- [Selkie::Widget::CommandPalette](Selkie--Widget--CommandPalette.md)
- [Selkie::Widget::FocusableByDefault](Selkie--Widget--FocusableByDefault.md)

## Charts

- [Selkie::Plot::Palette](Selkie--Plot--Palette.md)
- [Selkie::Plot::Scaler](Selkie--Plot--Scaler.md)
- [Selkie::Plot::Ticks](Selkie--Plot--Ticks.md)
- [Selkie::Widget::Axis](Selkie--Widget--Axis.md)
- [Selkie::Widget::Legend](Selkie--Widget--Legend.md)
- [Selkie::Widget::Plot](Selkie--Widget--Plot.md)
- [Selkie::Widget::Sparkline](Selkie--Widget--Sparkline.md)
- [Selkie::Widget::BarChart](Selkie--Widget--BarChart.md)
- [Selkie::Widget::Histogram](Selkie--Widget--Histogram.md)
- [Selkie::Widget::Heatmap](Selkie--Widget--Heatmap.md)
- [Selkie::Widget::ScatterPlot](Selkie--Widget--ScatterPlot.md)
- [Selkie::Widget::LineChart](Selkie--Widget--LineChart.md)

## Test helpers

- [Selkie::Test::Keys](Selkie--Test--Keys.md)
- [Selkie::Test::Supply](Selkie--Test--Supply.md)
- [Selkie::Test::Store](Selkie--Test--Store.md)
- [Selkie::Test::Focus](Selkie--Test--Focus.md)
- [Selkie::Test::Tree](Selkie--Test--Tree.md)
- [Selkie::Test::Snapshot](Selkie--Test--Snapshot.md)
- [Selkie::Test::Snapshot::Harness](Selkie--Test--Snapshot--Harness.md)

## Other

- [Selkie::Widget::TextInput::HighlightSpan](Selkie--Widget--TextInput--HighlightSpan.md)

