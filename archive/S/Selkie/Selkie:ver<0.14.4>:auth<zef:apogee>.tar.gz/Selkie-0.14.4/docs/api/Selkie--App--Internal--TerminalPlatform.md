NAME
====

Selkie::App::Internal::TerminalPlatform - platform boundary for terminal lifecycle operations

DESCRIPTION
===========

Internal implementation detail shared by `Selkie::App` and `Selkie::Test::Snapshot`. All access to the POSIX controlling-terminal path, termios ABI, flow-control command, and terminal-related signals is selected here. Windows deliberately exposes no controlling-terminal or Raku signal operations: its console is managed by notcurses and its resize events arrive as input events rather than `SIGWINCH`.

