NAME
====

Selkie::App::Internal::FocusTree - internal focus and tree-state role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.focus`, `Selkie::App.focused`, `Selkie::App.focus-next`, `Selkie::App.focus-prev`, and `Selkie::App.widget-attached` from application code.

