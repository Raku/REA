NAME
====

Selkie::App::Internal::IdleBudget - internal frame-budget helpers for Selkie::App

DESCRIPTION
===========

Implementation detail for `Selkie::App`. Use `Selkie::App` and `Selkie::App::pick-frame-budget` from application code.

