NAME
====

Selkie::App::Internal::OverlayTree - internal toast and image-tree coordination role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.toast` and `Selkie::App.force-refresh-sprixels` from application code.

