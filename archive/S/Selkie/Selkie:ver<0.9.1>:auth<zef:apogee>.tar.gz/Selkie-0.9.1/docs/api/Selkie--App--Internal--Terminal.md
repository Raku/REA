NAME
====

Selkie::App::Internal::Terminal - internal terminal cleanup role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. It is not part of the stable 1.0 application API.

