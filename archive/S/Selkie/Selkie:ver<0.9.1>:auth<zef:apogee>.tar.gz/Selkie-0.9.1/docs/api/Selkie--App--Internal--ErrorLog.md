NAME
====

Selkie::App::Internal::ErrorLog - internal stderr redirection role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.set-error-log` or the `error-log` constructor argument from application code.

