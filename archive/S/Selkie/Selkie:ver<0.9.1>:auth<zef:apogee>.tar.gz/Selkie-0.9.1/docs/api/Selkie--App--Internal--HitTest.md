NAME
====

Selkie::App::Internal::HitTest - internal coordinate hit-testing helpers

DESCRIPTION
===========

Implementation detail for `Selkie::App`. Use `Selkie::App.widget-at-in` from application code.

