NAME
====

Selkie::App::Internal::TerminalSequences - internal terminal escape builders

DESCRIPTION
===========

Implementation detail for `Selkie::App`. Use `Selkie::App.build-title-osc` and `Selkie::App.build-terminal-cleanup-sequence` from application code.

