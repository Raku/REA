NAME
====

Selkie::App::Internal::RenderLoop - internal render, resize, and event-loop role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.run`, `Selkie::App.quit`, `Selkie::App.on-frame`, and `Selkie::App.on-resize` from application code.

