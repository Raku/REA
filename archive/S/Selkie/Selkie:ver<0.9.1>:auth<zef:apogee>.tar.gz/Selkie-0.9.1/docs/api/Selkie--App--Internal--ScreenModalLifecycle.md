NAME
====

Selkie::App::Internal::ScreenModalLifecycle - internal screen and modal lifecycle role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.screen-manager`, `Selkie::App.root`, `Selkie::App.add-screen`, `Selkie::App.switch-screen`, `Selkie::App.show-modal`, `Selkie::App.close-modal`, and `Selkie::App.has-modal` from application code.

