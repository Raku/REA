NAME
====

Selkie::App::Internal::Dispatch - internal input dispatch role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.on-key`, `Selkie::App.event-supply`, and widget `handle-event` methods from application code.

