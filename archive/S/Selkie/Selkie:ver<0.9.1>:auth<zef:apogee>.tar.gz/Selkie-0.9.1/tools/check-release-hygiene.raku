#!/usr/bin/env raku
use v6.d;

# Fails when package-root artifacts that should never be present during a
# release validation are found. These files are ignored by git, so `git status`
# alone will not catch them.

my @bad;

for <.precomp lib/.precomp NUL> -> $path {
    @bad.push($path) if $path.IO.e;
}

for '.'.IO.dir -> $entry {
    my $name = $entry.basename;
    next unless $name.starts-with('Selkie-');
    if $entry.d || $name.ends-with('.tar.gz') {
        @bad.push($name);
    }
}

if @bad {
    note "Release hygiene failed: remove ignored package artifacts before release validation:";
    note "  - $_" for @bad.sort;
    exit 1;
}

say "Release hygiene OK";
