=begin pod

=head1 NAME

Selkie::Widget::Border - Decorative frame around a single content widget

=head1 SYNOPSIS

=begin code :lang<raku>

use Selkie::Widget::Border;
use Selkie::Sizing;

my $border = Selkie::Widget::Border.new(
    title  => 'Characters',
    sizing => Sizing.fixed(20),
);
$border.set-content($avatar-list);

=end code

=head1 DESCRIPTION

Draws a box around a single child widget. Auto-highlights when any
descendant has focus (via a store subscription on C<ui.focused-widget>
— it's the canonical example of the "widget reacts to store state"
pattern).

Requires at least 3x3 dimensions. Redraws its edges after content renders
to cover pixel bleed from image blits — useful when wrapping an Image.

=head2 Opting out of store-driven focus

Set C<focus-from-store = False> to disable both the store subscription
and the render-time override. In that mode C<set-has-focus> is the only
writer and its value persists across renders. Intended for Borders
managed by a parent container with richer selection semantics than
"focused descendant" — C<CardList>, for example, which wants its
I<selected> card's Border highlighted regardless of whether keyboard
focus has moved elsewhere.

=head2 Swapping content

By default, C<set-content> destroys the outgoing widget. Pass
C<:!destroy> to swap while keeping the old widget alive — useful for
tab-style panes that cycle through persistent views:

=begin code :lang<raku>

$border.set-content($view-a);
$border.set-content($view-b, :!destroy);    # $view-a survives
$border.set-content($view-a, :!destroy);    # swap back, still intact

=end code

=head1 EXAMPLES

=head2 Named panels

=begin code :lang<raku>

my $left = Selkie::Widget::Border.new(
    title  => 'Characters',
    sizing => Sizing.fixed(20),
);
$left.set-content($char-list);

my $right = Selkie::Widget::Border.new(
    title  => 'Chat',
    sizing => Sizing.flex,
);
$right.set-content($chat-view);

=end code

=head2 Stacking borders

Use C<hide-top-border> / C<hide-bottom-border> to share edges between
adjacent panels:

=begin code :lang<raku>

$top-panel.hide-bottom-border    = True;
$bottom-panel.hide-top-border    = True;

=end code

=head1 SEE ALSO

=item L<Selkie::Widget::Modal> — centered overlay; also has C<set-content(:!destroy)>
=item L<Selkie::Theme> — C<border> / C<border-focused> slots control appearance

=end pod

use Notcurses::Native;
use Notcurses::Native::Types;
use Notcurses::Native::Plane;

use Selkie::Widget;
use Selkie::Container;
use Selkie::Style;
use Selkie::Event;

unit class Selkie::Widget::Border does Selkie::Container;

has Selkie::Widget $!content;
has Str $.title = '';
has Bool $!has-focus = False;
has Bool $.hide-top-border is rw = False;
has Bool $.hide-bottom-border is rw = False;

#|( When True (default), the Border subscribes to C<ui.focused-widget>
    and its C<render> re-derives C<$!has-focus> from the store on every
    frame — the normal "highlight when any descendant is focused"
    pattern.

    When False, the Border treats C<set-has-focus> as the single source
    of truth: no subscription, no render-time override. This is the
    right mode for Borders whose focus state is managed by a parent
    container that has richer selection semantics than "focused
    descendant" — C<CardList> being the canonical case, where the
    I<selected> card's border should stay highlighted regardless of
    whether keyboard focus has moved out to another widget. )
has Bool $.focus-from-store is rw = True;

#| The current content widget, or the C<Selkie::Widget> type object
#| when no content is set.
method content(--> Selkie::Widget) { $!content }

#| Install C<$w> as the wrapped content. Re-callable to swap content
#| (e.g. for a Border that cycles through several views).
#|
#| C<:destroy> (default True) destroys the outgoing widget — the
#| common case when content isn't reused. Pass C<:!destroy> to keep
#| the outgoing widget alive (its plane is parked far off-screen so
#| its last-rendered cells don't bleed through behind the new
#| content); reinstall it later with another C<set-content> call.
method set-content(Selkie::Widget $w, Bool :$destroy = True) {
    # Destroying the outgoing content is the safe default — most callers
    # won't reuse it. Pass :!destroy when swapping between widgets that
    # you want to keep alive (e.g. a tab-style pane that cycles through
    # several persistent views).
    #
    # In the non-destroy case we park the outgoing plane far off-screen
    # so its last-rendered contents don't bleed through behind the new
    # content. Widget state (plane, subscriptions, cursor positions) is
    # preserved, and C<reposition> puts it back in place on the next
    # install. Values > screen height are safe — notcurses tolerates
    # out-of-bounds plane positions and simply clips them.
    if $!content && $destroy {
        $!content.destroy;
    } elsif $!content && $!content.plane {
        # park() recurses through containers and cleans up sprixels on
        # Image widgets (which otherwise stay visible on the terminal
        # even when their parent plane moves off-screen).
        $!content.park;
    }
    $!content = $w;
    $w.parent = self;
    $w.set-store(self.store) if self.store;
    self.mark-dirty;
}

#| Update the border's title text. Mark-dirties only; no event emit.
method set-title(Str:D $t) {
    $!title = $t;
    self.mark-dirty;
}

#| Set the border's focus state explicitly. Idempotent on no-ops.
#| Used by containers (notably C<CardList>) that drive border
#| highlighting from their own selection rather than the framework's
#| keyboard-focus tracking — pair with C<focus-from-store = False> in
#| those cases.
method set-has-focus(Bool $f) {
    return if $f == $!has-focus;
    $!has-focus = $f;
    self.mark-dirty;
}

#| Whether the border is currently rendered in its focused style.
method has-focus(--> Bool) { $!has-focus }

#|( Hook called when the widget is attached to a store. Auto-subscribes
#| to the focused-widget path when C<focus-from-store> is True (the
#| default) so the border highlights itself whenever the keyboard
#| focus is one of its descendants. C<once-*> variants are idempotent
#| — reparenting and repeated set-store calls won't create duplicate
#| subscriptions. Skipped entirely when C<focus-from-store> is False
#| (see attribute docs).
)
method on-store-attached($store) {
    return unless $!focus-from-store;
    my $border = self;
    self.once-subscribe-computed("border-focus-{self.WHICH}", -> $s {
        my $focused = $s.get-in('ui', 'focused-widget');
        $focused.defined ?? $border!is-descendant($focused) !! False;
    });
}

method !is-descendant(Selkie::Widget $widget --> Bool) {
    # Walk up from widget to see if we're an ancestor
    my $w = $widget;
    while $w.defined {
        return True if $w === $!content;
        return True if $w.parent.defined && $w.parent === self;
        $w = $w.parent;
    }
    False;
}

#| Resize own plane. Content is sized inside C<render> (after the
#| inner-top / inner-rows / inner-cols computation that accounts for
#| hide-top/bottom-border). No cascade here — one layout pass per
#| frame, top-down via render.
method handle-resize(UInt $rows, UInt $cols) {
    my $changed = $rows != self.rows || $cols != self.cols;
    return unless $changed;
    self.resize($rows, $cols);
    self!on-resize;
}

method render() {
    return without self.plane;

    # Update focus state directly from the store on each render. Cheap
    # and avoids stale state if the subscription-driven update hasn't
    # landed yet. Skipped when C<focus-from-store> is False — in that
    # mode a parent (e.g. CardList) owns the authoritative has-focus
    # state and set-has-focus is the single writer.
    if self.store && $!focus-from-store {
        my $focused = self.store.get-in('ui', 'focused-widget');
        $!has-focus = $focused.defined && self!is-descendant($focused);
    }

    my UInt $rows = self.rows;
    my UInt $cols = self.cols;
    if $rows < 3 || $cols < 3 {
        # Too small to draw a useful border. Still resize the content
        # plane to our footprint (treating both borders as hidden) so
        # its cells stay inside our bounds — without this, the content's
        # plane keeps its previous larger size and notcurses paints its
        # cells past our edge into siblings, since notcurses doesn't
        # clip child planes to parents. effective-bounds protects the
        # blit-plane (sprixel pixels), but the content's own cell-grid
        # paint needs the plane itself to be the right size.
        if $!content && $!content.plane {
            $!content.reposition(0, 0);
            $!content.handle-resize($rows, $cols);
        }
        ncplane_erase(self.plane);
        self.clear-dirty;
        return;
    }

    my $border-style = $!has-focus ?? self.theme.border-focused !! self.theme.border;
    self.apply-style($border-style);
    ncplane_erase(self.plane);

    # Draw border
    my UInt $top-y = 0;
    my UInt $bot-y = $rows - 1;
    my UInt $content-top = $!hide-top-border ?? 0 !! 1;
    my UInt $content-bot = $!hide-bottom-border ?? $rows !! $rows - 1;

    unless $!hide-top-border {
        ncplane_putstr_yx(self.plane, $top-y, 0, '┌');
        ncplane_putstr_yx(self.plane, $top-y, $cols - 1, '┐');
        for 1 ..^ ($cols - 1) -> $x {
            ncplane_putstr_yx(self.plane, $top-y, $x, '─');
        }
    }

    unless $!hide-bottom-border {
        ncplane_putstr_yx(self.plane, $bot-y, 0, '└');
        ncplane_putstr_yx(self.plane, $bot-y, $cols - 1, '┘');
        for 1 ..^ ($cols - 1) -> $x {
            ncplane_putstr_yx(self.plane, $bot-y, $x, '─');
        }
    }

    for $content-top ..^ $content-bot -> $y {
        ncplane_putstr_yx(self.plane, $y, 0, '│');
        ncplane_putstr_yx(self.plane, $y, $cols - 1, '│');
    }

    # Draw title in top border
    if !$!hide-top-border && $!title.chars > 0 && $cols > 4 {
        my $display = $!title.substr(0, $cols - 4);
        ncplane_putstr_yx(self.plane, 0, 2, " $display ");
    }

    # Position and render content inside the border
    if $!content {
        my UInt $inner-top = $content-top;
        my UInt $inner-rows = $content-bot - $content-top;
        my UInt $inner-cols = $cols - 2;
        if $inner-rows > 0 {
            if $!content.plane {
                $!content.reposition($inner-top, 1);
                $!content.handle-resize($inner-rows, $inner-cols);
            } else {
                $!content.init-plane(self.plane,
                    y => $inner-top, x => 1, rows => $inner-rows, cols => $inner-cols);
            }
            $!content.set-viewport(
                abs-y => self.abs-y + $inner-top,
                abs-x => self.abs-x + 1,
                rows  => $inner-rows,
                cols  => $inner-cols,
            );
            $!content.mark-dirty unless $!content.is-dirty;
            $!content.render;
        }
    }

    # Redraw border edges after content render to cover any pixel bleed
    self.apply-style($border-style);
    for $content-top ..^ $content-bot -> $y {
        ncplane_putstr_yx(self.plane, $y, 0, '│');
        ncplane_putstr_yx(self.plane, $y, $cols - 1, '│');
    }
    unless $!hide-bottom-border {
        ncplane_putstr_yx(self.plane, $bot-y, 0, '└');
        ncplane_putstr_yx(self.plane, $bot-y, $cols - 1, '┘');
        for 1 ..^ ($cols - 1) -> $x {
            ncplane_putstr_yx(self.plane, $bot-y, $x, '─');
        }
    }

    self.clear-dirty;
}

#| Focusable descendants of the wrapped content subtree. Used by
#| C<Selkie::App>'s Tab cycle to skip the Border itself (which is
#| chrome) and reach the inner widget.
method focusable-descendants(--> Seq) {
    return ().Seq without $!content;
    gather {
        take $!content if $!content.focusable;
        if $!content ~~ Selkie::Container {
            .take for $!content.focusable-descendants;
        }
    }
}

#| Destroy the wrapped content and the border's own plane. Always
#| destroys the content unconditionally — for "swap and keep alive"
#| flows, use C<set-content(:!destroy)> instead.
method destroy() {
    $!content.destroy if $!content;
    $!content = Selkie::Widget;
    self!destroy-plane;
}
