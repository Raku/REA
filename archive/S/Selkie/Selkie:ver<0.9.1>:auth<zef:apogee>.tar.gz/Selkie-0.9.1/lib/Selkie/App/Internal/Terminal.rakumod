=begin pod

=head1 NAME

Selkie::App::Internal::Terminal - internal terminal cleanup role for Selkie::App

=head1 DESCRIPTION

Implementation detail composed by C<Selkie::App>. It is not part of the stable
1.0 application API.

=end pod

unit role Selkie::App::Internal::Terminal;

use Selkie::App::Internal::TerminalSequences;

has Str $!saved-tty-state;

method !emit-terminal-cleanup(--> Nil) {
    return unless '/dev/tty'.IO.e;
    my $tty = try open('/dev/tty', :w);
    return without $tty;
    LEAVE { try $tty.close }
    try $tty.print(app-terminal-cleanup-sequence);
}

method !capture-tty-state(--> Str) {
    return Str unless '/dev/tty'.IO.e;
    my $state = try qx{stty -g < /dev/tty 2>/dev/null};
    $state.defined && $state.chomp.chars > 0 ?? $state.chomp !! Str;
}

method !restore-tty-state(--> Nil) {
    return unless $!saved-tty-state.defined && $!saved-tty-state.chars > 0;
    return unless '/dev/tty'.IO.e;
    try shell "stty '$!saved-tty-state' < /dev/tty 2>/dev/null";
}
