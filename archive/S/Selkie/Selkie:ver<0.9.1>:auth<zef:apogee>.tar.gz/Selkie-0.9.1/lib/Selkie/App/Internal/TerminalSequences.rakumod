=begin pod

=head1 NAME

Selkie::App::Internal::TerminalSequences - internal terminal escape builders

=head1 DESCRIPTION

Implementation detail for C<Selkie::App>. Use C<Selkie::App.build-title-osc>
and C<Selkie::App.build-terminal-cleanup-sequence> from application code.

=end pod

unit module Selkie::App::Internal::TerminalSequences;

sub app-detect-sprixel-bug-prone-terminal(--> Bool) is export {
    return True if %*ENV<KITTY_WINDOW_ID>:exists;
    return True if (%*ENV<TERM> // '').starts-with('xterm-kitty');
    False;
}

sub app-title-osc(Str:D $title, Bool :$tmux = False --> Str) is export {
    my $safe = $title.subst(/<[ \x00..\x1f \x7f ]>/, '', :g);

    my $osc = "\e]0;$safe\a";
    if $tmux {
        my $inner = $osc.subst("\e", "\e\e", :g);
        $osc = "\ePtmux;{$inner}\e\\";
    }
    $osc;
}

sub app-terminal-cleanup-sequence(--> Str) is export {
    join '',
        "\e[?25h",         # show cursor (DECTCEM)
        "\e[0m",           # reset SGR
        "\e[?1000l",       # X10 mouse off
        "\e[?1001l",       # VT220 highlight mouse off
        "\e[?1002l",       # button-event mouse off
        "\e[?1003l",       # any-event mouse off
        "\e[?1004l",       # focus event reporting off
        "\e[?1005l",       # UTF-8 mouse encoding off
        "\e[?1006l",       # SGR mouse encoding off
        "\e[?1015l",       # urxvt mouse encoding off
        "\e[?1016l",       # SGR-pixel mouse encoding off
        "\e[?2004l",       # bracketed paste off
        "\e[>4;0m",        # modify-other-keys off
        "\e[<u\e[<u\e[<u", # Kitty kbd protocol pop x3
        "\e[?1049l",       # exit alternate screen
    ;
}
