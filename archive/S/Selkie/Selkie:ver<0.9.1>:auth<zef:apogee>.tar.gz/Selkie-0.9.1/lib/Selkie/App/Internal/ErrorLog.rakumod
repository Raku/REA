=begin pod

=head1 NAME

Selkie::App::Internal::ErrorLog - internal stderr redirection role for Selkie::App

=head1 DESCRIPTION

Implementation detail composed by C<Selkie::App>. Use C<Selkie::App.set-error-log>
or the C<error-log> constructor argument from application code.

=end pod

unit role Selkie::App::Internal::ErrorLog;

use NativeCall;

has Int $!saved-stderr-fd;
has IO::Handle $!error-log-handle;

sub c-dup(int32)           returns int32 is native is symbol('dup')   { * }
sub c-dup2(int32, int32)   returns int32 is native is symbol('dup2')  { * }
sub c-close(int32)         returns int32 is native is symbol('close') { * }

method !try-log(Str:D $step, &block) {
    block();
    CATCH {
        default {
            my $msg = .message;
            my $bt  = .?backtrace.?full.?Str // '';
            try $*ERR.say("[shutdown:$step] $msg");
            try $*ERR.say($bt) if $bt;
        }
    }
}

method !install-error-log(Str:D $path --> Nil) {
    my Str $clean-path = $path.trim;
    return if $clean-path.chars == 0;

    my $parent = $clean-path.IO.parent;
    try $parent.mkdir unless $parent.e;

    my $handle = try open $clean-path, :a;
    return unless $handle;
    $!error-log-handle = $handle;

    my $banner = "=== session {DateTime.now.truncated-to('second')} ===\n";
    try $handle.print($banner);
    try $handle.flush;

    my $log-fd = $handle.native-descriptor;
    return unless $log-fd.defined && $log-fd >= 0;

    my $saved = c-dup(2);
    if $saved < 0 {
        $handle.close;
        $!error-log-handle = Nil;
        return;
    }
    $!saved-stderr-fd = $saved;

    my $rc = c-dup2($log-fd, 2);
    if $rc < 0 {
        c-close($saved);
        $!saved-stderr-fd = Int;
        $handle.close;
        $!error-log-handle = Nil;
    }
}

method !uninstall-error-log(--> Nil) {
    if $!saved-stderr-fd.defined && $!saved-stderr-fd >= 0 {
        c-dup2($!saved-stderr-fd, 2);
        c-close($!saved-stderr-fd);
        $!saved-stderr-fd = Int;
    }
    if $!error-log-handle {
        try $!error-log-handle.close;
        $!error-log-handle = Nil;
    }
}
