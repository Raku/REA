use lib "lib";

use Selkie::Test::Snapshot;
use Selkie::Test::SnapshotPlatform;

my $null-fp = snapshot-fopen(NULL-PATH, "w");
die "could not open the platform null device" unless $null-fp.defined;
die "could not close the platform null device" unless snapshot-fclose($null-fp) == 0;

say "snapshot-import-ok";
