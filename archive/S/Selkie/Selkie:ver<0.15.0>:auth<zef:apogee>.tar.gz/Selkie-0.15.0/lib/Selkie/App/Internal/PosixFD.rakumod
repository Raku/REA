=begin pod

=head1 NAME

Selkie::App::Internal::PosixFD - shared POSIX process-library fd bindings

=head1 DESCRIPTION

Internal raw ABI boundary for C<dup>, C<dup2>, and C<close>. Callers retain
their own semantic adapters and must select a POSIX branch before invoking
these routines. In particular, these integer descriptors must never be passed
to a Windows CRT DLL: official Windows MoarVM owns a private C</MT> descriptor
table.

=end pod

unit module Selkie::App::Internal::PosixFD;

use NativeCall;

our sub posix-fd-dup(int32 --> int32) is export
    is native(Str) is symbol('dup') { * }
our sub posix-fd-dup2(int32, int32 --> int32) is export
    is native(Str) is symbol('dup2') { * }
our sub posix-fd-close(int32 --> int32) is export
    is native(Str) is symbol('close') { * }
