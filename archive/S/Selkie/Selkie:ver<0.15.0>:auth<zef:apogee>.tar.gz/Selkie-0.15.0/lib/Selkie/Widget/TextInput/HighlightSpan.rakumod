=begin pod

=head1 NAME

Selkie::Widget::TextInput::HighlightSpan - A styled character range within a TextInput buffer

=head1 SYNOPSIS

=begin code :lang<raku>

use Selkie::Widget::TextInput::HighlightSpan;
use Selkie::Style;

# Color characters 4..^10 of the buffer green:
my $span = Selkie::Widget::TextInput::HighlightSpan.new(
    start => 4,
    end   => 10,
    style => Selkie::Style.new(fg => 0x80E060),
);

=end code

=head1 DESCRIPTION

A simple value class — a half-open character range (C<start>
inclusive, C<end> exclusive, both offsets into the input's buffer)
plus the style to paint it with. Returned in lists from a
C<TextInput.highlight-provider> callback; the input repaints each
range over its base text during C<render>.

Unlike L<Selkie::Widget::RichText::Span>, which carries its own text
and flows within a paragraph, a C<HighlightSpan> is positional: it
references characters the buffer already owns. Ranges outside the
visible window are clipped automatically; ranges that overlap paint
in list order (later spans win).

Span styles should normally set C<fg> only — the input merges each
span onto its own base style, so an unset C<bg> inherits the input's
background and the highlight doesn't punch a hole in the field.

The class has its own file so that C<unit class> can declare it
without conflicting with C<Selkie::Widget::TextInput> itself.

=head1 SEE ALSO

=item L<Selkie::Widget::TextInput> — the widget that consumes these via C<highlight-provider>
=item L<Selkie::Widget::RichText::Span> — the flowed-text counterpart
=item L<Selkie::Style> — styling attributes

=end pod

unit class Selkie::Widget::TextInput::HighlightSpan;

use Selkie::Style;

#| First character offset of the range (inclusive). Required.
has UInt $.start is required;

#| One past the last character offset of the range (exclusive). Required.
has UInt $.end is required;

#| Style painted over the range. Merged onto the input's base style, so
#| set C<fg> only unless you deliberately want a different background.
has Selkie::Style $.style is required;
