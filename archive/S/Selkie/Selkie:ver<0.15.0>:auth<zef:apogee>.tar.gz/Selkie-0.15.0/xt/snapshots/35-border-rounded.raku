use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Text;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Sizing;

# BorderRounded: arc corners, single-weight edges. Pins the glyph table
# and proves the title still lands in a gap in the top run.

my $text = Selkie::Widget::Text.new(
    text   => 'inside',
    sizing => Sizing.flex,
);

my $border = Selkie::Widget::Border.new(
    title        => 'Rounded',
    border-style => BorderRounded,
    sizing       => Sizing.flex,
);
$border.set-content($text);

print render-to-string($border, rows => 5, cols => 24);
