use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Text;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Sizing;

# BorderHeavy. There is no notcurses heavy-box native — this is the
# scenario that would break first if the hand-painter were ever swapped
# for ncplane_*_box.

my $text = Selkie::Widget::Text.new(
    text   => 'inside',
    sizing => Sizing.flex,
);

my $border = Selkie::Widget::Border.new(
    title        => 'Heavy',
    border-style => BorderHeavy,
    sizing       => Sizing.flex,
);
$border.set-content($text);

print render-to-string($border, rows => 5, cols => 24);
