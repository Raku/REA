use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::TabBar;
use Selkie::Layout::VBox;
use Selkie::Widget::Text;
use Selkie::Sizing;

# Badges drawn inside the tab cell, after the label. The upper bar is
# focused with a badged active tab (badge inside the brackets); the
# lower bar is unfocused with the badged tab active and a count over
# 99, which the stock formatter clamps to "99+" so a runaway number
# can't widen the strip without bound. The middle tab carries no badge
# at all — the separator goes with it.

my $vbox = Selkie::Layout::VBox.new(sizing => Sizing.flex);

my $focused = Selkie::Widget::TabBar.new(sizing => Sizing.fixed(1));
$focused.add-tab(name => 'inbox',   label => 'Inbox',   badge => 4);
$focused.add-tab(name => 'today',   label => 'Today');
$focused.add-tab(name => 'someday', label => 'Someday', badge => 128);
$focused.set-focused(True);
$vbox.add($focused);

$vbox.add: Selkie::Widget::Text.new(text => '', sizing => Sizing.fixed(1));

my $unfocused = Selkie::Widget::TabBar.new(sizing => Sizing.fixed(1));
$unfocused.add-tab(name => 'inbox',   label => 'Inbox',   badge => 4);
$unfocused.add-tab(name => 'today',   label => 'Today');
$unfocused.add-tab(name => 'someday', label => 'Someday', badge => 128);
$unfocused.select-index(2);
$vbox.add($unfocused);

print render-to-string($vbox, rows => 3, cols => 60);
