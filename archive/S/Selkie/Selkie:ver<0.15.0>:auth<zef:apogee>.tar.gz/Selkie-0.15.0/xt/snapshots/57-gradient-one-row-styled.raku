use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Gradient;
use Selkie::Widget::GradientFill;
use Selkie::Sizing;

# THE DEGENERATE-GEOMETRY GUARD.
#
# A 1 x 20 region is degenerate for ncplane_gradient: it refuses the
# call outright — returns -1 and paints not one cell — unless the top
# and bottom corners agree. A two-dimensional gradient handed to a
# one-row selection bar is therefore a silent no-op without
# Gradient.for-region, which gradient-fill applies for us.
#
# So the golden is the proof. If the collapse regresses, this scenario
# paints nothing at all: the cells stay at gcluster 0, the row reads as
# blank, the lockstep trailing-row trim drops it, and the golden becomes
# empty. What a working collapse produces instead is 20 '·' cells whose
# backgrounds ramp black -> white in 20 distinct steps.
#
# The bottom corners are deliberately unrelated to the top ones (red and
# green against black and white) so that the collapse has to actually
# discard them, and so that a collapse that averaged the corners instead
# of taking the top row would show up immediately as a tinted ramp.
#
# The flat foreground ramp keeps the golden independent of the active
# theme (an unset foreground resolves through to the plane's base cell).
my $bar = Selkie::Widget::GradientFill.new(
    gradient => Gradient.corners(
        top-left     => 0x000000, top-right    => 0xFFFFFF,
        bottom-left  => 0xFF0000, bottom-right => 0x00FF00,
    ),
    fg-gradient => Gradient.uniform(0x808080),
    egc         => '·',
    sizing      => Sizing.fixed(1),
);

print render-to-string($bar, rows => 1, cols => 20, :capture-styles);
