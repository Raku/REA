use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Layout::VBox;
use Selkie::Sizing;

# Border padding, with an inner ASCII frame as the content so the inset
# is visible on all four edges at once (a Text would only prove the top
# left corner moved).
#
# Top pane: uniform padding => 1. Content box is (2, 2) 4x20 inside an
# 8x24 frame — one cell of clearance all round.
#
# Bottom pane: asymmetric. padding-top / padding-bottom stay 0 so the
# content still meets the horizontal edges, while three columns on the
# left and one on the right push it sideways. Note the titles are
# untouched by either: they live on the frame, not in the content box.

my $box = Selkie::Layout::VBox.new(sizing => Sizing.flex);

my $uniform = Selkie::Widget::Border.new(
    title        => 'Uniform',
    border-style => BorderRounded,
    padding      => 1,
    sizing       => Sizing.fixed(8),
);
$uniform.set-content(Selkie::Widget::Border.new(
    border-style => BorderAscii,
    sizing       => Sizing.flex,
));

my $asymmetric = Selkie::Widget::Border.new(
    title          => 'Asymmetric',
    border-style   => BorderRounded,
    padding-left   => 3,
    padding-right  => 1,
    sizing         => Sizing.fixed(6),
);
$asymmetric.set-content(Selkie::Widget::Border.new(
    border-style => BorderAscii,
    sizing       => Sizing.flex,
));

$box.add: $uniform;
$box.add: $asymmetric;

print render-to-string($box, rows => 14, cols => 24);
