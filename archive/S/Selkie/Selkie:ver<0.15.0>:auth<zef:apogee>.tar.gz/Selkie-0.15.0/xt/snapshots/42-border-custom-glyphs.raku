use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Text;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Sizing;

# An explicit BorderGlyphs table beats border-style, and custom title
# affixes replace the default space padding — here a bracketed title
# sitting flush in the top run.

my $dotted = BorderGlyphs.new(
    top-left    => '.', top-right    => '.',
    bottom-left => "'", bottom-right => "'",
    horizontal  => '.', vertical     => ':',
);

my $text = Selkie::Widget::Text.new(
    text   => 'custom',
    sizing => Sizing.flex,
);

# border-style is deliberately set to something loud: the golden proves
# the explicit table wins.
my $border = Selkie::Widget::Border.new(
    title         => 'Glyphs',
    border-style  => BorderHeavy,
    border-glyphs => $dotted,
    title-prefix  => '[',
    title-suffix  => ']',
    sizing        => Sizing.flex,
);
$border.set-content($text);

print render-to-string($border, rows => 5, cols => 24);
