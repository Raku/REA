use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Align;
use Selkie::Widget::Border;
use Selkie::Widget::Text;
use Selkie::Sizing;

# Right-aligned text. Every line ends flush against the border's right
# edge — including the one that exactly fills the 18-column content box
# (it starts at 0 and is unmoved), and the over-long word, which clips
# on the right rather than being pushed off the left.

my $text = Selkie::Widget::Text.new(
    text   => "ready\n3 unread\n123456789012345678\nsupercalifragilisticexpialidocious",
    align  => TextRight,
    sizing => Sizing.flex,
);

my $border = Selkie::Widget::Border.new(title => 'right', sizing => Sizing.flex);
$border.set-content($text);

print render-to-string($border, rows => 9, cols => 20);
