use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Gradient;
use Selkie::Widget::GradientFill;
use Selkie::Sizing;

# A full two-dimensional ramp: a different colour in each corner, so the
# styled snapshot pins notcurses's bilinear interpolation, not just a
# one-axis lerp. Colour IS the regression here — the glyph grid alone
# would be identical whether the gradient painted or not.
#
# The EGC is '·' rather than the widget's default space on purpose: the
# styled readback trims trailing spaces per row, so an all-blank
# background wash would be trimmed to nothing and the snapshot would
# assert nothing at all. A visible glyph keeps every column in the
# golden while still exercising the background-gradient path.
#
# The flat foreground ramp is there so the golden depends on nothing
# but this scenario: without it the glyphs' colour resolves through to
# the plane's base cell, i.e. to whatever Selkie::Theme.default happens
# to say today.
my $fill = Selkie::Widget::GradientFill.new(
    gradient => Gradient.corners(
        top-left     => 0x000000, top-right    => 0xFF0000,
        bottom-left  => 0x0000FF, bottom-right => 0xFFFF00,
    ),
    fg-gradient => Gradient.uniform(0x808080),
    egc         => '·',
    sizing      => Sizing.flex,
);

print render-to-string($fill, rows => 3, cols => 8, :capture-styles);
