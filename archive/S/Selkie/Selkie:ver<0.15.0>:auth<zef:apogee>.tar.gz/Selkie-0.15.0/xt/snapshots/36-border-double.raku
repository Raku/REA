use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Text;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Sizing;

# BorderDouble: the whole table changes, edges included — a good check
# that the horizontal run and both verticals come from the same glyph
# set as the corners.

my $text = Selkie::Widget::Text.new(
    text   => 'inside',
    sizing => Sizing.flex,
);

my $border = Selkie::Widget::Border.new(
    title        => 'Double',
    border-style => BorderDouble,
    sizing       => Sizing.flex,
);
$border.set-content($text);

print render-to-string($border, rows => 5, cols => 24);
