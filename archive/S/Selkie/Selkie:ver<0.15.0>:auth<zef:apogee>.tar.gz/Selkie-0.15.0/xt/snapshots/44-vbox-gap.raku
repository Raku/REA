use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Border;
use Selkie::Layout::VBox;
use Selkie::Sizing;

# VBox gutters. Four panes, one of them hidden with the Sizing.fixed(0)
# idiom, in a 12-row box with gap => 1:
#
#   countable children = 3  →  gap-reserve = 2  →  content box = 10
#
# so the golden pins three things at once: a blank row between panes,
# no leading or trailing gutter, and — the rule that's easy to get
# wrong — no gutter beside the hidden pane. 'Three' therefore starts
# one row after 'Two' ends, not two.

my $box = Selkie::Layout::VBox.new(sizing => Sizing.flex, gap => 1);

$box.add: Selkie::Widget::Border.new(title => 'One', sizing => Sizing.fixed(3));
$box.add: Selkie::Widget::Border.new(title => 'Two', sizing => Sizing.fixed(3));
$box.add: Selkie::Widget::Border.new(title => 'Gone', sizing => Sizing.fixed(0));
$box.add: Selkie::Widget::Border.new(title => 'Three', sizing => Sizing.fixed(3));

print render-to-string($box, rows => 12, cols => 20);
