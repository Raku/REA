use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Layout::VBox;
use Selkie::Sizing;
use Selkie::Widget::Border;
use Selkie::Widget::Button;
use Selkie::Widget::Text;

# Greyscale is a colour change and nothing else — the glyph block below
# is byte-for-byte what an all-enabled version of this scene renders —
# so this scenario only means anything with :capture-styles. The legend
# is the assertion.
#
# Three pairs, each an enabled widget directly above its disabled twin:
#
#   * an unfocused Button, the plain case;
#   * a FOCUSED Button, which pins that greying wins over the focus
#     style — a disabled control that still holds the focus flag must
#     not sit there lit up in the accent colour;
#   * a Border whose CONTENT is disabled, which pins the frame/content
#     split: the frame lives on the Border's own plane and keeps its
#     colours, while the inside greys. A disabled panel reads as "these
#     controls are unavailable", not "this panel is gone";
#   * a Border that is ITSELF disabled, where the frame greys too and
#     the recursion carries on into the content.
#
# The third pair is also the guard on the load-bearing detail in
# Selkie::Widget.greyscale-plane. The `text` theme slot sets a
# foreground and no background, so that row's cells inherit their bg
# rather than carrying one. notcurses's own ncplane_greyscale would
# flatten those inherited channels to an explicit BLACK, turning the
# panel into a black bar; Selkie greys cell-by-cell and leaves them
# inherited, so what shows is the widget's own greyed base cell. If
# that ever regresses, the legend entry for the disabled content row
# turns into bg=#000000 and this golden fails.
#
# Cross-check against Selkie::Style.greyscale-rgb's reference table in
# t/96: whatever colour the enabled twin carries, the disabled twin's
# is that colour's Rec. 601 grey, truncated. 0x24243E -> 0x262626,
# 0x4A4A8A -> 0x515151, 0x1A1A2E -> 0x1C1C1C and the frame's
# 0x4A4A6A -> 0x4D4D4D are all in the legend below.

my $vbox = Selkie::Layout::VBox.new(sizing => Sizing.flex);

my $live = Selkie::Widget::Button.new(label => 'Save', sizing => Sizing.fixed(1));
$vbox.add($live);

my $dead = Selkie::Widget::Button.new(label => 'Save', sizing => Sizing.fixed(1));
$vbox.add($dead);
$dead.set-disabled(True);

my $live-focused
    = Selkie::Widget::Button.new(label => 'Save', sizing => Sizing.fixed(1));
$live-focused.set-focused(True);
$vbox.add($live-focused);

my $dead-focused
    = Selkie::Widget::Button.new(label => 'Save', sizing => Sizing.fixed(1));
$dead-focused.set-focused(True);
$vbox.add($dead-focused);
$dead-focused.set-disabled(True);

my $live-panel = Selkie::Widget::Border.new(
    title  => 'Live',
    sizing => Sizing.fixed(3),
);
$live-panel.set-content(
    Selkie::Widget::Text.new(text => 'ready', sizing => Sizing.flex));
$vbox.add($live-panel);

my $dead-panel = Selkie::Widget::Border.new(
    title  => 'Off',
    sizing => Sizing.fixed(3),
);
my $dead-body = Selkie::Widget::Text.new(text => 'ready', sizing => Sizing.flex);
$dead-panel.set-content($dead-body);
$vbox.add($dead-panel);
$dead-body.set-disabled(True);

my $dead-frame = Selkie::Widget::Border.new(
    title  => 'Gone',
    sizing => Sizing.fixed(3),
);
$dead-frame.set-content(
    Selkie::Widget::Text.new(text => 'ready', sizing => Sizing.flex));
$vbox.add($dead-frame);
$dead-frame.set-disabled(True);

print render-to-string($vbox, rows => 13, cols => 24, :capture-styles);
