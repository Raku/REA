use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Layout::VBox;
use Selkie::Sizing;

# Right-aligned titles. The second frame's title is long enough that
# the clamp has to pull it back off the corners — the golden shows the
# corner glyphs surviving on both sides.

my $box = Selkie::Layout::VBox.new(sizing => Sizing.flex);

$box.add: Selkie::Widget::Border.new(
    title       => 'Right',
    title-align => TitleRight,
    sizing      => Sizing.fixed(3),
);

$box.add: Selkie::Widget::Border.new(
    title       => 'Too long for this frame',
    title-align => TitleRight,
    sizing      => Sizing.fixed(3),
);

print render-to-string($box, rows => 6, cols => 24);
