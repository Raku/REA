use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::BorderStyle;
use Selkie::Sizing;
use Selkie::Widget::Modal;
use Selkie::Widget::Text;

# The key-hint slot: a framed modal carrying a title on the top edge and
# a hint strip on the bottom one, which is what lets a dialog drop the
# hand-rolled header and footer Text rows it would otherwise need.
#
# Both titles are centred by default (a dialog heading reads as a
# heading when it is centred, where a pane title reads better hard
# left); this scenario moves the hint strip right to prove the two
# alignments are independent. The heavy frame keeps the corner glyphs
# visually distinct from scenario 48's rounded one.
#
# 0.7 x 0.45 of 16x44 is a 7x30 dialog at (4, 7). No padding here, so
# the content box is 5x28 at (5, 8) and the single text row sits flush
# against the left edge run.

my $modal = Selkie::Widget::Modal.new(
    width-ratio              => 0.7,
    height-ratio             => 0.45,
    framed                   => True,
    frame-style              => BorderHeavy,
    frame-title              => 'Delete branch?',
    frame-bottom-title       => 'y yes . n no',
    frame-bottom-title-align => TitleRight,
    frame-padding            => 0,
);

$modal.set-content(Selkie::Widget::Text.new(
    text   => 'feature/rounded-borders',
    sizing => Sizing.flex,
));

print render-to-string($modal, rows => 16, cols => 44);
