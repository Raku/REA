use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::TabBar;
use Selkie::Layout::VBox;
use Selkie::Widget::Text;
use Selkie::Sizing;

# FocusColor spends colour instead of columns: there is no "▶ " prefix,
# so the strip starts at column 0 (visible in the glyph block — compare
# 11-tabbar-active-inactive, which is indented by two), and the focused
# bar's active tab is merged with the theme's tab-focus-accent slot
# instead. Colour is the whole assertion, hence :capture-styles.
#
# Both bars keep the default bracket decoration, which is what a bar
# opting into FocusColor usually looks like: the brackets say which tab
# is current, the accent says whether the bar is being driven.

my $vbox = Selkie::Layout::VBox.new(sizing => Sizing.flex);

my $focused = Selkie::Widget::TabBar.new(
    sizing          => Sizing.fixed(1),
    focus-indicator => FocusColor,
);
$focused.add-tab(name => 'notes', label => 'Notes');
$focused.add-tab(name => 'tasks', label => 'Tasks', badge => 3);
$focused.select-index(1);
$focused.set-focused(True);
$vbox.add($focused);

$vbox.add: Selkie::Widget::Text.new(text => '', sizing => Sizing.fixed(1));

my $unfocused = Selkie::Widget::TabBar.new(
    sizing          => Sizing.fixed(1),
    focus-indicator => FocusColor,
);
$unfocused.add-tab(name => 'notes', label => 'Notes');
$unfocused.add-tab(name => 'tasks', label => 'Tasks', badge => 3);
$unfocused.select-index(1);
$vbox.add($unfocused);

print render-to-string($vbox, rows => 3, cols => 26, :capture-styles);
