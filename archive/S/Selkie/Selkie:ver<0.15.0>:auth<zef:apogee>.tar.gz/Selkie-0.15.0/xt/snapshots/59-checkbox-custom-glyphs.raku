use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Checkbox;
use Selkie::Layout::VBox;
use Selkie::Sizing;

# A configured glyph pair, one unchecked and one checked, stacked to
# prove set-glyphs takes effect on both states and the label doesn't
# jitter when the glyphs are equal width.

my $off = Selkie::Widget::Checkbox.new(
    label  => 'Notifications',
    sizing => Sizing.fixed(1),
);
$off.set-glyphs(checked => '(•)', unchecked => '( )');

my $on = Selkie::Widget::Checkbox.new(
    label  => 'Auto-save',
    sizing => Sizing.fixed(1),
);
$on.set-glyphs(checked => '(•)', unchecked => '( )');
$on.set-checked(True);

my $root = Selkie::Layout::VBox.new(sizing => Sizing.flex);
$root.add($off);
$root.add($on);

print render-to-string($root, rows => 2, cols => 24);
