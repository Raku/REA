use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Image;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Sizing;

# Guards the post-content edge redraw. Border paints its frame, renders
# the content, then repaints the verticals and the bottom edge to cover
# pixel bleed from an image blit. That second pass is a separate branch
# from the first: it has to reach for the same glyph table, and it has
# to put the bottom title back on top of the edge it just redrew.
#
# The interior is masked before printing. Which blitter notcurses picks
# for the image depends on the terminal it detects and the multimedia
# backend it was compiled against, so the cells the image occupies are
# not stable across machines — but the frame around them is, and the
# frame is the whole point of this scenario. Bleed that reached a frame
# cell would still show, because only columns strictly inside the
# verticals are masked.

my $img = Selkie::Widget::Image.new(sizing => Sizing.flex);
$img.set-file('t/fixtures/test-4x4.png');

my $border = Selkie::Widget::Border.new(
    title              => 'Avatar',
    bottom-title       => 'esc close',
    bottom-title-align => TitleRight,
    border-style       => BorderRounded,
    sizing             => Sizing.flex,
);
$border.set-content($img);

my @rows = render-to-string($border, rows => 6, cols => 24).lines;

my $last = @rows.end;
my @masked = @rows.kv.map(-> $i, $line {
    ($i == 0 || $i == $last)
        ?? $line                              # top / bottom edge, verbatim
        !! $line.substr(0, 1)                 # left vertical
           ~ ('.' x (($line.chars - 2) max 0))
           ~ ($line.chars > 1 ?? $line.substr(*-1) !! '')   # right vertical
});

print @masked.join("\n") ~ "\n";
