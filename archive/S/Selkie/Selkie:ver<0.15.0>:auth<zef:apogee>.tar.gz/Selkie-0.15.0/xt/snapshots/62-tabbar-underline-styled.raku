use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::TabBar;
use Selkie::Layout::VBox;
use Selkie::Widget::Text;
use Selkie::Sizing;

# TabUnderline's marker is a style bit, not a glyph, so this scenario is
# captured with :capture-styles — the UNDERLINE flag in the legend IS
# the assertion. Two bars: focused (active tab in the tab-active
# colours, underlined) and unfocused (active tab recedes to the
# tab-inactive colours but keeps the underline, so you can still see
# which tab is current).

my $vbox = Selkie::Layout::VBox.new(sizing => Sizing.flex);

my $focused = Selkie::Widget::TabBar.new(
    sizing       => Sizing.fixed(1),
    active-style => TabUnderline,
);
$focused.add-tab(name => 'notes', label => 'Notes');
$focused.add-tab(name => 'tasks', label => 'Tasks');
$focused.select-index(1);
$focused.set-focused(True);
$vbox.add($focused);

$vbox.add: Selkie::Widget::Text.new(text => '', sizing => Sizing.fixed(1));

my $unfocused = Selkie::Widget::TabBar.new(
    sizing       => Sizing.fixed(1),
    active-style => TabUnderline,
);
$unfocused.add-tab(name => 'notes', label => 'Notes');
$unfocused.add-tab(name => 'tasks', label => 'Tasks');
$unfocused.select-index(1);
$vbox.add($unfocused);

print render-to-string($vbox, rows => 3, cols => 26, :capture-styles);
