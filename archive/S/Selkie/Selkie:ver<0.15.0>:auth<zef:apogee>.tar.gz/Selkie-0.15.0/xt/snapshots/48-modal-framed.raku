use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::BorderStyle;
use Selkie::Layout::VBox;
use Selkie::Sizing;
use Selkie::Widget::Modal;
use Selkie::Widget::Text;

# A framed modal: rounded frame, centred title, one cell of padding.
#
# The dialog rectangle is 0.6 x 0.5 of a 14x40 terminal — 7 rows by 24
# columns, centred at (3, 8). The frame then eats a row/column of edge
# and a row/column of padding on each side, so the content box is 3x20
# at (5, 10) — which is exactly what the three text rows land on. The
# ruler row makes the horizontal inset legible: it starts at column 10,
# two in from the frame's left edge at column 8.

my $modal = Selkie::Widget::Modal.new(
    width-ratio  => 0.6,
    height-ratio => 0.5,
    framed       => True,
    frame-style  => BorderRounded,
    frame-title  => 'Rename',
);

my $body = Selkie::Layout::VBox.new(sizing => Sizing.flex);
$body.add: Selkie::Widget::Text.new(
    text => '12345678901234567890', sizing => Sizing.fixed(1),
);
$body.add: Selkie::Widget::Text.new(
    text => 'new name', sizing => Sizing.flex,
);
$body.add: Selkie::Widget::Text.new(
    text => 'bottom row', sizing => Sizing.fixed(1),
);
$modal.set-content($body);

print render-to-string($modal, rows => 14, cols => 40);
