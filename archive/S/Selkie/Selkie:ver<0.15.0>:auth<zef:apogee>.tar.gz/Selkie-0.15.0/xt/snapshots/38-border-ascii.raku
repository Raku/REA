use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Text;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Sizing;

# BorderAscii — the manual escape hatch for terminals without the
# box-drawing block. Selkie never selects it automatically, so this
# golden is also the proof that the frame is drawable with nothing but
# 7-bit characters.

my $text = Selkie::Widget::Text.new(
    text   => 'inside',
    sizing => Sizing.flex,
);

my $border = Selkie::Widget::Border.new(
    title        => 'Ascii',
    border-style => BorderAscii,
    sizing       => Sizing.flex,
);
$border.set-content($text);

print render-to-string($border, rows => 5, cols => 24);
