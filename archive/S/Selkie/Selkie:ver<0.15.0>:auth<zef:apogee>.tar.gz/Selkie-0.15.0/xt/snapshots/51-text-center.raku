use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Align;
use Selkie::Widget::Border;
use Selkie::Widget::Text;
use Selkie::Sizing;

# Centred text, inside a border so the golden shows the column offsets
# against a known left edge. Three cases in one scene:
#
#   * a short line — floor((18 - 6) / 2) = 6 columns in;
#   * an odd-slack line — floor((18 - 5) / 2) = 6, so the extra column
#     lands on the right, not the left;
#   * a paragraph that wraps — each wrapped line is centred on its own,
#     which is what makes centred prose ragged rather than justified.
#
# The blank line between them proves alignment never writes padding:
# an empty line puts nothing anywhere.

my $text = Selkie::Widget::Text.new(
    text   => "Selkie\nv1.2.0\n\nthe quick brown fox jumps over the lazy dog",
    align  => TextCenter,
    sizing => Sizing.flex,
);

my $border = Selkie::Widget::Border.new(title => 'centred', sizing => Sizing.flex);
$border.set-content($text);

print render-to-string($border, rows => 10, cols => 20);
