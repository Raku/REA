use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Layout::VBox;
use Selkie::Sizing;

# Centred titles at an even and an odd leftover, stacked so one golden
# pins both. The odd case floors, so the second frame's title sits one
# column left of true centre.

my $box = Selkie::Layout::VBox.new(sizing => Sizing.flex);

$box.add: Selkie::Widget::Border.new(
    title       => 'Even',           # 24 - 6 = 18, exactly halved
    title-align => TitleCenter,
    sizing      => Sizing.fixed(3),
);

$box.add: Selkie::Widget::Border.new(
    title       => 'Odder',          # 24 - 7 = 17, floors to 8
    title-align => TitleCenter,
    sizing      => Sizing.fixed(3),
);

print render-to-string($box, rows => 6, cols => 24);
