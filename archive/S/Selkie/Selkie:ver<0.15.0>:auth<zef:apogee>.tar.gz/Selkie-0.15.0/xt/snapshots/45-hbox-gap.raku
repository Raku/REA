use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Border;
use Selkie::Layout::HBox;
use Selkie::Sizing;

# HBox gutters. Three panes across 30 columns with gap => 2:
#
#   gap-reserve = 4  →  content box = 26  →  8 fixed + 12 flex + 6 fixed
#
# The flex pane is the one that pays for the gutters: it gets 12
# columns rather than the 16 it would take without them. Columns 8-9
# and 22-23 are the gaps — unpainted, so the HBox's own plane base
# shows through.

my $row = Selkie::Layout::HBox.new(sizing => Sizing.flex, gap => 2);

$row.add: Selkie::Widget::Border.new(title => 'A',    sizing => Sizing.fixed(8));
$row.add: Selkie::Widget::Border.new(title => 'wide', sizing => Sizing.flex);
$row.add: Selkie::Widget::Border.new(title => 'C',    sizing => Sizing.fixed(6));

print render-to-string($row, rows => 5, cols => 30);
