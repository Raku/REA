use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::Border;
use Selkie::BorderStyle;
use Selkie::Layout::VBox;
use Selkie::Sizing;

# Bottom titles, plus the hidden-edge interaction. Two stacked panels
# share one edge:
#
#   * the top panel hides its bottom border, so its bottom-title has no
#     edge to sit on and must not be drawn at all;
#   * the bottom panel hides its top border, so its (top) title must
#     vanish for the same reason, while its right-aligned bottom title
#     — a key-hint strip — does get drawn.
#
# Getting this wrong paints a title into the content area, which is why
# it's worth a golden.

my $box = Selkie::Layout::VBox.new(sizing => Sizing.flex);

my $top = Selkie::Widget::Border.new(
    title        => 'Files',
    bottom-title => 'suppressed',
    sizing       => Sizing.fixed(3),
);
$top.hide-bottom-border = True;
$box.add($top);

my $bottom = Selkie::Widget::Border.new(
    title              => 'suppressed',
    bottom-title       => 'j/k move',
    bottom-title-align => TitleRight,
    sizing             => Sizing.fixed(3),
);
$bottom.hide-top-border = True;
$box.add($bottom);

print render-to-string($box, rows => 6, cols => 28);
