use lib 'lib';
use Selkie::Test::Snapshot;
use Selkie::Widget::TextInput;
use Selkie::Widget::TextInput::HighlightSpan;
use Selkie::Style;
use Selkie::Sizing;

# A focused input with two highlight spans (green over "#exist", red
# over "#new") and a blue ghost tail after the buffer. The plain
# snapshot would show uniform text; the styled snapshot pins the fg
# channel of each run — including the caret block sitting on the
# first ghost char.
my $ti = Selkie::Widget::TextInput.new(sizing => Sizing.fixed(1));
$ti.set-text-silent('#exist #new');
$ti.set-focused(True);

$ti.highlight-provider = -> Str $ {
    (
        Selkie::Widget::TextInput::HighlightSpan.new(
            start => 0, end => 6,
            style => Selkie::Style.new(fg => 0x80E060),
        ),
        Selkie::Widget::TextInput::HighlightSpan.new(
            start => 7, end => 11,
            style => Selkie::Style.new(fg => 0xE06060),
        ),
    )
};
$ti.suggest-provider = -> Str $, UInt $ { '-gadget' };
$ti.ghost-style = Selkie::Style.new(fg => 0x7AA2F7, italic => True);

print render-to-string($ti, rows => 1, cols => 30, :capture-styles);
