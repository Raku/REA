NAME
====

Selkie::App::Internal::ErrorLogPlatform - platform fd adapter for error logging

DESCRIPTION
===========

Internal implementation detail used by `Selkie::App::Internal::ErrorLog`.

