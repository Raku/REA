NAME
====

Selkie::Widget::TextInput::HighlightSpan - A styled character range within a TextInput buffer

SYNOPSIS
========

```raku
use Selkie::Widget::TextInput::HighlightSpan;
use Selkie::Style;

# Color characters 4..^10 of the buffer green:
my $span = Selkie::Widget::TextInput::HighlightSpan.new(
    start => 4,
    end   => 10,
    style => Selkie::Style.new(fg => 0x80E060),
);
```

DESCRIPTION
===========

A simple value class — a half-open character range (`start` inclusive, `end` exclusive, both offsets into the input's buffer) plus the style to paint it with. Returned in lists from a `TextInput.highlight-provider` callback; the input repaints each range over its base text during `render`.

Unlike [Selkie::Widget::RichText::Span](Selkie--Widget--RichText--Span.md), which carries its own text and flows within a paragraph, a `HighlightSpan` is positional: it references characters the buffer already owns. Ranges outside the visible window are clipped automatically; ranges that overlap paint in list order (later spans win).

Span styles should normally set `fg` only — the input merges each span onto its own base style, so an unset `bg` inherits the input's background and the highlight doesn't punch a hole in the field.

The class has its own file so that `unit class` can declare it without conflicting with `Selkie::Widget::TextInput` itself.

SEE ALSO
========

  * [Selkie::Widget::TextInput](Selkie--Widget--TextInput.md) — the widget that consumes these via `highlight-provider`

  * [Selkie::Widget::RichText::Span](Selkie--Widget--RichText--Span.md) — the flowed-text counterpart

  * [Selkie::Style](Selkie--Style.md) — styling attributes

### has UInt $.start

First character offset of the range (inclusive). Required.

### has UInt $.end

One past the last character offset of the range (exclusive). Required.

### has Selkie::Style $.style

Style painted over the range. Merged onto the input's base style, so set `fg` only unless you deliberately want a different background.

