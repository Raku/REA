NAME
====

Selkie::App::Internal::Terminal - internal terminal cleanup role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. It is not part of the stable 1.0 application API.

Captures the terminal's `termios` state before notcurses enters raw-style mode and restores it during shutdown. The capture/restore pair is implemented with in-process `tcgetattr`/`tcsetattr` NativeCall bindings rather than by shelling out to `stty`. Spawning a child process during shutdown proved fragile in two ways seen in the wild:

  * If the process's working directory has been deleted or renamed while the app was running, `posix_spawn` fails with ENOENT before the command even runs — the `stty` restore silently can't happen.

  * A failed spawn surfaces as an `X::Proc::Unsuccessful` broken on a thread-pool thread, which escapes a caller-side `try` and can propagate out of `Selkie::App.shutdown`, skipping `notcurses_stop` and the escape-sequence backstop entirely — the exact wedged-terminal outcome the restore existed to prevent.

An in-process `tcsetattr` has neither failure mode: it needs no child process, no working directory, and reports failure via a return code.

The termios snapshot is treated as an opaque byte blob. Platform selection, the POSIX ABI, controlling-terminal writes, and flow-control behavior live in `Selkie::App::Internal::TerminalPlatform`, shared with snapshot tests. On Windows those operations are explicit no-ops, before any POSIX path or symbol can be reached.

