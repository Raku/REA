NAME
====

Selkie::App::Internal::ScreenModalLifecycle - internal screen and modal lifecycle role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.screen-manager`, `Selkie::App.root`, `Selkie::App.add-screen`, `Selkie::App.switch-screen`, `Selkie::App.show-modal`, `Selkie::App.close-modal`, and `Selkie::App.has-modal` from application code.

### method close-modal-via-esc

```raku
method close-modal-via-esc() returns Nil
```

Esc-driven dismissal: a no-op unless a modal is open and that modal's `dismissable` attribute allows it, so a modal built with `:!dismissable` can only ever be closed programmatically (its own `.close`, or `Selkie::App.close-modal` called by application code).

