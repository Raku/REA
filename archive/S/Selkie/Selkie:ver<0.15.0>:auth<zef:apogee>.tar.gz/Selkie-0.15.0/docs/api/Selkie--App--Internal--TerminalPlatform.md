NAME
====

Selkie::App::Internal::TerminalPlatform - platform boundary for terminal lifecycle operations

DESCRIPTION
===========

Internal implementation detail shared by `Selkie::App` and `Selkie::Test::Snapshot`. All access to the POSIX controlling-terminal path, termios ABI, flow-control command, and terminal-related signals is selected here. Windows deliberately exposes no controlling-terminal or Raku signal operations: its console is managed by notcurses.

Resize on Windows
-----------------

Windows has no `SIGWINCH`, and — unlike earlier releases — no resize *input event* either. notcurses drives the console in pure VT input mode, where the byte stream is consumed with `read()`; mixing Win32 `INPUT_RECORD`s into that stream can signal the console handle for a record `read()` cannot consume, wedging the input thread. `ENABLE_WINDOW_INPUT` is therefore left off, and no resize key is ever delivered.

`Selkie::App`'s render loop instead polls the console viewport at a deliberately low rate through `windows-console-dimensions`, and only performs the (comparatively expensive) resize handling when the reported geometry actually differs from the current one.

SUBROUTINES
===========

windows-console-dimensions
--------------------------

    my @dims = windows-console-dimensions();   # (rows, cols), or () on failure

Read-only query of the Windows console viewport, returning a two-element `(rows, cols)` list. Returns an **empty** list on any platform other than Windows, when the standard output handle is not a console (a redirected or piped stdout), or when the geometry comes back degenerate — so callers must check `.elems == 2` rather than assuming two values.

Unlike `notcurses_refresh`, this neither invalidates notcurses's rendered-frame state nor emits any terminal output, which is what makes it safe to call on a timer.

