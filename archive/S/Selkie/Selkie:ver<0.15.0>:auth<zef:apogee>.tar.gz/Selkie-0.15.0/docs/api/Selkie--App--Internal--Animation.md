NAME
====

Selkie::App::Internal::Animation - internal tween-group and animation-refcount role for Selkie::App

DESCRIPTION
===========

Implementation detail composed by `Selkie::App`. Use `Selkie::App.tweens`, `Selkie::App.begin-animation`, `Selkie::App.end-animation`, and `Selkie::App.animating` from application code, and [Selkie::Tween](Selkie--Tween.md) for the animation primitives themselves.

Two pieces of state live here:

  * The **animation refcount** — an `atomicint` that the render loop reads once per frame to decide whether to bypass the idle ladder. Held separately from the tween group so that non-interpolated animation (a spinner while a job runs) can pin the loop too.

  * The **lazy tween group** — created on first use of `tweens`, at which point exactly one `'selkie-tweens'` frame callback is registered. Apps that never animate never allocate the group and never pay for the callback; apps that do pay one empty-array check per frame while idle.

The refcount is atomic because `begin-animation` / `end-animation` are public API and a store handler running on a worker thread is an entirely plausible caller. The tween group is not thread-safe and is only ever touched from the app thread's frame callback.

