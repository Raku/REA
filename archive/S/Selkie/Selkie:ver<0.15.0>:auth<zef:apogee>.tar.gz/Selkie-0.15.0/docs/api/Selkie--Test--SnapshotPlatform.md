NAME
====

Selkie::Test::SnapshotPlatform - platform fd adapter for snapshot testing

DESCRIPTION
===========

Internal implementation detail used by `Selkie::Test::Snapshot`.

