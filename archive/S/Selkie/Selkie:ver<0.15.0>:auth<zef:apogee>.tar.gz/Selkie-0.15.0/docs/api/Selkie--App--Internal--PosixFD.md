NAME
====

Selkie::App::Internal::PosixFD - shared POSIX process-library fd bindings

DESCRIPTION
===========

Internal raw ABI boundary for `dup`, `dup2`, and `close`. Callers retain their own semantic adapters and must select a POSIX branch before invoking these routines. In particular, these integer descriptors must never be passed to a Windows CRT DLL: official Windows MoarVM owns a private `/MT` descriptor table.

