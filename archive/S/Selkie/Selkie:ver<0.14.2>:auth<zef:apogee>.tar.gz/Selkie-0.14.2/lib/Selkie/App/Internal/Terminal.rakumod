=begin pod

=head1 NAME

Selkie::App::Internal::Terminal - internal terminal cleanup role for Selkie::App

=head1 DESCRIPTION

Implementation detail composed by C<Selkie::App>. It is not part of the stable
1.0 application API.

Captures the terminal's C<termios> state before notcurses enters raw-style
mode and restores it during shutdown. The capture/restore pair is implemented
with in-process C<tcgetattr>/C<tcsetattr> NativeCall bindings rather than by
shelling out to C<stty>. Spawning a child process during shutdown proved
fragile in two ways seen in the wild:

=item If the process's working directory has been deleted or renamed while
the app was running, C<posix_spawn> fails with ENOENT before the command
even runs — the C<stty> restore silently can't happen.

=item A failed spawn surfaces as an C<X::Proc::Unsuccessful> broken on a
thread-pool thread, which escapes a caller-side C<try> and can propagate
out of C<Selkie::App.shutdown>, skipping C<notcurses_stop> and the
escape-sequence backstop entirely — the exact wedged-terminal outcome the
restore existed to prevent.

An in-process C<tcsetattr> has neither failure mode: it needs no child
process, no working directory, and reports failure via a return code.

The termios snapshot is treated as an opaque byte blob: C<tcgetattr> fills
it, C<tcsetattr> replays it, and Selkie never interprets the fields. The
buffer is comfortably larger than C<struct termios> on every supported
POSIX platform (glibc/musl Linux x86_64 + aarch64, macOS arm64), so one
declaration serves all of them. On Windows there is no C</dev/tty>; every
method gates on its existence and returns early, so the POSIX symbols are
never resolved there.

=end pod

unit role Selkie::App::Internal::Terminal;

use NativeCall;

use Selkie::App::Internal::TerminalSequences;

# Opaque termios blob. struct termios is 60 bytes on glibc/musl and 72 on
# macOS arm64; 256 leaves headroom for any other libc without Selkie ever
# needing to know the layout.
my constant TERMIOS-BUF-BYTES = 256;

# TCSANOW is 0 on every platform Selkie supports (macOS, glibc, musl).
my constant TCSANOW = 0;
my constant O_RDONLY = 0;

# open(2) is variadic, but its two named parameters are register-passed
# identically to a non-variadic declaration on every supported ABI (the
# variadic mode arg is only needed with O_CREAT, which we never pass).
sub c-tty-open(Str, int32 --> int32)                   is native is symbol('open')      { * }
sub c-tty-close(int32 --> int32)                       is native is symbol('close')     { * }
sub c-tcgetattr(int32, CArray[uint8] --> int32)        is native is symbol('tcgetattr') { * }
sub c-tcsetattr(int32, int32, CArray[uint8] --> int32) is native is symbol('tcsetattr') { * }

has CArray[uint8] $!saved-tty-state;

method !emit-terminal-cleanup(--> Nil) {
    return unless '/dev/tty'.IO.e;
    my $tty = try open('/dev/tty', :w);
    return without $tty;
    LEAVE { try $tty.close }
    try $tty.print(app-terminal-cleanup-sequence);
}

method !capture-tty-state(--> CArray[uint8]) {
    return CArray[uint8] unless '/dev/tty'.IO.e;
    my int32 $fd = c-tty-open('/dev/tty', O_RDONLY);
    return CArray[uint8] if $fd < 0;
    LEAVE { c-tty-close($fd) }
    my $buf = CArray[uint8].allocate(TERMIOS-BUF-BYTES);
    c-tcgetattr($fd, $buf) == 0 ?? $buf !! CArray[uint8];
}

method !restore-tty-state(--> Nil) {
    return without $!saved-tty-state;
    return unless '/dev/tty'.IO.e;
    my int32 $fd = c-tty-open('/dev/tty', O_RDONLY);
    return if $fd < 0;
    LEAVE { c-tty-close($fd) }
    c-tcsetattr($fd, TCSANOW, $!saved-tty-state);
}
