use v6.d;
use Syndicate::Item;
use Syndicate::Utils;

unit role Syndicate::Feed:ver<0.0.1>:auth<zef:sasha>;

has Str $.title;
has Str $.link;
has Str $.description;
has Str $.generator;
has Str $.language;
has @!items of Syndicate::Item is built;
method items() { @!items.List }
# Caches assume the feed object is immutable after construction.
# Any mutation to attributes after the first call to .Str or .to-hash
# will not be reflected in the cached output.
has Str $!cached-str;
has Lock $!cache-lock = Lock.new;
# Item hashes are built once and deep-cloned on every call so callers can
# never mutate the cache (see sanitize), mirroring the JSONFeed cache.
has $!cached-item-hashes;

method to-hash(:$clone = True) {
    self.to-hash-common(:$clone)
}

method to-hash-common(:$clone = True) {
    my %h;
    %h<title>       = $.title       if $.title.defined;
    %h<link>        = $.link        if $.link.defined;
    %h<description> = $.description if $.description.defined;
    %h<generator>   = $.generator   if $.generator.defined;
    %h<language>    = $.language    if $.language.defined;
    if @!items {
        # Guarded by the cache lock so concurrent to-hash calls never race
        # the lazy build (the write is idempotent, but this matches the
        # lock-discipline of Str/JSONFeed).
        $!cache-lock.protect: {
            $!cached-item-hashes //= @!items.map(*.to-hash).Array;
        }
        # Cloned per call so callers can never mutate the cache (see
        # sanitize); :!clone opts out of the O(items) copy for hot paths.
        %h<items> = $clone
            ?? $!cached-item-hashes.map({ sanitize($_) }).Array
            !! $!cached-item-hashes;
    }
    %h
}

method Str {
    $!cached-str // $!cache-lock.protect: {
        $!cached-str //= '<?xml version="1.0" encoding="UTF-8"?>' ~ "\n" ~ self.XML.Str
    }
}

=begin pod

=head1 NAME

Syndicate::Feed - Common feed role

=head1 DESCRIPTION

All feed types (RSS, Atom, JSONFeed) do this role, providing a uniform
interface for accessing common feed metadata.

=head1 ATTRIBUTES

=item C<$.title> - Feed title
=item C<$.link> - Feed link/home page URL
=item C<$.description> - Feed description/subtitle
=item C<$.generator> - Generator name (e.g., "Syndicate")
=item C<$.language> - Feed language code (e.g., "en")
=item C<@.items> - Array of L<C<Syndicate::Item>|rakudoc:Syndicate::Item> objects

=end pod
