[![Actions Status](https://github.com/massa/SSH-LibSSH-Tunnel/actions/workflows/test.yml/badge.svg)](https://github.com/massa/SSH-LibSSH-Tunnel/actions)

NAME
====

SSH::LibSSH::Tunnel - blah blah blah

SYNOPSIS
========

```raku
use SSH::LibSSH::Tunnel;
```

DESCRIPTION
===========

SSH::LibSSH::Tunnel is a library (based on SSH::LibSSH) to simplify the setup of forwarding SSH tunnels.

AUTHOR
======

Humberto Massa <humbertomassa@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2023 Humberto Massa

This library is free software; you can redistribute it and/or modify it under either the Artistic License 2.0 or the LGPL v3.0, at your convenience.

