perl6sum
========

Sum:: Perl6 modules implementing checksums, hashes, etc.


