# Sparky::JobApi

API to run Sparky Jobs

[![SparrowCI](https://ci.sparrowhub.io/project/gh-melezhik-sparky-job-api/badge)](https://ci.sparrowhub.io)

# Installation

```bash
zef install Sparky::JobApi
```

# Documentation

This module is not meant to be used standalone, please read [Sparky Job API](https://github.com/melezhik/sparky#job-api) for details.

# Author

Alexey Melezhik

