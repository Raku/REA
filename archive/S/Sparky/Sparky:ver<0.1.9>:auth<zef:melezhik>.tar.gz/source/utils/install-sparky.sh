sparrowdo \
--desc="install sparky" \
--localhost  \
--sparrowfile=utils/install-sparky.raku \
--tags=api-token=secret \
--conf=conf/sparky-cluster.raku \
--no_sudo \
--with_sparky
