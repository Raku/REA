sparrowdo --desc="update sparky" \
--localhost  \
--sparrowfile=utils/update-sparky.raku \
--conf=conf/sparky-cluster.raku --no_sudo \
--with_sparky
