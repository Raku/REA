# 0.0.23

- remove old debug code 
- language correction in readme file

# 0.0.22

* Sparky distributuin moved to CPAN
* sparky.yaml - respect for `docker` parameter
* docker exec do not allocate pseudo tty
* format error fix

# 0.0.21

* SQL bug fix ( for project column )

# 0.0.20

* Database engine now is configurable. Yes, you can use MySQL and PostgreSQL!

# 0.0.19

* Use Data::Dump to dump config in a log

# 0.0.18

* Crontab entries check logic 

# 0.0.17

* Refactoring, child processes logic improved 

# 0.0.16

* Downstream projects
* Improved logging

# 0.0.15

Change the logic of runners spawner, trying to deal with memory leaks 

# 0.0.14

2017-07-31

* Improved web ui ( adjusted twitter bootstrap theme )

# 0.0.13

2017-07-28

* Improved sparky-runner.pl6 logic, when gets run standalone

# 0.0.12

2017-07-28

* Refactoring - `--report-root` and `--stdout` options are abolished

# 0.0.11

2017-07-27

* Minor documentation improvements

# 0.0.10

2017-07-27

* Rewrote documentation, hide some internal stuff.

# 0.0.9

2017-07-27

* Add web-ui

# 0.0.8

2017-07-26

* sparrowdo/sparky config mess bugfix 

# 0.0.7

2017-07-26

* First working version with purging old builds

# 0.0.4

2017-07-25

* Small improvements for sparky-runner default settings

# 0.0.3

2017-07-25

* Tweaked documentation a bit.

# 0.0.2

2017-07-19

* Changed logic of timeouts.
* Minor corrections in runner ( ignore crontab entries when gets run directly ).

# 0.0.1

2017-07-19

* Just a first version.
