curl -L -f https://bootswatch.com/$1/bootstrap.min.css -o public/css/bootstrap.min.css
