#!/bin/bash

raku -I../lib ../bin/check-journal journal.bad
