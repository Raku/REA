# Sparrowdo tests migration progress

# done

- +asserts
- +asserts-http-ok
- +bash
- +copy-local-file
- +cpan
- +directory
- +files
- +git
- +group
- +hello-world.pl6
- +templates
- +packages
- +user
- +systemd
- +df-check
- +scp
- +ssh
- +zef
- +service
- +read-config

# skiped

* -hostname
* -minoca
* -runtime-variables



