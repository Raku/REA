## Games::BubbleBreaker – a mouse based logic game

### Installation

This game requires `libSDL` and `libSDL_mixer`. On Debian-based systems
you can install these with:

```bash
sudo apt install libsdl1.2-dev libsdl-mixer1.2-dev
```

### Running

```bash
perl6 bin/bubble-breaker.p6
```
