#| Locate -- and if necessary compile -- the small C bridge described in
#| resources/duckdb-result-shim.c.
#|
#| Why this module exists
#| ======================
#| NativeCall passes a CStruct argument as a pointer to the struct.  On the
#| Microsoft x64 ABI that is also how a large struct is passed, so binding
#| `duckdb_result` by value works there by accident.  On SysV (Linux/macOS)
#| such a struct travels on the stack, so the callee reads garbage and
#| DuckDB dies with "unique_ptr NULL" as soon as a chunk is fetched.
#|
#| The bridge is a two-function shared object built on demand against the
#| very same headers and library that Alien::Libduckdb installed, so the
#| struct layout can never drift between the driver and the bridge.
unit module DB::DuckDB::Bridge;

use Alien::Libduckdb;
use DB::DuckDB::ShimCache;

#| Windows already matches NativeCall's by-pointer convention for large
#| structs; everywhere else the bridge is required.
sub needs-bridge(--> Bool) is export { !$*DISTRO.is-win }

my Str  $bridge-lib;
my Bool $resolved = False;
my Bool $available = False;

sub native-ext(--> Str)
{
    $*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so';
}

#| The C source, either from the distribution's resources or from a plain
#| `-I lib` checkout (where %?RESOURCES has no distribution to read from).
sub shim-source(--> IO::Path)
{
    my $from-res = quietly { %?RESOURCES<duckdb-result-shim.c> };
    return $from-res.IO if $from-res.defined && $from-res.IO.e;

    # lib/DB/DuckDB/Bridge.rakumod -> <root>/resources/duckdb-result-shim.c
    my $local = $?FILE.IO.parent.parent.parent.parent
                    .child('resources/duckdb-result-shim.c');
    $local.e ?? $local !! IO::Path;
}

my constant SHIM-PREFIX = 'libduckdb-result-shim';

sub cache-dir(--> IO::Path)
{
    %*ENV<DB_DUCKDB_SHIM_CACHE>
        ?? %*ENV<DB_DUCKDB_SHIM_CACHE>.IO
        !! $*HOME.IO.add('.local/share/DB-DuckDB');
}

sub lib-file(IO::Path $dir --> IO::Path) { $dir.add(SHIM-PREFIX ~ native-ext()) }

sub lib-stamp(IO::Path $lib --> IO::Path) { IO::Path.new($lib.absolute ~ '.abi') }

#| Which source produced a library: a content hash of the C file, not its
#| mtime.  The mtime comparison this used to do cannot work on this Rakudo,
#| which reports a negative Instant for files written seconds ago -- a freshly
#| compiled bridge then looks older than its own source and is rebuilt on
#| every run.
#|
#| FNV-1a rather than `sha1`: that method lives in Digest::SHA1, not in core,
#| and pulling in a dependency to fingerprint a 3 KB file is not a trade worth
#| making.  Collisions only cost a stale rebuild, never correctness, because
#| the fingerprint decides "reuse or recompile", nothing else.
sub source-fingerprint(IO::Path $src --> Str)
{
    my uint64 $hash = 0xcbf29ce484222325;
    for $src.slurp(:bin).list -> uint8 $byte {
        $hash = (($hash +^ $byte) * 0x100000001b3) +& 0xFFFFFFFFFFFFFFFF;
    }
    sprintf('%016x', $hash);
}

sub lib-fingerprint(IO::Path $lib --> Str)
{
    my $stamp = lib-stamp($lib);
    return '' unless $stamp.e;
    (try { $stamp.slurp.trim }) // '';
}

#| Shared name first, then per-process builds left behind when the shared name
#| was mapped by another process and could not be replaced.
sub cached-libs(IO::Path $dir --> List)
{
    my $canon = lib-file($dir);
    my @private = $dir.d
        ?? quietly {
                dir($dir).grep({
                    .f
                    && .basename.starts-with(SHIM-PREFIX ~ '-')
                    && .basename.ends-with(native-ext)
                }).sort({ (try { .modified.Instant } // 0) }).reverse
            }
        !! ();
    my @out;
    @out.push: $canon if $canon.e;
    @out.append: |@private;
    @out.List;
}

#| Compile the bridge when no cached build matches the current source.
#| Returns an undefined IO::Path when the source or a working compiler is
#| missing.
sub build-shim(--> IO::Path)
{
    my $src = shim-source();
    return IO::Path unless $src.defined;

    my $dir  = cache-dir();
    my $want = source-fingerprint($src);

    for cached-libs($dir) -> $lib {
        next unless $lib.e;
        return $lib if lib-fingerprint($lib) eq $want;
    }

    my $inc    = Alien::Libduckdb::include-dir().absolute;
    my $libdir = Alien::Libduckdb::lib-dir().absolute;
    my $cc     = %*ENV<CC> // 'cc';

    $dir.mkdir unless $dir.d;

    # Build under a private name, then move it into place: the shared name may
    # be mapped by another process, and a mapped library cannot be replaced on
    # any platform -- unlinking it would pull the bridge out from under the
    # process that is using it.
    my $out = $dir.add(SHIM-PREFIX ~ "-{$*PID}-{now.Int}" ~ native-ext());

    my @cmd = $cc, '-shared', '-fPIC', '-O2',
              '-o', $out.absolute, $src.absolute,
              '-I' ~ $inc,
              '-L' ~ $libdir, '-lduckdb',
              '-Wl,-rpath,' ~ $libdir;

    my $ok = try {
        my $proc = run(|@cmd, :out, :err);
        my $stderr-text = $proc.err.slurp(:close);
        $proc.out.slurp(:close);
        note "DB::DuckDB::Bridge: cc failed:\n$stderr-text"
            if $proc.exitcode != 0 && $stderr-text.chars;
        $proc.exitcode == 0;
    } // False;

    unless $ok {
        try { $out.unlink }
        note "DB::DuckDB::Bridge: could not compile the by-value shim; "
          ~ "falling back to the raw symbols (chunk reads will fail on "
          ~ "this ABI).  Set CC= if your compiler is not `cc`.";
        return IO::Path;
    }

    my $canon = lib-file($dir);
    my $stale = $canon.e && lib-fingerprint($canon) ne $want;
    my $final = $out;
    if $canon.e.not || $stale {
        my $moved = try {
            $canon.unlink if $stale;
            $out.rename($canon);
            $canon;
        } // Nil;
        $final = $moved.defined && $moved.e ?? $moved !! $out;
    }

    try { lib-stamp($final).spurt: $want ~ "\n" }
    $final;
}

#| Absolute path of the bridge library, or an empty string when the plain
#| libduckdb symbols must be used instead.  Computed once per process.
sub bridge-lib(--> Str) is export
{
    return $bridge-lib if $resolved;
    $resolved = True;

    unless needs-bridge() {
        $available = False;
        return $bridge-lib = '';
    }

    if %*ENV<DB_DUCKDB_SHIM> -> $explicit {
        return $bridge-lib = $explicit
            if $explicit.chars && $explicit.IO.e;
    }

    my $out = build-shim();
    $available = $out.defined && $out.e;
    $bridge-lib = $available ?? $out.absolute !! '';

    # Leftovers from earlier cache layouts; no ABI argument because the stamp
    # here is a source fingerprint, not a number.
    sweep(cache-dir(), SHIM-PREFIX, keep => ($available ?? $out !! Nil));

    $bridge-lib;
}

#| True when the bridge was found/built, i.e. when symbol names must be
#| translated to their `dbd_*_p` form.
sub bridge-active(--> Bool) is export
{
    bridge-lib();
    $available;
}

#| Map a libduckdb symbol to the name it carries in the bridge.
#| duckdb_fetch_chunk -> dbd_fetch_chunk_p
sub bridge-symbol(Str $name --> Str) is export
{
    return $name unless bridge-active();
    'dbd_' ~ $name.subst(/^ 'duckdb_' /, '') ~ '_p';
}
