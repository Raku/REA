use DB::Result;
use DB::DuckDB::Native;
use DB::DuckDB::Decoder;
use DB::DuckDB::ColumnView;
use DB::DuckDB::Chunk;
use DB::DuckDB::Error;
use NativeCall;
use nqp;

# The optional C VARCHAR unpacker, resolved at most once per process.  It is
# loaded with `require` (not `use`) because the module dies when the shim
# could not be compiled, and that must not take the whole driver down: the
# per-value decoder remains a correct fallback.
my $varchar-unpacker;
my $varchar-joiner;
my $temporal-joiner;
my $decimal-joiner;
my Bool $varchar-probed = False;

#| Load the shim module once and cache both entry points.
sub probe-varchar-shim(--> Nil)
{
    return if $varchar-probed;
    $varchar-probed = True;

    # Escape hatch, also used by the tests to compare both code paths.
    if %*ENV<DB_DUCKDB_NO_VARCHAR_SHIM> {
        $varchar-unpacker = Nil;
        $varchar-joiner    = Nil;
        return;
    }

    # The join path can be disabled on its own as well: it is the newer of the
    # two, and tests pin both halves against each other.
    my Bool $allow-join = !%*ENV<DB_DUCKDB_NO_VARCHAR_JOIN>;

    my $found = (try {
        my $mod = (require ::('DB::DuckDB::VarcharShim::Native'));
        # The shim declares its entry points with `our sub`, so they live in
        # the module's WHO table under their sigil-prefixed name.  Looking the
        # symbol up by name would work too but yields a soft Failure when the
        # module was precompiled with an older revision, which then blows up
        # later inside a DESTROY -- so probe the table and check it is Callable.
        my $pick = -> $name {
            my $sub = $mod.WHO{$name};
            $sub.defined && $sub ~~ Callable ?? $sub !! Nil;
        };

        # A cached .dll built by an older driver may be missing the newer
        # entry points.  shim-abi() says what it supports; when the probe is
        # absent entirely the library predates the ABI counter, so the join
        # path is off and only the offset-table unpacker is trusted.
        #
        # Calling into the library is also the only way to know it loads:
        # `require` succeeds even when the build failed or the .dll is
        # missing, and the failure would otherwise surface much later, in the
        # middle of a decode.  An ABI of 0 means "could not prove it loads",
        # and then nothing from this module is used at all.
        my $abi = 0;
        if $mod.WHO<&shim-abi>.defined {
            $abi = (try { $mod.WHO<&shim-abi>() }) // 0;
        }
        elsif $mod.WHO<&string-layout>.defined {
            $abi = (try { $mod.WHO<&string-layout>(); 1 }) // 0;
        }
        {
            unpack   => ($abi >= 1 ?? $pick('&unpack-varchar') !! Nil),
            join     => ($abi >= 2 ?? $pick('&join-varchar') !! Nil),
            # ABI 4 renumbered the temporal kind codes (they start at 1 now,
            # because 0 is false in Raku); an ABI 3 library would read them
            # as a different type, so only 4 and later may drive this path.
            temporal => ($abi >= 4 ?? $pick('&join-temporal') !! Nil),
            # ABI 5 added the DECIMAL renderer.
            decimal  => ($abi >= 5 ?? $pick('&join-decimal') !! Nil),
        };
    }) // Nil;
    $varchar-unpacker = ($found.defined ?? $found<unpack> !! Nil) // Nil;
    $varchar-joiner   = $allow-join && $found.defined
        ?? ($found<join> // Nil) !! Nil;

    # The temporal renderer is switched separately: it replaces the Raku
    # renderers, which the tests pin against DuckDB's own VARCHAR cast.
    if %*ENV<DB_DUCKDB_NO_TEMPORAL_SHIM> {
        $temporal-joiner = Nil;
    }
    else {
        $temporal-joiner = $found.defined ?? ($found<temporal> // Nil) !! Nil;
    }

    # Same switch for the DECIMAL renderer, which is the newest entry point.
    if %*ENV<DB_DUCKDB_NO_DECIMAL_SHIM> {
        $decimal-joiner = Nil;
    }
    else {
        $decimal-joiner = $found.defined ?? ($found<decimal> // Nil) !! Nil;
    }
}

#| The separator-joined VARCHAR decoder (one decode, one split per chunk).
sub varchar-joiner()
{
    probe-varchar-shim();
    $varchar-joiner;
}

sub varchar-unpacker()
{
    probe-varchar-shim();
    $varchar-unpacker;
}

#| The C temporal renderer, or Nil when the shim is unavailable.
sub temporal-joiner()
{
    probe-varchar-shim();
    $temporal-joiner;
}

#| The C DECIMAL renderer, or Nil when the shim is unavailable.
sub decimal-joiner()
{
    probe-varchar-shim();
    $decimal-joiner;
}

# The DKD_TEMPORAL_* codes of resources/duckdb-varchar-shim.c.  Keeping the
# numbers on the Raku side lets one filler cover every temporal type instead
# of one branch per DuckDB type id.  They start at 1 because the caller binds
# the result of temporal-kind() with `-> $kind`, and 0 is false in Raku.
my constant TEMPORAL-DATE    = 1;
my constant TEMPORAL-TS-US   = 2;
my constant TEMPORAL-TS-S    = 3;
my constant TEMPORAL-TS-MS   = 4;
my constant TEMPORAL-TS-NS   = 5;
my constant TEMPORAL-TIME-US = 6;
my constant TEMPORAL-TIME-NS = 7;

#| Code for a DuckDB type id the C shim can render, or Nil.  TIMESTAMP_TZ and
#| TIMESTAMP_TZ_NS are absent on purpose: their text form carries the session
#| time zone, which the raw count alone cannot reproduce.
my sub temporal-kind(int32 $tid --> UInt)
{
    return TEMPORAL-DATE    if $tid == DUCKDB_TYPE_DATE;
    return TEMPORAL-TS-US   if $tid == DUCKDB_TYPE_TIMESTAMP;
    return TEMPORAL-TS-S    if $tid == DUCKDB_TYPE_TIMESTAMP_S;
    return TEMPORAL-TS-MS   if $tid == DUCKDB_TYPE_TIMESTAMP_MS;
    return TEMPORAL-TS-NS   if $tid == DUCKDB_TYPE_TIMESTAMP_NS;
    return TEMPORAL-TIME-US if $tid == DUCKDB_TYPE_TIME;
    return TEMPORAL-TIME-NS if $tid == DUCKDB_TYPE_TIME_NS;
    Nil;
}

#========================================================================
# Bulk column fillers
#
# One whole chunk of a typed vector is appended to @dst in a plain typed
# loop.  When the vector carries a validity bitmap the NULL test is done a
# 64-bit word at a time inside that same loop: a column containing NULLs
# then costs a couple of integer ops per value instead of falling back to
# the per-value decoder, which was 5-9x slower (10% NULL used to make a
# BIGINT column 5.7x slower than the same column without NULLs).
#
# `Any` is the NULL placeholder everywhere, matching what the per-value
# decoders return.
#========================================================================

# --- temporal -----------------------------------------------------------
# DuckDB renders a DATE or a TIMESTAMP by building a Value and casting it to
# VARCHAR through ICU.  Measured on this machine that is ~6 us per DATE and
# ~240 us per TIMESTAMP: the text form of a timestamp costs hundreds of times
# more than the int64 it was built from, which makes a plain
# `SELECT ts FROM t` look like a slow query when the engine is actually done
# in milliseconds.
#
# The layout is trivial, so the text is assembled here instead: a DATE is an
# int32 day count since 1970-01-01, a TIMESTAMP an int64 count of its own unit
# since the same epoch, a TIME an int64 count since midnight.  Every renderer
# below takes that integer and produces exactly the string DuckDB would have.

#| Zero pad to two digits.
my sub pad2(Int $v --> Str) { $v < 10 ?? '0' ~ $v !! $v.Str }

#| Zero pad to four digits.
my sub pad4(Int $v --> Str)
{
    return $v.Str if $v > 999;
    my Str $s = $v.Str;
    ('0' x (4 - $s.chars)) ~ $s;
}

#| Day count since 1970-01-01 -> (year, month, day).  Howard Hinnant's
#| civil_from_days; Raku's `div` already floors, which is what the algorithm
#| assumes, so negative day counts (dates before the epoch) need no fixup.
my sub civil-from-days(Int $z --> List)
{
    my Int $u   = $z + 719468;
    my Int $era = $u div 146097;
    my Int $doe = $u - $era * 146097;
    my Int $yoe = ($doe - $doe div 1460 + $doe div 36524 - $doe div 146096) div 365;
    my Int $doy = $doe - (365 * $yoe + $yoe div 4 - $yoe div 100);
    my Int $mp  = (5 * $doy + 2) div 153;
    my Int $d   = $doy - (153 * $mp + 2) div 5 + 1;
    my Int $m   = $mp < 10 ?? $mp + 3 !! $mp - 9;
    my Int $y   = $yoe + $era * 400 + ($m <= 2 ?? 1 !! 0);
    ($y, $m, $d);
}

#| 'YYYY-MM-DD'.  Dates before year 1 print the way DuckDB prints them: the
#| astronomical year 0 is "0001" with a " (BC)" suffix, year -1 is "0002",
#| and so on.
my sub day-text(Int $z --> Str)
{
    my ($y, $m, $d) = civil-from-days($z);
    return pad4(1 - $y) ~ '-' ~ pad2($m) ~ '-' ~ pad2($d) ~ ' (BC)' if $y <= 0;
    pad4($y) ~ '-' ~ pad2($m) ~ '-' ~ pad2($d);
}

#| 'HH:MM:SS' with a fractional part only when there is one, $digits wide
#| including the trailing zeros DuckDB keeps inside the fraction... and only
#| inside: a value of exactly .716500 is printed as .7165, so the fraction is
#| trimmed at the right end.
my sub clock-text(Int $secs, Int $frac, Int $digits --> Str)
{
    my Str $base = pad2($secs div 3600) ~ ':' ~ pad2(($secs div 60) % 60)
                 ~ ':' ~ pad2($secs % 60);
    return $base if $digits == 0 || $frac == 0;
    my Str $f = $frac.abs.Str;
    $f = ('0' x ($digits - $f.chars)) ~ $f if $f.chars < $digits;
    $f = $f.subst(/ '0'+ $ /, '');
    $f.chars ?? $base ~ '.' ~ $f !! $base;
}

#| TIMESTAMP text: $v counts $per-sec units since 1970-01-01T00:00:00Z.
my sub stamp-text(Int $v, Int $per-sec, Int $digits --> Str)
{
    # `div` floors, so a pre-epoch value splits into a whole day plus a
    # non-negative time of day -- exactly the layout the formatter needs.
    my Int $secs = $v div $per-sec;
    my Int $frac = $v - $secs * $per-sec;
    my Int $days = $secs div 86400;
    my Int $tod  = $secs - $days * 86400;
    day-text($days) ~ ' ' ~ clock-text($tod, $frac, $digits);
}

#| TIME text: $v counts $per-sec units since midnight.
my sub time-text(Int $v, Int $per-sec, Int $digits --> Str)
{
    clock-text($v div $per-sec, $v - ($v div $per-sec) * $per-sec, $digits);
}

#| Push one rendered column, honouring the validity bitmap.  The renderer is
#| a named sub reference, so the loop stays monomorphic per column.
my sub push-rendered(@dst, $a, Pointer $validity, uint64 $size, &render --> Nil)
{
    my uint64 $r = 0;

    unless $validity.defined {
        loop (; $r < $size; $r++) { @dst.push: render($a[$r]) }
        return;
    }

    my CArray[uint64] $mask = nativecast(CArray[uint64], $validity);
    while $r < $size {
        my uint64 $word = $mask[$r div 64];
        my uint64 $stop = $r + 64;
        $stop = $size if $stop > $size;
        my uint64 $bit = 1;
        loop (; $r < $stop; $r++) {
            if $word +& $bit { @dst.push: render($a[$r]) } else { @dst.push: Any }
            $bit = $bit +< 1 if $r + 1 < $stop;
        }
    }
}

#| Push a timestamp column whose unit varies per type: one closure per unit,
#| built once per column rather than per value.
my sub push-stamps(@dst, $a, Pointer $validity, uint64 $size,
                   Int $per-sec, Int $digits --> Nil)
{
    push-rendered(@dst, $a, $validity, $size,
                  -> Int $v --> Str { stamp-text($v, $per-sec, $digits) });
}

my sub push-times(@dst, $a, Pointer $validity, uint64 $size,
                  Int $per-sec, Int $digits --> Nil)
{
    push-rendered(@dst, $a, $validity, $size,
                  -> Int $v --> Str { time-text($v, $per-sec, $digits) });
}

my sub push-days(@dst, $a, Pointer $validity, uint64 $size --> Nil)
{
    push-rendered(@dst, $a, $validity, $size, &day-text);
}

# --- temporal as Raku values (:typed) -----------------------------------
# The renderers above exist to produce the same text DuckDB would.  The
# typed path is the opposite trade: the caller wants a value it can do date
# arithmetic with, so the integer payload is turned straight into a Date or
# a DateTime -- formatting the string first and parsing it back would pay
# both costs.

#| Floored division: `div` truncates towards zero, which puts pre-1970
#| timestamps in the wrong second and makes the fractional part negative.
my sub floor-div(Int $a, Int $b --> Int) { ($a - $a % $b) div $b; }

my sub push-date-typed(@dst, $a, Pointer $validity, uint64 $size --> Nil)
{
    push-rendered(@dst, $a, $validity, $size,
                  -> Int $days { Date.new(1970, 1, 1).later(days => $days) });
}

#| TIMESTAMP_* as a UTC `DateTime`.  A DuckDB TIMESTAMP carries no zone, so
#| the wall clock it stores is handed over as-is and UTC is the only label
#| that does not silently shift it; sub-second digits survive as a Rat.
my sub push-stamps-typed(@dst, $a, Pointer $validity, uint64 $size,
                         Int $per-sec --> Nil)
{
    push-rendered(@dst, $a, $validity, $size,
                  -> Int $v {
                      my Int $secs = floor-div($v, $per-sec);
                      my Int $frac = $v - $secs * $per-sec;
                      $frac == 0
                          ?? DateTime.new($secs, timezone => 0)
                          !! DateTime.new($secs + $frac / $per-sec)
                  });
}

#| Fill a DATE / TIMESTAMP column with Raku values.  TIME has no value type
#| to map to (a Duration cannot say "24:00:00" without picking a day), and
#| the TZ variants never reach here, so both keep their text form.
my sub push-temporal-typed(@dst, Pointer $data, Pointer $validity,
                           uint64 $size, UInt $kind --> Nil)
{
    given $kind {
        when TEMPORAL-DATE {
            push-date-typed(@dst, nativecast(CArray[int32], $data),
                            $validity, $size);
        }
        when TEMPORAL-TS-US {
            push-stamps-typed(@dst, nativecast(CArray[int64], $data),
                              $validity, $size, 1_000_000);
        }
        when TEMPORAL-TS-S {
            push-stamps-typed(@dst, nativecast(CArray[int64], $data),
                              $validity, $size, 1);
        }
        when TEMPORAL-TS-MS {
            push-stamps-typed(@dst, nativecast(CArray[int64], $data),
                              $validity, $size, 1_000);
        }
        when TEMPORAL-TS-NS {
            push-stamps-typed(@dst, nativecast(CArray[int64], $data),
                              $validity, $size, 1_000_000_000);
        }
        default {
            die "push-temporal-typed called for temporal kind $kind";
        }
    }
}

#| Fill a DATE / TIMESTAMP / TIME column.
#|
#| The C shim renders the whole chunk in one call and the caller splits the
#| joined text once, so the per-value cost is a Split element instead of a
#| date decomposition plus a Str build plus a push: measured 10.5 us per
#| TIMESTAMP through the Raku renderers against ~1 us through the shim.  The
#| renderers above stay as the fallback for machines without a C compiler,
#| and are what the tests compare DuckDB's own output against.
my sub push-temporal(@dst, Pointer $data, Pointer $validity, uint64 $size,
                     UInt $kind --> Nil)
{
    if $size {
        with temporal-joiner() -> &join {
            my Pointer $mask = $validity.defined ?? $validity !! Pointer;
            my $joined = join($data, $mask, $size, $kind);
            if $joined.defined {
                @dst.append: |$joined;
                return;
            }
        }
    }

    given $kind {
        when TEMPORAL-DATE {
            push-days(@dst, nativecast(CArray[int32], $data), $validity, $size);
        }
        when TEMPORAL-TS-US {
            push-stamps(@dst, nativecast(CArray[int64], $data), $validity, $size,
                        1_000_000, 6);
        }
        when TEMPORAL-TS-S {
            push-stamps(@dst, nativecast(CArray[int64], $data), $validity, $size,
                        1, 0);
        }
        when TEMPORAL-TS-MS {
            push-stamps(@dst, nativecast(CArray[int64], $data), $validity, $size,
                        1_000, 3);
        }
        when TEMPORAL-TS-NS {
            push-stamps(@dst, nativecast(CArray[int64], $data), $validity, $size,
                        1_000_000_000, 9);
        }
        when TEMPORAL-TIME-US {
            push-times(@dst, nativecast(CArray[int64], $data), $validity, $size,
                       1_000_000, 6);
        }
        when TEMPORAL-TIME-NS {
            push-times(@dst, nativecast(CArray[int64], $data), $validity, $size,
                       1_000_000_000, 9);
        }
    }
}

my sub push-values(@dst, $a, Pointer $validity, uint64 $size --> Nil)
{
    my uint64 $r = 0;

    unless $validity.defined {
        loop (; $r < $size; $r++) { @dst.push: $a[$r] }
        return;
    }

    # The validity word is fetched once per 64 values and walked with a
    # shifting bit instead of recomputing `1 +< (r % 64)` per value, and the
    # valid/NULL choice is written as an if/else rather than a ternary: the
    # ternary has to merge two branches into one temp, and measured ~25%
    # slower on a 1M value column.
    my CArray[uint64] $mask = nativecast(CArray[uint64], $validity);
    while $r < $size {
        my uint64 $word = $mask[$r div 64];
        my uint64 $stop = $r + 64;
        $stop = $size if $stop > $size;
        my uint64 $bit = 1;
        loop (; $r < $stop; $r++) {
            if $word +& $bit { @dst.push: $a[$r] } else { @dst.push: Any }
            $bit = $bit +< 1 if $r + 1 < $stop;
        }
    }
}

my sub push-bools(@dst, $a, Pointer $validity, uint64 $size --> Nil)
{
    my uint64 $r = 0;

    unless $validity.defined {
        loop (; $r < $size; $r++) { @dst.push: so $a[$r] }
        return;
    }

    my CArray[uint64] $mask = nativecast(CArray[uint64], $validity);
    while $r < $size {
        my uint64 $word = $mask[$r div 64];
        my uint64 $stop = $r + 64;
        $stop = $size if $stop > $size;
        my uint64 $bit = 1;
        loop (; $r < $stop; $r++) {
            if $word +& $bit { @dst.push: so $a[$r] } else { @dst.push: Any }
            $bit = $bit +< 1 if $r + 1 < $stop;
        }
    }
}

#| Render one DECIMAL from its unscaled integer, using fixed-point arithmetic
#| instead of the generic text routine.  DuckDB prints a decimal with exactly
#| its scale, trailing zeros included, and so does this.
#|
#| `$trim-zero` covers the all-fraction widths: DECIMAL(9,9) prints .5 while
#| DECIMAL(10,9) prints 0.5, and the caller passes width == scale.
my sub decimal-fixed(Int $v, Int $scale, Int $div, Str $pad, Bool $trim-zero --> Str)
{
    my Bool $neg = $v < 0;
    my Int $abs  = $neg ?? -$v !! $v;
    my Int $ip   = $abs div $div;
    return ($neg ?? '-' !! '') ~ $ip.Str if $scale == 0;

    my Str $fp = ($abs % $div).Str;
    $fp = $pad.substr(0, $scale - $fp.chars) ~ $fp if $fp.chars < $scale;
    ($neg ?? '-' !! '') ~ ($trim-zero && $ip == 0 ?? '' !! $ip.Str) ~ '.' ~ $fp;
}

my sub push-decimals(@dst, $a, Pointer $validity, uint64 $size,
                     Int $scale, Int $div, Str $pad, Bool $trim-zero --> Nil)
{
    my uint64 $r = 0;

    unless $validity.defined {
        loop (; $r < $size; $r++) {
            @dst.push: decimal-fixed($a[$r], $scale, $div, $pad, $trim-zero);
        }
        return;
    }

    my CArray[uint64] $mask = nativecast(CArray[uint64], $validity);
    while $r < $size {
        my uint64 $word = $mask[$r div 64];
        my uint64 $stop = $r + 64;
        $stop = $size if $stop > $size;
        my uint64 $bit = 1;
        loop (; $r < $stop; $r++) {
            if $word +& $bit {
                @dst.push: decimal-fixed($a[$r], $scale, $div, $pad, $trim-zero);
            }
            else {
                @dst.push: Any;
            }
            $bit = $bit +< 1 if $r + 1 < $stop;
        }
    }
}

#| DECIMAL values wider than 18 digits live in a 128-bit slot.  Most of them
#| still fit in an int64 (that is, the high word is the sign extension), so
#| those take the same fixed-point path; the rest build the 128-bit integer
#| first, which is exact but slower.
my sub push-decimals-huge(@dst, Pointer $data, Pointer $validity, uint64 $size,
                          Int $scale, Int $div, Str $pad, Bool $trim-zero --> Nil)
{
    my CArray[int64] $s = nativecast(CArray[int64], $data);

    my sub value-at(uint64 $i --> Int) {
        my int64 $lo = $s[$i * 2];
        my int64 $hi = $s[$i * 2 + 1];
        # A high word of -1 with a negative low word is the sign extension of
        # an int64, where the low word already holds the whole value.  With a
        # positive low word the pair is a genuine 128 bit negative (say
        # -10**19) and has to go through the wide formula below.
        return $lo.Int if $hi == -1 && $lo < 0;
        # Otherwise the low word is an unsigned magnitude: values above the
        # int64 range (up to 2**64-1) are common for DECIMAL(19..20).
        my Int $magnitude = $lo < 0 ?? $lo + 18446744073709551616 !! $lo;
        return $magnitude if $hi == 0;
        $hi.Int * 18446744073709551616 + $magnitude;
    }

    my uint64 $r = 0;

    unless $validity.defined {
        loop (; $r < $size; $r++) {
            @dst.push: decimal-fixed(value-at($r), $scale, $div, $pad, $trim-zero);
        }
        return;
    }

    my CArray[uint64] $mask = nativecast(CArray[uint64], $validity);
    while $r < $size {
        my uint64 $word = $mask[$r div 64];
        my uint64 $stop = $r + 64;
        $stop = $size if $stop > $size;
        my uint64 $bit = 1;
        loop (; $r < $stop; $r++) {
            if $word +& $bit {
                @dst.push: decimal-fixed(value-at($r), $scale, $div, $pad, $trim-zero);
            }
            else {
                @dst.push: Any;
            }
            $bit = $bit +< 1 if $r + 1 < $stop;
        }
    }
}

#| Copy an ENUM's dictionary out of the logical type.  DuckDB hands out a
#| freshly allocated string per entry, so each entry is decoded into a Str
#| and freed straight away.  The dictionary is read once per chunk and holds
#| tens of entries, which is nothing next to the rows it serves.
my sub enum-dictionary($lt --> List)
{
    my uint32 $n = duckdb-enum-dictionary-size($lt);
    my @dict;

    loop (my uint32 $i = 0; $i < $n; $i++) {
        my Pointer $p = duckdb-enum-dictionary-value($lt, $i);
        if $p.defined {
            @dict.push: nativecast(Str, $p);
            duckdb-free($p);
        }
        else {
            @dict.push: Str;
        }
    }

    @dict.List;
}

#| Push one ENUM vector: read the key, look the text up.  Rows that share a
#| key share one Str object, so unlike VARCHAR this path allocates nothing
#| per value and hands the GC nothing to collect.
my sub push-enums(@dst, $a, Pointer $validity, uint64 $size, @dict --> Nil)
{
    my uint64 $r = 0;

    unless $validity.defined {
        loop (; $r < $size; $r++) { @dst.push: @dict[$a[$r]] }
        return;
    }

    my CArray[uint64] $mask = nativecast(CArray[uint64], $validity);
    while $r < $size {
        my uint64 $word = $mask[$r div 64];
        my uint64 $stop = $r + 64;
        $stop = $size if $stop > $size;
        my uint64 $bit = 1;
        loop (; $r < $stop; $r++) {
            if $word +& $bit {
                @dst.push: @dict[$a[$r]];
            }
            else {
                @dst.push: Any;
            }
            $bit = $bit +< 1 if $r + 1 < $stop;
        }
    }
}

#========================================================================
# Column-parallel decoding
#
# A materialised result exposes every chunk by index, and reading a vector
# is a pure read, so columns can be decoded by different threads at the
# same time.  Columns -- not chunks -- are the unit of work: one column is
# always built by exactly one thread, in chunk order, so the resulting
# Array needs no merge step at all.  Merging is what makes chunk-split
# parallel decoding pointless here: appending a value in pure Raku costs
# about a third of what decoding one costs, so a merge would eat most of
# the win.
#
# The tradeoff is that the speedup is bounded by the column count: a single
# column result stays serial, and the caller can pass :degree to cap the
# number of workers.
#========================================================================

# Rows below which the thread setup costs more than the decode it saves.
my constant PARALLEL-MIN-ROWS = 20_000;

my sub cpu-count(--> Int)
{
    with %*ENV<DB_DUCKDB_DEGREE> { return .Int if .Int > 0 }
    with %*ENV<NUMBER_OF_PROCESSORS> { return .Int if .Int > 0 }
    my $k = (try { $*KERNEL.cpu-core }) // 0;
    return $k.Int if $k > 0;
    4;
}

# Rough relative cost of decoding one value of a column, used to spread the
# columns over the workers.  Strings dominate a result far more than the
# numeric types do, and the non-vectorisable types are slower still because
# they go through a per-value callback.
my sub column-weight(Int $tid --> Int)
{
    return 4 if $tid == DUCKDB_TYPE_VARCHAR;
    return 3 if $tid == DUCKDB_TYPE_LIST || $tid == DUCKDB_TYPE_STRUCT
             || $tid == DUCKDB_TYPE_MAP  || $tid == DUCKDB_TYPE_ARRAY
             || $tid == DUCKDB_TYPE_UNION;
    return 2 if $tid == DUCKDB_TYPE_DECIMAL || $tid == DUCKDB_TYPE_HUGEINT
             || $tid == DUCKDB_TYPE_UHUGEINT;
    1;
}

class DB::DuckDB::Result does DB::Result
{
    has DuckDB-Raw-Result $.raw is required;
    has Int $.count;
    has Int $.columns;
    has Int $.rows-changed;

    has Int  $!cursor = 0;
    has Bool $!alive  = True;

    # Set when the result borrows a pooled connection that must be handed
    # back to the driver once the result is drained.
    has $!borrowed-conn;

    # --- chunk/vector state ---------------------------------------------
    has DuckDB-Data-Chunk $!chunk;
    has @!decoders;           # one Callable per column
    has @!column-types;       # duckdb_type ids, for introspection
    has uint64 $!chunk-size = 0;
    has uint64 $!chunk-pos  = 0;
    has Bool $!chunk-done = False;
    # Streaming results hand each chunk to the caller instead of keeping the
    # whole result materialised.
    has Bool $!streaming = False;

    # The most recently handed out streaming chunk, so freeing the result can
    # expire it: the chunk pointers die with the result's buffers.
    has $!live-chunk;

    # Double buffer for streaming results.  While the caller decodes the
    # chunk it holds, a worker thread is already pulling the next one out of
    # the engine, so query execution and Raku-side decoding overlap instead
    # of taking turns.  Two slots, not a deeper queue: a chunk is ~235 KB and
    # decoding one costs several times what fetching it does, so more slots
    # would only add memory and latency to the first row.
    has Channel $!pre-ch;
    has Channel $!pre-free;
    has $!pre-worker;
    has Bool $!pre-on = False;

    # Chunks fetched by column-views() that stay alive for lazy decoding.
    # duckdb_result_get_chunk hands ownership to the caller, so they have to
    # be destroyed by hand -- leaking them costs ~235 KB per 2048-row chunk.
    has @!owned-chunks;

    # Optional per-chunk column cache.  Only the column oriented readers
    # (arrays-fast/column/columns) fill it; row() and arrays() keep the
    # original per-cell path so their memory profile is unchanged.
    has @!col-buf;
    has Bool $!col-buf-ready = False;

    # Pre-built Hash rows for the current chunk (hashes fast path).
    has @!hash-buf;
    has uint64 $!hash-pos = 0;

    method attach-connection($conn --> Nil) { $!borrowed-conn = $conn }

    submethod BUILD(DuckDB-Raw-Result :$raw!,
                    :$sth,
                    Bool :$finish,
                    Bool :$streaming = False,
                    Int :$count)
    {
        $!raw     = $raw;
        $!sth     = $sth;
        $!finish  = $finish;
        $!streaming = $streaming;
        $!count   = $count // duckdb-row-count($!raw).Int;
        $!columns = duckdb-column-count($!raw).Int;
        $!rows-changed = duckdb-rows-changed($!raw).Int;

        @!column-types = (duckdb-column-type($!raw, $_) for ^$!columns).List;
    }

    method names()
    {
        return () unless $!alive;
        my @names = do for ^$!columns -> $col {
            take-cstr(duckdb-column-name($!raw, $col))
        };
        @names.List;
    }

    #| Raw duckdb_type ids, one per column.
    method column-types(--> List) { @!column-types.List }

    #| Pull the next non-empty chunk and rebuild the per-column readers.
    #| (Re)build the per-value decoders for the chunk in $!chunk.
    method !prepare-decoders(--> Nil)
    {
        @!decoders = ();
        for ^$!columns -> $col {
            my $vec = duckdb-data-chunk-get-vector($!chunk, $col);
            # The vector owns its logical type: duckdb_vector_get_column_type
            # returns a copy that we must destroy ourselves.
            my $lt = duckdb-vector-get-column-type($vec);
            @!decoders.push: build-decoder($vec, $lt);
            duckdb-destroy-logical-type($lt);
        }
    }

    #| Start the streaming prefetch worker unless it is already running.
    #| DB_DUCKDB_NO_PREFETCH=1 turns the double buffer off.
    method !prefetch-start(--> Nil)
    {
        return if $!pre-on || !$!streaming;
        return if %*ENV<DB_DUCKDB_NO_PREFETCH>;

        my Channel $ch   = Channel.new;
        my Channel $free = Channel.new;
        # Two slots: the chunk the caller holds and the one being fetched.
        $free.send: True for ^2;

        $!pre-ch   = $ch;
        $!pre-free = $free;
        $!pre-on   = True;

        my $raw := $!raw;
        $!pre-worker = start {
            loop {
                # A slot only frees up when the consumer has dropped the
                # chunk that was in it, so at most two chunks are alive.
                # A closed channel throws on receive in this Rakudo, so a
                # stop while parked here has to be caught, not awaited.
                my $slot;
                my Bool $parked = True;
                try {
                    $slot = $free.receive;
                    CATCH { default { $parked = False } }
                }
                last unless $parked;
                last unless $slot.defined;

                my $chunk = duckdb-stream-fetch-chunk($raw);
                my Bool $more = ($chunk.defined && $chunk.Bool).Bool;
                my $item = $more
                    ?? ($chunk, duckdb-data-chunk-get-size($chunk))
                    !! Nil;

                my Bool $ok = True;
                try {
                    $ch.send: $item;
                    CATCH { default { $ok = False } }
                }
                last unless $ok;
                last unless $more;
            }
            # Closing wakes a consumer that is still waiting, and turns any
            # later send into an error instead of a block.
            try { $ch.close }
            True;
        };
    }

    #| Hand a slot back to the prefetch worker, if it is running.
    method !prefetch-release(--> Nil)
    {
        with $!pre-free { try { .send: True } }
    }

    #| Next prefetched chunk, or Mu at the end of the stream.
    method !prefetch-take(--> Mu)
    {
        loop {
            my $item;
            my Bool $got = True;
            try {
                $item = $!pre-ch.receive;
                CATCH { default { $got = False } }
            }
            return Mu unless $got;
            return Mu unless $item.defined;
            my $chunk = $item[0];
            my uint64 $size = $item[1];
            return $chunk if $size > 0;
            # DuckDB may hand out an empty chunk mid-stream; drop it now and
            # carry on, returning its slot.
            duckdb-destroy-data-chunk($chunk) if $chunk.defined && $chunk.Bool;
            self!prefetch-release;
        }
    }

    #| Stop the worker and destroy whatever it had queued.  Must run before
    #| the raw result is destroyed: the worker reads from it.
    method !prefetch-stop(--> Nil)
    {
        return unless $!pre-on;
        $!pre-on = False;

        my $ch   = $!pre-ch;
        my $free = $!pre-free;
        my $w    = $!pre-worker;
        $!pre-ch     = Nil;
        $!pre-free   = Nil;
        $!pre-worker = Nil;

        # Closing the slot channel wakes a worker parked on a slot; closing
        # the queue only matters if the worker is mid-send.
        try { $free.close } if $free.defined;
        try { $ch.close }   if $ch.defined;
        await $w if $w.defined;

        if $ch.defined {
            loop {
                my $item = $ch.poll;
                last unless $item.defined;
                my $c = $item[0];
                duckdb-destroy-data-chunk($c) if $c.defined && $c.Bool;
            }
        }
    }

    method !next-chunk(--> Bool)
    {
        return False if $!chunk-done;

        if $!chunk.defined && $!chunk.Bool {
            duckdb-destroy-data-chunk($!chunk);
            # The slot the dead chunk sat in is free, so a worker parked on
            # it can start the next fetch right away.
            self!prefetch-release;
        }
        $!chunk = DuckDB-Data-Chunk;

        my $next;
        if $!streaming {
            self!prefetch-start;
            # Only used when the worker refused to start (env switch) -- the
            # fallback keeps the old one-chunk-at-a-time behaviour.
            $next = $!pre-on
                ?? self!prefetch-take
                !! duckdb-stream-fetch-chunk($!raw);
        }
        else {
            $next = duckdb-fetch-chunk($!raw);
        }

        unless $next.defined && $next.Bool {
            $!chunk-done = True;
            $!chunk-size = 0;
            $!chunk-pos  = 0;
            @!decoders   = ();
            return False;
        }

        $!chunk      = $next;
        $!chunk-size = duckdb-data-chunk-get-size($!chunk);
        $!chunk-pos  = 0;
        $!col-buf-ready = False;

        self!prepare-decoders;

        # DuckDB may hand out an empty chunk mid-stream; skip it.
        $!chunk-size > 0 || self!next-chunk;
    }

    method row()
    {
        return () unless $!alive;
        return () if $!columns == 0;
        return () if $!cursor >= $!count;

        while $!chunk-pos >= $!chunk-size {
            return () unless self!next-chunk;
        }

        my uint64 $pos = $!chunk-pos;

        my @row;
        for ^$!columns -> $col {
            @row.push: @!decoders[$col]($pos);
        }

        $!chunk-pos++;
        $!cursor++;
        @row;
    }

    # --- column oriented reading ------------------------------------------
    #| The `:typed` counterpart of !decode-into.  Returns False for every
    #| type it has no lossless Raku mapping for, so the caller falls back to
    #| the normal (text) path: TIME has no value type, the TZ variants are
    #| session-zone dependant, and DECIMAL/ENUM/UUID keep their text form.
    method !decode-into-typed(@dst, Pointer $data, int32 $tid,
                              Pointer $validity, uint64 $size --> Bool)
    {
        with temporal-kind($tid) -> $kind {
            return False
                if $kind == TEMPORAL-TIME-US || $kind == TEMPORAL-TIME-NS;
            push-temporal-typed(@dst, $data, $validity, $size, $kind);
            return True;
        }
        False;
    }

    #| Append a whole integer/float/boolean/decimal vector to @dst in one typed
    #| loop.  NULLs are handled in place from the validity bitmap, so a column
    #| is never dropped back to the per-value decoder merely because it holds
    #| NULLs.  Returns False (having appended nothing) only for types this
    #| method cannot render, letting the caller try the next fast path or the
    #| per-value decoder.
    method !decode-into(@dst, Pointer $data, int32 $tid, Pointer $validity,
                        uint64 $size, $lt --> Bool)
    {
        if $tid == DUCKDB_TYPE_BIGINT {
            push-values(@dst, nativecast(CArray[int64], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_INTEGER {
            push-values(@dst, nativecast(CArray[int32], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_SMALLINT {
            push-values(@dst, nativecast(CArray[int16], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_TINYINT {
            push-values(@dst, nativecast(CArray[int8], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_UBIGINT {
            push-values(@dst, nativecast(CArray[uint64], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_UINTEGER {
            push-values(@dst, nativecast(CArray[uint32], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_USMALLINT {
            push-values(@dst, nativecast(CArray[uint16], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_UTINYINT {
            push-values(@dst, nativecast(CArray[uint8], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_DOUBLE {
            push-values(@dst, nativecast(CArray[num64], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_FLOAT {
            push-values(@dst, nativecast(CArray[num32], $data), $validity, $size);
        }
        elsif $tid == DUCKDB_TYPE_BOOLEAN {
            push-bools(@dst, nativecast(CArray[uint8], $data), $validity, $size);
        }
        # Temporal types are rendered from their integer payload instead of
        # going through DuckDB's VARCHAR cast.  TIMESTAMP_TZ and TIMESTAMP_TZ_NS
        # stay on the generic path on purpose: their text form carries the
        # session time zone, which the raw count alone cannot reproduce.
        elsif temporal-kind($tid) -> $kind {
            push-temporal(@dst, $data, $validity, $size, $kind);
        }
        elsif $tid == DUCKDB_TYPE_ENUM && $lt.defined {
            # An ENUM is a dictionary plus one integer key per row, so the
            # column is a lookup rather than a render: read the keys, index
            # the dictionary.  The keys are stored in the narrowest unsigned
            # width that fits the dictionary, which is what internal_type says.
            my int32 $internal = duckdb-enum-internal-type($lt);
            my @dict = enum-dictionary($lt);

            if $internal == DUCKDB_TYPE_UTINYINT {
                push-enums(@dst, nativecast(CArray[uint8], $data),
                           $validity, $size, @dict);
            }
            elsif $internal == DUCKDB_TYPE_USMALLINT {
                push-enums(@dst, nativecast(CArray[uint16], $data),
                           $validity, $size, @dict);
            }
            elsif $internal == DUCKDB_TYPE_UINTEGER {
                push-enums(@dst, nativecast(CArray[uint32], $data),
                           $validity, $size, @dict);
            }
            else {
                return False;
            }
        }
        elsif $tid == DUCKDB_TYPE_DECIMAL && $lt.defined {
            # DECIMAL is stored as an unscaled integer plus a scale, so it can
            # be rendered with fixed point arithmetic: the scaling factor is
            # computed once for the whole chunk instead of DuckDB's textual
            # rendering being asked for every single value.
            my Int $scale = duckdb-decimal-scale($lt);
            my int32 $internal = duckdb-decimal-internal-type($lt);
            my Int $width = duckdb-decimal-width($lt);

            # C renders the whole chunk in one pass when it can: digit loops
            # are cheap there, while every Str built in Raku costs more than
            # asking DuckDB to format the value in the first place.
            my UInt $dec-kind = do given $internal {
                when DUCKDB_TYPE_SMALLINT { 1 }
                when DUCKDB_TYPE_INTEGER  { 2 }
                when DUCKDB_TYPE_BIGINT   { 3 }
                when DUCKDB_TYPE_HUGEINT  { 4 }
                default                   { 0 }
            };

            if $dec-kind && $scale <= 38 {
                with decimal-joiner() -> &join {
                    # width == scale means the type has no integer digits at
                    # all, and DuckDB prints those without a leading zero.
                    my $joined = join($data, $validity, $size, $scale,
                                      $dec-kind, $width == $scale);
                    if $joined.defined {
                        @dst.append: |$joined;
                        return True;
                    }
                }
            }

            # A scale above 9 leaves the "unscaled value fits comfortably in a
            # machine integer" assumption behind; those stay on the generic
            # decoder, which is exact for every width.
            return False if $scale > 9;

            my Int $div = 10 ** $scale;
            my Str $pad = '0' x $scale;
            # width == scale means the type has no integer digits and DuckDB
            # prints those without the leading zero.
            my Bool $trim-zero = $width == $scale;

            if $internal == DUCKDB_TYPE_SMALLINT {
                push-decimals(@dst, nativecast(CArray[int16], $data),
                              $validity, $size, $scale, $div, $pad, $trim-zero);
            }
            elsif $internal == DUCKDB_TYPE_INTEGER {
                push-decimals(@dst, nativecast(CArray[int32], $data),
                              $validity, $size, $scale, $div, $pad, $trim-zero);
            }
            elsif $internal == DUCKDB_TYPE_BIGINT {
                push-decimals(@dst, nativecast(CArray[int64], $data),
                              $validity, $size, $scale, $div, $pad, $trim-zero);
            }
            elsif $internal == DUCKDB_TYPE_HUGEINT {
                push-decimals-huge(@dst, $data, $validity, $size,
                                   $scale, $div, $pad, $trim-zero);
            }
            else {
                return False;
            }
        }
        else {
            return False;
        }

        True;
    }

    #| Append one column of the current chunk to @dst, falling back to the
    #| per-value decoder when the fast path does not apply.
    method !append-column(@dst, Int $col, uint64 $size --> Nil)
    {
        self!append-column-of($!chunk, @dst, $col, $size, @!decoders[$col]);
    }

    #| Bridge for DB::DuckDB::ColumnView's lazy path: decode one chunk's
    #| column into @dst.  Kept public because the view lives in another
    #| module and cannot reach the private helper.
    #|
    #| `:typed` asks for Raku values instead of text where a lossless
    #| mapping exists (DATE -> Date, TIMESTAMP* -> DateTime).  It is a
    #| request, not a guarantee: types without such a mapping keep the
    #| value `column()` would give.
    method decode-column-into(@dst, $chunk, Int $col, uint64 $size,
                              Bool :$typed = False --> Nil)
    {
        self!append-column-of($chunk, @dst, $col, $size, Mu, :$typed);
    }

    #| The body of append-column, parameterised by the chunk handle so a
    #| worker thread can decode a chunk it owns instead of touching the
    #| shared $!chunk/$!decoders state.  Pass a decoder only when the chunk
    #| is the one the cached decoders were built for; otherwise one is built
    #| on demand for this vector (only slow-path types need it).
    method !append-column-of($chunk, @dst, Int $col, uint64 $size,
                             Mu $decoder = Mu, Bool :$typed = False --> Nil)
    {
        return if $size == 0;

        my $vec = duckdb-data-chunk-get-vector($chunk, $col);
        # duckdb_vector_get_column_type hands back a copy we own; DECIMAL needs
        # it for its scale, so it lives until the column is done.
        my $lt  = duckdb-vector-get-column-type($vec);
        LEAVE duckdb-destroy-logical-type($lt);

        my int32 $tid = duckdb-get-type-id($lt);
        my Pointer $data     = duckdb-vector-get-data($vec);
        my Pointer $validity = duckdb-vector-get-validity($vec);

        # Typed first: DATE and TIMESTAMP are rendered from the same payload
        # either way, and only this path skips formatting it to text.
        if $typed
           && self!decode-into-typed(@dst, $data, $tid, $validity, $size) {
            return;
        }

        my Bool $done = self!decode-into(@dst, $data, $tid, $validity, $size, $lt);

        # VARCHAR is the one type whose per-value cost is dominated by string
        # assembly rather than by boxing, so it goes through the C shim.
        # Two shim strategies, cheapest first:
        #   join  -- one buffer with 0x01 between values, one decode, one
        #            split: no per-value work at all on the Raku side.
        #   unpack -- one buffer plus an offset table, one slice per value;
        #            the fallback for non-flat vectors and for payloads that
        #            contain the separator bytes.
        if !$done && $tid == DUCKDB_TYPE_VARCHAR {
            my Pointer $mask = $validity.defined ?? $validity !! Pointer;

            with varchar-joiner() -> &join {
                my $joined = join($data, $mask, $size);
                if $joined.defined {
                    @dst.append: |$joined;
                    return;
                }
            }

            with varchar-unpacker() -> &unpack {
                my $unpacked = unpack($data, $mask, $size);
                # Nil means the shim refused: the chunk vector is not flat
                # (dictionary/selection vector), so read it value by value.
                if $unpacked.defined {
                    @dst.append: |$unpacked;
                    return;
                }
            }
        }

        unless $done {
            my &decoder = $decoder.defined ?? $decoder !! build-decoder($vec, $lt);
            my uint64 $r = 0;
            loop (; $r < $size; $r++) { @dst.push: decoder($r) }
        }
    }

    method !build-col-buf(--> Nil)
    {
        my uint64 $size = $!chunk-size;
        my @buf;
        for ^$!columns -> $col {
            my @col;
            self!append-column(@col, $col, $size);
            @buf.push: @col;
        }
        @!col-buf = @buf;
        $!col-buf-ready = True;
    }

    #| Advance one row inside the cached chunk.  Returns -1 at end of result.
    method !next-row-pos(--> Int)
    {
        return -1 unless $!alive;
        return -1 if $!columns == 0;
        return -1 if $!cursor >= $!count;

        while $!chunk-pos >= $!chunk-size {
            return -1 unless self!next-chunk;
        }

        self!build-col-buf unless $!col-buf-ready;

        my uint64 $pos = $!chunk-pos;
        $!chunk-pos++;
        $!cursor++;
        $pos.Int;
    }

    method !make-row(uint64 $pos --> Array)
    {
        my @row;
        my int $i = 0;
        my int $n = $!columns;
        while $i < $n {
            @row.push: @!col-buf[$i][$pos];
            $i++;
        }
        @row;
    }

    #| One step of the arrays-fast() iterator.
    method _next-array(--> Mu)
    {
        my $pos = self!next-row-pos;
        return Mu if $pos < 0;
        self!make-row($pos);
    }

    #| Row-wise iteration (DB::Result contract) on top of the column decoder:
    #| 1.2-1.3x faster than the per-cell path at any width.
    method arrays()
    {
        self.arrays-fast;
    }

    #| Same rows as arrays(), but decoded column by column in typed loops.
    #| 1.2-1.35x faster on integer/float results of any width.
    method arrays-fast()
    {
        my $res = self;
        Seq.new(class :: does Iterator {
            has $.res;
            method pull-one()
            {
                my $r = $!res._next-array;
                $r.defined ?? $r !! IterationEnd;
            }
        }.new(:res($res)))
    }

    #| Drain the rest of the result into the supplied per-column Arrays.
    method !drain-into(@cols --> Nil)
    {
        my int $n = @cols.elems;
        loop {
            last if $!chunk-pos >= $!chunk-size && !self!next-chunk;
            my uint64 $from = $!chunk-pos;
            my uint64 $size = $!chunk-size;
            my int $i = 0;
            if $from == 0 {
                while $i < $n {
                    self!append-column(@cols[$i], $i, $size);
                    $i++;
                }
            } else {
                while $i < $n {
                    my @tmp;
                    self!append-column(@tmp, $i, $size);
                    @cols[$i].append(@tmp[$from ..^ $size]);
                    $i++;
                }
            }
            $!cursor += ($size - $from).Int;
            $!chunk-pos = $size;
        }
    }

    #| Drain the remaining values of a single column into @dst.
    method !drain-one(Int $col, @dst --> Nil)
    {
        loop {
            last if $!chunk-pos >= $!chunk-size && !self!next-chunk;
            my uint64 $from = $!chunk-pos;
            my uint64 $size = $!chunk-size;
            if $from == 0 {
                self!append-column(@dst, $col, $size);
            } else {
                my @tmp;
                self!append-column(@tmp, $col, $size);
                @dst.append(@tmp[$from ..^ $size]);
            }
            $!cursor += ($size - $from).Int;
            $!chunk-pos = $size;
        }
    }

    #| All remaining values of one column as a single Array.  Skips the
    #| per-row Array allocation: an order of magnitude faster than arrays()
    #| when only one column is needed.
    #| True when this result was executed in streaming mode, i.e. rows are
    #| only available through .chunks (row-wise readers see an empty result
    #| because no row count exists up front).
    method is-streaming(--> Bool) { $!streaming }

    #| Streaming iteration: each element is one data chunk of up to 2048 rows.
    #| The first chunk is available as soon as the engine produces it, and the
    #| driver never holds more than one chunk at a time, so peak memory stays
    #| flat regardless of result size.
    #|
    #| A chunk is invalidated when the next element is pulled -- consume it
    #| inside the loop body.
    method chunks(--> Seq)
    {
        die DB::DuckDB::Error.new(message => 'result has already been freed')
            unless $!alive;

        gather {
            my $prev;
            loop {
                # The engine recycles the chunk buffer as soon as we pull the
                # next one, so the previous handle has to die now -- otherwise
                # a caller that kept it reads whatever replaced it.
                $prev.expire if $prev.defined;

                last unless self!next-chunk;

                my uint64 $size = $!chunk-size;
                my @views;

                for ^$!columns -> int $col {
                    my $vec = duckdb-data-chunk-get-vector($!chunk, $col);
                    my $lt  = duckdb-vector-get-column-type($vec);
                    LEAVE duckdb-destroy-logical-type($lt);

                    my int32 $tid = duckdb-get-type-id($lt);
                    my Int $width = raw-width($tid);
                    # DECIMAL carries a scale, so it keeps the decoded path.
                    my Bool $raw = (raw-type($tid) && $width > 0
                                    && $tid != DUCKDB_TYPE_DECIMAL).Bool;
                    my Int $scale = $tid == DUCKDB_TYPE_DECIMAL
                        ?? duckdb-decimal-scale($lt)
                        !! 0;

                    my @boxed;
                    self!append-column(@boxed, $col, $size) unless $raw;

                    @views.push: DB::DuckDB::ColumnView.new(
                        index  => $col,
                        elems  => $size.Int,
                        tid    => $tid,
                        type   => type-name($tid),
                        width  => ($raw ?? $width !! 0),
                        scale  => $scale,
                        result => self,
                        raw    => $raw,
                        bases  => (0,).List,
                        rows   => ($size.Int,).List,
                        data   => (duckdb-vector-get-data($vec),).List,
                        valid  => (duckdb-vector-get-validity($vec),).List,
                        boxed  => @boxed.List,
                    );
                }

                $prev = DB::DuckDB::Chunk.new(
                    :size($size.Int),
                    :result(self),
                    :views(@views),
                );
                $!live-chunk = $prev;
                take $prev;
            }

            $!chunk-done = True;
            $!cursor     = $!count;
        }
    }

    method column(Int $idx --> Array)
    {
        die "column index $idx out of range" if $idx < 0 || $idx >= $!columns;
        my @out;
        self!drain-one($idx, @out) if $!columns > 0;
        @out;
    }

    #| All remaining values, column by column: a List with one Array per
    #| column.  This is the fastest way to consume a whole wide result.
    #| (Named column-arrays because $.columns is the column count accessor.)
    #|
    #| With :parallel the columns are decoded by several threads at once.
    #| The work is cut into (column, chunk-span) tasks: a worker takes one
    #| column over a contiguous run of chunks and writes straight into that
    #| column's preallocated array, so nothing is shared between workers.
    #| When a result has fewer columns than workers -- or one column costs
    #| far more than the others, as a VARCHAR beside a BIGINT does -- the
    #| chunks of that column are split across workers instead, in proportion
    #| to each column's decode weight, and the per-span arrays are stitched
    #| back in chunk order: values stay in row order and the result is
    #| identical to the serial one.
    #|
    #| Decoding several columns at once is the default: the work is pure
    #| reads, the split is free, and the serial path is left with a single
    #| core.  Turn it off with :!parallel or DB_DUCKDB_NO_COLUMN_PARALLEL=1.
    #|
    #| :degree caps the worker count (defaults to DB_DUCKDB_DEGREE, else the
    #| core count), further capped so that no worker gets fewer than
    #| 20_000 rows to decode: eight threads over a 25_000-row result spend
    #| more time starting than working.  Only a materialised, untouched
    #| result can be split -- streaming results and results that were
    #| already read fall back to the serial path, as does anything below
    #| 20_000 rows.
    method column-arrays(Bool :$parallel = !%*ENV<DB_DUCKDB_NO_COLUMN_PARALLEL>,
                         Int :$degree = 0 --> List)
    {
        my @cols;
        for ^$!columns { @cols.push: [] }
        return @cols.List if $!columns == 0;

        return @cols.List
            if $parallel && self!parallel-column-arrays(@cols, $degree);

        self!drain-into(@cols);
        @cols.List;
    }

    #| Fill @cols with one independently decoded Array per column.
    #| Returns False -- having touched nothing -- when the result cannot be
    #| split (streaming, partially consumed, or tiny).
    method !parallel-column-arrays(@cols, Int $degree --> Bool)
    {
        return False if $!streaming;
        # Same contract as column-views: chunk indices and the fetch cursor
        # share one iterator, so this may only run on an untouched result.
        return False if $!cursor > 0 || $!chunk-pos > 0;

        my int $ncols = $!columns;
        my uint64 $total = duckdb-row-count($!raw);
        # Thread setup costs more than the decode below this size.
        return False if $total < PARALLEL-MIN-ROWS;
        return False if $ncols < 1;

        my int $nt = $degree > 0 ?? $degree !! cpu-count();
        # Adaptive: every worker should have at least PARALLEL-MIN-ROWS rows
        # of its own, otherwise thread setup and the stitch-up copies cost
        # more than the decode they save.
        my int $by-rows = ($total div PARALLEL-MIN-ROWS).Int;
        $by-rows = 1 if $by-rows < 1;
        $nt = $by-rows if $by-rows < $nt;
        $nt = $ncols if $nt > $ncols && $ncols > 1;
        return False if $nt < 2;

        my @chunks;
        my uint64 $nchunks = duckdb-result-chunk-count($!raw);
        for ^$nchunks -> uint64 $ci {
            my $chunk = duckdb-result-get-chunk($!raw, $ci);
            last unless $chunk.defined && $chunk.Bool;
            my uint64 $size = duckdb-data-chunk-get-size($chunk);
            if $size == 0 {
                duckdb-destroy-data-chunk($chunk);
                next;
            }
            @chunks.push: ($chunk, $size);
        }
        return False unless @chunks.elems;

        my int $nch = @chunks.elems;

        # Work unit = one column over a contiguous span of chunks.  Splitting
        # a column between threads is only worth its stitch-up copy when the
        # columns alone cannot keep the workers fed.
        # Per-column weight: a VARCHAR (or nested) value costs several
        # numeric values to decode.  Splitting every column the same number
        # of times therefore leaves the cheap columns finished early and
        # their workers idle while the expensive one runs on -- the tail.
        my int @weight;
        my int $wsum = 0;
        for ^$ncols -> int $col {
            my int $w = column-weight(@!column-types[$col]);
            @weight[$col] = $w;
            $wsum += $w;
        }

        # Spans per column, proportional to that column's share of the total
        # cost.  Cutting a column costs one stitch-up copy of its values, so
        # a column is only split when it is expensive (weight > 1) or when it
        # is the only column there is: copying a numeric column costs about
        # what decoding it does, which would only move the work around.
        my int @split;
        for ^$ncols -> int $col {
            my int $w = @weight[$col];
            my int $sp = 1;
            if $nch > 1 && ($w > 1 || $ncols == 1) {
                $sp = ($nt * $w + $wsum - 1) div $wsum;
                $sp = 1   if $sp < 1;
                $sp = $nt if $sp > $nt;
                $sp = $nch if $sp > $nch;
            }
            @split[$col] = $sp;
        }

        # Flat task tables (column, first chunk, end chunk, weight).  Nested
        # Lists come back itemised from an Array slot, so the four fields are
        # kept in four typed arrays instead.
        my int @t-col;
        my int @t-from;
        my int @t-to;
        my int @t-w;
        for ^$ncols -> int $col {
            my int $w = @weight[$col];
            my int $sp = @split[$col];
            my int $step = ($nch + $sp - 1) div $sp;
            my int $i = 0;
            while $i < $nch {
                my int $to = $i + $step;
                $to = $nch if $to > $nch;
                @t-col.push: $col;
                @t-from.push: $i;
                @t-to.push: $to;
                @t-w.push: $w;
                $i += $step;
            }
        }
        my int $ntask = @t-col.elems;
        return False if $ntask == 0;

        # Cost of a task = type weight x rows.  Greedy longest-processing-time:
        # heaviest task first, each one to whichever worker is cheapest so far.
        my int @cost;
        for ^$ntask -> int $ti {
            @cost[$ti] = @t-w[$ti] * (@t-to[$ti] - @t-from[$ti]);
        }
        my @order = (^$ntask).sort({ @cost[$^a] <=> @cost[$^b] }).reverse;
        my @load = 0 xx $nt;
        my @plan;
        for ^$nt -> int $t { @plan[$t] = [] }
        for @order -> $ti {
            my int $best = 0;
            for ^$nt -> int $t { $best = $t if @load[$t] < @load[$best] }
            @plan[$best].push: $ti;
            @load[$best] += @cost[$ti];
        }

        # One slot per task, created here: worker threads only ever store
        # into their own pre-existing slots, which is the one write pattern
        # that is safe to share.  Hashes handed between threads do not
        # survive the await, Arrays in preallocated slots do.
        my @parts;
        for ^$ntask -> int $ti { @parts[$ti] = [] }

        my @promises;
        for ^$nt -> int $t {
            my @mine := @plan[$t];
            next unless @mine.elems;
            @promises.push: start {
                for @mine.list -> $ti {
                    my int $col  = @t-col[$ti];
                    my int $from = @t-from[$ti];
                    my int $to   = @t-to[$ti];
                    my @part;
                    my int $ci = $from;
                    while $ci < $to {
                        my $pair := @chunks[$ci];
                        self!append-column-of($pair[0], @part, $col, $pair[1]);
                        $ci++;
                    }
                    @parts[$ti] = @part;
                }
                True;
            }
        }
        await @promises;

        # Every worker copied what it needed out of the chunks, so hand the
        # caller-owned handles back now instead of at result free: a 200k-row
        # result is ~98 chunks and leaks ~23 MB per query otherwise.
        for @chunks -> $pair {
            duckdb-destroy-data-chunk($pair[0]);
        }
        @chunks = ();

        # Stitch the spans back together in chunk order.  A column decoded in
        # one piece is handed over without any copy at all; a split column
        # keeps the first span as its array and appends the rest onto it.
        for ^$ncols -> int $col {
            my @idxs;
            for ^$ntask -> int $ti { @idxs.push: $ti if @t-col[$ti] == $col }
            @cols[$col] = @parts[@idxs[0]];
            my int $k = 1;
            while $k < @idxs.elems {
                # splice, not append-with-slip: a span can hold far more than
                # the 65535 arguments a flattened list is allowed to carry.
                @cols[$col].splice(@cols[$col].elems, 0, @parts[@idxs[$k]]);
                $k++;
            }
        }
        @parts = ();

        $!cursor     = $!count;
        $!chunk-pos  = 0;
        $!chunk-done = True;
        True;
    }

    #| One column as a zero-copy view over this result's chunk vectors.
    method column-view(Int $idx --> DB::DuckDB::ColumnView)
    {
        die "column index $idx out of range" if $idx < 0 || $idx >= $!columns;
        self.column-views[$idx];
    }

    #| Every column as a ColumnView.  Numeric columns are read straight out
    #| of the chunk vectors -- no per-value objects -- while every other
    #| type keeps its chunk handles and is decoded a segment at a time, on
    #| first access, so asking for one VARCHAR column no longer pays for
    #| every VARCHAR column in the row.  Like column-arrays() this consumes
    #| the whole result, so call it before any other reader.
    method column-views(--> List)
    {
        die "result is not alive" unless $!alive;
        die "column-views must be the first reader on this result"
            if $!cursor > 0 || $!chunk-pos > 0;

        my int $ncols = $!columns;

        if %*ENV<DB_DUCKDB_NO_COLUMN_VIEW> {
            my @arrs = self.column-arrays;
            my @v;
            for ^$ncols -> int $c {
                @v.push: DB::DuckDB::ColumnView.from-list(
                    index => $c, values => @arrs[$c],
                    tid => @!column-types[$c],
                    type => type-name(@!column-types[$c]), result => self);
            }
            return @v.List;
        }

        my uint64 $nchunks = duckdb-result-chunk-count($!raw);
        my @segs;
        my @meta;
        for ^$ncols { @segs.push: []; @meta.push: Mu }

        my uint64 $base = 0;

        for ^$nchunks -> uint64 $ci {
            my $chunk = duckdb-result-get-chunk($!raw, $ci);
            last unless $chunk.defined && $chunk.Bool;

            my uint64 $size = duckdb-data-chunk-get-size($chunk);
            if $size == 0 {
                duckdb-destroy-data-chunk($chunk);
                next;
            }

            for ^$ncols -> int $col {
                my $vec = duckdb-data-chunk-get-vector($chunk, $col);

                unless @meta[$col].defined {
                    my $lt = duckdb-vector-get-column-type($vec);
                    my int32 $tid = duckdb-get-type-id($lt);
                    my Int $width = 0;
                    my Int $scale = 0;
                    my Bool $raw = raw-type($tid);
                    if $tid == DUCKDB_TYPE_DECIMAL {
                        my int32 $it = duckdb-decimal-internal-type($lt);
                        $width = raw-width($it);
                        $scale = duckdb-decimal-scale($lt);
                    }
                    elsif $raw {
                        $width = raw-width($tid);
                    }
                    duckdb-destroy-logical-type($lt);
                    @meta[$col] = %( :$tid, :$width, :$scale,
                                     raw => ($raw && $width > 0) );
                }

                my %m = @meta[$col];

                if %m<raw> {
                    @segs[$col].push: %(
                        base  => $base,
                        rows  => $size,
                        data  => duckdb-vector-get-data($vec),
                        valid => duckdb-vector-get-validity($vec),
                    );
                }
                else {
                    # Not decoded here: remember the chunk and let the view
                    # decode this segment the first time somebody asks for a
                    # value in it.  Eager decoding made every VARCHAR column
                    # in the result pay the full string-assembly cost even
                    # when the caller only wanted one of them.
                    @segs[$col].push: %(
                        base  => $base,
                        rows  => $size,
                        data  => Pointer,
                        valid => Pointer,
                        chunk => $chunk,
                    );
                }
            }

            # Ownership is unconditional: even a purely numeric chunk is
            # referenced by the raw segments (their data/validity pointers
            # point into it), so it has to stay alive until the view goes and
            # be destroyed by hand afterwards.
            @!owned-chunks.push: $chunk;

            $base += $size;
        }

        my @views;
        for ^$ncols -> int $col {
            # A zero-row result never pushes a chunk, so the per-column meta
            # was never filled in: derive it from the result's column types.
            unless @meta[$col].defined {
                my int32 $tid = @!column-types[$col];
                my Bool $r = (raw-type($tid) && raw-width($tid) > 0
                              && $tid != DUCKDB_TYPE_DECIMAL).Bool;
                @meta[$col] = %( tid    => $tid,
                                 width  => ($r ?? raw-width($tid) !! 0),
                                 scale  => 0,
                                 raw    => $r );
            }
            my %m = @meta[$col];
            my @s  = @segs[$col].List;
            @views.push: DB::DuckDB::ColumnView.new(
                index  => $col,
                elems  => $base.Int,
                tid    => %m<tid>,
                type   => type-name(%m<tid>),
                width  => %m<width>,
                scale  => %m<scale>,
                result => self,
                raw    => %m<raw>,
                bases  => @s.map({ $_<base>  }).List,
                rows   => @s.map({ $_<rows>  }).List,
                data   => @s.map({ $_<data>  }).List,
                valid  => @s.map({ $_<valid> }).List,
                # Non-raw columns keep their chunk handles and decode a
                # segment the first time a row in it is read; raw columns
                # never touch either of these.
                chunks => @s.map({ $_<chunk> }).List,
                lazy   => !%m<raw>,
                boxed  => (),
            );
        }

        $!cursor     = $base.Int;
        $!chunk-done = True;
        $!chunk-size = 0;
        $!chunk-pos  = 0;

        @views.List;
    }

    #| Assemble the whole next chunk into @!hash-buf via nqp::hash.
    method !fill-hash-buf(--> Bool)
    {
        @!hash-buf = ();
        $!hash-pos = 0;
        return False unless self!next-chunk;

        my uint64 $size = $!chunk-size;
        my @cd;
        for ^$!columns -> $col {
            my @c;
            self!append-column(@c, $col, $size);
            @cd.push: @c;
        }

        my @names = self.names;
        my @buf;
        if $!columns == 3 {
            my $c0 = @cd[0]; my $c1 = @cd[1]; my $c2 = @cd[2];
            my \k0 = @names[0]; my \k1 = @names[1]; my \k2 = @names[2];
            for ^$size -> uint64 $r {
                my $h := nqp::hash();
                nqp::bindkey($h, k0, $c0[$r]);
                nqp::bindkey($h, k1, $c1[$r]);
                nqp::bindkey($h, k2, $c2[$r]);
                @buf.push: $h;
            }
        }
        else {
            for ^$size -> uint64 $r {
                my $h := nqp::hash();
                for ^$!columns -> $col {
                    nqp::bindkey($h, @names[$col], @cd[$col][$r]);
                }
                @buf.push: $h;
            }
        }
        @!hash-buf = @buf;
        True;
    }

    #| One step of the hashes() iterator.
    method _next-hash(--> Mu)
    {
        if $!hash-pos >= @!hash-buf.elems {
            return Mu unless self!fill-hash-buf;
        }
        my $h = @!hash-buf[$!hash-pos];
        $!hash-pos++;
        $!cursor++;
        $h;
    }

    #| Hash rows built straight from the column buffers with nqp::hash, which
    #| avoids the Z=> / %() round trip of the generic implementation.
    method hashes()
    {
        my $res = self;
        Seq.new(class :: does Iterator {
            has $.res;
            method pull-one()
            {
                my $h = $!res._next-hash;
                $h.defined ?? $h !! IterationEnd;
            }
        }.new(:res($res)))
    }

    method free(--> Nil)
    {
        return unless $!alive;
        $!alive = False;

        # A chunk still held by the caller points into buffers that are about
        # to go away, so expire it rather than let it read freed memory.
        if $!live-chunk.defined {
            $!live-chunk.expire;
            $!live-chunk = Nil;
        }

        duckdb-destroy-data-chunk($!chunk)
            if $!chunk.defined && $!chunk.Bool;
        $!chunk = DuckDB-Data-Chunk;

        for @!owned-chunks -> $c {
            duckdb-destroy-data-chunk($c) if $c.defined && $c.Bool;
        }
        @!owned-chunks = ();

        # The prefetch worker reads from the raw result, so it has to be
        # joined before the result dies underneath it.
        self!prefetch-stop;

        duckdb-destroy-result($!raw);

        # `DB` always asks for `:finish` on `query` / `execute`, meaning the
        # statement must not stay cached once its result is drained.
        $!sth.finish if $!finish && $!sth.defined;

        if $!borrowed-conn.defined {
            my $conn = $!borrowed-conn;
            $!borrowed-conn = Nil;
            $conn.finish;
        }
    }

    submethod DESTROY() { self.free }
}
