#| Locate -- and if necessary compile -- the ArrowArray release shim described
#| in resources/duckdb-arrow-shim.c.
#|
#| The shim exists because the release callback inside an ArrowArray is only
#| known at run time, so calling it from Raku means invoking a raw function
#| pointer through NativeCall.  That is measurably lossy: a 30_000 iteration
#| convert/release loop grew the process by ~540 MB when the callback was
#| called from Raku, and stayed flat when the very same loop went through the
#| shim.  A wrong pointer here also corrupts the allocator instead of failing
#| cleanly, which is what crashed earlier attempts on Windows.
#|
#| The C file is self contained: no duckdb.h, no linking against libduckdb,
#| only the Arrow C data interface layout.  Failure is always soft -- when no
#| compiler is available Arrow.rakumod falls back to the in-Raku callback.
unit module DB::DuckDB::ArrowShim;

use DB::DuckDB::ShimCache;

my Str  $lib-path;
my Bool $probed = False;

sub native-ext(--> Str)
{
    return '.dll' if $*DISTRO.is-win;
    $*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so';
}

sub shim-source(--> IO::Path)
{
    my $from-res = quietly { %?RESOURCES<duckdb-arrow-shim.c> };
    return $from-res.IO if $from-res.defined && $from-res.IO.e;

    # lib/DB/DuckDB/ArrowShim.rakumod -> <root>/resources/...
    my $local = $?FILE.IO.parent.parent.parent.parent
                    .child('resources/duckdb-arrow-shim.c');
    $local.e ?? $local !! IO::Path;
}

sub cache-dir(--> IO::Path)
{
    %*ENV<DB_DUCKDB_SHIM_CACHE>
        ?? %*ENV<DB_DUCKDB_SHIM_CACHE>.IO
        !! $*HOME.IO.add('.local/share/DB-DuckDB');
}

sub lib-file(IO::Path $dir --> IO::Path) { $dir.add('libduckdb-arrow-shim' ~ native-ext()) }

#| ABI stamp belonging to one library file -- per file, not per directory: a
#| directory can hold the old shared library (mapped by another process and
#| therefore impossible to replace on Windows) next to fresh per-process
#| builds, and a directory-wide stamp would then vouch for the stale one.
sub lib-stamp(IO::Path $lib --> IO::Path) { IO::Path.new($lib.absolute ~ '.abi') }

sub lib-abi(IO::Path $lib --> Str)
{
    my $stamp = lib-stamp($lib);
    return '' unless $stamp.e;
    (try { $stamp.slurp.trim }) // '';
}

#| Usable libraries in this directory, shared name first, then the per-process
#| builds left behind when the shared name was busy.
sub cached-libs(IO::Path $dir --> List)
{
    my $canon = lib-file($dir);
    my @private = $dir.d
        ?? quietly {
                dir($dir).grep({
                    .f
                    && .basename.starts-with('libduckdb-arrow-shim-')
                    && .basename.ends-with(native-ext)
                }).sort({ (try { .modified.Instant } // 0) }).reverse
            }
        !! ();
    my @out;
    @out.push: $canon if $canon.e;
    @out.append: |@private;
    @out.List;
}

#| ABI of the entry points this driver expects; bumped together with
#| DKD_ARROW_SHIM_ABI in the C file.
our constant SHIM-ABI = 1;

sub compiler-candidates(--> List)
{
    my @c;
    @c.push: %*ENV<DB_DUCKDB_CC> if %*ENV<DB_DUCKDB_CC>;
    @c.push: %*ENV<CC>           if %*ENV<CC>;
    @c.append: 'cc', 'gcc', 'clang';

    if $*DISTRO.is-win {
        @c.append: |<
            C:/msys64/mingw64/bin/gcc.exe
            C:/msys64/ucrt64/bin/gcc.exe
            C:/msys64/clang64/bin/clang.exe
            C:/Strawberry/c/bin/gcc.exe
            C:/TDM-GCC-64/bin/gcc.exe
            C:/mingw64/bin/gcc.exe
            C:/rakudo/share/llvm-mingw/bin/gcc.exe
        >;
        for <C D E>.map({ $_ ~ ':/' }) -> $root {
            next unless $root.IO.d;
            my @dirs = quietly { dir($root).grep({ .d && .basename.starts-with('llvm-mingw') }) };
            for @dirs -> $d {
                my $g = $d.add('bin/gcc.exe');
                @c.push: $g.absolute if $g.e;
            }
        }
    }
    @c.cache;
}

sub build-shim(--> IO::Path)
{
    my $src = shim-source();
    return IO::Path unless $src.defined;

    my $dir = cache-dir();

    # A cached library counts only when *it* carries a current ABI stamp, not
    # when some directory-wide stamp says so.
    for cached-libs($dir) -> $lib {
        next unless $lib.e;
        return $lib if lib-abi($lib) eq SHIM-ABI.Str;
    }

    $dir.mkdir unless $dir.d;

    my @flags = $*DISTRO.is-win
        ?? ('-O2', '-shared')
        !! ('-fPIC', '-O2', '-shared');

    for compiler-candidates() -> $cc {
        # Never link onto the shared name: on Windows another process may have
        # it mapped, in which case the link fails with "Permission denied", and
        # deleting it out from under that process would pull the shim away
        # mid-run.  Build under a private name, then move it into place only
        # when the shared name is free (or holds an older ABI).
        my $out = $dir.add("libduckdb-arrow-shim-{$*PID}-{now.Int}" ~ native-ext());
        my @cmd = $cc, |@flags, '-o', $out.absolute, $src.absolute;
        my $ok = try {
            my $proc = run(|@cmd, :out, :err);
            my $err-text = $proc.err.slurp(:close);
            $proc.out.slurp(:close);
            note "DB::DuckDB::ArrowShim: $cc exited {$proc.exitcode}:\n$err-text"
                if $proc.exitcode != 0 && $err-text.chars;
            $proc.exitcode == 0;
        } // False;

        if $ok && $out.e {
            my $canon = lib-file($dir);
            my $stale = $canon.e && lib-abi($canon) ne SHIM-ABI.Str;
            my $final = $out;
            if $canon.e.not || $stale {
                my $moved = try {
                    $canon.unlink if $stale;
                    $out.rename($canon);
                    $canon;
                } // Nil;
                $final = $moved.defined && $moved.e ?? $moved !! $out;
            }

            try { lib-stamp($final).spurt: SHIM-ABI.Str ~ "\n" }
            return $final;
        }

        try { $out.unlink }
    }

    note "DB::DuckDB::ArrowShim: no working C compiler found; ArrowArray "
      ~ "release falls back to the in-Raku callback.  Set DB_DUCKDB_CC to "
      ~ "pick one.";
    IO::Path;
}

#| Absolute path of the compiled shim, or an empty string when unavailable.
#| Resolution happens once per process.
our sub shim-lib(--> Str) is export
{
    return $lib-path if $probed;
    $probed = True;

    # Same escape hatch as the VARCHAR shim: lets a caller (or a test) force
    # the in-Raku release path without waiting for a compiler to go missing.
    return $lib-path = '' if %*ENV<DB_DUCKDB_NO_ARROW_SHIM>;

    if %*ENV<DB_DUCKDB_ARROW_SHIM> -> $explicit {
        return $lib-path = $explicit
            if $explicit.chars && $explicit.IO.e;
    }

    my $out = build-shim();
    $lib-path = $out.defined && $out.e ?? $out.absolute !! '';

    # Cross-version cleanup, same as the VARCHAR shim: leftovers from earlier
    # naming schemes, dead stamps and stale per-process builds.
    sweep(
        cache-dir(),
        'libduckdb-arrow-shim',
        :abi(SHIM-ABI.Str),
        keep => ($lib-path.chars ?? $lib-path.IO !! Nil),
    );

    $lib-path;
}
