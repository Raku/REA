#| Cache hygiene shared by the three on-demand C shims (VARCHAR, Arrow, the
#| by-value result bridge).
#|
#| All three compile a small C file into `~/.local/share/DB-DuckDB` (or
#| `DB_DUCKDB_SHIM_CACHE`) on first use, and all three have been through at
#| least one change of naming scheme.  The result is that a cache directory
#| accumulates debris that no code path will ever read again:
#|
#|   * `libduckdb-*-shim.abi` -- a directory-wide stamp from before the switch
#|     to per-file stamps.  The library it vouched for is gone, so the stamp
#|     is stale by construction.
#|   * `*.bak` -- written by an earlier version that tried to move a library
#|     aside before replacing it.
#|   * `libduckdb-*-shim-<pid>-<epoch>.<ext>` -- per-process builds left behind
#|     when the shared name could not be replaced (another process had it
#|     mapped).  Correct at the time, pure ballast an hour later.
#|
#| None of these are load-bearing: every file here can be rebuilt from the C
#| source in `resources/`.  Even so the sweep is deliberately conservative --
#| anything that looks like it might still be the library a running process is
#| using is left alone, and every delete is best-effort (a file that cannot be
#| removed is skipped, not fatal).
unit module DB::DuckDB::ShimCache;

#| Where the shims live.  Deliberately not exported: each shim module has its
#| own copy of this lookup and importing a second one would be a redeclaration.
sub cache-dir(--> IO::Path)
{
    %*ENV<DB_DUCKDB_SHIM_CACHE>
        ?? %*ENV<DB_DUCKDB_SHIM_CACHE>.IO
        !! $*HOME.IO.add('.local/share/DB-DuckDB');
}

#| Native shared-object extension for this platform.  Not exported either, same
#| reason.
sub native-ext(--> Str)
{
    return '.dll' if $*DISTRO.is-win;
    $*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so';
}

#| The ABI file that belongs to one library, next to it.
sub lib-stamp(IO::Path $lib --> IO::Path) { IO::Path.new($lib.absolute ~ '.abi') }

sub lib-abi(IO::Path $lib --> Str)
{
    my $stamp = lib-stamp($lib);
    return '' unless $stamp.e;
    (try { $stamp.slurp.trim }) // '';
}

#| Epoch seconds encoded in a per-process build name (`<prefix>-<pid>-<epoch>`),
#| 0 for the shared name.  Read from the name rather than the mtime because this
#| Rakudo reports a negative Instant for files written seconds ago, which made
#| fresh builds look hours old and got them deleted.
sub lib-epoch(IO::Path $lib, Str:D $prefix --> Int)
{
    my $base = $lib.basename;
    return 0 unless $base.starts-with($prefix ~ '-');
    my @nums = $base.comb(/\d+/, :match);
    return 0 unless @nums.elems > 1;
    (try { @nums.tail.Str.Int }) // 0;
}

#| Remove debris for `$prefix` from `$dir`.
#|
#| `$abi` is the ABI the caller needs: when given, a "usable" library is one
#| whose own stamp says so, and the older-than-an-hour rule only applies once
#| such a library exists (never leave the cache empty).  `$keep` is the library
#| the caller just resolved; it is never touched.
our sub sweep(IO::Path $dir, Str:D $prefix, Str :$abi, :$keep --> Nil) is export
{
    return unless $dir.d;
    return if %*ENV<DB_DUCKDB_NO_CACHE_SWEEP>;

    my @files = quietly { dir($dir).grep(*.f).List };
    return unless @files.elems;

    my $keep-path = $keep.defined ?? $keep.absolute !! '';

    # 1. Backups from the version that swapped libraries aside.  Nothing reads
    #    them, and they are a full copy each.
    for @files.grep({ .basename.starts-with($prefix) && .basename.ends-with('.bak') }) {
        try { .unlink }
    }

    # 2. Stamps whose library is gone.  This covers the old directory-wide
    #    `libduckdb-x-shim.abi`, whose implied library path has no extension and
    #    therefore never exists.
    for @files.grep({ .basename.starts-with($prefix) && .basename.ends-with('.abi') }) -> $stamp {
        # NOTE: the pattern is `'.abi'`, not `'\.abi'` -- inside a Raku regex a
        # single-quoted run is taken literally, so `'\.abi'` would look for a
        # backslash that is never in the file name and quietly match nothing.
        my $implied = IO::Path.new($stamp.absolute.subst(/ '.abi' $/, ''));
        next if $implied.e;
        try { $stamp.unlink }
    }

    # 3. Per-process builds older than an hour.  Only when a usable library is
    #    still there: a cache with nothing usable in it must not be emptied.
    my @usable = @files.grep({ .basename.starts-with($prefix) && lib-abi($_).chars });
    if $abi.defined {
        @usable = @usable.grep({ lib-abi($_) eq $abi });
    }
    return unless @usable.elems;

    my $cutoff = now.Int - 3600;
    my $remaining-usable = @usable.elems;

    for @files.grep({ .basename.ends-with(native-ext) }) -> $lib {
        next if $lib.absolute eq $keep-path;
        my $epoch = lib-epoch($lib, $prefix);
        next unless $epoch > 0 && $epoch < $cutoff;

        # Never remove the last usable library.  It may be exactly the build
        # another process is about to load, and emptying the usable set would
        # force a rebuild on every run -- the opposite of what a cache is for.
        my $is-usable = @usable.grep({ .absolute eq $lib.absolute }).elems > 0;
        next if $is-usable && $remaining-usable <= 1;

        try { $lib.unlink }
        try { lib-stamp($lib).unlink }
        $remaining-usable-- if $is-usable;
    }

    # 4. A shared-name library with no stamp at all, predating a stamped one:
    #    left over from a naming scheme change, and nothing will load it (a
    #    library counts only when *its own* stamp matches).  Compared by mtime
    #    against a good library rather than against the clock, so the negative
    #    Instant this Rakudo reports cannot make a fresh file look ancient.
    return unless $abi.defined;
    my $shared = $dir.add($prefix ~ native-ext);
    return unless $shared.e && $shared.absolute ne $keep-path;
    return if lib-abi($shared).chars;

    my $newest-usable = @usable.max({ (try { .modified.Instant } // 0) });
    my $shared-time = try { $shared.modified.Instant } // 0;
    my $usable-time = $newest-usable.defined
        ?? (try { $newest-usable.modified.Instant } // 0)
        !! 0;
    return unless $shared-time < $usable-time;

    try { $shared.unlink }
    try { lib-stamp($shared).unlink }
}
