/* Bridge for C functions that take `duckdb_result` **by value**.
 *
 * NativeCall can only hand a CStruct to a C function as a pointer (the
 * address of the container).  That happens to be what the Microsoft x64
 * calling convention does with large structs anyway -- the caller makes a
 * copy and passes its address -- so the plain symbols work on Windows.
 *
 * On the SysV x86-64 ABI (Linux/macOS) a 48-byte non-trivial struct is in
 * the MEMORY class: it is copied onto the *stack*, not passed by reference.
 * Handing NativeCall's pointer to such a callee makes it read the struct
 * out of its own stack frame, so `internal_data` comes back as garbage and
 * DuckDB aborts with "unique_ptr NULL" from stream-c.cpp.
 *
 * These two shims take a pointer and forward a dereferenced copy, which
 * gives the compiler the correct calling convention at the call site.
 * Only the 2.0 functions that still take `duckdb_result` by value need
 * one; every other result accessor already takes `duckdb_result *`.
 */

#include "duckdb.h"

DUCKDB_C_API idx_t dbd_result_chunk_count_p(duckdb_result *result)
{
    return duckdb_result_chunk_count(*result);
}

DUCKDB_C_API duckdb_data_chunk dbd_fetch_chunk_p(duckdb_result *result)
{
    return duckdb_fetch_chunk(*result);
}
