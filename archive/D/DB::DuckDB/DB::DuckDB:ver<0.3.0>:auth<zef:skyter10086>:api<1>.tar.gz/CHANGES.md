---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_5f6512fed0d811f19fe7525400de85a5
    ReservedCode1: r/G4kgDkAPdokYtNFw8Fv9/XPY+ic1NHUNLNTwJXK8yUqmQRHGxECPCcLIXqotVuIBR1JDL78hSLmmfgZkRU83sI6JaDCc039ZSgxZkbV5mdsBRB50IpzBQgUGCkakgR075uy6I3B0spiU3BcyzSoOpMPtleN0hrD14AHxJHaFMxDtStcCqcxVoNtLQ=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_5f6512fed0d811f19fe7525400de85a5
    ReservedCode2: r/G4kgDkAPdokYtNFw8Fv9/XPY+ic1NHUNLNTwJXK8yUqmQRHGxECPCcLIXqotVuIBR1JDL78hSLmmfgZkRU83sI6JaDCc039ZSgxZkbV5mdsBRB50IpzBQgUGCkakgR075uy6I3B0spiU3BcyzSoOpMPtleN0hrD14AHxJHaFMxDtStcCqcxVoNtLQ=
---

# Changelog

Versioning follows Semantic Versioning. Because the module is still pre-1.0, the minor
number carries both new features and behaviour changes; `api` in META6.json is bumped only
when the `DB` role contract is broken.

## 0.3.0 — 2026-10-26

### Fixed

* **Crash on POSIX when a result needs more than one chunk.** `duckdb_result_chunk_count` and
  `duckdb_fetch_chunk` take `duckdb_result` *by value* (48 bytes on LP64). NativeCall's
  by-value marshalling for a struct that large happens to work under the MS x64 convention,
  but under SysV AMD64 the callee received a corrupt copy and DuckDB aborted in
  `unique_ptr`-related asserts. Any query whose result spanned multiple data chunks died;
  small results happened to fit in one chunk and looked fine.
* Result reading on POSIX no longer relies on NativeCall taking or returning `duckdb_result`
  by value anywhere.

### Added

* `DB::DuckDB::Bridge` — hands the same 48 bytes to the two remaining by-value accessors as a
  pointer instead. Enabled on POSIX only; Windows keeps binding the C API directly.
* `resources/duckdb-result-shim.c` — ~20-line pointer-in wrapper around those two accessors,
  compiled on first use into the user's data directory and cached there.

### Changed

* `DB::DuckDB::Native` binds the chunk accessors from the bridge library where one is used,
  and from `libduckdb` on Windows.
* `META6.json` gained `resources` and the `DB::DuckDB::Bridge` entry in `provides`
  (`resources` paths are declared relative to the distribution root, without the
  `resources/` prefix).
* README no longer claims the distribution is free of C code.

### Notes

* `api` stays `1`: the public `DB` interface is unchanged.
* Verified on Linux (DuckDB 1.5.x, SysV AMD64): 18 smoke assertions and the full 42-assertion
  test suite pass, including multi-chunk results; and on Windows (MS x64) as a regression
  check. `zef install` also builds the shim from the installed distribution.

## 0.2.0

* Initial NativeCall driver over the DuckDB C API: `DB` role, connections, prepared statements,
  all 2.0 result types rendered exactly like DuckDB's own `CAST(x AS VARCHAR)`.
*（内容由AI生成，仅供参考）*
