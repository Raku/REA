---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_5f6512fed0d811f19fe7525400de85a5
    ReservedCode1: r/G4kgDkAPdokYtNFw8Fv9/XPY+ic1NHUNLNTwJXK8yUqmQRHGxECPCcLIXqotVuIBR1JDL78hSLmmfgZkRU83sI6JaDCc039ZSgxZkbV5mdsBRB50IpzBQgUGCkakgR075uy6I3B0spiU3BcyzSoOpMPtleN0hrD14AHxJHaFMxDtStcCqcxVoNtLQ=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_5f6512fed0d811f19fe7525400de85a5
    ReservedCode2: r/G4kgDkAPdokYtNFw8Fv9/XPY+ic1NHUNLNTwJXK8yUqmQRHGxECPCcLIXqotVuIBR1JDL78hSLmmfgZkRU83sI6JaDCc039ZSgxZkbV5mdsBRB50IpzBQgUGCkakgR075uy6I3B0spiU3BcyzSoOpMPtleN0hrD14AHxJHaFMxDtStcCqcxVoNtLQ=
---

# Changelog

Versioning follows Semantic Versioning. Because the module is still pre-1.0, the minor
number carries both new features and behaviour changes; `api` in META6.json is bumped only
when the `DB` role contract is broken.

## 0.5.0 - 2026-10-27

### Added

* **C shim for VARCHAR columns** (`resources/duckdb-varchar-shim.c`, loaded
  through `DB::DuckDB::VarcharShim`). The vector's `duckdb_string_t` array is
  snapshotted once, then a single pass copies every payload into one contiguous
  `Buf` while filling an offsets table, a lengths table and a NULL bitmap. Raku
  side then decodes the flat buffer once and slices each value out with
  `substr`. This replaces the per-value `duckdb_string_t` dereference plus
  `Buf.push` loop that made wide string columns the slowest part of result
  reading.
  Measured against the per-value decoder on this machine:

  | rows | `column()` | `arrays()` | `hashes()` |
  |------|-----------|-----------|-----------|
  | 100k | 2.7x | 1.5x | 1.6x |
  | 500k | 3.1x | 1.8x | 1.7x |
  | 1M   | 3.4x | 1.7x | 1.8x |

* **Soft dependency on a C compiler.** The shim compiles on first use into
  `~/.local/share/DB-DuckDB` (`DB_DUCKDB_SHIM_CACHE` overrides the directory,
  `DB_DUCKDB_CC` / `CC` pick the compiler, `DB_DUCKDB_VARCHAR_SHIM` points at a
  prebuilt library). With no compiler the module logs one note and keeps using
  the pure Raku decoder; nothing fails.

### Changed

* **VARCHAR no longer falls back to the per-value decoder** whenever the shim
  is available: `column()`, `column-arrays()`, `arrays()`, `row()` and
  `hashes()` all share the batch result. The old path is kept and still used
  for non-flat vectors (dictionary or selection vectors), oversized payloads
  and unreadable pointers.

### Safety

* Everything the shim reads is validated first: the `duckdb_string_t` array is
  snapshotted into memory the shim owns, out-of-line payloads are copied with a
  read-probing helper, and any payload longer than 16 MiB (the signature of a
  selection buffer being mistaken for a string vector) makes the shim return
  `DKD_NOT_FLAT`, which makes the driver fall back instead of crashing.

## 0.4.0 - 2026-10-27

### Added

* **`column(Int $idx)`** returns every remaining value of a single column as
  one Array. It skips the per-row Array allocation, so pulling one column out
  of a wide result is roughly an order of magnitude cheaper than `arrays()`
  plus a map.
* **`column-arrays()`** drains the whole result column by column into a List of
  Arrays (one per column; named that way because `$.columns` is the column
  count accessor). Measured 1.7-2x faster than `arrays()` at 3-5 columns, and
  it is the cheapest way to consume a wide result in full.

### Changed

* **`hashes()` decodes a whole data chunk at a time**: each column is appended
  to a typed Raku array with one native loop pass, then row hashes are built
  with `nqp::hash`/`nqp::bindkey` instead of going through `Hash` assignment.
  Measured 2.2-2.6x faster at 3-5 columns on 300k rows.
* **Column decoding got typed fast paths** for the integer, unsigned integer,
  float, double and boolean vector types. Columns carrying NULLs, or types
  without a fast path (VARCHAR in particular), still fall back to the
  per-value decoder, so behaviour is unchanged.
* `row()` and `arrays()` are unchanged in behaviour; their timings sit inside
  run-to-run noise on this machine.

## 0.3.1 - 2026-10-26

### Changed

* **`Alien::Libduckdb` dependency pinned to an exact version**:
  `Alien::Libduckdb:ver<1.1.0>`. The C API is not ABI-stable across DuckDB
  majors - `duckdb_result` layout, `DUCKDB_TYPE` numbering and the by-value
  accessors all moved - so "whatever Alien is newest" was a silent
  memory-corruption risk. 1.1.0 is the release that ships libduckdb 2.0.0,
  which this binding targets.
* Alien::Libduckdb now installs libduckdb from the upstream prebuilt archive
  by default and falls back to a cmake source build; nothing changes on this
  side, the library simply appears in seconds instead of minutes.

### Added

* **ABI guard at first use.** `verify-library()` (exported from
  `DB::DuckDB::Native`) compares `duckdb_library_version()` with
  `BINDING-MAJOR` (2) and the driver calls it before opening its first
  database handle. A 1.x/3.x library reached through `%DB_DUCKDB_LIB`, a
  stale `duckdb.dll` next to `raku`, or a system libduckdb now dies with an
  explanatory message instead of corrupting result reads.

## 0.3.0 — 2026-10-26

### Fixed

* **Crash on POSIX when a result needs more than one chunk.** `duckdb_result_chunk_count` and
  `duckdb_fetch_chunk` take `duckdb_result` *by value* (48 bytes on LP64). NativeCall's
  by-value marshalling for a struct that large happens to work under the MS x64 convention,
  but under SysV AMD64 the callee received a corrupt copy and DuckDB aborted in
  `unique_ptr`-related asserts. Any query whose result spanned multiple data chunks died;
  small results happened to fit in one chunk and looked fine.
* Result reading on POSIX no longer relies on NativeCall taking or returning `duckdb_result`
  by value anywhere.

### Added

* `DB::DuckDB::Bridge` — hands the same 48 bytes to the two remaining by-value accessors as a
  pointer instead. Enabled on POSIX only; Windows keeps binding the C API directly.
* `resources/duckdb-result-shim.c` — ~20-line pointer-in wrapper around those two accessors,
  compiled on first use into the user's data directory and cached there.

### Changed

* `DB::DuckDB::Native` binds the chunk accessors from the bridge library where one is used,
  and from `libduckdb` on Windows.
* `META6.json` gained `resources` and the `DB::DuckDB::Bridge` entry in `provides`
  (`resources` paths are declared relative to the distribution root, without the
  `resources/` prefix).
* README no longer claims the distribution is free of C code.

### Notes

* `api` stays `1`: the public `DB` interface is unchanged.
* Verified on Linux (DuckDB 1.5.x, SysV AMD64): 18 smoke assertions and the full 42-assertion
  test suite pass, including multi-chunk results; and on Windows (MS x64) as a regression
  check. `zef install` also builds the shim from the installed distribution.

## 0.2.0

* Initial NativeCall driver over the DuckDB C API: `DB` role, connections, prepared statements,
  all 2.0 result types rendered exactly like DuckDB's own `CAST(x AS VARCHAR)`.
*（内容由AI生成，仅供参考）*
