use DB;
use DB::DuckDB::Native;
use DB::DuckDB::Error;
use DB::DuckDB::Connection;

#| DuckDB driver for the Raku `DB` interface.
#|
#|     my $db = DB::DuckDB.new;                        # in-memory
#|     my $db = DB::DuckDB.new(path => 'data.duckdb'); # file backed
#|
#|     say $db.query('select 42').value;               # 42
#|     $db.execute('create table foo (x int, y varchar)');
#|     $db.execute('insert into foo values (?, ?)', 1, 'a');
#|
#|     for $db.query('select * from foo').hashes -> %row { say %row }
class DB::DuckDB does DB
{
    has Str $.path = ':memory:';

    # One DuckDB database instance per driver; every connection handed out
    # by `connect` shares it.  Opening the same path twice would trip
    # DuckDB's instance/file locking, and for ':memory:' it would silently
    # create independent databases.
    has DuckDB-Database $!database;
    has Bool $!opened = False;

    # Whether the loaded libduckdb has been checked against the ABI this
    # binding targets.  Done once, right before the first handle is opened.
    has Bool $!abi-checked = False;

    # Every connection ever handed out, so `close` can cut them all loose
    # even when the caller dropped the handle without calling `finish`.
    has @!live-connections;

    # Session settings (`SET TimeZone`, PRAGMAs, temp tables) only live as
    # long as the connection they were issued on.  Handing out a brand new
    # connection per statement would silently drop them, so the driver keeps
    # one connection of its own and routes every statement through it.
    has DB::DuckDB::Connection $!session;

    method connect(Bool :$finish --> DB::DuckDB::Connection)
    {
        self!open-database unless $!opened;

        my DuckDB-Connection $handle .= new;
        my $rc = duckdb-connect($!database, $handle);
        if $rc != DuckDBSuccess {
            die DB::DuckDB::Error.new(
                :code($rc),
                message => "cannot create a connection for '{$!path}'",
            );
        }

        my $conn = DB::DuckDB::Connection.new(
            :owner(self), database => $!database, :$handle,
        );
        @!live-connections.push($conn);
        $conn.finish if $finish;
        $conn;
    }

    method !open-database()
    {
        # Cheapest place to catch a library/binding mismatch: the shared
        # object is guaranteed to be resident once this returns, and every
        # later code path assumes the 2.x ABI.  Runs once per process.
        verify-library() unless $!abi-checked;
        $!abi-checked = True;

        my DuckDB-Database $database .= new;
        my $rc = duckdb-open($!path, $database);
        if $rc != DuckDBSuccess {
            die DB::DuckDB::Error.new(
                :code($rc),
                message => "cannot open DuckDB database '{$!path}'",
            );
        }
        $!database = $database;
        $!opened   = True;
    }

    submethod DESTROY()
    {
        self!release-database;
    }

    method !release-database()
    {
        duckdb-close($!database) if $!database.defined && $!database.Bool;
    }

    #| Close the underlying database instance.  Normally called for you
    #| when the driver is garbage collected.
    method close(--> Nil)
    {
        return unless $!opened;
        $!opened = False;

        # DuckDB only releases the file lock once every connection and
        # prepared statement is gone, so both are torn down first -- even
        # handles the caller forgot to `finish`.
        $!session = Nil;
        .free for @!live-connections;
        @!live-connections = ();

        self.finish;
        self!release-database;
    }

    #| Version of the linked libduckdb, e.g. "v1.5.5".
    method library-version(--> Str)
    {
        take-cstr(duckdb-library-version());
    }

    #| The driver's own long-lived connection, created on first use so that
    #| session settings survive across statements.
    method session(--> DB::DuckDB::Connection)
    {
        $!session //= do {
            self!open-database unless $!opened;
            my DuckDB-Connection $handle .= new;
            my $rc = duckdb-connect($!database, $handle);
            if $rc != DuckDBSuccess {
                die DB::DuckDB::Error.new(
                    :code($rc),
                    message => "cannot create a connection for '{$!path}'",
                );
            }
            my $conn = DB::DuckDB::Connection.new(
                :owner(self), database => $!database, :$handle,
            );
            @!live-connections.push($conn);
            $conn;
        };
    }

    #| Statements are drained by the caller, so the result must not carry a
    #| connection away: the session connection outlives every result.
    method query(Str:D $query, *@args, *%args --> DB::Result)
    {
        self.session.query($query, :finish(False), |@args, |%args);
    }

    #| Statement execution with bound arguments.  `DB`'s own execute()
    #| forwards positional arguments straight to the connection, which has
    #| no notion of placeholders -- so the placeholder-aware path lives
    #| here, on top of a cached prepared statement.
    method execute(Str:D $query, *@args, *%args --> Int)
    {
        self.session.execute($query, |@args, |%args).Int;
    }
}
