﻿#| Native binding for resources/duckdb-varchar-shim.c.
#|
#| Deliberately a separate module from DB::DuckDB::VarcharShim: loading this
#| one requires the compiled library to exist, and Result loads it with a
#| `require` inside a try so a machine without a C compiler still gets a
#| working driver (just with the slower per-value VARCHAR decoder).
#|
#| Not exported: callers reach it via `require` and grab &unpack-varchar.
unit module DB::DuckDB::VarcharShim::Native;

use NativeCall;
use DB::DuckDB::VarcharShim;

# Resolved on first use rather than in a BEGIN block: the parent module has to
# be compiled (and possibly compile the C shim) before the path is known, and
# NativeCall accepts a Callable here -- the same trick DB::DuckDB::Native uses
# for its library path.
my Str $lib-cache;

# Temporary diagnostics: DB_DUCKDB_SHIM_TRACE=<file> appends a line per step.
# Written to a file (not stderr) because a hard crash swallows buffered stderr.
my sub trace-log(Str $msg --> Nil) {
    my $path = %*ENV<DB_DUCKDB_SHIM_TRACE>;
    return unless $path && $path ne '1';
    my $fh = open $path, :a;
    $fh.say: $msg;
    $fh.close;
}

sub shim-library(--> Str)
{
    return $lib-cache if $lib-cache.defined;
    my $path = DB::DuckDB::VarcharShim::shim-lib();
    die 'DB::DuckDB::VarcharShim: the C shim is not available'
        unless $path.chars;
    $lib-cache = $path;
}

sub dkd-varchar-unpack(Pointer $data, Pointer $validity, uint64 $n,
                       Pointer $out, uint64 $cap,
                       Pointer $offsets, Pointer $lens,
                       Pointer $nulls --> uint64)
    is native(&shim-library) is symbol('dkd_varchar_unpack') { * }

sub dkd-string-layout(CArray[uint32] $out --> uint64)
    is native(&shim-library) is symbol('dkd_string_layout') { * }

#| Byte layout of duckdb_string_t as the shim sees it: (sizeof, length@,
#| inlined@, ptr@).  Used by the tests to fail loudly if DuckDB ever changes
#| the struct underneath us.
our sub string-layout(--> List)
{
    my CArray[uint32] $o .= new;
    $o[2] = 0;
    my uint64 $size = dkd-string-layout($o);
    ($size, $o[0], $o[1], $o[2]).List;
}

#| Unpack `$n` VARCHAR values into a List of Str (Any for NULL).
#|
#| The C side copies every payload into one contiguous buffer and reports the
#| offset/length of each value, so the per-value cost here is a slice instead
#| of a 16-byte struct read plus a byte-at-a-time Buf build.
our sub unpack-varchar(Pointer $data, Pointer $validity, uint64 $n --> Mu)
{
    return () if $n == 0;

    my uint64 $i;

    # Sizing pass: C reports how many payload bytes the column needs.
    trace-log("shim: enter n=$n");
    my uint64 $total = dkd-varchar-unpack($data, $validity, $n, Pointer, 0,
        Pointer, Pointer, Pointer);
    trace-log("shim: sized total=$total");
    # UINT64_MAX means the vector is not flat (a dictionary or selection
    # vector); the caller must fall back to the per-value decoder.
    return Nil if $total == 18446744073709551615;

    my CArray[uint64] $offs  .= new;
    my CArray[uint32] $lens  .= new;
    my CArray[uint8]  $nulls .= new;
    $offs[$n - 1]  = 0;
    $lens[$n - 1]  = 0;
    $nulls[$n - 1] = 0;
    trace-log("shim: arrays allocated");

    if $total == 0 {
        my @empty;
        $i = 0;
        while $i < $n { @empty.push: $nulls[$i] ?? Any !! ''; $i++ }
        return @empty.List;
    }

    my Buf $buf = Buf.allocate($total);
    trace-log("shim: buf allocated bytes=" ~ $buf.bytes);
    my uint64 $written = dkd-varchar-unpack($data, $validity, $n, nativecast(Pointer, $buf), $total,
        nativecast(Pointer, $offs), nativecast(Pointer, $lens), nativecast(Pointer, $nulls));
    trace-log("shim: filled written=$written");
    return Nil if $written == 18446744073709551615;
    my @out;

    # Fast path: a pure ASCII column has one byte per character, so the whole
    # buffer can be decoded once and every value sliced out as a substring.
    # This is the common case for ids, keys and enum-like labels.
    my Str $flat = $buf.decode('utf-8');
    if $flat.chars == $total {
        $i = 0;
        while $i < $n {
            @out.push: $nulls[$i] ?? Any !! $flat.substr($offs[$i], $lens[$i]);
            $i++;
        }
        return @out.List;
    }

    # Multibyte payload: bytes and characters no longer line up, so decode
    # each slice separately.  Every payload is a complete UTF-8 string, so no
    # slice can split a character.
    $i = 0;
    while $i < $n {
        @out.push: $nulls[$i]
            ?? Any
            !! $buf.subbuf($offs[$i], $lens[$i]).decode('utf-8');
        $i++;
    }
    @out.List;
}
