use DB::Result;
use DB::DuckDB::Native;
use DB::DuckDB::Decoder;
use NativeCall;
use nqp;

# The optional C VARCHAR unpacker, resolved at most once per process.  It is
# loaded with `require` (not `use`) because the module dies when the shim
# could not be compiled, and that must not take the whole driver down: the
# per-value decoder remains a correct fallback.
my $varchar-unpacker;
my Bool $varchar-probed = False;

sub varchar-unpacker()
{
    return $varchar-unpacker if $varchar-probed;
    $varchar-probed = True;

    # Escape hatch, also used by the tests to compare both code paths.
    if %*ENV<DB_DUCKDB_NO_VARCHAR_SHIM> {
        return $varchar-unpacker = Nil;
    }

    $varchar-unpacker = (try {
        my $mod = (require ::('DB::DuckDB::VarcharShim::Native'));
        # The shim declares its entry points with `our sub`, so they live in
        # the module's WHO table under their sigil-prefixed name.  Looking the
        # symbol up by name would work too but yields a soft Failure when the
        # module was precompiled with an older revision, which then blows up
        # later inside a DESTROY -- so probe the table and check it is Callable.
        my $sub = $mod.WHO<&unpack-varchar>;
        $sub.defined && $sub ~~ Callable ?? $sub !! Nil;
    }) // Nil;
    $varchar-unpacker;
}

class DB::DuckDB::Result does DB::Result
{
    has DuckDB-Raw-Result $.raw is required;
    has Int $.count;
    has Int $.columns;
    has Int $.rows-changed;

    has Int  $!cursor = 0;
    has Bool $!alive  = True;

    # Set when the result borrows a pooled connection that must be handed
    # back to the driver once the result is drained.
    has $!borrowed-conn;

    # --- chunk/vector state ---------------------------------------------
    has DuckDB-Data-Chunk $!chunk;
    has @!decoders;           # one Callable per column
    has @!column-types;       # duckdb_type ids, for introspection
    has uint64 $!chunk-size = 0;
    has uint64 $!chunk-pos  = 0;
    has Bool $!chunk-done = False;

    # Optional per-chunk column cache.  Only the column oriented readers
    # (arrays-fast/column/columns) fill it; row() and arrays() keep the
    # original per-cell path so their memory profile is unchanged.
    has @!col-buf;
    has Bool $!col-buf-ready = False;

    # Pre-built Hash rows for the current chunk (hashes fast path).
    has @!hash-buf;
    has uint64 $!hash-pos = 0;

    method attach-connection($conn --> Nil) { $!borrowed-conn = $conn }

    submethod BUILD(DuckDB-Raw-Result :$raw!,
                    :$sth,
                    Bool :$finish,
                    Int :$count)
    {
        $!raw     = $raw;
        $!sth     = $sth;
        $!finish  = $finish;
        $!count   = $count // duckdb-row-count($!raw).Int;
        $!columns = duckdb-column-count($!raw).Int;
        $!rows-changed = duckdb-rows-changed($!raw).Int;

        @!column-types = (duckdb-column-type($!raw, $_) for ^$!columns).List;
    }

    method names()
    {
        return () unless $!alive;
        my @names = do for ^$!columns -> $col {
            take-cstr(duckdb-column-name($!raw, $col))
        };
        @names.List;
    }

    #| Raw duckdb_type ids, one per column.
    method column-types(--> List) { @!column-types.List }

    #| Pull the next non-empty chunk and rebuild the per-column readers.
    method !next-chunk(--> Bool)
    {
        return False if $!chunk-done;

        duckdb-destroy-data-chunk($!chunk)
            if $!chunk.defined && $!chunk.Bool;
        $!chunk = DuckDB-Data-Chunk;

        my $next = duckdb-fetch-chunk($!raw);

        unless $next.defined && $next.Bool {
            $!chunk-done = True;
            $!chunk-size = 0;
            $!chunk-pos  = 0;
            @!decoders   = ();
            return False;
        }

        $!chunk      = $next;
        $!chunk-size = duckdb-data-chunk-get-size($!chunk);
        $!chunk-pos  = 0;
        $!col-buf-ready = False;

        @!decoders = ();
        for ^$!columns -> $col {
            my $vec = duckdb-data-chunk-get-vector($!chunk, $col);
            # The vector owns its logical type: duckdb_vector_get_column_type
            # returns a copy that we must destroy ourselves.
            my $lt = duckdb-vector-get-column-type($vec);
            @!decoders.push: build-decoder($vec, $lt);
            duckdb-destroy-logical-type($lt);
        }

        # DuckDB may hand out an empty chunk mid-stream; skip it.
        $!chunk-size > 0 || self!next-chunk;
    }

    method row()
    {
        return () unless $!alive;
        return () if $!columns == 0;
        return () if $!cursor >= $!count;

        while $!chunk-pos >= $!chunk-size {
            return () unless self!next-chunk;
        }

        my uint64 $pos = $!chunk-pos;

        my @row;
        for ^$!columns -> $col {
            @row.push: @!decoders[$col]($pos);
        }

        $!chunk-pos++;
        $!cursor++;
        @row;
    }

    # --- column oriented reading ------------------------------------------
    #| Append a whole integer/float/boolean vector to @dst in one typed loop.
    #| Returns False (having appended nothing) when the column has NULLs or a
    #| type without a fast path, so the caller falls back to the per-value
    #| decoder.
    method !decode-into(@dst, Pointer $data, int32 $tid, Pointer $validity,
                        uint64 $size --> Bool)
    {
        return False if $validity.defined;
        my uint64 $r = 0;
            if $tid == DUCKDB_TYPE_BIGINT {
                my CArray[int64] $a = nativecast(CArray[int64], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_INTEGER {
                my CArray[int32] $a = nativecast(CArray[int32], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_SMALLINT {
                my CArray[int16] $a = nativecast(CArray[int16], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_TINYINT {
                my CArray[int8] $a = nativecast(CArray[int8], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_UBIGINT {
                my CArray[uint64] $a = nativecast(CArray[uint64], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_UINTEGER {
                my CArray[uint32] $a = nativecast(CArray[uint32], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_USMALLINT {
                my CArray[uint16] $a = nativecast(CArray[uint16], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_UTINYINT {
                my CArray[uint8] $a = nativecast(CArray[uint8], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Int }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_DOUBLE {
                my CArray[num64] $a = nativecast(CArray[num64], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Num }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_FLOAT {
                my CArray[num32] $a = nativecast(CArray[num32], $data);
                loop (; $r < $size; $r++) { @dst.push: $a[$r].Num }
                return True;
            }
            elsif $tid == DUCKDB_TYPE_BOOLEAN {
                my CArray[uint8] $a = nativecast(CArray[uint8], $data);
                loop (; $r < $size; $r++) { @dst.push: so $a[$r] }
                return True;
            }
        False;
    }

    #| Append one column of the current chunk to @dst, falling back to the
    #| per-value decoder when the fast path does not apply.
    method !append-column(@dst, Int $col, uint64 $size --> Nil)
    {
        return if $size == 0;

        my $vec = duckdb-data-chunk-get-vector($!chunk, $col);
        my $lt  = duckdb-vector-get-column-type($vec);
        my int32 $tid = duckdb-get-type-id($lt);
        my Pointer $data     = duckdb-vector-get-data($vec);
        my Pointer $validity = duckdb-vector-get-validity($vec);

        my Bool $done = self!decode-into(@dst, $data, $tid, $validity, $size);

        # VARCHAR is the one type whose per-value cost is dominated by string
        # assembly rather than by boxing, so it goes through the C shim:
        # one buffer, one offset table, one slice per value.
        if !$done && $tid == DUCKDB_TYPE_VARCHAR {
            with varchar-unpacker() -> &unpack {
                my Pointer $mask = $validity.defined ?? $validity !! Pointer;
                my $unpacked = unpack($data, $mask, $size);
                # Nil means the shim refused: the chunk vector is not flat
                # (dictionary/selection vector), so read it value by value.
                if $unpacked.defined {
                    @dst.append: |$unpacked;
                    return;
                }
            }
        }

        unless $done {
            my &decoder = @!decoders[$col];
            my uint64 $r = 0;
            loop (; $r < $size; $r++) { @dst.push: decoder($r) }
        }
    }

    method !build-col-buf(--> Nil)
    {
        my uint64 $size = $!chunk-size;
        my @buf;
        for ^$!columns -> $col {
            my @col;
            self!append-column(@col, $col, $size);
            @buf.push: @col;
        }
        @!col-buf = @buf;
        $!col-buf-ready = True;
    }

    #| Advance one row inside the cached chunk.  Returns -1 at end of result.
    method !next-row-pos(--> Int)
    {
        return -1 unless $!alive;
        return -1 if $!columns == 0;
        return -1 if $!cursor >= $!count;

        while $!chunk-pos >= $!chunk-size {
            return -1 unless self!next-chunk;
        }

        self!build-col-buf unless $!col-buf-ready;

        my uint64 $pos = $!chunk-pos;
        $!chunk-pos++;
        $!cursor++;
        $pos.Int;
    }

    method !make-row(uint64 $pos --> Array)
    {
        my @row;
        my int $i = 0;
        my int $n = $!columns;
        while $i < $n {
            @row.push: @!col-buf[$i][$pos];
            $i++;
        }
        @row;
    }

    #| One step of the arrays-fast() iterator.
    method _next-array(--> Mu)
    {
        my $pos = self!next-row-pos;
        return Mu if $pos < 0;
        self!make-row($pos);
    }

    #| Row-wise iteration (DB::Result contract) on top of the column decoder:
    #| 1.2-1.3x faster than the per-cell path at any width.
    method arrays()
    {
        self.arrays-fast;
    }

    #| Same rows as arrays(), but decoded column by column in typed loops.
    #| 1.2-1.35x faster on integer/float results of any width.
    method arrays-fast()
    {
        my $res = self;
        Seq.new(class :: does Iterator {
            has $.res;
            method pull-one()
            {
                my $r = $!res._next-array;
                $r.defined ?? $r !! IterationEnd;
            }
        }.new(:res($res)))
    }

    #| Drain the rest of the result into the supplied per-column Arrays.
    method !drain-into(@cols --> Nil)
    {
        my int $n = @cols.elems;
        loop {
            last if $!chunk-pos >= $!chunk-size && !self!next-chunk;
            my uint64 $from = $!chunk-pos;
            my uint64 $size = $!chunk-size;
            my int $i = 0;
            if $from == 0 {
                while $i < $n {
                    self!append-column(@cols[$i], $i, $size);
                    $i++;
                }
            } else {
                while $i < $n {
                    my @tmp;
                    self!append-column(@tmp, $i, $size);
                    @cols[$i].append(@tmp[$from ..^ $size]);
                    $i++;
                }
            }
            $!cursor += ($size - $from).Int;
            $!chunk-pos = $size;
        }
    }

    #| Drain the remaining values of a single column into @dst.
    method !drain-one(Int $col, @dst --> Nil)
    {
        loop {
            last if $!chunk-pos >= $!chunk-size && !self!next-chunk;
            my uint64 $from = $!chunk-pos;
            my uint64 $size = $!chunk-size;
            if $from == 0 {
                self!append-column(@dst, $col, $size);
            } else {
                my @tmp;
                self!append-column(@tmp, $col, $size);
                @dst.append(@tmp[$from ..^ $size]);
            }
            $!cursor += ($size - $from).Int;
            $!chunk-pos = $size;
        }
    }

    #| All remaining values of one column as a single Array.  Skips the
    #| per-row Array allocation: an order of magnitude faster than arrays()
    #| when only one column is needed.
    method column(Int $idx --> Array)
    {
        die "column index $idx out of range" if $idx < 0 || $idx >= $!columns;
        my @out;
        self!drain-one($idx, @out) if $!columns > 0;
        @out;
    }

    #| All remaining values, column by column: a List with one Array per
    #| column.  This is the fastest way to consume a whole wide result.
    #| (Named column-arrays because $.columns is the column count accessor.)
    method column-arrays(--> List)
    {
        my @cols;
        for ^$!columns { @cols.push: [] }
        self!drain-into(@cols) if $!columns > 0;
        @cols.List;
    }

    #| Assemble the whole next chunk into @!hash-buf via nqp::hash.
    method !fill-hash-buf(--> Bool)
    {
        @!hash-buf = ();
        $!hash-pos = 0;
        return False unless self!next-chunk;

        my uint64 $size = $!chunk-size;
        my @cd;
        for ^$!columns -> $col {
            my @c;
            self!append-column(@c, $col, $size);
            @cd.push: @c;
        }

        my @names = self.names;
        my @buf;
        if $!columns == 3 {
            my $c0 = @cd[0]; my $c1 = @cd[1]; my $c2 = @cd[2];
            my \k0 = @names[0]; my \k1 = @names[1]; my \k2 = @names[2];
            for ^$size -> uint64 $r {
                my $h := nqp::hash();
                nqp::bindkey($h, k0, $c0[$r]);
                nqp::bindkey($h, k1, $c1[$r]);
                nqp::bindkey($h, k2, $c2[$r]);
                @buf.push: $h;
            }
        }
        else {
            for ^$size -> uint64 $r {
                my $h := nqp::hash();
                for ^$!columns -> $col {
                    nqp::bindkey($h, @names[$col], @cd[$col][$r]);
                }
                @buf.push: $h;
            }
        }
        @!hash-buf = @buf;
        True;
    }

    #| One step of the hashes() iterator.
    method _next-hash(--> Mu)
    {
        if $!hash-pos >= @!hash-buf.elems {
            return Mu unless self!fill-hash-buf;
        }
        my $h = @!hash-buf[$!hash-pos];
        $!hash-pos++;
        $!cursor++;
        $h;
    }

    #| Hash rows built straight from the column buffers with nqp::hash, which
    #| avoids the Z=> / %() round trip of the generic implementation.
    method hashes()
    {
        my $res = self;
        Seq.new(class :: does Iterator {
            has $.res;
            method pull-one()
            {
                my $h = $!res._next-hash;
                $h.defined ?? $h !! IterationEnd;
            }
        }.new(:res($res)))
    }

    method free(--> Nil)
    {
        return unless $!alive;
        $!alive = False;

        duckdb-destroy-data-chunk($!chunk)
            if $!chunk.defined && $!chunk.Bool;
        $!chunk = DuckDB-Data-Chunk;

        duckdb-destroy-result($!raw);

        # `DB` always asks for `:finish` on `query` / `execute`, meaning the
        # statement must not stay cached once its result is drained.
        $!sth.finish if $!finish && $!sth.defined;

        if $!borrowed-conn.defined {
            my $conn = $!borrowed-conn;
            $!borrowed-conn = Nil;
            $conn.finish;
        }
    }

    submethod DESTROY() { self.free }
}
