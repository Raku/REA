﻿#| Locate -- and if necessary compile -- the VARCHAR unpacking shim described
#| in resources/duckdb-varchar-shim.c.
#|
#| The shim is a self contained C file: it does not include duckdb.h and does
#| not link against libduckdb, it only knows the byte layout of
#| duckdb_string_t.  That keeps the build trivial (any C compiler, one -shared
#| flag) and means it can be built on platforms where the by-value bridge in
#| DB::DuckDB::Bridge is not needed.
#|
#| Failure is always soft: when no compiler is available, or the build fails,
#| shim-lib() returns an empty string and DB::DuckDB::Result keeps using the
#| pure Raku decoder.
unit module DB::DuckDB::VarcharShim;

my Str  $lib-path;
my Bool $probed = False;

sub native-ext(--> Str)
{
    return '.dll' if $*DISTRO.is-win;
    $*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so';
}

#| The C source, either from the distribution's resources or from a plain
#| `-I lib` checkout (where %?RESOURCES has no distribution to read from).
sub shim-source(--> IO::Path)
{
    my $from-res = quietly { %?RESOURCES<duckdb-varchar-shim.c> };
    return $from-res.IO if $from-res.defined && $from-res.IO.e;

    # lib/DB/DuckDB/VarcharShim.rakumod -> <root>/resources/...
    my $local = $?FILE.IO.parent.parent.parent.parent
                    .child('resources/duckdb-varchar-shim.c');
    $local.e ?? $local !! IO::Path;
}

sub cache-dir(--> IO::Path)
{
    %*ENV<DB_DUCKDB_SHIM_CACHE>
        ?? %*ENV<DB_DUCKDB_SHIM_CACHE>.IO
        !! $*HOME.IO.add('.local/share/DB-DuckDB');
}

sub shim-target(--> IO::Path)
{
    cache-dir.add('libduckdb-varchar-shim' ~ native-ext());
}

#| Compilers to try, in order.  An explicit DB_DUCKDB_CC / CC wins, then the
#| usual names on PATH, then the toolchain locations that are commonly on
#| Windows boxes but never on PATH.
sub compiler-candidates(--> List)
{
    my @c;
    @c.push: %*ENV<DB_DUCKDB_CC> if %*ENV<DB_DUCKDB_CC>;
    @c.push: %*ENV<CC>           if %*ENV<CC>;
    @c.append: 'cc', 'gcc', 'clang';

    if $*DISTRO.is-win {
        @c.append: |<
            C:/msys64/mingw64/bin/gcc.exe
            C:/msys64/ucrt64/bin/gcc.exe
            C:/msys64/clang64/bin/clang.exe
            C:/Strawberry/c/bin/gcc.exe
            C:/TDM-GCC-64/bin/gcc.exe
            C:/mingw64/bin/gcc.exe
            C:/rakudo/share/llvm-mingw/bin/gcc.exe
        >;

        # llvm-mingw installs unpack to a versioned directory; pick up whatever
        # is on the fixed drives.
        for <C D E>.map({ $_ ~ ':/' }) -> $root {
            next unless $root.IO.d;
            my @dirs = quietly { dir($root).grep({ .d && .basename.starts-with('llvm-mingw') }) };
            for @dirs -> $d {
                my $g = $d.add('bin/gcc.exe');
                @c.push: $g.absolute if $g.e;
            }
        }
    }
    @c.cache;
}

#| Compile the shim when it is missing or older than its source.  Returns an
#| undefined IO::Path when the source or a working compiler is missing.
sub build-shim(--> IO::Path)
{
    my $src = shim-source();
    return IO::Path unless $src.defined;

    my $out = shim-target();
    return $out if $out.e && $out.modified >= $src.modified;

    $out.parent.mkdir unless $out.parent.e;

    my @flags = $*DISTRO.is-win
        ?? ('-O2', '-shared')
        !! ('-fPIC', '-O2', '-shared');

    for compiler-candidates() -> $cc {
        my @cmd = $cc, |@flags, '-o', $out.absolute, $src.absolute;
        my $ok = try {
            my $proc = run(|@cmd, :out, :err);
            my $err-text = $proc.err.slurp(:close);
            $proc.out.slurp(:close);
            note "DB::DuckDB::VarcharShim: $cc exited {$proc.exitcode}:\n$err-text"
                if $proc.exitcode != 0 && $err-text.chars;
            $proc.exitcode == 0;
        } // False;

        return $out if $ok && $out.e;
    }

    note "DB::DuckDB::VarcharShim: no working C compiler found; VARCHAR "
      ~ "columns keep using the pure Raku decoder.  Set DB_DUCKDB_CC to "
      ~ "pick one.";
    IO::Path;
}

#| Absolute path of the compiled shim, or an empty string when unavailable.
#| Resolution happens once per process.
our sub shim-lib(--> Str) is export
{
    return $lib-path if $probed;
    $probed = True;

    if %*ENV<DB_DUCKDB_VARCHAR_SHIM> -> $explicit {
        return $lib-path = $explicit
            if $explicit.chars && $explicit.IO.e;
    }

    my $out = build-shim();
    $lib-path = $out.defined && $out.e ?? $out.absolute !! '';
}

#| True when the shim compiled (or was supplied) and can be loaded.
our sub shim-active(--> Bool) is export
{
    shim-lib().chars > 0;
}

#| The source file the shim was built from, for diagnostics.
sub shim-source-file(--> IO::Path) is export { shim-source() }
