---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_8473260bcdfb11f18a50525400cd780f
    ReservedCode1: cI0zLrooC0vi+C5ifCc68IcqjKSpNgmiECl40/R0n/HoaGE78G2vEUn3WHKk9qPOaYa5NIWyjYR7uFC7FWvWrNMitTXrYpA3S7aiLGYhjutk4Gjmo28xdwosX9UZ7IF9Xu6BbK+WEmeB6XuVKB2tnRLuedznInEisibatti24Ck1QHc/kZ/8MnJP2BE=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_8473260bcdfb11f18a50525400cd780f
    ReservedCode2: cI0zLrooC0vi+C5ifCc68IcqjKSpNgmiECl40/R0n/HoaGE78G2vEUn3WHKk9qPOaYa5NIWyjYR7uFC7FWvWrNMitTXrYpA3S7aiLGYhjutk4Gjmo28xdwosX9UZ7IF9Xu6BbK+WEmeB6XuVKB2tnRLuedznInEisibatti24Ck1QHc/kZ/8MnJP2BE=
---



# DB::DuckDB

A DuckDB driver for Raku's [DB](https://raku.land/zef:raku-community-modules/DB) interface,
implemented as a direct [NativeCall](https://docs.raku.org/language/nativecall) binding over
the DuckDB C API — no external process, no hand-maintained FFI layer. The only C code in the
distribution is a ~20-line pointer bridge that exists because the two remaining by-value
`duckdb_result` accessors cannot be called safely from NativeCall on SysV platforms; it is
compiled on first use and skipped entirely on Windows.

```raku
use DB::DuckDB;

my $db = DB::DuckDB.new;                              # in-memory
# my $db = DB::DuckDB.new(path => 'data.duckdb');     # file backed

say $db.query('select 42').value;                     # 42

$db.execute('create table foo (id integer, name varchar)');
$db.execute('insert into foo values (?, ?)', 1, 'a');

for $db.query('select * from foo').hashes -> %row {
    say %row<id>, %row<name>;
}
```

## Status

Early but working. Implemented and covered by tests:

* driver: `new`, `connect`, `query`, `execute`, `close`, `library-version`
* connection: `prepare`, `prepare-nocache`, `query`, `execute`, `begin`, `commit`, `rollback`, `ping`, `finish`
* statement: positional `?` and named `$name` placeholders (DuckDB syntax; `:name` is not supported), binding and rebinding, `execute`
* result: `value`, `row`, `array`, `hash`, `arrays`, `hashes`, `column`, `column-arrays`, `names`, `rows`, `rows-changed`, `free`

Results are read chunk by chunk out of the vectors and decoded in Raku (`DB::DuckDB::Decoder`),
because 2.0 stopped rendering several types through `duckdb_value_varchar`. `VARCHAR` columns
are unpacked in bulk by a small C shim (see *Design notes*) and fall back to the per-value
decoder when the shim cannot be built.

Not implemented (yet): callbacks/UDFs, extension loading, `Appender`, and anything that needs a
by-value struct return (see *Design notes*).

## Requirements

* Raku 6.d / Rakudo (tested on Rakudo 2025.06, Windows 11)
* `DB`, plus `Alien::Libduckdb`, which puts a libduckdb where this module can
  find it: a prebuilt archive in seconds, a cmake source build as fallback
  (5-20 minutes). `zef` resolves both automatically.
* *Optional:* a C compiler for the `VARCHAR` shim. It is not required - without
  one the driver just logs a note and uses the slower pure Raku decoder. Set
  `DB_DUCKDB_CC` if the compiler is not called `cc`/`gcc`/`clang` and not in one
  of the usual Windows toolchain directories.

### The VARCHAR shim

`resources/duckdb-varchar-shim.c` is a self-contained C file: it does not
include `duckdb.h` and does not link libduckdb, it only knows the byte layout of
`duckdb_string_t`. It is compiled on first use (one `gcc -O2 -shared`) into
`~/.local/share/DB-DuckDB` and reloaded from there afterwards; it is rebuilt
whenever the `.c` file it came from is newer.

| variable | effect |
|---|---|
| `DB_DUCKDB_VARCHAR_SHIM` | path of a prebuilt shim library; skips the build |
| `DB_DUCKDB_SHIM_CACHE` | where the built library is cached |
| `DB_DUCKDB_CC` / `CC` | compiler to use |
| `DB_DUCKDB_NO_VARCHAR_SHIM=1` | never use the shim (pure Raku decoder) |
| `DB_DUCKDB_SHIM_TRACE` | path of a log file; the shim appends a line per step (survives a hard crash, unlike stderr) |

The two paths are cross-checked in `t/04-varchar-shim.rakutest`: both digests
of the same table have to match byte for byte.

### Why the Alien dependency is pinned

The DuckDB C API is not ABI-stable across majors: `duckdb_result` is passed by
value, the `DUCKDB_TYPE` enum was renumbered, and the by-value accessors moved.
This binding is written and tested against **DuckDB 2.x**, so `META6.json`
asks for exactly `Alien::Libduckdb:ver<1.1.0>` - the release that ships
libduckdb 2.0.0 - instead of whatever is newest. Bumping that pin is a
deliberate act: read `duckdb.h`, check the result struct layout, run `t/`, then
bump.

As a second line of defence, the driver calls `duckdb_library_version()` right
before it opens its first database handle and refuses to continue when the
loaded library is not 2.x:

```
DB::DuckDB: libduckdb v3.0.0 is not ABI-compatible with this binding, which
targets DuckDB 2.x; library in use: C:\rakudo\bin\duckdb.dll. ...
```

That catches what the pin cannot: a `DB_DUCKDB_LIB` override, a stale
`duckdb.dll` sitting next to `raku`, or a system libduckdb.

### How the library is located

1. `Alien::Libduckdb::shared-lib()` - the private prefix that `zef install`
   set up (this is the normal path)
2. `%DB_DUCKDB_LIB` environment variable, if it points at an existing file
3. `resources/libraries/duckdb` inside the distribution, if installed with one
4. next to the running `raku` executable - this covers `C:\rakudo\bin\duckdb.dll`
5. `/usr/local/lib`, `/usr/lib`, `/opt/homebrew/lib`
6. bare `duckdb`, letting the OS loader search

```powershell
$env:DB_DUCKDB_LIB = 'C:\rakudo\bin\duckdb.dll'
```
## Install

```sh
zef install .
```

Or run straight from a checkout:

```sh
raku -Ilib -e 'use DB::DuckDB; say DB::DuckDB.new.query("select version()").value'
```

## Type mapping (DuckDB → Raku)

| DuckDB type | Raku value |
|---|---|
| `BOOLEAN` | `Bool` |
| `TINYINT` / `SMALLINT` / `INTEGER` / `BIGINT` | `Int` |
| `UTINYINT` / `USMALLINT` / `UINTEGER` / `UBIGINT` | `Int` |
| `FLOAT` / `DOUBLE` | `Num` |
| `VARCHAR` | `Str` |
| `NULL` (any type) | `Any` (undefined) |
| `DATE`, `TIME`, `TIMESTAMP`, `TIMESTAMP_S/_MS/_NS`, `TIME_TZ`, `TIMESTAMP_TZ`, `TIMESTAMP_TZ_NS` | `Str` in DuckDB's own ISO rendering (session time zone honoured) |
| `DECIMAL`, `HUGEINT` / `UHUGEINT` | `Str`, exact and lossless |
| `BLOB`, `UUID`, `ENUM`, `INTERVAL`, `LIST`, `STRUCT`, `MAP`, `UNION`, `BIT`, `BIGNUM`, `ARRAY` | `Str` in DuckDB's textual rendering |
| `SQLNULL` type | `Any` |

Raku → DuckDB (bind): `Bool` → `BOOLEAN`, `Int` → `BIGINT`, `Num` / `Rat` / `FatRat` → `DOUBLE`,
`Str` → `VARCHAR`, `Blob` → `BLOB`, undefined → `NULL`, anything else → its `.Str`.

Dates and decimals are deliberately *not* auto-coerced into Raku `Date`/`DateTime`/`Rat`:
DuckDB's own textual rendering is exact for every type, while the `duckdb_value_*` family that
would return real date/decimal structures is deprecated and partly by-value. Exactness beats
convenience here — convert at the call site when you need it.

## Design notes

* **One database instance per driver.** `connect` creates connections that all share a single
  `duckdb_database`. Opening `:memory:` twice would silently create two independent databases,
  and opening a file path twice trips DuckDB's instance/file locking, so the driver opens once
  and guards it with `$!opened`.
* **`duckdb_result` is mapped as a fixed-layout struct** (48 bytes on LP64: three `idx_t` plus
  three pointers) and its size is asserted at load time, so an ABI change fails loudly instead
  of corrupting memory.
* **Results are read through the chunk/vector API.** `duckdb_result_chunk_count` /
  `duckdb_fetch_chunk` hand back a `duckdb_data_chunk` pointer, and each vector's data
  buffer is read in place; the structs living inside those buffers are dissected field by field
  through `uint32`/`uint64` views, since NativeCall faults on `CStruct` array element access on
  Windows. No struct is ever returned or taken by value, with one deliberate exception: the two
  accessors that still declare a by-value `duckdb_result` are called through
  `DB::DuckDB::Bridge`, which passes the same 48 bytes as a pointer. NativeCall's by-value
  marshalling happens to work under MS x64 but is miscompiled under SysV, where it surfaced as
  `unique_ptr` NULL crashes inside DuckDB.
* **Values are rendered exactly like DuckDB's own `CAST(x AS VARCHAR)`**, not coerced into Raku
  `Date`/`DateTime`/`Rat`. `TIMESTAMP_TZ` is the one piece of session state involved: the vector
  holds UTC microseconds, so the instant is shifted by the session zone's offset (synced from
  `strftime(..., '%z')` on construction and refreshed after `SET TimeZone`) and only then
  labelled with that offset.
* **Prepared statements are cached per connection** by the `DB` role; statements are destroyed
  when their connection is dropped. `close` also tears down connections the caller forgot to
  `finish`, because DuckDB will not release the file lock until every connection and prepared
  statement is gone.
* **`VARCHAR` is unpacked in bulk by a C shim.** Decoding a string column one
  `duckdb_string_t` at a time and `Buf.push`-ing each payload was the slowest
  thing in result reading (and pure-Raku batching was slower still, because
  every payload still had to be copied byte by byte). `duckdb-varchar-shim.c`
  snapshots the vector's `duckdb_string_t` array once, then copies every payload
  into one flat buffer while writing an offsets table, a lengths table and a
  NULL bitmap; Raku decodes that buffer once and slices values out with
  `substr`. Measured 2.7-3.4x on `column()` and 1.5-1.8x on `arrays()`/`hashes()`
  at 100k-1M rows.
  The shim never trusts the pointers it is handed: the `string_t` array is
  copied into memory it owns before being walked, out-of-line payloads are read
  through a probing copy, a payload longer than 16 MiB (the signature of a
  selection buffer mistaken for a string vector) and any unreadable pointer make
  it return `DKD_NOT_FLAT`, which is the signal to fall back to the per-value
  decoder for that chunk.
* **Works on Windows without an import library**: the DLL is loaded at runtime, so the MSVC
  `.lib` that ships with the C API is not needed.

## Tests

```sh
raku -Ilib t/01-basic.rakutest    # types, placeholders, transactions, errors
raku -Ilib t/02-file.rakutest     # file database, multiple connections, reopen
raku -Ilib t/03-types.rakutest    # every 2.0 type vs. DuckDB's own text rendering,
                                  # NULLs, chunked results, session time zone, uuid
```

## License

Artistic-2.0
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
