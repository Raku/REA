use NativeCall;
use DB::DuckDB::Native;
use DB::DuckDB::Error;

#| Bulk-load handle over DuckDB's C appender.
#|
#|     my $ap = $db.appender('measurements');
#|     $ap.append-row(1, 'x', 1.5);
#|     $ap.append-row([2, 'y', 2.5]);   # a single Positional is unpacked
#|     $ap.free;                        # flush + close + destroy
#|
#| Values are dispatched on their Raku type: `Bool` -> `duckdb_append_bool`,
#| `Int` -> `int64`, `Num`/`Rat` -> `double`, `Str`/anything else -> varchar
#| (DuckDB casts it at the column type), `Blob` -> blob and undefined ->
#| NULL.  Rows are buffered by DuckDB and committed when the appender is
#| flushed or closed; wrap the whole load in a transaction when you need it
#| to be atomic (`Connection.insert-rows` and `Connection.execute-many` do
#| that for you).
#|
#| Writing a whole list of rows goes through a specialised row writer
#| instead of the generic type dispatch above: the column types of the
#| target table are read once, and each column gets a small filler that
#| calls the matching `duckdb_append_*` directly, with the return code
#| compared inline.  That removes the per value `given`/`when` chain and a
#| Raku sub call per column; a 4 column bulk load goes from ~9-12 us to
#| ~3-4 us per row (best of several runs on the same machine).  Only the
#| four hot kinds (integer, float, text, boolean) are specialised;
#| `DECIMAL`, temporal, blob and nested columns keep the generic path so
#| exactness is preserved.
unit class DB::DuckDB::Appender;

has DuckDB-Appender $!handle;
has Str $.table is required;
has Str $.schema;
has Bool $!alive = True;
has Bool $!closed = False;
has Int $!rows = 0;
has Int $!width = 0;
has Bool $!planned = False;

#| Per column filler built from the target table's column types; see
#| `!plan-columns`.
has @!fillers;

#| Largest value `int64` can hold.  Anything wider goes through the varchar
#| path so DuckDB can widen it to HUGEINT/DECIMAL instead of wrapping.
my constant INT64-MIN = -9223372036854775808;
my constant INT64-MAX =  9223372036854775807;

#| Open an appender on `$table`.  `$schema` is optional: DuckDB uses the
#| connection's default schema when it is not given.
method open(DuckDB-Connection $connection, Str:D $table, Str :$schema --> DB::DuckDB::Appender)
{
    my Pointer $schema-ptr = Pointer;
    my $schema-buf;

    if $schema.defined && $schema.chars {
        my $bytes = $schema.encode('utf-8');
        my CArray[uint8] $buf .= allocate($bytes.elems + 1);
        $buf[$_] = $bytes[$_] for ^$bytes.elems;
        $buf[$bytes.elems] = 0;
        $schema-buf = $buf;
        $schema-ptr = nativecast(Pointer, $buf);
    }

    my DuckDB-Appender $handle .= new;
    my $rc = duckdb-appender-create($connection, $schema-ptr, $table, $handle);

    if $rc != DuckDBSuccess {
        my $msg = $handle.Bool
            ?? take-cstr(duckdb-appender-error($handle))
            !! '';
        duckdb-appender-destroy($handle) if $handle.Bool;
        die DB::DuckDB::Error.new(
            :code($rc),
            message => ($msg.chars ?? $msg !! "cannot open an appender for table '{$table}'"),
        );
    }

    # NOTE: `self.bless(:$handle)` silently drops the pointer 鈥?a `CPointer`
    # repr attribute is re-created (null) when passed through `bless`.  The
    # handle must be assigned to the attribute *after* construction.
    my $self = self.bless(:$table, :$schema);
    $self!set-handle($handle);
    $self!init-width;
    $self;
}

method !set-handle(DuckDB-Appender $handle --> Nil)
{
    $!handle = $handle;
}

method !init-width(--> Nil)
{
    $!width = duckdb-appender-column-count($!handle).Int;
}

#========================================================================
# Row writer -- specialised fillers
#========================================================================

#| How the row writer treats a column.  The hot kinds get a filler that
#| calls the matching `duckdb_append_*` directly; everything else falls
#| back to the full type dispatch.
my constant KIND-GENERIC = 0;
my constant KIND-INT     = 1;
my constant KIND-FLOAT   = 2;
my constant KIND-TEXT    = 3;
my constant KIND-BOOL    = 4;
my constant KIND-DECIMAL = 5;

my sub column-kind(Int $type-id --> Int)
{
    given $type-id {
        when DUCKDB_TYPE_BOOLEAN    { KIND-BOOL }
        when DUCKDB_TYPE_TINYINT    | DUCKDB_TYPE_SMALLINT | DUCKDB_TYPE_INTEGER
           | DUCKDB_TYPE_BIGINT     | DUCKDB_TYPE_UTINYINT | DUCKDB_TYPE_USMALLINT
           | DUCKDB_TYPE_UINTEGER   | DUCKDB_TYPE_UBIGINT
           | DUCKDB_TYPE_HUGEINT    | DUCKDB_TYPE_UHUGEINT { KIND-INT }
        when DUCKDB_TYPE_FLOAT      | DUCKDB_TYPE_DOUBLE   { KIND-FLOAT }
        when DUCKDB_TYPE_VARCHAR    | DUCKDB_TYPE_ENUM     { KIND-TEXT }
        when DUCKDB_TYPE_DECIMAL    { KIND-DECIMAL }
        default                     { KIND-GENERIC }
    }
}

#| Raise the appender's own error message.  A sub rather than a method so
#| the fillers do not have to capture `self` -- a closure stored in an
#| attribute and closing over the invocant would keep the appender alive
#| for good, and its handle would then never be destroyed.
my sub raise-appender-error(int32 $code, DuckDB-Appender $handle, Str $what --> Nil)
{
    my $msg = take-cstr(duckdb-appender-error($handle));
    die DB::DuckDB::Error.new(
        :$code,
        message => ($msg.chars ?? $msg !! $what),
    );
}

my sub check-rc(int32 $code, DuckDB-Appender $handle, Str $what --> Nil)
{
    raise-appender-error($code, $handle, $what) unless $code == DuckDBSuccess;
}

#| The generic, type-dispatched append.  Used for every value that the
#| specialised fillers do not cover.
my sub append-generic-value(DuckDB-Appender $handle, $value --> Nil)
{
    unless $value.defined {
        check-rc(duckdb-append-null($handle), $handle, 'append null failed');
        return;
    }

    given $value {
        when Bool {
            check-rc(duckdb-append-bool($handle, $value), $handle, 'append boolean failed');
        }
        when Int {
            if INT64-MIN <= $value <= INT64-MAX {
                check-rc(duckdb-append-int64($handle, $value), $handle, 'append integer failed');
            }
            else {
                check-rc(duckdb-append-varchar($handle, $value.Str), $handle, 'append wide integer failed');
            }
        }
        when Rat {
            # A Rat whose denominator only has 2/5 factors has an exact finite
            # decimal expansion (e.g. `1.25` or `0.5`), so hand it to DuckDB as
            # text: `DECIMAL` columns keep the exact value and `DOUBLE` columns
            # parse it the same way the SQL literal would.  Everything else
            # (1/3, ...) has no exact text form -> go through double.
            my $rest = $value.denominator;
            $rest = $rest div 2 while $rest > 1 && $rest % 2 == 0;
            $rest = $rest div 5 while $rest > 1 && $rest % 5 == 0;
            my $code = $rest == 1
                ?? duckdb-append-varchar($handle, $value.Str)
                !! duckdb-append-double($handle, $value.Num);
            check-rc($code, $handle, 'append decimal failed');
        }
        when Num | FatRat {
            check-rc(duckdb-append-double($handle, $value.Num), $handle, 'append number failed');
        }
        when Str {
            check-rc(duckdb-append-varchar($handle, $value), $handle, 'append string failed');
        }
        when Blob {
            my $len = $value.elems;
            my CArray[uint8] $buf .= allocate($len || 1);
            $buf[$_] = $value[$_] for ^$len;
            check-rc(duckdb-append-blob($handle, $buf, $len.Int), $handle, 'append blob failed');
        }
        default {
            check-rc(duckdb-append-varchar($handle, $value.Str), $handle, 'append value failed');
        }
    }
}

#| Build the filler for one column.  The returned closure only captures the
#| native handle, so the plan can be cached on the appender without pinning
#| its invocant.
my sub make-filler(Int $kind, DuckDB-Appender $handle --> Code)
{
    # The happy path of every filler is a type test plus one FFI call.  The
    # return code is compared inline instead of going through `check-rc`, so
    # the common case costs no Raku sub call at all.
    given $kind {
        when KIND-INT {
            -> $value {
                if $value ~~ Int {
                    if INT64-MIN <= $value <= INT64-MAX {
                        my $rc = duckdb-append-int64($handle, $value);
                        raise-appender-error($rc, $handle, 'append integer failed') unless $rc == DuckDBSuccess;
                    }
                    else {
                        # Wider than int64: let DuckDB parse the decimal text
                        # so the value is not silently wrapped.
                        my $rc = duckdb-append-varchar($handle, $value.Str);
                        raise-appender-error($rc, $handle, 'append wide integer failed') unless $rc == DuckDBSuccess;
                    }
                }
                elsif $value.defined {
                    append-generic-value($handle, $value);
                }
                else {
                    my $rc = duckdb-append-null($handle);
                    raise-appender-error($rc, $handle, 'append null failed') unless $rc == DuckDBSuccess;
                }
            }
        }
        when KIND-FLOAT {
            -> $value {
                if $value ~~ Num {
                    my $rc = duckdb-append-double($handle, $value);
                    raise-appender-error($rc, $handle, 'append number failed') unless $rc == DuckDBSuccess;
                }
                elsif $value ~~ Int {
                    my $rc = duckdb-append-double($handle, $value.Num);
                    raise-appender-error($rc, $handle, 'append number failed') unless $rc == DuckDBSuccess;
                }
                elsif $value.defined {
                    append-generic-value($handle, $value);
                }
                else {
                    my $rc = duckdb-append-null($handle);
                    raise-appender-error($rc, $handle, 'append null failed') unless $rc == DuckDBSuccess;
                }
            }
        }
        when KIND-TEXT {
            -> $value {
                if $value ~~ Str {
                    my $rc = duckdb-append-varchar($handle, $value);
                    raise-appender-error($rc, $handle, 'append string failed') unless $rc == DuckDBSuccess;
                }
                else {
                    append-generic-value($handle, $value);
                }
            }
        }
        when KIND-BOOL {
            -> $value {
                if $value ~~ Bool {
                    my $rc = duckdb-append-bool($handle, $value);
                    raise-appender-error($rc, $handle, 'append boolean failed') unless $rc == DuckDBSuccess;
                }
                else {
                    append-generic-value($handle, $value);
                }
            }
        }
        when KIND-DECIMAL {
            # `DECIMAL` keeps the generic path for anything that is not a
            # plain integer so a `Rat` still lands as exact text instead of
            # being rounded through a double.
            -> $value {
                if $value ~~ Int && INT64-MIN <= $value <= INT64-MAX {
                    my $rc = duckdb-append-int64($handle, $value);
                    raise-appender-error($rc, $handle, 'append integer failed') unless $rc == DuckDBSuccess;
                }
                else {
                    append-generic-value($handle, $value);
                }
            }
        }
        default {
            -> $value { append-generic-value($handle, $value) }
        }
    }
}

method !check(int32 $code, Str $what --> Nil)
{
    return if $code == DuckDBSuccess;

    my $msg = take-cstr(duckdb-appender-error($!handle));
    die DB::DuckDB::Error.new(
        :$code,
        message => ($msg.chars ?? $msg !! $what),
    );
}

method !append-value($value --> Nil)
{
    append-generic-value($!handle, $value);
}

#| Read the target table's column types once and build one filler per
#| column.  `duckdb_appender_column_type` hands out an owned logical type,
#| so each handle is destroyed as soon as its type id has been read.
method !plan-columns(--> Nil)
{
    return if $!planned;

    my @fillers;
    for ^$!width -> $c {
        my $type = duckdb-appender-column-type($!handle, $c);
        my $kind = column-kind(duckdb-get-type-id($type).Int);
        duckdb-destroy-logical-type($type) if $type.Bool;
        @fillers.push(make-filler($kind, $!handle));
    }

    @!fillers = @fillers;
    $!planned = True;
}

#| Fill the columns a short row did not supply with their DEFAULT (NULL
#| when the column has none).
method !append-defaults(Int $supplied --> Nil)
{
    for ^($!width - $supplied) {
        check-rc(duckdb-append-default($!handle), $!handle, 'append default failed');
    }
}

method !check-width(Int $count --> Nil)
{
    return unless $!width > 0 && $count > $!width;
    die DB::DuckDB::Error.new(
        message => "row has $count values but table '{$!table}' has {$!width} columns",
    );
}

#| The general path, used for rows that do not line up with the table
#| width.  Kept separate from `append-row` so multi dispatch cannot bounce
#| between the two candidates.
method !append-row-values($vals --> Nil)
{
    self!append-value($_) for $vals.list;
    self!append-defaults($vals.elems);
    check-rc(duckdb-appender-end-row($!handle), $!handle, 'end row failed');
    $!rows++;
}

#| Write one row through the specialised fillers when the value count
#| matches the table width, otherwise through the general path.
method !append-row-object($row --> Nil)
{
    self!assert-alive;

    my $vals = $row ~~ Positional && $row !~~ Blob ?? $row !! ($row,);

    if $!width > 0 && $vals.elems == $!width {
        self!plan-columns;
        my @fillers = @!fillers;
        for ^$!width -> $c { @fillers[$c]($vals[$c]) }
        my $rc = duckdb-appender-end-row($!handle);
        raise-appender-error($rc, $!handle, 'end row failed') unless $rc == DuckDBSuccess;
        $!rows++;
        return;
    }

    self!check-width($vals.elems);
    self!append-row-values($vals.list);
}

#| Append one row.  Accepts either a list of values (`append-row(1, 'a')`)
#| or a single Positional (`append-row(@row)`).  Columns beyond the supplied
#| values get their DEFAULT (NULL when the column has none).
multi method append-row(*@values --> Nil)
{
    # A single Positional is the row itself (`append-row(@row)`); otherwise
    # the arguments are the row (`append-row(1, 'a')`).
    self!append-row-object(@values.elems == 1 && @values.head ~~ Positional
        ?? @values.head
        !! @values);
}

multi method append-row(@values --> Nil)
{
    self!append-row-object(@values);
}

#| Append many rows in one call; each element is a Positional.
#|
#| This is the hot path for bulk loads: the column types are resolved once
#| and the values are written by per column fillers, which is what takes
#| the cost from ~37 us to ~3 us per row (the generic per value type
#| dispatch formerly dominated the FFI call by a factor of ~40).
multi method append-rows(@rows --> Int)
{
    self!assert-alive;

    # A table with no columns (or an appender whose width DuckDB could not
    # report) still has to accept rows, so fall back to the general path.
    if $!width == 0 {
        self!append-row-object($_) for @rows;
        return $!rows;
    }

    self!plan-columns;

    my $handle = $!handle;
    my $width  = $!width;
    my @fillers = @!fillers;

    for @rows -> $row {
        my $vals = $row ~~ Positional && $row !~~ Blob ?? $row !! ($row,);

        if $vals.elems == $width {
            for ^$width -> $c { @fillers[$c]($vals[$c]) }
            my $rc = duckdb-appender-end-row($handle);
            raise-appender-error($rc, $handle, 'end row failed') unless $rc == DuckDBSuccess;
            $!rows++;
        }
        else {
            self!check-width($vals.elems);
            self!append-row-values($vals.list);
        }
    }

    $!rows;
}

#| Push buffered rows into the table without closing the appender.
method flush(--> Nil)
{
    self!assert-alive;
    self!check(duckdb-appender-flush($!handle), 'flush failed');
}

#| Flush and close: no further rows can be appended afterwards.
method close(--> Nil)
{
    self!assert-alive;
    self!check(duckdb-appender-close($!handle), 'close failed');
    $!closed = True;
}

#| Flush, close and destroy the handle.  Idempotent.
#|
#| Rows are only really validated when the appender is flushed, so this is
#| where a duplicate key / failed cast surfaces: the error is raised instead
#| of being swallowed, otherwise a bulk load could look successful while
#| writing nothing.
method free(--> Nil)
{
    return unless $!alive;
    $!alive = False;
    return unless $!handle.Bool;

    my int32 $code = DuckDBSuccess;
    my Str $msg = '';

    unless $!closed {
        $code = duckdb-appender-close($!handle);
        $!closed = True;
        $msg = take-cstr(duckdb-appender-error($!handle)) if $code != DuckDBSuccess;
        $msg = '' unless $msg.defined;
    }

    my $err = $code != DuckDBSuccess;
    duckdb-appender-destroy($!handle);

    if $err {
        die DB::DuckDB::Error.new(
            :code($code),
            message => ($msg.chars ?? $msg !! 'appender flush failed'),
        );
    }
}

#| Number of rows appended so far (buffered rows included).
method rows(--> Int) { $!rows }

#| Column count of the target table, as reported by DuckDB.
method width(--> Int) { $!width }

#| True while rows can still be appended (not closed, not freed).
method alive(--> Bool) { $!alive && !$!closed && $!handle.Bool }

submethod DESTROY()
{
    try self.free;
}

method !assert-alive(--> Nil)
{
    die DB::DuckDB::Error.new(message => 'appender has already been freed')
        unless $!alive;
    die DB::DuckDB::Error.new(message => "appender for table '{$!table}' has already been closed")
        if $!closed;
}
