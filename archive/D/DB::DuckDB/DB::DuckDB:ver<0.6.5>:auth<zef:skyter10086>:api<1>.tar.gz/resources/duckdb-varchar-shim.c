﻿/* duckdb-varchar-shim.c -- bulk unpacker for DuckDB VARCHAR vectors.
 *
 * Why
 * ===
 * A VARCHAR vector is an array of duckdb_string_t: a uint32 length followed
 * either by 12 inlined bytes (length <= 12, the common case for ids, short
 * labels and dimension keys) or by a 4-byte prefix plus a pointer to the
 * payload.  Reading those values one at a time from Raku costs a Buf
 * allocation plus a byte-by-byte push per row, which dominates the cost of
 * scanning any text heavy result set.
 *
 * What
 * ====
 * dkd_varchar_unpack() walks the whole vector in C and lays every payload out
 * back to back in a single caller-supplied buffer, filling an offset/length
 * table (and, when a validity mask is supplied, a NULL table).  The caller
 * then slices the buffer once per value instead of reading 16 struct bytes
 * and N payload bytes per value through the FFI.
 *
 * The struct layout is written out by hand rather than taken from duckdb.h:
 * DuckDB 2.0 does not expose duckdb_string_t in its public headers, and the
 * shim must also build where the headers are missing entirely (prebuilt
 * libduckdb archives).  Byte layout, verified against duckdb_string_t:
 *
 *   offset 0  uint32  length
 *   offset 4  char[12] inlined payload   (used when length <= 12)
 *   offset 8  void *  payload pointer    (used when length > 12)
 *   sizeof = 16
 *
 * dkd_string_layout() reports those numbers so the Raku side can assert
 * agreement at load time instead of trusting the comment above.
 */

/* process_vm_readv()/struct iovec need _GNU_SOURCE; it has to be defined
 * before the first system header. */
#if defined(__linux__) && !defined(_GNU_SOURCE)
#define _GNU_SOURCE
#endif

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* Temporary diagnostics: when DB_DUCKDB_SHIM_TRACE names a file, every call
 * appends progress lines to it.  A crash inside the loop otherwise leaves no
 * trace at all, since stderr may still be buffered. */
static FILE *dkd_trace_open(void)
{
    const char *p = getenv("DB_DUCKDB_SHIM_TRACE");
    if (!p || !p[0] || (p[0] == '1' && !p[1])) return NULL;
    return fopen(p, "a");
}

#if defined(_WIN32)
#define DKD_EXPORT __declspec(dllexport)
#include <windows.h>

/* How many bytes starting at `p` are committed and readable, capped at
 * `want`.  Uses VirtualQuery because the C API offers no way to ask DuckDB
 * whether a chunk vector is flat: a non-flat vector's data pointer points at
 * a selection buffer that is far smaller than n * sizeof(string_t), and
 * reading it blindly is what crashed the first version of this shim. */
static uint64_t dkd_readable_bytes(const void *p, uint64_t want)
{
    const char *cur = (const char *)p;
    uint64_t got = 0;
    while (got < want) {
        MEMORY_BASIC_INFORMATION mbi;
        uint64_t avail;
        if (VirtualQuery(cur, &mbi, sizeof mbi) == 0) break;
        if (mbi.State != MEM_COMMIT) break;
        if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) break;
        if (!(mbi.Protect & (PAGE_READONLY | PAGE_READWRITE |
                             PAGE_WRITECOPY | PAGE_EXECUTE_READ |
                             PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)))
            break;
        avail = (uint64_t)((const char *)mbi.BaseAddress + mbi.RegionSize - cur);
        got += avail;
        cur += avail;
        if (avail == 0) break;
    }
    return got > want ? want : got;
}

/* Copy `len` bytes out of `src` without trusting it.  A plain memcpy is
 * enough to kill the process when the vector is not the flat array we think
 * it is, and VirtualQuery alone has been observed to bless a range that then
 * faults on the first 4 KiB boundary; ReadProcessMemory reports the failure
 * instead, so the caller can fall back to the per-value decoder. */
static int dkd_safe_copy(void *dst, const void *src, uint64_t len)
{
    SIZE_T got = 0;
    if (!len) return 1;
    if (!ReadProcessMemory(GetCurrentProcess(), src, dst, (SIZE_T)len, &got))
        return 0;
    return got == (SIZE_T)len;
}
#else
#define DKD_EXPORT __attribute__((visibility("default")))

#if defined(__linux__)
#include <sys/uio.h>
#include <unistd.h>

/* Linux counterpart of VirtualQuery: /proc/self/maps tells us whether the
 * start of the range is mapped readable and where that mapping ends.  Only
 * the first mapping is considered, which is deliberately conservative -- a
 * range that continues into a second mapping is reported short and the
 * caller falls back. */
static uint64_t dkd_readable_bytes(const void *p, uint64_t want)
{
    FILE *f;
    char line[512];
    uintptr_t addr = (uintptr_t)p;
    uint64_t got = 0;

    if (!p || !want) return 0;
    f = fopen("/proc/self/maps", "r");
    if (!f) return want; /* no maps to consult; the copy below still guards */

    while (fgets(line, sizeof line, f)) {
        unsigned long start = 0, end = 0;
        char perms[8];
        if (sscanf(line, "%lx-%lx %7s", &start, &end, perms) != 3) continue;
        if (addr < start || addr >= end) continue;
        if (perms[0] == 'r') got = (uint64_t)(end - addr);
        break;
    }
    fclose(f);
    return got > want ? want : got;
}

/* process_vm_readv() reports EFAULT instead of taking the process down, which
 * is exactly the behaviour ReadProcessMemory gives us on Windows. */
static int dkd_safe_copy(void *dst, const void *src, uint64_t len)
{
    struct iovec local;
    struct iovec remote;
    if (!len) return 1;
    local.iov_base  = dst;
    local.iov_len   = (size_t)len;
    remote.iov_base = (void *)src;
    remote.iov_len  = (size_t)len;
    return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) == (ssize_t)len;
}
#else
static uint64_t dkd_readable_bytes(const void *p, uint64_t want)
{
    (void)p;
    return want; /* assume readable; the length sanity check still applies */
}

static int dkd_safe_copy(void *dst, const void *src, uint64_t len)
{
    memcpy(dst, src, len);
    return 1;
}
#endif
#endif

/* Copy one payload, refreshing a cache of the mapped run we last proved
 * readable.  A chunk of 2048 rows carries ~1365 out-of-line payloads, and
 * probing each of them costs ~1 us in kernel time, while the runs they live
 * in are hundreds of KiB wide -- one probe per run is enough.
 *
 * The probe is a real read of the first bytes of the run, not just
 * VirtualQuery: VirtualQuery has blessed ranges that then faulted on first
 * touch.  A failed probe still falls back to the per-value safe copy, which
 * reports the problem instead of taking the process down. */
static int dkd_window_copy(char *dst, const char *src, uint64_t len,
                           uintptr_t *win_lo, uintptr_t *win_hi)
{
    uintptr_t p = (uintptr_t)src;
    uint64_t extent;

    if (len && p >= *win_lo && p + len <= *win_hi && p + len >= p) {
        memcpy(dst, src, len);
        return 1;
    }

    extent = dkd_readable_bytes(src, (uint64_t)1 << 40);
    if (extent >= 16 && extent >= len) {
        char probe[16];
        if (dkd_safe_copy(probe, src, sizeof probe)) {
            memcpy(dst, src, len);
            *win_lo = p;
            *win_hi = p + extent;
            return 1;
        }
    }
    return dkd_safe_copy(dst, src, len);
}

typedef union {
    struct {
        uint32_t length;
        char     inlined[12];
    } inlined;
    struct {
        uint32_t length;
        char     prefix[4];
        uint64_t ptr;
    } pointer;
} dkd_string_t;

/* Returned instead of a byte count when the vector cannot be unpacked in
 * place.  Callers must fall back to the per-value decoder. */
#define DKD_NOT_FLAT UINT64_MAX

/* Bumped whenever an entry point is added or its contract changes, so a
 * driver that finds an older .dll in the cache can stop trusting it instead
 * of dying on a missing symbol.  Version 2 added dkd_varchar_join(). */
#define DKD_SHIM_ABI 2

DKD_EXPORT uint32_t dkd_shim_abi(void)
{
    return DKD_SHIM_ABI;
}

/* Unpack `n` values starting at `data`.
 *
 * validity  NULL means "every row is valid"; otherwise it is DuckDB's
 *           validity mask (64 rows per uint64 word, LSB first).  Invalid
 *           rows contribute no payload and are flagged in `nulls`.
 * out       Destination buffer, or NULL for the sizing pass.
 * cap       Bytes available in `out`.
 * offsets   Optional, receives the byte offset of each payload in `out`.
 * lens      Optional, receives the byte length of each payload.
 * nulls     Optional, receives 1 for NULL rows and 0 otherwise.
 *
 * Returns the total number of payload bytes the column needs, so a caller
 * that passes out = NULL can size the buffer without a second output pass.
 */
DKD_EXPORT uint64_t dkd_varchar_unpack(const void *data,
                                       const uint64_t *validity,
                                       uint64_t n,
                                       char *out, uint64_t cap,
                                       uint64_t *offsets, uint32_t *lens,
                                       uint8_t *nulls)
{
    const dkd_string_t *s;
    dkd_string_t *stage = NULL;
    uint64_t total = 0;
    uint64_t i;
    FILE *dbg = dkd_trace_open();
    uint64_t need = n * (uint64_t)sizeof(dkd_string_t);
    uint64_t readable = dkd_readable_bytes(data, need);

    if (dbg) {
        fprintf(dbg, "c: enter n=%llu data=%p out=%p cap=%llu validity=%p need=%llu readable=%llu\n",
                (unsigned long long)n, (const void *)data,
                (void *)out, (unsigned long long)cap, (const void *)validity,
                (unsigned long long)need, (unsigned long long)readable);
        fflush(dbg);
    }
    if (readable < need) {
        if (dbg) { fprintf(dbg, "c: not flat\n"); fclose(dbg); }
        return DKD_NOT_FLAT;
    }

    /* Snapshot the string_t array into memory we own.  Every later read is
     * then a read of our own buffer, so a stale or foreign pointer can only
     * make us refuse the chunk, never crash. */
    stage = (dkd_string_t *)malloc(need ? need : 1);
    if (!stage) {
        if (dbg) { fprintf(dbg, "c: stage alloc failed\n"); fclose(dbg); }
        return DKD_NOT_FLAT;
    }
    if (!dkd_safe_copy(stage, data, need)) {
        if (dbg) { fprintf(dbg, "c: stage copy failed\n"); fclose(dbg); }
        free(stage);
        return DKD_NOT_FLAT;
    }
    s = stage;

    /* Readable-window cache for the payload copy below.  DuckDB's string heap
     * grows in blocks, so the long values of a chunk sit in a handful of
     * mapped runs separated by gaps -- a single min..max span is almost never
     * readable (measured: 393 KiB readable out of a 128 MiB span).  Caching
     * the run we last proved readable turns one syscall per value into a
     * couple per chunk. */
    uintptr_t win_lo = 0, win_hi = 0;

    for (i = 0; i < n; i++) {
        int is_null = validity ? !((validity[i >> 6] >> (i & 63)) & 1) : 0;
        uint32_t len;

        if (is_null) {
            if (offsets) offsets[i] = total;
            if (lens)    lens[i]    = 0;
            if (nulls)   nulls[i]   = 1;
            continue;
        }

        len = s[i].inlined.length;
        /* No single DuckDB string is anywhere near 16 MiB; a length above
         * that means `data` is a selection buffer, not a string_t array. */
        if (len > (1u << 24)) {
            if (dbg) { fprintf(dbg, "c: bogus len %u at %llu\n", (unsigned)len, (unsigned long long)i); fclose(dbg); }
            free(stage);
            return DKD_NOT_FLAT;
        }
        if (offsets) offsets[i] = total;
        if (lens)    lens[i]    = len;
        if (nulls)   nulls[i]   = 0;

        if (out && total + (uint64_t)len <= cap) {
            if (len <= 12) {
                if (len) memcpy(out + total, s[i].inlined.inlined, len);
            }
            else {
                const char *src = (const char *)(uintptr_t)s[i].pointer.ptr;
                if (len && src) {
                    if (!dkd_window_copy(out + total, src, len, &win_lo, &win_hi)) {
                        if (dbg) { fprintf(dbg, "c: bad payload ptr at %llu\n", (unsigned long long)i); fclose(dbg); }
                        free(stage);
                        return DKD_NOT_FLAT;
                    }
                }
            }
        }
        total += (uint64_t)len;
    }
    if (dbg) {
        fprintf(dbg, "c: done total=%llu\n", (unsigned long long)total);
        fclose(dbg);
    }
    free(stage);
    return total;
}

/* Returned when a payload happens to contain `sep` or `nullmark`, which would
 * make the joined form ambiguous.  The caller falls back to the offset-table
 * unpacker, which has no such limitation. */
#define DKD_SEP_CONFLICT (UINT64_MAX - 1)

/* Join `n` values into one buffer, separated by `sep`, with NULL rows written
 * as the single byte `nullmark`.
 *
 * Why
 * ===
 * Slicing a shared buffer still costs one Str per value on the Raku side, and
 * a Slice is far more expensive than a Split.  Splitting one decoded string
 * on a one byte separator, on the other hand, is done by the VM in a single
 * pass with no allocation per value (measured: 0.53 us per 1M values, against
 * 1.48 us for the slice loop).  This entry point produces the buffer that
 * split needs.
 *
 * The separator is *between* values, never after the last one, so the result
 * has exactly n tokens after Split -- except that Str.split drops trailing
 * empty strings, which the caller repairs by padding with empty strings.
 * NULL is a non-empty one byte token, so a trailing NULL is never dropped.
 *
 * Returns the number of bytes the joined form needs (0..n-1 separators plus
 * payload bytes, 1 byte per NULL).  Pass out = NULL to size the buffer; a
 * second call with a large enough `out` fills it.  DKD_NOT_FLAT and
 * DKD_SEP_CONFLICT mean "fall back".
 */
DKD_EXPORT uint64_t dkd_varchar_join(const void *data,
                                     const uint64_t *validity,
                                     uint64_t n,
                                     char *out, uint64_t cap,
                                     uint8_t sep, uint8_t nullmark)
{
    const dkd_string_t *s;
    dkd_string_t *stage = NULL;
    uint64_t total = 0;
    uint64_t i;
    uint64_t need = n * (uint64_t)sizeof(dkd_string_t);
    uint64_t readable;

    if (n == 0) return 0;

    readable = dkd_readable_bytes(data, need);
    if (readable < need) return DKD_NOT_FLAT;

    stage = (dkd_string_t *)malloc(need);
    if (!stage) return DKD_NOT_FLAT;
    if (!dkd_safe_copy(stage, data, need)) {
        free(stage);
        return DKD_NOT_FLAT;
    }
    s = stage;

    uintptr_t win_lo = 0, win_hi = 0;

    for (i = 0; i < n; i++) {
        int is_null = validity ? !((validity[i >> 6] >> (i & 63)) & 1) : 0;
        uint32_t len;
        const char *src;
        uint64_t k;

        if (i) {
            if (out && total < cap) out[total] = (char)sep;
            total += 1;
        }

        if (is_null) {
            if (out && total < cap) out[total] = (char)nullmark;
            total += 1;
            continue;
        }

        len = s[i].inlined.length;
        if (len > (1u << 24)) {
            free(stage);
            return DKD_NOT_FLAT;
        }
        if (!len) continue;

        if (len <= 12) {
            src = s[i].inlined.inlined;
        }
        else {
            src = (const char *)(uintptr_t)s[i].pointer.ptr;
            if (!src) {
                free(stage);
                return DKD_NOT_FLAT;
            }
        }

        if (out && total + (uint64_t)len <= cap) {
            char *dst = out + total;
            if (len <= 12) {
                memcpy(dst, src, len);
            }
            else if (!dkd_window_copy(dst, src, len, &win_lo, &win_hi)) {
                free(stage);
                return DKD_NOT_FLAT;
            }
            /* The copy lives in our own buffer, so scanning it cannot fault. */
            for (k = 0; k < len; k++) {
                uint8_t c = (uint8_t)dst[k];
                if (c == sep || c == nullmark) {
                    free(stage);
                    return DKD_SEP_CONFLICT;
                }
            }
        }
        total += (uint64_t)len;
    }

    free(stage);
    return total;
}

/* Layout probe: fills `out` with the byte offsets of length / inlined / ptr
 * and returns sizeof(dkd_string_t). */
DKD_EXPORT uint64_t dkd_string_layout(uint32_t *out)
{
    dkd_string_t probe;
    if (out) {
        out[0] = (uint32_t)offsetof(dkd_string_t, inlined.length);
        out[1] = (uint32_t)offsetof(dkd_string_t, inlined.inlined);
        out[2] = (uint32_t)offsetof(dkd_string_t, pointer.ptr);
    }
    return (uint64_t)sizeof(probe);
}
