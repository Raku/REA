---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_5f6512fed0d811f19fe7525400de85a5
    ReservedCode1: r/G4kgDkAPdokYtNFw8Fv9/XPY+ic1NHUNLNTwJXK8yUqmQRHGxECPCcLIXqotVuIBR1JDL78hSLmmfgZkRU83sI6JaDCc039ZSgxZkbV5mdsBRB50IpzBQgUGCkakgR075uy6I3B0spiU3BcyzSoOpMPtleN0hrD14AHxJHaFMxDtStcCqcxVoNtLQ=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_5f6512fed0d811f19fe7525400de85a5
    ReservedCode2: r/G4kgDkAPdokYtNFw8Fv9/XPY+ic1NHUNLNTwJXK8yUqmQRHGxECPCcLIXqotVuIBR1JDL78hSLmmfgZkRU83sI6JaDCc039ZSgxZkbV5mdsBRB50IpzBQgUGCkakgR075uy6I3B0spiU3BcyzSoOpMPtleN0hrD14AHxJHaFMxDtStcCqcxVoNtLQ=
---

# Changelog

Versioning follows Semantic Versioning. Because the module is still pre-1.0, the minor
number carries both new features and behaviour changes; `api` in META6.json is bumped only
when the `DB` role contract is broken.

## 0.6.5 - 2026-10-28

### Added

* **VARCHAR decoding is one decode plus one split per chunk.** The C shim grew
  `dkd_varchar_join`, which concatenates the payloads of a vector into a single
  buffer with a `0x01` separator between values and a `0x02` marker for NULLs.
  `join-varchar` then decodes that buffer once and splits it, instead of reading
  an offset/length pair and slicing out one substring per value.  NULL rows come
  back as `Any`, so the marker never reaches the caller.  Trailing empty strings
  are padded explicitly because `Str.split` drops them.  When a payload really
  contains `0x01` or `0x02`, the C side reports a conflict and the decoder falls
  back to the per-value path, so hostile data still round-trips exactly.
* `t/10-varchar-join.rakutest` covers the join path, the two fallback switches
  (`DB_DUCKDB_NO_VARCHAR_JOIN`, `DB_DUCKDB_NO_VARCHAR_SHIM`), empty strings,
  embedded NULs, multibyte text and payloads containing the separator bytes.

### Changed

* **Multibyte VARCHAR no longer decodes one `subbuf` per value.** `unpack-varchar`
  keeps its ASCII fast path (decode once, slice by byte offset), but a column
  that is not pure ASCII is now handed to `join-varchar` instead.  On 200k rows
  that is 5.14 us -> 1.27 us per value; the per-value loop survives only as the
  last resort for vectors the join refuses.
* **A whole-column read of a lazy column decodes straight into the result.** It
  used to build a 2048-element `List` per segment and copy it into the output, so
  every value was touched three times.  Uncached segments now decode into the
  caller's array directly and the per-segment cache holds only what `at()` and
  `slice()` asked for.  That removes the ~16% penalty the 0.6.4 note mentioned:
  at 1M rows a lazy VARCHAR read is now at parity with, or slightly faster than,
  eager `column()` (0.82 / 1.05 / 0.91 us per value for short / long / multibyte,
  against 0.85 / 1.28 / 0.98 eager).

### Removed

* The temporary `DB_DUCKDB_SHIM_TRACE` hook in the shim loader, used to bisect a
  crash during the join work.

## 0.6.4 - 2026-10-28

### Changed

* **`column-views` is lazy for non-raw columns.** `VARCHAR`, `BLOB`, temporal
  and nested columns used to be fully decoded while the views were built, so a
  wide result paid the whole string-assembly cost even when the caller read a
  single column.  Such a column now keeps one owned chunk handle per segment
  and decodes a segment the first time a row in it is touched, caching the
  result; `to-list` reuses the same segment decode.  On 1M rows x (2 VARCHAR +
  1 BIGINT), building the views drops from ~5.0 s to **0.10 s**, and reading a
  single value from 5.0 s to 0.09 s.  Reading every column still costs the same
  as before (~16% more than one-shot eager decode for VARCHAR, because each of
  the 489 segments is dispatched separately).  `DB_DUCKDB_NO_COLUMN_VIEW=1`
  still falls back to `column-arrays`.

### Fixed

* **Point access was 25x slower than it needed to be.** `ColumnView::!seg`
  copied the whole segment table (`my @b = @!bases`) on every value read, which
  runs once per `at` / `int64` / `num64` / `is-null` call.  1M `int64()` calls
  took 107 s (107 us per value); after reading the attributes in place it takes
  3.7 s, and 1000 `at()` calls drop from 202 ms to 19 ms.
* **`to-list` on raw columns ignored the element type.** The `CArray` sat in an
  untyped variable, so every index re-dispatched.  `to-list` now hands each
  NULL-free segment to one of ten typed loops, taking 1M BIGINTs from 1.71 s to
  0.97 s (on par with `column-arrays` at 1.01 s).

### Added

* **`t/09-lazy-view.rakutest`** - 22 assertions over the lazy path: shape,
  random access, NULLs, `to-list`, `slice`, single-column results, aggregates
  refusing a lazy column, and the eager fallback.  All nine test files pass.

## 0.6.2 - 2026-10-28

### Added

* **`Appender.append-rows(@rows)`** - bulk write path for the C appender. The
  target table's column types are read once (`duckdb_appender_column_type`,
  newly bound) and each column gets a filler that calls the matching
  `duckdb_append_*` directly, with the return code compared inline instead of
  through a Raku sub call. `integer` / `float` / `text` / `boolean` columns are
  specialised; `DECIMAL`, temporal, `BLOB` and nested columns keep the generic
  per-value type dispatch so exactness is preserved. `insert-rows` and
  `execute-many` were switched over to it, so both get the win without any API
  change.

### Performance

* `insert-rows`, 100k rows x 4 columns, `0.6.1` vs `0.6.2` measured back to
  back on the same machine (median of five runs, one mode per process because
  Raku GC noise swings a single run by 2-3x):
  - `int` / `num` / `bool` / `text` values: **~11.6 us -> ~4.2 us per row
    (~2.8x)**;
  - values holding a `Rat` (e.g. `$_ / 3` without `.Num`): **~15.5 us ->
    ~11.3 us per row (~1.4x)** - turning each `Rat` into a `num` now dominates
    the per-row cost, so the specialised filler has less to win back.

  Writing the rows with an explicit `append-row` loop still costs ~8.7 us/row
  (`num` data) - use `append-rows` (or `insert-rows`) for bulk loads.

### Fixed

* A row shorter than the table used to be appended as a single value
  (`for $vals` iterated the scalar holding the row once), so DuckDB tried to
  cast the row's string form - `Could not convert string '2 x' to INT64` - and
  the batch failed. Short rows now go through the general path and leave the
  missing columns on their `DEFAULT`.

### Tests

* `t/05-appender.rakutest` +5 assertions (30 total) - short rows through
  `append-rows` / `insert-rows`, `DEFAULT` on the missing columns, and an
  integer wider than `int64` (`2**80`) surviving the specialised filler as an
  exact `HUGEINT`.

## 0.6.1 - 2026-10-28

### Added

* **`column-arrays(:parallel)`** - the columns of a materialised result are
  now decoded by several threads at once (`:degree` caps the worker count,
  otherwise the core count / `DB_DUCKDB_DEGREE`). The work is cut into
  `(column, chunk-span)` tasks: a worker owns one column over a contiguous run
  of chunks and appends into that column's preallocated array, so workers share
  no memory and the result is byte-for-byte identical to the serial path.
  A result with fewer columns than workers splits the chunks of each column
  instead and stitches the spans back in chunk order, which is what makes a
  single wide `VARCHAR` column scale too.
  Measured at 1M rows (median of four runs): 5 numeric columns 2.2x,
  4 numeric columns 2.0x, 7 mixed columns 2.1x, 1 `VARCHAR` column 2.4x;
  narrow two-column results barely move (1.1x), because boxing and GC are
  shared between the workers.
* Streaming results and already-partially-read results cannot be split and
  fall back to the serial path; results below 20 000 rows stay serial.

### Docs

* `duckdb-perf-next-steps.md`: P2-1 (per-chunk parallel decode) marked
  implemented, with the numbers and the two dead ends written down.

### Tests

* `t/08-parallel.rakutest` (22 assertions) - `:parallel` against the serial
  path for a 50 000-row x 7-column table at 0/2/4/8 workers, single-column
  results that have to be stitched back together (`VARCHAR`, `BIGINT`,
  `DECIMAL`), the below-threshold fallback, the streaming fallback, the
  partially-consumed fallback, and repeated runs.

## 0.6.0 - 2026-10-28

### Added

* **`DB::DuckDB::ColumnView`** - a column handle that never boxes a value on
  the way in. It keeps the vector's data pointer and validity bitmap as they
  are, so `int64` / `num64` / `is-null` read straight out of DuckDB's buffers,
  and `to-list` walks them with a typed loop instead of going through `Mu`.
  `at` falls back to the boxed path for the types that have no scalar view
  (`VARCHAR`, dates, wide `DECIMAL`, nested types). `sum` / `min` / `max` /
  `count` / `mean` run over the raw buffers and skip NULLs; `slice` returns a
  narrower view. Reached through `$result.column-view($i)` and
  `$result.column-views`.
* **Streaming results.** `$conn.query($sql, :stream)` (and
  `$stmt.execute(:stream)`) switches the result over to
  `duckdb_execute_prepared_streaming` + `duckdb_stream_fetch_chunk`, and
  `$result.chunks` hands out one `DB::DuckDB::Chunk` at a time. A chunk is one
  DuckDB vector (2048 rows, the last one short), exposes `size`,
  `column-count`, `column-view($i)`, `row($i)` and `to-rows`, and keeps only
  the current vector in memory -- 1M rows x 3 columns take 12 ms to the first
  usable chunk instead of 5.8 s to the last one.
* `DB::DuckDB::Chunk` documents and enforces its own lifetime: a chunk dies
  the moment the next one is pulled, and the views handed out by it die with
  it. Reading a stale view raises instead of returning whatever now lives at
  that address, which is what the old code did silently.
* `Result.is-streaming`.

### Changed

* `chunks` expires the previous chunk before pulling the next one, and `free`
  expires and drops the chunk it still holds, so a `Result` can no longer be
  freed under a live view.
* `Statement.execute` and `Connection.query` default `:stream` to `False`.
  Without the default, an omitted `:stream` passed the `Bool` *type object*
  down to `Result`, which then reported an undefined `is-streaming` and made
  the streaming branch depend on how the value happened to be used.

### Tests

* `t/06-column-view.rakutest` (36 assertions) - `column-views` against
  `column-arrays` for all 20 columns of a 5000-row table covering every
  numeric width, `VARCHAR`, unicode, `DATE`, `TIMESTAMP`, `HUGEINT` and
  `DECIMAL(38,6)`, plus NULL counts, a single-chunk table, a zero-row result,
  the aggregates, and the "second read is refused" rule.
* `t/07-streaming.rakutest` (41 assertions) - chunk sizes follow the 2048-row
  vector capacity (2048/2048/904 for 5000 rows), streamed values equal the
  materialised ones, zero-row streams yield no chunks, `row` / `to-rows`
  box correctly, and both expiry paths (`next chunk pulled`, `result freed`)
  raise on use.

## 0.5.1 - 2026-10-27

### Added

* **`DB::DuckDB::Appender`** - a binding for `duckdb_appender_*`. Rows are
  appended straight into the table's storage instead of going through the SQL
  parser, and the value types are mapped the same way the parameter binder maps
  them (`Bool`, `Int`, `Num`, `Rat`, `Str`, `Blob`, undefined -> `NULL`).
* **`$db.insert-rows(Str $table, @rows)`** - the batch form. One appender, one
  transaction, `UInt` back. Measured on this machine, 100k rows x 4 columns
  (`bigint`, `double`, `varchar`, `boolean`) into an in-memory database:
  **1.0-1.5 s versus 3.4-3.7 s** for 1000-row multi-value `INSERT` statements,
  i.e. **2.5-3.3x** across runs. The remaining gap to the C API's own 0.33 s is
  Raku-level dispatch and string marshalling per value.
* **`$db.execute-many(Str $sql, @rows)`** - runs a prepared `INSERT` once per
  row and routes plain `INSERT INTO t [(cols)] VALUES (?...)` statements through
  the appender instead. `ON CONFLICT`, `RETURNING`, expressions and
  sub-selectors keep the statement path.
* **`$db.appender(Str $table)`** - the raw handle, for code that wants to
  control row boundaries itself. An unfinished appender is flushed and closed by
  its destructor, but an explicit `$ap.free` is what reports a failed cast.
* **Session options** - `DB::DuckDB.new(:threads(8), :memory-limit('2GB'),
  :preserve-insertion-order(False))` pushes them to every connection, and
  `$db.set-session-option($name, $value)` changes them on a live session.
  `preserve_insertion_order` is only sent when it is turned off, so the engine
  default stays untouched otherwise.

### Fixed

* **`Appender` opens the transaction only when it has to.** The bulk paths check
  the connection's real transaction state, so a batch issued inside a caller's
  `begin` joins that transaction instead of nesting a second one and committing
  the caller's work.
* **A failed batch leaves no rows behind.** The appender is closed inside the
  `CATCH` block, before the rollback, so buffered rows are not flushed into a
  transaction that is about to be discarded. Verified by a regression test that
  feeds a bad cast as the last row of a batch and expects an empty table.
* **`execute-many` no longer leaks an open transaction.** A `return` inside the
  `!atomically` callback skipped the `COMMIT`; the callback now yields a value
  instead.
* **`t/04-varchar-shim.rakutest`** had no `done-testing`, which turned the whole
  suite's TAP plan into a failure even though every assertion passed.
* **A reordered `INSERT` column list silently wrote DEFAULTs.** The appender
  fast path maps the statement's column order back onto table order using the
  index list from the insert plan, which lives in a Hash slot and therefore
  comes back itemized (`$(1, 2, 0)`). Assigning that into an array without
  `.List` produced a one-element array holding the whole list, so each row was
  appended as one sliced value and every column fell back to its DEFAULT;
  `execute-many('insert into t (d, i, s) values (?, ?, ?)', ...)` returned the
  right row count while writing nothing. Both table-order and reordered
  statements are now covered by `t/05-appender.rakutest`.

## 0.5.0 - 2026-10-27

### Added

* **C shim for VARCHAR columns** (`resources/duckdb-varchar-shim.c`, loaded
  through `DB::DuckDB::VarcharShim`). The vector's `duckdb_string_t` array is
  snapshotted once, then a single pass copies every payload into one contiguous
  `Buf` while filling an offsets table, a lengths table and a NULL bitmap. Raku
  side then decodes the flat buffer once and slices each value out with
  `substr`. This replaces the per-value `duckdb_string_t` dereference plus
  `Buf.push` loop that made wide string columns the slowest part of result
  reading.
  Measured against the per-value decoder on this machine:

  | rows | `column()` | `arrays()` | `hashes()` |
  |------|-----------|-----------|-----------|
  | 100k | 2.7x | 1.5x | 1.6x |
  | 500k | 3.1x | 1.8x | 1.7x |
  | 1M   | 3.4x | 1.7x | 1.8x |

* **Soft dependency on a C compiler.** The shim compiles on first use into
  `~/.local/share/DB-DuckDB` (`DB_DUCKDB_SHIM_CACHE` overrides the directory,
  `DB_DUCKDB_CC` / `CC` pick the compiler, `DB_DUCKDB_VARCHAR_SHIM` points at a
  prebuilt library). With no compiler the module logs one note and keeps using
  the pure Raku decoder; nothing fails.

### Changed

* **VARCHAR no longer falls back to the per-value decoder** whenever the shim
  is available: `column()`, `column-arrays()`, `arrays()`, `row()` and
  `hashes()` all share the batch result. The old path is kept and still used
  for non-flat vectors (dictionary or selection vectors), oversized payloads
  and unreadable pointers.

### Safety

* Everything the shim reads is validated first: the `duckdb_string_t` array is
  snapshotted into memory the shim owns, out-of-line payloads are copied with a
  read-probing helper, and any payload longer than 16 MiB (the signature of a
  selection buffer being mistaken for a string vector) makes the shim return
  `DKD_NOT_FLAT`, which makes the driver fall back instead of crashing.

## 0.4.0 - 2026-10-27

### Added

* **`column(Int $idx)`** returns every remaining value of a single column as
  one Array. It skips the per-row Array allocation, so pulling one column out
  of a wide result is roughly an order of magnitude cheaper than `arrays()`
  plus a map.
* **`column-arrays()`** drains the whole result column by column into a List of
  Arrays (one per column; named that way because `$.columns` is the column
  count accessor). Measured 1.7-2x faster than `arrays()` at 3-5 columns, and
  it is the cheapest way to consume a wide result in full.

### Changed

* **`hashes()` decodes a whole data chunk at a time**: each column is appended
  to a typed Raku array with one native loop pass, then row hashes are built
  with `nqp::hash`/`nqp::bindkey` instead of going through `Hash` assignment.
  Measured 2.2-2.6x faster at 3-5 columns on 300k rows.
* **Column decoding got typed fast paths** for the integer, unsigned integer,
  float, double and boolean vector types. Columns carrying NULLs, or types
  without a fast path (VARCHAR in particular), still fall back to the
  per-value decoder, so behaviour is unchanged.
* `row()` and `arrays()` are unchanged in behaviour; their timings sit inside
  run-to-run noise on this machine.

## 0.3.1 - 2026-10-26

### Changed

* **`Alien::Libduckdb` dependency pinned to an exact version**:
  `Alien::Libduckdb:ver<1.1.0>`. The C API is not ABI-stable across DuckDB
  majors - `duckdb_result` layout, `DUCKDB_TYPE` numbering and the by-value
  accessors all moved - so "whatever Alien is newest" was a silent
  memory-corruption risk. 1.1.0 is the release that ships libduckdb 2.0.0,
  which this binding targets.
* Alien::Libduckdb now installs libduckdb from the upstream prebuilt archive
  by default and falls back to a cmake source build; nothing changes on this
  side, the library simply appears in seconds instead of minutes.

### Added

* **ABI guard at first use.** `verify-library()` (exported from
  `DB::DuckDB::Native`) compares `duckdb_library_version()` with
  `BINDING-MAJOR` (2) and the driver calls it before opening its first
  database handle. A 1.x/3.x library reached through `%DB_DUCKDB_LIB`, a
  stale `duckdb.dll` next to `raku`, or a system libduckdb now dies with an
  explanatory message instead of corrupting result reads.

## 0.3.0 — 2026-10-26

### Fixed

* **Crash on POSIX when a result needs more than one chunk.** `duckdb_result_chunk_count` and
  `duckdb_fetch_chunk` take `duckdb_result` *by value* (48 bytes on LP64). NativeCall's
  by-value marshalling for a struct that large happens to work under the MS x64 convention,
  but under SysV AMD64 the callee received a corrupt copy and DuckDB aborted in
  `unique_ptr`-related asserts. Any query whose result spanned multiple data chunks died;
  small results happened to fit in one chunk and looked fine.
* Result reading on POSIX no longer relies on NativeCall taking or returning `duckdb_result`
  by value anywhere.

### Added

* `DB::DuckDB::Bridge` — hands the same 48 bytes to the two remaining by-value accessors as a
  pointer instead. Enabled on POSIX only; Windows keeps binding the C API directly.
* `resources/duckdb-result-shim.c` — ~20-line pointer-in wrapper around those two accessors,
  compiled on first use into the user's data directory and cached there.

### Changed

* `DB::DuckDB::Native` binds the chunk accessors from the bridge library where one is used,
  and from `libduckdb` on Windows.
* `META6.json` gained `resources` and the `DB::DuckDB::Bridge` entry in `provides`
  (`resources` paths are declared relative to the distribution root, without the
  `resources/` prefix).
* README no longer claims the distribution is free of C code.

### Notes

* `api` stays `1`: the public `DB` interface is unchanged.
* Verified on Linux (DuckDB 1.5.x, SysV AMD64): 18 smoke assertions and the full 42-assertion
  test suite pass, including multi-chunk results; and on Windows (MS x64) as a regression
  check. `zef install` also builds the shim from the installed distribution.

## 0.2.0

* Initial NativeCall driver over the DuckDB C API: `DB` role, connections, prepared statements,
  all 2.0 result types rendered exactly like DuckDB's own `CAST(x AS VARCHAR)`.
*（内容由AI生成，仅供参考）*
