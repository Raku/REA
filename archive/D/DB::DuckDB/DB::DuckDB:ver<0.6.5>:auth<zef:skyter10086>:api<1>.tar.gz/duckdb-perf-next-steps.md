---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_41362b1cd1ee11f1a301525400cd780f
    ReservedCode1: eMrVMfbX7E9089goMdUPx+3M4jE+58f3fsNz1MdD13Le7y4Sn5cFu5xlvTiCwZE1VqofbTiEWOUnbmoaN0lQv5vQhe3Sxkfi7bUDuLt6Jr9TempYj+B2DLX/Gs7caEO6OkDb9GWkzpWtp2SXAGtm8jzzHXW7ZwwF//QH0Rb6ZQ3SRs9a6ngTt2ISKwI=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_41362b1cd1ee11f1a301525400cd780f
    ReservedCode2: eMrVMfbX7E9089goMdUPx+3M4jE+58f3fsNz1MdD13Le7y4Sn5cFu5xlvTiCwZE1VqofbTiEWOUnbmoaN0lQv5vQhe3Sxkfi7bUDuLt6Jr9TempYj+B2DLX/Gs7caEO6OkDb9GWkzpWtp2SXAGtm8jzzHXW7ZwwF//QH0Rb6ZQ3SRs9a6ngTt2ISKwI=
---

# DB::DuckDB 性能再优化评估：瓶颈定位与 API 形态选择

环境：Windows 11 / Rakudo Star 2026.09 / DuckDB **v2.0.0-dev1**（Alien::Libduckdb 自编译）
方法：绕开 DB::DuckDB 直接用 NativeCall 绑定的 C API 建基线，与现有 Raku 层 API 同数据集对照（内存库）。
所有数字为本机实测，非估算。

---

## 一、结论摘要

1. **Raku 侧落地（解码 + 装箱）占整个读取耗时的 99% 以上**，DuckDB 引擎本身不是瓶颈。
   1M 行 × 4 列全扫：C 层 29–41 ms，现有 `column-arrays` **15 104 ms**（≈390×）。
2. 现有解码快路径有一个**结构性缺陷**：只要该列 chunk 带 validity bitmap（含 NULL），整列退回逐值 decoder。
   BIGINT 1M 行：无 NULL 745 ms → 10% NULL **4 286 ms**（5.7×）。这是单点收益最大的修复项。
3. **写入是当前与 SQLite 差距的主要来源，且有一条 19× 的现成解法**：
   10 万行 × 4 列，Appender 330 ms vs 多值 INSERT（事务内）6 453 ms。
4. **脱离 `DB` role 自写 API，对性能的直接收益很小**（点查场景约 15–20%，其余 <5%）；
   role 只是薄壳，真正决定性能的是 API 形态（列式/流式/零拷贝），而这些在保留 role 的前提下也能加。
   → 建议"双轨"而非"弃用 role"。
5. **第二~四节是早期探针数据，部分已被复核推翻**：见**第七节**（2026-10-28 实测复核）。
   列视图"20×"不成立、数值列"0.2 µs/值"是惰性容器造成的假快、prepared 复用实际快 37% 而非 5%。
   请以第七节数字为准。

---

## 二、实测数据

### 2.1 单列 100 万行落地成本（现有 `column($i)`）

| 列类型 | 无 NULL | 10% NULL | 每值成本（无 NULL） |
|---|---:|---:|---:|
| BIGINT | 745 ms | 4 286 ms | 0.75 µs |
| INTEGER | 887 ms | — | 0.89 µs |
| SMALLINT | 1 754 ms | — | 1.75 µs |
| DOUBLE | 2 252 ms | 6 070 ms | 2.25 µs |
| VARCHAR | 5 169 ms | 6 328 ms | 5.17 µs |
| DECIMAL(21,1) | 6 783 ms | — | 6.78 µs |

对照：同一份数据在 C 层（`duckdb_fetch_chunk` + `duckdb_vector_get_data` 遍历）29–41 ms。

### 2.2 语句级固定开销（500 次主键点查）

| 路径 | 总耗时 | 单次 |
|---|---:|---:|
| `SELECT 1` × 500（仅 execute + destroy） | 44 ms | 0.090 ms |
| prepared 复用 + bind + execute + destroy（纯 C） | 193 ms | 0.387 ms |
| 字面量 SQL + destroy（纯 C） | 206 ms | 0.413 ms |
| 现有 Raku 层 prepared 复用（含 Result + 解码） | 243 ms | 0.486 ms |

两个要点：
- **prepared 复用相对字面量只快 5%**，固定成本在 `execute`（DuckDB 每次建结果/事务），不在 `prepare`。
- Raku 层相对纯 C 多出 **0.07–0.10 ms/语句**，这就是 `DB` role + Result 对象 + 解码的全部开销。

### 2.3 写入：Appender vs 多值 INSERT（10 万行 × 4 列）

| 路径 | 耗时 |
|---|---:|
| Appender（`duckdb_append_*` + `end_row`，Raku 循环 40 万次调用） | **330 ms** |
| 多值 INSERT，1 000 行/句，包在事务里 | 6 453 ms |

**19.5×**。注意 Appender 这 330 ms 里还有大量 Raku→C 调用开销，若改用 `duckdb_append_data_chunk` 整块提交还能再降。

### 2.4 物化 vs 流式（1M × 4 列全扫）

| 路径 | 首块可用 | 总耗时 |
|---|---:|---:|
| `duckdb_execute_prepared`（全物化） | 28 ms | 37–41 ms |
| `duckdb_execute_prepared_streaming` + `stream_fetch_chunk` | **7.4 ms** | 29.5 ms |

流式总时间只快 1.1–1.3×，但**首块延迟低 3.8×**，且峰值内存不随结果集线性增长——对"边读边处理/大结果集"是结构性优势。

### 2.5 会话参数影响（1M 行扫描）

| 配置 | 耗时 |
|---|---:|
| 默认 | 37.0 ms |
| `SET preserve_insertion_order=false` + `SET threads=8` | **15.8 ms**（2.34×） |

### 2.6 其它

- 100 万行 4 列 `column-arrays`：15 104 ms；`hashes` 10 万行 × 4 列：1 939 ms。
- 聚合不下传 Raku（`SELECT count(*), sum(v), max(d)`）：5.3 ms —— 引擎侧几乎免费，能推到 SQL 侧的工作都应推。

---

## 三、瓶颈归因

| 层 | 现象 | 归因 |
|---|---|---|
| DuckDB 引擎 | 1M×4 列 29–41 ms | 已接近极限，无优化空间 |
| 语句固定成本 | 0.09 ms/语句（`SELECT 1`） | DuckDB 2.0 每次 execute 建结果对象，绑定层无法绕过 |
| C API 边界 | `fetch_chunk` 全走完只加 8–12 ms | 不是瓶颈 |
| **Raku 落地** | **占 99%** | 每值一个 Int/Num/Str 装箱 + Array push |
| **NULL 退化** | 5.7× 变慢 | `decode-into` 里 `return False if $validity.defined` 整列退回逐值 decoder |
| DECIMAL | 6.78 µs/值 | 走文本渲染/bignum 路径，未用 scale 做定点换算 |
| 写入 | 6.45 s / 10 万行 | 走 SQL 文本多值 INSERT，被解析器逐值解析 |

---

## 四、优化清单（按 ROI 排序）

### P0 立即做（改动局部，收益 5–20×）

**1. validity 位图内联处理，禁止整列退化**
现状：`Result::!decode-into` 开头 `return False if $validity.defined`。
改法：不整列退化，在批量循环里按 64 位字做位测试：

```raku
my CArray[uint64] $m = nativecast(CArray[uint64], $validity);
loop (; $r < $size; $r++) {
    @dst.push: ($m[$r +> 6] +& (1 +< ($r +& 63)))
        ?? $a[$r].Int !! Any;   # Any = NULL 占位
}
```
预期：BIGINT 带 NULL 4 286 → ~800 ms。若要更快，沿用 `VarcharShim` 的思路写一个 C shim：
一次遍历把有效值 compact 成连续数组 + 输出 null 索引表，Raku 侧只做无分支 push。

**2. DECIMAL 定点快路径**
`duckdb-decimal-width/scale/internal-type` 已有绑定。scale ≤ 9 且 internal 为 int64 时直接用
`$a[$r] / 10**$scale`（`10**$scale` 提到循环外），不必走文本渲染。
预期：6.78 → 1 µs 级（6×）。

**3. 写入走 Appender**
`Connection.execute`/批量 `insert` 检测"同一表连续 INSERT"时，切 `duckdb_appender_create` +
`append_*` + `end_row`，事务包一层。若能整批构造 `duckdb_data_chunk` 后 `duckdb_append_data_chunk`，
比逐值 append 更快。
预期：6.45 s → 0.3 s 量级（19×），直接抹平与 SQLite 的写入差距。

**4. 会话默认参数可配**
`preserve_insertion_order=false`、`threads`、`memory_limit` 通过构造参数/属性下发（默认保守，读密集场景建议开）。
预期：扫描 2.3×。

### P1 结构性改造（收益最大，需要新 API 面）

**5. 零装箱列视图 `column-view($i)`** ✅ 已实现（0.6.0，`DB::DuckDB::ColumnView`；惰性解码 0.6.4）
> 实测复核见**第七节**：本项"745 ms → 30 ms（20×+）"的预期**不成立**。列视图省的是"没读的列"，
> 读到的列仍要付解码钱（VARCHAR 3.2 µs/值、BIGINT 0.8–1.0 µs/值）。
返回对象内部持有 `Buf`（把 vector data `memcpy` 到 Raku 管理的缓冲区，1M×8B ≈ 8 MB、约 2 ms）或对结果保活的裸指针视图，
暴露 `.int64($i)` / `.num64($i)` / `.sum` / `.slice`。用户遍历时不做任何对象分配。
预期：1M BIGINT 745 ms → 30 ms 量级（20×+）。
注意：`duckdb_data_chunk_copy` 在 2.0 **未导出**，chunk 生命周期只能靠 result 保活或自行 memcpy。

**6. 流式 chunk 迭代** ✅ 已实现（0.6.0，`Result.chunks` + `DB::DuckDB::Chunk`，含块过期语义）
`for $res.chunks -> $chunk { ... }`，基于 `duckdb_execute_prepared_streaming` + `duckdb_stream_fetch_chunk`（2.0 均已导出，实测可用）。
收益：首块 7.4 ms、峰值内存恒定。

**7. Arrow 直通** 🟡 可行性已验完，结论与立项预期不同（0.6.6 起有 `DB::DuckDB::Arrow` 只读视图）

实现：`duckdb_result_get_arrow_options` + `duckdb_data_chunk_to_arrow` 在 2.0 的 `duckdb.dll` 中已导出且可用
（返回的 `error_data` 为 NULL，即成功）。**不需要** `LOAD arrow` 扩展，也**不需要** NanoArrow：Arrow C data
interface 只是 `ArrowArray`/`ArrowSchema` 两个固定 10 字段 C 结构，Raku 侧直接 `repr('CStruct')` 声明即可读，
实测转换成本 1M 行 × 3 列仅 35 ms（≈0.035 µs/行）。

实测（1M 行，`id BIGINT / v DOUBLE / s VARCHAR`，489 个 2048 行 chunk，含每 chunk 转换开销）：

| 路径 | 耗时 | 备注 |
| --- | --- | --- |
| Arrow int64 遍历（含转换） | 655 ms | 与 DuckDB vector 直读 587 ms 基本持平，差值≈转换成本 |
| Arrow VARCHAR（offsets + memcpy + `substr`） | 6.3 s | 比现有 join+split 的 1.7 s 慢 3.8× |
| `column-view.to-list`（现有） | 1.6 s | 装箱是主要成本 |
| `column(2)`（现有 VARCHAR） | 1.7 s | |

结论：**Arrow 不是性能优化项**。逐值 CArray 索引在 Raku 侧本来就要 ~0.6 µs，数值列换成 Arrow 后与此持平；
VARCHAR 反而更差（Arrow 没有分隔符，物化只能逐值 `substr`，而现有 join+split 是一次大字符串切分）。
真正的价值是**能力扩展**：LIST/STRUCT/MAP 拿到的是可递归遍历的数组，而现有 `column()` 只能返回 DuckDB 的
文本表示（`"[0, 0]"`、`"{'a': 0}"` 字符串）。

已落地的最小可用面（`lib/DB/DuckDB/Arrow.rakumod`，`t/11-arrow.rakutest` 13 项全过）：
`arrow-chunk($res, $i)` 返回 `Chunk`，`.column($j)` 取列，支持 `.ints/.nums/.int32s/.nums/.strs/.bools`、
`.is-null($i)`、`.children`（嵌套递归）、`.free`（幂等）；`with-arrow-chunks($res, &code)` 自动释放。
默认读取路径不变，Arrow 仅在需要嵌套类型或对外导出 buffer 时显式使用。

### P2 可选

**8. 分块并行解码 `column-arrays(:parallel)`** ✅ 已实现（0.6.1）
任务切分单位是 `(列, chunk 跨度)`：worker 独占一列的连续若干 chunk，直接 append 进该列预分配的数组，
worker 之间不共享任何容器。列数少于 worker 数时改为把单列的 chunk 列表再切成多段，回收后按 chunk 顺序拼接，
因此单列宽结果也能并行，且行序不变、结果与串行逐值一致（`t/08-parallel.rakutest`）。
实测（1M 行、整列落地墙钟、四轮取中位）：5 数值列 8.5 s → 3.4 s（2.2×）、4 数值列 5.2 s → 2.6 s（2.0×）、
7 混合列 22.5 s → 10.5 s（2.1×）、VARCHAR 单列 4.7 s → 1.9 s（2.4×）；2 列窄结果几乎无收益（1.1×），
因为装箱与 GC 是所有 worker 共享的瓶颈。同一形状重复跑波动可达 ±50%，机器负载噪声大于优化差异。
不到 20 000 行一律走串行（启动成本大于收益）；流式结果与已部分消费的结果无法切分，自动回退串行。

两个已排除的死路（勿重走）：
- 在 worker 内用**共享 Hash** 收集各列结果（`%col{$c}.append`）：Raku 跨线程的 Hash 传递会丢键，
  表现为部分列整列为空；必须写进主线程预建的 `@cols[$col]` 槽位。
- 用嵌套 `List` 当任务表（`@tasks[$i] = ($col, $from, $to)`）：取回来是 item 化的，各 span 变空。
  扁平 `int` 数组（`@t-col/@t-from/@t-to/@t-w`）才可靠；拼接时用 `|@parts[$ti]`（slip 强制展平），
  直接 `append: @parts[$ti]` 会把整个 Array 当成一个元素，合并结果只剩 worker 数个元素。

- `SELECT 1` 级别的 0.09 ms 固定成本属 DuckDB 内部，绑定层无解；点查密集场景用 IN 列表批量化更有效。

### P3 写入

**9. 列类型驱动 filler（原计划：`append_data_chunk` 整块提交）** ✅ 已实现（0.6.2），但**走的不是 chunk 路线**
原计划是把每列攒成连续 buffer 后一次 `duckdb_append_data_chunk`。实测发现更省事的一步就够：
写入的真正开销不在 FFI 次数，而在 Raku 侧的逐值 `given/when` 分派（每个值一次多分派 + 一次 `check-rc` 子调用）。
改成「建 appender 时读一次列类型（`duckdb_appender_column_type`），每列生成一个只调对应 `duckdb_append_*` 的闭包，
返回码内联比较」之后，10 万行 × 4 列 `insert-rows` 对比 0.6.1（同机同日、各取五轮中位）：
纯 `int/num/bool/str` 值 **11.6 → 4.2 µs/行（2.8×）**；值是 `Rat`（如 `$_ / 3` 不转 `.Num`）时
**15.5 → 11.3 µs/行（1.4×）**，因为每行 `Rat→num` 强转成了新瓶颈，filler 省下的部分被它吃掉。

结论：**先做类型特化，再谈 chunk 拼装**。剩余差距（`num` 数据 ~4.2 µs vs 裸 FFI 的 1.3 µs）在 Raku 每行的
循环/分派/强转开销里，继续往下压需要 C shim（把整批行一次性传给 C，由 C 侧填 chunk），目前收益不抵复杂度。
注意 `tools/perf/bench-write.raku` 的 `d` 列写的是 `$_ / 3`（`Rat`），跑出来自然偏慢，别拿它当极限值。

---

## 五、"不用 DB role、自己做 API"的评估

### 5.1 role 的真实成本

| 场景 | Raku 层附加开销 | 占比 |
|---|---:|---:|
| 点查（单行结果） | 0.07–0.10 ms/语句 | 15–20% |
| 大结果集读取 | 15 104 ms 中 role 协议部分 < 1% | ≈0 |
| 写入 | 与 role 无关 | 0 |

`DB` role 是薄壳：`DB::Result` 提供 `.row/.array/.hash/.hashes/.arrays`，`DB::Connection` 提供 `.query/.execute/.prepare`。
它带来的成本主要是"必须构造一个 Result 对象 + 支持逐行协议"，而不是每行每列的额外代理。

### 5.2 结论

- **为性能放弃 role，收益上限约 15%（点查），平均 <5%，不值。**
  真正的 20–400× 收益来自"要不要把数据落地成 Raku 对象"，与 role 无关。
- 现有 `DB::SQLite` 兼容层、用户已有代码、以及 `DB` 生态（`DB::Result` 的 hashes/arrays 契约）都应保留。
- **建议双轨**：
  - `DB::DuckDB`（`does DB`）保持现状 + P0 修复，DB 接口使用者无感知地变快；
  - 新增原生快路径命名空间（如 `DB::DuckDB::Raw` / `DB::DuckDB::Chunks`），提供
    `column-view`、`chunks`、`appender`、`arrow`，供追求极限吞吐的代码使用；
  - 在 Result 上直接挂 `.chunks` / `.column-view` 等价方法也可以，等价于把快路径做成 role 的超集。

### 5.3 若坚持完全重写（不 `does DB`）

可行，工作量 ≈ 重写 `Result`（497 行）+ `Connection`（151 行）+ `Statement`（118 行），主要风险不是性能而是：

- chunk/result 生命周期与释放顺序（`duckdb_data_chunk_copy` 不可用，2.0 ABI 无 copy 语义）；
- 与 DBIish/DB 生态脱钩后的迁移成本；
- 现有 `DB::SQLite` 对比基准与用户脚本需要改写。

除非目标是做成"Raku 的 Arrow/chunk 级数据库客户端"而非"DuckDB 的 DB 驱动"，否则不建议。

---

## 六、建议执行顺序

1. P0-1（NULL 位图）→ 2. P0-3（Appender 写入）→ 3. P0-2（DECIMAL）→ 4. P0-4（会话参数）
5. P1-5（`column-view` 零装箱）→ 6. P1-6（流式 chunks）→ 7. P1-7（Arrow，按需）→ 8. P2-8（并行解码，可选）

P0 全部为局部改动，预计能把"读取 1M 行 4 列"从 15 s 压到 2 s 内、写入 10 万行从 6.4 s 压到 0.3 s；
P1-5 落地后才能进入 100 ms 量级（受 Raku 对象模型限制，纯 Raku 层无法再往下）。
P2-8 已在 0.6.1 落地，1M 行整列落地墙钟再降 2–3.6×，剩余瓶颈是 Raku 装箱与 GC，不再是单线程解码。

---

## 七、实测复核与惰性 column-view（2026-10-28）

第二节的表格是项目早期一次性探针跑出来的，参数量级、机器负载、是否强制物化都与现在不同。
本轮把关键项重跑了一遍，结论有对有错，逐条记录如下。

### 7.1 复核方法

- 1M 行内存库，Rakudo Star 2026.09 / libduckdb v2.0.0-dev1，同机同日，多轮取最优。
- **所有读取结果强制物化**（`.List` 遍历或 `.to-list`），不取 `.elems`——惰性容器上 `.elems` 不触发解码，会给出虚快数字。
- 脚本放临时目录，不入仓库：`bench-lazy-final.raku`（VARCHAR 场景）、`bench-num2.raku`（数值 + 点查）。

### 7.2 原声明 vs 复测

| 项目 | 原文声明 | 本轮实测 | 判定 |
|---|---|---|---|
| 1M×4 列 `column-arrays` | 15 104 ms | 2 VARCHAR + BIGINT 7.2 s；单 VARCHAR 2.8 s | 量级一致，原值对应更宽结果 |
| P1-5 列视图 | 745 ms → 30 ms（20×+） | 建视图 10 ms（不读）；读单列 0.97–3.2 s | **20× 不成立**，见 7.3 |
| 数值列 bulk 拷 | 0.69 → 0.2 µs/值 | 0.8–1.0 µs/值 | 0.2 µs 是 `CArray.list` 惰性造成的假快 |
| 点查 prepared 复用 | 0.486 ms/句 | 0.43–0.46 ms/句 | 吻合 |
| 字面量 SQL vs prepared | prepared 仅快 5% | 0.69 vs 0.43 ms（prepared 快 37%） | **原结论有误**，prepared 复用收益被低估 |
| `SELECT 1` 固定成本 | 0.090 ms/句 | 0.20–0.25 ms/句 | Raku 层固定开销被低估约 2× |

### 7.3 本次改造：column-view 改成真惰性

改法（0.6.4）：非 raw 列（VARCHAR/BLOB/时间/嵌套等）不再在 `column-views` 时全量解码，改为每个 chunk 持有一个
owned chunk 句柄，首次访问该段才 `decode-column-into` 并缓存；`to-list` 复用同一条分段解码，`.at` / `is-null` 只解所读行所在段。

1M 行（2 VARCHAR + 1 BIGINT）：

| 场景 | 改前（建视图即全解） | 改后（惰性） | 倍数 |
|---|---:|---:|---:|
| `column-views` 建视图 | 5.0 s | **0.10 s** | 50× |
| 只取 `at(0)` / `at(last)` | 5.0 s | 0.09 s | 55× |
| 只读 1 个 VARCHAR 列 `to-list` | 5.0 + 3.2 s | 0.10 + 3.2 s | 1.5× |
| 三列全读 `to-list` | ≈8.2 s | 4.9 s | 1.7× |

对照：eager `column-arrays` 三列强制物化 7.2 s。

要点：**收益来自"没读的列不付钱"，不来自"读得更快"**。读单个 VARCHAR 列 `to-list` 3.2 s，比 eager 单列 2.8 s 慢约 16%
（逐段解码比一次性解码多了 489 次分派与列表拼接）；BIGINT 列 `to-list` 0.97 s 与 eager 1.01 s 持平。

### 7.4 顺带修掉的两个真实缺陷

1. **点查路径被"段表拷贝"拖死**（`ColumnView::!seg`）
   每读一个值都 `my @b = @!bases` 复制整张段表（1M 行 = 489 段）。1M 次 `int64()` 实测 **107 s（107 µs/值）**，`at()` 216 s。
   改为直接访问属性后：`int64()` 3.7 s（3.7 µs/值）、`at()` 8.7 s（8.7 µs/值）；`at()` 一千次 202 ms → **19 ms（约 10×）**。
   → 原文"点查快路径 0.38→0.15 ms 不成立"的判断，当时测到的其实是这次数组拷贝，不是 DuckDB 内部固定成本。
2. **raw 列 `to-list` 未走类型特化循环**：`CArray` 存在无类型变量里，每次索引都重新分派。按类型分派到 10 个
   类型化小循环后，BIGINT 1M `to-list` 1.71 s → **0.97 s**，与 `column-arrays` 的 1.01 s 持平。

残余：`at()` 8.7 µs/值仍是"每值一次方法调用"的代价，逐值 `.at` 不适合 1M 行级遍历（用 `.chunks` 或 `to-list`）；
真实单行点查不受影响（语句固定成本 0.43 ms 才是主项）。

### 7.5 回归

9 个 `.rakutest` 全绿（01–09），新增 `t/09-lazy-view.rakutest` 22 项：shape / 随机访问 / NULL / `to-list` / `slice` /
单列表 / 聚合拒绝 / eager 回退。参考：`is ... eqv` 对 List/Array 类型敏感，比较解码结果要统一转 `Array` 或用逐值 `eq`。

### 7.6 对清单的影响

- **P1-5 目标改写**：机制已落地，"20×"应改成"未读列零成本"。读到的列仍是 VARCHAR 3.2 µs/值、BIGINT 0.8–1.0 µs/值；
  再往下只能减少 Raku 侧逐值 `substr`（P4 已确认瓶颈在 Raku `substr` 而非 C shim）。
- **审查规则**：列视图类里任何"为了少写一行"的数组拷贝都会进入每值成本，新增访问器要按这条过一遍。
- 待办不变：Arrow 直通、并行粒度细化、流式双缓冲。
- 新增小项：VARCHAR 分段解码的 ~16% 折损，可用"跨段合并解码"（一次解多段）削平。

---

## 附：本机复核命令

```
# 写入路径基准（单进程单模式，避免 GC 噪声交叉污染）
raku -Ilib tools/perf/bench-write.raku <sql|prepared|insert-rows|exec-many|appender> 100000 1000

# P0-3 / P0-4 回归（写入路径 + 会话参数）
raku -Ilib tools/perf/regress-p03-p04.raku
```

> 早期一次性探针（`probe3/6/7` 等）已随调试残留清理，基线数据见上文表格。
*（内容由AI生成，仅供参考）*
