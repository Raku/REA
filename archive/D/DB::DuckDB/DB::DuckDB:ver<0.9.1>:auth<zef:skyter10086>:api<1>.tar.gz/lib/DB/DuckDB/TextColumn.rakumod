#| A byte oriented view of a VARCHAR / BLOB column.
#|
#| Why
#| ===
#| `column()` and `to-list` build one Raku `Str` per value.  For one million
#| 40-byte strings that is a million allocations plus a million GC roots --
#| measured at ~800 ms, and it is the single largest reason reading text out
#| of DuckDB is an order of magnitude slower here than in the Python binding,
#| where the same data never leaves the Arrow buffer.
#|
#| A TextColumn keeps the payloads in ONE buffer, laid out back to back, plus
#| a per-row byte offset and length.  Building it is a single copy per chunk
#| in C (`dkd_varchar_unpack`), no matter how many rows there are.  Work that
#| only needs bytes -- grouping, hashing, length filters, writing the column
#| back out, feeding a parser -- can then read `.bytes`, `.offset`, `.length`
#| without ever materialising a string.  `.at($i)` still works and costs one
#| `Str` for the one row you asked for.
#|
#| Layout
#| ======
#|     bytes[offset($i) .. offset($i) + length($i))   # UTF-8 payload of row $i
#|
#| Rows 0..n-1 are contiguous and non-overlapping; a NULL row has length 0.
#| The buffer is UTF-8, so byte offsets are what you want for slicing bytes,
#| but they are NOT character offsets -- do not index the decoded text of the
#| whole buffer with them.
#|
#| Lifetime
#| ========
#| The buffer belongs to this object; the chunk handles it was built from
#| belong to the Result, which is referenced here so it cannot be collected
#| while the view exists.  Streaming results are the exception: their chunks
#| are recycled when the next chunk is pulled, and a TextColumn built from a
#| streaming view is a detached copy (safe, but no longer tied to the stream).
unit class DB::DuckDB::TextColumn;

use DB::DuckDB::Native;
use DB::DuckDB::VarcharShim;
use DB::DuckDB::VarcharShim::Native;
use NativeCall;

# UINT64_MAX: the C side's "this vector is not flat, do not touch it".
my constant NOT-FLAT = 18446744073709551615;

#| True when the byte level export is available in this process (the C shim
#| compiled or was supplied).  When False, `.text` on a ColumnView dies with
#| an explanation instead of silently falling back to a slow path.
our sub text-column-available(--> Bool) is export
{
    DB::DuckDB::VarcharShim::shim-active();
}

has Int $.elems;
has Int $.tid;
has Str $.type;

#| Keeps the result -- and therefore the chunk handles -- alive.
has $.result;

has Buf $!buf;
has $!offs;        # CArray[uint64]
has $!lens;        # CArray[uint32]
has $!nulls;       # CArray[uint8]
has Bool $!has-nulls = False;

#| Build a TextColumn from a column of a materialised result.
#|
#| `@chunks` are the owned chunk handles, `@rows` the row count of each, and
#| `$index` the column position inside them.  Not called directly in normal
#| use: `ColumnView.text` is the documented entry point.
method build(Int :$index!, Int :$elems!, Int :$tid!, Str :$type,
             :$result, :@chunks, :@rows --> DB::DuckDB::TextColumn)
{
    die "the VARCHAR shim is not available in this process, so a text "
      ~ "column cannot be exported as raw bytes; use .to-list / .at instead "
      ~ "(set DB_DUCKDB_NO_VARCHAR_SHIM=0 and make sure a C compiler is on "
      ~ "PATH, or point DB_DUCKDB_VARCHAR_SHIM at a built library)"
        unless text-column-available();

    my uint64 $nchunks = @chunks.elems;

    # Pass 1: how many payload bytes does each chunk need?  The C side
    # answers that from the vector alone (out = NULL is a sizing pass), so
    # the destination buffer can be allocated exactly once for the column
    # instead of once per chunk and then concatenated.
    my @need;
    my uint64 $total = 0;
    my Bool $any-validity = False;
    for ^$nchunks -> int $s {
        my uint64 $n = @rows[$s];
        @need.push: 0;
        next if $n == 0;

        my $vec   = duckdb-data-chunk-get-vector(@chunks[$s], $index);
        my $data  = duckdb-vector-get-data($vec);
        my $valid = duckdb-vector-get-validity($vec);
        $any-validity = True if $valid.defined;

        my uint64 $need = unpack-varchar-into($data, $valid, $n,
            Pointer, 0, Pointer, Pointer, Pointer);
        return self!from-values(:$index, :$elems, :$tid, :$type,
                                :$result, :@chunks, :@rows)
            if $need >= NOT-FLAT;
        @need[$s] = $need;
        $total += $need;
    }

    my Buf $buf = $total > 0 ?? Buf.allocate($total) !! Buf.new;
    my CArray[uint64] $offs  .= new;
    my CArray[uint32] $lens  .= new;
    my CArray[uint8]  $nulls .= new;
    # Touching the last slot is what makes CArray allocate: `$elems` rows of
    # offsets, lengths and null flags, all filled by the C side below.
    if $elems > 0 {
        $offs[$elems - 1]  = 0;
        $lens[$elems - 1]  = 0;
        $nulls[$elems - 1] = 0;
    }

    my Pointer $buf-p   = $total > 0 ?? nativecast(Pointer, $buf) !! Pointer;
    my Pointer $offs-p  = nativecast(Pointer, $offs);
    my Pointer $lens-p  = nativecast(Pointer, $lens);
    my Pointer $nulls-p = nativecast(Pointer, $nulls);

    # Pass 2: fill.  Every destination pointer is advanced by element count
    # times element size here in Raku, so the C side always writes at offset
    # 0 of the slice it is handed.  The offset table is the one thing that
    # cannot be sliced that way -- C numbers a chunk's payloads from 0 -- so
    # $byte-base is handed over and added to each entry in C, where it costs
    # a store per row instead of a ~0.5 s per million Raku-level fixup.
    my uint64 $row-base  = 0;
    my uint64 $byte-base = 0;
    for ^$nchunks -> int $s {
        my uint64 $n = @rows[$s];
        next if $n == 0;

        my $vec   = duckdb-data-chunk-get-vector(@chunks[$s], $index);
        my $data  = duckdb-vector-get-data($vec);
        my $valid = duckdb-vector-get-validity($vec);

        my uint64 $got = unpack-varchar-into($data, $valid, $n,
            $total > 0 ?? Pointer.new($buf-p.Int + $byte-base) !! Pointer,
            @need[$s],
            Pointer.new($offs-p.Int  + $row-base * 8),
            Pointer.new($lens-p.Int  + $row-base * 4),
            Pointer.new($nulls-p.Int + $row-base),
            $byte-base);
        die "text column shrank between the sizing and filling pass "
          ~ "(chunk $s: {$got} of {@need[$s]} bytes); the result was read "
          ~ "from two places at once"
            if $got >= NOT-FLAT || $got != @need[$s];

        $byte-base += @need[$s];
        $row-base  += $n;
    }

    self.new(
        elems => $elems, tid => $tid, type => $type, result => $result,
        buf => $buf, offs => $offs, lens => $lens, nulls => $nulls,
        has-nulls => $any-validity,
    );
}

#| Fallback for vectors the shim refuses (dictionary / selection vectors).
#| Correct, but it goes through the per-value decoder first, so it is the
#| slow path and only triggers on results the engine did not flatten.
method !from-values(Int :$index!, Int :$elems!, Int :$tid!, Str :$type,
                    :$result, :@chunks, :@rows --> DB::DuckDB::TextColumn)
{
    my @vals;
    for ^@chunks.elems -> int $s {
        my uint64 $n = @rows[$s];
        next if $n == 0;
        $result.decode-column-into(@vals, @chunks[$s], $index, $n);
    }

    my @bytes;
    my @offs;
    my @lens;
    my @nulls;
    my uint64 $at = 0;
    for @vals -> $v {
        @offs.push: $at;
        @nulls.push: 0;
        if $v.defined {
            my Buf $b = $v.Str.encode('utf-8');
            @bytes.push: $b;
            @lens.push: $b.elems;
            $at += $b.elems;
        }
        else {
            @lens.push: 0;
            @nulls.push: 1;
        }
    }

    my Buf $buf = $at > 0 ?? Buf.allocate($at) !! Buf.new;
    my int $pos = 0;
    for @bytes -> Buf $b {
        $buf[$pos ..^ $pos + $b.elems] = $b if $b.elems;
        $pos += $b.elems;
    }

    my CArray[uint64] $offs  .= new;
    my CArray[uint32] $lens  .= new;
    my CArray[uint8]  $nulls .= new;
    for ^@offs.elems -> int $i {
        $offs[$i]  = @offs[$i];
        $lens[$i]  = @lens[$i];
        $nulls[$i] = @nulls[$i];
    }

    self.new(
        elems => $elems, tid => $tid, type => $type, result => $result,
        buf => $buf, offs => $offs, lens => $lens, nulls => $nulls,
        has-nulls => @nulls.grep(* != 0).elems > 0,
    );
}

submethod BUILD(Int :$!elems!, Int :$!tid!, Str :$!type, :$!result,
                Buf :$!buf!, :$!offs!, :$!lens!, :$!nulls!,
                Bool :$has-nulls = False)
{
    $!has-nulls = $has-nulls;
}

#| The payload bytes of the whole column, back to back.  Borrowed, not a
#| copy: do not modify it, and treat it as read-only while the view lives.
method bytes(--> Buf) { $!buf }

#| Byte offset of row `$i` inside `.bytes`.
method offset(Int $i --> Int) { $!offs[$i].Int }

#| Byte length of row `$i` (0 for NULL and for the empty string).
method length(Int $i --> Int) { $!lens[$i].Int }

#| The offset table itself: one uint64 per row, borrowed, read only.  A hot
#| loop reading `$t.offset-buffer[$i]` skips the per-row method dispatch that
#| `.offset($i)` pays.
method offset-buffer(--> Mu) { $!offs }

#| The length table itself: one uint32 per row, borrowed, read only.  Same
#| reason as `offset-buffer`: `length($i)` on a million rows costs 0.4 µs per
#| dispatch, indexing this costs a fraction of that.
method length-buffer(--> Mu) { $!lens }

#| The NULL flags, one uint8 per row (1 = SQL NULL), borrowed, read only.
method null-buffer(--> Mu) { $!nulls }

#| True when row `$i` is a SQL NULL.
method is-null(Int $i --> Bool)
{
    $!has-nulls && $!nulls[$i] != 0;
}

#| The bytes of row `$i` as a Buf slice -- no UTF-8 decode, no Str.
#| Buf.is null returns an empty Buf, so check `.is-null` when it matters.
method bytes-at(Int $i --> Buf)
{
    my Int $l = self.length($i);
    $l == 0 ?? Buf.new !! $!buf.subbuf(self.offset($i), $l);
}

#| Row `$i` as a Str, the same value `column()` would have produced.
#| Costs one Str -- call it for the rows you need, not for all of them.
method at(Int $i --> Mu)
{
    return Any if self.is-null($i);
    my Int $l = self.length($i);
    return '' if $l == 0;
    $!buf.subbuf(self.offset($i), $l).decode('utf-8');
}

#| Every value as a Str (or Any for NULL).  Same result as `.to-list` on the
#| ColumnView, and the only method here that allocates per row.
#|
#| ASCII payloads are decoded once per window and sliced with `substr`
#| instead of going through `subbuf` + `decode` for every row.  Measured on
#| a million rows / 19.5 MB, the per-row path costs about 5.7 s and this one
#| 1.6-2.7 s: the win is dropping a million Buf allocations and a million
#| UTF-8 validations, not the substr itself, which is now the floor (one
#| Str per value cannot be avoided).  Windows start on row boundaries and
#| are capped at 8 MiB, so peak extra memory is one window rather than a
#| second copy of the whole payload.  Any window that is not pure ASCII --
#| a `chars` count below its byte count -- falls back to the per-row path
#| for that window only, keeping non-ASCII columns correct.
#|
#| Set DB_DUCKDB_NO_TEXT_WHOLE=1 to force the old per-row path.
method to-list(--> List)
{
    my uint64 $n = $!elems;
    return ().List if $n == 0;

    my @out;
    my Buf  $buf   = $!buf;
    my Bool $nulls = $!has-nulls;
    my uint64 $bytes = $buf.elems;

    if $bytes == 0 || %*ENV<DB_DUCKDB_NO_TEXT_WHOLE> {
        for ^$n -> int $i { @out.push: self.at($i) }
        return @out.List;
    }

    # Rows are laid out back to back in $buf, so a window is a byte range
    # that begins and ends between rows and can be decoded on its own: a
    # slice never splits a UTF-8 sequence.
    my uint64 $win = 8 * 1024 * 1024;
    my uint64 $i   = 0;
    while $i < $n {
        my uint64 $from = $!offs[$i];
        my uint64 $j    = $i;
        my uint64 $to   = $from;
        while $j < $n && ($to - $from) < $win {
            $to += $!lens[$j];
            $j++;
        }

        my Buf $slice = $buf.subbuf($from, $to - $from);
        my Str $s     = $slice.decode('utf-8');

        if $s.chars == $slice.elems {
            # One Str per window, one Str per non-empty row.
            my uint64 $p = 0;
            loop (my uint64 $k = $i; $k < $j; $k++) {
                my uint32 $l = $!lens[$k];
                if $l == 0 {
                    @out.push: ($nulls && $!nulls[$k] != 0) ?? Any !! '';
                }
                else {
                    @out.push: $s.substr($p, $l);
                    $p += $l;
                }
            }
        }
        else {
            loop (my uint64 $k = $i; $k < $j; $k++) { @out.push: self.at($k) }
        }
        $i = $j;
    }
    @out.List;
}

#| Total payload byte count across the column (NULLs and empty strings 0).
method byte-size(--> Int) { $!buf.elems }

#| Number of non-NULL values.
method count(--> Int)
{
    return $!elems unless $!has-nulls;
    my Int $c = 0;
    for ^$!elems -> int $i { $c++ unless $!nulls[$i] }
    $c;
}

method gist(--> Str)
{
    "DB::DuckDB::TextColumn({$!type}, {$!elems} rows, {$!buf.elems} bytes)";
}
