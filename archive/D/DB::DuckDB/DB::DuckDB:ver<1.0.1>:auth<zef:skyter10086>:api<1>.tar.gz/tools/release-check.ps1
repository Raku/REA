﻿<#
.SYNOPSIS
    Run the full test suite and report a release verdict.

.DESCRIPTION
    The 16 test files are run one by one so that a crash in one of them cannot
    swallow the output of the rest, and so that the assertion count printed at
    the end is the sum of what actually executed.  Exit code is 0 only when
    every file exits 0 and reports no `not ok`.

    Each log is first stripped of the known `libunwind: pc not in table` noise that
    llvm-mingw builds of libduckdb print, so that it cannot be mistaken for a failure.

    This is the Windows half of the release gate; the WSL half is
    `zef install .` (see HANDOFF section 10).

.EXAMPLE
    pwsh -File tools/release-check.ps1
    pwsh -File tools/release-check.ps1 -Filter 16-text
#>
param(
    [string]$Filter = '',
    [string]$Raku = 'raku'
)

$root = Split-Path -Parent $PSScriptRoot
Push-Location $root

$files = Get-ChildItem t -Filter *.rakutest | Sort-Object Name |
         Where-Object { $Filter -eq '' -or $_.Name -like "*$Filter*" }

if (-not $files) { Write-Host "no test files matched '$Filter'" -ForegroundColor Red; Pop-Location; exit 1 }

$log = Join-Path ([IO.Path]::GetTempPath()) ("duckdb-test-{0}.log" -f [guid]::NewGuid())
$totalOk = 0
$totalTop = 0
$totalNotOk = 0
$totalNoise = 0
$failed = @()
$rows = @()

foreach ($f in $files) {
    # Go through cmd: PowerShell turns a native command's stderr into an ErrorRecord
    # ('raku.exe : ...' plus an At/category banner), which is what made the libunwind
    # line look like a crash in the first place.
    & cmd /c ('"{0}" -Ilib "{1}" > "{2}" 2>&1' -f $Raku, $f.FullName, $log)
    $code = $LASTEXITCODE
    $text = Get-Content $log -Raw
    if (-not $text) { $text = '' }
    # llvm-mingw builds of libduckdb print 'libunwind: pc not in table' when a C++
    # exception unwinds through a MoarVM frame.  It is not this distribution's
    # output and it does not affect the verdict, so drop it before counting.
    $noise = ([regex]::Matches($text, '(?m)^\s*libunwind:')).Count
    $totalNoise += $noise
    if ($noise -gt 0) { $text = [regex]::Replace($text, '(?m)^\s*libunwind:[^\r\n]*(\r?\n|$)', '') }
    $ok    = ([regex]::Matches($text, '(?m)^\s*ok[\s\d]')).Count
    $top   = ([regex]::Matches($text, '(?m)^ok[\s\d]')).Count
    $notOk = ([regex]::Matches($text, '(?m)^\s*not ok')).Count
    $totalOk    += $ok
    $totalTop   += $top
    $totalNotOk += $notOk
    if ($code -ne 0 -or $notOk -gt 0) { $failed += $f.Name }
    $rows += [pscustomobject]@{ Test = $f.Name; Ok = $ok; NotOk = $notOk; Exit = $code }
}

Remove-Item $log -ErrorAction SilentlyContinue

$rows | Format-Table -AutoSize | Out-String | Write-Host

"tests: {0}  ok: {1} (top-level {2})  not ok: {3}" -f $files.Count, $totalOk, $totalTop, $totalNotOk | Write-Host
if ($totalNoise -gt 0) { "suppressed {0} known libunwind noise line(s)" -f $totalNoise | Write-Host -ForegroundColor DarkGray }
if ($failed) {
    "FAILED: {0}" -f ($failed -join ', ') | Write-Host -ForegroundColor Red
    Pop-Location
    exit 1
}
Write-Host 'PASS' -ForegroundColor Green
Pop-Location
exit 0
