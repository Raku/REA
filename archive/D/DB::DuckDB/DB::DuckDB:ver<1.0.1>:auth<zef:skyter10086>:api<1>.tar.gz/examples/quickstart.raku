﻿#| A five-line tour: in-memory database, a query, a column view, an appender.
#|
#|     raku -Ilib examples/quickstart.raku
use DB::DuckDB;

my $db = DB::DuckDB.new;

say $db.query('select 42').value;                       # 42

$db.execute('create table t (id INTEGER, name VARCHAR)');
my $app = $db.appender('t');
$app.append-row($_, "name-$_") for 1..5;
$app.flush;

# Column views skip per-value boxing; `.sum` / `.count` run over the raw buffer.
my $ids = $db.query('select id from t').column-view(0);
say $ids.sum;                                           # 15

say $db.query('select name from t order by id').arrays.map(*.[0]).join(',');  # name-1,...
