﻿use DB::Connection;
use DB::DuckDB::Native;
use DB::DuckDB::Error;
use DB::DuckDB::Statement;
use DB::DuckDB::Decoder;
use DB::DuckDB::Appender;
use DB::DuckDB::Parquet;

class DB::DuckDB::Connection does DB::Connection
{
    has DuckDB-Database   $.database is required;
    has DuckDB-Connection $.handle   is required;

    #| Session settings (`SET <name> = <value>`) applied as soon as the
    #| connection is created.  Filled in by the driver from its constructor
    #| options; see DB::DuckDB's `threads` / `memory-limit` /
    #| `preserve-insertion-order`.
    has %.session-options;

    has Bool $!closed = False;

    #| Whether this connection currently sits inside an explicit transaction.
    #| Tracked from the statements that go through `execute`, because DuckDB
    #| has no C API to ask -- and *probing* with a nested `BEGIN` is not an
    #| option: DuckDB marks the running transaction as aborted as soon as it
    #| refuses the nested one, which would poison the caller's work.
    has Bool $!in-transaction = False;

    # table name -> ordered column names, so the appender path can check that
    # a positional INSERT really is in table order.
    has %!table-columns;

    # Counter behind the names of the TEMP staging tables `execute-many`
    # creates for ON CONFLICT batches; only has to be unique per connection.
    has Int $!stage-seq = 0;

    submethod TWEAK(--> Nil)
    {
        try self.sync-time-zone-offset;
        self!apply-session-options;
    }

    # ------------------------------------------------------------- settings

    #| Render a value the way DuckDB's `SET` parser expects it.
    my sub sql-setting-value($value --> Str)
    {
        return $value.Str if $value ~~ Numeric && $value !~~ Bool;
        return $value ?? 'true' !! 'false' if $value ~~ Bool;
        "'" ~ $value.Str.subst("'", "''", :g) ~ "'";
    }

    method !apply-session-options(--> Nil)
    {
        return unless %!session-options.elems;
        for %!session-options.sort(*.key) -> $pair {
            next unless $pair.value.defined;
            try self.set-session-option($pair.key, $pair.value);
        }
    }

    #| Apply one DuckDB session/`SET` option on this connection, e.g.
    #| `set-session-option('threads', 4)` or
    #| `set-session-option('preserve_insertion_order', False)`.
    method set-session-option(Str:D $name, $value --> Nil)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        die DB::DuckDB::Error.new(message => "invalid session option name '{$name}'")
            unless $name ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/;

        self.execute("SET {$name} = {sql-setting-value($value)}", :finish(False));
    }

    #| TIMESTAMP_TZ arrives from the C API as plain UTC microseconds; the
    #| session time zone offset is what DuckDB adds back when it renders the
    #| value as text.  The offset is seeded here and refreshed whenever the
    #| session runs `SET TimeZone`.
    method sync-time-zone-offset(--> Nil)
    {
        return if $!closed;
        return unless $!handle.Bool;

        my DuckDB-Raw-Result $raw .= new;
        my $rc = duckdb-query(
            $!handle,
            q{select strftime(TIMESTAMPTZ '1970-01-01 00:00:00+00', '%z')},
            $raw,
        );
        return if $rc != DuckDBSuccess || !$raw.Bool;

        my $text = '';
        if !duckdb-value-is-null($raw, 0, 0) {
            $text = take-cstr-free(duckdb-value-varchar($raw, 0, 0)) // '';
        }
        duckdb-destroy-result($raw);

        return unless $text.chars > 1;

        # Formats seen in the wild: "+08", "+0800", "+08:00".
        my $sign = $text.substr(0, 1) eq '-' ?? -1 !! 1;
        my @digits = $text.substr(1).split(/<[:\s}]>/, :skip-empty);
        return unless @digits;

        my Int $hours = @digits[0].Int;
        my Int $mins  = (@digits[1] // 0).Int;
        $DB::DuckDB::Decoder::TIMESTAMP-TZ-OFFSET = $sign * ($hours * 3600 + $mins * 60);
    }

    #| True while the connection handle is still usable; `free` (or the
    #| driver's `close`) makes it False.
    method ping(--> Bool)
    {
        !$!closed && so $!handle.Bool;
    }

    #| Release the connection handle. Repeat calls are no-ops; the database
    #| itself is owned by the driver and stays open.
    method free(--> Nil)
    {
        return if $!closed;
        $!closed = True;

        # The database instance is owned by the driver and shared by every
        # connection, so only the connection handle is released here.
        duckdb-disconnect($!handle) if $!handle.Bool;
    }

    #| Prepare `$query` without adding it to the statement cache.  Use it for
    #| one-off SQL whose text would only evict the hot entries.
    method prepare-nocache(Str:D $query --> DB::DuckDB::Statement)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        my DuckDB-Prepared $ps .= new;
        my $rc = duckdb-prepare($!handle, $query, $ps);

        if $rc != DuckDBSuccess {
            my $msg = take-cstr(duckdb-prepare-error($ps));
            duckdb-destroy-prepare($ps) if $ps.Bool;
            die DB::DuckDB::Error.new(
                :code($rc),
                message => ($msg.chars ?? $msg !! "cannot prepare statement: $query"),
            );
        }

        DB::DuckDB::Statement.new(:db(self), :stmt($ps));
    }

    #| `DB.query` hands its connection straight back without returning it to
    #| the pool, so the connection travels with the result: it is released
    #| only after the rows have been drained.
    method query(Str:D $query, Bool :$finish, Bool :$nocache, Bool :$stream = False,
                 *@args, *%args)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        my $res = $.prepare($query, :$nocache)
                     .execute(|@args, |%args, :finish(False), :stream($stream));

        if $res ~~ DB::DuckDB::Result {
            $res.attach-connection(self) if $finish;
            return $res;
        }

        $.finish if $finish;
        $res;
    }

    #| True while an explicit transaction opened through `execute` is active.
    method in-transaction(--> Bool) { $!in-transaction }

    #| Classify a statement as transaction control and keep `$!in-transaction`
    #| in sync.  Only the leading keyword matters; `END TRANSACTION` is the
    #| SQL-standard spelling of COMMIT.
    my sub transaction-verb(Str:D $command --> Str)
    {
        my $sql = $command.trim.lc;
        return 'begin'    if $sql.starts-with('begin') || $sql.starts-with('start transaction');
        return 'commit'   if $sql.starts-with('commit') || $sql.starts-with('end transaction');
        return 'rollback' if $sql.starts-with('rollback');
        '';
    }

    method !note-transaction(Str:D $command --> Nil)
    {
        given transaction-verb($command) {
            when 'begin'    { $!in-transaction = True }
            when 'commit'   { $!in-transaction = False }
            when 'rollback' { $!in-transaction = False }
        }
    }

    #| `DB`'s execute() contract is "how many rows were affected", while
    #| `DB::Connection.execute` would hand back a result set for statements
    #| like CREATE TABLE (DuckDB returns a one-column count for DDL).  So
    #| anything with a result set is drained and reduced to its row count.
    method execute(Str:D $command, Bool :$finish, *@args, *%args --> Int)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        # Statements without bind parameters go straight through duckdb_query.
        # Going via a prepared statement silently drops session settings such
        # as `SET TimeZone` in 2.0 (the setting is applied while preparing and
        # then thrown away), so SET / PRAGMA / ATTACH have to take this path.
        if !@args.elems && !%args.keys {
            my DuckDB-Raw-Result $raw .= new;
            my $rc = duckdb-query($!handle, $command, $raw);
            if $rc != DuckDBSuccess {
                my $msg = take-cstr(duckdb-result-error($raw));
                duckdb-destroy-result($raw);
                die DB::DuckDB::Error.new(
                    :code($rc),
                    message => ($msg.chars ?? $msg !! "execution failed: $command"),
                );
            }
            my $changed = duckdb-rows-changed($raw).Int;
            duckdb-destroy-result($raw);

            self!note-transaction($command);

            # Rendering of TIMESTAMP_TZ depends on the session zone, so the
            # cached offset has to follow any change to it.
            self.sync-time-zone-offset
                if $command ~~ m:i/^\s*SET\s+(TimeZone|Time\s*Zone|TZ)/;

            return $changed;
        }

        my $res = $.prepare($command).execute(|@args, |%args, :finish(False));

        self!note-transaction($command);

        if $res ~~ DB::DuckDB::Result {
            my $changed = $res.rows-changed;
            $res.free;
            return $changed;
        }

        $res.Int;
    }

    # ---------------------------------------------------- batch write paths

    #| Open an appender on `$table`.  Values are appended in table column
    #| order; see DB::DuckDB::Appender for the value mapping.
    #|
    #|     my $ap = $conn.appender('t');
    #|     $ap.append-row(1, 'a');
    #|     $ap.free;
    method appender(Str:D $table, Str :$schema --> DB::DuckDB::Appender)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        DB::DuckDB::Appender.open($!handle, $table, :$schema);
    }

    #| Column names of `$table`, in table order.  Cached per connection;
    #| empty List when the table is unknown to DuckDB.
    method table-columns(Str:D $table --> List)
    {
        # NOTE: `.List` on the cached value matters: returning the bare hash
        # entry hands back a Scalar container, which a `--> List` method then
        # coerces into a *one-element* list holding the whole column list.
        return %!table-columns{$table}.List if %!table-columns{$table}:exists;

        my $escaped = $table.subst("'", "''", :g);
        my @names;
        try {
            @names = self.query("select name from pragma_table_info('{$escaped}')")
                          .arrays.map(*.head.Str).List;
        }
        %!table-columns{$table} = @names.List if @names.elems;
        return @names.List;
    }

    my sub row-width($row --> Int)
    {
        $row ~~ Positional && $row !~~ Blob ?? $row.elems !! 1;
    }

    my sub row-values($row --> List)
    {
        $row ~~ Positional && $row !~~ Blob ?? $row.list !! ($row,).List;
    }

    #| Run `&code` inside a transaction, but only if one can be started --
    #| an appender load issued while the caller already has a transaction
    #| open must not commit their work, so the caller's transaction is left
    #| alone.
    #|
    #| The check is done on `$!in-transaction` rather than by trying a
    #| `BEGIN` and swallowing the error: DuckDB *aborts* the running
    #| transaction when it refuses a nested one, so probing would leave the
    #| connection unusable for the rest of the caller's transaction.
    method !atomically(&code)
    {
        my $own = !$!in-transaction;


        if $own {
            self.execute('BEGIN TRANSACTION', :finish(False));
        }

        my $result;
        try {
            $result = code();
            self.execute('COMMIT', :finish(False)) if $own;

            CATCH {
                default {
                    # ROLLBACK has to be attempted even when `$own` is false:
                    # a failed statement aborts the surrounding transaction,
                    # and DuckDB refuses everything else until it is rolled
                    # back.  A caller-owned transaction is rolled back too --
                    # it is already poisoned at this point.
                    try {
                        self.execute('ROLLBACK', :finish(False));
                    }
                    .rethrow;
                }
            }
        }
        $result;
    }

    #| Open an appender for `$table`, or return `Nil` when DuckDB refuses
    #| (unknown table, no write permission, ...).  `$schema` is only forwarded
    #| when the caller supplied one -- passing an undefined value into
    #| `Str :$schema` would fail the type check and silently turn every bulk
    #| load into the slow fallback.
    method !try-appender(Str $table, $schema?)
    {
        my $ap;
        try {
            $ap = $schema.defined
                ?? DB::DuckDB::Appender.open($!handle, $table, :$schema)
                !! DB::DuckDB::Appender.open($!handle, $table);
        }
        $ap;
    }

    method !append-rows-via-appender($ap, @rows, @order? --> Int)
    {
        # NOTE: the appender is closed from a CATCH, not from a LEAVE.  A
        # LEAVE block runs only when the exception has already left this
        # method, i.e. *after* the caller has rolled the transaction back --
        # and closing the appender then flushes what it had buffered into a
        # fresh transaction, so a failed batch would keep the rows that
        # preceded the bad one.
        CATCH {
            default {
                try $ap.free;
                .rethrow;
            }
        }

        # NOTE: `@order` may arrive nested (`((1, 2, 0),)`) when the caller copied
        # an itemized Hash slot; flatten one level so the index list is used as
        # it was meant, not as a single positional index.
        my @ord = @order.elems == 1 && @order[0] ~~ Positional ?? @order[0].List !! @order.List;

        if @ord.elems {
            for @rows -> $row {
                my @vals = row-values($row);
                $ap.append-row(@ord.map({ @vals[$_] }).List);
            }
        }
        else {
            # Hand the whole batch over: `append-rows` resolves the column
            # types once and writes every value through a specialised
            # filler, which is far cheaper than one `append-row` per row.
            $ap.append-rows(@rows);
        }

        $ap.free;
        $ap.rows;
    }

    method !rows-via-appender(Str $table, $schema, @rows --> Int)
    {
        self!append-rows-via-appender(self!try-appender($table, $schema), @rows);
    }

    method !rows-via-statement(Str:D $sql, @rows --> Int)
    {
        my $sth = $.prepare($sql);
        my $count = 0;
        for @rows -> $row {
            my $changed = $sth.execute(|row-values($row), :finish(False));
            # An INSERT still comes back as a `Result` (DuckDB 2.0 reports a
            # one-column "Count" result even for DML), so the affected-row
            # count is either the numeric return value or `.rows-changed`.
            if $changed ~~ Numeric {
                $count += $changed.Int;
            }
            else {
                $count += ($changed.?rows-changed // 0).Int;
                try $changed.free;
            }
        }
        $count;
    }

    method !rows-via-sql(Str $table, @rows, Int $width --> Int)
    {
        my $placeholders = ('?' xx $width).join(', ');
        self!rows-via-statement("INSERT INTO {$table} VALUES ({$placeholders})", @rows);
    }

    #| Describe how a single-row positional INSERT maps onto the appender.
    #| Returns an empty Hash when the statement is not appender-safe (no
    #| column list and a width mismatch, a partial column list -- DEFAULT
    #| would be lost --, duplicated names, unknown table).
    method !insert-plan(Str:D $sql, Int $width --> Hash)
    {
        my $pattern = rx:i{ ^ \s* insert \s+ into \s+ (<-[\s(]>+) \s*
                            [ \( (<-[()]>*) \) ]? \s*
                            values \s* \( \s* \? \s* [ \, \s* \? \s* ]* \) \s*
                            [ on \s+ conflict \s+ (<-[;]>*) ]? \s* \;? \s* $ };
        my $m = $sql.match($pattern) orelse return Hash;

        my $table = $m[0].Str.subst(/^ '"' | '"' $/, '', :g);
        my @table-cols = self.table-columns($table);
        return Hash unless @table-cols.elems;

        my $spec = $m[1];
        my @order;
        my @cols;    # statement order, i.e. the order `@params` rows arrive in

        if $spec.defined && $spec.Str.trim.chars {
            my @given = $spec.Str.split(',').map({
                .trim.subst(/^ '"' | '"' $/, '', :g)
            }).List;

            # A partial column list would make the appender write NULL where
            # SQL would have used the column DEFAULT, so those stay on the
            # prepared-statement path.
            return Hash unless @given.elems == $width;
            return Hash unless @given.elems == @table-cols.elems;

            my %pos;
            my $i = 0;
            %pos{$_} = $i++ for @given;

            for @table-cols -> $col {
                return Hash unless %pos{$col}:exists;
                @order.push(%pos{$col});
            }
            return Hash unless @order.sort.List eqv (^@order.elems).List;

            @cols = @given;
        }
        else {
            return Hash unless $width == @table-cols.elems;
            @order = (^@table-cols.elems).List;
            @cols = @table-cols;
        }

        # A trailing ON CONFLICT clause means the appender cannot serve the
        # batch, but `execute-many` can still stage it; `tail` carries the
        # clause verbatim so the bulk replay behaves like the original.
        my $tail = $m[2].defined ?? ('on conflict ' ~ $m[2].Str.trim) !! '';

        # NOTE: an explicit `return` matters here -- a bare trailing
        # `{ ... }` is parsed as a Block, not as a Hash, and the caller would
        # then silently fall back to the prepared-statement path.
        my %plan =
            :$table,
            :order(@order.List),
            :cols(@cols.List),
            :$tail,
            :identity(@order.List eqv (^@order.elems).List);
        return %plan;
    }

    # Below this many rows the prepared statement wins: staging costs a
    # CREATE TEMP TABLE plus a DROP before the first row is even loaded.
    my constant STAGING-MIN-ROWS = 32;

    # Rows per appender flush when filling a staging table.  One appender
    # that flushes 128Ki rows or more inside an explicit transaction leaves
    # the TEMP table unreadable for the rest of that transaction: the replay
    # `INSERT ... SELECT` reports 0 rows and inserts nothing, with no error.
    # A fresh appender every 64Ki rows keeps the load correct, and costs
    # nothing measurable.
    my constant STAGE-CHUNK = 65_536;

    #| Fill the staging table with `@rows`, one appender per chunk.
    method !stage-load(Str $name, @rows, @order --> Int)
    {
        my int $total = @rows.elems;
        my int $done  = 0;
        my int $i     = 0;
        while $i < $total {
            my $take = ($total - $i) min STAGE-CHUNK;
            my $ap = self.appender($name);
            $done += self!append-rows-via-appender($ap, @rows[$i ..^ $i + $take], @order);
            $i += $take;
        }
        $done;
    }

    #| Describe how an ON CONFLICT batch can be served by the staging table.
    #| Returns an empty Hash when the batch has to stay on the
    #| prepared-statement path.
    method !staging-plan(Hash $plan, @rows --> Hash)
    {
        return Hash unless $plan.defined && $plan.elems;

        my $tail = $plan<tail>;
        return Hash unless $tail.chars;

        # DO NOTHING is commutative: skipping a row gives the same result
        # whether the rows are applied one by one or all at once, so any
        # batch qualifies -- including one with duplicate keys inside it.
        return $plan if $tail ~~ m:i{ ^ on \s+ conflict <|w> <-[;]>*? do \s+ nothing \s* $ };

        # DO UPDATE is applied once per key by the bulk INSERT ... SELECT but
        # once per *row* by the prepared path.  Both agree while the batch
        # holds no duplicate key, and disagree once it does: the prepared path
        # updates the same row twice, the bulk one only once.  The last write
        # wins in both cases, so a batch with duplicates is not rejected -- it
        # is de-duplicated on the conflict key first (see `key-pos` below),
        # which is what the replay would have collapsed it to anyway.
        #
        # The conflict target is either an explicit column list or a
        # constraint name; `ON CONSTRAINT` is resolved against the catalogue
        # because the batch cannot be replayed without knowing its columns.
        # NOTE: `ON CONSTRAINT <name>` is not implemented by DuckDB itself --
        # the engine refuses the statement before any rows are looked at, so
        # there is nothing to stage and the caller gets the same error from
        # the prepared path.
        my $m = $tail.match(rx:i{ ^ on \s+ conflict \s* \( (<-[()]>+) \) \s+ do \s+ update <|w> });
        return Hash unless $m;

        my @keys = $m[0].Str.split(',').map({
            .trim.subst(/^ '"' | '"' $/, '', :g)
        }).List;
        return Hash unless @keys.elems;

        my %pos;
        my $i = 0;
        %pos{$_} = $i++ for $plan<cols>.List;

        my @idx;
        for @keys -> $key {
            return Hash unless %pos{$key}:exists;
            @idx.push(%pos{$key});
        }
        return Hash unless @idx.elems;

        # Hand the key positions over: the rows are replayed by a single
        # INSERT ... SELECT, so they have to be collapsed to one row per key
        # first, and only the staging load knows whether that is needed.
        $plan<key-pos> = @idx.List;
        return $plan;
    }

    #| Load `@rows` into a TEMP table through the appender, then apply them
    #| with a single INSERT ... SELECT that replays the statement's ON
    #| CONFLICT clause -- two round-trips instead of one prepared execution
    #| per row (a 100k-row upsert batch drops from minutes to under a second).
    method !rows-via-staging(Hash $plan, @rows --> Int)
    {
        my $table = $plan<table>;
        my @table-cols = self.table-columns($table);
        my $width = $plan<cols>.elems;
        return 0 unless @table-cols.elems;

        my $name = '__db_duckdb_stage_' ~ (++$!stage-seq);
        my $cols = @table-cols.map({ '"' ~ .subst('"', '""', :g) ~ '"' }).join(', ');
        my $tail = $plan<tail>;

        # CTAS copies the exact column types the appender needs while
        # dropping the target's constraints; `limit 0` keeps the copy empty.
        self.execute("create temp table {$name} as select {$cols} from {$table} limit 0");
        LEAVE { try self.execute("drop table if exists {$name}") }

        # `execute-many` hands a bare table name to the appender and DuckDB
        # resolves it against the `temp` schema -- passing `:schema<temp>`
        # here instead fails with 'Table ""."temp".x could not be found'.
        my $ap;
        try { $ap = self.appender($name) }

        # No appender means no staging: rebuild the caller's own statement
        # (same column order, same width) and run it row by row.
        return self!rows-via-statement(
                    "insert into {$table} (" ~ $plan<cols>.List.join(', ')
                    ~ ') values (' ~ ('?' xx $width).join(', ') ~ ") {$tail}",
                    @rows)
                unless $ap.defined;

        $ap.free;   # probe only: the batch is loaded in chunks below.

        self!stage-load($name, @rows, $plan<identity> ?? () !! $plan<order>.List);

        # One replay statement for the whole batch.  When the statement keys
        # the conflict on a column set, rows that share a key are collapsed
        # here rather than in Raku: the prepared path would update the same
        # row once per duplicate, the replay only once, and the last row of a
        # group is the one that survives both.  `rowid` is the staging table's
        # insertion order, so `order by rowid desc` picks that last row; rows
        # with a NULL in any key column are exempt, because a UNIQUE
        # constraint lets NULLs repeat and SQL would insert every one.
        my $src = "select {$cols} from {$name}";
        my $kp = $plan<key-pos>;
        if $kp.defined && $kp.List.elems {
            my @key-cols = $kp.List.map({ '"' ~ $plan<cols>[$_].subst('"', '""', :g) ~ '"' });
            my $any-null = '(' ~ @key-cols.map({ "{$_} is null" }).join(' or ') ~ ')';

            # The window costs about a third of the replay, so it is only
            # built when the batch really repeats a key: probe first, and
            # leave NULL keys out of the probe because they never collapse.
            my $repeats = self.query(
                "select 1 from {$name} where not {$any-null} "
              ~ "group by {@key-cols.join(', ')} having count(*) > 1 limit 1").array;

            if $repeats.elems {
                $src = "select {$cols} from (select {$cols}, "
                     ~ "case when {$any-null} then 1 else row_number() over "
                     ~ "(partition by {@key-cols.join(', ')} order by rowid desc) end "
                     ~ "as __db_duckdb_rn from {$name}) where __db_duckdb_rn = 1";
            }
        }

        self.execute("insert into {$table} ({$cols}) {$src} {$tail}");
    }

    #| Insert many rows through DuckDB's appender (falls back to a prepared
    #| single-row INSERT when the appender cannot be used, e.g. the table
    #| does not exist yet).  The whole load is wrapped in a transaction
    #| unless `:!transaction`.
    #|
    #|     $conn.insert-rows('t', ((1, 'a'), (2, 'b')));
    method insert-rows(Str:D $table, @rows, Str :$schema, Bool :$transaction = True --> Int)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        return 0 unless @rows.elems;

        my $width = row-width(@rows[0]);

        # NOTE: the appender must be created *inside* the transaction.  DuckDB
        # opens its own transaction when an appender is created, so a BEGIN
        # issued afterwards is refused and silently ignored -- and a failing
        # load would then keep whatever rows had already been flushed.
        # NOTE: no `return` inside the closure below -- in Raku a `return` in
        # a block returns from the enclosing *method*, which would skip the
        # COMMIT issued by `!atomically` and leave the transaction open.
        my $run = -> {
            my $ap = self!try-appender($table, $schema);
            $ap.defined
                ?? self!append-rows-via-appender($ap, @rows)
                !! self!rows-via-sql($table, @rows, $width);
        };

        return self!atomically($run) if $transaction;
        $run();
    }

    #| Run the same single-row INSERT once per parameter set.  When the
    #| statement is a plain `INSERT INTO t [(cols)] VALUES (?...)` the batch
    #| is routed through the appender (identical rows, no SQL parsing).
    #| A batch that carries an `ON CONFLICT` clause cannot use the appender
    #| on its own, so it is staged instead: the rows are loaded into a TEMP
    #| table by the appender and replayed with one `INSERT ... SELECT` that
    #| keeps the clause (`DO NOTHING` always, `DO UPDATE` when the batch has
    #| no duplicate key).  Anything left -- RETURNING, expressions, sub-selects,
    #| partial column lists -- runs through one prepared statement per row
    #| inside a transaction.
    #|
    #|     $conn.execute-many('insert into t values (?, ?)', ((1, 'a'), (2, 'b')));
    method execute-many(Str:D $sql, @params, Bool :$transaction = True --> Int)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        return 0 unless @params.elems;

        # NOTE: keep the plan in a scalar -- `!insert-plan` returns the `Hash`
        # *type object* when the statement is not appender-safe, and assigning
        # that to a `%`-sigiled variable blows up on the first lookup.
        my $plan = self!insert-plan($sql, row-width(@params[0]));

        # Only pay for a staging table once the batch is big enough to outrun
        # the per-row prepared statement.
        my $stage = $plan.defined && $plan.elems && $plan<tail>.chars
                        && @params.elems >= STAGING-MIN-ROWS
                    ?? self!staging-plan($plan, @params)
                    !! Hash;

        # As in `insert-rows`, the appender is opened by the transaction body:
        # opening it earlier would leave the batch without a transaction.
        # No `return` here either -- it would escape the method and skip the
        # COMMIT.
        my $run = -> {
            my $appender-safe = $plan.defined && $plan.elems && !$plan<tail>.chars;
            my $ap = $appender-safe ?? self!try-appender($plan<table>) !! Any;

            if $ap.defined {
                # NOTE: `$plan<order>` comes back itemized (`$(1, 2, 0)`) because a
                # Hash slot is a scalar container; copying it into @order without
                # `.List` yields a one-element array holding the whole list, and
                # every row then lands on DEFAULT.  `.List` unpacks it.
                my @order = $plan<identity> ?? () !! $plan<order>.List;
                $plan<identity>
                    ?? self!append-rows-via-appender($ap, @params)
                    !! self!append-rows-via-appender($ap, @params, @order);
            }
            elsif $stage.defined && $stage.elems {
                self!rows-via-staging($stage, @params);
            }
            else {
                self!rows-via-statement($sql, @params);
            }
        };

        return self!atomically($run) if $transaction;
        $run();
    }

    # ------------------------------------------------------------- parquet
    #
    # Parquet has no C API entry point in DuckDB 2.0 (see the note at the top
    # of DB::DuckDB::Parquet), so these methods compose SQL around the
    # `read_parquet` table function and `COPY ... TO`.  Read paths bind the
    # file names, which is why a path with a quote in it works unchanged and
    # no escaping is needed on the way in.

    #| Read a Parquet file -- or a glob like `dir/*.parquet` -- as an ordinary
    #| result set, decoded by the same chunk/vector path a table scan uses.
    #|
    #|     $db.read-parquet('sales.parquet').column-views[0].sum;
    #|     $db.read-parquet('dir/*.parquet', :union-by-name, :filename);
    #|     $db.read-parquet('dir/*.parquet', :columns<a b>);
    #|
    #| `:hive-partitioning` is left to DuckDB when not given (`hive_partitioning`
    #| is inferred).  `:filename` adds a `filename` column naming the source
    #| file; `:union-by-name` merges files whose column order differs.
    #|
    #| The rows are materialised unless `:stream` is passed, so the result
    #| cannot be read twice -- use `.column-views`, `arrays` or `hashes` once.
    multi method read-parquet(Str:D $path,
                              Bool :union-by-name($union-by-name) = False,
                              Bool :$filename = False,
                              Bool :hive-partitioning($hive-partitioning),
                              :columns($columns),
                              Bool :$stream = False)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        self.query(
            parquet-read-sql(:columns($columns), :union-by-name($union-by-name),
                             :filename($filename),
                             :hive-partitioning($hive-partitioning)),
            $path, :$stream,
        );
    }

    #| Read several Parquet files as one result set.  The list is bound one
    #| placeholder per file, so the names are never spliced into SQL.
    #|
    #|     $db.read-parquet(<a.parquet b.parquet>, :union-by-name);
    multi method read-parquet(@paths,
                              Bool :union-by-name($union-by-name) = False,
                              Bool :$filename = False,
                              Bool :hive-partitioning($hive-partitioning),
                              :columns($columns),
                              Bool :$stream = False)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        die DB::DuckDB::Error.new(message => 'read-parquet needs at least one path')
            unless @paths.elems;

        self.query(
            parquet-read-sql(:columns($columns), :union-by-name($union-by-name),
                             :filename($filename),
                             :hive-partitioning($hive-partitioning),
                             :path-count(@paths.elems)),
            |@paths, :$stream,
        );
    }

    #| Write a table or a query to a Parquet file and return the row count.
    #|
    #|     $db.write-parquet('out.parquet', 'events');                    # table
    #|     $db.write-parquet('out.parquet', 'select * from events where ok', :sql);
    #|     $db.write-parquet('out/z.parquet', 'events', :compression<zstd>,
    #|                       :row-group-size(250_000));
    #|     $db.write-parquet('out/part', 'events', :partition-by<day region>);
    #|
    #| DuckDB overwrites an existing file with the same name; pass
    #| `:overwrite-or-ignore` when writing into a partitioned directory that
    #| may already hold files.  `$source` is a table name by default and is
    #| quoted as one, so a name that looks like SQL cannot escape.
    method write-parquet(Str:D $path, Str:D $source, Bool :$sql = False, Str :$schema,
                         Str :$compression, Int :row-group-size($row-group-size),
                         :partition-by($partition-by),
                         Bool :overwrite-or-ignore($overwrite-or-ignore) = False --> Int)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        self.execute(
            parquet-copy-sql($path, $source, :$sql, :$schema, :$compression,
                             :row-group-size($row-group-size),
                             :partition-by($partition-by),
                             :overwrite-or-ignore($overwrite-or-ignore)),
            :finish(False),
        );
    }

    #| Footer metadata, one Hash per file: `num_rows`, `num_row_groups`,
    #| `format_version`, `created_by`, `file_name`, ...  Reads only the footer.
    method parquet-metadata(Str:D $path --> List)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        self.query('select * from parquet_file_metadata(?)', $path).hashes.List;
    }

    #| Column layout as stored in the file: `name`, `type` (physical),
    #| `converted_type`, `logical_type`, `num_children`, ...
    method parquet-schema(Str:D $path --> List)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        self.query('select * from parquet_schema(?)', $path).hashes.List;
    }

    #| Per row group and per column: compression, sizes, encodings, statistics.
    #| One row per column chunk, so a file with N row groups and C columns
    #| yields N x C rows.
    method parquet-row-groups(Str:D $path --> List)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;
        self.query('select * from parquet_metadata(?)', $path).hashes.List;
    }
}
