use v6.d;

#| Zero-copy arrow views over a DuckDB result.
#|
#| `duckdb_data_chunk_to_arrow` turns a chunk into an Arrow struct array
#| (one child per column) using the Arrow C data interface.  That interface
#| is a fixed 10 field layout, so no Arrow library -- neither the DuckDB
#| `arrow` extension nor NanoArrow -- is required: the struct is declared
#| here and read directly.
#|
#| Measured on 1M rows x 3 columns (see docs), the conversion itself costs
#| ~0.035 us/row, numeric columns read at the same speed as DuckDB's own
#| vectors, and UTF-8 columns are slower than the driver's join+split path.
#| The real win is nested data: LIST/STRUCT/MAP arrive as recursively
#| walkable arrays instead of being stringified.
unit module DB::DuckDB::Arrow;

use NativeCall;
use DB::DuckDB::Native;
use DB::DuckDB::Result;
use DB::DuckDB::ArrowShim;

my constant WIN = $*DISTRO.is-win;

class ArrowArray is repr('CStruct') is export {
    has int64 $.length;
    has int64 $.null-count;
    has int64 $.offset;
    has int64 $.n-buffers;
    has int64 $.n-children;
    has Pointer $.buffers;
    has Pointer $.children;
    has Pointer $.dictionary;
    has Pointer $.release-fn;
    has Pointer $.private-data;
}

sub result-arrow-options(DuckDB-Raw-Result $result --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_result_get_arrow_options') { }
sub chunk-to-arrow(Pointer $options, DuckDB-Data-Chunk $chunk, Pointer $out --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_data_chunk_to_arrow') { }

# The release callback is only known at run time, so it is called through the
# C shim when one could be built (see DB::DuckDB::ArrowShim): invoking a raw
# function pointer from Raku is both ABI-fragile and lossy, measured at ~24 KB
# of process growth per call.  The in-Raku path stays as a fallback for boxes
# without a compiler.
my $SHIM-RELEASE;
my Bool $SHIM-PROBED = False;

sub shim-release-fn()
{
    return Nil if %*ENV<DB_DUCKDB_NO_ARROW_SHIM>;
    return $SHIM-RELEASE if $SHIM-PROBED;
    $SHIM-PROBED = True;

    # `require` proves only that the module compiles: `is native(&shim-library)`
    # resolves lazily, so on a box without a compiler the module loads happily
    # and the failure is deferred to the first native call -- by which point the
    # array is in hand and there is no second release path left.  Ask the shim
    # module whether a library actually exists *before* promising to use it, so
    # the fallback is a fallback and not a die.
    my $lib = try { DB::DuckDB::ArrowShim::shim-lib() } // '';
    unless $lib.chars {
        note "ARROW DEBUG: no shim library; in-Raku release"
            if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
        return $SHIM-RELEASE = Nil;
    }

    $SHIM-RELEASE = try {
        my $mod = (require ::('DB::DuckDB::ArrowShim::Native'));
        my &release = $mod.WHO<&dkd-arrow-release>;
        &release.defined ?? &release !! Nil;
    };
    note "ARROW DEBUG: shim load failed: {$!}" if %*ENV<DB_DUCKDB_ARROW_DEBUG> && !$SHIM-RELEASE;
    $SHIM-RELEASE;
}

# Release callback pointers are stable for the lifetime of the library: DuckDB
# hands out one function for every chunk it converts (measured: a single
# distinct pointer across 245 chunks of five different results).  That matters
# because `nativecast(:(Pointer), $ptr)` builds a fresh native call stub every
# time it runs, and those stubs are never reclaimed -- the in-Raku path grew
# 69 MB over ~1500 releases, which is what the shim was hiding.  Caching one
# stub per distinct pointer removes the growth entirely without needing a
# compiler.
#
# The cache is keyed by the pointer value, so a library that really does use
# several release functions still gets one stub each.  A lock guards the fill
# only; lookups after the first are plain hash reads.
my %RELEASE-CACHE{Int};
my $RELEASE-LOCK = Lock.new;

sub raku-release(Pointer $addr --> Nil)
{
    my $root = nativecast(ArrowArray, $addr);
    my $fn = $root.release-fn;
    return unless $fn.defined && $fn.Int;

    my $key = $fn.Int;
    my $code = %RELEASE-CACHE{$key}
        // $RELEASE-LOCK.protect: { %RELEASE-CACHE{$key} //= nativecast(:(Pointer), $fn) };

    $code($addr);
    Nil;
}

sub release-array(Pointer $addr --> Nil)
{
    with shim-release-fn() -> &release {
        note "ARROW DEBUG: shim release" if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
        release($addr);
        return;
    }

    note "ARROW DEBUG: raku release (no shim)" if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
    raku-release($addr);
}

constant ARROW-ARRAY-SIZE = 80;   # 4 x int64 + 6 x pointer

#| The platform C library, which lends us memcpy.  The name is assembled from
#| pieces on purpose: installers (zef, raku-pm) scan the source for
#| `is native('<name>')` literals, collect every name they find as a hard
#| dependency, and then refuse to install on either platform -- Windows for a
#| missing libc, Linux for a missing msvcrt.  Building the constant keeps that
#| scan from inventing dependencies while still resolving at compile time,
#| which `is native(...)` requires.
#|
#| The Linux name carries the version on purpose: NativeCall would turn a bare
#| 'libc' into 'liblibc.so' and fail, while a name with dots is used as given.
my constant CLIB = $*DISTRO.is-win ?? 'msvc' ~ 'rt' !! 'libc' ~ '.so.6';

sub memcpy-clib(Pointer $dst, Pointer $src, size_t $n --> Pointer)
    is native(CLIB) is symbol('memcpy') { }

sub copy-bytes(Pointer $dst, Pointer $src, size_t $n --> Nil)
{
    memcpy-clib($dst, $src, $n);
}

#| One column of an arrow struct array, read through the C data interface.
class Column is export {
    has ArrowArray $!arr;
    has Pointer $!addr;

    submethod BUILD(:$!arr!, :$!addr!) { }

    #| Element count of this child array.
    method length(--> Int)     { $!arr.length.Int }
    #| Number of null slots, straight from the ArrowArray struct.
    method null-count(--> Int) { $!arr.null-count.Int }
    #| Number of nested child arrays (0 for a primitive column).
    method n-children(--> Int) { $!arr.n-children.Int }

    #| Raw buffer pointer, or a null Pointer when the slot is absent
    #| (e.g. the validity buffer of a column without nulls).
    method buffer(int $j --> Pointer)
    {
        my $base = $!arr.buffers;
        return Pointer unless $base.defined && $base.Int;
        return Pointer if $j >= $!arr.n-buffers;
        nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $j))[0] // Pointer;
    }

    #| The child arrays as `Column` objects, in Arrow order.
    method children(--> List)
    {
        my $base = $!arr.children;
        return () unless $base.defined && $base.Int;
        my @kids;
        for ^$!arr.n-children -> int $i {
            my $p = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
            @kids.push: Column.new(arr => nativecast(ArrowArray, $p), addr => $p);
        }
        @kids.List;
    }

    #| Bitmap test; an absent validity buffer means "nothing is null".
    method is-null(int $i --> Bool)
    {
        my $v = self.buffer(0);
        return False unless $v.defined && $v.Int;
        my $byte = nativecast(CArray[uint8], Pointer.new($v.Int + ($i +> 3)))[0];
        ($byte +& (1 +< ($i +& 7))) == 0;
    }

    method !typed(CArray $ca, int $n, &conv)
    {
        my @out;
        @out.push: conv($ca[$_]) for ^$n;
        @out.List;
    }

    #| Buffer 1 as a List of int, for the integer types.
    method ints(--> List)  { self!typed(nativecast(CArray[int64], self.buffer(1)), self.length, -> $v { $v }) }
    #| Buffer 1 as a List of Num, for FLOAT / DOUBLE.
    method nums(--> List)  { self!typed(nativecast(CArray[num64], self.buffer(1)), self.length, -> $v { $v }) }
    #| Buffer 1 as a List of int, for the 32 bit integer types (DATE and
    #| friends), where `ints` would read past the element.
    method int32s(--> List) { self!typed(nativecast(CArray[int32], self.buffer(1)), self.length, -> $v { $v }) }

    #| Bit-packed booleans; bit i of byte (i +> 3).
    method bools(--> List)
    {
        my $v = self.buffer(1);
        return (False xx self.length).List unless $v.defined && $v.Int;
        my $bytes = nativecast(CArray[uint8], $v);
        my int $n = self.length;
        my @out;
        @out.push: (($bytes[$_ +> 3] +& (1 +< ($_ +& 7))) != 0) for ^$n;
        @out.List;
    }

    #| UTF-8 column: buffer 1 holds int32 offsets, buffer 2 the bytes.
    #| The payload is copied once per chunk, then sliced by offset.
    method strs(--> List)
    {
        my int $n = self.length;
        my $offs = nativecast(CArray[int32], self.buffer(1));
        my int $total = $offs[$n];
        my $ca = CArray[uint8].allocate($total + 1);
        copy-bytes(nativecast(Pointer, $ca), self.buffer(2), $total);
        my $buf = Buf.new($ca[^$total]);
        my $all = $buf.decode('utf-8');
        my @out;
        if $all.chars == $total {
            # ASCII: byte and char offsets coincide, slice the decoded string.
            @out.push: $all.substr($offs[$_], $offs[$_ + 1] - $offs[$_]) for ^$n;
        }
        else {
            @out.push: $buf.subbuf($offs[$_], $offs[$_ + 1] - $offs[$_]).decode('utf-8') for ^$n;
        }
        @out.List;
    }
}

#| A whole chunk seen as an Arrow struct array: children are the columns.
class Chunk is export {
    has ArrowArray $!root;
    has Pointer $!addr;
    has $!holder;              # keeps the backing allocation alive
    has Bool $!freed = False;

    submethod BUILD(:$!root!, :$!addr!, :$!holder) { }

    #| Rows in the chunk.
    method length(--> Int) { $!root.length.Int }
    #| Number of columns, i.e. children of the root struct array.
    method columns(--> Int) { $!root.n-children.Int }

    #| Address of the root ArrowArray struct (for low-level callers).
    method addr(--> Pointer) { $!addr }

    #| Column `$i` as a `Column` view; dies when the index is out of range.
    method column(int $i --> Column)
    {
        die "column $i out of range (0..{$!root.n-children - 1})"
            if $i < 0 || $i >= $!root.n-children;
        my $base = $!root.children;
        my $p = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
        Column.new(arr => nativecast(ArrowArray, $p), addr => $p);
    }

    #| Hand the array back to its producer.  Required: native memory is not
    #| garbage collected.  Calling this twice is a no-op -- DuckDB's release
    #| callback does not clear `release-fn`, so the flag is tracked here.
    method free(--> Nil)
    {
        return if $!freed;
        $!freed = True;
        return unless $!root.release-fn.defined && $!root.release-fn.Int;
        release-array($!addr);
        Nil;
    }
}

#| Convert chunk `$idx` of `$result` into an arrow struct array.  The caller
#| owns the result and must call `.free` on the returned object.
our sub arrow-chunk(DB::DuckDB::Result $result, uint64 $idx --> Chunk) is export
{
    my $raw = $result.raw;
    my $chunk = duckdb-result-get-chunk($raw, $idx);
    die "no chunk at index $idx" unless $chunk.defined && $chunk.Bool;

    # The struct has to live in a plain byte buffer: a CArray[ArrowArray]
    # element cannot be handed to native code as a writable out-parameter
    # (DuckDB would write into a temporary, leaving the release pointer unset).
    my $holder = CArray[uint8].allocate(ARROW-ARRAY-SIZE);
    my Pointer $addr = nativecast(Pointer, $holder);
    chunk-to-arrow(result-arrow-options($raw), $chunk, $addr);

    # duckdb_result_get_chunk hands back a chunk that the *caller* owns (the
    # duckdb.h contract says to destroy it), and the Arrow conversion copies
    # the data into Arrow-owned buffers, so the source chunk can go back right
    # away.  Skipping this leaks one chunk per call: measured 235 KB per
    # 2048-row chunk, i.e. ~23 MB per 200k-row result.
    duckdb-destroy-data-chunk($chunk);

    my $root = nativecast(ArrowArray, $addr);
    die "arrow conversion failed at chunk $idx"
        unless $root.release-fn.defined && $root.release-fn.Int;

    Chunk.new(root => $root, addr => $addr, holder => $holder);
}

#| Every chunk of `$result` as an arrow struct array, handed to `&code` and
#| released afterwards.
our sub with-arrow-chunks(DB::DuckDB::Result $result, &code --> Nil) is export
{
    my uint64 $n = duckdb-result-chunk-count($result.raw);
    for ^$n -> uint64 $ci {
        my $chunk = arrow-chunk($result, $ci);
        LEAVE $chunk.free;
        code($chunk, $ci);
    }
    Nil;
}
