#| Locate -- and if necessary compile -- the ArrowArray release shim described
#| in resources/duckdb-arrow-shim.c.
#|
#| The shim exists because the release callback inside an ArrowArray is only
#| known at run time, so calling it from Raku means invoking a raw function
#| pointer through NativeCall.  That is measurably lossy: a 30_000 iteration
#| convert/release loop grew the process by ~540 MB when the callback was
#| called from Raku, and stayed flat when the very same loop went through the
#| shim.  A wrong pointer here also corrupts the allocator instead of failing
#| cleanly, which is what crashed earlier attempts on Windows.
#|
#| The C file is self contained: no duckdb.h, no linking against libduckdb,
#| only the Arrow C data interface layout.  Failure is always soft -- when no
#| compiler is available Arrow.rakumod falls back to the in-Raku callback.
unit module DB::DuckDB::ArrowShim;

my Str  $lib-path;
my Bool $probed = False;

sub native-ext(--> Str)
{
    return '.dll' if $*DISTRO.is-win;
    $*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so';
}

sub shim-source(--> IO::Path)
{
    my $from-res = quietly { %?RESOURCES<duckdb-arrow-shim.c> };
    return $from-res.IO if $from-res.defined && $from-res.IO.e;

    # lib/DB/DuckDB/ArrowShim.rakumod -> <root>/resources/...
    my $local = $?FILE.IO.parent.parent.parent.parent
                    .child('resources/duckdb-arrow-shim.c');
    $local.e ?? $local !! IO::Path;
}

sub cache-dir(--> IO::Path)
{
    %*ENV<DB_DUCKDB_SHIM_CACHE>
        ?? %*ENV<DB_DUCKDB_SHIM_CACHE>.IO
        !! $*HOME.IO.add('.local/share/DB-DuckDB');
}

sub shim-target(--> IO::Path) { cache-dir.add('libduckdb-arrow-shim' ~ native-ext()) }
sub abi-stamp(--> IO::Path)   { cache-dir.add('libduckdb-arrow-shim.abi') }

#| ABI of the entry points this driver expects; bumped together with
#| DKD_ARROW_SHIM_ABI in the C file.
our constant SHIM-ABI = 1;

sub compiler-candidates(--> List)
{
    my @c;
    @c.push: %*ENV<DB_DUCKDB_CC> if %*ENV<DB_DUCKDB_CC>;
    @c.push: %*ENV<CC>           if %*ENV<CC>;
    @c.append: 'cc', 'gcc', 'clang';

    if $*DISTRO.is-win {
        @c.append: |<
            C:/msys64/mingw64/bin/gcc.exe
            C:/msys64/ucrt64/bin/gcc.exe
            C:/msys64/clang64/bin/clang.exe
            C:/Strawberry/c/bin/gcc.exe
            C:/TDM-GCC-64/bin/gcc.exe
            C:/mingw64/bin/gcc.exe
            C:/rakudo/share/llvm-mingw/bin/gcc.exe
        >;
        for <C D E>.map({ $_ ~ ':/' }) -> $root {
            next unless $root.IO.d;
            my @dirs = quietly { dir($root).grep({ .d && .basename.starts-with('llvm-mingw') }) };
            for @dirs -> $d {
                my $g = $d.add('bin/gcc.exe');
                @c.push: $g.absolute if $g.e;
            }
        }
    }
    @c.cache;
}

sub build-shim(--> IO::Path)
{
    my $src = shim-source();
    return IO::Path unless $src.defined;

    my $out = shim-target();
    my $stamp = abi-stamp();

    if $out.e && $stamp.e {
        my $built = try { $stamp.slurp.trim } // '';
        return $out if $built eq SHIM-ABI.Str;
    }

    $out.parent.mkdir unless $out.parent.e;

    my @flags = $*DISTRO.is-win
        ?? ('-O2', '-shared')
        !! ('-fPIC', '-O2', '-shared');

    for compiler-candidates() -> $cc {
        my @cmd = $cc, |@flags, '-o', $out.absolute, $src.absolute;
        my $ok = try {
            my $proc = run(|@cmd, :out, :err);
            my $err-text = $proc.err.slurp(:close);
            $proc.out.slurp(:close);
            note "DB::DuckDB::ArrowShim: $cc exited {$proc.exitcode}:\n$err-text"
                if $proc.exitcode != 0 && $err-text.chars;
            $proc.exitcode == 0;
        } // False;

        if $ok && $out.e {
            try { $stamp.spurt: SHIM-ABI.Str ~ "\n" }
            return $out;
        }
    }

    note "DB::DuckDB::ArrowShim: no working C compiler found; ArrowArray "
      ~ "release falls back to the in-Raku callback.  Set DB_DUCKDB_CC to "
      ~ "pick one.";
    IO::Path;
}

#| Absolute path of the compiled shim, or an empty string when unavailable.
#| Resolution happens once per process.
our sub shim-lib(--> Str) is export
{
    return $lib-path if $probed;
    $probed = True;

    if %*ENV<DB_DUCKDB_ARROW_SHIM> -> $explicit {
        return $lib-path = $explicit
            if $explicit.chars && $explicit.IO.e;
    }

    my $out = build-shim();
    $lib-path = $out.defined && $out.e ?? $out.absolute !! '';
}
