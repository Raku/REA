use DB::Connection;
use DB::DuckDB::Native;
use DB::DuckDB::Error;
use DB::DuckDB::Statement;
use DB::DuckDB::Decoder;

class DB::DuckDB::Connection does DB::Connection
{
    has DuckDB-Database   $.database is required;
    has DuckDB-Connection $.handle   is required;

    has Bool $!closed = False;

    submethod TWEAK(--> Nil)
    {
        try self.sync-time-zone-offset;
    }

    #| TIMESTAMP_TZ arrives from the C API as plain UTC microseconds; the
    #| session time zone offset is what DuckDB adds back when it renders the
    #| value as text.  The offset is seeded here and refreshed whenever the
    #| session runs `SET TimeZone`.
    method sync-time-zone-offset(--> Nil)
    {
        return if $!closed;
        return unless $!handle.Bool;

        my DuckDB-Raw-Result $raw .= new;
        my $rc = duckdb-query(
            $!handle,
            q{select strftime(TIMESTAMPTZ '1970-01-01 00:00:00+00', '%z')},
            $raw,
        );
        return if $rc != DuckDBSuccess || !$raw.Bool;

        my $text = '';
        if !duckdb-value-is-null($raw, 0, 0) {
            $text = take-cstr-free(duckdb-value-varchar($raw, 0, 0)) // '';
        }
        duckdb-destroy-result($raw);

        return unless $text.chars > 1;

        # Formats seen in the wild: "+08", "+0800", "+08:00".
        my $sign = $text.substr(0, 1) eq '-' ?? -1 !! 1;
        my @digits = $text.substr(1).split(/<[:\s}]>/, :skip-empty);
        return unless @digits;

        my Int $hours = @digits[0].Int;
        my Int $mins  = (@digits[1] // 0).Int;
        $DB::DuckDB::Decoder::TIMESTAMP-TZ-OFFSET = $sign * ($hours * 3600 + $mins * 60);
    }

    method ping(--> Bool)
    {
        !$!closed && so $!handle.Bool;
    }

    method free(--> Nil)
    {
        return if $!closed;
        $!closed = True;

        # The database instance is owned by the driver and shared by every
        # connection, so only the connection handle is released here.
        duckdb-disconnect($!handle) if $!handle.Bool;
    }

    method prepare-nocache(Str:D $query --> DB::DuckDB::Statement)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        my DuckDB-Prepared $ps .= new;
        my $rc = duckdb-prepare($!handle, $query, $ps);

        if $rc != DuckDBSuccess {
            my $msg = take-cstr(duckdb-prepare-error($ps));
            duckdb-destroy-prepare($ps) if $ps.Bool;
            die DB::DuckDB::Error.new(
                :code($rc),
                message => ($msg.chars ?? $msg !! "cannot prepare statement: $query"),
            );
        }

        DB::DuckDB::Statement.new(:db(self), :stmt($ps));
    }

    #| `DB.query` hands its connection straight back without returning it to
    #| the pool, so the connection travels with the result: it is released
    #| only after the rows have been drained.
    method query(Str:D $query, Bool :$finish, Bool :$nocache, *@args, *%args)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        my $res = $.prepare($query, :$nocache).execute(|@args, |%args, :finish(False));

        if $res ~~ DB::DuckDB::Result {
            $res.attach-connection(self) if $finish;
            return $res;
        }

        $.finish if $finish;
        $res;
    }

    #| `DB`'s execute() contract is "how many rows were affected", while
    #| `DB::Connection.execute` would hand back a result set for statements
    #| like CREATE TABLE (DuckDB returns a one-column count for DDL).  So
    #| anything with a result set is drained and reduced to its row count.
    method execute(Str:D $command, Bool :$finish, *@args, *%args --> Int)
    {
        die DB::DuckDB::Error.new(message => 'connection is closed') if $!closed;

        # Statements without bind parameters go straight through duckdb_query.
        # Going via a prepared statement silently drops session settings such
        # as `SET TimeZone` in 2.0 (the setting is applied while preparing and
        # then thrown away), so SET / PRAGMA / ATTACH have to take this path.
        if !@args.elems && !%args.keys {
            my DuckDB-Raw-Result $raw .= new;
            my $rc = duckdb-query($!handle, $command, $raw);
            if $rc != DuckDBSuccess {
                my $msg = take-cstr(duckdb-result-error($raw));
                duckdb-destroy-result($raw);
                die DB::DuckDB::Error.new(
                    :code($rc),
                    message => ($msg.chars ?? $msg !! "execution failed: $command"),
                );
            }
            my $changed = duckdb-rows-changed($raw).Int;
            duckdb-destroy-result($raw);

            # Rendering of TIMESTAMP_TZ depends on the session zone, so the
            # cached offset has to follow any change to it.
            self.sync-time-zone-offset
                if $command ~~ m:i/^\s*SET\s+(TimeZone|Time\s*Zone|TZ)/;

            return $changed;
        }

        my $res = $.prepare($command).execute(|@args, |%args, :finish(False));

        if $res ~~ DB::DuckDB::Result {
            my $changed = $res.rows-changed;
            $res.free;
            return $changed;
        }

        $res.Int;
    }
}
