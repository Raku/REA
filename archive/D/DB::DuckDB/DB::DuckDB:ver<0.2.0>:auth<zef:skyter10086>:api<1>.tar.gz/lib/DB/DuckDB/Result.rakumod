use DB::Result;
use DB::DuckDB::Native;
use DB::DuckDB::Decoder;
use NativeCall;

class DB::DuckDB::Result does DB::Result
{
    has DuckDB-Raw-Result $.raw is required;
    has Int $.count;
    has Int $.columns;
    has Int $.rows-changed;

    has Int  $!cursor = 0;
    has Bool $!alive  = True;

    # Set when the result borrows a pooled connection that must be handed
    # back to the driver once the result is drained.
    has $!borrowed-conn;

    # --- chunk/vector state ---------------------------------------------
    has DuckDB-Data-Chunk $!chunk;
    has @!decoders;           # one Callable per column
    has @!column-types;       # duckdb_type ids, for introspection
    has uint64 $!chunk-size = 0;
    has uint64 $!chunk-pos  = 0;
    has Bool $!chunk-done = False;

    method attach-connection($conn --> Nil) { $!borrowed-conn = $conn }

    submethod BUILD(DuckDB-Raw-Result :$raw!,
                    :$sth,
                    Bool :$finish,
                    Int :$count)
    {
        $!raw     = $raw;
        $!sth     = $sth;
        $!finish  = $finish;
        $!count   = $count // duckdb-row-count($!raw).Int;
        $!columns = duckdb-column-count($!raw).Int;
        $!rows-changed = duckdb-rows-changed($!raw).Int;

        @!column-types = (duckdb-column-type($!raw, $_) for ^$!columns).List;
    }

    method names()
    {
        return () unless $!alive;
        my @names = do for ^$!columns -> $col {
            take-cstr(duckdb-column-name($!raw, $col))
        };
        @names.List;
    }

    #| Raw duckdb_type ids, one per column.
    method column-types(--> List) { @!column-types.List }

    #| Pull the next non-empty chunk and rebuild the per-column readers.
    method !next-chunk(--> Bool)
    {
        return False if $!chunk-done;

        duckdb-destroy-data-chunk($!chunk)
            if $!chunk.defined && $!chunk.Bool;
        $!chunk = DuckDB-Data-Chunk;

        my $next = duckdb-fetch-chunk($!raw);

        unless $next.defined && $next.Bool {
            $!chunk-done = True;
            $!chunk-size = 0;
            $!chunk-pos  = 0;
            @!decoders   = ();
            return False;
        }

        $!chunk      = $next;
        $!chunk-size = duckdb-data-chunk-get-size($!chunk);
        $!chunk-pos  = 0;

        @!decoders = ();
        for ^$!columns -> $col {
            my $vec = duckdb-data-chunk-get-vector($!chunk, $col);
            # The vector owns its logical type: duckdb_vector_get_column_type
            # returns a copy that we must destroy ourselves.
            my $lt = duckdb-vector-get-column-type($vec);
            @!decoders.push: build-decoder($vec, $lt);
            duckdb-destroy-logical-type($lt);
        }

        # DuckDB may hand out an empty chunk mid-stream; skip it.
        $!chunk-size > 0 || self!next-chunk;
    }

    method row()
    {
        return () unless $!alive;
        return () if $!columns == 0;
        return () if $!cursor >= $!count;

        while $!chunk-pos >= $!chunk-size {
            return () unless self!next-chunk;
        }

        my uint64 $pos = $!chunk-pos;

        my @row;
        for ^$!columns -> $col {
            @row.push: @!decoders[$col]($pos);
        }

        $!chunk-pos++;
        $!cursor++;
        @row;
    }

    method free(--> Nil)
    {
        return unless $!alive;
        $!alive = False;

        duckdb-destroy-data-chunk($!chunk)
            if $!chunk.defined && $!chunk.Bool;
        $!chunk = DuckDB-Data-Chunk;

        duckdb-destroy-result($!raw);

        # `DB` always asks for `:finish` on `query` / `execute`, meaning the
        # statement must not stay cached once its result is drained.
        $!sth.finish if $!finish && $!sth.defined;

        if $!borrowed-conn.defined {
            my $conn = $!borrowed-conn;
            $!borrowed-conn = Nil;
            $conn.finish;
        }
    }

    submethod DESTROY() { self.free }
}
