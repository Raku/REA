use DB::DuckDB::Native;
use NativeCall;

# The module name has to be spelled out: without it Raku wraps the file in an
# implicit package, and module-level state such as $TIMESTAMP-TZ-OFFSET ends
# up in a package nobody else can reach.
unit module DB::DuckDB::Decoder;

#========================================================================
# Value decoding for the 2.0 chunk/vector read path.
#
# DuckDB 2.0 added a fair number of value types (BIGNUM, VARIANT, GEOMETRY,
# TIMESTAMP_TZ_NS, ...) and -- more importantly -- the deprecated
# `duckdb_value_varchar` renderer no longer produces text for several types
# that 1.x used to render (UUID, LIST, MAP, TIME WITH TIME ZONE, ...).
# Everything therefore has to be decoded straight out of the vectors.
#
# A decoder is a `Callable` taking a row index and returning the value:
#   * scalars            -> native Raku types (Bool/Int/Num/Str)
#   * everything else    -> Str, rendered exactly like DuckDB's own
#                           `CAST(x AS VARCHAR)`, so callers see the same
#                           text they would get from the SQL shell.
#========================================================================

# NOTE (DuckDB 2.0 port): reading a `CArray[CStruct]` element ({...} = $arr[0])
# faults inside MoarVM on Windows, and the C structs DuckDB stores inline in a
# vector are plain scalar pairs anyway. Every struct is therefore dissected
# field-by-field through uint32/uint64 views of the vector data pointer.

#| Signed 32-bit field at word index $i of a uint32 view.
sub i32-at(CArray[uint32] $a, Int $i --> Int) is export {
    my UInt $v = $a[$i].UInt;
    $v >= 2147483648 ?? ($v.Int - 4294967296) !! $v.Int;
}

#| Signed 64-bit field at word index $i of a uint64 view.
sub i64-at(CArray[uint64] $a, Int $i --> Int) is export {
    my UInt $v = $a[$i].UInt;
    $v >= 9223372036854775808 ?? ($v.Int - 18446744073709551616) !! $v.Int;
}

#------------------------------------------------------------------------
# small helpers
#------------------------------------------------------------------------

#| Floored division: Raku's `div` truncates, which breaks pre-1970 epochs.
my sub floor-div(Int $a, Int $b --> Int) {
    ($a - $a % $b) div $b;
}

my sub date-text(Int $days --> Str) {
    Date.new(1970, 1, 1).later(days => $days).Str;
}

#| Fractional-second suffix the way DuckDB prints it: zero-padded to the
#| type's precision, then stripped of trailing zeros (and of the dot).
my sub frac-text(Int $frac, Int $digits --> Str) {
    return '' unless $frac;
    # NB: "%0{$digits}d" would be read as a hash subscript (%0{...}).
    my $s = sprintf('%0*d', $digits, $frac);
    $s = $s.subst(/0+$/, '');
    $s eq '' ?? '' !! '.' ~ $s;
}

my sub time-text(Int $micros, Int $unit = 1_000_000 --> Str) {
    # $unit is how many sub-units make a second (1e6 for us, 1e9 for ns).
    my Int $total = $micros;
    my Int $neg   = $total < 0;
    my Int $abs   = $total.abs;
    my Int $per-sec = $unit;
    my Int $h = $abs div ($per-sec * 3600);
    my Int $m = ($abs div ($per-sec * 60)) % 60;
    my Int $s = ($abs div $per-sec) % 60;
    my Int $frac = $abs % $per-sec;
    sprintf('%s%02d:%02d:%02d', ($neg ?? '-' !! ''), $h, $m, $s)
        ~ frac-text($frac, $unit == 1_000_000 ?? 6 !! 9);
}

my sub timestamp-text(Int $micros --> Str) {
    my Int $secs = floor-div($micros, 1_000_000);
    my Int $us   = $micros % 1_000_000;
    my $dt = DateTime.new($secs, timezone => 0);
    sprintf('%04d-%02d-%02d %02d:%02d:%02d',
            $dt.year, $dt.month, $dt.day,
            $dt.hour, $dt.minute, $dt.second) ~ frac-text($us, 6);
}

my sub timestamp-ns-text(Int $nanos --> Str) {
    my Int $secs = floor-div($nanos, 1_000_000_000);
    my Int $ns   = $nanos % 1_000_000_000;
    my $dt = DateTime.new($secs, timezone => 0);
    sprintf('%04d-%02d-%02d %02d:%02d:%02d',
            $dt.year, $dt.month, $dt.day,
            $dt.hour, $dt.minute, $dt.second) ~ frac-text($ns, 9);
}

#| 128-bit value assembled from the two 64-bit halves of a hugeint.
#| The high half is a two's-complement int64 kept in a uint64 slot.
my sub int128(uint64 $lower, uint64 $upper --> Int) {
    my Int $high = $upper >= (2 ** 63) ?? $upper - (2 ** 64) !! $upper;
    $high * (2 ** 64) + $lower;
}

my sub uint128(uint64 $lower, uint64 $upper --> Int) {
    $upper * (2 ** 64) + $lower;
}

my sub decimal-text(Int $value, Int $scale --> Str) {
    my $neg = $value < 0;
    my $digits = $value.abs.Str;
    if $scale > 0 {
        $digits = ('0' x (($scale + 1) - $digits.chars)) ~ $digits
            if $digits.chars <= $scale;
        my $cut = $digits.chars - $scale;
        $digits = $digits.substr(0, $cut) ~ '.' ~ $digits.substr($cut);
    }
    ($neg ?? '-' !! '') ~ $digits;
}

#| UUIDs are stored as a signed 128-bit value (so ordering matches text), which
#| means the high byte has its sign bit flipped. Read the 16 bytes directly:
#| byte-wise parsing avoids the sign games that `sprintf '%x'` plays on Ints.
my sub uuid-text(Pointer $data, uint64 $row --> Str) {
    my CArray[uint8] $b = nativecast(CArray[uint8], $data);
    my uint64 $base = $row * 16;
    my @lo = (^8).map({ $b[$base + $_].Int }).reverse;
    my @hi = (^8).map({ $b[$base + 8 + $_].Int }).reverse;
    @hi[0] = @hi[0] +^ 0x80;
    my $hex = (@hi, @lo).flat.map({ sprintf('%02x', $_) }).join;
    sprintf('%s-%s-%s-%s-%s',
            $hex.substr(0, 8), $hex.substr(8, 4), $hex.substr(12, 4),
            $hex.substr(16, 4), $hex.substr(20, 12));
}

my sub interval-text(int32 $months, int32 $days, int64 $micros --> Str) {
    my @parts;
    my $years  = $months div 12;
    my $mons   = $months % 12;
    my sub unit(Int $n, Str $one, Str $many --> Str) { $n.abs == 1 ?? "$n $one" !! "$n $many" }
    @parts.push(unit($years, 'year', 'years')) if $years;
    @parts.push(unit($mons, 'month', 'months')) if $mons;
    @parts.push(unit($days, 'day', 'days')) if $days;
    my $neg = $micros < 0;
    my $abs = $micros.abs;
    if $abs {
        my $h = $abs div 3_600_000_000;
        my $m = ($abs div 60_000_000) % 60;
        my $s = ($abs div 1_000_000) % 60;
        my $us = $abs % 1_000_000;
        my $t = sprintf('%s%02d:%02d:%02d', ($neg ?? '-' !! ''), $h, $m, $s);
        $t ~= frac-text($us, 6);
        @parts.push($t);
    }
    return '00:00:00' unless @parts;
    @parts.join(' ');
}

#| Offset (seconds) that DuckDB applies when it renders TIMESTAMP_TZ values.
#| The C API hands us plain UTC microseconds, so rendering the way DuckDB's
#| own text conversion does requires adding the session time zone offset.
#| Session time zones can shift with DST; the value is seeded from the
#| session's offset at the epoch, which is exact for fixed-offset zones
#| (including the default Asia/Shanghai) and best-effort elsewhere.
our Int $TIMESTAMP-TZ-OFFSET is export = 0;

#| 24-bit signed offset used by duckdb_time_tz / timestamptz rendering.
my sub render-with-offset(Str $text, Int $offset-seconds --> Str) {
    my $sign = $offset-seconds < 0 ?? '-' !! '+';
    my $abs  = $offset-seconds.abs;
    my $mins = ($abs div 60) % 60;
    my $zone = sprintf('%02d', $abs div 3600)
             ~ ($mins ?? sprintf(':%02d', $mins) !! '');
    $text ~ $sign ~ $zone;
}

my sub read-blob-buf(Pointer $data, uint64 $row --> Buf) {
    my CArray[uint8] $bytes = nativecast(CArray[uint8], $data);
    my uint64 $base = $row * 16;
    my uint32 $len = $bytes[$base]
                   + ($bytes[$base + 1] +< 8)
                   + ($bytes[$base + 2] +< 16)
                   + ($bytes[$base + 3] +< 24);
    my Buf $buf .= new;
    if $len <= 12 {
        $buf.push($bytes[$base + 4 + $_]) for ^$len;
    }
    else {
        my uint64 $addr = 0;
        $addr = $addr + ($bytes[$base + 8 + $_] +< (8 * $_)) for ^8;
        my CArray[uint8] $chars = nativecast(CArray[uint8], Pointer.new($addr));
        $buf.push($chars[$_]) for ^$len;
    }
    $buf;
}

#| DuckDB renders BLOB as text by keeping printable ASCII bytes verbatim and
#| escaping everything else as `\xHH` -- exactly what `CAST(blob AS VARCHAR)`
#| produces.
my sub blob-text(Buf $buf --> Str) {
    my $out = '';
    for $buf.list -> $b {
        my Int $c = $b.Int;
        $out ~= ($c >= 0x20 && $c <= 0x7E) ?? chr($c) !! '\\x' ~ sprintf('%02X', $c);
    }
    $out;
}

#| Decode the inline BIGNUM payload described at its decoder.
my sub bignum-text(Buf $raw --> Str) {
    my @b = $raw.list;
    return '0' unless @b;
    my Bool $neg = @b[0] != 0x80;
    @b = @b.map({ 0xFF - $_.Int }) if $neg;
    my Int $len = @b[1] * 256 + @b[2];
    my Int $avail = @b.elems - 3;
    $len = $avail if $len > $avail;
    return '0' if $len <= 0;
    my $hex = @b[3 .. 3 + $len - 1].map({ sprintf('%02x', $_) }).join;
    my $mag = $hex.chars ?? $hex.parse-base(16) !! 0;
    ($neg && $mag ?? '-' !! '') ~ $mag.Str;
}

#| Text form used when a nested value has to be embedded in a container.
my sub nested-text($value --> Str) {
    return 'NULL' if !$value.defined;
    return $value ?? 'true' !! 'false' if $value ~~ Bool;
    $value ~~ Str ?? $value !! $value.Str;
}

#------------------------------------------------------------------------
# decoder construction
#------------------------------------------------------------------------

#| Build a reader for one vector.  Returns a Callable: (uint64 $row) --> Mu.
sub build-decoder(DuckDB-Vector $vector, DuckDB-Logical-Type $type is copy --> Callable) is export
{
    my int32 $id = duckdb-get-type-id($type);

    my Pointer $data     = duckdb-vector-get-data($vector);
    my Pointer $validity = duckdb-vector-get-validity($vector);

    # ---- NULL handling wrapper -------------------------------------
    my &finish = sub ($reader) {
        sub (uint64 $row) {
            return Any unless row-valid($validity, $row);
            $reader($row);
        }
    };

    # ---- scalars ---------------------------------------------------
    if $id == DUCKDB_TYPE_BOOLEAN {
        my CArray[uint8] $a = nativecast(CArray[uint8], $data);
        return finish(sub (uint64 $r) { so $a[$r] });
    }
    if $id == DUCKDB_TYPE_TINYINT {
        my CArray[int8] $a = nativecast(CArray[int8], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_UTINYINT {
        my CArray[uint8] $a = nativecast(CArray[uint8], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_SMALLINT {
        my CArray[int16] $a = nativecast(CArray[int16], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_USMALLINT {
        my CArray[uint16] $a = nativecast(CArray[uint16], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_INTEGER {
        my CArray[int32] $a = nativecast(CArray[int32], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_UINTEGER {
        my CArray[uint32] $a = nativecast(CArray[uint32], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_BIGINT {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_UBIGINT {
        my CArray[uint64] $a = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) { $a[$r].Int });
    }
    if $id == DUCKDB_TYPE_FLOAT {
        my CArray[num32] $a = nativecast(CArray[num32], $data);
        return finish(sub (uint64 $r) { $a[$r].Num });
    }
    if $id == DUCKDB_TYPE_DOUBLE {
        my CArray[num64] $a = nativecast(CArray[num64], $data);
        return finish(sub (uint64 $r) { $a[$r].Num });
    }
    if $id == DUCKDB_TYPE_VARCHAR {
        return finish(sub (uint64 $r) { read-string-t($data, $r) });
    }
    if $id == DUCKDB_TYPE_BLOB {
        return finish(sub (uint64 $r) { blob-text(read-blob-buf($data, $r)) });
    }

    # ---- 128-bit integers -----------------------------------------
    if $id == DUCKDB_TYPE_HUGEINT {
        my CArray[uint64] $a = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) {
            int128($a[$r * 2], $a[$r * 2 + 1]).Str
        });
    }
    if $id == DUCKDB_TYPE_UHUGEINT {
        my CArray[uint64] $a = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) { uint128($a[$r * 2], $a[$r * 2 + 1]).Str });
    }

    # ---- decimals --------------------------------------------------
    if $id == DUCKDB_TYPE_DECIMAL {
        my int32 $internal = duckdb-decimal-internal-type($type);
        my Int $scale = duckdb-decimal-scale($type);
        if $internal == DUCKDB_TYPE_SMALLINT {
            my CArray[int16] $a = nativecast(CArray[int16], $data);
            return finish(sub (uint64 $r) { decimal-text($a[$r].Int, $scale) });
        }
        if $internal == DUCKDB_TYPE_INTEGER {
            my CArray[int32] $a = nativecast(CArray[int32], $data);
            return finish(sub (uint64 $r) { decimal-text($a[$r].Int, $scale) });
        }
        if $internal == DUCKDB_TYPE_BIGINT {
            my CArray[int64] $a = nativecast(CArray[int64], $data);
            return finish(sub (uint64 $r) { decimal-text($a[$r].Int, $scale) });
        }
        my CArray[uint64] $a = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) {
            decimal-text(int128($a[$r * 2], $a[$r * 2 + 1]), $scale)
        });
    }

    # ---- date / time / timestamp ----------------------------------
    if $id == DUCKDB_TYPE_DATE {
        my CArray[int32] $a = nativecast(CArray[int32], $data);
        return finish(sub (uint64 $r) { date-text($a[$r].Int) });
    }
    if $id == DUCKDB_TYPE_TIME {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        return finish(sub (uint64 $r) { time-text($a[$r].Int) });
    }
    if $id == DUCKDB_TYPE_TIME_NS {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        return finish(sub (uint64 $r) { time-text($a[$r].Int, 1_000_000_000) });
    }
    if $id == DUCKDB_TYPE_TIME_TZ {
        # 2.0 packs a TIME WITH TIME ZONE into one uint64:
        #   bits 24..63 = microseconds since midnight
        #   bits  0..23 = 57599 - offset-seconds   (so larger offsets sort first)
        # Measured against TIMETZ values from -12:00 to +14:00.
        my CArray[uint64] $a = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) {
            my uint64 $bits = $a[$r];
            my Int $micros = ($bits +> 24).Int;
            my Int $offset = 57599 - ($bits +& 0xFFFFFF).Int;
            render-with-offset(time-text($micros), $offset);
        });
    }
    if $id == DUCKDB_TYPE_TIMESTAMP {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        return finish(sub (uint64 $r) { timestamp-text($a[$r].Int) });
    }
    if $id == DUCKDB_TYPE_TIMESTAMP_TZ {
        # The vector holds UTC microseconds.  DuckDB renders the value in the
        # session zone, i.e. it shifts the instant first and only then names
        # the offset -- printing the UTC clock with a "+08" suffix would be a
        # different (and wrong) point in time.
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        my Int $off = $TIMESTAMP-TZ-OFFSET;
        return finish(sub (uint64 $r) {
            render-with-offset(timestamp-text($a[$r].Int + $off * 1_000_000), $off)
        });
    }
    if $id == DUCKDB_TYPE_TIMESTAMP_S {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        return finish(sub (uint64 $r) { timestamp-text($a[$r] * 1_000_000) });
    }
    if $id == DUCKDB_TYPE_TIMESTAMP_MS {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        return finish(sub (uint64 $r) { timestamp-text($a[$r] * 1_000) });
    }
    if $id == DUCKDB_TYPE_TIMESTAMP_NS {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        return finish(sub (uint64 $r) { timestamp-ns-text($a[$r].Int) });
    }
    if $id == DUCKDB_TYPE_TIMESTAMP_TZ_NS {
        my CArray[int64] $a = nativecast(CArray[int64], $data);
        my Int $off = $TIMESTAMP-TZ-OFFSET;
        return finish(sub (uint64 $r) {
            render-with-offset(timestamp-ns-text($a[$r].Int + $off * 1_000_000_000), $off)
        });
    }

    # ---- uuid ------------------------------------------------------
    if $id == DUCKDB_TYPE_UUID {
        # DuckDB keeps UUIDs as a hugeint so they sort correctly, which means
        # the top bit of the high half is flipped on the way in.
        return finish(sub (uint64 $r) { uuid-text($data, $r) });
    }

    # ---- interval --------------------------------------------------
    if $id == DUCKDB_TYPE_INTERVAL {
        # interval_t { int32 months; int32 days; int64 micros; } -> 16 bytes
        my $u32 = nativecast(CArray[uint32], $data);
        my $u64 = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) {
            interval-text(i32-at($u32, $r * 4), i32-at($u32, $r * 4 + 1),
                          i64-at($u64, $r * 2 + 1));
        });
    }

    # ---- enum ------------------------------------------------------
    if $id == DUCKDB_TYPE_ENUM {
        my Int $size = duckdb-enum-dictionary-size($type);
        my @dict = (0 ..^ $size).map({
            take-cstr-free(duckdb-enum-dictionary-value($type, $_))
        }).List;
        # DuckDB stores the dictionary index in the narrowest integer that
        # can address the whole dictionary.
        if $size <= 256 {
            my CArray[uint8] $a = nativecast(CArray[uint8], $data);
            return finish(sub (uint64 $r) { @dict[$a[$r]] // '' });
        }
        if $size <= 65536 {
            my CArray[uint16] $a = nativecast(CArray[uint16], $data);
            return finish(sub (uint64 $r) { @dict[$a[$r]] // '' });
        }
        my CArray[uint32] $a = nativecast(CArray[uint32], $data);
        return finish(sub (uint64 $r) { @dict[$a[$r]] // '' });
    }

    # ---- nesting: list / array -------------------------------------
    if $id == DUCKDB_TYPE_LIST {
        my $child-type = duckdb-list-type-child-type($type);
        my $child-vec  = duckdb-list-vector-get-child($vector);
        my &child = build-decoder($child-vec, $child-type);
        duckdb-destroy-logical-type($child-type);
        my $u64 = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) {
            my UInt $offset = $u64[$r * 2].UInt;
            my UInt $length = $u64[$r * 2 + 1].UInt;
            my @items = (&child($offset + $_) for ^$length);
            '[' ~ @items.map({ nested-text($_) }).join(', ') ~ ']';
        });
    }
    if $id == DUCKDB_TYPE_ARRAY {
        my $child-type = duckdb-array-type-child-type($type);
        my Int $count   = duckdb-array-type-array-size($type);
        my $child-vec   = duckdb-array-vector-get-child($vector);
        my &child = build-decoder($child-vec, $child-type);
        duckdb-destroy-logical-type($child-type);
        return finish(sub (uint64 $r) {
            my @items = (&child($r * $count + $_) for ^$count);
            '[' ~ @items.map({ nested-text($_) }).join(', ') ~ ']';
        });
    }

    # ---- nesting: struct -------------------------------------------
    if $id == DUCKDB_TYPE_STRUCT {
        my Int $count = duckdb-struct-type-child-count($type);
        my @names;
        my @children;
        for ^$count -> $i {
            my $child-type = duckdb-struct-type-child-type($type, $i);
            my $child-vec  = duckdb-struct-vector-get-child($vector, $i);
            @names.push: take-cstr-free(duckdb-struct-type-child-name($type, $i));
            @children.push: build-decoder($child-vec, $child-type);
            duckdb-destroy-logical-type($child-type);
        }
        my Bool $anonymous = !@names.first({ ($_ // '').chars });
        return finish(sub (uint64 $r) {
            my @vals = (^$count).map({ nested-text(@children[$_]($r)) });
            # DuckDB renders an unnamed ROW(...) as "(a, b)" and a named
            # struct as "{'a': 1, 'b': 2}".
            return '(' ~ @vals.join(', ') ~ ')' if $anonymous;
            my @parts = (^$count).map({ "'" ~ @names[$_] ~ "': " ~ @vals[$_] });
            '{' ~ @parts.join(', ') ~ '}';
        });
    }

    # ---- nesting: map ----------------------------------------------
    if $id == DUCKDB_TYPE_MAP {
        my $key-type   = duckdb-map-type-key-type($type);
        my $value-type = duckdb-map-type-value-type($type);
        my $child-vec  = duckdb-list-vector-get-child($vector);
        my $key-vec    = duckdb-struct-vector-get-child($child-vec, 0);
        my $val-vec    = duckdb-struct-vector-get-child($child-vec, 1);
        my &key-read   = build-decoder($key-vec, $key-type);
        my &val-read   = build-decoder($val-vec, $value-type);
        duckdb-destroy-logical-type($key-type);
        duckdb-destroy-logical-type($value-type);
        my $u64 = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) {
            my UInt $offset = $u64[$r * 2].UInt;
            my UInt $length = $u64[$r * 2 + 1].UInt;
            my @parts;
            for ^$length -> $i {
                my $k = &key-read($offset + $i);
                my $v = &val-read($offset + $i);
                @parts.push(nested-text($k) ~ '=' ~ nested-text($v));
            }
            '{' ~ @parts.join(', ') ~ '}';
        });
    }

    # ---- bignum ----------------------------------------------------
    if $id == DUCKDB_TYPE_BIGNUM {
        # 2.0 keeps a BIGNUM inline as a string_t whose bytes are
        #   [1 byte sign][2 byte big-endian length][length bytes magnitude]
        # with sign = 0x80 for non-negative values; a negative value is the
        # whole buffer bitwise-complemented (so memcmp ordering matches).
        # `CAST(x AS VARCHAR)` is the only public renderer -- the deprecated
        # value API returns NULL for the type.
        return finish(sub (uint64 $r) { bignum-text(read-string-t-bytes($data, $r)) });
    }

    # ---- bit string ------------------------------------------------
    if $id == DUCKDB_TYPE_BIT {
        my $u64 = nativecast(CArray[uint64], $data);
        return finish(sub (uint64 $r) {
            my UInt $ptr  = $u64[$r * 2].UInt;
            my UInt $size = $u64[$r * 2 + 1].UInt;
            return '' unless $size && $ptr;
            my $bytes = nativecast(CArray[uint8], Pointer.new($ptr));
            my @bits;
            my Int $total = $size.Int;
            for ^$total -> $i {
                my $byte = $bytes[$i div 8];
                my $bit  = ($byte +> (7 - ($i % 8))) +& 1;
                @bits.push: $bit;
            }
            @bits.join;
        });
    }

    # ---- anything we cannot render --------------------------------
    # VARIANT / GEOMETRY / UNION (and any future type) have no stable
    # textual projection from a vector; callers should CAST them in SQL.
    sub (uint64 $r) { Any }
}
