use NativeCall;
use DB::Statement;
use DB::DuckDB::Native;
use DB::DuckDB::Error;
use DB::DuckDB::Result;

class DB::DuckDB::Statement does DB::Statement
{
    has DuckDB-Prepared $.stmt is required;
    has Bool $!alive = True;

    my sub duckdb-fail(int32 $code, Str $what) is hidden-from-backtrace
    {
        die DB::DuckDB::Error.new(:$code, message => $what);
    }

    method !check(int32 $code, Str $what)
    {
        duckdb-fail($code, $what) unless $code == DuckDBSuccess;
    }

    #| Raku value -> duckdb_bind_* dispatch.  Bool must be tested before
    #| Int (they are unrelated types, but Bool is the more specific one).
    method !bind-value(uint64 $idx, $val)
    {
        unless $val.defined {
            self!check(duckdb-bind-null($!stmt, $idx), 'bind null failed');
            return;
        }

        given $val {
            when Bool {
                self!check(duckdb-bind-boolean($!stmt, $idx, $_), 'bind boolean failed');
            }
            when Int {
                self!check(duckdb-bind-int64($!stmt, $idx, $_.Int), 'bind integer failed');
            }
            when Rat | FatRat {
                self!check(duckdb-bind-double($!stmt, $idx, $_.Num), 'bind rational failed');
            }
            when Num {
                self!check(duckdb-bind-double($!stmt, $idx, $_), 'bind number failed');
            }
            when Str {
                self!check(duckdb-bind-varchar($!stmt, $idx, $_), 'bind string failed');
            }
            when Blob {
                my $len = $_.elems;
                my $buf = CArray[uint8].allocate($len || 1);
                $buf[$_] = $val[$_] for ^$len;
                self!check(duckdb-bind-blob($!stmt, $idx, $buf, $len), 'bind blob failed');
            }
            when .defined {
                self!check(duckdb-bind-varchar($!stmt, $idx, $_.Str), 'bind value failed');
            }
            default {
                self!check(duckdb-bind-null($!stmt, $idx), 'bind null failed');
            }
        }
    }

    method execute(Bool :$finish, *@args, *%args)
    {
        die DB::DuckDB::Error.new(message => 'statement has already been freed')
            unless $!alive;

        my $res = DuckDB-Raw-Result.new;

        if @args || %args {
            duckdb-clear-bindings($!stmt);

            my uint64 $i = 0;
            for @args -> $val {
                $i++;
                self!bind-value($i, $val);
            }

            for %args.kv -> $name, $val {
                my uint64 $idx = 0;
                self!check(
                    duckdb-bind-parameter-index($!stmt, $idx, $name.Str),
                    "unknown statement parameter '{$name}'"
                );
                self!bind-value($idx, $val);
            }
        }

        my $rc = duckdb-execute-prepared($!stmt, $res);
        if $rc != DuckDBSuccess {
            my $msg = take-cstr(duckdb-result-error($res));
            duckdb-destroy-result($res);
            duckdb-fail($rc, $msg || 'statement execution failed');
        }

        # `DB` asks for `:finish` on *both* query() and execute(), so the
        # presence of columns -- not the flag -- decides what comes back.
        if duckdb-column-count($res) > 0 {
            return DB::DuckDB::Result.new(
                :sth(self),
                :finish(so $finish),
                :raw($res),
            );
        }

        my $changed = duckdb-rows-changed($res).Int;
        duckdb-destroy-result($res);
        $.finish if $finish;
        $changed;
    }

    method free(--> Nil)
    {
        return unless $!alive;
        $!alive = False;
        duckdb-destroy-prepare($!stmt);
    }
}
