use DB::DuckDB;

# ---- 1. 打开数据库：不传 path 是内存库，传 path 是文件库 -------------------
my $db = DB::DuckDB.new(path => ':memory:');
# my $db = DB::DuckDB.new(path => 'C:/data/shop.duckdb');   # 文件库

# ---- 2. 建表 + 造点数据 ---------------------------------------------------
$db.execute(q{
    create table orders (
        id       integer,
        customer varchar,
        city     varchar,
        amount   decimal(10,2),
        created  date
    )
});

$db.execute('insert into orders values (?, ?, ?, ?, ?)',
    1, '张三', '上海', 199.50, '2026-09-01');
$db.execute('insert into orders values (?, ?, ?, ?, ?)',
    2, '李四', '北京', 88.00, '2026-09-03');
$db.execute('insert into orders values (?, ?, ?, ?, ?)',
    3, '王五', '上海', 1299.00, '2026-09-08');

# ---- 3. 只查需要的字段，拿成 Hash（最常用）--------------------------------
say '--- 只取 id / amount 两列，按行遍历 ---';
for $db.query('select id, amount from orders order by id').hashes -> %row {
    say "id=%row<id>  amount=%row<amount>";
}

# ---- 4. 拿成 Array（列顺序已知、追求轻量时用）-----------------------------
say '--- 同一份数据用 arrays 取 ---';
for $db.query('select id, amount from orders order by id').arrays -> @row {
    say "id=@row[0]  amount=@row[1]";
}

# ---- 5. 参数化查询：条件是绑定的，不是拼字符串 ----------------------------
say '--- where + 绑定参数 ---';
for $db.query('select customer, amount from orders where city = ? order by amount desc', '上海').hashes -> %row {
    say "%row<customer>\t%row<amount>";
}

# ---- 6. 单值：只要一行一列 -------------------------------------------------
say '--- 聚合单值 ---';
say '订单总数: ', $db.query('select count(*) from orders').value;
say '总金额  : ', $db.query('select sum(amount) from orders').value;

# ---- 7. 单行 / 列名 / 列类型 ----------------------------------------------
say '--- 单行 + 列元信息 ---';
my $r4 = $db.query('select id, customer, amount, created from orders where id = 1');
say '列名  : ', $r4.names;
say '整行  : ', $r4.array;
say '列类型: ', $r4.column-types;

# ---- 8. 命名占位符（DuckDB 的写法是 $name，不是 :name）--------------------
say '--- 命名占位符 ---';
say $db.query('select id, customer from orders where id = $id', :id(2)).hash;

# ---- 9. 动态列名：列名来自变量 --------------------------------------------
say '--- 按需选列（列名来自变量）---';
my @cols = <id customer amount>;
my $sql = 'select ' ~ @cols.join(', ') ~ ' from orders order by id';
for $db.query($sql).hashes -> %row {
    say @cols.map({ $_ ~ '=' ~ %row{$_} }).join('  ');
}

$db.close;
