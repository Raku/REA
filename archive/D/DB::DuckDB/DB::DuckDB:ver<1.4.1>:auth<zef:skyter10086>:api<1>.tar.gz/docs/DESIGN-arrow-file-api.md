# 文件级 Arrow API 设计（草案 v1）

> 状态：**草案，未动代码**。目的先把「谁负责编解码、API 长什么样」定下来，再动手。
> 时点：2026-11-24，本机 DB::DuckDB 1.2.2 / 驱动内嵌 DuckDB **2.0.0** / nanoarrow 已装。
> 所有数字为本机 Windows 实测，方法写在 §2 表头，可复现命令见 §10。
>
> **实施状态（2026-11-24 晚）：第 0 步已完成，随 1.3.0 落地。** 落地时与草案有四处偏差，记在 §13，
> 看代码前先读那一节（尤其 BLOB 那条：默认解码没改，改动的是取字节的路子）。

---

## 1. 结论

**文件级 Arrow 读写不需要任何自研 IPC 编解码。** DuckDB 2.0 + 社区扩展 `nanoarrow` 已经提供了：

| 需求 | 现成能力 | 实测 |
|---|---|---|
| 读 `.arrow` / `.arrows` | `read_arrow(path)` 表函数；也可 `SELECT * FROM 'x.arrow'`（扩展加载后按内容嗅探） | 5 万行 4 ms |
| 写 file 格式（Feather V2，pandas 可读） | `COPY ... TO 'x.arrow' (FORMAT ARROW, BATCH_SIZE n)` | 44 ms |
| 写 stream 格式 | `COPY ... TO 'x.arrows' (FORMAT ARROWS, BATCH_SIZE n)` | 44 ms |
| 压缩 | `(FORMAT ARROW, COMPRESSION zstd)` | 1.44 MB → 310 KB |
| 列裁剪 | 投影下推进 `READ_ARROW`（`EXPLAIN ANALYZE` 可见 `Projections: id`） | — |
| 表 → IPC 字节 | `to_arrow_ipc(table)` 返回 `(ipc BLOB, header BOOLEAN)` 消息流 | — |

所以这里要做的**不是实现**，而是**包一层**：把表函数/COPY 语句包成和 `DB::DuckDB::Parquet` 对称的 API，管好扩展生命周期，把类型和错误口径定死。

一句话分层：**字节归 DuckDB（C++），SQL 归 DB::DuckDB，语义归调用方。**

---

## 2. 实测基线

环境：Windows，驱动内嵌 DuckDB 2.0.0（`select version()`），nanoarrow 已安装（`duckdb_extensions()` → `installed=true`），
夹具 `tmp/p2.arrow` = 5 万行 × 3 列（int64 / utf8 / double），1.44 MB。

| 动作 | 现路径（Raku 自研） | 新路径（DuckDB + nanoarrow） | 倍数 |
|---|---|---|---|
| 读文件 → Raku 行 | 1.58 s | 查询 4 ms + `Result` 物化 232~302 ms ≈ **0.26 s** | ≈ 6× |
| 写 `Table` → 文件 | 2.79 s | **44 ms**（COPY） | ≈ 63× |
| `Table` → DuckDB → SQL → `Table` | 6.6 s | appender 480 ms + SQL 12 ms + 物化 230 ms ≈ **0.72 s** | ≈ 9× |
| 压缩写 | 不支持 | zstd，**310 KB** | 新能力 |

几条要记住的边界事实：

1. **`LOAD` 是数据库实例级**，不是连接级。在 `$db.connect` 的任一连接上 `LOAD nanoarrow` 后，同实例其它连接立即可用（已验）。
2. **不加载时的报错不可爱**：`Binder Error: No extension found that is capable of reading the file "x.arrow"` —— 用户看不出该装什么。必须由我们换成带安装指引的错误。
3. **file 与 stream 都按内容嗅探**：把 stream 格式文件改名成 `.arrow` 后 `read_arrow` 照样读得出 5 万行。所以扩展名只影响**写**，不影响读。
4. **`FORMAT ARROW`（file）官方文档没写**，文档只举了 `FORMAT ARROWS`（stream）。但实测可用，且产物是标准 file 格式（`ARROW1` 头尾，`pyarrow.ipc.open_file` 与 `pyarrow.feather.read_table` 都能读）。stream 产物则 **pandas / feather 读不了**（`Not a Feather V1 or Arrow IPC file`）。这条决定了写默认值（见 §4.3）。
5. **物化的钱在 Raku 侧**：4 ms 是 DuckDB 读完文件，232 ms 是 `Result` 把 5 万个格子装箱成 Raku 值。这一层在 `DB::DuckDB` 里，不在 nanoarrow 里，也是后续唯一值得继续优化的地方（`TextColumn` / `arrays-fast`）。

---

## 3. nanoarrow 到底给了什么（能力边界）

对 `t/fixtures/arrow/` 全部 8 个夹具跑 `read_arrow()`，全部成功：

| 夹具 | 结果 |
|---|---|
| `basic.arrow` / `kinds.arrow` / `multi.arrow` / `stream.arrow` | 3 行 |
| `nested.arrow` | 4 行 |
| `temporal.arrow` | 3 行 |
| `empty.arrow` | 0 行（不报错） |
| `compressed.arrow` | 3 行（**自研读侧是直接拒绝的**） |

类型映射（`DESCRIBE SELECT * FROM read_arrow(...)`）：

| Arrow | DuckDB | 说明 |
|---|---|---|
| `int64` / `int32` / `uint8` | `BIGINT` / `INTEGER` / `UTINYINT` | 位宽保留，无符号保留 |
| `double` / `float` | `DOUBLE` / `FLOAT` | |
| `utf8` | `VARCHAR` | 字典编码也落到 VARCHAR |
| `bool` | `BOOLEAN` | |
| `date32` | `DATE` | |
| `timestamp[ms, tz]` | `TIMESTAMP WITH TIME ZONE` | 时区保留 |
| `time32[s]` | `TIME` | 秒精度被抬到微秒 |
| `decimal128(10,2)` | `DECIMAL(10,2)` | 精度与标度保留 |
| `duration` | `INTERVAL` | 语义变了：`duration` 不是 `interval`，往返不是逐位无损 |
| `list<T>` | `T[]` | |
| `struct<...>` | `STRUCT(...)` | 字段名保留 |
| `map<K,V>` | `MAP(K,V)` | |

**不提供**：随机访问（不能 seek 到第 N 行）、页级裁剪（列裁剪只有投影下推）、谓词下推到文件内部（没有 zone map）。

---

## 4. 提议的 API

### 4.1 新模块 `DB::DuckDB::ArrowFile`

与 `DB::DuckDB::Parquet` 同构：**纯 SQL 构造 + 扩展门禁**，不持连接、不执行。

```raku
unit module DB::DuckDB::ArrowFile;

#| 扩展名 → 默认写格式。读侧不看扩展名（DuckDB 按内容嗅探）。
our constant ARROW-FORMATS = %(arrow => 'file', feather => 'file',
                               ipc   => 'file', arrows => 'stream');

#| 写侧接受的压缩名。白名单，绝不把用户串拼进 SQL。
our constant ARROW-COMPRESSIONS = <uncompressed lz4 zstd>;

#| 扩展是否已安装（只查目录，不改动实例）。
our sub arrow-installed(DB::DuckDB::Connection $conn --> Bool) is export;

#| 扩展是否已在本实例加载。
our sub arrow-loaded(DB::DuckDB::Connection $conn --> Bool) is export;

#| 确保可用：已加载 → 直接返回；已安装未加载 → LOAD；未安装 →
#|   :install 为真才 INSTALL nanoarrow FROM community 再 LOAD；
#|   否则抛带安装指引的 DB::DuckDB::Error。
our sub ensure-arrow(DB::DuckDB::Connection $conn, Bool :$install = False --> Bool) is export;

#| `select <cols> from read_arrow(?, ...)`；path-count>1 时用 [?, ?, ...]。
our sub arrow-read-sql(:columns($columns), :schema($schema),
                       Bool :union-by-name, Bool :filename,
                       Bool :hive-partitioning, Int :path-count = 1 --> Str) is export;

#| `copy <src> to 'x.arrow' (format arrow, batch_size n, compression zstd)`。
#| $format 只吞 'file' | 'stream'，由 ARROW-FORMATS 决定默认值。
our sub arrow-write-sql(Str:D $target, Str:D $source, Bool :$sql = False,
                        Str :$schema, Str :$format = 'file',
                        Int :batch-size($batch-size), Str :$compression --> Str) is export;
```

要点：

- **读路径必须绑定参数**，和 `parquet-read-sql` 一致 —— 路径永远不进 SQL 文本，Windows 反斜杠与引号都不用转义。
- **写路径必须插值**（`COPY` 的目标是字面量），所以复用 `parquet-literal` 的转义规则；压缩名走白名单。
- `:format` 只接受两个值，拼成 `format arrow` / `format arrows`，不接受任意串。

### 4.2 `DB::DuckDB::Connection` 新增方法

对齐 `read-parquet` / `write-parquet` 的形状，让用户不用记两套：

```raku
#| 读 Arrow 文件（或 glob / 路径列表）。默认确保扩展可用。
multi method read-arrow(Str:D $path,
                        Bool :union-by-name($union-by-name) = False,
                        Bool :$filename = False,
                        Bool :hive-partitioning($hive-partitioning),
                        :columns($columns), :schema($schema),
                        Bool :$stream = False,
                        Bool :$install = False --> DB::DuckDB::Result);

multi method read-arrow(@paths, *%same --> DB::DuckDB::Result);

#| 写 Arrow 文件。$format 缺省按目标扩展名推（.arrows → stream，其它 → file）。
method write-arrow(Str:D $path, Str:D $source, Bool :$sql = False, Str :$schema,
                   Str :$format, Int :batch-size($batch-size),
                   Str :$compression, Bool :$install = False --> Bool);

#| 表 → Arrow IPC 消息字节（stream 格式，含 header 消息）。
#| 给 Duckula 的 Frame.ipc-buf 用，替代它现在自己拼字节。
method to-arrow-ipc(Str:D $source, Bool :$sql = False,
                    Str :$compression, Int :$compression-level --> Blob);

#| 能力查询，给调用方做降级判断，不抛异常。
method arrow-available(Bool :$install = False --> Bool);
method nanoarrow-version(--> Version);
```

`read-arrow` 的 `:stream` 与 `read-parquet` 语义保持一致（流式结果集，不一次性物化）。

### 4.3 写默认值（需要你确认，见 §12）

| 目标扩展名 | 默认格式 | 理由 |
|---|---|---|
| `.arrow` `.feather` `.ipc` | `file` | pandas `read_feather` / polars / pyarrow `open_file` 只认 file 格式 |
| `.arrows` | `stream` | 官方文档唯一的写法，也是「不能 seek 的一次性流」的正确表达 |

`FORMAT ARROW` 未见于官方文档但有实测支撑 —— 这条要写进注释，并在每次抬 DuckDB 版本时复核一次（§11）。

---

## 5. 扩展生命周期

```
arrow-available
   └─ duckdb_extensions() 查 installed        → false：返回 False（不抛）
        └─ ensure-arrow
             ├─ 已加载（实例级缓存标记）        → True
             ├─ installed=true               → LOAD nanoarrow → True
             ├─ installed=false & :install   → INSTALL nanoarrow FROM community; LOAD → True
             └─ 其它                          → 抛 DB::DuckDB::Error（带两条命令）
```

- 加载状态缓存在 **Connection 对象**上（`has Bool $!arrow-loaded`），但语义是实例级 —— 缓存只是省一次 `LOAD`，判断错了也只多执行一条幂等语句。
- 默认**不联网**：`:install` 默认 `False`。理由：`INSTALL ... FROM community` 会写 `~/.duckdb/extensions/<ver>/<platform>/`，在受限机器/离线机器上是失败路径，不该由一次普通读文件触发。
- 环境变量退出开关：`DB_DUCKDB_NO_ARROW_AUTOLOAD=1` 时 `ensure-arrow` 只检查不加载，让嵌入方自己管。
- 失败错误文案（三段式，可直接抄给用户）：

  ```
  Arrow 文件读写需要 DuckDB 的 nanoarrow 社区扩展，当前实例没有加载。
  安装：INSTALL nanoarrow FROM community;   加载：LOAD nanoarrow;
  也可以调用时传 :install 让它自动装（需要能访问 DuckDB 社区扩展源）。
  ```

- 版本不匹配（装了但 `LOAD` 报 ABI/版本错）单独一条文案，提示「扩展按 DuckDB 版本分目录，升级驱动后需要重装」。

---

## 6. 错误模型

| 情形 | 谁报 | 形态 |
|---|---|---|
| 扩展缺失 | `ensure-arrow` | `DB::DuckDB::Error`，message 见 §5 |
| 文件不存在 | DuckDB | 原样透出，但**前置一次 `$path.IO.e` 检查**，给出我们自己的短句（DuckDB 的原句带 `IO Error` 与绝对路径，太长） |
| 文件截断（无 footer） | nanoarrow | `IO Error: Arrow IPC file "x.arrow" is truncated, it has no footer`，**不崩** |
| FlatBuffers 损坏 | nanoarrow | `IO Error: status failed with errno 22: Message flatbuffer verification failed (17) ...`，**不崩** |
| 不认识的 `:format` / `:compression` | `arrow-write-sql` | `DB::DuckDB::Error`，白名单列出 |
| 目标已存在 | `write-arrow` | 默认**覆盖**（与 `write-parquet` 一致）；`:no-clobber` 时前置检查并抛错 |

「不会段错误」是这块相对 `Arrow::IPC.decode-ipc` 的核心优势，有直接证据：把 `IKXKJU` 里那份
**320 字节、会让 `Arrow::IPC::decode-ipc` SIGSEGV(rc=139)** 的文件喂给 `read_arrow`，得到的是

```
IO Error: status failed with errno 22: Message flatbuffer verification failed (17)
          string header out of range or unaligned
```

—— 一句可捕获的错误，进程活着。截断文件同理（`is truncated, it has no footer`）。

> 注意一处**宽容但不保证**：把 Footer 里的 Block 偏移改坏（`badoff` / `badbody` / `badvt` 三种），
> `read_arrow` 仍然读出 3 行，不报错。说明它并不严格跟着那些偏移走。这是「不容易崩」，**不是校验器** ——
> 想验完整性别指望它。

---

## 7. 已知缺口（必须在文档里写明，不许假装没有）

### 7.1 `to_arrow_ipc` 的字节拿不出来 —— BLOB 解码缺口

`to_arrow_ipc` 返回 `(ipc BLOB, header BOOLEAN)`。但驱动把 BLOB 解成**带转义的 Str**：

```
select '\x41\x42\xFF'::blob  →  Str "AB\xFF"（chars=6，原始 3 字节）
```

长度和内容都被转义过一次，拼不出可用的 IPC 流。

**落地时的选择**：不改默认解码。`03-types` 的契约是「解码值与 DuckDB 的文本渲染一致」，
BLOB 默认改 `Blob` 会破坏它（也会破坏用户代码），这是 2.0 的事。改为走已经存在的零拷贝出口：

```raku
my $t = $result.column-view(0).text;   # TextColumn，BLOB 也可用
$t.bytes-at($i)                        # 原始字节，逐行
```

`to-arrow-ipc` 就是用它拼字节的（`t/20` 里有一条断言钉住 3 字节原样返回）。
代价：调用方要知道 BLOB 的「文本渲染」和「字节」是两条路 —— 已写进 README 与 CHANGES。

### 7.2 嵌套列经 SQL 出口会变文本

`read_arrow('nested.arrow')` 的 `LIST` / `STRUCT` / `MAP` 列，走普通 `Result` 出口是**DuckDB 的文本渲染**：

```
tags   → "[a, b]"                         (Str)
person → "{'name': ann, 'age': 30}"       (Str，NULL 变字面量 "NULL")
counts → "{}" / "{x=1, y=2}"              (Str)
```

结构信息（字段名、NULL 位、类型）在这一步丢失。三条路：

| 方案 | 代价 | 建议 |
|---|---|---|
| A. 接受文本，文档写明「嵌套要结构请走 C Data」 | 0 | **v1 采用** |
| B. 给 `Result` 加 LIST/STRUCT/MAP 解码器 | 大（跟 NULL 位、子 buffer、递归类型都要做） | 后续版本 |
| C. 调用方显式走 `DB::DuckDB::Arrow`（`with-arrow-table` + `children` 递归） | 中，调用方要自己遍历 | v1 提供 `read-arrow-arrow` 旁路，供 Rakuish 读嵌套文件用 |

Rakuish 的 `Table` 支持 list/map，所以「读带嵌套列的 .arrow」在 Rakuish 侧**不能**直接换成 SQL 出口，否则是功能回退。§9 的迁移路线里给了旁路做法。

### 7.3 `scan_arrow_ipc` 不作为产品 API

它接受 `STRUCT(ptr POINTER, size UBIGINT)[]`（指向序列化 IPC 消息的指针），官方原文：*"reading buffers is dangerous, as an incorrect pointer can crash the database system"*，且标注 *"temporary and will be deprecated"*。

结论：**不封装成公开方法**。真需要内存零拷贝（比如把外部 Arrow C Data 直接扫进来），走 `arrow_scan` / `arrow_scan_dumb` 的 C Data 路线，并且只在明确标注 `:unsafe` 的入口暴露。

---

## 8. 不做清单

- 不实现 IPC 编解码（FlatBuffers / 批 / 压缩）：那是 nanoarrow 的活。
- 不把 nanoarrow 作为**构建期**依赖：它是运行时 `LOAD` 的社区扩展，`zef install` 不应联网装它。
- 不自己维护 schema 映射表：类型口径以 `DESCRIBE read_arrow(...)` 为准，测试里固化（§10）。
- 不在 `DB::DuckDB` 里 `use Arrow::IPC`：那会把「零依赖纯 Raku」的 Arrow::IPC 拖进 libduckdb 依赖链，方向反了。

---

## 9. 跨仓库迁移路线

每一步都能用现有测试兜底，且**任何一步失败都可独立回退**。

### 第 0 步：DB::DuckDB 1.3.0 —— 打地基

1. BLOB → `Blob` 解码（§7.1）。
2. `DB::DuckDB::ArrowFile`（§4.1）。
3. `Connection.read-arrow` / `write-arrow` / `to-arrow-ipc` / `arrow-available`（§4.2）。
4. 新测试 `t/20-arrow-file.rakutest`。
5. `META6.json` 的 `provides` 加新模块；README / HANDOFF / CHANGES 各加一节。

**验收**：8 个夹具全读通；写出的 file 格式能被 `pyarrow.ipc.open_file` 与 `pyarrow.feather.read_table` 读回；不装扩展时有可读错误。

### 第 1 步：Duckula 0.36.0 —— 把它自己的解析器下岗

- `ArrowRead.decode-ipc` 的调用点改成 `DB::DuckDB.read-arrow`（Duckula 本来就有连接），保留它自己的 dtype 映射与解码缓存。
- `Frame.ipc-buf` 改成 `$conn.to-arrow-ipc(...)`，**顺带修掉 timestamptz 那个 issue（`IKXKJW`）**。
- `Arrow::IPC` 降级为「没装 DB::DuckDB 时的兜底」，不是主路径。

**验收**：Duckula 现有测试全绿；55 万行 `read-arrow` 从秒级掉到毫秒级；`ipc-buf` 的产物能被 `pyarrow.open_stream` 读回（现在不能）。

### 第 2 步：Rakuish 0.122.0 —— 删自研

- `open-data` 的 `.arrow/.feather/.ipc` → `$conn.read-arrow`；含嵌套列且需要结构时走 §7.2-C 的旁路。
- `save-data` 的 Arrow 分支 → `$conn.write-arrow`，`batch_size` = 现有 `:batch-size`，顺带白送压缩。
- `Table.sql` 不再写临时文件：`appender` 直插临时表。
- `Rakuish::Data::Arrow` 先降级为 fallback（`X::Rakuish::Arrow::UnsupportedType` 时才用），观察一版再删。

**验收**：`t/70`、`t/74`、`t/77` 语义等价（夹具不变）；`t/74` 里「压缩文件必须拒绝」这条要**改成「压缩文件可读」**（能力升级，不是回退）。

---

## 10. 测试矩阵（`t/20-arrow-file.rakutest`）

| 类别 | 用例 |
|---|---|
| 扩展 | 未装 → 可读错误；`:install` 路径（CI 里 skip）；`DB_DUCKDB_NO_ARROW_AUTOLOAD=1` 只检查不加载；同实例第二个连接复用已加载状态 |
| 读 | 8 个夹具逐一行数；`columns` 投影；`@paths` 多文件；`schema` 显式；空表 0 行；stream 格式文件；压缩文件 |
| 类型 | `basic` / `kinds` / `temporal` 逐列对 `column-types`，固化 §3 的映射表 |
| 写 | file / stream 两种格式；`batch_size` 产多批（用 nbatches 校验）；`compression` 三种；覆盖已存在文件；`:no-clobber` |
| 往返 | 写 → 读 → 值相等；写 → `pyarrow` 读回（有 pyarrow 时）；`to-arrow-ipc` → 拼字节 → `pyarrow.open_stream` |
| 错误 | 路径不存在；截断（无 footer）；FlatBuffers 损坏（用 `IKXKJU` 的 320 字节样本）；未知 `:format` / `:compression` |
| 整洁 | 临时文件只在 `$*TMPDIR`，用后删除；不写进仓库根 |

复现命令（本次实测用的）：

```bash
duckdb -c "LOAD nanoarrow; select count(*) from read_arrow('x.arrow');"
duckdb -c "LOAD nanoarrow; copy (select * from 'x.arrow') to 'o.arrow' (format arrow, batch_size 5000);"
duckdb -c "LOAD nanoarrow; select ipc from to_arrow_ipc((select * from t));"
```

---

## 11. 风险与回退

| 风险 | 影响 | 应对 |
|---|---|---|
| 用户机器离线/禁扩展 | `.arrow` 完全不可用 | 三层降级：DuckDB → `Arrow::IPC`（Rakuish 保留）；文档写清前置条件 |
| `FORMAT ARROW` 是未文档化写法 | 抬版本后可能消失 | 每次升级跑 `t/20`；真有变化就改用 `to_arrow_ipc` 落盘（多一次内存拷贝） |
| 扩展版本漂移 | `LOAD` 报错 | 检测错误文案，提示重装；错误里带上当前 DuckDB 版本与期望目录 |
| `duration → INTERVAL` 语义变化 | 往返不无损 | 文档写明；Rakuish 侧把 duration 列标成 `interval`，不假装还是 duration |
| 物化仍是 230 ms/5 万行 | 大表慢 | 后续用 `arrays-fast` / `TextColumn`；或调用方 `:stream` |

回退方式统一：`arrow-available` 为假 → 调用方走自己的兜底；`DB::DuckDB` 层永远不静默降级（不偷偷改用别的解析器）。

---

## 12. 需要你拍板的三件事

1. **默认要不要联网装扩展？** 我建议默认只 `LOAD`，`:install` 显式开（离线机器友好，也能避免一次读文件触发网络）。
2. **嵌套列 v1 的口径？** 我建议：SQL 出口接受文本（§7.2-A），同时提供 C Data 旁路给 Rakuish 读嵌套文件；给 `Result` 加嵌套解码留到 1.4。
3. **写 `.arrow` 默认 file 格式？** 我建议默认 file（pandas/feather 兼容），`.arrows` 才用 stream —— 代价是依赖一条未文档化的 `FORMAT ARROW`。

这三条定了，我就按 §9 第 0 步开工：先补 BLOB 解码，再落 `ArrowFile` 与 `Connection` 方法，`t/20` 跟上。

**已拍板（2026-11-24）：三条都按建议走** —— 默认不联网、嵌套 v1 接受文本、`.arrow` 默认 file 格式。

---

## 13. 落地记录：与草案的四处偏差

第 0 步已随 **DB::DuckDB 1.3.0** 落地（`DB::DuckDB::ArrowFile` + `Connection.read-arrow` /
`write-arrow` / `to-arrow-ipc` / `arrow-available` / `nanoarrow-version`，`t/20` 13 个子测试 /
66 条断言，全套 20 文件 / 631 条顶层断言通过）。实现时有四处与上面的草案不同，都是实测之后改的：

| # | 草案 | 实际 | 原因 |
|---|---|---|---|
| 1 | 「先补 BLOB → `Blob` 解码」 | 默认解码不动，用 `column-view($i).text.bytes-at($j)` 取字节 | 改默认会打破 `03-types` 的「与文本渲染一致」契约，属 2.0 的破坏性变更；零拷贝出口已经够用 |
| 2 | `read-arrow(:$schema)` | 未实现 | 扩展要求 `schema` 是 `MAP(VARCHAR, STRUCT(name, type, default_value))`，构造它等于把列类型拼进 SQL，收益低、注入面大；文件自带 schema 的情况占绝大多数 |
| 3 | 「`batch_size` 是每批行数」 | 是**上限**：DuckDB 不产小于 2048 行的批 | 实测 1 万行 `:batch-size(1)` 仍 5 批；不传则整份 1 批。README / CHANGES / HANDOFF §8.12 均已改写 |
| 4 | （未预见） | `to_arrow_ipc` 强制 `(select * from "t")` | 传裸表名会在扩展内部断言失败：`Expected struct child 1 to have length >= 1 but found child with length 0` |

另外两条保持草案原样，作为**已知边界**写进了文档：嵌套列经 SQL 出口是文本（§7.2-A），
`scan_arrow_ipc` 不封装（§7.3）。`FORMAT ARROW`（file 形式）仍是未文档化写法，`t/20` 用
「文件头必须是 `ARROW1`」把这条钉住，抬 DuckDB 版本时若写法变了会立刻红。
