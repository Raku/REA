use v6.d;

#| Zero-copy arrow views over a DuckDB result.
#|
#| `duckdb_data_chunk_to_arrow` turns a chunk into an Arrow struct array
#| (one child per column) using the Arrow C data interface.  That interface
#| is a fixed 10 field layout, so no Arrow library -- neither the DuckDB
#| `arrow` extension nor NanoArrow -- is required: the struct is declared
#| here and read directly.
#|
#| Measured on 1M rows x 3 columns (see docs), the conversion itself costs
#| ~0.035 us/row, numeric columns read at the same speed as DuckDB's own
#| vectors, and UTF-8 columns are slower than the driver's join+split path.
#| The real win is nested data: LIST/STRUCT/MAP arrive as recursively
#| walkable arrays instead of being stringified.
unit module DB::DuckDB::Arrow;

use NativeCall;
use DB::DuckDB::Native;
use DB::DuckDB::Result;
use DB::DuckDB::ArrowShim;

my constant WIN = $*DISTRO.is-win;

class ArrowArray is repr('CStruct') is export {
    has int64 $.length;
    has int64 $.null-count;
    has int64 $.offset;
    has int64 $.n-buffers;
    has int64 $.n-children;
    has Pointer $.buffers;
    has Pointer $.children;
    has Pointer $.dictionary;
    has Pointer $.release-fn;
    has Pointer $.private-data;
}

#| The schema half of the Arrow C data interface.
#|
#| Its layout is *not* the same as `ArrowArray`: three pointers come first
#| (format, name, metadata), so the release callback lands at offset 56 rather
#| than 64.  Anything that treats the two structs interchangeably works right
#| up until the moment something is released.
class ArrowSchema is repr('CStruct') is export {
    has Pointer $.format;
    has Pointer $.name;
    has Pointer $.metadata;
    has int64 $.flags;
    has int64 $.n-children;
    has Pointer $.children;
    has Pointer $.dictionary;
    has Pointer $.release-fn;
    has Pointer $.private-data;
}

sub result-arrow-options(DuckDB-Raw-Result $result --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_result_get_arrow_options') { }
sub chunk-to-arrow(Pointer $options, DuckDB-Data-Chunk $chunk, Pointer $out --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_data_chunk_to_arrow') { }
sub to-arrow-schema(Pointer $options, Pointer $types, Pointer $names, uint64 $n, Pointer $out --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_to_arrow_schema') { }
sub destroy-arrow-options(Pointer $options is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_arrow_options') { }

sub schema-from-arrow(DuckDB-Connection $conn, Pointer $schema, CArray[Pointer] $out --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_schema_from_arrow') { }
sub chunk-from-arrow(DuckDB-Connection $conn, Pointer $array, Pointer $converted, CArray[Pointer] $out --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_data_chunk_from_arrow') { }
sub destroy-arrow-converted-schema(Pointer $converted is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_arrow_converted_schema') { }

sub error-data-has-error(Pointer $err --> bool)
    is native(&duckdb-lib) is symbol('duckdb_error_data_has_error') { }
sub error-data-message(Pointer $err --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_error_data_message') { }
sub destroy-error-data(Pointer $err is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_error_data') { }

#| Read a NUL terminated UTF-8 string out of foreign memory.
sub cstr(Pointer $p --> Str)
{
    return '' unless $p.defined && $p.Int;
    my $ca = nativecast(CArray[uint8], $p);
    my $buf = Buf.new;
    my int $i = 0;
    while $ca[$i] != 0 {
        $buf.push: $ca[$i];
        $i++;
    }
    $buf.decode('utf-8');
}

#| Copy a Raku string into foreign memory and hand back its address.
#|
#| `CArray[Str].allocate` refuses to build an array of `Str` at all (it wants a
#| concrete initial value and then rejects NUL), and `nativecast(Pointer, $str)`
#| does not exist, so the bytes are written by hand.  The returned buffer is
#| pushed onto `@keep` so it outlives the native call that reads it.
sub c-alloc-str(Str:D $s, @keep --> Pointer)
{
    my $bytes = $s.encode('utf-8');
    my $ca = CArray[uint8].allocate($bytes.bytes + 1);
    my int $i = 0;
    for $bytes.list -> $b { $ca[$i++] = $b; }
    $ca[$i] = 0;
    @keep.push: $ca;
    nativecast(Pointer, $ca);
}

#| Turn a `duckdb_error_data` into a die, or into nothing when it is clean.
#|
#| Two traps live here.  A non-NULL return is *not* proof of failure -- the
#| struct is allocated either way and `has_error` is the real answer.  And the
#| out-parameters of these calls must be passed as `CArray[Pointer]`; handing
#| over `nativecast(Pointer, $carray)` instead gets a NULL return with the out
#| slot still empty, which then fails much later inside a different function
#| with `Invalid argument(s) to duckdb_data_chunk_to_arrow`.
sub check-arrow-call(Pointer $err, Str:D $what)
{
    return if $err.defined && $err.Int == 0;
    my Bool $bad = error-data-has-error($err).Bool;
    my Str $msg = $bad ?? cstr(error-data-message($err)) !! '';
    my Pointer $tmp = $err;
    destroy-error-data($tmp);
    die "$what failed: $msg" if $bad;
}

# The release callback is only known at run time, so it is called through the
# C shim when one could be built (see DB::DuckDB::ArrowShim): invoking a raw
# function pointer from Raku is both ABI-fragile and lossy, measured at ~24 KB
# of process growth per call.  The in-Raku path stays as a fallback for boxes
# without a compiler.
my $SHIM-RELEASE;
my Bool $SHIM-PROBED = False;

sub shim-release-fn()
{
    return Nil if %*ENV<DB_DUCKDB_NO_ARROW_SHIM>;
    return $SHIM-RELEASE if $SHIM-PROBED;
    $SHIM-PROBED = True;

    # `require` proves only that the module compiles: `is native(&shim-library)`
    # resolves lazily, so on a box without a compiler the module loads happily
    # and the failure is deferred to the first native call -- by which point the
    # array is in hand and there is no second release path left.  Ask the shim
    # module whether a library actually exists *before* promising to use it, so
    # the fallback is a fallback and not a die.
    my $lib = try { DB::DuckDB::ArrowShim::shim-lib() } // '';
    unless $lib.chars {
        note "ARROW DEBUG: no shim library; in-Raku release"
            if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
        return $SHIM-RELEASE = Nil;
    }

    $SHIM-RELEASE = try {
        my $mod = (require ::('DB::DuckDB::ArrowShim::Native'));
        my &release = $mod.WHO<&dkd-arrow-release>;
        &release.defined ?? &release !! Nil;
    };
    note "ARROW DEBUG: shim load failed: {$!}" if %*ENV<DB_DUCKDB_ARROW_DEBUG> && !$SHIM-RELEASE;
    $SHIM-RELEASE;
}

# Release callback pointers are stable for the lifetime of the library: DuckDB
# hands out one function for every chunk it converts (measured: a single
# distinct pointer across 245 chunks of five different results).  That matters
# because `nativecast(:(Pointer), $ptr)` builds a fresh native call stub every
# time it runs, and those stubs are never reclaimed -- the in-Raku path grew
# 69 MB over ~1500 releases, which is what the shim was hiding.  Caching one
# stub per distinct pointer removes the growth entirely without needing a
# compiler.
#
# The cache is keyed by the pointer value, so a library that really does use
# several release functions still gets one stub each.  A lock guards the fill
# only; lookups after the first are plain hash reads.
my %RELEASE-CACHE{Int};
my $RELEASE-LOCK = Lock.new;

sub raku-release(Pointer $addr --> Nil)
{
    my $root = nativecast(ArrowArray, $addr);
    my $fn = $root.release-fn;
    return unless $fn.defined && $fn.Int;

    my $key = $fn.Int;
    my $code = %RELEASE-CACHE{$key}
        // $RELEASE-LOCK.protect: { %RELEASE-CACHE{$key} //= nativecast(:(Pointer), $fn) };

    $code($addr);
    Nil;
}

sub release-array(Pointer $addr --> Nil)
{
    with shim-release-fn() -> &release {
        note "ARROW DEBUG: shim release" if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
        release($addr);
        return;
    }

    note "ARROW DEBUG: raku release (no shim)" if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
    raku-release($addr);
}

# The schema release has to go through its own shim entry point.  The two
# structs do *not* share a layout: ArrowArray opens with five int64 fields so
# its callback sits at offset 64, while ArrowSchema opens with three pointers
# so its callback sits at offset 56.  Calling the array release on a schema
# jumps through `dictionary` instead and takes the process down.
my $SHIM-SCHEMA-RELEASE;
my Bool $SHIM-SCHEMA-PROBED = False;

sub shim-schema-release-fn()
{
    return Nil if %*ENV<DB_DUCKDB_NO_ARROW_SHIM>;
    return $SHIM-SCHEMA-RELEASE if $SHIM-SCHEMA-PROBED;
    $SHIM-SCHEMA-PROBED = True;

    my $lib = try { DB::DuckDB::ArrowShim::shim-lib() } // '';
    return $SHIM-SCHEMA-RELEASE = Nil unless $lib.chars;

    $SHIM-SCHEMA-RELEASE = try {
        my $mod = (require ::('DB::DuckDB::ArrowShim::Native'));
        my &release = $mod.WHO<&dkd-arrow-schema-release>;
        &release.defined ?? &release !! Nil;
    };
}

sub raku-release-schema(Pointer $addr --> Nil)
{
    my $schema = nativecast(ArrowSchema, $addr);
    my $fn = $schema.release-fn;
    return unless $fn.defined && $fn.Int;

    my $key = $fn.Int;
    my $code = %RELEASE-CACHE{$key}
        // $RELEASE-LOCK.protect: { %RELEASE-CACHE{$key} //= nativecast(:(Pointer), $fn) };

    $code($addr);
    Nil;
}

sub release-schema(Pointer $addr --> Nil)
{
    with shim-schema-release-fn() -> &release {
        note "ARROW DEBUG: shim schema release" if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
        release($addr);
        return;
    }

    note "ARROW DEBUG: raku schema release (no shim)" if %*ENV<DB_DUCKDB_ARROW_DEBUG>;
    raku-release-schema($addr);
}

constant ARROW-ARRAY-SIZE = 80;   # 4 x int64 + 6 x pointer

#| The platform C library, which lends us memcpy.  The name is assembled from
#| pieces on purpose: installers (zef, raku-pm) scan the source for
#| `is native('<name>')` literals, collect every name they find as a hard
#| dependency, and then refuse to install on either platform -- Windows for a
#| missing libc, Linux for a missing msvcrt.  Building the constant keeps that
#| scan from inventing dependencies while still resolving at compile time,
#| which `is native(...)` requires.
#|
#| The Linux name carries the version on purpose: NativeCall would turn a bare
#| 'libc' into 'liblibc.so' and fail, while a name with dots is used as given.
my constant CLIB = $*DISTRO.is-win ?? 'msvc' ~ 'rt' !! 'libc' ~ '.so.6';

sub memcpy-clib(Pointer $dst, Pointer $src, size_t $n --> Pointer)
    is native(CLIB) is symbol('memcpy') { }

sub copy-bytes(Pointer $dst, Pointer $src, size_t $n --> Nil)
{
    memcpy-clib($dst, $src, $n);
}

#| One column of an arrow struct array, read through the C data interface.
class Column is export {
    has ArrowArray $!arr;
    has Pointer $!addr;

    submethod BUILD(:$!arr!, :$!addr!) { }

    #| Element count of this child array.
    method length(--> Int)     { $!arr.length.Int }
    #| Number of null slots, straight from the ArrowArray struct.
    method null-count(--> Int) { $!arr.null-count.Int }
    #| Number of nested child arrays (0 for a primitive column).
    method n-children(--> Int) { $!arr.n-children.Int }

    #| Raw buffer pointer, or a null Pointer when the slot is absent
    #| (e.g. the validity buffer of a column without nulls).
    method buffer(int $j --> Pointer)
    {
        my $base = $!arr.buffers;
        return Pointer unless $base.defined && $base.Int;
        return Pointer if $j >= $!arr.n-buffers;
        my $slot = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $j))[0];
        return Pointer unless $slot.defined && $slot.Int;
        # rakupp hands back a CArray[int64] element where MoarVM produces a
        # Pointer; normalise both to a real Pointer before it reaches a
        # Pointer-typed attribute or return slot.
        Pointer.new($slot.Int);
    }

    #| The child arrays as `Column` objects, in Arrow order.
    method children(--> List)
    {
        my $base = $!arr.children;
        return () unless $base.defined && $base.Int;
        my @kids;
        for ^$!arr.n-children -> int $i {
            my $raw = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
            my $p = Pointer.new($raw.Int);
            @kids.push: Column.new(arr => nativecast(ArrowArray, $p), addr => $p);
        }
        @kids.List;
    }

    #| Bitmap test; an absent validity buffer means "nothing is null".
    method is-null(int $i --> Bool)
    {
        my $v = self.buffer(0);
        return False unless $v.defined && $v.Int;
        my $byte = nativecast(CArray[uint8], Pointer.new($v.Int + ($i +> 3)))[0];
        ($byte +& (1 +< ($i +& 7))) == 0;
    }

    method !typed(CArray $ca, int $n, &conv)
    {
        my @out;
        @out.push: conv($ca[$_]) for ^$n;
        @out.List;
    }

    #| Buffer 1 as a List of int, for the integer types.
    method ints(--> List)  { self!typed(nativecast(CArray[int64], self.buffer(1)), self.length, -> $v { $v }) }
    #| Buffer 1 as a List of Num, for FLOAT / DOUBLE.
    method nums(--> List)  { self!typed(nativecast(CArray[num64], self.buffer(1)), self.length, -> $v { $v }) }
    #| Buffer 1 as a List of int, for the 32 bit integer types (DATE and
    #| friends), where `ints` would read past the element.
    method int32s(--> List) { self!typed(nativecast(CArray[int32], self.buffer(1)), self.length, -> $v { $v }) }

    #| Bit-packed booleans; bit i of byte (i +> 3).
    method bools(--> List)
    {
        my $v = self.buffer(1);
        return (False xx self.length).List unless $v.defined && $v.Int;
        my $bytes = nativecast(CArray[uint8], $v);
        my int $n = self.length;
        my @out;
        @out.push: (($bytes[$_ +> 3] +& (1 +< ($_ +& 7))) != 0) for ^$n;
        @out.List;
    }

    #| UTF-8 column: buffer 1 holds int32 offsets, buffer 2 the bytes.
    #| The payload is copied once per chunk, then sliced by offset.
    method strs(--> List)
    {
        my int $n = self.length;
        my $offs = nativecast(CArray[int32], self.buffer(1));
        my int $total = $offs[$n];
        my $ca = CArray[uint8].allocate($total + 1);
        copy-bytes(nativecast(Pointer, $ca), self.buffer(2), $total);
        my $buf = Buf.new($ca[^$total]);
        my $all = $buf.decode('utf-8');
        my @out;
        if $all.chars == $total {
            # ASCII: byte and char offsets coincide, slice the decoded string.
            @out.push: $all.substr($offs[$_], $offs[$_ + 1] - $offs[$_]) for ^$n;
        }
        else {
            @out.push: $buf.subbuf($offs[$_], $offs[$_ + 1] - $offs[$_]).decode('utf-8') for ^$n;
        }
        @out.List;
    }
}

#| A whole chunk seen as an Arrow struct array: children are the columns.
class Chunk is export {
    has ArrowArray $!root;
    has Pointer $!addr;
    has $!holder;              # keeps the backing allocation alive
    has Bool $!freed = False;

    submethod BUILD(:$!root!, :$!addr!, :$!holder) { }

    #| Rows in the chunk.
    method length(--> Int) { $!root.length.Int }
    #| Number of columns, i.e. children of the root struct array.
    method columns(--> Int) { $!root.n-children.Int }

    #| Address of the root ArrowArray struct (for low-level callers).
    method addr(--> Pointer) { $!addr }

    #| Column `$i` as a `Column` view; dies when the index is out of range.
    method column(int $i --> Column)
    {
        die "column $i out of range (0..{$!root.n-children - 1})"
            if $i < 0 || $i >= $!root.n-children;
        my $base = $!root.children;
        my $raw = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
        my $p = Pointer.new($raw.Int);
        Column.new(arr => nativecast(ArrowArray, $p), addr => $p);
    }

    #| Hand the array back to its producer.  Required: native memory is not
    #| garbage collected.  Calling this twice is a no-op -- DuckDB's release
    #| callback does not clear `release-fn`, so the flag is tracked here.
    method free(--> Nil)
    {
        return if $!freed;
        $!freed = True;
        return unless $!root.release-fn.defined && $!root.release-fn.Int;
        release-array($!addr);
        Nil;
    }
}

#| A whole-result Arrow schema.
#|
#| The root is a struct array whose children are the columns, each carrying an
#| Arrow format string: `l` int64, `g` double, `u` utf8, `b` boolean, `tdD`
#| date32, `tsm:` timestamp[ms], `+l` list, `+s` struct, `+m` map.
#|
#| This is the half a `RecordBatch._import_from_c(array_addr, schema_addr)`
#| needs on the other end -- without it the buffers are untyped.
class Schema is export {
    has ArrowSchema $!root;
    has Pointer $!addr;
    has $!holder;              # keeps the backing allocation alive
    has Bool $!freed = False;

    #| Everything the schema borrows from, released only in `.free`.
    #|
    #| `duckdb_to_arrow_schema` does not copy the format strings or the child
    #| array: they point into the arrow options and the logical types it was
    #| built from.  Freeing those right after the call (which is what 1.1.0
    #| did at first) leaves a schema that still reads its root format and then
    #| segfaults the moment a child is touched.
    has $!owned-options;       # untyped: child nodes carry nothing
    has @!owned-types;

    #| Every column name, as the `CArray[uint8]` buffers the child schemas
    #| point at, plus the pointer array handed to `duckdb_to_arrow_schema`.
    #|
    #| `duckdb_to_arrow_schema` stores the name *pointers* into the children
    #| and copies no bytes.  Holding them in a local `@keep-str` (what 1.1.0
    #| did) leaves the schema reading memory that GC may reclaim as soon as
    #| the function returns: on Linux that is an immediate SIGSEGV the moment
    #| a name is touched, while on Windows the freed block usually still reads
    #| back correctly, so the bug only showed up on one platform.
    has $!owned-strings;
    has $!names;

    submethod BUILD(:$!root!, :$!addr!, :$!holder, :$!owned-options,
                    :@!owned-types, :$!owned-strings, :$!names) { }

    #| Guard every reader: after `.free` the struct and everything it points
    #| at belongs to the producer.  Reading it is undefined behaviour that
    #| reads as a segfault rather than an error, so say what happened.
    method !alive(--> Nil)
    {
        die 'this arrow schema has already been freed'
            if $!freed;
    }

    #| Arrow format string of this node (`+s` for the root).
    method format(--> Str) { self!alive; cstr($!root.format) }
    #| Field name (`""` for the root).
    method name(--> Str) { self!alive; cstr($!root.name) }
    #| Number of child nodes: the column count, on the root.
    method n-children(--> Int) { self!alive; $!root.n-children.Int }

    #| Address of the root ArrowSchema struct (for low-level callers).
    method addr(--> Pointer) { self!alive; $!addr }

    #| Child node `$i`; dies when the index is out of range.
    method column(int $i --> Schema)
    {
        self!alive;
        die "column $i out of range (0..{$!root.n-children - 1})"
            if $i < 0 || $i >= $!root.n-children;
        my $base = $!root.children;
        my $raw = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
        my $p = Pointer.new($raw.Int);
        Schema.new(root => nativecast(ArrowSchema, $p), addr => $p);
    }

    #| Every child node, in column order.
    method children(--> List)
    {
        (^self.n-children).map({ self.column($_) }).List;
    }

    #| `name` and `format` per column, descending into `children` for nested
    #| types.  Enough to check a schema without walking the tree by hand.
    method fields(--> List)
    {
        self.children.map(-> $c {
            my %f = name => $c.name, format => $c.format;
            %f<children> = $c.fields if $c.n-children;
            %f;
        }).List;
    }

    #| Hand the schema back to its producer; idempotent.
    #|
    #| Goes through `release-schema`, not `release-array`: the callbacks sit at
    #| different offsets in the two structs, and using the array path here
    #| jumps through the schema's `dictionary` pointer.
    method free(--> Nil)
    {
        return if $!freed;
        $!freed = True;

        release-schema($!addr)
            if $!root.release-fn.defined && $!root.release-fn.Int;

        # Order matters: the schema points into both of these, so it goes
        # first and they go after.
        if $!owned-options.defined && $!owned-options.Int {
            my Pointer $o = $!owned-options;
            destroy-arrow-options($o);
        }
        for @!owned-types -> $lt {
            my $t = $lt;
            duckdb-destroy-logical-type($t);
        }
        Nil;
    }

    method gist(--> Str)
    {
        my @lines = 'struct {';
        for self.fields -> %f {
            my $tag = %f<children> ?? '  (' ~ %f<children>.elems ~ ' nested)' !! '';
            @lines.push: "  {%f<name>}: {%f<format>}$tag";
        }
        @lines.push: '}';
        @lines.join("\n");
    }
}

#| Arrow schema for a whole result.  Works whether or not the result has any
#| chunks -- an empty table still has a schema, which is exactly the case a
#| chunk-derived schema cannot answer.
our sub arrow-schema(DB::DuckDB::Result $result --> Schema) is export
{
    my $raw = $result.raw;
    my uint64 $n = duckdb-column-count($raw);

    my $opts = result-arrow-options($raw);
    die 'could not read arrow options from the result'
        unless $opts.defined && $opts.Int;

    my $types = CArray[Pointer].allocate($n);
    my $names = CArray[Pointer].allocate($n);
    my @keep-str;              # keeps the name buffers alive
    my @logical;               # ownership passes to the Schema on success

    # Failure cleanup only.  A `LEAVE` phaser cannot do this job: it runs on
    # the normal return path too, and freeing the options there is exactly what
    # leaves a live schema pointing at released memory.
    CATCH {
        default {
            for @logical -> $lt {
                my $t = $lt;
                duckdb-destroy-logical-type($t);
            }
            my Pointer $o = $opts;
            destroy-arrow-options($o);
            .rethrow;
        }
    }

    for ^$n -> uint64 $i {
        my $lt = duckdb-column-logical-type($raw, $i);
        @logical.push: $lt;
        $types[$i] = nativecast(Pointer, $lt);
        $names[$i] = c-alloc-str(cstr(duckdb-column-name($raw, $i)), @keep-str);
    }

    my $holder = CArray[uint8].allocate(ARROW-ARRAY-SIZE);
    my Pointer $addr = nativecast(Pointer, $holder);
    check-arrow-call(
        to-arrow-schema($opts, nativecast(Pointer, $types),
                        nativecast(Pointer, $names), $n, $addr),
        'duckdb_to_arrow_schema',
    );

    my $root = nativecast(ArrowSchema, $addr);
    die 'arrow schema conversion produced no release callback'
        unless $root.release-fn.defined && $root.release-fn.Int;

    # `$types` and `$names` are done being read once the call returns, but the
    # name *buffers* they point at are not: the children borrowed those
    # pointers, so the Schema has to own them for as long as it lives.
    Schema.new(root => $root, addr => $addr, holder => $holder,
               owned-options => $opts, owned-types => @logical,
               owned-strings => @keep-str, names => $names);
}

#| Every chunk of `$result` together with the result's schema, which is built
#| once and reused.  This is the shape a RecordBatch importer wants: one
#| schema, many arrays.
our sub with-arrow-table(DB::DuckDB::Result $result, &code --> Nil) is export
{
    my $schema = arrow-schema($result);
    LEAVE $schema.free;

    my uint64 $n = duckdb-result-chunk-count($result.raw);
    for ^$n -> uint64 $ci {
        my $chunk = arrow-chunk($result, $ci);
        LEAVE $chunk.free;
        code($schema, $chunk, $ci);
    }
    Nil;
}

#| Convert a foreign Arrow schema into DuckDB's type map.
#|
#| Returns a `duckdb_arrow_converted_schema` to hand to `arrow-import-chunk`;
#| release it with `arrow-destroy-converted` when done.
our sub arrow-import-schema(DuckDB-Connection $conn, Pointer $schema --> Pointer) is export
{
    my $out = CArray[Pointer].allocate(1);
    check-arrow-call(schema-from-arrow($conn, $schema, $out),
                     'duckdb_schema_from_arrow');
    die 'duckdb_schema_from_arrow returned no converted schema'
        unless $out[0].defined && $out[0].Int;
    Pointer.new($out[0].Int);
}

#| Convert a foreign Arrow array into a DuckDB data chunk.
#|
#| The array's ownership passes to the chunk, so the caller must not release
#| the array afterwards.  The returned chunk belongs to the caller and must be
#| destroyed with `duckdb-destroy-data-chunk`.
our sub arrow-import-chunk(DuckDB-Connection $conn, Pointer $array, Pointer $converted --> Pointer) is export
{
    my $out = CArray[Pointer].allocate(1);
    check-arrow-call(chunk-from-arrow($conn, $array, $converted, $out),
                     'duckdb_data_chunk_from_arrow');
    die 'duckdb_data_chunk_from_arrow returned no chunk'
        unless $out[0].defined && $out[0].Int;
    Pointer.new($out[0].Int);
}

#| Release a converted schema obtained from `arrow-import-schema`.
our sub arrow-destroy-converted(Pointer $converted --> Nil) is export
{
    return unless $converted.defined && $converted.Int;
    my Pointer $c = $converted;
    destroy-arrow-converted-schema($c);
    Nil;
}

#| Convert chunk `$idx` of `$result` into an arrow struct array.  The caller
#| owns the result and must call `.free` on the returned object.
our sub arrow-chunk(DB::DuckDB::Result $result, uint64 $idx --> Chunk) is export
{
    my $raw = $result.raw;
    my $chunk = duckdb-result-get-chunk($raw, $idx);
    die "no chunk at index $idx" unless $chunk.defined && $chunk.Bool;

    # The struct has to live in a plain byte buffer: a CArray[ArrowArray]
    # element cannot be handed to native code as a writable out-parameter
    # (DuckDB would write into a temporary, leaving the release pointer unset).
    my $holder = CArray[uint8].allocate(ARROW-ARRAY-SIZE);
    my Pointer $addr = nativecast(Pointer, $holder);

    # Options were leaked on every call before 1.1.0: the struct is allocated
    # by duckdb_result_get_arrow_options and nothing ever freed it, so a long
    # arrow loop grew without bound for a reason unrelated to the data.
    my $opts = result-arrow-options($raw);
    LEAVE {
        my Pointer $o = $opts;
        destroy-arrow-options($o);
    }

    check-arrow-call(chunk-to-arrow($opts, $chunk, $addr),
                     'duckdb_data_chunk_to_arrow');

    # duckdb_result_get_chunk hands back a chunk that the *caller* owns (the
    # duckdb.h contract says to destroy it), and the Arrow conversion copies
    # the data into Arrow-owned buffers, so the source chunk can go back right
    # away.  Skipping this leaks one chunk per call: measured 235 KB per
    # 2048-row chunk, i.e. ~23 MB per 200k-row result.
    duckdb-destroy-data-chunk($chunk);

    my $root = nativecast(ArrowArray, $addr);
    die "arrow conversion failed at chunk $idx"
        unless $root.release-fn.defined && $root.release-fn.Int;

    Chunk.new(root => $root, addr => $addr, holder => $holder);
}

#| Every chunk of `$result` as an arrow struct array, handed to `&code` and
#| released afterwards.
our sub with-arrow-chunks(DB::DuckDB::Result $result, &code --> Nil) is export
{
    my uint64 $n = duckdb-result-chunk-count($result.raw);
    for ^$n -> uint64 $ci {
        my $chunk = arrow-chunk($result, $ci);
        LEAVE $chunk.free;
        code($chunk, $ci);
    }
    Nil;
}
