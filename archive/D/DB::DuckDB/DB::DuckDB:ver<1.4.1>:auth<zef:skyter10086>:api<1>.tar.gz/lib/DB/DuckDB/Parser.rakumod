use v6.d;
use DB::DuckDB::Native;
use DB::DuckDB::Error;

#| 用 DuckDB 自己的解析器给 SQL 分类，而不是靠文本匹配。
#|
#| 两条 C API 就够：
#|   duckdb_extract_statements           把一段文本拆成 N 条语句
#|   duckdb_prepare_extracted_statement  逐条编译，拿类型与参数个数
#|
#| 编译只生成计划，不执行，所以可以当分类器用。代价是**绑定期检查也会发生**：
#| 表不存在的 `INSERT INTO nope ...` 会在这里报错，而不是报出「这是个 INSERT」。
#| 这个取舍是对的——那条 SQL 本来也跑不了。
#|
#| 为什么要它：文本匹配挡不住 `WITH d AS (DELETE FROM t RETURNING *) SELECT *
#| FROM d`（顶层是 SELECT），也数不清注释里的分号。解析器不会看错。
unit module DB::DuckDB::Parser;

#| `duckdb_statement_type` 的取值，抄自 duckdb.h。
my constant %TYPE-NAME = %(
    0  => 'INVALID',      1  => 'SELECT',       2  => 'INSERT',
    3  => 'UPDATE',       4  => 'EXPLAIN',      5  => 'DELETE',
    6  => 'PREPARE',      7  => 'CREATE',       8  => 'EXECUTE',
    9  => 'ALTER',        10 => 'TRANSACTION',  11 => 'COPY',
    12 => 'ANALYZE',      13 => 'VARIABLE_SET', 14 => 'CREATE_FUNC',
    15 => 'DROP',         16 => 'EXPORT',       17 => 'PRAGMA',
    18 => 'VACUUM',       19 => 'CALL',         20 => 'SET',
    21 => 'LOAD',         22 => 'RELATION',     23 => 'EXTENSION',
    24 => 'LOGICAL_PLAN', 25 => 'ATTACH',       26 => 'DETACH',
    27 => 'MULTI',
);

#| 只读的语句类型。只有 SELECT 和 EXPLAIN 算。
#|
#| 注意 EXPLAIN **不是**安全通行证：`EXPLAIN ANALYZE DELETE FROM t` 也报
#| EXPLAIN，但它会真的执行。所以调用方还需要自己扫一遍写操作关键字——
#| 本模块只回答「DuckDB 把它归到哪一类」。
my constant %READ-ONLY = set(1, 4);

#| 一条被解析出来的语句。
class ParsedStatement is export {
    has Int $.type-id = 0;
    has Str $.type = 'INVALID';
    has Int $.params = 0;

    #| False 表示 prepare 就没过（表不存在、语法边界问题等）。此时 `type`
    #| 不可信，`error` 里有 DuckDB 的原话。
    has Bool $.prepared = True;
    has Str $.error;

    #| DuckDB 会把这条语句当成只读的吗？不涉及外部访问、不涉及写语义的
    #| 判断由调用方补充（见模块文档）。
    method read-only(--> Bool) {
        $!prepared && %READ-ONLY{$!type-id};
    }

    method gist(--> Str) {
        $!prepared
            ?? "{$!type} ({$!params} param{$!params == 1 ?? '' !! 's'})"
            !! "unpreparable: {$!error // ''}";
    }
}

#| 语句类型编号 -> 名字。
our sub statement-type-name(Int:D $id --> Str) is export {
    %TYPE-NAME{$id} // "UNKNOWN($id)";
}

#| 把一条 SQL 拆开并逐条分类。
#|
#| 返回 `List of ParsedStatement`。**错误分两种，别混**：
#|   * 整段文本解析不了（语法错、空语句）—— 直接 die `DB::DuckDB::Error`；
#|   * 某条语句编译不了（表不存在等）—— 返回 `prepared => False` 的条目，
#|     让调用方自己决定要不要把它当成致命错误。
#|
#| 分两种是因为用途不同：前者说明「这段文本不是 SQL」，后者说明「这是 SQL，
#| 但现在跑不了」——只有调用方知道后者该不该拦。
our sub parse-sql($conn, Str:D $sql --> List) is export {
    my DuckDB-Extracted $extracted .= new;
    my uint64 $count = duckdb-extract-statements($conn.handle, $sql, $extracted);

    if $count == 0 {
        my Str $msg = take-cstr(duckdb-extract-statements-error($extracted));
        duckdb-destroy-extracted($extracted) if $extracted.Bool;
        die DB::DuckDB::Error.new(
            message => $msg.chars ?? $msg !! 'empty SQL statement (nothing to parse)',
        );
    }

    my @out;
    for ^$count -> uint64 $i {
        my DuckDB-Prepared $prepared .= new;
        my int32 $rc = duckdb-prepare-extracted-statement(
            $conn.handle, $extracted, $i, $prepared);

        if $rc != 0 {
            my Str $err = take-cstr(duckdb-prepare-error($prepared));
            duckdb-destroy-prepare($prepared) if $prepared.Bool;
            @out.push: ParsedStatement.new(:!prepared, error => $err);
            next;
        }

        my Int $type-id = duckdb-prepared-statement-type($prepared);
        @out.push: ParsedStatement.new(
            :$type-id,
            type   => statement-type-name($type-id),
            params => duckdb-nparams($prepared),
        );
        duckdb-destroy-prepare($prepared);
    }

    duckdb-destroy-extracted($extracted);
    @out.List;
}

#| 只要类型名的便捷版：`('SELECT',)`、`('SELECT', 'INSERT')`。
our sub statement-types($conn, Str:D $sql --> List) is export {
    parse-sql($conn, $sql).map(*.type).List;
}
