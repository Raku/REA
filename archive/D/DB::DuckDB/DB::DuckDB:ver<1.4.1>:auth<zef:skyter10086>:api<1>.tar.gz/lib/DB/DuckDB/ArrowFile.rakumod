#| File level Arrow IPC reading and writing on top of DuckDB.
#|
#| Why this module exists
#| ======================
#| DuckDB 2.0 ships no Arrow IPC entry point of its own, but the community
#| extension `nanoarrow` does: a `read_arrow` table function, a
#| `COPY ... (FORMAT ARROW|ARROWS)` writer, `to_arrow_ipc` for turning a
#| table into IPC messages, and `scan_arrow_ipc` for the reverse.  This
#| module is the SQL half of that -- statement builders plus the extension
#| gate -- mirroring `DB::DuckDB::Parquet`.
#|
#| Measured on this machine (Windows, DuckDB 2.0.0, 50k rows x 3 columns,
#| 1.4 MB file): reading costs 4 ms and writing 44 ms, against 1.58 s /
#| 2.79 s for a pure Raku IPC codec.  The remaining cost is not in Arrow
#| at all -- it is Raku boxing 150k values out of the result.
#|
#| Naming
#| ======
#| `DB::DuckDB::Arrow` is the C data interface (chunk <-> ArrowArray).
#| This module is about *files*, hence `ArrowFile`.
#|
#| Escaping rules
#| ==============
#| * **Reads bind the path as a parameter**, so nothing about the path is
#|   ever parsed as SQL: quotes, backslashes and Windows drive letters all
#|   work unchanged.
#| * **Writes interpolate** the target path and the table name, because
#|   `COPY` takes a literal there.  Both go through the Parquet module's
#|   `parquet-literal` / `parquet-ident`, which are the generic SQL rules
#|   (there is nothing Parquet specific about them), and the compression
#|   name is checked against a whitelist instead of being pasted through.
unit module DB::DuckDB::ArrowFile;

use DB::DuckDB::Error;
use DB::DuckDB::Parquet;   # parquet-literal / parquet-ident / parquet-source:
                           # SQL quoting rules are format independent, so they
                           # live in one place instead of being forked here.

#| The community extension that provides every Arrow IPC function used here.
our constant ARROW-EXTENSION = 'nanoarrow';

#| `:format` values accepted by `arrow-write-sql`, mapped to the SQL word.
#| `file` is the Arrow IPC *file* form (footer, random access, what pandas'
#| `read_feather` and polars' `read_ipc` expect); `stream` is the length
#| prefixed form with no footer.
our constant ARROW-WRITE-FORMATS = %(file => 'arrow', stream => 'arrows');

#| File name extensions that mean "write the stream form".  Everything
#| else (`.arrow`, `.feather`, `.ipc`) writes the file form -- reading does
#| not care, DuckDB sniffs the content.
our constant ARROW-STREAM-EXTENSIONS = <arrows>;

#| Compression names the writer accepts.  Anything outside this list is
#| rejected before the statement is built, so a caller's string can never
#| reach the parser as raw SQL.
our constant ARROW-COMPRESSIONS = <uncompressed lz4 zstd>;

our constant ARROW-MISSING-MESSAGE =
    "Arrow file I/O needs DuckDB's nanoarrow community extension, which this "
  ~ "instance does not have loaded. Install it with: INSTALL nanoarrow FROM "
  ~ "community;  then load it with: LOAD nanoarrow;  -- or pass :install to "
  ~ "have the driver run both (that needs access to DuckDB's community "
  ~ "extension repository).";

#| The `installed` / `loaded` row of `duckdb_extensions()`, or an empty Hash
#| when the extension is unknown to this build.
my sub extension-row($conn --> Hash)
{
    my @rows = $conn.query(
        "select installed, loaded from duckdb_extensions() "
      ~ "where extension_name = 'nanoarrow'"
    ).hashes.List;

    @rows.elems ?? @rows[0] !! Hash;
}

#| Whether this DuckDB build ships the extension (installed on disk), which
#| is not the same as it being loaded into the current database instance.
our sub arrow-installed($conn --> Bool) is export
{
    so extension-row($conn)<installed>;
}

#| Whether the extension is live in this database instance.  `LOAD` is
#| instance wide, so this is true for every connection of the same database
#| as soon as one of them loaded it.
our sub arrow-loaded($conn --> Bool) is export
{
    so extension-row($conn)<loaded>;
}

#| Make Arrow IPC usable on `$conn`, or die with an actionable message.
#|
#| * already loaded -> True (one cheap catalog query, no statement)
#| * installed, not loaded -> LOAD
#| * not installed -> only with `:install` do we reach the network:
#|   `INSTALL nanoarrow FROM community` then LOAD.  The default is False on
#|   purpose -- a plain "read this file" call should not download anything.
#|
#| `LOAD` is idempotent, so callers may cache the answer; `Connection` does.
our sub ensure-arrow($conn, Bool :$install = False --> Bool) is export
{
    my %row = extension-row($conn);
    return True if %row<loaded>;

    if !%row<installed> {
        die DB::DuckDB::Error.new(message => ARROW-MISSING-MESSAGE) unless $install;

        my Str $err = '';
        my Bool $ok = False;

        {
            CATCH { default { $err = .message } }
            $conn.execute('install nanoarrow from community', :finish(False));
            $ok = True;
        }

        die DB::DuckDB::Error.new(
            message => "installing the nanoarrow extension failed: {$err} "
                     ~ "(INSTALL nanoarrow FROM community needs network access "
                     ~ "to DuckDB's community extension repository)",
        ) unless $ok;
    }

    my Str $err = '';

    {
        CATCH { default { $err = .message } }
        $conn.execute('load nanoarrow', :finish(False));
        return True;
    }

    # A load failure right after a successful install is almost always a
    # version mismatch: extensions are built per DuckDB version and live in
    # `~/.duckdb/extensions/<version>/<platform>/`, so upgrading the driver
    # leaves the old build behind.
    die DB::DuckDB::Error.new(
        message => "nanoarrow is installed but LOAD failed: {$err} "
                 ~ "(extensions are built per DuckDB version; after upgrading "
                 ~ "the driver, reinstall with: INSTALL nanoarrow FROM community;)",
    );
}

#| Writing format implied by a file name: `.arrows` is the stream form,
#| everything else is the file form.
our sub arrow-format-for(Str:D $path --> Str) is export
{
    $path.IO.extension.lc eq any(ARROW-STREAM-EXTENSIONS) ?? 'stream' !! 'file';
}

#| Normalise `:columns`, which callers pass either as one value
#| (`:columns<id>`) or as a list (`:columns<id name>`).  A bare Str is not a
#| Positional, so a `:@columns` parameter would reject the single-value form
#| -- which is the one people write first.
my sub as-list($value --> List)
{
    return () unless $value.defined;
    $value ~~ Positional ?? $value.List !! ($value,).List;
}

#| `select <cols> from read_arrow(?, ...)`, with one placeholder per path
#| when several files are read at once.
#|
#| Projection is not cosmetic: DuckDB pushes the column list into the
#| `READ_ARROW` scan, so only the requested columns are decoded
#| (`EXPLAIN ANALYZE` shows `Projections: id` under the scan).
our sub arrow-read-sql(:columns($columns),
                       Bool :union-by-name($union-by-name) = False,
                       Bool :$filename = False,
                       Bool :hive-partitioning($hive-partitioning),
                       Int :path-count($path-count) = 1 --> Str) is export
{
    die DB::DuckDB::Error.new(message => 'path-count must be at least 1')
        unless $path-count >= 1;

    my @column-names = as-list($columns);

    my @select = @column-names.elems
        ?? @column-names.map({ parquet-ident($_.Str) })
        !! ('*',);

    my $argument = $path-count > 1
        ?? '[' ~ ('?' xx $path-count).join(', ') ~ ']'
        !! '?';

    my @opts;
    @opts.push: 'union_by_name = true'  if $union-by-name;
    @opts.push: 'filename = true'       if $filename;
    @opts.push: 'hive_partitioning = ' ~ ($hive-partitioning ?? 'true' !! 'false')
        if $hive-partitioning.defined;

    my $arglist = @opts.elems ?? $argument ~ ', ' ~ @opts.join(', ') !! $argument;

    "select {@select.join(', ')} from read_arrow({$arglist})";
}

#| `copy <source> to 'path' (format arrow, batch_size n, compression zstd)`.
#|
#| `$sql` marks the source as a query instead of a table name; a query is
#| wrapped in parentheses, a table name is quoted and may carry a schema.
#| `batch_size` is rows per record batch, which is what decides how many
#| batches a reader sees (and how much a streaming reader can consume at a
#| time); it is not a memory limit.
#|
#| `format arrow` (the file form) is not in DuckDB's documentation -- the
#| docs only show `format arrows` -- but it is what version 2.0.0 writes,
#| and the result is a standard IPC file whose footer pyarrow and pandas
#| both read.  `t/20-arrow-file` pins it, so a future DuckDB that changes
#| the spelling fails loudly instead of silently writing the wrong format.
our sub arrow-write-sql(Str:D $target, Str:D $source, Bool :$sql = False,
                        Str :$schema, Str :$format = 'file',
                        Int :batch-size($batch-size),
                        Str :$compression --> Str) is export
{
    die DB::DuckDB::Error.new(message => 'target path must not be empty')
        unless $target.chars;

    die DB::DuckDB::Error.new(
        message => "unsupported Arrow format '{$format}'; expected one of "
                 ~ ARROW-WRITE-FORMATS.keys.sort.join(', '),
    ) unless ARROW-WRITE-FORMATS{$format}:exists;

    my $from = $sql ?? "({$source})" !! parquet-source($source, :$schema);

    my @opts = 'format ' ~ ARROW-WRITE-FORMATS{$format};

    if $compression.defined {
        my $codec = $compression.lc;
        unless $codec eq any(ARROW-COMPRESSIONS) {
            die DB::DuckDB::Error.new(
                message => "unsupported Arrow compression '{$compression}'; "
                         ~ "expected one of {ARROW-COMPRESSIONS.join(', ')}",
            );
        }
        @opts.push: "compression {$codec}";
    }

    if $batch-size.defined {
        die DB::DuckDB::Error.new(message => "batch-size must be positive, got {$batch-size}")
            unless $batch-size > 0;
        @opts.push: "batch_size {$batch-size}";
    }

    "copy {$from} to {parquet-literal($target)} ({@opts.join(', ')})";
}

#| `select ipc from to_arrow_ipc(<source>, compression := 'zstd', ...)`.
#|
#| The extension's options are named arguments, not positional ones, which
#| is why they use `:=` rather than `=`.  Each result row is one IPC
#| message in stream order: the schema message first (`header = true`),
#| then one per record batch.
#|
#| A table name is passed as `(select * from "name")`, never bare: handing
#| `to_arrow_ipc` a table reference instead of a subquery trips an internal
#| assertion inside the extension (`Expected struct child 1 to have length
#| >= 1 but found child with length 0`) on DuckDB 2.0.0.  The subquery form
#| is also what the extension's own documentation shows.
our sub arrow-to-ipc-sql(Str:D $source, Bool :$sql = False, Str :$schema,
                         Str :$compression, Int :$compression-level --> Str) is export
{
    my $from = $sql
        ?? "({$source})"
        !! "(select * from {parquet-source($source, :$schema)})";

    my @opts;
    if $compression.defined {
        my $codec = $compression.lc;
        unless $codec eq any(ARROW-COMPRESSIONS) {
            die DB::DuckDB::Error.new(
                message => "unsupported Arrow compression '{$compression}'; "
                         ~ "expected one of {ARROW-COMPRESSIONS.join(', ')}",
            );
        }
        @opts.push: 'compression := ' ~ parquet-literal($codec);
        @opts.push: "compression_level := {$compression-level}" if $compression-level.defined;
    }

    my $arglist = @opts.elems ?? "{$from}, {@opts.join(', ')}" !! $from;

    "select ipc from to_arrow_ipc({$arglist})";
}
