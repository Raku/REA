use NativeCall;
use Alien::Libduckdb;
use DB::DuckDB::Bridge;

#| NativeCall layer for libduckdb — DuckDB C API, targeting **DuckDB 2.0**
#| (ABI documented by duckdb.h shipped with v2.0.0).
#|
#| Design notes
#| ============
#| * Only the flat C API is bound.  In 2.0 exactly two functions still take
#|   `duckdb_result` *by value*: `duckdb_fetch_chunk` and
#|   `duckdb_result_chunk_count`.  NativeCall can only pass a CStruct by
#|   address, which coincides with the Microsoft x64 convention (large
#|   structs travel by reference) but not with SysV (they go on the stack),
#|   so on Linux/macOS those two go through a tiny compiled bridge instead --
#|   see DB::DuckDB::Bridge.  Every other result accessor already takes
#|   `duckdb_result *` and binds directly.
#| * Result rows are read through the chunk/vector API introduced in 2.0:
#|     duckdb_fetch_chunk -> duckdb_data_chunk_get_vector ->
#|     duckdb_vector_get_data / duckdb_vector_get_validity
#|   This is the stable, non-deprecated path and is used whenever every
#|   column of the result is a scalar or VARCHAR.
#| * Results that contain rich types (DATE/TIME/TIMESTAMP/DECIMAL/HUGEINT/
#|   LIST/STRUCT/MAP/UUID/ENUM/BLOB/...) fall back to the deprecated but
#|   still-exported `duckdb_value_*` accessors, which return DuckDB's own
#|   textual rendering.  The two paths are never mixed inside one result,
#|   because `duckdb_fetch_chunk` consumes the materialised result.
#| * `duckdb_result` layout is unchanged in 2.0 and asserted at load time.
unit module DB::DuckDB::Native;

#========================================================================
# Library discovery
#========================================================================

my Str $lib-path;

#| Ask Alien::Libduckdb where it put the library it built.  Returned as an
#| empty IO::Path when the alien module has not built anything yet (e.g. the
#| module was installed with :no-build), so the caller can fall back to the
#| legacy probing below.
sub alien-lib(--> IO::Path)
{
    return IO::Path unless try { Alien::Libduckdb::installed() };
    my $p = try { Alien::Libduckdb::shared-lib() };
    $p.defined ?? $p.IO !! IO::Path;
}

#| Resolve the DuckDB shared library.  Order of precedence:
#|   1. %DB_DUCKDB_LIB environment variable
#|   2. the library built by Alien::Libduckdb (the declared dependency)
#|   3. libduckdb / duckdb next to the running Rakudo executable
#|      (covers `C:\rakudo\bin`, where v2.0 ships both names)
#|   4. resources/libraries shipped with the distribution
#|   5. usual system locations
#|   6. bare `duckdb`, letting the OS loader search
sub duckdb-lib(--> Str) is export
{
    return $lib-path if $lib-path.defined;

    with %*ENV<DB_DUCKDB_LIB> {
        return $lib-path = .IO.absolute if .chars && .IO.e;
    }

    my $alien = alien-lib();
    return $lib-path = $alien.absolute if $alien.defined && $alien.e;

    my $ext = $*DISTRO.is-win
        ?? '.dll'
        !! ($*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so');

    my $bin-dir = $*EXECUTABLE.parent;
    my @candidates = (
        $bin-dir.add("libduckdb$ext"),
        $bin-dir.add("duckdb$ext"),
    );

    # Look for a library shipped in resources/libraries.  When the
    # distribution declares no resources at all (the usual case here, since
    # the DLL is expected next to the interpreter), asking for a missing
    # entry makes CompUnit::Repository stringify an undefined value and warn
    # -- hence `quietly` around the probe.
    my $res-path = quietly { %?RESOURCES<libraries/duckdb> };
    @candidates.push($res-path.IO)
        if $res-path ~~ IO::Path && $res-path.IO.e;

    @candidates.append:
        "/usr/local/lib/libduckdb$ext",
        "/usr/lib/libduckdb$ext",
        "/opt/homebrew/lib/libduckdb$ext";

    for @candidates -> $cand {
        return $lib-path = $cand.absolute if $cand.IO.e;
    }

    $lib-path = 'duckdb';
}

#| Library that the two by-value result accessors must bind against.  On
#| SysV this is the compiled bridge (pointer in, dereferenced copy on the
#| call site); on Windows the plain library already matches NativeCall.
sub result-api-lib(--> Str)
{
    return duckdb-lib() unless needs-bridge();
    my $shim = bridge-lib();
    $shim.chars ?? $shim !! duckdb-lib();
}

#| Version string of the loaded library, e.g. "v2.0.0".
sub duckdb-linked-version(--> Str) is export
{
    my Pointer $p = duckdb-library-version();
    return '' unless $p.Bool;
    nativecast(Str, $p);
}

#| The DuckDB major version this binding was written against.  The C API is
#| not ABI-stable across majors: `duckdb_result` layout, the DUCKDB_TYPE
#| numbering and the by-value accessors all moved between 1.x and 2.x, so a
#| 3.x library reached through this module would corrupt memory rather than
#| fail cleanly.
constant BINDING-MAJOR is export = 2;

#| Confirm that the library actually loaded matches the ABI bound here.
#| Called before the first database handle is opened, which is the earliest
#| point where the shared library is guaranteed to be resident.  Throws by
#| default; `:!throw` downgrades it to a warning.
sub verify-library(Bool :$throw = True --> Bool) is export
{
    my $reported = duckdb-linked-version();

    # An empty string means the library answered with a null pointer, which
    # is not something we can reason about -- let the real call fail instead
    # of masking it with a bogus version error.
    return True unless $reported.chars;

    my $match = $reported.match(/(\d+)/);
    my $major = $match ?? +$match[0].Str !! 0;
    return True if $major == BINDING-MAJOR;

    my $msg = "DB::DuckDB: libduckdb {$reported} is not ABI-compatible with "
            ~ "this binding, which targets DuckDB {BINDING-MAJOR}.x; "
            ~ "library in use: {duckdb-lib()}.  Install the matching "
            ~ "Alien::Libduckdb (META6.json pins it) or point DB_DUCKDB_LIB "
            ~ "at a {BINDING-MAJOR}.x build.";

    die $msg if $throw;
    note $msg;
    False;
}

#========================================================================
# Enums (values copied verbatim from the 2.0 duckdb.h)
#========================================================================

constant DuckDBSuccess is export = 0;
constant DuckDBError   is export = 1;

# DUCKDB_TYPE as of DuckDB 2.0.  Note that 35 used to be VARINT and is now
# BIGNUM, and that 37..42 are new in 2.0.
constant DUCKDB_TYPE_INVALID          is export = 0;
constant DUCKDB_TYPE_BOOLEAN          is export = 1;
constant DUCKDB_TYPE_TINYINT          is export = 2;
constant DUCKDB_TYPE_SMALLINT         is export = 3;
constant DUCKDB_TYPE_INTEGER          is export = 4;
constant DUCKDB_TYPE_BIGINT           is export = 5;
constant DUCKDB_TYPE_UTINYINT         is export = 6;
constant DUCKDB_TYPE_USMALLINT        is export = 7;
constant DUCKDB_TYPE_UINTEGER         is export = 8;
constant DUCKDB_TYPE_UBIGINT          is export = 9;
constant DUCKDB_TYPE_FLOAT            is export = 10;
constant DUCKDB_TYPE_DOUBLE           is export = 11;
constant DUCKDB_TYPE_TIMESTAMP        is export = 12;
constant DUCKDB_TYPE_DATE             is export = 13;
constant DUCKDB_TYPE_TIME             is export = 14;
constant DUCKDB_TYPE_INTERVAL         is export = 15;
constant DUCKDB_TYPE_HUGEINT          is export = 16;
constant DUCKDB_TYPE_VARCHAR          is export = 17;
constant DUCKDB_TYPE_BLOB             is export = 18;
constant DUCKDB_TYPE_DECIMAL          is export = 19;
constant DUCKDB_TYPE_TIMESTAMP_S      is export = 20;
constant DUCKDB_TYPE_TIMESTAMP_MS     is export = 21;
constant DUCKDB_TYPE_TIMESTAMP_NS     is export = 22;
constant DUCKDB_TYPE_ENUM             is export = 23;
constant DUCKDB_TYPE_LIST             is export = 24;
constant DUCKDB_TYPE_STRUCT           is export = 25;
constant DUCKDB_TYPE_MAP              is export = 26;
constant DUCKDB_TYPE_UUID             is export = 27;
constant DUCKDB_TYPE_UNION            is export = 28;
constant DUCKDB_TYPE_BIT              is export = 29;
constant DUCKDB_TYPE_TIME_TZ          is export = 30;
constant DUCKDB_TYPE_TIMESTAMP_TZ     is export = 31;
constant DUCKDB_TYPE_UHUGEINT         is export = 32;
constant DUCKDB_TYPE_ARRAY            is export = 33;
constant DUCKDB_TYPE_ANY              is export = 34;
constant DUCKDB_TYPE_BIGNUM           is export = 35;
constant DUCKDB_TYPE_SQLNULL          is export = 36;
constant DUCKDB_TYPE_STRING_LITERAL   is export = 37;
constant DUCKDB_TYPE_INTEGER_LITERAL  is export = 38;
constant DUCKDB_TYPE_TIME_NS          is export = 39;
constant DUCKDB_TYPE_GEOMETRY         is export = 40;
constant DUCKDB_TYPE_VARIANT          is export = 41;
constant DUCKDB_TYPE_TIMESTAMP_TZ_NS  is export = 42;

#| Column types that the chunk/vector path can read natively.
my SetHash $VECTOR-TYPES = SetHash.new(
    DUCKDB_TYPE_BOOLEAN,
    DUCKDB_TYPE_TINYINT, DUCKDB_TYPE_SMALLINT,
    DUCKDB_TYPE_INTEGER, DUCKDB_TYPE_BIGINT,
    DUCKDB_TYPE_UTINYINT, DUCKDB_TYPE_USMALLINT,
    DUCKDB_TYPE_UINTEGER, DUCKDB_TYPE_UBIGINT,
    DUCKDB_TYPE_FLOAT, DUCKDB_TYPE_DOUBLE,
    DUCKDB_TYPE_VARCHAR,
);

#| True when every column of the result can be served from a data chunk.
sub vectorisable(Int $column-type --> Bool) is export
{
    $VECTOR-TYPES{$column-type}:exists;
}

#========================================================================
# Opaque handles
#========================================================================

class DuckDB-Database    is repr('CPointer') is export { }
class DuckDB-Connection  is repr('CPointer') is export { }
class DuckDB-Prepared    is repr('CPointer') is export { }
class DuckDB-Data-Chunk  is repr('CPointer') is export { }
class DuckDB-Vector      is repr('CPointer') is export { }
class DuckDB-Logical-Type is repr('CPointer') is export { }
class DuckDB-Appender    is repr('CPointer') is export { }
class DuckDB-Extracted   is repr('CPointer') is export { }

#========================================================================
# duckdb_result (POD, out-parameter)
#========================================================================

# 2.0 layout: idx_t x3, then 3 pointers.  Unchanged from 1.x, but it is
# asserted anyway: a silent ABI change would corrupt every row we read.
class DuckDB-Raw-Result is repr('CStruct') is export
{
    has uint64  $.deprecated-column-count;
    has uint64  $.deprecated-row-count;
    has uint64  $.deprecated-rows-changed;
    has Pointer $.deprecated-columns;
    has Pointer $.deprecated-error-message;
    has Pointer $.internal-data;
}

{
    my $expected = 3 * nativesizeof(uint64) + 3 * nativesizeof(Pointer);
    die "DB::DuckDB::Native: unexpected duckdb_result layout "
      ~ "({nativesizeof(DuckDB-Raw-Result)} bytes, expected $expected); "
      ~ "refusing to bind against an unknown ABI"
        unless nativesizeof(DuckDB-Raw-Result) == $expected;
}

#========================================================================
# Helpers
#========================================================================

#| Copy a NUL-terminated C string that is owned by the caller.
sub take-cstr-free(Pointer $p --> Str) is export
{
    return '' unless $p.Bool;
    my $s = nativecast(Str, $p);
    duckdb-free($p);
    $s;
}

#| Copy a NUL-terminated C string owned by a result/statement.
sub take-cstr(Pointer $p --> Str) is export
{
    return '' unless $p.Bool;
    nativecast(Str, $p);
}

#| DuckDB validity masks: a NULL mask means "all rows valid", otherwise
#| bit N set means row N is valid.
sub row-valid(Pointer $validity, uint64 $row --> Bool) is export
{
    return True unless $validity.Bool;
    my uint64 $word = nativecast(CArray[uint64], $validity)[$row div 64];
    so $word +& (1 +< ($row % 64));
}

#| Raw bytes of a `duckdb_string_t` (16 bytes, inlined when <= 12 bytes).
sub read-string-t-bytes(Pointer $data, uint64 $row --> Buf) is export
{
    my CArray[uint8] $bytes = nativecast(CArray[uint8], $data);
    my uint64 $base = $row * 16;

    my uint32 $len = $bytes[$base]
                   + ($bytes[$base + 1] +< 8)
                   + ($bytes[$base + 2] +< 16)
                   + ($bytes[$base + 3] +< 24);

    my Buf $buf .= new;
    if $len <= 12 {
        $buf.push($bytes[$base + 4 + $_]) for ^$len;
    }
    else {
        my uint64 $addr = 0;
        $addr = $addr + ($bytes[$base + 8 + $_] +< (8 * $_)) for ^8;
        my CArray[uint8] $chars = nativecast(CArray[uint8], Pointer.new($addr));
        $buf.push($chars[$_]) for ^$len;
    }
    $buf;
}

#| Read a `duckdb_string_t` as UTF-8 text.
sub read-string-t(Pointer $data, uint64 $row --> Str) is export
{
    read-string-t-bytes($data, $row).decode('utf-8');
}

#========================================================================
# Database / connection
#========================================================================

sub duckdb-open(Str $path, DuckDB-Database $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_open') is export { }

sub duckdb-close(DuckDB-Database $database is rw)
    is native(&duckdb-lib) is symbol('duckdb_close') is export { }

sub duckdb-connect(DuckDB-Database $database, DuckDB-Connection $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_connect') is export { }

sub duckdb-disconnect(DuckDB-Connection $connection is rw)
    is native(&duckdb-lib) is symbol('duckdb_disconnect') is export { }

sub duckdb-interrupt(DuckDB-Connection $connection)
    is native(&duckdb-lib) is symbol('duckdb_interrupt') is export { }

#========================================================================
# Direct query
#========================================================================

sub duckdb-query(DuckDB-Connection $connection, Str $query, DuckDB-Raw-Result $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_query') is export { }

sub duckdb-destroy-result(DuckDB-Raw-Result $result is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_result') is export { }

sub duckdb-column-count(DuckDB-Raw-Result $result --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_column_count') is export { }

sub duckdb-row-count(DuckDB-Raw-Result $result --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_row_count') is export { }

sub duckdb-rows-changed(DuckDB-Raw-Result $result --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_rows_changed') is export { }

sub duckdb-column-name(DuckDB-Raw-Result $result, uint64 $col --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_column_name') is export { }

sub duckdb-column-type(DuckDB-Raw-Result $result, uint64 $col --> int32)
    is native(&duckdb-lib) is symbol('duckdb_column_type') is export { }

#| Logical type of a result column, straight from the result.
#|
#| Unlike `duckdb-vector-get-column-type` this does not need a data chunk, so
#| it still answers for a result that has no chunks at all (an empty table, a
#| `LIMIT 0` schema probe).  The returned type is owned by the caller: destroy
#| it with `duckdb-destroy-logical-type`.
sub duckdb-column-logical-type(DuckDB-Raw-Result $result, uint64 $col --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_column_logical_type') is export { }

sub duckdb-result-error(DuckDB-Raw-Result $result --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_result_error') is export { }

#========================================================================
# Chunk / vector API (the stable 2.0 read path)
#========================================================================

sub duckdb-result-chunk-count(DuckDB-Raw-Result $result --> uint64)
    is native(&result-api-lib) is symbol(bridge-symbol('duckdb_result_chunk_count')) is export { }

#| Fetch chunk `idx` for reading only.  The returned chunk belongs to the
#| result: do not destroy it, and do not use it after the result is freed.
#| Unlike duckdb_fetch_chunk this leaves the result's own cursor alone.
sub duckdb-result-get-chunk(DuckDB-Raw-Result $result, uint64 $idx --> DuckDB-Data-Chunk)
    is native(&result-api-lib) is symbol(bridge-symbol('duckdb_result_get_chunk')) is export { }

#| Pull the next data chunk out of the result; a null chunk means "done".
#| `duckdb_result` is passed by value here.
sub duckdb-fetch-chunk(DuckDB-Raw-Result $result --> DuckDB-Data-Chunk)
    is native(&result-api-lib) is symbol(bridge-symbol('duckdb_fetch_chunk')) is export { }

#| Pull the next chunk out of a *streaming* result.  Unlike the materialised
#| path the chunk is owned by the caller and must be destroyed with
#| duckdb-destroy-data-chunk once its data has been consumed.
sub duckdb-stream-fetch-chunk(DuckDB-Raw-Result $result --> DuckDB-Data-Chunk)
    is native(&result-api-lib) is symbol(bridge-symbol('duckdb_stream_fetch_chunk')) is export { }

sub duckdb-data-chunk-get-size(DuckDB-Data-Chunk $chunk --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_data_chunk_get_size') is export { }

sub duckdb-data-chunk-get-vector(DuckDB-Data-Chunk $chunk, uint64 $col --> DuckDB-Vector)
    is native(&duckdb-lib) is symbol('duckdb_data_chunk_get_vector') is export { }

sub duckdb-vector-get-data(DuckDB-Vector $vector --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_vector_get_data') is export { }

sub duckdb-vector-get-validity(DuckDB-Vector $vector --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_vector_get_validity') is export { }

sub duckdb-vector-get-column-type(DuckDB-Vector $vector --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_vector_get_column_type') is export { }

sub duckdb-destroy-data-chunk(DuckDB-Data-Chunk $chunk is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_data_chunk') is export { }

sub duckdb-vector-size(--> uint64)
    is native(&duckdb-lib) is symbol('duckdb_vector_size') is export { }

#========================================================================
# Legacy value accessors (deprecated since v1.0, still exported in 2.0)
#========================================================================
# Used only for result sets containing rich types, where the textual
# rendering produced by DuckDB is both exact and lossless.

sub duckdb-value-is-null(DuckDB-Raw-Result $result, uint64 $col, uint64 $row --> bool)
    is native(&duckdb-lib) is symbol('duckdb_value_is_null') is export { }

sub duckdb-value-boolean(DuckDB-Raw-Result $result, uint64 $col, uint64 $row --> bool)
    is native(&duckdb-lib) is symbol('duckdb_value_boolean') is export { }

sub duckdb-value-int64(DuckDB-Raw-Result $result, uint64 $col, uint64 $row --> int64)
    is native(&duckdb-lib) is symbol('duckdb_value_int64') is export { }

sub duckdb-value-uint64(DuckDB-Raw-Result $result, uint64 $col, uint64 $row --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_value_uint64') is export { }

sub duckdb-value-double(DuckDB-Raw-Result $result, uint64 $col, uint64 $row --> num64)
    is native(&duckdb-lib) is symbol('duckdb_value_double') is export { }

#| Returns a freshly allocated char* that the caller must duckdb_free().
sub duckdb-value-varchar(DuckDB-Raw-Result $result, uint64 $col, uint64 $row --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_value_varchar') is export { }

sub duckdb-free(Pointer $ptr)
    is native(&duckdb-lib) is symbol('duckdb_free') is export { }

#========================================================================
# Prepared statements
#========================================================================

sub duckdb-prepare(DuckDB-Connection $connection, Str $query, DuckDB-Prepared $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_prepare') is export { }

sub duckdb-destroy-prepare(DuckDB-Prepared $prepared is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_prepare') is export { }

sub duckdb-prepare-error(DuckDB-Prepared $prepared --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_prepare_error') is export { }

sub duckdb-nparams(DuckDB-Prepared $prepared --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_nparams') is export { }

sub duckdb-clear-bindings(DuckDB-Prepared $prepared --> int32)
    is native(&duckdb-lib) is symbol('duckdb_clear_bindings') is export { }

sub duckdb-bind-parameter-index(DuckDB-Prepared $prepared, uint64 $idx is rw, Str $name --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_parameter_index') is export { }

sub duckdb-bind-boolean(DuckDB-Prepared $prepared, uint64 $idx, bool $val --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_boolean') is export { }

sub duckdb-bind-int64(DuckDB-Prepared $prepared, uint64 $idx, int64 $val --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_int64') is export { }

sub duckdb-bind-double(DuckDB-Prepared $prepared, uint64 $idx, num64 $val --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_double') is export { }

sub duckdb-bind-varchar(DuckDB-Prepared $prepared, uint64 $idx, Str $val --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_varchar') is export { }

sub duckdb-bind-varchar-length(DuckDB-Prepared $prepared, uint64 $idx, Str $val, uint64 $len --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_varchar_length') is export { }

sub duckdb-bind-blob(DuckDB-Prepared $prepared, uint64 $idx, CArray[uint8] $data, uint64 $len --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_blob') is export { }

sub duckdb-bind-null(DuckDB-Prepared $prepared, uint64 $idx --> int32)
    is native(&duckdb-lib) is symbol('duckdb_bind_null') is export { }

sub duckdb-execute-prepared(DuckDB-Prepared $prepared, DuckDB-Raw-Result $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_execute_prepared') is export { }

#| Execute a prepared statement in streaming mode: rows become available one
#| chunk at a time, so the first chunk arrives long before the query has
#| finished and peak memory stays flat.
sub duckdb-execute-prepared-streaming(DuckDB-Prepared $prepared, DuckDB-Raw-Result $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_execute_prepared_streaming') is export { }

sub duckdb-prepared-statement-column-count(DuckDB-Prepared $prepared --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_prepared_statement_column_count') is export { }

#========================================================================
# Statement extraction (parse without executing)
#========================================================================

#| Split a query into statements and hand back an opaque list.  Returns the
#| number of statements, or 0 on failure -- check
#| `duckdb-extract-statements-error` for the reason.  The out handle must be
#| destroyed with `duckdb-destroy-extracted` even when 0 was returned.
sub duckdb-extract-statements(DuckDB-Connection $connection, Str $query,
                              DuckDB-Extracted $out is rw --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_extract_statements') is export { }

#| Prepare one statement out of an extracted list.  Preparing compiles a plan;
#| it does not run anything, so this is safe to use as a classifier.
sub duckdb-prepare-extracted-statement(DuckDB-Connection $connection,
                                       DuckDB-Extracted $extracted,
                                       uint64 $index,
                                       DuckDB-Prepared $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_prepare_extracted_statement') is export { }

sub duckdb-extract-statements-error(DuckDB-Extracted $extracted --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_extract_statements_error') is export { }

sub duckdb-destroy-extracted(DuckDB-Extracted $extracted is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_extracted') is export { }

#| The `duckdb_statement_type` enum of a prepared statement -- 1 is SELECT,
#| 7 CREATE, 11 COPY, 25 ATTACH, and so on.  See `DB::DuckDB::Statement`.
sub duckdb-prepared-statement-type(DuckDB-Prepared $prepared --> int32)
    is native(&duckdb-lib) is symbol('duckdb_prepared_statement_type') is export { }


#========================================================================
# Misc
#========================================================================

sub duckdb-library-version(--> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_library_version') is export { }

#========================================================================
# Logical type introspection (needed by the chunk decoder)
#========================================================================

sub duckdb-get-type-id(DuckDB-Logical-Type $type --> int32)
    is native(&duckdb-lib) is symbol('duckdb_get_type_id') is export { }

sub duckdb-destroy-logical-type(DuckDB-Logical-Type $type is rw)
    is native(&duckdb-lib) is symbol('duckdb_destroy_logical_type') is export { }

sub duckdb-decimal-width(DuckDB-Logical-Type $type --> uint8)
    is native(&duckdb-lib) is symbol('duckdb_decimal_width') is export { }

sub duckdb-decimal-scale(DuckDB-Logical-Type $type --> uint8)
    is native(&duckdb-lib) is symbol('duckdb_decimal_scale') is export { }

sub duckdb-decimal-internal-type(DuckDB-Logical-Type $type --> int32)
    is native(&duckdb-lib) is symbol('duckdb_decimal_internal_type') is export { }

sub duckdb-list-type-child-type(DuckDB-Logical-Type $type --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_list_type_child_type') is export { }

sub duckdb-list-vector-get-child(DuckDB-Vector $vector --> DuckDB-Vector)
    is native(&duckdb-lib) is symbol('duckdb_list_vector_get_child') is export { }

sub duckdb-array-type-child-type(DuckDB-Logical-Type $type --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_array_type_child_type') is export { }

sub duckdb-array-type-array-size(DuckDB-Logical-Type $type --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_array_type_array_size') is export { }

sub duckdb-array-vector-get-child(DuckDB-Vector $vector --> DuckDB-Vector)
    is native(&duckdb-lib) is symbol('duckdb_array_vector_get_child') is export { }

sub duckdb-struct-type-child-count(DuckDB-Logical-Type $type --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_struct_type_child_count') is export { }

sub duckdb-struct-type-child-name(DuckDB-Logical-Type $type, uint64 $index --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_struct_type_child_name') is export { }

sub duckdb-struct-type-child-type(DuckDB-Logical-Type $type, uint64 $index --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_struct_type_child_type') is export { }

sub duckdb-struct-vector-get-child(DuckDB-Vector $vector, uint64 $index --> DuckDB-Vector)
    is native(&duckdb-lib) is symbol('duckdb_struct_vector_get_child') is export { }

sub duckdb-map-type-key-type(DuckDB-Logical-Type $type --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_map_type_key_type') is export { }

sub duckdb-map-type-value-type(DuckDB-Logical-Type $type --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_map_type_value_type') is export { }

sub duckdb-enum-dictionary-size(DuckDB-Logical-Type $type --> uint32)
    is native(&duckdb-lib) is symbol('duckdb_enum_dictionary_size') is export { }

#| Returns a freshly allocated char* that the caller must duckdb_free().
sub duckdb-enum-dictionary-value(DuckDB-Logical-Type $type, uint64 $index --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_enum_dictionary_value') is export { }

#| The integer width the enum keys are stored in: UTINYINT, USMALLINT or
#| UINTEGER.  Needed to read the key vector with the right element size.
sub duckdb-enum-internal-type(DuckDB-Logical-Type $type --> int32)
    is native(&duckdb-lib) is symbol('duckdb_enum_internal_type') is export { }

sub duckdb-union-type-member-count(DuckDB-Logical-Type $type --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_union_type_member_count') is export { }

sub duckdb-union-type-member-name(DuckDB-Logical-Type $type, uint64 $index --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_union_type_member_name') is export { }

sub duckdb-union-type-member-type(DuckDB-Logical-Type $type, uint64 $index --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_union_type_member_type') is export { }

#========================================================================
# Appender (bulk-load write path)
#========================================================================
# The appender is DuckDB's fast ingestion path: values are appended into
# vectors directly instead of going through the SQL parser, and the rows
# are buffered in the appender's own transaction.  It is ~19x faster than
# multi-value INSERT for wide batches (see duckdb-perf-next-steps.md).
#
# `duckdb_appender_create` takes the schema as a `const char *` where a
# NULL pointer means "the connection's default schema", so the parameter
# is bound as a Pointer and callers pass `Pointer` (NULL) unless they want
# an explicit schema.

sub duckdb-appender-create(DuckDB-Connection $connection, Pointer $schema, Str $table, DuckDB-Appender $out is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_appender_create') is export { }

#| Error of the appender, or '' when it is healthy.  The string is owned by
#| the appender and only valid until it is destroyed.
sub duckdb-appender-error(DuckDB-Appender $appender --> Pointer)
    is native(&duckdb-lib) is symbol('duckdb_appender_error') is export { }

sub duckdb-appender-flush(DuckDB-Appender $appender --> int32)
    is native(&duckdb-lib) is symbol('duckdb_appender_flush') is export { }

sub duckdb-appender-close(DuckDB-Appender $appender --> int32)
    is native(&duckdb-lib) is symbol('duckdb_appender_close') is export { }

sub duckdb-appender-destroy(DuckDB-Appender $appender is rw --> int32)
    is native(&duckdb-lib) is symbol('duckdb_appender_destroy') is export { }

sub duckdb-appender-end-row(DuckDB-Appender $appender --> int32)
    is native(&duckdb-lib) is symbol('duckdb_appender_end_row') is export { }

sub duckdb-appender-column-count(DuckDB-Appender $appender --> uint64)
    is native(&duckdb-lib) is symbol('duckdb_appender_column_count') is export { }

#| Logical type of column `$col-idx` of the target table.  The handle is
#| owned by the caller: destroy it with `duckdb-destroy-logical-type` once
#| the type id has been read.
sub duckdb-appender-column-type(DuckDB-Appender $appender, uint64 $col-idx --> DuckDB-Logical-Type)
    is native(&duckdb-lib) is symbol('duckdb_appender_column_type') is export { }

sub duckdb-append-bool(DuckDB-Appender $appender, bool $value --> int32)
    is native(&duckdb-lib) is symbol('duckdb_append_bool') is export { }

sub duckdb-append-int64(DuckDB-Appender $appender, int64 $value --> int32)
    is native(&duckdb-lib) is symbol('duckdb_append_int64') is export { }

sub duckdb-append-double(DuckDB-Appender $appender, num64 $value --> int32)
    is native(&duckdb-lib) is symbol('duckdb_append_double') is export { }

sub duckdb-append-varchar(DuckDB-Appender $appender, Str $value --> int32)
    is native(&duckdb-lib) is symbol('duckdb_append_varchar') is export { }

sub duckdb-append-blob(DuckDB-Appender $appender, CArray[uint8] $data, uint64 $length --> int32)
    is native(&duckdb-lib) is symbol('duckdb_append_blob') is export { }

sub duckdb-append-null(DuckDB-Appender $appender --> int32)
    is native(&duckdb-lib) is symbol('duckdb_append_null') is export { }

sub duckdb-append-default(DuckDB-Appender $appender --> int32)
    is native(&duckdb-lib) is symbol('duckdb_append_default') is export { }
