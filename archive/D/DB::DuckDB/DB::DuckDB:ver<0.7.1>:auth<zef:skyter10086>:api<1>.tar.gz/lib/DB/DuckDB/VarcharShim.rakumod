#| Locate -- and if necessary compile -- the VARCHAR unpacking shim described
#| in resources/duckdb-varchar-shim.c.
#|
#| The shim is a self contained C file: it does not include duckdb.h and does
#| not link against libduckdb, it only knows the byte layout of
#| duckdb_string_t.  That keeps the build trivial (any C compiler, one -shared
#| flag) and means it can be built on platforms where the by-value bridge in
#| DB::DuckDB::Bridge is not needed.
#|
#| Failure is always soft: when no compiler is available, or the build fails,
#| shim-lib() returns an empty string and DB::DuckDB::Result keeps using the
#| pure Raku decoder.
unit module DB::DuckDB::VarcharShim;

my Str  $lib-path;
my Bool $probed = False;

sub native-ext(--> Str)
{
    return '.dll' if $*DISTRO.is-win;
    $*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so';
}

#| The C source, either from the distribution's resources or from a plain
#| `-I lib` checkout (where %?RESOURCES has no distribution to read from).
sub shim-source(--> IO::Path)
{
    my $from-res = quietly { %?RESOURCES<duckdb-varchar-shim.c> };
    return $from-res.IO if $from-res.defined && $from-res.IO.e;

    # lib/DB/DuckDB/VarcharShim.rakumod -> <root>/resources/...
    my $local = $?FILE.IO.parent.parent.parent.parent
                    .child('resources/duckdb-varchar-shim.c');
    $local.e ?? $local !! IO::Path;
}

sub cache-dir(--> IO::Path)
{
    %*ENV<DB_DUCKDB_SHIM_CACHE>
        ?? %*ENV<DB_DUCKDB_SHIM_CACHE>.IO
        !! $*HOME.IO.add('.local/share/DB-DuckDB');
}

sub shim-target(--> IO::Path)
{
    cache-dir.add('libduckdb-varchar-shim' ~ native-ext());
}

#| ABI of the entry points this driver expects.  Bumped together with
#| DKD_SHIM_ABI in the C file; a cached library built from an older source is
#| rebuilt instead of being loaded and then failing on a missing symbol.
our constant SHIM-ABI = 5;

#| Directories the compiled library may live in, in order of preference: the
#| configured cache, an ABI-specific subdirectory of it, then the temp
#| directory.  The fallbacks exist because Windows will not let a .dll be
#| replaced while another process has it loaded -- the link step then fails
#| with "Permission denied", which used to leave the driver without the shim
#| (and 2-6x slower on string, temporal and decimal columns) for good.
sub cache-candidates(--> List)
{
    my $base = cache-dir();
    $base, $base.add("abi-{SHIM-ABI}"), $*TMPDIR.add("DB-DuckDB-shim-{SHIM-ABI}");
}

sub lib-file(IO::Path $dir --> IO::Path)   { $dir.add('libduckdb-varchar-shim' ~ native-ext()) }
sub stamp-file(IO::Path $dir --> IO::Path) { $dir.add('libduckdb-varchar-shim.abi') }

#| ABI stamp belonging to one library file.  It has to be per file, not per
#| directory: a directory can hold the old shared library (locked by another
#| process, impossible to replace) next to fresh per-process builds, and a
#| directory-wide stamp would then vouch for the stale one.
sub lib-stamp(IO::Path $lib --> IO::Path) { IO::Path.new($lib.absolute ~ '.abi') }

#| ABI a library was built for, '' when unknown (no stamp, or an old build).
sub lib-abi(IO::Path $lib --> Str)
{
    my $stamp = lib-stamp($lib);
    return '' unless $stamp.e;
    (try { $stamp.slurp.trim }) // '';
}

#| Libraries in this directory, newest first: the shared name, then the
#| per-process builds left behind when the shared name was mapped by another
#| process and could not be replaced.  Loading any of them is fine -- they all
#| come from the same source -- so a directory holding only a left-over
#| private build still counts as a cache hit instead of a rebuild on every
#| run.
sub cached-libs(IO::Path $dir --> List)
{
    my $canon = lib-file($dir);
    my @private = $dir.d
        ?? quietly {
                dir($dir).grep({
                    .f
                    && .basename.starts-with('libduckdb-varchar-shim-')
                    && .basename.ends-with(native-ext)
                    && .basename ne $canon.basename
                }).sort({ (try { .modified.Instant } // 0) }).reverse
            }
        !! ();
    my @out;
    @out.push: $canon if $canon.e;
    @out.append: |@private;
    @out.List;
}

#| Epoch seconds encoded in a per-process build name, 0 when the name is the
#| shared one.  Taken from the name rather than the mtime because this Rakudo
#| reports a negative Instant for recently written files (see the note on
#| abi-stamp), which made fresh builds look hours old.
sub lib-epoch(IO::Path $lib --> Int)
{
    my $b = $lib.basename;
    return 0 unless $b.starts-with('libduckdb-varchar-shim-');
    my @nums = $b.comb(/\d+/, :match);
    return 0 unless @nums.elems > 1;
    (try { @nums.tail.Str.Int }) // 0;
}

#| Keep the cache from growing without bound.  Only libraries older than an
#| hour are pruned: a build started moments ago by another process is exactly
#| the one that process is about to load, so deleting it would break a
#| concurrent run.  Files that cannot be deleted (still mapped) are skipped.
sub trim-cache(IO::Path $dir, IO::Path $keep)
{
    my $cutoff = now.Int - 3600;
    my @stale = cached-libs($dir).grep({
        my $epoch = lib-epoch($_);
        $epoch > 0 && $epoch < $cutoff && .absolute ne $keep.absolute
    });
    for @stale -> $lib {
        try { $lib.unlink }
        try { lib-stamp($lib).unlink }
    }
}

#| True when this directory can be written.  Probed with a throwaway file
#| rather than by deleting an existing library: on Windows DeleteFile() on a
#| mapped .dll reports success while merely marking the file for deletion,
#| which makes the path unusable for every other process -- a "write test"
#| that silently breaks whoever is using the shim right now.
sub dir-usable(IO::Path $dir --> Bool)
{
    try { $dir.mkdir unless $dir.d };
    return False unless $dir.d && $dir.w;

    my $probe = $dir.add(".dbd-write-probe-{$*PID}-{now.Int}");
    try {
        $probe.spurt('x');
        $probe.unlink;
        $probe.e.not;
    } // False;
}

#| Stamp recording which ABI the cached library was built for.  It exists
#| because the mtime comparison below cannot be trusted: this Rakudo returns
#| a negative Instant for some files (measured: -1.97 for a file written
#| minutes ago), which made `out.modified >= src.modified` true for a library
#| that predated the source by hours.
sub abi-stamp(--> IO::Path) { cache-dir.add('libduckdb-varchar-shim.abi') }

#| Compilers to try, in order.  An explicit DB_DUCKDB_CC / CC wins, then the
#| usual names on PATH, then the toolchain locations that are commonly on
#| Windows boxes but never on PATH.
sub compiler-candidates(--> List)
{
    my @c;
    @c.push: %*ENV<DB_DUCKDB_CC> if %*ENV<DB_DUCKDB_CC>;
    @c.push: %*ENV<CC>           if %*ENV<CC>;
    @c.append: 'cc', 'gcc', 'clang';

    if $*DISTRO.is-win {
        @c.append: |<
            C:/msys64/mingw64/bin/gcc.exe
            C:/msys64/ucrt64/bin/gcc.exe
            C:/msys64/clang64/bin/clang.exe
            C:/Strawberry/c/bin/gcc.exe
            C:/TDM-GCC-64/bin/gcc.exe
            C:/mingw64/bin/gcc.exe
            C:/rakudo/share/llvm-mingw/bin/gcc.exe
        >;

        # llvm-mingw installs unpack to a versioned directory; pick up whatever
        # is on the fixed drives.
        for <C D E>.map({ $_ ~ ':/' }) -> $root {
            next unless $root.IO.d;
            my @dirs = quietly { dir($root).grep({ .d && .basename.starts-with('llvm-mingw') }) };
            for @dirs -> $d {
                my $g = $d.add('bin/gcc.exe');
                @c.push: $g.absolute if $g.e;
            }
        }
    }
    @c.cache;
}

#| Compile the shim when it is missing or older than its source.  Returns an
#| undefined IO::Path when the source or a working compiler is missing.
sub build-shim(--> IO::Path)
{
    my $src = shim-source();
    return IO::Path unless $src.defined;

    # Up to date only when the library exists *and* was built for the current
    # ABI.  The stamp is written after a successful compile, so a library left
    # behind by an older revision of this driver (or by a failed build) is
    # rebuilt rather than loaded with symbols that no longer match.
    for cache-candidates() -> $dir {
        for cached-libs($dir) -> $lib {
            next unless $lib.e;
            next unless lib-abi($lib) eq SHIM-ABI.Str;
            return $lib;
        }
    }

    my @flags = $*DISTRO.is-win
        ?? ('-O2', '-shared')
        !! ('-fPIC', '-O2', '-shared');

    for cache-candidates() -> $dir {
        next unless dir-usable($dir);

        # Never link onto the shared name.  If another process already has
        # that .dll mapped the link fails with "Permission denied"; if the
        # file is merely deleted the other process loses the shim mid-query.
        # Build into a name nobody else can be using, then move it into place
        # only when the shared name is still free.
        my $canon = lib-file($dir);

        for compiler-candidates() -> $cc {
            my $out = $dir.add("libduckdb-varchar-shim-{$*PID}-{now.Int}" ~ native-ext());
            my @cmd = $cc, |@flags, '-o', $out.absolute, $src.absolute;
            my $ok = try {
                my $proc = run(|@cmd, :out, :err);
                my $err-text = $proc.err.slurp(:close);
                $proc.out.slurp(:close);
                note "DB::DuckDB::VarcharShim: $cc exited {$proc.exitcode}:\n$err-text"
                    if $proc.exitcode != 0 && $err-text.chars;
                $proc.exitcode == 0;
            } // False;

            if $ok && $out.e {
                # Move the fresh build onto the shared name when that name is
                # free, or when it is held by a library built for an older ABI
                # (loading that one would fail on a missing symbol anyway).
                # When the old file is mapped by a live process this fails and
                # the private name is used instead -- nothing is broken.
                my $final = $out;
                my $stale = $canon.e && lib-abi($canon) ne SHIM-ABI.Str;
                if $canon.e.not || $stale {
                    my $moved = try {
                        $canon.unlink if $stale;
                        $out.rename($canon);
                        $canon;
                    } // Nil;
                    $final = $moved.defined && $moved.e ?? $moved !! $out;
                }

                try { lib-stamp($final).spurt: SHIM-ABI.Str ~ "\n" }
                trim-cache($dir, $final);
                return $final;
            }

            try { $out.unlink }
        }

        # The directory was writable, so this was a compile error rather than
        # an unwritable path: another directory will not help.
        note "DB::DuckDB::VarcharShim: no working C compiler found; VARCHAR "
          ~ "columns keep using the pure Raku decoder.  Set DB_DUCKDB_CC to "
          ~ "pick one.";
        last;
    }

    IO::Path;
}

#| Absolute path of the compiled shim, or an empty string when unavailable.
#| Resolution happens once per process.
our sub shim-lib(--> Str) is export
{
    return $lib-path if $probed;
    $probed = True;

    if %*ENV<DB_DUCKDB_VARCHAR_SHIM> -> $explicit {
        return $lib-path = $explicit
            if $explicit.chars && $explicit.IO.e;
    }

    my $out = build-shim();
    $lib-path = $out.defined && $out.e ?? $out.absolute !! '';
}

#| True when the shim compiled (or was supplied) and can be loaded.
our sub shim-active(--> Bool) is export
{
    shim-lib().chars > 0;
}

#| The source file the shim was built from, for diagnostics.
sub shim-source-file(--> IO::Path) is export { shim-source() }
