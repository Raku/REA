use DB;
use DB::DuckDB::Native;
use DB::DuckDB::Error;
use DB::DuckDB::Connection;

#| DuckDB driver for the Raku `DB` interface.
#|
#|     my $db = DB::DuckDB.new;                        # in-memory
#|     my $db = DB::DuckDB.new(path => 'data.duckdb'); # file backed
#|
#|     say $db.query('select 42').value;               # 42
#|     $db.execute('create table foo (x int, y varchar)');
#|     $db.execute('insert into foo values (?, ?)', 1, 'a');
#|
#|     for $db.query('select * from foo').hashes -> %row { say %row }
#|
#| Writing and session tuning:
#|
#|     # bulk load: routed through DuckDB's appender, one transaction
#|     $db.insert-rows('foo', ((1, 'a'), (2, 'b')));
#|     $db.execute-many('insert into foo values (?, ?)', ((3, 'c'),));
#|
#|     # explicit appender handle
#|     my $ap = $db.appender('foo');
#|     $ap.append-row(4, 'd');
#|     $ap.free;
#|
#|     # conservative by default; opt into the read-heavy settings
#|     my $fast = DB::DuckDB.new(:preserve-insertion-order(False), :threads(8));
class DB::DuckDB does DB
{
    has Str $.path = ':memory:';

    #| Worker threads DuckDB may use; undefined keeps DuckDB's default.
    has Int $.threads is rw;

    #| Memory limit, e.g. '2GB'; undefined keeps DuckDB's default (80% RAM).
    has Str $.memory-limit is rw;

    #| `preserve_insertion_order`.  Left at DuckDB's default (True) because
    #| dropping it changes result ordering; set it to False for scan-heavy
    #| workloads (measured 2.3x on a 1M row scan).
    has Bool $.preserve-insertion-order is rw = True;

    #| Extra `SET <name> = <value>` options applied to every connection this
    #| driver hands out, e.g. `'enable-profiling' => True`.
    has %.session-options;

    # One DuckDB database instance per driver; every connection handed out
    # by `connect` shares it.  Opening the same path twice would trip
    # DuckDB's instance/file locking, and for ':memory:' it would silently
    # create independent databases.
    has DuckDB-Database $!database;
    has Bool $!opened = False;

    # Whether the loaded libduckdb has been checked against the ABI this
    # binding targets.  Done once, right before the first handle is opened.
    has Bool $!abi-checked = False;

    # Every connection ever handed out, so `close` can cut them all loose
    # even when the caller dropped the handle without calling `finish`.
    has @!live-connections;

    # Session settings (`SET TimeZone`, PRAGMAs, temp tables) only live as
    # long as the connection they were issued on.  Handing out a brand new
    # connection per statement would silently drop them, so the driver keeps
    # one connection of its own and routes every statement through it.
    has DB::DuckDB::Connection $!session;

    method connect(Bool :$finish --> DB::DuckDB::Connection)
    {
        self!open-database unless $!opened;

        my DuckDB-Connection $handle .= new;
        my $rc = duckdb-connect($!database, $handle);
        if $rc != DuckDBSuccess {
            die DB::DuckDB::Error.new(
                :code($rc),
                message => "cannot create a connection for '{$!path}'",
            );
        }

        my $conn = DB::DuckDB::Connection.new(
            :owner(self), database => $!database, :$handle,
            session-options => self.effective-session-options,
        );
        @!live-connections.push($conn);
        $conn.finish if $finish;
        $conn;
    }

    method !open-database()
    {
        # Cheapest place to catch a library/binding mismatch: the shared
        # object is guaranteed to be resident once this returns, and every
        # later code path assumes the 2.x ABI.  Runs once per process.
        verify-library() unless $!abi-checked;
        $!abi-checked = True;

        my DuckDB-Database $database .= new;
        my $rc = duckdb-open($!path, $database);
        if $rc != DuckDBSuccess {
            die DB::DuckDB::Error.new(
                :code($rc),
                message => "cannot open DuckDB database '{$!path}'",
            );
        }
        $!database = $database;
        $!opened   = True;
    }

    submethod DESTROY()
    {
        self!release-database;
    }

    method !release-database()
    {
        duckdb-close($!database) if $!database.defined && $!database.Bool;
    }

    #| Close the underlying database instance.  Normally called for you
    #| when the driver is garbage collected.
    method close(--> Nil)
    {
        return unless $!opened;
        $!opened = False;

        # DuckDB only releases the file lock once every connection and
        # prepared statement is gone, so both are torn down first -- even
        # handles the caller forgot to `finish`.
        $!session = Nil;
        .free for @!live-connections;
        @!live-connections = ();

        self.finish;
        self!release-database;
    }

    #| Version of the linked libduckdb, e.g. "v1.5.5".
    method library-version(--> Str)
    {
        take-cstr(duckdb-library-version());
    }

    #| The driver's own long-lived connection, created on first use so that
    #| session settings survive across statements.
    method session(--> DB::DuckDB::Connection)
    {
        $!session //= do {
            self!open-database unless $!opened;
            my DuckDB-Connection $handle .= new;
            my $rc = duckdb-connect($!database, $handle);
            if $rc != DuckDBSuccess {
                die DB::DuckDB::Error.new(
                    :code($rc),
                    message => "cannot create a connection for '{$!path}'",
                );
            }
            my $conn = DB::DuckDB::Connection.new(
                :owner(self), database => $!database, :$handle,
                session-options => self.effective-session-options,
            );
            @!live-connections.push($conn);
            $conn;
        };
    }

    #| Statements are drained by the caller, so the result must not carry a
    #| connection away: the session connection outlives every result.
    method query(Str:D $query, *@args, *%args --> DB::Result)
    {
        self.session.query($query, :finish(False), |@args, |%args);
    }

    #| Statement execution with bound arguments.  `DB`'s own execute()
    #| forwards positional arguments straight to the connection, which has
    #| no notion of placeholders -- so the placeholder-aware path lives
    #| here, on top of a cached prepared statement.
    method execute(Str:D $query, *@args, *%args --> Int)
    {
        self.session.execute($query, |@args, |%args).Int;
    }

    # ------------------------------------------------------ session options

    #| The `SET` options this driver installs on every new connection.
    method effective-session-options(--> Hash)
    {
        my %opts = %!session-options;
        %opts<threads> = $!threads if $!threads.defined;
        %opts<memory_limit> = $!memory-limit if $!memory-limit.defined;

        # Only push preserve_insertion_order when it has been turned off:
        # True is DuckDB's own default, so staying silent keeps us out of the
        # engine's way.
        %opts<preserve_insertion_order> = False unless $!preserve-insertion-order;

        %opts;
    }

    #| Change a session option and apply it to the live connections right
    #| away (new connections pick it up from the attributes).
    method set-session-option(Str:D $name, $value --> Nil)
    {
        %!session-options{$name} = $value;
        if $!session.defined {
            $!session.set-session-option($name, $value);
            .set-session-option($name, $value) for @!live-connections;
        }
    }

    #| Re-apply the configured options to the session connection, e.g. after
    #| changing `threads` on the driver object.
    method apply-session-options(--> Nil)
    {
        my %opts = self.effective-session-options;
        if $!session.defined {
            $!session.set-session-option(.key, .value) for %opts.sort(*.key);
        }
        Nil;
    }

    # ------------------------------------------------------ batch write API

    #| Open an appender on `$table`; see DB::DuckDB::Appender.
    method appender(Str:D $table, Str :$schema --> DB::DuckDB::Appender)
    {
        self.session.appender($table, :$schema);
    }

    #| Bulk insert rows through the appender (transactional by default).
    method insert-rows(Str:D $table, @rows, Str :$schema, Bool :$transaction = True --> Int)
    {
        self.session.insert-rows($table, @rows, :$schema, :$transaction);
    }

    #| Run the same single-row INSERT for many parameter sets; plain
    #| INSERT ... VALUES (?) statements are routed through the appender.
    method execute-many(Str:D $sql, @params, Bool :$transaction = True --> Int)
    {
        self.session.execute-many($sql, @params, :$transaction);
    }

    # ------------------------------------------------------------- parquet

    #| Read a Parquet file, or a glob of them, as a normal result set.  See
    #| DB::DuckDB::Connection.read-parquet for the options.
    #|
    #|     $db.read-parquet('sales.parquet').hashes;
    #|     $db.read-parquet('dir/*.parquet', :union-by-name, :filename);
    #|
    #| The two candidates exist because a list of paths must stay one argument:
    #| forwarding through `*@args` would flatten it into several positionals.
    multi method read-parquet(Str:D $path, *%options)
    {
        self.session.read-parquet($path, |%options);
    }

    multi method read-parquet(@paths, *%options)
    {
        self.session.read-parquet(@paths, |%options);
    }

    #| Write a table or a query to Parquet and return the row count.  See
    #| DB::DuckDB::Connection.write-parquet for the options.
    #|
    #|     $db.write-parquet('out.parquet', 'events');
    #|     $db.write-parquet('out.parquet', 'select * from events', :sql);
    method write-parquet(*@args, *%options)
    {
        self.session.write-parquet(|@args, |%options);
    }

    #| File-level Parquet metadata (footer only).
    method parquet-metadata(Str:D $path --> List)
    {
        self.session.parquet-metadata($path);
    }

    #| Physical/logical column layout of a Parquet file.
    method parquet-schema(Str:D $path --> List)
    {
        self.session.parquet-schema($path);
    }

    #| Per row group and per column statistics.
    method parquet-row-groups(Str:D $path --> List)
    {
        self.session.parquet-row-groups($path);
    }
}
