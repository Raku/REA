﻿#| A zero-copy, column oriented view over a materialised result.
#|
#| Why
#| ===
#| `column()` returns an Array of boxed values: for one million BIGINTs that
#| is one million Int objects, plus the Array slots, plus the GC work of
#| finding them again.  A lot of read-side work only needs the numbers, not
#| the containers -- sums, min/max, feeding a loop, slicing a window -- and
#| paying for the containers is then pure overhead.
#|
#| A ColumnView instead keeps, per chunk, the vector's data pointer, its
#| validity pointer and the row range that chunk covers.  The bytes stay
#| where DuckDB put them: `.int64($i)` / `.num64($i)` read straight out of
#| the vector's memory, and `.sum` walks the chunks without allocating one
#| object per value for the whole column.
#|
#| Lifetime
#| ========
#| The pointers belong to the `duckdb_result`, not to the view.  Chunks come
#| from `duckdb_result_get_chunk`, which hands back a chunk *owned by the
#| result* (no destroy, valid until the result is freed).  The view therefore
#| holds a reference to its Result: as long as the view is alive, the result
#| cannot be garbage collected and the pointers stay valid.  Calling
#| `.free` on the result yourself invalidates every view taken from it.
#|
#| Flatness
#| ========
#| Reading the vector data as a dense array assumes the chunk's vectors are
#| flat.  Materialised results satisfy this -- the collection flattens before
#| it stores -- and the same assumption already underpins the typed bulk
#| fillers in Result.  Types that are not handled here (VARCHAR, LIST, STRUCT,
#| ENUM, dates, intervals ...) do not take that risk at all: they simply
#| keep their chunk handles and decode one segment (one chunk) at a time,
#| the first time a row in that segment is read.  `$.raw` is False, and
#| `to-list` still matches `column()` exactly.  Decoding is lazy on purpose:
#| a wide VARCHAR result used to pay the full string-assembly cost for every
#| non-numeric column at `column-views` time, even when the caller read only
#| one of them.
#|
#| Set DB_DUCKDB_NO_COLUMN_VIEW=1 to make `column-views` fall back to plain
#| `column-arrays` for the whole result.
use DB::DuckDB::Native;
use NativeCall;

# Module level type tables; the class itself is declared below, after them,
# so these stay file scoped rather than becoming class-lexical state.

# Byte width of every type this module reads straight from the vector.
my %WIDTH =
    (DUCKDB_TYPE_BOOLEAN)   => 1,
    (DUCKDB_TYPE_TINYINT)   => 1,
    (DUCKDB_TYPE_UTINYINT)  => 1,
    (DUCKDB_TYPE_SMALLINT)  => 2,
    (DUCKDB_TYPE_USMALLINT) => 2,
    (DUCKDB_TYPE_INTEGER)   => 4,
    (DUCKDB_TYPE_UINTEGER)  => 4,
    (DUCKDB_TYPE_BIGINT)    => 8,
    (DUCKDB_TYPE_UBIGINT)   => 8,
    (DUCKDB_TYPE_FLOAT)     => 4,
    (DUCKDB_TYPE_DOUBLE)    => 8,
    (DUCKDB_TYPE_HUGEINT)   => 16,
    (DUCKDB_TYPE_UHUGEINT)  => 16,
    (DUCKDB_TYPE_DECIMAL)   => 8,
;

my %NAME =
    (DUCKDB_TYPE_BOOLEAN)   => 'BOOLEAN',
    (DUCKDB_TYPE_TINYINT)   => 'TINYINT',
    (DUCKDB_TYPE_UTINYINT)  => 'UTINYINT',
    (DUCKDB_TYPE_SMALLINT)  => 'SMALLINT',
    (DUCKDB_TYPE_USMALLINT) => 'USMALLINT',
    (DUCKDB_TYPE_INTEGER)   => 'INTEGER',
    (DUCKDB_TYPE_UINTEGER)  => 'UINTEGER',
    (DUCKDB_TYPE_BIGINT)    => 'BIGINT',
    (DUCKDB_TYPE_UBIGINT)   => 'UBIGINT',
    (DUCKDB_TYPE_FLOAT)     => 'FLOAT',
    (DUCKDB_TYPE_DOUBLE)    => 'DOUBLE',
    (DUCKDB_TYPE_HUGEINT)   => 'HUGEINT',
    (DUCKDB_TYPE_UHUGEINT)  => 'UHUGEINT',
    (DUCKDB_TYPE_DECIMAL)   => 'DECIMAL',
    (DUCKDB_TYPE_VARCHAR)   => 'VARCHAR',
    (DUCKDB_TYPE_BLOB)      => 'BLOB',
    (DUCKDB_TYPE_DATE)      => 'DATE',
    (DUCKDB_TYPE_TIME)      => 'TIME',
    (DUCKDB_TYPE_TIMESTAMP) => 'TIMESTAMP',
    (DUCKDB_TYPE_LIST)      => 'LIST',
    (DUCKDB_TYPE_STRUCT)    => 'STRUCT',
    (DUCKDB_TYPE_MAP)       => 'MAP',
    (DUCKDB_TYPE_ENUM)      => 'ENUM',
    (DUCKDB_TYPE_UUID)      => 'UUID',
;

my constant UNSIGNED = set(
    DUCKDB_TYPE_UTINYINT, DUCKDB_TYPE_USMALLINT, DUCKDB_TYPE_UINTEGER,
    DUCKDB_TYPE_UBIGINT, DUCKDB_TYPE_UHUGEINT,
);

my constant FLOATS = set(DUCKDB_TYPE_FLOAT, DUCKDB_TYPE_DOUBLE);

my constant INTEGRAL = set(
    DUCKDB_TYPE_TINYINT, DUCKDB_TYPE_SMALLINT, DUCKDB_TYPE_INTEGER,
    DUCKDB_TYPE_BIGINT, DUCKDB_TYPE_UTINYINT, DUCKDB_TYPE_USMALLINT,
    DUCKDB_TYPE_UINTEGER, DUCKDB_TYPE_UBIGINT,
);

# Typed bulk loops used by `to-list`.  The parameter type is what makes them
# fast: a CArray held in an untyped variable has to re-dispatch on every
# index, while a typed parameter is read as a plain array element.  One sub
# per element type keeps the loop body monomorphic.
my sub fill-i64(@out, CArray[int64] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-u64(@out, CArray[uint64] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-i32(@out, CArray[int32] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-u32(@out, CArray[uint32] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-i16(@out, CArray[int16] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-u16(@out, CArray[uint16] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-i8(@out, CArray[int8] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-u8(@out, CArray[uint8] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Int; $k++ }
}
my sub fill-n64(@out, CArray[num64] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Num; $k++ }
}
my sub fill-n32(@out, CArray[num32] $c, uint64 $n --> Nil) {
    my uint64 $k = 0; while $k < $n { @out.push: $c[$k].Num; $k++ }
}

#| True when a type can be handed out as raw bytes by `column-views`.
sub raw-type(Int $tid --> Bool) is export { %WIDTH{$tid}:exists }

#| Byte width of a raw type, 0 otherwise.
sub raw-width(Int $tid --> Int) is export { %WIDTH{$tid} // 0 }

#| DuckDB type id -> the type name used by `column-types` and friends.
sub type-name(Int $tid --> Str) is export { %NAME{$tid} // 'UNKNOWN' }

class DB::DuckDB::ColumnView
{
    has Int $.index;
    has Int $.elems;
    has Int $.tid;
    has Str $.type;
    has Int $.width;
    has Int $.scale = 0;
    has Bool $.raw = True;

    # Keeps the owning result -- and therefore the chunk vectors -- alive.
    has $.result;

    # Set by DB::DuckDB::Chunk.expire when the streaming driver recycles the
    # chunk this view points into.  Every read goes through !guard, so a stale
    # view dies loudly instead of handing back whatever the engine put there.
    has Bool $.expired is rw = False;

    # One entry per chunk: first row, row count, data pointer, validity
    # pointer (an undefined Pointer means "no NULLs in this chunk").
    has @!bases;
    has @!rows;
    has @!data;
    has @!valid;
    has @!mask;      # validity as CArray[uint64], or Pointer when absent
    has @!c;         # data as a typed CArray of the column's element type
    has @!boxed;

    # Lazy (non-raw) columns: one owned chunk handle per segment, plus the
    # decoded values once a segment has been touched.  Decoding on first
    # access keeps `column-views` cheap on wide VARCHAR results -- the
    # caller only pays for the columns it actually reads.
    has Bool $!lazy = False;
    has @!chunks;
    has @!dec;

    submethod BUILD(Int :$!index!, Int :$!elems!, Int :$!tid!, Str :$type,
                    Int :$width!, Int :$scale = 0, :$!result,
                    Bool :$raw = True, :@bases, :@rows, :@data, :@valid,
                    :@boxed, Bool :$lazy = False, :@chunks)
    {
        $!type  = $type // (%NAME{$!tid} // 'UNKNOWN');
        $!width = $width;
        $!scale = $scale;
        $!raw   = $raw;

        @!bases = @bases.List;
        @!rows  = @rows.List;
        @!data  = @data.List;
        @!valid = @valid.List;
        @!boxed = @boxed.List;

        # A lazy column is implied by having chunk handles: `from-list` and
        # the slice fallbacks pass decoded values and no chunks.
        $!lazy   = $lazy && @chunks.elems > 0;
        @!chunks = $!lazy ?? @chunks.List !! ();
        @!dec    = @!chunks.map({ Mu }).List;

        my @masks;
        for @!valid.List -> $ptr {
            @masks.push: ($ptr.defined && $ptr.Bool)
                ?? nativecast(CArray[uint64], $ptr)
                !! Pointer;
        }
        @!mask = @masks.List;

        # Build the typed element view once, so a value read is an array
        # index rather than a fresh nativecast per value.
        my @c;
        for @!data.List -> $ptr {
            unless $ptr.defined && $ptr.Bool { @c.push: Pointer; next }
            @c.push: do given $!tid {
                when DUCKDB_TYPE_FLOAT  { nativecast(CArray[num32], $ptr) }
                when DUCKDB_TYPE_DOUBLE { nativecast(CArray[num64], $ptr) }
                default {
                    # Unsigned columns must be read through unsigned element
                    # types: a CArray[int8] turns 200 into -56.
                    given $!tid {
                        when DUCKDB_TYPE_UTINYINT  { nativecast(CArray[uint8],  $ptr) }
                        when DUCKDB_TYPE_USMALLINT { nativecast(CArray[uint16], $ptr) }
                        when DUCKDB_TYPE_UINTEGER  { nativecast(CArray[uint32], $ptr) }
                        when DUCKDB_TYPE_UBIGINT   { nativecast(CArray[uint64], $ptr) }
                        default {
                            given $!width {
                                when 1  { nativecast(CArray[int8],   $ptr) }
                                when 2  { nativecast(CArray[int16],  $ptr) }
                                when 4  { nativecast(CArray[int32],  $ptr) }
                                when 8  { nativecast(CArray[int64],  $ptr) }
                                when 16 { nativecast(CArray[uint64], $ptr) }
                                default { Pointer }
                            }
                        }
                    }
                }
            }
        }
        @!c = @c.List;
    }

    #| Build a view over already decoded values: the fallback for types that
    #| are not read as raw bytes, and the shape `column-views` returns when a
    #| result cannot hand out borrowed chunks.
    method from-list(Int :$index!, :@values, Int :$tid!, Str :$type,
                     Int :$width = 0, Int :$scale = 0, :$result --> DB::DuckDB::ColumnView)
    {
        DB::DuckDB::ColumnView.new(
            index => $index, elems => @values.elems, tid => $tid,
            type => $type, width => $width, scale => $scale,
            result => $result, raw => False,
            bases => (), rows => (), data => (), valid => (), boxed => @values,
        );
    }

    method is-float(--> Bool) { FLOATS{$!tid} }

    method is-unsigned(--> Bool) { UNSIGNED{$!tid} }

    #| Index of the chunk holding row $i.  Chunk sizes are uniform in
    #| practice, so the common case is a division; a binary search covers
    #| uneven chunking (a partially consumed result, an odd last chunk).
    method !seg(uint64 $i --> Int)
    {
        # No array copies here: this runs once per value on the point-access
        # path (`at` / `int64` / `num64` / `is-null`), so `my @b = @!bases`
        # would copy the whole segment table for every single row.
        my int $last = @!bases.elems - 1;
        return 0 if $last <= 0;

        my uint64 $first = @!rows[0];
        if $first > 0 && $i div $first >= $last {
            return $last;
        }
        if $first > 0 {
            my int $guess = ($i div $first).Int;
            return $guess
                if @!bases[$guess] <= $i
                && ($guess == $last || @!bases[$guess + 1] > $i);
        }

        my int $lo = 0;
        my int $hi = $last;
        while $lo < $hi {
            my int $mid = ($lo + $hi + 1) div 2;
            if @!bases[$mid] <= $i { $lo = $mid } else { $hi = $mid - 1 }
        }
        $lo;
    }

    method !check(uint64 $i --> Nil)
    {
        self!guard;
        die "row $i out of range (elems=$!elems)" if $i >= $!elems;
    }

    #| Refuse to read once the streaming chunk behind this view has been
    #| recycled -- the pointers in @!data now belong to somebody else.
    method !guard(--> Nil)
    {
        die "column view of column $!index is stale: the streaming chunk it "
          ~ "pointed into was recycled when the next chunk was pulled"
            if $!expired;
    }

    #| Decode the segment holding row $s, once, and return its values.
    method !ensure-seg(int $s --> List)
    {
        my $seg = @!dec[$s];
        return $seg if $seg.defined;

        my @dst;
        # The row count lives in a plain Int hash; assigning into a native
        # variable coerces it without the uint64() sub's boxed-return trap.
        my uint64 $size = @!rows[$s];
        $!result.decode-column-into(@dst, @!chunks[$s], $!index, $size);
        $seg = @dst.List;
        @!dec[$s] = $seg;
        $seg;
    }

    method !lazy-at(uint64 $i --> Mu)
    {
        my int $s = self!seg($i);
        my $seg = self!ensure-seg($s);
        my uint64 $off = $i - @!bases[$s];
        $off < $seg.elems ?? $seg[$off] !! Any;
    }

    #| Row $i on the decoded side of the column: a lazy segment decode for
    #| types `column-views` did not read as raw bytes, a plain array index
    #| otherwise.
    method !boxed-at(uint64 $i --> Mu)
    {
        $!lazy ?? self!lazy-at($i) !! @!boxed[$i];
    }

    #| Every value of a lazy column, segment by segment.
    #|
    #| Segments already decoded for at()/slice() are copied from the cache;
    #| the rest are decoded straight into @out instead of going through
    #| !ensure-seg, because that would build a 2048-element List for each
    #| segment and then copy it again into @out.  A whole-column read does not
    #| need a second copy of values it is about to keep, and it does not
    #| populate the segment cache -- the caller now holds the values.
    method !lazy-all(--> List)
    {
        my @out;
        my uint64 $s = 0;
        my uint64 $n = @!chunks.elems;
        while $s < $n {
            my $cached = @!dec[$s];
            if $cached.defined {
                @out.append: |$cached;
            }
            else {
                my uint64 $size = @!rows[$s];
                $!result.decode-column-into(@out, @!chunks[$s], $!index, $size);
            }
            $s++;
        }
        @out.List;
    }

    #| True for a SQL NULL.  Out of range rows count as NULL.  A chunk with
    #| no validity bitmap has no NULLs at all, so it answers False without
    #| touching memory.
    method is-null(uint64 $i --> Bool)
    {
        self!guard;
        return True if $i >= $!elems;
        return !self!boxed-at($i).defined unless $!raw;

        my int $s = self!seg($i);
        my $mask = @!mask[$s];
        return False unless $mask.defined && $mask.Bool;

        my CArray[uint64] $m = $mask ~~ CArray
            ?? $mask
            !! nativecast(CArray[uint64], $mask);
        my uint64 $off = $i - @!bases[$s];
        ($m[$off div 64] +& (1 +< ($off % 64))) == 0;
    }

    #| Raw little endian integer of row $i: the unscaled value for DECIMAL,
    #| the day/microsecond count for date and time types.  NULLs read as 0,
    #| so check `is-null` first when the column may contain them.
    method int64(uint64 $i --> Int)
    {
        return self!boxed-int($i) unless $!raw;
        die ".int64 is not defined for {$!type} (use .num64)" if self.is-float;
        self!check($i);

        my int $s = self!seg($i);
        my uint64 $off = $i - @!bases[$s];
        my $v = @!c[$s][$off];

        my Int $n = $v.Int;
        my Int $w = $!width;
        if $w == 16 {
            # hugeint: low word at 2*off, high word at 2*off+1
            my $lo = @!c[$s][$off * 2].Int;
            my $hi = @!c[$s][$off * 2 + 1].Int;
            # Two's complement: the low word carries the same unsigned
            # weight either way, so signed and unsigned agree here.
            return $hi * (2 ** 64) + $lo;
        }
        if $w < 8 && self.is-unsigned {
            $n = $n +& ((1 +< ($w * 8)) - 1);
        }
        $n;
    }

    #| Value of row $i as a float.  Integers, floats and DECIMALs all answer.
    method num64(uint64 $i --> Num)
    {
        unless $!raw {
            my $v = self!boxed-at($i);
            return $v.defined ?? $v.Num !! 0e0;
        }
        self!check($i);

        if $!tid == DUCKDB_TYPE_DOUBLE || $!tid == DUCKDB_TYPE_FLOAT {
            my int $s = self!seg($i);
            my uint64 $off = $i - @!bases[$s];
            return @!c[$s][$off].Num;
        }
        my Int $v = self.int64($i);
        return $v.Num if $!tid != DUCKDB_TYPE_DECIMAL;
        $!scale == 0 ?? $v.Num !! $v.Num / (10 ** $!scale).Num;
    }

    method !boxed-int(uint64 $i --> Int)
    {
        self!check($i);
        my $v = self!boxed-at($i);
        return 0 unless $v.defined;
        return $v.Int if $v ~~ Numeric|Str;
        die "row $i of {$!type} is not numeric";
    }

    #| The value at row $i rendered the way `column()` renders it.  Raw
    #| numeric columns are formatted here; every other type comes straight
    #| from the decoded fallback Array.
    method at(uint64 $i --> Mu)
    {
        self!guard;
        return self!boxed-at($i) unless $!raw;
        return Any if self.is-null($i);

        given $!tid {
            when DUCKDB_TYPE_BOOLEAN { so self.int64($i) }
            when DUCKDB_TYPE_DECIMAL { self!decimal-text(self.int64($i)) }
            # 128 bit values do not fit a Raku native int on every backend;
            # the decoded path has always answered them as decimal strings.
            when DUCKDB_TYPE_HUGEINT { self.int64($i).Str }
            default {
                self.is-float ?? self.num64($i) !! self.int64($i);
            }
        }
    }

    method !decimal-at(Int $v, int $scale --> Str)
    {
        my Bool $neg = $v < 0;
        my Int $abs = $neg ?? -$v !! $v;
        my Int $div = 10 ** $scale;
        my Str $ip = ($abs div $div).Str;
        return ($neg ?? '-' !! '') ~ $ip if $scale == 0;
        my Str $fp = ($abs % $div).Str;
        $fp = ('0' x $scale).substr(0, $scale - $fp.chars) ~ $fp
            if $fp.chars < $scale;
        ($neg ?? '-' !! '') ~ $ip ~ '.' ~ $fp;
    }

    method !decimal-text(Int $v --> Str) { self!decimal-at($v, $!scale) }

    #| Append a NULL-free segment, picking the loop by element type once per
    #| segment rather than testing the type once per value.
    method !fill-raw(@out, $ca, uint64 $n --> Nil)
    {
        given $!tid {
            when DUCKDB_TYPE_BIGINT    { fill-i64(@out, $ca, $n) }
            when DUCKDB_TYPE_UBIGINT   { fill-u64(@out, $ca, $n) }
            when DUCKDB_TYPE_INTEGER   { fill-i32(@out, $ca, $n) }
            when DUCKDB_TYPE_UINTEGER  { fill-u32(@out, $ca, $n) }
            when DUCKDB_TYPE_SMALLINT  { fill-i16(@out, $ca, $n) }
            when DUCKDB_TYPE_USMALLINT { fill-u16(@out, $ca, $n) }
            when DUCKDB_TYPE_TINYINT   { fill-i8(@out,  $ca, $n) }
            when DUCKDB_TYPE_UTINYINT  { fill-u8(@out,  $ca, $n) }
            when DUCKDB_TYPE_DOUBLE    { fill-n64(@out, $ca, $n) }
            when DUCKDB_TYPE_FLOAT     { fill-n32(@out, $ca, $n) }
            default {
                my uint64 $k = 0;
                while $k < $n { @out.push: $ca[$k].Int; $k++ }
            }
        }
    }

    #| The whole column as a List with `column()`'s value types.  This is the
    #| convenience path: it allocates, so it is the wrong tool for bulk work.
    method to-list(--> List)
    {
        self!guard;
        unless $!raw {
            # Lazy columns decode only the segments that exist, once, and
            # reuse the cached result on every later call.
            return self!lazy-all if $!lazy;
            return @!boxed.List;
        }

        my Str $mode = '';
        if self.is-float { $mode = 'num' }
        # A 128-bit DECIMAL is stored as two 64-bit words per row, so the
        # one-element-per-index shortcut does not hold for it.
        elsif $!tid == DUCKDB_TYPE_DECIMAL && $!width <= 8 { $mode = 'dec' }
        elsif INTEGRAL{$!tid} { $mode = 'int' }

        my @out;
        unless $mode {
            @out.push: self.at($_) for ^$!elems;
            return @out.List;
        }

        my @b  = @!bases;
        my @r  = @!rows;
        my @m  = @!mask;
        my @c  = @!c;
        my int $scale = $!scale;

        for ^@b.elems -> int $s {
            my $ca   = @c[$s];
            my $mask = @m[$s];
            my uint64 $n = @r[$s];
            my uint64 $k = 0;

            if !$mask.defined || !$mask.Bool {
                # NULL-free segments are the common case: hand them to a
                # typed loop instead of walking through an untyped CArray.
                if $mode eq 'dec' {
                    while $k < $n { @out.push: self!decimal-at($ca[$k].Int, $scale); $k++ }
                }
                else {
                    self!fill-raw(@out, $ca, $n);
                }
                next;
            }

            my CArray[uint64] $mk = $mask;
            while $k < $n {
                if ($mk[$k div 64] +& (1 +< ($k % 64))) != 0 {
                    if $mode eq 'int' { @out.push: $ca[$k].Int }
                    elsif $mode eq 'num' { @out.push: $ca[$k].Num }
                    else { @out.push: self!decimal-at($ca[$k].Int, $scale) }
                }
                else { @out.push: Any }
                $k++;
            }
        }
        @out.List;
    }

    # --- aggregates ------------------------------------------------------
    #| Walk every chunk once and reduce.  NULLs are skipped, matching SQL.
    method !agg(Str $kind --> Mu)
    {
        self!guard;
        return Any unless $!raw;
        return Any if $!elems == 0;

        my Bool $is-int = !self.is-float && $!tid != DUCKDB_TYPE_DECIMAL;
        my int $op = $kind eq 'sum' ?? 0 !! ($kind eq 'min' ?? 1 !! 2);
        my Mu $acc = $kind eq 'sum' ?? ($is-int ?? 0 !! 0e0) !! Mu;
        my Int $count = 0;

        my @b = @!bases; my @r = @!rows; my @m = @!mask;
        for ^@b.elems -> int $s {
            my $ca = @!c[$s];
            my $mask = @m[$s];
            my uint64 $n = @r[$s];
            my uint64 $k = 0;
            my $mk = ($mask.defined && $mask.Bool)
                ?? nativecast(CArray[uint64], $mask) !! Pointer;

            while $k < $n {
                my Bool $valid = True;
                my uint64 $stop = $n;
                my uint64 $word = 0;
                if $mk.defined {
                    $word = $mk[$k div 64];
                    $stop = $k + 64;
                    $stop = $n if $stop > $n;
                }

                while $k < $stop {
                    if $mk.defined {
                        # Bit offset inside the word is just $k % 64: never
                        # accumulate, so the shift cannot run past 63.
                        $valid = ($word +& (1 +< ($k % 64))) != 0;
                    }
                    if $valid {
                        my Mu $v = $ca[$k];
                        # An integer opcode beats three string comparisons in
                        # this loop, which runs once per value.
                        if $op == 0 {
                            $acc = $acc + $v;
                        }
                        elsif $op == 1 {
                            $acc = ($acc.defined && $v >= $acc) ?? $acc !! $v;
                        }
                        else {
                            $acc = ($acc.defined && $v <= $acc) ?? $acc !! $v;
                        }
                        $count++;
                    }
                    $k++;
                }
            }
        }

        return Any if $count == 0 && $kind ne 'sum';

        given $kind {
            when 'sum' {
                return $acc if $is-int;
                return $!scale == 0 ?? $acc.Num !! $acc.Num / (10 ** $!scale).Num
                    if $!tid == DUCKDB_TYPE_DECIMAL;
                $acc.Num;
            }
            # A DECIMAL aggregate must come back as the same fixed point
            # string the element accessor produces, not the raw unscaled
            # integer that happens to be stored in the vector.
            when 'min' { $!tid == DUCKDB_TYPE_DECIMAL
                         ?? self!decimal-text($acc.Int)
                         !! ($is-int ?? $acc.Int !! $acc.Num) }
            when 'max' { $!tid == DUCKDB_TYPE_DECIMAL
                         ?? self!decimal-text($acc.Int)
                         !! ($is-int ?? $acc.Int !! $acc.Num) }
        }
    }

    #| SUM over the column, NULLs skipped.  Int for integer columns, Num for
    #| FLOAT/DOUBLE and for DECIMAL (already scaled).
    method sum(--> Mu) { self!agg('sum') }

    method min(--> Mu) { self!agg('min') }

    method max(--> Mu) { self!agg('max') }

    #| Number of non-NULL values in the column.
    method count(--> Int)
    {
        self!guard;
        unless $!raw {
            return self!lazy-all.grep(*.defined).elems if $!lazy;
            return @!boxed.grep(*.defined).elems;
        }

        my Int $count = 0;
        my @m = @!mask;
        for ^@m.elems -> int $s {
            my $mask = @m[$s];
            my uint64 $n = @!rows[$s];
            if !$mask.defined || !$mask.Bool { $count += $n; next }
            my $mk = nativecast(CArray[uint64], $mask);
            my uint64 $k = 0;
            while $k < $n {
                $count++ if ($mk[$k div 64] +& (1 +< ($k % 64))) != 0;
                $k++;
            }
        }
        $count;
    }

    method mean(--> Mu)
    {
        my Int $count = self.count;
        return Any if $count == 0;
        self.sum / $count;
    }

    #| A new view over rows [$from, $from + $count).  The result is backed
    #| by fresh decoded values, so a slice is a convenience, not a hot path.
    method slice(Int $from, Int $count --> DB::DuckDB::ColumnView)
    {
        self!guard;
        die "negative slice start" if $from < 0;
        die "negative slice count" if $count < 0;
        my Int $last = $from + $count;
        $last = $!elems if $last > $!elems;
        return self!slice-boxed($from, $last) if $last > $from;

        die "slice outside column: $from + $count > $!elems" if $from > $!elems;

        DB::DuckDB::ColumnView.new(
            index => $!index, elems => 0, tid => $!tid, type => $!type,
            width => $!width, scale => $!scale, result => $!result,
            raw => $!raw, bases => (), rows => (), data => (), valid => (),
            boxed => (),
        );
    }

    method !slice-boxed(Int $from, Int $to --> DB::DuckDB::ColumnView)
    {
        # A raw column has no decoded array to cut, so materialise exactly the
        # rows asked for; a decoded column can just cut its own array.
        my @vals = ($!raw || $!lazy)
            ?? ($from ..^ $to).map({ self.at($_) }).List
            !! @!boxed[$from ..^ $to];
        DB::DuckDB::ColumnView.new(
            index => $!index, elems => $to - $from, tid => $!tid,
            type => $!type, width => $!width, scale => $!scale,
            result => $!result, raw => False,
            bases => (), rows => (), data => (), valid => (),
            boxed => @vals.List,
        );
    }
}
