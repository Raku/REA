#| Locate -- and if necessary compile -- the small C bridge described in
#| resources/duckdb-result-shim.c.
#|
#| Why this module exists
#| ======================
#| NativeCall passes a CStruct argument as a pointer to the struct.  On the
#| Microsoft x64 ABI that is also how a large struct is passed, so binding
#| `duckdb_result` by value works there by accident.  On SysV (Linux/macOS)
#| such a struct travels on the stack, so the callee reads garbage and
#| DuckDB dies with "unique_ptr NULL" as soon as a chunk is fetched.
#|
#| The bridge is a two-function shared object built on demand against the
#| very same headers and library that Alien::Libduckdb installed, so the
#| struct layout can never drift between the driver and the bridge.
unit module DB::DuckDB::Bridge;

use Alien::Libduckdb;

#| Windows already matches NativeCall's by-pointer convention for large
#| structs; everywhere else the bridge is required.
sub needs-bridge(--> Bool) is export { !$*DISTRO.is-win }

my Str  $bridge-lib;
my Bool $resolved = False;
my Bool $available = False;

sub native-ext(--> Str)
{
    $*DISTRO.name ~~ /mac|darwin/ ?? '.dylib' !! '.so';
}

#| The C source, either from the distribution's resources or from a plain
#| `-I lib` checkout (where %?RESOURCES has no distribution to read from).
sub shim-source(--> IO::Path)
{
    my $from-res = quietly { %?RESOURCES<duckdb-result-shim.c> };
    return $from-res.IO if $from-res.defined && $from-res.IO.e;

    # lib/DB/DuckDB/Bridge.rakumod -> <root>/resources/duckdb-result-shim.c
    my $local = $?FILE.IO.parent.parent.parent.parent
                    .child('resources/duckdb-result-shim.c');
    $local.e ?? $local !! IO::Path;
}

sub shim-target(--> IO::Path)
{
    my $base = %*ENV<DB_DUCKDB_SHIM_CACHE>
        ?? %*ENV<DB_DUCKDB_SHIM_CACHE>.IO
        !! $*HOME.IO.add('.local/share/DB-DuckDB');
    $base.add('libduckdb-result-shim' ~ native-ext());
}

#| Compile the bridge when it is missing or older than its source.  Returns
#| an undefined IO::Path when the source or a working compiler is missing.
sub build-shim(--> IO::Path)
{
    my $src = shim-source();
    return IO::Path unless $src.defined;

    my $out = shim-target();
    if $out.e && $out.modified >= $src.modified {
        return $out;
    }

    my $inc    = Alien::Libduckdb::include-dir().absolute;
    my $libdir = Alien::Libduckdb::lib-dir().absolute;
    my $cc     = %*ENV<CC> // 'cc';

    $out.parent.mkdir unless $out.parent.e;

    my @cmd = $cc, '-shared', '-fPIC', '-O2',
              '-o', $out.absolute, $src.absolute,
              '-I' ~ $inc,
              '-L' ~ $libdir, '-lduckdb',
              '-Wl,-rpath,' ~ $libdir;

    my $ok = try {
        my $proc = run(|@cmd, :out, :err);
        my $stderr-text = $proc.err.slurp(:close);
        $proc.out.slurp(:close);
        note "DB::DuckDB::Bridge: cc failed:\n$stderr-text"
            if $proc.exitcode != 0 && $stderr-text.chars;
        $proc.exitcode == 0;
    } // False;

    unless $ok {
        note "DB::DuckDB::Bridge: could not compile the by-value shim; "
          ~ "falling back to the raw symbols (chunk reads will fail on "
          ~ "this ABI).  Set CC= if your compiler is not `cc`.";
        return IO::Path;
    }

    $out;
}

#| Absolute path of the bridge library, or an empty string when the plain
#| libduckdb symbols must be used instead.  Computed once per process.
sub bridge-lib(--> Str) is export
{
    return $bridge-lib if $resolved;
    $resolved = True;

    unless needs-bridge() {
        $available = False;
        return $bridge-lib = '';
    }

    if %*ENV<DB_DUCKDB_SHIM> -> $explicit {
        return $bridge-lib = $explicit
            if $explicit.chars && $explicit.IO.e;
    }

    my $out = build-shim();
    $available = $out.defined && $out.e;
    $bridge-lib = $available ?? $out.absolute !! '';
}

#| True when the bridge was found/built, i.e. when symbol names must be
#| translated to their `dbd_*_p` form.
sub bridge-active(--> Bool) is export
{
    bridge-lib();
    $available;
}

#| Map a libduckdb symbol to the name it carries in the bridge.
#| duckdb_fetch_chunk -> dbd_fetch_chunk_p
sub bridge-symbol(Str $name --> Str) is export
{
    return $name unless bridge-active();
    'dbd_' ~ $name.subst(/^ 'duckdb_' /, '') ~ '_p';
}
