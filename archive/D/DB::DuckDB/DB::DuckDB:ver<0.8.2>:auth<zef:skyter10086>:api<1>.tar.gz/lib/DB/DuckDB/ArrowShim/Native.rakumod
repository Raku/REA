#| Native binding for resources/duckdb-arrow-shim.c.
#|
#| Deliberately a separate module from DB::DuckDB::ArrowShim: loading this one
#| requires the compiled library to exist, so Arrow.rakumod pulls it in with a
#| `require` inside a try and falls back to the in-Raku release callback on
#| machines without a C compiler.
#|
#| Not exported: callers reach it via `require` and grab &release-array.
unit module DB::DuckDB::ArrowShim::Native;

use NativeCall;
use DB::DuckDB::ArrowShim;

# Resolved on first use rather than in a BEGIN block: the parent module has to
# be compiled (and may have to compile the C shim) before the path is known,
# and NativeCall accepts a Callable here -- the same trick
# DB::DuckDB::VarcharShim::Native uses.
my Str $lib-cache;

sub shim-library(--> Str)
{
    return $lib-cache if $lib-cache.defined;
    my $path = DB::DuckDB::ArrowShim::shim-lib();
    die 'DB::DuckDB::ArrowShim: the C shim is not available'
        unless $path.chars;
    $lib-cache = $path;
}

our sub dkd-arrow-release(Pointer $array --> int32)
    is native(&shim-library) is symbol('dkd_arrow_release') { * }

our sub dkd-arrow-probe(Pointer $array --> int64)
    is native(&shim-library) is symbol('dkd_arrow_probe') { * }

our sub dkd-arrow-shim-abi(--> int32)
    is native(&shim-library) is symbol('dkd_arrow_shim_abi') { * }
