unit class DB::DuckDB::Error is Exception is export;

#| Every failure raised by the driver is an instance of this class.
#| `DB` itself has no common exception base class, so each driver ships
#| its own -- this is the DB::DuckDB counterpart of DB::SQLite::Error.
has Int $.code;
has Str $.message;

method gist(--> Str)
{
    my $prefix = 'DuckDB error';
    $prefix ~= " ({$!code})" if $!code.defined;
    $!message.defined && $!message.chars
        ?? "$prefix: {$!message}"
        !! $prefix;
}
