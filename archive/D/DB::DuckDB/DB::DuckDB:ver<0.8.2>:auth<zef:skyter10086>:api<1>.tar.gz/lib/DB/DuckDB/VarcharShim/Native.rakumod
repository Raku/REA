﻿#| Native binding for resources/duckdb-varchar-shim.c.
#|
#| Deliberately a separate module from DB::DuckDB::VarcharShim: loading this
#| one requires the compiled library to exist, and Result loads it with a
#| `require` inside a try so a machine without a C compiler still gets a
#| working driver (just with the slower per-value VARCHAR decoder).
#|
#| Not exported: callers reach it via `require` and grab &unpack-varchar.
unit module DB::DuckDB::VarcharShim::Native;

use NativeCall;
use DB::DuckDB::VarcharShim;

# Resolved on first use rather than in a BEGIN block: the parent module has to
# be compiled (and possibly compile the C shim) before the path is known, and
# NativeCall accepts a Callable here -- the same trick DB::DuckDB::Native uses
# for its library path.
my Str $lib-cache;

sub shim-library(--> Str)
{
    return $lib-cache if $lib-cache.defined;
    my $path = DB::DuckDB::VarcharShim::shim-lib();
    die 'DB::DuckDB::VarcharShim: the C shim is not available'
        unless $path.chars;
    $lib-cache = $path;
}

sub dkd-varchar-unpack(Pointer $data, Pointer $validity, uint64 $n,
                       Pointer $out, uint64 $cap,
                       Pointer $offsets, Pointer $lens,
                       Pointer $nulls --> uint64)
    is native(&shim-library) is symbol('dkd_varchar_unpack') { * }

sub dkd-varchar-join(Pointer $data, Pointer $validity, uint64 $n,
                     Pointer $out, uint64 $cap,
                     uint8 $sep, uint8 $nullmark --> uint64)
    is native(&shim-library) is symbol('dkd_varchar_join') { * }

sub dkd-string-layout(CArray[uint32] $out --> uint64)
    is native(&shim-library) is symbol('dkd_string_layout') { * }

sub dkd-temporal-join(Pointer $data, Pointer $validity, uint64 $n,
                      Pointer $out, uint64 $cap,
                      uint32 $kind, uint8 $sep, uint8 $nullmark --> uint64)
    is native(&shim-library) is symbol('dkd_temporal_join') { * }

sub dkd-decimal-join(Pointer $data, Pointer $validity, uint64 $n,
                     Pointer $out, uint64 $cap,
                     uint32 $scale, uint32 $internal-type, uint32 $flags,
                     uint8 $sep, uint8 $nullmark --> uint64)
    is native(&shim-library) is symbol('dkd_decimal_join') { * }

sub dkd-shim-abi(--> uint32)
    is native(&shim-library) is symbol('dkd_shim_abi') { * }

#: ABI version of the loaded library, so the caller can tell a current build
#: from one left in the cache by an older driver.
our sub shim-abi(--> UInt)
{
    my uint32 $v = dkd-shim-abi();
    $v.UInt;
}

# The two "fall back" answers of the C side, spelled out as plain numbers so
# the comparisons here do not depend on a native uint64 constant being boxed.
my constant NOT-FLAT     = 18446744073709551615;
my constant SEP-CONFLICT = 18446744073709551614;

# Separator and NULL marker of the joined form.  Both are control bytes no
# sane text column contains; a payload that does hold one makes the C side
# refuse the join (SEP-CONFLICT) and the caller uses the offset table instead.
my constant JOIN-SEP      = 1;
my constant JOIN-NULL     = 2;

#| Byte layout of duckdb_string_t as the shim sees it: (sizeof, length@,
#| inlined@, ptr@).  Used by the tests to fail loudly if DuckDB ever changes
#| the struct underneath us.
our sub string-layout(--> List)
{
    my CArray[uint32] $o .= new;
    $o[2] = 0;
    my uint64 $size = dkd-string-layout($o);
    ($size, $o[0], $o[1], $o[2]).List;
}

#| Join `$n` VARCHAR values into one buffer and hand back the Split result:
#| a List of Str (Any for NULL), in row order.
#|
#| This is the fast path.  The C side lays the values out back to back with a
#| one byte separator between them, so a single decode plus a single split
#| produces every Str at once -- no per-value slice, no per-value allocation.
#| Multibyte payloads need no special case: split counts characters, not
#| bytes, and the separator is one character either way.
#|
#| Returns Nil when the chunk must be decoded differently: the vector is not
#| flat (dictionary/selection vector), or some payload already contains the
#| separator or NULL marker byte.
our sub join-varchar(Pointer $data, Pointer $validity, uint64 $n --> Mu)
{
    return () if $n == 0;

    # Sizing pass: n-1 separators, one byte per NULL, plus the payloads.
    my uint64 $total = dkd-varchar-join($data, $validity, $n,
        Pointer, 0, JOIN-SEP, JOIN-NULL);
    return Nil if $total >= SEP-CONFLICT;

    # Zero bytes of payload happens only for a single empty string (any NULL
    # or any second row would have contributed a byte), but spell the general
    # case out so the caller never sees a short list.
    unless $total {
        my @empty;
        my uint64 $i = 0;
        while $i < $n { @empty.push: ''; $i++ }
        return @empty.List;
    }

    my Buf $buf = Buf.allocate($total);
    my uint64 $written = dkd-varchar-join($data, $validity, $n,
        nativecast(Pointer, $buf), $total, JOIN-SEP, JOIN-NULL);
    return Nil if $written >= SEP-CONFLICT;
    return Nil unless $written == $total;

    my Str $flat = $buf.decode('utf-8');
    my Str $sep  = chr(JOIN-SEP);
    my Str $nul  = chr(JOIN-NULL);

    my @out = $flat.split($sep).List;

    # Str.split drops trailing empty strings, so a column whose last values
    # are empty strings comes back short.  Padding is exact: the C side never
    # writes a separator after the last value, so a trailing token is missing
    # only when it was an empty string.
    my uint64 $got = @out.elems;
    while $got < $n { @out.push: ''; $got++ }

    # NULL mapping costs one test per value, so it is skipped outright when
    # the joined text holds no NULL marker at all -- the common all-valid case.
    if $flat.index($nul).defined {
        my uint64 $i = 0;
        while $i < $n {
            my $v = @out[$i];
            @out[$i] = Any if $v.chars == 1 && $v.ord == JOIN-NULL;
            $i++;
        }
    }

    @out.List;
}

#| Join `$n` rendered temporal values (DATE / TIMESTAMP / TIME) into one
#| buffer and hand back the Split result: a List of Str (Any for NULL), in
#| row order.
#|
#| `$kind` selects the interpretation of the raw vector data; the numbers
#| match DKD_TEMPORAL_* in the C file and are spelled out in
#| DB::DuckDB::Result, which is the only caller.
#|
#| Unlike join-varchar() there is no separator-conflict check to do: every
#| rendered value is ASCII digits plus '-', ':', '.' or ' ', so a payload can
#| never contain the separator.  Returns Nil only when the chunk has to be
#| rendered some other way (no flat data pointer).
our sub join-temporal(Pointer $data, Pointer $validity, uint64 $n,
                      UInt $kind --> Mu)
{
    return () if $n == 0;

    my uint64 $total = dkd-temporal-join($data, $validity, $n,
        Pointer, 0, $kind, JOIN-SEP, JOIN-NULL);
    return Nil if $total >= SEP-CONFLICT;

    my Buf $buf = Buf.allocate($total || 1);
    my uint64 $written = dkd-temporal-join($data, $validity, $n,
        nativecast(Pointer, $buf), $total, $kind, JOIN-SEP, JOIN-NULL);
    return Nil if $written >= SEP-CONFLICT;
    return Nil unless $written == $total;

    my Str $flat = $buf.decode('utf-8');
    my Str $nul  = chr(JOIN-NULL);

    my @out = $flat.split(chr(JOIN-SEP)).List;

    # Str.split drops trailing empty strings; no rendered value is empty, so
    # this only ever corrects a column the C side could not fill completely.
    my uint64 $got = @out.elems;
    while $got < $n { @out.push: ''; $got++ }

    if $flat.index($nul).defined {
        my uint64 $i = 0;
        while $i < $n {
            my $v = @out[$i];
            @out[$i] = Any if $v.chars == 1 && $v.ord == JOIN-NULL;
            $i++;
        }
    }

    @out.List;
}

#| Join `$n` DECIMAL values into one buffer and hand back a List of Str
#| (Any for NULL), in row order.
#|
#| `$internal-type` selects the element width of the raw vector (1 = int16,
#| 2 = int32, 3 = int64, 4 = the 128 bit slot, the DKD_DEC_* codes) and
#| `$scale` is the number of decimal digits DuckDB prints.
#|
#| `$trim-zero` mirrors DuckDB's quirk for the all-fraction widths: a
#| DECIMAL(9,9) prints `.5`, where DECIMAL(10,9) prints `0.5`.  The caller
#| sets it from `width == scale`.
our sub join-decimal(Pointer $data, Pointer $validity, uint64 $n,
                     UInt $scale, UInt $internal-type, Bool $trim-zero = False --> Mu)
{
    return () if $n == 0;

    my uint32 $flags = $trim-zero ?? 1 !! 0;

    my uint64 $total = dkd-decimal-join($data, $validity, $n, Pointer, 0,
        $scale, $internal-type, $flags, JOIN-SEP, JOIN-NULL);
    return Nil if $total >= SEP-CONFLICT;

    my Buf $buf = Buf.allocate($total || 1);
    my uint64 $written = dkd-decimal-join($data, $validity, $n,
        nativecast(Pointer, $buf), $total,
        $scale, $internal-type, $flags, JOIN-SEP, JOIN-NULL);
    return Nil if $written >= SEP-CONFLICT;
    return Nil unless $written == $total;

    my Str $flat = $buf.decode('utf-8');
    my Str $nul  = chr(JOIN-NULL);

    my @out = $flat.split(chr(JOIN-SEP)).List;

    my uint64 $got = @out.elems;
    while $got < $n { @out.push: ''; $got++ }

    if $flat.index($nul).defined {
        my uint64 $i = 0;
        while $i < $n {
            my $v = @out[$i];
            @out[$i] = Any if $v.chars == 1 && $v.ord == JOIN-NULL;
            $i++;
        }
    }

    @out.List;
}

#| Unpack `$n` VARCHAR values into a List of Str (Any for NULL).
#|
#| The C side copies every payload into one contiguous buffer and reports the
#| offset/length of each value, so the per-value cost here is a slice instead
#| of a 16-byte struct read plus a byte-at-a-time Buf build.
#|
#| Kept as the fallback for vectors join-varchar() refuses.  Both of those
#| refusals are rare (non-flat vectors, payloads containing 0x01/0x02 bytes),
#| so the per-value slicing below no longer shows up in normal use.
our sub unpack-varchar(Pointer $data, Pointer $validity, uint64 $n --> Mu)
{
    return () if $n == 0;

    my uint64 $i;

    # Sizing pass: C reports how many payload bytes the column needs.
    my uint64 $total = dkd-varchar-unpack($data, $validity, $n, Pointer, 0,
        Pointer, Pointer, Pointer);
    # UINT64_MAX means the vector is not flat (a dictionary or selection
    # vector); the caller must fall back to the per-value decoder.
    return Nil if $total >= SEP-CONFLICT;

    my CArray[uint64] $offs  .= new;
    my CArray[uint32] $lens  .= new;
    my CArray[uint8]  $nulls .= new;
    $offs[$n - 1]  = 0;
    $lens[$n - 1]  = 0;
    $nulls[$n - 1] = 0;

    if $total == 0 {
        my @empty;
        $i = 0;
        while $i < $n { @empty.push: $nulls[$i] ?? Any !! ''; $i++ }
        return @empty.List;
    }

    my Buf $buf = Buf.allocate($total);
    my uint64 $written = dkd-varchar-unpack($data, $validity, $n, nativecast(Pointer, $buf), $total,
        nativecast(Pointer, $offs), nativecast(Pointer, $lens), nativecast(Pointer, $nulls));
    return Nil if $written >= SEP-CONFLICT;

    # Fast path: a pure ASCII column has one byte per character, so the whole
    # buffer can be decoded once and every value sliced out as a substring.
    # This is the common case for ids, keys and enum-like labels.
    my Str $flat = $buf.decode('utf-8');
    if $flat.chars == $total {
        my @out;
        $i = 0;
        while $i < $n {
            @out.push: $nulls[$i] ?? Any !! $flat.substr($offs[$i], $lens[$i]);
            $i++;
        }
        return @out.List;
    }

    # Multibyte payload: bytes and characters no longer line up, so $flat
    # cannot be sliced by byte offset.  Re-run the vector through the join
    # decoder -- one decode plus one split costs a fraction of decoding one
    # subbuf per value, and multibyte columns are exactly the case where that
    # per-value cost used to dominate.
    my $joined = join-varchar($data, $validity, $n);
    return $joined if $joined.defined;

    # Last resort: join refuses a vector whose payloads contain the separator
    # or NULL marker bytes, so slice and decode value by value.  Every payload
    # is a complete UTF-8 string, so no slice can split a character.
    my @out;
    $i = 0;
    while $i < $n {
        @out.push: $nulls[$i]
            ?? Any
            !! $buf.subbuf($offs[$i], $lens[$i]).decode('utf-8');
        $i++;
    }
    @out.List;
}
