#| One chunk of a streaming result.
#|
#| Lifetime matters here: a chunk handed out by a streaming result owns the
#| memory the driver is about to reuse, so pulling the next chunk expires it.
#| Reading an expired chunk throws instead of returning whatever the engine
#| happened to leave in that buffer -- a silent wrong answer is the worst
#| possible failure mode for a data driver.
#|
#| The normal pattern is therefore to consume the chunk inside the loop body:
#|
#|     for $result.chunks -> $chunk {
#|         for $chunk.column-view(0).to-list -> $v { ... }
#|     }
unit class DB::DuckDB::Chunk;

use DB::DuckDB::ColumnView;

has Int $.size;
has $.result;      # keeps the owning Result (and its buffers) alive
has @!views;
has Bool $!expired = False;

submethod BUILD(Int :$!size!, :$!result, :@views)
{
    @!views = @views.List;
}

#| True once the driver has moved on to the next chunk.  The size and the
#| column count stay readable: they are plain numbers, not pointers.
method is-valid(--> Bool) { !$!expired }

#| Called by DB::DuckDB::Result.chunks before the next chunk is pulled.
method expire(--> Nil)
{
        return if $!expired;
        $!expired = True;
        .expired = True for @!views;
        Nil;
}

method !guard(--> Nil)
{
        die "streaming chunk is stale: it was recycled when the next chunk "
          ~ "was pulled; consume each chunk inside the loop body"
            if $!expired;
}

method column-count(--> Int) { @!views.elems }

#| The zero-copy view of column $i, with the same API as
#| `DB::DuckDB::Result.column-views`.
method column-view(Int $i --> DB::DuckDB::ColumnView)
{
    self!guard;
    @!views[$i];
}

method columns(--> List) { self!guard; @!views.List }

#| One row as an Array.  Boxes every value, so it is the convenience path.
method row(Int $i --> Array)
{
    self!guard;
    my @row;
    for @!views -> $v { @row.push: $v.at($i) }
    @row;
}

#| Every row of the chunk, boxed.  Same caveat as .row -- this allocates one
#| object per value, which is exactly what the views exist to avoid.
method to-rows(--> List)
{
    self!guard;
    my @rows;
    for ^$!size -> int $i { @rows.push: self!row-unchecked($i) }
    @rows.List;
}

# Internal: the guard has already run for the whole chunk.
method !row-unchecked(Int $i --> Array)
{
    my @row;
    for @!views -> $v { @row.push: $v.at($i) }
    @row;
}
