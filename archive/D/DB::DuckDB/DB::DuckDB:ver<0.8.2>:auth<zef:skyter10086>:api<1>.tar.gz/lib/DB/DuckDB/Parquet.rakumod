#| SQL builders for DuckDB's Parquet reader and writer.
#|
#| Why this module exists
#| ======================
#| The DuckDB 2.0 C API exposes *no* Parquet entry point: `duckdb.h` has no
#| `duckdb_read_parquet`, no `duckdb_append_parquet`, nothing with "parquet"
#| in the name.  Parquet lives in the SQL layer only, as the `read_parquet`
#| table function and the `COPY ... TO ... (FORMAT PARQUET)` statement, and
#| the extension is statically linked into the library this driver loads
#| (`duckdb_extensions()` reports it loaded).
#|
#| So "direct Parquet" here means: compose those two statements correctly, and
#| let the rows travel through the existing result path.  That is not a
#| compromise -- the reader hands back the same chunk/vector layout as a table
#| scan, so the VARCHAR, temporal and DECIMAL C channels apply unchanged
#| (measured: within 7% of reading the equivalent table).
#|
#| Escaping rules
#| ==============
#| * **Reads bind the path as a parameter**, so a path is never interpolated
#|   and never needs escaping, even when it contains a quote.  Multiple paths
#|   go in as `read_parquet([?, ?])`; one placeholder per path, still bound.
#| * **Writes interpolate** the target path and the table name, because
#|   `COPY` takes a literal there.  Both go through `parquet-literal` /
#|   `parquet-ident`, and the compression name is checked against a whitelist
#|   instead of being pasted through.
unit module DB::DuckDB::Parquet;

use DB::DuckDB::Error;

#| Compression codecs DuckDB's Parquet writer accepts.  Anything outside this
#| list is rejected before the statement is built, so the value can never
#| reach the parser as raw SQL.
our constant PARQUET-COMPRESSIONS =
    <snappy zstd gzip lz4 brotli lzma uncompressed>;

#| Normalise an option that callers may pass either as a single value
#| (`:columns<id>`) or as a list (`:columns<id name>`).  A bare String is not
#| a Positional, so a `:@columns` parameter would reject the single-value
#| form -- which is exactly the one people write first.
my sub as-list($value --> List)
{
    return () unless $value.defined;
    $value ~~ Positional ?? $value.List !! ($value,).List;
}

#| Render a value as a SQL string literal.  DuckDB doubles an embedded quote
#| (SQL standard); backslashes are ordinary characters, which is why a Windows
#| path can go in as-is.
our sub parquet-literal(Str:D $value --> Str) is export
{
    "'" ~ $value.subst("'", "''", :g) ~ "'";
}

#| Render a name as a quoted identifier.  Always quoted, so keywords, spaces
#| and dots in a table name are taken literally rather than parsed.
our sub parquet-ident(Str:D $name --> Str) is export
{
    '"' ~ $name.subst('"', '""', :g) ~ '"';
}

#| `"schema"."table"`, or just `"table"` when no schema is given.
our sub parquet-source(Str:D $table, Str :$schema --> Str) is export
{
    $schema.defined && $schema.chars
        ?? parquet-ident($schema) ~ '.' ~ parquet-ident($table)
        !! parquet-ident($table);
}

#| The parenthesised option list of a `COPY ... TO` statement.
our sub parquet-write-options(Str :$compression,
                              Int :row-group-size($row-group-size),
                              :partition-by($partition-by),
                              Bool :overwrite-or-ignore($overwrite-or-ignore) = False --> Str)
    is export
{
    my @partition-by = as-list($partition-by);
    my @opts = 'format parquet';

    if $compression.defined {
        my $codec = $compression.lc;
        unless $codec eq any(PARQUET-COMPRESSIONS) {
            die DB::DuckDB::Error.new(
                message => "unsupported Parquet compression '{$compression}'; "
                         ~ "expected one of {PARQUET-COMPRESSIONS.join(', ')}",
            );
        }
        @opts.push: "compression {$codec}";
    }

    if $row-group-size.defined {
        die DB::DuckDB::Error.new(message => "row-group-size must be positive, got {$row-group-size}")
            unless $row-group-size > 0;
        @opts.push: "row_group_size {$row-group-size}";
    }

    if @partition-by.elems {
        @opts.push: 'partition_by (' ~ @partition-by.map({ parquet-ident($_.Str) }).join(', ') ~ ')';
    }

    @opts.push: 'overwrite_or_ignore true' if $overwrite-or-ignore;

    @opts.join(', ');
}

#| `select ... from read_parquet(?)`, or with a list of placeholders when more
#| than one path is read at once.  The paths are the caller's bind arguments,
#| in order.
our sub parquet-read-sql(:columns($columns),
                         Bool :union-by-name($union-by-name) = False,
                         Bool :$filename = False,
                         Bool :hive-partitioning($hive-partitioning),
                         Int :path-count($path-count) = 1 --> Str) is export
{
    die DB::DuckDB::Error.new(message => 'path-count must be at least 1')
        unless $path-count >= 1;

    my @column-names = as-list($columns);

    my @select = @column-names.elems
        ?? @column-names.map({ parquet-ident($_.Str) })
        !! ('*',);

    my $argument = $path-count > 1
        ?? '[' ~ ('?' xx $path-count).join(', ') ~ ']'
        !! '?';

    my @opts;
    @opts.push: 'union_by_name = true'  if $union-by-name;
    @opts.push: 'filename = true'       if $filename;
    @opts.push: 'hive_partitioning = ' ~ ($hive-partitioning ?? 'true' !! 'false')
        if $hive-partitioning.defined;

    my $arglist = @opts.elems ?? $argument ~ ', ' ~ @opts.join(', ') !! $argument;

    "select {@select.join(', ')} from read_parquet({$arglist})";
}

#| `copy <source> to 'path' (format parquet, ...)`.  `$sql` marks the source
#| as a query instead of a table name; a query is wrapped in parentheses, a
#| table name is quoted and may carry a schema.
our sub parquet-copy-sql(Str:D $target, Str:D $source, Bool :$sql = False,
                         Str :$schema, Str :$compression,
                         Int :row-group-size($row-group-size),
                         :partition-by($partition-by),
                         Bool :overwrite-or-ignore($overwrite-or-ignore) = False --> Str)
    is export
{
    die DB::DuckDB::Error.new(message => 'target path must not be empty')
        unless $target.chars;

    my $from = $sql ?? "({$source})" !! parquet-source($source, :$schema);

    my $options = parquet-write-options(
        :$compression,
        :row-group-size($row-group-size),
        :partition-by($partition-by),
        :overwrite-or-ignore($overwrite-or-ignore),
    );

    "copy {$from} to {parquet-literal($target)} ({$options})";
}
