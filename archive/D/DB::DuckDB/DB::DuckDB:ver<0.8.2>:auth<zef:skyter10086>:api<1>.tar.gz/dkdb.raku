use DB::DuckDB;
my $db = DB::DuckDB.new;
say $db.query('select 42').value;
say $db.query('select name from META6.json');