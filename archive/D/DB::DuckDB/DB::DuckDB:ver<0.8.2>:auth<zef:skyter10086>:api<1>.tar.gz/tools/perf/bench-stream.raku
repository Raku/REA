﻿use DB::DuckDB;

# Streaming read: does prefetching the next chunk while the current one is
# being decoded actually pay off?  Two workloads, because the answer depends
# on where the time goes:
#   decode-bound -- the engine emits rows cheaply, Raku decoding dominates,
#                   so there is little to overlap.
#   engine-bound -- the engine does real work per row (md5), so a fetch costs
#                   far more than the decode and overlap should show up.
# Sums are compared between modes so a prefetch bug shows as a mismatch.

my $rows = (%*ENV<ROWS> // 300_000).Int;
my $reps = (%*ENV<REPS> // 7).Int;

my $db = DB::DuckDB.new;
my $c  = $db.connect;
$c.execute("CREATE TABLE big AS SELECT i::BIGINT AS id, (i % 1000)::INT AS k, "
         ~ "repeat('y', 40) AS s FROM range($rows) tbl(i)");

my %case =
    decode-bound => 'SELECT id, k, s FROM big',
    engine-bound => "SELECT i::BIGINT AS id, sum(j)::BIGINT AS h FROM range(200000) t(i), range(60) u(j) GROUP BY i";

sub consume(Str $sql --> Hash) {
    my $t0 = now;
    my $r = $c.query($sql, :stream);
    my $first = Nil;
    my Int $sum = 0;
    for $r.chunks -> $chunk {
        $first //= (now - $t0).Num;
        my $id = $chunk.column-view(0);
        my $other = $chunk.column-view($chunk.column-count - 1);
        $sum += $id.sum + ($other.at(0).chars // 0);
    }
    my $total = (now - $t0).Num;
    $r.free;
    { :$sum, :$first, :$total };
}

sub median(@v) { my @s = @v.sort; @s[@s.elems div 2] }

printf "rows=%d reps=%d\n", $rows, $reps;
for %case.keys.sort -> $name {
    my $sql = %case{$name};
    my %res;
    for 'prefetch', 'noprefetch' -> $mode {
        %*ENV<DB_DUCKDB_NO_PREFETCH> = $mode eq 'noprefetch' ?? '1' !! Nil;
        consume($sql);                       # warm up the plan and the table
        my (@first, @total);
        my $sum;
        for ^$reps {
            my %r = consume($sql);
            $sum = %r<sum>;
            @first.push: %r<first>;
            @total.push: %r<total>;
        }
        %res{$mode} = { :first(median(@first)), :total(median(@total)), :$sum };
    }
    %*ENV<DB_DUCKDB_NO_PREFETCH> = Nil;

    my %p = %res<prefetch>;
    my %s = %res<noprefetch>;
    printf "%-13s prefetch total=%6.1f ms first=%5.1f ms | serial total=%6.1f ms | total %.2fx first %.2fx | sum %s\n",
        $name, %p<total> * 1000, %p<first> * 1000, %s<total> * 1000,
        (%s<total> / %p<total>) // 0, (%s<first> / %p<first>) // 0,
        %p<sum> == %s<sum> ?? 'match' !! 'MISMATCH';
}

