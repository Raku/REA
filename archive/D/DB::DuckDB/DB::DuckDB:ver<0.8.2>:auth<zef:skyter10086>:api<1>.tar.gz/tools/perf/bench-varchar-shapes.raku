use lib 'C:/Users/Admin/DB-DuckDB/lib';
use DB::DuckDB;

# Measures the VARCHAR decode cost of three column shapes, both through the
# eager column() path and through the lazy column-view path, so the three
# decode strategies (join / unpack / pure Raku) can be compared by running the
# same script with DB_DUCKDB_NO_VARCHAR_JOIN=1 or DB_DUCKDB_NO_VARCHAR_SHIM=1.
#
# The reported number is microseconds per value for the decode step only: the
# same scan is also run on an integer column and that cost is subtracted, so
# what is left is the string assembly work the shim is supposed to remove.

my $rows    = (%*ENV<DB_DUCKDB_BENCH_ROWS> // 1_000_000).Int;
my $best-of = (%*ENV<DB_DUCKDB_BENCH_REPS> // 3).Int;

sub best(&code --> Num) {
    my $min = Inf;
    for ^$best-of {
        my $t0 = (now).Num;
        code();
        my $d = (now).Num - $t0;
        $min = $d if $d < $min;
    }
    $min;
}

my $db = DB::DuckDB.new;
$db.execute("create table short as
    select i as id, 'k' || (i % 1000)::varchar as s from range(1, {$rows + 1}) t(i)");
$db.execute("create table long as
    select i as id, repeat('abcdefghij', 9) || i::varchar as s
    from range(1, {$rows + 1}) t(i)");
$db.execute("create table mb as
    select i as id, 'ce' || chr(20013) || chr(25991) || i::varchar as s
    from range(1, {$rows + 1}) t(i)");

my %control;
my %eager;
my %view;
my %chars;

for <short long mb> -> $tbl {
    # control: same scan, integer column, so no string work at all
    %control{$tbl} = best({ $db.query("select id from $tbl").column(0).elems });

    %eager{$tbl} = best({
        my @c = $db.query("select s from $tbl").column(0);
        die 'eager width' unless @c.elems == $rows;
        %chars{$tbl} = @c[0].chars;
    });

    %view{$tbl} = best({
        my $v = $db.query("select s from $tbl").column-view(0);
        my @c = $v.to-list;
        die 'view width' unless @c.elems == $rows;
    });
}

my $mode = %*ENV<DB_DUCKDB_NO_VARCHAR_SHIM> ?? 'pure-raku'
        !! %*ENV<DB_DUCKDB_NO_VARCHAR_JOIN>  ?? 'unpack'
        !! 'join';

for <short long mb> -> $tbl {
    my $ctl = %control{$tbl};
    for <eager view> -> $path {
        my $total = $path eq 'eager' ?? %eager{$tbl} !! %view{$tbl};
        my $net   = ($total - $ctl) max 0;
        printf "mode=%-10s shape=%-5s path=%-5s total=%7.1fms net=%7.1fms us_per_val=%5.2f chars=%d\n",
            $mode, $tbl, $path, $total * 1000, $net * 1000, $net * 1e6 / $rows,
            %chars{$tbl} // 0;
    }
}
