#!/usr/bin/env raku
# Regression bench for chunk ownership (P1-7 follow-up).
#
#   raku -Ilib tools/perf/bench-arrow-leak.raku
#   ROUNDS=200 MODE=arrow raku -Ilib tools/perf/bench-arrow-leak.raku
#
# MODE=noarrow  plain read path (column-views / to-list)
# MODE=arrow    DB::DuckDB::Arrow conversion per chunk
# MODE=views    column-views() with lazy VARCHAR decoding
#
# Before 0.6.6 the arrow mode grew ~23 MB per round (the duckdb_result_get_chunk
# handles were never destroyed); it should now hold flat.  Watch the RSS column:
# a plateau with a saw-tooth is GC noise, a monotonic climb is a leak.

use DB::DuckDB;
use DB::DuckDB::Arrow;

sub rss-mb(--> Int) {
    state $is-win = $*DISTRO.is-win;
    if $is-win {
        my $pid = $*PID;
        my $out = qqx{powershell -NoProfile -Command "(Get-Process -Id $pid).WorkingSet64"} .trim;
        return ($out.Numeric / 1048576).Int if $out.Numeric;
        return 0;
    }
    my $status = try slurp '/proc/self/status';
    return 0 without $status;
    for $status.lines {
        # /proc/self/status separates the label from the value with a tab (and
        # pads with spaces), so a literal single space after the colon matches
        # nothing and the whole column read as 0.
        return ($0.Numeric / 1024).Int if /^ 'VmRSS:' \s+ (\d+)/;
    }
    0;
}

my $rounds = (%*ENV<ROUNDS> // 100).Int;
my $mode   = %*ENV<MODE> // 'arrow';
my $rows   = (%*ENV<ROWS> // 200_000).Int;

my $db = DB::DuckDB.new;
my $c  = $db.connect;
$c.execute("CREATE TABLE big AS SELECT i::BIGINT AS id, (i % 1000)::INT AS k, "
         ~ "repeat('y', 40) AS s FROM range($rows) tbl(i)");

my $base = 0;
my $sum  = 0;

for ^$rounds -> $i {
    my $r = $c.query('SELECT id, k, s FROM big');

    if $mode eq 'arrow' {
        with-arrow-chunks($r, -> $ch, $ci { $sum += $ch.length });
    }
    elsif $mode eq 'views' {
        my @v = $r.column-views;
        $sum += @v[0].sum;
        $sum += @v[2].count;
    }
    else {
        my @cols = $r.column-arrays;
        $sum += @cols[0].elems;
    }

    $r.free;

    if $i == 4 { $base = rss-mb() }
    if $i % 10 == 0 || $i == $rounds - 1 {
        my $mb = rss-mb();
        note sprintf("round %3d  rss=%4d MB  delta=%+5d MB  sum=%d",
                     $i, $mb, ($base ?? $mb - $base !! 0), $sum);
    }
}

note "DONE mode=$mode rounds=$rounds rows=$rows sum=$sum";
