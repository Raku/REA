use v6;
use DB::DuckDB;

# Single-case write benchmark.  Usage:
#     raku -I<lib> tools/perf/bench-write.raku <mode> <rows> [batch]
#
# modes:
#   sql          multi-value INSERT built in Raku, 1 transaction   (works on the
#                pre-P0-3 driver too -> this is the "before" baseline)
#   prepared     one prepared single-row INSERT per row, 1 transaction (baseline)
#   insert-rows  $db.insert-rows('m', @rows)                        (new API)
#   exec-many    $db.execute-many('insert into m values (?,?,?,?)')  (new API)
#   appender     explicit $db.appender('m') + append-row loop        (new API)
#
# Each process does one mode only: Raku/MoovVM GC noise from a previous case
# would otherwise contaminate the next one (measured 2-3x swings).
#
# Note the `d` column is `$_ / 3`, i.e. a Rat, so every row also pays a
# Rat -> num coercion.  That coercion is the floor this benchmark can reach:
# with `($_ / 3).Num` the same 4-column insert runs about 2.5x faster.  Use
# the Rat form for realistic worst-case numbers, the .Num form for the
# binding's own cost.

my $mode  = @*ARGS[0] // 'sql';
my $rows  = (@*ARGS[1] // 100_000).Int;
my $batch = (@*ARGS[2] // 1_000).Int;

my $db = DB::DuckDB.new;
$db.execute('create table m (i bigint, s varchar, d double, b boolean)');

my @data = (^$rows).map({ ($_, "name{$_}", $_ / 3, $_ % 2 == 0) }).List;

my $t0 = now;
my $written;

given $mode {
    when 'sql' {
        $db.execute('BEGIN TRANSACTION');
        my $buf = '';
        my $n = 0;
        for @data -> $r {
            $buf ~= ',' if $n;
            $buf ~= "({$r[0]}, '{$r[1]}', {$r[2]}, {$r[3]})";
            if ++$n == $batch {
                $db.execute("insert into m values $buf");
                $buf = '';
                $n = 0;
            }
        }
        $db.execute("insert into m values $buf") if $n;
        $db.execute('COMMIT');
        $written = $db.query('select count(*) from m').value;
    }
    when 'prepared' {
        $db.execute('BEGIN TRANSACTION');
        my $sth = $db.prepare('insert into m values (?, ?, ?, ?)');
        $sth.execute(|$_) for @data;
        $db.execute('COMMIT');
        $written = $db.query('select count(*) from m').value;
    }
    when 'insert-rows' {
        $written = $db.insert-rows('m', @data);
    }
    when 'exec-many' {
        $written = $db.execute-many('insert into m values (?, ?, ?, ?)', @data);
    }
    when 'appender' {
        my $ap = $db.appender('m');
        $ap.append-row($_) for @data;
        $ap.free;
        $written = $ap.rows;
    }
    default { die "unknown mode $mode" }
}

my $ms = (now - $t0) * 1000;
my $count = $db.query('select count(*) from m').value;
printf "MODE=%s ROWS=%d MS=%.0f WRITTEN=%s COUNT=%s SUM=%s\n",
    $mode, $rows, $ms, $written // '-', $count,
    $db.query('select coalesce(sum(i), 0) from m').value;
