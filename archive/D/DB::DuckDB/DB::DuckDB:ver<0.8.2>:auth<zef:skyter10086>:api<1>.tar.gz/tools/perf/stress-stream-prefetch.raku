﻿use DB::DuckDB;

# Streaming robustness: 120 short streams drained, 40 abandoned mid-way (the
# worker must be joined and its queued chunk destroyed), 40 drained twice
# through free/DESTROY paths.  RSS is printed every 30 rounds so a leaking
# prefetch buffer shows up as a slope.

my $db = DB::DuckDB.new;
my $c  = $db.connect;
$c.execute("CREATE TABLE big AS SELECT i::BIGINT AS id, repeat('z', 40) AS s FROM range(200000) tbl(i)");

sub rss-mb(--> Int) {
    my $out = qqx{powershell -NoProfile -Command "(Get-Process -Id $*PID).WorkingSet64"} .trim;
    $out.Numeric ?? ($out.Numeric / 1048576).Int !! 0;
}

my $sql = 'SELECT id, s FROM big';
sub drain(--> Int) {
    my $r = $c.query($sql, :stream);
    my Int $n = 0;
    for $r.chunks -> $chunk { $n += $chunk.size }
    $r.free;
    $n;
}

sub abandon(--> Int) {
    my $r = $c.query($sql, :stream);
    my Int $n = 0;
    for $r.chunks -> $chunk {
        $n += $chunk.size;
        last if $n >= 2048;      # stop after the first chunk
    }
    $r.free;                     # worker is still mid-fetch at this point
    $n;
}

# Sanity: the abandoned path must still give correct rows on a fresh stream.
my $first = abandon();
my $again = drain();
die "abandon returned $first, expected 200000" unless $again == 200_000;

for ^60 -> $i {
    drain();
    abandon();
    drain();
    abandon();
    note "round $i rss=" ~ rss-mb() if $i % 15 == 0;
}
note "STREAM STRESS DONE rss=" ~ rss-mb();

