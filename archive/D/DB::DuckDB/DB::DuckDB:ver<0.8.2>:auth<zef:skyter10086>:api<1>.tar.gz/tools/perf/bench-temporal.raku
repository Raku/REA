use DB::DuckDB;

# Temporal decode benchmark.
#
# Run it once per mode in a fresh process -- two modes in one process share a
# warm heap, and then the GC cost of the first mode leaks into the second.
#
#   raku -Ilib tools/perf/bench-temporal.raku 1000000
#   DB_DUCKDB_NO_TEMPORAL_SHIM=1 raku -Ilib tools/perf/bench-temporal.raku 1000000
#
# Prints microseconds per value for a single column and per row for a three
# column arrays() read, plus DuckDB's own ::VARCHAR cast as a reference point.

my Int $rows = (@*ARGS[0] // 1_000_000).Int;

my $mode = %*ENV<DB_DUCKDB_NO_TEMPORAL_SHIM> ?? 'raku' !! 'shim';

my $db = DB::DuckDB.new;

# Values spread over 68 years so no column degenerates into one constant, and
# so both the pre-1970 and the post-1970 paths get exercised.
$db.execute(qq:to/SQL/);
    create table t as select
        i as id,
        DATE '1970-01-01' + CAST((i % 25000) AS INTEGER) - 12000                  as d,
        make_timestamp(i * 1234567)                                             as ts,
        CAST(TIME '00:00:00' + (i % 86400)::BIGINT * INTERVAL 1 SECOND AS TIME)  as tm
      from range(0, $rows) r(i)
    SQL

sub best-of(Int $n, &code --> Num) {
    my @t;
    for ^$n {
        my $start = now;
        code();
        @t.push: (now - $start).Num;
    }
    @t.min;
}

# Warm up: the first scan pays for statement preparation and the initial
# vector allocation on DuckDB's side.
$db.query('select d, ts, tm from t').arrays;

my $per-row = best-of(3, { $db.query('select d, ts, tm from t').arrays }) / $rows * 1e6;
my $d       = best-of(3, { $db.query('select d from t').column(0)   }) / $rows * 1e6;
my $ts      = best-of(3, { $db.query('select ts from t').column(0)  }) / $rows * 1e6;
my $tm      = best-of(3, { $db.query('select tm from t').column(0)  }) / $rows * 1e6;

# Reference: DuckDB formats the values itself, the driver only collects Str.
my $cast    = best-of(3, { $db.query('select ts::VARCHAR from t').column(0) }) / $rows * 1e6;

say "mode=$mode rows=$rows";
say "  arrays 3 cols  {sprintf('%6.2f', $per-row)} us/row";
say "  DATE           {sprintf('%6.2f', $d)} us/value";
say "  TIMESTAMP      {sprintf('%6.2f', $ts)} us/value";
say "  TIME           {sprintf('%6.2f', $tm)} us/value";
say "  TIMESTAMP cast {sprintf('%6.2f', $cast)} us/value   (DuckDB renders, reference)";

$db.finish;
