use DB::DuckDB;

# Interleaved measurement: every repetition times serial and each parallel
# degree back to back, so slow drift on a busy machine hits all of them
# equally.  Reported figure is the median per configuration.

my $rows  = (%*ENV<ROWS>  // 200_000).Int;
my $reps  = (%*ENV<REPS>  // 15).Int;
my @degs  = (%*ENV<DEGS>  // '2,4').split(',')».Int;

my $db = DB::DuckDB.new;
my $c  = $db.connect;
$c.execute("CREATE TABLE big AS SELECT i::BIGINT AS id, (i % 1000)::INT AS k, "
         ~ "repeat('y', 40) AS s FROM range($rows) tbl(i)");

my $sql = %*ENV<SQL> // 'SELECT id, s FROM big';

sub median(@v) { my @s = @v.sort; @s[@s.elems div 2] }

# Warm up: first query pays for the shim probe and the type caches.
for ^3 {
    my $r = $c.query($sql);
    $r.column-arrays(:parallel, :degree(@degs[0]));
    $r.free;
}

my %t;
%t<serial> = [];
%t{"d$_"}  = [] for @degs;
%t{"r$_"}  = [] for @degs;      # paired ratio, robust against drift

for ^$reps -> $i {
    my $serial;
    {
        my $r = $c.query($sql);
        my $t0 = now;
        my @cols = $r.column-arrays;
        $serial = (now - $t0).Num;
        %t<serial>.push: $serial;
        $r.free;
    }
    for @degs -> $deg {
        my $r = $c.query($sql);
        my $t0 = now;
        my @cols = $r.column-arrays(:parallel, :degree($deg));
        my $d = (now - $t0).Num;
        %t{"d$deg"}.push: $d;
        %t{"r$deg"}.push: $serial / $d;
        $r.free;
    }
}

sub min-of(@v) { @v.min }

my $base = median(%t<serial>);
printf "rows=%d sql=%s reps=%d\n", $rows, $sql, $reps;
printf "serial           %7.1f ms  (min %7.1f)\n", $base * 1000, min-of(%t<serial>) * 1000;
for @degs -> $deg {
    my $m = median(%t{"d$deg"});
    printf "parallel deg=%-2d  %7.1f ms  (min %7.1f)  %5.2fx by median, %5.2fx by paired ratio\n",
        $deg, $m * 1000, min-of(%t{"d$deg"}) * 1000,
        $base / $m, median(%t{"r$deg"});
}
