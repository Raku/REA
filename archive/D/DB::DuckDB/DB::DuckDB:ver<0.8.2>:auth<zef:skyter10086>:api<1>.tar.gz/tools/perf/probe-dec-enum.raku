use DB::DuckDB;

# Probe: how much is left in DECIMAL and ENUM?
#
# Neither is currently rendered by DuckDB -- DECIMAL already has a native
# unscaled-integer path (push-decimals / decimal-fixed), ENUM still falls
# through to the generic text path.  So the question is different for each:
#
#   DECIMAL  what share of the per-value cost is Raku's fixed-point formatting,
#            i.e. what would moving decimal-fixed into the C shim buy?
#   ENUM     how expensive is the current text path, and how cheap would
#            "index + dictionary lookup" be?
#
# Every measurement is microseconds per value, best of 3, 200k rows by default.

my Int $rows = (@*ARGS[0] // 200_000).Int;

my $db = DB::DuckDB.new;

$db.execute(qq:to/SQL/);
    create type mood as enum (
        'alpha','bravo','charlie','delta','echo','foxtrot','golf','hotel',
        'india','juliet','kilo','lima','mike','november','oscar','papa',
        'quebec','romeo','sierra','tango'
    )
    SQL

$db.execute(qq:to/SQL/);
    create table t as select
        i as id,
        CAST(((i % 2000001) - 1000000) AS DECIMAL(18,4))  as d18,
        CAST(((i % 2000001) - 1000000) AS DECIMAL(38,10)) as d38,
        CAST(((i % 2000001) - 1000000) AS DECIMAL(9,2))   as d9,
        (['alpha','bravo','charlie','delta','echo','foxtrot','golf','hotel',
          'india','juliet','kilo','lima','mike','november','oscar','papa',
          'quebec','romeo','sierra','tango'])[(i % 20) + 1]::mood as e
      from range(0, $rows) r(i)
    SQL

sub best-of(Int $n, &code --> Num) {
    my @t;
    for ^$n {
        my $start = now;
        code();
        @t.push: (now - $start).Num;
    }
    @t.min;
}

sub us-per(Int $n, &code --> Num) { best-of(3, &code) / $n * 1e6 }

# Warm up: first scan pays statement preparation and vector allocation.
$db.query('select d18, d38, d9, e from t').arrays;

my $int-baseline = us-per($rows, { $db.query('select id from t').column(0) });
my $d18          = us-per($rows, { $db.query('select d18 from t').column(0) });
my $d9           = us-per($rows, { $db.query('select d9 from t').column(0) });
my $d38          = us-per($rows, { $db.query('select d38 from t').column(0) });
my $d18-raw      = us-per($rows, { $db.query('select (d18 * 10000)::BIGINT from t').column(0) });
my $d18-cast     = us-per($rows, { $db.query('select d18::VARCHAR from t').column(0) });
my $d9-cast      = us-per($rows, { $db.query('select d9::VARCHAR from t').column(0) });
my $d38-cast     = us-per($rows, { $db.query('select d38::VARCHAR from t').column(0) });
my $d18-double   = us-per($rows, { $db.query('select d18::DOUBLE from t').column(0) });

my $enum-text    = us-per($rows, { $db.query('select e from t').column(0) });
my $enum-cast    = us-per($rows, { $db.query('select e::VARCHAR from t').column(0) });

# The index behind an ENUM value: enum_code() is DuckDB's own accessor.
my $enum-raw = try {
    us-per($rows, { $db.query('select enum_code(e) from t').column(0) });
} // NaN;

# The three- and four-column arrays read shows whether the per-column costs
# actually add up in the shape a caller uses.
my $arrays = us-per($rows, { $db.query('select d18, d38, d9, e from t').arrays });

say "rows=$rows";
say "  int column (baseline)      {sprintf('%6.2f', $int-baseline)} us/value";
say "  DECIMAL(9,2)   native      {sprintf('%6.2f', $d9)} us/value";
say "  DECIMAL(18,4)  native      {sprintf('%6.2f', $d18)} us/value";
say "  DECIMAL(38,10) native      {sprintf('%6.2f', $d38)} us/value";
say "  DECIMAL(18,4)  raw int64   {sprintf('%6.2f', $d18-raw)} us/value   (payload read, no formatting)";
say "  DECIMAL(18,4)  ::DOUBLE    {sprintf('%6.2f', $d18-double)} us/value   (plain numeric decode)";
say "  DECIMAL(9,2)   ::VARCHAR   {sprintf('%6.2f', $d9-cast)} us/value   (DuckDB formats, reference)";
say "  DECIMAL(18,4)  ::VARCHAR   {sprintf('%6.2f', $d18-cast)} us/value   (DuckDB formats, reference)";
say "  DECIMAL(38,10) ::VARCHAR   {sprintf('%6.2f', $d38-cast)} us/value   (DuckDB formats, reference)";
say "  ENUM           current     {sprintf('%6.2f', $enum-text)} us/value";
say "  ENUM           ::VARCHAR   {sprintf('%6.2f', $enum-cast)} us/value";
say "  ENUM           enum_code   {sprintf('%6.2f', $enum-raw)} us/value   (index only)";
say "  arrays of 4                {sprintf('%6.2f', $arrays)} us/row";
say "";
say "  => DECIMAL formatting share  {sprintf('%5.1f', ($d18 - $d18-raw) / $d18 * 100)}% of the native path";
say "  => DECIMAL vs DuckDB cast    {sprintf('%5.2f', $d18 / $d18-cast)}x (above 1 means the cast is cheaper)";
say "  => ENUM index vs text        {sprintf('%5.2f', $enum-text / $enum-raw)}x cheaper to read the index";
say "";

# ------------------------------------------------------------------ pure Raku
# What the Raku side alone costs, with no driver in the way: this is the
# upper bound on what a C shim could remove for DECIMAL, and the floor for
# ENUM once the index is in hand.

my Int $scale = 4;
my Int $div = 10 ** $scale;
my Str $pad = '0' x $scale;
my @vals = (0 ..^ $rows).map: { ($_ % 2000001) - 1000000 };

my sub decimal-fixed(Int $v, Int $scale, Int $div, Str $pad --> Str) {
    my Bool $neg = $v < 0;
    my Int $abs  = $neg ?? -$v !! $v;
    my Str $ip   = ($abs div $div).Str;
    return ($neg ?? '-' !! '') ~ $ip if $scale == 0;
    my Str $fp = ($abs % $div).Str;
    $fp = $pad.substr(0, $scale - $fp.chars) ~ $fp if $fp.chars < $scale;
    ($neg ?? '-' !! '') ~ $ip ~ '.' ~ $fp;
}

my $fmt = best-of(3, { @vals.map({ decimal-fixed($_, $scale, $div, $pad) }).eager }) / $rows * 1e6;

my @dict = <alpha bravo charlie delta echo foxtrot golf hotel india juliet
            kilo lima mike november oscar papa quebec romeo sierra tango>;
my @idx  = (0 ..^ $rows).map: { $_ % 20 };
my $lookup = best-of(3, { @idx.map({ @dict[$_] }).eager }) / $rows * 1e6;

say "pure Raku, no driver:";
say "  decimal-fixed loop         {sprintf('%6.2f', $fmt)} us/value";
say "  dictionary lookup loop     {sprintf('%6.2f', $lookup)} us/value";

$db.finish;
