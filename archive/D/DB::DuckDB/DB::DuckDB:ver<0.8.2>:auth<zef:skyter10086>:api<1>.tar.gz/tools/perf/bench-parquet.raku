use DB::DuckDB;

# Parquet read/write baseline: what the wrapper costs against a table scan, and
# what COPY buys against the batch write paths.
#
#     raku -Ilib tools/perf/bench-parquet.raku [rows]
#
# Single process, single mode, best of three, because interleaving modes lets
# GC noise from one run land in the next.

my Int $rows = @*ARGS.elems && @*ARGS[0] ~~ /^\d+$/ ?? @*ARGS[0].Int !! 1_000_000;

my $dir = $*TMPDIR.add("dkd-bench-parquet-{$*PID}-{now.Int}");
$dir.mkdir;
my $pq = $dir.add('bench.parquet');

sub cleanup(IO::Path $d)
{
    if $*DISTRO.is-win { run 'cmd', '/c', 'rmdir', '/s', '/q', $d.absolute, :!out, :!err }
    else               { run 'rm', '-rf', $d.absolute, :!out, :!err }
}
END { cleanup($dir) }

my sub best-of(Int $rounds, &code --> Num)
{
    my $best = Inf;
    for ^$rounds {
        my $t = now;
        code();
        my $d = (now - $t).Num;
        $best = $d if $d < $best;
    }
    $best;
}

my sub row(Str $label, Num $seconds, Str $unit --> Nil)
{
    printf "  %-34s %8.3f s   %8.2f us/%s\n", $label, $seconds, $seconds * 1e6 / $rows, $unit;
}

my $db = DB::DuckDB.new;

say "rows: $rows";

my $build = best-of 1, {
    $db.execute("create or replace table t as select i::bigint as i,
        'v' || (i % 1000)::varchar as s,
        DATE '2020-01-01' + (i % 3000)::int as d,
        ((i % 100000)::decimal(18,4)) / 100 as m
      from range($rows) t(i)");
};
printf "build table: %.3f s\n", $build;

say "\n-- write --";
my $w = best-of 3, { $db.write-parquet($pq.Str, 't', compression => 'zstd') };
printf "  write-parquet (COPY, zstd)         %8.3f s   %8.2f us/row   %.2f MiB\n",
    $w, $w * 1e6 / $rows, $pq.s / 1024 / 1024;

my $insert = best-of 3, {
    $db.execute('create or replace table ins as select * from t limit 0');
    $db.execute-many('insert into ins values (?, ?, ?, ?)',
                     (^($rows min 20_000)).map({ ( $_, "v{$_ % 1000}", '2020-01-01', '0.01' ) }));
};
printf "  execute-many, 20k rows             %8.3f s   %8.2f us/row (extrapolated)\n",
    $insert, $insert * 1e6 / 20_000;

say "\n-- read: engine side, no Raku decoding --";
for 'table', 'parquet' -> $kind {
    my $sql = "select sum(i), count(*) from "
            ~ ($kind eq 'table' ?? 't' !! 'read_parquet(?)');
    my $t = best-of 3, { $kind eq 'table' ?? $db.query($sql).row !! $db.query($sql, $pq.Str).row };
    printf "  %-34s %8.3f s\n", "$kind aggregate", $t;
}

say "\n-- read: Raku side, one column decoded --";
for 'table', 'parquet' -> $kind {
    for 'i', 's' -> $col {
        my $sql = "select $col from " ~ ($kind eq 'table' ?? 't' !! 'read_parquet(?)');
        my $t = best-of 3, {
            my $n = $kind eq 'table'
                ?? $db.query($sql).column(0).elems
                !! $db.query($sql, $pq.Str).column(0).elems;
            die "bad row count $n" unless $n == $rows;
        };
        row "$kind.$col", $t, 'value';
    }
}

say "\n-- read: all four columns, column-arrays --";
for 'table', 'parquet' -> $kind {
    my $sql = 'select * from ' ~ ($kind eq 'table' ?? 't' !! 'read_parquet(?)');
    my $t = best-of 3, {
        my $a = $kind eq 'table'
            ?? $db.query($sql).column-arrays
            !! $db.query($sql, $pq.Str).column-arrays;
        die 'bad column count' unless $a.elems == 4;
    };
    row $kind, $t, 'row';
}

say "\n-- stream: first chunk --";
for 'table', 'parquet' -> $kind {
    my $sql = 'select * from ' ~ ($kind eq 'table' ?? 't' !! 'read_parquet(?)');
    my $t = now;
    my $r = $kind eq 'table' ?? $db.query($sql, :stream) !! $db.query($sql, $pq.Str, :stream);
    my $first = $r.chunks.head;
    my $d = (now - $t).Num;
    $r.free;
    printf "  %-34s %8.1f ms  (%d rows)\n", "$kind first chunk", $d * 1000, $first.size;
}

say "\n-- footer only --";
my $meta = best-of 3, { $db.parquet-metadata($pq.Str) };
printf "  parquet-metadata                   %8.1f ms\n", $meta * 1000;
my $schema = best-of 3, { $db.parquet-schema($pq.Str) };
printf "  parquet-schema                     %8.1f ms\n", $schema * 1000;
