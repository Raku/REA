use lib 'C:/Users/Admin/DB-DuckDB/lib';
use DB::DuckDB;

# Does the lazy column-view path accumulate native memory?
#
# Rakudo cannot answer that by itself here: nqp::collectgarbage does not exist on
# Rakudo 2026.09 (the deleted probe-views-gc.raku died at compile time on it), and
# pulling a powershell child out of the Rakudo process corrupts the parent console
# with CLIXML.  So this script only does the work and prints a "round N" heartbeat;
# RSS is sampled from the outside by probe-views-rss.ps1, which correlates the curve
# with those heartbeats.
#
#   powershell -File tools/perf/probe-views-rss.ps1                 # lazy views
#   powershell -File tools/perf/probe-views-rss.ps1 -Path chunks    # control
#
# A monotonic rise on "views" while "chunks" stays flat is the leak signature;
# two identical high-water sawtooths mean the GC is just holding on to freed
# natives, which is not a leak and cannot be optimised away.
#
# Env: DB_DUCKDB_BENCH_ROWS (rows), DB_DUCKDB_PROBE_ROUNDS (rounds),
#      DB_DUCKDB_PROBE_PATH (views|chunks).

my $rows   = (%*ENV<DB_DUCKDB_BENCH_ROWS>  // 200_000).Int;
my $rounds = (%*ENV<DB_DUCKDB_PROBE_ROUNDS> // 100).Int;
my $path   = %*ENV<DB_DUCKDB_PROBE_PATH>   // 'views';

my $db  = DB::DuckDB.new;
my $pad = 'abcdefgh' x 9;    # 72 chars, so 2k rows of s1+s2 is a few hundred KB

$db.execute("create table t as
    select i as id, '{$pad}' || i::varchar as s1, 'x' || i::varchar as s2, i * 2 as n
    from range(1, {$rows + 1}) t(i)");

say "setup rows=$rows rounds=$rounds path=$path";

my $total = now;

for 1 .. $rounds -> $r {
    if $path eq 'chunks' {
        # Control: the same bytes get decoded, but one row at a time through the
        # chunk API, which never keeps a long-lived owned chunk handle around.
        my $seen = 0;
        for $db.query('select s1, s2, n from t').chunks -> $chunk {
            $seen += $chunk.to-rows.elems;
        }
    }
    else {
        # The lazy path: build every ColumnView, read every column out, drop it all.
        my @views = $db.query('select s1, s2, n from t').column-views;
        my $seen  = 0;
        for @views -> $v {
            $seen += $v.to-list.elems;
        }
    }

    say "round $r";
}

say "done " ~ (now - $total).Int ~ "s";
