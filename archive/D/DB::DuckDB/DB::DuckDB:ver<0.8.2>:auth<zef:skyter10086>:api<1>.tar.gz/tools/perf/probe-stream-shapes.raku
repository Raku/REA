use DB::DuckDB;

# Which streaming shapes are actually engine-bound?  Measured as time to
# first chunk (engine work before anything can be decoded) against total.
my $db = DB::DuckDB.new;
my $c  = $db.connect;

my %q =
    md5      => "SELECT i::BIGINT AS id, md5(i::VARCHAR) AS h FROM range(300000) tbl(i)",
    joinagg  => "SELECT i::BIGINT AS id, sum(j)::BIGINT AS h FROM range(200000) t(i), range(60) u(j) GROUP BY i",
    exprs    => "SELECT i::BIGINT AS id, (sqrt(i)*sin(i)*cos(i))::DOUBLE AS h FROM range(300000) tbl(i)",
    varchar  => "SELECT i::BIGINT AS id, repeat(md5(i::VARCHAR), 2) AS h FROM range(300000) tbl(i)";

for %q.keys.sort -> $k {
    my $t0 = now;
    my $r = $c.query(%q{$k}, :stream);
    my $first = Nil;
    my Int $n = 0;
    for $r.chunks -> $chunk {
        $first //= (now - $t0).Num;
        $n += $chunk.size;
    }
    my $total = (now - $t0).Num;
    $r.free;
    printf "%-8s rows=%7d first=%6.1f ms total=%7.1f ms  engine-share=%s\n",
        $k, $n, $first * 1000, $total * 1000,
        $total > 0 ?? (($first / $total) * 100).fmt('%.0f%%') !! '-';
}
