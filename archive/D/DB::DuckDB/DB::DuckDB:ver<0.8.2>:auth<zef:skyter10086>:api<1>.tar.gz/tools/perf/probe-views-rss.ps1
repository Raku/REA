<#
.SYNOPSIS
    Samples the working set of probe-views-rss.raku every half second and reports the
    RSS curve: overall slope, per-third slopes, and the plateau the GC oscillates in.

.DESCRIPTION
    The sampling has to live outside the Rakudo process: nqp::collectgarbage is absent
    on Rakudo 2026.09, and spawning powershell from inside Rakudo welds CLIXML into the
    parent console.  So the Raku side just prints "round N" heartbeats and this script
    watches the child's WorkingSet64 from here.

    Run it twice, once per path, and compare:

        powershell -File tools/perf/probe-views-rss.ps1
        powershell -File tools/perf/probe-views-rss.ps1 -Path chunks

    A leak shows up as a rising *last-third* slope with a decent fit; a GC high-water
    mark climbs once, then flattens while the min/max band stays wide.

.EXAMPLE
    powershell -File tools/perf/probe-views-rss.ps1 -Rows 200000 -Rounds 300
#>
[CmdletBinding()]
param(
    [ValidateSet('views', 'chunks')][string]$Path = 'views',
    [int]$Rows = 200000,
    [int]$Rounds = 300,
    [int]$IntervalMs = 500,
    [string]$Csv = (Join-Path $env:TEMP 'probe-views-rss.csv')
)

$ErrorActionPreference = 'Stop'

$perf    = $PSScriptRoot
$repo    = Split-Path -Parent (Split-Path -Parent $perf)
$log     = [IO.Path]::ChangeExtension($Csv, '.log')
$rakuCmd = Get-Command raku -ErrorAction SilentlyContinue
$raku    = if ($rakuCmd) { $rakuCmd.Source } else { 'C:\rakudo\bin\raku.exe' }
if (-not (Test-Path -LiteralPath $raku)) { throw "raku not found; put it on PATH" }
if (-not (Test-Path -LiteralPath (Join-Path $perf 'probe-views-rss.raku'))) {
    throw "probe-views-rss.raku missing next to this script"
}

# Least squares over (seconds, MB).  A leak is a steep slope with a tight fit; a GC
# high-water mark is a flat slope with r2 near zero and a wide min/max band.
function Measure-Trend([object[]]$Pts) {
    $m = $Pts.Count
    if ($m -lt 2) { return [pscustomobject]@{ slope = 0.0; r2 = 0.0 } }
    [double]$sx = 0; [double]$sy = 0; [double]$sxy = 0; [double]$sxx = 0; [double]$syy = 0
    foreach ($p in $Pts) {
        $sx += $p.t; $sy += $p.rss_mb
        $sxy += $p.t * $p.rss_mb; $sxx += $p.t * $p.t; $syy += $p.rss_mb * $p.rss_mb
    }
    $den = $m * $sxx - $sx * $sx
    $slope = if ($den -ne 0) { ($m * $sxy - $sx * $sy) / $den } else { 0.0 }
    $rden = $den * ($m * $syy - $sy * $sy)
    $r2 = if ($rden -gt 0) { [math]::Pow($m * $sxy - $sx * $sy, 2) / $rden } else { 0.0 }
    [pscustomobject]@{ slope = $slope; r2 = $r2 }
}

$env:DB_DUCKDB_BENCH_ROWS   = "$Rows"
$env:DB_DUCKDB_PROBE_ROUNDS = "$Rounds"
$env:DB_DUCKDB_PROBE_PATH   = $Path

Write-Host "path=$Path rows=$Rows rounds=$Rounds"

$proc = Start-Process -FilePath $raku `
    -ArgumentList '-Ilib', 'tools/perf/probe-views-rss.raku' `
    -WorkingDirectory $repo -NoNewWindow -PassThru `
    -RedirectStandardOutput $log

$samples = New-Object System.Collections.Generic.List[object]
$clock   = [Diagnostics.Stopwatch]::StartNew()

while (-not $proc.HasExited) {
    $proc.Refresh()
    $samples.Add([pscustomobject]@{
        t      = [math]::Round($clock.Elapsed.TotalSeconds, 2)
        rss_mb = [math]::Round($proc.WorkingSet64 / 1MB, 1)
    })
    Start-Sleep -Milliseconds $IntervalMs
}

$proc.WaitForExit()
$clock.Stop()

$samples | Export-Csv -LiteralPath $Csv -NoTypeInformation -Encoding UTF8

$n = $samples.Count
if ($n -lt 3) { throw "too few samples ($n); did the Raku run die? see $log" }

$span  = $samples[$n - 1].t - $samples[0].t
$third = [int][math]::Floor($n / 3)
$overall = Measure-Trend $samples.ToArray()
$early   = Measure-Trend ($samples.GetRange(0, $third)).ToArray()
$middle  = Measure-Trend ($samples.GetRange($third, $third)).ToArray()
$late    = Measure-Trend ($samples.GetRange($n - $third, $third)).ToArray()

# Plateau = what the GC oscillates in after the warm-up fifth is dropped.
$t0   = $samples[0].t
$tail = $samples | Where-Object { $_.t -ge ($t0 + $span * 0.2) }
$lo   = ($tail | Measure-Object rss_mb -Minimum).Minimum
$hi   = ($tail | Measure-Object rss_mb -Maximum).Maximum

$lateSpan  = $samples[$n - 1].t - $samples[$n - $third].t
$lateGrow  = $late.slope * $lateSpan
$verdict = if ($span -lt 20) {
    'run too short to judge -- raise -Rounds'
} elseif ($late.r2 -ge 0.5 -and $lateGrow -gt ($hi - $lo) * 0.5) {
    'STILL CLIMBING in the last third -- leak signature, investigate'
} else {
    'flattened out -- high-water sawtooth, no leak'
}

""
"samples   $n over $([math]::Round($span, 1)) s (every ${IntervalMs} ms)"
"log       $log"
"csv       $Csv"
"first     $($samples[0].rss_mb) MB"
"slope     all $([math]::Round($overall.slope * 60, 2))  first $([math]::Round($early.slope * 60, 2))  mid $([math]::Round($middle.slope * 60, 2))  last $([math]::Round($late.slope * 60, 2)) MB/min"
"fit       last-third r2=$([math]::Round($late.r2, 2))"
"platform  $lo .. $hi MB (last 80% of the run, band $([math]::Round($hi - $lo, 1)) MB)"
"last gain $([math]::Round($lateGrow, 1)) MB over $([math]::Round($lateSpan, 1)) s"
"verdict   $verdict"

$exit = (Select-String -LiteralPath $log -Pattern '^done ' | Select-Object -Last 1).Line
if ($exit) { "child     $exit" } else { "child     no 'done' line -- the run did not finish, read $log" }
