use lib 'lib';
use DB::DuckDB;
use Test;

# Correctness regression for P0-3 (appender bulk-write path) and P0-4
# (session options).  Every check is written so that a silent fall-back to
# the prepared-statement path still has to produce the *same* data: the tests
# assert on what ends up in the table, not on which internal path ran.

# NOTE: this Rakudo build crashes inside Test's *failure* diagnostics
# (`is`/`is-deeply` printing a diff), which would hide every later check.
# So comparisons go through `ok` and the diagnostics are printed by hand.
# Canonical form: container type (List vs Array) is irrelevant, but element
# types are not - a Rat 1.5 must not pass for a Num 1.5e0.
sub norm($v --> Str)
{
    $v ~~ Positional ?? ('[' ~ $v.map(&norm).join(',') ~ ']') !! ($v.WHAT.^name ~ ':' ~ $v.raku)
}
sub same-deep($got, $want --> Bool) { norm($got) eq norm($want) }
sub died(&code --> Bool) { !(try { code(); True }) }

sub check-deep($got, $want, Str $desc)
{
    my $ok = same-deep($got, $want);
    unless $ok {                       # print *before* ok: a failing ok aborts
        say "  # {$desc}";             # this Rakudo's Test diag, so dump first
        say "  #   got:  {norm($got)}";
        say "  #   want: {norm($want)}";
    }
    ok $ok, $desc;
}

my $db = DB::DuckDB.new;

# ---------------------------------------------------------------- appender
$db.execute('create table t (i integer, s varchar, d double, b boolean)');

my $ap = $db.appender('t');
ok $ap.width == 4, 'appender reports the column count';
ok $ap.rows == 0, 'fresh appender row count is 0';

$ap.append-row(1, 'a', 1.5, True);              # list of values
$ap.append-row([2, 'b', 2.5, False]);           # single Positional
$ap.append-row([3, 'c']);                       # trailing DEFAULT / NULL
$ap.append-row([4, Any, Any, Any]);             # explicit NULLs
ok $ap.rows == 0 + 4, 'append-row counts every call';

$ap.flush;                                      # mid-stream flush keeps it usable
$ap.append-row([5, 'e', 5.5, True]);
$ap.close;
ok $ap.rows == 5, 'row count survives close';
nok $ap.alive, 'appender is not alive after close';
ok died({ $ap.append-row(6, 'f', 6.5, True) }), 'appending after close dies';

check-deep $db.query('select i from t order by i').arrays.map({ .head }).List,
    (1, 2, 3, 4, 5), 'every appended row landed';
check-deep $db.query('select i, s, d, b from t order by i').arrays.List,
    ((1, 'a', 1.5e0, True), (2, 'b', 2.5e0, False), (3, 'c', Any, Any),
     (4, Any, Any, Any), (5, 'e', 5.5e0, True)).List,
    'values, DEFAULTs and NULLs round-trip';

# ------------------------------------------------- appender.append-rows bulk
$db.execute('create table bulk (a bigint, b varchar)');
my $bulk = $db.appender('bulk');
ok $bulk.append-rows(((1, 'x'), (2, 'y'), (3, 'z'))) == 3, 'append-rows returns the row count';
$bulk.close;
ok $db.query('select count(*) from bulk').column(0)[0] == 3, 'append-rows wrote 3 rows';

# ------------------------------------------------------------ insert-rows API
$db.execute('create table ins (i integer, s varchar, d double)');
ok $db.insert-rows('ins', ((1, 'a', 1.0e0), (2, 'b', 2.0e0), (3, 'c', 3.0e0))) == 3,
    'insert-rows returns the number of rows written';
ok $db.query('select count(*) from ins').column(0)[0] == 3, 'insert-rows persisted the batch';
check-deep $db.query('select i, s, d from ins order by i').arrays.List,
    ((1, 'a', 1.0e0), (2, 'b', 2.0e0), (3, 'c', 3.0e0)).List,
    'insert-rows values are exact';

# every scalar value type the appender understands
$db.execute('create table types (b boolean, i bigint, d double, s varchar, bl blob)');
$db.insert-rows('types', ((True, 42, 1.25e0, 'hi', Blob.new(1, 2, 255)),));
check-deep $db.query('select b, i, d, s, octet_length(bl) from types').arrays.List,
    ((True, 42, 1.25e0, 'hi', 3),).List, 'bool/int64/double/varchar/blob all append';

ok $db.insert-rows('ins', ()) == 0, 'empty batch returns 0';

# atomicity: a batch that violates a constraint must leave the table untouched
$db.execute('create table uniq (i integer primary key)');
$db.insert-rows('uniq', ((1,), (2,)));
ok died({ $db.insert-rows('uniq', ((3,), (1,))) }), 'duplicate key inside a batch dies';
ok $db.query('select count(*) from uniq').column(0)[0] == 2,
    'failed batch was rolled back, table still has 2 rows';

# ------------------------------------------------------------- execute-many
$db.execute('create table em (i integer, s varchar)');
ok $db.execute-many('insert into em values (?, ?)', ((1, 'a'), (2, 'b'), (3, 'c'))) == 3,
    'execute-many returns the number of executions';
check-deep $db.query('select i, s from em order by i').arrays.List,
    ((1, 'a'), (2, 'b'), (3, 'c')).List, 'execute-many wrote the rows';

# reordered column list must be mapped back onto table order
$db.execute('create table ord (i integer, s varchar, d double)');
ok $db.execute-many('insert into ord (d, i, s) values (?, ?, ?)',
        ((1.0e0, 1, 'a'), (2.0e0, 2, 'b'))) == 2, 'reordered insert accepted';
check-deep $db.query('select i, s, d from ord order by i').arrays.List,
    ((1, 'a', 1.0e0), (2, 'b', 2.0e0)).List, 'reordered values land in the right columns';

# ON CONFLICT cannot go through the appender -> must still work via fallback
$db.execute('create table up (i integer primary key, s varchar)');
$db.execute-many('insert into up values (?, ?)', ((1, 'a'), (2, 'b')));
ok $db.execute-many(
        'insert into up values (?, ?) on conflict (i) do update set s = excluded.s',
        ((1, 'z'), (3, 'c'))) == 2, 'ON CONFLICT statement is accepted';
check-deep $db.query('select i, s from up order by i').arrays.List,
    ((1, 'z'), (2, 'b'), (3, 'c')).List,
    'ON CONFLICT fell back to the prepared path and updated';

# a non-VALUES statement keeps working through the prepared fallback
$db.execute('create table fallback (i integer)');
ok $db.execute-many('insert into fallback select ? * 2', ((1,), (2,))) == 2,
    'INSERT ... SELECT falls back and still runs';
check-deep $db.query('select i from fallback order by i').arrays.List,
    ((2,), (4,)).List, 'fallback evaluated the expression';

# ------------------------------------------------------- connection-level API
my $conn = $db.session;
$db.execute('create table via_conn (i integer, s varchar)');
my $cap = $conn.appender('via_conn');
$cap.append-row(1, 'x');
$cap.close;
ok $conn.insert-rows('via_conn', ((2, 'y'),)) == 1, 'Connection.insert-rows works';
ok $conn.execute-many('insert into via_conn values (?, ?)', ((3, 'z'),)) == 1,
    'Connection.execute-many works';
ok $db.query('select count(*) from via_conn').column(0)[0] == 3,
    'driver and connection APIs share the same session';

# ------------------------------------------------------- session options P0-4
my %defaults = $db.effective-session-options;
nok %defaults<preserve_insertion_order>:exists,
    'preserve_insertion_order is left alone by default (conservative)';
nok %defaults<threads>:exists, 'threads is not overridden by default';
nok %defaults<memory_limit>:exists, 'memory_limit is not overridden by default';

my $tuned = DB::DuckDB.new(
    :preserve-insertion-order(False),
    :threads(2),
    :memory-limit('512MB'),
    :session-options('enable_progress_bar' => False),
);
my %expected = $tuned.effective-session-options;
ok %expected<preserve_insertion_order> == False, 'preserve_insertion_order=false is propagated';
ok %expected<threads> == 2, 'threads is propagated';
ok %expected<memory_limit> eq '512MB', 'memory_limit is propagated';
ok %expected<enable_progress_bar> == False, 'extra SET options pass through';

$tuned.execute('create table st (i integer)');
$tuned.insert-rows('st', ((1,), (2,)));
ok $tuned.query('select count(*) from st').column(0)[0] == 2,
    'a tuned session still reads and writes correctly';

# the options really reached DuckDB, not just the Raku-side hash
# current_setting() hands back a real BOOLEAN for this setting, so compare on
# `.Str.lc` instead of a bool/string mix that never matches.
ok $tuned.query('select current_setting(?)', 'preserve_insertion_order').column(0)[0].Str.lc eq 'false',
    'engine reports preserve_insertion_order=false';
ok $tuned.query('select current_setting(?)', 'threads').column(0)[0] eq '2',
    'engine reports threads=2';
ok $tuned.query('select current_setting(?)', 'memory_limit').column(0)[0] ~~ /MiB | GiB/,
    'engine reports a memory limit in effect';

# mutating an attribute + re-applying must reach the live session
$tuned.threads = 3;
$tuned.apply-session-options;
ok $tuned.query('select current_setting(?)', 'threads').column(0)[0] eq '3',
    'apply-session-options pushes a changed attribute to the live session';

# set-session-option applies immediately too
$db.set-session-option('threads', 1);
ok $db.query('select current_setting(?)', 'threads').column(0)[0] eq '1',
    'set-session-option reaches an already-open session';

# a table's columns are reported in order; an unknown table reports none
# `st` lives in $tuned's in-memory database, not in $db's -- ask the
# connection that actually created it.
check-deep $tuned.session.table-columns('st'), ('i',), 'table-columns reports order';
check-deep $conn.table-columns('no-such-table'), (), 'unknown table yields no columns';

done-testing;
