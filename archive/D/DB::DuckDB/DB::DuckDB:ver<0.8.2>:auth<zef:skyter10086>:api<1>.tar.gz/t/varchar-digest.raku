﻿use Test;
use DB::DuckDB;

# Digest of a VARCHAR column as seen through the driver: the two code paths
# (C shim vs. per-value decoder) must agree exactly.  Run by 04-varchar-shim
# as a child process with DB_DUCKDB_NO_VARCHAR_SHIM set/unset.
my $db-file = $*TMPDIR.add("db-duckdb-varchar-digest-{$*PID}.duckdb");
LEAVE { $db-file.unlink if $db-file.e }

my $db = DB::DuckDB.new(path => $db-file.absolute);
LEAVE { $db.finish }

$db.execute('create table v (id integer, s varchar)');
$db.execute(q:to/SQL/), 3000;
    insert into v
    select i,
           case i % 6
             when 0 then NULL
             when 1 then ''
             when 2 then 'short_' || i
             when 3 then 'a_payload_longer_than_twelve_bytes_' || i
             when 4 then '中文值_' || i
             else 'mix混合_' || i || '_tail'
           end
      from range(1, 3001) t(i)
    SQL

my @vals = $db.query('select id, s from v order by id').column(1);

# A cheap order sensitive digest plus a few spot values.
my $chars = 0;
my $nulls = 0;
for @vals -> $v {
    if $v.defined { $chars += $v.chars } else { $nulls++ }
}

say "count={@vals.elems}";
say "chars=$chars";
say "nulls=$nulls";
say "first={@vals[0].raku}";
say "inline={@vals[1].raku}";
say "long={@vals[2].raku}";
say "multibyte={@vals[3].raku}";
say "mixed={@vals[4].raku}";
say "last={@vals[2999].raku}";

# Wide columns exercise the row oriented readers too.
my @rows = $db.query('select id, s, s as s2 from v order by id').arrays;
say "rows={@rows.elems}";
say "row3={@rows[2].raku}";
say "row500={@rows[499].raku}";
