use DB::DuckDB;

# Digest of a VARCHAR column that is deliberately hostile to the
# separator-joined decoder: payloads that contain the join separator itself
# (0x01), the NULL marker (0x02), NUL bytes, empty strings, strings that become
# empty only after joining (a trailing empty value would be lost by a plain
# split), multibyte text, and values longer than the 12 byte inlined limit.
#
# Run by 10-varchar-join as a child process with different env settings; the
# three decode paths must agree exactly.

my $db-file = $*TMPDIR.add("db-duckdb-varchar-join-digest-{$*PID}.duckdb");
LEAVE { $db-file.unlink if $db-file.e }

my $db = DB::DuckDB.new(path => $db-file.absolute);
LEAVE { $db.finish }

$db.execute('create table j (id integer, s varchar, tag varchar)');

# Explicit rows first: they are the ones that can break a naive join.
my @literal = (
    "\x01",            # separator alone
    "\x02",            # NULL marker alone
    "a\x01b",          # separator in the middle
    "a\x02b",          # NULL marker in the middle
    "\x01\x02\x01",    # both, repeated
    '',                # empty
    '',                # two empties in a row
    'plain',
    'trailing empty next',  # followed by '' below
    '',
    '中文' ~ "\x01" ~ '混合',
    'x' x 300,         # far beyond the inlined limit
    'é' x 200,         # multibyte, out of line
);
my $id = 0;
for @literal -> $v {
    $db.execute('insert into j values (?, ?, ?)', ++$id, $v, "tag$id");
}
$db.execute('insert into j values (?, NULL, ?)', ++$id, "null$id");

# NUL bytes cannot go through a bound parameter (the binder treats the value
# as a C string and stops at the NUL), so those two rows are built in SQL.
$db.execute(q{insert into j values (9001, 'a' || chr(0) || 'b', 'tag9001')});
$db.execute(q{insert into j values (9002, chr(0), 'tag9002')});

# Then bulk rows that mix every shape, so the chunked path is exercised too.
my $bulk = $db.execute(q:to/SQL/);
    insert into j
    select 1000 + i,
           case i % 9
             when 0 then NULL
             when 1 then ''
             when 2 then 'short_' || i
             when 3 then 'a_payload_longer_than_twelve_bytes_' || i
             when 4 then '中文值_' || i
             when 5 then 'mix混合_' || i || '_tail'
             when 6 then 'sep' || chr(1) || i
             when 7 then 'nul' || chr(2) || i
             else 'tail' || i || chr(1) || chr(2) || ''
           end,
           'b' || i
      from range(1, 4001) t(i)
    SQL

# ------------------------------------------------------------- column path
my @vals = $db.query('select id, s from j order by id').column(1);

my $chars = 0;
my $nulls = 0;
my $empties = 0;
my @repr;
for @vals.kv -> $i, $v {
    if $v.defined {
        $chars += $v.chars;
        $empties++ if $v eq '';
    }
    else {
        $nulls++;
    }
    @repr.push: $v.raku if $i < 40;
}

say "count={@vals.elems}";
say "chars=$chars";
say "nulls=$nulls";
say "empties=$empties";
say "head={@repr.join('|')}";
say "tail={@vals.tail(3).map(*.raku).join('|')}";

# ------------------------------------------------- row oriented path (wide)
my @rows = $db.query('select id, s, tag, s as s2 from j order by id').arrays;
say "rows={@rows.elems}";
say "row1={@rows[0].raku}";
say "row8={@rows[7].raku}";
say "row14={@rows[13].raku}";
say "row-last={@rows.tail.raku}";

# ------------------------------------------------------- column view / lazy
my $rs = $db.query('select id, s, tag, s as s2 from j order by id');
my $view = $rs.column-view(1);
# count() is documented as the number of non-NULL values; elems is the width.
say "view-elems={$view.elems}";
say "view-nonnull={$view.count}";
say "view-at0={$view.at(0).raku}";
say "view-at6={$view.at(6).raku}";
say "view-slice={$view.slice(10, 6).to-list.map(*.raku).join('|')}";
say "view-eqv={($view.to-list.List eqv @vals.List)}";

# A second view: column-views() must be the first reader on a result, so this
# needs its own query rather than another view off $rs.
my $rs2 = $db.query('select id, s, tag, s as s2 from j order by id');
my $view2 = $rs2.column-view(3);
say "view2-last={$view2.at($view2.elems - 1).raku}";
say "view2-at0={$view2.at(0).raku}";
say "view2-eqv={($view2.to-list.List eqv @vals.List)}";
