use DB::DuckDB;

# Digest of the DECIMAL and ENUM text for every code path, so the test can
# compare runs that take the C shim against runs that do not.  Print one line
# per column: shape, a few sampled values, the total character count, and how
# many values disagree with DuckDB's own ::VARCHAR.

my Int $rows = (@*ARGS[0] // 5001).Int;

my $db = DB::DuckDB.new;

$db.execute(q:to/SQL/);
    create type mood as enum ('alpha','bravo','charlie','delta','echo','foxtrot',
                              'golf','hotel','india','juliet','kilo','lima',
                              'mike','november','oscar','papa','quebec','romeo',
                              'sierra','tango')
    SQL

$db.execute(qq:to/SQL/);
    create table t as select
        i as id,
        CAST((i % 400) - 200 AS DECIMAL(9,2)) + CAST('0.37' AS DECIMAL(9,2))                 as d9,
        CAST((i % 4000) - 2000 AS DECIMAL(18,4)) + CAST('0.1234' AS DECIMAL(18,4))           as d18,
        CAST((i % 4000) - 2000 AS DECIMAL(18,8)) + CAST('0.12345678' AS DECIMAL(18,8))       as d18f,
        CAST((i % 4000) - 2000 AS DECIMAL(28,9)) + CAST('0.000000001' AS DECIMAL(28,9))      as d28,
        CAST((i % 4000) - 2000 AS DECIMAL(38,10)) + CAST('0.0000000001' AS DECIMAL(38,10))   as d38,
        CAST((i % 100) / 100.0 AS DECIMAL(9,9))             as dfr,
        CAST((i % 4000) - 2000 AS DECIMAL(18,0))            as d0,
        (['alpha','bravo','charlie','delta','echo','foxtrot','golf','hotel',
          'india','juliet','kilo','lima','mike','november','oscar','papa',
          'quebec','romeo','sierra','tango'])[(i % 20) + 1]::mood  as e,
        case when i % 31 = 0 then NULL else
            (['alpha','bravo','charlie','delta','echo','foxtrot','golf','hotel',
              'india','juliet','kilo','lima','mike','november','oscar','papa',
              'quebec','romeo','sierra','tango'])[(i % 20) + 1]::mood end     as en
      from range(0, $rows) r(i)
    SQL

# A second enum wide enough that DuckDB stores its keys in USMALLINT instead
# of UTINYINT, so both element widths get exercised.
my @wide = (1 .. 400).map: { "w$_" };
$db.execute("create type wide as enum (" ~ @wide.map({ "'$_'" }).join(',') ~ ")");
$db.execute("create table w (x wide)");
$db.execute("insert into w select ([" ~ @wide.map({ "'$_'" }).join(',')
    ~ "])[(i % 400) + 1]::wide from range(0, $rows) r(i)");

my @cols = <d9 d18 d18f d28 d38 dfr d0 e en>;

sub digest(Str $col --> Str)
{
    my @got  = $db.query("select $col from t order by id").column(0);
    my @want = $db.query("select {$col}::VARCHAR from t order by id").column(0);

    my $miss = 0;
    my $chars = 0;
    for ^@got.elems -> $r {
        my $g = @got[$r];
        my $w = @want[$r];
        if defined($g) && defined($w) {
            $miss++ unless $g eq $w;
            $chars += $g.chars;
        }
        elsif defined($g) || defined($w) {
            $miss++;
        }
    }

    my Int $mid = @got.elems div 2;
    my @sample = (@got[0], @got[1], @got[$mid], @got[*-1])
                     .map({ .defined ?? $_ !! 'NULL' });

    "$col {@got.elems}|{@sample.join('/')}|chars=$chars|mismatched=$miss";
}

@cols.map({ digest($_) }).join("\n").say;

my @got  = $db.query('select x from w').column(0);
my @want = $db.query('select x::VARCHAR from w').column(0);
my $miss = 0;
for ^@got.elems -> $r { $miss++ unless @got[$r] eq @want[$r] }
"wide {@got.elems}|{@got[0]}/{@got[399]}/{@got[400]}|mismatched=$miss".say;

$db.finish;
