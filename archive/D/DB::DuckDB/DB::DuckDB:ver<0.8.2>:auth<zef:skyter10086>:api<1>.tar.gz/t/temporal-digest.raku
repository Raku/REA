use DB::DuckDB;

# Digest of the temporal decode paths: the C shim renders DATE / TIMESTAMP* /
# TIME* from their integer payload, the pure Raku renderers do the same in
# Raku.  Both must reproduce DuckDB's own VARCHAR cast exactly (including the
# (BC) suffix, the dropped trailing zeros on fractional seconds, 24:00:00 and
# pre-epoch values).
#
# Run by 12-temporal as a child process with different env settings; the
# output of the three runs must be identical.

my $db-file = $*TMPDIR.add("db-duckdb-temporal-digest-{$*PID}.duckdb");
LEAVE { $db-file.unlink if $db-file.e }

my $db = DB::DuckDB.new(path => $db-file.absolute);
LEAVE { $db.finish }

# Explicit edges first: these are the shapes a hand written renderer gets
# wrong (calendar arithmetic before 1970, the (BC) suffix, 24:00:00, a
# fractional part that ends in zeros, the maximum timestamp).
$db.execute(q:to/SQL/);
    create table e as select * from (values
        (DATE '1970-01-01', TIMESTAMP '1970-01-01 00:00:00',        TIME '00:00:00'),
        (DATE '1969-12-31', TIMESTAMP '1969-12-31 23:59:59.999999', TIME '23:59:59.999999'),
        (DATE '0001-12-31', TIMESTAMP '1677-09-21 12:34:56.789012', TIME '12:34:56.1'),
        (DATE '9999-12-31', TIMESTAMP '2262-04-11 23:47:16.854775', TIME '24:00:00'),
        (DATE '1582-10-15', TIMESTAMP '2000-01-01 00:00:00.000001', TIME '01:02:03.000400'),
        (DATE '1955-11-05', TIMESTAMP '1900-02-28 06:00:00',        TIME '00:00:00.5'),
        (NULL,              NULL,                                   NULL)
    ) v(d, ts, tm)
    SQL

# Then bulk rows over every temporal type DuckDB hands back as its own type id,
# with NULLs mixed in so the validity mask is exercised too.
$db.execute(q:to/SQL/);
    create table b as select
        i as id,
        case when i % 11 = 0 then NULL else make_date(1969, 12, 31) + (i % 25000)::INTEGER end as d,
        case when i % 11 = 1 then NULL else make_timestamp(i * 1234567) end as ts,
        make_timestamp(i * 1234567)::TIMESTAMP_S              as ts_s,
        make_timestamp(i * 1234567)::TIMESTAMP_MS             as ts_ms,
        make_timestamp(i * 1234567)::TIMESTAMP_NS             as ts_ns,
        (TIME '00:00:00' + (i % 86400)::BIGINT * INTERVAL 1 SECOND) as tm,
        (TIME '00:00:00' + (i % 86400)::BIGINT * INTERVAL 1 SECOND)::TIME_NS as tm_ns
      from range(1, 3001) t(i)
    SQL

my @cols = <d ts ts_s ts_ms ts_ns tm tm_ns>;
my Str @lines;
my Int $total = 0;
my Int $bad = 0;
my Int $nulls = 0;

# Row oriented: every column of one result, which is the path an application
# takes with `.arrays`.
my @rows = $db.query("select { @cols.join(',') } from b order by id").arrays;
my @want-rows =
    $db.query("select { @cols.map(* ~ '::VARCHAR').join(',') } from b order by id").arrays;

for ^@rows.elems -> $r {
    for ^@cols.elems -> $i {
        $total++;
        my $g = @rows[$r][$i];
        my $w = @want-rows[$r][$i];
        $nulls++ unless $g.defined;
        unless (!defined($g) && !defined($w)) || (defined($g) && defined($w) && $g eq $w) {
            $bad++;
            @lines.push: "MISMATCH r$r {@cols[$i]}: got "
                ~ ($g.defined ?? $g.raku !! 'NULL') ~ ' want ' ~ ($w.defined ?? $w.raku !! 'NULL')
                if $bad <= 5;
        }
    }
}

@lines.push: "bulk count={@rows.elems} values=$total nulls=$nulls mismatched=$bad";
@lines.push: "bulk-head={@rows[0].map({ $_.defined ?? $_ !! 'NULL' }).join(' | ')}";
@lines.push: "bulk-mid={@rows[1500].map({ $_.defined ?? $_ !! 'NULL' }).join(' | ')}";
@lines.push: "bulk-last={@rows.tail.map({ $_.defined ?? $_ !! 'NULL' }).join(' | ')}";

# Per column path: each column read on its own, which goes through the same
# filler but a fresh result.
for @cols.kv -> $i, $name {
    my @got = $db.query("select { @cols.join(',') } from b order by id").column($i);
    @lines.push: "$name col count={@got.elems} head={@got.head(3).map({ $_.defined ?? $_ !! 'NULL' }).join(' | ')}";
}

# The edge table, where sign handling and fractional trimming matter.
for 0, 1, 2 -> $i {
    my @got = $db.query('select d, ts, tm from e').column($i);
    @lines.push: "edge col$i={@got.map({ $_.defined ?? $_ !! 'NULL' }).join(' | ')}";
}

# TIMESTAMP_TZ keeps using DuckDB's own rendering (its text carries the
# session time zone), so this only proves the generic path still agrees.
my @tz = $db.query("select TIMESTAMP '2000-01-01 00:00:00'::TIMESTAMPTZ").column(0);
my @tz-want = $db.query("select (TIMESTAMP '2000-01-01 00:00:00'::TIMESTAMPTZ)::VARCHAR").column(0);
@lines.push: "tz-ok={@tz[0] eq @tz-want[0]}";

# Lazy view over the same columns must agree with the eager arrays.
my @eager = $db.query("select { @cols.join(',') } from b order by id").column(1);
my $view  = $db.query("select { @cols.join(',') } from b order by id").column-view(1);
@lines.push: "view-elems={$view.elems} view-nonnull={$view.count}";
@lines.push: "view-eqv={($view.to-list.List eqv @eager.List)}";
@lines.push: "view-at1={$view.at(1).defined ?? $view.at(1) !! 'NULL'}";

say @lines.join("\n");
