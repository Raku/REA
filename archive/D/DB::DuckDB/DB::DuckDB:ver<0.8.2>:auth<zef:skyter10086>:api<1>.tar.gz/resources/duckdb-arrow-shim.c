/* Release an ArrowArray that DuckDB handed us through its C API.
 *
 * Why a shim at all: the release callback is only known at run time (it is a
 * function pointer stored in the ArrowArray struct), so calling it from Raku
 * means nativecast-ing a raw address and invoking it through NativeCall.  That
 * works, but every such call leaks roughly 24 KB inside the VM: a loop of
 * 30_000 convert/release cycles grew the process by ~540 MB with the Raku side
 * callback while the same loop through this shim stayed flat.  Going through
 * ordinary C also keeps the call ABI-proof, which matters because a wrong
 * call here corrupts the allocator (it showed up as STATUS_STACK_BUFFER_OVERRUN
 * on Windows).
 *
 * The file deliberately does not include duckdb.h and does not link against
 * libduckdb: it only needs the Arrow C data interface layout, so it builds with
 * any C compiler and one -shared flag.
 */
#include <stdint.h>
#include <stddef.h>

#if defined(_WIN32)
#define DKD_EXPORT __declspec(dllexport)
#else
#define DKD_EXPORT __attribute__((visibility("default")))
#endif

#define DKD_ARROW_SHIM_ABI 1

struct ArrowArray {
    int64_t length;
    int64_t null_count;
    int64_t offset;
    int64_t n_buffers;
    int64_t n_children;
    const void **buffers;
    struct ArrowArray **children;
    struct ArrowArray *dictionary;
    void (*release)(struct ArrowArray *);
    void *private_data;
};

/* ABI stamp, checked by DB::DuckDB::ArrowShim before it trusts a cached
 * library. */
DKD_EXPORT
int dkd_arrow_shim_abi(void)
{
    return DKD_ARROW_SHIM_ABI;
}

/* Call the array's release callback once.  Returns 1 when a callback was
 * invoked, 0 when the array had already been released (or the pointer was
 * NULL).  Never throws, never touches anything but the struct it is given. */
DKD_EXPORT
int dkd_arrow_release(void *opaque)
{
    struct ArrowArray *array = (struct ArrowArray *)opaque;
    if (!array || !array->release)
        return 0;
    array->release(array);
    return 1;
}

/* Number of children, exposed for the same reason as arrow_probe in the
 * ad-hoc shim: a cheap call that proves the struct layout the module assumes
 * matches what DuckDB wrote. */
DKD_EXPORT
int64_t dkd_arrow_probe(void *opaque)
{
    struct ArrowArray *array = (struct ArrowArray *)opaque;
    if (!array)
        return -1;
    return array->length;
}
