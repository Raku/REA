/* duckdb-varchar-shim.c -- bulk unpacker for DuckDB VARCHAR vectors.
 *
 * Why
 * ===
 * A VARCHAR vector is an array of duckdb_string_t: a uint32 length followed
 * either by 12 inlined bytes (length <= 12, the common case for ids, short
 * labels and dimension keys) or by a 4-byte prefix plus a pointer to the
 * payload.  Reading those values one at a time from Raku costs a Buf
 * allocation plus a byte-by-byte push per row, which dominates the cost of
 * scanning any text heavy result set.
 *
 * What
 * ====
 * dkd_varchar_unpack() walks the whole vector in C and lays every payload out
 * back to back in a single caller-supplied buffer, filling an offset/length
 * table (and, when a validity mask is supplied, a NULL table).  The caller
 * then slices the buffer once per value instead of reading 16 struct bytes
 * and N payload bytes per value through the FFI.
 *
 * The struct layout is written out by hand rather than taken from duckdb.h:
 * DuckDB 2.0 does not expose duckdb_string_t in its public headers, and the
 * shim must also build where the headers are missing entirely (prebuilt
 * libduckdb archives).  Byte layout, verified against duckdb_string_t:
 *
 *   offset 0  uint32  length
 *   offset 4  char[12] inlined payload   (used when length <= 12)
 *   offset 8  void *  payload pointer    (used when length > 12)
 *   sizeof = 16
 *
 * dkd_string_layout() reports those numbers so the Raku side can assert
 * agreement at load time instead of trusting the comment above.
 */

/* process_vm_readv()/struct iovec need _GNU_SOURCE; it has to be defined
 * before the first system header. */
#if defined(__linux__) && !defined(_GNU_SOURCE)
#define _GNU_SOURCE
#endif

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* Temporary diagnostics: when DB_DUCKDB_SHIM_TRACE names a file, every call
 * appends progress lines to it.  A crash inside the loop otherwise leaves no
 * trace at all, since stderr may still be buffered. */
static FILE *dkd_trace_open(void)
{
    const char *p = getenv("DB_DUCKDB_SHIM_TRACE");
    if (!p || !p[0] || (p[0] == '1' && !p[1])) return NULL;
    return fopen(p, "a");
}

#if defined(_WIN32)
#define DKD_EXPORT __declspec(dllexport)
#include <windows.h>

/* How many bytes starting at `p` are committed and readable, capped at
 * `want`.  Uses VirtualQuery because the C API offers no way to ask DuckDB
 * whether a chunk vector is flat: a non-flat vector's data pointer points at
 * a selection buffer that is far smaller than n * sizeof(string_t), and
 * reading it blindly is what crashed the first version of this shim. */
static uint64_t dkd_readable_bytes(const void *p, uint64_t want)
{
    const char *cur = (const char *)p;
    uint64_t got = 0;
    while (got < want) {
        MEMORY_BASIC_INFORMATION mbi;
        uint64_t avail;
        if (VirtualQuery(cur, &mbi, sizeof mbi) == 0) break;
        if (mbi.State != MEM_COMMIT) break;
        if (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) break;
        if (!(mbi.Protect & (PAGE_READONLY | PAGE_READWRITE |
                             PAGE_WRITECOPY | PAGE_EXECUTE_READ |
                             PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)))
            break;
        avail = (uint64_t)((const char *)mbi.BaseAddress + mbi.RegionSize - cur);
        got += avail;
        cur += avail;
        if (avail == 0) break;
    }
    return got > want ? want : got;
}

/* Copy `len` bytes out of `src` without trusting it.  A plain memcpy is
 * enough to kill the process when the vector is not the flat array we think
 * it is, and VirtualQuery alone has been observed to bless a range that then
 * faults on the first 4 KiB boundary; ReadProcessMemory reports the failure
 * instead, so the caller can fall back to the per-value decoder. */
static int dkd_safe_copy(void *dst, const void *src, uint64_t len)
{
    SIZE_T got = 0;
    if (!len) return 1;
    if (!ReadProcessMemory(GetCurrentProcess(), src, dst, (SIZE_T)len, &got))
        return 0;
    return got == (SIZE_T)len;
}
#else
#define DKD_EXPORT __attribute__((visibility("default")))

#if defined(__linux__)
#include <sys/uio.h>
#include <unistd.h>

/* Linux counterpart of VirtualQuery: /proc/self/maps tells us whether the
 * start of the range is mapped readable and where that mapping ends.  Only
 * the first mapping is considered, which is deliberately conservative -- a
 * range that continues into a second mapping is reported short and the
 * caller falls back. */
static uint64_t dkd_readable_bytes(const void *p, uint64_t want)
{
    FILE *f;
    char line[512];
    uintptr_t addr = (uintptr_t)p;
    uint64_t got = 0;

    if (!p || !want) return 0;
    f = fopen("/proc/self/maps", "r");
    if (!f) return want; /* no maps to consult; the copy below still guards */

    while (fgets(line, sizeof line, f)) {
        unsigned long start = 0, end = 0;
        char perms[8];
        if (sscanf(line, "%lx-%lx %7s", &start, &end, perms) != 3) continue;
        if (addr < start || addr >= end) continue;
        if (perms[0] == 'r') got = (uint64_t)(end - addr);
        break;
    }
    fclose(f);
    return got > want ? want : got;
}

/* process_vm_readv() reports EFAULT instead of taking the process down, which
 * is exactly the behaviour ReadProcessMemory gives us on Windows. */
static int dkd_safe_copy(void *dst, const void *src, uint64_t len)
{
    struct iovec local;
    struct iovec remote;
    if (!len) return 1;
    local.iov_base  = dst;
    local.iov_len   = (size_t)len;
    remote.iov_base = (void *)src;
    remote.iov_len  = (size_t)len;
    return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) == (ssize_t)len;
}
#else
static uint64_t dkd_readable_bytes(const void *p, uint64_t want)
{
    (void)p;
    return want; /* assume readable; the length sanity check still applies */
}

static int dkd_safe_copy(void *dst, const void *src, uint64_t len)
{
    memcpy(dst, src, len);
    return 1;
}
#endif
#endif

/* Copy one payload, refreshing a cache of the mapped run we last proved
 * readable.  A chunk of 2048 rows carries ~1365 out-of-line payloads, and
 * probing each of them costs ~1 us in kernel time, while the runs they live
 * in are hundreds of KiB wide -- one probe per run is enough.
 *
 * The probe is a real read of the first bytes of the run, not just
 * VirtualQuery: VirtualQuery has blessed ranges that then faulted on first
 * touch.  A failed probe still falls back to the per-value safe copy, which
 * reports the problem instead of taking the process down. */
static int dkd_window_copy(char *dst, const char *src, uint64_t len,
                           uintptr_t *win_lo, uintptr_t *win_hi)
{
    uintptr_t p = (uintptr_t)src;
    uint64_t extent;

    if (len && p >= *win_lo && p + len <= *win_hi && p + len >= p) {
        memcpy(dst, src, len);
        return 1;
    }

    extent = dkd_readable_bytes(src, (uint64_t)1 << 40);
    if (extent >= 16 && extent >= len) {
        char probe[16];
        if (dkd_safe_copy(probe, src, sizeof probe)) {
            memcpy(dst, src, len);
            *win_lo = p;
            *win_hi = p + extent;
            return 1;
        }
    }
    return dkd_safe_copy(dst, src, len);
}

typedef union {
    struct {
        uint32_t length;
        char     inlined[12];
    } inlined;
    struct {
        uint32_t length;
        char     prefix[4];
        uint64_t ptr;
    } pointer;
} dkd_string_t;

/* Returned instead of a byte count when the vector cannot be unpacked in
 * place.  Callers must fall back to the per-value decoder. */
#define DKD_NOT_FLAT UINT64_MAX

/* Bumped whenever an entry point is added or its contract changes, so a
 * driver that finds an older .dll in the cache can stop trusting it instead
 * of dying on a missing symbol.  Version 2 added dkd_varchar_join(),
 * version 4 added dkd_temporal_join(), version 5 added dkd_decimal_join()
 * (and renumbered the temporal kinds to start at 1). */
#define DKD_SHIM_ABI 5

DKD_EXPORT uint32_t dkd_shim_abi(void)
{
    return DKD_SHIM_ABI;
}

/* Unpack `n` values starting at `data`.
 *
 * validity  NULL means "every row is valid"; otherwise it is DuckDB's
 *           validity mask (64 rows per uint64 word, LSB first).  Invalid
 *           rows contribute no payload and are flagged in `nulls`.
 * out       Destination buffer, or NULL for the sizing pass.
 * cap       Bytes available in `out`.
 * offsets   Optional, receives the byte offset of each payload in `out`.
 * lens      Optional, receives the byte length of each payload.
 * nulls     Optional, receives 1 for NULL rows and 0 otherwise.
 *
 * Returns the total number of payload bytes the column needs, so a caller
 * that passes out = NULL can size the buffer without a second output pass.
 */
DKD_EXPORT uint64_t dkd_varchar_unpack(const void *data,
                                       const uint64_t *validity,
                                       uint64_t n,
                                       char *out, uint64_t cap,
                                       uint64_t *offsets, uint32_t *lens,
                                       uint8_t *nulls)
{
    const dkd_string_t *s;
    dkd_string_t *stage = NULL;
    uint64_t total = 0;
    uint64_t i;
    FILE *dbg = dkd_trace_open();
    uint64_t need = n * (uint64_t)sizeof(dkd_string_t);
    uint64_t readable = dkd_readable_bytes(data, need);

    if (dbg) {
        fprintf(dbg, "c: enter n=%llu data=%p out=%p cap=%llu validity=%p need=%llu readable=%llu\n",
                (unsigned long long)n, (const void *)data,
                (void *)out, (unsigned long long)cap, (const void *)validity,
                (unsigned long long)need, (unsigned long long)readable);
        fflush(dbg);
    }
    if (readable < need) {
        if (dbg) { fprintf(dbg, "c: not flat\n"); fclose(dbg); }
        return DKD_NOT_FLAT;
    }

    /* Snapshot the string_t array into memory we own.  Every later read is
     * then a read of our own buffer, so a stale or foreign pointer can only
     * make us refuse the chunk, never crash. */
    stage = (dkd_string_t *)malloc(need ? need : 1);
    if (!stage) {
        if (dbg) { fprintf(dbg, "c: stage alloc failed\n"); fclose(dbg); }
        return DKD_NOT_FLAT;
    }
    if (!dkd_safe_copy(stage, data, need)) {
        if (dbg) { fprintf(dbg, "c: stage copy failed\n"); fclose(dbg); }
        free(stage);
        return DKD_NOT_FLAT;
    }
    s = stage;

    /* Readable-window cache for the payload copy below.  DuckDB's string heap
     * grows in blocks, so the long values of a chunk sit in a handful of
     * mapped runs separated by gaps -- a single min..max span is almost never
     * readable (measured: 393 KiB readable out of a 128 MiB span).  Caching
     * the run we last proved readable turns one syscall per value into a
     * couple per chunk. */
    uintptr_t win_lo = 0, win_hi = 0;

    for (i = 0; i < n; i++) {
        int is_null = validity ? !((validity[i >> 6] >> (i & 63)) & 1) : 0;
        uint32_t len;

        if (is_null) {
            if (offsets) offsets[i] = total;
            if (lens)    lens[i]    = 0;
            if (nulls)   nulls[i]   = 1;
            continue;
        }

        len = s[i].inlined.length;
        /* No single DuckDB string is anywhere near 16 MiB; a length above
         * that means `data` is a selection buffer, not a string_t array. */
        if (len > (1u << 24)) {
            if (dbg) { fprintf(dbg, "c: bogus len %u at %llu\n", (unsigned)len, (unsigned long long)i); fclose(dbg); }
            free(stage);
            return DKD_NOT_FLAT;
        }
        if (offsets) offsets[i] = total;
        if (lens)    lens[i]    = len;
        if (nulls)   nulls[i]   = 0;

        if (out && total + (uint64_t)len <= cap) {
            if (len <= 12) {
                if (len) memcpy(out + total, s[i].inlined.inlined, len);
            }
            else {
                const char *src = (const char *)(uintptr_t)s[i].pointer.ptr;
                if (len && src) {
                    if (!dkd_window_copy(out + total, src, len, &win_lo, &win_hi)) {
                        if (dbg) { fprintf(dbg, "c: bad payload ptr at %llu\n", (unsigned long long)i); fclose(dbg); }
                        free(stage);
                        return DKD_NOT_FLAT;
                    }
                }
            }
        }
        total += (uint64_t)len;
    }
    if (dbg) {
        fprintf(dbg, "c: done total=%llu\n", (unsigned long long)total);
        fclose(dbg);
    }
    free(stage);
    return total;
}

/* Returned when a payload happens to contain `sep` or `nullmark`, which would
 * make the joined form ambiguous.  The caller falls back to the offset-table
 * unpacker, which has no such limitation. */
#define DKD_SEP_CONFLICT (UINT64_MAX - 1)

/* Join `n` values into one buffer, separated by `sep`, with NULL rows written
 * as the single byte `nullmark`.
 *
 * Why
 * ===
 * Slicing a shared buffer still costs one Str per value on the Raku side, and
 * a Slice is far more expensive than a Split.  Splitting one decoded string
 * on a one byte separator, on the other hand, is done by the VM in a single
 * pass with no allocation per value (measured: 0.53 us per 1M values, against
 * 1.48 us for the slice loop).  This entry point produces the buffer that
 * split needs.
 *
 * The separator is *between* values, never after the last one, so the result
 * has exactly n tokens after Split -- except that Str.split drops trailing
 * empty strings, which the caller repairs by padding with empty strings.
 * NULL is a non-empty one byte token, so a trailing NULL is never dropped.
 *
 * Returns the number of bytes the joined form needs (0..n-1 separators plus
 * payload bytes, 1 byte per NULL).  Pass out = NULL to size the buffer; a
 * second call with a large enough `out` fills it.  DKD_NOT_FLAT and
 * DKD_SEP_CONFLICT mean "fall back".
 */
DKD_EXPORT uint64_t dkd_varchar_join(const void *data,
                                     const uint64_t *validity,
                                     uint64_t n,
                                     char *out, uint64_t cap,
                                     uint8_t sep, uint8_t nullmark)
{
    const dkd_string_t *s;
    dkd_string_t *stage = NULL;
    uint64_t total = 0;
    uint64_t i;
    uint64_t need = n * (uint64_t)sizeof(dkd_string_t);
    uint64_t readable;

    if (n == 0) return 0;

    readable = dkd_readable_bytes(data, need);
    if (readable < need) return DKD_NOT_FLAT;

    stage = (dkd_string_t *)malloc(need);
    if (!stage) return DKD_NOT_FLAT;
    if (!dkd_safe_copy(stage, data, need)) {
        free(stage);
        return DKD_NOT_FLAT;
    }
    s = stage;

    uintptr_t win_lo = 0, win_hi = 0;

    for (i = 0; i < n; i++) {
        int is_null = validity ? !((validity[i >> 6] >> (i & 63)) & 1) : 0;
        uint32_t len;
        const char *src;
        uint64_t k;

        if (i) {
            if (out && total < cap) out[total] = (char)sep;
            total += 1;
        }

        if (is_null) {
            if (out && total < cap) out[total] = (char)nullmark;
            total += 1;
            continue;
        }

        len = s[i].inlined.length;
        if (len > (1u << 24)) {
            free(stage);
            return DKD_NOT_FLAT;
        }
        if (!len) continue;

        if (len <= 12) {
            src = s[i].inlined.inlined;
        }
        else {
            src = (const char *)(uintptr_t)s[i].pointer.ptr;
            if (!src) {
                free(stage);
                return DKD_NOT_FLAT;
            }
        }

        if (out && total + (uint64_t)len <= cap) {
            char *dst = out + total;
            if (len <= 12) {
                memcpy(dst, src, len);
            }
            else if (!dkd_window_copy(dst, src, len, &win_lo, &win_hi)) {
                free(stage);
                return DKD_NOT_FLAT;
            }
            /* The copy lives in our own buffer, so scanning it cannot fault. */
            for (k = 0; k < len; k++) {
                uint8_t c = (uint8_t)dst[k];
                if (c == sep || c == nullmark) {
                    free(stage);
                    return DKD_SEP_CONFLICT;
                }
            }
        }
        total += (uint64_t)len;
    }

    free(stage);
    return total;
}

/* Layout probe: fills `out` with the byte offsets of length / inlined / ptr
 * and returns sizeof(dkd_string_t). */
DKD_EXPORT uint64_t dkd_string_layout(uint32_t *out)
{
    dkd_string_t probe;
    if (out) {
        out[0] = (uint32_t)offsetof(dkd_string_t, inlined.length);
        out[1] = (uint32_t)offsetof(dkd_string_t, inlined.inlined);
        out[2] = (uint32_t)offsetof(dkd_string_t, pointer.ptr);
    }
    return (uint64_t)sizeof(probe);
}

/* ------------------------------------------------------------------------
 * Temporal rendering
 *
 * Why
 * ===
 * DuckDB turns a DATE or a TIMESTAMP into text by materialising a Value and
 * running it through its VARCHAR cast, which goes through ICU for timestamps.
 * Measured from Raku on a 20k row column: ~6 us per DATE and ~240 us per
 * TIMESTAMP, i.e. the text form costs hundreds of times more than the int64
 * it was built from.  The layout is arithmetic, so it is done here instead:
 * a DATE is an int32 day count since 1970-01-01, a TIMESTAMP an int64 count
 * of its own unit since the same epoch, a TIME an int64 count since midnight.
 *
 * The output is byte-identical to DuckDB's own rendering, including the
 * "(BC)" suffix for dates before year 1 and the trailing zeros that DuckDB
 * drops from the fractional part of a time.
 *
 * Values are written with a one byte separator between them, the shape
 * dkd_varchar_join() already produces, so the Raku side pays one Split for
 * the whole chunk instead of one Str per value.
 * ---------------------------------------------------------------------- */

/* Codes start at 1 so that a zeroed `kind` argument is never a valid one and
 * the Raku side can test the returned code for truth instead of comparing
 * against a sentinel. */
#define DKD_TEMPORAL_DATE          1u
#define DKD_TEMPORAL_TIMESTAMP_US  2u
#define DKD_TEMPORAL_TIMESTAMP_S   3u
#define DKD_TEMPORAL_TIMESTAMP_MS  4u
#define DKD_TEMPORAL_TIMESTAMP_NS  5u
#define DKD_TEMPORAL_TIME_US       6u
#define DKD_TEMPORAL_TIME_NS       7u

/* Floor division: C truncates toward zero, the calendar algorithms below
 * assume the quotient rounds down (a pre-epoch value must split into a whole
 * day plus a non-negative time of day). */
static int64_t dkd_floor_div(int64_t a, int64_t b)
{
    int64_t q = a / b;
    if (a % b && ((a < 0) != (b < 0))) q--;
    return q;
}

/* Day count since 1970-01-01 -> proleptic Gregorian (year, month, day).
 * Howard Hinnant's civil_from_days. */
static void dkd_civil(int64_t z, int64_t *py, int *pm, int *pd)
{
    int64_t u   = z + 719468;
    int64_t era = dkd_floor_div(u, 146097);
    int64_t doe = u - era * 146097;
    int64_t yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    int64_t doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    int64_t mp  = (5 * doy + 2) / 153;
    int64_t d   = doy - (153 * mp + 2) / 5 + 1;
    int64_t m   = mp < 10 ? mp + 3 : mp - 9;
    *py = yoe + era * 400 + (m <= 2 ? 1 : 0);
    *pm = (int)m;
    *pd = (int)d;
}

/* Write `v` in decimal, zero padded to at least `width` digits. */
static char *dkd_put_uint(char *p, uint64_t v, int width)
{
    char tmp[24];
    int n = 0;
    do { tmp[n++] = (char)('0' + (int)(v % 10)); v /= 10; } while (v);
    while (n < width) tmp[n++] = '0';
    while (n) *p++ = tmp[--n];
    return p;
}

/* 'YYYY-MM-DD', with DuckDB's "(BC)" suffix for dates before year 1. */
static char *dkd_put_date(char *p, int64_t day)
{
    int64_t y;
    int m, d;
    dkd_civil(day, &y, &m, &d);
    p = dkd_put_uint(p, (uint64_t)(y <= 0 ? 1 - y : y), 4);
    *p++ = '-'; p = dkd_put_uint(p, (uint64_t)m, 2);
    *p++ = '-'; p = dkd_put_uint(p, (uint64_t)d, 2);
    if (y <= 0) { memcpy(p, " (BC)", 5); p += 5; }
    return p;
}

/* 'HH:MM:SS' plus a fractional part when `frac` is non-zero.  The fraction is
 * zero padded to `digits` and then trimmed at the right end, which is what
 * DuckDB does: 0.100000 prints as .1, 0.000001 stays .000001. */
static char *dkd_put_clock(char *p, int64_t secs, int64_t frac, int digits)
{
    char fb[16];
    int i, len;

    p = dkd_put_uint(p, (uint64_t)(secs / 3600), 2);
    *p++ = ':'; p = dkd_put_uint(p, (uint64_t)((secs / 60) % 60), 2);
    *p++ = ':'; p = dkd_put_uint(p, (uint64_t)(secs % 60), 2);

    if (digits <= 0 || frac == 0) return p;
    if (frac < 0) frac = -frac;
    if (digits > 15) digits = 15;
    for (i = digits - 1; i >= 0; i--) {
        fb[i] = (char)('0' + (int)(frac % 10));
        frac /= 10;
    }
    for (len = digits; len > 0 && fb[len - 1] == '0'; len--) ;
    if (len) { *p++ = '.'; memcpy(p, fb, (size_t)len); p += len; }
    return p;
}

static char *dkd_put_stamp(char *p, int64_t v, int64_t per_sec, int digits)
{
    int64_t secs = dkd_floor_div(v, per_sec);
    int64_t frac = v - secs * per_sec;
    int64_t days = dkd_floor_div(secs, 86400);
    int64_t tod  = secs - days * 86400;
    p = dkd_put_date(p, days);
    *p++ = ' ';
    return dkd_put_clock(p, tod, frac, digits);
}

static char *dkd_put_time(char *p, int64_t v, int64_t per_sec, int digits)
{
    int64_t secs = v / per_sec;
    return dkd_put_clock(p, secs, v - secs * per_sec, digits);
}

/* Join `n` rendered temporal values with `sep` between them, NULL rows
 * written as the byte `nullmark`.  Same contract as dkd_varchar_join():
 * pass out = NULL (or a short `cap`) to size, call again to fill.  The
 * returned count is the number of bytes the joined form needs, and it never
 * collides with DKD_NOT_FLAT, so a refusal is unambiguous. */
DKD_EXPORT uint64_t dkd_temporal_join(const void *data,
                                      const uint64_t *validity,
                                      uint64_t n,
                                      char *out, uint64_t cap,
                                      uint32_t kind, uint8_t sep,
                                      uint8_t nullmark)
{
    const int64_t *v64 = (const int64_t *)data;
    const int32_t *v32 = (const int32_t *)data;
    uint64_t total = 0;
    uint64_t i;

    if (n == 0) return 0;
    if (!data) return DKD_NOT_FLAT;
    if (kind > DKD_TEMPORAL_TIME_NS) return DKD_NOT_FLAT;

    for (i = 0; i < n; i++) {
        char tmp[64];
        char *end;
        uint64_t len;
        int is_null = validity ? !((validity[i >> 6] >> (i & 63)) & 1) : 0;

        if (i) {
            if (out && total < cap) out[total] = (char)sep;
            total += 1;
        }

        if (is_null) {
            if (out && total < cap) out[total] = (char)nullmark;
            total += 1;
            continue;
        }

        switch (kind) {
        case DKD_TEMPORAL_DATE:
            end = dkd_put_date(tmp, (int64_t)v32[i]);
            break;
        case DKD_TEMPORAL_TIMESTAMP_US:
            end = dkd_put_stamp(tmp, v64[i], 1000000, 6);
            break;
        case DKD_TEMPORAL_TIMESTAMP_S:
            end = dkd_put_stamp(tmp, v64[i], 1, 0);
            break;
        case DKD_TEMPORAL_TIMESTAMP_MS:
            end = dkd_put_stamp(tmp, v64[i], 1000, 3);
            break;
        case DKD_TEMPORAL_TIMESTAMP_NS:
            end = dkd_put_stamp(tmp, v64[i], 1000000000, 9);
            break;
        case DKD_TEMPORAL_TIME_US:
            end = dkd_put_time(tmp, v64[i], 1000000, 6);
            break;
        default: /* DKD_TEMPORAL_TIME_NS */
            end = dkd_put_time(tmp, v64[i], 1000000000, 9);
            break;
        }

        len = (uint64_t)(end - tmp);
        if (out && total + len <= cap && len <= sizeof tmp) {
            memcpy(out + total, tmp, (size_t)len);
        }
        total += len;
    }
    return total;
}

/* ----------------------------------------------------------------------
 * DECIMAL: join the text form of `n` unscaled integers.
 *
 * A DECIMAL is an integer plus a scale, and DuckDB prints it with exactly
 * `scale` decimal digits -- trailing zeros included (1.5000, not 1.5).  Doing
 * that here costs one division and one digit loop per value, which is cheaper
 * than asking DuckDB to format the value and then paying for the resulting
 * Str on the Raku side.
 *
 * 128 bit values are not handled: the Raku side keeps its own path for them.
 * ---------------------------------------------------------------------- */

#define DKD_DEC_INT16 1u
#define DKD_DEC_INT32 2u
#define DKD_DEC_INT64 3u
#define DKD_DEC_HUGE  4u

static const int64_t dkd_pow10[] = {
    1LL, 10LL, 100LL, 1000LL, 10000LL, 100000LL, 1000000LL, 10000000LL,
    100000000LL, 1000000000LL, 10000000000LL, 100000000000LL,
    1000000000000LL, 10000000000000LL, 100000000000000LL,
    1000000000000000LL, 10000000000000000LL, 100000000000000000LL,
    1000000000000000000LL
};

/* Decimal text for one unscaled value: optional '-', the integer digits, and
 * exactly `scale` fractional digits.
 *
 * `trim_zero` drops the integer part when it is 0, which is what DuckDB does
 * for the all-fraction widths (DECIMAL(9,9) prints .5, DECIMAL(10,9) prints
 * 0.5).  The caller sets it from width == scale. */
static char *dkd_put_decimal(char *p, int64_t v, int scale, int trim_zero)
{
    uint64_t mag;
    uint64_t div;

    if (scale < 0) scale = 0;
    if (scale > 18) scale = 18;
    div = (uint64_t)dkd_pow10[scale];

    if (v < 0) {
        *p++ = '-';
        mag = (uint64_t)(-(v + 1)) + 1u;   /* survives INT64_MIN */
    }
    else {
        mag = (uint64_t)v;
    }

    p = (trim_zero && scale > 0 && mag < div)
        ? p
        : dkd_put_uint(p, mag / div, 1);
    if (scale > 0) {
        uint64_t frac = mag % div;
        char fb[20];
        int i;
        for (i = scale - 1; i >= 0; i--) {
            fb[i] = (char)('0' + (int)(frac % 10));
            frac /= 10;
        }
        *p++ = '.';
        memcpy(p, fb, (size_t)scale);
        p += scale;
    }
    return p;
}

/* DECIMAL(19..38) keeps its unscaled value in a 128 bit slot.  MSVC has no
 * native 128 bit integer, so that branch only exists on compilers that do
 * (gcc/clang define __SIZEOF_INT128__); elsewhere dkd_decimal_join() refuses
 * the wide type and the Raku side keeps its own decoder. */
#if defined(__SIZEOF_INT128__)
#define DKD_HAS_I128 1
typedef __int128 dkd_i128;
typedef unsigned __int128 dkd_u128;

static char *dkd_put_u128(char *p, dkd_u128 v, int width)
{
    char tmp[48];
    int n = 0;
    do { tmp[n++] = (char)('0' + (int)(v % 10)); v /= 10; } while (v);
    while (n < width) tmp[n++] = '0';
    while (n) *p++ = tmp[--n];
    return p;
}

static char *dkd_put_decimal_huge(char *p, dkd_i128 v, int scale, int trim_zero)
{
    dkd_u128 mag;
    dkd_u128 div = 1;
    int i;

    if (scale < 0) scale = 0;
    for (i = 0; i < scale; i++) div *= 10;

    if (v < 0) {
        *p++ = '-';
        mag = (dkd_u128)(-(v + 1)) + 1;    /* survives INT128_MIN */
    }
    else {
        mag = (dkd_u128)v;
    }

    p = (trim_zero && scale > 0 && mag < div)
        ? p
        : dkd_put_u128(p, mag / div, 1);
    if (scale > 0) {
        dkd_u128 frac = mag % div;
        char fb[40];
        for (i = scale - 1; i >= 0; i--) {
            fb[i] = (char)('0' + (int)(frac % 10));
            frac /= 10;
        }
        *p++ = '.';
        memcpy(p, fb, (size_t)scale);
        p += scale;
    }
    return p;
}
#endif

/* Join `n` rendered DECIMAL values, same contract as dkd_temporal_join():
 * pass out = NULL (or a short `cap`) to size, call again to fill. */
DKD_EXPORT uint64_t dkd_decimal_join(const void *data,
                                     const uint64_t *validity,
                                     uint64_t n,
                                     char *out, uint64_t cap,
                                     uint32_t scale, uint32_t internal_type,
                                     uint32_t flags, uint8_t sep,
                                     uint8_t nullmark)
{
    const int16_t *v16 = (const int16_t *)data;
    const int32_t *v32 = (const int32_t *)data;
    const int64_t *v64 = (const int64_t *)data;
    int trim_zero = (int)(flags & 1u);
    uint64_t total = 0;
    uint64_t i;

    if (n == 0) return 0;
    if (!data) return DKD_NOT_FLAT;
    if (internal_type < DKD_DEC_INT16 || internal_type > DKD_DEC_HUGE)
        return DKD_NOT_FLAT;
    if (internal_type != DKD_DEC_HUGE && scale > 18) return DKD_NOT_FLAT;
    if (scale > 38) return DKD_NOT_FLAT;

    for (i = 0; i < n; i++) {
        char tmp[48];
        char *end;
        uint64_t len;
        int64_t v;
        int is_null = validity ? !((validity[i >> 6] >> (i & 63)) & 1) : 0;

        if (i) {
            if (out && total < cap) out[total] = (char)sep;
            total += 1;
        }

        if (is_null) {
            if (out && total < cap) out[total] = (char)nullmark;
            total += 1;
            continue;
        }

        if (internal_type == DKD_DEC_HUGE) {
#if defined(DKD_HAS_I128)
            /* duckdb_hugeint is {uint64_t lower; int64_t upper;}, which is
             * exactly the two's complement 128 bit value on a little endian
             * target, so the pair can be read as one. */
            dkd_i128 h = ((dkd_i128)v64[i * 2 + 1] << 64)
                       | (dkd_u128)(uint64_t)v64[i * 2];
            end = dkd_put_decimal_huge(tmp, h, (int)scale, trim_zero);
#else
            return DKD_NOT_FLAT;
#endif
        }
        else {
            switch (internal_type) {
            case DKD_DEC_INT16: v = (int64_t)v16[i]; break;
            case DKD_DEC_INT32: v = (int64_t)v32[i]; break;
            default:            v = v64[i];          break;
            }
            end = dkd_put_decimal(tmp, v, (int)scale, trim_zero);
        }

        len = (uint64_t)(end - tmp);
        if (out && total + len <= cap && len <= sizeof tmp) {
            memcpy(out + total, tmp, (size_t)len);
        }
        total += len;
    }
    return total;
}

