unit module Do321::Host;

#| The run host: one detached process per run, which outlives the
#| terminal that started it.  It runs the same runtime a person or a work
#| system runs (`321 run --package FILE`), as its child, so there is one
#| runtime path: trust, grants, approvals, ordered directives and the
#| receipt are all the runtime's, unchanged.  The host adds only what a
#| run needs to be watched and controlled from elsewhere:
#|
#|   - it records who it is (pid, start time, boot) so nothing is mistaken
#|     for it after it is gone;
#|   - it is the only writer of the run's event log;
#|   - it takes requests from the run's inbox, numbers them in the order
#|     they arrive and hands them to the runtime as directives;
#|   - it is the subreaper of everything below it, and when the runtime
#|     ends it stops whatever the agent left running, and records that.
#|
#| It never writes the receipt and never changes one (the receipt is the
#| runtime's: work-package-immutable.cli.321.do).  A stop always reaches
#| the runtime first; signals are the fallback, never the first word
#| (a person can always stop the run, and safely).

use Do321::JSON;
use Do321::Shape;
use Do321::Protocol;
use Do321::Trust;
use Do321::CLI;
use Do321::Sys;
use Do321::RunDir;
use Do321::Fold;
use Do321::Harnesses;
use Do321::Learn;

constant HOST-VERSION is export = '0.7.0';
#| How long a delivered stop may take before the host signals the runtime.
constant STOP-GRACE = 30;
#| How long a stopped process gets between SIGTERM and SIGKILL.
constant KILL-GRACE = 5;
#| How large a run's log may grow before the agent's words are dropped.
constant LOG-CAP = 64 * 1_048_576;
#| Exit code when a run started and how it ended is unknown.
constant EXIT-LOST is export = 6;

# ---------------------------------------------------------------- launch

#| Start a run that outlives this terminal.  The package is built exactly
#| as `321 <agent> <request>` builds it, through the CLI's own builder:
#| the same trust, the same grants inside the same policy ceiling.  A run
#| launched here carries no approval; an approval stays where a person
#| gives one.  Returns (RunDir, error).
sub launch-run(Str $agent-name, Str $request, Str :$workspace = '', Str :$trust-path = '', IO::Path :$home = home-dir(),
               Str :$via = 'mission-control', :%continues, RunDir :$follows, Str :$harness = '', Bool :$isolate = False,
               Str :$context = '' --> List) is export {
    return (RunDir, 'say what the agent should do') if $request.trim eq '';
    # a follow-up goes on from a receipt: a run still going has none
    my $prev-bytes;
    with $follows {
        return (RunDir, "{.short} has no receipt yet; a run is talked to while it works with steer") unless .receipt-file.e;
        $prev-bytes = try .receipt-file.slurp(:bin);
        return (RunDir, "cannot read {.short}'s receipt: {$!.message}") if $!;
    }
    # The harness is chosen here or left to the runtime, which picks the
    # first one able to enforce what the package needs.  Either way the
    # runtime checks it again: a choice never widens what is enforced.
    my $adapter = '';
    if $harness ne '' {
        my ($name, $why) = check-harness($harness);
        return (RunDir, $why) with $why;
        $adapter = $name;
    }
    private-umask();
    # a follow-up belongs to the work context of the run it goes on from
    my $ctx = $context;
    with $follows { $ctx = ((runs-applied($home){.id} // {})<context> // '').Str if $ctx eq '' }
    my $cfg = try load-trust($trust-path ne '' ?? $trust-path.IO !! default-trust-path());
    return (RunDir, $!.message) if $!;
    my $g = Do321::CLI::Global.new(:$trust-path, :$workspace, context => $ctx);
    my ($agent, $err) = load-agent-named($cfg, $g, $agent-name);
    return (RunDir, $err) with $err;
    my ($ws, $kind) = resolve-workspace($workspace);
    ($ws, $kind) = ('', 'none') unless needs-workspace($agent.manifest);
    # Two runs that write never share a workspace: the second is refused,
    # or given a worktree of its own.
    my %isolation;
    if $ws ne '' && $isolate {
        return (RunDir, "$ws is not a git repository, so a run cannot have a worktree of it") unless $kind eq 'git';
        my ($path, $base, $why) = make-worktree($ws, $home);
        return (RunDir, $why) with $why;
        %isolation = kind => 'git-worktree', of => $ws, path => $path, base => $base;
        $ws = $path;
    }
    # Otherwise a run that writes waits its turn for the workspace, and a
    # run past the agent's standing limit (policy.now) waits for a place:
    # the run's own host does the waiting, oldest first.  Nothing here
    # chooses between pieces of work.
    my %queue = workspace => so($ws ne '' && !%isolation && writes($agent.manifest)),
                limit => (($cfg.policy // {})<now> // 0).Int;
    my %wp = (try build-package($cfg, $agent, $g, $request, $ws, $kind, :$home, harness => $adapter)) // %();
    if $! {
        my $why = $!.message;
        drop-worktree(%isolation) if %isolation;
        return (RunDir, $why);
    }
    # A follow-up is the same agent as it was running: the grants, limits
    # and placement the followed package carried, not this shell's
    # defaults, so a harness able to run that run can run this one.  The
    # local ceiling still bounds them, here and again in the runtime.
    with $follows {
        my %was = followed-package($_, $home);
        %wp<capabilities> = %was<capabilities> if %was<capabilities> ~~ Associative && (%was<capabilities><granted>:exists);
        %wp<placement> = %was<placement> if (%was<placement> // '') ne '';
        with $cfg.policy<capabilityCeiling> -> $ceiling {
            for @(%wp<capabilities><granted> // []) -> $c {
                return (RunDir, "local policy does not allow $c, which {.short} ran with (policy.capabilityCeiling in {$cfg.path})") unless $c (elem) @$ceiling;
            }
        }
        my $ps = validate-work-package(%wp);
        return (RunDir, "the follow-up package is not valid: $ps") if $ps;
    }

    my $rd = try {
        private-dir(home-dir-of($home));
        private-dir(runs-root($home));
        # Control files rely on rename and O_EXCL meaning the same thing to
        # every reader: on a network filesystem they may not.
        with weak-filesystem(runs-root($home).Str) {
            die "{runs-root($home)} is on $_, and runs need a local filesystem; set DO_321_HOME to a local directory" if $_ ne '';
        }
        my $r = run-dir(%wp<packageId>, $home);
        private-dir($r.dir);
        private-dir($r.inbox);
        $r;
    };
    # a refusal that already says what to do needs no preface
    return (RunDir, ($!.message.contains('DO_321_HOME') || $!.message.contains('not safe to use') ?? '' !! 'cannot make the run directory: ') ~ $!.message) if $!;
    my %m = $agent.manifest;
    write-atomic($rd.package-file, to-wire('WorkPackage', %wp) ~ "\n", :durable);
    write-atomic(follows-file($rd), $prev-bytes.decode, :durable) with $prev-bytes;
    my %run = schema => SCHEMA-RUN, runId => %wp<packageId>, attempt => 1, continues => (%continues ?? %continues !! Nil),
        follows => ($follows.defined ?? %( runId => $follows.id, receiptDigest => digest-bytes($prev-bytes) ) !! Nil),
        agent => { id => $agent.id, name => $agent-name, version => (%m<version> // ''), displayName => (%m<displayName> // $agent-name),
                   byline => byline-of(%m) },
        request => $request, workspace => $ws, grants => [ |@(%wp<capabilities><granted>) ],
        harness => { requested => $adapter }, isolation => (%isolation ?? %isolation !! Nil), queue => %queue,
        launchedBy => { uid => my-uid(), via => $via }, launchedAt => now-iso();
    write-atomic($rd.run-file, encode-json-pretty(%run) ~ "\n", :durable);

    my $spawned = spawn-host($rd);
    return ($rd, "the host did not start: $spawned") with $spawned;
    ($rd, Str);
}

#| Host a package something else issued: `321 start --package FILE`.  The
#| package arrives whole, grants and all, so nothing is built here and no
#| trust is read for it: the runtime re-checks every grant as it does for
#| any package, and a package it will not run ends the run with the
#| reason on the receipt.  The run id is the packageId, so the issuer
#| knows it before the host answers.  A continuation runs the same
#| package again from its receipt, so that run needs an id of its own,
#| and the issuer reads it from the answer.  Returns (RunDir, error).
sub launch-package(IO::Path $file, Str :$workspace = '', Str :$continue = '', IO::Path :$home = home-dir(),
                   Str :$via = '321 start --package', Str :$harness = '' --> List) is export {
    return (RunDir, "no such file: $file") unless $file.f;
    my $raw = try $file.slurp;
    return (RunDir, "cannot read $file: {$!.message}") if $!;
    my $doc = try parse-json($raw);
    return (RunDir, "$file is not JSON") unless $doc ~~ Associative;
    my %wp = (try load('WorkPackage', $doc)) // %();
    return (RunDir, "$file is not a work package: {$!.message}") if $!;
    # the workspace: the caller's word, else the package's; caller-owned
    # either way, and never a worktree of 321's making.  An issuer leaves
    # the path out on purpose, since its digest is taken over the document
    # as issued, so the caller's word is filled in before the package is
    # judged, as the runtime does
    my $ws = $workspace ne '' ?? $workspace !! ((%wp<workspace> // {})<path> // '').Str;
    return (RunDir, "no such directory: $ws") if $ws ne '' && !$ws.IO.d;
    $ws = $ws.IO.absolute.Str if $ws ne '';
    %wp<workspace><path> = $ws if $ws ne '' && ((%wp<workspace> // {})<path> // '') eq '';
    my $problems = validate-work-package(%wp);
    return (RunDir, "$file is not a work package: {$problems.Str}") if $problems;
    my $id = %wp<packageId>.Str;
    return (RunDir, "packageId '$id' is not a ULID, so it cannot name a run") unless valid-run-id($id);
    my $adapter = '';
    if $harness ne '' {
        my ($name, $why) = check-harness($harness);
        return (RunDir, $why) with $why;
        $adapter = $name;
    }
    # a continuation: the receipt it goes on from, read now and kept with
    # the run, so the runtime continues exactly what the issuer named
    my (%prev, $prev-bytes);
    if $continue ne '' {
        return (RunDir, "no such receipt: $continue") unless $continue.IO.f;
        $prev-bytes = try $continue.IO.slurp(:bin);
        return (RunDir, "cannot read $continue: {$!.message}") if $!;
        my $p = try parse-json($prev-bytes.decode);
        return (RunDir, "$continue is not a run receipt") unless $p ~~ Associative && ($p<schema> // '') eq SCHEMA-RUN-RECEIPT;
        return (RunDir, "$continue is the receipt of package {$p<packageId> // ''}, not $id") if ($p<packageId> // '') ne $id;
        %prev = %$p;
    }
    private-umask();
    my $rd = try {
        private-dir(home-dir-of($home));
        private-dir(runs-root($home));
        with weak-filesystem(runs-root($home).Str) {
            die "{runs-root($home)} is on $_, and runs need a local filesystem; set DO_321_HOME to a local directory" if $_ ne '';
        }
        my $r = run-dir(%prev ?? new-ulid() !! $id, $home);
        die "run $id already exists: a package starts once, and a continuation names its receipt with --continue" if $r.dir.e;
        private-dir($r.dir);
        private-dir($r.inbox);
        $r;
    };
    return (RunDir, ($!.message.contains('DO_321_HOME') || $!.message.contains('not safe to use') || $!.message.contains('already exists')
                     ?? '' !! 'cannot make the run directory: ') ~ $!.message) if $!;
    # the package exactly as received
    write-atomic($rd.package-file, $raw.ends-with("\n") ?? $raw !! $raw ~ "\n", :durable);
    write-atomic(continued-file($rd), $prev-bytes.decode, :durable) if %prev;
    my %run = schema => SCHEMA-RUN, runId => $rd.id, attempt => 1,
        continues => (%prev ?? %( runId => (%prev<runId> // '').Str, receiptDigest => digest-bytes($prev-bytes) ) !! Nil),
        agent => agent-words(%wp<agent><id>.Str), request => %wp<objective>.Str, workspace => $ws,
        grants => [ |@((%wp<capabilities> // {})<granted> // []) ],
        harness => { requested => $adapter }, isolation => Nil,
        issuer => %wp<issuer>, refs => [ |@((%wp<correlation> // {})<refs> // []) ],
        launchedBy => { uid => my-uid(), via => $via }, launchedAt => now-iso();
    write-atomic($rd.run-file, encode-json-pretty(%run) ~ "\n", :durable);
    my $spawned = spawn-host($rd);
    return ($rd, "the host did not start: $spawned") with $spawned;
    ($rd, Str);
}

#| Where a hosted continuation keeps the receipt it goes on from.
#| The package a follow-up takes its grants from: the followed run's, or
#| when that run was denied before it did anything, the nearest run back
#| along the chain that was not, so one refusal does not shape every run
#| after it.  Empty when no run of the chain can say.
sub followed-package(RunDir $r, IO::Path $home --> Hash) {
    my $at = $r;
    for ^32 {
        my %rc = $at.receipt;
        my %pk = (read-json-file($at.package-file) // {}).Hash;
        return %pk if (%rc<status> // '') ne STATUS-DENIED && %pk<capabilities> ~~ Associative;
        my $prev = ((($at.run<follows> // {}) ~~ Associative ?? $at.run<follows> !! {})<runId> // '').Str;
        return {} if $prev eq '' || !valid-run-id($prev);
        $at = run-dir($prev, $home);
        return {} unless $at.dir.e;
    }
    {};
}

sub continued-file(RunDir $r --> IO::Path) { $r.dir.add('continued-receipt.json') }
sub follows-file(RunDir $r --> IO::Path) { $r.dir.add('follows-receipt.json') }

#| How the crew list names an agent a package refers to by id: its
#| local package's own words when it is installed here, the id's last
#| word otherwise.  Nothing here decides whether it runs.
sub agent-words(Str $id --> Hash) {
    my $name = $id.split('/').tail;
    my %w = id => $id, name => $name, displayName => $name, byline => '', version => '', color => '';
    try {
        my $cfg = load-trust(default-trust-path());
        my $g = Do321::CLI::Global.new;
        my ($agent, $err) = load-agent-named($cfg, $g, $id);
        ($agent, $err) = load-agent-named($cfg, $g, $name) without $agent;
        with $agent {
            my %m = .manifest;
            %w<displayName> = %m<displayName> // $name;
            %w<byline> = byline-of(%m);
            %w<version> = %m<version> // '';
            # the agent's own accent, as 123 gives each agent one
            %w<color> = ((%m<identity> // {})<color> // '').Str;
        }
    }
    %w;
}

sub home-dir-of(IO::Path $home --> IO::Path) { $home }

#| Take back a worktree no run used.
sub drop-worktree(%iso) {
    try { my $p = run 'git', '-C', %iso<of>, 'worktree', 'remove', '--force', %iso<path>, :out, :err; $p.out.slurp(:close); $p.err.slurp(:close) }
}

#| The runs this one waits behind, oldest first, from evidence alone:
#| a run at work in the same workspace, a run at work for the same
#| agent when the agent's places are all taken, and any run waiting for
#| the same thing that was launched before this one.  Empty: its turn.
sub ahead-of(RunDir $r, IO::Path $home = home-dir() --> List) is export {
    my %me = $r.run;
    my %q = (%me<queue> // {}).Hash;
    return () unless %q<workspace> || (%q<limit> // 0) > 0;
    my $ws = (%me<workspace> // '').Str;
    my $agent = (%me<agent><id> // %me<agent><name> // '').Str;
    my (@ws, @agent);
    for all-runs($home) -> $o {
        next if $o.id eq $r.id || !$o.hosted;
        my $phase = liveness($o)<phase>;
        next unless $phase eq 'starting' | 'running' | 'held' | 'stopping' | 'blocked' | 'queued';
        # a run still waiting counts only when it was launched first
        next if $phase eq 'queued' && $o.id gt $r.id;
        my %o = $o.run;
        @ws.push($o) if %q<workspace> && $ws ne '' && (%o<workspace> // '') eq $ws;
        @agent.push($o) if (%o<agent><id> // %o<agent><name> // '') eq $agent;
    }
    my @behind = @ws;
    @behind.append(@agent) if (%q<limit> // 0) > 0 && @agent >= %q<limit>;
    @behind.unique(:as(*.id)).sort(*.id).List;
}

#| Why a run waits, in words, from the runs it is behind.
sub queue-reason(RunDir $r, @behind --> Str) is export {
    my %me = $r.run;
    my $ws = (%me<workspace> // '').Str;
    my @in-ws = @behind.grep({ $ws ne '' && (.run<workspace> // '') eq $ws });
    my $names = @behind.map({ "{.run<agent><displayName> // .run<agent><name> // 'a run'} {.short}" }).join(', ');
    @in-ws ?? "$names {@behind == 1 ?? 'is' !! 'are'} ahead of it in $ws"
           !! "{%me<agent><displayName> // 'the agent'} works on {(%me<queue> // {})<limit>} at once here, and $names {@behind == 1 ?? 'is' !! 'are'} ahead";
}

#| Whether an agent can change files: one that can, holds its workspace.
sub writes(%m --> Bool) {
    so (|@(%m<capabilities><required> // []), |@(%m<capabilities><optional> // [])).first({ $_ eq 'repo.write' | 'files.write' | 'shell.run' });
}

#| A worktree of the workspace at its last commit, for one run, under
#| ~/.321/worktrees.  Nothing is committed: the person reviews what the
#| run changed there and takes it, or removes the worktree.  Returns
#| (path, base commit, error).
sub make-worktree(Str $ws, IO::Path $home --> List) {
    my $root = private-dir($home.add('worktrees'));
    my $path = $root.add(new-ulid()).Str;
    my $head = run 'git', '-C', $ws, 'rev-parse', 'HEAD', :out, :err;
    my $base = $head.out.slurp(:close).trim;
    $head.err.slurp(:close);
    return (Str, Str, "$ws has no commit yet, so there is nothing to make a worktree of") if $head.exitcode != 0 || $base eq '';
    my $add = run 'git', '-C', $ws, 'worktree', 'add', '--detach', $path, $base, :out, :err;
    $add.out.slurp(:close);
    my $err = $add.err.slurp(:close);
    return (Str, Str, "git could not make a worktree: {$err.lines.grep(*.trim ne '').tail // 'it said nothing'}") if $add.exitcode != 0;
    ($path, $base, Str);
}

#| Whether an agent can touch files at all; one that cannot gets no
#| workspace, as at the terminal.
sub needs-workspace(%m --> Bool) {
    for |@(%m<capabilities><required> // []), |@(%m<capabilities><optional> // []) -> $c {
        return True if $c (elem) <repo.read repo.write files.read files.write shell.run>;
    }
    False;
}

#| An agent's byline: its own, or the first clause of its role.
sub byline-of(%m --> Str) is export {
    my $b = (%m<identity><byline> // '').trim;
    return $b if $b ne '';
    my $role = (%m<identity><role> // '').trim;
    my $first = $role.split(/<[.;,]>/)[0] // '';
    $first.chars > 40 ?? $first.substr(0, 39) ~ '…' !! $first;
}

#| Start the host in a session of its own, with no terminal, so closing
#| the terminal, losing the connection or a crash of the screen kills
#| nothing.  Returns an error, or Str.
sub spawn-host(RunDir $r --> Str) {
    my $setsid = </usr/bin/setsid /bin/setsid>.first(*.IO.x) // return 'setsid is not installed';
    my $log = $r.log-file;
    $log.spurt('') unless $log.e;
    $log.chmod(0o600);
    my $p = Proc::Async.new('sh', '-c', 'exec "$1" -f "$@" </dev/null >>"$0" 2>&1', $log.Str, $setsid, |mission-argv(), 'host', $r.dir.Str);
    my $res = try await $p.start;
    return "could not run setsid: {$!.message}" if $!;
    return "setsid exited {$res.exitcode}" if $res.exitcode != 0;
    Str;
}

# ---------------------------------------------------------------- the host

#| `321 host DIR`: be the host of one run.  Returns the exit code.
sub host-main(Str $dir --> Int) is export {
    my $r = RunDir.new(:dir($dir.IO.absolute.IO));
    with unsafe-dir($r.dir.Str) { note "321 host: {$r.dir} is not safe to use: $_" ~ remedy($r.dir, $_); return 70 }
    return 64 unless valid-run-id($r.id) && $r.run-file.e && $r.package-file.e;
    # one host per run: the live marker is taken exclusively
    unless create-exclusive($r.live-file.Str, '') {
        note "321 host: run {$r.id} already has a host";
        return 70;
    }
    private-umask();
    my $reaper = become-subreaper();
    my %run = $r.run;
    my %self = proc-stat(my-pid()) // {};
    my %host = schema => SCHEMA-HOST, runId => $r.id, pid => my-pid(), startTicks => %self<start> // 0, bootId => boot-id(),
        pgid => %self<pgid> // 0, sid => %self<sid> // 0, subreaper => $reaper, version => HOST-VERSION, startedAt => now-iso();
    write-atomic($r.host-file, encode-json-pretty(%host) ~ "\n", :durable);

    my $log = EventLog.new(:path($r.events-file));
    my $state = RunState.new;
    my $mu = Lock.new;
    # Past the cap the agent's own words are dropped, once said; every
    # other event (tools, controls, the end) is still recorded.
    my $cap = (%*ENV<DO_321_MC_LOG_CAP> // LOG-CAP).Int;
    my $capped = 0;
    my sub record(Str $src, Str $kind, %payload, Str :$at = now-iso()) {
        $mu.protect({
            if $kind eq 'progress' && (%payload<text> // '') ne '' && $r.events-file.s > $cap {
                fold-event($state, $log.append('host', 'log_truncated', %( bytes => $cap, dropping => 'progress text' ))) unless $capped++;
            }
            else { fold-event($state, $log.append($src, $kind, %payload, :$at)) }
        });
    }
    my sub write-status() {
        my %d = $mu.protect({ status-doc($state, $r.id) });
        my @below = descendants(my-pid());
        my ($ticks, $rss) = usage-of(@below);
        %d<usage> = %( cpuSeconds => ($ticks / 100).round(0.1), rssBytes => $rss, processes => +@below, basis => '/proc, every process below the host' );
        try write-atomic($r.status-file, encode-json-pretty(%d) ~ "\n");
    }
    record('host', 'host_started', %( pid => my-pid(), request => %run<request> // '', agent => %run<agent><id> // '', subreaper => $reaper,
        continues => (%run<continues> ~~ Associative ?? %run<continues><runId> // '' !! ''),
        follows => (%run<follows> ~~ Associative ?? %run<follows><runId> // '' !! '') ));

    # Its turn: a run that must wait does so here, before anything runs.
    # The marker is made before the first look, so two runs launched at
    # once each see the other waiting and the older goes first.  While it
    # waits, a stop ends it having done nothing, a resume lets it go now,
    # and anything else said to it is kept, in order, for when it starts.
    my @early;
    my $stop-first = False;
    if (%run<queue> // {})<workspace> || ((%run<queue> // {})<limit> // 0) > 0 {
        try $r.queued-file.spurt('');
        my %pkg = (read-json-file($r.package-file) // {}).Hash;
        my $expires = (%pkg<expiresAt> // '') ne '' ?? (try DateTime.new(%pkg<expiresAt>.Str).Instant) !! Nil;
        my $said = '';
        my $why = 'its turn';
        loop {
            my @behind = ahead-of($r, $r.dir.parent.parent);
            last unless @behind;
            my $key = @behind.map(*.id).join(',');
            if $key ne $said {
                $said = $key;
                record('host', 'queued', %( behind => @behind.map(*.id).Array, why => queue-reason($r, @behind) ));
            }
            write-status();
            my $go = False;
            for take-inbox($r) -> %t {
                with %t<refused> { record('host', 'directive_refused', %( directiveId => %t<directiveId>, reason => "the request was not read: $_" )); next }
                my %d = %t<directive>;
                if %d<kind> eq 'stop' { $stop-first = True; $why = 'stopped while it waited'; @early.push(%d); $go = True }
                elsif %d<kind> eq 'resume' {
                    record('host', 'directive_delivered', %( directiveId => %d<directiveId>, kind => 'resume', text => '', seq => 0 ));
                    record('host', 'directive_applied', %( directiveId => %d<directiveId> ));
                    $why = 'asked to go now'; $go = True;
                }
                else { @early.push(%d) }
            }
            # a package that expires while it waits is put to the runtime, which says so on the receipt
            if $expires.defined && now > $expires { $why = 'its package expired while it waited'; $go = True }
            last if $go;
            sleep 0.5;
        }
        record('host', 'dequeued', %( :$why )) if $said ne '';
        try $r.queued-file.unlink;
    }

    # The runtime, as its own child, told to go when the host goes.
    my @pre = </usr/bin/setpriv /bin/setpriv>.first(*.IO.x) ?? (</usr/bin/setpriv /bin/setpriv>.first(*.IO.x), '--pdeathsig', 'TERM', '--') !! ();
    # the receipt names the run as this directory does, so the two agree
    my @argv = |@pre, |runtime-argv(), 'run', '--package', $r.package-file.Str, '--receipt', $r.receipt-file.Str, '--history-dir', $r.dir.Str,
               '--run-id', $r.id;
    my $asked = (%run<harness> // {})<requested> // '';
    @argv.append('--adapter', $asked) if $asked ne '';
    # a hosted package: the caller's workspace where it is not the
    # package's own, and the receipt a continuation goes on from
    my %wp = (read-json-file($r.package-file) // {}).Hash;
    my $ws = (%run<workspace> // '').Str;
    @argv.append('--workspace', $ws) if $ws ne '' && $ws ne ((%wp<workspace> // {})<path> // '').Str;
    @argv.append('--continue', continued-file($r).Str) if continued-file($r).e;
    @argv.append('--follows', follows-file($r).Str) if follows-file($r).e;
    @argv.append('--stop-first') if $stop-first;
    my $proc = Proc::Async.new(:w, |@argv);
    my $receipt-seen = False;
    $proc.stdout.lines.tap(-> $line {
        my $f = try parse-json($line);
        if $f ~~ Associative {
            given $f<schema> // '' {
                when SCHEMA-RUN-EVENT { record('run', $f<kind> // '', ($f<payload> // {}).Hash, :at($f<at> // now-iso())) }
                when SCHEMA-RUN-RECEIPT {
                    $receipt-seen = True;
                    record('host', 'receipt', %( status => $f<status> // '', summary => $f<summary> // '', file => $r.receipt-file.Str ));
                }
                when SCHEMA-PROTOCOL-ERROR { record('host', 'protocol_error', %( code => $f<code> // '', message => $f<message> // '' )) }
            }
        }
    });
    $proc.stderr.tap(-> $s { $*ERR.print($s) });
    my $done = $proc.start;
    my $child = try await $proc.ready;
    with $child {
        %host<runtimePid> = $child;
        %host<runtimeStartTicks> = (proc-stat($child) // {})<start> // 0;
        write-atomic($r.host-file, encode-json-pretty(%host) ~ "\n", :durable);
    }
    my $pkg = (try parse-json($r.package-file.slurp)) // {};
    my $package-id = $pkg<packageId> // $r.id;

    my $seq = 0;
    my %seen;
    my $stop-at;
    my $escalated = False;
    my $ended = False;
    my $send-mu = Lock.new;
    my sub deliver(%d) {
        $send-mu.protect({
            my $id = %d<directiveId>;
            if %seen{$id}++ { record('host', 'directive_duplicate', %( directiveId => $id )); return }
            if $ended { record('host', 'directive_refused', %( directiveId => $id, reason => 'the run has ended' )); return }
            my $kind = %d<kind> eq 'hold' ?? DIRECTIVE-PAUSE !! %d<kind>;
            my %w = doc('WorkDirective', schema => SCHEMA-WORK-DIRECTIVE, directiveId => $id, packageId => $package-id, seq => ++$seq,
                issuer => { kind => 'local', id => "{%*ENV<USER> // ''}/{%d<from><client> // 'client'}" }, issuedAt => %d<sentAt> // now-stamp(),
                kind => $kind, payload => { text => %d<text> // '', reason => %d<reason> // '' });
            %w<digest> = directive-digest(%w);
            my $ok = try { await $proc.say(to-wire('WorkDirective', %w)); True };
            if $ok {
                record('host', 'directive_delivered', %( directiveId => $id, kind => %d<kind>, text => %d<text> // '', seq => $seq ));
                $stop-at //= now if %d<kind> eq 'stop';
            }
            else { $seq--; record('host', 'directive_refused', %( directiveId => $id, reason => 'the runtime is no longer listening' )) }
        });
    }
    # what was said while it waited its turn, in the order it was said
    deliver($_) for @early;
    # a signal to the host is a stop, from the one who sent it
    signal(SIGHUP).tap({ });
    signal(SIGTERM, SIGINT).tap(-> $s {
        deliver(%( directiveId => new-ulid(), kind => 'stop', reason => "signal {$s.Str} to the host", from => { client => 'signal' } ));
    });

    my $inbox-loop = start {
        # inotify wakes the loop when a request lands; without it, a poll
        my $watch = Watch.new;
        $watch.add($r.inbox.Str);
        until $ended {
            for take-inbox($r) -> %t {
                with %t<refused> { record('host', 'directive_refused', %( directiveId => %t<directiveId>, reason => "the request was not read: $_" )) }
                else { deliver(%t<directive>) }
            }
            # a stop that the runtime has not honoured in time: signal it
            if $stop-at.defined && !$escalated && !$ended && now - $stop-at > STOP-GRACE {
                $escalated = True;
                with $child {
                    record('host', 'escalated', %( signal => 'TERM', pid => $_, after => STOP-GRACE ));
                    send-signal($_, SIGTERM);
                    my $c = $_;
                    start { sleep KILL-GRACE * 3; send-signal($c, SIGKILL) unless $ended }
                }
            }
            $watch.wait(200);
        }
        $watch.close;
    };
    # The heartbeat also notes every process below the host, so that if
    # the host itself is killed, what it was running can still be found
    # and stopped by identity (pid and start time), not by guesswork.
    my $beat = start {
        until $ended {
            write-status();
            snapshot-tree($r);
            for ^10 { last if $ended; sleep 0.2 }
        }
    };

    my $res = try await $done;
    my $exit = $res.defined ?? $res.exitcode !! -1;
    $send-mu.protect({ $ended = True });
    try $proc.close-stdin;
    # The heartbeat and the inbox stop before the sweep: from here on one
    # thread works, so nothing below races the end of the run.
    try await $inbox-loop;
    try await $beat;

    # Whatever the agent left running below the host is stopped now, and
    # each process is named: the model's word that it was killed is not
    # evidence, the kernel's is.
    my @swept = sweep(my-pid());
    record('host', 'swept', %( processes => @swept ));
    if !$r.receipt-file.e {
        record('host', 'runtime_exited', %( exitCode => $exit, receipt => False ));
        record-ended($r, %( summary => "the runtime exited $exit without writing a receipt", exitCode => $exit,
                            lastSeq => $log.seq, observedBy => 'host' ));
    }
    elsif !$receipt-seen {
        my %rc = $r.receipt;
        record('host', 'receipt', %( status => %rc<status> // '', summary => %rc<summary> // '', file => $r.receipt-file.Str ));
    }
    record('host', 'host_ended', %( runtimeExit => $exit ));
    write-status();
    # Anything still in the inbox now cannot be delivered: say so.
    for take-inbox($r) -> %t {
        record('host', 'directive_refused', %( directiveId => %t<directiveId> // %t<directive><directiveId>, reason => 'the run has ended' ));
    }
    $log.close;
    try $r.live-file.unlink;
    0;
}

#| Note the processes below this host, by identity, for a force stop
#| that has to work without the host.
sub snapshot-tree(RunDir $r) is export {
    my @t = descendants(my-pid()).map(-> $pid {
        my %s = proc-stat($pid) // Nil;
        %s ?? %( pid => $pid, start => %s<start>, sid => %s<sid>, pgid => %s<pgid>, command => proc-cmdline($pid).substr(0, 120) ) !! Empty
    });
    try write-atomic($r.dir.add('tree.json'), encode-json(%( at => now-iso(), bootId => boot-id(), processes => @t )) ~ "\n");
}

#| Stop every process below $root: SIGTERM, a grace period, then SIGKILL
#| for what remains.  Returns what was found and what it took.
sub sweep(Int $root, Int :$grace = KILL-GRACE --> List) is export {
    my %found;
    for descendants($root) -> $pid {
        my %s = proc-stat($pid) // next;
        %found{$pid} = %( pid => $pid, start => %s<start>, command => proc-cmdline($pid).substr(0, 200), signal => 'TERM' );
        send-signal($pid, SIGTERM);
    }
    my $deadline = now + $grace;
    while %found && now < $deadline {
        last unless %found.values.grep({ same-process(.<pid>, .<start>, '') });
        sleep 0.1;
    }
    for %found.values -> %p {
        if same-process(%p<pid>, %p<start>, '') { send-signal(%p<pid>, SIGKILL); %p<signal> = 'KILL' }
    }
    # whatever a TERM let fork in the meantime
    for descendants($root) -> $pid {
        my %s = proc-stat($pid) // next;
        send-signal($pid, SIGKILL);
        %found{$pid} //= %( pid => $pid, start => %s<start>, command => proc-cmdline($pid).substr(0, 200), signal => 'KILL' );
    }
    %found.values.sort(*<pid>).map({ %( pid => .<pid>, command => .<command>, signal => .<signal> ) }).List;
}

# ---------------------------------------------------------------- restart

#| Why a run cannot be started again, or Str when it can: only a run that
#| has ended (or is lost) has a request to run again.
sub restart-refusal(RunDir $r --> Str) is export {
    my %l = liveness($r);
    return Str if %l<phase> eq 'ended' | 'lost';
    "it is still {%l<phase>}; stop it first";
}

#| The question a person answers before a run's request is run again: what
#| the old run did, and that the new one starts from nothing.
sub restart-question(RunDir $r, Str :$harness = '' --> Str) is export {
    my %run = $r.run;
    my %rc = $r.receipt;
    my $files = @(%rc<evidence><filesChanged> // []).elems;
    my $tools = $r.events-file.e ?? fold($r.events-file.lines.map({ try parse-json($_) }).grep(Associative)).tools !! 0;
    my $who = "{%run<agent><displayName> // %run<agent><name> // 'the agent'} {$r.short}";
    "Run {$who}'s request again{$harness ne '' ?? ' on ' ~ harness-name($harness) !! ''}? It changed {$files} file{$files == 1 ?? '' !! 's'} and ran {$tools} tool{$tools == 1 ?? '' !! 's'}; "
        ~ "the new run has its own budget, and no approval carries over.";
}

#| A new run of an ended run's request: its own id, its own package, its
#| own budget.  The old run and its receipt are untouched; the new one
#| names the old one and the digest of the receipt it read.
sub restart-run(RunDir $r, Str :$via = 'mission-control', Str :$harness = '' --> List) is export {
    with restart-refusal($r) { return (RunDir, $_) }
    my %run = $r.run;
    my %continues = runId => $r.id, receiptDigest => ($r.receipt-file.e ?? digest-bytes($r.receipt-file.slurp(:bin)) !! Nil);
    # A run that had a worktree gets a fresh one of the same workspace:
    # it never inherits the other run's half-finished files.
    my %iso = (%run<isolation> // {}).Hash;
    my $ws = %iso ?? (%iso<of> // '') !! (%run<workspace> // '');
    my $h = $harness ne '' ?? $harness !! ((%run<harness> // {})<requested> // '');
    launch-run(%run<agent><name> // '', %run<request> // '', :workspace($ws), :$via, :%continues, :harness($h), :isolate(so %iso));
}

# ---------------------------------------------------------------- stopping

#| Ask a run to stop through its inbox.  Returns (directive id, error).
sub request-stop(RunDir $r, Str :$reason = 'stopped from Mission Control', Str :$client = 'mission-control' --> List) is export {
    my %l = liveness($r);
    return (Str, "it has already ended: {%l<outcome>}") if %l<phase> eq 'ended';
    return (Str, "it is lost: {%l<why>}") if %l<phase> eq 'lost';
    my $id = try send-directive($r, 'stop', :$reason, :$client);
    return (Str, $!.message) if $!;
    ($id, Str);
}

#| Stop a run without its host's help: verify the host is the process
#| host.json names, then stop it and everything below it.  When the host
#| is already gone, stop only processes still in its session, each
#| checked against the kernel.  Never a pid whose start time differs,
#| never anything outside the run.  Records ended.json with the basis.
sub force-stop(RunDir $r --> Hash) is export {
    my %l = liveness($r);
    # Ended and swept by its host: nothing to do.  Ended but unswept (the
    # host died before it could look for leftovers) still gets the sweep.
    return %( done => False, why => "it has already ended: {%l<outcome>}" ) if %l<phase> eq 'ended' && !%l<unswept>;
    my %h = $r.host;
    my @signalled;
    if %h && same-process(%h<pid>.Int, %h<startTicks>.Int, %h<bootId> // '') {
        my $hp = %h<pid>.Int;
        @signalled = sweep($hp);
        send-signal($hp, SIGTERM);
        my $deadline = now + KILL-GRACE;
        sleep 0.1 while now < $deadline && same-process($hp, %h<startTicks>.Int, '');
        my $sig = 'TERM';
        if same-process($hp, %h<startTicks>.Int, '') { send-signal($hp, SIGKILL); $sig = 'KILL' }
        @signalled.push(%( pid => $hp, command => 'the run host', signal => $sig ));
    }
    elsif %h && (%h<bootId> // '') eq boot-id() {
        # The host is gone.  What it ran may still be alive: every process
        # its last snapshot named that is still that same process, and
        # every process in the host's session or in a session one of those
        # led (a background task that set up its own).
        my %tree = (read-json-file($r.dir.add('tree.json')) // {}).Hash;
        my %sids;
        %sids{%h<sid>.Int} = True if (%h<sid> // 0) > 1;
        my %kill;
        for @(%tree<processes> // []) -> %p {
            next unless same-process(%p<pid>.Int, %p<start>.Int, '');
            %kill{%p<pid>.Int} = True;
            %sids{%p<sid>.Int} = True if %p<sid>.Int == %p<pid>.Int;    # it leads its own session
        }
        for '/proc'.IO.dir.grep({ .basename ~~ /^ \d+ $/ }) -> $d {
            my %s = proc-stat($d.basename.Int) // next;
            %kill{%s<pid>} = True if %sids{%s<sid>} && %s<pid> != my-pid();
        }
        for %kill.keys.map(*.Int).sort -> $pid {
            my $cmd = proc-cmdline($pid).substr(0, 200);
            send-signal($pid, SIGKILL) and @signalled.push(%( pid => $pid, command => $cmd, signal => 'KILL' ));
        }
    }
    sleep 0.3;
    my $recorded = $r.receipt-file.e ?? False !! record-ended($r, %(
        summary => @signalled ?? "stopped by force; the run left no receipt" !! "the host was gone and left no receipt; nothing of it was still running",
        hostPid => %h<pid> // Nil, lastHeartbeat => ($r.status<heartbeatAt> // ''), signalled => @signalled, observedBy => 'force-stop' ));
    try $r.live-file.unlink;
    %( done => True, signalled => @signalled, recorded => $recorded, receipt => $r.receipt-file.e );
}
