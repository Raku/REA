# Copyright Nige Ltd. Author: Nigel Hamilton.
unit module Do321::ClaudeHooks;

#| What 321 knows about Claude Code's hooks, in one place: which native
#| event carries each control, how a controller is wired into a project's
#| settings and taken out again, how a native event becomes a generic
#| action, and how a verdict becomes the answer Claude Code understands.
#| When Claude Code changes its hook mechanism, this file changes; no
#| controller does.
#|
#| The wiring never calls a controller directly.  Every hook runs
#|
#|     321 hook claude_code <controller> <control>
#|
#| which reads the native event, translates it, asks the controller, and
#| answers in Claude Code's terms.  That command line is also how 321
#| recognises its own entries: it replaces and removes those and leaves
#| every other setting and hook alone.

use Do321::JSON;
use Do321::Protocol;
use Do321::Controller;
use Do321::Look;

constant CLAUDE-HARNESS  is export = 'claude_code';
constant CLAUDE-SETTINGS is export = '.claude/settings.json';

#| The native event and matcher for a control; an empty list when Claude
#| Code has no place for it.
sub claude-event(Str $control --> List) is export {
    given $control {
        when CTRL-AUTHORITATIVE-CONTEXT { ('SessionStart', 'startup|resume|compact') }
        when CTRL-FILESYSTEM-GUARD      { ('PreToolUse', 'Edit|Write|MultiEdit|NotebookEdit') }
        when CTRL-SHELL-GUARD           { ('PreToolUse', 'Bash') }
        when CTRL-PRE-TOOL              { ('PreToolUse', '') }
        when CTRL-PRE-ACTION            { ('PreToolUse', '') }
        when CTRL-POST-TOOL             { ('PostToolUse', '') }
        when CTRL-POST-ACTION           { ('PostToolUse', '') }
        when CTRL-POST-RUN              { ('Stop', '') }
        default                         { () }
    }
}

#| The glue command for one control.
sub glue-command(Str $self, Str $controller, Str $control --> Str) is export {
    "$self hook {CLAUDE-HARNESS} $controller $control";
}

#| Whether a settings entry is 321's wiring for a controller.  The legacy
#| form (a controller's own hook command written straight into the
#| settings, as `321 hooks install` and iz4 once did) counts for iz4, so
#| an install replaces it instead of running both.
sub ours($entry, Str $controller --> Bool) {
    return False unless $entry ~~ Associative;
    so @($entry<hooks> // []).grep({
        $_ ~~ Associative && ($_<command> // '') ~~ Str
            && ($_<command>.contains(" hook {CLAUDE-HARNESS} $controller ")
                || ($controller eq 'iz4' && so $_<command> ~~ m:P5/(^|[\/ ])iz4 hook (session-start|pre-edit|stop)$/))
    });
}

#| The hook entries for a set of controls, grouped by native event.
#| Controls Claude Code has no event for are left out.
sub claude-entries(Str $self, Str $controller, @controls --> Hash) is export {
    my %h;
    for @controls -> $control {
        my ($event, $matcher) = claude-event($control);
        next without $event;
        my %e = hooks => [ %( type => 'command', command => glue-command($self, $controller, $control) ), ];
        %e<matcher> = $matcher if $matcher ne '';
        %h{$event} = [ |@(%h{$event} // []), %e ];
    }
    %h;
}

sub read-settings(IO::Path $target --> Hash) {
    return %() unless $target.e;
    my $parsed = try parse-json($target.slurp);
    die "{$target.Str} is not a JSON object; fix it, then install again\n" unless $parsed ~~ Associative;
    %$parsed;
}

sub settings-text($v --> Str) is export { encode-json-pretty($v) ~ "\n" }

#| The status line 321 writes: it re-reads iz4's last result every two
#| seconds, so a check run outside the session shows too.
sub status-line-entry(Str $self --> Hash) is export {
    %( type => 'command', command => "$self hook {CLAUDE-HARNESS} iz4 {STATUS-LINE}", refreshInterval => 2 );
}

sub status-line-ours($entry --> Bool) is export {
    so $entry ~~ Associative && ($entry<command> // '') ~~ Str
       && $entry<command>.ends-with(" hook {CLAUDE-HARNESS} iz4 {STATUS-LINE}");
}

#| Whether the person set a status line of their own, for every project.
sub own-status-line(--> Bool) {
    my $home = %*ENV<CLAUDE_CONFIG_DIR> ?? %*ENV<CLAUDE_CONFIG_DIR>.IO !! $*HOME.add('.claude');
    so <settings.json settings.local.json>.grep(-> $f {
        my $p = try parse-json($home.add($f).slurp);
        $p ~~ Associative && $p<statusLine>.defined && !status-line-ours($p<statusLine>)
    });
}

#| Wire a controller into a project's settings for the given controls,
#| keeping every other setting and every hook that is not 321's for this
#| controller.  Returns 'installed', 'updated' or 'unchanged'; dies on a
#| settings file it cannot parse, touching nothing.
sub claude-install(IO::Path $workspace, Str $self, Str $controller, @controls --> Str) is export {
    my $target = $workspace.add(CLAUDE-SETTINGS);
    my %settings = read-settings($target);
    my $before = $target.e ?? canonical(%settings) !! '';
    my %hooks = %settings<hooks> ~~ Associative ?? %(%settings<hooks>) !! %();
    my $had = so %hooks.values.grep({ @($_ // []).grep({ ours($_, $controller) }) });
    for %hooks.keys -> $event {
        my @kept = @(%hooks{$event} // []).grep({ !ours($_, $controller) });
        if @kept { %hooks{$event} = [ |@kept ] } else { %hooks{$event}:delete }
    }
    my %add = claude-entries($self, $controller, @controls);
    for %add.keys.sort -> $event { %hooks{$event} = [ |@(%hooks{$event} // []), |@(%add{$event}) ] }
    %settings<hooks> = %hooks;
    # iz4's last result on the status line, where nothing labels it as a
    # warning.  Only where no status line is set, here or in the person's
    # own settings: a project's line would hide theirs.
    %settings<statusLine> = status-line-entry($self)
        if $controller eq 'iz4' && (status-line-ours(%settings<statusLine>) || (!%settings<statusLine>.defined && !own-status-line()));
    return 'unchanged' if $before ne '' && canonical(%settings) eq $before;
    mkdir-p($target.parent);
    $target.spurt(settings-text(%settings));
    $had ?? 'updated' !! 'installed';
}

#| Take only this controller's entries out; 'removed' or 'unchanged'.
sub claude-remove(IO::Path $workspace, Str $controller --> Str) is export {
    my $target = $workspace.add(CLAUDE-SETTINGS);
    return 'unchanged' unless $target.e;
    my %settings = read-settings($target);
    return 'unchanged' unless %settings<hooks> ~~ Associative;
    my %hooks = %(%settings<hooks>);
    my $removed = False;
    for %hooks.keys -> $event {
        my @all = @(%hooks{$event} // []);
        my @kept = @all.grep({ !ours($_, $controller) });
        $removed = True if @kept.elems != @all.elems;
        if @kept { %hooks{$event} = [ |@kept ] } else { %hooks{$event}:delete }
    }
    if $controller eq 'iz4' && status-line-ours(%settings<statusLine>) { %settings<statusLine>:delete; $removed = True }
    return 'unchanged' unless $removed;
    if %hooks { %settings<hooks> = %hooks } else { %settings<hooks>:delete }
    $target.spurt(settings-text(%settings));
    'removed';
}

#| What is actually in the settings for a controller: control => 'installed',
#| 'legacy' (an older direct wiring covers that moment) or 'missing'.  A
#| settings file that cannot be parsed has nothing installed.
sub claude-verify(IO::Path $workspace, Str $controller, @controls --> Hash) is export {
    my %state = @controls.map({ $_ => 'missing' });
    my $target = $workspace.add(CLAUDE-SETTINGS);
    return %state unless $target.e;
    my $parsed = try parse-json($target.slurp);
    return %state unless $parsed ~~ Associative && $parsed<hooks> ~~ Associative;
    my %hooks = %($parsed<hooks>);
    my %legacy = CTRL-AUTHORITATIVE-CONTEXT, 'session-start', CTRL-FILESYSTEM-GUARD, 'pre-edit', CTRL-POST-RUN, 'stop';
    for @controls -> $control {
        my ($event, $matcher) = claude-event($control);
        next without $event;
        for @(%hooks{$event} // []) -> $entry {
            next unless $entry ~~ Associative;
            for @($entry<hooks> // []) -> $h {
                next unless $h ~~ Associative && ($h<command> // '') ~~ Str;
                if $h<command>.ends-with(" hook {CLAUDE-HARNESS} $controller $control") { %state{$control} = 'installed' }
                elsif %state{$control} eq 'missing' && $controller eq 'iz4' && (%legacy{$control} // '') ne ''
                      && $h<command>.ends-with("iz4 hook {%legacy{$control}}") { %state{$control} = 'legacy' }
            }
        }
    }
    %state;
}

# ---------------------------------------------------------------- per run

#| The same wiring as a value for `claude --settings`, so a run 321
#| launches carries its hooks without anything being written into the
#| caller's workspace.
sub claude-run-settings(Str $self, %by-controller --> Str) is export {
    my %hooks;
    for %by-controller.keys.sort -> $controller {
        my %add = claude-entries($self, $controller, @(%by-controller{$controller}));
        for %add.keys.sort -> $event { %hooks{$event} = [ |@(%hooks{$event} // []), |@(%add{$event}) ] }
    }
    %hooks ?? encode-json(%( hooks => %hooks )) !! '';
}

#| The tools a turn may use without changing anything.  Any other tool
#| (Edit, Write, Bash, an agent it delegated to, one 321 has never heard
#| of) counts as able to change files: the answer errs towards asking.
my constant @READ-ONLY-TOOLS = <Read Grep Glob LS WebSearch WebFetch TodoWrite AskUserQuestion ToolSearch
                                ReadNotifications ListAgents SendMessage>;

sub turn-record-uses-tool($rec --> Bool) {
    my $content = ($rec<message> // {})<content> // $rec<content>;
    $content ~~ Positional && so @$content.grep({ $_ ~~ Associative && ($_<type> // '') eq 'tool_use' });
}

#| Whether the turn that is ending (the records since the person's last
#| prompt) used any tool that can change files.  No transcript, or one
#| that cannot be read, is taken as yes: the controller is then asked.
sub claude-turn-may-have-changed(Str $path --> Bool) is export {
    return True unless $path ne '' && $path.IO.f;
    my @turn;
    for $path.IO.lines -> $line {
        my $rec = try parse-json($line);
        next unless $rec ~~ Associative;
        my $type = ($rec<type> // '').Str;
        # the person's own prompt starts a turn; a tool result is also
        # typed 'user' and does not
        if $type eq 'user' && !$rec<toolUseResult> && !$rec<isMeta> {
            my $content = ($rec<message> // {})<content> // $rec<content>;
            my $is-prompt = $content ~~ Str
                || ($content ~~ Positional && !@$content.grep({ $_ ~~ Associative && ($_<type> // '') eq 'tool_result' }));
            if $is-prompt { @turn = (); next }
        }
        # a prompt typed while the assistant was busy arrives as an
        # attachment; it starts a turn only if the one before had ended,
        # because one delivered between tool calls joins that turn's work
        if $type eq 'attachment' && (($rec<attachment> // {})<type> // '') eq 'queued_command' {
            @turn = () unless @turn && turn-record-uses-tool(@turn.tail);
            next;
        }
        @turn.push($rec) if $type eq 'assistant';
    }
    for @turn -> $rec {
        my $content = ($rec<message> // {})<content> // $rec<content>;
        next unless $content ~~ Positional;
        for @$content.grep({ $_ ~~ Associative && ($_<type> // '') eq 'tool_use' }) -> $use {
            return True unless is-in(($use<name> // '').Str, @READ-ONLY-TOOLS);
        }
    }
    False;
}

#| The last thing the assistant said, from a Claude Code transcript (JSON
#| lines): the text a controller needs to look for a report in.
sub claude-last-words(Str $path --> Str) is export {
    return '' unless $path ne '' && $path.IO.f;
    my $text = '';
    for $path.IO.lines -> $line {
        my $rec = try parse-json($line);
        next unless $rec ~~ Associative && ($rec<type> // '') eq 'assistant';
        my $content = ($rec<message> // {})<content> // $rec<content>;
        my @parts;
        if $content ~~ Positional { @parts = @$content.grep({ $_ ~~ Associative && ($_<type> // '') eq 'text' }).map({ ($_<text> // '').Str }) }
        elsif $content ~~ Str { @parts = ($content,) }
        $text = @parts.join("\n") if @parts.join.trim ne '';
    }
    $text;
}

# ------------------------------------------------------------- translation

#| A native Claude Code hook event as a generic action: what is being done
#| to what.  Tools 321 does not know by name are still described, as a
#| tool call with their input, so nothing passes unseen for want of a
#| mapping.
sub claude-action(%native --> Action) is export {
    my $tool = (%native<tool_name> // '').Str;
    my %in = %native<tool_input> ~~ Associative ?? %(%native<tool_input>) !! %();
    my $repo = (%native<cwd> // '').Str;
    my $context = "claude_code tool $tool";
    given $tool {
        when 'Write' {
            Action.new(:operation<write>, :target((%in<file_path> // '').Str), :parameters(%( content => (%in<content> // '').Str )), :repository($repo), :$context)
        }
        when 'Edit' {
            Action.new(:operation<edit>, :target((%in<file_path> // '').Str),
                :parameters(%( old => (%in<old_string> // '').Str, new => (%in<new_string> // '').Str )), :repository($repo), :$context)
        }
        when 'MultiEdit' {
            Action.new(:operation<edit>, :target((%in<file_path> // '').Str), :parameters(%( edits => (%in<edits> // []) )), :repository($repo), :$context)
        }
        when 'NotebookEdit' {
            Action.new(:operation<edit>, :target((%in<notebook_path> // %in<file_path> // '').Str),
                :parameters(%( new => (%in<new_source> // '').Str )), :repository($repo), :$context)
        }
        when 'Bash' {
            Action.new(:operation<execute>, :target<shell>, :parameters(%( command => (%in<command> // '').Str )), :repository($repo), :$context)
        }
        when 'WebFetch' {
            Action.new(:operation<fetch>, :target((%in<url> // '').Str), :parameters(%( prompt => (%in<prompt> // '').Str )),
                :recipient((%in<url> // '').Str), :repository($repo), :$context)
        }
        default {
            Action.new(:operation<tool>, :target($tool), :parameters(%in), :repository($repo), :$context)
        }
    }
}

#| A line Claude Code shows to the person at the session, whatever the
#| model does with it.
sub claude-system-message(Str $text --> Str) is export { encode-json(%( systemMessage => $text )) ~ "\n" }

#| A verdict in Claude Code's terms: (exit code, stdout, stderr).
#|
#| Before a tool call: a block refuses it (exit 2, the reason to the
#| model).  needs_human asks the person at the session to decide, which is
#| the harness's own approval prompt; in a headless run there is nobody to
#| ask, so it refuses and tells the agent to stop and put the proposal to a
#| person.  A warning lets the call through and says why.  At the end of a
#| turn a block or needs_human refuses the stop, so the agent says what is
#| outstanding instead of ending silently, and a warning is shown to the
#| person.
#|
#| When the controller could not be asked at all (it is missing, crashed,
#| timed out, gave no result), what happens depends on what this control
#| can do, never on convenience:
#|
#|   an ENFORCING control (a guard before a tool call, the check at the
#|   end of a turn) STOPS the thing it guards and says that enforcement
#|   could not be performed.  It never quietly becomes advice.
#|
#|   an ADVISORY control (it can only tell: the context at session start,
#|   a note after a tool, or any control this harness can only advise on)
#|   lets the work through and shows the person a warning that the
#|   controller did NOT check it.
#|
#| :strength is what the harness can do at this control here (enforces or
#| advises); :controller names who was asked, for the message.
sub claude-answer(Str $control, Verdict $v, Bool :$headless = False, Str :$strength = STRENGTH-ENFORCES,
                  Str :$controller = 'the controller' --> List) is export {
    my ($event) = claude-event($control);
    my $why = $v.proposal ne '' ?? $v.proposal !! $v.reason;
    my $who = $controller.uc;
    unless $v.ran {
        my $can-stop = $strength eq STRENGTH-ENFORCES && (($event // '') eq 'PreToolUse' || ($event // '') eq 'Stop');
        if $can-stop {
            my $what = ($event // '') eq 'Stop'
                ?? "The finished work was not checked, so this turn was not allowed to end as if it had been. Say plainly to the person that $who could not check the work, and why."
                !! "This action was stopped because the check that guards it did not run; that is not a finding about the action. Do not work around it: tell the person.";
            return (2, '', "321: $who enforcement could not be performed: {$v.reason}\n$what\n"
                         ~ "A person can put it right (restore {$controller}) or take the wiring out: 321 {$controller} remove\n");
        }
        my $note = "321: $who did NOT check this: {$v.reason}. The work was let through unchecked.";
        return (0, claude-system-message($note), "$note\n");
    }
    if ($event // '') eq 'PreToolUse' {
        given $v.result {
            when RESULT-BLOCK { return (2, '', "$why\n") }
            when RESULT-NEEDS-HUMAN {
                return (2, '', "$why\nNobody can be asked from here. Stop this part of the work and put the proposal to a person.\n") if $headless;
                return (0, encode-json(%( hookSpecificOutput => %( hookEventName => 'PreToolUse', permissionDecision => 'ask',
                    permissionDecisionReason => $why ) )) ~ "\n", '');
            }
            when RESULT-WARN {
                return (0, encode-json(%( hookSpecificOutput => %( hookEventName => 'PreToolUse', additionalContext => $why ),
                                          systemMessage => "321: $who warns: {$v.reason}" )) ~ "\n", '');
            }
            default { return (0, '', '') }
        }
    }
    if ($event // '') eq 'Stop' {
        # A refusal is the controller's one line, named as its own, and
        # nothing appended: the harness shows it to the agent as it stands.
        # (A proposal already opens with the controller's name.)
        return (2, '', ($v.proposal ne '' ?? $why !! "$who: $why") ~ "\n") if $v.stops;
        return (0, claude-system-message("321: $who warns: {$v.reason}"), '') if $v.result eq RESULT-WARN;
        # A clean end is quiet: Claude Code shows any line here as a warning
        # ("Stop says:"), and nothing waits on the person.  What held is
        # shown where nothing labels it: the status line and Mission
        # Control, both read from iz4's last result.
        return (0, '', '');
    }
    # After the fact nothing can be stopped; what was found is still shown.
    return (0, claude-system-message("321: $who: {$v.reason}"), '') if $v.result ne RESULT-PASS;
    return (0, '', '');
}
