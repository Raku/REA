unit module Do321::Run;

#| Executes one WorkPackage: checks the package against the loaded agent
#| and local policy, computes effective grants, selects a procedure or a
#| capable adapter, drives attempts while applying ordered directives, and
#| produces the immutable receipt.
#|
#| Authority is decided here, once, before any adapter runs.  Nothing an
#| adapter or an agent says afterwards widens it.

use Data::Native;
use Do321::JSON;
use Do321::Shape;
use Do321::Protocol;
use Do321::Async;
use Do321::Adapter;
use Do321::Trust;
use Do321::Controller;
use Do321::Enforcement;
use Do321::Models;
use Do321::Plan;

#| Receives run events in order.  Implementations must not block for
#| long: the wire layer buffers and coalesces; tests collect.
role Sink is export {
    method emit(%event) { ... }
}

#| A Sink that can report how many events it dropped.
role CoalescingSink does Sink is export {
    method coalesced(--> Int) { ... }
}

class SinkFunc does Sink is export {
    has &.f;
    method emit(%e) { &!f(%e) }
}

sub null-sink() { SinkFunc.new(:f(-> % {})) }

#| One run's options.
class Options is export {
    has Mailbox $.directives;
    #| Stops raised by signals.  Their own box, because the caller's closes
    #| when stdin does, and a signal must still reach the run after that.
    has Mailbox $.signals;
    has $.sink;
    has Str $.run-id = '';
    has Str $.history-dir = '';
    has %.policy;                   # a Policy document
    has Str $.adapter = '';         # restrict selection to one adapter name
    #| The caller already holds a stop for this run: wait for it before
    #| anything is attempted, so the run ends stopped having done nothing.
    has Bool $.stop-first = False;
    #| The terminal receipt of an earlier run of the SAME package that
    #| this run continues.  Cost and attempt numbering carry forward; the
    #| old receipt is untouched and linked from the new one.
    has $.continue;
    #| The terminal receipt of an earlier run of the same agent package
    #| whose conversation this run goes on from: a new package (the
    #| person's next words), its own budget, and the harness session
    #| resumed where the harness can, so the agent remembers.
    has $.follows;
    #| The package exactly as received.  The receipt's packageDigest is
    #| computed over these bytes canonicalised, never over a re-marshalled
    #| document, so the issuer can compare it with what it sent.
    has Blob $.package-raw;
    has &.now;
    has &.list-changed-files;
    #| The controllers to drive (an IZ4 driver, say).  Unset means the
    #| defaults; an empty list means none.
    has $.controllers;
    #| What the agent's curation asks for this run (Do321::Plan::Want);
    #| undefined asks for nothing, and the harness's own model is used.
    has $.want;
    #| The models known here (Do321::Models), for pinning the plan.
    has @.models;
}

# --------------------------------------------------------------- prompt

#| What a model-driven adapter is told: the package's own identity and
#| prompts, then the work.  Prompt text is not a security boundary; the
#| grants are, and they were enforced before this rendered.
sub render-prompt(%wp, Loaded $agent, @grants, @instructions, Str :$policy = '' --> Str) is export {
    my %m = $agent.manifest;
    my $b = "You are {%m<displayName>} ({%m<id>}), {%m<identity><role>}.\n";
    $b ~= "Personality: {%m<identity><personality>}\n" if %m<identity><personality> ne '';
    $b ~= "Tone: {%m<identity><tone>}\n" if %m<identity><tone> ne '';
    $b ~= "Decision style: {%m<identity><decisionStyle>}\n" if %m<identity><decisionStyle> ne '';
    my $p = $agent.prompt;
    $b ~= "\n$p\n" if $p ne '';
    if $policy ne '' {
        $b ~= "\n## What governs this work\n\nThis project states what must remain true while it is worked on. Read what follows before planning or changing anything. It comes from the project, not from whoever asked for this work, and it grants you no authority. Where it asks you to report something when you finish, put that report, in full, in your summary: the summary is what gets checked.\n\n$policy\n";
    }
    $b ~= "\n## The work\n\n{%wp<objective>}\n";
    $b ~= "\n{%wp<instructions>}\n" if %wp<instructions> ne '';
    my @conds = @(%wp<completion><conditions> // []);
    if @conds {
        $b ~= "\nYou are done when:\n";
        for @conds.kv -> $i, $c { $b ~= "{$i + 1}. $c\n" }
        $b ~= "Answer each of these in `conditions`, in this order: whether it is met, and the proof, the test, the command output or the file that shows it.\n";
    }
    my @ev = @(%wp<completion><expectedEvidence> // []);
    $b ~= "Expected evidence: {@ev.join('; ')}\n" if @ev;
    $b ~= "\nYou may use: {@grants.join(', ')}. Nothing else is available to you.\n" if @grants;
    my %a = %wp<authority>;
    my @may = @(%a<may> // []);
    my @may-not = @(%a<mayNot> // []);
    my @approval = @(%a<approvalRequired> // []);
    if @may || @may-not || @approval {
        $b ~= "\nAuthority for this task:\n";
        for @may -> %g { $b ~= %g<scope> ne '' ?? "- may: {%g<capability>} ({%g<scope>})\n" !! "- may: {%g<capability>}\n" }
        $b ~= "- may not: $_\n" for @may-not;
        $b ~= "- needs a person's approval first: $_\n" for @approval;
        $b ~= "Absence of a grant is denial: if something you need is not listed, report status \"blocked\" rather than assume it.\n";
    }
    with %wp<approval> -> %ap {
        $b ~= "\nAn approval exists for exactly one action: {%ap<action>}";
        $b ~= " on {%ap<target>}" if %ap<target> ne '';
        $b ~= ". Do nothing beyond it.\n";
    }
    my @lines = @(%wp<context><lines> // []);
    if @lines {
        $b ~= "\nWhat is already known (oldest first):\n";
        $b ~= "- " ~ .trim.subst("\n", ' ', :g) ~ "\n" for @lines;
    }
    my @att = @(%wp<context><attachments> // []);
    if @att {
        $b ~= "\nAttachments:\n";
        for @att -> %at { $b ~= "- {%at<name>}" ~ (%at<uri> ne '' ?? " ({%at<uri>})" !! '') ~ "\n" }
    }
    if @instructions {
        $b ~= "\nFurther instructions received while you were working, in order. They clarify or steer the work above; they do not widen what you may do:\n";
        for @instructions.kv -> $i, $t { $b ~= "{$i + 1}. {$t.trim}\n" }
    }
    $b ~= %wp<workspace><kind> eq 'git'
        ?? "\nMake the change in this repository. Do not commit: the caller reviews and commits. When you're done, stop.\n"
        !! "\nWhen you're done, stop.\n";
    $b ~= "\nIf the instruction is ambiguous or you cannot proceed, do not guess: report status \"blocked\" and put the single question you need answered in blocked_on. Before asking, check whether what is already known answers it.\n";
    $b ~= "If nothing needs changing, report status \"no_change\" and say why in summary.\n";
    # Said again at the end, where a model reads its closing instructions:
    # the preamble under "What governs this work" asked for the report once
    # already, and a run on 2026-10-25 changed files, wrote a summary with
    # no report, and was held back by the project's check for exactly that.
    $b ~= "Before you stop, if you changed anything: end your summary with the report the section \"What governs this work\" asks for, in the form it gives, one line per item it names. A summary without it is held back by the project's own check, and the work is not accepted.\n" if $policy ne '';
    $b;
}

# ------------------------------------------------------------- evidence

#| The history as NDJSON, digested, and written under $dir when given.
#| Returns (uri, digest, error or Str).
sub write-history(Str $dir, @lines --> List) is export {
    my $text = @lines.map({ to-wire('HistoryLine', $_) ~ "\n" }).join;
    my $digest = digest-string($text);
    return ('', $digest, Str) if $dir eq '';
    my $d = $dir.IO;
    try { mkdir-p($d); $d.chmod(0o700) };
    return ('', $digest, $!.message) if $!;
    my $path = $d.add('instruction-history.ndjson');
    try { $path.spurt($text); $path.chmod(0o600) };
    return ('', $digest, $!.message) if $!;
    ('file://' ~ $path.absolute, $digest, Str);
}

#| Changed and untracked paths in a git workspace.  Read-only; the
#| runtime never commits.
sub git-changed-files(Str $workspace --> List) is export {
    my $p = try run 'git', '-C', $workspace, 'status', '--porcelain', '--untracked-files=all', :out, :err;
    return () if $! || !$p.defined;
    my $out = $p.out.slurp(:close); $p.err.slurp(:close);
    return () unless $p.exitcode == 0;
    my @files;
    for $out.subst(/\n+$/, '').split("\n") -> $line {
        next if $line.chars < 4;
        my $f = $line.substr(3).trim;
        $f = $f.substr($f.index(' -> ') + 4) if $f.contains(' -> ');
        @files.push($f);
    }
    @files.List;
}

# ------------------------------------------------------------ directives

constant BOUNDARY-NONE  = '';
constant BOUNDARY-STEER = 'steer';
constant BOUNDARY-PAUSE = 'pause';

#| The ordered intake of directives for one run.
#|
#| Ordinary directives are applied strictly in sequence: a directive whose
#| predecessor has not arrived waits, and is rejected at the end of the
#| run if the gap never fills.  Stop bypasses the order: it is applied as
#| soon as it is authenticated, the gap is recorded, and nothing that is
#| waiting on stdout, a full buffer or a slow adapter can hold it up,
#| because stopping is a cancellation and not an event.
class DirectiveState {
    has $.session;
    has Lock $!mu = Lock.new;
    has %!seen-id;
    has %!seen-seq;
    has %!all;
    has Int $!next-seq = 1;
    has %!waiting;
    has @!instr-queue;           # received, not yet applied (runner-level)
    has %!applied-set;
    has @!received;
    has @!applied-list;
    has @!rejected-list;
    has @!duplicates;
    has @!gaps;
    has $!stop;
    has Str $!stop-at = '';
    has Cancel $!cancel-run;
    has Bool $!run-done = False;
    # attempt-scoped
    has Cancel $!attempt-cancel;
    has %!live;
    has Mailbox $!live-ch;
    has Str $!boundary = '';
    has $!pause-pending;
    has Bool $!paused = False;
    has Promise $!resume-p;
    has Str $!resume-id = '';

    #| Begin reading the caller's directive mailbox for the life of the
    #| run.  The reader never blocks on the adapter: it records, orders
    #| and either cancels, queues or forwards.
    method start(Cancel $ctx, Cancel $cancel-run) {
        $!cancel-run = $cancel-run;
        my $self = self;
        for self!boxes -> $box {
            start {
                loop {
                    my $d = $box.receive(:cancel($ctx));
                    last without $d;
                    $self.receive($d);
                }
            }
        }
    }

    method !boxes(--> List) { ($!session.opts.directives, $!session.opts.signals).grep(*.defined).List }

    #| Take every directive the caller has already delivered, so
    #| instructions handed over with the package apply at the first
    #| attempt rather than interrupting it a moment later.
    method drain-now() {
        for self!boxes -> $box {
            loop {
                my $d = $box.poll;
                last without $d;
                self.receive($d);
            }
        }
    }

    method receive(%dir) {
        $!mu.protect({
            return if $!run-done;
            my $ps = validate-work-directive(%dir);
            if $ps { self!reject-locked(%dir<directiveId>, 'invalid directive: ' ~ $ps.Str); return }
            if %dir<packageId> ne $!session.wp<packageId> {
                self!reject-locked(%dir<directiveId>, "directive names package {%dir<packageId>} but this run is {$!session.wp<packageId>}"); return;
            }
            if %dir<runRef> ne '' && %dir<runRef> ne $!session.receipt<runId> {
                self!reject-locked(%dir<directiveId>, "directive names run {%dir<runRef>} but this run is {$!session.receipt<runId>}"); return;
            }
            if %!seen-id{%dir<directiveId>} {
                @!duplicates.push(%dir<directiveId>);
                $!session.emit(EVENT-DIRECTIVE-DUPLICATE, %( directiveId => %dir<directiveId>, seq => %dir<seq> ));
                return;
            }
            if %!seen-seq{%dir<seq>}:exists {
                @!duplicates.push(%dir<directiveId>);
                $!session.emit(EVENT-DIRECTIVE-DUPLICATE, %( directiveId => %dir<directiveId>, seq => %dir<seq>, sameSeqAs => %!seen-seq{%dir<seq>} ));
                return;
            }
            %!seen-id{%dir<directiveId>} = True;
            %!seen-seq{%dir<seq>} = %dir<directiveId>;
            %!all{%dir<directiveId>} = %dir;
            @!received.push(%dir<directiveId>);
            $!session.emit(EVENT-DIRECTIVE-RECEIVED, %( directiveId => %dir<directiveId>, seq => %dir<seq>, kind => %dir<kind> ));

            if %dir<kind> eq DIRECTIVE-STOP {
                if %dir<seq> != $!next-seq {
                    @!gaps.push(doc('SequenceGap', directiveId => %dir<directiveId>, expectedSeq => $!next-seq, receivedSeq => %dir<seq>));
                }
                # with/else, not without/else: Raku++ 5.1 refuses an else on without.
                with $!stop { self!reject-locked(%dir<directiveId>, 'already stopping on ' ~ $!stop<directiveId>) }
                else {
                    $!stop = %dir;
                    $!stop-at = $!session.now.();
                    # Cancel first, then tell anyone listening: a full event
                    # buffer must never delay the stop itself.
                    $!cancel-run.cancel;
                    if $!paused && $!resume-p.defined { $!resume-p.keep(True); $!resume-p = Promise }
                    $!session.emit(EVENT-STOPPING, %( directiveId => %dir<directiveId>, reason => %dir<payload><reason> ));
                }
                return;
            }
            %!waiting{%dir<seq>} = %dir;
            loop {
                last unless %!waiting{$!next-seq}:exists;
                my %next = %!waiting{$!next-seq};
                %!waiting{$!next-seq}:delete;
                $!next-seq++;
                self!dispatch-locked(%next);
            }
        });
    }

    #| Route one in-order directive: live to the adapter when it can act
    #| on it, otherwise to the runner's own boundary handling.
    method !dispatch-locked(%dir) {
        given %dir<kind> {
            when DIRECTIVE-CLARIFY | DIRECTIVE-STEER {
                if enforces(%!live, FEAT-LIVE-STEER) && $!live-ch.defined && !$!paused { self!forward-locked(%dir); return }
                @!instr-queue.push(%dir);
                if $!attempt-cancel.defined && $!boundary eq BOUNDARY-NONE && !$!paused
                    && enforces(%!live, FEAT-SESSION-CONTINUE) && enforces(%!live, FEAT-GRACEFUL-STOP) {
                    $!boundary = BOUNDARY-STEER;
                    $!attempt-cancel.cancel;
                }
            }
            when DIRECTIVE-PAUSE {
                if enforces(%!live, FEAT-PAUSE) && $!live-ch.defined { self!forward-locked(%dir); return }
                if $!paused || $!pause-pending.defined { self!reject-locked(%dir<directiveId>, 'already paused'); return }
                $!pause-pending = %dir;
                if $!attempt-cancel.defined { $!boundary = BOUNDARY-PAUSE; $!attempt-cancel.cancel }
            }
            when DIRECTIVE-RESUME {
                if enforces(%!live, FEAT-PAUSE) && $!live-ch.defined { self!forward-locked(%dir); return }
                unless $!paused { self!reject-locked(%dir<directiveId>, 'not paused'); return }
                $!resume-id = %dir<directiveId>;
                $!paused = False;
                if $!resume-p.defined { $!resume-p.keep(True); $!resume-p = Promise }
            }
        }
    }

    method !forward-locked(%dir) {
        # The adapter is not draining: a directive is never dropped; it is
        # queued for the runner instead, which applies it at the next boundary.
        @!instr-queue.push(%dir) unless $!live-ch.try-send(%dir);
    }

    method !reject-locked(Str $id, Str $reason) {
        @!rejected-list.push(doc('RejectedDirective', directiveId => $id, reason => $reason));
        $!session.emit(EVENT-DIRECTIVE-REJECTED, %( directiveId => $id, reason => $reason ));
    }

    #| Acknowledge a directive as actually in effect.
    method applied(Str $id) {
        $!mu.protect({
            return if %!applied-set{$id};
            %!applied-set{$id} = True;
            @!applied-list.push($id);
            $!session.emit(EVENT-DIRECTIVE-APPLIED, %( directiveId => $id ));
            if %!all{$id}:exists {
                $!session.append-history(doc('HistoryLine', kind => 'directive', directive => %!all{$id}, disposition => 'applied'));
            }
        });
    }

    #| Acknowledge a directive the adapter could not apply.
    method rejected(Str $id, Str $reason) { $!mu.protect({ self!reject-locked($id, $reason) }) }

    method stop-requested(--> Bool) { $!mu.protect({ $!stop.defined }) }

    #| The queued instructions for the next attempt and the ids to
    #| acknowledge once that attempt has started.
    method take-instructions(--> List) {
        $!mu.protect({
            my @texts = @!instr-queue.map({ $_<payload><text> });
            my @ids = @!instr-queue.map({ $_<directiveId> });
            @!instr-queue = ();
            ([ |@texts ], [ |@ids ]);
        });
    }

    method has-instructions(--> Bool) { $!mu.protect({ so @!instr-queue }) }

    method attempt-started(Cancel $cancel, %live) {
        $!mu.protect({
            $!attempt-cancel = $cancel;
            %!live = %live;
            $!boundary = BOUNDARY-NONE;
            if enforces(%live, FEAT-LIVE-STEER) || enforces(%live, FEAT-PAUSE) {
                $!live-ch = Mailbox.new(:capacity(64));
                # Directives that arrived before this attempt was listening
                # are replayed to it in order, so nothing is lost between attempts.
                my @queued = @!instr-queue;
                @!instr-queue = ();
                self!forward-locked($_) for @queued;
                if $!pause-pending.defined && !$!paused && enforces(%live, FEAT-PAUSE) {
                    my %p = $!pause-pending;
                    $!pause-pending = Any;
                    self!forward-locked(%p);
                }
                return;
            }
            $!live-ch = Mailbox;
            # A pause that arrived between attempts takes effect before work
            # resumes: end this attempt at once.
            if $!pause-pending.defined && !$!paused { $!boundary = BOUNDARY-PAUSE; $cancel.cancel }
        });
    }

    method live-channel() { $!mu.protect({ $!live-ch }) }

    #| The boundary that ended the attempt, if the runner forced one;
    #| clears attempt state.
    method attempt-ended(--> Str) {
        $!mu.protect({
            my $b = $!boundary;
            $!boundary = BOUNDARY-NONE;
            $!attempt-cancel = Cancel;
            with $!live-ch {
                # Anything the adapter did not drain is not lost.
                loop {
                    my $d = $!live-ch.poll;
                    last without $d;
                    next if %!applied-set{$d<directiveId>};
                    if $d<kind> eq DIRECTIVE-CLARIFY || $d<kind> eq DIRECTIVE-STEER { @!instr-queue.push($d) }
                    else { self!reject-locked($d<directiveId>, 'attempt ended before it could be applied') }
                }
                $!live-ch = Mailbox;
            }
            $b;
        });
    }

    #| Mark the pending pause as in effect: the attempt has ended.
    method pause-applied() {
        my $p = $!mu.protect({
            my $p = $!pause-pending;
            $!pause-pending = Any;
            $!paused = True;
            $!resume-p = Promise.new;
            $p;
        });
        self.applied($p<directiveId>) with $p;
    }

    #| Block while paused.  False when the run was stopped instead of
    #| resumed.
    method wait-resumed(Cancel $ctx --> Bool) {
        my $p = $!mu.protect({ $!resume-p });
        with $p { await Promise.anyof($p, $ctx.promise); return False if $ctx.done && !($p.status ~~ Kept) }
        my ($id, $stopped) = $!mu.protect({ my $i = $!resume-id; $!resume-id = ''; ($i, $!stop.defined) });
        return False if $stopped;
        self.applied($id) if $id ne '';
        True;
    }

    #| Settle everything still outstanding: waiting gaps, queued
    #| instructions, a pause that never took effect, directives already
    #| delivered but too late to act on, and the stop itself.
    method finish-run() {
        # Anything the caller has already handed over but the reader has not
        # yet taken is late: acknowledged as rejected rather than lost.
        for self!boxes -> $box {
            loop {
                my $d = $box.poll;
                last without $d;
                $!mu.protect({
                    if !$!run-done && !%!seen-id{$d<directiveId>} {
                        %!seen-id{$d<directiveId>} = True;
                        self!reject-locked($d<directiveId>, 'arrived after the run ended');
                    }
                });
            }
        }
        my $stop = $!mu.protect({
            $!run-done = True;
            my @leftovers = @!instr-queue;
            @!instr-queue = ();
            if $!pause-pending.defined { @leftovers.push($!pause-pending); $!pause-pending = Any }
            for %!waiting.keys.map(*.Int).sort -> $seq {
                self!reject-locked(%!waiting{$seq}<directiveId>, "sequence $!next-seq never arrived, so seq $seq was never applied");
            }
            %!waiting = ();
            for @leftovers -> $l {
                self!reject-locked($l<directiveId>, 'the run ended before it could be applied') unless %!applied-set{$l<directiveId>};
            }
            $!stop;
        });
        self.applied($stop<directiveId>) with $stop;
    }

    method stop-info(Str $now --> Hash) {
        $!mu.protect({
            without $!stop {
                return doc('StopInfo', issuer => { kind => 'runtime', id => 'context' }, at => $now, reason => 'cancelled');
            }
            my $reason = $!stop<payload><reason>;
            $reason = 'stop directive' if $reason eq '';
            doc('StopInfo', issuer => $!stop<issuer>, at => $!stop-at, reason => $reason, directiveId => $!stop<directiveId>);
        });
    }

    method summarise(%r) {
        $!mu.protect({
            %r<directives> = doc('DirectiveSummary', received => [ |@!received ], applied => [ |@!applied-list ],
                rejected => [ |@!rejected-list ], duplicates => [ |@!duplicates ], gaps => [ |@!gaps ]);
        });
    }
}

# ------------------------------------------------------------ controllers

#| Controllers on a run.  When something governs the workspace (an IZ4,
#| found and driven through its controller) and the run is model-driven,
#| the runtime does four things and records each on the receipt:
#|
#|   - the controller's context goes into the prompt before the work;
#|   - the harness's own interception points are used where it has them:
#|     wiring already installed in the project is counted, and what is
#|     missing is registered for this run alone, without writing to the
#|     caller's workspace;
#|   - the hooks report back through a log, so the receipt says how many
#|     really fired instead of assuming they did;
#|   - the finished work is put to the controller.  needs_human and block
#|     end the run blocked with the reason, or the proposal a person must
#|     decide on, in blockedOn; a warning and a check that could not run
#|     go on the uncertain list.  The runtime never records agreement.
#|
#| What a controller's words mean is the controller's business: nothing
#| here reads an IZ4.  Procedures (no model) are outside all of this.

#| The 321 command a harness should call back from this run's hooks: this
#| very program.  DO_321_HOOK_SELF overrides it (the suite runs from
#| source).  '' when the runtime cannot name itself, which is reported as
#| a gap, never papered over.
sub run-hook-self(--> Str) is export {
    with %*ENV<DO_321_HOOK_SELF> { return $_ if $_ ne '' }
    my $exe = $*EXECUTABLE.Str;
    $exe.IO.basename ~~ m:P5/^(rakupp|raku|rakudo|perl6)/ ?? '' !! $exe;
}

#| One controller's state on one run.
class Governing {
    has $.controller;
    has %.found;
    has Str $.text is rw = '';
    has Bool $.aware is rw = False;
    has Bool $.checked is rw = False;
    has Bool $.verified is rw = False;
    has Str $.human is rw = '';
    has Int $.fired is rw = 0;         # hooks that reported back with the controller's answer
    has Int $.unanswered is rw = 0;    # hooks that fired and could not get one
    has @.checks;
    has @.gaps;
    has %.controls;
    has @.registered;            # controls registered with the harness for this run
    has @.guards;                # guard controls operating, installed or registered
}

# --------------------------------------------------------------- session

class Session is export {
    has $.runner;
    has %.wp;
    has $.agent;
    has Options $.opts;
    has &.now;
    has %.receipt;
    has @.grants is rw;
    has $.adapter is rw;
    has %.plan is rw;                    # the execution plan this run is pinned to
    has @!carry;                         # what the next attempt is told of the one before it
    has $.procedure is rw;
    has %.captures is rw;
    has Lock $!mu = Lock.new;
    has Int $!event-seq = 0;
    has %.spent;
    has @!history;
    has Bool $!closed = False;
    has Int $.attempt-base = 0;
    has Str $.seed-session = '';
    has DirectiveState $.dir;
    has @!governing;                     # a Governing per controller that applies
    has Str $.policy-text = '';          # the controllers' context, as it goes into the prompt
    has Str $!hook-log = '';             # where this run's hooks report back
    has Str $!final-words = '';          # what the agent said in its last attempt, beyond the summary
    has @!tool-failures;                 # failing tool results 321 saw in this run's events, in words
    has Int $!tool-failures-more = 0;    # those beyond the ones kept
    has Int $!hook-lines = 0;

    method !init() {
        my $run-id = $!opts.run-id ne '' ?? $!opts.run-id !! new-ulid();
        my %agent-ref = %!wp<agent>;
        with $!agent { %agent-ref = doc('AgentRef', id => .id, version => .manifest<version>, digest => .digest) }
        %!receipt = doc('RunReceipt', schema => SCHEMA-RUN-RECEIPT, receiptId => new-ulid(), packageId => %!wp<packageId>,
            supersedesPackageId => %!wp<supersedesPackageId>, runId => $run-id, issuer => %!wp<issuer>,
            correlation => %!wp<correlation>, agent => %agent-ref, attempts => [],
            directives => { received => [], applied => [], rejected => [] }, startedAt => &!now(), conditions => []);
        %!spent = doc('Cost');
        with $!opts.package-raw {
            my $canon = try canonicalize-json($_);
            %!receipt<packageDigest> = digest-string($canon) unless $!;
        }
        %!receipt<packageDigest> = package-digest(%!wp) if %!receipt<packageDigest> eq '';
        %!receipt<conditionsDigest> = conditions-digest(%!wp<completion><conditions>);
        @!history.push(doc('HistoryLine', kind => 'package', package => %!wp));
        with $!opts.continue -> %prev {
            $!attempt-base = @(%prev<attempts> // []).elems;
            $!attempt-base += %prev<continues><attempts> with %prev<continues>;
            %!spent = load('Cost', %prev<cost>);
            %!receipt<continues> = doc('Continuation', runId => %prev<runId>, receiptId => %prev<receiptId>,
                receiptDigest => %prev<receiptDigest>, attempts => $!attempt-base);
            my @att = @(%prev<attempts> // []);
            $!seed-session = @att.tail<sessionRef> if @att;
            @!history.push(doc('HistoryLine', kind => 'continues', continues => %!receipt<continues>));
        }
        with $!opts.follows -> %prev {
            %!receipt<follows> = doc('RunLink', runId => %prev<runId>, receiptId => %prev<receiptId>, receiptDigest => %prev<receiptDigest>);
            my @att = @(%prev<attempts> // []);
            $!seed-session = (@att.tail<sessionRef> // '') if @att;
            @!history.push(doc('HistoryLine', kind => 'follows', follows => %!receipt<follows>));
        }
        $!dir = DirectiveState.new(:session(self));
    }

    method make($runner, %wp, $agent, Options $opts) {
        my &now = $opts.now // &now-stamp;
        my $s = Session.new(:$runner, :%wp, :$agent, :$opts, :&now);
        $s!init;
        $s;
    }

    method append-history(%l) { $!mu.protect({ @!history.push(%l) }) }
    method close() { $!mu.protect({ $!closed = True }) }

    method emit(Str $kind, %payload) {
        my %ev = $!mu.protect({
            $!event-seq++;
            doc('RunEvent', schema => SCHEMA-RUN-EVENT, eventId => new-ulid(), packageId => %!wp<packageId>,
                runId => %!receipt<runId>, attempt => $!attempt-base + @(%!receipt<attempts>).elems + 1,
                seq => $!event-seq, at => &!now(), kind => $kind, payload => %payload);
        });
        ($!opts.sink // null-sink()).emit(%ev);
        self!note-tool-failure(%payload) if $kind eq EVENT-TOOL-RESULT;
    }

    #| A tool result that says it failed is something 321 saw on the run,
    #| not something the agent claimed.  A few are kept, in words; the
    #| rest are counted.
    method !note-tool-failure(%p) {
        return unless (%p<ok>:exists) && !%p<ok>;
        my sub s($v) { $v ~~ Str ?? $v !! '' }
        my $what = (s(%p<tool>), s(%p<op>)).grep(* ne '').join(' ') || 'a tool';
        my $why = s(%p<unavailable>) || s(%p<error>) || ((%p<exitCode>:exists) ?? "exit {%p<exitCode>}" !! 'failed');
        $!mu.protect({
            if @!tool-failures.elems < 10 { @!tool-failures.push("$what: $why") }
            else { $!tool-failures-more++ }
        });
    }

    method tool-failures(--> List) {
        $!mu.protect({
            ( |@!tool-failures, |($!tool-failures-more ?? ("and $!tool-failures-more more failing tool result(s)",) !! ()) ).List
        });
    }

    #| Refuse packages the runtime must not execute at all.  Returns
    #| (reason, details) with reason '' when the package may run.
    method check(--> List) {
        my $ps = validate-work-package(%!wp);
        return ('the work package is invalid', [ |$ps.list.map(*.Str) ]) if $ps;
        if %!wp<expiresAt> ne '' {
            my $t = try parse-time(%!wp<expiresAt>);
            my $n = try parse-time(&!now());
            return ('the work package has expired', ['expiresAt ' ~ %!wp<expiresAt>]) if $t && $n && $n > $t;
        }
        return ('the work package names a different agent', ["package wants {%!wp<agent><id>}, loaded {$!agent.id}"]) if %!wp<agent><id> ne $!agent.id;
        return ('the pinned agent version does not match', ["package wants {%!wp<agent><version>}, loaded {$!agent.manifest<version>}"])
            if %!wp<agent><version> ne '' && %!wp<agent><version> ne $!agent.manifest<version>;
        return ('the pinned agent digest does not match', ["package wants {%!wp<agent><digest>}, loaded {$!agent.digest}"])
            if %!wp<agent><digest> ne '' && %!wp<agent><digest> ne $!agent.digest;
        if %!wp<placement> ne PLACEMENT-EITHER && !is-in(%!wp<placement>, @($!agent.manifest<placement><allowed> // [])) {
            return ("the package's placement is not allowed by the agent package",
                ["placement {%!wp<placement>}, agent allows {@($!agent.manifest<placement><allowed> // []).join(', ')}"]);
        }
        return ('runtime-owned workspaces are not supported in this release', []) if %!wp<workspace><kind> eq 'git' && %!wp<workspace><ownership> ne 'caller';
        with $!opts.continue -> %prev {
            return ('the continued receipt is for a different package', ["receipt {%prev<packageId>}, package {%!wp<packageId>}"]) if %prev<packageId> ne %!wp<packageId>;
            return ('the continued receipt saw a different package document', ["receipt {%prev<packageDigest>}, now {%!receipt<packageDigest>}"])
                if %prev<packageDigest> ne '' && %prev<packageDigest> ne %!receipt<packageDigest>;
            return ('the continued receipt ran a different agent package', ["receipt {%prev<agent><digest>}, loaded {$!agent.digest}"])
                if %prev<agent><digest> ne '' && %prev<agent><digest> ne $!agent.digest;
            return ('the continued receipt does not match its own digest', []) unless receipt-digest(%prev) eq %prev<receiptDigest>;
            return ('only a blocked, stopped or completed run can be continued', ['previous status ' ~ %prev<status>])
                unless is-in(%prev<status>, [STATUS-BLOCKED, STATUS-STOPPED, STATUS-COMPLETED, STATUS-NO-CHANGE]);
        }
        with $!opts.follows -> %prev {
            return ('the followed receipt does not match its own digest', []) unless receipt-digest(%prev) eq %prev<receiptDigest>;
            return ('the followed receipt ran a different agent package', ["receipt {%prev<agent><digest>}, loaded {$!agent.digest}"])
                if %prev<agent><digest> ne '' && %prev<agent><digest> ne $!agent.digest;
        }
        ('', []);
    }

    #| The caller's grants intersected with local policy and the package's
    #| own restrictions.  Returns (grants, reason, details).
    method effective-grants(--> List) {
        my %granted = @(%!wp<capabilities><granted> // []).map({ $_ => True });
        with $!opts.policy<capabilityCeiling> -> $ceiling {
            my %c = @$ceiling.map({ $_ => True });
            for %granted.keys -> $g { %granted{$g}:delete unless %c{$g} }
        }
        %granted{$_}:delete for @($!agent.manifest<capabilities><denied> // []);
        my @missing = @($!agent.manifest<capabilities><required> // []).grep({ !%granted{$_} });
        return ([], 'the package requires capabilities that are not granted', ['missing: ' ~ @missing.join(', ')]) if @missing;
        return ([], 'net.fetch is granted but the network limit is not open', []) if %granted{CAP-NET-FETCH} && effective-network(%!wp) ne NETWORK-OPEN;
        ([ |%granted.keys.sort ], '', []);
    }

    #| The first procedure whose predicate matches the objective, with the
    #| named groups it captured.
    method match-procedure(--> List) {
        for @($!agent.manifest<procedures> // []) -> %p {
            my $pat = %p<matches><objectiveRegex>;
            my $m = try { %!wp<objective> ~~ m:P5/$pat/ };
            next if $! || !$m;
            my %captures;
            for $m.hash.kv -> $k, $v { %captures{$k} = $v.Str if $v.defined }
            return (%p, %captures);
        }
        (Any, {});
    }

    method deny(Str $reason, @details --> Hash) {
        self.emit(EVENT-DENIED, %( reason => $reason, details => [ |@details ] ));
        %!receipt<status> = STATUS-DENIED;
        %!receipt<denied> = doc('DenialInfo', reason => $reason, details => [ |@details ]);
        %!receipt<summary> = 'denied: ' ~ $reason;
        %!receipt<harness><adapter> = 'none' if %!receipt<harness><adapter> eq '';
        self.finish;
    }

    #| Check an operation against the package's exact approval: the
    #| recomputed params hash, and the action, target and params
    #| themselves.  Returns (ApprovalCheck, error or Str).
    method approval-gate(Str $action, Str $target, $params --> List) {
        my $a = %!wp<approval>;
        return (doc('ApprovalCheck', detail => 'no approval on the package'), no-approval-error().message) without $a;
        my %check = doc('ApprovalCheck');
        %check<paramsHashMatched> = params-hash($a<params>) eq $a<paramsHash>;
        my $want = canonical($a<params> // {});
        my $got = canonical($params // {});
        %check<operationMatched> = $action eq $a<action> && $target eq ($a<target> // '') && $want eq $got;
        if !%check<paramsHashMatched> {
            %check<detail> = 'paramsHash does not match the approved params';
            return (%check, 'approval: ' ~ %check<detail>);
        }
        if !%check<operationMatched> {
            %check<detail> = "operation $action on \"$target\" does not match the approved {$a<action>} on \"{$a<target>}\"";
            return (%check, 'approval: ' ~ %check<detail>);
        }
        %check<detail> = 'operation matches approval ' ~ $a<approvalRef>;
        (%check, Str);
    }

    # ------------------------------------------------------ the attempt loop

    method drive(Cancel $parent --> Hash) {
        my $run-ctx = $parent.child;
        my $t = %!wp<capabilities><limits><timeout> // '';
        if $t ne '' {
            my $d = try parse-duration($t);
            $run-ctx = $run-ctx.with-timeout($d) if $d && $d > 0;
        }
        $!dir.start($run-ctx, $run-ctx);
        $!dir.drain-now;
        if $!opts.stop-first { for ^200 { last if $!dir.stop-requested; sleep 0.05; $!dir.drain-now } }
        my %live = $!adapter.enforcement;
        self.apply-controllers;

        my $last = Outcome.new;
        # the session is the earlier run's harness's: another harness
        # cannot resume it, and one that cannot continue sessions starts anew
        my $earlier = $!opts.continue // $!opts.follows;
        if $!seed-session ne '' && $earlier.defined && $earlier<harness><adapter> eq $!adapter.name && enforces(%live, FEAT-SESSION-CONTINUE) {
            $last.session-ref = $!seed-session;
        }
        loop {
            if $!dir.stop-requested { %!receipt<status> = STATUS-STOPPED; last }
            my $reason = self.budget-exhausted;
            if $reason ne '' {
                %!receipt<status> = STATUS-FAILED;
                %!receipt<summary> = 'budget exhausted: ' ~ $reason;
                %!receipt<evidence><errors> = [ |@(%!receipt<evidence><errors> // []), $reason ];
                last;
            }
            my $n = $!attempt-base + @(%!receipt<attempts>).elems + 1;
            my $attempt-ctx = $run-ctx.child;
            $!dir.attempt-started($attempt-ctx, %live);
            my ($instructions, $applying) = $!dir.take-instructions;
            if @!carry { $instructions = [ |@!carry, |@$instructions ]; @!carry = () }
            self.refresh-controllers($n);
            my $spec = self.spec($n, @$instructions, $last.session-ref);
            self.emit(EVENT-ATTEMPT-STARTED, %( attempt => $n, adapter => $!adapter.name, instructions => @$instructions.elems, resumed => $spec.session-ref ne '',
                |((%!plan<modelName> // '') ne '' ?? (model => %!plan<modelName>) !! ()),
                |((%!plan<effort> // '') ne '' ?? (effort => %!plan<effort>) !! ()) ));
            $!dir.applied($_) for @$applying;
            my $started = &!now();
            my ($out, $err) = self.run-attempt($attempt-ctx, $spec);
            $attempt-ctx.cancel;
            self.read-hook-log;
            my $boundary = $!dir.attempt-ended;
            with $err {
                $out.status = STATUS-FAILED; $out.end-reason = 'adapter_error';
                $out.errors.push($err);
            }
            %!spent = add-cost(%!spent, $out.cost);
            %!receipt<attempts>.push(doc('Attempt', n => $n, adapter => $!adapter.name, startedAt => $started, endedAt => &!now(),
                endReason => end-reason($out, $boundary, $run-ctx), sessionRef => $out.session-ref, cost => $out.cost,
                model => $spec.model, effort => $spec.effort, profile => (%!plan<profile> // '')));
            if $out.session-ref ne '' {
                %!receipt<harness><sessionRefs> = [ |@(%!receipt<harness><sessionRefs> // []), $out.session-ref ];
            }
            self.append-history(doc('HistoryLine', kind => 'attempt', attempt => $n, instructions => [ |@$instructions ],
                sessionRef => $out.session-ref, endReason => $out.end-reason));
            self.emit(EVENT-ATTEMPT-ENDED, %( attempt => $n, status => $out.status, endReason => $out.end-reason, boundary => $boundary ));
            $last = $out;
            $last.session-ref = $spec.session-ref if $out.session-ref eq '' && $spec.session-ref ne '';

            if $!dir.stop-requested { %!receipt<status> = STATUS-STOPPED; last }
            if $run-ctx.deadline-exceeded {
                %!receipt<status> = STATUS-FAILED;
                %!receipt<summary> = 'no result within the time allowed';
                %!receipt<evidence><errors> = [ |@(%!receipt<evidence><errors> // []), 'timeout: ' ~ %!wp<capabilities><limits><timeout> ];
                last;
            }
            if $boundary eq BOUNDARY-PAUSE {
                $!dir.pause-applied;
                self.emit(EVENT-PAUSED, %( attempt => $n ));
                unless $!dir.wait-resumed($run-ctx) { %!receipt<status> = STATUS-STOPPED; last }
                self.emit(EVENT-RESUMED, %( attempt => $n ));
                $last.session-ref = '' unless enforces(%live, FEAT-SESSION-CONTINUE);
                next;
            }
            if $boundary eq BOUNDARY-STEER {
                $last.session-ref = '' unless enforces(%live, FEAT-SESSION-CONTINUE);
                next;
            }
            if $!dir.stop-requested { %!receipt<status> = STATUS-STOPPED; last }
            # A natural end.  Instructions that arrived too late for this
            # attempt are not dropped: they start a continuation, unless the
            # run failed, in which case they are rejected below.
            if $!dir.has-instructions && $out.status ne STATUS-FAILED {
                $last.session-ref = '' unless enforces(%live, FEAT-SESSION-CONTINUE);
                next;
            }
            # A check showed the work needs more than this configuration
            # gave: climb one step of the plan's own ladder and go on, while
            # the budget and the plan's bound allow.  Nothing done is redone:
            # the harness session carries over where the harness keeps one.
            my $gap = self.capability-gap($out);
            if $gap ne '' && self.budget-exhausted eq '' {
                my $moved = escalate-plan(%!plan, $!adapter, $!opts.models, $n, $gap);
                if $moved ne '' {
                    self.emit(EVENT-PROGRESS, %( text => "$gap; going on with more: $moved" ));
                    @!carry.push("The attempt before this one did not finish the work ($gap). Go on from where it stopped. Do not repeat anything that is already done.");
                    $last.session-ref = '' unless enforces(%live, FEAT-SESSION-CONTINUE);
                    next;
                }
            }
            %!receipt<status> = $out.status;
            last;
        }
        %!receipt<plan> = %!plan if %!plan;
        $!dir.finish-run;
        self.fill($last);
        self.check-controllers;
        self.check-conditions;
        self.blocked-evidence($last);
        self.finish;
    }

    method controllers(--> List) { $!opts.controllers.defined ?? @($!opts.controllers).List !! default-controllers() }

    method !uncertain(Str $line) { %!receipt<uncertain> = [ |@(%!receipt<uncertain> // []), $line ] }

    method !rebuild-policy-text() {
        $!policy-text = @!governing.grep({ .text ne '' }).map({ "### {.controller.name}\n\n{.text.trim-trailing}" }).join("\n\n");
    }

    #| Find what governs the workspace, take its context for the prompt,
    #| and plan the harness's interception points.
    method apply-controllers() {
        return if $!procedure.defined;
        return if $!adapter ~~ ProcedureAdapter && !$!adapter.controls;
        my $ws = (%!wp<workspace><path> // '').Str;
        return if $ws eq '';
        for self.controllers -> $c {
            my %found = $c.discover($ws);
            next unless %found;
            my $label = $c.name.uc;
            my $g = Governing.new(:controller($c), :%found);
            @!governing.push($g);
            unless %found<available> {
                self!uncertain("$label present at {%found<subject>}; not applied: {%found<reason>}");
                $g.gaps.push("not driven: {%found<reason>}");
                next;
            }
            my ($text, $err) = $c.context($ws);
            with $err {
                self!uncertain("$label present at {%found<subject>}; not applied: $err");
                $g.gaps.push("its context could not be read: $err");
                next;
            }
            $g.text = $text;
            $g.aware = True;
            $g.controls{CTRL-AUTHORITATIVE-CONTEXT} = 'in the prompt';
            $g.checks.push(%( point => POINT-CONTEXT, result => RESULT-PASS, reason => 'the context is in the prompt' ));
            self!plan-hooks($g, $ws);
            self.append-history(doc('HistoryLine', kind => 'controller-context', instructions => [ "$label {%found<subject>} {%found<digest>}" ]));
            # nothing is said to the person: a policy that is in place and
            # holds is silent.  The check above keeps the fact for the record.
        }
        self!rebuild-policy-text;
    }

    #| Which of the harness's controls will operate for a controller on
    #| this run: what the project already has installed, what can be
    #| registered for the run, and what the harness does not have.
    method !plan-hooks(Governing $g, Str $ws) {
        my @wants = $g.controller.wants;
        my %caps = $!adapter.headless-controls;
        my %installed = $!adapter.verify-controller($ws.IO, $g.controller.name, @wants);
        my $self = run-hook-self();
        for @wants -> $ctl {
            next if $ctl eq CTRL-AUTHORITATIVE-CONTEXT;       # the runtime puts the context in the prompt itself
            my $strength = control-strength(%caps, $ctl);
            my $guard = is-in($ctl, [CTRL-FILESYSTEM-GUARD, CTRL-SHELL-GUARD, CTRL-PRE-TOOL, CTRL-PRE-ACTION]);
            if $strength eq STRENGTH-NONE {
                if $ctl eq CTRL-POST-RUN { $g.controls{$ctl} = 'by the runtime, at the end of the run' }
                else {
                    $g.controls{$ctl} = 'unavailable';
                    $g.gaps.push("{control-label($ctl)} is not available in {$!adapter.name}");
                }
                next;
            }
            if (%installed{$ctl} // '') eq 'installed' { $g.controls{$ctl} = "installed in the project ($strength)" }
            elsif $!adapter.can-register-hooks && $self ne '' {
                $g.controls{$ctl} = "registered for this run ($strength)";
                $g.registered.push($ctl);
            }
            else {
                if $ctl eq CTRL-POST-RUN { $g.controls{$ctl} = 'by the runtime, at the end of the run' }
                else {
                    $g.controls{$ctl} = 'not registered';
                    $g.gaps.push("{control-label($ctl)} could not be registered for this run"
                        ~ ($self eq '' ?? ' (the runtime could not name its own command)' !! " ({$!adapter.name} takes no hooks for a single run)"));
                }
                next;
            }
            $g.guards.push($ctl) if $guard && $strength eq STRENGTH-ENFORCES;
        }
    }

    #| What the adapter needs to carry this run's hooks: the controls to
    #| register, the command to call back, and where the hooks report.
    method hook-spec(--> Hash) {
        my %by;
        for @!governing -> $g { %by{$g.controller.name} = [ |$g.registered ] if $g.registered.elems > 0 }
        my $any = so @!governing.grep({ .registered.elems > 0 || .guards.elems > 0 });
        return %() unless $any;
        if $!hook-log eq '' {
            $!hook-log = $*TMPDIR.add("321-hooks-{%!receipt<runId>}-{(^1_000_000).pick}.ndjson").Str;
            try $!hook-log.IO.spurt('');
        }
        %( hook-controls => %by, hook-self => run-hook-self(), hook-env => %( DO_321_HEADLESS => '1', DO_321_HOOK_LOG => $!hook-log ) );
    }

    #| Read what the hooks reported since the last look.  A refusal or a
    #| warning is recorded in full; a pass is only counted.
    method read-hook-log() {
        return if $!hook-log eq '' || !$!hook-log.IO.f;
        my @lines = $!hook-log.IO.lines;
        my $i = $!hook-lines;
        while $i < @lines.elems {
            my $rec = try parse-json(@lines[$i]);
            $i++;
            next unless $rec ~~ Associative;
            my $g = @!governing.first({ .controller.name eq ($rec<controller> // '') });
            next without $g;
            # A hook that owed the controller no question (a turn that could
            # not have changed a file) answered nothing: it is not a hook
            # that fired, and never counts towards guarded.
            next if ($rec<asked>:exists) && !$rec<asked>;
            # A hook that could not get the controller's answer checked
            # nothing: it is counted apart and never as protection.
            if ($rec<result> // '') eq RESULT-UNAVAILABLE {
                $g.unanswered = $g.unanswered + 1;
                $g.checks.push(%( point => (($rec<point> // '') || POINT-ACTION).Str, result => RESULT-UNAVAILABLE,
                                  control => ($rec<control> // '').Str, reason => ($rec<reason> // '').Str ));
                $g.gaps.push("a hook could not ask {$g.controller.name}: {($rec<reason> // '').Str}");
                next;
            }
            $g.fired = $g.fired + 1;
            next if ($rec<result> // '') eq RESULT-PASS;
            my %c = point => ($rec<point> // 'action').Str, result => ($rec<result> // '').Str, control => ($rec<control> // '').Str;
            %c<point> = POINT-ACTION if %c<point> eq '';
            %c<reason> = $rec<reason>.Str if ($rec<reason> // '') ne '';
            %c<invariants> = [ |@($rec<invariants> // []).map(*.Str) ] if @($rec<invariants> // []);
            $g.checks.push(%c);
            $g.human = 'required during the work: an action was refused until a person decides' if %c<result> eq RESULT-NEEDS-HUMAN;
        }
        $!hook-lines = @lines.elems;
    }

    #| Take the context again when what governs changed between attempts.
    method refresh-controllers(Int $n) {
        my $ws = (%!wp<workspace><path> // '').Str;
        my $changed = False;
        for @!governing.grep(*.aware) -> $g {
            my %now = $g.controller.discover($ws);
            next unless %now && %now<available> && (%now<digest> // '') ne ($g.found<digest> // '');
            my ($text, $err) = $g.controller.context($ws);
            next with $err;
            $g.text = $text;
            $g.found<digest> = %now<digest>;
            $changed = True;
            self.append-history(doc('HistoryLine', kind => 'controller-context', attempt => $n,
                instructions => [ "{$g.controller.name.uc} {%now<subject>} changed; re-read, {%now<digest>}" ]));
            self.emit(EVENT-PROGRESS, %( text => "{$g.controller.name.uc} policy: what governs the work changed during the run; its context was re-read" ));
        }
        self!rebuild-policy-text if $changed;
    }

    #| Put the finished work to each controller, and record on the receipt
    #| what governed the run and how strongly.
    method check-controllers() {
        return unless @!governing;
        my %r := %!receipt;
        my $ws = (%!wp<workspace><path> // '').Str;
        self.read-hook-log;
        if is-in(%r<status>, [STATUS-COMPLETED, STATUS-NO-CHANGE]) {
            for @!governing.grep(*.aware) -> $g {
                my $label = $g.controller.name.uc;
                my $words = (%r<summary> // '').Str ~ ($!final-words ne '' ?? "\n\n$!final-words" !! '');
                my $v = $g.controller.verify($ws, %( summary => $words ));
                $v = $g.controller.check-change($ws) unless $v.ran;
                unless $v.ran {
                    # The end-of-work check is one the runtime enforces.  When
                    # it cannot be performed the work is not passed off as
                    # completed: the run ends blocked, saying enforcement could
                    # not be performed, for a person to look at.
                    self!uncertain("$label: the finished work was not checked: {$v.reason}");
                    $g.gaps.push("the finished work was not checked: {$v.reason}");
                    $g.checks.push(%( point => POINT-VERIFY, result => RESULT-UNAVAILABLE, reason => $v.reason ));
                    if %r<status> ne STATUS-BLOCKED {
                        %r<status> = STATUS-BLOCKED;
                        %r<blockedOn> = "$label enforcement could not be performed: the finished work was not checked ({$v.reason}). "
                                      ~ 'Nothing here says the work is wrong; a person should look before it is taken as done.';
                        self.emit(EVENT-PROGRESS, %( text => "$label policy: the finished work could not be checked; the run is blocked, not completed" ));
                    }
                    next;
                }
                if $v.parts {
                    for @($v.parts) -> %p {
                        $g.checks.push(%( point => "{$v.point}/{%p<part>}", result => %p<result>, reason => %p<detail> ));
                        $g.checked = True if %p<part> eq 'change' && %p<result> ne 'not_checked';
                    }
                }
                elsif $v.point eq POINT-CHANGE { $g.checked = True }
                $g.checks.push($v.record);
                $g.verified = $v.point eq POINT-VERIFY && $v.result eq RESULT-PASS;
                self!uncertain($_) for @($v.uncertain);
                next unless $v.stops && %r<status> ne STATUS-BLOCKED;
                %r<status> = STATUS-BLOCKED;
                if $v.result eq RESULT-NEEDS-HUMAN {
                    %r<blockedOn> = $v.proposal ne '' ?? $v.proposal !! "$label: {$v.reason}";
                    $g.human = 'required: a person must agree to this change, and none has; the runtime never agrees for them';
                    self.emit(EVENT-PROGRESS, %( text => "$label policy: this work changes what the project commits to; the run is blocked until a person decides" ));
                }
                else {
                    %r<blockedOn> = "$label: {$v.reason}";
                    self.emit(EVENT-PROGRESS, %( text => "$label policy: the finished work did not pass; the run is blocked, not completed" ));
                }
            }
        }
        %r<evidence><controllers> = [ |@!governing.map({ self!controller-evidence($_) }) ];
        try $!hook-log.IO.unlink if $!hook-log ne '';
    }

    #| The package's done conditions decide whether the work is done, not
    #| the agent's word that it is.  A run that would end completed or
    #| no_change with any condition unmet, or unanswered, ends blocked
    #| instead, naming them, so it can be continued to finish them.  The
    #| answers themselves are the agent's: the receipt says 321 did not
    #| check them.  A run with no conditions is left as it is.
    method check-conditions() {
        my @want = @(%!wp<completion><conditions> // []);
        return unless @want;
        my %r := %!receipt;
        self!uncertain("the done conditions' met and proof answers are the agent's own; 321 did not check them");
        return unless is-in(%r<status>, [STATUS-COMPLETED, STATUS-NO-CHANGE]);
        my @unmet = @want.keys.grep({ !(%r<conditions>[$_] // {})<met> });
        return unless @unmet;
        my sub short(Str $s) { my $l = $s.lines.head // ''; $l.chars > 80 ?? $l.substr(0, 80) ~ '…' !! $l }
        my @named = @unmet.head(3).map({ "#{$_ + 1} {short(@want[$_].Str)}" });
        @named.push('…') if @unmet > 3;
        %r<status> = STATUS-BLOCKED;
        %r<blockedOn> = "done conditions not met: {+@unmet} of {+@want} ({@named.join('; ')})";
        self.emit(EVENT-PROGRESS, %( text => "{+@unmet} of {+@want} done conditions are not met; the run is blocked, not completed" ));
    }

    #| Whether a blocked run's blocker was seen by 321 or is only the
    #| agent's word.  Blocked by 321 itself (unmet conditions, a
    #| controller, a procedure's own step): observed.  Blocked on the
    #| agent's say-so: observed only when the run recorded a failing tool,
    #| a denial or an error; otherwise reported.  The status stands either
    #| way: this records, it does not judge.
    method blocked-evidence(Outcome $last) {
        my %r := %!receipt;
        return unless %r<status> eq STATUS-BLOCKED;
        my %e = %r<evidence> // {};
        my $seen = so (@(%e<toolFailures> // []) || @(%e<denials> // []) || @(%e<errors> // []));
        my $agents-word = $last.status eq STATUS-BLOCKED && !$!procedure.defined;
        %r<blockedEvidence> = !$agents-word || $seen ?? 'observed' !! 'reported';
    }

    method !controller-evidence(Governing $g --> Hash) {
        my @levels;
        @levels.push(PROTECT-AWARE) if $g.aware;
        @levels.push(PROTECT-CHECKED) if $g.checked;
        if $g.guards {
            if $g.fired > 0 && $g.unanswered == 0 { @levels.push(PROTECT-GUARDED) }
            elsif $g.unanswered > 0 {
                $g.gaps.push("interception was wired, but {$g.unanswered} hook call(s) could not ask {$g.controller.name}; those actions were stopped, and the run is not counted as guarded");
            }
            else { $g.gaps.push('interception was wired, but no hook reported back, so it is not counted as guarded') }
        }
        @levels.push(PROTECT-VERIFIED) if $g.verified;
        my @checks;
        for @($g.checks) -> %c { @checks.push(doc('ControllerCheck', |%c)) }
        doc('ControllerEvidence', name => $g.controller.name, harness => $!adapter.name, subject => ($g.found<subject> // '').Str,
            digest => ($g.found<digest> // '').Str, levels => [ |@levels ], controls => %( $g.controls ),
            checks => @checks, hooksFired => $g.fired,
            humanDecision => ($g.human ne '' ?? $g.human !! 'none was needed'), gaps => [ |$g.gaps.unique ]);
    }

    #| Why the attempt that just ended calls for a stronger configuration,
    #| or '' when it does not.  Only what 321 saw counts: the harness
    #| failing or ending with no result, or the agent itself reporting a
    #| done condition unmet.  An attempt that acted outside the workspace
    #| is never followed by another on its account, and a blocked attempt
    #| is a question for a person, not for a larger model.
    method capability-gap(Outcome $out --> Str) {
        return '' unless %!plan && @(%!plan<ladder> // []);
        return '' if $!procedure.defined || $out.external-action.defined || $out.denials;
        # What a climb may answer is the plan's own list.  A harness that
        # failed is the default and the only one: an unmet condition is as
        # often something missing on the machine as a model too small, and a
        # larger model cannot install it.  An agent's curation may add it.
        my %on = @(%!plan<escalateOn> // ['harness_failure']).map({ $_ => True });
        if $out.status eq STATUS-FAILED {
            return 'the harness stopped before a result' if %on<harness_failure> && $out.end-reason eq 'harness_error' | 'no_result';
            return '';
        }
        if %on<unmet_conditions> && is-in($out.status, [STATUS-COMPLETED, STATUS-NO-CHANGE]) {
            my @want = @(%!wp<completion><conditions> // []);
            my @unmet = @want.keys.grep({ !(($out.conditions[$_] // {})<met>) });
            return "{+@unmet} of {+@want} done conditions were not met" if @want && @unmet;
        }
        '';
    }

    method run-attempt(Cancel $ctx, Spec $spec --> List) {
        my %live = $!adapter.enforcement;
        my $self = self;
        my $ctl = Control.new(
            emit     => -> $kind, %payload { $self.emit($kind, %payload) },
            applied  => -> $id { $self.dir.applied($id) },
            rejected => -> $id, $reason { $self.dir.rejected($id, $reason) },
            approval => -> $action, $target, $params { $self.approval-gate($action, $target, $params) },
            directives => (enforces(%live, FEAT-LIVE-STEER) || enforces(%live, FEAT-PAUSE)) ?? $!dir.live-channel !! Mailbox,
        );
        my $out = try $!adapter.run($ctx, $spec, $ctl);
        return (Outcome.new, 'adapter failed: ' ~ $!.message) if $!;
        return (Outcome.new, 'adapter returned nothing') without $out;
        ($out, Str);
    }

    method spec(Int $n, @instructions, Str $session-ref --> Spec) {
        my %limits = self.remaining;
        my $schema = try $!agent.output-schema($!procedure.defined ?? $!procedure<name> !! '');
        my $overlay = try $!agent.overlay($!adapter.name);
        Spec.new(:package(%!wp), :agent($!agent), :attempt($n), :workspace(%!wp<workspace><path>),
            :prompt(render-prompt(%!wp, $!agent, @!grants, @instructions, :policy($!policy-text))), :@instructions, :grants(@!grants),
            :%limits, :$session-ref, :output-schema($schema // ''), :procedure($!procedure), :captures(%!captures),
            :overlay($overlay // Str), :model((%!plan<model> // '').Str), :effort((%!plan<effort> // '').Str), |self.hook-spec);
    }

    #| What this attempt may still spend: the package limits less
    #| everything earlier attempts consumed.  Budgets are cumulative.
    method remaining(--> Hash) {
        my %l = load('Limits', %!wp<capabilities><limits>);
        if %l<maxUsd> > 0 { %l<maxUsd> = %l<maxUsd> - %!spent<usd>; %l<maxUsd> = 0.01 if %l<maxUsd> < 0.01 }
        if %l<maxTurns> > 0 { %l<maxTurns> = %l<maxTurns> - %!spent<turns>; %l<maxTurns> = 1 if %l<maxTurns> < 1 }
        %l;
    }

    method budget-exhausted(--> Str) {
        my %l = %!wp<capabilities><limits>;
        return sprintf('spend %.2f USD reached the limit of %.2f', %!spent<usd>, %l<maxUsd>) if %l<maxUsd> > 0 && %!spent<usd> >= %l<maxUsd>;
        return "{%!spent<turns>} turns reached the limit of {%l<maxTurns>}" if %l<maxTurns> > 0 && %!spent<turns> >= %l<maxTurns>;
        '';
    }

    #| Copy the final attempt's outcome onto the receipt, aligning the
    #| conditions to the contract by index and never reordering them.
    method fill(Outcome $out) {
        my %r := %!receipt;
        $!final-words = $out.final-words;
        %r<summary> = $out.summary if %r<summary> eq '';
        %r<blockedOn> = $out.blocked-on;
        my $n = @(%!wp<completion><conditions> // []).elems;
        my @conds;
        for ^$n -> $i {
            my $c = $i < $out.conditions.elems ?? $out.conditions[$i] !! Any;
            @conds.push($c.defined && ($c<met> || ($c<proof> // '') ne '')
                ?? doc('ConditionProof', met => so $c<met>, proof => $c<proof>)
                !! doc('ConditionProof', met => False, proof => 'no answer was reported for this condition'));
        }
        %r<conditions> = @conds;
        %r<evidence><denials> = [ |$out.denials ] if $out.denials;
        %r<evidence><errors> = [ |@(%r<evidence><errors> // []), |$out.errors ] if $out.errors || %r<evidence><errors>.defined;
        %r<evidence><noChange> = $out.status eq STATUS-NO-CHANGE;
        %r<evidence><externalAction> = $out.external-action if $out.external-action.defined;
        %r<evidence><approvalCheck> = $out.approval-check if $out.approval-check.defined;
        %r<evidence><toolCalls> = [ |@(%r<evidence><toolCalls> // []), |$out.tool-calls ] if $out.tool-calls;
        with self.tool-failures { %r<evidence><toolFailures> = [ |$_ ] if .elems }
        %r<evidence><proposal> = $out.proposal if $out.proposal.defined;
        if %!wp<workspace><kind> eq 'git' && %!wp<workspace><path> ne '' {
            my @files = ($!opts.list-changed-files // &git-changed-files)(%!wp<workspace><path>);
            %r<evidence><filesChanged> = [ |@files ] if @files;
        }
        if %r<status> eq STATUS-STOPPED {
            %r<stop> = $!dir.stop-info(&!now());
            %r<summary> = 'stopped: ' ~ %r<stop><reason> if %r<summary> eq '' || %r<summary> eq $out.summary;
            %r<uncertain> = [ |@(%r<uncertain> // []), 'an external action was recorded before the stop; it is not undone' ] if $out.external-action.defined;
        }
        %r<status> = STATUS-FAILED if %r<status> eq '';
    }

    #| Seal the receipt: directive summary, history, cost, digest.
    method finish(--> Hash) {
        my %r := %!receipt;
        $!dir.summarise(%r);
        %r<cost> = %!spent;
        # a run that ended before any attempt used no model, and says so:
        # a zero without a basis would be unknown, not free
        %r<cost><basis> = COST-NONE if (%r<cost><basis> // '') eq '' && !@(%r<attempts> // []);
        %r<endedAt> = &!now();
        %r<conditions> //= [];
        $!mu.protect({ %r<events><emitted> = $!event-seq });
        %r<events><coalesced> = $!opts.sink.coalesced if $!opts.sink ~~ CoalescingSink;
        my @history = $!mu.protect({ [ |@!history ] });
        my ($uri, $hdigest, $err) = write-history($!opts.history-dir, @history);
        %r<uncertain> = [ |@(%r<uncertain> // []), 'instruction history could not be written: ' ~ $err ] with $err;
        %r<instructionHistory> = doc('HistoryRef', uri => $uri, digest => $hdigest);
        %r<receiptDigest> = receipt-digest(%r);
        %r;
    }
}

sub end-reason(Outcome $out, Str $boundary, Cancel $ctx --> Str) {
    return 'paused' if $boundary eq BOUNDARY-PAUSE;
    return 'ended_for_instructions' if $boundary eq BOUNDARY-STEER;
    return 'timeout' if $ctx.deadline-exceeded;
    $out.end-reason eq '' ?? $out.status !! $out.end-reason;
}

sub add-cost(%a, %b --> Hash) is export {
    my $basis = %b<basis> // '';
    $basis = COST-UNREPORTED if $basis eq '';
    if (%a<basis> // '') ne '' && %a<basis> ne $basis { $basis = COST-MIXED }
    doc('Cost', usd => (%a<usd> // 0) + (%b<usd> // 0), turns => (%a<turns> // 0) + (%b<turns> // 0),
        tokens => (%a<tokens> // 0) + (%b<tokens> // 0), basis => $basis);
}

# ---------------------------------------------------------------- runner

#| Executes packages with a registry of adapters.
class Runner is export {
    has Registry $.adapters;

    #| A denial receipt for a package whose agent could not be loaded at
    #| all, so the caller still gets a receipt naming the package.
    method deny(%wp, Str $reason, @details, Options $opts --> Hash) {
        my $s = Session.make(self, %wp, Any, $opts);
        LEAVE $s.close;
        $s.emit(EVENT-STARTED, %( agent => %wp<agent><id>, trust => 'not loaded' ));
        $s.deny($reason, @details);
    }

    #| Execute %wp with $agent; always returns a receipt, even for a
    #| denial.  The receipt's digest is set; its signature is not.
    method run(Cancel $ctx, %wp, Loaded $agent, Options $opts --> Hash) {
        my $s = Session.make(self, %wp, $agent, $opts);
        LEAVE $s.close;
        $s.emit(EVENT-STARTED, %( agent => $agent.id, trust => $agent.label ));
        my ($reason, $details) = $s.check;
        return $s.deny($reason, @$details) if $reason ne '';
        my ($grants, $reason2, $details2) = $s.effective-grants;
        return $s.deny($reason2, @$details2) if $reason2 ne '';
        $s.grants = @$grants;
        my ($proc, $captures) = $s.match-procedure;
        $s.captures = %$captures;
        my $ad;
        with $proc {
            $ad = $!adapters.get('procedure');
            return $s.deny('no procedure executor is registered', []) without $ad;
            $s.plan = procedure-plan($ad);
            $s.emit(EVENT-PROCEDURE-SELECTED, %( procedure => $proc<name> ));
        }
        else {
            my @reqs = requirements($agent.manifest, %wp, @$grants);
            # The agent's curation asked; here the runtime answers.  The
            # harness must enforce the package first, and then be able to
            # run what was asked: never the other way about.
            my $want = $opts.want // Want.new;
            my ($chosen, $plan, $rejections) = pin-plan($!adapters, @reqs, $opts.policy<adapters> // {}, $opts.adapter, $want, $opts.models);
            without $chosen {
                my @details = @$rejections.map(*.Str);
                @details.push('required enforcement: ' ~ @reqs.map(*.feature).join(', ')) if @reqs;
                # the one step that most often puts it right: a shell with
                # the network shut needs a harness none installed is
                @details.push('to run it here: 321 trust network open grants the network to every run started here, --network open to one; shell.run never grants it by itself')
                    if @reqs.first(*.feature eq FEAT-NETWORK-DENY);
                return $s.deny('no installed adapter can enforce what this package requires', @details);
            }
            $ad = $chosen;
            $s.plan = %$plan;
            $s.emit(EVENT-ADAPTER-SELECTED, %( adapter => $ad.name, version => $plan<harnessVersion>,
                |(($plan<modelName> // '') ne '' ?? (model => $plan<modelName>) !! ()),
                |(($plan<effort> // '') ne '' ?? (effort => $plan<effort>) !! ()),
                |(($plan<profile> // '') ne '' ?? (profile => $plan<profile>) !! ()) ));
        }
        $s.adapter = $ad;
        $s.procedure = $proc;
        $s.receipt<harness><adapter> = $ad.name;
        $s.receipt<harness><version> = $ad.detect.version;
        $s.receipt<harness><procedure> = $proc<name> with $proc;
        $s.drive($ctx);
    }
}
