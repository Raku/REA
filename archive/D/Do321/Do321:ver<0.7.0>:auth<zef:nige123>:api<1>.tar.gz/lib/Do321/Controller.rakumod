# Copyright Nige Ltd. Author: Nigel Hamilton.
unit module Do321::Controller;

#| Controllers: things outside a harness that say what must hold while an
#| agent works, and that the runtime drives at the points a harness lets
#| it.  321 knows how each harness works (its adapters); a controller
#| knows what must remain true.  IZ4 is the first; an approval system or a
#| tracer would be another.
#|
#| The seam is deliberately small: discover whether the controller
#| governs a workspace, get the context to give the agent, and ask for a
#| verdict on a consequential action, on a change, and on the finished
#| run.  A controller answers in one vocabulary (pass, warn, block,
#| needs_human), and 'unavailable' for a question it could not answer, so
#| a gap is reported instead of being read as a pass.
#|
#| Nothing here decides what an invariant means.  The IZ4 driver runs the
#| iz4 command line and reads its result documents; the same commands
#| serve a native hook, a Git hook or CI with no 321 anywhere.

use Do321::JSON;
use Do321::Protocol;

constant RESULT-PASS        is export = 'pass';
constant RESULT-WARN        is export = 'warn';
constant RESULT-BLOCK       is export = 'block';
constant RESULT-NEEDS-HUMAN is export = 'needs_human';
constant RESULT-UNAVAILABLE is export = 'unavailable';

sub results(--> List) is export { (RESULT-PASS, RESULT-WARN, RESULT-BLOCK, RESULT-NEEDS-HUMAN, RESULT-UNAVAILABLE) }

constant POINT-CONTEXT is export = 'context';
constant POINT-ACTION  is export = 'action';
constant POINT-CHANGE  is export = 'change';
constant POINT-VERIFY  is export = 'verify';

#| A controller's answer at one point.
class Verdict is export {
    has Str $.point = '';
    has Str $.result = RESULT-UNAVAILABLE;
    has Str $.reason = '';
    has @.invariants;            # what the controller considered, as it names them
    has @.uncertain;             # lines for a receipt's uncertain list
    has Str $.proposal = '';     # for needs_human: what a person is asked to agree to
    has Str $.limits = '';       # what the controller says it did not establish
    has @.parts;                 # for a compound answer: { part, result, detail } each
    has $.evidence;              # the controller's own document, verbatim, or Any
    has Bool $.asked = True;     # False when nothing was owed, so the controller was never put the question

    #| Whether work must not simply continue past this answer.
    method stops(--> Bool) { $!result eq RESULT-BLOCK || $!result eq RESULT-NEEDS-HUMAN }
    #| Whether the controller looked for the report that changed files owe
    #| and found it: its 'report' part passed.  A turn that changed nothing
    #| owes none, and the part is then not checked.
    method report-in(--> Bool) { so @!parts.grep({ .<part> eq 'report' && .<result> eq RESULT-PASS }) }
    method ran(--> Bool) { $!result ne RESULT-UNAVAILABLE }
    #| The answer as a small record for a receipt.
    method record(--> Hash) {
        my %r = point => $!point, result => $!result;
        %r<reason> = $!reason if $!reason ne '';
        %r<invariants> = [ |@!invariants.map(*.Str) ] if @!invariants;
        %r;
    }
}

sub unavailable(Str $point, Str $reason --> Verdict) is export {
    Verdict.new(:$point, :result(RESULT-UNAVAILABLE), :$reason);
}

#| A consequential action in terms no harness owns: what is being done to
#| what.  Adapters translate their harness's native event into one.
class Action is export {
    has Str $.operation = '';    # write, edit, delete, execute, send, fetch, commit, ...
    has Str $.target = '';       # a path, a command name, an address, a resource
    has %.parameters;
    has Str $.resource = '';
    has Str $.repository = '';
    has Str $.recipient = '';
    has Str $.context = '';

    method document(--> Hash) {
        my %d = operation => $!operation, target => $!target;
        %d<parameters> = %!parameters if %!parameters;
        for <resource repository recipient context> -> $k {
            my $v = self."$k"();
            %d{$k} = $v if $v ne '';
        }
        %d;
    }
}

role Controller is export {
    method name(--> Str) { ... }
    #| Whether this controller governs a workspace.  An empty Hash means it
    #| does not apply.  Otherwise: subject (what governs, e.g. a file),
    #| digest (its content identity), available (Bool: can it be driven
    #| here?) and reason (why not, when it cannot).
    method discover(Str $workspace --> Hash) { ... }
    #| The context to give the agent, as (text, error or Str).
    method context(Str $workspace --> List) { ... }
    #| Which of the four points this controller can answer here.
    method answers(--> List) { () }
    #| The harness controls it wants to be driven from, strongest first; an
    #| adapter wires the ones its harness has.
    method wants(--> List) { () }
    method check-action(Str $workspace, Action $action --> Verdict) { unavailable(POINT-ACTION, "{self.name} offers no action check") }
    method check-change(Str $workspace --> Verdict) { unavailable(POINT-CHANGE, "{self.name} offers no change check") }
    #| %run may carry summary: the agent's last words, as text.
    method verify(Str $workspace, %run --> Verdict) { unavailable(POINT-VERIFY, "{self.name} offers no verification") }
}

# --------------------------------------------------------------------- IZ4

#| The iz4 executable: DO_321_IZ4 when that is set (and nothing else, so a
#| caller can pin or withhold it), else `iz4` on PATH; '' when absent.
sub iz4-binary(--> Str) is export {
    with %*ENV<DO_321_IZ4> { return ($_.IO.x ?? $_ !! '') if $_ ne '' }
    my $found = on-path('iz4');
    $found.defined ?? $found.Str !! '';
}

#| How long a controller is given to answer, in seconds, by the kind of
#| question.  A question about one action or the context is quick; a
#| check of the change or the finished work may run the project's tests.
#| DO_321_CONTROLLER_TIMEOUT overrides every one of them.
sub controller-timeout(Str $point --> Int) is export {
    with %*ENV<DO_321_CONTROLLER_TIMEOUT> { return .Int if $_ ~~ /^ \d+ $/ && .Int > 0 }
    $point eq POINT-CHANGE || $point eq POINT-VERIFY ?? 900 !! 30;
}

#| The command that puts a time limit on another, or an empty list where
#| this system has none: `timeout` where it exists, else Perl's alarm.
sub time-limited(Int $seconds --> List) {
    with on-path('timeout') { return (.Str, $seconds.Str) }
    with on-path('perl')    { return (.Str, '-e', 'alarm shift; exec @ARGV or exit 127', $seconds.Str) }
    ();
}

#| Run a command in a directory under a time limit.  Returns (exit code,
#| stdout, stderr, why): why is '' when the command ran to its own end, and
#| otherwise says how it did not (could not start, timed out, was killed).
#| A command that did not run to its own end has no exit code worth
#| reading, so the code is -1 whenever why is not ''.
sub run-in(Str $dir, @argv, Str :$in, Int :$seconds = 30 --> List) {
    my @limit = time-limited($seconds);
    my $p = try run |@limit, |@argv, :cwd($dir), :in, :out, :err, :env(%*ENV);
    return (-1, '', '', "could not start: {$!.message.lines.head // ''}") if $!;
    $p.in.print($in) with $in;
    # Raku++ returns the Proc from closing stdin; sinking an unsuccessful
    # one throws, and the exit code is what we want, read below.
    try { $p.in.close; Nil };
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    my $signal = (try $p.signal) // 0;
    return (-1, $out, $err, "timed out after {$seconds}s") if @limit && ($p.exitcode == 124 || $signal == 14);
    return (-1, $out, $err, "was killed by signal $signal") if $signal != 0;
    return (-1, $out, $err, 'could not start: not found') if $p.exitcode == 127 && $out eq '';
    ($p.exitcode, $out, $err, '');
}

#| The exit code a result must come with (iz4's contract: pass and warn 0,
#| needs_human 2, block 3).  Exit 1 is "the check could not run".
sub result-exit(Str $result --> Int) is export {
    $result eq RESULT-NEEDS-HUMAN ?? 2 !! $result eq RESULT-BLOCK ?? 3 !! 0;
}

#| The IZ4 driver.  It calls iz4's machine interface and nothing else:
#|
#|     iz4 discover --json          does an IZ4 govern this place?
#|     iz4 context --json           what to tell the agent
#|     iz4 check action --json      one consequential action, on stdin
#|     iz4 check change --json      the change in the working directory
#|     iz4 verify --json            the finished run
#|
#| Each check answers with an iz4-check document: result, reason,
#| invariants_considered, evidence, proposed_invariant_change, limits.
#| Which invariants exist, what they mean and what a change to one is are
#| iz4's business; an iz4 too old to offer a command makes that point
#| unavailable, which is reported, never passed.
class IZ4 does Controller is export {
    has Str $.bin = '';              # '' means DO_321_IZ4, else iz4 on PATH

    method name(--> Str) { 'iz4' }
    method binary(--> Str) { $!bin ne '' ?? $!bin !! iz4-binary() }
    method answers(--> List) { (POINT-CONTEXT, POINT-ACTION, POINT-CHANGE, POINT-VERIFY) }
    #| Context at the start, every write and shell command before it runs,
    #| and the end of the work.
    method wants(--> List) { (CTRL-AUTHORITATIVE-CONTEXT, CTRL-FILESYSTEM-GUARD, CTRL-SHELL-GUARD, CTRL-POST-RUN) }

    method discover(Str $workspace --> Hash) {
        return %() if $workspace eq '' || !$workspace.IO.d;
        my $bin = self.binary;
        if $bin eq '' {
            # Without iz4 only the file's presence can be seen; say that it
            # is there and cannot be driven.
            my $file = find-iz4-file($workspace);
            return %() without $file;
            return %( subject => $file.Str, digest => '', available => False, reason => 'iz4 is not installed' );
        }
        my ($code, $out, $err, $why) = run-in($workspace, [$bin, 'discover', '--json'], :seconds(controller-timeout(POINT-CONTEXT)));
        my $doc = try parse-json($out);
        unless $why eq '' && $code == 0 && $doc ~~ Associative && ($doc<schema> // '') ~~ Str && $doc<schema>.starts-with('iz4-discover/') {
            my $file = find-iz4-file($workspace);
            return %() without $file;
            return %( subject => $file.Str, digest => '', available => False,
                      reason => $why ne '' ?? "iz4 discover $why"
                          !! "this iz4 offers no machine interface (iz4 discover: {($err.trim.lines.head // "exit $code")}); iz4 0.15.0 or later has it" );
        }
        return %() unless $doc<present>;
        return %( subject => $doc<file>.Str, digest => 'sha256:' ~ $doc<sha256>.Str, available => False,
                  reason => 'the IZ4 is invalid: ' ~ @($doc<errors> // []).join('; ') ) unless $doc<valid>;
        %( subject => $doc<file>.Str, digest => 'sha256:' ~ $doc<sha256>.Str, available => True, reason => '',
           invariants => [ |@($doc<invariants> // []).map({ identity-of($_) }) ] );
    }

    #| Can this iz4 be driven at all, wherever it is asked?  (drivable,
    #| reason, version).  Asked of the command itself, never inferred from
    #| a file being on PATH: an iz4 with no machine interface is installed
    #| and is not drivable.
    method probe(--> Hash) {
        my $bin = self.binary;
        return %( binary => '', drivable => False, reason => 'iz4 is not installed', tool => '' ) if $bin eq '';
        my ($code, $out, $err, $why) = run-in($*TMPDIR.Str, [$bin, 'discover', '--json'], :seconds(controller-timeout(POINT-CONTEXT)));
        my $doc = try parse-json($out);
        my $ok = $why eq '' && $code == 0 && $doc ~~ Associative && ($doc<schema> // '') ~~ Str && $doc<schema>.starts-with('iz4-discover/');
        %( binary => $bin, drivable => $ok, tool => ($ok ?? ($doc<tool> // '').Str !! ''),
           reason => $ok ?? '' !! $why ne '' ?? "iz4 discover $why"
                         !! "this iz4 offers no machine interface (iz4 discover: {($err.trim.lines.head // "exit $code")}); iz4 0.15.0 or later has it" );
    }

    method context(Str $workspace --> List) {
        my ($code, $out, $err, $why) = run-in($workspace, [self.binary, 'context', '--json'], :seconds(controller-timeout(POINT-CONTEXT)));
        return ('', "iz4 context $why") if $why ne '';
        my $doc = try parse-json($out);
        return ('', ($err.trim || "iz4 context exited $code")) unless $code == 0 && $doc ~~ Associative && ($doc<text> // '') ~~ Str;
        ($doc<text>, Str);
    }

    method check-action(Str $workspace, Action $action --> Verdict) {
        self!check(POINT-ACTION, $workspace, ['check', 'action', '--json'], :in(encode-json($action.document)));
    }
    method check-change(Str $workspace --> Verdict) {
        self!check(POINT-CHANGE, $workspace, ['check', 'change', '--worktree', '--json']);
    }
    #| The working directory's tree now, as iz4 names it (evidence.gate.
    #| candidate of a change check that runs no tests), or '' when iz4 does
    #| not say.  The post_run control stores it to measure the next turn
    #| from here rather than from HEAD, so a tree that was already dirty
    #| when a turn began is not laid at the turn's door.
    method baseline(Str $workspace --> Str) {
        my $bin = self.binary;
        return '' if $bin eq '';
        my @args = ['check', 'change', '--worktree', '--json', '--/checks'];
        my ($code, $out, $err, $why) = run-in($workspace, [$bin, |@args], :seconds(controller-timeout(POINT-CHANGE)));
        return '' if $why ne '';
        # whatever the result and exit code (an iz4 may call a check that
        # checked nothing unassessed), the document is read for the tree
        # alone: this is never a verdict
        my $doc = try parse-json($out);
        tree-of(Verdict.new(:point(POINT-CHANGE), :evidence($doc)));
    }
    #| %run<summary> is the agent's last words; %run<base> the tree the
    #| turn began from (--base=TREE), when one is known.
    method verify(Str $workspace, %run --> Verdict) {
        my @args = 'verify', '--worktree', '--json';
        @args.push('--base=' ~ %run<base>) if (%run<base> // '') ne '';
        my $file;
        if %run<summary>:exists {
            $file = $*TMPDIR.add("321-summary-{$*PID}-{(^1_000_000).pick}.txt");
            $file.spurt((%run<summary> // '').Str);
            @args.push('--summary=' ~ $file.Str);
        }
        LEAVE { try $file.unlink if $file.defined }
        self!check(POINT-VERIFY, $workspace, @args);
    }

    method !check(Str $point, Str $workspace, @args, Str :$in --> Verdict) {
        my $bin = self.binary;
        return unavailable($point, 'iz4 is not installed') if $bin eq '';
        my $name = "iz4 {@args.head($point eq POINT-VERIFY ?? 1 !! 2).join(' ')}";
        my ($code, $out, $err, $why) = run-in($workspace, [$bin, |@args], :$in, :seconds(controller-timeout($point)));
        return unavailable($point, "$name $why") if $why ne '';
        # Exit 1 is iz4 saying the check could not run, whatever it printed.
        return unavailable($point, "$name could not run (exit 1): {$err.trim.lines.head // 'no reason given'}") if $code == 1;
        my $v = verdict-from($point, $out, "$name (exit $code): {$err.trim.lines.head // 'no result document'}");
        # A result is believed only with the exit code that belongs to it: a
        # document saying pass beside a failing exit is not a pass.
        return unavailable($point, "$name answered \"{$v.result}\" with exit $code, which do not agree; treated as not run")
            if $v.ran && $code != result-exit($v.result);
        $v;
    }
}

#| The tree a check measured as its candidate, from iz4's own document
#| (evidence.gate.candidate), or '' when it gave none.
sub tree-of(Verdict $v --> Str) is export {
    my $doc = $v.evidence;
    return '' unless $doc ~~ Associative;
    my $tree = (($doc<evidence> // {})<gate> // {})<candidate> // '';
    $tree ~~ Str && $tree ~~ / ^ <[0..9a..f]> ** 40 $ / ?? $tree !! '';
}

#| How iz4 identifies an invariant in one of its documents, as it gave
#| it: 'id' (a name, since iz4-discover/2 and iz4-check/2), or 'number'
#| from the documents before that.  An opaque string here.  321 passes it
#| on and shows it; it never reads meaning into its shape, compares its
#| parts, orders by it or builds one.
sub identity-of($entry --> Str) {
    return '' unless $entry ~~ Associative;
    ($entry<id> // $entry<number> // '').Str;
}

#| The same, as a person is shown it: the identity itself, or
#| 'Invariant N' for a document that still gives a number.
sub identity-label($entry --> Str) {
    $entry ~~ Associative && ($entry<id> // '').Str ne '' ?? $entry<id>.Str !! "Invariant {identity-of($entry)}";
}

#| A Verdict from an iz4-check document.  Anything that is not one is
#| unavailable: an old iz4, an error, a crash.
sub verdict-from(Str $point, Str $out, Str $otherwise --> Verdict) is export {
    my $doc = try parse-json($out);
    return unavailable($point, $otherwise) unless $doc ~~ Associative && ($doc<schema> // '') ~~ Str && $doc<schema>.starts-with('iz4-check/');
    my $result = ($doc<result> // '').Str;
    return unavailable($point, "iz4 answered an unknown result \"$result\"")
        unless is-in($result, [RESULT-PASS, RESULT-WARN, RESULT-BLOCK, RESULT-NEEDS-HUMAN]);
    my $reason = ($doc<reason> // '').Str;
    # what the agent said may be broken, in its own line: iz4 0.41 names
    # the list broken, an older iz4 called it uncertain.  Either way it
    # goes on the receipt's uncertain list, never claimed settled
    my $rep = ($doc<evidence> // {})<report> // {};
    $rep = {} unless $rep ~~ Associative;
    my @uncertain = (|@($rep<broken> // []), |@($rep<uncertain> // [])).grep(Str).map({ "IZ4 $_" });
    @uncertain.push("IZ4: $reason") if $result eq RESULT-WARN || $result eq RESULT-BLOCK;
    my $proposal = '';
    with $doc<proposed_invariant_change> -> $p {
        if $p ~~ Associative {
            my @lines = 'IZ4: ' ~ $reason;
            @lines.push('  ' ~ $p<summary>) if ($p<summary> // '') ne '';
            for @($p<changes> // []) -> $c {
                next unless $c ~~ Associative;
                @lines.push('  - ' ~ ($c<kind> // 'change') ~ (identity-of($c) ne '' ?? ' ' ~ identity-label($c) !! '')
                    ~ (($c<text> // $c<after> // '') ne '' ?? ": {($c<text> // $c<after>).Str.substr(0, 160)}" !! ''));
            }
            @lines.push('  to agree, a person runs: ' ~ $p<agree_with>) if ($p<agree_with> // '') ne '';
            @lines.push('  proposal digest: ' ~ $p<proposal_digest>) if ($p<proposal_digest> // '') ne '';
            $proposal = @lines.join("\n");
        }
    }
    my @parts = @((($doc<evidence> // {})<parts>) // []).grep(Associative).map({
        %( part => ($_<part> // '').Str, result => ($_<result> // '').Str, detail => ($_<detail> // '').Str ) });
    Verdict.new(:$point, :$result, :$reason, :invariants(@($doc<invariants_considered> // []).map(*.Str)),
        :@uncertain, :$proposal, :limits(($doc<limits> // '').Str), :@parts, :evidence($doc));
}

#| The IZ4 file above a directory, for the one case where iz4 itself
#| cannot be asked (it is missing, or too old to answer `discover`).
#| Presence only, so that a status can say "an IZ4 is here and is not
#| being driven" instead of staying silent: the runtime never reads what
#| the file says, and whenever iz4 can be asked, iz4 is what answers.
sub find-iz4-file(Str $workspace --> IO::Path) is export {
    return IO::Path if $workspace eq '';
    my $dir = $workspace.IO;
    loop {
        my $f = $dir.add('IZ4');
        return $f if $f.f;
        last if $dir.add('.git').e || $dir.parent.Str eq $dir.Str;
        $dir = $dir.parent;
    }
    IO::Path;
}

#| What a harness's status line calls 321 for: '321 hook claude_code iz4
#| status_line'.  Not a control: it checks nothing and refuses nothing.
constant STATUS-LINE is export = 'status_line';

#| The line iz4 left after its last verify of a workspace's tree, ready to
#| show as it stands (iz4-last/1, in the Git directory's iz4/last.json), or
#| '' where there is none.  The words are iz4's: the status line and
#| Mission Control show them unchanged, so every harness says the same.
#| Read often (a status line runs every few seconds), so it starts no
#| process and never throws.
sub iz4-last-line(Str $workspace --> Str) is export {
    return '' if $workspace eq '';
    my $dir = $workspace.IO;
    loop {
        my $g = $dir.add('.git');
        if $g.d || $g.f {
            my $git = $g;
            # a worktree's .git is a file naming its own Git directory
            if $g.f {
                my $to = (try $g.slurp) // '';
                return '' unless $to ~~ /^ 'gitdir:' \s* (\N+)/;
                $git = ~$0.trim.IO;
                $git = $dir.add(~$0.trim) if $git.is-relative;
            }
            my $doc = try parse-json($git.add('iz4').add('last.json').slurp);
            return '' unless $doc ~~ Associative && ($doc<schema> // '') eq 'iz4-last/1' && ($doc<line> // '') ~~ Str;
            my $line = $doc<line>.lines.head // '';
            # a notice beside iz4's words, never in them, and never a hold
            my $unseen = ($doc<unseen> // 0).Str;
            return $line ne '' && $unseen ~~ / ^ \d+ $ / && $unseen.Int > 0 ?? "$line · $unseen unseen" !! $line;
        }
        last if $dir.parent.Str eq $dir.Str;
        $dir = $dir.parent;
    }
    '';
}

#| The controllers the runtime drives by default.
sub default-controllers(--> List) is export { (IZ4.new,) }

sub controller-named(Str $name, @controllers = default-controllers() --> Controller) is export {
    @controllers.first(*.name eq $name) // Controller;
}
