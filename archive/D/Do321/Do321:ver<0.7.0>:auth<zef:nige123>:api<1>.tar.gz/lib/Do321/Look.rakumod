unit module Do321::Look;

use Do321::Palette;

#| How 321 speaks to a person: the one place every command's words pass
#| through on their way to a terminal.
#|
#| The words are the same everywhere.  Into a pipe, a file or a test
#| they arrive untouched, byte for byte, so a tool reads what it always
#| read.  On a terminal they are dressed: the icon before a header, the
#| names a person cites in bold, comments dimmed, a tick green, a cross
#| red, a question amber, and a row of air above and below, because a
#| person reading a screen is in the middle of something else and holds
#| only a few things at once.
#|
#| NO_COLOR and TERM=dumb turn the dress off; DO_321_COLOR=0 or 1 says
#| outright, and 1 keeps it into a pipe.

# ------------------------------------------------------------ the icon

#| The 321 mark in text: the 123 mark with a square eye, arrows either
#| side.  Its plain twin stands in wherever the locale is not UTF-8.
#| Windows Terminal is UTF-8 without saying so in LANG.
constant ICON       is export = '❮▣❯';
constant ICON-PLAIN is export = '<#>';

sub utf8-terminal(--> Bool) is export {
    so ((%*ENV<LC_ALL> // %*ENV<LC_CTYPE> // %*ENV<LANG> // '') ~~ /:i 'utf' '-'? '8'/) || (%*ENV<WT_SESSION> // '') ne '';
}

sub icon(--> Str) is export { utf8-terminal() ?? ICON !! ICON-PLAIN }

#| The marks a result carries, each a different shape so it reads without
#| colour, each with a plain twin.
constant %GLYPH = yes => ('✓', '+'), no => ('✗', 'x'), unknown => ('?', '?'), dot => ('·', '-'), note => ('›', '>');
sub glyph(Str $which --> Str) is export { %GLYPH{$which}[utf8-terminal() ?? 0 !! 1] }

#| The mark a run's last word carries: a tick for done, a cross for what
#| did not happen, a question for what waits on a person, a dot for a
#| run the person stopped.
sub status-glyph(Str $status --> Str) is export {
    given $status {
        when 'completed' | 'no_change' { glyph('yes') }
        when 'failed' | 'denied'       { glyph('no') }
        when 'blocked'                 { glyph('unknown') }
        default                        { glyph('dot') }
    }
}

# ------------------------------------------------------------ on or off

#| The variables were X321_* and DO321_* before 0.4.2.  An old spelling
#| still works: it is read into the new name when the new one is unset.
#| Called before anything reads the environment.
sub adopt-old-names() is export {
    for %*ENV.keys.grep({ .starts-with('X321_') || .starts-with('DO321_') }) -> $old {
        my $new = $old.subst(/ ^ 'X321_' | ^ 'DO321_' /, 'DO_321_');
        %*ENV{$new} = %*ENV{$old} unless %*ENV{$new}:exists;
    }
}

#| Whether to dress output for a person: only on a terminal, never into a
#| pipe, a file or a test.  NO_COLOR and TERM=dumb turn it off;
#| DO_321_COLOR=1 or 0 says outright.
sub pretty-on(--> Bool) is export {
    return %*ENV<DO_321_COLOR> eq '1' if (%*ENV<DO_321_COLOR> // '') eq any('0', '1');
    return False if (%*ENV<NO_COLOR> // '') ne '' || (%*ENV<TERM> // '') eq 'dumb';
    so $*OUT.t;
}

#| The same, for what goes to standard error: a run's header is said
#| there, so a pipe on standard output gets the run alone.
sub pretty-on-err(--> Bool) is export {
    return %*ENV<DO_321_COLOR> eq '1' if (%*ENV<DO_321_COLOR> // '') eq any('0', '1');
    return False if (%*ENV<NO_COLOR> // '') ne '' || (%*ENV<TERM> // '') eq 'dumb';
    so $*ERR.t;
}

#| A document for a machine (--json) is never dressed, terminal or not.
my Bool $DRESS = True;
sub dress(Bool $on) is export { $DRESS = $on }

# --------------------------------------------------------------- colour

#| The family's colours (Do321::Palette), as this terminal can show
#| them; ink stays the terminal's own.
my sub blue(--> Str)  { colour-code('blue') }
my sub green(--> Str) { colour-code('green') }
my sub amber(--> Str) { colour-code('amber') }
my sub red(--> Str)   { colour-code('red') }
my constant BOLD  = "\e[1m";
my constant DIM   = "\e[2m";
my constant OFF   = "\e[0m";

#| The first words a person types: the command words, bold wherever a
#| line cites one as '321 <word>'.
my constant @COMMANDS = <agents status receipt key iz4 doctor trust packages harness run hook hooks help version>;

#| Names a person cites, bold within a line: a work package or receipt id
#| (a ULID), a harness, and '321 <command>'.
my @HARNESSES = <claude_code>;
sub emphasise-harnesses(@names) is export { @HARNESSES = @names.grep(* ne 'fake' | 'procedure').List }

my sub emphasise(Str $s --> Str) {
    $s.subst(/ <!after <[\w / : . \-]>> (<[0..9 A..H J..K M..N P..T V..Z]> ** 26) <!before <[\w /]>> /, { "{BOLD}{$0}{OFF}" }, :g)
      .subst(/ <!after <[\w / . \-]>> ('321 ' @COMMANDS) <!before <[\w \-]>> /, { "{BOLD}{$0}{OFF}" }, :g)
      .subst(/ <!after <[\w / . \-]>> (@HARNESSES) <!before <[\w \-]>> /, { "{BOLD}{$0}{OFF}" }, :g)
}

#| The words a run ends on, and the ones a check ends on: said in lower
#| case like every other word here, bold after their mark so the eye
#| lands on them.  Nothing shouts.
my constant @LAST-WORDS = <completed no_change blocked failed denied stopped valid invalid verified>;

#| After a mark: a run's last word in bold, the rest as it is.
my sub verdict(Str $s --> Str) {
    $s ~~ / ^ (\h) (@LAST-WORDS | 'no change') (':' .*)? $ /
        ?? "{$0}{BOLD}{$1}{OFF}{emphasise(~($2 // ''))}"
        !! emphasise($s)
}

#| Text as a person sees it on a terminal.  Nothing is added or removed
#| but colour; strip the escapes and every word is as it was.  With :!on
#| the text comes back untouched.
sub pretty(Str $text, Bool :$on = pretty-on() --> Str) is export {
    return $text unless $on && $DRESS;
    my $b = blue();
    $text.lines(:!chomp).map(-> $line {
        my $nl = $line.ends-with("\n") ?? "\n" !! '';
        my $l = $line.chomp;
        # a document for a machine, on a terminal by chance: left alone
        if $l ~~ / ^ \h* <[{}\[\]"]> / { }
        # every header: the icon, then '321', the command and the colon in bold
        elsif $l ~~ / ^ ([ '❮▣❯' | '<#>' ]) (' 321' [' ' <-[:\s]>+]* ':') (.*) $ / { $l = "{$b}{$0}{OFF}{BOLD}{$1}{OFF}{emphasise(~$2)}" }
        # a block's title: the icon, then bold words
        elsif $l ~~ / ^ ([ '❮▣❯' | '<#>' ]) ' ' (.*) $ / { $l = "{$b}{$0}{OFF} {BOLD}{$1}{OFF}" }
        # the quiet line under a title, a byline among them: furniture, so
        # it recedes
        elsif $l ~~ / ^ ('    ' \S .* \h ['·' | '-'] \h .*) $ / { $l = "{DIM}{$0}{OFF}" }
        # what comes next: the person's focus, so the family blue
        elsif $l ~~ / ^ ('next:' | 'then:') (.*) $ / { $l = "{$b}{BOLD}{$0}{OFF}{emphasise(~$1)}" }
        # something that did not happen, said by 321 itself: red, whole
        elsif $l ~~ / ^ '321' [\h <-[:\s]>+]? ':' \h / { $l = "{red()}{$l}{OFF}" }
        # comments, dimmed
        elsif $l ~~ / ^ \h* '#' / { $l = "{DIM}{$l}{OFF}" }
        # the marks; a run's last word after one is bold
        elsif $l ~~ / ^ (\h*) ('✓' | '+') (\h .*) $ / { $l = "{$0}{green()}{$1}{OFF}{verdict(~$2)}" }
        elsif $l ~~ / ^ (\h*) ('✗' | 'x') (\h .*) $ / { $l = "{$0}{red()}{$1}{$2}{OFF}" }
        elsif $l ~~ / ^ (\h*) '?' (\h .*) $ / { $l = "{$0}{amber()}?{OFF}{verdict(~$1)}" }
        elsif $l ~~ / ^ (\h*) ('·' | '-') (\h 'stopped' .*) $ / { $l = "{$0}{$1}{verdict(~$2)}" }
        # the line that says everything holds
        elsif $l ~~ / ^ ('All ' \w+) (':' .*)? $ / { $l = "{BOLD}{$0}{OFF}{emphasise(~($1 // ''))}" }
        # a command a person can type, on its own line or heading a
        # column: what they do next, so the family blue
        elsif $l ~~ / ^ (\h+ [ \S+ '=' \S* \h+ ]* '321' [\h <-[\h]>+]+?) (\h ** 2..* .*)? $ / { $l = "{$b}{$0}{OFF}{emphasise(~($1 // ''))}" }
        # a labelled row: the label in bold
        elsif $l ~~ / ^ (<[a..z A..Z]> <[a..z A..Z \-]> ** 0..12 [\h <[a..z A..Z]>+]? ':') (\h+ .*) $ / { $l = "{BOLD}{$0}{OFF}{emphasise(~$1)}" }
        else { $l = emphasise($l) }
        $l ~ $nl;
    }).join;
}

# ------------------------------------------------------------------ air

#| A row of air above and below everything 321 says to a person: the
#| first write is preceded by a blank line unless it brings its own, and
#| the last is followed by one.  Only on a terminal (or DO_321_COLOR=1,
#| which asks for the terminal's dress anywhere); a pipe gets the words
#| alone.  Every line is dressed on its way through, so no command has
#| to remember.
class Air is IO::Handle {
    has IO::Handle $.inner is required;
    has Bool $.air = True;          # standard error is dressed, never aired
    has Bool $!started = False;
    has Str  $!tail = '';
    method WRITE(Blob:D $data --> True) {
        my $s = $data.decode;
        unless $!started { $!started = True; $!inner.print("\n") if $!air && !$s.starts-with("\n") }
        $!tail = ($!tail ~ $s).substr(* - 2 max 0);
        $!inner.print(pretty($s, :on));
        True;
    }
    #| Something else has already opened the screen (a header on standard
    #| error): the first write here adds no air of its own.
    method begun() { $!started = True }
    method settle() { $!inner.print("\n") if $!air && $!started && !$!tail.ends-with("\n\n"); $!inner.flush }
    method flush() { $!inner.flush }
    method t() { $!inner.t }
}

sub air-on(--> Bool) is export {
    return True  if (%*ENV<DO_321_COLOR> // '') eq '1';
    return False if (%*ENV<DO_321_COLOR> // '') eq '0';
    $*OUT.t && (%*ENV<TERM> // '') ne 'dumb';
}

#| --plain anywhere on the command line is DO_321_COLOR=0 said once: the
#| pipe form on a terminal.  Read before the air goes in, since the air
#| is the first thing that looks.
sub adopt-plain-flag(@args) is export {
    %*ENV<DO_321_COLOR> = '0' if @args.first('--plain' | '--brief').defined || brief-on();
}

#| Pipeline mode for a whole session: DO_321_BRIEF=1 is --brief on every
#| command, so a program that calls 321 sets it once and never meets a
#| screen.
sub brief-on(--> Bool) is export { (%*ENV<DO_321_BRIEF> // '') eq '1' }

#| DO_321_PROGRESS=1: a pipe that wants a run's events as lines, one per
#| event, where a terminal would have shown one live line and wiped it.
sub progress-on(--> Bool) is export { (%*ENV<DO_321_PROGRESS> // '') eq '1' }

#| One live line under a title while something runs: rewritten in place,
#| never left on the screen.  wipe-live() clears it before the next thing
#| is said.
sub live-line($w, Str $text) is export { $w.print("\r\e[2K" ~ $text); $w.flush }
sub wipe-live($w) is export { $w.print("\r\e[2K"); $w.flush }

my $air;
#| Installed once at startup, before anything is written.
sub install-air() is export {
    adopt-old-names();
    adopt-plain-flag(@*ARGS);
    # what 321 says went wrong, and the way on, wear the same dress on
    # standard error: red for what did not happen, blue for what to do
    if pretty-on-err() {
        my $e = Air.new(:inner($*ERR), :!air);
        $e.encoding('utf8');
        $*ERR = $e;
    }
    return unless air-on();
    $air = Air.new(:inner($*OUT));
    $air.encoding('utf8');
    $*OUT = $air;
}
sub settle-air() is export { .settle with $air }
sub air-begun() is export { .begun with $air }

# --------------------------------------------------------------- shapes

#| One header shape everywhere: the icon, '321', the command, a summary.
#| One header shape everywhere: the icon, '321', the command, a summary.
#| A command with nothing worth summarising passes none, and the header is
#| the command alone: a summary that only repeats a row below it costs a
#| person a line to read and tells them nothing.
sub header(Str $name, Str $summary = '' --> Str) is export {
    $summary eq '' ?? "{icon()} 321 $name" !! "{icon()} 321 $name: $summary";
}

#| A labelled row as the status screen draws it: the label in a column
#| of thirteen, the value beside it, wrapped so a long one continues
#| under itself and never runs off a narrow terminal.
sub row-lines(Str $label, Str $value --> List) is export {
    my @v = wrap-at($value, 64);
    @v = ('',) unless @v;
    (sprintf('%-13s %s', $label, @v[0]), |@v[1..*].map({ (' ' x 14) ~ $_ })).List;
}

#| Money as a person reads it.  A cost under a cent is said to be one: it
#| was not nothing, and $0.00 would read as free.
sub usd-words($usd --> Str) is export {
    my $u = ($usd // 0).Numeric;
    $u > 0 && $u < 0.005 ?? 'under $0.01' !! sprintf('$%.2f', $u);
}

#| A count that reads like English: one turn, not 1 turns.
sub many-of(Int $n, Str $word --> Str) is export { "$n $word" ~ ($n == 1 ?? '' !! 's') }

#| A run's last word as a person reads it: the receipt's status, in lower
#| case, with its underscore gone (no change, not NO_CHANGE).
sub last-word(Str $status --> Str) is export { $status.lc.subst('_', ' ', :g) }

#| One record per line for a tool (--brief): the fields tab-separated, in
#| the order given, nothing else on the line.  A tab never appears inside
#| a field, so cut, awk and sort read it as it is.
sub brief-line(*@fields --> Str) is export { @fields.map({ .Str.subst(/<[\t\n]>/, ' ', :g) }).join("\t") }

#| The line that closes a clean screen: one warm, true sentence, said
#| last.  'All' opens it so the dress can find it; what follows is only
#| what was established.
sub all-well(Str $word, Str $rest --> Str) is export { "All $word: $rest" }

#| The quiet line under a title: what a person needs only sometimes -
#| which build this is, which machine - said where it can be found rather
#| than in the title, where it would be read every time and wanted
#| rarely.  Two parts, so the dress can tell it from a wrapped line.
sub subtitle(Str $left, Str $right --> Str) is export { "    $left {glyph('dot')} $right" }

#| A byline is that line naming who answered, and the identity they
#| answered as: a page says who wrote it, a run says who did it.
sub byline(Str $who, Str $id --> Str) is export { subtitle("by $who", $id) }

sub wrap-at(Str $text, Int $width --> List) is export {
    my @lines; my $line = '';
    for $text.words -> $w {
        if $line eq '' { $line = $w }
        elsif $line.chars + 1 + $w.chars <= $width { $line ~= ' ' ~ $w }
        else { @lines.push($line); $line = $w }
    }
    @lines.push($line) if $line ne '';
    @lines.List;
}

#| A short block a person can take in at a glance: a title under the
#| icon, a sentence or two wrapped at 72, a blank line, then the commands
#| that come next with why.  The shape anything a person reads after
#| acting answers in, so nothing is a wall.
sub calm(Str $title, *@body, :@next --> Str) is export {
    my @l = "{icon()} $title";
    if @body { @l.push(''); @l.push("  $_") for wrap-at(@body.join(' '), 72) }
    if @next { @l.push(''); @l.push(sprintf('  321 %-18s %s', .key, .value)) for @next }
    @l.join("\n") ~ "\n";
}

#| What comes next, in one breath: a line of advice and, beneath it, a
#| command that can be typed as it stands.
sub next-text(Str $advice, Str $example --> Str) is export {
    "next:  $advice\n       $example";
}

#| The numbered next steps that clear what a command found, and the one
#| that confirms it.
sub say-next(@steps, Str :$then --> Str) is export {
    my @l = 'next:';
    my $n = 0;
    @l.push("  {++$n}. $_") for @steps;
    @l.push("  then: $then again") with $then;
    @l.join("\n") ~ "\n";
}
