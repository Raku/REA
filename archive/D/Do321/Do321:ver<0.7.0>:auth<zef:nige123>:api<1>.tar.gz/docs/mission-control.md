# Mission Control

Mission Control runs on Linux for now. On macOS and Windows the rest of 321 works, and `321` on a terminal shows the help.

Runs that outlive the terminal, watched and steered from one screen.
Processes do the work. Files carry the messages. Mission Control presents the state.

Mission Control is part of `321`: its words are `321`'s own, in the
registry that help, typo suggestions and shell completion all read.

| Command | What it does |
|---|---|
| `321 tui`, or `321` alone | opens Mission Control (`321` alone in a pipe prints help, as before), only when stdin and stdout are terminals, without `--json` or `--brief` or `DO_321_BRIEF=1`, and with `TERM` not `dumb`; with `--brief` or `--json` it lists the runs as records instead |
| `321 start <agent> <request...>` | starts a run that keeps going when the terminal closes |
| `321 attach <run>` | opens Mission Control on one run; in a pipe, prints its phase |
| `321 stop <run>` | asks the run to stop through its inbox and waits for its own evidence |
| `321 stop <run> --force` | stops a run whose host is not answering, by process identity |
| `321 start --harness <name> --isolate <agent> <request...>` | the same, on the harness named, in a worktree of its own |
| `321 start --package <file> [--workspace <dir>] [--continue <receipt>]` | hosts a work package something else issued, as it stands: the run id is its packageId; a continuation gets an id of its own |
| `321 restart <run>` | a new run of an ended run's request, with its own id and budget; asks first on a terminal, and takes `--yes` in a pipe; `--harness` runs it on another engine |
| `321 harness can` | the harnesses this machine has, whether 321 drives each, and what each can enforce |
| `321 tui --brief` | one record per run: id, phase, outcome, agent, harness, request |

A run is named by its id or the last three characters of it.

Each Mission Control session writes `~/.321/logs/tui.log` (yours alone:
0600 in a 0700 directory; `DO_321_TUI_LOG` names another file): every key
and what it changed, every line sent, everything the screen said back,
and any error with its backtrace. A single character being typed is
logged as `typed`, never itself; a line sent is logged whole. Past 1 MB
the log starts again, keeping one before as `tui.log.1`.

Beside it, `~/.321/logs/cli.log` is 321's record of how it is used at the
shell: one JSON line per command a person types, with the command word,
its options and arguments, the form the answer took (screen, plain,
brief, json), whether a terminal was there and how wide, the exit code,
how long it took, and any usage help 321 had to show. A request to an
agent, a steer or words to find are counted (`free`), never kept. The
hooks a harness calls and the processes 321 runs for itself write
nothing. It is yours alone, never sent anywhere; `DO_321_INTERACTIONS=0`
keeps nothing, `DO_321_CLI_LOG` names another file. It is there so the
people who shape 321 can read back where its words helped and where they
got in the way.

## How a run is hosted

`start` builds the work package through the CLI's own builder, so trust,
grants and the policy ceiling are exactly those of `321 <agent> <request>`.
A run started here carries no approval. It then starts a host in a
session of its own with `setsid`. The host:

- records who it is in `host.json`: pid, start time, boot id;
- runs the unchanged runtime, `321 run --package FILE`, as its child, under
  `setpriv --pdeathsig TERM`;
- is the only writer of `events.jsonl`;
- takes requests from `inbox/`, numbers them in arrival order, and hands
  them to the runtime as directives;
- is the subreaper of everything below it. When the runtime ends, it stops
  whatever the agent left running and records each process.

The runtime writes the receipt, and nothing changes a receipt.

## The screen

Below 80 columns or 22 rows the crew folds into one line. From 150
columns the crew is a rail at the left, the conversation is in the middle,
and the selected run's evidence is at the right: harness, attempts, tools,
cost with its basis, the host and its heartbeat, the processes below it
with their CPU and memory, the open control, the receipt.

| Key | Does |
|---|---|
| Alt-Enter | a new line in what you are typing; the input area grows with the text, up to eight rows or a third of the screen, then scrolls with the cursor and says how much is above |
| `/edit`, Ctrl-G | opens what you are typing in your own editor (`$VISUAL`, else `$EDITOR`, else `vi`); what you save comes back to the input line, and nothing is sent until Enter |
| Enter | sends what is typed to the selected run: a steer while it works; once it has ended, the agent's next run, going on from that one |
| Esc | between typing and moving among runs |
| `v` | shows every run, the active ones, or the ones that need you |
| Ctrl-F | finds words in the conversation; Enter again for the next older |
| Ctrl-P | every action, Run again among them for an ended run |

A run that something else issued says where it came from, beside its
request and in the evidence: the issuer and the references its package
carried, word for word (`from api.123.do: track shop.example, step
200`). A run started here says only that. Nothing is said that the
package did not carry.

A control sent from the screen says its shell words once it is sent
(`stop requested for BEA K3F · CLI: 321 stop K3F`), so the words learnt
here work at the shell. Only words the shell takes get one;
`DO_321_HINTS=0` leaves them out. `DO_321_MOTION=0` keeps every mark
still: the words carry the state by themselves.

An agent is named on the input line by its short name, with or without
an `@`: `/start b1ll tidy the README` and `/start @b1ll tidy the README`
are the same, and a line that begins `@b1ll` is work for b1ll, a new run
of its own. Tab finishes a name being typed after `@` or after `/start`,
or takes it as far as the names agree; the line under the input lists
who it could be. The names are the ones in your trust file.

A run that said something since you last looked at it is marked new. A
steer is shown at once as sending, and as unconfirmed when its run has not
taken it within five seconds. A running run whose host has not written its
status for ten seconds says so; whether it is lost is still decided by
the kernel, not by the silence.

## Agents and harnesses

An agent is the crew: its name, role, character and package, installed
once. A harness is the engine a run uses: Claude Code, Codex, or 321's own
procedure executor. A run binds one agent package to one harness, one
workspace and one request:

    agent + harness + mission = run

So Bea on Claude Code and Bea on Codex are two runs, each with its own id,
log, inbox, receipt and controls, and stopping one never touches the
other. The screen leads with the agent and shows the harness beside it,
quieter: `BEA  claude` and `BEA  codex`. The evidence pane lists what that
harness can and cannot do.

**What a harness can do comes from its adapter.** Each adapter states
which features it enforces (tool allowlist, network off, turn and spend
limits, structured output, event stream, resume, graceful stop, live
steer, hold). Mission Control turns those claims into words ("steer
between steps", "keeps the network off", "no spend limit") and offers
only the controls that follow from them. Nothing on the screen is keyed
to a provider's name, so a new adapter is shown correctly as soon as it
is registered.

| | Claude Code | Codex |
|---|---|---|
| tools held to the grant | yes, by an allowlist | no: its sandbox limits effects, not tools; its web search and MCP servers run outside it |
| network off | no | yes, by its sandbox (tried: no host resolves) |
| turn and spend limits | yes | no |
| steer | between steps | between steps |
| hold | ends the step | ends the step |
| cost | dollars, as it reports them | tokens only, with the cost marked unreported |

**Choosing a harness.** `--harness` names one, and `bea on codex` in the
new-run line does the same. Without one, the runtime picks the first
harness able to enforce what the package needs. Either way, the runtime
checks the choice again: a harness that cannot enforce a requirement is
refused, never used with the requirement waived.

**Workspaces.** Two runs that can write never share a workspace. A second
one waits its turn (see *Waiting its turn*), or is started with
`--isolate`, which gives the run a git
worktree of the workspace at its last commit, under `~/.321/worktrees`.
Changes not yet committed are not in it. The run never commits. You
review what it did there, take it, and remove the worktree with
`git worktree remove`.

**Running again on another harness** makes a new run of the same request
with its own budget. It names the old run and that run's receipt
digest, gets a fresh worktree if the old run had one, and carries no
approval or grant. Nothing of the old harness's session moves across.

## A line for each agent

The screen opens on tracklines: a row an agent, time running left to
right. The marks are squares, because these are bots; 123 draws a
person's steps as dots.

      CREW             DONE   NOW     NEXT
      1DA               ■ ▪ │ ·     │
      B1LL   +3 ■ ■ ■ ⊠ ■ │ ▣❮▣❯◧ │ □ □
      M1RA                  │ ▣     │

     ▣ b1ll KD2  fix flaky t/19-status
       running a tool · bash · 3:40 · on Claude Code

    ■ done  ▪ no change  ⊟ stopped  ⊠ did not happen  ◧ waits on you  ▣ working  ◫ held  □ next

What an agent has done leads up to NOW, the newest nearest it and older
ones counted. Everything it has in hand stands side by side between two
blue bars, and the bars line up down the screen as one band: what is
happening now is a column the eye runs down. What waits its turn
follows. An agent with nothing in hand has a still point between its
bars. Agents are in name order, so each stays where it was.

A row is marks alone. What a job is, is said for the one under the
cursor, in the two lines beneath: the agent, the run and its request,
then how it stands, the time it has taken, what it has cost and the
harness it is on. Beside the title is what can be done to that job, by
its own state: keys while the arrows are on the lines (`h hold`,
`s stop`, `r resume` or `r go now`, `a again`), the same things as
words at the prompt (`/hold`, `/stop`). The key to the shapes sits
beside the headings on a wide, short screen, or on a row of its own on a tall
one. A large screen (140 columns by 30 rows, or more) has a panel at
the right instead: the shapes a row each, with the cursor's own picked
out; under them what can be done to the job under the cursor; then how
to move. The screen is kept quiet on purpose: no rules along the rows. A mark's shape says its state and its
colour says where on the track it is: green for done, blue for now,
orange for next. What did not happen is red, so it is never read as
done. An agent's own colour is on its name. A job being worked on
throbs, an even pulse (`DO_321_MOTION=0` keeps it still).

NOW is everything in hand: at work, held, and a run that ended waiting
on you, which is your move. It stays there until a run goes on from it;
then it has been answered and takes its place in DONE.

The cursor is 321's own mark closed on a job: `❮▣❯`. Enter
zooms in: the other rows give their room to that job's conversation and
the input line is ready to speak to it. Esc gives its keys; Esc again
shows every line.

The arrows live in two places, one above the other: the lines and the
prompt. On the lines, ←→ move along one agent's line, through done, now
and next, and stop at its ends; ↑↓ go to the next agent, landing on
what it has in hand. Down from the last line goes to the prompt, which
names the job and says what it is for (`B1LL 7MY ❯ say something to
b1ll, or / for a word`). Up from an empty prompt is back on the lines.
Esc does the same either way. The conversation is the run under the cursor, and every control acts on
that run. Its evidence (phase, harness, attempts, cost, host, workspace,
receipt) is detail and is out of the way; `e` on the lines, or
`/view evidence`, shows it beside the conversation and puts it away
again. The lines take at most two fifths of the screen; agents past that
are counted above and below, and follow the cursor. `t`, or
`/view table` and `/view lines`, switches between the lines and a table
with a row a run; `DO_321_VIEW=table` opens on the table. Below 80
columns the crew is one line, as before.

## Waiting its turn

A run that cannot start yet is accepted and waits: phase `queued`. Two
things make a run wait. A run that writes waits for the workspace while
another run is at work there. And where `321 trust now N` stands, an
agent works on N things at once, and a run started past that waits for a
place. The oldest waiting run goes first.

Nothing schedules. Each run's own host waits, looking at the other runs'
evidence, and starts its runtime when nothing is ahead of it. 321 keeps
no queue of work and chooses between nothing: which work comes first is
still the word of whoever started it.

A waiting run is a run: it has its id, its package and its inbox.

- `321 stop <run>` ends it having done nothing. The runtime writes the
  receipt, `stopped`, with no attempt on it.
- `321 resume <run>`, or Go now on the screen, starts it at once, ahead
  of its turn.
- A steer is kept, and given to the agent when it starts.
- A package that expires while it waits is put to the runtime, which
  says so on the receipt.

`321 start` says when a run waits, behind which run, and how to let it
go. This holds for runs started here, at the shell or from Mission
Control. A package another system issues (`321 start --package`) is
hosted as it stands and does not wait: that would change what the
issuer is told, and is proposed to 123.do, not made.

## The run directory

`~/.321/runs/<run-id>/`, mode 0700. Each file has one writer.

| File | Writer | Meaning |
|---|---|---|
| `run.json` | launcher, once | what was launched; `continues` names the run it is again of, and that run's receipt digest |
| `work-package.json` | launcher, once | the package as issued |
| `host.json` | host, once | who is running it |
| `live` | host | exists from host start until the end is written |
| `events.jsonl` | host | what happened, in order, `seq` without gaps |
| `status.json` | host, atomic replace | a cache of the folded state, never proof, with `usage`: CPU and memory of the processes below the host, from `/proc` |
| `tree.json` | host, each heartbeat | the processes below the host, by identity |
| `inbox/` | any client | `<ULID>-<kind>.json`, written whole and renamed in |
| `queued` | host | exists while the run waits its turn; nothing has run |
| `receipt.json` | the runtime, once | the outcome |
| `ended.json` | first to prove it | an end the host could not record, with its basis |

The inbox carries `steer`, `clarify`, `hold`, `resume` and `stop`, and
nothing else. No file can approve, grant or widen anything. A directive is
read only when it is a regular file, owned by this user, private, well
formed, and addressed to this run. Anything else is moved to
`inbox/rejected/` and logged as `directive_refused`.

`~/.321/runs` must be on a local filesystem. On NFS, SMB or FUSE a
rename or an exclusive create may not mean the same thing to every
reader, so `start` refuses and says to set `DO_321_HOME`.

A run's log keeps everything up to 64 MB. Past that the agent's own words
are dropped and the log says so once (`log_truncated`); tool calls,
controls and the end are still recorded. A screen keeps the newest 2,000
lines of a conversation in memory and says how many earlier ones are only
in `events.jsonl`.

## Phase and outcome

`phase` says where a run is in its life: starting, queued, running, blocked, held,
stopping, ended, lost. `outcome` says how it ended: the receipt's word,
or `lost` when it ended and nobody knows how. A run is `running` only
while its host is that very process. A pid whose start time or boot
differs is not the host. A receipt always wins over `ended.json`.

`stop` and `attach` exit 6 for a lost run. `lost` and exit 6 are
Mission Control's own until they are agreed into the shared outcome
vocabulary.

## Talking to an agent whose run has ended

The prompt stays on an ended run. Words typed there begin a new run of
the same agent in the same workspace, and it goes on from the ended
run's receipt: the runtime resumes the agent's harness session where the
harness can (`session_continue`), so a question like "what did you
change, and why?" is answered with that work in mind. It is a run of its
own, with its own id and budget, a new package, and no approval carried
over; its receipt names the run it follows (`follows`) and the receipt
digest it read. Nothing asks first: the words are yours. A lost run has
no receipt to go on from; `/restart` runs its request again.

## What hold and steer do today

Today's Claude Code adapter has no live input. **Hold** ends the agent's
current step now and waits, and **resume** continues the same
conversation. **Steer** ends the current step, and the agent continues
with your words. The screen says "taken" when the runtime has applied a
steer. It never says the agent obeyed.

## Known gaps

- Codex is registered, and is chosen only where its claims cover the
  package. It has a sandbox, not a tool allowlist, so a package with tool
  grants is refused on it, and the receipt names what it cannot enforce.
  Whether a sandbox may count for some grants, per grant and with its
  basis in the receipt, is the owner's decision. Codex also needs
  `codex login`.
- 123.do cannot yet ask for or limit a harness. The owner's trust policy
  (`adapters.preferred` and `adapters.denied`) already can. A work
  package field for it is a change to the shared contract with 123.do,
  and is proposed rather than made.

- `321 run` ignores SIGTERM once its stdin has closed. When a host is
  killed outright, its runtime and harness keep running until
  `321 stop <run> --force` finds them through `tree.json`.
- The streaming Claude adapter is not built yet. It would give live
  steering, a true hold at the tool boundary, and interrupt.
- macOS has no `/proc`, subreaper or `setpriv`, so this is Linux first.
