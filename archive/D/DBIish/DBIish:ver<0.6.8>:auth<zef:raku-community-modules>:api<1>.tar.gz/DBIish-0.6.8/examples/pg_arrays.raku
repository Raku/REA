#!/usr/bin/env raku

use DBIish;
use NativeCall;

# Windows support
if $*DISTRO.is-win {
	# libpq.dll on windows depends on libeay32.dll which in this path
	my constant PG-HOME   = 'C:\Program Files\PostgreSQL\9.3';
	my $path              = sprintf( 'Path=%s;%s\bin', %*ENV<Path>, PG-HOME );
	%*ENV<DBIISH_PG_LIB>  = (PG-HOME).fmt( '%s\lib\libpq.dll' );

	# Since %*ENV<Path> = ... does not actually own process environment
	# Weird magic but needed atm :)
	sub _putenv(Str) is native('msvcrt') { ... }
	_putenv( $path);
}

my $dbh = DBIish.connect(
	"Pg",
	:database<postgres>,
	:user<postgres>,
	:password<sa>, :RaiseError
);

my $sth = $dbh.execute(q:to/STATEMENT/);
  DROP TABLE IF EXISTS sal_emp;
STATEMENT

$sth = $dbh.execute(q:to/STATEMENT/);
  CREATE TABLE sal_emp (
    name               text,
    pay_by_quarter     integer[],
    schedule           text[][],
    salary_by_month    float[]
  );
STATEMENT

$sth = $dbh.execute(q:to/STATEMENT/);
	INSERT INTO sal_emp
    VALUES (
      'Bill',
      '{10000, 10000, 10000, 10000}',
      '{{"meeting", "lunch"}, {"training day", "presentation"}}',
      '{511.123, 622.345,1}'
    );
STATEMENT

$sth = $dbh.prepare(q:to/STATEMENT/);
	SELECT name, pay_by_quarter, schedule, salary_by_month
	FROM sal_emp
STATEMENT

for $sth.execute.allrows(:array-of-hash) -> $row {
    say $row<name>;  # Bill
    say $row<pay_by_quarter>.join(", ");  # 10000, 10000, 10000, 10000
    say $row<salary_by_month>.join(", "); # 511.123, 622.345, 1

    # Schedule is a multi-dimensional array
    for $row<schedule>.list -> $schedule {
        say $schedule.join(' : ');  # meeting : lunch
                                    # training day : presentation
    }
}

# Cleanup
$sth.dispose;
$dbh.dispose;
