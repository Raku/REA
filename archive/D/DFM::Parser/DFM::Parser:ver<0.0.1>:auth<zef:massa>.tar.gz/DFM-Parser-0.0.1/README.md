[![Actions Status](https://github.com/massa/DFM-Parser/actions/workflows/test.yml/badge.svg)](https://github.com/massa/DFM-Parser/actions)

NAME
====

DFM::Parser - Parse DFM (Delphi Module) text format

SYNOPSIS
========

```raku
use DFM::Parser;
DFM::Parser.parse: 'a-dfm-file.dfm'.IO.slurp
```

DESCRIPTION
===========

DFM::Parser is the simplest possible parser for DFM files

AUTHOR
======

Humberto Massa <humbertomassa@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright © 2025 Humberto Massa

This library is free software; you can redistribute it and/or modify it under either the Artistic License 2.0 or the LGPL v3.0, at your convenience.

