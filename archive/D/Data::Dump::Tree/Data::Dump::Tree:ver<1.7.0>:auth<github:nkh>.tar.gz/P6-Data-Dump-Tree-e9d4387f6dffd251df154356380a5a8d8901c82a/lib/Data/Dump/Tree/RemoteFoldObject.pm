
class RemoteFoldObject { has $.object ; has %.options } ;


