#!raku

use Duck::CSV;

# Use read-column-names to print rows in column order, since the
# row hashes themselves are unordered.

sub MAIN($file) {
  my @columns = read-column-names $file;
  my @rows    = read-csv $file;

  for @rows -> $row {
    say @columns.map({ "$_=$row{$_}" }).join(", ");
  }
}
