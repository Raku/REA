add @others an array of names of other data sets

Now:
     class must have basic features
     possibility of individual class attributes such as must have periods
     code vs. abbreviation attr on an array
     separate class for sets arrays?
     better intro

Planned improvements:

+ Add more languages

+ Add more tests

+ Add usage examples

+ Add CLDR data use capability
