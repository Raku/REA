my constant PRINTABLE_TABLE = do {
    my int @table;
    @table[flat ords("\t\b\o33\o14"), 32..126, 128..255] = 1 xx *;
    @table
}

multi is-text(Blob $content, Int(Cool) :$test-bytes = 4096) is export {
    my int $limit = $content.elems min $test-bytes;
    my int $printable;
    my int $unprintable;

    # Don't let a CR as the last byte ruin the result
    --$limit if $limit;

    loop (my int $i = 0; $i < $limit; ++$i) {
        my uint $check = $content[$i];
        if $check {
            if $check == 13 {
                # \r not followed by \n hints binary
                return False if $content[++$i] != 10;
            }
            elsif $check == 10 {
                # Ignore lone \n
            }
            elsif PRINTABLE_TABLE[$check] {
                $printable++;
            }
            else {
                $unprintable++;
            }
        }
        else {
            # NULL byte, so binary.
            return False;
        }
    }

    ($printable +> 7) >= $unprintable;
}

multi is-text(IO::Path $path, Int(Cool) :$test-bytes = 4096) is export {
    my $fh := $path.open(:r, :bin);
    LEAVE .close with $fh;

    is-text($fh.read($test-bytes), :$test-bytes);
}

# vim: expandtab shiftwidth=4
