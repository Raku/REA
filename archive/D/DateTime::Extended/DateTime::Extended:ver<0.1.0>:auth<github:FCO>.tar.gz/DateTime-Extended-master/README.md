[![Build Status](https://travis-ci.org/FCO/DateTime-Extended.svg?branch=master)](https://travis-ci.org/FCO/DateTime-Extended)

# DateTime-Extended
