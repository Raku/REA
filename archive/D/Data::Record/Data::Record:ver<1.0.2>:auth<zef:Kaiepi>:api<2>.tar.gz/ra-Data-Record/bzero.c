#include <limits.h>
#include <stdio.h>

unsigned int
cast_int_to_uint(int value)
{
    union {
        int i;
        struct {
            unsigned int a : 1;
            unsigned int b : 31;
        } __attribute__((packed)) c;
    } x = { value };
    return x.c.a ? x.c.b + INT_MIN : x.c.b;
}

int
main(void)
{
    printf("%X\n", cast_int_to_uint(-1));
    return 0;
}
