[![Build Status](https://travis-ci.org/yowcow/p6-Digest-MurmurHash.svg?branch=master)](https://travis-ci.org/yowcow/p6-Digest-MurmurHash)

NAME
====

Digest::MurmurHash - blah blah blah

SYNOPSIS
========

    use Digest::MurmurHash;

DESCRIPTION
===========

Digest::MurmurHash is ...

AUTHOR
======

yowcow <yowcow@cpan.org>

COPYRIGHT AND LICENSE
=====================

Copyright 2016 yowcow

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.
