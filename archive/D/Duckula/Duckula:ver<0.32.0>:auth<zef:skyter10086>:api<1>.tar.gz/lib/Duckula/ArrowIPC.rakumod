use v6.d;
need Arrow::IPC::Write;
need Arrow::IPC::Format;

#| Arrow IPC 写侧的兼容适配。真正的 FlatBuffers 编解码在 Arrow::IPC 包里，
#| 这里只保留 Duckula 原有的调用签名，避免破坏已有代码。
unit module Duckula::ArrowIPC;

our sub parse-format(Str:D $f --> Hash) is export {
    Arrow::IPC::Format::parse-format($f)
}
our sub write-ipc($arrow, Str:D $path, Str:D :$format = 'file' --> Nil) is export {
    Arrow::IPC::Write::write-ipc($arrow, $path, :$format)
}
our sub ipc-buf($arrow, Str:D :$format = 'stream' --> Buf) is export {
    Arrow::IPC::Write::ipc-buf($arrow, :$format)
}
