use v6.d;
use Duckula::SQL;
use Duckula::Guard;
use Duckula::Expr;
use Duckula::X::Frame;

#| Frame/Series 的「函数式 API」公共构件（v0.27.0）。
#|
#| 这里只放**纯字符串工具**：不引用 Frame/Series 类型（前向引用会让
#| Raku 的 resolver 崩），也不碰连接。调用方负责把生成的 SQL 交给
#| `Frame.derived`，所以白名单、窗口锚定这些仍由 Frame 复用现成逻辑。
#|
#| 两个难点：
#|   1. Raku 闭包的结果要回到 DuckDB。DuckDB 的 COPY/VALUES 都不接受绑定
#|      参数出现在列值里，所以这里把值渲染成 SQL 字面量（走 sql-literal，
#|      字符串双写单引号，NaN/Inf 变 NULL）。
#|   2. 写回时必须保留原行序与原列。做法是先钉一个扫描序行号，LEFT JOIN
#|      一张 VALUES 表，再把旧列 EXCLUDE 掉、中间列 alias 回去。
unit module Duckula::FrameOps;

#| 条件归一化：Expr 已经是渲染好的片段；字符串片段要过网关。
#| 返回 (sql, 剩余列集合)：Expr 的列要交给 Frame 做白名单校验，字符串
#| 片段里的列名是受信代码入口（和 filter(Str) 一致），返回空集合。
our sub normalize-condition($cond, @args --> List) is export {
    if $cond ~~ Duckula::Expr {
        die Duckula::X::Frame.new(
            reason => 'extra bind arguments are only valid with a SQL string condition'
        ) if @args.elems;
        return ($cond.render, $cond.columns).List;
    }
    if $cond ~~ Str {
        check-fragment($cond, :params(@args.elems));
        my Str $sql = @args.elems ?? render-bindings($cond, @args) !! $cond;
        return ($sql, Set.new).List;
    }
    die Duckula::X::Frame.new(
        reason => 'condition must be a Duckula::Expr or a SQL fragment string, got '
                ~ $cond.^name
    );
}

#| pandas 的 `where` / `mask` 都是逐列的条件替换。
#| cond 为 NULL 时按 False 处理（pandas 把 NaN 条件视为 False），所以
#| where 用 COALESCE(cond, false)、mask 用 NOT COALESCE(cond, false)。
our sub fill-expression(
    Str:D $column,
    Str:D $condition,
    $other,
    Bool:D :$mask = False,
    Str :$type,
    --> Str
) is export {
    my Str $lit = $other.defined ?? sql-literal($other) !! 'NULL';
    if $other.defined && $type.defined && $type.chars {
        # 类型名来自 DuckDB 自己的 DESCRIBE，但仍只放行 ASCII 类型写法，
        # 免得它哪天带了奇怪内容变成注入点。TRY_CAST 让「把 'X' 写进
        # INTEGER 列」变成 NULL，而不是整条查询报 Conversion Error。
        die Duckula::X::Frame.new(reason => "invalid column type '$type'")
            unless $type ~~ /^ <[A..Z a..z 0..9 _ ( ) , \s]> + $/;
        $lit = 'TRY_CAST(' ~ $lit ~ ' AS ' ~ $type ~ ')';
    }
    my Str $test = 'COALESCE((' ~ $condition ~ '), false)';
    $test = 'NOT ' ~ $test if $mask;
    'CASE WHEN ' ~ $test ~ ' THEN ' ~ quote-ident($column)
        ~ ' ELSE ' ~ $lit ~ ' END';
}

#| Raku 值 → SQL 字面量。Date/DateTime 先转字符串；NaN/Inf 交给
#| sql-literal 的 `refusing non-finite numeric literal` 处理——这里主动
#| 转成 NULL，因为 pandas 的 map/apply 里 NaN 是合法返回值。
our sub cell-literal($v --> Str) is export {
    return 'NULL' unless $v.defined;
    # NaN 自不等；Inf 用直接比较，避开不同 Raku 版本的方法名差异。
    return 'NULL' if $v ~~ Num && ($v != $v || $v == Inf || $v == -Inf);
    return sql-literal($v.Str) if $v ~~ Date || $v ~~ DateTime;
    # 显式 DOUBLE：否则 DuckDB 会把小数推断成 DECIMAL，驱动再解码成
    # 十进制字符串，Series 里就看不到 Num 了。
    return sql-literal($v) ~ '::DOUBLE' if $v ~~ Num;
    sql-literal($v);
}

#| 一张 VALUES 表：两列 `__duckula_ord` / `v`，给写回 LEFT JOIN 用。
#| 空列表时不能写 `VALUES ()`，退化成一条恒假的 SELECT。
our sub values-table(Str:D $alias, @values --> Str) is export {
    if @values.elems {
        # row_number() 从 1 开始，VALUES 的序号也要从 1 开始。
        my @rows = @values.kv.map(-> $i, $v {
            '(' ~ ($i + 1) ~ ', ' ~ cell-literal($v) ~ ')'
        });
        return '(VALUES ' ~ @rows.join(', ') ~ ') AS '
             ~ quote-ident($alias) ~ '(' ~ quote-ident('__duckula_ord')
             ~ ', ' ~ quote-ident('v') ~ ')';
    }
    '(SELECT NULL::BIGINT AS ' ~ quote-ident('__duckula_ord')
        ~ ', NULL::DOUBLE AS ' ~ quote-ident('v')
        ~ ' WHERE false) AS ' ~ quote-ident($alias);
}

#| 给中间列挑不与源列撞名的名字。
my sub temp-names(@names --> List) {
    my Set $known = @names.Set;
    my Str $ord = '__duckula_ord';
    my Str $tmp = '__duckula_v';
    $ord ~= '_' while $ord ∈ $known;
    $tmp ~= '_' while $tmp ∈ $known || $tmp eq $ord;
    ($ord, $tmp).List;
}

#| JOIN 的骨架：给源 SQL 钉一个扫描序行号，LEFT JOIN VALUES 表。
my sub join-values(
    Str:D $source-sql,
    Str:D $ord,
    Str:D $tmp,
    Str:D $values-sql,
    Str:D $alias,
    --> Str
) {
    'SELECT a.*, ' ~ $alias ~ '.' ~ quote-ident('v')
      ~ ' AS ' ~ quote-ident($tmp) ~ ' FROM ('
      ~ 'SELECT *, row_number() OVER () AS ' ~ quote-ident($ord)
      ~ ' FROM (' ~ $source-sql ~ ') AS __duckula_src_ord) AS a '
      ~ 'LEFT JOIN ' ~ $values-sql ~ ' ON a.' ~ quote-ident($ord)
      ~ ' = ' ~ $alias ~ '.' ~ quote-ident($ord);
}

#| 把一列 Raku 值写回原 SQL，保持行数、列序与行序。
#|
#| 不用 `SELECT * EXCLUDE (...)`：同名列被 EXCLUDE 时，JOIN 进来的新值
#| 会一起被排除（踩过坑，结果多出一列还错位）。这里显式列出投影列，
#| 并用两层 ORDER BY 钉住行序。
our sub replace-column-sql(
    Str:D $source-sql,
    Str:D $column,
    @values,
    @names,
    --> Str
) is export {
    my ($ord, $tmp) = temp-names(@names);
    my Str $alias = '__duckula_vals';
    my Str $vals = values-table($alias, @values);
    my @proj = @names.map(-> $n {
        $n eq $column
            ?? quote-ident($tmp) ~ ' AS ' ~ quote-ident($n)
            !! quote-ident($n)
    });
    my Str $rows = @proj.join(', ');
    my Str $outer = @names.map({ quote-ident($_) }).join(', ');

    # 中层把新值 alias 回原列名，外层只按原名投影（不能再引用临时列）。
    'SELECT ' ~ $outer ~ ' FROM ('
      ~ 'SELECT ' ~ $rows ~ ', ' ~ quote-ident($ord) ~ ' FROM ('
      ~ join-values($source-sql, $ord, $tmp, $vals, $alias)
      ~ ') AS __duckula_joined ORDER BY ' ~ quote-ident($ord)
      ~ ') AS __duckula_ordered ORDER BY ' ~ quote-ident($ord);
}

#| 追加一列 Raku 值（Frame.apply(axis => 1) 的结果列）。
our sub add-column-sql(
    Str:D $source-sql,
    Str:D $column,
    @values,
    @names,
    --> Str
) is export {
    my ($ord, $tmp) = temp-names(@names);
    my Str $alias = '__duckula_vals';
    my Str $vals = values-table($alias, @values);
    my Str $rows = @names.map({ quote-ident($_) }).join(', ');
    my Str $proj = ($rows.chars ?? $rows ~ ', ' !! '')
                 ~ quote-ident($tmp) ~ ' AS ' ~ quote-ident($column);
    my Str $outer = ($rows.chars ?? $rows ~ ', ' !! '')
                  ~ quote-ident($column);

    'SELECT ' ~ $outer ~ ' FROM ('
      ~ 'SELECT ' ~ $proj ~ ', ' ~ quote-ident($ord) ~ ' FROM ('
      ~ join-values($source-sql, $ord, $tmp, $vals, $alias)
      ~ ') AS __duckula_joined ORDER BY ' ~ quote-ident($ord)
      ~ ') AS __duckula_ordered ORDER BY ' ~ quote-ident($ord);
}
