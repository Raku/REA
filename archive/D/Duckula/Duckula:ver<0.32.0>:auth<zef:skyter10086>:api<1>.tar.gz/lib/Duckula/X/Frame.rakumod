use v6.d;

#| Frame 层面的用法错误（参数非法、链式调用不成立等），不是数据库错误。
class Duckula::X::Frame is Exception is export {
    has Str $.reason is required;

    method message(--> Str) { $!reason }
}
