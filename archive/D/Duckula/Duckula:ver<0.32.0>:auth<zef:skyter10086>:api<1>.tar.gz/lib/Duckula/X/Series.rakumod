use v6.d;

#| Series 层面的用法错误（列名不存在、head 负数、空 select 等）。
class Duckula::X::Series is Exception is export {
    has Str $.reason is required;

    method message(--> Str) { $!reason }
}
