use v6.d;

#| SQL 字符串工具层的用法错误（占位符与实参不匹配等）。
class Duckula::X::SQL is Exception is export {
    has Str $.reason is required;

    method message(--> Str) { $!reason }
}
