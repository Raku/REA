use v6.d;

#| 查询网关拒绝执行时抛出的异常。
#|
#| 与 App::DuckETL::X::Pipeline 同构：单字段 reason，message 直接回显。
unit class Duckula::X::Guard is Exception;

has Str $.reason is required;

method message(--> Str) { $!reason }
