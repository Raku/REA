use v6.d;
use Duckula::SQL;
use Duckula::X::Frame;

#| 清洗与重塑（阶段 11）的 SQL 构件。
#|
#| 这里只有**纯函数**：把参数译成 SQL 片段，既不执行、也不碰 Frame 类型。
#| 原因和 `Duckula::Join` 一样 —— eager（`Frame`）与 lazy（`LazyFrame`）两条
#| 路径必须给出语义一致的结果，各自把同一批片段塞进不同的壳（`SELECT * FROM
#| (...)` vs 计划节点）。语义写在一处，就不会出现"惰性路径少判一个空值"。
#|
#| 另一条共同约定：列名一律 quote-ident + 白名单。两个动作分工见 §9.5.3 ——
#| quote-ident 保证任何字符都退化成合法标识符，白名单保证拼错的列名当场
#| 报错，而不是静默多出一列 NULL。
#|
#| 辅助列（行号、计数）的命名统一走 `private-name`：撞上用户列名就加下划线。
#| 这不是洁癖 —— `tail` 当初就吃过亏，静默覆盖一列真实数据是最难查的错。
#|
#| 参数一律用 `@`-sigil 而不是 `List` 类型约束。这不是风格问题：`my List $x =
#| $y` 是把 List 塞进标量容器，之后 `for $x -> $i` **只迭代一次**、把整个
#| List 当成一个元素交出来（`.elems` 却照样返回真实长度，所以很难发现）。
#| 第一版就是这么把三个列名当成一个叫 `id g v` 的列名报错的。
unit module Duckula::Clean;

#| `unique(:keep)` 的合法取值。
#| `first` / `last` 是 pandas 的默认语义，`any` 是 Polars 的省事版（不定序），
#| `none` 只留下不重复的行（Polars 里叫 `keep="none"`，pandas 没有对应项）。
my constant %KEEP = (
    first => True,
    last  => True,
    any   => True,
    none  => True,
);

#| 需要「行序锚」的填充策略。
#| `ffill` / `bfill` 本质是「按当前顺序往前/往后找第一个非空」，SQL 里没有
#| 天然行序，必须显式钉一个 `row_number()`。`mean` / `median` 是整列聚合，
#| 与顺序无关。
my constant %NEEDS-SEQ = (
    ffill => True,
    bfill => True,
);

#| 累积窗口的帧子句。默认帧是 `RANGE`，同值行会被当成 peer group 一起取，
#| 只有显式 `ROWS` 才是「严格按行推进」。
my constant $FWD-FRAME = 'ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW';
my constant $BWD-FRAME = 'ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING';

my constant $KEEP-HINT = 'first, last, any or none';
my constant $FILL-HINT = 'ffill, bfill, mean or median';

#| 参数列表归一：`f($a, $b)` 与 `f([$a, $b])` 等价。
#|
#| 每个收 `*@cols` 的算子都要它 —— 让 `$df.drop(<a b>)` 和 `$df.drop('a','b')`
#| 都能用，不必让调用方记住哪一个。
our sub flatten-args(@raw --> List) is export {
    if @raw.elems == 1 && @raw[0] ~~ Positional {
        return @raw[0].List;
    }
    @raw.List;
}

#| 列名白名单校验。
our sub need-cols(@cols, @names, Str:D $op --> Nil) is export {
    my Set $known = @names.Set;
    for @cols -> $c {
        die Duckula::X::Frame.new(
            reason => "$op refers to unknown column '$c'; "
                    ~ "available: {@names.join(', ')}"
        ) unless $known{$c};
    }
}

#| 给辅助列挑一个不与用户列名冲突的名字。
our sub private-name(@names, Str:D $base --> Str) is export {
    my Set $known = @names.Set;
    my Str $n = $base;
    $n ~= '_' while $known{$n};
    $n;
}

#| 各算子共用的「子集为空就用全部列」规则。
our sub cols-or-all(@cols, @names --> List) is export {
    @cols.elems ?? @cols.List !! @names.List;
}

#| 把 Hash / Pair / Pair 列表归一成 Pair 列表，供 `rename` / `cast` 使用。
our sub as-pairs($map, Str:D $op --> List) is export {
    my @pairs = do {
        if $map ~~ Associative   { $map.pairs.List }
        elsif $map ~~ Pair       { ($map,).List }
        elsif $map ~~ Positional { $map.List }
        else {
            die Duckula::X::Frame.new(
                reason => "$op expects a hash or a list of pairs "
                        ~ "('old' => 'new'), got {$map.^name}"
            );
        }
    };

    for @pairs -> $p {
        die Duckula::X::Frame.new(
            reason => "$op expects pairs, got {$p.^name}"
        ) unless $p ~~ Pair;
    }

    @pairs.List;
}

# ------------------------------------------------------------------ 拼接

#| 纵向拼接：`UNION ALL BY NAME`。
#|
#| 为什么用 `BY NAME` 而不是按位置：按位置的 `UNION ALL` 完全是陷阱 ——
#| 两张表列序不同就会把「城市」拼进「金额」。`BY NAME` 按名字对齐、缺的列补
#| NULL、列序取第一个分支再追加后续新列，正是 pandas `concat` 的默认行为。
#|
#| 也不用自己加 `ORDER BY`：SQL 的集合运算不保证行序，但 DuckDB 的实现是
#| 顺序追加的，实测稳定（`t/18` 里钉住了这一点）。
our sub concat-sql(@rels --> Str) is export {
    @rels.map({ 'SELECT * FROM (' ~ $_ ~ ') AS __duckula_cat' })
         .join("\nUNION ALL BY NAME\n");
}

#| `:strict` 下逐帧比对列名，报出「少了什么、多了什么」。
our sub check-same-columns(@names-list, Str:D $op --> Nil) is export {
    my Set $base = @names-list[0].Set;

    for @names-list.kv -> $i, $names {
        my Set $s = $names.Set;
        my Set $missing = $base (-) $s;
        my Set $extra   = $s (-) $base;
        next unless $missing.elems || $extra.elems;

        my @bits;
        @bits.push: 'missing ' ~ $missing.keys.sort.join(', ') if $missing.elems;
        @bits.push: 'extra ' ~ $extra.keys.sort.join(', ')     if $extra.elems;

        die Duckula::X::Frame.new(
            reason => "$op: frame $i has different columns ({@bits.join('; ')})"
        );
    }
}

# ------------------------------------------------------------------ 去重

#| 去重。
#|
#| 四种 `:keep` 的 SQL 形态不同，原因在「行序」：
#|   - `any`：`DISTINCT ON` 最省，但输出顺序由执行计划决定，不保证；
#|   - `first` / `last` / `none`：必须先钉扫描序行号，否则「第一行」无从定义。
#|     定完再按行号排回去，所以去重后的顺序与输入一致 —— 这一点比 Polars 的
#|     `unique` 更可预期（它不保证保序），也更容易测。
our sub unique-sql(
    Str:D $rel,
    @cols,
    Str:D $keep,
    @names
    --> Str
) is export {
    die Duckula::X::Frame.new(
        reason => "unique: unknown keep mode '$keep'; expected $KEEP-HINT"
    ) unless %KEEP{$keep};

    my Str $part = @cols.map({ quote-ident($_) }).join(', ');

    if $keep eq 'any' {
        return 'SELECT DISTINCT ON (' ~ $part ~ ') * '
             ~ 'FROM (' ~ $rel ~ ') AS __duckula_u';
    }

    my Str $seq = private-name(@names, '__duckula_seq');
    my Str $inner = 'SELECT *, row_number() OVER () AS ' ~ quote-ident($seq)
                  ~ ' FROM (' ~ $rel ~ ') AS __duckula_u_src';
    my Str $scoped = '(' ~ $inner ~ ') AS __duckula_u_w';

    if $keep eq 'none' {
        # 只留「在自己这一组里独一无二」的行：组大小 == 1。
        # 窗口函数不能出现在 WHERE 里，所以计数必须在中间层算完。
        my Str $cnt = private-name(@names, '__duckula_cnt');
        my Str $mid = 'SELECT *, count(*) OVER (PARTITION BY ' ~ $part ~ ') AS '
                    ~ quote-ident($cnt) ~ ' FROM ' ~ $scoped;

        return 'SELECT * EXCLUDE (' ~ quote-ident($seq) ~ ', ' ~ quote-ident($cnt) ~ ') '
             ~ 'FROM (' ~ $mid ~ ') AS __duckula_u_out '
             ~ 'WHERE ' ~ quote-ident($cnt) ~ ' = 1 '
             ~ 'ORDER BY ' ~ quote-ident($seq);
    }

    my Str $desc = $keep eq 'last' ?? ' DESC' !! '';
    my Str $rn = private-name(@names, '__duckula_rn');
    my Str $mid = 'SELECT *, row_number() OVER (PARTITION BY ' ~ $part
                ~ ' ORDER BY ' ~ quote-ident($seq) ~ $desc ~ ') AS ' ~ quote-ident($rn)
                ~ ' FROM ' ~ $scoped;

    'SELECT * EXCLUDE (' ~ quote-ident($seq) ~ ', ' ~ quote-ident($rn) ~ ') '
    ~ 'FROM (' ~ $mid ~ ') AS __duckula_u_out '
    ~ 'WHERE ' ~ quote-ident($rn) ~ ' = 1 '
    ~ 'ORDER BY ' ~ quote-ident($seq);
}

# ------------------------------------------------------------------ 频次

#| 单列频次表（pandas 的 `value_counts`）。
#|
#| 输出两列：原列 + `count`；`:normalize` 再多一列 `proportion`。
#| `count` 撞上真实列名时退让成 `count_`，理由同 `private-name`。
#|
#| 排序是 `count DESC, <列名>` 而不是只按 `count DESC`：只有一级排序键时，
#| 计数相同的行由执行计划决定顺序，eager 与 lazy 两条路径就会给出不同的行序
#| （实测如此）。补上列名做次级键，结果才是确定的 —— pandas 在并列时按
#| 「首次出现」排，SQL 里做不到（没有天然行序），退一步按值升序，可解释。
#|
#| `:keep-nulls` 默认关：pandas 的 `value_counts` 默认丢掉空值，Polars 保留。
#| 这里跟 pandas，因为频次表的读者通常不想看到一行 NULL。
our sub value-counts-sql(
    Str:D $rel,
    Str:D $col,
    @names,
    Bool :$sort = True,
    Bool :$normalize = False,
    Bool :$keep-nulls = False
    --> Str
) is export {
    need-cols(($col,), @names, 'value-counts');

    my Str $q = quote-ident($col);
    my Str $cnt = private-name(@names, 'count');

    my @items;
    @items.push: $q ~ ' AS ' ~ $q;
    @items.push: 'count(*) AS ' ~ quote-ident($cnt);
    # 分母是整个窗口：`sum(count(*)) OVER ()` 在分组之上再求一次总和。
    @items.push: 'count(*)::DOUBLE / sum(count(*)) OVER () AS "proportion"'
        if $normalize;

    my Str $sql = 'SELECT ' ~ @items.join(', ')
                ~ ' FROM (' ~ $rel ~ ') AS __duckula_vc';
    $sql ~= ' WHERE ' ~ $q ~ ' IS NOT NULL' unless $keep-nulls;
    $sql ~= ' GROUP BY ' ~ $q;
    $sql ~= ' ORDER BY ' ~ quote-ident($cnt) ~ ' DESC, ' ~ $q if $sort;
    $sql;
}

# ------------------------------------------------------------------ 改名 / 删列

#| `rename` 的完整投影列表。
#|
#| 做法是**显式列出全部列**（未改名的写 `"a" AS "a"`），而不是 `* EXCLUDE`
#| 加几个别名：`EXCLUDE` 只能删不能换名，硬拼会产出两个同名列，之后
#| `$df.column('x')` 只拿得到前面那个（旧值）—— 和 `with-column` 里记的
#| 静默错一模一样。
#|
#| 一次调用里允许链式换名（`a => b` 加 `b => c`）：投影是一次成型的，不按
#| 顺序串行套子查询，所以 `b` 既是被换走的旧名、又是新名，两者都对。
our sub rename-items(@names, $map, Bool :$strict = True --> List) is export {
    my @pairs = as-pairs($map, 'rename');
    my Set $known = @names.Set;

    my %new-of;
    for @pairs -> $p {
        my Str $old = $p.key.Str;
        my Str $new = $p.value.Str;

        die Duckula::X::Frame.new(
            reason => "rename: target name for '$old' must not be empty"
        ) if $new eq '';

        unless $known{$old} {
            next unless $strict;
            die Duckula::X::Frame.new(
                reason => "rename refers to unknown column '$old'; "
                        ~ "available: {@names.join(', ')}"
            );
        }

        %new-of{$old} = $new;
    }

    my Set $renamed = %new-of.keys.Set;
    my %taken;
    for %new-of.kv -> $old, $new {
        die Duckula::X::Frame.new(
            reason => "rename: '$old' and '%taken{$new}' would both be named '$new'"
        ) if %taken{$new}:exists;
        %taken{$new} = $old;

        die Duckula::X::Frame.new(
            reason => "rename: '$new' collides with an existing column "
                    ~ "(rename it too, or pick another name)"
        ) if $known{$new} && !$renamed{$new};
    }

    @names.map(-> $c {
        my Str $to = %new-of{$c} // $c;
        quote-ident($c) ~ ' AS ' ~ quote-ident($to);
    }).List;
}

#| `drop` 的投影列表：删掉指定列后剩下的全部列。
our sub drop-items(@names, @cols, Str:D $op = 'drop' --> List) is export {
    need-cols(@cols, @names, $op);

    my Set $gone = @cols.Set;
    my @left = @names.grep({ !$gone{$_} });

    die Duckula::X::Frame.new(
        reason => "$op would remove every column of the frame"
    ) unless @left.elems;

    @left.map({ quote-ident($_) ~ ' AS ' ~ quote-ident($_) }).List;
}

# ------------------------------------------------------------------ 空值

#| `drop-nulls` 的谓词。谓词返回真 = **保留**这一行。
#|
#|   :how<any>（默认）  任一列为空就丢  -> a IS NOT NULL AND b IS NOT NULL
#|   :how<all>          整行全空才丢    -> NOT (a IS NULL AND b IS NULL)
#|
#| `all` 写成「全空的否定」而不是 `a IS NOT NULL OR b IS NOT NULL`：后者等价，
#| 但前者与被丢掉的形状一一对应 —— 读谓词时不用在脑子里再做一次德摩根。
#| 第一版就写反成 `NOT (a IS NOT NULL AND b IS NOT NULL)`（= 至少一个为空），
#| 于是 `:how<all>` 只留下含空值的行，测试当场抓住。
our sub null-predicate(@cols, Str:D $how --> Str) is export {
    die Duckula::X::Frame.new(
        reason => "drop-nulls: unknown how '$how'; expected any or all"
    ) unless $how eq 'any' || $how eq 'all';

    if $how eq 'any' {
        return @cols.map({ quote-ident($_) ~ ' IS NOT NULL' }).join(' AND ');
    }

    'NOT (' ~ @cols.map({ quote-ident($_) ~ ' IS NULL' }).join(' AND ') ~ ')';
}

#| 归一 `fill-nulls` 的两个入口，返回模式名（`value` / 策略名）。
#|
#| 两者必须恰好给一个。都不给是忘了写；都给是不知道要哪个 —— 静默挑一个
#| 会让人以为另一个生效了。
our sub fill-mode(:$value, Str :$strategy --> Str) is export {
    my Bool $has-value = $value.defined;
    my Bool $has-strategy = $strategy.defined;

    if $has-value && $has-strategy {
        die Duckula::X::Frame.new(
            reason => 'fill-nulls: pass either :value or :strategy, not both'
        );
    }

    die Duckula::X::Frame.new(
        reason => 'fill-nulls needs :value(...) or :strategy(...); '
                ~ "known strategies: $FILL-HINT"
    ) unless $has-value || $has-strategy;

    return 'value' unless $has-strategy;

    die Duckula::X::Frame.new(
        reason => "fill-nulls: unknown strategy '$strategy'; expected $FILL-HINT"
    ) unless %NEEDS-SEQ{$strategy} || $strategy eq 'mean' || $strategy eq 'median';

    $strategy;
}

#| 该模式是否需要行序锚。
our sub needs-seq(Str:D $mode --> Bool) is export { so %NEEDS-SEQ{$mode} }

#| 单列的填充表达式。
our sub fill-expr(
    Str:D $col,
    Str:D $mode,
    :$value,
    Str :$seq
    --> Str
) is export {
    my Str $q = quote-ident($col);

    my Str $body = do given $mode {
        when 'ffill'  {
            'last_value(' ~ $q ~ ' IGNORE NULLS) OVER (ORDER BY '
            ~ quote-ident($seq) ~ ' ' ~ $FWD-FRAME ~ ')'
        }
        when 'bfill'  {
            'first_value(' ~ $q ~ ' IGNORE NULLS) OVER (ORDER BY '
            ~ quote-ident($seq) ~ ' ' ~ $BWD-FRAME ~ ')'
        }
        when 'mean'   { 'avg(' ~ $q ~ ') OVER ()' }
        when 'median' { 'median(' ~ $q ~ ') OVER ()' }
        default       { sql-literal($value) }
    };

    'coalesce(' ~ $q ~ ', ' ~ $body ~ ') AS ' ~ $q;
}

#| 一批列的填充表达式。
our sub fill-items(
    @cols,
    Str:D $mode,
    :$value,
    Str :$seq = ''
    --> List
) is export {
    my Str $anchor = '';

    if needs-seq($mode) {
        die Duckula::X::Frame.new(
            reason => "fill-nulls: strategy '$mode' needs a row-order anchor"
        ) if $seq eq '';
        $anchor = $seq;
    }

    @cols.map(-> $c { fill-expr($c, $mode, :$value, seq => $anchor) }).List;
}

#| `* EXCLUDE (...)` 里的那串名字（空列表返回空串）。
our sub quoted-list(@cols --> Str) is export {
    @cols.map({ quote-ident($_) }).join(', ');
}

# ------------------------------------------------------------------ 类型

#| 校验 `CAST(... AS <type>)` 里的类型名。
#|
#| 类型名没法参数绑定 —— `CAST(x AS ?)` 是语法错误 —— 所以它和列名一样属于
#| 「必须由我们自己保证合法」的一类。用形态白名单而不是黑名单：
#|   `BIGINT`、`DECIMAL(18,4)`、`VARCHAR[]`、`STRUCT(a INTEGER)`、`DOUBLE`
#| 都是合法目标；带引号、分号、注释符的一律拒绝，因为它们能让 CAST 之后的
#| 文本变成另一条语句。
our sub check-type-name(Str:D $type --> Str) is export {
    my Str $t = $type.trim;

    die Duckula::X::Frame.new(
        reason => 'cast: empty type name'
    ) if $t eq '';

    die Duckula::X::Frame.new(
        reason => "cast: '$type' is not a plain SQL type name"
    ) unless $t ~~ /
        ^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>*
        [ \s+ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* ]*
        [ \s* '(' <[A..Z a..z 0..9 _ , \s]>* ')' ]?
        [ \s* '[' \s* ']' ]*
        \s* $
    /;

    $t;
}
