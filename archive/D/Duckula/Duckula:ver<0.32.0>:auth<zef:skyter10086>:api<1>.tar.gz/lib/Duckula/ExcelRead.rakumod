use v6.d;
use Compress::Zlib::Raw;
use Duckula::SQL;
use Duckula::X::Frame;

#| 不依赖 DuckDB excel 扩展的最小 XLSX 读取器（兜底路径）。
#|
#| Windows 的 windows_amd64_mingw 构建在官方扩展仓库里没有 excel 扩展，
#| `INSTALL excel` 会 404；这种情况下 read-excel 走这里。支持的是日常表格
#| 的公共子集：sharedStrings / inlineStr / 数字 / 布尔 / 公式结果，首行
#| 作表头。样式、日期格式、合并单元格不解析——日期会像 Excel 内部那样
#| 是序号。需要完整语义时请用带 excel 扩展的 DuckDB 构建。
#|
#| 解出来的行会灌进一张连接级临时表，然后像 read-arrow 一样返回指向
#| 那张表的 Frame：后续算子仍然由 DuckDB 执行。
unit module Duckula::ExcelRead;

my Int $TABLE-SEQ = 0;

sub fail(Str:D $reason --> Nil) {
    die Duckula::X::Frame.new(:$reason);
}

# ---------- ZIP（只读 central directory，够用就行） ----------

sub u16(Buf:D $b, Int:D $i --> Int) { $b[$i] + ($b[$i + 1] +< 8) }

sub u32(Buf:D $b, Int:D $i --> Int) {
    $b[$i] + ($b[$i + 1] +< 8) + ($b[$i + 2] +< 16) + ($b[$i + 3] +< 24);
}

#| ZIP 存的是 raw deflate（没有 zlib 头和校验和），用 -15 交给 zlib。
sub inflate-raw(Buf:D $raw, Int:D $size --> Str) {
    my Buf $out = Buf.allocate($size > 0 ?? $size !! 1);
    my $stream = z_stream.new;
    my Bool $inited = False;
    LEAVE { inflateEnd($stream) if $inited }

    $stream.set-input($raw);
    $stream.set-output($out);
    my $rc = inflateInit2($stream, -15);
    fail("xlsx: cannot initialise deflate stream (zlib rc=$rc)") unless $rc == 0;
    $inited = True;

    $rc = inflate($stream, 4); # Z_FINISH
    fail("xlsx: cannot inflate a ZIP entry (zlib rc=$rc)") unless $rc == 1;
    $out.subbuf(0, $stream.total-out).decode('utf8');
}

sub zip-entries(Buf:D $data --> Hash) {
    my Int $eocd = $data.elems - 22;
    while $eocd >= 0 && u32($data, $eocd) != 0x06054b50 { $eocd-- }
    fail('xlsx: not a ZIP archive (no end-of-central-directory)') if $eocd < 0;

    my Int $count = u16($data, $eocd + 10);
    my Int $off   = u32($data, $eocd + 16);
    my %entries;

    for ^$count -> $i {
        fail("xlsx: bad central directory at entry $i")
            unless $off + 46 <= $data.elems && u32($data, $off) == 0x02014b50;

        my Int $method = u16($data, $off + 10);
        my Int $csize  = u32($data, $off + 20);
        my Int $usize  = u32($data, $off + 24);
        my Int $nlen   = u16($data, $off + 28);
        my Int $elen   = u16($data, $off + 30);
        my Int $clen   = u16($data, $off + 32);
        my Int $lho    = u32($data, $off + 42);
        my Str $name   = $data.subbuf($off + 46, $nlen).decode('utf8');

        fail("xlsx: bad local header for $name")
            unless $lho + 30 <= $data.elems && u32($data, $lho) == 0x04034b50;
        my Int $start = $lho + 30 + u16($data, $lho + 26) + u16($data, $lho + 28);
        my Buf $raw = $data.subbuf($start, $csize);

        %entries{$name} = do given $method {
            when 0 { $raw.decode('utf8') }              # stored
            when 8 { inflate-raw($raw, $usize) }        # deflate
            default { fail("xlsx: unsupported ZIP method $method for $name") }
        }
        $off += 46 + $nlen + $elen + $clen;
    }
    %entries;
}

# ---------- 一点点 XML（字符串层面，避免依赖完整的 DOM） ----------

sub xml-text(Str:D $s --> Str) {
    $s.subst(/'&#x' (<[0..9 a..f A..F]>+) ';'/, -> $/ { :16(~$0).chr }, :g)
      .subst(/'&#' (\d+) ';'/, -> $/ { $0.Int.chr }, :g)
      .subst('&lt;',   '<',  :g)
      .subst('&gt;',   '>',  :g)
      .subst('&quot;', '"',  :g)
      .subst('&apos;', "'",  :g)
      .subst('&amp;',  '&',  :g);
}

sub attr(Str:D $tag, Str:D $name --> Str) {
    my $m = $tag.match(/ "$name" \s* '=' \s* '"' $<v>=(<-["]>*) '"' /);
    $m.defined ?? ~$m<v> !! '';
}

sub resolve-part(Str:D $target --> Str) {
    my Str $p = $target.starts-with('/') ?? $target.substr(1) !! "xl/$target";
    my @parts;
    for $p.split('/') -> $seg {
        next if $seg eq '' || $seg eq '.';
        $seg eq '..' ?? @parts.pop !! @parts.push($seg);
    }
    @parts.join('/');
}

#| 把 `sheet`（表名或省略时的第一张）解析成 zip 里的 worksheet 部件名。
sub worksheet-part(%entries, Str :$sheet --> Str) {
    my Str $wb = %entries{'xl/workbook.xml'}
        // fail('xlsx: xl/workbook.xml is missing');
    my @sheets = $wb.match(/'<sheet' \s+ $<a>=(<- [>] >+) '/>'/, :g)
                   .map({ ~$_<a> });
    fail('xlsx: no worksheets found') unless @sheets;

    my Str $wanted = $sheet.defined ?? $sheet.fc !! '';
    my $chosen;
    for @sheets -> $tag {
        my Str $name = xml-text(attr($tag, 'name'));
        if !$sheet.defined || $name.fc eq $wanted {
            $chosen = $tag;
            last;
        }
    }
    fail("xlsx: no sheet named '$sheet'") unless $chosen.defined;

    my Str $rid = attr($chosen, 'r:id');
    my Str $rels = %entries{'xl/_rels/workbook.xml.rels'}
        // fail('xlsx: workbook relationships are missing');
    my @rels = $rels.match(/'<Relationship' \s+ $<a>=(<- [>] >+) '/>'/, :g)
                   .map({ ~$_<a> });
    for @rels -> $tag {
        next unless attr($tag, 'Id') eq $rid;
        my Str $part = resolve-part(attr($tag, 'Target'));
        return $part if %entries{$part}:exists;
        fail("xlsx: worksheet part $part is missing");
    }
    fail("xlsx: no relationship for sheet '$sheet'");
}

sub shared-strings(%entries --> Array) {
    return [] unless %entries{'xl/sharedStrings.xml'}:exists;
    my Str $xml = %entries{'xl/sharedStrings.xml'};
    my @out;
    for $xml.match(/'<si' \s* <-[>]>* '>' $<body>=(.*?) '</si>'/, :g) -> $m {
        my @runs = $m<body>.match(/'<t' \s* <-[>]>* '>' (.*?) '</t>'/, :g)
                     .map({ xml-text(~$_[0]) });
        @out.push(@runs.join);
    }
    @out;
}

sub column-index(Str:D $ref --> Int) {
    my $m = $ref.match(/^ $<letters>=(<[A..Z]>+) /);
    fail("xlsx: bad cell reference '$ref'") unless $m;
    my Int $n = 0;
    $n = $n * 26 + ($_.ord - 64) for $m<letters>.Str.comb;
    $n - 1;
}

sub cell-value(Str:D $attrs, Str:D $inner, @shared) {
    my Str $type = attr($attrs, 't');
    my $v-match = $inner.match(/'<v' \s* <-[>]>* '>' (.*?) '</v>'/);
    my Str $v = $v-match.defined ?? xml-text(~$v-match[0]) !! '';

    return @shared[$v.Int] // '' if $type eq 's';
    if $type eq 'inlineStr' {
        return $inner.match(/'<t' \s* <-[>]>* '>' (.*?) '</t>'/, :g)
                    .map({ xml-text(~$_[0]) }).join;
    }
    return $v eq '1' ?? True !! False if $type eq 'b';
    return $v if $type eq 'str' || $type eq 'e' || $v eq '';
    return $v + 0
        if $v ~~ /^ <[+\-]>? \d+ ['.' \d*]? <[eE]>? <[+\-]>? \d* $/;
    $v;
}

sub sheet-rows(Str:D $xml, @shared --> Array) {
    my @rows;
    for $xml.match(/'<row' \s+ <-[>]>* '>' $<body>=(.*?) '</row>'/, :g) -> $r {
        my @cells;
        for $r<body>.split('<c ').skip(1) -> $chunk {
            my Str $head = $chunk.split('>')[0];
            my Str $attrs = $head.subst(/ \s* $ /, '');
            my Str $inner = $chunk.contains('</c>')
                ?? $chunk.split('</c>')[0].substr($head.chars + 1)
                !! '';
            my Str $ref = attr($attrs, 'r');
            my Int $idx = $ref eq '' ?? @cells.elems !! column-index($ref);
            @cells[$idx] = cell-value($attrs, $inner, @shared);
        }
        @rows.push(@cells);
    }
    @rows;
}

sub normalise-headers(@raw --> Array) {
    my @out;
    my %seen;
    for @raw.kv -> $i, $v {
        my Str $name = ($v.defined ?? ~$v !! '').trim;
        $name = "col_{$i + 1}" if $name eq '';
        if %seen{$name}:exists {
            %seen{$name}++;
            $name = "{$name}_{%seen{$name}}";
        }
        else {
            %seen{$name} = 1;
        }
        @out.push($name);
    }
    @out;
}

sub column-type(@vals, Bool:D :$all-varchar --> Str) {
    return 'VARCHAR' if $all-varchar;
    my @defined = @vals.grep(*.defined);
    return 'VARCHAR' unless @defined;
    return 'BOOLEAN' if @defined.all ~~ Bool;
    return 'DOUBLE'  if @defined.all ~~ Numeric;
    'VARCHAR';
}

#| 主入口：解析 xlsx -> 临时表 -> Frame。
our sub read-excel(
    $session,
    Str:D $path,
    Str :$sheet,
    Bool:D :$header = True,
    Bool:D :$all-varchar = False,
) is export {
    fail('read-excel needs file-system access, but this session is sandboxed')
        if $session.sandboxed;
    fail("read-excel: no such file '$path'") unless $path.IO.e;

    my %entries = zip-entries(slurp($path, :bin));
    my Str $part = worksheet-part(%entries, :$sheet);
    my @shared = shared-strings(%entries);
    my @all-rows = sheet-rows(%entries{$part}, @shared);

    my (@headers, @rows);
    if $header && @all-rows {
        @headers = normalise-headers(@all-rows[0]);
        @rows = @all-rows.skip(1).Array;
    }
    else {
        @rows = @all-rows;
        my Int $width = @rows.map(*.elems).max // 0;
        @headers = (0 ..^ $width).map({ "col_{$_ + 1}" }).Array;
    }

    my Int $width = @headers.elems;
    my @types = (0 ..^ $width).map(-> $c {
        column-type(@rows.map({ $_[$c] // Nil }).Array, :$all-varchar)
    }).Array;
    my @data = @rows.map(-> $row {
        (0 ..^ $width).map(-> $c {
            my $v = $row[$c];
            !$v.defined ?? Nil !! (@types[$c] eq 'VARCHAR' ?? ~$v !! $v)
        }).Array
    }).Array;

    my Str $table = "__duckula_xlsx_{$*PID}_{++$TABLE-SEQ}";
    my Str $cols = (0 ..^ $width).map({
        "{quote-ident(@headers[$_])} {@types[$_]}"
    }).join(', ');
    $session.execute("CREATE OR REPLACE TEMP TABLE {quote-ident($table)} ($cols)");
    $session.insert($table, @data) if @data;

    $session.sql('SELECT * FROM ' ~ quote-ident($table));
}

#| 只看骨架：sheet 名和行列数（不建表）。
our sub describe-xlsx(Str:D $path --> Hash) is export {
    my %entries = zip-entries(slurp($path, :bin));
    my Str $part = worksheet-part(%entries);
    my @rows = sheet-rows(%entries{$part}, shared-strings(%entries));
    my @tags = %entries{'xl/workbook.xml'}
        .match(/'<sheet' \s+ $<a>=(<- [>] >+) '/>'/, :g).map({ ~$_<a> });
    {
        sheets => @tags.map({ xml-text(attr($_, 'name')) }).Array,
        rows   => @rows.elems,
        cols   => @rows.map(*.elems).max // 0,
    };
}
