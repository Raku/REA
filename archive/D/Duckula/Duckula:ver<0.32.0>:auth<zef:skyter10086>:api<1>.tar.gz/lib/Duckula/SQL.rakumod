use v6.d;
use Duckula::X::SQL;

#| Duckula 的 SQL 字符串工具层：纯函数，无 I/O，无连接。
#|
#| 设计要点（详见 ARCHITECTURE.md §9.5）：
#|   - 值优先走参数绑定，sql-literal 只作为兜底；
#|   - 标识符必须过 quote-ident；
#|   - 所有"看 SQL 文本"的判断都基于 code-mask：先跳过
#|     字符串字面量 / 引号标识符 / 行注释 / 块注释 / 美元引用，
#|     否则 select 'drop table t' 这种会把黑名单骗过去。
unit module Duckula::SQL;

# ============================================================
# 标识符与字面量
# ============================================================

#| 把任意字符串包成合法 SQL 标识符。内部的 " 双写，整体用 " 包围。
#| 实测：amount"; DROP TABLE t; --  ->  "amount""; DROP TABLE t; --"
our sub quote-ident(Str:D $name --> Str) is export {
    '"' ~ $name.subst('"', '""', :g) ~ '"';
}

multi sub sql-literal(Nil --> Str) is export { 'NULL' }

multi sub sql-literal(Bool:D $value --> Str) is export {
    $value ?? 'true' !! 'false';
}

multi sub sql-literal(Numeric:D $value --> Str) is export {
    # NaN 自不等，Inf 直接比较；不同 Raku 版本的方法名（is-nan/isNaN、
    # is-inf/isInfinite）不一致，用比较避免踩版本差异。
    die "refusing non-finite numeric literal"
        if $value ~~ Num && ($value != $value || $value == Inf || $value == -Inf);
    $value.Str;
}

multi sub sql-literal(Str:D $value --> Str) is export {
    "'" ~ $value.subst("'", "''", :g) ~ "'";
}

multi sub sql-literal(Positional:D $value --> Str) is export {
    '[' ~ $value.map({ sql-literal($_) }).join(', ') ~ ']';
}

multi sub sql-literal($value --> Str) is export {
    die "unsupported SQL literal: {$value.raku}";
}

# ============================================================
# 跳过段：返回"下一个扫描位置"（不含结束定界符之后）
# ============================================================

my sub skip-single(@ch, Int $i --> Int) {
    # '...' 内部 '' 表示一个单引号
    my $n = @ch.elems;
    my $j = $i + 1;
    while $j < $n {
        if @ch[$j] eq "'" {
            if $j + 1 < $n && @ch[$j + 1] eq "'" { $j += 2; next }
            return $j + 1;
        }
        $j++;
    }
    $n;
}

my sub skip-double(@ch, Int $i --> Int) {
    # "..." 内部 "" 表示一个双引号
    my $n = @ch.elems;
    my $j = $i + 1;
    while $j < $n {
        if @ch[$j] eq '"' {
            if $j + 1 < $n && @ch[$j + 1] eq '"' { $j += 2; next }
            return $j + 1;
        }
        $j++;
    }
    $n;
}

my sub skip-line(@ch, Int $i --> Int) {
    my $n = @ch.elems;
    my $j = $i + 2;
    while $j < $n {
        return $j if @ch[$j] eq "\n";
        $j++;
    }
    $n;
}

my sub skip-block(@ch, Int $i --> Int) {
    my $n = @ch.elems;
    my $j = $i + 2;
    while $j + 1 < $n {
        return $j + 2 if @ch[$j] eq '*' && @ch[$j + 1] eq '/';
        $j++;
    }
    $n;
}

my sub dollar-quote-ahead(@ch, Int $i --> Bool) {
    # 只认 $$ 和 $tag$（tag 必须是 [A-Za-z0-9_]），避免把 $c 参数当成引用
    my $n = @ch.elems;
    return True if $i + 1 < $n && @ch[$i + 1] eq '$';
    my $j = $i + 1;
    while $j < $n {
        my $d = @ch[$j];
        return True if $d eq '$' && $j > $i + 1;
        return False unless $d ~~ /<[A..Z a..z 0..9 _]>/;
        $j++;
    }
    False;
}

my sub skip-dollar(@ch, Int $i --> Int) {
    my $n = @ch.elems;
    my $j = $i + 1;
    my $tag = '';
    while $j < $n && @ch[$j] ne '$' {
        $tag ~= @ch[$j];
        $j++;
    }
    return $n if $j >= $n;

    my @close = ('$' ~ $tag ~ '$').comb;
    my $k = $j + 1;
    while $k < $n {
        if @ch[$k] eq '$' {
            my Bool $hit = True;
            for ^@close.elems -> $m {
                if $k + $m >= $n || @ch[$k + $m] ne @close[$m] { $hit = False; last }
            }
            return $k + @close.elems if $hit;
        }
        $k++;
    }
    $n;
}

# ============================================================
# 代码掩码
# ============================================================

#| 返回与字符一一对应的 Bool 数组：True 表示该字符属于 SQL 代码，
#| False 表示它落在字符串 / 引号标识符 / 注释 / 美元引用里。
our sub code-mask(Str:D $sql --> Array) is export {
    my @ch = $sql.comb;
    my $n = @ch.elems;
    my @mask = True xx $n;
    my $i = 0;

    while $i < $n {
        my $c = @ch[$i];
        my $end = $i;

        if $c eq "'" {
            $end = skip-single(@ch, $i);
        }
        elsif $c eq '"' {
            $end = skip-double(@ch, $i);
        }
        elsif $c eq '-' && $i + 1 < $n && @ch[$i + 1] eq '-' {
            $end = skip-line(@ch, $i);
        }
        elsif $c eq '/' && $i + 1 < $n && @ch[$i + 1] eq '*' {
            $end = skip-block(@ch, $i);
        }
        elsif $c eq '$' && dollar-quote-ahead(@ch, $i) {
            $end = skip-dollar(@ch, $i);
        }

        if $end > $i {
            @mask[$_] = False for $i ..^ $end;
            $i = $end;
        }
        else {
            $i++;
        }
    }

    @mask;
}

#| 把非代码字符全部替换成空格，便于做词级判断。
our sub code-only-text(Str:D $sql --> Str) is export {
    my @ch = $sql.comb;
    my @mask = code-mask($sql);
    my $out = '';
    for ^@ch.elems -> $i {
        $out ~= @mask[$i] ?? @ch[$i] !! ' ';
    }
    $out;
}

# ============================================================
# 计数与判定
# ============================================================

#| 只数裸 ?，跳过的段里的问号不算。
our sub placeholder-count(Str:D $sql --> Int) is export {
    my @ch = $sql.comb;
    my @mask = code-mask($sql);
    my $count = 0;
    for ^@ch.elems -> $i {
        $count++ if @mask[$i] && @ch[$i] eq '?';
    }
    $count;
}

#| 语句条数：尾部分号不计；字符串 / 注释里的分号不计。
our sub statement-count(Str:D $sql --> Int) is export {
    my @ch = $sql.comb;
    my @mask = code-mask($sql);
    my $count = 0;
    my Bool $has-content = False;

    for ^@ch.elems -> $i {
        next unless @mask[$i];
        my $c = @ch[$i];
        if $c eq ';' {
            $count++ if $has-content;
            $has-content = False;
        }
        elsif $c !~~ /\s/ {
            $has-content = True;
        }
    }

    $count++ if $has-content;
    $count;
}

# ============================================================
# 占位符扫描（bare identifier 替换）
# ============================================================

my sub ident-char(Str:D $c --> Bool) {
    so $c ~~ /^ <[A..Z a..z 0..9 _]> $/;
}

my sub token-at(@ch, Int $i, @tok, Bool $ci, @mask --> Bool) {
    my $n = @ch.elems;
    for ^@tok.elems -> $k {
        return False if $i + $k >= $n;
        return False unless @mask[$i + $k];        # 不允许跨越"非代码"边界
        my $a = @ch[$i + $k];
        my $b = @tok[$k];
        if $ci { return False unless $a.lc eq $b.lc }
        else   { return False unless $a eq $b }
    }
    True;
}

#| 把 SQL 中**裸标识符**位置的 $token 换成 $replacement，跳过
#| 字符串字面量 / 引号标识符 / 行注释 / 块注释 / 美元引用（复用 code-mask）。
#|
#| 边界规则：
#|   - 前一个字符不能是标识符字符，也不能是 `.` —— 这样 `t.self`（限定的列名）不动；
#|   - 后一个字符不能是标识符字符 —— 这样 `selfish` 不动；
#|   - 因此 `self.city` 会变成 `__duckula_1.city`，正是想要的。
#|
#| :$ignore-case 默认为 True，因为 SQL 标识符不区分大小写（SELF 与 self 等价）。
our sub replace-bare-ident(
    Str:D $sql,
    Str:D $token,
    Str:D $replacement,
    Bool :$ignore-case = True,
    --> Str
) is export {
    my @ch = $sql.comb;
    my @mask = code-mask($sql);
    my @tok = $token.comb;
    my Int $n = @ch.elems;
    my Int $tl = @tok.elems;

    return $sql unless $tl && $n;

    my Str $out = '';
    my Int $i = 0;

    while $i < $n {
        if token-at(@ch, $i, @tok, $ignore-case, @mask) {
            my Bool $prev-ok = $i == 0
                || (!ident-char(@ch[$i - 1]) && @ch[$i - 1] ne '.');
            my Int $after = $i + $tl;
            my Bool $next-ok = $after >= $n || !ident-char(@ch[$after]);

            if $prev-ok && $next-ok {
                $out ~= $replacement;
                $i = $after;
                next;
            }
        }
        $out ~= @ch[$i];
        $i++;
    }

    $out;
}

# ============================================================
# 把参数固化成自包含的 SQL
# ============================================================

#| 按顺序把代码位置的裸 `?` 换成转义后的字面量，返回一条**无参数**的 SQL。
#|
#| 为什么需要它：Frame 的真相是那条 SELECT（§9.7）。攒下来的 relation-sql
#| 要能塞进 `CREATE TEMP VIEW ... AS <sql>`，而视图定义不允许带绑定参数。
#| 值都来自调用方的 Raku 变量，经 sql-literal 转义后内联，语义与绑定等价。
#| 执行时仍然走真绑定（值不经过 SQL 文本），内联版本只用于回溯引用。
our sub render-bindings(Str:D $sql, @values --> Str) is export {
    my @ch = $sql.comb;
    my @mask = code-mask($sql);
    my Int $n = @ch.elems;
    my Int $k = 0;
    my Str $out = '';

    for ^$n -> $i {
        if @mask[$i] && @ch[$i] eq '?' {
            die Duckula::X::SQL.new(
                reason => "SQL has more '?' than the {+@values} value(s) supplied"
            ) if $k >= @values.elems;
            $out ~= sql-literal(@values[$k]);
            $k++;
        }
        else {
            $out ~= @ch[$i];
        }
    }

    if $k != @values.elems {
        die Duckula::X::SQL.new(
            reason => "SQL has $k '?' but {+@values} value(s) were supplied"
        );
    }

    $out;
}

my constant %DANGEROUS = set <
    insert update delete drop create alter truncate
    copy attach detach install load pragma call
    export import vacuum checkpoint
>;

#| 写操作动词。比 `%DANGEROUS` 窄得多：只留语句**类型**看不出来的那几个。
#|
#| `PRAGMA`、`CALL`、`COPY`、`ATTACH`、`INSTALL` 在类型里已经各归各类（SET、
#| CALL、COPY、ATTACH、LOAD），不需要按词猜。但 `WITH d AS (DELETE FROM t
#| RETURNING *) SELECT * FROM d` 在 DuckDB 眼里是 **SELECT** —— 写操作藏在
#| CTE 里，类型层面完全看不出来，只能扫词。
my constant %WRITE-VERB = set <
    insert update delete drop create alter truncate
>;

#| 代码区里是否出现写操作动词（字符串与注释里的不算）。
#|
#| 与 `is-readonly-sql` 的分工：那个在没有解析器时**整体**判断，这个只做
#| 「类型看不见的那一层」，由 `Duckula::Guard` 在有连接时叠加使用。
#|
#| 误拒的边界：列名与动词同形且没加引号时（`select delete_flag from t` 不会，
#| 因为分词结果就是 `delete_flag`；但 `select x as delete from t` 会）。加引号
#| 即可。
our sub has-write-keyword(Str:D $sql --> Bool) is export {
    my $words = code-only-text($sql).lc.comb(/ <[a..z 0..9 _]>+ /).Set;
    so (%WRITE-VERB (&) $words).elems;
}


#| 粗判一条语句是否只读。
#|
#| 两道检查：
#|   1. 首个词必须是查询类（select / with / values / from / describe / explain / show / summarize）；
#|   2. 在全部代码字符里扫危险词 —— 因为 `WITH x AS (...) DELETE FROM t` 和
#|      `EXPLAIN ANALYZE DELETE FROM t` 都能绕过前缀检查。
#|
#| 局限：这是启发式。列名若与保留字同名且没加引号，会被误拒（加引号即可）。
our sub is-readonly-sql(Str:D $sql --> Bool) is export {
    my $code = code-only-text($sql).trim.lc;
    return False if $code eq '';

    return False unless $code ~~ /^ [ '(' | (select|with|values|from|describe|explain|show|summarize) <|w> ]/;

    my $words = $code.comb(/ <[a..z 0..9 _]>+ /).Set;
    my $hit = %DANGEROUS (&) $words;
    return False if $hit.elems;

    True;
}
