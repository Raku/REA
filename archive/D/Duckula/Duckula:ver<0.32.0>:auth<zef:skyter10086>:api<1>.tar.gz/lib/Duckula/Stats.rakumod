use v6.d;
use Duckula::SQL;
use Duckula::X::Frame;

#| 统计函数的 SQL 构件（v0.25.0）：corr / cov / skew / kurt 与 nlargest / nsmallest。
#|
#| 两条设计约束贯穿本文件：
#|
#| 1. **源 SQL 只出现一次**。LazyFrame 的 relation-sql 里可能带 `?` 占位符，
#|    复制一遍就得重复绑一遍参数。所以相关矩阵不用 N 段 UNION ALL，而是
#|    `CROSS JOIN` 一张标签表 + `CASE` 条件聚合，一次扫描出整张矩阵。
#| 2. **spearman 必须套子查询**。DuckDB 不允许把窗口函数直接嵌进聚合
#|    （`corr(rank() OVER (...), ...)` 报 bind error），先投影 rank 再聚合。
#|
#| 函数名、方法名、keep 模式全部过白名单；列名过 quote-ident；标签是数据值，
#| 走 sql-literal。延续 §9 的防注入模型。

my constant %CORR-METHOD = set <pearson spearman>;
my constant %MATRIX-FN   = set <corr covar_samp covar_pop>;
my constant %ROW-FN      = set <skewness kurtosis>;
my constant %KEEP        = set <first last all>;

our sub check-corr-method(Str:D $method --> Str) is export {
    my Str $m = $method.trim.lc;
    return $m if %CORR-METHOD{$m};
    die Duckula::X::Frame.new(
        reason => "unknown correlation method '$method'; expected 'pearson' or 'spearman'"
    );
}

our sub check-matrix-fn(Str:D $fn --> Str) is export {
    return $fn if %MATRIX-FN{$fn};
    die Duckula::X::Frame.new(reason => "unsupported matrix aggregate '$fn'");
}

our sub check-row-fn(Str:D $fn --> Str) is export {
    return $fn if %ROW-FN{$fn};
    die Duckula::X::Frame.new(reason => "unsupported row aggregate '$fn'");
}

our sub check-keep(Str:D $keep --> Str) is export {
    my Str $k = $keep.trim.lc;
    return $k if %KEEP{$k};
    die Duckula::X::Frame.new(
        reason => "unknown keep mode '$keep'; expected 'first', 'last' or 'all'"
    );
}

#| :ddof 默认 1（pandas 的 cov 默认），0 为总体。
our sub cov-fn(Int:D :$ddof = 1 --> Str) is export {
    die Duckula::X::Frame.new(reason => "ddof must be 0 or 1, got $ddof")
        unless $ddof == 0 || $ddof == 1;
    $ddof == 0 ?? 'covar_pop' !! 'covar_samp';
}

#| 把 :columns 归一成列名列表：未给时用全部列，给单个 Str 或 List 都收成 List。
our sub norm-stat-cols($cols, @names, Str:D $op --> List) is export {
    return @names.List unless $cols.defined;
    my @raw = $cols ~~ Positional ?? $cols.List !! ($cols,).List;
    my Set $known = Set.new(@names.map(*.Str));
    for @raw -> $c {
        die Duckula::X::Frame.new(
            reason => "$op: no column named '$c'; available: {@names.join(', ')}"
        ) unless $c.Str ∈ $known;
    }
    @raw.List;
}

#| 起一个不撞用户列名的辅助列名。
my sub aux-name(Str:D $base, @known --> Str) {
    my Set $taken = Set.new(@known.map(*.Str));
    my Str $candidate = $base;
    $candidate ~= '_' while $candidate ∈ $taken;
    $candidate;
}

#| 两列统计的一行一列 SQL。同 Frame 的 Series.corr / cov 用它。
our sub pair-stat-sql(
    Str:D $sql, Str:D $a, Str:D $b,
    Str:D $fn, Str:D :$method = 'pearson',
    --> Str
) is export {
    my Str $agg = $fn eq 'cov' ?? cov-fn() !! check-matrix-fn($fn);
    my Str $how = check-corr-method($method);
    my Str $qa = quote-ident($a);
    my Str $qb = quote-ident($b);

    if $how eq 'spearman' {
        die Duckula::X::Frame.new(
            reason => 'spearman is only available for corr, not cov'
        ) unless $agg eq 'corr';
        # 窗口函数不能直接嵌进 corr，先投影 rank。$sql 只出现一次。
        'SELECT corr("__duckula_lr", "__duckula_rr") AS __duckula_stat FROM ('
          ~ 'SELECT CASE WHEN ' ~ $qa ~ ' IS NULL THEN NULL ELSE '
                   ~ 'rank() OVER (ORDER BY ' ~ $qa ~ ') END AS "__duckula_lr", '
          ~ 'CASE WHEN ' ~ $qb ~ ' IS NULL THEN NULL ELSE '
                   ~ 'rank() OVER (ORDER BY ' ~ $qb ~ ') END AS "__duckula_rr"'
          ~ ' FROM (' ~ $sql ~ ') AS __duckula_pairbase'
          ~ ') AS __duckula_pairrank';
    }
    else {
        'SELECT ' ~ $agg ~ '(' ~ $qa ~ ', ' ~ $qb ~ ') AS __duckula_stat'
          ~ ' FROM (' ~ $sql ~ ') AS __duckula_pairbase';
    }
}

# ------------------------------------------------------------ 矩阵：corr / cov

#| N×N 矩阵：首列是行标签（真实列，调用方会 set-index），其余列名是原数值列。
#|
#| pearson / cov：一次扫描 + CROSS JOIN 标签表 + CASE 条件聚合。
#| spearman：内层先给每列投影 rank，外层对 rank 做 corr；同样一次扫描。
our sub stats-matrix-sql(
    Str:D $sql, @cols,
    Str:D :$fn = 'corr',
    Str:D :$method = 'pearson',
    Str:D :$label = 'index',
    --> Str
) is export {
    die Duckula::X::Frame.new(reason => 'stats matrix needs at least one column')
        unless @cols.elems;
    my Str $agg = check-matrix-fn($fn);
    my Str $how = check-corr-method($method);
    my Str $lab = quote-ident($label);

    my Bool $ranked = $agg eq 'corr' && $how eq 'spearman';

    # 辅助列避让：rank 别名 + 标签列都可能在源数据里出现。
    my @known = @cols.map(*.Str);
    my Str $tag = aux-name('__duckula_label', @known);
    my Str $tagq = quote-ident($tag);

    my Str $inner;
    my @pair-names;   # 每列在（可能的）rank 投影里对应的实际表达式列名
    if $ranked {
        my @ranks;
        for @cols.kv -> $i, $c {
            my Str $r = aux-name('__duckula_r' ~ $i, @known);
            # NULL 行的秩必须是 NULL：否则 corr 会把「NULL 排位」当成真实秩，
            # 和 pandas 的 pairwise 剔除语义不符（实测会算出 0.6 而不是 -1）。
            my Str $qc = quote-ident($c.Str);
            @ranks.push: 'CASE WHEN ' ~ $qc ~ ' IS NULL THEN NULL ELSE '
                       ~ 'rank() OVER (ORDER BY ' ~ $qc ~ ') END AS '
                       ~ quote-ident($r);
            @pair-names.push: $r;
        }
        $inner = 'SELECT ' ~ @ranks.join(', ') ~ ' FROM (' ~ $sql ~ ') AS __duckula_rankbase';
    }
    else {
        @pair-names = @cols.map(*.Str);
        $inner = $sql;
    }

    # 每个输出列 c：对标签 r，取第 r 行 / 第 c 列的统计量。
    my @items;
    for @cols.kv -> $ci, $col {
        my Str $cq = quote-ident($col.Str);
        my @branches;
        for @cols.kv -> $ri, $rowcol {
            my Str $a = quote-ident(@pair-names[$ri]);
            my Str $b = quote-ident(@pair-names[$ci]);
            my Str $call = $ranked
                ?? "corr({$a}, {$b})"
                !! "{$agg}({$a}, {$b})";
            @branches.push: 'WHEN ' ~ sql-literal($rowcol.Str) ~ ' THEN ' ~ $call;
        }
        @items.push: 'CASE ' ~ $tagq ~ ' ' ~ @branches.join(' ')
                   ~ ' END AS ' ~ $cq;
    }

    my Str $labels = 'VALUES ' ~ @cols.map({ '(' ~ sql-literal($_.Str) ~ ')' }).join(', ');
    my @order;
    for @cols.kv -> $i, $c {
        @order.push: 'WHEN ' ~ sql-literal($c.Str) ~ ' THEN ' ~ $i;
    }
    my Str $order = @order.join(' ');

    'SELECT ' ~ $tagq ~ ' AS ' ~ $lab ~ ', ' ~ @items.join(', ')
      ~ ' FROM (' ~ $inner ~ ') AS __duckula_statbase'
      ~ ' CROSS JOIN (' ~ $labels ~ ') AS __duckula_tags(' ~ $tagq ~ ')'
      ~ ' GROUP BY ' ~ $tagq
      ~ ' ORDER BY CASE ' ~ $tagq ~ ' ' ~ $order ~ ' END';
}

#| 单行多列：skew / kurt。列名保持原样，调用方直接读第一行。
our sub row-stats-sql(Str:D $sql, @cols, Str:D $fn --> Str) is export {
    die Duckula::X::Frame.new(reason => 'row stats needs at least one column')
        unless @cols.elems;
    my Str $agg = check-row-fn($fn);
    my @items = @cols.map({
        "{$agg}(" ~ quote-ident($_.Str) ~ ') AS ' ~ quote-ident($_.Str)
    });
    'SELECT ' ~ @items.join(', ') ~ ' FROM (' ~ $sql ~ ') AS __duckula_rowstats';
}

# ------------------------------------------------------------ top-n

#| 按 @by 列排序取前 $n 行，保留全部原列。
#| keep=first（默认）按扫描序破平局，last 反扫描序，all 用 rank 保留并列。
our sub top-n-sql(
    Str:D $sql, @by, Int:D $n,
    Bool:D :$desc = True,
    Str:D  :$keep = 'first',
    :$known = (),
    --> Str
) is export {
    die Duckula::X::Frame.new(reason => 'top-n needs a non-negative count, got ' ~ $n)
        if $n < 0;
    die Duckula::X::Frame.new(reason => 'top-n needs at least one sort column')
        unless @by.elems;
    my Str $k = check-keep($keep);

    # n=0 不需要辅助列，直接空结果；也避开 EXCLUDE 要求列存在的细节。
    return 'SELECT * FROM (' ~ $sql ~ ') AS __duckula_topempty LIMIT 0' if $n == 0;

    my @names = $known.map(*.Str);
    my Str $scan = aux-name('__duckula_scan', @names);
    my Str $ord  = aux-name('__duckula_ord', @names);
    my Str $scanq = quote-ident($scan);
    my Str $ordq  = quote-ident($ord);

    my Str $dir = $desc ?? 'DESC' !! 'ASC';
    # first 取扫描序最前的同值行（scan ASC），last 取最后的（scan DESC）。
    my Str $tie = $keep eq 'last' ?? 'DESC' !! 'ASC';
    my Str $sort = @by.map({ quote-ident($_.Str) ~ ' ' ~ $dir }).join(', ');

    my Str $rank-fn = $keep eq 'all' ?? 'rank()' !! 'row_number()';
    my Str $rank-order = $keep eq 'all'
        ?? $sort
        !! $sort ~ ', ' ~ $scanq ~ ' ' ~ $tie;

    'SELECT * EXCLUDE (' ~ $scanq ~ ', ' ~ $ordq ~ ') FROM ('
      ~ 'SELECT *, ' ~ $rank-fn ~ ' OVER (ORDER BY ' ~ $rank-order ~ ') AS ' ~ $ordq
      ~ ' FROM (SELECT *, row_number() OVER () AS ' ~ $scanq
      ~ ' FROM (' ~ $sql ~ ') AS __duckula_topbase) AS __duckula_topscan'
      ~ ') AS __duckula_topranked WHERE ' ~ $ordq ~ ' <= ' ~ $n
      ~ ' ORDER BY ' ~ $ordq;
}

# ------------------------------------------------------------ 跨 Frame 对齐统计

#| 两个 Frame 按 key 对齐后求一列对的相关/协方差。
#| spearman 先投影 rank 再聚合（同矩阵的理由）。
our sub align-stat-sql(
    Str:D $lsql, Str:D $rsql, @keys,
    Str:D $lcol, Str:D $rcol,
    Str:D $fn, Str:D :$method = 'pearson',
    --> Str
) is export {
    die Duckula::X::Frame.new(reason => 'align needs at least one key column')
        unless @keys.elems;
    my Str $agg = $fn eq 'cov' ?? cov-fn() !! check-matrix-fn($fn);
    my Str $how = check-corr-method($method);

    my Str $on = @keys.map({
        'l.' ~ quote-ident($_.Str) ~ ' = r.' ~ quote-ident($_.Str)
    }).join(' AND ');
    my Str $join = ' FROM (' ~ $lsql ~ ') AS l'
                 ~ ' FULL OUTER JOIN (' ~ $rsql ~ ') AS r ON ' ~ $on;

    my Str $le = 'l.' ~ quote-ident($lcol);
    my Str $re = 'r.' ~ quote-ident($rcol);

    my Str $expr;
    if $how eq 'spearman' {
        die Duckula::X::Frame.new(
            reason => 'spearman is only available for corr, not cov'
        ) unless $agg eq 'corr';
        $expr = 'corr(__duckula_lr, __duckula_rr)';
    }
    else {
        $expr = "{$agg}({$le}, {$re})";
    }

    if $how eq 'spearman' {
        'SELECT ' ~ $expr ~ ' AS __duckula_stat FROM ('
          ~ 'SELECT CASE WHEN ' ~ $le ~ ' IS NULL THEN NULL ELSE '
                   ~ 'rank() OVER (ORDER BY ' ~ $le ~ ') END AS __duckula_lr, '
          ~ 'CASE WHEN ' ~ $re ~ ' IS NULL THEN NULL ELSE '
                   ~ 'rank() OVER (ORDER BY ' ~ $re ~ ') END AS __duckula_rr'
          ~ $join ~ ') AS __duckula_alignrank';
    }
    else {
        'SELECT ' ~ $expr ~ ' AS __duckula_stat' ~ $join;
    }
}
