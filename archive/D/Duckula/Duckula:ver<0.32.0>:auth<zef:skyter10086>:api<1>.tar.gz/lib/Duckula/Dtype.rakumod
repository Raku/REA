use v6.d;
use Duckula::SQL;
use Duckula::Clean;
use Duckula::Expr;
use Duckula::TimeSeries;
use Duckula::X::Frame;

#| dtype 系统（v0.30.0）：nullable 类型 + Categorical。
#|
#| DuckDB 自己的类型全都可空，pandas 却区分 `int64`（遇到 NA 报错）与
#| `Int64`（允许 NA），还有 `category` 这种带类别表的逻辑类型。Duckula 不
#| 另造一套内存模型：dtype 只是**贴在列上的一层逻辑元数据**，物理存储
#| 和计算仍然是 DuckDB 的 SQL 类型。所以：
#|
#|   - `.dtypes` 继续返回原始 DuckDB 类型串（老 API 不变）；
#|   - `.schema` 返回列名 → Duckula::Dtype 对象（nullable / categories 等）；
#|   - `cast('x' => dtype('Int64'))` 与 `cast('x' => 'BIGINT')` 都合法。
#|
#| Categorical 在 SQL 侧统一存成 VARCHAR，类别顺序保存在 Dtype 元数据里，
#| `.cat.codes` 用 CASE 现算，不写任何隐藏列。类别值走 `sql-literal`，
#| 逻辑类型名走白名单 —— 延续 §9 的防注入模型。
#|
#| 本文件与 IndexLabels 一样不用 `unit module`：类名必须是
#| `Duckula::Dtype` 而不是 `Duckula::Dtype::Dtype`，`is export` 照常可用。

#| 一个逻辑 dtype。`nullable=False` 在 cast 时会真的检查源列有没有 NULL；
#| `is-categorical` 为真时 `categories` / `ordered` 决定编码顺序。
class Duckula::Dtype {
    has Str $.name is required;
    has Str $.sql-type is required;
    has Bool $.nullable = True;
    has Bool $.ordered = False;
    has List $.categories = ();

    method is-categorical(--> Bool) { $!name eq 'category' }
    method Str(--> Str) { $!name }
    method gist(--> Str) {
        my $s = $!name;
        $s ~= '[' ~ $!categories.join(', ') ~ ']' if self.is-categorical && $!categories.elems;
        $s ~= ' (ordered)' if $!ordered;
        $s ~= ' (non-nullable)' unless $!nullable;
        $s;
    }
}

#| pandas / numpy / Arrow 常见写法 → (DuckDB 物理类型, nullable 默认值)。
#| 小写 numpy 风格默认非空，首字母大写的 pandas 扩展 dtype 默认可空。
my constant %ALIAS = (
    int8   => ('TINYINT', False),   Int8   => ('TINYINT', True),
    int16  => ('SMALLINT', False),  Int16  => ('SMALLINT', True),
    int32  => ('INTEGER', False),   Int32  => ('INTEGER', True),
    int64  => ('BIGINT', False),    Int64  => ('BIGINT', True),
    uint8  => ('UTINYINT', False),  UInt8  => ('UTINYINT', True),
    uint16 => ('USMALLINT', False), UInt16 => ('USMALLINT', True),
    uint32 => ('UINTEGER', False),  UInt32 => ('UINTEGER', True),
    uint64 => ('UBIGINT', False),   UInt64 => ('UBIGINT', True),
    float32 => ('FLOAT', False),    Float32 => ('FLOAT', True),
    float64 => ('DOUBLE', False),   Float64 => ('DOUBLE', True),
    bool    => ('BOOLEAN', False),  boolean => ('BOOLEAN', True),
    Boolean => ('BOOLEAN', True),
    str     => ('VARCHAR', True),   string  => ('VARCHAR', True),
    String  => ('VARCHAR', True),   object  => ('VARCHAR', True),
    date    => ('DATE', True),      Date    => ('DATE', True),
    time    => ('TIME', True),      Time    => ('TIME', True),
    json    => ('JSON', True),      JSON    => ('JSON', True),
    blob    => ('BLOB', True),      BLOB    => ('BLOB', True),
    uuid    => ('UUID', True),      UUID    => ('UUID', True),
    'timedelta64[ns]' => ('INTERVAL', True),
    'datetime64[ns]'  => ('TIMESTAMP', True),
    'timestamptz'     => ('TIMESTAMPTZ', True),
);

#| DuckDB 物理类型 → 逻辑名字。没见过的类型原样保留大写名。
my constant %REVERSE = (
    TINYINT => 'Int8', SMALLINT => 'Int16', INTEGER => 'Int32', BIGINT => 'Int64',
    UTINYINT => 'UInt8', USMALLINT => 'UInt16', UINTEGER => 'UInt32', UBIGINT => 'UInt64',
    FLOAT => 'Float32', DOUBLE => 'Float64', BOOLEAN => 'boolean',
    VARCHAR => 'string', DATE => 'date', TIME => 'time', TIMESTAMP => 'datetime64[ns]',
    TIMESTAMPTZ => 'timestamptz', INTERVAL => 'timedelta64[ns]',
    JSON => 'json', BLOB => 'blob', UUID => 'uuid',
);

#| 构造 dtype。接受 Dtype 对象、pandas/numpy 别名，或直接写 DuckDB 类型名。
#|
#|   dtype('Int64')                       可空整数
#|   dtype('int64')                       非空整数（cast 时检查 NULL）
#|   dtype('category', categories => <a b>, ordered => True)
#|   dtype('datetime64[ns, Asia/Shanghai]')  带时区的 aware 时间
our sub dtype(
    $spec,
    :@categories = (),
    Bool :$ordered = False,
    Bool :$nullable,
    --> Duckula::Dtype
) is export {
    my Bool $null-given = $nullable.defined;
    my Bool $null-value = $null-given ?? $nullable !! True;

    if $spec ~~ Duckula::Dtype {
        return $spec unless @categories.elems || $ordered || $null-given;
        return Duckula::Dtype.new(
            name       => $spec.name,
            sql-type   => $spec.sql-type,
            nullable   => $null-given ?? $null-value !! $spec.nullable,
            ordered    => $ordered || $spec.ordered,
            categories => (@categories.elems ?? @categories.map(*.Str).List !! $spec.categories),
        );
    }

    die Duckula::X::Frame.new(reason => 'dtype: type spec cannot be empty')
        unless $spec.defined && $spec.Str.trim.chars;

    my Str $s = $spec.Str.trim;
    my Str $lc = $s.lc;

    if $lc eq 'category' || $lc eq 'categorical' {
        return Duckula::Dtype.new(
            name       => 'category',
            sql-type   => 'VARCHAR',
            nullable   => $null-given ?? $null-value !! True,
            ordered    => $ordered,
            categories => @categories.map(*.Str).List,
        );
    }

    # datetime64[ns, <zone>]：时区名复用已有的 IANA 白名单（check-tz）。
    if $s ~~ /^ 'datetime64' \s* '[' \s* 'ns' \s* ',' \s* $<tz>=(\S+) \s* ']' $/ {
        my Str $tz = check-tz(~$<tz>);
        return Duckula::Dtype.new(
            name       => "datetime64[ns, $tz]",
            sql-type   => 'TIMESTAMPTZ',
            nullable   => $null-given ?? $null-value !! True,
        );
    }

    if %ALIAS{$s}:exists {
        my ($sql, $default-null) = %ALIAS{$s};
        return Duckula::Dtype.new(
            name       => $s,
            sql-type   => $sql,
            nullable   => $null-given ?? $null-value !! $default-null,
        );
    }

    # 原始 SQL 类型名必须过既有白名单：CAST(x AS ?) 不成立，类型文本
    # 拼进 SQL 前必须自己保证它只能是类型名。
    my Str $raw = check-type-name($s);
    Duckula::Dtype.new(
        name     => $raw.uc,
        sql-type => $raw,
        nullable => $null-given ?? $null-value !! True,
    );
}

#| DESCRIBE 拿到的 DuckDB 类型串 → Dtype 对象。
our sub dtype-from-sql(Str:D $sql --> Duckula::Dtype) is export {
    my Str $t = $sql.trim;
    return dtype('string') unless $t.chars;
    my Str $name = %REVERSE{$t.uc}:exists ?? %REVERSE{$t.uc} !! $t.uc;
    Duckula::Dtype.new(name => $name, sql-type => $t, nullable => True);
}

#| cast / astype 的统一入口：Dtype 原样用，其余字符串过 dtype()。
our sub as-dtype($spec --> Duckula::Dtype) is export {
    $spec ~~ Duckula::Dtype ?? $spec !! dtype($spec);
}

#| 类别未指定时从数据里推断（pandas `astype('category')` 的行为）。
#| 用 CAST(... AS VARCHAR) 统一类别值的表示，NULL 不算一个类别。
our sub infer-categories($session, Str:D $source-sql, Str:D $col, @params = () --> List) is export {
    my Str $q = 'SELECT DISTINCT CAST(' ~ quote-ident($col) ~ ' AS VARCHAR) '
              ~ 'FROM (' ~ $source-sql ~ ') AS __duckula_cat '
              ~ 'WHERE ' ~ quote-ident($col) ~ ' IS NOT NULL ORDER BY 1';
    my $res = @params.elems
        ?? $session.conn.query($q, |@params.List)
        !! $session.conn.query($q);
    $res.arrays.List.grep({ $_[0].defined }).map({ $_[0].Str }).List;
}

#| 推断缺失的 categories；其他 Dtype 原样返回。
our sub resolve-dtype($session, Str:D $source-sql, Str:D $col,
                      Duckula::Dtype:D $d, @params = () --> Duckula::Dtype) is export {
    return $d unless $d.is-categorical && !$d.categories.elems;
    $d.clone(categories => infer-categories($session, $source-sql, $col, @params));
}

#| 非空约束：dtype('int64') / :strict 时检查源列有没有 NULL。
our sub check-dtype-nulls($session, Str:D $source-sql, Str:D $col,
                          Duckula::Dtype:D $d, @params = (), Bool:D :$strict = False --> Nil) is export {
    return unless $strict || !$d.nullable;
    # count() 是 nullable BIGINT，rakupp 上有 bitmap 解码缺陷；VARCHAR 稳定。
    my Str $q = 'SELECT CAST(count(*) FILTER (WHERE ' ~ quote-ident($col)
              ~ ' IS NULL) AS VARCHAR) FROM (' ~ $source-sql
              ~ ') AS __duckula_dtype_nulls';
    my $res = @params.elems
        ?? $session.conn.query($q, |@params.List)
        !! $session.conn.query($q);
    my Int $n = $res.arrays.List[0][0].Int;
    die Duckula::X::Frame.new(
        reason => "cannot cast column '$col' to non-nullable dtype '{$d.name}': "
                ~ "$n NULL value(s) present"
    ) if $n;
}

#| Categorical 用的列表达式。类别值走字面量，列名走 quote-ident。
#| 未知值映射到 NULL，与 pandas 的 CategoricalDtype 行为一致。
our sub categorical-expr(Str:D $col, @categories --> Duckula::Expr) is export {
    my @when = @categories.kv.map(-> $i, $c {
        'WHEN ' ~ quote-ident($col) ~ ' = ' ~ sql-literal($c.Str) ~ ' THEN ' ~ $i
    });
    my Str $sql = @when.elems
        ?? 'CASE ' ~ @when.join(' ') ~ ' ELSE NULL END'
        !! 'CAST(NULL AS INTEGER)';
    Duckula::Expr.new(sql => $sql, columns => Set.new($col));
}

#| 生成一个 cast 投影项（不带别名，调用方自己加 `AS "col"`）。
our sub cast-expr-for(Str:D $col, Duckula::Dtype:D $d --> Str) is export {
    my Str $q = quote-ident($col);
    return 'CAST(' ~ $q ~ ' AS ' ~ check-type-name($d.sql-type) ~ ')'
        unless $d.is-categorical;

    my Str $v = 'CAST(' ~ $q ~ ' AS VARCHAR)';
    return $v unless $d.categories.elems;

    my @lits = $d.categories.map({ sql-literal($_.Str) });
    '(CASE WHEN ' ~ $q ~ ' IS NULL THEN NULL WHEN ' ~ $v
        ~ ' IN (' ~ @lits.join(', ') ~ ') THEN ' ~ $v ~ ' ELSE NULL END)';
}

#| Series.cat 访问器。和 StrAccessor / DtAccessor 一样不提 Series 类型名，
#| 只持列名、dtype 和「Expr → Series」闭包，避免 resolver 前向引用崩溃。
class Duckula::CatAccessor {
    has Str $.col is required;
    has Duckula::Dtype $.dtype is required;
    has $.apply is required;

    method categories(--> List) { $!dtype.categories.List }
    method ordered(--> Bool) { $!dtype.ordered }
    method codes() { $!apply.(categorical-expr($!col, $!dtype.categories)) }
}
