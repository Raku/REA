use v6.d;
use DB::DuckDB::Arrow;
use Duckula::X::Frame;
use Duckula::ArrowIPC;

#| Arrow 视图：一张 Frame 的类型描述（`Schema`）加上逐块的数据（`Chunk`）。
#|
#| 这是把 Duckula 的结果交给外部消费者的出口 —— Python 侧的
#| `pyarrow.RecordBatch._import_from_c(array_addr, schema_addr)`、Polars 的
#| Arrow 入口，或者任何按 Arrow C data interface 读 buffer 的库。两者必须
#| 成对出现：只有 array 没有 schema，等于一堆没人能命名的 buffer。
#|
#| 生命周期：Arrow 的 schema 引用着它构建时的 result，所以本类**持有
#| result**，`free` 时才连同 schema 一起放掉。这也是为什么它不直接返回
#| `DB::DuckDB::Arrow::Schema` —— 那样调用方拿到的 schema 会比 result 活得
#| 更久，读到的是已经释放的内存。
#|
#|     my $t = $df.arrow;
#|     say $t.schema.gist;
#|     $t.chunks: -> $chunk { ... };
#|     $t.free;
unit class Duckula::Arrow;

has $!result;
has $!schema;
has @!names;
has Bool $!freed = False;

submethod BUILD(:$!result!, :$!schema!, :@!names) { }

#| 从一个已经存在的 Frame 建 Arrow 视图。
#|
#| 用鸭子类型取 `$frame.session` / `$frame.relation-sql`，不 `use
#| Duckula::Frame`：Frame 会 `use` 本模块，反向依赖会形成预编译循环。
method from-frame($frame --> Duckula::Arrow) {
    my Str $sql = $frame.relation-sql;
    my $res = $frame.session.conn.query($sql);
    my $sch = arrow-schema($res);
    self.new(result => $res, schema => $sch, names => $res.names.List);
}

#| 结果里的列名，顺序与 schema 的 children 一致。
method names(--> List) { @!names.List }

#| `DB::DuckDB::Arrow::Schema`：`.format` / `.fields` / `.column($i)`。
method schema(--> Mu) { $!schema }

#| 每列一条 `name` + `format`（嵌套类型带 `children`）。
method fields(--> List) { $!schema.fields }

#| 某列的 Arrow format 字符串；列名不存在时当场报错。
method format-of(Str:D $column --> Str) {
    my $i = @!names.first($column, :k);
    die Duckula::X::Frame.new(
        reason => "arrow: no column '$column' (have: {@!names.join(', ')})"
    ) unless $i.defined;
    $!schema.column($i.Int).format;
}

#| 逐块遍历，每块给一个 `Chunk`。块在回调返回后自动释放，所以别把它存
#| 下来 —— 需要留下数据就在回调里拷出去。
#|
#| 回调可以只要 chunk（`-> $chunk { ... }`），也可以再要一个块序号
#| （`-> $chunk, $i { ... }`）。
method chunks(&code --> Nil) {
    self!check-usable('chunks');
    my Int $arity = &code.arity;
    with-arrow-table($!result, -> $schema, $chunk, $i {
        $arity >= 2 ?? code($chunk, $i) !! code($chunk);
    });
    Nil;
}

#| 写成 Arrow IPC 文件，交给 pyarrow / polars / DuckDB 直接读。
#|
#| 这是跨进程交换的出口：C data interface 的裸指针只在本进程有效，而 IPC
#| 文件是自描述的字节能落到磁盘。`file` 格式（.arrow / .feather）带 footer
#| 索引、可随机访问；`stream` 格式（.arrows）只是一串 message 加结尾标记，
#| 适合管道。
#|
#|     $df.arrow.write-ipc('out.arrow');
#|     $df.arrow.write-ipc('out.arrows', :format<stream>);
method write-ipc(Str:D $path, Str:D :$format = 'file' --> Nil) {
    self!check-usable('write-ipc');
    Duckula::ArrowIPC::write-ipc(self, $path, :$format);
    Nil;
}

#| 编码成内存里的 IPC 字节，交给别的进程 / 别的语言读。
#|
#| 与 `write-ipc` 的关系：编码逻辑完全同一份，只是 sink 换成 Buf。默认
#| `stream` 格式，因为内存里没人需要 footer 索引。
#|
#|     my Buf $bytes = $df.arrow.ipc-buf;
#|     # Python: pa.ipc.open_stream(bytes).read_all()
#|
#| 这是 C data interface 裸指针的替代品 —— 裸指针只在导出它的进程里有效，
#| 字节流则能跨进程。要走零拷贝才需要裸指针。
method ipc-buf(Str:D :$format = 'stream' --> Buf) {
    self!check-usable('ipc-buf');
    Duckula::ArrowIPC::ipc-buf(self, :$format);
}

#| 释放 schema 与背后的 result；幂等。
method free(--> Nil) {    return if $!freed;
    $!freed = True;
    $!schema.free if $!schema.defined;
    my $r = $!result;
    $r.free if $r.defined && $r.can('free');
    Nil;
}

method !check-usable(Str:D $what --> Nil) {
    die Duckula::X::Frame.new(
        reason => "arrow: $what was called after free()"
    ) if $!freed;
}

method gist(--> Str) {
    "Duckula::Arrow({@!names.elems} columns){$!freed ?? ' [freed]' !! ''}";
}
