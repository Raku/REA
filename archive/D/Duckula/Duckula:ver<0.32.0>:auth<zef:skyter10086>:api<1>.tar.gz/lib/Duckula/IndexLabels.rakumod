use v6.d;
use Duckula::SQL;
use Duckula::Expr;
use Duckula::X::Frame;

# ============================================================
# 真正的 Index / MultiIndex 值对象（v0.28.0）
# ============================================================
#
# 之前 v0.21/0.22 只给了两样东西：显式行号列（Polars 的 with_row_index）
# 和 index-cols 元数据（key 列清单）。它们足够做 iloc 和按 key 对齐，
# 但还不是一个 pandas 意义上的 Index —— 没有 names/nlevels，也没有
# loc/xs/swaplevel 这一套标签算子。
#
# 这里补的 IndexLabels 不碰 SQL 的真相：level 就是普通 DuckDB 列，
# 无 key 时 level 是临时生成的 0 基行号。对象只持有来源（Frame 或
# LazyFrame）+ level 列名，**只有在真的取值时才执行查询**。
#
# 命名上刻意避开 Duckula::Index（那是 SQL 构件模块），所以类叫
# Duckula::IndexLabels，对外由 Frame.index / Series.index 返回。

#| 把标量 / 元组标签归一成与 level 数等长的列表。
our sub label-values($label, Int:D $nlevels --> List) is export {
    my @v = $label ~~ Positional:D ?? $label.List !! ($label,);
    die Duckula::X::Frame.new(
        reason => "index label needs $nlevels value(s), got {@v.elems}"
    ) unless @v.elems == $nlevels;
    @v.List;
}

#| level 可以是位置（Int，负数从末尾算）或列名。
our sub level-index(@levels, $level --> Int) is export {
    my Int $i = -1;
    if $level ~~ Int:D {
        $i = $level < 0 ?? $level + @levels.elems !! $level;
    }
    else {
        my Str $name = ~$level;
        for @levels.kv -> $k, $n {
            if $n eq $name { $i = $k; last }
        }
    }
    die Duckula::X::Frame.new(
        reason => "no index level '$level'; available: {@levels.join(', ')}"
    ) unless 0 <= $i < @levels.elems;
    $i;
}

#| 摘掉一个 level，返回剩下的列名清单。
our sub remove-level(@levels, $level --> List) is export {
    my Int $i = level-index(@levels, $level);
    my @out;
    for @levels.kv -> $k, $n { @out.push($n) unless $k == $i }
    @out.List;
}

#| 交换两个 level 的位置，返回新的列名清单（纯元数据）。
our sub swap-levels(@levels, $a, $b --> List) is export {
    my Int $i = level-index(@levels, $a);
    my Int $j = level-index(@levels, $b);
    my @out = @levels.List;
    @out[$i] = @levels[$j];
    @out[$j] = @levels[$i];
    @out.List;
}

#| 把完整标签编译成过滤表达式；列名过 quote-ident，值走 sql-literal。
our sub index-loc-expr(@levels, $label --> Duckula::Expr) is export {
    my @vals = label-values($label, @levels.elems);
    my @pred = @levels.kv.map(-> $i, $n { col($n) == @vals[$i] });
    @pred.elems == 1 ?? @pred[0] !! @pred.reduce({ $^a & $^b });
}

class Duckula::IndexLabels does Iterable {
    # 二选一：eager Frame 或 LazyFrame。Lazy 路径在真的取值时才 collect。
    has $.frame;
    has $.lazy-frame;
    has List $.levels = ();
    has Bool $.row-based = False;
    has Str $.row-name = 'index';
    has Int $.row-offset = 0;

    submethod BUILD(:$!frame, :$!lazy-frame, :$!levels = (), :$!row-based = False,
                    :$!row-name = 'index', :$!row-offset = 0) {
        $!levels = $!levels.List;
    }

    method !resolved-frame() {
        my $f = $!frame.defined ?? $!frame !! ($!lazy-frame.defined ?? $!lazy-frame.collect !! Nil);
        die Duckula::X::Frame.new(reason => 'IndexLabels has no source Frame') unless $f.defined;
        $f;
    }

    #| 单个 level 的 raw Series。行号 level 走 Frame 的旧 :name/:offset 形态，
    #| 避免这里递归回 IndexLabels。
    method !series-at(Int:D $i) {
        my $f = self!resolved-frame;
        $!row-based
            ?? $f.index(:name($!row-name), :offset($!row-offset))
            !! $f.column($!levels[$i]);
    }

    #| 用于 SQL 计数的来源 Frame（加好行号列）。
    method !sql-frame() {
        my $f = self!resolved-frame;
        $!row-based ?? $f.with-row-index(:name($!row-name), :offset($!row-offset)) !! $f;
    }

    method names(--> List) {
        $!row-based ?? ($!row-name,).List !! $!levels
    }

    method name() {
        die Duckula::X::Frame.new(
            reason => "name needs exactly one level; got {self.nlevels} "
                    ~ "({self.names.join(', ')})"
        ) unless self.nlevels == 1;
        self.names[0];
    }

    method nlevels(--> Int) { $!row-based ?? 1 !! $!levels.elems }

    method is-row-based(--> Bool) { $!row-based }

    method elems(--> Int) { self!series-at(0).elems }

    #| 单 level 返回标量列表；多 level 返回 List of List（一个标签一行）。
    method to-list(Bool :$typed = False --> List) {
        my Int $n = self.nlevels;
        return self!series-at(0).to-list(:$typed) if $n == 1;

        my @cols = (^$n).map({ self!series-at($_).to-list(:$typed).Array }).Array;
        my @out;
        for ^self.elems -> $r {
            @out.push: (^$n).map({ @cols[$_][$r] }).List;
        }
        @out.List;
    }

    method rows(--> List) {
        self.to-list.map({
            ($_ ~~ Positional:D ?? $_.List !! ($_,).List).Array
        }).Array;
    }

    method iterator() { self.to-list.iterator }
    method list() { self.to-list }

    method sum(--> Mu) { self!series-at(0).sum }
    method min(--> Mu) { self!series-at(0).min }
    method max(--> Mu) { self!series-at(0).max }
    method mean(--> Mu) { self!series-at(0).mean }

    method at(Int $i --> Mu) { self!series-at(0).at($i) }

    #| 标签唯一性。多 level 用 DISTINCT 整行比较，不用拼接字符串。
    method is-unique(--> Bool) {
        my $f = self!sql-frame;
        my Str $cols = $!row-based
            ?? quote-ident($!row-name)
            !! $!levels.map({ quote-ident($_) }).join(', ');
        my Str $sql = 'SELECT (SELECT count(*) FROM (' ~ $f.relation-sql ~ '))'
                    ~ ' = (SELECT count(*) FROM (SELECT DISTINCT ' ~ $cols
                    ~ ' FROM (' ~ $f.relation-sql ~ '))) AS u';
        my @rows = $f.session.sql($sql).rows;
        @rows.elems ?? (@rows[0][0] ?? True !! False) !! False;
    }

    #| 标签是否存在。值一律走 sql-literal 转义。
    method contains($label --> Bool) {
        my @vals = label-values($label, self.nlevels);
        my @names = self.names.List;
        my Str $pred = @names.kv.map(-> $i, $n {
            quote-ident($n) ~ ' = ' ~ sql-literal(@vals[$i])
        }).join(' AND ');
        my $f = self!sql-frame;
        my @rows = $f.session.sql(
            'SELECT EXISTS(SELECT 1 FROM (' ~ $f.relation-sql ~ ') WHERE ' ~ $pred ~ ') AS e'
        ).rows;
        @rows.elems ?? (@rows[0][0] ?? True !! False) !! False;
    }

    method get-level-values($level) {
        die Duckula::X::Frame.new(
            reason => 'get-level-values is not available for a generated row index'
        ) if $!row-based;
        self!series-at(level-index($!levels, $level));
    }

    #| 交换层只改对象里的 level 顺序，不碰 SQL。要连 Frame.index-cols
    #| 一起换，请用 Frame.swaplevel。
    method swaplevel($a = 0, $b = 1 --> Duckula::IndexLabels) {
        die Duckula::X::Frame.new(
            reason => 'swaplevel needs at least two levels'
        ) if self.nlevels < 2;
        my @lv = swap-levels(self.names.List, $a, $b);
        Duckula::IndexLabels.new(
            frame      => $!frame,
            lazy-frame => $!lazy-frame,
            levels     => @lv,
        );
    }

    method droplevel($level = -1 --> Duckula::IndexLabels) {
        die Duckula::X::Frame.new(
            reason => 'droplevel is not available for a generated row index'
        ) if $!row-based;
        my @lv = remove-level($!levels, $level);
        @lv.elems
            ?? Duckula::IndexLabels.new(
                   frame => $!frame, lazy-frame => $!lazy-frame, levels => @lv)
            !! ($!frame.defined ?? $!frame.index !! $!lazy-frame.index);
    }

    method gist(--> Str) { "IndexLabels({self.names.join(', ')})" }
    method Str(--> Str) { self.gist }
}
