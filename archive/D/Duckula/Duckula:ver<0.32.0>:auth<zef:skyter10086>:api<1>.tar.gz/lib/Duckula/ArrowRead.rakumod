use v6.d;
need Arrow::IPC::Read;
need Arrow::IPC::Format;
use Duckula::SQL;
use Duckula::X::Frame;
use Duckula::Frame;

#| Arrow IPC 读侧适配：字节解码由 Arrow::IPC 完成，这里只负责 DuckDB 类型
#| 映射、临时表创建与 Appender 灌入，以及进程内解码缓存。
unit module Duckula::ArrowRead;

our sub describe-ipc(Str:D $path --> Hash) is export {
    Arrow::IPC::Read::describe-ipc($path)
}

#| 一个 Arrow 字段在 DuckDB 里应该是什么类型。
#|
#| 目标是**往返不丢**：`$df.to-arrow` 之后再读回来，列类型应当与原来一致
#| （`BIGINT` 还是 `BIGINT`，`DECIMAL(18,4)` 还是 `DECIMAL(18,4)`）。所以
#| 这里刻意不用「差不多就行」的宽类型。
my sub duck-type($f --> Str) {
    my %t = Arrow::IPC::Format::parse-format($f.format);

    given %t<kind> {
        when 'null'   { return 'VARCHAR' }
        when 'bool'   { return 'BOOLEAN' }
        when 'utf8'   { return 'VARCHAR' }
        when 'binary' { return 'BLOB' }
        when 'list'   { return duck-type($f.children[0]) ~ '[]' }
        when 'struct' {
            my @names = Arrow::IPC::Read::struct-names($f);
            my @kids = @($f.children);
            return 'STRUCT()' unless @kids.elems;
            return 'STRUCT(' ~ @kids.kv.map(-> $i, $c {
                quote-ident(@names[$i]) ~ ' ' ~ duck-type($c)
            }).join(', ') ~ ')';
        }
        when 'map' {
            my @kids = @($f.children);
            die "arrow-read: column '{$f.name}' is a Map without an entries field"
                unless @kids.elems && @(@kids[0].children).elems >= 2;
            return 'MAP(' ~ duck-type(@kids[0].children[0]) ~ ', '
                          ~ duck-type(@kids[0].children[1]) ~ ')';
        }

        default {
            given %t<tag> {
                when 2 {
                    my Str $base = %(8 => 'TINYINT', 16 => 'SMALLINT',
                                     32 => 'INTEGER', 64 => 'BIGINT'){%t<bitwidth>}
                        // die "arrow-read: unsupported Int bitWidth {%t<bitwidth>}";
                    return %t<signed> ?? $base !! 'U' ~ $base;
                }
                when 3 {
                    return %t<precision> == 2 ?? 'DOUBLE' !! 'REAL';
                }
                when 7 {
                    die "arrow-read: DECIMAL({%t<precision>},{%t<scale>}) exceeds "
                      ~ 'DuckDB\'s 38-digit limit'
                        if %t<precision> > 38;
                    return "DECIMAL({%t<precision>},{%t<scale>})";
                }
                when 8  { return 'DATE' }
                when 9  { return 'TIME' }
                when 10 {
                    return (%t<timezone> // '').chars ?? 'TIMESTAMPTZ' !! 'TIMESTAMP';
                }
                when 11 {
                    # Appender 的 cast 不支持 VARCHAR -> INTERVAL（DuckDB 只
                    # 实现了 SQL 侧的 cast），所以这里落成文本，用户要算就
                    # 自己 `::INTERVAL`。转成整数会丢语义：月不是固定天数。
                    return 'VARCHAR';
                }
                when 15 { return 'BLOB' }
                when 18 { return 'BIGINT' }
                default {
                    die "arrow-read: no DuckDB type for Arrow type '{$f.format}'";
                }
            }
        }
    }
}

#| 把一个字符串写成 DuckDB 容器字面量里的样子。
#|
#| 规矩不是 SQL 标准的「单引号双写」，而是 DuckDB 自己打印 VARCHAR 时的
#| 转义：反斜杠双写、单引号写成 `\'`。两种写法混用不会报错，只会**静默
#| 给出错误的字符串**（`'q''r'` 被读成 `qr`），所以必须与打印格式对齐，
#| 反过来的 cast 才认得回去。
sub quoted-str(Str $s --> Str) {
    "'" ~ $s.subst('\\', '\\\\', :g).subst("'", "\\'", :g) ~ "'";
}

#| 把一个值渲染成 DuckDB 的字面量文本，供 LIST / STRUCT / MAP 用。
#|
#| 三种容器各有各的写法，都是 DuckDB **能 cast 回来**的形式：
#|
#|     LIST    [1, 2, NULL]
#|     STRUCT  {'name': <value>, ...}
#|     MAP     {'key'=<value>, ...}
#|
#| 注意 MAP 不能用 `MAP {…}` 前缀，也不能用冒号 —— 那两种只在 SQL 字面量
#| 里成立，`VARCHAR -> MAP` 的 cast 只认 `{k=v}` 这种「打印出来的形式」。
sub render($v --> Str) {
    return 'NULL' unless $v.defined;
    given $v {
        when Arrow::IPC::Read::StructVal {
            '{' ~ $v.names.kv.map(-> $i, $n {
                quoted-str($n) ~ ': ' ~ render($v.vals[$i])
            }).join(', ') ~ '}';
        }
        when Arrow::IPC::Read::MapVal {
            '{' ~ $v.pairs.map({ quoted-str($_.key.Str) ~ '=' ~ render($_.value) }).join(', ') ~ '}';
        }
        when Array { '[' ~ $v.map({ render($_) }).join(', ') ~ ']' }
        when Str   { quoted-str($v) }
        when Bool  { $v ?? 'true' !! 'false' }
        # BLOB 走 DuckDB 的 `\xNN` 转义。这个转义得先经过容器字面量自身的
        # 一层反转义（`\x00` 在那一层会被吃成 `x00`），所以这里同样交给
        # `quoted-str` 把反斜杠双写 —— 与字符串是完全一样的规矩。
        when Blob  { quoted-str($v.map({ sprintf('\\x%02X', $_) }).join) }
        default    { $v.Str }
    }
}

#| 行内单元格：标量原样交给 Appender（走原生绑定，精度不丢），容器转成
#| 上面那种文本 —— Appender 没有 LIST / STRUCT / MAP 的专门接口。
sub cell($v --> Mu) {
    return Any unless $v.defined;
    given $v {
        when Array | Arrow::IPC::Read::StructVal | Arrow::IPC::Read::MapVal { return render($v) }
        default { return $v }
    }
}

#| 进程内的临时表编号。放在模块作用域而不是 `state`：`state` 在
#| `do { }` 块里每次进入都可能是新的闭包，编号会从 1 重来，第二次导入
#| 就覆盖了第一次的表。
my Int $arrow-seq = 0;

# ============================================================
# 解码缓存
# ============================================================

#| 指纹 → 解码产物。缓存项形如 `%(names => [...], types => [...], cols => [...])`。
#|
#| 只缓存**纯 Raku 值**：列名、DuckDB 类型串、逐列解码后的值。刻意不缓存
#| `Buf` / `Bytes` / `Tbl` —— 那些是字节窗口，持有底层 Buf，属于「解码过程」
#| 而非「解码结果」；留着它们等于把整个文件钉在内存里。也不缓存连接或表：
#| 那些是 session 私有的，见下面 `read-arrow` 的注释。
my %DECODE-CACHE;
my Lock $CACHE-LOCK .= new;
my Int $CACHE-HITS = 0;
my Int $CACHE-MISSES = 0;
my @CACHE-ORDER;                 # FIFO 淘汰顺序
my constant $CACHE-CAP = 8;      # 最多留几个文件的解码结果

#| 文件指纹：绝对路径 + 字节数 + mtime。
#|
#| 为什么不用内容哈希：那要先 slurp 整个文件，而 slurp 正是缓存想省掉的一部分
#| （虽然解码比 slurp 贵得多）。size + mtime 是标准的「文件变没变」判据，
#| 对「写完立刻再读」也够用 —— 写文件必然更新这两者之一。
#|
#| 用绝对路径作键的一部分：相对路径从不同 cwd 指向同一个文件会被当成两个
#| 键（浪费但不错误），反过来同名不同路径串味才是真问题。
my sub file-fingerprint(Str:D $path --> Str) {
    my $io = $path.IO;
    $io.absolute ~ '\0' ~ $io.s ~ '\0' ~ $io.modified.Str;
}

#| 查缓存，未命中记一次 miss。命中返回 Hash，否则返回 Nil。
my sub cache-get(Str:D $key) {
    my $hit;
    $CACHE-LOCK.protect: {
        if %DECODE-CACHE{$key}:exists {
            $CACHE-HITS++;
            $hit = %DECODE-CACHE{$key};
        }
        else {
            $CACHE-MISSES++;
        }
    }
    $hit;
}

#| 存缓存。超过上限按 FIFO 淘汰最老的条目 —— 解码结果是全部行数据，
#| 不加约束的话长期运行的进程会一直攒着，这不是"优化"而是内存泄漏。
my sub cache-put(Str:D $key, $entry --> Nil) {
    $CACHE-LOCK.protect: {
        unless %DECODE-CACHE{$key}:exists {
            @CACHE-ORDER.push($key);
            if @CACHE-ORDER.elems > $CACHE-CAP {
                my Str $oldest = @CACHE-ORDER.shift;
                %DECODE-CACHE{$oldest}:delete;
            }
        }
        %DECODE-CACHE{$key} = $entry;
    }
}

#| 运行时观测缓存效果（命中/未命中/当前条目数）。
our sub arrow-cache-stats(--> Hash) is export {
    $CACHE-LOCK.protect: {
        %( hits => $CACHE-HITS, misses => $CACHE-MISSES,
           entries => %DECODE-CACHE.elems );
    }
}

#| 清空解码缓存（拿到新计数器的干净起点，测试与手动释放内存都用）。
our sub clear-arrow-cache(--> Nil) is export {
    $CACHE-LOCK.protect: {
        %DECODE-CACHE = ();
        @CACHE-ORDER = ();
        $CACHE-HITS = 0;
        $CACHE-MISSES = 0;
    }
}



#| 纯解码：IPC 字节 -> 可缓存的列值。解码本身在 Arrow::IPC 包里，
#| 这里只把 Arrow format 串映射成 DuckDB 类型（类型映射属于本项目的职责）。
my sub decode-arrow(Str:D $path --> Hash) {
    my %raw = Arrow::IPC::Read::decode-ipc($path);
    my @types = %raw<fields>.List.map({ duck-type($_) });
    %( names => %raw<names>, types => @types.List, cols => %raw<cols> );
}

#| Arrow format 串 -> DuckDB 类型串；用 AField 的拍平形式处理嵌套。
our sub read-arrow($session, Str:D $path, Str :$name --> Duckula::Frame) is export {
    die Duckula::X::Frame.new(reason => "read-arrow: no such file '$path'")
        unless $path.IO.f;

    my Str $key = file-fingerprint($path);
    my $decoded = cache-get($key);
    unless $decoded.defined {
        $decoded = decode-arrow($path);
        cache-put($key, $decoded);
    }

    # ---- 建表并灌数据 ----
    # 这一步**不缓存**：TEMP 表属于当前连接，连接一关就没了；换个 session
    # 就是另一张表。缓存的是上面的纯解码结果，所以跨 session 命中时只需
    # 重新建表 + Appender，不必再解一遍字节。
    my @names = $decoded<names>.List;
    my @types = $decoded<types>.List;
    my @cols  = $decoded<cols>.List;

    my Str $table = $name // ('__duckula_arrow_' ~ (++$arrow-seq));

    my Str $cols-sql = @names.kv.map(-> $i, $n {
        quote-ident($n) ~ ' ' ~ @types[$i]
    }).join(', ');

    $session.conn.execute(
        'CREATE OR REPLACE TEMP TABLE ' ~ quote-ident($table) ~ " ($cols-sql)"
    );

    my Int $rows = @cols.elems ?? @cols[0].elems !! 0;
    if $rows {
        my Int $chunk = 4096;
        for 0, $chunk ...^ $rows -> int $start {
            my Int $stop = min($start + $chunk, $rows);
            my @slice = ($start ..^ $stop).map: -> int $r {
                [ (^@names.elems).map({ cell(@cols[$_][$r]) }) ]
            };
            $session.insert($table, @slice);
        }
    }

    Duckula::Frame.new(
        session      => $session,
        relation-sql => 'SELECT * FROM ' ~ quote-ident($table),
    );
}
