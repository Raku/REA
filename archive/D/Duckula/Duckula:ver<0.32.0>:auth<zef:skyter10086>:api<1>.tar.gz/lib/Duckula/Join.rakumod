use v6.d;
use Duckula::SQL;
use Duckula::X::Frame;

#| 需要 `JOIN` 关键字的那几种。值直接就是 SQL 关键字。
#|
#| 常量一律声明在 sub 之前：Raku 里方法/子例程体引用文件后面才声明的
#| lexical 常量，会让 resolver 内部崩掉（`Use of Nil in string context`），
#| 而不是给个正常的 "undeclared" 报错。同 §8.4、§8.7 记的坑。
my constant %JOIN-SQL = (
    inner => 'INNER JOIN',
    left  => 'LEFT JOIN',
    right => 'RIGHT JOIN',
    full  => 'FULL OUTER JOIN',
    outer => 'FULL OUTER JOIN',
    cross => 'CROSS JOIN',
);

#| 半连接 / 反连接：没有对应的 JOIN 关键字，走 `WHERE [NOT] EXISTS`。
my constant %EXISTS-KIND = (
    semi => 'EXISTS',
    anti => 'NOT EXISTS',
);

# 用 slip 展平两个 key 列表。直接 `(%A.keys ∪ %B.keys)` 得到的 Set
# 在报错消息里会打成 `anti<TAB>True` 这种 Pair 形态，很怪。
my constant @ALL-KINDS = (|%JOIN-SQL.keys, |%EXISTS-KIND.keys).sort;

#| 给冲突的右侧列名找一个不冲突的输出名。
#|
#| 只在**真的冲突**时加后缀：左侧有 `amount`、右侧也有 `amount`，
#| 输出 `amount` + `amount_right`。右侧独有的列保持原名 —— 这比 pandas
#| 的「两边都加后缀」更贴近直觉，也避免为了 join 一次把左表的列名全改掉。
my sub unique-name(Str:D $base, %taken, Str:D $suffix --> Str) {
    my Str $cand = $base;
    $cand ~= $suffix while %taken{$cand};
    %taken{$cand} = True;
    $cand;
}

#| 把 `:on` 归一化成「左列名 => 右列名」的列表，并逐个校验。
#|
#| 接受的写法：
#|   'id'                     同名连接
#|   <id city>                多个同名键
#|   ('id' => 'uid')          异名连接（Pair）
#|   ('id' => 'uid', ...)     多个异名键
#|
#| 注意 `('a', 'b')` 被理解为**两个同名键**，不是「左 a 接右 b」——
#| 要异名必须用 Pair，这样两种意图不会混在一起。
my sub normalize-keys($on, $lnames, $rnames --> List) {
    # 必须收进数组：`my List $raw = ($on,)` 会被 itemize 成 `$(($on,))`，
    # `for $raw -> $item` 于是把整个 List 绑给 $item，Pair 判断永远为假。
    # 这个坑在 §8.7 / §8.8 里已经踩过三次，这里是第四次。
    my @raw = $on ~~ Positional ?? $on.List !! ($on,);

    my Set $ls = $lnames.Set;
    my Set $rs = $rnames.Set;

    my @out;
    my %seen;

    for @raw -> $item {
        my Str $l;
        my Str $r;

        if $item ~~ Pair {
            $l = $item.key.Str;
            $r = $item.value.Str;
        } else {
            $l = $item.Str;
            $r = $l;
        }

        die Duckula::X::Frame.new(
            reason => "join key '$l' is not a column of the left frame; "
                    ~ "available: {$lnames.join(', ')}"
        ) unless $ls{$l};

        die Duckula::X::Frame.new(
            reason => "join key '$r' is not a column of the right frame; "
                    ~ "available: {$rnames.join(', ')}"
        ) unless $rs{$r};

        die Duckula::X::Frame.new(reason => "join key '$l' appears more than once")
            if %seen{$l}++;

        @out.push: [$l, $r];
    }

    @out.List;
}

#| join 的「规格」：校验 + 算出输出列清单和连接条件，但**不拼整条 SQL**。
#|
#| 抽出来是为了让两条路径共用同一套列名规则（§8.8 那张后缀表）：
#|   - `join-frames`：Frame 用的字符串拼接路径；
#|   - `Duckula::LazyFrame.join`：计划树路径，把 items/on-sql 塞进 Plan::Join。
#|
#| 返回 Hash：
#|   mode       => join | cross | exists
#|   join-sql   => INNER JOIN / LEFT JOIN / …
#|   exists-sql => EXISTS / NOT EXISTS
#|   on-sql     => `l."a" = r."b" AND …`
#|   items      => 输出投影片段（`l."x" AS "x"`, …）
sub join-layout(
    $lnames,
    $rnames,
    :$on,
    Str :$how = 'inner',
    Str :$suffix = '_right',
    --> Hash
) is export {
    my Str $kind = $how.trim.lc;

    die Duckula::X::Frame.new(
        reason => "unknown join kind '$how'; expected one of: {@ALL-KINDS.join(', ')}"
    ) unless %JOIN-SQL{$kind} || %EXISTS-KIND{$kind};

    # 收进数组而不是 `my List $x = ...`：List 赋给标量会被 itemize，
    # `for $x -> $n` 就会把整个 List 绑给 $n 而不是逐个元素。
    my @ln = $lnames.List;
    my @rn = $rnames.List;

    # ---------------- 交叉连接：不要键 ----------------
    if $kind eq 'cross' {
        my %taken;
        my @out;
        for @ln -> $n {
            %taken{$n} = True;
            @out.push: 'l.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($n);
        }
        for @rn -> $n {
            my Str $o = unique-name($n, %taken, $suffix);
            @out.push: 'r.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($o);
        }

        return %(
            mode       => 'cross',
            join-sql   => 'CROSS JOIN',
            exists-sql => '',
            on-sql     => '',
            items      => @out.List,
        );
    }

    # ---------------- 其余都需要键 ----------------
    die Duckula::X::Frame.new(
        reason => "join(:how<$kind>) needs :on — a column name, a list of names, "
                ~ "or a Pair like ('left-col' => 'right-col')"
    ) unless $on.defined;

    my @pairs = normalize-keys($on, @ln, @rn);

    my Str $on-sql = @pairs.map(-> $p {
        'l.' ~ quote-ident($p[0]) ~ ' = r.' ~ quote-ident($p[1])
    }).join(' AND ');

    # ---------------- 半连接 / 反连接：只输出左表 ----------------
    if %EXISTS-KIND{$kind}:exists {
        return %(
            mode       => 'exists',
            join-sql   => '',
            exists-sql => %EXISTS-KIND{$kind},
            on-sql     => $on-sql,
            items      => ('l.*',),
        );
    }

    # ---------------- 常规连接 ----------------
    my %right-key-of = @pairs.map({ .[0] => .[1] }).Hash;   # 左键 -> 右键
    my Set $right-keys = @pairs.map({ .[1] }).Set;          # 右键列不重复输出

    # RIGHT / FULL 的外连接里，未匹配的那一侧键列是 NULL。
    # 用 coalesce 把两边的键合起来，这样键列永远不会因为方向而变成 NULL
    # （标准 SQL 的 `USING` 也是这个语义，只是我们手写列清单拿不到它）。
    # 注意别写 `$kind eq 'right' | 'full'` —— 那得到的是 Junction，
    # 赋给 Bool 会当场类型检查失败。
    my Bool $coalesce = $kind ∈ <right full outer>;

    my %taken;
    my @out;

    for @ln -> $n {
        %taken{$n} = True;
        my Str $expr = 'l.' ~ quote-ident($n);
        # 注意 `&& %h{$n}:exists` 会被解析成给 `&&` 加副词，必须加括号。
        if $coalesce && (%right-key-of{$n}:exists) {
            my Str $rk = %right-key-of{$n};
            $expr = 'coalesce(l.' ~ quote-ident($n) ~ ', r.' ~ quote-ident($rk) ~ ')';
        }
        @out.push: $expr ~ ' AS ' ~ quote-ident($n);
    }

    for @rn -> $n {
        next if $right-keys{$n};        # 键列已在左边输出过了
        my Str $o = unique-name($n, %taken, $suffix);
        @out.push: 'r.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($o);
    }

    %(
        mode       => 'join',
        join-sql   => %JOIN-SQL{$kind},
        exists-sql => '',
        on-sql     => $on-sql,
        items      => @out.List,
    );
}

#| 造一个 join 后的 Frame。
#|
#| `$left` / `$right` 刻意不加类型约束：本模块不能 `use Duckula::Frame`
#| （Frame 会 `use` 本模块），所以只用它们的公开接口 —— `relation-sql`、
#| `names`，以及 `derived($sql)` 造下游 Frame。
sub join-frames(
    $left,
    $right,
    :$on,
    Str :$how = 'inner',
    Str :$suffix = '_right',
    --> Any
) is export {
    my %spec = join-layout($left.names.List, $right.names.List, :$on, :$how, :$suffix);

    my Str $ls = $left.relation-sql;
    my Str $rs = $right.relation-sql;
    my Str $items = %spec<items>.List.join(', ');

    my Str $sql = do given %spec<mode> {
        when 'exists' {
            'SELECT l.* FROM (' ~ $ls ~ ') AS l WHERE ' ~ %spec<exists-sql>
            ~ ' (SELECT 1 FROM (' ~ $rs ~ ') AS r WHERE ' ~ %spec<on-sql> ~ ')'
        }
        when 'cross' {
            'SELECT ' ~ $items ~ ' FROM (' ~ $ls ~ ') AS l'
            ~ ' CROSS JOIN (' ~ $rs ~ ') AS r'
        }
        default {
            'SELECT ' ~ $items ~ ' FROM (' ~ $ls ~ ') AS l'
            ~ ' ' ~ %spec<join-sql> ~ ' (' ~ $rs ~ ') AS r'
            ~ ' ON ' ~ %spec<on-sql>
        }
    };

    $left.derived($sql);
}
