use v6.d;
use Duckula::SQL;
use Duckula::X::Frame;
use Duckula::Clean;

#| 重塑与概览（阶段 11 第二批）的 SQL 构件。
#|
#| 与 `Duckula::Clean` 同为纯函数层：只把参数译成 SQL 片段，不碰 Frame 类型，
#| eager / lazy 两条路径共用同一份语义。
#|
#| =head2 为什么 pivot 不用 DuckDB 原生的 PIVOT
#|
#| DuckDB 的 `PIVOT ... USING ...` 语法很好用，但它被自己的语句分类器判成
#| **MULTI**（`duckdb_extract_statements` 把 PIVOT 重写成多条内部语句）。
#| 我们的只读守卫（§9.5）拒绝一切 MULTI，且不能为 PIVOT 开口子 —— 一旦允许
#| MULTI，"只读"的保证就形同虚设（`statement 1: SELECT; statement 2: DELETE`）。
#| 所以这里用**条件聚合**手搓 pivot：`sum(CASE WHEN k = 'v' THEN x END)`。
#| 代价是要先跑一次 `SELECT DISTINCT k` 拿分组值；好处是列名由我们控制、
#| 聚合函数可以任意组合、且不引入新的攻击面。
#|
#| UNPIVOT 则被判成 SELECT，可以直接用原生语法。
#|
#| =head2 列表展开的空行
#|
#| `unnest(list)` 遇到空列表/NULL 会**不产生行**（DuckDB 的语义），但 pandas /
#| Polars 的 `explode` 会保留一行 NULL。为了贴合 DataFrame 语义，`explode`
#| 默认把空列表与 NULL 都替换成 `[NULL]` 再展开（`:!keep-empty` 可切回
#| DuckDB 原生行为）。多列展开写在同一个 SELECT 列表里，天然按位置 zip，
#| 长度不齐时短的补 NULL。
unit module Duckula::Reshape;

#| 允许出现在 pivot 里的聚合函数白名单。
#|
#| 与 `cast` 的类型名同理：函数名没法参数绑定，只能拼文本。用白名单把
#| `sum` 之类固定下来，不让调用方传进任意 SQL 片段。
#| `count` 用 `count(CASE WHEN ... THEN x END)`：只数 x 非空的行，
#| 与其他聚合函数一致地忽略空值。
my constant %AGG = (
    sum      => True,
    avg      => True,
    min      => True,
    max      => True,
    first    => True,
    last     => True,
    count    => True,
    median   => True,
    stddev   => True,
    variance => True,
    product  => True,
);
my constant $AGG-HINT = 'sum, avg, min, max, first, last, count, median, '
                      ~ 'stddev, variance or product';

#| 校验 pivot 的聚合函数名，返回其规范化小写形式。
our sub check-agg(Str:D $agg --> Str) is export {
    my Str $a = $agg.trim.lc;
    die Duckula::X::Frame.new(
        reason => "pivot: unknown aggregate '$agg'; expected $AGG-HINT"
    ) unless %AGG{$a};
    $a;
}

#| 去重 column list：保持顺序、去掉重复（pivot 的分组值 / explode 的列）。
our sub distinct-list(@xs --> List) is export {
    my %seen;
    @xs.grep({ %seen{$_}++ == 0 }).List;
}

# ------------------------------------------------------------------ explode

#| `explode` 的投影列表。
#|
#| 未展开的列原样 `"c" AS "c"`；展开的列写成
#| `unnest(CASE WHEN "x" IS NULL OR len("x") = 0 THEN [NULL] ELSE "x" END) AS "x"`。
#| 保持列名不变，这样展开后还能接着 `filter('x > ?', 5)`。
our sub explode-items(@names, @cols, Bool:D :$keep-empty = True --> List) is export {
    need-cols(@cols, @names, 'explode');
    die Duckula::X::Frame.new(reason => 'explode needs at least one column')
        unless @cols.elems;

    my Set $gone = @cols.Set;
    my @items = @names.map(-> $c {
        if $gone{$c} {
            my Str $q = quote-ident($c);
            my Str $src = $keep-empty
                ?? "CASE WHEN $q IS NULL OR len($q) = 0 THEN [NULL] ELSE $q END"
                !! $q;
            "unnest($src) AS $q";
        } else {
            quote-ident($c) ~ ' AS ' ~ quote-ident($c);
        }
    });
    @items.List;
}

#| 把投影列表包成一条完整的 SELECT。
our sub project-sql(Str:D $rel, @items, Str:D $alias = '__duckula_rs' --> Str) is export {
    'SELECT ' ~ @items.join(', ') ~ ' FROM (' ~ $rel ~ ') AS ' ~ $alias;
}

# ------------------------------------------------------------------ unpivot

#| 宽转长：`UNPIVOT ... ON ... INTO NAME ... VALUE ...`。
#|
#| `:$on` 是要展开的列（值列），`:$index` 是保持不动的列。两者都不能为空：
#| 全展开没有锚列，得到的 `(name, value)` 行无法回溯到原行，通常不是想要的。
our sub unpivot-sql(
    Str:D $rel,
    @on,
    @index,
    Str:D $var,
    Str:D $val
    --> Str
) is export {
    die Duckula::X::Frame.new(reason => 'unpivot needs at least one column to unpivot')
        unless @on.elems;

    my Str $body = 'UNPIVOT (' ~ $rel ~ ') ON ' ~ @on.map({ quote-ident($_) }).join(', ');
    $body ~= ' INTO NAME ' ~ quote-ident($var) ~ ' VALUE ' ~ quote-ident($val);

    'SELECT * FROM (' ~ $body ~ ') AS __duckula_up';
}

#| 校验 `on` 与 `index` 不重叠 —— UNPIVOT 里同一列不能既展开又保留。
our sub check-unpivot-columns(@on, @index, @names --> Nil) is export {
    need-cols(@on, @names, 'unpivot');
    need-cols(@index, @names, 'unpivot');

    my Set $idx = @index.Set;
    my @both = @on.grep({ $idx{$_} });
    die Duckula::X::Frame.new(
        reason => 'unpivot: columns cannot be both in :on and :index ('
                ~ @both.join(', ') ~ ')'
    ) if @both.elems;
}

# ------------------------------------------------------------------ pivot

#| 先取一遍分组值（DISTINCT），供条件聚合生成列名。
#|
#| 这是 reshape 里唯一一个**建算子时就查询数据**的地方 —— 列名必须由数据
#| 决定，没法只靠 schema。eager / lazy 都走这里，所以两边看到的列集合一致。
#| 参数（`?`）原样绑定，不拼进 SQL 文本。
our sub pivot-keys(
    $conn,
    Str:D $rel,
    Str:D $on,
    @params = (),
    Bool :$keep-nulls = False
    --> List
) is export {
    my Str $q = quote-ident($on);
    my Str $sql = 'SELECT DISTINCT ' ~ $q ~ ' FROM (' ~ $rel ~ ') AS __duckula_pv';
    $sql ~= " WHERE $q IS NOT NULL" unless $keep-nulls;
    $sql ~= " ORDER BY $q";

    my $res = $conn.query($sql, |@params);
    $res.arrays.List.map({ .[0] }).List;
}

#| 单列的聚合片段：`agg(CASE WHEN "k" = 'v' THEN "x" END) AS "v"`。
#|
#| `$pred` 是已经渲染好的谓词（含 NULL 值的 `IS NULL`），`$name` 是输出列名。
our sub pivot-item(
    Str:D $on,
    Str:D $value,
    Str:D $pred,
    Str:D $agg,
    Str:D $name
    --> Str
) is export {
    my Str $q = quote-ident($on);
    "{$agg}(CASE WHEN $q $pred THEN " ~ quote-ident($value) ~ ' END) AS '
    ~ quote-ident($name);
}

#| 生成 pivot 的列集合 + SQL。
#|
#| `@keys` 是上一步 DISTINCT 出来的值（可含 Any 表示 NULL）；`@values` 是要
#| 聚合的列。单值列时输出列就叫分组值；多值列时叫 `<值列>_<分组值>`，避免
#| 两个值列的同名聚合撞在一起。
#|
#| 输出始终按 `index` 排序 —— 条件聚合本身不保证组顺序，和 `value-counts`
#| 同理，不补这一刀 eager/lazy 两次跑出的行序可能不同。
our sub pivot-sql(
    Str:D $rel,
    Str:D $on,
    @index,
    @values,
    @keys,
    Str:D $agg,
    Bool :$keep-nulls = False
    --> Str
) is export {
    my %taken = @index.map({ $_ => True });
    my @items = @index.map({ quote-ident($_) ~ ' AS ' ~ quote-ident($_) });

    sub add-name(Str:D $name --> Str) {
        my Str $out = $name;
        my Int $n = 2;
        while %taken{$out} {
            $out = $name ~ '_' ~ $n++;
        }
        %taken{$out} = True;
        $out;
    }

    for @keys -> $k {
        my Bool $is-null = !$k.defined;
        next if $is-null && !$keep-nulls;

        my Str $pred = $is-null
            ?? 'IS NULL'
            !! '= ' ~ sql-literal($k);
        my Str $key-name = $is-null ?? 'NULL' !! $k.Str;

        for @values -> $v {
            my Str $name = @values.elems == 1
                ?? $key-name
                !! "{$v}_{$key-name}";
            @items.push: pivot-item($on, $v, $pred, $agg, add-name($name));
        }
    }

    my Str $sql = 'SELECT ' ~ @items.join(', ')
                ~ ' FROM (' ~ $rel ~ ') AS __duckula_pv_src';
    if @index.elems {
        $sql ~= ' GROUP BY ' ~ @index.map({ quote-ident($_) }).join(', ')
              ~ ' ORDER BY ' ~ @index.map({ quote-ident($_) }).join(', ');
    }
    $sql;
}

# ------------------------------------------------------------------ sample

#| 采样：`USING SAMPLE`。
#|
#| 两种取法：
#|   - `:$n`（行数）→ `RESERVOIR (n ROWS)`；`n ROWS REPEATABLE (seed)` 不被
#|     DuckDB 接受（实测 parser error），必须写 RESERVOIR 形式；
#|   - `:$frac`（0<frac<=1）→ `BERNOULLI (p PERCENT)`，抽样比例可复现。
#|
#| `:$seed` 走 `REPEATABLE`，同一份输入 + 同一个种子必得同一批行 —— 测试能
#| 钉住结果，文档示例也能复现。
our sub sample-sql(
    Str:D $rel,
    Int :$n,
    :$frac,
    Int :$seed
    --> Str
) is export {
    my Bool $has-n = $n.defined;
    my Bool $has-frac = $frac.defined;

    die Duckula::X::Frame.new(
        reason => 'sample: pass exactly one of :n(...) or :frac(...)'
    ) if $has-n == $has-frac;

    my Str $spec;
    if $has-n {
        die Duckula::X::Frame.new(reason => 'sample: :n must be positive')
            unless $n > 0;
        $spec = "RESERVOIR ($n ROWS)";
    } else {
        die Duckula::X::Frame.new(
            reason => 'sample: :frac must be a number in (0, 1]'
        ) unless $frac ~~ Numeric && 0 < $frac <= 1;
        $spec = 'BERNOULLI (' ~ ($frac * 100).Str ~ ' PERCENT)';
    }

    die Duckula::X::Frame.new(reason => 'sample: :seed must be non-negative')
        if $seed.defined && $seed < 0;
    $spec ~= " REPEATABLE ($seed)" if $seed.defined;

    'SELECT * FROM (' ~ $rel ~ ') AS __duckula_sp USING SAMPLE ' ~ $spec;
}

# ------------------------------------------------------------------ describe

#| 概览：`SUMMARIZE`，每列一行，给出 min/max/分位数/均值/标准差/空值率。
#|
#| DuckDB 把 SUMMARIZE 分类为 SELECT，包成子查询后仍然只读，可以直接进
#| 计划树。输出列固定 12 个，所以 eager / lazy 两条路径的 schema 天然一致。
our sub describe-sql(Str:D $rel --> Str) is export {
    'SELECT * FROM (SUMMARIZE ' ~ $rel ~ ') AS __duckula_desc';
}
