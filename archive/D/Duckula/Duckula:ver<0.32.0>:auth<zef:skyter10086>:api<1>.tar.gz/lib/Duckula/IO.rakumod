use v6.d;
use Duckula::SQL;
use Duckula::X::Frame;

#| 读侧文件源的 SQL 构件（JSON / Excel）。
#|
#| 与 `Duckula::Write` 对称：路径永远作为绑定参数 `?` 交给 DuckDB，
#| 只有选项进 SQL 文本，而且选项一律走白名单 + sql-literal。
#|
#| 为什么不把整条 `read_json_auto('path')` 拼好再传进去：那样文件名里
#| 一个单引号就是注入点。现在 `Session.sql` 收到的 SQL 里只有 `?`，
#| `relation-sql` 里的字面量是 `render-bindings` 事后固化的，二者不是一回事。
unit module Duckula::IO;

my constant JSON-FORMATS = <auto newline_delimited array unstructured>.Set;
my constant JSON-RECORDS = <auto true false>.Set;

#| `read_json_auto(...)` 的来源 SQL，路径留一个 `?`。
#|
#|   json-source-sql(:format<array>, :ignore-errors)
#|   # SELECT * FROM read_json_auto(?, format = 'array', ignore_errors = true)
#|
#| `format` / `records` 必须是白名单里的字符串，不能是任意 SQL 片段。
our sub json-source-sql(
    Str :$format,
    Str :$records,
    Int :$maximum-depth,
    Bool :$ignore-errors,
    --> Str
) is export {
    if $format.defined {
        die Duckula::X::Frame.new(
            reason => "unknown JSON format '{$format}'; expected one of "
                    ~ JSON-FORMATS.keys.sort.join(', ')
        ) unless JSON-FORMATS{$format};
    }
    if $records.defined {
        die Duckula::X::Frame.new(
            reason => "JSON records must be auto/true/false, got '{$records}'"
        ) unless JSON-RECORDS{$records};
    }
    if $maximum-depth.defined && $maximum-depth < 1 {
        die Duckula::X::Frame.new(reason => 'maximum-depth must be positive');
    }

    my @args = '?';
    @args.push('format = ' ~ sql-literal($format)) if $format.defined;
    @args.push('records = ' ~ sql-literal($records)) if $records.defined;
    @args.push("maximum_depth = {$maximum-depth}") if $maximum-depth.defined;
    @args.push('ignore_errors = ' ~ sql-literal($ignore-errors))
        if $ignore-errors.defined;
    'SELECT * FROM read_json_auto(' ~ @args.join(', ') ~ ')';
}

#| `read_xlsx(...)` 的来源 SQL，路径留一个 `?`。
#|
#| 注意参数名是 `sheet`（DuckDB v2.x），不是 `sheet_name`。
our sub excel-source-sql(
    Str :$sheet,
    Bool:D :$header = True,
    Bool:D :$all-varchar = False,
    --> Str
) is export {
    my @args = '?';
    @args.push('sheet = ' ~ sql-literal($sheet)) if $sheet.defined;
    @args.push('header = ' ~ sql-literal($header));
    @args.push('all_varchar = ' ~ sql-literal($all-varchar));
    'SELECT * FROM read_xlsx(' ~ @args.join(', ') ~ ')';
}

#| 这个连接能不能用 DuckDB 的 `read_xlsx`。
#|
#| 优先 LOAD（已经装过就不需要联网），失败再试 INSTALL + LOAD。
#| 沙箱会话不尝试联网安装，直接判定不可用。整段不抛异常：调用方据此
#| 决定走 SQL 路径还是 Raku 解码兜底。
our sub excel-available($session --> Bool) is export {
    return False if $session.sandboxed;

    my $conn = $session.conn;
    my Bool $loaded = False;
    try {
        $loaded = $conn.query(
            "SELECT coalesce(bool_and(loaded), false) AS ok "
            ~ "FROM duckdb_extensions() WHERE extension_name = 'excel'"
        ).value.Bool;
        CATCH { default { $loaded = False } }
    }
    return True if $loaded;

    try {
        $conn.execute('LOAD excel');
        return True;
        CATCH { default { } }
    }

    # Windows 的 mingw 构建在官方仓库里没有 excel 扩展，INSTALL 会 404；
    # 这里只是"再试一次"，失败后安静交给 Raku 解码兜底。
    try {
        $conn.execute('INSTALL excel');
        $conn.execute('LOAD excel');
        return True;
        CATCH { default { } }
    }
    False;
}
