use v6.d;
use Duckula::SQL;
use Duckula::Expr;
use Duckula::TimeSeries;
use Duckula::X::Series;

#| Series 访问器（v0.23.0）：对标 pandas 的 `.str` / `.dt`。
#|
#| 为什么单独一个文件、并且必须在 Duckula::Series **之前**加载：
#| Duckula::Expr 里已经踩过坑（§8.4 / Expr.rakumod 顶部注释）——若一个类的方法
#| 体里引用文件后面才声明的类名，Raku 的 resolver 会内部崩掉，报的是
#| `Use of Nil in string context` 而不是正常的 undeclared。所以这里不反向引用
#| Series；访问器只持有「列名」和一支 `Expr --> Series` 的闭包，Series 在
#| 自己的 `str` / `dt` 方法里构造闭包时捕获 self。
#|
#| 所有参数（分隔符、正则、格式串、补位字符）都走 `sql-literal` 变成 SQL 字面量；
#| 函数名和类型名写死或过白名单 —— 这是延续 §9 的防注入模型：Expr 渲染的是
#| 可嵌入任意 SQL 的片段，没有位置可绑，所以绝不能让用户文本当标识符拼进来。
#| 每个 Expr 都带上来源列名，Frame 的白名单校验照常生效。

my sub col-expr(Str:D $col --> Str) { col($col).render }

# 只能写死的标识符/枚举，不能来自用户输入
my constant %TRUNC-UNIT = set <year quarter month week day hour minute second millisecond microsecond>;

my sub call-expr(Str:D $col, Str:D $fn, *@args --> Duckula::Expr) {
    my Str $sql = $fn ~ '(' ~ col-expr($col);
    $sql ~= ', ' ~ @args.map({ sql-literal($_) }).join(', ') if @args.elems;
    Duckula::Expr.new(sql => $sql ~ ')', columns => Set.new($col));
}

my sub cast-expr(Str:D $col, Str:D $type --> Duckula::Expr) {
    Duckula::Expr.new(
        sql     => 'CAST(' ~ col-expr($col) ~ ' AS ' ~ $type ~ ')',
        columns => Set.new($col),
    );
}

#| 字符串访问器。用法：`$s.str.upper`、`$s.str.replace('a', 'b')`。
#| 已有扁平方法（Series.upper/lower/...）保留；这里提供完整的一族。
class Duckula::StrAccessor {
    has Str $.col is required;
    has $.apply is required;

    method !run(Duckula::Expr:D $e) { $!apply.($e) }
    method !call(Str:D $fn, *@args)  { self!run(call-expr($!col, $fn, |@args)) }

    # ---- 大小写 / 长度 / 方向
    method upper()   { self!call('upper') }
    method lower()   { self!call('lower') }
    method length()  { self!call('length') }
    method reverse() { self!call('reverse') }

    # ---- 去空白：DuckDB trim/ltrim/rtrim 只去空格，和 pandas 默认一致
    method strip()  { self!call('trim') }
    method lstrip() { self!call('ltrim') }
    method rstrip() { self!call('rtrim') }

    # ---- 匹配：字面用 starts_with/contains，正则用 regexp_matches
    method starts-with($prefix ) { self!call('starts_with', $prefix) }
    method startswith($prefix )  { self.starts-with($prefix) }
    method ends-with($suffix )   { self!call('ends_with', $suffix) }
    method endswith($suffix )    { self.ends-with($suffix) }
    method contains($needle )    { self!call('contains', $needle) }
    method matches($pattern )    { self!call('regexp_matches', $pattern) }

    # ---- 替换 / 抽取
    # DuckDB replace() 是字面替换（不是正则），和 pandas .str.replace 默认 regex=False 一致。
    method replace($old, $new ) {
        self!call('replace', $old, $new);
    }

    # 正则替换。:$global 决定第四参是不是 'g'；参数走 sql-literal。
    method replace-regex($pattern, $new, Bool :$global = True ) {
        $global
            ?? self!call('regexp_replace', $pattern, $new, 'g')
            !! self!call('regexp_replace', $pattern, $new);
    }

    method extract($pattern, Int:D :$group = 1 ) {
        die Duckula::X::Series.new(reason => "extract group must be >= 0, got $group")
            if $group < 0;
        self!call('regexp_extract', $pattern, $group);
    }

    # ---- 切分。split() 返回 LIST（ARRAY）列；split-part() 返回标量列。
    method split($delim ) { self!call('string_split', $delim) }
    method split-part($delim, Int:D $index ) {
        die Duckula::X::Series.new(reason => "split-part index is 1-based, got $index")
            if $index < 1;
        self!call('split_part', $delim, $index);
    }

    #| pandas 语义：start 含、stop 不含、0 基。DuckDB substring 是 1 基，
    #| 所以转成 substring(col, start + 1, stop - start)。先只接受非负。
    method slice(Int:D $start, Int:D $stop ) {
        die Duckula::X::Series.new(
            reason => "str.slice needs 0 <= start <= stop, got $start..$stop"
        ) if $start < 0 || $stop < $start;
        self!run(Duckula::Expr.new(
            sql     => 'substring(' ~ col-expr($!col) ~ ', '
                        ~ ($start + 1) ~ ', ' ~ ($stop - $start) ~ ')',
            columns => Set.new($!col),
        ));
    }

    # ---- 补位：lpad/rpad 的 pad 字符走 sql-literal
    method pad(Int:D $width, Str:D :$char = ' ', Str:D :$side = 'left' ) {
        die Duckula::X::Series.new(reason => "str.pad side must be 'left' or 'right', got '$side'")
            unless $side eq 'left' || $side eq 'right';
        die Duckula::X::Series.new(reason => "str.pad width must be >= 0, got $width")
            if $width < 0;
        self!call($side eq 'left' ?? 'lpad' !! 'rpad', $width, $char);
    }

    method zfill(Int:D $width ) {
        die Duckula::X::Series.new(reason => "str.zfill width must be >= 0, got $width")
            if $width < 0;
        self!call('lpad', $width, '0');
    }

    method repeat(Int:D $n ) {
        die Duckula::X::Series.new(reason => "str.repeat n must be >= 0, got $n") if $n < 0;
        self!call('repeat', $n);
    }
}

#| 日期/时间访问器。用法：`$s.dt.year`、`$s.dt.strftime('%Y-%m')`。
#| 列可以是 DATE / TIMESTAMP / 纯日期字符串（DuckDB 会隐式转换）。
class Duckula::DtAccessor {
    has Str $.col is required;
    has $.apply is required;

    method !run(Duckula::Expr:D $e) { $!apply.($e) }
    method !call(Str:D $fn, *@args)  { self!run(call-expr($!col, $fn, |@args)) }

    # ---- 部件
    method year()        { self!call('year') }
    method month()       { self!call('month') }
    method day()         { self!call('day') }
    method hour()        { self!call('hour') }
    method minute()      { self!call('minute') }
    method second()      { self!call('second') }
    #| DuckDB 的 millisecond(t)/microsecond(t) 是「秒部+小数部」的累计值
    #| （10:20:30.123 → 30123），pandas 要的只是小数部件（123），取模还原。
    method millisecond() {
        self!run(Duckula::Expr.new(
            sql     => '(date_part(' ~ sql-literal('millisecond') ~ ', ' ~ col-expr($!col) ~ ') % 1000)',
            columns => Set.new($!col),
        ));
    }
    method microsecond() {
        self!run(Duckula::Expr.new(
            sql     => '(date_part(' ~ sql-literal('microsecond') ~ ', ' ~ col-expr($!col) ~ ') % 1000000)',
            columns => Set.new($!col),
        ));
    }
    method quarter()     { self!call('quarter') }
    method week()        { self!call('week') }
    method dayofyear()   { self!call('dayofyear') }

    #| pandas 的 dayofweek 是 Monday=0；DuckDB 的 dayofweek 是 Sunday=0，
    #| isodow 则是 Monday=1。用 isodow - 1 正好对上 pandas，不用再取模。
    method dayofweek() {
        self!run(Duckula::Expr.new(
            sql     => '(isodow(' ~ col-expr($!col) ~ ') - 1)',
            columns => Set.new($!col),
        ));
    }

    # ---- 类型转换 / 截断
    method date() { self!run(cast-expr($!col, 'DATE')) }
    method time() { self!run(cast-expr($!col, 'TIME')) }

    method floor(Str:D $unit ) {
        die Duckula::X::Series.new(
            reason => "dt.floor unknown unit '$unit'; use one of {%TRUNC-UNIT.keys.sort.join(', ')}"
        ) unless %TRUNC-UNIT{$unit};
        # date_trunc 的参数顺序和其他函数相反：date_trunc(part, value)。
        # unit 已过白名单，再走 sql-literal 变成字面量。
        self!run(Duckula::Expr.new(
            sql     => 'date_trunc(' ~ sql-literal($unit) ~ ', ' ~ col-expr($!col) ~ ')',
            columns => Set.new($!col),
        ));
    }

    #| 格式串走 sql-literal（单引号已转义），不会变成 SQL 代码。
    method strftime(Str:D $format ) {
        self!call('strftime', $format);
    }
    method format(Str:D $format ) { self.strftime($format) }

    method epoch()    { self!call('epoch') }
    method last-day() { self!call('last_day') }
    method lastday()  { self.last-day }

    # ---- 时区（v0.29.0）
    #| 把 naive 墙钟钉到某时区 → TIMESTAMPTZ。
    method tz-localize(Str:D $tz ) {
        self!run(Duckula::Expr.new(
            sql     => Duckula::TimeSeries::tz-localize-sql(col-expr($!col), $tz),
            columns => Set.new($!col),
        ));
    }
    method tzlocalize(Str:D $tz ) { self.tz-localize($tz) }

    #| TIMESTAMPTZ 换成目标时区的墙钟 → TIMESTAMP。
    method tz-convert(Str:D $tz ) {
        self!run(Duckula::Expr.new(
            sql     => Duckula::TimeSeries::tz-convert-sql(col-expr($!col), $tz),
            columns => Set.new($!col),
        ));
    }
    method tzconvert(Str:D $tz ) { self.tz-convert($tz) }

    #| UTC 偏移字符串（如 '+08'）。
    method tz-offset(Str:D $tz ) {
        self!run(Duckula::Expr.new(
            sql     => Duckula::TimeSeries::tz-offset-sql(col-expr($!col), $tz),
            columns => Set.new($!col),
        ));
    }

    # ---- Period（v0.29.0）
    #| 周期起点。freq: Y/Q/M/W/D/h/min/s（对齐 resample 的写法）。
    method to-period(Str:D $freq ) {
        self!run(Duckula::Expr.new(
            sql     => Duckula::TimeSeries::period-start-sql(col-expr($!col), $freq),
            columns => Set.new($!col),
        ));
    }
    method period-start(Str:D $freq ) { self.to-period($freq) }

    #| 周期终点（周期最后一刻）。
    method period-end(Str:D $freq ) {
        self!run(Duckula::Expr.new(
            sql     => Duckula::TimeSeries::period-end-sql(col-expr($!col), $freq),
            columns => Set.new($!col),
        ));
    }

    #| 周期内的序号（年/季/月/周/日/时…）。
    method period-ordinal(Str:D $freq ) {
        self!run(Duckula::Expr.new(
            sql     => Duckula::TimeSeries::period-ordinal-sql(col-expr($!col), $freq),
            columns => Set.new($!col),
        ));
    }
}
