use v6.d;
use Duckula::SQL;
use Duckula::Guard;
use Duckula::Clean;
use Duckula::Index;
use Duckula::IndexLabels;
use Duckula::Reshape;
use Duckula::GroupOps;
use Duckula::Stats;
use Duckula::Expr;
use Duckula::GroupBy;
use Duckula::Join;
use Duckula::AsOf;
use Duckula::Series;
use Duckula::LazyFrame;
use Duckula::Plan;
use Duckula::Arrow;
use Duckula::Write;
use Duckula::FrameOps;
use Duckula::TimeSeries;
use Duckula::Dtype;
use Duckula::X::Frame;

#| DuckDB 里「Raku 没有原生对应类型、被驱动解码成十进制字符串」的类型。
#|
#| HUGEINT 是 128 位整数（`sum(bigint)` 的结果就是它），DECIMAL 是定点数。
#| Raku 的 Int 本来就没有位宽上限、Rat 是精确有理数，所以把字符串还原成
#| 数值是**无损**的 —— 白白保留字符串只会让 `$g.rows` 里出现 `"450"`。
my sub looks-typed-numeric(Str:D $t --> Bool) {
    so $t ~~ /^ [ 'HUGEINT' | 'UHUGEINT' | 'BIGNUM' | 'DECIMAL' ]/;
}

#| 一张表视图：**真相是 $.relation-sql 这条 SELECT，不是那堆数据**。
#|
#| 这样做的原因（ARCHITECTURE.md §9.7）：
#|   - `$df.sql("... from self ...")` 需要一条能塞进临时视图的 SELECT；
#|   - 链式算子可以直接拼 SQL，不必先把数据搬进 Raku；
#|   - 物化只在真正要数据时发生一次，且结果缓存。
#|
#| 注意：本类的物化结果会消耗 DB::DuckDB::Result 的游标，所以一次性取全
#| 并存进 @!rows。ColumnView 的零拷贝路径留给 Series（阶段 1）。
class Duckula::Frame {
    has $.session is required;
    has Str $.relation-sql is required;

    #| 用户显式声明的 key 列（pandas 的 set_index）。这是**元数据**，
    #| 不是隐藏的行号：key 列本身还在 SQL 里，派生时原样带过去。
    #| 空 List 表示没有 key，跨 Frame 的逐行运算仍被拒绝。
    has List $.index-cols = ();

    #| 用户显式声明的逻辑 dtype（v0.30.0）。物理类型仍由 DuckDB 决定，
    #| 这里只记住 nullable / categories 这类 SQL 里没有的语义。派生时
    #| 原样带过去，cast 时按列更新。
    has Hash $!dtype-meta = {};

    has $!result;
    has Bool $!materialized = False;
    has Bool $!names-known = False;
    has @!names;
    has @!rows;

    #| 内部构造：允许把已执行好的 Result 一并交进来，避免二次执行。
    submethod BUILD(:$!session, Str :$relation-sql!, :$result, :$index-cols, :$dtype-meta) {
        $!relation-sql = $relation-sql.trim.subst(/ ';' $ /, '').trim;
        $!result = $result;
        $!index-cols = $index-cols.defined ?? $index-cols.List !! ();
        $!dtype-meta = $dtype-meta.defined ?? $dtype-meta.Hash !! {};
    }

    method !materialize(--> Nil) {
        return if $!materialized;

        my $res = $!result // $!session.conn.query($!relation-sql);
        @!names = $res.names.List;      # names 要在结果 alive 时读

        # 优先走 ColumnView：它带 .type，能把 HUGEINT / DECIMAL 这类
        # 「驱动解码成字符串」的列还原成数值。ColumnView 被
        # DB_DUCKDB_NO_COLUMN_VIEW=1 整体关掉时退回 arrays。
        my @views = ();
        @views = $res.column-views.List if $res.can('column-views');

        if @views.elems && @views.elems == @!names.elems {
            @!rows = self!rows-from-views(@views);
        } else {
            @!rows = $res.arrays.List;  # 游标消耗，取全
        }

        $!result = Nil;
        $!materialized = True;
        $!names-known = True;
    }

    #| 只取列名，不取数据。
    #|
    #| `SELECT * FROM (...) LIMIT 0` 让 DuckDB 规划一遍并返回 schema，
    #| 一行都不搬。算子（select / filter / join / group-by）都只要列名，
    #| 走这条路径才不会为了拿几个名字把整张表拉进 Raku。
    method !ensure-names(--> Nil) {
        return if $!names-known;

        # 已经拿到 Result 的话直接读它的 names，省一次查询。
        if $!result {
            @!names = $!result.names.List;
        } else {
            my $res = $!session.conn.query(
                "SELECT * FROM ({$!relation-sql}) AS __duckula_names LIMIT 0"
            );
            @!names = $res.names.List;
        }
        $!names-known = True;
    }

    #| 按列取类型化数据再转置成行。
    method !rows-from-views(@views --> List) {
        my @cols = @views.map(-> $v { self!decode-column($v) });
        my Int $n = @cols.elems ?? @cols[0].elems !! 0;

        my @out;
        for ^$n -> $i {
            # 行用 Array（和 `Result.arrays` 的返回形态一致），不是 List，
            # 这样两条物化路径对调用方是同一种东西。
            @out.push: @cols.map(-> @c { @c[$i] }).Array;
        }
        @out.List;
    }

    method !decode-column($v --> List) {
        my List $vals = $v.to-list.List;

        my Str $t = ($v.type // '').Str;
        return $vals unless looks-typed-numeric($t);

        # DECIMAL 走 Rat（精确），整数类走 Int。Raku 的 Int 没有位宽上限，
        # 128 位的 HUGEINT 也不会溢出。
        my Bool $decimal = $t.uc.starts-with('DECIMAL');

        # 注意别在 map 块里写 `return` —— 那会从整个方法返回。
        $vals.map(-> $x {
            $x ~~ Str
                ?? ($decimal
                        ?? ($x ~~ /^ '-'? \d+ ['.' \d+]? $/ ?? $x.Rat !! $x)
                        !! ($x ~~ /^ '-'? \d+ $/             ?? $x.Int !! $x))
                !! $x;
        }).List;
    }

    #| 列名，顺序与 SELECT 输出一致。
    #|
    #| 只问 schema，不搬数据 —— 所以 `join` 问两次列名也不会把两张表拉下来。
    method names(--> List) {
        self!ensure-names;
        @!names.List;
    }

    #| 全部行，每行是一个 Array（按 names 顺序）。
    method rows(--> List) {
        self!materialize;
        @!rows.List;
    }

    method elems(--> Int) {
        self!materialize;
        @!rows.elems;
    }

    #| (rows, cols)，对位 pandas 的 df.shape。
    method shape(--> List) {
        (self.elems, self.names.elems);
    }

    #| 取前 $n 行，仍然返回 Frame（SQL 层面加 LIMIT，不搬数据）。
    method head(Int $n = 5 --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => "head() needs a non-negative count, got $n")
            if $n < 0;
        self.derived("SELECT * FROM ({$!relation-sql}) AS __duckula_head LIMIT $n");
    }

    #| Polars 的名字，等价于 `head($n)`。
    method limit(Int $n = 5 --> Duckula::Frame) { self.head($n) }

    #| 取末尾 $n 行（Polars 的 `tail`）。
    #|
    #| 没有「行序」这回事的 SQL 里，末尾只能靠计数找。这里**只扫一遍**数据：
    #| `row_number() OVER ()` 给每行编号、`count(*) OVER ()` 给总行数，
    #| 外层筛 `rn > 总数 - n`。两个窗口函数共用同一次扫描，顺序沿用扫描顺序
    #| （和 Polars 依赖 frame 行序一个意思），筛选后顺序不变。
    #|
    #| 备选写法是 `OFFSET (SELECT count(*)-n …)`，但那会让关系被算两遍，
    #| 在 CSV/Parquet 上就是两次全表扫描。
    method tail(Int $n = 5 --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => "tail() needs a non-negative count, got $n")
            if $n < 0;
        return self.head(0) if $n == 0;

        # 辅助列名要保证不撞上用户列名，撞了会静默覆盖掉一列真实数据。
        my Set $known = self.names.Set;
        my Str $rn = '__duckula_rn';
        $rn ~= '_' while $rn ∈ $known;
        my Str $cnt = $rn ~ '_n';

        self.derived('SELECT * EXCLUDE (' ~ quote-ident($rn) ~ ', ' ~ quote-ident($cnt) ~ ') '
              ~ 'FROM (SELECT *, row_number() OVER () AS ' ~ quote-ident($rn)
              ~ ', count(*) OVER () AS ' ~ quote-ident($cnt)
              ~ " FROM ({$!relation-sql}) AS __duckula_tail_w) AS __duckula_tail "
              ~ 'WHERE ' ~ quote-ident($rn) ~ ' > ' ~ quote-ident($cnt) ~ ' - ' ~ $n);
    }

    #| 切片，对应 Polars 的 `slice(offset, length)`：
    #|
    #|   $df.slice(2, 3);   # 第 3~5 行
    #|   $df.slice(2);      # 从第 3 行到末尾
    #|   $df.slice(-3);     # 末尾 3 行
    #|   $df.slice(-5, 2);  # 倒数第 5 行起取 2 行
    #|
    #| 负 offset 从末尾算（和 Polars 一致），代价是一次 `count(*)` —— 因为
    #| 「从末尾数第几行」在 SQL 里必须先知道总行数。
    method slice(Int $offset, Int $length? --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => "slice() needs a non-negative length, got $length")
            if $length.defined && $length < 0;

        my Str $lim = $length.defined ?? ' LIMIT ' ~ $length !! '';

        return self.derived("SELECT * FROM ({$!relation-sql}) AS __duckula_slice"
                          ~ $lim ~ ' OFFSET ' ~ $offset) if $offset >= 0;

        # 负 offset：先数总行数，再跳过 (总数 + offset) 行。
        # greatest(..., 0) 保证 offset 比总行数还长时跳过全部，不报负 OFFSET。
        my Str $skip = 'greatest(count(*) - ' ~ $offset.abs ~ ', 0)';
        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_slice"
                          ~ $lim
                          ~ " OFFSET (SELECT $skip FROM ({$!relation-sql}) AS __duckula_count)");
    }

    #| 转成惰性计划（Polars 的 `lazy()`），之后的算子攒计划树、`collect` 才渲染。
    method lazy(--> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(
            session    => $!session,
            plan       => plan-source($!relation-sql),
            index-cols => $!index-cols,
        );
    }

    #| 导出 Arrow：schema + 逐块 array，交给 pyarrow / Polars 之类的消费者。
    #|
    #|     my $t = $df.arrow;
    #|     say $t.schema.gist;
    #|     $t.chunks: -> $chunk { ... };
    #|     $t.free;
    #|
    #| 返回的对象持有自己的 Result（Arrow 的 schema 引用着它），所以这个
    #| Frame 之后再被复用也无所谓 —— 代价是多执行一次 SELECT。
    method arrow(--> Duckula::Arrow) {
        Duckula::Arrow.from-frame(self);
    }

    #| 直接把结果写成 Arrow IPC 文件（`.arrow` / `.feather`）。
    #|
    #| 等价于 `self.arrow.write-ipc($path, :$format)`，只是省掉自己收尾。
    #| 产物是自描述字节，pyarrow / polars / 任何 Arrow 实现都能直接读 ——
    #| 跨进程交换走这条路，不用 DuckDB 的 `arrow` 扩展。
    method write-ipc(Str:D $path, Str:D :$format = 'file' --> Nil) {
        my $a = self.arrow;
        LEAVE $a.free;
        $a.write-ipc($path, :$format);
    }

    #| 编码成内存里的 IPC 字节（默认 `stream` 格式）。
    #|
    #| 跨进程交换用这个，而不是 C data interface 的裸指针 —— 指针只在导出
    #| 它的进程里有效。字节可以写进管道、塞给 `Inline::Python` 里的
    #| `pa.ipc.open_stream(...)`。
    method ipc-buf(Str:D :$format = 'stream' --> Buf) {
        my $a = self.arrow;
        LEAVE $a.free;
        $a.ipc-buf(:$format);
    }

    # ---------------------------------------------------------------- 写出

    #| 写成 Parquet，返回行数。
    #|
    #| 数据不出 DuckDB：`COPY (<relation-sql>) TO ...` 由 DuckDB 自己做，
    #| 一行都不经过 Raku。压缩默认 zstd（同 pandas 的 pyarrow 默认之外更省），
    #| 可选 uncompressed / snappy / gzip / brotli / lz4 / lz4_raw。
    method to-parquet(Str:D $path, Str:D :$compression = 'zstd' --> Int) {
        Duckula::Write::write-parquet($!session, $!relation-sql, $path,
                                      :$compression);
    }

    #| 写成 CSV，返回行数。
    #|
    #| `:$delimiter` / `:$quote` 必须是单字符；`:$null` 给定后空值写成它。
    #| 路径与选项都经过转义，文件名里带单引号也不会变成注入点。
    method to-csv(
        Str:D $path,
        Bool:D :$header = True,
        Str:D :$delimiter = ',',
        Str:D :$quote = '"',
        Str :$null,
        --> Int
    ) {
        Duckula::Write::write-csv($!session, $!relation-sql, $path,
                                  :$header, :$delimiter, :$quote, :$null);
    }

    #| 写成 JSON，返回行数。`:format<array>`（默认）产出 JSON 数组，
    #| `:format<newline-delimited>` 产出 NDJSON。路径走转义。
    method to-json(Str:D $path, Str:D :$format = 'array' --> Int) {
        Duckula::Write::write-json($!session, $!relation-sql, $path, :$format);
    }

    #| 写成 XLSX，返回行数。有 DuckDB excel 扩展时走 COPY，否则走纯 Raku
    #| 的 XLSX 写出兜底；非默认 sheet 名一律走兜底路径。
    method to-excel(Str:D $path, Str:D :$sheet = 'Sheet1' --> Int) {
        Duckula::Write::write-excel($!session, $!relation-sql, $path,
                                    :$sheet, rows => self.rows,
                                    names => self.names);
    }

    #| 变成一张真表（`CREATE TABLE ... AS`），返回行数。
    #|
    #| 数据不出库，所以不受沙箱限制，也比落文件快。`:replace` 默认 True
    #| （对齐 pandas 的 `to_sql(if_exists => 'replace')`）；`:temporary` 建
    #| 连接级临时表。
    method to-table(
        Str:D $name,
        Bool:D :$replace = True,
        Bool:D :$temporary = False,
        --> Int
    ) {
        Duckula::Write::create-table($!session, $!relation-sql, $name,
                                     :$replace, :$temporary);
    }

    #| 把本 Frame 写进 SQL 库的表（对标 pandas `DataFrame.to_sql`，v0.29.0）。
    #| 不给 `:$db` 时等价于 `to-table`（写当前库）；给了就 ATTACH 外部库再写。
    #| `:if-exists` 三态 fail / replace（默认）/ append。
    method to-sql(
        Str:D $table,
        Str :$db,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Str:D :$if-exists = 'replace',
        --> Int
    ) {
        $!session.to-sql(
            $table, self, :$db, :$alias, :$schema, :$if-exists
        );
    }

    #| 追加到已有表（`INSERT INTO ... SELECT`），返回插入行数。
    #|
    #| 列按位置对齐。表不存在、列数与类型不兼容都让 DuckDB 当场报错 ——
    #| 这里不替它猜。
    method append-to(Str:D $table --> Int) {
        Duckula::Write::insert-into($!session, $!relation-sql, $table);
    }

    #| 在当前 Frame 上执行一段 SQL，`self` 指代它自己。
    #| 绑定方式见 Session.sql-on-frame（临时视图，不是子查询）。
    method sql(Str:D $sql, *@args, *%named, Bool :$unsafe = False --> Duckula::Frame) {
        $!session.sql-on-frame(self, $sql, |@args, |%named, :$unsafe);
    }

    #| 由一条 SQL 派生出新 Frame（同会话）。
    #|
    #| 存在的意义是给 `GroupBy` 这类外部模块用：它们握着「上游 Frame」，
    #| 需要造下游 Frame，但不能 `use Duckula::Frame`（会与 Frame 的
    #| `use Duckula::GroupBy` 形成预编译循环）。有了这个方法，它们只要
    #| `$frame.derived($sql)`，一个类型名都不用写。
    method derived(Str:D $sql, List :$index-cols, Hash :$dtype-meta --> Duckula::Frame) {
        Duckula::Frame.new(
            session    => $!session,
            relation-sql => $sql,
            index-cols => $index-cols.defined ?? $index-cols !! $!index-cols,
            dtype-meta => $dtype-meta.defined ?? $dtype-meta !! $!dtype-meta,
        );
    }

    #| 给 collect 出来的 Frame 贴上惰性路径声明的 dtype 元数据。
    method with-dtype-meta(Hash:D $meta --> Duckula::Frame) {
        self.derived($!relation-sql, :dtype-meta($meta));
    }

    #| 取一列，返回 Series（ColumnView 的薄包装，零拷贝）。
    #|
    #| 会重跑一次 relation-sql 以拿到新的 Result —— ColumnView 的指针属于
    #| result，而物化路径已经消耗掉上一个结果集的游标。取的列多了建议改
    #| 用 `.select` 一次取齐，或直接在 SQL 里聚合。
    method column(Str:D $name --> Duckula::Series) {
        my $res = $!session.conn.query($!relation-sql);
        my List $names = $res.names.List;
        my $idx = $names.first($name, :k);

        die Duckula::X::Frame.new(
            reason => "no column named '$name'; available: {$names.join(', ')}"
        ) unless defined $idx;

        my List $views = $res.column-views.List;

        Duckula::Series.new(
            name => $name, view => $views[$idx], result => $res, frame => self,
            dtype => $!dtype-meta{$name},
        );
    }

    # ---------------------------------------------------------------- 逻辑索引
    #
    # 不藏一份 pandas 式的 Index 元数据：行号是一列显式数据，跟着行走。
    # 因此 sort / filter / concat 之后不需要「元数据传播」，也不会走丢。
    # 语义细节见 Duckula::Index 与 ARCHITECTURE §8.19。

    #| 显式行号列（Polars 的 with_row_index）。0 基，同名列被覆盖。
    method with-row-index(Str:D :$name = 'index', Int:D :$offset = 0 --> Duckula::Frame) {
        my Bool $replace = $name ∈ self.names.Set;
        self.derived(with-row-index-sql(
            $!relation-sql, $name, :$replace, :$offset,
        ));
    }

    #| 索引值对象（v0.28.0）。无参时返回 IndexLabels：有 key 就是 key 列，
    #| 没有 key 就用 0 基行号充当单 level。旧的 :name/:offset 形态仍返回
    #| raw Series，保持 v0.21.0 以来的用法不变。
    multi method index(--> Duckula::IndexLabels) {
        Duckula::IndexLabels.new(
            frame     => self,
            levels    => $!index-cols.List,
            row-based => $!index-cols.elems == 0,
        );
    }

    multi method index(Str:D :$name!, Int:D :$offset = 0) {
        my $src = $name ∈ self.names.Set
            ?? self
            !! self.with-row-index(:$name, :$offset);
        $src.column($name);
    }

    #| 按行号取子集。Int / Range / Positional，负数从末尾算。
    method iloc($rows, Str:D :$name = 'index' --> Duckula::Frame) {
        my $src = $name ∈ self.names.Set
            ?? self
            !! self.with-row-index(:$name);
        check-index-column($name, $src.names, 'iloc');
        $src.derived(iloc-sql($src.relation-sql, $name, $rows));
    }

    #| 按列值定位（pandas `.loc` 的单列形态）。多条件可链式。
    #| 值走 Expr 的参数绑定，列名过白名单。
    multi method loc(Str:D $col, $value --> Duckula::Frame) {
        die Duckula::X::Frame.new(
            reason => "loc: no column named '$col'; available: {self.names.join(', ')}"
        ) unless $col ∈ self.names.Set;
        self.filter(col($col) == $value);
    }

    #| pandas 风格的标签定位：单 level 传标量，MultiIndex 传完整标签元组。
    multi method loc($label --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'loc(label) needs a key; call set-index first'
        ) unless @keys.elems;
        self.filter(index-loc-expr(@keys, $label));
    }

    #| MultiIndex 横切：按某一层取值过滤，并把该层从索引里摘掉。
    method xs($value, :$level = 0 --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'xs needs a key; call set-index first')
            unless @keys.elems;
        my Int $i = level-index(@keys, $level);
        my @rest = remove-level(@keys, $i);
        my $f = self.filter(col(@keys[$i]) == $value);
        @rest.elems ?? $f.set-index(@rest) !! $f.reset-index;
    }

    #| 按索引 level 排序；多列用 ORDER BY 多键，纯 SQL 不搬数据。
    method sort-index(Bool :$desc = False --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'sort-index needs a key; call set-index first')
            unless @keys.elems;
        my Str $order = @keys.map({
            quote-ident($_) ~ ($desc ?? ' DESC' !! ' ASC')
        }).join(', ');
        self.derived('SELECT * FROM (' ~ $!relation-sql
                     ~ ') AS __duckula_sort_index ORDER BY ' ~ $order);
    }

    #| 交换两层的位置，只改元数据，SQL 一行不动。
    method swaplevel($a = 0, $b = 1 --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'swaplevel needs at least two levels')
            unless @keys.elems >= 2;
        self.derived($!relation-sql,
                     index-cols => swap-levels(@keys, $a, $b));
    }

    method droplevel($level = -1 --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'droplevel needs a key; call set-index first')
            unless @keys.elems;
        self.derived($!relation-sql,
                     index-cols => remove-level(@keys, $level));
    }

    method get-level-values($level) { self.index.get-level-values($level) }

    # ---------------------------------------------------------------- 声明式 key 索引
    #
    # v0.21.0 的行号列是「按位置取」；这里的 key 是「按身份对齐」。
    # key 列的清单随 Frame 派生传播（derived 统一出口），但列本身一直是普通列。

    #| 把若干列声明为逻辑 key（pandas 的 `set_index`）。
    #| 与 pandas 不同：key 列**不从数据里消失**，所以不需要 reset_index 才能取回。
    method set-index(*@cols, Bool :$append = False --> Duckula::Frame) {
        my @flat = flatten-args(@cols);
        my @keys = $append ?? (|$!index-cols.List, |@flat) !! @flat;
        check-index-cols(@keys, self.names, 'set-index');
        self.derived($!relation-sql, index-cols => @keys.List);
    }

    #| 清掉 key 声明。`:drop` 会顺手把 key 列也删掉（key 列本来就是普通列）。
    multi method reset-index(Bool :$drop = False --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        return self unless @keys.elems;
        my $f = self.derived($!relation-sql, index-cols => ());
        $drop ?? $f.drop(@keys) !! $f;
    }

    #| 只摘掉一个 level（MultiIndex），列本身保留。
    multi method reset-index($level, Bool :$drop = False --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'reset-index needs a key; call set-index first')
            unless @keys.elems;
        my @rest = remove-level(@keys, $level);
        my $f = self.derived($!relation-sql, index-cols => @rest.List);
        $drop ?? $f.drop((@keys[level-index(@keys, $level)],).List) !! $f;
    }

    #| 按 key 值重排/过滤，对应 pandas 的 `reindex`。
    #|
    #|   $df.set-index('id').reindex(3, 1, 2);      # 单列 key，直接传标量
    #|   $df.set-index(<id g>).reindex((1,'a'), (2,'b'));  # 多列 key
    #|
    #| 给定顺序原样输出；没有对应行的 key 留一行全 NULL（LEFT JOIN）。
    multi method reindex(:$fill --> Duckula::Frame) { self.head(0) }

    multi method reindex(+@rows, :$fill --> Duckula::Frame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'reindex needs a key; call set-index first'
        ) unless @keys.elems;

        my @raw = @rows.elems == 1 && @rows[0] ~~ Positional
            ?? @rows[0].List !! @rows.List;
        my @norm = @raw.map({ ($_ ~~ Positional ?? $_.List !! ($_,).List).item }).List;
        return self.head(0) unless @norm.elems;

        self.derived(reindex-sql(
            $!relation-sql, @keys, @norm, self.names, :$fill,
        ));
    }

    #| 选若干列，返回新的 Frame（SQL 层面只投影这些列）。
    #|
    #| 列名一律过 quote-ident + 白名单（§9.5.3）：
    #|   - quote-ident 保证任何字符都退化成合法标识符；
    #|   - 白名单保证写错的列名当场报错，而不是静默多出一个 NULL 列。
    method select(*@cols --> Duckula::Frame) {
        my @flat = @cols.elems == 1 && @cols[0] ~~ Positional
            ?? @cols[0].List
            !! @cols.List;

        die Duckula::X::Frame.new(reason => 'select() needs at least one column')
            unless @flat.elems;

        my Set $known = self.names.Set;
        my @picked;
        for @flat -> $c {
            my Str $n = $c.Str;
            die Duckula::X::Frame.new(
                reason => "no column named '$n'; available: {self.names.join(', ')}"
            ) unless $known{$n};
            @picked.push: quote-ident($n);
        }

        self.derived("SELECT {@picked.join(', ')} "
                          ~ "FROM ({$!relation-sql}) AS __duckula_select");
    }

    #| 表达式引用的列必须在 names 里，否则拼错的列名会被 DuckDB 静默当成
    #| 「未知标识符」报错，或者更糟——在外层子查询里意外绑定到别的列。
    method !check-columns(Set $cols, Str:D $op --> Nil) {
        return unless $cols.elems;
        my Set $known = self.names.Set;
        for $cols.keys.sort -> $c {
            die Duckula::X::Frame.new(
                reason => "$op refers to unknown column '$c'; "
                        ~ "available: {self.names.join(', ')}"
            ) unless $known{$c};
        }
    }

    #| 过滤行。表达式版本，列名已在 col() 里过 quote-ident：
    #|
    #|   $df.filter(col('amount') > 100);
    #|   $df.filter((col('city').starts-with('北')) & (col('amount') > 100));
    multi method filter(Duckula::Expr:D $pred --> Duckula::Frame) {
        self!check-columns($pred.columns, 'filter');
        self.derived("SELECT * FROM ({$!relation-sql}) AS __duckula_filter "
                          ~ "WHERE {$pred.render}");
    }

    #| 过滤行。SQL 片段版本，值必须走 `?` 绑定：
    #|
    #|   $df.filter('city = ?', $city);
    #|
    #| 片段里的列名是裸写的（这是受信代码入口），但值和语句边界仍然受网关保护：
    #| 不许夹带多条语句，`?` 个数必须与实参一致。
    multi method filter(Str:D $pred, *@args --> Duckula::Frame) {
        check-fragment($pred, :params(@args.elems));
        my Str $p = @args.elems ?? render-bindings($pred, @args) !! $pred;
        self.derived("SELECT * FROM ({$!relation-sql}) AS __duckula_filter "
                          ~ "WHERE $p");
    }

    #| 新增（或覆盖）一列：
    #|
    #|   $df.with-column((col('amount') * 1.1).alias('amount_taxed'));
    #|   $df.with-column(col('city').upper, :name<city_up>);
    #|   $df.with-column(col('amount').sum.over('dept').alias('dept_total'));
    #|
    #| 三种输入各走一条路：
    #|   - 窗口表达式（`.over` / `.cum-sum` / `.rank` …）：原样拼上；
    #|   - 裸聚合（`col('x').sum`）：补 `OVER ()` 变成逐行广播 —— 这是 Polars
    #|     `with_columns(pl.col('x').sum())` 的语义，也是 pandas
    #|     `df['t'] = df['x'].sum()` 的语义。不补的话 DuckDB 会按全表聚合处理，
    #|     整个 frame 当场塌成一行；
    #|   - 聚合混在算术里（`sum(x) / count(*)`）：补不了 OVER，因为 OVER 只能
    #|     跟在一个函数调用后面，所以直接报错并告诉用户怎么写。
    multi method with-column(Duckula::Expr:D $e, Str :$name --> Duckula::Frame) {
        my $raw = $name // $e.as;
        die Duckula::X::Frame.new(
            reason => 'with-column needs an alias: '
                    ~ 'use .alias("name") on the expression or pass :name<name>'
        ) unless $raw.defined && $raw.Str ne '';
        my Str $n = $raw.Str;

        self!check-columns($e.columns, 'with-column');

        my Str $expr = $e.render;

        if $e.window.defined {
            # 已经是窗口函数，自带 OVER (…)，不用再动。
        } elsif $e.bare-agg {
            $expr ~= ' OVER ()';
        } elsif $e.is-aggregate {
            die Duckula::X::Frame.new(
                reason => "with-column can't use an aggregate inside a larger "
                        ~ "expression ('$expr'); put .over() on each aggregate, "
                        ~ "e.g. (col('x').sum.over / len().over)"
            );
        }

        # 覆盖已有列时必须先把它 EXCLUDE 掉。`SELECT *, expr AS "v"` 会产出
        # 两个同名的 v，之后 `$df.column('v')` 只拿得到第一个（旧值），
        # 而 gist 里看起来"新值好像生效了"—— 这种静默错最难查。
        my Set $known = self.names.Set;
        my Str $head = ($n ∈ $known)
            ?? 'SELECT * EXCLUDE (' ~ quote-ident($n) ~ '), '
            !! 'SELECT *, ';

        my Str $rn = '';
        my Str $src;

        if $e.window.defined {
            # 窗口算子会**改变输出行序**：`rank() OVER (ORDER BY v DESC)` 之后
            # DuckDB 直接按 v 降序吐行，`sum() OVER (PARTITION BY g)` 之后按组
            # 聚拢。这违反了 with-column「只加一列、别动别的」的约定（五个
            # 测试用例全挂在这上面）。所以先在内层给每行钉一个扫描序行号，
            # 外层算完窗口再按它排回去。
            $rn = '__duckula_ord';
            $rn ~= '_' while $rn ∈ $known;
            $src = 'FROM (SELECT *, row_number() OVER () AS ' ~ quote-ident($rn)
                 ~ " FROM ({$!relation-sql}) AS __duckula_win_src) AS __duckula_win";
        } else {
            $src = "FROM ({$!relation-sql}) AS __duckula_with";
        }

        my Str $sql = $head ~ $expr ~ ' AS ' ~ quote-ident($n) ~ ' ' ~ $src;

        if $e.window.defined {
            $sql = 'SELECT * EXCLUDE (' ~ quote-ident($rn) ~ ') FROM (' ~ $sql
                 ~ ') AS __duckula_win_out ORDER BY ' ~ quote-ident($rn);
        }

        self.derived($sql);
    }

    #| 一次加多列，等价于连续调用 `with-column`（Polars 的 `with_columns`）。
    #|
    #|   $df.with-columns(
    #|       col('amount').sum.over('dept').alias('dept_total'),
    #|       (col('amount') / col('dept_total')).alias('share'),
    #|   );
    #|
    #| 后一个表达式能看到前一个刚加的列 —— 因为每一步都是「新的 SELECT 套在
    #| 上一层外面」，不是同时投影。
    multi method with-columns(*@exprs --> Duckula::Frame) {
        my @flat = @exprs.elems == 1 && @exprs[0] ~~ Positional
            ?? @exprs[0].List
            !! @exprs.List;

        my $f = self;
        for @flat -> $e {
            $f = $f.with-column($e);
        }
        $f;
    }

    #| 按列分组，返回中间对象，必须接 `.agg(...)` 或 `.count`：
    #|
    #|   $df.group-by('city').agg(col('amount').sum.alias('total'));
    #|   $df.group-by('city', 'country').agg(len().alias('n'));
    #|   $df.group-by(col('city').upper.alias('city_up')).agg(col('amount').max);
    #|
    #| 列名（含表达式里引用到的列）一律过白名单，拼错当场报错。
    multi method group-by(*@keys --> Duckula::GroupBy) {
        my @flat = @keys.elems == 1 && @keys[0] ~~ Positional
            ?? @keys[0].List
            !! @keys.List;

        my @exprs = @flat.map(-> $k {
            $k ~~ Duckula::Expr ?? $k !! col($k.Str);
        });

        for @exprs -> Duckula::Expr $e {
            self!check-columns($e.columns, 'group-by');
        }

        Duckula::GroupBy.new(frame => self, keys => @exprs);
    }

    #| 全表聚合，不分组：
    #|
    #|   $df.agg(len().alias('n'), col('amount').sum.alias('total'));
    #|
    #| 内部就是「零个分组键的 group-by」，所以两种写法的语义完全一致。
    method agg(*@aggs --> Duckula::Frame) {
        Duckula::GroupBy.new(frame => self, keys => ()).agg(|@aggs);
    }

    #| 和另一张表连接，返回新 Frame（仍然只是 SQL）。
    #|
    #|   $orders.join($depts, on => 'dept_id');                  # 同名键
    #|   $orders.join($depts, on => <dept_id region>);           # 多个同名键
    #|   $orders.join($depts, on => 'dept_id' => 'did');         # 异名键（Pair）
    #|   $orders.join($depts, on => 'dept_id', :how<left>);
    #|   $orders.join($depts, on => 'dept_id', :how<anti>);
    #|   $orders.join($depts, :how<cross>);                      # 笛卡尔积
    #|
    #| `:how` 取 inner（默认）/ left / right / full（同 outer）/ semi / anti /
    #| cross。semi / anti 只输出左表的列。
    #|
    #| 列名冲突时右侧列自动加 `:suffix`（默认 `_right`），且只在真的撞名时加。
    #| 连接键的右侧列不重复输出（和 SQL 的 `USING` 语义一致）。
    multi method join(
        Duckula::Frame:D $right,
        :$on,
        Str :$how = 'inner',
        Str :$suffix = '_right',
        --> Duckula::Frame
    ) {
        join-frames(self, $right, :$on, :$how, :$suffix);
    }

    #| pandas 风格的近似连接（merge_asof）：按有序键找最近的前/后一行。
    #|
    #|   $left.merge-asof($right, :on<ts>);                    # backward（默认）
    #|   $left.merge-asof($right, :on<ts>, :by<symbol>);       # 分组内匹配
    #|   $left.merge-asof($right, :on<ts>, :direction<nearest>, :tolerance(3));
    #|
    #| backward/forward 下推 DuckDB 原生 ASOF JOIN；nearest 用距离排序取
    #| 第一行（无原生 ASOF 模式，代价更高）。`:how` 取 left（默认）/ inner。
    method merge-asof(
        Duckula::Frame:D $right,
        :$on!, :$by, Str :$direction = 'backward', Str :$how = 'left',
        :$tolerance, Str :$suffix = '_right',
        --> Duckula::Frame
    ) {
        my Str $lk = $on ~~ Pair ?? $on.key.Str
                   !! ($on ~~ Positional ?? $on[0].Str !! $on.Str);
        my $dtype = $!dtype-meta{$lk}.defined
            ?? $!dtype-meta{$lk} !! self.dtype-of($lk);
        my %spec = asof-layout(
            self.names, $right.names,
            :$on, :$by, :$direction, :$how, :$tolerance, :$suffix,
            :key-dtype($dtype),
        );
        self.derived(asof-sql($!relation-sql, $right.relation-sql, %spec));
    }

    #| pandas 的 `pipe`：把当前 Frame 作为第一个参数交给闭包，便于链式复用。
    method pipe(&fn, *@args, *%kw) { &fn(self, |@args, |%kw) }

    #| 按声明的 key 做 FULL OUTER JOIN，每列左值优先、右值兜底。
    method combine-first(Duckula::Frame:D $other --> Duckula::Frame) {
        my @ka = self.index-cols.List;
        my @kb = $other.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'combine-first needs matching index keys on both frames'
        ) unless @ka.elems && @ka eqv @kb && $other.session === $!session;
        self.derived(combine-first-sql(
            $!relation-sql, $other.relation-sql, @ka,
            self.names, $other.names,
        ));
    }

    #| 检查声明的 index 是否有重复标签：有就报错，否则 True。
    method verify_integrity(--> Bool) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'verify_integrity needs a key; call set-index first'
        ) unless @keys.elems;
        my Str $q = 'SELECT ' ~ @keys.map({ quote-ident($_) }).join(', ')
                  ~ ' FROM (' ~ $!relation-sql ~ ') AS __duckula_vi '
                  ~ 'GROUP BY ' ~ @keys.map({ quote-ident($_) }).join(', ')
                  ~ ' HAVING count(*) > 1 LIMIT 1';
        die Duckula::X::Frame.new(
            reason => 'index labels are not unique'
        ) if $!session.conn.query($q).arrays.List.elems;
        True;
    }

    #| 按某列排序。列名过 quote-ident + 白名单。
    multi method sort-values(Str:D $column, Bool :$desc = False --> Duckula::Frame) {
        my Set $known = self.names.Set;
        die Duckula::X::Frame.new(
            reason => "no column named '$column'; available: {self.names.join(', ')}"
        ) unless $known{$column};

        self.derived("SELECT * FROM ({$!relation-sql}) AS __duckula_sort "
                          ~ "ORDER BY {quote-ident($column)}" ~ ($desc ?? ' DESC' !! ''));
    }

    # ---------------------------------------------------------------- 清洗与重塑

    #| 纵向拼接若干 Frame（pandas 的 `pd.concat` / Polars 的 `pl.concat`）。
    #|
    #|   $a.concat($b);
    #|   $a.concat($b, $c);
    #|   $a.concat($b, :strict);   # 列名必须完全一致
    #|
    #| 列按**名字**对齐（`UNION ALL BY NAME`）：缺的列补 NULL，列序沿用第一个
    #| Frame 再追加后面新出现的列。这正是 pandas `concat` 的默认行为，等价于
    #| Polars 的 `how="diagonal"`；`:strict` 对应 Polars 的 `how="vertical"`。
    #|
    #| 只认同会话的 Frame 拼接：跨会话拼出来的 SQL 会在错误的连接上执行，
    #| 结果要么报错要么含糊，不如在这里拦住。
    multi method concat(*@others, Bool :$strict = False --> Duckula::Frame) {
        my @flat = flatten-args(@others);
        die Duckula::X::Frame.new(
            reason => 'concat needs at least one other frame'
        ) unless @flat.elems;

        my @frames;
        @frames.push: self;

        for @flat -> $f {
            die Duckula::X::Frame.new(
                reason => 'concat expects Frames, got ' ~ $f.^name
            ) unless $f ~~ Duckula::Frame;
            die Duckula::X::Frame.new(
                reason => 'concat: every frame must belong to the same session'
            ) unless $f.session === $!session;
            @frames.push: $f;
        }

        if $strict {
            my @sets = @frames.map({ $_.names.List });
            check-same-columns(@sets, 'concat(:strict)');
        }

        self.derived(concat-sql(@frames.map(*.relation-sql).List));
    }

    #| 去重（pandas 的 `drop_duplicates` / Polars 的 `unique`）。
    #|
    #|   $df.unique;                          # 整行相同才算重复
    #|   $df.unique('city');                  # 按 city 去重
    #|   $df.unique(<city dept>, :keep<last>);
    #|   $df.unique('city', :keep<none>);     # 只留 city 出现一次的行
    #|   $df.unique('city', :keep<any>);      # 最省，但不保证行序
    #|
    #| `first` / `last` / `none` 都**保持输入行序**：SQL 没有天然行序，所以
    #| 先钉扫描序行号、去重后再按它排回来（`Duckula::Clean::unique-sql`）。
    multi method unique(*@subset, Str :$keep = 'first' --> Duckula::Frame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'unique');

        self.derived(unique-sql($!relation-sql, @cols, $keep, @names));
    }

    #| 单列频次表（pandas 的 `value_counts`）。
    #|
    #|   $df.value-counts('city');
    #|   # city | count
    #|   # 北京 | 3
    #|   # 上海 | 2
    #|
    #| `:normalize` 再加一列 `proportion`（占比，分母是**非空**行数，同 pandas）；
    #| `:keep-nulls` 让 NULL 也成为一个分组（默认丢，同 pandas）；`:sort(False)`
    #| 关掉按计数降序。
    method value-counts(
        Str:D $column,
        Bool :$sort = True,
        Bool :$normalize = False,
        Bool :$keep-nulls = False,
        --> Duckula::Frame
    ) {
        self.derived(value-counts-sql(
                $!relation-sql, $column, self.names,
                :$sort, :$normalize, :$keep-nulls,
            ));
    }

    #| 改列名（pandas 的 `rename` / Polars 的 `rename`）。
    #|
    #|   $df.rename('amount' => '金额');
    #|   $df.rename('a' => 'b', 'b' => 'c');      # 一次调用里可链式换名
    #|   $df.rename(%( a => 'b' ));
    #|   $df.rename('nope' => 'x', :!strict);     # 忽略陌生列名
    #|
    #| 未改名的列原样保留。新名撞上「没被换走的已有列」直接报错 —— 否则会
    #| 产出两列同名，之后按名取值只拿得到前一个。
    multi method rename(*@maps, Bool :$strict = True --> Duckula::Frame) {
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        my @items = rename-items(self.names, $map, :$strict);
        my $f = self.derived('SELECT ' ~ @items.join(', ')
                          ~ " FROM ({$!relation-sql}) AS __duckula_rename");
        # key 元数据跟着改名走，不能指向已经不存在的列。
        if $!index-cols.elems {
            my %ren;
            for as-pairs($map, 'rename') -> $p {
                %ren{$p.key.Str} = $p.value.Str;
            }
            my @keys = $!index-cols.List.map({
                %ren{$_}:exists ?? %ren{$_} !! $_
            }).List;
            $f = $f.set-index(@keys);
        }
        $f;
    }

    #| 删列（pandas 的 `drop(columns=…)` / Polars 的 `drop`）。
    #|
    #|   $df.drop('tmp');
    #|   $df.drop(<tmp raw>);
    #|
    #| 想把列删光会报错 —— 零列的 Frame 之后什么都做不了，这通常是笔误。
    multi method drop(*@cols --> Duckula::Frame) {
        my @dropped = flatten-args(@cols);
        my @items = drop-items(self.names, @dropped);
        my $f = self.derived('SELECT ' ~ @items.join(', ')
                          ~ " FROM ({$!relation-sql}) AS __duckula_drop");
        # 被删掉的 key 列要一起从元数据里摘掉。
        if $!index-cols.elems {
            my @keys = $!index-cols.List.grep({ $_ ∉ @dropped.Set }).List;
            $f = @keys.elems ?? $f.set-index(@keys) !! $f.reset-index;
        }
        $f;
    }

    #| 删掉含空值的行（pandas 的 `dropna` / Polars 的 `drop_nulls`）。
    #|
    #|   $df.drop-nulls;                        # 任一列为空就丢
    #|   $df.drop-nulls(<city amount>);         # 只看这两列
    #|   $df.drop-nulls(:how<all>);             # 所有列都空才丢
    multi method drop-nulls(*@subset, Str :$how = 'any' --> Duckula::Frame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'drop-nulls');

        self.derived("SELECT * FROM ({$!relation-sql}) AS __duckula_nn "
                          ~ 'WHERE ' ~ null-predicate(@cols, $how));
    }

    #| 填空值（pandas 的 `fillna` / Polars 的 `fill_null` / `fill_nan`）。
    #|
    #|   $df.fill-nulls(:value(0));                     # 全部列填 0
    #|   $df.fill-nulls('amount', :value(0));
    #|   $df.fill-nulls('amount', :strategy<mean>);     # 用均值填
    #|   $df.fill-nulls('amount', :strategy<ffill>);    # 用上一个非空值填
    #|   $df.fill-nulls('amount', :strategy<bfill>);    # 用下一个非空值填
    #|
    #| `:value` 与 `:strategy` 只能给一个。策略里 `mean` / `median` 是整列聚合，
    #| 与行序无关；`ffill` / `bfill` 需要行序，会先钉一个扫描序行号、填完再按
    #| 它排回去 —— 所以「上一个」指的是**当前 Frame 的行序**，和 Polars 一样。
    #|
    #| 有类型问题时让 DuckDB 报错：`mean` 填 VARCHAR 列、`:value` 与列类型不相容
    #| 都会失败，这里不替它猜 —— 但要注意 Frame 是惰性的，错误会在物化
    #| （`gist` / `rows` / `collect`）时才出现。因此**整帧填同一个值只在列类型
    #| 相容时成立**：`fill-nulls(:value(0))` 碰上 VARCHAR 列会被拒绝，混合类型
    #| 请指定列子集。
    multi method fill-nulls(*@subset, :$value, Str :$strategy --> Duckula::Frame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'fill-nulls');

        my Str $mode = fill-mode(:$value, :$strategy);
        my Bool $win = needs-seq($mode);
        my Str $seq = $win ?? private-name(@names, '__duckula_seq') !! '';

        my @items = fill-items(@cols, $mode, :$value, :$seq);

        # `* EXCLUDE (cols)` 把那几列剔掉、再由 items 用新表达式补回来。
        # 子集等于全部列时 EXCLUDE 会把 `*` 清空，只剩 items —— 合法，但这里
        # 仍照写，为的是让两条路径（有锚 / 无锚）共用同一段投影。
        my Str $proj = 'SELECT * EXCLUDE (' ~ quoted-list(@cols) ~ '), '
                     ~ @items.join(', ');

        my Str $src = $win
            ?? '(SELECT *, row_number() OVER () AS ' ~ quote-ident($seq)
             ~ " FROM ({$!relation-sql}) AS __duckula_fill_src) AS __duckula_fill_w"
            !! "({$!relation-sql}) AS __duckula_fill";

        my Str $sql = $proj ~ ' FROM ' ~ $src;

        # 带 ORDER BY 的窗口可能改变输出行序（§8.9 记过），所以外面再按行号
        # 排回去，顺手把辅助列剔掉。
        if $win {
            $sql = 'SELECT * EXCLUDE (' ~ quote-ident($seq) ~ ') FROM (' ~ $sql
                 ~ ') AS __duckula_fill_out ORDER BY ' ~ quote-ident($seq);
        }

        self.derived($sql);
    }

    #| 改列类型（pandas 的 `astype` / Polars 的 `cast`）。
    #|
    #|   $df.cast(%( id => 'VARCHAR', amount => 'DECIMAL(18,4)' ));
    #|   $df.cast('id' => 'BIGINT');
    #|
    #| 没提到的列原样保留。类型名过白名单（见 `Duckula::Clean::check-type-name`）：
    #| `CAST(x AS ...)` 里的类型不能参数绑定，只能拼文本，所以必须校验。
    #| 表达式级的转换用 `col('x').cast('BIGINT')`。
    multi method cast(*@maps, Bool :$strict = False --> Duckula::Frame) {
        my @names = self.names;
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        my @pairs = as-pairs($map, 'cast');

        die Duckula::X::Frame.new(reason => 'cast needs at least one column')
            unless @pairs.elems;

        my %target;
        for @pairs -> $p {
            my Str $c = $p.key.Str;
            need-cols(($c,), @names, 'cast');
            my $d = as-dtype($p.value);
            %target{$c} = resolve-dtype($!session, $!relation-sql, $c, $d);
            check-dtype-nulls($!session, $!relation-sql, $c, %target{$c}, :$strict);
        }

        my @items = @names.map(-> $c {
            %target{$c}:exists
                ?? cast-expr-for($c, %target{$c}) ~ ' AS ' ~ quote-ident($c)
                !! quote-ident($c) ~ ' AS ' ~ quote-ident($c);
        });

        my %meta = $!dtype-meta.Hash;
        %meta{$_} = %target{$_} for %target.keys;

        self.derived('SELECT ' ~ @items.join(', ')
                          ~ " FROM ({$!relation-sql}) AS __duckula_cast",
                     :dtype-meta(%meta));
    }

    #| pandas 的拼法；语义与 cast 完全一致。
    multi method astype(*@maps, Bool :$strict = False --> Duckula::Frame) {
        self.cast(|@maps, :$strict);
    }

    #| 展开列表列（pandas / Polars 的 `explode`）。
    #|
    #|   $df.explode('tags');
    #|   $df.explode(<x y>);              # 多列按位置展开，长度不齐补 NULL
    #|   $df.explode('tags', :!keep-empty);  # 空列表/NULL 不产生行（DuckDB 原生行为）
    #|
    #| 默认把空列表与 NULL 各替换成 `[NULL]` 再展开，保留一行 NULL —— 与
    #| pandas / Polars 一致。展开列保持原名，之后还能继续 filter / select。
    multi method explode(*@cols, Bool :$keep-empty = True --> Duckula::Frame) {
        my @names = self.names;
        my @items = explode-items(@names, flatten-args(@cols), :$keep-empty);

        self.derived(project-sql($!relation-sql, @items, '__duckula_ex'));
    }

    #| 宽表转长表（pandas 的 `melt` / Polars 的 `unpivot`）。
    #|
    #|   $df.unpivot(<q1 q2>, :index<id>);
    #|   #   id | variable | value
    #|   $df.unpivot('q1', :index<id>, :variable-name<quarter>, :value-name<amount>);
    #|
    #| `on` 是要展开的值列，`index` 是保持不动的锚列。新列名撞上已有列时
    #| 自动加下划线（和辅助列同一套规则），不会静默覆盖。
    multi method unpivot(*@on, :$index, Str :$variable-name = 'variable',
                         Str :$value-name = 'value' --> Duckula::Frame) {
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @uncols = flatten-args(@on);
        @uncols = @names.grep({ !@idx.Set{$_} }) unless @uncols.elems;
        check-unpivot-columns(@uncols, @idx, @names);

        my Str $var = private-name(@names, $variable-name);
        my Str $val = private-name(@names, $value-name);

        self.derived(unpivot-sql($!relation-sql, @uncols, @idx, $var, $val));
    }

    #| 长表转宽表（pandas 的 `pivot_table` / Polars 的 `pivot`）。
    #|
    #|   $df.pivot(:on<quarter>, :index<id>, :values<amount>);
    #|   #   id | q1  | q2
    #|   $df.pivot(:on<quarter>, :index<id>, :values<amount>, :agg<count>);
    #|
    #| `on` 的取值决定输出列名，所以调用时要跑一次 `SELECT DISTINCT on`
    #| 拿分组值（这是唯一一个建算子时就读数据的动词，eager/lazy 都如此）。
    #| 聚合函数走白名单，见 `Duckula::Reshape::check-agg`。
    #|
    #| 为什么不用 DuckDB 原生 PIVOT：它被语句分类器判成 MULTI，过不了只读
    #| 守卫；条件聚合达到同样效果，列名还可控（§8.17）。
    method pivot(
        Str:D :$on!,
        :$index,
        :$values,
        Str :$agg = 'sum',
        Bool :$keep-nulls = False,
        --> Duckula::Frame
    ) {
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @vls = $values.defined ?? flatten-args(($values,)) !! ();
        need-cols(($on,), @names, 'pivot');
        need-cols(@idx, @names, 'pivot');

        my @vals = @vls.elems
            ?? @vls
            !! @names.grep({ $_ ne $on && !@idx.Set{$_} }).List;
        need-cols(@vals, @names, 'pivot');
        die Duckula::X::Frame.new(reason => 'pivot: nothing left to aggregate')
            unless @vals.elems;

        # pandas 的默认 aggfunc 叫 'mean'，DuckDB 的聚合函数叫 'avg'。
        my Str $a = check-agg($agg);
        my @keys = pivot-keys($!session.conn, $!relation-sql, $on,
                              (), :$keep-nulls);

        self.derived(pivot-sql($!relation-sql, $on, @idx, @vals,
                                      @keys, $a, :$keep-nulls));
    }

    #| 频率交叉表（pandas.crosstab）。
    #|
    #|   $df.crosstab(:index<gender>, :columns<city>);
    #|   $df.crosstab(:index<gender>, :columns<city>, :normalize<index>);
    #|
    #| `normalize` 接受 'all' / 'index' / 'columns'，True 等价于 'all'，False 等价于 ''。
    #| 给了 `values` 就变成加权表：`aggfunc(values)` 而不是每行计 1。
    method crosstab(
        :$index!,
        :$columns!,
        :$values,
        Str :$agg = 'count',
        :$normalize = '',
        :$fill-value,
        Bool :$keep-nulls = False,
        --> Duckula::Frame
    ) {
        my @names = self.names;
        need-cols(($index,), @names, 'crosstab');
        need-cols(($columns,), @names, 'crosstab');
        need-cols(($values,), @names, 'crosstab') if $values.defined;

        my Str $how = $normalize ~~ Bool:D
            ?? ($normalize ?? 'all' !! '')
            !! ($normalize // '').Str;
        my @keys = pivot-keys($!session.conn, $!relation-sql, $columns.Str,
                              (), :$keep-nulls);
        self.derived(crosstab-sql(
            $!relation-sql, $index.Str, $columns.Str, @keys,
            :normalize($how), :$fill-value, :$values, :$agg,
        ));
    }

    #| 聚合透视表（pandas.pivot_table）。
    #|
    #|   $df.pivot-table(:index<dept>, :columns<quarter>, :values<amount>);
    #|   $df.pivot-table(:index<dept>, :columns<quarter>, :values<amount>,
    #|                  :agg<count>, :fill-value(0), :margins);
    #|
    #| 默认聚合是 `mean`（pandas 的默认值），和 `pivot` 的 `sum` 不同。
    #| `margins` 加一行/一列合计（键名 'All'），走 GROUPING SETS。
    method pivot-table(
        :$index!,
        :$columns!,
        :$values,
        Str :$agg = 'mean',
        Bool :$margins = False,
        :$fill-value,
        Bool :$keep-nulls = False,
        --> Duckula::Frame
    ) {
        my @names = self.names;
        my @idx = flatten-args(($index,));
        my @cols = flatten-args(($columns,));
        die Duckula::X::Frame.new(reason => 'pivot-table: columns must be a single column')
            unless @cols.elems == 1;
        need-cols(@idx, @names, 'pivot-table');
        need-cols(@cols, @names, 'pivot-table');

        my @vals = $values.defined
            ?? flatten-args(($values,))
            !! @names.grep({ $_ ∉ @idx.Set && $_ ∉ @cols.Set }).List;
        need-cols(@vals, @names, 'pivot-table');
        die Duckula::X::Frame.new(reason => 'pivot-table: nothing left to aggregate')
            unless @vals.elems;

        # pandas 的默认 aggfunc 叫 'mean'，DuckDB 的聚合函数叫 'avg'。
        my Str $a = check-agg($agg.trim.lc eq 'mean' ?? 'avg' !! $agg);
        my @keys = pivot-keys($!session.conn, $!relation-sql, @cols[0],
                              (), :$keep-nulls);
        self.derived(pivot-table-sql(
            $!relation-sql, @idx, @cols[0], @keys, @vals, $a,
            :$margins, :$fill-value,
        ));
    }

    #| 采样（pandas 的 `sample` / Polars 的 `sample`）。
    #|
    #|   $df.sample(:n(2));                    # 取 2 行（无放回）
    #|   $df.sample(:frac(0.5));               # 每行 50% 概率
    #|   $df.sample(:n(2), :seed(42));         # 可复现
    #|
    #| `n` 走 `RESERVOIR`、`frac` 走 `BERNOULLI`，两者只能给一个。种子走
    #| `REPEATABLE`，同一输入同一种子必得同一批行。
    method sample(Int :$n, :$frac, Int :$seed --> Duckula::Frame) {
        self.derived(sample-sql($!relation-sql, :$n, :$frac, :$seed));
    }

    # ------------------------------------------------------------ 统计（v0.25.0）

    #| 相关矩阵。首列是行标签（真实列，声明为 key），其余列名是原数值列。
    #| pearson / spearman；:$columns 不给时用全部列。
    method corr(Str:D :$method = 'pearson', :$columns --> Duckula::Frame) {
        self!stats-matrix(:fn<corr>, :$method, :$columns);
    }

    #| 协方差矩阵；:$ddof(0) 改为总体协方差。
    method cov(Int:D :$ddof = 1, :$columns --> Duckula::Frame) {
        self!stats-matrix(:fn(cov-fn(:$ddof)), :$columns);
    }

    method !stats-matrix(Str:D :$fn!, Str:D :$method = 'pearson',
                         :$columns! --> Duckula::Frame) {
        my @cols = norm-stat-cols($columns, self.names, $fn);
        # 行标签列不能撞上原列名，否则矩阵里会有两个同名列。
        my Set $taken = self.names.Set;
        my Str $label = 'index';
        $label ~= '_' while $label ∈ $taken;
        my Str $sql = stats-matrix-sql($!relation-sql, @cols,
                                        :$fn, :$method, :$label);
        self.derived($sql).set-index($label);
    }

    #| 每列偏度 / 超额峰度，返回单行 Frame（列名保持原样）。
    method skew(:$columns --> Duckula::Frame) {
        my @cols = norm-stat-cols($columns, self.names, 'skew');
        self.derived(row-stats-sql($!relation-sql, @cols, 'skewness'));
    }
    method kurt(:$columns --> Duckula::Frame) {
        my @cols = norm-stat-cols($columns, self.names, 'kurt');
        self.derived(row-stats-sql($!relation-sql, @cols, 'kurtosis'));
    }

    #| 按列值取前 / 后 n 行（pandas 的 nlargest / nsmallest）。
    #| $columns 可给一列或多列，不给时按全部列排序；keep 见 Stats 构件层。
    method nlargest(Int:D $n, $columns = Nil,
                    Str:D :$keep = 'first' --> Duckula::Frame) {
        my @by = $columns.defined
            ?? norm-stat-cols($columns, self.names, 'nlargest')
            !! self.names;
        self.derived(top-n-sql($!relation-sql, @by, $n,
                               desc => True, :$keep, known => self.names));
    }
    method nsmallest(Int:D $n, $columns = Nil,
                     Str:D :$keep = 'first' --> Duckula::Frame) {
        my @by = $columns.defined
            ?? norm-stat-cols($columns, self.names, 'nsmallest')
            !! self.names;
        self.derived(top-n-sql($!relation-sql, @by, $n,
                               desc => False, :$keep, known => self.names));
    }

    #| 每列一行的数据概览（DuckDB 的 `SUMMARIZE`）。
    #|
    #| 输出固定 12 列：`column_name` / `column_type` / `min` / `max` /
    #| `approx_unique` / `avg` / `std` / `q25` / `q50` / `q75` / `count` /
    #| `null_percentage`。非数值列的统计量是 NULL（DuckDB 的行为）。
    #|
    #| 和 pandas `describe` 的差别：这里是「每列一行」，pandas 是「每个统计量
    #| 一行」；这里还多出类型、近似唯一值数和空值率 —— 信息量更大。
    method describe(--> Duckula::Frame) {
        self.derived(describe-sql($!relation-sql));
    }

    # =================================================================
    # 常用属性与函数式 API（v0.27.0）
    # =================================================================

    #| 列名 → DuckDB 类型名（来自 `DESCRIBE`，只问 schema 不搬数据）。
    method dtypes(--> Hash) {
        my $res = $!session.conn.query(
            'DESCRIBE SELECT * FROM (' ~ $!relation-sql ~ ') AS __duckula_dtypes'
        );
        my %out;
        for $res.arrays.List -> $row {
            %out{$row[0].Str} = $row[1].Str;
        }
        %out;
    }

    #| 列名 → Duckula::Dtype（v0.30.0）。`.dtypes` 仍是原始 DuckDB 类型串，
    #| 这里补上 nullable / categories 这些逻辑语义；没有被 cast 声明过的列
    #| 按物理类型反查一个 dtype。
    method schema(--> Hash) {
        my %out;
        for self.dtypes.kv -> $c, $t {
            my Str $name = $c.Str;
            %out{$name} = $!dtype-meta{$name}.defined
                ?? $!dtype-meta{$name}
                !! dtype-from-sql($t.Str);
        }
        %out;
    }

    #| 单列的 dtype，列名走白名单。
    method dtype-of(Str:D $name --> Duckula::Dtype) {
        need-cols(($name,), self.names, 'dtype-of');
        self.schema{$name};
    }

    #| 一页文字摘要，形状接近 pandas 的 `DataFrame.info()`。
    #| 返回 Str（不直接打印），`say $df.info` 即可。每列的非空计数在
    #| 同一条 SELECT 里算完，只有类型来自额外的 DESCRIBE。
    method info(--> Str) {
        my List $names = self.names;
        # count() 是 nullable BIGINT，rakupp 上 DB::DuckDB 的 bitmap 解码有
        # 既有缺陷（见 §8.29 的 list-dbs）；转成 VARCHAR 再 .Int 两端都稳。
        my @counts = $names.kv.map(-> $i, $n {
            'CAST(count(' ~ quote-ident($n) ~ ') AS VARCHAR) AS '
              ~ quote-ident("__nn_$i")
        });
        my Str $q = 'SELECT CAST(count(*) AS VARCHAR) AS '
                  ~ quote-ident('__duckula_n')
                  ~ (@counts.elems ?? ', ' ~ @counts.join(', ') !! '')
                  ~ ' FROM (' ~ $!relation-sql ~ ') AS __duckula_info';
        my @row = $!session.conn.query($q).arrays.List[0].List;
        my Int $n = @row[0].Int;
        my Hash $types = self.dtypes;

        my @lines = "Duckula::Frame: $n rows × {$names.elems} columns",
                    '#   Column  Non-Null Count  Dtype';
        for $names.kv -> $i, $name {
            my Int $non-null = @row[$i + 1].Int;
            @lines.push: sprintf('%-3d %-8s %-5d non-null      %s',
                                 $i, $name, $non-null, $types{$name} // '?');
        }
        @lines.join("\n");
    }

    #| pandas 的 `DataFrame.size`：元素总数 = 行数 × 列数。
    method size(--> Int) { self.elems * self.names.elems }

    #| pandas 的 `DataFrame.empty`：没有行或没有列。
    method empty(--> Bool) { self.elems == 0 || self.names.elems == 0 }

    #| where / mask 共用的逐列条件替换。条件为 Expr 时走列名白名单；
    #| 为字符串片段时走 Guard；为 Series 时要求来自同一个 Frame。
    method !fill-frame($cond, $other, @args, Bool:D :$mask --> Duckula::Frame) {
        my Str $c;
        my Set $cols;
        my Str $source = $!relation-sql;
        if $cond ~~ Duckula::Series {
            my $cf = $cond.frame;
            die Duckula::X::Frame.new(
                reason => 'condition Series must come from the same session'
            ) unless $cf.defined && $cf.session === $!session;
            die Duckula::X::Frame.new(
                reason => 'condition Series must have the same columns as this Frame'
            ) unless Set.new($cf.names) eqv self.names.Set;
            die Duckula::X::Frame.new(
                reason => "no condition column named '{$cond.name}'"
            ) unless $cond.name ∈ $cf.names.Set;

            # 布尔 Series 通常是 self 的派生 Frame（那一列已变成 true/false）。
            # 直接用它的 SQL 当源会把原列也换成布尔值，所以按扫描序 JOIN
            # 回 self：数据列取 self 的原值，条件列取派生后的布尔值。
            my Set $known = self.names.Set;
            my Str $ord = '__duckula_ord';
            my Str $cc  = '__duckula_cond';
            $ord ~= '_' while $ord ∈ $known;
            $cc  ~= '_' while $cc ∈ $known || $cc eq $ord;
            $source =
                'SELECT __duckula_self.*, __duckula_cond.'
              ~ quote-ident($cond.name) ~ ' AS ' ~ quote-ident($cc)
              ~ ' FROM (SELECT *, row_number() OVER () AS ' ~ quote-ident($ord)
              ~ ' FROM (' ~ $!relation-sql ~ ') AS __src_self) AS __duckula_self'
              ~ ' LEFT JOIN (SELECT row_number() OVER () AS ' ~ quote-ident($ord)
              ~ ', ' ~ quote-ident($cond.name) ~ ' FROM (' ~ $cf.relation-sql
              ~ ') AS __src_cond) AS __duckula_cond USING (' ~ quote-ident($ord) ~ ')';
            $c = col($cc).render;
            $cols = Set.new;
        } else {
            ($c, $cols) = normalize-condition($cond, @args);
        }
        self!check-columns($cols, $mask ?? 'mask' !! 'where');

        my Hash $types = self.dtypes;
        my @exprs = self.names.map(-> $n {
            fill-expression($n, $c, $other, :$mask, type => $types{$n})
                ~ ' AS ' ~ quote-ident($n)
        });
        self.derived('SELECT ' ~ @exprs.join(', ')
                     ~ ' FROM (' ~ $source ~ ') AS __duckula_fill');
    }

    #| 条件为真的位置保留原值，其余替换为 `$other`（默认 NULL）。
    method where($cond, $other = Any, *@args --> Duckula::Frame) {
        self!fill-frame($cond, $other, @args, :!mask);
    }

    #| 条件为真的位置替换为 `$other`，其余保留原值。
    method mask($cond, $other = Any, *@args --> Duckula::Frame) {
        self!fill-frame($cond, $other, @args, :mask);
    }

    #| pandas 的 `query`：就是 SQL 片段过滤，`and/or/not` 都能用；
    #| 值走 `?` 绑定（`$df.query('amount > ?', 100)`）。
    method query(Str:D $expr, *@args --> Duckula::Frame) {
        self.filter($expr, |@args);
    }

    #| 把 Raku 闭包作用在指定列上，返回整张 Frame（该列被替换）。
    #| 闭包作用于每个非 NULL 元素；NULL 原样保留。
    method map(&fn, Str:D :$column! --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => "no column named '$column'")
            unless $column ∈ self.names.Set;
        my @vals = self.column($column).to-list(:typed)
                       .map(-> $v { $v.defined ?? &fn($v) !! $v }).List;
        self.derived(replace-column-sql(
            $!relation-sql, $column, @vals, self.names));
    }

    #| 函数式 apply。`:axis(0)` 逐列把闭包作用到每个元素（等价于对每列
    #| 调 `.map`）；`:axis(1)` 逐行把闭包作用到一行 Array，结果写成新列
    #| `__duckula_apply`（同名时自动加下划线）。
    #|
    #| 与 pandas 的区别：pandas 的 axis=0 是把**整列 Series** 交给闭包；
    #| 这里按元素调用，更好预测，也避免把计算搬出 DuckDB 之后还要重建
    #| Series。需要整列语义时直接写 `$df.column('x')` 再交给闭包。
    method apply(&fn, Int:D :$axis = 0 --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => 'apply axis must be 0 or 1')
            unless $axis == 0 || $axis == 1;

        if $axis == 0 {
            my $f = self;
            $f = $f.map(&fn, :column($_)) for self.names;
            return $f;
        }

        my @vals = self.rows.map(-> $row { &fn($row) }).List;
        my Str $col = '__duckula_apply';
        $col ~= '_' while $col ∈ self.names.Set;
        self.derived(add-column-sql(
            $!relation-sql, $col, @vals, self.names));
    }

    #| pandas 的 `DataFrame.applymap`：逐元素映射，等价于 apply(:axis(0))。
    method applymap(&fn --> Duckula::Frame) { self.apply(&fn, :axis(0)) }

    #| 时间重采样。`$df.resample('15min', :on<ts>).agg(col('v').sum.alias('s'))`。
    #| 先按规则把时间列换成桶起点，再走 group-by，所以聚合语义、列名
    #| 白名单和自动命名都与 group-by 一致；结果按时间升序。
    method resample(Str:D $rule, Str:D :$on! --> Duckula::Resample) {
        die Duckula::X::Frame.new(reason => "no column named '$on'")
            unless $on ∈ self.names.Set;
        Duckula::Resample.new(
            frame  => self,
            column => $on,
            bucket => resample-bucket-sql($rule, $on),
        );
    }

    #| pandas 风格的取列，但用的是 Raku 的 `{}` 而不是 `[]`：
    #|
    #|   $df{'amount'}          -> Series
    #|   $df<amount>            -> 同上
    #|   $df{'city', 'amount'}  -> 两个 Series 的 List（Raku 多值下标语义）
    #|   $df[0]                 -> 第 0 列的 Series（按位置）
    #|
    #| **为什么不是 `$df["amount"]`**：Raku 的 `[ ]` 把下标当位置索引，
    #| 传字符串会先被强转成 Int 而失败（实测 `Cannot convert string to number`）。
    #| 这不是 Duckula 的选择，是语言的 postcircumfix 语义。
    multi method AT-KEY(Str:D $name --> Duckula::Series) {
        self.column($name);
    }

    multi method AT-POS(Int:D $i --> Duckula::Series) {
        my List $names = self.names;
        die Duckula::X::Frame.new(
            reason => "column index $i out of range 0..{$names.elems - 1}"
        ) unless 0 <= $i < $names.elems;
        self.column($names[$i]);
    }

    method gist(--> Str) {
        self!materialize;

        my @cols = @!names;
        return '(empty frame)' unless @cols.elems;

        my @cells = @!rows.map(-> @r { @r.map({ $_.defined ?? $_.Str !! 'NULL' }) });
        my @width = @cols.map({ $_.chars });
        for @cells -> @r {
            for ^@cols.elems -> $i {
                my $w = (@r[$i] // '').chars;
                @width[$i] = $w if $w > @width[$i];
            }
        }

        my Str $out = '';
        $out ~= (@cols Z @width).map({ .[0].fmt("%-{.[1]}s") }).join(' | ') ~ "\n";
        $out ~= (@width.map({ '-' x $_ })).join('-+-') ~ "\n";
        for @cells -> @r {
            $out ~= (@r Z @width).map({ (.[0] // '').fmt("%-{.[1]}s") }).join(' | ') ~ "\n";
        }
        $out;
    }
}
