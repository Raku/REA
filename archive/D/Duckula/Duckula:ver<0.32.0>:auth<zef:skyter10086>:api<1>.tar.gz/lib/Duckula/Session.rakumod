use v6.d;
use DB::DuckDB;
use Duckula::SQL;
use Duckula::Guard;
use Duckula::Frame;
use Duckula::LazyFrame;
use Duckula::Plan;
use Duckula::Write;
use Duckula::ArrowRead;
use Duckula::IO;
use Duckula::ExcelRead;
use Duckula::SqlDb;
use Duckula::X::Frame;

#| 一次数据分析会话：一个 DuckDB 连接 + 小写入口 `$session.sql(...)`。
#|
#| 职责很小，只做四件事：
#|   1. 管连接（可选复用外部传入的，或自己开一个）；
#|   2. 把整条 SQL 送过 Duckula::Guard 三道闸，再交给 DuckDB；
#|   3. 为 `Frame.sql` 的 `self` 占位符分配临时视图名；
#|   4. 把结果包成 Duckula::Frame（SQL 为真相，数据惰性）。
#|
#| 不做：解析 SQL、优化查询、计算。那些都是 DuckDB 的活。
class Duckula::Session {
    has $!conn;
    has Bool $!owns-conn = False;
    has Bool $!sandboxed = False;
    has Bool $!strict = True;
    has Int $!view-seq = 0;
    has @!views;

    #| :$conn    复用已有连接（DB::DuckDB 实例）；不传则自己开一个
    #| :$sandbox 立刻切断外部文件/网络访问（见 §9.5.5）
    #| :$strict  False 表示默认放行写操作（等于每条 SQL 都 :unsafe）
    submethod BUILD(:$conn, Bool :$sandbox = False, Bool :$strict = True) {
        $!owns-conn = !$conn.defined;
        $!conn = $conn // DB::DuckDB.new;
        $!strict = $strict;
        if $sandbox {
            apply-sandbox($!conn);
            $!sandboxed = True;
        }
    }

    method conn(--> Mu) { $!conn }

    #| 让 DuckDB 的解析器看一眼这条 SQL 是什么。自查用，不执行、不校验。
    #|
    #|   $s.classify("SELECT 1");              # ('SELECT',)
    #|   $s.classify("SELECT 1; COPY ...");    # ('SELECT', 'COPY')
    #|
    #| 与 `check-sql` 的关系：那个是守门（不安全就 die），这个是照镜子
    #| （把结论给你看）。想知道「为什么被拒」时用它。
    method classify(Str:D $sql --> List) {
        $!conn.classify-sql($sql).map(*.type).List;
    }


    method sandboxed(--> Bool) { $!sandboxed }

    #| 严格模式（默认开）：只放行只读语句。`LazyFrame.sql` 要照着这里的开关
    #| 决定要不要让用户 `:unsafe` 才行。
    method strict(--> Bool) { $!strict }

    #| 把一段 SQL 绑成临时视图，返回视图名（登记进 `drop-views` 名单）。
    #|
    #| 给 `LazyFrame.sql` 用：惰性路径没法推迟 `CREATE VIEW`，只能在校验通过
    #| 后立刻建好视图，再把用户 SQL 包成计划节点。
    method bind-view(Str:D $sql --> Str) {
        my Str $view = self!view-name;
        $!conn.execute("CREATE OR REPLACE TEMP VIEW $view AS $sql");
        @!views.push: $view;
        $view;
    }

    #| 临时视图的单调命名，避免与用户表撞名。
    method !view-name(--> Str) { '__duckula_view_' ~ (++$!view-seq) }

    method !clean(Str:D $sql --> Str) {
        $sql.trim.subst(/ ';' $ /, '').trim;
    }

    #| 执行一条独立的 SQL（没有 `self` 上下文）。
    #|
    #|   duckula.sql("select * from read_csv_auto('o.csv')");
    #|   duckula.sql('select * from t where city = ?', $city);
    #|
    #| 值走参数绑定，不经过 SQL 文本；`?` 的个数必须与实参一致，否则当场 die。
    method sql(Str:D $sql, *@args, Bool :$unsafe = False --> Duckula::Frame) {
        my Str $text = self!clean($sql);
        check-sql($text, :params(@args.elems), :strict(!$unsafe && $!strict), :conn($!conn));

        my $res = $!conn.query($text, |@args);
        my Str $relation = @args.elems ?? render-bindings($text, @args) !! $text;

        Duckula::Frame.new(session => self, relation-sql => $relation, result => $res);
    }

    #| 读 CSV/TSV。列名与类型交给 DuckDB 自动推断（sniffing）。
    #|
    #| 路径作为**绑定参数**传入，不拼进 SQL 文本 —— 文件名里带单引号也安全
    #| （已实测 `tmp-o'rders.csv`）。
    method read-csv(Str:D $path --> Duckula::Frame) {
        self.sql('SELECT * FROM read_csv_auto(?)', $path);
    }

    #| 读 Parquet。
    method read-parquet(Str:D $path --> Duckula::Frame) {
        self.sql('SELECT * FROM read_parquet(?)', $path);
    }

    # ============================================================
    # SQL 数据库读写（v0.29.0，对标 pandas read_sql / to_sql）
    # ============================================================

    #| 执行一段 SQL 读成 Frame，和 `sql` 的区别是它明确服务于「外部库」：
    #| 给了 `:$db` 就先 `ATTACH` 成 `:$alias`，SQL 里用 `<alias>.<table>` 限定名。
    #| 不给 `:$db` 时等价于 `sql`（读当前连接能看见的表）。
    #|
    #|   $s.read-sql('SELECT * FROM ext.orders WHERE amount > ?', 5,
    #|               :db<warehouse.duckdb>, :alias<ext>);
    #|
    #| SQL 照旧过 Guard 的只读判定；路径走 sql-literal、别名走 quote-ident。
    method read-sql(
        Str:D $sql,
        *@args,
        Str :$db,
        Str :$alias = 'duckula_ext',
        Bool:D :$read-only = True,
        Bool :$unsafe = False,
        --> Duckula::Frame
    ) {
        Duckula::SqlDb::attach-db(self, $db, $alias, :$read-only) if $db.defined;
        self.sql($sql, |@args, :$unsafe);
    }

    #| 读外部库的一张表，省去自己写 `<alias>.<table>`。
    method read-sql-table(
        Str:D $table,
        Str :$db!,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Bool:D :$read-only = True,
        --> Duckula::Frame
    ) {
        Duckula::SqlDb::attach-db(self, $db, $alias, :$read-only);
        self.sql(
            Duckula::SqlDb::read-sql-table-sql($table, :$alias, :$schema)
        );
    }

    #| 惰性读外部库的一张表。ATTACH 是连接级副作用，建计划前先做掉。
    method scan-sql-table(
        Str:D $table,
        Str :$db!,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Bool:D :$read-only = True,
        --> Duckula::LazyFrame
    ) {
        Duckula::SqlDb::attach-db(self, $db, $alias, :$read-only);
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source(
                Duckula::SqlDb::read-sql-table-sql($table, :$alias, :$schema)
            ),
        );
    }

    #| 挂一个外部 DuckDB 库，返回可用的限定名前缀（已 quote 的别名）。
    method attach-db(
        Str:D $path,
        Str:D $alias = 'duckula_ext',
        Bool:D :$read-only = False,
        --> Str
    ) {
        Duckula::SqlDb::attach-db(self, $path, $alias, :$read-only);
    }

    #| 拆掉一个已挂的外部库。
    method detach-db(Str:D $alias --> Nil) {
        Duckula::SqlDb::detach-db(self, $alias);
    }

    #| 当前连接挂着哪些库。
    method list-dbs(--> List) { Duckula::SqlDb::list-dbs(self) }

    #| 惰性读 CSV：只建计划节点，一行都不读。`collect` 时才真正扫文件。
    method scan-csv(Str:D $path --> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source('SELECT * FROM read_csv_auto(?)', $path),
        );
    }

    #| 惰性读 Parquet。
    method scan-parquet(Str:D $path --> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source('SELECT * FROM read_parquet(?)', $path),
        );
    }

    #| 读 JSON / NDJSON（`.json` / `.ndjson` / `.jsonl`）。
    #|
    #| DuckDB 自己嗅探是数组还是逐行对象；需要时可以钉死：
    #|   $s.read-json('x.json', :format<array>);
    #|   $s.read-json('x.ndjson', :format<newline_delimited>, :ignore-errors);
    #|
    #| 路径走绑定参数；`format` / `records` 走白名单，都不接受 SQL 片段。
    method read-json(
        Str:D $path,
        Str :$format,
        Str :$records,
        Int :$maximum-depth,
        Bool :$ignore-errors,
        --> Duckula::Frame
    ) {
        self.sql(
            Duckula::IO::json-source-sql(
                :$format, :$records, :$maximum-depth, :$ignore-errors
            ),
            $path
        );
    }

    #| 惰性读 JSON：计划里的路径仍然是绑定参数，collect 时才扫文件。
    method scan-json(
        Str:D $path,
        Str :$format,
        Str :$records,
        Int :$maximum-depth,
        Bool :$ignore-errors,
        --> Duckula::LazyFrame
    ) {
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source(
                Duckula::IO::json-source-sql(
                    :$format, :$records, :$maximum-depth, :$ignore-errors
                ),
                $path
            ),
        );
    }

    #| 读 Excel（`.xlsx`）。
    #|
    #|   my $df = $s.read-excel('book.xlsx');
    #|   my $df = $s.read-excel('book.xlsx', :sheet<Sheet2>, :!header);
    #|
    #| 两条路：DuckDB 装了 `excel` 扩展就直接用 `read_xlsx`（纯 SQL、惰性列
    #| 读取）；否则用 `Duckula::ExcelRead` 解 xlsx 到临时表（与 read-arrow
    #| 一样的急切路径）。Windows 的 mingw 构建没有官方 excel 扩展，走的
    #| 就是后者。支持 sharedStrings / inlineStr / 数字 / 布尔 / 公式结果；
    #| 日期按 Excel 序号读出，样式与合并单元格不解析。
    method read-excel(
        Str:D $path,
        Str :$sheet,
        Bool:D :$header = True,
        Bool:D :$all-varchar = False,
        --> Duckula::Frame
    ) {
        die Duckula::X::Frame.new(
            reason => 'read-excel needs file-system access, but this session is sandboxed'
        ) if $!sandboxed;

        Duckula::IO::excel-available(self)
            ?? self.sql(
                   Duckula::IO::excel-source-sql(:$sheet, :$header, :$all-varchar),
                   $path
               )
            !! Duckula::ExcelRead::read-excel(
                   self, $path, :$sheet, :$header, :$all-varchar
               );
    }

    #| 惰性读 Excel。和 `read-arrow` 一样需要先把内容解到临时表，所以
    #| 建计划之前会做一次急切的读取；后续算子仍是惰性的。
    method scan-excel(
        Str:D $path,
        Str :$sheet,
        Bool:D :$header = True,
        Bool:D :$all-varchar = False,
        --> Duckula::LazyFrame
    ) {
        my $frame = self.read-excel($path, :$sheet, :$header, :$all-varchar);
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source($frame.relation-sql),
        );
    }

    #| 只看 xlsx 骨架：所有 sheet 名 + 行列数，不建临时表。
    method describe-excel(Str:D $path --> Hash) {
        die Duckula::X::Frame.new(
            reason => 'describe-excel needs file-system access, but this session is sandboxed'
        ) if $!sandboxed;
        Duckula::ExcelRead::describe-xlsx($path);
    }

    #| 读 Arrow IPC 文件（`.arrow` / `.arrows`）。
    #|
    #|   my $df = $s.read-arrow('out.arrow');
    #|   my $df = $s.read-arrow('out.arrows');            # stream 格式
    #|   my $df = $s.read-arrow('out.arrow', :name<raw>); # 指定临时表名
    #|
    #| 与上面两个读入口不同，这条**不是 SQL 谓词**：DuckDB 没有内置的
    #| `read_arrow`（Arrow 读取要靠没有 mingw 构建的 `arrow` 扩展），所以
    #| 字节由 `Duckula::ArrowRead` 自己解，解出的行再灌进一张临时表。因此
    #| 它是急切的 —— Arrow 必须现在就解码，表也就必须现在就建。连接一关，
    #| 表跟着消失，Frame 不能跨连接使用。
    method read-arrow(Str:D $path, Str :$name --> Duckula::Frame) {
        $name.defined
            ?? Duckula::ArrowRead::read-arrow(self, $path, :$name)
            !! Duckula::ArrowRead::read-arrow(self, $path);
    }

    #| 解码缓存的命中/未命中/条目数。
    #|
    #| 同一文件重复 `read-arrow` 时，字节解码只做一次 —— 这里能看到效果：
    #| 第一次 misses+1，之后同一份文件（指纹不变）hits 递增。
    #| 缓存是**进程级**的（解码结果是纯值，与连接无关），跨 session 也共享。
    method arrow-cache-stats(--> Hash) {
        Duckula::ArrowRead::arrow-cache-stats();
    }

    #| 清空解码缓存并重置计数。想强制重读文件内容、或释放缓存内存时用。
    method clear-arrow-cache(--> Nil) {
        Duckula::ArrowRead::clear-arrow-cache();
    }

    #| 只看一个 IPC 文件的骨架，不读数据。
    #|
    #| 返回 `%(format, batches, rows, fields)`；`fields` 是每个字段的
    #| `name:format` 摘要，`dict-id` 非空说明那列是字典编码的。
    #|
    #|   $s.describe-arrow('out.arrow');
    #|   # {format => file, batches => 2, rows => 4096, fields => [...]}
    method describe-arrow(Str:D $path --> Hash) {
        Duckula::ArrowRead::describe-ipc($path);
    }

    #| 执行一条**会改数据**的语句，返回受影响行数。
    #|
    #|   $s.execute('CREATE TABLE t (i BIGINT, s VARCHAR)');
    #|   $s.execute('DELETE FROM t WHERE i < ?', 3);
    #|
    #| 与 `sql` 的区别只有一条：不做只读校验（`sql` 在严格模式下会拒绝
    #| INSERT/UPDATE/CREATE）。单语句与占位符对齐这两道照旧检查 —— 写操作
    #| 一样不该被拼接注入。
    method execute(Str:D $sql, *@args --> Int) {
        my Str $text = self!clean($sql);
        check-sql($text, :params(@args.elems), :strict(False));
        $!conn.execute($text, |@args).Int;
    }

    #| 把一批 Raku 行写进已有表，走 Appender（单事务，失败整批回滚）。
    #|
    #|   $s.insert('t', ((1, 'a'), (2, 'b')));
    #|
    #| 每行是与表列**按位置对齐**的序列；`Any` 写 NULL。表必须已经存在
    #| （用 `execute` 建，或者把结果集用 `Frame.to-table` 变成表）。
    method insert(Str:D $table, @rows, Str :$schema --> Int) {
        Duckula::Write::append-rows(self, $table, @rows, :$schema);
    }

    #| 从一个结果集建表，返回行数。
    #|
    #| `$source` 可以是 `Frame`、`LazyFrame` 或一段 SQL 字符串。惰性源会先
    #| `collect`，因为 `CREATE TABLE ... AS` 要一条没有占位符的语句。
    #| 与 `$df.to-table(...)` 等价，只是入口在会话上。
    method create-table(
        Str:D $name,
        $source,
        Bool:D :$replace = True,
        Bool:D :$temporary = False,
        --> Int
    ) {
        my Str $sql = do {
            if $source ~~ Str:D { $source }
            elsif $source.can('collect') { $source.collect.relation-sql }
            elsif $source.can('relation-sql') { $source.relation-sql }
            else {
                die Duckula::X::Frame.new(
                    reason => 'create-table expects a Frame, a LazyFrame '
                            ~ 'or a SQL string, got ' ~ $source.^name
                );
            }
        };
        Duckula::Write::create-table(self, $sql, $name, :$replace, :$temporary);
    }

    #| 把一个结果集写进 SQL 库的表（对标 pandas `DataFrame.to_sql`）。
    #|
    #|   $s.to-sql('clean_orders', $frame);                 # 当前库
    #|   $s.to-sql('orders', $frame, :db<wh.duckdb>, :alias<ext>,
    #|             :if-exists<append>);
    #|
    #| `:$db` 给了就先 ATTACH 外部库；不给就写当前连接。外部库写入要求非
    #| 沙箱会话。`:if-exists` 三态：fail / replace（默认）/ append。
    method to-sql(
        Str:D $table,
        $source,
        Str :$db,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Str:D :$if-exists = 'replace',
        --> Int
    ) {
        my Str $sql = do {
            if $source ~~ Str:D { $source }
            elsif $source.can('collect') { $source.collect.relation-sql }
            elsif $source.can('relation-sql') { $source.relation-sql }
            else {
                die Duckula::X::Frame.new(
                    reason => 'to-sql expects a Frame, a LazyFrame or a SQL string, '
                            ~ 'got ' ~ $source.^name
                );
            }
        };

        if $db.defined {
            die Duckula::X::Frame.new(
                reason => 'to-sql to an external database needs file-system access, '
                        ~ 'but this session is sandboxed'
            ) if $!sandboxed;
            Duckula::SqlDb::attach-db(self, $db, $alias);
        }

        Duckula::SqlDb::write-sql-table(
            self, $sql, $table, :$if-exists,
            alias => ($db.defined ?? $alias !! Str),
            :$schema
        );
    }

    #| 在一个 Frame 的上下文里执行 SQL，`self` 指代该 Frame。
    #|
    #| `self` 绑成**临时视图**而不是 FROM 子查询，两个原因（§9.3）：
    #|   - 子查询必须带别名，`self.col` 会变成 `(select ...) AS __v.col`，语法错误；
    #|   - `self` 出现两次（自连接）时子查询会被重复计算。
    method sql-on-frame(
        Duckula::Frame $frame,
        Str:D $sql,
        *@args,
        Bool :$unsafe = False,
        --> Duckula::Frame
    ) {
        my Str $text = self!clean($sql);
        my Str $view = self!view-name;

        # 校验用的是「把 self 换成视图名」之后的 SQL，也就是真正要执行的
        # 那一条。所以视图得先建出来——否则 DuckDB 的解析器会说
        # `Table with name __duckula_view_1 does not exist`，校验永远过不了。
        # 建临时视图没有副作用（只是名字绑定），校验失败时再拆掉即可。
        $!conn.execute("CREATE OR REPLACE TEMP VIEW $view AS {$frame.relation-sql}");
        @!views.push: $view;

        my Str $bound = replace-bare-ident($text, 'self', $view);

        {
            check-sql($bound, :params(@args.elems), :strict(!$unsafe && $!strict),
                      :conn($!conn));
            CATCH {
                default {
                    $!conn.execute("DROP VIEW IF EXISTS $view");
                    @!views.pop;
                    .rethrow;
                }
            }
        }

        my $res = $!conn.query($bound, |@args);
        my Str $relation = @args.elems ?? render-bindings($bound, @args) !! $bound;

        Duckula::Frame.new(session => self, relation-sql => $relation, result => $res);
    }

    #| 丢掉本会话建过的全部临时视图。临时视图本是连接级的，连接一关就消失；
    #| 这个方法给长期存活的会话用，避免一连串 `Frame.sql` 攒出上百个视图。
    method drop-views(--> Nil) {
        for @!views -> $v {
            $!conn.execute("DROP VIEW IF EXISTS $v");
        }
        @!views = ();
    }

    #| 关闭会话。只关自己开的连接；外部传入的连接仍归调用方所有。
    method close(--> Nil) {
        self.drop-views;
        $!conn.close if $!owns-conn;
    }
}
