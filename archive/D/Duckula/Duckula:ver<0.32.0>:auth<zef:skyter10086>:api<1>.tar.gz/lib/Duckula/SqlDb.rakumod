use v6.d;
use Duckula::SQL;
use Duckula::X::Frame;

#| SQL 数据库读写（v0.29.0）：对标 pandas 的 `read_sql` / `to_sql`。
#|
#| 与 `read-parquet` 这类「读文件」不同，这里读的是**另一张 DuckDB 目录里的表**。
#| DuckDB 原生支持 `ATTACH '<path>' AS <alias>`，不需要任何扩展；sqlite/postgres
#| 那些要装扩展的在当前 mingw 构建里装不上（和 excel 一样），所以明确只支持
#| DuckDB 自己的库文件。SQL 注入模型延续 §9：
#|   - 路径走 `sql-literal`（ATTACH 不接受绑定参数，和 COPY 一样）；
#|   - 别名、表名、schema 走 `quote-ident`；
#|   - `if_exists` / `read-only` 走白名单与 Bool 类型；
#|   - 用户 SQL 本身照旧过 Guard（`check-sql` 的只读判定）。
#|
#| 路径里带单引号、别名里带引号、表名是注入形状的字符串都只会变成合法
#| 标识符或字面量，不会变成第二条语句。
unit module Duckula::SqlDb;

#| 外部库别名：`ATTACH` 的 alias 是 SQL 标识符，用 quote-ident 转义。
#| 不限制字符集，但拒绝空串（DuckDB 对空别名会给出晦涩错误）。
my sub check-alias(Str:D $alias --> Nil) {
    die Duckula::X::Frame.new(reason => 'database alias must not be empty')
        unless $alias.chars;
}

#| 沙箱会话不能 ATTACH 外部文件（等于打开文件）。写到当前库的表另算，
#| 因为数据不出库——那边由 `to-table` 负责，这里只管外部库。
my sub need-db-access($session, Str:D $what --> Nil) {
    die Duckula::X::Frame.new(
        reason => "$what needs file-system access, but this session is sandboxed; "
                ~ 'create it with Duckula::Session.new(:!sandbox) to allow it'
    ) if $session.sandboxed;
}

#| 挂上一个外部 DuckDB 库，返回 alias 的 SQL 文本（已 quote）。
#|
#| 用 `ATTACH IF NOT EXISTS`：同一个库被多次 read-sql 时幂等，不重复挂。
#| 别名相同但路径不同时 DuckDB 会报错，正好提醒调用方换别名。
#| `:read-only` 让 ATTACH 带 `READ_ONLY`，写操作会在 DuckDB 层被拒。
our sub attach-db(
    $session,
    Str:D $path,
    Str:D $alias,
    Bool:D :$read-only = False,
    --> Str
) is export {
    need-db-access($session, 'ATTACH');
    check-alias($alias);

    my Str $ident = quote-ident($alias);

    # 已经挂过就复用：DuckDB 不允许同一别名换模式重挂（read-write ↔ read-only），
    # `ATTACH IF NOT EXISTS` 照样会检查模式并报错。先查 duckdb_databases()，
    # 路径一致就直接返回；路径不同说明调用方拿错库了，明确报错而不是悄悄复用。
    # path 是 nullable 列，rakupp 上会踩 bitmap 解码缺陷；string_agg 成单列
    # 纯 VARCHAR（没有行时是 NULL，Raku 侧判 defined）。
    my $got = $session.conn.query(
        "SELECT string_agg(coalesce(path, ''), '') FROM duckdb_databases() "
        ~ 'WHERE database_name = ?', $alias
    ).value;
    if $got.defined {
        my Str $existing = $got.Str;
        my Str $wanted   = $path.IO.absolute.Str;
        my Str $abs      = $existing.chars ?? $existing.IO.absolute.Str !! '';
        unless $abs eq $wanted {
            die Duckula::X::Frame.new(
                reason => "database alias '$alias' is already attached to "
                        ~ "$existing; detach it first or use another alias"
            );
        }
        return $ident;
    }

    my Str $opts = $read-only ?? ' (READ_ONLY)' !! '';
    $session.conn.execute(
        'ATTACH ' ~ sql-literal($path) ~ ' AS ' ~ $ident ~ $opts
    );
    $ident;
}

#| 把一个已挂库的 alias 拆掉。别名用 quote-ident 处理。
our sub detach-db($session, Str:D $alias --> Nil) is export {
    need-db-access($session, 'DETACH');
    check-alias($alias);
    $session.conn.execute('DETACH IF EXISTS ' ~ quote-ident($alias));
}

#| 列出当前连接挂着的库：`%(name, path, type, read-only)` 的列表。
our sub list-dbs($session --> List) is export {
    # duckdb_databases() 的 path 是 nullable、readonly 是 BOOLEAN，两类列在
    # rakupp 上都会踩 DB::DuckDB 的 nullable-bitmap 解码缺陷。用 string_agg
    # 在 SQL 侧拼成单个非 nullable 字符串再 Raku 侧 split，一列纯 VARCHAR，
    # 两端解码都稳。字段里不含分隔符（'|' 与换行），所以 split 不会拆错。
    my $res = $session.conn.query(q[
        SELECT string_agg(
            database_name || '|' || coalesce(path, '') || '|'
            || coalesce(type, '') || '|'
            || CASE WHEN readonly THEN '1' ELSE '0' END,
            chr(10)
        ) AS s
        FROM (SELECT * FROM duckdb_databases() ORDER BY database_name)
    ]);
    my $v = $res.value;
    return [] unless $v.defined;
    $v.Str.split("\n").map(-> $line {
        my @f = $line.split('|', 4);
        %(name => @f[0], path => @f[1], type => @f[2],
          read-only => (@f[3] // '0') eq '1')
    }).List;
}

#| 表的完整限定名。给了 alias 就用 `<alias>.<schema>.<table>`，否则用
#| `<schema>.<table>` / `<table>`。三段都过 quote-ident。
our sub qualified-table(
    Str:D $table,
    Str :$alias,
    Str :$schema,
    --> Str
) is export {
    my Str $name = quote-ident($table);
    $name = quote-ident($schema) ~ '.' ~ $name if $schema.defined && $schema.chars;
    $name = quote-ident($alias) ~ '.' ~ $name if $alias.defined && $alias.chars;
    $name;
}

#| 读一张外部库的表的 SQL。由调用方负责 ATTACH（read-sql-table 会做）。
our sub read-sql-table-sql(Str:D $table, Str :$alias, Str :$schema --> Str) is export {
    'SELECT * FROM ' ~ qualified-table($table, :$alias, :$schema);
}

#| 判断一张表是否存在。用 information_schema 而不是 duckdb_tables()，
#| 因为前者能按 catalog/schema 精确限定，且表名走绑定参数（不是拼文本）。
our sub table-exists(
    $session,
    Str:D $table,
    Str :$alias,
    Str :$schema,
    --> Bool
) is export {
    my Str $cat = $alias.defined && $alias.chars ?? $alias !! 'memory';
    my Str $sch = $schema.defined && $schema.chars ?? $schema !! 'main';
    my $r = $session.conn.query(q[
        SELECT count(*) FROM information_schema.tables
        WHERE table_catalog = ? AND table_schema = ? AND table_name = ?
    ], $cat, $sch, $table);
    so $r.value.Int;
}

#| 把一段查询结果写进表，对齐 pandas 的 `if_exists` 三态：
#|   fail    — 表已存在则报错（CREATE TABLE）
#|   replace — 存在就重建（CREATE OR REPLACE TABLE，默认，和 pandas 不同：
#|             pandas 默认 fail，这里沿用 to-table 的 replace 默认值）
#|   append  — 存在就 INSERT，不存在则报错
#|
#| 返回写进去的行数。表在外部库时 alias 必须由调用方先 ATTACH 好。
our sub write-sql-table(
    $session,
    Str:D $sql,
    Str:D $table,
    Str:D :$if-exists = 'replace',
    Str :$alias,
    Str :$schema,
    --> Int
) is export {
    my Str $mode = $if-exists.lc;
    die Duckula::X::Frame.new(
        reason => "unknown if_exists '$if-exists'; use 'fail', 'replace' or 'append'"
    ) unless $mode eq 'fail' | 'replace' | 'append';

    my Str $target = qualified-table($table, :$alias, :$schema);
    my Bool $exists = table-exists($session, $table, :$alias, :$schema);

    if $mode eq 'append' {
        die Duckula::X::Frame.new(
            reason => "cannot append: table $target does not exist; "
                    ~ "use if_exists => 'replace' to create it"
        ) unless $exists;
        # INSERT 的 rows-affected 就是本次写入行数；返回表总行数会把
        # "这次写了多少" 和 "表里一共多少" 混为一谈。
        return $session.conn.execute("INSERT INTO $target $sql").Int;
    } else {
        if $mode eq 'fail' && $exists {
            die Duckula::X::Frame.new(
                reason => "table $target already exists; use if_exists => 'replace' "
                        ~ "or 'append'"
            );
        }
        my Str $verb = $mode eq 'replace'
            ?? 'CREATE OR REPLACE TABLE'
            !! 'CREATE TABLE';
        $session.conn.execute("$verb $target AS $sql");
    }

    my $res = $session.conn.query('SELECT count(*) FROM ' ~ $target);
    $res.value.Int;
}
