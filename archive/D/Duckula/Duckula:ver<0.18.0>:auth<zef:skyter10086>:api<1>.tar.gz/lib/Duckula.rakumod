use v6.d;
use Duckula::Session;

#| Duckula -- pandas / Polars 风格的 DataFrame API，跑在 DuckDB 上。
#|
#| 命名：Duck + Dracula 的混成词，取自《Count Duckula》（怪鸭历险记）。
#|      一是指向 DuckDB，二是隐喻"同时兼容 pandas 与 Polars 两套 API 的缝合体"。
#|
#| 设计边界（详见 ARCHITECTURE.md）：
#|   - 不写 DuckDB FFI          -> 复用 DB::DuckDB::Native
#|   - 不写列式内存模型         -> 复用 DB::DuckDB::ColumnView
#|   - 不写计算引擎             -> 翻译成 SQL，交给 DuckDB 执行
#|
#| 三种入口（§9.2）：
#|   duckula.sql("select ...")         纯 SQL
#|   $frame.sql("... from self ...")   Frame 上跑，self 指当前 Frame
#|   $frame.filter(...)                pandas / Polars 风格 API
#|   $frame.group-by(...).agg(...)     分组聚合（v0.6.0）
#|   $frame.join($other, on => ...)    连接（v0.7.0）
#|   $frame.concat($other)             纵向拼接（v0.16.0，另有 unique / rename /
#|                                     drop / drop-nulls / fill-nulls / cast）
#|   $frame.pivot(...) / .unpivot(...) 长宽互转（v0.17.0，另有 explode / sample /
#|                                     describe）
#|   $s.read-arrow(...)               Arrow 文件导入（v0.18.0 起带解码缓存）
unit module Duckula;

our $VERSION = '0.18.0';

my Duckula::Session $default;

#| 默认会话，首次调用时创建（一个进程一个连接）。
#| 需要隔离或多连接时，直接 `Duckula::Session.new`。
sub duckula(--> Duckula::Session) is export {
    $default //= Duckula::Session.new;
}
