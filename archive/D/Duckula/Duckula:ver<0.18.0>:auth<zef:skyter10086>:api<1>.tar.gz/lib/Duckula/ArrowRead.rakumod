use v6.d;
use NativeCall;
use Duckula::ArrowIPC;
use Duckula::Frame;
use Duckula::SQL;
use Duckula::X::Frame;

#| Arrow IPC 的**读**侧：把别人写出的 `.arrow` / `.arrows` 变成一张 Frame。
#|
#| 写侧（`Duckula::ArrowIPC`）是自己拼 FlatBuffers 字节；读侧反过来解字节。
#| 两者共用一套词汇表：FlatBuffers 的 `Type` union 先被翻译成 Arrow 的
#| format 字符串（`l` / `u` / `tsu:` …），再交给 `parse-format` 归一成
#| `%(kind => 'fixed'|'utf8'|'list'|…)`。这样解码分支与写出分支一一对称，
#| 遇到没见过的类型能立刻指出是哪一种。
#|
#| # 为什么必须把数据搬进 DuckDB
#|
#| DuckDB 没有 `read_arrow()` —— 读 Arrow 靠的是 `arrow` 扩展（无 mingw 构建）
#| 或者 C data interface 的 `duckdb_arrow_array_scan`（已废弃，且要求调用方
#| 亲手维护 ArrowSchema/ArrowArray 的 C 结构）。所以这里选一条最笨但最可控的
#| 路：解码成 Raku 值 → `CREATE TEMP TABLE` → Appender 批量灌入。
#|
#| 代价是数据过一次解释器（几十万行/秒量级），换来的是：没有裸指针、没有
#| 废弃 API、每个不支持的类型都能报出**列名 + Arrow 类型**，而不是一句
#| 「scan failed」。
#|
#| # 支持范围
#|
#| 标量全部支持（含 Decimal / 各种日期时间单位 / 字典编码的 ENUM）；
#| `List`、`Struct`、`Map` 任意互相嵌套（`Map` 就是 `List<Struct>` 的特例，
#| entries 直接复用 Struct 的解码分支）。`FixedSizeList` / `Union` /
#| `RunEndEncoded` 明确报错 —— 宁可说清楚是哪一列不支持，也不要静默读成
#| 一片 NULL。
unit module Duckula::ArrowRead;

# ============================================================
# 字节视图：Buf + 基址偏移，零拷贝切片
# ============================================================

#| 一段字节的只读窗口。`base` 是相对底层 Buf 的起点，切片不复制数据。
#|
#| 底层指针只在 `buf` 存活期间有效，所以这个类**必须持有 Buf** —— 拿
#| `$!buf` 的公开属性就是为了不让它被回收（MoarVM 的 Buf 存储不移动，
#| 但只要 Buf 被回收，指针就成了野指针）。
#|
#| `len` 与 `buf.elems - base` 不是一回事：Arrow 里长度为 0 的 buffer
#| （比如「全非空」的 validity bitmap）是合法的，它不能靠「剩余多少字节」
#| 推断。
class Bytes {
    has Buf $.buf;
    has Int $.base = 0;
    has Int $.len;

    has CArray[uint8] $!ca;
    has Pointer[uint8] $!ptr;

    submethod TWEAK() {
        $!len = $!buf.elems - $!base unless $!len.defined;
        $!ptr = nativecast(Pointer[uint8], $!buf);
        $!ca = nativecast(CArray[uint8], $!ptr);
    }

    #| 窗口内第 `p` 字节的绝对指针，给定宽类型（float / double）用。
    method ptr-at(Int $p --> Pointer) { $!ptr.add($!base + $p) }

    method elems(--> Int) { $!len }

    #| 相对本窗口的切片，不拷贝。
    method slice(Int $off, Int $len --> Bytes) {
        die "arrow-read: slice out of range ($off + $len > {self.elems})"
            if $off < 0 || $len < 0 || $off + $len > self.elems;
        Bytes.new(buf => $!buf, base => $!base + $off, len => $len);
    }

    method u8(Int $p --> Int)  { $!ca[$!base + $p] }
    method i8(Int $p --> Int)  { my Int $v = self.u8($p); $v > 127 ?? $v - 256 !! $v }
    method u16(Int $p --> Int) { self.u8($p) +| (self.u8($p + 1) +< 8) }
    method i16(Int $p --> Int) { my Int $v = self.u16($p); $v > 32767 ?? $v - 65536 !! $v }
    method u32(Int $p --> Int) {
        self.u8($p) +| (self.u8($p + 1) +< 8) +| (self.u8($p + 2) +< 16)
            +| (self.u8($p + 3) +< 24)
    }
    method i32(Int $p --> Int) {
        my Int $v = self.u32($p);
        $v > 2147483647 ?? $v - 4294967296 !! $v
    }
    method i64(Int $p --> Int) {
        my $ptr = nativecast(Pointer[uint8], $!buf).add($!base + $p);
        nativecast(CArray[int64], $ptr)[0]
    }
    method u64(Int $p --> Int) {
        my Int $v = self.i64($p);
        $v < 0 ?? $v + 18446744073709551616 !! $v
    }

    #| 读一个 `[uoffset]`：先取相对偏移，再加到自己的位置上。
    method deref(Int $p --> Int) { $p + self.u32($p) }

    method bytes(Int $off, Int $len --> Buf) {
        my Buf $b = Buf.new;
        for ^$len -> int $i { $b.append(self.u8($off + $i)) }
        $b
    }

    method str(Int $off, Int $len --> Str) { self.bytes($off, $len).decode('utf-8') }

    #| 别让 gist 把整份文件打出来。
    method gist(--> Str) { "Bytes({$!len}B @ {$!base})" }
}

# ============================================================
# FlatBuffers：table / vtable
# ============================================================

#| 一张 FlatBuffers table。
#|
#| table 的第一个 int32 是 **soffset**（有符号）：`vtable = table_pos - soffset`。
#| vtable 的前 4 字节是「vtable 总长」「字段区长度」，之后每个字段 2 字节的
#| 偏移（相对 table 起点），0 表示该字段缺省 —— 缺省值不写进缓冲区，读的
#| 时候必须自己补默认值，这是 FlatBuffers 最容易读错的地方。
class Tbl {
    has Bytes $.b;
    has Int $.pos;

    has Int $!vt;
    has Int $!vtsize;

    submethod TWEAK() {
        $!vt = $!pos - $!b.i32($!pos);
        $!vtsize = $!b.u16($!vt);
    }

    #| 字段的绝对偏移；0 表示缺省。
    method !field(Int $id --> Int) {
        my Int $slot = $!vt + 4 + 2 * $id;
        return 0 if $slot + 2 > $!vt + $!vtsize;
        my Int $off = $!b.u16($slot);
        $off == 0 ?? 0 !! $!pos + $off;
    }

    method has-field(Int $id --> Bool) { self!field($id) != 0 }

    method u8(Int $id, Int $default = 0 --> Int)  { my $p = self!field($id); $p ?? $!b.u8($p)  !! $default }
    method i8(Int $id, Int $default = 0 --> Int)  { my $p = self!field($id); $p ?? $!b.i8($p)  !! $default }
    method i16(Int $id, Int $default = 0 --> Int) { my $p = self!field($id); $p ?? $!b.i16($p) !! $default }
    method i32(Int $id, Int $default = 0 --> Int) { my $p = self!field($id); $p ?? $!b.i32($p) !! $default }
    method i64(Int $id, Int $default = 0 --> Int) { my $p = self!field($id); $p ?? $!b.i64($p) !! $default }
    method bool(Int $id, Bool $default = False --> Bool) {
        my $p = self!field($id);
        $p ?? ($!b.u8($p) != 0) !! $default
    }

    #| 间接字段（string / vector / 子 table）的绝对起始位置；缺省返回 0。
    method ref(Int $id --> Int) {
        my Int $p = self!field($id);
        $p == 0 ?? 0 !! $!b.deref($p)
    }

    method str(Int $id, Str $default = '' --> Str) {
        my Int $p = self.ref($id);
        return $default if $p == 0;
        $!b.str($p + 4, $!b.u32($p));
    }

    method vec-len(Int $id --> Int) {
        my Int $p = self.ref($id);
        $p == 0 ?? 0 !! $!b.u32($p)
    }

    #| vector 里第 i 个 table。
    method vec-tbl(Int $id, Int $i --> Tbl) {
        my Int $p = self.ref($id);
        my Int $elem = $p + 4 + 4 * $i;
        Tbl.new(b => $!b, pos => $!b.deref($elem));
    }

    #| struct vector（FieldNode / Buffer / Block）：元素内联，无 uoffset。
    method vec-struct-at(Int $id, Int $i, Int $size --> Int) {
        my Int $p = self.ref($id);
        $p + 4 + $size * $i;
    }

    method gist(--> Str) { 'Tbl@' ~ $!pos }
}

# ============================================================
# Schema
# ============================================================

#| 一个 Arrow 字段：名字、可空、类型，以及（可能的）字典编码。
class AField {
    has Str $.name = '';
    has Bool $.nullable = True;
    has Int $.type-id = 0;          # Type union 的判别式
    has $.type;                     # Type table，可能为 Nil
    has AField @.children;
    has $.dict-id;                  # DictionaryEncoding.id，无则 Nil
    has $.dict-index-type;          # 字典索引的 Int table
    has $.dict-ordered = False;
    has Str $.format = '';          # 归一后的 Arrow format 字符串

    method gist(--> Str) {
        "{$.name}:{$.format}{$.nullable ?? '' !! '!'}"
            ~ (@!children.elems ?? "({@!children».gist.join(', ')})" !! '');
    }
}

#| Type union 的 tag → Arrow format 字符串。
#|
#| tag 编号来自 Arrow 的 `Schema.fbs`；写侧 `parse-format` 走的是反方向。
sub type-format(Int $tag, $t --> Str) {
    given $tag {
        when 1  { 'n' }                                          # Null
        when 2  {                                                # Int
            my Int $bw  = $t.i32(0, 32);
            my Bool $sg = $t.bool(1, False);
            my Str $c = %(8 => 'c', 16 => 's', 32 => 'i', 64 => 'l'){$bw}
                // die "arrow-read: unsupported Int bitWidth $bw";
            $sg ?? $c !! $c.uc;
        }
        when 3  {                                                # FloatingPoint
            my Int $p = $t.i16(0, 0);                            # 0=HALF 1=SINGLE 2=DOUBLE
            %(0 => 'e', 1 => 'f', 2 => 'g'){$p}
                // die "arrow-read: unsupported float precision $p";
        }
        when 4  { 'z' }                                          # Binary
        when 5  { 'u' }                                          # Utf8
        when 6  { 'b' }                                          # Bool
        when 7  {                                                # Decimal
            my Int $prec = $t.i32(0, 0);
            my Int $scale = $t.i32(1, 0);
            my Int $bw = $t.i32(2, 128);
            "d:$prec,$scale,$bw";
        }
        when 8  { $t.i16(0, 1) == 0 ?? 'tdD' !! 'tdm' }           # Date: DAY / MILLISECOND
        when 9  {                                                # Time
            my Str $u = %(0 => 's', 1 => 'm', 2 => 'u', 3 => 'n'){$t.i16(0, 0)};
            # 位宽由 unit 决定（s/m → 32 位，u/n → 64 位），与写出侧一致
            "tt$u";
        }
        when 10 {                                                # Timestamp
            my Str $u = %(0 => 's', 1 => 'm', 2 => 'u', 3 => 'n'){$t.i16(0, 0)};
            "ts$u:" ~ $t.str(1, '');
        }
        when 11 {                                                # Interval
            %(0 => 'tiM', 1 => 'tiD', 2 => 'tin'){$t.i16(0, 0)};
        }
        when 12 { '+l' }                                         # List
        when 13 { '+s' }                                         # Struct
        when 15 { 'w:' ~ $t.i32(0, 0) }                          # FixedSizeBinary
        when 17 { '+m' }                                         # Map
        when 18 {                                                # Duration
            'tD' ~ %(0 => 's', 1 => 'm', 2 => 'u', 3 => 'n'){$t.i16(0, 0)};
        }
        when 19 { 'Z' }                                          # LargeBinary
        when 20 { 'U' }                                          # LargeUtf8
        when 21 { '+L' }                                         # LargeList
        default {
            die "arrow-read: unsupported Arrow type tag $tag";
        }
    }
}

#| Type union 里还没实现的 tag 叫什么。报错要能指出「哪一种」，
#| 光给个数字没法判断是自己写错了还是版本不支持。
sub tag-name(Int $tag --> Str) {
    %(14 => 'Union', 16 => 'FixedSizeList', 22 => 'LargeListView',
      23 => 'ListView', 24 => 'RunEndEncoded'){$tag} // "type tag $tag";
}

#| `type-format` 的包装：失败时把列名补进去。
#|
#| 类型不支持的判定在 schema 解析阶段就发生了，那时候只有 tag 数字；
#| 但用户要看的是「哪一列」—— 所以在这里接住再抛一次。
sub field-format(Str $name, Int $tag, $type --> Str) {
    return type-format($tag, $type);
    CATCH {
        default {
            die "arrow-read: column '$name' is an Arrow {tag-name($tag)}, "
              ~ 'which this version does not read';
        }
    }
}

sub parse-field(Tbl $t --> AField) {
    my Int $tag = $t.u8(2);
    my Int $type-pos = $t.ref(3);
    my $type = $type-pos ?? Tbl.new(b => $t.b, pos => $type-pos) !! Nil;

    my Int $dict-pos = $t.ref(4);
    my $dict = $dict-pos ?? Tbl.new(b => $t.b, pos => $dict-pos) !! Nil;
    my $index-type;
    if $dict.defined {
        my Int $itp = $dict.ref(1);
        $index-type = $itp ?? Tbl.new(b => $dict.b, pos => $itp) !! Nil;
    }

    my Int $n = $t.vec-len(5);
    my @kids;
    for ^$n -> int $i { @kids.push: parse-field($t.vec-tbl(5, $i)) }

    my Str $name = $t.str(0, '');

    AField.new(
        name    => $name,
        nullable => $t.bool(1, False),
        type-id => $tag,
        type    => $type,
        children => @kids.List,
        dict-id => $dict.defined ?? $dict.i64(0) !! Nil,
        dict-index-type => $index-type,
        dict-ordered => $dict.defined ?? $dict.bool(2, False) !! False,
        format  => field-format($name, $tag, $type),
    );
}

sub parse-schema(Tbl $t --> List) {
    # endianness: 0 = little, 1 = big。整条链路都是小端，遇到大端直接拒绝。
    die 'arrow-read: big-endian Arrow data is not supported'
        if $t.i16(0, 0) != 0;
    my Int $n = $t.vec-len(1);
    (^$n).map({ parse-field($t.vec-tbl(1, $_)) }).List;
}

# ============================================================
# Message 拆包
# ============================================================

my constant MSG-SCHEMA       = 1;
my constant MSG-DICT-BATCH   = 2;
my constant MSG-RECORD-BATCH = 3;

#| 读一条 encapsulated message 的 metadata，返回
#| `%(kind, header, bodyLen, body, next)`；`kind` 为 0 表示流结束。
#|
#| 布局：`ffffffff` + int32 长度 + metadata。长度 0 就是 EOS 标记
#| （`ffffffff 00000000`），file 格式在 footer 之前也可能出现。
sub read-message(Bytes $b, Int $pos --> Hash) {
    return %(kind => 0) if $pos + 8 > $b.elems;

    my Int $marker = $b.u32($pos);
    die sprintf('arrow-read: bad message prefix at %d (0x%08x)', $pos, $marker)
        unless $marker == 0xFFFFFFFF;

    my Int $len = $b.i32($pos + 4);
    die "arrow-read: negative metadata length at $pos" if $len < 0;
    return %(kind => 0) if $len == 0;

    my Int $meta-pos = $pos + 8;
    my $msg = Tbl.new(b => $b, pos => $b.deref($meta-pos));

    my Int $kind = $msg.u8(1);
    my Int $header = $msg.ref(2);
    my Int $body-len = $msg.i64(3, 0);

    %(
        kind     => $kind,
        header   => $header ?? Tbl.new(b => $b, pos => $header) !! Nil,
        body-len => $body-len,
        body     => $meta-pos + $len,
        next     => $meta-pos + $len + $body-len,
    );
}

# ============================================================
# 对外：只看 schema（调试 / 检查文件用）
# ============================================================

#| 不读数据，只把 IPC 文件的 schema 摘出来。给「这个文件到底是什么」用。
#|
#|     say describe-ipc('x.arrow').raku;
our sub describe-ipc(Str:D $path --> Hash) is export {
    my Buf $raw = $path.IO.slurp(:bin);
    die "arrow-read: '$path' is empty" unless $raw.elems;
    my Bytes $b = Bytes.new(buf => $raw);

    # 先看首字节再解码：stream 格式开头是 `ff ff ff ff`，直接当字符串解会炸。
    my Bool $is-file = $raw.elems >= 8 && $b.u8(0) == 0x41    # 'A'
        && $b.str(0, 6) eq 'ARROW1';
    my @fields;
    my Int $batches = 0;
    my Int $rows = 0;

    if $is-file {
        my Int $flen = $b.i32($b.elems - 10);
        my $footer = Tbl.new(b => $b, pos => $b.deref($b.elems - 10 - $flen));
        @fields = parse-schema(Tbl.new(b => $b, pos => $footer.ref(1)));
        my Int $nb = $footer.vec-len(3);
        for ^$nb -> int $i {
            my Int $p = $footer.vec-struct-at(3, $i, 24);
            my $m = read-message($b, $b.i64($p));
            $batches++;
            $rows += $m<header>.i64(0) if $m<kind> == MSG-RECORD-BATCH;
        }
    }
    else {
        my $m = read-message($b, 0);
        die 'arrow-read: stream does not start with a schema message'
            unless $m<kind> == MSG-SCHEMA;
        @fields = parse-schema($m<header>);
        my Int $pos = $m<next>;
        loop {
            my $n = read-message($b, $pos);
            last unless $n<kind>;
            $batches++ if $n<kind> == MSG-RECORD-BATCH;
            $rows += $n<header>.i64(0) if $n<kind> == MSG-RECORD-BATCH;
            $pos = $n<next>;
        }
    }

    %(
        format  => $is-file ?? 'file' !! 'stream',
        fields  => @fields.List,
        batches => $batches,
        rows    => $rows,
    );
}

# ============================================================
# 复合值：Struct / Map
# ============================================================

#| Arrow 的一个 Struct 值。
#|
#| 不用 Raku 的 `Hash` 装：Hash 的遍历顺序没有保证，而 STRUCT 的字面量
#| 必须按 schema 的顺序写字段名。`names` 在解码时就解析好（空名 / 重名
#| 都按位置补），这样渲染时只剩拼字符串。
class StructVal {
    has $.names;
    has $.vals;

    method gist(--> Str) {
        '{' ~ $.names.kv.map(-> $i, $n { "$n: {$.vals[$i].gist}" }).join(', ') ~ '}'
    }
}

#| Arrow 的一个 Map 值：有序的 (键, 值) 对。
#|
#| 键可以是任意类型，所以不能用 `Hash`；用 `Pair` 保留键值对本身。
#| 注意属性是标量 `$.pairs` 而不是 `@.pairs` —— `@`-sigil 属性装 Array
#| 会被 itemize 一层，取出来是「一个元素的数组」，遍历就成了垃圾。
class MapVal {
    has $.pairs;

    method gist(--> Str) {
        '{' ~ $.pairs.map({ "{$_.key.gist}={$_.value.gist}" }).join(', ') ~ '}'
    }
}

#| STRUCT 的字段名：空的按位置补 `f0`，重名的加后缀 —— DuckDB 两样都不收。
sub struct-names(AField $f --> List) {
    my @names;
    for @($f.children).kv -> $i, $c {
        my Str $n = $c.name;
        $n = "f$i" unless $n.chars;
        my Int $dup = @names.grep(* eq $n).elems;
        $n = $n ~ "_$dup" if $dup;
        @names.push: $n;
    }
    @names.List;
}

# ============================================================
# 解码：Arrow 列存 -> Raku 值
# ============================================================

#| 一条 RecordBatch 的游标。
#|
#| `nodes` 与 `buffers` 是两条独立的流，都按**深度优先前序**排列：父节点
#| 在子节点之前，父 buffer 在子 buffer 之前。所以解一个嵌套列必须严格按
#| schema 走 —— 少消费一个 buffer，后面整条流就错位了。
class Cursor {
    has Tbl $.hdr;
    has Bytes $.body;
    has Int $!ni = 0;
    has Int $!bi = 0;

    #| (length, null_count)，对应 `struct FieldNode { int64, int64 }`。
    method node(--> List) {
        my Int $p = $!hdr.vec-struct-at(1, $!ni++, 16);
        ($!hdr.b.i64($p), $!hdr.b.i64($p + 8));
    }

    #| 下一个 buffer 的切片，对应 `struct Buffer { int64 offset, length }`。
    method buf(--> Bytes) {
        my Int $p = $!hdr.vec-struct-at(2, $!bi++, 16);
        $!body.slice($!hdr.b.i64($p), $!hdr.b.i64($p + 8));
    }
}

#| validity bitmap 第 i 位。空 bitmap（长度 0）表示「这一列没有 NULL」。
sub bit-at(Bytes $v, Int $i --> Bool) {
    return True if $v.elems == 0;
    ($v.u8($i div 8) +& (1 +< ($i % 8))) != 0;
}

sub int-at(Bytes $b, Int $p, Int $bytes, Bool $signed --> Int) {
    given $bytes {
        when 1 { $signed ?? $b.i8($p)  !! $b.u8($p)  }
        when 2 { $signed ?? $b.i16($p) !! $b.u16($p) }
        when 4 { $signed ?? $b.i32($p) !! $b.u32($p) }
        when 8 { $signed ?? $b.i64($p) !! $b.u64($p) }
        default { die "arrow-read: bad integer width $bytes" }
    }
}

sub num-at(Bytes $b, Int $p, Int $bytes --> Num) {
    $bytes == 4
        ?? nativecast(CArray[num32], $b.ptr-at($p))[0].Num
        !! nativecast(CArray[num64], $b.ptr-at($p))[0];
}

#| IEEE 754 半精度 -> Num。DuckDB 不会产出 half，但别人的文件可能有。
sub half-to-num(Int $h --> Num) {
    my Int $s = ($h +> 15) +& 1;
    my Int $e = ($h +> 10) +& 0x1F;
    my Int $m = $h +& 0x3FF;
    my Num $sign = $s ?? -1e0 !! 1e0;

    return $m == 0 ?? $sign * 0e0 !! $sign * ($m / 1024e0) * 2 ** -14 if $e == 0;
    return $m == 0 ?? $sign * Inf !! NaN if $e == 31;
    $sign * (1 + $m / 1024e0) * 2 ** ($e - 15);
}

#| 从 1970-01-01 起的天数 -> `YYYY-MM-DD`。
#|
#| Howard Hinnant 的 `civil_from_days`。原文的 `(z >= 0 ? z : z - 146096) / 146097`
#| 是为了在**截断除法**下拿到 floor 语义；Raku 的 `div` 本身就是 floor，
#| 所以这里直接除，不能再减 146096。
sub civil-date(Int $days --> Str) {
    my Int $z = $days + 719468;
    my Int $era = $z div 146097;
    my Int $doe = $z - $era * 146097;               # [0, 146096]
    my Int $yoe = ($doe - ($doe div 1460) + ($doe div 36524) - ($doe div 146096)) div 365;
    my Int $y = $yoe + $era * 400;
    my Int $doy = $doe - (365 * $yoe + ($yoe div 4) - ($yoe div 100));
    my Int $mp = (5 * $doy + 2) div 153;
    my Int $d = $doy - (153 * $mp + 2) div 5 + 1;
    my Int $m = $mp < 10 ?? $mp + 3 !! $mp - 9;
    $y += 1 if $m <= 2;
    sprintf('%04d-%02d-%02d', $y, $m, $d);
}

sub clock-text(Int $us-of-day --> Str) {
    my Int $sec = $us-of-day div 1000000;
    my Int $frac = $us-of-day - $sec * 1000000;
    my Str $hms = sprintf('%02d:%02d:%02d', $sec div 3600, ($sec div 60) % 60, $sec % 60);
    $frac == 0 ?? $hms !! $hms ~ '.' ~ sprintf('%06d', $frac);
}

#| 某个时间单位下的整数值 -> 微秒。`div` 是 floor，负值也对。
sub to-micros(Int $v, Int $unit --> Int) {
    given $unit {
        when 0 { $v * 1000000 }
        when 1 { $v * 1000 }
        when 2 { $v }
        default { $v div 1000 }
    }
}

#| 时间戳 -> `YYYY-MM-DD HH:MM:SS[.ffffff]`，DuckDB 认这个文本。
#|
#| `$tz` 非空时补 `+00`：Arrow 的 timestamp 值永远是 UTC 计数，带时区的
#| 列交给 DuckDB 的 TIMESTAMPTZ 按 UTC 解释，语义一致。
sub timestamp-text(Int $v, Int $unit, Str $tz = '' --> Str) {
    my Int $us = to-micros($v, $unit);
    my Int $sec = $us div 1000000;
    my Int $frac = $us - $sec * 1000000;
    my Int $days = $sec div 86400;
    my Int $sod = $sec - $days * 86400;
    my Str $d = civil-date($days);
    my Str $t = sprintf('%02d:%02d:%02d', $sod div 3600, ($sod div 60) % 60, $sod % 60);
    my Str $frac-text = $frac == 0 ?? '' !! '.' ~ sprintf('%06d', $frac);
    $tz.chars ?? "$d $t$frac-text+00" !! "$d $t$frac-text";
}

#| Decimal 的整数值 + scale -> 精确十进制文本。
#|
#| 不能走 Num：`1.10` 经 double 会变成 `1.1000000000000000888…`，而
#| DECIMAL 列要的是精确值。Raku 的 Int 是任意精度，所以直接搬字符串。
sub decimal-text(Int $v, Int $scale --> Str) {
    my Str $sign = $v < 0 ?? '-' !! '';
    my Str $digits = $v.abs.Str;
    return $sign ~ $digits if $scale <= 0;
    $digits = ('0' x ($scale + 1 - $digits.chars)) ~ $digits
        if $digits.chars <= $scale;
    $sign ~ $digits.substr(0, $digits.chars - $scale)
          ~ '.' ~ $digits.substr($digits.chars - $scale);
}

#| 定点宽度类型的单个值。
sub scalar-value(%t, Bytes $b, Int $i --> Mu) {
    my Int $tag = %t<tag>;
    my Int $w = %t<bytes> // 0;
    my Int $p = $i * $w;

    given $tag {
        when 2 { int-at($b, $p, $w, %t<signed>) }
        when 3 {
            %t<precision> == 0 ?? half-to-num($b.u16($p))
                !! num-at($b, $p, $w);
        }
        when 7 {
            # Decimal128：4 个 u32 拼成有符号 128 位整数
            my Int $lo = $b.u32($p);
            my Int $v = $b.u32($p + 4) * 4294967296 + $lo;
            $v += $b.u32($p + 8) * 18446744073709551616;
            $v += $b.u32($p + 12) * 79228162514264337593543950336;
            $v -= 340282366920938463463374607431768211456
                if $b.u32($p + 12) >= 2147483648;
            decimal-text($v, %t<scale>);
        }
        when 8  { civil-date(%t<unit> == 0 ?? int-at($b, $p, 4, True)
                                                    !! int-at($b, $p, 8, True) div 86400000) }
        when 9  { clock-text(to-micros(int-at($b, $p, $w, True), %t<unit>)) }
        when 10 { timestamp-text(int-at($b, $p, 8, True), %t<unit>, %t<timezone> // '') }
        when 11 {
            # Interval 有三种布局，第三段是「毫秒」还是「纳秒」取决于 unit：
            #   YEAR_MONTH    months:int32
            #   DAY_TIME      days:int32, milliseconds:int32
            #   MONTH_DAY_NANO months:int32, days:int32, nanoseconds:int64
            given %t<unit> {
                when 0 { int-at($b, $p, 4, True) ~ ' months' }
                when 1 {
                    int-at($b, $p, 4, True) ~ ' days '
                        ~ int-at($b, $p + 4, 4, True) ~ ' milliseconds';
                }
                default {
                    int-at($b, $p, 4, True) ~ ' months '
                        ~ int-at($b, $p + 4, 4, True) ~ ' days '
                        ~ int-at($b, $p + 8, 8, True) ~ ' nanoseconds';
                }
            }
        }
        when 15 { $b.bytes($p, $w) }                     # FixedSizeBinary -> Blob
        when 18 { int-at($b, $p, 8, True) }              # Duration：保持原始计数
        default { die "arrow-read: cannot decode fixed-width type tag $tag" }
    }
}

#| 定长/位图/变长都从这里进来。
sub decode-plain(AField $f, %t, Cursor $c, %dicts --> Array) {
    my Str $kind = %t<kind>;

    return Array.new if $kind eq 'null';   # Null 列不占 buffer

    my ($len, $nnull) = $c.node;

    if $kind eq 'bool' {
        my Bytes $valid = $c.buf;
        my Bytes $bits = $c.buf;
        my @out;
        for ^$len -> int $i {
            @out.push: bit-at($valid, $i) ?? bit-at($bits, $i) !! Any;
        }
        return @out.Array;
    }

    if $kind eq 'fixed' {
        my Bytes $valid = $c.buf;
        my Bytes $vals = $c.buf;
        my @out;
        for ^$len -> int $i {
            @out.push: bit-at($valid, $i) ?? scalar-value(%t, $vals, $i) !! Any;
        }
        return @out.Array;
    }

    if $kind eq 'utf8' || $kind eq 'binary' {
        my Bytes $valid = $c.buf;
        my Bytes $offs = $c.buf;
        my Bytes $data = $c.buf;
        my Int $w = %t<width>;
        my sub off(Int $k --> Int) {
            $w == 4 ?? $offs.u32($k * 4) !! $offs.u64($k * 8);
        }
        my Bool $is-str = $kind eq 'utf8';
        my @out;
        for ^$len -> int $i {
            unless bit-at($valid, $i) { @out.push: Any; next }
            my Int $a = off($i);
            my Int $b = off($i + 1);
            my Buf $raw = $data.bytes($a, $b - $a);
            @out.push: $is-str ?? $raw.decode('utf-8') !! $raw;
        }
        return @out.Array;
    }

    if $kind eq 'list' {
        my Bytes $valid = $c.buf;
        my Bytes $offs = $c.buf;
        my Int $w = %t<width>;
        my sub off(Int $k --> Int) {
            $w == 4 ?? $offs.u32($k * 4) !! $offs.u64($k * 8);
        }
        # 子列先整条解出来：List 的 offsets 是子列的下标区间
        my @child = decode-field($f.children[0], $c, %dicts);
        my @out;
        for ^$len -> int $i {
            unless bit-at($valid, $i) { @out.push: Any; next }
            @out.push: @child[off($i) ..^ off($i + 1)].Array;
        }
        return @out.Array;
    }

    # Struct 自己没有 offsets：一个 FieldNode、一个 validity，然后是各子列
    # 按声明顺序的节点与 buffer。子列长度与父列相同，逐行拼成一条值。
    if $kind eq 'struct' {
        my Bytes $valid = $c.buf;
        my @names = struct-names($f);
        my @kids = @($f.children).map({ decode-field($_, $c, %dicts) });
        my @out;
        for ^$len -> int $i {
            unless bit-at($valid, $i) { @out.push: Any; next }
            @out.push: StructVal.new(
                names => @names.Array,
                vals  => @kids.map(*[$i]).Array,
            );
        }
        return @out.Array;
    }

    # Map 在 Arrow 里的物理布局就是 `List<Struct<key, value>>`：validity +
    # int32 offsets，然后是一个 entries 子节点。所以这里只有 offsets 要自己
    # 读，entries 整个交给 decode-field 当 Struct 解。
    if $kind eq 'map' {
        my Bytes $valid = $c.buf;
        my Bytes $offs = $c.buf;
        my Int $w = %t<width>;
        my sub off(Int $k --> Int) {
            $w == 4 ?? $offs.u32($k * 4) !! $offs.u64($k * 8);
        }
        my @entries = decode-field($f.children[0], $c, %dicts);
        my @out;
        for ^$len -> int $i {
            unless bit-at($valid, $i) { @out.push: Any; next }
            my @pairs;
            for off($i) ..^ off($i + 1) -> int $k {
                my $e = @entries[$k];
                # entries 在规范里必须不可空，但坏文件可能有 —— 别崩，留空对
                next unless $e.defined;
                @pairs.push: $e.vals[0] => $e.vals[1];
            }
            @out.push: MapVal.new(pairs => @pairs.Array);
        }
        return @out.Array;
    }

    die "arrow-read: column '{$f.name}' is an Arrow {$f.format}, which this "
      ~ 'version does not read';
}

#| 解码一列（含字典列）。返回值里 `Any` 表示 NULL。
sub decode-field(AField $f, Cursor $c, %dicts, Bool :$use-dict = True --> Array) {
    if $use-dict && $f.dict-id.defined {
        my Int $w = ($f.dict-index-type ?? $f.dict-index-type.i32(0, 32) !! 32) div 8;
        my Bool $signed = $f.dict-index-type ?? $f.dict-index-type.bool(1, False) !! False;
        my ($len, $nnull) = $c.node;
        my Bytes $valid = $c.buf;
        my Bytes $vals = $c.buf;

        # 注意用标量 `$dict` 而不是 `my @dict = %dicts{...}`：Hash 里存的是
        # 一个 Array（item），赋给 @ 变量会变成「一个元素的数组」，下标 0
        # 拿到的是整个字典而不是第一个值。
        my $dict = %dicts{$f.dict-id}
            // die "arrow-read: column '{$f.name}' references dictionary "
                 ~ "{$f.dict-id} but no batch carried it";
        my @out;
        for ^$len -> int $i {
            unless bit-at($valid, $i) { @out.push: Any; next }
            @out.push: $dict[int-at($vals, $i * $w, $w, $signed)];
        }
        return @out.Array;
    }

    decode-plain($f, Duckula::ArrowIPC::parse-format($f.format), $c, %dicts);
}

# ============================================================
# Arrow 类型 -> DuckDB 类型
# ============================================================

#| 一个 Arrow 字段在 DuckDB 里应该是什么类型。
#|
#| 目标是**往返不丢**：`$df.to-arrow` 之后再读回来，列类型应当与原来一致
#| （`BIGINT` 还是 `BIGINT`，`DECIMAL(18,4)` 还是 `DECIMAL(18,4)`）。所以
#| 这里刻意不用「差不多就行」的宽类型。
sub duck-type(AField $f --> Str) {
    my %t = Duckula::ArrowIPC::parse-format($f.format);

    given %t<kind> {
        when 'null'   { return 'VARCHAR' }
        when 'bool'   { return 'BOOLEAN' }
        when 'utf8'   { return 'VARCHAR' }
        when 'binary' { return 'BLOB' }
        when 'list'   { return duck-type($f.children[0]) ~ '[]' }
        when 'struct' {
            my @names = struct-names($f);
            my @kids = @($f.children);
            return 'STRUCT()' unless @kids.elems;
            return 'STRUCT(' ~ @kids.kv.map(-> $i, $c {
                quote-ident(@names[$i]) ~ ' ' ~ duck-type($c)
            }).join(', ') ~ ')';
        }
        when 'map' {
            my @kids = @($f.children);
            die "arrow-read: column '{$f.name}' is a Map without an entries field"
                unless @kids.elems && @(@kids[0].children).elems >= 2;
            return 'MAP(' ~ duck-type(@kids[0].children[0]) ~ ', '
                          ~ duck-type(@kids[0].children[1]) ~ ')';
        }

        default {
            given %t<tag> {
                when 2 {
                    my Str $base = %(8 => 'TINYINT', 16 => 'SMALLINT',
                                     32 => 'INTEGER', 64 => 'BIGINT'){%t<bitwidth>}
                        // die "arrow-read: unsupported Int bitWidth {%t<bitwidth>}";
                    return %t<signed> ?? $base !! 'U' ~ $base;
                }
                when 3 {
                    return %t<precision> == 2 ?? 'DOUBLE' !! 'REAL';
                }
                when 7 {
                    die "arrow-read: DECIMAL({%t<precision>},{%t<scale>}) exceeds "
                      ~ 'DuckDB\'s 38-digit limit'
                        if %t<precision> > 38;
                    return "DECIMAL({%t<precision>},{%t<scale>})";
                }
                when 8  { return 'DATE' }
                when 9  { return 'TIME' }
                when 10 {
                    return (%t<timezone> // '').chars ?? 'TIMESTAMPTZ' !! 'TIMESTAMP';
                }
                when 11 {
                    # Appender 的 cast 不支持 VARCHAR -> INTERVAL（DuckDB 只
                    # 实现了 SQL 侧的 cast），所以这里落成文本，用户要算就
                    # 自己 `::INTERVAL`。转成整数会丢语义：月不是固定天数。
                    return 'VARCHAR';
                }
                when 15 { return 'BLOB' }
                when 18 { return 'BIGINT' }
                default {
                    die "arrow-read: no DuckDB type for Arrow type '{$f.format}'";
                }
            }
        }
    }
}

# ============================================================
# 值 -> Appender 能吃的形状
# ============================================================

#| 把一个字符串写成 DuckDB 容器字面量里的样子。
#|
#| 规矩不是 SQL 标准的「单引号双写」，而是 DuckDB 自己打印 VARCHAR 时的
#| 转义：反斜杠双写、单引号写成 `\'`。两种写法混用不会报错，只会**静默
#| 给出错误的字符串**（`'q''r'` 被读成 `qr`），所以必须与打印格式对齐，
#| 反过来的 cast 才认得回去。
sub quoted-str(Str $s --> Str) {
    "'" ~ $s.subst('\\', '\\\\', :g).subst("'", "\\'", :g) ~ "'";
}

#| 把一个值渲染成 DuckDB 的字面量文本，供 LIST / STRUCT / MAP 用。
#|
#| 三种容器各有各的写法，都是 DuckDB **能 cast 回来**的形式：
#|
#|     LIST    [1, 2, NULL]
#|     STRUCT  {'name': <value>, ...}
#|     MAP     {'key'=<value>, ...}
#|
#| 注意 MAP 不能用 `MAP {…}` 前缀，也不能用冒号 —— 那两种只在 SQL 字面量
#| 里成立，`VARCHAR -> MAP` 的 cast 只认 `{k=v}` 这种「打印出来的形式」。
sub render($v --> Str) {
    return 'NULL' unless $v.defined;
    given $v {
        when StructVal {
            '{' ~ $v.names.kv.map(-> $i, $n {
                quoted-str($n) ~ ': ' ~ render($v.vals[$i])
            }).join(', ') ~ '}';
        }
        when MapVal {
            '{' ~ $v.pairs.map({ quoted-str($_.key.Str) ~ '=' ~ render($_.value) }).join(', ') ~ '}';
        }
        when Array { '[' ~ $v.map({ render($_) }).join(', ') ~ ']' }
        when Str   { quoted-str($v) }
        when Bool  { $v ?? 'true' !! 'false' }
        # BLOB 走 DuckDB 的 `\xNN` 转义。这个转义得先经过容器字面量自身的
        # 一层反转义（`\x00` 在那一层会被吃成 `x00`），所以这里同样交给
        # `quoted-str` 把反斜杠双写 —— 与字符串是完全一样的规矩。
        when Blob  { quoted-str($v.map({ sprintf('\\x%02X', $_) }).join) }
        default    { $v.Str }
    }
}

#| 行内单元格：标量原样交给 Appender（走原生绑定，精度不丢），容器转成
#| 上面那种文本 —— Appender 没有 LIST / STRUCT / MAP 的专门接口。
sub cell($v --> Mu) {
    return Any unless $v.defined;
    given $v {
        when Array | StructVal | MapVal { return render($v) }
        default { return $v }
    }
}

# ============================================================
# 对外：读
# ============================================================

#| 递归找出所有带字典编码的字段，建 `id => AField` 表。
sub dict-map(@fields --> Hash) {
    my %m;
    my sub walk(AField $f) {
        %m{$f.dict-id} = $f if $f.dict-id.defined;
        walk($_) for @($f.children);
    }
    walk($_) for @fields;
    %m;
}

#| 进程内的临时表编号。放在模块作用域而不是 `state`：`state` 在
#| `do { }` 块里每次进入都可能是新的闭包，编号会从 1 重来，第二次导入
#| 就覆盖了第一次的表。
my Int $arrow-seq = 0;

# ============================================================
# 解码缓存
# ============================================================

#| 指纹 → 解码产物。缓存项形如 `%(names => [...], types => [...], cols => [...])`。
#|
#| 只缓存**纯 Raku 值**：列名、DuckDB 类型串、逐列解码后的值。刻意不缓存
#| `Buf` / `Bytes` / `Tbl` —— 那些是字节窗口，持有底层 Buf，属于「解码过程」
#| 而非「解码结果」；留着它们等于把整个文件钉在内存里。也不缓存连接或表：
#| 那些是 session 私有的，见下面 `read-arrow` 的注释。
my %DECODE-CACHE;
my Lock $CACHE-LOCK .= new;
my Int $CACHE-HITS = 0;
my Int $CACHE-MISSES = 0;
my @CACHE-ORDER;                 # FIFO 淘汰顺序
my constant $CACHE-CAP = 8;      # 最多留几个文件的解码结果

#| 文件指纹：绝对路径 + 字节数 + mtime。
#|
#| 为什么不用内容哈希：那要先 slurp 整个文件，而 slurp 正是缓存想省掉的一部分
#| （虽然解码比 slurp 贵得多）。size + mtime 是标准的「文件变没变」判据，
#| 对「写完立刻再读」也够用 —— 写文件必然更新这两者之一。
#|
#| 用绝对路径作键的一部分：相对路径从不同 cwd 指向同一个文件会被当成两个
#| 键（浪费但不错误），反过来同名不同路径串味才是真问题。
my sub file-fingerprint(Str:D $path --> Str) {
    my $io = $path.IO;
    $io.absolute ~ '\0' ~ $io.s ~ '\0' ~ $io.modified.Str;
}

#| 查缓存，未命中记一次 miss。命中返回 Hash，否则返回 Nil。
my sub cache-get(Str:D $key) {
    my $hit;
    $CACHE-LOCK.protect: {
        if %DECODE-CACHE{$key}:exists {
            $CACHE-HITS++;
            $hit = %DECODE-CACHE{$key};
        }
        else {
            $CACHE-MISSES++;
        }
    }
    $hit;
}

#| 存缓存。超过上限按 FIFO 淘汰最老的条目 —— 解码结果是全部行数据，
#| 不加约束的话长期运行的进程会一直攒着，这不是"优化"而是内存泄漏。
my sub cache-put(Str:D $key, $entry --> Nil) {
    $CACHE-LOCK.protect: {
        unless %DECODE-CACHE{$key}:exists {
            @CACHE-ORDER.push($key);
            if @CACHE-ORDER.elems > $CACHE-CAP {
                my Str $oldest = @CACHE-ORDER.shift;
                %DECODE-CACHE{$oldest}:delete;
            }
        }
        %DECODE-CACHE{$key} = $entry;
    }
}

#| 运行时观测缓存效果（命中/未命中/当前条目数）。
our sub arrow-cache-stats(--> Hash) is export {
    $CACHE-LOCK.protect: {
        %( hits => $CACHE-HITS, misses => $CACHE-MISSES,
           entries => %DECODE-CACHE.elems );
    }
}

#| 清空解码缓存（拿到新计数器的干净起点，测试与手动释放内存都用）。
our sub clear-arrow-cache(--> Nil) is export {
    $CACHE-LOCK.protect: {
        %DECODE-CACHE = ();
        @CACHE-ORDER = ();
        $CACHE-HITS = 0;
        $CACHE-MISSES = 0;
    }
}

#| 纯解码：IPC 字节 → 可缓存的列值。不碰 session / 连接 / 临时表。
my sub decode-arrow(Str:D $path --> Hash) {
    my Buf $raw = $path.IO.slurp(:bin);
    die Duckula::X::Frame.new(reason => "read-arrow: '$path' is empty")
        unless $raw.elems >= 8;

    my Bytes $b = Bytes.new(buf => $raw);
    my Bool $is-file = $b.u8(0) == 0x41 && $b.str(0, 6) eq 'ARROW1';

    my @fields;
    my @batches;        # %(header => Tbl, body => Bytes)
    my @dict-specs;     # %(id, header, body, delta)

    if $is-file {
        my Int $flen = $b.i32($b.elems - 10);
        die 'arrow-read: bad footer length'
            if $flen <= 0 || $flen > $b.elems - 10;
        my $footer = Tbl.new(b => $b, pos => $b.deref($b.elems - 10 - $flen));
        @fields = parse-schema(Tbl.new(b => $b, pos => $footer.ref(1)));

        for ^$footer.vec-len(2) -> int $i {
            my Int $p = $footer.vec-struct-at(2, $i, 24);
            my $m = read-message($b, $b.i64($p));
            next unless $m<kind> == MSG-DICT-BATCH;
            @dict-specs.push: %(
                id     => $m<header>.i64(0),
                header => $m<header>,
                body   => $b.slice($m<body>, $m<body-len>),
                delta  => $m<header>.bool(2, False),
            );
        }
        for ^$footer.vec-len(3) -> int $i {
            my Int $p = $footer.vec-struct-at(3, $i, 24);
            my $m = read-message($b, $b.i64($p));
            next unless $m<kind> == MSG-RECORD-BATCH;
            @batches.push: %(
                header => $m<header>,
                body   => $b.slice($m<body>, $m<body-len>),
            );
        }
    }
    else {
        my $m = read-message($b, 0);
        die 'arrow-read: stream does not start with a schema message'
            unless $m<kind> == MSG-SCHEMA;
        @fields = parse-schema($m<header>);

        my Int $pos = $m<next>;
        loop {
            my $n = read-message($b, $pos);
            last unless $n<kind>;
            my Bytes $body = $b.slice($n<body>, $n<body-len>);
            if $n<kind> == MSG-DICT-BATCH {
                @dict-specs.push: %(
                    id => $n<header>.i64(0), header => $n<header>, body => $body,
                    delta => $n<header>.bool(2, False),
                );
            }
            elsif $n<kind> == MSG-RECORD-BATCH {
                @batches.push: %(header => $n<header>, body => $body);
            }
            $pos = $n<next>;
        }
    }

    # 字典必须先于引用它的批次解出来（写侧也是这个顺序）。
    my %dict-field = dict-map(@fields);
    my %dicts;
    for @dict-specs -> $d {
        my AField $vf = %dict-field{$d<id>}
            // die "arrow-read: dictionary {$d<id>} has no matching field";
        my Int $data = $d<header>.ref(1);
        die "arrow-read: dictionary {$d<id>} has no data batch" unless $data;
        my $rh = Tbl.new(b => $b, pos => $data);
        my $cur = Cursor.new(hdr => $rh, body => $d<body>);
        my @vals = decode-field($vf, $cur, %dicts, :!use-dict);
        if $d<delta> && %dicts{$d<id>}.defined {
            %dicts{$d<id>}.append(|@vals);
        }
        else {
            %dicts{$d<id>} = @vals;
        }
    }

    # 逐批次解列，同名列按顺序拼接。
    my @cols = @fields.map({ [] });
    for @batches -> $bt {
        my $cur = Cursor.new(hdr => $bt<header>, body => $bt<body>);
        for ^@fields.elems -> int $i {
            @cols[$i].append(|decode-field(@fields[$i], $cur, %dicts));
        }
    }

    # 列名归一（空名补 column_N、重名加后缀）与 DuckDB 类型都要在解码时
    # 算好：它们依赖 AField 对象，而 AField 不进缓存。
    my @names = @fields.map(*.name);
    for ^@names.elems -> int $i {
        @names[$i] = "column_$i" unless @names[$i].chars;
        my Int $dup = @names[^$i].grep(* eq @names[$i]).elems;
        @names[$i] = @names[$i] ~ "_$dup" if $dup;
    }
    my @types = @fields.map({ duck-type($_) });

    %( names => @names.List, types => @types.List, cols => @cols.List );
}

#| 把 IPC 文件读成一张 Frame。
#|
#|     my $df = $s.read-arrow('out.arrow');
#|     my $df = duckula.read-arrow('out.arrows');
#|
#| 数据会落进一张**临时表**（`CREATE TEMP TABLE`），Frame 的 SQL 指向它，
#| 所以随后的算子全部由 DuckDB 执行。与 `read-parquet` 不同，这里是急切
#| 的：Arrow 的字节必须现在就解码，临时表也就必须现在就建。连接一关，
#| 表跟着消失，Frame 不能跨连接使用。
#|
#| `:$name` 指定表名；不传就用 `__duckula_arrow_N`（进程内单调递增）。
our sub read-arrow($session, Str:D $path, Str :$name --> Duckula::Frame) is export {
    die Duckula::X::Frame.new(reason => "read-arrow: no such file '$path'")
        unless $path.IO.f;

    my Str $key = file-fingerprint($path);
    my $decoded = cache-get($key);
    unless $decoded.defined {
        $decoded = decode-arrow($path);
        cache-put($key, $decoded);
    }

    # ---- 建表并灌数据 ----
    # 这一步**不缓存**：TEMP 表属于当前连接，连接一关就没了；换个 session
    # 就是另一张表。缓存的是上面的纯解码结果，所以跨 session 命中时只需
    # 重新建表 + Appender，不必再解一遍字节。
    my @names = $decoded<names>.List;
    my @types = $decoded<types>.List;
    my @cols  = $decoded<cols>.List;

    my Str $table = $name // ('__duckula_arrow_' ~ (++$arrow-seq));

    my Str $cols-sql = @names.kv.map(-> $i, $n {
        quote-ident($n) ~ ' ' ~ @types[$i]
    }).join(', ');

    $session.conn.execute(
        'CREATE OR REPLACE TEMP TABLE ' ~ quote-ident($table) ~ " ($cols-sql)"
    );

    my Int $rows = @cols.elems ?? @cols[0].elems !! 0;
    if $rows {
        my Int $chunk = 4096;
        for 0, $chunk ...^ $rows -> int $start {
            my Int $stop = min($start + $chunk, $rows);
            my @slice = ($start ..^ $stop).map: -> int $r {
                [ (^@names.elems).map({ cell(@cols[$_][$r]) }) ]
            };
            $session.insert($table, @slice);
        }
    }

    Duckula::Frame.new(
        session      => $session,
        relation-sql => 'SELECT * FROM ' ~ quote-ident($table),
    );
}
