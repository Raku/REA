use v6.d;
use Duckula::SQL;
use Duckula::Guard;
use Duckula::Clean;
use Duckula::Reshape;
use Duckula::Expr;
use Duckula::GroupBy;
use Duckula::Join;
use Duckula::Plan;
use Duckula::Write;
use Duckula::X::Frame;

#| Polars 风格的惰性 Frame：**攒计划树，`collect` 才一次成型**。
#|
#| 和 `Frame` 的分工（§8.3）：
#|   - `Frame`：每次算子立刻拼一条 SQL，`relation-sql` 是真相。用起来像 pandas，
#|     链式十步就是十层子查询 —— DuckDB 吃得下，但 SQL 不好读。
#|   - `LazyFrame`：只累积计划节点，`collect` 时才渲染成**一条**扁平的 SQL。
#|     相邻 filter 合并成一个 WHERE，filter 与 group-by 待在同一层。
#|
#| 两者共享全部语义（列名白名单、表达式、聚合规则、join 后缀规则、窗口锚定），
#| 差别只在「什么时候拼 SQL」。所以同一段逻辑跑出来的**结果必须一致**——
#| `t/12-lazy.rakutest` 就是拿 eager 结果当标准答案来对账的。
#|
#| 刻意 `use` 了 `Duckula::GroupBy` / `Duckula::Join` / `Duckula::Plan`，
#| 但**没有** `use Duckula::Session` 与 `Duckula::Frame`：`Frame` 要 `use`
#| 本模块来实现 `.lazy`，反向 `use` 会形成预编译循环。会话与结果对象在这里
#| 一律按鸭子类型使唤（`$!session.sql(...)`、`$right.relation-sql`）。
class Duckula::LazyFrame {
    has $.session is required;
    has Duckula::Plan $.plan is required;

    has @!names-cache;
    has Bool $!names-known = False;

    #| 已经收集好的 `Frame`（`collect` 的产物），只用来避免重复执行。
    method lazy(--> Duckula::LazyFrame) { self }

    method !derive(Duckula::Plan:D $p --> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(session => $!session, plan => $p);
    }

    #| 渲染成 (SQL, 参数)。
    #|
    #| 参数**不固化**：`?` 一直留到 `collect` 才由驱动绑定，所以惰性路径下
    #| 值从头到尾都没进过 SQL 文本。这是比 eager 路径更严的一条线。
    method !compiled(--> List) { compile-plan($!plan) }

    #| 生成的 SQL（调试/日志用）。注意带 `?` 占位符时不能直接拿去执行。
    method relation-sql(--> Str) { self!compiled[0] }

    #| 列名。只问 schema（`LIMIT 0`），不搬数据，结果缓存。
    method names(--> List) {
        return @!names-cache.List if $!names-known;

        my ($sql, $params) = self!compiled;
        my $res = $!session.conn.query(
            "SELECT * FROM ($sql) AS __duckula_lazy_names LIMIT 0", |$params.List);

        @!names-cache = $res.names.List;
        $!names-known = True;
        @!names-cache.List;
    }

    #| 真的执行。等价于 `duckula.sql(计划渲染出的 SQL)`，但参数走绑定。
    method collect() {
        my ($sql, $params) = self!compiled;
        $params.elems
            ?? $!session.sql($sql, |$params)
            !! $!session.sql($sql);
    }

    #| `collect` 之后导出 Arrow（schema + 逐块 array）。
    #|
    #| 惰性路径没法把 Arrow 也推迟 —— Arrow 的 chunk 就是执行结果本身 ——
    #| 所以这里是计划树的终点，语义等同 `self.collect.arrow`。
    method arrow() {
        self.collect.arrow;
    }

    #| 执行并直接写成 Arrow IPC 文件；语义等同 `self.collect.write-ipc(...)`。
    method write-ipc(Str:D $path, Str:D :$format = 'file' --> Nil) {
        self.collect.write-ipc($path, :$format);
    }

    #| 执行并编码成内存里的 IPC 字节；语义等同 `self.collect.ipc-buf(...)`。
    #|
    #| 这是惰性路径唯一的「执行点」——不 collect 就拿不到字节。
    method ipc-buf(Str:D :$format = 'stream' --> Buf) {
        self.collect.ipc-buf(:$format);
    }

    # ---------------------------------------------------------------- 写出

    #| 渲染出一条**不带占位符**的 SQL，供 `COPY` / `INSERT` 使用。
    #|
    #| 写文件的语句没法绑定参数（见 `Duckula::Write` 的说明），所以这里的
    #| 参数要提前变成字面量。这一步只发生在出库这一刻：计划树本身、以及
    #| `collect` 走的查询路径，仍然是绑定参数。
    method !write-sql(--> Str) {
        my ($sql, $params) = self!compiled;
        $params.elems ?? render-bindings($sql, $params.List) !! $sql;
    }

    #| 写成 Parquet，返回行数；语义等同 `self.collect.to-parquet(...)`，
    #| 但不会为了写文件多跑一次取数的查询。
    method to-parquet(Str:D $path, Str:D :$compression = 'zstd' --> Int) {
        Duckula::Write::write-parquet($!session, self!write-sql, $path,
                                      :$compression);
    }

    #| 写成 CSV，返回行数。
    method to-csv(
        Str:D $path,
        Bool:D :$header = True,
        Str:D :$delimiter = ',',
        Str:D :$quote = '"',
        Str :$null,
        --> Int
    ) {
        Duckula::Write::write-csv($!session, self!write-sql, $path,
                                  :$header, :$delimiter, :$quote, :$null);
    }

    #| 变成一张真表，返回行数。
    method to-table(
        Str:D $name,
        Bool:D :$replace = True,
        Bool:D :$temporary = False,
        --> Int
    ) {
        Duckula::Write::create-table($!session, self!write-sql, $name,
                                     :$replace, :$temporary);
    }

    #| 追加到已有表，返回插入行数。
    method append-to(Str:D $table --> Int) {
        Duckula::Write::insert-into($!session, self!write-sql, $table);
    }

    #| 计划树 + 生成的 SQL，一次看全。
    #|
    #| 有它就是计划树相对 eager 路径最直接的收益：出问题时不用再从
    #| `relation-sql` 那坨嵌套里反推「到底算了什么」。
    method explain(--> Str) {
        my ($sql, $params) = self!compiled;
        my Str $out = "计划：\n" ~ describe-plan($!plan)
                    ~ "\nSQL：\n$sql\n";
        $out ~= "\n参数：{$params.raku}\n" if $params.elems;
        $out;
    }

    # ---------------------------------------------------------------- 列名校验

    method !check-columns(Set $cols, Str:D $op --> Nil) {
        return unless $cols.elems;
        my Set $known = self.names.Set;
        for $cols.keys.sort -> $c {
            die Duckula::X::Frame.new(
                reason => "$op refers to unknown column '$c'; "
                        ~ "available: {self.names.join(', ')}"
            ) unless $known{$c};
        }
    }

    # ---------------------------------------------------------------- 算子

    #| 过滤。表达式版：
    #|   $lf.filter(col('amount') > 100);
    #| SQL 片段版（值走 `?` 绑定）：
    #|   $lf.filter('amount > ?', 100);
    multi method filter(Duckula::Expr:D $pred --> Duckula::LazyFrame) {
        self!check-columns($pred.columns, 'filter');
        self!derive(plan-filter($!plan, $pred.render));
    }

    multi method filter(Str:D $pred, *@args --> Duckula::LazyFrame) {
        check-fragment($pred, :params(@args.elems));
        self!derive(plan-filter($!plan, $pred, |@args));
    }

    #| 投影。列名过白名单。
    method select(*@cols --> Duckula::LazyFrame) {
        my @flat = @cols.elems == 1 && @cols[0] ~~ Positional
            ?? @cols[0].List
            !! @cols.List;

        die Duckula::X::Frame.new(reason => 'select() needs at least one column')
            unless @flat.elems;

        my Set $known = self.names.Set;
        my @items;
        for @flat -> $c {
            my Str $n = $c.Str;
            die Duckula::X::Frame.new(
                reason => "no column named '$n'; available: {self.names.join(', ')}"
            ) unless $known{$n};
            @items.push: quote-ident($n) ~ ' AS ' ~ quote-ident($n);
        }

        self!derive(plan-project($!plan, items => @items.List));
    }

    #| 新增（或覆盖）一列。规则和 `Frame.with-column` 完全一致：
    #| 裸聚合补 `OVER ()` 广播、窗口表达式锚定行号、覆盖同名列先 EXCLUDE。
    multi method with-column(Duckula::Expr:D $e, Str :$name --> Duckula::LazyFrame) {
        my $raw = $name // $e.as;
        die Duckula::X::Frame.new(
            reason => 'with-column needs an alias: '
                    ~ 'use .alias("name") on the expression or pass :name<name>'
        ) unless $raw.defined && $raw.Str ne '';
        my Str $n = $raw.Str;

        self!check-columns($e.columns, 'with-column');

        my Str $expr = $e.render;
        my Bool $anchored = False;

        if $e.window.defined {
            $anchored = True;
        } elsif $e.bare-agg {
            $expr ~= ' OVER ()';
        } elsif $e.is-aggregate {
            die Duckula::X::Frame.new(
                reason => "with-column can't use an aggregate inside a larger "
                        ~ "expression ('$expr'); put .over() on each aggregate, "
                        ~ "e.g. (col('x').sum.over / len().over)"
            );
        }

        my Set $known = self.names.Set;
        my Bool $replace = $n ∈ $known;
        my Str $alien = quote-ident($n);

        if $anchored {
            # 锚定那层由渲染器拼，覆盖列交给它的 `exclude` 字段。
            my Str $rn = '__duckula_ord';
            $rn ~= '_' while $rn ∈ $known;

            return self!derive(plan-project(
                $!plan,
                items    => ($expr ~ ' AS ' ~ $alien,),
                anchored => True,
                exclude  => $replace ?? $alien !! '',
                anchor   => $rn,
            ));
        }

        my Str $head = $replace ?? '* EXCLUDE (' ~ $alien ~ ')' !! '*';
        self!derive(plan-project(
            $!plan,
            items => ($head, $expr ~ ' AS ' ~ $alien),
        ));
    }

    multi method with-columns(*@exprs --> Duckula::LazyFrame) {
        my @flat = @exprs.elems == 1 && @exprs[0] ~~ Positional
            ?? @exprs[0].List
            !! @exprs.List;

        my $f = self;
        for @flat -> $e {
            $f = $f.with-column($e);
        }
        $f;
    }

    #| 分组，返回中间对象（和 eager 路径是同一个类）。
    #| `GroupBy.agg` 会调我们的 `agg-from-spec`，于是聚合也进计划树。
    method group-by(*@keys --> Duckula::GroupBy) {
        my @flat = @keys.elems == 1 && @keys[0] ~~ Positional
            ?? @keys[0].List
            !! @keys.List;

        my @exprs = @flat.map(-> $k {
            $k ~~ Duckula::Expr ?? $k !! col($k.Str);
        });

        for @exprs -> Duckula::Expr $e {
            self!check-columns($e.columns, 'group-by');
        }

        Duckula::GroupBy.new(frame => self, keys => @exprs);
    }

    method agg(*@aggs --> Duckula::LazyFrame) {
        Duckula::GroupBy.new(frame => self, keys => ()).agg(|@aggs);
    }

    #| `GroupBy.agg` 的钩子：接住已经校验好的投影，造计划节点。
    #| 位置分组（`GROUP BY 1, 2`）与 eager 路径保持一致。
    method agg-from-spec(Hash $spec, List $keys --> Duckula::LazyFrame) {
        my List $group = $keys.elems ?? (1 .. $keys.elems).List !! ();
        self!derive(plan-aggregate(
            $!plan,
            items => $spec<items>.List,
            group => $group,
        ));
    }

    method sort-values(Str:D $column, Bool :$desc = False --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(
            reason => "no column named '$column'; available: {self.names.join(', ')}"
        ) unless $column ∈ self.names.Set;

        self!derive(plan-sort(
            $!plan,
            order => (quote-ident($column) ~ ($desc ?? ' DESC' !! ''),),
        ));
    }

    method limit(Int $n = 5 --> Duckula::LazyFrame) { self.head($n) }

    method head(Int $n = 5 --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(reason => "head() needs a non-negative count, got $n")
            if $n < 0;
        self!derive(plan-limit($!plan, $n));
    }

    #| 末尾 n 行。要数总行数，所以在这里就把上游渲染成子查询 ——
    #| 计划树在这个节点断开，但数据仍然只扫一遍（§8.10）。
    method tail(Int $n = 5 --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(reason => "tail() needs a non-negative count, got $n")
            if $n < 0;
        return self.head(0) if $n == 0;

        my ($sql, $params) = self!compiled;
        my Set $known = self.names.Set;

        my Str $rn = '__duckula_rn';
        $rn ~= '_' while $rn ∈ $known;
        my Str $cnt = $rn ~ '_n';

        my Str $tail =
            'SELECT * EXCLUDE (' ~ quote-ident($rn) ~ ', ' ~ quote-ident($cnt) ~ ') '
          ~ 'FROM (SELECT *, row_number() OVER () AS ' ~ quote-ident($rn)
          ~ ', count(*) OVER () AS ' ~ quote-ident($cnt)
          ~ ' FROM (' ~ $sql ~ ') AS __duckula_tail_w) AS __duckula_tail '
          ~ 'WHERE ' ~ quote-ident($rn) ~ ' > ' ~ quote-ident($cnt) ~ ' - ' ~ $n;

        self!derive(plan-source($tail, |$params));
    }

    #| 切片。负 offset 从末尾算，代价是一次 `count(*)`。
    method slice(Int $offset, Int $length? --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(reason => "slice() needs a non-negative length, got $length")
            if $length.defined && $length < 0;

        my ($sql, $params) = self!compiled;
        my Str $lim = $length.defined ?? ' LIMIT ' ~ $length !! '';

        return self!derive(plan-source(
            "SELECT * FROM ($sql) AS __duckula_slice" ~ $lim ~ ' OFFSET ' ~ $offset,
            |$params,
        )) if $offset >= 0;

        my Str $skip = 'greatest(count(*) - ' ~ $offset.abs ~ ', 0)';
        # 关系出现两次（一次取数、一次数行数），所以参数也要给两遍。
        my @twice = (|$params.List, |$params.List);
        self!derive(plan-source(
            "SELECT * FROM ($sql) AS __duckula_slice" ~ $lim
            ~ " OFFSET (SELECT $skip FROM ($sql) AS __duckula_count)",
            |@twice,
        ));
    }

    # ---------------------------------------------------------------- 清洗与重塑
    #
    # 和 eager 路径同一批语义，只是落点不同：
    #   - `rename` / `drop` / `cast` / `fill-nulls`（定值、mean、median）能表达成
    #     投影，`drop-nulls` 能表达成过滤 —— 全部进计划树，后续的 filter 还能
    #     和它们合并成一层；
    #   - `concat`（集合运算）、`unique` / `value-counts` / `fill-nulls`
    #     （ffill / bfill，要行序锚）需要三层嵌套或集合运算，`Plan::Query`
    #     表达不了，所以在这里渲染成 SQL、包成 `Source` 节点往下走。参数顺序
    #     照样保留（子查询 SQL 总在外层子句之前）。

    #| 纵向拼接（同 `Frame.concat`，右侧可以混用 Frame 与 LazyFrame）。
    multi method concat(*@others, Bool :$strict = False --> Duckula::LazyFrame) {
        my @flat = flatten-args(@others);
        die Duckula::X::Frame.new(
            reason => 'concat needs at least one other frame'
        ) unless @flat.elems;

        my ($sql, $params) = self!compiled;

        my @sqls;
        @sqls.push: $sql;

        my @params;
        @params.append: $params.List;

        # 每帧的列名各占一个元素（List 套 List），供 :strict 逐帧比对。
        my @names;
        @names.push: self.names;

        for @flat -> $o {
            die Duckula::X::Frame.new(
                reason => 'concat: every frame must belong to the same session'
            ) unless $o.can('session') && $o.session === $!session;

            if $o.can('plan') {
                my ($s, $p) = compile-plan($o.plan);
                @sqls.push: $s;
                @params.append: $p.List;
            } elsif $o.can('relation-sql') {
                @sqls.push: $o.relation-sql;
            } else {
                die Duckula::X::Frame.new(
                    reason => 'concat expects Frames or LazyFrames, got ' ~ $o.^name
                );
            }

            @names.push: $o.names;
        }

        check-same-columns(@names, 'concat(:strict)') if $strict;

        self!derive(plan-source(concat-sql(@sqls.List), |@params));
    }

    #| 去重（语义见 `Frame.unique`）。
    multi method unique(*@subset, Str :$keep = 'first' --> Duckula::LazyFrame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'unique');

        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            unique-sql($sql, @cols, $keep, @names), |$params.List
        ));
    }

    #| 单列频次表（语义见 `Frame.value-counts`）。
    method value-counts(
        Str:D $column,
        Bool :$sort = True,
        Bool :$normalize = False,
        Bool :$keep-nulls = False,
        --> Duckula::LazyFrame
    ) {
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            value-counts-sql($sql, $column, self.names,
                             :$sort, :$normalize, :$keep-nulls),
            |$params.List,
        ));
    }

    #| 改列名（语义见 `Frame.rename`）。进计划树，所以后面接 filter 能合并。
    multi method rename(*@maps, Bool :$strict = True --> Duckula::LazyFrame) {
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        self!derive(plan-project(
            $!plan,
            items => rename-items(self.names, $map, :$strict),
        ));
    }

    #| 删列（语义见 `Frame.drop`）。
    multi method drop(*@cols --> Duckula::LazyFrame) {
        self!derive(plan-project(
            $!plan,
            items => drop-items(self.names, flatten-args(@cols)),
        ));
    }

    #| 删掉含空值的行（语义见 `Frame.drop-nulls`）。这就是一个过滤，能合并。
    multi method drop-nulls(*@subset, Str :$how = 'any' --> Duckula::LazyFrame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'drop-nulls');

        self!derive(plan-filter($!plan, null-predicate(@cols, $how)));
    }

    #| 填空值（语义见 `Frame.fill-nulls`）。
    multi method fill-nulls(*@subset, :$value, Str :$strategy --> Duckula::LazyFrame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'fill-nulls');

        my Str $mode = fill-mode(:$value, :$strategy);
        my Bool $win = needs-seq($mode);
        my Str $seq = $win ?? private-name(@names, '__duckula_seq') !! '';

        my @items = fill-items(@cols, $mode, :$value, :$seq);

        if $win {
            # 带行序锚的投影：渲染器知道怎么钉行号、算完再排回去（§8.9）。
            return self!derive(plan-project(
                $!plan,
                items    => @items.List,
                anchored => True,
                exclude  => quoted-list(@cols),
                anchor   => $seq,
            ));
        }

        self!derive(plan-project(
            $!plan,
            items => ('* EXCLUDE (' ~ quoted-list(@cols) ~ ')', |@items).List,
        ));
    }

    #| 改列类型（语义见 `Frame.cast`）。
    multi method cast(*@maps --> Duckula::LazyFrame) {
        my @names = self.names;
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        my @pairs = as-pairs($map, 'cast');

        die Duckula::X::Frame.new(reason => 'cast needs at least one column')
            unless @pairs.elems;

        my %type-of;
        for @pairs -> $p {
            my Str $c = $p.key.Str;
            need-cols(($c,), @names, 'cast');
            %type-of{$c} = check-type-name($p.value.Str);
        }

        my @items = @names.map(-> $c {
            %type-of{$c}:exists
                ?? 'CAST(' ~ quote-ident($c) ~ ' AS ' ~ %type-of{$c} ~ ') AS '
                 ~ quote-ident($c)
                !! quote-ident($c) ~ ' AS ' ~ quote-ident($c);
        });

        self!derive(plan-project($!plan, items => @items.List));
    }

    #| 展开列表列（语义见 `Frame.explode`）。unnest 是合法投影，进计划树。
    multi method explode(*@cols, Bool :$keep-empty = True --> Duckula::LazyFrame) {
        my @names = self.names;
        my @items = explode-items(@names, flatten-args(@cols), :$keep-empty);
        self!derive(plan-project($!plan, items => @items.List));
    }

    #| 宽转长（语义见 `Frame.unpivot`）。UNPIVOT 是表函数，断成 Source 节点。
    multi method unpivot(*@on, :$index, Str :$variable-name = 'variable',
                         Str :$value-name = 'value' --> Duckula::LazyFrame) {
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @uncols = flatten-args(@on);
        @uncols = @names.grep({ !@idx.Set{$_} }) unless @uncols.elems;
        check-unpivot-columns(@uncols, @idx, @names);

        my Str $var = private-name(@names, $variable-name);
        my Str $val = private-name(@names, $value-name);

        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            unpivot-sql($sql, @uncols, @idx, $var, $val), |$params.List
        ));
    }

    #| 长转宽（语义见 `Frame.pivot`）。分组值要先查一遍数据，因此这里和 eager
    #| 一样会在建算子时跑一次 DISTINCT；计划树本身退化成 Source 节点。
    method pivot(
        Str:D :$on!,
        :$index,
        :$values,
        Str :$agg = 'sum',
        Bool :$keep-nulls = False,
        --> Duckula::LazyFrame
    ) {
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @vls = $values.defined ?? flatten-args(($values,)) !! ();
        need-cols(($on,), @names, 'pivot');
        need-cols(@idx, @names, 'pivot');

        my @vals = @vls.elems
            ?? @vls
            !! @names.grep({ $_ ne $on && !@idx.Set{$_} }).List;
        need-cols(@vals, @names, 'pivot');
        die Duckula::X::Frame.new(reason => 'pivot: nothing left to aggregate')
            unless @vals.elems;

        my Str $a = check-agg($agg);
        my ($sql, $params) = self!compiled;
        my @keys = pivot-keys($!session.conn, $sql, $on,
                              $params.List, :$keep-nulls);

        self!derive(plan-source(
            pivot-sql($sql, $on, @idx, @vals, @keys, $a, :$keep-nulls),
            |$params.List,
        ));
    }

    #| 采样（语义见 `Frame.sample`）。USING SAMPLE 属于 FROM 子句，退成 Source。
    method sample(Int :$n, :$frac, Int :$seed --> Duckula::LazyFrame) {
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            sample-sql($sql, :$n, :$frac, :$seed), |$params.List
        ));
    }

    #| 每列一行的概览（语义见 `Frame.describe`）。SUMMARIZE 退成 Source。
    method describe(--> Duckula::LazyFrame) {
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(describe-sql($sql), |$params.List));
    }

    #| 连接。右侧可以是 `LazyFrame`，也可以是 `Frame`（自动包成 Source 节点）。
    method join($right, :$on, Str :$how = 'inner', Str :$suffix = '_right'
                --> Duckula::LazyFrame) {
        my $rp = $right ~~ Duckula::LazyFrame
            ?? $right.plan
            !! plan-source($right.relation-sql);

        my %spec = join-layout(
            self.names.List, $right.names.List, :$on, :$how, :$suffix
        );

        self!derive(Duckula::Plan::Join.new(
            left       => $!plan,
            right      => $rp,
            mode       => %spec<mode>,
            join-sql   => %spec<join-sql>,
            exists-sql => %spec<exists-sql>,
            on-sql     => %spec<on-sql>,
            items      => %spec<items>.List,
        ));
    }

    #| 在计划中插一段 SQL，`self` 指代当前计划的结果。
    #|
    #| **这是计划树的边界**：`self` 要绑成临时视图，而建视图必须立刻执行
    #| `CREATE VIEW`，没法推迟到 collect —— 所以这里会把上游先渲染成 SQL、
    #| 建好视图，再把用户 SQL 包成一个 Source 节点继续往下攒。
    method sql(Str:D $sql, *@args, Bool :$unsafe = False --> Duckula::LazyFrame) {
        my ($body, $params) = self!compiled;

        # 视图里不能留占位符，参数先固化（`render-bindings` 会正确转义）。
        my Str $body-sql = $params.elems ?? render-bindings($body, $params) !! $body;

        my Str $text = $sql.trim.subst(/ ';' $ /, '').trim;
        my Str $view = $!session.bind-view($body-sql);
        my Str $bound = replace-bare-ident($text, 'self', $view);

        check-sql($bound, :params(@args.elems), :strict(!$unsafe && $!session.strict),
                  :conn($!session.conn));

        self!derive(plan-source($bound, |@args));
    }
}
