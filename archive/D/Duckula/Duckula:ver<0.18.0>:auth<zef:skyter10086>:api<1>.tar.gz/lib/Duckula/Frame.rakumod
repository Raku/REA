use v6.d;
use Duckula::SQL;
use Duckula::Guard;
use Duckula::Clean;
use Duckula::Reshape;
use Duckula::Expr;
use Duckula::GroupBy;
use Duckula::Join;
use Duckula::Series;
use Duckula::LazyFrame;
use Duckula::Plan;
use Duckula::Arrow;
use Duckula::Write;
use Duckula::X::Frame;

#| DuckDB 里「Raku 没有原生对应类型、被驱动解码成十进制字符串」的类型。
#|
#| HUGEINT 是 128 位整数（`sum(bigint)` 的结果就是它），DECIMAL 是定点数。
#| Raku 的 Int 本来就没有位宽上限、Rat 是精确有理数，所以把字符串还原成
#| 数值是**无损**的 —— 白白保留字符串只会让 `$g.rows` 里出现 `"450"`。
my sub looks-typed-numeric(Str:D $t --> Bool) {
    so $t ~~ /^ [ 'HUGEINT' | 'UHUGEINT' | 'BIGNUM' | 'DECIMAL' ]/;
}

#| 一张表视图：**真相是 $.relation-sql 这条 SELECT，不是那堆数据**。
#|
#| 这样做的原因（ARCHITECTURE.md §9.7）：
#|   - `$df.sql("... from self ...")` 需要一条能塞进临时视图的 SELECT；
#|   - 链式算子可以直接拼 SQL，不必先把数据搬进 Raku；
#|   - 物化只在真正要数据时发生一次，且结果缓存。
#|
#| 注意：本类的物化结果会消耗 DB::DuckDB::Result 的游标，所以一次性取全
#| 并存进 @!rows。ColumnView 的零拷贝路径留给 Series（阶段 1）。
class Duckula::Frame {
    has $.session is required;
    has Str $.relation-sql is required;

    has $!result;
    has Bool $!materialized = False;
    has Bool $!names-known = False;
    has @!names;
    has @!rows;

    #| 内部构造：允许把已执行好的 Result 一并交进来，避免二次执行。
    submethod BUILD(:$!session, Str :$relation-sql!, :$result) {
        $!relation-sql = $relation-sql.trim.subst(/ ';' $ /, '').trim;
        $!result = $result;
    }

    method !materialize(--> Nil) {
        return if $!materialized;

        my $res = $!result // $!session.conn.query($!relation-sql);
        @!names = $res.names.List;      # names 要在结果 alive 时读

        # 优先走 ColumnView：它带 .type，能把 HUGEINT / DECIMAL 这类
        # 「驱动解码成字符串」的列还原成数值。ColumnView 被
        # DB_DUCKDB_NO_COLUMN_VIEW=1 整体关掉时退回 arrays。
        my @views = ();
        @views = $res.column-views.List if $res.can('column-views');

        if @views.elems && @views.elems == @!names.elems {
            @!rows = self!rows-from-views(@views);
        } else {
            @!rows = $res.arrays.List;  # 游标消耗，取全
        }

        $!result = Nil;
        $!materialized = True;
        $!names-known = True;
    }

    #| 只取列名，不取数据。
    #|
    #| `SELECT * FROM (...) LIMIT 0` 让 DuckDB 规划一遍并返回 schema，
    #| 一行都不搬。算子（select / filter / join / group-by）都只要列名，
    #| 走这条路径才不会为了拿几个名字把整张表拉进 Raku。
    method !ensure-names(--> Nil) {
        return if $!names-known;

        # 已经拿到 Result 的话直接读它的 names，省一次查询。
        if $!result {
            @!names = $!result.names.List;
        } else {
            my $res = $!session.conn.query(
                "SELECT * FROM ({$!relation-sql}) AS __duckula_names LIMIT 0"
            );
            @!names = $res.names.List;
        }
        $!names-known = True;
    }

    #| 按列取类型化数据再转置成行。
    method !rows-from-views(@views --> List) {
        my @cols = @views.map(-> $v { self!decode-column($v) });
        my Int $n = @cols.elems ?? @cols[0].elems !! 0;

        my @out;
        for ^$n -> $i {
            # 行用 Array（和 `Result.arrays` 的返回形态一致），不是 List，
            # 这样两条物化路径对调用方是同一种东西。
            @out.push: @cols.map(-> @c { @c[$i] }).Array;
        }
        @out.List;
    }

    method !decode-column($v --> List) {
        my List $vals = $v.to-list.List;

        my Str $t = ($v.type // '').Str;
        return $vals unless looks-typed-numeric($t);

        # DECIMAL 走 Rat（精确），整数类走 Int。Raku 的 Int 没有位宽上限，
        # 128 位的 HUGEINT 也不会溢出。
        my Bool $decimal = $t.uc.starts-with('DECIMAL');

        # 注意别在 map 块里写 `return` —— 那会从整个方法返回。
        $vals.map(-> $x {
            $x ~~ Str
                ?? ($decimal
                        ?? ($x ~~ /^ '-'? \d+ ['.' \d+]? $/ ?? $x.Rat !! $x)
                        !! ($x ~~ /^ '-'? \d+ $/             ?? $x.Int !! $x))
                !! $x;
        }).List;
    }

    #| 列名，顺序与 SELECT 输出一致。
    #|
    #| 只问 schema，不搬数据 —— 所以 `join` 问两次列名也不会把两张表拉下来。
    method names(--> List) {
        self!ensure-names;
        @!names.List;
    }

    #| 全部行，每行是一个 Array（按 names 顺序）。
    method rows(--> List) {
        self!materialize;
        @!rows.List;
    }

    method elems(--> Int) {
        self!materialize;
        @!rows.elems;
    }

    #| (rows, cols)，对位 pandas 的 df.shape。
    method shape(--> List) {
        (self.elems, self.names.elems);
    }

    #| 取前 $n 行，仍然返回 Frame（SQL 层面加 LIMIT，不搬数据）。
    method head(Int $n = 5 --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => "head() needs a non-negative count, got $n")
            if $n < 0;
        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_head LIMIT $n",
        );
    }

    #| Polars 的名字，等价于 `head($n)`。
    method limit(Int $n = 5 --> Duckula::Frame) { self.head($n) }

    #| 取末尾 $n 行（Polars 的 `tail`）。
    #|
    #| 没有「行序」这回事的 SQL 里，末尾只能靠计数找。这里**只扫一遍**数据：
    #| `row_number() OVER ()` 给每行编号、`count(*) OVER ()` 给总行数，
    #| 外层筛 `rn > 总数 - n`。两个窗口函数共用同一次扫描，顺序沿用扫描顺序
    #| （和 Polars 依赖 frame 行序一个意思），筛选后顺序不变。
    #|
    #| 备选写法是 `OFFSET (SELECT count(*)-n …)`，但那会让关系被算两遍，
    #| 在 CSV/Parquet 上就是两次全表扫描。
    method tail(Int $n = 5 --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => "tail() needs a non-negative count, got $n")
            if $n < 0;
        return self.head(0) if $n == 0;

        # 辅助列名要保证不撞上用户列名，撞了会静默覆盖掉一列真实数据。
        my Set $known = self.names.Set;
        my Str $rn = '__duckula_rn';
        $rn ~= '_' while $rn ∈ $known;
        my Str $cnt = $rn ~ '_n';

        Duckula::Frame.new(
            :$!session,
            relation-sql =>
                'SELECT * EXCLUDE (' ~ quote-ident($rn) ~ ', ' ~ quote-ident($cnt) ~ ') '
              ~ 'FROM (SELECT *, row_number() OVER () AS ' ~ quote-ident($rn)
              ~ ', count(*) OVER () AS ' ~ quote-ident($cnt)
              ~ " FROM ({$!relation-sql}) AS __duckula_tail_w) AS __duckula_tail "
              ~ 'WHERE ' ~ quote-ident($rn) ~ ' > ' ~ quote-ident($cnt) ~ ' - ' ~ $n,
        );
    }

    #| 切片，对应 Polars 的 `slice(offset, length)`：
    #|
    #|   $df.slice(2, 3);   # 第 3~5 行
    #|   $df.slice(2);      # 从第 3 行到末尾
    #|   $df.slice(-3);     # 末尾 3 行
    #|   $df.slice(-5, 2);  # 倒数第 5 行起取 2 行
    #|
    #| 负 offset 从末尾算（和 Polars 一致），代价是一次 `count(*)` —— 因为
    #| 「从末尾数第几行」在 SQL 里必须先知道总行数。
    method slice(Int $offset, Int $length? --> Duckula::Frame) {
        die Duckula::X::Frame.new(reason => "slice() needs a non-negative length, got $length")
            if $length.defined && $length < 0;

        my Str $lim = $length.defined ?? ' LIMIT ' ~ $length !! '';

        return Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_slice"
                          ~ $lim ~ ' OFFSET ' ~ $offset,
        ) if $offset >= 0;

        # 负 offset：先数总行数，再跳过 (总数 + offset) 行。
        # greatest(..., 0) 保证 offset 比总行数还长时跳过全部，不报负 OFFSET。
        my Str $skip = 'greatest(count(*) - ' ~ $offset.abs ~ ', 0)';
        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_slice"
                          ~ $lim
                          ~ " OFFSET (SELECT $skip FROM ({$!relation-sql}) AS __duckula_count)",
        );
    }

    #| 转成惰性计划（Polars 的 `lazy()`），之后的算子攒计划树、`collect` 才渲染。
    method lazy(--> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(
            session => $!session,
            plan    => plan-source($!relation-sql),
        );
    }

    #| 导出 Arrow：schema + 逐块 array，交给 pyarrow / Polars 之类的消费者。
    #|
    #|     my $t = $df.arrow;
    #|     say $t.schema.gist;
    #|     $t.chunks: -> $chunk { ... };
    #|     $t.free;
    #|
    #| 返回的对象持有自己的 Result（Arrow 的 schema 引用着它），所以这个
    #| Frame 之后再被复用也无所谓 —— 代价是多执行一次 SELECT。
    method arrow(--> Duckula::Arrow) {
        Duckula::Arrow.from-frame(self);
    }

    #| 直接把结果写成 Arrow IPC 文件（`.arrow` / `.feather`）。
    #|
    #| 等价于 `self.arrow.write-ipc($path, :$format)`，只是省掉自己收尾。
    #| 产物是自描述字节，pyarrow / polars / 任何 Arrow 实现都能直接读 ——
    #| 跨进程交换走这条路，不用 DuckDB 的 `arrow` 扩展。
    method write-ipc(Str:D $path, Str:D :$format = 'file' --> Nil) {
        my $a = self.arrow;
        LEAVE $a.free;
        $a.write-ipc($path, :$format);
    }

    #| 编码成内存里的 IPC 字节（默认 `stream` 格式）。
    #|
    #| 跨进程交换用这个，而不是 C data interface 的裸指针 —— 指针只在导出
    #| 它的进程里有效。字节可以写进管道、塞给 `Inline::Python` 里的
    #| `pa.ipc.open_stream(...)`。
    method ipc-buf(Str:D :$format = 'stream' --> Buf) {
        my $a = self.arrow;
        LEAVE $a.free;
        $a.ipc-buf(:$format);
    }

    # ---------------------------------------------------------------- 写出

    #| 写成 Parquet，返回行数。
    #|
    #| 数据不出 DuckDB：`COPY (<relation-sql>) TO ...` 由 DuckDB 自己做，
    #| 一行都不经过 Raku。压缩默认 zstd（同 pandas 的 pyarrow 默认之外更省），
    #| 可选 uncompressed / snappy / gzip / brotli / lz4 / lz4_raw。
    method to-parquet(Str:D $path, Str:D :$compression = 'zstd' --> Int) {
        Duckula::Write::write-parquet($!session, $!relation-sql, $path,
                                      :$compression);
    }

    #| 写成 CSV，返回行数。
    #|
    #| `:$delimiter` / `:$quote` 必须是单字符；`:$null` 给定后空值写成它。
    #| 路径与选项都经过转义，文件名里带单引号也不会变成注入点。
    method to-csv(
        Str:D $path,
        Bool:D :$header = True,
        Str:D :$delimiter = ',',
        Str:D :$quote = '"',
        Str :$null,
        --> Int
    ) {
        Duckula::Write::write-csv($!session, $!relation-sql, $path,
                                  :$header, :$delimiter, :$quote, :$null);
    }

    #| 变成一张真表（`CREATE TABLE ... AS`），返回行数。
    #|
    #| 数据不出库，所以不受沙箱限制，也比落文件快。`:replace` 默认 True
    #| （对齐 pandas 的 `to_sql(if_exists => 'replace')`）；`:temporary` 建
    #| 连接级临时表。
    method to-table(
        Str:D $name,
        Bool:D :$replace = True,
        Bool:D :$temporary = False,
        --> Int
    ) {
        Duckula::Write::create-table($!session, $!relation-sql, $name,
                                     :$replace, :$temporary);
    }

    #| 追加到已有表（`INSERT INTO ... SELECT`），返回插入行数。
    #|
    #| 列按位置对齐。表不存在、列数与类型不兼容都让 DuckDB 当场报错 ——
    #| 这里不替它猜。
    method append-to(Str:D $table --> Int) {
        Duckula::Write::insert-into($!session, $!relation-sql, $table);
    }

    #| 在当前 Frame 上执行一段 SQL，`self` 指代它自己。
    #| 绑定方式见 Session.sql-on-frame（临时视图，不是子查询）。
    method sql(Str:D $sql, *@args, *%named, Bool :$unsafe = False --> Duckula::Frame) {
        $!session.sql-on-frame(self, $sql, |@args, |%named, :$unsafe);
    }

    #| 由一条 SQL 派生出新 Frame（同会话）。
    #|
    #| 存在的意义是给 `GroupBy` 这类外部模块用：它们握着「上游 Frame」，
    #| 需要造下游 Frame，但不能 `use Duckula::Frame`（会与 Frame 的
    #| `use Duckula::GroupBy` 形成预编译循环）。有了这个方法，它们只要
    #| `$frame.derived($sql)`，一个类型名都不用写。
    method derived(Str:D $sql --> Duckula::Frame) {
        Duckula::Frame.new(session => $!session, relation-sql => $sql);
    }

    #| 取一列，返回 Series（ColumnView 的薄包装，零拷贝）。
    #|
    #| 会重跑一次 relation-sql 以拿到新的 Result —— ColumnView 的指针属于
    #| result，而物化路径已经消耗掉上一个结果集的游标。取的列多了建议改
    #| 用 `.select` 一次取齐，或直接在 SQL 里聚合。
    method column(Str:D $name --> Duckula::Series) {
        my $res = $!session.conn.query($!relation-sql);
        my List $names = $res.names.List;
        my $idx = $names.first($name, :k);

        die Duckula::X::Frame.new(
            reason => "no column named '$name'; available: {$names.join(', ')}"
        ) unless defined $idx;

        my List $views = $res.column-views.List;

        Duckula::Series.new(name => $name, view => $views[$idx], result => $res, frame => self);
    }

    #| 选若干列，返回新的 Frame（SQL 层面只投影这些列）。
    #|
    #| 列名一律过 quote-ident + 白名单（§9.5.3）：
    #|   - quote-ident 保证任何字符都退化成合法标识符；
    #|   - 白名单保证写错的列名当场报错，而不是静默多出一个 NULL 列。
    method select(*@cols --> Duckula::Frame) {
        my @flat = @cols.elems == 1 && @cols[0] ~~ Positional
            ?? @cols[0].List
            !! @cols.List;

        die Duckula::X::Frame.new(reason => 'select() needs at least one column')
            unless @flat.elems;

        my Set $known = self.names.Set;
        my @picked;
        for @flat -> $c {
            my Str $n = $c.Str;
            die Duckula::X::Frame.new(
                reason => "no column named '$n'; available: {self.names.join(', ')}"
            ) unless $known{$n};
            @picked.push: quote-ident($n);
        }

        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT {@picked.join(', ')} "
                          ~ "FROM ({$!relation-sql}) AS __duckula_select",
        );
    }

    #| 表达式引用的列必须在 names 里，否则拼错的列名会被 DuckDB 静默当成
    #| 「未知标识符」报错，或者更糟——在外层子查询里意外绑定到别的列。
    method !check-columns(Set $cols, Str:D $op --> Nil) {
        return unless $cols.elems;
        my Set $known = self.names.Set;
        for $cols.keys.sort -> $c {
            die Duckula::X::Frame.new(
                reason => "$op refers to unknown column '$c'; "
                        ~ "available: {self.names.join(', ')}"
            ) unless $known{$c};
        }
    }

    #| 过滤行。表达式版本，列名已在 col() 里过 quote-ident：
    #|
    #|   $df.filter(col('amount') > 100);
    #|   $df.filter((col('city').starts-with('北')) & (col('amount') > 100));
    multi method filter(Duckula::Expr:D $pred --> Duckula::Frame) {
        self!check-columns($pred.columns, 'filter');
        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_filter "
                          ~ "WHERE {$pred.render}",
        );
    }

    #| 过滤行。SQL 片段版本，值必须走 `?` 绑定：
    #|
    #|   $df.filter('city = ?', $city);
    #|
    #| 片段里的列名是裸写的（这是受信代码入口），但值和语句边界仍然受网关保护：
    #| 不许夹带多条语句，`?` 个数必须与实参一致。
    multi method filter(Str:D $pred, *@args --> Duckula::Frame) {
        check-fragment($pred, :params(@args.elems));
        my Str $p = @args.elems ?? render-bindings($pred, @args) !! $pred;
        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_filter "
                          ~ "WHERE $p",
        );
    }

    #| 新增（或覆盖）一列：
    #|
    #|   $df.with-column((col('amount') * 1.1).alias('amount_taxed'));
    #|   $df.with-column(col('city').upper, :name<city_up>);
    #|   $df.with-column(col('amount').sum.over('dept').alias('dept_total'));
    #|
    #| 三种输入各走一条路：
    #|   - 窗口表达式（`.over` / `.cum-sum` / `.rank` …）：原样拼上；
    #|   - 裸聚合（`col('x').sum`）：补 `OVER ()` 变成逐行广播 —— 这是 Polars
    #|     `with_columns(pl.col('x').sum())` 的语义，也是 pandas
    #|     `df['t'] = df['x'].sum()` 的语义。不补的话 DuckDB 会按全表聚合处理，
    #|     整个 frame 当场塌成一行；
    #|   - 聚合混在算术里（`sum(x) / count(*)`）：补不了 OVER，因为 OVER 只能
    #|     跟在一个函数调用后面，所以直接报错并告诉用户怎么写。
    multi method with-column(Duckula::Expr:D $e, Str :$name --> Duckula::Frame) {
        my $raw = $name // $e.as;
        die Duckula::X::Frame.new(
            reason => 'with-column needs an alias: '
                    ~ 'use .alias("name") on the expression or pass :name<name>'
        ) unless $raw.defined && $raw.Str ne '';
        my Str $n = $raw.Str;

        self!check-columns($e.columns, 'with-column');

        my Str $expr = $e.render;

        if $e.window.defined {
            # 已经是窗口函数，自带 OVER (…)，不用再动。
        } elsif $e.bare-agg {
            $expr ~= ' OVER ()';
        } elsif $e.is-aggregate {
            die Duckula::X::Frame.new(
                reason => "with-column can't use an aggregate inside a larger "
                        ~ "expression ('$expr'); put .over() on each aggregate, "
                        ~ "e.g. (col('x').sum.over / len().over)"
            );
        }

        # 覆盖已有列时必须先把它 EXCLUDE 掉。`SELECT *, expr AS "v"` 会产出
        # 两个同名的 v，之后 `$df.column('v')` 只拿得到第一个（旧值），
        # 而 gist 里看起来"新值好像生效了"—— 这种静默错最难查。
        my Set $known = self.names.Set;
        my Str $head = ($n ∈ $known)
            ?? 'SELECT * EXCLUDE (' ~ quote-ident($n) ~ '), '
            !! 'SELECT *, ';

        my Str $rn = '';
        my Str $src;

        if $e.window.defined {
            # 窗口算子会**改变输出行序**：`rank() OVER (ORDER BY v DESC)` 之后
            # DuckDB 直接按 v 降序吐行，`sum() OVER (PARTITION BY g)` 之后按组
            # 聚拢。这违反了 with-column「只加一列、别动别的」的约定（五个
            # 测试用例全挂在这上面）。所以先在内层给每行钉一个扫描序行号，
            # 外层算完窗口再按它排回去。
            $rn = '__duckula_ord';
            $rn ~= '_' while $rn ∈ $known;
            $src = 'FROM (SELECT *, row_number() OVER () AS ' ~ quote-ident($rn)
                 ~ " FROM ({$!relation-sql}) AS __duckula_win_src) AS __duckula_win";
        } else {
            $src = "FROM ({$!relation-sql}) AS __duckula_with";
        }

        my Str $sql = $head ~ $expr ~ ' AS ' ~ quote-ident($n) ~ ' ' ~ $src;

        if $e.window.defined {
            $sql = 'SELECT * EXCLUDE (' ~ quote-ident($rn) ~ ') FROM (' ~ $sql
                 ~ ') AS __duckula_win_out ORDER BY ' ~ quote-ident($rn);
        }

        Duckula::Frame.new(:$!session, relation-sql => $sql);
    }

    #| 一次加多列，等价于连续调用 `with-column`（Polars 的 `with_columns`）。
    #|
    #|   $df.with-columns(
    #|       col('amount').sum.over('dept').alias('dept_total'),
    #|       (col('amount') / col('dept_total')).alias('share'),
    #|   );
    #|
    #| 后一个表达式能看到前一个刚加的列 —— 因为每一步都是「新的 SELECT 套在
    #| 上一层外面」，不是同时投影。
    multi method with-columns(*@exprs --> Duckula::Frame) {
        my @flat = @exprs.elems == 1 && @exprs[0] ~~ Positional
            ?? @exprs[0].List
            !! @exprs.List;

        my $f = self;
        for @flat -> $e {
            $f = $f.with-column($e);
        }
        $f;
    }

    #| 按列分组，返回中间对象，必须接 `.agg(...)` 或 `.count`：
    #|
    #|   $df.group-by('city').agg(col('amount').sum.alias('total'));
    #|   $df.group-by('city', 'country').agg(len().alias('n'));
    #|   $df.group-by(col('city').upper.alias('city_up')).agg(col('amount').max);
    #|
    #| 列名（含表达式里引用到的列）一律过白名单，拼错当场报错。
    multi method group-by(*@keys --> Duckula::GroupBy) {
        my @flat = @keys.elems == 1 && @keys[0] ~~ Positional
            ?? @keys[0].List
            !! @keys.List;

        my @exprs = @flat.map(-> $k {
            $k ~~ Duckula::Expr ?? $k !! col($k.Str);
        });

        for @exprs -> Duckula::Expr $e {
            self!check-columns($e.columns, 'group-by');
        }

        Duckula::GroupBy.new(frame => self, keys => @exprs);
    }

    #| 全表聚合，不分组：
    #|
    #|   $df.agg(len().alias('n'), col('amount').sum.alias('total'));
    #|
    #| 内部就是「零个分组键的 group-by」，所以两种写法的语义完全一致。
    method agg(*@aggs --> Duckula::Frame) {
        Duckula::GroupBy.new(frame => self, keys => ()).agg(|@aggs);
    }

    #| 和另一张表连接，返回新 Frame（仍然只是 SQL）。
    #|
    #|   $orders.join($depts, on => 'dept_id');                  # 同名键
    #|   $orders.join($depts, on => <dept_id region>);           # 多个同名键
    #|   $orders.join($depts, on => 'dept_id' => 'did');         # 异名键（Pair）
    #|   $orders.join($depts, on => 'dept_id', :how<left>);
    #|   $orders.join($depts, on => 'dept_id', :how<anti>);
    #|   $orders.join($depts, :how<cross>);                      # 笛卡尔积
    #|
    #| `:how` 取 inner（默认）/ left / right / full（同 outer）/ semi / anti /
    #| cross。semi / anti 只输出左表的列。
    #|
    #| 列名冲突时右侧列自动加 `:suffix`（默认 `_right`），且只在真的撞名时加。
    #| 连接键的右侧列不重复输出（和 SQL 的 `USING` 语义一致）。
    multi method join(
        Duckula::Frame:D $right,
        :$on,
        Str :$how = 'inner',
        Str :$suffix = '_right',
        --> Duckula::Frame
    ) {
        join-frames(self, $right, :$on, :$how, :$suffix);
    }

    #| 按某列排序。列名过 quote-ident + 白名单。
    multi method sort-values(Str:D $column, Bool :$desc = False --> Duckula::Frame) {
        my Set $known = self.names.Set;
        die Duckula::X::Frame.new(
            reason => "no column named '$column'; available: {self.names.join(', ')}"
        ) unless $known{$column};

        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_sort "
                          ~ "ORDER BY {quote-ident($column)}" ~ ($desc ?? ' DESC' !! ''),
        );
    }

    # ---------------------------------------------------------------- 清洗与重塑

    #| 纵向拼接若干 Frame（pandas 的 `pd.concat` / Polars 的 `pl.concat`）。
    #|
    #|   $a.concat($b);
    #|   $a.concat($b, $c);
    #|   $a.concat($b, :strict);   # 列名必须完全一致
    #|
    #| 列按**名字**对齐（`UNION ALL BY NAME`）：缺的列补 NULL，列序沿用第一个
    #| Frame 再追加后面新出现的列。这正是 pandas `concat` 的默认行为，等价于
    #| Polars 的 `how="diagonal"`；`:strict` 对应 Polars 的 `how="vertical"`。
    #|
    #| 只认同会话的 Frame 拼接：跨会话拼出来的 SQL 会在错误的连接上执行，
    #| 结果要么报错要么含糊，不如在这里拦住。
    multi method concat(*@others, Bool :$strict = False --> Duckula::Frame) {
        my @flat = flatten-args(@others);
        die Duckula::X::Frame.new(
            reason => 'concat needs at least one other frame'
        ) unless @flat.elems;

        my @frames;
        @frames.push: self;

        for @flat -> $f {
            die Duckula::X::Frame.new(
                reason => 'concat expects Frames, got ' ~ $f.^name
            ) unless $f ~~ Duckula::Frame;
            die Duckula::X::Frame.new(
                reason => 'concat: every frame must belong to the same session'
            ) unless $f.session === $!session;
            @frames.push: $f;
        }

        if $strict {
            my @sets = @frames.map({ $_.names.List });
            check-same-columns(@sets, 'concat(:strict)');
        }

        Duckula::Frame.new(
            :$!session,
            relation-sql => concat-sql(@frames.map(*.relation-sql).List),
        );
    }

    #| 去重（pandas 的 `drop_duplicates` / Polars 的 `unique`）。
    #|
    #|   $df.unique;                          # 整行相同才算重复
    #|   $df.unique('city');                  # 按 city 去重
    #|   $df.unique(<city dept>, :keep<last>);
    #|   $df.unique('city', :keep<none>);     # 只留 city 出现一次的行
    #|   $df.unique('city', :keep<any>);      # 最省，但不保证行序
    #|
    #| `first` / `last` / `none` 都**保持输入行序**：SQL 没有天然行序，所以
    #| 先钉扫描序行号、去重后再按它排回来（`Duckula::Clean::unique-sql`）。
    multi method unique(*@subset, Str :$keep = 'first' --> Duckula::Frame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'unique');

        Duckula::Frame.new(
            :$!session,
            relation-sql => unique-sql($!relation-sql, @cols, $keep, @names),
        );
    }

    #| 单列频次表（pandas 的 `value_counts`）。
    #|
    #|   $df.value-counts('city');
    #|   # city | count
    #|   # 北京 | 3
    #|   # 上海 | 2
    #|
    #| `:normalize` 再加一列 `proportion`（占比，分母是**非空**行数，同 pandas）；
    #| `:keep-nulls` 让 NULL 也成为一个分组（默认丢，同 pandas）；`:sort(False)`
    #| 关掉按计数降序。
    method value-counts(
        Str:D $column,
        Bool :$sort = True,
        Bool :$normalize = False,
        Bool :$keep-nulls = False,
        --> Duckula::Frame
    ) {
        Duckula::Frame.new(
            :$!session,
            relation-sql => value-counts-sql(
                $!relation-sql, $column, self.names,
                :$sort, :$normalize, :$keep-nulls,
            ),
        );
    }

    #| 改列名（pandas 的 `rename` / Polars 的 `rename`）。
    #|
    #|   $df.rename('amount' => '金额');
    #|   $df.rename('a' => 'b', 'b' => 'c');      # 一次调用里可链式换名
    #|   $df.rename(%( a => 'b' ));
    #|   $df.rename('nope' => 'x', :!strict);     # 忽略陌生列名
    #|
    #| 未改名的列原样保留。新名撞上「没被换走的已有列」直接报错 —— 否则会
    #| 产出两列同名，之后按名取值只拿得到前一个。
    multi method rename(*@maps, Bool :$strict = True --> Duckula::Frame) {
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        my @items = rename-items(self.names, $map, :$strict);
        Duckula::Frame.new(
            :$!session,
            relation-sql => 'SELECT ' ~ @items.join(', ')
                          ~ " FROM ({$!relation-sql}) AS __duckula_rename",
        );
    }

    #| 删列（pandas 的 `drop(columns=…)` / Polars 的 `drop`）。
    #|
    #|   $df.drop('tmp');
    #|   $df.drop(<tmp raw>);
    #|
    #| 想把列删光会报错 —— 零列的 Frame 之后什么都做不了，这通常是笔误。
    multi method drop(*@cols --> Duckula::Frame) {
        my @items = drop-items(self.names, flatten-args(@cols));
        Duckula::Frame.new(
            :$!session,
            relation-sql => 'SELECT ' ~ @items.join(', ')
                          ~ " FROM ({$!relation-sql}) AS __duckula_drop",
        );
    }

    #| 删掉含空值的行（pandas 的 `dropna` / Polars 的 `drop_nulls`）。
    #|
    #|   $df.drop-nulls;                        # 任一列为空就丢
    #|   $df.drop-nulls(<city amount>);         # 只看这两列
    #|   $df.drop-nulls(:how<all>);             # 所有列都空才丢
    multi method drop-nulls(*@subset, Str :$how = 'any' --> Duckula::Frame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'drop-nulls');

        Duckula::Frame.new(
            :$!session,
            relation-sql => "SELECT * FROM ({$!relation-sql}) AS __duckula_nn "
                          ~ 'WHERE ' ~ null-predicate(@cols, $how),
        );
    }

    #| 填空值（pandas 的 `fillna` / Polars 的 `fill_null` / `fill_nan`）。
    #|
    #|   $df.fill-nulls(:value(0));                     # 全部列填 0
    #|   $df.fill-nulls('amount', :value(0));
    #|   $df.fill-nulls('amount', :strategy<mean>);     # 用均值填
    #|   $df.fill-nulls('amount', :strategy<ffill>);    # 用上一个非空值填
    #|   $df.fill-nulls('amount', :strategy<bfill>);    # 用下一个非空值填
    #|
    #| `:value` 与 `:strategy` 只能给一个。策略里 `mean` / `median` 是整列聚合，
    #| 与行序无关；`ffill` / `bfill` 需要行序，会先钉一个扫描序行号、填完再按
    #| 它排回去 —— 所以「上一个」指的是**当前 Frame 的行序**，和 Polars 一样。
    #|
    #| 有类型问题时让 DuckDB 报错：`mean` 填 VARCHAR 列、`:value` 与列类型不相容
    #| 都会失败，这里不替它猜 —— 但要注意 Frame 是惰性的，错误会在物化
    #| （`gist` / `rows` / `collect`）时才出现。因此**整帧填同一个值只在列类型
    #| 相容时成立**：`fill-nulls(:value(0))` 碰上 VARCHAR 列会被拒绝，混合类型
    #| 请指定列子集。
    multi method fill-nulls(*@subset, :$value, Str :$strategy --> Duckula::Frame) {
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'fill-nulls');

        my Str $mode = fill-mode(:$value, :$strategy);
        my Bool $win = needs-seq($mode);
        my Str $seq = $win ?? private-name(@names, '__duckula_seq') !! '';

        my @items = fill-items(@cols, $mode, :$value, :$seq);

        # `* EXCLUDE (cols)` 把那几列剔掉、再由 items 用新表达式补回来。
        # 子集等于全部列时 EXCLUDE 会把 `*` 清空，只剩 items —— 合法，但这里
        # 仍照写，为的是让两条路径（有锚 / 无锚）共用同一段投影。
        my Str $proj = 'SELECT * EXCLUDE (' ~ quoted-list(@cols) ~ '), '
                     ~ @items.join(', ');

        my Str $src = $win
            ?? '(SELECT *, row_number() OVER () AS ' ~ quote-ident($seq)
             ~ " FROM ({$!relation-sql}) AS __duckula_fill_src) AS __duckula_fill_w"
            !! "({$!relation-sql}) AS __duckula_fill";

        my Str $sql = $proj ~ ' FROM ' ~ $src;

        # 带 ORDER BY 的窗口可能改变输出行序（§8.9 记过），所以外面再按行号
        # 排回去，顺手把辅助列剔掉。
        if $win {
            $sql = 'SELECT * EXCLUDE (' ~ quote-ident($seq) ~ ') FROM (' ~ $sql
                 ~ ') AS __duckula_fill_out ORDER BY ' ~ quote-ident($seq);
        }

        Duckula::Frame.new(:$!session, relation-sql => $sql);
    }

    #| 改列类型（pandas 的 `astype` / Polars 的 `cast`）。
    #|
    #|   $df.cast(%( id => 'VARCHAR', amount => 'DECIMAL(18,4)' ));
    #|   $df.cast('id' => 'BIGINT');
    #|
    #| 没提到的列原样保留。类型名过白名单（见 `Duckula::Clean::check-type-name`）：
    #| `CAST(x AS ...)` 里的类型不能参数绑定，只能拼文本，所以必须校验。
    #| 表达式级的转换用 `col('x').cast('BIGINT')`。
    multi method cast(*@maps --> Duckula::Frame) {
        my @names = self.names;
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        my @pairs = as-pairs($map, 'cast');

        die Duckula::X::Frame.new(reason => 'cast needs at least one column')
            unless @pairs.elems;

        my %type-of;
        for @pairs -> $p {
            my Str $c = $p.key.Str;
            need-cols(($c,), @names, 'cast');
            %type-of{$c} = check-type-name($p.value.Str);
        }

        my @items = @names.map(-> $c {
            %type-of{$c}:exists
                ?? 'CAST(' ~ quote-ident($c) ~ ' AS ' ~ %type-of{$c} ~ ') AS '
                 ~ quote-ident($c)
                !! quote-ident($c) ~ ' AS ' ~ quote-ident($c);
        });

        Duckula::Frame.new(
            :$!session,
            relation-sql => 'SELECT ' ~ @items.join(', ')
                          ~ " FROM ({$!relation-sql}) AS __duckula_cast",
        );
    }

    #| 展开列表列（pandas / Polars 的 `explode`）。
    #|
    #|   $df.explode('tags');
    #|   $df.explode(<x y>);              # 多列按位置展开，长度不齐补 NULL
    #|   $df.explode('tags', :!keep-empty);  # 空列表/NULL 不产生行（DuckDB 原生行为）
    #|
    #| 默认把空列表与 NULL 各替换成 `[NULL]` 再展开，保留一行 NULL —— 与
    #| pandas / Polars 一致。展开列保持原名，之后还能继续 filter / select。
    multi method explode(*@cols, Bool :$keep-empty = True --> Duckula::Frame) {
        my @names = self.names;
        my @items = explode-items(@names, flatten-args(@cols), :$keep-empty);

        Duckula::Frame.new(
            :$!session,
            relation-sql => project-sql($!relation-sql, @items, '__duckula_ex'),
        );
    }

    #| 宽表转长表（pandas 的 `melt` / Polars 的 `unpivot`）。
    #|
    #|   $df.unpivot(<q1 q2>, :index<id>);
    #|   #   id | variable | value
    #|   $df.unpivot('q1', :index<id>, :variable-name<quarter>, :value-name<amount>);
    #|
    #| `on` 是要展开的值列，`index` 是保持不动的锚列。新列名撞上已有列时
    #| 自动加下划线（和辅助列同一套规则），不会静默覆盖。
    multi method unpivot(*@on, :$index, Str :$variable-name = 'variable',
                         Str :$value-name = 'value' --> Duckula::Frame) {
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @uncols = flatten-args(@on);
        @uncols = @names.grep({ !@idx.Set{$_} }) unless @uncols.elems;
        check-unpivot-columns(@uncols, @idx, @names);

        my Str $var = private-name(@names, $variable-name);
        my Str $val = private-name(@names, $value-name);

        Duckula::Frame.new(
            :$!session,
            relation-sql => unpivot-sql($!relation-sql, @uncols, @idx, $var, $val),
        );
    }

    #| 长表转宽表（pandas 的 `pivot_table` / Polars 的 `pivot`）。
    #|
    #|   $df.pivot(:on<quarter>, :index<id>, :values<amount>);
    #|   #   id | q1  | q2
    #|   $df.pivot(:on<quarter>, :index<id>, :values<amount>, :agg<count>);
    #|
    #| `on` 的取值决定输出列名，所以调用时要跑一次 `SELECT DISTINCT on`
    #| 拿分组值（这是唯一一个建算子时就读数据的动词，eager/lazy 都如此）。
    #| 聚合函数走白名单，见 `Duckula::Reshape::check-agg`。
    #|
    #| 为什么不用 DuckDB 原生 PIVOT：它被语句分类器判成 MULTI，过不了只读
    #| 守卫；条件聚合达到同样效果，列名还可控（§8.17）。
    method pivot(
        Str:D :$on!,
        :$index,
        :$values,
        Str :$agg = 'sum',
        Bool :$keep-nulls = False,
        --> Duckula::Frame
    ) {
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @vls = $values.defined ?? flatten-args(($values,)) !! ();
        need-cols(($on,), @names, 'pivot');
        need-cols(@idx, @names, 'pivot');

        my @vals = @vls.elems
            ?? @vls
            !! @names.grep({ $_ ne $on && !@idx.Set{$_} }).List;
        need-cols(@vals, @names, 'pivot');
        die Duckula::X::Frame.new(reason => 'pivot: nothing left to aggregate')
            unless @vals.elems;

        my Str $a = check-agg($agg);
        my @keys = pivot-keys($!session.conn, $!relation-sql, $on,
                              (), :$keep-nulls);

        Duckula::Frame.new(
            :$!session,
            relation-sql => pivot-sql($!relation-sql, $on, @idx, @vals,
                                      @keys, $a, :$keep-nulls),
        );
    }

    #| 采样（pandas 的 `sample` / Polars 的 `sample`）。
    #|
    #|   $df.sample(:n(2));                    # 取 2 行（无放回）
    #|   $df.sample(:frac(0.5));               # 每行 50% 概率
    #|   $df.sample(:n(2), :seed(42));         # 可复现
    #|
    #| `n` 走 `RESERVOIR`、`frac` 走 `BERNOULLI`，两者只能给一个。种子走
    #| `REPEATABLE`，同一输入同一种子必得同一批行。
    method sample(Int :$n, :$frac, Int :$seed --> Duckula::Frame) {
        Duckula::Frame.new(
            :$!session,
            relation-sql => sample-sql($!relation-sql, :$n, :$frac, :$seed),
        );
    }

    #| 每列一行的数据概览（DuckDB 的 `SUMMARIZE`）。
    #|
    #| 输出固定 12 列：`column_name` / `column_type` / `min` / `max` /
    #| `approx_unique` / `avg` / `std` / `q25` / `q50` / `q75` / `count` /
    #| `null_percentage`。非数值列的统计量是 NULL（DuckDB 的行为）。
    #|
    #| 和 pandas `describe` 的差别：这里是「每列一行」，pandas 是「每个统计量
    #| 一行」；这里还多出类型、近似唯一值数和空值率 —— 信息量更大。
    method describe(--> Duckula::Frame) {
        Duckula::Frame.new(
            :$!session,
            relation-sql => describe-sql($!relation-sql),
        );
    }

    #| pandas 风格的取列，但用的是 Raku 的 `{}` 而不是 `[]`：
    #|
    #|   $df{'amount'}          -> Series
    #|   $df<amount>            -> 同上
    #|   $df{'city', 'amount'}  -> 两个 Series 的 List（Raku 多值下标语义）
    #|   $df[0]                 -> 第 0 列的 Series（按位置）
    #|
    #| **为什么不是 `$df["amount"]`**：Raku 的 `[ ]` 把下标当位置索引，
    #| 传字符串会先被强转成 Int 而失败（实测 `Cannot convert string to number`）。
    #| 这不是 Duckula 的选择，是语言的 postcircumfix 语义。
    multi method AT-KEY(Str:D $name --> Duckula::Series) {
        self.column($name);
    }

    multi method AT-POS(Int:D $i --> Duckula::Series) {
        my List $names = self.names;
        die Duckula::X::Frame.new(
            reason => "column index $i out of range 0..{$names.elems - 1}"
        ) unless 0 <= $i < $names.elems;
        self.column($names[$i]);
    }

    method gist(--> Str) {
        self!materialize;

        my @cols = @!names;
        return '(empty frame)' unless @cols.elems;

        my @cells = @!rows.map(-> @r { @r.map({ $_.defined ?? $_.Str !! 'NULL' }) });
        my @width = @cols.map({ $_.chars });
        for @cells -> @r {
            for ^@cols.elems -> $i {
                my $w = (@r[$i] // '').chars;
                @width[$i] = $w if $w > @width[$i];
            }
        }

        my Str $out = '';
        $out ~= (@cols Z @width).map({ .[0].fmt("%-{.[1]}s") }).join(' | ') ~ "\n";
        $out ~= (@width.map({ '-' x $_ })).join('-+-') ~ "\n";
        for @cells -> @r {
            $out ~= (@r Z @width).map({ (.[0] // '').fmt("%-{.[1]}s") }).join(' | ') ~ "\n";
        }
        $out;
    }
}
