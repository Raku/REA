use v6.d;
use NativeCall;
use DB::DuckDB::Arrow;

#| Arrow IPC：把 `Schema` + `Chunk` 直接写成 Arrow IPC 字节流（.arrow / .feather v2）。
#|
#| 为什么自己写：`COPY ... TO ... (FORMAT ARROW)` 要 DuckDB 的 `arrow` 扩展，
#| 而该扩展只发布在标准平台，本机这种 `windows_amd64_mingw` 构建在核心仓和
#| 社区仓都是 404。但 Arrow IPC 的文件格式是完全公开的：一段段
#| 「continuation + metadata(FlatBuffers) + body」而已，DuckDB 的 C API 已经
#| 把 schema（格式串）、buffers（裸指针）、长度都交到手里了，缺的只是把
#| 这些字段序列化成 FlatBuffers 这一层。
#|
#| 于是这里手写一个最小 FlatBuffers 构造器（只支持本项目用得到的 table /
#| struct / vector / string / union），再按 Arrow 的 Message.fbs / Schema.fbs /
#| File.fbs 摆布局。产物用 pyarrow `ipc.open_file` / `ipc.open_stream` 验证。
#|
#| 只做写：读别人的 Arrow 文件走 DuckDB 的 `read_parquet` 或后续的 reader。
#| 字节布局对齐是这里最容易错的地方，注释里逐条标了为什么。
unit module Duckula::ArrowIPC;

# ============================================================
# 小端字节序的原子写入
# ============================================================

#| 把 `$v` 按 `$n` 字节小端展开。负值先截到 2^(8n) 再取位，避免无限符号位。
sub le-bytes(Int $v, Int $n --> Buf) {
    my $mask = (1 +< (8 * $n)) - 1;
    my $u = $v +& $mask;
    my @b;
    for ^$n -> int $i { @b.push: ($u +> (8 * $i)) +& 0xFF }
    Buf.new(@b);
}

# 名字拼起来是为了躲开 zef / raku-pm 对 `is native('<字面量>')` 的依赖扫描，
# 与 DB::DuckDB 里同样的理由（Windows 会去找一个不存在的 libc）。
my constant CLIB = $*DISTRO.is-win ?? 'msvc' ~ 'rt' !! 'libc' ~ '.so.6';

sub c-memcpy(Pointer $dst, Pointer $src, size_t $n --> Pointer)
    is native(CLIB) is symbol('memcpy') { }

# ============================================================
# 最小 FlatBuffers 构造器
# ============================================================
#
# FlatBuffers 规定所有标量相对「缓冲区起点」对齐，而构造器是**从后往前**写的。
# 于是每个字段写入时保证的是「距末尾的偏移」对齐；最后 `finish` 在**前面**补
# 零，让总长是 min-align 的倍数，这样 (L - e) 就一定落在对齐地址上。
#
#   地址 = 起点 + (总长 L - 距末尾偏移 e)
#
# L % m == 0 且 e % align == 0（align | m）=> 地址 % align == 0。
#| 一张正在构建的 table：起点 + 各字段位置。
#|
#| `slots` 用标量持有 Array —— `@`-sigil 属性收 Array 会 itemize 一层。
class TblState {
    has Int $.start = 0;
    has $.slots;

    submethod BUILD(Int :$start!, Int :$n!) {
        $!start = $start;
        $!slots = (0 xx $n).Array;
    }
}

class FlatBuf {
    has Buf $!b;
    has Int $!head;              # 已用区间的起点（可写区间的末尾）
    has Int $!min-align = 1;
    has @!tables;                # 嵌套 table 的栈：{ start, slots }

    submethod BUILD(Int :$cap = 4096) {
        $!b = Buf.new(0 xx $cap);
        $!head = $cap;
    }

    #| 已写入的字节数。
    method size(--> Int) { $!b.elems - $!head }

    method !grow(Int $need --> Nil) {
        my Int $used = self.size;
        return if $!head >= $need;
        my Int $cap = $!b.elems;
        $cap = $cap * 2 while $cap - $used < $need;
        my $nb = Buf.new(0 xx $cap);
        my Int $dst = $cap - $used;
        for ^$used -> int $i { $nb[$dst + $i] = $!b[$!head + $i] }
        $!b = $nb;
        $!head = $dst;
    }

    method !raw(Buf $bytes --> Nil) {
        my Int $n = $bytes.elems;
        return unless $n;
        self!grow($n);
        $!head -= $n;
        for ^$n -> int $i { $!b[$!head + $i] = $bytes[$i] }
    }

    #| 在数据前面补零（物理上位于已写内容的更低位地址）。
    method pad(Int $n --> Nil) {
        self!raw(Buf.new(0 xx $n)) if $n > 0;
    }

    #| 把已写长度补到 `$a` 的倍数，同时抬高整体对齐要求。
    method align(Int $a --> Nil) {
        $!min-align = $a if $a > $!min-align;
        self.pad((-(self.size)) % $a);
    }

    method prepend-i8(Int $v --> Nil)  { self!raw(le-bytes($v, 1)) }
    method prepend-i16(Int $v --> Nil) { self.align(2); self!raw(le-bytes($v, 2)) }
    method prepend-i32(Int $v --> Nil) { self.align(4); self!raw(le-bytes($v, 4)) }
    method prepend-i64(Int $v --> Nil) { self.align(8); self!raw(le-bytes($v, 8)) }

    #| 写一个指向 `$target`（距末尾偏移）的 uoffset 引用。
    #|
    #| 值本身也是「距末尾」的：`size - target + 4`，其中 size 取对齐之后的，
    #| 这与官方 builder 的 `ReferTo` 完全一致。
    method prepend-uoffset(Int $target --> Nil) {
        self.align(4);
        my Int $rel = self.size - $target + 4;
        self!raw(le-bytes($rel, 4));
    }

    #| 写 flatbuffers string：`[int32 长度][bytes][0x00]`。
    method prepend-string(Str $s --> Nil) {
        my Buf $bytes = Buf.new($s.encode('utf-8'));
        my Int $total = $bytes.elems + 1;
        # 让「载荷 + NUL」写完之后正好 4 对齐，长度前缀才落得下。
        self.pad((-(self.size + $total)) % 4);
        self!raw(Buf.new(0));
        self!raw($bytes);
        self!raw(le-bytes($bytes.elems, 4));
    }

    # ---- table ----

    method start-table(Int $nfields --> Nil) {
        @!tables.push: TblState.new(start => self.size, n => $nfields);
    }

    #| 记下「刚写完的那个字段」的位置。必须在写值之后调用。
    #|
    #| 字段表存在标量属性 `$.slots` 里而不是 `@.slots`：`@`-sigil 属性装
    #| Array 会被 itemize 一层，取出来就变成 `[[...]]`，vtable 只剩一个
    #| 字段 —— 报错会出现在很远的地方（pyarrow 说 footer 校验失败）。
    method slot(Int $id --> Nil) {
        @!tables[*-1].slots[$id] = self.size;
    }

    #| 收尾一张 table，返回它距末尾的偏移。
    #|
    #| vtable 里存的是「相对 table 起点」的字段偏移，soffset 存的是
    #| 「table 起点 - vtable 起点」，所以最后要回填那个 4 字节占位。
    method end-table(--> Int) {
        my TblState $t = @!tables.pop;
        my $slots = $t.slots;
        my Int $start = $t.start;

        self.align(4);
        my Int $p = self.size;
        self!raw(le-bytes(0, 4));            # soffset 占位
        my Int $table-off = $p + 4;

        # 尾部连续的空字段不必进 vtable（flatbuffers 的常规压缩）。
        my @kept;
        for ^$slots.elems -> int $i { @kept.push: $slots[$i]; }
        @kept.pop while @kept && @kept[*-1] == 0;

        self.align(2);
        for @kept.reverse -> $off {
            self!raw(le-bytes($off == 0 ?? 0 !! $table-off - $off, 2));
        }
        self!raw(le-bytes($table-off - $start, 2));    # table 大小
        self!raw(le-bytes(4 + 2 * @kept.elems, 2));    # vtable 大小
        my Int $vtable-off = self.size;

        # soffset = table 地址 - vtable 地址。vtable 写在 table 之后，
        # 所以它的「距末尾偏移」更大、实际地址更低，差值必须取这个方向。
        my Buf $patch = le-bytes($vtable-off - $table-off, 4);
        my Int $pos = $!b.elems - $table-off;
        for ^4 -> int $i { $!b[$pos + $i] = $patch[$i] }

        $table-off;
    }

    # ---- vector ----

    #| 开一个 vector。`$align` 是元素对齐，长度前缀固定要 4 对齐，
    #| 所以取两者中更严的那个 `$m`，一次补够。
    method start-vector(Int $n, Int $elemsize, Int $align --> Nil) {
        my Int $len = $n * $elemsize;
        my Int $m = $align > 4 ?? 8 !! 4;
        $!min-align = $m if $m > $!min-align;
        self.pad((-(self.size + $len)) % $m);
    }

    #| 写完元素后补上 int32 长度，返回 vector 头（长度前缀）的偏移。
    method end-vector(Int $n --> Int) {
        self!raw(le-bytes($n, 4));
        self.size;
    }

    # ---- finish ----

    #| 在前面补零到整体对齐，再写根 uoffset。返回完整字节。
    #|
    #| 结果长度一定是 8 的倍数（构造时至少 align(8) 过一次），
    #| 因此 Arrow IPC 里「metadata 补零到 8」这一步永远不需要额外动手。
    method finish(Int $root --> Buf) {
        my Int $m = $!min-align;
        self.pad((-(self.size + 4)) % $m);
        my Int $rel = self.size - $root + 4;
        self!raw(le-bytes($rel, 4));
        $!b.subbuf($!head, self.size);
    }
}

#| 只读的 ArrowArray 视图，给不是 `Chunk` 来的数组用（字典值就是这种）。
#|
#| 方法与 `DB::DuckDB::Arrow::Column` 同名同义，于是 `walk-node` 不需要
#| 知道自己拿到的是哪一种。
class ArrayView {
    has ArrowArray $.arr;

    method length(--> Int)     { $!arr.length }
    method null-count(--> Int) { $!arr.null-count }

    method buffer(int $j --> Pointer) {
        my $base = $!arr.buffers;
        return Pointer unless $base.defined && $base.Int;
        return Pointer if $j >= $!arr.n-buffers;
        nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $j))[0] // Pointer;
    }

    method children(--> List) {
        my $base = $!arr.children;
        return () unless $base.defined && $base.Int;
        my @kids;
        for ^$!arr.n-children -> int $i {
            my $p = nativecast(CArray[Pointer], Pointer.new($base.Int + 8 * $i))[0];
            @kids.push: ArrayView.new(arr => nativecast(ArrowArray, $p));
        }
        @kids.List;
    }
}

#| 一个 schema 节点的 `dictionary` 指针（没有就是空指针）。
sub dict-of($node --> Pointer) {
    my $root = nativecast(ArrowSchema, $node.addr);
    my $d = $root.dictionary;
    return Pointer unless $d.defined && $d.Int;
    $d;
}

#| 由裸指针包一个 `Schema` 节点（字典的值类型就是这么拿到的）。
sub schema-node-of(Pointer $p) {
    Schema.new(root => nativecast(ArrowSchema, $p), addr => $p);
}

#| 找出 schema 里所有字典列，按深度优先编号。
#|
#| 编号必须与 DictionaryBatch 的发出顺序一致，否则 RecordBatch 里的
#| 索引会指向别人的字典。
sub dict-scan($schema --> List) {
    my @out;
    my sub walk($node, @path --> Nil) {
        my $d = dict-of($node);
        if $d.defined && $d.Int {
            @out.push: %( id => @out.elems, path => @path.List,
                          schema-addr => $d.Int, node-addr => $node.addr.Int,
                          format => schema-node-of($d).format );
        }
        for ^$node.n-children -> int $i {
            walk($node.column($i), (|@path, $i));
        }
        Nil;
    }
    walk($schema, ());
    @out.List;
}

#| 顺着路径走进一个 chunk，拿到那一列的 ArrowArray。
sub array-at($chunk, @path --> ArrowArray) {
    my $arr = nativecast(ArrowArray, $chunk.addr);
    for @path -> $k {
        my $kids = nativecast(CArray[Pointer], $arr.children);
        $arr = nativecast(ArrowArray, $kids[$k]);
    }
    $arr;
}

# ============================================================
# Arrow format 字符串 -> Type union 标签
# ============================================================
#
# 标签顺序就是 Schema.fbs 里 `union Type` 的声明顺序，改不得。

my constant %INT-CODES = (
    'c' => (8,  True),  'C' => (8,  False),
    's' => (16, True),  'S' => (16, False),
    'i' => (32, True),  'I' => (32, False),
    'l' => (64, True),  'L' => (64, False),
);
my constant %FLOAT-CODES = ('e' => 0, 'f' => 1, 'g' => 2);
my constant %TIME-UNIT   = ('s' => 0, 'm' => 1, 'u' => 2, 'n' => 3);

#| 把一个 Arrow format 字符串解析成构造 Type table 需要的全部信息。
#|
#| `kind` 决定 body 里怎么算 buffer 长度，`tag` 决定 Message 里写哪种 Type。
#| 读侧（`Duckula::ArrowRead`）反着用同一个函数：从 FlatBuffers 的 Type
#| union 拼出 format 字符串，再交给它统一成同一套 `kind` 词汇。
our sub parse-format(Str:D $f --> Hash) {
    return %(tag => 1, kind => 'null')                    if $f eq 'n';
    return %(tag => 6, kind => 'bool')                    if $f eq 'b';
    return %(tag => 5, kind => 'utf8', width => 4)        if $f eq 'u';
    return %(tag => 20, kind => 'utf8', width => 8)       if $f eq 'U';
    return %(tag => 4, kind => 'binary', width => 4)      if $f eq 'z';
    return %(tag => 19, kind => 'binary', width => 8)     if $f eq 'Z';
    return %(tag => 13, kind => 'struct')                 if $f eq '+s';
    return %(tag => 12, kind => 'list', width => 4)       if $f eq '+l';
    return %(tag => 21, kind => 'list', width => 8)       if $f eq '+L';
    return %(tag => 17, kind => 'map', width => 4)        if $f eq '+m';

    if %INT-CODES{$f} -> ($bw, $sgn) {
        return %(tag => 2, kind => 'fixed', bitwidth => $bw,
                 signed => $sgn, bytes => $bw div 8);
    }
    # 注意：HALF 的 precision 是 0，所以不能写 `if %FLOAT-CODES{$f} -> $p`
    # —— 那个 0 是假值，会把 'e' 漏进下面的 die。也不能写
    # `if %FLOAT-CODES{$f}.defined -> $p` —— 那绑定的是 defined 的返回值
    # （True），不是映射出来的 precision。
    my $prec = %FLOAT-CODES{$f};
    if $prec.defined {
        my Int $bytes = $prec == 0 ?? 2 !! ($prec == 1 ?? 4 !! 8);
        return %(tag => 3, kind => 'fixed', precision => $prec, bytes => $bytes);
    }

    return %(tag => 8, kind => 'fixed', unit => 0, bytes => 4) if $f eq 'tdD';
    return %(tag => 8, kind => 'fixed', unit => 1, bytes => 8) if $f eq 'tdm';

    if $f ~~ /^ 'tt' $<u>=<[smun]> $/ {
        my Str $u = ~$<u>;
        my Int $bw = ($u eq 's' || $u eq 'm') ?? 32 !! 64;
        return %(tag => 9, kind => 'fixed', unit => %TIME-UNIT{$u},
                 bitwidth => $bw, bytes => $bw div 8);
    }
    if $f ~~ /^ 'ts' $<u>=<[smun]> ':' $<tz>=.* $/ {
        my Str $u = ~$<u>;
        return %(tag => 10, kind => 'fixed', unit => %TIME-UNIT{$u},
                 timezone => ~$<tz>, bytes => 8);
    }
    if $f ~~ /^ 'tD' $<u>=<[smun]> $/ {
        return %(tag => 18, kind => 'fixed', unit => %TIME-UNIT{~$<u>}, bytes => 8);
    }
    return %(tag => 11, kind => 'fixed', unit => 0, bytes => 4)  if $f eq 'tiM';
    return %(tag => 11, kind => 'fixed', unit => 1, bytes => 8)  if $f eq 'tiD';
    return %(tag => 11, kind => 'fixed', unit => 2, bytes => 16) if $f eq 'tin';

    if $f ~~ /^ 'd:' $<p>=\d+ ',' $<s>=\d+ [ ',' $<bw>=\d+ ]? $/ {
        my Int $bw = $<bw>.defined ?? +$<bw> !! 128;
        return %(tag => 7, kind => 'fixed', precision => +$<p>, scale => +$<s>,
                 bitwidth => $bw, bytes => $bw div 8);
    }
    if $f ~~ /^ 'w:' $<n>=\d+ $/ {
        return %(tag => 15, kind => 'fixed', size => +$<n>, bytes => +$<n>);
    }

    die "arrow-ipc: unsupported Arrow format string '$f'";
}

# ============================================================
# Type / Field / Schema -> FlatBuffers
# ============================================================

#| 写一个 Type table，返回它的偏移。
#|
#| 空 table（Bool / Utf8 / List / Struct_ …）也真的写一张 0 字段的 table，
#| 因为 union 的值必须是一个有效指针。
sub build-type(FlatBuf $fb, %t --> Int) {
    my Int $tag = %t<tag>;

    if $tag == 2 {                                  # Int
        $fb.start-table(2);
        $fb.prepend-i8(%t<signed> ?? 1 !! 0); $fb.slot(1);
        $fb.prepend-i32(%t<bitwidth>);        $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 3 {                                  # FloatingPoint
        $fb.start-table(1);
        # precision 默认 0（HALF），所以 HALF 时不写
        if %t<precision> != 0 {
            $fb.prepend-i16(%t<precision>); $fb.slot(0);
        }
        return $fb.end-table;
    }
    if $tag == 7 {                                  # Decimal
        $fb.start-table(3);
        # bitWidth 默认 128，等于默认值时省略
        if %t<bitwidth> != 128 {
            $fb.prepend-i32(%t<bitwidth>); $fb.slot(2);
        }
        $fb.prepend-i32(%t<scale>);     $fb.slot(1);
        $fb.prepend-i32(%t<precision>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 8 {                                  # Date
        $fb.start-table(1);
        # Date.unit 的默认值是 MILLISECOND，不是 DAY —— 省略就等于
        # 声明 date64，于是 4 字节的 date32 会被当成 8 字节读，日期飞到几千年后。
        $fb.prepend-i16(%t<unit>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 9 {                                  # Time
        $fb.start-table(2);
        $fb.prepend-i32(%t<bitwidth>); $fb.slot(1);
        if %t<unit> != 0 { $fb.prepend-i16(%t<unit>); $fb.slot(0) }
        return $fb.end-table;
    }
    if $tag == 10 {                                 # Timestamp
        $fb.start-table(2);
        my Str $tz = %t<timezone> // '';
        if $tz.chars { $fb.prepend-string($tz); $fb.slot(1) }
        if %t<unit> != 0 { $fb.prepend-i16(%t<unit>); $fb.slot(0) }
        return $fb.end-table;
    }
    if $tag == 11 || $tag == 18 {                   # Interval / Duration
        $fb.start-table(1);
        if %t<unit> != 0 { $fb.prepend-i16(%t<unit>); $fb.slot(0) }
        return $fb.end-table;
    }
    if $tag == 15 {                                 # FixedSizeBinary
        $fb.start-table(1);
        $fb.prepend-i32(%t<size>); $fb.slot(0);
        return $fb.end-table;
    }
    if $tag == 17 {                                 # Map
        $fb.start-table(1);                         # keysSorted 默认 false
        return $fb.end-table;
    }
    die "arrow-ipc: unsupported Arrow type tag $tag" unless $tag == 1 || $tag == 4
        || $tag == 5 || $tag == 6 || $tag == 12 || $tag == 13 || $tag == 19
        || $tag == 20 || $tag == 21;

    $fb.start-table(0);                             # Null / Bool / Utf8 / …
    $fb.end-table;
}

#| 写一张 DictionaryEncoding，返回它的偏移。
#|
#| DuckDB 的 ENUM 在 C data interface 里表现为「索引数组 + dictionary 指针」：
#| 列本身的 format 是 `C`（uint8），值类型在 `dictionary` 指向的 schema 里。
#| 照着写出来，pyarrow 才会把它读成真正的字典类型而不是一堆数字。
sub build-dictionary-encoding(FlatBuf $fb, Int $id --> Int) {
    $fb.start-table(2);                     # Int { bitWidth, is_signed }
    $fb.prepend-i32(8); $fb.slot(0);        # is_signed 默认 false，省略
    my Int $index-type = $fb.end-table;

    $fb.start-table(4);
    $fb.prepend-uoffset($index-type); $fb.slot(1);
    $fb.prepend-i64($id);             $fb.slot(0);
    $fb.end-table;
}

#| 写一个 Field table（含递归子字段），返回它的偏移。
#|
#| `:$of` 用来告诉嵌套字段它们处在哪种父类型里：list 的元素名默认
#| `item`，map 的 entries 必须不可空且键不可空 —— 这两条 pyarrow 会校验。
sub build-field(FlatBuf $fb, %dict-info, $node, Str :$of = '', Bool :$nullable = True,
                Bool :$map-entries = False --> Int) {
    # 字典列要特别对待：Field.type 描述的是**值**的类型（比如 utf8），
    # 索引类型另有 DictionaryEncoding.indexType 说明。照列自己的 format（C）
    # 写，pyarrow 会认定字典值是 uint8，读出满屏数字。
    my $dinfo = %dict-info{$node.addr.Int};
    my $dict-id = $dinfo ?? $dinfo<id> !! Nil;
    my Str $fmt = $dinfo ?? $dinfo<format> !! $node.format;
    my %t = parse-format($fmt);

    my Str $name = $node.name;
    my Bool $null = $nullable;
    if $of eq 'map' {
        $name = 'entries' if $name eq '';
        $null = False;
    }
    elsif $of eq 'list' || $of eq 'large-list' {
        $name = 'item' if $name eq '';
    }

    # 子字段必须先写（从后往前写，子内容在前）
    my @child-offs;
    my Bool $is-map = %t<kind> eq 'map';
    for ^$node.n-children -> int $i {
        # Arrow 对 map 的布局要求很硬：唯一的子字段 entries 是不可空的
        # struct，而 entries 的第一个子字段（key）也必须不可空。少一条
        # pyarrow 就直接拒收：「Map's keys must be non-nullable」。
        my Bool $cn = True;
        $cn = False if $is-map;
        $cn = False if $map-entries && $i == 0;
        my $kid = $node.column($i);
        @child-offs.push: build-field($fb, %dict-info, $kid,
                                      of => %t<kind>,
                                      nullable => $cn,
                                      map-entries => $is-map);
    }
    my Int $type-off = build-type($fb, %t);
    my Int $dict-off = $dict-id.defined
        ?? build-dictionary-encoding($fb, $dict-id) !! 0;

    $fb.prepend-string($name);
    my Int $name-off = $fb.size;

    my Int $children-vec = 0;
    if @child-offs.elems {
        $fb.start-vector(@child-offs.elems, 4, 4);
        for @child-offs.reverse -> $o { $fb.prepend-uoffset($o) }
        $children-vec = $fb.end-vector(@child-offs.elems);
    }

    $fb.start-table(7);
    $fb.prepend-uoffset($name-off);  $fb.slot(0);
    if $null { $fb.prepend-i8(1); $fb.slot(1) }     # nullable 默认 false
    $fb.prepend-i8(%t<tag>); $fb.slot(2);           # type_type
    $fb.prepend-uoffset($type-off); $fb.slot(3);
    if $children-vec {
        $fb.prepend-uoffset($children-vec); $fb.slot(5);
    }
    if $dict-off {
        $fb.prepend-uoffset($dict-off); $fb.slot(4);
    }
    $fb.end-table;
}

#| 写一张 Schema table，返回它的偏移。
sub build-schema(FlatBuf $fb, $root, %dict-info --> Int) {
    my @field-offs;
    for ^$root.n-children -> int $i {
        my $node = $root.column($i);
        @field-offs.push: build-field($fb, %dict-info, $node);
    }
    my Int $vec = 0;
    if @field-offs.elems {
        $fb.start-vector(@field-offs.elems, 4, 4);
        for @field-offs.reverse -> $o { $fb.prepend-uoffset($o) }
        $vec = $fb.end-vector(@field-offs.elems);
    }

    $fb.start-table(4);
    # endianness 默认 Little(0)，不写
    if $vec { $fb.prepend-uoffset($vec); $fb.slot(1) }
    $fb.end-table;
}

# ============================================================
# 一条 IPC message 的 metadata
# ============================================================

my constant MSG-SCHEMA       = 1;
my constant MSG-RECORD-BATCH = 3;
my constant METADATA-V5      = 4;

#| Schema message（body 为空）。
sub schema-message($root-schema, %dict-info --> Buf) {
    my $fb = FlatBuf.new;
    $fb.align(8);                       # 保证产物长度是 8 的倍数
    my Int $schema-off = build-schema($fb, $root-schema, %dict-info);

    $fb.start-table(4);
    $fb.prepend-i16(METADATA-V5); $fb.slot(0);
    $fb.prepend-i8(MSG-SCHEMA);   $fb.slot(1);
    $fb.prepend-uoffset($schema-off); $fb.slot(2);
    my Int $msg = $fb.end-table;
    $fb.finish($msg);
}

#| 写一张 RecordBatch table，返回它的偏移。
sub build-record-batch(FlatBuf $fb, Int $length, @nodes, @buffers --> Int) {
    # struct FieldNode { int64 length; int64 null_count; }  —— 16 字节 / 对齐 8
    $fb.start-vector(@nodes.elems, 16, 8);
    for @nodes.reverse -> $nd {
        $fb.prepend-i64($nd[1]);
        $fb.prepend-i64($nd[0]);
    }
    my Int $nodes-vec = $fb.end-vector(@nodes.elems);

    # struct Buffer { int64 offset; int64 length; }
    $fb.start-vector(@buffers.elems, 16, 8);
    for @buffers.reverse -> $bf {
        $fb.prepend-i64($bf[1]);
        $fb.prepend-i64($bf[0]);
    }
    my Int $buffers-vec = $fb.end-vector(@buffers.elems);

    $fb.start-table(5);
    $fb.prepend-i64($length);          $fb.slot(0);
    $fb.prepend-uoffset($nodes-vec);   $fb.slot(1);
    $fb.prepend-uoffset($buffers-vec); $fb.slot(2);
    $fb.end-table;
}

#| RecordBatch message。`@nodes` 是 (长度, 空值数)，`@buffers` 是 (偏移, 长度)。
sub batch-message(Int $length, @nodes, @buffers, Int $body-len --> Buf) {
    my $fb = FlatBuf.new;
    $fb.align(8);
    my Int $batch = build-record-batch($fb, $length, @nodes, @buffers);

    $fb.start-table(4);
    $fb.prepend-i64($body-len);        $fb.slot(3);
    $fb.prepend-i16(METADATA-V5);      $fb.slot(0);
    $fb.prepend-i8(MSG-RECORD-BATCH);  $fb.slot(1);
    $fb.prepend-uoffset($batch);       $fb.slot(2);
    my Int $msg = $fb.end-table;
    $fb.finish($msg);
}

#| DictionaryBatch message：字典值本身也是一个 RecordBatch，只是挂在 `data` 上。
#|
#| 必须排在所有引用它的 RecordBatch **之前**，否则读到第一条批次时字典还没到。
sub dictionary-batch-message(Int $id, Int $length, @nodes, @buffers,
                             Int $body-len --> Buf) {
    my $fb = FlatBuf.new;
    $fb.align(8);
    my Int $batch = build-record-batch($fb, $length, @nodes, @buffers);

    $fb.start-table(3);
    $fb.prepend-i64($id);        $fb.slot(0);
    $fb.prepend-uoffset($batch); $fb.slot(1);
    my Int $db = $fb.end-table;

    $fb.start-table(4);
    $fb.prepend-i64($body-len);   $fb.slot(3);
    $fb.prepend-i16(METADATA-V5); $fb.slot(0);
    $fb.prepend-i8(2);            $fb.slot(1);   # MessageHeader.DictionaryBatch
    $fb.prepend-uoffset($db);     $fb.slot(2);
    my Int $msg = $fb.end-table;
    $fb.finish($msg);
}

#| Footer（file 格式才有）。
sub footer-message($root-schema, %dict-info, @dict-blocks, @blocks --> Buf) {
    my $fb = FlatBuf.new;
    $fb.align(8);

    my Int $schema-off = build-schema($fb, $root-schema, %dict-info);

    my Int $dict-vec = 0;
    if @dict-blocks.elems {
        $fb.start-vector(@dict-blocks.elems, 24, 8);
        for @dict-blocks.reverse -> $b {
            $fb.prepend-i64($b[2]); $fb.pad(4);
            $fb.prepend-i32($b[1]);
            $fb.prepend-i64($b[0]);
        }
        $dict-vec = $fb.end-vector(@dict-blocks.elems);
    }

    # struct Block { int64 offset; int32 metaDataLength; int64 bodyLength; }
    # 声明顺序 8 + 4 + (4 填充) + 8 = 24 字节，对齐 8。
    $fb.start-vector(@blocks.elems, 24, 8);
    for @blocks.reverse -> $b {
        $fb.prepend-i64($b[2]);        # bodyLength   @16
        $fb.pad(4);                    # 结构体内部的填充 @12
        $fb.prepend-i32($b[1]);        # metaDataLength @8
        $fb.prepend-i64($b[0]);        # offset       @0
    }
    my Int $blocks-vec = $fb.end-vector(@blocks.elems);

    $fb.start-table(5);
    $fb.prepend-i16(METADATA-V5);      $fb.slot(0);
    $fb.prepend-uoffset($schema-off);  $fb.slot(1);
    if $dict-vec {
        $fb.prepend-uoffset($dict-vec); $fb.slot(2);
    }
    if @blocks.elems {
        $fb.prepend-uoffset($blocks-vec); $fb.slot(3);
    }
    my Int $footer = $fb.end-table;
    $fb.finish($footer);
}

# ============================================================
# body：把每个 array 的 buffer 拷进一段连续内存
# ============================================================

class BodyAcc {
    has Buf $!data = Buf.new;
    has @!nodes;
    has @!descs;

    #| 记一个 FieldNode。
    method node(Int $length, Int $null-count --> Nil) {
        @!nodes.push: ($length, $null-count);
    }

    # ---- 就地改写（给 null 槽规范化用）----

    method byte-at(Int $pos --> Int) { $!data[$pos] }

    method zero-range(Int $off, Int $from, Int $to --> Nil) {
        for $from ..^ $to -> int $k { $!data[$off + $k] = 0 }
    }

    method zero-slots(Int $off, Int $w, $undef --> Nil) {
        for $undef.keys -> $i { self.zero-range($off, $i * $w, ($i + 1) * $w) }
    }

    method clear-bits(Int $off, $undef --> Nil) {
        for $undef.keys -> $i {
            my Int $b = $off + ($i div 8);
            $!data[$b] = $!data[$b] +& ~(1 +< ($i % 8));
        }
    }

    method write-offset(Int $off, Int $i, Int $v, Int $w --> Nil) {
        my Buf $b = le-bytes($v, $w);
        for ^$w -> int $k { $!data[$off + $i * $w + $k] = $b[$k] }
    }

    #| 追加一个 buffer（8 字节对齐），记下 (offset, length)，返回 offset。
    #|
    #| `:$bits` 给位图类 buffer（有效位、bool 数据）用：末尾那个字节里超出
    #| `$bits` 的高位在 Arrow 里是未定义的，DuckDB 会原样留着上一位的残留。
    #| 不清掉的话同一份数据两次写出的字节就不同 —— 内容合法但不可复现，
    #| 校验和、缓存、逐字节对比全都会失效。
    method add(Pointer $p, Int $len, Int :$bits --> Int) {
        while $!data.elems % 8 > 0 { $!data.push: 0 }
        my Int $off = $!data.elems;
        if $len > 0 && $p.defined && $p.Int {
            my $tmp = Buf.allocate($len);
            c-memcpy(nativecast(Pointer, $tmp), $p, $len);
            $!data.append($tmp);
        }
        if $bits.defined && $len > 0 {
            my Int $rem = $bits % 8;
            if $rem {
                my Int $last = $!data.elems - 1;
                $!data[$last] = $!data[$last] +& ((1 +< $rem) - 1);
            }
        }
        @!descs.push: ($off, $len);
        $off;
    }

    #| 补齐到 8 字节。IPC 要求每条 message 的 body 长度是 8 的倍数，
    #| 否则后面那条 message 的起点就歪了 —— 报的是「Unaligned block」。
    method padded(--> Buf) {
        my $out = Buf.new($!data);
        $out.push: 0 while $out.elems % 8;
        $out;
    }

    method nodes(--> List)   { @!nodes.List }
    method descs(--> List)   { @!descs.List }
    method bytes(--> Buf)    { $!data }
}

#| 读变长类型 offsets 的第 `k` 个值。
sub off-at(Pointer $p, Int $k, Int $width --> Int) {
    return 0 unless $p.defined && $p.Int;
    return $width == 8 ?? nativecast(CArray[int64], $p)[$k]
                        !! nativecast(CArray[int32], $p)[$k];
}

#| 读变长类型 offsets 的最后一个值，用来算数据段真实长度。
sub last-offset(Pointer $p, Int $n, Int $width --> Int) {
    return 0 unless $p.defined && $p.Int;
    return $width == 8 ?? nativecast(CArray[int64], $p)[$n]
                        !! nativecast(CArray[int32], $p)[$n];
}

#| 深度优先走一棵列：每层写 FieldNode，再按类型顺序写它自己的 buffers。
#|
#| 顺序必须和 schema 的字段顺序完全一致，否则 pyarrow 会把 offset 和
#| 数据段错配 —— 报错往往指向别处，很难查。
#|
#| # null 槽规范化
#|
#| Arrow 规定「空值所在的那一格内容未定义」，所以缓冲区里那一格可以是任何
#| 垃圾 —— DuckDB 目前的实现多数时候会顺手清掉，但规范并不保证，也不同版本
#| 一致。唯一能确定的是「语义相同」，不是「字节相同」。
#|
#| 于是这里在拷贝之后做一遍归一：
#|
#| * 定长：null 槽那 `$w` 字节清零；
#| * 位图（bool 数据）：null 位清零；
#| * 变长：先把 null 槽真正指向的那段数据清零，再把它的 offset 改成
#|   「长度 0」（`off[i] = off[i+1]`），于是连未被引用的空洞都不存在；
#| * 复合类型：父级为空时，子级对应的槽同样是未定义的，用 `$mask`
#|   把这份「未定义」传下去。
#|
#| 归一之后同一份数据必然写出逐字节相同的文件。
sub walk-node($sch, $col, BodyAcc $body, $mask? --> Nil) {
    my Str $fmt = $sch.format;
    my %t = parse-format($fmt);
    my Int $n = $col.length;
    my Int $nc = $col.null-count;

    $body.node($n, $nc);

    # 有效位图：没有空值就写一条 0 长度的 buffer
    my Int $vlen = $nc > 0 ?? (($n + 7) div 8) !! 0;
    my Int $voff = $body.add($col.buffer(0), $vlen, bits => $n);

    # 逻辑上未定义的槽 = 自己为空 ∪ 父级为空
    my Set $undef = Set.new;
    if $vlen {
        my @nulls;
        for ^$n -> int $i {
            my Int $bit = $body.byte-at($voff + ($i div 8)) +& (1 +< ($i % 8));
            @nulls.push: $i unless $bit;
        }
        $undef = Set.new(@nulls);
    }
    $undef = $undef (|) $mask if $mask.defined;

    given %t<kind> {
        when 'null' { }

        when 'bool' {
            my Int $boff = $body.add($col.buffer(1), ($n + 7) div 8, bits => $n);
            $body.clear-bits($boff, $undef) if $undef.elems;
        }

        when 'fixed' {
            my Int $w = %t<bytes>;
            my Int $off = $body.add($col.buffer(1), $n * $w);
            $body.zero-slots($off, $w, $undef) if $undef.elems;
        }

        when 'utf8' | 'binary' {
            my Int $w = %t<width>;
            my $op = $col.buffer(1);
            my Int $last = last-offset($op, $n, $w);
            my Int $ooff = $body.add($op, ($n + 1) * $w);
            my Int $doff = $body.add($col.buffer(2), $last);
            for $undef.keys -> $i {
                my Int $a = off-at($op, $i, $w);
                my Int $b = off-at($op, $i + 1, $w);
                $body.zero-range($doff, $a, $b) if $b > $a;
                $body.write-offset($ooff, $i, $b, $w);
            }
        }

        when 'list' | 'map' | 'struct' {
            my $kid-mask;
            if %t<kind> ne 'struct' {
                my Int $w = %t<width>;
                my $op = $col.buffer(1);
                my Int $ooff = $body.add($op, ($n + 1) * $w);
                my @kid-undef;
                for $undef.keys -> $i {
                    my Int $a = off-at($op, $i, $w);
                    my Int $b = off-at($op, $i + 1, $w);
                    @kid-undef.append: $a ..^ $b;
                    # 空容器覆盖的元素区间可以是任意垃圾，缩成「不占格子」
                    $body.write-offset($ooff, $i, $b, $w);
                }
                $kid-mask = Set.new(@kid-undef) if @kid-undef.elems;
            }
            elsif $undef.elems {
                # Struct 的子列与父列等长，索引直接对上
                $kid-mask = $undef;
            }

            my @kids = $col.children;
            my @sch-kids = $sch.children;
            for ^@kids.elems -> int $i {
                walk-node(@sch-kids[$i], @kids[$i], $body, $kid-mask);
            }
        }

        default {
            die "arrow-ipc: unsupported Arrow format '$fmt'";
        }
    }
}

# ============================================================
# 对外：写文件 / 写字节
# ============================================================

my constant MAGIC = Buf.new(0x41, 0x52, 0x52, 0x4F, 0x57, 0x31);   # "ARROW1"

#| 一条 encapsulated message：`ffffffff` + 长度 + metadata + body。
sub encapsulated(Buf $meta --> Buf) {
    my $head = Buf.new(0xFF, 0xFF, 0xFF, 0xFF) ~ le-bytes($meta.elems, 4);
    $head ~ $meta;
}

#| 把一张 Arrow 视图编码成 IPC 字节流，一块一块交给 `&sink`。
#|
#| 参数用鸭子类型（只需要 `.schema` 和 `.chunks(&code)`），不 `use`
#| Duckula::Arrow —— 那个模块会反过来 use 本模块。
#|
#| 落盘还是留在内存由 sink 决定，编码逻辑只此一份：`write-ipc` 把块写进
#| 文件句柄，`ipc-buf` 把块追加进 Buf。
sub emit-ipc($arrow, Str:D $format, &sink --> Nil) {
    die "arrow-ipc: unknown format '$format' (file|stream)"
        unless $format eq 'file' || $format eq 'stream';

    my Bool $is-file = $format eq 'file';
    my $schema = $arrow.schema;

    # 字典要先摸清楚：schema 里要给每个字典列编号，数据侧还要按同一顺序
    # 先把字典批次发出去。
    my @dicts = dict-scan($schema);
    my %dict-info;
    for @dicts -> %d { %dict-info{%d<node-addr>} = %d; }

    my Int $pos = 0;
    my @blocks;
    my @dict-blocks;

    my sub put(Buf $b --> Nil) {
        sink($b);
        $pos += $b.elems;
    }

    # file 格式开头是 magic + 2 字节补零（magic 本身 6 字节）
    put(MAGIC ~ Buf.new(0, 0)) if $is-file;

    my Buf $schema-msg = schema-message($schema, %dict-info);
    put(encapsulated($schema-msg));

    my Bool $dicts-written = False;

    $arrow.chunks: -> $chunk {
        unless $dicts-written {
            $dicts-written = True;
            for @dicts -> %d {
                my $col = array-at($chunk, %d<path>);
                my $darr = nativecast(ArrowArray, $col.dictionary);
                next unless $darr.defined && $darr.release-fn.Int;

                my $dbody = BodyAcc.new;
                walk-node(schema-node-of(Pointer.new(%d<schema-addr>)),
                          ArrayView.new(arr => $darr), $dbody);
                my Buf $dbb = $dbody.padded;
                my Buf $dmeta = dictionary-batch-message(
                    %d<id>, $darr.length, $dbody.nodes, $dbody.descs, $dbb.elems);
                my Int $dstart = $pos;
                put(encapsulated($dmeta));
                put($dbb);
                @dict-blocks.push: ($dstart, 8 + $dmeta.elems, $dbb.elems);
            }
        }

        my $body = BodyAcc.new;
        my Int $ncol = $schema.n-children;
        for ^$ncol -> int $i {
            walk-node($schema.column($i), $chunk.column($i), $body);
        }

        my Buf $bb = $body.padded;
        my Buf $meta = batch-message($chunk.length, $body.nodes, $body.descs,
                                     $bb.elems);
        my Int $start = $pos;
        put(encapsulated($meta));
        put($bb);
        @blocks.push: ($start, 8 + $meta.elems, $bb.elems);
    }

    if $is-file {
        # 尾部布局：<footer flatbuffer><int32 footer 长度><magic>
        my Buf $footer = footer-message($schema, %dict-info, @dict-blocks, @blocks);
        put($footer);
        put(le-bytes($footer.elems, 4));
        put(MAGIC);
    }
    else {
        put(Buf.new(0xFF, 0xFF, 0xFF, 0xFF) ~ le-bytes(0, 4));
    }
    Nil;
}

#| 把一张 Arrow 视图写成 IPC 文件。
#|
#|     write-ipc($arrow, 'x.arrow');                   # file 格式（默认）
#|     write-ipc($arrow, 'x.arrows', :format<stream>); # stream 格式
our sub write-ipc($arrow, Str:D $path, Str:D :$format = 'file' --> Nil) {
    my $fh = $path.IO.open(:w, :bin);
    LEAVE { $fh.close if $fh.defined }
    emit-ipc($arrow, $format, -> Buf $b { $fh.write($b) });
    Nil;
}

#| 把一张 Arrow 视图编码成内存里的 IPC 字节。
#|
#| 这是给**别的进程**的出口。C data interface 的裸指针只在本进程有效，
#| 而 IPC 字节是可以塞进管道、写进 socket、交给 `Inline::Python` 的：
#|
#|     my Buf $bytes = $df.arrow.ipc-buf;      # stream 格式（默认）
#|     # Python: pa.ipc.open_stream(bytes).read_all()
#|
#| 默认 `stream` 而不是 `file`：在内存里没人需要 footer 索引，而 stream
#| 格式的开销就是每条 message 一个 8 字节前缀，另外省掉收尾的 magic 和
#| footer。要随机访问才显式 `:format<file>`。
our sub ipc-buf($arrow, Str:D :$format = 'stream' --> Buf) {
    my Buf $out = Buf.new;
    emit-ipc($arrow, $format, -> Buf $b { $out.append($b) });
    $out;
}
