use v6.d;
use Duckula::X::Series;

#| 一列数据：DB::DuckDB::ColumnView 的薄包装。
#|
#| 刻意做得薄（ARCHITECTURE.md §8.5）：所有读值、聚合、切片都直接代理给
#| ColumnView，Duckula 一行计算代码都不写。ColumnView 的 `.at` / `.to-list`
#| 本身就走向量内存，比先取成 Array 再在 Raku 里算快一个量级。
#|
#| **生命周期（最容易出悬垂指针的地方）**
#| ColumnView 的指针属于 `duckdb_result`，不是属于 view。所以 Series 必须
#| 同时持有 result 的引用，否则 view 还活着、result 已被 GC，读到的就是野内存。
#| `$!result` 这个属性唯一的作用就是"钉住" result。
class Duckula::Series {
    has Str $.name = '';
    has $!view;
    has $!result;
    has $!frame;

    submethod BUILD(Str :$!name = '', :$!view!, :$!result, :$!frame) { }

    #| 元素个数（含 NULL）。
    method elems(--> Int) { $!view.elems }

    #| 非 NULL 的个数。
    method count(--> Int) { $!view.count }

    #| 整列取成 List。`:typed` 会把日期类还原成 Date / DateTime。
    #| 注意这是分配路径，批量计算请用聚合方法。
    method to-list(Bool :$typed = False --> List) { $!view.to-list(:$typed) }

    #| SUM，跳过 NULL。整数列返回 Int，浮点列返回 Num。
    method sum(--> Mu) { $!view.sum }

    method min(--> Mu) { $!view.min }

    method max(--> Mu) { $!view.max }

    #| sum / count，全 NULL 时返回 Any。
    method mean(--> Mu) { $!view.mean }

    #| 取前 $n 个值。
    #|
    #| 走来源 Frame 的 SQL LIMIT，而不是 ColumnView.slice —— 因为 slice 返回的是
    #| 重新解码出来的 view（`.raw` 为 False），`!agg` 对它直接返回 Any，聚合就废了。
    #| 重新走 SQL 多一次查询，但拿到的仍是 raw 列，`.sum` / `.mean` 照常可用。
    method head(Int $n = 5 --> Duckula::Series) {
        die Duckula::X::Series.new(reason => "head() needs a non-negative count, got $n")
            if $n < 0;

        return $!frame.head($n).column($!name) if $!frame.defined;

        Duckula::Series.new(
            name   => $!name,
            view   => $!view.slice(0, $n),
            result => $!result,        # 继续钉住同一个 result
        );
    }

    #| 第 $i 个值（0 基），越界返回 Any，NULL 也是 Any。
    method at(Int $i --> Mu) { $!view.at($i) }

    method gist(--> Str) {
        my Int $n = $!view.elems;
        my Int $show = $n < 5 ?? $n !! 5;
        my @vals = $!view.slice(0, $show).to-list;
        my Str $body = @vals.map({ defined($_) ?? $_.Str !! 'NULL' }).join(', ');
        $body ~= ', ...' if $n > $show;

        my Str $head = $!name eq '' ?? 'Series' !! $!name;
        "$head ($n elems)\n[$body]";
    }

    method raku(--> Str) {
        "Duckula::Series.new(name => {$!name.raku}, elems => {$!view.elems})";
    }
}
