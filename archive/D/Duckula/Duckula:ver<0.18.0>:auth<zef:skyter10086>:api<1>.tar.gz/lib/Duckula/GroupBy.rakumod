use v6.d;
use Duckula::Expr;
use Duckula::SQL;
use Duckula::X::Frame;

#| 分组阶段的中间对象：持有来源 Frame 和分组键，等 `agg` 才拼 SQL。
#|
#|   $df.group-by('city').agg(col('amount').sum.alias('total'));
#|   $df.group-by('city', 'country').agg(len().alias('n'));
#|   $df.group-by(col('city').upper.alias('city_up')).agg(col('amount').max);
#|
#| 为什么要有这个中间对象，而不是让 `Frame.group-by` 直接返回专用 Frame：
#| 分组键和聚合表达式是两件事，必须同时到齐才能拼出一条 SELECT。
#| 中间对象正好卡在那里，也顺手把「只 group 不 agg」这种半成品挡在类型之外。
#|
#| 刻意不在这里 `use Duckula::Frame`：`Frame` 已经 `use` 了本模块，双向 use
#| 会形成预编译循环。这里只在运行时构造 `Duckula::Frame`，不做类型约束。
class Duckula::GroupBy {
    has $.frame is required;
    has @.keys;        # List[Duckula::Expr]
    has @.key-names;   # List[Str]

    submethod BUILD(:$!frame!, :$keys) {
        # 用标量参数接 `keys` 而不是 `: @keys`：后者在把数组当命名参数传进来时
        # 也会再包一层。收到之后一律 `.flat` —— `Array.List` 赋给标量会被 Raku
        # itemize 成 `$(($expr,),)` 这种嵌套，`for` 直接绑不上类型。
        my @ks = ($keys // ()).flat;
        my @names;

        for @ks -> Duckula::Expr $e {
            my $n = $e.out-name;
            die Duckula::X::Frame.new(
                reason => 'group-by key needs a name: '
                        ~ 'use .alias("name") on the expression'
            ) unless defined $n && $n ne '';
            @names.push: $n.Str;
        }

        self!check-duplicate(@names, 'group-by key');

        @!keys = @ks;
        @!key-names = @names.List;
    }

    method !check-duplicate(@names, Str:D $what --> Nil) {
        my %seen;
        for @names -> $n {
            die Duckula::X::Frame.new(reason => "$what '$n' appears more than once")
                if %seen{$n}++;
        }
    }

    #| 分组键（Expr 列表）。
    method keys(--> List) { @!keys.List }

    #| 校验聚合并生成输出投影，返回 `%( names => …, items => … )`。
    #|
    #| `items` 是 `expr AS "name"` 的完整投影片段，`names` 是输出列名。
    #| 抽出来是为了让两条路径共用同一套列名规则（自动命名、重名检测、
    #| 非聚合/窗口表达式的拒绝）：`Frame` 的字符串拼接，和 `LazyFrame`
    #| 的计划树节点。两套实现分叉的话，迟早会出现「eager 报错、lazy 不报」
    #| 这种最难查的不一致。
    method spec(*@aggs --> Hash) {
        my @flat = self!flatten(@aggs);
        die Duckula::X::Frame.new(reason => 'agg() needs at least one aggregate expression')
            unless @flat.elems;

        my @out-names;
        my @out-sql;

        for @!keys Z @!key-names -> ($e, $n) {
            @out-names.push: $n;
            # 键表达式也要显式起名：`col('city')` 渲染成 `"city"` 刚好同名，
            # 但 `col('city').upper.alias('cu')` 渲染成 `upper("city")`，
            # 不加 AS 输出列名就会变成 `upper(city)`。
            @out-sql.push: $e.render ~ ' AS ' ~ quote-ident($n);
        }

        for @flat -> $a {
            die Duckula::X::Frame.new(
                reason => "agg() only takes Duckula::Expr, got {$a.WHAT.gist}"
            ) unless $a ~~ Duckula::Expr;

            my Duckula::Expr $e = $a;

            # 窗口函数是逐行的，放进聚合里没有意义（DuckDB 会报「window
            # functions are not allowed in GROUP BY」这类难懂的错）。
            die Duckula::X::Frame.new(
                reason => "agg() takes aggregates, but '{$e.render}' is a window "
                        ~ "expression; drop .over() / .cum-* / .rank and use "
                        ~ "with-column if you want it per row"
            ) if $e.window.defined;

            die Duckula::X::Frame.new(
                reason => "agg() needs aggregate expressions, but '{$e.render}' has no "
                        ~ "aggregate function; try col('x').sum / .mean / .min / .max / "
                        ~ ".count, or len()"
            ) unless $e.is-aggregate;

            my $n = $e.out-name;
            die Duckula::X::Frame.new(
                reason => "agg() expression '{$e.render}' needs a name: "
                        ~ 'use .alias("name") on the expression'
            ) unless defined $n && $n ne '';

            @out-names.push: $n.Str;
            @out-sql.push: $e.render ~ ' AS ' ~ quote-ident($n.Str);
        }

        self!check-duplicate(@out-names, 'output column');

        %( names => @out-names.List, items => @out-sql.List );
    }

    #| 执行聚合，返回新的 Frame（仍只是 SQL，不搬数据）。
    #|
    #| 列名规则：显式 `.alias(...)` 优先，否则用 Expr 推出来的名字
    #| （`col('amount').sum` → `amount_sum`）。推不出来就当场报错，
    #| 不会让 DuckDB 给一个 `sum("amount")` 这样的怪列名。
    multi method agg(*@aggs) {
        my %spec = self.spec(|@aggs);
        my $frame = $!frame;

        # 计划树路径：LazyFrame 自己接规格去造节点，SQL 留到 collect 才渲染。
        # 用 `^can` 而不是 `~~ Duckula::LazyFrame` —— 本模块不能 use LazyFrame
        # （LazyFrame 会 use 本模块），只能问它「认不认这个协议」。
        return $frame.agg-from-spec(%spec, @!keys.List)
            if $frame.^can('agg-from-spec');

        # 位置分组：`GROUP BY 1, 2` 比重复整段表达式干净，也避免键表达式
        # 里带聚合函数时被 DuckDB 当成 HAVING 语义。
        my Str $group = @!keys.elems
            ?? ' GROUP BY ' ~ (1 .. @!keys.elems).join(', ')
            !! '';

        # 走 `$frame.derived($sql)` 而不是 `Duckula::Frame.new(...)`：
        # 本模块不能 `use Duckula::Frame`（会与 Frame 的 use 形成循环），
        # 而 `Duckula::Frame.new` 在编译期会被解析成子例程调用并报
        # 「Could not find symbol '&Frame'」。
        $frame.derived(
            'SELECT ' ~ %spec<items>.List.join(', ')
            ~ ' FROM (' ~ $frame.relation-sql ~ ') AS __duckula_group'
            ~ $group
        );
    }

    #| 每组行数，列名 `count`。等价于 `agg(len().alias('count'))`。
    method count() {
        self.agg(len().alias('count'));
    }

    method !flatten(@aggs --> List) {
        @aggs.elems == 1 && @aggs[0] ~~ Positional
            ?? @aggs[0].List
            !! @aggs.List;
    }
}
