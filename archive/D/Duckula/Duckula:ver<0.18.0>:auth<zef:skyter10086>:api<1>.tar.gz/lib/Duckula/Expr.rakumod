use v6.d;
use Duckula::SQL;
use Duckula::Clean;
use Duckula::X::Frame;

#| 聚合函数名 → 自动命名用的后缀。
#| `avg` 的后缀是 `mean`，这样 `col('amount').sum` 叫 `amount_sum`、
#| `.mean` 叫 `amount_mean`，和 Series 的方法名一致。
#|
#| 必须声明在 `class Duckula::Expr` **之前**：方法体里引用一个文件后面才
#| 声明的 lexical 常量，会让 Raku 的 resolver 内部崩掉
#| （`Use of Nil in string context` + `Cannot unbox a type object (Nil) to a str`），
#| 而不是给个正常的 "undeclared" 报错。同 §8.4 里记的前向引用坑。
my constant %AGG-SUFFIX = (
    sum   => 'sum',
    avg   => 'mean',
    min   => 'min',
    max   => 'max',
    count => 'count',
);

#| 累积窗口的帧子句。
#|
#| 为什么不直接依赖 SQL 的默认帧：`sum(x) OVER (ORDER BY id)` 的默认帧是
#| `RANGE UNBOUNDED PRECEDING`，**同值的行会被当成一个 peer group**，排序键
#| 有重复时多行拿到同一个累积值。显式写 `ROWS` 严格按行推进，才和 Polars 的
#| `cum_sum()` 语义一致。
my constant $CUM-FRAME = 'ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW';

#| 排名方法名 → DuckDB 窗口函数。
#| `min` 是 SQL 的 `rank()`（并列跳号），`dense` 不跳号，`ordinal` 不并列。
my constant %RANK-FN = (
    min     => 'rank()',
    rank    => 'rank()',
    max     => 'rank()',
    dense   => 'dense_rank()',
    ordinal => 'row_number()',
    row     => 'row_number()',
);

#| 一段 SQL 表达式的包装：持有已渲染的 SQL 片段，以及它引用到的列名集合。
#|
#| 为什么自带 `$.columns`：Duckula 的防注入模型里，列名必须过白名单（§9.5.3）。
#| 但表达式是拼出来的，Frame 拿到的只是一段字符串，没法再反解出列名——
#| 所以让每个 Expr 在构造时就记住自己引用了哪些列，Frame 执行前拿这个集合
#| 去和 `names` 对账。
#|
#| 渲染本身不做任何校验：`col("x")` 里的 x 已经在构造时过了 quote-ident，
#| 哪怕叫 `a"; DROP TABLE t; --` 也只会退化成一个合法标识符。
class Duckula::Expr {
    has Str $.sql is required;
    has Set $.columns = Set.new;
    has Str $.as;

    #| 自动命名用的候选名：`col('amount').sum` → `amount_sum`。
    #| 只有「单个列引用」及其「一层聚合」能推出名字，其余为 Str 类型对象。
    has Str $.label;

    #| 这个表达式的顶层是否是聚合函数（sum/avg/min/max/count/len）。
    #| `agg` 靠它拒绝 `agg(col('city'))` 这种会在 GROUP BY 里炸掉的写法。
    has Bool $.is-aggregate = False;

    #| 窗口子句的完整文本，例如 `OVER (PARTITION BY "g" ORDER BY "id" DESC)`。
    #| 非窗口表达式是 Str 类型对象（`.defined` 为 False）。
    #|
    #| 单独存一份而不去 grep SQL 文本：`with-column` 要靠它判断「该不该补
    #| `OVER ()`」，`agg` 要靠它拒绝窗口函数 —— 都属于不该靠字符串猜测的判断。
    has Str $.window;

    #| 顶层是不是一个**裸**聚合调用（`sum("v")` 外面没套任何算术）。
    #|
    #| 只有裸聚合才能在 `with-column` 里安全地补一个 `OVER ()` 变成广播。
    #| `(sum("v") / count(*))` 这种复合表达式补在末尾会变成
    #| `(sum("v") / count(*)) OVER ()` —— 语法错误，因为 OVER 只能跟在一个
    #| 函数调用后面。所以复合情形要让用户自己给每个聚合加 `.over()`。
    has Bool $.bare-agg = False;

    #| 给表达式起别名，供 `with-column` / `select` 使用。
    method alias(Str:D $name --> Duckula::Expr) {
        Duckula::Expr.new(
            sql          => $!sql,
            columns      => $!columns,
            as           => $name,
            label        => $!label,
            is-aggregate => $!is-aggregate,
            window       => $!window,
            bare-agg     => $!bare-agg,
        );
    }

    method render(--> Str) { $!sql }

    #| 输出名：显式别名优先，其次可以从表达式推出的名字。
    method out-name(--> Str) { $!as // $!label }

    #| 聚合，供 group-by 的 agg 使用。单独用在 with-column 里会变成全表聚合。
    method sum(--> Duckula::Expr)   { self!aggregate('sum') }
    method mean(--> Duckula::Expr)  { self!aggregate('avg') }
    method min(--> Duckula::Expr)   { self!aggregate('min') }
    method max(--> Duckula::Expr)   { self!aggregate('max') }
    method count(--> Duckula::Expr) { self!aggregate('count') }

    #| 布尔取反：`col('flag').not`
    method not(--> Duckula::Expr) {
        Duckula::Expr.new(sql => "(NOT {$!sql})", columns => $!columns);
    }
    # 字符串方法：直接挂在 Expr 上，不做 `.str` 二级对象。
    # 二级对象会引入跨类前向引用（`Duckula::Expr` 引用后面定义的
    # `Duckula::ExprStr`），Raku 在这上面会崩 resolver，所以改成扁平方法。
    # 用起来也更短：`col('city').starts-with('北')` 而不是 `.str.starts-with('北')`。

    method starts-with($prefix --> Duckula::Expr) {
        Duckula::Expr.new(
            sql     => "starts_with({$!sql}, {sql-literal($prefix)})",
            columns => $!columns,
        );
    }

    method contains($needle --> Duckula::Expr) {
        Duckula::Expr.new(
            sql     => "contains({$!sql}, {sql-literal($needle)})",
            columns => $!columns,
        );
    }

    method upper(--> Duckula::Expr) {
        Duckula::Expr.new(sql => "upper({$!sql})", columns => $!columns);
    }

    method lower(--> Duckula::Expr) {
        Duckula::Expr.new(sql => "lower({$!sql})", columns => $!columns);
    }

    method length(--> Duckula::Expr) {
        Duckula::Expr.new(sql => "length({$!sql})", columns => $!columns);
    }

    #| 类型转换（pandas 的 `astype` / Polars 的 `cast`）：
    #|
    #|   col('id').cast('VARCHAR')
    #|   col('amount').cast('DECIMAL(18,4)')
    #|
    #| 类型名过白名单（`Duckula::Clean::check-type-name`）：`CAST(x AS ?)` 不成立，
    #| 类型只能拼进文本，所以它和列名一样必须由我们保证合法 —— 带分号、引号、
    #| 注释符的一律拒绝，免得 CAST 之后的文本变成另一条语句。
    method cast(Str:D $type --> Duckula::Expr) {
        Duckula::Expr.new(
            sql     => "CAST({$!sql} AS {check-type-name($type)})",
            columns => $!columns,
            label   => $!label,
        );
    }

    # ============================================================
    # 窗口（window functions）
    # ============================================================
    #
    # 所有窗口方法最终都汇到 `!make-window`，它只干一件事：拼出
    #   `<函数调用> OVER (<PARTITION BY …> <ORDER BY …> <帧>)`
    # 顺手把分区键 / 排序键引用到的列并进 $.columns —— 这样 Frame 的列名
    # 白名单（§9.5.3）也能看见它们，`over('custmer')` 这种拼错当场报错，
    # 而不是等 DuckDB 在运行时抛 Binder Error。

    #| 把 `over('g')` / `over(<a b>)` / `over(col('x').upper)` 规整成 Expr 列表。
    #| 裸字符串按列名处理，和 `col()` 一样过 quote-ident。
    method !keys(*@raw --> List) {
        my @flat = @raw.elems == 1 && @raw[0] ~~ Positional
            ?? @raw[0].List
            !! @raw.List;

        @flat.map(-> $k {
            $k ~~ Duckula::Expr
                ?? $k
                !! Duckula::Expr.new(
                    sql     => quote-ident($k.Str),
                    columns => Set.new($k.Str),
                    label   => $k.Str,
                );
        }).List;
    }

    method !make-window(
        Str:D $fn-sql,
        List $by,
        List $order-by,
        Bool $desc,
        Str $frame,
        --> Duckula::Expr
    ) {
        my Set $cols = $!columns;
        my @spec;

        if $by.elems {
            @spec.push: 'PARTITION BY ' ~ $by.map(*.render).join(', ');
            for $by.list -> $e { $cols = $cols ∪ $e.columns }
        }
        if $order-by.elems {
            @spec.push: 'ORDER BY '
                      ~ $order-by.map({ $_.render ~ ($desc ?? ' DESC' !! '') }).join(', ');
            for $order-by.list -> $e { $cols = $cols ∪ $e.columns }
        }
        @spec.push: $frame if $frame ne '';

        my Str $w = 'OVER (' ~ @spec.join(' ') ~ ')';

        Duckula::Expr.new(
            sql      => $fn-sql ~ ' ' ~ $w,
            columns  => $cols,
            label    => $!label,
            window   => $w,
        );
    }

    #| 给聚合表达式加上窗口子句（Polars 的 `over`）：
    #|
    #|   col('amount').sum.over('dept');                    # 每个 dept 的总额
    #|   col('amount').sum.over('dept', :order-by('day'));  # 部门内按天累计
    #|   col('amount').mean.over();                         # 全表均值
    #|
    #| 注意 `.over()` 之后 `is-aggregate` 变成 False：它已经是**逐行**的窗口
    #| 值，不再是会折叠行的聚合，所以能安全地放进 `with-column`。
    method over(*@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        die Duckula::X::Frame.new(
            reason => "'{$!sql}' already has a window clause; "
                    ~ 'apply .over() once, on the aggregate itself'
        ) if $!window.defined;

        # `"amount" OVER (...)` / `1 OVER (...)` 都不是合法 SQL。OVER 只能跟在
        # 函数调用后面，用「有没有括号」做一次廉价的前置检查，比让 DuckDB
        # 报 Binder Error 更好读。
        die Duckula::X::Frame.new(
            reason => ".over() applies a window to a function call, but '{$!sql}' "
                    ~ "is not one; try col('x').sum.over(...) or .cum-sum / .rank"
        ) unless $!sql.contains('(');

        self!make-window(
            $!sql,
            self!keys(|@by),
            $order-by.defined ?? self!keys($order-by) !! (),
            $desc,
            '',
        );
    }

    #| 累积求和（Polars 的 `cum_sum`）：
    #|
    #|   $df.with-column(col('amount').cum-sum.alias('running'));
    #|   $df.with-column(col('amount').cum-sum('dept', :order-by<day>).alias('running'));
    #|
    #| 不给 `order-by` 时按扫描顺序推进（和 Polars 依赖 frame 行序一个意思）。
    method cum-sum(*@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        self!cumulative('sum', |@by, :$order-by, :$desc);
    }

    method cum-max(*@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        self!cumulative('max', |@by, :$order-by, :$desc);
    }

    method cum-min(*@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        self!cumulative('min', |@by, :$order-by, :$desc);
    }

    #| 累积计数（数非 NULL）。相当于 Polars 的 `cum_count`。
    method cum-count(*@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        self!cumulative('count', |@by, :$order-by, :$desc);
    }

    method !cumulative(Str:D $fn, *@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        # `len()` 的 SQL 本身就是 `count(*)`，再包一层会变成 `count(count(*))`。
        my Str $base = $!sql.starts-with('count(')
            ?? $!sql
            !! $fn ~ '(' ~ $!sql ~ ')';

        my $e = self!make-window(
            $base,
            self!keys(|@by),
            $order-by.defined ?? self!keys($order-by) !! (),
            $desc,
            $CUM-FRAME,
        );

        $e.clone-with(label => $!label.defined ?? "{$!label}_cum_{%AGG-SUFFIX{$fn} // $fn}" !! Str);
    }

    #| 前后挪一行（Polars 的 `shift`）：正数取前一行，负数取后一行。
    #| 没有 order-by 时按扫描顺序，和 `cum-sum` 一致。
    method shift(Int $n = 1, *@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        die Duckula::X::Frame.new(reason => 'shift() needs a non-zero offset')
            if $n == 0;

        my Str $fn = $n < 0 ?? 'lead' !! 'lag';
        my $e = self!make-window(
            $fn ~ '(' ~ $!sql ~ ', ' ~ $n.abs ~ ')',
            self!keys(|@by),
            $order-by.defined ?? self!keys($order-by) !! (),
            $desc,
            '',
        );

        $e.clone-with(label => $!label.defined ?? "{$!label}_shift" !! Str);
    }

    #| 与前一行的差（Polars 的 `diff`）：`x - lag(x, n)`。
    method diff(Int $n = 1, *@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        my $lag = self.shift($n, |@by, :$order-by, :$desc);

        Duckula::Expr.new(
            sql    => '(' ~ $!sql ~ ' - ' ~ $lag.sql ~ ')',
            columns => $lag.columns,
            label  => $!label.defined ?? "{$!label}_diff" !! Str,
            window => $lag.window,
        );
    }

    #| 排名（Polars 的 `rank`）：默认升序，`:desc` 反序。
    #|
    #|   col('score').rank;                 # rank() OVER (ORDER BY "score")
    #|   col('score').rank(:desc);          # 从大到小
    #|   col('score').rank(:method<dense>); # 并列不跳号
    #|
    #| 默认 `min` 走 SQL 的 `rank()`（并列跳号，1,1,3），和 pandas 的
    #| `rank(method='min')` 一致；`ordinal` 走 `row_number()`（1,2,3）。
    method rank(Bool :$desc = False, Str :$method = 'min', *@by --> Duckula::Expr) {
        my Str $fn = %RANK-FN{$method} // '';
        die Duckula::X::Frame.new(
            reason => "unknown rank method '$method'; "
                    ~ "use one of {%RANK-FN.keys.sort.join(', ')}"
        ) if $fn eq '';

        my $e = self!make-window($fn, self!keys(|@by), (self,), $desc, '');

        $e.clone-with(label => $!label.defined ?? "{$!label}_rank" !! Str);
    }

    #| 以「当前行和前 w-1 行」为窗口的滚动求和（Polars 的 `rolling_sum`）。
    #|
    #| 窗口不满时按现有的行算（就是 `min_periods = 1` 的语义），这也是
    #| SQL 帧 `ROWS BETWEEN w-1 PRECEDING AND CURRENT ROW` 的默认行为。
    method rolling-sum(Int $w, *@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        self!rolling('sum', $w, |@by, :$order-by, :$desc);
    }

    method rolling-mean(Int $w, *@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        self!rolling('avg', $w, |@by, :$order-by, :$desc);
    }

    method !rolling(Str:D $fn, Int $w, *@by, :$order-by, Bool :$desc = False --> Duckula::Expr) {
        die Duckula::X::Frame.new(reason => "rolling window must be >= 1, got $w")
            if $w < 1;

        my $e = self!make-window(
            $fn ~ '(' ~ $!sql ~ ')',
            self!keys(|@by),
            $order-by.defined ?? self!keys($order-by) !! (),
            $desc,
            'ROWS BETWEEN ' ~ ($w - 1) ~ ' PRECEDING AND CURRENT ROW',
        );

        $e.clone-with(label => $!label.defined ?? "{$!label}_rolling_{%AGG-SUFFIX{$fn}}" !! Str);
    }

    #| 换一个 label 造一份新 Expr（内部用，避免十处重复写全字段构造）。
    method clone-with(Str :$label --> Duckula::Expr) {
        Duckula::Expr.new(
            sql          => $!sql,
            columns      => $!columns,
            as           => $!as,
            label        => $label,
            is-aggregate => $!is-aggregate,
            window       => $!window,
            bare-agg     => $!bare-agg,
        );
    }

    method !aggregate(Str:D $fn --> Duckula::Expr) {
        # 注意别写成 "$fn({$!sql})" —— 插值会把 $fn(...) 当成函数调用。
        my $base = $!label;
        Duckula::Expr.new(
            sql          => $fn ~ '(' ~ $!sql ~ ')',
            columns      => $!columns,
            label        => $base.defined ?? "{$base}_{%AGG-SUFFIX{$fn}}" !! Str,
            is-aggregate => True,
            bare-agg     => True,
        );
    }

    method gist(--> Str) { $!sql }

    method raku(--> Str) { "col-expr({$!sql.raku})" }
}

#| 造一个列引用。列名在这里就过 quote-ident，之后怎么拼都安全。
sub col(Str:D $name --> Duckula::Expr) is export {
    Duckula::Expr.new(sql => quote-ident($name), columns => Set.new($name), label => $name);
}

#| 造一个字面量表达式（给需要显式包一层的场景用）。
sub lit($value --> Duckula::Expr) is export {
    Duckula::Expr.new(sql => sql-literal($value));
}

#| 行数：`count(*)`。group-by 之后用它数每组的行数，比 `col('x').count` 更准
#| （后者不数 x 为 NULL 的行）。对应 Polars 的 `pl.len()`。
sub len(--> Duckula::Expr) is export {
    Duckula::Expr.new(
        sql          => 'count(*)',
        label        => 'len',
        is-aggregate => True,
        bare-agg     => True,
    );
}

my sub coerce($v --> Duckula::Expr) {
    $v ~~ Duckula::Expr ?? $v !! Duckula::Expr.new(sql => sql-literal($v));
}

my sub binop(Str:D $op, $a, $b --> Duckula::Expr) {
    my Duckula::Expr $l = coerce($a);
    my Duckula::Expr $r = coerce($b);
    Duckula::Expr.new(
        sql          => '(' ~ $l.sql ~ ' ' ~ $op ~ ' ' ~ $r.sql ~ ')',
        columns      => $l.columns ∪ $r.columns,
        is-aggregate => $l.is-aggregate || $r.is-aggregate,
    );
}

# ============================================================
# 算术
# ============================================================

multi sub infix:<+>(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('+', $a, $b) }
multi sub infix:<+>(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('+', $a, $b) }
multi sub infix:<+>(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('+', $a, $b) }

multi sub infix:<->(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('-', $a, $b) }
multi sub infix:<->(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('-', $a, $b) }
multi sub infix:<->(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('-', $a, $b) }

multi sub infix:<*>(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('*', $a, $b) }
multi sub infix:<*>(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('*', $a, $b) }
multi sub infix:<*>(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('*', $a, $b) }

multi sub infix:</>(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('/', $a, $b) }
multi sub infix:</>(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('/', $a, $b) }
multi sub infix:</>(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('/', $a, $b) }

multi sub prefix:<->(Duckula::Expr:D $a --> Duckula::Expr) is export {
    Duckula::Expr.new(sql => "(-{$a.sql})", columns => $a.columns);
}

# ============================================================
# 比较（返回布尔表达式，喂给 filter）
# ============================================================

multi sub infix:<==>(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('=', $a, $b) }
multi sub infix:<==>(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('=', $a, $b) }
multi sub infix:<==>(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('=', $a, $b) }

multi sub infix:<!=>(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('<>', $a, $b) }
multi sub infix:<!=>(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('<>', $a, $b) }
multi sub infix:<!=>(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('<>', $a, $b) }

multi sub infix:«>»(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('>', $a, $b) }
multi sub infix:«>»(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('>', $a, $b) }
multi sub infix:«>»(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('>', $a, $b) }

multi sub infix:«<»(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('<', $a, $b) }
multi sub infix:«<»(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('<', $a, $b) }
multi sub infix:«<»(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('<', $a, $b) }

multi sub infix:«>=»(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('>=', $a, $b) }
multi sub infix:«>=»(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('>=', $a, $b) }
multi sub infix:«>=»(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('>=', $a, $b) }

multi sub infix:«<=»(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('<=', $a, $b) }
multi sub infix:«<=»(Duckula::Expr:D $a, Any:D $b --> Duckula::Expr) is export { binop('<=', $a, $b) }
multi sub infix:«<=»(Any:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('<=', $a, $b) }

# ============================================================
# 逻辑
# ============================================================

multi sub infix:<&>(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('AND', $a, $b) }
multi sub infix:<|>(Duckula::Expr:D $a, Duckula::Expr:D $b --> Duckula::Expr) is export { binop('OR', $a, $b) }

# `prefix:<!>` 不能重载（Raku 报 "Too many symbols provided for categorical of
# type prefix; needs only 1"），所以取反走方法：`col('flag').not`。
