# Duckula

**pandas / Polars 风格的 DataFrame API，跑在 DuckDB 上，用 Raku 写。**

名字来自 `Duck` + `Dracula`——1988 年动画《Count Duckula》（内地译《怪鸭历险记》）。
一是指向底层的 DuckDB，二是隐喻"同时兼容 pandas 与 Polars 两套 API 的缝合体"，
三是那只鸭子本就是家族里的异类：不吸血、爱蔬菜、讨厌阴森城堡。

## 快速上手

```raku
use Duckula;
use Duckula::Expr;

my $d = duckula;                                      # 默认会话；隔离用 Duckula::Session.new

# 1. 读文件（路径走参数绑定）
my $df = $d.read-csv('orders.csv');

say $df.names;         # 列名
say $df.shape;         # (行数, 列数)

# 2. 取列 -> Series（注意是 {} 不是 []，Raku 的 [] 只收 Int）
my $amount = $df{'amount'};
say $amount.sum;       # 走向量内存，整数列返回 Int

# 3. 表达式与算子（全部编译成 SQL，数据不搬进 Raku）
my $hot = $df.filter((col('amount') > 100) & (col('city').starts-with('北')))
             .with-column((col('amount') * 1.1).alias('amount_taxed'))
             .sort-values('amount', :desc);

# 4. 分组聚合
my $by-city = $df.group-by('city')
                 .agg(col('amount').sum.alias('total'), len().alias('n'))
                 .sort-values('total', :desc);

# 列名可以省：col('amount').sum 自动叫 amount_sum
say $df.group-by('city', 'kind').agg(col('amount').sum).names;

# 全表聚合（不分组）
say $df.agg(len().alias('n'), col('amount').max.alias('hi')).rows;

# 5. 连接（列名只在真冲突时加后缀，默认 _right）
my $cities = $d.read-csv('cities.csv');                       # city, region
my $joined = $df.join($cities, on => 'city', :how<left>);     # inner/left/right/full/semi/anti/cross
say $joined.names;                                            # city,kind,amount,region

# 异名键用 Pair；多个同名键直接列（列名按你的表调整）
#   $df.join($cities, on => 'city' => 'name');    # 左 city 对右 name
#   $df.join($cities, on => <city kind>);         # 两个同名键

# 6. 窗口 / 环比 / 排名 —— 窗口是表达式的一部分，入口是 with-column
$df.with-column(col('amount').sum.over('city').alias('city_total'))
   .with-column((col('amount') / col('city_total')).alias('share'))
   .with-column(col('amount').diff.alias('dod'))
   .with-column(col('amount').rank(:desc).alias('rk'));

# 裸聚合会自动广播（等价 Polars 的 with_columns(pl.col('amount').sum())）
say $df.with-column(col('amount').sum.alias('total')).rows.elems;   # 行数不变

# 7. 切片
$df.head(10);      # = $df.limit(10)
$df.tail(10);      # 末 10 行
$df.slice(5, 10);  # 从第 6 行起取 10 行
$df.slice(-10);    # 倒数 10 行

# 8. 也可以直接写 SQL，self 指当前 Frame
my $top = $by-city.sql('select city, total from self where total > ?', 1000);

# 9. 临时视图用完可回收（连接关闭时也会自动消失）
$d.drop-views;

# 10. Polars 风格的惰性路径：只攒计划，collect 才执行
my $lf = $d.scan-csv('orders.csv')                 # 一个字节都不读
           .filter(col('amount') > 100)
           .group-by('city')
           .agg(col('amount').sum.alias('total'))
           .sort-values('total', :desc)
           .limit(10);

say $lf.explain;        # 计划树 + 生成的 SQL（比 eager 的十层子查询干净得多）
my $out = $lf.collect;  # 这时才真正扫文件

# 11. 导出 Arrow：交给 pyarrow / Polars，或任何读 C data interface 的库
my $arrow = $df.arrow;
say $arrow.schema.gist;            # id: l  city: u  amount: d:18,2  这种
say $arrow.format-of('amount');    # 单看一列的类型

$arrow.chunks(-> $chunk {
    say $chunk.length;             # 2048 行一块，最后一块可能更短
    say $chunk.column(0).ints;     # 按 schema 的类型选 .ints / .int32s / .strs ...
});
$arrow.free;

# 12. 落成 Arrow IPC 文件：跨进程交给 pyarrow / Polars
$df.write-ipc('out.arrow');                              # file 格式（.arrow/.feather）
$df.write-ipc('out.arrows', :format<stream>);            # stream 格式，适合管道

#     不想落盘？直接拿字节（默认 stream 格式）
my Buf $bytes = $df.ipc-buf;

#     Python 侧：
#     >>> import pyarrow.ipc as ipc
#     >>> ipc.open_file('out.arrow').read_all().to_pydict()
#     >>> ipc.open_stream(bytes).read_all()          # 读 ipc-buf 的产物

# 13. 写出去：Parquet / CSV / 真表（数据不出 DuckDB，返回行数）
$df.to-parquet('out.parquet');                    # 默认 zstd
$df.to-parquet('out.parquet', :compression<snappy>);
$df.to-csv('out.csv');                            # 可选 :!header :delimiter<;> :null<NA>
$df.to-table('clean_orders');                     # CREATE TABLE AS，:!replace 则已存在就报错
$df.append-to('clean_orders');                    # INSERT INTO ... SELECT

# 反向：Raku 里的行写进已有表（走 Appender，单事务）
$s.execute('CREATE TABLE t (i BIGINT, s VARCHAR)');
$s.insert('t', ((1, 'a'), (2, Any)));             # Any -> NULL

# 14. 想知道一条 SQL 会被判成什么？问 DuckDB 的解析器
$s.classify('SELECT 1');                              # (SELECT)
$s.classify('SELECT 1; CREATE TABLE t(a INT)');       # (SELECT CREATE)
$s.classify('PRAGMA database_list');                  # (SELECT)
$s.sql('INSTALL arrow');                              # 拒：DuckDB parsed it as LOAD

# 15. 读 Arrow IPC：别人（pyarrow / Polars / Duckula 自己）写的文件
my $raw = $s.read-arrow('out.arrow');                    # file 格式
my $raw2 = $s.read-arrow('out.arrows');                  # stream 格式，自动识别
my $raw3 = $s.read-arrow('out.arrow', :name<imported>);  # 指定临时表名
my $raw4 = $s.read-arrow('out.arrow', :native(False));   # 强制纯 Raku 解码

#     数据落进一张 TEMP 表：连接一关就没了，Frame 不能跨连接用
say $raw.rows;                                           # 已经解好的行
say $raw.filter(col('amount') > 100).rows;               # 之后的算子照常交给 DuckDB

#     只想看看文件里是什么，不读数据：
say $s.describe-arrow('out.arrow').gist;                 # format/batches/rows/fields
#     # 每个字段的 name:format 摘要也能单看：
say $s.describe-arrow('out.arrow')<fields>>>.gist.join(' | ');

# 16. 清洗与重塑：拼接 / 去重 / 频次 / 改名 / 删列 / 空值 / 类型
my $all  = $df.concat($other);                # 按名字对齐，缺的列补 NULL
my $same = $df.concat($other, :strict);       # 列名必须完全一致（Polars 的 vertical）

say $df.unique('city').rows;                  # 去重，保持行序
say $df.unique('city', :keep<last>).rows;     # first（默认）/ last / none / any
say $df.value-counts('city').gist;            # city | count；:normalize 再加 proportion

say $df.rename('amount' => '金额').names;     # 未改名的列原样保留
say $df.drop(<tmp raw>).names;
say $df.drop-nulls('amount').rows;            # :how<all> 只丢整行全空的
say $df.fill-nulls('amount', :strategy<ffill>);   # 或 :value(0) / mean / median / bfill
say $df.cast(amount => 'DECIMAL(18,4)').gist;     # 表达式级：col('amount').cast('BIGINT')

# 17. 重塑与概览：展开 / 宽长互转 / 透视 / 采样 / 概览
say $df.explode('tags').rows;                  # 列表列展开；空列表/NULL 各留一行 NULL
say $df.explode(<x y>).rows;                   # 多列按位置展开，长度不齐补 NULL
say $df.explode('tags', :!keep-empty).rows;    # 切回 DuckDB 原生：空列表不产行

my $long = $wide.unpivot(<q1 q2>, :index<id>); # id | variable | value
my $pvt  = $long.pivot(:on<variable>, :index<id>, :values<value>);
say $pvt.gist;                                 # 分组值成为列名；:agg<count|max|...>
say $pvt.sample(:n(2), :seed(42)).gist;        # 可复现抽样；:frac(0.5) 按比例
say $df.describe.gist;                         # 每列一行：类型/分位数/空值率等 12 列

# 18. Series：单列入口（v0.19.0）
my $s = $df{'amount'};
say $s.sum;                                    # 读值/聚合直接走 ColumnView
say $s.head(2).sum;                            # 切片后仍可聚合
my @values = $s.list;                          # for $s.list / for |$s 逐值迭代
say $s[0]; say $s[*-1];                        # 下标（*-1 从末尾数）
say $s.unique.to-list;                         # 单列变换：代理回 Frame
say $s.sort(:desc).to-list;
say $s.fill-nulls(:strategy<ffill>).to-list;
say $s.cast('VARCHAR').to-list;
say $s.round(2).to-list; say $s.abs.to-list;   # 数值函数走 Expr
say $s.value-counts.gist;                      # 注意返回 Frame（两列）
say $s.rank.to-list; say $s.cum-sum.to-list;   # 窗口函数

# 19. Series 运算与统计（v0.20.0）—— 用方法，不用运算符
say $s.add(1).to-list; say $s.subtract(1).to-list;
say $s.multiply(2).to-list; say $s.divide(2).to-list;
say $s.gt(15).to-list;                         # 布尔 Series
say $s.isin(10, 30).to-list; say $s.between(10, 20).to-list;
say $s.upper.to-list; say $s.sqrt.to-list;
say $s.median; say $s.std; say $s.std(:ddof(0));  # 标量统计
say $s.nunique; say $s.any; say $s.all;

# 20. 逻辑索引（v0.21.0）—— 显式行号列，不是隐藏 Index
say $df.with-row-index.rows;              # 末尾多一列 index，0 基
say $df.iloc(0).rows;                     # 按位置取；负数从末尾算
say $df.iloc(1..3).rows;                  # Range
say $df.iloc([3,1]).rows;                 # List 保持给定顺序
say $df.loc('city', '北京').rows;         # 按列值定位
say $df{'amount'}.index.to-list;          # Series 的行号列

# 21. 声明式 key 与对齐（v0.22.0）
my $a = $d.sql(q{select * from (values (1,10),(2,20)) as t(id,v)}).set-index('id');
my $b = $d.sql(q{select * from (values (2,5),(3,7)) as t(id,v)}).set-index('id');
say $a.index-cols;                        # (id)
say $a.reindex(2, 1).rows;                # 按给定 key 顺序重排
say $a{'v'}.add($b{'v'}).frame.rows;      # 按 key 对齐：id=1 与 3 为 NULL
say $a.reset-index.index-cols;            # 清空 key 声明

# 21b. 真正的 Index / MultiIndex（v0.28.0）
my $ix = $f.set-index(<city id>);
say $ix.index.names;                      # (city id)
say $ix.index.nlevels;                    # 2
say $ix.index.to-list;                    # (('b',2), ('a',1), ('c',3))
say $ix.loc(('b', 2)).rows;               # 按完整标签定位
say $ix.xs('b', :level<city>).rows;       # 按层横切，该层从索引摘掉
say $ix.sort-index.rows;                  # 按所有 level 排序
say $ix.swaplevel(0,1).index.names;       # (id city)
say $ix.index.is-unique;                  # 标签是否唯一
say $ix.column('amount').index.to-list;   # Series 也拿到同一套 Index

# 22. 二级访问器（v0.23.0）
my $s = $df{'name'};
say $s.str.strip.upper.to-list;           # 字符串：大小写/去空白/切分/正则/切片...
say $s.str.replace(',', '|').to-list;      # 字面前缀：参数走 SQL 字面量
say $s.str.split(',').to-list;             # LIST 列
say $s.str.slice(0, 3).to-list;            # 0 基、stop 不含（pandas 语义）
my $t = $df{'created_at'};
say $t.dt.year.to-list;                    # 部件：year/month/day/hour/.../week/dayofweek
say $t.dt.strftime('%Y-%m').to-list;       # 格式串转义后作字面量
say $t.dt.floor('month').to-list;          # unit 过白名单

# 23. 分组糖（v0.24.0）
say $df.group-by('city').transform(col('amount').sum.alias('total')).rows;
say $df.group-by('city').filter(col('amount').sum.over('city') > 100).rows;
say $df.group-by('city').apply(-> $g { $g.head(1) }).rows;   # 逐组，N+1 查询
say $df.crosstab(:index<city>, :columns<channel>, :normalize<index>).rows;
say $df.pivot-table(:index<city>, :columns<quarter>, :values<amount>,
                    :fill-value(0), :margins).rows;

# 24. 统计与 top-n（v0.25.0）
say $s.corr($df{'other'});                 # pearson；method => 'spearman'
say $s.skew; say $s.kurt;                   # 偏度 / 超额峰度
say $df.corr(columns => <a b>).rows;        # 相关矩阵（首列行标签）
say $df.cov(ddof => 0).rows;                # 协方差矩阵
say $df.nlargest(5, 'amount').rows;         # keep => first / last / all
say $s.nsmallest(3).to-list;

# 25. 读文件补齐（v0.26.0）
my $j = $d.read-json('orders.json');        # JSON 数组 / NDJSON 自动嗅探
my $n = $d.scan-json('events.ndjson', :format<newline_delimited>);
my $x = $d.read-excel('book.xlsx');         # 有 excel 扩展走 read_xlsx
my $p = $d.read-parquet('orders.parquet');  # Parquet 从 v0.4.0 起就有
say $d.describe-excel('book.xlsx');         # sheets / rows / cols

# 26. 常用属性与函数式 API（v0.27.0）
say $df.dtypes;                             # 列名 → DuckDB 类型
say $df.info;                               # 一页文字摘要（返回 Str）
say $df.size; say $df.empty;                # 元素总数 / 是否为空
say $df.where(col('amount') > 100, 0).rows; # 条件为假的格子替换
say $df.mask(col('id') == 2, -1).rows;      # 条件为真的格子替换
say $df.query('amount > ?', 100).rows;      # SQL 片段过滤，值走绑定
say $df.map(-> $v { $v * 2 }, :column<amount>).rows;
say $df.apply(-> $row { $row[1] ~ $row[2] }, :axis(1)).rows;
say $s.map(-> $v { $v + 1 }).to-list;

# 27. 时间序列（v0.27.0）
my $v = $df{'amount'};
say $v.rolling(3).mean.to-list;             # 另有 sum/min/max/count/std/var/median
say $v.rolling(3, :min-periods(3)).mean.to-list;
say $v.expanding.sum.to-list;               # 从头累积
say $v.pct-change.to-list;                  # 变化率，分母为 0 时给 NULL
say $v.ewm(:span(10)).mean.to-list;         # 也可 :alpha / :halflife
say $df.resample('15min', :on<ts>)          # ts 是时间列
       .agg(col('amount').sum.alias('total')).rows;

# 28. 导出（v0.27.0）
say $df.to-json('out.json');                # JSON 数组
say $df.to-json('out.ndjson', :format<newline-delimited>);
say $df.to-excel('out.xlsx', :sheet<Data>); # 纯 Raku XLSX 写出，不依赖扩展
say $df.lazy.to-json('lazy.json');          # 惰性路径同语义

# 29. SQL 库读写与时区/Period（v0.29.0）
my $w = $d.attach-db('warehouse.duckdb', 'wh'); # ATTACH，返回带引号别名
say $d.to-sql('orders', $df, :db<warehouse.duckdb>, :alias<wh>,
              :if-exists<replace>);          # fail / replace / append 三态
say $d.read-sql('select * from wh.orders where id > ?', 5).rows; # 值走绑定
say $d.read-sql-table('orders', :db<warehouse.duckdb>).rows;     # 省去前缀
say $d.scan-sql-table('orders', :db<warehouse.duckdb>).collect.rows;
say $df.to-sql('clean', :db<warehouse.duckdb>);# Frame / LazyFrame 两入口
say $d.list-dbs;                            # 当前挂着的库
$d.detach-db('wh');

my $ts = $df{'ts'};
say $ts.dt.tz-localize('Asia/Shanghai').to-list;      # naive → aware
say $ts.dt.tz-localize('UTC').dt.tz-convert('Asia/Shanghai').to-list;
say $ts.dt.tz-offset('Asia/Shanghai').to-list;        # 偏移小时数：8 / 5.5
say $ts.dt.to-period('M').to-list;                    # 周期起点
say $ts.dt.period-end('M').to-list;                   # 周期终点（最后一秒）
say $ts.dt.period-ordinal('Q').to-list;               # 季序号
say $df.with-column(col('ts').to-period('M').alias('month')).rows;

# 30. dtype 系统：nullable 类型与 Categorical（v0.30.0）
say $df.dtypes;                             # 原始 DuckDB 类型串（老 API 不变）
say $df.schema;                             # 列名 → Duckula::Dtype
say $df.dtype-of('id').name;                # Int32
say $df{'id'}.dtype.gist;                   # Series 的 dtype
say $df.cast('amount' => dtype('Float32')){'amount'}.to-list;
say $df.astype('id' => 'VARCHAR').rows;     # Frame 也有 astype 别名
# 'int64' 遇到 NULL 报错；'Int64' 允许 NULL；:strict 强制检查
say $df.cast('amount' => dtype('Int64'), :strict).rows;
my $cat = $df.cast('label' => dtype('category', categories => <a b>, :ordered));
say $cat{'label'}.cat.categories;           # [a b]
say $cat{'label'}.cat.codes.to-list;        # 按 categories 顺序编码，未知值 → NULL
say $cat{'label'}.cat.ordered;              # True
say $df.lazy.cast('label' => dtype('category')).collect{'label'}.cat.codes.to-list;

# 31. 函数式与对齐长尾（v0.31.0）
say $left.merge-asof($right, on => 'ts').rows;         # 最近的前一行（backward）
say $left.merge-asof($right, on => 'ts', :by<symbol>).rows;  # 分组内匹配
say $left.merge-asof($right, on => 'ts', :direction<forward>).rows;
say $left.merge-asof($right, on => 'ts', :direction<nearest>, :tolerance(2)).rows;
say $left.pipe(-> $f, $n { $f.head($n) }, 5).rows;     # Frame/LazyFrame/Series/GroupBy
say $a.combine-first($b).rows;                         # NULL 用另一 Frame 的同 key 值补
say $s.combine-first($t).to-list;                      # Series 按 key 补齐
say $df.applymap(-> $v { $v * 2 }).rows;               # 逐元素映射
say $df.set-index('id').verify_integrity;              # 重复标签报错，唯一返回 True
say $df.set-index('id').reindex(1, 9, :fill(-1)).rows; # 缺失行补值

# 32. Arrow IPC（v0.31.1）
$df.arrow.write-ipc('out.arrow');        # C Data Interface → IPC 字节
say $d.read-arrow('out.arrow').rows;     # 自往返

# 33. Expr helpers（v0.33.0）：片段仍带列名白名单 / 窗口锚定
use Duckula::Expr;
$df.with-column(case-when(col('v') > 2, 1, :else(0)).alias('big'));
$df.with-column(least(col('v'), 2).alias('lo'));          # DuckDB least()
$df.with-column(greatest(col('v'), 2).alias('hi'));
$df.with-column(coalesce(col('v'), 0).alias('filled'));
$df.filter(isin-subquery(col('v'), 'SELECT col0 FROM (VALUES (2),(3))'));
$df.with-column(lag-default(col('v'), 1, 'g', :order-by<v>, :default(-1)).alias('prev'));
$df.with-column(sql-expr('row_number() OVER (PARTITION BY "g" ORDER BY "v")',
                         'g', 'v', :window('OVER (PARTITION BY "g" ORDER BY "v")')).alias('rn'));
```

`pivot` 的分组值来自数据，所以在建算子时会先跑一次 `SELECT DISTINCT`（这是唯一
一个"立刻读数据"的动词，eager / lazy 都一样）；它不用 DuckDB 原生 `PIVOT` ——
后者被语句分类器判成 MULTI，过不了只读守卫，因此改用条件聚合，列名由我们控制。
`describe` 是「每列一行」，与 pandas 的「每个统计量一行」不同，但多了类型、
近似唯一值数与空值率。

Arrow IPC 的字节由 Duckula 自己编码（一个最小 FlatBuffers 构造器 + Arrow 的
Message/Schema/File 布局），**不需要 DuckDB 的 `arrow` 扩展**。覆盖基本类型、
decimal、date/time/timestamp、list/struct/map、BLOB 以及 ENUM（走 DictionaryBatch）。

FlatBuffers 编解码本身已经拆成独立包 **`Arrow::IPC`**（v0.1.0），不依赖
DuckDB 或 Duckula；Duckula 只保留 DuckDB 类型映射、临时表创建与 Appender
灌入这一层薄适配。Rakuish / DB::DuckDB 要用 Arrow IPC，直接依赖 `Arrow::IPC`
即可。

读侧有两条路，默认走快的那条：

| 路径 | 谁在解码 | 5 万行 × 3 列 | 嵌套列 |
|---|---|---:|---|
| **native**（默认） | DuckDB 的 `nanoarrow` 扩展 + 一条 CTAS | **8 ms** | 真正的 `STRUCT` / `MAP` / `T[]` |
| **raku**（兜底） | `Arrow::IPC` 解字节 + Appender 灌行 | 2.75 s | 先渲染成文本再 cast |

native 就是 `CREATE TEMP TABLE ... AS SELECT * FROM read_arrow(?)`：字节在 C++
里走，Raku 侧一个格都不碰，类型也由 DuckDB 从 Arrow schema 直接落成。扩展没装、
或者设了 `DUCKULA_ARROW_RAKU=1`（也能用 `read-arrow(:native(False))` 单次指定）
时退回纯 Raku 解码，离线环境照常工作。

兜底路径的词汇表是编码那套反着用：FlatBuffers 的 `Type` union 先翻译成 Arrow
format 字符串，再交给 `parse-format` 归一。它仍然支持标量、`List`、`Struct`、
`Map` 的任意互相嵌套；两处有意的降级是 `Interval` 落成文本（Appender 的 cast
不支持 VARCHAR→INTERVAL）、`Duration` 落成 `BIGINT`（保留原始计数）。
`Union` / `RunEndEncoded` 仍明确报错；`FixedSizeList` 在 native 路径下已能读
（落成 DuckDB 的 `ARRAY`），兜底路径仍会报出不支持的列名。

native 读不了的文件会自动落到兜底 —— 已知一种：**零 record batch 的合法空文件**
（DuckDB 报 `Expected continuation token (0xFFFFFFFF) but got 16`，pyarrow 认为
文件没问题），这类文件按空表读出来才是对的。

`ipc-buf` 是 C data interface 裸指针的**跨进程替代品**：指针只在导出它的进程里有
效，而 IPC 字节可以塞进管道、交给 `Inline::Python` 里的 `pa.ipc.open_stream(...)`。

兜底路径下，同一份文件反复 `read-arrow` 时 FlatBuffers 解析与逐 cell 解码只做一次：
缓存的是纯解码产物（列名 / 类型 / 列值），按「路径 + 字节数 + mtime」判失效，
进程内跨 session 共享；建表与 Appender 仍按各自连接重做。native 路径没有 Raku
解码可缓存，计数不会动。可观测与手动清理：

```
say $s.arrow-cache-stats;   # {hits => 3, misses => 1, entries => 1}
$s.clear-arrow-cache;       # 强制下次重解，也释放缓存内存
```

默认拒绝写操作，而且这个判定**来自 DuckDB 自己的解析器**，不是文本匹配：
`duckdb_extract_statements` 拆语句、`duckdb_prepared_statement_type` 定类型、
`duckdb_nparams` 数参数。所以 `PRAGMA database_list` 这种只读语句能放行（正则时代
因为含 `pragma` 一词被误拒），而 `INSTALL` / `SET` / `COPY` / `ATTACH` 各按真实类型拦下。
类型之外还有一层写动词扫描——因为 `WITH d AS (DELETE ... RETURNING *) SELECT ...`
的类型是 **SELECT**、`EXPLAIN ANALYZE DELETE ...` 的类型是 **EXPLAIN**，两条都会真的
改数据。`$s.sql(..., :unsafe)` 显式放开。

Parquet / CSV / JSON 写文件走 `COPY (<select>) TO 'file'`，DuckDB 自己做，一行都不
经过 Raku；写表走 `CREATE TABLE AS` / `INSERT INTO ... SELECT`，数据同样不出库。
`COPY` **不接受绑定参数**，所以路径与表名必须转义（`sql-literal` 单引号双写、
`quote-ident` 双引号双写），带引号的文件名和表名都实测可用。XLSX 是例外：
`to-excel` 自己写一个最小 OOXML 包（stored ZIP + inlineStr），因为 DuckDB 的
`COPY ... (FORMAT XLSX)` 在本机版本上不写表头，读回来会少一行。Raku 闭包
（`map` / `apply` / `ewm`）同样要把值过一遍 Raku，写回时按扫描序 JOIN VALUES
表，显式投影列名以免同名列被 `EXCLUDE` 一起排除。沙箱会话
（`Session.new(:sandbox)`）写文件会被当场拒绝并说清原因，写表不受影响——表不出库。

`Frame` 与 `LazyFrame` 语义完全一致（同一套列名白名单、表达式、聚合、join 规则），
区别只在「什么时候拼 SQL」：`Frame` 每一步立刻套一层 `SELECT`，`LazyFrame` 攒计划树、
`collect` 时融合成一条扁平 SQL。`LazyFrame.arrow` 会先 `collect`——Arrow 的 chunk
就是执行结果本身，没法推迟。惰性路径的 `to-parquet` / `to-csv` / `to-json` / `to-table` 不需要
`collect`：参数渲染成字面量后直接交给 `COPY`，省掉一次取数；`to-excel` 需要
`collect` 拿列名与数据（Raku 写出）。

## 设计原则

1. **不写 DuckDB 交互** —— 全部复用 [`DB::DuckDB`](https://gitee.com/skyter10086/DB-DuckDB)
2. **不拥有数据** —— 数据永远在 DuckDB 的向量里，Duckula 只描述"下一步算什么"
3. **SQL-first** —— 所有算子编译成 SQL，`filter/join/groupby` 由 DuckDB 执行器完成
4. **SQL 可直写** —— `duckula.sql(...)` / `$df.sql("... from self ...")`，
   **不写 SQL 解析器**：解析与优化都交给 DuckDB，只做字符串感知的占位符绑定
5. **默认防注入** —— 值走参数绑定，标识符走 `quote-ident` + 白名单，
   SQL 直写走网关（**DuckDB 解析器判定语句类型** / 写动词扫描 / `enable_external_access=false`）

## 状态

- **v0.53.0**：`Series` 的五个聚合（`sum` / `min` / `max` / `mean` / `count`）
  回到 SQL，并修掉驱动里让这条路以前不可信的三个 bug ——
  - **性能与正确性双修**：1,000,000 行的一列，`Series.sum` 从
    `ColumnView` 路径的 0.80–5.37 s 降到 0.006–0.061 s；HUGEINT 以前求和
    是**错的**（0..9 的和算出 10，负值算出 1.4e20 的垃圾），DECIMAL 以前
    返回有浮点误差的 `Num`，现在是精确的 `Rat`；
  - **驱动 `DB::DuckDB` 1.4.3**：`ColumnView.!agg` 三个缺陷 —— 128 位类型
    （HUGEINT / UHUGEINT / DECIMAL(>18 位)）只读了低 64 位字；VARCHAR /
    DATE / TIMESTAMP 这类非 raw 列的 `min` / `max` 一律 Any；DECIMAL 用
    浮点累加器丢精度，`mean` 还会打 "Use of uninitialized value"；
  - **pandas 语义**（`skipna`）：浮点列的聚合带
    `FILTER (WHERE NOT isnan(col))`，`[1.5, NaN, NULL]` 的五个聚合都返回
    `1.5`、`count` 返回 1；空集/全 NULL 的 `sum` 给 0，`min`/`mean` 给 Any；
    `BOOLEAN` 列的 `mean` 是 True 的比例（`avg(CAST(col AS BIGINT))`，
    DuckDB 没有 `avg(BOOLEAN)`）；
  - **非数值列报错而不是算错**：`VARCHAR` / `DATE` / `TIMESTAMP` 上调用
    `sum` / `mean` 报 `Duckula::X::Series` 并提示先 `cast`，`min` / `max`
    照常可用；
  - **Arrow::IPC 边界维持现状**（独立包、硬依赖、零依赖），只把两条使用约定
    写进文档：`Frame` 必须拥有独立 `Result`；原生编码器与纯 Raku 编码器只
    保证互相可读，不保证字节相等。
  `t/51` 42 项（新增），DB-DuckDB `t/06` 扩到 61 项，ARCHITECTURE 增 §8.62，
  全套 52 文件 **1811 项**。
- **v0.52.1**：v0.52.0 的两处收尾 ——
  - **`*@` slurpy 入口补齐 `reject-named`**：`Session.sql` / `Session.execute`、
    `LazyFrame.sql`、`resample().agg`，以及 `Expr` 的 `over` / `cum-sum` /
    `cum-max` / `cum-min` / `cum-count` / `shift` / `diff` / `rank` /
    `rolling-sum` / `rolling-mean`（共 14 处）以前照样静默吞掉 `:bogus<1>`；
    现在统一报 `Duckula::X::Frame`（`Duckula::TimeSeries` 随之显式
    `use Duckula::Clean`，因为 import 不传递导出符号）；
  - **`read-excel` 的原生兜底有了回归测试**：用 `write-xlsx` 现场造一张
    "`code` 列前三行数字、第五行蹦出字符串 `oops`"的表，先确认原生
    `read_xlsx` 真会报 `Could not convert string 'oops' to DOUBLE`，再断言
    `read-excel` 捕获后退回纯 Raku 解析、4 行一行不少（`code` 整列成
    VARCHAR）。
  `t/50` 从 26 项扩到 40 项，ARCHITECTURE §8.61 补第 9 小节，全套 51 文件
  **1769 项**。
- **v0.52.0**：一轮"静默出错"收口 —— 每一条以前会悄悄给出另一种语义，现在
  要么算对、要么当场 `Duckula::X::Frame` 报错：
  - **`iloc` 不再把同名数据列当行号**：只有 `with-row-index` 标记过的列才
    是稳定行号；数据列恰好叫 `index` 时用临时列过滤、`EXCLUDE` 掉，不泄漏
    到输出（`Frame` / `LazyFrame` 新增 `$!row-index-col` 元数据沿计划树传递）；
  - **`unpivot` 默认保留 NULL 行**（`INCLUDE NULLS`，对齐 pandas `melt`），
    `:!keep-nulls` 回到旧行为；同时修掉旧 `UNPIVOT ... ON` 语句在 DuckDB
    2.0.0 上的 `Parser Error`；
  - **`merge-asof` 的时间键 `:tolerance` 可用**：距离改 `abs(epoch_ms(l) -
    epoch_ms(r))`、容差写成毫秒字面量（旧 `abs(INTERVAL ...)` 会被 DuckDB
    以 "no function matches" 拒绝）；
  - **`sql-literal(DateTime)` 保留微秒**（`.123456` 不再截成整秒 —— 以前带
    微秒的条件在 `filter` 里 0 行，`?` 绑定路径却能命中）；
  - **`read-arrow` 的显式 `:name` 不再静默覆盖**同名表/视图，撞名即报错并
    提示换名；
  - **Arrow 缓存指纹加 ctime**：`rsync -t` / `Copy-Item` 保留 mtime 的覆盖
    不再命中旧缓存；
  - **`read-excel` 原生 `read_xlsx` 推断失败时退回纯 Raku 解析**；
  - **未知命名参数不再被 `*@` slurpy 静默吞掉**：42 处公开算子统一收
    `*%extra` 并调 `reject-named`，`:bogus<1>` 由静默变成报错。
  新增 `t/50-v0520-hardening.rakutest`（26 项），ARCHITECTURE 增 §8.61，
  全套 51 文件 **1755 项**。
- **v0.51.3**：输入文件（Arrow IPC / xlsx）读入的**临时表改为按指纹命名并复用**
  —— 表名由「绝对路径 + 大小 + mtime」派生（Excel 再加 sheet/表头/类型选项，
  Arrow 把 native / 纯 Raku 引擎也编进键），同一个文件重复读会对同名表
  `CREATE OR REPLACE`，不再每读一次攒一张表；文件被改写则换新表，旧 `Frame`
  仍读到旧内容（快照语义）。新增 `t/49-input-tables.rakutest`（8 项）与
  `tools/run-tests.raku`（逐文件跑测试并汇总，Windows/WSL 同一条命令）。
  `t/17` / `t/20` 里"每读一次换表"的断言相应改为"同一文件复用一张表"。
  ARCHITECTURE 增 §8.60，全套 50 文件 **1725 项**。
- **v0.51.2**：原生 IPC 路径的临时视图改为**按调用自增命名**（以前按
  Session 生成，同一会话并发写会撞 `CREATE TEMP VIEW`，异常残留视图会让
  下一次直接失败）；`t/48` 增 3 项锁"调用前后无残留视图、连续两次
  `ipc-buf` 成功"。同时记录两条 xlsx 固有边界（数值单元格是 IEEE double，
  `>2^53` 的整数两种写法都失精度；尾部全 NULL 行按格式语义消失），并**订正**
  0.50 的一条误判：DB::DuckDB 不按 SQL 缓存 Result，之前看到的"旧结果"来自
  仍持活的 Frame/Result 对象。ARCHITECTURE 增 §8.59，全套 49 文件 **1717 项**。
- **v0.51.1**：补上原生 IPC 路径的验证 —— 本机 DuckDB 的 arrow 扩展已可用
  （`DB::DuckDB.arrow-available` 会 `INSTALL`+`LOAD`），`write-ipc` 走的是
  C++ 侧 `to-arrow-ipc`。实测：带可空布尔 / DOUBLE / 列表的 3 行数据，
  原生写 + 原生读与 `rows` 逐值一致；`Arrow::IPC` 的纯 Raku 解码器也能正确
  读 DuckDB 产的文件（含可空布尔与 LIST），两条路径的文件大小一致。
  `t/48` 增 3 项（没有 arrow 扩展的环境自动 skip）。
- **v0.51.0**：P2 边界修复：
  - **`sort-values` 叠 `sort-values` 合并成多键**（`ORDER BY 外层键, 内层键`），
    不再丢掉内层排序 —— 这样才等于 pandas/polars 的稳定排序；
  - **`tail` / `iloc` 的辅助列都避让用户列名**（以前用户列叫
    `__duckula_rn_n` 时 `tail(1)` 返回空、叫 `__duckula_n` 时 `iloc` 会把
    真实列 EXCLUDE 掉）；
  - **`group-by(...).transform()` 拒绝复合聚合**（`(sum/count) OVER ()` 是
    语法错误），提前给出"给每个聚合分别 `.over()`"的提示；
  - **空集 `SUM` 返回 0**（与 pandas/polars 一致，`mean`/`min`/`max` 仍为
    NULL）：只对裸 `sum` 包 `coalesce(..., 0)`；
  - **Excel 解析**支持自闭合 `<row/>` 与 `<si/>`（以前分别会吞掉下一行、
    让共享字符串索引整体错位），并给 ZIP 解压加**单条目 256 MB / 总计 1 GB**
    上限（zip bomb）；
  - ARCHITECTURE 增 §8.58，并记录 **Arrow::IPC 为什么保留为独立包**。
  新增 `t/48-p2-hardening`（10 项），全套 49 文件 **1711 项**。
- **v0.50.0**：P1 生命周期与沙箱修复：
  - **Session 不再强引用 Frame**。以前 `@!frames` 从活的 Session 出发可达，
    Frame 与它的 `Result` 永远不回收；`register-frame` 还是 O(n) 去重，建
    Frame 的总代价 O(n²)。现在只按**视图名**记引用计数，没有视图引用的
    Frame 完全不登记：3000 个派生 Frame 从 ~5 s 降到 **0.12 s**，Frame 也
    可以正常回收。
  - **活 LazyFrame / Frame 依赖的临时视图不再被 `drop-views` 误删**。
    引用挂在计划树的 `ViewRef` 上（派生计划共享同一份），视图计数归零前
    会被跳过；`:force` 才是无条件清空。
  - **被 Guard 拒绝的 `LazyFrame.sql` 不再残留临时视图**（失败即
    `discard-view`）。
  - **沙箱补口**：`:sandbox` 会话下 `write-ipc` / `Arrow.write-ipc` 现在
    明确拒绝（以前能直接写文件）；`:sandbox` 也不再接受借用的 `:conn`
    —— `enable_external_access=false` 运行期不可逆，不能永久废掉别人的连接。
  - **`join(:suffix(''))` 撞名不再死循环**，改成当场报错。
  - **`write-ipc` 非法 `:format` 不再先把目标文件清成 0 字节**：先白名单
    校验，再走临时文件 + 改名，编码失败也不毁旧文件。
  注意：视图引用计数的归还在 `DESTROY` 里，而 Rakudo 的 GC 时机不确定
  （普通对象常常到进程退出才触发），所以 `drop-views` 默认保护可能"多保护
  一段时间"；要立刻清干净用 `drop-views(:force)`。新增 `t/47-p1-hardening`
  （24 项），全套 48 文件 **1701 项**。
- **v0.49.0**：P0 隐患排查与修复（10 组）—— 三路代码审查 + 逐条实测，修掉一批
  "不报错但结果错"的问题：
  - **共享 `:conn` 的两个 Session 建同名临时视图**、后者覆盖前者，派生 Frame
    读到另一个会话的数据（视图名改为进程级单调序号）；
  - **lazy 的 Project 叠在 Sort 之上不物化**：DuckDB 把裸列 `ORDER BY` 重绑到
    输出别名，`cast` / `fill-nulls` / `with-column` 会悄悄换掉排序键；
  - **Expr 组合丢 `window` / `is-aggregate` 元数据**（`+`、`cast`、`not`、
    `coalesce`、`case-when`、`isin-subquery`）→ `with-column` 不再锚定行序、
    `agg(sum.cast('DOUBLE'))` 被误拒；
  - **Raku 的 `Rat` 字面量被 `.Str` 截成 6 位小数**：`3 * (1/3)` 得到
    `0.999999`；改为有限小数精确渲染、循环小数用浮点除，并补上 `Date` /
    `DateTime` 字面量与绑定参数；
  - **`Session.sql` 先执行后渲染**：写操作已提交却对外抛异常（`render-bindings`
    挪到 `query` 之前）；
  - **`close` 后继续用会静默重开空库**：新增 `closed` 状态，所有入口经 `conn`
    取值时明确报错；
  - **定长 `ARRAY` 列静默变文本、`UNION` 列静默变 NULL**：按 `ColumnView.tid`
    识别（两者 type 名都是 `UNKNOWN`）；ARRAY 走 `:typed` 真值，UNION 明确
    拒绝；
  - **Excel 兜底读**：大整数被推成 DOUBLE（`9007199254740993` 变
    `...992`）、空白单元格变空串；现在只有超出 2^53 才用 BIGINT/HUGEINT，
    空白回 NULL；
  - **Excel 写出控制字符**：兜底写当场报错（不再产出读不回来的坏 XML）；
    原生 `COPY ... (FORMAT XLSX)` 路径改为 **临时文件 + 产后自检 + 改名**，
    失败不毁原文件；
  - **可空 `BOOLEAN` 的 IPC 写出把 true 写成 false**。根因在
    `Arrow::IPC`：`clear-bits` 把 Raku 的字符串化 `~` 当成按位取反，
    "清 null 位"实际成了"只保留 null 位"。已在 **Arrow::IPC 0.1.3** 修复并
    加回归，本包依赖提到 `0.1.3+`。
  新增 `t/46-p0-hardening`（28 项）钉住以上行为，全套 47 文件 **1677 项**。
- **v0.48.2**：文档补齐 —— 0.38.0–0.48.1 共 11 个版本的代码改动都没有对应的
  文档条目，README「状态」与 ARCHITECTURE 停在 0.37.0 / §8.44。这次按
  `git show` 的改动逐条补上 §8.45–§8.54（嵌套真值、公共解码器、入口只查一次、
  LIMIT 屏障、Series 行数对齐、聚合下推的尝试与回退、批量列解码、安全与
  生命周期、原生 IPC、单次 Appender）。同时**订正 §8.44 的一条错结论**：
  本机实测 DB::DuckDB 1.4.1 的
  `ColumnView.to-list` 对 HUGEINT / DECIMAL **仍返回十进制字符串**
  （`-1::HUGEINT` → `"-1"`），所以 `Duckula::Decode` 不是"多余的安全网"，
  而是必需的解码层，删掉它 `rows` / `Series.to-list` 立刻退回字符串。
  README 的依赖段与 `META6.json` 对齐（此前还写着 1.0.1 / 1.1.0），
  删掉"`LazyFrame` 与写入仍待实现"这句过期话，`HANDOFF.md` 按 0.48.x 重写。
  全套 46 文件 1649 项。
- **v0.48.1**：`read-arrow` 灌库改从 `conn.appender($table)` 拿 Appender ——
  0.48.0 里 `use DB::DuckDB::Appender` + `Appender.open(conn, $table)` 在
  `Session.conn` 收窄返回类型后拿到的 native handle 类型不对。顺带把
  `Session.conn` 的返回类型从 `Mu` 精确到 `DB::DuckDB`，`to-arrow-ipc` /
  `appender` 这些原生方法才在类型检查下可见。全套 46 文件 1649 项。
- **v0.48.0**：`read-arrow` 从「4096 行一批 `Session.insert`」改成**一次 Appender
  灌完** —— 解码后的列本来就全部常驻内存，分 chunk 只会多开事务、反复开关
  handle；Appender 自带事务，`free` 时 flush + commit，整批原子。配套把
  `Session.conn` 的返回类型写成 `DB::DuckDB`。
- **v0.47.0**：`write-ipc` / `ipc-buf` 优先走 **DB::DuckDB 原生 `to-arrow-ipc`**
  （C++ 侧直接出 IPC 字节：5 万行 × 3 列 0.009 s，Raku 侧 `Arrow::IPC` 编码
  0.075 s，**8×**）。原生路径用临时 VIEW 包住 `relation-sql`，取完字节立刻
  `DROP VIEW`；`conn.arrow-available` 为假时自动退回 Raku 编码。`format`
  参数只在兜底路径生效（原生总是 file 格式 IPC）。
- **v0.46.0**：安全网关补口 + 临时视图生命周期 —— `read-arrow` /
  `describe-arrow` 要碰文件系统，补上与 `read-excel` 对称的沙箱检查；
  `create-table` / `to-sql` 的 **Str 源**过 `check-sql` 网关（`:params(0)`
  `:strict(False)`），Frame / LazyFrame 源来自自家 SQL 渲染仍信任。`Frame`
  在 BUILD 时从 `relation-sql` 提取 `__duckula_view_N` 引用并向 `Session`
  注册、DESTROY 时注销；`drop-views` 默认跳过被活 Frame 引用的视图
  （`:force` 才是无条件清空），避免 `LazyFrame.sql` 绑的视图被 DROP 后
  Frame 悬空成 `Table does not exist`。
- **v0.45.0**：三处收口 —— `Frame!ensure-result` 抽成最底层
  （`ensure-views` / `ensure-names` / `rows` / `column` 全部委托它）；
  `Arrow.from-frame` 保留**独立** query（试过共享 Result，`t/13` 第 74 行
  立刻暴露 `Arrow.free()` 让 Frame 的 Result 悬空）；`Series.sum` / `min` /
  `max` / `mean` / `count` **从 0.43.0 的 SQL 下推退回 ColumnView** ——
  提交说明的理由是"类型正确 + 不触发物化"比那点延迟更重要（见 §8.50）。
- **v0.44.0**：`RowsView.Array` / `.List` 的全量解码从「逐格 `view.at()`」
  改成「每列一次 `column-decode`」—— 20 万行 × 36 列原来是 720 万次
  `at()` 函数调用，每次带边界检查 + 指针计算；标量列现在整列 `to-list`
  一次拿完，再在 Raku 侧 map 还原类型。5 万 × 5 列 `rows.Array` 3.2 s，
  惰性单行索引不变（1000 次 `row[12345]` 0.13 s）。
- **v0.43.0**：`Series` 聚合尝试下推 SQL（`SELECT SUM(col) FROM (rel)`），
  省掉「整列解码进 Raku 再遍历」，20 万行 × 36 列 0.317 s / 486 MB →
  DuckDB 内部 0.05 s / 2 MB。**此改动在 0.45.0 被回退**，取舍见 §8.50；
  `median` / `std` / `skew` / `kurt` / `quantile` / `nunique` / `product` /
  `mode` / `any` / `all` 仍走 `!scalar`（ColumnView 没有对应原生实现）。
- **v0.42.0**：`where` / `mask` 接受 Series 条件时补**行数一致性检查** ——
  两边靠 `row_number() OVER ()` 锚定行号再 JOIN，行数不同（filter /
  group-by / limit 派生的 Frame）时序号会静默错位：self 的第 2 行拿到
  原表第 3 行的条件值。现在 `$cf.elems != self.elems` 直接拒绝，并提示
  改用 Expr 或 SQL 字符串。行数不变的 `with-column` 派生 Frame 照常可用。
- **v0.41.0**：惰性路径的 **LIMIT / OFFSET 屏障** —— `head(10).filter(...)`
  在 eager 路径是「先截断再筛」，lazy 路径却因为 `Query.locked` 只把
  select / group 当屏障，把 WHERE 拼进 LIMIT 同一层，变成「全表筛完再取
  10 行」。`locked` 加入 `limit` / `offset` 后两条路径语义一致。
- **v0.40.0**：入口二次执行消除 —— `Session.sql` 已经 query 过
  `relation-sql` 并把 Result 存进 Frame，`rows()` 在 0.37.0 惰性化时却
  自己硬写了一段 query，1 GB CSV / 亿级 Parquet 白跑第二遍。改为统一走
  `!ensure-names` + `!ensure-views`；`column()` 优先从已缓存的整表
  column-views 按索引取列，**零额外查询**。`.sql(...).rows`、
  `.column('x')`、`.column('x').rows` 都只执行一次。
- **v0.39.0**：解码逻辑抽成公共模块 **`Duckula::Decode`**
  （`type-decode-kind` / `val-decode` / `column-decode`），`Frame`、
  `RowsView`、`Series` 共用同一份。`Series.to-list` 不再直接透传
  `ColumnView.to-list`：HUGEINT → `Int`、DECIMAL → `Rat`、嵌套列 → 真值，
  和 `rows` 完全一致。顺带补上 0.38.0 漏同步的 `Duckula.rakumod` 版本号。
- **v0.38.0**：嵌套类型（LIST / ARRAY / STRUCT / MAP / UNION / ENUM）返回
  **真值**而非文本 —— 依赖 DB::DuckDB 1.4.0 的 `ColumnView.to-list(:typed)`，
  原来 `[1, 2]` / `{'k': 1}` 只是 DuckDB 的 VARCHAR 渲染。`Frame` 新增
  `columns-typed` 列式接口（Rakuish 的 `table-from-frame` 用，省掉行→列
  转置）；`rows` 里嵌套列按 kind=3 整列解码并缓存。
- **v0.37.0**：`$df.rows` 惰性化 —— 未物化时返回 `Duckula::RowsView`（独立模块
  `lib/Duckula/RowsView.rakumod`），实现 `Positional` + `Iterable` 角色。RowsView
  内部只持有 Result + ColumnViews（不预先解码任何列），取值发生在访问时：

  | 场景 | 惰性化前 | 惰性化后 |
  |---|---|---|
  | `rows.elems` | 触发全量物化 3.99 s | ColumnView 元数据 **13 ms** |
  | `rows[0]` | 同上 | 逐列 `at()` 组装 **2 ms** |
  | `rows.head(5)` | 同上 | 只解 5 行 **1 ms** |
  | `rows.Array` | 已物化走缓存 | 逐行 `at()` 全量 2.0 s |

  核心约束：DB::DuckDB 要求 `column-views` 只能是 Result 的"第一个 reader"，
  所以 `Frame` 只在 rows 第一次被调用时 query + 拿 column-views，之后缓存到
  `@!views`。RowsView 也必须持有 Result 引用防止 GC 掉后 ColumnView 悬垂。

  类型还原：DB::DuckDB 1.3.1 的 `ColumnView.at()` / `to-list()` 对 HUGEINT
  和 DECIMAL 仍返回字符串（补码扩展只修了内部表示，解码层没改）。RowsView
  在构造时扫一遍 `view.type` 记住每列要转成什么（Rat / Int / 原样），
  `!row()` 里逐元素转换 —— 和 `Frame.!decode-column` 逻辑一致。

  行为变化：
  - `$df.rows` 不再触发 `!materialize`（`$MATERIALIZATIONS` 计数器不动）
  - `rows.Array` / `rows.List` / `rows.to-list` / `rows.raku` / `rows.gist`
    才强制全量解码
  - `rows.elems` 从 ColumnView 元数据拿，零成本
  - 已物化 Frame 的 rows 直接返回 `@!rows.List`，零变化

  新增 `t/45-decimal-128.rakutest`（P0，已在 v0.36.3 引入），`t/41-elems-count`
  适配了 rows 惰性化的计数断言。

- **v0.36.3**：跟进 DB::DuckDB 1.3.1 修复 —— 128 位负数（DECIMAL / HUGEINT）
  由两个 64 位字拼成，旧实现把高字当无符号读，`(-0.0001)::DECIMAL(20,4)` 变成
  `34028236692093846346337460743176821.1455`。Duckula 侧代码不用改（上游已修），
  但依赖必须提到 `DB::DuckDB:ver<1.3.1+>`，否则 `Frame.rows` 走 ColumnView
  物化路径时仍会静默给出天文数字。顺带发现 **Series.to-list 的类型还原已在
  上游修复**：DECIMAL 列走 ColumnView 现在直接还原成 `Rat`、HUGEINT 还原成 `Int`，
  不再是十进制字符串 —— ARCHITECTURE §8.43 末尾那条已知差异（"等 Series 统一
  类型还原时再改"）已经不成立了。新增 `t/45-decimal-128.rakutest`（10 项），
  锁死负 DECIMAL / HUGEINT / UHUGEINT 在 `rows` 与 `Series.to-list` 两条路径上
  的还原正确性，以及 NULL 混合。

- **v0.36.2**：`$df.column('x')` 不再为取一列把整张表算出来。以前它内部跑的是
  `relation-sql` 本身（即 `SELECT *`），宽表场景白算几十列 —— 20 万行 × 36 列
  实测 0.485 s / 592 MB；现在收窄成 `SELECT "x" FROM (rel)`，让 DuckDB 做
  **投影下推**（列存下只读那一列的 segment，其它列既不解压也不计算），同一
  测量降到 0.317 s / 486 MB，且 `column()` 依旧不触发物化。列名走
  `quote-ident`，空格 / 双引号 / 括号都不会变成注入点；列名写错时补查一次
  schema，报出候选列表而不是 DuckDB 的 binder 原话。新增
  `t/44-column-projection.rakutest`（15 项）。
- **v0.36.1**：修 `zef install .` 在测试阶段挂掉（`read-excel` 报
  `xlsx: cannot inflate a ZIP entry (zlib rc=-3)`）。根因是进程里同时存在
  **两份 zlib**：`Compress::Zlib::Raw` 用它打包在 resources 里的那份
  （`zlibVersion()` 回 `1.4`），而 `Duckula::ExcelWrite` 的 native `crc32`
  另外 dlopen 了系统 `libz.so.1`（`1.3.1`）。`z_stream` 的 state 由其中一份
  创建、被另一份解释，700 字节的 XML 也会 `Z_DATA_ERROR(-3)`。所以
  `use Duckula::ExcelRead` 单独跑是好的，`use Duckula`（带进 ExcelWrite）
  就必挂 —— 而 zef 测试正是后者。现在 crc32 **直接调用 `Compress::Zlib::Raw`
  自己导出的那个**（和 `inflate` 共用同一个 `find-lib`，天然同源，不用管版本
  也不用猜资源路径）；
  新增 `t/43-excel-zlib.rakutest`（8 项）守着「加载 Duckula 后仍能解压」和
  「写→读往返 CRC 自洽」。顺带补上 0.36.0 漏改的 `$VERSION` 常量。
- **v0.36.0**：`read-arrow` 默认把字节交给 DuckDB（`nanoarrow` 扩展 +
  `CREATE TEMP TABLE ... AS SELECT * FROM read_arrow(?)`）。5 万行 × 3 列从
  2.75 s 降到 8 ms，嵌套列落成真正的 `STRUCT` / `MAP` / `T[]` 而不是文本，
  `FixedSizeList` 也从「报错」变成能读（DuckDB 的 `ARRAY`）。纯 Raku 解码
  保留为兜底（`DUCKULA_ARROW_RAKU=1` / `:native(False)`），离线可用；
  native 读不了的文件（例如零 record batch 的空文件）自动落回它。
  缓存统计因此只反映兜底路径。
- **v0.35.5**：`gist`（REPL 里 `say $df`）按 pandas 那套截断。此前它是
  `self!materialize` + 全量排版 —— 86 万行的表一 `say` 就是十几 GB 解码再刷屏。
  现在 `LIMIT` 下推到 SQL：行数 ≤ 60（pandas 的 `display.max_rows`）全显示，
  超过就只取前 5 行并补一行 `… N more rows`，末尾固定给
  `[N rows x M columns]`；想多看用 `$df.gist(20)`。总数那个 `N` 只在真被截断时
  才多跑一次 `count(*)`。实测 100 万行 × 4 列：**10.49 s / 物化 +1 → 0.025 s /
  物化 +0**。新增 `t/42-gist-truncate.rakutest`（33 项）。
- **v0.35.4**：`shape` / `size` / `empty` 彻底摆脱「数一次就搬一次表」。
  这三个本来就是 `elems` 的包装（`shape` = `(elems, names.elems)`、
  `size` = `elems × 列数`、`empty` = `elems == 0`），v0.35.3 之后它们跟着
  变便宜；本次再把 `empty` 拆出来单独做**存在性探测**——它只关心「有没有行」，
  不需要那个数字，因此走 `SELECT 1 ... LIMIT 1` 而不是 `count(*)`：
  Parquet 只读一个 row group、CSV 只扫第一个 chunk，亿级关系上差别是「探一行」
  和「数完」的区别。`info` 本来就只发 count 查询（不物化），未改。
  诊断探针实测五种形状（`range(20 万)` / values / `head(0)` / 全滤掉 /
  group-by）`shape`+`size`+`empty`+`elems` 一次跑完 **物化计数 +0**。
  `t/41` 扩到 30 项。
- **v0.35.3**：`$df.elems` 不再物化整张表。此前 `elems`（以及 `shape` /
  `empty` / `size`）走的是 `self!materialize; @!rows.elems`——为了数一个行数，
  先把全部行经 ColumnView 解码成 Raku Array-of-Array，86 万行 × 36 列就是
  十几 GB。现在只发一条 `SELECT count(*) FROM (<relation>)`，数字由 DuckDB
  数，Raku 只收一行一列；已物化的 Frame 直接数内存里的行。新增诊断计数器
  `$Duckula::Frame::MATERIALIZATIONS`（物化次数），`t/41-elems-count.rakutest`
  用它在 values / range(20 万) / filter / group-by / join / 空表 / 全 NULL
  七种形状上断言「取行数不搬数据」（24 项）。实测 100 万行 × 4 列：
  `rows.elems` 12.29 s → `elems` 0.055 s。顺带修掉 `Write::count-rows`
  （`to-parquet` / `to-csv` / `to-table` 的返回值）的旧账：裸
  `count(*)` 的 `.value` 在 nullable BIGINT 上会偶发读成 0，改用
  `CAST(... AS VARCHAR)` 中转。
- **v0.35.2**：读侧补齐坏文件防护（Gitee issue `IKXKJU`）。`read-arrow` /
  `describe-arrow` 之前遇到损坏的 `.arrow` 会**段错误退出整个宿主进程**
  （rc=139），Raku 的 `try` / `CATCH` 接不住——REPL 用户只要给一个坏文件
  就能让宿主消失。根因在 `Arrow::IPC` 读侧按文件里给的偏移和长度直读原生
  指针；依赖升到 `Arrow::IPC:ver<0.1.2+>`（每一次取字节都过边界断言，
  file/stream 校验合并成一份），坏文件现在只会抛可捕获的异常。新增
  `t/40-ipc-bounds.rakutest`（6 项）。
- **v0.35.1**：修复 `ipc-buf` 对 `TIMESTAMP WITH TIME ZONE` 列产出非法
  FlatBuffers 字节流（Gitee issue `IKXKJW`，pyarrow `open_stream` 报
  `Invalid flatbuffers message`、`Arrow::IPC::decode-ipc` 段错误）。根因在
  `Arrow::IPC` 写侧：timezone 是 FlatBuffers string 字段，必须先写字符串拿
  偏移、再用 uoffset 引用，原实现直接把字符串内容塞进 table 槽位。依赖升到
  `Arrow::IPC:ver<0.1.1+>`，并修正 Time/Timestamp/Interval/Duration 的
  `unit` 默认值与必填性。新增 `t/39-ipc-timestamptz.rakutest`（4 项，含
  pyarrow 跨语言验证）。
- **v0.35.0**：依赖升级 + Excel 读写全面原生化。依赖更新到
  `DB::DuckDB:ver<1.2.2+>` / `Alien::Libduckdb:ver<1.2.1+>`，Windows 默认
  使用官方 `windows_amd64` 预编译 DLL，DuckDB 2.0.0 自带 `excel` 扩展，
  **不再需要 Python duckdb**。读侧 `Session.read-excel` 直接走原生 `read_xlsx`
  （9.5MB / 18,525 行约 1.1 秒）；写侧 `to-excel` 默认走原生
  `COPY ... (FORMAT XLSX, HEADER true)`，数据一行不进 Raku，18,525 行读写
  往返约 1.8 秒。自定义 sheet 名或无扩展时才回退纯 Raku，rows/names 改为
  惰性取值。v0.34.0 的 Python CSV 快路径降级为显式 `DUCKULA_XLSX_PY=1`
  开启的可选加速。
- **v0.34.0**：`read-excel` 性能根治。大 xlsx 自动探测带 Excel 扩展的 Python
  duckdb，先转 UTF-8 CSV 再交给 DuckDB `read_csv`；9.5MB / 18,525 行实测
  **1.89 秒**（此前纯 Raku 解析 905MB sheet XML 约 4 分钟）。路径、表名都经
  argv/SQL 转义传入，`:all-varchar`、`:sheet`、`:header` 语义与纯 Raku 兜底一致。
  可用 `DUCKULA_PYTHON` 指定解释器、`DUCKULA_XLSX_PY_MIN` 调整阈值（0 强制）、
  `DUCKULA_XLSX_PY_DISABLE=1` 关闭；`$LAST-READER` 记录实际路径。
- **v0.33.1**：`to-excel` 性能。ZIP stored 模式的 CRC32 从纯 Raku 逐字节循环
  换成 zlib 原生调用（有 fallback），9MB sheet 的写出从 ~21 秒降到 ~2 秒；
  列字母改为预计算。85k→836k 行的 Excel→SQL→Excel 全流程实测 31 秒。
- **v0.33.0**：Expr helpers。新增 `sql-expr`（带列名白名单 / 窗口标记的原生片段）、
  `case-when`、`least`、`greatest`、`coalesce`、`isin-subquery`、`lag-default`
  （ibis `lag(n, default)` 的直接对应）。新增 `t/37-expr-helpers.rakutest` 21 项。
- **v0.32.0**：Arrow IPC 拆成独立 `Arrow::IPC` 包；Duckula 变为类型映射 + 灌表薄适配，行为不变。
- **v0.31.1**：Arrow IPC  rakupp 兼容。写出侧 `ArrayView.buffer/children` 与
  读侧 `Bytes` 的指针统一归一化（`CArray[Pointer]` 在 rakupp 下返回
  `CArray[int64]`），`DB::DuckDB` 同步升到 1.2.1；`t/14-arrow-ipc` 在
  rakupp 下从写不出文件变为全绿。
- **v0.31.0**：函数式与对齐长尾。新增 `merge_asof`（DuckDB 原生 ASOF JOIN 的
  backward/forward + `by` + tolerance，nearest 用距离排序兜底，eager/lazy
  同语义），`pipe`（Frame/LazyFrame/Series/GroupBy）、`combine-first`（按 key
  FULL OUTER JOIN 后 coalesce）、`applymap`、`verify_integrity` 与
  `reindex(:fill)`。同时修正纯元数据算子（set-index/swaplevel 等）丢失 dtype
  元数据的问题。共 1507 项回归测试。
- **v0.30.0**：dtype 系统。新增 `Duckula::Dtype`：`dtype()` 接受 pandas/numpy
  别名、带时区的 `datetime64[ns, Zone]` 与原始 DuckDB 类型名；`.schema` /
  `.dtype-of` / `Series.dtype` 返回带 `nullable` / `categories` / `ordered`
  的 dtype 对象（`.dtypes` 仍返回原始类型串，老 API 不变）。小写 numpy 风格
  dtype 在 cast 时真的检查 NULL，`Int64` 等扩展 dtype 放行，`:strict` 可强制
  检查。Categorical 物理存 VARCHAR，`cat.categories` / `cat.ordered` /
  `cat.codes` 提供编码，类别未指定时从数据推断；eager 与 lazy 语义一致，
  类别值走 `sql-literal` 防注入。共 1473 项回归测试。
- **v0.29.0**：SQL 库读写与时区/Period。`read-sql` / `read-sql-table` /
  `scan-sql-table` 走 DuckDB 原生 `ATTACH` 外部 `.duckdb` 库（不用扩展），
  `to-sql` 对齐 pandas 的 `if_exists` 三态（fail / replace / append），
  Frame/LazyFrame/Session 三入口；`dt.tz-localize` / `tz-convert` / `tz-offset`
  和 `dt.to-period` / `period-end` / `period-ordinal` 补齐时区与 Period，
  表达式层同步可用。共 1415 项回归测试。
- **v0.28.0**：真正的 Index / MultiIndex。`Frame.index()` / `Series.index()`
  返回 `Duckula::IndexLabels`：`names` / `name` / `nlevels` / `to-list` /
  `rows` / `is-unique` / `contains` / `get-level-values`。新增 `loc(标签)`、
  `xs`、`sort-index`、`swaplevel`、`droplevel`，`set-index(:append)` 与
  `reset-index(:level)`；旧的行号 Series 形态（`:name` / `:offset`）保持不变。
  level 仍是普通 DuckDB 列，lazy/eager 同语义，共 1357 项回归测试。
- **v0.27.0**：按 pandas 差距清单补齐三块。① `Frame` 常用属性与函数式 API：
  `dtypes` / `info` / `size` / `empty`、`where` / `mask` / `query`、
  `map` / `apply` 以及 Series 同名方法；Raku 闭包算出的值经 VALUES 写回
  DuckDB，保持原行序与列序（NULL 不经闭包）。② 时间序列：`rolling(w)` 返回
  对象，支持 mean/sum/min/max/count/std/var/median、`:center` 与
  `:min-periods`；`expanding`、`pct-change`（除零给 NULL）与 `ewm`
  （span/alpha/halflife、adjust、min-periods）；`resample(rule, :on<col>)`
  把子日频率下推到 `time_bucket`、日以上用 `date_trunc`，再接现成的
  group-by。③ 导出：`to-json` / `to-excel`（eager 与 lazy 同语义）。
  XLSX 一律走纯 Raku 写出——实测本机 DuckDB 的 `COPY ... (FORMAT XLSX)`
  不写表头，读回会少一行——生成 stored ZIP + inlineStr，无需 zlib，
  sheet 名被校验后写进 workbook。共 1273 项回归测试。详见
  ARCHITECTURE §8.25–8.27。
- **v0.26.0**：读文件补齐。`read-json` / `scan-json` 走 DuckDB 的
  `read_json_auto`，路径绑定参数，`format` / `records` / `ignore-errors`
  等选项全部过白名单或 `sql-literal`；`read-excel` / `scan-excel` 优先用
  DuckDB `excel` 扩展的 `read_xlsx`，没有扩展时（Windows mingw 构建官方仓库
  没有 `excel`）回退到纯 Raku 的 XLSX 解码 + 临时表，支持 sharedStrings /
  inlineStr / 数字 / 布尔，日期按 Excel 序号读出；`describe-excel` 只看骨架。
  Parquet 的 `read-parquet` / `scan-parquet` 从 v0.4.0 就有，本版补了惰性
  路径的回归测试。共 1175 项回归测试。详见 ARCHITECTURE §8.24。
- **v0.25.0**：统计与 top-n。`corr/cov/skew/kurt` 覆盖 Series 与 Frame；
  相关/协方差矩阵首列是行标签（声明为 key），`spearman` 用秩子查询，
  `ddof` 对齐 pandas 的样本/总体语义；`nlargest/nsmallest` 支持多列排序与
  `keep=first/last/all` 三种破平局策略。跨 Frame 的相关沿用 `set-index` 的
  按 key 对齐。详见 ARCHITECTURE §8.23。共 1144 项回归测试。
- **v0.24.0**：分组糖。`group-by.transform` 把组内聚合用 `OVER` 广播回每行，
  `group-by.filter` 用窗口谓词保留整组，`group-by.apply` 逐组调 Raku 函数
  再 UNION ALL 拼回（N+1 次查询，明确标注代价）；`crosstab` 支持四种
  normalize 与加权，`pivot-table` 默认 mean、支持 fill-value 与 margins
  （GROUPING SETS，合计行置底）。eager / lazy 同语义。详见 ARCHITECTURE §8.22。
  共 1083 项回归测试。
- **v0.23.0**：`Series.str` / `Series.dt` 访问器，对标 pandas 的二级命名空间。
  字符串族覆盖大小写、去空白、字面/正则匹配与替换、抽取、切分、切片、补位；
  时间族覆盖年/月/日/时/分/秒/毫秒/微秒/季度/周/星期、DATE/TIME 转换、
  `floor` 截断、`strftime`、`epoch`、月末。语义对齐 pandas：0 基切片、
  Monday=0 的星期、毫秒/微秒只取小数部件。参数全走 SQL 字面量、函数名写死
  或过白名单。详见 ARCHITECTURE §8.21。共 1036 项回归测试。
- **v0.22.0**：声明式 key 与按 key 对齐。`set-index` / `reset-index` / `reindex`
  把真实列声明为逻辑 key（元数据随所有算子传播，`rename`/`drop` 会同步更新）；
  两边有相同 key 的 Series 可以直接做四则/比较运算，走 FULL OUTER JOIN 按 key
  对齐，独有 key 的结果是 NULL；没有 key 仍拒绝跨 Frame 运算。惰性路径同语义。
  详见 ARCHITECTURE §8.20。共 973 项回归测试。
- **v0.21.0**：显式逻辑索引。不再说「Duckula 没有 index」——准确的说是没有
  **隐藏** Index。`with-row-index` 把 0 基行号作为一列显式产出（Polars 风格），
  `iloc` 支持 Int / Range / List（负数从末尾算，List 保持给定顺序），`loc` 按列值
  定位，`Series.index` 拿到仍是 raw 的 ColumnView。行号跟着行走，不需要在派生时
  传播元数据；全部翻译成 SQL。详见 ARCHITECTURE §8.19。共 938 项回归测试。
- **v0.20.0**：Series 运算与统计。算术（`add`/`subtract`/`multiply`/`divide`/
  `mod`/`power`/`negate`）、比较（`eq`/`ne`/`gt`/`lt`/`ge`/`le`）、成员判断
  （`isin`/`between`/`is-null`/`not-null`）、字符串与数学函数、描述统计
  （`median`/`std`/`var`/`quantile`/`nunique`/`product`/`mode`/`any`/`all`）。
  用方法而非运算符：Raku 核心算术 multi 的分派会抢走 `$s - 1`，详见 §8.5。
  没有 key 的跨 Frame 运算拒绝；两边 `set-index` 相同 key 后按 key 对齐。
- **v0.19.0**：Series API 补齐。读值/聚合仍直连 ColumnView，变换/运算全部
  代理回来源 Frame 与 Expr —— 不写列计算代码，NULL 传播与类型提升交给 DuckDB。
  新增 Raku 协议（`iterator` / `.list` / `AT-POS` / `.Array` / `Bool`）、切片
  （`head` / `tail` / `reverse`）、单列变换（`unique` / `value-counts` / `sort` /
  `drop-nulls` / `fill-nulls` / `cast`/`astype` / `round` / `abs` / `clip`）与
  窗口代理（`rank` / `shift` / `diff` / `cum-*` / `rolling-*`）。
  `for $s` 只迭代一次是 Raku scalar itemize 的固有行为，逐值要写 `for $s.list`。
- **v0.18.0**：`read-arrow` 解码缓存。重复的 `read-arrow` 不再重解 FlatBuffers：
  进程级缓存纯解码产物（`names` / `types` / `cols`），按「绝对路径 + 字节数 +
  mtime」判失效，跨 session 共享（解码结果与连接无关）。刻意**不**缓存字节窗口
  （`Buf`/`Bytes`/`Tbl`，会把整个文件钉在内存）、schema 对象、临时表（属于连接）。
  命中后仍各自建表 + Appender，上限 8 个文件 FIFO 淘汰，`Lock` 保护。新增
  `$s.arrow-cache-stats` / `$s.clear-arrow-cache`。共 812 项回归测试。
- **v0.17.0**：阶段 11 第二批 —— 重塑与概览。五个动词在 `Frame` 与 `LazyFrame`
  上各一套、语义一致：`explode`（列表列展开，默认保留空列表/NULL 为一行 NULL，
  多列按位置 zip）、`unpivot`（宽转长，走 DuckDB 原生 UNPIVOT）、`pivot`（长转宽，
  分组值成列名，聚合函数走白名单）、`sample`（`:n`/`:frac` + `:seed` 可复现）、
  `describe`（SUMMARIZE，每列一行 12 列）。SQL 构件集中在 `Duckula::Reshape`。
  `pivot` 不用 DuckDB 原生 PIVOT —— 它被语句分类器判成 MULTI 过不了只读守卫，
  改用条件聚合，代价是建算子时要先 `SELECT DISTINCT` 拿分组值。共 782 项回归测试。
- **v0.16.0**：阶段 11 第一批 —— 清洗与重塑。八个动词在 `Frame` 与 `LazyFrame`
  上各一套、语义一致：`concat`（`UNION ALL BY NAME`，按名字对齐，`:strict` 要求
  列名完全一致）、`unique`（`first` / `last` / `none` / `any`，前三种**保持行序**）、
  `value-counts`（`:normalize` 加占比列）、`rename`、`drop`、`drop-nulls`（`:how<any|all>`）、
  `fill-nulls`（`:value` 或 `ffill` / `bfill` / `mean` / `median`）、`cast`（列级
  `$df.cast(id => 'VARCHAR')`，表达式级 `col('id').cast('BIGINT')`）。
  SQL 片段集中在新的 `Duckula::Clean`（纯函数），eager 与 lazy 各自套壳；能表达成
  投影/过滤的进计划树（`drop-nulls` 会与相邻 filter 合并成一个 `WHERE`），
  需要集合运算或行序锚的退化成 `Source`。类型名过白名单 —— `CAST(x AS ?)` 不成立，
  类型只能拼文本。共 730 项回归测试。
- **v0.15.0**：嵌套类型读入 + 字节可复现。`read-arrow` 现在能读 `Struct` /
  `Map` / `List<Struct>` / 结构套结构：`Map` 在 Arrow 里就是
  `List<Struct<key, value>>`，entries 直接复用 Struct 的解码分支，因此没有新增
  一套类型系统。渲染回 DuckDB 时三种容器各用它能 cast 的形式（`[..]` /
  `{'k': v}` / `{k=v}`），转义按 DuckDB 自己打印 VARCHAR 的规矩（反斜杠双写、
  单引号写成 `\'`）—— 混用 SQL 标准的单引号双写不会报错，只会静默给出错误的
  字符串。写出侧同时补了 **null 槽归一**：定长槽清零、位图空值位清零、变长槽
  清掉旧数据并把 offset 改成「长度 0」、复合类型把父级的空传给子级，于是同一份
  逻辑数据必然写出逐字节相同的文件（CASE 出来的列、过滤后的列与源列三者字节
  一致）。共 649 项回归测试。
- **v0.14.0**：Arrow 往返闭合 —— `ipc-buf` 与 `read-arrow`。
  `Frame.ipc-buf` / `LazyFrame.ipc-buf` / `Arrow.ipc-buf` 把结果编码成内存里的
  IPC 字节（默认 stream 格式），与 `write-ipc` 共用同一份编码逻辑、字节逐位相同；
  这是 C data interface 裸指针的跨进程替代。`Session.read-arrow` 反过来：
  `Duckula::ArrowRead` 解 FlatBuffers（table/vtable、Schema、RecordBatch、
  DictionaryBatch、Footer），把列 buffer 解码成 Raku 值，再建 TEMP 表用 Appender
  灌进去。file / stream 两种格式、多批次、字典（含 delta）、`List<标量>` 全部支持，
  标量类型往返后**列类型与值都精确一致**。`describe-ipc` 只读骨架不读数据。
  共 634 项回归测试。
- **v0.13.0**：阶段 8 收口 —— 判定改由 DuckDB 自己的解析器给出。
  `duckdb_extract_statements` 拆语句、`duckdb_prepared_statement_type` 定类型、
  `duckdb_nparams` 数参数，替换掉前缀启发式与数问号。类型白名单之外再加一层写动词
  扫描，因为 `WITH d AS (DELETE ... RETURNING *) SELECT ...` 的类型是 SELECT、
  `EXPLAIN ANALYZE DELETE ...` 的类型是 EXPLAIN —— 只看类型会放行真的写操作。
  `Session.classify` 可自查某条 SQL 被判成什么。共 597 项回归测试。依赖
  `DB::DuckDB:ver<1.2.0+>`（新增 `DB::DuckDB::Parser`）。
- **v0.12.0**：阶段 7 收口 —— 写出。`to-parquet` / `to-csv` / `to-table` /
  `append-to` 在 `Frame` 与 `LazyFrame` 上各一套，数据不出 DuckDB；`Session.execute`
  （写语句）、`Session.insert`（Appender 批量）、`Session.create-table`（接 Frame /
  LazyFrame / SQL）补齐反向通道。路径与表名全部转义，沙箱会话写文件当场拒绝。
  共 527 项回归测试。
- **v0.11.0**：阶段 6 收口 —— Arrow IPC 导出。`write-ipc($path, :$format<file|stream>)`
  把结果直接写成 Arrow IPC 字节（`Duckula::ArrowIPC`：自写 FlatBuffers 构造器 +
  Message/Schema/RecordBatch/Footer 布局 + DictionaryBatch）。绕开 `COPY … FORMAT
  ARROW` 对 `arrow` 扩展的依赖（该扩展只在标准平台发布）。全类型覆盖，产物用
  pyarrow 26 逐值验证。共 457 项回归测试。
- **v0.10.0**：阶段 6 的第一半 —— Arrow 出口。`Frame.arrow` / `LazyFrame.arrow`
  返回 `Duckula::Arrow`：`.schema` 是整表类型描述（含嵌套结构），`.chunks` 逐块给
  2048 行的 Arrow array，`.fields` / `.format-of` 查类型，`free` 幂等。依赖
  `DB::DuckDB:ver<1.1.0+>`（该版补齐了 Arrow 的 schema 一半与反向导入）。
  共 431 项回归测试。
- **v0.9.0**：阶段 4 —— `LazyFrame` + 计划树 + `collect`。7 种计划节点
  （source / project / filter / aggregate / join / sort / limit），渲染器把树累积成
  一个 `Query`：相邻 filter 合并成一个 `WHERE`、filter 与 group-by 待在同一层，
  该物化时才物化。`explain` 看计划树 + SQL；`scan-csv` / `scan-parquet` 惰性读；
  `LazyFrame.sql` 走临时视图边界；`?` 参数从头留到 `collect` 才绑定。
  顺带把 `GroupBy` / `Join` 的校验抽成 `spec` / `join-layout` 供两套 API 共用。
  共 401 项回归测试。
- **v0.8.0**：窗口函数与切片——`Expr.over` / `cum-sum` / `cum-max` / `cum-min` /
  `cum-count` / `shift` / `diff` / `rank` / `rolling-sum` / `rolling-mean`；
  `with-column` 支持裸聚合广播、覆盖同名列、窗口后锚回行序；`with-columns` 一次加多列；
  `Frame.limit` / `tail` / `slice`（含负 offset）。阶段 5 到此收尾。共 337 项回归测试。
- **v0.7.0**：`join` —— `inner` / `left` / `right` / `full` / `semi` / `anti` / `cross`，
  同名键、多键、异名键（Pair）、自定义后缀；`Frame.names` 改走 `LIMIT 0` 只问 schema。
  共 271 项回归测试。
- **v0.6.1**：`Frame.rows` 按 `ColumnView.type` 还原类型——`sum()` 这类 HUGEINT
  结果不再以字符串出现，DECIMAL 还原成 `Rat`。共 224 项回归测试。
- **v0.6.0**：分组聚合——`group-by(...).agg(...)` / `.count` / `Frame.agg`（全表），
  `Expr.label` 自动列名、`Expr.is-aggregate` 拦住非聚合表达式、重名与未知列提前报错。
- **v0.5.0**：表达式系统——`col()`、算术 / 比较 / 逻辑运算符重载、字符串方法，
  以及建立在它上面的 `filter` / `with-column` / `sort-values`（全部编译成 SQL）。
- **v0.4.0**：数据入口与 `Series`——`read-csv` / `read-parquet`（路径走绑定参数）、
  `$df{'col'}` → Series（ColumnView 薄包，聚合零拷贝）、`$df[0]`、`$df.select(...)`。
- **v0.3.0**：SQL 入口——`duckula.sql(...)`、`Frame.sql("... from self ...")`、
  字符串感知的 `self` 占位符扫描（临时视图绑定，不是子查询）、参数固化、临时视图回收。
- **v0.2.0**：注入防护层——`Duckula::SQL`（转义 / 掩码 / 计数 / 只读判定）+
  `Duckula::Guard`（单语句 / 只读 / 占位符校验 + 外部访问沙箱）。
- **v0.1.0**：骨架（`META6.json` + 入口模块 + 加载测试）。

路线图见 [ARCHITECTURE.md](ARCHITECTURE.md#10-路线图)。

## 依赖

- Raku 6.d
- `DB::DuckDB` >= 1.3.1（1.3.0 及以前会把负的 128 位 DECIMAL / HUGEINT 读成天文数字）
- `Alien::Libduckdb` >= 1.2.1
- `Arrow::IPC` >= 0.1.3（IPC 读写的 Raku 侧编解码与兜底；0.1.3 修了可空
  BOOLEAN 的写出）
- `Compress::Zlib::Raw` >= 1.0.1（xlsx 的 crc32 / inflate，和 ExcelWrite 共用同一份 zlib）
- `DB` >= 0.5（`DB::DuckDB` 的接口层）

`write-ipc` / `ipc-buf` 的原生路径还要求 libduckdb 带 `arrow` 扩展
（`conn.arrow-available` 为真）；不可用时自动退回 Raku 侧编码，功能不受影响。

## 开发

```bash
raku -Ilib -e 'use Duckula; say $Duckula::VERSION'          # 注意 sigil：$Duckula::VERSION
raku tools/run-tests.raku                                   # 全部回归（逐文件汇总）
for f in t/*.rakutest; do raku -Ilib "$f"; done             # 不用脚本时
```

安装：

```bash
zef install .
```

**后端要求**：Rakudo + MoarVM。本包依赖 `Alien::Libduckdb` 拉原生库，
rakupp 上装不上，不在支持范围（验证只在 Windows / WSL 两个 MoarVM 环境跑）。

## 文档

- [ARCHITECTURE.md](ARCHITECTURE.md) —— 架构、复用边界、已知坑、API 草案；
  §8.x 按版本记录每个决策与实测数字
- [HANDOFF.md](HANDOFF.md) —— 接手说明：现状、待办、环境与验证命令

## 家族

| 模块 | 职责 |
|---|---|
| `DB::DuckDB` | DuckDB 驱动（NativeCall + DB 接口） |
| `App::DuckETL` | SQL-first ETL，带 TUI |
| `Duckula` | DataFrame API |
