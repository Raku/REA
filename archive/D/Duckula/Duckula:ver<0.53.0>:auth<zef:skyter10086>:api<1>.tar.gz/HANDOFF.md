# Duckula 交接说明（2026-11-27，v0.53.0）

接手对象：继续做 Duckula（Raku 的 DataFrame 库，DuckDB 做执行引擎）的同学。
本文描述 **0.53.0 时点的真实状态**；更早那份停在 0.36.2 的交接已作废。

---

## 0. 一句话现状

`C:\Users\Administrator\duckula` 在 **v0.53.0**，工作区干净、与
`origin/master` 一致，全套测试 **52 文件 1811 项 0 失败**。
0.49.0 修完 P0（十组静默错误），0.50.0 修完 P1（生命周期 / 沙箱 / join /
IPC 写失败的原子性），0.51.0 修完 P2（排序合并、辅助列名、复合聚合、空集
sum、Excel 自闭合标签与 zip bomb），0.51.1 补上了**原生 IPC 路径的验证**
（本机 arrow 扩展已可用），0.51.2 修掉原生 IPC 临时视图的**命名冲突**并记录
xlsx 的两条格式边界，0.51.3 把读入的临时表改成**按输入指纹命名并复用**
（同一个文件重复读不再攒表），并加了 `tools/run-tests.raku` 测试脚本。0.52.0 把一批"静默出错"改成当场报错（§8.61：iloc 行号、unpivot NULL 行、asof 毫秒容差、sql-literal 微秒、read-arrow `:name` 撞名、缓存指纹 ctime、Excel 原生兜底、未知命名参数）。0.53.0 是两条设计取舍的收口：`Series` 五个聚合**重新下推**到 SQL（1M 行 0.80–5.37 s → 0.006–0.061 s，HUGEINT 从错值变正确、DECIMAL 从 `Num` 变精确 `Rat`），为此修掉 `DB::DuckDB` 1.4.3 里 `ColumnView.!agg` 的三个 bug；`Arrow::IPC` 维持独立包边界，只补了两条使用约定（§8.62）。
WSL 已恢复（FedoraLinux-45 / moar-2026.11），`t/40` 跑通 6/6，**旧的段错误
未能复现**；v0.52.1 与 v0.53.0 都在 WSL 里同步 `origin/master` 跑了**全套**：
v0.52.1 是 51 文件 1769 项 0 失败（57.6s），v0.53.0 是 52 文件 1811 项 0 失败
（64.5s），与 Windows 本机一致（WSL 的 DB::DuckDB 已装到 1.4.3）。剩余只有
CI 接线，见 §3。

| 项 | 值 |
|---|---|
| 仓库 | `C:\Users\Administrator\duckula`（git bash 里 `~/duckula`） |
| 远端 | `https://gitee.com/skyter10086/duckula.git`，分支 `master` |
| HEAD | 见 `git log --oneline -1` |
| 规模 | `lib/` 36 个模块、约 8700 行；`t/` 52 个文件、1811 项断言 |
| 版本链（近期） | 0.37.0 `92cac28` → … → 0.48.1 `6668651` → 0.48.2 文档补齐 → 0.49.0 P0 修复 → 0.50.0 P1 修复 → 0.51.0 P2 修复 → 0.51.1 原生 IPC 验证 → 0.51.2 IPC 临时视图命名 → 0.51.3 输入临时表复用 + 测试脚本 → 0.52.0 静默出错收口 → 0.52.1 入口补齐 + Excel 兜底 → 0.53.0 Series 聚合下推 + 驱动修复 |

### 约定（作者明确要求，别破）

1. 每次改动**同时**递增 `META6.json` 与 `lib/Duckula.rakumod` 的 `$VERSION`
   —— 漏一个就会出现"装的还是老版本"。
2. README 的「状态」段加一条（按版本倒序）；`ARCHITECTURE.md` 加一节
   （现有最后一节是 §8.61，接着编 §8.62）。
3. 中文 commit message，标题带 `feat(...)` / `fix(...)` / `perf(...)` /
   `refactor(...)` / `docs(...)` 前缀和版本号。
4. 推送后单独核对 `git rev-parse HEAD` 与 `git rev-parse origin/master`。

---

## 1. 环境与验证（先跑一遍，别信文档只信输出）

本机是 Windows，Raku 在 `C:\rakudo\bin\raku.exe`，**没有** `raku` 在 PATH。

一条命令跑全套（推荐，0.51.3 起）：

```powershell
cd C:\Users\Administrator\duckula
C:\rakudo\bin\raku.exe tools\run-tests.raku
# 期望结尾：files: 52  ok: 1811  not-ok: 0  failed files: 0
```

也可以只跑几个文件：`C:\rakudo\bin\raku.exe tools\run-tests.raku t/17-arrow-read.rakutest t/49-input-tables.rakutest`。
单个文件直接：`C:\rakudo\bin\raku.exe -Ilib t\17-arrow-read.rakutest`。

### 本机环境快照（2026-11-27）

| 依赖 | 版本 |
|---|---|
| Rakudo / MoarVM | Windows 版，`C:\rakudo` |
| DB::DuckDB | 1.4.3（引擎 `library_version` = v2.0.0，2026-11-27 实测；1.4.3 修的是 `ColumnView.!agg`，见 §8.62） |
| Alien::Libduckdb | 1.2.2 |
| Arrow::IPC | 0.1.3（0.1.3 修了可空 BOOLEAN 的 IPC 写出，必须 >= 0.1.3） |
| Compress::Zlib::Raw | 2.0.0（META6 要求 `1.0.1+`） |
| DB | 0.5 |

环境事实（2026-11-26 核对）：

- **`conn.arrow-available` 现在是 `True`**。`DB::DuckDB.arrow-available` 会
  `INSTALL`+`LOAD`（要联网），扩展装好后原生 `to-arrow-ipc` / `read_arrow`
  就能用；0.51.1 已用它做过原生写读往返验证（`t/48` 有 3 项，无扩展时 skip）。
  离线/无扩展的构建仍会回退到 Raku 的 `Arrow::IPC`，所以兜底路径的回归也一直
  在跑（`t/46` 的 IPC 布尔用例固定走 Raku 编码）。
- **WSL 2026-11-26 已恢复**：发行版是 `FedoraLinux-45`（不是旧文档里的
  Ubuntu），内核 6.18.58.1-microsoft-standard-WSL2，`HOME=/home/zby`。Raku
  在 `~/.rakubrew/versions/moar-2026.11/bin/raku`（Rakudo/MoarVM 2026.11），
  zef 在同版本 `share/perl6/site/bin/zef`。依赖已装齐（Alien::Libduckdb
  1.2.2、DB::DuckDB 1.4.3、Arrow::IPC 0.1.3、Compress::Zlib::Raw 2.0.0、
  DB 0.5）。本地 checkout：`~/duckula` 停在 8eac01b（v0.51.1，尚未同步到
  0.51.3）、`~/Alien-Libduckdb`、`~/DB-DuckDB`、`~/arrow-ipc`。
  `t/40-ipc-bounds.rakutest` 在该环境 **6/6 通过，旧的段错误未复现**。
- 用 `wsl -e bash -lc '...'` 传多行 bash 时，PowerShell 5.1 会重写 `$` 与
  引号（症状：变量变空、`for` 语法错误）。多行脚本先写成 `.sh`，再
  `wsl -d FedoraLinux-45 -e bash /mnt/c/...` 执行。

### 关于"模块加载失败 / Failed to spawn process"

Raku 的预编译要**创建子进程**。如果运行环境禁止子进程（比如某些受限沙箱），
`use Duckula` 会报：

```
Failed to spawn process C:\rakudo\bin\raku.exe: operation not permitted
```

这不是代码坏了，是环境不让 fork。换一个允许创建子进程的终端跑即可。

---

## 2. 已经做完的事（别重做）

| 版本 | 改动 | 关键收益 |
|---|---|---|
| 0.38.0 | 嵌套类型（LIST/STRUCT/MAP/ARRAY）返回真值 | `rows` / `explode` 不再拿到 DuckDB 文本渲染 |
| 0.39.0 | 解码器抽公共 `Duckula::Decode` | Frame / RowsView / Series 类型还原一致 |
| 0.40.0 | 入口二次执行消除 | `.sql(...).rows` 只执行 1 次（原 2 次） |
| 0.41.0 | lazy LIMIT/OFFSET 屏障 | `head(n).filter(...)` 语义与 eager 一致 |
| 0.42.0 | where/mask Series 行数检查 | 跨关系错位从静默错误变成明确拒绝 |
| 0.43.0 → 0.45.0 | Series 聚合 SQL 下推，**又撤回** | 类型正确 + 不触发物化优先（§8.50） |
| 0.44.0 | RowsView 每列一次解码 | 20 万 × 36 列不再 720 万次 `at()` |
| 0.46.0 | 安全网关补口 + 临时视图生命周期 | 沙箱 / 注入面 / `drop-views` 悬空 |
| 0.47.0 | Arrow IPC 原生导出 | 5 万 × 3 列 0.075 s → 0.009 s（有 arrow 扩展时） |
| 0.48.0/1 | read-arrow 单次 Appender | 少开关事务与 handle；handle 类型修正 |
| 0.48.2 | 文档补齐 + §8.44 订正 | 0.38–0.48 的决策可追溯 |
| 0.49.0 | P0 隐患十组（§8.56） | 串会话视图、lazy 排序键、Expr 元数据、Rat 精度、写后抛错、close 状态、ARRAY/UNION、Excel 读/写、IPC 布尔 |
| 0.50.0 | P1 生命周期 + 沙箱（§8.57） | 不再强引用 Frame（1701 项、3000 Frame 0.12 s）、活视图保护、沙箱写口、join 空后缀、IPC 写原子性 |
| 0.51.0 | P2 边界（§8.58） | 多键稳定排序、tail/iloc 辅助列避让、transform 拒绝复合聚合、空集 sum=0、Excel 自闭合标签、zip bomb 上限 |
| 0.51.1 | 原生 IPC 路径验证 | arrow 扩展可用后，`to-arrow-ipc` 写读往返与 `rows` 一致；Raku 解码器能读原生文件 |
| 0.51.2 | IPC 临时视图命名 + 文档 | 原生 IPC 路径的临时视图按调用自增命名（同会话并发/残留视图不再撞名）；记录 xlsx 数值精度与尾部空行的格式边界，订正"DB::DuckDB 缓存 Result"的误判 |
| 0.51.3 | 输入临时表按指纹复用（§8.60） | 同一文件重复读复用同一张临时表（表名由路径+大小+mtime 派生，引擎/reader 进键），会话内不再累积表；新增 `tools/run-tests.raku` 与 `t/49` |
| 0.52.0 | 静默出错收口（§8.61） | iloc 不再把同名数据列当行号；unpivot 默认保留 NULL 行；asof 时间键容差改毫秒；sql-literal 保留微秒；read-arrow `:name` 撞名报错；缓存指纹加 ctime；Excel 原生失败兜底；未知命名参数报错 |
| 0.52.1 | 入口补齐 + Excel 兜底回归（§8.61.9） | Session.sql / Session.execute、LazyFrame.sql、resample().agg、Expr 的 over / cum-* / shift / diff / rank / rolling-* 共 14 处补 reject-named；read-excel 兜底用 write-xlsx 造夹具锁住 |
| 0.53.0 | Series 聚合下推 + 驱动修复（§8.62） | 五个聚合改走 SQL（1M 行 0.80–5.37 s → 0.006–0.061 s）；HUGEINT 求和从错值变正确、DECIMAL 从 `Num` 变精确 `Rat`、文本/时间 min/max 从 Any 变真值；NaN 按 pandas skipna、空集 sum=0；DB::DuckDB 1.4.3 修 `ColumnView.!agg` 三个 bug；`t/51` 42 项 |

更早的 0.1.0–0.37.0 见 README「状态」段。**明确不要动的**：

- 算子层（filter / join / groupby 一律翻译成 SQL 交给 DuckDB，别在 Raku 里重写）；
- `Series.sum / min / max / mean / count` 走 SQL 下推（`Series.rakumod` 的
  `!agg-sql` + `!scalar`）。别退回 `ColumnView` 聚合：§8.50 的"类型正确"
  前提已被证伪，实测慢 30–900 倍且 HUGEINT 值错（§8.62）；
- `Arrow.from-frame` 的**独立** query（它必须拥有自己的 Result，`free` 才安全）。

---

## 3. 待办（建议顺序）

### P1：WSL moar-2026.11 的 `t/40-ipc-bounds` 段错误（已关闭：未复现）

2026-11-26 在 FedoraLinux-45 / moar-2026.11 / v0.51.1 上跑 `t/40`：**6/6 全
ok**，进程正常退出，旧的段错误没能复现。当时记录的两个可能（越界读被新版
抓出 / MoarVM 回归）都无从验证；**不要再盲改代码**。要做的是：每次发版在
WSL 里把全套跑一遍，哪次复现了再按现场查。

WSL 里同步并复跑（`~/duckula` 已在 v0.53.0 的提交上；同步步骤要先
`git -C ~/duckula fetch && git -C ~/duckula reset --hard origin/master`，
而 `~/DB-DuckDB` 同理 —— **v0.53.0 起 WSL 里也要装 1.4.3**，否则驱动侧
的聚合修复不生效）：

```bash
wsl -d FedoraLinux-45 -e bash -lc 'cd ~/duckula && ~/.rakubrew/versions/moar-2026.11/bin/raku tools/run-tests.raku'
```

**WSL 的 gitee 拉取会间歇性卡死**（实测 19 分钟无进展）：给 `git fetch`
套 `timeout 90` + `http.lowSpeedLimit/lowSpeedTime`，失败就重试，别让脚本
无限等；拉不到就跳过 WSL 复跑，别把 Windows 的结果当成两边都绿。

### P1.5：CI 接线

仓库里已有 `.github/workflows/ci.yml`（镜像用）。Gitee 的流水线要在 Gitee Go
界面里配置，读的是仓库根的 `.workflow/` 目录；当前只提供可执行的
`tools/run-tests.raku`，**Gitee Go 配置尚未提交**，接的时候照 `.github` 那份
改路径即可。

### P2：两条设计取舍（已在 0.53.0 收口）

- **`Series` 聚合**：0.45.0 的"回退 ColumnView"作废，五个聚合改回 SQL 下推。
  依据是 1M 行实测（BIGINT 0.80 s→0.061 s、HUGEINT 2.22 s 且值错→0.006 s、
  DECIMAL 2.06 s `Num`→0.006 s 精确 `Rat`、DOUBLE 5.37 s→0.006 s）与
  pandas 语义对齐（NaN 走 `FILTER (WHERE NOT isnan(...))`、空集 sum=0、
  `BOOLEAN` 的 mean 用 `avg(CAST(col AS BIGINT))`）。**前提是驱动先修好**：
  `DB::DuckDB` 1.4.3 修了 `ColumnView.!agg` 的 128 位字对、非 raw 列
  min/max、DECIMAL 精度三处。细节见 §8.62。
- **`Arrow::IPC` 边界**：维持独立的硬依赖包，不并回 Duckula —— 离线/无
  arrow 扩展时它是唯一读写路径，`Rakuish` 等下游直接依赖它，且它零依赖。
  只补两条文档约定：`Frame` 必须拥有独立 `Result`；原生编码器与纯 Raku
  编码器只保证互相可读，不保证字节相等。

### 已完成的验证（0.51.1）

原生 `to-arrow-ipc` 写读往返、`write-ipc(:format<stream>)` 的格式语义、
Raku 解码器读原生文件（可空布尔/LIST）—— 都在 `t/48` 最后几条，无扩展时
自动 skip。原生 IPC 的临时视图命名回归在 `t/48` 末尾 3 项（0.51.2）。

### 已记录、但决定不"修"的格式限制（§8.59）

- xlsx 数值单元格是 IEEE double：`9007199254740993::BIGINT` 两种写入路径
  读回都是 `9007199254740992`，这是文件格式决定的，要保真只能写文本。
- 尾部全 NULL 行在 xlsx 里按"数据结束"处理，两种写、两种读都会少这一行。
- 这两条再遇到时**不要再当 bug 修**，要么改文档、要么另立 `:as-text` 选项
  （会改变列类型，需要单独设计）。

---

## 4. 踩过的坑（省你半小时起步）

- **`CATCH` 块自身的值是 `Nil`**，写在方法末尾会让方法静默返回 `Nil`
  （症状：`.column('a').add(...)` 变成 `Nil` 而不报错）。必须显式 `return`。
- **`ColumnView` 对 HUGEINT / DECIMAL 返回十进制字符串**（DB::DuckDB 1.4.1
  实测）：`(-1)::HUGEINT` 的 `at(0)` / `to-list[0]` 都是 `"-1"`。
  类型还原必须过 `Duckula::Decode`，别直接透传。§8.44 旧结论已作废。
- **`DB_DUCKDB_NO_COLUMN_VIEW=1`** 会整体关掉 ColumnView，`Frame` 退回
  `$res.arrays`（大量 bug 只在某一条路径上出现时，先查这个环境变量）。
- **`Frame` 的 Result 不能和 `Arrow` 共享**：`Arrow.free` 会释放它，共享会让
  Frame 悬空（0.45.0 试过，`t/13` 第 74 行立刻挂）。
- **别把"读旧数据"归因于驱动缓存**。0.51.2 用 `Session.sql` 复验过：同一条
  SQL 在 `insert` 前后、视图 `CREATE OR REPLACE` 前后都会重新执行，`DROP VIEW`
  后直接报 `Catalog Error`；`Session.sql` 没有 Result 缓存。看到旧结果先查是不是
  还有活的 `Frame` / `DB::DuckDB::Result` 绑着旧计划（他们本来就该持有当时的
  计划）。验证视图是否删掉用 `duckdb_views()`，别靠重复 SQL。
- **原生 IPC 的临时视图名不能按 Session 生成**：0.51.2 起用进程级自增
  `__duckula_ipc_<n>`（`Frame.rakumod` 的 `$IPC-VIEW-SEQ`）。按 Session 命名时
  同一会话连续/并发调用会撞 `CREATE TEMP VIEW`，崩溃残留也会挡住下一次。
- **输入临时表名由「指纹」派生，不是每读一次自增**（0.51.3 起）。`read-arrow`
  的键是 `arrow:<engine>:<绝对路径|大小|mtime>`，`read-excel` 还带
  `sheet|header|all-varchar` 和 `python`/`raku` reader。同一文件重复读是
  `CREATE OR REPLACE` 同一张表（旧 Frame 仍能读旧内容，因为它的 SQL 早生成了）；
  文件被改写则指纹变、换新表。映射表在模块级 `%INPUT-TABLE-NAMES`，赋值必须用
  `//=` —— 写成 `%h{$k} // $expr` 是"取值"，不会写回，症状是每次读都建新表。
  引擎也进键是故意的：native 与纯 Raku 的 INTERVAL 类型映射不同，混用会掩盖
  差异（`t/17` 的 native vs 兜底对比要的是两张表）。
- **`drop-views` 默认保护活对象引用的视图**，要全清得 `:force`。保护靠视图名
  引用计数，而计数在 `DESTROY` 里归还 —— Rakudo 普通对象常常到进程退出才
  finalize，所以默认保护可能"多保护一段时间"，这是有意为之（见 §8.57）。
- **`LEAVE` 是块级 phaser**：方法前面提前 `die` 时，LEAVE 里引用的变量可能还是
  `Any`（如 `LEAVE $a.free`），会顶掉真正的错误。释放动作要加 `.defined` 守卫。
- **`submethod DESTROY` 不保证运行期触发**：Rakudo 普通对象通常在进程退出时
  才 finalize，别把资源回收建在 DESTROY 上（视图引用计数只用于"保护"，不用于
  精确清理）。
- **Appender 从 `conn.appender($table)` 开**，不要自己
  `Appender.open(conn, ...)`（handle 类型不对，0.48.1 的修正）。
- **`Compress::Zlib::Raw` 是编译期硬依赖**：没装它，`use Duckula` 直接
  编译失败（ExcelWrite 最顶层就 `use`），不是运行时才报。
- **别用 `IO.dir(:recurse)` 扫安装目录**，本机实测没真递归。
- **`$dist.content($key)` 返回 IO::Handle**，不是路径；要 `.path.absolute` 并 close。
- **nullable BIGINT 的 `.value` 不可靠**，计数统一
  `CAST(count(*) AS VARCHAR)` + `.value.Int`。
- **直接往 DuckDB 传小数会被推断成 DECIMAL**，想拿 DOUBLE 要显式 `::DOUBLE`。
- **Raku 的 method 只收 `*@` 时，命名参数会被 slurpy 静默吞掉**：`method m(*@a)` 调
  `m(1, :bogus<2>)` **不报错**（sub 才会报 "Unexpected named argument"）。公开算子要
  显式收 `*%extra` 再调 `reject-named`。批量改签名时注意**返回类型必须留在参数表
  末尾**（`*%extra --> Duckula::Frame`）；写成 `--> T, *%extra` 会报
  `Malformed return value (return constraints only allowed at the end of the signature)`。
- **`abs(INTERVAL)` 在 DuckDB 里没有候选函数**（2.0.0 实测：`Binder Error: No
  function matches the given name and argument types 'abs(INTERVAL)'`）。时间距离
  一律用 `abs(epoch_ms(a) - epoch_ms(b))`，容差写成毫秒整数（`sql-literal($sec * 1000)`）。
- **`UNPIVOT` 只有表因子写法**：`SELECT * FROM (rel) UNPIVOT [INCLUDE NULLS]
  (v FOR n IN (a, b)) AS up` 可用；旧式 `UNPIVOT (rel) ON a, b INTO NAME n VALUE v`
  在 2.0.0 里直接 `Parser Error: syntax error at or near "ON"`，而且默认**静默丢
  NULL 行**。
- **本机 `$*TZ` 是 28800（UTC+8），但 `DateTime.new(年,月,日,...)` 默认给 UTC**：
  `sql-literal(DateTime)` 内部还会 `.utc`，写测试时别拿本地时间当基准。
- **Windows 上 `IO::Path.changed` 与 `.modified` 同步刷新**：`spurt` / `.copy`
  都会同时改两者，"同大小同 mtime 不同内容"造不出来（POSIX 的 ctime 才独立），
  Arrow 指纹的 ctime 回归只能靠改写文件的用例 + 代码审查。
- **`DuckDB` 引擎版本以 `SELECT version()` 为准**（2026-11-27 实测 v2.0.0），
  DB::DuckDB 模块号（1.4.1）不等于引擎版本；碰语句语法差异先看这个。
- **PowerShell 5.1 的 `Set-Content -Encoding utf8` 会写 BOM**；改仓库里的
  UTF-8 文件用 .NET `UTF8Encoding($false)`，否则 diff 里多出 `EF BB BF`。
- **`ColumnView.!agg` 在 DB::DuckDB 1.4.2 及以前对 128 位列是错的**：HUGEINT /
  UHUGEINT / DECIMAL(>18 位) 的元素是两个 64 位字，`nativecast(CArray[uint64])`
  之后 `$ca[$k]` 只拿到低字，求和把"低字/高字"混在一起（0..9 的 HUGEINT 列
  `sum` 得 10，负值给 1.4e20 的垃圾）。1.4.3 起按 `$ca[$k*2]` / `$ca[$k*2+1]`
  字对还原，写这类聚合代码时别再用 `$ca[$k]`。窄整数与 128 位可以用
  `$!width == 16` 区分（DECIMAL 的 width 来自 `raw-width(decimal-internal-type)`）。
- **Raku 的 `<=` / `>=` 对 Str 会 numify 成 Failure**：`"a" <= "b"` 返回
  `Failure.new(X::Str::Numeric)`，不是布尔。字符串比较用 `cmp`
  （`Order::Less` / `Order::More`）；踩过这个坑的 `max` 会静默返回最小值。
- **浮点列聚合要自己排除 NaN**：DuckDB 把 NaN 当可排序值，不写
  `FILTER (WHERE NOT isnan(col))` 时 `SUM` 传播 NaN、`MAX` 返回 NaN；pandas 的
  语义是 skipna。`BOOLEAN` 列没有 `avg` 候选函数（`Binder Error`），要
  `avg(CAST(col AS BIGINT))`。
- **`Series` 聚合别走 `Frame.rows`**：会触发 `Frame.!materialize` 的计数器
  （`t/44` 守着"取列不物化"），还白建一个派生 Frame。`Series.!scalar` 直接
  `$f.session.conn.query($sql)` + `column-decode`，一条 SQL 一行结果。

---

## 5. 文件地图（改哪儿）

```
lib/Duckula.rakumod              入口 + $VERSION（改版本记得同步 META6.json）
lib/Duckula/Frame.rakumod        核心：ensure-result/names/views、rows、elems、
                                 empty、gist、column、arrow、write-ipc
lib/Duckula/RowsView.rakumod     惰性行视图（Positional + Iterable），嵌套列 kind=3
lib/Duckula/Decode.rakumod       统一解码器（type-decode-kind / val-decode /
                                 column-decode）—— 改类型还原只改这里
lib/Duckula/Series.rakumod       列包装：to-list / 聚合 / add
lib/Duckula/Plan.rakumod         惰性计划树与 Query（locked 决定能否合并子句）
lib/Duckula/Session.rakumod      会话：SQL 网关、临时视图、视图引用计数
lib/Duckula/Arrow.rakumod        Arrow 出口与生命周期（独立 Result + free）
lib/Duckula/ArrowIPC.rakumod     Raku 侧 IPC 编码（原生路径的兜底）
lib/Duckula/ArrowRead.rakumod    IPC 读（默认交给 DuckDB 读，纯 Raku 解码兜底）
lib/Duckula/ExcelRead.rakumod    xlsx 读（python→CSV 快路径 + 纯 Raku 解析兜底）
lib/Duckula/ExcelWrite.rakumod   xlsx 写出，crc32 走 Compress::Zlib::Raw
lib/Duckula/Write.rakumod        parquet/csv 落盘
lib/Duckula/SQL.rakumod          quote-ident / 转义 / 只读判定
tools/run-tests.raku             逐文件跑 t/*.rakutest 并汇总（Windows/WSL 通用）
t/49-input-tables.rakutest       输入临时表复用（同文件/文件改写/表数量）
t/51-v0530-aggregates.rakutest     Series 五个聚合的语义与类型契约（42 项）
ARCHITECTURE.md                  设计档案，§8.x 每节一个决策 + 实测数字
README.md                        面向用户；「状态」段按版本倒序累积
```

---

## 6. 基准脚本

基准脚本在仓库根、**已进 `.gitignore`（`/bench-*.raku`）**，不随包发布。
WSL 可用（FedoraLinux-45）时的命令：

```bash
# 行式物化 vs Arrow vs SQL 聚合
wsl -d FedoraLinux-45 -e bash -lc 'cd ~/duckula && for m in elems sqlsum arrowsum arrowall rows writeipc; do
  /usr/bin/time -f "   %e s peak %M KB" ~/.rakubrew/versions/moar-2026.11/bin/raku \
    -Ilib /mnt/c/Users/Administrator/duckula/bench-arrow.raku 200000 $m; done'
```

Windows 本机没有 `/usr/bin/time`，要看内存请用 Process Explorer 或
`Get-Process -Id $PID | Select WorkingSet64` 前后对比。
