use v6.d;
use Duckula::Expr;
use Duckula::SQL;
use Duckula::Clean;
use Duckula::X::Frame;

#| 分组阶段的中间对象：持有来源 Frame 和分组键，等 `agg` 才拼 SQL。
#|
#|   $df.group-by('city').agg(col('amount').sum.alias('total'));
#|   $df.group-by('city', 'country').agg(len().alias('n'));
#|   $df.group-by(col('city').upper.alias('city_up')).agg(col('amount').max);
#|
#| 为什么要有这个中间对象，而不是让 `Frame.group-by` 直接返回专用 Frame：
#| 分组键和聚合表达式是两件事，必须同时到齐才能拼出一条 SELECT。
#| 中间对象正好卡在那里，也顺手把「只 group 不 agg」这种半成品挡在类型之外。
#|
#| 刻意不在这里 `use Duckula::Frame`：`Frame` 已经 `use` 了本模块，双向 use
#| 会形成预编译循环。这里只在运行时构造 `Duckula::Frame`，不做类型约束。
class Duckula::GroupBy {
    has $.frame is required;
    has @.keys;        # List[Duckula::Expr]
    has @.key-names;   # List[Str]

    submethod BUILD(:$!frame!, :$keys) {
        # 用标量参数接 `keys` 而不是 `: @keys`：后者在把数组当命名参数传进来时
        # 也会再包一层。收到之后一律 `.flat` —— `Array.List` 赋给标量会被 Raku
        # itemize 成 `$(($expr,),)` 这种嵌套，`for` 直接绑不上类型。
        my @ks = ($keys // ()).flat;
        my @names;

        for @ks -> Duckula::Expr $e {
            my $n = $e.out-name;
            die Duckula::X::Frame.new(
                reason => 'group-by key needs a name: '
                        ~ 'use .alias("name") on the expression'
            ) unless defined $n && $n ne '';
            @names.push: $n.Str;
        }

        self!check-duplicate(@names, 'group-by key');

        @!keys = @ks;
        @!key-names = @names.List;
    }

    method !check-duplicate(@names, Str:D $what --> Nil) {
        my %seen;
        for @names -> $n {
            die Duckula::X::Frame.new(reason => "$what '$n' appears more than once")
                if %seen{$n}++;
        }
    }

    #| 分组键（Expr 列表）。
    #| pandas 的 `GroupBy.pipe`。
    method pipe(&fn, *@args, *%kw) { &fn(self, |@args, |%kw) }

    method keys(--> List) { @!keys.List }

    #| 校验聚合并生成输出投影，返回 `%( names => …, items => … )`。
    #|
    #| `items` 是 `expr AS "name"` 的完整投影片段，`names` 是输出列名。
    #| 抽出来是为了让两条路径共用同一套列名规则（自动命名、重名检测、
    #| 非聚合/窗口表达式的拒绝）：`Frame` 的字符串拼接，和 `LazyFrame`
    #| 的计划树节点。两套实现分叉的话，迟早会出现「eager 报错、lazy 不报」
    #| 这种最难查的不一致。
    method spec(*@aggs, *%extra --> Hash) {
        reject-named(%extra, 'spec');
        my @flat = self!flatten(@aggs);
        die Duckula::X::Frame.new(reason => 'agg() needs at least one aggregate expression')
            unless @flat.elems;

        my @out-names;
        my @out-sql;

        for @!keys Z @!key-names -> ($e, $n) {
            @out-names.push: $n;
            # 键表达式也要显式起名：`col('city')` 渲染成 `"city"` 刚好同名，
            # 但 `col('city').upper.alias('cu')` 渲染成 `upper("city")`，
            # 不加 AS 输出列名就会变成 `upper(city)`。
            @out-sql.push: $e.render ~ ' AS ' ~ quote-ident($n);
        }

        for @flat -> $a {
            die Duckula::X::Frame.new(
                reason => "agg() only takes Duckula::Expr, got {$a.WHAT.gist}"
            ) unless $a ~~ Duckula::Expr;

            my Duckula::Expr $e = $a;

            # 窗口函数是逐行的，放进聚合里没有意义（DuckDB 会报「window
            # functions are not allowed in GROUP BY」这类难懂的错）。
            die Duckula::X::Frame.new(
                reason => "agg() takes aggregates, but '{$e.render}' is a window "
                        ~ "expression; drop .over() / .cum-* / .rank and use "
                        ~ "with-column if you want it per row"
            ) if $e.window.defined;

            die Duckula::X::Frame.new(
                reason => "agg() needs aggregate expressions, but '{$e.render}' has no "
                        ~ "aggregate function; try col('x').sum / .mean / .min / .max / "
                        ~ ".count, or len()"
            ) unless $e.is-aggregate;

            my $n = $e.out-name;
            die Duckula::X::Frame.new(
                reason => "agg() expression '{$e.render}' needs a name: "
                        ~ 'use .alias("name") on the expression'
            ) unless defined $n && $n ne '';

            @out-names.push: $n.Str;
            # SUM 的空集语义：SQL 返回 NULL，pandas/polars 返回 0（sum 的单位元）。
            # 只对**裸 sum** 包 coalesce：复合表达式补不了 OVER、也不该改语义。
            my Str $item = ($e.agg-fn.defined && $e.agg-fn eq 'sum' && $e.bare-agg)
                ?? 'coalesce(' ~ $e.render ~ ', 0)'
                !! $e.render;
            @out-sql.push: $item ~ ' AS ' ~ quote-ident($n.Str);
        }

        self!check-duplicate(@out-names, 'output column');

        %( names => @out-names.List, items => @out-sql.List );
    }

    #| 执行聚合，返回新的 Frame（仍只是 SQL，不搬数据）。
    #|
    #| 列名规则：显式 `.alias(...)` 优先，否则用 Expr 推出来的名字
    #| （`col('amount').sum` → `amount_sum`）。推不出来就当场报错，
    #| 不会让 DuckDB 给一个 `sum("amount")` 这样的怪列名。
    multi method agg(*@aggs, *%extra) {
        reject-named(%extra, 'agg');
        my %spec = self.spec(|@aggs);
        my $frame = $!frame;

        # 计划树路径：LazyFrame 自己接规格去造节点，SQL 留到 collect 才渲染。
        # 用 `^can` 而不是 `~~ Duckula::LazyFrame` —— 本模块不能 use LazyFrame
        # （LazyFrame 会 use 本模块），只能问它「认不认这个协议」。
        return $frame.agg-from-spec(%spec, @!keys.List)
            if $frame.^can('agg-from-spec');

        # 位置分组：`GROUP BY 1, 2` 比重复整段表达式干净，也避免键表达式
        # 里带聚合函数时被 DuckDB 当成 HAVING 语义。
        my Str $group = @!keys.elems
            ?? ' GROUP BY ' ~ (1 .. @!keys.elems).join(', ')
            !! '';

        # 走 `$frame.derived($sql)` 而不是 `Duckula::Frame.new(...)`：
        # 本模块不能 `use Duckula::Frame`（会与 Frame 的 use 形成循环），
        # 而 `Duckula::Frame.new` 在编译期会被解析成子例程调用并报
        # 「Could not find symbol '&Frame'」。
        $frame.derived(
            'SELECT ' ~ %spec<items>.List.join(', ')
            ~ ' FROM (' ~ $frame.relation-sql ~ ') AS __duckula_group'
            ~ $group
        );
    }

    #| 每组行数，列名 `count`。等价于 `agg(len().alias('count'))`。
    method count() {
        self.agg(len().alias('count'));
    }

    #| 组内聚合广播回每一行（pandas 的 groupby.transform）。
    #|
    #|   $df.group-by('dept').transform(col('salary').mean.alias('dept_avg'));
    #|
    #| 输入必须是**聚合**表达式；`Expr.over(keys)` 把它变成逐行的窗口值，
    #| 再交给 Frame.with-columns 写回同名列。行数和行序都不变。
    #| 这和手写 `col('salary').mean.over('dept')` 等价，只是 key 不用重复写。
    multi method transform(*@exprs, *%extra) {
        reject-named(%extra, 'transform');
        my @flat = self!flatten(@exprs);
        die Duckula::X::Frame.new(reason => 'transform() needs at least one expression')
            unless @flat.elems;

        my @out;
        for @flat -> $a {
            die Duckula::X::Frame.new(
                reason => "transform() only takes Duckula::Expr, got {$a.WHAT.gist}"
            ) unless $a ~~ Duckula::Expr;
            my Duckula::Expr $e = $a;

            die Duckula::X::Frame.new(
                reason => "transform() takes aggregates, but '{$e.render}' is a window "
                        ~ 'expression; drop .over() first'
            ) if $e.window.defined;
            die Duckula::X::Frame.new(
                reason => "transform() needs an aggregate to broadcast, but "
                        ~ "'{$e.render}' has none; try col('x').mean / .sum / .count"
            ) unless $e.is-aggregate;
            # OVER 只能跟在**一个**函数调用后面。`(sum(v)/count(*))` 这种
            # 复合聚合补在末尾会变成 `(...) OVER (...)` —— DuckDB 语法错误。
            # 必须在这里拦下来，提示用户给每个聚合分别 `.over()` 再组合。
            die Duckula::X::Frame.new(
                reason => "transform() cannot broadcast the composite aggregate "
                        ~ "'{$e.render}'; put .over() on each aggregate and combine "
                        ~ 'the window expressions instead, e.g. '
                        ~ "(col('v').sum.over(...) / len().over(...))"
            ) unless $e.bare-agg;

            my $n = $e.out-name;
            die Duckula::X::Frame.new(
                reason => "transform() expression '{$e.render}' needs a name: "
                        ~ 'use .alias("name") on the expression'
            ) unless defined $n && $n ne '';

            @out.push: $e.over(|@!keys.List).alias($n.Str);
        }
        $!frame.with-columns(@out);
    }

    #| 组级谓词筛选（pandas 的 groupby.filter）。
    #|
    #|   $df.group-by('dept').filter(col('salary').mean.over('dept') > 100);
    #|
    #| 谓词本身要写成窗口表达式 —— 没有 OVER 的聚合会把整表折成一行，
    #| 那不是 groupby.filter。这里只做一次字符串提醒，真正拦不住的由
    #| DuckDB 报错；校验谓词树成本更高，收益有限。
    method filter(Duckula::Expr:D $pred) {
        # SQL 的 WHERE 不允许窗口函数，所以先把整条谓词投影成一列，
        # 再在外层按这列过滤，最后把临时列摘掉。
        my Str $tmp = '__duckula_gfilter';
        my Int $n = 0;
        while $tmp ∈ $!frame.names.Set {
            $tmp = '__duckula_gfilter_' ~ ++$n;
        }
        $!frame.with-column($pred, name => $tmp)
               .filter(col($tmp) == True)
               .drop($tmp);
    }

    #| 逐组调用 Raku 函数（pandas 的 groupby.apply），把结果纵向拼回。
    #|
    #|   $df.group-by('dept').apply(-> $g { $g.filter(col('v') > 0) });
    #|
    #| **代价**：先 DISTINCT 取组键，再对每组各跑一次查询，最后 UNION ALL
    #| BY NAME —— 是 N+1 次 SQL。数据量大时优先用 `transform` + `filter`，
    #| 那个路径全程在 DuckDB 内完成。函数必须返回 Duckula::Frame。
    #|
    #| 只接受**裸列**作分组键：表达式键（`col('x').upper.alias('u')`）在原
    #| Frame 里没有同名列，没法拿值回去过滤，明确拒绝而不是静默算错。
    #| 同理只支持 eager Frame；LazyFrame 先 collect 再 apply。
    method apply(&fn) {
        die Duckula::X::Frame.new(
            reason => 'groupby.apply needs an eager Frame; call .collect first'
        ) unless $!frame.^can('relation-sql');

        for @!keys -> $e {
            die Duckula::X::Frame.new(
                reason => "groupby.apply only supports plain column keys; "
                        ~ "'{$e.render}' is an expression key"
            ) unless $e.render eq quote-ident($e.out-name // '');
        }

        # 没有 key 就是一整组，直接用全表调一次 —— 不必查
        # SELECT DISTINCT 1（那在 rakupp 后端会踩 DB::DuckDB 的 null-mask bug）。
        unless @!keys.elems {
            my $whole = &fn($!frame);
            die Duckula::X::Frame.new(
                reason => "groupby.apply: function must return a Duckula::Frame, "
                        ~ "got {$whole.WHAT.gist}"
            ) unless $whole.^can('rows') && $whole.^can('relation-sql');
            return $whole;
        }

        my Str $sql = 'SELECT DISTINCT ' ~ @!keys.map(*.render).join(', ')
            ~ ' FROM (' ~ $!frame.relation-sql ~ ') AS __duckula_gapply'
            ~ ' ORDER BY ' ~ (1 .. @!keys.elems).join(', ');

        my @groups = $!frame.session.conn.query($sql).arrays.List;
        my @parts;
        for @groups -> $row {
            my $sub = $!frame;
            for @!key-names.list Z $row.list -> ($name, $v) {
                $sub = $v.defined
                    ?? $sub.filter(col($name) == $v)
                    !! $sub.filter(Duckula::Expr.new(
                        sql     => quote-ident($name) ~ ' IS NULL',
                        columns => Set.new($name),
                    ));
            }
            my $out = &fn($sub);
            die Duckula::X::Frame.new(
                reason => "groupby.apply: function must return a Duckula::Frame, "
                        ~ "got {$out.WHAT.gist}"
            ) unless $out.^can('rows') && $out.^can('relation-sql');
            @parts.push: $out;
        }

        return @parts[0] if @parts.elems == 1;
        return $!frame.head(0) unless @parts.elems;
        @parts[0].concat(|@parts[1 .. *]);
    }

    method !flatten(@aggs --> List) {
        @aggs.elems == 1 && @aggs[0] ~~ Positional
            ?? @aggs[0].List
            !! @aggs.List;
    }
}
