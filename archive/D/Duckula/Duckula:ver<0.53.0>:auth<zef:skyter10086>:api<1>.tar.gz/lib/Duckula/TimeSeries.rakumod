use v6.d;
use Duckula::SQL;
use Duckula::Clean;
use Duckula::X::Frame;

#| 时间序列算子（v0.27.0）：rolling / expanding / ewm / resample。
#|
#| 前两类能完整下推到 DuckDB 的窗口函数；ewm 要递推、resample 要时间桶，
#| 分别走「Raku 算好再写回」和「date_trunc / time_bucket 下推」两条路。
#| 这里的类都不引用 Frame / Series 类型——前向引用会让 resolver 崩，
#| 统一用闭包把动作交回调用方。
unit module Duckula::TimeSeries;

my constant %ROLL-FN = set <sum avg min max count stddev_samp stddev_pop
                             var_samp var_pop median>;
my constant %FN-ALIAS = (
    mean => 'avg', std => 'stddev_samp', var => 'var_samp',
    sd   => 'stddev_samp', sample => 'stddev_samp',
);

#| 聚合函数名归一：pandas 的 mean/std/var 映射到 SQL 的 avg/stddev_samp/
#| var_samp；其余按原名。白名单挡住任意字符串进 SQL。
our sub check-roll-fn(Str:D $fn --> Str) is export {
    my Str $f = %FN-ALIAS{$fn.lc} // $fn.lc;
    die Duckula::X::Frame.new(
        reason => "unknown window aggregator '$fn'; use one of "
                ~ <%ROLL-FN.keys.sort.join(', ')>
    ) unless %ROLL-FN{$f};
    $f;
}

#| `ROWS BETWEEN` 帧子句。center=True 时把窗口对称铺在当前行两侧；
#| 偶数窗口多出来的一行放在前面（和 pandas 的 center 一致）。
our sub rolling-frame(Int:D $w, Bool:D :$center = False --> Str) is export {
    die Duckula::X::Frame.new(reason => "window must be >= 1, got $w") if $w < 1;
    return "ROWS BETWEEN {$w - 1} PRECEDING AND CURRENT ROW" unless $center;
    my Int $before = $w div 2;
    my Int $after  = $w - 1 - $before;
    "ROWS BETWEEN $before PRECEDING AND $after FOLLOWING";
}

our sub expanding-frame(--> Str) is export {
    'ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW';
}

#| pandas 频率字符串 → DuckDB 的桶表达式。
#|
#| 子日频率（可带倍数，如 `15min`）用 `time_bucket`；日及以上用
#| `date_trunc`。注意 pandas 的 `M/Q/Y` 是「周期末」，这里对齐到周期
#| 起始（和 Polars 的 `dt.truncate` 一致），文档里会写明。
our sub check-resample-rule(Str:D $rule --> Hash) is export {
    my Str $r = $rule.trim.lc;
    $r = $r.subst(/\s+/, '', :g);
    die Duckula::X::Frame.new(reason => 'resample rule cannot be empty')
        unless $r.chars;

    my $m = $r.match(/^ $<n>=(\d*) $<u>=(ms|s|min|t|h|d|w|m|q|y|a) $/);
    die Duckula::X::Frame.new(
        reason => "unsupported resample rule '$rule'; use e.g. "
                ~ "'15min', 'H', 'D', 'W', 'M', 'Q', 'Y'"
    ) unless $m;

    my Int $n = $m<n>.Str eq '' ?? 1 !! $m<n>.Int;
    die Duckula::X::Frame.new(reason => 'resample multiplier must be >= 1')
        if $n < 1;

    my Str $u = $m<u>.Str;
    my %sub-day = s => 'second', ms => 'millisecond', min => 'minute',
                  t => 'minute', h => 'hour';
    if %sub-day{$u}:exists {
        my Str $unit = %sub-day{$u};
        # time_bucket 认 '15 minutes' / '1 hour' / '500 milliseconds'。
        my Str $word = $u eq 's' ?? 'second'
                     !! $u eq 'ms' ?? 'millisecond'
                     !! ($u eq 'min' || $u eq 't') ?? 'minute'
                     !! 'hour';
        my Str $interval = $n == 1 ?? "1 $word" !! "$n {$word}s";
        return %{ kind => 'bucket', unit => $unit, interval => $interval };
    }

    die Duckula::X::Frame.new(
        reason => "multiplier $n is not supported for calendar rule '$u'; "
                ~ 'only sub-daily rules accept a multiplier'
    ) if $n != 1;

    my %calendar = d => 'day', w => 'week', m => 'month', q => 'quarter',
                   y => 'year', a => 'year';
    %{ kind => 'trunc', unit => %calendar{$u} };
}

our sub resample-bucket-sql(Str:D $rule, Str:D $column --> Str) is export {
    my Hash $r = check-resample-rule($rule);
    $r<kind> eq 'bucket'
        ?? 'time_bucket(INTERVAL ' ~ sql-literal($r<interval>)
           ~ ', ' ~ quote-ident($column) ~ ')'
        !! 'date_trunc(' ~ sql-literal($r<unit>) ~ ', '
           ~ quote-ident($column) ~ ')';
}

#| `s.rolling(3)` 返回的对象。每个聚合都走同一支闭包，最终仍是 Series。
class Duckula::Rolling {
    has &.run is required;
    has Int $.window is required;
    method sum   { &!run('sum') }
    method mean  { &!run('mean') }
    method min   { &!run('min') }
    method max   { &!run('max') }
    method count { &!run('count') }
    method std   { &!run('std') }
    method var   { &!run('var') }
    method median { &!run('median') }
}

#| `s.expanding` 返回的对象，方法与 Rolling 一致。
class Duckula::Expanding {
    has &.run is required;
    method sum   { &!run('sum') }
    method mean  { &!run('mean') }
    method min   { &!run('min') }
    method max   { &!run('max') }
    method count { &!run('count') }
    method std   { &!run('std') }
    method var   { &!run('var') }
    method median { &!run('median') }
}

#| `s.ewm(...)` 返回的对象。DuckDB 没有指数加权窗口函数，这里在 Raku
#| 侧做递推，再通过闭包写回 Duckula::Series，保持后续链式能力。
class Duckula::Ewm {
    has @.values;
    has Num:D $.alpha = 0.5e0;
    has Bool:D $.adjust = True;
    has Int:D $.min-periods = 1;
    has &.write is required;

    method mean {
        my @out;
        my Num $num = 0e0;
        my Num $den = 0e0;
        my Int $seen = 0;
        my Num $last = 0e0;

        for @!values -> $v {
            unless $v.defined {
                @out.push: Any;
                next;
            }
            # DECIMAL / HUGEINT 列在 ColumnView 里可能是十进制字符串，
            # 先转成 Num 再做递推，免得结果列变成字符串。
            my Num $x = do given $v {
                when Numeric { .Num }
                when Str     { .Num }
                default {
                    die Duckula::X::Frame.new(
                        reason => 'ewm() needs numeric values, got ' ~ $v.^name);
                }
            };
            die Duckula::X::Frame.new(
                reason => 'ewm() cannot handle NaN or infinite values'
            ) if $x != $x || $x == Inf || $x == -Inf;
            $seen++;
            if $!adjust {
                $num = $!alpha * $x + (1e0 - $!alpha) * $num;
                $den = $!alpha          + (1e0 - $!alpha) * $den;
                @out.push: $seen >= $!min-periods ?? $num / $den !! Any;
            } else {
                $last = $seen == 1 ?? $x !! $!alpha * $x + (1e0 - $!alpha) * $last;
                @out.push: $seen >= $!min-periods ?? $last !! Any;
            }
        }
        &!write(@out);
    }
}

#| `df.resample('15min', :on<ts>)` 返回的对象。`.agg(...)` 先把时间列
#| 换成桶起点，再走现成的 group-by，于是白名单、聚合命名、NULL 语义全部
#| 与 group-by 一致。
class Duckula::Resample {
    has $.frame is required;
    has Str:D $.column is required;
    has Str:D $.bucket is required;

    method agg(*@exprs, *%extra) {
        reject-named(%extra, 'resample().agg');
        die Duckula::X::Frame.new(reason => 'resample().agg() needs at least one expression')
            unless @exprs.elems;
        my $b = $!frame.derived(
            'SELECT * REPLACE (' ~ $!bucket ~ ' AS ' ~ quote-ident($!column)
            ~ ') FROM (' ~ $!frame.relation-sql ~ ') AS __duckula_bucket'
        );
        my $g = $b.group-by($!column).agg(|@exprs);
        $g.derived('SELECT * FROM (' ~ $g.relation-sql
                   ~ ') AS __duckula_resampled ORDER BY 1');
    }
}

# ============================================================
# 时区与 Period（v0.29.0）
# ============================================================
#
# 时区：DuckDB 原生 `AT TIME ZONE` 双向转换，时区名走 sql-literal。
#   tz-localize:  naive TIMESTAMP → TIMESTAMPTZ（把墙钟钉到某时区）
#   tz-convert:   TIMESTAMPTZ → 另一时区的墙钟 TIMESTAMP（同一时刻换显示）
# Period：用 date_trunc 求周期起点，起点 + 一个周期 - 一个最小单位求终点。
# 频率字符串走白名单，绝不拼进 SQL 原文。

#| 时区名的基本形状校验。DuckDB 自己会进一步查 IANA 库；这里先挡住
#| 引号/分号/空白这类明显不是时区名的字符（具体名字仍走 sql-literal）。
our sub check-tz(Str:D $tz --> Str) is export {
    die Duckula::X::Frame.new(reason => 'time zone name cannot be empty')
        unless $tz.chars;
    die Duckula::X::Frame.new(
        reason => "invalid time zone name {$tz.raku}; expected an IANA name "
                ~ "like 'Asia/Shanghai' or 'UTC'"
    ) unless $tz ~~ /^ <[A..Z a..z 0..9 _ \/ + \-]> + $/;
    $tz;
}

#| naive TIMESTAMP 钉到某时区 → TIMESTAMPTZ。
our sub tz-localize-sql(Str:D $col, Str:D $tz --> Str) is export {
    '(CAST(' ~ $col ~ ' AS TIMESTAMP) AT TIME ZONE ' ~ sql-literal(check-tz($tz)) ~ ')';
}

#| TIMESTAMPTZ 换成目标时区的墙钟 → TIMESTAMP。
our sub tz-convert-sql(Str:D $col, Str:D $tz --> Str) is export {
    '(CAST(' ~ $col ~ ' AS TIMESTAMPTZ) AT TIME ZONE ' ~ sql-literal(check-tz($tz)) ~ ')';
}

#| 某时区相对 UTC 的偏移小时数（如 8 或 5.5）。
#|
#| 不用 strftime 的 %z：那个取的是**会话时区**的偏移，与目标时区无关
#| （TIMESTAMPTZ 的显示也跟着会话时区走）。改用两个 localize 的 epoch 差：
#| 同一墙钟钉到目标时区和 UTC，时刻差就是该时区的偏移秒数，除以 3600 得小时。
our sub tz-offset-sql(Str:D $col, Str:D $tz --> Str) is export {
    my Str $t   = sql-literal(check-tz($tz));
    my Str $utc = sql-literal('UTC');
    '((epoch(CAST(' ~ $col ~ ' AS TIMESTAMP) AT TIME ZONE ' ~ $utc ~ ')'
        ~ ' - epoch(CAST(' ~ $col ~ ' AS TIMESTAMP) AT TIME ZONE ' ~ $t ~ '))'
        ~ ' / 3600.0)';
}

#| Period 频率白名单。value 是 date_trunc 的 part；step 用于终点计算。
my constant %PERIOD = (
    y    => %(part => 'year',       step => 'INTERVAL 1 YEAR',   back => 'INTERVAL 1 SECOND', ordinal => 'year'),
    a    => %(part => 'year',       step => 'INTERVAL 1 YEAR',   back => 'INTERVAL 1 SECOND', ordinal => 'year'),
    q    => %(part => 'quarter',    step => 'INTERVAL 3 MONTH',  back => 'INTERVAL 1 SECOND', ordinal => 'quarter'),
    m    => %(part => 'month',      step => 'INTERVAL 1 MONTH',  back => 'INTERVAL 1 SECOND', ordinal => 'month'),
    w    => %(part => 'week',       step => 'INTERVAL 7 DAY',    back => 'INTERVAL 1 SECOND', ordinal => 'week'),
    d    => %(part => 'day',        step => 'INTERVAL 1 DAY',    back => 'INTERVAL 1 SECOND', ordinal => 'dayofyear'),
    h    => %(part => 'hour',       step => 'INTERVAL 1 HOUR',   back => 'INTERVAL 1 SECOND', ordinal => 'hour'),
    't'  => %(part => 'minute',     step => 'INTERVAL 1 MINUTE', back => 'INTERVAL 1 SECOND', ordinal => 'minute'),
    min  => %(part => 'minute',     step => 'INTERVAL 1 MINUTE', back => 'INTERVAL 1 SECOND', ordinal => 'minute'),
    s    => %(part => 'second',     step => 'INTERVAL 1 SECOND', back => 'INTERVAL 1 MILLISECOND', ordinal => 'second'),
);

our sub check-period-freq(Str:D $freq --> Hash) is export {
    my Str $f = $freq.trim.lc;
    die Duckula::X::Frame.new(
        reason => "unsupported period frequency '$freq'; use one of "
                ~ <%PERIOD.keys.sort.join(', ')>
    ) unless %PERIOD{$f};
    %PERIOD{$f};
}

#| 周期起点：date_trunc(part, col)。
our sub period-start-sql(Str:D $col, Str:D $freq --> Str) is export {
    my %p = check-period-freq($freq);
    'date_trunc(' ~ sql-literal(%p<part>) ~ ', ' ~ $col ~ ')';
}

#| 周期终点：起点 + 一个周期 - 一个最小单位，落在周期最后一刻。
our sub period-end-sql(Str:D $col, Str:D $freq --> Str) is export {
    my %p = check-period-freq($freq);
    '(' ~ period-start-sql($col, $freq) ~ ' + ' ~ %p<step>
        ~ ' - ' ~ %p<back> ~ ')';
}

#| 周期内的序号（年/季/月/周/日序号），对标 pandas Period 的序数部件。
our sub period-ordinal-sql(Str:D $col, Str:D $freq --> Str) is export {
    my %p = check-period-freq($freq);
    %p<ordinal> ~ '(' ~ $col ~ ')';
}
