use v6.d;
use Duckula::SQL;
use Duckula::Guard;
use Duckula::Clean;
use Duckula::Index;
use Duckula::IndexLabels;
use Duckula::Reshape;
use Duckula::GroupOps;
use Duckula::Stats;
use Duckula::Expr;
use Duckula::GroupBy;
use Duckula::Join;
use Duckula::AsOf;
use Duckula::Plan;
use Duckula::Dtype;
use Duckula::Write;
use Duckula::X::Frame;

#| Polars 风格的惰性 Frame：**攒计划树，`collect` 才一次成型**。
#|
#| 和 `Frame` 的分工（§8.3）：
#|   - `Frame`：每次算子立刻拼一条 SQL，`relation-sql` 是真相。用起来像 pandas，
#|     链式十步就是十层子查询 —— DuckDB 吃得下，但 SQL 不好读。
#|   - `LazyFrame`：只累积计划节点，`collect` 时才渲染成**一条**扁平的 SQL。
#|     相邻 filter 合并成一个 WHERE，filter 与 group-by 待在同一层。
#|
#| 两者共享全部语义（列名白名单、表达式、聚合规则、join 后缀规则、窗口锚定），
#| 差别只在「什么时候拼 SQL」。所以同一段逻辑跑出来的**结果必须一致**——
#| `t/12-lazy.rakutest` 就是拿 eager 结果当标准答案来对账的。
#|
#| 刻意 `use` 了 `Duckula::GroupBy` / `Duckula::Join` / `Duckula::Plan`，
#| 但**没有** `use Duckula::Session` 与 `Duckula::Frame`：`Frame` 要 `use`
#| 本模块来实现 `.lazy`，反向 `use` 会形成预编译循环。会话与结果对象在这里
#| 一律按鸭子类型使唤（`$!session.sql(...)`、`$right.relation-sql`）。
class Duckula::LazyFrame {
    has $.session is required;
    has Duckula::Plan $.plan is required;

    #| 声明式 key 列（v0.22.0）。只在元数据里，不改变 Plan 树。
    has List $.index-cols = ();

    #| 声明式逻辑 dtype（v0.30.0），collect 时贴回 Frame。
    has Hash $!dtype-meta = {};

    has @!names-cache;
    has Bool $!names-known = False;

    #| `with-row-index` 生成的行号列名（语义见 `Frame` 的同名属性）。
    has $!row-index-col;

    # 私有属性不会被默认 BUILD 从 .new 的具名参数里填，必须自己接一下。
    submethod BUILD(:$!session!, :$!plan!, :$index-cols, :$dtype-meta,
                    :$row-index-col) {
        $!index-cols = $index-cols.defined ?? $index-cols.List !! ();
        $!dtype-meta = $dtype-meta.defined ?? $dtype-meta.Hash !! {};
        $!row-index-col = $row-index-col;
    }

    #| 已经收集好的 `Frame`（`collect` 的产物），只用来避免重复执行。
    method lazy(--> Duckula::LazyFrame) { self }

    method !derive(Duckula::Plan:D $p, List :$index-cols,
                   Hash :$dtype-meta, :$row-index-col --> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(
            session    => $!session,
            plan       => $p,
            index-cols => $index-cols.defined ?? $index-cols !! $!index-cols,
            dtype-meta => $dtype-meta.defined ?? $dtype-meta !! $!dtype-meta,
            row-index-col => $row-index-col.defined ?? $row-index-col !! $!row-index-col,
        );
    }

    #| 渲染成 (SQL, 参数)。
    #|
    #| 参数**不固化**：`?` 一直留到 `collect` 才由驱动绑定，所以惰性路径下
    #| 值从头到尾都没进过 SQL 文本。这是比 eager 路径更严的一条线。
    method !compiled(--> List) { compile-plan($!plan) }

    #| 生成的 SQL（调试/日志用）。注意带 `?` 占位符时不能直接拿去执行。
    method relation-sql(--> Str) { self!compiled[0] }

    #| 列名。只问 schema（`LIMIT 0`），不搬数据，结果缓存。
    method names(--> List) {
        return @!names-cache.List if $!names-known;

        my ($sql, $params) = self!compiled;
        my $res = $!session.conn.query(
            "SELECT * FROM ($sql) AS __duckula_lazy_names LIMIT 0", |$params.List);

        @!names-cache = $res.names.List;
        $!names-known = True;
        @!names-cache.List;
    }

    #| 真的执行。等价于 `duckula.sql(计划渲染出的 SQL)`，但参数走绑定。
    method collect() {
        my ($sql, $params) = self!compiled;
        my $f = $params.elems
            ?? $!session.sql($sql, |$params)
            !! $!session.sql($sql);
        $f = $f.set-index($!index-cols.List) if $!index-cols.elems;
        $f = $f.with-dtype-meta($!dtype-meta) if $!dtype-meta.elems;
        $f = $f.with-row-index-meta($!row-index-col) if $!row-index-col.defined;
        $f;
    }

    #| `collect` 之后导出 Arrow（schema + 逐块 array）。
    #|
    #| 惰性路径没法把 Arrow 也推迟 —— Arrow 的 chunk 就是执行结果本身 ——
    #| 所以这里是计划树的终点，语义等同 `self.collect.arrow`。
    method arrow() {
        self.collect.arrow;
    }

    #| 执行并直接写成 Arrow IPC 文件；语义等同 `self.collect.write-ipc(...)`。
    method write-ipc(Str:D $path, Str:D :$format = 'file' --> Nil) {
        self.collect.write-ipc($path, :$format);
    }

    #| 执行并编码成内存里的 IPC 字节；语义等同 `self.collect.ipc-buf(...)`。
    #|
    #| 这是惰性路径唯一的「执行点」——不 collect 就拿不到字节。
    method ipc-buf(Str:D :$format = 'stream' --> Buf) {
        self.collect.ipc-buf(:$format);
    }

    # ---------------------------------------------------------------- 写出

    #| 渲染出一条**不带占位符**的 SQL，供 `COPY` / `INSERT` 使用。
    #|
    #| 写文件的语句没法绑定参数（见 `Duckula::Write` 的说明），所以这里的
    #| 参数要提前变成字面量。这一步只发生在出库这一刻：计划树本身、以及
    #| `collect` 走的查询路径，仍然是绑定参数。
    method !write-sql(--> Str) {
        my ($sql, $params) = self!compiled;
        $params.elems ?? render-bindings($sql, $params.List) !! $sql;
    }

    #| 写成 Parquet，返回行数；语义等同 `self.collect.to-parquet(...)`，
    #| 但不会为了写文件多跑一次取数的查询。
    method to-parquet(Str:D $path, Str:D :$compression = 'zstd' --> Int) {
        Duckula::Write::write-parquet($!session, self!write-sql, $path,
                                      :$compression);
    }

    #| 写成 CSV，返回行数。
    method to-csv(
        Str:D $path,
        Bool:D :$header = True,
        Str:D :$delimiter = ',',
        Str:D :$quote = '"',
        Str :$null,
        --> Int
    ) {
        Duckula::Write::write-csv($!session, self!write-sql, $path,
                                  :$header, :$delimiter, :$quote, :$null);
    }

    #| 写成 JSON / NDJSON，返回行数；语义等同 collect 之后导出。
    method to-json(Str:D $path, Str:D :$format = 'array' --> Int) {
        Duckula::Write::write-json($!session, self!write-sql, $path, :$format);
    }

    #| 写成 XLSX，返回行数。有扩展且用默认 sheet 名时直接 COPY，
    #| 连 collect 都不做；只有兜底路径才惰性 collect 一次拿 rows/names。
    method to-excel(Str:D $path, Str:D :$sheet = 'Sheet1' --> Int) {
        my $frame;
        my &lazy-rows  = -> { $frame = self.collect unless $frame.defined; $frame.rows };
        my &lazy-names = -> { $frame = self.collect unless $frame.defined; $frame.names };
        Duckula::Write::write-excel($!session, self!write-sql, $path,
                                    :$sheet, rows => &lazy-rows,
                                    names => &lazy-names);
    }

    #| 变成一张真表，返回行数。
    method to-table(
        Str:D $name,
        Bool:D :$replace = True,
        Bool:D :$temporary = False,
        --> Int
    ) {
        Duckula::Write::create-table($!session, self!write-sql, $name,
                                     :$replace, :$temporary);
    }

    #| 把本计划写进 SQL 库的表（对标 pandas `DataFrame.to_sql`，v0.29.0）。
    #| 惰性路径直接把编译好的 SQL 交给 COPY/CREATE，不需要先 collect。
    method to-sql(
        Str:D $table,
        Str :$db,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Str:D :$if-exists = 'replace',
        --> Int
    ) {
        $!session.to-sql(
            $table, self!write-sql, :$db, :$alias, :$schema, :$if-exists
        );
    }

    #| 追加到已有表，返回插入行数。
    method append-to(Str:D $table --> Int) {
        Duckula::Write::insert-into($!session, self!write-sql, $table);
    }

    #| 计划树 + 生成的 SQL，一次看全。
    #|
    #| 有它就是计划树相对 eager 路径最直接的收益：出问题时不用再从
    #| `relation-sql` 那坨嵌套里反推「到底算了什么」。
    method explain(--> Str) {
        my ($sql, $params) = self!compiled;
        my Str $out = "计划：\n" ~ describe-plan($!plan)
                    ~ "\nSQL：\n$sql\n";
        $out ~= "\n参数：{$params.raku}\n" if $params.elems;
        $out;
    }

    # ---------------------------------------------------------------- 列名校验

    method !check-columns(Set $cols, Str:D $op --> Nil) {
        return unless $cols.elems;
        my Set $known = self.names.Set;
        for $cols.keys.sort -> $c {
            die Duckula::X::Frame.new(
                reason => "$op refers to unknown column '$c'; "
                        ~ "available: {self.names.join(', ')}"
            ) unless $known{$c};
        }
    }

    # ---------------------------------------------------------------- 算子

    #| 过滤。表达式版：
    #|   $lf.filter(col('amount') > 100);
    #| SQL 片段版（值走 `?` 绑定）：
    #|   $lf.filter('amount > ?', 100);
    multi method filter(Duckula::Expr:D $pred --> Duckula::LazyFrame) {
        self!check-columns($pred.columns, 'filter');
        self!derive(plan-filter($!plan, $pred.render));
    }

    multi method filter(Str:D $pred, *@args, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'filter');
        check-fragment($pred, :params(@args.elems));
        self!derive(plan-filter($!plan, $pred, |@args));
    }

    #| pandas 风格别名：与 filter(Str) 完全同义。
    method query(Str:D $expr, *@args, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'query');
        self.filter($expr, |@args);
    }

    # ---------------------------------------------------------------- 逻辑索引
    # 与 Frame 同语义：行号是一列显式投影，不藏元数据。能进 Plan 树的
    # with-row-index 走 plan-project；iloc 因为要重排/计数，包成 Source 节点。

    method with-row-index(Str:D :$name = 'index', Int:D :$offset = 0 --> Duckula::LazyFrame) {
        my Bool $replace = $name ∈ self.names.Set;
        my Str $q = quote-ident($name);
        my Str $head = $replace ?? '* EXCLUDE (' ~ $q ~ ')' !! '*';
        self!derive(plan-project(
            $!plan,
            items => ($head, row-index-expr(:$offset) ~ ' AS ' ~ $q),
        ), row-index-col => $name);
    }

    multi method index(--> Duckula::IndexLabels) {
        Duckula::IndexLabels.new(
            lazy-frame => self,
            levels     => $!index-cols.List,
            row-based  => $!index-cols.elems == 0,
        );
    }

    multi method index(Str:D :$name!, Int:D :$offset = 0) {
        my $src = $name ∈ self.names.Set
            ?? self
            !! self.with-row-index(:$name, :$offset);
        $src.collect.column($name);
    }

    #| 按行号取子集（语义见 `Frame.iloc`）。只有被 `with-row-index` 标记过
    #| 的列才复用；数据里恰好同名的列按位置重新编号，临时行号列过滤后
    #| EXCLUDE 掉，不会在结果里多出一列。
    method iloc($rows, Str:D :$name = 'index' --> Duckula::LazyFrame) {
        my @names = self.names;
        my Set $has = @names.Set;
        my Bool $reuse = $!row-index-col.defined
                       && $!row-index-col eq $name
                       && $has{$name};

        if !$reuse && !$has{$name} {
            my $src = self.with-row-index(:$name);
            my ($sql, $params) = $src!compiled;
            return $src!derive(plan-source(
                iloc-sql($sql, $name, $rows, $src.names.List), |$params));
        }

        my Str $key = $reuse ?? $name
                    !! private-name(@names, '__duckula_iloc_rn');
        my $plan-src = $reuse ?? self !! self.with-row-index(:name($key));
        my ($sql, $params) = $plan-src!compiled;
        Duckula::LazyFrame.new(
            session       => $!session,
            plan          => plan-source(iloc-sql(
                $sql, $key, $rows, @names, :drop($reuse ?? Str !! $key)), |$params),
            index-cols    => $!index-cols,
            dtype-meta    => $!dtype-meta,
            row-index-col => $!row-index-col,
        );
    }

    multi method loc(Str:D $col, $value --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(
            reason => "loc: no column named '$col'; available: {self.names.join(', ')}"
        ) unless $col ∈ self.names.Set;
        self.filter(col($col) == $value);
    }

    multi method loc($label --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'loc(label) needs a key; call set-index first'
        ) unless @keys.elems;
        self.filter(index-loc-expr(@keys, $label));
    }

    method xs($value, :$level = 0 --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'xs needs a key; call set-index first')
            unless @keys.elems;
        my Int $i = level-index(@keys, $level);
        my @rest = remove-level(@keys, $i);
        my $f = self.filter(col(@keys[$i]) == $value);
        @rest.elems ?? $f.set-index(@rest) !! $f.reset-index;
    }

    method sort-index(Bool :$desc = False --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'sort-index needs a key; call set-index first')
            unless @keys.elems;
        my ($sql, $params) = self!compiled;
        my Str $order = @keys.map({
            quote-ident($_) ~ ($desc ?? ' DESC' !! ' ASC')
        }).join(', ');
        self!derive(plan-source(
            'SELECT * FROM (' ~ $sql ~ ') AS __duckula_sort_index ORDER BY ' ~ $order,
            |$params.List,
        ));
    }

    method swaplevel($a = 0, $b = 1 --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'swaplevel needs at least two levels')
            unless @keys.elems >= 2;
        self!derive($!plan, index-cols => swap-levels(@keys, $a, $b));
    }

    method droplevel($level = -1 --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'droplevel needs a key; call set-index first')
            unless @keys.elems;
        self!derive($!plan, index-cols => remove-level(@keys, $level));
    }

    method get-level-values($level) { self.collect.index.get-level-values($level) }

    # ---------------------------------------------------------------- 声明式 key 索引
    # 与 eager 同语义：key 清单是元数据，不进 Plan 树；collect 时贴回 Frame。

    method set-index(*@cols, Bool :$append = False, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'set-index');
        my @flat = flatten-args(@cols);
        my @keys = $append ?? (|$!index-cols.List, |@flat) !! @flat;
        check-index-cols(@keys, self.names, 'set-index');
        self!derive($!plan, index-cols => @keys.List);
    }

    multi method reset-index(Bool :$drop = False --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        return self unless @keys.elems;
        my $f = self!derive($!plan, index-cols => ());
        $drop ?? $f.drop(@keys) !! $f;
    }

    multi method reset-index($level, Bool :$drop = False --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(reason => 'reset-index needs a key; call set-index first')
            unless @keys.elems;
        my @rest = remove-level(@keys, $level);
        my $f = self!derive($!plan, index-cols => @rest.List);
        $drop ?? $f.drop((@keys[level-index(@keys, $level)],).List) !! $f;
    }

    multi method reindex(:$fill --> Duckula::LazyFrame) { self.head(0) }

    multi method reindex(+@rows, :$fill --> Duckula::LazyFrame) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'reindex needs a key; call set-index first'
        ) unless @keys.elems;

        my @raw = @rows.elems == 1 && @rows[0] ~~ Positional
            ?? @rows[0].List !! @rows.List;
        my @norm = @raw.map({ ($_ ~~ Positional ?? $_.List !! ($_,).List).item }).List;
        return self.head(0) unless @norm.elems;

        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            reindex-sql($sql, @keys, @norm, self.names, :$fill), |$params,
        ));
    }

    #| 投影。列名过白名单。
    method select(*@cols, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'select');
        my @flat = @cols.elems == 1 && @cols[0] ~~ Positional
            ?? @cols[0].List
            !! @cols.List;

        die Duckula::X::Frame.new(reason => 'select() needs at least one column')
            unless @flat.elems;

        my Set $known = self.names.Set;
        my @items;
        for @flat -> $c {
            my Str $n = $c.Str;
            die Duckula::X::Frame.new(
                reason => "no column named '$n'; available: {self.names.join(', ')}"
            ) unless $known{$n};
            @items.push: quote-ident($n) ~ ' AS ' ~ quote-ident($n);
        }

        self!derive(plan-project($!plan, items => @items.List));
    }

    #| 新增（或覆盖）一列。规则和 `Frame.with-column` 完全一致：
    #| 裸聚合补 `OVER ()` 广播、窗口表达式锚定行号、覆盖同名列先 EXCLUDE。
    multi method with-column(Duckula::Expr:D $e, Str :$name --> Duckula::LazyFrame) {
        my $raw = $name // $e.as;
        die Duckula::X::Frame.new(
            reason => 'with-column needs an alias: '
                    ~ 'use .alias("name") on the expression or pass :name<name>'
        ) unless $raw.defined && $raw.Str ne '';
        my Str $n = $raw.Str;

        self!check-columns($e.columns, 'with-column');

        my Str $expr = $e.render;
        my Bool $anchored = False;

        if $e.window.defined {
            $anchored = True;
        } elsif $e.bare-agg {
            $expr ~= ' OVER ()';
        } elsif $e.is-aggregate {
            die Duckula::X::Frame.new(
                reason => "with-column can't use an aggregate inside a larger "
                        ~ "expression ('$expr'); put .over() on each aggregate, "
                        ~ "e.g. (col('x').sum.over / len().over)"
            );
        }

        my Set $known = self.names.Set;
        my Bool $replace = $n ∈ $known;
        my Str $alien = quote-ident($n);

        if $anchored {
            # 锚定那层由渲染器拼，覆盖列交给它的 `exclude` 字段。
            my Str $rn = '__duckula_ord';
            $rn ~= '_' while $rn ∈ $known;

            return self!derive(plan-project(
                $!plan,
                items    => ($expr ~ ' AS ' ~ $alien,),
                anchored => True,
                exclude  => $replace ?? $alien !! '',
                anchor   => $rn,
            ));
        }

        my Str $head = $replace ?? '* EXCLUDE (' ~ $alien ~ ')' !! '*';
        self!derive(plan-project(
            $!plan,
            items => ($head, $expr ~ ' AS ' ~ $alien),
        ));
    }

    multi method with-columns(*@exprs, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'with-columns');
        my @flat = @exprs.elems == 1 && @exprs[0] ~~ Positional
            ?? @exprs[0].List
            !! @exprs.List;

        my $f = self;
        for @flat -> $e {
            $f = $f.with-column($e);
        }
        $f;
    }

    #| 分组，返回中间对象（和 eager 路径是同一个类）。
    #| `GroupBy.agg` 会调我们的 `agg-from-spec`，于是聚合也进计划树。
    method group-by(*@keys, *%extra --> Duckula::GroupBy) {
        reject-named(%extra, 'group-by');
        my @flat = @keys.elems == 1 && @keys[0] ~~ Positional
            ?? @keys[0].List
            !! @keys.List;

        my @exprs = @flat.map(-> $k {
            $k ~~ Duckula::Expr ?? $k !! col($k.Str);
        });

        for @exprs -> Duckula::Expr $e {
            self!check-columns($e.columns, 'group-by');
        }

        Duckula::GroupBy.new(frame => self, keys => @exprs);
    }

    method agg(*@aggs, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'agg');
        Duckula::GroupBy.new(frame => self, keys => ()).agg(|@aggs);
    }

    #| `GroupBy.agg` 的钩子：接住已经校验好的投影，造计划节点。
    #| 位置分组（`GROUP BY 1, 2`）与 eager 路径保持一致。
    method agg-from-spec(Hash $spec, List $keys --> Duckula::LazyFrame) {
        my List $group = $keys.elems ?? (1 .. $keys.elems).List !! ();
        self!derive(plan-aggregate(
            $!plan,
            items => $spec<items>.List,
            group => $group,
        ));
    }

    method sort-values(Str:D $column, Bool :$desc = False --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(
            reason => "no column named '$column'; available: {self.names.join(', ')}"
        ) unless $column ∈ self.names.Set;

        self!derive(plan-sort(
            $!plan,
            order => (quote-ident($column) ~ ($desc ?? ' DESC' !! ''),),
        ));
    }

    method limit(Int $n = 5 --> Duckula::LazyFrame) { self.head($n) }

    method head(Int $n = 5 --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(reason => "head() needs a non-negative count, got $n")
            if $n < 0;
        self!derive(plan-limit($!plan, $n));
    }

    #| 末尾 n 行。要数总行数，所以在这里就把上游渲染成子查询 ——
    #| 计划树在这个节点断开，但数据仍然只扫一遍（§8.10）。
    method tail(Int $n = 5 --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(reason => "tail() needs a non-negative count, got $n")
            if $n < 0;
        return self.head(0) if $n == 0;

        my ($sql, $params) = self!compiled;
        my Set $known = self.names.Set;

        my Str $rn = '__duckula_rn';
        $rn ~= '_' while $rn ∈ $known;
        my Str $cnt = $rn ~ '_n';
        $cnt ~= '_' while $cnt ∈ $known;

        my Str $tail =
            'SELECT * EXCLUDE (' ~ quote-ident($rn) ~ ', ' ~ quote-ident($cnt) ~ ') '
          ~ 'FROM (SELECT *, row_number() OVER () AS ' ~ quote-ident($rn)
          ~ ', count(*) OVER () AS ' ~ quote-ident($cnt)
          ~ ' FROM (' ~ $sql ~ ') AS __duckula_tail_w) AS __duckula_tail '
          ~ 'WHERE ' ~ quote-ident($rn) ~ ' > ' ~ quote-ident($cnt) ~ ' - ' ~ $n;

        self!derive(plan-source($tail, |$params));
    }

    #| 切片。负 offset 从末尾算，代价是一次 `count(*)`。
    method slice(Int $offset, Int $length? --> Duckula::LazyFrame) {
        die Duckula::X::Frame.new(reason => "slice() needs a non-negative length, got $length")
            if $length.defined && $length < 0;

        my ($sql, $params) = self!compiled;
        my Str $lim = $length.defined ?? ' LIMIT ' ~ $length !! '';

        return self!derive(plan-source(
            "SELECT * FROM ($sql) AS __duckula_slice" ~ $lim ~ ' OFFSET ' ~ $offset,
            |$params,
        )) if $offset >= 0;

        my Str $skip = 'greatest(count(*) - ' ~ $offset.abs ~ ', 0)';
        # 关系出现两次（一次取数、一次数行数），所以参数也要给两遍。
        my @twice = (|$params.List, |$params.List);
        self!derive(plan-source(
            "SELECT * FROM ($sql) AS __duckula_slice" ~ $lim
            ~ " OFFSET (SELECT $skip FROM ($sql) AS __duckula_count)",
            |@twice,
        ));
    }

    # ---------------------------------------------------------------- 清洗与重塑
    #
    # 和 eager 路径同一批语义，只是落点不同：
    #   - `rename` / `drop` / `cast` / `fill-nulls`（定值、mean、median）能表达成
    #     投影，`drop-nulls` 能表达成过滤 —— 全部进计划树，后续的 filter 还能
    #     和它们合并成一层；
    #   - `concat`（集合运算）、`unique` / `value-counts` / `fill-nulls`
    #     （ffill / bfill，要行序锚）需要三层嵌套或集合运算，`Plan::Query`
    #     表达不了，所以在这里渲染成 SQL、包成 `Source` 节点往下走。参数顺序
    #     照样保留（子查询 SQL 总在外层子句之前）。

    #| 纵向拼接（同 `Frame.concat`，右侧可以混用 Frame 与 LazyFrame）。
    multi method concat(*@others, Bool :$strict = False, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'concat');
        my @flat = flatten-args(@others);
        die Duckula::X::Frame.new(
            reason => 'concat needs at least one other frame'
        ) unless @flat.elems;

        my ($sql, $params) = self!compiled;

        my @sqls;
        @sqls.push: $sql;

        my @params;
        @params.append: $params.List;

        # 每帧的列名各占一个元素（List 套 List），供 :strict 逐帧比对。
        my @names;
        @names.push: self.names;

        for @flat -> $o {
            die Duckula::X::Frame.new(
                reason => 'concat: every frame must belong to the same session'
            ) unless $o.can('session') && $o.session === $!session;

            if $o.can('plan') {
                my ($s, $p) = compile-plan($o.plan);
                @sqls.push: $s;
                @params.append: $p.List;
            } elsif $o.can('relation-sql') {
                @sqls.push: $o.relation-sql;
            } else {
                die Duckula::X::Frame.new(
                    reason => 'concat expects Frames or LazyFrames, got ' ~ $o.^name
                );
            }

            @names.push: $o.names;
        }

        check-same-columns(@names, 'concat(:strict)') if $strict;

        self!derive(plan-source(concat-sql(@sqls.List), |@params));
    }

    #| 去重（语义见 `Frame.unique`）。
    multi method unique(*@subset, Str :$keep = 'first', *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'unique');
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'unique');

        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            unique-sql($sql, @cols, $keep, @names), |$params.List
        ));
    }

    #| 单列频次表（语义见 `Frame.value-counts`）。
    method value-counts(
        Str:D $column,
        Bool :$sort = True,
        Bool :$normalize = False,
        Bool :$keep-nulls = False,
        --> Duckula::LazyFrame
    ) {
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            value-counts-sql($sql, $column, self.names,
                             :$sort, :$normalize, :$keep-nulls),
            |$params.List,
        ));
    }

    #| 改列名（语义见 `Frame.rename`）。进计划树，所以后面接 filter 能合并。
    multi method rename(*@maps, Bool :$strict = True, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'rename');
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        my $f = self!derive(plan-project(
            $!plan,
            items => rename-items(self.names, $map, :$strict),
        ));
        if $!index-cols.elems {
            my %ren;
            for as-pairs($map, 'rename') -> $p {
                %ren{$p.key.Str} = $p.value.Str;
            }
            my @keys = $!index-cols.List.map({
                %ren{$_}:exists ?? %ren{$_} !! $_
            }).List;
            $f = $f.set-index(@keys);
        }
        $f;
    }

    #| 删列（语义见 `Frame.drop`）。
    multi method drop(*@cols, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'drop');
        my @dropped = flatten-args(@cols);
        my $f = self!derive(plan-project(
            $!plan,
            items => drop-items(self.names, @dropped),
        ));
        if $!index-cols.elems {
            my @keys = $!index-cols.List.grep({ $_ ∉ @dropped.Set }).List;
            $f = @keys.elems ?? $f.set-index(@keys) !! $f.reset-index;
        }
        $f;
    }

    #| 删掉含空值的行（语义见 `Frame.drop-nulls`）。这就是一个过滤，能合并。
    multi method drop-nulls(*@subset, Str :$how = 'any', *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'drop-nulls');
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'drop-nulls');

        self!derive(plan-filter($!plan, null-predicate(@cols, $how)));
    }

    #| 填空值（语义见 `Frame.fill-nulls`）。
    multi method fill-nulls(*@subset, :$value, Str :$strategy, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'fill-nulls');
        my @names = self.names;
        my @cols = cols-or-all(flatten-args(@subset), @names);
        need-cols(@cols, @names, 'fill-nulls');

        my Str $mode = fill-mode(:$value, :$strategy);
        my Bool $win = needs-seq($mode);
        my Str $seq = $win ?? private-name(@names, '__duckula_seq') !! '';

        my @items = fill-items(@cols, $mode, :$value, :$seq);

        if $win {
            # 带行序锚的投影：渲染器知道怎么钉行号、算完再排回去（§8.9）。
            return self!derive(plan-project(
                $!plan,
                items    => @items.List,
                anchored => True,
                exclude  => quoted-list(@cols),
                anchor   => $seq,
            ));
        }

        self!derive(plan-project(
            $!plan,
            items => ('* EXCLUDE (' ~ quoted-list(@cols) ~ ')', |@items).List,
        ));
    }

    #| 改列类型（语义见 `Frame.cast`）。
    multi method cast(*@maps, Bool :$strict = False, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'cast');
        my @names = self.names;
        my $map = @maps.elems == 1 ?? @maps[0] !! @maps.List;
        my @pairs = as-pairs($map, 'cast');

        die Duckula::X::Frame.new(reason => 'cast needs at least one column')
            unless @pairs.elems;

        my ($sql, $params) = self!compiled;
        my %target;
        for @pairs -> $p {
            my Str $c = $p.key.Str;
            need-cols(($c,), @names, 'cast');
            my $d = as-dtype($p.value);
            %target{$c} = resolve-dtype($!session, $sql, $c, $d, $params.List);
            check-dtype-nulls($!session, $sql, $c, %target{$c}, $params.List, :$strict);
        }

        my @items = @names.map(-> $c {
            %target{$c}:exists
                ?? cast-expr-for($c, %target{$c}) ~ ' AS ' ~ quote-ident($c)
                !! quote-ident($c) ~ ' AS ' ~ quote-ident($c);
        });

        my %meta = $!dtype-meta.Hash;
        %meta{$_} = %target{$_} for %target.keys;
        self!derive(plan-project($!plan, items => @items.List), :dtype-meta(%meta));
    }

    #| pandas 的拼法；语义与 cast 一致。
    multi method astype(*@maps, Bool :$strict = False, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'astype');
        self.cast(|@maps, :$strict);
    }

    #| 列名 → Duckula::Dtype（v0.30.0），见 Frame.schema。
    method schema(--> Hash) {
        my ($sql, $params) = self!compiled;
        my Str $q = 'DESCRIBE SELECT * FROM (' ~ $sql
                  ~ ') AS __duckula_lazy_dtypes';
        my $res = $params.elems
            ?? $!session.conn.query($q, |$params.List)
            !! $!session.conn.query($q);
        my %out;
        for $res.arrays.List -> $row {
            my Str $name = $row[0].Str;
            %out{$name} = $!dtype-meta{$name}.defined
                ?? $!dtype-meta{$name}
                !! dtype-from-sql($row[1].Str);
        }
        %out;
    }

    #| 展开列表列（语义见 `Frame.explode`）。unnest 是合法投影，进计划树。
    multi method explode(*@cols, Bool :$keep-empty = True, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'explode');
        my @names = self.names;
        my @items = explode-items(@names, flatten-args(@cols), :$keep-empty);
        self!derive(plan-project($!plan, items => @items.List));
    }

    #| 宽转长（语义见 `Frame.unpivot`）。UNPIVOT 是表函数，断成 Source 节点。
    multi method unpivot(*@on, :$index, Str :$variable-name = 'variable',
                         Str :$value-name = 'value',
                         Bool :$keep-nulls = True, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'unpivot');
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @uncols = flatten-args(@on);
        @uncols = @names.grep({ !@idx.Set{$_} }) unless @uncols.elems;
        check-unpivot-columns(@uncols, @idx, @names);

        my Str $var = private-name(@names, $variable-name);
        my Str $val = private-name(@names, $value-name);

        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            unpivot-sql($sql, @uncols, @idx, $var, $val, :$keep-nulls), |$params.List
        ));
    }

    #| 长转宽（语义见 `Frame.pivot`）。分组值要先查一遍数据，因此这里和 eager
    #| 一样会在建算子时跑一次 DISTINCT；计划树本身退化成 Source 节点。
    method pivot(
        Str:D :$on!,
        :$index,
        :$values,
        Str :$agg = 'sum',
        Bool :$keep-nulls = False,
        --> Duckula::LazyFrame
    ) {
        my @names = self.names;
        my @idx = $index.defined ?? flatten-args(($index,)) !! ();
        my @vls = $values.defined ?? flatten-args(($values,)) !! ();
        need-cols(($on,), @names, 'pivot');
        need-cols(@idx, @names, 'pivot');

        my @vals = @vls.elems
            ?? @vls
            !! @names.grep({ $_ ne $on && !@idx.Set{$_} }).List;
        need-cols(@vals, @names, 'pivot');
        die Duckula::X::Frame.new(reason => 'pivot: nothing left to aggregate')
            unless @vals.elems;

        my Str $a = check-agg($agg);
        my ($sql, $params) = self!compiled;
        my @keys = pivot-keys($!session.conn, $sql, $on,
                              $params.List, :$keep-nulls);

        self!derive(plan-source(
            pivot-sql($sql, $on, @idx, @vals, @keys, $a, :$keep-nulls),
            |$params.List,
        ));
    }

    #| 频率交叉表（语义见 `Frame.crosstab`）。退成 Source，因为要先 DISTINCT 取值。
    method crosstab(
        :$index!,
        :$columns!,
        :$values,
        Str :$agg = 'count',
        :$normalize = '',
        :$fill-value,
        Bool :$keep-nulls = False,
        --> Duckula::LazyFrame
    ) {
        my @names = self.names;
        need-cols(($index,), @names, 'crosstab');
        need-cols(($columns,), @names, 'crosstab');
        need-cols(($values,), @names, 'crosstab') if $values.defined;

        my Str $how = $normalize ~~ Bool:D
            ?? ($normalize ?? 'all' !! '')
            !! ($normalize // '').Str;
        my ($sql, $params) = self!compiled;
        my @keys = pivot-keys($!session.conn, $sql, $columns.Str,
                              $params.List, :$keep-nulls);
        self!derive(plan-source(crosstab-sql(
            $sql, $index.Str, $columns.Str, @keys,
            :normalize($how), :$fill-value, :$values, :$agg,
        ), |$params.List));
    }

    #| 聚合透视表（语义见 `Frame.pivot-table`）。
    method pivot-table(
        :$index!,
        :$columns!,
        :$values,
        Str :$agg = 'mean',
        Bool :$margins = False,
        :$fill-value,
        Bool :$keep-nulls = False,
        --> Duckula::LazyFrame
    ) {
        my @names = self.names;
        my @idx = flatten-args(($index,));
        my @cols = flatten-args(($columns,));
        die Duckula::X::Frame.new(reason => 'pivot-table: columns must be a single column')
            unless @cols.elems == 1;
        need-cols(@idx, @names, 'pivot-table');
        need-cols(@cols, @names, 'pivot-table');

        my @vals = $values.defined
            ?? flatten-args(($values,))
            !! @names.grep({ $_ ∉ @idx.Set && $_ ∉ @cols.Set }).List;
        need-cols(@vals, @names, 'pivot-table');
        die Duckula::X::Frame.new(reason => 'pivot-table: nothing left to aggregate')
            unless @vals.elems;

        # pandas 的默认 aggfunc 叫 'mean'，DuckDB 的聚合函数叫 'avg'。
        my Str $a = check-agg($agg.trim.lc eq 'mean' ?? 'avg' !! $agg);
        my ($sql, $params) = self!compiled;
        my @keys = pivot-keys($!session.conn, $sql, @cols[0],
                              $params.List, :$keep-nulls);
        self!derive(plan-source(pivot-table-sql(
            $sql, @idx, @cols[0], @keys, @vals, $a,
            :$margins, :$fill-value,
        ), |$params.List));
    }

    #| 采样（语义见 `Frame.sample`）。USING SAMPLE 属于 FROM 子句，退成 Source。
    method sample(Int :$n, :$frac, Int :$seed --> Duckula::LazyFrame) {
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            sample-sql($sql, :$n, :$frac, :$seed), |$params.List
        ));
    }

    # ------------------------------------------------------------ 统计（v0.25.0）
    # 统计矩阵 / top-n 都是「整表重排 + 聚合」，不进 Plan 树，包成 Source；
    # :index-cols 让 collect() 把矩阵的行标签声明贴回 Frame（见 §8.20）。

    method corr(Str:D :$method = 'pearson', :$columns --> Duckula::LazyFrame) {
        self!stats-source(:fn<corr>, :$method, :$columns);
    }
    method cov(Int:D :$ddof = 1, :$columns --> Duckula::LazyFrame) {
        self!stats-source(:fn(cov-fn(:$ddof)), :$columns);
    }

    method !stats-source(Str:D :$fn!, Str:D :$method = 'pearson',
                         :$columns! --> Duckula::LazyFrame) {
        my @cols = norm-stat-cols($columns, self.names, $fn);
        my Set $taken = self.names.Set;
        my Str $label = 'index';
        $label ~= '_' while $label ∈ $taken;
        my ($sql, $params) = self!compiled;
        my Str $out = stats-matrix-sql($sql, @cols,
                                        :$fn, :$method, :$label);
        self!derive(plan-source($out, |$params.List),
                    index-cols => ($label,).List);
    }

    method skew(:$columns --> Duckula::LazyFrame) {
        my @cols = norm-stat-cols($columns, self.names, 'skew');
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(row-stats-sql($sql, @cols, 'skewness'),
                                |$params.List));
    }
    method kurt(:$columns --> Duckula::LazyFrame) {
        my @cols = norm-stat-cols($columns, self.names, 'kurt');
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(row-stats-sql($sql, @cols, 'kurtosis'),
                                |$params.List));
    }

    method nlargest(Int:D $n, $columns = Nil,
                    Str:D :$keep = 'first' --> Duckula::LazyFrame) {
        my @by = $columns.defined
            ?? norm-stat-cols($columns, self.names, 'nlargest')
            !! self.names;
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            top-n-sql($sql, @by, $n, desc => True, :$keep, known => self.names),
            |$params.List,
        ));
    }
    method nsmallest(Int:D $n, $columns = Nil,
                     Str:D :$keep = 'first' --> Duckula::LazyFrame) {
        my @by = $columns.defined
            ?? norm-stat-cols($columns, self.names, 'nsmallest')
            !! self.names;
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(
            top-n-sql($sql, @by, $n, desc => False, :$keep, known => self.names),
            |$params.List,
        ));
    }

    #| 每列一行的概览（语义见 `Frame.describe`）。SUMMARIZE 退成 Source。
    method describe(--> Duckula::LazyFrame) {
        my ($sql, $params) = self!compiled;
        self!derive(plan-source(describe-sql($sql), |$params.List));
    }

    #| 连接。右侧可以是 `LazyFrame`，也可以是 `Frame`（自动包成 Source 节点）。
    method join($right, :$on, Str :$how = 'inner', Str :$suffix = '_right'
                --> Duckula::LazyFrame) {
        my $rp = $right ~~ Duckula::LazyFrame
            ?? $right.plan
            !! plan-source($right.relation-sql);

        my %spec = join-layout(
            self.names.List, $right.names.List, :$on, :$how, :$suffix
        );

        self!derive(Duckula::Plan::Join.new(
            left       => $!plan,
            right      => $rp,
            mode       => %spec<mode>,
            join-sql   => %spec<join-sql>,
            exists-sql => %spec<exists-sql>,
            on-sql     => %spec<on-sql>,
            items      => %spec<items>.List,
        ));
    }

    #| 近似连接，语义见 Frame.merge-asof。右侧的占位符先固化为字面量，
    #| 左侧参数留到 collect 再绑定；所以这一步仍算半个计划边界。
    method merge-asof(
        $right,
        :$on!, :$by, Str :$direction = 'backward', Str :$how = 'left',
        :$tolerance, Str :$suffix = '_right',
        --> Duckula::LazyFrame
    ) {
        my ($lsql, $lparams) = self!compiled;
        my Str $rsql;
        if $right ~~ Duckula::LazyFrame {
            my ($s, $p) = $right!compiled;
            $rsql = $p.elems ?? render-bindings($s, $p.List) !! $s;
        } else {
            $rsql = $right.relation-sql;
        }
        my Str $lk = $on ~~ Pair ?? $on.key.Str
                   !! ($on ~~ Positional ?? $on[0].Str !! $on.Str);
        my %spec = asof-layout(
            self.names, $right.names,
            :$on, :$by, :$direction, :$how, :$tolerance, :$suffix,
            :key-dtype(self.schema{$lk}),
        );
        self!derive(plan-source(
            asof-sql($lsql, $rsql, %spec), |$lparams.List,
        ));
    }

    #| pandas 的 `pipe`：闭包拿当前 LazyFrame 作第一个参数。
    method pipe(&fn, *@args, *%kw) { &fn(self, |@args, |%kw) }

    #| 语义见 Frame.combine-first；右侧参数同样固化。
    method combine-first($right --> Duckula::LazyFrame) {
        my @ka = self.index-cols.List;
        my @kb = $right.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'combine-first needs matching index keys on both frames'
        ) unless @ka.elems && @ka eqv @kb;
        my ($lsql, $lparams) = self!compiled;
        my Str $rsql;
        if $right ~~ Duckula::LazyFrame {
            my ($s, $p) = $right!compiled;
            $rsql = $p.elems ?? render-bindings($s, $p.List) !! $s;
        } else {
            $rsql = $right.relation-sql;
        }
        self!derive(plan-source(
            combine-first-sql($lsql, $rsql, @ka, self.names, $right.names),
            |$lparams.List,
        ));
    }

    #| 检查 key 是否唯一；惰性路径要渲染 SQL 才能查，但不搬数据。
    method verify_integrity(--> Bool) {
        my @keys = self.index-cols.List;
        die Duckula::X::Frame.new(
            reason => 'verify_integrity needs a key; call set-index first'
        ) unless @keys.elems;
        my ($sql, $params) = self!compiled;
        my Str $q = 'SELECT ' ~ @keys.map({ quote-ident($_) }).join(', ')
                  ~ ' FROM (' ~ $sql ~ ') AS __duckula_vi '
                  ~ 'GROUP BY ' ~ @keys.map({ quote-ident($_) }).join(', ')
                  ~ ' HAVING count(*) > 1 LIMIT 1';
        my $res = $params.elems
            ?? $!session.conn.query($q, |$params.List)
            !! $!session.conn.query($q);
        die Duckula::X::Frame.new(
            reason => 'index labels are not unique'
        ) if $res.arrays.List.elems;
        True;
    }

    #| 在计划中插一段 SQL，`self` 指代当前计划的结果。
    #|
    #| **这是计划树的边界**：`self` 要绑成临时视图，而建视图必须立刻执行
    #| `CREATE VIEW`，没法推迟到 collect —— 所以这里会把上游先渲染成 SQL、
    #| 建好视图，再把用户 SQL 包成一个 Source 节点继续往下攒。
    method sql(Str:D $sql, *@args, Bool :$unsafe = False, *%extra --> Duckula::LazyFrame) {
        reject-named(%extra, 'sql');
        my ($body, $params) = self!compiled;

        # 视图里不能留占位符，参数先固化（`render-bindings` 会正确转义）。
        my Str $body-sql = $params.elems ?? render-bindings($body, $params) !! $body;

        my Str $text = $sql.trim.subst(/ ';' $ /, '').trim;
        my Str $view = $!session.bind-view($body-sql);
        my Str $bound = replace-bare-ident($text, 'self', $view);

        # 校验失败时把刚建的视图拆掉：留着的话，每次被拒的 `.sql` 都会
        # 泄漏一个临时视图（而且它会一直被 drop-views 当成"有人在用"）。
        {
            check-sql($bound, :params(@args.elems), :strict(!$unsafe && $!session.strict),
                      :conn($!session.conn));
            CATCH {
                default {
                    $!session.discard-view($view);
                    .rethrow;
                }
            }
        }

        # 引用挂在计划树的 Source 节点上：派生 LazyFrame 共享同一份计划，
        # 只要还有任何一个活着，视图就不会被 drop-views 删掉。
        self!derive(plan-source($bound, |@args, :view-holder($!session.view-ref($view))));
    }
}
