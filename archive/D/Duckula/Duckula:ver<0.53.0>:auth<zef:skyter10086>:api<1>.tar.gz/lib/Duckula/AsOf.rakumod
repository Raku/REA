use v6.d;
use Duckula::SQL;
use Duckula::Dtype;
use Duckula::X::Frame;

#| merge_asof 的 SQL 构件（v0.31.0）。对标 pandas `merge_asof`：
#| 按一个有序键找「最近的前一行」（backward，默认）、后一行（forward）
#| 或两边较近的一行（nearest），可选 `by` 分组键与 tolerance 上限。
#|
#| backward / forward 直接走 DuckDB 原生 `ASOF [LEFT] JOIN`，不变慢；
#| nearest 用 LEFT JOIN + `row_number()` 取距离最小的一行，代价更高但语义正确
#| （DuckDB 的 ASOF 没有 nearest 模式）。所有键列名走 quote-ident，
#| tolerance 走 sql-literal 或固定格式的 INTERVAL 字面量，不接裸用户输入。

my constant %DIRECTION = set <backward forward nearest>;
my constant %HOW = set <left inner>;

#| 归一化 `on` / `by`：'k' 表示同名键，Pair 表示异名键。
my sub normalize-asof-keys($spec, @lnames, @rnames, Str:D $what --> List) {
    my @raw = $spec ~~ Positional ?? $spec.List !! ($spec,);
    my Set $ls = @lnames.Set;
    my Set $rs = @rnames.Set;
    my @out;
    my %seen;
    for @raw -> $item {
        my Str $l = $item ~~ Pair ?? $item.key.Str !! $item.Str;
        my Str $r = $item ~~ Pair ?? $item.value.Str !! $l;
        die Duckula::X::Frame.new(
            reason => "$what key '$l' is not a column of the left frame"
        ) unless $ls{$l};
        die Duckula::X::Frame.new(
            reason => "$what key '$r' is not a column of the right frame"
        ) unless $rs{$r};
        die Duckula::X::Frame.new(
            reason => "$what key '$l' appears more than once"
        ) if %seen{$l}++;
        @out.push: [$l, $r];
    }
    @out.List;
}

#| tolerance 的字面量。时间类型换算成毫秒（与 `epoch_ms` 差值同单位），
#| 数值直接走 sql-literal。
#|
#| 早先时间类型写成 `INTERVAL n seconds`，而 `abs(ts_l - ts_r)` 在 DuckDB 里
#| 得到的是 INTERVAL —— `abs(INTERVAL)` 不存在，nearest/tolerance 直接挂。
our sub asof-tolerance-sql($tolerance, $dtype --> Str) is export {
    die Duckula::X::Frame.new(
        reason => 'merge_asof tolerance must be a non-negative number'
    ) unless $tolerance ~~ Numeric && $tolerance >= 0;

    my Str $t = $dtype.defined ?? $dtype.sql-type.uc !! '';
    # DATE - DATE 在 DuckDB 里是「天数的整数」，不能跟 INTERVAL 比。
    ($t.starts-with('TIMESTAMP') || $t eq 'TIMESTAMPTZ')
        ?? sql-literal($tolerance * 1000)
        !! sql-literal($tolerance);
}

#| 检查参数并生成投影项 / 连接条件。不碰 Frame 类型，eager / lazy 共用。
our sub asof-layout(
    @lnames, @rnames,
    :$on!,
    :$by = Nil,
    Str :$direction = 'backward',
    Str :$how = 'left',
    :$tolerance = Nil,
    Str :$suffix = '_right',
    :$key-dtype = Nil,
    --> Hash
) is export {
    my Str $dir = $direction.trim.lc;
    my Str $kind = $how.trim.lc;
    die Duckula::X::Frame.new(
        reason => "unknown merge_asof direction '$direction'; expected: "
                ~ %DIRECTION.keys.sort.join(', ')
    ) unless %DIRECTION{$dir};
    die Duckula::X::Frame.new(
        reason => "unknown merge_asof how '$how'; expected: left, inner"
    ) unless %HOW{$kind};

    my @pairs = normalize-asof-keys($on, @lnames, @rnames, 'on');
    die Duckula::X::Frame.new(reason => 'merge_asof needs exactly one on key')
        unless @pairs.elems == 1;
    my Str $lk = @pairs[0][0];
    my Str $rk = @pairs[0][1];

    my @by = $by.defined ?? normalize-asof-keys($by, @lnames, @rnames, 'by').List !! ();
    my Set $right-skip = set($rk, |@by.map({ .[1] }));

    my %taken;
    my @items;
    for @lnames -> $n {
        %taken{$n} = True;
        @items.push: 'l.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($n);
    }
    for @rnames -> $n {
        next if $right-skip{$n};
        my Str $out = $n;
        $out ~= $suffix while %taken{$out};
        %taken{$out} = True;
        @items.push: 'r.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($out);
    }

    my Str $by-sql = @by.map({
        'l.' ~ quote-ident($_[0]) ~ ' = r.' ~ quote-ident($_[1])
    }).join(' AND ');
    # 时间键的「距离」用毫秒整数：TIMESTAMP - TIMESTAMP 是 INTERVAL，
    # 而 `abs(INTERVAL)` 在 DuckDB 里没有实现（nearest/tolerance 会挂）。
    my Str $t = $key-dtype.defined ?? $key-dtype.sql-type.uc !! '';
    my Bool $is-time = $t.starts-with('TIMESTAMP') || $t eq 'TIMESTAMPTZ';
    my Str $diff = $is-time
        ?? 'abs(epoch_ms(l.' ~ quote-ident($lk) ~ ') - epoch_ms(r.' ~ quote-ident($rk) ~ '))'
        !! 'abs(l.' ~ quote-ident($lk) ~ ' - r.' ~ quote-ident($rk) ~ ')';
    my Str $tol-sql = $tolerance.defined
        ?? asof-tolerance-sql($tolerance, $key-dtype)
        !! '';

    # nearest 没有原生 ASOF 模式：先按 `by` 做（可能是多对多的）连接，
    # 再按距离取每组第一行；tolerance 在连接条件里先挡掉太远的行。
    if $dir eq 'nearest' {
        my @join = @by.map({
            'l.' ~ quote-ident($_[0]) ~ ' = r.' ~ quote-ident($_[1])
        });
        @join.push: $diff ~ ' <= ' ~ $tol-sql if $tol-sql.chars;
        my Str $on-sql = @join.elems ?? @join.join(' AND ') !! 'TRUE';
        return %(
            mode     => 'nearest',
            direction => $dir,
            how      => $kind,
            items    => @items.List,
        on-left-key => $lk,
        order-by => (|$lk, |@by.map({ $_[0] })).List,
        on-sql   => $on-sql,
            diff-sql => $diff,
            tolerance-sql => $tol-sql,
            by-sql   => $by-sql,
        );
    }

    my Str $op = $dir eq 'forward' ?? '<=' !! '>=';
    my @cond;
    @cond.push($by-sql) if $by-sql.chars;
    @cond.push('l.' ~ quote-ident($lk) ~ ' ' ~ $op ~ ' r.' ~ quote-ident($rk));
    @cond.push($diff ~ ' <= ' ~ $tol-sql) if $tol-sql.chars;

    %(
        mode      => 'asof',
        direction => $dir,
        how       => $kind,
        items     => @items.List,
        on-left-key => $lk,
        order-by => (|$lk, |@by.map({ $_[0] })).List,
        on-sql    => @cond.join(' AND '),
        diff-sql  => $diff,
        tolerance-sql => $tol-sql,
        by-sql    => $by-sql,
    );
}

#| 生成整条 SQL。`$lsql` / `$rsql` 里可以留 `?`，由调用方按顺序绑定。
our sub asof-sql(
    Str:D $lsql, Str:D $rsql, Hash:D $spec --> Str
) is export {
    my Str $items = $spec<items>.List.join(', ');

    if $spec<mode> eq 'nearest' {
        # 给左表钉一个行号，QUALIFY 分区用它，避免相同 key 的多行被合并。
        my Str $left = '(SELECT *, row_number() OVER () AS '
                     ~ quote-ident('__duckula_asof_rn')
                     ~ ' FROM (' ~ $lsql ~ ')) AS l';
        my Str $join = $spec<how> eq 'left' ?? 'LEFT JOIN' !! 'JOIN';
        return 'SELECT ' ~ $items ~ ' FROM ' ~ $left ~ ' ' ~ $join
             ~ ' (' ~ $rsql ~ ') AS r ON ' ~ $spec<on-sql>
             ~ ' QUALIFY row_number() OVER (PARTITION BY l.'
             ~ quote-ident('__duckula_asof_rn')
             ~ ' ORDER BY ' ~ $spec<diff-sql> ~ ') = 1'
             ~ ' ORDER BY ' ~ $spec<order-by>.List.map({
                   'l.' ~ quote-ident($_.Str)
               }).join(', ');
    }

    my Str $join = ($spec<how> eq 'left' ?? 'ASOF LEFT JOIN' !! 'ASOF JOIN');
    # ASOF JOIN 不保证保持左表行序；pandas merge_asof 的结果按 on 键排序。
    'SELECT ' ~ $items ~ ' FROM (' ~ $lsql ~ ') AS l ' ~ $join
        ~ ' (' ~ $rsql ~ ') AS r ON ' ~ $spec<on-sql>
        ~ ' ORDER BY ' ~ $spec<order-by>.List.map({
              'l.' ~ quote-ident($_.Str)
          }).join(', ');
}
