use v6.d;
use DB::DuckDB;
use Duckula::SQL;
use Duckula::Guard;
use Duckula::Frame;
use Duckula::LazyFrame;
use Duckula::Plan;
use Duckula::Clean;
use Duckula::Write;
use Duckula::ArrowRead;
use Duckula::IO;
use Duckula::ExcelRead;
use Duckula::SqlDb;
use Duckula::X::Frame;

#| 对一张临时视图的「活引用」。
#|
#| 放进 `Plan::Source`：一份计划树可能被多个派生 LazyFrame 共享，持有者只要
#| 还有任何一个活着，视图引用计数就不为零；全部释放后 DESTROY 自动减回去。
#| 这样 `drop-views` 既不会误删活 LazyFrame 依赖的视图，也不需要 Session
#| 反向强引用 LazyFrame（那会导致永不回收）。
class Duckula::ViewRef is export {
    has $.session is required;
    has Str $.name is required;
    has Bool $!released = False;

    submethod BUILD(:$!session!, Str :$!name!) {
        $!session.retain-views([$!name]);
    }

    method release(--> Nil) {
        return if $!released;
        $!released = True;
        $!session.release-views([$!name]);
    }

    submethod DESTROY { self.release }
}

#| 一次数据分析会话：一个 DuckDB 连接 + 小写入口 `$session.sql(...)`。
#|
#| 职责很小，只做四件事：
#|   1. 管连接（可选复用外部传入的，或自己开一个）；
#|   2. 把整条 SQL 送过 Duckula::Guard 三道闸，再交给 DuckDB；
#|   3. 为 `Frame.sql` 的 `self` 占位符分配临时视图名；
#|   4. 把结果包成 Duckula::Frame（SQL 为真相，数据惰性）。
#|
#| 不做：解析 SQL、优化查询、计算。那些都是 DuckDB 的活。
class Duckula::Session {
    has $!conn;
    has Bool $!owns-conn = False;
    has Bool $!sandboxed = False;
    has Bool $!strict = True;
    has @!views;

    #| close 之后置真。所有入口经 `conn` 取值，关闭后一律明确报错，
    #| 避免驱动懒重开空库造成的"数据好像丢了"。
    has Bool $!closed = False;

    #| 临时视图的「谁还在用」登记：视图名 => 引用计数。
    #|
    #| **不要**在这里存 Frame 对象。以前是 `@!frames` 强引用活 Frame，而
    #| Frame 又持有 session 与 Result —— 从活的 Session 出发永远可达，Frame
    #| 与它的物化数据就永远不回收，`drop-views` 也会因为历史 Frame 一直"在
    #| 用"而失效。现在只记视图名的计数，Frame / LazyFrame 在 DESTROY 里
    #| 减回去；没有视图引用的对象根本不登记（所以建 Frame 是 O(1)）。
    has %!view-refs;

    #| :$conn    复用已有连接（DB::DuckDB 实例）；不传则自己开一个
    #| :$sandbox 立刻切断外部文件/网络访问（见 §9.5.5）
    #| :$strict  False 表示默认放行写操作（等于每条 SQL 都 :unsafe）
    submethod BUILD(:$conn, Bool :$sandbox = False, Bool :$strict = True) {
        $!owns-conn = !$conn.defined;
        $!conn = $conn // DB::DuckDB.new;
        $!strict = $strict;
        if $sandbox {
            # `enable_external_access=false` 在 DuckDB 运行期不可逆，而借用
            # 连接的真正主人是调用方 —— 对他人的连接做这种永久降权太霸道。
            # 沙箱只接受自有连接，想隔离就 `Session.new(:sandbox)`。
            die Duckula::X::Frame.new(
                reason => 'a sandboxed session must own its connection: '
                        ~ '`enable_external_access=false` cannot be undone while '
                        ~ 'the database is running. Use Duckula::Session.new(:sandbox) '
                        ~ 'instead of passing :conn.'
            ) unless $!owns-conn;
            apply-sandbox($!conn);
            $!sandboxed = True;
        }
    }

    method conn(--> DB::DuckDB) {
        die Duckula::X::Frame.new(
            reason => 'this Duckula::Session has been closed; '
                    ~ 'create a new session instead of reusing a closed one'
        ) if $!closed;
        $!conn;
    }

    #| 让 DuckDB 的解析器看一眼这条 SQL 是什么。自查用，不执行、不校验。
    #|
    #|   $s.classify("SELECT 1");              # ('SELECT',)
    #|   $s.classify("SELECT 1; COPY ...");    # ('SELECT', 'COPY')
    #|
    #| 与 `check-sql` 的关系：那个是守门（不安全就 die），这个是照镜子
    #| （把结论给你看）。想知道「为什么被拒」时用它。
    method classify(Str:D $sql --> List) {
        self.conn.classify-sql($sql).map(*.type).List;
    }


    method sandboxed(--> Bool) { $!sandboxed }

    #| 严格模式（默认开）：只放行只读语句。`LazyFrame.sql` 要照着这里的开关
    #| 决定要不要让用户 `:unsafe` 才行。
    method strict(--> Bool) { $!strict }

    #| 把一段 SQL 绑成临时视图，返回视图名（登记进 `drop-views` 名单）。
    #|
    #| 给 `LazyFrame.sql` 用：惰性路径没法推迟 `CREATE VIEW`，只能在校验通过
    #| 后立刻建好视图，再把用户 SQL 包成计划节点。
    method bind-view(Str:D $sql --> Str) {
        my Str $view = self!view-name;
        self.conn.execute("CREATE OR REPLACE TEMP VIEW $view AS $sql");
        @!views.push: $view;
        $view;
    }

    #| 临时视图的单调命名，避免与用户表撞名。
    #|
    #| 用**进程级** `state` 而不是会话级计数器：`Session.new(:conn($c))` 允许
    #| 多个会话共用一条连接，而临时视图是连接级的 —— 会话级计数会让两个会话
    #| 都建出 `__duckula_view_1`，后者的 CREATE OR REPLACE 直接覆盖前者的
    #| 视图，派生 Frame 之后就会读到另一个会话的数据（静默串数据）。
    method !view-name(--> Str) {
        state $seq = 0;
        '__duckula_view_' ~ (++$seq);
    }

    method !clean(Str:D $sql --> Str) {
        $sql.trim.subst(/ ';' $ /, '').trim;
    }

    #| 执行一条独立的 SQL（没有 `self` 上下文）。
    #|
    #|   duckula.sql("select * from read_csv_auto('o.csv')");
    #|   duckula.sql('select * from t where city = ?', $city);
    #|
    #| 值走参数绑定，不经过 SQL 文本；`?` 的个数必须与实参一致，否则当场 die。
    method sql(Str:D $sql, *@args, Bool :$unsafe = False, *%extra --> Duckula::Frame) {
        reject-named(%extra, 'sql');
        my Str $text = self!clean($sql);
        check-sql($text, :params(@args.elems), :strict(!$unsafe && $!strict), :conn(self.conn));

        # 先把参数渲染进 relation-sql，再执行。反过来的话（先 query 后
        # render-bindings）渲染失败时写操作已经提交，调用方却收到异常，
        # 一重试就是重复写入。
        my Str $relation = @args.elems ?? render-bindings($text, @args) !! $text;
        my $res = self.conn.query($text, |@args);

        Duckula::Frame.new(session => self, relation-sql => $relation, result => $res);
    }

    #| 读 CSV/TSV。列名与类型交给 DuckDB 自动推断（sniffing）。
    #|
    #| 路径作为**绑定参数**传入，不拼进 SQL 文本 —— 文件名里带单引号也安全
    #| （已实测 `tmp-o'rders.csv`）。
    method read-csv(Str:D $path --> Duckula::Frame) {
        self.sql('SELECT * FROM read_csv_auto(?)', $path);
    }

    #| 读 Parquet。
    method read-parquet(Str:D $path --> Duckula::Frame) {
        self.sql('SELECT * FROM read_parquet(?)', $path);
    }

    # ============================================================
    # SQL 数据库读写（v0.29.0，对标 pandas read_sql / to_sql）
    # ============================================================

    #| 执行一段 SQL 读成 Frame，和 `sql` 的区别是它明确服务于「外部库」：
    #| 给了 `:$db` 就先 `ATTACH` 成 `:$alias`，SQL 里用 `<alias>.<table>` 限定名。
    #| 不给 `:$db` 时等价于 `sql`（读当前连接能看见的表）。
    #|
    #|   $s.read-sql('SELECT * FROM ext.orders WHERE amount > ?', 5,
    #|               :db<warehouse.duckdb>, :alias<ext>);
    #|
    #| SQL 照旧过 Guard 的只读判定；路径走 sql-literal、别名走 quote-ident。
    method read-sql(
        Str:D $sql,
        *@args,
        Str :$db,
        Str :$alias = 'duckula_ext',
        Bool:D :$read-only = True,
        Bool :$unsafe = False,
        --> Duckula::Frame
    ) {
        Duckula::SqlDb::attach-db(self, $db, $alias, :$read-only) if $db.defined;
        self.sql($sql, |@args, :$unsafe);
    }

    #| 读外部库的一张表，省去自己写 `<alias>.<table>`。
    method read-sql-table(
        Str:D $table,
        Str :$db!,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Bool:D :$read-only = True,
        --> Duckula::Frame
    ) {
        Duckula::SqlDb::attach-db(self, $db, $alias, :$read-only);
        self.sql(
            Duckula::SqlDb::read-sql-table-sql($table, :$alias, :$schema)
        );
    }

    #| 惰性读外部库的一张表。ATTACH 是连接级副作用，建计划前先做掉。
    method scan-sql-table(
        Str:D $table,
        Str :$db!,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Bool:D :$read-only = True,
        --> Duckula::LazyFrame
    ) {
        Duckula::SqlDb::attach-db(self, $db, $alias, :$read-only);
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source(
                Duckula::SqlDb::read-sql-table-sql($table, :$alias, :$schema)
            ),
        );
    }

    #| 挂一个外部 DuckDB 库，返回可用的限定名前缀（已 quote 的别名）。
    method attach-db(
        Str:D $path,
        Str:D $alias = 'duckula_ext',
        Bool:D :$read-only = False,
        --> Str
    ) {
        Duckula::SqlDb::attach-db(self, $path, $alias, :$read-only);
    }

    #| 拆掉一个已挂的外部库。
    method detach-db(Str:D $alias --> Nil) {
        Duckula::SqlDb::detach-db(self, $alias);
    }

    #| 当前连接挂着哪些库。
    method list-dbs(--> List) { Duckula::SqlDb::list-dbs(self) }

    #| 惰性读 CSV：只建计划节点，一行都不读。`collect` 时才真正扫文件。
    method scan-csv(Str:D $path --> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source('SELECT * FROM read_csv_auto(?)', $path),
        );
    }

    #| 惰性读 Parquet。
    method scan-parquet(Str:D $path --> Duckula::LazyFrame) {
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source('SELECT * FROM read_parquet(?)', $path),
        );
    }

    #| 读 JSON / NDJSON（`.json` / `.ndjson` / `.jsonl`）。
    #|
    #| DuckDB 自己嗅探是数组还是逐行对象；需要时可以钉死：
    #|   $s.read-json('x.json', :format<array>);
    #|   $s.read-json('x.ndjson', :format<newline_delimited>, :ignore-errors);
    #|
    #| 路径走绑定参数；`format` / `records` 走白名单，都不接受 SQL 片段。
    method read-json(
        Str:D $path,
        Str :$format,
        Str :$records,
        Int :$maximum-depth,
        Bool :$ignore-errors,
        --> Duckula::Frame
    ) {
        self.sql(
            Duckula::IO::json-source-sql(
                :$format, :$records, :$maximum-depth, :$ignore-errors
            ),
            $path
        );
    }

    #| 惰性读 JSON：计划里的路径仍然是绑定参数，collect 时才扫文件。
    method scan-json(
        Str:D $path,
        Str :$format,
        Str :$records,
        Int :$maximum-depth,
        Bool :$ignore-errors,
        --> Duckula::LazyFrame
    ) {
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source(
                Duckula::IO::json-source-sql(
                    :$format, :$records, :$maximum-depth, :$ignore-errors
                ),
                $path
            ),
        );
    }

    #| 读 Excel（`.xlsx`）。
    #|
    #|   my $df = $s.read-excel('book.xlsx');
    #|   my $df = $s.read-excel('book.xlsx', :sheet<Sheet2>, :!header);
    #|
    #| 两条路：DuckDB 装了 `excel` 扩展就直接用 `read_xlsx`（纯 SQL、惰性列
    #| 读取）；否则用 `Duckula::ExcelRead` 解 xlsx 到临时表（与 read-arrow
    #| 一样的急切路径）。Windows 的 mingw 构建没有官方 excel 扩展，走的
    #| 就是后者。支持 sharedStrings / inlineStr / 数字 / 布尔 / 公式结果；
    #| 日期按 Excel 序号读出，样式与合并单元格不解析。
    method read-excel(
        Str:D $path,
        Str :$sheet,
        Bool:D :$header = True,
        Bool:D :$all-varchar = False,
        --> Duckula::Frame
    ) {
        die Duckula::X::Frame.new(
            reason => 'read-excel needs file-system access, but this session is sandboxed'
        ) if $!sandboxed;

        # native 失败（例如某列首格为空、后续是字符串，read_xlsx 的类型推断
        # 报 `Could not convert string ... to DOUBLE`）时退回纯 Raku 解析：
        # 这条兜底路径本来就更宽松，不该让整次读取失败。
        if Duckula::IO::excel-available(self) {
            my $frame = try {
                self.sql(
                    Duckula::IO::excel-source-sql(:$sheet, :$header, :$all-varchar),
                    $path
                )
            };
            return $frame if $frame.defined;
        }
        Duckula::ExcelRead::read-excel(
            self, $path, :$sheet, :$header, :$all-varchar
        );
    }

    #| 惰性读 Excel。和 `read-arrow` 一样需要先把内容解到临时表，所以
    #| 建计划之前会做一次急切的读取；后续算子仍是惰性的。
    method scan-excel(
        Str:D $path,
        Str :$sheet,
        Bool:D :$header = True,
        Bool:D :$all-varchar = False,
        --> Duckula::LazyFrame
    ) {
        my $frame = self.read-excel($path, :$sheet, :$header, :$all-varchar);
        Duckula::LazyFrame.new(
            session => self,
            plan    => plan-source($frame.relation-sql),
        );
    }

    #| 只看 xlsx 骨架：所有 sheet 名 + 行列数，不建临时表。
    method describe-excel(Str:D $path --> Hash) {
        die Duckula::X::Frame.new(
            reason => 'describe-excel needs file-system access, but this session is sandboxed'
        ) if $!sandboxed;
        Duckula::ExcelRead::describe-xlsx($path);
    }

    #| 读 Arrow IPC 文件（`.arrow` / `.arrows`）。
    #|
    #|   my $df = $s.read-arrow('out.arrow');
    #|   my $df = $s.read-arrow('out.arrows');            # stream 格式
    #|   my $df = $s.read-arrow('out.arrow', :name<raw>); # 指定临时表名
    #|   my $df = $s.read-arrow('out.arrow', :native(False)); # 强制纯 Raku 解码
    #|
    #| 0.36 起默认交给 DuckDB 的 `nanoarrow` 扩展读（`read_arrow` 表函数 +
    #| 一条 CTAS），原因很直接：5 万行 × 3 列从 2.75 s 降到 8 ms，而且嵌套
    #| 列落成真正的 `STRUCT` / `MAP` / `T[]`，不再先渲染成文本再 cast。
    #|
    #| 兜底仍是纯 Raku 解码（`Arrow::IPC`）：扩展没装、或者设了
    #| `DUCKULA_ARROW_RAKU=1` 时走它，离线环境照常用。
    #|
    #| 两条路都是急切的 —— 表现在就建。连接一关，表跟着消失，Frame 不能
    #| 跨连接使用。
    method read-arrow(Str:D $path, Str :$name,
                      Bool :$native = True --> Duckula::Frame) {
        die Duckula::X::Frame.new(
            reason => 'read-arrow needs file-system access, but this session is sandboxed'
        ) if $!sandboxed;
        Duckula::ArrowRead::read-arrow(self, $path, :$name, :$native);
    }

    #| 纯 Raku 兜底解码器的命中/未命中/条目数。
    #|
    #| 只统计**兜底路径**：默认的 native 路径把字节交给 DuckDB，Raku 侧
    #| 没有解码可缓存，计数不会动。想观察缓存效果，用
    #| `DUCKULA_ARROW_RAKU=1`（或 `:native(False)`）读同一个文件两次。
    method arrow-cache-stats(--> Hash) {
        Duckula::ArrowRead::arrow-cache-stats();
    }

    #| 清空解码缓存并重置计数。想强制重读文件内容、或释放缓存内存时用。
    method clear-arrow-cache(--> Nil) {
        Duckula::ArrowRead::clear-arrow-cache();
    }

    #| 只看一个 IPC 文件的骨架，不读数据。
    #|
    #| 返回 `%(format, batches, rows, fields)`；`fields` 是每个字段的
    #| `name:format` 摘要，`dict-id` 非空说明那列是字典编码的。
    #|
    #|   $s.describe-arrow('out.arrow');
    #|   # {format => file, batches => 2, rows => 4096, fields => [...]}
    method describe-arrow(Str:D $path --> Hash) {
        die Duckula::X::Frame.new(
            reason => 'describe-arrow needs file-system access, but this session is sandboxed'
        ) if $!sandboxed;
        Duckula::ArrowRead::describe-ipc($path);
    }

    #| 执行一条**会改数据**的语句，返回受影响行数。
    #|
    #|   $s.execute('CREATE TABLE t (i BIGINT, s VARCHAR)');
    #|   $s.execute('DELETE FROM t WHERE i < ?', 3);
    #|
    #| 与 `sql` 的区别只有一条：不做只读校验（`sql` 在严格模式下会拒绝
    #| INSERT/UPDATE/CREATE）。单语句与占位符对齐这两道照旧检查 —— 写操作
    #| 一样不该被拼接注入。
    method execute(Str:D $sql, *@args, *%extra --> Int) {
        reject-named(%extra, 'execute');
        my Str $text = self!clean($sql);
        check-sql($text, :params(@args.elems), :strict(False));
        self.conn.execute($text, |@args).Int;
    }

    #| 把一批 Raku 行写进已有表，走 Appender（单事务，失败整批回滚）。
    #|
    #|   $s.insert('t', ((1, 'a'), (2, 'b')));
    #|
    #| 每行是与表列**按位置对齐**的序列；`Any` 写 NULL。表必须已经存在
    #| （用 `execute` 建，或者把结果集用 `Frame.to-table` 变成表）。
    method insert(Str:D $table, @rows, Str :$schema --> Int) {
        Duckula::Write::append-rows(self, $table, @rows, :$schema);
    }

    #| 从一个结果集建表，返回行数。
    #|
    #| `$source` 可以是 `Frame`、`LazyFrame` 或一段 SQL 字符串。惰性源会先
    #| `collect`，因为 `CREATE TABLE ... AS` 要一条没有占位符的语句。
    #| 与 `$df.to-table(...)` 等价，只是入口在会话上。
    method create-table(
        Str:D $name,
        $source,
        Bool:D :$replace = True,
        Bool:D :$temporary = False,
        --> Int
    ) {
        my Str $sql = do {
            if $source ~~ Str:D {
                my Str $clean = self!clean($source);
                # Str source 要过 Guard 单语句校验 —— callers 把外部字符串
                # （比如用户上传的 SQL 文件）传进来时不能绕过安全网关。
                # check-sql 的 strict 给 False：create-table 语义就是写，
                # 但单语句 + 参数绑定校验仍然有效。
                check-sql($clean, :params(0), :strict(False), :conn(self.conn));
                $clean;
            }
            elsif $source.can('collect') { $source.collect.relation-sql }
            elsif $source.can('relation-sql') { $source.relation-sql }
            else {
                die Duckula::X::Frame.new(
                    reason => 'create-table expects a Frame, a LazyFrame '
                            ~ 'or a SQL string, got ' ~ $source.^name
                );
            }
        };
        Duckula::Write::create-table(self, $sql, $name, :$replace, :$temporary);
    }

    #| 把一个结果集写进 SQL 库的表（对标 pandas `DataFrame.to_sql`）。
    #|
    #|   $s.to-sql('clean_orders', $frame);                 # 当前库
    #|   $s.to-sql('orders', $frame, :db<wh.duckdb>, :alias<ext>,
    #|             :if-exists<append>);
    #|
    #| `:$db` 给了就先 ATTACH 外部库；不给就写当前连接。外部库写入要求非
    #| 沙箱会话。`:if-exists` 三态：fail / replace（默认）/ append。
    method to-sql(
        Str:D $table,
        $source,
        Str :$db,
        Str :$alias = 'duckula_ext',
        Str :$schema,
        Str:D :$if-exists = 'replace',
        --> Int
    ) {
        my Str $sql = do {
            if $source ~~ Str:D {
                my Str $clean = self!clean($source);
                check-sql($clean, :params(0), :strict(False), :conn(self.conn));
                $clean;
            }
            elsif $source.can('collect') { $source.collect.relation-sql }
            elsif $source.can('relation-sql') { $source.relation-sql }
            else {
                die Duckula::X::Frame.new(
                    reason => 'to-sql expects a Frame, a LazyFrame or a SQL string, '
                            ~ 'got ' ~ $source.^name
                );
            }
        };

        if $db.defined {
            die Duckula::X::Frame.new(
                reason => 'to-sql to an external database needs file-system access, '
                        ~ 'but this session is sandboxed'
            ) if $!sandboxed;
            Duckula::SqlDb::attach-db(self, $db, $alias);
        }

        Duckula::SqlDb::write-sql-table(
            self, $sql, $table, :$if-exists,
            alias => ($db.defined ?? $alias !! Str),
            :$schema
        );
    }

    #| 在一个 Frame 的上下文里执行 SQL，`self` 指代该 Frame。
    #|
    #| `self` 绑成**临时视图**而不是 FROM 子查询，两个原因（§9.3）：
    #|   - 子查询必须带别名，`self.col` 会变成 `(select ...) AS __v.col`，语法错误；
    #|   - `self` 出现两次（自连接）时子查询会被重复计算。
    method sql-on-frame(
        Duckula::Frame $frame,
        Str:D $sql,
        *@args,
        Bool :$unsafe = False,
        --> Duckula::Frame
    ) {
        my Str $text = self!clean($sql);
        my Str $view = self!view-name;

        # 校验用的是「把 self 换成视图名」之后的 SQL，也就是真正要执行的
        # 那一条。所以视图得先建出来——否则 DuckDB 的解析器会说
        # `Table with name __duckula_view_1 does not exist`，校验永远过不了。
        # 建临时视图没有副作用（只是名字绑定），校验失败时再拆掉即可。
        self.conn.execute("CREATE OR REPLACE TEMP VIEW $view AS {$frame.relation-sql}");
        @!views.push: $view;

        my Str $bound = replace-bare-ident($text, 'self', $view);

        {
            check-sql($bound, :params(@args.elems), :strict(!$unsafe && $!strict),
                      :conn(self.conn));
            CATCH {
                default {
                    self.conn.execute("DROP VIEW IF EXISTS $view");
                    @!views.pop;
                    .rethrow;
                }
            }
        }

        # 同上：先渲染再执行，避免写操作已提交、渲染却抛异常。
        my Str $relation = @args.elems ?? render-bindings($bound, @args) !! $bound;
        my $res = self.conn.query($bound, |@args);

        Duckula::Frame.new(session => self, relation-sql => $relation, result => $res);
    }

    #| 丢掉本会话建过的全部临时视图。临时视图本是连接级的，连接一关就消失；
    #| 这个方法给长期存活的会话用，避免一连串 `Frame.sql` 攒出上百个视图。
    #|
    #| 默认安全：被活 Frame / LazyFrame 引用的视图会被跳过 —— 强行 DROP
    #| 会让它们悬空（后续 rows()/column()/collect 都报 Table does not exist）。
    #| 传 `:force` 无条件清空（**危险**，会让活对象悬空）。
    method drop-views(Bool :$force = False --> Nil) {
        my Set $protected = $force ?? Set.new() !! %!view-refs.keys.Set;
        for @!views -> $v {
            next if $v ∈ $protected;
            self.conn.execute("DROP VIEW IF EXISTS $v");
        }
        @!views = @!views.grep({ $_ ∈ $protected });
    }

    #| 登记/释放对临时视图的引用。`Frame` / `LazyFrame` 在 BUILD/DESTROY 里
    #| 成对调用；只有计数归零的视图才允许被 `drop-views` 删掉。
    method retain-views(@names --> Nil) {
        %!view-refs{$_}++ for @names;
    }

    method release-views(@names --> Nil) {
        for @names -> $n {
            next unless %!view-refs{$n}:exists;
            my Int $left = %!view-refs{$n} - 1;
            if $left > 0 { %!view-refs{$n} = $left }
            else { %!view-refs{$n}:delete }
        }
    }

    #| 某个临时视图当前被几个活对象引用（0 表示可以被 drop-views 删掉）。
    #| 诊断用：测试与排查泄漏时比"猜 GC 什么时候跑"可靠。
    method view-ref-count(Str:D $name --> Int) {
        %!view-refs{$name} // 0;
    }

    #| 建视图后、还没来得及交给持有者就被拒绝（`LazyFrame.sql` 的 Guard
    #| 校验失败）时用：立刻 DROP 并把名字从台账里摘掉，不留残余视图。
    method discard-view(Str:D $v --> Nil) {
        self.conn.execute("DROP VIEW IF EXISTS $v");
        @!views = @!views.grep({ $_ ne $v });
        %!view-refs{$v}:delete;
    }

    #| 造一个视图引用持有者（放进计划树，随计划对象一起销毁）。
    method view-ref(Str:D $name --> Duckula::ViewRef) {
        Duckula::ViewRef.new(session => self, name => $name);
    }

    #| 写文件的统一入口：沙箱会话一律拒绝。
    method require-file-access(Str:D $what --> Nil) {
        return unless $!sandboxed;
        die Duckula::X::Frame.new(
            reason => "$what needs file-system access, but this session is sandboxed; "
                    ~ 'create it with Duckula::Session.new(:!sandbox) to allow writes'
        );
    }

    #| 关闭会话。只关自己开的连接；外部传入的连接仍归调用方所有。
    #|
    #| 关闭后会话进入 `closed` 状态，任何再用它的操作都会明确报错。不设这个
    #| 状态的话，`DB::DuckDB` 会在下次取 `conn` 时**懒重开一个空内存库**，
    #| 于是 close 之后的查询要么静默成功、要么报 `Table ... does not exist`
    #| —— 看起来像数据丢了，实际是换了一个库。
    method close(--> Nil) {
        return if $!closed;
        self.drop-views;
        $!closed = True;
        @!views = ();
        %!view-refs = ();
        $!conn.close if $!owns-conn;
    }

    method closed(--> Bool) { $!closed }
}
