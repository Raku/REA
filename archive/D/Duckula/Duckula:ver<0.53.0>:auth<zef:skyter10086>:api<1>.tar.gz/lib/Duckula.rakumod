use v6.d;
use Duckula::Session;

#| Duckula -- pandas / Polars 风格的 DataFrame API，跑在 DuckDB 上。
#|
#| 命名：Duck + Dracula 的混成词，取自《Count Duckula》（怪鸭历险记）。
#|      一是指向 DuckDB，二是隐喻"同时兼容 pandas 与 Polars 两套 API 的缝合体"。
#|
#| 设计边界（详见 ARCHITECTURE.md）：
#|   - 不写 DuckDB FFI          -> 复用 DB::DuckDB::Native
#|   - 不写列式内存模型         -> 复用 DB::DuckDB::ColumnView
#|   - 不写计算引擎             -> 翻译成 SQL，交给 DuckDB 执行
#|
#| 三种入口（§9.2）：
#|   duckula.sql("select ...")         纯 SQL
#|   $frame.sql("... from self ...")   Frame 上跑，self 指当前 Frame
#|   $frame.filter(...)                pandas / Polars 风格 API
#|   $frame.group-by(...).agg(...)     分组聚合（v0.6.0）
#|   $frame.join($other, on => ...)    连接（v0.7.0）
#|   $frame.concat($other)             纵向拼接（v0.16.0，另有 unique / rename /
#|                                     drop / drop-nulls / fill-nulls / cast）
#|   $frame.pivot(...) / .unpivot(...) 长宽互转（v0.17.0，另有 explode / sample /
#|                                     describe）
#|   $s.read-arrow(...)               Arrow 文件导入（v0.18.0 起带解码缓存）
#|   $df{'col'}.sort / .unique / ...  单列 Series 变换（v0.19.0）
#|   $s.add(1) / .gt(15) / .median     单列运算与统计（v0.20.0）
#|   $df.with-row-index / .iloc(...)   显式行号列与位置取值（v0.21.0）
#|   $df.set-index(...) / .reindex(...) 声明式 key 与按 key 对齐（v0.22.0）
#|   $s.str.upper / .dt.year           pandas 风格访问器（v0.23.0）
#|   group-by.transform / .apply      分组广播与逐组函数（v0.24.0）
#|   $df.crosstab / .pivot-table      交叉表与聚合透视（v0.24.0）
#|   $s.corr($t) / $df.corr(...)      相关/协方差/分布统计（v0.25.0）
#|   $df.nlargest(5, 'col')           前后 n 行与 tie 策略（v0.25.0）
#|   $s.read-json / .scan-json        JSON / NDJSON 读入（v0.26.0）
#|   $s.read-excel / .scan-excel      XLSX 读入（v0.26.0）
#|   $s.read-parquet / .scan-parquet  Parquet 读入（v0.4.0 起）
#|   $df.dtypes / .info / .size       常用属性（v0.27.0）
#|   $df.where / .mask / .query       条件替换与 SQL 过滤（v0.27.0）
#|   $df.map / .apply  / $s.map       Raku 闭包逐元素映射（v0.27.0）
#|   $s.rolling(3).mean / .expanding 滚动与累积窗口（v0.27.0）
#|   $s.pct-change / .ewm(:span(3))  百分比变化与指数加权（v0.27.0）
#|   $df.resample('15min', :on<ts>)  时间重采样（v0.27.0）
#|   $df.to-json / .to-excel         JSON / XLSX 导出（v0.27.0）
#|   $df.index / .loc / .xs          Index 对象与 MultiIndex 算子（v0.28.0）
#|   $df.sort-index / .swaplevel    索引排序与层交换（v0.28.0）
#|   $s.read-sql / $df.to-sql       SQL 库读写，attach 外部 DuckDB（v0.29.0）
#|   $s.dt.tz-localize / .to-period 时区与 Period（v0.29.0）
#|   $df.schema / $s.dtype / $s.cat.codes nullable 类型与 Categorical（v0.30.0）
#|   $df.merge-asof / .combine-first / .pipe   近似连接与函数式长尾（v0.31.0）
#|   Arrow IPC 写/读在 rakupp 下的指针归一化（v0.31.1）
#|   Arrow IPC 编解码拆到独立 Arrow::IPC 包，Duckula 只留类型映射与灌表（v0.32.0）
#|   Expr helpers：sql-expr / case-when / least / greatest / coalesce /
#|                isin-subquery / lag-default（v0.33.0）
#|   read-excel 大文件走 Python duckdb 的 Excel→CSV 快路径，纯 Raku 仍兜底（v0.34.0）
#|   依赖 DB::DuckDB 1.2.2+ / Alien::Libduckdb 1.2.1+：原生 read_xlsx/COPY XLSX
#|   全程可用，Python 快路径降级为仅无扩展时的可选加速（v0.35.0）
#|   Arrow::IPC 0.1.1+：修 timestamptz 的 ipc-buf 非法 FlatBuffers（v0.35.1，issue IKXKJW）
unit module Duckula;

our $VERSION = '0.53.0';

my Duckula::Session $default;

#| 默认会话，首次调用时创建（一个进程一个连接）。
#| 需要隔离或多连接时，直接 `Duckula::Session.new`。
sub duckula(--> Duckula::Session) is export {
    $default //= Duckula::Session.new;
}
