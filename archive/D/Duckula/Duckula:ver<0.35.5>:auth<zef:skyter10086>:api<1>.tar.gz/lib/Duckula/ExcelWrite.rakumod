use v6.d;
use NativeCall;
use Duckula::X::Frame;

# zlib 的 crc32：CArray[int8] 指针 + 长度，返回 uLong。
# `is native` 需要编译期常量，用 BEGIN 在编译期挑一个可用的库名：
# Windows 优先找 zef 装的 Compress::Zlib::Raw 自带的 zlib1.dll，其次交给
# 动态链接器；Linux/macOS 用系统库名。找不到时给空串，运行时探测会退回纯 Raku。
my constant $ZLIB = BEGIN {
    if $*VM.config<dll> ~~ /dll/ {
        my @roots = ($*HOME.add('.zef/store'), $*HOME.add('.rakubrew'));
        my $found;
        for @roots -> $root {
            next unless $root.IO.e;
            my @dlls = $root.IO.dir(:recurse).grep({ .basename eq 'zlib1.dll' && $_.Str.contains('Compress-Zlib-Raw') });
            if @dlls { $found = @dlls[0].Str; last }
        }
        $found // 'zlib1';   # 让系统 PATH 再碰碰运气
    }
    elsif $*VM.config<dll> ~~ /dylib$/ { 'libz.dylib' }
    else { 'libz.so.1' }
};
sub zlib-crc32(int32, CArray[int8], int32 --> int32) is native($ZLIB) is symbol<crc32> { * }

#| 纯 Raku 的 XLSX 写出兜底（v0.27.0）。
#|
#| Windows 的 mingw 版 DuckDB 在官方扩展仓库里没有 `excel`，所以
#| `to-excel` 不能只靠 `COPY ... (FORMAT XLSX)`。这里生成一份最小的
#| OOXML 包：ZIP 用 method 0（stored，不压缩），因此不需要 zlib；CRC32
#| 自己算。字符串走 inlineStr，不写 sharedStrings，也不需要样式表。
#|
#| 产出的文件 openpyxl / Excel / DuckDB 的 read_xlsx 都能直接打开；
#| 不保留类型样式（日期按 Excel 序号或字符串写入，取决于源 SQL 的值）。
unit module Duckula::ExcelWrite;

my @CRC-TABLE = (^256).map(-> $i {
    my $c = $i;
    for ^8 {
        $c = ($c +& 1) ?? ((0xEDB88320 +^ ($c +> 1)) +& 0xFFFFFFFF) !! ($c +> 1);
    }
    $c +& 0xFFFFFFFF;
}).Array;

sub crc32-pure($buf --> Int) {
    my Int $c = 0xFFFFFFFF;
    for $buf.list -> $b {
        $c = @CRC-TABLE[($c +^ $b) +& 0xFF] +^ ($c +> 8);
        $c +&= 0xFFFFFFFF;
    }
    ($c +^ 0xFFFFFFFF) +& 0xFFFFFFFF;
}

# 纯 Raku 逐字节 CRC32 在 9MB 的 sheet XML 上要 35 秒——ZIP stored 模式下
# 这是导出的绝对瓶颈。zlib 的原生 crc32 只要 0.04 秒。用 nativecast 把
# Buf 直接当 CArray[int8] 指针传进去（零拷贝）；加载失败则退回纯 Raku。
my Bool $NATIVE-CRC = so try {
    my $probe = Buf.new(1, 2, 3);
    zlib-crc32(0, nativecast(CArray[int8], $probe), $probe.elems);
    True;
};

sub crc32($buf --> Int) {
    return crc32-pure($buf) unless $NATIVE-CRC;
    my Int $r = zlib-crc32(0, nativecast(CArray[int8], $buf), $buf.elems);
    $r +& 0xFFFFFFFF;
}

sub u16(Int:D $n --> Buf) {
    Buf.new($n +& 0xFF, ($n +> 8) +& 0xFF);
}

sub u32(Int:D $n --> Buf) {
    Buf.new($n +& 0xFF, ($n +> 8) +& 0xFF,
            ($n +> 16) +& 0xFF, ($n +> 24) +& 0xFF);
}

#| ZIP 的 DOS 时间固定成 1980-01-01 00:00:00，让输出字节可复现。
my constant $DOS-TIME = 0;
my constant $DOS-DATE = 0x0021;

sub xml-escape(Str:D $s --> Str) {
    $s.subst('&', '&amp;', :g)
      .subst('<', '&lt;', :g)
      .subst('>', '&gt;', :g)
      .subst('"', '&quot;', :g)
      .subst("'", '&apos;', :g);
}

sub col-letter(Int:D $i --> Str) {
    my Str $s = '';
    my Int $n = $i + 1;
    while $n > 0 {
        my Int $r = ($n - 1) % 26;
        $s = ('A'.ord + $r).chr ~ $s;
        $n = ($n - 1) div 26;
    }
    $s;
}

sub clean-sheet(Str:D $name --> Str) {
    my Str $s = $name.trim;
    die Duckula::X::Frame.new(
        reason => 'sheet name cannot be empty'
    ) unless $s.chars;
    die Duckula::X::Frame.new(
        reason => 'sheet name cannot contain []:*?/\\'
    ) if $s ~~ /<[\[ \] \: \* \? \/ \\]>/;
    $s.substr(0, 31);
}

sub cell-xml(Str:D $ref, $v --> Str) {
    return "<c r=\"$ref\"/>" unless $v.defined;
    # 注意用 {$v} 花括号插值：直接写 $v</v> 会被 Raku 解析成关联下标
    # $v{'/v'}，运行时报 "Str does not support associative indexing"。
    if $v ~~ Bool {
        return "<c r=\"$ref\" t=\"b\"><v>" ~ ($v ?? 1 !! 0) ~ "</v></c>";
    }
    if $v ~~ Int {
        return "<c r=\"$ref\"><v>{$v}</v></c>";
    }
    if $v ~~ Rat || $v ~~ Num {
        my Str $n = $v ~~ Rat ?? $v.Num.Str !! $v.Str;
        return "<c r=\"$ref\"><v>{$n}</v></c>";
    }
    my Str $text = xml-escape($v.Str);
    "<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{$text}</t></is></c>";
}

sub sheet-xml(@names, @rows --> Str) {
    my @lines = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
        '<sheetData>';

    my Str $head = '<row r="1">';
    for @names.kv -> $i, $n {
        $head ~= cell-xml(col-letter($i) ~ '1', $n.Str);
    }
    @lines.push: $head ~ '</row>';

    for @rows.kv -> $ri, $row {
        my Int $r = $ri + 2;
        my Str $line = "<row r=\"$r\">";
        for @names.kv -> $ci, $n {
            my $v = $row ~~ Positional    ?? $row[$ci]
                 !! $row ~~ Associative ?? $row.{$n}
                 !! $row;
            $line ~= cell-xml(col-letter($ci) ~ $r, $v);
        }
        @lines.push: $line ~ '</row>';
    }

    @lines.push: '</sheetData>', '</worksheet>';
    @lines.join("\n");
}

sub workbook-xml(Str:D $sheet --> Str) {
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      ~ '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
      ~ 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
      ~ '<sheets><sheet name="' ~ xml-escape($sheet)
      ~ '" sheetId="1" r:id="rId1"/></sheets></workbook>';
}

my constant $CONTENT-TYPES =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    ~ '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    ~ '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    ~ '<Default Extension="xml" ContentType="application/xml"/>'
    ~ '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
    ~ '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
    ~ '</Types>';

my constant $ROOT-RELS =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    ~ '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    ~ '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
    ~ '</Relationships>';

my constant $WORKBOOK-RELS =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    ~ '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    ~ '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
    ~ '</Relationships>';

sub local-header($name, Int:D $crc, Int:D $size --> Buf) {
    my Buf $h = Buf.new(0x50, 0x4b, 0x03, 0x04);
    $h.append(u16(20));            # version needed
    $h.append(u16(0));             # flags
    $h.append(u16(0));             # stored
    $h.append(u16($DOS-TIME));
    $h.append(u16($DOS-DATE));
    $h.append(u32($crc));
    $h.append(u32($size));
    $h.append(u32($size));
    $h.append(u16($name.elems));
    $h.append(u16(0));             # extra
    $h.append($name);
    $h;
}

sub central-header($name, Int:D $crc, Int:D $size, Int:D $offset --> Buf) {
    my Buf $h = Buf.new(0x50, 0x4b, 0x01, 0x02);
    $h.append(u16(20));            # version made by
    $h.append(u16(20));            # version needed
    $h.append(u16(0));
    $h.append(u16(0));
    $h.append(u16($DOS-TIME));
    $h.append(u16($DOS-DATE));
    $h.append(u32($crc));
    $h.append(u32($size));
    $h.append(u32($size));
    $h.append(u16($name.elems));
    $h.append(u16(0));             # extra
    $h.append(u16(0));             # comment
    $h.append(u16(0));             # disk
    $h.append(u16(0));             # internal attrs
    $h.append(u32(0));             # external attrs
    $h.append(u32($offset));
    $h.append($name);
    $h;
}

#| 把若干 (路径, 内容) 打成一个 stored ZIP。
sub zip-store(@files --> Buf) {
    my Buf $body .= new;
    my Buf $cd .= new;
    my Int $offset = 0;

    for @files -> $entry {
        # utf8 是 Buf[uint8] 的子类，但类型约束 `Buf` 不接受它；
        # 去掉约束，后面的 append/u16/u32 都按字节流处理。
        my $name = $entry[0].encode('utf8');
        my $data = $entry[1].encode('utf8');
        my Int $crc = crc32($data);

        $body.append(local-header($name, $crc, $data.elems));
        $body.append($data);
        $cd.append(central-header($name, $crc, $data.elems, $offset));
        $offset += 30 + $name.elems + $data.elems;
    }

    my Buf $eocd = Buf.new(0x50, 0x4b, 0x05, 0x06);
    $eocd.append(u16(0));
    $eocd.append(u16(0));
    $eocd.append(u16(@files.elems));
    $eocd.append(u16(@files.elems));
    $eocd.append(u32($cd.elems));
    $eocd.append(u32($offset));
    $eocd.append(u16(0));

    my Buf $out .= new;
    $out.append($body);
    $out.append($cd);
    $out.append($eocd);
    $out;
}

#| 写一份 .xlsx，返回数据行数（不含表头）。
our sub write-xlsx(
    Str:D $path,
    @names,
    @rows,
    Str:D :$sheet = 'Sheet1',
    --> Int
) is export {
    my Str $name = clean-sheet($sheet);
    my @files =
        '[Content_Types].xml', $CONTENT-TYPES,
        '_rels/.rels',         $ROOT-RELS,
        'xl/workbook.xml',     workbook-xml($name),
        'xl/_rels/workbook.xml.rels', $WORKBOOK-RELS,
        'xl/worksheets/sheet1.xml',   sheet-xml(@names, @rows),
    ;

    my @pairs;
    for @files -> $p, $c { @pairs.push: [$p, $c] }
    spurt $path, zip-store(@pairs);
    @rows.elems;
}
