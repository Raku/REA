use v6.d;
use Compress::Zlib::Raw;
use Duckula::SQL;
use Duckula::X::Frame;

#| 不依赖 DuckDB excel 扩展的最小 XLSX 读取器（兜底路径）。
#|
#| 正常路径由 `Session.read-excel` 直接走 DuckDB 原生 `read_xlsx`（v2.0.0
#| 官方 windows_amd64 构建带 excel 扩展，实测 9.5MB / 18525 行约 1.1 秒）。
#| 只有当前连接确实没有 excel 扩展时才进这里。支持日常表格的公共子集：
#| sharedStrings / inlineStr / 数字 / 布尔 / 公式结果，首行作表头。样式、
#| 日期格式、合并单元格不解析——日期会像 Excel 内部那样是序号。需要完整
#| 语义时请用带 excel 扩展的 DuckDB 构建。
#|
#| 解出来的行会灌进一张连接级临时表，然后像 read-arrow 一样返回指向
#| 那张表的 Frame：后续算子仍然由 DuckDB 执行。
unit module Duckula::ExcelRead;

my Int $TABLE-SEQ = 0;

sub fail(Str:D $reason --> Nil) {
    die Duckula::X::Frame.new(:$reason);
}

# ---------- ZIP（只读 central directory，够用就行） ----------

sub u16(Buf:D $b, Int:D $i --> Int) { $b[$i] + ($b[$i + 1] +< 8) }

sub u32(Buf:D $b, Int:D $i --> Int) {
    $b[$i] + ($b[$i + 1] +< 8) + ($b[$i + 2] +< 16) + ($b[$i + 3] +< 24);
}

#| ZIP 存的是 raw deflate（没有 zlib 头和校验和），用 -15 交给 zlib。
sub inflate-raw(Buf:D $raw, Int:D $size --> Str) {
    my Buf $out = Buf.allocate($size > 0 ?? $size !! 1);
    my $stream = z_stream.new;
    my Bool $inited = False;
    LEAVE { inflateEnd($stream) if $inited }

    $stream.set-input($raw);
    $stream.set-output($out);
    my $rc = inflateInit2($stream, -15);
    fail("xlsx: cannot initialise deflate stream (zlib rc=$rc)") unless $rc == 0;
    $inited = True;

    $rc = inflate($stream, 4); # Z_FINISH
    fail("xlsx: cannot inflate a ZIP entry (zlib rc=$rc)") unless $rc == 1;
    $out.subbuf(0, $stream.total-out).decode('utf8');
}

sub zip-entries(Buf:D $data --> Hash) {
    my Int $eocd = $data.elems - 22;
    while $eocd >= 0 && u32($data, $eocd) != 0x06054b50 { $eocd-- }
    fail('xlsx: not a ZIP archive (no end-of-central-directory)') if $eocd < 0;

    my Int $count = u16($data, $eocd + 10);
    my Int $off   = u32($data, $eocd + 16);
    my %entries;

    for ^$count -> $i {
        fail("xlsx: bad central directory at entry $i")
            unless $off + 46 <= $data.elems && u32($data, $off) == 0x02014b50;

        my Int $method = u16($data, $off + 10);
        my Int $csize  = u32($data, $off + 20);
        my Int $usize  = u32($data, $off + 24);
        my Int $nlen   = u16($data, $off + 28);
        my Int $elen   = u16($data, $off + 30);
        my Int $clen   = u16($data, $off + 32);
        my Int $lho    = u32($data, $off + 42);
        my Str $name   = $data.subbuf($off + 46, $nlen).decode('utf8');

        fail("xlsx: bad local header for $name")
            unless $lho + 30 <= $data.elems && u32($data, $lho) == 0x04034b50;
        my Int $start = $lho + 30 + u16($data, $lho + 26) + u16($data, $lho + 28);
        my Buf $raw = $data.subbuf($start, $csize);

        %entries{$name} = do given $method {
            when 0 { $raw.decode('utf8') }              # stored
            when 8 { inflate-raw($raw, $usize) }        # deflate
            default { fail("xlsx: unsupported ZIP method $method for $name") }
        }
        $off += 46 + $nlen + $elen + $clen;
    }
    %entries;
}

# ---------- 一点点 XML（字符串层面，避免依赖完整的 DOM） ----------

#| XML 实体解码。绝大多数单元格不含 `&`，快速路径直接返回原串——
#| 避免对 3000 万个小字符串各跑 7 次 subst(:g)（正则引擎开销极大）。
sub xml-text(Str:D $s --> Str) {
    return $s unless $s.contains('&');
    $s.subst(/'&#x' (<[0..9 a..f A..F]>+) ';'/, -> $/ { :16(~$0).chr }, :g)
      .subst(/'&#' (\d+) ';'/, -> $/ { $0.Int.chr }, :g)
      .subst('&lt;',   '<',  :g)
      .subst('&gt;',   '>',  :g)
      .subst('&quot;', '"',  :g)
      .subst('&apos;', "'",  :g)
      .subst('&amp;',  '&',  :g);
}

#| 从标签属性串里取 `name="..."`。手写 index，避免每行每列都跑一次 regex。
sub attr(Str:D $tag, Str:D $name --> Str) {
    my Str $needle = $name ~ '="';
    my Int $i = $tag.index($needle);
    return '' unless $i.defined;
    $i += $needle.chars;
    my Int $j = $tag.index('"', $i);
    $j.defined ?? $tag.substr($i, $j - $i) !! '';
}

sub resolve-part(Str:D $target --> Str) {
    my Str $p = $target.starts-with('/') ?? $target.substr(1) !! "xl/$target";
    my @parts;
    for $p.split('/') -> $seg {
        next if $seg eq '' || $seg eq '.';
        $seg eq '..' ?? @parts.pop !! @parts.push($seg);
    }
    @parts.join('/');
}

#| 把 `sheet`（表名或省略时的第一张）解析成 zip 里的 worksheet 部件名。
sub worksheet-part(%entries, Str :$sheet --> Str) {
    my Str $wb = %entries{'xl/workbook.xml'}
        // fail('xlsx: xl/workbook.xml is missing');
    my @sheets = $wb.match(/'<sheet' \s+ $<a>=(<- [>] >+) '/>'/, :g)
                   .map({ ~$_<a> });
    fail('xlsx: no worksheets found') unless @sheets;

    my Str $wanted = $sheet.defined ?? $sheet.fc !! '';
    my $chosen;
    for @sheets -> $tag {
        my Str $name = xml-text(attr($tag, 'name'));
        if !$sheet.defined || $name.fc eq $wanted {
            $chosen = $tag;
            last;
        }
    }
    fail("xlsx: no sheet named '$sheet'") unless $chosen.defined;

    my Str $rid = attr($chosen, 'r:id');
    my Str $rels = %entries{'xl/_rels/workbook.xml.rels'}
        // fail('xlsx: workbook relationships are missing');
    my @rels = $rels.match(/'<Relationship' \s+ $<a>=(<- [>] >+) '/>'/, :g)
                   .map({ ~$_<a> });
    for @rels -> $tag {
        next unless attr($tag, 'Id') eq $rid;
        my Str $part = resolve-part(attr($tag, 'Target'));
        return $part if %entries{$part}:exists;
        fail("xlsx: worksheet part $part is missing");
    }
    fail("xlsx: no relationship for sheet '$sheet'");
}

sub shared-strings(%entries --> Array) {
    return [] unless %entries{'xl/sharedStrings.xml'}:exists;
    my Str $xml = %entries{'xl/sharedStrings.xml'};
    my @out;
    my Int $pos = 0;
    my Int $len = $xml.chars;
    loop {
        my Int $s = $xml.index('<si>', $pos);
        last unless $s.defined;
        my Int $e = $xml.index('</si>', $s + 4);
        last unless $e.defined;
        my Str $body = $xml.substr($s + 4, $e - $s - 4);

        # 顺次取所有 <t...>...</t>（富文本会拆成多个 run）
        my Str $text = '';
        my Int $cp = 0;
        loop {
            my Int $ts = $body.index('<t', $cp);
            last unless $ts.defined;
            my Int $gt = $body.index('>', $ts + 2);
            last unless $gt.defined;
            my Int $te = $body.index('</t>', $gt + 1);
            last unless $te.defined;
            $text ~= xml-text($body.substr($gt + 1, $te - $gt - 1));
            $cp = $te + 4;
        }
        @out.push($text);
        $pos = $e + 5;
    }
    @out;
}

sub column-index(Str:D $ref --> Int) {
    my $m = $ref.match(/^ $<letters>=(<[A..Z]>+) /);
    fail("xlsx: bad cell reference '$ref'") unless $m;
    my Int $n = 0;
    $n = $n * 26 + ($_.ord - 64) for $m<letters>.Str.comb;
    $n - 1;
}

sub cell-value(Str:D $attrs, Str:D $inner, @shared) {
    my Str $type = attr($attrs, 't');

    if $type eq 'inlineStr' {
        my Str $text = '';
        my Int $cp = 0;
        loop {
            my Int $ts = $inner.index('<t', $cp);
            last unless $ts.defined;
            my Int $gt = $inner.index('>', $ts + 2);
            last unless $gt.defined;
            my Int $te = $inner.index('</t>', $gt + 1);
            last unless $te.defined;
            $text ~= xml-text($inner.substr($gt + 1, $te - $gt - 1));
            $cp = $te + 4;
        }
        return $text;
    }

    my Int $vs = $inner.index('<v>');
    my Str $v = '';
    if $vs.defined {
        my Int $ve = $inner.index('</v>', $vs + 3);
        $v = xml-text($inner.substr($vs + 3, $ve - $vs - 3)) if $ve.defined;
    }

    return @shared[$v.Int] // '' if $type eq 's';
    return $v eq '1' ?? True !! False if $type eq 'b';
    return $v if $type eq 'str' || $type eq 'e' || $v eq '';
    return $v + 0
        if $v ~~ /^ <[+\-]>? \d+ ['.' \d*]? <[eE]>? <[+\-]>? \d* $/;
    $v;
}

#| 流式遍历 sheet XML 的每一行。`&sink($row-index, @cells)` 收到一行即处理，
#| 处理完立刻释放——不保留 Match、不保留全量行数组。用 index 手工定位标签，
#| 替代原来 regex `:g` 一次性生成全部 Match 对象（85 万行时会吃掉十几 GB）。
sub each-row(Str:D $xml, @shared, &sink --> Nil) {
    my Int $pos = 0;
    my Int $ri  = 0;
    my Int $len = $xml.chars;

    loop {
        # 找下一个 <row（要求后面是空白或 >，避免误命中 <rowBreaks> 之类）
        my Int $s;
        loop {
            $s = $xml.index('<row', $pos);
            last unless $s.defined;
            $pos = $s + 4;
            my Str $nxt = $s + 4 < $len ?? $xml.substr($s + 4, 1) !! '';
            last if $nxt eq '>' || $nxt ~~ /^\s$/;
        }
        last unless $s.defined;

        my Int $gt = $xml.index('>', $s + 4);
        last unless $gt.defined;
        my Int $e = $xml.index('</row>', $gt + 1);
        last unless $e.defined;

        my Str $body = $xml.substr($gt + 1, $e - $gt - 1);
        my @cells;
        my Int $cp = 0;
        loop {
            my Int $cs = $body.index('<c ', $cp);
            last unless $cs.defined;
            my Int $cg = $body.index('>', $cs + 3);
            last unless $cg.defined;
            my Str $attrs = $body.substr($cs + 3, $cg - $cs - 3).subst(/ \s* $ /, '');
            my Int $next;
            my Str $inner = '';
            if $attrs.ends-with('/') {          # 自闭合 <c r="A1"/>
                $attrs = $attrs.substr(0, $attrs.chars - 1);
                $next = $cg + 1;
            } else {
                my Int $ce = $body.index('</c>', $cg + 1);
                last unless $ce.defined;
                $inner = $body.substr($cg + 1, $ce - $cg - 1);
                $next  = $ce + 4;
            }
            my Str $ref = attr($attrs, 'r');
            my Int $idx = $ref eq '' ?? @cells.elems !! column-index($ref);
            @cells[$idx] = cell-value($attrs, $inner, @shared);
            $cp = $next;
        }

        sink($ri, @cells);
        $ri++;
        $pos = $e + 6;
    }
}

sub normalise-headers(@raw --> Array) {
    my @out;
    my %seen;
    for @raw.kv -> $i, $v {
        my Str $name = ($v.defined ?? ~$v !! '').trim;
        $name = "col_{$i + 1}" if $name eq '';
        if %seen{$name}:exists {
            %seen{$name}++;
            $name = "{$name}_{%seen{$name}}";
        }
        else {
            %seen{$name} = 1;
        }
        @out.push($name);
    }
    @out;
}

sub column-type(@vals, Bool:D :$all-varchar --> Str) {
    return 'VARCHAR' if $all-varchar;
    my @defined = @vals.grep(*.defined);
    return 'VARCHAR' unless @defined;
    return 'BOOLEAN' if @defined.all ~~ Bool;
    return 'DOUBLE'  if @defined.all ~~ Numeric;
    'VARCHAR';
}

#| 可选加速：找一个带 excel 扩展的 Python duckdb，把 xlsx 转成 UTF-8 CSV 缓存。
#| 成功返回 CSV 路径；失败（无 Python / 无扩展 / 转换失败）返回 Nil，走纯 Raku 兜底。
#|
#| v0.35.0 起 **默认关闭**：DuckDB 2.0.0 官方构建自带原生 read_xlsx，比
#| Python 快且不引入外部依赖，正常路径根本不会进这个模块。只有在确实没有
#| excel 扩展、又必须读超大 xlsx 时，才需要显式开启本加速（纯 Raku 解析
#| 905MB sheet XML 要 4 分钟，Python duckdb 约 15 秒）。
#|
#| 开关：DUCKULA_XLSX_PY=1 开启；DUCKULA_PYTHON 指定解释器；
#| DUCKULA_XLSX_PY_MIN 调整启用阈值（0 表示强制）；
#| DUCKULA_XLSX_PY_DISABLE=1 彻底关闭。$LAST-READER 记录最后一次实际走的路，
#| 便于测试和排障。
my %CACHE;
my Int $CACHE-SEQ = 0;
my Bool $PY-PROBED = False;
my $PY-CMD;
our $LAST-READER is export = 'raku';

END {
    for %CACHE.values -> $csv {
        $csv.IO.unlink if $csv.IO.e;
    }
}

sub python-probe(@cmd --> Bool) {
    my Str $code = 'import duckdb;duckdb.connect().execute("LOAD excel")';
    my $proc = run(|@cmd, '-c', $code, :out, :err);
    $proc.out.slurp;
    $proc.err.slurp;
    return $proc.exitcode == 0;
    CATCH { default { return False } }
}

sub python-command(--> Any) {
    if %*ENV<DUCKULA_XLSX_PY_DISABLE>:exists
        && %*ENV<DUCKULA_XLSX_PY_DISABLE> ne '0' {
        return Nil;
    }
    # v0.35.0: 默认关闭，只在显式 DUCKULA_XLSX_PY=1 时启用。
    # 原生 read_xlsx 已覆盖常规大文件，不需要额外引入 Python 依赖。
    return Nil unless %*ENV<DUCKULA_XLSX_PY>:exists
        && %*ENV<DUCKULA_XLSX_PY> ne '0';
    return $PY-CMD if $PY-PROBED;
    $PY-PROBED = True;

    my @candidates;
    @candidates.push([%*ENV<DUCKULA_PYTHON>]) if %*ENV<DUCKULA_PYTHON>;
    @candidates.push(['python']);
    @candidates.push(['python3']);
    @candidates.push(['C:/Users/Admin/AppData/Local/Python/bin/python.exe']);

    for @candidates -> @cmd {
        next unless python-probe(@cmd);
        $PY-CMD = @cmd.Array;
        return $PY-CMD;
    }
    Nil;
}

sub python-csv-cache(Str:D $path, Str :$sheet, Bool:D :$all-varchar --> Any) {
    my $py = python-command();
    return Nil unless $py;

    my IO::Path $src = $path.IO;
    my Str $tag = ($all-varchar ?? 'v' !! 't') ~ '|' ~ ($sheet // '')
        ~ '|' ~ $src.modified.Num.Str ~ '|' ~ $src.s.Str;
    my Str $cached = %CACHE{$path ~ $tag} // '';
    return $cached if $cached && $cached.IO.e;

    my Str $out = $*TMPDIR.add("duckula-xlsx-{$*PID}-{++$CACHE-SEQ}.csv").Str;
    # 用 argv 传路径/表名，避免把用户数据拼进 Python 源码；SQL 字面量在脚本里再转义。
    my Str $code = q:to/PY/;
import sys, duckdb

def q(s):
    return "'" + s.replace("'", "''") + "'"

src, out = sys.argv[1], sys.argv[2]
all_varchar = sys.argv[3] == '1'
sheet = sys.argv[4] if len(sys.argv) > 4 else None
con = duckdb.connect()
con.execute("LOAD excel")
sql = "SELECT * FROM read_xlsx(" + q(src)
if sheet is not None:
    sql += ", sheet = " + q(sheet)
if all_varchar:
    sql += ", all_varchar = true"
sql += ", ignore_errors = true)"
con.execute("COPY (" + sql + ") TO " + q(out) + " (FORMAT CSV, HEADER)")
PY
    my @args = |$py, '-c', $code, $path, $out, ($all-varchar ?? '1' !! '0');
    @args.push($sheet) if $sheet.defined;
    my $proc = run(|@args, :out, :err);
    $proc.out.slurp;
    my Str $err = $proc.err.slurp;   # slurp 会等到进程结束
    unless $proc.exitcode == 0 && $out.IO.e && $out.IO.s > 0 {
        note "xlsx: python duckdb cache failed: {$err.trim}" if %*ENV<DUCKULA_VERBOSE>;
        $out.IO.unlink if $out.IO.e;
        return Nil;
    }
    note "xlsx: via python duckdb csv cache ($out)" if %*ENV<DUCKULA_VERBOSE>;
    %CACHE{$path ~ $tag} = $out;
    $out;
}

#| 主入口：解析 xlsx -> 临时表 -> Frame。
our sub read-excel(
    $session,
    Str:D $path,
    Str :$sheet,
    Bool:D :$header = True,
    Bool:D :$all-varchar = False,
) is export {
    fail('read-excel needs file-system access, but this session is sandboxed')
        if $session.sandboxed;
    fail("read-excel: no such file '$path'") unless $path.IO.e;
    $LAST-READER = 'raku';

    # ---- 快路径：大 xlsx 交给 Python duckdb（自带 excel 扩展）转 CSV ----
    # 阈值 5MB：小文件走纯 Raku 反而快（省去 Python 进程启动）。
    # DUCKULA_XLSX_PY_MIN=0 可强制所有文件走快路径，便于测试。
    my Int $fast-min = 5 * 1024 * 1024;
    if %*ENV<DUCKULA_XLSX_PY_MIN>:exists
        && %*ENV<DUCKULA_XLSX_PY_MIN> ~~ /^ \d+ $/ {
        $fast-min = %*ENV<DUCKULA_XLSX_PY_MIN>.Int;
    }
    if $path.IO.s >= $fast-min {
        my $csv = python-csv-cache($path, :$sheet, :$all-varchar);
        if $csv.defined {
            $LAST-READER = 'python-csv';
            my Str $tbl = "__duckula_xlsx_{$*PID}_{++$TABLE-SEQ}";
            $session.execute(
                "CREATE OR REPLACE TEMP TABLE {quote-ident($tbl)} AS "
                ~ "SELECT * FROM read_csv({sql-literal($csv)}, all_varchar={$all-varchar ?? 'true' !! 'false'}, header={$header ?? 'true' !! 'false'})"
            );
            return $session.sql('SELECT * FROM ' ~ quote-ident($tbl));
        }
    }

    my %entries = zip-entries(slurp($path, :bin));
    my Str $part = worksheet-part(%entries, :$sheet);
    my @shared = shared-strings(%entries);
    my Str $xml = %entries{$part};

    # ---- 单遍流式：第一行拿表头 -> 立刻建表 -> 每行分批灌入 ----
    # all-varchar 时用全 VARCHAR 表（快路径，不做类型推断第二遍）；
    # 否则先流式推断列类型再建表。整个过程中不保留任何完整行数组。
    my Str $table = "__duckula_xlsx_{$*PID}_{++$TABLE-SEQ}";
    my Int $batch-size = 5000;
    my @batch;
    my @headers;
    my @types;
    my Int $width = 0;
    my Bool $created = False;
    my @seen;
    my @all-bool;
    my @all-num;

    # all-varchar 且带表头时，第一遍只取表头即可定表结构。
    # 非 all-varchar 需要推断类型：先流式扫一遍收集每列的类型状态。
    if !($all-varchar && $header) {
        each-row($xml, @shared, -> $ri, @cells {
            if $ri == 0 && $header {
                @headers = normalise-headers(@cells);
                @seen = False xx @headers.elems;
                @all-bool = True xx @headers.elems;
                @all-num = True xx @headers.elems;
            } else {
                my Int $w = @cells.elems;
                if !$header && $w > @headers.elems {
                    my Int $old = @headers.elems;
                    @headers.append((^($w - $old)).map({ "col_{$old + $_ + 1}" }));
                    @seen.append(False xx ($w - $old));
                    @all-bool.append(True xx ($w - $old));
                    @all-num.append(True xx ($w - $old));
                }
                if $all-varchar {
                    @seen.append(True xx (@cells.elems - @seen.elems)) if @cells.elems > @seen.elems;
                } else {
                    for ^(@headers.elems min $w) -> $c {
                        my $v = @cells[$c];
                        next unless $v.defined;
                        @seen[$c] = True;
                        @all-bool[$c] = False unless $v ~~ Bool;
                        @all-num[$c]  = False unless $v ~~ Numeric;
                    }
                }
            }
        });
        $width = @headers.elems;
        @types = (0 ..^ $width).map(-> $c {
            !@seen[$c] ?? 'VARCHAR'
            !! @all-bool[$c] ?? 'BOOLEAN'
            !! @all-num[$c] ?? 'DOUBLE'
            !! 'VARCHAR'
        }).Array;
    }

    each-row($xml, @shared, -> $ri, @cells {
        # 第一行当表头：建立表结构（或已在上一步推断好则直接建）
        if $ri == 0 && $header && !$created {
            @headers = normalise-headers(@cells) unless @headers;
            $width = @headers.elems;
            @types = 'VARCHAR' xx $width unless @types;
            my Str $cols = (0 ..^ $width).map({
                "{quote-ident(@headers[$_])} {@types[$_]}"
            }).join(', ');
            $session.execute("CREATE OR REPLACE TEMP TABLE {quote-ident($table)} ($cols)");
            $created = True;
            next;
        }
        unless $created {
            # 无表头：以第一行的宽度建表
            my Int $w = @cells.elems;
            if $w > $width {
                $width = $w;
                @headers.append((^($w - @headers.elems)).map({ "col_{$_ + 1}" }));
            }
            @types = 'VARCHAR' xx $width unless @types;
            my Str $cols = (0 ..^ $width).map({
                "{quote-ident(@headers[$_])} {@types[$_]}"
            }).join(', ');
            $session.execute("CREATE OR REPLACE TEMP TABLE {quote-ident($table)} ($cols)");
            $created = True;
        }
        my @data;
        for ^$width -> $c {
            my $v = @cells[$c];
            @data.push(!$v.defined ?? Nil !! (@types[$c] eq 'VARCHAR' ?? ~$v !! $v));
        }
        @batch.push(@data);
        if @batch.elems >= $batch-size {
            $session.insert($table, @batch);
            @batch = ();
        }
    });
    $session.insert($table, @batch) if @batch;
    $session.execute("CREATE OR REPLACE TEMP TABLE {quote-ident($table)} (col_1 VARCHAR)")
        unless $created;

    $session.sql('SELECT * FROM ' ~ quote-ident($table));
}

#| 只看骨架：sheet 名和行列数（不建表）。
our sub describe-xlsx(Str:D $path --> Hash) is export {
    my %entries = zip-entries(slurp($path, :bin));
    my Str $part = worksheet-part(%entries);
    my @shared = shared-strings(%entries);
    my Int $rows = 0;
    my Int $cols = 0;
    each-row(%entries{$part}, @shared, -> $ri, @cells {
        $rows++;
        $cols = @cells.elems if @cells.elems > $cols;
    });
    my @tags = %entries{'xl/workbook.xml'}
        .match(/'<sheet' \s+ $<a>=(<- [>] >+) '/>'/, :g).map({ ~$_<a> });
    {
        sheets => @tags.map({ xml-text(attr($_, 'name')) }).Array,
        rows   => $rows,
        cols   => $cols,
    };
}
