use v6.d;
use Duckula::SQL;
use Duckula::X::Frame;
use Duckula::IO;
use Duckula::ExcelWrite;

#| 把结果「写出去」：落到 Parquet / CSV，或者写进一张真表。
#|
#| 这是阶段 7 的落点。读侧（`read-parquet` / `scan-csv`）在 v0.3.0 就有了，
#| 写侧一直缺口 —— 只能导出 Arrow IPC，换不成分析生态里的通用文件。
#|
#| # 为什么每个入口都收「已经渲染好的 SQL」
#|
#| DuckDB 的 `COPY` 不接受绑定参数：`COPY (SELECT ... WHERE x = ?) TO ...`
#| 里那个 `?` 不会被 prepared statement 填上，执行时直接报错。所以写文件
#| 只能拼文本 —— 那路径和表名就必须由我们自己转义，而不能指望参数绑定。
#| 两个工具都在 `Duckula::SQL`：`sql-literal` 处理字符串（单引号双写）、
#| `quote-ident` 处理标识符（双引号双写）。
#|
#| 惰性路径因此要先 `render-bindings` 把参数变成字面量。这一步比 eager 路
#| 稍早（eager 在 `Session.sql` 里就做了），但同样只发生在**出库**这一刻，
#| 查询本身的执行仍然是绑定参数。
#|
#| # 行数是怎么来的
#|
#| `COPY` 不回报行数，`INSERT` 的 rows-affected 在 DuckDB 里也不总是可信。
#| 所以统一在写之前 `SELECT count(*) FROM (<sql>)`：DuckDB 对这条有统计
#| 信息可用，通常不扫数据。返回值是「这次写了多少行」，空结果就是 0。
unit module Duckula::Write;

#| DuckDB 认的 Parquet 压缩算法。写死在白名单里，不让调用方的字符串直接
#| 进 SQL 的选项区 —— `COMPRESSION ZSTD; DROP TABLE t` 这种就先拦在这里。
my constant PARQUET-COMPRESSION =
    <uncompressed brotli gzip snappy lz4 lz4_raw zstd>.Set;

#| 去掉尾部分号。`COPY (<sql>)` 里多一个分号就是语法错误。
sub clean-sql(Str:D $sql --> Str) {
    $sql.trim.subst(/ ';' $ /, '').trim;
}

#| 写文件要先有外部访问权。沙箱会话已经 `SET enable_external_access=false`，
#| 让它执行下去只会得到 DuckDB 一句「Cannot access file」，不如在入口说清楚。
sub need-file-access($session, Str:D $what --> Nil) {
    return unless $session.sandboxed;
    die Duckula::X::Frame.new(
        reason => "$what needs file-system access, but this session is sandboxed; "
                ~ "create it with Duckula::Session.new(:!sandbox) to allow writes"
    );
}

#| CSV 的分隔符/引号只能是单个字符，且不能是换行。
sub check-char(Str:D $name, Str:D $value --> Nil) {
    die Duckula::X::Frame.new(
        reason => "$name must be a single character, got {$value.raku}"
    ) unless $value.chars == 1;
    die Duckula::X::Frame.new(
        reason => "$name cannot be a line break"
    ) if $value ~~ /<[\r\n]>/;
}

#| 一行都不搬地数一遍，给写入口当返回值。
sub count-rows($session, Str:D $sql --> Int) {
    $session.conn.query(
        "SELECT count(*) FROM ({clean-sql($sql)}) AS __duckula_count"
    ).value.Int;
}

#| 把结果写成 Parquet。
#|
#|   $df.to-parquet('out.parquet');
#|   $df.to-parquet('out.parquet', :compression<snappy>);
#|
#| 返回写出的行数。压缩算法见 `PARQUET-COMPRESSION`，默认 zstd。
our sub write-parquet(
    $session,
    Str:D $sql,
    Str:D $path,
    Str:D :$compression = 'zstd',
    --> Int
) is export {
    need-file-access($session, 'to-parquet');

    my Str $algo = $compression.lc;
    die Duckula::X::Frame.new(
        reason => "unknown parquet compression '{$compression}'; "
                ~ 'expected one of ' ~ PARQUET-COMPRESSION.keys.sort.join(', ')
    ) unless PARQUET-COMPRESSION{$algo};

    my Int $rows = count-rows($session, $sql);
    $session.conn.execute(
        "COPY ({clean-sql($sql)}) TO {sql-literal($path)} "
        ~ "(FORMAT PARQUET, COMPRESSION {$algo.uc})"
    );
    $rows;
}

#| 把结果写成 CSV。
#|
#|   $df.to-csv('out.csv');
#|   $df.to-csv('out.csv', :!header, :delimiter<;>);
#|
#| 返回写出的行数。`:$null` 给定后，NULL 写成那个字符串（DuckDB 的 NULL
#| 选项）；不给就按 DuckDB 默认（空字段）。
our sub write-csv(
    $session,
    Str:D $sql,
    Str:D $path,
    Bool:D :$header = True,
    Str:D :$delimiter = ',',
    Str:D :$quote = '"',
    Str :$null,
    --> Int
) is export {
    need-file-access($session, 'to-csv');
    check-char('delimiter', $delimiter);
    check-char('quote', $quote);

    my @opts = 'FORMAT CSV', 'HEADER ' ~ ($header ?? 'true' !! 'false');
    @opts.push: 'DELIMITER ' ~ sql-literal($delimiter);
    @opts.push: 'QUOTE ' ~ sql-literal($quote);
    @opts.push: 'NULL ' ~ sql-literal($null) if $null.defined;

    my Int $rows = count-rows($session, $sql);
    $session.conn.execute(
        "COPY ({clean-sql($sql)}) TO {sql-literal($path)} ({@opts.join(', ')})"
    );
    $rows;
}

#| 把结果写成 JSON（v0.27.0）。
#|
#|   $df.to-json('out.json');                       # JSON 数组
#|   $df.to-json('out.ndjson', :format<newline-delimited>);
#|
#| `ARRAY true` 产出一个 JSON 数组，`FORMAT NDJSON` 产出行分隔 JSON。
#| 和读入侧一样，路径走 sql-literal，格式字符串走白名单。
our sub write-json(
    $session,
    Str:D $sql,
    Str:D $path,
    Str:D :$format = 'array',
    --> Int
) is export {
    need-file-access($session, 'to-json');
    my Str $fmt = $format.lc;
    die Duckula::X::Frame.new(
        reason => "unknown json format '$format'; use 'array' or 'newline-delimited'"
    ) unless $fmt eq 'array' || $fmt eq 'newline-delimited';

    my Str $opts = $fmt eq 'array'
        ?? '(FORMAT JSON, ARRAY true)'
        !! '(FORMAT NDJSON)';

    my Int $rows = count-rows($session, $sql);
    $session.conn.execute(
        "COPY ({clean-sql($sql)}) TO {sql-literal($path)} $opts"
    );
    $rows;
}

#| 把结果写成 XLSX（v0.27.0；v0.35.0 起默认走 DuckDB 原生 COPY）。
#|
#| 两条路：
#|   1. DuckDB 装了 excel 扩展且用默认 sheet 名时，直接
#|      `COPY (<sql>) TO <path> (FORMAT XLSX, HEADER true)`。数据一行不过
#|      Raku，86 万行也不会在 Raku 侧堆成 Array-of-Array —— 这是原先纯 Raku
#|      写出大结果集时最吃内存的地方。
#|   2. 自定义 sheet 名（DuckDB COPY 不支持指定 sheet）或没有 excel 扩展时，
#|      退回纯 Raku 的 OOXML 写出，保证 sheet 名、表头、行序跨平台一致。
#|
#| 旧注释说「COPY 出来的文件没有表头」——那是 mingw/旧构建的行为；官方
#| windows_amd64 的 2.0.0 上 `HEADER true` 已被实测带表头且可读回。
#|
#| `$rows` / `$names` 可以是可调用对象（惰性 thunk）：原生路径不会调用它，
#| 只有兜底路径才求值，避免白白把整张表拉进内存。
our sub write-excel(
    $session,
    Str:D $sql,
    Str:D $path,
    Str:D :$sheet = 'Sheet1',
    :$rows = Nil,
    :$names = Nil,
    --> Int
) is export {
    need-file-access($session, 'to-excel');

    my Int $count = count-rows($session, $sql);
    my Bool $native = $sheet eq 'Sheet1' && excel-available($session);

    if $native {
        # COPY 不支持绑定参数，路径必须自己转义成 SQL 字面量。
        $session.conn.execute(
            "COPY ({clean-sql($sql)}) TO {sql-literal($path)} "
            ~ '(FORMAT XLSX, HEADER true)'
        );
        return $count;
    }

    # 兜底：这时才把行拉进 Raku。Frame/LazyFrame 传进来的是 thunk，
    # 走原生路径时它们根本不会被调用。
    my @names = $names.defined
        ?? ($names ~~ Callable ?? $names().List !! $names.List) !! ();
    my @rows = $rows.defined
        ?? ($rows ~~ Callable ?? $rows().List !! $rows.List) !! ();
    unless @names && @rows {
        my $res = $session.conn.query(clean-sql($sql));
        @names = $res.names.List unless @names;
        # 每行钉成 Array，避免赋值时被展平成单元格字符串；同时这也是
        # ColumnView 的解码路径，比 Result.arrays 在 rakupp 上稳定。
        @rows = $res.arrays.map(-> $r { $r.Array }).List unless @rows;
    }
    Duckula::ExcelWrite::write-xlsx($path, @names, @rows, :$sheet);
    $count;
}

#| 把结果变成一张真表（`CREATE TABLE ... AS SELECT`）。
#|
#|   $df.to-table('clean_orders');              # 建或替换
#|   $df.to-table('raw', :!replace);            # 已存在则报错
#|   $df.to-table('tmp', :temporary);           # 连接级临时表
#|
#| 数据不出 DuckDB，所以比写文件快，也**不受沙箱限制**。返回表里的行数。
#| `:replace` 默认 True —— 与 pandas `to_sql(if_exists='replace')` 对齐。
our sub create-table(
    $session,
    Str:D $sql,
    Str:D $name,
    Bool:D :$replace = True,
    Bool:D :$temporary = False,
    --> Int
) is export {
    my Str $verb = 'CREATE' ~ ($replace ?? ' OR REPLACE' !! '')
                 ~ ($temporary ?? ' TEMP' !! '') ~ ' TABLE ' ~ quote-ident($name);

    $session.conn.execute("$verb AS {clean-sql($sql)}");
    count-rows($session, 'SELECT * FROM ' ~ quote-ident($name));
}

#| 把结果追加到已有表（`INSERT INTO ... SELECT`），列按位置对齐。
#|
#| 数据同样不出 DuckDB。返回实际插入的行数。
our sub insert-into(
    $session,
    Str:D $sql,
    Str:D $name,
    --> Int
) is export {
    $session.conn.execute(
        "INSERT INTO {quote-ident($name)} {clean-sql($sql)}"
    ).Int;
}

#| 把一批 Raku 行写进已有表，走 DuckDB 的 Appender（批量、单事务）。
#|
#| 与 `insert-into` 的分工：那边是「结果集已经在库里，换个地方放」，纯 SQL，
#| 一行不过 Raku；这边是「数据本来就在 Raku 里」，必须逐行过 Appender。
#| 一次失败整批回滚，不会留下半截数据（DB::DuckDB 的既有语义）。
our sub append-rows(
    $session,
    Str:D $table,
    @rows,
    Str :$schema,
    --> Int
) is export {
    $session.conn.insert-rows($table, @rows, :$schema);
}
