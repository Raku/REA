use v6.d;

# 跑 t/*.rakutest 并逐文件汇总。
#
#   raku tools/run-tests.raku                 # 全部
#   raku tools/run-tests.raku t/20-arrow-cache.rakutest   # 指定文件
#
# 直接在仓库根目录运行（测试里的相对路径都按根目录解析）。退出码：
# 0 = 全绿，1 = 有文件失败或崩溃。
#
# 为什么不用 `prove` / `zef test`：Duckula 的测试是 `Test` 脚本而不是
# TAP 生产者之外的框架，本脚本只做「逐个文件跑 + 汇总失败断言」，
# 任何 CI 只要能跑 raku 就能用。

# $*EXE 在部分 Rakudo 构建里不存在（Windows 版实测是 undef，2026.11 的
# WSL 版访问它直接报 "Dynamic variable $*EXE not found"）；$*EXECUTABLE
# 是当前解释器路径，作为首选，取不到再退回 PATH 里的 raku。
my Str $exe;
try { $exe = $*EXECUTABLE.Str }
$exe //= 'raku';

my @files = @*ARGS.elems
    ?? @*ARGS.map({ .IO })
    !! 't'.IO.dir.grep({ .f && .extension eq 'rakutest' }).sort({ .Str });

my Int $failed-files = 0;
my Int $ok-count = 0;
my Int $not-ok-count = 0;
my @bad;
my $start = now;

for @files -> $f {
    my $t0 = now;
    my $proc = run($exe, '-Ilib', $f.Str, :out, :err);
    # 两个管道同时抽，避免子进程写满 stderr 管道后卡住。
    my $err-p = start { $proc.err.slurp };
    my Str $out = $proc.out.slurp;
    my Str $err = $err-p.result;
    my @not-ok = ($out ~ "\n" ~ $err).lines.grep({ .starts-with('not ok') });
    my Int $ok = $out.lines.grep({ .starts-with('ok ') }).elems;
    my $secs = (now - $t0).round(0.1);

    $ok-count += $ok;
    $not-ok-count += @not-ok.elems;

    if @not-ok.elems || $proc.exitcode != 0 {
        $failed-files++;
        @bad.push($f.Str);
        say "FAIL {$f.Str}  ({$ok} ok, {@not-ok.elems} not ok, {$secs}s, exit {$proc.exitcode})";
        say "    $_" for @not-ok;
        # 崩在断言之前（编译错误、段错误）时 not ok 为 0，得把 stderr 带出来。
        if !@not-ok.elems {
            say "    $_" for $err.lines.tail(20);
        }
    }
    else {
        say "ok   {$f.Str}  ({$ok} tests, {$secs}s)";
    }
}

say '-' x 64;
say "files: {@files.elems}  ok: {$ok-count}  not-ok: {$not-ok-count}  "
    ~ "failed files: {$failed-files}  elapsed: {(now - $start).round(0.1)}s";
say "failed: {@bad.join(', ')}" if @bad;

exit($failed-files ?? 1 !! 0);
