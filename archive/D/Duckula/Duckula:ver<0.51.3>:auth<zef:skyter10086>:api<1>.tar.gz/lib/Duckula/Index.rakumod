use v6.d;
use Duckula::SQL;
use Duckula::Clean;
use Duckula::X::Frame;

# ============================================================
# 逻辑索引：显式行号列（不是 pandas 那种隐藏 Index）
# ============================================================
#
# DuckDB 的关系没有「自带行号」，所以 Duckula 一开始刻意不提供 index。
# 但 Polars 的 with_row_index 指出了一条不破坏 SQL-first 的路：把行号
# **作为一列显式产出来**，后续 iloc / 对齐都只是对这列做 SQL。
#
# 这样做的好处：
#   - 行号跟着行走（sort / filter / concat 之后仍然对得上）；
#   - 不需要在 Frame 里藏一份「索引元数据」，也不会在派生时走丢；
#   - 全部翻译成 SQL，DuckDB 仍是唯一执行引擎。
#
# 语义：0 基（与 Polars 一致），负数从末尾算（与 pandas iloc 一致）。
# 行号锚定的是「当前扫描序」；要稳定就先 sort。这一点和 tail/reverse
# 用 row_number() OVER () 的做法一致（ARCHITECTURE §8.10）。

#| 行号表达式。0 基，可选偏移。
our sub row-index-expr(Int:D :$offset = 0 --> Str) is export {
    my Str $sql = 'row_number() OVER () - 1';
    $sql ~= ' + ' ~ $offset if $offset != 0;
    $sql;
}

#| 给一条 SQL 加上行号列。同名列先 EXCLUDE —— 与 Polars 的
#| with_row_index 覆盖语义一致，也避免 SELECT * 出现两个同名列。
our sub with-row-index-sql(
    Str:D $sql,
    Str:D $name,
    Bool:D :$replace = False,
    Int:D :$offset = 0,
    --> Str
) is export {
    my Str $q = quote-ident($name);
    # DuckDB 的 EXCLUDE 要求列真的存在，不能无脑带上。
    my Str $head = $replace ?? '* EXCLUDE (' ~ $q ~ ')' !! '*';
    'SELECT ' ~ $head ~ ', ' ~ row-index-expr(:$offset) ~ ' AS ' ~ $q
      ~ ' FROM (' ~ $sql ~ ') AS __duckula_rowidx';
}

#| 行号列必须显式存在。不偷偷加一列，免得 `iloc` 在用户没意识到的
#| 情况下把「当前扫描序」当成永久身份。
our sub check-index-column(Str:D $name, @names, Str:D $op --> Nil) is export {
    die Duckula::X::Frame.new(
        reason => "$op: no index column '$name'; call with-row-index first "
                ~ "(available: {@names.join(', ')})"
    ) unless $name ∈ @names.Set;
}

#| 单个整数位置 → SQL 片段。负数借 `__duckula_n`（总行数）从末尾算。
my sub idx-value(Int:D $i, Str:D $nq --> Str) {
    $i >= 0 ?? $i.Str !! '(' ~ $nq ~ ' + ' ~ $i ~ ')';
}

#| 把 Int / Range / Positional 归一成 WHERE 谓词。
our sub iloc-predicate($rows, Str:D $name, Str:D $nq --> Str) is export {
    my Str $q = quote-ident($name);

    if $rows ~~ Int:D {
        return $q ~ ' = ' ~ idx-value($rows, $nq);
    }

    if $rows ~~ Range:D {
        die Duckula::X::Frame.new(reason => 'iloc: unbounded ranges are not supported')
            if $rows.min == -Inf || $rows.max == Inf;

        my Int $lo = $rows.min.Int + ($rows.excludes-min ?? 1 !! 0);
        my Int $hi = $rows.max.Int - ($rows.excludes-max ?? 1 !! 0);
        return 'false' if $lo > $hi;
        return $q ~ ' BETWEEN ' ~ idx-value($lo, $nq)
                   ~ ' AND ' ~ idx-value($hi, $nq);
    }

    if $rows ~~ Positional:D {
        my @vals = $rows.List;
        return 'false' unless @vals.elems;
        die Duckula::X::Frame.new(reason => 'iloc: list items must be Int')
            unless @vals.all ~~ Int:D;
        return @vals.map({ $q ~ ' = ' ~ idx-value($_, $nq) }).join(' OR ');
    }

    die Duckula::X::Frame.new(
        reason => 'iloc expects an Int, a Range or a list of Int, got '
                ~ $rows.^name
    );
}

#| 列表下标按用户给的顺序输出（pandas 的 iloc[[2,0]] 语义），
#| 不是照源表顺序。Int / Range 没有这个需求。
my sub iloc-order($rows, Str:D $name, Str:D $nq --> Str) {
    return '' unless $rows ~~ Positional:D;
    my Str $q = quote-ident($name);
    my @cases;
    for $rows.List.kv -> $pos, $i {
        @cases.push: 'WHEN ' ~ $q ~ ' = ' ~ idx-value($i, $nq) ~ ' THEN ' ~ $pos;
    }
    return '' unless @cases.elems;
    ' ORDER BY CASE ' ~ @cases.join(' ') ~ ' END';
}

#| 按行号取子集。外层补一个 count(*) OVER () 只为支持负数下标；
#| 这个辅助列随后被 EXCLUDE，不会漏到结果里。
#|
#| `@names` 是源表的列名：辅助列名必须先避让，否则用户恰好有一列叫
#| `__duckula_n` 时，辅助列会把它盖掉、EXCLUDE 掉真实数据。
our sub iloc-sql(Str:D $sql, Str:D $name, $rows, @names = () --> Str) is export {
    my Set $known = @names.Set;
    my Str $n  = '__duckula_n';
    $n ~= '_' while $n ∈ $known;
    my Str $nq = quote-ident($n);
    my Str $pred = iloc-predicate($rows, $name, $nq);
    my Str $order = iloc-order($rows, $name, $nq);

    'SELECT * EXCLUDE (' ~ $nq ~ ') FROM ('
      ~ 'SELECT *, count(*) OVER () AS ' ~ $nq
      ~ ' FROM (' ~ $sql ~ ') AS __duckula_iloc_base'
      ~ ') AS __duckula_iloc WHERE ' ~ $pred ~ $order;
}

# ============================================================
# 声明式 key 索引（v0.22.0）
# ============================================================
#
# v0.21.0 的行号列解决「按位置取」；这一层解决「按身份对齐」。
# key 列是用户显式声明的真实列，不是隐藏序号 —— 因此 sort/filter
# 之后它们还在，Frame 派生时只需把列名清单带过去。

#| 校验 key 列确实存在，且不与自己重复。
our sub check-index-cols(@cols, @names, Str:D $op --> Nil) is export {
    need-cols(@cols, @names, $op);
    my %seen;
    for @cols -> $c {
        die Duckula::X::Frame.new(reason => "$op: duplicate key column '$c'")
            if %seen{$c}:exists;
        %seen{$c} = True;
    }
}

#| pandas `reindex` 的 SQL：按给定的 key 值列表过滤**并重排**，
#| 缺失的 key 留一行全 NULL（LEFT JOIN 的结果）。
#|
#| 用一张 `VALUES` 临时键表带 `__duckula_ord` 列来保序，而不是
#| `ORDER BY CASE`：多列 key 时 CASE 写起来很丑，而且值要绑两次。
#| `@rows` 是 List of List，每个内层 List 与 `@keys` 一一对应。
our sub reindex-sql(Str:D $sql, @keys, @rows, @names = (), :$fill --> Str) is export {
    my @qk = @keys.map({ quote-ident($_) });
    my Set $key-set = @keys.Set;
    my $ord = '__duckula_ord';
    my @tuples;
    for @rows.kv -> $pos, $vals {
        my @v = $vals.List;
        die Duckula::X::Frame.new(
            reason => "reindex: expected {@keys.elems} values per row, got {@v.elems}"
        ) unless @v.elems == @keys.elems;
        @tuples.push: '(' ~ @v.map({ sql-literal($_) }).join(', ') ~ ', ' ~ $pos ~ ')';
    }

    my Str $on = @keys.map({
        'f.' ~ quote-ident($_) ~ ' = k.' ~ quote-ident($_)
    }).join(' AND ');

    # :fill 给缺失行的**非 key 列**补值；key 列仍沿用原有的 LEFT JOIN
    # 语义（缺失时为 NULL），这样不会动到 t/24 里已固化的默认行为。
    my Str $projection = 'f.*';
    if $fill.defined && @names.elems {
        my @items = @names.map(-> $n {
            $key-set{$n}
                ?? 'f.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($n)
                !! 'coalesce(f.' ~ quote-ident($n) ~ ', ' ~ sql-literal($fill)
                   ~ ') AS ' ~ quote-ident($n)
        });
        $projection = @items.join(', ');
    }

    'SELECT ' ~ $projection ~ ' FROM (VALUES ' ~ @tuples.join(', ') ~ ') AS k('
      ~ @qk.join(', ') ~ ', ' ~ quote-ident($ord) ~ ')'
      ~ ' LEFT JOIN (' ~ $sql ~ ') AS f ON ' ~ $on
      ~ ' ORDER BY k.' ~ quote-ident($ord);
}

#| 两个 Frame 的 Series 按 key 对齐做二元运算。
#|
#| FULL OUTER JOIN：只在一边出现的 key 也保留，对应侧的列是 NULL，
#| 于是 `s1.add(s2)` 的结果在缺行处自然是 NULL —— 这正是 pandas 的
#| index 对齐语义。key 重复时两边做笛卡尔积，和 pandas 一致。
our sub align-binop-sql(
    Str:D $lsql, Str:D $rsql,
    @keys, Str:D $lcol, Str:D $rcol,
    Str:D $op, Str:D $out,
    --> Str
) is export {
    my @sel = @keys.map({
        'coalesce(l.' ~ quote-ident($_) ~ ', r.' ~ quote-ident($_) ~ ') AS '
          ~ quote-ident($_)
    });
    my Str $on = @keys.map({
        'l.' ~ quote-ident($_) ~ ' = r.' ~ quote-ident($_)
    }).join(' AND ');

    'SELECT ' ~ @sel.join(', ')
      ~ ', (l.' ~ quote-ident($lcol) ~ ' ' ~ $op
      ~ ' r.' ~ quote-ident($rcol) ~ ') AS ' ~ quote-ident($out)
      ~ ' FROM (' ~ $lsql ~ ') AS l'
      ~ ' FULL OUTER JOIN (' ~ $rsql ~ ') AS r ON ' ~ $on;
}

#| 按 key 对齐后取 coalesce（v0.31.0）：pandas `Series.combine_first`。
our sub align-coalesce-sql(
    Str:D $lsql, Str:D $rsql,
    @keys, Str:D $lcol, Str:D $rcol, Str:D $out,
    --> Str
) is export {
    my @sel = @keys.map({
        'coalesce(l.' ~ quote-ident($_) ~ ', r.' ~ quote-ident($_) ~ ') AS '
          ~ quote-ident($_)
    });
    my Str $on = @keys.map({
        'l.' ~ quote-ident($_) ~ ' = r.' ~ quote-ident($_)
    }).join(' AND ');

    'SELECT ' ~ @sel.join(', ')
      ~ ', coalesce(l.' ~ quote-ident($lcol) ~ ', r.' ~ quote-ident($rcol)
      ~ ') AS ' ~ quote-ident($out)
      ~ ' FROM (' ~ $lsql ~ ') AS l'
      ~ ' FULL OUTER JOIN (' ~ $rsql ~ ') AS r ON ' ~ $on;
}

#| 整张 Frame 的 combine_first：按声明的 key 做 FULL OUTER JOIN，
#| 每列取左值优先、右值兜底；右边独有的列也一并带进来。
our sub combine-first-sql(
    Str:D $lsql, Str:D $rsql, @keys, @lnames, @rnames,
    --> Str
) is export {
    my @sel = @keys.map({
        'coalesce(l.' ~ quote-ident($_) ~ ', r.' ~ quote-ident($_) ~ ') AS '
          ~ quote-ident($_)
    });
    my Set $keys = @keys.Set;
    my Set $left-names = @lnames.Set;
    my Set $right-names = @rnames.Set;
    for @lnames -> $n {
        next if $keys{$n};
        # 两边都有的列取 coalesce；右边没有的保持左值。
        @sel.push: $right-names{$n}
            ?? 'coalesce(l.' ~ quote-ident($n) ~ ', r.' ~ quote-ident($n)
               ~ ') AS ' ~ quote-ident($n)
            !! 'l.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($n);
    }
    for @rnames -> $n {
        next if $keys{$n} || $left-names{$n};
        @sel.push: 'r.' ~ quote-ident($n) ~ ' AS ' ~ quote-ident($n);
    }
    my Str $on = @keys.map({
        'l.' ~ quote-ident($_) ~ ' = r.' ~ quote-ident($_)
    }).join(' AND ');

    'SELECT ' ~ @sel.join(', ') ~ ' FROM (' ~ $lsql ~ ') AS l'
      ~ ' FULL OUTER JOIN (' ~ $rsql ~ ') AS r ON ' ~ $on;
}
