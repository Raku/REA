use v6.d;
use DB::DuckDB;
use Duckula::X::Frame;

#| DB::DuckDB 的 `%NAME` 映射里没有这两个 tid，`ColumnView.type` 都会回落成
#| `'UNKNOWN'`，所以只能按 tid 判断。
#|   ARRAY(33)：`to-list(:typed)` 能给真值（和 LIST 一样）
#|   UNION(28)：`at()` / `to-list(:typed)` 都给 Any —— ColumnView 层拿不到值
my constant TID-UNION = 28;
my constant TID-ARRAY = 33;

#| DuckDB ColumnView 类型 → 解码目标：
#|   0 = 原样（已经是 Raku 原生或不需要转换）
#|   1 = Int（HUGEINT / BIGINT / INTEGER / SMALLINT / TINYINT + 无符号版）
#|   2 = Rat（DECIMAL / NUMERIC）
#|   3 = 嵌套（LIST / ARRAY / STRUCT / MAP / ENUM）——
#|       需要 DB::DuckDB 1.4.0 的 ColumnView.to-list(:typed) 拿真值
#|   4 = UNION —— ColumnView 层解不了，取值时明确报错而不是静默回 NULL
sub type-decode-kind(Str $t-raw, Int $tid = 0 --> Int) is export {
    my Str $t = $t-raw.uc;

    # 先看 tid：ARRAY / UNION 的 type 名都是 'UNKNOWN'，靠前缀判断会漏，
    # 漏掉的后果是 ARRAY 静默变文本、UNION 静默变 NULL。
    return 4 if $tid == TID-UNION;
    return 3 if $tid == TID-ARRAY;

    if $t.starts-with('LIST') || $t.starts-with('ARRAY')
       || $t.starts-with('STRUCT') || $t.starts-with('MAP')
       || $t.starts-with('UNION')  || $t.starts-with('ENUM') {
        return 3;   # 嵌套：DB::DuckDB 1.4.0 ColumnView.to-list(:typed) 给真值
    }

    if $t.starts-with('DECIMAL') || $t.starts-with('NUMERIC') {
        return 2;   # Rat
    }

    # 整数族：HUGEINT / BIGINT / INTEGER / INT4 / SMALLINT / TINYINT
    # + 各自无符号版（UHUGEINT / UBIGINT / UINTEGER / USMALLINT / UTINYINT）
    if $t.starts-with('UHUGEINT') || $t.starts-with('UBIGINT')
       || $t.starts-with('UINTEGER') || $t.starts-with('USMALLINT')
       || $t.starts-with('UTINYINT')
       || $t eq 'HUGEINT' || $t eq 'BIGINT' || $t eq 'INTEGER'
       || $t eq 'INT4' || $t eq 'SMALLINT' || $t eq 'TINYINT' {
        return 1;   # Int
    }

    return 0;   # 原样（VARCHAR / TIMESTAMP / BOOLEAN / DOUBLE / REAL / ...）
}

#| 单值解码 —— HUGEINT/DECIMAL 列的 ColumnView.at() / to-list() 对
#| 负值仍返回字符串（DB::DuckDB 1.3.1 补码扩展修了内部表示，解码层没改）。
#| 这里把合法数字字符串还原成 Raku 原生类型，已经是原生类型的（BIGINT at()
#| 返回 Int）直接透传。
sub val-decode($raw, Int $kind --> Mu) is export {
    return $raw unless $raw.defined;
    return $raw unless $kind.defined && $kind ~~ Int;
    return $raw if $kind == 0;
    return $raw if $raw !~~ Str;   # 已经是 Raku 原生类型

    if $kind == 2 {
        # Rat：DECIMAL / NUMERIC 字符串
        $raw ~~ /^ '-'? \d+ ['.' \d+]? $/ ?? $raw.Rat !! $raw
    } else {
        # Int：HUGEINT 等整数类字符串
        $raw ~~ /^ '-'? \d+ $/ ?? $raw.Int !! $raw
    }
}

#| 整列解码 —— 给 Frame.!rows-from-views / Series.to-list 批量用。
#|
#| 重要：**不随便调 `.List`** —— DB::DuckDB 的 ColumnView.to-list 已经返回
#| List 了，再调一次 `.List` 会变成 Seq.List（`.raku` 输出带 `$`），
#| 导致和原始 Series.to-list 返回值类型不一致。
sub column-decode($view --> List) is export {
    my Str $t = ($view.type // '').Str;
    my Int $kind = type-decode-kind($t, $view.tid);

    # UNION：ColumnView 的 at()/to-list(:typed) 都给 Any，拿不到值。
    # 静默返回一列 NULL 比报错更危险，所以这里明确拒绝；用户可以在 SQL 里
    # `union_value(...)::VARCHAR` 或 cast 成 JSON 后再进来。
    die Duckula::X::Frame.new(
        reason => 'UNION columns cannot be decoded through ColumnView '
                ~ '(DB::DuckDB returns NULL for every value). '
                ~ 'Cast the column to VARCHAR or JSON in SQL first.'
    ) if $kind == 4;

    # 嵌套类型（LIST/ARRAY/STRUCT/MAP/ENUM）—— DB::DuckDB 1.4.0
    # 的 ColumnView.to-list(:typed) 返回真值（List/Hash）。
    if $kind == 3 {
        return $view.to-list(:typed);
    }

    # 原样透传（VARCHAR / TIMESTAMP / BOOLEAN / DOUBLE / REAL / BIGINT / ...）
    return $view.to-list if $kind == 0;

    # 数值需要解码（HUGEINT / DECIMAL）—— view.to-list 对这些列仍返回 Str
    my $vals = $view.to-list;
    $vals.map(-> $x { val-decode($x, $kind) }).List;
}
