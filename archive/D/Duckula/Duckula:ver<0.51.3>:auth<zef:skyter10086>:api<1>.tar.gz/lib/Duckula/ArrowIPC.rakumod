use v6.d;
need Arrow::IPC::Write;
need Arrow::IPC::Format;
use Duckula::X::Frame;

#| Arrow IPC 写侧的兼容适配。真正的 FlatBuffers 编解码在 Arrow::IPC 包里，
#| 这里只保留 Duckula 原有的调用签名，避免破坏已有代码。
unit module Duckula::ArrowIPC;

our sub parse-format(Str:D $f --> Hash) is export {
    Arrow::IPC::Format::parse-format($f)
}
our sub write-ipc($arrow, Str:D $path, Str:D :$format = 'file' --> Nil) is export {
    # 先校验再碰文件：底层是"先截断目标文件、再校验 format"，非法值会把
    # 已有文件清成 0 字节。这里提前拒绝，并改用临时文件 + 改名，编码中途
    # 失败也不会留下半截文件。
    die Duckula::X::Frame.new(
        reason => "arrow-ipc: unknown format '$format' (expected file or stream)"
    ) unless $format eq 'file' || $format eq 'stream';

    my Str $tmp;
    LEAVE $tmp.IO.unlink if $tmp.defined && $tmp.IO.e;
    $tmp = "$path.tmp-{$*PID}";
    Arrow::IPC::Write::write-ipc($arrow, $tmp, :$format);
    $path.IO.unlink if $path.IO.e;
    $tmp.IO.move($path);
}
our sub ipc-buf($arrow, Str:D :$format = 'stream' --> Buf) is export {
    Arrow::IPC::Write::ipc-buf($arrow, :$format)
}
