use v6.d;

# ============================================================
# 计划树
# ============================================================
#
# 为什么不直接拼 SQL 字符串（`Frame` 现在就是这么干的）：
#
#   每一次算子都写 `SELECT * FROM (<上一步>) WHERE ...`，链式十步就是十层
#   子查询。DuckDB 的优化器当然吃得下，但 `$df.relation-sql` 越来越不可读、
#   写进日志没法看、给人 review 更没法看。
#
# 计划树保留「做了什么」而不是「怎么写的」，`collect` 时才一次渲染。相邻的
# `filter` 会合并进同一个 `WHERE`，`filter` 和 `group-by` 也待在同一层
# —— 这两件事正是层层套娃的主要来源。
#
# 渲染的产物是一个 `Query`（一个还没闭合的 SELECT 的各子句），自底向上累积：
# 能往当前层塞就塞（WHERE / GROUP BY / ORDER BY / LIMIT），塞不进去
# （当前层已经投影过或分过组）才把当前层物化成子查询。
#
# 注意：本文件里所有「一列值」的属性都声明成**标量**（`$.items` 而不是
# `@.items`）。`@`-sigil 属性在 `new` 里收到一个 List 会被 itemize 成
# `((...),)`，`@!items.elems` 于是永远等于 1 —— 这个坑在建树第一版就把聚合
# 投影拼成了 `"g" AS "g" sum("v") AS "s"`（少了逗号）。

#| 渲染时给子查询起的别名序号。全局单调递增，同一棵树里不会重名。
my $alias-seq = 0;
my sub next-alias(--> Str) { '__duckula_q' ~ (++$alias-seq) }

# ---------------------------------------------------------------- 节点

#| 计划节点基类：描述「在输入之上做一件事」。
class Duckula::Plan is export {
    has $.input;

    method kind(--> Str) { 'plan' }

    method kids(--> List) { $!input.defined ?? ($!input,) !! () }

    method describe(--> Str) { self.kind }
}

#| 叶子：一条已经成型的 SQL（读文件、`values (...)`、用户 `sql()` 的产物）。
#| `params` 是这条 SQL 里的 `?` 要绑的值，渲染时原样带走。
class Duckula::Plan::Source is Duckula::Plan is export {
    has Str $.sql is required;
    has $.params = ();
    #| 这条 SQL 依赖的临时视图（Duckula::ViewRef）。计划树被派生 Frame 共享，
    #| 持有者随计划对象一起存亡 —— 引用计数归零后视图才允许被 drop-views 删。
    has $.view-holder;

    method kind(--> Str) { 'source' }

    method describe(--> Str) {
        my Str $s = $!sql.subst(/\s+/, ' ', :g).trim;
        'source   ' ~ ($s.chars > 64 ?? $s.substr(0, 64) ~ '…' !! $s);
    }
}

#| 投影：`items` 是已经渲染好的 `expr AS "name"` 片段列表。
#|
#| `anchored` 打开时是「窗口投影」：窗口算子会改变输出行序，必须在内层先钉
#| 行号、外层再排回去（见 ARCHITECTURE §8.9）。`exclude` 是覆盖同名列时要
#| 先从 `*` 里剔掉的名字。
class Duckula::Plan::Project is Duckula::Plan is export {
    has $.items = ();
    has Bool $.anchored = False;
    has Str $.exclude = '';
    has Str $.anchor = '__duckula_ord';

    method kind(--> Str) { 'project' }

    method describe(--> Str) {
        my Str $tail = $!anchored ?? '  (窗口，带行号锚定)' !! '';
        "project  {@($!items).elems} 项$tail";
    }
}

#| 过滤：谓词是裸写的 SQL 片段（列名由调用方过白名单，值走 `?` 绑定）。
class Duckula::Plan::Filter is Duckula::Plan is export {
    has Str $.pred is required;
    has $.params = ();

    method kind(--> Str) { 'filter' }

    method describe(--> Str) { 'filter   ' ~ $!pred }
}

#| 聚合：`items` 是输出投影（键 + 聚合），`group` 是分组键。
#| `group` 为空就是全表聚合。
class Duckula::Plan::Aggregate is Duckula::Plan is export {
    has $.items = ();
    has $.group = ();

    method kind(--> Str) { 'aggregate' }

    method describe(--> Str) {
        @($!group).elems
            ?? 'aggregate 按 ' ~ @($!group).join(', ')
            !! 'aggregate 全表';
    }
}

#| 排序：`order` 是 `"col"` / `"col" DESC` 这样的片段列表。
class Duckula::Plan::Sort is Duckula::Plan is export {
    has $.order = ();

    method kind(--> Str) { 'sort' }

    method describe(--> Str) { 'sort     ' ~ @($!order).join(', ') }
}

#| 截断。`offset` 为 0 时只输出 LIMIT。
class Duckula::Plan::Limit is Duckula::Plan is export {
    has Int $.limit;
    has Int $.offset;

    method kind(--> Str) { 'limit' }

    method describe(--> Str) {
        my @bits;
        @bits.push: 'limit ' ~ $!limit if $!limit.defined;
        @bits.push: 'offset ' ~ $!offset if $!offset.defined && $!offset != 0;
        'limit    ' ~ @bits.join(' ');
    }
}

#| 连接。二元节点，所以不用基类的 `$.input`。
#|
#| `mode` 取 join（inner/left/right/full）、cross、exists（semi/anti）——
#| 三种形态要拼的 SQL 结构完全不同，所以在建树时就分开，而不是渲染时再判断。
class Duckula::Plan::Join is Duckula::Plan is export {
    has $.left is required;
    has $.right is required;
    has Str $.mode is required;
    has Str $.join-sql = '';
    has Str $.exists-sql = '';
    has Str $.on-sql = '';
    has $.items = ();

    method kind(--> Str) { 'join' }

    method kids(--> List) { ($!left, $!right) }

    method describe(--> Str) {
        my Str $how = $!mode eq 'exists' ?? $!exists-sql
                    !! $!mode eq 'cross'  ?? 'CROSS JOIN'
                    !! $!join-sql;
        'join     ' ~ $how ~ ($!on-sql eq '' ?? '' !! '  on ' ~ $!on-sql);
    }
}

# ---------------------------------------------------------------- 渲染

#| 一个还没闭合的 SELECT：各子句分开存，最后一次性拼成一条语句。
class Duckula::Plan::Query is export {
    has Str $.from is required;
    has $.select = ();   # 空 = `*`
    has $.where = ();
    has $.group = ();
    has $.order = ();
    has $.limit;
    has $.offset;
    has $.params = ();

    #| 原始 SQL（只有 Source 会给）。当这一层没挂任何子句时直接原样输出，
    #| 于是「只 scan 了一步」的计划渲染出来就是那条原始 SQL，不会平白多一层
    #| `SELECT * FROM (…)`。
    has Str $.passthrough;

    #| 已经投影过 / 分过组 / 截过：再往这一层塞 WHERE / ORDER BY 就会改变
    #| 语义 —— SQL 执行顺序是 FROM → WHERE → GROUP BY → ORDER BY → LIMIT，
    #| LIMIT 之后再来的 WHERE 会变成"先 WHERE 后 LIMIT"，把全表筛完再取 N 行。
    #| 所以 limit/offset 也必须是屏障。
    method locked(--> Bool) {
        @($!select).elems > 0 || @($!group).elems > 0
        || $!limit.defined || $!offset.defined
    }

    method !has-clauses(--> Bool) {
        @($!select).elems || @($!where).elems || @($!group).elems
            || @($!order).elems || $!limit.defined || $!offset.defined;
    }

    #| 这一层什么都没加，就是那条原始 SQL。
    method bare(--> Bool) { $!passthrough.defined && !self!has-clauses }

    method render(--> Str) {
        return $!passthrough if self.bare;

        my Str $s = 'SELECT ' ~ (@($!select).elems ?? @($!select).join(', ') !! '*')
                  ~ ' FROM ' ~ $!from;
        $s ~= ' WHERE '    ~ @($!where).join(' AND ') if @($!where).elems;
        $s ~= ' GROUP BY ' ~ @($!group).join(', ')    if @($!group).elems;
        $s ~= ' ORDER BY ' ~ @($!order).join(', ')    if @($!order).elems;
        $s ~= ' LIMIT '    ~ $!limit                  if $!limit.defined;
        $s ~= ' OFFSET '   ~ $!offset                 if $!offset.defined && $!offset != 0;
        $s;
    }
}

#| 把一层物化成子查询：它的 SQL 全部进 FROM，参数照原顺序带上去。
#| 参数顺序能保持，是因为子查询的 SQL 总排在外层子句之前。
my sub materialize(Duckula::Plan::Query $q --> Duckula::Plan::Query) {
    Duckula::Plan::Query.new(
        from   => '(' ~ $q.render ~ ') AS ' ~ next-alias,
        params => $q.params.List,
    );
}

multi sub plan-query(Duckula::Plan::Source $p --> Duckula::Plan::Query) {
    Duckula::Plan::Query.new(
        from        => '(' ~ $p.sql ~ ') AS ' ~ next-alias,
        passthrough => $p.sql,
        params      => $p.params.List,
    );
}

multi sub plan-query(Duckula::Plan::Project $p --> Duckula::Plan::Query) {
    my $q = plan-query($p.input);
    my Str $items = @($p.items).join(', ');

    if $p.anchored {
        # 窗口投影：内层钉扫描序行号 → 算窗口 → 外层按行号排回去。
        # 不走 Query 累积，因为这一层必须严格是这个三层形状（§8.9）。
        my Str $rn = $p.anchor;
        my Str $head = $p.exclude eq ''
            ?? 'SELECT *, '
            !! 'SELECT * EXCLUDE (' ~ $p.exclude ~ '), ';

        return Duckula::Plan::Query.new(
            from   => '(' ~ $head ~ $items
                    ~ ' FROM (SELECT *, row_number() OVER () AS ' ~ $rn
                    ~ ' FROM (' ~ $q.render ~ ') AS __duckula_win_src) AS __duckula_win'
                    ~ ') AS __duckula_win_out',
            select => ('* EXCLUDE (' ~ $rn ~ ')',),
            order  => ($rn,),
            params => $q.params.List,
        );
    }

    #| Project 叠在 Sort 之上时也必须物化：DuckDB 里裸列引用的 ORDER BY
    #| 会优先绑定到 SELECT 的输出别名，若这一层同时改了列名/值（cast、
    #| fill-nulls、with-column），内层 `ORDER BY "v"` 就会排到「新 v」上，
    #| 排序键被悄悄换掉。Filter 合到 Sort 层是安全的，所以不能把 order
    #| 塞进 locked()，只在这里和 Aggregate 一样单独判断。
    $q = materialize($q) if $q.locked || @($q.order).elems;

    Duckula::Plan::Query.new(
        from   => $q.from,
        select => $p.items.List,
        where  => $q.where.List,
        group  => $q.group.List,
        order  => $q.order.List,
        limit  => $q.limit,
        offset => $q.offset,
        params => $q.params.List,
    );
}

multi sub plan-query(Duckula::Plan::Filter $p --> Duckula::Plan::Query) {
    my $q = plan-query($p.input);
    $q = materialize($q) if $q.locked;

    Duckula::Plan::Query.new(
        from   => $q.from,
        select => $q.select.List,
        where  => (|$q.where.List, $p.pred),
        group  => $q.group.List,
        order  => $q.order.List,
        limit  => $q.limit,
        offset => $q.offset,
        params => (|$q.params.List, |$p.params.List),
    );
}

multi sub plan-query(Duckula::Plan::Aggregate $p --> Duckula::Plan::Query) {
    my $q = plan-query($p.input);

    # WHERE 能合并（这正是计划树最值的地方：filter + group-by 待在同一层），
    # 但投影 / 分组 / 排序 / 截断都不行 —— 聚合必须在它们之后。
    # 现在 limit/offset 也加进 locked 了，这里只额外看 order（Sort 必须在
    # Aggregate 外层，ORDER BY 在 GROUP BY 之后是 SQL 语法决定的）。
    $q = materialize($q) if $q.locked || @($q.order).elems;

    Duckula::Plan::Query.new(
        from   => $q.from,
        select => $p.items.List,
        where  => $q.where.List,
        group  => $p.group.List,
        params => $q.params.List,
    );
}

multi sub plan-query(Duckula::Plan::Sort $p --> Duckula::Plan::Query) {
    my $q = plan-query($p.input);
    my @inner = @($q.order).List;

    # 同一层只能有一个 ORDER BY，但这不代表要丢掉内层排序键：
    # `sort(g).sort(v)` 的语义是"主键 v、次键 g"（稳定排序）。把内层键
    # 接在外层后面即可；前提是两层在同一层（没有被投影/分组/截断隔开）。
    # 隔开时必须物化，否则内层的列名在外层可能已经不存在。
    my Bool $same-layer = !$q.locked;
    # LIMIT/OFFSET 必须物化（否则排序会作用到截断之前的全表）；
    # 有内层排序键且被投影/分组隔开时也要物化，保证列名可见。
    $q = materialize($q)
        if $q.locked && ($q.limit.defined || $q.offset.defined || @inner.elems);
    my @order = $same-layer ?? (|$p.order.List, |@inner) !! $p.order.List;

    Duckula::Plan::Query.new(
        from   => $q.from,
        select => $q.select.List,
        where  => $q.where.List,
        group  => $q.group.List,
        order  => @order,
        params => $q.params.List,
    );
}

multi sub plan-query(Duckula::Plan::Limit $p --> Duckula::Plan::Query) {
    my $q = plan-query($p.input);
    $q = materialize($q) if $q.limit.defined || $q.offset.defined;

    Duckula::Plan::Query.new(
        from   => $q.from,
        select => $q.select.List,
        where  => $q.where.List,
        group  => $q.group.List,
        order  => $q.order.List,
        limit  => $p.limit,
        offset => $p.offset,
        params => $q.params.List,
    );
}

multi sub plan-query(Duckula::Plan::Join $p --> Duckula::Plan::Query) {
    my $l = plan-query($p.left);
    my $r = plan-query($p.right);
    my List $params = (|$l.params.List, |$r.params.List);

    if $p.mode eq 'exists' {
        return Duckula::Plan::Query.new(
            from   => '(' ~ $l.render ~ ') AS l',
            where  => ($p.exists-sql ~ ' (SELECT 1 FROM (' ~ $r.render
                       ~ ') AS r WHERE ' ~ $p.on-sql ~ ')',),
            params => $params,
        );
    }

    my Str $from = '(' ~ $l.render ~ ') AS l '
                 ~ ($p.mode eq 'cross' ?? 'CROSS JOIN' !! $p.join-sql)
                 ~ ' (' ~ $r.render ~ ') AS r';
    $from ~= ' ON ' ~ $p.on-sql if $p.mode ne 'cross';

    Duckula::Plan::Query.new(
        from   => $from,
        select => $p.items.List,
        params => $params,
    );
}

# ---------------------------------------------------------------- 构造

sub plan-source(Str:D $sql, *@params, :$view-holder --> Duckula::Plan::Source) is export {
    Duckula::Plan::Source.new(:$sql, params => @params.List, :$view-holder);
}

sub plan-filter(Duckula::Plan:D $p, Str:D $pred, *@params --> Duckula::Plan) is export {
    # 相邻 filter 建树时就合并：`WHERE a AND b` 比两层子查询干净得多，
    # 而且合并掉之后渲染器根本不用操心这件事。
    if $p ~~ Duckula::Plan::Filter {
        return Duckula::Plan::Filter.new(
            input  => $p.input,
            pred   => '(' ~ $p.pred ~ ') AND (' ~ $pred ~ ')',
            params => (|$p.params.List, |@params.List),
        );
    }

    Duckula::Plan::Filter.new(:input($p), :$pred, params => @params.List);
}

sub plan-project(
    Duckula::Plan:D $p,
    List :$items!,
    Bool :$anchored = False,
    Str :$exclude = '',
    Str :$anchor = '__duckula_ord',
    --> Duckula::Plan
) is export {
    Duckula::Plan::Project.new(
        :input($p), :$items, :$anchored, :$exclude, :$anchor
    );
}

sub plan-aggregate(Duckula::Plan:D $p, List :$items!, List :$group = () --> Duckula::Plan) is export {
    Duckula::Plan::Aggregate.new(:input($p), :$items, :$group);
}

sub plan-sort(Duckula::Plan:D $p, List :$order! --> Duckula::Plan) is export {
    Duckula::Plan::Sort.new(:input($p), :$order);
}

sub plan-limit(Duckula::Plan:D $p, Int $limit, Int $offset = 0 --> Duckula::Plan) is export {
    # 相邻 limit 合并：`LIMIT 10` 套 `LIMIT 5` 就是 `LIMIT 5`。
    # 不合并的话渲染器会把内层物化成子查询，白白多一层。
    if $p ~~ Duckula::Plan::Limit {
        my Int $skip = ($p.offset // 0) + $offset;
        my $take = $limit;

        if $p.limit.defined {
            my Int $left = $p.limit - $offset;
            $take = $left <= 0 ?? 0 !! min($limit, $left);
        }

        return Duckula::Plan::Limit.new(input => $p.input, limit => $take, offset => $skip);
    }

    Duckula::Plan::Limit.new(:input($p), :$limit, :$offset);
}

# ---------------------------------------------------------------- 出口

#| 渲染成 (SQL, 参数)。参数顺序与 SQL 里 `?` 的出现顺序一致。
sub compile-plan(Duckula::Plan:D $p --> List) is export {
    my $q = plan-query($p);
    ($q.render, $q.params.List);
}

#| 只渲染 SQL（调试用；真要执行请用 compile-plan，否则参数会丢）。
sub render-plan(Duckula::Plan:D $p --> Str) is export {
    plan-query($p).render;
}

#| 计划树的可读文本，给 `explain` 用。
sub describe-plan(Duckula::Plan:D $p, Int $depth = 0 --> Str) is export {
    my Str $out = ('  ' x $depth) ~ $p.describe ~ "\n";
    for $p.kids -> $k {
        $out ~= describe-plan($k, $depth + 1);
    }
    $out;
}
