use v6.d;
use Duckula::SQL;
use Duckula::X::Guard;

#| 查询网关：SQL 送进 DuckDB 之前的最后一道检查。
#|
#| 三层防线的落点（ARCHITECTURE.md §9.5）：
#|   L1 值 -> 参数绑定（由调用方保证，这里校验 ? 的个数与参数个数一致）
#|   L2 标识符 -> quote-ident（在 Duckula::SQL）
#|   L3 整条 SQL -> 本模块：单语句 / 只读 / 无外部访问
unit module Duckula::Guard;

#| 占位符个数的统一报错。三个调用点文案一致。
my sub check-params(Int $want, Int $found, Str $lead --> Nil) {
    return if $found == $want;
    die Duckula::X::Guard.new(
        reason => "placeholder mismatch: $lead $found '?' but $want "
                ~ 'parameter(s) were bound; pass values as bind parameters '
                ~ 'instead of interpolating them into the SQL text'
    );
}

#| 校验一条即将执行的 SQL。
#|
#|   $conn         给了就用 DuckDB 的解析器判定（推荐，见下）
#|   $params       期望绑定的参数个数
#|   :$strict      是否强制只读语义，默认 True
#|   :$allow-multi 是否允许多语句，默认 False
#|
#| 有 `$conn` 时判定来自 `duckdb_extract_statements` +
#| `duckdb_prepared_statement_type`，看到的是 DuckDB 自己解析出来的语句类型，
#| 不是文本猜测。但仍然保留一层写动词扫描 —— 原因见 `check-parsed` 的注释。
#|
#| 没有 `$conn` 时退回文本启发式。那种模式只适合做「大概安全吗」的自查，
#| 不适合守门：它会把 `PRAGMA database_list` 这种只读语句一起拒掉。
our sub check-sql(
    Str:D $sql,
    Int :$params = 0,
    Bool :$strict = True,
    Bool :$allow-multi = False,
    :$conn,
    --> Nil
) is export {
    die Duckula::X::Guard.new(reason => 'empty SQL statement')
        unless so $sql.trim.chars;

    if $conn.defined && $conn.^can('classify-sql') {
        check-parsed($conn, $sql, :$params, :$strict, :$allow-multi);
        return;
    }

    my Int $stmts = statement-count($sql);
    if !$allow-multi && $stmts > 1 {
        die Duckula::X::Guard.new(
            reason => "multiple statements are not allowed (found $stmts); "
                    ~ "split them and call again"
        );
    }

    if $strict && !is-readonly-sql($sql) {
        die Duckula::X::Guard.new(
            reason => 'statement is not read-only; pass :!strict or use a write API'
        );
    }

    check-params($params, placeholder-count($sql), 'SQL has');
}

#| 用 DuckDB 自己的解析结果判定。两关，缺一不可。
#|
#| 第一关看**语句类型**（`duckdb_statement_type`）：SELECT / EXPLAIN 之外的
#| 一律拒。这一关把 `INSTALL`、`ATTACH`、`COPY`、`PRAGMA enable_profiling`
#| （类型是 SET）、多语句、`$$` 之类的花样一并解决 —— 全是解析器给的答案，
#| 不依赖正则猜得到什么。
#|
#| 第二关扫**写动词**。因为类型会撒谎：`WITH d AS (DELETE FROM t RETURNING *)
#| SELECT * FROM d` 的顶层类型是 **SELECT**，`EXPLAIN ANALYZE DELETE FROM t`
#| 的类型是 **EXPLAIN** —— 两条都会真的改数据。只看类型就放行了。
#|
#| 两关都是「拒绝优先」：任何一关判危险就拒。
my sub check-parsed(
    $conn,
    Str:D $sql,
    Int :$params,
    Bool :$strict,
    Bool :$allow-multi,
    --> Nil
) {
    my @stmts = $conn.classify-sql($sql);

    if !$allow-multi && @stmts.elems > 1 {
        die Duckula::X::Guard.new(
            reason => "multiple statements are not allowed (found {+@stmts}); "
                    ~ 'split them and call again'
        );
    }

    if $strict {
        # 编译不过的语句拿不到类型，只能拒 —— 但要把 DuckDB 的原话带出去，
        # 否则「表名打错」会被误读成「被安全策略拦下」。
        #
        # 非严格模式跳过这一条：用户已经明说「我知道这是写操作」，此时拦下来
        # 只会拦住一条本来就要报错的 SQL（执行时 DuckDB 自己会说），拿不到
        # 类型不代表不安全。
        for @stmts -> $st {
            next if $st.prepared;
            die Duckula::X::Guard.new(
                reason => "cannot prepare statement: {$st.error // 'unknown reason'}"
            );
        }

        for @stmts -> $st {
            next if $st.read-only;
            die Duckula::X::Guard.new(
                reason => "statement is not read-only (DuckDB parsed it as "
                        ~ "{$st.type}); pass :!strict or use a write API"
            );
        }

        if has-write-keyword($sql) {
            die Duckula::X::Guard.new(
                reason => 'statement hides a write where the statement type does not '
                        ~ 'show it (e.g. `WITH d AS (DELETE ... RETURNING *) SELECT ...`, '
                        ~ 'or `EXPLAIN ANALYZE DELETE ...` which really runs); '
                        ~ 'pass :!strict or use a write API'
            );
        }
    }

    check-params($params, ([+] @stmts.map(*.params)), 'SQL has');

    CATCH {
        when Duckula::X::Guard { .rethrow }
        default {
            die Duckula::X::Guard.new(
                reason => "cannot parse SQL: {.message}"
            );
        }
    }
}

#| 校验一段 SQL **片段**（谓词、投影表达式），不是完整语句。
#|
#| 与 check-sql 的区别：片段不是完整语句，DuckDB 的解析器无从下手，
#| 所以这里仍然走文本层——不许夹带多条语句，占位符必须和实参对齐。
#| 「只读」由调用方保证：片段最终会被拼进 `SELECT ... WHERE <片段>`。
our sub check-fragment(Str:D $sql, Int :$params = 0 --> Nil) is export {
    die Duckula::X::Guard.new(reason => 'empty SQL fragment')
        unless so $sql.trim.chars;

    my Int $stmts = statement-count($sql);
    if $stmts > 1 {
        die Duckula::X::Guard.new(
            reason => "fragment contains $stmts statements; "
                    ~ 'only a single expression is allowed'
        );
    }

    check-params($params, placeholder-count($sql), 'fragment has');
}

#| 给连接打开沙箱。切断 DuckDB 的文件读写、网络访问与扩展安装：
#|   read_csv('/etc/passwd') / COPY ... TO / ATTACH 'http://...' / INSTALL ...
our sub apply-sandbox($conn, Bool :$allow-external = False --> Nil) is export {
    return if $allow-external;
    $conn.execute('SET enable_external_access=false');
}
