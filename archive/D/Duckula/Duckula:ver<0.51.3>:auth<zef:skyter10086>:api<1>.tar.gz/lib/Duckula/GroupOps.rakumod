use v6.d;
use Duckula::SQL;
use Duckula::Reshape;
use Duckula::X::Frame;

#| 分组糖的 SQL 构件（v0.24.0）：crosstab / pivot-table。
#|
#| 和 Reshape 里的 `pivot-sql` 一样走条件聚合，不用 DuckDB 原生 PIVOT ——
#| 后者被语句分类器判成 MULTI，过不了只读守卫（§8.17）。这里多两件事：
#| crosstab 的归一化，和 pivot-table 的 fill-value / margins。
#|
#| 列名来自数据（分组值），所以要先 DISTINCT 取回来；调用方负责这一步
#| （`pivot-keys`）。所有数据值都以 sql-literal 进 SQL，列名过 quote-ident，
#| 聚合函数名过 check-agg 白名单 —— 延续 §9 的防注入模型。

my constant %NORMALIZE = set <all index columns>;

our sub check-normalize(Str:D $how --> Str) is export {
    my Str $h = $how.trim.lc;
    return $h if $h eq '' || %NORMALIZE{$h};
    die Duckula::X::Frame.new(
        reason => "crosstab: unknown normalize '$how'; expected "
                ~ "'all', 'index', 'columns' or ''"
    );
}

my sub cell-name($k --> Str) {
    $k.defined ?? $k.Str !! 'NULL';
}

my sub cell-pred($col-q, $k --> Str) {
    $k.defined ?? "= " ~ sql-literal($k) !! 'IS NULL';
}

#| 频率交叉表（pandas.crosstab）。
#|
#|   $row / $col 是列名；@keys 是该列 DISTINCT 出来的分组值；
#|   $values 未给时按「每行计 1」做频率表，给了就做 `$agg(value)` 的加权表。
#|
#| normalize 在**外层**做：先出交叉表，再对外层的结果套窗口求和。直接把
#| `sum(...) OVER ()` 写进内层会和 GROUP BY 的聚合混在一起，语义和语法都乱。
our sub crosstab-sql(
    Str:D $rel,
    Str:D $row,
    Str:D $col,
    @keys,
    Str :$normalize = '',
    :$fill-value,
    :$values,
    Str :$agg = 'count',
    --> Str
) is export {
    my Str $how = check-normalize($normalize);
    my Str $row-q = quote-ident($row);
    my Str $col-q = quote-ident($col);
    my Str $a = check-agg($agg);

    my @items = $row-q;
    for @keys -> $k {
        my Str $pred = cell-pred($col-q, $k);
        my Str $cell = $values.defined
            ?? "{$a}(CASE WHEN $col-q $pred THEN " ~ quote-ident($values.Str) ~ ' END)'
            !! "count(CASE WHEN $col-q $pred THEN 1 END)";
        $cell = 'coalesce(' ~ $cell ~ ', ' ~ sql-literal($fill-value) ~ ')'
            if $fill-value.defined;
        @items.push: $cell ~ ' AS ' ~ quote-ident(cell-name($k));
    }

    my Str $base = 'SELECT ' ~ @items.join(', ')
                 ~ ' FROM (' ~ $rel ~ ') AS __duckula_ct_src'
                 ~ ' GROUP BY ' ~ $row-q
                 ~ ' ORDER BY ' ~ $row-q;
    return $base if $how eq '' || !@keys.elems;

    my @cols = @keys.map({ quote-ident(cell-name($_)) }).List;
    my Str $row-sum = @cols.join(' + ');
    my Str $total = @cols.map({ 'sum(' ~ $_ ~ ') OVER ()' }).join(' + ');

    my @out = $row-q;
    for @keys -> $k {
        my Str $q = quote-ident(cell-name($k));
        my Str $den = $how eq 'index' ?? $row-sum
                    !! $how eq 'columns' ?? 'sum(' ~ $q ~ ') OVER ()'
                    !! $total;
        @out.push: "coalesce($q / nullif($den, 0), 0) AS $q";
    }

    'SELECT ' ~ @out.join(', ') ~ ' FROM (' ~ $base ~ ') AS __duckula_ct_norm'
      ~ ' ORDER BY ' ~ $row-q;
}

#| 聚合透视（pandas.pivot_table）。
#|
#| 和 `pivot-sql` 的区别是 pandas 风格默认值：`mean` 而不是 `sum`，
#| 支持 fill-value，和 margins（行/列/全表合计，走 GROUPING SETS）。
#|
#| margins 时 index 列在合计行是 NULL，用 `coalesce(CAST(... AS VARCHAR), 'All')`
#| 补成 'All'，和 pandas 一致；代价是 index 列的类型会变成字符串。
our sub pivot-table-sql(
    Str:D $rel,
    @index,
    Str:D $on,
    @keys,
    @values,
    Str:D $agg,
    Bool :$margins = False,
    :$fill-value,
    --> Str
) is export {
    my Str $on-q = quote-ident($on);
    my @items = @index.map({ quote-ident($_) }).List;

    for @keys -> $k {
        my Str $pred = cell-pred($on-q, $k);
        for @values -> $v {
            my Str $name = @values.elems == 1
                ?? cell-name($k)
                !! "{$v}_{cell-name($k)}";
            my Str $cell = "{$agg}(CASE WHEN $on-q $pred THEN " ~ quote-ident($v.Str) ~ ' END)';
            $cell = 'coalesce(' ~ $cell ~ ', ' ~ sql-literal($fill-value) ~ ')'
                if $fill-value.defined;
            @items.push: $cell ~ ' AS ' ~ quote-ident($name);
        }
    }

    if $margins {
        for @values -> $v {
            my Str $name = @values.elems == 1 ?? 'All' !! "{$v}_All";
            my Str $cell = "{$agg}(" ~ quote-ident($v.Str) ~ ')';
            $cell = 'coalesce(' ~ $cell ~ ', ' ~ sql-literal($fill-value) ~ ')'
                if $fill-value.defined;
            @items.push: $cell ~ ' AS ' ~ quote-ident($name);
        }
        # 总计行的 index 是 NULL：cast 成 VARCHAR 才能和 'All' 共存。
        # index 投影项就在 @items 前段，逐个替换成 coalesce 形式。
        for ^@index.elems -> $i {
            my Str $q = quote-ident(@index[$i]);
            @items[$i] = "coalesce(CAST($q AS VARCHAR), 'All') AS $q";
        }
    }

    my Str $sql = 'SELECT ' ~ @items.join(', ')
                ~ ' FROM (' ~ $rel ~ ') AS __duckula_pt_src';
    if @index.elems {
        my Str $by = @index.map({ quote-ident($_) }).join(', ');
        if $margins {
            # 合计行放最后；不加 ORDER BY 时 GROUPING SETS 的行序不稳定。
            my Str $key-q = quote-ident(@index[0]);
            $sql ~= ' GROUP BY GROUPING SETS ((' ~ $by ~ '), ())'
                  ~ " ORDER BY (CASE WHEN $key-q IS NULL THEN 1 ELSE 0 END), " ~ $by;
        }
        else {
            $sql ~= ' GROUP BY ' ~ $by ~ ' ORDER BY ' ~ $by;
        }
    }
    $sql;
}
