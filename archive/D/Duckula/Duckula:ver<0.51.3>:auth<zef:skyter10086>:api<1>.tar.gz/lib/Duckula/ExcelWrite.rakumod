use v6.d;
use NativeCall;
use Duckula::X::Frame;

# zlib 的 crc32：CArray[int8] 指针 + 长度，返回 uLong。
#
# WHY 必须用 `Compress::Zlib::Raw` **自带**的那份 zlib，而不是系统库：
# 那个模块把 zlib 打包进了自己的 resources（`lib/<os>-<arch>/libz.so.1`），
# `inflateInit2_` / `inflate` 全部 `is native(&find-lib)` 指向它。如果这里
# 另外 dlopen 系统 libz，进程里就同时存在**两个独立的 zlib 实例**（实测
# `zlibVersion()` 一个回 1.4、一个回 1.3.1），`z_stream` 的 state 由其中一个
# 创建、被另一个解释 —— 小到 700 字节的 XML 也会 `Z_DATA_ERROR(-3)`。
#
# 这就是那条 `zef install .` 失败的根因：`use Duckula` 会把本模块带进来，
# 于是 `read-excel` 的解压立刻坏掉；单独 `use Duckula::ExcelRead` 却是好的
# （那时进程里只有 bundled 那份）。crc32 本身是无状态纯函数，用哪份都算得
# 对，问题只出在两份共存。
#
# 所以既不猜库文件路径、也不锁版本号：`Compress::Zlib::Raw` 自己就导出
# `crc32`，而且它的 native 绑定和 `inflate`/`inflateInit2` 指向同一份库
# （1.x 用系统 zlib、2.0 用 dist 里 bundled 的那份，各自天然同源）。
# 直接调它，进程里永远不会出现第二份 zlib，也就不用关心装的是哪个版本、
# 资源目录叫什么名字。空括号 = 只加载模块、不把一堆 deflate/inflate 符号
# 导进本文件（避免和我们自己的 `crc32` 撞名）。
use Compress::Zlib::Raw ();

#| 纯 Raku 的 XLSX 写出兜底（v0.27.0）。
#|
#| Windows 的 mingw 版 DuckDB 在官方扩展仓库里没有 `excel`，所以
#| `to-excel` 不能只靠 `COPY ... (FORMAT XLSX)`。这里生成一份最小的
#| OOXML 包：ZIP 用 method 0（stored，不压缩），因此不需要 zlib；CRC32
#| 自己算。字符串走 inlineStr，不写 sharedStrings，也不需要样式表。
#|
#| 产出的文件 openpyxl / Excel / DuckDB 的 read_xlsx 都能直接打开；
#| 不保留类型样式（日期按 Excel 序号或字符串写入，取决于源 SQL 的值）。
unit module Duckula::ExcelWrite;

my @CRC-TABLE = (^256).map(-> $i {
    my $c = $i;
    for ^8 {
        $c = ($c +& 1) ?? ((0xEDB88320 +^ ($c +> 1)) +& 0xFFFFFFFF) !! ($c +> 1);
    }
    $c +& 0xFFFFFFFF;
}).Array;

sub crc32-pure($buf --> Int) {
    my Int $c = 0xFFFFFFFF;
    for $buf.list -> $b {
        $c = @CRC-TABLE[($c +^ $b) +& 0xFF] +^ ($c +> 8);
        $c +&= 0xFFFFFFFF;
    }
    ($c +^ 0xFFFFFFFF) +& 0xFFFFFFFF;
}

# 纯 Raku 逐字节 CRC32 在 9MB 的 sheet XML 上要 35 秒——ZIP stored 模式下
# 这是导出的绝对瓶颈。zlib 的原生 crc32 只要 0.04 秒。用 nativecast 把
# Buf 直接当 CArray[int8] 指针传进去（零拷贝）；加载失败则退回纯 Raku。
my Bool $NATIVE-CRC = so try {
    my $probe = Buf.new(1, 2, 3);
    Compress::Zlib::Raw::crc32(0, nativecast(CArray[int8], $probe), $probe.elems);
    True;
};

sub crc32($buf --> Int) {
    return crc32-pure($buf) unless $NATIVE-CRC;
    Compress::Zlib::Raw::crc32(0, nativecast(CArray[int8], $buf), $buf.elems) +& 0xFFFFFFFF;
}

sub u16(Int:D $n --> Buf) {
    Buf.new($n +& 0xFF, ($n +> 8) +& 0xFF);
}

sub u32(Int:D $n --> Buf) {
    Buf.new($n +& 0xFF, ($n +> 8) +& 0xFF,
            ($n +> 16) +& 0xFF, ($n +> 24) +& 0xFF);
}

#| ZIP 的 DOS 时间固定成 1980-01-01 00:00:00，让输出字节可复现。
my constant $DOS-TIME = 0;
my constant $DOS-DATE = 0x0021;

sub xml-escape(Str:D $s --> Str) {
    $s.subst('&', '&amp;', :g)
      .subst('<', '&lt;', :g)
      .subst('>', '&gt;', :g)
      .subst('"', '&quot;', :g)
      .subst("'", '&apos;', :g);
}

#| XML 1.0 不允许的字符：直接写进 sheet1.xml 会让整个文件不是 well-formed
#| （DuckDB / ElementTree / Excel 全部拒收）。宁可当场报错，也不要产出一个
#| "写入成功但读不回来"的坏文件 —— 静默写坏文件比报错更难查。
my sub check-xml-chars(Str:D $s, Str:D $where --> Nil) {
    for $s.ords -> Int $o {
        next unless $o <= 0x08 || $o == 0x0B || $o == 0x0C
                 || (0x0E <= $o <= 0x1F) || $o == 0xFFFE || $o == 0xFFFF;
        die Duckula::X::Frame.new(
            reason => "$where contains control character U+"
                    ~ $o.fmt('%04X')
                    ~ " which XML 1.0 cannot represent; "
                    ~ 'strip or replace it before to-excel'
        );
    }
}

sub col-letter(Int:D $i --> Str) {
    my Str $s = '';
    my Int $n = $i + 1;
    while $n > 0 {
        my Int $r = ($n - 1) % 26;
        $s = ('A'.ord + $r).chr ~ $s;
        $n = ($n - 1) div 26;
    }
    $s;
}

sub clean-sheet(Str:D $name --> Str) {
    my Str $s = $name.trim;
    die Duckula::X::Frame.new(
        reason => 'sheet name cannot be empty'
    ) unless $s.chars;
    die Duckula::X::Frame.new(
        reason => 'sheet name cannot contain []:*?/\\'
    ) if $s ~~ /<[\[ \] \: \* \? \/ \\]>/;
    check-xml-chars($s, 'sheet name');
    $s.substr(0, 31);
}

sub cell-xml(Str:D $ref, $v --> Str) {
    return "<c r=\"$ref\"/>" unless $v.defined;
    # 注意用 {$v} 花括号插值：直接写 $v</v> 会被 Raku 解析成关联下标
    # $v{'/v'}，运行时报 "Str does not support associative indexing"。
    if $v ~~ Bool {
        return "<c r=\"$ref\" t=\"b\"><v>" ~ ($v ?? 1 !! 0) ~ "</v></c>";
    }
    if $v ~~ Int {
        return "<c r=\"$ref\"><v>{$v}</v></c>";
    }
    if $v ~~ Rat || $v ~~ Num {
        my Str $n = $v ~~ Rat ?? $v.Num.Str !! $v.Str;
        return "<c r=\"$ref\"><v>{$n}</v></c>";
    }
    my Str $text = $v.Str;
    check-xml-chars($text, "cell $ref");
    "<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">"
        ~ xml-escape($text) ~ "</t></is></c>";
}

sub sheet-xml(@names, @rows --> Str) {
    my @lines = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
        '<sheetData>';

    my Str $head = '<row r="1">';
    for @names.kv -> $i, $n {
        $head ~= cell-xml(col-letter($i) ~ '1', $n.Str);
    }
    @lines.push: $head ~ '</row>';

    for @rows.kv -> $ri, $row {
        my Int $r = $ri + 2;
        my Str $line = "<row r=\"$r\">";
        for @names.kv -> $ci, $n {
            my $v = $row ~~ Positional    ?? $row[$ci]
                 !! $row ~~ Associative ?? $row.{$n}
                 !! $row;
            $line ~= cell-xml(col-letter($ci) ~ $r, $v);
        }
        @lines.push: $line ~ '</row>';
    }

    @lines.push: '</sheetData>', '</worksheet>';
    @lines.join("\n");
}

sub workbook-xml(Str:D $sheet --> Str) {
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      ~ '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
      ~ 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
      ~ '<sheets><sheet name="' ~ xml-escape($sheet)
      ~ '" sheetId="1" r:id="rId1"/></sheets></workbook>';
}

my constant $CONTENT-TYPES =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    ~ '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    ~ '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    ~ '<Default Extension="xml" ContentType="application/xml"/>'
    ~ '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
    ~ '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
    ~ '</Types>';

my constant $ROOT-RELS =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    ~ '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    ~ '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
    ~ '</Relationships>';

my constant $WORKBOOK-RELS =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    ~ '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    ~ '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
    ~ '</Relationships>';

sub local-header($name, Int:D $crc, Int:D $size --> Buf) {
    my Buf $h = Buf.new(0x50, 0x4b, 0x03, 0x04);
    $h.append(u16(20));            # version needed
    $h.append(u16(0));             # flags
    $h.append(u16(0));             # stored
    $h.append(u16($DOS-TIME));
    $h.append(u16($DOS-DATE));
    $h.append(u32($crc));
    $h.append(u32($size));
    $h.append(u32($size));
    $h.append(u16($name.elems));
    $h.append(u16(0));             # extra
    $h.append($name);
    $h;
}

sub central-header($name, Int:D $crc, Int:D $size, Int:D $offset --> Buf) {
    my Buf $h = Buf.new(0x50, 0x4b, 0x01, 0x02);
    $h.append(u16(20));            # version made by
    $h.append(u16(20));            # version needed
    $h.append(u16(0));
    $h.append(u16(0));
    $h.append(u16($DOS-TIME));
    $h.append(u16($DOS-DATE));
    $h.append(u32($crc));
    $h.append(u32($size));
    $h.append(u32($size));
    $h.append(u16($name.elems));
    $h.append(u16(0));             # extra
    $h.append(u16(0));             # comment
    $h.append(u16(0));             # disk
    $h.append(u16(0));             # internal attrs
    $h.append(u32(0));             # external attrs
    $h.append(u32($offset));
    $h.append($name);
    $h;
}

#| 把若干 (路径, 内容) 打成一个 stored ZIP。
sub zip-store(@files --> Buf) {
    my Buf $body .= new;
    my Buf $cd .= new;
    my Int $offset = 0;

    for @files -> $entry {
        # utf8 是 Buf[uint8] 的子类，但类型约束 `Buf` 不接受它；
        # 去掉约束，后面的 append/u16/u32 都按字节流处理。
        my $name = $entry[0].encode('utf8');
        my $data = $entry[1].encode('utf8');
        my Int $crc = crc32($data);

        $body.append(local-header($name, $crc, $data.elems));
        $body.append($data);
        $cd.append(central-header($name, $crc, $data.elems, $offset));
        $offset += 30 + $name.elems + $data.elems;
    }

    my Buf $eocd = Buf.new(0x50, 0x4b, 0x05, 0x06);
    $eocd.append(u16(0));
    $eocd.append(u16(0));
    $eocd.append(u16(@files.elems));
    $eocd.append(u16(@files.elems));
    $eocd.append(u32($cd.elems));
    $eocd.append(u32($offset));
    $eocd.append(u16(0));

    my Buf $out .= new;
    $out.append($body);
    $out.append($cd);
    $out.append($eocd);
    $out;
}

#| 写一份 .xlsx，返回数据行数（不含表头）。
our sub write-xlsx(
    Str:D $path,
    @names,
    @rows,
    Str:D :$sheet = 'Sheet1',
    --> Int
) is export {
    my Str $name = clean-sheet($sheet);
    my @files =
        '[Content_Types].xml', $CONTENT-TYPES,
        '_rels/.rels',         $ROOT-RELS,
        'xl/workbook.xml',     workbook-xml($name),
        'xl/_rels/workbook.xml.rels', $WORKBOOK-RELS,
        'xl/worksheets/sheet1.xml',   sheet-xml(@names, @rows),
    ;

    my @pairs;
    for @files -> $p, $c { @pairs.push: [$p, $c] }
    spurt $path, zip-store(@pairs);
    @rows.elems;
}
