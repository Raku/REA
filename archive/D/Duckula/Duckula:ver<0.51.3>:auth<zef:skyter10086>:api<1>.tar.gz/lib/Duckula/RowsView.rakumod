use v6.d;
use DB::DuckDB;
use Duckula::Decode;

#| RowsView 的 pull iterator —— 逐行调 row-at()，一次只解一行。
class Duckula::RowsView::Iterator does Iterator {
    has $!rows-view;
    has Int $!i;
    has Int $!n;

    submethod BUILD(:$rows-view, Int :$n) {
        $!rows-view = $rows-view;
        $!i = 0;
        $!n = $n;
    }

    method pull-one() {
        return IterationEnd if $!i >= $!n;
        $!rows-view.row-at($!i++)
    }
}

#| 惰性行视图：持有 Result + ColumnViews，但**不预先解码**任何列。
#|
#| 设计意图：`$df.rows` 未物化时返回这个对象 —— 它实现了 List 协议
#| （elems / AT-POS / iterator / Array / raku / gist），但取值发生在
#| **访问时**而非构造时。
#|
#| 这样：
#|   - $df.rows[0]       # 只解一行  ← 极快
#|   - $df.rows.head(5)  # 只解 5 行 ← 快
#|   - $df.rows.elems    # 零成本（ColumnView.elems 是元数据）
#|   - $df.rows.Array    # 强制全量解码 ← 和以前一样
#|
#| 关键约束：ColumnView 的指针属于 Result，所以 RowsView 必须持有
#| Result 引用防止 GC 掉后悬垂。DB::DuckDB 要求 column-views 只能是
#| Result 的「第一个 reader」，调过一次 Result 就被消耗 —— 所以
#| Frame 只在 rows 第一次被调用时拿 column-views，之后一直复用缓存的 views。
#|
#| 类型还原：标量列（DECIMAL/HUGEINT 等）在 RowsView 里逐元素做 Rat/Int 转换。
#| **嵌套列**（LIST/STRUCT/MAP/ARRAY）需要 DB::DuckDB 1.4.0 的
#| `ColumnView.to-list(:typed)` 才能拿到真值 — 标记 kind=3，全量解码时
#| 一次性拿整列避免每行重复调。
class Duckula::RowsView does Positional does Iterable {
    has $!result;
    has @!views;
    has Int $!n;
    #| 每列的解码目标：0=原样，1=Int，2=Rat，3=嵌套（需 :typed），4=UNION（不支持）
    has @!col-decode;
    #| 全量 :typed 解码后的列式缓存（Array / List 时一次算完，之后复用）
    has @!typed-cols;
    has Bool $!typed-cached = False;

    submethod BUILD(:$!result, :@!views, Int :$!n) {
        # 预先扫描每列的 type/tid，决定解码目标（委托 Duckula::Decode）
        @!col-decode = @!views.map(-> $v { type-decode-kind(($v.type // '').Str, $v.tid) });
    }

    #| 行数 —— 直接从 ColumnView 的元数据拿，不碰数据。
    method elems(--> Int) { $!n }

    #| 全量列式解码 —— 每列一次 column-decode（内部走 view.to-list 或
    #| view.to-list(:typed)），然后类型还原。对标量列不再逐格 at()，
    #| 直接拿整列 List 遍历，每列只调一次 view.to-list。
    method !materialize-typed() {
        return if $!typed-cached;
        @!typed-cols = @!views.kv.map(-> Int $ci, $v {
            my $kind = @!col-decode[$ci];
            my $raw = column-decode($v);  # 整列一次拿
            if $kind == 0 {
                $raw.List;                # 原样（已经是正确类型）
            } else {
                $raw.map({ val-decode($_, $kind) }).List;
            }
        });
        $!typed-cached = True;
    }

    #| 按位置取一行（Array）。
    multi method AT-POS(Int:D $i) { self!row($i) }
    multi method AT-POS(WhateverCode:D $w) {
        my Int $i = $w($!n);
        die "RowsView.index($i) out of range (0..$!n)"
            if $i < 0 || $i >= $!n;
        self!row($i);
    }

    #| Range 切片 —— 逐行 pull iterator，不预解码。
    multi method AT-POS(Range:D $r) {
        my Int $from = $r.minmax[0].Int;
        my Int $to   = $r.minmax[1].Int;
        # WhateverCode 处理负索引
        $from = $from < 0 ?? $!n + $from !! $from;
        $to   = $to   < 0 ?? $!n + $to   !! $to;
        $from = max($from, 0);
        $to   = min($to,   $!n - 1);
        return () if $from > $to;
        gather for $from..$to -> $i { take self!row($i) }
    }

    #| 全量解码成 Array of Array。只有 Array / List / .to-list / raku / gist 才触发。
    method Array(--> Array) {
        self!materialize-typed();
        my @out;
        for ^$!n -> $i {
            my @r;
            for @!typed-cols.kv -> Int $ci, @col {
                @r.push(@col[$i]);
            }
            @out.push: @r.Array;
        }
        @out;
    }

    method List(--> List) { self.Array.List }
    method to-list(--> List) { self.Array.List }
    method list(--> List) { self.Array.List }

    #| 逐行 pull iterator —— 一次只解一行。
    method iterator() returns Iterator {
        Duckula::RowsView::Iterator.new(rows-view => self, n => $!n)
    }

    #| raku / gist —— 表现得像 List，触发一次全量解码。
    method raku(--> Str) { self.List.raku }
    method gist(--> Str) { self.List.gist }

    method Bool(--> Bool) { $!n > 0 }

    #| 组装一行：标量列 view.at($i) + 类型还原；嵌套列从全量缓存取。
    #| Iterator 类通过公开方法调它（!row 是私有，跨类不可见）。
    method row-at(Int $i --> Array) { self!row($i) }

    method !row(Int $i --> Array) {
        return [] unless @!views.elems;
        my @r;
        for @!views.kv -> Int $ci, $v {
            my $kind = @!col-decode[$ci];
            if $kind >= 3 {
                # 嵌套（3）或 UNION（4）：列级解码，UNION 会在 column-decode 里
                # 给出明确错误（全量缓存可能已算好，没算就先算）
                self!materialize-typed() unless $!typed-cached;
                @r.push(@!typed-cols[$ci][$i]);
            } else {
                @r.push: self!decode-val($v.at($i), $kind);
            }
        }
        @r.Array;
    }

    #| 单元素解码：委托 Duckula::Decode.val-decode
    method !decode-val($raw, $kind) { val-decode($raw, $kind) }
}
