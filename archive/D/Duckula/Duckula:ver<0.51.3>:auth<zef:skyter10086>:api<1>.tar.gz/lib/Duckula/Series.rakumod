use v6.d;
use Duckula::SQL;
use Duckula::Decode;
use Duckula::Clean;
use Duckula::Index;
use Duckula::IndexLabels;
use Duckula::Accessor;
use Duckula::Expr;
use Duckula::Stats;
use Duckula::FrameOps;
use Duckula::TimeSeries;
use Duckula::Dtype;
use Duckula::X::Series;

# 类还没声明，不能用类型名做前向引用，改查类名（同样可靠）。
my sub is-series($v --> Bool) { $v.^name eq "Duckula::Series" }

my sub series-binop(Str:D $op, $a, $b) {
    my $s;
    my $e;

    if is-series($a) && is-series($b) {
        if $a.same-origin($b) {
            $s = $a;
            my Set $cols = Set.new($a.name, $b.name);
            $e = Duckula::Expr.new(
                sql     => '(' ~ col($a.name).render ~ ' ' ~ $op ~ ' ' ~ col($b.name).render ~ ')',
                columns => $cols,
            );
        }
        else {
            my $fa = $a.frame;
            my $fb = $b.frame;
            my @ka = $fa.defined ?? $fa.index-cols.List !! ();
            my @kb = $fb.defined ?? $fb.index-cols.List !! ();

            # 两边声明了同一组 key 才能按身份对齐。没有 key 时按位置对齐
            # 会静默算错行，必须拒绝。
            die Duckula::X::Series.new(
                reason => 'cannot combine Series from different Frames without '
                        ~ 'matching key columns; call set-index with the same '
                        ~ 'keys on both Frames'
            ) unless @ka.elems && @ka eqv @kb && $fa.session === $fb.session;

            my $out = $a.name;
            my $sql = align-binop-sql(
                $fa.relation-sql, $fb.relation-sql,
                @ka, $a.name, $b.name, $op, $out,
            );
            return $fa.derived($sql).column($out);
        }
    }
    elsif is-series($a) {
        $s = $a;
        $e = Duckula::Expr.new(
            sql     => '(' ~ col($a.name).render ~ ' ' ~ $op ~ ' ' ~ sql-literal($b) ~ ')',
            columns => Set.new($a.name),
        );
    }
    else {
        $s = $b;
        $e = Duckula::Expr.new(
            sql     => '(' ~ sql-literal($a) ~ ' ' ~ $op ~ ' ' ~ col($b.name).render ~ ')',
            columns => Set.new($b.name),
        );
    }

    $s.apply-expr($e);
}

#| 一列数据：DB::DuckDB::ColumnView 的薄包装 + Frame 算子的代理。
#|
#| 两层职责（v0.19.0 起）：
#|   1. **读值/聚合**直接代理 ColumnView —— 零计算开销，走向量内存；
#|   2. **变换/运算**代理回来源 Frame 的算子或 Expr，再取回同名列。
#|
#| 第 2 层是刻意的：Duckula 不写计算引擎（ARCHITECTURE 设计边界）。在 Series
#| 里遍历 ColumnView 逐元素算，会重新实现 NULL 传播、类型提升、DECIMAL 精度，
#| 还绕开 SQL-first。代理回 Frame 后，API 像 pandas，执行仍在 DuckDB。
#|
#| **生命周期（最容易出悬垂指针的地方）**
#| ColumnView 的指针属于 `duckdb_result`，不是属于 view。所以 Series 必须
#| 同时持有 result 的引用，否则 view 还活着、result 已被 GC，读到的就是野内存。
#| `$!result` 这个属性唯一的作用就是"钉住" result。
#|
#| **$!frame 的作用**
#| 变换时要重跑 SQL。Frame 的 `.column` 本来就会重跑一次 relation-sql 拿新
#| result（见 Frame 的注释），所以 Series 的每个变换都走
#| `$frame.<算子>.column($!name)`，拿回的仍是 raw ColumnView，聚合照常可用。
class Duckula::Series does Iterable {
    has Str $.name = '';
    has $!view;
    has $!result;
    has $!frame;
    has $!dtype;

    submethod BUILD(Str :$!name = '', :$!view!, :$!result, :$!frame, :$dtype) {
        $!dtype = $dtype;
    }

    #| 来源 Frame。跨 Frame 运算要靠它的 index-cols 判断能否按 key 对齐；
    #| 手工构造的裸 Series 没有来源，这里给回 Nil。
    method frame() { $!frame }

    #| 来源 Frame 声明的 key 列；裸 Series 没有来源时返回空 List。
    #| 之前这条信息只在四则运算内部读，v0.28.0 起作为公开自省入口。
    method index-cols(--> List) {
        $!frame.defined ?? $!frame.index-cols.List !! ();
    }

    #| 变换类操作要求 Series 有来源 Frame。手工构造的裸 Series（没有 frame）
    #| 只能读值，不能变换 —— 报清楚，别让它静默返回旧值。
    method !source-frame() {
        my $f = $!frame;
        die Duckula::X::Series.new(
            reason => "this Series has no source Frame; only value access "
                    ~ "(at / to-list / sum / ...) is available"
        ) unless $f.defined;
        $f;
    }

    #| 把一个 Expr 作用在本列上，结果写回同名列，再取回 Series。
    #|
    #| 用 `with-column(...alias($!name))` 而不是自己拼 SELECT：Frame 已经处理了
    #| 覆盖同名列要 EXCLUDE、窗口函数会改变行序要按扫描序排回去（§8.9）这两件
    #| 最容易出错的事。这里沾现成的光。
    method !apply-expr(Duckula::Expr:D $e --> Duckula::Series) {
        my $f = self!source-frame;
        $f.with-column($e.alias($!name)).column($!name);
    }

    #| 运算符 multi sub 在类外，私有方法够不着，所以这两条公开入口只给
    #| 运算符用（实现仍留在私有方法里）。
    method apply-expr(Duckula::Expr:D $e --> Duckula::Series) { self!apply-expr($e) }

    #| 两个 Series 是否来自同一个 Frame（同一行序）。不同 Frame 时若两边声明
    #| 相同的 key 列，就走 key 对齐；否则拒绝（没有隐式行号，按位置对齐会算错行）。
    method same-origin(Duckula::Series:D $other --> Bool) {
        my $mine = $!frame;
        my $theirs = $other!source-frame;
        so $mine.defined && $theirs.defined && $mine === $theirs;
    }

    #| 在来源 Frame 上跑一条只有一行的聚合 SQL，取回标量。
    #| 走 Frame.rows（RowsView 解码链路已处理 HUGEINT→Int、DECIMAL→Rat
    #| 还原，统计结果不该以十进制字符串漏出来），不触发 Frame.materialize
    #| 计数器 —— rows() 是 RowsView 惰性路径，列表化只调自己的内部解码。
    method !scalar(Str:D $agg --> Mu) {
        my $f = self!source-frame;
        my Str $q = $f.relation-sql;
        my $r = $f.derived("SELECT $agg AS __duckula_agg FROM ($q) AS __duckula_src");
        my @rows = $r.rows;
        @rows.elems ?? @rows[0][0] !! Any;
    }

    #| 造一个「函数调用」Expr：fn("col", 参数...)。
    #| 参数走 sql-literal，不走绑定 —— Expr 渲染的是一段可以嵌进任何 SQL 的
    #| 片段，没有位置可绑。字面量生成器已经处理了引号与 NaN/Inf。
    method !func-expr(Str:D $fn, *@args --> Duckula::Expr) {
        my Str $head = $fn ~ '(' ~ col($!name).render;
        $head ~= ', ' ~ @args.map({ sql-literal($_) }).join(', ') if @args.elems;
        Duckula::Expr.new(sql => $head ~ ')', columns => Set.new($!name));
    }

    # ============================================================
    # 读值与聚合（原始职责，直接代理 ColumnView）
    # ============================================================

    #| 元素个数（含 NULL）。
    method elems(--> Int) { $!view.elems }

    #| 非 NULL 的个数。
    method count(--> Int) { $!view.count }

    #| 整列取成 List。内部走 Duckula::Decode.column-decode：
    #|   - HUGEINT / DECIMAL / NUMERIC 列的 ColumnView.to-list() 对负值
    #|     仍返回字符串（DB::DuckDB 1.3.1 补码扩展只修了内部表示），
    #|     column-decode 把合法数字字符串还原成 Raku 原生类型（Int / Rat）。
    #|   - 嵌套类型（LIST / STRUCT / MAP / ...）自动调 ColumnView.to-list(:typed)
    #|     拿真值（List / Hash）。
    #|   - 其他类型（VARCHAR / TIMESTAMP / BOOLEAN / DOUBLE / BIGINT / ...）
    #|     直接透传 ColumnView 的返回值。
    #|
    #| 所以 Series.to-list() 现在和 Frame.rows 走同一份解码逻辑，类型一致。
    method to-list(Bool :$typed = False --> List) { column-decode($!view) }

    #| SUM，跳过 NULL。整数列返回 Int，浮点列返回 Num。
    method sum(--> Mu) { $!view.sum }

    method min(--> Mu) { $!view.min }

    method max(--> Mu) { $!view.max }

    #| sum / count，全 NULL 时返回 Any。
    method mean(--> Mu) { $!view.mean }

    #| 第 $i 个值（0 基），越界返回 Any，NULL 也是 Any。
    method at(Int $i --> Mu) { $!view.at($i) }

    #| 行号索引列（0 基）。来源 Frame 已有同名行号列就直接取；
    #| 否则临时生成一列，不改动原 Frame。仍走 `.column`，拿到的是 raw
    #| ColumnView，可以继续 `.sum` / `.mean`，不只是打印用。
    multi method index(--> Duckula::IndexLabels) {
        my $f = self!source-frame;
        Duckula::IndexLabels.new(
            frame     => $f,
            levels    => $f.index-cols.List,
            row-based => $f.index-cols.elems == 0,
        );
    }

    multi method index(Str:D :$name!, Int:D :$offset = 0) {
        my $f = self!source-frame;
        my $src = $name ∈ $f.names.Set
            ?? $f
            !! $f.with-row-index(:$name, :$offset);
        $src.column($name);
    }

    #| 按索引标签取一个值/一行：有 key 时委托给来源 Frame.loc。
    method loc($label --> Duckula::Series) {
        self!source-frame.loc($label).column($!name);
    }

    # ============================================================
    # Raku 基本协议（v0.19.0）
    # ============================================================

    #| 逐值迭代协议。Raku 的 scalar 变量天然 itemize：`for $s -> $v` 只会把
    #| 整个 Series 当一个元素交出去（`for $list` 对普通 List 也一样）。
    #| 正确拼法是 `for $s.list -> $v` 或 `for |$s -> $v`；这里提供 iterator
    #| 与下面的小写 `.list` 让这两种写法都拿到逐值语义。
    #|
    #| 走 to-list 是分配路径 —— 迭代本身就是逐值访问，没有零拷贝的迭代形式。
    method iterator(--> Iterator) { self.to-list.iterator }

    #| 小写 `.list` 才是 `for $s.list` 调用的入口；大写 `.List` 是显式转换。
    method list(--> List) { self.to-list }

    #| `$s[0]` / `$s[-1]`（负数从末尾算）。
    #| 原来的 `.at` 保留，因为它是 0 基严格索引，越界/负数都交 ColumnView 判。
    multi method AT-POS(Int:D $i --> Mu) {
        my Int $n = $!view.elems;
        self.at($i < 0 ?? $n + $i !! $i);
    }

    #| Raku 编译期就禁掉字面 `$s[-1]`（要求写 `$s[*-1]`），所以「从末尾数」
    #| 的正规拼法是 WhateverCode。它拿到的是「最后一个下标」，交给它算即可。
    multi method AT-POS(WhateverCode:D $i --> Mu) {
        self.at($i($!view.elems - 1).Int);
    }

    #| 与 List / Array 互转。注意 `.Array` 是新数组，改动它不影响 Series。
    method List(--> List) { self.to-list }
    method Array(--> Array) { self.to-list.Array }

    #| `if $s` 的真假 = 是否非空。Raku 没有 pandas 那种「Series 真值歧义」，
    #| 但让 Series 能自然出现在条件里还是方便的。
    method Bool(--> Bool) { $!view.elems > 0 }

    # ============================================================
    # 切片
    # ============================================================

    #| 取前 $n 个值。
    #|
    #| 走来源 Frame 的 SQL LIMIT，而不是 ColumnView.slice —— 因为 slice 返回的是
    #| 重新解码出来的 view（`.raw` 为 False），`!agg` 对它直接返回 Any，聚合就废了。
    #| 重新走 SQL 多一次查询，但拿到的仍是 raw 列，`.sum` / `.mean` 照常可用。
    method head(Int $n = 5 --> Duckula::Series) {
        die Duckula::X::Series.new(reason => "head() needs a non-negative count, got $n")
            if $n < 0;

        return $!frame.head($n).column($!name) if $!frame.defined;

        Duckula::Series.new(
            name   => $!name,
            view   => $!view.slice(0, $n),
            result => $!result,        # 继续钉住同一个 result
        );
    }

    #| 取末尾 $n 个值（Polars 的 `tail`）。复用 Frame.tail 的单扫描实现。
    method tail(Int $n = 5 --> Duckula::Series) {
        die Duckula::X::Series.new(reason => "tail() needs a non-negative count, got $n")
            if $n < 0;
        self!source-frame.tail($n).column($!name);
    }

    #| 反转行序。SQL 没有天然行序，这里和 Frame.tail / Expr.cum-sum 一样用
    #| `row_number() OVER ()` 钉扫描序，再按它倒排。辅助列名走 private-name，
    #| 撞上真实列名会自动加下划线。
    method reverse(--> Duckula::Series) {
        my $f = self!source-frame;
        my Str $rn = private-name($f.names, '__duckula_rn');
        my Str $sql =
              'SELECT * EXCLUDE (' ~ quote-ident($rn) ~ ') FROM ('
            ~ 'SELECT *, row_number() OVER () AS ' ~ quote-ident($rn)
            ~ " FROM ({$f.relation-sql}) AS __duckula_rev_src"
            ~ ') AS __duckula_rev ORDER BY ' ~ quote-ident($rn) ~ ' DESC';
        $f.derived($sql).column($!name);
    }

    # ============================================================
    # 单列变换（v0.19.0）：全部代理回 Frame
    # ============================================================

    #| 去重，语义同 `Frame.unique` 的单列版。`:keep` 取 first / last / none / any。
    method unique(Str :$keep = 'first' --> Duckula::Series) {
        self!source-frame.unique($!name, :$keep).column($!name);
    }

    #| 频次表。**返回 Frame 而不是 Series**：有两列（原列 + count），
    #| 而 Series 的定义就是单列。这也正是 Polars `Series.value_counts()`
    #| 返回 DataFrame 的形态；pandas 返回带 index 的 Series，Duckula 没有
    #| index 概念，硬塞进单列 Series 只会把值丢掉。
    method value-counts(
        Bool :$sort = True,
        Bool :$normalize = False,
        Bool :$keep-nulls = False,
    ) {
        self!source-frame.value-counts(
            $!name, :$sort, :$normalize, :$keep-nulls,
        );
    }

    #| 排序。默认升序，`:desc` 反序。NULL 的位置交给 DuckDB。
    method sort(Bool :$desc = False --> Duckula::Series) {
        self!source-frame.sort-values($!name, :$desc).column($!name);
    }

    #| 丢掉 NULL 行。
    method drop-nulls(--> Duckula::Series) {
        self!source-frame.drop-nulls($!name).column($!name);
    }

    #| 填空值，语义同 `Frame.fill-nulls`：
    #|   $s.fill-nulls(:value(0));
    #|   $s.fill-nulls(:strategy<ffill>);
    method fill-nulls(:$value, Str :$strategy --> Duckula::Series) {
        self!source-frame.fill-nulls($!name, :$value, :$strategy).column($!name);
    }

    #| 这一列 declared 的逻辑 dtype（v0.30.0）。来源 Frame 没声明过时，
    #| 从 DuckDB 的物理类型反查；裸 Series 用 ColumnView 的 .type。
    method dtype(--> Duckula::Dtype) {
        return $!dtype if $!dtype.defined;
        my $f = $!frame;
        return $f.dtype-of($!name) if $f.defined;
        my $t = $!view.defined && $!view.can('type') ?? ($!view.type // '').Str !! '';
        dtype-from-sql($t);
    }

    #| pandas 的 `.cat`：只有 category dtype 才有，否则报错。
    method cat(--> Duckula::CatAccessor) {
        my $d = self.dtype;
        die Duckula::X::Series.new(
            reason => "Series '$!name' is not categorical (dtype '{$d.name}')"
        ) unless $d.is-categorical;
        my $s = self;
        Duckula::CatAccessor.new(
            col    => $!name,
            dtype  => $d,
            apply  => -> $e { $s.apply-expr($e) },
        );
    }

    #| 改类型（pandas 的 `astype` / Polars 的 `cast`）。
    #| 既接受 SQL 类型串，也接受 Duckula::Dtype（nullable / category）。
    method cast($type, Bool :$strict = False --> Duckula::Series) {
        self!source-frame.cast($!name => $type, :$strict).column($!name);
    }

    #| `astype` 是 pandas 的拼法，`cast` 是 Polars 的；两个都留。
    method astype($type, Bool :$strict = False --> Duckula::Series) {
        self.cast($type, :$strict);
    }

    #| pandas 的 `pipe`：闭包拿当前 Series 作第一个参数。
    method pipe(&fn, *@args, *%kw) { &fn(self, |@args, |%kw) }

    #| pandas 的 `combine_first`：自己的 NULL 用另一个 Series 同 key 的值补。
    #| 同一来源直接 coalesce；不同来源要求声明过相同的 key（对齐语义）。
    method combine-first(Duckula::Series:D $other --> Duckula::Series) {
        if self.same-origin($other) {
            my $e = Duckula::Expr.new(
                sql     => 'coalesce(' ~ col($!name).render ~ ', '
                         ~ col($other.name).render ~ ')',
                columns => Set.new($!name, $other.name),
            );
            return self.apply-expr($e);
        }
        my $fa = $!frame;
        my $fb = $other.frame;
        die Duckula::X::Series.new(
            reason => 'combine-first needs matching key columns on both Series'
        ) unless $fa.defined && $fb.defined
               && $fa.index-cols.List eqv $fb.index-cols.List
               && $fa.index-cols.List.elems
               && $fa.session === $fb.session;

        my Str $out = $!name;
        my $sql = align-coalesce-sql(
            $fa.relation-sql, $fb.relation-sql,
            $fa.index-cols.List, $!name, $other.name, $out,
        );
        $fa.derived($sql).column($out);
    }

    # ============================================================
    # 元素级运算（v0.20.0）
    # ============================================================
    #
    # 用**方法**而不是运算符：Raku 核心的算术 multi（`infix:<->` 尤甚）有
    # `(Int,Int)` / `(Real,Real)` 等具体候选，窄化时会对 Series 调 `Numeric()`，
    # 抢在我们注册的 multi 之前命中（结果变成标量）。加精确候选、`where`、
    # 类型对象 Numeric 桩都试过，压不过。Expr 用运算符没问题是因为它没有
    # Iterable / 协议方法干扰窄化；Series 用方法就没有这层分派歧义。
    #
    # 参数是标量（Int/Num/Rat/Str）或另一 Series：
    # 同来源直接逐行算；不同来源时两边要有相同的 set-index key，
    # 否则拒绝 —— 没有隐式行号，按位置对齐会静默算错行。

    method add($other --> Duckula::Series) { series-binop('+', self, $other) }
    method subtract($other --> Duckula::Series) { series-binop('-', self, $other) }
    method multiply($other --> Duckula::Series) { series-binop('*', self, $other) }
    method divide($other --> Duckula::Series) { series-binop('/', self, $other) }
    method mod($other --> Duckula::Series) { series-binop('%', self, $other) }

    #| 幂。DuckDB 用 power()，只接受标量指数。
    method power(Numeric:D $n --> Duckula::Series) {
        self.apply-expr(Duckula::Expr.new(
            sql     => 'power(' ~ col($!name).render ~ ', ' ~ sql-literal($n) ~ ')',
            columns => Set.new($!name),
        ));
    }

    #| 取负。
    method negate(--> Duckula::Series) {
        self.apply-expr(Duckula::Expr.new(
            sql     => '(-' ~ col($!name).render ~ ')',
            columns => Set.new($!name),
        ));
    }

    # ---- 比较：返回布尔 Series ----
    method eq($other --> Duckula::Series) { series-binop('=', self, $other) }
    method ne($other --> Duckula::Series) { series-binop('<>', self, $other) }
    method gt($other --> Duckula::Series) { series-binop('>', self, $other) }
    method lt($other --> Duckula::Series) { series-binop('<', self, $other) }
    method ge($other --> Duckula::Series) { series-binop('>=', self, $other) }
    method le($other --> Duckula::Series) { series-binop('<=', self, $other) }

    #| 四舍五入到 $digits 位（DuckDB 的 round）。
    method round(Int $digits = 0 --> Duckula::Series) {
        self!apply-expr(self!func-expr('round', $digits));
    }

    #| 绝对值。
    method abs(--> Duckula::Series) { self!apply-expr(self!func-expr('abs')) }

    #| 截到 [$lo, $hi] 区间（DuckDB 的 greatest / least 嵌套）。
    #|
    #| 必须显式保护 NULL：DuckDB 的 greatest/least 会**忽略** NULL 参数，
    #| `least(NULL, 5)` 给 5，`greatest(5, 0)` 给 5 —— 一个空值被静默变成
    #| 上界，pandas 的 `clip` 却是 NULL 原样保留。CASE 挡一下才对齐。
    method clip($lo, $hi --> Duckula::Series) {
        my Str $q = col($!name).render;
        my Str $sql = 'CASE WHEN ' ~ $q ~ ' IS NULL THEN NULL ELSE greatest(least('
                    ~ $q ~ ', ' ~ sql-literal($hi) ~ '), ' ~ sql-literal($lo)
                    ~ ') END';
        self!apply-expr(Duckula::Expr.new(sql => $sql, columns => Set.new($!name)));
    }

    # ---- 窗口算子：Expr 已有，这里只做一行代理 ----

    #| 排名。`:method` 取 min / rank / max / dense / ordinal / row。
    method rank(Bool :$desc = False, Str :$method = 'min' --> Duckula::Series) {
        self!apply-expr(col($!name).rank(:$desc, :$method));
    }

    #| 前后挪一行：正数为前一行，负数为后一行。
    method shift(Int $n = 1 --> Duckula::Series) {
        self!apply-expr(col($!name).shift($n));
    }

    #| 与前一行的差。
    method diff(Int $n = 1 --> Duckula::Series) {
        self!apply-expr(col($!name).diff($n));
    }

    method cum-sum(--> Duckula::Series) { self!apply-expr(col($!name).cum-sum) }
    method cum-max(--> Duckula::Series) { self!apply-expr(col($!name).cum-max) }
    method cum-min(--> Duckula::Series) { self!apply-expr(col($!name).cum-min) }
    method cum-count(--> Duckula::Series) { self!apply-expr(col($!name).cum-count) }

    method rolling-sum(Int $w --> Duckula::Series) {
        self!apply-expr(col($!name).rolling-sum($w));
    }
    method rolling-mean(Int $w --> Duckula::Series) {
        self!apply-expr(col($!name).rolling-mean($w));
    }

    # ============================================================
    # 函数式 API 与时间窗口（v0.27.0）
    # ============================================================

    #| Raku 闭包算好的一列值写回 DuckDB，仍拿回 raw ColumnView。
    #| 这是 map/apply/ewm 共用的桥：值先在 Raku 里过一遍，之后再回到
    #| SQL-first 的世界，后续链式算子照常可用。
    method !write-values(@vals --> Duckula::Series) {
        my $f = self!source-frame;
        my Str $sql = replace-column-sql(
            $f.relation-sql, $!name, @vals, $f.names);
        $f.derived($sql).column($!name);
    }

    #| 逐元素映射。NULL 不经闭包、原样保留（和 pandas 的常用写法一致）。
    #| 闭包返回值支持数值、Bool、Str、Date/DateTime、Nil/Any。
    method map(&fn --> Duckula::Series) {
        my @vals = self.to-list.map(-> $v { $v.defined ?? &fn($v) !! $v }).List;
        self!write-values(@vals);
    }

    #| `apply` 在 Series 上是 `map` 的同义词。
    method apply(&fn --> Duckula::Series) { self.map(&fn) }

    #| 条件替换（pandas 的 `Series.where`）：cond 为 True 保留原值，
    #| 否则换成 `$other`（默认 NULL）。NULL 条件按 False 处理。
    #| cond 可以是 Expr、同来源的布尔 Series，或带 `?` 绑定的 SQL 片段。
    method where($cond, $other = Any, *@args --> Duckula::Series) {
        my Str $c;
        my Set $cols;
        if is-series($cond) {
            die Duckula::X::Series.new(
                reason => 'condition Series must come from the same Frame'
            ) unless self.same-origin($cond);
            $c = col($cond.name).render;
            $cols = Set.new($cond.name);
        } else {
            ($c, $cols) = normalize-condition($cond, @args);
        }
        my Str $type = ($!frame.defined ?? $!frame.dtypes{$!name} !! Str) // Str;
        self!apply-expr(Duckula::Expr.new(
            sql     => fill-expression($!name, $c, $other, :!mask, :$type),
            columns => $cols ∪ Set.new($!name),
        ));
    }

    #| `mask` 与 `where` 相反：cond 为 True 时替换，否则保留原值。
    method mask($cond, $other = Any, *@args --> Duckula::Series) {
        my Str $c;
        my Set $cols;
        if is-series($cond) {
            die Duckula::X::Series.new(
                reason => 'condition Series must come from the same Frame'
            ) unless self.same-origin($cond);
            $c = col($cond.name).render;
            $cols = Set.new($cond.name);
        } else {
            ($c, $cols) = normalize-condition($cond, @args);
        }
        my Str $type = ($!frame.defined ?? $!frame.dtypes{$!name} !! Str) // Str;
        self!apply-expr(Duckula::Expr.new(
            sql     => fill-expression($!name, $c, $other, :mask, :$type),
            columns => $cols ∪ Set.new($!name),
        ));
    }

    #| 百分比变化：`(x - lag(x, n)) / lag(x, n)`。
    method pct-change(Int:D $periods = 1 --> Duckula::Series) {
        self!apply-expr(col($!name).pct-change($periods));
    }

    #| 滚动窗口对象：`$s.rolling(3).mean` / `.sum` / `.std` / ...
    #| 默认窗口不满也算（min-periods=1）；`:center` 居中；`:min-periods`
    #| 大于 1 时不足的行给 NULL。
    method rolling(
        Int:D $w,
        Bool :$center = False,
        Int :$min-periods = 1,
        --> Duckula::Rolling
    ) {
        my $s = self;
        Duckula::Rolling.new(
            window => $w,
            run    => -> Str $fn {
                $s.apply-expr(
                    col($s.name).rolling($fn, $w, :$center, :$min-periods)
                );
            },
        );
    }

    #| 累积窗口对象：`$s.expanding.mean` / `.sum` / ...
    method expanding(Int :$min-periods = 1 --> Duckula::Expanding) {
        my $s = self;
        Duckula::Expanding.new(
            run => -> Str $fn {
                $s.apply-expr(col($s.name).expanding($fn, :$min-periods));
            },
        );
    }

    #| 指数加权移动平均。必须给且只给一个 span / alpha / halflife。
    #| 默认 `adjust => True`（pandas 的默认），窗口不满也算。
    #| DuckDB 没有 EWMA 窗口函数，这里在 Raku 里递推后写回，属于非向量化路径。
    method ewm(
        Int :$span,
        Num :$alpha,
        Num :$halflife,
        Bool :$adjust = True,
        Int :$min-periods = 1,
        --> Duckula::Ewm
    ) {
        my Int $given = ($span.defined ?? 1 !! 0)
                      + ($alpha.defined ?? 1 !! 0)
                      + ($halflife.defined ?? 1 !! 0);
        die Duckula::X::Series.new(
            reason => 'ewm() needs exactly one of :span, :alpha or :halflife'
        ) unless $given == 1;

        my Num $a = $alpha.defined ?? $alpha.Num
                  !! $span.defined ?? 2e0 / ($span + 1)
                  !! 1e0 - (0.5e0 ** (1e0 / $halflife.Num));
        die Duckula::X::Series.new(
            reason => "ewm decay must be in (0, 1], got {$a}"
        ) unless 0e0 < $a <= 1e0;

        my $s = self;
        Duckula::Ewm.new(
            values      => self.to-list.List,
            alpha       => $a,
            :$adjust,
            :$min-periods,
            write       => -> @vals {
                my $f = $s!source-frame;
                my Str $sql = replace-column-sql(
                    $f.relation-sql, $s.name, @vals, $f.names);
                $f.derived($sql).column($s.name);
            },
        );
    }

    # ============================================================
    # 比较 / 成员判断（v0.20.0）：返回布尔 Series
    # ============================================================

    #| `s.isin(1, 3)` / `s.isin([1,3])`：DuckDB 的 `IN (...)`。
    #| 空集合恒假 —— SQL 的 `IN ()` 不合法，写成 `false` 字面量。
    method isin(*@vals --> Duckula::Series) {
        my @flat = @vals.elems == 1 && @vals[0] ~~ Positional
            ?? @vals[0].List !! @vals.List;
        my Str $sql = @flat.elems
            ?? col($!name).render ~ ' IN (' ~ @flat.map({ sql-literal($_) }).join(', ') ~ ')'
            !! 'false';
        self!apply-expr(Duckula::Expr.new(sql => $sql, columns => Set.new($!name)));
    }

    #| `s.between(10, 20)`：闭区间，等价于 `s >= 10 & s <= 20`。
    method between($lo, $hi --> Duckula::Series) {
        my Str $sql = col($!name).render ~ ' BETWEEN ' ~ sql-literal($lo)
                    ~ ' AND ' ~ sql-literal($hi);
        self!apply-expr(Duckula::Expr.new(sql => $sql, columns => Set.new($!name)));
    }

    #| 空值判断。返回布尔 Series（NULL 本身转成 true/false，不是 NULL）。
    method is-null(--> Duckula::Series) {
        self!apply-expr(Duckula::Expr.new(
            sql => col($!name).render ~ ' IS NULL', columns => Set.new($!name),
        ));
    }
    method not-null(--> Duckula::Series) {
        self!apply-expr(Duckula::Expr.new(
            sql => col($!name).render ~ ' IS NOT NULL', columns => Set.new($!name),
        ));
    }

    # ============================================================
    # 字符串 / 数学函数（v0.20.0）：Expr 已有的能力挂到 Series 上
    # ============================================================

    #| pandas 风格的二级访问器（v0.23.0）：`$s.str.upper`、`$s.dt.year`。
    #| 访问器不反向引用 Series 类型（会崩 Raku resolver），而是拿列名 +
    #| 一支 Expr→Series 的闭包；闭包在这里捕获 self，变换仍走
    #| `!apply-expr`，所以拿回的 Series 照旧是 raw ColumnView。
    method str(--> Duckula::StrAccessor) {
        my $s = self;
        Duckula::StrAccessor.new(
            col   => $!name,
            apply => -> $e { $s.apply-expr($e) },
        );
    }

    method dt(--> Duckula::DtAccessor) {
        my $s = self;
        Duckula::DtAccessor.new(
            col   => $!name,
            apply => -> $e { $s.apply-expr($e) },
        );
    }

    method starts-with($prefix --> Duckula::Series) { self!apply-expr(col($!name).starts-with($prefix)) }
    method contains($needle --> Duckula::Series) { self!apply-expr(col($!name).contains($needle)) }
    method upper(--> Duckula::Series) { self!apply-expr(col($!name).upper) }
    method lower(--> Duckula::Series) { self!apply-expr(col($!name).lower) }
    method length(--> Duckula::Series) { self!apply-expr(col($!name).length) }

    #| 常用数学函数走白名单：函数名不能参数绑定，只能拼文本，所以绝不能
    #| 让用户直接传任意字符串（那是 SQL 注入面）。只放这些纯函数。
    my constant $MATH-FN = set <sqrt exp ln log10 floor ceil sign>;
    method math(Str:D $fn --> Duckula::Series) {
        die Duckula::X::Series.new(
            reason => "unknown math function '$fn'; use one of {$MATH-FN.keys.sort.join(', ')}"
        ) unless $MATH-FN{$fn};
        self!apply-expr(self!func-expr($fn));
    }

    method sqrt(--> Duckula::Series) { self.math('sqrt') }
    method exp(--> Duckula::Series) { self.math('exp') }
    method ln(--> Duckula::Series) { self.math('ln') }
    method log10(--> Duckula::Series) { self.math('log10') }
    method floor(--> Duckula::Series) { self.math('floor') }
    method ceil(--> Duckula::Series) { self.math('ceil') }
    method sign(--> Duckula::Series) { self.math('sign') }

    # ============================================================
    # 描述统计（v0.20.0）：返回标量
    # ============================================================

    #| 中位数。DuckDB 的 median 跳过 NULL。
    method median(--> Mu) { self!scalar('median(' ~ col($!name).render ~ ')') }

    #| 标准差：`:ddof` 默认 1（样本，pandas / Polars 的默认），0 为总体。
    method std(Int :$ddof = 1 --> Mu) {
        my Str $fn = $ddof == 0 ?? 'stddev_pop' !! 'stddev_samp';
        self!scalar($fn ~ '(' ~ col($!name).render ~ ')');
    }

    #| 方差，`:ddof` 语义同 std。
    method var(Int :$ddof = 1 --> Mu) {
        my Str $fn = $ddof == 0 ?? 'var_pop' !! 'var_samp';
        self!scalar($fn ~ '(' ~ col($!name).render ~ ')');
    }

    #| 连续分位数（$q 在 0..1）。默认 0.5 与 median 等价。
    method quantile(Numeric:D $q = 0.5 --> Mu) {
        die Duckula::X::Series.new(reason => "quantile needs 0 <= q <= 1, got $q")
            if $q < 0 || $q > 1;
        self!scalar('quantile_cont(' ~ col($!name).render ~ ', ' ~ sql-literal($q) ~ ')');
    }

    #| 不同值个数（不含 NULL）。
    method nunique(--> Mu) { self!scalar('count(DISTINCT ' ~ col($!name).render ~ ')') }

    #| 乘积。空列 / 全 NULL 时 DuckDB 给 NULL。
    method product(--> Mu) { self!scalar('product(' ~ col($!name).render ~ ')') }

    #| 众数。
    method mode(--> Mu) { self!scalar('mode(' ~ col($!name).render ~ ')') }

    #| 任一为真 / 全部为真。先把值 CAST 成 BOOLEAN（0/1 整数列也能用），
    #| 再 coalesce 到 false —— 全 NULL 时 pandas 给 False，不是 NULL。
    method any(--> Mu) {
        self!scalar('coalesce(bool_or(CAST(' ~ col($!name).render ~ ' AS BOOLEAN)), false)');
    }
    method all(--> Mu) {
        self!scalar('coalesce(bool_and(CAST(' ~ col($!name).render ~ ' AS BOOLEAN)), false)');
    }

    # ------------------------------------------------------------ 相关与分布（v0.25.0）

    #| 两列相关 / 协方差。同来源 Frame 直接算；跨 Frame 要有相同的 set-index key，
    #| 走 FULL OUTER JOIN 按 key 对齐 —— 和 v0.22.0 的 Series 四则运算同一条规矩，
    #| 没有 key 就拒绝，绝不按位置对齐。
    method !pair-stat(Duckula::Series:D $other, Str:D $fn,
                      Str:D :$method = 'pearson' --> Mu) {
        my $f = self!source-frame;
        my $g = $other!source-frame;
        my Str $sql;
        if $f === $g {
            $sql = pair-stat-sql($f.relation-sql, $!name, $other.name, $fn, :$method);
        }
        else {
            my @ka = $f.index-cols.List;
            my @kb = $g.index-cols.List;
            die Duckula::X::Series.new(
                reason => 'cannot correlate Series from different Frames without '
                        ~ 'matching key columns; call set-index with the same keys '
                        ~ 'on both Frames'
            ) unless @ka.elems && @ka eqv @kb && $f.session === $g.session;
            $sql = align-stat-sql($f.relation-sql, $g.relation-sql, @ka,
                                  $!name, $other.name, $fn, :$method);
        }
        my @rows = $f.derived($sql).rows;
        @rows.elems ?? @rows[0][0] !! Any;
    }

    #| Pearson（默认）或 Spearman 秩相关。
    method corr(Duckula::Series:D $other, Str:D :$method = 'pearson' --> Mu) {
        self!pair-stat($other, 'corr', :$method);
    }

    #| 样本协方差；:$ddof(0) 改为总体协方差。
    method cov(Duckula::Series:D $other, Int:D :$ddof = 1 --> Mu) {
        self!pair-stat($other, cov-fn(:$ddof));
    }

    #| 偏度 / 超额峰度（DuckDB 的 kurtosis 即 pandas 默认的 excess=True）。
    method skew(--> Mu) { self!scalar('skewness(' ~ col($!name).render ~ ')') }
    method kurt(--> Mu) { self!scalar('kurtosis(' ~ col($!name).render ~ ')') }

    #| 按值取前 / 后 n 个，返回仍是 raw ColumnView 的 Series。
    #| keep=first（默认）按扫描序破平局，last 取末尾，all 保留并列。
    method !top-n(Int:D $n, Bool:D :$desc!, Str:D :$keep! --> Duckula::Series) {
        my $f = self!source-frame;
        my Str $sql = top-n-sql($f.relation-sql, ($!name,), $n,
                                :$desc, :$keep, known => $f.names);
        $f.derived($sql).column($!name);
    }
    method nlargest(Int:D $n, Str:D :$keep = 'first' --> Duckula::Series) {
        self!top-n($n, desc => True, :$keep);
    }
    method nsmallest(Int:D $n, Str:D :$keep = 'first' --> Duckula::Series) {
        self!top-n($n, desc => False, :$keep);
    }

    # ============================================================
    # 展示
    # ============================================================

    method gist(--> Str) {
        my Int $n = $!view.elems;
        my Int $show = $n < 5 ?? $n !! 5;
        my @vals = $!view.slice(0, $show).to-list;
        my Str $body = @vals.map({ defined($_) ?? $_.Str !! 'NULL' }).join(', ');
        $body ~= ', ...' if $n > $show;

        my Str $head = $!name eq '' ?? 'Series' !! $!name;
        "$head ($n elems)\n[$body]";
    }

    method raku(--> Str) {
        "Duckula::Series.new(name => {$!name.raku}, elems => {$!view.elems})";
    }
}

# ============================================================
# 元素级运算（v0.20.0）
# ============================================================
#
# 与 Expr 的运算符同构：Series op Series / Series op 标量 / 标量 op Series。
# 结果仍是一列 Series —— 逐行表达式交给 `with-column` 写回同名列，执行在
# DuckDB，NULL 传播由 SQL 决定（NULL + 1 仍是 NULL，和 pandas 的 NaN 一致）。
#
# 标量位置用 Cool:D 而不是 Any:D：Expr 模块已经导出了
# `(Expr, Any)` / `(Any, Expr)` 两个候选，用 Any 会造成
# `$s + col('x')` 的歧义，也会把 Series 自己吸进标量分支。Cool 覆盖
# Int/Num/Rat/Str/Bool，正是标量字面量的范围。


# 算术
