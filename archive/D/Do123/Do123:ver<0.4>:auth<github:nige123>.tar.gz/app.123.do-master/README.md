# app.123.do

123 - a timeline to help your work flow: do, doing, done

To install:

[Install Perl 6](http://perl6intro.com/#_installing_perl_6)

shell> zef install Do123

shell> 123 help

![](images/demo.gif?raw=true)
