class Do::Timeline::UI::Colours {
    
    has $.past-colour   = 'blue';
    has $.now-colour    = 'yellow';
    has $.next-colour   = 'red';

}

