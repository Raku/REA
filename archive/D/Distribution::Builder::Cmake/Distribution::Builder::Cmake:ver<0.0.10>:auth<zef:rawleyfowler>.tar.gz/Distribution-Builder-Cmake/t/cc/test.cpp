int ReturnThree(void) {
	return 3;
}
