[![Actions Status](https://github.com/rawleyfowler/Distribution-Builder-Cmake/actions/workflows/test.yml/badge.svg)](https://github.com/rawleyfowler/Distribution-Builder-Cmake/actions)



