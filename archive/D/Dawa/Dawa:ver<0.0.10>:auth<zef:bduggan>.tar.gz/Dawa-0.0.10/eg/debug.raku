#!/usr/bin/env raku

use Dawa;

say "one";
say "two";
my $x = 99;

stop;

my $y = 100;

say "three";
say "four";
$x = $x + 11;
say "five";
say "x is $x";
say "bye";

