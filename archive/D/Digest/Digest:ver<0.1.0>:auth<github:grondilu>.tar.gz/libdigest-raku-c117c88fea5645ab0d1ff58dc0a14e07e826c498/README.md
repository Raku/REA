This is a perl6 module implementing some digest algorithms in pure Perl6 (no rakudo code).

So far only SHA-256 and RIPEMD-160 are implemented.

The code is mainly a translation from javascript code (see CREDITS file), so it
is not clear for me whether copyrights apply or not.

This work is published under the terms of the artistic license, as rakudo is.
See LICENSE file.
