# raku-mint
Raku implementation of a double-entry accounting system.