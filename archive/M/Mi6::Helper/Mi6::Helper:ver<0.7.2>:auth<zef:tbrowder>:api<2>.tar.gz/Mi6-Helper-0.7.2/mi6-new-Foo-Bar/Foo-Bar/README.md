NAME
====

Foo::Bar - blah blah blah

SYNOPSIS
========

```raku
use Foo::Bar;
```

DESCRIPTION
===========

Foo::Bar is ...

AUTHOR
======

Tom Browder <tbrowder@acm.org>

COPYRIGHT AND LICENSE
=====================

Copyright 2022 Tom Browder

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

