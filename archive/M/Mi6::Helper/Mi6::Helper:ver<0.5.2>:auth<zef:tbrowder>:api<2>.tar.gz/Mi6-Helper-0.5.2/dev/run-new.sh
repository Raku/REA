#!/bin/bash

rm -rf Foo-Bar
raku -I../lib ./mi6-helper new=Foo::Bar  provides=Provides.framistan.handling
