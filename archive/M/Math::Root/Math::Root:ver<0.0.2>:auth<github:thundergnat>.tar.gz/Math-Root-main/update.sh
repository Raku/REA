raku --doc=Markdown ./lib/Math/Root.rakumod > ./README.md
