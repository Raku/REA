# Changelog
All notable changes to this project will be documented in this file.

## 0.1.1
- Use standard UInt instead of a custom `where` clause (contributed by lizmat of github)

## 0.1.0 
- Initial release
