Math-ChebyshevPolynomial
========================

Polynomial approximations for arbitrary functions
