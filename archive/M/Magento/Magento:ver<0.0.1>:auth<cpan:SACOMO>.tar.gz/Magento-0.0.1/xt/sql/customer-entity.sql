INSERT INTO customer_entity (
    website_id, email, group_id, store_id, is_active, disable_auto_group_change, 
    created_in, firstname, middlename, lastname, password_hash, default_billing, 
    default_shipping, gender, failures_num)
VALUES (
    1, 'p6magento@fakeemail.com', 1, 1, 1, 0, 'Default Store View', 'Camelia', 'Perl 6', 'Butterfly',
    '7768199f94416d657a4659d85f81fe6f68b71c3f4cfa4810dcc6a827b53b90ec:dKC12HiRynYjMlRbQWIcb5H7dF2qkO6k:1',
    31, 31, 0, 0);
