---
title: About MongoDB Driver
#nav_title: About
nav_menu: default-nav
sidebar_menu: about-sidebar
layout: sidebar
---

# The MongoDB Project

The project started out by taking over the repository from **Paweł Pabian** (2011-2015, version 0.6.0)(bbkr on github) who setup the basics of the driver.
