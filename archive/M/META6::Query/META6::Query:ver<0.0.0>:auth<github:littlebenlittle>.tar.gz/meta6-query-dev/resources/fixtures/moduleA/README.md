# ModuleA

an example module of type A
