# ModuleC

an example module of type C
