# ModuleB

an example module of type B
