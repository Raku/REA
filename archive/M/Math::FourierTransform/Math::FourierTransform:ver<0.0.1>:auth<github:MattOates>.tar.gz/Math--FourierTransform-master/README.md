# Math--FourierTransform [![Build Status](https://travis-ci.org/MattOates/Math--FourierTransform.svg?branch=master)](https://travis-ci.org/MattOates/Math--FourierTransform)

Discrete Fourier Transform for Perl 6

```perl6
use Math::FourierTransform;

@spectrum = discrete-fourier-transform(@data);

```
