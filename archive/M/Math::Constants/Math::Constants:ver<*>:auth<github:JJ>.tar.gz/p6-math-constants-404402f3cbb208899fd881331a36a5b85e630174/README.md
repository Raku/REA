Math::Constants
====

Math::Constants - A few constants defined in Perl6

SYNOPSIS
========

    use Math::Constants;

DESCRIPTION
===========

Math::Constants is a collection of Math and Physics constants that
will save you the trouble of definint them. 

AUTHOR
======

JJ Merelo <jjmerelo@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2016 JJ Merelo

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.


