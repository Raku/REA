=begin pod

=head1 NAME

Markdown::Lex - a total, streaming-tolerant Markdown lexer: typed blocks and
flat styled spans, no renderer attached

=head1 SYNOPSIS

=begin code :lang<raku>

use Markdown::Lex;

for parse("# Title\n\nHello **world** and `code`.\n") -> $block {
    given $block {
        when Markdown::Lex::Heading {
            say "H{$block.level}: ", $block.inlines».text.join;
        }
        when Markdown::Lex::Para {
            for $block.inlines -> $span {
                print bold($span.text)   if $span.bold;
                print italic($span.text) if $span.italic;
                print plain($span.text)  unless $span.bold || $span.italic;
            }
        }
    }
}

=end code

=head1 DESCRIPTION

A lexer for the Markdown a language model actually emits, aimed at a terminal
renderer that has to draw the text I<while it is still arriving>.

Two properties drive every design decision in here:

=item B<It is total.> C<parse> never throws. Not on C<Str:U>, not on the empty
string, not on a document that is one unterminated code fence, not on ten
thousand asterisks in a row. Whatever comes in, a C<List> of blocks comes out.

=item B<It is prefix-stable.> Every prefix of a document is itself a valid
document. A consumer that re-lexes the accumulated text on every token batch
never sees an error and never sees text I<vanish> — a half-typed C<**bo> is
literal text until the closing C<**> arrives, at which point it becomes bold.

Everything else — colour, wrapping, indentation, hyperlink escape sequences,
whether C<code> gets a background — belongs to the renderer. This module has no
opinion and no dependencies.

=head1 THE OUTPUT

C<parse> returns an immutable C<List> of block objects. Every block is a
C<Markdown::Lex::Block>, is immutable, and has a useful C<.gist>:

=begin table

Class                       | Attributes
============================|=====================================================
Markdown::Lex::Heading      | C<Int:D $.level> (1..6), C<@.inlines>
Markdown::Lex::Para         | C<@.inlines>
Markdown::Lex::CodeFence    | C<Str $.lang>, C<@.lines>, C<Bool:D $.closed>
Markdown::Lex::Bullet       | C<Int:D $.depth> (0-based), C<Str:D $.marker>, C<@.inlines>
Markdown::Lex::Quote        | C<@.inlines>
Markdown::Lex::Rule         | (none)

=end table

The classes are plain global names. C<use Markdown::Lex;> exports exactly one
symbol — the C<parse> sub — and the classes are reachable fully qualified,
which is what you want in a C<given>/C<when> anyway.

=head2 Spans are flat, not a tree

C<@.inlines> is a flat list of C<Markdown::Lex::Span>, never a tree:

=begin code :lang<raku>

class Markdown::Lex::Span {
    has Str:D  $.text is required;
    has Bool:D $.bold   = False;
    has Bool:D $.italic = False;
    has Bool:D $.code   = False;
    has Str    $.link;              # undefined unless this span is a link
}

=end code

Nesting is expressed by I<combining flags>, because that is exactly what a
terminal can draw. C<**bold with *both* inside**> lexes to three spans:

=begin code :lang<raku>

my @spans = parse("**bold with *both* inside**").head.inlines;

@spans[0];   # Span("bold with " :b)
@spans[1];   # Span("both" :bi)
@spans[2];   # Span(" inside" :b)

=end code

There is therefore no nesting depth limit, and no recursion: twenty levels of
emphasis saturate at C<bold + italic> and cost nothing. Adjacent runs with
identical flags are merged, and a span with empty text is never emitted, so a
renderer can loop over C<@.inlines> without defensive checks.

=head1 STREAMING

The prefix guarantee, as a consumer uses it:

=begin code :lang<raku>

my $accumulated = '';

react whenever $token-supply -> $chunk {
    $accumulated ~= $chunk;
    render(parse($accumulated));       # always safe, always sensible
}

=end code

Mid-stream constructs degrade gracefully rather than disappearing:

=begin table

Partial text            | What you get while it is partial
========================|==========================================================
C<**bo>                 | one literal span C<"**bo">
C<``` then code lines>  | a CodeFence with C<:!closed> that grows line by line
C<[label](htt>          | one literal span C<"[label](htt">
C<`unfinished>          | one literal span C<"`unfinished">

=end table

C<CodeFence.closed> is the one place the distinction is surfaced deliberately:
a renderer can draw an unclosed fence with a "still writing" affordance, and it
will close itself when the final C<```> arrives.

=head1 WHAT IT LEXES

=head2 Blocks

=item B<ATX headings> — one to six C<#> followed by a space (or end of line, for
an empty heading). A trailing run of C<#> is stripped: C<"## Title ##"> is
C<Title>.

=item B<Fenced code> — three or more backticks or tildes. The first word of the
info string becomes C<$.lang> (undefined when absent). The fence closes on a
line of the same character, at least as long, with nothing else on it. An
unclosed fence at end of input is still a C<CodeFence>, with C<:!closed>. The
opening fence's indentation is stripped from the content lines; everything else
about them is verbatim, Markdown syntax included.

=item B<Bullets> — C<->, C<*> or C<+>, or an ordinal (C<1.>, C<2)>, C<17.>),
followed by a space. C<$.marker> is the marker exactly as written, so a renderer
can keep the author's numbering. C<$.depth> is the leading indentation divided
by two, floored: zero, two, four... spaces are depths 0, 1, 2, and a tab counts
as however many columns it takes to reach the next four-column stop. A following
non-blank, non-structural line continues the bullet rather than starting a
paragraph.

=item B<Quotes> — a leading C<< > >>, with or without the space after it.
Consecutive quote lines merge into one C<Quote>.

=item B<Rules> — three or more C<->, C<*> or C<_> alone on a line, spaces
allowed between them. This wins over the bullet reading, so C<- - -> is a rule,
as CommonMark says.

=item B<Paragraphs> — everything else. Consecutive non-blank, non-structural
lines merge into one C<Para> and the line breaks between them become single
spaces. A blank line ends whatever block is open.

=head2 Inline

=begin code :lang<raku>

parse('`code`').head.inlines;             # Span("code" :c)
parse('**bold**').head.inlines;           # Span("bold" :b)
parse('*italic*').head.inlines;           # Span("italic" :i)
parse('_italic_').head.inlines;           # Span("italic" :i)
parse('__bold__').head.inlines;           # Span("bold" :b)
parse('***both***').head.inlines;         # Span("both" :bi)
parse('[docs](http://x)').head.inlines;   # Span("docs" ->http://x)

=end code

Code spans take a run of I<N> backticks and close on the next run of exactly
I<N>, so C<``a `b` c``> is one code span containing C<a `b` c>. The content is
verbatim: no emphasis, no links, no escapes. One leading and one trailing space
are dropped if both are present, which is how you write a code span containing
a backtick.

Emphasis follows CommonMark's delimiter-run rules closely enough that the cases
which bite in practice come out right:

=begin code :lang<raku>

parse('*a **b** c*').head.inlines;    # "a " :i / "b" :bi / " c" :i
parse('**a*').head.inlines;           # "*" / "a" :i        (leftover is literal)
parse('a * b * c').head.inlines;      # one literal span    (space-flanked)
parse('snake_case_name').head.inlines;# one literal span    (intraword _)
parse('foo*bar*baz').head.inlines;    # "foo" / "bar" :i / "baz"

=end code

Links are C<[text](destination)>. The destination may be wrapped in angle
brackets, and a title after it is discarded. The bracket text is B<not> lexed
for styles — the span's C<.text> is exactly what you wrote between the brackets
— but it does inherit the emphasis it sits inside, so a link inside C<**...**>
comes back bold. C<[](url)> renders the URL as its own label.

An unmatched delimiter is I<always> literal text. Nothing is ever dropped.

=head1 DIVERGENCES AND NON-GOALS

Deliberately not implemented. Each of these degrades to literal text, which is
the only failure mode this module has:

=item Setext headings (C<Title> over C<=====>). C<---> after a paragraph is a
rule here, not an H2.

=item Indented (four-space) code blocks. There is consequently no four-space
cliff: structural markers are recognised at any indentation, and indentation
means depth for bullets and nothing anywhere else.

=item Tables, images, raw HTML, autolinks, footnotes, reference links, entity
references, and hard line breaks (two trailing spaces). C<![alt](url)> lexes as
a literal C<!> followed by a link.

=item Backslash escapes. C<\*> is a backslash and an asterisk, and the asterisk
still opens emphasis.

=item Nested block structure. A quote inside a quote, a list inside a quote, or
a fence inside a bullet are all lexed at the top level; C<Bullet.depth> is the
only nesting a consumer gets, and a second C<< > >> stays as literal text.

=item Lazy continuation into a quote. A non-quote line ends the quote and starts
a paragraph. (Bullets I<do> take continuation lines, because a soft-wrapped
bullet is common and losing the association is visibly wrong.)

Input normalisation is not a divergence but is worth stating: C<\r\n> and lone
C<\r> both become C<\n> on entry. These blocks describe something on a screen
and are never written back to disk, so there is nothing for the normalisation to
corrupt.

=head1 AUTHOR

Matt Doughty <matt@apogee.guru>

=head1 COPYRIGHT AND LICENSE

Copyright 2026 Matt Doughty

This library is free software; you can redistribute it and/or modify it under
the Artistic License 2.0.

=end pod

unit module Markdown::Lex;

#| How much of a block's text C<.gist> shows before it gives up and elides.
my constant GIST-WIDTH = 48;

#| The flat text of a span list, for gists and nothing else.
my sub preview(@inlines --> Str:D) {
	my $text = @inlines.map(*.text).join;
	$text.chars > GIST-WIDTH ?? $text.substr(0, GIST-WIDTH) ~ '…' !! $text;
}

#|( One styled run of text. The atom of everything inline: a renderer walks a
    block's C<@.inlines> and draws each of these with whatever the flags mean on
    its output device.

    C<$.link> is the odd one out — it is undefined for ordinary text and holds
    the destination for a link, whose C<$.text> is the label. )
class Span {
	#| Verbatim, including whitespace. Never the empty string.
	has Str:D $.text is required;
	has Bool:D $.bold = False;
	has Bool:D $.italic = False;
	#| A code span. Its text was never lexed for styles, but it can still be
	#| bold or italic from the emphasis it sits inside.
	has Bool:D $.code = False;
	#| The link destination, or undefined. Link spans are never merged with
	#| their neighbours, so one link is always exactly one span.
	has Str $.link;

	method gist(--> Str:D) {
		my $flags = ($!bold ?? 'b' !! '') ~ ($!italic ?? 'i' !! '')
			~ ($!code ?? 'c' !! '');
		'Span(' ~ $!text.raku
			~ ($flags ne '' ?? " :$flags" !! '')
			~ ($!link.defined ?? " ->$!link" !! '') ~ ')';
	}
}

#|( The base of the block taxonomy. Never produced on its own: it exists so a
    consumer can type a signature, and so an unhandled C<when> is a compile-time
    question rather than a runtime surprise. )
class Block {
	method gist(--> Str:D) { '[' ~ self.^name.subst('Markdown::Lex::', '').lc ~ ']' }
}

#| An ATX heading: C<# Title> through C<###### Title>.
class Heading is Block {
	#| 1 through 6. Seven hashes is a paragraph, not a heading.
	has Int:D $.level is required where 1 <= * <= 6;
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) { "[h$!level] " ~ preview(@!inlines) }
}

#| A run of ordinary text. The default block: anything structural is one of the
#| others, and everything else lands here.
class Para is Block {
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) { '[para] ' ~ preview(@!inlines) }
}

#|( A fenced code block. The contents are never lexed — C<@.lines> is exactly
    what was between the fences, Markdown syntax and all — and C<$.closed> tells
    a streaming renderer whether the closing fence has arrived yet. )
class CodeFence is Block {
	#| The first word of the info string, or undefined when there wasn't one.
	has Str $.lang;
	#| One Str per line, with no trailing newlines.
	has @.lines;
	#| False for a fence still waiting for its closing line at end of input.
	has Bool:D $.closed is required;

	submethod TWEAK { @!lines := @!lines.List }

	method gist(--> Str:D) {
		'[code' ~ ($!lang.defined ?? " lang=$!lang" !! '')
			~ " lines={@!lines.elems}" ~ ($!closed ?? '' !! ' unclosed') ~ ']';
	}
}

#|( One list item, flattened. There is no list block and no nesting: a
    consumer draws each bullet at C<$.depth> and the shape falls out. )
class Bullet is Block {
	#| Leading indentation over two, floored. Zero for a top-level item.
	has Int:D $.depth where * >= 0 = 0;
	#| The marker as written: C<->, C<*>, C<+>, C<1.>, C<2)>, ...
	has Str:D $.marker is required;
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) {
		"[bullet d$!depth $!marker] " ~ preview(@!inlines);
	}
}

#| A block quote. Consecutive quoted lines are one of these.
class Quote is Block {
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) { '[quote] ' ~ preview(@!inlines) }
}

#| A thematic break.
class Rule is Block {
	method gist(--> Str:D) { '[rule]' }
}

# ---------------------------------------------------------------------------
# Inline lexing
#
# Three passes over one line's worth of text:
#
#   1. tokenize   - resolve code spans and links (which are atomic and win over
#                   everything), and reduce every run of `*` or `_` to a
#                   delimiter node that knows whether it may open and/or close.
#   2. emphasise  - CommonMark's delimiter-stack match, recording each matched
#                   pair as an interval rather than building a tree.
#   3. build      - prefix-sum the intervals into per-node flags and emit merged
#                   Spans.
#
# The interval trick is what keeps the output flat and the code non-recursive:
# a node inside three nested emphasis pairs simply has three intervals covering
# it, and bold/italic are booleans, not a stack.
# ---------------------------------------------------------------------------

#| A tokenizer node: literal text, a resolved atom (code span or link), or an
#| unresolved delimiter run.
my class Node {
	has Str $.kind is required;      # 'text' | 'atom' | 'delim'
	has Str $.text = '';
	has Bool $.code = False;
	has Str $.link;

	# delimiter bookkeeping, unused for the other kinds
	has Str $.dchar;
	has Int $.orig = 0;
	has Int $.remaining is rw = 0;
	has Bool $.can-open = False;
	has Bool $.can-close = False;
	has Bool $.active is rw = True;
}

my sub is-space(Str $c --> Bool:D) { $c.defined && so $c ~~ /\s/ }

my sub is-alnum(Str $c --> Bool:D) { $c.defined && so $c ~~ / ^ <+:L +:N> $ / }

#| Length of the run of C<$ch> starting at C<$i>.
my sub run-length(@c, Int $i, Str $ch --> Int:D) {
	my $n = 0;
	$n++ while $i + $n < @c.elems && @c[$i + $n] eq $ch;
	$n;
}

#| Index of the start of the next run of B<exactly> C<$n> backticks at or after
#| C<$from>, or Nil. Runs of a different length are skipped whole, which is what
#| makes C<``a `b` c``> one span.
my sub find-code-close(@c, Int $from, Int $n) {
	my $i = $from;
	while $i < @c.elems {
		if @c[$i] eq '`' {
			my $len = run-length(@c, $i, '`');
			return $i if $len == $n;
			$i += $len;
		}
		else {
			$i++;
		}
	}
	Nil;
}

#|( Pair up every C<[>/C<]> and C<(>/C<)> in one left-to-right pass, skipping
    code spans so that C<[a `]` b](u)> reads the way it looks.

    A stack pairs each opener with the position where a local scan would have
    seen its depth return to zero, which is the same answer C<try-link> used to
    compute for itself — but once for the whole line instead of once per
    bracket, which is the difference between linear and quadratic on a line
    that is five thousand unmatched C<[>. )
my sub match-pairs(@c --> List) {
	my %bracket;
	my %paren;
	my @bstack;
	my @pstack;
	my $i = 0;
	while $i < @c.elems {
		my $ch = @c[$i];
		if $ch eq '`' {
			my $n = run-length(@c, $i, '`');
			my $j = find-code-close(@c, $i + $n, $n);
			$i = $j.defined ?? $j + $n !! $i + $n;
			next;
		}
		if $ch eq '[' { @bstack.push: $i }
		elsif $ch eq ']' { %bracket{@bstack.pop} = $i if @bstack }
		elsif $ch eq '(' { @pstack.push: $i }
		elsif $ch eq ')' { %paren{@pstack.pop} = $i if @pstack }
		$i++;
	}
	(%bracket, %paren);
}

#|( Try to read C<[text](dest)> starting at C<$start>, using the pairings from
    C<match-pairs>. Returns a Hash with C<text>, C<url> and C<next>, or Nil when
    this is just a stray bracket. )
my sub try-link(@c, Int $start, %bracket, %paren) {
	my $close = %bracket{$start};
	return Nil unless $close.defined;
	return Nil unless $close + 1 < @c.elems && @c[$close + 1] eq '(';

	my $end = %paren{$close + 1};
	return Nil unless $end.defined;

	my $text = @c[$start + 1 ..^ $close].join;
	my $dest = @c[$close + 2 ..^ $end].join.trim;
	if $dest.starts-with('<') && $dest.index('>').defined {
		# `<...>` wins over the whitespace rule: this is exactly how you write
		# a destination that contains a space.
		$dest = $dest.substr(1, $dest.index('>') - 1);
	}
	elsif $dest ~~ /\s/ {
		# `[a](url "title")` - the title is not ours to keep.
		$dest = $dest.words.head // '';
	}
	return Nil if $text eq '' && $dest eq '';

	{ text => ($text ne '' ?? $text !! $dest), url => $dest, next => $end + 1 };
}

#| Pass 1. Text, atoms and delimiter runs, in source order.
my sub tokenize(@c --> Array) {
	my Node @nodes;
	# Only a `[` can start a link, and the paren map exists only to finish one.
	my (%bracket, %paren) := @c.first('[', :k).defined ?? match-pairs(@c) !! ({}, {});
	my $run-start = 0;
	my $i = 0;

	my sub flush-text($upto) {
		return if $upto <= $run-start;
		@nodes.push: Node.new(kind => 'text', text => @c[$run-start ..^ $upto].join);
	}

	while $i < @c.elems {
		my $ch = @c[$i];

		if $ch eq '`' {
			my $n = run-length(@c, $i, '`');
			my $j = find-code-close(@c, $i + $n, $n);
			if $j.defined {
				flush-text($i);
				my $content = @c[$i + $n ..^ $j].join;
				# One space of padding on both sides is how you write a code
				# span whose content starts or ends with a backtick.
				if $content.chars >= 2 && $content.starts-with(' ')
					&& $content.ends-with(' ') && $content ~~ /\S/ {
					$content = $content.substr(1, $content.chars - 2);
				}
				@nodes.push: Node.new(kind => 'atom', text => $content, code => True)
					if $content ne '';
				$i = $j + $n;
				$run-start = $i;
			}
			else {
				$i += $n;      # literal backticks, left in the text run
			}
		}
		elsif $ch eq '[' {
			my $link = try-link(@c, $i, %bracket, %paren);
			if $link {
				flush-text($i);
				@nodes.push: Node.new(
					kind => 'atom', text => $link<text>, link => $link<url>);
				$i = $link<next>;
				$run-start = $i;
			}
			else {
				$i++;          # literal bracket
			}
		}
		elsif $ch eq '*' || $ch eq '_' {
			my $n = run-length(@c, $i, $ch);
			my $prev = $i > 0 ?? @c[$i - 1] !! Str;
			my $next = $i + $n < @c.elems ?? @c[$i + $n] !! Str;
			my $can-open = $next.defined && !is-space($next);
			my $can-close = $prev.defined && !is-space($prev);
			if $ch eq '_' {
				# Underscores never emphasise inside a word, which is the only
				# reason `snake_case_name` survives contact with this module.
				$can-open = $can-open && !is-alnum($prev);
				$can-close = $can-close && !is-alnum($next);
			}
			flush-text($i);
			@nodes.push: Node.new(
				kind => 'delim', dchar => $ch, orig => $n, remaining => $n,
				:$can-open, :$can-close);
			$i += $n;
			$run-start = $i;
		}
		else {
			$i++;
		}
	}
	flush-text(@c.elems);
	@nodes;
}

#|( Pass 2. CommonMark's process-emphasis, with matched pairs recorded into two
    difference arrays instead of a tree.

    Returns C<(@bold-delta, @italic-delta)>, each one longer than C<@nodes>, to
    be prefix-summed by the builder. )
my sub emphasise(Node @nodes) {
	my @bold = 0 xx (@nodes.elems + 1);
	my @italic = 0 xx (@nodes.elems + 1);

	my Int @delims = @nodes.keys.grep({ @nodes[$_].kind eq 'delim' });
	return (@bold, @italic) unless @delims;

	# The still-matchable delimiters, as a doubly linked list over positions in
	# @delims. Walking it instead of the raw array is what keeps the backward
	# opener scan and the "everything between a matched pair is dead" sweep
	# amortized linear: an entry is unlinked at most once, ever.
	my Int @prv = (-1 ..^ @delims.end);
	my Int @nxt = (1 .. @delims.elems);
	my sub unlink-delim(Int $k) {
		my $p = @prv[$k];
		my $n = @nxt[$k];
		@nxt[$p] = $n if $p >= 0;
		@prv[$n] = $p if $n < @delims.elems;
		@nodes[@delims[$k]].active = False;
	}

	# CommonMark's openers_bottom: once a closer of a given shape has failed to
	# find any opener below some point, no later closer of that shape can
	# either. Without this the backward scan is quadratic on a wall of
	# unmatchable delimiters.
	my %bottom;

	for @delims.kv -> $ci, $cidx {
		my $closer = @nodes[$cidx];
		next unless $closer.can-close && $closer.active;

		while $closer.remaining > 0 {
			my $key = $closer.dchar ~ ($closer.can-open ?? '1' !! '0')
				~ ($closer.orig % 3);
			my $bottom = %bottom{$key} // 0;
			my $found;

			loop (my $oi = @prv[$ci]; $oi >= $bottom; $oi = @prv[$oi]) {
				my $o = @nodes[@delims[$oi]];
				next unless $o.remaining > 0 && $o.can-open
					&& $o.dchar eq $closer.dchar;
				# CommonMark's "rule of three": when either delimiter of a pair
				# can do both jobs, their original lengths may not sum to a
				# multiple of three unless both are multiples of three. This is
				# what makes `*foo**bar**baz*` come out right.
				next if ($o.can-close || $closer.can-open)
					&& (($o.orig + $closer.orig) %% 3)
					&& !($o.orig %% 3 && $closer.orig %% 3);
				$found = $oi;
				last;
			}

			unless $found.defined {
				%bottom{$key} = $ci;
				last;
			}

			my $oidx = @delims[$found];
			my $opener = @nodes[$oidx];
			my $use = ($opener.remaining >= 2 && $closer.remaining >= 2) ?? 2 !! 1;
			$opener.remaining -= $use;
			$closer.remaining -= $use;

			# The interval covers the nodes strictly between the two delimiter
			# nodes; leftover delimiter characters live on the nodes themselves
			# and are correctly left outside.
			if $use == 2 {
				@bold[$oidx + 1]++;
				@bold[$cidx]--;
			}
			else {
				@italic[$oidx + 1]++;
				@italic[$cidx]--;
			}

			# Anything between the pair can never match anything again.
			my $between = @nxt[$found];
			while $between < $ci {
				my $after = @nxt[$between];
				unlink-delim($between);
				$between = $after;
			}

			unlink-delim($found) unless $opener.remaining;
			unless $closer.remaining {
				unlink-delim($ci);
				last;
			}
		}
	}

	(@bold, @italic);
}

#| Pass 3. Prefix-sum the intervals, drop empties, merge neighbours.
my sub build-spans(Node @nodes, @bold-delta, @italic-delta --> List) {
	my @raw;                        # [text, bold, italic, code, link]
	my $bold = 0;
	my $italic = 0;

	for @nodes.kv -> $k, $node {
		$bold += @bold-delta[$k];
		$italic += @italic-delta[$k];

		my $text = $node.kind eq 'delim'
			?? $node.dchar x $node.remaining
			!! $node.text;
		next if $text eq '';

		my $b = $bold > 0;
		my $i = $italic > 0;

		if @raw && !@raw[*-1][4].defined && !$node.link.defined
			&& @raw[*-1][1] === $b && @raw[*-1][2] === $i
			&& @raw[*-1][3] === $node.code {
			@raw[*-1][0] ~= $text;
		}
		else {
			@raw.push: [$text, $b, $i, $node.code, $node.link];
		}
	}

	@raw.map({
		Span.new(
			text => .[0], bold => .[1], italic => .[2], code => .[3], link => .[4])
	}).List;
}

#| The four characters that can start something other than plain text.
my constant MARKUP-START = / <[ * _ ` \[ ]> /;

#| The whole inline pipeline, for one block's worth of already-joined text.
my sub lex-inline(Str $text --> List) {
	return () unless $text.defined && $text ne '';
	# By far the most common block is one with no markup in it at all, and that
	# case is worth answering without combing, tokenizing or allocating.
	return (Span.new(text => $text),) unless $text ~~ MARKUP-START;
	my @c = $text.comb;
	my Node @nodes = tokenize(@c);
	my ($bold, $italic) = emphasise(@nodes);
	build-spans(@nodes, $bold, $italic);
}

# ---------------------------------------------------------------------------
# Block lexing
# ---------------------------------------------------------------------------

#|( Split a line into its indentation width and the rest. Tabs advance to the
    next four-column stop, which is the only place this module thinks about
    tabs at all. )
my sub split-indent(Str $line --> List) {
	my $col = 0;
	my $i = 0;
	my $chars = $line.chars;
	while $i < $chars {
		my $c = $line.substr($i, 1);
		if $c eq ' ' { $col++ }
		elsif $c eq "\t" { $col += 4 - ($col % 4) }
		else { last }
		$i++;
	}
	# The overwhelmingly common case is no indentation at all, and the whole
	# point of not combing the line is to not copy it either.
	($col, $i == 0 ?? $line !! $line.substr($i));
}

#| Remove up to C<$width> columns of leading whitespace, tab stops included.
my sub strip-indent(Str $line, Int $width --> Str:D) {
	return $line if $width <= 0;
	my $col = 0;
	my $i = 0;
	my $chars = $line.chars;
	while $i < $chars && $col < $width {
		my $c = $line.substr($i, 1);
		if $c eq ' ' { $col++ }
		elsif $c eq "\t" { $col += 4 - ($col % 4) }
		else { last }
		$i++;
	}
	$i == 0 ?? $line !! $line.substr($i);
}

my sub is-blank(Str $line --> Bool:D) { $line !~~ /\S/ }

#|( An opening code fence, as C<(char, len, lang)>, or Nil.

    A backtick fence may not carry a backtick in its info string — that rule is
    what keeps C<```inline``` in a sentence> a paragraph rather than a fence
    swallowing the rest of the document. )
my sub match-fence(Str $rest) {
	return Nil unless $rest.starts-with('`') || $rest.starts-with('~');
	my $char = $rest.substr(0, 1);
	my $len = 0;
	$len++ while $len < $rest.chars && $rest.substr($len, 1) eq $char;
	return Nil if $len < 3;
	my $info = $rest.substr($len).trim;
	return Nil if $char eq '`' && $info.contains('`');
	my $lang = $info eq '' ?? Str !! $info.words.head;
	($char, $len, $lang);
}

#| Does this line close a fence of C<$char> x C<$len>?
my sub is-fence-close(Str $rest, Str $char, Int $len --> Bool:D) {
	my $n = 0;
	$n++ while $n < $rest.chars && $rest.substr($n, 1) eq $char;
	$n >= $len && $rest.substr($n).trim eq '';
}

#| An ATX heading, as C<(level, text)>, or Nil.
my sub match-heading(Str $rest) {
	return Nil unless $rest.starts-with('#');
	my $level = 0;
	$level++ while $level < $rest.chars && $rest.substr($level, 1) eq '#';
	return Nil unless 1 <= $level <= 6;
	my $tail = $rest.substr($level);
	return Nil unless $tail eq '' || $tail.starts-with(' ') || $tail.starts-with("\t");
	my $text = $tail.trim;
	# Closing sequence: `## Title ##`, and the degenerate `## ##`.
	if $text ~~ / ^ '#'+ $ / {
		$text = '';
	}
	else {
		$text = $text.subst(/ \s '#'+ $ /, '').trim;
	}
	($level, $text);
}

#| Three or more of one of C<-*_>, alone on the line bar spaces.
my sub is-rule(Str $rest --> Bool:D) {
	my $first = $rest.substr(0, 1);
	return False unless $first eq '-' || $first eq '*' || $first eq '_';
	my $count = 0;
	my $chars = $rest.chars;
	loop (my $i = 0; $i < $chars; $i++) {
		my $c = $rest.substr($i, 1);
		next if $c eq ' ' || $c eq "\t";
		return False unless $c eq $first;
		$count++;
	}
	$count >= 3;
}

#| A list marker, as C<(marker, text)>, or Nil. C<$rest> is already unindented.
my sub match-bullet(Str $rest) {
	my $first = $rest.substr(0, 1);
	if $first eq '-' || $first eq '+' || $first eq '*' {
		my $after = $rest.substr(1, 1);
		return Nil unless $after eq '' || $after eq ' ' || $after eq "\t";
		return ($first, $rest.substr(1).trim);
	}
	if $first ~~ / ^ \d $ / && $rest ~~ / ^ (\d+ <[.)]>) / {
		my $marker = ~$0;
		my $tail = $rest.substr($marker.chars);
		return Nil unless $tail eq '' || $tail.substr(0, 1) ~~ /\s/;
		return ($marker, $tail.trim);
	}
	Nil;
}

#| The content of a quote line, or Nil when this isn't one.
my sub match-quote(Str $rest) {
	return Nil unless $rest.starts-with('>');
	my $body = $rest.substr(1);
	$body = $body.substr(1) if $body.starts-with(' ');
	$body;
}

#|( Lex Markdown into a flat, immutable C<List> of block objects.

    Total: every input produces a List, including C<Str:U> and C<''> (both give
    the empty List). Prefix-stable: lexing any prefix of a document succeeds and
    degrades unterminated constructs to literal text or, for a code fence, to a
    block with C<:!closed>.

    =begin code :lang<raku>
    my @blocks = parse("- one\n- two\n\n> quoted **hard**\n");
    @blocks.map(*.gist).join("\n");
    # [bullet d0 -] one
    # [bullet d0 -] two
    # [quote] quoted hard
    =end code )
our sub parse(Str $text --> List) is export {
	return () unless $text.defined;
	# Literal Str needles, not a regex: Raku stores CR LF as a single grapheme,
	# so /\r\n/ never matches one and /\n/ never finds one either.
	my $norm = $text.subst("\r\n", "\n", :g).subst("\r", "\n", :g);
	return () if $norm eq '';

	my @lines = $norm.split("\n");
	# A trailing newline ends the last line; it does not begin an empty one.
	@lines.pop if @lines && @lines[*-1] eq '';

	my @blocks;

	# The block currently being accumulated, if any. Kinds: para, quote, bullet.
	my $open-kind;
	my @open-lines;
	my $open-depth = 0;
	my $open-marker = '';

	my sub flush() {
		return unless $open-kind.defined;
		my $joined = @open-lines.grep({ $_ ne '' }).join(' ');
		my @inlines = lex-inline($joined);
		given $open-kind {
			when 'para' {
				@blocks.push: Para.new(:@inlines);
			}
			when 'quote' {
				@blocks.push: Quote.new(:@inlines);
			}
			when 'bullet' {
				@blocks.push: Bullet.new(
					depth => $open-depth, marker => $open-marker, :@inlines);
			}
		}
		$open-kind = Nil;
		@open-lines = ();
		$open-depth = 0;
		$open-marker = '';
	}

	my $i = 0;
	while $i < @lines.elems {
		my $line = @lines[$i];

		if is-blank($line) {
			flush();
			$i++;
			next;
		}

		my ($indent, $rest) = split-indent($line);

		with match-fence($rest) -> ($char, $len, $lang) {
			flush();
			my @content;
			my $closed = False;
			my $j = $i + 1;
			while $j < @lines.elems {
				my $frest = split-indent(@lines[$j])[1];
				if is-fence-close($frest, $char, $len) {
					$closed = True;
					$j++;
					last;
				}
				@content.push: strip-indent(@lines[$j], $indent);
				$j++;
			}
			@blocks.push: CodeFence.new(:$lang, lines => @content, :$closed);
			$i = $j;
			next;
		}

		with match-heading($rest) -> ($level, $htext) {
			flush();
			@blocks.push: Heading.new(:$level, inlines => lex-inline($htext));
			$i++;
			next;
		}

		if is-rule($rest) {
			flush();
			@blocks.push: Rule.new;
			$i++;
			next;
		}

		with match-bullet($rest) -> ($marker, $btext) {
			flush();
			$open-kind = 'bullet';
			$open-depth = ($indent / 2).Int;
			$open-marker = $marker;
			@open-lines = ($btext,);
			$i++;
			next;
		}

		with match-quote($rest) -> $qtext {
			flush() unless $open-kind.defined && $open-kind eq 'quote';
			$open-kind = 'quote';
			@open-lines.push: $qtext.trim;
			$i++;
			next;
		}

		# Ordinary text: continues an open paragraph or bullet, otherwise opens
		# a paragraph. A quote is not continued lazily.
		flush() if $open-kind.defined && $open-kind eq 'quote';
		$open-kind //= 'para';
		@open-lines.push: $line.trim;
		$i++;
	}
	flush();

	@blocks.List;
}
