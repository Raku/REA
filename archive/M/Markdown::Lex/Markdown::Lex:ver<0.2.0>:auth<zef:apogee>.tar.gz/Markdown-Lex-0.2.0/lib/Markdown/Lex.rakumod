=begin pod

=head1 NAME

Markdown::Lex - a total, streaming-tolerant Markdown lexer: typed blocks and
flat styled spans, no renderer attached

=head1 SYNOPSIS

=begin code :lang<raku>

use Markdown::Lex;

for parse("# Title\n\nHello **world** and `code`.\n") -> $block {
    given $block {
        when Markdown::Lex::Heading {
            say "H{$block.level}: ", $block.inlines».text.join;
        }
        when Markdown::Lex::Para {
            for $block.inlines -> $span {
                print bold($span.text)   if $span.bold;
                print italic($span.text) if $span.italic;
                print plain($span.text)  unless $span.bold || $span.italic;
            }
        }
    }
}

=end code

=head1 DESCRIPTION

A lexer for the Markdown a language model actually emits, aimed at a terminal
renderer that has to draw the text I<while it is still arriving>.

Two properties drive every design decision in here:

=item B<It is total.> C<parse> never throws. Not on C<Str:U>, not on the empty
string, not on a document that is one unterminated code fence, not on ten
thousand asterisks in a row. Whatever comes in, a C<List> of blocks comes out.

=item B<It is prefix-stable.> Every prefix of a document is itself a valid
document. A consumer that re-lexes the accumulated text on every token batch
never sees an error and never sees text I<vanish> — a half-typed C<**bo> is
literal text until the closing C<**> arrives, at which point it becomes bold.

Everything else — colour, wrapping, indentation, hyperlink escape sequences,
whether C<code> gets a background — belongs to the renderer. This module has no
opinion and no dependencies.

=head1 THE OUTPUT

C<parse> returns an immutable C<List> of block objects. Every block is a
C<Markdown::Lex::Block>, is immutable, and has a useful C<.gist>:

=begin table

Class                       | Attributes
============================|=====================================================
Markdown::Lex::Heading      | C<Int:D $.level> (1..6), C<@.inlines>
Markdown::Lex::Para         | C<@.inlines>
Markdown::Lex::CodeFence    | C<Str $.lang>, C<@.lines>, C<Bool:D $.closed>
Markdown::Lex::Bullet       | C<Int:D $.depth> (0-based), C<Str:D $.marker>, C<@.inlines>
Markdown::Lex::Quote        | C<@.inlines>
Markdown::Lex::Rule         | (none)
Markdown::Lex::Table        | C<@.alignments>, C<@.header>, C<@.rows>, C<.columns>

=end table

The classes are plain global names. C<use Markdown::Lex;> exports exactly one
symbol — the C<parse> sub — and the classes are reachable fully qualified,
which is what you want in a C<given>/C<when> anyway.

A table's cells are C<Markdown::Lex::Cell>, which is B<not> a Block — it is a
holder for one cell's C<@.inlines> and nothing else. See L<#TABLES>.

=head2 Spans are flat, not a tree

C<@.inlines> is a flat list of C<Markdown::Lex::Span>, never a tree:

=begin code :lang<raku>

class Markdown::Lex::Span {
    has Str:D  $.text is required;
    has Bool:D $.bold   = False;
    has Bool:D $.italic = False;
    has Bool:D $.code   = False;
    has Str    $.link;              # undefined unless this span is a link
}

=end code

Nesting is expressed by I<combining flags>, because that is exactly what a
terminal can draw. C<**bold with *both* inside**> lexes to three spans:

=begin code :lang<raku>

my @spans = parse("**bold with *both* inside**").head.inlines;

@spans[0];   # Span("bold with " :b)
@spans[1];   # Span("both" :bi)
@spans[2];   # Span(" inside" :b)

=end code

There is therefore no nesting depth limit, and no recursion: twenty levels of
emphasis saturate at C<bold + italic> and cost nothing. Adjacent runs with
identical flags are merged, and a span with empty text is never emitted, so a
renderer can loop over C<@.inlines> without defensive checks.

The span vocabulary has exactly one other member, and you only ever meet it if
you asked for it: C<Markdown::Lex::Break>, a zero-text C<Span> subclass emitted
under C<parse>'s C<:hard-breaks> option to mark a newline the author meant. A
renderer that has never heard of it prints C<.text> and draws nothing, which is
why it is a C<Span> and not a class of its own. See L<#HARD LINE BREAKS>.

=head1 STREAMING

The prefix guarantee, as a consumer uses it:

=begin code :lang<raku>

my $accumulated = '';

react whenever $token-supply -> $chunk {
    $accumulated ~= $chunk;
    render(parse($accumulated));       # always safe, always sensible
}

=end code

Mid-stream constructs degrade gracefully rather than disappearing:

=begin table

Partial text            | What you get while it is partial
========================|==========================================================
C<**bo>                 | one literal span C<"**bo">
C<``` then code lines>  | a CodeFence with C<:!closed> that grows line by line
C<[label](htt>          | one literal span C<"[label](htt">
C<`unfinished>          | one literal span C<"`unfinished">

=end table

A pipe table takes two lines before it is a table at all, so what it degrades to
is an honest paragraph rather than a placeholder:

=begin code :lang<raku>

parse("| a | b |");             # one Para: a header row on its own is text
parse("| a | b |\n|---");       # one Para: one delimiter cell, two header cells
parse("| a | b |\n|-|-");       # a Table, two columns wide, with no rows yet

=end code

C<CodeFence.closed> is the one place the distinction is surfaced deliberately:
a renderer can draw an unclosed fence with a "still writing" affordance, and it
will close itself when the final C<```> arrives.

=head1 WHAT IT LEXES

=head2 Blocks

=item B<ATX headings> — one to six C<#> followed by a space (or end of line, for
an empty heading). A trailing run of C<#> is stripped: C<"## Title ##"> is
C<Title>.

=item B<Fenced code> — three or more backticks or tildes. The first word of the
info string becomes C<$.lang> (undefined when absent). The fence closes on a
line of the same character, at least as long, with nothing else on it. An
unclosed fence at end of input is still a C<CodeFence>, with C<:!closed>. The
opening fence's indentation is stripped from the content lines; everything else
about them is verbatim, Markdown syntax included.

=item B<Bullets> — C<->, C<*> or C<+>, or an ordinal (C<1.>, C<2)>, C<17.>),
followed by a space. C<$.marker> is the marker exactly as written, so a renderer
can keep the author's numbering. C<$.depth> is the leading indentation divided
by two, floored: zero, two, four... spaces are depths 0, 1, 2, and a tab counts
as however many columns it takes to reach the next four-column stop. A following
non-blank, non-structural line continues the bullet rather than starting a
paragraph.

=item B<Quotes> — a leading C<< > >>, with or without the space after it.
Consecutive quote lines merge into one C<Quote>.

=item B<Rules> — three or more C<->, C<*> or C<_> alone on a line, spaces
allowed between them. This wins over the bullet reading, so C<- - -> is a rule,
as CommonMark says.

=item B<Tables> — a row of pipe-separated cells with a delimiter row under it.
Both lines have to carry a pipe, and the two have to agree on how many columns
there are; without that the header row is ordinary paragraph text. L<#TABLES>
has the whole of it.

=item B<Paragraphs> — everything else. Consecutive non-blank, non-structural
lines merge into one C<Para> and the line breaks between them become single
spaces. A blank line ends whatever block is open.

=head2 Inline

=begin code :lang<raku>

parse('`code`').head.inlines;             # Span("code" :c)
parse('**bold**').head.inlines;           # Span("bold" :b)
parse('*italic*').head.inlines;           # Span("italic" :i)
parse('_italic_').head.inlines;           # Span("italic" :i)
parse('__bold__').head.inlines;           # Span("bold" :b)
parse('***both***').head.inlines;         # Span("both" :bi)
parse('[docs](http://x)').head.inlines;   # Span("docs" ->http://x)

=end code

Code spans take a run of I<N> backticks and close on the next run of exactly
I<N>, so C<``a `b` c``> is one code span containing C<a `b` c>. The content is
verbatim: no emphasis, no links, no escapes. One leading and one trailing space
are dropped if both are present, which is how you write a code span containing
a backtick.

Emphasis follows CommonMark's delimiter-run rules closely enough that the cases
which bite in practice come out right:

=begin code :lang<raku>

parse('*a **b** c*').head.inlines;    # "a " :i / "b" :bi / " c" :i
parse('**a*').head.inlines;           # "*" / "a" :i        (leftover is literal)
parse('a * b * c').head.inlines;      # one literal span    (space-flanked)
parse('snake_case_name').head.inlines;# one literal span    (intraword _)
parse('foo*bar*baz').head.inlines;    # "foo" / "bar" :i / "baz"

=end code

Links are C<[text](destination)>. The destination may be wrapped in angle
brackets, and a title after it is discarded. The bracket text is B<not> lexed
for styles — the span's C<.text> is exactly what you wrote between the brackets
— but it does inherit the emphasis it sits inside, so a link inside C<**...**>
comes back bold. C<[](url)> renders the URL as its own label.

An unmatched delimiter is I<always> literal text. Nothing is ever dropped.

=head1 TABLES

A GFM pipe table is a header row, a B<delimiter row> underneath it that gives
every column its alignment, and any number of body rows:

=begin code :lang<raku>

my $table = parse(q:to/MD/).head;
    | Package | Version | Status  |
    |:--------|:-------:|--------:|
    | Selkie  | 0.13.0  | shipped |
    | Sadna   | 0.2.0   | soon    |
    MD

$table.columns;                          # 3
$table.alignments;                       # ("left", "center", "right")
$table.header[0].inlines».text.join;     # "Package"
$table.rows.elems;                       # 2
$table.rows[1][2].inlines».text.join;    # "soon"
$table.gist;                     # "[table 3x2] Package | Version | Status"

=end code

The three attributes are rectangular by construction: C<@.alignments>,
C<@.header> and every row in C<@.rows> are all C<.columns> long, always, so a
renderer can zip a row against the alignments without counting or guarding
anything.

C<@.alignments> holds plain lowercase strings — C<'left'>, C<'center'> or
C<'right'> — rather than an enum, so that a C<when 'center'> in a renderer
needs no import and a debug dump reads as itself. A delimiter cell with no
colons is C<'left'>, because that is what every renderer draws it as.

=head2 What makes a table

Two lines, checked together:

=item The B<header row> is any line with an unescaped pipe in it that is not
already something else. Structural markers win, so C<< - a | b >> is a bullet
and C<< > a | b >> is a quote, whatever sits under them.

=item The B<delimiter row> is the line directly below, split into cells the same
way. Every cell must be a run of one or more C<-> with an optional leading
and/or trailing C<:>, and there must be exactly as many of them as the header
had. It must contain a pipe of its own, which is what keeps C<---> a thematic
break and C<-> a bullet instead of turning every dash under a piped line into a
one-column table.

=begin code :lang<raku>

parse("a | b\n---|---");       # a Table: 2 header cells, 2 delimiter cells
parse("a | b\n---");           # a Para and a Rule: one delimiter cell, not two
parse("| a | b |\n|- - -|-|"); # one Para: spaces are not allowed in a delimiter
parse("| a |\n|-|");           # a Table, one column wide
parse("a\n-|-");               # one Para of both lines: the header has no pipe

=end code

Alignment comes from the colons: C<:---> and C<---> are C<'left'>, C<:---:> is
C<'center'>, C<---:> is C<'right'>. A single C<-> is a perfectly good delimiter
cell, so C<|-|-|> is the shortest two-column table you can write.

A table interrupts an open paragraph, as GFM says it does — the paragraph is
closed above it and the table starts:

=begin code :lang<raku>

parse("intro\n| a | b |\n|-|-|").map(*.gist);
# [para] intro
# [table 2x0] a | b

=end code

=head2 Cells

Cells are trimmed, and the outer pipes are the table's punctuation rather than
empty cells: C<< | a | b | >>, C<< a | b >> and C<< | a | b >> are all the same
two cells. An empty cell that no outer pipe created survives, which is how you
write a trailing empty one:

=begin code :lang<raku>

parse("| a | |\n|-|-|").head.header».inlines».elems;   # (1, 0)

=end code

Each cell's C<@.inlines> is lexed exactly the way a paragraph's is — same
C<Markdown::Lex::Span>, same flags, same merging — so emphasis, code spans and
links inside a cell all work:

=begin code :lang<raku>

my $row = parse("| a | b |\n|-|-|\n| **hi** | [d](u) |").head.rows[0];
$row[0].inlines.head.gist;    # Span("hi" :b)
$row[1].inlines.head.gist;    # Span("d" ->u)

=end code

The order matters and is GFM's: B<cells are cut first, then each cell is lexed>.
A pipe inside a code span is therefore still a cell boundary —
C<< | `a|b` | >> is two cells holding C<`a> and C<b`> — which looks wrong for
about a second and is the only rule that can be implemented without lexing the
whole row twice. To put a pipe inside a cell, escape it:

=begin code :lang<raku>

parse("| a \\| b |\n|-|").head.header[0].inlines.head.text;   # "a | b"

=end code

C<\|> is the only backslash escape in this module (see L<#DIVERGENCES AND
NON-GOALS>), and it exists because there is otherwise no way at all to get a
pipe into a cell. It is recognised anywhere on a line, so a paragraph line whose
only pipes are escaped is not a header candidate at all.

=head2 Ragged rows

Rows are normalised to the header's width, which is GFM's rule: cells past the
last column are B<dropped>, and a row that stops early is padded with empty
cells.

=begin code :lang<raku>

my @rows = parse("| a | b |\n|-|-|\n| 1 | 2 | 3 |\n| 4 |").head.rows;
@rows[0]».inlines».elems;    # (1, 1)   -- the 3 went nowhere
@rows[1]».inlines».elems;    # (1, 0)   -- the missing cell is empty

=end code

This is the one place in the module where text goes in and does not come out,
and it is a deliberate divergence from "nothing is ever dropped": the
alternative — a row wider than its own table — pushes the problem onto every
renderer instead. A consumer that must not lose a keystroke should treat a
C<Table> as advisory and keep the source text, the way it already has to for the
C<:!closed> case.

=head2 Where a table ends

A table takes rows until one of these, whichever comes first:

=item a blank line,

=item a line with no unescaped pipe in it,

=item a line that opens a block of its own — a heading, a fence, a rule, a
bullet or a quote — even if it does have a pipe,

=item the end of the input.

=begin code :lang<raku>

parse("| a |\n|-|\n| 1 |\nprose").map(*.gist);
# [table 1x1] a
# [para] prose

=end code

That second rule is a deliberate divergence: C<cmark-gfm> reads a pipeless line
under a table as a one-cell row and pads the rest. Ending the table is the
better answer for text that is still arriving, where the line after a table is
almost always the next paragraph and swallowing it into the table makes the
whole screen jump.

=head2 A table while it is still arriving

The two-line rule falls out of prefix-stability rather than fighting it. Each
stage below is what C<parse> returns for that prefix, and no character of the
document is off the screen at any of them:

=begin code :lang<raku>

parse("| Name");                            # [para] | Name
parse("| Name | Age |");                    # [para] | Name | Age |
parse("| Name | Age |\n|-");                # [para] | Name | Age | |-
parse("| Name | Age |\n|-|-");              # [table 2x0] Name | Age
parse("| Name | Age |\n|-|-\n| Bob | 4 |"); # [table 2x1] Name | Age
parse("| Name | Age |\n|-|-\n| Bob | 4 |\n| Sue |");
                                            # [table 2x2] Name | Age

=end code

A renderer that draws C<.header> and C<.rows> as they are gets a table that
grows a row at a time and never redraws a cell it has already drawn.

=head1 HARD LINE BREAKS

C<parse> takes one option:

=begin code :lang<raku>

parse($text, :hard-breaks);

=end code

Off — the default, and byte-for-byte the behaviour described everywhere
else in this document — the newlines inside a paragraph, bullet or quote are
soft: the lines are joined with single spaces and lexed as one run of text,
because that
is what Markdown means by a line break.

On, every one of those newlines becomes a C<Markdown::Lex::Break> span sitting
between the two lines' spans:

=begin code :lang<raku>

parse("one\ntwo").head.inlines;                # Span("one two")
parse("one\ntwo", :hard-breaks).head.inlines;  # Span("one") Break Span("two")

=end code

It is for rendering text a human typed, where the newlines are where they
are on purpose — a chat message, a commit message, a form field — and joining
them into a wall of prose is visibly wrong. It changes nothing else: blank
lines still separate blocks, headings and rules are single lines anyway, a
C<CodeFence> was already line-faithful, and table cells never contain a
C<Break> because a row is a line.

A C<Break> has no text, no flags and no link, and it is the only span in the
module whose C<.text> is the empty string. Draw it as a newline; ignore it and
you get the old wall of prose back, minus the spaces.

=head2 Emphasis does not cross a hard break

Under C<:hard-breaks> each line is lexed on its own, so a delimiter cannot reach
across a newline to find its partner:

=begin code :lang<raku>

parse("**bold across\nthe break**").head.inlines;
# Span("bold across the break" :b)                 -- one bold span

parse("**bold across\nthe break**", :hard-breaks).head.inlines;
# Span("**bold across") Break Span("the break**")  -- literal, both halves

=end code

This diverges from GFM, where emphasis I<does> span a soft break. It is the
honest reading of what the option asks for — if a newline is a line break,
the line is the unit — and it is the cheap one: the alternative is lexing the
joined text and then mapping span offsets back onto lines, which is a second
model to keep correct for a case (emphasis opened on one line and closed on the
next) that human-typed text almost never contains. Both behaviours are pinned by
the test suite, so the divergence cannot drift.

Prefix-stability is unaffected, and for the same reason: the option changes only
how one block's already-collected lines are lexed.

=head1 DIVERGENCES AND NON-GOALS

Deliberately not implemented. Each of these degrades to literal text, which is
the only failure mode this module has:

=item Setext headings (C<Title> over C<=====>). C<---> after a paragraph is a
rule here, not an H2.

=item Indented (four-space) code blocks. There is consequently no four-space
cliff: structural markers are recognised at any indentation, and indentation
means depth for bullets and nothing anywhere else.

=item Images, raw HTML, autolinks, footnotes, reference links and entity
references. C<![alt](url)> lexes as a literal C<!> followed by a link.

=item Hard line breaks written as two trailing spaces, or as a trailing
backslash. Trailing whitespace is trimmed and that is the end of it — a
deliberate newline is asked for with C<:hard-breaks> (L<#HARD LINE BREAKS>),
which is honest about being a mode rather than pretending a renderer can see
invisible characters in a diff.

=item Backslash escapes, with exactly one exception: C<\|> inside a table row.
C<\*> is a backslash and an asterisk, and the asterisk still opens emphasis.

=item Nested block structure. A quote inside a quote, a list inside a quote, or
a fence inside a bullet are all lexed at the top level; C<Bullet.depth> is the
only nesting a consumer gets, and a second C<< > >> stays as literal text.

=item Lazy continuation into a quote. A non-quote line ends the quote and starts
a paragraph. (Bullets I<do> take continuation lines, because a soft-wrapped
bullet is common and losing the association is visibly wrong.)

Input normalisation is not a divergence but is worth stating: C<\r\n> and lone
C<\r> both become C<\n> on entry. These blocks describe something on a screen
and are never written back to disk, so there is nothing for the normalisation to
corrupt.

=head1 AUTHOR

Matt Doughty <matt@apogee.guru>

=head1 COPYRIGHT AND LICENSE

Copyright 2026 Matt Doughty

This library is free software; you can redistribute it and/or modify it under
the Artistic License 2.0.

=end pod

unit module Markdown::Lex;

#| How much of a block's text C<.gist> shows before it gives up and elides.
my constant GIST-WIDTH = 48;

#| The three column alignments a table's delimiter row can ask for.
my constant ALIGNMENTS = <left center right>;

#| One gist's worth of text, elided if it runs long.
my sub elide(Str $text --> Str:D) {
	$text.chars > GIST-WIDTH ?? $text.substr(0, GIST-WIDTH) ~ '…' !! $text;
}

#| The flat text of a span list, for gists and nothing else.
my sub preview(@inlines --> Str:D) { elide(@inlines.map(*.text).join) }

#|( One styled run of text. The atom of everything inline: a renderer walks a
    block's C<@.inlines> and draws each of these with whatever the flags mean on
    its output device.

    C<$.link> is the odd one out — it is undefined for ordinary text and holds
    the destination for a link, whose C<$.text> is the label. )
class Span {
	#| Verbatim, including whitespace. Never the empty string.
	has Str:D $.text is required;
	has Bool:D $.bold = False;
	has Bool:D $.italic = False;
	#| A code span. Its text was never lexed for styles, but it can still be
	#| bold or italic from the emphasis it sits inside.
	has Bool:D $.code = False;
	#| The link destination, or undefined. Link spans are never merged with
	#| their neighbours, so one link is always exactly one span.
	has Str $.link;

	method gist(--> Str:D) {
		my $flags = ($!bold ?? 'b' !! '') ~ ($!italic ?? 'i' !! '')
			~ ($!code ?? 'c' !! '');
		'Span(' ~ $!text.raku
			~ ($flags ne '' ?? " :$flags" !! '')
			~ ($!link.defined ?? " ->$!link" !! '') ~ ')';
	}
}

#|( A line break the author typed on purpose, produced only under C<parse>'s
    C<:hard-breaks> option. It carries no text: it is a marker sitting between
    two runs of spans saying "the newline here was meant".

    It is a C<Span> so that a renderer which has never heard of it keeps
    working — walking C<@.inlines> and printing C<.text> draws the empty
    string and nothing moves — while a renderer which has can C<when
    Markdown::Lex::Break> and start a new line. It is the one span whose text
    is empty, and it never carries a flag or a link. )
class Break is Span {
	method new(--> Break:D) { self.bless(text => '') }

	method gist(--> Str:D) { 'Break' }
}

#|( The base of the block taxonomy. Never produced on its own: it exists so a
    consumer can type a signature, and so an unhandled C<when> is a compile-time
    question rather than a runtime surprise. )
class Block {
	method gist(--> Str:D) { '[' ~ self.^name.subst('Markdown::Lex::', '').lc ~ ']' }
}

#| An ATX heading: C<# Title> through C<###### Title>.
class Heading is Block {
	#| 1 through 6. Seven hashes is a paragraph, not a heading.
	has Int:D $.level is required where 1 <= * <= 6;
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) { "[h$!level] " ~ preview(@!inlines) }
}

#| A run of ordinary text. The default block: anything structural is one of the
#| others, and everything else lands here.
class Para is Block {
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) { '[para] ' ~ preview(@!inlines) }
}

#|( A fenced code block. The contents are never lexed — C<@.lines> is exactly
    what was between the fences, Markdown syntax and all — and C<$.closed> tells
    a streaming renderer whether the closing fence has arrived yet. )
class CodeFence is Block {
	#| The first word of the info string, or undefined when there wasn't one.
	has Str $.lang;
	#| One Str per line, with no trailing newlines.
	has @.lines;
	#| False for a fence still waiting for its closing line at end of input.
	has Bool:D $.closed is required;

	submethod TWEAK { @!lines := @!lines.List }

	method gist(--> Str:D) {
		'[code' ~ ($!lang.defined ?? " lang=$!lang" !! '')
			~ " lines={@!lines.elems}" ~ ($!closed ?? '' !! ' unclosed') ~ ']';
	}
}

#|( One list item, flattened. There is no list block and no nesting: a
    consumer draws each bullet at C<$.depth> and the shape falls out. )
class Bullet is Block {
	#| Leading indentation over two, floored. Zero for a top-level item.
	has Int:D $.depth where * >= 0 = 0;
	#| The marker as written: C<->, C<*>, C<+>, C<1.>, C<2)>, ...
	has Str:D $.marker is required;
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) {
		"[bullet d$!depth $!marker] " ~ preview(@!inlines);
	}
}

#| A block quote. Consecutive quoted lines are one of these.
class Quote is Block {
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) { '[quote] ' ~ preview(@!inlines) }
}

#| A thematic break.
class Rule is Block {
	method gist(--> Str:D) { '[rule]' }
}

#|( One cell of a table. It holds spans rather than text so that C<**bold**>,
    C<`code`> and C<[links](u)> inside a cell reach the renderer exactly the way
    they do inside a paragraph: C<Cell.inlines> here I<is> C<Para.inlines>
    there, same class, same flat list, same guarantees.

    A cell is not a C<Block> — it has no standing of its own, and a consumer
    only ever meets one through a C<Table>. )
class Cell {
	#| A flat List of Span, empty for an empty cell. Never holds a Break: a
	#| table row is one line, so there is no newline in it to be hard.
	has @.inlines;

	submethod TWEAK { @!inlines := @!inlines.List }

	method gist(--> Str:D) { 'Cell(' ~ preview(@!inlines).raku ~ ')' }
}

#|( A GFM pipe table: a header row, a delimiter row that gave every column its
    alignment, and zero or more body rows.

    The three attributes are rectangular by construction — C<@.alignments>,
    C<@.header> and every row of C<@.rows> have the same length — so a
    renderer can zip them together without counting anything:

    =begin code :lang<raku>
    for @($table.rows) -> @row {
        for @row Z @($table.alignments) -> ($cell, $align) {
            print pad($cell.inlines».text.join, $align);
        }
    }
    =end code )
class Table is Block {
	#| One per column, and at least one: C<'left'>, C<'center'> or C<'right'>.
	#| A delimiter cell with no colons is C<'left'>, which is what every
	#| renderer draws it as anyway.
	has @.alignments;
	#| The header row: one C<Cell> per column.
	has @.header;
	#| The body: a List of rows, each a List of one C<Cell> per column. Empty
	#| for a table whose delimiter row has arrived but whose body has not.
	has @.rows;

	submethod TWEAK {
		@!alignments := @!alignments.List;
		@!header := @!header.List;
		@!rows := @!rows.map({ $_ ~~ Positional ?? .List !! ($_,) }).List;

		die 'a table needs at least one column' unless @!alignments;
		die "an alignment is one of {ALIGNMENTS.join(', ')}"
			unless @!alignments.all ~~ ALIGNMENTS.any;
		die 'a table header has exactly one cell per column'
			unless @!header.elems == @!alignments.elems;
		die 'a table cell is a Markdown::Lex::Cell' unless @!header.all ~~ Cell;
		for @!rows -> @row {
			die 'a table row has exactly one cell per column'
				unless @row.elems == @!alignments.elems;
			die 'a table cell is a Markdown::Lex::Cell' unless @row.all ~~ Cell;
		}
	}

	#| How many columns the delimiter row declared. Always one or more.
	method columns(--> Int:D) { @!alignments.elems }

	method gist(--> Str:D) {
		'[table ' ~ @!alignments.elems ~ 'x' ~ @!rows.elems ~ '] '
			~ elide(@!header.map({ .inlines.map(*.text).join }).join(' | '));
	}
}

# ---------------------------------------------------------------------------
# Inline lexing
#
# Three passes over one line's worth of text:
#
#   1. tokenize   - resolve code spans and links (which are atomic and win over
#                   everything), and reduce every run of `*` or `_` to a
#                   delimiter node that knows whether it may open and/or close.
#   2. emphasise  - CommonMark's delimiter-stack match, recording each matched
#                   pair as an interval rather than building a tree.
#   3. build      - prefix-sum the intervals into per-node flags and emit merged
#                   Spans.
#
# The interval trick is what keeps the output flat and the code non-recursive:
# a node inside three nested emphasis pairs simply has three intervals covering
# it, and bold/italic are booleans, not a stack.
# ---------------------------------------------------------------------------

#| A tokenizer node: literal text, a resolved atom (code span or link), or an
#| unresolved delimiter run.
my class Node {
	has Str $.kind is required;      # 'text' | 'atom' | 'delim'
	has Str $.text = '';
	has Bool $.code = False;
	has Str $.link;

	# delimiter bookkeeping, unused for the other kinds
	has Str $.dchar;
	has Int $.orig = 0;
	has Int $.remaining is rw = 0;
	has Bool $.can-open = False;
	has Bool $.can-close = False;
	has Bool $.active is rw = True;
}

my sub is-space(Str $c --> Bool:D) { $c.defined && so $c ~~ /\s/ }

my sub is-alnum(Str $c --> Bool:D) { $c.defined && so $c ~~ / ^ <+:L +:N> $ / }

#| Length of the run of C<$ch> starting at C<$i>.
my sub run-length(@c, Int $i, Str $ch --> Int:D) {
	my $n = 0;
	$n++ while $i + $n < @c.elems && @c[$i + $n] eq $ch;
	$n;
}

#| Index of the start of the next run of B<exactly> C<$n> backticks at or after
#| C<$from>, or Nil. Runs of a different length are skipped whole, which is what
#| makes C<``a `b` c``> one span.
my sub find-code-close(@c, Int $from, Int $n) {
	my $i = $from;
	while $i < @c.elems {
		if @c[$i] eq '`' {
			my $len = run-length(@c, $i, '`');
			return $i if $len == $n;
			$i += $len;
		}
		else {
			$i++;
		}
	}
	Nil;
}

#|( Pair up every C<[>/C<]> and C<(>/C<)> in one left-to-right pass, skipping
    code spans so that C<[a `]` b](u)> reads the way it looks.

    A stack pairs each opener with the position where a local scan would have
    seen its depth return to zero, which is the same answer C<try-link> used to
    compute for itself — but once for the whole line instead of once per
    bracket, which is the difference between linear and quadratic on a line
    that is five thousand unmatched C<[>. )
my sub match-pairs(@c --> List) {
	my %bracket;
	my %paren;
	my @bstack;
	my @pstack;
	my $i = 0;
	while $i < @c.elems {
		my $ch = @c[$i];
		if $ch eq '`' {
			my $n = run-length(@c, $i, '`');
			my $j = find-code-close(@c, $i + $n, $n);
			$i = $j.defined ?? $j + $n !! $i + $n;
			next;
		}
		if $ch eq '[' { @bstack.push: $i }
		elsif $ch eq ']' { %bracket{@bstack.pop} = $i if @bstack }
		elsif $ch eq '(' { @pstack.push: $i }
		elsif $ch eq ')' { %paren{@pstack.pop} = $i if @pstack }
		$i++;
	}
	(%bracket, %paren);
}

#|( Try to read C<[text](dest)> starting at C<$start>, using the pairings from
    C<match-pairs>. Returns a Hash with C<text>, C<url> and C<next>, or Nil when
    this is just a stray bracket. )
my sub try-link(@c, Int $start, %bracket, %paren) {
	my $close = %bracket{$start};
	return Nil unless $close.defined;
	return Nil unless $close + 1 < @c.elems && @c[$close + 1] eq '(';

	my $end = %paren{$close + 1};
	return Nil unless $end.defined;

	my $text = @c[$start + 1 ..^ $close].join;
	my $dest = @c[$close + 2 ..^ $end].join.trim;
	if $dest.starts-with('<') && $dest.index('>').defined {
		# `<...>` wins over the whitespace rule: this is exactly how you write
		# a destination that contains a space.
		$dest = $dest.substr(1, $dest.index('>') - 1);
	}
	elsif $dest ~~ /\s/ {
		# `[a](url "title")` - the title is not ours to keep.
		$dest = $dest.words.head // '';
	}
	return Nil if $text eq '' && $dest eq '';

	{ text => ($text ne '' ?? $text !! $dest), url => $dest, next => $end + 1 };
}

#| Pass 1. Text, atoms and delimiter runs, in source order.
my sub tokenize(@c --> Array) {
	my Node @nodes;
	# Only a `[` can start a link, and the paren map exists only to finish one.
	my (%bracket, %paren) := @c.first('[', :k).defined ?? match-pairs(@c) !! ({}, {});
	my $run-start = 0;
	my $i = 0;

	my sub flush-text($upto) {
		return if $upto <= $run-start;
		@nodes.push: Node.new(kind => 'text', text => @c[$run-start ..^ $upto].join);
	}

	while $i < @c.elems {
		my $ch = @c[$i];

		if $ch eq '`' {
			my $n = run-length(@c, $i, '`');
			my $j = find-code-close(@c, $i + $n, $n);
			if $j.defined {
				flush-text($i);
				my $content = @c[$i + $n ..^ $j].join;
				# One space of padding on both sides is how you write a code
				# span whose content starts or ends with a backtick.
				if $content.chars >= 2 && $content.starts-with(' ')
					&& $content.ends-with(' ') && $content ~~ /\S/ {
					$content = $content.substr(1, $content.chars - 2);
				}
				@nodes.push: Node.new(kind => 'atom', text => $content, code => True)
					if $content ne '';
				$i = $j + $n;
				$run-start = $i;
			}
			else {
				$i += $n;      # literal backticks, left in the text run
			}
		}
		elsif $ch eq '[' {
			my $link = try-link(@c, $i, %bracket, %paren);
			if $link {
				flush-text($i);
				@nodes.push: Node.new(
					kind => 'atom', text => $link<text>, link => $link<url>);
				$i = $link<next>;
				$run-start = $i;
			}
			else {
				$i++;          # literal bracket
			}
		}
		elsif $ch eq '*' || $ch eq '_' {
			my $n = run-length(@c, $i, $ch);
			my $prev = $i > 0 ?? @c[$i - 1] !! Str;
			my $next = $i + $n < @c.elems ?? @c[$i + $n] !! Str;
			my $can-open = $next.defined && !is-space($next);
			my $can-close = $prev.defined && !is-space($prev);
			if $ch eq '_' {
				# Underscores never emphasise inside a word, which is the only
				# reason `snake_case_name` survives contact with this module.
				$can-open = $can-open && !is-alnum($prev);
				$can-close = $can-close && !is-alnum($next);
			}
			flush-text($i);
			@nodes.push: Node.new(
				kind => 'delim', dchar => $ch, orig => $n, remaining => $n,
				:$can-open, :$can-close);
			$i += $n;
			$run-start = $i;
		}
		else {
			$i++;
		}
	}
	flush-text(@c.elems);
	@nodes;
}

#|( Pass 2. CommonMark's process-emphasis, with matched pairs recorded into two
    difference arrays instead of a tree.

    Returns C<(@bold-delta, @italic-delta)>, each one longer than C<@nodes>, to
    be prefix-summed by the builder. )
my sub emphasise(Node @nodes) {
	my @bold = 0 xx (@nodes.elems + 1);
	my @italic = 0 xx (@nodes.elems + 1);

	my Int @delims = @nodes.keys.grep({ @nodes[$_].kind eq 'delim' });
	return (@bold, @italic) unless @delims;

	# The still-matchable delimiters, as a doubly linked list over positions in
	# @delims. Walking it instead of the raw array is what keeps the backward
	# opener scan and the "everything between a matched pair is dead" sweep
	# amortized linear: an entry is unlinked at most once, ever.
	my Int @prv = (-1 ..^ @delims.end);
	my Int @nxt = (1 .. @delims.elems);
	my sub unlink-delim(Int $k) {
		my $p = @prv[$k];
		my $n = @nxt[$k];
		@nxt[$p] = $n if $p >= 0;
		@prv[$n] = $p if $n < @delims.elems;
		@nodes[@delims[$k]].active = False;
	}

	# CommonMark's openers_bottom: once a closer of a given shape has failed to
	# find any opener below some point, no later closer of that shape can
	# either. Without this the backward scan is quadratic on a wall of
	# unmatchable delimiters.
	my %bottom;

	for @delims.kv -> $ci, $cidx {
		my $closer = @nodes[$cidx];
		next unless $closer.can-close && $closer.active;

		while $closer.remaining > 0 {
			my $key = $closer.dchar ~ ($closer.can-open ?? '1' !! '0')
				~ ($closer.orig % 3);
			my $bottom = %bottom{$key} // 0;
			my $found;

			loop (my $oi = @prv[$ci]; $oi >= $bottom; $oi = @prv[$oi]) {
				my $o = @nodes[@delims[$oi]];
				next unless $o.remaining > 0 && $o.can-open
					&& $o.dchar eq $closer.dchar;
				# CommonMark's "rule of three": when either delimiter of a pair
				# can do both jobs, their original lengths may not sum to a
				# multiple of three unless both are multiples of three. This is
				# what makes `*foo**bar**baz*` come out right.
				next if ($o.can-close || $closer.can-open)
					&& (($o.orig + $closer.orig) %% 3)
					&& !($o.orig %% 3 && $closer.orig %% 3);
				$found = $oi;
				last;
			}

			unless $found.defined {
				%bottom{$key} = $ci;
				last;
			}

			my $oidx = @delims[$found];
			my $opener = @nodes[$oidx];
			my $use = ($opener.remaining >= 2 && $closer.remaining >= 2) ?? 2 !! 1;
			$opener.remaining -= $use;
			$closer.remaining -= $use;

			# The interval covers the nodes strictly between the two delimiter
			# nodes; leftover delimiter characters live on the nodes themselves
			# and are correctly left outside.
			if $use == 2 {
				@bold[$oidx + 1]++;
				@bold[$cidx]--;
			}
			else {
				@italic[$oidx + 1]++;
				@italic[$cidx]--;
			}

			# Anything between the pair can never match anything again.
			my $between = @nxt[$found];
			while $between < $ci {
				my $after = @nxt[$between];
				unlink-delim($between);
				$between = $after;
			}

			unlink-delim($found) unless $opener.remaining;
			unless $closer.remaining {
				unlink-delim($ci);
				last;
			}
		}
	}

	(@bold, @italic);
}

#| Pass 3. Prefix-sum the intervals, drop empties, merge neighbours.
my sub build-spans(Node @nodes, @bold-delta, @italic-delta --> List) {
	my @raw;                        # [text, bold, italic, code, link]
	my $bold = 0;
	my $italic = 0;

	for @nodes.kv -> $k, $node {
		$bold += @bold-delta[$k];
		$italic += @italic-delta[$k];

		my $text = $node.kind eq 'delim'
			?? $node.dchar x $node.remaining
			!! $node.text;
		next if $text eq '';

		my $b = $bold > 0;
		my $i = $italic > 0;

		if @raw && !@raw[*-1][4].defined && !$node.link.defined
			&& @raw[*-1][1] === $b && @raw[*-1][2] === $i
			&& @raw[*-1][3] === $node.code {
			@raw[*-1][0] ~= $text;
		}
		else {
			@raw.push: [$text, $b, $i, $node.code, $node.link];
		}
	}

	@raw.map({
		Span.new(
			text => .[0], bold => .[1], italic => .[2], code => .[3], link => .[4])
	}).List;
}

#| The four characters that can start something other than plain text.
my constant MARKUP-START = / <[ * _ ` \[ ]> /;

#| The whole inline pipeline, for one block's worth of already-joined text.
my sub lex-inline(Str $text --> List) {
	return () unless $text.defined && $text ne '';
	# By far the most common block is one with no markup in it at all, and that
	# case is worth answering without combing, tokenizing or allocating.
	return (Span.new(text => $text),) unless $text ~~ MARKUP-START;
	my @c = $text.comb;
	my Node @nodes = tokenize(@c);
	my ($bold, $italic) = emphasise(@nodes);
	build-spans(@nodes, $bold, $italic);
}

#|( The inline pipeline for a block whose newlines are meaningful: one run of
    spans per line, with a C<Break> between each pair of lines.

    Lexing per line rather than lexing the joined text is the whole difference
    C<:hard-breaks> makes inline: a delimiter cannot reach across a newline to
    find its partner, because the lexer never sees the two lines together. )
my sub lex-lines(@lines --> List) {
	my @out;
	for @lines.kv -> $k, $line {
		@out.push: Break.new if $k;
		@out.append: lex-inline($line);
	}
	@out.List;
}

# ---------------------------------------------------------------------------
# Block lexing
# ---------------------------------------------------------------------------

#|( Split a line into its indentation width and the rest. Tabs advance to the
    next four-column stop, which is the only place this module thinks about
    tabs at all. )
my sub split-indent(Str $line --> List) {
	my $col = 0;
	my $i = 0;
	my $chars = $line.chars;
	while $i < $chars {
		my $c = $line.substr($i, 1);
		if $c eq ' ' { $col++ }
		elsif $c eq "\t" { $col += 4 - ($col % 4) }
		else { last }
		$i++;
	}
	# The overwhelmingly common case is no indentation at all, and the whole
	# point of not combing the line is to not copy it either.
	($col, $i == 0 ?? $line !! $line.substr($i));
}

#| Remove up to C<$width> columns of leading whitespace, tab stops included.
my sub strip-indent(Str $line, Int $width --> Str:D) {
	return $line if $width <= 0;
	my $col = 0;
	my $i = 0;
	my $chars = $line.chars;
	while $i < $chars && $col < $width {
		my $c = $line.substr($i, 1);
		if $c eq ' ' { $col++ }
		elsif $c eq "\t" { $col += 4 - ($col % 4) }
		else { last }
		$i++;
	}
	$i == 0 ?? $line !! $line.substr($i);
}

my sub is-blank(Str $line --> Bool:D) { $line !~~ /\S/ }

#|( An opening code fence, as C<(char, len, lang)>, or Nil.

    A backtick fence may not carry a backtick in its info string — that rule is
    what keeps C<```inline``` in a sentence> a paragraph rather than a fence
    swallowing the rest of the document. )
my sub match-fence(Str $rest) {
	return Nil unless $rest.starts-with('`') || $rest.starts-with('~');
	my $char = $rest.substr(0, 1);
	my $len = 0;
	$len++ while $len < $rest.chars && $rest.substr($len, 1) eq $char;
	return Nil if $len < 3;
	my $info = $rest.substr($len).trim;
	return Nil if $char eq '`' && $info.contains('`');
	my $lang = $info eq '' ?? Str !! $info.words.head;
	($char, $len, $lang);
}

#| Does this line close a fence of C<$char> x C<$len>?
my sub is-fence-close(Str $rest, Str $char, Int $len --> Bool:D) {
	my $n = 0;
	$n++ while $n < $rest.chars && $rest.substr($n, 1) eq $char;
	$n >= $len && $rest.substr($n).trim eq '';
}

#| An ATX heading, as C<(level, text)>, or Nil.
my sub match-heading(Str $rest) {
	return Nil unless $rest.starts-with('#');
	my $level = 0;
	$level++ while $level < $rest.chars && $rest.substr($level, 1) eq '#';
	return Nil unless 1 <= $level <= 6;
	my $tail = $rest.substr($level);
	return Nil unless $tail eq '' || $tail.starts-with(' ') || $tail.starts-with("\t");
	my $text = $tail.trim;
	# Closing sequence: `## Title ##`, and the degenerate `## ##`.
	if $text ~~ / ^ '#'+ $ / {
		$text = '';
	}
	else {
		$text = $text.subst(/ \s '#'+ $ /, '').trim;
	}
	($level, $text);
}

#| Three or more of one of C<-*_>, alone on the line bar spaces.
my sub is-rule(Str $rest --> Bool:D) {
	my $first = $rest.substr(0, 1);
	return False unless $first eq '-' || $first eq '*' || $first eq '_';
	my $count = 0;
	my $chars = $rest.chars;
	loop (my $i = 0; $i < $chars; $i++) {
		my $c = $rest.substr($i, 1);
		next if $c eq ' ' || $c eq "\t";
		return False unless $c eq $first;
		$count++;
	}
	$count >= 3;
}

#| A list marker, as C<(marker, text)>, or Nil. C<$rest> is already unindented.
my sub match-bullet(Str $rest) {
	my $first = $rest.substr(0, 1);
	if $first eq '-' || $first eq '+' || $first eq '*' {
		my $after = $rest.substr(1, 1);
		return Nil unless $after eq '' || $after eq ' ' || $after eq "\t";
		return ($first, $rest.substr(1).trim);
	}
	if $first ~~ / ^ \d $ / && $rest ~~ / ^ (\d+ <[.)]>) / {
		my $marker = ~$0;
		my $tail = $rest.substr($marker.chars);
		return Nil unless $tail eq '' || $tail.substr(0, 1) ~~ /\s/;
		return ($marker, $tail.trim);
	}
	Nil;
}

#| The content of a quote line, or Nil when this isn't one.
my sub match-quote(Str $rest) {
	return Nil unless $rest.starts-with('>');
	my $body = $rest.substr(1);
	$body = $body.substr(1) if $body.starts-with(' ');
	$body;
}

#|( Does this line carry a pipe that a table would cut a cell at?

    C<\|> does not count: a backslash immediately before a pipe escapes it. That
    is the only backslash escape in the whole module, and it is here because
    there is otherwise no way at all to put a pipe inside a cell. )
my sub has-pipe(Str $rest --> Bool:D) {
	# Most lines have no pipe at all, and the scan is only worth entering when
	# there is something in there for it to find.
	return False unless $rest.contains('|');
	my $chars = $rest.chars;
	my $i = 0;
	while $i < $chars {
		my $c = $rest.substr($i, 1);
		if $c eq '\\' && $i + 1 < $chars && $rest.substr($i + 1, 1) eq '|' {
			$i += 2;
			next;
		}
		return True if $c eq '|';
		$i++;
	}
	False;
}

#|( Cut one table row into its trimmed cell texts, GFM style: the outer pipes
    are the table's own punctuation rather than empty cells, C<\|> is a literal
    pipe, and the result always has at least one cell. )
my sub split-row(Str $rest --> List) {
	my @cells;
	my $chars = $rest.chars;
	my $start = 0;
	my $i = 0;
	my $escaped = False;

	my sub cut(Int $upto) {
		my $cell = $rest.substr($start, $upto - $start).trim;
		# Unescaping is a whole extra pass over the cell, so it only happens to
		# the cells that actually contain an escape.
		@cells.push: $escaped ?? $cell.subst("\\|", '|', :g) !! $cell;
		$escaped = False;
	}

	while $i < $chars {
		my $c = $rest.substr($i, 1);
		if $c eq '\\' && $i + 1 < $chars && $rest.substr($i + 1, 1) eq '|' {
			$escaped = True;
			$i += 2;
			next;
		}
		if $c eq '|' {
			cut($i);
			$start = $i + 1;
		}
		$i++;
	}
	cut($chars);

	# `| a | b |` is two cells, not four. An empty cell that no outer pipe
	# created survives, which is how `| a | |` writes a trailing empty one.
	@cells.shift if @cells.elems > 1 && @cells[0] eq '';
	@cells.pop if @cells.elems > 1 && @cells[*-1] eq '';
	@cells.List;
}

#|( The alignments a delimiter row declares for a header of C<$cols> columns, or
    Nil when this line is not one.

    The row has to carry a pipe of its own. That is what keeps C<---> a thematic
    break and C<-> a bullet instead of turning every dash under a line with a
    pipe in it into a one-column table. )
my sub match-separator(Str $rest, Int:D $cols) {
	return Nil unless has-pipe($rest);
	my @cells = split-row($rest);
	return Nil unless @cells.elems == $cols;

	my @alignments;
	for @cells -> $cell {
		return Nil unless $cell ~~ / ^ ':'? '-'+ ':'? $ /;
		my $left = $cell.starts-with(':');
		my $right = $cell.ends-with(':');
		@alignments.push:
			$left && $right ?? 'center' !! ($right ?? 'right' !! 'left');
	}
	@alignments.List;
}

#|( One row's cells, normalised to the header's width the way GFM says: the
    extras are dropped and the shortfall is padded with empty cells, so every
    row of a Table is exactly as wide as its header. )
my sub row-cells(@raw, Int:D $cols --> List) {
	(^$cols).map({ Cell.new(inlines => lex-inline(@raw[$_] // '')) }).List;
}

#|( Does this line start a block of its own? Asked only of a line that might
    otherwise have continued a table's body, so that a heading, a fence, a rule,
    a bullet or a quote under a table ends the table rather than being eaten as
    a row with a pipe in it. )
my sub starts-block(Str $rest --> Bool:D) {
	return True if match-fence($rest).defined;
	return True if match-heading($rest).defined;
	return True if is-rule($rest);
	return True if match-bullet($rest).defined;
	return True if match-quote($rest).defined;
	False;
}

#|( Lex Markdown into a flat, immutable C<List> of block objects.

    Total: every input produces a List, including C<Str:U> and C<''> (both give
    the empty List). Prefix-stable: lexing any prefix of a document succeeds and
    degrades unterminated constructs to literal text or, for a code fence, to a
    block with C<:!closed>.

    C<:hard-breaks> turns the soft line breaks inside a paragraph, bullet or
    quote into C<Break> spans instead of spaces, and is off by default.

    =begin code :lang<raku>
    my @blocks = parse("- one\n- two\n\n> quoted **hard**\n");
    @blocks.map(*.gist).join("\n");
    # [bullet d0 -] one
    # [bullet d0 -] two
    # [quote] quoted hard

    parse("one\ntwo").head.inlines;                 # Span("one two")
    parse("one\ntwo", :hard-breaks).head.inlines;   # Span("one") Break Span("two")
    =end code )
our sub parse(Str $text, Bool:D :$hard-breaks = False --> List) is export {
	return () unless $text.defined;
	# Literal Str needles, not a regex: Raku stores CR LF as a single grapheme,
	# so /\r\n/ never matches one and /\n/ never finds one either.
	my $norm = $text.subst("\r\n", "\n", :g).subst("\r", "\n", :g);
	return () if $norm eq '';

	my @lines = $norm.split("\n");
	# A trailing newline ends the last line; it does not begin an empty one.
	@lines.pop if @lines && @lines[*-1] eq '';

	my @blocks;

	# The block currently being accumulated, if any. Kinds: para, quote, bullet.
	my $open-kind;
	my @open-lines;
	my $open-depth = 0;
	my $open-marker = '';

	my sub flush() {
		return unless $open-kind.defined;
		# Off, the lines of a block are one run of text with its newlines spent
		# as spaces. On, each newline is a Break and each line is lexed alone.
		my @inlines = $hard-breaks
			?? lex-lines(@open-lines)
			!! lex-inline(@open-lines.grep({ $_ ne '' }).join(' '));
		given $open-kind {
			when 'para' {
				@blocks.push: Para.new(:@inlines);
			}
			when 'quote' {
				@blocks.push: Quote.new(:@inlines);
			}
			when 'bullet' {
				@blocks.push: Bullet.new(
					depth => $open-depth, marker => $open-marker, :@inlines);
			}
		}
		$open-kind = Nil;
		@open-lines = ();
		$open-depth = 0;
		$open-marker = '';
	}

	my $i = 0;
	while $i < @lines.elems {
		my $line = @lines[$i];

		if is-blank($line) {
			flush();
			$i++;
			next;
		}

		my ($indent, $rest) = split-indent($line);

		with match-fence($rest) -> ($char, $len, $lang) {
			flush();
			my @content;
			my $closed = False;
			my $j = $i + 1;
			while $j < @lines.elems {
				my $frest = split-indent(@lines[$j])[1];
				if is-fence-close($frest, $char, $len) {
					$closed = True;
					$j++;
					last;
				}
				@content.push: strip-indent(@lines[$j], $indent);
				$j++;
			}
			@blocks.push: CodeFence.new(:$lang, lines => @content, :$closed);
			$i = $j;
			next;
		}

		with match-heading($rest) -> ($level, $htext) {
			flush();
			@blocks.push: Heading.new(:$level, inlines => lex-inline($htext));
			$i++;
			next;
		}

		if is-rule($rest) {
			flush();
			@blocks.push: Rule.new;
			$i++;
			next;
		}

		with match-bullet($rest) -> ($marker, $btext) {
			flush();
			$open-kind = 'bullet';
			$open-depth = ($indent / 2).Int;
			$open-marker = $marker;
			@open-lines = ($btext,);
			$i++;
			next;
		}

		with match-quote($rest) -> $qtext {
			flush() unless $open-kind.defined && $open-kind eq 'quote';
			$open-kind = 'quote';
			@open-lines.push: $qtext.trim;
			$i++;
			next;
		}

		# A pipe table, which takes two lines to recognise: this one has a pipe
		# in it, and the one under it is a delimiter row of the same width. With
		# only the first line in hand the text is an ordinary paragraph, which is
		# exactly what makes a table arriving one line at a time prefix-stable.
		if $i + 1 < @lines.elems && $rest.contains('|')
			&& @lines[$i + 1].contains('|') && has-pipe($rest) {
			my @header = split-row($rest);
			with match-separator(split-indent(@lines[$i + 1])[1], @header.elems)
				-> @alignments {
				flush();
				my $cols = @alignments.elems;
				my @rows;
				my $j = $i + 2;
				while $j < @lines.elems {
					last if is-blank(@lines[$j]);
					my $rrest = split-indent(@lines[$j])[1];
					# A line with no pipe, or one that opens a block of its own,
					# is not a row: the table ends above it.
					last unless has-pipe($rrest);
					last if starts-block($rrest);
					@rows.push: row-cells(split-row($rrest), $cols);
					$j++;
				}
				@blocks.push: Table.new(
					:@alignments, header => row-cells(@header, $cols), :@rows);
				$i = $j;
				next;
			}
		}

		# Ordinary text: continues an open paragraph or bullet, otherwise opens
		# a paragraph. A quote is not continued lazily.
		flush() if $open-kind.defined && $open-kind eq 'quote';
		$open-kind //= 'para';
		@open-lines.push: $line.trim;
		$i++;
	}
	flush();

	@blocks.List;
}
