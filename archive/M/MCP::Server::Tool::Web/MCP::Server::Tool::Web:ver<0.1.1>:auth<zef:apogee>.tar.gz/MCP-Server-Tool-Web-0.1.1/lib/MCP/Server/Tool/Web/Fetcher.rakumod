=begin pod

=head1 NAME

MCP::Server::Tool::Web::Fetcher - one guarded HTTP GET, redirects, budgets and
character sets included

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Fetcher;
use MCP::Server::Tool::Web::Guard;

my $fetcher = MCP::Server::Tool::Web::Fetcher.new(
    guard     => MCP::Server::Tool::Web::Guard.new,
    max-bytes => 2 * 1024 * 1024,
);

my $page = $fetcher.fetch('https://docs.example.com/guide');

say $page.status;             # 200
say $page.final-url;          # https://docs.example.com/guide/  (after a 301)
say $page.redirect-chain;     # [https://docs.example.com/guide https://…/guide/]
say $page.content-type;       # text/html
say $page.charset;            # utf-8      — the encoding that actually worked
say $page.byte-count;         # 48219
say $page.text.lines.head;    # <!DOCTYPE html>
say $page.elapsed;            # 0.31

=end code

A 404 is a result, not an exception. Only the request never happening is:

=begin code :lang<raku>

my $missing = $fetcher.fetch('https://example.com/nope');
say $missing.status;          # 404
say $missing.text.chars;      # the error page is still the body

{
    $fetcher.fetch('http://169.254.169.254/latest/meta-data/');
    CATCH {
        when X::MCP::Server::Tool::Web::Blocked   { say .message }  # metadata endpoint
        when X::MCP::Server::Tool::Web::BadUrl    { say .message }
        when X::MCP::Server::Tool::Web::Deadline  { say .message }
        when X::MCP::Server::Tool::Web::Transport { say .message }
    }
}

=end code

One budget, shared by every page of a crawl:

=begin code :lang<raku>

my $budget = $fetcher.new-budget;         # this Fetcher's caps, one call's worth
for @urls -> $url {
    last if $budget.expired;
    my $page = $fetcher.fetch($url, :$budget);
    say "$url: {$page.byte-count} bytes"
        ~ ($page.truncated ?? " (cut: {$page.truncated-reason})" !! '');
}

=end code

=head1 DESCRIPTION

Everything between "here is a URL" and "here is the text of that page", with
the pack's rules applied at every step: the guard vets the URL and, through
L<MCP::Server::Tool::Web::Transport>, the address behind it; the budget bounds
the time and the bytes; redirects are followed by hand so that every hop is
checked again; and the body is decoded with the encoding the bytes are
actually in rather than the one the fetcher would prefer.

=head2 Redirects are followed here, not by Cro

C<Cro::HTTP::Client> can follow redirects itself, and this class asks it not
to (C<follow =E<gt> False>). Every hop goes back through
C<Guard.check-url> and, on connect, through the address check: a
C<Location: file:///etc/passwd>, a C<Location: http://10.0.0.1/> or a redirect
that quietly drops from https to http is refused on the hop that produced it,
naming the rule. Cro's own loop would have skipped all of that from hop two
onwards.

The other reason is bookkeeping the tool surface needs: the chain, in order,
and the B<final> URL — which is what a crawl's same-origin test and a
relative link's base have to be resolved against.

Loops are detected on (origin, path, query), so a site that alternates between
two URLs is refused as a loop rather than as "too many redirects": the first
is a fact about the site that no setting will fix, the second is a budget.

=head2 The body is read against a ledger

The response body is streamed and counted. When the budget's byte allowance
runs out mid-body the download is cancelled and what arrived is kept; when the
deadline passes mid-body, likewise. Either way the result carries
C<truncated =E<gt> True> and a C<truncated-reason> of C<'max-bytes'> or
C<'deadline'>, and B<a body that simply ended is never marked truncated>,
however close to a limit it came.

=head3 Why head-only, and not head-and-tail

The shell tool keeps the head and the tail of a long output, because the
interesting part of a build log is usually at the end. This one keeps only the
head, deliberately: the tail of a truncated HTML document is closing markup,
the extractor needs a parseable prefix rather than two fragments spliced
together, and C<web_grep>'s line numbers have to mean something. Please do not
"improve" this into head+tail.

=head3 The cancel that looks exactly like a timeout

Cancelling a body makes Cro quit the byte stream with
C<X::Cro::HTTP::Client::Timeout(phase =E<gt> 'body')> — the very same
exception, of the very same type, that a real body timeout raises (a real body
timeout B<is> a cancel, internally). There is no way to tell them apart from
the exception, so a C<$stopped> flag records that the cancel was ours. Without
it, a genuinely stalled server would be reported as a tidy truncation.

Cro's own body timeout is switched off (C<body =E<gt> Inf>) for the same
reason: two things racing to cancel the same stream makes
C<truncated-reason> unattributable. The ledger and the deadline in
L<MCP::Server::Tool::Web::Budget> end the body; Cro does not.

=head2 Character sets

Bodies are decoded here, never by C<body-text> — Cro's own encoding guess
falls back to latin-1 in a way that overwrites a successful UTF-8 decode, so
C<café> arrives as C<cafÃ©>. The order is:

=item the C<charset> parameter of the C<Content-Type> header;
=item failing that, for HTML, a C<E<lt>meta charsetE<gt>> in the first 1 KB
      (sniffed from a latin-1 decode of those bytes, which cannot throw);
=item failing that, UTF-8 for JSON (RFC 8259 §8.1 leaves no other option);
=item and a byte-order mark beats all three, because it is evidence rather
      than a claim.

Whatever is chosen, the decode is attempted with fallbacks — chosen, then
UTF-8, then latin-1, which cannot fail — and C<charset> on the result reports
B<the encoding that actually worked>, not the one the server claimed.

When the body was truncated, an incomplete UTF-8 sequence at the cut is
trimmed first (at most three bytes): without that, one severed character makes
the whole document fail to decode as UTF-8 and fall back to latin-1, turning
a clean truncation into a page of mojibake.

Binary bodies — images, PDFs, archives — are not decoded at all: C<text> is
empty and C<bytes> is intact, so the tool layer can say what it is and how big
it is. L<MCP::Server::Tool::Web::Extract> owns that message.

=head2 robots.txt

The Fetcher holds a L<MCP::Server::Tool::Web::Robots> policy, C<Off> by
default, and consults it before B<every> hop — a redirect onto a path the
origin disallows is still a request to that path. C<web_fetch> and depth-zero
C<web_grep> keep the default; crawling swaps in C<Respect>. See that module
for how the two point at each other without a dependency cycle.

=end pod

use Cro::HTTP::Client;

use MCP::Server::Tool::Web::Budget;
use MCP::Server::Tool::Web::Guard;
use MCP::Server::Tool::Web::Robots;
use MCP::Server::Tool::Web::Transport;
use MCP::Server::Tool::Web::Url;
use MCP::Server::Tool::Web::X;

#| Everything one GET produced. The seam the tool layer consumes: it never
#| sees a Cro response, a socket or a budget.
class MCP::Server::Tool::Web::FetchResult {
	#| The URL as it was asked for, normalised.
	has Str:D $.requested-url is required;

	#| The URL the body actually came from, after redirects. Relative links in
	#| the body resolve against this, not against C<requested-url>.
	has Str:D $.final-url is required;

	#| Every URL visited, in order: C<requested-url> first, C<final-url> last.
	#| One element long when there were no redirects.
	has Str:D @.redirect-chain;

	#| The HTTP status. 4xx and 5xx arrive here as results, not exceptions.
	has Int:D $.status is required;

	#| The media type without its parameters, lowercased ('text/html'), or the
	#| C<Str> type object when the server sent no C<Content-Type> at all.
	has Str $.content-type;

	#| The encoding the body was successfully decoded with, or the C<Str> type
	#| object for a binary body that was not decoded.
	has Str $.charset;

	#| The decoded body. Empty for a binary body — C<bytes> still holds it.
	has Str:D $.text = '';

	#| The bytes that were retained, exactly as they arrived.
	has Buf:D $.bytes = Buf.new;

	#| How many bytes were retained. Equal to C<bytes.elems>; kept as a field
	#| because it is what notices quote.
	has Int:D $.byte-count = 0;

	#| True only when bytes that existed were not kept.
	has Bool:D $.truncated = False;

	#| Why the body was cut: 'max-bytes' or 'deadline'. C<Str> when it was not.
	has Str $.truncated-reason;

	#| Wall-clock seconds this fetch took, including its redirects.
	has Real:D $.elapsed = 0;

	#| A 2xx status.
	method ok(--> Bool:D) { 200 <= $!status < 300 }

	#| Did the body come from somewhere other than the URL asked for?
	method redirected(--> Bool:D) { $!requested-url ne $!final-url }

	method gist(--> Str:D) {
		"FetchResult($!status $!final-url, $!byte-count bytes"
			~ ($!charset.defined ?? ", $!charset" !! '')
			~ ($!truncated ?? ", truncated: $!truncated-reason" !! '')
			~ ')';
	}
}

#| Fetches one URL — with its redirects — under a guard, a transport and a
#| budget. One per pack instance; safe to reuse for every fetch that pack
#| makes.
class MCP::Server::Tool::Web::Fetcher {
	#| The policy. Shared with the transport, which enforces its address half.
	has MCP::Server::Tool::Web::Guard:D $.guard = MCP::Server::Tool::Web::Guard.new;

	#| The guarded client factory. Built from C<guard> when not supplied.
	has MCP::Server::Tool::Web::Transport $.transport;

	#| The robots.txt policy consulted before every hop. C<Off> is the right
	#| default: a single page asked for by name is not crawling.
	has MCP::Server::Tool::Web::Robots:D $.robots =
		MCP::Server::Tool::Web::Robots::Off.new;

	#| Default body cap for budgets this Fetcher makes, in bytes.
	has Int:D $.max-bytes = 2_097_152;

	#| Default wall-clock cap for budgets this Fetcher makes, in seconds.
	has Real:D $.total-seconds = 60;

	#| Default redirect hop cap for budgets this Fetcher makes.
	has Int:D $.max-redirects = 5;

	#| How long a single connect may take. Clamped down by whatever is left of
	#| the budget, never up.
	has Real:D $.connect-timeout = 15;

	#| How long a single response's headers may take, likewise clamped.
	has Real:D $.headers-timeout = 30;

	submethod TWEAK {
		$!transport //= MCP::Server::Tool::Web::Transport.new(guard => $!guard);
		die 'connect-timeout must be positive' unless $!connect-timeout > 0;
		die 'headers-timeout must be positive' unless $!headers-timeout > 0;
	}

	#| A fresh budget with this Fetcher's caps — one tool call's worth. Pass
	#| the same one to every fetch of a crawl so twenty pages share the
	#| allowance instead of each taking it whole.
	method new-budget(--> MCP::Server::Tool::Web::Budget:D) {
		MCP::Server::Tool::Web::Budget.new(
			total-bytes   => $!max-bytes,
			total-seconds => $!total-seconds,
			max-redirects => $!max-redirects,
		);
	}

	#| The user agent this Fetcher presents, and the token robots.txt groups
	#| are matched against.
	method user-agent(--> Str:D) { $!transport.user-agent }

	#| Fetch one URL. Follows redirects, applies the budget, decodes the body,
	#| and answers a C<FetchResult> — including for 4xx and 5xx. Throws only
	#| when there is no result to give: a refused URL or address, a redirect
	#| loop or hop-cap, an expired deadline before a body arrived, a
	#| connection that failed, or a robots.txt refusal.
	method fetch(Str:D $url, MCP::Server::Tool::Web::Budget :$budget, :%headers
			--> MCP::Server::Tool::Web::FetchResult:D) {
		my $b = $budget // self.new-budget;
		my $start = $!guard.check-url($url);
		self!run($start, $b, %headers, :consult-robots);
	}

	#| The robots.txt of an origin ('https://example.com'), or the C<Str> type
	#| object when there is not one to be had. Its own small budget, and it
	#| does not consult the robots policy — that would be a cycle. This is the
	#| method a C<Robots::Respect> fetch closure calls.
	method robots-text(Str:D $origin --> Str) {
		my $budget = MCP::Server::Tool::Web::Budget.new(
			total-bytes   => 65_536,
			total-seconds => min(10, $!total-seconds),
			max-redirects => $!max-redirects,
		);
		my $url = $!guard.check-url($origin ~ '/robots.txt');
		my $result = self!run($url, $budget, {}, consult-robots => False);
		$result.status == 200 ?? $result.text !! Str;
	}

	# === The hop loop ===

	method !run(MCP::Server::Tool::Web::Url:D $start,
			MCP::Server::Tool::Web::Budget:D $budget, %headers,
			Bool:D :$consult-robots --> MCP::Server::Tool::Web::FetchResult:D) {
		my $began = now;
		my $current = $start;
		my Str @chain = $start.Str;
		my %seen = hop-key($start) => True;
		my Int $hops = 0;

		loop {
			self!check-robots($current) if $consult-robots;

			X::MCP::Server::Tool::Web::Deadline.new(
				url     => $current.Str,
				seconds => $budget.total-seconds,
				phase   => 'starting a request',
			).throw if $budget.expired;

			# Cro would obey HTTP_PROXY/HTTPS_PROXY here, below every URL
			# check; the transport refuses rather than let that happen quietly.
			$!transport.check-proxy($current.host);

			my $resp = self!request($current, $budget, %headers);

			my $location = redirect-location($resp);
			without $location {
				return self!collect($resp, $start, $current, @chain, $budget, $began);
			}

			# A body we are not going to read must still be ended: an undrained
			# response leaves the peer writing into a socket nobody is reading,
			# which shows up in its logs as our fault.
			try $resp.cancel;

			# resolve() re-runs the whole of Url.parse, and check-url re-runs
			# the address rules — a Location is attacker-chosen input, so it is
			# treated exactly like a URL the caller typed.
			my $next = $current.resolve($location);
			refuse-downgrade($current, $next);
			$!guard.check-url($next);

			$hops++;
			@chain.push($next.Str);

			# The loop check goes first: when a site alternates between two
			# URLs, "this is a loop" is the true answer and "you ran out of
			# hops" is an invitation to raise a limit that cannot help.
			my $key = hop-key($next);
			X::MCP::Server::Tool::Web::RedirectLoop.new(
				url   => $next.Str,
				chain => @chain.List,
			).throw if %seen{$key};

			X::MCP::Server::Tool::Web::TooManyRedirects.new(
				url   => $start.Str,
				limit => $budget.max-redirects,
				chain => @chain.List,
			).throw if $hops > $budget.max-redirects;

			%seen{$key} = True;
			$current = $next;
		}
	}

	#| Ask the robots policy about this hop, and turn a refusal into the typed
	#| exception with the rule that refused it.
	method !check-robots(MCP::Server::Tool::Web::Url:D $url --> Nil) {
		my $agent = $!transport.user-agent;
		return if $!robots.allow($url, :$agent);
		X::MCP::Server::Tool::Web::RobotsRefused.new(
			url   => $url.Str,
			rule  => $!robots.disallow-rule($url, :$agent),
			agent => $agent,
		).throw;
	}

	#| One request. Unwraps Cro's 4xx/5xx exceptions back into the responses
	#| they carry, and turns everything else into the pack's own failures.
	method !request(MCP::Server::Tool::Web::Url:D $url,
			MCP::Server::Tool::Web::Budget:D $budget, %headers) {
		my $remaining = $budget.remaining-seconds;
		my %timeout =
			connection => min($!connect-timeout, $remaining),
			headers    => min($!headers-timeout, $remaining),
			# The ledger ends the body, not Cro — see the Pod.
			body       => Inf,
			total      => $remaining;

		my $resp;
		{
			CATCH {
				# Ours travel untouched: a Blocked from the connector is the
				# whole answer, and wrapping it would bury the remedy.
				when X::MCP::Server::Tool::Web { .rethrow }
				when X::Cro::HTTP::Error {
					# A status is a result. This is the one place in the pack
					# where an exception becomes a value.
					$resp = .response;
				}
				when X::Cro::HTTP::Client::Timeout {
					X::MCP::Server::Tool::Web::Deadline.new(
						url     => $url.Str,
						seconds => $remaining,
						phase   => timeout-phase(.phase),
					).throw;
				}
				default {
					X::MCP::Server::Tool::Web::Transport.new(
						url    => $url.Str,
						detail => (.message // .^name).lines.head,
					).throw;
				}
			}
			$resp = await $!transport.client.get(
				$url.Str,
				follow  => False,
				timeout => %timeout,
				|(headers => %headers if %headers),
			);
		}
		$resp;
	}

	# === The body ===

	#| Stream the body against the ledger, decode it, and build the result.
	method !collect($resp, MCP::Server::Tool::Web::Url:D $requested,
			MCP::Server::Tool::Web::Url:D $final, @chain,
			MCP::Server::Tool::Web::Budget:D $budget, Instant:D $began
			--> MCP::Server::Tool::Web::FetchResult:D) {
		my $buf = Buf.new;
		my Bool $stopped = False;
		my Str  $reason;
		my      $failure;

		my $stream = $resp.body-byte-stream;
		react {
			whenever $stream -> $chunk {
				my $wanted   = $chunk.elems;
				my $accepted = $budget.take($wanted);
				$buf.append($accepted == $wanted ?? $chunk !! $chunk.subbuf(0, $accepted));

				if $accepted < $wanted {
					# Bytes existed and we did not keep them: that, and only
					# that, is truncation.
					$stopped = True;
					$reason  = 'max-bytes';
					try $resp.cancel;
					done;
				}
				elsif $budget.expired {
					$stopped = True;
					$reason  = 'deadline';
					try $resp.cancel;
					done;
				}

				LAST { done }
				QUIT {
					default {
						# $stopped is why this flag exists: our own cancel
						# arrives here as X::Cro::HTTP::Client::Timeout with
						# phase 'body', indistinguishable by type or message
						# from a server that stalled mid-body. Without the
						# flag, every truncation would be reported as a
						# timeout and every timeout as a clean truncation.
						$failure = $_ unless $stopped;
						done;
					}
				}
			}
			whenever Promise.in($budget.remaining-seconds) {
				$stopped = True;
				$reason  = 'deadline';
				try $resp.cancel;
				done;
			}
		}

		with $failure {
			X::MCP::Server::Tool::Web::Transport.new(
				url    => $final.Str,
				detail => 'the connection failed while the body was arriving ('
					~ (.message // .^name).lines.head ~ ')',
			).throw;
		}

		my $type    = media-type($resp);
		my $charset = header-charset($resp);
		my ($text, $used) = self!decode($buf, $type, $charset, truncated => $stopped);

		MCP::Server::Tool::Web::FetchResult.new(
			requested-url  => $requested.Str,
			final-url      => $final.Str,
			redirect-chain => @chain.List,
			status         => $resp.status.Int,
			content-type   => $type,
			charset        => $used,
			text           => $text,
			bytes          => $buf,
			byte-count     => $buf.elems,
			truncated      => $stopped,
			truncated-reason => $reason,
			elapsed        => (now - $began).Real,
		);
	}

	#| Decide the encoding and decode. Answers C<($text, $encoding-used)>,
	#| with an empty text and no encoding for binary bodies.
	method !decode(Buf:D $bytes, Str $type, Str $declared, Bool:D :$truncated --> List:D) {
		return ('', Str) unless $bytes.elems;
		return ('', Str) if $type.defined && is-binary($type);

		my $body = $bytes;
		my Str $chosen;

		# A byte-order mark is evidence, not a claim, so it outranks the
		# header — including a header that says something else entirely.
		if $body.elems >= 2 && (($body[0] == 0xFF && $body[1] == 0xFE)
				|| ($body[0] == 0xFE && $body[1] == 0xFF)) {
			$chosen = 'utf-16';
		}
		elsif $body.elems >= 3 && $body[0] == 0xEF && $body[1] == 0xBB && $body[2] == 0xBF {
			$chosen = 'utf-8';
		}
		else {
			$chosen = normalize-charset($declared) if $declared.defined;
			$chosen //= sniff-meta-charset($body) if $type.defined && is-html($type);
			# RFC 8259 §8.1: JSON exchanged between systems is UTF-8. There is
			# no other legal answer, so a missing charset is not a mystery.
			$chosen //= 'utf-8' if $type.defined && is-json($type);
		}

		if $truncated {
			$body = $chosen.defined && $chosen.starts-with('utf-16')
				?? even-length($body)
				!! trim-partial-utf8($body);
		}

		# The chain the whole pack decodes by: what was chosen, then UTF-8,
		# then latin-1, which cannot fail whatever the bytes are.
		for ($chosen, 'utf-8', 'latin-1').grep(*.defined).unique -> $encoding {
			my $decoded = try $body.decode($encoding);
			next without $decoded;
			# Some decoders keep the BOM as U+FEFF; it is not part of the text.
			$decoded = $decoded.substr(1) if $decoded.starts-with("\x[FEFF]");
			return ($decoded, $encoding);
		}
		('', Str);
	}
}

# === Helpers ===

#| The key two URLs must share to count as the same stop on a redirect chain:
#| origin, path and query. The fragment is already gone by now, and two
#| spellings of the default port are one origin.
my sub hop-key(MCP::Server::Tool::Web::Url:D $url --> Str:D) {
	$url.origin ~ $url.target;
}

#| The C<Location> of a redirect worth following, or the C<Str> type object —
#| for any other status, and for a 3xx that gave nothing to redirect to (which
#| is a response in its own right, not an error).
my sub redirect-location($resp --> Str) {
	return Str unless $resp.status == 301 | 302 | 303 | 307 | 308;
	my $location = ($resp.header('location') // '').trim;
	$location.chars ?? $location !! Str;
}

#| Refuse a redirect that drops out of https into http. The bytes that come
#| back would be readable — and rewritable — by anything on the path, which is
#| exactly what the https in the original URL asked not to happen.
my sub refuse-downgrade(MCP::Server::Tool::Web::Url:D $from,
		MCP::Server::Tool::Web::Url:D $to --> Nil) {
	return unless $from.scheme eq 'https' && $to.scheme eq 'http';
	X::MCP::Server::Tool::Web::BadUrl.new(
		url    => $to.Str,
		reason => 'it is an https page redirecting to plain http',
		hint   => 'A downgrade like this is either a misconfigured site or an '
			~ 'attempt to move the request onto a connection that can be read '
			~ 'and rewritten in transit. Ask for the https URL directly.',
	).throw;
}

#| Cro's timeout phase, in words a refusal message can use.
my sub timeout-phase(Str $phase --> Str:D) {
	given $phase // '' {
		when 'connection' { 'connecting' }
		when 'headers'    { 'reading headers' }
		when 'body'       { 'reading the body' }
		default           { 'making the request' }
	}
}

#| The media type without parameters, lowercased.
my sub media-type($resp --> Str) {
	my $header = $resp.header('content-type');
	return Str without $header;
	my $type = $header;
	with $type.index(';') -> $semi {
		$type = $type.substr(0, $semi);
	}
	$type = $type.trim.lc;
	$type.chars ?? $type !! Str;
}

#| The C<charset> parameter of the C<Content-Type> header, if any. Read with a
#| regex rather than through Cro's media-type parser, which answers Nil for
#| headers that are merely untidy.
my sub header-charset($resp --> Str) {
	my $header = $resp.header('content-type');
	return Str without $header;
	with $header ~~ /:i 'charset' \s* '=' \s* <['"]>? $<cs> = <[ A..Z a..z 0..9 _ . : + \- ]>+ / {
		return ~.<cs>;
	}
	Str;
}

my constant BINARY-TYPES = <
	application/epub+zip application/gzip application/java-archive
	application/msword application/octet-stream application/pdf
	application/postscript application/vnd.ms-excel
	application/vnd.ms-powerpoint application/wasm application/x-7z-compressed
	application/x-bzip2 application/x-msdownload application/x-rar-compressed
	application/x-tar application/x-xz application/zip application/zstd
>.Set;

my constant BINARY-PREFIXES = <audio/ font/ image/ model/ video/>;

#| Is this a type there is no point decoding? The list mirrors
#| L<MCP::Server::Tool::Web::Extract>'s, which owns the message the tool layer
#| shows; here it only decides whether to spend the decode.
my sub is-binary(Str:D $type --> Bool:D) {
	return True if BINARY-TYPES{$type};
	so BINARY-PREFIXES.first({ $type.starts-with($_) });
}

my sub is-html(Str:D $type --> Bool:D) {
	so $type eq 'text/html' | 'application/xhtml+xml' | 'application/html';
}

my sub is-json(Str:D $type --> Bool:D) {
	so $type eq 'application/json' | 'text/json' || $type.ends-with('+json');
}

#| The names encodings are written under on the web, mapped to the names Raku
#| knows them by. Anything not listed is passed through untouched: the decode
#| chain's C<try> turns "no such encoding" into "fall back", which is the same
#| answer as "those bytes are not that encoding".
my constant %CHARSET-ALIASES =
	'utf8'         => 'utf-8',
	'utf-8'        => 'utf-8',
	'unicode-1-1-utf-8' => 'utf-8',
	'us-ascii'     => 'ascii',
	'ascii'        => 'ascii',
	'iso-8859-1'   => 'latin-1',
	'iso8859-1'    => 'latin-1',
	'iso_8859-1'   => 'latin-1',
	'latin1'       => 'latin-1',
	'latin-1'      => 'latin-1',
	'l1'           => 'latin-1',
	'cp1252'       => 'windows-1252',
	'windows-1252' => 'windows-1252',
	'utf16'        => 'utf-16',
	'utf-16'       => 'utf-16',
	'utf-16le'     => 'utf16le',
	'utf-16be'     => 'utf16be',
;

my sub normalize-charset(Str:D $declared --> Str) {
	my $name = $declared.trim.lc;
	$name = $name.substr(1, *-1) if $name.chars > 1
		&& ($name.starts-with('"') || $name.starts-with("'"));
	return Str unless $name.chars;
	%CHARSET-ALIASES{$name} // $name;
}

#| Look for a C<E<lt>meta charsetE<gt>> in the first kilobyte. Sniffed from a
#| latin-1 decode because latin-1 accepts any byte at all: sniffing must not
#| be able to throw on the very documents it exists to rescue.
my sub sniff-meta-charset(Buf:D $bytes --> Str) {
	my $head-length = $bytes.elems < 1024 ?? $bytes.elems !! 1024;
	my $head = (try $bytes.subbuf(0, $head-length).decode('latin-1')) // '';
	return Str unless $head.chars;
	with $head ~~ /:i '<meta' <-[<>]>*? 'charset' \s* '=' \s* <['"]>?
			$<cs> = <[ A..Z a..z 0..9 _ . : + \- ]>+ / {
		return normalize-charset(~.<cs>);
	}
	Str;
}

#| Drop an incomplete UTF-8 sequence from the end of a truncated body — at
#| most three bytes, since that is the longest tail a four-byte sequence can
#| leave behind. Without this one severed character costs the whole document
#| its UTF-8 decode.
my sub trim-partial-utf8(Buf:D $bytes --> Buf:D) {
	my $elems = $bytes.elems;
	return $bytes unless $elems;

	for 1 .. 3 -> $back {
		last if $back > $elems;
		my $index = $elems - $back;
		my $byte  = $bytes[$index];
		# Continuation bytes (10xxxxxx) are not sequence starts; keep walking.
		next if ($byte +& 0b1100_0000) == 0b1000_0000;
		# ASCII: the tail is complete as it stands.
		last if $byte < 0x80;

		my $needed = ($byte +& 0b1110_0000) == 0b1100_0000 ?? 2
			!! ($byte +& 0b1111_0000) == 0b1110_0000       ?? 3
			!! ($byte +& 0b1111_1000) == 0b1111_0000       ?? 4
			!! 0;
		# A lead byte that means nothing is left where it is: the decode
		# fallback chain, not a guess here, decides what to do with it.
		last unless $needed;
		return $index ?? Buf.new($bytes[^$index]) !! Buf.new if $back < $needed;
		last;
	}
	$bytes;
}

#| UTF-16 comes in pairs; a body cut between them cannot be decoded at all.
my sub even-length(Buf:D $bytes --> Buf:D) {
	$bytes.elems %% 2 ?? $bytes !! Buf.new($bytes[^($bytes.elems - 1)]);
}
