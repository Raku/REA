=begin pod

=head1 NAME

MCP::Server::Tool::Web::X - the typed failures thrown by the web tool pack

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::X;

# The tool surface catches the base class and reports it as a tool error;
# everything else is a bug and should keep travelling.
{
    CATCH {
        when X::MCP::Server::Tool::Web {
            return %( isError => True, content => [ { type => 'text', text => .message } ] );
        }
    }
    # ... a fetch, a crawl, a grep ...
}

=end code

Reacting to particular failures rather than to all of them:

=begin code :lang<raku>

CATCH {
    when X::MCP::Server::Tool::Web::Blocked {
        # .address-class is 'loopback', 'private', 'metadata', ... — the
        # refusal is teachable without re-reading the message.
        note "SSRF floor said no: {.address-class} at {.address}";
        note "the operator could permit it with {.config-key}";
    }
    when X::MCP::Server::Tool::Web::BadUrl {
        note "bad URL ({.reason}): {.url}";
    }
}

=end code

=head1 DESCRIPTION

Every failure this distribution raises on its own behalf is an
C<X::MCP::Server::Tool::Web>, so one C<CATCH> arm separates "the web request
went wrong" from "the code around it went wrong". The tool handlers catch the
base class and turn it into an MCP C<isError> result; nothing else is caught,
so a genuine bug still surfaces as a bug.

Two properties are enforced across the whole family, because the consumer of
these messages is a language model that has to decide what to do next:

=item Every C<.message> names B<the rule> that refused the request — not "denied"
      but "private address (RFC 1918)", "port out of range", "robots.txt
      Disallow: /private".

=item Every C<.message> names B<the configuration key> that would change the
      answer, or says plainly that no key would. A refusal an operator cannot
      act on is a support ticket; a refusal that names C<allow-loopback> is a
      one-line fix.

The classes are declared as plain global classes — no C<unit module>, no
C<is export> — exactly the way Rakudo core declares C<X::AdHoc>. C<is export>
on a nested-name class exports its leaf name too, which makes two
distributions that both ship, say, an C<X::…::Transport> impossible to import
together. Consumers C<use> this file and refer to the full names.

=head2 The failures

=item C<X::MCP::Server::Tool::Web::BadUrl> — the URL was refused on its shape
      alone (scheme, credentials, obfuscated host, port range). No allow-list
      rescues these; they are refused before anything is resolved or connected.
=item C<X::MCP::Server::Tool::Web::Blocked> — the address behind the URL is one
      the SSRF floor will not connect to. Carries the host, the address, the
      classification and the permitting config key.
=item C<X::MCP::Server::Tool::Web::TooManyRedirects> — the hop budget ran out.
      Carries the whole chain, in order.
=item C<X::MCP::Server::Tool::Web::RedirectLoop> — a redirect came back to a
      URL already visited on this fetch.
=item C<X::MCP::Server::Tool::Web::Deadline> — a time budget expired. Carries
      the phase ('connecting', 'reading headers', 'reading the body') so the
      caller can tell a dead host from a slow one.
=item C<X::MCP::Server::Tool::Web::Transport> — the connection itself failed:
      refused, reset, DNS miss, TLS rejection.
=item C<X::MCP::Server::Tool::Web::RobotsRefused> — robots.txt disallows the
      URL for our user agent.

=end pod

#| Base class for every failure raised by the web tool pack. Throwable on its
#| own with a C<detail> string, but the subclasses below are what you normally
#| see. Catch this to convert pack failures into tool errors.
class X::MCP::Server::Tool::Web is Exception {
	has Str $.detail;

	method message(--> Str:D) {
		$!detail // 'web tool error';
	}
}

#| The URL was refused on its shape. C<reason> is the rule that refused it and
#| C<hint> the repair, when there is one. Shape rules are deliberately not
#| configurable: a URL carrying credentials or a hexadecimal host is refused on
#| a machine whose allow-lists permit everything, so the message says so rather
#| than sending the operator hunting for a key that does not exist.
class X::MCP::Server::Tool::Web::BadUrl is X::MCP::Server::Tool::Web {
	has Str:D $.url is required;
	has Str:D $.reason is required;
	has Str   $.hint;

	method message(--> Str:D) {
		"Refusing the URL '$!url': $!reason."
			~ ($!hint.defined ?? " $!hint" !! '')
			~ ' URL shape rules are not configurable — allow-private,'
			~ ' allow-hosts, allow-cidrs and allow-loopback do not apply to them.';
	}
}

#| The address behind a host is one the SSRF floor refuses to talk to. Thrown
#| by the guard, from the connector, with the peer address of the socket that
#| was actually established — so the address named here is the address the
#| request would have reached, not one a second DNS lookup might disagree with.
#|
#| C<config-key> is the single most specific key that would permit this exact
#| refusal; the message also lists the general ones, because an operator who
#| wants one host allowed should reach for allow-hosts rather than opening up
#| every private range.
class X::MCP::Server::Tool::Web::Blocked is X::MCP::Server::Tool::Web {
	has Str:D $.host is required;
	has Str   $.address;
	has Str   $.address-class;
	has Str   $.reference;
	has Str:D $.config-key = 'allow-private';
	has Str   $.note;
	#| The whole "how to permit this" sentence. The guard composes it, because
	#| the guard is what knows which keys apply to this particular refusal;
	#| left out, the message falls back to naming C<config-key> alone.
	has Str   $.remedy;

	method message(--> Str:D) {
		my $where = $!address.defined && $!address ne $!host
			?? "'$!host' at $!address"
			!! "'$!host'";
		my $what = $!address-class.defined
			?? "it is a $!address-class address"
				~ ($!reference.defined ?? " ($!reference)" !! '')
			!! 'its address could not be classified, and an address the guard cannot classify fails closed';

		"Refusing to connect to $where: $what."
			~ ($!note.defined ?? " $!note" !! '')
			~ ' ' ~ ($!remedy // "Set $!config-key to permit it.");
	}
}

#| The redirect budget ran out. C<chain> is every URL visited in order,
#| starting with the one that was asked for, so the loop shape is visible even
#| when it is not a loop.
class X::MCP::Server::Tool::Web::TooManyRedirects is X::MCP::Server::Tool::Web {
	has Str:D $.url is required;
	has Int:D $.limit is required;
	has       @.chain;

	method message(--> Str:D) {
		"Gave up on '$!url' after $!limit redirect{$!limit == 1 ?? '' !! 's'}"
			~ (@!chain ?? ': ' ~ @!chain.join(' -> ') !! '')
			~ ". Raise max-redirects to follow more.";
	}
}

#| A redirect returned to a URL this fetch had already been to. Distinct from
#| TooManyRedirects on purpose: a loop is a fact about the site and following
#| it longer cannot help, so the message does not invite raising the hop cap.
class X::MCP::Server::Tool::Web::RedirectLoop is X::MCP::Server::Tool::Web {
	has Str:D $.url is required;
	has       @.chain;

	method message(--> Str:D) {
		"Redirect loop at '$!url'"
			~ (@!chain ?? ': ' ~ @!chain.join(' -> ') !! '')
			~ '. The site redirects to a page already visited, so no setting'
			~ ' will complete this fetch; max-redirects only bounds how long it'
			~ ' takes to notice.';
	}
}

#| A time budget expired. C<phase> says where the time went, which is the
#| difference between "the host is dead" (connecting), "the server is thinking"
#| (reading headers) and "the page is enormous" (reading the body).
class X::MCP::Server::Tool::Web::Deadline is X::MCP::Server::Tool::Web {
	has Str       $.url;
	has Real:D    $.seconds is required;
	has Str       $.phase;
	has Str:D     $.config-key = 'timeout';

	method message(--> Str:D) {
		'Timed out after ' ~ $!seconds ~ 's'
			~ ($!phase.defined ?? " while $!phase" !! '')
			~ ($!url.defined ?? " '$!url'" !! '')
			~ ". Raise $!config-key to allow more time.";
	}
}

#| The connection itself failed — refused, reset, unresolvable, or rejected
#| during the TLS handshake. Never used for an HTTP status: a 404 is a result,
#| not an exception.
class X::MCP::Server::Tool::Web::Transport is X::MCP::Server::Tool::Web {
	has Str:D $.url is required;
	has Str:D $.detail is required;

	method message(--> Str:D) {
		"Could not reach '$!url': $!detail."
			~ ' This is the network refusing, not a setting: check the host is'
			~ ' spelled right and reachable from this machine, and that no'
			~ ' HTTP_PROXY/HTTPS_PROXY in the environment is redirecting the'
			~ ' connection (set proxy explicitly to control that).';
	}
}

#| robots.txt disallows the URL for our user agent. Only ever thrown on the
#| crawling paths — a single-page fetch does not consult robots.txt.
class X::MCP::Server::Tool::Web::RobotsRefused is X::MCP::Server::Tool::Web {
	has Str:D $.url is required;
	has Str   $.rule;
	has Str   $.agent;

	method message(--> Str:D) {
		"robots.txt disallows '$!url'"
			~ ($!agent.defined ?? " for user agent '$!agent'" !! '')
			~ ($!rule.defined ?? " (rule: Disallow: $!rule)" !! '')
			~ '. Set respect-robots to false to crawl it anyway.';
	}
}
