=begin pod

=head1 NAME

MCP::Server::Tool::Web::Budget - the deadline and byte ledger one tool call
spends

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Budget;

# One budget per tool call. The clock starts now, not at the first request.
my $budget = MCP::Server::Tool::Web::Budget.new(
    total-seconds => 30,
    total-bytes   => 2 * 1024 * 1024,
    max-redirects => 5,
);

say $budget.remaining-seconds;      # 29.99...
say $budget.expired;                # False

# The ledger: ask for what a chunk needs, get what is left to give.
say $budget.take(1000);             # 1000 — all of it
say $budget.spent-bytes;            # 1000
say $budget.remaining-bytes;        # 2096152

# A body bigger than the budget is cut, and the cut is remembered.
my $big = MCP::Server::Tool::Web::Budget.new(total-bytes => 10);
say $big.take(4);                   # 4
say $big.take(99);                  # 6  — only six were left
say $big.truncated;                 # True
say $big.take(1);                   # 0  — nothing left at all

=end code

A budget is shared, not copied: one crawl hands the same object to every page
it fetches, so twenty pages cannot each spend the whole allowance.

=begin code :lang<raku>

my $shared = MCP::Server::Tool::Web::Budget.new(total-bytes => 100_000);
for @urls -> $url {
    last if $shared.expired || !$shared.remaining-bytes;
    my $page = $fetcher.fetch($url, budget => $shared);
    say "{$url}: {$page.byte-count} bytes, {$shared.remaining-bytes} left";
}

=end code

=head1 DESCRIPTION

Three limits and a clock, in one object that everything on a single tool call
shares. It is deliberately dumb: it has no idea what a socket is, holds no
timer, starts no thread, and cannot fail. The Fetcher asks it questions and
acts on the answers.

=head2 The clock starts at construction

C<total-seconds> is measured from the moment the budget is made, not from the
first request — connecting is part of what the caller is waiting for, and a
crawl that spends its whole allowance on DNS should say so rather than run
long. C<remaining-seconds> never goes negative; it bottoms out at zero, which
is what C<expired> reports.

=head2 The ledger cuts, it does not throw

C<take($n)> answers with how many of the C<$n> bytes the budget could afford —
C<$n> when there is room, less when there is not, zero when there is none.
That is the whole protocol: the caller appends what it was given, and if it
was given less than it asked for it knows the body was cut and can stop
reading. Nothing here throws, because a body that ran over a limit is a
B<result> ("here is the first 2 MB of it"), not an error.

C<truncated> latches True the first time C<take> gives back less than it was
asked for. It is not set merely by the budget running out on a body that had
already ended: the last chunk of a body that fits exactly is taken whole, and
a C<take(0)> asks for nothing and is given nothing.

=head2 Thread safety

The byte ledger is guarded by a lock. Body chunks arrive on the scheduler's
threads rather than the caller's, and a crawl may one day fetch in parallel;
an under-counted ledger would be a silent hole in the byte cap rather than a
visible bug.

=end pod

#| One tool call's allowance of time, bytes and redirect hops. Construct one
#| per call and pass the same object to every fetch that call makes.
unit class MCP::Server::Tool::Web::Budget;

#| Wall-clock seconds for the whole call, counted from construction.
has Real:D $.total-seconds = 60;

#| Bytes of response body the whole call may retain. Two megabytes is the
#| default: comfortably more than any documentation page, far less than a
#| release tarball someone linked to by mistake.
has Int:D $.total-bytes = 2_097_152;

#| Redirect hops a single fetch may follow before giving up.
has Int:D $.max-redirects = 5;

#| When the clock started. Exposed so a caller can report how long a whole
#| crawl took without keeping its own stopwatch.
has Instant:D $.started = now;

has Int:D  $!spent = 0;
has Bool:D $!truncated = False;
has Lock:D $!lock = Lock.new;

submethod TWEAK {
	die "total-seconds must be positive; got $!total-seconds"
		unless $!total-seconds > 0;
	die "total-bytes must be positive; got $!total-bytes"
		unless $!total-bytes > 0;
	die "max-redirects cannot be negative; got $!max-redirects"
		if $!max-redirects < 0;
}

# === Time ===

#| Seconds since the budget was made.
method elapsed(--> Real:D) {
	(now - $!started).Real;
}

#| Seconds left before the deadline, never below zero.
method remaining-seconds(--> Real:D) {
	my $left = $!total-seconds - self.elapsed;
	$left > 0 ?? $left !! 0;
}

#| Has the deadline passed?
method expired(--> Bool:D) {
	self.remaining-seconds <= 0;
}

# === Bytes ===

#| Spend up to C<$n> bytes and answer how many were actually available. A
#| short answer means the body was cut here, and latches C<truncated>.
method take(Int:D $n --> Int:D) {
	return 0 if $n <= 0;
	$!lock.protect: {
		my $room = $!total-bytes - $!spent;
		$room = 0 if $room < 0;
		my $given = $n <= $room ?? $n !! $room;
		$!spent += $given;
		# Only a chunk that existed and was not kept counts as truncation —
		# a body that simply ended is not truncated, however little of the
		# budget it used.
		$!truncated = True if $given < $n;
		$given;
	}
}

#| Bytes taken so far, across every fetch sharing this budget.
method spent-bytes(--> Int:D) {
	$!lock.protect: { $!spent }
}

#| Bytes still available.
method remaining-bytes(--> Int:D) {
	$!lock.protect: {
		my $room = $!total-bytes - $!spent;
		$room > 0 ?? $room !! 0;
	}
}

#| Did the ledger ever have to refuse bytes that existed?
method truncated(--> Bool:D) {
	$!lock.protect: { $!truncated }
}

#| A one-line summary for notices and refusal messages.
method describe(--> Str:D) {
	"budget: {$!total-bytes} bytes, {$!total-seconds}s, {$!max-redirects} redirects"
		~ " (spent {self.spent-bytes} bytes, {self.elapsed.round(0.01)}s)";
}
