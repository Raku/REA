=begin pod

=head1 NAME

MCP::Server::Tool::Web::Transport - a Cro HTTP client that checks the address
of every socket it opens before it writes a byte to it

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Guard;
use MCP::Server::Tool::Web::Transport;

my $transport = MCP::Server::Tool::Web::Transport.new(
    guard => MCP::Server::Tool::Web::Guard.new,
);

# An ordinary Cro::HTTP::Client — except that the connection under it was
# vetted after connecting and before anything was sent.
my $resp = await $transport.client.get('https://example.com/', follow => False);
say $resp.status;

# A host that resolves onto this machine's own network is refused with the
# address it actually resolved to, and the key that would permit it.
{
    await $transport.client.get('http://localhost:8080/');
    CATCH {
        when X::MCP::Server::Tool::Web::Blocked {
            say .address-class;     # loopback
            say .message;           # ... To permit it, set allow-loopback ...
        }
    }
}

=end code

Test rigs inject the one thing that talks to the network — hostnames stay
real, sockets go wherever the rig says:

=begin code :lang<raku>

my %ports = 'example.test' => 39662, 'other.test' => 39663;

my $rig = MCP::Server::Tool::Web::Transport.new(
    guard       => MCP::Server::Tool::Web::Guard.new(:allow-loopback),
    connect-tcp => -> Str $host, Int $port {
        IO::Socket::Async.connect('127.0.0.1', %ports{$host} // $port);
    },
    # The origin's self-signed certificate, trusted for this rig only.
    ca-file => 'resources/test-cert.pem',
);

# The origin sees 'Host: example.test' and the TLS handshake carries
# example.test as its SNI name; the socket went to loopback.
await $rig.client.get('https://example.test/page');

=end code

=head1 DESCRIPTION

This is the SSRF floor's enforcement half — L<MCP::Server::Tool::Web::Guard>
decides, and this class makes sure the decision is taken about the connection
that is actually going to be used.

C<Cro::HTTP::Client.choose-connector> is a documented override point (Cro's
own testing module uses it). This class subclasses the client and returns a
connector that:

=item connects with plain TCP, B<even for https>;
=item reads C<.peer-host> — the address of the socket it is holding;
=item asks the guard about that address, and closes the socket and throws
      C<X::MCP::Server::Tool::Web::Blocked> if the answer is no;
=item sets C<TCP_NODELAY>, exactly as Cro's own connectors do;
=item and only then, for https, upgrades the vetted socket to TLS with
      C<IO::Socket::Async::SSL.upgrade-client($sock, :host($host))> — the
      C<:host> named argument sets both the SNI name and the name the
      certificate is verified against, independently of what was connected to.

=head2 Why this kills DNS rebinding rather than narrowing it

The address that is checked B<is> the address of the established connection.
A name cannot be re-resolved out from under a live TCP socket, so there is no
window between the check and the use: the usual "resolve, check, connect"
shape has one, and an attacker who controls a DNS zone with a one-second TTL
owns it. At the point of the check nothing has been written — no request
line, no C<Host> header, not even a TLS ClientHello — so a refused connection
is a TCP handshake and an immediate reset, and the peer learns nothing about
what was going to be asked for.

Numeric obfuscations come out in the wash: C<0x7f000001>, C<017700000001>,
C<127.1> and C<2130706433> are all canonicalised by the resolver, and the
socket reports C<127.0.0.1> however the host was spelled. (They are refused
earlier, on shape, by L<MCP::Server::Tool::Web::Url> — but the floor does not
depend on that.)

=head2 Connection reuse is a security property here, not a risk

The client is built with C<persistent =E<gt> True>, and that is deliberate: a
cached pipeline is an B<already vetted, still established> socket. Nothing can
retarget it, because retargeting a name has no effect on an open connection.
Turning persistence off would mean re-connecting — and re-checking — more
often, which is not safer, only slower.

The consequence to respect is the other way round: one client belongs to one
guard configuration. Never share a Transport between packs configured with
different allow-lists, because the second pack would inherit connections the
first one's rules approved. One Transport per Guard, one Guard per pack.

=head2 The proxy hazard

C<Cro::HTTP::Client> reads C<HTTP_PROXY> / C<HTTPS_PROXY> from the environment
even for client instances, and connects to the proxy instead of the URL's
host. The floor still holds — whatever the client is told to connect to is
what gets vetted, so an internal proxy is refused like any other internal
address — but "refused: 10.0.0.1 is private" is a baffling answer to a request
for C<https://example.com/>. So the environment is checked up front by
C<check-proxy> and the refusal names the variables, while
C<proxy =E<gt> 'http://proxy.corp:3128'> is available for operators who mean
it (its host is then guard-subject like any other). C<NO_PROXY> is honoured
exactly as Cro honours it, so a host the environment already exempts is not
refused.

=head2 HTTP/1.1 only

The client is pinned to HTTP/1.1. ALPN negotiation would let a gateway steer
us onto Cro's HTTP/2 client, whose failure modes here are silent hangs; a
documentation page is not worth that. The connector still exposes
C<alpn-result>, because Cro's version-conditional pipeline asks for it when
the version is B<not> pinned, and a connector that answers it is one less
thing to remember if that pin ever moves.

=end pod

use Cro::Connector;
use Cro::HTTP::Client;
use Cro::TCP;
use Cro::TCP::NoDelay;
use Cro::Transform;
use Cro::Uri;
use IO::Socket::Async::SSL;

use MCP::Server::Tool::Web::Guard;
use MCP::Server::Tool::Web::X;

#| A guarded C<Cro::HTTP::Client> factory. One per pack instance: the client
#| it memoises caches connections, and those connections were vetted under
#| this object's guard.
unit class MCP::Server::Tool::Web::Transport;

#| The identity this pack presents. Sent as C<User-agent> on every request
#| that does not carry one of its own, and the product token robots.txt
#| groups are matched against. The version here tracks META6.json by hand;
#| there is no reliable way to read a distribution's own version from inside
#| a module that also works from C<-Ilib>.
our constant DEFAULT-USER-AGENT =
	'MCP-Server-Tool-Web/0.1.0 (+https://github.com/m-doughty/MCP-Server-Tool-Web)';

#| The policy this transport enforces. Every socket it opens is checked
#| against this object, so a Transport and a Guard belong together for life.
has MCP::Server::Tool::Web::Guard:D $.guard = MCP::Server::Tool::Web::Guard.new;

#| Sent as C<User-agent> on requests that do not carry one of their own.
has Str:D $.user-agent = DEFAULT-USER-AGENT;

#| A PEM file of certificate authorities to trust B<in addition to> the
#| system's. Test rigs point this at a self-signed origin certificate; in
#| production it is normally left unset.
has Str $.ca-file;

#| An explicit proxy URL. Given one, requests go through it and its host is
#| checked by the guard like any other host. Left unset — the normal case —
#| C<HTTP_PROXY>/C<HTTPS_PROXY> in the environment are refused rather than
#| silently obeyed.
has Str $.proxy;

#|( How a TCP connection is made: C<($host, $port --E<gt> Promise[IO::Socket::Async])>.
    This is the single seam a test rig replaces, and the only thing in this
    class that touches the network. Replacing it does not weaken the floor —
    whatever socket comes back still has its C<peer-host> checked. )
has &!connect-tcp is built = -> Str $host, Int $port {
	IO::Socket::Async.connect($host, $port);
};

has $!client;
has Lock:D $!lock = Lock.new;
has @!open-sockets;

submethod TWEAK {
	with $!proxy {
		# Validated now rather than at first use: a typo in a config file
		# should not surface as a puzzling connection failure an hour later.
		my $uri = try Cro::Uri.parse($_);
		die "The proxy setting must be an absolute URL like 'http://proxy.example:3128'; got '$_'"
			unless $uri.defined && ($uri.scheme // '').lc eq 'http' | 'https';
	}
}

# === The connector ===
#
# These classes are lexical to this file so that no Cro type appears in the
# pack's own interfaces, and they are declared here — above the methods that
# name them — because a `my` declaration is only visible after its
# declaration point.

#| Wraps whichever socket survived the check — plain or TLS — in the
#| C<Cro::TCP::Message> transform the rest of Cro's pipeline expects. One
#| class serves both, because C<IO::Socket::Async> and
#| C<IO::Socket::Async::SSL> answer the same three methods.
my class GuardedTransform does Cro::Transform {
	has $.socket is required;
	has $.alpn;
	has &.on-close;

	method consumes() { Cro::TCP::Message }
	method produces() { Cro::TCP::Message }

	#| HTTP/1.1 is pinned, so nothing consults this — see the Pod. It exists
	#| so that unpinning the version does not silently break the pipeline.
	method alpn-result() { $!alpn }

	method transformer(Supply $incoming --> Supply) {
		supply {
			whenever $incoming {
				whenever $!socket.write(.data) {}
			}
			whenever $!socket.Supply(:bin) -> $data {
				emit Cro::TCP::Message.new(:$data);
				LAST done;
			}
			CLOSE {
				$!socket.close;
				&!on-close($!socket) with &!on-close;
			}
		}
	}
}

#| The connector proper: connect, check, then — only for https — upgrade.
#| One instance per pipeline, built by the factory below.
my class GuardedConnector does Cro::Connector {
	has Bool:D $.secure is required;
	has MCP::Server::Tool::Web::Guard:D $.guard is required;
	has Str $.ca-file;
	has &.connect-tcp is required;
	has &.register;
	has &.unregister;

	method consumes() { Cro::TCP::Message }
	method produces() { Cro::TCP::Message }

	method connect(:$nodelay, *%options --> Promise) {
		# Cro passes the host and port it wants, plus whatever TLS options the
		# client was built with. The host is both what the guard is told about
		# and what TLS verifies against, so it is taken out of the option bag
		# rather than left to be forwarded blindly.
		my Str $host = (%options<host>:delete // 'localhost').Str;
		my Int $port = (%options<port>:delete // ($!secure ?? 443 !! 80)).Int;
		# Untyped on purpose: an absent %options key is Any, not Str.
		my $ca = $!ca-file // %options<ca-file>;

		start {
			my $sock = await &!connect-tcp($host, $port);

			# THE CHECK. Nothing has been written to this socket, and nothing
			# will be unless the guard says so. $peer is the address of this
			# connection — not a second lookup of $host, which is what makes
			# rebinding a non-event rather than a narrowed window.
			my $peer = (try $sock.peer-host) // '';
			my $ok = False;
			{
				# The guard's refusal is what the caller should see, so the
				# socket is closed on the way past.
				CATCH {
					default {
						try $sock.close;
						.rethrow;
					}
				}
				$ok = $!guard.check-address($host, $peer);
			}
			# Belt and braces: check-address either returns True or throws,
			# but a guard subclass that returned False would otherwise be a
			# silent bypass.
			unless $ok {
				try $sock.close;
				X::MCP::Server::Tool::Web::Blocked.new(
					host    => $host,
					address => $peer,
					remedy  => 'The guard refused this address without saying why,'
						~ ' which is a bug in the guard rather than a setting.',
				).throw;
			}

			nodelay($sock) if $nodelay;

			my $final = $sock;
			my $alpn;
			if $!secure {
				# :host sets the SNI name and the name the certificate is
				# checked against; it is deliberately independent of what was
				# connected to, which is the whole point of vetting the
				# address first and naming the host second.
				$final = await IO::Socket::Async::SSL.upgrade-client(
					$sock, host => $host, |($ca.defined ?? (ca-file => $ca) !! ()),
				);
				$alpn = try $final.alpn-result;
			}

			&!register($final) with &!register;
			GuardedTransform.new(
				socket   => $final,
				alpn     => $alpn,
				on-close => &!unregister,
			);
		}
	}
}

#| Built once per Transport and handed to the client, which asks it for the
#| plaintext or TLS flavour as it builds each pipeline.
my class ConnectorFactory {
	has MCP::Server::Tool::Web::Guard:D $.guard is required;
	has Str $.ca-file;
	has &.connect-tcp is required;
	has &.register;
	has &.unregister;

	method for(Bool:D :$secure --> GuardedConnector:D) {
		GuardedConnector.new(
			:$secure, :$!guard, :$!ca-file,
			connect-tcp => &!connect-tcp,
			register    => &!register,
			unregister  => &!unregister,
		);
	}
}

#| The subclass whose only job is to answer C<choose-connector> with our
#| connector instead of Cro's. Everything else about it is a stock client —
#| C<Cro.compose> accepts connector B<instances>, so no Cro internals are
#| reimplemented here.
my class GuardedClient is Cro::HTTP::Client {
	has ConnectorFactory:D $.connector is required;

	method choose-connector($secure) {
		$!connector.for(secure => ?$secure);
	}
}

# === The client ===

#| The memoised C<Cro::HTTP::Client>. Built on first use, shared by every
#| request this Transport makes, and holding the connection cache that makes
#| reuse of already-vetted sockets possible.
method client(--> Cro::HTTP::Client:D) {
	$!lock.protect: {
		unless $!client.defined {
			my %args =
				http       => '1.1',
				persistent => True,
				# Redirects are followed by the Fetcher, one hop at a time,
				# so that every hop is re-checked against the URL rules and
				# the guard. Cro following them internally would skip both
				# on hops 2..n.
				follow     => False,
				user-agent => $!user-agent,
				connector  => ConnectorFactory.new(
					guard       => $!guard,
					ca-file     => $!ca-file,
					connect-tcp => &!connect-tcp,
					register    => -> $sock { self!register($sock) },
					unregister  => -> $sock { self!unregister($sock) },
				);
			with $!proxy {
				%args<http-proxy>  = $_;
				%args<https-proxy> = $_;
			}
			$!client = GuardedClient.new(|%args);
		}
		$!client;
	}
}

#| Close every connection this transport still holds open and forget the
#| client. Entirely optional — nothing here runs a timer or a thread, so a
#| pack that simply stops using its Transport leaks nothing that outlives the
#| process. Calling it is polite in long-lived hosts, and the Transport is
#| usable again afterwards: the next C<client> call builds a fresh one.
method close(--> Nil) {
	my @sockets;
	$!lock.protect: {
		@sockets = @!open-sockets;
		@!open-sockets = ();
		$!client = Nil;
	}
	for @sockets -> $sock {
		# A socket the peer already closed throws here; that is the state we
		# wanted it in anyway.
		try $sock.close;
	}
}

#| How many connections this transport currently holds open — diagnostics,
#| and the assertion a connection-reuse test needs.
method open-connections(--> Int:D) {
	$!lock.protect: { @!open-sockets.elems }
}

method !register($sock --> Nil) {
	$!lock.protect: { @!open-sockets.push($sock) }
}

method !unregister($sock --> Nil) {
	$!lock.protect: {
		@!open-sockets = @!open-sockets.grep({ $_ !=== $sock }).Array;
	}
}

# === The proxy hazard ===

#| The environment variables that would silently redirect a request for
#| C<$host>, or the empty list when none would. Empty whenever an explicit
#| C<proxy> was configured (that one is deliberate) or C<NO_PROXY> already
#| exempts the host.
method proxy-vars(Str:D $host --> List:D) {
	return () if $!proxy.defined;
	return () if self!no-proxy($host);
	<HTTP_PROXY HTTPS_PROXY>.grep({ (%*ENV{$_} // '').trim.chars }).List;
}

#| Refuse to fetch C<$host> when the environment holds a proxy setting that
#| Cro would obey below the URL checks. Throws
#| C<X::MCP::Server::Tool::Web::Blocked> naming the variables; returns True
#| when there is nothing to refuse, so it reads as a guard clause.
method check-proxy(Str:D $host --> Bool:D) {
	my @vars = self.proxy-vars($host);
	return True unless @vars;

	my $names = @vars.join(' and ');
	X::MCP::Server::Tool::Web::Blocked.new(
		host       => $host,
		config-key => 'proxy',
		note       => "$names in the environment would send this request to a"
			~ ' proxy instead of to the host it names, which puts the connection'
			~ ' somewhere the URL cannot account for.',
		remedy     => 'To use that proxy deliberately, set the web config\'s'
			~ ' "proxy" key to its URL — its own address is then checked like'
			~ " any other host. To bypass it, unset $names, or name this host"
			~ ' in NO_PROXY.',
	).throw;
}

#| C<NO_PROXY> matching, deliberately identical to Cro's own (suffix match, or
#| C<*> for everything) — anything stricter would refuse fetches Cro was never
#| going to proxy in the first place.
method !no-proxy(Str:D $host --> Bool:D) {
	my $no-proxy = (%*ENV<NO_PROXY> // '').trim;
	return False unless $no-proxy.chars;
	so $no-proxy.split(',').map(*.trim).grep(*.chars)
		.first({ $_ eq '*' || $host.ends-with($_) }).defined;
}
