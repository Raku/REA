=begin pod

=head1 NAME

MCP::Server::Tool::Web::SearchProvider - the pluggable seam behind C<web_search>

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::SearchProvider;

class MyProvider does MCP::Server::Tool::Web::SearchProvider {
    method name(--> Str:D) { 'my-provider' }

    method search(Str:D $query, Int:D $count --> List:D) {
        # ... call out to whatever search backend, then ...
        (
            %( title => 'Example', url => 'https://example.com/', snippet => '...' ),
        );
    }
}

=end code

=head1 DESCRIPTION

C<web_search> does not talk to any particular search engine directly —
it asks whatever object composes this role. C<MCP::Server::Tool::Web>
picks a concrete implementation (L<MCP::Server::Tool::Web::Provider::Brave>
by default) via its C<provider> attribute; tests compose a tiny fake
that never touches the network. A provider is exactly two methods.

=head1 METHODS

=head2 method name

=begin code :lang<raku>

method name(--> Str:D) { ... }

=end code

A short, stable, lowercase identifier for the provider (C<'brave'>,
C<'my-provider'>, ...). C<web_search>'s JSON result carries this under
its C<provider> key, so callers — and the model reading the tool
output — can tell which engine actually answered.

=head2 method search

=begin code :lang<raku>

method search(Str:D $query, Int:D $count --> List:D) { ... }

=end code

Run one search and return up to C<$count> results as a C<List> of
plain C<Hash>es, each shaped:

=item C<title>   — C<Str:D>, the result's headline text.
=item C<url>     — C<Str:D>, the result's absolute URL.
=item C<snippet> — C<Str:D>, a short excerpt of the page (empty string
  when the provider has none, never omitted).
=item C<age>     — C<Str>, OPTIONAL. A human-readable freshness hint
  ("3 days ago", "2026-08-01", ...) when the provider supplies one.
  Omitted from the Hash entirely when unknown — callers must check
  C<:exists>, not merely definedness.

An empty C<List> is a legitimate, non-error answer (the query matched
nothing, or the provider only had non-web results to offer) — it is
NOT how failure is reported.

B<Failure is reported by throwing.> Implementations C<die> with a
plain C<Str> message (never a typed exception the caller would have to
know about) whose B<first line is a teaching sentence> — one a person
(or the model that triggered the call) can act on without reading
source: it names what went wrong, and, wherever one exists, the
specific config key or environment variable that would change the
outcome. C<MCP::Server::Tool::Web>'s C<web_search> tool catches
whatever a provider throws and surfaces C<.message> verbatim as the
tool's C<is_error> text, so a vague "search failed" here becomes the
whole story the model gets. Multi-line messages are fine (extra
context on later lines); the first line alone must stand on its own.

C<$query> is guaranteed non-empty and already length-checked by the
tool layer against the provider's advertised limit before this method
is ever called; C<$count> is guaranteed to be a positive integer
within whatever range the tool layer negotiated. A provider is free to
apply its own tighter limits (and should die with a teaching message,
not silently clamp, if it does) but does not need to re-validate the
basics.

=head1 AUTHOR

Matt Doughty

=head1 COPYRIGHT AND LICENSE

Copyright 2026 Matt Doughty

This library is free software; you can redistribute it and/or modify
it under the Artistic License 2.0.

=end pod

unit role MCP::Server::Tool::Web::SearchProvider;

method name(--> Str:D) { ... }
method search(Str:D $query, Int:D $count --> List:D) { ... }
