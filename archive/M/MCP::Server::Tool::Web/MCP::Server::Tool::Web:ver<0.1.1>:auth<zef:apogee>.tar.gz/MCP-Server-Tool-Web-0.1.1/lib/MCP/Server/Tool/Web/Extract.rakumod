=begin pod

=head1 NAME

MCP::Server::Tool::Web::Extract - turning a fetched page into text a model can read

=head1 SYNOPSIS

=begin code :lang<raku>
use MCP::Server::Tool::Web::Extract;

my $html = q:to/HTML/;
	<!doctype html>
	<html>
	<head><title>Raku &amp; regexes</title><script>var x = "</div>";</script></head>
	<body>
	  <nav><a href="/">Home</a></nav>
	  <main>
	    <h1>Grammars</h1>
	    <p>See the <a href="/docs/grammar">grammar docs</a> for&nbsp;more.</p>
	    <pre><code>rule TOP { &lt;thing&gt;+ }</code></pre>
	  </main>
	</body>
	</html>
	HTML

say extract-title($html);
# Raku & regexes

say html-to-text($html, base => 'https://example.test/page');
# # Grammars
#
# See the [grammar docs](https://example.test/docs/grammar) for more.
#
# rule TOP { <thing>+ }

.say for extract-links($html, base => 'https://example.test/page');
# {nofollow => False, url => https://example.test/}
# {nofollow => False, url => https://example.test/docs/grammar}

say text-for('{"b":1,"a":2}', content-type => 'application/json');
# {
#   "a": 2,
#   "b": 1
# }
=end code

=head1 DESCRIPTION

Everything in this module is a pure function of its arguments: no I/O, no
network, no module state, no clock, no locale. The same string in gives the
same string out, byte for byte, on every platform — C<web_grep> numbers the
lines of this output and quotes them back with line numbers, so a rendering
that shifted by a blank line between two runs would make every citation a lie.
The determinism is tested, not hoped for.

The parser is a single hand-rolled character scanner with a small state
machine. It is deliberately B<not> a chain of regexes: real pages carry
unterminated comments, tag soup, minified scripts with C<< </div> >> inside a
JavaScript string, and megabytes of markup, and a regex chain over that is one
pathological input away from taking a minute. Every scan here advances
monotonically through the document, so a 1MB page is linear work (a test pins
the wall clock).

=head2 What is thrown away

Comments (including an unterminated C<< <!-- >> that runs to the end of the
document), C<< <!DOCTYPE …> >>, C<< <![CDATA[…]]> >> and processing
instructions never reach the renderer. Neither does the content of
C<< <script> >>, C<< <style> >>, C<< <svg> >>, C<< <template> >>,
C<< <iframe> >>, C<< <noscript> >> or C<< <head> >>.

Those elements are skipped by scanning for their literal closing tag rather
than by parsing what is inside them, which is the only way to survive real
scripts:

=begin code :lang<raku>
say html-to-text('<script>var a = "</div>";</script><p>Kept</p>');
# Kept
=end code

C<< <head> >> is the one exception to "skip by literal close tag": it is
dropped a step later, from the token stream, so that a C<< <base href> >>
inside it is still available for resolving links, and so that a document with
no C<< </head> >> loses its head only as far as its C<< <body> >> rather than
losing everything. C<< <title> >> and C<< <textarea> >> keep their text as one
verbatim chunk, so C<< <title>a < b</title> >> reads correctly.

=head2 Which part of the page is rendered

In order, first hit wins, and a candidate that turns out to hold no text at all
is passed over:

=item1 the first C<< <main> >>;
=item1 otherwise every C<< <article> >>, concatenated in document order;
=item1 otherwise C<< <body> >> with C<< <nav> >>, C<< <header> >>,
       C<< <footer> >> and C<< <aside> >> removed;
=item1 otherwise the whole document.

The furniture removal only happens in the C<< <body> >> case: a page whose
author put everything inside a C<< <main> >> has already said where the content
is, and a document with no C<< <body> >> at all is usually a fragment in which
every element is content.

=head2 How it renders

Output is markdown-flavoured, because that is the shape a language model reads
best and the shape it will quote back:

=begin table
Element               | Rendered as
======================|=================================================
C<< <h1> >>…C<< <h6> >> | C<#> … C<######> then the heading text
C<< <p> >>            | text with a blank line around it
C<< <div> >>          | text with a line break around it
C<< <li> >>           | C<- item>, indented two spaces per level of nesting
C<< <pre> >>          | verbatim: line breaks and indentation survive
C<< <a href> >>       | C<[text](absolute-url)>
C<< <img alt> >>      | C<[image: alt]>
C<< <br> >>           | a line break
C<< <td> >>, C<< <th> >> | cells joined with C< | >, one row per line
=end table

Anchors are resolved against the document's C<< <base href> >> if it has one,
otherwise against the C<:base> you pass (normally the fetch's final URL). A
link that cannot be made absolute, that is not C<http> or C<https>, or that
points at the page being rendered is written as its bare text — a
C<[Skip to content](#main)> line teaches a model nothing and costs it tokens.
An anchor with no text at all disappears entirely, as does an C<< <img> >> with
no C<alt>; both are decoration.

Inside C<< <pre> >> collapsing is suspended and links are left as plain text,
because code samples are the payload and C<[foo](https://…)> in the middle of
one is corruption rather than annotation.

=head2 Entities

C<decode-entities> handles the named entities that actually turn up in prose
(about eighty of them), plus numeric C<&#8212;> and hex C<&#x2014;> forms with
full codepoint validation. Deliberate choices:

=item1 C<&nbsp;> becomes an ordinary space (U+0020), and so do C<&ensp;>,
       C<&emsp;>, C<&thinsp;> and a literal U+00A0 in the source. A model that
       greps for C<"foo bar"> has to match text a designer wrote with a
       non-breaking space.
=item1 Zero-width and directional marks (C<&shy;>, C<&zwj;>, C<&lrm;>, …)
       become nothing at all: invisible characters that break a literal search
       are worse than useless in extracted text.
=item1 Surrogates, C<&#0;> and anything above U+10FFFF are dropped — they
       cannot be represented, and a replacement character would only be noise a
       grep would have to learn to ignore.
=item1 C<&#128;>..C<&#159;> are read as Windows-1252, exactly as the HTML
       standard requires; that is where real pages' curly quotes live.
=item1 An unknown name is left B<verbatim>: C<&foo;> stays C<&foo;>, and a bare
       C<&> stays a bare C<&>. Guessing is how C<AT&T> turns into something
       that is not C<AT&T>.

A named entity must carry its semicolon. The legacy semicolon-less forms are
ambiguous (C<&notit;> is famously two different things) and this is a reading
aid, not a browser.

=head2 Whitespace, and why it is nailed down

Outside C<< <pre> >>: runs of whitespace collapse to one space, every line is
trimmed, and a run of blank lines becomes a single blank line. Leading and
trailing blank lines are removed and the result does B<not> end with a newline.

That is the whole contract C<web_grep> depends on. Line I<n> of this output is
line I<n> of the same output tomorrow, on macOS, Linux and Windows alike; input
line endings are normalised to C<\n> before anything else happens, so a page
served with CRLF and the same page served with LF extract identically.

=head2 Links for the crawler

C<extract-links> works on the B<raw> HTML rather than on the extracted region:
a crawler wants the site's navigation, which is exactly what C<html-to-text>
throws away. It reports each link once, in document order, with whether it was
marked C<rel="nofollow">:

=begin code :lang<raku>
my @links = extract-links(
	'<a href="/a">A</a> <a href="/a#x">again</a> <a rel="nofollow" href="/b">B</a>',
	base => 'https://example.test/',
);
# ({url => https://example.test/a, nofollow => False},
#  {url => https://example.test/b, nofollow => True })
=end code

Fragments are stripped before deduplication (C</a> and C</a#x> are one page),
only C<http> and C<https> survive, and a URL that appears both with and without
C<nofollow> is reported as followable — the restrictive marking has to be
unanimous to count.

=head2 Dispatching on content type

C<text-for> is the seam the tool layer calls with whatever the server said the
body was:

=begin table
Content type                      | Result
==================================|=========================================
C<text/html>, C<application/xhtml+xml> | extracted as HTML
C<text/*>                         | verbatim
C<application/json>, C<…+json>    | re-printed with C<:pretty :sorted-keys>
C<application/xml>, C<…+xml>      | verbatim
absent                            | sniffed from the content
C<image/*>, C<application/pdf>, … | refused, naming the type
=end table

JSON is pretty-printed because a 200KB API response on one line is one grep hit
that contains everything and locates nothing; sorted keys are what make two
fetches of the same document produce the same line numbers. A body that claims
to be JSON and is not comes back verbatim with a bracketed notice appended —
appended, not prepended, so the line numbers of the content itself do not shift
because of the diagnosis.

A binary type C<die>s rather than returning bytes-as-text. The message names
the type and the size, because "I cannot read a PDF" is something a model can
act on and 40KB of mojibake is not.

=head1 EXAMPLES

Extracting the readable part of a documentation page and numbering it the way
C<web_grep> does:

=begin code :lang<raku>
my $text = html-to-text($fetched.text, base => $fetched.final-url);
for $text.lines.kv -> $index, $line {
	say "{$fetched.final-url}:{$index + 1}:$line" if $line.contains('Signature');
}
=end code

Feeding a crawler's frontier, honouring C<nofollow>:

=begin code :lang<raku>
my @next = extract-links($body, base => $final-url)
	.grep({ !.<nofollow> })
	.map({ .<url> });
=end code

Reading a JSON API response and an HTML page through one call:

=begin code :lang<raku>
my $body = text-for(
	$response.text,
	content-type => $response.content-type,
	url          => $response.final-url,
	byte-count   => $response.byte-count,
);
=end code

Decoding entities on their own — useful for a title or a C<meta> description
pulled out of markup by something else:

=begin code :lang<raku>
say decode-entities('caf&eacute; &amp; cr&#232;me &mdash; 100&nbsp;%');
# café & crème — 100 %
say decode-entities('AT&T &unknown; &#xZZ;');
# AT&T &unknown; &#xZZ;
=end code

=head1 SEE ALSO

L<MCP::Server::Tool::Web|lib/MCP/Server/Tool/Web.rakumod> — the tool pack whose
C<web_fetch>, C<web_crawl> and C<web_grep> tools consume this module.

=end pod

use JSON::Fast;
use Cro::Uri;

unit module MCP::Server::Tool::Web::Extract;

#| Elements whose content is discarded wholesale.  Skipped by scanning for the
#| literal closing tag rather than by parsing: a minified script is full of
#| angle brackets that are not markup, and a parser that believes them loses
#| the rest of the page.
my constant DROP-ELEMENTS = <iframe noscript script style svg template>.Set;

#| Elements whose content is text but may contain characters that look like
#| markup.  Captured as one verbatim chunk (entities still decode).
my constant RAW-TEXT-ELEMENTS = <textarea title>.Set;

#| Elements that never have a closing tag, so a stray one must not open a
#| subtree that swallows the rest of the document.
my constant VOID-ELEMENTS =
	<area base br col embed hr img input link meta param source track wbr>.Set;

#| Removed from a <body> region: site furniture, repeated on every page of a
#| site, and never the thing that was asked for.
my constant FURNITURE-ELEMENTS = <aside footer header nav>.Set;

#| Everything HTML allows inside <head>.  Anything else means the head is over,
#| whether or not the document bothered to say so.
my constant HEAD-ELEMENTS = <
	base basefont bgsound link meta noscript script style template title
>.Set;

#| Rendered with a blank line before and after.
my constant PARAGRAPH-ELEMENTS = <
	address article aside blockquote details dialog dl fieldset figcaption
	figure footer form h1 h2 h3 h4 h5 h6 header hgroup hr main nav ol p pre
	section table ul
>.Set;

#| Rendered with a line break before and after.  Anything in neither set is
#| inline, which includes unknown elements: a custom element is inline by
#| default in a browser too.
my constant LINE-ELEMENTS = <
	caption dd div dt legend li optgroup option output summary tbody tfoot
	thead tr
>.Set;

my constant HEADING-ELEMENTS = <h1 h2 h3 h4 h5 h6>.Set;

#| The longest entity body we will look at, counting from just after the '&'.
#| Bounding it is what keeps a document full of bare ampersands linear: without
#| it, every '&' would scan to the end of the document looking for a ';'.
my constant MAX-ENTITY-BODY = 32;

#| Named character references, semicolon-terminated.  Not the full HTML5 table
#| of 2231 names — that is a browser's problem.  This is what turns up in prose
#| and in API documentation, which is what gets fetched.
my constant ENTITIES = {
	agrave => 'à',  alpha  => 'α',  amp    => '&',  apos   => "'",
	asymp  => '≈',  auml   => 'ä',  bdquo  => '„',  beta   => 'β',
	brvbar => '¦',  bull   => '•',  ccedil => 'ç',  cent   => '¢',
	copy   => '©',  curren => '¤',  Dagger => '‡',  dagger => '†',
	darr   => '↓',  deg    => '°',  delta  => 'δ',  divide => '÷',
	eacute => 'é',  egrave => 'è',  emsp   => ' ',  ensp   => ' ',
	equiv  => '≡',  euro   => '€',  frac12 => '½',  frac14 => '¼',
	frac34 => '¾',  gamma  => 'γ',  ge     => '≥',  gt     => '>',
	harr   => '↔',  hellip => '…',  iexcl  => '¡',  infin  => '∞',
	iquest => '¿',  laquo  => '«',  larr   => '←',  ldquo  => '“',
	le     => '≤',  lrm    => '',   lsaquo => '‹',  lsquo  => '‘',
	lt     => '<',  mdash  => '—',  micro  => 'µ',  middot => '·',
	minus  => '−',  mu     => 'μ',  nbsp   => ' ',  ndash  => '–',
	ne     => '≠',  ntilde => 'ñ',  omega  => 'ω',  ordf   => 'ª',
	ordm   => 'º',  ouml   => 'ö',  para   => '¶',  permil => '‰',
	pi     => 'π',  plusmn => '±',  pound  => '£',  Prime  => '″',
	prime  => '′',  prod   => '∏',  quot   => '"',  raquo  => '»',
	rarr   => '→',  rdquo  => '”',  reg    => '®',  rlm    => '',
	rsaquo => '›',  rsquo  => '’',  sbquo  => '‚',  sect   => '§',
	shy    => '',   sigma  => 'σ',  sum    => '∑',  sup1   => '¹',
	sup2   => '²',  sup3   => '³',  szlig  => 'ß',  theta  => 'θ',
	thinsp => ' ',  times  => '×',  trade  => '™',  uarr   => '↑',
	uuml   => 'ü',  yen    => '¥',  zwj    => '',   zwnj   => '',
};

#| The HTML standard's override for numeric references in the C1 range: pages
#| authored in Windows-1252 and served as UTF-8 are full of &#146; where they
#| mean a right single quote, and a literal U+0092 helps nobody.
my constant CP1252-OVERRIDES = {
	0x80 => 0x20AC, 0x82 => 0x201A, 0x83 => 0x0192, 0x84 => 0x201E,
	0x85 => 0x2026, 0x86 => 0x2020, 0x87 => 0x2021, 0x88 => 0x02C6,
	0x89 => 0x2030, 0x8A => 0x0160, 0x8B => 0x2039, 0x8C => 0x0152,
	0x8E => 0x017D, 0x91 => 0x2018, 0x92 => 0x2019, 0x93 => 0x201C,
	0x94 => 0x201D, 0x95 => 0x2022, 0x96 => 0x2013, 0x97 => 0x2014,
	0x98 => 0x02DC, 0x99 => 0x2122, 0x9A => 0x0161, 0x9B => 0x203A,
	0x9C => 0x0153, 0x9E => 0x017E, 0x9F => 0x0178,
};

#| Codepoints that decode to something invisible.  Mapped here rather than in
#| the entity table so that the named form and the numeric form of the same
#| character behave identically: &nbsp;, &#160; and &#xA0; are all one space.
my constant INVISIBLE-CODEPOINTS = {
	0x00A0 => ' ',  0x00AD => '',   0x2002 => ' ',  0x2003 => ' ',
	0x2009 => ' ',  0x200B => '',   0x200C => '',   0x200D => '',
	0x200E => '',   0x200F => '',   0x202F => ' ',  0xFEFF => '',
};

#| Content types whose bytes are not text in any useful sense.  Whole families
#| are handled by BINARY-PREFIXES below.
my constant BINARY-TYPES = <
	application/epub+zip application/gzip application/java-archive
	application/msword application/octet-stream application/pdf
	application/postscript application/vnd.ms-excel
	application/vnd.ms-powerpoint application/wasm application/x-7z-compressed
	application/x-bzip2 application/x-msdownload application/x-rar-compressed
	application/x-tar application/x-xz application/zip application/zstd
>.Set;

my constant BINARY-PREFIXES = <audio/ font/ image/ model/ video/>;

#| Application types that are text despite not living under text/.
my constant TEXT-APPLICATION-TYPES = <
	application/ecmascript application/graphql application/javascript
	application/sql application/toml application/x-javascript
	application/x-ndjson application/x-sh application/x-www-form-urlencoded
	application/x-yaml application/yaml
>.Set;

#| Enough of a document's opening for it to be HTML rather than some other
#| angle-bracket format.  Only consulted when nobody told us the content type.
my constant HTML-MARKERS = (
	'<!doctype html', '<html', '<head', '<body', '<div', '<p>', '<p ', '<br',
	'<span', '<table', '<h1', '<li>', '<ul', '<meta ', '<script', '<title',
	'<a href',
);

# ---------------------------------------------------------------- primitives

my sub is-space(Str $ch --> Bool:D) {
	$ch eq ' ' || $ch eq "\n" || $ch eq "\t" || $ch eq "\f" || $ch eq "\r";
}

my sub is-alpha(Str $ch --> Bool:D) {
	return False if $ch eq '';
	my $ord = $ch.ord;
	(0x41 <= $ord <= 0x5A) || (0x61 <= $ord <= 0x7A);
}

#| What may appear in a tag or attribute name.  Generous on purpose: custom
#| elements use '-', XML islands from word processors use ':', and refusing
#| them would turn a tag into visible text.
my sub is-name-char(Str $ch --> Bool:D) {
	return False if $ch eq '';
	my $ord = $ch.ord;
	(0x41 <= $ord <= 0x5A) || (0x61 <= $ord <= 0x7A) || (0x30 <= $ord <= 0x39)
		|| $ch eq '-' || $ch eq '_' || $ch eq ':' || $ch eq '.';
}

#| CRLF is a single grapheme in Raku, so a document served with CRLF endings
#| would never split on "\n" and every <pre> block would come out as one line.
#| Normalising once, up front, is what makes the same page extract identically
#| however its server chose to end its lines.
my sub normalize-newlines(Str:D $text --> Str:D) {
	my $out = $text;
	$out = $out.subst("\r\n", "\n", :g) if $out.contains("\r\n");
	$out = $out.subst("\r", "\n", :g)   if $out.contains("\r");
	$out;
}

# ------------------------------------------------------------------ entities

my sub all-digits(Str:D $text, Bool:D :$hex = False --> Bool:D) {
	so $text.chars && !$text.comb.first: {
		my $ord = .ord;
		!((0x30 <= $ord <= 0x39)
			|| ($hex && ((0x41 <= $ord <= 0x46) || (0x61 <= $ord <= 0x66))));
	};
}

#| The replacement for one entity body (what sits between '&' and ';'), or an
#| undefined Str when this is not an entity we know — in which case the caller
#| leaves the source text exactly as it found it.
my sub entity-replacement(Str:D $body --> Str) {
	return Str if $body eq '';
	return ENTITIES{$body} // Str unless $body.starts-with('#');

	my $digits = $body.substr(1);
	my Int $code;
	if $digits.lc.starts-with('x') {
		my $hex = $digits.substr(1);
		return Str unless $hex.chars <= 6 && all-digits($hex, :hex);
		$code = :16($hex);
	}
	else {
		return Str unless $digits.chars <= 7 && all-digits($digits);
		$code = $digits.Int;
	}

	$code = CP1252-OVERRIDES{$code} if CP1252-OVERRIDES{$code}:exists;

	# Dropped rather than replaced: a surrogate or an out-of-range codepoint is
	# a broken document, and U+FFFD in the middle of a sentence is noise that a
	# literal search would have to learn to step over.
	return '' if $code == 0 || $code > 0x10FFFF || (0xD800 <= $code <= 0xDFFF);

	INVISIBLE-CODEPOINTS{$code} // $code.chr;
}

#| Decode HTML character references in a run of text.  Unknown names and bare
#| ampersands survive untouched.
our sub decode-entities(Str:D $text --> Str:D) is export {
	return $text unless $text.contains('&');

	my @out;
	my int $pos = 0;
	my int $len = $text.chars;

	while $pos < $len {
		my $amp = $text.index('&', $pos);
		without $amp {
			@out.push($text.substr($pos));
			last;
		}
		@out.push($text.substr($pos, $amp - $pos)) if $amp > $pos;

		# Bounded lookahead, never a scan to the end of the document: a page of
		# bare '&' characters is a linear amount of work, not a quadratic one.
		my $window = $text.substr($amp + 1, MAX-ENTITY-BODY);
		my $semi   = $window.index(';');
		my $rep    = $semi.defined ?? entity-replacement($window.substr(0, $semi)) !! Str;

		if $rep.defined {
			@out.push($rep);
			$pos = $amp + 1 + $semi + 1;
		}
		else {
			@out.push('&');
			$pos = $amp + 1;
		}
	}

	@out.join;
}

# ----------------------------------------------------------------- tokenizer

my class Token {
	has Str  $.kind is required;         # 'text' | 'start' | 'end'
	has Str  $.name = '';                # lowercased, for tags
	has Str  $.text = '';                # raw source text, entities undecoded
	has      %.attrs;                    # lowercased names => raw values
	has Bool $.self-closing = False;
}

#| Turn a document into a flat token stream.  One pass, forward only: every
#| search starts where the previous one stopped, and a needle that has been
#| shown to be absent from here on is never searched for again.  That memo is
#| what stops '<!<!<!<!…' — a perfectly legal thing to find in a broken page —
#| from costing a scan of the whole document per character.
my sub tokenize(Str:D $html --> Array) {
	my Token @tokens;
	my int $len = $html.chars;
	my int $pos = 0;

	# needle => [searched-from, first-hit-at-or-after-it (undefined = none)].
	# One remembered answer per needle is all it takes to keep the scanner
	# linear: knowing there is no '>' between here and position P answers every
	# question about '>' asked from anywhere in between, and a document that is
	# 20,000 copies of '<!' asks exactly that question 20,000 times.
	my %memo;

	my sub find(Str:D $needle, Int:D $from --> Int) {
		my $known = %memo{$needle};
		if $known.defined && $known[0] <= $from {
			return Int without $known[1];
			return $known[1] if $from <= $known[1];
		}
		my $at = $html.index($needle, $from);
		%memo{$needle} = [$from, $at // Int];
		$at // Int;
	}

	my sub push-text(Str:D $text) {
		@tokens.push: Token.new(kind => 'text', :$text) if $text ne '';
	}

	#| Position just past the '>' that closes the tag starting at $from, or the
	#| end of the document for a tag nobody ever closed.
	my sub after-tag(Int:D $from --> Int) {
		my $gt = find('>', $from);
		$gt.defined ?? $gt + 1 !! $len;
	}

	#| Find the literal closing tag for $name at or after $from.  Returns where
	#| its content ends and where to carry on from.
	my sub scan-to-close(Str:D $name, Int:D $from) {
		my int $probe = $from;
		loop {
			my $lt = find('</', $probe);
			return ($len, $len) without $lt;

			my $after = $lt + 2;
			if $html.substr($after, $name.chars).lc eq $name {
				my $follow = $html.substr($after + $name.chars, 1);
				if $follow eq '' || is-space($follow) || $follow eq '>' || $follow eq '/' {
					return ($lt, after-tag($after + $name.chars));
				}
			}
			$probe = $lt + 2;
		}
	}

	#| Read a tag or attribute name at $from; returns (name, next-offset).
	my sub read-name(Int:D $from) {
		my int $probe = $from;
		$probe++ while $probe < $len && is-name-char($html.substr($probe, 1));
		($html.substr($from, $probe - $from).lc, $probe);
	}

	#| Parse the attributes of a start tag whose name ended at $from.  Returns
	#| [attrs, self-closing, next-offset].  Never fails: a malformed tag is
	#| consumed up to the best '>' available and the document carries on.
	my sub read-attributes(Int:D $from) {
		my %attrs;
		my Bool $self-closing = False;
		my int $probe = $from;

		loop {
			$probe++ while $probe < $len && is-space($html.substr($probe, 1));
			last if $probe >= $len;

			my $ch = $html.substr($probe, 1);
			if $ch eq '>' {
				$probe++;
				last;
			}
			if $ch eq '/' {
				$self-closing = True if $html.substr($probe + 1, 1) eq '>';
				$probe++;
				next;
			}

			my ($name, $after-name) = read-name($probe);
			if $name eq '' {
				# Junk inside a tag: a stray quote, an '=' with no name.  Step
				# over exactly one character so the loop always progresses.
				$probe++;
				next;
			}
			$probe = $after-name;
			$probe++ while $probe < $len && is-space($html.substr($probe, 1));

			my $value = '';
			if $html.substr($probe, 1) eq '=' {
				$probe++;
				$probe++ while $probe < $len && is-space($html.substr($probe, 1));
				my $quote = $html.substr($probe, 1);
				# A quoted value may contain '>' — that is exactly why the end
				# of a tag cannot be found by searching for the next '>'.  A
				# quote that is never closed is treated as if it had not been
				# there at all: a browser would swallow the rest of the
				# document, and losing a whole page to one stray quote mark is
				# a worse answer than reading the page.
				my $close = ($quote eq '"' || $quote eq "'")
					?? find($quote, $probe + 1)
					!! Int;
				if $close.defined {
					$value = $html.substr($probe + 1, $close - $probe - 1);
					$probe = $close + 1;
				}
				else {
					my int $start = $probe;
					$probe++ while $probe < $len
						&& !is-space($html.substr($probe, 1))
						&& $html.substr($probe, 1) ne '>';
					$value = $html.substr($start, $probe - $start);
				}
			}

			# First declaration wins, as in every browser.
			%attrs{$name} = $value unless %attrs{$name}:exists;
		}

		[%attrs.item, $self-closing, $probe];
	}

	while $pos < $len {
		my $lt = find('<', $pos);
		without $lt {
			push-text($html.substr($pos));
			last;
		}
		push-text($html.substr($pos, $lt - $pos)) if $lt > $pos;

		my $next = $html.substr($lt + 1, 1);

		if $next eq '!' {
			if $html.substr($lt + 2, 2) eq '--' {
				# An unterminated comment runs to the end of the document, which
				# is what a browser does too: the rest was never going to render.
				my $end = find('-->', $lt + 4);
				$pos = $end.defined ?? $end + 3 !! $len;
			}
			elsif $html.substr($lt + 2, 7).uc eq '[CDATA[' {
				my $end = find(']]>', $lt + 9);
				$pos = $end.defined ?? $end + 3 !! $len;
			}
			else {
				# <!DOCTYPE …> and any other bogus declaration.
				$pos = after-tag($lt + 2);
			}
		}
		elsif $next eq '?' {
			# A processing instruction, or an XML declaration on an XHTML page.
			$pos = after-tag($lt + 2);
		}
		elsif $next eq '/' {
			my ($name, $after-name) = read-name($lt + 2);
			if $name eq '' {
				$pos = after-tag($lt + 2);   # '</ …' — a bogus comment
			}
			else {
				@tokens.push: Token.new(kind => 'end', :$name);
				$pos = after-tag($after-name);
			}
		}
		elsif is-alpha($next) {
			my ($name, $after-name) = read-name($lt + 1);
			my $parsed = read-attributes($after-name);
			my $self-closing = $parsed[1];
			@tokens.push: Token.new(
				kind => 'start', :$name, attrs => $parsed[0], :$self-closing,
			);
			$pos = $parsed[2];

			if !$self-closing && !VOID-ELEMENTS{$name} {
				if DROP-ELEMENTS{$name} {
					$pos = scan-to-close($name, $pos)[1];
					@tokens.push: Token.new(kind => 'end', :$name);
				}
				elsif RAW-TEXT-ELEMENTS{$name} {
					my ($content-end, $resume) = scan-to-close($name, $pos);
					push-text($html.substr($pos, $content-end - $pos));
					$pos = $resume;
					@tokens.push: Token.new(kind => 'end', :$name);
				}
			}
		}
		else {
			# '<' that starts nothing: '3 < 4', or a stray bracket at the end of
			# a truncated document.  It is text.  A run of them becomes one
			# token rather than one token each, which is what keeps a document
			# made of nothing but '<' cheap.
			my int $end = $lt + 1;
			while $end < $len && $html.substr($end, 1) eq '<' {
				my $after = $html.substr($end + 1, 1);
				last if is-alpha($after) || $after eq '/' || $after eq '!' || $after eq '?';
				$end++;
			}
			push-text($html.substr($lt, $end - $lt));
			$pos = $end;
		}
	}

	@tokens;
}

# ------------------------------------------------------------- region choice

#| Index of the token that closes the subtree opened at $start, of a boundary
#| tag that cut it short, or the token count if it was never closed.
#| :stop-unless names everything the subtree may contain; the first start tag
#| that is not one of them ends it, which is how an unclosed <head> gives way
#| to the page rather than swallowing it.
my sub matching-end(@tokens, Int:D $start, Str:D $name, :%stop-at, :%stop-unless --> Int) {
	my int $depth = 1;
	my int $index = $start + 1;
	my int $elems = @tokens.elems;

	while $index < $elems {
		my $token = @tokens[$index];
		if $token.kind eq 'start' {
			return $index if %stop-at{$token.name};
			return $index if %stop-unless.elems && !%stop-unless{$token.name};
			$depth++ if $token.name eq $name
				&& !$token.self-closing && !VOID-ELEMENTS{$token.name};
		}
		elsif $token.kind eq 'end' && $token.name eq $name {
			$depth--;
			return $index if $depth == 0;
		}
		$index++;
	}

	$elems;
}

my sub first-start(@tokens, Str:D $name --> Int) {
	my int $index = 0;
	while $index < @tokens.elems {
		my $token = @tokens[$index];
		return $index if $token.kind eq 'start' && $token.name eq $name
			&& !$token.self-closing;
		$index++;
	}
	Int;
}

#| Remove named subtrees.  :stop-at names elements whose opening tag ends the
#| removal even without a closing tag — that is what stops a document with no
#| </head> from losing its entire body.
my sub drop-subtrees(@tokens, %names, :%stop-at, :%stop-unless --> Array) {
	my @out;
	my int $index = 0;
	my int $elems = @tokens.elems;

	while $index < $elems {
		my $token = @tokens[$index];
		if $token.kind eq 'start' && %names{$token.name}
		&& !$token.self-closing && !VOID-ELEMENTS{$token.name} {
			my $end = matching-end(@tokens, $index, $token.name, :%stop-at, :%stop-unless);
			$index = $end < $elems && @tokens[$end].kind eq 'end' ?? $end + 1 !! $end;
		}
		else {
			@out.push($token);
			$index++;
		}
	}

	@out;
}

#| Does this token range hold anything a reader would see?  Used to pass over
#| an empty <main> rather than rendering a blank page out of it.
my sub has-content(@tokens --> Bool:D) {
	so @tokens.first: {
		.kind eq 'text' && decode-entities(.text).trim ne ''
			|| .kind eq 'start' && (.name eq 'img' || .name eq 'br');
	};
}

#| Pick the part of the document worth rendering: main, then articles, then
#| body-minus-furniture, then everything.
my sub choose-region(@tokens --> Array) {
	with first-start(@tokens, 'main') -> $start {
		my @main = @tokens[$start + 1 ..^ matching-end(@tokens, $start, 'main')];
		return @main if has-content(@main);
	}

	my @articles;
	my int $index = 0;
	while $index < @tokens.elems {
		my $token = @tokens[$index];
		if $token.kind eq 'start' && $token.name eq 'article' && !$token.self-closing {
			my $end = matching-end(@tokens, $index, 'article');
			@articles.append(@tokens[$index + 1 ..^ $end]);
			# A synthetic close keeps two adjacent articles from running their
			# text together; 'article' is a paragraph element to the renderer.
			@articles.push: Token.new(kind => 'end', name => 'article');
			$index = $end + 1;
		}
		else {
			$index++;
		}
	}
	return @articles if has-content(@articles);

	with first-start(@tokens, 'body') -> $start {
		my @body    = @tokens[$start + 1 ..^ matching-end(@tokens, $start, 'body')];
		my @trimmed = drop-subtrees(@body, FURNITURE-ELEMENTS);
		# A page whose entire content lives inside a <header> is badly built but
		# still readable; better its furniture than nothing at all.
		return has-content(@trimmed) ?? @trimmed !! @body;
	}

	my @all = @tokens;
	@all;
}

# ----------------------------------------------------------------- link URLs

#| Is this a character Cro::Uri (correctly) refuses in a reference?  '%' is not
#| among them: leaving it alone is what stops an already-encoded reference from
#| being encoded a second time.
my sub unsafe-in-url(Str:D $ch --> Bool:D) {
	my $ord = $ch.ord;
	$ord < 0x21 || $ord > 0x7E
		|| $ch eq '"' || $ch eq '<' || $ch eq '>' || $ch eq '\\'
		|| $ch eq '^' || $ch eq '`' || $ch eq '{' || $ch eq '|' || $ch eq '}';
}

#| Percent-encode those characters, exactly as a browser does before resolving.
#| Real pages link to 'my file.html' and to paths with raw non-ASCII in them,
#| and refusing those costs a crawler pages for no benefit.
my sub escape-unsafe(Str:D $ref --> Str:D) {
	return $ref unless $ref.comb.first(&unsafe-in-url);
	$ref.comb.map({
		unsafe-in-url($_)
			?? .encode('utf-8').list.map({ sprintf('%%%02X', $_) }).join
			!! $_
	}).join;
}

#| One canonical spelling for a URL: lowercase scheme and host, an explicit
#| root path, no fragment.  Two links that differ only in the case of their
#| host are one link to a crawler, and this is where that becomes true.
my sub canonical-str(Cro::Uri:D $uri --> Str:D) {
	my $host = ($uri.host // '').lc;
	# Cro hands back an IPv6 literal without its brackets; putting them back is
	# what keeps the result re-parseable.
	my $authority = $host.contains(':') ?? '[' ~ $host ~ ']' !! $host;
	my $userinfo  = $uri.userinfo;
	my $port      = $uri.port;
	my $path      = $uri.path // '';
	my $query     = $uri.query;

	($uri.scheme // '').lc
		~ '://'
		~ ($userinfo.defined && $userinfo ne '' ?? $userinfo ~ '@' !! '')
		~ $authority
		~ ($port.defined ?? ':' ~ $port !! '')
		~ ($path eq '' ?? '/' !! $path)
		~ ($query.defined && $query ne '' ?? '?' ~ $query !! '');
}

#| Tidy an href into something resolvable: no surrounding whitespace, no
#| embedded line breaks (browsers drop those, and a formatter that wrapped a
#| long href would otherwise break the link), no fragment.
my sub clean-ref(Str:D $href --> Str:D) {
	my $ref = $href.trim;
	$ref = $ref.subst("\n", '', :g) if $ref.contains("\n");
	$ref = $ref.subst("\t", '', :g) if $ref.contains("\t");
	with $ref.index('#') -> $hash {
		$ref = $ref.substr(0, $hash);
	}
	escape-unsafe($ref);
}

my sub parse-base(Str $base --> Cro::Uri) {
	return Cro::Uri if !$base.defined || $base eq '';
	my $parsed = try Cro::Uri.parse($base);
	$parsed.defined ?? $parsed !! Cro::Uri;
}

#| Resolve one href against an already-parsed base, RFC 3986 §5 style —
#| Cro::Uri.add does the merging, because hand-rolling that is how relative
#| paths quietly go wrong.  Returns an undefined Str for anything unusable: an
#| unresolvable relative reference, a scheme we do not fetch, or a reference
#| Cro cannot parse even after escaping.
my sub resolve-ref(Str:D $href, Cro::Uri $base-uri --> Str) {
	my $ref = clean-ref($href);

	my $uri;
	if $base-uri.defined {
		$uri = try $base-uri.add($ref);
	}
	elsif $ref eq '' {
		return Str;
	}
	else {
		$uri = try Cro::Uri.parse($ref);
	}
	return Str without $uri;

	my $scheme = ($uri.scheme // '').lc;
	return Str unless $scheme eq 'http' || $scheme eq 'https';
	return Str if ($uri.host // '') eq '';

	canonical-str($uri);
}

my sub resolve-url(Str:D $href, Str $base --> Str) {
	resolve-ref($href, parse-base($base));
}

#| One document's worth of link resolution.  Parsing a URL is by a wide margin
#| the most expensive thing in this module, and a page repeats its navigation
#| in every one of its sections, so the base is parsed once and each distinct
#| href is resolved once.
my class UrlResolver {
	has Str $.base;          # canonical base URL, or undefined
	has     $!base-uri;
	has     %!cache;

	submethod TWEAK() {
		$!base-uri = parse-base($!base);
	}

	method resolve(Str:D $href --> Str) {
		return %!cache{$href} if %!cache{$href}:exists;
		%!cache{$href} = resolve-ref($href, $!base-uri);
	}
}

#| The document's own idea of where it is: <base href> if it declares one
#| (resolved against the fetch URL, since a relative <base> is legal), else the
#| fetch URL in canonical form.
my sub effective-base(@tokens, Str $base --> Str) {
	my $declared = @tokens.first({
		.kind eq 'start' && .name eq 'base' && (.attrs<href> // '') ne ''
	});

	with $declared {
		# Only the first <base href> is consulted, as in a browser; one that
		# cannot be resolved at all leaves the fetch URL in charge rather than
		# leaving the document with no base and every relative link dead.
		my $resolved = resolve-url(decode-entities($declared.attrs<href>), $base);
		return $resolved with $resolved;
	}

	my $parsed = parse-base($base);
	return Str without $parsed;
	canonical-str($parsed);
}

# ------------------------------------------------------------------ renderer

#| The rendering state machine.  Lines are built one at a time and remembered
#| with a flag saying whether they came out of a <pre>, because the final
#| whitespace pass must not touch those.
my class Renderer {
	has UrlResolver $.resolver is required;
	has Str  @!lines;
	has Bool @!verbatim-lines;
	has Str  $!cur;                 # the open line, undefined when none is open
	has Bool $!cur-verbatim = False;
	has Int  $!want-blanks = 0;     # blank lines owed before the next line
	has Bool $!pending-space = False;
	has Int  $!line-serial = 0;     # bumped whenever a line is finished
	has Int  $!pre-depth = 0;
	has Bool $!pre-fresh = False;
	has Int  $!list-depth = 0;
	has      @!anchors;

	method !push-line(Str:D $text, Bool:D $verbatim --> Nil) {
		@!lines.push($text);
		@!verbatim-lines.push($verbatim);
	}

	method open-line(--> Nil) {
		return if $!cur.defined;
		if @!lines.elems {
			self!push-line('', False) for ^$!want-blanks;
		}
		$!want-blanks = 0;
		$!cur = '';
		$!cur-verbatim = $!pre-depth > 0;
	}

	method close-line(Int:D $blanks --> Nil) {
		if $!cur.defined {
			self!push-line($!cur, $!cur-verbatim);
			$!cur = Str;
			$!line-serial++;
		}
		$!pending-space = False;
		$!want-blanks = max($!want-blanks, $blanks);
	}

	method emit(Str:D $text, Bool:D :$space = False --> Nil) {
		return if $text eq '';
		self.open-line;
		$!cur ~= ' ' if ($space || $!pending-space) && $!cur.chars;
		$!pending-space = False;
		$!cur ~= $text;
		$!pre-fresh = False;
	}

	#| Text inside a <pre>: its line breaks and its indentation are content.
	method verbatim(Str:D $text --> Nil) {
		my $body = $text;
		# HTML says a newline straight after <pre> is not part of the content,
		# and every hand-written code block relies on it.
		if $!pre-fresh {
			$body = $body.substr(1) if $body.starts-with("\n");
			$!pre-fresh = False;
		}
		return if $body eq '';

		for $body.split("\n").kv -> $index, $part {
			self.close-line(0) if $index > 0;
			self.open-line;
			$!cur ~= $part if $part ne '';
		}
	}

	method text(Str:D $raw --> Nil) {
		my $decoded = decode-entities($raw);
		return if $decoded eq '';

		if $!pre-depth > 0 {
			self.verbatim($decoded);
			return;
		}

		my $collapsed = $decoded.words.join(' ');
		if $collapsed eq '' {
			# Whitespace between two inline elements is a separator, never a
			# line of its own.
			$!pending-space = True if $!cur.defined && $!cur.chars;
			return;
		}

		self.emit($collapsed, space => is-space($decoded.substr(0, 1)));
		$!pending-space = is-space($decoded.substr(*- 1));
	}

	method !anchor-url(%attrs --> Str) {
		# Inside a <pre> a link marker would corrupt a code sample, so the
		# anchor keeps its text and loses its URL.
		return Str if $!pre-depth > 0;
		my $href = %attrs<href>;
		return Str without $href;
		my $url = $!resolver.resolve(decode-entities($href));
		return Str without $url;
		# A link to the page being read is not worth the tokens it costs.
		return Str if $!resolver.base.defined && $url eq $!resolver.base;
		$url;
	}

	method start-anchor(%attrs --> Nil) {
		@!anchors.push: {
			url    => self!anchor-url(%attrs),
			serial => $!line-serial,
			col    => ($!cur // '').chars,
		};
	}

	method end-anchor(--> Nil) {
		# A </a> with no <a> is ordinary tag soup, not something to fail on.
		return unless @!anchors.elems;
		my $anchor = @!anchors.pop;
		return without $anchor<url>;
		# The label has to have stayed on one line: an anchor wrapped around
		# whole blocks is a layout device, not a link in a sentence.
		return unless $!cur.defined && $!line-serial == $anchor<serial>;
		my $col = $anchor<col>;
		return if $col > $!cur.chars;

		my $captured = $!cur.substr($col);
		my $lead     = $captured.starts-with(' ') ?? ' ' !! '';
		my $label    = $captured.trim;
		$!cur = $!cur.substr(0, $col)
			~ ($label eq '' ?? '' !! $lead ~ '[' ~ $label ~ '](' ~ $anchor<url> ~ ')');
	}

	method image(%attrs --> Nil) {
		my $alt = decode-entities(%attrs<alt> // '').words.join(' ');
		return if $alt eq '';
		self.emit('[image: ' ~ $alt ~ ']');
	}

	method start-tag(Token:D $token --> Nil) {
		my $name = $token.name;

		if $name eq 'br' {
			self.close-line(0);
		}
		elsif $name eq 'img' {
			self.image($token.attrs);
		}
		elsif $name eq 'a' {
			self.start-anchor($token.attrs);
		}
		elsif $name eq 'pre' {
			self.close-line(1);
			$!pre-depth++;
			$!pre-fresh = True;
		}
		elsif $name eq 'ul' || $name eq 'ol' {
			# A blank line sets a list off from the prose around it, but a
			# nested list belongs to the item above it and must stay attached.
			self.close-line($!list-depth == 0 ?? 1 !! 0);
			$!list-depth++;
		}
		elsif $name eq 'li' {
			self.close-line(0);
			self.open-line;
			$!cur ~= '  ' x max($!list-depth - 1, 0);
			$!cur ~= '- ';
			$!pending-space = False;
		}
		elsif $name eq 'td' || $name eq 'th' {
			# Cells share one line; the row element supplies the break.
			if $!cur.defined && $!cur.chars {
				$!cur ~= ' | ';
				$!pending-space = False;
			}
			else {
				self.open-line;
			}
		}
		elsif HEADING-ELEMENTS{$name} {
			self.close-line(1);
			self.open-line;
			$!cur ~= '#' x $name.substr(1).Int;
			$!cur ~= ' ';
			$!pending-space = False;
		}
		elsif PARAGRAPH-ELEMENTS{$name} {
			self.close-line(1);
		}
		elsif LINE-ELEMENTS{$name} {
			self.close-line(0);
		}
	}

	method end-tag(Str:D $name --> Nil) {
		if $name eq 'a' {
			self.end-anchor;
		}
		elsif $name eq 'pre' {
			$!pre-depth = max($!pre-depth - 1, 0);
			$!pre-fresh = False;
			self.close-line(1);
			self!trim-trailing-verbatim;
		}
		elsif $name eq 'ul' || $name eq 'ol' {
			$!list-depth = max($!list-depth - 1, 0);
			self.close-line($!list-depth == 0 ?? 1 !! 0);
		}
		elsif $name eq 'li' {
			self.close-line(0);
		}
		elsif HEADING-ELEMENTS{$name} {
			self.close-line(1);
		}
		elsif PARAGRAPH-ELEMENTS{$name} {
			self.close-line(1);
		}
		elsif LINE-ELEMENTS{$name} {
			self.close-line(0);
		}
	}

	#| A <pre> almost always ends with a newline and some indentation before its
	#| closing tag; those became blank lines that are not part of the sample.
	method !trim-trailing-verbatim(--> Nil) {
		while @!lines.elems && @!verbatim-lines[*- 1] && @!lines[*- 1].trim eq '' {
			@!lines.pop;
			@!verbatim-lines.pop;
		}
	}

	method result(--> Str:D) {
		self.close-line(0);

		my @out;
		my int $blank-run = 0;
		for @!lines.kv -> $index, $line {
			my $verbatim = @!verbatim-lines[$index];
			# Only trailing whitespace is cut, even outside a <pre>: text was
			# collapsed on the way in, so any space at the start of a line was
			# put there on purpose — it is a nested list item's indent.
			my $text = $line.trim-trailing;

			if $text.trim eq '' && !$verbatim {
				$blank-run++;
				# One blank line is a paragraph break; more is only padding, and
				# padding that varied would move every line number below it.
				next if $blank-run > 1 || !@out.elems;
			}
			else {
				$blank-run = 0;
			}
			@out.push($text);
		}

		@out.pop while @out.elems && @out[*- 1].trim eq '';
		@out.join("\n");
	}
}

my sub render(@tokens, UrlResolver:D $resolver --> Str:D) {
	my $renderer = Renderer.new(:$resolver);
	for @tokens -> $token {
		if $token.kind eq 'text' {
			$renderer.text($token.text);
		}
		elsif $token.kind eq 'start' {
			$renderer.start-tag($token);
			# XHTML writes <p/> and <div/>; the renderer has to see both edges
			# or everything after inherits the open element's state.
			$renderer.end-tag($token.name) if $token.self-closing;
		}
		else {
			$renderer.end-tag($token.name);
		}
	}
	$renderer.result;
}

# ------------------------------------------------------------ public surface

#| Every text token in a range, decoded and collapsed onto one line.  Joined
#| with nothing rather than with a space: the source's own whitespace is what
#| separates words, so '<h1>Head<em>line</em></h1>' stays one word.
my sub collect-text(@tokens --> Str:D) {
	@tokens.grep({ .kind eq 'text' }).map({ decode-entities(.text) })
		.join.words.join(' ');
}

#| The page's title: <title> if it has one, else the first <h1>, else the empty
#| string.  Entities are decoded and whitespace collapsed, so the result is
#| always a single line fit to head a fetch result.
our sub extract-title(Str:D $html --> Str:D) is export {
	my @tokens = tokenize(normalize-newlines($html));

	my int $index = 0;
	while $index < @tokens.elems {
		my $token = @tokens[$index];
		if $token.kind eq 'start' && $token.name eq 'title' && !$token.self-closing {
			my $end  = matching-end(@tokens, $index, 'title');
			my $text = collect-text(@tokens[$index + 1 ..^ $end]);
			return $text if $text ne '';
			$index = $end + 1;
			next;
		}
		$index++;
	}

	# No <title>, or an empty one.  The first <h1> is what a reader would call
	# the page anyway, and a fetch result with no heading at all is confusing.
	with first-start(@tokens, 'h1') -> $start {
		my $text = collect-text(@tokens[$start + 1 ..^ matching-end(@tokens, $start, 'h1')]);
		return $text if $text ne '';
	}

	'';
}

#| Render a page as text.  :base is the URL the HTML came from — the fetch's
#| final URL after redirects — and is what relative links resolve against
#| unless the document declares its own <base href>.
our sub html-to-text(Str:D $html, Str :$base --> Str:D) is export {
	my @tokens = tokenize(normalize-newlines($html));
	my $doc-base = effective-base(@tokens, $base);

	# <head> is dropped here rather than in the tokenizer so that its
	# <base href> was available above, and so that a document missing its
	# </head> loses the head only as far as the first element that cannot be
	# in one — losing a whole page to a missing closing tag is not a trade
	# worth making for tidier markup handling.
	@tokens = drop-subtrees(@tokens, ('head',).Set, stop-unless => HEAD-ELEMENTS);

	render(choose-region(@tokens), UrlResolver.new(base => $doc-base));
}

#| Every link in the raw document, in the order the page lists them, each
#| reported once.  :base is required — a link a crawler cannot resolve is not a
#| link — and is overridden by the document's own <base href>.
#|
#| The Hashes have two keys: 'url' (absolute, fragment-stripped, http or https
#| only) and 'nofollow' (True only when every occurrence of that URL carried
#| rel="nofollow").
our sub extract-links(Str:D $html, Str:D :$base! --> List:D) is export {
	my @tokens   = tokenize(normalize-newlines($html));
	my $resolver = UrlResolver.new(base => effective-base(@tokens, $base));

	my @order;        # URLs in first-seen order
	my %nofollow;     # URL => still unanimously nofollow?

	for @tokens -> $token {
		next unless $token.kind eq 'start';
		next unless $token.name eq 'a' || $token.name eq 'area';

		my $href = $token.attrs<href>;
		next without $href;
		my $url = $resolver.resolve(decode-entities($href));
		next without $url;

		my $marked = so decode-entities($token.attrs<rel> // '').lc.words.first('nofollow');

		if %nofollow{$url}:exists {
			# One followable occurrence is enough: a page that links to the same
			# target twice, once without the marking, means it to be followed.
			%nofollow{$url} = %nofollow{$url} && $marked;
		}
		else {
			@order.push($url);
			%nofollow{$url} = $marked;
		}
	}

	@order.map({ %( url => $_, nofollow => %nofollow{$_} ) }).List;
}

#| Normalise a Content-Type header down to its type/subtype, lowercased.
my sub normalize-type(Str $content-type --> Str:D) {
	return '' without $content-type;
	my $type = $content-type;
	with $type.index(';') -> $semi {
		$type = $type.substr(0, $semi);
	}
	$type.trim.lc;
}

my sub is-binary-type(Str:D $type --> Bool:D) {
	return True if BINARY-TYPES{$type};
	so BINARY-PREFIXES.first({ $type.starts-with($_) });
}

#| Does this body look like bytes rather than text?  Only consulted for content
#| types nobody recognises, where the label is worth less than the content.
my sub looks-binary(Str:D $text --> Bool:D) {
	my $head = $text.substr(0, 1000);
	return False if $head eq '';
	return True if $head.contains("\0");
	my $control = $head.comb.grep({
		.ord < 0x20 && $_ ne "\n" && $_ ne "\t" && $_ ne "\r"
	}).elems;
	$control * 10 > $head.chars;
}

my sub looks-html(Str:D $head --> Bool:D) {
	my $lower = $head.lc;
	so HTML-MARKERS.first({ $lower.contains($_) });
}

#| Parse JSON without letting a parse failure become an exception: returns a
#| one-element Array holding the data, or Nil.  The box matters — 'null' parses
#| to an undefined value, which is a success, not a failure.
my sub parse-json(Str:D $text) {
	my $data;
	my $parsed = True;
	{
		CATCH { default { $parsed = False } }
		$data = from-json($text);
	}
	$parsed ?? [$data.item] !! Nil;
}

my sub pretty-json(Str:D $text, Str:D $claim --> Str:D) {
	with parse-json($text) -> $box {
		return to-json($box[0], :pretty, :sorted-keys);
	}
	# Appended rather than prepended: the diagnosis must not move the content's
	# line numbers, which is what a grep of this text will be quoting.
	$text ~ "\n\n[" ~ $claim ~ ', but the body is not valid JSON; shown verbatim]';
}

#| No content type at all — read the first bytes and decide.
my sub sniff(Str:D $text, Str $url --> Str:D) {
	my $head = $text.substr(0, 1024).trim-leading;
	return $text if $head eq '';

	if $head.starts-with('<') {
		# An XML document that is not XHTML is more useful verbatim: its tags
		# are the data, and extraction would throw exactly those away.
		return looks-html($head) ?? html-to-text($text, :base($url)) !! $text;
	}
	if $head.starts-with('{') || $head.starts-with('[') {
		with parse-json($text) -> $box {
			return to-json($box[0], :pretty, :sorted-keys);
		}
	}
	$text;
}

my sub refuse-binary(Str:D $type, Str:D $text, Int $byte-count, Str $url) {
	my $bytes = $byte-count // $text.encode('utf-8').bytes;
	die "Cannot read $type as text: it is a binary format, and its $bytes bytes "
		~ 'would arrive as noise rather than as something to read'
		~ ($url.defined && $url ne '' ?? " (the URL was $url)" !! '')
		~ '. Fetch a URL that serves HTML, plain text or JSON instead.';
}

#| Turn a fetched body into the text a model should read, choosing how by
#| content type.  Dies — with a message naming the type and the size — for
#| formats whose bytes are not text.
#|
#| :byte-count is the size of the body as it came off the wire; it defaults to
#| the encoded length of $text, which differs only when the caller decoded
#| nothing, as a fetcher does for a binary response.
our sub text-for(
	Str:D $text,
	Str :$content-type,
	Str :$url,
	Int :$byte-count
	--> Str:D
) is export {
	my $type = normalize-type($content-type);

	refuse-binary($type, $text, $byte-count, $url)
		if $type ne '' && is-binary-type($type);

	return html-to-text($text, :base($url))
		if $type eq 'text/html' || $type eq 'application/xhtml+xml'
		|| $type eq 'application/html';

	return pretty-json($text, "the server said $type")
		if $type eq 'application/json' || $type eq 'text/json'
		|| $type.ends-with('+json');

	# XML keeps its tags: they are the payload, and whoever fetched a feed or a
	# sitemap wanted the feed, not a paraphrase of it.
	return $text
		if $type eq 'application/xml' || $type eq 'text/xml' || $type.ends-with('+xml');

	return $text if $type.starts-with('text/');
	return $text if TEXT-APPLICATION-TYPES{$type};

	return sniff($text, $url) if $type eq '';

	# An unrecognised type: trust the bytes rather than the label.
	refuse-binary($type, $text, $byte-count, $url) if looks-binary($text);
	sniff($text, $url);
}
