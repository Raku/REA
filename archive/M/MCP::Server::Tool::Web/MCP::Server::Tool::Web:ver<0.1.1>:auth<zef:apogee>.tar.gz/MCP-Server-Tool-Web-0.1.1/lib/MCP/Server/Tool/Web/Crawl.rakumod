=begin pod

=head1 NAME

MCP::Server::Tool::Web::Crawl - one breadth-first walk of a site, with a
callback per page

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Crawl;
use MCP::Server::Tool::Web::Fetcher;
use MCP::Server::Tool::Web::Guard;

my $fetcher = MCP::Server::Tool::Web::Fetcher.new(
    guard => MCP::Server::Tool::Web::Guard.new,
);

my $crawl = MCP::Server::Tool::Web::Crawl.new(
    fetcher   => $fetcher,
    max-depth => 1,       # 0 = the starting page and nothing else
    max-pages => 20,      # counting the starting page
    delay     => 0.25,    # seconds between requests, single-threaded
);

my @index;
my $report = $crawl.run('https://docs.example.com/', on-page => -> $page {
    @index.push("{$page.final-url} {$page.status} {$page.byte-count} bytes");
    True;             # False would stop the crawl here
});

say $report.fetched;          # 7
say $report.origin;           # https://docs.example.com
say $report.stopped;          # max-pages | deadline | max-bytes | callback | Str
say $report.failures;         # [{url => …, reason => …}, …]
say $report.robots-skipped;   # [https://docs.example.com/private/, …]

=end code

Stopping early is the callback's job — this is how C<web_grep> spends a global
result budget without the cap logic being written twice:

=begin code :lang<raku>

my Int $matched = 0;
my $report = $crawl.run($seed, on-page => -> $page {
    $matched += count-matches($page);
    $matched < 50;        # once 50 lines have matched, nothing more is fetched
});
say $report.stopped;      # callback — and the pages after it were never requested

=end code

=head1 DESCRIPTION

One traversal, two consumers: C<web_crawl> builds an index out of the callback
and C<web_grep> greps each page as it arrives and stops the walk when it has
found enough. Writing the cap, dedup and same-origin logic twice is how the two
tools would drift apart, so they share this class and differ only in what their
callback does.

=head2 What the walk does

=item B<Breadth first.> Every page at depth I<n> is fetched before any page at
      depth I<n+1>, and within a level the order is the order the pages
      themselves list their links in — the site's own idea of what matters
      most, and deterministic for a fixed site.
=item B<Same origin only.> Origin means scheme, host and B<effective> port, and
      it is taken from the seed's B<final> URL: a seed that redirects to
      C<www.example.com> crawls C<www.example.com>, which is what the redirect
      was for. Links elsewhere are not followed and are not failures.
=item B<Every page once.> Both the URL a page was requested by and the URL it
      finally came from are remembered, so a page reachable by two paths — or
      by a redirect from one of them — is fetched once.
=item B<Links come from the raw HTML>, resolved against the document's own
      C<E<lt>base hrefE<gt>> or the final URL, http(s) only, fragments dropped,
      and C<rel="nofollow"> honoured. Only successful HTML responses are read
      for links: the link list of a 404 page is the site's error template.
=item B<max-pages counts fetched pages, including the seed.>
=item B<One budget for the whole walk.> Time and bytes are shared, so a crawl
      cannot cost twenty times a single fetch. Running out of either stops the
      walk with a C<stopped> reason rather than an exception.

=head2 Failures are results, except the first one

A page that cannot be fetched — refused address, dead connection, redirect
loop — is recorded in C<failures> and the walk carries on: one broken link in a
documentation site is not a reason to report nothing. The B<seed> is the
exception: if the page the caller actually named cannot be fetched, the
exception travels, because "0 pages, 1 failure" is a worse answer than the
refusal that explains why.

Pages refused by robots.txt are counted separately in C<robots-skipped>: they
are a policy decision rather than a fault, and the tool layer says so with a
notice naming the setting that would change it.

=head2 Politeness

The walk is single-threaded and sleeps C<delay> seconds between requests. When
the fetcher's robots.txt policy asks for a longer C<Crawl-delay> for a URL,
that one is used instead — robots.txt may slow the crawl down, never speed it
up. Tests set C<delay =E<gt> 0>.

=end pod

use MCP::Server::Tool::Web::Budget;
use MCP::Server::Tool::Web::Extract;
use MCP::Server::Tool::Web::Fetcher;
use MCP::Server::Tool::Web::Url;
use MCP::Server::Tool::Web::X;

# === Helpers ===
#
# Declared before the classes that call them: a `my sub` is only visible after
# its declaration point.

#| One spelling per page, for the visited set. Anything that will not parse is
#| kept as it came: it is only ever compared with itself.
my sub canonical(Str:D $url --> Str:D) {
	my $parsed = try MCP::Server::Tool::Web::Url.parse($url);
	$parsed.defined ?? $parsed.Str !! $url;
}

#| Enough of a document's opening for it to be HTML, for the case where nobody
#| said what it was.
my constant HTML-MARKERS = ('<!doctype html', '<html', '<head', '<body', '<title');

#| Is this response HTML — either because it says so, or because it said
#| nothing and reads like it? Links and titles come out of HTML and nothing
#| else; a JSON document full of URL-shaped strings is not a page to crawl.
my sub html-ish($result --> Bool:D) {
	my $type = $result.content-type;
	with $type {
		return so $_ eq 'text/html' | 'application/xhtml+xml' | 'application/html';
	}
	my $head = $result.text.substr(0, 1024).trim-leading.lc;
	return False unless $head.starts-with('<');
	so HTML-MARKERS.first({ $head.contains($_) });
}

#| One fetched page, as handed to the C<on-page> callback.
class MCP::Server::Tool::Web::Crawl::Page {
	#| The URL this page was queued under, already normalised.
	has Str:D $.url is required;

	#| How many links from the seed this page was: 0 for the seed itself.
	has Int:D $.depth is required;

	#| Everything the fetch produced, including the raw decoded body.
	has MCP::Server::Tool::Web::FetchResult:D $.result is required;

	#| Where the body actually came from — what a link on this page resolves
	#| against, and what the tool layer quotes.
	method final-url(--> Str:D) { $!result.final-url }

	method status(--> Int:D) { $!result.status }

	method byte-count(--> Int:D) { $!result.byte-count }

	#| The media type without parameters, or the C<Str> type object when the
	#| server sent none.
	method content-type(--> Str) { $!result.content-type }

	#| The page's title, or the empty string for a page that has none (and for
	#| everything that is not HTML).
	method title(--> Str:D) {
		return '' unless html-ish($!result);
		extract-title($!result.text);
	}

	method gist(--> Str:D) {
		"Page({$!result.status} {self.final-url}, depth $!depth)";
	}
}

#| What a whole walk did. The pages themselves went to the callback as they
#| arrived; this is everything the tool layer needs to write its notices.
class MCP::Server::Tool::Web::Crawl::Report {
	#| How many pages were fetched, including the seed.
	has Int:D $.fetched = 0;

	#| The origin every fetched page shares, taken from the seed's final URL.
	has Str:D $.origin = '';

	#| The seed's final URL — where the crawl actually started, after any
	#| redirect the seed itself made.
	has Str:D $.seed = '';

	#| The deepest level actually reached.
	has Int:D $.depth-reached = 0;

	#| Pages that could not be fetched: C<%( url, reason )>, in the order they
	#| were tried.
	has @.failures;

	#| URLs robots.txt refused, in the order they were tried.
	has Str @.robots-skipped;

	#| Why the walk ended early, or the C<Str> type object when it simply ran
	#| out of links: 'max-pages', 'deadline', 'max-bytes' or 'callback'.
	has Str $.stopped;

	#| Were there links left unvisited when the walk stopped?
	method truncated(--> Bool:D) { $!stopped.defined }
}

#| A breadth-first walk, bounded by depth, page count and one shared budget.
#| Build one per tool call: it holds no state between runs, but its caps are
#| the call's.
class MCP::Server::Tool::Web::Crawl {
	#| The fetcher every page goes through — and, through its C<robots>
	#| policy, what decides which pages may be fetched at all.
	has MCP::Server::Tool::Web::Fetcher:D $.fetcher is required;

	#| How many links from the seed the walk may follow. 0 fetches the seed
	#| and nothing else, which is how depth-zero C<web_grep> shares this code.
	has Int:D $.max-depth = 1;

	#| How many pages may be fetched in total, the seed included.
	has Int:D $.max-pages = 20;

	#| Seconds between requests. Raised, never lowered, by a robots.txt
	#| C<Crawl-delay>.
	has Real:D $.delay = 0.25;

	#| The time and byte allowance for the whole walk. One is made from the
	#| fetcher's own caps when none is supplied.
	has MCP::Server::Tool::Web::Budget $.budget;

	submethod TWEAK {
		die "max-depth cannot be negative; got $!max-depth" if $!max-depth < 0;
		die "max-pages must be at least 1; got $!max-pages" if $!max-pages < 1;
		die "delay cannot be negative; got $!delay" if $!delay < 0;
	}

	#|( Walk from C<$seed>. C<&on-page> is called with a
	    L<MCP::Server::Tool::Web::Crawl::Page> for every page fetched, in the
	    order they were fetched, and returning a false value from it stops the
	    walk. Throws whatever fetching the B<seed> throws; every later failure
	    is recorded in the report instead. )
	method run(Str:D $seed, :&on-page --> MCP::Server::Tool::Web::Crawl::Report:D) {
		my $budget = $!budget // $!fetcher.new-budget;
		my $agent  = $!fetcher.user-agent;

		# Pushed rather than assigned: a Hash on the right of a list assignment
		# flattens into its pairs, and a queue of pairs is not a queue of jobs.
		my @queue;
		@queue.push(%( url => $seed, depth => 0 ));
		my %seen = $seed => True;

		my Int $fetched = 0;
		my Int $deepest = 0;
		my Str $stopped;
		my Str $origin = '';
		my Str $seed-final = '';
		my MCP::Server::Tool::Web::Url $origin-url;
		my @failures;
		my Str @robots-skipped;

		while @queue {
			if $fetched >= $!max-pages {
				$stopped = 'max-pages';
				last;
			}
			if $budget.expired {
				$stopped = 'deadline';
				last;
			}
			# A page fetched with no allowance left would come back empty and
			# be reported as an empty page, which is a lie about the site.
			if $fetched > 0 && $budget.remaining-bytes <= 0 {
				$stopped = 'max-bytes';
				last;
			}

			my %job = @queue.shift;
			my Str:D $url = %job<url>;
			my Int:D $depth = %job<depth>;
			my Bool $first = $fetched == 0;

			# Asked before the delay rather than discovered inside the fetch: a
			# page we are not going to request costs neither a wait nor a
			# connection. The fetcher checks again for itself, which is what
			# covers a redirect onto a disallowed path.
			#
			# The seed is exempt: if the page the caller named is forbidden,
			# that refusal is the answer, and it comes from the fetcher with
			# the rule that produced it.
			if !$first && self!robots-refuses($url, $agent) {
				@robots-skipped.push($url);
				next;
			}

			self!wait-before($url, $agent) if $fetched > 0;

			my $result;
			{
				CATCH {
					when X::MCP::Server::Tool::Web::RobotsRefused {
						# Not a fault: a decision the site made and we honoured.
						# The seed being refused is still the caller's answer,
						# though — a grep that reported "0 pages" for a page
						# robots.txt forbids would be inexplicable.
						.rethrow if $first;
						@robots-skipped.push($url);
					}
					default {
						.rethrow if $first;
						@failures.push(%( :$url, reason => .message.lines.head ));
					}
				}
				$result = $!fetcher.fetch($url, :$budget);
			}
			next without $result;

			$fetched++;
			$deepest = $depth if $depth > $deepest;
			%seen{canonical($result.requested-url)} = True;
			%seen{canonical($result.final-url)} = True;

			if $first {
				# The origin is the seed's FINAL url: a seed that redirects to
				# the site's canonical host is asking for that host to be
				# crawled, not for a walk that stops after one page.
				$origin-url = try MCP::Server::Tool::Web::Url.parse($result.final-url);
				$origin     = $origin-url.defined ?? $origin-url.origin !! '';
				$seed-final = $result.final-url;
			}

			with &on-page {
				unless on-page(MCP::Server::Tool::Web::Crawl::Page.new(
						:$url, :$depth, :$result)) {
					$stopped = 'callback';
					last;
				}
			}

			next unless $depth < $!max-depth;
			for self!links($result, $origin-url) -> $link {
				next if %seen{$link};
				%seen{$link} = True;
				@queue.push(%( url => $link, depth => $depth + 1 ));
			}
		}

		MCP::Server::Tool::Web::Crawl::Report.new(
			:$fetched, :$origin, seed => $seed-final, depth-reached => $deepest,
			:@failures, :@robots-skipped, :$stopped,
		);
	}

	#| Does the fetcher's robots policy forbid this URL? False for anything it
	#| cannot judge — a URL that will not parse is the fetcher's to refuse, and
	#| a policy that throws is an unavailable robots.txt, which means allowed.
	method !robots-refuses(Str:D $url, Str:D $agent --> Bool:D) {
		my $parsed = try MCP::Server::Tool::Web::Url.parse($url);
		return False without $parsed;
		my $allowed = try $!fetcher.robots.allow($parsed, :$agent);
		$allowed.defined && !$allowed;
	}

	#| Sleep for as long as politeness asks: this crawl's own delay, or a
	#| longer one the origin's robots.txt asked for.
	method !wait-before(Str:D $url, Str:D $agent --> Nil) {
		my $wait = $!delay;
		my $parsed = try MCP::Server::Tool::Web::Url.parse($url);
		with $parsed {
			# robots.txt may only slow us down — max(), not the crawl-delay
			# alone, or a site could ask to be hammered.
			my $asked = (try $!fetcher.robots.crawl-delay($_, :$agent)) // 0;
			$wait = max($wait, $asked);
		}
		sleep $wait if $wait > 0;
	}

	#| The same-origin links of one page, in the order the page lists them.
	method !links($result, MCP::Server::Tool::Web::Url $origin-url --> List:D) {
		return () without $origin-url;
		return () unless $result.ok;
		return () unless html-ish($result);

		my @links = (try extract-links($result.text, base => $result.final-url)) // ();
		my Str @out;
		for @links -> %link {
			next if %link<nofollow>;
			my $url = try MCP::Server::Tool::Web::Url.parse(%link<url>);
			next without $url;
			next unless $url.same-origin($origin-url);
			@out.push($url.Str);
		}
		@out.List;
	}
}
