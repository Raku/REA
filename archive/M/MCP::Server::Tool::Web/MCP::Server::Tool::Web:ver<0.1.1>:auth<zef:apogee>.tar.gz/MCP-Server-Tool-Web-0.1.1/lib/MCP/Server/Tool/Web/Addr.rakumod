=begin pod

=head1 NAME

MCP::Server::Tool::Web::Addr - IP literal parsing, unwrapping and classification

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Addr;

# Parse, then ask what kind of address it is.
my $a = MCP::Server::Tool::Web::Addr.parse('10.0.0.5');
say $a.classify;                     # private
say $a.reference;                    # RFC 1918

# Anything that is not a public address is refused by the guard, and the
# class name is what the refusal teaches with.
say classify-address('8.8.8.8');            # public
say classify-address('169.254.169.254');    # metadata
say classify-address('::1');                # loopback
say classify-address('not an address');     # (Str) — unparseable

# IPv6 forms that carry an IPv4 address inside them are unwrapped first, so
# there is no way to smuggle 127.0.0.1 past the table by spelling it in v6.
say classify-address('::ffff:127.0.0.1');   # loopback   (v4-mapped)
say classify-address('::ffff:8.8.8.8');     # public     (v4-mapped)
say classify-address('64:ff9b::a00:1');     # private    (NAT64, 10.0.0.1)
say classify-address('2002:7f00:1::');      # loopback   (6to4, 127.0.0.1)

# The allow-list helper: does this address fall inside this block?
say cidr-contains('10.0.0.0/8', '10.4.5.6');            # True
say cidr-contains('10.0.0.0/8', '11.0.0.1');            # False
say cidr-contains('10.0.0.0/8', '::ffff:10.4.5.6');     # True — mapped form counts
say valid-cidr('10.0.0.0/33');                          # False

=end code

=head1 DESCRIPTION

Pure address arithmetic: no DNS, no sockets, no clock, nothing that can fail
in a way a test cannot reproduce. Everything here answers one question — given
a literal address, is it somewhere on the public internet, or somewhere on the
machine (or the network) that is running the tool?

The answer is a class B<name>, not a boolean, because the whole point of the
SSRF floor is to teach: a model that is told "refused: loopback (RFC 1122)"
can decide to stop asking for C<localhost>, while one told "refused" tries
seventeen spellings of the same thing.

=head2 The classification

C<classify> returns exactly one of these strings. Everything not covered by
the table is C<'public'>:

=table
    class            what it covers                                   reference
    public           anything not listed below                        —
    unspecified      ::                                               RFC 4291 §2.5.2
    this-network     0.0.0.0/8                                        RFC 1122 §3.2.1.3
    loopback         127.0.0.0/8, ::1                                 RFC 1122, RFC 4291 §2.5.3
    private          10/8, 172.16/12, 192.168/16                      RFC 1918
    unique-local     fc00::/7                                         RFC 4193
    cgnat            100.64.0.0/10                                    RFC 6598
    link-local       169.254.0.0/16, fe80::/10                        RFC 3927, RFC 4291 §2.5.6
    metadata         well-known cloud metadata endpoints              (inside the ranges above)
    ietf-protocol    192.0.0.0/24                                     RFC 6890 §2.1
    documentation    192.0.2/24, 198.51.100/24, 203.0.113/24, 2001:db8::/32   RFC 5737, RFC 3849
    6to4-relay       192.88.99.0/24                                   RFC 7526
    benchmark        198.18.0.0/15                                    RFC 2544
    multicast        224.0.0.0/4, ff00::/8                            RFC 5771, RFC 4291 §2.7
    reserved         240.0.0.0/4 (incl. 255.255.255.255)              RFC 1112 §4
    discard          100::/64                                         RFC 6666
    teredo           2001::/32                                        RFC 4380
    segment-routing  5f00::/16                                        RFC 9602
    nat64-local      64:ff9b:1::/48 that carries no RFC 6052 address  RFC 8215

C<metadata> is mostly a refinement rather than an extra denial: nearly every
address it names sits inside a range that is denied anyway (169.254.169.254
is link-local, 100.100.100.200 is CGNAT, 192.0.0.192 is IETF-protocol,
fd00:ec2::254 is unique-local). It exists because "cloud instance metadata
endpoint" is a far more useful thing to tell a model — or an operator reading
a log — than "link-local". The one genuine extra denial is Azure's
wireserver, C<168.63.129.16>: it sits in public address space but is routed
only inside an Azure VNet, so nothing on the public web legitimately serves
from it and denying the single address closes a well-known SSRF target.

=head2 Unwrapping

IPv6 has five ways to write an IPv4 address, and every one of them is a way
to spell C<127.0.0.1> that a naive table misses. C<unwrap> maps them all back
to the address they carry, and C<classify> unwraps before it looks anything
up:

=item C<::ffff:0:0/96> — IPv4-mapped (RFC 4291 §2.5.5.2). What a dual-stack
      socket reports for a v4 peer on some platforms, so this is the common
      case, not the exotic one.
=item C<::/96> — IPv4-compatible (deprecated, RFC 4291 §2.5.5.1), B<except>
      C<::> and C<::1> themselves, which keep their own meanings.
=item C<64:ff9b::/96> — the well-known NAT64 prefix (RFC 6052 §2.1).
=item C<64:ff9b:1::/48> — local-use NAT64 (RFC 8215) with the RFC 6052 §2.2
      /48 embedding (two octets, the zero u-octet, two more octets). An
      address in that prefix whose u-octet is B<not> zero carries no address
      we can read, so it fails closed as C<nat64-local> rather than being
      waved through as public.
=item C<2002::/16> — 6to4 (RFC 3056), the embedded address being the next 32
      bits.

Unwrapping is one level deep by construction: every wrapper yields an IPv4
address, and IPv4 has no wrappers.

=head2 Strictness

C<parse> takes canonical literals only. C<0177.0.0.1>, C<127.1>, C<0x7f000001>
and C<2130706433> are B<not> addresses here — they are refused, and
L<MCP::Server::Tool::Web::Url> refuses URLs that carry them, so neither an
operator nor a model ever has to reason about which radix a host name is in.
Zone identifiers (C<fe80::1%eth0>) are refused for the same reason: the guard
would have nothing meaningful to say about the scope.

=end pod

#| A parsed IP literal: a version (4 or 6) and its octets in network order.
#| Immutable, cheap, and comparable. Construct with C<parse> — C<new> is
#| internal and does no validation.
unit class MCP::Server::Tool::Web::Addr;

has Int:D $.version is required;
has List:D $.octets is required;

# === Parsing ===

#| Parse a canonical IPv4 dotted quad or IPv6 literal. Returns the type object
#| (so C<.defined> is the test) for anything else: an obfuscated spelling, a
#| host name, a zone identifier, a bracketed literal, or rubbish.
method parse(Str() $literal --> ::?CLASS) {
	return ::?CLASS unless $literal.defined && $literal.chars;

	if $literal.contains(':') {
		my $octets = parse-v6-octets($literal);
		return ::?CLASS without $octets;
		return ::?CLASS.new(version => 6, octets => $octets);
	}

	my $octets = parse-v4-octets($literal);
	return ::?CLASS without $octets;
	::?CLASS.new(version => 4, octets => $octets);
}

#| Strict dotted quad: exactly four decimal octets, no leading zeros (which
#| would be an octal invitation), each 0..255. Returns Nil for anything else.
my sub parse-v4-octets(Str:D $s --> List) {
	my @labels = $s.split('.');
	return Nil unless @labels == 4;
	my @octets;
	for @labels -> $label {
		return Nil unless $label ~~ /^ \d ** 1..3 $/;
		# '01' and '007' are refused rather than read as decimal: every tool
		# that disagrees about their radix is a bypass waiting to happen.
		return Nil if $label.chars > 1 && $label.starts-with('0');
		my $value = +$label;
		return Nil if $value > 255;
		@octets.push($value);
	}
	@octets.List;
}

#| Full IPv6 literal parser: compressed forms, the mixed C<::ffff:1.2.3.4>
#| notation, and nothing else. Zone identifiers and brackets are refused.
my sub parse-v6-octets(Str:D $s --> List) {
	return Nil if $s.contains('%') || $s.contains('[') || $s.contains(']');

	my $double = $s.index('::');
	my (@head, @tail);
	with $double {
		# Exactly one '::' — a second one makes the elision ambiguous.
		return Nil if $s.substr($double + 2).contains('::');
		my $before = $s.substr(0, $double);
		my $after  = $s.substr($double + 2);
		@head = $before eq '' ?? () !! $before.split(':');
		@tail = $after  eq '' ?? () !! $after.split(':');
	}
	else {
		@head = $s.split(':');
	}

	# The embedded dotted quad, when there is one, may only be the very last
	# group of the whole literal.
	my $tail-is-last = $double.defined && ?@tail;
	my $head-is-last = !$double.defined || !@tail;

	my $head-octets = groups-to-octets(@head, :last($head-is-last));
	return Nil without $head-octets;
	my $tail-octets = groups-to-octets(@tail, :last($tail-is-last));
	return Nil without $tail-octets;

	my $have = $head-octets.elems + $tail-octets.elems;
	with $double {
		# '::' stands for at least one elided group of zeros, so a literal
		# that already spells all eight groups may not also carry one.
		return Nil if $have > 14;
		return (|$head-octets, |(0 xx (16 - $have)), |$tail-octets);
	}
	return Nil unless $have == 16;
	$head-octets;
}

#| Turn one side of a v6 literal into octets. C<:last> says whether this side
#| ends the literal, which is the only position an embedded dotted quad is
#| allowed in.
my sub groups-to-octets(@groups, Bool:D :$last --> List) {
	my @octets;
	for @groups.kv -> $index, $group {
		if $last && $index == @groups.end && $group.contains('.') {
			my $v4 = parse-v4-octets($group);
			return Nil without $v4;
			# Slipped, not appended: a List inside a Scalar is one item to
			# .append, which would leave a nested list in the octets.
			@octets.append(|$v4);
			next;
		}
		return Nil unless $group ~~ /^ <[0..9a..fA..F]> ** 1..4 $/;
		my $value = :16($group);
		@octets.push($value +> 8, $value +& 0xff);
	}
	@octets.List;
}

# === Unwrapping ===

#| The address this one really points at: for the five IPv6 forms that embed
#| an IPv4 address, the address they embed; for everything else, itself.
method unwrap(::?CLASS:D: --> ::?CLASS:D) {
	return self if $!version == 4;
	my @o := $!octets;

	my sub embedded(*@bytes) { ::?CLASS.new(version => 4, octets => @bytes.List) }

	# Explicit loop rather than a slice: a Range held in a Scalar subscripts
	# as a single index, not as a slice, so @o[$range] would quietly answer
	# "yes, all zero" about nothing at all.
	my sub zeros(Int:D $from, Int:D $to --> Bool:D) {
		for $from .. $to -> $i {
			return False unless @o[$i] == 0;
		}
		True;
	}

	# IPv4-mapped: ::ffff:0:0/96.
	return embedded(@o[12], @o[13], @o[14], @o[15])
		if zeros(0, 9) && @o[10] == 0xff && @o[11] == 0xff;

	# IPv4-compatible: ::/96, deprecated — but ':: 'and '::1' are not embedded
	# addresses, they are the unspecified and loopback addresses.
	if zeros(0, 11) {
		my $low = @o[12] +< 24 + @o[13] +< 16 + @o[14] +< 8 + @o[15];
		return self if $low <= 1;
		return embedded(@o[12], @o[13], @o[14], @o[15]);
	}

	if @o[0] == 0x00 && @o[1] == 0x64 && @o[2] == 0xff && @o[3] == 0x9b {
		# Well-known NAT64 prefix 64:ff9b::/96.
		return embedded(@o[12], @o[13], @o[14], @o[15])
			if @o[4] == 0 && @o[5] == 0 && zeros(6, 11);
		# Local-use NAT64 64:ff9b:1::/48, RFC 6052 §2.2 /48 embedding. The
		# u-octet must be zero; if it is not, this is not an embedding we can
		# read, and the deny table catches the whole /48 as nat64-local.
		if @o[4] == 0x00 && @o[5] == 0x01 {
			return self unless @o[8] == 0;
			return embedded(@o[6], @o[7], @o[9], @o[10]);
		}
	}

	# 6to4: 2002::/16, the address in the next 32 bits.
	return embedded(@o[2], @o[3], @o[4], @o[5])
		if @o[0] == 0x20 && @o[1] == 0x02;

	self;
}

# === The deny table ===

# Rows are checked in order and the first match wins, so the metadata
# refinements sit above the ranges that contain them. Everything else is
# disjoint, so the order below is simply numeric for readability.
#
# This table is the security floor of the whole distribution. Anything added
# to it must come with both edges of the block in t/01-addr.rakutest: an
# off-by-one in a prefix length is a hole nobody notices until it is used.
my sub deny-row(Str:D $cidr, Str:D $class, Str:D $reference --> Hash:D) {
	my ($octets, $bits) = parse-cidr($cidr);
	die "Malformed CIDR in the deny table: '$cidr'" without $octets;
	%( :$cidr, :$class, :$reference, :$octets, :$bits );
}

my @DENY-V4 =
	deny-row('169.254.169.254/32', 'metadata', 'RFC 3927 link-local; the EC2/GCE/Azure instance metadata endpoint'),
	deny-row('169.254.170.2/32',   'metadata', 'RFC 3927 link-local; the ECS task metadata endpoint'),
	deny-row('100.100.100.200/32', 'metadata', 'RFC 6598 CGNAT; the Alibaba Cloud instance metadata endpoint'),
	deny-row('192.0.0.192/32',     'metadata', 'RFC 6890 IETF protocol assignments; the Oracle Cloud instance metadata endpoint'),
	# The one metadata endpoint that is NOT inside an already-denied range:
	# Azure's wireserver sits in public address space, but it is routed only
	# inside an Azure VNet and nothing on the public web legitimately serves
	# from it, so denying the single address costs nothing and closes a
	# well-known SSRF target on Azure-hosted deployments.
	deny-row('168.63.129.16/32',   'metadata', 'Azure wireserver / instance metadata endpoint (public space, VNet-internal routing)'),
	deny-row('0.0.0.0/8',          'this-network',  'RFC 1122 §3.2.1.3'),
	deny-row('10.0.0.0/8',         'private',       'RFC 1918'),
	deny-row('100.64.0.0/10',      'cgnat',         'RFC 6598'),
	deny-row('127.0.0.0/8',        'loopback',      'RFC 1122 §3.2.1.3'),
	deny-row('169.254.0.0/16',     'link-local',    'RFC 3927'),
	deny-row('172.16.0.0/12',      'private',       'RFC 1918'),
	deny-row('192.0.0.0/24',       'ietf-protocol', 'RFC 6890 §2.1'),
	deny-row('192.0.2.0/24',       'documentation', 'RFC 5737'),
	deny-row('192.88.99.0/24',     '6to4-relay',    'RFC 7526'),
	deny-row('192.168.0.0/16',     'private',       'RFC 1918'),
	deny-row('198.18.0.0/15',      'benchmark',     'RFC 2544'),
	deny-row('198.51.100.0/24',    'documentation', 'RFC 5737'),
	deny-row('203.0.113.0/24',     'documentation', 'RFC 5737'),
	deny-row('224.0.0.0/4',        'multicast',     'RFC 5771'),
	deny-row('240.0.0.0/4',        'reserved',      'RFC 1112 §4'),
;

my @DENY-V6 =
	deny-row('fd00:ec2::254/128', 'metadata', 'RFC 4193 unique-local; the EC2 IPv6 instance metadata endpoint'),
	deny-row('::/128',            'unspecified',     'RFC 4291 §2.5.2'),
	deny-row('::1/128',           'loopback',        'RFC 4291 §2.5.3'),
	deny-row('64:ff9b:1::/48',    'nat64-local',     'RFC 8215'),
	deny-row('100::/64',          'discard',         'RFC 6666'),
	deny-row('2001::/32',         'teredo',          'RFC 4380'),
	deny-row('2001:db8::/32',     'documentation',   'RFC 3849'),
	deny-row('5f00::/16',         'segment-routing', 'RFC 9602'),
	deny-row('fc00::/7',          'unique-local',    'RFC 4193'),
	deny-row('fe80::/10',         'link-local',      'RFC 4291 §2.5.6'),
	deny-row('ff00::/8',          'multicast',       'RFC 4291 §2.7'),
;

# === CIDR arithmetic ===

#| Split a CIDR block into its base octets and prefix length. Returns
#| C<(Nil, Nil)> when the block is malformed, the base is not a canonical
#| literal, or the prefix length does not fit the family.
my sub parse-cidr(Str:D $cidr) {
	my @parts = $cidr.split('/');
	return (Nil, Nil) unless @parts == 2;
	my $base = MCP::Server::Tool::Web::Addr.parse(@parts[0]);
	return (Nil, Nil) without $base;
	return (Nil, Nil) unless @parts[1] ~~ /^ \d ** 1..3 $/;
	my $bits = +@parts[1];
	return (Nil, Nil) if $bits > ($base.version == 4 ?? 32 !! 128);
	($base.octets, $bits);
}

#| Do two octet lists agree on their first $bits bits?
my sub bits-equal(@a, @b, Int:D $bits --> Bool:D) {
	return False unless @a.elems == @b.elems;
	my $whole = $bits div 8;
	for ^$whole -> $i {
		return False unless @a[$i] == @b[$i];
	}
	my $spare = $bits % 8;
	return True unless $spare;
	my $mask = 0xff +^ (0xff +> $spare);
	(@a[$whole] +& $mask) == (@b[$whole] +& $mask);
}

# === Classification ===

#| Which row of the deny table this address falls in, C<'public'> when none.
#| Unwraps first, so a v4-mapped loopback is loopback and a NAT64-wrapped
#| private address is private.
method classify(::?CLASS:D: --> Str:D) {
	my $row = self!classification-row;
	$row ?? $row<class> !! 'public';
}

#| The RFC (or other authority) behind this address's classification, or the
#| Str type object for a public address. Refusal messages quote it so an
#| operator can go and read why.
method reference(::?CLASS:D: --> Str) {
	my $row = self!classification-row;
	$row ?? $row<reference> !! Str;
}

method !classification-row() {
	my $addr = self.unwrap;
	my @table := $addr.version == 4 ?? @DENY-V4 !! @DENY-V6;
	@table.first({ bits-equal($addr.octets, .<octets>, .<bits>) });
}

# === Rendering ===

#| Canonical text form: dotted quad for v4; RFC 5952 for v6 (lowercase, no
#| leading zeros, the longest run of zero groups compressed once, leftmost run
#| winning a tie), with the dotted tail kept for v4-mapped addresses because
#| that is the form people recognise.
multi method Str(::?CLASS:D: --> Str:D) {
	return $!octets.join('.') if $!version == 4;

	my @groups = (^8).map({ $!octets[$_ * 2] +< 8 + $!octets[$_ * 2 + 1] });

	# ::ffff:1.2.3.4 rather than ::ffff:102:304 — RFC 5952 §5.
	if @groups[0..4].all == 0 && @groups[5] == 0xffff {
		return "::ffff:" ~ $!octets[12..15].join(".");
	}

	my ($best-start, $best-length) = (-1, 0);
	my ($start, $length) = (-1, 0);
	for ^8 -> $i {
		if @groups[$i] == 0 {
			$start = $i if $length == 0;
			$length++;
			($best-start, $best-length) = ($start, $length) if $length > $best-length;
		}
		else {
			$length = 0;
		}
	}
	# A single zero group is written out, not compressed (RFC 5952 §4.2.2).
	($best-start, $best-length) = (-1, 0) if $best-length < 2;

	my @parts;
	my $i = 0;
	while $i < 8 {
		if $i == $best-start {
			@parts.push('');
			@parts.push('') if $i == 0;
			@parts.push('') if $best-start + $best-length == 8;
			$i += $best-length;
			next;
		}
		@parts.push(@groups[$i].base(16).lc);
		$i++;
	}
	@parts.join(':');
}

multi method gist(::?CLASS:D: --> Str:D) { self.Str }

# === Exported helpers ===

#| Parse a literal, or get the type object back. Sugar for C<Addr.parse> so
#| callers need not name the class.
sub parse-address(Str() $literal --> MCP::Server::Tool::Web::Addr) is export {
	MCP::Server::Tool::Web::Addr.parse($literal);
}

#| Classify a literal in one step. Returns the Str type object — not
#| C<'public'> — when the literal does not parse, so callers cannot mistake
#| "I could not tell" for "it is fine".
sub classify-address(Str() $literal --> Str) is export {
	my $addr = MCP::Server::Tool::Web::Addr.parse($literal);
	$addr.defined ?? $addr.classify !! Str;
}

#| Is this CIDR block well formed? Used to validate the C<allow-cidrs> config
#| key up front, so a typo is a startup error rather than a silent hole.
sub valid-cidr(Str() $cidr --> Bool:D) is export {
	my ($octets, $bits) = parse-cidr($cidr // '');
	$octets.defined;
}

#| Does C<$address> fall inside C<$cidr>? False for a malformed block or an
#| unparseable address — this backs an allow-list, so anything it cannot
#| understand must fail closed.
#|
#| The two families meet where an IPv4 address is written in v6: a peer
#| reported as C<::ffff:10.0.0.5> matches C<10.0.0.0/8>, and a block written
#| as C<::ffff:10.0.0.0/104> matches the peer C<10.0.0.5>. Both spellings mean
#| the same machine, and which one an operator sees depends on the platform.
sub cidr-contains(Str() $cidr, Str() $address --> Bool:D) is export {
	my ($base, $bits) = parse-cidr($cidr // '');
	return False without $base;
	my $addr = MCP::Server::Tool::Web::Addr.parse($address);
	return False without $addr;

	my $version = $base.elems == 4 ?? 4 !! 6;
	return bits-equal($addr.octets, $base, $bits) if $addr.version == $version;

	# The address is v6 and the block v4 (or the reverse): compare the
	# embedded address instead.
	if $addr.version == 6 && $version == 4 {
		my $inner = $addr.unwrap;
		return $inner.version == 4 && bits-equal($inner.octets, $base, $bits);
	}

	# A v4-mapped block: strip the /96 wrapper from both the base and the
	# prefix length. Other v6 wrappers (6to4, NAT64) are left alone — an
	# operator who writes 2002::/16 means the 6to4 range itself.
	if $addr.version == 4 && $version == 6 && $bits >= 96 {
		my $inner = MCP::Server::Tool::Web::Addr.new(version => 6, octets => $base).unwrap;
		return False unless $inner.version == 4;
		return bits-equal($addr.octets, $inner.octets, $bits - 96);
	}

	False;
}
