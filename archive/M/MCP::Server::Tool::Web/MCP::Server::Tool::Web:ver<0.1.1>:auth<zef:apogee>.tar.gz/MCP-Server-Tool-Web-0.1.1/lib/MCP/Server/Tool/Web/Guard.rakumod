=begin pod

=head1 NAME

MCP::Server::Tool::Web::Guard - the SSRF floor: which URLs, and which
addresses behind them, the web tools will talk to

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Guard;

# The default: the public internet, and nothing else.
my $guard = MCP::Server::Tool::Web::Guard.new;

# Shape first — this throws X::…::BadUrl before anything is resolved.
my $url = $guard.check-url('https://docs.example.com/guide');

# Then the address, once a socket is actually connected. $peer is what the
# socket says it is talking to, so a name cannot be re-resolved out from
# under the check.
$guard.check-address($url.host, '93.184.216.34');    # True
$guard.check-address($url.host, '10.0.0.5');         # throws X::…::Blocked

# A test rig, or an operator who really does want the machine's own network:
my $lan = MCP::Server::Tool::Web::Guard.new(
    allow-loopback => True,                 # 127.0.0.0/8 and ::1 only
    allow-hosts    => <wiki.corp docs.corp>,# exact host names, no wildcards
    allow-cidrs    => ['10.9.0.0/16'],      # v4 and v6 blocks
);
$lan.check-address('wiki.corp', '10.1.2.3');     # True — named in allow-hosts
$lan.check-address('other.corp', '10.9.1.1');    # True — inside allow-cidrs
$lan.check-address('other.corp', '10.1.2.3');    # throws — neither

# No allow-list entry rescues a URL that was refused on its shape.
$lan.check-url('file:///etc/passwd');                 # throws X::…::BadUrl
$lan.check-url('http://user:pw@wiki.corp/');          # throws X::…::BadUrl

=end code

=head1 DESCRIPTION

The guard is the policy half of the SSRF floor: it holds the operator's
configuration and answers two questions.

=head2 C<check-url> — is this URL one we would ever fetch?

Shape only: scheme, credentials, host spelling, port range. It runs before
anything is resolved, and B<no allow-list entry can rescue a URL it refuses>.
That is a deliberate asymmetry: allow-lists exist to widen which B<machines>
may be reached, and C<file:///etc/passwd> is not a machine.

When the URL's host is an address literal, C<check-url> also runs the address
check immediately, because there is nothing left to learn from resolving it —
so C<http://127.0.0.1/> is refused up front, with the same message and the same
allow-list rules that would have applied after connecting.

=head2 C<check-address> — is the machine we just connected to one we may talk to?

Given the host that was asked for and the peer address of the socket that was
actually established, the peer is classified by
L<MCP::Server::Tool::Web::Addr> and:

=item C<'public'> is allowed. Nothing else is, unless the configuration says so.
=item C<allow-private> allows every class. It is the blunt instrument: one
      switch for "this machine may reach its own network".
=item C<allow-hosts> allows the request if the host asked for is in the list,
      B<matched exactly>. C<corp> matches the host C<corp> and nothing else —
      not C<wiki.corp>, and emphatically not C<evil.com.corp>. Suffix matching
      is where allow-list CVEs come from; there is no wildcard syntax, and a
      pattern in the list is a configuration error rather than a silent no-op.
=item C<allow-cidrs> allows the request if the peer address falls inside one
      of the listed blocks. IPv4 and IPv6 both, and a v4 address written in
      its v6-mapped form matches a v4 block (which platform you are on decides
      which spelling you see).
=item C<allow-loopback> allows loopback B<only> — the narrow key for test rigs
      and local development servers, so that enabling one does not open the
      whole LAN.

An address that does not parse is refused: the guard never treats "I could not
tell" as "it is fine".

=head2 Why the peer, not a lookup

C<check-address> takes the address of an B<established socket>. Resolving the
name a second time to check it would be a race the attacker picks the winner
of (DNS rebinding); the address of a live TCP connection cannot be changed by
a later DNS answer. The connector in L<MCP::Server::Tool::Web::Transport>
connects first, checks second, and has written nothing at the point of the
check — no request, no C<Host>, not even a TLS ClientHello.

=head2 Refusals teach

Every refusal names the rule, the classification, the RFC behind it, the host,
the address it resolved to, and the configuration key that would permit it.
The audience is a language model deciding what to try next, and "denied" makes
it try the same thing spelled differently.

=end pod

use MCP::Server::Tool::Web::Addr;
use MCP::Server::Tool::Web::Url;
use MCP::Server::Tool::Web::X;

#| The policy object. Immutable after construction: one guard per pack
#| instance, shared by every fetch it makes, so a connection cached by the
#| HTTP client was vetted under exactly the configuration still in force.
unit class MCP::Server::Tool::Web::Guard;

#| Allow every non-public class — the whole of RFC 1918, CGNAT, link-local,
#| metadata endpoints, the lot. Off by default.
has Bool:D $.allow-private = False;

#| Allow loopback (127.0.0.0/8, ::1) without allowing anything else. This is
#| the key for test rigs and local development servers.
has Bool:D $.allow-loopback = False;

#| Exact host names that may resolve anywhere. Lowercased on the way in; a
#| trailing root dot is dropped so the entries match normalised URL hosts.
has Str:D @.allow-hosts;

#| CIDR blocks whose addresses may be connected to, IPv4 and IPv6.
has Str:D @.allow-cidrs;

submethod TWEAK {
	my @hosts;
	for @!allow-hosts -> $entry {
		my $host = $entry.trim.lc;
		die 'allow-hosts entries must be host names; got an empty one'
			unless $host.chars;
		# A pattern here would match nothing and look like it matched
		# everything, which is the worst failure mode an allow-list has.
		die "allow-hosts takes exact host names, not patterns: '$entry' would never match. "
			~ 'List each host you want to allow.'
			if $host.contains('*') || $host.contains('?');
		die "allow-hosts entries are host names, not URLs: '$entry'"
			if $host.contains('/') || $host.contains(':');
		$host = $host.substr(0, *-1) if $host.chars > 1 && $host.ends-with('.');
		@hosts.push($host);
	}
	@!allow-hosts = @hosts.unique;

	for @!allow-cidrs -> $cidr {
		die "allow-cidrs entries must be CIDR blocks like '10.0.0.0/8' or 'fd00::/8'; got '$cidr'"
			unless valid-cidr($cidr.trim);
	}
	@!allow-cidrs = @!allow-cidrs.map(*.trim).unique;
}

# === URL shape ===

#| Parse and vet a URL string. Returns the normalised
#| L<MCP::Server::Tool::Web::Url>; throws C<X::…::BadUrl> for a shape no
#| configuration permits, or C<X::…::Blocked> when the host is an address
#| literal this guard will not talk to.
multi method check-url(Str:D $url --> MCP::Server::Tool::Web::Url:D) {
	self.check-url(MCP::Server::Tool::Web::Url.parse($url));
}

#| Vet an already-parsed URL — the form the redirect loop uses, once per hop.
multi method check-url(MCP::Server::Tool::Web::Url:D $url --> MCP::Server::Tool::Web::Url:D) {
	# Belt and braces: Url.parse enforces this too, but a Url built by hand
	# (or by a future caller of .new) must not be able to sidestep it.
	X::MCP::Server::Tool::Web::BadUrl.new(
		url    => $url.Str,
		reason => "the '{$url.scheme}' scheme is not fetchable",
		hint   => 'These tools speak http and https only.',
	).throw unless $url.scheme eq 'http' | 'https';

	# A literal address needs no resolving, so judge it now: the caller gets
	# the refusal before a socket is opened, and a crawl can skip the link.
	self.check-address($url.host, $url.host) if $url.literal-address;

	$url;
}

# === Addresses ===

#| Vet the peer address of an established connection to C<$host>. Returns True
#| when the connection may proceed, and throws C<X::…::Blocked> — naming the
#| class, the RFC, the host, the address and the key that would permit it —
#| when it may not.
method check-address(Str:D $host, Str:D $peer --> Bool:D) {
	my $name = $host.trim.lc;
	$name = $name.substr(0, *-1) if $name.chars > 1 && $name.ends-with('.');

	my $addr = MCP::Server::Tool::Web::Addr.parse($peer);
	without $addr {
		# Fail closed, and say so: allow-hosts is the only key that could
		# possibly apply, since every other one reasons about the address.
		X::MCP::Server::Tool::Web::Blocked.new(
			host       => $name,
			address    => $peer,
			config-key => 'allow-hosts',
			remedy     => "Add '$name' to allow-hosts to permit it by name.",
		).throw unless @!allow-hosts.first($name).defined;
		return True;
	}

	my Str:D $class = $addr.classify;
	return True if $class eq 'public';

	return True if $!allow-private;
	return True if @!allow-hosts.first($name).defined;
	return True if @!allow-cidrs.first({ cidr-contains($_, $peer) }).defined;
	return True if $class eq 'loopback' && $!allow-loopback;

	my Str:D $key = $class eq 'loopback' ?? 'allow-loopback' !! 'allow-private';
	my $inner = $addr.unwrap;
	X::MCP::Server::Tool::Web::Blocked.new(
		host          => $name,
		address       => $addr.Str,
		address-class => $class,
		reference     => $addr.reference,
		config-key    => $key,
		note          => $inner.Str eq $addr.Str
			?? Str
			!! "That address carries the IPv4 address {$inner.Str} inside it.",
		remedy        => remedy-for($key, $name, $addr),
	).throw;
}

#| Is this address one the guard would connect to, without throwing? For
#| callers that need to sort links rather than refuse a request — a crawl
#| deciding whether a link is worth following, say.
method allows-address(Str:D $host, Str:D $peer --> Bool:D) {
	my $ok = try self.check-address($host, $peer);
	$ok // False;
}

#| A one-line summary of what this guard permits, for notices and logs.
method describe(--> Str:D) {
	my @parts = 'public addresses';
	@parts.push('every private range (allow-private)') if $!allow-private;
	@parts.push('loopback (allow-loopback)') if $!allow-loopback && !$!allow-private;
	@parts.push("hosts: {@!allow-hosts.join(', ')} (allow-hosts)") if @!allow-hosts;
	@parts.push("blocks: {@!allow-cidrs.join(', ')} (allow-cidrs)") if @!allow-cidrs;
	'Reachable: ' ~ @parts.join('; ');
}

#| Compose the "how to permit this" half of a refusal. Every key that would
#| actually work is named, most specific first, because an operator who wants
#| one host reachable should not be reaching for allow-private.
my sub remedy-for(Str:D $key, Str:D $host, MCP::Server::Tool::Web::Addr:D $addr --> Str:D) {
	my @ways =
		"set $key to true",
		"add '$host' to allow-hosts (exact match — no wildcards or suffixes)",
		"add a block covering {$addr.Str} to allow-cidrs";
	@ways.push('set allow-private to true to permit every private range')
		if $key eq 'allow-loopback';
	'To permit it, ' ~ @ways[0] ~ ', ' ~ @ways[1..*-2].join(', ') ~ ' or ' ~ @ways[*-1] ~ '.';
}
