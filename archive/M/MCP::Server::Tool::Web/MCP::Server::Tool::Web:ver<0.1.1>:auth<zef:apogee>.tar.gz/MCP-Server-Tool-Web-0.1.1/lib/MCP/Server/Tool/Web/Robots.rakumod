=begin pod

=head1 NAME

MCP::Server::Tool::Web::Robots - robots.txt policy: the seam, the
"do not consult it" implementation, and the RFC 9309 one

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Robots;
use MCP::Server::Tool::Web::Url;

my $url = MCP::Server::Tool::Web::Url.parse('https://example.com/private/x');

# What a single-page fetch uses: robots.txt is never consulted.
my $off = MCP::Server::Tool::Web::Robots::Off.new;
say $off.allow($url, agent => 'MCP-Server-Tool-Web/0.1.0');   # True
say $off.describe;    # robots.txt is not consulted (single-page fetches)

# What a crawl uses. The one thing it cannot do for itself is fetch, so the
# fetch is handed in — which is also how tests give it bodies directly.
my $respect = MCP::Server::Tool::Web::Robots::Respect.new(
    fetch-robots => -> Str $origin {
        "User-agent: *\nDisallow: /private/\nCrawl-delay: 2\n";
    },
);

say $respect.allow($url, agent => 'MCP-Server-Tool-Web/0.1.0');        # False
say $respect.disallow-rule($url, agent => 'MCP-Server-Tool-Web/0.1.0');# /private/
say $respect.crawl-delay($url, agent => 'MCP-Server-Tool-Web/0.1.0');  # 2

=end code

Wiring it to a real fetcher is a two-step, because the robots policy and the
fetcher that feeds it point at each other. The closure is not called until
the first crawl, so binding the fetcher after the fact is safe:

=begin code :lang<raku>

my $fetcher;
my $robots = MCP::Server::Tool::Web::Robots::Respect.new(
    fetch-robots => -> Str $origin { $fetcher.robots-text($origin) },
);
$fetcher = MCP::Server::Tool::Web::Fetcher.new(:$guard, :$transport, :$robots);

=end code

=head1 DESCRIPTION

Per the pack's ruling, C<web_crawl> (and C<web_grep> with a depth above zero)
respects robots.txt; C<web_fetch> and depth-zero grep do not. A single page a
person explicitly asked for is not crawling, and no robots.txt has ever meant
"this URL may not be read once, deliberately, by a human's agent". Traversal
is a different act, and that one is asked for.

So there are two implementations of one role, and the difference between "we
crawl politely" and "we fetch one page" is which object the Fetcher holds.

=head2 The role

=item C<allow(Url:D $url, Str:D :$agent!)> — may we request this URL?
=item C<disallow-rule(Url:D $url, Str:D :$agent!)> — the C<Disallow> pattern
      that refused it, for the refusal message, or the C<Str> type object.
=item C<crawl-delay(Url:D $url, Str:D :$agent!)> — seconds this origin asks
      to be left between requests. B<A crawl takes the larger of this and its
      own configured delay>: robots.txt may slow us down, never speed us up.
=item C<describe()> — one line for notices and logs.

=head2 What C<Respect> implements (RFC 9309)

=item Groups are C<User-agent> lines followed by their rules; consecutive
      C<User-agent> lines share one group.
=item The group whose product token matches ours wins; failing that, the
      C<*> group; failing that, everything is allowed. Matching is
      case-insensitive, and a full user-agent string is reduced to its
      product token (the part before the C</>) before comparing.
=item C<Allow> and C<Disallow> patterns support C<*> (any run of characters)
      and a trailing C<$> (end of path). The B<longest matching pattern>
      decides, and C<Allow> wins a tie — so C<Disallow: /docs/> plus
      C<Allow: /docs/public/> reads the way its author meant.
=item An empty C<Disallow:> is not a rule at all (it is the idiomatic way to
      say "everything is permitted"), and neither is an empty C<Allow:>.
=item C<Crawl-delay> is read, and only ever raises a caller's delay.
=item Anything else — C<Sitemap>, unknown fields, junk — is ignored rather
      than treated as an error.

=head2 Failure is permission

A missing robots.txt, a 4xx, a timeout, a body that does not parse, or a fetch
that throws all mean B<allowed>. That is RFC 9309's own reading ("unavailable"
means unrestricted), and it is the only choice that does not turn a flaky
origin into a silently empty crawl. The one thing that would be worse than
crawling a page we should not have is reporting "no pages found" for a site
that was simply slow to answer.

=head2 The cache

One entry per origin, holding the parsed groups and an expiry. Lookups drop
expired entries as they pass them, and an insert that would take the cache
over C<cache-size> evicts the least recently used entry. There are no timers
and no threads: a cache that needed cleaning up would be a shutdown obligation
the pack does not otherwise have.

The fetch happens outside the cache lock, so two crawls starting at once may
both fetch the same robots.txt. That is one wasted request rather than a
lock held across the network, which is the right trade.

=end pod

use MCP::Server::Tool::Web::Url;

#| The seam C<MCP::Server::Tool::Web::Fetcher> consults before it requests
#| anything. Two implementations ship: C<Off> and C<Respect>.
role MCP::Server::Tool::Web::Robots {
	#| May we request this URL as C<$agent>?
	method allow(MCP::Server::Tool::Web::Url:D $url, Str:D :$agent! --> Bool:D) { ... }

	#| The C<Disallow> pattern that refused this URL, or the C<Str> type
	#| object when nothing did. Only ever asked after C<allow> said no.
	method disallow-rule(MCP::Server::Tool::Web::Url:D $url, Str:D :$agent! --> Str) { Str }

	#| Seconds this origin asks to be left between requests. Callers take the
	#| larger of this and their own setting.
	method crawl-delay(MCP::Server::Tool::Web::Url:D $url, Str:D :$agent! --> Real:D) { 0 }

	#| One line describing this policy, for notices.
	method describe(--> Str:D) { ... }
}

#| robots.txt is not consulted. What C<web_fetch> and depth-zero C<web_grep>
#| hold: one page, asked for by name, is not a crawl.
class MCP::Server::Tool::Web::Robots::Off does MCP::Server::Tool::Web::Robots {
	method allow(MCP::Server::Tool::Web::Url:D $url, Str:D :$agent! --> Bool:D) { True }

	method describe(--> Str:D) {
		'robots.txt is not consulted (single-page fetches are not crawling)';
	}
}

#| RFC 9309 robots.txt, fetched once per origin and cached. What C<web_crawl>
#| and C<web_grep> with depth hold, unless C<respect-robots> is off.
class MCP::Server::Tool::Web::Robots::Respect does MCP::Server::Tool::Web::Robots {
	#|( How a robots.txt is fetched: C<($origin --E<gt> Str)>, where C<$origin>
	    is a scheme-host-port string like C<'https://example.com'> and the
	    return is the body text, or C<Str> / C<Nil> when there is none. It may
	    throw; throwing means "allowed", like every other failure. Required —
	    a Respect policy that silently could not fetch would be an Off policy
	    wearing its name. )
	has &!fetch-robots is built;

	#| How long a parsed robots.txt is trusted, in seconds.
	has Real:D $.cache-seconds = 300;

	#| How many origins are remembered at once.
	has Int:D $.cache-size = 32;

	has %!cache;
	has Int:D $!tick = 0;
	has Lock:D $!lock = Lock.new;

	submethod TWEAK {
		die 'Robots::Respect needs a fetch-robots closure: it has no opinion '
			~ 'about how to make an HTTP request. Pass '
			~ 'fetch-robots => -> $origin { ... } returning the robots.txt '
			~ 'body (or Str when there is none).'
			unless &!fetch-robots.defined;
		die "cache-seconds cannot be negative; got $!cache-seconds"
			if $!cache-seconds < 0;
		die "cache-size must be at least 1; got $!cache-size"
			if $!cache-size < 1;
	}

	method allow(MCP::Server::Tool::Web::Url:D $url, Str:D :$agent! --> Bool:D) {
		my $verdict = self!verdict($url, $agent);
		$verdict<allowed>;
	}

	method disallow-rule(MCP::Server::Tool::Web::Url:D $url, Str:D :$agent! --> Str) {
		my $verdict = self!verdict($url, $agent);
		$verdict<allowed> ?? Str !! $verdict<rule>;
	}

	method crawl-delay(MCP::Server::Tool::Web::Url:D $url, Str:D :$agent! --> Real:D) {
		my @groups = self!groups-for($url, $agent);
		my $delay = 0;
		for @groups -> %group {
			$delay = %group<crawl-delay>
				if %group<crawl-delay>.defined && %group<crawl-delay> > $delay;
		}
		$delay;
	}

	method describe(--> Str:D) {
		"robots.txt is respected (cached per origin for {$!cache-seconds}s;"
			~ ' set respect-robots to false to ignore it)';
	}

	#| How many origins are currently cached. Diagnostics, and what a cache
	#| test asserts on.
	method cached-origins(--> Int:D) {
		$!lock.protect: { %!cache.elems }
	}

	#| Forget everything. A crawl that has just been told the world changed —
	#| or a test moving between fixtures — can start clean.
	method clear-cache(--> Nil) {
		$!lock.protect: { %!cache = () }
	}

	method !verdict(MCP::Server::Tool::Web::Url:D $url, Str:D $agent --> Hash:D) {
		my @groups = self!groups-for($url, $agent);
		return %( allowed => True, rule => Str ) unless @groups;

		my $path = $url.target;
		my $best-allow = -1;
		my $best-deny  = -1;
		my Str $deny-rule;

		for @groups -> %group {
			for %group<rules>.List -> %rule {
				next unless path-matches(%rule<pattern>, $path);
				my $length = %rule<pattern>.chars;
				if %rule<allow> {
					$best-allow = $length if $length > $best-allow;
				}
				elsif $length > $best-deny {
					$best-deny = $length;
					$deny-rule = %rule<pattern>;
				}
			}
		}

		# RFC 9309 §2.2.2: the longest match wins, and Allow wins a tie — which
		# is what makes 'Disallow: /docs/' + 'Allow: /docs/public/' behave.
		$best-deny > $best-allow
			?? %( allowed => False, rule => $deny-rule )
			!! %( allowed => True,  rule => Str );
	}

	#| The groups that apply to C<$agent> for this URL's origin: ours if the
	#| file names us, else the C<*> group, else none at all.
	method !groups-for(MCP::Server::Tool::Web::Url:D $url, Str:D $agent --> List:D) {
		my @groups = self!groups($url.origin);
		return () unless @groups;

		my $token = product-token($agent);
		my @mine = @groups.grep({ .<agents>.first({ $_ eq $token }).defined });
		return @mine.List if @mine;
		@groups.grep({ .<agents>.first('*').defined }).List;
	}

	#| The parsed groups for an origin, fetching and caching as needed.
	method !groups(Str:D $origin --> List:D) {
		my $hit = $!lock.protect: {
			my $entry = %!cache{$origin};
			if $entry.defined && $entry<expires> > now {
				$entry<used> = ++$!tick;
				$entry;
			}
			else {
				# An expired entry is dropped on the way past rather than by a
				# sweep: the cache is small and every lookup passes through here.
				%!cache{$origin}:delete if $entry.defined;
				Nil;
			}
		}
		return $hit<groups>.List if $hit.defined;

		# Deliberately outside the lock: this is a network request, and a lock
		# held across one is a stall waiting for a slow origin.
		my $text = self!fetch($origin);
		my @groups = $text.defined ?? parse-robots($text) !! ();

		$!lock.protect: {
			%!cache{$origin} = %( groups => @groups.List, used => ++$!tick,
				expires => now + $!cache-seconds );
			if %!cache.elems > $!cache-size {
				my $victim = %!cache.keys.sort({ %!cache{$_}<used> }).head;
				%!cache{$victim}:delete with $victim;
			}
		}
		@groups.List;
	}

	#| Fetch, and turn every kind of failure into "there is no robots.txt",
	#| which RFC 9309 reads as "nothing is restricted".
	method !fetch(Str:D $origin --> Str) {
		my $text = try &!fetch-robots($origin);
		$text ~~ Str:D ?? $text !! Str;
	}
}

# === Parsing ===

#| The product token of a user-agent string: 'MCP-Server-Tool-Web/0.1.0 (+…)'
#| is matched against robots.txt as 'mcp-server-tool-web'.
my sub product-token(Str:D $agent --> Str:D) {
	my $token = $agent.trim.lc;
	with $token.index('/') -> $slash {
		$token = $token.substr(0, $slash);
	}
	$token.words.head // $token;
}

#| Parse a robots.txt into groups: C<%(agents =E<gt> [...], rules =E<gt>
#| [%(allow, pattern)], crawl-delay)>. Never throws — a file it cannot make
#| sense of yields the groups it could, which may be none, and none means
#| "allowed".
my sub parse-robots(Str:D $text --> List:D) {
	my @groups;
	my @agents;
	my @rules;
	my $delay;
	my Bool $in-agents = False;

	my sub flush() {
		@groups.push(%( agents => @agents.List, rules => @rules.List,
			crawl-delay => $delay )) if @agents;
		@agents = ();
		@rules  = ();
		$delay  = Real;
	}

	for $text.lines -> $raw {
		my $line = $raw;
		# Comments run to end of line, and a '#' is not otherwise meaningful.
		with $line.index('#') -> $hash {
			$line = $line.substr(0, $hash);
		}
		$line = $line.trim;
		next unless $line.chars;

		my $colon = $line.index(':');
		next without $colon;
		my $field = $line.substr(0, $colon).trim.lc;
		my $value = $line.substr($colon + 1).trim;

		if $field eq 'user-agent' {
			# A run of User-agent lines shares one group; the first one after
			# a rule starts a new group.
			flush() unless $in-agents;
			@agents.push($value.lc) if $value.chars;
			$in-agents = True;
			next;
		}

		$in-agents = False;
		# Rules before any User-agent line belong to nobody, so they are
		# dropped rather than guessed at.
		next unless @agents;

		given $field {
			when 'disallow' | 'allow' {
				# 'Disallow:' with nothing after it is the idiomatic way of
				# saying "no restrictions", so it is not a rule.
				@rules.push(%( allow => $field eq 'allow', pattern => $value ))
					if $value.chars;
			}
			when 'crawl-delay' {
				my $seconds = +$value;
				$delay = $seconds if $seconds.defined && $seconds >= 0;
			}
		}
	}
	flush();

	@groups.List;
}

#| Does a robots.txt path pattern match this path? C<*> stands for any run of
#| characters and a trailing C<$> anchors the end; everything else is literal.
#| A pattern always matches from the start of the path, which is what makes
#| C<Disallow: /a> cover C</about> — deliberately, per RFC 9309 §2.2.2.
my sub path-matches(Str:D $pattern, Str:D $path --> Bool:D) {
	my $p = $pattern;
	my Bool $anchored = $p.ends-with('$');
	$p = $p.substr(0, *-1) if $anchored;

	my @parts = $p.split('*');
	my Int $pos = 0;
	for @parts.kv -> $index, $part {
		my Int $from = $pos;
		if $index == 0 {
			return False unless $path.substr(0, $part.chars) eq $part;
			$pos = $part.chars;
		}
		else {
			my $at = $part.chars ?? $path.index($part, $from) !! $from;
			return False without $at;
			$pos = $at + $part.chars;
		}
		if $index == @parts.end && $anchored {
			# The last literal has to land at the very end of the path, and no
			# earlier than wherever the previous ones left off.
			return False if $part.chars > $path.chars;
			my $tail = $path.chars - $part.chars;
			return $tail >= $from && $path.substr($tail) eq $part;
		}
	}
	True;
}
