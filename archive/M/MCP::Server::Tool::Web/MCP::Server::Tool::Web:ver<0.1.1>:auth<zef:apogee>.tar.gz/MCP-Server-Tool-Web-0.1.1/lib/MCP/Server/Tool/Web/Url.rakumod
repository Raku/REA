=begin pod

=head1 NAME

MCP::Server::Tool::Web::Url - strict, normalising URL parsing for the web tools

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Url;

my $url = MCP::Server::Tool::Web::Url.parse('HTTP://Example.COM:80/A/b?q=1#frag');
say $url.Str;            # http://example.com/A/b?q=1  — host folded, default
                         # port dropped, fragment gone, path untouched
say $url.origin;         # http://example.com
say $url.host;           # example.com
say $url.port;           # 80  — the effective port, never undefined
say $url.target;         # /A/b?q=1  — what goes on the wire

# Redirects: RFC 3986 reference resolution, then the whole parse again. A
# Location header cannot smuggle in a scheme or a host shape that
# MCP::Server::Tool::Web::Url.parse would have refused.
my $next = $url.resolve('/other?x=2');
say $next.Str;                       # http://example.com/other?x=2
say $url.same-origin($next);         # True

# Same origin means scheme, host and *effective* port — so the default port
# spelled out is still the same origin.
say MCP::Server::Tool::Web::Url.parse('https://example.com/a')
    .same-origin(MCP::Server::Tool::Web::Url.parse('https://example.com:443/b'));  # True

# Everything below is refused, with a message that says which rule refused it.
for <
    file:///etc/passwd
    javascript:alert(1)
    http://user:pw@example.com/
    http://2130706433/
    http://0x7f000001/
    http://127.1/
    http://017700000001/
    http://example.com:99999/
    http://exämple.com/
> -> $bad {
    my $why = (try MCP::Server::Tool::Web::Url.parse($bad)) // $!.message;
    say $why;
}

=end code

=head1 DESCRIPTION

C<Cro::Uri> does RFC 3986 — it parses the grammar and resolves references,
and it is right to be liberal about it, because RFC 3986 describes every URI
anyone has ever written. This class is the opposite: it accepts the small,
boring subset of URLs a web tool should ever act on, and refuses everything
else B<by name>, before a socket is opened.

Everything C<parse> returns is normalised, so two spellings of one page
compare equal:

=item scheme and host lowercased;
=item a single trailing root dot removed from the host (C<example.com.> and
      C<example.com> are the same name in DNS, and treating them as two
      origins would split a crawl in half);
=item an IPv6 literal rewritten in its canonical RFC 5952 form, so
      C<[0:0:0:0:0:0:0:1]> and C<[::1]> are one origin;
=item the default port for the scheme dropped from C<origin> and C<Str>, but
      always available as C<port>;
=item the fragment dropped — it is never sent to a server, and keeping it
      would make two requests for one page look like two pages.

The path is B<not> touched beyond that: C</a/../b> is requested as written,
because the server, not this class, decides what a dot segment means to it.
Reference resolution is the one place dot segments are removed, because RFC
3986 §5 says to — so C<parse('http://x/a/../b')> keeps the path and
C<parse('http://x/').resolve('/a/../b')> does not. Compare fetched pages by
their B<final> URL if you need one canonical spelling per page.

=head2 What is refused, and why

Each of these throws C<X::MCP::Server::Tool::Web::BadUrl>, whose message
names the rule. B<No allow-list rescues any of them>: these are shape rules,
decided before anything is resolved, and C<allow-private> / C<allow-hosts> /
C<allow-cidrs> / C<allow-loopback> are about addresses, not shapes.

=item B<Non-absolute, or a scheme other than http/https.> C<file:> would read
      the disk, C<javascript:> and C<data:> mean nothing to a fetcher, and a
      relative URL has no host to check.
=item B<Credentials in the URL.> C<http://user:pw@host/> exists mostly to make
      a host look like a path to a human ("http://docs.example.com@evil.test").
      Refused outright rather than stripped, so nobody has to wonder which
      half was used.
=item B<Numerically obfuscated hosts.> C<2130706433>, C<0x7f000001>,
      C<017700000001> and C<127.1> are all C<127.0.0.1> — legal for
      C<getaddrinfo>, unreadable for a human reviewing a log. The connector
      floor would catch them anyway (it checks the address of the socket it
      actually holds), but a URL nobody can read is refused as a matter of
      clarity, not just safety.
=item B<Percent-encoding in the host.> C<http://127.0.0.%31/> decodes to
      C<127.0.0.1>. There is no legitimate use.
=item B<Non-ASCII hosts.> Cro percent-encodes them rather than punycoding, and
      a percent-encoded host does not resolve; the refusal asks for the
      A-label (C<xn--…>) form instead, which is what DNS wants anyway.
=item B<Ports outside 1..65535>, IPv6 zone identifiers, empty or over-long
      host labels, and characters that are not valid in a host name.

=head2 Resolving redirects

C<resolve> is C<Cro::Uri.add> — the RFC 3986 §5 reference resolution algorithm,
which is fiddly enough to be worth not reimplementing — followed by the whole
of C<parse> again. That second half is the point: a C<Location: file:///etc/passwd>
or C<Location: http://10.0.0.1/> is refused on the hop that produced it, with
the same message it would have got as a starting URL.

=end pod

use Cro::Uri;

use MCP::Server::Tool::Web::Addr;
use MCP::Server::Tool::Web::X;

#| One normalised, validated http(s) URL. Construct with C<parse> or C<resolve>;
#| C<new> is internal and assumes its arguments are already checked.
unit class MCP::Server::Tool::Web::Url;

has Str:D  $.scheme is required;
has Str:D  $.host   is required;
has Int:D  $.port   is required;
has Str:D  $.path   is required;
has Str    $.query;
has Bool:D $.literal-address = False;
has Int    $.address-version;

my constant %DEFAULT-PORT = http => 80, https => 443;

# Characters a host may contain once Cro has decoded any percent sequences.
# Deliberately narrower than RFC 3986's reg-name (which also allows
# !$&'()*+,;= ): for http(s) a host is a DNS name or an address literal, and
# anything else is either an encoding trick or a typo.
my constant HOST-CHARS = /^ <[a..z 0..9 _ . -]>+ $/;

# === Parsing ===

#| Parse an absolute http(s) URL, or throw C<X::…::BadUrl> naming the rule that
#| refused it. Works as a class method (the normal case) and as an instance
#| method (which is how C<resolve> re-validates).
method parse(Str() $input --> ::?CLASS:D) {
	my $raw = ($input // '').trim;
	refuse($input // '', 'it is empty') unless $raw.chars;

	# Anything below U+0021 (space, tab, CR, LF, NUL) or U+007F inside the URL
	# is either a header that was not trimmed or a request-splitting attempt.
	refuse($raw, 'it contains whitespace or a control character')
		if $raw ~~ /<[ \x00 .. \x20 \x7f ]>/;

	my $authority = raw-authority($raw);
	if $raw ~~ /<-[ \x00 .. \x7f ]>/ {
		refuse($raw, 'the host is not ASCII',
			hint => 'Supply an internationalised domain name in its A-label '
				~ "form (the 'xn--…' spelling) — that is what DNS resolves.")
			if $authority.defined && $authority ~~ /<-[ \x00 .. \x7f ]>/;
		refuse($raw, 'it contains non-ASCII characters',
			hint => 'Percent-encode them as UTF-8 (a space is %20, é is %C3%A9).');
	}

	# Scheme first, by hand: Cro's parse failures for 'example.com/x' and
	# 'mailto:me@example.com' are both 'malformed syntax', and the difference
	# is exactly what the caller needs to hear.
	with $raw ~~ /^ $<scheme> = (<[A..Za..z]> <[A..Za..z0..9+.-]>*) ':' / -> $match {
		my Str:D $scheme = (~$match<scheme>).lc;
		unless $scheme eq 'http' | 'https' {
			refuse($raw, "the '$scheme' scheme is not fetchable",
				hint => $scheme eq 'file'
					?? 'These tools speak http and https only; read local files with the filesystem tools.'
					!! 'These tools speak http and https only.');
		}
		refuse($raw, 'it has no host',
			hint => "Write the whole URL, including the '//': '$scheme://example.com/page'.")
			unless $raw.substr($match<scheme>.chars).starts-with('://');
	}
	else {
		refuse($raw, 'it is not an absolute URL',
			hint => "Write the whole URL, including the scheme: 'https://example.com/page'.");
	}

	my $uri = try Cro::Uri.parse($raw);
	without $uri {
		refuse($raw, 'it is not a well-formed URL',
			hint => 'Percent-encode any character that is not allowed in a URL.');
	}

	my Str:D $scheme = $uri.scheme.lc;
	# Cro's own $uri.host-class is not consulted, even where it is populated:
	# it answers 'RegName' for 0x7f000001, 2130706433 and 127.1 alike, which
	# are exactly the spellings that have to be caught. The classification
	# below is ours, and the raw authority — not Cro's percent-decoded host —
	# is what the bracket and encoding checks read.
	my $host = $uri.host;
	refuse($raw, 'it has no host') unless $host.defined && $host.chars;

	# Credentials are refused, never stripped: 'http://docs.example.com@evil.test/'
	# reads as a URL for docs.example.com and fetches evil.test.
	refuse($raw, 'it carries credentials in the URL',
		hint => 'Drop the "user:password@" part; these tools do not send URL credentials.')
		if $uri.userinfo.defined;

	refuse($raw, 'the host is percent-encoded',
		hint => 'Write the host literally — percent sequences in a host name only ever hide it.')
		if $authority.defined && $authority.contains('%');

	my Str  $canonical-host;
	my Bool $literal = False;
	my Int  $version;

	if $authority.defined && $authority.starts-with('[') {
		# Bracketed: an IPv6 literal, or nothing. Cro hands over the inside of
		# the brackets, including for the IPvFuture 'v7.whatever' form, which
		# Addr rightly refuses.
		my $addr = MCP::Server::Tool::Web::Addr.parse($host);
		refuse($raw, "the bracketed host '$host' is not a valid IPv6 literal",
			hint => 'Zone identifiers (%eth0) and IPvFuture forms are not accepted.')
			unless $addr.defined && $addr.version == 6;
		# Canonical RFC 5952 spelling, so [0:0:0:0:0:0:0:1] and [::1] are one
		# origin rather than two.
		$canonical-host = $addr.Str.lc;
		$literal = True;
		$version = 6;
	}
	else {
		$canonical-host = check-name-host($raw, $host);
		my $addr = MCP::Server::Tool::Web::Addr.parse($canonical-host);
		if $addr.defined {
			$literal = True;
			$version = 4;
		}
	}

	my $port = $uri.port;
	if $port.defined {
		refuse($raw, "the port $port is outside the range 1..65535")
			if $port < 1 || $port > 65535;
	}

	my Str:D $path = $uri.path eq '' ?? '/' !! $uri.path;

	::?CLASS.new(
		scheme          => $scheme,
		host            => $canonical-host,
		port            => $port // %DEFAULT-PORT{$scheme},
		path            => $path,
		query           => $uri.query,
		literal-address => $literal,
		address-version => $version,
	);
}

#| Resolve a C<Location> header (or any URI reference) against this URL and
#| validate the result exactly as if it had been passed to C<parse>. The
#| re-validation is the whole point: a redirect is attacker-chosen input.
method resolve(::?CLASS:D: Str() $location --> ::?CLASS:D) {
	my $target = ($location // '').trim;
	X::MCP::Server::Tool::Web::BadUrl.new(
		url    => self.Str,
		reason => 'the redirect gave an empty Location',
		hint   => 'The server sent a redirect with nothing to redirect to.',
	).throw unless $target.chars;

	my $resolved = try Cro::Uri.parse(self.Str).add($target);
	without $resolved {
		refuse($target, "it could not be resolved against '{self.Str}'",
			hint => 'A Location header must be an absolute URL or a valid relative reference.');
	}
	self.parse($resolved.Str);
}

# === Comparison and rendering ===

#| Scheme, host and port, with the scheme's default port left out — the string
#| two URLs must share to be same-origin.
method origin(::?CLASS:D: --> Str:D) {
	$!scheme ~ '://' ~ self.host-in-url ~ (self.default-port ?? '' !! ':' ~ $!port);
}

#| Is this URL on the same origin as another? Scheme, host and B<effective>
#| port, so 'https://x/' and 'https://x:443/' are one origin.
method same-origin(::?CLASS:D: ::?CLASS:D $other --> Bool:D) {
	$!scheme eq $other.scheme && $!host eq $other.host && $!port == $other.port;
}

#| Is the port the default one for the scheme?
method default-port(::?CLASS:D: --> Bool:D) {
	$!port == %DEFAULT-PORT{$!scheme};
}

#| The host as it appears inside a URL: IPv6 literals bracketed, everything
#| else as-is.
method host-in-url(::?CLASS:D: --> Str:D) {
	$!address-version.defined && $!address-version == 6 ?? "[$!host]" !! $!host;
}

#| Path and query only — the request target that goes on the wire.
method target(::?CLASS:D: --> Str:D) {
	$!path ~ ($!query.defined ?? '?' ~ $!query !! '');
}

#| The normalised URL. Round-trips: parsing this string gives an equal URL.
multi method Str(::?CLASS:D: --> Str:D) {
	self.origin ~ self.target;
}

multi method gist(::?CLASS:D: --> Str:D) { self.Str }

# === Internals ===

#| Throw the refusal, naming the rule. One place, so every message reads the
#| same way and every one of them says that no configuration key applies.
my sub refuse(Str:D $url, Str:D $reason, Str :$hint) {
	X::MCP::Server::Tool::Web::BadUrl.new(:$url, :$reason, :$hint).throw;
}

#| The authority as it was B<written> — before Cro decodes percent sequences
#| and drops the brackets. The checks that need the original spelling (is this
#| an IPv6 literal? is anything percent-encoded? is the host non-ASCII?) all
#| read this rather than the parsed host.
my sub raw-authority(Str:D $s --> Str) {
	my $start = $s.index('://');
	return Str without $start;
	my $rest = $s.substr($start + 3);
	my @ends = ($rest.index('/'), $rest.index('?'), $rest.index('#')).grep(*.defined);
	@ends ?? $rest.substr(0, @ends.min) !! $rest;
}

#| Validate a non-bracketed host and return its normalised form. Refuses empty
#| and over-long labels, characters that do not belong in a host name, and
#| every numeric spelling of an address that is not a plain dotted quad.
my sub check-name-host(Str:D $url, Str:D $host --> Str:D) {
	my Str:D $name = $host.lc;
	# One trailing root dot is the same name; two dots are a typo.
	$name = $name.substr(0, *-1) if $name.chars > 1 && $name.ends-with('.');

	refuse($url, 'it has no host') unless $name.chars;
	refuse($url, "the host '$name' is longer than 253 characters") if $name.chars > 253;
	refuse($url, "the host '$name' contains characters that are not valid in a host name",
		hint => 'Host names hold letters, digits, hyphens and dots.')
		unless $name ~~ HOST-CHARS;

	my @labels = $name.split('.');
	refuse($url, "the host '$name' has an empty label",
		hint => 'A host name cannot start with a dot or contain two dots in a row.')
		if @labels.first('').defined;
	refuse($url, "the host '$name' has a label longer than 63 characters")
		if @labels.first(*.chars > 63).defined;

	# --- Numeric obfuscation ---------------------------------------------
	# Every one of these is a legal argument to getaddrinfo and an illegible
	# one to a human. They are refused rather than normalised so that what the
	# tool was asked for and what it fetched are the same string.
	refuse($url, "the host '$name' is written in hexadecimal",
		hint => 'A host like 0x7f000001 is an address in disguise (127.0.0.1); '
			~ 'write the host name, or the address in dotted form.')
		if @labels.first({ $_ ~~ /^ 0 <[xX]> <[0..9a..fA..F]>* $/ }).defined;

	if @labels.all ~~ /^ \d+ $/ {
		refuse($url, "the host '$name' has a component with a leading zero",
			hint => 'A leading zero makes a component octal for the resolver but decimal '
				~ 'to a reader (017700000001 is 127.0.0.1); write it without leading zeros.')
			if @labels.first({ .chars > 1 && .starts-with('0') }).defined;

		refuse($url, "the host '$name' is a bare number",
			hint => 'A number like 2130706433 is an address in disguise (127.0.0.1); '
				~ 'write the host name, or the address in dotted form.')
			if @labels == 1;

		my $addr = MCP::Server::Tool::Web::Addr.parse($name);
		return $name if $addr.defined;    # a plain, canonical dotted quad

		refuse($url, "the host '$name' is a short-form IPv4 address",
			hint => 'A dotted address must have all four octets (127.1 means 127.0.0.1); '
				~ 'write them all.')
			if @labels != 4;

		refuse($url, "the host '$name' is not a valid IPv4 address",
			hint => 'Each of the four octets must be 0..255.');
	}

	$name;
}
