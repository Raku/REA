use Test;

use Cro::HTTP::Client;
use Cro::HTTP::Router;
use Cro::HTTP::Server;
use IO::Socket::Async::SSL;

use MCP::Server::Tool::Web::Addr;
use MCP::Server::Tool::Web::Guard;
use MCP::Server::Tool::Web::SearchProvider;

# Shared fixtures for the web toolkit tests: a local Cro origin with canned
# routes and per-path request counting, the same origin over TLS using the
# distribution's own test certificate, the fake resolver that keeps hostnames
# real while sockets go to loopback, a guard whose idea of an address can be
# rewritten between requests, and the handle-request idiom every tool call is
# driven through.
#
# Deliberately does not `use MCP::Server::Tool::Web`: the self-load test has to
# load the pack dynamically and must not have it pulled in behind its back.
unit module WebTest;

#| How long any single wait may take before it is called a failure rather than
#| a slow machine.
constant TIMEOUT is export = 30;

#| How long /slow sits on its second chunk. Long enough that a one-second
#| budget expires mid-body without making the suite wait for it.
constant SLOW-DELAY is export = 5;

#| The body /big serves, in bytes. Comfortably more than any byte cap a test
#| sets, small enough to stream in a blink.
constant BIG-BYTES is export = 262_144;

#| Two-byte-per-character text, for the cut-mid-character tests.
constant MULTIBYTE-TEXT is export = 'é' x 200;

#| Await $promise, giving up loudly rather than blocking forever.
sub timed($promise, Str:D $what) is export {
	await Promise.anyof($promise, Promise.in(TIMEOUT));
	die "Timed out after {TIMEOUT}s waiting for $what" if $promise.status === Planned;
	$promise;
}

# === Endpoints the canned routes point at ===

my %endpoints;
my Lock $endpoint-lock .= new;

#| Tell the routes where a named origin lives, so that a redirect can name a
#| real second origin: /to-other and /to-http read these. Set after booting,
#| because a port is not knowable before then.
sub set-endpoint(Str:D $name, Str:D $base) is export {
	$endpoint-lock.protect: { %endpoints{$name} = $base };
}

sub endpoint(Str:D $name --> Str:D) {
	$endpoint-lock.protect: { %endpoints{$name} // 'http://unset.test' };
}

# === The origin ===

#| A booted origin: the port it is on, what it has been asked for, and how to
#| stop it. Hostnames are the test's business — the origin only ever listens
#| on loopback.
class Origin {
	has $.server is rw;
	has Int:D $.port is required;
	has Bool:D $.tls = False;
	has %!hits;
	has Lock:D $!lock = Lock.new;

	#| How many times this path has been requested.
	method hits(Str:D $path --> Int:D) {
		$!lock.protect: { %!hits{$path} // 0 }
	}

	#| Every path requested so far, with counts.
	method all-hits(--> Hash:D) {
		$!lock.protect: { %!hits.clone }
	}

	#| Total requests across every path.
	method total-hits(--> Int:D) {
		$!lock.protect: { %!hits.values.sum // 0 }
	}

	method reset-hits(--> Nil) {
		$!lock.protect: { %!hits = () }
	}

	method record(Str:D $path --> Nil) {
		$!lock.protect: { %!hits{$path} = (%!hits{$path} // 0) + 1 }
	}

	#| The origin as a URL, under whatever host name the test wants to use.
	method base(Str:D $host = '127.0.0.1' --> Str:D) {
		($!tls ?? 'https' !! 'http') ~ "://$host:$!port";
	}

	method stop(--> Nil) {
		try $!server.stop;
	}
}

#| The certificate pair shipped in resources/, found whether this module was
#| loaded from an installed distribution or straight out of the checkout.
#| %?RESOURCES resolves against t/lib when the tests run with -It/lib, where
#| there is no META6.json and so no resources at all, hence the fallback.
sub resource-file(Str:D $name --> IO::Path:D) is export {
	my $from-dist = try { %?RESOURCES{$name}.IO };
	return $from-dist if $from-dist ~~ IO::Path:D && $from-dist.e;
	# t/lib/WebTest.rakumod -> t/lib -> t -> the distribution root.
	$?FILE.IO.parent(3).add('resources').add($name);
}

#| Build the canned application. Every route records the path it served, so a
#| test can assert that a crawl stopped early or that robots.txt was fetched
#| exactly once.
my sub canned-app(Origin:D $origin) {
	route {
		# The boot probe: the only honest proof that the listener on the port
		# we picked is ours, since Cro cannot report where :port(0) landed.
		get -> 'ping' {
			$origin.record('/ping');
			content 'text/plain', 'pong';
		}

		get -> 'ok' {
			$origin.record('/ok');
			html-response('<!DOCTYPE html><html><head><title>Ok page</title></head>'
				~ '<body><h1>Ok page</h1><p>Hello from the origin.</p>'
				~ '<a href="/other">another page</a></body></html>',
				'text/html; charset=utf-8');
		}

		get -> 'other' {
			$origin.record('/other');
			html-response('<html><head><title>Other</title></head><body><p>Other page.</p></body></html>',
				'text/html; charset=utf-8');
		}

		# Declared latin-1, and actually latin-1: 'café' is five bytes here.
		get -> 'latin1' {
			$origin.record('/latin1');
			blob-response('<html><head><title>Latin</title></head><body><p>café</p></body></html>'
				.encode('latin-1'), 'text/html; charset=iso-8859-1');
		}

		# UTF-8 bytes with no charset at all — the shape that makes Cro's own
		# body-text answer 'cafÃ©'.
		get -> 'no-charset' {
			$origin.record('/no-charset');
			blob-response('<html><head><title>No charset</title></head><body><p>café</p></body></html>'
				.encode('utf-8'), 'text/html');
		}

		# No charset on the header, one in the document: the document wins.
		get -> 'meta-charset' {
			$origin.record('/meta-charset');
			blob-response(('<html><head><meta charset="iso-8859-1"><title>Meta</title>'
				~ '</head><body><p>café</p></body></html>').encode('latin-1'),
				'text/html');
		}

		# A header that is simply wrong: UTF-8 bytes announced as US-ASCII,
		# which cannot decode them. The fallback chain has to rescue it, and
		# say which encoding actually worked.
		get -> 'lying-charset' {
			$origin.record('/lying-charset');
			blob-response('café au lait'.encode('utf-8'), 'text/plain; charset=us-ascii');
		}

		# A byte-order mark under a header that says something else: evidence
		# against a claim.
		get -> 'bom' {
			$origin.record('/bom');
			blob-response(Buf.new(0xEF, 0xBB, 0xBF) ~ 'café au lait'.encode('utf-8'),
				'text/plain; charset=iso-8859-1');
		}

		# Little-endian UTF-16 with a byte-order mark, built a byte at a time
		# because .encode('utf16') answers 16-bit units rather than octets.
		get -> 'utf16' {
			$origin.record('/utf16');
			my $body = Buf.new(0xFF, 0xFE);
			for 'café au lait'.encode('utf16').list -> $unit {
				$body.push($unit +& 0xFF, $unit +> 8);
			}
			blob-response($body, 'text/plain');
		}

		# Two bytes per character throughout, so a byte cap lands mid-character.
		get -> 'multibyte' {
			$origin.record('/multibyte');
			blob-response(MULTIBYTE-TEXT.encode('utf-8'), 'text/plain; charset=utf-8');
		}

		get -> 'big' {
			$origin.record('/big');
			blob-response(Buf.new(0x78 xx BIG-BYTES), 'text/plain; charset=utf-8');
		}

		# Headers and a first chunk immediately, the rest much later: a body
		# deadline has something to be partial about.
		get -> 'slow' {
			$origin.record('/slow');
			content 'text/plain', supply {
				emit 'partial body '.encode('ascii');
				whenever Promise.in(SLOW-DELAY) {
					emit 'the rest of it'.encode('ascii');
					done;
				}
			};
		}

		get -> 'json' {
			$origin.record('/json');
			blob-response('{"greeting":"café","items":[1,2,3]}'.encode('utf-8'),
				'application/json');
		}

		get -> 'binary' {
			$origin.record('/binary');
			blob-response(Buf.new(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0xFF, 0x00),
				'image/png');
		}

		get -> 'notfound' {
			$origin.record('/notfound');
			response.status = 404;
			blob-response('<html><body>No such page here.</body></html>'.encode('utf-8'),
				'text/html; charset=utf-8');
		}

		get -> 'boom' {
			$origin.record('/boom');
			response.status = 500;
			blob-response('the server fell over'.encode('utf-8'), 'text/plain; charset=utf-8');
		}

		# /r/3 -> /r/2 -> /r/1 -> /r/0 -> /ok, so a test picks its own chain
		# length. Every hop carries a body, which the fetcher must cancel
		# rather than drain.
		get -> 'r', Int $n {
			$origin.record("/r/$n");
			redirect-to($n > 0 ?? "/r/{$n - 1}" !! '/ok');
		}

		get -> 'loop-a' {
			$origin.record('/loop-a');
			redirect-to('/loop-b');
		}

		get -> 'loop-b' {
			$origin.record('/loop-b');
			redirect-to('/loop-a');
		}

		# A relative Location with dot segments, resolved per RFC 3986 §5.
		get -> 'deep', 'rel' {
			$origin.record('/deep/rel');
			redirect-to('../ok');
		}

		# A Location carrying a fragment, which is never sent to a server.
		get -> 'frag' {
			$origin.record('/frag');
			redirect-to('/ok#section-2');
		}

		get -> 'see-other' {
			$origin.record('/see-other');
			redirect-to('/ok', 303);
		}

		# A 3xx with nothing to redirect to is a response, not an error.
		get -> 'no-location' {
			$origin.record('/no-location');
			response.status = 302;
			blob-response('nowhere to go'.encode('utf-8'), 'text/plain; charset=utf-8');
		}

		get -> 'to-private' {
			$origin.record('/to-private');
			redirect-to('http://10.0.0.1/secrets');
		}

		get -> 'to-file' {
			$origin.record('/to-file');
			redirect-to('file:///etc/passwd');
		}

		get -> 'creds' {
			$origin.record('/creds');
			redirect-to('http://user:pw@example.test/ok');
		}

		# Cross-origin, for same-origin rules; and the https -> http downgrade.
		get -> 'to-other' {
			$origin.record('/to-other');
			redirect-to(endpoint('other') ~ '/ok');
		}

		get -> 'to-http' {
			$origin.record('/to-http');
			redirect-to(endpoint('plain') ~ '/ok');
		}

		# A page of links, for the crawl: one on this origin, one on the
		# second origin, one marked nofollow, one no crawler can follow,
		# one repeated, and one that will answer 404. The order is the
		# order a crawl must discover them in.
		get -> 'links' {
			$origin.record('/links');
			html-response('<html><head><title>Links</title></head><body>'
				~ '<a href="/other">other</a>'
				~ '<a href="' ~ endpoint('other') ~ '/ok">elsewhere</a>'
				~ '<a href="/latin1" rel="nofollow">no follow</a>'
				~ '<a href="mailto:nobody@example.test">mail</a>'
				~ '<a href="/other">other again</a>'
				~ '<a href="/notfound">missing</a>'
				~ '</body></html>', 'text/html; charset=utf-8');
		}

		# Links a crawl cannot follow to the end: one that redirects in a
		# circle, one that redirects out of http, and one on a private
		# address (which is not even same-origin, so it is never tried).
		# A crawl reports them and carries on.
		get -> 'badlinks' {
			$origin.record('/badlinks');
			html-response('<html><head><title>Bad links</title></head><body>'
				~ '<a href="/other">other</a>'
				~ '<a href="/loop-a">round in circles</a>'
				~ '<a href="/to-file">off the web</a>'
				~ '<a href="http://10.0.0.1/secrets">private</a>'
				~ '</body></html>', 'text/html; charset=utf-8');
		}

		# Links into the two halves of robots.txt: one disallowed path, one
		# the Allow line rescues, and one ordinary page.
		get -> 'robotslinks' {
			$origin.record('/robotslinks');
			html-response('<html><head><title>Robot links</title></head><body>'
				~ '<a href="/private/secret">secret</a>'
				~ '<a href="/private/public">public</a>'
				~ '<a href="/other">other</a>'
				~ '</body></html>', 'text/html; charset=utf-8');
		}

		# A <base href> that moves relative links out of this directory:
		# without it 'other' would resolve to /deep/other.
		get -> 'deep', 'base' {
			$origin.record('/deep/base');
			html-response('<html><head><title>Based</title><base href="/">'
				~ '</head><body><a href="other">other</a></body></html>',
				'text/html; charset=utf-8');
		}

		# A hub of documents, each with the same two matching lines: what a
		# multi-page grep walks, and what proves it stopped walking.
		get -> 'hub' {
			$origin.record('/hub');
			html-response('<html><head><title>Hub</title></head><body>'
				~ (1 .. 4).map({ '<a href="/doc/' ~ $_ ~ '">doc ' ~ $_ ~ '</a>' }).join
				~ '</body></html>', 'text/html; charset=utf-8');
		}

		get -> 'doc', Int $n {
			$origin.record("/doc/$n");
			html-response('<html><head><title>Doc ' ~ $n ~ '</title></head><body>'
				~ "<p>needle $n first</p><p>filler line</p><p>needle $n second</p>"
				~ '</body></html>', 'text/html; charset=utf-8');
		}

		get -> 'robots.txt' {
			$origin.record('/robots.txt');
			blob-response(("User-agent: *\n"
				~ "Disallow: /private/\n"
				~ "Allow: /private/public\n"
				~ "Crawl-delay: 2\n").encode('utf-8'), 'text/plain');
		}

		get -> 'private', *@rest {
			$origin.record('/private/' ~ @rest.join('/'));
			html-response('<html><head><title>Private</title></head><body>secret</body></html>',
				'text/html; charset=utf-8');
		}

		# What the origin was actually sent: the identity of the caller, the
		# Host it thought it was talking to, and one header a caller may add.
		get -> 'headers' {
			$origin.record('/headers');
			content 'text/plain', join("\n",
				'user-agent: ' ~ (request.header('User-agent') // ''),
				'host: ' ~ (request.header('Host') // ''),
				'x-test: ' ~ (request.header('X-Test') // ''),
			);
		}

		# What the connector actually connected to, as the origin sees it: the
		# local address of this connection is the address the client dialled.
		get -> 'whoami' {
			$origin.record('/whoami');
			content 'text/plain', (try request.connection.socket-host) // 'unknown';
		}
	}
}

#| Send exact bytes with an exact Content-Type. Everything charset-sensitive
#| goes through here: Cro appends '; charset=utf-8' to the content type of a
#| B<Str> body, which is the very thing under test, and leaves a Blob's type
#| exactly as written.
my sub blob-response(Blob:D $body, Str:D $type) {
	content $type, $body;
}

my sub html-response(Str:D $body, Str:D $type) {
	blob-response($body.encode('utf-8'), $type);
}

my sub redirect-to(Str:D $location, Int:D $status = 302) {
	response.status = $status;
	header 'Location', $location;
	# A body on a redirect is normal, and the fetcher has to cancel it rather
	# than read it: an undrained body makes the peer log a write to a closed
	# socket.
	content 'text/plain', "redirecting to $location";
}

#| Is the plain listener on this port ours? GET /ping is the only honest
#| proof, since Cro cannot report where an OS-assigned :port(0) landed.
my sub plain-probe(Int:D $port --> List:D) {
	my $probe = Cro::HTTP::Client.new(:!persistent, :http<1.1>)
		.get("http://127.0.0.1:$port/ping");
	await Promise.anyof($probe, Promise.in(10));
	return (True, '') if $probe.status === Kept;
	(False, $probe.status === Broken
		?? $probe.cause.message.lines.head
		!! 'probe request timed out');
}

#|( The same proof for the TLS listener, made by hand rather than with
    C<Cro::HTTP::Client>. The certificate carries no usable IP entry, so the
    handshake has to name a host the SAN covers while the socket goes to
    loopback — which C<Cro::HTTP::Client> cannot be asked for, and which is
    exactly what the pack's own connector exists to do. Raw HTTP/1.1 over
    C<upgrade-client> keeps the probe independent of the code under test. )
my sub tls-probe(Int:D $port --> List:D) {
	my $answered = Promise.new;
	my $error    = 'TLS probe did not answer';

	my $work = start {
		CATCH {
			default {
				$error = .message.lines.head;
			}
		}
		my $sock = await IO::Socket::Async.connect('127.0.0.1', $port);
		my $ssl  = await IO::Socket::Async::SSL.upgrade-client($sock,
			host => 'localhost', ca-file => resource-file('test-cert.pem').absolute);
		my $seen = Buf.new;
		my $tap = $ssl.Supply(:bin).tap: -> $chunk {
			$seen.append($chunk);
			try $answered.keep(True)
				if ((try $seen.decode('latin-1')) // '').contains('pong');
		};
		await $ssl.write("GET /ping HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n".encode('ascii'));
		await Promise.anyof($answered, Promise.in(10));
		try $tap.close;
		try $ssl.close;
	}

	await Promise.anyof($work, Promise.in(15));
	$answered.status === Kept ?? (True, '') !! (False, $error);
}

#| Boot the canned origin on a random high port, retrying if something else
#| already owns the one we picked. The caller stops it.
sub boot-origin(Bool :$tls = False --> Origin:D) is export {
	my $last-error = 'no attempt made';

	for ^5 {
		my $port = (20000 .. 40000).pick;
		# The Origin exists before the server does, because the routes close
		# over it to record their hits; the server is stitched in afterwards.
		my $origin = Origin.new(:$port, :$tls);
		my %tls-config = $tls
			?? %(
				private-key-file => resource-file('test-key.pem').absolute,
				certificate-file => resource-file('test-cert.pem').absolute,
			)
			!! %();
		my $server = Cro::HTTP::Server.new(
			:host<127.0.0.1>, :$port,
			application => canned-app($origin),
			|(tls => %tls-config if $tls),
		);
		$origin.server = $server;

		my Bool $listening = True;
		{
			CATCH {
				default {
					$last-error = .message.lines.head;
					$listening  = False;
				}
			}
			$server.start;
		}

		if $listening {
			my ($served, $why) = $tls ?? tls-probe($port) !! plain-probe($port);
			if $served {
				$origin.reset-hits;
				return $origin;
			}

			$last-error = $why;
			try $server.stop;
		}
	}

	die "Could not start the fixture origin on any port: $last-error";
}

#| A comparable spelling of an address. The two ends of one loopback
#| connection describe it identically on most platforms and differently on
#| some — Windows reports v4-mapped forms for dual-stack sockets — so
#| addresses are compared through Addr, which unwraps the IPv6 spellings of an
#| IPv4 address. Comparing raw strings would make a passing assertion a
#| platform accident.
sub address-key(Str:D $address --> Str:D) is export {
	my $addr = parse-address($address);
	$addr.defined ?? $addr.unwrap.Str !! $address;
}

# === The network seam ===

#| The fake resolver: hostnames stay real end to end (the origin sees
#| 'Host: example.test', a redirect resolves against example.test, robots.txt
#| is cached per example.test) while the socket goes to loopback on whatever
#| port %ports says. Read live, so a test can rebind a name between requests.
#|
#| Anything not in the map is connected to as written, so a test can mix
#| mapped names with real loopback addresses.
sub fake-resolver(%ports, :@record --> Callable) is export {
	-> Str $host, Int $port {
		@record.push($host) if @record.defined;
		my $target = %ports{"$host:$port"} // %ports{$host};
		$target.defined
			?? IO::Socket::Async.connect('127.0.0.1', $target.Int)
			!! IO::Socket::Async.connect($host, $port);
	}
}

#| A guard whose idea of what a host resolves to can be rewritten between
#| requests, and which records every (host, peer) pair it was actually asked
#| about.
#|
#| The rewrite is the DNS: C<dns> maps a host name to the address the guard is
#| told about, standing in for a resolver that answers differently the second
#| time. The recording is the proof: what the connector passes in is the peer
#| of the socket it is holding, which is why re-resolution cannot help an
#| attacker.
class RebindGuard is MCP::Server::Tool::Web::Guard {
	has %.dns;
	has @.seen;
	has Lock:D $!lock = Lock.new;

	method check-address(Str:D $host, Str:D $peer --> Bool:D) {
		$!lock.protect: { @!seen.push($host => $peer) };
		callwith($host, %!dns{$host} // $peer);
	}

	#| The (host, peer) pairs seen so far, oldest first.
	method recorded(--> List:D) {
		$!lock.protect: { @!seen.List }
	}

	method forget(--> Nil) {
		$!lock.protect: { @!seen = () }
	}
}

# === Tool-surface helpers (shared with the later surface tests) ===

sub call-tool($server, Str:D $name, %arguments --> Hash) is export {
	$server.handle-request({
		jsonrpc => '2.0', id => 1, method => 'tools/call',
		params => { name => $name, arguments => %arguments },
	});
}

sub result-text(%response --> Str) is export {
	%response<result><content>[0]<text> // '';
}

sub result-errored(%response --> Bool:D) is export {
	so %response<result><isError>;
}

sub tool-names($server --> List) is export {
	$server.handle-request({
		jsonrpc => '2.0', id => 99, method => 'tools/list',
	})<result><tools>.map(*<name>).sort.list;
}

#| The advertised schema of one tool, for the tests that pin a tool's
#| parameter set.
sub tool-schema($server, Str:D $name --> Hash) is export {
	my %response = $server.handle-request({
		jsonrpc => '2.0', id => 98, method => 'tools/list',
	});
	my $tool = %response<result><tools>.first({ .<name> eq $name });
	($tool // {}).Hash;
}

#| Assert that a tool call came back as an error result carrying $needle.
sub errors-with($server, Str:D $name, %arguments, Str:D $needle, Str:D $desc) is export {
	my %response = call-tool($server, $name, %arguments);
	my $text     = result-text(%response);
	my $matched  = result-errored(%response) && $text.contains($needle);
	ok $matched, $desc;
	diag "result was: {%response<result>.raku}" unless $matched;
}

#| Assert that &code throws something whose message contains $needle.
sub dies-with(&code, Str:D $needle, Str:D $desc) is export {
	my Str $message;
	{
		code();
		CATCH { default { $message = .message } }
	}
	my $matched = $message.defined && $message.contains($needle);
	ok $matched, $desc;
	diag "message was: {$message // '(nothing thrown)'}" unless $matched;
}

# === A search provider that never touches the network ===

#| The provider the search tests dispatch through. Records its calls, answers
#| canned rows, can be told to fail, and can be given a C<&before> thunk to run
#| first (a sleep, a counter — whatever a test needs to watch a call happen).
#|
#| B<Thread-safe, because web_search is annotated read-only and idempotent>:
#| a host may have several searches in flight on one pack, so the call log is
#| kept under a lock. An Array that has to grow to take an element is not safe
#| to push to from two threads at once.
class FakeProvider does MCP::Server::Tool::Web::SearchProvider {
	has Str:D $.provider-name = 'fake';
	has @.rows = (
		%( title => 'Raku', url => 'https://raku.org/', snippet => 'A sister language of Perl' ),
	);
	has Str $.die-with;

	#| Run at the top of every search, before anything else happens.
	has &.before;

	has Lock $!lock .= new;
	has @!calls;

	method name(--> Str:D) { $!provider-name }

	#| Every search this provider has been asked for, in the order it took
	#| them, as C<< { query, count } >> hashes.
	method calls(--> List:D) { $!lock.protect: { @!calls.map(*.Hash).List } }

	#| How many searches it has answered.
	method searches(--> Int:D) { $!lock.protect: { @!calls.elems } }

	method search(Str:D $query, Int:D $count --> List:D) {
		$!lock.protect: { @!calls.push(%( :$query, :$count )) };
		&!before() if &!before.defined;
		die $!die-with with $!die-with;
		@!rows.head($count).List;
	}
}
