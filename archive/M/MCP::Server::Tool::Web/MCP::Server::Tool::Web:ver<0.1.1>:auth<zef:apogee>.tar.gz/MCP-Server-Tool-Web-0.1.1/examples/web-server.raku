#!/usr/bin/env raku

# A web research server: search, fetch, crawl and grep, against the public
# internet with the SSRF floor at its default (public addresses only).
#
# Run it (from the distribution root):
#   raku -Ilib examples/web-server.raku
#
# Or, without any Raku glue at all, using the raku-mcp command from MCP::Server:
#   raku-mcp --tool=Web='{"crawl-delay":0.5,"max-bytes":4194304}'
#
# Claude Code configuration:
#   { "mcpServers": { "research": {
#       "command": "raku",
#       "args": ["-Ilib", "examples/web-server.raku"],
#       "env": { "BRAVE_API_KEY": "..." } } } }

use MCP::Server;
use MCP::Server::Tool::Web;

my $server = MCP::Server.new(
	:name<research>,
	:version<1.0>,
	:instructions(
		'Search and read the web. web_search looks things up and needs a '
		~ 'BRAVE_API_KEY in the environment; web_fetch, web_crawl and web_grep '
		~ 'work without one. web_fetch reads one page whole; web_crawl indexes '
		~ 'a site without returning its pages; web_grep searches one page, or '
		~ 'a whole site at a depth, and returns only the matching lines. '
		~ 'Prefer web_grep over web_fetch when you already know what you are '
		~ 'looking for — it is far cheaper.'
	),
);

$server.plug: MCP::Server::Tool::Web.new(
	# A page bigger than this, or a crawl that would exceed it in total,
	# comes back cut short and says so.
	max-bytes   => 4 * 1024 * 1024,
	# Be a little more patient than the default with a slow documentation
	# site while crawling or grepping across several pages.
	crawl-delay => 0.5,
);

$server.run;
