=begin pod

=head1 NAME

MCP::Server::Tool::Web - web search, fetch, crawl and grep for MCP::Server

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server;
use MCP::Server::Tool::Web;

my $server = MCP::Server.new(name => 'research');
$server.plug: MCP::Server::Tool::Web.new;      # web_search, web_fetch,
                                               # web_crawl, web_grep
$server.run;

=end code

Configured rather than constructed — the shape a host's JSON config takes:

=begin code :lang<raku>

my $server = MCP::Server.new(
    name  => 'research',
    tools => [
        'Web' => {
            provider       => 'brave',
            'api-key-env'  => 'BRAVE_API_KEY',
            'max-bytes'    => 4 * 1024 * 1024,
            'total-timeout' => 90,
            'crawl-delay'  => 0.5,
            'allow-hosts'  => <wiki.corp docs.corp>,   # exact names only
        },
    ],
);

=end code

What the tools answer with:

=begin code :lang<raku>

# web_search — JSON, so the model can pick a URL out of it
# {"count":10,"provider":"brave","query":"raku grammars",
#  "results":[{"snippet":"…","title":"Grammars","url":"https://docs.raku.org/…"}]}

# web_fetch — plain text, because a page is text
# # Grammars
# Retrieved from https://docs.raku.org/language/grammars
#
# Grammars are a powerful tool used to destructure text …

# web_crawl — an index, not the pages
# Crawled 3 pages from https://docs.example.com/ (depth 1, same origin).
#
# https://docs.example.com/  200  4213 bytes  Documentation
# https://docs.example.com/install  200  2288 bytes  Installing

# web_grep — only the lines that matched, exactly as fs_grep reports them
# https://docs.example.com/install:42:  zef install Foo::Bar
#
# [stopped at 50 matching lines; raise max-results to see more]

=end code

=head1 DESCRIPTION

Four tools, one prefix (C<web>), and one rule that runs under all of them: a
URL the model supplied is fetched only after the address of the socket that was
actually opened has been checked (see L<MCP::Server::Tool::Web::Guard> and
L<MCP::Server::Tool::Web::Transport>), so a hostname that resolves onto this
machine's own network is refused whatever it is spelled like.

=head2 The four tools

=item B<web_search(query, count?)> — the search engine, behind a seam. Answers
      JSON so the model can pick a URL out of it. Zero results is an empty
      list and a notice, not an error.
=item B<web_fetch(url)> — one page, as text: title, the final URL when a
      redirect moved it, then the page with its markup, scripts and navigation
      removed. Exactly one parameter, deliberately: a windowing tool would
      invite the model to page through a document it should have grepped.
=item B<web_crawl(url, depth?, max-pages?)> — an B<index> of a site's pages,
      never their bodies. See below.
=item B<web_grep(pattern, url, regex?, context?, max-results?, depth?,
      max-pages?)> — C<fs_grep> for the web, output format and notices
      included. The cheap tool, and the one to reach for first.

=head2 Why web_crawl returns an index

Concatenating twenty pages into one tool result is a way to spend a context
window without answering anything: what the model actually receives is page one,
half of page two, and a truncation marker. So a crawl reports what is there —
URL, status, size, title, one line each — and the corpus stays reachable
through C<web_grep> (with a C<depth>) and C<web_fetch>.

=head2 robots.txt

Per the pack's ruling: C<web_crawl>, and C<web_grep> with a C<depth> above
zero, respect robots.txt; C<web_fetch> and depth-zero C<web_grep> never consult
it. A page a person asked for by name is not crawling, and no robots.txt has
ever meant "this URL may not be read once, deliberately, on a human's behalf" —
traversal is a different act, and that one is asked for. Setting
C<respect-robots> to C<False> turns it off for the traversing tools too.

Mechanically that is two fetchers over one transport (so they share the vetted,
already-established connections): one holding
L<MCP::Server::Tool::Web::Robots>::C<Off>, one holding C<Respect>. The decision
is per call rather than per pack, which is why it cannot simply be a setting on
one fetcher.

=head2 The search provider is not guard-subject

The endpoint C<web_search> calls is the operator's, named in configuration —
not the model's. A SearXNG on the operator's own LAN is a legitimate thing to
point this at, so the search provider talks to its API directly rather than
through the SSRF guard. The guard exists for URLs an attacker (or a confused
model) chose; a config key is neither.

The API key is resolved B<at call time>, so a pack with no C<BRAVE_API_KEY> in
its environment still serves C<web_fetch>, C<web_crawl> and C<web_grep>
perfectly well, and C<web_search> answers with a message naming the variable
and the two config keys that would fix it.

=head2 Configuration

Every public attribute below is a JSON config key (C<from-config> validates
against exactly this set, so a typo names the valid keys instead of doing
nothing quietly).

=item B<provider>, B<api-key-env>, B<api-key>, B<search-country>,
      B<search-lang>, B<safesearch>, B<timeout> — the search provider.
=item B<max-bytes>, B<total-timeout>, B<connect-timeout>, B<headers-timeout> —
      what one tool call may spend. C<max-bytes> and C<total-timeout> are the
      whole call's: twenty pages of a crawl share them, so a crawl cannot cost
      twenty times a fetch.
=item B<crawl-delay>, B<respect-robots>, B<user-agent> — how the traversing
      tools behave.
=item B<allow-private>, B<allow-loopback>, B<allow-hosts>, B<allow-cidrs>,
      B<proxy> — the SSRF floor's escape hatches, all off by default. See
      L<MCP::Server::Tool::Web::Guard>: C<allow-hosts> is B<exact> matching,
      because suffix matching is where allow-list CVEs come from.

Two more settings exist and are deliberately B<not> config keys, because a
C<Callable> and a live object cannot come out of JSON — they are C<is built>
private attributes, so C<.new> can pass them and C<from-config> cannot:

=item B<search-provider> — anything doing
      L<MCP::Server::Tool::Web::SearchProvider>, used instead of building the
      named C<provider>. This is how a test dispatches C<web_search> without a
      network, and how a host wires up an engine this pack has never heard of.
=item B<fetcher> — a prepared L<MCP::Server::Tool::Web::Fetcher>. Given one,
      the pack uses it for single-page work and clones it (with the robots
      policy swapped in) for traversal, so the transport — and its cache of
      vetted connections — is shared.
=item B<connect-tcp> — the one closure that touches the network,
      C<($host, $port --E<gt> Promise[IO::Socket::Async])>, handed straight to
      L<MCP::Server::Tool::Web::Transport>. Test rigs replace it so that
      hostnames stay real end to end while the sockets go to a local origin;
      replacing it does not weaken the floor, since whatever socket comes back
      still has its peer address checked.

=head1 AUTHOR

Matt Doughty

=head1 COPYRIGHT AND LICENSE

Copyright 2026 Matt Doughty

This library is free software; you can redistribute it and/or modify
it under the Artistic License 2.0.

=end pod

use JSON::Fast;

use MCP::Server::Toolkit;

use MCP::Server::Tool::Web::Crawl;
use MCP::Server::Tool::Web::Extract;
use MCP::Server::Tool::Web::Fetcher;
use MCP::Server::Tool::Web::Guard;
use MCP::Server::Tool::Web::Provider::Brave;
use MCP::Server::Tool::Web::Robots;
use MCP::Server::Tool::Web::SearchProvider;
use MCP::Server::Tool::Web::Transport;

#| Web tools for MCP::Server: search, fetch, crawl and grep, over an SSRF floor
#| that checks the address of every socket before a byte is written to it.
unit class MCP::Server::Tool::Web does MCP::Server::Toolkit;

# === Search ===

#| Which search engine C<web_search> asks. The only name this pack ships an
#| adapter for is 'brave'; anything else is a typo or a distribution that is
#| not installed, and either way it fails at construction rather than on the
#| first search.
has Str:D $.provider = 'brave';

#| The environment variable the provider's API key is read from.
has Str:D $.api-key-env = 'BRAVE_API_KEY';

#| The API key itself, for hosts that hold their secrets somewhere other than
#| the environment. Beats C<api-key-env> when both are set.
has Str $.api-key;

#| Two-letter country code biasing the search ('US', 'GB', ...). The provider's
#| default applies when it is unset.
has Str $.search-country;

#| Language code for the results ('en', 'de', ...).
has Str $.search-lang;

#| Adult-content filtering: 'off', 'moderate' or 'strict'.
has Str:D $.safesearch = 'moderate';

#| Seconds one search request may take before it is given up on. Fetches are
#| bounded by C<connect-timeout>, C<headers-timeout> and C<total-timeout>
#| instead.
has Real:D $.timeout = 15;

# === Fetching ===

#| Body bytes B<one tool call> may retain, across every page it fetches. The
#| page that runs into this cap is cut and says so.
has Int:D $.max-bytes = 2_097_152;

#| Wall-clock seconds for a whole tool call, crawls included.
has Real:D $.total-timeout = 60;

#| Seconds a single connection attempt may take. Clamped down by whatever is
#| left of the call's own budget, never up.
has Real:D $.connect-timeout = 15;

#| Seconds a single response's headers may take, likewise clamped.
has Real:D $.headers-timeout = 30;

#| Seconds left between requests while crawling. A robots.txt C<Crawl-delay>
#| may raise it; nothing lowers it.
has Real:D $.crawl-delay = 0.25;

#| Consult robots.txt when traversing (C<web_crawl>, and C<web_grep> with a
#| depth). Never consulted for a single named page, whatever this says.
has Bool:D $.respect-robots = True;

#| The C<User-agent> every request carries, and the product token robots.txt
#| groups are matched against.
has Str:D $.user-agent = MCP::Server::Tool::Web::Transport::DEFAULT-USER-AGENT;

# === The SSRF floor's escape hatches ===

#| Allow every private range — RFC 1918, CGNAT, link-local, cloud metadata
#| endpoints, the lot.
has Bool:D $.allow-private = False;

#| Allow loopback only (127.0.0.0/8 and ::1), which is what a test rig or a
#| local documentation server needs and nothing more.
has Bool:D $.allow-loopback = False;

#| Exact, lowercase host names that may resolve anywhere. No wildcards and no
#| suffix matching: 'corp' permits the host 'corp' and not 'evil.com.corp'.
has Str:D @.allow-hosts;

#| CIDR blocks that may be connected to, IPv4 and IPv6.
has Str:D @.allow-cidrs;

#| An explicit proxy URL. Without one, C<HTTP_PROXY>/C<HTTPS_PROXY> in the
#| environment are refused rather than silently obeyed — see
#| L<MCP::Server::Tool::Web::Transport>.
has Str $.proxy;

# === Seams (private on purpose: not JSON, so not config keys) ===

#| A ready-made search provider, used instead of building C<provider>.
has $!search-provider is built;

#| A ready-made fetcher. Its transport is shared with the traversing fetcher
#| this pack derives from it.
has $!fetcher is built;

#| The one closure that opens a socket, handed to the Transport.
has &!connect-tcp is built;

# The traversing fetcher: the same transport and guard, with the robots policy
# the ruling asks for. Derived, never configured.
has $!crawl-fetcher;

# The policy object, kept so refusal messages and Pod can describe it.
has $!guard;

my constant KNOWN-PROVIDERS = <brave>;

# Below this a page cannot hold a document, and every fetch would report more
# truncation notice than page.
my constant MIN-MAX-BYTES = 4096;

submethod TWEAK {
	die "web toolkit max-bytes must be at least {MIN-MAX-BYTES}, got $!max-bytes"
		if $!max-bytes < MIN-MAX-BYTES;
	for (total-timeout => $!total-timeout, connect-timeout => $!connect-timeout,
			headers-timeout => $!headers-timeout, timeout => $!timeout) -> $pair {
		die "web toolkit {$pair.key} must be greater than zero, got {$pair.value}"
			unless $pair.value > 0;
	}
	die "web toolkit crawl-delay cannot be negative, got $!crawl-delay"
		if $!crawl-delay < 0;
	die 'web toolkit user-agent must not be empty: robots.txt groups are matched '
		~ 'against its product token, and an origin cannot report who visited it'
		unless $!user-agent.trim.chars;

	$!search-provider //= self!build-provider;
	die "The search-provider must do the MCP::Server::Tool::Web::SearchProvider "
		~ "role; got a {$!search-provider.^name}"
		unless $!search-provider ~~ MCP::Server::Tool::Web::SearchProvider;

	# The guard is built even when a fetcher was injected: it is what the Pod
	# and the tool descriptions describe, and an injected fetcher carries its
	# own anyway.
	$!guard = MCP::Server::Tool::Web::Guard.new(
		allow-private  => $!allow-private,
		allow-loopback => $!allow-loopback,
		allow-hosts    => @!allow-hosts,
		allow-cidrs    => @!allow-cidrs,
	);

	die "The fetcher must be a MCP::Server::Tool::Web::Fetcher; got a "
		~ "{$!fetcher.^name}"
		if $!fetcher.defined && $!fetcher !~~ MCP::Server::Tool::Web::Fetcher;

	$!fetcher //= MCP::Server::Tool::Web::Fetcher.new(
		guard     => $!guard,
		transport => MCP::Server::Tool::Web::Transport.new(
			guard      => $!guard,
			user-agent => $!user-agent,
			|($!proxy.defined ?? (proxy => $!proxy) !! ()),
			|(&!connect-tcp.defined ?? (connect-tcp => &!connect-tcp) !! ()),
		),
		# Robots::Off, the Fetcher's own default: this one serves web_fetch and
		# depth-zero web_grep, neither of which consults robots.txt.
		max-bytes       => $!max-bytes,
		total-seconds   => $!total-timeout,
		connect-timeout => $!connect-timeout,
		headers-timeout => $!headers-timeout,
	);

	# The traversing fetcher shares the transport — and therefore the cache of
	# already-vetted connections — and differs only in its robots policy.
	# Cloned rather than rebuilt so that "same everything except robots" cannot
	# drift into "same except robots and whatever was forgotten".
	my $robots = $!respect-robots
		?? MCP::Server::Tool::Web::Robots::Respect.new(
			# Not called until the first crawl, so naming the fetcher that does
			# not exist yet is safe — see the Robots Pod.
			fetch-robots => -> Str $origin { $!crawl-fetcher.robots-text($origin) },
		)
		!! MCP::Server::Tool::Web::Robots::Off.new;
	$!crawl-fetcher = $!fetcher.clone(:$robots);
}

#| Build the adapter named by C<provider>, passing through the settings that
#| belong to it.
method !build-provider() {
	my $name = $!provider.trim.lc;
	die "Unknown search provider '$!provider'. This distribution ships: "
		~ "{KNOWN-PROVIDERS.join(', ')}. To use another engine, pass an object "
		~ 'doing MCP::Server::Tool::Web::SearchProvider as search-provider.'
		unless KNOWN-PROVIDERS.first($name).defined;

	MCP::Server::Tool::Web::Provider::Brave.new(
		api-key-env => $!api-key-env,
		safesearch  => $!safesearch,
		timeout     => $!timeout,
		|($!api-key.defined       ?? (api-key => $!api-key)         !! ()),
		|($!search-country.defined ?? (country => $!search-country)  !! ()),
		|($!search-lang.defined    ?? (search-lang => $!search-lang) !! ()),
	);
}

method default-prefix(--> Str) { 'web' }

#| The provider C<web_search> dispatches to. Named rather than assumed, so a
#| host can report which engine it ended up with.
method search-provider() { $!search-provider }

#| A one-line summary of which machines this pack may talk to, for notices and
#| startup logs.
method describe-guard(--> Str:D) { $!guard.describe }

# Parameter names are a contract, not a matter of taste: a policy layer in
# front of the server (MCP::Client::Policy) matches calls by them to decide
# what a call would reach, so 'url' must stay 'url' and multi-word parameters
# stay kebab-case.
method register($registrar) {
	$registrar.tool: 'search',
		description => 'Search the web and return the top results as JSON: an '
			~ 'object with the query, the engine that answered, the count that '
			~ 'was asked for, and results — where every result carries title, '
			~ 'url and snippet (and age, when the engine knows how old the page '
			~ 'is). Use it when you do not already know '
			~ 'which page holds the answer, then read the page that looks right '
			~ 'with web_grep (only the matching lines) or web_fetch (the whole '
			~ 'page). Snippets are the engine\'s summary, not the page: never '
			~ 'quote one as fact without reading the page it came from. A query '
			~ 'that matches nothing returns an empty results list and a notice, '
			~ 'not an error.',
		params => {
			query => {
				type        => 'string',
				description => 'What to search for, as you would type it into a '
					~ 'search engine; up to 400 characters',
				required    => True,
			},
			count => {
				type        => 'integer',
				description => 'How many results to return, 1 to 20; defaults to 10',
			},
		},
		handler => -> :%args {
			self!search(
				arg-str(%args, 'query'),
				arg-int(%args, 'count', :default(10), :min(1), :max(20)),
			);
		};

	$registrar.tool: 'fetch',
		description => 'Fetch one web page and return it as readable text: a '
			~ '"# title" line, the final URL when a redirect moved it, then the '
			~ 'page with its markup, scripts, navigation and styling removed. '
			~ 'JSON comes back pretty-printed, plain text and XML verbatim, and '
			~ 'binary formats (images, PDFs, archives) are refused rather than '
			~ 'shown as noise. This returns the whole page, so if you are '
			~ 'looking for something specific, web_grep is much cheaper — use '
			~ 'this when the page itself is the point: an API reference to read '
			~ 'end to end, a short article, a JSON document. Only http and '
			~ 'https URLs can be fetched, redirects are followed, a page bigger '
			~ 'than the server\'s byte cap comes back cut short and says so on '
			~ 'its last line, and URLs on this machine\'s own network are '
			~ 'refused.',
		params => {
			url => {
				type        => 'string',
				description => 'Absolute http or https URL of the page to read, '
					~ 'e.g. "https://docs.example.com/guide"',
				required    => True,
			},
		},
		handler => -> :%args { self!fetch(arg-str(%args, 'url')) };

	$registrar.tool: 'crawl',
		description => 'Follow the links from a page and return an index of what '
			~ 'is there: one line per page giving its URL, HTTP status, size and '
			~ 'title. It does not return the pages themselves — read the ones '
			~ 'that look promising with web_grep (only the matching lines) or '
			~ 'web_fetch (the whole page). Only links on the same origin as the '
			~ 'starting page (same scheme, host and port) are followed, depth '
			~ 'counts hops from that page, and the walk stops at max-pages. If '
			~ 'you are looking for something specific across a documentation '
			~ 'site, web_grep with a depth does the same walk and returns the '
			~ 'matching lines instead, which is much cheaper than crawling and '
			~ 'then fetching. robots.txt is respected, and URLs on this '
			~ 'machine\'s own network are refused.',
		params => {
			url => {
				type        => 'string',
				description => 'Absolute http or https URL to start from',
				required    => True,
			},
			depth => {
				type        => 'integer',
				description => 'How many links deep to follow, 0 to 3; 0 reports '
					~ 'only the starting page, and it defaults to 1',
			},
			'max-pages' => {
				type        => 'integer',
				description => 'Stop after fetching this many pages, counting the '
					~ 'starting page, 1 to 50; defaults to 20',
			},
		},
		handler => -> :%args {
			self!crawl(
				arg-str(%args, 'url'),
				arg-int(%args, 'depth', :default(1), :min(0), :max(3)),
				arg-int(%args, 'max-pages', :default(20), :min(1), :max(50)),
			);
		};

	$registrar.tool: 'grep',
		description => 'Search web pages for lines containing a pattern, reported '
			~ 'as "url:line:text". The pattern is literal text unless regex is '
			~ 'set, in which case it is a Raku regex and not a PCRE one: '
			~ 'classes, quantifiers, alternation and anchors read the same, but '
			~ 'a space is not literal unless quoted and a pattern carrying a '
			~ 'code block is refused. Each page is fetched and reduced to text '
			~ 'first, so the line numbers are that text\'s and not the HTML\'s. '
			~ 'With the default depth of 0 only the URL you give is searched; '
			~ 'with a depth above 0 the same-origin links are followed as '
			~ 'web_crawl does, up to max-pages, and no more pages are fetched '
			~ 'once max-results lines have matched. This is far cheaper than '
			~ 'web_fetch or web_crawl when you know what you are looking for, so '
			~ 'reach for it first and fetch the whole page only when the '
			~ 'surrounding text matters. Pages that are not text are skipped and '
			~ 'counted, and URLs on this machine\'s own network are refused.',
		params => {
			pattern => {
				type        => 'string',
				description => 'Text to search for, or a Raku regex when regex is true',
				required    => True,
			},
			url => {
				type        => 'string',
				description => 'Absolute http or https URL of the page to search, '
					~ 'and the page to crawl from when depth is above 0',
				required    => True,
			},
			regex => {
				type        => 'boolean',
				description => 'Treat pattern as a Raku regex instead of literal '
					~ 'text; defaults to false',
			},
			'context' => {
				type        => 'integer',
				description => 'Lines of surrounding context to show around each '
					~ 'match, 0 to 20; defaults to 0',
			},
			'max-results' => {
				type        => 'integer',
				description => 'Stop after this many matching lines, 1 to 1000; '
					~ 'defaults to 50',
			},
			depth => {
				type        => 'integer',
				description => 'How many links deep to follow from the URL, 0 to '
					~ '3; 0 searches that page alone, which is the default',
			},
			'max-pages' => {
				type        => 'integer',
				description => 'When depth is above 0, stop after fetching this '
					~ 'many pages, 1 to 50; defaults to 20',
			},
		},
		handler => -> :%args {
			self!grep(
				arg-str(%args, 'pattern'),
				arg-str(%args, 'url'),
				arg-bool(%args, 'regex'),
				arg-int(%args, 'context', :default(0), :min(0), :max(20)),
				arg-int(%args, 'max-results', :default(50), :min(1), :max(1000)),
				arg-int(%args, 'depth', :default(0), :min(0), :max(3)),
				arg-int(%args, 'max-pages', :default(20), :min(1), :max(50)),
			);
		};
}

# === Tool bodies ===
#
# Anything that is the caller's fault — an empty query, an unfetchable URL, a
# page that is not text — dies, and MCP::Server turns that into an isError
# result carrying the message. Conditions of the walk itself (a page that could
# not be fetched, a cap that was reached) are reported in the payload's notices,
# because the answer is still worth having.

#| Longest query the search providers accept. Enforced here so the refusal
#| teaches rather than arriving as somebody else's HTTP 422.
my constant MAX-QUERY-CHARS = 400;

method !search(Str:D $raw-query, Int:D $count --> Str:D) {
	my Str:D $query = $raw-query.trim;
	die 'The query must not be empty: web_search needs something to search for.'
		unless $query.chars;
	die "The query is {$query.chars} characters; the limit is {MAX-QUERY-CHARS}. "
		~ 'Search engines match on terms rather than on whole documents, so cut '
		~ 'it down to the words that identify what you want.'
		if $query.chars > MAX-QUERY-CHARS;

	# Whatever a provider throws travels as it is: its first line is written to
	# be the whole answer (a missing key names the environment variable and both
	# config keys that would supply one).
	my @rows = $!search-provider.search($query, $count);

	my %payload =
		query    => $query,
		provider => $!search-provider.name,
		count    => $count,
		results  => @rows.map({ result-row($_) }).List;

	%payload<notice> = "No results for '$query'. The engine matched nothing: try "
		~ 'fewer or more common terms, or drop any quoting.'
		unless @rows;

	to-json(%payload, :!pretty, :sorted-keys);
}

method !fetch(Str:D $url --> Str:D) {
	my $result = $!fetcher.fetch($url);
	die status-message($result) unless $result.ok;

	my $body = text-for($result.text,
		content-type => $result.content-type,
		url          => $result.final-url,
		byte-count   => $result.byte-count);

	my @head;
	my $title = page-title($result);
	@head.push("# $title") if $title.chars;
	# Only when it moved: on every other page the line would be the URL the
	# caller just typed, which teaches nothing and costs a line every time.
	@head.push("Retrieved from {$result.final-url}") if $result.redirected;

	my @out;
	if @head {
		@out.append(@head);
		@out.push('');
	}
	@out.push($body);
	# Only when the pack actually dropped data: a body that simply ended, however
	# close to the cap it came, is the whole page and must not say otherwise.
	# The full page size is unknowable (a chunked body has no Content-Length we
	# trust), so the notice names what was KEPT and why it stopped -- never a
	# total it would have to invent.
	if $result.truncated {
		my Str:D $why = $result.truncated-reason eq 'deadline'
			?? 'the fetch ran out of time'
			!! "the server's byte cap of {$result.byte-count} bytes was reached";
		@out.push("[truncated: kept the first {$body.chars} characters "
			~ "because $why; the rest of the page was not fetched]");
	}
	@out.join("\n");
}

method !crawl(Str:D $url, Int:D $depth, Int:D $max-pages --> Str:D) {
	# web_crawl is traversal however shallow, so it takes the robots-respecting
	# fetcher even at depth 0.
	my $crawl = MCP::Server::Tool::Web::Crawl.new(
		fetcher   => $!crawl-fetcher,
		max-depth => $depth,
		:$max-pages,
		delay     => $!crawl-delay,
	);

	my @index;
	my $report = $crawl.run($url, on-page => -> $page {
		my $title = $page.title;
		@index.push(($page.final-url, $page.status, "{$page.byte-count} bytes",
			|($title.chars ?? ($title,) !! ())).join('  '));
		True;
	});

	my @out = "Crawled {plural($report.fetched, 'page')} from {$report.seed} "
		~ "(depth $depth, same origin only).", '', |@index;

	my @notices = self!crawl-notices($report, $max-pages);
	@out.append('', |@notices) if @notices;
	@out.join("\n");
}

method !grep(Str:D $pattern, Str:D $url, Bool:D $regex, Int:D $context,
		Int:D $max, Int:D $depth, Int:D $max-pages --> Str:D) {
	die 'Pattern must not be empty' if $pattern eq '';

	# Interpolating a caller's string into a real regex is only safe because
	# Rakudo refuses, by default, to interpolate one containing a code block:
	# /<$pattern>/ on `{ unlink "x" }` is an error, not an execution.  NEVER add
	# `use MONKEY-SEE-NO-EVAL` to this file — that pragma exists to turn this
	# exact guard off, and turning it off here turns a search tool into remote
	# code execution.  t/16-grep.rakutest asserts the refusal.
	#
	# It runs before anything is fetched, so a bad pattern costs no requests and
	# the message is about the pattern rather than about some page.
	if $regex {
		my $compiles = try { '' ~~ /<$pattern>/; True };
		die "Invalid regex pattern '$pattern': {error-line($!)}" without $compiles;
	}

	my $crawl = MCP::Server::Tool::Web::Crawl.new(
		fetcher   => $depth > 0 ?? $!crawl-fetcher !! $!fetcher,
		max-depth => $depth,
		:$max-pages,
		delay     => $!crawl-delay,
	);

	my @out;
	my Int:D $matched   = 0;
	my Int:D $skipped   = 0;
	my Int:D $truncated = 0;
	my Str   $seed-status;

	# The scan of one page, lifted out of the callback so it can return early:
	# a `return` inside the pointy block would unwind the crawl rather than the
	# page.
	my sub scan($page --> Nil) {
		$truncated++ if $page.result.truncated;

		my $text = try text-for($page.result.text,
			content-type => $page.result.content-type,
			url          => $page.final-url,
			byte-count   => $page.result.byte-count);
		without $text {
			$skipped++;
			return;
		}

		my @lines = $text.lines;
		my @hits  = (^@lines).grep({
			$regex ?? so(@lines[$_] ~~ /<$pattern>/) !! @lines[$_].contains($pattern)
		});
		return unless @hits;

		my @taken = @hits.head($max - $matched);
		$matched += @taken.elems;

		# Context turns each hit into a window; overlapping windows merge, and
		# a gap between them prints GNU grep's '--' separator.
		my @hit is default(False);
		my @show is default(False);
		for @taken -> $i {
			@hit[$i] = True;
			@show[$_] = True for max(0, $i - $context) .. min(@lines.end, $i + $context);
		}

		my Int:D $previous = -2;   # far enough back that the first line is never contiguous
		my Str:D $display = $page.final-url;
		for ^@lines -> $i {
			next unless @show[$i];
			@out.push('--') if $context > 0 && @out.elems && $i != $previous + 1;
			my Str:D $sep = @hit[$i] ?? ':' !! '-';
			@out.push($display ~ $sep ~ ($i + 1) ~ $sep ~ @lines[$i]);
			$previous = $i;
		}
	}

	my $report = $crawl.run($url, on-page => -> $page {
		$seed-status = "{$page.final-url} answered HTTP {$page.status}"
			if $page.depth == 0 && !$page.result.ok;
		scan($page);
		# Checked between pages: once the budget is spent nothing more is
		# fetched, which is the whole reason grep is cheaper than crawl.
		$matched < $max;
	});

	my @notices;
	if $matched >= $max {
		my Str:D $lines = $max == 1 ?? 'line' !! 'lines';
		@notices.push: "[stopped at $max matching $lines; raise max-results to see more]";
	}
	if $skipped {
		my Str:D $pages = $skipped == 1 ?? 'page that is not' !! 'pages that are not';
		@notices.push: "[skipped $skipped $pages text]";
	}
	if $truncated {
		my Str:D $pages = $truncated == 1 ?? 'page was' !! 'pages were';
		@notices.push: "[$truncated $pages cut short at the server's byte cap and "
			~ 'searched only as far as it was read]';
	}
	@notices.push: "[$seed-status; what was searched is the server's error page]"
		with $seed-status;
	@notices.append(self!crawl-notices($report, $max-pages, :quiet-cap($matched >= $max)));

	return ("No matches for '$pattern' under '$url'", |@notices).join("\n")
		unless @out.elems;
	(|@out, |(@notices.elems ?? ('', |@notices) !! ())).join("\n");
}

#| The notices a crawl report earns, shared by web_crawl and web_grep so the
#| two never disagree about what happened. :quiet-cap suppresses the page-cap
#| notice for a grep that stopped because it had found enough, where "raise
#| max-pages" would be advice about the wrong limit.
method !crawl-notices($report, Int:D $max-pages, Bool:D :$quiet-cap = False --> List:D) {
	my @notices;

	if $report.robots-skipped {
		@notices.push: "[{plural($report.robots-skipped.elems, 'page')} skipped by "
			~ 'robots.txt; set respect-robots false in the server config to read them]';
	}

	if $report.failures -> @failed {
		# Three, and the first sentence of each: a refusal explains itself at
		# length, which is right when it is the whole answer and wrong when it
		# is a footnote to twenty pages that did work.
		@notices.push: "[{plural(@failed.elems, 'page')} could not be fetched: "
			~ @failed.head(3).map({ "{.<url>} ({clip(.<reason>)})" }).join('; ')
			~ (@failed.elems > 3 ?? "; and {@failed.elems - 3} more]" !! ']');
	}

	given $report.stopped {
		when 'max-pages' {
			@notices.push: "[stopped after $max-pages pages; raise max-pages to go further]"
				unless $quiet-cap;
		}
		when 'deadline' {
			@notices.push: "[stopped after {$!total-timeout} seconds; raise "
				~ 'total-timeout in the server config, or crawl a smaller depth]';
		}
		when 'max-bytes' {
			@notices.push: "[stopped after {$!max-bytes} bytes; raise max-bytes in "
				~ 'the server config, or crawl a smaller depth]';
		}
	}

	@notices.List;
}

# === Helpers ===

#| One search result, normalised to the three keys every provider promises
#| plus the one it may not have. Coerced rather than trusted: a provider is a
#| plug-in, and a missing snippet must not become a JSON null the model has to
#| reason about.
my sub result-row($row --> Hash:D) {
	my %out =
		title   => ($row<title>   // '').Str,
		url     => ($row<url>     // '').Str,
		snippet => ($row<snippet> // '').Str;
	%out<age> = $row<age>.Str if ($row<age>:exists) && $row<age>.defined;
	%out;
}

#| The page's title, for pages that have one. Only asked of HTML: running the
#| tokenizer over a 200 KB JSON document to learn it has no C<E<lt>titleE<gt>>
#| is a pass nobody needs.
my sub page-title($result --> Str:D) {
	my $type = $result.content-type;
	return '' without $type;
	return '' unless $type eq 'text/html' | 'application/xhtml+xml' | 'application/html';
	extract-title($result.text);
}

#| What to say about a page the server would not give us. The status is the
#| answer, so the message names it and says what would be worth trying next.
my sub status-message($result --> Str:D) {
	my $status = $result.status;
	my $url    = $result.final-url;

	my $detail = do given $status {
		when 404 | 410 {
			'There is no page at that URL. Check the address for a typo, try the '
				~ "site's own index, or find the page with web_search.";
		}
		when 401 | 403 {
			'The page exists but is not public: it wants credentials these tools '
				~ 'do not have. Look for a public mirror or the documentation the '
				~ 'site publishes without a login.';
		}
		when 429 {
			'The server is rate-limiting these requests. Wait before asking it for '
				~ 'anything else, and crawl with a larger crawl-delay.';
		}
		when 400 .. 499 {
			'The server rejected the request for that URL.';
		}
		when 500 .. 599 {
			"That is a fault at the server's end rather than a problem with the "
				~ 'URL; the same request may work later.';
		}
		default {
			'The server answered with a status that carries no page: a redirect '
				~ 'without a destination, or an informational status.';
		}
	}

	"Fetching $url returned HTTP $status. $detail";
}

#| The first sentence of a refusal, or its first 160 characters — whichever
#| comes first. Enough to tell one kind of failure from another; a caller who
#| needs the whole message can fetch the page on its own and read it.
my sub clip(Str:D $reason, Int:D $limit = 160 --> Str:D) {
	my $text = $reason.trim;
	with $text.index('. ') -> $stop {
		$text = $text.substr(0, $stop + 1) if $stop + 1 < $limit;
	}
	$text.chars > $limit ?? $text.substr(0, $limit).trim ~ '…' !! $text;
}

#| 'one page' / '3 pages', for notices that count things.
my sub plural(Int:D $n, Str:D $noun --> Str:D) {
	"$n $noun" ~ ($n == 1 ?? '' !! 's');
}

my sub error-line(Mu $error --> Str:D) {
	($error.defined ?? ($error.message // '').lines.head !! Str) // 'unknown error';
}

# === Argument coercion ===
#
# Copied from MCP::Server::Tool::FileSystem, deliberately unchanged: the two
# packs advertise the same kinds of parameter and a model that has learned one
# tool's error messages should recognise the other's. Out-of-range values die
# naming the bound rather than being clamped — a silently clamped max-results
# looks to the caller like a page with fewer matches than it has.

#| Fetch a string argument.  Handlers validate their own arguments: the MCP
#| input schema advertises what is required but nothing enforces it, and a
#| client that omits a URL deserves a clearer answer than a type error.
my sub arg-str(%args, Str:D $name, Str :$default --> Str:D) {
	my $value = %args{$name};
	unless $value.defined {
		die "Missing required parameter '$name'" without $default;
		return $default;
	}
	die "Parameter '$name' must be a string, not {$value.^name}"
		if $value ~~ Positional | Associative;
	$value.Str;
}

#| Fetch a whole-number argument, optionally bounded.  Without :default it is
#| required unless :optional is passed, in which case an absent argument comes
#| back as an undefined Int.  Booleans are refused explicitly: Bool does Int in
#| Raku, so a client sending `true` for a page count would otherwise be silently
#| read as the number 1.  A string of digits is accepted because models produce
#| them constantly and the intent is never in doubt.
my sub arg-int(%args, Str:D $name, Int :$default, Bool :$optional, Int :$min, Int :$max --> Int) {
	my $value = %args{$name};
	unless $value.defined {
		return $default if $default.defined;
		return Int if $optional;
		die "Missing required parameter '$name'";
	}

	die "Parameter '$name' must be a whole number, not a boolean" if $value ~~ Bool;
	my Int $int = do given $value {
		when Int          { $_ }
		when Str          { $_ ~~ /^ '-'? \d+ $/ ?? .Int !! Int }
		default           { Int }
	};
	die "Parameter '$name' must be a whole number, not {$value.^name}" without $int;

	die "Parameter '$name' must be at least $min, not $int" if $min.defined && $int < $min;
	die "Parameter '$name' must be at most $max, not $int"  if $max.defined && $int > $max;
	$int;
}

#| Fetch a flag argument.  JSON booleans arrive as Bool; the words spelled as
#| strings are accepted too, since a model that quotes `"true"` means it.
my sub arg-bool(%args, Str:D $name, Bool:D :$default = False --> Bool:D) {
	my $value = %args{$name};
	return $default without $value;
	return $value.so if $value ~~ Bool;
	if $value ~~ Str {
		return True  if $value.lc eq 'true';
		return False if $value.lc eq 'false';
	}
	die "Parameter '$name' must be true or false, not {$value.^name}";
}
