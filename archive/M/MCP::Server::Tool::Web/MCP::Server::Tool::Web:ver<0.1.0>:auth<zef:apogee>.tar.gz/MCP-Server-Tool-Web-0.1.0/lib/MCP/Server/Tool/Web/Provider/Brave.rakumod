=begin pod

=head1 NAME

MCP::Server::Tool::Web::Provider::Brave - Brave Search adapter for C<web_search>

=head1 SYNOPSIS

=begin code :lang<raku>

use MCP::Server::Tool::Web::Provider::Brave;

# BRAVE_API_KEY set in the environment:
my $brave = MCP::Server::Tool::Web::Provider::Brave.new;
my @rows = $brave.search('raku json::fast api', 5);
# @rows[0]<title> / <url> / <snippet> / <age>?

# Or explicit, e.g. a key vaulted under a different name, or a
# self-hosted Brave-compatible proxy:
my $brave2 = MCP::Server::Tool::Web::Provider::Brave.new(
    api-key     => $vault.fetch('brave-search'),
    api-url     => 'https://search.internal.example.com/res/v1/web/search',
    country     => 'GB',
    search-lang => 'en',
);

=end code

=head1 DESCRIPTION

Default L<MCP::Server::Tool::Web::SearchProvider> implementation,
talking to the Brave Search API's C<web/search> endpoint. This is what
C<MCP::Server::Tool::Web>'s C<web_search> tool uses unless a different
C<provider> is configured or an alternative
L<MCP::Server::Tool::Web::SearchProvider> is injected for testing.

=head1 KEY RESOLUTION

The API key is resolved B<at call time>, inside C<.search>, never at
construction. This matters: a C<MCP::Server::Tool::Web> instance with
no key configured anywhere must still construct and register all four
C<web_*> tools — C<web_fetch>, C<web_crawl> and C<web_grep> don't need
a search key at all, and only C<web_search> should fail, with a
teaching message, the moment it's actually called without one.

Resolution order, first match wins:

=item1 C<$.api-key> — used verbatim when set to a non-empty string.
=item1 C<%*ENV{$.api-key-env}> — C<$.api-key-env> defaults to
  C<'BRAVE_API_KEY'> but names whatever environment variable the
  operator points it at; used when non-empty.
=item1 Neither is set (or both are empty) — C<.search> dies with a
  message naming the environment variable actually in play (i.e. the
  current value of C<$.api-key-env>, not always the literal string
  C<"BRAVE_API_KEY">) and both config keys that would supply it.

=head1 SSRF GUARD — DELIBERATELY NOT APPLIED HERE

B<This provider does NOT go through the pack's SSRF C<Guard>.> That
guard exists to stop a model-supplied URL (from C<web_fetch> /
C<web_crawl> / C<web_grep>) from being used to probe the operator's
own network — the URL in those cases comes from untrusted model
output. C<$.api-url> here is the opposite: it is set once, by
whoever deploys C<MCP::Server::Tool::Web>, in the same config that
also chooses the provider class. Refusing loopback/private addresses
on it would break the entirely legitimate case of a self-hosted
search backend (a SearXNG instance, an internal Brave-compatible
proxy, ...) running on the operator's own LAN or even C<localhost>.
If C<$.api-url> is ever made settable from an untrusted source, THAT
call site is responsible for guarding it — this class intentionally
does not.

=head1 REQUEST SHAPE

C<GET $.api-url> with query parameters C<q> (the query), C<count>,
C<safesearch>, and C<country> / C<search_lang> only when those
attributes are set. Headers: C<X-Subscription-Token> (the resolved
key), C<Accept: application/json>, and C<Cache-Control: no-cache> —
the last of these is not cosmetic: Brave has been observed in the
field to answer a request that omits it with a C<422> that has
nothing to do with the query, so it is sent on every call.
C<Accept-Encoding: gzip> is deliberately I<not> sent: Cro's
C<body-blob> does not decompress a gzipped response unless the
optional C<Compress::Zlib> module happens to be installed, and this
class hand-decodes C<body-blob> itself (see C<!blob-text> below) — an
environment-dependent decompression step is not something this dist
can rely on, so the request stays identity-encoded and Brave answers
in kind.

=head1 ERRORS

Every failure mode C<.search> can hit is turned into a C<die> with a
teaching first line, per the L<MCP::Server::Tool::Web::SearchProvider>
contract:

=item C<401> / C<403> — names the environment variable / config key
  the key was actually read from.
=item C<422> — "Brave refused the request as invalid", Brave's own
  error message when the body carries one, and a reminder of the
  400-character / 50-word query limit (the most common cause).
=item C<429> — "Brave rate-limited this search", the
  C<X-RateLimit-Reset> seconds when Brave sent that header, and a note
  that only successful requests count against quota (so retrying
  after the reset is safe).
=item Other 5xx — described as transient; safe to retry.
=item Timeout — names the seconds waited and the C<timeout> config
  key that controls it.
=item Connection failure (refused, reset, DNS, ...) — names the host
  and a one-line cause.
=item An unparseable (non-JSON) response body — quotes its first 200
  characters, which is usually enough to recognise a captive portal
  or an HTML error page from an intermediary proxy.
=item A gzip-compressed response body (the gzip magic bytes C<1f 8b>
  at the start of C<body-blob>) — this client cannot decompress it
  (see REQUEST SHAPE above on why C<Accept-Encoding: gzip> is never
  sent) and dies with a diagnostic that says so plainly, rather than
  feeding a latin-1 mangling of the compressed bytes to C<from-json>
  and reporting a confusing "not JSON" error instead.

=head1 AUTHOR

Matt Doughty

=head1 COPYRIGHT AND LICENSE

Copyright 2026 Matt Doughty

This library is free software; you can redistribute it and/or modify
it under the Artistic License 2.0.

=end pod

use Cro::HTTP::Client;
use Cro::Uri;
use JSON::Fast;

use MCP::Server::Tool::Web::SearchProvider;

unit class MCP::Server::Tool::Web::Provider::Brave does MCP::Server::Tool::Web::SearchProvider;

has Str:D  $.api-url     = 'https://api.search.brave.com/res/v1/web/search';
has Str:D  $.api-key-env = 'BRAVE_API_KEY';
has Str    $.api-key;
has Real:D $.timeout     = 15;
has Str    $.country;
has Str    $.search-lang;
has Str:D  $.safesearch  = 'moderate';

#| Injectable Cro::HTTP::Client for tests. Left unset in normal use —
#| built lazily by C<!client> the first time C<.search> is called, so
#| constructing this provider (and therefore the whole toolkit, keyless
#| or not) never opens a connection.
has $!client is built;

method name(--> Str:D) { 'brave' }

#| The API key, resolved AT CALL TIME rather than in TWEAK — see the
#| KEY RESOLUTION section of the Pod. Dies with a teaching message
#| naming the environment variable actually consulted (whatever
#| C<$.api-key-env> is currently set to) when neither source has one.
method !resolve-key(--> Str:D) {
	return $!api-key if $!api-key.defined && $!api-key.chars;

	my $from-env = %*ENV{$!api-key-env} // '';
	return $from-env if $from-env.chars;

	die "web_search needs a Brave Search API key. Set the environment "
		~ "variable $!api-key-env, or point \"api-key-env\" at the "
		~ 'variable that holds it, or put an "api-key" in the web config.';
}

#| The client used for the actual HTTP call: whatever was injected at
#| construction (tests), else a lazily-built default.
method !client(--> Cro::HTTP::Client:D) {
	return $!client if $!client.defined;

	$!client = Cro::HTTP::Client.new(
		# Pin HTTP/1.1. Cro defaults to ALPN-negotiated HTTP version for
		# HTTPS, which lets it pick HTTP/2 against gateways that
		# advertise it — and Cro's HTTP/2 client has been seen to hang
		# silently waiting for headers against some upstream-routed
		# providers, surfacing only as a slow X::Cro::HTTP::Client::Timeout.
		# See LLM::Chat::Backend::OpenAICommon's chat-completion for the
		# same fix against the same class of gateway.
		:http<1.1>,
		timeout => %(
			connection => min(10, $!timeout),
			headers    => $!timeout,
			body       => Inf,
			total      => $!timeout,
		),
	);
}

#|( Decode response bytes as text ourselves rather than letting Cro do
    it. Cro's C<body-text> asks C<body-text-encoding> for an encoding
    and, when the Content-Type names no charset, that returns the LIST
    C<('utf-8', 'latin-1')> — C<body-text> then loops it with no
    C<last>, so the latin-1 attempt, which cannot fail whatever the
    bytes are, always overwrites a successful utf-8 decode. Brave's
    JSON is UTF-8 by definition (RFC 8259 §8.1) and search results are
    full of non-ASCII titles and snippets, so this class never calls
    C<body-text> / C<body> / C<body-json> — see
    C<LLM::Chat::Backend::OpenAICommon._blob-text> for the original
    diagnosis of this Cro behaviour. )
method !blob-text($blob --> Str:D) {
	return '' unless $blob ~~ Blob:D;

	if $blob.elems >= 2 && $blob[0] == 0x1f && $blob[1] == 0x8b {
		die 'Brave sent a gzip-compressed body; this client cannot '
			~ 'decompress it. The Accept-Encoding header should not have '
			~ 'been sent — or a proxy in front of Brave is forcing '
			~ 'compression regardless.';
	}

	(try $blob.decode('utf-8')) // (try $blob.decode('latin-1')) // '';
}

#| Pull whatever error message Brave's JSON error body carries, or the
#| first 200 characters of the raw body when it isn't JSON / carries
#| none. Never throws.
method !error-detail(Str:D $body --> Str:D) {
	return '' unless $body.chars;

	my $parsed = try from-json($body);
	return $body.substr(0, 200) unless $parsed ~~ Associative;

	my $msg = $parsed<message>
		// ($parsed<error> ~~ Associative ?? $parsed<error><message> !! Nil)
		// ($parsed<error> ~~ Str:D ?? $parsed<error> !! Nil);

	($msg // $body.substr(0, 200)).Str;
}

#| Turn a caught X::Cro::HTTP::Error::Client into a teaching C<die>.
#| Called from inside a CATCH block, so the C<die> here propagates
#| past the C<try> that caught the original exception rather than
#| being re-caught by it.
method !die-client-error($exn --> Nil) {
	my $status = (try $exn.response.status.Int) // 0;
	my $body   = (try self!blob-text(await $exn.response.body-blob)) // '';

	given $status {
		when 401 | 403 {
			die "Brave rejected the API key (HTTP $status). Check the "
				~ "value behind the \"$!api-key-env\" environment "
				~ 'variable (or the "api-key" config key), and that '
				~ 'the key is still active in the Brave dashboard.';
		}
		when 422 {
			my $detail = self!error-detail($body);
			die 'Brave refused the request as invalid (HTTP 422)'
				~ ($detail.chars ?? ": $detail" !! '.')
				~ ' Brave search queries are capped at 400 characters '
				~ 'and 50 words — shorten the query and try again.';
		}
		when 429 {
			my $reset = try $exn.response.header('X-RateLimit-Reset');
			die 'Brave rate-limited this search (HTTP 429)'
				~ ($reset.defined && $reset.chars
					?? ", resetting in {$reset}s"
					!! '')
				~ '. Only successful requests count against quota, so '
				~ 'retrying after the reset is safe.';
		}
		default {
			my $detail = self!error-detail($body);
			die "Brave rejected the search (HTTP $status)"
				~ ($detail.chars ?? ": $detail" !! '.');
		}
	}
}

method search(Str:D $query, Int:D $count --> List:D) {
	my Str:D $key = self!resolve-key;

	my %query = q => $query, count => $count, safesearch => $!safesearch;
	%query<country>     = $!country     with $!country;
	%query<search_lang> = $!search-lang with $!search-lang;

	my $resp;
	try {
		$resp = await self!client.get:
			$!api-url,
			query   => %query,
			headers => %(
				'X-Subscription-Token' => $key,
				'Accept'                => 'application/json',
				# No Accept-Encoding here — see the REQUEST SHAPE section of
				# the Pod: Cro's body-blob does not decompress gzip (that
				# needs the optional Compress::Zlib) and this class hand-
				# decodes the blob, so sending it makes Brave answer
				# compressed and !blob-text cannot cope.
				# Not optional — see the REQUEST SHAPE section of the Pod.
				'Cache-Control'         => 'no-cache',
			);

		CATCH {
			when X::Cro::HTTP::Error::Client {
				self!die-client-error($_);
			}
			when X::Cro::HTTP::Error::Server {
				my $status = (try .response.status.Int) // 0;
				die "Brave Search is having a transient problem "
					~ "(HTTP $status); this is not something the query "
					~ 'caused — retry the search in a moment.';
			}
			when X::Cro::HTTP::Client::Timeout {
				die "Brave Search did not respond within {$!timeout}s. "
					~ 'Raise the web config\'s "timeout" key if this '
					~ 'keeps happening.';
			}
			default {
				my $host = (try Cro::Uri.parse($!api-url).host) // $!api-url;
				my $cause = (.message // 'connection failed').lines.head;
				die "Could not reach Brave Search at $host: $cause";
			}
		}
	}

	my Str:D $text = self!blob-text(try await $resp.body-blob);

	my %data;
	try {
		%data = from-json($text);
		CATCH {
			default {
				die "Brave's response was not JSON: "
					~ $text.substr(0, 200);
			}
		}
	}

	# Brave answers some queries (news-only, video-only, ...) with no
	# "web" key at all rather than an empty results array under it —
	# that is a legitimate zero-web-results answer, not a malformed one.
	my @rows;
	with %data<web> {
		for (.<results> // []).List -> %r {
			my %row = (
				title   => (%r<title> // '').Str,
				url     => (%r<url> // '').Str,
				snippet => (%r<description> // '').Str,
			);
			%row<age> = %r<age>.Str if %r<age>:exists && %r<age>.defined;
			@rows.push: %row;
		}
	}

	@rows.List;
}
