% MUGS Announcements

*Reviewed 2021-05-19 by japhb*


# Release Announcements


## 0.1.x Series

* [0.1.2](v0.1.2.md) -- JSON → CBOR transition, better performance, docs, bug fixes
* [0.1.1](v0.1.1.md) -- Broad low-level infrastructure improvements
* [0.1.0](v0.1.0.md) -- Initial public release
