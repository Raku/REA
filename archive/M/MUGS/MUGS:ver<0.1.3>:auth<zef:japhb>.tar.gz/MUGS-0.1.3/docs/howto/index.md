% MUGS How-To Guides

*Reviewed 2021-05-19 by japhb*


# For Users

* [Install MUGS](install-mugs.md)


# For Developers

* [Create a UI](create-a-ui.md)
* [Port a Game](port-a-game.md)


# For Maintainers

* [Release Guide](release-guide.md)
