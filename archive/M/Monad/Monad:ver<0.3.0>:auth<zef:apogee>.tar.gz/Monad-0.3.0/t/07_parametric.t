use Test;
use lib 'lib';

use Monad::Maybe;
use Monad::Either;
use Monad::List;
use Monad::Writer;

plan 25;

# --- Maybe[T] ---

subtest "Maybe[Int] accepts Int" => {
    plan 3;
    my $a = Monad::Maybe[Int].some(42);
    isa-ok $a, Monad::Maybe, 'still a Maybe';
    is $a.value, 42, 'value preserved';
    is $a.value.WHAT.^name, 'Int', 'value typed as Int';
};

subtest "Maybe[Int] rejects Str" => {
    plan 1;
    my $caught = False;
    try {
        Monad::Maybe[Int].some('not an int');
        CATCH { default { $caught = True } }
    };
    ok $caught, 'type mismatch throws';
};

subtest "Maybe[Int].none is still a None" => {
    plan 2;
    my $n = Monad::Maybe[Int].none;
    ok $n.is-none, 'is-none';
    nok $n.is-some, 'not is-some';
};

subtest "Legacy Maybe (no brackets) still works" => {
    plan 3;
    my $m = Monad::Maybe.some('hello');
    isa-ok $m, Monad::Maybe, 'is a Maybe';
    is $m.value, 'hello', 'value preserved';
    ok $m.is-some, 'is-some';
};

# --- Either[L, R] ---

subtest "Either[Str, Int] accepts both variants" => {
    plan 4;
    my $r = Monad::Either[Str, Int].right(42);
    my $l = Monad::Either[Str, Int].left('error!');
    is $r.unwrap-right, 42, 'right unwraps to Int';
    is $l.unwrap-left, 'error!', 'left unwraps to Str';
    ok $r.is-right, 'right is-right';
    ok $l.is-left, 'left is-left';
};

subtest "Either[Str, Int] rejects wrong types" => {
    plan 2;
    my $r-bad = False;
    try {
        Monad::Either[Str, Int].right('not an int');
        CATCH { default { $r-bad = True } }
    };
    ok $r-bad, 'right with Str rejected';

    my $l-bad = False;
    try {
        Monad::Either[Str, Int].left(123);
        CATCH { default { $l-bad = True } }
    };
    ok $l-bad, 'left with Int rejected';
};

# --- List[T] ---

subtest "List[Int] values are typed" => {
    plan 2;
    my $lst = Monad::List[Int].of(1, 2, 3);
    isa-ok $lst, Monad::List, 'is a List';
    is $lst.values.WHAT.^name, 'Array[Int]', 'values are Array[Int]';
};

subtest "List[Int] rejects non-ints" => {
    plan 1;
    my $caught = False;
    try {
        Monad::List[Int].of(1, 'two', 3);
        CATCH { default { $caught = True } }
    };
    ok $caught, 'mixed-type list rejected';
};

# --- Writer[A, W] ---

subtest "Writer[Int, Str] typed value and log" => {
    plan 2;
    my $w = Monad::Writer[Int, Str].unit(42);
    is $w.value, 42, 'value preserved';
    is $w.logs, '', 'default log is empty';
};

subtest "Writer[Int, Str] rejects wrong value type" => {
    plan 1;
    my $caught = False;
    try {
        Monad::Writer[Int, Str].unit('not an int');
        CATCH { default { $caught = True } }
    };
    ok $caught, 'Str value on Writer[Int,Str] rejected';
};

# --- Interop / bind across typed monads ---

subtest "Maybe[Int] bind preserves type" => {
    plan 2;
    my $a = Monad::Maybe[Int].some(10);
    my $b = $a.bind(-> $v { Monad::Maybe[Int].some($v * 2) });
    ok $b.is-some, 'bound value is Some';
    is $b.value, 20, 'bind computed correctly';
};

subtest "~~ works against bare role name" => {
    plan 2;
    my $a = Monad::Maybe[Int].some(1);
    ok $a ~~ Monad::Maybe, 'typed Maybe smart-matches base Maybe';
    ok $a ~~ Monad, 'also smart-matches Monad';
};

# --- Unparameterized (legacy) defaults to Any ---

subtest "Legacy bare Maybe allows any type" => {
    plan 3;
    my $a = Monad::Maybe.some(42);
    my $b = Monad::Maybe.some('hi');
    my $c = Monad::Maybe.some([1, 2, 3]);
    is $a.value, 42,      'Int allowed';
    is $b.value, 'hi',    'Str allowed';
    is-deeply $c.value, [1, 2, 3], 'Array allowed';
};

# --- Edge case: Nil handling with typed Maybe ---

subtest "Maybe[Int].none.unwrap dies" => {
    plan 2;
    my $n = Monad::Maybe[Int].none;
    throws-like { $n.unwrap }, X::AdHoc, message => /'Cannot unwrap a None'/,
        'unwrap of a typed None dies (0.2 returned Nil)';
    nok $n.value.defined, 'the raw .value accessor is still undefined';
};

subtest "Maybe[Int] normalises an undefined payload to its type object" => {
    plan 3;
    my $s = Monad::Maybe[Int].some(Nil);
    ok $s.is-some, 'Some(Nil) on a typed Maybe is still a Some';
    nok $s.unwrap.defined, 'the payload is undefined';
    is $s.unwrap.WHAT.^name, 'Int',
        'assigning Nil to a typed attribute yields that type object';
};

subtest "typed constructors round-trip through the new combinators" => {
    plan 5;
    my $m = Monad::Maybe[Str].from-defined('hi');
    ok $m.is-some, 'from-defined on Maybe[Str]';
    is $m.map(*.uc).unwrap, 'HI', 'map computes correctly';

    # Lawful fmap has signature `f a -> f b` — map is allowed to change
    # the payload type. This used to die (map rebuilt via the payload's
    # own T), which was the bug: it made map unlawful.
    my $crossed = Monad::Maybe[Str].some('x').map({ 42 });
    is $crossed.unwrap, 42,
        'map crossing to a different payload type succeeds — the result is Any-parameterized';

    my $e = Monad::Either[Str, Int].right(7);
    is $e.get-or-else(0), 7, 'get-or-else on a typed Either';
    is $e.fold(left => -> $l { 0 }, right => -> $r { $r * 2 }), 14,
        'fold on a typed Either';
};

# --- Typed transformation: map/map-left/bimap erase parameterization ---

class Persona {
    has Str $.name = 'Alice';
}

subtest "Maybe[T].map crossing to a different payload type" => {
    plan 4;
    my $p = Persona.new;
    my $some = Monad::Maybe[Persona].some($p).map(*.name);
    ok $some.is-some, 'still a Some after crossing Persona -> Str';
    is $some.unwrap, 'Alice', 'value transformed correctly';
    ok $some ~~ Some, 'erased result still smart-matches the exported Some marker';
    is $some.^name, Monad::Maybe[Any].some(1).^name,
        '.^name shape is Monad::Maybe[Any], not [Persona] or [Str]';
};

subtest "Maybe[Int].map to the same type still works (Any admits Int)" => {
    plan 2;
    my $m = Monad::Maybe[Int].some(5).map(* + 1);
    ok $m.is-some, 'Some after map';
    is $m.unwrap, 6, 'value computed correctly';
};

subtest "Maybe[T].map on a None crossing types stays None" => {
    plan 2;
    my $n = Monad::Maybe[Persona].none.map(*.name);
    ok $n.is-none, 'still None';
    ok $n ~~ None, 'erased None still smart-matches the exported None marker';
};

subtest "functor composition law holds for a typed Maybe crossing types" => {
    plan 1;
    # (m.map(f)).map(g) == m.map(g o f), even when f and g each change
    # the payload type (Persona -> Str -> Int).
    my &f = -> Persona $p { $p.name };
    my &g = -> Str $s { $s.chars };

    my $m = Monad::Maybe[Persona].some(Persona.new);
    my $composed-then-mapped = $m.map(&f).map(&g);
    my $mapped-composed      = $m.map(&g o &f);

    is $composed-then-mapped.unwrap, $mapped-composed.unwrap,
        'map(f).map(g) equals map(g o f) across type-crossing transformations';
};

subtest "Either[L,R].map crossing the Right payload type" => {
    plan 4;
    my $right = Monad::Either[Str, Persona].right(Persona.new).map(*.name);
    ok $right.is-right, 'still a Right after crossing Persona -> Str';
    is $right.unwrap-right, 'Alice', 'value transformed correctly';
    ok $right ~~ Right, 'erased result still smart-matches the exported Right marker';
    is $right.^name, Monad::Either[Any, Any].right(1).^name,
        '.^name shape is Monad::Either[Any,Any]';
};

subtest "Either[L,R].map-left crossing the Left payload type" => {
    plan 4;
    my $left = Monad::Either[Persona, Int].left(Persona.new).map-left(*.name);
    ok $left.is-left, 'still a Left after crossing Persona -> Str';
    is $left.unwrap-left, 'Alice', 'value transformed correctly';
    ok $left ~~ Left, 'erased result still smart-matches the exported Left marker';
    is $left.^name, Monad::Either[Any, Any].left(1).^name,
        '.^name shape is Monad::Either[Any,Any]';
};

subtest "Either[L,R].bimap crossing both payload types" => {
    plan 4;
    my $right = Monad::Either[Persona, Persona].right(Persona.new).bimap(*.name, *.name);
    is $right.unwrap-right, 'Alice', 'right branch transformed correctly';
    is $right.^name, Monad::Either[Any, Any].right(1).^name,
        'right result shape is Monad::Either[Any,Any]';

    my $left = Monad::Either[Persona, Persona].left(Persona.new).bimap(*.name, *.name);
    is $left.unwrap-left, 'Alice', 'left branch transformed correctly';
    is $left.^name, Monad::Either[Any, Any].left(1).^name,
        'left result shape is Monad::Either[Any,Any]';
};

subtest "swap still reparameterizes to the transposed [R, L], unlike map" => {
    plan 2;
    my $swapped = Monad::Either[Str, Int].right(4).swap;
    is $swapped.^name, Monad::Either[Int, Str].left(1).^name,
        'swap keeps a real type parameterization, not Any — it is a genuine type swap';
    ok $swapped.is-left, 'value moved to Left';
};

subtest "sequence and traverse return unparameterized results" => {
    plan 4;
    my $seq = Monad::Maybe[Int].sequence([
        Monad::Maybe[Int].some(1), Monad::Maybe[Int].some(2),
    ]);
    ok $seq ~~ Monad::Maybe, 'still a Maybe';
    is-deeply $seq.unwrap, (1, 2),
        'a List payload, so the element type parameter cannot describe it';

    my $tr = Monad::Either[Str, Int].traverse([1, 2], -> $n {
        Monad::Either[Str, Int].right($n)
    });
    ok $tr ~~ Monad::Either, 'still an Either';
    is-deeply $tr.unwrap-right, (1, 2), 'with a List payload';
};
