use Test;
use lib 'lib';
use Monad;
use Monad::Maybe;
use Monad::Either;

# Every Maybe / Either operation builds the type it returns from a type
# hook, and the result is cached so that each distinct type is built
# exactly once per process. This file hammers that cache from several
# real threads at once.
#
# It is a smoke test, not a proof: a passing run says the cache handed
# out correct, type-closed results while sixteen threads raced through
# it, not that no interleaving anywhere can misbehave. Concurrency bugs
# are not provable by testing, and this one would show up as a wrong
# type, a lost marker role, or a crash rather than as a wrong value.
#
# Threads are real OS threads (Thread.start), never `start { }` blocks:
# thread-pool scheduling is free to run those one after another on a
# single worker, which would exercise no concurrency at all. All of them
# block on one Promise so they are released together and hit the caches
# while they are still cold — which is when the types are actually being
# built, and so the only moment a race could do any damage.

constant THREADS = 16;
constant CHAINS  = 5_000;

plan THREADS + 5;

# A subtype family that overrides nothing but the two type hooks, so
# every combinator has to route through them to stay in the family.

my $LAZY-MAYBE;
sub lazy-maybe() { $LAZY-MAYBE //= ::('Conc::Maybe') }

role Conc::Either[::L = Any, ::R = Any] does Monad::Either[L, R] {
    method either-type(--> Mu) { Conc::Either }
    method maybe-type(--> Mu)  { lazy-maybe() }
}

role Conc::Maybe[::T = Any] does Monad::Maybe[T] {
    method maybe-type(--> Mu)  { Conc::Maybe  }
    method either-type(--> Mu) { Conc::Either }
}

# One iteration's worth of work: a Maybe chain that crosses into Either
# and back, and an Either chain that crosses into Maybe and back, for
# whichever family it is handed. Returns a description of anything that
# came out wrong, so that the assertions themselves can all be made on
# the main thread — Test's own routines are not thread-safe.
sub check-chains(Mu \MaybeType, Mu \EitherType, Str \family, Int \i --> Seq) {
    my @wrong;

    my $from-maybe = MaybeType.some(i)
                         .map(* + 1)
                         .bind(-> $v { MaybeType.some($v * 2) })
                         .to-either('missing');

    @wrong.push("{family}: maybe chain value {$from-maybe.gist} for i={i}")
        unless $from-maybe.is-right && $from-maybe.unwrap-right == (i + 1) * 2;

    @wrong.push("{family}: maybe chain type {$from-maybe.^name}")
        unless $from-maybe ~~ EitherType && $from-maybe ~~ Monad::Either;

    my $from-either = EitherType.right(i)
                          .map(* + 1)
                          .bind(-> $v { EitherType.right($v * 2) })
                          .to-maybe;

    @wrong.push("{family}: either chain value {$from-either.gist} for i={i}")
        unless $from-either.is-some && $from-either.unwrap == (i + 1) * 2;

    @wrong.push("{family}: either chain type {$from-either.^name}")
        unless $from-either ~~ MaybeType && $from-either ~~ Monad::Maybe;

    # The empty side of each family, which takes the other marker role
    # and so a different cache entry.
    my $none = MaybeType.some(i).filter(* < 0);

    @wrong.push("{family}: filtered-out value is {$none.gist}")
        unless $none.is-none && !$none.is-some;

    my $left = EitherType.left("e{i}").map(* + 1).map-left(*.uc);

    @wrong.push("{family}: left chain {$left.gist} / {$left.^name}")
        unless $left.is-left && $left.unwrap-left eq "E{i}" && $left ~~ EitherType;

    @wrong.Seq;
}

my $go = Promise.new;

my @threads = (^THREADS).map: -> $n {
    my @errors;

    Thread.start({
        await $go;

        for ^CHAINS -> $i {
            @errors.append: check-chains(Monad::Maybe, Monad::Either, 'base', $i);
            @errors.append: check-chains(Conc::Maybe, Conc::Either, 'subtype', $i);

            last if @errors;
        }
    }) => @errors;
};

$go.keep;
.key.finish for @threads;

for @threads.kv -> $n, $thread {
    my @errors := $thread.value;

    ok !@errors, "thread $n ran {CHAINS} mixed chains cleanly"
        or diag @errors.head(3).join("\n");
}

# The whole point of the cache is that a given (type, parameter) pair
# yields one type, not a fresh one per call, however many threads asked
# for it. Identity here is type identity, so === rather than =:=.

ok Monad::Maybe.some(1).WHAT === Monad::Maybe.some(2).WHAT,
    'two Somes built after the hammering share one type';

ok Monad::Maybe.none.WHAT === Monad::Maybe.some(1).filter(* > 99).WHAT,
    'a None and a filtered-out Some share one type';

ok Monad::Either.right(1).WHAT === Monad::Either.right(2).map(* + 1).WHAT,
    'a constructed Right and a mapped one share one type';

ok Conc::Maybe.some(1).WHAT === Conc::Maybe.some(2).WHAT,
    'the subtype family shares one type too';

isnt Monad::Maybe.some(1).^name, Conc::Maybe.some(1).^name,
    'the subtype family is still a distinct type from the base one';

# vim: expandtab shiftwidth=4
