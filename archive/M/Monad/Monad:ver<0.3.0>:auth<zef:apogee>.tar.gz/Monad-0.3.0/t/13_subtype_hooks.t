use Test;
use lib 'lib';
use Monad;
use Monad::Maybe;
use Monad::Either;

plan 27;

# A pair of subtypes that override nothing but the two type hooks. If
# subtype-friendliness works, every operation below stays inside this
# family without either role naming an operation of its own.

my $LAZY-MAYBE;
sub lazy-maybe() { $LAZY-MAYBE //= ::('Sub::Maybe') }

role Sub::Either[::L = Any, ::R = Any] does Monad::Either[L, R] {
    method either-type(--> Mu) { Sub::Either  }
    method maybe-type(--> Mu)  { lazy-maybe() }
}

role Sub::Maybe[::T = Any] does Monad::Maybe[T] {
    method maybe-type(--> Mu)  { Sub::Maybe  }
    method either-type(--> Mu) { Sub::Either }
}

sub is-sub-maybe($m, Str:D $why) {
    ok $m ~~ Sub::Maybe && $m ~~ Monad::Maybe, $why;
}

sub is-sub-either($e, Str:D $why) {
    ok $e ~~ Sub::Either && $e ~~ Monad::Either, $why;
}

# --- constructors --------------------------------------------------

is-sub-maybe Sub::Maybe.some(4),                'some builds the subtype';
is-sub-maybe Sub::Maybe.none,                   'none builds the subtype';
is-sub-maybe Sub::Maybe.unit(4),                'unit builds the subtype';
is-sub-maybe Sub::Maybe.from-defined(4),        'from-defined builds the subtype';
is-sub-maybe Sub::Maybe[Int].some(4),           'a parameterized some builds the subtype';
is-sub-either Sub::Either.left('e'),            'left builds the subtype';
is-sub-either Sub::Either.right(4),             'right builds the subtype';
is-sub-either Sub::Either.unit(4),              'unit builds the Either subtype';

ok Sub::Maybe.some(4).is-some,  'a subtype Some knows it is a Some';
ok Sub::Maybe.none.is-none,     'a subtype None knows it is a None';
ok Sub::Either.left('e').is-left,   'a subtype Left knows it is a Left';
ok Sub::Either.right(4).is-right,   'a subtype Right knows it is a Right';

# --- transformations preserve the subtype --------------------------

is-sub-maybe Sub::Maybe.some(4).map(* * 2),          'map stays in the subtype';
is-sub-maybe Sub::Maybe.some(4).filter(* %% 2),      'a passing filter stays in the subtype';
is-sub-maybe Sub::Maybe.some(3).filter(* %% 2),      'a failing filter stays in the subtype';
is-sub-maybe Sub::Maybe.sequence([Sub::Maybe.some(1), Sub::Maybe.some(2)]),
                                                     'sequence stays in the subtype';
is-sub-maybe Sub::Maybe.traverse([1, 2], -> $n { Sub::Maybe.some($n) }),
                                                     'traverse stays in the subtype';

is-sub-either Sub::Either.right(4).map(* * 2),       'Either map stays in the subtype';
is-sub-either Sub::Either.left('e').map-left(*.uc),  'map-left stays in the subtype';
is-sub-either Sub::Either.right(4).bimap(*.uc, * + 1), 'bimap stays in the subtype';
is-sub-either Sub::Either.left('e').swap,            'swap stays in the subtype';
is-sub-either Sub::Either.sequence([Sub::Either.right(1)]),
                                                     'Either sequence stays in the subtype';

# --- cross-type conversions land on the counterpart ----------------

is-sub-either Sub::Maybe.some(4).to-either('missing'),  'to-either on a Some lands on the Either subtype';
is-sub-either Sub::Maybe.none.to-either('missing'),     'to-either on a None lands on the Either subtype';
is-sub-maybe  Sub::Either.right(4).to-maybe,            'to-maybe on a Right lands on the Maybe subtype';
is-sub-maybe  Sub::Either.left('e').to-maybe,           'to-maybe on a Left lands on the Maybe subtype';

# --- a whole chain, asserted at the far end ------------------------

is-sub-maybe Sub::Maybe.some(4)
                 .map(* * 2)
                 .filter(* > 4)
                 .to-either('missing')
                 .map(* + 1)
                 .swap
                 .swap
                 .to-maybe
                 .map(*.Str),
             'every link of a mixed chain stays inside the subtype family';

# vim: expandtab shiftwidth=4
