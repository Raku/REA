use Test;
use lib 'lib';
use Monad;
use Monad::Either;

# Monad and functor laws for Monad::Either.
#
# As with Maybe, structurally identical Eithers are distinct objects, so
# equality is observable equivalence: same Left/Right side, same
# contents.

plan 6;

sub same-either($a, $b, $desc) {
    subtest $desc => {
        plan 2;
        is $a.is-right, $b.is-right, 'same Left/Right side';

        my $av = $a.value;
        my $bv = $b.value;
        ok ($av.defined || $bv.defined) ?? ($av eqv $bv)
                                        !! (!$av.defined && !$bv.defined),
            'same contents';
    }
}

my @values = 42, 'text', 0, '', Nil, Any;

# Kleisli arrows (value -> Either).
my &f-double = -> $v { Monad::Either.right($v.defined ?? $v.Str x 2 !! 'undef') };
my &f-left   = -> $v { Monad::Either.left("failed on {$v.gist}") };
my &f-unit   = -> $v { Monad::Either.unit($v) };
my @arrows   = &f-double, &f-left, &f-unit;

# Plain functions (value -> value).
my &g-mark = -> $v { $v.defined ?? "<$v>" !! '<undef>' };
my &g-len  = -> $v { $v.defined ?? $v.Str.chars !! -1 };

subtest 'left identity: unit(x).bind(&f) === f(x)' => {
    plan @values.elems * @arrows.elems;

    for @values -> $x {
        for @arrows -> &f {
            same-either
                Monad::Either.unit($x).bind(&f),
                f($x),
                "x = {$x.gist}";
        }
    }
}

subtest 'unit lifts into Right and is total' => {
    plan @values.elems;

    for @values -> $x {
        ok Monad::Either.unit($x).is-right, "unit({$x.gist}) is a Right";
    }
}

subtest 'right identity: m.bind(&unit) === m' => {
    plan @values.elems + 1;

    for @values -> $x {
        my $m = Monad::Either.right($x);
        same-either $m.bind(&f-unit), $m, "Right({$x.gist})";
    }

    my $l = Monad::Either.left('boom');
    same-either $l.bind(&f-unit), $l, 'Left';
}

subtest 'associativity: m.bind(f).bind(g) === m.bind({ f($_).bind(g) })' => {
    plan (@values.elems + 1) * @arrows.elems * @arrows.elems;

    my @monads = |@values.map({ Monad::Either.right($_) }),
                 Monad::Either.left('boom');

    for @monads -> $m {
        for @arrows -> &f {
            for @arrows -> &g {
                same-either
                    $m.bind(&f).bind(&g),
                    $m.bind(-> $v { f($v).bind(&g) }),
                    "m = {$m.gist}";
            }
        }
    }
}

subtest 'functor identity: m.map({ $_ }) === m' => {
    plan @values.elems + 2;

    for @values -> $x {
        my $m = Monad::Either.right($x);
        same-either $m.map({ $_ }), $m, "Right({$x.gist})";
    }

    my $l = Monad::Either.left('boom');
    same-either $l.map({ $_ }), $l, 'Right-map leaves a Left alone';
    same-either $l.map-left({ $_ }), $l, 'map-left identity on a Left';
}

subtest 'functor composition' => {
    plan 6;

    my $r = Monad::Either.right(42);
    my $l = Monad::Either.left('boom');

    same-either
        $r.map(&g-len).map(&g-mark),
        $r.map(-> $v { g-mark(g-len($v)) }),
        'map composes on a Right';

    same-either
        $l.map(&g-len).map(&g-mark),
        $l.map(-> $v { g-mark(g-len($v)) }),
        'map composes vacuously on a Left';

    same-either
        $l.map-left(&g-len).map-left(&g-mark),
        $l.map-left(-> $v { g-mark(g-len($v)) }),
        'map-left composes on a Left';

    same-either
        $r.map-left(&g-len).map-left(&g-mark),
        $r.map-left(-> $v { g-mark(g-len($v)) }),
        'map-left composes vacuously on a Right';

    # bimap is the two-sided functor map: applying it is the same as
    # applying whichever one-sided map matches.
    same-either $r.bimap(&g-mark, &g-len), $r.map(&g-len),
        'bimap on a Right agrees with map';
    same-either $l.bimap(&g-mark, &g-len), $l.map-left(&g-mark),
        'bimap on a Left agrees with map-left';
}
