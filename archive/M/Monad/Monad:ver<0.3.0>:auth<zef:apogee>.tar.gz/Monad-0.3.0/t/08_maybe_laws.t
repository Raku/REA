use Test;
use lib 'lib';
use Monad;
use Monad::Maybe;

# Monad and functor laws for Monad::Maybe.
#
# Two Maybes are compared by observable state rather than by identity or
# `eqv` on the objects themselves: Raku's role punning gives structurally
# identical Maybes distinct type objects once marker roles are mixed in,
# so `===`/`eqv` on the containers is not a meaningful equality here.
# `same-maybe` is the closest observable equivalence: same Some/None
# shape, same contents.

plan 5;

sub same-maybe($a, $b, $desc) {
    subtest $desc => {
        plan 2;
        is $a.is-some, $b.is-some, 'same Some/None shape';

        if $a.is-some && $b.is-some {
            my $av = $a.unwrap;
            my $bv = $b.unwrap;
            ok ($av.defined || $bv.defined) ?? ($av eqv $bv)
                                            !! (!$av.defined && !$bv.defined),
                'same contents';
        }
        else {
            pass 'both empty — nothing to compare';
        }
    }
}

# A value matrix that deliberately includes undefined and falsy values.
my @values = 42, 'text', 0, '', Nil, Any;

# Kleisli arrows (value -> Maybe).
my &f-double = -> $v { Monad::Maybe.some($v.defined ?? $v.Str x 2 !! 'undef') };
my &f-none   = -> $v { Monad::Maybe.none };
my &f-nil    = -> $v { Monad::Maybe.some(Nil) };
my &f-unit   = -> $v { Monad::Maybe.unit($v) };
my @arrows   = &f-double, &f-none, &f-nil, &f-unit;

# Plain functions (value -> value).
my &g-mark   = -> $v { $v.defined ?? "<$v>" !! '<undef>' };
my &g-nil    = -> $v { Nil };
my &g-len    = -> $v { $v.defined ?? $v.Str.chars !! -1 };

subtest 'left identity: unit(x).bind(&f) === f(x)' => {
    plan @values.elems * @arrows.elems;

    for @values -> $x {
        for @arrows -> &f {
            same-maybe
                Monad::Maybe.unit($x).bind(&f),
                f($x),
                "x = {$x.gist}, arrow {&f.gist.substr(0, 12)}";
        }
    }
}

subtest 'right identity: m.bind(&unit) === m' => {
    plan @values.elems + 1;

    for @values -> $x {
        my $m = Monad::Maybe.some($x);
        same-maybe $m.bind(&f-unit), $m, "Some({$x.gist})";
    }

    same-maybe Monad::Maybe.none.bind(&f-unit), Monad::Maybe.none, 'None';
}

subtest 'associativity: m.bind(f).bind(g) === m.bind({ f($_).bind(g) })' => {
    plan (@values.elems + 1) * @arrows.elems * @arrows.elems;

    my @monads = |@values.map({ Monad::Maybe.some($_) }), Monad::Maybe.none;

    for @monads -> $m {
        for @arrows -> &f {
            for @arrows -> &g {
                same-maybe
                    $m.bind(&f).bind(&g),
                    $m.bind(-> $v { f($v).bind(&g) }),
                    "m = {$m.gist}";
            }
        }
    }
}

subtest 'functor identity: m.map({ $_ }) === m' => {
    plan @values.elems + 1;

    for @values -> $x {
        my $m = Monad::Maybe.some($x);
        same-maybe $m.map({ $_ }), $m, "Some({$x.gist})";
    }

    same-maybe Monad::Maybe.none.map({ $_ }), Monad::Maybe.none, 'None';
}

subtest 'functor composition: m.map(f).map(g) === m.map(g of f)' => {
    plan 4 + 3 * 3;

    # The case 0.2 got wrong: a map whose function returns Nil used to
    # collapse the Some to a None, which breaks composition outright.
    my $m = Monad::Maybe.some(42);

    same-maybe
        $m.map(&g-nil).map(&g-mark),
        $m.map(-> $v { g-mark(g-nil($v)) }),
        'f returns Nil: composition still holds (0.2 gave None on the left)';

    ok $m.map(&g-nil).is-some,
        'the intermediate stays a Some — that is what makes it hold';
    is $m.map(&g-nil).map(&g-mark).unwrap, '<undef>',
        'and the second map sees the undefined value';
    is $m.map(&g-mark).unwrap, '<42>', 'sanity: mapping a defined value';

    for @values.head(3) -> $x {
        my $mv = Monad::Maybe.some($x);
        for (&g-mark, &g-nil, &g-len) -> &g {
            same-maybe
                $mv.map(&g-len).map(&g),
                $mv.map(-> $v { g(g-len($v)) }),
                "Some({$x.gist})";
        }
    }
}
