use Test;
use lib 'lib';

# Maybe.to-either and Either.to-maybe let the two types convert to each
# other, which means each module has to reach the other one without a
# compile-time circular `use`. That is done with a lazy, memoised
# `require`, and it has to work no matter which module the consumer
# loaded — including when they loaded only one of them. Each case runs in
# its own process, because load order is a per-process property.

plan 8;

my $lib = ~$*CWD.child('lib');

sub run-snippet(Str $code, Str $desc) {
    my $proc = run $*EXECUTABLE, '-I', $lib, '-e', $code, :out, :err;
    my $out  = $proc.out.slurp(:close).trim;
    my $err  = $proc.err.slurp(:close).trim;

    diag "stderr from '$desc': $err" if $err;

    $out;
}

is run-snippet(
        'use Monad::Maybe; print Monad::Maybe.some(1).to-either("e").gist',
        'maybe alone',
    ),
    'Right(1)',
    'to-either works when only Monad::Maybe was loaded';

is run-snippet(
        'use Monad::Either; print Monad::Either.right(2).to-maybe.gist',
        'either alone',
    ),
    'Some(2)',
    'to-maybe works when only Monad::Either was loaded';

is run-snippet(
        'use Monad::Maybe; use Monad::Either;'
        ~ ' print Monad::Maybe.none.to-either("e").gist ~ "|" ~ Monad::Either.right(3).to-maybe.gist',
        'maybe first',
    ),
    'Left(e)|Some(3)',
    'both conversions work when Maybe was loaded first';

is run-snippet(
        'use Monad::Either; use Monad::Maybe;'
        ~ ' print Monad::Either.left("z").to-maybe.gist ~ "|" ~ Monad::Maybe.some(4).to-either("e").gist',
        'either first',
    ),
    'None|Right(4)',
    'both conversions work when Either was loaded first';

is run-snippet(
        'use Monad; use Monad::Maybe; print Monad::Maybe.some(5).to-either("e").gist',
        'umbrella first',
    ),
    'Right(5)',
    'the sibling lookup survives the umbrella Monad package being loaded';

is run-snippet(
        'use Monad::Maybe;'
        ~ ' print (^3).map({ Monad::Maybe.some($_).to-either("e").gist }).join(",")',
        'repeated',
    ),
    'Right(0),Right(1),Right(2)',
    'the memoised type resolves the same way on every call';

# ...and it really is memoised. The memo holds a type object, which is
# undefined, so a `//=` (or any other definedness test) never takes and
# the require runs again on every single conversion — invisible in the
# results, but a module lookup per call and a concurrent module load per
# thread. Warming the memo and then pointing $*REPO at a repository that
# has no Monad in it makes the difference visible: a second require would
# fail to find the module, so surviving proves no second require happened.
# Each case runs in its own process because breaking $*REPO is not
# something to do to the test run itself.

sub without-a-repo(Str $code) {
    # The declaration has to be inside a block: `my $*REPO` shadows the
    # real one for its whole frame, so at unit scope it would also blind
    # the warm-up call that has to succeed first.
    '{ my $*REPO = CompUnit::Repository::FileSystem.new('
    ~ ' prefix => $*TMPDIR.add("monad-empty-repo-$*PID"));'
    ~ $code
    ~ ' }';
}

is run-snippet(
        'use Monad::Maybe; Monad::Maybe.some(0).to-either("warm");'
        ~ without-a-repo(' print Monad::Maybe.some(1).to-either("e").gist'),
        'maybe memo',
    ),
    'Right(1)',
    'to-either resolves Monad::Either once, not on every call';

is run-snippet(
        'use Monad::Either; Monad::Either.right(0).to-maybe;'
        ~ without-a-repo(' print Monad::Either.right(1).to-maybe.gist'),
        'either memo',
    ),
    'Some(1)',
    'to-maybe resolves Monad::Maybe once, not on every call';
