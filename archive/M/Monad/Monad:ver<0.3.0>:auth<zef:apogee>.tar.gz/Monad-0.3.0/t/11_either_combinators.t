use Test;
use lib 'lib';
use Monad;
use Monad::Either;
use Monad::Maybe;

plan 10;

my $right = Monad::Either.right(42);
my $left  = Monad::Either.left('boom');

subtest 'map-left' => {
    plan 6;

    my $mapped = $left.map-left(*.uc);
    ok $mapped.is-left,               'map-left on a Left stays a Left';
    is $mapped.unwrap-left, 'BOOM',   'applying the function to the error';

    my $untouched = $right.map-left(*.uc);
    ok $untouched.is-right,           'map-left on a Right stays a Right';
    is $untouched.unwrap-right, 42,   'leaving the value alone';

    my $called = 0;
    $right.map-left(-> $e { $called++; $e });
    is $called, 0, 'the function is not called on a Right';

    ok $left.map-left({ Nil }).is-left,
        'an undefined result does not change the side';
}

subtest 'bimap' => {
    plan 6;

    my $l = $left.bimap(*.uc, * * 2);
    ok $l.is-left,             'bimap on a Left stays a Left';
    is $l.unwrap-left, 'BOOM', 'the left function ran';

    my $r = $right.bimap(*.uc, * * 2);
    ok $r.is-right,            'bimap on a Right stays a Right';
    is $r.unwrap-right, 84,    'the right function ran';

    my ($lc, $rc) = 0, 0;
    $right.bimap(-> $e { $lc++; $e }, -> $v { $rc++; $v });
    is $lc, 0, 'the left function is not called on a Right';
    is $rc, 1, 'the right function is called exactly once';
}

subtest 'get-or-else is right-biased' => {
    plan 5;

    is $right.get-or-else(0), 42,  'Right returns its value';
    is $left.get-or-else(0), 0,    'Left returns the default';
    is $left.get-or-else('safe'), 'safe', 'default may be any type';
    is Monad::Either.right(0).get-or-else(99), 0, 'a falsy Right is still a Right';

    nok Monad::Either.right(Nil).get-or-else(99).defined,
        'Right(Nil) returns its (undefined) value, not the default';
}

subtest 'fold' => {
    plan 6;

    my ($lc, $rc) = 0, 0;
    my $seen;

    my $from-left = $left.fold(
        left  => -> $e { $lc++; $seen = $e; "error: $e" },
        right => -> $v { $rc++; "ok: $v" },
    );
    is $from-left, 'error: boom', 'the left branch produces the result';
    is $seen, 'boom',             'the left branch receives the left value';
    is $rc, 0,                    'the right branch is not called';

    ($lc, $rc) = 0, 0;
    my $from-right = $right.fold(
        left  => -> $e { $lc++; "error: $e" },
        right => -> $v { $rc++; "ok: $v" },
    );
    is $from-right, 'ok: 42', 'the right branch produces the result';
    is $lc, 0,                'the left branch is not called';

    is $right.fold(left => -> $e { 0 }, right => -> $v { $v + 1 }), 43,
        'the fold result is returned as-is';
}

subtest 'fold requires both branches' => {
    plan 2;

    throws-like { $right.fold(left => -> $e { 1 }) }, X::AdHoc,
        message => /"'right' not passed"/,
        'omitting :right is a hard error';

    throws-like { $right.fold(right => -> $v { 1 }) }, X::AdHoc,
        message => /"'left' not passed"/,
        'omitting :left is a hard error';
}

subtest 'swap' => {
    plan 7;

    my $swapped-left = $left.swap;
    ok $swapped-left.is-right,             'a Left swaps to a Right';
    is $swapped-left.unwrap-right, 'boom', 'carrying the same payload';

    my $swapped-right = $right.swap;
    ok $swapped-right.is-left,            'a Right swaps to a Left';
    is $swapped-right.unwrap-left, 42,    'carrying the same payload';

    ok $left.swap.swap.is-left,      'swapping twice is the identity (Left)';
    ok $right.swap.swap.is-right,    'swapping twice is the identity (Right)';

    my $typed = Monad::Either[Str, Int].left('nope').swap;
    is $typed.^name.subst(/'+{' .* '}'/, ''), 'Monad::Either[Int,Str]',
        'the type parameters swap along with the sides';
}

subtest 'to-maybe' => {
    plan 6;

    my $s = $right.to-maybe;
    ok $s ~~ Monad::Maybe, 'Right converts to a Maybe';
    ok $s.is-some,         'Right becomes a Some';
    is $s.unwrap, 42,      'carrying the value';

    my $n = $left.to-maybe;
    ok $n ~~ Monad::Maybe, 'Left converts to a Maybe';
    ok $n.is-none,         'Left becomes a None — the error is discarded';

    ok Monad::Either.right(Nil).to-maybe.is-some,
        'a Right holding an undefined value is still a Some';
}

subtest 'round-tripping through Maybe and back' => {
    plan 4;

    my $round = $right.to-maybe.to-either('lost');
    ok $round.is-right,          'Right survives the round trip';
    is $round.unwrap-right, 42,  'with its value';

    my $lossy = $left.to-maybe.to-either('lost');
    ok $lossy.is-left,               'Left survives as a Left';
    is $lossy.unwrap-left, 'lost',   'but the original error is gone — to-maybe discards it';
}

subtest 'sequence' => {
    plan 8;

    my $all = Monad::Either.sequence([
        Monad::Either.right(1), Monad::Either.right(2), Monad::Either.right(3),
    ]);
    ok $all.is-right, 'all Right yields a Right';
    is-deeply $all.unwrap-right, (1, 2, 3), 'holding the values in order';

    my $first-left = Monad::Either.left('first');
    my $failed = Monad::Either.sequence([
        Monad::Either.right(1), $first-left, Monad::Either.left('second'),
    ]);
    ok $failed.is-left,                'one Left yields a Left';
    is $failed.unwrap-left, 'first',   'the first Left wins';
    ok $failed === $first-left,        'and it is that very Left, unchanged';

    my $empty = Monad::Either.sequence([]);
    ok $empty.is-right, 'an empty list yields a Right';
    is-deeply $empty.unwrap-right, (), 'holding an empty list';

    throws-like { Monad::Either.sequence([1, 2]) }, X::AdHoc,
        message => /'expects Monad::Either elements'/,
        'non-Either elements are a loud error';
}

subtest 'traverse' => {
    plan 8;

    my $calls = 0;
    my &parse = -> $s {
        $calls++;
        $s ~~ /^ \d+ $/
            ?? Monad::Either.right(+$s)
            !! Monad::Either.left("bad: $s");
    };

    my $ok = Monad::Either.traverse(<1 2 3>, &parse);
    ok $ok.is-right, 'all-Right traversal yields a Right';
    is-deeply $ok.unwrap-right, (1, 2, 3), 'holding the mapped values in order';
    is $calls, 3, 'the function ran once per element';

    $calls = 0;
    my $bad = Monad::Either.traverse(<1 2 x 4 y>, &parse);
    ok $bad.is-left,                 'a Left result yields a Left';
    is $bad.unwrap-left, 'bad: x',   'carrying the first error';
    is $calls, 3, 'and the function is not called past the first Left';

    my $empty = Monad::Either.traverse([], &parse);
    ok $empty.is-right, 'an empty list yields a Right';

    throws-like { Monad::Either.traverse([1], -> $n { $n }) }, X::AdHoc,
        message => /'to return a Monad::Either'/,
        'a function that returns a bare value is a loud error';
}
