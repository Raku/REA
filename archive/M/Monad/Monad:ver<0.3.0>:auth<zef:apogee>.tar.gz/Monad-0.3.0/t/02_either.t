use Test;
use lib 'lib';
use Monad;
use Monad::Either;

plan 11;

sub dubz ($v) { Monad::Either.right($v * 2) }
sub dubzbare ($v) { $v * 2 }

my $right = Monad::Either.right(21);
my $left  = Monad::Either.left("Bad stuff");

subtest 'constructors and identity' => {
    plan 7;

    ok $right ~~ Monad::Either, 'Right is an Either';
    ok $left  ~~ Monad::Either, 'Left is an Either';
    ok $right ~~ Monad,         'Right is a Monad';
    ok $right ~~ Right,         'Right smart-matches the Right marker role';
    ok $left  ~~ Left,          'Left smart-matches the Left marker role';
    nok $right ~~ Left,         'Right does not smart-match Left';

    is $left.value, 'Bad stuff', 'the raw .value accessor is still side-blind';
}

subtest 'is-left / is-right' => {
    plan 4;

    is $right.is-right, True,  'Right.is-right';
    is $right.is-left,  False, 'Right.is-left is False';
    is $left.is-left,   True,  'Left.is-left';
    is $left.is-right,  False, 'Left.is-right is False';
}

subtest 'side-blind unwrap is gone (0.3 BREAKING)' => {
    plan 3;

    nok $right.can('unwrap'),
        'Either no longer has an unwrap method (0.2 returned either side blindly)';

    throws-like { $right.unwrap }, X::Method::NotFound,
        'calling unwrap is a hard method-not-found error';

    nok Monad::Either.can('unwrap'),
        'not present on the type object either';
}

subtest 'unwrap-left / unwrap-right' => {
    plan 6;

    is $right.unwrap-right, 21,          'unwrap-right on Right returns the value';
    is $left.unwrap-left, 'Bad stuff',   'unwrap-left on Left returns the value';

    throws-like { $left.unwrap-right }, X::AdHoc,
        message => /'unwrap-right on a Left'/,
        'unwrap-right on Left throws';

    throws-like { $right.unwrap-left }, X::AdHoc,
        message => /'unwrap-left on a Right'/,
        'unwrap-left on Right throws';

    throws-like { $left.unwrap-right }, X::AdHoc, message => /'Bad stuff'/,
        'the message shows what was actually there';

    throws-like { Monad::Either.right(Nil).unwrap-left }, X::AdHoc,
        'an undefined payload still produces a clean failure';
}

subtest 'bind is right-biased' => {
    plan 6;

    my $bound = $right.bind(&dubz);
    isa-ok $bound, Monad::Either, 'bind on Right returns Either';
    is $bound.is-right, True,     'bind on Right stays Right';
    is $bound.unwrap-right, 42,   'bind on Right transforms correctly';

    my $bound2 = $left >>= &dubz;
    isa-ok $bound2, Monad::Either, '>>= on Left returns Either';
    is $bound2.is-left, True,      'bind on Left remains unchanged';

    my $called = 0;
    $left.bind(-> $v { $called++; Monad::Either.right($v) });
    is $called, 0, 'bind on Left never calls the function';
}

subtest 'bind may switch sides' => {
    plan 2;

    my $r = $right.bind(-> $v { Monad::Either.left("too big: $v") });
    ok $r.is-left, 'a Right can bind into a Left';
    is $r.unwrap-left, 'too big: 21', 'carrying the new error';
}

subtest 'map is right-biased' => {
    plan 5;

    my $mapped = $right.map(&dubzbare);
    is $mapped.is-right, True,   'map on Right stays Right';
    is $mapped.unwrap-right, 42, 'map on Right applies transformation';

    my $mapped2 = $left >>- &dubzbare;
    is $mapped2.is-left, True,   'map on Left does not apply function';
    is $mapped2.unwrap-left, 'Bad stuff', 'unwrap-left still returns the value';

    my $called = 0;
    $left.map(-> $v { $called++; $v });
    is $called, 0, 'map on Left never calls the function';
}

subtest 'map does not collapse on an undefined result' => {
    plan 2;

    my $mapped = $right.map({ Nil });
    ok $mapped.is-right, 'a Right stays a Right even when &f returns Nil';
    nok $mapped.unwrap-right.defined, 'the contained value is undefined';
}

subtest 'structurally identical Eithers compare equal' => {
    plan 4;

    is-deeply Monad::Either.right(3), Monad::Either.right(3),
        'two Rights with the same value are is-deeply equal';
    is-deeply $right.map({ $_ + 1 }), Monad::Either.right(22),
        'a mapped Either equals a directly constructed one';

    nok (Monad::Either.left('x') eqv Monad::Either.right('x')),
        'same payload on different sides is not equal';
    nok (Monad::Either.left('x') eqv Monad::Either.left('y')),
        'different payloads are not equal';
}

subtest 'a constructor called on the opposite variant is clean' => {
    plan 5;

    # Building from an instance used to mix the new marker role on top of
    # the old one, producing a value that answered True to both is-left
    # and is-right.
    my $from-right = $right.left('nope');
    ok $from-right.is-left,   'Right.left produces a Left';
    nok $from-right.is-right, 'and it is not also a Right';

    my $from-left = $left.right(7);
    ok $from-left.is-right,   'Left.right produces a Right';
    nok $from-left.is-left,   'and it is not also a Left';

    ok $from-right.WHAT =:= $left.WHAT, 'and it is the same type as any other Left';
}

subtest 'gist' => {
    plan 3;

    is $right.gist, 'Right(21)',      'Right gist';
    is $left.gist,  'Left(Bad stuff)', 'Left gist';
    is Monad::Either.right(Nil).gist, 'Right((Any))',
        'an undefined payload gists without warning';
}
