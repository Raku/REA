use Test;
use lib 'lib';
use Monad;
use Monad::Maybe;
use Monad::Either;

plan 10;

my $some = Monad::Maybe.some(42);
my $none = Monad::Maybe.none;

subtest 'get-or-else' => {
    plan 6;

    is $some.get-or-else(0), 42,       'Some returns its value';
    is $none.get-or-else(0), 0,        'None returns the default';
    is $none.get-or-else('fallback'), 'fallback', 'default may be any type';
    is Monad::Maybe.some(0).get-or-else(99), 0, 'a falsy value is still a value';
    is Monad::Maybe.some('').get-or-else('x'), '', 'an empty string is still a value';

    nok Monad::Maybe.some(Nil).get-or-else(99).defined,
        'Some(Nil) returns its (undefined) value, not the default — presence, not truth';
}

subtest 'fold on Some' => {
    plan 4;

    my $none-called = 0;
    my $seen;

    my $out = $some.fold(
        none => { $none-called++; 'empty' },
        some => -> $v { $seen = $v; "got $v" },
    );

    is $out, 'got 42',     'the some branch produces the result';
    is $seen, 42,          'the some branch receives the contained value';
    is $none-called, 0,    'the none branch is not called';
    is $some.fold(none => { 0 }, some => -> $v { $v * 2 }), 84, 'result is returned as-is';
}

subtest 'fold on None' => {
    plan 3;

    my $some-called = 0;

    my $out = $none.fold(
        none => { 'empty' },
        some => -> $v { $some-called++; "got $v" },
    );

    is $out, 'empty',     'the none branch produces the result';
    is $some-called, 0,   'the some branch is not called';

    ok $none.fold(none => { Monad::Maybe.some(1) }, some => -> $v { $v }).is-some,
        'fold may return anything, including another Maybe';
}

subtest 'fold requires both branches' => {
    plan 2;

    throws-like { $some.fold(none => { 1 }) }, X::AdHoc,
        message => /"'some' not passed"/,
        'omitting :some is a hard error';

    throws-like { $some.fold(some => -> $v { 1 }) }, X::AdHoc,
        message => /"'none' not passed"/,
        'omitting :none is a hard error';
}

subtest 'filter' => {
    plan 7;

    ok Monad::Maybe.some(4).filter(* %% 2).is-some, 'passing predicate keeps the Some';
    is Monad::Maybe.some(4).filter(* %% 2).unwrap, 4, 'the value is unchanged';
    ok Monad::Maybe.some(3).filter(* %% 2).is-none, 'failing predicate yields None';
    ok $none.filter(* %% 2).is-none, 'None stays None';

    my $called = 0;
    $none.filter(-> $v { $called++; True });
    is $called, 0, 'the predicate is not called on a None';

    my $seen;
    Monad::Maybe.some('hi').filter(-> $v { $seen = $v; True });
    is $seen, 'hi', 'the predicate receives the contained value';

    ok Monad::Maybe.some(Nil).filter({ .defined }).is-none,
        'filter is how you collapse an undefined payload on purpose';
}

subtest 'to-either' => {
    plan 7;

    my $r = $some.to-either('missing');
    ok $r ~~ Monad::Either, 'Some converts to an Either';
    ok $r.is-right,         'Some becomes a Right';
    is $r.unwrap-right, 42, 'carrying the value';

    my $l = $none.to-either('missing');
    ok $l ~~ Monad::Either,       'None converts to an Either';
    ok $l.is-left,                'None becomes a Left';
    is $l.unwrap-left, 'missing', 'carrying the supplied left value';

    ok $none.to-either(Nil).is-left, 'the left value may itself be undefined';
}

subtest 'sequence' => {
    plan 8;

    my $all = Monad::Maybe.sequence([
        Monad::Maybe.some(1), Monad::Maybe.some(2), Monad::Maybe.some(3),
    ]);
    ok $all.is-some, 'all Some yields a Some';
    is-deeply $all.unwrap, (1, 2, 3), 'holding the values in order';

    ok Monad::Maybe.sequence([
        Monad::Maybe.some(1), Monad::Maybe.none, Monad::Maybe.some(3),
    ]).is-none, 'one None yields a None';

    ok Monad::Maybe.sequence([Monad::Maybe.none]).is-none, 'a single None yields None';

    my $empty = Monad::Maybe.sequence([]);
    ok $empty.is-some, 'an empty list yields a Some';
    is-deeply $empty.unwrap, (), 'holding an empty list';

    ok Monad::Maybe.sequence([Monad::Maybe.some(Nil)]).is-some,
        'a Some holding an undefined value does not count as absent';

    throws-like { Monad::Maybe.sequence([1, 2]) }, X::AdHoc,
        message => /'expects Monad::Maybe elements'/,
        'non-Maybe elements are a loud error';
}

subtest 'sequence short-circuits' => {
    plan 2;

    my $pulled = 0;
    my $lazy = lazy gather for 1 .. 5 -> $n {
        $pulled++;
        take $n < 3 ?? Monad::Maybe.some($n) !! Monad::Maybe.none;
    };

    ok Monad::Maybe.sequence($lazy).is-none, 'a lazy source still yields None';
    is $pulled, 3, 'and nothing past the first None was pulled';
}

subtest 'traverse' => {
    plan 8;

    my $calls = 0;
    my &half-ok = -> $n {
        $calls++;
        $n < 3 ?? Monad::Maybe.some($n * 2) !! Monad::Maybe.none;
    };

    my $ok = Monad::Maybe.traverse([1, 2], &half-ok);
    ok $ok.is-some, 'all-Some traversal yields a Some';
    is-deeply $ok.unwrap, (2, 4), 'holding the mapped values in order';
    is $calls, 2, 'the function ran once per element';

    $calls = 0;
    my $bad = Monad::Maybe.traverse([1, 2, 3, 4, 5], &half-ok);
    ok $bad.is-none, 'a None result yields None';
    is $calls, 3, 'and the function is not called past the first None';

    my $empty = Monad::Maybe.traverse([], &half-ok);
    ok $empty.is-some, 'an empty list yields a Some';
    is-deeply $empty.unwrap, (), 'holding an empty list';

    throws-like { Monad::Maybe.traverse([1], -> $n { $n }) }, X::AdHoc,
        message => /'to return a Monad::Maybe'/,
        'a function that returns a bare value is a loud error';
}

subtest 'parametric forms of the new methods' => {
    plan 6;

    my $m = Monad::Maybe[Int].some(10);

    is $m.get-or-else(0), 10, 'get-or-else on a typed Maybe';
    is $m.fold(none => { 0 }, some => -> $v { $v + 1 }), 11, 'fold on a typed Maybe';
    ok $m.filter(* > 5).is-some, 'filter on a typed Maybe';
    ok $m.filter(* > 50).is-none, 'filter can empty a typed Maybe';
    ok Monad::Maybe[Int].from-defined(Int).is-none, 'from-defined on a typed Maybe';
    is $m.to-either('nope').unwrap-right, 10, 'to-either on a typed Maybe';
}
