use Test;
use lib 'lib';
use Monad;
use Monad::Maybe;

plan 14;

sub dubz ($v) { Monad::Maybe.some($v * 2) }
sub dubzbare ($v) { $v * 2 }
sub returnnil ($_) { Nil }

my $some = Monad::Maybe.some(42);
my $none = Monad::Maybe.none();

subtest 'constructors and identity' => {
    plan 8;

    ok $some ~~ Monad::Maybe, 'Some is a Maybe';
    ok $none ~~ Monad::Maybe, 'None is a Maybe';
    ok $some ~~ Monad,        'Some is a Monad';
    ok $some ~~ Some,         'Some smart-matches the Some marker role';
    ok $none ~~ None,         'None smart-matches the None marker role';
    nok $some ~~ None,        'Some does not smart-match None';

    is-deeply $some.value, 42, 'Some contains correct value';
    nok $none.value.defined,   'None is empty';
}

subtest 'is-some / is-none' => {
    plan 4;

    is $some.is-some, True,  'Some.is-some';
    is $some.is-none, False, 'Some.is-none is False';
    is $none.is-none, True,  'None.is-none';
    is $none.is-some, False, 'None.is-some is False';
}

subtest 'unwrap' => {
    plan 3;

    is $some.unwrap, 42, 'unwrap on Some returns the value';

    throws-like { $none.unwrap }, X::AdHoc,
        message => /'Cannot unwrap a None'/,
        'unwrap on None dies (0.3 BREAKING: was Nil in 0.2)';

    throws-like { Monad::Maybe[Int].none.unwrap }, X::AdHoc,
        message => /'get-or-else'/,
        'the failure message points at the total eliminators';
}

subtest 'bind' => {
    plan 6;

    my $bound = $some.bind(&dubz);
    isa-ok $bound, Monad::Maybe, 'bind on Some returns a Maybe';
    is $bound.is-some, True, 'bind on Some correctly stays Some';
    is $bound.unwrap, 84,    'bind on Some transforms correctly';

    my $bound2 = $none >>= &dubz;
    isa-ok $bound2, Monad::Maybe, '>>= on None returns a Maybe';
    is $bound2.is-none, True, 'bind on None correctly stays None';

    my $called = 0;
    $none.bind(-> $v { $called++; Monad::Maybe.some($v) });
    is $called, 0, 'bind on None never calls the function';
}

subtest 'bind can return a None' => {
    plan 2;

    my $r = $some.bind(-> $v { $v > 100 ?? Monad::Maybe.some($v) !! Monad::Maybe.none });
    ok $r.is-none, 'bind may collapse a Some to a None — that is what bind is for';

    my $r2 = $some.bind(-> $v { Monad::Maybe.from-defined(Nil) });
    ok $r2.is-none, 'from-defined inside bind is the 0.2 map behaviour, spelled out';
}

subtest 'map' => {
    plan 6;

    my $mapped = $some.map(&dubzbare);
    isa-ok $mapped, Monad::Maybe, 'map on Some returns a Maybe';
    is $mapped.is-some, True, 'map on Some correctly stays Some';
    is $mapped.unwrap, 84,    'map on Some transforms correctly';

    my $mapped2 = $none.map(&dubzbare);
    isa-ok $mapped2, Monad::Maybe, 'map on None returns a Maybe';
    is $mapped2.is-none, True, 'map on None correctly stays None';

    my $called = 0;
    $none.map(-> $v { $called++; $v });
    is $called, 0, 'map on None never calls the function';
}

subtest 'map never collapses a Some (0.3 BREAKING)' => {
    plan 4;

    my $mapped = $some >>- &returnnil;
    isa-ok $mapped, Monad::Maybe, 'map returning Nil still yields a Maybe';
    ok $mapped.is-some,
        'map on Some that returns Nil stays Some (0.2 turned it into None)';
    nok $mapped.unwrap.defined, 'the contained value is undefined';

    ok $some.map({ Any }).is-some, 'a returned type object also stays Some';
}

subtest 'unit is total (0.3 BREAKING)' => {
    plan 5;

    my $lifted = Monad::Maybe.unit(3);
    isa-ok $lifted, Monad::Maybe, 'unit returns a Maybe';
    is $lifted.is-some, True, 'unit with a value returns Some';
    is $lifted.unwrap, 3,     'unwrapping returns 3';

    my $nil-lifted = Monad::Maybe.unit(Nil);
    ok $nil-lifted.is-some,
        'unit with Nil returns Some (0.2 returned None); pure must be total';
    nok $nil-lifted.unwrap.defined, 'the lifted value is undefined but present';
}

subtest 'from-defined replaces the 0.2 unit' => {
    plan 6;

    ok Monad::Maybe.from-defined(3).is-some,     'defined value becomes Some';
    is Monad::Maybe.from-defined(3).unwrap, 3,   'value preserved';
    ok Monad::Maybe.from-defined(Nil).is-none,   'Nil becomes None';
    ok Monad::Maybe.from-defined(Any).is-none,   'type object becomes None';
    ok Monad::Maybe.from-defined('').is-some,    'empty string is defined, so Some';
    ok Monad::Maybe.from-defined(0).is-some,     'zero is defined, so Some';
}

subtest 'Some may hold an undefined value' => {
    plan 3;

    my $s = Monad::Maybe.some(Nil);
    ok $s.is-some,          'Some(Nil) is a Some';
    nok $s.is-none,         'Some(Nil) is not a None';
    nok $s.unwrap.defined,  'its value is undefined, and unwrap does not die';
}

subtest 'gist' => {
    plan 4;

    is $some.gist, 'Some(42)',  'Some gist';
    is $none.gist, 'None',      'None gist';
    is Monad::Maybe.some('hi').gist, 'Some(hi)', 'Some(Str) gist';
    is Monad::Maybe.some(Nil).gist, 'Some((Any))',
        'Some of an undefined value gists without warning';
}

subtest 'chaining keeps one stable type' => {
    plan 2;

    my $chained = $some.map(&dubzbare).map(&dubzbare);
    is $chained.unwrap, 168, 'two maps compose';
    ok $chained.WHAT =:= $some.WHAT,
        'repeated mapping does not accumulate marker-role mixins';
}

subtest 'structurally identical Maybes compare equal' => {
    plan 5;

    is-deeply Monad::Maybe.some(3), Monad::Maybe.some(3),
        'two Somes with the same value are is-deeply equal';
    is-deeply $some.map({ $_ + 1 }), Monad::Maybe.some(43),
        'a mapped Maybe equals a directly constructed one';
    is-deeply Monad::Maybe.none, Monad::Maybe.none, 'two Nones are equal';

    nok (Monad::Maybe.some(3) eqv Monad::Maybe.some(4)),
        'different values are not equal';
    nok (Monad::Maybe.some(3) eqv Monad::Maybe.none),
        'a Some is not equal to a None';
}

subtest 'a constructor called on the opposite variant is clean' => {
    plan 6;

    # Building from an instance used to mix the new marker role on top of
    # the old one, producing a value that answered True to both is-some
    # and is-none.
    my $from-some = $some.none;
    ok $from-some.is-none,  'Some.none produces a None';
    nok $from-some.is-some, 'and it is not also a Some';

    my $from-none = $none.some(7);
    ok $from-none.is-some,  'None.some produces a Some';
    nok $from-none.is-none, 'and it is not also a None';
    is $from-none.unwrap, 7, 'carrying the value';

    ok $from-some.WHAT =:= $none.WHAT, 'and it is the same type as any other None';
}
