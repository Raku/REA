use Monad;

# Marker roles mixed onto Maybe instances to distinguish Some from None.
# Defined at file scope because nested roles can't live inside a
# parametric role body. Exposed as module-level constants under the
# short names C<Some> and C<None>.
role Monad::Maybe::Some { has $.type = 'Some' }
role Monad::Maybe::None { has $.type = 'None' }

our constant Some is export = Monad::Maybe::Some;
our constant None is export = Monad::Maybe::None;

# Every combinator rebuilds the type it returns from the `maybe-type`
# hook, so the obvious implementation re-parameterises that role on every
# call — and a constructor also re-mixes the Some / None marker onto every
# value it builds. That is meta-object work on the hot path of an
# otherwise trivial operation, and meta-object work that several threads
# can end up doing for the same type at the same moment. The set of types
# a program actually uses is small and fixed, so each one is built once
# and reused from there on.
#
# Writes go through $type-lock: whichever thread arrives first builds the
# type and every other thread takes what it built, so each distinct type
# is constructed exactly once per process. Reads are deliberately
# lock-free — the cache is published as an immutable Map, and a write
# installs a *new* Map rather than mutating the live one, so a reader
# either sees an entry or does not, never a half-written hash. Guarding
# the read path instead would funnel every monadic operation in the
# process through a single mutex, which costs considerably more than the
# work it protects.
#
# Keys compose the .WHICH of each type involved rather than its .^name:
# two types can share a name, and telling a subtype's family apart from
# the base one is the entire point of the type hooks. Every cached value
# refers to the types its key was built from — a parameterisation holds
# its role and its arguments — so those types outlive the entry and their
# .WHICH cannot be recycled underneath it.
my $type-lock  = Lock.new;
my $type-cache = Map.new;

# Is this the absence of a memoised type, rather than a memoised type?
# Everything cached here is a type object, so it is undefined and `//`
# and `.defined` are useless for telling "nothing yet" from "a type" —
# testing definedness is exactly how a memo of a type object ends up
# recomputing itself on every call. A Map answers Nil for a key it does
# not hold and an untouched scalar holds Any; a cached value is never
# either. Identity is tested with =:= rather than ===, so this is a
# pointer comparison rather than a .WHICH round-trip. That makes the
# parameter sigilless on purpose — it has to bind what the caller has,
# not a fresh container around it — and it is why callers passing a
# scalar decontainerise it with <>, since =:= on a container compares
# the container and would answer False for anything at all.
sub absent(Mu \candidate --> Bool) {
    candidate =:= Nil || candidate =:= Any;
}

# Slow path: build and publish under the lock, re-checking first in case
# another thread won the race while this one was waiting. `&build` runs
# with the lock held, which is what serialises the meta-object work; it
# may call back into these helpers, as Raku's Lock is reentrant.
sub publish-type(Str \key, &build --> Mu) {
    $type-lock.protect({
        my \raced = $type-cache{key};

        if absent(raced) {
            my \built = build();
            my %next  = $type-cache;

            %next{key} = built;
            $type-cache = %next.Map;

            built;
        }
        else {
            raced;
        }
    });
}

# `\M` parameterised for a payload of `\T` — the type the combinators
# call their constructors on.
sub parameterized(Mu \M, Mu \T --> Mu) {
    my \key = M.WHICH ~ '|' ~ T.WHICH;
    my \hit = $type-cache{key};

    absent(hit) ?? publish-type(key, { M.^parameterize(T) }) !! hit;
}

# `\M` parameterised for `\T` and already carrying the Some marker, ready
# to be constructed from directly. Punning and mixing the marker into the
# type once here is what keeps both off every constructor call.
sub some-type(Mu \M, Mu \T --> Mu) {
    my \key = M.WHICH ~ '|' ~ T.WHICH ~ '|Some';
    my \hit = $type-cache{key};

    absent(hit)
        ?? publish-type(key, { parameterized(M, T).^pun but Monad::Maybe::Some })
        !! hit;
}

# As `some-type`, for the None marker.
sub none-type(Mu \M, Mu \T --> Mu) {
    my \key = M.WHICH ~ '|' ~ T.WHICH ~ '|None';
    my \hit = $type-cache{key};

    absent(hit)
        ?? publish-type(key, { parameterized(M, T).^pun but Monad::Maybe::None })
        !! hit;
}

# Monad::Either is resolved lazily (and memoised) rather than `use`d, so
# that Maybe and Either can convert to each other without a compile-time
# circular dependency. The require's return value is captured directly —
# a separate ::('Monad::Either') lookup would resolve against this
# compunit's GLOBALish stub for the `Monad` package and miss it.
#
# The memo is tested with `absent` and not with `//`: what it holds is a
# type object, so it is undefined, and a `//=` memo of an undefined value
# never takes — it re-ran the require on every single conversion. The
# require also runs under $type-lock, so a cold burst of conversions from
# several threads loads the module once instead of racing to load it
# concurrently. Once the memo is populated the lock is never taken again:
# reading an already-published type object needs no guarding.
my $EITHER-TYPE;
sub default-either-type() {
    return $EITHER-TYPE unless absent($EITHER-TYPE<>);

    $type-lock.protect({
        $EITHER-TYPE = (require ::('Monad::Either')) if absent($EITHER-TYPE<>);

        $EITHER-TYPE;
    });
}

#| The Maybe monad — represents a value that may or may not be present.
#|
#| Parameterized by C<::T>, the type of the contained value. Defaults to
#| C<Any>, so C<Monad::Maybe.some(42)> (without brackets) works unchanged.
#|
#|     # Untyped — any value
#|     my $a = Monad::Maybe.some('hi');
#|
#|     # Typed — compile-time checking on the payload
#|     my Monad::Maybe[Int] $b = Monad::Maybe[Int].some(42);
#|     my $c = Monad::Maybe[Int].none;
#|
#| C<map> is a lawful functor map (it never turns a Some into a None) and
#| C<unit> is total (it never inspects the value). To build a Maybe from a
#| possibly-undefined value, use C<from-defined>.
#|
#| Implemented as a parametric role — Raku doesn't support parametric
#| classes. Role auto-punning means C<~~> and C<isa-ok> against the bare
#| C<Monad::Maybe> name still work.
role Monad::Maybe[::T = Any] is Monad {
    has T $.value;

    #| The Maybe type this value's own operations build — the one hook a
    #| subtype overrides to make every combinator return B<its> type
    #| rather than this one. Returns the unparameterized type; callers
    #| re-parameterize it (C<M.^parameterize(T)>) as the operation requires.
    #|
    #| Overriding it is the whole of what a Maybe subtype has to do:
    #|
    #|     role My::Maybe[::T = Any] does Monad::Maybe[T] {
    #|         method maybe-type(--> Mu)  { My::Maybe  }
    #|         method either-type(--> Mu) { My::Either }
    #|     }
    #|
    #| ...after which C<My::Maybe.some(1).map(* + 1)> is a C<My::Maybe>,
    #| and so is every other link in the chain.
    method maybe-type(--> Mu) { Monad::Maybe }

    #| The Either type C<to-either> builds. Same hook, other side of the
    #| conversion: a subtype that has its own Either counterpart names it
    #| here so C<to-either> stays inside the subtype's family.
    method either-type(--> Mu) { default-either-type() }

    #| The contained value, or a fatal error when called on a None.
    #| Partial by design (Haskell's C<fromJust>) — reach for
    #| C<get-or-else> or C<fold> when you need a total eliminator.
    #|
    #|     Monad::Maybe.some(42).unwrap;   # 42
    #|     Monad::Maybe.none.unwrap;       # dies
    method unwrap {
        die "Cannot unwrap a None: use get-or-else, fold, or check is-some first"
            if self.is-none;

        $!value;
    }

    #| True when this Maybe holds a value.
    #|
    #|     Monad::Maybe.some(1).is-some;   # True
    method is-some {
        self ~~ Monad::Maybe::Some;
    }

    #| True when this Maybe is empty.
    #|
    #|     Monad::Maybe.none.is-none;      # True
    method is-none {
        self ~~ Monad::Maybe::None;
    }

    #| Monadic bind. C<&f> receives the contained value and must return a
    #| Maybe; a None short-circuits and C<&f> is never called.
    #|
    #|     Monad::Maybe.some(4).bind(-> $v { Monad::Maybe.some($v * 2) });  # Some(8)
    #|     Monad::Maybe.none.bind(-> $v { Monad::Maybe.some($v * 2) });     # None
    method bind(&f --> Monad:D) {
        return self if self.is-none;

        f($!value);
    }

    #| Functor map. C<&f> takes and returns bare values. A Some always
    #| stays a Some — even when C<&f> returns an undefined value — and a
    #| None always stays a None.
    #|
    #| Lawful C<fmap> has signature C<f a -> f b> — C<&f> is free to
    #| change the payload type, so the result is an C<Any>-parameterized
    #| C<Monad::Maybe> rather than one reusing C<T>, whatever C<T> was.
    #|
    #|     Monad::Maybe.some(4).map(* * 2);      # Some(8)
    #|     Monad::Maybe.some(4).map({ Nil });    # Some(Any) — still Some
    #|     Monad::Maybe.none.map(* * 2);         # None
    method map(&f) {
        return self if self.is-none;

        my \M = parameterized(self.maybe-type, Any);

        M.some(f($!value));
    }

    #| Total eliminator: the contained value, or C<$default> for a None.
    #| C<$default> is evaluated eagerly by the caller.
    #|
    #|     Monad::Maybe.some(42).get-or-else(0);   # 42
    #|     Monad::Maybe.none.get-or-else(0);       # 0
    method get-or-else($default) {
        self.is-some ?? $!value !! $default;
    }

    #| Catamorphism. Exactly one branch runs: C<:none> is a thunk taking
    #| no arguments, C<:some> receives the contained value. Both are
    #| required, so neither case can be forgotten.
    #|
    #|     Monad::Maybe.some(3).fold(
    #|         none => { 'nothing' },
    #|         some => -> $v { "got $v" },
    #|     );                                      # 'got 3'
    method fold(:&none!, :&some!) {
        self.is-some ?? some($!value) !! none();
    }

    #| Keep a Some only when C<&pred> holds for its value; otherwise
    #| None. A None passes through untouched and C<&pred> is not called.
    #|
    #|     Monad::Maybe.some(4).filter(* %% 2);    # Some(4)
    #|     Monad::Maybe.some(3).filter(* %% 2);    # None
    method filter(&pred) {
        return self if self.is-none;

        pred($!value) ?? self !! self.none;
    }

    #| Convert to an Either: Some(x) becomes Right(x), None becomes
    #| Left($left). The result is an unparameterized C<Monad::Either>.
    #|
    #|     Monad::Maybe.some(42).to-either('missing');  # Right(42)
    #|     Monad::Maybe.none.to-either('missing');      # Left(missing)
    method to-either($left --> Monad) {
        my \E = self.either-type;

        self.is-some ?? E.right($!value) !! E.left($left);
    }

    #| Human-readable rendering: C<Some(value)> or C<None>.
    method gist {
        return self.^name unless self.defined;

        self.is-some ?? "Some({$!value.gist})" !! "None";
    }

    # The constructors below build from `self.maybe-type` re-parameterized,
    # never from `self` directly. These are class methods that are also
    # reachable on instances (map/filter call them), and `self.new(...)
    # but Marker` would mix the new marker on top of whatever the
    # invocant already carried — so `$some.none` came back matching both
    # Some and None, and a chain of maps grew one mixin per step. Naming
    # the parameterisation gives exactly one type per T, whichever way
    # the value was built; taking that name from the `maybe-type` hook
    # rather than hard-coding `Monad::Maybe` is what lets a subtype keep
    # its own type all the way along a chain.
    #
    # `some-type` / `none-type` hand back that parameterisation with the
    # marker already mixed into it, so constructing is a plain `.new` on
    # a type built once rather than a fresh mixin per value. The result
    # is the same type either way — `Monad::Maybe[T]+{...::Some}` — so
    # nothing downstream can tell the difference.

    #| Build a Some around C<$value>, whatever it is — including an
    #| undefined value.
    #|
    #|     Monad::Maybe.some('hi');        # Some(hi)
    #|     Monad::Maybe[Int].some(42);     # Some(42), payload checked as Int
    method some($value --> Monad::Maybe) {
        some-type(self.maybe-type, T).new(:$value);
    }

    #| Build an empty Maybe.
    #|
    #|     Monad::Maybe.none;              # None
    method none(--> Monad::Maybe) {
        none-type(self.maybe-type, T).new();
    }

    #| Monadic C<pure>/C<return>: lift a value into a Maybe. Total — it
    #| never inspects the value, so C<unit(Nil)> is a Some. This is what
    #| makes the left-identity law hold for undefined values.
    #|
    #|     Monad::Maybe.unit(42);          # Some(42)
    #|     Monad::Maybe.unit(Nil);         # Some(Any) — still Some
    method unit($value --> Monad::Maybe) {
        self.some($value);
    }

    #| Lift a possibly-absent value: defined values become Some, undefined
    #| values become None. The right constructor for lookups and other
    #| APIs that signal absence with an undefined value.
    #|
    #|     Monad::Maybe.from-defined(%h{$k});          # Some(v) or None
    #|     Monad::Maybe[Str].from-defined(Str);        # None
    method from-defined($value --> Monad::Maybe) {
        $value.defined ?? self.some($value) !! self.none;
    }

    #| Turn a list of Maybes into a Maybe of a list: Some of every value
    #| when they are all Some, None as soon as one is None. The result is
    #| an unparameterized C<Monad::Maybe> holding a C<List>, because the
    #| payload type is a list of C<T> rather than a C<T>.
    #|
    #|     Monad::Maybe.sequence([Monad::Maybe.some(1), Monad::Maybe.some(2)]);
    #|     # Some((1 2))
    #|     Monad::Maybe.sequence([Monad::Maybe.some(1), Monad::Maybe.none]);
    #|     # None
    method sequence(@maybes --> Monad::Maybe) {
        my \M = parameterized(self.maybe-type, Any);
        my @values;

        for @maybes -> $m {
            die "Monad::Maybe.sequence expects Monad::Maybe elements, got {$m.^name}"
                unless $m ~~ Monad::Maybe;

            return M.none if $m.is-none;

            @values.push($m.unwrap);
        }

        M.some(@values.List);
    }

    #| Map C<&f> (a value to a Maybe) over C<@xs> and sequence the
    #| results, stopping at the first None — C<&f> is not called for the
    #| remaining elements.
    #|
    #|     Monad::Maybe.traverse([1, 2, 3, 4], -> $n {
    #|         $n < 3 ?? Monad::Maybe.some($n * 2) !! Monad::Maybe.none
    #|     });                                     # None — &f never sees 4
    method traverse(@xs, &f --> Monad::Maybe) {
        my \M = parameterized(self.maybe-type, Any);
        my @values;

        for @xs -> $x {
            my $m = f($x);

            die "Monad::Maybe.traverse expects &f to return a Monad::Maybe, got {$m.^name}"
                unless $m ~~ Monad::Maybe;

            return M.none if $m.is-none;

            @values.push($m.unwrap);
        }

        M.some(@values.List);
    }
}

=begin pod

=head1 NAME

Monad::Maybe - the Maybe monad: a value that is either present or absent

=head1 SYNOPSIS

=begin code :lang<raku>

use Monad;
use Monad::Maybe;

sub lookup-age(Str $name --> Monad::Maybe[Int]) {
    my %ages = alice => 30, bob => 41;
    Monad::Maybe[Int].from-defined(%ages{$name});
}

say lookup-age('alice')
    .map(* + 1)                          # Some(31)
    .filter(* > 18)                      # Some(31)
    .get-or-else(0);                     # 31

say lookup-age('carol').get-or-else(0);  # 0

# Pattern-match both cases at once
say lookup-age('bob').fold(
    none => { 'unknown' },
    some => -> $age { "age $age" },
);                                       # age 41

=end code

=head1 DESCRIPTION

C<Monad::Maybe[T]> models an optional C<T>. It has exactly two shapes:
C<Some>, which carries a value, and C<None>, which carries nothing.
Compared with using an undefined value directly, a Maybe makes absence
explicit in the signature and forces the consumer to say what should
happen when the value is missing.

The type parameter defaults to C<Any>, so C<Monad::Maybe.some(42)>
works without brackets. When you do supply one, the payload is
type-checked at construction:

=begin code :lang<raku>

my $m = Monad::Maybe[Int].some('nope');   # throws — Str is not Int

=end code

Maybe follows the standard functional semantics, so what you know from
Haskell's C<Maybe> or Scala's C<Option> transfers directly:

=item C<map> is a functor map. C<Some> stays C<Some>, C<None> stays C<None>, always.
=item C<unit> is C<pure>. It is total: it lifts any value, defined or not.
=item C<unwrap> is C<fromJust>. It is partial and dies loudly on a C<None>.
=item C<from-defined> is the lifting constructor for APIs that signal absence with an undefined value.

=head2 Constructors

=begin code :lang<raku>

Monad::Maybe.some(42);                   # Some(42)
Monad::Maybe.none;                       # None
Monad::Maybe.unit(42);                   # Some(42)   — pure, total
Monad::Maybe.unit(Nil);                  # Some(Any)  — still a Some
Monad::Maybe.from-defined(42);           # Some(42)
Monad::Maybe.from-defined(Nil);          # None

=end code

Note that assigning an undefined value to a typed attribute normalises
it to that type's type object, so C<Monad::Maybe[Int].some(Nil).unwrap>
is C<Int> rather than C<Nil>. It is still undefined, and still a C<Some>.

=head2 Inspecting

=begin code :lang<raku>

my $m = Monad::Maybe.some('hi');

$m.is-some;                              # True
$m.is-none;                              # False
$m ~~ Some;                              # True  — exported marker role
$m.value;                                # hi    — raw attribute, no checking
$m.unwrap;                               # hi    — dies on a None
$m.gist;                                 # Some(hi)

=end code

=head2 Transforming

=begin code :lang<raku>

Monad::Maybe.some(4).map(* * 2);         # Some(8)
Monad::Maybe.none.map(* * 2);            # None

Monad::Maybe.some(4).bind(-> $v { Monad::Maybe.some($v * 2) });   # Some(8)
Monad::Maybe.none.bind(-> $v { Monad::Maybe.some($v * 2) });      # None

Monad::Maybe.some(4).filter(* %% 2);     # Some(4)
Monad::Maybe.some(3).filter(* %% 2);     # None

# The exported infix operators do the same thing
Monad::Maybe.some(4) >>- * * 2;                                   # Some(8)
Monad::Maybe.some(4) >>= -> $v { Monad::Maybe.some($v * 2) };     # Some(8)

=end code

C<map> never collapses a C<Some>. If C<&f> returns an undefined value
you get C<Some(Any)>, not C<None> — mapping is not allowed to change the
shape of the container. When you want the collapsing behaviour, say so:

=begin code :lang<raku>

$m.bind({ Monad::Maybe.from-defined(risky($_)) });

=end code

Type parameterization is a constructor-side constraint, not something
C<map> preserves — lawful C<fmap> has signature C<f a -> f b>, and
C<&f> is free to change the payload type. C<map> on a typed
C<Monad::Maybe[T]> therefore returns an C<Any>-parameterized
C<Monad::Maybe>, the same way C<sequence>/C<traverse> already do:

=begin code :lang<raku>

my Monad::Maybe[Int] $age = Monad::Maybe[Int].some(30);
$age.map(*.Str).^name;              # Monad::Maybe[Any]+{...}, not [Int] or [Str]
$age.map(*.Str) ~~ Some;            # True — still smart-matches fine

=end code

=head2 Eliminating

=begin code :lang<raku>

Monad::Maybe.some(42).get-or-else(0);    # 42
Monad::Maybe.none.get-or-else(0);        # 0

Monad::Maybe.none.fold(
    none => { 'empty' },
    some => -> $v { "value $v" },
);                                       # empty

Monad::Maybe.some(42).to-either('missing');   # Right(42)
Monad::Maybe.none.to-either('missing');       # Left(missing)

=end code

=head2 Collections

C<sequence> and C<traverse> are class methods. Both return an
unparameterized C<Monad::Maybe> whose payload is a C<List>.

=begin code :lang<raku>

Monad::Maybe.sequence([Monad::Maybe.some(1), Monad::Maybe.some(2)]);
# Some((1 2))

Monad::Maybe.sequence([Monad::Maybe.some(1), Monad::Maybe.none]);
# None

# Parse every field, or fail as a whole on the first bad one
Monad::Maybe.traverse(<1 2 x 4>, -> $s {
    $s ~~ /^ \d+ $/ ?? Monad::Maybe.some(+$s) !! Monad::Maybe.none
});
# None — the callback is never called for '4'

=end code

=head1 LAWS

C<Monad::Maybe> satisfies the monad laws, comparing values by their
C<is-some>/C<is-none> state and their contents:

=item Left identity — C<Monad::Maybe.unit($x).bind(&f)> equals C<f($x)>, for any C<$x> including an undefined one.
=item Right identity — C<$m.bind(-> $v { Monad::Maybe.unit($v) })> equals C<$m>.
=item Associativity — C<< $m.bind(&f).bind(&g) >> equals C<< $m.bind(-> $v { f($v).bind(&g) }) >>.

And the functor laws:

=item Identity — C<$m.map({ $_ })> equals C<$m>.
=item Composition — C<< $m.map(&f).map(&g) >> equals C<< $m.map(&g o &f) >>.

The functor laws are exactly why C<map> cannot collapse a C<Some> whose
mapped value happens to be undefined: C<< $m.map({ Nil }).map({ 'x' }) >>
has to equal C<< $m.map({ 'x' }) >>, and it only does if the first C<map>
leaves a C<Some> behind.

=head1 MIGRATION FROM 0.2

Version 0.3.0 is a breaking release. Three behaviours changed and one
method was added to replace the old one:

=head2 map no longer collapses undefined results

=begin code :lang<raku>

# 0.2: Some(4).map({ Nil }) === None
# 0.3: Some(4).map({ Nil }) === Some(Any)

# If you relied on the old behaviour, ask for it explicitly:
$m.bind({ Monad::Maybe.from-defined(f($_)) });

# ...or filter afterwards:
$m.map(&f).filter(*.defined);

=end code

=head2 unit is total; use from-defined for the old behaviour

=begin code :lang<raku>

# 0.2: Monad::Maybe.unit(Nil) === None
# 0.3: Monad::Maybe.unit(Nil) === Some(Any)

# Old call sites that fed unit a possibly-undefined value become:
Monad::Maybe.from-defined($maybe-undefined);

=end code

C<unit> had to become total for left identity to hold — a C<pure> that
inspects its argument is not a monadic C<pure>.

=head2 unwrap dies on None

=begin code :lang<raku>

# 0.2: Monad::Maybe.none.unwrap === Nil
# 0.3: Monad::Maybe.none.unwrap dies

# Total replacements:
$m.get-or-else($fallback);
$m.fold(none => { $fallback }, some => -> $v { $v });

# Or guard first:
$m.unwrap if $m.is-some;

=end code

C<.value> still returns the raw attribute without checking, so
C<$m.value> remains an undefined-valued escape hatch where you truly
want one.

=head2 Everything else is unchanged

Constructors (C<some>, C<none>), predicates (C<is-some>, C<is-none>),
C<bind>, the exported C<Some>/C<None> marker roles, C<< >>= >>/C<< >>- >>,
parametric usage (C<Monad::Maybe[Int]>) and C<~~ Monad::Maybe>
smart-matching all behave exactly as they did in 0.2.

=head1 SEE ALSO

C<Monad::Either> — the two-sided sibling, for absence that carries a
reason. C<Monad::Maybe.to-either> and C<Monad::Either.to-maybe> convert
between them.

=head1 AUTHOR

Matt Doughty <matt@apogee.guru>

=head1 COPYRIGHT AND LICENSE

Copyright 2024–2026 Matt Doughty

This library is free software; you can redistribute it and/or modify it
under the Artistic License 2.0.

=end pod
