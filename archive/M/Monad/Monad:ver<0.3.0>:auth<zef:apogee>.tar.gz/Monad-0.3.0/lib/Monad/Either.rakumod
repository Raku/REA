use Monad;

# Marker roles for the Left / Right variants. Defined at file scope so
# they can be referenced from inside the parametric role body.
role Monad::Either::Left  { has $.type = 'Left'  }
role Monad::Either::Right { has $.type = 'Right' }

our constant Left  is export = Monad::Either::Left;
our constant Right is export = Monad::Either::Right;

# Every combinator rebuilds the type it returns from the `either-type`
# hook, so the obvious implementation re-parameterises that role on every
# call — and a constructor also re-mixes the Left / Right marker onto
# every value it builds. That is meta-object work on the hot path of an
# otherwise trivial operation, and meta-object work that several threads
# can end up doing for the same type at the same moment. The set of types
# a program actually uses is small and fixed, so each one is built once
# and reused from there on.
#
# Writes go through $type-lock: whichever thread arrives first builds the
# type and every other thread takes what it built, so each distinct type
# is constructed exactly once per process. Reads are deliberately
# lock-free — the cache is published as an immutable Map, and a write
# installs a *new* Map rather than mutating the live one, so a reader
# either sees an entry or does not, never a half-written hash. Guarding
# the read path instead would funnel every monadic operation in the
# process through a single mutex, which costs considerably more than the
# work it protects.
#
# Keys compose the .WHICH of each type involved rather than its .^name:
# two types can share a name, and telling a subtype's family apart from
# the base one is the entire point of the type hooks. Every cached value
# refers to the types its key was built from — a parameterisation holds
# its role and its arguments — so those types outlive the entry and their
# .WHICH cannot be recycled underneath it.
my $type-lock  = Lock.new;
my $type-cache = Map.new;

# Is this the absence of a memoised type, rather than a memoised type?
# Everything cached here is a type object, so it is undefined and `//`
# and `.defined` are useless for telling "nothing yet" from "a type" —
# testing definedness is exactly how a memo of a type object ends up
# recomputing itself on every call. A Map answers Nil for a key it does
# not hold and an untouched scalar holds Any; a cached value is never
# either. Identity is tested with =:= rather than ===, so this is a
# pointer comparison rather than a .WHICH round-trip. That makes the
# parameter sigilless on purpose — it has to bind what the caller has,
# not a fresh container around it — and it is why callers passing a
# scalar decontainerise it with <>, since =:= on a container compares
# the container and would answer False for anything at all.
sub absent(Mu \candidate --> Bool) {
    candidate =:= Nil || candidate =:= Any;
}

# Slow path: build and publish under the lock, re-checking first in case
# another thread won the race while this one was waiting. `&build` runs
# with the lock held, which is what serialises the meta-object work; it
# may call back into these helpers, as Raku's Lock is reentrant.
sub publish-type(Str \key, &build --> Mu) {
    $type-lock.protect({
        my \raced = $type-cache{key};

        if absent(raced) {
            my \built = build();
            my %next  = $type-cache;

            %next{key} = built;
            $type-cache = %next.Map;

            built;
        }
        else {
            raced;
        }
    });
}

# `\E` parameterised for a left of `\L` and a right of `\R` — the type
# the combinators call their constructors on. Order matters: `swap`
# asks for the transposed pair, which is a different entry.
sub parameterized(Mu \E, Mu \L, Mu \R --> Mu) {
    my \key = E.WHICH ~ '|' ~ L.WHICH ~ '|' ~ R.WHICH;
    my \hit = $type-cache{key};

    absent(hit) ?? publish-type(key, { E.^parameterize(L, R) }) !! hit;
}

# `\E` parameterised for `\L` and `\R` and already carrying the Left
# marker, ready to be constructed from directly. Punning and mixing the
# marker into the type once here is what keeps both off every
# constructor call.
sub left-type(Mu \E, Mu \L, Mu \R --> Mu) {
    my \key = E.WHICH ~ '|' ~ L.WHICH ~ '|' ~ R.WHICH ~ '|Left';
    my \hit = $type-cache{key};

    absent(hit)
        ?? publish-type(key, { parameterized(E, L, R).^pun but Monad::Either::Left })
        !! hit;
}

# As `left-type`, for the Right marker.
sub right-type(Mu \E, Mu \L, Mu \R --> Mu) {
    my \key = E.WHICH ~ '|' ~ L.WHICH ~ '|' ~ R.WHICH ~ '|Right';
    my \hit = $type-cache{key};

    absent(hit)
        ?? publish-type(key, { parameterized(E, L, R).^pun but Monad::Either::Right })
        !! hit;
}

# Monad::Maybe is resolved lazily (and memoised) rather than `use`d, so
# that Either and Maybe can convert to each other without a compile-time
# circular dependency. The require's return value is captured directly —
# a separate ::('Monad::Maybe') lookup would resolve against this
# compunit's GLOBALish stub for the `Monad` package and miss it.
#
# The memo is tested with `absent` and not with `//`: what it holds is a
# type object, so it is undefined, and a `//=` memo of an undefined value
# never takes — it re-ran the require on every single conversion. The
# require also runs under $type-lock, so a cold burst of conversions from
# several threads loads the module once instead of racing to load it
# concurrently. Once the memo is populated the lock is never taken again:
# reading an already-published type object needs no guarding.
my $MAYBE-TYPE;
sub default-maybe-type() {
    return $MAYBE-TYPE unless absent($MAYBE-TYPE<>);

    $type-lock.protect({
        $MAYBE-TYPE = (require ::('Monad::Maybe')) if absent($MAYBE-TYPE<>);

        $MAYBE-TYPE;
    });
}

#| The Either monad — represents a value that is one of two types.
#| Conventionally C<Left> carries an error and C<Right> carries success.
#|
#| Parameterized by C<::L> (left type) and C<::R> (right type). Both
#| default to C<Any>, so C<Monad::Either.left(...)> / C<.right(...)>
#| work without brackets.
#|
#|     # Untyped
#|     my $a = Monad::Either.right(42);
#|
#|     # Typed: error is Str, success is Int
#|     my $b = Monad::Either[Str, Int].right(42);
#|     my $c = Monad::Either[Str, Int].left('nope');
#|
#| Every operation is right-biased: C<bind>, C<map>, C<get-or-else> and
#| C<unit> act on the Right and pass a Left through untouched. Use
#| C<map-left> / C<bimap> / C<swap> to work on the Left.
#|
#| The stored value can be of either L or R depending on variant, so
#| internally it remains untyped — the type parameters document intent
#| and constrain the C<left> / C<right> constructors.
role Monad::Either[::L = Any, ::R = Any] is Monad {
    has $.value;

    #| The Either type this value's own operations build — the one hook a
    #| subtype overrides to make every combinator return B<its> type
    #| rather than this one. Returns the unparameterized type; callers
    #| re-parameterize it — C<E.^parameterize(L, R)>, or
    #| C<E.^parameterize(R, L)> for a swap — as the operation requires.
    #|
    #| Overriding it is the whole of what an Either subtype has to do:
    #|
    #|     role My::Either[::L = Any, ::R = Any] does Monad::Either[L, R] {
    #|         method either-type(--> Mu) { My::Either }
    #|         method maybe-type(--> Mu)  { My::Maybe  }
    #|     }
    #|
    #| ...after which C<My::Either.right(1).map(* + 1)> is a C<My::Either>,
    #| and so is every other link in the chain.
    method either-type(--> Mu) { Monad::Either }

    #| The Maybe type C<to-maybe> builds. Same hook, other side of the
    #| conversion: a subtype that has its own Maybe counterpart names it
    #| here so C<to-maybe> stays inside the subtype's family.
    method maybe-type(--> Mu) { default-maybe-type() }

    #| The Right value, or a fatal error when called on a Left.
    #|
    #|     Monad::Either.right(42).unwrap-right;   # 42
    #|     Monad::Either.left('no').unwrap-right;  # dies
    method unwrap-right {
        self.is-right
            ?? $!value
            !! die "Tried to unwrap-right on a Left({$!value.gist})";
    }

    #| The Left value, or a fatal error when called on a Right.
    #|
    #|     Monad::Either.left('no').unwrap-left;   # no
    #|     Monad::Either.right(42).unwrap-left;    # dies
    method unwrap-left {
        self.is-left
            ?? $!value
            !! die "Tried to unwrap-left on a Right({$!value.gist})";
    }

    #| True when this Either holds a Left (conventionally, an error).
    #|
    #|     Monad::Either.left('no').is-left;       # True
    method is-left {
        self ~~ Monad::Either::Left;
    }

    #| True when this Either holds a Right (conventionally, a success).
    #|
    #|     Monad::Either.right(42).is-right;       # True
    method is-right {
        self ~~ Monad::Either::Right;
    }

    #| Monadic bind, right-biased. C<&f> receives the Right value and
    #| must return an Either; a Left short-circuits and C<&f> is never
    #| called.
    #|
    #|     Monad::Either.right(4).bind(-> $v { Monad::Either.right($v * 2) });  # Right(8)
    #|     Monad::Either.left('no').bind(-> $v { Monad::Either.right($v) });    # Left(no)
    method bind(&f --> Monad:D) {
        return self if self.is-left;

        f($!value);
    }

    #| Functor map, right-biased. C<&f> takes and returns bare values; a
    #| Left passes through untouched.
    #|
    #| Lawful C<fmap> has signature C<f a -> f b> — C<&f> is free to
    #| change the Right payload type, so the result is an
    #| C<Any>-parameterized C<Monad::Either> rather than one reusing
    #| C<L>/C<R>, whatever they were.
    #|
    #|     Monad::Either.right(4).map(* * 2);      # Right(8)
    #|     Monad::Either.left('no').map(* * 2);    # Left(no)
    method map(&f) {
        return self if self.is-left;

        my \E = parameterized(self.either-type, Any, Any);

        E.right(f($!value));
    }

    #| Map over the Left side only; a Right passes through untouched.
    #| Useful for enriching or translating errors mid-chain. Like
    #| C<map>, the result is an C<Any>-parameterized C<Monad::Either>.
    #|
    #|     Monad::Either.left('no').map-left(*.uc);    # Left(NO)
    #|     Monad::Either.right(4).map-left(*.uc);      # Right(4)
    method map-left(&f) {
        return self if self.is-right;

        my \E = parameterized(self.either-type, Any, Any);

        E.left(f($!value));
    }

    #| Map both sides at once with whichever function matches this
    #| Either's side. Exactly one of C<&left> / C<&right> is called.
    #| Like C<map>, the result is an C<Any>-parameterized
    #| C<Monad::Either>.
    #|
    #|     Monad::Either.left('no').bimap(*.uc, * * 2);    # Left(NO)
    #|     Monad::Either.right(4).bimap(*.uc, * * 2);      # Right(8)
    method bimap(&left, &right) {
        my \E = parameterized(self.either-type, Any, Any);

        self.is-left
            ?? E.left(left($!value))
            !! E.right(right($!value));
    }

    #| Total eliminator, right-biased: the Right value, or C<$default>
    #| for a Left. C<$default> is evaluated eagerly by the caller.
    #|
    #|     Monad::Either.right(42).get-or-else(0);     # 42
    #|     Monad::Either.left('no').get-or-else(0);    # 0
    method get-or-else($default) {
        self.is-right ?? $!value !! $default;
    }

    #| Catamorphism. Exactly one branch runs, and each receives the
    #| corresponding side's value. Both are required, so neither case
    #| can be forgotten.
    #|
    #|     Monad::Either.left('boom').fold(
    #|         left  => -> $e { "error: $e" },
    #|         right => -> $v { "ok: $v" },
    #|     );                                          # 'error: boom'
    method fold(:&left!, :&right!) {
        self.is-left ?? left($!value) !! right($!value);
    }

    #| Exchange the sides: a Left becomes a Right and vice versa. On a
    #| typed Either the type parameters swap with it, so
    #| C<Monad::Either[Str, Int]> swaps to C<Monad::Either[Int, Str]>.
    #|
    #|     Monad::Either.left('no').swap;              # Right(no)
    #|     Monad::Either.right(42).swap;               # Left(42)
    method swap(--> Monad::Either) {
        my \E = parameterized(self.either-type, R, L);

        self.is-left
            ?? E.right($!value)
            !! E.left($!value);
    }

    #| Convert to a Maybe, discarding any Left value: Right(x) becomes
    #| Some(x), Left becomes None. The result is an unparameterized
    #| C<Monad::Maybe>.
    #|
    #|     Monad::Either.right(42).to-maybe;           # Some(42)
    #|     Monad::Either.left('no').to-maybe;          # None
    method to-maybe(--> Monad) {
        my \M = self.maybe-type;

        self.is-right ?? M.some($!value) !! M.none;
    }

    #| Human-readable rendering: C<Right(value)> or C<Left(value)>.
    method gist {
        return self.^name unless self.defined;

        self.is-right ?? "Right({$!value.gist})" !! "Left({$!value.gist})";
    }

    # The constructors below build from `self.either-type` re-parameterized,
    # never from `self` directly. These are class methods that are also
    # reachable on instances (map/map-left/bimap call them), and
    # `self.new(...) but Marker` would mix the new marker on top of
    # whatever the invocant already carried — so `$right.left(...)` came
    # back matching both Left and Right, and a chain of maps grew one
    # mixin per step. Naming the parameterisation gives exactly one type
    # per (L, R), whichever way the value was built; taking that name
    # from the `either-type` hook rather than hard-coding
    # `Monad::Either` is what lets a subtype keep its own type all the
    # way along a chain.
    #
    # `left-type` / `right-type` hand back that parameterisation with the
    # marker already mixed into it, so constructing is a plain `.new` on
    # a type built once rather than a fresh mixin per value. The result
    # is the same type either way — `Monad::Either[L, R]+{...::Left}` —
    # so nothing downstream can tell the difference.

    #| Build a Left around C<$value>, type-checked against C<L>.
    #|
    #|     Monad::Either.left('boom');                 # Left(boom)
    #|     Monad::Either[Str, Int].left('boom');       # Left(boom)
    method left(L $value --> Monad::Either) {
        left-type(self.either-type, L, R).new(:$value);
    }

    #| Build a Right around C<$value>, type-checked against C<R>.
    #|
    #|     Monad::Either.right(42);                    # Right(42)
    #|     Monad::Either[Str, Int].right(42);          # Right(42)
    method right(R $value --> Monad::Either) {
        right-type(self.either-type, L, R).new(:$value);
    }

    #| Monadic C<pure>/C<return>: lift a value into the Right side.
    #| Total — it never inspects the value.
    #|
    #|     Monad::Either.unit(42);                     # Right(42)
    method unit($value --> Monad::Either) {
        self.right($value);
    }

    #| Turn a list of Eithers into an Either of a list: Right of every
    #| value when they are all Right, otherwise the first Left itself —
    #| identity and all — so the error survives. The Right result is an
    #| unparameterized C<Monad::Either> holding a C<List>, because the
    #| payload type is a list of C<R> rather than an C<R>.
    #|
    #|     Monad::Either.sequence([Monad::Either.right(1), Monad::Either.right(2)]);
    #|     # Right((1 2))
    #|     Monad::Either.sequence([Monad::Either.right(1), Monad::Either.left('no')]);
    #|     # Left(no)
    method sequence(@eithers --> Monad::Either) {
        my \E = parameterized(self.either-type, Any, Any);
        my @values;

        for @eithers -> $e {
            die "Monad::Either.sequence expects Monad::Either elements, got {$e.^name}"
                unless $e ~~ Monad::Either;

            return $e if $e.is-left;

            @values.push($e.unwrap-right);
        }

        E.right(@values.List);
    }

    #| Map C<&f> (a value to an Either) over C<@xs> and sequence the
    #| results, stopping at the first Left — C<&f> is not called for the
    #| remaining elements, and that Left is the result.
    #|
    #|     Monad::Either.traverse(<1 2 x 4>, -> $s {
    #|         $s ~~ /^ \d+ $/
    #|             ?? Monad::Either.right(+$s)
    #|             !! Monad::Either.left("bad: $s")
    #|     });                                         # Left(bad: x)
    method traverse(@xs, &f --> Monad::Either) {
        my \E = parameterized(self.either-type, Any, Any);
        my @values;

        for @xs -> $x {
            my $e = f($x);

            die "Monad::Either.traverse expects &f to return a Monad::Either, got {$e.^name}"
                unless $e ~~ Monad::Either;

            return $e if $e.is-left;

            @values.push($e.unwrap-right);
        }

        E.right(@values.List);
    }
}

=begin pod

=head1 NAME

Monad::Either - the Either monad: a value that is either a failure or a
success, both typed

=head1 SYNOPSIS

=begin code :lang<raku>

use Monad;
use Monad::Either;

sub parse-int(Str $s --> Monad::Either[Str, Int]) {
    $s ~~ /^ (\d+) $/
        ?? Monad::Either[Str, Int].right(+$0)
        !! Monad::Either[Str, Int].left("'$s' is not a number");
}

my $doubled = parse-int('21').map(* * 2);       # Right(42)
my $failed  = parse-int('x').map(* * 2);        # Left('x' is not a number)

say $doubled.get-or-else(0);                    # 42
say $failed.get-or-else(0);                     # 0

say $failed.fold(
    left  => -> $e { "failed: $e" },
    right => -> $v { "got $v" },
);                                              # failed: 'x' is not a number

=end code

=head1 DESCRIPTION

C<Monad::Either[L, R]> models a computation that either failed with an
C<L> or succeeded with an C<R>. Where C<Monad::Maybe> says only "there
is no value", Either carries I<why>.

Every chaining operation is B<right-biased>: C<bind>, C<map>,
C<get-or-else> and C<unit> operate on the Right and pass a Left through
untouched, so a pipeline short-circuits on the first failure and the
original error survives to the end. The Left side is reachable through
C<map-left>, C<bimap>, C<fold> and C<swap>.

Both type parameters default to C<Any>, so C<Monad::Either.right(42)>
works without brackets. When you supply them, each constructor is
checked against its own side:

=begin code :lang<raku>

Monad::Either[Str, Int].right('nope');   # throws — Str is not Int
Monad::Either[Str, Int].left(42);        # throws — Int is not Str

=end code

=head2 Constructors

=begin code :lang<raku>

Monad::Either.right(42);                 # Right(42)
Monad::Either.left('boom');              # Left(boom)
Monad::Either.unit(42);                  # Right(42) — pure, right-biased

=end code

=head2 Inspecting

=begin code :lang<raku>

my $e = Monad::Either.left('boom');

$e.is-left;                              # True
$e.is-right;                             # False
$e ~~ Left;                              # True — exported marker role
$e.value;                                # boom  — raw attribute, side-blind
$e.unwrap-left;                          # boom
$e.unwrap-right;                         # dies
$e.gist;                                 # Left(boom)

=end code

=head2 Transforming

=begin code :lang<raku>

Monad::Either.right(4).map(* * 2);            # Right(8)
Monad::Either.left('no').map(* * 2);          # Left(no)

Monad::Either.right(4).bind(-> $v { Monad::Either.right($v * 2) });  # Right(8)

Monad::Either.left('no').map-left(*.uc);      # Left(NO)
Monad::Either.right(4).bimap(*.uc, * * 2);    # Right(8)
Monad::Either.left('no').swap;                # Right(no)

# The exported infix operators do the same thing
Monad::Either.right(4) >>- * * 2;                                    # Right(8)
Monad::Either.right(4) >>= -> $v { Monad::Either.right($v * 2) };    # Right(8)

=end code

Type parameterization is a constructor-side constraint, not something
C<map>/C<map-left>/C<bimap> preserve — lawful C<fmap> has signature
C<f a -> f b>, and the mapping function is free to change the payload
type. All three therefore return an C<Any>-parameterized
C<Monad::Either>, the same way C<sequence>/C<traverse> already do:

=begin code :lang<raku>

my $parsed = Monad::Either[Str, Int].right(42);
$parsed.map(*.Str).^name;           # Monad::Either[Any,Any]+{...}, not [Str,Int] or [Str,Str]
$parsed.map(*.Str) ~~ Right;        # True — still smart-matches fine

=end code

C<swap> is the exception: it genuinely does reparameterize to the
transposed C<[R, L]>, because exchanging the sides is exactly a type
parameter swap, not an erasure.

=head2 Eliminating

=begin code :lang<raku>

Monad::Either.right(42).get-or-else(0);       # 42
Monad::Either.left('no').get-or-else(0);      # 0

Monad::Either.left('no').fold(
    left  => -> $e { "error: $e" },
    right => -> $v { "value: $v" },
);                                            # error: no

Monad::Either.right(42).to-maybe;             # Some(42)
Monad::Either.left('no').to-maybe;            # None — the error is discarded

=end code

There is deliberately no side-blind C<unwrap>: see L</MIGRATION FROM 0.2>.

=head2 Collections

C<sequence> and C<traverse> are class methods. They collect Right values
into a C<List> and short-circuit on the first Left, which becomes the
result unchanged.

=begin code :lang<raku>

Monad::Either.sequence([Monad::Either.right(1), Monad::Either.right(2)]);
# Right((1 2))

Monad::Either.traverse(<1 2 x 4>, -> $s {
    $s ~~ /^ \d+ $/
        ?? Monad::Either.right(+$s)
        !! Monad::Either.left("bad: $s")
});
# Left(bad: x) — the callback is never called for '4'

=end code

=head1 LAWS

C<Monad::Either> satisfies the monad laws, comparing values by their
C<is-left>/C<is-right> state and their contents:

=item Left identity — C<Monad::Either.unit($x).bind(&f)> equals C<f($x)>.
=item Right identity — C<$m.bind(-> $v { Monad::Either.unit($v) })> equals C<$m>.
=item Associativity — C<< $m.bind(&f).bind(&g) >> equals C<< $m.bind(-> $v { f($v).bind(&g) }) >>.

And the functor laws, for C<map> on the Right side and C<map-left> on
the Left:

=item Identity — C<$m.map({ $_ })> equals C<$m>.
=item Composition — C<< $m.map(&f).map(&g) >> equals C<< $m.map(&g o &f) >>.

("Left identity" here is the monad law about C<unit>; it has nothing to
do with the C<Left> variant, which is exactly why the law is stated in
terms of C<unit>.)

=head1 MIGRATION FROM 0.2

Version 0.3.0 is a breaking release for Either in one respect, and adds
a set of combinators.

=head2 unwrap has been removed

C<unwrap> returned the payload regardless of which side it was on, so
C<$e.unwrap> silently handed you an error message where you expected a
result. There is no side-blind replacement — say which side you mean:

=begin code :lang<raku>

# 0.2:
my $v = $e.unwrap;

# 0.3 — pick the one that says what you meant:
my $v = $e.unwrap-right;         # dies on a Left (was the usual intent)
my $v = $e.get-or-else($fallback);
my $v = $e.fold(left => -> $err { $fallback }, right => -> $ok { $ok });
my $v = $e.value;                # raw attribute — still side-blind, but explicit

=end code

The C<.value> attribute accessor is untouched, so a genuinely
side-agnostic call site can keep working by spelling it C<.value>.

=head2 Everything else is unchanged

C<left>, C<right>, C<unit>, C<bind>, C<map>, C<is-left>, C<is-right>,
C<unwrap-left>, C<unwrap-right>, the exported C<Left>/C<Right> marker
roles, C<< >>= >>/C<< >>- >>, parametric usage
(C<Monad::Either[Str, Int]>) and C<~~ Monad::Either> smart-matching all
behave exactly as they did in 0.2. The C<unwrap-left>/C<unwrap-right>
failure messages now include the value that was there instead.

=head1 SEE ALSO

C<Monad::Maybe> — the one-sided sibling, for absence with no reason
attached. C<Monad::Either.to-maybe> and C<Monad::Maybe.to-either>
convert between them.

=head1 AUTHOR

Matt Doughty <matt@apogee.guru>

=head1 COPYRIGHT AND LICENSE

Copyright 2024–2026 Matt Doughty

This library is free software; you can redistribute it and/or modify it
under the Artistic License 2.0.

=end pod
