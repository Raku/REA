unit class Module::Toolkit::Distribution is Distribution;

has @.build-depends;
has @.test-depends;
