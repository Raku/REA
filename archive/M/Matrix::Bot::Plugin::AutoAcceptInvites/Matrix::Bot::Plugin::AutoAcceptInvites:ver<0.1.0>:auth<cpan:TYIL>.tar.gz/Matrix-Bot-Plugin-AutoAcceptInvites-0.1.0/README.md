NAME
====

Matrix::Bot::Plugin::AutoAcceptInvites

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.0.0

Description
===========

A plugin for Matrix::Bot to automatically accept all room invites

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install Matrix::Bot::Plugin::AutoAcceptInvites
```

Usage
=====

To use this plugin in your Matrix bot, include it in the `plugins` list.

    use Matrix::Bot;
    use Matrix::Bot::Plugin::AutoAcceptInvites;

    Matrix::Bot.new(
	    home-server => $*ENV<MATRIX_HOMESERVER> // "https://matrix.org",
	    username => %*ENV<USER>,
	    password => %*ENV<MATRIX_PASSWORD>,
	    plugins => [
		    Matrix::Bot::Plugin::AutoAcceptInvites.new,
	    ],
    );

License
=======

This module is distributed under the terms of the AGPL-3.0.

