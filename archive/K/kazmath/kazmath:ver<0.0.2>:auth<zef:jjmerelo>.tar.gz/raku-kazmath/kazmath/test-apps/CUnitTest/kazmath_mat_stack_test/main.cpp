//
//  main.cpp
//  kazmath_mat_stack_test
//
//  Created by Carsten Haubold on 6/08/12.
//  Copyright (c) 2012 Carsten Haubold. All rights reserved.
//

#include <stdio.h>
