# Authors

Kazmath wouldn't have been possible without the following awesome people:

 - Luke Benstead - kazade@gmail.com
 - Carsten Haubold
 - Carlos Carrasco
 - chris
 - Cloudef
 - Daniel Rosser
 - David Givone
 - David Hontecillas
 - Henry Stratmann III
 - Jari Vetoniemi
 - starbugs
 - Teemu Erkkola

