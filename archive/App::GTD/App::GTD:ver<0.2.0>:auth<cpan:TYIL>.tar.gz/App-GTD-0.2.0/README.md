NAME
====

App::GTD

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.2.0

Synopsis
========

  * gtd [--help]

  * gtd add <words...>

  * gtd inbox

  * gtd inbox <id>

  * gtd next

  * gtd next <id> [--prio[=<a..z>]] [words...]

  * gtd someday

  * gtd someday <id>

  * gtd done <id>

Description
===========

A command line application to support the [Getting Things Done](https://gettingthingsdone.com/) methodology, written using the Raku programming language.

Installation
============

Through `zef`
-------------

[zef](https://github.com/ugexe/zef) is the standard distribution manager for [Raku](https://raku.org). If you're using an end-user distribution like [Rakudo Star](https://rakudo.org/files/star), it will be installed for you by default.

`zef` will install the latest available version from [CPAN](http://www.cpan.org/modules/index.html).

```sh
zef install App::GTD
```

Documentation
=============

Documentation is available as Pod6 documents in the module. You can use a module such as [`p6doc`](https://modules.raku.org/dist/p6doc:github:perl6) or [`App::Rakuman`](https://home.tyil.nl/git/raku/App::Rakuman/) to read through it.

    rakuman App::GTD
    rakuman App::GTD::Config

Contributing
============

Reporting bugs or other feedback
--------------------------------

Any bugs or other feedback can be sent to my email address. I generally try to respond to all mail within 24 hours.

Proposing code patches
----------------------

Code patches can also be sent in through email. If you need help to send git patches through email, you may want to read up on [git-send-email.io](https://git-send-email.io/).

License
=======

This module is distributed under the terms of the GNU AGPL, version 3.0.

