NAME
====

App::GTD

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.1.0

Synopsis
========

  * `gtd <command>`

Description
===========

A Raku application aimed at helping you getting things done.

`App::GTD` uses [todo.txt](http://todotxt.org/) as storage backend, but the application itself is geared towards use with a [GTD](https://en.wikipedia.org/wiki/Getting_Things_Done) mindset.

Installation
============

Through `zef`
-------------

[zef](https://github.com/ugexe/zef) is the standard distribution manager for [Raku](https://raku.org). If you're using an end-user distribution like [Rakudo Star](https://rakudo.org/files/star), it will be installed for you by default.

`zef` will install the latest available version from [CPAN](http://www.cpan.org/modules/index.html).

```sh
zef install App::GTD
```

Contributing
============

Reporting bugs or other feedback
--------------------------------

Any bugs or other feedback can be sent to my email address. I generally try to respond to all mail within 24 hours.

Proposing code patches
----------------------

Code patches can also be sent in through email. If you need help to send git patches through email, you may want to read up on [git-send-email.io](https://git-send-email.io/).

License
=======

This module is distributed under the terms of the GNU AGPL, version 3.0.

