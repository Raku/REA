# GREEN

[About Green](http://ugexe.com/parallel-testing-and-a-perilous-pilgrimage/)
