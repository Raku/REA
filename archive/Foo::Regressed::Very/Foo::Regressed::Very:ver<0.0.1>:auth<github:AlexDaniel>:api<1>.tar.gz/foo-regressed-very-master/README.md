## Foo::Regressed

A simple module to test tooling for regression hunters.

It passes tests on old rakudo versions but segfaults on newer ones.
