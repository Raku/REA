raku --doc=Markdown ./lib/FixedInt.rakumod > ./README.md
