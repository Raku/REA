unit module Form::Types;

enum Justify is export <left right centre full>;
enum Alignment is export <top middle bottom>;
