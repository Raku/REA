
use v6;

sub sum($a, $b) {
	my $sum =  $a + $b;
	return $sum;
};

say sum(1,2);
