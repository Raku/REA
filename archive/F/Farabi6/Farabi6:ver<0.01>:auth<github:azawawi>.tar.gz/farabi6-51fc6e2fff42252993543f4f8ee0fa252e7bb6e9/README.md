Farabi6
=======

This is a fun Perl 6 port of the Farabi Modern Perl Editor:
http://metacpan.org/module/Farabi

The idea here is to experiment with a Perl 6 in-browser editor running over Rakudo Perl 6. 

Please Note that this project is highly **experimental** and may explode in your face. You have been warned :)

Have fun!

To run it without installing it:

    PERL6LIB=lib perl6 bin/farabi6

To install it using Panda:

    panda install Farabi6


