#ifndef __FT6_H
#define __FT6_H

#include "ft2build.h"

#ifdef _WIN32
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT extern
#endif

#endif /* __FT6_H */
