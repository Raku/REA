#ifndef __FT6_FACE_H
#define __FT6_FACE_H

#include "ft6.h"

#include FT_FREETYPE_H

DLLEXPORT FT_Bitmap_Size* ft6_face_get_bitmap_size(FT_Face, FT_Int);

#endif /* __FT6_FACE_H */
