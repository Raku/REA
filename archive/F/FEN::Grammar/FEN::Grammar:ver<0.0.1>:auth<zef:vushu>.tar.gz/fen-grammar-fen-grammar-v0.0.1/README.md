## Forsyth–Edwards Notation (FEN) Grammar

example:
```
use FEN::Grammar;
my $match = FEN::Grammar.parse('r1bk3r/p2pBpNp/n4n2/1p1NP2P/6P1/3P4/P1P1K3/q5b1');
```
