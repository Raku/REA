my constant @defaults = <
  !RAKUAST_MARKER !UNIT_MARKER
  $! $/ $?CHECKSUM $?FILE $?LANGUAGE-REVISION $?PACKAGE $?SOURCE $_ $¢
  ::?PACKAGE
  EXPORT GLOBALish
>;

sub EXPORT($distro, *@exports is copy) {

    # Either inclusive or exclusive exports
    if @exports {

        # Exclusive
        if @exports.head eq "!" {
            @exports.shift;
            @exports.prepend(@defaults);

            Map.new: ("use $distro; MY::\{MY::.keys.map(\{
                \$_ unless \$_ (elem) @exports
            })}:p".EVAL)
        }

        # Inclusive
        else {
            Map.new: ("use $distro; MY::<@exports[]>:p".EVAL)
        }
    }

    # Effectvely just "need"
    else {
        "use $distro".EVAL;
        BEGIN Map.new
    }
}

# vim: expandtab shiftwidth=4
