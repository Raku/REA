use v6.d;
use NativeCall;
use Terminal::Size;

# ============================================================================
# Terminal - Platform-Specific Terminal Handling
# ============================================================================
# Provides:
#   - Terminal detection (is it a TTY?)
#   - Unicode support detection
#   - Bar length calculation based on terminal width
#   - ANSI color codes
#   - Raw mode for key input (Unix: stty, Windows: Console API)
# Implementations for Unix and Win32

my constant %COLOR-DEF = 
    'reset' => "\e[0m",
    'green' => "\e[32m",
    'red' => "\e[31m",
    'yellow' => "\e[33m",
    'cyan' => "\e[36m",
    'bold' => "\e[1m";

my constant IS-WIN = $*DISTRO.is-win;

# NativeCall poll() for non-blocking stdin check (Unix only)
# poll() does not exist on Windows kernel, but we only use it in the Unix class.
# The native symbol is only resolved when actually called, and Windows uses Win32 class instead.
constant POLLIN = 1;
constant POLLERR = 0x008;
constant POLLHUP = 0x010;
constant POLLNVAL = 0x020;
constant POLL_TIMEOUT = 20;  # milliseconds

class pollfd is repr('CStruct') {
    has int32 $.fd;
    has int16 $.events;
    has int16 $.revents;
}

sub poll(pollfd $fds, uint64 $nfds, int32 $timeout) returns int32 is native { ... }
# NOTE: poll() is Unix-only (libc). Windows uses GetNumberOfConsoleInputEvents + ReadConsoleInputW instead.
# Pass struct directly (not Pointer[pollfd]) - Pointer + nativecast breaks on Android/Bionic
# NativeCall passes a pointer to the struct implicitly, which poll(2) expects.
# nfds_t is unsigned long on most platforms (64-bit), so uint64 is correct.

# ============================================================
# Windows Console API Bindings
# ============================================================
sub GetStdHandle(int32 $nStdHandle) returns Pointer[void] is native('kernel32') { ... }
sub SetConsoleTextAttribute(Pointer[void] $hConsole, int16 $wAttributes) returns int32 is native('kernel32') { ... }
sub SetConsoleOutputCP(int32 $CodePageID) returns int32 is native('kernel32') { ... }
sub GetConsoleOutputCP() returns int32 is native('kernel32') { ... }
sub GetConsoleCP() returns int32 is native('kernel32') { ... }
sub SetConsoleCP(int32 $CodePageID) returns int32 is native('kernel32') { ... }

class COORD is repr('CStruct') {
    has int16 $.X;
    has int16 $.Y;
}

class SMALL_RECT is repr('CStruct') {
    has int16 $.Left;
    has int16 $.Top;
    has int16 $.Right;
    has int16 $.Bottom;
}

class CONSOLE_SCREEN_BUFFER_INFO is repr('CStruct') {
    HAS COORD      $.dwSize;
    HAS COORD      $.dwCursorPosition;
    has int16      $.wAttributes;      # WORD
    HAS SMALL_RECT $.srWindow;
    HAS COORD      $.dwMaximumWindowSize;
}

sub GetConsoleScreenBufferInfo(Pointer[void] $hConsole, Pointer[CONSOLE_SCREEN_BUFFER_INFO] $lpConsoleScreenBufferInfo) returns int32 is native('kernel32') { ... }

sub SetConsoleMode(Pointer[void] $hConsoleHandle, uint32 $dwMode) returns int32 is native('kernel32') { ... }
sub GetConsoleMode(Pointer[void] $hConsoleHandle, Pointer[uint32] $lpMode) returns int32 is native('kernel32') { ... }
sub GetNumberOfConsoleInputEvents(Pointer[void] $hConsoleInput, Pointer[uint32] $NumberOfEvents) returns int32 is native('kernel32') { ... }
sub ReadConsoleInputW(Pointer[void] $hConsoleInput, Pointer $lpBuffer, uint32 $nLength, Pointer[uint32] $lpNumberOfEventsRead) returns int32 is native('kernel32') { ... }

# _get_osfhandle from msvcrt - converts C runtime fd to Windows console handle
sub _get_osfhandle(int32 $fd) returns Pointer[void] is native('msvcrt') { ... }

# Job Object bindings - used to ensure ffmpeg is killed if ffpb is force-killed
sub CreateJobObjectW(Pointer, Pointer) returns Pointer[void] is native('kernel32') { ... }
sub AssignProcessToJobObject(Pointer[void] $hJob, Pointer[void] $hProcess) returns int32 is native('kernel32') { ... }
sub SetInformationJobObject(Pointer[void] $hJob, int32 $JobObjectInfoClass, Pointer $lpJobObjectInfo, uint32 $cbJobObjectInfoLength) returns int32 is native('kernel32') { ... }
sub OpenProcess(uint32 $dwDesiredAccess, int32 $bInheritHandle, uint32 $dwProcessId) returns Pointer[void] is native('kernel32') { ... }
sub CloseHandle(Pointer[void] $hObject) returns int32 is native('kernel32') is export { ... }

constant ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004;
constant INVALID_HANDLE_VALUE = 0xFFFFFFFFFFFFFFFF;  # Windows INVALID_HANDLE_VALUE as unsigned 64-bit

constant KEY_EVENT = 0x0001;

constant CP_UTF8 = 65001;

# Job Object constants
constant PROCESS_ALL_ACCESS = 0x1F0FFF;
constant JobObjectExtendedLimitInformation = 9;
constant JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x2000;

# JOBOBJECT_EXTENDED_LIMIT_INFORMATION for SetInformationJobObject (class 9)
# Layout matches Windows x64 API with proper alignment.
class JOBOBJECT_EXTENDED_LIMIT_INFORMATION is repr('CStruct') {
    has int64  $.PerProcessUserTimeLimit = 0;   # 0
    has int64  $.PerJobUserTimeLimit = 0;        # 8
    has uint32 $.LimitFlags = 0;                 # 16
    has uint32 $.Align1 = 0;                     # 20 (padding)
    has uint64 $.MinimumWorkingSetSize = 0;      # 24
    has uint64 $.MaximumWorkingSetSize = 0;      # 32
    has uint32 $.ActiveProcessLimit = 0;         # 40
    has uint32 $.Align2 = 0;                     # 44 (padding)
    has uint64 $.Affinity = 0;                   # 48
    has uint32 $.PriorityClass = 0;              # 56
    has uint32 $.SchedulingClass = 0;            # 60
    has uint64 $.ReadOperationCount = 0;         # 64
    has uint64 $.WriteOperationCount = 0;        # 72
    has uint64 $.OtherOperationCount = 0;        # 80
    has uint64 $.ReadTransferCount = 0;          # 88
    has uint64 $.WriteTransferCount = 0;         # 96
    has uint64 $.OtherTransferCount = 0;         # 104
    has uint64 $.ProcessMemoryLimit = 0;         # 112
    has uint64 $.JobMemoryLimit = 0;             # 120
    has uint64 $.PeakProcessMemoryUsed = 0;      # 128
    has uint64 $.PeakJobMemoryUsed = 0;          # 136
    # Total: 144 bytes
}

# Role defining terminal capabilities (base implementation)
role FFmpegProgressBar::Terminal::Actions {
    has atomicint $!stop = 0;
    has $!reader-thread;

    method is-terminal() {
        my $in-t = try { $*IN.t } // False;
        my $out-t = try { $*OUT.t } // False;
        return False unless $in-t && $out-t;
        return False if %*ENV<CI>;  # CI environments may not fully support TTY
        return True;
    }

    method supports-unicode() {
        return False if !$*OUT.t || %*ENV<CI>;
        return True;   # default for Unix-like systems
    }

    method !stop-reader-thread() {
        if $!reader-thread.defined {
            $!stop ⚛= 1;
            try { await Promise.anyof($!reader-thread, Promise.in(0.1)) }
            $!reader-thread = Nil;
            $!stop ⚛= 0;
        }
    }

    # NOTE: This is only called once at startup (Bar.new), not in the render loop.
    # If called per-frame, terminal-width would require syscalls per frame.
    method bar-length(Int :$prefix, Int :$suffix, Int :$min, Int :$max --> Int) {
        my Int $cols = self.get-terminal-width(:default(80));
        my $len = $cols - $prefix - $suffix;
        $len max= 0;
        $len = $min if $len < $min;
        $len = $max if $len > $max;
        return $len;
    }

    method get-terminal-width(Int :$default = 80 --> Int) {
        # Try terminal-size first if stdout is a TTY (avoids throw on non-TTY)
        my $ts-width = $*OUT.t ?? try { terminal-size($*OUT).cols } !! Nil;
        return $ts-width if $ts-width.defined && $ts-width > 0;

        # Fallback: Win32 API -> %*ENV<COLUMNS>
        if IS-WIN {
            my $w = try { self.get-console-width(:$default) } // 0;
            return $w if $w > 0;
        }

        return (%*ENV<COLUMNS> // $default).Int;
    }

    method color(Str $name --> Str) { ... }

    method clear-line(--> Str) { ... }

    method clear-line-after(--> Str) { ... }

    method get-key-supply(--> Supply) { ... }

    method enter-raw-mode() { ... }

    method exit-raw-mode() { ... }

    method close-key-reader() { ... }
}

# Unix terminal implementation using stty for raw mode
class FFmpegProgressBar::Terminal::Unix does FFmpegProgressBar::Terminal::Actions {
    has Bool $!use-colors = False;
    has Str $!original = '';
    has Bool $!saved = False;

    submethod BUILD(Bool :$use-colors) {
        $!use-colors = $use-colors;
    }

    method color(Str $name --> Str) {
        return '' unless $!use-colors;
        return %COLOR-DEF{$name} // '';
    }

    method clear-line(--> Str) {
        return "\r\e[K";
    }

    method clear-line-after(--> Str) {
        return "\e[K";
    }

    # Sets up key input using poll() for non-blocking read.
    # Returns Supply of keypresses.
    method get-key-supply(--> Supply) {
        unless $!saved {
            # Raw mode not active ($!saved is False when enter-raw-mode wasn't called or failed).
            # The caller (FFmpegProgressBar.run) only subscribes to this Supply when $raw-mode-ok
            # is True, so a dead Supply here is harmless - the whenever block simply never fires.
            my $s = Supplier.new;
            $s.done;
            return $s.Supply;
        }
        self!stop-reader-thread;
        my $supplier = Supplier.new;
        my int32 $fd = $*IN.native-descriptor;
        $!reader-thread = start {
            LEAVE { try { $supplier.done } }
            loop {
                last if $!stop;
                
                # Use poll for non-blocking read - pass struct directly
                my pollfd $pfd = pollfd.new(:$fd, :events(POLLIN), :revents(0));
                my int32 $result = -1;
                # Retry on EINTR (interrupted by signal)
                for 1..3 {
                    $result = try { poll($pfd, 1, POLL_TIMEOUT) } // -1;
                    last if $result >= 0;  # Success (POLLIN) or terminal error, not retryable
                    last if $!stop;
                }
                last if $!stop;
                
                if $result > 0 {
                    my int16 $revents = $pfd.revents;
                    if $revents +& POLLIN {
                        last if $!stop;
                        my $chunk = $*IN.read(64);
                        last if $!stop;
                        if $chunk.defined && $chunk.elems {
                            for $chunk.decode('utf-8', :replace).comb -> $char {
                                last if $!stop;
                                $supplier.emit($char);
                            }
                        }
                    }
                    elsif $revents +& (POLLHUP +| POLLERR +| POLLNVAL) {
                        last;
                    }
                }
                elsif $result < 0 {
                    last;
                }
            }
        }
        return $supplier.Supply;
    }

    # Enables raw mode: saves stty settings, disables canonical mode and echo
    method enter-raw-mode() {
        return True if $!saved;
        return False unless self.is-terminal;
        my $stty-result = run('stty', '-g', :out, :err(IO::Path.new($*SPEC.devnull)));
        return False unless $stty-result.exitcode == 0;
        $!original = $stty-result.out.slurp(:close).trim;
        return False if $!original eq '';
        my $stty-set = run('stty', '-icanon', '-echo', '-echoe', '-echok', :err(IO::Path.new($*SPEC.devnull)));
        return False unless $stty-set.exitcode == 0;
        $!saved = True;
        return True;
    }

    # Restores terminal to saved settings (from enter-raw-mode)
    method exit-raw-mode() {
        return True unless $!saved;
        run('stty', $!original, :err(IO::Path.new($*SPEC.devnull))) if $!original;
        $!saved = False;
        $!original = '';
        return True;
    }

    # Gracefully stops the key reader thread by signaling stop and joining
    method close-key-reader() {
        self.exit-raw-mode if $!saved;
        $!stop ⚛= 1;
        with $!reader-thread -> $th {
            try { await Promise.anyof($th, Promise.in(0.1)) }
        }
        $!reader-thread = Nil;
        $!stop ⚛= 0;
    }

    submethod DESTROY() {
        # NOTE: Raku's GC doesn't guarantee DESTROY timing. The LEAVE block in
        # FFmpegProgressBar::run() is the real guarantee for cleanup.
        self.exit-raw-mode;
    }
}

# Windows terminal implementation using Win32 Console API
class FFmpegProgressBar::Terminal::Win32 does FFmpegProgressBar::Terminal::Actions {
    has Bool $!use-colors = False;
    has Pointer[void] $!console-out;
    has Pointer[void] $!console-in;
    has int16 $!original-attrs = 0;
    has Bool $!attrs-read = False;
    has int32 $!original-cp = 0;
    has int32 $!original-output-cp = 0;
    has Bool $!cp-set = False;
    has Bool $!unicode-supported = False;

    submethod BUILD(Bool :$use-colors) {
        $!use-colors = $use-colors;
        
        $!console-out = GetStdHandle(-11);

        # Use _get_osfhandle to convert stdin fd to console handle
        # This gives us a handle that Console API can actually use
        my int32 $stdin-fd = $*IN.native-descriptor;
        # Validate fd and handle before using
        if $stdin-fd >= 0 {
            my $handle = _get_osfhandle($stdin-fd);
            $!console-in = $handle if +$handle != INVALID_HANDLE_VALUE;
        }

        # Store original codepage and set UTF-8
        $!original-cp = GetConsoleCP();
        $!original-output-cp = GetConsoleOutputCP();
        my $cp-ok = SetConsoleCP(CP_UTF8);
        my $cp-out-ok = SetConsoleOutputCP(CP_UTF8);
        $!cp-set = ($cp-ok != 0) && ($cp-out-ok != 0);
        $*OUT.encoding('utf-8') if $!cp-set;
        $!unicode-supported = ($cp-ok != 0) && ($cp-out-ok != 0);

        if $!use-colors && $!console-out.defined {
            # Get actual console attributes to restore later
            my $csbi = self!get-console-buffer-info($!console-out);
            if $csbi {
                $!original-attrs = $csbi.wAttributes;
                $!attrs-read = True;
            }
            # Try to enable Virtual Terminal processing for ANSI colors.
            # This enables ANSI escape codes on Windows 10+ terminals.
            # On older conhost (pre-Windows 10), this silently fails - we
            # detect that and disable colors to avoid printing garbage.
            my $mode-arr = CArray[uint32].new(0);
            if GetConsoleMode($!console-out, nativecast(Pointer[uint32], $mode-arr)) {
                my uint32 $mode = $mode-arr[0];
                my int32 $vt-result = SetConsoleMode($!console-out, $mode +| ENABLE_VIRTUAL_TERMINAL_PROCESSING);
                # If VT fails (returns 0), disable colors - no fallback rendering
                $!use-colors = $vt-result != 0;
            } else {
                $!use-colors = False;  # GetConsoleMode failed - no VT support
            }
        }
    }

    method color(Str $name --> Str) {
        return '' unless $!use-colors;
        return %COLOR-DEF{$name} // '';
    }

    method clear-line(--> Str) {
        return "\r\e[K";
    }

    method clear-line-after(--> Str) {
        return "\e[K";
    }

    method supports-unicode() {
        return $!unicode-supported;
    }

    method get-key-supply(--> Supply) {
        self!stop-reader-thread;
        my $supplier = Supplier.new;
        my Pointer[void] $console-in = $!console-in;
        
        # Check if we got a valid console handle by trying GetConsoleMode
        my $is-real-console = False;
        if $console-in.defined {
            my $mode-arr = CArray[uint32].new(0);
            $is-real-console = GetConsoleMode($console-in, nativecast(Pointer[uint32], $mode-arr)) != 0;
        }
        
        if $is-real-console {
            $!reader-thread = start {
                my $num-arr = CArray[uint32].new(0);
                my $read-arr = CArray[uint32].new(0);
                my $event-buf = Buf.new(0 xx 24);
                LEAVE { try { $supplier.done } }
                loop {
                    last if $!stop;
                    # INPUT_RECORD layout (Windows SDK, stable ABI, all modern 64-bit Windows):
                    #   Offset 0  (WORD,  2 bytes): EventType  (1 = KEY_EVENT)
                    #   Offset 2  (2 bytes padding)
                    #   Offset 4  (DWORD, 4 bytes): bKeyDown
                    #   Offset 8  (WORD,  2 bytes): wRepeatCount
                    #   Offset 10 (WORD,  2 bytes): wVirtualKeyCode
                    #   Offset 12 (WORD,  2 bytes): wVirtualScanCode
                    #   Offset 14 (WCHAR, 2 bytes): uChar.UnicodeChar  <- the character we want
                    #   Offset 16 (DWORD, 4 bytes): dwControlKeyState
                    # Total: 20 bytes (we allocate 24 for safety)
                    my int32 $check = GetNumberOfConsoleInputEvents($console-in, nativecast(Pointer[uint32], $num-arr));
                    my uint32 $num-events = $num-arr[0];
                    if $check == 0 || $num-events == 0 {
                        sleep 0.02;
                        next;
                    }
                    my Pointer $p-event = nativecast(Pointer, $event-buf);
                    if ReadConsoleInputW($console-in, $p-event, 1, nativecast(Pointer[uint32], $read-arr)) {
                        my uint32 $events-read = $read-arr[0];
                        if $events-read > 0 {
                            my $event-type = $event-buf.read-uint16(0);   # Offset 0: WORD EventType

                            if $event-type == KEY_EVENT {
                                my $key-down = $event-buf.read-uint32(4);  # Offset 4: DWORD bKeyDown

                                if $key-down {
                                    my $wchar = $event-buf.read-uint16(14); # Offset 14: WCHAR UnicodeChar

                                    if $wchar > 0 {
                                        my $char = try { chr($wchar) } // '';
                                        last if $!stop;
                                        $supplier.emit($char) if $char ne '';
                                    }
                                }
                            }
                        }
                    }
                    last if $!stop;
                }
            }
        } else {
            # No fallback: non-console stdin can't receive 'q' keypresses anyway.
            # Supply with no emits and no done is fine — whenever simply never fires.
            # The fallback path would block forever on piped stdin.
            $supplier.done;
        }
        return $supplier.Supply;
    }

    # No-op on Windows: raw mode is handled by Console API (SetConsoleMode)
    method enter-raw-mode() {
        return True;
    }

    method exit-raw-mode() {
        # Restore console attributes
        if $!attrs-read && $!console-out.defined {
            SetConsoleTextAttribute($!console-out, $!original-attrs);
        }
        # Restore original codepage to avoid breaking parent process
        if $!cp-set {
            SetConsoleCP($!original-cp);
            SetConsoleOutputCP($!original-output-cp);
        }
        # Note: FlushConsoleInputBuffer removed - it discards pending input during shutdown,
        # causing 'q' keypress to be lost if reader thread hasn't processed it yet.
        return True;
    }

    method close-key-reader() {
        self.exit-raw-mode;
        $!stop ⚛= 1;
        with $!reader-thread -> $th {
            try { await Promise.anyof($th, Promise.in(0.1)) }
        }
        $!reader-thread = Nil;
        $!stop ⚛= 0;
    }

    # Deduplicated helper for getting console buffer info
    method !get-console-buffer-info(Pointer[void] $console-out) {
        return Nil unless $console-out.defined;
        my CONSOLE_SCREEN_BUFFER_INFO $csbi .= new;
        my Pointer[CONSOLE_SCREEN_BUFFER_INFO] $p-csbi = nativecast(Pointer[CONSOLE_SCREEN_BUFFER_INFO], $csbi);
        return GetConsoleScreenBufferInfo($console-out, $p-csbi) ?? $csbi !! Nil;
    }

    method get-console-width(Int :$default = 80 --> Int) {
        return $default unless $!console-out.defined;
        my $csbi = self!get-console-buffer-info($!console-out);
        return $default unless $csbi;
        my Int $width = $csbi.dwSize.X.Int;
        return $width > 0 ?? $width !! $default;
    }
}

# Factory function - creates appropriate Terminal based on OS
sub new-terminal(Bool :$use-colors = False) is export {
    if IS-WIN {
        return FFmpegProgressBar::Terminal::Win32.new(:$use-colors);
    }
    return FFmpegProgressBar::Terminal::Unix.new(:$use-colors);
}

# Creates a Job Object and assigns a process to it with KILL_ON_JOB_CLOSE.
# Returns the job handle on success, Nil on failure.
# Caller must keep the handle alive and call CloseHandle when done.
sub assign-to-kill-job(Int $pid --> Pointer) is export {
    return Nil unless IS-WIN;
    return Nil if $pid <= 0;

    my $job = CreateJobObjectW(Pointer, Pointer);
    return Nil unless $job.defined && +$job != 0;

    my $info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION.new(
        :LimitFlags(JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE)
    );

    my $set-ok = SetInformationJobObject(
        $job,
        JobObjectExtendedLimitInformation,
        nativecast(Pointer, $info),
        nativesizeof($info)
    );
    unless $set-ok {
        CloseHandle($job);
        return Nil;
    }

    my $proc-handle = OpenProcess(PROCESS_ALL_ACCESS, 0, $pid);
    unless $proc-handle.defined && +$proc-handle != 0 {
        CloseHandle($job);
        return Nil;
    }

    my $assigned = AssignProcessToJobObject($job, $proc-handle);
    CloseHandle($proc-handle);

    unless $assigned {
        CloseHandle($job);
        return Nil;
    }

    return $job;
}

=begin pod

=head1 NAME

FFmpegProgressBar::Terminal - Platform-specific terminal handling

=head1 DESCRIPTION

Provides terminal detection, Unicode support, bar length calculation,
ANSI colors, and raw mode key input for Unix and Windows.

=head1 METHODS

=item method new(Bool :$use-colors) - Creates terminal instance (Unix or Win32)

=item method is-terminal() - Returns True if stdout is a terminal

=item method supports-unicode() - Check if terminal supports Unicode

=item method bar-length() - Returns appropriate bar length for terminal width

=item method get-key-supply() - Returns Supply for key events

=item method close-key-reader() - Closes key reader

=item sub assign-to-kill-job(Int $pid) - Assign process to Windows Job Object with KILL_ON_JOB_CLOSE so ffmpeg is killed if ffpb force-exits. Returns job handle on success, Nil on failure or non-Windows.

=end pod
