use v6.d;

# ============================================================================
#   - $!output-lock (Mutex) and $!stderr-lock (Lock) are used in two places:
#     1. STDOUT tap (Section 5): $!stderr-lock → $!output-lock (A→B)
#        This is safe because the inner lock ($!output-lock) is NEVER held when
#        acquiring $!stderr-lock elsewhere. Consistent ordering prevents deadlock.
#   - All other sites acquire only one lock at a time.

# ============================================================================
# Timing Constants 
# ============================================================================
my constant FPS_DELAY_SECONDS = 1.3;    # Wait this long before calculating FPS
my constant OUTPUT_THROTTLE_SECONDS = 0.1;  # Minimum time between output updates
my constant ETA_PERCENT_THRESHOLD = 5;  # Show ETA when progress exceeds this %
my constant ETA_TIME_THRESHOLD = 5;    # Show ETA when elapsed exceeds this (seconds)
my constant ETA_STABLE_VIDEO_SECONDS = 5;  # Trust speed-based ETA after this much video time
my constant ETA_MAX_SECONDS = 604800;     # Clamp ETA to max 7 days (prevents Inf)
my constant STDERR_MAX_CHARS = 50_000;  # Maximum stderr chars to collect
my constant @SPINNER-UNICODE = '⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏';
my constant @SPINNER-ASCII   = '|', '/', '-', '\\';

unit class FFmpegProgressBar:ver<0.0.5>:auth<zef:sasha>;

our constant VERSION = '0.0.5';

our sub version() is export {
    $?DISTRIBUTION.meta<version> // VERSION
}

use Terminal::Spinners:ver<1.6.0>:auth<github:ryn1x>;
use FFmpegProgressBar::Terminal;
use FFmpegProgressBar::Parser;
use FFmpegProgressBar::Formatter;
use FFmpegProgressBar::Probe;
use FFmpegProgressBar::ProgressSnapshot;

my regex stderr-error { :i « (error|failed) » }
my regex line-break { \r?\n }
my constant IS-WIN = $*DISTRO.is-win;

enum OverwriteDecision <OverwriteOne NothingToOverwrite Aborted>;

# ============================================================================
# ProgressState - Atomic-backed progress data for progress API
# ============================================================================
# Acts as the single source of truth for get-progress() snapshots.
# 
# Design rationale:
#   - Atomic ints for lockless hot-path reads (frame, fps, speed, stall tracking)
#   - Single Lock for less-frequent string updates (bitrate, status)
#   - quit-percent-scaled frozen at quit time for consistent snapshots
#
# Separation of concerns:
#   - ProgressState: API-visible state only (what get-progress() returns)
#   - Local atomics in run(): rendering-only state (bars, spinner, ETA)
#   - $!effective-duration-us: local-only, never exposed via API
#
# Sync pattern: run() method taps update locals and call !sync-* to update
# ProgressState. get-progress() reads from ProgressState only, never locals.

class ProgressState {
    has atomicint $!frame-count = 0;
    has atomicint $!total-frames = 0;
    has atomicint $!last-fps-scaled = 0;
    has atomicint $!last-speed-scaled = 0;
    has atomicint $!saw-fps-stable = 0;
    has atomicint $!progress-end = 0;
    has atomicint $!last-stall-frame = -1;
    has atomicint $!stall-start-time-ms = 0;
    has atomicint $!quit-percent-scaled = 0;  # Store percent*100 at quit (matches bar)
    has atomicint $!quit-elapsed-ms = 0;  # Store wall-clock elapsed ms at quit
    has atomicint $!last-time-us = 0;  # Store out_time_us (matches progress bar)
    
    has Lock $!string-lock = Lock.new;
    has Str $!last-bitrate = '';
    has EncodeStatus $!status = EncodeRunning;

    method frame-count() { $!frame-count }
    method total-frames() { $!total-frames }
    method last-fps-scaled() { $!last-fps-scaled }
    method last-speed-scaled() { $!last-speed-scaled }
    method saw-fps-stable() { $!saw-fps-stable }
    method progress-end() { $!progress-end }
    method last-stall-frame() { $!last-stall-frame }
    method stall-start-time-ms() { $!stall-start-time-ms }
    method quit-percent-scaled() { $!quit-percent-scaled }
    method quit-elapsed-ms() { $!quit-elapsed-ms }
    method last-time-us() { $!last-time-us }
    method last-bitrate() { $!string-lock.protect: { $!last-bitrate } }
    method status() { $!string-lock.protect: { $!status } }

    method set-frame-count(Int $v) { $!frame-count ⚛= $v }
    method set-total-frames(Int $v) { $!total-frames ⚛= $v; }
    method set-last-fps-scaled(Int $v) { $!last-fps-scaled ⚛= $v }
    method set-last-speed-scaled(Int $v) { $!last-speed-scaled ⚛= $v }
    method set-saw-fps-stable(Int $v) { $!saw-fps-stable ⚛= $v }
    method set-progress-end(Int $v) { $!progress-end ⚛= $v }
    method set-last-stall-frame(Int $v) { $!last-stall-frame ⚛= $v }
    method set-stall-start-time-ms(Int $v) { $!stall-start-time-ms ⚛= $v }
    method set-quit-percent-scaled(Int $v) { $!quit-percent-scaled ⚛= $v }
    method set-quit-elapsed-ms(Int $v) { $!quit-elapsed-ms ⚛= $v }
    method set-last-time-us(Int $v) { $!last-time-us ⚛= $v }
    method set-last-bitrate(Str $v) { $!string-lock.protect: { $!last-bitrate = $v } }
    method set-status(EncodeStatus $v) { $!string-lock.protect: { $!status = $v } }
}

# Terminal Escape Sequences Used:
#   \r        - Carriage return (move cursor to start of line)
#   \e[K      - Clear from cursor to end of line (prevents orphan text)
#   \e[0m     - Reset all attributes (colors, bold, etc.)
#   \e[1;32m  - Example: bold green text (color codes vary)

# ============================================================================
# FFmpegProgress - Main Orchestration Class
# ============================================================================

class FfmpegProgress is export {
    # === ATTRIBUTES ===
    has Str $.ffmpeg = 'ffmpeg';
    has Str $.ffprobe = 'ffprobe';
    has Numeric $.duration = 0;
    has Bool $.verbose = False;
    has Bool $.quiet = False;  # Suppress progress bar rendering (useful when only using progress API)

    has Bool $.show-frames = False;
    has Bool $.show-bitrate = False;
    has Str $.stderr-lines = '';
    has Str $!bar-type = '';
    method bar-type() { $!bar-type }
    has Numeric $.output-throttle = OUTPUT_THROTTLE_SECONDS;
    has Bool $.no-color = False;
    has Bool $.dry-run = False;
    has atomicint $!effective-duration-us = 0;  # Duration in microseconds (for writes)
    has $!proc;
    has atomicint $!stdin-closed = 0;  # Track if stdin was closed (idempotency)
    has atomicint $!user-quit = 0;  # Intentionally uses ⚛= instead of CAS - idempotent, multiple writes are benign
    has atomicint $!force-exit-code = 0;

    # Lifecycle state: encoded as single atomicint to avoid TOCTOU races in watch-progress.
# Bits: proc_started (bit0), running (bit 1). Values: 0=idle/done, 2=running (proc not yet started), 3=running (proc started)
    has atomicint $!lifecycle = 0;
    has $!terminal;
    has atomicint $!last-output-update = 0;  # Store timestamp as integer (monotonic counter)
    # NOTE: All atomicints here are intentionally *scaled* (e.g., percent*1000, fps*1000)
    # to avoid floating-point atomics. This is a deliberate performance trade-off.
    
    has $!parser = FFmpegProgressBar::Parser.new;
    has $!probe;
    has $!formatter;
    has Str $!cached-filename-str = '';
    has Str $!color-yellow-bang = '';

    # === Progress Tracking ===
    has ProgressState $!progress-state = ProgressState.new;
    has Numeric $!encoding-start-time = 0;
    has Supplier $!progress-supplier = Supplier.new;
    has atomicint $!subscribers-enabled = 0;  # Atomic for cross-thread safety
    has Numeric $.stall-threshold = 2.0;
    has Str $!all-stderr = '';
    has Str $!cached-last-error = '';  # Cached last error line for quick retrieval
    has Lock $!stderr-lock = Lock.new;  # Lock for consistent stderr reads
    has Lock $!output-lock = Lock.new;  # Lock for serialized terminal output

    submethod TWEAK(Str :$ffmpeg = 'ffmpeg', Str :$ffprobe = 'ffprobe', Str :$bar-type = '') {
        die "ffmpeg path cannot be empty" if $!ffmpeg.chars == 0;
        die "ffprobe path cannot be empty" if $!ffprobe.chars == 0;
        # NO_COLOR is checked at TWEAK time only. If the env var changes during a long run,
        # it won't be picked up - which is fine for normal usage.
        my $no-color-set = %*ENV<NO_COLOR>:exists || $!no-color;
        my $is-tty = try { $*OUT.t } // False;
        my $use-colors = !$no-color-set && $is-tty;
        try {
            my $t = new-terminal(:$use-colors);
            $!terminal = $t if $t.is-terminal;
            CATCH {
                default {
                    note "Warning: Could not initialize terminal: {$_.message}. Falling back to no terminal.";
                    $!terminal = Nil;
                }
            }
        }
        $!bar-type = self!validate-bar-type($bar-type, $!terminal);
        $!probe = FFmpegProgressBar::Probe.new(ffprobe => $!ffprobe);

        my Int $filename-len = 100;
        my Bool $use-unicode = False;
        if $!terminal.defined {
            my Int $cols = $!terminal.get-terminal-width;
            $filename-len = max(20, min(100, ($cols / 4).Int));
            $use-unicode = $!terminal.supports-unicode();
        }
        $!formatter = FFmpegProgressBar::Formatter.new(:max-filename-length($filename-len), :$use-unicode);
        
        # Pre-build commonly used colored strings for hot paths
        $!color-yellow-bang = $!terminal.defined ?? $!terminal.color('yellow') ~ '!' ~ $!terminal.color('reset') !! '';
    }

    method color(Str $name --> Str) {
        return '' unless $!terminal.defined;
        return $!terminal.color($name);
    }

    # =========================================================================
    # Progress State Sync/Get Methods (Bridge Pattern)
    # =========================================================================

    method !sync-frame-count(Int $val) { $!progress-state.set-frame-count($val); }
    method !sync-total-frames(Int $val) { $!progress-state.set-total-frames($val); }
    method !sync-fps-scaled(Int $val) { $!progress-state.set-last-fps-scaled($val); }
    method !sync-speed-scaled(Int $val) { $!progress-state.set-last-speed-scaled($val); }
    method !sync-saw-fps-stable(Int $val) { $!progress-state.set-saw-fps-stable($val); }
    method !sync-progress-end(Int $val) { $!progress-state.set-progress-end($val); }
    
    method !sync-bitrate(Str $val) {
        $!progress-state.set-last-bitrate($val);
    }

    method !sync-status(EncodeStatus $val) {
        $!progress-state.set-status($val);
    }

    method !sync-quit-percent(Numeric $pct) {
        $!progress-state.set-quit-percent-scaled(($pct * 100).Int);
    }

    method !sync-quit-elapsed(Numeric $elapsed-sec) {
        $!progress-state.set-quit-elapsed-ms(($elapsed-sec * 1000).Int);
    }

    method !sync-time-us(Int $val) {
        $!progress-state.set-last-time-us($val);
    }
    
    # Getters
    method !get-frame-count(--> Int) { $!progress-state.frame-count }
    method !get-total-frames(--> Int) { $!progress-state.total-frames }
    method !get-fps-scaled(--> Int) { $!progress-state.last-fps-scaled }
    method !get-speed-scaled(--> Int) { $!progress-state.last-speed-scaled }
    method !get-saw-fps-stable(--> Int) { $!progress-state.saw-fps-stable }
    method !get-progress-end(--> Int) { $!progress-state.progress-end }
    method !get-duration-us(--> Int) { ⚛$!effective-duration-us }
    
    method !get-bitrate(--> Str) {
        $!progress-state.last-bitrate
    }

    method !get-status(--> EncodeStatus) {
        $!progress-state.status
    }

    method !get-quit-percent-scaled(--> Int) { $!progress-state.quit-percent-scaled }
    method !get-quit-elapsed-ms(--> Int) { $!progress-state.quit-elapsed-ms }
    method !get-time-us(--> Int) { $!progress-state.last-time-us }
    method !get-last-stall-frame(--> Int) { $!progress-state.last-stall-frame }

    method !get-start-time(--> Numeric) { $!encoding-start-time }

    # =========================================================================
    # Public Progress Tracking API
    # =========================================================================
    
    method get-progress(--> ProgressSnapshot) {
        return self!compute-progress-snapshot(now);
    }

    method progress-supply(--> Supply) {
        $!subscribers-enabled ⚛= 1;
        return $!progress-supplier.Supply;
    }

method watch-progress(Numeric :$interval = 0.1, Bool :$emit = False --> Supply) {
        return supply {
            my $start-wait = now;
            my Bool $saw-start = False;
            
            loop {
                # Read single lifecycle atomic atomically to avoid TOCTOU
                my Int $state = ⚛$!lifecycle;
                my Bool $proc-running = ($state +& 2).Bool;  # Coerce Int to Bool
                my Bool $ready = $state == 3;  # Both bits: running (bit 1) + proc_started (bit 0)
                
                # First time we see proc running, note it and reset timeout
                if $proc-running && !$saw-start {
                    $saw-start = True;
                    $start-wait = now;
                }
                
                last if $ready;
                
                # Aborted before start (lifecycle == 4) - exit immediately
                if $state == 4 {
                    die "watch-progress: run() aborted before ffmpeg started";
                }

                # Cleanly skipped (lifecycle == 5, e.g. -n with existing output)
                if $state == 5 {
                    last;
                }
                
                # Timeout after 60 seconds
                if now - $start-wait > 60 {
                    # Only die if run() was truly never called ($saw-start still false)
                    die "watch-progress: run() was never called (timeout after 60s)" unless $saw-start;
                    last;
                }
                
                sleep 0.01;
            }
            
            my $snap = self.get-progress();
            while ⚛$!lifecycle == 3 {
                $snap = self.get-progress();
                emit $emit ?? $snap !! $snap.percent;
                sleep $interval;
            }
            # Emit final state after Section 8 sync
            $snap = self.get-progress();
            emit $emit ?? $snap !! $snap.percent;
            done;
        }
    }
    
    method !compute-progress-snapshot(Numeric $now --> ProgressSnapshot) {
        my Int $frame = self!get-frame-count();
        my Int $total-frames = self!get-total-frames();
        my EncodeStatus $status = self!get-status();
        
        # Get duration - prefer effective (from ffmpeg), fall back to metadata
        my $duration-us = self!get-duration-us();
        my $current-duration-sec = self!duration-sec($duration-us);
        
        # Compute percent based on status - use stored quit percent when not running
        # State machine:
        #   running: calculate from out_time_us (matches progress bar exactly)
        #   (aborted|failed|incomplete|completed): use frozen quit-percent for consistency with bar
        my Numeric $percent;
        my Numeric $elapsed;
        
        if $status == EncodeRunning {
            # Live: use out_time_us from progress state (matches bar)
            my Int $time-us = self!get-time-us();
            if $time-us > 0 && $duration-us > 0 {
                $percent = min(($time-us / $duration-us) * 100, 100);
            } else {
                # No progress yet (ffmpeg starting) - show 0%
                $percent = 0;
            }
            $elapsed = $now - self!get-start-time();
        } else {
            # Post-quit: use stored quit percent (matches bar exactly)
            my Int $quit-pct-scaled = self!get-quit-percent-scaled();
            if $quit-pct-scaled > 0 {
                $percent = min($quit-pct-scaled / 100, 100);
                # Use stored wall-clock elapsed at quit time (not video time)
                my Int $quit-elapsed-ms = self!get-quit-elapsed-ms();
                if $quit-elapsed-ms > 0 {
                    $elapsed = $quit-elapsed-ms / 1000;
                } else {
                    # Fallback to wall-clock time if not stored
                    $elapsed = $now - self!get-start-time();
                }
            } else {
                # Fallback if quit percent not set - use actual elapsed time
                $percent = 0;
                $elapsed = $now - self!get-start-time();
            }
        }
        
        my Numeric $fps = (self!get-fps-scaled() / 1000).Num;
        my Numeric $speed = (self!get-speed-scaled() / 1000).Num;
        
        my Numeric $eta = self!compute-eta($percent, $elapsed, $speed, $current-duration-sec);
        
        my Str $bitrate = self!get-bitrate();
        my Bool $stalled = self!check-stalled($frame, $now);
        my Str $error = self!get-last-error();
        
        my $snap = ProgressSnapshot.new(
            frame-count => $frame,
            total-frames => ($total-frames > 0 ?? $total-frames !! 0),
            :$percent,
            :$elapsed,
            :$eta,
            :$bitrate,
            :$fps,
            :$speed,
            :$status,
            :is-stalled($stalled),
            :last-error($error),
            timestamp => DateTime.now,
        );
        return $snap;
    }

    method !compute-eta(Numeric $percent, Numeric $elapsed, Numeric $speed, Numeric $duration-sec --> Numeric) {
        return 0 if $percent <= 0 || $percent >= 99.9;
        
        # Video time processed - only trust speed-based ETA after stabilization threshold
        my $video-time = $duration-sec * $percent / 100;
        if $speed > 0.01 && $duration-sec > 0 && $video-time > ETA_STABLE_VIDEO_SECONDS {
            # Calculate remaining video time from percent directly
            my $remaining-video = $duration-sec * (1 - $percent / 100);
            return max(0, $remaining-video / $speed);
        }
        
        # Fallback: use video time for consistent extrapolation (not wall-clock)
        if $percent > ETA_PERCENT_THRESHOLD && $video-time > ETA_TIME_THRESHOLD {
            my $raw-eta = $video-time / ($percent / 100) * (100 - $percent);
            return min(max($raw-eta, 0), ETA_MAX_SECONDS);
        }
        
        return 0;
    }

    method !check-stalled(Int $current-frame, Numeric $now --> Bool) {
        # Now read-only (stall tracking updated in STDOUT tap)
        my Int $last-frame = self!get-last-stall-frame();
        
        # No frames processed yet - not stalled
        return False if $last-frame == -1;
        return False if $current-frame != $last-frame;  # Frame advanced = not stalled
        
        # Frame hasn't advanced - check duration (skip if stall timer not initialized)
        my Int $stall-start-ms = $!progress-state.stall-start-time-ms;
        return False if $stall-start-ms == 0;  # Timer not initialized = no frames yet
        my Numeric $stall-duration = $now - ($stall-start-ms / 1000);
        return $stall-duration > $.stall-threshold;
    }

    # LOCK NOTE: Must NOT be called while $!stderr-lock is held (acquires it internally twice).
    # Safe call sites: STDOUT tap (!emit-progress-update), get-progress(), watch-progress().
    # NOT safe from STDERR tap (which holds $!stderr-lock).
    method !get-last-error(--> Str) {
        my ($cached, $copy) = $!stderr-lock.protect: {
            ($!cached-last-error, $!all-stderr)
        };
        return $cached if $cached ne '';
        
        return '' unless $copy.defined && $copy.chars > 0;
        
        my @lines = $copy.split(/\r?\n/, :skip-empty);
        return '' if @lines.elems == 0;
        
        for @lines.reverse -> $line {
            if $line ~~ /:i [error|failed|invalid|cannot]>> / {
                my $v = $line.substr(0, 100);
                $!stderr-lock.protect: { $!cached-last-error = $v };
                return $v;
            }
        }
        return '';
    }

    method !emit-progress-update() {
        if ⚛$!subscribers-enabled {
            my $snapshot = self!compute-progress-snapshot(now);
            try { $!progress-supplier.emit($snapshot) };
        }
    }

    my constant BAR_MIN_LENGTH = 20;
    my constant BAR_MAX_LENGTH = 30;
    my constant BAR_PREFIX = 25;
    my constant BAR_SUFFIX = 25;
    my constant %VALID-BAR-TYPES = %(
        'bar' => True,
        'hash' => True,
        'hash-dash' => True,
        'equals' => True
    );

    method bar-length() {
        if $!terminal.defined {
            return $!terminal.bar-length(:prefix(BAR_PREFIX), :suffix(BAR_SUFFIX), :min(BAR_MIN_LENGTH), :max(BAR_MAX_LENGTH));
        }
        return BAR_MIN_LENGTH max (80 - BAR_PREFIX - BAR_SUFFIX);
    }

    has Numeric $.eta-percent-threshold = ETA_PERCENT_THRESHOLD;
    has Numeric $.eta-time-threshold = ETA_TIME_THRESHOLD;

    # === FORMATTING ===
    method !format-filename-str(Str $output-file, Str $suffix = ' ') {
        return '' if $output-file eq '';
        my $display = $!formatter.truncate-filename($output-file);
        return "{self.color('cyan')}{$display}{self.color('reset')}" ~ $suffix;
    }

    method !format-filename-multi(@output-files, Str $suffix = ' ') {
        return '' if @output-files.elems == 0;
        my $first = @output-files[0];
        my $display = $!formatter.truncate-filename($first);
        if @output-files.elems == 1 {
            return "{self.color('cyan')}{$display}{self.color('reset')}" ~ $suffix;
        }
        my $count = @output-files.elems - 1;
        return "{self.color('cyan')}{$display}{self.color('reset')} {self.color('cyan')}+{$count} more{self.color('reset')}" ~ $suffix;
    }

    method !drain-lines(Str $buffer is rw --> List) {
        return () if $buffer eq '';
        my @parts = $buffer.split(&line-break);
        $buffer = @parts.pop // '';
        return @parts.grep(*.chars > 0).list;
    }

    # Runs first pass of two-pass encoding (analysis pass)
    # Uses Proc::Async to drain stdout/stderr concurrently and avoid deadlock
    method run-pass1(Array $args --> Int) {
        note "Running first pass (analysis)..." if $!verbose;
        
        my $proc = Proc::Async.new($!ffmpeg, |$args);
        my $stderr-supply = $proc.stderr(:bin);  # Use :bin for consistency with stdout
        my Str $pass1-stderr = '';
        my $stderr-done = Promise.new;
        $proc.stdout(:bin).tap: -> $data { };
        $stderr-supply.tap:
            -> $data { $pass1-stderr ~= $data.decode('utf-8', :replace) },
            done => { $stderr-done.keep };
        
        my $sigint;
        LEAVE { try { $sigint.close } if defined $sigint }
        
        $sigint = signal(SIGINT).tap: {
            try { $proc.kill(SIGINT) };
        } unless IS-WIN;
        # Separate SIGINT tap from run()'s outer $signal-tap because run-pass1 runs
        # before the outer react block (and its tap) is set up. This tap self-closes
        # in LEAVE so it won't interfere once run()'s own tap is active.
        
        my $result = await $proc.start;
        await $stderr-done;
        try { $sigint.close } if defined $sigint;
        
        if $result.exitcode != 0 && $pass1-stderr ne '' {
            note "Pass 1 stderr:\n{$pass1-stderr.substr(0, min($pass1-stderr.chars, 5000))}";
        }
        
        return $result.exitcode // -1;
    }

    method get-duration(Str $file --> Numeric) {
        return 0 if $.dry-run || !$file.defined || $file eq '';
        try $!probe.get-duration($file) // 0;
    }

    method get-frame-count(Str $file --> Int) {
        return 0 if $.dry-run || !$file.defined || $file eq '';
        try $!probe.get-frame-count($file) // 0;
    }

    method quit(Bool :$force = False) {
        return unless ⚛$!lifecycle +& 2;
        my Bool $proc-started = ?(⚛$!lifecycle +& 1);
        if $force {
            $!force-exit-code ⚛= 255;
            try { $!proc.kill(Signal::KILL) if $!proc.defined && $proc-started }
        } else {
            $!user-quit ⚛= 1;
            try { 
                if $!proc.defined && $proc-started && !⚛$!stdin-closed { 
                    $!stdin-closed ⚛= 1;
                    try { await $!proc.write("q\n".encode) };
                    # close-stdin omitted: relay thread owns stdin and will close it
                } 
            }
        }
    }

    # === RENDERING HELPERS ===
    
    # Throttled output to avoid flooding terminal.
    # :force bypasses throttle - used for signal handling (Ctrl+C) and final output
    #   to ensure messages appear immediately rather than being delayed.
    # Default throttle is 0.1s (10 updates/sec max) - configurable via $.output-throttle.
    # Uses atomicint for thread-safe timestamp tracking from both main thread and taps.
    method !print-throttled(Str $text, Bool :$force = False, :$now) {
        return if $.quiet;
        my $time-ms = ($now // now).Numeric * 1000;
        $!output-lock.protect: {
            my $last-ms = ⚛$!last-output-update;
            my $threshold = $!output-throttle;
            if $force || $threshold == 0 || ($time-ms - $last-ms) >= ($threshold * 1000).Int {
                $*ERR.print($text);
                $*ERR.flush;
                $!last-output-update ⚛= $time-ms;
            }
        };
    }

    # NOTE: $frame-count typed as Int but callers may pass either local variable or atomicint.
    # Safe because Section 8 runs after await synchronization - both are guaranteed resolved.
    method !end-info(Int $frame-count, Int $total-frames, Num $last-fps, Bool $saw-fps-stable, Int $total-bytes, Numeric $elapsed, Str $last-bitrate) {
        my $frame-info-end = $.show-frames 
            ?? $!formatter.frame-info(True, $frame-count, $total-frames, $last-fps, $saw-fps-stable) 
            !! '';
        my $bitrate-end-str = $.show-bitrate
            ?? $!formatter.average-bitrate($total-bytes, $elapsed) || $!formatter.human-bitrate($last-bitrate)
            !! '';
        return $frame-info-end, $bitrate-end-str;
    }

    # === SPINNER & PROGRESS RENDERING ===

    method !show-spinner(
        $now,
        $last-spinner-update is rw,
        $spinner-idx is rw,
        @spinner-chars,
        Str $filename-str,
        Str $error-indicator,
        Str $frame-info = '',
        Str $bitrate-str = '',
        Str :$current-time-str = ''
    ) {
        return if @spinner-chars.elems == 0;
        
        # Only update spinner if enough time has passed (throttle to ~30fps visual)
        my $time-since-last = $now - $last-spinner-update;
        if $time-since-last >= 0.033 {  # ~30fps = 33ms between updates
            $spinner-idx = ($spinner-idx + 1) % @spinner-chars.elems;
            $last-spinner-update = $now;
        }
        
        my $clear = $!terminal.defined ?? $!terminal.clear-line !! "\r\e[K";
        my $time-display = $current-time-str ne '' ?? " $current-time-str" !! '';
        self!print-throttled("$clear$filename-str @spinner-chars[$spinner-idx]$time-display$frame-info$bitrate-str$error-indicator", :$now);
    }

    method !render-with-eta(Str $filename-str, Str $bar-str, Str $elapsed-str, Str $eta-str, Str $frame-info, Str $bitrate-str, Str $error-indicator = '', :$now) {
        my $clear = $!terminal.defined ?? $!terminal.clear-line !! "\r\e[K";
        self!print-throttled("$clear$filename-str$bar-str $elapsed-str $eta-str$frame-info$bitrate-str$error-indicator", :$now);
    }

    method !format-eta(Numeric $eta --> Str) {
        return '' if $eta <= 0;
        my Int $s = $eta.Int;
        return sprintf("ETA: %ds",           $s)                              if $s < 60;
        return sprintf("ETA: %dm %ds",       $s div 60,  $s % 60)            if $s < 3600;
        return sprintf("ETA: %dh %dm %ds",   $s div 3600, ($s % 3600) div 60, $s % 60);
    }

    # Converts microseconds to seconds (Numeric)
    method !duration-sec(Numeric $us --> Numeric) {
        $us.Num / 1_000_000
    }

    method !bitrate-str(Str $last-bitrate --> Str) {
        return '' unless $!show-bitrate && $last-bitrate ne '';
        return $!formatter.human-bitrate($last-bitrate);
    }

    # Prints the final completion line.
    # Uses :now, :nop to get bar string without backspaces, combines into single print for atomic output.
    method !print-final-line(
        Str $filename-str,
        Str $time-str,
        Numeric $duration,
        $bar,
        Int $final-frame-count,
        Int $total-frames,
        Num $last-fps,
        Bool $saw-fps-stable,
        Str $last-frame-info = '',
        Int $total-bytes = 0,
        Str $last-bitrate = '',
        Bool :$use-last-frame-fallback = False,
        Numeric :$percent = 100,
        Str :$status = ''
    ) {
        my $frame-info = $.show-frames && $final-frame-count > 0
            ?? $!formatter.frame-info(True, $final-frame-count, $total-frames, $last-fps, $saw-fps-stable)
            !! ($use-last-frame-fallback && $.show-frames ?? $last-frame-info !! '');
        my $bitrate-end-str = $.show-bitrate
            ?? $!formatter.average-bitrate($total-bytes, $duration) || $!formatter.human-bitrate($last-bitrate)
            !! '';
        
        my $bar-str = $bar.show($percent, :now, :nop);
        my $colored-status = $status ne '' ?? " $status" !! '';
        $!output-lock.protect: {
            $*ERR.print("\r$filename-str$bar-str $time-str$frame-info$bitrate-end-str$colored-status\e[K\n") unless $.quiet;
            $*ERR.flush unless $.quiet;
        }
    }

    # Pure logic: returns True if confirmation is needed, False otherwise.
    # Takes parameters to avoid I/O side-effects (testable).
    method !prompt-overwrites(@files, Bool $has-y, Bool $has-n --> OverwriteDecision) {
        # has-y and has-n are constant - check once before loop
        return NothingToOverwrite if $has-y;
        return NothingToOverwrite if $has-n;  # -n means ffmpeg will skip existing files
        
        # Collect all existing files first
        my @existing-files;
        for @files -> $f {
            next if $f eq '' || $f eq '-' || $f ~~ /^ 'pipe:' /;
            push @existing-files, $f if $f.IO.e;
        }
        
        # Skip TTY prompt entirely if no files to overwrite
        return NothingToOverwrite if @existing-files.elems == 0;
        
        # Try to open TTY for interactive prompt; if stdin is redirected/non-interactive, abort
        my $tty = IS-WIN 
            ?? (try { open("CONIN\$", :r) } // Nil) 
            !! (try { open("/dev/tty", :r) } // Nil);
        
        # If we couldn't get a real TTY (stdin redirected or console unavailable), abort
        if !$tty.defined {
            $*ERR.say("stdin is not a terminal - cannot prompt for overwrite confirmation");
            return Aborted;
        }
        
        LEAVE { try { $tty.close } }
        
        # Show all files in the initial prompt
        my $files-str = @existing-files.elems == 1 
            ?? @existing-files[0] 
            !! @existing-files.join(', ');
        my $plural-s = @existing-files.elems > 1 ?? 's' !! '';
        $*ERR.print("Output file$plural-s $files-str already exist$plural-s. Overwrite? [y/n] ");
        $*ERR.flush;
        
        my $decision = '';
        my $attempts = 0;
        loop {
            if $attempts++ > 100 {
                $*ERR.say("Too many invalid responses, aborting");
                return Aborted;
            }
            my $answer = $tty.get;
            if !$answer.defined {
                $*ERR.say("Not overwriting - exiting");
                return Aborted;
            }
            my $trimmed = $answer.trim;
            if $trimmed eq '' {
                next;
            }
            my $first-char = $trimmed.substr(0, 1);
            given $first-char {
                when 'y' | 'Y' { $decision = 'yes'; last; }
                when 'n' | 'N' {
                    $*ERR.say("Not overwriting - exiting");
                    return Aborted;
                }
                default {
                    $*ERR.say("Please answer y or n");
                    $*ERR.flush;
                    next;
                }
            }
        }
        
        return OverwriteOne if $decision eq 'yes';
        return Aborted;
    }

    method !combine-durations(@durations, Bool $shortest --> Numeric) {
        return $shortest ?? @durations.min !! @durations.max;
    }

    # Validates bar-type, returns default if invalid
    # NOTE: Takes $terminal as parameter for testability (can pass mock/different terminal)
    # rather than reading $!terminal directly. Allows testing validation logic in isolation.
    method !validate-bar-type(Str $type, $terminal) {
        my $exists = %VALID-BAR-TYPES{$type}:exists;
        return $type if $type ne '' && $exists;
        return $terminal.defined && $terminal.supports-unicode() ?? 'bar' !! 'hash-dash';
    }

    # Shared helper: tail last N lines with optional omission note
    method !tail-with-note(Str $stderr, Int $num-lines, Bool :$omit-note = False --> Str) {
        return '' if $num-lines <= 0;
        my @lines = $stderr.split(/\r?\n/, :skip-empty);
        return '' if @lines.elems == 0;

        my @display = @lines.elems > $num-lines ?? @lines.tail($num-lines) !! @lines;
        my $result = @display.join("\n");
        if !$omit-note && @lines.elems > $num-lines {
            my $skipped = @lines.elems - @display.elems;
            my $ellipsis = $!formatter.use-unicode ?? '…' !! '...';
            $result = "$ellipsis ($skipped earlier lines omitted)\n" ~ $result;
        }
        return $result;
    }

    # Process a single stderr line: check for errors and parse duration
    # Returns the parsed duration if found, or Nil
    # Also returns error indicator string - caller should handle lock for writes
    method !process-stderr-line(Str $line, Str $current-indicator) {
        return (Nil, $current-indicator) if $line.trim eq '';
        
        my Str $new-indicator = $current-indicator;
        if $line ~~ &stderr-error {
            $new-indicator = " $!color-yellow-bang";
        }
        
        return ($!parser.parse-duration($line), $new-indicator);
    }

    # Process stderr line and update duration tracking
    # Now accepts $explicit-duration so we don't re-parse args every line
method !process-stderr-line-and-update-duration(
        Str $line,
        Str $error-indicator-cached is rw,
        $stderr-lock,
        Bool $suppress-stderr-duration,
        @durations,
        Int $input-count,
        Numeric $seek-start,
        Bool $has-shortest,
        $duration-printed is rw,
        Numeric $explicit-duration = 0
    ) {
        # Returns new-indicator so caller can propagate changes
        my Bool $should-print = False;
        my Numeric $combined-for-print = 0;
        my Str $new-indicator = '';
        
        # Variables that need to be captured for say outside lock
        my Numeric $old-sec-capture = 0;
        my Numeric $combined-capture = 0;
        my Numeric $diff-pct-capture = 0;
        my Bool $diff-exceeded = False;
        
        my Bool $early-return = False;
        $stderr-lock.protect: {
            my ($dur, $new-indicator-inner) = self!process-stderr-line($line, $error-indicator-cached);
            $new-indicator = $new-indicator-inner;
            # Only set yellow indicator if red (error) is not already set - red takes priority.
            # If no terminal, we can't detect colors, so bypass priority logic.
            my Bool $is-red = False;
            if $!terminal.defined {
                $is-red = ($error-indicator-cached // '') ne ''
                    && ($error-indicator-cached // '').contains(self.color('red'));
            }
            $error-indicator-cached = $new-indicator unless $is-red;
            
            if $dur.defined && !$suppress-stderr-duration {
                # Have valid duration - continue processing
                @durations.push: $dur;
                
                # Duration precedence (highest to lowest):
                # 1. Explicit CLI duration (-t/-to) - cannot be overridden by stderr
                # 2. Detected duration from ffprobe/stderr - respects -shortest if set
                # 3. Elapsed time fallback (no duration available)
                if $explicit-duration > 0 {
                    # Explicit CLI duration (-t/-to) already set - no need to detect/print
                    # $duration-printed status from earlier iterations is preserved
                    my Int $new-us = ($explicit-duration * 1_000_000).Int;
                    if ⚛$!effective-duration-us == 0 {
                        $!effective-duration-us ⚛= $new-us;
                    }
                    $early-return = True;
                    # Don't return - let block end naturally
                } else {
                    # Normal fallback: multi-input / -shortest logic
                    if $input-count > 0 && @durations.elems >= $input-count {
                        $combined-for-print = max(0, self!combine-durations(@durations, $has-shortest) - $seek-start);
                        my Int $new-us = ($combined-for-print * 1_000_000).Int;
                        # Allow refinement if difference > 5% to prevent jitter but allow real updates
                        my Int $old-us = ⚛$!effective-duration-us;
                        if $old-us == 0 {
                            $!effective-duration-us ⚛= $new-us;
                        } elsif $new-us > 0 {
                            my Numeric $old-sec = $old-us / 1_000_000;
                            my Numeric $diff-pct = (($combined-for-print - $old-sec).abs / $old-sec) * 100;
                            if $diff-pct > 5 {
                                $!effective-duration-us ⚛= $new-us;
                                if $!verbose {
                                    # Capture values before leaving lock
                                    $old-sec-capture = $old-sec;
                                    $combined-capture = $combined-for-print;
                                    $diff-pct-capture = $diff-pct;
                                    $diff-exceeded = True;
                                }
                            }
                        }
                    }
                    if $!verbose && ⚛$duration-printed == 0 {
                        $should-print = True;
                        $duration-printed ⚛= 1;  # Set inside lock to prevent duplicate prints
                    }
                }
            } else {
                # No duration or suppressed - early return
                $early-return = True;
                # Don't return - let block end naturally
            }
        };
        
        return $new-indicator if $early-return;
        
        if $should-print {
                $*ERR.say("Detected duration (from stderr): {$combined-for-print.fmt('%.2f')} seconds");
        }
        
        if $diff-exceeded {
            $*ERR.say("Refined duration from {$old-sec-capture.fmt('%.2f')}s to {$combined-capture.fmt('%.2f')}s (diff: {$diff-pct-capture.fmt('%.1f')}%)");
        }
        
        return $new-indicator;
    }
    
    method !get-stderr-output(Str $stderr, Int $num-lines --> Str) {
        return $stderr.split(/\r?\n/, :skip-empty).join("\n") if $num-lines == -1;
        return self!tail-with-note($stderr, $num-lines);
    }

    method !compute-stderr-depth(Int $lines --> Int) {
        return -1 if $lines == -1;
        return $lines > 0 ?? $lines !! 20;
    }

    # Kept public for testing purposes.
    # NOTE: This covers pre-run ffprobe-based detection only. Duration can also be
    # refined during the run from ffmpeg's stderr output (see SECTION 6), which is
    # a separate streaming path that cannot share this logic.
    method detect-duration(
        Numeric $duration,
        Numeric $output-duration,
        Numeric $seek-start,
        Bool $has-shortest = False,
        @input-groups = [],
        $mapped-inputs = Nil,  # MapSelection|Nil
        Numeric $output-seek = 0
    ) {
        if $output-duration > 0 {
            return $output-duration;
        }
        
        # If output-seek is used but no -t/-to, reduce duration by output-seek
        if $output-seek > 0 && $duration > 0 {
            return max(0, $duration - $output-seek);
        }
        
        return $duration if $duration > 0;
        return 0 if $.dry-run;

        # Filter to only mapped inputs if -map was used
        # $mapped-inputs can be:
        #   - MapSelection with include/exclude -> specific inputs to probe
        #   - empty MapSelection (both Sets empty) -> no -map flag, probe all inputs
        #   - MapSelection with unknown=True -> -map [label] form (filter_complex), probe no inputs
        if $mapped-inputs.defined.not || $mapped-inputs.unknown {
            # Can't probe inputs (filter_complex -map [label]) - fall back to ffprobe duration
            return $duration;
        }
        
        my @input-groups-filtered;
        # $mapped-inputs is always a MapSelection here (Nil handled above)
        my $include = $mapped-inputs.include;
        my $exclude = $mapped-inputs.exclude;
        
        # Start with include set (or all inputs if empty)
        my $start-set = $include.elems > 0 
            ?? $include 
            !! Set.new(0..^@input-groups.elems);
        
        # Apply excludes
        my $final-set = $start-set (-) $exclude;
        
        @input-groups-filtered = @input-groups.pairs.grep({ $final-set{$_.key} }).map(*.value);
        
        return 0 if @input-groups-filtered.elems == 0;
        
        my @durations;
        
        if @input-groups-filtered.elems >= 2 {
            my @promises = @input-groups-filtered.map({
                start {
                    my $dur = try $!probe.get-duration($_.file) // 0;
                    max(0, $dur - $_.seek);
                }
            });
            my $timeout = Promise.in(5);
            await Promise.anyof(Promise.allof(|@promises), $timeout);
            # Note: .cancel on start {} promises is a no-op (Raku doesn't cancel start threads).
            # Threads will continue running until they naturally finish, but $!probe is idempotent.
            my $timed-out = @promises.grep({ .status != Kept }).elems;
            if $timed-out > 0 && $!verbose {
                note "Warning: {$timed-out} input(s) timed out probing duration";
            }
            @durations = @promises.grep({ .status == Kept }).map: { .result };
            @durations = @durations.grep({ $_ > 0 });
        } else {
            # Single input - use start {} with same 5-second timeout to prevent indefinite hang
            my $input = @input-groups-filtered[0];
            my $p = start {
                my $dur = try { $!probe.get-duration($input.file) } // 0;
                max(0, $dur - $input.seek);
            }
            my $timeout = Promise.in(5);
            await Promise.anyof($p, $timeout);
            my $timed-out = $p.status != Kept;
            if $timed-out && $!verbose {
                note "Warning: input timed out probing duration";
            }
            my $dur-result = $p.status == Kept ?? ($p.result // 0) !! 0;
            @durations = $dur-result > 0 ?? ($dur-result,) !! ();
        }
        
        if @durations {
            return $has-shortest ?? @durations.min !! @durations.max;
        }
        return 0;
    }

    method run(*@args --> Int) {
        # =========================================================================
        # SECTION 1: Initialization & Validation
        # =========================================================================
        # Reset instance state FIRST to ensure get-progress() sees clean state
        # if called during the reset window (before CAS completes)
        $!progress-state = ProgressState.new;
        # Close old supplier if it had subscribers from a prior run
        try { $!progress-supplier.done } if ⚛$!subscribers-enabled;
        $!progress-supplier = Supplier.new;
        $!subscribers-enabled ⚛= 0;
        
        # CAS AFTER all resets complete to prevent stale state reads
        # Set lifecycle to 2 (running, proc not yet started)
        if cas($!lifecycle, 0, 2) != 0 {
            die "FFmpegProgress.run called while already running";
        }
        $!user-quit ⚛= 0;
        $!force-exit-code ⚛= 0;
        $!stdin-closed ⚛= 0;
        $!effective-duration-us ⚛= 0;
        # Reset stderr state (safe here, no locks held)
        $!stderr-lock.protect: {
            $!cached-last-error = '';
            $!all-stderr = '';
        }
        unless $!probe.check-binary-exists($!ffmpeg) {
            $!lifecycle ⚛= 4;  # Signal aborted before proc start
            die "ffmpeg not found in PATH";
        }
        unless $!probe.check-binary-exists($!ffprobe) {
            $!lifecycle ⚛= 4;  # Signal aborted before proc start
            die "ffprobe not found in PATH";
        }
        my $key-supply;
        my $signal-tap;
        my $pass-log;  # Two-pass temp log file (cleaned up in LEAVE)
        my $stdin-relay-promise;
        my $win-job-handle = Nil;  # Windows Job Object handle (cleaned up in LEAVE)
        # $!force-exit-code: written in signal tap (separate thread), read after react completes.
        # Using atomicint for $!force-exit-code ensures cross-thread visibility.
        LEAVE {
            # Only reset lifecycle if not aborted (4) or skipped (5) - preserve signals for watch-progress
            if ⚛$!lifecycle != 4 && ⚛$!lifecycle != 5 {
                $!lifecycle ⚛= 0;
            }
            if $stdin-relay-promise.defined {
                try { await Promise.anyof($stdin-relay-promise, Promise.in(1)) }
            }
            if $win-job-handle.defined {
                try { CloseHandle($win-job-handle) }
                $win-job-handle = Nil;
            }
            $!proc = Nil;  # Clear previous process reference to avoid stale state
            try { $!terminal.exit-raw-mode if $!terminal.defined }
            try { $!terminal.close-key-reader if $!terminal.defined }
            try { $!progress-supplier.done } if ⚛$!subscribers-enabled;
            if $signal-tap.defined {
                $signal-tap.close;
            }
            try { $pass-log.IO.unlink } if $pass-log.defined;
            if $pass-log.defined {
                # Glob-based cleanup: remove all files starting with pass-log basename.
                # This handles all ffmpeg two-pass log variants (-0.log, -1.log, .mbtree, etc.)
                my $log-base = $pass-log.IO.basename;
                my $log-dir = $pass-log.IO.parent;
                if $log-dir.defined && $log-dir.d {
                    for $log-dir.dir.grep({ .basename.starts-with($log-base) }) -> $f {
                        try { $f.unlink }
                    }
                }
            }
        }

        # =========================================================================
        # SECTION 2: Argument Parsing
        # =========================================================================
        my %args-parsed = $!parser.parse-arguments(@args);
        my $suppress-stderr-duration = %args-parsed<suppress-stderr-duration>;
        my $has-shortest = %args-parsed<has-shortest>;
        my $input-count = %args-parsed<input-count>;
        
        # Normalize '--' separator: if present and followed by an option-like
        # token (starts with -<letter>), strip it so ffmpeg doesn't misinterpret
        # it as "end of options". Keep '--' when followed by non-option tokens
        # (e.g. -0.5, or bare words), since ffmpeg needs it for correct parsing.
        my @normalized-args = @args;
        if %args-parsed<saw-double-dash> {
            my $dd-idx = @args.first(* eq '--', :k);
            my $next = @args[$dd-idx + 1] // '';
            if $next ~~ /^ '-' <[A..Z a..z]> <[A..Z a..z0..9_-]>* $/ {
                @normalized-args .= grep(* ne '--');
                %args-parsed = $!parser.parse-arguments(@normalized-args);
            }
        }
        
        # Validate stderr-lines once at startup (not on every call)
        my $stderr-lines-raw = $.stderr-lines // '';
        my Bool $should-show-stderr = $stderr-lines-raw ne '' && $stderr-lines-raw ne '0';
        my $stderr-lines-valid = $should-show-stderr 
            ?? do {
                if $stderr-lines-raw eq 'all' {
                    -1;
                } else {
                    my $lines-int = try { $stderr-lines-raw.Int };
                    if $lines-int ~~ Int && $lines-int > 0 {
                        $lines-int;
                    } else {
                        note "Warning: invalid --stderr value '$stderr-lines-raw', defaulting to 20 lines";
                        20;
                    }
                }
            }
            !! 0;
        
        my @input-groups = $!parser.get-input-groups-with-seeks(@normalized-args);
        my $mapped-inputs = $!parser.parse-map-inputs(@normalized-args, $input-count);
        my $output-file = %args-parsed<output-file> || %args-parsed<output-file-backward> || '';
        my @output-files = (%args-parsed<output-files> // []).flat;
        
        # Detect if output is stdout (-) to prevent mixing binary media + text on stdout
        my Bool $output-is-stdout = @output-files.first(-> $f { $f eq '-' }).defined;
        
        # Two-pass encoding: detect and run pass 1 if needed
        if is-pass2(@normalized-args) && @output-files.elems > 0 && !$.dry-run {
            my $output-file-idx = %args-parsed<output-file-idx> // -1;
            my $result = build-pass1-args(@normalized-args, :@output-files, :first-output-idx($output-file-idx));
            my @pass1-args = $result[0].list;
            $pass-log = $result[1];
            
            note "Running two-pass encoding: pass 1 (analysis)..." if $!verbose;
            
            my $pass1-code = self.run-pass1(@pass1-args);
            
            if $pass1-code != 0 {
                my $msg = ($pass1-code == 130 || $pass1-code == 2)
                    ?? "Pass 1 interrupted (Ctrl+C)"
                    !! "First pass failed with exit code $pass1-code";
                die $msg;
            }
            
            note "Pass 1 complete. Starting pass 2 (encoding)..." if $!verbose;
        }
        
        # Get initial duration from ffprobe and initialize atomic immediately
        # This ensures progress bar shows percentage from the very first update
        # Skip for special files (devices, pipes, stdin) - ffprobe can't determine duration
        if @input-groups.elems > 0 && $.duration <= 0 {
            my $input = @input-groups[0].file // '';
            my $is-special = $input eq '-' || $input ~~ /^\/dev\// || $input ~~ /^\w+ '://'/ || $input ~~ /^pipe:/ || ($input.IO.d // False);
            if $input.defined && $input ne '' && !$is-special && !$.dry-run {
                my $initial-duration = try $!probe.get-duration($input) // 0;
                if $initial-duration > 0 {
                    my $adjusted = $initial-duration - @input-groups[0].seek;
                    my Int $duration-us = (max(0, $adjusted) * 1_000_000).Int;
                    $!effective-duration-us ⚛= $duration-us;
                    if $!verbose {
                        $*ERR.say("Initial duration from ffprobe: {$initial-duration.fmt('%.2f')} seconds");
                    }
                }
            }
        }
        
        # Fallback: if no output file detected, use 'output' as placeholder
        if $output-file eq '' && $!verbose {
            note "Warning: could not detect output filename, using placeholder";
        }
        
        my @output-durations = (%args-parsed<output-durations> // []).list;
        my @output-ends = (%args-parsed<output-ends> // []).list;
        my $input-seek = %args-parsed<input-seek> // 0;
        my $output-seek = %args-parsed<output-seek> // 0;
        
        # Only use input-seek for seek-start to avoid double-counting
        # Output-seek is handled separately via OutputSpec.ss per-output
        # InputGroup.seek already has input-seek subtracted from probe duration
        my $seek-start = $input-seek;
        
        # Calculate effective duration: max of explicit durations (or min with -shortest)
        # Option A for -to: don't subtract seek-start since they're absolute times
        my $effective-explicit = 0;
        
        if @output-durations.elems > 0 {
            my $max-dur = @output-durations.max;
            $effective-explicit = $max-dur if $max-dur > $effective-explicit;
        }
        
        if @output-ends.elems > 0 {
            # -to is absolute output time (not relative to input seek)
            # If output-seek is also used, subtract it to get actual encoding duration
            my $max-end = @output-ends.max;
            if $output-seek > 0 {
                $max-end = max(0, $max-end - $output-seek);
            }
            $effective-explicit = $max-end if $max-end > $effective-explicit;
        }
        
        # Use explicit duration if set
        my $output-duration = $effective-explicit;
        
        # Validate parsed values (catch parsing errors)
        if $output-duration < 0 || $seek-start < 0 {
            note "Warning: negative duration value detected, ignoring parsed values";
            $output-duration = 0;
            $seek-start = 0;
        }
        my $explicit-duration = max($output-duration, $!duration);
        
        my $has-y = %args-parsed<has-y>;
        my $has-n = %args-parsed<has-n> // False;

        # Fail if input is from stdin, output exists, and -y is not used.
        # ffmpeg would prompt for overwrite but stdin is occupied by the pipe.
        my Bool $has-stdin-input = @input-groups.grep({ .file eq '-' }).so;
        if $has-stdin-input && !$has-y && !$has-n {
            for (%args-parsed<output-files> // []).list -> $f {
                if $f ne '' && $f ne '-' && $f !~~ /^ 'pipe:' / && $f.IO.e {
                    $*ERR.say("Error: input is from stdin but output file '$f' already exists.");
                    $*ERR.say("Use -y to overwrite, or remove the existing file.");
                    $!lifecycle ⚛= 4;
                    return 1;
                }
            }
        }

        my $decision = self!prompt-overwrites((%args-parsed<output-files> // []).list, $has-y, $has-n);
        my @ffmpeg-args = @normalized-args;  # Already normalized above
        
        # Insert -y at the very beginning of user args (after ffmpeg global options)
        if $decision == Aborted {
            $!lifecycle ⚛= 4;  # Aborted before proc start
            return 1;
        }
        if $decision == OverwriteOne && !$has-y {
            @ffmpeg-args = '-y', |@ffmpeg-args;
        }

        $!cached-filename-str = @output-files.elems > 1 
            ?? self!format-filename-multi(@output-files) 
            !! self!format-filename-str($output-file);

        if $has-n && @output-files.elems > 0 {
            my @skipped = @output-files.grep({
                $_ ne '' && $_ ne '-' && $_ !~~ /^ 'pipe:' / && $_.IO.e
            });
            if @skipped.elems == @output-files.elems {
                my $files-str = @skipped.elems == 1
                    ?? @skipped[0]
                    !! "{@skipped[0]} (+{@skipped.elems - 1} more)";
                $!output-lock.protect: {
                    $*ERR.print("$!cached-filename-str skipped (already exists)\e[K\n") unless $.quiet;
                    $*ERR.flush unless $.quiet;
                }
                self!sync-status(EncodeSkipped);   # <-- changed from EncodeCompleted
                self!sync-quit-percent(100);
                self!sync-quit-elapsed(0);
                $!lifecycle ⚛= 5;  # Clean skip, not an error
                return 0;
            } elsif @skipped.elems > 0 {
                note "Note: {+@skipped} of {+@output-files} output file(s) will be skipped (-n)";
            }
        }

        # Use the value from $!duration (CLI -D) first if set, otherwise probed value
        my Numeric $probe-duration = $!duration > 0
            ?? $!duration
            !! (self!get-duration-us() > 0
                ?? self!duration-sec(self!get-duration-us())
                !! 0);

        # Don't pass pipe/device/stdin inputs to detect-duration — ffprobe
        # cannot read them without consuming bytes from the OS pipe that are
        # meant for ffmpeg. Filter these out before probing.
        my @probeable-groups = @input-groups.grep(-> $g {
            my $f = $g.file;
            $f ne '-'
                && $f !~~ /^\/dev\//
                && $f !~~ /^\w+ '://' /
                && $f !~~ /^ 'pipe:' /
                && !($f.IO.d // False)
        });

        my Int $duration-us = (self.detect-duration(
            $probe-duration,
            $explicit-duration,
            $seek-start,
            $has-shortest,
            @probeable-groups,
            $mapped-inputs,
            $output-seek
        ) * 1_000_000).Int;
        $!effective-duration-us ⚛= $duration-us if $duration-us > 0;

        # =========================================================================
        # SECTION 3: FFmpeg Command Setup
        # =========================================================================
        # Force usable loglevel for -progress pipe:1 to work reliably.
        # Any level quieter than "info" can suppress progress output.
        my @final-args = @ffmpeg-args;
        
        # Add -passlogfile for pass 2 if two-pass was done
        # Must be in @final-args so it ends up before the output file
        if $pass-log.defined {
            my $has-passlogfile = @final-args.grep({ $_ eq '-passlogfile' }).elems > 0;
            unless $has-passlogfile {
                # Insert before -pass 2 to ensure it's in the right position
                my $insert-pos = -1;
                for @final-args.kv -> $i, $arg {
                    if $arg eq '-pass' && $i + 1 < @final-args.elems && @final-args[$i + 1] eq '2' {
                        $insert-pos = $i;
                        last;
                    }
                }
                if $insert-pos >= 0 {
                    @final-args.splice($insert-pos, 0, '-passlogfile', $pass-log);
                } else {
                    @final-args.push: '-passlogfile', $pass-log;
                }
            }
        }
        
        my $has-loglevel = False;
        for @final-args.kv -> $i, $arg {
            if $arg eq '-loglevel' || $arg eq '-v' {
                $has-loglevel = True;
                if $i + 1 < @final-args.elems {
                    my $level = @final-args[$i + 1];
                    if $level eq any(<quiet panic fatal error>) {
                        @final-args[$i + 1] = 'info';
                    }
                }
                last;
            }
        }
        unless $has-loglevel {
            @final-args.unshift: '-loglevel', 'info';
        }
        
        # When output is '-', progress must NOT go to stdout (would mix with binary media)
        # Use deterministic 'pipe:2' (stderr) instead of relying on ffmpeg defaults
        my $progress-target = $output-is-stdout ?? 'pipe:2' !! 'pipe:1';
        @ffmpeg-args = $!ffmpeg, '-hide_banner', '-progress', $progress-target, '-nostats', |@final-args;
        my atomicint $duration-printed = 0;
        my $bar = Bar.new(:type($!bar-type), :length(self.bar-length));

        if $!verbose {
            if $!effective-duration-us > 0 {
                $*ERR.say("Detected duration: {self!duration-sec($!effective-duration-us).fmt('%.2f')} seconds");
                $duration-printed ⚛= 1;
            } else {
                $*ERR.say("Duration: not detected (will use elapsed time for progress)");
            }
            if @output-files.elems > 1 {
                $*ERR.say("Output files:");
                for @output-files -> $f {
                    $*ERR.say("  - {$f.IO.basename}");
                }
            } else {
                my $output-display = $output-file eq '' ?? '(unknown, using placeholder)' !! $output-file;
                $*ERR.say("Output file: $output-display");
            }
            $*ERR.say("Input files: {$input-count} detected");
            $*ERR.say("Executing: {@ffmpeg-args.join(' ')}");
        }

        # =========================================================================
        # SECTION 4: State Initialization for Progress Tracking
        # =========================================================================
        $!proc = Proc::Async.new(:w, |@ffmpeg-args);
        my $start-time = now;
        $!encoding-start-time = $start-time;

        # === Progress State (rendering-only locals, use ProgressState for API) ===
        my atomicint $last-percent-scaled = 0;  # For local rendering only
        my $render-lock = Lock.new;
        my $last-eta-str = '';
        my $last-frame-info = '';
        my $last-bitrate = '';

        # === Error State ===
        my Str $all-stderr = '';
        my atomicint $stderr-capped = 0;
        my Str $error-indicator-cached = '';
        my @durations;

        # === Frame Data ===
        my atomicint $frame-count = 0;
        my atomicint $total-frames = 0;
        my atomicint $final-frame-count = 0;
        my atomicint $total-bytes = 0;

        # === Mode & Flags ===
        my atomicint $saw-fps-stable-atomic = 0;
        my atomicint $progress-end = 0;

        # === Thresholds (extracted once for hot path) ===
        my $thresh-eta-pct = $.eta-percent-threshold;
        my $thresh-eta-time = $.eta-time-threshold;

        # === Feature flags (cached for hot path) ===
        my Bool $show-frames = $.show-frames;
        my Bool $show-bitrate = $.show-bitrate;

        # === Spinner State ===
        my $use-unicode = $!terminal.defined ?? $!terminal.supports-unicode() !! False;
        my @spinner-chars = $use-unicode ?? @SPINNER-UNICODE !! @SPINNER-ASCII;
        my int $spinner-idx = 0;
        my $last-spinner-update = now;

        # === Signal Handling ===
        my atomicint $signal-count = 0;
        my int $last-handled-signal-count = 0;

        # === Stream Detection ===
        my $is-stream = False;
        if $input-count > 0 && !$.dry-run {
            my $input-file = @input-groups[0].file;
            $is-stream = $input-file eq '-' || $input-file ~~ /^\/dev\// || $input-file ~~ /^\w+ '://'/ || $input-file ~~ /^pipe:/ || ($input-file.IO.d // False);
            my Int $frames = $is-stream ?? 0 !! ((try { $!probe.get-frame-count($input-file) }) // 0);
            $total-frames ⚛= $frames;
            self!sync-total-frames($frames);
        }

        my $filename-str-with-space = $!cached-filename-str;  # Already has trailing space from !format-filename-str
        $!last-output-update ⚛= ((now - $!output-throttle).Num * 1000).Int;
        # NOTE: $out-buffer doesn't need post-react flush like $err-buffer.
        # If ffmpeg's final progress=end has no trailing newline, drain-lines leaves it in buffer.
        # Section 8 then falls through to progress-end==0 path which correctly re-prints the final line.
        my Str $out-buffer = '';
        my Str $err-buffer = '';

        # Lock spinner/bar decision to prevent transitions
        my Bool $duration-locked = False;
        my Bool $has-duration = False;

        # =========================================================================
        # SECTION 5: STDOUT Tap - Progress Parsing & Rendering
        # =========================================================================
        if $output-is-stdout {
            # stdout is BINARY MEDIA ONLY - never decode, never parse progress
            # Write binary data to parent process stdout for piping
            $!proc.stdout(:bin).tap: -> $buf {
                $*OUT.write($buf);
            };
        } else {
            # stdout contains progress text - decode and parse as before
            $!proc.stdout(:bin).tap: -> $buf {
                my $now = now;
                my $elapsed = $now - $start-time;

                $out-buffer ~= $!parser.decode-buffer($buf);

            my Bool $block-progress-end = False;
            my $block-out-time-us;

            my @complete-lines = self!drain-lines($out-buffer);

            for @complete-lines -> $l {
                my %upd = $!parser.parse-progress-line($l);
                
                if %upd<progress>:exists && %upd<progress> eq 'end' {
                    $block-progress-end = True;
                    $progress-end ⚛= 1 if ⚛$!user-quit == 0;
                    self!sync-progress-end(⚛$!user-quit == 0 ?? 1 !! 0);
                }
                if %upd<speed>:exists {
                    my $speed-str = %upd<speed>;
                    if $speed-str.ends-with('x') {
                        my $speed = $speed-str.substr(0, *-1).Num;
                        if $speed > 0.01 {
                            my Int $speed-scaled = ($speed * 1000).Int;
                            self!sync-speed-scaled($speed-scaled);
                        }
                    }
                }
                if %upd<fps>:exists {
                    # $fps-val is already a Num (validated in parse-progress-line)
                    my $fps-val = %upd<fps>;
                    my $parsed-fps = $fps-val.Num;
                    if $parsed-fps > 0 {
                        my Int $fps-scaled = ($parsed-fps * 1000).Int;
                        self!sync-fps-scaled($fps-scaled);
                        $saw-fps-stable-atomic ⚛= 1;
                        self!sync-saw-fps-stable(1);
                    }
                }
                if %upd<frame>:exists {
                    my Int $frame-int = %upd<frame>.Int;
                    $frame-count ⚛= $frame-int;
                    self!sync-frame-count($frame-int);
                    $final-frame-count ⚛= ⚛$frame-count;
                    
                    # Update stall tracking: on first frame, set start from encoding-start-time
                    # When frame advances, reset stall timer so is-stalled can go back to False
                    # Cache last-stall-frame to avoid multiple reads (thread-safe since atomic)
                    my Int $last-frame = $!progress-state.last-stall-frame;
                    if $last-frame == -1 {
                        $!progress-state.set-stall-start-time-ms(($!encoding-start-time * 1000).Int);
                    } elsif $frame-int != $last-frame {
                        $!progress-state.set-stall-start-time-ms((now * 1000).Int);
                    }
                    $!progress-state.set-last-stall-frame($frame-int);
                    
                    if $elapsed >= FPS_DELAY_SECONDS && $elapsed > 0.001 && ⚛$frame-count > 0 && (⚛$saw-fps-stable-atomic) == 0 {
                        my Int $fps-scaled = (⚛$frame-count / $elapsed * 1000).Int;
                        self!sync-fps-scaled($fps-scaled);
                        $saw-fps-stable-atomic ⚛= 1;
                        self!sync-saw-fps-stable(1);
                    }
                }
                if %upd<time-us>:exists {
                    $block-out-time-us = %upd<time-us>;
                    self!sync-time-us($block-out-time-us);
                }
                if %upd<bitrate>:exists {
                    my $bitrate-val = %upd<bitrate>;
                    if $bitrate-val ne 'N/A' && $bitrate-val !~~ /^0\.?0*kbits\/s$/ {
                        my Str $bt = $bitrate-val;
                        $render-lock.protect: { $last-bitrate = $bt; };
                        self!sync-bitrate($bt);
                    }
                }
                if %upd<bytes>:exists {
                    $total-bytes ⚛= %upd<bytes>;
                }
            }
            
            # Emit progress update to subscribers
            self!emit-progress-update();
            
            # Rendering - only when not quitting
            if ⚛$!user-quit == 0 {
                # Cache frame values AFTER data loop to avoid stale reads
                my $cached-frame-count = ⚛$frame-count;
                my $cached-total-frames = ⚛$total-frames;
                my $cached-total-bytes = ⚛$total-bytes;

                my $elapsed-str = $!formatter.elapsed($elapsed);
                my $error-indicator = $!stderr-lock.protect: { $error-indicator-cached // '' };
                my Str $spinner-frame-info = '';
                my Str $spinner-bitrate-str = '';
                my $filename-str = $filename-str-with-space;
                
                # Progress output parsing - three branches based on ffmpeg's progress format:
                # Branch 1: progress=end - ffmpeg finished, print final completion line
                # Branch 2: No out_time_us - ffmpeg started but no time progress yet
                # Branch 3: out_time_us present - active progress with time data
                
                # Re-read duration directly from atomic to catch late-detected duration immediately
                my $current-duration-sec = self!duration-sec(self!get-duration-us());
                
                # Compute spinner info for both Branch 2 and Branch 3
                my $fps-read = ($!progress-state.last-fps-scaled / 1000).Num;
                my $fps-stable = (⚛$saw-fps-stable-atomic) != 0;
                if $show-frames {
                    $spinner-frame-info = $!formatter.frame-info(True, $cached-frame-count, $cached-total-frames, $fps-read, $fps-stable);
                }
                if $show-bitrate {
                    my $bt-read = $render-lock.protect: { $last-bitrate };
                    $spinner-bitrate-str = self!bitrate-str($bt-read);
                }
                
                if $block-progress-end {
                    $final-frame-count ⚛= $cached-frame-count;
                    my $time-str = $!formatter.elapsed($elapsed);
                    my $filename-str-bare = $!cached-filename-str;
                    my $fi-read = $render-lock.protect: { $last-frame-info };
                    my $bt-read = $render-lock.protect: { $last-bitrate };
                    self!sync-status(EncodeCompleted);
                    self!sync-quit-percent(100);
                    self!sync-quit-elapsed($elapsed);
                    if $current-duration-sec > 0 {
                        self!print-final-line(
                            $filename-str-bare, $time-str, $current-duration-sec, $bar,
                            $final-frame-count, $cached-total-frames, $fps-read, $fps-stable,
                            $fi-read, $cached-total-bytes, $bt-read, :use-last-frame-fallback
                        );
                    } else {
                        self!print-throttled("\r$filename-str-bare done $time-str\e[K\n", :force);
                    }
                }
                # Branch 2: No out_time_us - ffmpeg output but no time data yet (initial state)
                # Deliberately shows nothing when $pct == 0 to prevent spinner-to-bar flash
                elsif !$block-out-time-us.defined {
                    my $pct = ((⚛$last-percent-scaled) / 1000).Num;
                    if $pct > 0 {
                        my $bt = $render-lock.protect: { $last-bitrate };
                        my $bitrate-branch-str = self!bitrate-str($bt);
                        my $bar-str = $bar.show($pct, :now, :nop);
                        my $eta-read = $render-lock.protect: { $last-eta-str };
                        my $fi-read = $render-lock.protect: { $last-frame-info };
                        self!print-throttled("\r$filename-str$bar-str $elapsed-str $eta-read$fi-read$bitrate-branch-str$error-indicator\e[K", :force);
                    }
                }
                # Branch 3: out_time_us present - active progress with time data
                else {
                    if $block-out-time-us > 0 {
                        my num $time-us = $block-out-time-us.Num;
                        if $time-us > 0 {
                            # Lock spinner/bar decision to prevent transitions
                            # For streams: always spinner. For files: wait for duration detection
                            if !$duration-locked {
                                if $is-stream {
                                    $has-duration = False;
                                    $duration-locked = True;
                                } elsif $current-duration-sec > 0 {
                                    $has-duration = True;
                                    $duration-locked = True;
                                }
                                # If not stream and no duration yet: don't lock, wait for stderr
                            }

                            if $duration-locked && $has-duration {
                                my num $eta = 0e0;  # Reset each iteration
                                my $current-time = $time-us / 1_000_000;
                                my $percent = max(0, ($current-time / $current-duration-sec) * 100);
                                $percent = max($percent, ((⚛$last-percent-scaled) / 1000).Num);
                                $percent = min($percent, 100);
                                my $remaining-video = max(0e0, $current-duration-sec - $current-time);
                                my $spd-read = $!progress-state.last-speed-scaled / 1000;
                                if $spd-read > 0.01 && $current-time > ETA_STABLE_VIDEO_SECONDS {
                                    $eta = $remaining-video / $spd-read;
                                } elsif $percent > max($thresh-eta-pct, 0.001) && $current-time > $thresh-eta-time {
                                    my $raw-eta = $current-time / ($percent / 100) * (100 - $percent);
                                    $eta = $raw-eta if $raw-eta > 0;
                                }
                                $eta = min($eta, ETA_MAX_SECONDS) if $eta > 0;
                                $eta = 0e0 if $percent >= 99.9;
                                my $eta-str = self!format-eta($eta);
                                $render-lock.protect: { $last-eta-str = $eta-str; };
                                my $frame-info = '';
                                if $show-frames {
                                    my $fps = $!progress-state.last-fps-scaled / 1000;
                                    my $fps-stable = (⚛$saw-fps-stable-atomic) != 0;
                                    $frame-info = $!formatter.frame-info(True, $cached-frame-count, $cached-total-frames, $fps, $fps-stable);
                                }
                                my $last-bt = $render-lock.protect: { $last-bitrate };
                                my $bitrate-str = self!bitrate-str($last-bt);

                                $render-lock.protect: { $last-frame-info = $frame-info if $frame-info ne ''; };
                                my $bar-str = $bar.show($percent, :now, :nop);
                                self!render-with-eta($filename-str, $bar-str, $elapsed-str, $eta-str, $frame-info, $bitrate-str, $error-indicator, :$now);
                                $last-percent-scaled ⚛= ($percent * 1000).Int;
                            } else {
                                # No duration (stream/webcam) - show spinner forever
                                my $current-time-str = $!formatter.elapsed($time-us / 1_000_000);
                                self!show-spinner($now, $last-spinner-update, $spinner-idx, @spinner-chars, $filename-str, $error-indicator, $spinner-frame-info, $spinner-bitrate-str, :$current-time-str);
                            }
                        }
                    }
                }
            }
        }
        };

        # =========================================================================
        # SECTION 6: STDERR Tap
        # =========================================================================
        $!proc.stderr(:bin).tap: -> $buf {
            my @complete-lines;
            my $chunk = $!parser.decode-buffer($buf);
            $!stderr-lock.protect: {
                if $chunk ~~ rx/:i [error|failed|invalid|cannot]>> / || $chunk.starts-with("no such", :i) || $chunk.ends-with("denied", :i) {
                    $error-indicator-cached = self.color('red') ~ '!' ~ self.color('reset');
                    # Cache last error line for quick retrieval
                    my @lines = $chunk.split(/\r?\n/);
                    for @lines.reverse -> $line {
                        if $line ~~ /:i (error|failed|invalid|cannot)/ && $line.chars > 0 {
                            $!cached-last-error = $line.substr(0, 100);
                            last;
                        }
                    }
                }
                if !⚛$stderr-capped {
                    my $new-chars = $all-stderr.chars + $chunk.chars;
                    if $new-chars > STDERR_MAX_CHARS {
                        my $remaining = STDERR_MAX_CHARS - $all-stderr.chars;
                        $all-stderr ~= $chunk.substr(0, max(0, $remaining)) if $remaining > 0;
                        $stderr-capped ⚛= 1;
                    } else {
                        $all-stderr ~= $chunk;
                    }
                }
                # Cap err-buffer at 100k to prevent unbounded growth while keeping progress data
                $err-buffer ~= $chunk;
                if $err-buffer.chars > 100_000 {
                    # Trim on newline boundary to avoid cutting mid-line
                    my $cut = $err-buffer.chars - 100_000;
                    my $last-newline = $err-buffer.index("\n", $cut);
                    $err-buffer = $err-buffer.substr($last-newline.defined ?? $last-newline + 1 !! $cut);
                }
                # Drain lines inside lock and capture result
                @complete-lines = self!drain-lines($err-buffer);
                # Sync to instance for API access
                $!all-stderr = $all-stderr;
            };

            # Process each complete line (method handles its own locking)
            for @complete-lines -> $p {
                # When output is stdout, progress key=value lines arrive on stderr
                # (because we passed -progress pipe:2). Parse and render them here.
                if $output-is-stdout {
                    my %upd = $!parser.parse-progress-line($p);
                    if %upd {
                        my $now        = now;
                        my $elapsed    = $now - $start-time;
                        my $elapsed-str = $!formatter.elapsed($elapsed);

                        # ---- state updates (mirrors the stdout tap loop) ----
                        if %upd<progress>:exists && %upd<progress> eq 'end' {
                            $progress-end ⚛= 1 if ⚛$!user-quit == 0;
                            self!sync-progress-end(⚛$!user-quit == 0 ?? 1 !! 0);
                        }
                        if %upd<speed>:exists {
                            my $speed-str = %upd<speed>;
                            if $speed-str.ends-with('x') {
                                my $speed = $speed-str.substr(0, *-1).Num;
                                self!sync-speed-scaled(($speed * 1000).Int) if $speed > 0.01;
                            }
                        }
                        if %upd<fps>:exists {
                            my $parsed-fps = %upd<fps>.Num;
                            if $parsed-fps > 0 {
                                self!sync-fps-scaled(($parsed-fps * 1000).Int);
                                $saw-fps-stable-atomic ⚛= 1;
                                self!sync-saw-fps-stable(1);
                            }
                        }
                        if %upd<frame>:exists {
                            my Int $frame-int = %upd<frame>.Int;
                            $frame-count ⚛= $frame-int;
                            self!sync-frame-count($frame-int);
                            $final-frame-count ⚛= $frame-int;
                            # stall tracking
                            my Int $last-frame = $!progress-state.last-stall-frame;
                            if $last-frame == -1 {
                                $!progress-state.set-stall-start-time-ms(($!encoding-start-time * 1000).Int);
                            } elsif $frame-int != $last-frame {
                                $!progress-state.set-stall-start-time-ms((now * 1000).Int);
                            }
                            $!progress-state.set-last-stall-frame($frame-int);
                            if $elapsed >= FPS_DELAY_SECONDS && $elapsed > 0.001 && ⚛$frame-count > 0 && (⚛$saw-fps-stable-atomic) == 0 {
                                self!sync-fps-scaled((⚛$frame-count / $elapsed * 1000).Int);
                                $saw-fps-stable-atomic ⚛= 1;
                                self!sync-saw-fps-stable(1);
                            }
                        }
                        my $block-out-time-us;
                        if %upd<time-us>:exists {
                            $block-out-time-us = %upd<time-us>;
                            self!sync-time-us($block-out-time-us);
                        }
                        if %upd<bitrate>:exists {
                            my $bitrate-val = %upd<bitrate>;
                            if $bitrate-val ne 'N/A' && $bitrate-val !~~ /^0\.?0*kbits\/s$/ {
                                $render-lock.protect: { $last-bitrate = $bitrate-val };
                                self!sync-bitrate($bitrate-val);
                            }
                        }
                        if %upd<bytes>:exists {
                            $total-bytes ⚛= %upd<bytes>;
                        }

                        self!emit-progress-update();

                        # ---- rendering (mirrors the stdout tap render section) ----
                        if ⚛$!user-quit == 0 {
                            my $cached-frame-count  = ⚛$frame-count;
                            my $cached-total-frames = ⚛$total-frames;
                            my $cached-total-bytes  = ⚛$total-bytes;
                            my $current-duration-sec = self!duration-sec(self!get-duration-us());
                            my $fps-read    = ($!progress-state.last-fps-scaled / 1000).Num;
                            my $fps-stable  = (⚛$saw-fps-stable-atomic) != 0;
                            my $error-indicator = $!stderr-lock.protect: { $error-indicator-cached // '' };
                            my $filename-str = $filename-str-with-space;

                            my Str $spinner-frame-info = '';
                            my Str $spinner-bitrate-str = '';
                            if $show-frames {
                                $spinner-frame-info = $!formatter.frame-info(True, $cached-frame-count, $cached-total-frames, $fps-read, $fps-stable);
                            }
                            if $show-bitrate {
                                my $bt-read = $render-lock.protect: { $last-bitrate };
                                $spinner-bitrate-str = self!bitrate-str($bt-read);
                            }

                            # Branch 1: progress=end
                            if %upd<progress>:exists && %upd<progress> eq 'end' {
                                $final-frame-count ⚛= $cached-frame-count;
                                my $time-str         = $!formatter.elapsed($elapsed);
                                my $filename-str-bare = $!cached-filename-str;
                                my $fi-read  = $render-lock.protect: { $last-frame-info };
                                my $bt-read  = $render-lock.protect: { $last-bitrate };
                                self!sync-status(EncodeCompleted);
                                self!sync-quit-percent(100);
                                self!sync-quit-elapsed($elapsed);
                                if $current-duration-sec > 0 {
                                    self!print-final-line(
                                        $filename-str-bare, $time-str, $current-duration-sec, $bar,
                                        $final-frame-count, $cached-total-frames, $fps-read, $fps-stable,
                                        $fi-read, $cached-total-bytes, $bt-read, :use-last-frame-fallback
                                    );
                                } else {
                                    self!print-throttled("\r$filename-str-bare done $time-str\e[K\n", :force);
                                }
                            }
                            # Branch 2: no out_time_us yet but have prior percent
                            elsif !$block-out-time-us.defined {
                                my $pct = ((⚛$last-percent-scaled) / 1000).Num;
                                if $pct > 0 {
                                    my $bt      = $render-lock.protect: { $last-bitrate };
                                    my $bar-str = $bar.show($pct, :now, :nop);
                                    my $eta-read = $render-lock.protect: { $last-eta-str };
                                    my $fi-read  = $render-lock.protect: { $last-frame-info };
                                    self!print-throttled("\r$filename-str$bar-str $elapsed-str $eta-read$fi-read" ~ self!bitrate-str($bt) ~ "$error-indicator\e[K");
                                }
                            }
                            # Branch 3: active time-based progress
                            elsif $block-out-time-us > 0 {
                                my num $time-us = $block-out-time-us.Num;
                                if !$duration-locked {
                                    if $is-stream {
                                        $has-duration = False;
                                        $duration-locked = True;
                                    } elsif $current-duration-sec > 0 {
                                        $has-duration = True;
                                        $duration-locked = True;
                                    }
                                }
                                if $duration-locked && $has-duration {
                                    my num $eta = 0e0;
                                    my $current-time = $time-us / 1_000_000;
                                    my $percent = max(0, ($current-time / $current-duration-sec) * 100);
                                    $percent = max($percent, ((⚛$last-percent-scaled) / 1000).Num);
                                    $percent = min($percent, 100);
                                    my $remaining-video = max(0e0, $current-duration-sec - $current-time);
                                    my $spd-read = $!progress-state.last-speed-scaled / 1000;
                                    if $spd-read > 0.01 && $current-time > ETA_STABLE_VIDEO_SECONDS {
                                        $eta = $remaining-video / $spd-read;
                                    } elsif $percent > max($thresh-eta-pct, 0.001) && $current-time > $thresh-eta-time {
                                        my $raw-eta = $current-time / ($percent / 100) * (100 - $percent);
                                        $eta = $raw-eta if $raw-eta > 0;
                                    }
                                    $eta = min($eta, ETA_MAX_SECONDS) if $eta > 0;
                                    $eta = 0e0 if $percent >= 99.9;
                                    my $eta-str = self!format-eta($eta);
                                    $render-lock.protect: { $last-eta-str = $eta-str };
                                    my $frame-info = '';
                                    if $show-frames {
                                        my $fps2 = $!progress-state.last-fps-scaled / 1000;
                                        $frame-info = $!formatter.frame-info(True, $cached-frame-count, $cached-total-frames, $fps2, $fps-stable);
                                    }
                                    my $last-bt = $render-lock.protect: { $last-bitrate };
                                    my $bitrate-str = self!bitrate-str($last-bt);
                                    $render-lock.protect: { $last-frame-info = $frame-info if $frame-info ne '' };
                                    my $bar-str = $bar.show($percent, :now, :nop);
                                    self!render-with-eta($filename-str, $bar-str, $elapsed-str, $eta-str, $frame-info, $bitrate-str, $error-indicator, :$now);
                                    $last-percent-scaled ⚛= ($percent * 1000).Int;
                                } else {
                                    # stream / no duration — spinner
                                    my $current-time-str = $!formatter.elapsed($time-us / 1_000_000);
                                    self!show-spinner($now, $last-spinner-update, $spinner-idx, @spinner-chars, $filename-str, $error-indicator, $spinner-frame-info, $spinner-bitrate-str, :$current-time-str);
                                }
                            }
                        }
                        next;  # <-- do NOT pass progress lines to the log/duration handler
                    }
                }

                self!process-stderr-line-and-update-duration(
                    $p, $error-indicator-cached, $!stderr-lock, $suppress-stderr-duration,
                    @durations, $input-count, $seek-start, $has-shortest,
                    $duration-printed, $explicit-duration);
                # $error-indicator-cached updated via is rw parameter
            }
        };

        # Enter raw mode first, then create key supply
        # The supplier buffers events until whenever subscribes
        # Only enter raw mode if stdin is a terminal (not a pipe from ffmpeg)
        my $raw-mode-ok = False;
        if $*IN.t {
            $raw-mode-ok = try { $!terminal.enter-raw-mode // False } // False;
        }
        $key-supply = $!terminal.get-key-supply() if $!terminal.defined && $raw-mode-ok;

        # =========================================================================
        # SECTION 7: Signal Handling (Ctrl+C)
        # =========================================================================
        # Signal handling strategy (SIGINT):
        #   Windows: Force kill and exit immediately (no graceful option)
        #   Unix: 1st = graceful (send 'q'), 2nd = force kill, 3rd+ = exit
        # All output uses :force to ensure messages appear immediately.
        
        # Start process and resolve PID synchronously (safe here, not in signal context)
        my $proc-promise = try $!proc.start;
        
        # Check for start failure (e.g., binary not found, permission denied)
        unless $proc-promise.defined {
            note "Failed to start ffmpeg process";
            $!lifecycle ⚛= 4;  # Aborted before proc start
            return 1;
        }
        
        # Only mark as started after confirming start succeeded (set bit 0)
        # Use CAS to ensure we only set if still in state 2 (not already moved)
        cas($!lifecycle, 2, 3);
        
        # When ffmpeg reads from stdin (-i -), relay ffpb's own $*IN to it.
        # Proc::Async(:w) creates a private pipe to ffmpeg's stdin; the OS
        # shell pipeline connects to ffpb's $*IN, not to ffmpeg directly.
	if $has-stdin-input {
            $stdin-relay-promise = start {
                my $buf-size = 65536;
                loop {
                    my $chunk = try { $*IN.read($buf-size) };
                    last unless $chunk.defined && $chunk.bytes > 0;
                    last if ⚛$!user-quit || ⚛$!stdin-closed;
                    try { await $!proc.write($chunk) };
                }
                $!stdin-closed ⚛= 1;
                try { $!proc.close-stdin };
            }
        }
        
        # Fetch PID reliably (use try to handle edge cases safely)
        my Int $pid = try { $!proc.pid.result } // 0;
        if $pid == 0 && $!verbose {
            note "Warning: could not resolve ffmpeg PID";
        }

        # Windows: assign ffmpeg to a Job Object so it's killed if ffpb is force-closed.
        # The job handle must stay alive until run() exits — closing it triggers the kill.
        $win-job-handle = Nil;
        if IS-WIN && $pid > 0 {
            $win-job-handle = assign-to-kill-job($pid);
            if $!verbose {
                if $win-job-handle.defined {
                    $*ERR.say("Job Object assigned (ffmpeg will be killed if ffpb exits)");
                } else {
                    $*ERR.say("Warning: could not assign ffmpeg to Job Object");
                }
            }
        }

        if IS-WIN {
            # Windows: no reliable signal(SIGINT) support.
            # User can press 'q' in the terminal to quit gracefully.
            $signal-tap = Nil;
        } else {
            # Signal handler only sets flag (async-safe). I/O deferred to main thread via polling.
            $signal-tap = signal(SIGINT).tap: -> $sig {
                $signal-count ⚛+= 1;
            };
        }

        my $result;
        my Bool $timeout-exit = False;
        my $caught-exception;
        react {
            CATCH {
                default {
                    $caught-exception = $_;
                    $*ERR.say("\rUnexpected exception: {$_.message}");
                    done;
                }
            }
             if $key-supply.defined {
                 whenever $key-supply -> $key {
                     given $key {
                         when 'q' | 'Q' {
                             $!user-quit ⚛= 1;
                             $!force-exit-code ⚛= 0;  # Graceful quit != force kill; don't inherit prior force-exit code
                             my Bool $started = ?(⚛$!lifecycle +& 1);
                             try {
                                 if $!proc.defined && $started && !⚛$!stdin-closed {
                                     $!stdin-closed ⚛= 1;
                                     await $!proc.write("q\n".encode);
                                     # close-stdin omitted: relay thread owns stdin and will close it
                                 }
                             }
                            $!output-lock.protect: {
                                $*ERR.print("\r{self.color('yellow')}stopping...{self.color('reset')}\e[K") unless $.quiet;
                                $*ERR.flush;
                            }
                        }
                    }
                }
            }
            # Handle signal events in main thread (safe I/O context)
            # Poll every 50ms: fast response (imperceptible), low overhead, safe for encoding
            whenever Supply.interval(0.05) {
                my Int $current-count = ⚛$signal-count;
                if $current-count > $last-handled-signal-count {
                    $last-handled-signal-count = $current-count;
                    given $current-count {
                        when 1 {
                            $!user-quit ⚛= 1;  # Mark as user-initiated quit
                            self!print-throttled(
                                "\r{self.color('yellow')}stopping...{self.color('reset')}\e[K",
                                :force
                             );
                            my Bool $started = ?(⚛$!lifecycle +& 1);
                            try {
                                if $!proc.defined && $started && !⚛$!stdin-closed {
                                    $!stdin-closed ⚛= 1;
                                    await $!proc.write("q\n".encode);
                                    # close-stdin omitted: relay thread owns stdin and will close it
                                }
                            }
                        }
                        when 2 {
                            $!force-exit-code ⚛= 1;
                            self!print-throttled(
                                "\r{self.color('red')}force stopping...{self.color('reset')}\e[K",
                                :force
                            );
                            try { $!proc.kill(Signal::KILL) if $!proc.defined };
                            done;
                        }

                    }
                }
            }
            # Timeout after 24h to prevent hangs. If timeout fires, kill ffmpeg and treat as failure.
            whenever Promise.anyof($proc-promise, Promise.in(86400)) {
                if $proc-promise.status == Kept {
                    $result = $proc-promise.result;
                } elsif $proc-promise.status == Broken {
                    $result = Nil;  # Process error, not a timeout
                } else {
                    $timeout-exit = True;  # Planned = actual 24h timeout
                    try { $!proc.kill(Signal::KILL) } if $!proc.defined;
                    $result = Nil;
                }
                done;
            }
        }

        # =========================================================================
        # SECTION 8: Exit Code & Final Output
        # =========================================================================
        # Wait for taps to drain BEFORE reading any tap-written state
        # Use lock to ensure no in-flight appends while reading
        await Promise.in(0.2);
        my $trimmed-err = $!stderr-lock.protect: { $err-buffer.trim };
        # Note: $err-buffer at this point holds only the partial/unterminated line
        # (remainder after the last \n in drain-lines). Passing it through
        # process-stderr-line-and-update-duration works for complete key-value progress
        # lines but a truncated progress line (e.g. "Duration: 01:23" missing ".45")
        # may misparse. In practice ffmpeg final stderr flushes with a newline.
        if $trimmed-err ne '' {
            # Matches Section 6 convention: rely on is rw parameter, ignore return value
            self!process-stderr-line-and-update-duration(
                    $trimmed-err,
                    $error-indicator-cached,
                    $!stderr-lock,
                    $suppress-stderr-duration,
                    @durations,
                    $input-count,
                    $seek-start,
                    $has-shortest,
                    $duration-printed,
                    $explicit-duration
                );
        }

        # Rethrow any exception caught in react block
        if $caught-exception {
            die $caught-exception;
        }

        my $exit-code = $result.defined ?? $result.exitcode !! 1;
        my $total-elapsed = now - $start-time;

        # Pre-compute stderr once for both exit paths
        # Only capture stderr on force kill or when explicitly requested
        # Don't capture on user-initiated quit (graceful 'q' or first Ctrl+C)
        my $should-capture = $should-show-stderr
            || ⚛$!force-exit-code != 0  # Force kill (SIGKILL from 2nd Ctrl+C)
            || ($exit-code != 0 && ⚛$!user-quit == 0);  # Unexpected failure
        my $stderr-to-capture = $should-capture
            ?? $!stderr-lock.protect: { $!all-stderr } !! '';

        # Cache duration-sec after sync (used multiple times in Section 8)
        my $duration-sec = self!duration-sec(self!get-duration-us()); 

        if ⚛$!user-quit != 0 && ⚛$progress-end == 0 {
            my $filename-str = $!cached-filename-str;
            my $time-str = $!formatter.elapsed($total-elapsed);
            my $status-str = self.color('yellow') ~ 'aborted' ~ self.color('reset');
            
            # Store percent at quit - clamp to 0-100 to prevent overflow/underflow
            my $pct = max(0, min((⚛$last-percent-scaled / 1000).Num, 100));
            self!sync-quit-percent($pct);
            self!sync-quit-elapsed($total-elapsed);
             
            self!sync-status(EncodeAborted);
            my $fps-read = ($!progress-state.last-fps-scaled / 1000).Num;
            my $fps-stable = (⚛$saw-fps-stable-atomic) != 0;
            my $bt-read = $render-lock.protect: { $last-bitrate };
            if $duration-sec > 0 {
                self!print-final-line(
                    $filename-str, $time-str, $duration-sec, $bar,
                    ⚛$frame-count, ⚛$total-frames, $fps-read, $fps-stable,
                    '', ⚛$total-bytes, $bt-read, :status($status-str), :percent($pct)
                );
            } else {
                my ($frame-info-end, $bitrate-end-str) = self!end-info(⚛$frame-count, ⚛$total-frames, $fps-read, $fps-stable, ⚛$total-bytes, $total-elapsed, $bt-read);
                self!print-throttled("\r$filename-str $status-str $time-str$frame-info-end$bitrate-end-str\n", :force);
            }
            # Show stderr on quit if -E/--stderr was requested, OR always on force quit
            if $should-show-stderr || ⚛$!force-exit-code != 0 {
                my $lines = self!compute-stderr-depth($stderr-lines-valid);
                my $omit-note = !$should-show-stderr && ⚛$!force-exit-code != 0;
                my $capped = self!tail-with-note($stderr-to-capture // '', $lines, :omit-note($omit-note));
                if $capped.trim ne '' {
                    note ⚛$!force-exit-code != 0 
                        ?? "{self.color('red')}{$capped.trim}{self.color('reset')}" 
                        !! $capped.trim;
                }
            }
            return ⚛$!user-quit != 0 ?? 0 !! +⚛$!force-exit-code;
        }

        if $exit-code != 0 || +⚛$!force-exit-code != 0 {
            my $filename-str = $!cached-filename-str;
            my $time-str = $!formatter.elapsed($total-elapsed);
            my $status-str = '';
            
            # Store percent at quit - clamp to 0-100 to prevent overflow/underflow
            my $pct = max(0, min((⚛$last-percent-scaled / 1000).Num, 100));
            self!sync-quit-percent($pct);
            self!sync-quit-elapsed($total-elapsed);
             
            if ⚛$progress-end != 0 && $duration-sec > 0 && ⚛$!user-quit == 0 {
                $status-str = self.color('yellow') ~ 'INCOMPLETE' ~ self.color('reset');
                self!sync-status(EncodeIncomplete);
            } elsif $duration-sec > 0 {
                $status-str = self.color('red') ~ 'FAILED' ~ self.color('reset');
                self!sync-status(EncodeFailed);
            } else {
                self!print-throttled("{self.color('red')}FAILED{self.color('reset')} $time-str\e[K\n", :force);
                my $fallback-lines = self!compute-stderr-depth($stderr-lines-valid);
                my $capped = self!get-stderr-output($stderr-to-capture // '', $fallback-lines);
                note "{self.color('red')}{$capped.trim}{self.color('reset')}" if $capped.trim ne '';
                my $timeout-msg = $timeout-exit ?? ' (24h timeout)' !! '';
                note "ffmpeg failed with exit code $exit-code$timeout-msg";
                self!sync-status(EncodeFailed);
                return $exit-code;
            }
            my $fps-read = ($!progress-state.last-fps-scaled / 1000).Num;
            my $fps-stable = (⚛$saw-fps-stable-atomic) != 0;
            my $bt-read = $render-lock.protect: { $last-bitrate };
            self!print-final-line(
                $filename-str, $time-str, $duration-sec, $bar,
                ⚛$frame-count, +⚛$total-frames, $fps-read, $fps-stable,
                '', +⚛$total-bytes, $bt-read, :status($status-str), :percent($pct)
            );
            my $fallback-lines = self!compute-stderr-depth($stderr-lines-valid);
            my $capped = self!get-stderr-output($stderr-to-capture // '', $fallback-lines);
            note "{self.color('red')}{$capped.trim}{self.color('reset')}" if $capped.trim ne '';
            my $timeout-msg = $timeout-exit ?? ' (24h timeout)' !! '';
            note "ffmpeg failed with exit code $exit-code$timeout-msg";
            return $exit-code;
        }

        # Only print final line if progress=end didn't already handle it
        if ⚛$progress-end == 0 && $duration-sec > 0 {
            my $filename-str = $!cached-filename-str;
            my $time-str = $!formatter.elapsed($total-elapsed);
            my $fps-read = ($!progress-state.last-fps-scaled / 1000).Num;
            my $fps-stable = (⚛$saw-fps-stable-atomic) != 0;
            my $fi-read = $render-lock.protect: { $last-frame-info };
            my $bt-read = $render-lock.protect: { $last-bitrate };
            self!print-final-line(
                $filename-str, $time-str, $duration-sec, $bar,
                $final-frame-count, +$total-frames, $fps-read, $fps-stable,
                $fi-read, +$total-bytes, $bt-read, :use-last-frame-fallback
            );
            self!sync-quit-percent(100) if $exit-code == 0;
            self!sync-quit-elapsed($total-elapsed) if $exit-code == 0;
            self!sync-status(EncodeCompleted);
        } elsif ⚛$progress-end == 0 {
            my $filename-str = $!cached-filename-str;
            my $time-str = $!formatter.elapsed($total-elapsed);
            self!print-throttled("Done in $time-str! $filename-str\n", :force);
            self!sync-quit-percent(100) if $exit-code == 0;
            self!sync-quit-elapsed($total-elapsed) if $exit-code == 0;
            self!sync-status(EncodeCompleted);
        }

        # Show stderr on success if requested
        if $should-show-stderr && $exit-code == 0 {
            my $stderr-to-show = self!get-stderr-output($stderr-to-capture // '', $stderr-lines-valid);
            if $stderr-to-show.trim ne '' {
                note $stderr-to-show;
            }
        }
        return 0;
    }
}

sub ffmpeg-progress(*@args, *%opts) is export {
    FfmpegProgress.new(|%opts).run(@args);
}

=begin pod

=head1 NAME

FFmpegProgressBar - Add a progress bar to ffmpeg commands

=head1 DESCRIPTION

Provides a progress bar for ffmpeg encoding operations. Uses Terminal::Spinners
for rendering and detects duration automatically via ffprobe or by parsing
-t/-to/-ss arguments.

Supports graceful shutdown via 'q' or Ctrl+C (Unix), preserving partial output.

=head1 SUBROUTINES

=item sub ffmpeg-progress(*@args, *%opts) is export

Convenience wrapper. Equivalent to:

    FfmpegProgress.new(|%opts).run(@args);

Valid %opts keys (any FfmpegProgress attribute):
=item duration - Numeric duration in seconds
=item ffmpeg - Str path to ffmpeg binary (default: 'ffmpeg')
=item ffprobe - Str path to ffprobe binary (default: 'ffprobe')
=item bar-type - Str 'bar', 'hash', 'hash-dash', or 'equals'
=item show-frames - Bool show frame count
=item show-bitrate - Bool show bitrate
=item no-color - Bool disable colors
=item verbose - Bool show detected duration and command

B<Note:> Extra keys in %opts are silently ignored. Use named parameters
with the module for validation, e.g. C<FfmpegProgress.new(:verbose)>. 

Example:

    ffmpeg-progress('-i', 'input.mp4', '-c:v', 'libx264', 'output.mp4');

=head1 ATTRIBUTES

=item $!ffmpeg - Path to ffmpeg binary (default: "ffmpeg")

=item $!ffprobe - Path to ffprobe binary (default: "ffprobe")

=item $!duration - Manually set duration in seconds (default: 0, auto-detected)

=item $!verbose - Show detected duration and executed command

=item $.show-frames - Show current frame and encoding fps

=item $.show-bitrate - Show output bitrate

=item $.stderr-lines - Number of stderr lines to show on success (default: '', 20 lines if --stderr used)

=item $!bar-type - Progress bar style: bar, hash, hash-dash, or equals

=item $.output-throttle - Minimum time between output updates (default: 0.1 seconds)

=item $!no-color - Disable colored output

=item $.dry-run - Validate args without running ffmpeg

=item $.eta-percent-threshold - Percent threshold for ETA calculation (default: 5)

=item $.eta-time-threshold - Time threshold (seconds) for ETA calculation (default: 4)

=item EncodeSkipped - Output file(s) already exist and -n was passed; ffmpeg did nothing

=head1 METHODS

=item method new(...) - Create FfmpegProgress instance

=item method run(*@args --> Int) - Run ffmpeg with progress bar, returns exit code

=item sub ffmpeg-progress(*@args --> Int) - Convenience function wrapper

=item method color(Str $name) - Get ANSI color code by name (reset, green, red, yellow, cyan, bold)

=item method bar-length() - Returns appropriate bar length for terminal width

=item method get-duration(Str $file) - Get video duration via ffprobe

=item method get-frame-count(Str $file) - Get video frame count via ffprobe

=item method quit(Bool :$force = False) - Quit the running ffmpeg process. Use :force for immediate kill.

=head2 Progress Tracking API

FFmpegProgressBar provides a progress API for external code to monitor encoding:

=item method get-progress(--> ProgressSnapshot) - Get current progress as an immutable snapshot. Returns a L<ProgressSnapshot|FFmpegProgressBar::ProgressSnapshot> object with: percent, elapsed, fps, speed, frame-count, total-frames, bitrate, status, is-stalled, last-error, eta.

=item method progress-supply(--> Supply) - Get a Supply that emits ProgressSnapshot updates. Use this for reactive/async progress monitoring.

=item method watch-progress(Numeric :$interval = 0.1, Bool :$emit = False --> Supply) - Simple progress iteration. By default yields percent (0-100). Use :emit to yield full ProgressSnapshot instead. Recommended for most use cases - no manual promise management needed.

=head3 Example: Using watch-progress() (Simplest)

=begin code
use FFmpegProgressBar;

my $p = FfmpegProgress.new(:quiet);  # Suppress progress bar, use API only
my $promise = start { $p.run('-i', 'input.mp4', 'output.mp4') };

for $p.watch-progress(:interval(0.5)) -> $percent {
    say "Progress: {$percent.fmt('%.1f')}%";
    $p.quit() if $percent >= 50;
}

await $promise;
say $p.get-progress().summary;
=end code

Quitting early based on progress:

=begin code
for $p.watch-progress(:emit) -> $snap {
    $p.quit() if $snap.percent >= 50;
    $p.quit() if $snap.is-stalled;
}
=end code

=head3 Alternative: get-progress() (One-off)

For one-off reads:

=begin code
my $snap = $p.get-progress();
say $snap.percent;
say $snap.is-complete;
=end code

=head3 ProgressSnapshot Methods

=item method summary() - Human-readable one-line summary (e.g., "75.0% [500/1000 25.0fps] @ 2.5Mbps ETA: 3s")

=item method remaining-seconds(--> Numeric) - Estimated seconds remaining

=item method completion-time(--> DateTime) - Estimated DateTime when encoding will finish

=item method is-complete(--> Bool) - True if encoding finished successfully

=item method is-failed(--> Bool) - True if encoding failed or was aborted

=head3 Example: External Progress Monitoring with Quit

This example shows how to monitor progress externally and quit early based on progress:

=begin code
use FFmpegProgressBar;

my $p = FfmpegProgress.new;

# Start encoding in background
my $promise = start {
    $p.run('-i', 'input.mp4', '-c:v', 'libx264', 'output.mp4');
};

# Poll progress until quit condition or completion
loop {
    last if $promise.status ~~ Kept | Broken;
    
    my $snap = $p.get-progress();
    say "Progress: {$snap.percent.fmt('%.1f')}% - {$snap.status}";
    
    # Quit at 50% if some external condition is met
    if $snap.percent >= 50 && $snap.percent < 75 {  # e.g. quit between 50-75%
        say "Quitting at 50%!";
        $p.quit();
        last;
    }
    
    if $snap.is-complete || $snap.is-failed {
        last;
    }
    
    sleep 0.1;
}

await $promise;

my $final = $p.get-progress();
say "Final: {$final.summary}";
say "Final status: {$final.status}";
=end code

For reactive monitoring using Supply:

=begin code
use FFmpegProgressBar;

my $p = FfmpegProgress.new;

# Start encoding and subscribe to progress updates
my $promise = start {
    $p.run('-i', 'input.mp4', 'output.mp4');
};

$p.progress-supply.tap: -> $snap {
    say "Progress: {$snap.percent.fmt('%.1f')}% - ETA: {$snap.eta // '?'}s";
};

await $promise;
=end code

=item method run-pass1(Array $args --> Int) - Run first pass of two-pass encoding

=item method detect-duration(Numeric $duration, Numeric $output-duration, Numeric $seek-start, Bool $has-shortest, @input-groups, $mapped-inputs, Numeric $output-seek = 0) - Detect effective duration from multiple sources (considers -map and -ss/-t/-to to filter relevant inputs)

=head1 SIGNAL HANDLING

=item B<Unix/Linux/macOS>: First Ctrl+C sends 'q' (graceful), second force-kills ffmpeg, third exits program. During two-pass pass 1, Ctrl+C aborts the analysis pass.

=item B<Windows>: Press 'q' for graceful shutdown. Ctrl+C force kills ffmpeg immediately.

=head1 TWO-PASS ENCODING

When C<-pass 2> is detected in the arguments, FFmpegProgressBar automatically runs the first (analysis) pass before showing the progress bar for the second (encoding) pass. Signal handling works during both passes.

=head1 COMMAND-LINE USAGE

The module installs the C<ffpb> command for CLI usage:

    ffpb -i input.mp4 output.mp4
    ffpb -V -F -B -i input.mp4 output.mp4
    ffpb -S hash -D 60 -i input.mp4 output.mp4
    ffpb -M /usr/bin/ffmpeg -P /usr/bin/ffprobe -i input.mp4 output.mp4
    ffpb -E -i input.mp4 output.mp4

Use C<ffpb --help> for options, or C<ffpb --man> for the full manual.

=head1 CLI OPTIONS

=item B<-h>, B<--help> - Show help message

=item B<-V>, B<--verbose> - Show detected duration and executed command

=item B<-F>, B<--frames> - Show current frame and encoding fps

=item B<-B>, B<--bitrate> - Show output bitrate

=item B<-S>, B<--style>=I<style> - Set progress bar style (bar, hash, hash-dash, equals)

=item B<-D>, B<--duration>=I<seconds> - Set duration in seconds (skip auto-detection)

=item B<-M>, B<--ffmpeg>=I<path> - Path to ffmpeg binary

=item B<-P>, B<--ffprobe>=I<path> - Path to ffprobe binary

=item B<-E>, B<--stderr>[=I<N>|all] - Show ffmpeg stderr on successful completion. Without value: last 20 lines. With value: N lines or 'all'.

=item B<--version> - Show version information

=item B<--man> - Show full manual page

=head1 CONFIG FILES

Config files are checked in the following order:

=head2 Unix/Linux/macOS

=item F<~/.ffpbrc>

=item F<~/.config/ffpbrc>

=item F<~/.config/ffpb/config>

=item F</etc/ffpbrc>

=head2 Windows

=item F<%USERPROFILE%\.ffpbrc>

=item F<%USERPROFILE%\.config\ffpbrc>

=item F<%USERPROFILE%\.config\ffpb\config>

=item F<%APPDATA%\ffpb\config>

=item F<%APPDATA%\ffpbrc>

Each line should contain one option (like CLI arguments). Lines
starting with C<#> are treated as comments.

=head1 SEE ALSO

L<FFmpegProgressBar::Parser>, L<FFmpegProgressBar::Formatter>, L<FFmpegProgressBar::Probe>, L<FFmpegProgressBar::Terminal>

=end pod
