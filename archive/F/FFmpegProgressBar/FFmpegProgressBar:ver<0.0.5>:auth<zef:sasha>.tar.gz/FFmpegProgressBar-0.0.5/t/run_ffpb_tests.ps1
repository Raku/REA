$ErrorActionPreference = "Stop"

# ------------------------------------------------------------
# Temp working directory
# ------------------------------------------------------------
$workDir = Join-Path $env:TEMP ("ffpb-tests-" + [System.Guid]::NewGuid().ToString())

New-Item -ItemType Directory -Path $workDir | Out-Null

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item (Join-Path $scriptDir "myVideo_with_tone.mp4") (Join-Path $workDir "input.mp4")
Copy-Item (Join-Path $scriptDir "Give It To Me Straight - Jeremy Black.mp3") (Join-Path $workDir "audio.mp3")
Set-Location $workDir

# ------------------------------------------------------------
# Cleanup (idempotent)
# ------------------------------------------------------------
$cleanupDone = $false

function Cleanup {
    if ($script:cleanupDone) { return }
    $script:cleanupDone = $true

    Write-Host ""
    Write-Host "Cleaning up..."

    Set-Location $env:TEMP
    Remove-Item $workDir -Recurse -Force -ErrorAction SilentlyContinue
}

# ------------------------------------------------------------
# Ensure cleanup always runs on exit
# ------------------------------------------------------------
Register-EngineEvent PowerShell.Exiting -Action { Cleanup } | Out-Null

# ------------------------------------------------------------
# Ctrl+C handling (reliable version)
# ------------------------------------------------------------
$null = Register-EngineEvent Console_CancelKeyPress -Action {
    Write-Host ""
    Write-Host "Interrupted (Ctrl+C). Cleaning up..."
    Cleanup
    exit 130
}

# ------------------------------------------------------------
# Safe runner
# ------------------------------------------------------------
function Run($cmd) {
    Write-Host ""
    Write-Host "============================================================"
    Write-Host $cmd
    Write-Host "============================================================"

    try {
        & cmd /c $cmd
    }
    catch {
        Write-Host "FAILED: $cmd"
    }
}

# ------------------------------------------------------------
# Test suite
# ------------------------------------------------------------

# Basic cases
Run "ffpb -y -i input.mp4 output.mkv"
Run "ffpb -y -i input.mp4 -c:v libx264 -crf 23 output.mp4"
Run "ffpb -y -i input.mp4 -vn -c:a aac audio_out.aac"
Run "ffpb -y -i input.mp4 -an -c:v copy no_audio.mp4"
Run "ffpb -y -i input.mp4 -i audio.mp3 -map 0:v -map 1:a -c:v copy -shortest output_replace_audio.mp4"

# Seeking
Run "ffpb -y -ss 10 -i input.mp4 -c copy seeked.mp4"
Run "ffpb -y -i input.mp4 -ss 10 -c copy out_ss.mp4"
Run "ffpb -y -i input.mp4 -t 30 -c copy thirty_sec.mp4"
Run "ffpb -y -i input.mp4 -to 00:01:00 -c copy one_min.mp4"
Run "ffpb -y -ss 5 -i input.mp4 -t 20 -c copy segment.mp4"
Run "ffpb -y -ss 00:00:05 -i input.mp4 -to 00:00:25 -c copy segment2.mp4"

# Overwrite behavior
Run "ffpb -y -i input.mp4 output_overwrite.mp4"
Run "ffpb -n -i input.mp4 output_no_overwrite.mp4"

# Two-pass
Run "ffpb -y -i input.mp4 -c:v libx264 -b:v 1M -pass 2 -f mp4 output_2pass.mp4"

# Map tests
Run "ffpb -y -i input.mp4 -i audio.mp3 -map 0:v:0 -map 1:a:0 -c copy mapped.mp4"
Run "ffpb -y -i input.mp4 -map 0 -map -0:a -c copy video_only.mp4"
Run "ffpb -y -i input.mp4 -i audio.mp3 -map 0 -map 1 -c copy all_streams.mkv"

# Multiple outputs
Run "ffpb -y -i input.mp4 -c:v libx264 out1.mp4 -c:v libx265 out2.mp4"
Run "ffpb -y -i input.mp4 -t 10 short.mp4 -t 30 medium.mp4"

# filter_complex
Run "ffpb -y -i input.mp4 -vf scale=1280:720 scaled.mp4"

Run "ffpb -y -i input.mp4 -i audio.mp3 -filter_complex ""[0:v][1:a]concat=n=1:v=1:a=1[v][a]"" -map ""[v]"" -map ""[a]"" filter_out.mp4"

Run "ffpb -y -i input.mp4 -i input.mp4 -filter_complex ""[0:v][1:v]hstack[v]"" -map ""[v]"" -an hstack.mp4"

Run "ffpb -y -i input.mp4 -i audio.mp3 -filter_complex ""[0:a][1:a]amix=inputs=2[a]"" -map 0:v -map ""[a]"" -c:v copy mixed.mp4"

Run "ffpb -y -i input.mp4 -filter_complex ""[0:v]trim=0:10,setpts=PTS-STARTPTS[a];[0:v]trim=20:30,setpts=PTS-STARTPTS[b];[a][b]concat[v]"" -map ""[v]"" -an concat_trim.mp4"

# Loglevel
Run "ffpb -y -i input.mp4 -loglevel quiet output_q.mp4"
Run "ffpb -y -i input.mp4 -loglevel error output_e.mp4"
Run "ffpb -y -i input.mp4 -v fatal output_f.mp4"
Run "ffpb -y -i input.mp4 -loglevel info output_i.mp4"

# Pipe test
Run "cmd /c `"ffmpeg -y -i input.mp4 -f matroska - 2>nul | ffpb -y -i - -c copy from_pipe.mp4`""

# ffpb flags
Run "ffpb -y -Q -i input.mp4 quiet_out.mp4"
Run "ffpb -y -D 25 -V -i input.mp4 -c copy duration_override.mp4"

# Edge cases
Run "ffpb -y -i input.mp4 -ss -0 -c copy neg_ss.mp4"
Run "ffpb -y -- -i input.mp4 output_dashdash.mp4"
Run "ffpb -y -i input.mp4 -c copy -- -weird-name.mp4"
Run "ffpb -y -i input.mp4 -t 0.5 -c copy tiny.mp4"

# ------------------------------------------------------------
# Done
# ------------------------------------------------------------
Cleanup