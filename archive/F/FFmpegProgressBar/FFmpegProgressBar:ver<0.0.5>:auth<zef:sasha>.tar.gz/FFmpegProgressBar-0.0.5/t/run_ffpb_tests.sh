#!/usr/bin/env bash
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKDIR="$(mktemp -d -t ffpb-tests-XXXXXX)"

cp "$SCRIPT_DIR/myVideo_with_tone.mp4" "$WORKDIR/input.mp4"
cp "$SCRIPT_DIR/Give It To Me Straight - Jeremy Black.mp3" "$WORKDIR/audio.mp3"

cd "$WORKDIR"

cleanup() {
  rm -rf "$WORKDIR"
}

on_interrupt() {
  echo
  echo "Interrupted. Cleaning up..."
  cleanup
  exit 130
}

trap cleanup EXIT
trap on_interrupt INT TERM

run() {
  echo
  echo "============================================================"
  echo "$*"
  echo "============================================================"

  "$@"
  status=$?

  if [ "$status" -eq 130 ]; then
    exit 130
  fi

  return "$status"
}

# ------------------------------------------------------------------
# Basic cases
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 output.mkv
run ffpb -y -i input.mp4 -c:v libx264 -crf 23 output.mp4
run ffpb -y -i input.mp4 -vn -c:a aac audio_out.aac
run ffpb -y -i input.mp4 -an -c:v copy no_audio.mp4
run ffpb -y -i input.mp4 -i audio.mp3 -map 0:v -map 1:a -c:v copy -shortest output_replace_audio.mp4

# ------------------------------------------------------------------
# Seeking and duration flags
# ------------------------------------------------------------------
run ffpb -y -ss 10 -i input.mp4 -c copy seeked.mp4
run ffpb -y -i input.mp4 -ss 10 -c copy out_ss.mp4
run ffpb -y -i input.mp4 -t 30 -c copy thirty_sec.mp4
run ffpb -y -i input.mp4 -to 00:01:00 -c copy one_min.mp4
run ffpb -y -ss 5 -i input.mp4 -t 20 -c copy segment.mp4
run ffpb -y -ss 00:00:05 -i input.mp4 -to 00:00:25 -c copy segment2.mp4

# ------------------------------------------------------------------
# Overwrite prompts
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 output_overwrite.mp4
run ffpb -y -i input.mp4 output_overwrite2.mp4
run ffpb -n -i input.mp4 output_no_overwrite.mp4

# ------------------------------------------------------------------
# Two-pass encoding
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 -c:v libx264 -b:v 1M -pass 2 -f mp4 output_2pass.mp4

# ------------------------------------------------------------------
# -map flag variations
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 -i audio.mp3 -map 0:v:0 -map 1:a:0 -c copy mapped.mp4
run ffpb -y -i input.mp4 -map 0 -map -0:a -c copy video_only.mp4
run ffpb -y -i input.mp4 -i audio.mp3 -map 0 -map 1 -c copy all_streams.mkv

# ------------------------------------------------------------------
# Multiple outputs
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 -c:v libx264 out1.mp4 -c:v libx265 out2.mp4
run ffpb -y -i input.mp4 -t 10 short.mp4 -t 30 medium.mp4

# ------------------------------------------------------------------
# filter_complex cases
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 -vf scale=1280:720 scaled.mp4

run ffpb -y -i input.mp4 -i audio.mp3 \
  -filter_complex "[0:v][1:a]concat=n=1:v=1:a=1[v][a]" \
  -map "[v]" -map "[a]" filter_out.mp4

run ffpb -y -i input.mp4 -i input.mp4 \
  -filter_complex "[0:v][1:v]hstack[v]" \
  -map "[v]" -an hstack.mp4

run ffpb -y -i input.mp4 -i audio.mp3 \
  -filter_complex "[0:a][1:a]amix=inputs=2[a]" \
  -map 0:v -map "[a]" -c:v copy mixed.mp4

run ffpb -y -i input.mp4 \
  -filter_complex "[0:v]trim=0:10,setpts=PTS-STARTPTS[a]; \
                   [0:v]trim=20:30,setpts=PTS-STARTPTS[b]; \
                   [a][b]concat[v]" \
  -map "[v]" -an concat_trim.mp4

# ------------------------------------------------------------------
# Loglevel edge cases
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 -loglevel quiet output_q.mp4
run ffpb -y -i input.mp4 -loglevel error output_e.mp4
run ffpb -y -i input.mp4 -v fatal output_f.mp4
run ffpb -y -i input.mp4 -loglevel info output_i.mp4

# ------------------------------------------------------------------
# Pipe and special inputs
# ------------------------------------------------------------------
run bash -c 'ffmpeg -y -i input.mp4 -f matroska - 2>/dev/null | ffpb -y -i - -c copy from_pipe.mp4'
run ffpb -y -f lavfi -i testsrc=duration=10:size=320x240:rate=30 testsrc.mp4

# ------------------------------------------------------------------
# ffpb-specific flags combined
# ------------------------------------------------------------------
run ffpb -y -V -F -B -S hash -i input.mp4 -c:v libx264 verbose_full.mp4
run ffpb -y -Q -i input.mp4 quiet_out.mp4
run ffpb -y -D 25 -V -i input.mp4 -c copy duration_override.mp4
run ffpb -y -E -i input.mp4 output_stderr.mp4
run ffpb -y -E 5 -i input.mp4 output_stderr5.mp4
run ffpb -y -E all -i input.mp4 output_stderrall.mp4
run ffpb -y -S bar -i input.mp4 style_bar.mp4
run ffpb -y -S hash -i input.mp4 style_hash.mp4
run ffpb -y -S hash-dash -i input.mp4 style_hashdash.mp4
run ffpb -y -S equals -i input.mp4 style_equals.mp4

# ------------------------------------------------------------------
# Edge cases likely to expose parser bugs
# ------------------------------------------------------------------
run ffpb -y -i input.mp4 -ss -0 -c copy neg_ss.mp4
run ffpb -y -- -i input.mp4 output_dashdash.mp4
run ffpb -y -i input.mp4 -c copy -- -weird-name.mp4
run ffpb -y -i input.mp4 -t 0.5 -c copy tiny.mp4
run ffpb -y -i input.mp4 -f matroska - > piped.mkv 

echo
echo "All test commands completed."
