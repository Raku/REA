use v6.d;

unit class FFmpegProgressBar::Parser:ver<0.0.4>:auth<zef:sasha>;

use FFmpegProgressBar::FFmpegFlags;

my constant IS-WIN = $*DISTRO.is-win;

# Use flags from FFmpegFlags module (comprehensive list from ffmpeg -h full)
my constant $value-taking-opts = $FFmpegProgressBar::FFmpegFlags::value-taking-opts;
my constant $value-taking-prefixes = $FFmpegProgressBar::FFmpegFlags::value-taking-prefixes;
my constant $duration-affecting-opts = $FFmpegProgressBar::FFmpegFlags::duration-affecting-opts;
my constant $no-value-flags = $FFmpegProgressBar::FFmpegFlags::no-value-flags;

# Pre-compiled regex constants for parse-time (avoid recompilation on each call)
my constant &RX-HMS-FRAC = rx{^ $<h>=(\d+) ':' $<m>=(\d+) ':' $<s>=(\d+) '.' $<f>=(\d+) $};
my constant &RX-HMS      = rx{^ $<h>=(\d+) ':' $<m>=(\d+) ':' $<s>=(\d+) $};
my constant &RX-MS-FRAC  = rx{^ $<m>=(\d+) ':' $<s>=(\d+) '.' $<f>=(\d+) $};
my constant &RX-MS       = rx{^ $<m>=(\d+) ':' $<s>=(\d+) $};
my constant &RX-HMS-UNIT = rx{^ $<h>=(\d+\.?\d*)h\s* $<m>=(\d+\.?\d*)m\s* $<s>=(\d+\.?\d*)s$};
my constant &RX-HM-UNIT  = rx{^ $<h>=(\d+\.?\d*)h\s* $<m>=(\d+\.?\d*)m$};

my constant &RX-MS-UNIT  = rx{^ $<m>=(\d+\.?\d*)m\s* $<s>=(\d+\.?\d*)s$};
my constant &RX-H-UNIT   = rx{^ $<h>=(\d+\.?\d*)h\s* $};
my constant &RX-M-UNIT   = rx{^ $<m>=(\d+\.?\d*)m$};
my constant &RX-S-UNIT  = rx{^ $<s>=(\d+\.?\d*)s$};

# Negative number regex for detecting values vs flags (e.g., -0.5, -1e-3)
my constant &RX-NEG-NUM = rx{^ '-' ( \d+ ['.' \d*]? | '.' \d+ ) [ <[eE]> <[+-]>? \d+ ]? $};

# ============================================================================
# ParsedOptions - Value object for get-effective-options return type
# ============================================================================
class FFmpegProgressBar::Parser::ParsedOptions {
    has Bool $.verbose;
    has Bool $.quiet;
    has Bool $.show-frames;
    has Bool $.show-bitrate;
    has Bool $.no-color;
    has Str $.bar-type;
    has Numeric $.duration = 0;
    has Str $.ffmpeg = '';
    has Str $.ffprobe = '';
    has Str $.stderr-lines = '';
    has @.rest;
    has %.set;

    method as-capture() {
        Capture.new(:list(@.rest.list), :hash({
            verbose      => $.verbose,
            quiet       => $.quiet,
            show-frames  => $.show-frames,
            show-bitrate => $.show-bitrate,
            no-color     => $.no-color,
            bar-type     => $.bar-type,
            duration     => $.duration,
            ffmpeg       => $.ffmpeg,
            ffprobe      => $.ffprobe,
            stderr-lines => $.stderr-lines,
        }))
    }
}

# ============================================================================
# InputGroup - Groups an input file with its preceding options
# ============================================================================
class FFmpegProgressBar::Parser::InputGroup {
    has Str $.file;
    has Numeric $.seek = 0;
}

# ============================================================================
# MapSelection - Represents -map argument selection with include/exclude
# ============================================================================
class FFmpegProgressBar::Parser::MapSelection {
    has Set $.include;
    has Set $.exclude;
    has Bool $.unknown = False;
}

# ============================================================================
# OutputSpec - Per-output specification with its own timeline context
# ============================================================================
class FFmpegProgressBar::Parser::OutputSpec {
    has $.file is rw;
    has $.duration is rw = 0;
    has $.to is rw = 0;
    has $.ss is rw = 0;
    has Bool $.shortest is rw = False;
}

# ============================================================================
# Parser - Argument & Output Parsing
# ============================================================================
# Parses:
#   - ffmpeg progress output (e.g., "frame=100", "out_time_us=5000000")
#   - CLI arguments (-i, -t, -to, -ss, -y, -filter_complex)
#   - Config files (~/.ffpbrc)
#   - Duration strings (HH:MM:SS format from ffmpeg stderr)

# Precompiled regex for parse-progress-line (avoids recompilation on each call)
# Key must be pure word chars (no spaces); value is everything after '=' to end of line.
# This rejects garbled lines where ffmpeg concatenated multiple progress lines without newlines.
my regex progress-kv { ^ $<key>=(\w+) '=' $<val>=(\S.*) $ }

# Whitelist of known ffmpeg -progress keys. Anything not in this set is ignored.
# This prevents the forward-compat else-branch from storing garbage into %h and
# making the hash truthy on a garbled line.
my constant $KNOWN-PROGRESS-KEYS = set <
    frame fps bitrate total_size out_time_us out_time_ms out_time
    dup_frames drop_frames speed progress out_bytes
>;

# Helper for output detection - stronger heuristic to avoid false positives
sub looks-like-file(Str $arg --> Bool) {
    return True if $arg eq '-' || $arg.starts-with('pipe:');
    return False if $arg.starts-with('-');
    return False if $arg ~~ /^\[[^\]]+\]$/;  # filter labels like [v], [out]
    return False if $arg ~~ /^\w+ '='/;  # filter expressions like scale=, trim=
    return True;
}

# Short flag mappings (e.g., -V -> verbose)
our %flag-opts is export = (
    '--verbose' => 'verbose',
    '-V'        => 'verbose',
    '--quiet'   => 'quiet',
    '-Q'        => 'quiet',
    '--frames'  => 'show-frames',
    '-F'        => 'show-frames',
    '--bitrate' => 'show-bitrate',
    '-B'        => 'show-bitrate',
    '--no-color' => 'no-color',
    '-h'        => 'help',
);

our %value-opts is export = (
    '--style' => 'bar-type',
    '-S'      => 'bar-type',
    '--duration' => 'duration',
    '-D'      => 'duration',
    '--total-time' => 'duration',
    '--ffmpeg' => 'ffmpeg',
    '-M'      => 'ffmpeg',
    '--ffprobe' => 'ffprobe',
    '-P'      => 'ffprobe',
    '--stderr' => 'stderr-lines',
    '-E'      => 'stderr-lines',
);

# Default value when a value-option is passed without a following argument on CLI
    my constant %value-opt-defaults = 
        stderr-lines => '20',
        bar-type     => '',
        duration     => '0',
        ffmpeg       => '',
        ffprobe      => '',
        verbose      => False,
        quiet       => False,
        show-frames => False,
        show-bitrate => False,
        no-color     => False;

# Decodes binary output from ffmpeg, replacing invalid sequences
method decode-buffer(Blob $buf --> Str) {
    $buf.decode('utf-8', :replace);
}

# Parses a single line from ffmpeg's -progress pipe:1 output.
# Example lines: "frame=100", "out_time_us=5000000", "bitrate=1.2M", "speed=1.5x", "progress=end"
# Returns hash with normalized keys (e.g., 'time-us', 'bytes', 'bitrate', 'speed', 'progress')
method parse-progress-line(Str $line --> Hash) {
    my %h;
    if $line ~~ &progress-kv {
        my $k = ~$<key>;
        my $v = ~$<val>;
        if $k eq 'frame' {
            %h<frame> = $v.trim.Int if $v.trim ~~ /^\d+$/;
        } elsif $k eq 'out_bytes' {
            %h<bytes> = $v.trim.Int if $v.trim ~~ /^\d+$/;
        } elsif $k eq 'out_time_us' {
            # -1 is ffmpeg's initial "not started" state - allowed through parsing
            # but gated at render time (> 0 check in stdout tap prevents display)
            %h<time-us> = $v.trim.Int if $v.trim ~~ / ^ ('-1' | \d+) $ /;
        } elsif $k eq 'fps' {
            %h<fps> = $v.trim.Num if $v.trim ~~ /^\d+(\.\d+)?$/ && $v.trim ne 'N/A' && $v.trim ne 'nan';
        } elsif $k eq 'bitrate' {
            # Always return trimmed raw string - let Formatter handle formatting
            %h<bitrate> = $v.trim;
        } elsif $k eq 'speed' {
            %h<speed> = $v.trim;
        } elsif $k eq 'progress' {
            %h<progress> = $v.trim;
        } else {
            # Forward compatibility - only store keys we recognise as progress keys.
            # Unknown/garbled keys (e.g. from concatenated lines) are silently dropped
            # so %h stays empty and the caller's `if %upd` guard correctly skips them.
            %h{$k} = $v.trim if $k (elem) $KNOWN-PROGRESS-KEYS;
        }
    }
    return %h;
}

# Parses duration from ffmpeg stderr, e.g., "Duration: 01:23:45.67"
# Returns duration in seconds as Numeric, or Nil if not found or N/A
method parse-duration(Str $line) {
    return Nil if $line ~~ / Duration \: \s* N\/A /;
    # Match Duration: anywhere in line (may have log prefixes like [info])
    if $line ~~ m/ 'Duration:' \s+ $<h>=(\d+) ':' $<m>=(\d+) ':' $<s>=(\d+) [ '.' $<f>=(\d+) ]? / {
        my $frac = $<f> ?? do {
            my $s = ~$<f>;
            $s.Int / (10 ** $s.chars)
        } !! 0;
        return $<h>.Int * 3600 + $<m>.Int * 60 + $<s>.Int + $frac;
    }
    return Nil;
}

# Parses time/duration from various formats:
#   HH:MM:SS       -> hours:minutes:seconds
#   MM:SS         -> minutes:seconds
#   1h 30m 15s    -> human-readable with h/m/s units
#   123 or 0.5    -> bare number or decimal treated as seconds
# Returns seconds as Numeric (may be Rat or Num depending on branch).
# Callers multiply by 1_000_000 and call .Int, which works for both types.
#
# NOTE: "1:2" is interpreted as MM:SS (1 minute 2 seconds). This may differ
# from ffmpeg's interpretation in some contexts where it could mean HH:MM.
our sub parse-time(Str:D $s --> Numeric) is export {
    my $trimmed = $s.trim;

    given $trimmed {
        when &RX-HMS-FRAC {
            my $frac-str = ~$<f>;
            my $frac = $frac-str.Int / (10 ** $frac-str.chars);
            return $<h>.Int * 3600 + $<m>.Int * 60 + $<s>.Int + $frac;
        }
        when &RX-HMS {
            return $<h>.Int * 3600 + $<m>.Int * 60 + $<s>.Int;
        }
        when &RX-MS-FRAC {
            # Always treat MM:SS.frac as minutes:seconds (ffmpeg convention)
            my $frac = $<f> ?? do {
                my $frac-str = ~$<f>;
                $frac-str.Int / (10 ** $frac-str.chars)
            } !! 0;
            return $<m>.Int * 60 + $<s>.Int + $frac;
        }
        when &RX-MS {
            # Always treat MM:SS as minutes:seconds (ffmpeg convention)
            # Note: "1:2" is treated as 1 minute 2 seconds, matching ffmpeg behavior
            return $<m>.Int * 60 + $<s>.Int;
        }
        when &RX-HMS-UNIT {
            my $h = $<h>.defined ?? $<h>.Num !! 0;
            my $m = $<m>.defined ?? $<m>.Num !! 0;
            my $s = $<s>.defined ?? $<s>.Num !! 0;
            return $h * 3600 + $m * 60 + $s;
        }
        when &RX-HM-UNIT {
            my $h = $<h>.defined ?? $<h>.Num !! 0;
            my $m = $<m>.defined ?? $<m>.Num !! 0;
            return $h * 3600 + $m * 60;
        }
        when &RX-MS-UNIT {
            my $m = $<m>.defined ?? $<m>.Num !! 0;
            my $s = $<s>.defined ?? $<s>.Num !! 0;
            return $m * 60 + $s;
        }
        when &RX-H-UNIT {
            return $<h>.Num * 3600;
        }
        when &RX-M-UNIT {
            return $<m>.Num * 60;
        }
        when &RX-S-UNIT {
            return $<s>.Num;
        }
        default {
            return Nil unless $trimmed ~~ /^ \d+ (\.\d+)? ([eE] <[+-]>? \d+)? $ /;
            my $n = $trimmed.Num;
            return $n.isNaN ?? Nil !! $n;
        }
    }
}

# Detects if args specify two-pass encoding (-pass 2)
    sub is-pass2(@args --> Bool) is export {
        my Bool $found-pass = False;
        for @args.kv -> $i, $arg {
            last if $arg eq '--';
            if $arg eq '-pass' && $i + 1 < @args.elems {
                # Check if this is the last -pass in args (for multi-output)
                # If multiple -pass flags exist, use the last one
                $found-pass = @args[$i + 1] eq '2';
            }
        }
        return $found-pass;
    }

# Builds arguments for pass 1 from pass 2 command
# Replaces -pass 2 with -pass 1, and output file with null sink
# Optional $first-output-idx enables position-based matching (safer than name matching)
sub build-pass1-args(@args, :@output-files = [], Int :$first-output-idx = -1 --> List) is export {
    # Returns a 2-element list: (pass1-args, logfilename)
    # Usage: my @args = $result[0].list; my $log = $result[1];
    my @new;
    my $has-y = False;
    my $has-an = False;
    my $has-passlogfile = False;
    my $pass-log = "ffpb2pass-{$*PID}-{(now * 1_000_000).Int}";
    my $null = IS-WIN ?? 'NUL' !! '/dev/null';

my $first-output-replaced = False;
        my Bool $warned-name-based-matching = False;
        my int $i = 0;
        my Bool $pending-f = False;
        my int $last-i-idx = -1;  # Track last -i position for output territory
        while $i < @args.elems {
            my $arg = @args[$i];
            last if $arg eq '--';

        # Transform -pass 2 -> -pass 1
        if $arg eq '-pass' && $i + 1 < @args.elems && @args[$i + 1] eq '2' {
            @new.push: '-pass', '1';
            $i += 2;
            next;
        }

        $has-an = True if $arg eq '-an';
        $has-y = True if $arg eq '-y';
        if $arg eq '-n' {  # Remove -n since output goes to /dev/null; -y added unconditionally below
            $i++;
            next;
        }
        $has-passlogfile = True if $arg eq '-passlogfile' && $i + 1 < @args.elems;
        if $arg eq '-passlogfile' && $i + 1 < @args.elems {
            $i += 2;  # Skip both flag and its value
            next;
        }

        # Track last -i index for output territory detection
        if $arg eq '-i' {
            $last-i-idx = $i;
        }
        # Skip -f only if it's after the last -i (output territory)
        # This preserves input-format -f like "-f lavfi -i testsrc -f mp4 -i second.mp4 output.mp4"
        if $arg eq '-f' && $last-i-idx >= 0 && $i > $last-i-idx {
            if $i + 1 >= @args.elems {
                note "Warning: trailing '-f' with no value, ignoring";
                $i++;
                next;
            }
            # Only skip if next arg is not a flag (i.e., not starting with -)
            my $next-arg = @args[$i + 1];
            if $next-arg !~~ /^^ '-' / {
                $pending-f = True;
                $i++;
                next;
            }
            # Next arg is a flag, don't consume it as -f value
        }
        if $pending-f {
            # This is the value for the -f we skipped above - skip it
            $pending-f = False;
            $i++;
            next;
        }

        # Replace first output file with null sink (by position if available)
        my $is-first-output = $first-output-idx >= 0 
            ?? ($i == $first-output-idx)
            !! (@output-files && $arg eq @output-files[0] && !$first-output-replaced);
        # Warn if trying to replace output without explicit index (name-based fallback unsafe)
        if $is-first-output && $first-output-idx < 0 && !$warned-name-based-matching {
            note "Warning: first-output-idx not provided, using name-based matching (may be unreliable)";
            $warned-name-based-matching = True;
        }
        if $is-first-output {
            @new.push: '-an' unless $has-an;
            @new.push: '-passlogfile', $pass-log unless $has-passlogfile;
            @new.push: '-f', 'null', $null;
            $first-output-replaced = True;
            $i++;
            next;
        } elsif @output-files && $arg (elem) @output-files {
            # Skip subsequent output files (strip them)
            $i++;
            next;
        }

        @new.push: $arg;
        $i++;
    }

# Pass 1 output is always /dev/null - unconditionally add -y unless already present.
    # If user specified -n, it's silently dropped (irrelevant for /dev/null).
    # If user specified -y, it's preserved (no-op but harmless).
    # -an and -passlogfile already added above at first-output.
    # Fallback: if no first-output was found, add them now before the null sink.
    if !$first-output-replaced {
        @new.push: '-an' unless $has-an;
        @new.push: '-passlogfile', $pass-log unless $has-passlogfile;
    }
    @new.unshift: '-y' unless $has-y;
    
    return [@new, $pass-log];  # Return as single array to prevent flattening
}

# Reads config file (~/.ffpbrc), returns array of options.
# Skips empty lines and lines starting with # (comments)
# Uses split(/\r?\n/) to explicitly handle both CRLF and LF line endings
our sub parse-dotfile(IO::Path $path) is export {
    return [] unless $path.e;
    CATCH {
        default {
            note "Warning: Error parsing config file {$path}: {$_.message}. Ignoring.";
            return [];
        }
    }
    my @lines = $path.slurp.split(/\r?\n/);
    my @opts;
    # Shell-style tokenizer: handles quoted strings and space-separated values
    sub tokenize(Str $line --> List) {
        my @tokens;
        my $pos = 0;
        my $len = $line.chars;
        while $pos < $len {
            # Skip whitespace
            $pos++ while $pos < $len && $line.substr($pos, 1) ~~ /\s/;
            last if $pos >= $len;
            # Check for quote
            my $char = $line.substr($pos, 1);
            if $char eq '"' || $char eq "'" {
                my $quote = $char;
                $pos++;
                my $start = $pos;
                $pos++ while $pos < $len && $line.substr($pos, 1) ne $quote;
                my $quoted = $line.substr($start, $pos - $start);
                @tokens.push: $quoted if $quoted.defined;  # Allow empty strings (e.g., --style "")
                $pos++ if $pos < $len;  # skip closing quote
            } else {
                # Unquoted token
                my $start = $pos;
                $pos++ while $pos < $len && $line.substr($pos, 1) !~~ /\s/;
                my $token = $line.substr($start, $pos - $start);
                @tokens.push: $token if $token ne '';
            }
        }
        return @tokens;
    }

    for @lines -> $line {
        my $trimmed = $line.trim;
        next if $trimmed eq '';
        next if $trimmed.starts-with('#');
        # Tokenize with shell-style quoting support
        @opts.append: tokenize($trimmed);
    }
    return @opts;
}

# Parses CLI options from array (not ffmpeg args, but ffpb options like -V, -F, -B)
# Returns: { opts => %options, rest => @remaining-args }
our sub parse-options-from-array(@args) is export {
    my %opts = (
        verbose => False,
        quiet => False,
        show-frames => False,
        show-bitrate => False,
        bar-type => '',
    );
    my %set;  # tracks which options were explicitly set on CLI
    my @rest;
    my int $i = 0;
    while $i < @args.elems {
        my $arg = @args[$i] // '';
        if %flag-opts{$arg}:exists {
            my $key = %flag-opts{$arg};
            %opts{$key} = True;
            %set{$key} = True;
            $i++;
        } elsif $arg ~~ /^ '--' (<-[\s=]>+?) '=' (.*) $/ {
            # Handle --style=value form (equals-separated)
            # Priority: %flag-opts checked first (boolean flags take precedence)
            my $opt-key = ~$0;
            my $opt-val = ~$1;
            # Check both value-opts and flag-opts tables
            my $key = %value-opts{'--' ~ $opt-key} // %flag-opts{'--' ~ $opt-key};
            if $key.defined {
                # Ignore value for boolean flags (always use True)
                %opts{$key} = %flag-opts{'--' ~ $opt-key}:exists 
                    ?? True 
                    !! $opt-val;
                %set{$key} = True;
                $i++;
            } else {
                # Unknown --option=value - pass through to ffmpeg (no warning needed)
                @rest.push: $arg;
                $i++;
            }
        } elsif %value-opts{$arg}:exists {
            my $key = %value-opts{$arg};
            # Disallow overlap - a flag cannot be both boolean and value-taking
            die "Internal error: flag '$arg' defined as both boolean and value-taking"
                if %flag-opts{$arg}:exists;
            my $has-next = $i + 1 < @args.elems;
            my $next = $has-next ?? @args[$i + 1] !! '';
            my $is-neg-num = $next ~~ &RX-NEG-NUM;
            my $is-known-flag = False;
            if $next.starts-with('-') {
                $is-known-flag = True if %flag-opts{$next}:exists;
                $is-known-flag = True if %value-opts{$next}:exists;
            }
            if $has-next && !$is-neg-num && !$is-known-flag {
                # For options with optional values (stderr-lines), only consume
                # the next arg if it actually looks like a valid value
                if $key eq 'stderr-lines' {
                    my $looks-like-value = $next ~~ /^ \d+ $/ || $next eq 'all';
                    if $looks-like-value {
                        %opts{$key} = @args[$i + 1];
                        %set{$key} = True;
                        $i += 2;
                    } else {
                        %opts{$key} = %value-opt-defaults{$key};
                        %set{$key} = True;
                        $i++;
                    }
                } else {
                    %opts{$key} = @args[$i + 1];
                    %set{$key} = True;
                    $i += 2;
                }
            } else {
                %opts{$key} = %value-opt-defaults{$key};
                %set{$key} = True;
                $i++;
            }
        } else {
            @rest.push: $arg;
            $i++;
        }
    }
    my %result = opts => %opts, set => %set, rest => @rest;
    return %result;
}

# Helper: check if a flag at position $idx takes a value
method !arg-takes-value(Str $arg, Int $idx, @args --> Bool) {
    return False unless $idx + 1 < @args.elems;
    my $next = @args[$idx + 1];
    # Match negative numbers that could be values (same logic as parse-arguments)
    if $next ~~ /^ '-' <[0..9]> / {
        # Only treat as value if next arg doesn't take its own value
        unless prefix-takes-value($next) {
            return True;
        }
    }
    return prefix-takes-value($arg);
}

# Parses ffmpeg CLI arguments to extract:
#   - output-file: the output filename
#   - output-duration: -t value (duration limit)
#   - output-end: -to value (end time)
#   - seek-start: -ss value (seek position)
#   - has-y: -y flag (overwrite)
#   - has-filter-complex: -filter_complex present
# Supports '--' separator - all args after it are treated as positional (filenames)
method parse-arguments(@args) {
    my %result;
    my Bool $saw-double-dash = False;

    # Pre-set defaults only (not redundant with // defaults below)
    %result<output-file> = '';
    %result<output-files> = [];
    %result<output-durations> = [];  # initialize before push
    %result<output-ends> = [];  # initialize for consistency

    my int $i = 0;
    my Bool $seen-input = False;

    # Track -shortest flag and input count
    my Bool $has-shortest = False;
    my Int $input-count = 0;

    # Track consumed flag value indices to exclude from output detection
    my %consumed-indices;

    # Stateful output builder - binds -t, -to, -ss to next output file
    my @outputs;
    my $current-output = OutputSpec.new;

    # Track -t/-to before -i (input trimming) to apply when -i is seen
    my Numeric $pre-input-t = 0;
    my Numeric $pre-input-to = 0;

    # When processing flag args (e.g., -i, -t, -ss), we skip both the flag
    # and its associated value by incrementing $i by 2. We always check that
    # a value exists with "$i + 1 < @args.elems" before attempting to read it.
    while $i < @args.elems {
        my $arg = @args[$i];

        if $arg eq '--' {
            $saw-double-dash = True;
            $i++;
            my @post-dash = @args[$i..*];
            # After --, all tokens are positional (files), not flags.
            # -i appearing here is a filename, not a flag - don't count it.
            # NOTE: ffmpeg convention says first is input, last is output,
            # but this is ambiguous when multiple files are present.
            # We conservatively pick the last file as output.
            if @post-dash.elems > 0 {
                %result<output-file> = @post-dash[* - 1];
                %result<output-files> = [@post-dash[* - 1],];
                %result<output-file-idx> = @args.elems - 1;
            }
            last;
        }

        if $arg eq '-i' && $i + 1 < @args.elems {
            $seen-input = True;
            $input-count++;
            # Apply any pre-input -t/-to values
            if $pre-input-t > 0 {
                $current-output.duration = $pre-input-t;
                %result<output-durations>.push: $current-output.duration;
                %result<output-duration> = $current-output.duration;
                $pre-input-t = 0;
            }
            if $pre-input-to > 0 {
                $current-output.to = $pre-input-to;
                %result<output-ends>.push: $current-output.to;
                %result<output-end> = $current-output.to;
                $pre-input-to = 0;
            }
            %consumed-indices{$i + 1} = True;
            $i += 2;
        } elsif $arg eq '-shortest' {
            $has-shortest = True;
            $i++;
        } elsif $arg eq '-filter_complex' && $i + 1 < @args.elems {
            %result<has-filter-complex> = True;
            %consumed-indices{$i + 1} = True;
            $i += 2;
        } elsif $arg eq '-filter_complex_script' && $i + 1 < @args.elems {
            %result<has-filter-complex> = True;
            %consumed-indices{$i + 1} = True;
            $i += 2;
        } elsif $arg eq '-y' {
            %result<has-y> = True;
            $i++;
        } elsif $arg eq '-n' {
            %result<has-n> = True;
            $i++;
        } elsif $arg eq '-t' && $i + 1 < @args.elems {
            my $val = parse-time(@args[$i + 1]) // 0;
            # Store for input if -i not seen yet
            if $seen-input {
                $current-output.duration = $val;
                %result<output-durations>.push: $current-output.duration;
                %result<output-duration> = $current-output.duration;  # backward compat
            } else {
                $pre-input-t = $val;
            }
            %consumed-indices{$i + 1} = True;
            $i += 2;
        } elsif $arg eq '-to' && $i + 1 < @args.elems {
            my $val = parse-time(@args[$i + 1]) // 0;
            # Store for input if -i not seen yet
            if $seen-input {
                $current-output.to = $val;
                %result<output-ends>.push: $current-output.to;
                %result<output-end> = $current-output.to;  # backward compat
            } else {
                $pre-input-to = $val;
            }
            %consumed-indices{$i + 1} = True;
            $i += 2;
        } elsif $arg eq '-ss' && $i + 1 < @args.elems {
            my $seek-val = parse-time(@args[$i + 1]) // 0;
            if !$seen-input {
                %result<input-seek> = $seek-val;
            } else {
                # -ss after -i binds to next output
                $current-output.ss = $seek-val;
                %result<output-seek> = $seek-val;  # backward compat (last one)
            }
            %consumed-indices{$i + 1} = True;
            $i += 2;
        } elsif $arg.starts-with('-') {
            # Use shared helper for consistency with FFmpegFlags
            my Bool $takes-value = prefix-takes-value($arg);

            # Special case for negative numbers that are values, not flags
            if $i + 1 < @args.elems && @args[$i + 1] ~~ /^ '-' <[0..9]> / {
                my $next = @args[$i + 1];
                unless prefix-takes-value($next) {
                    $takes-value = True;
                }
            }

            if $takes-value && $i + 1 < @args.elems {
                %consumed-indices{$i + 1} = True;
                $i += 2;
            } else {
                $i++;
            }
        }
        # Else: any unmatched argument (unknown flags or positional files)
        else {
            $i++;
        }
    }

    # Output file detection: collect ALL positional args after last -i, skipping flag values
    # Fall back to last non-flag arg when no -i or only one input file
    my Int $last-i-idx = -1;
    my Int $output-idx = -1;  # Track index of output file in @args

    unless $saw-double-dash {
        for @args.kv -> $idx, $arg {
            $last-i-idx = $idx if $arg eq '-i';
        }

        if $last-i-idx < 0 {
        # No -i flag: use last non-flag arg as output, skipping flag values
        my int $j = 0;
        while $j < @args.elems {
            my $arg = @args[$j];
            # Skip filter labels like [v], [out], etc. - these are not output files
            if $arg ~~ /^\[[^\]]+\]$/ {
                $j++;
                next;
            }
            # Skip filter expressions (e.g., scale=1280:720)
            if $arg ~~ /^\w+ '='/ {
                $j++;
                next;
            }
            # Skip arguments that were consumed as flag values
            if %consumed-indices{$j} {
                $j++;
                next;
            }
            if looks-like-file($arg) {
                # Push output immediately with current flags, then reset
                @outputs.push: OutputSpec.new(
                    file => $arg,
                    duration => $current-output.duration,
                    to => $current-output.to,
                    ss => $current-output.ss,
                );
                $current-output = OutputSpec.new;
                $output-idx = $j if $output-idx < 0;
            } else {
                if self!arg-takes-value($arg, $j, @args) {
                    %consumed-indices{$j + 1} = True;
                    $j++;
                }
            }
            $j++;
        }
    } else {
        # Has -i: start after the input file path (last-i-idx + 2)
        my int $j = $last-i-idx + 2;
        while $j < @args.elems {
            my $arg = @args[$j];
            # Skip filter labels like [v], [out], etc. - these are not output files
            if $arg ~~ /^\[[^\]]+\]$/ {
                $j++;
                next;
            }
            # Skip filter expressions (e.g., scale=1280:720)
            if $arg ~~ /^\w+ '='/ {
                $j++;
                next;
            }
            # Skip arguments that were consumed as flag values
            if %consumed-indices{$j} {
                $j++;
                next;
            }
            if looks-like-file($arg) {
                # Push output immediately with current flags, then reset
                @outputs.push: OutputSpec.new(
                    file => $arg,
                    duration => $current-output.duration,
                    to => $current-output.to,
                    ss => $current-output.ss,
                );
                $current-output = OutputSpec.new;
                $output-idx = $j if $output-idx < 0;
            } else {
                if self!arg-takes-value($arg, $j, @args) {
                    %consumed-indices{$j + 1} = True;  # Mark flag value as consumed
                    $j++;  # Skip the flag value
                }
            }
            $j++;
        }
        
        # Fallback: if main loop didn't find any output files, try to find the first
        # non-flag argument after the last -i. This handles edge cases the main loop misses.
        # Push immediately to @outputs with current flags, then reset
        if @outputs.elems == 0 && $last-i-idx >= 0 {
            my int $input-after-i = $last-i-idx + 1;
            for @args.kv -> $idx, $arg {
                next if $idx <= $input-after-i;
                next if !looks-like-file($arg) || $arg ~~ /^\[.*\]$/;
                @outputs.push: OutputSpec.new(
                    file => $arg,
                    duration => $current-output.duration,
                    to => $current-output.to,
                    ss => $current-output.ss,
                );
                $current-output = OutputSpec.new;
                $output-idx = $idx if $output-idx < 0;
                last;
            }
        }
    }

    if @outputs.elems > 0 {
        %result<output-file>  = @outputs[* - 1].file;
        %result<output-files> = @outputs.map({ .file }).list;
        %result<outputs> = @outputs;
    }
    }  # end unless $saw-double-dash

    # Add computed values to result
    %result<saw-double-dash> = $saw-double-dash;
    %result<has-shortest> = $has-shortest;
    %result<input-count> = $input-count;
    %result<suppress-stderr-duration> = self.uses-error-loglevel(@args);
    %result<output-file-backward> = %result<output-file>;
    %result<output-file-idx> //= $output-idx;  # Index of output file in @args
    
    # Use // defaults for remaining keys (avoid redundant pre-init)
    %result<output-duration> //= 0;
    %result<input-seek> //= 0;
    %result<output-seek> //= 0;
    %result<seek-start> //= 0;  # Legacy: keep for backward compat but don't sum
    %result<output-end> //= 0;
    %result<output-durations> //= [];
    %result<output-ends> //= [];
    %result<has-y> //= False;
    %result<has-n> //= False;
    %result<has-filter-complex> //= False;

    return %result;
}

# Checks if args include -loglevel error|quiet|fatal (needed for duration detection)
    # Also handles -v shorthand
    method uses-error-loglevel(@args) {
        for @args.kv -> $i, $arg {
            last if $arg eq '--';
            if ($arg eq '-loglevel' || $arg eq '-v')
                && $i + 1 < @args.elems
                && @args[$i + 1] eq any(<error quiet fatal>) {
                return True;
            }
        }
        return False;
    }

# Returns array of InputGroup objects with per-input seeks extracted.
    # Each InputGroup has .file (the input path) and .seek (-ss value before that -i)
    # Output-level -ss (after last -i) is NOT included - caller must handle separately.
    method get-input-groups-with-seeks(@args) {
        my @groups;
        my Numeric $pending-seek = 0;
        my int $i = 0;
        while $i < @args.elems {
            my $arg = @args[$i];
            last if $arg eq '--';
        if $arg eq '-ss' && $i + 1 < @args.elems {
            $pending-seek = parse-time(@args[$i + 1]) // 0;
            $i += 2;  # Skip past -ss and its value
        } elsif $arg eq '-i' && $i + 1 < @args.elems {
            my $file = @args[$i + 1];
            @groups.push: InputGroup.new(:$file, seek => $pending-seek) if $file && $file ne '';
            $pending-seek = 0;
            $i += 2;  # Skip past -i and its value
        } else {
            $i++;
        }
    }
    @groups;
}

# Parses -map arguments to extract input indices that contribute to output.
    # Returns MapSelection with include set (excludes already applied).
    # Returns:
    #   - MapSelection -> include set with excludes applied
    #   - Nil -> -map [label] form (filter_complex output), probe no inputs (can't determine)
    method parse-map-inputs(@args, Int $input-count = 0) {
        my @include;
        my @exclude;
        my int $i = 0;
        my Bool $has-filter-label = False;
        while $i < @args.elems {
            last if @args[$i] eq '--';
            if @args[$i] eq '-map' && $i + 1 < @args.elems {
            my $target = @args[$i + 1];
            # -map 0:v:0 -> input index 0 (stream selector, take first digit)
            # -map 0:v -> input index 0
            # -map 1:a -> input index 1
            # -map 0 -> input index 0 (all streams from input 0)
            # -map "[v]" -> filter_complex output, skip (unknowable)
            # -map -0:a -> exclude audio from input 0
            if $target ~~ /^\[.+\]$/ {
                $has-filter-label = True;
            } elsif $target ~~ /^ '-' (\d+) [ ':' .* ]? $/ {
                @exclude.push: $0.Int;
            } elsif $target ~~ /^ (\d+) [ ':' .* ]? $/ {
                @include.push: $0.Int;
            }
            $i += 2;
        } else {
            $i++;
        }
    }
    return MapSelection.new(:unknown(True)) if $has-filter-label;
    
# Apply exclusions: start with include (or all inputs if empty), then subtract exclude
    # If no -map at all, returning empty set means "use default" which is valid
    # For lone negative -map (e.g. -map -0:a), start with all inputs then subtract
    my $start-set = @include.elems > 0 
        ?? @include.Set 
        !! ($input-count > 0)
            ?? (0..^$input-count).Set
            !! Set.new;  # Empty = use ffmpeg default mapping
    my $final-set = $start-set (-) @exclude.Set;
    
    return MapSelection.new(
        include => $final-set,
        exclude => @exclude.Set,  # keep for debugging/reporting
    );
}

# Returns config file paths in order of precedence (~/.ffpbrc, etc.)
# Note: returns all potential paths, not just existing ones - caller filters via .e
our sub get-config-paths() is export {
    my @paths;
    if IS-WIN {
        my $userprofile = $*ENV<USERPROFILE> // $*HOME;
        my $appdata = $*ENV<APPDATA> // $*HOME;
        @paths.push: "$userprofile/.ffpbrc".IO;
        @paths.push: "$userprofile/.config/ffpbrc".IO;
        @paths.push: "$userprofile/.config/ffpb/config".IO;
        @paths.push: "$appdata/ffpb/config".IO;
        @paths.push: "$appdata/ffpbrc".IO;
    } else {
        my $home = $*HOME // '';
        if $home ne '' {
            @paths.push: "$home/.ffpbrc".IO;
            @paths.push: "$home/.config/ffpbrc".IO;
            @paths.push: "$home/.config/ffpb/config".IO;
        }
        @paths.push: "/etc/ffpbrc".IO;
    }
    return @paths;
}

# Parses CLI options and optional dotfile, merges them with CLI taking precedence.
# Returns: ParsedOptions object
our sub get-effective-options(@cli, Str :$dotfile) is export {
    my IO::Path $path = do {
        if $dotfile.defined {
            $dotfile.IO;
        } else {
            get-config-paths().first(*.e);
        }
    };
    my @dot = $path.defined && $path.e ?? parse-dotfile($path) !! [];
    my %dot-parsed = @dot.elems > 0 ?? parse-options-from-array(@dot)<opts> !! {};
    my %parsed := parse-options-from-array(@cli);
    my %opts = %parsed<opts> // {};
    my %set = %parsed<set> // {};
    my @rest = (%parsed<rest> // []).flat;
    
    # stderr-lines handling: 
    # - parse-options-from-array defaults to '20' when -E/--stderr has no value (via %value-opt-defaults)
    # - empty string '' means "don't show stderr", '20' or 'all' means "show N lines"
    my $stderr-lines = %opts<stderr-lines> // %dot-parsed<stderr-lines> // '';
    
    my $dur-raw = %opts<duration> // %dot-parsed<duration> // '0';
    my $trimmed = $dur-raw.trim;
    my $parsed = parse-time($trimmed);
    my $dur = $parsed // 0;
    my $parsed-ok = $parsed.defined;
    # Allow any numeric form: 0, 00, 0.0, 00.0, etc.
    if !$parsed-ok && $trimmed ne '' && $trimmed !~~ /^ \d+ (\.\d+)? $ / {
        note "Warning: invalid --duration value '$dur-raw', ignoring";
    }
    
    # Dotfile option fallback:
    # - parse-options-from-array treats boolean flags (verbose, quiet, show-frames, show-bitrate)
    #   as presence-only; any value in the dotfile sets the flag to True.
    # - If dotfile contains an invalid boolean value (e.g., "yes", "1"), it's coerced to True.
    # - This is safe for dotfile use cases since the config is user-controlled and boolean flags
    #   don't have semantic meaning beyond "enabled" or "disabled".
    return ParsedOptions.new(
        :verbose(%set<verbose> ?? True !! (%dot-parsed<verbose> // False)),
        :quiet(%set<quiet> ?? True !! (%dot-parsed<quiet> // False)),
        :show-frames(%set<show-frames> ?? True !! (%dot-parsed<show-frames> // False)),
        :show-bitrate(%set<show-bitrate> ?? True !! (%dot-parsed<show-bitrate> // False)),
        :no-color(%set<no-color> ?? True !! (%dot-parsed<no-color> // False)),
        :bar-type(%opts<bar-type> // %dot-parsed<bar-type> // ''),
        :duration($dur),
        :ffmpeg(%opts<ffmpeg> // %dot-parsed<ffmpeg> // ''),
        :ffprobe(%opts<ffprobe> // %dot-parsed<ffprobe> // ''),
        :stderr-lines($stderr-lines),
        :rest(@rest),
        :set(%set),
    );
}

=begin pod

=head1 NAME

FFmpegProgressBar::Parser - Argument and output parsing

=head1 DESCRIPTION

Parses ffmpeg progress output, CLI arguments, config files, and duration
strings. Provides methods for extracting duration from -t/-to/-ss flags
and detecting video metadata via ffprobe.

=head1 METHODS

=item method parse-progress-line(Str $line) - Parse progress key=value pairs

=item method parse-duration(Str $line) - Parse duration from ffmpeg stderr

=item method parse-time(Str:D $s) - Parse time/duration strings (HH:MM:SS, MM:SS, etc.)

=item sub parse-dotfile(IO::Path $path) - Parse config file with shell-style tokenization (supports quoted strings and space-separated values)

=item sub parse-options-from-array(@args) - Parse CLI options

=item method parse-arguments(@args) - Parse ffmpeg CLI arguments

=item method uses-error-loglevel(@args) - Check for -loglevel error|quiet

=item method get-input-groups-with-seeks(@args) - Group inputs with their preceding -ss seeks

=item method parse-map-inputs(@args) - Parse -map arguments to extract contributing input indices

=item sub get-config-paths() - Return config file paths in priority order

=item sub get-effective-options(@cli, Str :$dotfile) - Merge CLI and dotfile options

=item sub is-pass2(@args --> Bool) - Detect if arguments specify two-pass encoding (-pass 2)

=item sub build-pass1-args(@args, Int :$first-output-idx = -1 --> List) - Build arguments for pass 1 from pass 2 command, returns (args, logfilename)

=end pod
