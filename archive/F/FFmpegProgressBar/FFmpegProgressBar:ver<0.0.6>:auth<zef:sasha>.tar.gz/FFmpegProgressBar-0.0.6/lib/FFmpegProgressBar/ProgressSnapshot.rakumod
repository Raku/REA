use v6.d;

unit class FFmpegProgressBar::ProgressSnapshot:ver<0.0.6>:auth<zef:sasha>;

# ============================================================================
# ProgressSnapshot - Immutable snapshot of current encoding progress
# ============================================================================
# Designed for thread-safe reading from multiple contexts.
# Freezes state at a single moment, so callers don't see torn reads.

our enum EncodeStatus is export <EncodeRunning EncodeCompleted EncodeAborted EncodeFailed EncodeIncomplete EncodeSkipped>;

class ProgressSnapshot is export {
    has Int $.frame-count = 0;
    has Int $.total-frames = 0;
    has Numeric $.percent;       # Time-based (always matches progress bar)
    has Numeric $.elapsed;
    has Numeric $.eta;
    has Str $.bitrate;
    has Numeric $.fps = 0;
    has Numeric $.speed;
    has EncodeStatus $.status;
    has Bool $.is-stalled;
    has Str $.last-error;
    has DateTime $.timestamp = DateTime.now;  # Default to creation time

    method remaining-seconds() {
        with $.eta {
            return $_ if $_ > 0;  # Only return eta if > 0
        }
        return Nil unless $.total-frames > 0 && $.fps > 0;
        max(0, $.total-frames - $.frame-count) / $.fps;
    }

    method completion-time() {
        my $remaining = $.remaining-seconds;
        return Nil unless $remaining.defined;  # Only Nil means unavailable, 0 means done
        return $.timestamp.later(seconds => $remaining.round);
    }

    method is-complete(--> Bool) {
	$.status == EncodeCompleted
    }

    method is-skipped(--> Bool) {
	$.status == EncodeSkipped
    }

    method is-failed(--> Bool) {
	$.status ∈ (EncodeAborted, EncodeFailed, EncodeIncomplete)
    }

    method summary(--> Str) {
	return "skipped (output already exists)" if $.status == EncodeSkipped;
	
	my $frame-str = $.total-frames > 0 
				       ?? "{$.frame-count}/{$.total-frames}" 
				       !! "{$.frame-count}";
	my $eta = $.remaining-seconds;
	my $eta-str = ($eta.defined && $eta > 0) ?? " ETA: {$eta.fmt('%.0f')}s" !! "";
	my $bitrate-str = $.bitrate ?? " @ {$.bitrate}" !! "";
	my $fps-str = "{($.fps // 0).fmt('%.1f')}fps";
	my $percent = ($.percent // 0).fmt('%.1f');
	
	return "{$percent}% [{$frame-str} {$fps-str}]{$bitrate-str}{$eta-str}";
    }
}

=begin pod

=head1 NAME

FFmpegProgressBar::ProgressSnapshot - Immutable progress state at a point in time

=head1 DESCRIPTION

A value object representing the complete state of an ffmpeg encoding at a single moment.
Safe to pass between threads; immutable and thread-safe by design.

Obtained via L<FFmpegProgressBar#get-progress> or L<FFmpegProgressBar#progress-supply>.

=head1 ATTRIBUTES

=item $.frame-count - Current frame number (Int)

=item $.total-frames - Total frames (Int, 0 if unknown)

=item $.percent - Progress 0-100% (Numeric)

=item $.elapsed - Seconds elapsed since encoding started (Numeric)

=item $.eta - Estimated seconds remaining (Numeric or Nil if unavailable)

=item $.bitrate - Current bitrate string (Str, e.g. "1.5Mbps")

=item $.fps - Encoding speed in frames/second (Numeric)

=item $.speed - Playback speed multiplier (Numeric, e.g. 1.5x)

=item $.status - Encoding status (EncodeStatus enum: EncodeRunning, EncodeCompleted, EncodeAborted, EncodeFailed, EncodeIncomplete, EncodeSkipped)

=item $.is-stalled - True if no progress for stall-threshold seconds (Bool)

=item $.last-error - Last error message from ffmpeg stderr (Str)

=item $.timestamp - DateTime when snapshot was created (defaults to DateTime.now)

=head1 METHODS

=item method remaining-seconds() - Estimated remaining seconds (Numeric or Nil if unavailable)

=item method completion-time() - Estimated DateTime when encoding will finish

=item method is-complete() - Returns True if encoding finished successfully

=item method is-failed() - Returns True if encoding failed or was aborted

=item method is-skipped() - Returns True if output was skipped because it already exists (-n flag)

=item method summary() - Human-readable one-line progress summary

=end pod
