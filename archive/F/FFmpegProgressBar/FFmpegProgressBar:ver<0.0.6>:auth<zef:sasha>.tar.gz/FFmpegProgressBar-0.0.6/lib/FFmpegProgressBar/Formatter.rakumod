use v6.d;
use Terminal::WCWidth;

unit class FFmpegProgressBar::Formatter:ver<0.0.6>:auth<zef:sasha>;

has Int $.max-filename-length = 100;
has Bool $.use-unicode = True;

my constant %SCALE = k => 1_000, m => 1_000_000, g => 1_000_000_000;

# Safe width calculation: returns actual width if available, fallback otherwise
sub safe-width(Str $s --> Int) {
    my $w = wcswidth($s);
    return $w if $w >= 0;
    return $s.codes;  # fallback: approximate width using codepoints (may overcount for graphemes/emoji)
}

# ============================================================================
# Formatter - String Formatting Utilities
# ============================================================================
# Formats:
#   - Bitrate strings (kbits/s -> Mbps)
#   "1500kbits/s" -> " (1.5Mbps)"
#   "2.5Mbits/s"  -> " (2.5Mbps)"
# Returns empty string for invalid/zero values
method human-bitrate(Str() $bitrate --> Str) {
    my $bitrate-str = $bitrate.Str.trim;
    return '' if $bitrate-str eq '' || $bitrate-str eq 'N/A' || $bitrate-str eq '0.0kbits/s';
    
    my $bitrate-lc = $bitrate-str.lc;
    # Primary: strict match with /s (e.g., "1234kbits/s", "1.5Mb/s", "500kb/s")
    # Use \d+\.?\d* instead of (\d+(\.\d+)?) to avoid nested group index shifting
    if $bitrate-lc ~~ /^(\d+\.?\d*)\s*(<[kmg]>)(b?(it|its)?)?\/s$/ {
        my $val = $0.Num;
        my $unit = $1 // '';
        my $mbps = $val * (%SCALE{$unit} // 1) / 1_000_000;
        return '' if $mbps <= 0;
        return sprintf(" (%.1fMbps)", $mbps);
    }
    # Fallback: short format without /s (e.g., "1.2M", "500k")
    if $bitrate-lc ~~ /^(\d+\.?\d*)\s*(<[kmg]>)?$/ {
        my $val = $0.Num;
        my $unit = $1 // '';
        my $mbps = $val * (%SCALE{$unit} // 1) / 1_000_000;
        return '' if $mbps <= 0;
        return sprintf(" (%.1fMbps)", $mbps);
    }
    return '';
}

# Calculates average bitrate from total bytes and duration.
# Returns format: " (1.5Mbps)"
method average-bitrate(Numeric $bytes, Numeric $duration --> Str) {
    return '' if $bytes <= 10_000 || $duration < 0.5;
    my Numeric $bits = $bytes * 8;
    my Numeric $mbps = $bits / ($duration * 1_000_000);
    # Adaptive precision: use %.2f for small values, %.1f for larger
    my $format = $mbps < 1 ?? " (%.2fMbps)" !! " (%.1fMbps)";
    return sprintf($format, $mbps);
}

# Formats frame count and optional FPS.
# Examples: "[100/900 (25.0fps)]", "[100/900]", "[100 (25.0fps)]", "[100]"
method frame-info(Bool $show, Int $cur, Int $total = 0, Numeric $fps = 0, Bool $saw-fps = False --> Str) {
    return '' unless $show && $cur > 0;
    if $total > 0 && $saw-fps && $fps > 0 {
        return sprintf(" [%d/%d (%.1ffps)]", $cur, $total, $fps);
    } elsif $total > 0 {
        return sprintf(" [%d/%d]", $cur, $total);
    } elsif $saw-fps && $fps > 0 {
        return sprintf(" [%d (%.1ffps)]", $cur, $fps);
    }
    return sprintf(" [%d]", $cur);
}

# Formats seconds as HH:MM:SS (always 2 digits each)
# Truncates to integer seconds - intentional for display format
    method elapsed(Real $secs --> Str) {
        my Real $n = $secs;
        return '00:00:00' if !$n.defined || $n.Num.isNaN || $n == Inf || $n == -Inf;
    return '00:00:00' if $n < 0;
    my Int $s = $n.Int;
    sprintf("%02d:%02d:%02d",
        ($s div 3600),
        (($s % 3600) div 60),
        ($s % 60));
}

# Truncates long filenames by keeping start and end, inserting …
# Example: "very_long_video_file_name.mp4" -> "very_lo…_name.mp4"
# Uses wcswidth() for proper CJK character width handling
# Handles compound extensions and multi-part archives:
#   backup.tar.gz       → ("tar.gz",       "backup")
#   backup.tar.gz.asc  → ("tar.gz.asc",   "backup")
#   archive.7z.001     → ("7z.001",       "archive")
#   movie.part01.rar   → ("part01.rar",   "movie")
#   backup.zip.z01     → ("zip.z01",      "backup")
#   file.deb           → ("deb",          "file")
#   .hiddenfile        → ("",             ".hiddenfile")
#   file.001          → ("001",          "file")   (no archive base)
sub extract-extension(Str $name --> List) is export {
    # Handle dotfiles: return whole name as basename if only one dot (e.g., .hidden)
    return ('', $name) if $name.starts-with('.') && !$name.substr(1).contains('.');
    
    # Find the last path separator to get basename for extension extraction
    my $sep-pos = $name.rindex('/') // $name.rindex('\\');
    my $basename = $sep-pos.defined 
        ?? $name.substr($sep-pos + 1) 
        !! $name;
    
    # Handle dotfiles with compound extensions (e.g., .tar.gz)
    # Use a separate variable for processing to preserve original $basename with leading dot
    my $stripped = $basename.starts-with('.') ?? $basename.substr(1) !! $basename;
    my @parts = $stripped.split('.');
    
    # Handle "file." (trailing dot)
    if @parts[*-1] eq '' {
        my $b = @parts[0..*-2].join('.');
        $b = '.' ~ $b if $basename.starts-with('.');
        return ('', $b);
    }
    
    return ('', $basename) if @parts.elems <= 1;
    
    my constant @ARCHIVE-EXTS = <tar 7z gz bz2 xz lz lzma zst br zip rar ace cab iso img>;
    my constant @SUFFIX-EXTS  = <md5 sha1 sha256 sha512 asc sfv cksum sum diz nfo>;
    
    my sub is-numbered(Str $s --> Bool) {
        my $l = $s.lc;
        so($l ~~ rx/^\d+$/) || so($l ~~ rx/^<[rz]>\d+$/) || so($l ~~ rx/^part\.?\d+$/)
    }
    
    # Collect trailing compound parts
    my Int constant $MAX-PARTS = 5;
    my @ext-parts;
    for @parts.reverse -> $p {
        last if @ext-parts.elems >= $MAX-PARTS;
        
        my $p-lc = $p.lc;
        last unless $p-lc eq any(|@ARCHIVE-EXTS, |@SUFFIX-EXTS) 
                 || is-numbered($p-lc);
        
        @ext-parts.unshift($p);
    }
    
    # Accept as compound extension if 2+ parts collected
    if @ext-parts.elems >= 2 {
        my $count = @ext-parts.elems;
        
        # Guard: if count >= parts, treat whole thing as basename with no extension
        if $count >= @parts.elems {
            return ('', $basename);
        }
        
        my $ext   = @parts[*-$count .. *-1].join('.');
        my $base  = @parts[0 .. *-$count-1].join('.');
        $base = '.' ~ $base if $basename.starts-with('.');
        
        return ($ext, $base);
    }
    
    # Normal single extension
    my $ext  = @parts[*-1];
    my $base = @parts[0 .. *-2].join('.');
    $base = '.' ~ $base if $basename.starts-with('.') && !$base.starts-with('.');
    
    return ($ext, $base);
}

method truncate-filename(Str $name, Int $max-len? --> Str) {
    my Int $max = $max-len // $!max-filename-length;
    return '' if $max < 1;
    return '' if $name eq '';
    
my Int $display-width = safe-width($name);
    return $name if $display-width <= $max;
    
    # Find directory prefix position first
    my $sep-pos = $name.rindex('/') // $name.rindex('\\');
    my $prefix = $sep-pos.defined && $sep-pos >= 0 
        ?? $name.substr(0, $sep-pos + 1) 
        !! '';
    my Int $prefix-width = safe-width($prefix);
    # Get basename for extension extraction and base computation
    my $basename = $sep-pos.defined && $sep-pos >= 0
        ?? $name.substr($sep-pos + 1)
        !! $name;
    
    my ($ext, $base) = extract-extension($basename);  # Use basename, not full path
    my $ext-full = $ext ne '' ?? '.' ~ $ext !! '';
    my $ext-width = safe-width($ext-full);
    
    my $ellipsis = $!use-unicode ?? '…' !! '...';
    my Int $ellipsis-width = safe-width($ellipsis);
    
    my Int $available = $max - $ext-width - $ellipsis-width - $prefix-width;
    if $available <= 0 {
        my $minimal = $ellipsis ~ $ext-full;
        return $minimal if safe-width($minimal) <= $max;
        return safe-width($ellipsis) <= $max ?? $ellipsis !! '';
    }
    
    my $base-width = safe-width($base);
    return $prefix ~ $base ~ $ext-full if $base-width <= $available;
    
    my Int $front-budget = (($available * 6) / 10).ceiling;
    my Int $back-budget = $available - $front-budget;
    
    # Greedy loop for front part (simpler than binary search, same result)
    my Str $front = '';
    my Int $w = 0;
    for $base.comb -> $g {
        my $gw = safe-width($g);
        last if $w + $gw > $front-budget;
        $front ~= $g;
        $w += $gw;
    }
    
    # Greedy loop for back part
    my Str $back = '';
    $w = 0;
    for $base.comb.reverse -> $g {
        my $gw = safe-width($g);
        last if $w + $gw > $back-budget;
        $back = $g ~ $back;
        $w += $gw;
    }
    
    my $truncated = $prefix ~ $front ~ $ellipsis ~ $back;
    $truncated ~= $ext-full if $ext;
    
    if safe-width($truncated) > $max {
        # Fallback: show ellipsis + extension, then truncate base width-aware
        my $fallback = $ellipsis ~ $ext-full;
        return safe-width($fallback) <= $max 
            ?? $fallback 
            !! self!truncate-with-ellipsis($ellipsis, $name, $max);
    }
    return $truncated;
}

# Helper for width-aware fallback truncation
method !truncate-with-ellipsis(Str $ellipsis, Str $name, Int $max --> Str) {
    my Int $ellipsis-width = safe-width($ellipsis);
    my Int $remaining = $max - $ellipsis-width;
    return $ellipsis if $remaining <= 0;
    
    my Str $result = '';
    my Int $w = 0;
    for $name.comb -> $g {
        my $gw = safe-width($g);
        last if $w + $gw > $remaining;
        $result ~= $g;
        $w += $gw;
    }
    return $ellipsis ~ $result;
}

=begin pod

=head1 NAME

FFmpegProgressBar::Formatter - String formatting utilities

=head1 DESCRIPTION

Provides string formatting methods for progress bar output, including
bitrate formatting, frame info, elapsed time, and filename truncation.

=head1 ATTRIBUTES

=item $.max-filename-length - Maximum filename length before truncation

=item $.use-unicode - Whether to use Unicode characters

=head1 METHODS

=item method human-bitrate(Str $bitrate) - Format bitrate string (e.g., "1500kbits/s" -> " (1.5Mbps)")

=item method average-bitrate(Numeric $bytes, Numeric $duration) - Calculate average bitrate

=item method frame-info(Bool $show, Int $cur, Int $total = 0, Numeric $fps = 0, Bool $saw-fps = False) - Format frame info

=item method elapsed(Numeric $secs) - Format seconds as HH:MM:SS

=item method truncate-filename(Str $name, Int $max?) - Truncate long filenames

=end pod
