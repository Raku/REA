use v6.d;

unit class FFmpegProgressBar::Probe:ver<0.0.6>:auth<zef:sasha>;

my constant IS-WIN = $*DISTRO.is-win;

# ============================================================================
# Probe - Binary Verification & ffprobe Interaction
# ============================================================================
# Owns all interaction with ffprobe binary:
#   - Checking if binaries exist in PATH
#   - Running ffprobe to get duration/frame count

has Str $.ffprobe = 'ffprobe';

# Cached at module load time — use refresh-path() to update after environment changes.
my @cached-path = $*SPEC.path;

# Refresh the cached PATH (call after environment changes)
sub refresh-path() is export {
    @cached-path = $*SPEC.path;
}

# Checks if a binary exists in PATH and is executable
method check-binary-exists(Str $name --> Bool) {
    return False unless $name.defined && $name ne '';
    # Check for absolute or relative paths using $*SPEC
    if $name.IO.is-absolute || $name.contains($*SPEC.dir-sep) {
        my $io = $name.IO;
        return False unless $io.e;
        # On Windows, check for executable extension or try adding common extensions
        if IS-WIN {
            my $detected-ext = $io.extension.lc;
            return True if $detected-ext eq any('exe', 'bat', 'cmd', 'com', 'ps1');
            # No extension - try common executables
            for <.exe .bat .cmd .com .ps1> -> $ext {
                my $with-ext = $io.path ~ $ext;
                return True if $with-ext.IO.e;
            }
        }
        # On Unix, use .x check
        if !IS-WIN {
            my $is-executable = try $io.x;
            return $is-executable // False;
        }
        return False;
    }
    my @extensions = IS-WIN
        ?? ('.exe', '.bat', '.cmd', '.com', '.ps1')
        !! ('');
    for @cached-path -> $dir {
        for @extensions -> $ext {
            my $path = $*SPEC.catfile($dir, "$name$ext").IO;
            next unless $path.e;
            my $is-executable = IS-WIN 
                ?? True 
                !! (try $path.x) // False;
            return True if $is-executable;
        }
    }
    return False;
}

# Runs ffprobe with given args, returns (output, error) tuple
method run-ffprobe(*@args) {
    my $proc;
    try {
        $proc = run($!ffprobe, |@args, :out, :err);
        CATCH { default { return (Nil, "Failed to run ffprobe: {$_.message}") } }
    }
    return (Nil, "Failed to run ffprobe") unless $proc;
    # Must drain stdout and stderr concurrently before checking exitcode.
    # If either pipe fills its OS buffer, ffprobe blocks on write and deadlock occurs.
    my $p1 = start { try $proc.out.slurp(:close) };
    my $p2 = start { try $proc.err.slurp(:close) };
    await Promise.allof($p1, $p2);
    # Check promise status before accessing .result to avoid broken promise exceptions
    my $out = $p1.status == Kept ?? (try $p1.result) !! '';
    my $err = $p2.status == Kept ?? (try $p2.result // '') !! '';
    # Check exitcode first (ground truth), then validate output
    my $err-msg = $err.trim.chars ?? $err.trim !! "ffprobe exited with code {$proc.exitcode}";
    return (Nil, "ffprobe failed: $err-msg") if $proc.exitcode != 0;
    return (Nil, "ffprobe produced no output") unless $out.defined && $out.chars;
    return ($out.trim, Nil);
}

# Queries ffprobe for video duration in seconds.
# Returns Failure on invalid file or ffprobe failure.
method get-duration(Str $file --> Numeric:D) {
    fail "No file specified" unless $file.defined && $file ne '';
    my ($output, $err) = self.run-ffprobe('-v', 'error', '-show_entries', 'format=duration',
                   '-of', 'default=noprint_wrappers=1:nokey=1', $file);
    fail "Failed to get duration for $file: $err" if $err;
    fail "Failed to get duration for $file" unless $output && $output ne '';
    my $n = $output.Num;
    fail "Invalid duration output for $file: '$output'" if $n.isNaN;
    return $n;
}

# Queries ffprobe for video frame count.
# Returns Failure on invalid file or ffprobe failure.
method get-frame-count(Str $file --> Int:D) {
    fail "No file specified" unless $file.defined && $file ne '';
    my ($output, $err) = self.run-ffprobe('-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=nb_frames',
        '-of', 'default=noprint_wrappers=1:nokey=1', $file);
    fail "Failed to get frame count for $file: $err" if $err;
    my $first-line = ($output.lines.first // '').trim;
    fail "Invalid frame count output for $file: '$first-line'" unless $first-line ~~ /^\d+$/;
    return $first-line.Int;
}

# Verifies both ffmpeg and ffprobe binaries exist in PATH.
# Takes optional ffmpeg binary name/path (defaults to 'ffmpeg').
method check-ffmpeg-exists(Str :$ffmpeg = 'ffmpeg' --> Bool) {
    return self.check-binary-exists($ffmpeg) && self.check-binary-exists($!ffprobe);
}

=begin pod

=head1 NAME

FFmpegProgressBar::Probe - Binary verification and ffprobe interaction

=head1 DESCRIPTION

Handles interaction with ffprobe binary for duration and frame count
detection. Also verifies ffmpeg and ffprobe binaries exist in PATH.

=head1 ATTRIBUTES

=item $!ffprobe - Path to ffprobe binary (default: "ffprobe")

=head1 METHODS

=item method check-binary-exists(Str $name) - Check if binary exists in PATH

=item method run-ffprobe(*@args) - Run ffprobe with args, returns (output, error)

=item method get-duration(Str $file) - Get video duration in seconds via ffprobe.
Returns Failure on failure.

=item method get-frame-count(Str $file) - Get video frame count via ffprobe using
stream metadata (C<nb_frames>). Returns Failure on failure.

=item method check-ffmpeg-exists(Str :$ffmpeg) - Verify both ffmpeg and ffprobe exist

=end pod
