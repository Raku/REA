[![Actions Status](https://github.com/librasteve/FStrings/actions/workflows/test.yml/badge.svg)](https://github.com/librasteve/FStrings/actions)

# FStrings

## Synopsis

```raku
use FStrings;

# left-align, right-align, center with width
say "hello" -f 10;     # "hello     "
say "hello" +f 10;     # "     hello"
say "hello" ^f 10;     # "  hello   "

# float formatting: Rat spec encodes width.precision
say 3.14159 +f 8.2;    # "    3.14"
say 3.14159 -f 8.2;    # "3.14    "

# join formatted columns
say f('Name' -f 20, 'Hours' +f 6, 'Rate' +f 8);
# "Name                 Hours     Rate"

# full format spec via fmt()
say fmt(1234567.89, '>12,.2f');   # " 1,234,567.89"
say fmt(0.1875,     '>8.1%');     # "    18.8%"
say fmt(42,         '>08d');      # "00000042"
```

## Description

FStrings brings Python f-string-style formatting operators to Raku.

The three infix operators `-f` (left-align), `+f` (right-align), and `^f` (center) let you format
values into fixed-width columns with an ergonomic DSL. When the spec is a `Rat` literal (e.g. `8.2`),
it is interpreted as `width.precision` for float formatting.

The `fmt($value, $spec)` function covers the full Python format-spec mini-language:

```
[align][zero][width][grouping][.precision][type]
```

Supported types: `s d f e E g G %`  
Supported flags: `0` (zero-pad), `,` or `_` (digit grouping)

## Installation

```
zef install FStrings
```

## Author

librasteve <librasteve@furnival.net>

## Copyright and License

Copyright 2026 Stephen Roe.

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.
