unit module FStrings;

# Full Python format spec: [[fill]align][sign][z][#][0][width][grouping][.precision][type]
# Supported via fmt(): <N >N ^N  with types s d f e E g G %  and flags 0 , _
sub fmt($value, Str $spec = '' --> Str) is export {
    my $m = $spec ~~ /^
        $<align>=(<[<>^]>)
        $<zero>=(0?)
        $<width>=(\d+)
        [ $<group>=(<[,_]>) ]?
        [ '.' $<prec>=(\d+) ]?
        $<type>=(<[sdfFeEgG%]>?)
    $/;
    return ~$value unless $m;

    my $align = ~$m<align>;
    my $width = +$m<width>;
    my $prec  = $m<prec>  ?? +$m<prec>  !! Nil;
    my $type  = ~$m<type>  || 's';
    my $zero  = ~$m<zero> eq '0';
    my $group = $m<group> ?? ~$m<group> !! Nil;

    # percentage: multiply by 100, format as f, append %
    if $type eq '%' {
        my $v    = $value * 100;
        my $p    = $prec // 2;
        my $body = sprintf('%' ~ ($zero ?? '0' !! '') ~ $width ~ '.' ~ $p ~ 'f', $v) ~ '%';
        return $body;
    }

    # grouping (comma/underscore) — format as f or d then insert separator
    if $group {
        my $sep  = $group eq ',' ?? ',' !! '_';
        my $p    = $prec // 0;
        my $raw  = $type eq 'd'
            ?? sprintf('%d', $value.Int)
            !! sprintf('%.' ~ $p ~ 'f', $value);
        my ($int-part, $dec-part) = $raw.split('.');
        my $sign = $int-part.starts-with('-') ?? do { $int-part .= substr(1); '-' } !! '';
        $int-part = $int-part.flip.comb(3).join($sep).flip;
        $raw = $sign ~ $int-part ~ ($dec-part ?? '.' ~ $dec-part !! '');
        return $align eq '<' ?? sprintf('%-*s', $width, $raw)
            !! $align eq '^' ?? center($raw, $width)
            !!                   sprintf('%*s',  $width, $raw);
    }

    my $flags = $zero ?? '0' !! '';
    my $fmt-str = do given $align {
        when '<' { '%-' ~ $flags ~ $width ~ ($prec.defined ?? '.' ~ $prec !! '') ~ $type }
        when '^' { return center(sprintf('%' ~ $flags ~ ($prec.defined ?? '.' ~ $prec !! '') ~ $type, $value), $width) }
        default  { '%'  ~ $flags ~ $width ~ ($prec.defined ?? '.' ~ $prec !! '') ~ $type }
    };
    sprintf($fmt-str, $value)
}

sub center($val, Int $width --> Str) is export {
    my $s   = ~$val;
    my $pad = $width - $s.chars;
    $pad = 0 if $pad < 0;
    ' ' x ($pad div 2) ~ $s ~ ' ' x ($pad - $pad div 2)
}

# -f : left-align  (Int → string, Rat → float)
sub infix:«-f»($val, $spec --> Str) is export {
    $spec ~~ Rat
        ?? do { my ($w, $p) = $spec.Str.split('.').map(*.Int); fmt($val, '<' ~ $w ~ '.' ~ $p ~ 'f') }
        !! fmt($val, '<' ~ $spec)
}

# +f : right-align (Int → string, Rat → float)
sub infix:«+f»($val, $spec --> Str) is export {
    $spec ~~ Rat
        ?? do { my ($w, $p) = $spec.Str.split('.').map(*.Int); fmt($val, '>' ~ $w ~ '.' ~ $p ~ 'f') }
        !! fmt($val, '>' ~ $spec)
}

# ^f : center-align (Int → string, Rat → float)
sub infix:«^f»($val, $spec --> Str) is export {
    $spec ~~ Rat
        ?? do { my ($w, $p) = $spec.Str.split('.').map(*.Int); fmt($val, '^' ~ $w ~ '.' ~ $p ~ 'f') }
        !! fmt($val, '^' ~ $spec)
}

sub f(+@parts --> Str) is export { @parts.join(' ') }
