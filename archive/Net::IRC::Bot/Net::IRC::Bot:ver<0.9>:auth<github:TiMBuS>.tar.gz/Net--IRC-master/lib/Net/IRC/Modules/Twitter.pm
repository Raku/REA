#!/usr/env perl6
use v6;

# vim: ft=perl6 tabstop=4 shiftwidth=4
