# DB::Xoos::SQLite

see https://github.com/tony-o/perl6-xoo for more info.
