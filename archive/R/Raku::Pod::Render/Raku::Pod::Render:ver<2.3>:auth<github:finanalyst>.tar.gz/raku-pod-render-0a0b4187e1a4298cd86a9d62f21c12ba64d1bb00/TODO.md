# ToDo
- hierarchical glossary needs looking at
- Change the minimal CSS
- more refactoring of the ProcessedPod class. Lots of common
code in the handles methods.
- html generator like read-y-me.raku