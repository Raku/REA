[![Actions Status](https://github.com/tbrowder/RakupodObject/actions/workflows/linux.yml/badge.svg)](https://github.com/tbrowder/RakupodObject/actions) [![Actions Status](https://github.com/tbrowder/RakupodObject/actions/workflows/macos.yml/badge.svg)](https://github.com/tbrowder/RakupodObject/actions) [![Actions Status](https://github.com/tbrowder/RakupodObject/actions/workflows/windows.yml/badge.svg)](https://github.com/tbrowder/RakupodObject/actions)

NAME
====

**RakupodObject** - An obsolete attempt to provide a routine to extract the '$=pod' object from an external Rakupod source (a file or a string)

**Please use Pod::Loader instead.**

AUTHOR
======

Tom Browder <tbrowder@acm.org>

COPYRIGHT AND LICENSE
=====================

© 2022-2024 Tom Browder

This library is free software; you may redistribute it or modify it under the Artistic License 2.0.

