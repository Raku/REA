# Test for oct mode

- translate = `:oct`

```bash
echo "Hello World!"
```
