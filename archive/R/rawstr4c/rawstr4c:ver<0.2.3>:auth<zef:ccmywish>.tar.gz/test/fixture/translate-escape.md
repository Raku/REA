# Test for escape mode

- translate = `:escape`
- output = `:terminal`

```bash
echo "Hello World!"
printf "Line with \"quotes\" and 'apostrophes'\n"
```
