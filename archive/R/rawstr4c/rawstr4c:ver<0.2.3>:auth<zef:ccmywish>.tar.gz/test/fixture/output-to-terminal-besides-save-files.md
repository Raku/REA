


# some config

- output = `:terminal`

```toml
[setting]
init = true
```


# some code

- output = `:global-variable`

```ruby
puts 123;
```
