# Test output to default files

- output = `:global-variable`

## Test String

```c
char *str = "Default file names test.";
```
