# ---------------------------------------------------------------
# SPDX-License-Identifier: Artistic-2.0
# ---------------------------------------------------------------
# File Name     : Version.rakumod
# File Authors  : Aoran Zeng <ccmywish@qq.com>
# Contributors  :  Nul None  <nul@none.org>
# Created On    : <2025-07-14>
# Last Modified : <2026-04-15>
# ---------------------------------------------------------------

unit package Rawstr4c;

constant VERSION = "1.2.0";
constant RELEASE_DATE = "2026/04/15";

constant Maintain_URL  = "https://github.com/RubyMetric/rawstr4c";
constant Maintain_URL2 = "https://gitee.com/RubyMetric/rawstr4c";

constant VERSION_CONTENT_FOR_-version = qq:to/EOF/
  rawstr4c {VERSION} ({RELEASE_DATE})
  Copyright (C) 2025-2026 Aoran Zeng
  License Artistic-2.0: Artistic License 2.0 <https://opensource.org/licenses/Artistic-2.0>
  This is free software: you are free to change and redistribute it.
  There is NO WARRANTY, to the extent permitted by law.

  Written by Aoran Zeng.
  EOF
