- prefix = `ROOT`
- no-prefix = `false`

```c
root code;
```

# Level 1

- prefix = `L1`

```c
level1 code;
```

## Level 2

```c
level2 code;
```

### Level 3

- prefix = `L3`

```c
level3 code;
```
