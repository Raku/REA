# Test output to customized files

- output = `:global-variable`
- output-h-file = `custom_strings.h`
- output-c-file = `custom_strings_impl.c`

## Test String

```c
Hello, World!
This is a test string for custom file names.
```
