# Test for hex mode

- translate = `:hex`

```bash
echo "Hello World!"
```
