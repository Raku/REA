```sh
echo 'hello world'
echo 'hello Raku'

```

Note: Intentionally leave a blank line, the end of the result should only contain one **`\n`**.
