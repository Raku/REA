# Linting

- keep-prefix = `false`
- keep-postfix = `true`
- unknown-option = `some-value`
- another-bad-option = `test`

## section

```bash
echo Test linting
```
