unit module RakuPMVerifyTmp;
our sub hello(--> Str) { "hello from RakuPMVerifyTmp" }
