# p6-Random-Hawking-Boltzmann

A random number generator based on a Boltzmann function 
filling in a Hawking Temperature
