# Raku Pod Extraction
>Change log


## Table of Contents
[2021-01-18 Transfer from Raku::Pod::Render](#2021-01-18-transfer-from-rakupodrender)  
[2021-02-03](#2021-02-03)  
[2022-01-01](#2022-01-01)  
[2022-02-18 v0.2.0](#2022-02-18-v020)  
[2022-02-20 v0.2.1](#2022-02-20-v021)  

----
# 2021-01-18 Transfer from Raku::Pod::Render
*  create module, rewrite Extractor.raku utility into module and Entrypoint

*  no other changes

# 2021-02-03
*  fixup for change in Raku::Pod::Render

# 2022-01-01
*  remove no precompilation

# 2022-02-18 v0.2.0
*  add github badge functionality

*  do not call HTML or MD methods on empty arrays

# 2022-02-20 v0.2.1


*  change CI setup to minimise actions

*  add placeholder to GTK





----
Rendered from CHANGLOG at 2022-02-20T20:41:58Z