# Raku Pod Extraction

----
----
## Table of Contents
[2021-01-18 Transfer from Raku::Pod::Render](#2021-01-18-transfer-from-rakupodrender)  
[2021-02-03](#2021-02-03)  

----
# 2021-01-18 Transfer from Raku::Pod::Render
*  create module, rewrite Extractor.raku utility into module and Entrypoint

*  no other changes

# 2021-02-03


*  fixup for change in Raku::Pod::Render





----
Rendered from CHANGLOG at 2021-02-03T10:44:34Z