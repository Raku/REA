use Test;
use JSON::Fast;
use Rakuish::Audit;
use Rakuish::Kernel;
use Rakuish::REPL::Session;

# 40-audit.t —— 「每次操作一条」的统一审计（0.80.0 / ADR-0018）
#
# 0.81.0 / ADR-0019 起只剩本机一条前端（REPL / -e / 脚本），Agent 线已删除；
# 审计仍是用户硬约束，不随安全壳一起撤。这个文件的核心是两件事：
#   1. 单点记账：三种 origin（human / script / source）都进同一本账；
#   2. 变异护栏：**策略越界的早返回**也必须记一条 —— 0.76 的实现在末尾
#      !record，而 `return $r if $denied` 会绕过它。把 LEAVE 改回去，这里必挂。

my $dir = $*TMPDIR.IO.add("audit-t-{$*PID}");
$dir.mkdir;
my $log = $dir.add('audit.jsonl');
# 0.79.1 的教训：夹具在**开头**清理，PID 复用 / 上次中断都会留下文件。
$log.unlink if $log.e;

# ── 1. Audit：字段白名单、补齐、开关 ────────────────────────────────
{
    my $a = Rakuish::Audit.new(:default-origin<agent>);
    my %e = $a.record(%(
        op => 'read_file', stage => 'op', ok => True, code => 0,
        token => 'SECRET', content => 'BODY', sql => 'select secret',
        source => 'my $pw = "secret"', seq => 999,
    ));
    is %e<seq>, 1, 'seq 由 Audit 生成，调用方不能伪造';
    ok %e<ts>.chars > 0, '自动补时间戳';
    is %e<origin>, 'agent', 'origin 有默认值';
    is %e<ok>, True, 'ok 保留';
    nok %e<token>:exists, 'token 被字段白名单挡掉';
    nok %e<content>:exists, '文件内容被挡掉';
    nok %e<sql>:exists, 'SQL 全文被挡掉';
    nok %e<source>:exists, '源码全文被挡掉';
    is $a.entries.elems, 1, '内存账本 1 条';

    my $off = Rakuish::Audit.new(:!enabled);
    $off.record(%(op => 'x'));
    is $off.entries.elems, 0, '关闭后一条都不记';

    ok Rakuish::Audit::fingerprint('abc').chars > 0, '指纹非空';
    is Rakuish::Audit::fingerprint('abc'), Rakuish::Audit::fingerprint('abc'),
        '指纹稳定';
    isnt Rakuish::Audit::fingerprint('abc'), Rakuish::Audit::fingerprint('abd'),
        '不同源码指纹不同';
}

# ── 2. 轮转上限 ────────────────────────────────────────────────────
{
    my $a = Rakuish::Audit.new(:max-entries(3));
    $a.record(%(op => $_.Str)) for 1 .. 5;
    is $a.entries.elems, 3, '超过 max-entries 后只留最新 3 条';
    is $a.entries[0]<op>, '3', '淘汰的是最早的';
    is $a.summary<entries>, 3, 'summary 报条目数';
}

# ── 3. Kernel：每次 execute 恰好一条，含失败 / 拒绝 / 坏请求 ──────────
my $klog = Rakuish::Audit.new(:default-origin<human>);
my $kernel = Rakuish::Kernel.new(
    :session(Rakuish::REPL::Session.new), :audit($klog));

my @reqs =
    Request.new(:kind<source>, :payload('1 + 1'), :origin<human>),
    Request.new(:kind<source>, :payload('NoSuchNameAbc()'), :origin<human>),
    Request.new(:kind<op>, :payload(%(op => 'capabilities')), :origin<human>),
    Request.new(:kind<op>, :payload(%(op => 'nope')), :origin<human>),
    Request.new(:kind<teleport>, :payload('x'), :origin<human>),
    Request.new(:kind<source>, :payload(42), :origin<human>);
$kernel.execute($_) for @reqs;
is $klog.entries.elems, 6, '6 次 execute 恰好 6 条（成功/失败/501/坏请求都算）';
is $klog.entries.grep({ .<origin> eq 'human' }).elems, 6, 'origin 都是 human';
is $klog.entries.grep({ .<code> == 0 }).elems, 2, '成功 2 条';
ok $klog.entries.grep({ .<code> != 0 }).elems == 4, '失败 4 条也留痕';

my @src = $klog.entries.grep({ .<kind> eq 'source' });
ok @src[0]<source-hash>.chars > 0, '源码留指纹';
is @src[0]<source-bytes>, 5, '源码留字节数';
my $dump = to-json($klog.entries.List, :!pretty);
nok $dump.contains('NoSuchNameAbc'), '审计里不出现源码文本（含编译错误里的片段）';
nok $dump.contains('"token"'), '审计条目不含 token 字段';

# 变异护栏：这是 0.76 真正漏记的那条路径（CATCH → return → 绕过末尾记账）。
{
    my $rlog = Rakuish::Audit.new(:default-origin<human>);
    my $rooted = Rakuish::Kernel.new(
        :session(Rakuish::REPL::Session.new), :audit($rlog),
        :policy(Policy.new(:root($dir))));
    my $r = $rooted.execute(Request.new(
        :kind<source>, :payload('6'), :origin<human>,
        :policy(Policy.new(:root(IO::Path.new('/'))))));
    nok $r.ok, 'root 越界请求被拒绝';
    is $r.code, 403, '越界码 403';
    is $rlog.entries.elems, 1, '策略越界的早返回也恰好记一条（LEAVE 回归）';
    is $rlog.entries[0]<code>, 403, '记的是拒绝结果';
}

# ── 5. 注入共享实例：三种 origin 进同一本账 ────────────────────────
# 0.81.0 之前这里是「人 + Agent 双前端对账」；Agent 线删除后，
# 仍然要证明「同一个 Audit 实例可被多处注入、条目不串不乱」。
{
    my $shared = Rakuish::Audit.new;
    my $k = Rakuish::Kernel.new(
        :session(Rakuish::REPL::Session.new), :audit($shared));
    $k.execute(Request.new(:kind<source>, :payload('1'), :origin<human>));
    $k.execute(Request.new(:kind<source>, :payload('2'), :origin<human>));
    $k.execute(Request.new(:kind<op>, :payload(%(op => 'capabilities')),
                           :origin<script>));
    $k.execute(Request.new(:kind<source>, :payload('3'), :origin<script>));
    is $shared.entries.elems, 4, '4 次 execute 4 条';
    is $shared.entries.grep({ .<origin> eq 'human' }).elems, 2, 'human origin 2 条';
    is $shared.entries.grep({ .<origin> eq 'script' }).elems, 2, 'script origin 2 条';
    ok $shared.entries.map(*.<seq>).List.Array ~~ Array, 'seq 字段存在';
}

# ── 6. 落盘：单行 JSONL、seq 连续、可解析 ──────────────────────────
{
    $log.unlink if $log.e;
    my $a = Rakuish::Audit.new(:path($log.Str));
    $a.record(%(op => 'a', ok => True));
    $a.record(%(op => 'b', ok => False, err => 'x'));
    my @lines = $log.slurp.lines;
    is @lines.elems, 2, '落盘 2 行';
    is from-json(@lines[0])<op>, 'a', '每行一条可解析 JSON';
    is from-json(@lines[1])<seq>, 2, '进程内 seq 连续';

    my $b = Rakuish::Audit.new(:path($log.Str));
    $b.record(%(op => 'c'));
    is from-json($log.slurp.lines.tail)<seq>, 3, '新进程追加时 seq 接着走';
}

# ── 7. 入口静态护栏：唯一入口的三个模式共用一本账 ──────────────────
{
    # 0.106.1：入口逻辑在 Rakuish::CLI 模块；bin 只是启动器。
    my $rakuish = $*CWD.add('lib').add('Rakuish').add('CLI.rakumod').slurp;
    ok $rakuish.contains('make-kernel($sess, shared-audit())'),
        'REPL / -e / 脚本共用 make-kernel 的共享审计';
    ok $rakuish.contains("use Rakuish::Audit"), 'REPL 入口加载 Audit';
    # ADR-0019：Agent 入口已删除，不再有第二个注入点。
    nok $*CWD.add('bin').add('rakuish-agent').e, 'Agent 入口已删除';
}

# ── 8. 默认开启：-e 模式也会落盘（不经任何命令开关）────────────────
{
    my $probe = $dir.add('probe.jsonl');
    $probe.unlink if $probe.e;
    my $saved = %*ENV<RAKUISH_AUDIT>;
    %*ENV<RAKUISH_AUDIT> = $probe.Str;
    my $p = run($*EXECUTABLE.Str, '-Ilib', 'bin/rakuish', '-e', '1 + 1',
                :out, :err);
    $p.out.slurp;
    $p.err.slurp;
    if $saved.defined { %*ENV<RAKUISH_AUDIT> = $saved }
    else { %*ENV<RAKUISH_AUDIT>:delete }
    ok $probe.e, '-e 模式默认落盘审计';
    is $probe.slurp.lines.elems, 1, '-e 恰好一条';
    my %e = from-json($probe.slurp.lines[0]);
    is %e<origin>, 'human', '入口审计 origin=human';
    is %e<kind>, 'source', '入口审计 kind=source';
}

# ── 清理 ───────────────────────────────────────────────────────────
for $dir.dir -> $f { try { $f.unlink } }
try { $dir.rmdir };

done-testing;
