# 测试夹具（t/62）：模块导出普通 sub，验证导入的函数也能跨格生效。
unit module TestNS::Tool;

sub tool-name(--> Str) is export { 'tool' }
