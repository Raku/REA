# 测试夹具（t/62）：模拟 DB::DuckDB / Concurrent::Stack 那种「模块名即类名」
# 的包，用来验证 REPL 跨格 `use` 后能不能解析 `TestNS::Box` 这种带 :: 的名字。
unit class TestNS::Box;

method hi(--> Int) { 42 }
