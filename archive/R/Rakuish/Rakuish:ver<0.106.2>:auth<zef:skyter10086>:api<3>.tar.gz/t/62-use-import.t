use Test;
use lib 't/lib';
use Rakuish::REPL::Session;

# ══════════════════════════════════════════════════════════════════
# 62-use-import.t —— `use` 必须跨格生效（0.106.2 / V-297）
# ══════════════════════════════════════════════════════════════════
# 起因（真实报障）：
#     > use DB::DuckDB
#     > my $db = DB::DuckDB.new
#     错误: assign requires a concrete object (got a VMNull type object instead)
#
# 根因有两层：
#   1. EVAL 在包 Rakuish::REPL::Session 里编译，`DB::DuckDB` 会被当成
#      Rakuish::REPL::Session::DB::DuckDB 去找；只有同一编译单元里出现过
#      `use DB::DuckDB` 时，编译器才认得出这是 GLOBAL 下的类型。
#   2. Rakudo 里 `use Foo` **不带分号**、后面直接换行时，同一编译单元也
#      认不到导入名（`do { use X⏎X::Y }` 实测报 "Could not find symbol '&Y'"）。
#      rakuish 的 prelude 用换行拼接，于是重放出来的 `use` 形同虚设。
#
# 所以这里既测「跨格重放」，也测「同一格里 use 后面直接换行」的写法。

my $R = $*EXECUTABLE.Str;

# ── 1. 跨格：先 use，下一格直接用带 :: 的类型名 ────────────────────
my $s = Rakuish::REPL::Session.new;
my $u = $s.eval-line('use TestNS::Box');
ok $u.ok, 'use TestNS::Box 成功';
is $u.err, '', 'use 格没有错误输出';

my $r = $s.eval-line('TestNS::Box.new.hi');
ok $r.ok, '下一格能解析 TestNS::Box（不再落到 Session::TestNS）';
is $r.value, 42, '方法正常调用';
nok $r.err.contains('Could not find symbol'), '没有 &Box 找不到的报错';

# ── 2. 同一格里 use 后直接换行（不写分号）───────────────────────────
my $nl = Rakuish::REPL::Session.new;
my $r2 = $nl.eval-line("use TestNS::Box\nTestNS::Box.new.hi");
ok $r2.ok, 'use 后面直接换行，同一格仍能解析类型名';
is $r2.value, 42, '换行写法的方法调用结果';

# ── 3. use 和其它语句混在一格：use 仍要进 prelude ───────────────────
my $mix = Rakuish::REPL::Session.new;
my $r3 = $mix.eval-line('use TestNS::Box; 1 + 1');
ok $r3.ok, '混合格求值成功';
is $r3.value, 2, '混合格的表达式值';
my $r4 = $mix.eval-line('TestNS::Box.new.hi');
ok $r4.ok, '混合格里的 use 也被记住';
is $r4.value, 42, '混合格之后类型仍可用';

# ── 4. use 后面跟注释 ──────────────────────────────────────────────
my $cm = Rakuish::REPL::Session.new;
ok $cm.eval-line('use TestNS::Box # 注释').ok, 'use + 行内注释求值成功';
my $r5 = $cm.eval-line('TestNS::Box.new.hi');
ok $r5.ok, '注释不影响导入';
is $r5.value, 42, '注释格之后的类型调用';

# ── 5. 导入的函数也跨格 ────────────────────────────────────────────
my $fn = Rakuish::REPL::Session.new;
ok $fn.eval-line('use TestNS::Tool').ok, 'use 一个纯导出 sub 的模块';
my $r6 = $fn.eval-line('tool-name()');
ok $r6.ok, '导出的 sub 下一格可见';
is $r6.value, 'tool', '导出 sub 的返回值';

# ── 6. 重复 use 不报重复声明 ───────────────────────────────────────
my $dup = Rakuish::REPL::Session.new;
ok $dup.eval-line('use TestNS::Box').ok, '第一次 use';
ok $dup.eval-line('use TestNS::Box').ok, '第二次 use 不报重复声明';
ok $dup.eval-line('TestNS::Box.new.hi').ok, '重复 use 之后照常可用';

# ── 7. 带引号的 use lib 不被补分号的动作弄坏 ───────────────────────
my $lib = Rakuish::REPL::Session.new;
my $r7 = $lib.eval-line(q{use lib "t/lib"});
ok $r7.ok, q{use lib "t/lib" 正常};
ok $lib.eval-line('use TestNS::Box').ok, 'use lib 之后仍能加载夹具模块';
is $lib.eval-line('TestNS::Box.new.hi').value, 42, 'use lib 链路上的类型调用';

# ── 8. 原有行为没被打破：普通 my / sub 仍跨格 ──────────────────────
my $keep = Rakuish::REPL::Session.new;
$keep.eval-line('my $x = 41');
is $keep.eval-line('$x + 1').value, 42, 'my 仍跨格';
$keep.eval-line('sub twice($n) { $n * 2 }');
is $keep.eval-line('twice(21)').value, 42, 'sub 仍跨格';

done-testing;
