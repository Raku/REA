use Test;

# 0.76.1 / ADR-0014：Windows 控制台码页收口。
#
# 现场：中文环境的控制台默认 936（GBK），Rakudo 的控制台 I/O 按 UTF-8 解析。
# 于是「ls 后面跟中文」敲进去没反应 —— 实测 `$*IN.get` 直接抛
# `Malformed UTF-8 near byte d0`，行编辑器按「凑够一个合法 UTF-8 序列」
# 循环读字节，凑不出来就一直等（回车也不生效）。
#
# 这里钉四件事：
#   ① 模块在非 Windows 上是纯 no-op，不会去碰 NativeCall 的 kernel32；
#   ② `:interactive(False)` 是硬闸门：管道 / 脚本不许改用户的全局码页；
#   ③ 切换后必须能还原，且 `restore-console` 幂等；
#   ④ 入口在**所有分发之前**调用它，且有 END 兜底还原。
#
# 注意：本文件**不会**真的改测试进程的码页 —— 所有断言走 `:interactive(False)`
# 与静态检查；真实切换只验证「返回 False 且码页没动」。

use Rakuish::Sys::Console;

sub repo-root(--> IO::Path) {
    my IO::Path $d = $*CWD.IO.absolute.IO;
    loop {
        return $d if $d.add('META6.json').e;
        my IO::Path $up = $d.parent;
        return $d if $up.absolute.Str eq $d.absolute.Str;
        $d = $up;
    }
}
my $root = repo-root();
# 0.106.1：入口逻辑在 Rakuish::CLI 模块里；bin 只是启动器。
my Str $bin = $root.add('lib/Rakuish/CLI.rakumod').slurp;

# ── 1. 平台闸门 ──────────────────────────────────────────────────
if $*DISTRO.is-win {
    ok console-cp() >= 0, 'Windows: console-cp 返回非负整数（0 = 没有控制台）';
    ok console-output-cp() >= 0, 'Windows: console-output-cp 同样非负';
    is ensure-utf8-console(:interactive(False)), False,
       'Windows: 非交互时拒绝改码页（返回 False）';
    is restore-console(), Nil, 'Windows: 未改动过时 restore 是安全 no-op';
}
else {
    is console-cp(), 0, '非 Windows: console-cp 恒为 0';
    is ensure-utf8-console(:interactive(True)), False,
       '非 Windows: 即便声明交互也不动（POSIX 终端本来就是 UTF-8）';
    ok describe().contains('non-Windows'), '非 Windows: describe 走 non-Windows 分支';
}

# ── 2. 闸门不产生副作用（关键：别把测试机的码页改掉）────────────
my Int $cp-before = console-cp();
is ensure-utf8-console(:interactive(False)), False, '非交互调用一律返回 False';
is console-cp(), $cp-before, '非交互调用后码页一字未变';
is ensure-utf8-console(:interactive(False)), False, '重复调用仍返回 False（幂等）';
is console-cp(), $cp-before, '重复调用也不改码页';

# ── 3. 入口接线（静态）──────────────────────────────────────────
ok $bin.contains('use Rakuish::Sys::Console'), '入口加载码页模块';
ok $bin.contains('ensure-utf8-console(:interactive('), '入口按交互与否决定是否切换';

my Int $i-ensure = $bin.index('ensure-utf8-console(:interactive(');
my Int $i-given  = $bin.index('given @a[0]');
ok $i-ensure.defined && $i-ensure > 0, '入口里有切换调用';
ok $i-given.defined && $i-given > 0, '入口里有参数分发';
ok $i-ensure < $i-given, '切换发生在所有分发之前（-e / 脚本 / REPL 都覆盖）';

ok $bin.contains('END {') && $bin.contains('restore-console()'),
    '入口有 END 兜底还原';
nok $bin.contains('chcp'), '不靠 chcp / 外部命令改码页（那要起进程，也跨不过沙箱）';
nok $bin.contains('cmd /c'), '不 shell out 到 cmd';

# ── 4. 端到端：管道下中文仍然完好（编码回归）────────────────────
# 管道不走控制台，靠的是 UTF-8 本身；这条守着「有人把 CP 改成全局强制」。
my $tmp = $*TMPDIR.IO.add("rk-cjk-{$*PID}");
$tmp.mkdir;
$tmp.add('中文目录').mkdir;
$tmp.add('中文目录').add('文件.txt').spurt("x\n");
END {
    if $tmp.d {
        for $tmp.dir -> $f {
            if $f.d {
                for $f.dir -> $g { try $g.unlink }
                try $f.rmdir;
            }
        }
        try $tmp.rmdir;
    }
}

my Str $exe = $*EXECUTABLE.Str;
sub run-rakuish(Str $stdin, *@args, IO::Path :$cwd --> Hash) {
    my $in = $*TMPDIR.IO.add("rk-cjk-stdin-{$*PID}.txt");
    $in.spurt($stdin);
    my $fh = $in.open;
    my $p = run($exe, $root.add('bin/rakuish').Str, |@args,
                :in($fh), :out, :err, :cwd($cwd // $root));
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    my Int $rc = $p.exitcode;
    $fh.close;
    try $in.unlink;
    { out => $out, err => $err, rc => $rc };
}

my %e1 = run-rakuish('', '-e', 'say "中文"');
is %e1<rc>, 0, '-e 中文输出退出码 0';
ok %e1<out>.contains('中文'), '-e 中文输出未被编码破坏';

my %e2 = run-rakuish('ls 中文目录' ~ "\n", :cwd($tmp));
is %e2<rc>, 0, '管道下 ls 中文目录 退出码 0';
ok %e2<out>.contains('文件.txt'), '管道下 ls 中文目录 能列出内容';
ok %e2<err>.contains('Malformed') == False, '没有 Malformed UTF-8';

my %e3 = run-rakuish('ls 中文*' ~ "\n", :cwd($tmp));
ok %e3<out>.contains('中文目录'), '管道下中文 glob 可用';

done-testing;
