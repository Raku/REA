"""Windows 真控制台下「求值期间 Ctrl-C」的实测探针。

0.85.0 的中断支持只在 Linux / WSL 验证过：那边终端在求值期间是 cooked，
`\\x03` 由行规程转成 SIGINT 投给前台进程组，父进程与引擎都会收到。
Windows 没有 POSIX 会话/进程组，Ctrl-C 是 `CTRL_C_EVENT`，由
`GenerateConsoleCtrlEvent` 投给**同一控制台**的进程 —— 语义相近但不保证
逐条对应。所以这里不推断，直接用 ConPTY 起真控制台跑一遍。

探针做的事（三步，缺一不可）：

  1. `my $keep = 99` → 确认基线可用，并且快照里有一个可恢复的变量；
  2. `loop { }` → 引擎卡住；往伪控制台写 `\\x03`，观察
     · REPL 是否回到 prompt（父进程没被打死）
     · 输出里是「已中断当前求值」还是「引擎进程已退出」
       —— 前者说明 Client 的 handler 抢到了信号，后者说明没抢到、
          只是终端信号顺手把引擎打死了（0.84 的行为）
  3. `say $keep` → 99 说明中断后走的是重启 + 快照恢复，而不是白丢状态。

第二个场景是 `! --tty` 期间的中断（`t/30` 的 Windows 对应物）：

  · `! --tty raku <child>` 把终端交给子进程；
  · 此时按 Ctrl-C，SIGINT 必须落到**子进程**（它自己 trap 并打印标记）；
  · 同一个信号不许带走宿主 REPL；
  · 交接结束后 prompt 回来、还能正常求值、还能正常退出。

POSIX 侧这条契约由 `t/30-tty-exec-sigint.t` 用真 PTY 覆盖；Windows 之前
整段 skip，等于「没验过」，这里补上。

退出码：0 全部符合预期 / 1 有断言失败 / 2 环境不具备（非 Windows、没有
raku、没有控制台且没有 winpty）。

用法：
    python tools/ctrl-c-win.py          # 有控制台时直接跑
    python tools/ctrl-c-win.py --json   # 机器可读结果（给后续接进 t/43 用）
"""

import ctypes
import ctypes.wintypes as wt
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAKU = shutil.which("raku") or r"C:\rakudo\bin\raku.exe"
PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE = 0x00020016
EXTENDED_STARTUPINFO_PRESENT = 0x00080000
RELAUNCH_ENV = "RAKUISH_WINCTRL_RELAUNCHED"
VERDICT_ENV = "RAKUISH_WINCTRL_VERDICT"

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)


class COORD(ctypes.Structure):
    _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]


class STARTUPINFOW(ctypes.Structure):
    _fields_ = [
        ("cb", wt.DWORD), ("lpReserved", wt.LPWSTR), ("lpDesktop", wt.LPWSTR),
        ("lpTitle", wt.LPWSTR), ("dwX", wt.DWORD), ("dwY", wt.DWORD),
        ("dwXSize", wt.DWORD), ("dwYSize", wt.DWORD),
        ("dwXCountChars", wt.DWORD), ("dwYCountChars", wt.DWORD),
        ("dwFillAttribute", wt.DWORD), ("dwFlags", wt.DWORD),
        ("wShowWindow", wt.WORD), ("cbReserved2", wt.WORD),
        ("lpReserved2", ctypes.c_void_p), ("hStdInput", wt.HANDLE),
        ("hStdOutput", wt.HANDLE), ("hStdError", wt.HANDLE),
    ]


class STARTUPINFOEXW(ctypes.Structure):
    _fields_ = [("StartupInfo", STARTUPINFOW), ("lpAttributeList", ctypes.c_void_p)]


class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [("hProcess", wt.HANDLE), ("hThread", wt.HANDLE),
                ("dwProcessId", wt.DWORD), ("dwThreadId", wt.DWORD)]


kernel32.CreatePipe.argtypes = [ctypes.POINTER(wt.HANDLE), ctypes.POINTER(wt.HANDLE),
                                ctypes.c_void_p, wt.DWORD]
kernel32.CreatePseudoConsole.argtypes = [COORD, wt.HANDLE, wt.HANDLE, wt.DWORD,
                                         ctypes.POINTER(wt.HANDLE)]
kernel32.CreatePseudoConsole.restype = ctypes.c_long
kernel32.InitializeProcThreadAttributeList.argtypes = [
    ctypes.c_void_p, wt.DWORD, wt.DWORD, ctypes.POINTER(ctypes.c_size_t)]
kernel32.UpdateProcThreadAttribute.argtypes = [
    ctypes.c_void_p, wt.DWORD, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t,
    ctypes.c_void_p, ctypes.c_void_p]
kernel32.CreateProcessW.argtypes = [
    wt.LPCWSTR, wt.LPWSTR, ctypes.c_void_p, ctypes.c_void_p, wt.BOOL, wt.DWORD,
    ctypes.c_void_p, wt.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(PROCESS_INFORMATION)]
kernel32.ReadFile.argtypes = [wt.HANDLE, ctypes.c_void_p, wt.DWORD,
                              ctypes.POINTER(wt.DWORD), ctypes.c_void_p]
kernel32.WriteFile.argtypes = [wt.HANDLE, ctypes.c_void_p, wt.DWORD,
                               ctypes.POINTER(wt.DWORD), ctypes.c_void_p]
kernel32.GetExitCodeProcess.argtypes = [wt.HANDLE, ctypes.POINTER(wt.DWORD)]


def has_console():
    mode = wt.DWORD(0)
    return bool(kernel32.GetConsoleMode(kernel32.GetStdHandle(-10), ctypes.byref(mode)))


class ConPTY:
    """在真伪控制台里跑一个子进程，可写输入、收集输出。"""

    def __init__(self, cmdline, cwd=None, cols=110, rows=30):
        self.buf = bytearray()
        self._lock = threading.Lock()

        h_in_read, h_in_write = wt.HANDLE(), wt.HANDLE()
        h_out_read, h_out_write = wt.HANDLE(), wt.HANDLE()
        for a, b in ((h_in_read, h_in_write), (h_out_read, h_out_write)):
            if not kernel32.CreatePipe(ctypes.byref(a), ctypes.byref(b), None, 0):
                raise OSError(ctypes.get_last_error(), "CreatePipe failed")

        self.h_in_write = h_in_write
        self.h_out_read = h_out_read
        self.h_pc = wt.HANDLE()
        hr = kernel32.CreatePseudoConsole(COORD(cols, rows), h_in_read, h_out_write,
                                          0, ctypes.byref(self.h_pc))
        if hr != 0:
            raise OSError(hr, "CreatePseudoConsole failed hr=0x%08x" % (hr & 0xFFFFFFFF))

        size = ctypes.c_size_t(0)
        kernel32.InitializeProcThreadAttributeList(None, 1, 0, ctypes.byref(size))
        self._attrs = ctypes.create_string_buffer(size.value)
        if not kernel32.InitializeProcThreadAttributeList(self._attrs, 1, 0,
                                                          ctypes.byref(size)):
            raise OSError(ctypes.get_last_error(), "InitializeProcThreadAttributeList failed")
        if not kernel32.UpdateProcThreadAttribute(
                self._attrs, 0, PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE,
                self.h_pc, ctypes.sizeof(wt.HANDLE), None, None):
            raise OSError(ctypes.get_last_error(), "UpdateProcThreadAttribute failed")

        si = STARTUPINFOEXW()
        si.StartupInfo.cb = ctypes.sizeof(STARTUPINFOEXW)
        si.StartupInfo.dwFlags = 0          # 不能设 STARTF_USESTDHANDLES
        si.lpAttributeList = ctypes.cast(self._attrs, ctypes.c_void_p)

        pi = PROCESS_INFORMATION()
        cmd = ctypes.create_unicode_buffer(cmdline)
        ok = kernel32.CreateProcessW(None, cmd, None, None, False,
                                     EXTENDED_STARTUPINFO_PRESENT, None,
                                     cwd or ROOT, ctypes.byref(si), ctypes.byref(pi))
        if not ok:
            raise OSError(ctypes.get_last_error(), "CreateProcessW failed")
        self.h_process = pi.hProcess
        kernel32.CloseHandle(pi.hThread)
        kernel32.CloseHandle(h_in_read)
        kernel32.CloseHandle(h_out_write)

        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        buf = ctypes.create_string_buffer(4096)
        n = wt.DWORD(0)
        while True:
            if not kernel32.ReadFile(self.h_out_read, buf, 4096, ctypes.byref(n), None):
                return
            if n.value == 0:
                return
            with self._lock:
                self.buf.extend(buf.raw[: n.value])

    def write(self, data):
        if isinstance(data, str):
            data = data.encode("utf-8")
        n = wt.DWORD(0)
        kernel32.WriteFile(self.h_in_write, data, len(data), ctypes.byref(n), None)

    @property
    def raw(self):
        with self._lock:
            return bytes(self.buf)

    def text(self):
        txt = self.raw.decode("utf-8", "replace")
        txt = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", txt)
        txt = re.sub(r"\x1b\][^\x07]*\x07", "", txt)
        return txt

    def poll(self):
        code = wt.DWORD(0)
        kernel32.GetExitCodeProcess(self.h_process, ctypes.byref(code))
        return None if code.value == 259 else code.value

    def settle(self, quiet=1.2, timeout=40):
        """等输出静止一段时间。

        ConPTY 里「敲完一行」不等于「这一格跑完」：回显、重绘、引擎重启都会
        陆续吐字节。用固定 sleep 判下一步，就会把**上一格还没收尾**当成
        「已经空出来了」，下一行输入被行编辑器当成中途编辑吃掉
        （0.86 开发中实测：连 `note 'SPIN'` 都没执行）。
        """
        end = time.time() + timeout
        last, stable = -1, 0.0
        while time.time() < end:
            n = len(self.raw)
            if n != last:
                last, stable = n, time.time()
            elif time.time() - stable >= quiet:
                return True
            time.sleep(0.1)
        return False

    def type_line(self, text, quiet=0.5):
        """打字 + 回车分两次写。

        ConPTY 里把 `整行 + \r` 一次写进去会有竞态：行编辑器正在重绘时，
        回车可能被当成「重绘的一部分」吞掉，表现为「这行压根没执行」
        （0.87 实测：`! --tty ...` 三次里偶发一次不执行）。
        分开写等价于人类敲完停一下再按回车，稳定得多。
        """
        self.write(text)
        self.settle(quiet, 10)
        self.write("\r")
        self.settle(1.0, 40)

    def wait_for(self, needle, timeout=60):
        end = time.time() + timeout
        while time.time() < end:
            if needle in self.text():
                return True
            time.sleep(0.2)
        return False

    def close(self):
        try:
            kernel32.ClosePseudoConsole(self.h_pc)
        except Exception:
            pass
        for h in (self.h_in_write, self.h_out_read, self.h_process):
            try:
                kernel32.CloseHandle(h)
            except Exception:
                pass


def run_scenario():
    """起一个真 rakuish，跑「基线 → 死循环 → Ctrl-C → 复查」四步。"""
    home = tempfile.mkdtemp(prefix="rakuish-winctrl-")
    env = dict(os.environ)
    env.update({
        "RAKUISH_CONFIG": os.path.join(home, "config.json"),
        "RAKUISH_SNAPSHOT": os.path.join(home, "snap.json"),
        "RAKUISH_NO_AUDIT": "1",
        "RAKUISH_NO_SNAPSHOT": "",
        "TERM": "xterm-256color",
    })
    os.environ.update({k: env[k] for k in ("RAKUISH_CONFIG", "RAKUISH_SNAPSHOT",
                                          "RAKUISH_NO_AUDIT", "RAKUISH_NO_SNAPSHOT")})

    p = ConPTY('"%s" -Ilib bin\\rakuish' % RAKU, cwd=ROOT)
    res = {"platform": "win", "steps": {}}
    try:
        res["steps"]["ready"] = p.wait_for("\u276f", 60)
        if not res["steps"]["ready"]:
            res["verdict"] = "no-prompt"
            res["tail"] = p.text()[-800:]
            return res

        # prompt 打印 ≠ 行编辑器可接收输入：read-input 进入 raw mode 后还要
        # await DSR / 终端尺寸探测，`react whenever` 建立前到达的按键会丢
        # （整行变空行 → 快照从未写出 → state_survived 假失败）。
        # 真机实测：不等则 4 次里 3 次失败；留出建立时间后稳定。
        p.settle(1.0, 10)

        def send(line, quiet=1.2):
            """发一行并等它收尾（回显 + 求值 + 重绘都结束）。"""
            p.type_line(line, 0.5)
            if quiet > 1.0:
                p.settle(quiet - 1.0, 10)
            return p.text()

        send("my $keep = 99")
        baseline_text = send("say $keep")
        res["steps"]["baseline"] = "99" in baseline_text

        # 对照：在**没有求值**的时候按 Ctrl-C，必须走行编辑器的输入中断。
        # 没有这一步，上面「出现『已中断当前求值』」就可能只是文案恒真，
        # 断言等于没写（0.85 的 POSIX 测试也靠同型对照站住）。
        ctl_mark = len(p.text())
        p.write(b"\x03")
        p.settle(1.0, 20)
        ctl = p.text()[ctl_mark:]
        res["steps"]["control_input_intr"] = "已中断当前输入" in ctl
        res["steps"]["control_no_eval_intr"] = "已中断当前求值" not in ctl

        # 用 `note` 当门闩：它写引擎的 stderr，Client 直接转发、不等格结束，
        # 所以「SPIN 出现」== 「引擎确实进了这一格」。
        # 直接 `loop { }` 无法从外部观测，探针会在格子还没开始时就把 \x03
        # 发出去 —— 那测到的是行编辑器的「输入中断」，是假阴性
        # （0.85 之前就是在这一步误判成「Windows 不支持」）。
        mark = len(p.text())
        p.type_line("note 'SPIN'; loop { }", 0.8)
        res["steps"]["cell_started"] = p.wait_for("SPIN", 25)
        time.sleep(0.5)
        res["steps"]["spinning"] = p.poll() is None

        p.write(b"\x03")          # 真 Ctrl-C：写进伪控制台输入端
        p.settle(2.0, 40)

        seg = p.text()[mark:]
        res["steps"]["alive_after_ctrlc"] = p.poll() is None
        res["steps"]["says_interrupted"] = "已中断当前求值" in seg
        res["steps"]["says_crashed"] = "引擎进程已退出" in seg
        res["steps"]["says_input_intr"] = "已中断当前输入" in seg
        res["steps"]["prompt_back"] = seg.count("\u276f") > 0

        after_mark = len(p.text())
        if p.poll() is None:
            # 引擎重启 + 快照恢复要时间；等它自己收尾，别用固定 sleep
            # 把「还没跑完」判成「被吞掉了」。
            after = send("say $keep", 2.0)
            after = p.text()[after_mark:]
            res["steps"]["state_survived"] = "99" in after
            res["after_interrupt"] = after[-800:]
        else:
            res["steps"]["state_survived"] = False

        res["segment"] = seg[-1200:]
        if p.poll() is None:
            p.type_line("exit", 0.4)
            time.sleep(2)
        res["exit"] = p.poll()
    finally:
        p.close()
    return res


CHILD = """say 'NESTED-READY tty=' ~ $*IN.t;
signal(SIGINT).tap({ say 'NESTED-SIGINT'; exit 130 });
loop {
    my $l = $*IN.get;
    last unless $l.defined;
    last if $l.trim eq 'exit';
    say "NESTED-GOT[{$l.trim}]";
}
say 'NESTED-BYE';
"""


def run_tty_exec():
    """场景二：`! --tty` 期间 Ctrl-C 的归属（t/30 的 Windows 对应物）。"""
    home = tempfile.mkdtemp(prefix="rakuish-wintty-")
    env = dict(os.environ)
    env.update({
        "RAKUISH_CONFIG": os.path.join(home, "config.json"),
        "RAKUISH_SNAPSHOT": os.path.join(home, "snap.json"),
        "RAKUISH_NO_AUDIT": "1",
        "RAKUISH_NO_SNAPSHOT": "1",
        "TERM": "xterm-256color",
    })
    os.environ.update({k: env[k] for k in ("RAKUISH_CONFIG", "RAKUISH_SNAPSHOT",
                                          "RAKUISH_NO_AUDIT", "RAKUISH_NO_SNAPSHOT")})

    child = os.path.join(ROOT, "tmp", "wintty-child-%d.raku" % os.getpid())
    with open(child, "w", encoding="utf-8", newline="\n") as f:
        f.write(CHILD)

    p = ConPTY('"%s" -Ilib bin\\rakuish' % RAKU, cwd=ROOT)
    res = {"scenario": "tty-exec", "steps": {}}
    try:
        res["steps"]["ready"] = p.wait_for("\u276f", 60)
        if not res["steps"]["ready"]:
            res["tail"] = p.text()[-800:]
            return res

        p.type_line("1 + 1")
        res["steps"]["first_eval"] = "Out[1] = 2" in p.text()

        rel = os.path.relpath(child, ROOT).replace("\\", "/")
        p.type_line("! --tty %s %s" % (RAKU, rel), 0.8)
        res["steps"]["nested_ready"] = p.wait_for("NESTED-READY", 40)
        time.sleep(0.5)

        p.write(b"\x03")
        p.settle(2.0, 40)

        t = p.text()
        res["steps"]["child_sigint"] = "NESTED-SIGINT" in t
        res["steps"]["host_alive"] = p.poll() is None
        res["steps"]["prompt_back"] = t.count("\u276f") >= 2
        # 0.101.4：Ctrl-C 属于前台子进程，**不能把引擎打死**。此前父进程的
        # SIGINT handler 在 tty 直通期走 `in-request` 分支 SIGKILL 引擎，
        # REPL 虽活着但会打印「引擎进程已退出 → 重启」，终端半坏后卡死。
        # 探针之前只看「下一格能不能求值」，所以一直假绿。
        res["steps"]["engine_survived"] = "引擎进程已退出" not in t

        if p.poll() is None:
            before = len(t)
            p.type_line("say 6 * 7", 0.6)
            res["steps"]["next_eval"] = "42" in p.text()[before:]
            p.write("exit\r")
            for _ in range(30):
                p.settle(0.4, 3)
                if p.poll() is not None:
                    break
            res["steps"]["clean_exit"] = p.poll() == 0
        else:
            res["steps"]["next_eval"] = False
            res["steps"]["clean_exit"] = False

        res["segment"] = p.text()[-1200:]
        res["exit"] = p.poll()
    finally:
        p.close()
        try:
            os.unlink(child)
        except OSError:
            pass
    return res


def decide_tty_exec(res):
    fails = []
    s = res.get("steps", {})
    if not s.get("ready"):
        return ["场景二：REPL 没起来"]
    if not s.get("first_eval"):
        fails.append("场景二：前置求值失败（`1 + 1` 没出 Out[1] = 2）")
    if not s.get("nested_ready"):
        fails.append("场景二：`! --tty` 的子进程没拿到终端（没打印 NESTED-READY）")
    if not s.get("child_sigint"):
        fails.append("场景二：子进程没收到 SIGINT —— 信号没进前台进程组")
    if not s.get("host_alive"):
        fails.append("场景二：同一个 SIGINT 把宿主 REPL 带走了")
    if not s.get("engine_survived"):
        fails.append("场景二：Ctrl-C 把引擎打死了（出现「引擎进程已退出」——"
                     "重启后终端易进光标错位/输入无响应的死角）")
    if not s.get("prompt_back"):
        fails.append("场景二：交接结束后 prompt 没回来")
    if not s.get("next_eval"):
        fails.append("场景二：交接后下一格不能求值")
    if not s.get("clean_exit"):
        fails.append("场景二：之后不能正常退出（或退出码非 0）")
    return fails


def decide(res):
    """把观察结果翻译成结论 + 失败项。"""
    fails = []
    s = res.get("steps", {})
    if not s.get("ready"):
        return ["REPL 没起来（ConPTY 没挂上或启动失败）"]
    if not s.get("baseline"):
        fails.append("基线求值失败：`my $keep = 99` / `say $keep` 没按预期输出")
    if not s.get("control_input_intr"):
        fails.append("对照失效：prompt 上按 Ctrl-C 没有出现「已中断当前输入」")
    if not s.get("control_no_eval_intr"):
        fails.append("对照失效：没在求值却说「已中断当前求值」，说明文案判定不可信")
    if not s.get("cell_started"):
        fails.append("`note 'SPIN'` 没出现：这一格根本没开始，Ctrl-C 测不到求值中断")
    if not s.get("spinning"):
        fails.append("`loop { }` 期间 REPL 进程已退出，无法观察中断")
    if not s.get("alive_after_ctrlc"):
        fails.append("Ctrl-C 后 REPL 进程死了（父进程没接住信号）")
    if not s.get("prompt_back"):
        fails.append("Ctrl-C 后 prompt 没回来")
    if s.get("says_crashed") and not s.get("says_interrupted"):
        fails.append("归因退化成「引擎进程已退出」：Client 的 SIGINT handler 没抢到信号")
    if s.get("says_input_intr") and not s.get("says_interrupted"):
        fails.append("Ctrl-C 被行编辑器当成「输入中断」吃掉了：信号没进到求值层")
    if not s.get("says_interrupted"):
        fails.append("输出里没有「已中断当前求值」")
    if not s.get("state_survived"):
        fails.append("中断后 $keep 没恢复（快照恢复没走通）")
    return fails


def relaunch_under_winpty():
    winpty = shutil.which("winpty")
    if not winpty:
        print("SKIP: 当前进程没有控制台，且找不到 winpty（ConPTY 属性不会生效）")
        return 2
    fd, path = tempfile.mkstemp(prefix="rakuish-winctrl-", suffix=".json")
    os.close(fd)
    env = dict(os.environ, **{RELAUNCH_ENV: "1", VERDICT_ENV: path})
    try:
        subprocess.run([winpty, "-Xallow-non-tty", sys.executable,
                        os.path.abspath(__file__)], cwd=ROOT, env=env)
        with open(path, encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return 2
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def check(as_json=False):
    if not sys.platform.startswith("win"):
        print("SKIP: 仅 Windows")
        return 2
    if not os.path.exists(RAKU):
        print("SKIP: 找不到 raku: %s" % RAKU)
        return 2
    if not has_console():
        if os.environ.get(RELAUNCH_ENV):
            print("SKIP: 已经在 winpty 下仍然拿不到控制台")
            return 2
        return relaunch_under_winpty()

    res = run_scenario()
    fails = decide(res)
    res2 = run_tty_exec()
    fails2 = decide_tty_exec(res2)
    fails += fails2
    if as_json:
        print(json.dumps({"result": res, "result_tty": res2,
                          "fails": fails}, ensure_ascii=False, indent=2))
    else:
        s = res.get("steps", {})
        print("== Windows 真控制台：求值期间 Ctrl-C ==")
        for k in ("ready", "baseline", "control_input_intr", "control_no_eval_intr",
                  "cell_started", "spinning", "alive_after_ctrlc",
                  "says_interrupted", "says_crashed", "says_input_intr",
                  "prompt_back", "state_survived"):
            print("  %-18s %s" % (k, s.get(k)))
        print("  exit=%s" % res.get("exit"))
        if fails:
            for f in fails:
                print("FAIL: " + f)
        else:
            print("PASS: 场景一（归因/存活/快照恢复）+ 场景二（tty-exec 信号归属）")
        print("== Windows 真控制台：! --tty 期间 Ctrl-C ==")
        for k in ("ready", "first_eval", "nested_ready", "child_sigint",
                  "host_alive", "prompt_back", "next_eval", "clean_exit"):
            print("  %-18s %s" % (k, res2.get("steps", {}).get(k)))
        print("  exit=%s" % res2.get("exit"))
        print("--- 场景二输出 ---")
        print(res2.get("segment", ""))
        print("--- 场景一中断前后 ---")
        print(res.get("segment", ""))
    return 0 if not fails else 1


def main():
    as_json = "--json" in sys.argv
    rc = check(as_json)
    verdict = os.environ.get(VERDICT_ENV)
    if verdict:
        try:
            with open(verdict, "w", encoding="utf-8") as f:
                f.write(str(rc))
        except OSError:
            pass
    return rc


if __name__ == "__main__":
    sys.exit(main())
