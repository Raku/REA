unit module Rakuish::CLI;

# Rakuish 命令行入口的实现（0.106.1）。bin/rakuish 只负责加 lib 路径、
# require 本模块并调用 run()，这样入口脚本保持极小、本模块走 Rakudo
# 预编译缓存；`--version` / `-e` 不再为每次启动重编译 700 行入口。
# 各模式的模块仍在分支里 require，见 run()。
#
# 注意：模块内部的 `Rakuish::...` 是相对当前包解析的；只有在编译期
# `use` 过对应模块，全名才等于全局名。这里把入口会用到的模块统一 use
# 一次（模块本身走预编译缓存），否则运行期 require 后再写全名会变成
# `Rakuish::CLI::Rakuish::...`（实测）。
use Rakuish::REPL::Session;
use Rakuish::REPL::Chrome;
use Rakuish::REPL::Shell;
use Rakuish::REPL::Keymap;
use Rakuish::Kernel;
use Rakuish::Kernel::Factory;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;
use Rakuish::Result;
use Rakuish::Sys::Console;
use Rakuish::Sys::Term;
use Rakuish::Data::Pager;
use Rakuish::Audit;


# 0.106.1：入口按模式**懒加载**。原来这些 `use` 在编译期就会把行编辑器、
# 补全、分页、引擎客户端全部装进来 —— `rakuish --version` 也要 1.2s，
# `-e '1+1'` 1.35s，而真正求值只占几十毫秒。现在只有交互式 REPL 才
# require 前端模块；`-e` / 脚本 / `--version` 各取所需。
# 注意：这里不能写 `use`（编译期），必须是方法/分支里的 `require`。

# 0.98.2：退出后的残留线程消解（linger guard，POSIX-only）。
#
# 现象：退出调用完成后，行编辑器的输入解析线程偶发卡在 9p 文件 RPC
# （WSL /mnt/c 检出）里，进程最后一步「变 zombie」迟迟完不成 —— 外部
# waitpid 不返回，t/30 契约 5（干净退出 rc=0）因此挂住。逐帧插桩证明
# 所有收尾（END 块、history 落盘、VM teardown）都已完成、退出码也已按
# exit(N) 记账；只是残留线程咽不下最后一口气。外部 kill -9 实测 0.1s
# 收割，且 waitpid 报告的仍是 exit(N) 的退出码（不是信号码）—— 因为
# do_exit 记账在前。对输入时序极敏感（换一个轮询写法就能翻转）。
#
# 处置：退出前起一个看门狗子进程，0.5s 后核验「我是否还是它的父进程」：
# 不是 → 进程已正常回收，什么都不做；是 → kill -9 消解残留线程。
# 正常路径只多一次 sh spawn（毫秒级），退出码语义不变；Windows 无此现象。
# 详见 docs/PROBE-2026-11-17-exit-teardown-9p.md。
sub arm-linger-guard(--> Nil) {
    return if $*DISTRO.is-win;
    my Str $script = q:to/SH/;
        trap '' HUP
        PP=$PPID
        sleep 0.5
        CUR=$(ps -o ppid= -p $$ 2>/dev/null | tr -d ' ')
        [ "$CUR" = "$PP" ] && kill -9 $PP 2>/dev/null
        exit 0
        SH
    try {
        my $wd = Proc::Async.new('sh', '-c', $script);
        $wd.stdout.tap(-> | {});
        $wd.stderr.tap(-> | {});
        $wd.start;
        True;
    };
    Nil
}

my constant FALLBACK_VERSION = '0.106.2';   # 与 META6.json 同步（t/51 守护）

# 0.80.0：**默认开启**的统一审计。落盘路径按
#   RAKUISH_AUDIT 环境变量 → $*HOME/.rakuish/audit.jsonl → 纯内存（都不可用时）
# 取；RAKUISH_NO_AUDIT 可整体关闭。落盘失败只退化为内存，绝不弄崩 REPL。
# 懒初始化：--help / --version 不该为了打印说明就去建目录。
my $audit;
sub default-audit() {
    require ::("Rakuish")::Audit;
    my Str $p = (%*ENV<RAKUISH_AUDIT> // '').Str;
    unless $p.chars {
        my $home = try { $*HOME };
        if $home.defined {
            my $d = $home.add('.rakuish');
            try { $d.mkdir unless $d.e };
            $p = $d.add('audit.jsonl').Str;
        }
    }
    ::("Rakuish")::Audit.new(:path($p), :default-origin<human>,
        :enabled(!(%*ENV<RAKUISH_NO_AUDIT> // '').Str.chars));
}
sub shared-audit() { $audit //= default-audit() }

# 注意：不要用 $?FILE.IO.dirname —— 它在 Windows 上返回 Str 且**丢掉盘符**
# （C:/Users/... → /Users/...），从其它盘调用时会指到错误位置。
sub project-root(--> IO::Path) { $?FILE.IO.parent.parent.parent }

sub meta-version(--> Str) {
    my $f = project-root().add('META6.json');
    if $f.e {
        my $t = try { $f.slurp };
        if $t.defined && $t ~~ /'"version"' \s* ':' \s* '"' (<-["]>+) '"'/ {
            return $0.Str;
        }
    }
    my $v = try { $?DISTRIBUTION.meta<version> };
    return $v.Str if $v.defined && $v.Str.chars;
    FALLBACK_VERSION;
}

# 0.90.0 / ADR-0025：启动文件路径。只对交互式 REPL 生效 —— `-e` / 脚本
# 必须保持可重复，不能被用户 HOME 里的 rc 影响。
sub rc-path(--> Str) {
    return '' if (%*ENV<RAKUISH_NO_RC> // '').Str.chars;
    my Str $p = (%*ENV<RAKUISH_RC> // '').Str;
    unless $p.chars {
        my $home = try { $*HOME };
        # 不用 `~/.rakuishrc`：v2 曾把 KEY=VALUE 配置写在那里
        # （color=true / auto-shell=true …），v3 把同一路径当 Raku 源码执行
        # 会在每个会话开头刷一屏「Undeclared routine」。改到自己的目录下，
        # 旧文件原样保留；想继续用它就显式 RAKUISH_RC=~/.rakuishrc（并改成 Raku）。
        $p = $home.add('.rakuish').add('rc.raku').Str if $home.defined;
    }
    # 相对路径按**父进程**的启动目录解析：引擎 cwd 是它自己的进程目录，
    # 而 rc 的「相对」不应该随钩子里的 cd 漂移。
    $p = $p.IO.absolute.Str if $p.chars;
    $p;
}

sub help-text(--> Str) {
    q:to/END/;
    Rakuish · Raku 原生命令与脚本环境（API v3）

    用法
      rakuish                       启动 REPL
      rakuish -e '1 + 1'            求值一段 Raku 后退出
      rakuish foo.raku [args...]    跑 Raku 脚本（已预加载 DSL）
      rakuish --help / --version    本说明 / 版本号

    输入（只有两类）
      ! git status             argv 分词 → sys.exec（| > $ * && 原样当参数）
      其它全部                 Raku 表达式（%foo<a> 就是哈希访问，不是魔法命令）
      没有 %magic、没有 auto-shell、没有反引号 shellq、没有 bash 语法

    外部命令的输出与超时（0.90）
      终端里 ! cmd 边跑边出；管道/脚本仍「收完再出」，保持 Result.out 契约
      ! --capture cmd ...      强制收完再显示
      ! --timeout-ms N cmd ... 单次超时（毫秒；0 = 不超时）
      ! --no-timeout cmd ...   同上，显式关掉默认 30s
      ! --tty cmd ...          交给真终端直通（无捕获、无超时）

    REPL 对象与短命令（表达式里直接可用）
      sys.read('a.txt') / sys.ls('docs') / sys.exec('git','status')
      repl.history / repl.config<key> / repl.trace = True
      registry.names / registry.get('read').spec
      ls / read / write / append / stat / rm / cp / mv / mkdir / glob
      exec / cd / pwd / env / timed { ... } / bench({ ... }) / recent(7, 'md') / help()
      perf [N] 查看每格耗时（Shell 薄层命令，数据来自会话而非文本魔法）

    审计（0.80）
      每次操作一条结构化记录：origin / kind / action / ok / code / 耗时
      源码只记指纹与字节数，不记源码文本、token、文件内容、SQL 全文
      默认落盘 $*HOME/.rakuish/audit.jsonl（10k 条 / 10MB 轮转）
      覆盖 REPL、-e、脚本、失败格、被策略拒绝的请求
      RAKUISH_AUDIT=PATH 改路径 · RAKUISH_NO_AUDIT=1 关闭
      `log` 命令是人类可读的会话抄本，与这份审计互不影响

    引擎与崩溃恢复（0.83 / 0.84）
      求值引擎跑在独立的 raku 子进程里：exit / 段错误 / while 1{} 只带走引擎
      崩溃后自动重启，并从快照恢复「声明 + 纯值」
      能恢复：变量（标量/集合/时间/路径/枚举）、class/sub/role/grammar、简单对象
      不能恢复：数据库连接、文件句柄、闭包、超过 1MB 的值（会列出来并置为 Any）
      语句不重放：write / rm 这类副作用不会因为恢复再执行一次
      快照默认 $*HOME/.rakuish/session-<cwd指纹>.json
      RAKUISH_SNAPSHOT=PATH 改路径 · RAKUISH_NO_SNAPSHOT=1 关闭（同时停读停写）
      RAKUISH_SNAPSHOT_MAX=N 单值上限字符数（默认 1000000；0/off/none=不限制）

    启动文件与选项（0.90）
      $*HOME/.rakuish/rc.raku  引擎启动后逐格执行（变量 / use / alias / set 都能写）
      RAKUISH_RC=PATH 改路径 · RAKUISH_NO_RC=1 关闭；崩溃重启后会重新执行
      repl.prompt = -> { "..." }   可编程 prompt，返回什么就显示什么
      set                      列出选项；set -o NAME 开 / set +o NAME 关
        errexit / histexpand / noglob / noexpand / xtrace
      set -o noglob            薄层不展开 * ?；set +o noexpand 恢复 $NAME 展开

    中断（0.85）
      求值中按 Ctrl-C：引擎被 kill 并重启，从快照恢复后继续
      提示是「已中断当前求值」，不会被说成引擎故障；perf 仍记录该格耗时
      Linux / WSL 与 Windows 均已在真终端验证（0.86）：tools/ctrl-c-*.py

    快捷键（TTY 宿主）
      Up / Down 历史 · Ctrl-R 循环历史检索 · Ctrl-C 中断输入（不退出） · Ctrl-D 退出
      Tab 补全命令名 / 路径 / 命令选项 · ShiftTab 列出候选 · → 接受灰字建议

    界面与计时（0.62）
      banner / prompt 显示时间、cwd、git 分支、格号与上格耗时
      timed { ... } / bench({ ... }, :repeat(5)) / perf [N] 查看耗时历史
      config set color auto|on|off · clock on|off · timing on|off
      config set git on|off · prompt-style full|compact|plain · banner on|off
      NO_COLOR 强制关色；FORCE_COLOR=1 强制开；管道下自动纯文本

    会话工具（0.75）
      doc <命令名|Raku 名字>   命令用法或类型内省（零 EVAL，不执行参数里的代码）
      log [start [路径]|stop|show]   会话日志，逐格记录输入与结果（纯文本）
      pushd / popd / dirs 目录栈 · bookmark add|list|go|del 目录书签

    声明与 glob（0.65）
      class Box { ... } 单独成格后，后续格可直接用 Box.new(...)
      role / grammar 同理；sub / use 也跨格；混合语句格不缓存
      glob('{a,{b,c}}.txt') 嵌套 brace · glob('\{a,b\}.txt') 转义字面量
      Shell 薄层文件名参数只展开 * ?；边界见 docs/MANUAL.md / SPEC V-153

    交互体验（0.66，ADR-0003）
      config set edit-mode emacs|vi|helix  行编辑键位 / 模态（默认 emacs）
      config set vi-start insert|normal   每行起始模式（vi/helix 下）
      config set hints on|off             上下文提示（默认 on，同一首词只提示一次）
      config set plugins on|off           允许加载本地 Raku 插件（默认 off）
      Esc 进 normal · i/a/A/I/o/O 进 insert · h/l/w/b/0/$/x/dd/u · j/k 翻历史
      hint [输入行] 查询提示 · plugin list|load PATH|unload NAME|info NAME
      插件 = 返回 Command 对象（或 List）的本地 .rakumod/.raku；加载即执行本地代码

    分页（0.92，ADR-0027）
      explore 在交互式 REPL 里也分页了：Enter 下一页 / q 退出 / Ctrl-C 停下
      RAKUISH_PAGER=auto      默认，只给 explore 分页
      RAKUISH_PAGER=always    任何超过一页的结果都分页（cat 大文件也会停）
      RAKUISH_PAGER=never     一律不分页

    数据工作台（0.67 / 0.68，ADR-0004 / ADR-0005）
      my $c = $db.cursor('select ...')  惰性分批：batches / take / close
      open-data('x.csv', :allow-external)  由 DuckDB 推断 int/num（默认仍走 Sys）
      save-data('x.csv', $t, :allow-external)  COPY ... FORMAT CSV, HEADER
      open-db(...) 注册当前会话 Engine；Tab 在 SQL 字符串里补表名 / 列名

    数据剖析与方言（0.69，ADR-0006）
      describe [表名]            列摘要 Table（name/type/nullable/non_null/…）
      describe($t) / describe('表名')   Raku 值 API，可继续 .where / .to-json
      open-data('x.csv', :allow-external, :csv-options({ delimiter => ';' }))
        CSV 方言：delimiter/quote/escape/nullstr/header/skip/all-varchar
        读选项全部 ? 绑定；写出仅支持 delimiter/quote/escape/header/nullstr
      Tab 支持表别名前缀（s.am → s.amount）与关键字大小写（SEL → SELECT）
      不做 SQL AST 解析；边界见 docs/MANUAL.md / SPEC V-162…165

    结构化管道（0.91，ADR-0026）
      stream('a\nb')                 文本 → 惰性记录流（n / line 两列）
      stream($r) / stream($t) / stream($cursor)
        $r = cmd-result('! find . -name "*.raku"')  → 三行加一个 Result
      :format<lines|csv|tsv|json|jsonl|pattern>，pattern 用 :pattern(正则)
      阶段：.where .select .drop .map .add-column .limit .skip（惰性）
            .sort-by .unique .count-by .group-by（物化，要看完）
      出口：.table .text .json .csv .lines .count .sum .mean .min .max .each
      喂回子进程：stream(...).exec('wc', '-l', :format<csv>)  边算边写 stdin
        （子进程提前退出时上游立刻停；Result.value<in-early> 可查）
      两条流：.zip(另一条) / .join(另一条, :on<列>, :how<inner|left|right|outer>)
      收拢两条流：.interleave(另一条, :shortest) / .append(另一条)  不改列名
      边流边存：.tee('out.csv')  写多少取决于下游读多少（limit 放上游）
      没有 | 也没有 |>：管道就是方法链（| 属 V-901，|> 在 Raku 里不可定义）

    嵌套 REPL / 交互式子进程（0.70，ADR-0007）
      ! --tty rakupp          或 -t：把 TTY 直通给子进程，无 30s 超时
      tty-exec('rakupp')      Raku 原生入口（表达式里可用）
      ! -- --tty foo         -- 之后是字面 argv，不解析元选项
      输出实时可见但不进 _ / Out[n]；非 TTY 明确拒绝（管道/脚本请用 exec）
      普通 ! 命令仍受 30s 超时与输出捕获约束，超时会给提示

    后台作业（0.96，ADR-0031，POSIX-only）
      bg-exec('cmd', ...)     起后台作业，Result.value<job> 是 id
      bg-jobs()               列作业（Table）；fg(id) / bg(id) 切换前后台
      Ctrl-Z 停住时 fg 归还前台不卡死；与 spawn()/jobs()（捕获式后台）不同

    输入中断与求值中断（0.71 / 0.85，ADR-0008 / ADR-0023）
      Ctrl-C 中断当前输入 / 清空续行缓冲，重画 prompt（不退出、不产生空 Out）
      求值中按 Ctrl-C：杀掉并重启引擎，从快照恢复（op=interrupted / code=130）
      Ctrl-D / exit 才退出会话
      $db.query(q[select * from sales where region = 'east' and am])  Tab 补 amount
      query(sql => '...') / query(:sql('...'))  具名参数也进 SQL 补全
      仍不做 SQL AST / qq / heredoc；边界见 docs/MANUAL.md / SPEC V-168…169

    退出：Ctrl-D 或输入 exit / exit N；管道 EOF 自动结束。
    END
}

sub run-start-hooks($sess --> Nil) {
    for $sess.run-hooks('start') -> $r {
        print $r.out if $r.out.chars;
        $*ERR.print($r.err) if $r.err.chars;
        unless $r.ok {
            $*ERR.say: 'rakuish: 启动 hook 失败，停止启动';
            exit 1;
        }
    }
}


my Bool $console-fixed = False;
sub setup-console() {
    require Rakuish::Sys::Console;
    $console-fixed = ensure-utf8-console(:interactive(so $*IN.t));
}
END {
    if $console-fixed {
        require Rakuish::Sys::Console;
        restore-console();
    }
}


our sub run(--> Nil) {
    my @a = @*ARGS;

if @a.elems {
    given @a[0] {
        when '--help' | '-h' {
            say "rakuish " ~ meta-version();
            say help-text();
            exit 0;
        }
        when '--version' | '-V' {
            say 'rakuish ' ~ meta-version();
            exit 0;
        }
        when '-e' {
            unless @a.elems >= 2 {
                $*ERR.say: 'rakuish: -e 后面要跟一段 Raku 代码';
                exit 2;
            }
            setup-console();
            require ::("Rakuish")::REPL::Session;
            require Rakuish::REPL::Chrome;
            require Rakuish::Sys::Term;
            my $sess = ::("Rakuish")::REPL::Session.new(
                :color(color-mode('auto',
                    :tty(stdout-is-console()))));
            # 0.90.0：stdout 是终端时 `!` 边跑边出；管道 / 测试保持「收完再出」，
            # 免得把 `Result.out` 契约和断言一起改掉。
            $sess.set-stream-out(stdout-is-console());
            run-start-hooks($sess);
            my $kernel = make-kernel($sess, shared-audit());
            my $r = $kernel.execute(
                make-request(@a[1], :origin<human>));
            # `-e` 等于跑一个 REPL 格，默认仍打印 `Out[1] = ...`。
            # 唯一例外：值恰好是 `Bool::True` 时不打印那行 —— Raku 里 say / print /
            # note 都返回 True，渲染它只会给 `-e 'say 1'` 添噪声。
            # 注意要**保留**捕获到的 stdout（不然 `-e 'say 1'` 会什么都不输出）；
            # 确实想看 True 就写 `-e 'True.raku'` 或 `-e 'say True'`。
            if $r.ok && $r.value ~~ Bool && $r.value {
                print $r.out if $r.out.chars;
            }
            else {
                my $text = $sess.render($r);
                if $text.chars {
                    $r.no-newline ?? print($text) !! say($text);
                }
            }
            exit($r.ok ?? 0 !! 1);
        }
        default {
            if @a[0].starts-with('-') {
                $*ERR.say: "rakuish: 未知选项 {@a[0]}（用 --help 查看用法）";
                exit 2;
            }
            # 脚本就是 Raku 脚本：整份源码作为一个 cell 求值，
            # 与 REPL 共用同一套词法环境（sys / repl / registry + DSL），
            # 不另建解释器、不解析 shebang、不模拟 %magic。
            my $file = @a[0].IO;
            unless $file.e {
                $*ERR.say: "rakuish: 找不到脚本 {@a[0]}";
                exit 2;
            }
            @*ARGS = @a.skip(1);
            setup-console();
            require ::("Rakuish")::REPL::Session;
            require Rakuish::REPL::Chrome;
            require Rakuish::Sys::Term;
            my $sess = ::("Rakuish")::REPL::Session.new(
                :color(color-mode('auto',
                    :tty(stdout-is-console()))));
            # 0.90.0：stdout 是终端时 `!` 边跑边出；管道 / 测试保持「收完再出」，
            # 免得把 `Result.out` 契约和断言一起改掉。
            $sess.set-stream-out(stdout-is-console());
            run-start-hooks($sess);
            my $kernel = make-kernel($sess, shared-audit());
            my $r = $kernel.execute(
                make-request($file.slurp, :origin<script>));
            if $r.op eq 'more' {
                $*ERR.say: "rakuish: 脚本 {@a[0]} 存在未闭合结构，拒绝静默不执行";
                exit 2;
            }
            # 脚本模式不打印 Out[n]（那是 REPL 的格子标签）：
            # stdout 原样透传，stderr 原样透传，值不另作展示。
            print $r.out if $r.out.chars;
            $*ERR.print($r.err) if $r.err.chars;
            exit($r.ok ?? 0 !! 1);
        }
    }
}

# ── 交互式 REPL ─────────────────────────────────────────────────────
# 只有走到这里才装前端：行编辑器、补全、分页、引擎客户端。
setup-console();
require Rakuish::Sys::Term;
require ::("Rakuish")::REPL::Session;
require Rakuish::REPL::Chrome;
require Rakuish::REPL::Shell;    # 0.105.0：`!` 的 PATH 补全预热
require Rakuish::REPL::Keymap;
require Rakuish::Eval;           # 0.83：引擎子进程客户端（ADR-0021）
require ::("Rakuish")::Eval::Proxy;    # 0.83：引擎的 Session 形状门面
require Rakuish::Result;         # Proxy 的 TTY 回传需要真正的 Result
require ::("Rakuish")::Data::Pager;    # 0.92：前端分页（ADR-0027）
require ::("Rakuish")::Audit;          # 0.80：每次操作一条的统一审计

# 管道下不打印 banner / prompt，保证 stdout 只有求值结果（SPEC V-116）。
my Bool $tty     = so try { $*IN.t };
my Bool $tty-out = stdout-is-console();

# 0.83.0 / ADR-0021：交互式 REPL 的**求值引擎跑在子进程**里。
#
# 为什么：Rakudo 上 `EVAL` 与宿主同进程，用户代码 `exit` / 段错误 /
# `while 1 {}` 都会把整个 REPL 带走（SIGINT 打不断纯表达式循环，实测）。
# 引擎独立成进程后，死的是引擎，行编辑 / 渲染 / 审计仍在父进程。
#
# 管道 / `-e` / 脚本**不走** worker：它们没有「会话要继续」这回事，
# 崩了就崩了，多一层进程只是多一处出错点。所以这里按 `$tty` 分流。
my $engine;
my $sess;
if $tty {
    $engine = ::("Rakuish")::Eval::Client.new(
        :lib(project-root().add('lib')),
        # `! --tty` 必须由持有终端的父进程执行：引擎的 stdio 是协议管道。
        :tty-exec(-> Str $exe, @argv {
            {
                CATCH { default {
                    return Result.new(
                        :!ok, :code(127), :op<tty-exec>, :err(.message));
                } }
                $sess.sys.tty-exec($exe, |@argv);
            }
        }),
        # 0.96.0 / ADR-0031：作业控制在持有真终端 + 作业表的父进程执行。
        # 与 tty-exec 同一个 CATCH 形状：hook 不抛异常，异常收敛成 Result/Table。
        # 0.99.0：should-stop 把「Ctrl-C 停跟随」的判据带给 tail-follow
        # （Eval::Client 的 job-interactive 期间信号置 job-stop）。
        :job-dispatch(-> Str $op, @args {
            {
                CATCH { default {
                    return Result.new(
                        :!ok, :code(127), :op($op), :err(.message));
                } }
                $sess.sys.job-op($op, |@args,
                                 :should-stop(-> { $engine.job-stop }));
            }
        }),
    );
    $engine.start;
    # 0.90.0：rc 路径要在建 Proxy 之前算好 —— 崩溃重启时 Proxy 会重新执行它。
    my Str $rc = rc-path();
    $sess = ::("Rakuish")::Eval::Proxy.new(:client($engine), :rc-path($rc));
    # 启动 hook 跑在引擎里，输出随 ready 帧回来。
    print $engine.startup-out if $engine.startup-out.chars;
    $*ERR.print($engine.startup-err) if $engine.startup-err.chars;
    # 0.90.0 / ADR-0025：启动文件在 hook 之后执行，所以 rc 能覆盖 hook 里的
    # 设置与别名。rc 的输出照常显示，但**不占格号**（Session.run-rc 会清零）。
    if $rc.chars && $rc.IO.e {
        my $rc-out = try { $sess.run-rc($rc) };
        if $rc-out.defined {
            print $rc-out<out> if ($rc-out<out> // '').Str.chars;
            $*ERR.print($rc-out<err>) if ($rc-out<err> // '').Str.chars;
        }
        else {
            $*ERR.say: "rakuish: 启动文件执行失败（{$rc}）";
        }
    }
    END { $engine.shutdown if $engine.defined }
}
else {
    $sess = ::("Rakuish")::REPL::Session.new(
        :color(color-mode('auto', :tty($tty-out))));
    run-start-hooks($sess);
}
my $kernel = make-kernel($sess, shared-audit());

# 交互式行编辑：上下翻历史、Ctrl-R 循环检索、光标编辑、历史落盘。
# 管道/脚本仍走 $*IN.get，避免把控制序列混进 stdout。
my $cli;
my $history-file;
my Str $edit-mode = ($sess.config<edit-mode> // 'emacs').Str.lc;
my Str $vi-start  = ($sess.config<vi-start>  // 'insert').Str.lc;
# 闭包（具名 sub 捕获不到这里的 $sess）：vi/helix 走 Keymap 的子类行编辑器，
# 构造失败由 make-cli 自动回退到原生 CLIInput。
my &build-cli = -> Str $style --> Any {
    make-cli(
        :$style,
        :start-mode($vi-start),
        :get-completions(-> $line, $pos { $sess.completions($line, $pos) }),
        :get-marks(-> $line { $sess.error-marks($line) }),
    )
};
if $tty {
    $cli = build-cli($edit-mode);
    $history-file = try { $*HOME.add('.rakuish-history') };
    if $cli.defined && $history-file.defined && $history-file.e {
        try { $cli.load-history($history-file.Str) };
    }
}

# 0.76 / ADR-0013：TTY 前端不再直接调 `Session.eval-line`，一律经 Kernel。
# `local` profile 与 0.75 的语义一一对应：允许源码、root 不限制（REPL 是
# 可信本地环境）。0.82.0 起 Policy 只剩真有执行点的字段（ADR-0020）：
# 进程 / 写权限不再声明式开关，因为本地 shell 本来就不拦。

# 展示配置都是扁平字符串键；每格重新读取，config set 当格即生效。
# 用闭包而不是具名 sub —— 具名 sub 无法捕获这里的词法 $sess。
my &conf = -> Str $key, Str $default --> Str {
    ($sess.config{$key} // $default).Str
};
my &on = -> Str $key --> Bool { conf($key, 'on').lc ne 'off' };

if $tty && on('banner') {
    print banner-text(
        :version(meta-version()),
        :cwd($sess.sys.cwd.Str),
        :editor($cli.defined ?? 'LineEditor' !! '基础输入'),
        :mode($edit-mode),
        :plugins($sess.plugin-names.elems.Str),
        :color(color-mode(conf('color', 'auto'), :tty($tty-out))),
    );
}

my Bool $last-ok = True;
my Int  $last-code = 0;
my      $last-elapsed;
my Bool $continuing = False;
my Str  $hint-text = '';
my Int  $term-rows = 0;      # 0.92：每格更新，分页按它算每页行数

# 0.92.0 / ADR-0027：前端分页。
# 引擎的 stdout 是协议管道，它自己没法分页（0.89 起 `explore` 在 worker 模式下
# 从不分页）；0.92 把分页搬到父进程：引擎照旧把整份文本放 `Result.out`，
# 父进程按终端高度切页、用真正的 stdin 等一个回车。
# 只对 `explore`（RAKUISH_PAGER=always 时扩展到任何超过一页的结果）——
# `cat` 大文件应该是「全给」，分页该是显式请求。
sub page-result($r, Str $text, Bool :$tty, Int :$rows --> Bool) {
    return False unless $text.chars;
    require ::("Rakuish")::Data::Pager;
    my Str $mode = ::("Rakuish")::Data::Pager.mode(%*ENV<RAKUISH_PAGER> // '');
    my $pager = ::("Rakuish")::Data::Pager.new;
    return False unless $pager.wants-page(
        :op($r.op), :lines($text.lines.elems),
        :height($rows), :mode($mode), :tty($tty));
    my &read-line = -> { $*OUT.flush; try { $*IN.get } };
    my &emit-line = -> Str $line { say $line };
    my Int $size = $pager.size-for-height($rows);
    $pager.paginate($text, &read-line, &emit-line, :$size);
    True;
}

# 0.105.0：PATH 里外部程序名的首次扫描在本机实测约 1.6 s（100+ 目录）。
# 启动 REPL 前后台预热：用户敲到第一个 `! ...<Tab>` 时通常已经缓存好了。
# `start` 不阻塞进程退出（实测），失败也无所谓（补全会再试一次）。
start { try { path-executables() } };

loop {
    my Bool $color   = color-mode(conf('color', 'auto'), :tty($tty-out));
    # 0.74.0 / ADR-0011：结果渲染层与输入行高亮的开关都要跟着 config 走，
    # 且当格生效（`config set color off` 之后下一格就该没有颜色）。
    $sess.set-color($color);
    $sess.set-tty($tty-out) if $sess.^can('set-tty');
    # 0.90.0 / ADR-0024：`!` 的流式判据是**父进程**的 stdout 是不是终端。
    # 引擎自己的 live-out 恒 False（协议管道），不能拿来判。
    $sess.set-stream-out($tty-out) if $sess.^can('set-stream-out');
    # 0.88.0：尺寸也是终端事实，每格查一次（ioctl/CSBI 是微秒级），
    # 这样 `resize` 之后下一格就按新宽度排版。
    if $sess.^can('set-size') {
        my %sz = $tty-out ?? term-size() !! %(cols => 0, rows => 0);
        $sess.set-size(:width(%sz<cols>.Int), :height(%sz<rows>.Int));
        $term-rows = %sz<rows>.Int if %sz<rows>.Int > 0;
    }
    set-highlight($color);

    # config set edit-mode vi|helix|emacs 当格生效：重建行编辑器并迁移历史。
    if $tty {
        my Str $want = conf('edit-mode', 'emacs').lc;
        if $want ne $edit-mode {
            if $cli.defined && $history-file.defined {
                try { $cli.save-history($history-file.Str) };
            }
            $edit-mode = $want;
            $cli = build-cli($edit-mode);
            if $cli.defined && $history-file.defined && $history-file.e {
                try { $cli.load-history($history-file.Str) };
            }
        }
    }

    # hints 是「上一格给下一格的提示」；管道 / 非 TTY 完全不输出。
    if $tty && on('hints') && $hint-text.chars {
        my Str $hint-line = '  · ' ~ $hint-text;
        say $color ?? "\e[90m" ~ $hint-line ~ "\e[0m" !! $hint-line;
    }

    my Str  $cwd     = $sess.sys.cwd.Str;
    my Str  $branch  = ($tty && on('git'))
        ?? git-branch($sess.sys, $sess.sys.cwd) !! '';
    my Str  $mode-badge = $edit-mode eq 'emacs'
        ?? '' !! $edit-mode.uc ~ '·' ~ vi-state().mode-label;
    # 0.90.0 / ADR-0025：rc 里 `repl.prompt = -> {...}` 定义的 prompt。
    # 每格问一次引擎，时间 / git 才是当下的；返回空串就用默认样式。
    my Str  $custom-prompt = '';
    if $tty && !$continuing && $sess.^can('prompt-text') {
        my $got = try { $sess.prompt-text };
        $custom-prompt = $got.defined && $got ~~ Str ?? $got !! '';
    }
    my Str  $prompt  = $custom-prompt.chars
        ?? $custom-prompt
        !! prompt-text(
            :$cwd,
            :index($sess.index),
            :elapsed($last-elapsed),
            :ok($last-ok), :code($last-code),
            :$branch, :$color,
            :clock(on('clock')), :timing(on('timing')),
            :$continuing, :style(conf('prompt-style', 'full')),
            :mode($mode-badge),
        );

    my $line;
    if $tty && $cli.defined {
        my $in = try { $cli.prompt($prompt) };
        if $! {
            # 行编辑器在异常终端上不可用时退回普通行输入，不阻塞用户。
            $cli = Nil;
            print $prompt;
            $line = $*IN.get;
            $! = Nil;
        }
        elsif !$in.defined {
            last;
        }
        else {
            $line = $in;
        }
    }
    else {
        print $prompt if $tty;
        $line = $*IN.get;
    }
    last unless $line.defined;

    # 0.71 / ADR-0008 §3.1：Ctrl-C 只中断当前输入，不退出宿主 REPL。
    # 复用 Session.handle-key 的值 API 清掉续行缓冲；不 eval、不进历史、
    # 不产生空 Out[n] 格。原生 CLIInput 回退路径没有 take-interrupt，
    # 语义保持 0.70 不变。
    if $cli.defined && $cli.^can('take-interrupt') && $cli.take-interrupt {
        $sess.handle-key('Ctrl-C');
        $continuing = False;
        $hint-text = '';
        say $color ?? "\e[90m  · 已中断当前输入（Ctrl-C）；Ctrl-D 退出\e[0m"
                   !! '  · 已中断当前输入（Ctrl-C）；Ctrl-D 退出';
        next;
    }
    $cli.add-history($line) if $cli.defined && $line.trim.chars;

    my Instant $t0 = now;
    my $r = $kernel.execute(
        make-request($line, :origin<human>));
    my Duration $dt = now - $t0;

    # 0.85.0 / ADR-0023：求值期间的 Ctrl-C 由引擎层接管（`op=interrupted`），
    # 但行编辑器同时也记了一个 take-interrupt 标志。不在这里清掉的话，
    # 它会在**下一轮**被当成「输入中断」执行 `next` —— 表现为「下一格输进去
    # 却没执行、只显示一行已中断」。0.84 之前这个错位一直存在。
    if $r.op eq 'interrupted' && $cli.defined && $cli.^can('take-interrupt') {
        $cli.take-interrupt;
        $sess.handle-key('Ctrl-C');
        $continuing = False;
        $hint-text  = '';
    }
    $sess.note-timing($dt, $line, $r.ok);
    $last-elapsed = $dt;
    $last-ok      = $r.ok;
    $last-code    = $r.code;
    $continuing   = $r.op eq 'more';
    $hint-text    = $sess.next-hint($line, $r);

    my $text = $sess.render($r);
    # 0.75.0 / ADR-0012 §5：唯一同时拿到「输入行 + Result + 渲染文本」的位置。
    # log-line 内部会剥掉 SGR，日志恒为纯文本。
    $sess.log-line($line, $r, $text);
    if $text.chars {
        # 分页自己打印；返回 False 时仍走原来的路径（观感与 0.91 完全一致）。
        unless page-result($r, $text, :tty($tty-out), :rows($term-rows)) {
            $r.no-newline ?? print($text) !! say($text);
        }
    }
    # 最常见的误用：把启动参数当 REPL 命令敲。这里不会为它开魔法分支
    # （输入一律按 Raku 求值），但值得给一句提示，省掉读栈回溯。
    if !$r.ok && $line.trim ~~ /^ '--' \w+ $/ {
        say '提示: --help / --version 是**启动参数**，要在 shell 里写 '
          ~ '`rakuish --help`；提示符里输入一律按 Raku 求值，所以 `--help` 被当成 `--` 运算符。';
    }
    last if $sess.exit-requested;
}
if $cli.defined && $history-file.defined {
    try { $cli.save-history($history-file.Str) };
}
arm-linger-guard();
exit $sess.exit-code;
}
