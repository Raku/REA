unit module Rakuish::Kernel::Factory;

# 0.106.1：入口改成运行时 require 后，`require Rakuish::Kernel` 拿到的是
# 模块桩（`Rakuish::Kernel` 与导出的 `Kernel` 类同名），不能 `.new` /
# 调不到 `execute`。这里用正常的 `use` 在一个**按需加载**的小模块里完成
# 导入，再以工厂函数的形式给入口用；`--version` / `--help` 不会加载它。

use Rakuish::Kernel;

our sub make-kernel($sess, $audit) is export {
    Kernel.new(:session($sess), :audit($audit));
}

our sub make-request(Str $src, Str :$origin = 'human') is export {
    Request.new(:kind<source>, :payload($src), :$origin);
}
