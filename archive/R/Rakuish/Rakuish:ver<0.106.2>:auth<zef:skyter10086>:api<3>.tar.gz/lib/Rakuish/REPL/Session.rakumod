unit class Rakuish::REPL::Session;

# Rakuish::REPL::Session —— API v3 的会话与求值器（ADR-0001 §2.3 / 设计 §5）。
#
# 输入只有两类，没有第三套语言：
#   · `!` 开头（第二个字符不是 = / ~）→ argv 便利入口，等价于 sys.exec(...)
#   · 其余全部（含 `%` 开头）        → Raku 表达式，直接 EVAL
#
# 明确**不做**的事（这是 Phase 3 的产品决策，别再加回来）：
#   · 没有 %magic 分流：`%STATE{...}` 就是 Raku 哈希访问（v2 的 %STORE / %RC 已删）；
#   · 没有 auto-shell：Raku 求值失败就是失败，不偷偷转交外部程序；
#   · 没有反引号 shellq / 管道 / 重定向 / 变量展开 / glob 展开；
#   · 求值器自带，不复用 v2 的 eval-cell（它内置 expand-backticks）。
#
# 原 %magic 的 REPL 状态由本对象承载，用户写 `repl.history` / `repl.config`
# / `repl.trace = True`；纯交互动作（历史回调、外部编辑、中断）走快捷键，
# 见 key-bindings() / handle-key()。本对象**不提供文件 / 进程的旁路**。

use Rakuish::Sys;
use Rakuish::Sys::Term;   # 0.98.2：stdout-is-console（Windows NUL 误判修正）
use Rakuish::Result;
use Rakuish::Command;
use Rakuish::DSL;
use Rakuish::Data::Table;
use Rakuish::Data::Stream;
use Rakuish::Data::Pager;
# 必须只加载、不导入：Rakuish::Data 也导出 open-data/save-data，但那是带
# $sys 的底层签名。若用 use 会覆盖 DSL 的同名导出，使 EVAL 里文档示例的
# open-data('x.csv') / save-data(...) 变成参数错误（0.69 修，V-165）。
need Rakuish::Data;
use Rakuish::REPL::Shell;
use Rakuish::REPL::Chrome;        # banner/prompt/耗时格式化（纯展示层）
use Rakuish::REPL::Keymap;        # Vi/Helix 模态与键位预设（ADR-0003）
use Rakuish::REPL::Highlight;     # 0.97：续行时把多行引号状态传给输入高亮器
use Rakuish::REPL::Hints;         # 上下文提示（纯函数）
use Rakuish::REPL::Plugins;       # 显式本地 Raku 插件
use Rakuish::REPL::SqlComplete;   # SQL 字符串上下文补全（ADR-0005，纯函数）
use Rakuish::REPL::Complete;      # 公共前缀 / suggest-suffix（0.100.0 / ADR-0034）
use Rakuish::Incomplete;          # 纯 Raku 多行续行，设计 §5.1 允许复用
use Rakuish::Audit;               # 0.84：快照路径用同一个 FNV 指纹
use Rakuish::Snapshot;            # 0.84：会话快照（ADR-0022）
use JSON::Fast;

my class CapturingOut {
    has @.buf is rw;
    method print(*@a) { @!buf.push(@a.map(*.Str).join); True }
    method say(*@a)   { @!buf.push(@a.map(*.Str).join ~ "\n"); True }
    method put(*@a)   { @!buf.push(@a.map(*.Str).join("\n") ~ "\n"); True }
    method flush()    { Nil }
    method nl-out()   { "\n" }
    method text()     { @!buf.join }
}

has Rakuish::Sys $.sys;
has CommandRegistry $.commands;
has Rakuish::REPL::Shell $.shell;
has PluginManager $.plugins;
has $.engine is rw;               # 当前会话数据引擎（open-db 注册，SQL 补全用）

# 0.83.0 / ADR-0021：引擎子进程模式下，`! --tty` 必须由**持有终端的父进程**
# 执行 —— worker 的 stdin/stdout 是管道，`Sys.tty-exec` 在里面只会报「无 TTY」。
# 注入这个 hook 后，`! --tty` 改走它；hook 负责一次完整往返并返回与
# `Sys.tty-exec` 同形状的 Result。未注入（默认）时行为与 0.82 完全一致。
has &.tty-handler is rw;

# 0.90.0 / ADR-0024：`!` 的流式输出。
#   · stream-out    = 本次会话要不要边跑边给用户看（由入口按 stdout 是否终端决定）
#   · chunk-handler = 引擎子进程用：把块写成协议帧（父进程负责真正打印）
# 两者都不在时完全退回 0.89 的「收完再显示」。
has Bool $.stream-out is rw = False;
has &.chunk-handler is rw;

# 0.90.0 / ADR-0025：`set -o` 的选项。每一个都必须有执行点，否则就是
# 一个「被存起来的布尔值」（V-211 同一条尺子）。
#   errexit     → 失败格请求退出（复用 strict）
#   xtrace      → 求值前把源码打到 stderr
#   noglob      → Shell 薄层不展开 * ?
#   noexpand    → Shell 薄层不展开 $NAME / ~
#   histexpand  → 是否认整行 !! / !$ / !n
has Bool $.xtrace     is rw = False;
has Bool $.noglob     is rw = False;
has Bool $.noexpand   is rw = False;
has Bool $.histexpand is rw = True;

# 0.90.0 / ADR-0025：可编程 prompt。rc 里写
#   repl.prompt = -> { "..." }
# 后每次取 prompt 都会调用它；返回空串 / Nil 则退回默认样式。
has &.prompt is rw;

method set-engine($e --> Nil) { $!engine = $e; Nil }

# 插件名单：前端只需要数量与名字，不必拿到 PluginManager 本身。
# Proxy（引擎子进程）也实现同名方法，两者形状一致。
method plugin-names(--> List) { $!plugins.names.List }

# ── 原 %magic 的 REPL 运行时状态（会话级，可读写）────────────────────
has @.history is rw;
has %.config  is rw;
has Bool $.trace is rw = False;
has Bool $.watch is rw = False;
has Bool $.perf  is rw = True;
# 0.74.0 / ADR-0011：结果渲染层的颜色开关，由入口按 Chrome::color-mode 传入。
# 默认 False 是刻意的 —— 忘记传参的调用点（测试、库内构造）一律退回纯文本，
# 绝不因为「代码路径没覆盖到」就给数据管道塞 ANSI。
has Bool $.color is rw = False;
# 0.87.0：**真实终端**是不是 TTY。0.83 起 REPL 跑在引擎子进程里，那里的
# `$*OUT` 是协议管道 —— `$*OUT.t` 恒为 False，于是 `clear` 静默、shell 彩色
# 全灭。探测权收归入口，引擎只接受结论。
has Bool $.tty   is rw = False;
# 0.88.0 / V-227：终端尺寸同样是「终端事实」，由入口查好再下发。
# 0 表示未知（管道 / 无控制台），排版时回落到 80 列。
has Int  $.width  is rw = 0;
# 0.89.0 / V-228：**本进程的 stdout 是不是那个终端**。
# 与 `tty` 是两件事：`tty` 说「用户面前有终端」（排版用），
# `live-out` 说「我写 stdout 就能写到它」（分页、逐行流式用）。
# 引擎子进程里恒 False（stdout 是协议管道）—— 用 `tty` 代替它会让
# 分页器把表格文本写进 JSON 流、并去读 stdin 当按键（0.87 引入的回归，
# 实测 `explore` 之后 REPL 直接卡死）。
has Bool $.live-out = False;
has Int  $.height is rw = 0;
has Bool $.bt    is rw = False;
has @.perf-hist is rw;
has Int  $.index is rw = 0;
has Bool $.exit-requested is rw = False;
has Int  $.exit-code      is rw = 0;
has Bool $.interrupt-requested is rw = False;
has Bool $.strict is rw = False;   # set -e 等价：失败格请求退出
has Bool $!expanding = False;      # 防历史替换递归
# 0.77.0 / ADR-0015 §3：输入序与格号分离。
#   · $!index  = 格号（成功求值/执行的格），`Out[n]` 与 perf 用它；
#   · @!history = 输入序，`history` 显示与 `!n` / `!!` 的编号用它。
# 以前两者绑在同一句 `$!index++; @!history.push(...)` 里，于是会话级命令
# （config / alias / log …）两个都不进 —— 用户敲过的那行凭空消失，
# `!!` 重放的是上一格。
has Str  $!cell-source = '';       # 本格的完整源码（多行拼接后），供 !finish 记账
has Bool $!skip-record = False;    # `!!` 的外层不重复记（内层已记展开结果）

# 0.75.0 / ADR-0012 §5：会话日志。状态只在内存，落盘一律经 Sys（V-125），
# 不能照抄 !save-config 的裸 .spurt —— 那是配置文件的既有例外。
has Bool $!log-on = False;
has Str  $!log-path = '';
has Int  $!log-seq = 0;
has @!log-lines;

# ── 求值器内部状态 ───────────────────────────────────────────────────
has Str $.accum is rw = '';      # 兼容旧字段；不再用于整份重 EVAL
has Int $.shown is rw = 0;       # 已展示过的 stdout 长度（当前格）
has %.state;                    # 跨格持久化的顶层 my/our/state 变量
has @!decls;                    # 跨格持久化的纯 sub/class/use 声明

# ── 会话快照（0.84.0 / ADR-0022）──────────────────────────────────────
# 每格成功后把 `%!state` + `@!decls` 写到磁盘，崩溃重启时可以重放。
# 快照只存**声明 + 纯值**：语句格不重放（`write` / `! rm` 幂等性不成立）。
has Str  $.snapshot-path is rw = '';
has Bool $.snapshot-on   is rw = True;
has      %!restored;            # 最近一次恢复的摘要（给前端展示）
has      @!restore-failed;      # 恢复失败的变量名
has @!pending;                  # 多行续行缓冲
has @!out;                      # 成功结果历史；Out[1] 是第一个成功格
has %!hinted;                   # hints 去重：同一首词只提示一次

submethod TWEAK() {
    # 进程内构造（管道 / -e / 测试）就按自己的 stdout 判定；引擎里由
    # `set-tty` 覆盖成父进程的结论（见 Server 的 eval 分支）。
    # 0.98.2：不用 `$*OUT.t` —— Windows 上它对 NUL 误报 True（见 Term）。
    $!tty = Rakuish::Sys::Term::stdout-is-console();
    $!live-out = Rakuish::Sys::Term::stdout-is-console();
    unless $!sys.defined {
        # REPL/脚本是可信的本地环境：默认 root 是文件系统根，而不是启动 cwd。
        # 否则用户连 `cd ..` / 读绝对路径都做不到；Agent 入口仍要求显式 root。
        my IO::Path $root = $*DISTRO.is-win
            ?? IO::Path.new($*CWD.volume ~ '\\')
            !! IO::Path.new('/');
        # Windows 的 C:\ 只是当前盘根，不是“文件系统根”；REPL 应像 POSIX
        # root=/ 一样允许用户访问 D:/F: 等其他盘。Agent 走自己的 root，不受影响。
        $!sys = Rakuish::Sys.new(
            :root($root), :cwd($*CWD.IO),
            :all-drives($*DISTRO.is-win),
        );
    }
    $!commands = default-registry()  unless $!commands.defined;
    $!shell = Rakuish::REPL::Shell.new(:sys($!sys), :color($!color), :tty($!tty))
        unless $!shell.defined;
    $!plugins = PluginManager.new unless $!plugins.defined;
    self!load-config;
    bind-session($!sys);
    self!init-snapshot;
}

# ── 配置 / alias ─────────────────────────────────────────────────────
method config-path(--> IO::Path) {
    my $env = %*ENV<RAKUISH_CONFIG>;
    return IO::Path.new($env) if $env.defined && $env.chars;
    my $home = try { $*HOME } // $*CWD;
    $home.add('.rakuish-config.json');
}

method !load-config(--> Nil) {
    my $p = self.config-path;
    return unless $p.e;
    my $data = try { from-json($p.slurp) };
    %!config = $data.Hash if $data ~~ Hash;
    Nil
}

method !save-config(--> Nil) {
    my $p = self.config-path;
    try { $p.parent.mkdir unless $p.parent.d; $p.spurt(to-json(%!config, :pretty)); }
    Nil
}

# ── set -o 选项（0.90.0 / ADR-0025）──────────────────────────────────
# 每个选项都必须有执行点；这张表同时是 `set -o` 的列表输出与测试的真值源。
method !option-names(--> List) {
    <errexit histexpand noglob noexpand xtrace>.List;
}

method !option-table(--> Hash) {
    %(
        errexit    => $!strict,
        histexpand => $!histexpand,
        noglob     => $!noglob,
        noexpand   => $!noexpand,
        xtrace     => $!xtrace,
    );
}

method !set-option(Str $name, Bool $on --> Bool) {
    given $name.lc {
        when 'errexit'    { $!strict     = $on }
        when 'histexpand' { $!histexpand = $on }
        when 'noglob' {
            $!noglob = $on;
            $!shell.noglob = $on if $!shell.defined;
        }
        when 'noexpand' {
            $!noexpand = $on;
            $!shell.noexpand = $on if $!shell.defined;
        }
        when 'xtrace'     { $!xtrace = $on }
        default           { return False }
    }
    True
}

# 公开只读视图：`repl.options` 可在 Rc / 插件里查，不必再猜。
method options(--> Hash) { self!option-table }

method !aliases(--> Hash) {
    my $a = %!config<aliases>;
    $a ~~ Hash ?? $a !! %();
}

method !expand-alias(Str $line --> Str) {
    my Str $out = $line;
    my %a = self!aliases;
    for ^10 {
        my @parts = $out.split(/\s+/, 2);
        last unless @parts.elems;
        my Str $name = @parts[0];
        last unless %a{$name}:exists;
        my Str $rest = @parts.elems > 1 ?? @parts[1] !! '';
        $out = %a{$name}.Str ~ ($rest.chars ?? ' ' ~ $rest !! '');
    }
    $out
}

method !cmd-alias(Str $raw --> Result) {
    my Str $t = $raw.trim;
    if $t eq 'alias' {
        my @lines = self!aliases.keys.sort.map({ "{$_}={self!aliases{$_}}" });
        return Result.new(:ok, :op<alias>, :value(self!aliases),
                          :out(@lines.join("\n")));
    }
    my Str $rest = $t.substr(5).trim;
    if $rest.starts-with('--') {
        return Result.new(:!ok, :code(2), :op<alias>,
                          :err('用法: alias [name=command]'));
    }
    my Int $eq = $rest.index('=');
    my Str $name;
    my Str $value;
    if $eq.defined {
        $name  = $rest.substr(0, $eq).trim;
        $value = $rest.substr($eq + 1).trim;
    }
    else {
        my @p = $rest.split(/\s+/, 2);
        $name = @p[0] // '';
        $value = @p.elems > 1 ?? @p[1] !! '';
    }
    return Result.new(:!ok, :code(2), :op<alias>,
                      :err('用法: alias name=command')) unless $name.chars;
    if !$value.chars {
        %!config<aliases>{$name}:delete;
    }
    else {
        %!config<aliases>{$name} = $value;
    }
    self!save-config;
    Result.new(:ok, :op<alias>, :value($name), :out("alias {$name}={$value}"));
}

method !cmd-unalias(Str $raw --> Result) {
    my Str $name = $raw.trim.substr(8).trim;
    return Result.new(:!ok, :code(2), :op<unalias>,
                      :err('用法: unalias name')) unless $name.chars;
    %!config<aliases>{$name}:delete;
    self!save-config;
    Result.new(:ok, :op<unalias>, :value($name), :out("unalias {$name}"));
}

method !cmd-config(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines = %!config.keys.sort.map({
            my $v = %!config{$_};
            "{$_}={$v ~~ Str ?? $v !! to-json($v, :!pretty)}"
        });
        return Result.new(:ok, :op<config>, :value(%!config),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'get' && @args.elems >= 3 {
        my Str $k = @args[2];
        return Result.new(:!ok, :code(1), :op<config>, :err("没有配置: {$k}"))
            unless %!config{$k}:exists;
        return Result.new(:ok, :op<config>, :value(%!config{$k}),
                          :out(%!config{$k}.Str));
    }
    if $sub eq 'set' && @args.elems >= 4 {
        my Str $k = @args[2];
        my Str $v = @args[3..*].join(' ');
        %!config{$k} = $v;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($v), :out("{$k}={$v}"));
    }
    if $sub eq 'unset' && @args.elems >= 3 {
        my Str $k = @args[2];
        %!config{$k}:delete;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($k), :out("unset {$k}"));
    }
    Result.new(:!ok, :code(2), :op<config>,
               :err('用法: config [get KEY|set KEY VALUE|unset KEY]'))
}

method !hooks(--> Hash) {
    my $h = %!config<hooks>;
    $h ~~ Hash ?? $h !! %();
}

method run-hooks(Str $event --> List) {
    my %h = self!hooks;
    return () unless %h{$event} ~~ Positional;
    my @res;
    for %h{$event}.List -> $code {
        @res.push(self.eval-line($code.Str));
        last if $!exit-requested;
    }
    @res.List;
}

method !cmd-hook(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines;
        for self!hooks.keys.sort -> $e {
            @lines.push("{$e}:");
            @lines.push("  {$_}") for self!hooks{$e}.List;
        }
        return Result.new(:ok, :op<hook>, :value(self!hooks),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'add' && @args.elems >= 4 {
        my Str $event = @args[2];
        my Str $code = @args[3..*].join(' ');
        my %h = self!hooks;
        %h{$event} //= [];
        %h{$event}.push($code);
        %!config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($code),
                          :out("hook {$event} += {$code}"));
    }
    if $sub eq 'clear' && @args.elems >= 3 {
        my Str $event = @args[2];
        my %h = self!hooks;
        %h{$event}:delete;
        %!config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($event),
                          :out("hook {$event} cleared"));
    }
    if $sub eq 'run' && @args.elems >= 3 {
        my Str $event = @args[2];
        my @rs = self.run-hooks($event);
        my Str $out = @rs.map({ $_.out.chomp }).grep(*.chars).join("\n");
        my Str $err = @rs.map({ $_.err.chomp }).grep(*.chars).join("\n");
        my Bool $all-ok = so @rs.map(*.ok).all;
        return Result.new(:ok($all-ok), :op<hook>,
                          :value(@rs.List), :out($out), :err($err));
    }
    Result.new(:!ok, :code(2), :op<hook>,
               :err('用法: hook [add EVENT CODE|clear EVENT|run EVENT]'))
}

method !cmd-explore(Str $raw --> Result) {
    my Str $arg = $raw.trim.substr(7).trim;
    my $value;
    if $arg.chars {
        my $path = try { $!sys.resolve($arg) };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err("路径不存在: {$arg}")) unless $path.defined;
        my $loaded = try {
            $path.d
                ?? $!sys.ls-table($arg)
                !! Rakuish::Data::open-data($!sys, $arg)
        };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err($!.message)) unless $loaded.defined;
        $value = $loaded;
    }
    else {
        $value = @!out.elems ?? @!out[*-1] !! Nil;
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err('没有可探索的上一格结果')) unless $value.defined;
    }

    $value = Rakuish::Data::tableify($value)
        if $value ~~ Hash | Positional && $value !~~ Rakuish::Data::Table;
    return Result.new(:!ok, :code(1), :op<explore>,
                      :err('explore 需要 Table / 可表格化的数据'))
        unless $value ~~ Rakuish::Data::Table | Str;

    # 每页行数按终端高度算（留 2 行给提示符与 "-- more --"）。
    # 高度未知时退回 Pager 的默认 20 —— 这就是 height 的执行点，
    # 没有它 `height` 只是一个被存起来的数字（V-211 的同一把尺子）。
    my $pager = Rakuish::Data::Pager.new(:page-size(self.pager-page-size));
    # 这里要的是 live-out 而不是 tty：分页要往**真 stdout** 写、再读**真 stdin**。
    my Bool $tty = $!live-out;
    $tty = False if (%*ENV<RAKUISH_PAGER> // '') eq 'never';
    my Str $text = $pager.page($value, :interactive($tty));
    Result.new(:ok, :op<explore>, :value($value),
               :out($tty ?? '' !! $text));
}

# ── `!` 的 argv 分词：只处理空格与引号，元字符一律原样当参数 ──────────
# 不做 $VAR / * / ? / | / > / && / ; / heredoc / 命令替换。
method !unclosed-quote(Str $s --> Bool) {
    my Str $q = '';
    my Bool $escape = False;
    for $s.comb -> $ch {
        if $escape { $escape = False; next }
        if $q eq '' {
            if $ch eq '\\' { $escape = True; next }
            $q = $ch if $ch eq "'" || $ch eq '"';
        }
        else {
            if $ch eq '\\' { $escape = True; next }
            $q = '' if $ch eq $q;
        }
    }
    $q ne '';
}

method !split-argv(Str $s --> List) {
    my @out;
    my Str $cur   = '';
    my Str $quote = '';
    my Bool $has  = False;
    for $s.comb -> $ch {
        if $quote eq '' {
            if $ch eq "'" || $ch eq '"' {
                $quote = $ch;
                $has = True;
            }
            elsif so($ch ~~ /\s/) {
                if $has { @out.push($cur); $cur = ''; $has = False }
            }
            else { $cur ~= $ch; $has = True }
        }
        else {
            if $ch eq $quote { $quote = '' }
            else             { $cur ~= $ch }
        }
    }
    @out.push($cur) if $has;
    @out.List
}

# ── 顶层声明状态化（替代整份历史重 EVAL）────────────────────────────
# Raku 的 EVAL 不能跨调用保留词法 my；为了同时做到「my 跨格」和
# 「副作用只执行一次」，这里只把**顶层声明**转成状态 Hash 的别名：
#
#   my $x = 41;      →  $x = 41;        （$x 已别名到 %STATE<$x>）
#   my @a = (1,2);   →  @a = (1,2);
#   my %h = a=>1;    →  %h = a=>1;
#
# 当前格里的普通语句只执行一次；不再把上一格的 sys.write / append / exec
# 重新跑一遍。已知边界：嵌套块里的 my 保持局部（正确）；复杂类型约束/
# 自定义 trait 会被简化掉；sub/class 的跨格持久仍不在本状态层内。

method !take-name(Int $at, @ch, Int $n --> Str) {
    return '' if $at >= $n;
    my Str $sig = @ch[$at];
    return '' unless $sig ~~ /^<[$@%&]>$/;
    return '' if $at + 1 >= $n;
    return '' unless @ch[$at + 1] ~~ /^<[A..Za..z_]>$/;
    my Str $name = $sig;
    my Int $j = $at + 1;
    while $j < $n && @ch[$j] ~~ /^<[A..Za..z0..9_-]>$/ {
        $name ~= @ch[$j];
        $j++;
    }
    $name;
}

method !scan-cell(Str $src --> Hash) {
    my @ch = $src.comb;
    my Int $n = @ch.elems;
    my Str $out = '';
    my @names;
    my Str $quote = '';
    my Bool $esc = False;
    my Int $brace = 0;
    my Int $paren = 0;
    my Int $bracket = 0;
    my Bool $stmt-start = True;
    my Int $i = 0;

    while $i < $n {
        my Str $c = @ch[$i];

        if $quote ne '' {
            $out ~= $c;
            if $quote eq '"' && $esc {
                $esc = False;
            }
            elsif $quote eq '"' && $c eq '\\' {
                $esc = True;
            }
            elsif $c eq $quote {
                $quote = '';
            }
            $i++;
            next;
        }

        if $c eq q{'} || $c eq q{"} {
            $quote = $c;
            $out ~= $c;
            $stmt-start = False;
            $i++;
            next;
        }

        if $c eq '#' {
            while $i < $n {
                $out ~= @ch[$i];
                last if @ch[$i] eq "\n";
                $i++;
            }
            $i++;
            next;
        }

        if $stmt-start && $brace == 0 && $paren == 0 && $bracket == 0 {
            my Str $rest = $src.substr($i);

            # 0.106.2：`use Foo` 不带分号、后面直接换行时，同一编译单元里
            # 看不到它导入的名字（Rakudo 2026.09 实测：`do { use X⏎X::Y }` 报
            # "Could not find symbol '&Y' in '<pkg>::X'"）。这里补一个 `;`，
            # 让「用户敲 use X」和「prelude 重放 use X」都等价于 `use X;`。
            if $rest ~~ /^ use \s / {
                my Int $mark = $out.chars;
                my Str $q = '';
                my Int $hash = -1;
                my Int $depth = 0;
                while $i < $n {
                    my Str $ch = @ch[$i];
                    if $q ne '' {
                        $out ~= $ch;
                        if $q eq '"' && $ch eq '\\' && $i + 1 < $n {
                            $i++;
                            $out ~= @ch[$i];
                        }
                        elsif $ch eq $q {
                            $q = '';
                        }
                        $i++;
                        next;
                    }
                    if $ch eq q{'} || $ch eq q{"} {
                        $q = $ch;
                        $out ~= $ch;
                        $i++;
                        next;
                    }
                    if $ch eq '#' {
                        $hash = $out.chars;
                        last;
                    }
                    last if $ch eq "\n";
                    $depth++ if $ch eq '(' || $ch eq '[' || $ch eq '{';
                    $depth-- if $ch eq ')' || $ch eq ']' || $ch eq '}';
                    $out ~= $ch;
                    $i++;
                }
                # 括号没闭合（多行 use）时不动它，维持原行为。
                if $depth == 0 {
                    $out ~= ';' unless $out.substr($mark).trim-trailing.ends-with(';');
                    # `use Foo # 注释`：分号要补在注释之前，注释原样接回。
                    while $hash >= 0 && $i < $n && @ch[$i] ne "\n" {
                        $out ~= @ch[$i];
                        $i++;
                    }
                }
                $stmt-start = True;
                next;
            }

            my Str $kw = '';
            for <my our state> -> $cand {
                next unless $rest.starts-with($cand);
                my Str $after = $rest.substr($cand.chars, 1);
                next if $after ~~ /^<[A..Za..z0..9_-]>$/;
                $kw = $cand;
                last;
            }
            # 顶层类型声明必须留在词法作用域：裸 class/role/grammar 会被 EVAL
            # 安装到 GLOBAL，跨格前置重放时触发 "Redeclaration of symbol"。
            # 统一改写为 my；同时不能让下面的 %STATE 扫描把 my/our/state 剥掉
            # （剥离只适用于带 sigil 的变量声明）。
            if $kw.chars {
                my Str $ahead = $rest.substr($kw.chars).trim-leading;
                if $ahead ~~ /^ (class|role|grammar|subset|enum|constant) \s / {
                    $out ~= 'my';
                    $i += $kw.chars;
                    $stmt-start = False;
                    next;
                }
            }
            my $tm = $kw.chars ?? Nil !! ($rest ~~ /^ (class|role|grammar) \s /);
            if $tm {
                my Str $tk = ~$tm[0];
                $out ~= 'my ' ~ $tk;
                $i += $tk.chars;
                $stmt-start = False;
                next;
            }
            if $kw.chars {
                my Int $j = $i + $kw.chars;
                $j++ while $j < $n && @ch[$j] ~~ /\s/;

                # 可选类型约束：`my Int $x` / `my IO::Path $p`
                if $j < $n && @ch[$j] ne '(' && @ch[$j] !~~ /^<[$@%&]>/ {
                    while $j < $n && @ch[$j] ~~ /^<[A..Za..z0..9_:]>$/ { $j++ }
                    $j++ while $j < $n && @ch[$j] ~~ /\s/;
                }

                my @new;
                if $j < $n && @ch[$j] eq '(' {
                    my Int $k = $j + 1;
                    while $k < $n && @ch[$k] ne ')' {
                        my Str $name = self!take-name($k, @ch, $n);
                        if $name.chars {
                            @new.push($name);
                            $k += $name.chars;
                        }
                        else {
                            $k++;
                        }
                    }
                }
                else {
                    my Int $k = $j;
                    while $k < $n && @ch[$k] ne '=' && @ch[$k] ne ';' && @ch[$k] ne "\n" {
                        if @ch[$k] eq ',' { $k++; next }
                        my Str $name = self!take-name($k, @ch, $n);
                        if $name.chars {
                            @new.push($name);
                            $k += $name.chars;
                        }
                        else {
                            $k++;
                        }
                    }
                }

                @names.append(@new);
                $i = $j;
                $stmt-start = False;
                next;
            }
        }

        $out ~= $c;
        given $c {
            when '{' { $brace++ }
            when '}' { $brace-- if $brace > 0 }
            when '(' { $paren++ }
            when ')' { $paren-- if $paren > 0 }
            when '[' { $bracket++ }
            when ']' { $bracket-- if $bracket > 0 }
        }

        if $c eq ';' && $brace == 0 && $paren == 0 && $bracket == 0 {
            $stmt-start = True;
        }
        elsif $c eq "\n" {
            $stmt-start = True;
        }
        elsif $c !~~ /\s/ {
            $stmt-start = False;
        }
        $i++;
    }

    %( code => $out, names => @names.unique.List );
}

# ── 会话快照（0.84.0 / ADR-0022）─────────────────────────────────────
# 路径：RAKUISH_SNAPSHOT 显式指定 → $*HOME/.rakuish/session-<cwd指纹>.json
# → 空（纯内存）。按 cwd 分文件是为了让不同项目的会话互不覆盖。
method !init-snapshot(--> Nil) {
    $!snapshot-on = !(%*ENV<RAKUISH_NO_SNAPSHOT> // '').Str.chars;
    my Str $p = (%*ENV<RAKUISH_SNAPSHOT> // '').Str;
    unless $p.chars {
        my $home = try { $*HOME };
        if $home.defined {
            my $d = $home.add('.rakuish');
            my Str $key = Rakuish::Audit::fingerprint($!sys.cwd.Str).substr(0, 12);
            $p = $d.add("session-{$key}.json").Str;
        }
    }
    $!snapshot-path = $p;
    Nil
}

# 每格成功后调用。任何失败都吞掉：快照是**附加价值**，
# 不能因为它写不出去就让求值失败。
method save-snapshot(--> Nil) {
    return unless $!snapshot-on && $!snapshot-path.chars;
    my %snap = Rakuish::Snapshot::capture(
        %!state, @!decls,
        :cwd($!sys.cwd.Str),
        :session('local'),
        :rakuish(($?DISTRIBUTION.meta<version> // '').Str),
    );
    try { Rakuish::Snapshot::save(%snap, $!snapshot-path.IO) };
    Nil
}

# 从快照恢复。只做两件事：把声明填回缓存、把纯值灌回 %!state。
# 返回摘要 %( decls, vars, failed, saved-at )。
#
# 值必须**带着 prelude 一起 EVAL**：Raku 的 `EVAL` 定义的类型不会跨 EVAL
# 存活（实测），所以 `Foo.new(...)` 单独求值只会得到「Undeclared routine」。
method restore-snapshot(%snap --> Hash) {
    my @decls = (%snap<decls> // []).List;
    my %values = (%snap<state> // %{}).Hash;
    return %( decls => 0, vars => 0, failed => ().List, 'saved-at' => '' )
        unless @decls.elems || %values.elems;

    my @srcs;
    for @decls -> %d {
        my Str $src = (%d<src> // '').Str;
        next unless $src.chars;
        @srcs.push($src);
        @!decls.push(%(
            key       => (%d<key>  // '').Str,
            src       => $src,
            name      => (%d<name> // '').Str,
            'is-type' => ?(%d{'is-type'} // False),
        ));
    }

    my Int $ok-vars = 0;
    my @failed;
    my @pairs;          # (name, raku)
    for %values.kv -> $k, %c {
        given (%c<kind> // '').Str {
            when 'value' { @pairs.push(($k, (%c<raku> // '').Str)) }
            when 'nil'   { %!state{$k} = Any; ++$ok-vars }
            default      { %!state{$k} = Any; @failed.push($k) }
        }
    }

    if @pairs.elems {
        my Str $pre = @srcs.join("\n");
        # 用户在会话里定义的类由本类的 EVAL 定义，`.raku` 会写成
        # `Rakuish::REPL::Session::Foo.new(...)`。但声明源码是 `my class Foo`
        # —— `my` 类型不以全名注册，直接用全名构造会「找不到类型」。
        # 所以恢复前把本类前缀剥掉，让它按短名解析（同一 EVAL 块内可见）。
        my Str $pkg = self.WHAT.^name ~ '::';
        my Str $body = @pairs.map({ "'{.[0]}' => { .[1].subst($pkg, '', :g) }" }).join(",\n");
        my $bag;
        my Str $batch-err = '';
        {
            CATCH { default { $batch-err = .message } }
            $bag = EVAL "no worries; do \{ $pre \n %( $body ) }";
        }
        if $bag.defined && $bag ~~ Hash {
            for $bag.kv -> $k, $v { %!state{$k} = $v; ++$ok-vars }
        }
        else {
            # 批量失败（某个值依赖恢复不回来的东西）就逐个来：
            # 能救几个是几个，救不回的进 failed 列表。
            for @pairs -> $p {
                my $v;
                {
                    CATCH { default { } }
                    $v = EVAL "no worries; do \{ $pre \n { $p[1].subst($pkg, '', :g) } }";
                }
                if $v.defined || $p[1] eq 'Any' {
                    %!state{$p[0]} = $v;
                    ++$ok-vars;
                }
                else {
                    %!state{$p[0]} = Any;
                    @failed.push($p[0]);
                }
            }
        }
    }

    $!index = 0;
    %!restored = %(
        decls    => @srcs.elems,
        vars     => $ok-vars,
        failed   => @failed.List,
        'saved-at' => (%snap{'saved-at'} // '').Str,
    );
    @!restore-failed = @failed.List;
    %!restored;
}

method restored(--> Hash) { %!restored }

method !state-alias(Str $name --> Str) {
    given $name.substr(0, 1) {
        when '$' { 'my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;' }
        when '@' {
            '%STATE<' ~ $name ~ '> //= []; my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;'
        }
        when '%' {
            '%STATE<' ~ $name ~ '> //= {}; my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;'
        }
        default { '' }
    }
}

# 只接受“纯声明格”：整个 cell 就是一个 sub/class/role/grammar 或 use。
# 混有其它语句的 cell 不缓存，避免把副作用也带进后续格。
# 编译期/运行期 phaser 也不缓存：prelude 每格前置重放一次，BEGIN/INIT/END
# 之类的副作用会被反复执行；拒绝缓存后该格仍照常求值，只是不跨格持久。
method !pure-decl(Str $src --> Hash) {
    my Str $t = $src.trim;
    return Nil unless $t.chars;

    # 0.106.2：扫描阶段会给 `use` 补分号，这里按「第一条语句」切，
    # 允许后面只跟注释；旧快照里没分号的写法也一并收编。
    if $t ~~ /^ use \s+ \S+ / {
        my Int $semi = $t.index(';') // -1;
        my Str $one  = $semi >= 0 ?? $t.substr(0, $semi + 1) !! $t;
        my Str $tail = $semi >= 0 ?? $t.substr($semi + 1) !! '';
        return Nil unless $tail.trim ~~ /^ ['#' .*]? $/;
        $one = $one.subst(/\s* '#' .* $/, '') unless $semi >= 0;
        $one = $one.trim;
        $one ~= ';' unless $one.ends-with(';');
        return %( key => "use:$one", src => $one );
    }

    for <BEGIN INIT CHECK END START FIRST> -> $phaser {
        return Nil if $t ~~ / << $phaser >> /;
    }

    my $m = $t ~~ /^ [multi \s+]? [my \s+]? (sub|class|role|grammar) \s+ (\S+) /;
    return Nil unless $m;
    my Str $kind = ~$m[0];
    my Str $name = (~$m[1]).subst(/<[{;(]>.*$/, '');
    return Nil unless $name.chars;
    my Int $open = $t.index('{');
    return Nil unless $open.defined;

    my @ch = $t.comb;
    my Int $n = @ch.elems;
    my Str $quote = '';
    my Bool $esc = False;
    my Int $depth = 0;
    my Int $i = $open;
    my Int $close = -1;
    while $i < $n {
        my Str $c = @ch[$i];
        if $quote ne '' {
            if $quote eq '"' && $esc { $esc = False }
            elsif $quote eq '"' && $c eq '\\' { $esc = True }
            elsif $c eq $quote { $quote = '' }
            $i++;
            next;
        }
        if $c eq q{'} || $c eq q{"} { $quote = $c; $i++; next }
        if $c eq '#' {
            while $i < $n && @ch[$i] ne "\n" { $i++ }
            next;
        }
        if $c eq '{' { $depth++ }
        elsif $c eq '}' {
            $depth--;
            if $depth == 0 { $close = $i; last }
        }
        $i++;
    }
    return Nil if $close < 0;
    my Str $tail = $t.substr($close + 1).trim;
    return Nil if $tail.chars && $tail ne ';';

    %( key => "{$kind}:{$name}", src => $t, :name($name),
       is-type => ($kind eq 'class' || $kind eq 'role' || $kind eq 'grammar') );
}

# 0.106.2：从任意 cell 里挑出顶层 `use` 语句（每行一条、必须已有 `;`，
# 扫描阶段保证）。用于「use 和其它语句混在一格」时也不丢导入。
method !collect-uses(Str $code --> List) {
    my @found;
    for $code.lines -> $ln {
        next unless $ln ~~ /^ use \s+ \S+ /;
        my Str $t = $ln.trim;
        my Int $semi = $t.index(';') // -1;
        next if $semi < 0;
        my Str $one = $t.substr(0, $semi + 1);
        @found.push(%( key => "use:$one", src => $one ));
    }
    @found.List;
}

# ── Raku 求值：只执行当前格；顶层声明用 %STATE / @decls 持久化 ──────
method !remember(Result $r --> Nil) {
    return unless $r.ok;
    return if $r.op eq 'more' || $r.op eq 'exit' || $r.op eq 'skip';
    @!out.push($r.value);
    @!out.shift while @!out.elems > 1000;
    Nil
}

method !eval-raku(Str $src --> Result) {
    my %scanned = self!scan-cell($src);
    my @new-names = %scanned<names>.List;
    my Str $cell-code = %scanned<code>;
    my %decl = self!pure-decl($cell-code) // %();
    my Bool $is-type = so %decl<is-type>;

    # 声明进入 prelude 的方式：
    #   · sub / use：当前 cell 自己声明，成功后按原位插回缓存；
    #   · class / role / grammar：直接原位替换缓存，当前 cell 只引用类型名。
    #     否则重定义被继承的类型时，依赖它的声明会排在它前面（编译失败）。
    my Int $slot = -1;
    my @saved-decls = @!decls.List;
    # 0.106.2：混着其它语句的 cell（`use X; say 1`）不算纯声明格，
    # 但里面的顶层 `use` 必须留下 —— 它只是加载 + 导入，重放无副作用。
    for self!collect-uses($cell-code) -> $u {
        next if @!decls.first({ .<key> eq $u<key> });
        @!decls.push($u);
    }
    if %decl<key> {
        $slot = @!decls.first({ .<key> eq %decl<key> }, :k) // -1;
        if $is-type {
            if $slot >= 0 { @!decls[$slot] = %decl }
            else          { @!decls.push(%decl) }
            $cell-code = %decl<name>;
        }
        elsif $slot >= 0 {
            @!decls = @!decls.grep({ .<key> ne %decl<key> }).List;
        }
    }

    for @new-names -> $name {
        next if %!state{$name}:exists;
        given $name.substr(0, 1) {
            when '$' { %!state{$name} = Any }
            when '@' { %!state{$name} = [] }
            when '%' { %!state{$name} = {} }
        }
    }

    my @prelude;
    for @!decls -> $d {
        my Str $s = $d<src>;
        # 旧快照里可能存着没分号的 `use Foo`，重放时同样补上（见 !scan-cell）。
        $s ~= ';' if $s ~~ /^ use \s / && !$s.trim-trailing.ends-with(';');
        @prelude.push($s);
    }
    for %!state.keys.sort -> $name {
        my Str $alias = self!state-alias($name);
        @prelude.push($alias) if $alias.chars;
    }
    my Str $code = @prelude.join("\n")
        ~ (@prelude.elems ?? "\n" !! '')
        ~ $cell-code;

    my $cap  = CapturingOut.new;
    my $t0   = now;
    my $value;
    my Str $err = '';
    my Bool $ok = True;
    my $last = @!out.elems ?? @!out[*-1] !! Any;
    my @out  = (Any, |@!out);

    {
        # 部分编译期异常（典型：跨格引用未声明类型）的 .message / .gist
        # 在**方法内部**字符串化未定义值并抛 CX::Warn，仅在外面判断
        # .defined 拦不住（0.69.1 实测：警告行号就落在取消息这一行）。
        # quietly 只包住「构造异常文本」这一小块，抑制驱动自身的警告；
        # 结果仍显式收敛成 Str，最后用异常类名兜底，$err 绝不接收 Any。
        CATCH { default {
            $ok = False;
            my $ex = $_;
            my Str $text = (quietly {
                my $m = try { $ex.message };
                my Str $s = $m.defined ?? (try { ~$m } // '') !! '';
                $s.chars ?? $s !! (try { ~$ex.gist } // '')
            }) // '';
            $err = $text.chars ?? $text !! $ex.^name;
        } }
        # 无 sigil 词法绑定：EVAL 里可直接写 sys.read(...) / repl.history /
        # registry.names（实测 MoarVM 上 EVAL 能看到调用处的词法绑定）。
        my \sys      = $!sys;
        my \repl     = self;
        my \registry = $!commands;
        my \_        = $last;
        my \Out      = @out;
        my $*RAKUISH-SESSION = self;
        my $*RAKUISH-SYS = $!sys;
        my %STATE := %!state;
        temp $*OUT = $cap;
        $value = EVAL "no worries; do \{ $code \n }";
    }

    my Str $all = $cap.text;
    $!shown = $all.chars;

    if $ok {
        if %decl<key> && !$is-type {
            if $slot >= 0 && $slot <= @!decls.elems {
                @!decls.splice($slot, 0, %decl);
            }
            else {
                @!decls.push(%decl);
            }
        }
        $!accum = $src;
        $!index = $!index + 1;
        # 0.84.0 / ADR-0022：成功格之后落一次快照。只在**成功**时写 ——
        # 失败格没有改变可持久状态，写了反而会把上一份好快照冲掉。
        self.save-snapshot;
        # 耗时由入口 note-timing() 统一记录（覆盖 shell / ! / Raku 三类格），
        # 这里不再重复推入，否则 perf 报表会出现双倍条目。
    }
    else {
        # 声明格求值失败时回滚，不能把上一格可用的旧声明弄丢。
        @!decls = @saved-decls.List if %decl<key>;
    }
    my $res = Result.new(:ok($ok), :code($ok ?? 0 !! 1), :value($value),
                         :out($all), :err($err), :op<eval>,
                         :elapsed(now - $t0));
    self!remember($res);
    $res;
}

# ── 主入口 ────────────────────────────────────────────────────────────
method !strict-result(Result $r --> Result) {
    if $!strict && !$r.ok {
        $!exit-requested = True;
        $!exit-code = $r.code || 1;
    }
    $r;
}

# 0.76.0 / ADR-0013：这是 `Kernel` 的 `source` 通道实现，**不是前端入口**。
# 前端（bin/rakuish、将来的 Agent/Notebook）必须调 `Kernel.execute(Request)`，
# 让 Policy 在进入这里之前就被执行；`t/35` 有静态断言守着这条。
# 保留 public 是因为：进程内的 `repl` 对象 API（DSL）已经处在 Kernel 的执行
# 上下文里，再套一层只会绕回来。
#
# 0.77.0：拆成「执行 + 记账」两段。记账必须每行都走到，可 `!eval-line-body`
# 里有十几处 return（会话命令、`!` 前缀、shell 薄层、Raku 求值…）；
# 逐个补 `@!history.push` 正是以前漏掉一半的原因。包一层，让记账只有一处。
method eval-line(Str $line --> Result) {
    # 0.90.0 / ADR-0025：`set -o xtrace` 的执行点。打在求值之前、走 stderr，
    # 不参与 Out/值 —— 与 shell 的 `+ cmd` 同义。
    if $!xtrace && $line.trim.chars {
        $*ERR.say('+ ' ~ $line);
        try { $*ERR.flush };
    }
    my Result $r = self!eval-line-body($line);
    self!finish($line, $r);
    $r;
}

# ── 启动文件（0.90.0 / ADR-0025）────────────────────────────────────
# 逐**格**执行 rc：既能写 Raku（`my $x = 1` / `use Foo`），也能写薄层命令
# （`alias ll=ls -alh` / `set -o xtrace`）—— 后者只有 eval-line 认识。
# 空行与续行中间态不记账；整份跑完后把格号 / 历史 / perf 清零，让用户的
# 第一个格仍然是 Out[1]。
method run-rc(Str $src, Str :$label = 'rc' --> Hash) {
    my @out;
    my @err;
    my Int $failed = 0;
    my Int $n = 0;
    my Bool $pending = False;

    # 一行一行喂给 eval-line：续行缓冲由 Session 自己持有（@!pending），
    # 这里再拼一遍会把同一行喂两次 —— 0.90 开发中实测 class 因此永远不完整。
    for $src.lines -> $l {
        $n++;
        my $r = self.eval-line($l);
        if $r.op eq 'more' {
            $pending = True;
            next;
        }
        $pending = False;
        @out.push($r.out.chomp) if $r.out.chars;
        if !$r.ok && $r.op ne 'skip' && $r.err.chars {
            $failed++;
            @err.push("{$label}:{$n}: {$r.err.trim}");
        }
    }
    if $pending {
        $failed++;
        @err.push("{$label}:{$n}: 文件结束时仍有未闭合结构");
    }

    self!reset-counters;
    %(
        out    => @out.join("\n"),
        err    => @err.join("\n"),
        failed => $failed,
        lines  => $n,
    );
}

# rc 里的命令不该占用 Out[n] / history / perf：它们不是用户敲的格。
method !reset-counters(--> Nil) {
    $!index = 0;
    @!out = ();
    @!history = ();
    @!perf-hist = ();
    $!exit-requested = False;
    $!exit-code = 0;
    @!pending = ();
    set-continuation('');
    $!cell-source = '';
    Nil
}

# ── 可编程 prompt（0.90.0 / ADR-0025）────────────────────────────────
# 返回值就是用户看到的整个 prompt（含箭头）。函数里 `say` 的内容会被
# 吞掉：prompt 计算不能污染结果流 / 协议流。任何异常都退回空串，由前端
# 使用默认样式 —— 一个坏 prompt 不该让 REPL 无法输入。
method render-prompt(--> Str) {
    return '' unless &!prompt.defined;
    my Str $text = '';
    my Bool $ok = True;
    {
        CATCH { default { $ok = False } }
        my $cap = CapturingOut.new;
        temp $*OUT = $cap;
        temp $*ERR = $cap;
        my $v = &!prompt();
        $text = $v.defined ?? $v.Str !! '';
    }
    return '' unless $ok;
    # prompt 必须是单行：行编辑器按行计算光标位置。
    $text.subst(:g, /<[\r\n]>/, ' ');
}

# 唯一记账点：输入序（history）在这里增长，与格号（index）彻底解耦。
# 刻意**不**在这里碰 $!index —— 「失败的 Raku 格不占 Out 编号」是既定契约
# （t/07 有断言），shell 失败格占不占号是 0.77 之前的行为，不动它。
method !finish(Str $line, Result $r --> Nil) {
    if $!skip-record {          # `!!`：内层已经记过展开后的真实命令
        $!skip-record = False;
        return;
    }
    my Str $src = $!cell-source;
    $!cell-source = '';
    # 空行、续行中间态（`for ... {` 只敲了一半）都不是「用户提交的一行」。
    return unless $line.trim.chars;
    return if $r.op eq 'more';
    # 多行格记完整源码，不记最后一行 —— 否则 history 里只剩半个 for。
    @!history.push($r.op eq 'eval' && $src.chars ?? $src !! $line);
}

method !eval-line-body(Str $line --> Result) {
    return Result.new(:ok, :op<skip>) if $line.trim.chars == 0;

    my Str $t = $line.trim-leading;

    # `set`：0.90.0 起是一个真的选项系统（ADR-0025）。只实现有执行点的
    # 五个选项；不认识的明确报错，不做「存下来但没人读」的 inert 键。
    if $t.trim eq 'set' || $t.trim ~~ /^ 'set' \s+ <[-+]> 'o' $/ {
        my %opts = self!option-table;
        my Str $text = %opts.keys.sort
            .map({ "{$_} " ~ (%opts{$_} ?? 'on' !! 'off') }).join("\n");
        return Result.new(:ok, :op<set>, :value(%opts), :out($text));
    }
    if $t.trim ~~ /^ 'set' \s+ (<[-+]>) 'o' \s+ (\w+) ';'? $/ {
        my Bool $on   = ~$0 eq '-';
        my Str  $name = ~$1;
        unless self!set-option($name, $on) {
            return Result.new(:!ok, :code(1), :op<set>,
                :err("未知选项: {$name}（可用: {self!option-names.join(', ')}）"));
        }
        return Result.new(:ok, :op<set>, :value(self!option-table),
                          :out("{$name} " ~ ($on ?? 'on' !! 'off')));
    }
    # 兼容 shell 习惯：set -e / set +e 就是 errexit 的别名。
    if $t.trim ~~ /^ 'set' \s+ (<[-+]>) 'e' ';'? $/ {
        my Bool $on = ~$0 eq '-';
        self!set-option('errexit', $on);
        my Str $msg = $on ?? 'errexit on' !! 'errexit off';
        return Result.new(:ok, :op<set>, :value($on), :out($msg));
    }

    # shell 习惯的 history：显示本会话已执行行。
    if $t.trim eq 'history' {
        my Str $text = @!history.kv.map(-> $i, $v { "{$i + 1}  {$v}" }).join("\n");
        return Result.new(:ok, :op<history>, :value(@!history.List), :out($text));
    }

    # perf：查看每格耗时。不引入 %magic —— 耗时是会话数据，prompt 也读它。
    if $t.trim eq 'perf' || $t.trim.starts-with('perf ') {
        return self!cmd-perf($t);
    }

    # 0.75.0 / ADR-0012 §5：会话日志（与 config/alias 同级的普通会话命令）。
    if $t.trim eq 'log' || $t.trim.starts-with('log ') {
        return self!cmd-log($t);
    }

    # 0.66：hints（会话数据查询）与 plugin（显式本地 Raku 插件）。
    # 仍然不是 %magic：它们是普通会话命令，与 config/alias/hook 同级。
    if $t.trim eq 'hint' || $t.trim.starts-with('hint ') {
        return self!cmd-hint($t);
    }
    if $t.trim eq 'plugin' || $t.trim.starts-with('plugin ') {
        return self!cmd-plugin($t);
    }

    # 0.69：describe 是值 API 的会话入口（不是 %magic、不是文本报告）。
    # 只拦「首词是 describe 且后面是普通参数」；describe(...) 这类 Raku 调用
    # 仍交给 EVAL，由 DSL.describe 处理。
    if $t.trim eq 'describe' || $t.trim.starts-with('describe ') {
        return self!cmd-describe($t);
    }

    # 配置 / alias：会话级命令，不交给 Shell 参数解析。
    if $t.trim eq 'alias' || $t.trim.starts-with('alias ') {
        return self!cmd-alias($t);
    }
    if $t.trim.starts-with('unalias ') {
        return self!cmd-unalias($t);
    }
    if $t.trim eq 'config' || $t.trim.starts-with('config ') {
        return self!cmd-config($t);
    }
    if $t.trim eq 'hook' || $t.trim.starts-with('hook ') {
        return self!cmd-hook($t);
    }
    if $t.trim eq 'explore' || $t.trim.starts-with('explore ') {
        return self!cmd-explore($t);
    }
    # 历史替换只认整行 !! / !$ / !n；`!cmd` 仍是外部命令。
    # `set +o histexpand` 关闭后，`!!` 会落回外部命令（不存在 → 127），
    # 这是显式选项，不是静默退化。
    if !$!expanding && $!histexpand
       && $t.trim ~~ /^ '!' ('!' | '$' | '-'? \d+) $/ {
        return Result.new(:!ok, :code(127), :op<history>,
                          :err('历史为空')) unless @!history.elems;
        my Str $spec = $t.trim;
        my Str $expanded;
        if $spec eq '!!' {
            $expanded = @!history[*-1];
        }
        elsif $spec eq '!$' {
            $expanded = @!history[*-1].words.tail // '';
        }
        else {
            my Int $n = $spec.substr(1).Int;
            my Int $idx = $n < 0 ?? @!history.elems + $n !! $n - 1;
            return Result.new(:!ok, :code(127), :op<history>,
                              :err("没有历史项: {$spec}"))
                unless $idx >= 0 && $idx < @!history.elems;
            $expanded = @!history[$idx];
        }
        return Result.new(:!ok, :code(127), :op<history>,
                          :err("历史项为空: {$spec}")) unless $expanded.chars;
        $!expanding = True;
        my $r = self.eval-line($expanded);
        $!expanding = False;
        # 内层已经把**展开后的真实命令**记进 history；`!!` 这一行本身不再记，
        # 否则用户敲一次 `!!`，history 里会多出一条不存在的命令。
        $!skip-record = True;
        return $r;
    }

    # 1) `!` argv 便利入口。`!=` / `!~~` 是 Raku 运算符，仍按 Raku 求值。
    if $t.starts-with('!') {
        my Str $next = $t.chars > 1 ?? $t.substr(1, 1) !! '';
        if $next ne '=' && $next ne '~' {
            my Str $cmdline = $t.substr(1).trim;
            if self!unclosed-quote($cmdline) {
                return self!strict-result(
                    Result.new(:!ok, :code(127), :op<exec>,
                               :err('! 命令的引号未闭合')));
            }
            my @argv = self!split-argv($cmdline);
            # 0.70 / ADR-0007：`! --tty` / `! -t` 是显式 TTY 直通的元选项，
            # 只认首个 token；`! -- ...` 之后全部按字面 argv，不再解析元选项。
            # 0.90.0 / ADR-0024：同一层新增 `--capture` / `--timeout-ms` /
            # `--no-timeout`。它们仍属于 rakuish 的分发层，子进程只收到 argv。
            my Bool $tty-mode = False;
            my Bool $capture  = False;
            my Int  $timeout-ms = -1;          # -1 = 用 Sys 的默认（30s）
            while @argv.elems {
                my Str $head = @argv[0].Str;
                if $head eq '--' { @argv.shift; last }
                if $head eq '--tty' || $head eq '-t' {
                    $tty-mode = True; @argv.shift; next;
                }
                if $head eq '--capture' {
                    $capture = True; @argv.shift; next;
                }
                if $head eq '--no-timeout' {
                    $timeout-ms = 0; @argv.shift; next;
                }
                if $head eq '--timeout-ms' {
                    @argv.shift;
                    my $raw = @argv.shift;
                    my $n = $raw.defined ?? (try { $raw.Str.Int }) !! Nil;
                    unless $n.defined && $n >= 0 {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('! --timeout-ms 需要一个非负整数（毫秒；0 = 不超时）')));
                    }
                    $timeout-ms = $n.Int;
                    next;
                }
                last;
            }
            return self!strict-result(Result.new(:!ok, :code(127), :op<exec>,
                              :err('! 后面没有命令'))) unless @argv.elems;
            my $exe = @argv.shift;
            $!index = $!index + 1;
            my $r;
            if $tty-mode {
                my $hook = self.tty-handler;
                if $hook.defined {
                    # worker 模式：交回父进程执行（ADR-0021 §4）。
                    # hook 自己不抛：它把父进程的结果包装成 Result。
                    $r = $hook($exe, @argv);
                }
                else {
                    # 非 TTY 时 Sys 会抛 X::Rakuish::Unsupported；收敛成失败 Result，
                    # 不让异常穿透 eval-line（管道/脚本必须保持干净）。
                    my Str $start-err = '';
                    {
                        CATCH { default { $start-err = .message } }
                        $r = $!sys.tty-exec($exe, |@argv);
                    }
                    $r = Result.new(:!ok, :code(127), :op<tty-exec>,
                                    :err($start-err)) unless $r.defined;
                }
            }
            else {
                my %to = $timeout-ms >= 0 ?? ('timeout-ms' => $timeout-ms) !! %();
                my Bool $want-stream = $!stream-out && !$capture;
                if $want-stream {
                    my &emit-out = -> Str $t { self!emit-chunk('out', $t) };
                    my &emit-err = -> Str $t { self!emit-chunk('err', $t) };
                    $r = $!sys.exec($exe, |@argv, |%to,
                                    :on-out(&emit-out), :on-err(&emit-err));
                    # 启动失败时没有任何 chunk，err 必须留给 render；
                    # 正常结束则输出已经实时写过，不能再由 render 重放一遍。
                    my %v = ($r.value ~~ Hash) ?? %($r.value) !! %();
                    unless ?(%v<start-failed> // False) {
                        $r = Result.new(:ok($r.ok), :code($r.code), :op($r.op),
                                        :out(''), :err(''),
                                        :value($r.value), :elapsed($r.elapsed),
                                        :streamed(True));
                    }
                }
                else {
                    $r = $!sys.exec($exe, |@argv, |%to);
                }
            }
            self!remember($r);
            return self!strict-result($r);
        }
    }

    # 2) shell 习惯的常用命令：必须在续行判定前处理 `cd -`（Raku 会把它当
    #    不完整表达式）。只处理单行、无待续行的输入。
    if !@!pending && !$line.contains("\n") {
        my $shell-result = $!shell.handle(self!expand-alias($line));
        if $shell-result.defined {
            $!index = $!index + 1;
            self!remember($shell-result);
            return self!strict-result($shell-result);
        }
    }

    # 3) 其余一律 Raku（% 开头不再分流）。先处理多行续行。
    my @parts = @!pending.List;
    @parts.push($line);
    my Str $src = @parts.join("\n");

    # Raku 的 `exit` 会真的终止 REPL 进程（v2 用 prelude 覆盖）。这里显式
    # 映射成会话退出请求；这不是新命令表，不改变「只有两类输入」的分流。
    my Str $trim = $src.trim;
    my Bool $is-exit = $trim eq 'exit'
        || so($trim ~~ /^ 'exit' \s+ <[0..9]>+ $/);
    if $is-exit {
        $!exit-requested = True;
        $!exit-code = $trim eq 'exit' ?? 0 !! $trim.split(/\s+/)[*-1].Int;
        @!pending = ();
        set-continuation('');
        return Result.new(:ok, :op<exit>, :value<exit>);
    }

    if is-incomplete($src) {
        @!pending = @parts;
        # 0.97.0：把已提交的续行源码交给高亮器——它据此算出「本行开头是否
        # 还在上一行的引号里」，用户敲下一行时才能整行染对色（跨行字符串）。
        set-continuation($src);
        return Result.new(:ok, :op<more>, :value(@parts.elems));
    }
    @!pending = ();
    set-continuation('');
    $!cell-source = $src;      # 供 !finish 记完整多行源码
    self!strict-result(self!eval-raku($src))
}

# ── 渲染：值用 .raku，先 decont 避免 Scalar 多打 $ 前缀 ────────────────
method !fmt($v --> Str) {
    my $x = $v<>;
    (try { $x.raku } // $x.Str) // ''
}

# `ls` / `glob` / `recent` 返回的是 List[IO::Path]，不能按默认 .raku 展示成
# `$(IO::Path.new(...), ...)`。这里给一个 shell `ls` 风格的展示：
#   · 只显示 basename，按名字排序；
#   · 非 TTY / 管道下每行一个（与 ls 管道行为一致）；
#   · TTY 下按 COLUMNS 排成多列（与 ls 默认视觉一致）。
method !render-path-list(@paths --> Str) {
    # 递归 ls 的条目来自不同目录时，只显示 basename 会丢上下文；
    # 这种情况改用相对 cwd 的路径。单目录列表仍保持 shell ls 的 basename。
    my @parents = @paths.map({ .parent.Str }).unique;
    my Str $cwd = $!sys.cwd.Str;
    my Bool $multi = @parents.elems > 1 || @parents.first({ $_ ne $cwd }).defined;

    # 0.74.0 / ADR-0011：每个条目同时保留「纯文本」与「路径」。
    # 列宽、列数、padding 一律按纯文本算 —— 着色只插入零宽转义，
    # 一旦把它算进宽度，多列就会错位。
    my @items = @paths.map(-> $p {
        my Str $plain = $multi
            ?? do {
                my Str $rel = $p.relative($!sys.cwd).Str.subst(:g, '\\', '/');
                $rel.starts-with('..') ?? $p.Str.subst(:g, '\\', '/') !! $rel;
            }
            !! $p.basename;
        %( plain => $plain, path => $p );
    }).sort({ .<plain>.lc });

    return '' unless @items.elems;

    my Bool $tty = $!tty;
    my Bool $color = $tty && self!color-on;

    my &shown = -> $it { paint($it<plain>, path-color($it<path>), $color) };

    return @items.map(&shown).join("\n") unless $tty && @items.elems > 1;

    # 0.88.0：尺寸来自入口查到的真实终端（V-227）。以前读 `%*ENV<COLUMNS>`，
    # 而它不是终端属性：bash 只在交互 shell 里赋值、默认不导出，`resize`
    # 之后还会变陈旧 —— 40 列终端里按 80 列排，输出直接乱序换行。
    my Int $width = $!width > 0 ?? $!width !! 80;
    my Int $max = @items.map({ .<plain>.chars }).max;
    my Int $cols = (($width + 2) div ($max + 2)) max 1;
    return @items.map(&shown).join("\n") if $cols <= 1;

    my Int $rows = (@items.elems + $cols - 1) div $cols;
    my @lines;
    for ^$rows -> $r {
        my @cells;
        for ^$cols -> $c {
            my $i = $r * $cols + $c;
            last if $i >= @items.elems;
            my Str $plain = @items[$i]<plain>;
            @cells.push(shown(@items[$i]) ~ (' ' x ($max - $plain.chars)));
        }
        # 尾部填充是纯空格，替换不会碰到中间的转义序列。
        @lines.push(@cells.join('  ').subst(/\s+$/, ''));
    }
    @lines.join("\n");
}

# help() / registry.names：命令列表给人看，不要显示成 $("...")。
method !render-command-help(@specs --> Str) {
    my Int $w = @specs.map(*.name.chars).max // 0;
    my Bool $c = self!color-on;
    # padding 按纯文本名字长度算；着色不参与对齐。
    @specs.sort({ .name }).map({
        paint(.name, %CLR{'b-cyan'}, $c)
        ~ (' ' x ($w - .name.chars + 2))
        ~ paint(.summary, %CLR<dim>, $c)
    }).join("\n");
}

# env()：按 shell `env` 的习惯输出 KEY=VALUE，而不是 Raku Hash 的 raku 结构。
method !render-env-hash(%h --> Str) {
    my Bool $c = self!color-on;
    %h.keys.sort({ .Str }).map({
        paint($_.Str, %CLR<cyan>, $c) ~ '=' ~ %h{$_}.Str
    }).join("\n");
}

method !render-stat(Stat $s --> Str) {
    my Bool $c = self!color-on;
    # $value 可能是 IO::Path / Int / Bool，统一在这里 stringify —— 原来用
    # 字符串插值自动转了，包成函数后必须显式做。
    my sub k(Str $name, $value --> Str) {
        paint($name, %CLR<dim>, $c) ~ ': ' ~ $value.Str
    }
    my @lines;
    @lines.push(k('path', $s.path));
    @lines.push(k('type', $s.type));
    @lines.push(k('size', $s.size.Str));
    @lines.push(k('mode', '0' ~ $s.mode.fmt('%o'))) if $s.mode > 0;
    # Windows 的 modified 可能是 1969 年假值；不可信就不显示，别给用户看 -0.15。
    my $y2k = Instant.from-posix(946684800);
    @lines.push(k('modified', $s.modified.DateTime.Str))
        if $s.modified.defined && $s.modified >= $y2k;
    @lines.push(k('readable', $s.readable.Str)
                ~ '  ' ~ k('writable', $s.writable.Str)
                ~ '  ' ~ k('executable', $s.executable.Str));
    @lines.join("\n");
}

method !render-write(WriteResult $w --> Str) {
    my Bool $c = self!color-on;
    my Str $text = paint('wrote', %CLR<green>, $c) ~ " {$w.bytes} bytes to {$w.path}";
    $text ~= ' (backup: ' ~ $w.backup ~ ')' if $w.backup.chars;
    $text ~= ' ' ~ paint('[non-atomic]', %CLR<yellow>, $c) unless $w.atomic;
    $text;
}

# 0.74.0 / ADR-0011：入口每格按 config 重算颜色能力后调它。
# 必须同时同步 Shell —— ls 的长格式 / 普通列表在 Shell 里渲染，
# 只改 Session 会出现「路径列表彩色、ls -l 无色」的半截状态。
# 渲染层唯一该问的一句话：开关开着**且**当前 stdout 是终端。
# 只问 $!color 会漏掉管道：`rakuish -e 'ls' | cat` 的 stdout 不是 TTY，
# 混进 ANSI 就违反了 SPEC V-116（管道输出只能是求值结果）。
method !color-on(--> Bool) {
    return False unless $!color;
    $!tty;
}

method set-color(Bool $on --> Nil) {
    $!color = $on;
    $!shell.color = $on if $!shell.defined;
}

# 与 set-color 同理：Shell 也要同步，否则 `clear` 认 TTY、`ls` 认管道。
method set-tty(Bool $on --> Nil) {
    $!tty = $on;
    $!shell.tty = $on if $!shell.defined;
}

# 0.90.0 / ADR-0024：流式开关由入口决定（stdout 是不是真终端）。
# 引擎里恒为 False 的 `live-out` 解决不了这个问题：引擎没有终端，但
# **父进程有** —— 所以「要不要流式」由父进程下发，块通过 chunk-handler 走协议。
method set-stream-out(Bool $on --> Nil) {
    $!stream-out = $on;
    Nil
}

# 把一块输出交给「能看到用户的那一层」：引擎用协议帧，进程内直接打印。
# 两边都不在（测试 / 管道）时静默丢弃 —— 调用方只有在 stream-out 时才走这里。
method !emit-chunk(Str $ch, Str $text --> Nil) {
    return unless $text.chars;
    if &!chunk-handler.defined {
        try { &!chunk-handler($ch, $text) };
    }
    elsif $!stream-out {
        my $handle = $ch eq 'err' ?? $*ERR !! $*OUT;
        try { $handle.print($text); $handle.flush };
    }
    Nil
}

# 尺寸每格同步一次（和 tty / color 同一趟）：用户 `resize` 之后下一格就生效，
# 不需要 SIGWINCH 状态机。0 = 未知，保留上一份有效值。
# 每页行数由终端高度推出（留 2 行给提示符与 "-- more --"）。
# 独立成方法是为了可测：`height` 若没人读，就只是「被存起来的数字」。
method pager-page-size(--> Int) {
    $!height > 2 ?? $!height - 2 !! 20;
}

method set-size(Int :$width = 0, Int :$height = 0 --> Nil) {
    $!width  = $width  if $width  > 0;
    $!height = $height if $height > 0;
    if $!shell.defined {
        $!shell.width  = $!width  if $width  > 0;
        $!shell.height = $!height if $height > 0;
    }
}

method render(Result $r --> Str) {
    my @lines;
    # 0.90.0 / ADR-0024：流式输出的字节已经实时写过，不能再重放。
    @lines.push($r.out.chomp) if !$r.streamed && $r.out.chars;
    # Shell 薄层的 Result 也按普通值展示；exec 的 value 是审计 Hash，不能套。
    # 0.77.0：op 名单从 Shell 的命令表取，不再在这里另抄一份 —— 抄写版漏过
    # doc / pushd / popd / dirs / bookmark（它们的 out 已经自带文本，所以之前
    # 没暴露；但下一次新增命令就会踩）。
    my List $shell-ops = $!shell.shell-command-names;
    my Bool $value-op = $r.op eq 'eval' || ($r.op (elem) $shell-ops);
    my Bool $shell-op = ($r.op (elem) $shell-ops);
    my Bool $shell-value = $r.op eq 'ls' && $r.out.chars == 0;
    if $r.ok && $r.value-defined && $value-op && (!$shell-op || $shell-value) {
        my $v = $r.value;
        # junction 不能进 fmt / smartmatch：Raku 会把参数逐分支喂给函数体。
        # 展示用它自己的 `.raku`（`any(1, 2)`），`_` / `Out[n]` 里仍是原对象。
        $v = $v.raku if $v.WHAT === Junction;
        if $v ~~ Result {
            @lines.push($v.display);
        }
        elsif $v ~~ Rakuish::Data::Table {
            @lines.push($v.to-text);
        }
        elsif $v ~~ Rakuish::Data::Stream {
            # 0.91.0：流的默认展示就是它自己的表格形态（与 Table 一致）。
            # 这里会真的消费一次；一次性来源（游标）被展示后再取会明确报错，
            # 所以 Out[n] 里存的是「已经渲染过的流」，不是可以反复读的东西。
            @lines.push($v.text);
        }
        elsif $r.op eq 'ls' && $v ~~ Positional && $v.elems == 0 {
            # 空目录：shell ls 不打印任何东西
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ IO::Path {
            # ls / glob / recent 的 shell 风格列表
            @lines.push(self!render-path-list($v));
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ CommandSpec {
            # help() 的命令列表
            @lines.push(self!render-command-help($v));
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ Str {
            # registry.names 这类字符串列表，一行一个
            @lines.push($v.join("\n"));
        }
        elsif $v ~~ Str {
            # read / pwd：shell 习惯是直接显示内容/路径，不显示 Raku 引号
            @lines.push($v);
        }
        elsif $v ~~ Hash {
            # env()：shell `env` 风格
            @lines.push(self!render-env-hash($v));
        }
        elsif $v ~~ Stat {
            @lines.push(self!render-stat($v));
        }
        elsif $v ~~ WriteResult {
            @lines.push(self!render-write($v));
        }
        elsif $v ~~ IO::Path {
            # cd / pwd 等单路径结果
            @lines.push($v.Str);
        }
        else {
            @lines.push(paint("Out[{$!index}] =", %CLR<dim>, self!color-on)
                        ~ ' ' ~ self!fmt($v));
        }
    }
    @lines.push(paint('错误: ' ~ $r.err.trim, %CLR<red>, self!color-on)) if $r.err.chars;
    @lines.join("\n")
}

# ── 计时：入口对每一格统一写入，perf 命令读 ─────────────────────────
# 这是「%time 的 Raku 原生替代」的一半：不用文本魔法，耗时是会话数据，
# 既能显示在 prompt 上，也能作为值查（repl.perf-hist）。
method note-timing(Duration $d, Str $src, Bool $ok = True --> Nil) {
    if $!perf {
        @!perf-hist.push([$!index, ($d.Num * 1000).Int, $src.substr(0, 60), $ok]);
    }
}

method perf-report(Int :$limit = 10 --> Str) {
    return '还没有计时记录。' unless @!perf-hist.elems;
    my @rows = @!perf-hist.tail($limit max 1);
    my @lines;
    for @rows -> $row {
        my ($idx, $ms, $src, $ok) = @$row;
        my Str $text = $src.subst(:g, "\n", ' ');
        $text = $text.substr(0, 42) ~ '...' if $text.chars > 43;
        my Str $flag = $ok ?? 'ok' !! 'ERR';
        @lines.push(sprintf('#%-4d %8d ms  %-3s %s', $idx, $ms, $flag, $text));
    }
    my @all = @!perf-hist.map({ .[1] });
    my Str $avg = @all.elems ?? sprintf('%.1f', @all.sum / @all.elems) !! '0';
    my Int  $max = @all.elems ?? @all.max !! 0;
    @lines.push("共 {@!perf-hist.elems} 格 · 平均 {$avg} ms · 最慢 {$max} ms");
    @lines.join("\n")
}

method !cmd-perf(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('perf'),
                          :out($!shell.usage('perf')));
    }
    my Int $n = @args.elems ?? ((try { @args[0].Int }) // 10) !! 10;
    $n = 1   if $n < 1;
    $n = 200 if $n > 200;
    Result.new(:ok, :op<perf>, :value(@!perf-hist.List),
               :out(self.perf-report(:limit($n))))
}

# ── 0.75.0 / ADR-0012 §5：会话日志 ─────────────────────────────────
method log-active(--> Bool) { $!log-on }
method log-path(--> Str)    { $!log-path }
method log-lines(--> List)  { @!log-lines.List }

# 入口主循环每格调一次：那是唯一同时拿得到「输入行 + Result + 渲染文本」的地方。
# Session.render 在 TTY 下会加 ANSI，日志必须纯文本，所以先剥掉 SGR 序列。
method log-line(Str $line, Result $r, Str $rendered --> Nil) {
    return unless $!log-on;
    my Str $plain = $rendered.subst(/ \e \[ <[0..9;]>* m /, :g, '');
    ++$!log-seq;
    my Str $mark = $r.ok ?? '=' !! '!';
    my Str $entry = "[{$!log-seq}] > $line\n[{$!log-seq}] $mark $plain";
    @!log-lines.push($entry);
    if $!log-path.chars {
        try { $!sys.append($!log-path, $entry ~ "\n") };
    }
}

method !cmd-log(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('log'),
                          :out($!shell.usage('log')));
    }
    my Str $sub = @args.elems ?? @args[0].Str !! 'status';
    given $sub {
        when 'start' {
            if @args.elems > 2 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log start [路径]'));
            }
            my Str $path = @args.elems == 2
                ?? @args[1].Str
                !! ((try { $*HOME.add('.rakuish-session.log').Str })
                    // '.rakuish-session.log');
            my $resolved = try { $!sys.resolve($path) };
            unless $resolved.defined {
                return Result.new(:!ok, :code(1), :op<log>,
                                  :err("路径不可用: $path"));
            }
            my Str $header = '# Rakuish 会话日志 · ' ~ DateTime.now.Str ~ "\n";
            my $w = try { $!sys.write($path, $header, :mkdir) };
            unless $w.defined {
                return Result.new(:!ok, :code(1), :op<log>,
                                  :err("无法写日志: $path"));
            }
            $!log-on = True;
            $!log-path = $path;
            $!log-seq = 0;
            @!log-lines = ();
            return Result.new(:ok, :op<log>, :value($path),
                              :out("日志已开启: $path"));
        }
        when 'stop' {
            if @args.elems > 1 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log stop'));
            }
            $!log-on = False;
            my Int $n = @!log-lines.elems;
            my Str $where = $!log-path.chars ?? "（$!log-path）" !! '';
            return Result.new(:ok, :op<log>, :value($n),
                              :out("日志已关闭；共 $n 格$where"));
        }
        when 'show' {
            if @args.elems > 1 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log show'));
            }
            my Str $text = @!log-lines.elems
                ?? @!log-lines.join("\n") !! '（没有记录）';
            return Result.new(:ok, :op<log>, :value(@!log-lines.List),
                              :out($text));
        }
        when 'status' {
            my Str $state = $!log-on
                ?? "日志开启：$!log-path（" ~ @!log-lines.elems ~ ' 格）'
                !! '日志未开启（log start [路径]）';
            return Result.new(:ok, :op<log>, :value($!log-on), :out($state));
        }
        default {
            return Result.new(:!ok, :code(2), :op<log>,
                              :err('用法: log [start [路径]|stop|show]'));
        }
    }
}

# ── 0.66：Vi/Helix 状态、hints、插件（ADR-0003）─────────────────────
method vi(--> ViState)   { vi-state() }
method vi-keys(--> Hash) { vi-actions() }

method hint-text(Str $line = '' --> Str) {
    my Str $t = $line.chars ?? $line
              !! (@!history.elems ?? @!history[*-1] !! '');
    hint-for($t, :shell($!shell), :registry($!commands))
}

# 入口每格调用：失败优先给下一步建议；成功时给一次性的命令用法提示。
method next-hint(Str $line, Result $r --> Str) {
    unless $r.ok {
        my Str $advice = result-hint($r, $line);
        return $advice if $advice.chars;
    }
    my Str $ctx = hint-for($line, :shell($!shell), :registry($!commands));
    return '' unless $ctx.chars;
    my Str $key = $line.trim.words[0] // '';
    return '' if %!hinted{$key}:exists;
    %!hinted{$key} = True;
    $ctx
}

method !cmd-hint(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $h = self.hint-text(@p[1] // '');
    Result.new(:ok, :op<hint>, :value($h),
               :out($h.chars ?? $h !! '（该输入没有上下文提示）'))
}

method !cmd-describe(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $arg = (@p[1] // '').trim;
    my Str $usage = '用法: describe [表名]'
        ~ "\n  无参数：摘要上一格 Table；否则列出已注册 Engine 的表"
        ~ "\n  有参数：describe('表名') 的结构摘要（需先 open-db(...)）";

    my $table;
    if $arg.chars {
        return Result.new(:!ok, :code(2), :op<describe>,
                          :err('还没有会话 Engine，先用 open-db(...) 打开数据库'))
            unless $!engine.defined;
        $table = try { $!engine.describe($arg) };
    }
    else {
        my $last = @!out.elems ?? @!out[*-1] !! Nil;
        if $last ~~ Rakuish::Data::Table {
            $table = try { $last.describe };
        }
        elsif $!engine.defined {
            $table = try { $!engine.tables };
        }
        else {
            return Result.new(:!ok, :code(2), :op<describe>, :err($usage));
        }
    }
    return Result.new(:!ok, :code(2), :op<describe>,
                      :err(($! ?? $!.message !! 'describe 失败').Str))
        unless $table.defined;

    Result.new(:ok, :op<describe>, :value($table),
               :out($table.to-text(:max-rows(50))))
}

method !cmd-plugin(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 3);
    my Str $sub = @p[1] // 'list';
    my Str $arg = (@p[2] // '').trim;
    my Str $usage = '用法: plugin [list|load PATH|unload NAME|info NAME]';
    given $sub {
        when 'list' {
            my $table = $!plugins.list;
            Result.new(:ok, :op<plugin>, :value($table),
                       :out($table.elems ?? $table.to-text !! '（未加载插件）'))
        }
        when 'info' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            Result.new(:ok, :op<plugin>, :value($arg),
                       :out($!plugins.info($arg)))
        }
        when 'load' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $!plugins.load($!sys, $!commands, $arg,
                           :enabled($!plugins.enabled(%!config)))
        }
        when 'unload' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $!plugins.unload($!commands, $arg)
        }
        when 'help' | '--help' | '-?' {
            Result.new(:ok, :op<help>, :value<plugin>, :out($usage))
        }
        default {
            Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
        }
    }
}

method completions(Str $line, Int $pos --> List) {
    # In[n] / Out[n] 结果引用补全（V-285）：引擎侧持有 @!out，命中此形态
    # 就接管；纯函数 + 结果历史长度，无额外 IO。
    my @refs = in-out-completions($line, $pos, @!out.elems);
    return @refs.List if @refs.elems;

    # SQL 字符串上下文优先（纯函数、engine 缺失/异常时返回空），
    # 否则原样交给 Shell；这样 0.68 之前的所有补全行为不变。
    my @sql = sql-completions($line, $pos, :engine($!engine));
    my @c = @sql.elems ?? @sql.List !! $!shell.completions($line, $pos).List;

    # 公共前缀优先（V-278）：多候选共享更长前缀时，Tab 序列首位放前缀
    # 补全（首位无尾随空格），其后才是逐个候选——等价 fish 的「先补最长
    # 公共前缀」。上游 do-complete 按序循环，不动它的循环逻辑。
    if @c.elems > 1 {
        my Str $cp = common-prefix(@c);
        my Str $typed = $line.substr(0, $pos min $line.chars);
        @c = ($cp, |@c) if $cp.chars > $typed.chars;
    }
    @c.List;
}

# ── 错误态标记（0.100.0 / ADR-0034 §2.4 / V-280）────────────────────────
# 纯扫描在 Highlight.error-marks（回调注入）；这里提供真实判定：
# 命令是否已知（usage / 用户层注册表 / PATH 缓存）与路径是否存在。
my %path-names-cache;

method !path-names(--> Set) {
    my Str $path = (%*ENV<PATH> // '').Str;
    return %path-names-cache{$path} if %path-names-cache{$path}:exists;
    my Str $sep = $*DISTRO.is-win ?? ';' !! ':';
    my @exts = $*DISTRO.is-win
        ?? (%*ENV<PATHEXT> // '.COM;.EXE;.BAT;.CMD').split(';')
                .map(*.lc).grep(*.chars).List
        !! ();
    my %names;
    for $path.split($sep) -> $dir {
        next unless $dir.chars;
        my @entries = try { $dir.IO.dir } // ();
        for @entries -> $e {
            my Str $n = $e.basename.lc;
            %names{$n} = True;
            for @exts -> $x {
                if $n.chars > $x.chars && $n.ends-with($x) {
                    %names{$n.substr(0, $n.chars - $x.chars)} = True;
                    last;
                }
            }
        }
    }
    %path-names-cache{$path} = set %names.keys;
}

# 引擎侧名字可见性（V-286）：跨格 sub/class/use 声明（@!decls 的 <name>）
# 与跨格 my 变量（%!state 的带 sigil 键）。消除「上一格定义的无括号
# listop（foo bar）被当成未知命令标红」的误报——这些名字只有引擎知道。
method !known-name(Str $w --> Bool) {
    return True if @!decls.first({ (.<name> // '') eq $w });
    for '$', '@', '%', '&' -> $sigil {
        return True if %!state{"$sigil$w"}:exists;
    }
    False
}

method error-marks(Str $line --> List) {
    error-marks($line,
        known-command => sub (Str $w --> Bool) {
            return True if $!shell.defined && $!shell.usage($w).chars;
            return True if $!commands.defined && $!commands.has($w);
            return True if self!known-name($w);
            so self!path-names(){$w.lc}:exists;
        },
        path-exists => sub (Str $w --> Bool) {
            my Str $p = $w;
            if $p.starts-with('~') && $*HOME.defined {
                $p = $*HOME.Str ~ $p.substr(1);
            }
            my $v = try { $p.IO.e };
            return False unless $v.defined;
            so $v;
        });
}

# ── 快捷键：纯交互动作不占文本命令 ────────────────────────────────────
# 0.75.0 订正：这里只列**真正绑定**的键。曾有 `Ctrl-X Ctrl-E / edit-request`
# 值 API，但 Keymap 从未绑定、入口也不消费；补实现又会撞上 V-125 的
# 「快捷键禁止读写文件、启动进程」的限制已随 Agent 线一并删除（ADR-0019）。
method key-bindings(--> Hash) {
    {
        'Up'          => '历史上一格',
        'Down'        => '历史下一格',
        'Ctrl-R'      => '循环历史检索（首按以当前行为查询串，连按走向更旧的匹配）',
        'CursorRight' => '接受灰字建议（无建议时右移一格）',
        'Ctrl-F'      => '同 CursorRight',
        'ShiftTab'    => '列出补全候选（分栏菜单）',
        'Ctrl-C'      => '中断当前输入 / 清空续行缓冲（不退出）',
        'Ctrl-D'      => '退出会话（EOF）',
        'Tab'         => '补全（命令名 / 选项 / 路径 / SQL 上下文）',
    }
}

method handle-key(Str $key, Str :$query = '', Int :$at --> Result) {
    given $key {
        when 'Ctrl-C' {
            $!interrupt-requested = True;
            @!pending = ();
            set-continuation('');
            Result.new(:ok, :op<key>, :value<interrupted>)
        }
        when 'Ctrl-D' {
            $!exit-requested = True;
            $!exit-code = 0;
            Result.new(:ok, :op<key>, :value<exit>)
        }
        when 'Ctrl-R' {
            my @hits = @!history.grep({ .contains($query) });
            Result.new(:ok, :op<key>, :value(@hits.List))
        }
        when 'Up' | 'Down' {
            my $i = $at.defined ?? $at !! @!history.elems - 1;
            $i = $i - 1 if $key eq 'Up';
            $i = $i + 1 if $key eq 'Down';
            $i = 0 if $i < 0;
            $i = @!history.elems - 1 if $i >= @!history.elems;
            Result.new(:ok, :op<key>,
                       :value(@!history.elems ?? @!history[$i] !! ''))
        }
        default {
            Result.new(:!ok, :code(1), :op<key>,
                       :err("未绑定按键: $key"))
        }
    }
}
