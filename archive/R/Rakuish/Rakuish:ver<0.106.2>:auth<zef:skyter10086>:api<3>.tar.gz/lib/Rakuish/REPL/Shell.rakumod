unit class Rakuish::REPL::Shell;

# Rakuish::REPL::Shell —— REPL 的“日常 shell 观感”薄层。
#
# 它不是第二套 shell 引擎：不执行管道/重定向/子 shell，也不把命令变成
# 字符串协议。它只把最常见的**命令 + 参数**翻译成直接的 Sys 调用，让
# `cd ..`、`ls -la`、`rm -rf`、`cat file` 这类日常输入符合用户习惯。
# 带 `$var`、表达式、引号或非字面参数的输入仍交给 Raku。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::REPL::Chrome;   # 色表与 paint（0.74.0 / ADR-0011）
use Rakuish::REPL::Complete; # 模糊回退 / 公共前缀（0.100.0 / ADR-0034 §2.5）
use Rakuish::Data;
use Rakuish::Data::Table;
use Rakuish::REPL::Introspect;   # 对象内省（0.75.0 / ADR-0012 §3）

has Rakuish::Sys $.sys is required;
# 0.74.0 / ADR-0011：结果着色开关，由 Session 按入口的颜色能力注入。
has Bool $.color is rw = False;
# 0.87.0：同 Session.tty —— 引擎里 `$*OUT` 是管道，必须由入口告知。
has Bool $.tty   is rw = False;
has Int  $.width  is rw = 0;   # 0 = 未知（由 Session.set-size 下发）
# 0.89 / V-228：stdout 是不是真终端（决定能不能逐行流式写）。
# 引擎里是协议管道 → False，必须退回「攒成文本交给父进程打印」。
has Bool $.live-out = False;
has Int  $.height is rw = 0;
# 0.90.0 / ADR-0025：`set -o noglob` / `set -o noexpand` 的执行点。
# 选项本身在 Session 里持有，这里只是缓存——Shell 是薄层，不另开一套配置。
has Bool $.noglob   is rw = False;
has Bool $.noexpand is rw = False;
has IO::Path $.prev-cwd;
# 0.75.0 / ADR-0012 §4：目录栈与书签。和 cd 放一起，避免 Session/Shell 两处状态漂移。
has @!dir-stack;
has %!bookmarks;

# 0.77.0 / ADR-0015 §2：命令名的**单一数据源**。
#
# 此前一个新命令要登记 ~9 处（COMMANDS / SHELL-COMMANDS / usage() / help-index /
# `given` 分发 / OPTIONS / 补全 / 文档），漏一处就是半截状态：`hint` / `plugin`
# 就是这样一直不在 COMMANDS 里，有完整用法、`help hint` 能查，但 Tab 补不出来
# （0.77.0 修的就是这个）。
#
# 现在只在这里声明「名字属于哪一组」，下面全部派生：
#   · COMMANDS / SHELL-COMMANDS；
#   · help-index 的三段分类；
#   · Tab 补全的命令名候选。
# 仍然需要人工维护的只有三处，且各有测试守着：
#   · usage() 的文案（太长，放进表里会淹没结构；t/37 断言每个名字都有用法）
#   · `given $cmd` 的分发体（要调私有方法，无法从数据生成；t/37 双向断言）
#   · OPTIONS 的 flag 清单（只对真解析选项的命令有；t/37 断言键都是已知命令）
my constant COMMAND-GROUPS = %(
    # Shell 薄层真正分发的外部/文件命令（`given $cmd` 里必须有分支）
    shell => <
        cd pwd clear ls cat read rm mkdir cp mv stat echo head tail
        export unset touch glob grep wc help jobs which open
        doc pushd popd dirs bookmark
    >,
    # 会话级命令：在 Session.eval-line 的早返回分支里处理，不经过 Shell 分发
    session => <
        history set alias unalias config hook explore perf hint plugin log describe
    >,
    # 只有 Raku 侧 API、没有同名文本命令的名字；列进 help 供发现
    # 0.97.3：补登记后来新增、此前只在 DSL 里导出导致 help 查不到 / Tab 补不出
    # 的名字（作业 API、受控数据入口、并行/历史工具）。每个都必须有 usage()，
    # t/37 §2.2 守着这条不变量。
    api => < write append exec env ls-table open-data save-data stream
             bg-exec bg-jobs fg bg open-db tty-exec pty-exec peach recent >,
);

my constant COMMANDS = (|COMMAND-GROUPS<shell>, |COMMAND-GROUPS<session>, |COMMAND-GROUPS<api>);

# 真正由 Shell 分发的命令；COMMANDS 还包含会话级与仅 Raku API 的名字。
my constant SHELL-COMMANDS = COMMAND-GROUPS<shell>;

# 0.75.0 / ADR-0012 §2：命令选项的结构化清单（Tab 补全用）。
# usage() 只是人读文本，解析它反推 flag 太脆弱，所以这里单独留一份。
# 只列 Shell 薄层真正会解析的选项；--help / -? 对所有命令通用，补全时补上。
my constant OPTIONS = %(
    'ls'    => [< -a -A -l -h -F -p -R -t -S -r -d -1 --json >],
    'head'  => [< -n >],
    'tail'  => [< -n >],
    'echo'  => [< -n >],
    'mkdir' => [< -p >],
    'cp'    => [< -r -R >],
    'rm'    => [< -r -R -f -n >],
    'grep'  => [< -i -n -v -F -E >],
    'wc'    => [< -l -w -c >],
    'pwd'   => [< -L -P >],
    'open'  => [< --raw --external >],
);

# ── 分词：空格 + 单/双引号 + 反斜杠转义 ─────────────────────────────
method !split(Str $s --> List) {
    my @out;
    my Str $cur = '';
    my Str $quote = '';
    my Bool $esc = False;
    my Bool $started = False;

    for $s.comb -> $c {
        if $quote ne '' {
            if $quote eq '"' && $esc {
                $cur ~= $c;
                $esc = False;
            }
            elsif $quote eq '"' && $c eq '\\' {
                $esc = True;
            }
            elsif $c eq $quote {
                $quote = '';
            }
            else {
                $cur ~= $c;
            }
            $started = True;
            next;
        }
        if $c eq q{'} || $c eq q{"} {
            $quote = $c;
            $started = True;
            next;
        }
        if $c eq '\\' {
            $esc = True;
            $started = True;
            next;
        }
        if $esc {
            $cur ~= $c;
            $esc = False;
            $started = True;
            next;
        }
        if $c ~~ /\s/ {
            if $started {
                @out.push($cur);
                $cur = '';
                $started = False;
            }
            next;
        }
        $cur ~= $c;
        $started = True;
    }
    @out.push($cur) if $started;
    @out.List;
}

method !expand-home(Str $arg --> Str) {
    return $arg if $!noexpand;
    return $arg unless $arg eq '~'
        || $arg.starts-with('~/') || $arg.starts-with('~\\');
    my Str $home = (try { $*HOME.Str }) // '';
    return $arg unless $home.chars;
    $arg eq '~' ?? $home !! $home ~ $arg.substr(1);
}

method !expand-env(@args --> List) {
    return @args.List if $!noexpand;
    my @out;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s ~~ /^ '$' (<[A..Za..z_]> <[A..Za..z0..9_]>*) $/ {
            my $v = $!sys.get-env(~$0);
            @out.push($v.defined ?? $v.Str !! $s);
        }
        else {
            @out.push($s);
        }
    }
    @out.List;
}

method !is-glob(Str $s --> Bool) {
    $s.contains('*') || $s.contains('?');
}

# shell 的 glob 展开；没有匹配时保留原 token（与 shell 一致）。
# 注意：这里只处理 * / ?。brace、字符集、反斜杠转义属于 Sys.glob 的
# 模式语法（见 t/18），Shell 薄层不猜参数：含 { } [ ] 的参数会交回 Raku，
# 且 !split 会把 '\' 当转义前缀吃掉。要用完整语法请写 Raku glob('...')。
method !expand-globs(@args --> List) {
    return @args.List if $!noglob;
    my @out;
    for @args -> $a {
        my Str $s = $a.Str;
        next if $s eq '';
        if self!is-glob($s) {
            my @hits = try { $!sys.glob($s) } // ();
            if @hits.elems {
                @out.append(@hits.map(*.Str));
                next;
            }
        }
        @out.push($s);
    }
    @out.List;
}

method !err(Str $op, Str $msg, Int $code = 1 --> Result) {
    Result.new(:!ok, :$code, :$op, :err($msg));
}

method !ok(Str $op, $value, Str :$out = '', Bool :$no-newline = False --> Result) {
    Result.new(:ok, :$op, :$value, :$out, :$no-newline);
}

method !stat-text(Rakuish::Result::Stat $st --> Str) {
    my @lines;
    @lines.push("path: {self!native-path($st.path.Str)}");
    @lines.push("type: {$st.type}");
    @lines.push("size: {$st.size}");
    @lines.push("mode: 0{$st.mode.fmt('%o')}") if $st.mode > 0;
    my $y2k = Instant.from-posix(946684800);
    @lines.push("modified: {$st.modified.DateTime.Str}")
        if $st.modified.defined && $st.modified >= $y2k;
    @lines.join("\n");
}

method !human-size(Int $n --> Str) {
    return $n.Str if $n < 1024;
    my Str @units = <K M G T P>;
    my Num $v = $n.Num;
    my Int $i = -1;
    while $v >= 1024 && $i < @units.elems - 1 {
        $v /= 1024;
        $i++;
    }
    my Str $num = $v < 10 ?? $v.fmt('%.1f') !! $v.fmt('%.0f');
    $num ~ @units[$i];
}

method !ls-text(@entries, Bool :$classify, Bool :$long, Bool :$human,
                Str :$sort = 'name', Bool :$reverse,
                Bool :$full-paths = False --> Str) {
    # 0.74.0 / ADR-0011：只有 TTY 且入口开了色才上色。着色只作用于名字列
    # （行尾），前面的 size / date 用 fmt 对齐，不受影响。
    my Bool $tty = $!tty;
    my Bool $color = $tty && $!color;

    my @sorted = @entries.sort(-> $a, $b {
        given $sort {
            when 'time' {
                my $am = (try { $!sys.stat($a).modified }) // Instant.from-posix(0);
                my $bm = (try { $!sys.stat($b).modified }) // Instant.from-posix(0);
                $bm <=> $am;
            }
            when 'size' {
                my $as = (try { $!sys.stat($a).size }) // 0;
                my $bs = (try { $!sys.stat($b).size }) // 0;
                $bs <=> $as;
            }
            default { $a.basename.lc cmp $b.basename.lc }
        }
    });
    @sorted = @sorted.reverse if $reverse;

    if $long {
        my @rows;
        for @sorted -> $e {
            my $st = try { $!sys.stat($e) };
            my Str $mode = $st.defined && $st.mode > 0
                ?? '0' ~ $st.mode.fmt('%o') !! '----------';
            my Int $size = $st.defined ?? $st.size !! 0;
            my Str $size-text = $human ?? self!human-size($size) !! $size.Str;
            my Str $date = '';
            if $st.defined && $st.modified.defined
               && $st.modified >= Instant.from-posix(946684800) {
                $date = $st.modified.DateTime.Str.substr(0, 10);
            }
            my Str $kind = $e.d ?? 'd' !! ($e.l ?? 'l' !! '-');
            my Str $name = $full-paths
                ?? $e.relative($!sys.cwd).Str.subst(:g, '\\', '/')
                !! $e.basename;
            $name ~= '/' if $classify && $e.d;
            @rows.push($kind ~ ' ' ~ $mode ~ ' ' ~ $size-text.fmt('%8s')
                       ~ ' ' ~ $date ~ ' ' ~ paint($name, path-color($e), $color));
        }
        return @rows.join("\n");
    }
    my @names = @sorted.map({
        my Str $name = $full-paths
            ?? .relative($!sys.cwd).Str.subst(:g, '\\', '/')
            !! .basename;
        $name ~= '/' if $classify && .d;
        paint($name, path-color($_), $color)
    });
    @names.join("\n");
}

method !ls-tree(@paths, Bool :$all, Bool :$classify, Bool :$long,
                 Bool :$human, Str :$sort = 'name', Bool :$reverse,
                 Bool :$full-paths = False,
                 :&emit --> Hash) {
    my @blocks;
    my @all;
    my sub block(Str $s) {
        if &emit.defined { emit($s) } else { @blocks.push($s) }
    }
    my sub walk(IO::Path $d) {
        my @entries = try { $!sys.ls($d, :$all, :!recursive) } // ();
        @all.append(@entries) unless &emit.defined;
        my Str $label = $d.relative($!sys.cwd).Str;
        $label = '.' unless $label.chars;
        block("{$label}:");
        my Str $body = self!ls-text(@entries, :$classify, :$long,
                                     :$human, :$sort, :$reverse,
                                     :$full-paths);
        block($body) if $body.chars;
        for @entries.grep({ $_.d && !$_.l }).sort({ .basename.lc }) -> $child {
            walk($child);
        }
    }
    for @paths -> $path {
        my $p = try { $!sys.resolve($path) };
        next unless $p.defined;
        if $p.d && !$p.l {
            walk($p);
        }
        else {
            @all.push($p) unless &emit.defined;
            my Str $body = self!ls-text(($p,), :$classify, :$long,
                                        :$human, :$sort, :$reverse,
                                        :$full-paths);
            block($body) if $body.chars;
        }
    }
    { blocks => @blocks.List, entries => @all.List };
}

method !cmd-ls(@args --> Result) {
    my Bool $all = False;
    my Bool $long = False;
    my Bool $recursive = False;
    my Bool $classify = False;
    my Bool $human = False;
    my Bool $reverse = False;
    my Bool $dirs-as-files = False;
    my Bool $json = False;
    my Str $sort = 'name';
    my @paths;

    for @args -> $a {
        my Str $s = $a.Str;
        if $s eq '--json' { $json = True; next }
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'a' | 'A' { $all = True }
                    when 'l' { $long = True }
                    when 'R' { $recursive = True }
                    when 'F' | 'p' { $classify = True }
                    when 'h' { $human = True }
                    when 'r' { $reverse = True }
                    when 't' { $sort = 'time' }
                    when 'S' { $sort = 'size' }
                    when 'd' { $dirs-as-files = True }
                    when 'j' { $json = True }
                    when '1' | 'C' | 'x' { } # 默认列/一行；-C 不需要额外处理
                    default {
                        return self!err('ls', "不支持的 ls 选项: -{$f}");
                    }
                }
            }
        }
        else {
            @paths.push($s);
        }
    }

    my @input-paths = @paths.elems ?? @paths !! ('.');
    if $recursive && !$json {
        my %tree;
        if $!live-out {
            # 终端模式：每找到一个目录就输出并 flush，不再等整棵树。
            # 判 live-out 而不是 tty：引擎里 stdout 是协议管道，往那里
            # 写会在 JSON 流里插入表格/路径文本（0.87 的同类回归）。
            %tree = self!ls-tree(@input-paths, :$all, :$classify,
                :$long, :$human, :$sort, :$reverse,
                :emit(-> Str $s { $*OUT.print($s ~ "\n"); $*OUT.flush }));
            return self!ok('ls', (), :out(''));
        }
        %tree = self!ls-tree(@input-paths, :$all, :$classify,
            :$long, :$human, :$sort, :$reverse, :full-paths);
        return self!ok('ls', %tree<entries>,
                       :out(%tree<blocks>.join("\n\n")));
    }

    my @entries;
    for @input-paths -> $path {
        if $dirs-as-files {
            if self!is-glob($path) {
                @entries.append(try { $!sys.glob($path) } // ());
            }
            else {
                my $p = try { $!sys.resolve($path) };
                return self!err('ls', $!.message) unless $p.defined;
                @entries.push($p);
            }
        }
        elsif self!is-glob($path) {
            @entries.append(try { $!sys.glob($path) } // ());
        }
        else {
            my $r = try { $!sys.ls($path, :$all, :$recursive) };
            return self!err('ls', $!.message) unless $r.defined;
            @entries.append($r.List);
        }
    }
    if $json {
        my @rows;
        for @entries -> $e {
            my $st = try { $!sys.stat($e) };
            my Str $type = $e.l ?? 'symlink' !! ($e.d ?? 'dir' !! 'file');
            my Str $modified = '';
            if $st.defined && $st.modified.defined
               && $st.modified >= Instant.from-posix(946684800) {
                $modified = $st.modified.DateTime.Str;
            }
            @rows.push({
                name => $e.basename, type => $type,
                size => ($st.defined ?? $st.size !! 0),
                modified => $modified, path => $e.Str,
            });
        }
        my $table = Rakuish::Data::Table.from-rows(@rows);
        return self!ok('ls', $table, :out($table.to-json(:pretty)));
    }
    my Str $text = ($long || $classify || $reverse || $sort ne 'name')
        ?? self!ls-text(@entries, :$classify, :$long, :$human, :$sort, :$reverse)
        !! '';
    self!ok('ls', @entries.List, :out($text));
}

# 0.102.0：`cat` / `read` 也接受 `--max-bytes=N`（K/M/G 后缀，1024 进制）。
# 以前只有 API 能抬上限，shell 用户看到「读取超限」后只能改用 Raku 调用；
# 而 `cat` / `read` 恰恰是最可能撞上大文件的两个入口。
my sub parse-size(Str $s --> Int) {
    my Str $t = $s.trim;
    return $t.Int if $t ~~ /^\d+$/;
    if $t.chars >= 2 {
        my Str $unit = $t.substr(* - 1).lc;
        my Str $num  = $t.substr(0, * - 1);
        if $unit ~~ /^<[kmg]>$/ && $num ~~ /^\d+ ['.' \d+]?$/ {
            my Int $mul = $unit eq 'k' ?? 1024
                        !! $unit eq 'm' ?? 1024 * 1024
                        !!                 1024 * 1024 * 1024;
            return ($num.Num * $mul).Int;
        }
    }
    -1;   # 非法：让调用方报用法，不要静默当成“没有上限”
}

    method !split-read-opts(@args --> List) {
    my Int $cap;
    my Str $enc;
    my @rest;
    my @a = @args.List;
    my Int $i = 0;
    while $i < @a.elems {
        my Str $s = @a[$i].Str;
        if $s eq '--max-bytes' && $i + 1 < @a.elems {
            $cap = parse-size(@a[$i + 1].Str);
            $i += 2;
            next;
        }
        if $s ~~ /^'--max-bytes='(.+)$/ {
            $cap = parse-size($0.Str);
            $i++;
            next;
        }
        # 0.104.0：--enc 走 Sys 的编码别名（gbk→gb18030 等）。
        if $s eq '--enc' && $i + 1 < @a.elems {
            $enc = @a[$i + 1].Str;
            $i += 2;
            next;
        }
        if $s ~~ /^'--enc='(.+)$/ {
            $enc = $0.Str;
            $i++;
            next;
        }
        @rest.push(@a[$i]);
        $i++;
    }
    ($cap, $enc, @rest.List);
}

method !cmd-cat(@args --> Result) {
    my ($cap, $enc, @files) = self!split-read-opts(@args);
    return self!err('cat', '用法: cat [--max-bytes=N] [--enc=编码] 文件...') unless @files.elems;
    return self!err('cat', '--max-bytes 需要正整数（支持 K/M/G）')
        if $cap.defined && $cap <= 0;
    my Str $text = '';
    for self!expand-globs(@files) -> $p {
        my $v = $cap.defined
            ?? (try { $!sys.read($p, :max-bytes($cap), :enc($enc // 'utf-8')) })
            !! (try { $!sys.read($p, :enc($enc // 'utf-8')) });
        unless $v.defined {
            my Str $msg = $!.message;
            # 0.102.0：底层只说 Raku 调用（read(..., :max-bytes(N))），但用户敲的是
            # cat/read，直接告诉他本命令也能抬。
            $msg ~= "\n  · 本命令也能抬：cat --max-bytes=64M {$p}"
                if $msg.contains('读取超限');
            return self!err('cat', $msg);
        }
        $text ~= $v.Str;
    }
    self!ok('cat', $text, :out($text));
}

method !cmd-read(@args --> Result) {
    my ($cap, $enc, @files) = self!split-read-opts(@args);
    return self!err('read', '用法: read [--max-bytes=N] [--enc=编码] 文件...') unless @files.elems;
    return self!err('read', '--max-bytes 需要正整数（支持 K/M/G）')
        if $cap.defined && $cap <= 0;
    my Str $text = '';
    for self!expand-globs(@files) -> $p {
        my $v = $cap.defined
            ?? (try { $!sys.read($p, :max-bytes($cap), :enc($enc // 'utf-8')) })
            !! (try { $!sys.read($p, :enc($enc // 'utf-8')) });
        unless $v.defined {
            my Str $msg = $!.message;
            $msg ~= "\n  · 本命令也能抬：read --max-bytes=64M {$p}"
                if $msg.contains('读取超限');
            return self!err('read', $msg);
        }
        $text ~= $v.Str;
    }
    self!ok('read', $text, :out($text));
}

# 所有「改当前目录」的入口都过这里：cd / pushd / popd / bookmark go。
# 只此一处更新 prev-cwd，cd - 才不会和目录栈各说各话。
method !change-dir(Str $target, Str $op = 'cd' --> Result) {
    my $old = $!sys.cwd;
    my $p = try { $!sys.cd($target) };
    return self!err($op, $!.message) unless $p.defined;
    $!prev-cwd = $old;
    self!ok($op, $p, :out(''));
}

method !cmd-cd(@args --> Result) {
    return self!err('cd', '用法: cd [目录|-]') if @args.elems > 1;
    my Str $target;
    if @args.elems == 0 {
        $target = (try { $*HOME.Str }) // '';
        return self!err('cd', '无法确定 HOME') unless $target.chars;
    }
    elsif @args[0] eq '-' {
        return self!err('cd', '没有上一个目录') unless $!prev-cwd.defined;
        $target = $!prev-cwd.Str;
    }
    else {
        $target = self!expand-home(@args[0].Str);
    }
    self!change-dir($target, 'cd');
}

# ── 0.75.0 / ADR-0012 §3：doc 内省 ─────────────────────────────────
method !cmd-doc(@args --> Result) {
    return self!err('doc', '用法: doc <命令名|Raku 名字>') unless @args.elems == 1;
    my Str $name = @args[0].Str;
    # 内置命令优先：usage() 是权威帮助，比元对象自省有用得多。
    my Str $usage = self.usage($name);
    return self!ok('doc', $name, :out($usage.trim-trailing)) if $usage.chars;
    my %info = introspect($name);
    return self!err('doc', %info<reason>) unless %info<ok>;
    self!ok('doc', $name, :out(%info<text>));
}

# ── 0.75.0 / ADR-0012 §4：目录栈与书签 ─────────────────────────────
method !cmd-pushd(@args --> Result) {
    return self!err('pushd', '用法: pushd 目录') unless @args.elems == 1;
    my $old = $!sys.cwd;
    my $r = self!change-dir(self!expand-home(@args[0].Str), 'pushd');
    return $r unless $r.ok;
    @!dir-stack.push($old);
    self!ok('pushd', $!sys.cwd, :out("入栈 $old（" ~ @!dir-stack.elems ~ ' 层）'));
}

method !cmd-popd(@args --> Result) {
    return self!err('popd', '用法: popd') if @args.elems;
    return self!err('popd', '目录栈为空') unless @!dir-stack.elems;
    my Str $target = @!dir-stack.pop.Str;
    my $r = self!change-dir($target, 'popd');
    return $r unless $r.ok;
    self!ok('popd', $!sys.cwd, :out("返回 $target"));
}

method !cmd-dirs(@args --> Result) {
    return self!err('dirs', '用法: dirs') if @args.elems;
    my @lines = @!dir-stack.kv.map(-> $i, $path { "$i: {$path.Str}" });
    @lines.push(@!dir-stack.elems ~ ': ' ~ $!sys.cwd.Str ~ '  (当前)');
    self!ok('dirs', @lines.List, :out(@lines.join("\n")));
}

method !cmd-bookmark(@args --> Result) {
    my Str $help = '用法: bookmark add NAME [DIR] | list | go NAME | del NAME';
    return self!err('bookmark', $help) unless @args.elems >= 1;
    my Str $sub = @args[0].Str;
    given $sub {
        when 'add' {
            return self!err('bookmark', $help)
                unless @args.elems == 2 || @args.elems == 3;
            my Str $name = @args[1].Str;
            return self!err('bookmark', '书签名字只能是字母/数字/下划线')
                unless $name ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/;
            my Str $dir = @args.elems == 3
                ?? self!expand-home(@args[2].Str) !! $!sys.cwd.Str;
            %!bookmarks{$name} = $dir;
            return self!ok('bookmark', $dir, :out("书签 $name → $dir"));
        }
        when 'list' {
            return self!err('bookmark', $help) if @args.elems > 1;
            my @lines = %!bookmarks.keys.sort.map({
                $_ ~ ' → ' ~ %!bookmarks{$_}.Str
            });
            return self!ok('bookmark', @lines.List,
                           :out(@lines.elems ?? @lines.join("\n") !! '（没有书签）'));
        }
        when 'go' {
            return self!err('bookmark', $help) unless @args.elems == 2;
            my Str $name = @args[1].Str;
            return self!err('bookmark', "没有书签: $name")
                unless %!bookmarks{$name}:exists;
            my Str $dir = %!bookmarks{$name}.Str;
            my $r = self!change-dir($dir, 'bookmark');
            return $r unless $r.ok;
            return self!ok('bookmark', $!sys.cwd, :out("→ $dir"));
        }
        when 'del' {
            return self!err('bookmark', $help) unless @args.elems == 2;
            my Str $name = @args[1].Str;
            return self!err('bookmark', "没有书签: $name")
                unless %!bookmarks{$name}:exists;
            %!bookmarks{$name}:delete;
            return self!ok('bookmark', $name, :out("已删除书签 $name"));
        }
        default {
            return self!err('bookmark', $help ~ "；未知子命令: $sub");
        }
    }
}

method !native-path(Str $p --> Str) {
    $*DISTRO.is-win ?? $p.subst(:g, '/', '\\') !! $p;
}

# 0.77.0：索引由 COMMAND-GROUPS 生成，不再手写名单 —— 手写名单正是
# `hint` / `plugin` 被漏掉的地方（它们有 usage，却不在任何一张表里）。
# 命令名清单的对外视图（0.77.0 / ADR-0015 §2）。
# 渲染层要判「这个 op 是不是 Shell 薄层的」，以前在 Session 里另抄一份名单，
# 0.75 新增的 doc / pushd / popd / dirs / bookmark 因此一直没跟上。
# 从这里取，抄写点归零。
method command-names(--> List)       { COMMANDS.List }
method shell-command-names(--> List) { SHELL-COMMANDS.List }

method !help-index(--> Str) {
    my sub block(Str $title, @names --> Str) {
        my @lines;
        my @cur;
        # 0.89.0：宽度已知就按真实终端折行（原本硬编码 62 —— 40 列终端会溢出，
        # 120 列终端又白白浪费半屏）。未知时保持 62，与手写版观感一致。
        my Int $limit = $!width > 0 ?? (($!width - 4) max 32) !! 62;
        my Int $width = 0;
        for @names -> $n {
            # 按累计宽度折行，保持和手写版一致的 4 空格缩进观感。
            if @cur && $width + $n.chars + 1 > $limit {
                @lines.push('  ' ~ @cur.join(' '));
                @cur = ();
                $width = 0;
            }
            @cur.push($n);
            $width += $n.chars + 1;
        }
        @lines.push('  ' ~ @cur.join(' ')) if @cur;
        $title ~ ":\n" ~ @lines.join("\n");
    }

    my Str $shell   = block('Shell 日常命令', COMMAND-GROUPS<shell>);
    my Str $session = block('会话级命令', COMMAND-GROUPS<session>);
    my Str $api     = block('Raku / 文件 API', COMMAND-GROUPS<api>);

    # 注意 `{ ... }` 不能写进双引号串：Raku 会把 `{...}` 当代码块求值，
    # 而 `...` 是 stub 操作符 —— 直接抛 "Stub code executed"。用 q[] 保住字面量。
    my Str $text = $shell ~ "\n\n" ~ $session ~ "\n\n" ~ $api ~ "\n\n"
    ~ "计时（Raku 原生，不是 magic）:\n"
    ~ q[  timed { ... } / bench({ ... }, :repeat(5)) / perf] ~ "\n\n"
    ~ "用 `help <命令>` 或 `<命令> --help` 查看具体参数。";

    # 命令块已经按名字折过行，但**散文行**（计时示例、结尾提示）是整句，
    # 窄终端下照样溢出。最后统一按空格折一遍：续行缩进 2，和命令块同观感。
    my Int $limit = $!width > 0 ?? (($!width - 4) max 32) !! 0;
    return $text unless $limit > 0;

    my @out;
    for $text.lines -> $line {
        if $line.chars <= $limit {
            @out.push($line);
            next;
        }
        # 保留原缩进：散文行以两个空格开头，折行后不该把缩进吃掉。
        my Str $indent = $line ~~ /^ (\s*) / ?? $0.Str !! '';
        my Str $cur = '';
        for $line.split(' ', :skip-empty) -> $word {
            if $cur.chars && $cur.chars + 1 + $word.chars > $limit {
                @out.push($cur);
                $cur = $indent ~ '  ' ~ $word;
            }
            else {
                $cur = $cur.chars ?? $cur ~ ' ' ~ $word !! $indent ~ $word;
            }
        }
        @out.push($cur) if $cur.chars;
    }
    @out.join("\n");
}

method usage(Str $cmd --> Str) {
    given $cmd {
        when 'cd' { q:to/USAGE/
        用法: cd [目录|-]
          cd           回到 $*HOME
          cd ..        上一级
          cd -         上一个目录
          cd ~/x       展开家目录
        USAGE
        }
        when 'pwd' { "用法: pwd [-L|-P]\n  显示当前会话目录（当前实现两种都等价）" }
        when 'clear' { "用法: clear\n  清屏；非 TTY 下不输出控制码" }
        when 'history' { "用法: history\n  显示本会话已执行的命令行（带编号）" }
        when 'hint' { "用法: hint [输入行]\n  查看该输入的上下文提示；不带参数查上一格\n  config set hints on|off 控制 TTY 下自动显示" }
        when 'plugin' { "用法: plugin [list|load PATH|unload NAME|info NAME]\n  加载显式本地 Raku 插件（返回 Command 对象）；需 config set plugins on\n  加载即执行本地 Raku 代码，只加载可信文件；Agent 不开放" }
        when 'which' { "用法: which 命令\n  查 Shell 内置或 PATH 上的外部命令" }
        when 'alias' { "用法: alias [name=command]\n  查看或设置会话别名（写入 ~/.rakuish-config.json）" }
        when 'unalias' { "用法: unalias name\n  删除别名" }
        when 'config' { "用法: config [get KEY|set KEY VALUE|unset KEY]\n  查看/修改会话配置" }
        when 'hook' { "用法: hook [add EVENT CODE|clear EVENT|run EVENT]\n  管理启动等事件 hook（写入配置）" }
        when 'explore' { "用法: explore [路径]\n  分页查看上一格 Table，或从 JSON/CSV/目录加载" }
        when 'set' { "用法: set [-e|+e] | set -o NAME | set +o NAME | set -o\n  errexit（同 -e）· histexpand · noglob · noexpand · xtrace\n  不带参数或 -o 单独出现时列出全部选项" }
        when 'jobs' { "用法: jobs\n  列出本会话通过 sys.spawn 启动的后台进程" }
        when 'ls' {
            q:to/USAGE/
        用法: ls [选项] [路径...]
          -a, -A        显示隐藏项
          -l            长格式（类型/权限/大小/日期/名称）
          -h            人类可读大小（配合 -l）
          -F, -p        目录后加 /
          -R            递归
          -t            按修改时间排序
          -S            按大小排序
          -r            反向排序
          -d            只列目录本身
          -1            一行一个
          --json        输出结构化 JSON（name/type/size/modified/path）
        USAGE
        }
        when 'open' { "用法: open [--raw] [--external] 文件\n  .json → Record/Table；.csv → Table；.parquet/.pq → Table（必须 --external）；其它按文本\n  CSV 方言参数只在 Raku 层：open-data(path, :allow-external, :csv-options(...))" }
        when 'cat' { "用法: cat [--max-bytes=N] [--enc=编码] 文件...\n  原样输出文件内容；N 支持 K/M/G（默认上限 1 MiB）。\n  编码默认 utf-8；GBK/GB2312 用 --enc=gbk（内部按 gb18030 解码）" }
        when 'head' { "用法: head [-n N] 文件\n  输出前 N 行（默认 10）" }
        when 'tail' { "用法: tail [-n N] [-f|--follow] 文件\n  输出后 N 行（默认 10；-n 0 只看新增）\n  -f 轮询跟随新增内容，Ctrl-C 停止；截断 / 轮转替换后从新内容继续\n  跟随的行实时显示，不重复进结果" }
        when 'echo' { "用法: echo [-n] 文字...\n  输出参数，空格分隔；参数中的 \$NAME 按会话 env 展开" }
        when 'mkdir' { "用法: mkdir [-p] 目录...\n  创建目录" }
        when 'touch' { "用法: touch 文件...\n  文件不存在时创建空文件" }
        when 'cp' { "用法: cp [-r] 源 目标\n  -r, -R 复制目录树" }
        when 'mv' { "用法: mv 源 目标\n  移动/重命名；目标存在时覆盖" }
        when 'rm' { "用法: rm [-r] [-f] [-n] 路径...\n  -r, -R 递归\n  -f 不存在也成功\n  -n dry-run" }
        when 'stat' { "用法: stat 路径\n  显示 path/type/size/mode/modified" }
        when 'export' { "用法: export KEY=VALUE...\n  写入会话 env" }
        when 'unset' { "用法: unset KEY...\n  删除会话 env 变量" }
        when 'glob' {
            '用法: glob 模式 [目录]' ~ "\n"
              ~ '  * 不跨目录；? 单字符；**/ 任意深度；[a-z] 字符集；{a,{b,c}} 嵌套 brace' ~ "\n"
              ~ '  反斜杠转义请写 Raku glob(...)；Shell 薄层会把 \ 当转义前缀吃掉'
        }
        when 'grep' { "用法: grep [-inv] [-F|-E] 模式 文件...\n  -i 忽略大小写\n  -n 行号\n  -v 反向匹配\n  -F 字面量，-E 正则（默认）" }
        when 'wc' { "用法: wc [-l] [-w] [-c] 文件...\n  -l 行数，-w 词数，-c 字符数" }
        when 'read' { "用法: read [--max-bytes=N] [--enc=编码] 文件...\n  原样读取文本文件（与 cat 同源）；N 支持 K/M/G。\n  编码默认 utf-8；GBK/GB2312 用 --enc=gbk。二进制请用 sys.read(路径, :bin)" }
        when 'write' { "用法: write(路径, 数据) [:append] [:mkdir] [:backup] [:atomic]\n  Raku 调用（不是 shell 命令，不支持 > 重定向）；写入文件，默认原子替换" }
        when 'append' { "用法: append(路径, 数据)\n  Raku 调用；追加写入，不宣称原子" }
        when 'exec' { "用法: exec 程序 [参数...]\n  argv-only，不经过 shell；返回 Result" }
        when 'env' { "用法: env\n  显示会话环境变量（KEY=VALUE）" }
        when 'ls-table' { "用法: ls-table [路径]\n  返回 Rakuish::Data::Table（name/type/size/modified/path）" }
        when 'open-data' { "用法: open-data 文件 [--raw] [:allow-external] [:csv-options]\n  .parquet/.pq 需 :allow-external；.csv + :allow-external 可传 delimiter/quote/escape/header/skip/all-varchar/nullstr" }
        when 'save-data' { "用法: save-data 文件 值 [:allow-external] [:csv-options]\n  按扩展名写 JSON/CSV/Parquet；写出方言仅支持 delimiter/quote/escape/header/nullstr" }
        when 'stream' { "用法: stream 值 [:format<lines|csv|tsv|json|jsonl|pattern>] [:pattern(正则)] [:names(...)]\n  结构化管道的入口：文本 / Result / Table / Cursor → 惰性记录流\n  阶段：.where .select .sort-by .unique .count-by .group-by .limit .skip .add-column .drop .map\n  两条流：.zip(另一条) .join(另一条, :on<列>, :how<inner|left|right|outer>)\n  收拢：.interleave(另一条, :shortest) .append(另一条)（每行原样、不改列名）\n  出口：.table .text .json .csv .lines .count .sum .exec（边算边写 stdin） .tee(路径)" }
        when 'bg-exec' { "用法: bg-exec('命令', 参数...)\n  POSIX-only：后台起作业并立即返回 Result，job id 在 .value<job>。\n  子进程继承真终端、自成进程组；Windows 返回 code=127。" }
        when 'bg-jobs' { "用法: bg-jobs()\n  列出当前后台作业，返回 Table（id/state/exe/cmd/pid/pgid/exit/since）。\n  注意与文本命令 `jobs`（捕获式后台）区分。" }
        when 'fg' { "用法: fg(job-id)\n  把后台作业带回前台并等待；Ctrl-Z 停住时归还前台并返回 state=stopped，不卡死。\n  job-id 来自 bg-exec().value<job>。" }
        when 'bg' { "用法: bg(job-id)\n  让已挂起（stopped）的作业在后台继续（SIGCONT），不切前台。" }
        when 'open-db' { "用法: open-db(':memory:'|:file:', :engine<duckdb|sqlite>, :!read-only, :!safe)\n  注册会话 Engine 供 describe / SQL 补全用；duckdb 需 zef install DB::DuckDB，\n  sqlite 需 DB::SQLite。受控引擎默认只读、禁外部文件。" }
        when 'tty-exec' { "用法: tty-exec('命令', 参数...)\n  TTY 直通运行交互式子进程：继承真终端、前台进程组交接、无 30s 超时。\n  POSIX 用 tcsetpgrp 切前台；适合嵌套 REPL / 编辑器。" }
        when 'pty-exec' { "用法: pty-exec('命令', 参数...)\n  在伪终端里跑子进程并捕获输出（与 tty-exec 的直通不同）。\n  返回 Result，stdout 在 .out，适合要看 TTY 行为的程序。" }
        when 'peach' { "用法: peach(@items, &code, :degree(4))\n  并行 map：按 degree 并发处理列表，保持输入顺序返回结果。" }
        when 'recent' { "用法: recent(7, 'md', :path('.'))\n  列出指定路径下最近改动过的 .md 文件（按扩展名过滤），返回路径列表。" }
        when 'describe' { "用法: describe [表名]\n  返回结构化 Table（name/type/nullable/non_null/distinct/total/sample）\n  无参数摘要上一格 Table；有参数需先 open-db(...)" }
        when 'perf' { "用法: perf [N]\n  显示最近 N 格耗时（默认 10，上限 200）与平均/最慢；耗时由 prompt 同源数据记录" }
        when 'help' { "用法: help [命令]\n  不带参数列出全部内置命令；带命令显示该命令帮助" }
        when 'doc' { "用法: doc <命令名|Raku 名字>\n  命令名显示 usage()；Raku 名字显示类型/WHY/签名/方法（零 EVAL，看不到跨格 my/our）" }
        when 'pushd' { "用法: pushd 目录\n  把当前目录压栈后切换；popd 返回" }
        when 'popd' { "用法: popd\n  弹栈顶并切回；栈空时报错" }
        when 'dirs' { "用法: dirs\n  列出目录栈与当前目录" }
        when 'bookmark' { "用法: bookmark add NAME [DIR] | list | go NAME | del NAME\n  会话内目录书签，不落盘" }
        when 'log' { "用法: log [start [路径]|stop|show]\n  会话日志：记录每格输入与结果（纯文本，写文件经 Sys）；默认 ~/.rakuish-session.log" }
        default { '' }
    }
}

method !cmd-pwd(@args --> Result) {
    for @args -> $a {
        return self!err('pwd', "不支持的 pwd 选项: {$a.Str}")
            unless $a.Str eq '-L' || $a.Str eq '-P';
    }
    my Str $p = self!native-path($!sys.cwd.Str);
    self!ok('pwd', $p, :out($p));
}

method !cmd-clear(@args --> Result) {
    return self!err('clear', 'clear 不接受参数') if @args.elems;
    # 只在真实 TTY 下发送 ANSI；管道/重定向时不污染输出。
    # `$!tty` 由入口传入（0.87.0）：引擎子进程的 `$*OUT` 是管道，
    # 用 `$*OUT.t` 判定会让 `clear` 在 REPL 里静默失效。
    self!ok('clear', '', :out($!tty ?? "\e[2J\e[H" !! ''));
}

method !cmd-rm(@args --> Result) {
    my Bool $recursive = False;
    my Bool $force = False;
    my Bool $dry = False;
    my @paths;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'r' | 'R' { $recursive = True }
                    when 'f' { $force = True }
                    when 'n' { $dry = True }
                    default { return self!err('rm', "不支持的 rm 选项: -{$f}") }
                }
            }
        }
        else { @paths.push($s) }
    }
    return self!err('rm', '用法: rm [-r] [-f] 路径...') unless @paths.elems;

    my Int $count = 0;
    my @outs;
    for self!expand-globs(@paths) -> $p {
        my $r = try { $!sys.rm($p, :$recursive, :$force, :dry-run($dry)) };
        return self!err('rm', $!.message) unless $r.defined;
        return $r unless $r.ok;
        $count += ($r.value // 0).Int;
        @outs.push($r.out) if $r.out.chars;
    }
    self!ok('rm', $count, :out(''));
}

method !cmd-mkdir(@args --> Result) {
    my @paths;
    for @args -> $a {
        if $a.Str eq '-p' || $a.Str eq '--parents' { next }
        return self!err('mkdir', "不支持的 mkdir 选项: {$a.Str}")
            if $a.Str.starts-with('-');
        @paths.push($a.Str);
    }
    return self!err('mkdir', '用法: mkdir [-p] 目录...') unless @paths.elems;
    my @made;
    for @paths -> $p {
        my $r = try { $!sys.mkdir($p) };
        return self!err('mkdir', $!.message) unless $r.defined;
        return $r unless $r.ok;
        @made.push($r.value // $p);
    }
    self!ok('mkdir', @made.List, :out(''));
}

method !cmd-cp(@args --> Result) {
    my Bool $recursive = False;
    my @paths;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s eq '-r' || $s eq '-R' || $s eq '--recursive' {
            $recursive = True;
        }
        elsif $s.starts-with('-') {
            return self!err('cp', "不支持的 cp 选项: {$s}");
        }
        else { @paths.push($s) }
    }
    return self!err('cp', '用法: cp [-r] 源 目标') unless @paths.elems == 2;
    my $r = try { $!sys.cp(@paths[0], @paths[1], :$recursive) };
    return self!err('cp', $!.message) unless $r.defined;
    return $r unless $r.ok;
    self!ok('cp', $r.value, :out(''));
}

method !cmd-mv(@args --> Result) {
    return self!err('mv', '用法: mv 源 目标') unless @args.elems == 2;
    my $r = try { $!sys.mv(@args[0], @args[1]) };
    return self!err('mv', $!.message) unless $r.defined;
    return $r unless $r.ok;
    self!ok('mv', $r.value, :out(''));
}

method !cmd-stat(@args --> Result) {
    return self!err('stat', '用法: stat 路径') unless @args.elems == 1;
    my $st = try { $!sys.stat(@args[0]) };
    return self!err('stat', $!.message) unless $st.defined;
    self!ok('stat', $st, :out(self!stat-text($st)));
}

method !cmd-echo(@args --> Result) {
    my Bool $no-newline = False;
    my @words;
    for @args -> $a {
        if $a.Str eq '-n' && !$no-newline { $no-newline = True; next }
        @words.push($a.Str);
    }
    my Str $text = @words.join(' ');
    self!ok('echo', $text, :out($text), :no-newline($no-newline));
}

method !cmd-head-tail(Str $op, @args --> Result) {
    my Int $n = 10;
    my Str $file = '';
    my Bool $follow = False;
    my Int $i = 0;
    while $i < @args.elems {
        my Str $a = @args[$i].Str;
        if $a eq '-n' {
            return self!err($op, '用法: head|tail [-n N] [-f] 文件') if $i + 1 >= @args.elems;
            $n = @args[$i + 1].Int;
            $i += 2;
        }
        elsif $a eq '-f' || $a eq '--follow' {
            return self!err($op, 'head 不支持 -f（跟随请用 tail -f）') if $op ne 'tail';
            $follow = True;
            $i++;
        }
        elsif $a ~~ /^ '-' [ (\d+) 'f' | 'f' (\d+) ] $/ {
            return self!err($op, 'head 不支持 -f（跟随请用 tail -f）') if $op ne 'tail';
            $n = ($0 // $1).Int;
            $follow = True;
            $i++;
        }
        elsif $a ~~ /^ '-' (<[0..9]>+) $/ {
            $n = $0.Int;
            $i++;
        }
        else {
            return self!err($op, '用法: head|tail [-n N] [-f] 文件') if $file.chars;
            $file = $a;
            $i++;
        }
    }
    return self!err($op, '用法: head|tail [-n N] [-f] 文件')
        unless $file.chars && $n >= 0;

    # 0.99.0：跟随走 job-op('tail-follow') —— 引擎模式转给持有真终端的
    # 父进程跑循环（Ctrl-C 只停跟随、不杀引擎），单进程模式本地跑。
    # 行经 emit 实时显示；Result 只带停止摘要（out），不重复行内容。
    if $follow {
        my $r;
        {
            CATCH { default { return self!err('tail', .message) } }
            $r = $!sys.job-op('tail-follow', $file, $n);
        }
        return $r if $r ~~ Result;
        return self!err('tail', '跟随执行器返回了非 Result: ' ~ ($r // 'Any').raku);
    }

    # 0.97.0：流式按行读，不再走 read() 的整文件 max-bytes 上限 ——
    # head/tail 只读 n 行，跟文件多大无关（大文件也能 head/tail）。
    my Str $read-err = '';
    my @selected;
    {
        CATCH { default { $read-err = .message } }
        @selected = $op eq 'head'
            ?? $!sys.read-lines($file, :head($n))
            !! $!sys.read-lines($file, :tail($n));
    }
    return self!err($op, $read-err) if $read-err.chars;
    my Str $out = @selected.join("\n");
    self!ok($op, $out, :out($out));
}

method !cmd-export(@args --> Result) {
    return self!err('export', '用法: export KEY=VALUE ...') unless @args.elems;
    for @args -> $a {
        my Str $s = $a.Str;
        my Int $eq = $s.index('=');
        return self!err('export', "需要 KEY=VALUE: {$s}") unless $eq.defined;
        $!sys.set-env($s.substr(0, $eq), $s.substr($eq + 1));
    }
    self!ok('export', @args.List, :out(''));
}

method !cmd-unset(@args --> Result) {
    return self!err('unset', '用法: unset KEY...') unless @args.elems;
    for @args -> $a { $!sys.unset-env($a.Str) }
    self!ok('unset', @args.List, :out(''));
}

method !cmd-touch(@args --> Result) {
    return self!err('touch', '用法: touch 文件...') unless @args.elems;
    for @args -> $a {
        my $p = try { $!sys.resolve($a.Str) };
        return self!err('touch', $!.message) unless $p.defined;
        if !($p.e || $p.l) {
            my $r = try { $!sys.write($a.Str, '', :atomic) };
            return self!err('touch', $!.message) unless $r.defined;
        }
    }
    self!ok('touch', @args.List, :out(''));
}

method !cmd-glob(@args --> Result) {
    return self!err('glob', '用法: glob 模式 [目录]') unless @args.elems;
    my $r = try {
        @args.elems > 1
            ?? $!sys.glob(@args[0].Str, @args[1].Str)
            !! $!sys.glob(@args[0].Str)
    };
    return self!err('glob', $!.message) unless $r.defined;
    my @names = $r.List.map(*.basename);
    self!ok('glob', $r.List, :out(@names.join("\n")));
}

method !cmd-grep(@args --> Result) {
    my Bool $ignore = False;
    my Bool $line-no = False;
    my Bool $invert = False;
    my Bool $fixed = False;
    my @rest;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'i' { $ignore = True }
                    when 'n' { $line-no = True }
                    when 'v' { $invert = True }
                    when 'F' { $fixed = True }
                    when 'E' { $fixed = False }
                    default { return self!err('grep', "不支持的 grep 选项: -{$f}") }
                }
            }
        }
        else { @rest.push($s) }
    }
    return self!err('grep', '用法: grep [-inv] 模式 文件...') unless @rest.elems >= 2;
    my Str $pat = @rest.shift;
    my @files = self!expand-globs(@rest);
    my $rx = $fixed ?? Nil !! (try {
        $ignore ?? rx:i/ <$pat> / !! rx/ <$pat> /
    });
    return self!err('grep', "无效正则: {$pat}") if !$fixed && !$rx.defined;
    my @out;
    for @files -> $file {
        my $text = try { $!sys.read($file) };
        return self!err('grep', $!.message) unless $text.defined;
        for $text.Str.lines.kv -> $i, $line {
            my Bool $hit;
            if $fixed {
                $hit = $ignore
                    ?? $line.lc.contains($pat.lc)
                    !! $line.contains($pat);
            }
            else {
                $hit = so($line ~~ $rx);
            }
            $hit = !$hit if $invert;
            next unless $hit;
            my Str $row = '';
            $row ~= "{$i + 1}:" if $line-no;
            $row ~= "{$file}:" if @files.elems > 1;
            @out.push($row ~ $line);
        }
    }
    self!ok('grep', @out.List, :out(@out.join("\n")));
}

method !cmd-wc(@args --> Result) {
    my Bool $lines = False;
    my Bool $words = False;
    my Bool $chars = False;
    my @files;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'l' { $lines = True }
                    when 'w' { $words = True }
                    when 'c' { $chars = True }
                    default { return self!err('wc', "不支持的 wc 选项: -{$f}") }
                }
            }
        }
        else { @files.push($s) }
    }
    $lines = $words = $chars = True
        unless $lines || $words || $chars;
    @files = self!expand-globs(@files);
    return self!err('wc', '用法: wc [-l] [-w] [-c] 文件...') unless @files.elems;

    my @rows;
    for @files -> $file {
        my $text = try { $!sys.read($file) };
        return self!err('wc', $!.message) unless $text.defined;
        my Str $t = $text.Str;
        my Int $l = $t.lines.elems;
        my Int $w = $t.words.elems;
        my Int $c = $t.chars;
        my @cols;
        @cols.push($l) if $lines;
        @cols.push($w) if $words;
        @cols.push($c) if $chars;
        @cols.push($file);
        @rows.push(@cols.join(' '));
    }
    self!ok('wc', @rows.List, :out(@rows.join("\n")));
}

method !cmd-open(@args --> Result) {
    my Bool $raw = False;
    my Bool $external = False;
    my @paths;
    for @args -> $a {
        if $a.Str eq '--raw' { $raw = True }
        elsif $a.Str eq '--external' { $external = True }
        elsif $a.Str.starts-with('-') {
            return self!err('open', "不支持的 open 选项: {$a.Str}");
        }
        else { @paths.push($a.Str) }
    }
    return self!err('open', '用法: open [--raw] [--external] 文件')
        unless @paths.elems == 1;
    my $data = try {
        Rakuish::Data::open-data($!sys, @paths[0], :$raw,
                                 :allow-external($external))
    };
    return self!err('open', $!.message) unless $data.defined;
    my Str $out = $data ~~ Rakuish::Data::Table
        ?? $data.to-text
        !! $data ~~ Str
            ?? $data
            !! Rakuish::Data::to-json-data($data, :pretty);
    self!ok('open', $data, :out($out));
}

method !cmd-which(@args --> Result) {
    return self!err('which', '用法: which 命令') unless @args.elems == 1;
    my Str $name = @args[0].Str;
    if $name (elem) COMMANDS {
        return self!ok('which', "shell: {$name}", :out("shell: {$name}"));
    }
    my Str $path = $!sys.env<PATH> // '';
    my Str $sep = $*DISTRO.is-win ?? ';' !! ':';
    my Str $suffix = $*DISTRO.is-win ?? '.exe' !! '';
    for $path.split($sep) -> $dir {
        next unless $dir.chars;
        my $candidate = IO::Path.new($dir).add($name ~ $suffix);
        # 不用 `$candidate.x`：Windows 上 Rakudo 2026.11 的 IO::Path.x 对
        # 存在的文件也抛「rindex search target requires a concrete string,
        # but got null」，异常会穿透 handle 中止整段输入（0.101.3 修，
        # 见 docs/RESEARCH 的外部评测 §4.1）。is-executable 在 Windows 走
        # 扩展名白名单、POSIX 走 x 位，两平台都安全。
        next unless $candidate.f;
        return self!ok('which', $candidate.Str, :out($candidate.Str))
            if is-executable($candidate);
    }
    self!err('which', "未找到: {$name}");
}

method !cmd-help(@args --> Result) {
    if @args.elems && @args[0].Str eq '--find' {
        my Str $needle = @args.skip(1).map(*.Str).join(' ');
        return self!err('help', '用法: help --find 文本') unless $needle.chars;
        my @hits;
        for COMMANDS.sort -> $c {
            my Str $u = self.usage($c);
            if $u.contains($needle) {
                @hits.push($c);
            }
        }
        my Str $out = @hits.elems
            ?? @hits.map({ "{$_}\n" ~ self.usage($_) }).join("\n\n")
            !! "没有匹配: {$needle}";
        return self!ok('help', @hits.List, :out($out));
    }
    return self!ok('help', '', :out(self!help-index)) unless @args.elems;
    my Str $cmd = @args[0].Str;
    my Str $usage = self.usage($cmd);
    return self!err('help', "没有这个内置命令: {$cmd}") unless $usage.chars;
    self!ok('help', $cmd, :out($usage));
}

# 0.103.0：`!` 模式的首词补全要包含 PATH 里的外部程序。
# PATH 扫描是按 Tab 才发生的热路径，按 PATH 字符串缓存；口径与 V-288 一致
# ——Windows 用扩展名白名单（is-executable），不碰会抛异常的 IO::Path.x。
my %PATH-EXE-CACHE;

our sub path-executables(--> List) is export {
    my Str $path = (%*ENV<PATH> // '').Str;
    return %PATH-EXE-CACHE{$path} if %PATH-EXE-CACHE{$path}:exists;
    my Str $sep = $*DISTRO.is-win ?? ';' !! ':';
    my Bool $is-win = $*DISTRO.is-win;
    # 目录之间有天然并行性：串行遍历本机 100+ 个 PATH 目录实测约 2.2 s，
    # 首次按 Tab 会卡住；并行后落到几十毫秒量级。每个目录独立收集，
    # 顺序由 PATH 决定（去重取先出现的那个）。
    my @lists = await $path.split($sep).grep(*.chars).map(-> $dir {
        start {
            my @n;
            for (try { $dir.IO.dir } // ()) -> $e {
                next unless is-executable($e);
                my Str $n = $e.basename;
                if $is-win {
                    # Windows 下 `! raku` 就能跑（CreateProcess 会补 .exe），
                    # 所以候选去掉后缀、避免 `raku` / `raku.exe` 两条噪声。
                    my Str $ext = $e.extension;
                    $n = $n.substr(0, $n.chars - $ext.chars - 1) if $ext.chars;
                }
                @n.push($n) if $n.chars;
            }
            @n.List
        }
    });
    my %seen;
    my @names;
    for @lists -> @dir-names {
        for @dir-names -> $n {
            next if %seen{$n.lc}++;
            @names.push($n);
        }
    }
    my @sorted = @names.sort({ $^a.lc cmp $^b.lc });
    %PATH-EXE-CACHE{$path} = @sorted.List;
    @sorted.List;
}

method completions(Str $line, Int $pos --> List) {
    my Int $at = $pos min $line.chars;
    my Str $prefix = $line.substr(0, $at);

    # 0.102.0：`!` 模式也要补全。以前这里直接 `return ()`，于是
    # `! ls tmp/fi<Tab>` / `! raku script/<Tab>` 什么都不会发生。
    # 现在剥掉感叹号（连同其后的空白，原样记在 $bang 里），走同一套
    # argv 补全；返回值是「完整替换行」，所以每处结果都要把 $bang 加回。
    my Str $bang = '';
    if $prefix.starts-with('!') {
        my Str $rest = $prefix.substr(1);
        my Str $lead = $rest ~~ /^(\s+)/ ?? ~$0 !! '';
        $bang = '!' ~ $lead;
        $prefix = $rest.substr($lead.chars);
        return () unless $prefix.chars;   # 只有 `!`：不猜，等用户继续敲
    }

    return () if $prefix ~~ /<[$@%&()\[\]{};|<>]>/;

    # 命令名补全：还没输入空格，或刚输入 help。
    # 前缀优先（排序不变），零前缀命中时子序列回退（V-282）。
    if $prefix !~~ /\s/ {
        my @words = COMMANDS.List;
        # 0.103.0：`!` 的首词还包括 PATH 里的外部程序（Grep / 去重后交给
        # fuzzy-words，零命中时的子序列回退同样生效）。
        @words = (|@words, |path-executables()).unique if $bang.chars;
        return fuzzy-words($prefix, @words).map({ $bang ~ $_ ~ ' ' }).List;
    }

    my Str $cmd = ($prefix.split(/\s+/))[0] // '';
    # `!` 模式下首词是任意外部程序（或 `--tty` 这类元选项），不要求是内置
    # 命令；参数位置照常补路径。
    return () unless $bang.chars || $cmd (elem) COMMANDS;

    if $cmd eq 'help' && $prefix ~~ /^ 'help' \s+ (\S*)$/ {
        my Str $frag = ~$0;
        return COMMANDS.grep({ .starts-with($frag) })
            .sort.map({ $bang ~ 'help ' ~ $_ ~ ' ' }).List;
    }

    my Int $start = $prefix.chars;
    while $start > 0 && $prefix.substr($start - 1, 1) !~~ /\s/ {
        $start--;
    }
    my Str $before = $prefix.substr(0, $start);
    my Str $frag = $prefix.substr($start);
    return () if $frag.contains('$');

    # 0.103.0：`! --tty <Tab>` / `! -t <Tab>` 的第二词也是外部程序名，
    # 不是文件路径；带 / 或 \ 时才当作路径片段交给下面的路径补全。
    if $bang.chars && ($cmd eq '--tty' || $cmd eq '-t')
       && $frag.chars && !$frag.contains('/') && !$frag.contains('\\') {
        return fuzzy-words($frag, path-executables())
            .map({ $bang ~ $before ~ $_ ~ ' ' }).List;
    }

    # 0.75.0 / ADR-0012 §2：`-` / `--` 前缀补该命令的选项，别拿去当文件名找。
    # 返回「完整替换行」，与路径补全的约定一致。
    if $frag.starts-with('-') {
        my @opts = (OPTIONS{$cmd} // []).list;
        @opts.push('--help', '-?');
        return @opts.grep({ .Str.starts-with($frag) }).map(*.Str).sort.unique
                   .map({ $bang ~ $before ~ $_ ~ ' ' }).List;
    }

    my Str $dir = '';
    my Str $base = $frag;
    if $frag.contains('/') || $frag.contains('\\') {
        my Int $slash = max($frag.rindex('/') // -1, $frag.rindex('\\') // -1);
        $dir = $frag.substr(0, $slash + 1);
        $base = $frag.substr($slash + 1);
    }
    my @entries = try {
        $!sys.ls($dir.chars ?? $dir !! '.', :all($base.starts-with('.')))
    } // ();
    my @out;
    for @entries -> $e {
        my Str $name = $e.basename;
        next unless $name.starts-with($base);
        @out.push($bang ~ $before ~ $dir ~ $name ~ ($e.d ?? '/' !! ''));
    }
    @out.sort.List;
}

method !cmd-jobs(@args --> Result) {
    my $t = $!sys.jobs;
    my Str $out = $t.elems ?? $t.to-text !! '没有后台任务';
    self!ok('jobs', $t, :$out);
}

method !has-unquoted-meta(Str $s, Bool :$braces = False --> Bool) {
    my Str $quote = '';
    my Bool $esc = False;
    for $s.comb -> $c {
        if $esc { $esc = False; next }
        if $quote ne '' {
            if $quote eq '"' && $c eq '\\' { $esc = True }
            elsif $c eq $quote { $quote = '' }
            next;
        }
        if $c eq q{'} || $c eq q{"} { $quote = $c; next }
        if $c eq '\\' { $esc = True; next }
        return True if $c ~~ /<[%@&();|<>]>/;
        return True if $braces && $c ~~ /<[\[\]{}]>/;
    }
    False;
}

method handle(Str $line --> Result) {
    my Str $trim = $line.trim;
    return Nil unless $trim.chars;
    my @args = self!split($trim);
    return Nil unless @args.elems;

    my Str $cmd = @args.shift.Str;
    @args = @args.map({ self!expand-home(.Str) }).List;
    @args = self!expand-env(@args);

    return Nil unless $cmd (elem) COMMANDS;

    # 未展开的 $NAME 仍是 Raku 变量，交回 Raku；已由会话 env 展开的没有 $。
    # `set -o noexpand` 是用户显式要求「别展开」，此时字面 $ 必须当参数传下去。
    return Nil if !$!noexpand && @args.elems
                  && @args.grep({ .Str.contains('$') }).elems;

    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        my Str $usage = self.usage($cmd);
        return self!ok('help', $cmd, :out($usage)) if $usage.chars;
    }

    # 只处理真正实现的 Shell 命令；其余（write/append/exec/...）是 Raku API，
    # 保留 help/补全条目，但执行时交回 Raku。
    return Nil unless $cmd (elem) SHELL-COMMANDS;

    if @args.grep({ $_ eq '|' || $_ eq '>' || $_ eq '>>' || $_ eq '<' }).elems {
        return self!err('shell', '不支持管道/重定向；用 ! 交给外部 argv 程序');
    }

    # 只看引号外的元字符。`echo "a;b"`、`cat "file(1).txt"` 是字面参数，
    # 不应因为引号内的标点被误交给 Raku。
    if $cmd ne 'export' && $cmd ne 'grep' && $cmd ne 'doc'
       && self!has-unquoted-meta($line) {
        return Nil;
    }
    if $cmd ne 'glob' && $cmd ne 'export' && $cmd ne 'grep' && $cmd ne 'doc'
       && self!has-unquoted-meta($line, :braces) {
        return Nil;
    }

    given $cmd {
        when 'cd'    { self!cmd-cd(@args) }
        when 'pwd'   { self!cmd-pwd(@args) }
        when 'clear' { self!cmd-clear(@args) }
        when 'ls'    { self!cmd-ls(@args) }
        when 'cat'   { self!cmd-cat(@args) }
        when 'read'  { self!cmd-read(@args) }
        when 'rm'    { self!cmd-rm(@args) }
        when 'mkdir' { self!cmd-mkdir(@args) }
        when 'cp'    { self!cmd-cp(@args) }
        when 'mv'    { self!cmd-mv(@args) }
        when 'stat'  { self!cmd-stat(@args) }
        when 'echo'  { self!cmd-echo(@args) }
        when 'head'  { self!cmd-head-tail('head', @args) }
        when 'tail'  { self!cmd-head-tail('tail', @args) }
        when 'export' { self!cmd-export(@args) }
        when 'unset'  { self!cmd-unset(@args) }
        when 'touch'  { self!cmd-touch(@args) }
        when 'glob'   { self!cmd-glob(@args) }
        when 'grep'   { self!cmd-grep(@args) }
        when 'wc'     { self!cmd-wc(@args) }
        when 'help'   { self!cmd-help(@args) }
        when 'jobs'   { self!cmd-jobs(@args) }
        when 'which'  { self!cmd-which(@args) }
        when 'open'   { self!cmd-open(@args) }
        when 'doc'      { self!cmd-doc(@args) }
        when 'pushd'    { self!cmd-pushd(@args) }
        when 'popd'     { self!cmd-popd(@args) }
        when 'dirs'     { self!cmd-dirs(@args) }
        when 'bookmark' { self!cmd-bookmark(@args) }
        default       { Nil }
    }
}
