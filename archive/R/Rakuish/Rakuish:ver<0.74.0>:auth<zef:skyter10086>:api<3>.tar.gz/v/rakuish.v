module rakuish

import os
import shell_lexer
import shell_parser
import shell_expand
import raku_engine

// ── Rakuish v0.2：bash 式外壳 + Raku 逃逸层 ──────────────────────
//
// 路由规则（shell-design §1 的核心契约：**外壳层永不解析 Raku**）：
//   · 一行输入**默认**按 shell 解析执行（管道/重定向/glob/$VAR/内建）
//   · 只有两种形式穿过逃逸层进 Raku 引擎：
//       eval "Raku 代码"        —— 字符串边界
//       raku { ... }            —— 多行块
//   两个 parser 靠这个字符串边界隔开，各自只认自己的语法。
//
// 这样就**没有**「print 是内建还是 lpr」「_ 是不是变量」这类歧义 ——
// 外壳层根本不碰 Raku 语法。

pub struct ExecOutcome {
pub:
	handled bool     // 是否被内建处理掉了（true 则不该走外部命令）
	ok bool
	stdout string
	code int
	is_raku bool     // true 表示 stdout 里装的是待送引擎的 Raku 代码
	// shell → Raku 的 %*ENV 镜像前缀（白皮书 §4 字符串桥）。
	// 每次 export/set 之后都会变，调用方在送引擎前写到 engine.env_prefix。
	env_prefix string
}

pub struct Escape {
pub:
	is_escape bool
	code string
}

// ── 逃逸层：判定这一行是否该进引擎 ────────────────────────────────
pub fn detect_escape(line string) Escape {
	mut t := line.trim_space()
	if t.len < 4 {
		return Escape{ is_escape: false, code: '' }
	}
	if t.starts_with('eval ') || t.starts_with('eval(') {
		body := t[4..].trim_space()
		if body.len >= 2 {
			first := body[0]
			last := body[body.len - 1]
			if (first == `"` && last == `"`) || (first == 0x27 && last == 0x27) {
				return Escape{ is_escape: true, code: body[1..body.len - 1] }
			}
		}
		if body != '' {
			return Escape{ is_escape: true, code: body }
		}
	}
	return Escape{ is_escape: false, code: '' }
}

// raku { ... } 多行块
pub fn raku_block_open(line string) bool {
	t := line.trim_space()
	return t.starts_with('raku {') || t.starts_with('raku{')
}

pub fn raku_block_body(line string) string {
	t := line.trim_space()
	if t.starts_with('raku {') {
		return t[6..]
	}
	if t.starts_with('raku{') {
		return t[5..]
	}
	return t
}

// ── 会话 ──────────────────────────────────────────────────────────
fn C.chdir(&u8) int

pub struct Session {
pub mut:
	vars map[string]string
	// true = 外部命令直接继承 stdio（交互式 REPL 用，保留颜色/进度条）；
	// false = 捕获 stdout（批处理/测试用）
	passthrough bool
}

// ── 进程原语：管道 / 重定向执行 ───────────────────────────────────
// V 没有内建 dup2/open 的高层封装，这里直接绑 libc。
// （V 坑：这版 V 必须写 `fn C.xxx(...)`，**没有** `extern` 关键字。）
// V 坑：fd / flag 参数必须声明为 i32，写成 64 位 `int` 会静默失败。
//
// ⚠ 关键约束：**C.close / C.read / C.write / C.dup2 绝不在本模块重复声明** ——
// raku_engine.v 已声明了它们的 64 位版本。同名不同签名会被 V 合并成
// 错误的调用约定。fd 操作一律走 V 官方 API：
//   os.pipe() / os.fd_dup() / os.fd_dup2() / os.fd_close() / os.fd_write()
// 这里只声明 V 没有的：fork / open / waitpid / _exit / execvp。
fn C.fork() i32
fn C.open(&char, i32, i32) i32
fn C.waitpid(i32, voidptr, i32) i32
fn C._exit(i32)
// V 坑：argv 形参必须声明成 voidptr —— 写成 &[&char] 会让 V 生成
// `typedef void Array_fixed_void_ptrchar[ptrchar]` 这种废 C 代码，编译直接失败。
fn C.execvp(&char, voidptr) i32

// Linux x86_64 的 open flags（asm-generic/fcntl.h 真值）
const o_rdonly = 0
const o_wronly = 1
const o_creat = 64
const o_trunc = 512
const o_append = 1024
const mode_644 = 420 // 0o644

// 单条命令 argv 的最大个数（含结尾的 nil）
const len_cmd_max = 64

// 归一化路径（处理 .. 与重复 /）
fn normalize(path string) string {
	mut parts := []string{}
	for seg in path.split('/') {
		if seg == '..' {
			// V 数组没有 delete_at；用 slice 截掉最后一个元素
			if parts.len > 0 {
				parts = parts[..parts.len - 1]
			}
		} else if seg == '.' || seg == '' {
			continue
		} else {
			parts << seg
		}
	}
	return '/' + parts.join('/')
}

// cd：必须**在进程内**切换目录（fork 出去切了没用）
fn do_cd(target string) ExecOutcome {
	mut path := target
	if path == '' {
		path = os.getenv('HOME')
	}
	path = shell_expand.expand_vars(path)
	if path.starts_with('~') {
		path = os.getenv('HOME') + path[1..]
	}
	if !path.starts_with('/') {
		path = os.getwd() + '/' + path
	}
	norm := normalize(path)
	if !os.exists(norm) || !os.is_dir(norm) {
		return ExecOutcome{ handled: true, ok: false, stdout: 'cd: 没有那个目录: ${target}', code: 1 }
	}
	if unsafe { C.chdir(&char(norm.str)) } != 0 {
		return ExecOutcome{ handled: true, ok: false, stdout: 'cd: 失败', code: 1 }
	}
	return ExecOutcome{ handled: true, ok: true, stdout: '', code: 0 }
}

// 内建命令（必须在进程内生效）
fn run_builtin(mut s Session, name string, args []string) ExecOutcome {
	if name == 'cd' {
		mut t := ''
		if args.len > 0 {
			t = args[0]
		}
		return do_cd(t)
	}
	if name == 'export' {
		for a in args {
			pos := a.index('=') or { continue }
			key := a[..pos]
			val := a[pos + 1..]
			s.vars[key] = val
			os.setenv(key, val, true)
		}
		return ExecOutcome{ handled: true, ok: true, stdout: '', code: 0 }
	}
	if name == 'set' {
		if args.len >= 2 {
			s.vars[args[0]] = args[1]
		}
		return ExecOutcome{ handled: true, ok: true, stdout: '', code: 0 }
	}
	return ExecOutcome{ handled: false, ok: false, stdout: '', code: 127 }
}

// 把单个参数重新引用成 shell 安全的词。
// 批处理模式走 shell 字符串，unquote 之后 "a b" 变成裸值，
// 不重新加引号会被 shell 拆成两个词（实测踩坑：多行 echo 的第二段
// 被当成独立命令执行，报 sh: not found）。
fn shq(s string) string {
	if s.len == 0 {
		return "''"
	}
	mut safe := true
	mut i := 0
	for i < s.len {
		c := s[i]
		if c == 32 || c == 9 || c == 34 || c == 0x27 || c == 36 || c == 0x60 || c == 92
			|| c == 42 || c == 63 || c == 91 || c == 35 || c == 126 {
			safe = false
			break
		}
		i++
	}
	if safe {
		return s
	}
	mut r := ''
	i = 0
	for i < s.len {
		c := s[i]
		if c == 34 || c == 36 || c == 0x60 || c == 92 {
			r += '\\'
		}
		r += c.ascii_str()
		i++
	}
	return '"' + r + '"'
}

// 展开一条命令：expand_arg = 引号感知的「展开 + 剥引号」一步完成
//（先剥后展会把单引号内容也展开 —— 实测踩坑）
// 之后对**未加引号的**含 * ? 参数做 glob（bash 语义：引号内不 glob）。
// glob 可能把 1 个参数变成多个，所以必须在 argv 组装完之后做。
fn expand_cmd(c shell_parser.Command) Cmd {
	if c.args.len == 0 {
		return Cmd{ name: '', argv: []string{} }
	}
	mut argv := []string{}
	argv << shell_expand.expand_arg(c.args[0])
	for i in 1 .. c.args.len {
		raw := c.args[i]
		expanded := shell_expand.expand_arg(raw)
		if is_quoted(raw) {
			argv << expanded
		} else {
			for g in shell_expand.glob_expand(expanded) {
				argv << g
			}
		}
	}
	return Cmd{ name: argv[0], argv: argv }
}

// 参数本身是否带过引号（含任一种引号即算「引号内」）
// V 坑：string.contains / index **只接 string**，传 char 编译不过；
// 要按字符找用 contains_any("'\"") 或 contains_u8(u8)。
fn is_quoted(raw string) bool {
	return raw.contains_any("'\"")
}

pub struct Cmd {
pub:
	name string
	argv []string
}

// 读整个文件（捕获模式用）。
// 用 V 官方的 os.read_bytes —— 自己绑 C.read 会与 raku_engine.v 里
// 同名的 64 位声明冲突（同名不同签名被 V 合并，行为不可预测）。
fn read_file_all(path string) string {
	data := os.read_bytes(path) or { return '' }
	if data.len == 0 {
		return ''
	}
	return data.bytestr()
}

// ── 子进程侧：在**已经 dup2 好**的 fd 布局下真正执行一条命令 ───────
// 注意：这个函数只在 fork 出来的子进程里跑，绝不返回到父进程逻辑。
fn child_exec(mut s Session, c shell_parser.Command) {
	cmd := expand_cmd(c)
	if cmd.name == '' {
		unsafe { C._exit(0) }
	}
	// 内建在子进程里执行 —— 语义与 bash 一致：
	// `export X=1 | cat` 的 export 发生在 subshell，不影响父会话。
	// V 坑：argv[1..] 在 len==1 时 panic（array.get index out of range）
	rest := if cmd.argv.len > 1 { cmd.argv[1..] } else { []string{} }
	bi := run_builtin(mut s, cmd.name, rest)
	if bi.handled {
		unsafe { C._exit(if bi.ok { 0 } else { 1 }) }
	}
	// 注意 argv[0..]：这里自建 C 字符串数组。
	//
	// 不能直接用 os.execvp —— 它内部 `&char(cmdpath.str)` 取的是
	// V 字符串的内部指针，本项目实测会失败（`/usr/bin/ls` 绝对路径都
	// code=1「命令未找到」）。所以把每个 argv 元素**复制进一块 arena**，
	// 再取 arena 内的偏移地址 —— arena 生命周期覆盖整个 exec 调用，
	// 指针稳定。
	//
	// arena 大小：4096 字节足够（单条命令的参数总量远小于此）。
	mut arena := [4096]u8{}
	mut off := 0
	// V 坑：不能把 []&char 的 .data 传给形参 voidptr —— 实测 execvp
	// 会一直失败（连绝对路径的 printf 都跑不起来）。
	// 改用固定长度 C 指针数组，取首元素地址。
	// 注意初值必须是 nil —— [64]&char{} 的元素是**垃圾指针**，
	// 不清零会让 execvp 在中途读到野指针（实测 invalid memory access）。
	mut cargs := [len_cmd_max]&char{}
	for i in 0 .. len_cmd_max {
		cargs[i] = unsafe { nil }
	}
	for i in 0 .. cmd.argv.len {
		if i >= len_cmd_max - 1 {
			break
		}
		mut n := cmd.argv[i].len
		if n > 1024 {
			n = 1024
		}
		if off + n + 1 > arena.len {
			break
		}
		for k in 0 .. n {
			arena[off + k] = cmd.argv[i][k]
		}
		arena[off + n] = 0
		cargs[i] = unsafe { &arena[off] }
		off += n + 1
	}
	mut argc := cmd.argv.len
	if argc > len_cmd_max - 1 {
		argc = len_cmd_max - 1
	}
	cargs[argc] = unsafe { nil }
	rc := unsafe { C.execvp(cargs[0], voidptr(&cargs[0])) }
	if rc != 0 {
		// exec 失败。注意不能用 eprintln —— 它走 C stderr 流，
		// 而 dup2 可能已改了 fd 2，V 的 C 流仍绑在旧 fd 上。
		msg := '${cmd.name}: 命令未找到\n'
		os.fd_write(2, msg)
	}
	unsafe { C._exit(127) }
}

// RedirKind 的整数序号 —— **不要用 int(k) 现算**：
// V 0.5 里 enum 跨模块时值可能对不上（实测 rakuish.v 里把
// shell_parser.RedirKind 转 int 后与字面量比较恒为假）。
// shell_parser 在构造 Redirect 时已把 kind_i 填好，这里直接用。
const rk_in = 0
const rk_out = 1
const rk_append = 2
const rk_dup = 3

// 把一条命令的重定向应用到当前进程（子进程里，fork 之后 exec 之前）
//
// V 坑（实测）：`for r in c.redirs` 对**跨模块结构体数组**只迭代一次 ——
// 实测 `ls x > f 2>&1` 的两条重定向里，第二条从不执行（索引恒为 0）。
// 改用显式索引循环，逐条按值取出。
fn apply_redirs(c shell_parser.Command) {
	rs := c.redirs
	mut idx := 0
	for idx < rs.len {
		r := rs[idx]
		k := r.kind_i
		idx++
		if k == rk_dup {
			// `N>&M` —— 让 fd N 指向 fd M 当前所指向的目标。
			//
			// 实现就是 dup2(M, N)（**M 是源，N 是目标**）。
			// ⚠ 参数顺序极易写反：dup2(oldfd, newfd) 里 oldfd 是**源**。
			// 本项目最初写成 dup2(N, M)，把 fd1 指向了 fd2（终端），
			// 症状是 `2>&1` 完全无效且所有标记都跑到终端 ——
			// 排查时误判成「dup2 到 fd1 静默失效」，白绕了很久。
			// 记住：`2>&1` = dup2(1, 2)，不是 dup2(2, 1)。
			os.fd_dup2(r.dup_fd, r.fd)
			continue
		}
		mut flags := 0
		if k == rk_out {
			flags = o_wronly | o_creat | o_trunc
		} else if k == rk_append {
			flags = o_wronly | o_creat | o_append
		} else {
			flags = o_rdonly
		}
		fd := unsafe { C.open(&char(r.target.str), i32(flags), mode_644) }
		if fd < 0 {
			if k == rk_in {
				eprintln('rakuish: 无法打开 ${r.target}')
			} else {
				eprintln('rakuish: 无法写入 ${r.target}')
			}
			continue
		}
		// 注意参数顺序：dup2(源, 目标)。
		// 这里是「让 fd r.fd 指向这个新打开的文件」。
		os.fd_dup2(fd, r.fd)
		os.fd_close(fd)
	}
}

// waitpid 取退出码（正常退出时 (status >> 8) & 0xFF）
fn reap(pid i32) int {
	mut status := 0
	unsafe { C.waitpid(pid, voidptr(&status), 0) }
	return (status >> 8) & 0xFF
}

// ── 真正的管道 / 重定向执行器 ─────────────────────────────────────
//
// 语义（对齐 bash）：
//   · 每个 pipeline 段一个子进程，段间用 pipe(2) 串起来
//   · 首段 stdin 继承父进程（交互式 REPL 下就是终端）
//   · 末段 stdout：passthrough 直接继承；捕获模式写临时文件后读回
//   · 重定向在 exec 之前 dup2 到位（可覆盖 pipe 布局）
//   · 内建在子进程里跑（`export X=1 | cat` 不污染父会话）
fn run_pipeline(mut s Session, p shell_parser.Pipeline) ExecOutcome {
	cmds := p.commands
	n := cmds.len
	if n == 0 {
		return ExecOutcome{ handled: false, ok: true, stdout: '', code: 0 }
	}
	// 快路径：单命令无重定向 —— 走已验证的 system_args / execute_opt 路径，
	// 内建（cd/export/set）在**父进程**生效。
	if n == 1 && cmds[0].redirs.len == 0 {
		return run_shell(mut s, cmds[0])
	}

	// 段间管道
	mut pr := []int{} // 读端
	mut pw := []int{} // 写端
	for _ in 0 .. n - 1 {
		pp := os.pipe() or {
			return ExecOutcome{
				handled: false
				ok: false
				stdout: 'pipe 创建失败'
				code: 1
			}
		}
		pr << pp.read_fd
		pw << pp.write_fd
	}

	// 捕获模式的末段 stdout → 临时文件（用文件而不是 pipe 收集：
	// 父进程先 wait 再读，彻底避免管道缓冲区打满的死锁）
	mut cap_path := ''
	mut cap_fd := -1
	if !s.passthrough {
		cap_path = '/tmp/rakuish-cap-${os.getpid()}'
		cap_fd = unsafe { C.open(&char(cap_path.str), o_wronly | o_creat | o_trunc, mode_644) }
		if cap_fd < 0 {
			cap_path = ''
		}
	}

	mut pids := []i32{}
	for i in 0 .. n {
		c := cmds[i]
		// fork 之前必须把父进程自己的缓冲刷掉：
		// 子进程继承了 V 的 stdout 缓冲，退出时再刷一次就会**输出重复**。
		flush_stdout()
		pid := unsafe { C.fork() }
		if pid == 0 {
			// ── 子进程 ──
			// 注意 dup2(old, new)：old 是**源** fd。
			if i > 0 {
				os.fd_dup2(pr[i - 1], 0)
			}
			if i < n - 1 {
				os.fd_dup2(pw[i], 1)
			} else if cap_fd >= 0 {
				os.fd_dup2(cap_fd, 1)
			}
			// 关掉所有继承来的管道端，否则末段永远等不到 EOF。
			// 必须在上面那批 dup2 **之后**关，否则会把刚设好的 fd 关掉。
			for k in 0 .. n - 1 {
				os.fd_close(pr[k])
				os.fd_close(pw[k])
			}
			if cap_fd >= 0 {
				os.fd_close(cap_fd)
			}
			apply_redirs(c)
			child_exec(mut s, c)
			unsafe { C._exit(127) }
		}
		pids << pid
	}
	// ── 父进程 ──
	for k in 0 .. n - 1 {
		os.fd_close(pr[k])
		os.fd_close(pw[k])
	}
	if cap_fd >= 0 {
		os.fd_close(cap_fd)
	}
	mut code := 0
	for pid in pids {
		code = reap(pid)
	}
	mut out := ''
	if cap_path != '' {
		out = read_file_all(cap_path)
		os.rm(cap_path) or { }
	}
	mut ok := code == 0
	if p.negated {
		ok = !ok
		code = if ok { 0 } else { 1 }
	}
	return ExecOutcome{ handled: false, ok: ok, stdout: out, code: code }
}

// ── 执行一行 shell 命令（无管道无重定向的快路径）──────────────────
fn run_shell(mut s Session, cmd shell_parser.Command) ExecOutcome {
	if cmd.args.len == 0 {
		return ExecOutcome{ handled: false, ok: true, stdout: '', code: 0 }
	}
	ec := expand_cmd(cmd)
	name := ec.name
	// V 坑：`argv[1..]` 在 len==1 时会 panic（array.get index out of range）。
	// 单参数命令（cat / wc / true）非常常见，必须显式分支。
	rest := if ec.argv.len > 1 { ec.argv[1..] } else { []string{} }
	// 内建？
	bi := run_builtin(mut s, name, rest)
	if bi.handled {
		return bi
	}
	if s.passthrough {
		// REPL 模式：参数数组直通 execvp（**不走 shell**）——
		// 引号语义天然保留（"a b" 是一个参数）、无注入风险、
		// stdio 直接继承（颜色/进度条/交互式子命令都不丢）
		code := os.system_args(ec.argv)
		if code < 0 {
			return ExecOutcome{
				handled: false
				ok: false
				stdout: '${name}: 命令未找到'
				code: 127
			}
		}
		return ExecOutcome{ handled: false, ok: code == 0, stdout: '', code: code }
	}
	// 批处理模式：拼回带引号的命令行交给 shell 捕获 stdout
	// （不能裸 join —— unquote 之后 "a b" 是裸值，会被 shell 拆成两个词）
	mut cmdline := shq(name)
	for a in rest {
		cmdline += ' ' + shq(a)
	}
	r := os.execute_opt(cmdline) or {
		msg := err.msg()
		code := 127
		if !msg.contains('ENOENT') && !msg.contains('not found') {
			// 程序跑起来了但退出码非 0 —— execute_opt 会把输出当错误返回
			return ExecOutcome{ handled: false, ok: false, stdout: msg, code: 1 }
		}
		return ExecOutcome{
			handled: false
			ok: false
			stdout: '${name}: 命令未找到'
			code: code
		}
	}
	return ExecOutcome{ handled: false, ok: true, stdout: r.output, code: r.exit_code }
}

// ── 顶层：一行的完整处理 ──────────────────────────────────────────
// 注意：run_line **不接管引擎**（见文件头「V 坑 33」）——
// 逃逸行只把代码原样返回（code 字段），由调用方送进引擎。
// 这样彻底避开 V 的可变引用传参死结。
pub fn run_line(mut s Session, line string) ExecOutcome {
	mut t := line.trim_space()
	if t == '' {
		return ExecOutcome{ handled: false, ok: true, stdout: '', code: 0 }
	}
	// ① 先看是不是逃逸层
	esc := detect_escape(t)
	if esc.is_escape {
		// 把 Raku 代码交回调用方执行（run_line 不碰引擎）
		return ExecOutcome{
			handled: true
			ok: true
			stdout: esc.code
			code: 0
			is_raku: true
			env_prefix: raku_engine.make_env_prefix(s.vars)
		}
	}
	// ② 默认按 shell 解析
	pipes := shell_parser.parse(t)
	mut last := ExecOutcome{ handled: false, ok: true, stdout: '', code: 0 }
	for p in pipes {
		last = run_pipeline(mut s, p)
		if !last.ok {
			return with_env(last, s)
		}
	}
	// 注意：env_prefix 必须在**所有** return 之前重新生成 ——
	// export/set 是处理过程中才改 s.vars 的，函数开头算的那份是旧值。
	return with_env(last, s)
}

// 给结果补上当前的 %*ENV 镜像前缀。
// V 不支持 `mut x.field = ...`（那是声明语法），所以重新构造。
fn with_env(r ExecOutcome, s Session) ExecOutcome {
	return ExecOutcome{
		handled: r.handled
		ok: r.ok
		stdout: r.stdout
		code: r.code
		is_raku: r.is_raku
		env_prefix: raku_engine.make_env_prefix(s.vars)
	}
}
