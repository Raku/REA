module pty_selftest

import os
import raku_engine

// ── Rakuish pty 常驻引擎回归测试 ──────────────────────────────────
//
// 为什么单独一个文件：shell 层（lexer/parser/expand/执行）的回归在
// selftest.v；**pty 引擎**这一层此前**没有任何入库的测试**（2026-10-30 前
// 只在提交说明里口头记过「11/11 通过」，文件没留）—— 于是引擎一旦坏掉，
// 没有任何机制能发现。
//
// 跑法：cd v && /home/zby/v/v -o rakuish . && ./rakuish --ptytest
//
// 文件名注意：不能叫 *_test.v —— V 把 `_test.v` 当**独立测试文件**编译，
// 不进工程模块图，`import` 会报 cannot import module "..." (not found)。
// （不用 v test —— 它把 _test.v 当独立文件编译，不走工程模块解析，
//  import 同目录模块会 not found。实测踩的坑。）
//
// 依赖：需要一个可执行的 Raku 解释器（默认 /home/zby/.rakupp/bin/rakupp，
//  可用环境变量 RAKUISH_ENGINE 覆盖）。引擎起不来时**如实报失败**，
//  不静默跳过 —— 静默跳过等于没测。
//
// V 字符串备忘（沿用 selftest.v 的坑位记录）：
//   · 反引号字符串不支持 $
//   · 单引号字符串**支持**插值 —— 消息文本里的 $ 字面量一律用双引号 + \$

// 引擎程序路径：与 main.v 保持一致
fn engine_prog() string {
	return os.getenv_opt('RAKUISH_ENGINE') or { '/home/zby/.rakupp/bin/rakupp' }
}

// 单次求值，返回 (结果文本, 错误说明)
fn ev(eng &raku_engine.Engine, code string) [2]string {
	r := raku_engine.eval_line(eng, code)
	return [r.trim_space(), '']
}

fn t_engine_eval_basic(eng &raku_engine.Engine) [2]string {
	r := ev(eng, '1 + 2')
	if r[0] != '3' {
		return ['pty: 求值 1+2', "期望 3，实际 '${r[0]}'"]
	}
	return ['pty: 求值 1+2', '']
}

fn t_engine_state_persists(eng &raku_engine.Engine) [2]string {
	_ := ev(eng, 'my $pty_count = 10')
	r := ev(eng, '$pty_count * 2')
	if r[0] != '20' {
		return ['pty: 状态跨行存活', "期望 20，实际 '${r[0]}'"]
	}
	return ['pty: 状态跨行存活', '']
}

fn t_engine_error_does_not_kill(eng &raku_engine.Engine) [2]string {
	r := ev(eng, '1/0')
	if r[0] == '' {
		return ['pty: 出错有消息', '1/0 应返回错误文本，实际为空']
	}
	// 关键：出错后引擎必须还活着
	r2 := ev(eng, '$pty_count * 3')
	if r2[0] != '30' {
		return ['pty: 出错后引擎仍可用', "期望 30，实际 '${r2[0]}'"]
	}
	return ['pty: 出错后引擎仍可用', '']
}

fn t_engine_env_bridge(eng &raku_engine.Engine) [2]string {
	prefix := raku_engine.make_env_prefix({'NAME': 'rakuish'})
	if prefix == '' {
		return ['pty: %*ENV 镜像前缀', 'make_env_prefix 返回空']
	}
	r := ev(eng, prefix + ' %*ENV<NAME>')
	if r[0] != 'rakuish' {
		return ['pty: %*ENV 镜像前缀', "期望 rakuish，实际 '${r[0]}'"]
	}
	return ['pty: %*ENV 镜像前缀', '']
}

fn t_engine_stopped(eng &raku_engine.Engine) [2]string {
	raku_engine.stop(eng)
	r := raku_engine.eval_line(eng, '1 + 1')
	if r != '(引擎已退出)' {
		return ['pty: 停止后不再求值', "实际 '${r}'"]
	}
	return ['pty: 停止后不再求值', '']
}

// 入口：启动引擎 → 跑各项 → 打印汇总 → 返回失败数
pub fn run() int {
	prog := engine_prog()
	if !os.exists(prog) {
		println('ptytest: FAIL 引擎程序不存在: ${prog}')
		println('')
		println('ptytest: 0 通过 / 1 失败（共 1 项）')
		return 1
	}
	mut eng := raku_engine.start(prog, []) or {
		println('ptytest: FAIL 引擎启动失败: ${err}')
		println('')
		println('ptytest: 0 通过 / 1 失败（共 1 项）')
		return 1
	}
	mut cases := [][]string{}
	cases << t_engine_eval_basic(&eng)
	cases << t_engine_state_persists(&eng)
	cases << t_engine_error_does_not_kill(&eng)
	cases << t_engine_env_bridge(&eng)
	cases << t_engine_stopped(&eng)
	mut pass := 0
	mut fail := 0
	for c in cases {
		if c[1] == '' {
			pass++
			println('  ok   ${c[0]}')
		} else {
			fail++
			println('  FAIL ${c[0]} —— ${c[1]}')
		}
	}
	println('')
	println('ptytest: ${pass} 通过 / ${fail} 失败（共 ${pass + fail} 项）')
	return fail
}
