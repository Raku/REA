# v/ —— Rakuish v0.2（V 实现）· **已停止维护，仅作移植参考**

> **状态：2026-10-30 定案 —— 项目主线回到 Raku 实现（`lib/` + `bin/rakuish`）。**
> 本目录保留下来**只为一件事**：里面的 shell 层（lexer / parser / expand）质量不错，
> 是移植进 Raku 实现（拿到原生管道 / 重定向语义）的素材。
>
> **2026-10-31：移植已完成** —— shell 层已进入 Raku 实现，落在
> `lib/Rakuish/Shell/{Lexer,Parser,Expand,Exec}.rakumod`。
> `!cmd` 与反引号捕获不再整段丢给 `sh -c`，而是**自己解析 + 自己执行**
> （`posix_spawn` + `pipe(2)` + `dup2`）。
> 验收基线 `selftest.v` 的 24 项已逐条搬进 `t/31`~`t/34`（两后端全绿）。
> 移植时相对本目录的**三处刻意差异**（都写在新模块注释里）：
> 进程创建改用 `posix_spawn(3)` 而不是「fork + 子进程里 execvp」
> （MoarVM 的 fork 锁死，见 `HANDOFF.md` §4.5）、
> argv 数组用 libc `strdup` + `CArray[Pointer]` 造、修掉 V 版两个真 bug
> （双引号内 `"` 提前结束引号段；`a ; b` 只剩 b 的输出）。

## 为什么停下来

选型曾长期悬而未决（见仓库根的 `HANDOFF.md` 第 5 节）。2026-10-30 实测给出了答案：

| 依赖漂移时的表现 | Raku 实现 | V 实现 |
|---|---|---|
| rakupp 5.3.0 → 5.5.0 | 退化：1 个测试回归（正则跨后端语义），根因已定位、修复已验证 | — |
| V 编译器 `8471a2a` → `cdfaf29` | — | **构建直接失败**，整个 REPL 跑不起来 |
| 付出的代价 | 降级后仍可用 | 硬崩 |

更要命的是**功能倒退**：V 重写当初是为了拿到更好的 shell 层，结果把 Raku 版已有的
全部交互打磨都丢了（TAB 补全、历史、magic 命令、`Out[n]` 值渲染、报错美化、
会话回放、`~/.rakuishrc`、Ctrl-C 保活）。V 版 REPL 至今只是个裸的读-求值-打印循环。

而 V 路线要求 pty 常驻、ANSI 剥离、提示符边界识别、`%*ENV` 字符串桥 —— 这套复杂度
在 Raku 里**全部消失**（`EVAL` 就在同一进程内）。白皮书第 0.1 节早就论证过这一点。

## 这里有什么

| 文件 | 内容 | 移植价值 |
|---|---|---|
| `shell_lexer.v` | 词法：引号保留在 `token.text` 里 | ⭐ 高（纯逻辑，537 行） |
| `shell_parser.v` | 语法：Pipeline / Command / Redirect | ⭐ 高 |
| `shell_expand.v` | 展开：变量、引号剥离、glob | ⭐ 高 |
| `rakuish.v` | 执行层：fast path + `run_pipeline`（fork/pipe/dup2） | ⭐ 高（管道/重定向语义） |
| `raku_engine.v` | 常驻 pty 引擎（forkpty + 逐行发送 + ANSI 剥离） | ❌ 低（Raku 里不需要） |
| `shell_repl.v` | 交互式 REPL 循环 | ❌ 低 |
| `main.v` | 入口（`--selftest` / `--ptytest` / `--demo` / REPL） | ❌ 低 |
| `selftest.v` | shell 层回归 24 项 | ⭐ 中（可作移植后的验收基线） |
| `pty_selftest.v` | pty 引擎回归 5 项 | ❌ 低 |

## 还能跑吗

能，但**不再维护**。当前状态（2026-10-30 修完三个缺陷后）：

```bash
cd v
/home/zby/v/v -o rakuish .        # 编译干净
./rakuish --selftest              # 24 通过 / 0 失败
./rakuish --ptytest               # 5 通过 / 0 失败
./rakuish --demo                  # 端到端演示
```

移植时**只取 shell 层**（前 4 行表里标 ⭐ 的），pty 引擎那一路整套丢掉。

## V 0.5 的坑（移植时务必避开）

按费时排前面：

1. **`dup2` 参数顺序**：`dup2(oldfd, newfd)` 里 **oldfd 是源**。`2>&1` = `dup2(1, 2)`。
   写反的症状极具误导性 —— dup2 返回成功、`2> file` 正常落盘、只有 `2>&1` 静默失效。
2. **`for x in <跨模块结构体数组>` 只迭代一次**（索引恒为 0）。必须写
   `for i < arr.len { x := arr[i] }`。
3. **`argv[1..]` 在 len==1 时 panic**。单参数命令（`cat`/`wc`/`true`）会崩掉整个 REPL。
4. **同名 C 函数、不同签名会被 V 合并**。fd 操作一律用官方 API：
   `os.pipe / os.fd_dup / os.fd_dup2 / os.fd_close / os.fd_write / os.read_bytes`。
5. **execvp 的 argv 形参必须写 `voidptr`**；`[64]&char{}` 的元素初值是**垃圾指针**，
   必须逐个置 nil。
6. **`os.execvp` 自带一个 argv[0]** —— 要传 `argv[1..]`，否则变成
   `tr a-z A-Z A-Z`（extra operand）。
7. **V 的 `eprintln` 走 C stderr 流，dup2 后仍写旧 fd**。重定向生效的子进程里
   报错必须用 `os.fd_write(2, msg)`。
8. `os.remove` → `os.rm`；无 `os.read_file` → `os.read_bytes`。
9. **`string.contains` / `string.index` 只接 `string`**，传 char 编译失败。
10. 捕获子进程输出用**临时文件而非 pipe**：父进程先 waitpid 再读文件，
    彻底避免「管道缓冲区写满 → 子进程阻塞 → 父进程等 waitpid」的死锁。
11. 反引号字符串不支持 `$`；单引号字符串**支持** `${}` 与 `$NAME` 插值 ——
    消息文本含 `$` 必须用双引号 + `\$`。
12. `v test .` 不走工程模块解析（`_test.v` 当独立文件编译）。
    测试写成普通模块 + main 里 `--selftest` 分支。
13. **文件名不能以 `_test.v` 结尾** —— V 把它当独立测试文件，不进工程模块图，
    `import` 会报 `cannot import module "..." (not found)`。
14. **形参别写 `mut x &T`**（可变引用形参）—— 新版 V 直接拒：
    `parameter 'x' is 'mut x &T' ...`。写成 `x &T` 再在体内
    `mut xx := unsafe { x }`（与 `eval_line` 一致）。
