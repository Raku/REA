module shell_lexer

// 外壳层词法（shell-design 4.1）
// 逐字符状态机，不做正则 —— shell 词法需要精确控制引号边界与转义，
// 正则反而会在这些地方打转。
//
// V 坑：u8.str() 返回**码点数值**（'echo' -> "10199104111"），
// 取真实字符要用 ascii_str()。

pub enum TokKind {
	word
	op
}

pub struct Token {
pub:
	kind TokKind
	text string
	quoted bool
}

// 反斜杠可转义的后续字符（bash 语义）
fn is_escapable(c u8) bool {
	return c == 0x5C || c == `"` || c == `$` || c == 0x60 || c == `>` || c == ` `
		|| c == 0x27 || c == 0x09
}

pub fn lex(src string) []Token {
	mut toks := []Token{}
	mut cur := ''
	mut has_cur := false
	mut mode := 0 // 0=bare 1=single 2=double
	mut i := 0
	mut q := false

	for i < src.len {
		c := src[i]
		if mode == 1 {
			// 单引号：原样（bash 语义：单引号内一切不转义）
			// 引号字符保留在 text 里 —— expand_arg 要靠它区分
			// 单/双引号上下文（丢了就会把 'a $B' 错误展开）
			if c == 0x27 {
				mode = 0
				cur += c.ascii_str()
			} else {
				cur += c.ascii_str()
			}
			i++
			continue
		}
		if mode == 2 {
			if c == `"` {
				mode = 0
				cur += c.ascii_str()
				i++
				continue
			}
			if c == 0x5C && i + 1 < src.len {
				nx := src[i + 1]
				if is_escapable(nx) {
					cur += nx.ascii_str()
					i += 2
					continue
				}
			}
			cur += c.ascii_str()
			i++
			continue
		}

		// ── bare 模式 ────────────────────────────────────────────
		if c == 0x5C && i + 1 < src.len {
			// bare 模式的反斜杠转义（这是之前漏掉的一处：
			// 只在双引号里处理了，导致 `echo a\ b` 被切成两个词）
			nx := src[i + 1]
			if is_escapable(nx) {
				cur += nx.ascii_str()
				has_cur = true
				i += 2
				continue
			}
		}
		if c == ` ` || c == 0x09 {
			if has_cur {
				toks << Token{ kind: .word, text: cur, quoted: q }
				cur = ''
				has_cur = false
				q = false
			}
			i++
			continue
		}
		if c == 0x27 {
			mode = 1
			has_cur = true
			q = true
			cur += c.ascii_str()
			i++
			continue
		}
		if c == `"` {
			mode = 2
			has_cur = true
			q = true
			cur += c.ascii_str()
			i++
			continue
		}
		if c == `|` || c == `;` || c == `&` {
			if has_cur {
				toks << Token{ kind: .word, text: cur, quoted: q }
				cur = ''
				has_cur = false
				q = false
			}
			// `&>` / `&>>` = stdout+stderr 一并重定向（bash 语义）
			// 不合并的话 parser 看到裸 `&`，会把当前命令提前切掉
			if c == `&` && i + 1 < src.len && src[i + 1] == `>` {
				if i + 2 < src.len && src[i + 2] == `>` {
					toks << Token{ kind: .op, text: '&>>', quoted: false }
					i += 3
				} else {
					toks << Token{ kind: .op, text: '&>', quoted: false }
					i += 2
				}
				continue
			}
			toks << Token{ kind: .op, text: c.ascii_str(), quoted: false }
			i++
			continue
		}
		// `!` 只在**词首**切出 op（`echo hi!` 里的 ! 属于词内容）
		if c == `!` && !has_cur {
			toks << Token{ kind: .op, text: '!', quoted: false }
			i++
			continue
		}
		if c == `<` || c == `>` {
			if has_cur {
				toks << Token{ kind: .word, text: cur, quoted: q }
				cur = ''
				has_cur = false
				q = false
			}
			// 两个 > = 追加重定向（>>> 不是我们要的语法，
			// 之前误写成判断三个 >，导致 >> 被拆成两个单 token）
			if c == `>` && i + 1 < src.len && src[i + 1] == `>` {
				toks << Token{ kind: .op, text: '>>', quoted: false }
				i += 2
			} else if i + 1 < src.len && src[i + 1] == `&` {
				toks << Token{ kind: .op, text: c.ascii_str() + '&', quoted: false }
				i += 2
			} else {
				toks << Token{ kind: .op, text: c.ascii_str(), quoted: false }
				i++
			}
			continue
		}
		cur += c.ascii_str()
		has_cur = true
		i++
	}
	if has_cur {
		toks << Token{ kind: .word, text: cur, quoted: q }
	}
	return toks
}
