module shell_expand

import os

// 外壳层展开（shell-design 4.3）
// 顺序：变量展开 → 命令替换 → glob → 引号剥离
// 本模块实现「变量展开 / 引号剥离 / glob」，命令替换 $( ) 留待后续
// （它需要执行器，会造成循环依赖，故放在 executor 里调用）。

// 剥掉一层引号。词法阶段已把内容原样收进来，这里只去壳。
pub fn unquote(s string) string {
	if s.len < 2 {
		return s
	}
	a := s[0]
	b := s[s.len - 1]
	if (a == 0x27 && b == 0x27) || (a == `"` && b == `"`) {
		return s[1..s.len - 1]
	}
	return s
}

fn is_name_char(c u8) bool {
	return (c >= `a` && c <= `z`) || (c >= `A` && c <= `Z`) || (c >= `0` && c <= `9`)
		|| c == `_`
}

// 变量展开：$VAR / ${VAR}
// 查 %*ENV（进程环境）—— **不查 shell 变量表**，因为隔离契约要求
// shell 变量与 Raku 变量互不可见；shell 变量经 export 进环境后才可见。
pub fn expand_vars(s string) string {
	if !s.contains('$') {
		return s
	}
	mut out := ''
	mut i := 0
	for i < s.len {
		c := s[i]
		if c == 0x5C && i + 1 < s.len {
			nx := s[i + 1]
			if nx == 0x5C || nx == `"` || nx == `$` {
				out += nx.ascii_str()
				i += 2
				continue
			}
		}
		if c == `$` && i + 1 < s.len {
			// ${VAR}
			if s[i + 1] == `{` {
				// string.index 只接一个参数且返回 ?int，必须 unwrap
				rest := s[i + 2..]
				close := rest.index('}') or { -1 }
				if close >= 0 {
					name := rest[..close]
					out += os.getenv(name)
					i = i + 2 + close + 1
					continue
				}
			}
			// $VAR
			if is_name_char(s[i + 1]) {
				mut j := i + 1
				mut name := ''
				for j < s.len && is_name_char(s[j]) {
					name += s[j].ascii_str()
					j++
				}
				out += os.getenv(name)
				i = j
				continue
			}
		}
		out += c.ascii_str()
		i++
	}
	return out
}

// ── 参数级展开：引号感知（shell-design §4.3 的正确顺序）──────────
// 之前的实现是「先 unquote 剥壳、再 expand_vars 展开」——
// 剥壳之后单引号/双引号的上下文丢了，导致 `echo 'a $B'` 被错误展开
// （bash 语义：单引号内一切原样）。实测踩坑后改为一步完成：
//   · 单引号段：一切原样
//   · 双引号段：变量展开 + \" \\ \$ 转义
//   · 裸段：变量展开 + \ 转义
// 引号字符本身不进入输出（展开与剥引号合一）。
pub fn expand_arg(s string) string {
	mut out := ''
	mut i := 0
	mut mode := 0 // 0=bare 1=single 2=double
	for i < s.len {
		c := s[i]
		if mode == 1 {
			if c == 0x27 {
				mode = 0
			} else {
				out += c.ascii_str()
			}
			i++
			continue
		}
		if mode == 2 {
			if c == `"` {
				mode = 0
				i++
				continue
			}
			if c == 0x5C && i + 1 < s.len {
				nx := s[i + 1]
				if nx == `"` || nx == 36 || nx == 92 {
					out += nx.ascii_str()
					i += 2
					continue
				}
			}
			if c == 36 {
				adv, txt := expand_var_at(s, i)
				out += txt
				i += adv
				continue
			}
			out += c.ascii_str()
			i++
			continue
		}
		// ── bare ──
		if c == 0x27 {
			mode = 1
			i++
			continue
		}
		if c == `"` {
			mode = 2
			i++
			continue
		}
		if c == 0x5C && i + 1 < s.len {
			nx := s[i + 1]
			if nx == 92 || nx == `"` || nx == 36 || nx == 0x27 {
				out += nx.ascii_str()
				i += 2
				continue
			}
		}
		if c == 36 {
			adv, txt := expand_var_at(s, i)
			out += txt
			i += adv
			continue
		}
		out += c.ascii_str()
		i++
	}
	return out
}

// 从 s[i]（$ 处）展开一个变量，返回 (消耗字节数, 值)
fn expand_var_at(s string, i int) (int, string) {
	if i + 1 >= s.len {
		return 1, '$'
	}
	if s[i + 1] == `{` {
		rest := s[i + 2..]
		close := rest.index('}') or { -1 }
		if close >= 0 {
			name := rest[..close]
			return 2 + close + 1, os.getenv(name)
		}
	}
	if is_name_char(s[i + 1]) {
		mut j := i + 1
		mut name := ''
		for j < s.len && is_name_char(s[j]) {
			name += s[j].ascii_str()
			j++
		}
		return j - i, os.getenv(name)
	}
	return 1, '$'
}

// glob 展开：含 * ? 的参数才展开；无匹配则原样保留（bash 语义）。
// 刻意与 expand_vars 分开 —— 它要碰文件系统，是 IO 而非纯字符串变换。
pub fn glob_expand(pattern string) []string {
	if !pattern.contains('*') && !pattern.contains('?') {
		return [pattern]
	}
	// 真实 API 是 os.glob(pattern) ![]string（会失败），不是 glob.glob_file。
	hits := os.glob(pattern) or { return [pattern] }
	if hits.len == 0 {
		return [pattern]
	}
	return hits
}
