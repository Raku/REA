Module {
	name: 'rakuish'
	description: 'Rakuish - bash style shell + Raku escape layer'
	version: '0.2.0'
	license: 'Artistic-2.0'
	dependencies: []
}
