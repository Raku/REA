module raku_engine

import strings

// 🔴 本轮 V/引擎踩坑清单（写这块必看）
// 14. C 函数声明写 `fn C.name(...)` —— **不要** extern（报 "extern evaluated
//     but not used"）、**不要** @[link]（默认链 libc）。
// 15. V 字符串传给 C 用 `&char(s.str)`，没有 `cstr()` 方法。
// 16. `[]&byteptr` 的元素类型会变成 `&&u8`；改用 `[]byteptr`。
// 17. `last_index` / `index` 返回 ?int，要 `or { -1 }` unwrap。
// 18. **C.read 在 pty 上是阻塞的**：没数据时永远挂起，循环 guard 无效，
//     整个程序卡死。必须先 `ioctl(fd, FIONREAD)` 问可读字节数，0 就不读。
// 19. `C.ioctl` / `C.usleep` 等 **V 已内置声明**，重复声明会报
//     "already declared with a different signature"。直接用内置的。
// 20. **可变数组取元素地址（`&buf[0]`）必须包在 `unsafe { }` 里**。
// 21. `[]u8` 切片转 string 用 **`.bytestr()`**；用 `.str()` 会打印
//     [109, 121, ...]（每个字节的整数）。
// 23. `trim(0,0)` 是切片不是字符串 trim；去空白用 `trim_space()`。
//
// ── 引擎层最关键的一条（第 24 条）────────────────────────────────
// rakupp/MoarVM 的 REPL 输出**全带 ANSI 转义序列**，提示符是绿色的
// `\x1b[1;32m>\x1b[0m `，而且**开启行编辑**：每敲一个字符就回显
// `> <累积输入>`。
// 所以「见到裸 > 就收」会在第一个字符处返回，把回显当结果。
// 正确顺序：**先剥 ANSI → 再按「行首的 > 」判结束 → 最后过滤回显行**。

fn C.forkpty(&int, &u8, voidptr, voidptr) int
fn C.execv(byteptr, voidptr) int
fn C.waitpid(int, voidptr, int) int
fn C.close(int) int
fn C.read(int, voidptr, usize) isize
fn C.write(int, voidptr, usize) isize
fn C._exit(int)

// FIONREAD（Linux）
const fionread = 0x541B

pub struct Engine {
pub mut:
	pid    int
	master int
	alive  bool
	// shell → Raku 的 %*ENV 镜像前缀（白皮书 §4 的字符串桥）。
	// Raku 的 %*ENV 是启动快照，之后 os.setenv 改 C 层 environ 它看不到，
	// 所以每次求值前把 shell 变量以 `%*ENV<K> = 'v';` 形式**前置注入**。
	env_prefix string
}

// 构造 %*ENV 镜像前缀（值做单引号转义）
pub fn make_env_prefix(vars map[string]string) string {
	if vars.len == 0 {
		return ''
	}
	mut sb := strings.new_builder(256)
	mut keys := vars.keys()
	keys.sort()
	for k in keys {
		v := vars[k]
		// 单引号串内的单引号用 \x27 表示（Raku 双引号里的转义）
		// 正确语法（实测 rakupp -e 确认）：%*ENV<KEY> = 'value';
		// **KEY 不能加引号** —— 写成 %*ENV<'KEY'> 会静默失效。
		// 值做单引号转义（反斜杠与单引号）。
		apostrophe := u8(0x27).str()
		safe := v.replace('\\', '\\\\').replace(apostrophe, "\\x27")
		sb.write_string("%*ENV<${k}> = '${safe}';")
	}
	return sb.str()
}

// 剥掉 ANSI 转义序列（CSI 与 OSC）
fn strip_ansi(raw string) string {
	// 用 strings.Builder 而不是手搓字节数组 —— 这版 V 里
	// []u8{len: N, init: [...]}(u8 被推成 []u8) 与 make() 都不可用。
	mut sb := strings.new_builder(unsafe { raw.len })
	mut i := 0
	for i < raw.len {
		c := raw[i]
		if c == 0x1B {
			if i + 1 < raw.len && raw[i + 1] == 0x5B {
				// CSI: ESC [ 参数 中间 终结
				i += 2
				for i < raw.len && raw[i] >= 0x20 && raw[i] <= 0x3F {
					i++
				}
				if i < raw.len {
					i++
				}
				continue
			}
			if i + 1 < raw.len && raw[i + 1] == 0x5D {
				// OSC: ESC ] ... BEL
				i += 2
				for i < raw.len && raw[i] != 0x07 {
					i++
				}
				if i < raw.len {
					i++
				}
				continue
			}
			i++
			continue
		}
		sb.write_u8(c)
		i++
	}
	return sb.str()
}

// 一轮结束判据：剥 ANSI 后，文本以「行首的 > 」收尾
fn ends_with_prompt(raw string) bool {
	clean := strip_ansi(raw)
	mut t := clean
	for t.len > 0 {
		last := t[t.len - 1]
		if last != ` ` && last != `\t` && last != `\r` && last != `\n` {
			break
		}
		t = t[..t.len - 1]
	}
	if !t.ends_with('>') {
		return false
	}
	if t.len == 1 {
		return true
	}
	return t[t.len - 2] == `\n`
}

// 剥掉提示符与行编辑回显行
fn strip_prompt(raw string) string {
	clean := strip_ansi(raw)
	mut kept := []string{}
	for l in clean.split('\n') {
		mut t := l.trim_space()
		if t == '' || t == '>' {
			continue
		}
		if t.starts_with('>') {
			continue
		}
		kept << t
	}
	return kept.join('\n')
}

fn do_read(fd int, buf &u8, len int) isize {
	return unsafe { C.read(fd, buf, len) }
}

fn do_write(fd int, data string) isize {
	return unsafe { C.write(fd, data.str, data.len) }
}

// 先 ioctl 问可读字节数，避免 C.read 阻塞卡死
fn readable_bytes(fd int) int {
	mut n := 0
	r := unsafe { C.ioctl(fd, u64(fionread), voidptr(&n)) }
	if r != 0 {
		return 0
	}
	return n
}

fn read_available(fd int) string {
	avail := readable_bytes(fd)
	if avail <= 0 {
		return ''
	}
	// 固定栈数组（这版 V 里 []u8{len:..} / make() 都不可用）
	mut buf := [65536]u8{}
	mut want := avail
	if want > 65535 {
		want = 65535
	}
	n := unsafe { do_read(fd, &buf[0], want) }
	if n <= 0 {
		return ''
	}
	return buf[..n].bytestr()
}

// 启动常驻 REPL 子进程
pub fn start(prog string, args []string) !Engine {
	mut master := 0
	mut name := [128]u8{}
	pid := unsafe { C.forkpty(&master, &name[0], voidptr(0), voidptr(0)) }
	if pid < 0 {
		return error('forkpty failed')
	}
	if pid == 0 {
		// 子进程：exec 目标程序
		// 固定栈数组：这版 V 里 []T{len:..} / make() 都不可用
		mut argv := [64]byteptr{}
		mut k := 0
		argv[k] = &char(prog.str)
		k++
		for a in args {
			if k >= 63 {
				break
			}
			argv[k] = &char(a.str)
			k++
		}
		argv[k] = byteptr(0)
		// argv 是栈数组（没有 .data 字段），直接用 unsafe 指针转换
		unsafe { C.execv(argv[0], voidptr(&argv[0])) }
		unsafe { C._exit(127) }
	}
	mut e := Engine{ pid: pid, master: master, alive: true }
	drain_banner(&e)
	return e
}

// 丢弃 banner：一直读到首个提示符
//
// 形参写 `&Engine`（不可变引用）再在体内 `mut ee := unsafe { e }` ——
// 写 `mut e &Engine`（可变引用形参）会被新版 V 拒：
//   "parameter `e` is `mut e &Engine` ... pass `mut` of a `&Engine` variable"
// 这与本文件 eval_line 的写法一致（见该函数上方注释）。
fn drain_banner(e &Engine) {
	mut ee := unsafe { e }
	mut acc := ''
	mut guard := 0
	for guard < 2000 {
		chunk := read_available(ee.master)
		if chunk.len > 0 {
			acc += chunk
			if ends_with_prompt(acc) {
				return
			}
		} else {
			unsafe { C.usleep(1000) }
		}
		guard++
	}
}

// 送一行，返回本轮结果（已剥 ANSI 与回显）
//
// 一轮结束有**两个**判据（缺一不可）：
//   ① 收到带提示符的行尾（正常路径）
//   ② **静默超时**（错误路径）—— 错误输出常常不带提示符收尾，
//      死等提示符会卡住几十秒。
// 注意：形参**不要**写 mut。`&Engine` 已是引用；写 `mut e &Engine`
// 会变成「可变引用形参」，调用时要求传可写引用，而调用方又要声明 mut，
// 两边一撞就成了死结（传值报 mutable reference，传引用报 immutable）。
pub fn eval_line(e &Engine, code string) string {
	if !e.alive {
		return '(引擎已退出)'
	}
	// e 是 &Engine 引用；绑定到 mut 局部也要 unsafe（可能指向栈对象）
	mut ee := unsafe { e }
	// shell → Raku 的 %*ENV 镜像注入（白皮书 §4 字符串桥）
	send := if ee.env_prefix != '' { ee.env_prefix + ' ' + code } else { code }
	do_write(ee.master, send + '\n')
	mut acc := ''
	mut idle := 0        // 连续空读次数
	mut guard := 0
	// 静默阈值：约 60ms 无新数据即认为本轮结束（每次循环 400µs）
	silent_limit := 150
	for guard < 20000 {
		chunk := read_available(ee.master)
		if chunk.len > 0 {
			acc += chunk
			idle = 0
			if ends_with_prompt(acc) {
				return strip_prompt(acc)
			}
		} else {
			unsafe { C.usleep(400) }
			idle++
			if idle >= silent_limit {
				// 静默足够久：本轮结束（多半是错误输出）
				break
			}
		}
		guard++
	}
	return strip_prompt(acc)
}

pub fn stop(e &Engine) {
	mut ee := unsafe { e }
	if ee.alive {
		do_write(ee.master, "exit\n")
		unsafe { C.waitpid(ee.pid, voidptr(0), 0) }
		unsafe { C.close(ee.master) }
		unsafe { ee.alive = false }
	}
}