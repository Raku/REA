module shell_parser

import shell_lexer

// 外壳层语法（shell-design 4.2）
// Pipeline：; 分隔；每条流水线内 | 分段为 Command；每个 Command 带重定向。
//
// V 坑（已踩）：for 循环变量默认不可变，必须 `mut i := 0`。

pub enum RedirKind {
	in
	out
	append
	dup // fd 复制：2>&1 / >&2
}

pub struct Redirect {
pub:
	kind RedirKind
	target string
	fd int // 被重定向的源 fd（默认 1 = stdout）
	dup_fd int // kind == .dup 时的目标 fd
	// 整数形态的 kind。**跨模块直接比较 enum 不可靠**（V 0.5 里
	// enum 在不同模块各自实例化，int() 取到的值可能对不上 ——
	// 实测 rakuish.v 里 `r.kind == .dup` 恒为假，.dup 分支从不执行）。
	// 由 parser 在**构造时**用本模块的字面量填好，执行层只比整数。
	kind_i int
}

// 本模块内的 kind 序号（与 RedirKind 声明顺序严格一致）
const ki_in = 0
const ki_out = 1
const ki_append = 2
const ki_dup = 3

fn redir(kind RedirKind, target string, fd int, dup_fd int) Redirect {
	mut ki := ki_in
	if kind == .out {
		ki = ki_out
	} else if kind == .append {
		ki = ki_append
	} else if kind == .dup {
		ki = ki_dup
	}
	return Redirect{ kind: kind, target: target, fd: fd, dup_fd: dup_fd, kind_i: ki }
}

pub struct Command {
pub:
	args []string
	redirs []Redirect
}

pub struct Pipeline {
pub:
	commands []Command
	negated bool
}

fn default_redir(kind RedirKind, target string) Redirect {
	fd := if kind == .in { 0 } else { 1 }
	return redir(kind, target, fd, 2)
}

// 词是不是纯数字（用于 `2>&1` 的 fd 前缀识别）
fn is_digits(s string) bool {
	if s.len == 0 {
		return false
	}
	for c in s {
		if c < `0` || c > `9` {
			return false
		}
	}
	return true
}

pub fn parse(line string) []Pipeline {
	toks := shell_lexer.lex(line)
	mut pipes := []Pipeline{}
	mut args := []string{}
	mut cur_redirs := []Redirect{}
	mut cmds := []Command{}
	mut negated := false

	mut i := 0
	for i < toks.len {
		t := toks[i]
		if t.kind == .word {
			args << t.text
		} else {
			// op token
			if t.text == '<' || t.text == '>' || t.text == '>>' {
				//重定向**属于当前 command** —— 不能在这里 flush，
				// 否则 `echo x >> log` 会把重定向甩给下一个 command。
				mut kind := RedirKind.out
				if t.text == '<' {
					kind = .in
				} else if t.text == '>>' {
					kind = .append
				}
				// fd 前缀：紧邻重定向符号的数字 word 是源 fd。
				// 默认值随方向不同 —— `<` 是 stdin(0)，`>`/`>>` 是 stdout(1)。
				mut fd := if kind == .in { 0 } else { 1 }
				if args.len > 0 {
					lastw := args[args.len - 1]
					if is_digits(lastw) {
						fd = lastw.int()
						args = args[..args.len - 1]
					}
				}
				mut target := ''
				if i + 1 < toks.len {
					i++
					target = toks[i].text
				}
				cur_redirs << redir(kind, target, fd, 2)
			} else if t.text == '>&' {
				// `2>&1` / `>&2` —— 源 fd 取自紧邻的数字前缀
				mut fd := 1
				if args.len > 0 {
					lastw := args[args.len - 1]
					if is_digits(lastw) {
						fd = lastw.int()
						args = args[..args.len - 1]
					}
				}
				mut dst := 2
				if i + 1 < toks.len {
					i++
					nxt := toks[i].text
					dst = if is_digits(nxt) { nxt.int() } else { 2 }
				}
				cur_redirs << redir(.dup, '', fd, dst)
			} else if t.text == '&>' || t.text == '&>>' {
				// `cmd &> f` = `> f 2>&1`（展开成两条，简化执行器）
				mut kind := RedirKind.out
				if t.text == '&>>' {
					kind = .append
				}
				mut target := ''
				if i + 1 < toks.len {
					i++
					target = toks[i].text
				}
				cur_redirs << default_redir(kind, target)
				cur_redirs << redir(.dup, '', 2, 1)
			} else if t.text == '!' {
				negated = true
			} else {
				// ; | & —— 这里才结束当前 command
				if args.len > 0 || cur_redirs.len > 0 {
					cmds << Command{ args: args.clone(), redirs: cur_redirs.clone() }
				}
				args = []
				cur_redirs = []
				if t.text == ';' {
					if cmds.len > 0 {
						pipes << Pipeline{ commands: cmds.clone(), negated: negated }
					}
					cmds = []
					negated = false
				}
			}
		}
		i++
	}
	// 收尾
	if args.len > 0 || cur_redirs.len > 0 {
		cmds << Command{ args: args.clone(), redirs: cur_redirs.clone() }
	}
	if cmds.len > 0 {
		pipes << Pipeline{ commands: cmds, negated: negated }
	}
	return pipes
}
