module main

// ─────────────────────────────────────────────────────────────
// ⚠️ 本文件属于 **Rakuish v0.2（V 实现）—— 已停止维护**。
//    项目主线是 Raku 实现（../lib + ../bin/rakuish）。
//    本目录保留只为把 shell 层（lexer/parser/expand）移植进 Raku 实现。
//    详见 v/README.md（含 V 0.5 的 14 条坑）。
// ─────────────────────────────────────────────────────────────

import os
import shell_repl
import selftest
import pty_selftest
import rakuish
import raku_engine

// 路由 + 打印。**不接管引擎**（V 的 mut 引用传参死结）：
// 逃逸行只把代码放进 ExecOutcome，由调用方决定何时送引擎。
fn show(mut s rakuish.Session, label string, line string) rakuish.ExecOutcome {
	out := rakuish.run_line(mut s, line)
	mark := if out.ok { 'ok ' } else { 'ERR' }
	println('  [${mark}] ${label}')
	println('        > ${line}')
	if !out.is_raku && out.stdout.trim_space() != '' {
		println('        ${out.stdout.trim_space()}')
	}
	println('')
	return out
}

// 送引擎并打印。白皮书 §4：每次求值前注入 shell 变量的 %*ENV 镜像。
// %*ENV 镜像直接前置到代码里，不依赖 Engine.env_prefix ——
// V 里跨函数改 &T 的字段太容易踩坑，而「拼接前缀」本就是白皮书认可的机制。
fn ev(eng &raku_engine.Engine, label string, code string, prefix string) {
	// 真正发给引擎的是**拼好前缀的一行**（不是 eval "..."）——显示要与实际一致，
	// 否则排查时会被显示内容误导。
	send := if prefix != '' { prefix + ' ' + code } else { code }
	println('  [raku] ${label}')
	println('        > ${send}')
	r := raku_engine.eval_line(eng, send)
	if r.trim_space() != '' {
		println('        ${r.trim_space()}')
	}
	println('')
}

fn run_demo(prog string) {
	println('Rakuish v0.2 演示')
	println('路由：裸词默认走 shell；只有 eval "..." / raku { } 进 Raku 引擎')
	println('')

	mut s := rakuish.Session{ vars: {} }
	mut eng := raku_engine.start(prog, []) or {
		println('引擎启动失败: ${err}')
		exit(1)
	}
	mut prefix := ''

	println('── 一、shell 命令（不需要任何前缀）──────────────────')
	show(mut s, '外部命令', 'echo hello from shell')
	mut o := show(mut s, '内建 export', 'export NAME=rakuish')
	prefix = o.env_prefix
	show(mut s, '环境变量展开', 'echo $NAME')
	show(mut s, 'cd 进程内生效', 'cd /tmp')
	show(mut s, 'pwd 看到新目录', 'pwd')

	println('── 二、shell → Raku 字符串桥（白皮书 §4）────────────')
	ev(&eng, 'Raku 经 %*ENV 读到 shell 变量', '%*ENV<NAME>', prefix)
	ev(&eng, 'Raku 看不到 shell 裸变量（两侧隔离）', 'NAME', prefix)

	println('── 三、Raku 逃逸层（常驻引擎）────────────────────')
	ev(&eng, '声明变量', 'my $count = 10', prefix)
	ev(&eng, '下次仍可见（状态存活）', '$count * 2', prefix)
	ev(&eng, '强类型结果保留', '1..5', prefix)
	ev(&eng, '惰性序列 + grep', '(1..10).grep(* %% 3)', prefix)
	ev(&eng, '正则提取', "'a1b2c3'.comb(/<[a..z]>/).join('-')", prefix)
	ev(&eng, '哈希排序', "%('a' => 1, 'b' => 2).keys.sort.join(',')", prefix)

	println('── 四、错误处理（不杀引擎）────────────────────────')
	ev(&eng, '触发错误', '1/0', prefix)
	ev(&eng, '出错后仍可用', '$count * 3', prefix)

	raku_engine.stop(&eng)
	println('演示结束')
}

fn main() {
	prog := os.getenv_opt('RAKUISH_ENGINE') or { '/home/zby/.rakupp/bin/rakupp' }
	arg := if os.args.len > 1 { os.args[1] } else { '' }
	if arg == '--selftest' {
		n := selftest.run()
		if n > 0 {
			exit(1)
		}
	} else if arg == '--ptytest' {
		n := pty_selftest.run()
		if n > 0 {
			exit(1)
		}
	} else if arg == '--demo' {
		run_demo(prog)
	} else {
		shell_repl.run(prog)
	}
}
