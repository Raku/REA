module shell_repl

import os
import rakuish
import raku_engine

// ── Rakuish v0.2 交互式 REPL ───────────────────────────────────────
//
// 读-求值-打印循环（白皮书第三节的 MVP 切片）：
//   · 提示符 rakuish> ；多行输入（未闭合引号 / raku { 块）自动续行
//   · 裸词走 shell 路由；eval "..." / raku { } 穿过逃逸层进常驻引擎
//   · exit / quit / Ctrl-D 退出
//
// 关键约束（V 踩坑记录）：本模块**不接管引擎可变性** ——
// eng 是 run() 内的 mut 局部变量，求值处直接传 &eng
// （main.v 已验证 &eng 引用传参可行，绕开 `mut x &T` 死结）。

const prompt_main = 'rakuish> '
const prompt_cont = '     ... '

// 扫一遍源码，判断是否还有未闭合的引号（跳过 \ 转义）
fn unclosed_quote(src string) bool {
	mut sq := false
	mut dq := false
	mut i := 0
	for i < src.len {
		c := src[i]
		if c == 92 { // \ 转义：连同下一个字符一起跳过
			i += 2
			continue
		}
		if !dq && c == 0x27 {
			sq = !sq
		} else if !sq && c == `"` {
			dq = !dq
		}
		i++
	}
	return sq || dq
}

// raku { } 块是否还没闭合：数花括号深度（跳过字符串与转义）
fn block_open(src string) bool {
	mut depth := 0
	mut sq := false
	mut dq := false
	mut i := 0
	for i < src.len {
		c := src[i]
		if c == 92 {
			i += 2
			continue
		}
		if !dq && c == 0x27 {
			sq = !sq
		} else if !sq && c == `"` {
			dq = !dq
		} else if !sq && !dq {
			if c == `{` {
				depth++
			} else if c == `}` {
				depth--
			}
		}
		i++
	}
	return depth > 0
}

// 读一行；EOF（Ctrl-D）返回 none
// 注意：os.get_line() 对 EOF 与空行都返回 ''，必须靠 C.feof 区分
fn read_line() ?string {
	l := os.get_line()
	if l == '' && C.feof(C.stdin) != 0 {
		return none
	}
	return l
}

// 读一条完整语句：未闭合引号或 raku { 块时换行续读
fn read_statement() ?string {
	mut acc := ''
	mut cont := false
	for {
		print(if cont { prompt_cont } else { prompt_main })
		flush_stdout()
		line := read_line() or { return none }
		if acc == '' {
			acc = line
		} else {
			acc += '\n' + line
		}
		cont = false
		t := acc.trim_space()
		if t.len > 0 {
			if (rakuish.raku_block_open(t) && block_open(t)) || unclosed_quote(t) {
				cont = true
			}
		}
		if !cont {
			return acc
		}
	}
}

// 送引擎并打印。白皮书 §4：每次求值前注入 shell 变量的 %*ENV 镜像前缀。
fn run_raku(eng &raku_engine.Engine, prefix string, code string) {
	send := if prefix != '' { prefix + ' ' + code } else { code }
	r := raku_engine.eval_line(eng, send)
	t := r.trim_space()
	if t != '' {
		println(t)
	}
}

// ── REPL 主循环 ────────────────────────────────────────────────────
pub fn run(prog string) {
	mut s := rakuish.Session{
		vars: {}
		passthrough: true // 外部命令直接继承 stdio（颜色/进度条/交互命令保留）
	}
	mut eng := raku_engine.start(prog, []) or {
		eprintln('rakuish: 引擎启动失败: ${err}')
		return
	}
	println('Rakuish v0.2 —— 裸词走 shell；eval "..." / raku { } 进 Raku；exit 或 Ctrl-D 退出')
	println('')
	for {
		line := read_statement() or {
			println('')
			break
		}
		t := line.trim_space()
		if t == '' {
			continue
		}
		// 退出（内建，优先于 shell 路由）
		if t == 'exit' || t == 'quit' {
			break
		}
		// raku { ... } 多行块：剥掉外壳，整体送引擎
		if rakuish.raku_block_open(t) {
			mut body := rakuish.raku_block_body(t).trim_space()
			if body.ends_with('}') {
				body = body[..body.len - 1].trim_space()
			}
			run_raku(&eng, raku_engine.make_env_prefix(s.vars), body)
			continue
		}
		// 其余走统一路由（eval "..." 在这里被识别为逃逸）
		out := rakuish.run_line(mut s, t)
		if out.is_raku {
			run_raku(&eng, out.env_prefix, out.stdout)
		} else if out.stdout.trim_space() != '' {
			println(out.stdout.trim_space())
		}
	}
	raku_engine.stop(&eng)
}
