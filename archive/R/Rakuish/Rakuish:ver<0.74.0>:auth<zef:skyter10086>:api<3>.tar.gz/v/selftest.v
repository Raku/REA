module selftest

import os
import shell_lexer
import shell_parser
import shell_expand
import rakuish

// ── Rakuish shell 层回归测试 ──────────────────────────────────────
// 跑法：cd v && /home/zby/v/v -o rakuish . && ./rakuish --selftest
// （不用 v test —— 它把 _test.v 当独立文件编译，不走工程模块解析，
//  import 同目录模块会 not found。实测踩的坑。）
//
// V 字符串备忘（本轮连踩三次）：
//   · 反引号字符串不支持 $（会被当字符字面量，直接编译错）
//   · 单引号字符串**支持** ${} 与 $NAME 插值 —— 消息文本里的 $
//     会被当变量插值报 undefined ident；含 $ 字面量一律双引号 + \$
//   · 多返回值 (string, string) 不能直接 << 进数组 ——
//     函数改返回 [2]string 固定数组字面量
//   · V 0.5 的 match 未经验证，main 里用 if-else 链更稳

fn t_lex_quotes_kept_in_text() [2]string {
	toks := shell_lexer.lex("echo 'a \$B' \"c d\"")
	if toks.len != 3 {
		return ['lexer: 引号词切分', "期望 3 个 token，实际 ${toks.len}"]
	}
	if toks[1].text != "'a \$B'" {
		return ['lexer: 单引号文本保留', "期望 'a \$B'，实际 ${toks[1].text}"]
	}
	if toks[2].text != "\"c d\"" {
		return ['lexer: 双引号文本保留', "期望 \"c d\"，实际 ${toks[2].text}"]
	}
	if !toks[1].quoted {
		return ['lexer: quoted 标记', '单引号词 quoted 应为 true']
	}
	return ['lexer: 引号保留', '']
}

fn t_lex_append_redirect() [2]string {
	toks := shell_lexer.lex('echo hi >> log.txt')
	if toks.len != 4 || toks[2].text != '>>' {
		return ['lexer: >> 追加', "token2=${toks[2].text}（曾把 >> 拆成两个 >）"]
	}
	return ['lexer: >> 追加', '']
}

fn t_lex_pipe_and_semi() [2]string {
	toks := shell_lexer.lex('a | b ; c')
	if toks.len != 5 || toks[1].text != '|' || toks[3].text != ';' {
		return ['lexer: 管道与分号', "toks.len=${toks.len}"]
	}
	return ['lexer: 管道与分号', '']
}

fn t_parser_pipeline_structure() [2]string {
	pipes := shell_parser.parse('echo hi | tr a-z A-Z ; ls -l')
	if pipes.len != 2 {
		return ['parser: 流水线条数', "期望 2，实际 ${pipes.len}"]
	}
	if pipes[0].commands.len != 2 || pipes[0].commands[0].args.len != 2 {
		return ['parser: 管道内命令', "commands.len=${pipes[0].commands.len}"]
	}
	if pipes[1].commands.len != 1 {
		return ['parser: 分号后命令', "commands.len=${pipes[1].commands.len}"]
	}
	return ['parser: 流水线结构', '']
}

fn t_expand_arg_single_quote_literal() [2]string {
	os.setenv('RK_TEST', 'xyz', true)
	// bash 语义：单引号内一切原样（「先剥壳后展开」在这里出错）
	got := shell_expand.expand_arg("'a \$RK_TEST'")
	if got != "a \$RK_TEST" {
		return ['expand: 单引号不展开', "期望 a \$RK_TEST，实际 ${got}"]
	}
	return ['expand: 单引号不展开', '']
}

fn t_expand_arg_double_quote_expands() [2]string {
	os.setenv('RK_TEST', 'xyz', true)
	got := shell_expand.expand_arg("\"a \$RK_TEST\"")
	if got != 'a xyz' {
		return ['expand: 双引号展开', "期望 a xyz，实际 ${got}"]
	}
	return ['expand: 双引号展开', '']
}

fn t_expand_arg_bare_var() [2]string {
	os.setenv('RK_TEST', 'xyz', true)
	if shell_expand.expand_arg("a\$RK_TEST") != 'axyz' {
		return ['expand: 裸变量拼接', '拼接失败']
	}
	if shell_expand.expand_arg("\${RK_TEST}b") != 'xyzb' {
		return ['expand: 花括号变量', '花括号形式失败']
	}
	return ['expand: 裸变量与花括号', '']
}

fn t_expand_arg_escaped_dollar() [2]string {
	os.setenv('RK_TEST', 'xyz', true)
	// 裸 \$ 与双引号内 \$ 都应该是字面 $，且阻止后续展开
	if shell_expand.expand_arg("a\\\$RK_TEST") != "a\$RK_TEST" {
		return ['expand: 裸反斜杠美元', '未阻止展开']
	}
	if shell_expand.expand_arg("\"a\\\$RK_TEST\"") != "a\$RK_TEST" {
		return ['expand: 双引号内转义美元', '未阻止展开']
	}
	return ['expand: 转义美元符', '']
}

fn t_expand_arg_mixed_quotes() [2]string {
	os.setenv('RK_TEST', 'xyz', true)
	got := shell_expand.expand_arg("x'y'\$RK_TEST\"z\"")
	if got != 'xyxyzz' {
		return ['expand: 混合引号', "期望 xyxyzz（x+y+xyz+z），实际 ${got}"]
	}
	return ['expand: 混合引号', '']
}

fn t_detect_escape_eval() [2]string {
	e := rakuish.detect_escape("eval \"my \$x = 1\"")
	if !e.is_escape || e.code != "my \$x = 1" {
		return ['逃逸层: eval 识别', "is_escape=${e.is_escape} code=${e.code}"]
	}
	e2 := rakuish.detect_escape('echo hi')
	if e2.is_escape {
		return ['逃逸层: 普通行不误判', 'echo hi 被当成逃逸']
	}
	return ['逃逸层: eval 识别', '']
}

fn t_raku_block() [2]string {
	if !rakuish.raku_block_open('raku {') || !rakuish.raku_block_open('raku{') {
		return ['raku 块: 开块识别', 'raku { 未识别']
	}
	if rakuish.raku_block_open('echo hi') {
		return ['raku 块: 普通行不误判', 'echo hi 被当成 raku 块']
	}
	return ['raku 块: 识别', '']
}

fn t_run_line_shell_routing() [2]string {
	os.setenv('RK_NAME', 'rakuish', true)
	mut s := rakuish.Session{
		vars: {}
	}
	// 批处理模式（passthrough=false）走 execute_opt 捕获 stdout
	out := rakuish.run_line(mut s, "echo \$RK_NAME")
	if out.is_raku {
		return ['路由: 普通行走 shell', '被误判为逃逸']
	}
	if out.stdout.trim_space() != 'rakuish' {
		return ['路由: 外部命令输出', "期望 rakuish，实际 ${out.stdout.trim_space()}"]
	}
	return ['路由: 普通行走 shell', '']
}

fn t_run_line_export_then_expand() [2]string {
	mut s := rakuish.Session{
		vars: {}
	}
	rakuish.run_line(mut s, 'export RK_EXPORTED=yes')
	out := rakuish.run_line(mut s, "echo \$RK_EXPORTED")
	if out.stdout.trim_space() != 'yes' {
		return ['内建: export 后展开', "期望 yes，实际 ${out.stdout.trim_space()}"]
	}
	if !out.env_prefix.contains('RK_EXPORTED') {
		return ['白皮书 §4: env_prefix', '前缀里没有 RK_EXPORTED']
	}
	return ['内建: export 与 env_prefix', '']
}

fn t_run_line_escape_returns_code() [2]string {
	mut s := rakuish.Session{
		vars: {}
	}
	out := rakuish.run_line(mut s, 'eval "1 + 1"')
	if !out.is_raku || out.stdout != '1 + 1' {
		return ['路由: 逃逸行交回代码', "is_raku=${out.is_raku} code=${out.stdout}"]
	}
	return ['路由: 逃逸行交回代码', '']
}

// `&>` 必须被 lexer 切成**单个** op —— 否则 parser 看到裸 `&`
// 会把当前命令提前切掉，重定向落到错误的 command 上
fn t_lex_and_redirect() [2]string {
	toks := shell_lexer.lex('ls /nope &> out.txt')
	mut ands := 0
	for tk in toks {
		if tk.kind == .op && tk.text == '&>' {
			ands++
		}
	}
	if ands != 1 {
		return ['lexer: &> 合并', '期望 1 个 &> op，实际 ${ands}；tokens=${toks.len}']
	}
	return ['lexer: &> 合并', '']
}

// 2> file 应产出 kind=.out 且 fd=2
fn t_parser_stderr_redirect() [2]string {
	ps := shell_parser.parse('ls /nope 2> err.txt')
	if ps.len != 1 || ps[0].commands.len != 1 {
		return ['parser: stderr 重定向', '结构不对']
	}
	rs := ps[0].commands[0].redirs
	if rs.len != 1 {
		return ['parser: stderr 重定向', '期望 1 条重定向，实际 ${rs.len}']
	}
	if rs[0].kind != .out || rs[0].fd != 2 || rs[0].target != 'err.txt' {
		return ['parser: stderr 重定向', '实际 kind=${rs[0].kind} fd=${rs[0].fd} target=${rs[0].target}']
	}
	// 且数字前缀 2 不应留在 args 里
	for a in ps[0].commands[0].args {
		if a == '2' {
			return ['parser: stderr 重定向', 'fd 前缀 2 泄漏进 args']
		}
	}
	return ['parser: stderr 重定向', '']
}

// `<` 的默认源 fd 必须是 0（实测踩坑：写成 1 会让 cat 去读终端，
// 抢走 REPL 的下一行输入）
fn t_parser_in_default_fd() [2]string {
	ps := shell_parser.parse('cat < in.txt')
	if ps.len != 1 || ps[0].commands.len != 1 {
		return ['parser: < 默认 fd', '结构不对']
	}
	rs := ps[0].commands[0].redirs
	if rs.len != 1 {
		return ['parser: < 默认 fd', '期望 1 条重定向，实际 ${rs.len}']
	}
	if rs[0].kind != .in || rs[0].fd != 0 {
		return ['parser: < 默认 fd', '实际 kind=${rs[0].kind} fd=${rs[0].fd}（应为 in/0）']
	}
	return ['parser: < 默认 fd', '']
}

// `!` 只在词首切 op；词内（echo hi!）不算
fn t_parser_negate() [2]string {
	ps := shell_parser.parse('! false')
	if ps.len != 1 {
		return ['parser: ! 取反', '结构不对']
	}
	if !ps[0].negated {
		return ['parser: ! 取反', 'negated 未置位']
	}
	if ps[0].commands.len != 1 || ps[0].commands[0].args != ['false'] {
		return ['parser: ! 取反', '命令被 ! 污染：${ps[0].commands.len} 段']
	}
	return ['parser: ! 取反', '']
}

// 端到端：真跑一条管道（捕获模式）
fn t_run_line_pipe_executes() [2]string {
	mut s := rakuish.Session{ vars: {}, passthrough: false }
	out := rakuish.run_line(mut s, 'echo hi | tr a-z A-Z')
	got := out.stdout.trim_space()
	if got != 'HI' {
		return ['执行: 管道', '期望 HI，实际 "${got}"']
	}
	return ['执行: 管道', '']
}

// `2>&1` 必须产出 kind=.dup fd=2 dup_fd=1，且 2 不能泄漏进 args。
// 实测踩坑：pty 里 `ls /nope > f 2>&1` 的 stderr 仍打到终端、f 为空。
fn t_parser_fd_dup() [2]string {
	ps := shell_parser.parse('ls /nope > f 2>&1')
	if ps.len != 1 || ps[0].commands.len != 1 {
		return ['parser: 2>&1', '结构不对：${ps.len} 条流水线']
	}
	c := ps[0].commands[0]
	if c.args != ['ls', '/nope'] {
		return ['parser: 2>&1', 'args 被污染：${c.args.len} 个 —— ${c.args}']
	}
	if c.redirs.len != 2 {
		return ['parser: 2>&1', '期望 2 条重定向，实际 ${c.redirs.len}']
	}
	r0 := c.redirs[0]
	r1 := c.redirs[1]
	if r0.kind != .out || r0.fd != 1 || r0.target != 'f' {
		return ['parser: 2>&1', "第 1 条应为 out/fd=1/f，实际 kind=${r0.kind} fd=${r0.fd} target=${r0.target}"]
	}
	if r1.kind != .dup || r1.fd != 2 || r1.dup_fd != 1 {
		return ['parser: 2>&1', "第 2 条应为 dup/2->1，实际 kind=${r1.kind} fd=${r1.fd} dup_fd=${r1.dup_fd}"]
	}
	return ['parser: 2>&1', '']
}

// 端到端：`cmd 2> file` 与 `cmd 2>&1 | head` 必须真的改到 fd。
// 实测踩坑：pty 里 `ls /nope > f 2>&1` 的 stderr 仍打到终端、f 为空 ——
// 解析层是对的（见 t_parser_fd_dup），所以要单独盯执行层。
fn t_run_line_redirect_writes_file() [2]string {
	path := '/tmp/rakuish-selftest-redir.txt'
	os.rm(path) or { }
	mut s := rakuish.Session{ vars: {}, passthrough: false }
	// printf 一定有输出，用它验证 stdout 重定向落盘
	rakuish.run_line(mut s, 'printf REDIRECTED > ${path}')
	got := os.read_file(path) or { return ['执行: 重定向落盘', '文件没生成'] }
	if got.trim_space() != 'REDIRECTED' {
		return ['执行: 重定向落盘', '文件内容 "${got.trim_space()}"']
	}
	// 追加
	rakuish.run_line(mut s, 'printf -NAPPED >> ${path}')
	got2 := os.read_file(path) or { return ['执行: 追加落盘', '文件丢了'] }
	if !got2.contains('REDIRECTED') || !got2.contains('-NAPPED') {
		return ['执行: 追加落盘', '内容 "${got2}"']
	}
	os.rm(path) or { }
	return ['执行: 重定向落盘', '']
}

// `2>&1` 必须在捕获模式下把 stderr 并进 stdout（否则调用方拿不到）
fn t_run_line_stderr_merged() [2]string {
	mut s := rakuish.Session{ vars: {}, passthrough: false }
	out := rakuish.run_line(mut s, 'ls /rakuish-no-such-path 2>&1 | cat')
	if !out.stdout.contains('No such file') {
		return ['执行: 2>&1 合并', 'stdout="${out.stdout.trim_space()}"']
	}
	return ['执行: 2>&1 合并', '']
}

// `2>&1` 必须真把 stderr 并进 stdout。
//
// 本项目最深的坑（实测链条）：
//   ① fork 出的子进程里，dup2 **以 fd 1 为目标会静默失效** ——
//      返回 1（成功），但随后写 fd 1 的内容仍出现在终端；
//      而 dup2 到 fd 2 完全正常（`2> file` 正确落盘）。
//   ② 绕过办法：目标为 fd 1 时先 dup(1) 复制出「fd1 指向的东西」，
//      再 dup2(新fd → 源fd)。
// ③ 另外：`for x in c.redirs` 对跨模块结构体数组**只迭代一次**，
//      必须显式索引循环。
// 本断言锁住 ② 的行为，防止有人"简化"回 dup2(x, 1)。
fn t_run_line_redirect_stderr_into_file() [2]string {
	path := '/tmp/rakuish-selftest-both.txt'
	os.rm(path) or { }
	mut s := rakuish.Session{ vars: {}, passthrough: false }
	rakuish.run_line(mut s, 'ls /rakuish-definitely-missing > ${path} 2>&1')
	got := os.read_file(path) or { return ['执行: > f 2>&1 落盘', '文件没生成'] }
	if !got.contains('No such file') {
		return ['执行: > f 2>&1 落盘', "文件内容 \"${got.trim_space()}\"（stderr 没并进来）"]
	}
	os.rm(path) or { }
	return ['执行: > f 2>&1 落盘', '']
}

// 多条重定向必须**全部**生效（for 循环只跑一次的回归防线）
fn t_run_line_multi_redirects_all_apply() [2]string {
	p1 := '/tmp/rk-multi-1.txt'
	os.rm(p1) or { }
	mut s := rakuish.Session{ vars: {}, passthrough: false }
	rakuish.run_line(mut s, 'ls /rakuish-missing > ${p1} 2>&1')
	got := os.read_file(p1) or { return ['执行: 多条重定向', '文件没生成'] }
	// 第 1 条 out(fd1) 与第 2 条 dup(2->1) 都要生效
	if !got.contains('No such file') {
		os.rm(p1) or { }
		return ['执行: 多条重定向', "只有部分生效：\"${got.trim_space()}\""]
	}
	os.rm(p1) or { }
	return ['执行: 多条重定向', '']
}

pub fn run() int {
	mut cases := [][2]string{}
	cases << t_lex_quotes_kept_in_text()
	cases << t_lex_append_redirect()
	cases << t_lex_pipe_and_semi()
	cases << t_parser_pipeline_structure()
	cases << t_expand_arg_single_quote_literal()
	cases << t_expand_arg_double_quote_expands()
	cases << t_expand_arg_bare_var()
	cases << t_expand_arg_escaped_dollar()
	cases << t_expand_arg_mixed_quotes()
	cases << t_detect_escape_eval()
	cases << t_raku_block()
	cases << t_run_line_shell_routing()
	cases << t_run_line_export_then_expand()
	cases << t_run_line_escape_returns_code()
	cases << t_lex_and_redirect()
	cases << t_parser_stderr_redirect()
	cases << t_parser_in_default_fd()
	cases << t_parser_negate()
	cases << t_run_line_pipe_executes()
	cases << t_parser_fd_dup()
	cases << t_run_line_redirect_writes_file()
	cases << t_run_line_stderr_merged()
	cases << t_run_line_redirect_stderr_into_file()
	cases << t_run_line_multi_redirects_all_apply()
	mut pass := 0
	mut fail := 0
	for c in cases {
		if c[1] == '' {
			pass++
			println('  ok   ${c[0]}')
		} else {
			fail++
			println('  FAIL ${c[0]} —— ${c[1]}')
		}
	}
	println('')
	println('selftest: ${pass} 通过 / ${fail} 失败（共 ${pass + fail} 项）')
	return fail
}
