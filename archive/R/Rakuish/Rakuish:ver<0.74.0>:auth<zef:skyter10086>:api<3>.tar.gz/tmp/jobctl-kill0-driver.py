import os, pty, select, time, re, sys

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
pid, fd = pty.fork()
if pid == 0:
    os.chdir(os.path.expanduser("~/Rakuish"))
    os.execv(RAKU, [RAKU, "-Ilib", "tmp/jobctl-kill0.raku"])

buf = bytearray(); end = time.time() + 15
while time.time() < end:
    r,_,_ = select.select([fd],[],[],0.1)
    if not r: continue
    try: d = os.read(fd, 65536)
    except OSError: break
    if not d: break
    buf.extend(d)
    if b"PROBE done" in buf: break

txt = bytes(buf).decode("utf-8","replace")
for line in txt.splitlines():
    if line.startswith("PROBE") or line.startswith("  "):
        print(line.strip())
print("survived-kill0:", "parent-sigints" in txt and "PROBE done" in txt)
try: os.kill(pid, 9)
except ProcessLookupError: pass
