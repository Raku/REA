use lib 'lib';
use Rakuish::Sys;

my $dir = $*TMPDIR.IO.add("rakuish-pty-probe-{$*PID}");
$dir.mkdir;
LEAVE { try { .unlink for $dir.dir; $dir.rmdir } }
my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
my $exe = $*EXECUTABLE.Str;

say "RAKU=", $*RAKU.compiler.version, " OS=", $*DISTRO.name;

# 1) isatty + stderr 是否合流
my $r1 = $sys.pty-exec($exe, '-e',
    'say "OUT=" ~ $*OUT.t; say "IN=" ~ $*IN.t; say "ERR=" ~ $*ERR.t; note "STDERR-LINE";',
    :timeout-ms(8000));
say "1 isatty/out+err: ok={$r1.ok} code={$r1.code} out={$r1.out.raku} err={$r1.err.raku}";
say "1 value: ", $r1.value.raku;

# 2) strip-ansi 开关
my $r2 = $sys.pty-exec($exe, '-e', 'say "\e[31mRED\e[0m";',
    :timeout-ms(8000), :!strip-ansi);
say "2 strip-ansi=False: out=", $r2.out.raku;
my $r2b = $sys.pty-exec($exe, '-e', 'say "\e[31mRED\e[0m";',
    :timeout-ms(8000));
say "2 strip-ansi=True : out=", $r2b.out.raku;

# 3) 超时后最后一块是否还在
my $r3 = $sys.pty-exec($exe, '-e', 'say "BEFORE"; sleep 3; say "AFTER";',
    :timeout-ms(300));
say "3 timeout: code={$r3.code} out={$r3.out.raku} err={$r3.err.raku}";

# 4) 大输出耗时（tap 内 O(n^2) 拼接）
for 100_000, 400_000 -> $n {
    my $t0 = now;
    my $r = $sys.pty-exec($exe, '-e', "print 'x' x $n;",
        :timeout-ms(20000), :max-bytes(2 * 1024 * 1024));
    say "4 big n=$n elapsed={(now - $t0).round(0.001)}s chars={$r.out.chars} truncated={$r.value<truncated>}";
}

# 5) 非零退出码
my $r5 = $sys.pty-exec($exe, '-e', 'say "X"; exit 7;', :timeout-ms(8000));
say "5 nonzero: ok={$r5.ok} code={$r5.code} out={$r5.out.raku} err={$r5.err.raku}";

# 6) 能力探测前提：Proc::Async.new 是否静默吞掉未知命名参数
my $swallow = try {
    my $p = Proc::Async.new($exe, '-e', 'say "SWALLOW";', :bogus-option(1));
    my $s = $p.start;
    my $proc = await $s;
    "no-error exit={$proc.exitcode}";
} // "threw: {$!.^name}";
say "6 unknown-named-arg: ", $swallow;

# 7) 源码级：pty-exec 是否读取了任何能力探测结果
say "7 source has version probe: ",
    so 'lib/Rakuish/Sys/Proc.rakumod'.IO.slurp.contains('compiler.version');
