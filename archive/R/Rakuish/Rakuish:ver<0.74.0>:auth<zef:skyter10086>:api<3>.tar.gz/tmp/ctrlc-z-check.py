import os, pty, select, time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"

def st(pid):
    try:
        d = open("/proc/%d/stat" % pid).read(); return d.rsplit(") ",1)[1].split()[0]
    except OSError: return "?"

def trial(cmd, ctrl=b"\x03"):
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(os.path.expanduser("~/Rakuish")); os.execvp(cmd[0], cmd)
    time.sleep(2.0); b = st(pid)
    os.write(fd, ctrl); time.sleep(1.0); a = st(pid)
    try:
        os.kill(pid, 18); time.sleep(0.1); os.kill(pid, 9)
    except ProcessLookupError: pass
    return b, a

print("ctrl-c on bare python:", trial(["python3","-c","import time; time.sleep(30)"], b"\x03"))
print("ctrl-z on bare python:", trial(["python3","-c","import time; time.sleep(30)"], b"\x1a"))

# 直接看 slave 的 termios 关键位
prog = ("import termios,sys; a=termios.tcgetattr(0); "
        "print('ISIG=%d VSUSP=%d VINTR=%d ICANON=%d' % (bool(a[3]&termios.ISIG), a[6][termios.VSUSP], a[6][termios.VINTR], bool(a[3]&termios.ICANON)), flush=True); "
        "import time; time.sleep(3)")
pid, fd = pty.fork()
if pid == 0:
    os.chdir(os.path.expanduser("~/Rakuish")); os.execvp("python3", ["python3","-c",prog])
time.sleep(1.5)
try: print("slave termios:", os.read(fd, 200).decode().strip())
except OSError: print("read failed")
try: os.kill(pid,9)
except ProcessLookupError: pass
