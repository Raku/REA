# 实测：Proc::Async 起子进程后，父进程侧再 setpgid(pid,pid) 还来不来得及。
# POSIX 规定父进程只能对「尚未 exec」的子进程 setpgid，否则 EACCES。
use NativeCall;

sub setpgid(int32 $pid, int32 $pgid --> int32) is native { * }
sub getpgid(int32 $pid --> int32) is native { * }
sub getpid(--> int32) is native { * }

my Int $ok = 0;
my Int $fail = 0;
my Int $other = 0;
my @samples;

for ^60 -> $i {
    my $p = Proc::Async.new('/bin/sleep', '0.30');
    my $started = $p.start;
    my $pid = (await $p.pid).Int;
    my $rc = setpgid($pid, $pid);
    my $pg = getpgid($pid);
    if $rc == 0 && $pg == $pid {
        $ok++;
    }
    elsif $rc != 0 {
        $fail++;
        @samples.push("err rc=$rc pg=$pg") if @samples.elems < 5;
    }
    else {
        $other++;
    }
    try { await $started };
}

say "parent-side setpgid: ok=$ok fail=$fail other=$other  (mypid={getpid()} mypgid={getpgid(0)})";
say "samples: ", @samples.join(' | ') if @samples;
