# 确认父进程侧 setpgid 失败的 errno（期望 EACCES=13，POSIX 规定父进程只能
# 对尚未 exec 的子进程 setpgid）。
use NativeCall;

sub setpgid(int32 $pid, int32 $pgid --> int32) is native { * }
sub getpid(--> int32) is native { * }
sub __errno_location(--> Pointer[int32]) is native { * }

my $p = Proc::Async.new('/bin/sleep', '0.5');
my $s = $p.start;
my $pid = (await $p.pid).Int;
my $rc = setpgid($pid, $pid);
my $errno = __errno_location().deref;
say "pid=$pid rc=$rc errno=$errno (13=EACCES, 3=ESRCH, 22=EINVAL) mypid={getpid()}";
await $s;
