use Rakuish::Sys;

my Str $mode = @*ARGS[0] // 'ctrlc';
my $sys = Rakuish::Sys.new(:root($*TMPDIR), :cwd($*CWD));

my $cmd = $mode eq 'kill0'
    ?? 'python3 -c "import os, signal; os.kill(0, signal.SIGTERM)"'
    !! 'sleep 30';

say "READY mode=$mode";
$*OUT.flush;

my $r = $sys.proc.tty-exec('/bin/sh', '-c', $cmd);

say "RESULT code={$r.code} sig={$r.value<signal>} jc={$r.value<job-control>.Int} fg={$r.value<fg-restored>.Int}";
say "ALIVE-AFTER";
say "REASON {$r.value<job-control-reason> // '-'}";
say "DONE";
$*OUT.flush;
