import os
import pty
import re
import select
import sys
import time

CMD = sys.argv[1:]


def main():
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(os.path.expanduser("~/Rakuish"))
        os.execvp(CMD[0], CMD)

    buf = b""

    def pump(seconds):
        nonlocal buf
        end = time.time() + seconds
        while time.time() < end:
            r, _, _ = select.select([fd], [], [], 0.1)
            if not r:
                continue
            try:
                chunk = os.read(fd, 4096)
            except OSError:
                return False
            if not chunk:
                return False
            buf += chunk
        return True

    pump(4.0)
    print("--- before ctrl-c ---")
    print(buf.decode("utf-8", "replace").strip())

    if b"FG-READY" not in buf:
        print("RESULT: 没到 FG-READY")
        os.kill(pid, 9)
        return 1

    os.write(fd, b"\x03")
    pump(4.0)
    print("--- after ctrl-c ---")
    print(buf.decode("utf-8", "replace").strip())

    text = buf.decode("utf-8", "replace")
    checks = {
        "child own group": bool(re.search(r"own-group=1", text)),
        "foreground switched": bool(re.search(r"tcsetpgrp rc=0", text)),
        "child killed by SIGINT": bool(re.search(r"signaled=1", text)),
        "parent got 0 SIGINT": bool(re.search(r"parent-sigints=0", text)),
        "foreground restored": bool(re.search(r"matches-mypg=1", text)),
    }
    for k, v in checks.items():
        print(("PASS  " if v else "FAIL  ") + k)
    try:
        os.kill(pid, 9)
    except ProcessLookupError:
        pass
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
