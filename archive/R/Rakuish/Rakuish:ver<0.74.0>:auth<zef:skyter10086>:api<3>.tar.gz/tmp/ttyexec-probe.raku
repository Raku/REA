use Rakuish::Sys;

# 真 PTY 内调用 tty-exec：让子进程报告自己的 pid/pgid/tpgid。
# tpgid == pgid 说明它确实拿到了终端前台（job control 生效的判据）。
my $sys = Rakuish::Sys.new(:root($*TMPDIR), :cwd($*CWD));

my $r = $sys.proc.tty-exec(
    '/bin/sh', '-c', 'ps -o pid=,pgid=,tpgid= -p $$; exit 3');

say "RESULT code={$r.code} ok={$r.ok.Int} sig={$r.value<signal>}";
say "VALUE jc={$r.value<job-control>.Int} fg={$r.value<fg-restored>.Int} pgid={$r.value<pgid>}";
say "REASON {$r.value<job-control-reason> // '-'}";
say "ERR [{$r.err}]";

# 子进程被信号打死时的映射：128+sig
my $r2 = $sys.proc.tty-exec('/bin/sh', '-c', 'kill -TERM $$');
say "SIGCODE code={$r2.code} sig={$r2.value<signal>}";

# cwd 生效（这里与当前目录不同，会走 addchdir 动作）
my $r3 = $sys.proc.tty-exec('/bin/sh', '-c', 'pwd', :cwd('/tmp'.IO));
say "CWD out-code={$r3.code}";

say "DONE";
