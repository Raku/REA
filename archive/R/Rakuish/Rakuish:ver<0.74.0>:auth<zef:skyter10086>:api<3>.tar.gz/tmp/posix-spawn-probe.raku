# 原型：posix_spawn + POSIX_SPAWN_SETPGROUP，在 spawn 瞬间就把子进程放进
# 自己的进程组（没有 fork/exec 之间的竞态窗口），这是 job control 的前置条件。
#
# 验证点：
#   1. posix_spawn 能起子进程、argv 传参正确；
#   2. 子进程 pgid == 自己的 pid（说明 SETPGROUP 生效）；
#   3. 父进程 waitpid 能拿到退出码（不被 Rakudo 自己的回收机制抢走）。
use NativeCall;

constant POSIX_SPAWN_SETPGROUP = 0x02;

sub posix_spawn(Pointer[uint32] $pid, Str $path, Pointer[void] $file-actions,
                Pointer[void] $attrp, CArray[Str] $argv, CArray[Str] $envp --> int32) is native { * }
sub posix_spawnattr_init(Pointer[void] $attr --> int32) is native { * }
sub posix_spawnattr_destroy(Pointer[void] $attr --> int32) is native { * }
sub posix_spawnattr_setpgroup(Pointer[void] $attr, int32 $pgroup --> int32) is native { * }
sub posix_spawnattr_setflags(Pointer[void] $attr, int16 $flags --> int32) is native { * }
sub waitpid(int32 $pid, Pointer[int32] $status, int32 $options --> int32) is native { * }
sub getpid(--> int32) is native { * }
sub getpgid(int32 $pid --> int32) is native { * }

sub spawn2(@argv, Int $pgroup = 0, :%env) {
    my $argv = CArray[Str].new;
    for @argv.kv -> $i, $v { $argv[$i] = $v }
    $argv[@argv.elems] = Str;

    my @env = (%env // %*ENV).pairs.map({ "{.key}={.value}" });
    my $envp = CArray[Str].new;
    for @env.kv -> $i, $v { $envp[$i] = $v }
    $envp[@env.elems] = Str;

    my $attr-buf = buf8.allocate(512);     # glibc 的 posix_spawnattr_t 是 336 字节
    my $attr = nativecast(Pointer[void], $attr-buf);
    posix_spawnattr_init($attr);
    posix_spawnattr_setpgroup($attr, $pgroup);
    posix_spawnattr_setflags($attr, POSIX_SPAWN_SETPGROUP);

    my $pid-buf = buf8.allocate(4);
    my $pidp = nativecast(Pointer[uint32], $pid-buf);
    my $rc = posix_spawn($pidp, @argv[0], Pointer[void], $attr, $argv, $envp);
    posix_spawnattr_destroy($attr);
    ($rc, $pidp.deref);
}

sub run-child(@argv, Int $pgroup --> Hash) {
    my ($rc, $pid) = spawn2(@argv, $pgroup);
    return %( rc => $rc, ok => False ) if $rc != 0;
    my $child-pg = getpgid($pid);
    my $st = CArray[int32].new;
    $st[0] = 0;
    my $w = waitpid($pid, nativecast(Pointer[int32], $st), 0);
    %(
        rc => $rc, ok => True, pid => $pid, child-pg => $child-pg,
        waitpid => $w, exit => ($st[0] +> 8), raw => $st[0],
    );
}

say "parent pid=", getpid(), " pgid=", getpgid(0);

my @child-argv = '/usr/bin/python3', '-c', 'import os,sys; print("child", os.getpid(), os.getpgrp()); sys.exit(7)';
my %pg = run-child(@child-argv, 0);
say "SETPGROUP pgroup=0  -> ", %pg.gist;
say "   pgid==pid? ", (%pg<child-pg> == %pg<pid>);

my %same = run-child(['/usr/bin/true'], getpgid(0));
say "SETPGROUP pgroup=parent -> ", %same.gist;
