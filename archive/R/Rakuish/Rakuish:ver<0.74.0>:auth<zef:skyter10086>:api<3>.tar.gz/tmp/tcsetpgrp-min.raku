use NativeCall;

sub tcsetpgrp(int32 $fd, int32 $pgrp --> int32) is native { * }
sub tcgetpgrp(int32 $fd --> int32) is native { * }
sub getpgid(int32 $pid --> int32) is native { * }
sub __errno_location(--> Pointer[int32]) is native { * }

my $tg = getpgid(0);
say "fg=", tcgetpgrp(0), " mypg=$tg";

for 1..3 -> $i {
    my $rc = tcsetpgrp(0, $tg);
    my $e = __errno_location().deref;
    say "call$i rc=$rc errno=$e fg=", tcgetpgrp(0);
}
say "DONE";
