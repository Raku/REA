use lib 'lib';
use Rakuish::Sys;

my $dir = $*TMPDIR.IO.add("rakuish-pty-probe2-{$*PID}");
$dir.mkdir;
LEAVE { try { .unlink for $dir.dir; $dir.rmdir } }
my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
my $exe = $*EXECUTABLE.Str;

# 基线：子进程启动 + PTY 建立
my @base;
for ^3 {
    my $t = now;
    $sys.pty-exec($exe, '-e', 'say 1', :timeout-ms(8000));
    @base.push(now - $t);
}
my $baseline = @base.min;
say "baseline={$baseline.round(0.001)}s";

# 超线性验证（tap 内 O(n^2) 拼接）
for 50_000, 100_000, 200_000, 400_000, 800_000 -> $n {
    my $t = now;
    my $r = $sys.pty-exec($exe, '-e', "print 'x' x $n;",
        :timeout-ms(30000), :max-bytes(4 * 1024 * 1024));
    my $d = (now - $t) - $baseline;
    say "n=$n net={$d.round(0.001)}s chars={$r.out.chars}";
}

# ANSI 序列被 max-bytes 从中间截断时，strip 后残留什么
my $cut = $sys.pty-exec($exe, '-e',
    q{print 'A' x 60; print "\e[31mRED\e[0m"; print 'B' x 60;},
    :timeout-ms(8000), :max-bytes(75));
say "cut-stripped=", $cut.out.raku, " truncated=", $cut.value<truncated>;
my $cut2 = $sys.pty-exec($exe, '-e',
    q{print 'A' x 60; print "\e[31mRED\e[0m"; print 'B' x 60;},
    :timeout-ms(8000), :max-bytes(75), :!strip-ansi);
say "cut-raw=", $cut2.out.raku;

# 对照组：普通 exec 的 isatty 必须是 False
my $plain = $sys.exec($exe, '-e', 'say "TTY=" ~ $*OUT.t;', :timeout-ms(8000));
say "plain-exec out=", $plain.out.raku;

# 超时瞬间输出（固定 sleep 0.02 drain 是否够）
for ^3 {
    my $r = $sys.pty-exec($exe, '-e',
        q{say "EARLY"; sleep 2; say "LATE";}, :timeout-ms(120));
    say "timeout-drain code={$r.code} out={$r.out.raku}";
}
