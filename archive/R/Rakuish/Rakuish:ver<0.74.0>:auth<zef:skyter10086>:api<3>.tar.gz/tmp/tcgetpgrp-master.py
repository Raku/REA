import os
import pty
import subprocess
import sys
import termios
import time

master, slave = pty.openpty()
proc = subprocess.Popen(["/bin/sleep", "5"], stdin=slave, stdout=slave,
                        stderr=slave, close_fds=True, start_new_session=True)

# 子进程自成会话；让它把自己的组设为前台，模拟 shell 的 tcsetpgrp
def child_fg():
    try:
        return os.tcgetpgrp(slave)
    except OSError as e:
        return "ERR:%s" % e

print("child pgid:", os.getpgid(proc.pid))
print("tcgetpgrp(slave) before:", child_fg())
os.tcsetpgrp(slave, os.getpgid(proc.pid))
print("tcgetpgrp(slave) after :", child_fg())
print("tcgetpgrp(master)      :", os.tcgetpgrp(master))
print("match:", os.tcgetpgrp(master) == os.getpgid(proc.pid))

os.close(slave)
try:
    proc.kill()
    proc.wait(timeout=2)
except Exception:
    pass
os.close(master)
