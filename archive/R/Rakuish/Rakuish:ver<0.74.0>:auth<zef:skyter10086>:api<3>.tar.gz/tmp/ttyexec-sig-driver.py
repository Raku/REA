import os
import pty
import re
import select
import sys
import time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")
MODE = sys.argv[1] if len(sys.argv) > 1 else "ctrlc"

pid, fd = pty.fork()
if pid == 0:
    os.chdir(ROOT)
    os.execv(RAKU, [RAKU, "-Ilib", "tmp/ttyexec-sig.raku", MODE])


def state(p):
    try:
        d = open("/proc/%d/stat" % p).read()
        return d.rsplit(") ", 1)[1].split()[0]
    except OSError:
        return "?"


def pump(seconds, collect):
    end = time.time() + seconds
    while time.time() < end:
        r, _, _ = select.select([fd], [], [], 0.08)
        if not r:
            continue
        try:
            data = os.read(fd, 65536)
        except OSError:
            return
        if not data:
            return
        collect.extend(data)
        end = max(end, time.time() + 0.15)


buf = bytearray()
pump(6.0, buf)
print("ready:", b"READY" in buf)

if MODE == "ctrlc":
    os.write(fd, b"\x03")          # 真终端：ISIG -> SIGINT 给前台进程组
    pump(3.0, buf)
else:
    pump(3.0, buf)                 # kill0 自己触发

print("rakuish state:", state(pid), "(S=运行中 T=已停止)")
print("result:", [re.sub(r"[\x00-\x1f]", " ", l).strip() for l in buf.decode("utf-8", "replace").splitlines()
                  if "RESULT" in l])
print("alive-after:", b"ALIVE-AFTER" in buf)
print("done:", b"DONE" in buf)

try:
    os.kill(pid, 9)
except ProcessLookupError:
    pass
