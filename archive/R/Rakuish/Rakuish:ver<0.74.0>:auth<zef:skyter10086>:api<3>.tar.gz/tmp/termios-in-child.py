import os, pty, select, time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")

pid, fd = pty.fork()
if pid == 0:
    os.chdir(ROOT); os.execv(RAKU, [RAKU, "-Ilib", "bin/rakuish"])

buf = bytearray(); esc = bytearray(); sp=[False]
def feed(d):
    for b in d:
        esc.append(b)
        if len(esc) > 24: del esc[:-24]
        if esc.endswith(b"\x1b[9999;9999H"): sp[0]=True
        elif esc.endswith(b"\x1b[6n"):
            os.write(fd, b"\x1b[24;110R" if sp[0] else b"\x1b[1;1R"); sp[0]=False; del esc[:]
def pump(sec):
    end=time.time()+sec
    while time.time()<end:
        r,_,_=select.select([fd],[],[],0.08)
        if not r: continue
        try: d=os.read(fd,65536)
        except OSError: return
        if not d: return
        buf.extend(d); feed(d); end=max(end,time.time()+0.2)
def send(t,w=0.8):
    os.write(fd, t.encode() if isinstance(t,str) else t); pump(w)

pump(4.0)
# 子进程读自己的 termios（就是同一个 tty）
code = ("import termios,sys; a=termios.tcgetattr(0); "
        "print('TERMIOS ISIG=%d ICANON=%d ECHO=%d' % (bool(a[3]&termios.ISIG), bool(a[3]&termios.ICANON), bool(a[3]&termios.ECHO)), flush=True)")
send('! --tty /usr/bin/python3 -c "%s"\r' % code, 2.5)
txt = bytes(buf).decode("utf-8","replace")
import re
m = re.search(r"TERMIOS[^\r\n]*", txt)
print("child sees:", m.group(0) if m else "<none>")
print("fg pgrp:", "n/a")
try:
    os.kill(pid,9)
except ProcessLookupError: pass
