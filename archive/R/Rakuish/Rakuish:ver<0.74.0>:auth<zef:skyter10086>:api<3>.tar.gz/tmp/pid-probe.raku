my $p = Proc::Async.new('/bin/sleep', '1');
my $s = $p.start;
say "pid.WHAT=", $p.pid.WHAT;
say "pid.perl=", $p.pid.perl;
my $r = try { $p.pid.result };
say "pid.result=", ($r // '<none>');
await $s;
