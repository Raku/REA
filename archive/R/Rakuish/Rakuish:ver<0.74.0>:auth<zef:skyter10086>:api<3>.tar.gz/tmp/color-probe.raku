use Rakuish::REPL::Session;

my $s = Rakuish::REPL::Session.new(:color(True));
$s.set-color(True);

my $r = $s.eval-line('ls');
say 'LS-RAW>>' ~ $s.render($r).raku;

my $r2 = $s.eval-line('ls -l');
say 'LSL>>' ~ $s.render($r2).substr(0, 120).raku;

my $r3 = $s.eval-line('help()');
say 'HELP>>' ~ $s.render($r3).substr(0, 90).raku;

my $r4 = $s.eval-line('stat("META6.json")');
say 'STAT>>' ~ $s.render($r4).substr(0, 80).raku;

my $r5 = $s.eval-line('env()');
say 'ENV>>' ~ $s.render($r5).substr(0, 60).raku;

my $r6 = $s.eval-line('1 + 1');
say 'OUT>>' ~ $s.render($r6).raku;

my $r7 = $s.eval-line('nonexistent_function_xyz()');
say 'ERR>>' ~ $s.render($r7).substr(0, 60).raku;

# 无色时应当逐字节无 ANSI
my $t = Rakuish::REPL::Session.new;
my $tr = $t.eval-line('ls');
my Str $plain = $t.render($tr);
say 'PLAIN-HAS-ESC>>' ~ ($plain.contains("\e[")).Int;
$*OUT.flush;
