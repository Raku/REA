import os
import pty
import select
import sys
import time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")

pid, fd = pty.fork()
if pid == 0:
    os.chdir(ROOT)
    os.execv(RAKU, [RAKU, "-Ilib", "tmp/ttyexec-probe.raku"])

buf = bytearray()
deadline = time.time() + 60
while time.time() < deadline:
    r, _, _ = select.select([fd], [], [], 0.1)
    if not r:
        continue
    try:
        data = os.read(fd, 65536)
    except OSError:
        break
    if not data:
        break
    buf.extend(data)
    if b"DONE" in buf:
        break

text = buf.decode("utf-8", "replace")
for line in text.splitlines():
    line = line.strip()
    if line.startswith(("RESULT", "VALUE", "REASON", "ERR", "SIGCODE", "CWD", "DONE")):
        print(line)

try:
    os.kill(pid, 9)
except ProcessLookupError:
    pass
