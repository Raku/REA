"""在真 PTY（带 controlling terminal）里驱动 job control 原型。

用 pty.fork()：子进程会 setsid + TIOCSCTTY，拿到控制终端 —— 这是
tcsetpgrp 能工作的前提（普通 openpty + Popen 没有 controlling terminal，
tcsetpgrp 会返回 ENOTTY，t/30 的 harness 就属于那种）。

流程：等到 FG-READY（原型已把前台交给子进程组）→ 发 Ctrl-C → 观察
子进程是否被 SIGINT 打死、父进程收到几次 SIGINT、前台是否收回。
"""

import os
import pty
import re
import select
import sys
import time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")


def main():
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(ROOT)
        os.execv(RAKU, [RAKU, "-Ilib", "tmp/jobctl-probe.raku"])

    buf = b""

    def pump(seconds):
        nonlocal buf
        end = time.time() + seconds
        while time.time() < end:
            r, _, _ = select.select([fd], [], [], 0.1)
            if not r:
                continue
            try:
                chunk = os.read(fd, 4096)
            except OSError:
                return False
            if not chunk:
                return False
            buf += chunk
        return True

    pump(4.0)
    print("--- before ctrl-c ---")
    print(buf.decode("utf-8", "replace").strip())

    if b"FG-READY" not in buf:
        print("RESULT: 原型没到 FG-READY")
        os.kill(pid, 9)
        return 1

    os.write(fd, b"\x03")          # 终端驱动的 SIGINT → 前台进程组
    pump(4.0)
    print("--- after ctrl-c ---")
    print(buf.decode("utf-8", "replace").strip())

    text = buf.decode("utf-8", "replace")
    checks = {
        "child own group": bool(re.search(r"own-group=1", text)),
        "foreground switched": bool(re.search(r"matches-child=1", text)),
        "child killed by SIGINT": bool(re.search(r"signaled=1 sig=2\b", text)),
        "parent got 0 SIGINT": bool(re.search(r"parent-sigints=0", text)),
        "foreground restored": bool(re.search(r"matches-mypg=1", text)),
    }
    for k, v in checks.items():
        print(("PASS  " if v else "FAIL  ") + k)
    try:
        os.kill(pid, 9)
    except ProcessLookupError:
        pass
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
