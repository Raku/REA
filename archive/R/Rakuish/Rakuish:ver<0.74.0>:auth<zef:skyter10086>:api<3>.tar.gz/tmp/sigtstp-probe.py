import os, pty, select, time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"

def st(pid):
    try:
        d = open("/proc/%d/stat" % pid).read()
        return d.rsplit(") ", 1)[1].split()[0]
    except OSError:
        return "?"

def trial(cmd, ctrl=b"\x1a"):
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(os.path.expanduser("~/Rakuish"))
        os.execvp(cmd[0], cmd)
    time.sleep(2.5)
    before = st(pid)
    os.write(fd, ctrl)
    time.sleep(1.2)
    after = st(pid)
    try:
        os.kill(pid, 18); time.sleep(0.2); os.kill(pid, 9)
    except ProcessLookupError:
        pass
    return before, after

print("raku  -e sleep :", trial([RAKU, "-e", "sleep 30"]))
print("python sleep   :", trial(["python3", "-c", "import time; time.sleep(30)"]))
