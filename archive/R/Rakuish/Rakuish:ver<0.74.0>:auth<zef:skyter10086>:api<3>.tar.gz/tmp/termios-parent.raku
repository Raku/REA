
use lib 'lib';
use Terminal::API;
use Rakuish::Sys;
my $fd = $*IN.native-descriptor;
sub snap(Str $tag) {
    my $c = Terminal::API::get-config($fd);
    say "$tag lflag={$c.lflag} iflag={$c.iflag} oflag={$c.oflag} vintr={$c.cc_VINTR}";
}
snap('BEFORE');
my $saved = Terminal::API::get-config($fd);
my $r = Rakuish::Sys.new(:root($*CWD), :cwd($*CWD))
    .tty-exec('/bin/sh', '-c', 'stty raw -echo; sleep 0.3');
snap('AFTER-TTY');
say "TTY-EXEC ok={$r.ok} code={$r.code}";
# Simulate the NEXT prompt: LineEditor snapshots whatever state it finds now.
my $prompt-saved = Terminal::API::get-config($fd);
Terminal::API::make-raw($fd, :when(Terminal::API::FLUSH));
Terminal::API::restore-config($prompt-saved, $fd, :when(Terminal::API::DRAIN));
snap('AFTER-NEXT-PROMPT');
# Counterfactual: a backend-level snapshot taken before the handoff.
Terminal::API::restore-config($saved, $fd, :when(Terminal::API::DRAIN));
snap('WITH-BACKEND-SNAPSHOT');
