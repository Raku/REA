import os, pty, select, sys, time, glob

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")

def pcl(pid):
    try:
        d = open("/proc/%d/stat" % pid).read()
        rest = d.rsplit(") ", 1)
        return rest[0].split("(")[-1], rest[1].split()[0], rest[1].split()[2]
    except OSError:
        return ("?", "?", "?")

pid, fd = pty.fork()
if pid == 0:
    os.chdir(ROOT); os.execv(RAKU, [RAKU, "-Ilib", "bin/rakuish"])

buf = bytearray(); esc = bytearray(); sp = [False]
def feed(data):
    for b in data:
        esc.append(b)
        if len(esc) > 24: del esc[:-24]
        if esc.endswith(b"\x1b[9999;9999H"): sp[0] = True
        elif esc.endswith(b"\x1b[6n"):
            os.write(fd, b"\x1b[24;110R" if sp[0] else b"\x1b[1;1R"); sp[0]=False; del esc[:]
def pump(sec):
    end = time.time()+sec
    while time.time() < end:
        r,_,_ = select.select([fd],[],[],0.08)
        if not r: continue
        try: d = os.read(fd, 65536)
        except OSError: return
        if not d: return
        buf.extend(d); feed(d); end = max(end, time.time()+0.2)
def send(t, w=0.8):
    os.write(fd, t.encode() if isinstance(t,str) else t); pump(w)

pump(4.0)
send("! --tty /bin/sleep 30\r", 2.5)
print("rakuish:", pcl(pid))
kids = [p for p in glob.glob("/proc/[0-9]*") if pcl(int(p.split("/")[2]))[0] == "sleep"]
print("sleep procs:", [(k.split("/")[2], pcl(int(k.split("/")[2]))[1], "pgrp="+pcl(int(k.split("/")[2]))[2]) for k in kids])
print("fg pgrp of tty:", os.tcgetpgrp(fd) if False else "<skip>")
send("\x1a", 2.0)
print("after ctrl-z rakuish:", pcl(pid))
kids = [p for p in glob.glob("/proc/[0-9]*") if pcl(int(p.split("/")[2]))[0] == "sleep"]
print("after ctrl-z sleep:", [(k.split("/")[2], pcl(int(k.split("/")[2]))[1]) for k in kids])
try:
    os.kill(pid, 18); time.sleep(0.2); os.kill(pid, 9)
except ProcessLookupError: pass
