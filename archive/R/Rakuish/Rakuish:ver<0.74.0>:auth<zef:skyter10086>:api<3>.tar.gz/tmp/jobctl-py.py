"""Python 版 job control 原型：与 jobctl-probe.raku 做同样的动作，
用来判断「子进程死后 tcsetpgrp 失败」是内核语义还是 Raku 侧的问题。"""

import os
import signal
import subprocess
import sys
import termios

tty = 0
my_pg = os.getpgrp()
print("PROBE mypid=%d mypg=%d tty-fg=%d" % (os.getpid(), my_pg, os.tcgetpgrp(tty)), flush=True)

signal.signal(signal.SIGTTOU, signal.SIG_IGN)
got_int = []
signal.signal(signal.SIGINT, lambda *a: got_int.append(1))

child = subprocess.Popen(
    [sys.executable, "-c", "import time; print('CHILD alive', flush=True); time.sleep(30)"],
    preexec_fn=os.setpgrp,      # 子进程自成一个进程组（等价 POSIX_SPAWN_SETPGROUP）
)
print("PROBE child pid=%d pg=%d own-group=%d"
      % (child.pid, os.getpgid(child.pid), int(os.getpgid(child.pid) == child.pid)), flush=True)

try:
    os.tcsetpgrp(tty, child.pid)
    print("PROBE tcsetpgrp rc=0 fg=%d" % os.tcgetpgrp(tty), flush=True)
except OSError as e:
    print("PROBE tcsetpgrp FAILED", e, flush=True)

print("FG-READY", flush=True)
child.wait()
print("PROBE reaped signaled=%d" % int(child.returncode < 0), flush=True)

try:
    os.tcsetpgrp(tty, my_pg)
    print("PROBE restore rc=0 fg=%d matches-mypg=%d"
          % (os.tcgetpgrp(tty), int(os.tcgetpgrp(tty) == my_pg)), flush=True)
except OSError as e:
    print("PROBE restore FAILED errno=%d (%s) fg=%d"
          % (e.errno, e.strerror, os.tcgetpgrp(tty)), flush=True)

print("PROBE parent-sigints=%d" % len(got_int), flush=True)
print("PROBE done", flush=True)
