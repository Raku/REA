"""在真 PTY 里跑一条命令并把输出打出来（不要求 FG-READY 标记）。"""

import os
import pty
import select
import sys
import time

CMD = sys.argv[1:]


def main():
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(os.path.expanduser("~/Rakuish"))
        os.execvp(CMD[0], CMD)

    buf = b""
    end = time.time() + float(os.environ.get("PTY_SECONDS", "4"))
    while time.time() < end:
        r, _, _ = select.select([fd], [], [], 0.1)
        if not r:
            continue
        try:
            chunk = os.read(fd, 4096)
        except OSError:
            break
        if not chunk:
            break
        buf += chunk
    print(buf.decode("utf-8", "replace").strip())
    try:
        os.kill(pid, 9)
    except ProcessLookupError:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
