use lib 'lib';
use Rakuish::Sys;

my $dir = $*TMPDIR.IO.add("rakuish-pty-probe3-{$*PID}");
$dir.mkdir;
LEAVE { try { .unlink for $dir.dir; $dir.rmdir } }
my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
my $exe = $*EXECUTABLE.Str;

# A) max-bytes 恰好切在 ESC 序列中间时，strip 后是否残留碎片
for 61, 62, 63, 64, 65, 67, 70 -> $cap {
    my $r = $sys.pty-exec($exe, '-e',
        q{print 'A' x 60; print "\e[31mRED\e[0m";},
        :timeout-ms(8000), :max-bytes($cap));
    say "A cap=$cap out=", $r.out.raku;
}

# B) 超时给足启动时间，验证固定 sleep 0.02 drain 是否稳定
for ^3 {
    my $r = $sys.pty-exec($exe, '-e',
        q{say "EARLY"; sleep 2; say "LATE";}, :timeout-ms(400));
    say "B code={$r.code} out={$r.out.raku}";
}

# C) PTY 下子进程等待 stdin（SPEC V-170 明确不提供 stdin 写入）
my $t = now;
my $r = $sys.pty-exec($exe, '-e',
    q{say "WAITING"; my $l = $*IN.get; say "GOT=" ~ ($l // 'EOF');},
    :timeout-ms(700));
say "C code={$r.code} elapsed={(now - $t).round(0.01)}s out={$r.out.raku}";
