"""测当前实现（Proc::Async + SIGINT tap，不切进程组）按 Ctrl-Z 的后果。

行编辑器会发 DSR（ESC[6n）问光标位置，必须应答，否则按键被吞。
预期缺陷：Ctrl-Z 发给「整个前台进程组」，父 REPL 与子进程同组，
所以 REPL 自己也被 SIGTSTP 挂起 —— 用户看到整个 shell 冻结。
"""

import os
import pty
import select
import sys
import time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")


def state_of(pid):
    try:
        with open("/proc/%d/stat" % pid) as f:
            data = f.read()
        return data.rsplit(") ", 1)[1].split()[0]
    except OSError:
        return "?"


def main():
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(ROOT)
        os.execv(RAKU, [RAKU, "-Ilib", "bin/rakuish"])

    buf = bytearray()
    esc = bytearray()
    size_pending = [False]

    def feed(data):
        for byte in data:
            esc.append(byte)
            if len(esc) > 24:
                del esc[:-24]
            if esc.endswith(b"\x1b[9999;9999H"):
                size_pending[0] = True
            elif esc.endswith(b"\x1b[6n"):
                os.write(fd, b"\x1b[24;110R" if size_pending[0] else b"\x1b[1;1R")
                size_pending[0] = False
                del esc[:]

    def pump(seconds):
        end = time.time() + seconds
        while time.time() < end:
            r, _, _ = select.select([fd], [], [], 0.08)
            if not r:
                continue
            try:
                data = os.read(fd, 65536)
            except OSError:
                return
            if not data:
                return
            buf.extend(data)
            feed(data)
            end = max(end, time.time() + 0.2)

    def send(text, wait=0.8):
        os.write(fd, text.encode() if isinstance(text, str) else text)
        pump(wait)

    pump(4.0)
    send("! --tty /bin/sleep 30\r", 2.5)
    print("state before ctrl-z:", state_of(pid))
    print("cmd accepted:", b"sleep" in bytes(buf) or b"tty-exec" in bytes(buf))

    send("\x1a", 2.0)                       # Ctrl-Z
    st = state_of(pid)
    print("state after ctrl-z :", st, "(T=已停止 S=运行中)")

    try:
        os.kill(pid, 18)                    # SIGCONT
        time.sleep(0.3)
        os.kill(pid, 9)
    except ProcessLookupError:
        pass
    print("REPL stopped by Ctrl-Z:", st == "T")
    return 0


if __name__ == "__main__":
    sys.exit(main())
