# job control 可行性原型（不是产品代码）：posix_spawn(SETPGROUP) + tcsetpgrp。
#
# 结论要点（详见 docs/ADR-0010）：
#   · Proc::Async 起完子进程后父进程再也 setpgid 不了（POSIX 只允许在 exec 前），
#     所以必须换 spawn 路径；posix_spawn + POSIX_SPAWN_SETPGROUP 是唯一无竞态的
#     做法，且它直接继承 fd 0/1/2，比 bind-stdin/out/err 更简单。
#   · 交接前必须用 NativeCall 把 SIGTTOU **真正 SIG_IGN**；用 Raku 的
#     signal(SIGTTOU).tap 会让后续 tcsetpgrp 恢复返回 ENOTTY（实测）。
#   · 交接后 Ctrl-C 只到前台进程组，父进程收到 0 次 —— 不再需要 SIGINT tap。
use NativeCall;

constant POSIX_SPAWN_SETPGROUP = 0x02;

sub posix_spawn(Pointer[uint32] $pid, Str $path, Pointer[void] $file-actions,
                Pointer[void] $attrp, CArray[Str] $argv, CArray[Str] $envp --> int32) is native { * }
sub posix_spawnattr_init(Pointer[void] $attr --> int32) is native { * }
sub posix_spawnattr_destroy(Pointer[void] $attr --> int32) is native { * }
sub posix_spawnattr_setpgroup(Pointer[void] $attr, int32 $pgroup --> int32) is native { * }
sub posix_spawnattr_setflags(Pointer[void] $attr, int16 $flags --> int32) is native { * }
sub waitpid(int32 $pid, Pointer[int32] $status, int32 $options --> int32) is native { * }
sub tcsetpgrp(int32 $fd, int32 $pgrp --> int32) is native { * }
sub tcgetpgrp(int32 $fd --> int32) is native { * }
sub getpgid(int32 $pid --> int32) is native { * }
sub getpid(--> int32) is native { * }
sub c-signal(int32 $sig, Pointer[void] $handler --> Pointer[void])
    is native('libc.so.6') is symbol('signal') { * }

constant SIGTTOU = 22;

sub spawn-pgroup(@argv, Int $pgroup = 0) {
    my $argv = CArray[Str].new;
    for @argv.kv -> $i, $v { $argv[$i] = $v }
    $argv[@argv.elems] = Str;
    my @env = %*ENV.pairs.map({ "{.key}={.value}" });
    my $envp = CArray[Str].new;
    for @env.kv -> $i, $v { $envp[$i] = $v }
    $envp[@env.elems] = Str;

    my $attr-buf = buf8.allocate(512);          # glibc 的 posix_spawnattr_t 是 336 字节
    my $attr = nativecast(Pointer[void], $attr-buf);
    posix_spawnattr_init($attr);
    posix_spawnattr_setpgroup($attr, $pgroup);
    posix_spawnattr_setflags($attr, POSIX_SPAWN_SETPGROUP);

    my $pid-buf = buf8.allocate(4);
    my $pidp = nativecast(Pointer[uint32], $pid-buf);
    my $rc = posix_spawn($pidp, @argv[0], Pointer[void], $attr, $argv, $envp);
    posix_spawnattr_destroy($attr);
    ($rc, $pidp.deref);
}

my $tty = 0;
my Int $my-pg = getpgid(0);
say "PROBE mypid=", getpid(), " mypg=$my-pg tty-fg=", tcgetpgrp($tty);

# 交接后父进程就是后台进程；必须「真正忽略」SIGTTOU，否则 tcsetpgrp 解挂失败。
c-signal(SIGTTOU, Pointer[void].new(1));

my Int $sigints = 0;
signal(SIGINT).tap(-> $ { $sigints++ });

my @child = '/usr/bin/python3', '-c', 'import time; print("CHILD alive", flush=True); time.sleep(30)';
my ($rc, $pid) = spawn-pgroup(@child, 0);
if $rc != 0 {
    say "PROBE spawn-failed rc=$rc";
    exit 1;
}
my Int $child-pg = getpgid($pid);
say "PROBE child pid=$pid pg=$child-pg own-group=", ($child-pg == $pid).Int;

tcsetpgrp($tty, $child-pg);
say "PROBE fg=", tcgetpgrp($tty), " matches-child=", (tcgetpgrp($tty) == $child-pg).Int;
say "FG-READY";

my $st = CArray[int32].new;
$st[0] = 0;
waitpid($pid, nativecast(Pointer[int32], $st), 0);
my Int $raw = $st[0];
my Int $sig = $raw +& 0x7F;
say "PROBE signaled=", ($sig > 0).Int, " sig=$sig";

my $back = tcsetpgrp($tty, $my-pg);
say "PROBE restore rc=$back matches-mypg=", (tcgetpgrp($tty) == $my-pg).Int;
say "PROBE parent-sigints=$sigints";
say "PROBE done";
