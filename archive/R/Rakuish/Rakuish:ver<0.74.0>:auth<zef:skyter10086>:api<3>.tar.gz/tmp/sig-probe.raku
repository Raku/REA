say "signals: ", try { Signal.enums.keys.sort.join(',') } // 'n/a';
my $ok = try { signal(SIGTTOU).tap(-> $ { }); True };
say "signal(SIGTTOU) works=", $ok.Int;
