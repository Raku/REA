import os, pty, select, time, re

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")

pid, fd = pty.fork()
if pid == 0:
    os.chdir(ROOT); os.execv(RAKU, [RAKU, "-Ilib", "bin/rakuish"])

buf = bytearray(); esc = bytearray(); sp=[False]
def feed(d):
    for b in d:
        esc.append(b)
        if len(esc) > 24: del esc[:-24]
        if esc.endswith(b"\x1b[9999;9999H"): sp[0]=True
        elif esc.endswith(b"\x1b[6n"):
            os.write(fd, b"\x1b[24;110R" if sp[0] else b"\x1b[1;1R"); sp[0]=False; del esc[:]
def pump(sec):
    end=time.time()+sec
    while time.time()<end:
        r,_,_=select.select([fd],[],[],0.08)
        if not r: continue
        try: d=os.read(fd,65536)
        except OSError: return
        if not d: return
        buf.extend(d); feed(d); end=max(end,time.time()+0.2)
def send(t,w=0.8):
    os.write(fd, t.encode() if isinstance(t,str) else t); pump(w)

pump(4.0)
# 子进程对自己所在进程组发 SIGTERM：POSIX 语义下 kill(0,...) 只应影响它自己那组
send('! --tty /usr/bin/python3 -c "import os,signal; os.kill(0, signal.SIGTERM)"\r', 3.0)
try:
    wpid, status = os.waitpid(pid, os.WNOHANG)
except ChildProcessError:
    wpid, status = -1, 0
alive = (wpid == 0)
print("REPL alive after child kill(0,SIGTERM):", alive)
if alive:
    send("1 + 1\r", 2.0)
    txt = bytes(buf).decode("utf-8","replace")
    print("still evaluates:", bool(re.search(r"Out\[\d+\] = 2", txt)))
try: os.kill(pid,9)
except ProcessLookupError: pass
