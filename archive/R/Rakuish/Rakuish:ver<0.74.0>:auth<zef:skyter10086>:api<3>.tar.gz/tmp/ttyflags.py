import termios
a = termios.tcgetattr(0)
print("FLAGS ISIG=%d ICANON=%d ECHO=%d" % (bool(a[3] & termios.ISIG),
                                           bool(a[3] & termios.ICANON),
                                           bool(a[3] & termios.ECHO)), flush=True)
