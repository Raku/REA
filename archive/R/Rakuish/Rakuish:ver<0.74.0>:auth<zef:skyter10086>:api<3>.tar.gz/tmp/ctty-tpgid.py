import fcntl
import os
import pty
import signal
import subprocess
import termios
import time

master, slave = pty.openpty()
fcntl.ioctl(slave, termios.TIOCSWINSZ, b'\x00' * 8)


def preexec():
    os.setsid()
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)


proc = subprocess.Popen(["/bin/sleep", "30"], stdin=slave, stdout=slave,
                        stderr=slave, close_fds=True, preexec_fn=preexec)
os.close(slave)


def fg(pid):
    try:
        data = open("/proc/%d/stat" % pid).read()
        return int(data.rsplit(") ", 1)[1].split()[5])
    except (OSError, IndexError, ValueError) as e:
        return "ERR:%s" % e


time.sleep(0.5)
print("child pgrp:", os.getpgid(proc.pid))
print("child tpgid:", fg(proc.pid))
print("match (no job control yet):", fg(proc.pid) == os.getpgid(proc.pid))

# 模拟 shell 做法：把前台交给子进程组
try:
    os.tcsetpgrp(master, os.getpgid(proc.pid))
    print("tcsetpgrp ok, tpgid now:", fg(proc.pid))
except OSError as e:
    print("tcsetpgrp ERR:", e)

try:
    os.killpg(fg(proc.pid), signal.SIGINT)
    time.sleep(0.3)
    print("after killpg: poll=", proc.poll(), "(negative = killed by signal)")
except Exception as e:
    print("killpg ERR:", e)

try:
    proc.kill()
    proc.wait(timeout=2)
except Exception:
    pass
os.close(master)
