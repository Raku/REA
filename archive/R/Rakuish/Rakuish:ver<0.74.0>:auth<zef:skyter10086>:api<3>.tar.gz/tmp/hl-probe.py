import os
import pty
import re
import select
import sys
import time

RAKU = "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
ROOT = os.path.expanduser("~/Rakuish")

pid, fd = pty.fork()
if pid == 0:
    os.chdir(ROOT)
    os.execv(RAKU, [RAKU, "-Ilib", "bin/rakuish"])

buf = bytearray()
esc = b""
size_pending = False


def feed(data):
    global esc, size_pending
    for byte in data:
        esc += bytes((byte,))
        if len(esc) > 24:
            esc = esc[-24:]
        if esc.endswith(b"\x1b[9999;9999H"):
            size_pending = True
        elif esc.endswith(b"\x1b[6n"):
            os.write(fd, b"\x1b[24;110R" if size_pending else b"\x1b[1;1R")
            size_pending = False
            esc = b""


def pump(seconds):
    end = time.time() + seconds
    while time.time() < end:
        r, _, _ = select.select([fd], [], [], 0.08)
        if not r:
            continue
        try:
            data = os.read(fd, 65536)
        except OSError:
            return
        if not data:
            return
        buf.extend(data)
        feed(data)
        end = max(end, time.time() + 0.2)


pump(4.0)
mark = len(buf)
# 逐字符输入，模拟真人敲键（也让 refresh-string 每次都跑）
for ch in 'say "hello" # note':
    os.write(fd, ch.encode())
    pump(0.06)
pump(0.4)

typed = bytes(buf[mark:])
print("HAS-STRING-GREEN:", b"\x1b[32m" in typed)
print("HAS-COMMENT-GRAY:", b"\x1b[90m" in typed)
print("HAS-KEYWORD-BLUE:", b"\x1b[1m\x1b[34m" in typed)
print("HAS-ESC-1m:", b"\x1b[1m" in typed)
idx = typed.find(b"say")
print("AROUND-SAY:", repr(typed[max(0, idx-40):idx+40]) if idx >= 0 else "no say")
print("TAIL300:", repr(typed[-300:]))

os.write(fd, b"\r")
pump(1.5)
tail = bytes(buf[mark:]).decode("utf-8", "replace")
clean = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", tail)
print("EVAL-OK:", "Out[1] = hello" in clean or "hello" in clean)

os.write(fd, b"exit\r")
pump(1.0)
try:
    os.kill(pid, 9)
except ProcessLookupError:
    pass
