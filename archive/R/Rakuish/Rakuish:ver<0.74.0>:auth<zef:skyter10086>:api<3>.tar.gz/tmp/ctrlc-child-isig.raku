say 'NESTED-READY tty=' ~ $*IN.t;
signal(SIGINT).tap(-> $ { say 'NESTED-SIGINT'; exit 130 });
loop {
    my $l = $*IN.get;
    last unless $l.defined;
    last if $l.trim eq 'exit';
    say "NESTED-GOT[{$l.trim}]";
}
say 'NESTED-BYE';
