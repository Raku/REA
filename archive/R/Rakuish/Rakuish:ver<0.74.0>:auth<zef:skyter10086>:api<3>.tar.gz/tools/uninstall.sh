#!/usr/bin/env bash
# 从当前 Raku 环境卸载 Rakuish
set -euo pipefail

if ! command -v zef >/dev/null 2>&1; then
    echo "未找到 zef。" >&2
    exit 1
fi

echo "==> 卸载 Rakuish"
zef uninstall Rakuish || true
echo "完成。"
