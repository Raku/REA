"""Windows 控制台模式（termios 对应物）快照/恢复的真机自查。

Linux / macOS 侧的同一契约由 `t/31-tty-termios.t` 用 POSIX PTY 自动化；
Windows 没有 POSIX termios，走的是 `GetConsoleMode` / `SetConsoleMode`，
而且**必须有真控制台**才能观测，`prove6` 的管道环境测不了。因此这里用
真 ConPTY 起一个子 Raku 进程做检查：

  BEFORE    父进程读自己的输入模式（典型 503 = 0x1F7）
  子进程    make-raw 后不还原（清 PROCESSED/LINE/ECHO，置 VT input → 1008）
  AFTER     `tty-exec` 返回后应当回到 BEFORE

两个场景成对断言，避免「恢复成功」其实是「子进程根本没改」的假绿：
  · 默认路径：AFTER == BEFORE 且 restored=True
  · 对照路径（NOSNAP=1 关掉快照）：AFTER != BEFORE 且 restored=False

已知环境约束（0.72.5 实测，写在这里省下一个人一小时的排查）：
  1. ConPTY 属性只有在**驱动进程自己已经挂着控制台**时才生效。没有控制台
     时 `CreateProcess` 会给子进程新建一个隐式控制台，返回值照样成功、
     `isatty` 也是 True，但输出不进伪控制台管道 —— 表现为「静默不生效」。
     本脚本因此先检测自己有没有控制台，没有就用 winpty（Git for Windows
     自带）把自己重新拉起来。
  2. `UpdateProcThreadAttribute` 的 lpValue 要传 HPCON **句柄值本身**
     （MS EchoCon 样例写法），传 `byref(hPC)` 同样会静默不生效。
  3. winpty 自己会往 stderr 打一行 `Assertion failed: ... cols > 0`，是它
     查控制台尺寸失败的无害噪声，不影响结果。

用法：python tools/tty-termios-win.py
退出码：0 全部通过 / 1 有断言失败 / 2 环境不具备（非 Windows、没有 raku）
"""

import ctypes
import ctypes.wintypes as wt
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAKU = shutil.which("raku") or r"C:\rakudo\bin\raku.exe"
PROBE = "tools/tty-termios-probe.raku"
PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE = 0x00020016
EXTENDED_STARTUPINFO_PRESENT = 0x00080000
RELAUNCH_ENV = "RAKUISH_WIN_TTY_RELAUNCHED"
VERDICT_ENV = "RAKUISH_WIN_TTY_VERDICT"

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)


class COORD(ctypes.Structure):
    _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]


class STARTUPINFOW(ctypes.Structure):
    _fields_ = [
        ("cb", wt.DWORD), ("lpReserved", wt.LPWSTR), ("lpDesktop", wt.LPWSTR),
        ("lpTitle", wt.LPWSTR), ("dwX", wt.DWORD), ("dwY", wt.DWORD),
        ("dwXSize", wt.DWORD), ("dwYSize", wt.DWORD),
        ("dwXCountChars", wt.DWORD), ("dwYCountChars", wt.DWORD),
        ("dwFillAttribute", wt.DWORD), ("dwFlags", wt.DWORD),
        ("wShowWindow", wt.WORD), ("cbReserved2", wt.WORD),
        ("lpReserved2", ctypes.c_void_p), ("hStdInput", wt.HANDLE),
        ("hStdOutput", wt.HANDLE), ("hStdError", wt.HANDLE),
    ]


class STARTUPINFOEXW(ctypes.Structure):
    _fields_ = [("StartupInfo", STARTUPINFOW), ("lpAttributeList", ctypes.c_void_p)]


class PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [("hProcess", wt.HANDLE), ("hThread", wt.HANDLE),
                ("dwProcessId", wt.DWORD), ("dwThreadId", wt.DWORD)]


kernel32.CreatePipe.argtypes = [ctypes.POINTER(wt.HANDLE), ctypes.POINTER(wt.HANDLE),
                                ctypes.c_void_p, wt.DWORD]
kernel32.CreatePseudoConsole.argtypes = [COORD, wt.HANDLE, wt.HANDLE, wt.DWORD,
                                         ctypes.POINTER(wt.HANDLE)]
kernel32.CreatePseudoConsole.restype = ctypes.c_long
kernel32.InitializeProcThreadAttributeList.argtypes = [
    ctypes.c_void_p, wt.DWORD, wt.DWORD, ctypes.POINTER(ctypes.c_size_t)]
kernel32.UpdateProcThreadAttribute.argtypes = [
    ctypes.c_void_p, wt.DWORD, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t,
    ctypes.c_void_p, ctypes.c_void_p]
kernel32.CreateProcessW.argtypes = [
    wt.LPCWSTR, wt.LPWSTR, ctypes.c_void_p, ctypes.c_void_p, wt.BOOL, wt.DWORD,
    ctypes.c_void_p, wt.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(PROCESS_INFORMATION)]
kernel32.ReadFile.argtypes = [wt.HANDLE, ctypes.c_void_p, wt.DWORD,
                              ctypes.POINTER(wt.DWORD), ctypes.c_void_p]
kernel32.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]


def has_console():
    mode = wt.DWORD(0)
    return bool(kernel32.GetConsoleMode(kernel32.GetStdHandle(-10), ctypes.byref(mode)))


class ConPTY:
    """在真伪控制台里跑一个子进程，收集它的输出。"""

    def __init__(self, cmdline, cwd=None, cols=110, rows=30):
        self.buf = bytearray()
        self._lock = threading.Lock()

        h_in_read, h_in_write = wt.HANDLE(), wt.HANDLE()
        h_out_read, h_out_write = wt.HANDLE(), wt.HANDLE()
        for a, b in ((h_in_read, h_in_write), (h_out_read, h_out_write)):
            if not kernel32.CreatePipe(ctypes.byref(a), ctypes.byref(b), None, 0):
                raise OSError(ctypes.get_last_error(), "CreatePipe failed")

        self.h_in_write = h_in_write
        self.h_out_read = h_out_read
        self.h_pc = wt.HANDLE()
        hr = kernel32.CreatePseudoConsole(COORD(cols, rows), h_in_read, h_out_write,
                                          0, ctypes.byref(self.h_pc))
        if hr != 0:
            raise OSError(hr, "CreatePseudoConsole failed hr=0x%08x" % (hr & 0xFFFFFFFF))

        size = ctypes.c_size_t(0)
        kernel32.InitializeProcThreadAttributeList(None, 1, 0, ctypes.byref(size))
        self._attrs = ctypes.create_string_buffer(size.value)
        if not kernel32.InitializeProcThreadAttributeList(self._attrs, 1, 0,
                                                          ctypes.byref(size)):
            raise OSError(ctypes.get_last_error(), "InitializeProcThreadAttributeList failed")
        # lpValue 传 HPCON 句柄值本身；传指针会静默不生效（见文件头约束 2）。
        if not kernel32.UpdateProcThreadAttribute(
                self._attrs, 0, PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE,
                self.h_pc, ctypes.sizeof(wt.HANDLE), None, None):
            raise OSError(ctypes.get_last_error(), "UpdateProcThreadAttribute failed")

        si = STARTUPINFOEXW()
        si.StartupInfo.cb = ctypes.sizeof(STARTUPINFOEXW)
        si.StartupInfo.dwFlags = 0          # 不能设 STARTF_USESTDHANDLES
        si.lpAttributeList = ctypes.cast(self._attrs, ctypes.c_void_p)

        pi = PROCESS_INFORMATION()
        cmd = ctypes.create_unicode_buffer(cmdline)
        ok = kernel32.CreateProcessW(None, cmd, None, None, False,
                                     EXTENDED_STARTUPINFO_PRESENT, None,
                                     cwd or ROOT, ctypes.byref(si), ctypes.byref(pi))
        if not ok:
            raise OSError(ctypes.get_last_error(), "CreateProcessW failed")
        self.h_process = pi.hProcess
        kernel32.CloseHandle(pi.hThread)
        kernel32.CloseHandle(h_in_read)
        kernel32.CloseHandle(h_out_write)

        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        buf = ctypes.create_string_buffer(4096)
        n = wt.DWORD(0)
        while True:
            if not kernel32.ReadFile(self.h_out_read, buf, 4096, ctypes.byref(n), None):
                return
            if n.value == 0:
                return
            with self._lock:
                self.buf.extend(buf.raw[: n.value])

    @property
    def text(self):
        with self._lock:
            return bytes(self.buf).decode("utf-8", "replace")

    def poll(self):
        code = wt.DWORD(0)
        kernel32.GetExitCodeProcess(self.h_process, ctypes.byref(code))
        return None if code.value == 259 else code.value

    def wait(self, timeout=90):
        kernel32.WaitForSingleObject(self.h_process, int(timeout * 1000))
        return self.poll()

    def close(self):
        try:
            kernel32.ClosePseudoConsole(self.h_pc)
        except Exception:
            pass
        for h in (self.h_in_write, self.h_out_read, self.h_process):
            try:
                kernel32.CloseHandle(h)
            except Exception:
                pass


def run_probe(nosnap):
    """跑一次探针，返回 (exit, 解析出的键值)。"""
    old = os.environ.pop("NOSNAP", None)
    if nosnap:
        os.environ["NOSNAP"] = "1"
    try:
        p = ConPTY('"%s" -Ilib %s' % (RAKU, PROBE), cwd=ROOT)
        code = p.wait(120)
        time.sleep(0.6)
        text = p.text
        p.close()
    finally:
        if old is not None:
            os.environ["NOSNAP"] = old

    probe, polluter = {}, {}
    for line in text.splitlines():
        # ConPTY 会在行首塞模式序列（ESC[?25h 之类），先清掉再判断。
        line = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", line)
        line = re.sub(r"\x1b\][^\x07]*\x07", "", line).strip()
        if line.startswith("PROBE"):
            bucket = probe
        elif line.startswith("POLLUTER"):
            bucket = polluter
        else:
            continue
        for tok in line.split():
            if "=" in tok:
                k, v = tok.split("=", 1)
                bucket[k] = v
    return code, probe, polluter, text


def relaunch_under_winpty():
    # winpty 不透传子进程退出码（实测把 exit 5 变成 0），所以走裁决文件。
    winpty = shutil.which("winpty")
    if not winpty:
        print("SKIP: 当前进程没有控制台，且找不到 winpty（ConPTY 属性不会生效）")
        return 2
    fd, path = tempfile.mkstemp(prefix="rakuish-tty-", suffix=".rc")
    os.close(fd)
    env = dict(os.environ, **{RELAUNCH_ENV: "1", VERDICT_ENV: path})
    try:
        subprocess.run([winpty, "-Xallow-non-tty", sys.executable,
                        os.path.abspath(__file__)], cwd=ROOT, env=env)
        with open(path, encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return 2
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def check():
    if not sys.platform.startswith("win"):
        print("SKIP: 仅 Windows")
        return 2
    if not os.path.exists(RAKU):
        print("SKIP: 找不到 raku: %s" % RAKU)
        return 2
    if not has_console():
        if os.environ.get(RELAUNCH_ENV):
            print("SKIP: 已经在 winpty 下仍然拿不到控制台")
            return 2
        return relaunch_under_winpty()

    print("== Windows 控制台模式快照/恢复 ==")
    fails = []

    code, on, pol_on, text_on = run_probe(nosnap=False)
    before, after = on.get("before"), on.get("after")
    print("[snapshot on ] before=%s polluter=%s after=%s restored=%s dirty=%s"
          % (before, pol_on.get("after"), after, on.get("restored"), on.get("dirty")))
    if on.get("tty") != "True":
        fails.append("探针不在控制台里（tty=False），ConPTY 没挂上")
    if pol_on.get("after") in (None, before):
        fails.append("子进程没有真的改动控制台模式，对照失效")
    if on.get("restored") != "True":
        fails.append("termios-restored 不是 True")
    if after != before:
        fails.append("tty-exec 返回后模式没有恢复（after=%s before=%s）" % (after, before))

    code2, off, _, text_off = run_probe(nosnap=True)
    print("[snapshot off] before=%s after=%s restored=%s dirty=%s"
          % (off.get("before"), off.get("after"), off.get("restored"), off.get("dirty")))
    if off.get("restored") != "False":
        fails.append("关闭快照时 restored 应为 False")
    if off.get("after") == off.get("before"):
        fails.append("关闭快照后模式竟然没变，说明断言不敏感")

    print("exit codes: snapshot-on=%s snapshot-off=%s" % (code, code2))
    if fails:
        for f in fails:
            print("FAIL: " + f)
        return 1
    print("PASS: ConPTY 下 tty-exec 交接期控制台模式已自动恢复")
    return 0


def main():
    rc = check()
    verdict = os.environ.get(VERDICT_ENV)
    if verdict:
        try:
            with open(verdict, "w", encoding="utf-8") as f:
                f.write(str(rc))
        except OSError:
            pass
    return rc


if __name__ == "__main__":
    sys.exit(main())
