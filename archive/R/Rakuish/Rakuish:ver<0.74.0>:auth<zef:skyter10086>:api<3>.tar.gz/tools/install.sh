#!/usr/bin/env bash
# 安装 Rakuish 到当前 Raku 环境（zef）
set -euo pipefail

here="$(cd "$(dirname "$0")/.." && pwd)"
cd "$here"

# 两个入口都要可执行位（shebang 是 #!/usr/bin/env raku，直接跑要靠它）
chmod +x bin/rakuish bin/rakuish-agent

if ! command -v zef >/dev/null 2>&1; then
    echo "未找到 zef。请先安装 Raku 工具链（rakubrew / rakudo 自带 zef）。" >&2
    exit 1
fi

echo "==> 用 zef 安装 Rakuish（读取 META6.json，运行期依赖只有 JSON::Fast）"
zef install .

echo
echo "完成。之后可直接运行："
echo "    rakuish                 # REPL：Raku 表达式 + ! argv"
echo "    rakuish -e '1 + 1'      # 求值一段 Raku"
echo "    rakuish foo.raku        # 跑 Raku 脚本（已预加载 DSL）"
echo "    rakuish --agent --help  # Agent（结构化 op）"
echo "    # 或：raku $here/bin/rakuish"
