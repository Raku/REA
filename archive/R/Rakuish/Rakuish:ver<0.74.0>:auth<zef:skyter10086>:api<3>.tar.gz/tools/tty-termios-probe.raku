# ConPTY 探针：父进程在 tty-exec 前后读自己的控制台输入模式，
# 子进程把模式改成 raw 且**故意不还原**（等价 vim / less / stty raw）。
# NOSNAP=1 时用子类关掉快照，作为「污染确实发生」的对照。
#
# 由 tools/tty-termios-win.py 驱动；单独跑需要自己处在真控制台里。
use Terminal::API;
use Rakuish::Sys::Proc;

class NoSnapProc is Rakuish::Sys::Proc {
    method termios-snapshot($fd) { Nil }
}

my Bool $nosnap = so %*ENV<NOSNAP>;
my $fd = $*IN.native-descriptor;
my $before = (try { Terminal::API::get-config($fd) });
say "PROBE nosnap=$nosnap tty={$*IN.t} fd=$fd before=$before";

my $p = $nosnap ?? NoSnapProc.new !! Rakuish::Sys::Proc.new;
my $r = $p.tty-exec($*EXECUTABLE.Str, '-Ilib', 'tools/tty-polluter.raku');

my $after = (try { Terminal::API::get-config($fd) });
say "PROBE result ok={$r.ok} code={$r.code} tty={$r.value<tty>} "
    ~ "restored={$r.value<termios-restored>} after=$after "
    ~ "dirty={($before ne $after).so}";
