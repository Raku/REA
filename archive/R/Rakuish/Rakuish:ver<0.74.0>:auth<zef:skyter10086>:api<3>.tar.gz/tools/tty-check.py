#!/usr/bin/env python3
"""Rakuish 真 TTY 交互自检（0.70 起可复现，0.71 加 Ctrl-C 中断验收），
0.72.3 加 `tty-exec` 期间前台进程组 SIGINT 的归属回归（ADR-0009）；
0.72.4 的 termios 快照恢复由 t/31 用 canonical 基线单独覆盖（本驱动是 raw）；
0.73.0 起 `tty-exec` 会切进程组，本驱动改为读 /proc 的 tpgid 取**真实前台组**
（原来 killpg(父进程组) 的模拟写法已失效，见 ADR-0010 §6.3）；
0.74.0 增结果着色 / 输入行高亮三项（在 raw 字节上断言，ADR-0011）。

真实终端会应答 ESC[6n（光标位置报告），`script` 不会；每个 prompt 会发
两次 DSR：
  #1 detect-cursor-pos      必须回当前光标位置（回 1;1 即可）
  #2 detect-terminal-size   在 ESC[9999;9999H 之后，回被钳制到的右下角
两次都回 24;110 会让 display-width 变成 0，输入区直接卡死。本脚本用
字节级状态机跟踪 9999 标记，Tab 补全 / vi 切换带来的额外重绘也不会错位。

另有两个坑（都踩过）：
  · 行编辑器 enter-raw-mode 用 TCSAFLUSH，Raku 启动完成前送进去的按键
    会被丢弃 ⇒ 必须等第一个 prompt 出现再发键。
  · 不要改 HOME：Raku 靠 $HOME 找 site 资源与原生库（DuckDB 会因此
    「Cannot locate native library」）⇒ 用 RAKUISH_CONFIG 隔离配置。

用法（需要 python3 + pty，即 Linux/macOS/WSL）：
    RAKU=/path/to/raku python3 tools/tty-check.py
    python3 tools/tty-check.py            # 自动从 PATH 找 raku
输出写到 tmp/tty-out.raw / tmp/tty-out.txt；任一检查 FAIL 时退出码 1。
Windows 原生没有 pty 模块，请在 WSL 里跑（或按 tmp/TTY-CHECK.md 人肉试）。
"""
import fcntl
import os
import pty
import re
import select
import shutil
import signal
import struct
import subprocess
import sys
import termios
import time
import tty
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CWD = str(ROOT)
OUTDIR = ROOT / "tmp"
HOME = "/tmp/rakuish-tty-probe"
RAW_OUT = OUTDIR / "tty-out.raw"
TXT_OUT = OUTDIR / "tty-out.txt"

RAKU = (
    os.environ.get("RAKU")
    or shutil.which("raku")
    or "/home/zby/.rakubrew/versions/moar-2026.09/install/bin/raku"
)
if not Path(RAKU).exists() and not shutil.which(RAKU):
    sys.exit("找不到 raku：设 RAKU=/path/to/raku 或把它放进 PATH")

os.makedirs(HOME, exist_ok=True)
OUTDIR.mkdir(exist_ok=True)
# 自检用的「嵌套 REPL」替身由工具自己生成，不依赖任何 gitignored 文件。
CHILD = OUTDIR / "nested-repl-child.raku"
CHILD.write_text(
    "say 'NESTED-READY tty=' ~ $*IN.t;\n"
    # 0.72.3：让第二轮嵌套 REPL 能被 SIGINT 中断，并留下可断言的标记。
    "signal(SIGINT).tap(-> $ { say 'NESTED-SIGINT'; exit 130 });\n"
    "loop {\n"
    "    my $l = $*IN.get;\n"
    "    last unless $l.defined;\n"
    "    last if $l.trim eq 'exit';\n"
    "    say \"NESTED-GOT[$l]\";\n"
    "}\n"
    "say 'NESTED-BYE';\n",
    encoding="utf-8",
)
env = os.environ.copy()
env.update(
    # 不要覆盖 HOME，详见模块 docstring。配置按 PID 隔离，避免上一轮残留的
    # edit-mode / vi-start 让本轮从 vi normal 起步。
    RAKUISH_CONFIG=HOME + "/config-%d.json" % os.getpid(),
    TERM="xterm-256color",
    LANG="C.UTF-8",
    PATH=os.path.dirname(RAKU) + ":" + env.get("PATH", ""),
)

master, slave = pty.openpty()
fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 24, 110, 0, 0))
# 让 REPL 自己接管终端：canonical 模式下没有换行的 DSR 应答不会送达。
tty.setraw(slave)


def _own_session():
    """让 REPL 成为 session leader 并**把 slave 设成控制终端**。

    只 setsid 不够：继承来的 fd 不会自动变成 controlling terminal，
    那样 /proc/<pid>/stat 的 tpgid 是 -1，读不到真实前台组。
    """
    os.setsid()
    fcntl.ioctl(0, termios.TIOCSCTTY, 0)


proc = subprocess.Popen(
    [RAKU, "-Ilib", "bin/rakuish"],
    cwd=CWD, env=env, stdin=slave, stdout=slave, stderr=slave, close_fds=True,
    preexec_fn=_own_session,
)
os.close(slave)


def foreground_group(pid):
    """读 /proc/<pid>/stat 的 tpgid —— 该 tty 当前的**真实前台进程组**。

    `tty-exec` 切组后，前台组会是子进程自己的组；继续用
    `killpg(os.getpgid(pid))` 只会打到宿主那一组（ADR-0010 §6.3）。
    字段布局：state ppid pgrp session tty_nr tpgid ...
    """
    try:
        with open("/proc/%d/stat" % pid) as f:
            fields = f.read().rsplit(") ", 1)[1].split()
        return int(fields[5])
    except (OSError, IndexError, ValueError):
        return os.getpgid(pid)

raw = bytearray()
deadline = time.time() + 140
esc = b""
size_pending = False
dsr_count = 0


def feed(data):
    """Byte-level scan: answer every DSR with the right kind of report."""
    global esc, size_pending, dsr_count
    for byte in data:
        esc += bytes((byte,))
        if len(esc) > 24:
            esc = esc[-24:]
        if esc.endswith(b"\x1b[9999;9999H"):
            size_pending = True
        elif esc.endswith(b"\x1b[6n"):
            dsr_count += 1
            os.write(master, b"\x1b[24;110R" if size_pending else b"\x1b[1;1R")
            size_pending = False
            esc = b""


def pump(seconds):
    """Read pty output for `seconds`, answering DSR queries."""
    end = time.time() + seconds
    while time.time() < end and time.time() < deadline:
        readable, _, _ = select.select([master], [], [], 0.08)
        if not readable:
            continue
        try:
            data = os.read(master, 65536)
        except OSError:
            break
        if not data:
            break
        raw.extend(data)
        feed(data)
        end = max(end, time.time() + 0.25)


def send(text, wait=0.9):
    # A callable step performs an out-of-band action (e.g. SIGINT) instead
    # of writing bytes into the pty.
    if callable(text):
        text()
    else:
        os.write(master, text.encode("utf-8") if isinstance(text, str) else text)
    pump(wait)


def prompt_count():
    """Number of prompts emitted so far (the arrow is printed once per cell)."""
    return raw.count(b"\xe2\x9d\xaf")


def wait_ready(timeout=30):
    """Wait for the first real prompt before typing (TCSAFLUSH discards early keys)."""
    end = time.time() + timeout
    while time.time() < end:
        pump(0.3)
        if prompt_count() or dsr_count >= 2:
            return True
    return False


def wait_new_prompt(before, timeout=18):
    """Wait until the NEXT prompt appears.

    Fixed sleeps are unreliable: first open-db can take 600ms+, and keys sent
    while a cell is still evaluating are discarded by the next TCSAFLUSH.
    """
    end = time.time() + timeout
    while time.time() < end:
        pump(0.2)
        if prompt_count() > before:
            return True
    return False


# (label, keys, wait_after_send, sync_on_new_prompt)
# sync=False only for keystrokes aimed at the nested child: while it owns the
# TTY there is no Rakuish prompt until it exits.
STEPS = [
    ("startup", None, 0, False),
    ("eval 1+1", "1 + 1\r", 0.8, True),
    # 0.71 / ADR-0008：半行输入后按 Ctrl-C，REPL 必须继续活着，
    # 且下一格仍能求值（中断本身不产生空 Out[n] 格）。
    ("ctrl-c half line", "say 'half-line", 0.4, False),
    ("ctrl-c abort", "\x03", 0.8, False),
    ("eval after ctrl-c", "40 + 2\r", 0.8, True),
    ("hint ls", "hint ls\r", 0.8, True),
    ("perf", "perf\r", 0.8, True),
    ("vi mode on", "config set edit-mode vi\r", 0.8, True),
    ("vi prompt", "say 'vi-check'\r", 0.8, True),
    ("vi normal", "config set vi-start normal\r", 0.8, True),
    ("emacs back", "config set edit-mode emacs\r", 0.8, True),
    ("completion", "c\t", 1.0, False),
    ("submit leftover", "\r", 0.7, True),
    ("register engine",
     "my $db = open-db(':memory:', :!read-only, :!safe); "
     "$db.execute('create table sales (id int, region text)')\r", 1.0, True),
    ("sql completion", "$db.query('select * from sa\t", 1.0, False),
    ("submit sql line", "')\r", 0.8, True),
    ("describe table", "describe sales\r", 1.0, True),
    # 0.70 嵌套 REPL：代理 pty 是 raw 模式，子进程的 .get 需要真正的 \n。
    ("launch nested",
     "! --tty " + RAKU + " " + str(CHILD.relative_to(ROOT)) + "\n", 1.5, False),
    ("nested input", "hello\n", 1.2, False),
    ("nested exit", "exit\n", 1.5, False),
    ("back in rakuish", "1 + 1\n", 0.8, True),
    # 0.72.3 / ADR-0009：`tty-exec` 期间 Ctrl-C 的归属。本驱动是 raw 模式
    # （ISIG 关），写 \x03 不会变成信号；改成显式 killpg —— 但目标必须是
    # **终端前台进程组**（/proc tpgid），不能是宿主自己的组：0.73.0 起
    # tty-exec 会把子进程放进独立进程组并抢走前台（ADR-0010 §6.3）。
    ("launch nested for sigint",
     "! --tty " + RAKU + " " + str(CHILD.relative_to(ROOT)) + "\n", 1.5, False),
    ("sigint foreground group",
     lambda: os.killpg(foreground_group(proc.pid), signal.SIGINT)
     if proc.poll() is None else None, 1.8, False),
    ("back after tty sigint", "7 * 7\n", 0.8, True),
    # 0.74.0 / ADR-0011：结果着色与输入行高亮。ls 会走 Session 的路径列表
    # 渲染（目录粗蓝），输入行走行编辑器的 HlField（字符串绿 / 关键字粗蓝）。
    ("ls colored", "ls\n", 1.0, False),
    ("type highlighted", 'say "hi"\n', 1.2, True),
    ("quit", "exit\n", 0.8, False),
]

for label, keys, wait, sync in STEPS:
    if keys is None:
        ready = wait_ready()
        print(f"[ready] first prompt: {ready}", flush=True)
        if not ready:
            print("[abort] REPL 在超时内没有出现 prompt", flush=True)
            break
        continue
    before = prompt_count()
    send(keys, 0.12)              # deliver keystrokes, keep reading DSRs
    if sync:
        if not wait_new_prompt(before):
            print(f"[warn] {label}: 等不到新 prompt，仍继续发送", flush=True)
    else:
        pump(wait)
    alive = proc.poll() is None
    print(f"[step] {label} alive={alive}", flush=True)
    if not alive:
        print(f"[exit] REPL ended at {label}, rc={proc.returncode}", flush=True)
        break

pump(0.6)
if proc.poll() is None:
    proc.send_signal(signal.SIGTERM)
    try:
        proc.wait(timeout=3)
    except subprocess.TimeoutExpired:
        proc.kill()
os.close(master)

RAW_OUT.write_bytes(raw)
text = raw.decode("utf-8", "replace")
text = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", text)
text = re.sub(r"\x1b[=>]", "", text)
text = text.replace("\r", "")
TXT_OUT.write_text(text, encoding="utf-8")

CHECKS = [
    ("banner wordmark", "Rakuish"),
    ("version in banner", r"v0\.(?:69|70|71|72|73|74)\.\d+"),
    ("colored prompt arrow", "\u276f"),
    ("git branch badge", "git:main"),
    ("eval result", r"Out\[1\] = 2"),
    ("ctrl-c interrupt hint", "已中断当前输入"),
    ("eval after ctrl-c", r"Out\[\d+\] = 42"),
    ("hint output", "\u63d0\u793a|\u7528\u6cd5"),
    ("perf report", "perf|\u8017\u65f6|ms"),
    ("vi badge", "VI\u00b7|VI\\|normal|NORMAL"),
    ("engine registered", r"Rakuish::Data::Engine::DuckDB|Out\["),
    ("sql completion", "sales"),
    ("describe output", "nullable|describe"),
    ("nested child ready", r"NESTED-READY tty=True"),
    ("nested child first char intact", r"NESTED-GOT\[hello\]"),
    ("nested child exit", "NESTED-BYE"),
    ("tty-exec handoff summary", r"\u21a9|已退出"),
    ("REPL alive after nested", r"Out\[\d+\] = 2"),
    ("tty-exec sigint child", "NESTED-SIGINT"),
    ("tty-exec sigint exit code", r"code=130"),
    ("REPL alive after tty sigint", r"Out\[\d+\] = 49"),
    # 着色（在 raw 上匹配；text 已经 strip 过 ANSI）
    ("ls dir colored", r"\x1b\[1m\x1b\[34m", True),
    ("input string colored", r"\x1b\[32m\"hi\"", True),
    ("input keyword colored", r"\x1b\[1m\x1b\[34msay", True),
    ("no crash trace", None),
]

print("\n===== CHECKS =====")
failed = 0
for entry in CHECKS:
    label, pattern = entry[0], entry[1]
    # 第三元素为 True 表示「在 raw 字节里找」——着色是 ANSI，去色后看不见。
    on_raw = len(entry) > 2 and entry[2]
    if pattern is None:
        hit = "Cannot invoke" not in text and "Unhandled exception" not in text
    elif on_raw:
        hit = re.search(pattern.encode(), bytes(raw), re.IGNORECASE) is not None
    else:
        hit = re.search(pattern, text, re.IGNORECASE) is not None
    failed += 0 if hit else 1
    print(f"{'PASS' if hit else 'FAIL'}  {label}")
print(f"\nraw bytes={len(raw)}  text chars={len(text)}  DSR answered={dsr_count}")
print(f"output: {TXT_OUT}")
sys.exit(1 if failed else 0)
