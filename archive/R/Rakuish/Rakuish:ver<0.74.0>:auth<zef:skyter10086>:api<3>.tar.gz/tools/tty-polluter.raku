# ConPTY 子进程：把控制台输入模式改成 raw 后**不还原**。
# Windows 分支走 Terminal::API::make-raw 的 SetConsoleMode：
#   清掉 ENABLE_PROCESSED_INPUT / ENABLE_LINE_INPUT / ENABLE_ECHO_INPUT，
#   置上 ENABLE_VIRTUAL_TERMINAL_INPUT —— 与 vim / less 拿到终端时一样。
use Terminal::API;

my $fd = $*IN.native-descriptor;
my $before = (try { Terminal::API::get-config($fd) });
say "POLLUTER tty={$*IN.t.Int} fd=$fd before={$before.raku}";

Terminal::API::make-raw($fd);

my $after = (try { Terminal::API::get-config($fd) });
say "POLLUTER after={$after.raku} changed={($before.raku ne $after.raku).Int}";
