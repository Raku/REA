#!/usr/bin/env bash
# 全套件回归：每个套件在 **Rakudo（MoarVM）** 上跑，结果写 tmp/all.log。
#
# 0.34.0（Phase 5b）起仓库只有一套实现（API v3），v2 已整体删除，
# 所以测试目录也只剩一层：t/*.t
#
#   t/01 … 07      V3 语义：Sys 文件 API、会话语义、进程 API、
#                  DSL/Command、REPL 会话、Sandbox/Agent、入口契约
#   t/51 / t/52    元数据护栏（provides 与文件一一对应）、全模块 require 冒烟
#
# ⚠ 本脚本的退出码反映汇总结果：问题总数为 0 才 exit 0，否则 exit 1。
#   CI 直接看退出码即可；但人肉核对时仍要把 not ok 计数和退出码一起看：
#   测试崩在中途时 not ok 计数是 0 而退出码非 0，只看计数会把「崩溃」当「全绿」。
#
# 用法：
#   bash tools/run-all.sh

_here="$(cd "$(dirname "$0")" && pwd)"
source "$_here/env.sh"          # 统一探测 raku（并塞进 PATH，供 shebang 用）
cd "$_here/.." || exit 1

R=$RAKU
mkdir -p tmp

total=0
: > tmp/all.log

run_one() {
    local t="$1"
    local name
    name=$(printf '%s' "$t" | sed 's#^t/##; s#/#__#g')

    timeout 300 "$R" -Ilib "$t" > "tmp/$name.out" 2>&1
    local rc_m=$?
    local n_m p_m
    n_m=$(grep -c 'not ok' "tmp/$name.out")
    # plan 行允许带 SKIP 注释：整文件跳过时 TAP 输出是 `1..0 # SKIP 原因`，
    # 用行尾锚定的 ^1\.[0-9]+$ 会把它误判成「缺 plan」⇒ 唯一合法跳过也报红。
    p_m=$(grep -cE '^1\.\.[0-9]+( *# *SKIP.*)?$' "tmp/$name.out")
    printf '%-36s MoarVM rc=%s notok=%s plan=%s\n' "$name" "$rc_m" "$n_m" "$p_m" >> tmp/all.log

    total=$(( total + n_m ))
    [ "$rc_m" -ne 0 ] && total=$(( total + 1 ))
    [ "$p_m" -eq 0 ] && total=$(( total + 1 ))
}

for t in t/*.t; do
    [ -e "$t" ] || continue
    run_one "$t"
done

echo "-----------------------------------------" >> tmp/all.log
echo "问题总数（not ok + 非零退出码 + 缺 TAP plan）: $total" >> tmp/all.log
cat tmp/all.log

if [ "$total" -eq 0 ]; then
    exit 0
fi
exit 1
