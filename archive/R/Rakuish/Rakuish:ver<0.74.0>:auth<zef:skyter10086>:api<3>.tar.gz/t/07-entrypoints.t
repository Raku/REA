use Test;
use JSON::Fast;

# ════════════════════════════════════════════════════════════════════
# t/07 — 入口契约（Phase 5b：v2 已删除，只剩两个入口）
#
# 钉住五件事：
#   ① 入口只有 bin/rakuish 与 bin/rakuish-agent；v2 的入口文件必须不存在
#   ② bin/rakuish 里不能残留任何 v2 痕迹（Loop / daemon / --v2 / magic）
#   ③ 默认入口 = Raku 原生：% 按 Raku、无 auto-shell、! 只做 argv
#   ④ --agent 转发继承 stdio 与退出码
#   ⑤ 两个入口的版本常量与 META6 一致，且 META6.api = 3
#
# 全部走真实子进程，不 mock、不直接 use 被测入口。
# ════════════════════════════════════════════════════════════════════

sub repo-root(--> IO::Path) {
    # 不用 $?FILE：Win32 上它常丢盘符（实测），拼出来会指到当前盘根。
    my IO::Path $d = $*CWD.IO.absolute.IO;
    loop {
        return $d if $d.add('META6.json').e;
        my IO::Path $up = $d.parent;
        return $d if $up.absolute.Str eq $d.absolute.Str;
        $d = $up;
    }
}

my $root = repo-root();
my $BIN  = $root.add('bin/rakuish');
my $BINA = $root.add('bin/rakuish-agent');
my %meta = from-json($root.add('META6.json').slurp);
my $version = %meta<version>.Str;
my $exe = $*EXECUTABLE.Str;

my $tmp = $*TMPDIR.IO.add("rk-entry-{$*PID}");
$tmp.mkdir;
END {
    if $tmp.d {
        for $tmp.dir -> $f { try { $f.d ?? $f.rmdir !! $f.unlink } }
        try $tmp.rmdir;
    }
}

my $seq = 0;
sub invoke(IO::Path $entry, *@args, Str :$stdin = '', Str :$cwd = '' --> Hash) {
    my $in = $tmp.add("stdin-{$seq++}.txt");
    $in.spurt($stdin);
    my $fh = $in.open;
    # :in(句柄) + :out/:err —— stdio 全部可控，且不经过 shell；
    # :cwd 可选，用来验证脚本的相对路径跟随调用者 cwd（不是脚本所在目录）。
    my $p = $cwd.chars
        ?? run($exe, $entry.Str, |@args, :in($fh), :out, :err, :cwd($cwd))
        !! run($exe, $entry.Str, |@args, :in($fh), :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    my $rc  = $p.exitcode;
    $fh.close;
    try $in.unlink;
    { out => $out, err => $err, rc => $rc }
}

sub tmp-file(Str $name, Str $body --> IO::Path) {
    my $f = $tmp.add($name);
    $f.spurt($body);
    $f
}

# ── ① 只剩两个入口，v2 入口必须不存在 ─────────────────────────────
ok $BIN.e,  '入口 bin/rakuish 存在';
ok $BINA.e, '入口 bin/rakuish-agent 存在';
nok $root.add('bin/rakuish-v2').e, 'bin/rakuish-v2 已删除（v2 不再保留兼容入口）';
nok $root.add('bin/rakuish-v3').e, 'bin/rakuish-v3 已删除（V3 就是唯一实现，不需要别名）';
nok $root.add('bin/rakuish-sh').e, 'bin/rakuish-sh 已删除（独立 shell 引擎下线）';

my @bin = $root.add('bin').dir.map(*.basename).sort;
is-deeply @bin.List, ('rakuish', 'rakuish-agent'), 'bin 下只有两个入口脚本';

# ── ② 入口源码里没有 v2 痕迹 ─────────────────────────────────────
my $main-src = $BIN.slurp;
ok $main-src.contains('Rakuish::REPL::Session'), '入口装载 Raku 原生会话';
nok $main-src.contains('Rakuish::Loop'),          '入口不再装载 v2 Loop';
nok $main-src.contains('daemon'),                 '入口不再有 daemon 概念';
nok $main-src.contains("'--v2'"),                 '入口不再提供 --v2 开关';
nok $main-src.contains('rakuish-v2'),             '入口不再转发到 v2';

nok $root.add('lib/Rakuish/Loop.rakumod').e,     'v2 的 Loop 模块已删除';
nok $root.add('lib/Rakuish/Parser.rakumod').e,   'v2 的 Parser 已删除';
nok $root.add('lib/Rakuish/Shell').e,            'v2 的 Shell::* 已删除';
nok $root.add('lib/Rakuish/Engine').e,           'v2 的 Engine::* 已删除';
nok $root.add('lib/Rakuish/V3').e,               '不再有 V3 命名空间（已提升为顶层）';
ok $root.add('lib/Rakuish/Sys.rakumod').e,       'Rakuish::Sys 已是顶层模块';

# ── ③ 版本与 api ─────────────────────────────────────────────────
is %meta<api>.Str, '3', 'META6.api = 3（v2 已下线，宣称与实际一致）';
for $BIN, $BINA -> $e {
    ok $e.slurp.contains("'$version'"), "{$e.basename} 的版本常量与 META6($version) 一致";
}

my %v-main = invoke($BIN,  '--version');
my %v-ag   = invoke($BIN,  '--agent', '--version');
ok %v-main<out>.contains($version), "bin/rakuish --version = $version";
ok %v-ag<out>.contains($version),   "--agent --version = $version";
is %v-main<rc>, 0, '--version 正常退出';

# ── ④ help 只描述一套语义 ────────────────────────────────────────
my %help = invoke($BIN, '--help');
ok %help<out>.contains('--agent'),   'help 说明 Agent 转发';
ok %help<out>.contains('Raku 原生'), 'help 标明 Raku 原生环境';
ok %help<out>.contains('没有 %magic'), 'help 明确无 magic 分流';
nok %help<out>.contains('--v2'),      'help 不再提 --v2';
nok %help<out>.contains('%magic /'),  'help 不再有 magic 用法段落';

# ── ⑤ -e：一个 REPL 格 ──────────────────────────────────────────
my %e1 = invoke($BIN, '-e', '1 + 1');
is %e1<out>.trim, 'Out[1] = 2', '-e 求值 Raku 表达式';
is %e1<rc>, 0, '-e 正常退出';

my %e2 = invoke($BIN, '-e', 'my %h = a => 7; %h<a>');
ok %e2<out>.contains('7'),       '% 开头按 Raku 哈希求值，不是魔法命令';
nok %e2<err>.contains('magic'),  '没有触发任何 magic 分流';

my %e3 = invoke($BIN, '-e', 'git status');
isnt %e3<rc>, 0, '裸打 git status 失败（无 auto-shell 回退）';
ok %e3<out>.contains('Undeclared') || %e3<err>.contains('Undeclared'),
    '失败原因是 Raku 未声明例程，而非 shell 找不到命令';

# say 的返回值是 Bool::True，渲染出来只是噪声
my %e4 = invoke($BIN, '-e', 'say 2 ** 8');
is %e4<out>.trim, '256', '-e 里 say 输出干净，不追加 Out[1] = Bool::True';
is %e4<rc>, 0, '-e + say 正常退出';
my %e5 = invoke($BIN, '-e', 'True');
is %e5<out>.trim, '', '-e 的 Bool::True 不渲染（边界行为，已写进 help/注释）';

my %bad-opt = invoke($BIN, '--definitely-not-an-option');
is %bad-opt<rc>, 2, '未知选项退出码 2';
ok %bad-opt<err>.contains('未知选项'), '未知选项有明确报错';

my %missing = invoke($BIN, $tmp.add('no-such-script.raku').Str);
is %missing<rc>, 2, '脚本不存在退出码 2';
ok %missing<err>.contains('找不到脚本'), '脚本不存在有明确报错';

# ── ⑥ 脚本就是 Raku 脚本 ────────────────────────────────────────
my $script = tmp-file('prog.raku', q:to/SRC/);
    say "中文 script-", @*ARGS.join(',');
    write('made.txt', 'DSL-ok');
    say read('made.txt');
    SRC
my %run = invoke($BIN, $script.Str, 'a', 'b', :cwd($tmp.Str));
is %run<rc>, 0,              '脚本正常退出';
ok %run<out>.contains('中文 script-a,b'), '脚本能拿到 @*ARGS 且中文正常';
ok %run<out>.contains('DSL-ok'),         '脚本里 DSL 短 sub 直接可用（无需 use）';
nok %run<out>.contains('Out['),          '脚本模式不打印 REPL 的 Out[n] 标签';
ok $tmp.add('made.txt').e,               '相对路径跟随调用者 cwd（会话级 Sys，不改进程全局）';

my $unclosed = tmp-file('broken.raku', "my @a = (\n");
my %unclosed-r = invoke($BIN, $unclosed.Str);
is %unclosed-r<rc>, 2, '未闭合结构拒绝静默不执行';

# ── ⑦ 管道 REPL ─────────────────────────────────────────────────
my $stdin = q{my %h = a => 7;
%h<a>
} ~ '! ' ~ $exe ~ q{ -e "say @*ARGS.raku" "a|b" "x y"} ~ "\nexit\n";
my %pipe = invoke($BIN, :stdin($stdin));
is %pipe<rc>, 0,                        '管道 REPL 正常退出';
ok %pipe<out>.contains('Out[2] = 7'),   '%h<a> 按 Raku 求值为 7，不是 magic';
ok %pipe<out>.contains('"a|b"'),        '! 里的 | 原样当 argv，不解释成管道';
ok %pipe<out>.contains('"x y"'),        '! 的引号分词保留空格参数';
nok %pipe<out>.contains('rakuish>'),    '管道下不打印交互提示符';
nok %pipe<out>.contains('Out[4]'),      'exit 不会被渲染成假的表达式结果';

# 把启动参数当 REPL 命令敲（用户实际踩过）：不为此开魔法分支，
# 但要给出「这是启动参数、请在 shell 里用」的提示。
my %flag-in-repl = invoke($BIN, :stdin("--help\n1 + 1\n"));
ok %flag-in-repl<out>.contains('提示:'),      '提示符里敲 --help 会给出提示';
ok %flag-in-repl<out>.contains('启动参数'),   '提示明确说明 --help 是启动参数';
ok %flag-in-repl<out>.contains('Out[1] = 2'), '提示之后 REPL 继续正常工作（失败格不占 Out 编号）';
nok %flag-in-repl<out>.contains('rakuish> --help'), '没有把它偷偷当成 REPL 命令分发';

# ── ⑧ Agent 转发继承 stdio ──────────────────────────────────────
my %ag-help = invoke($BIN, '--agent', '--help');
ok %ag-help<out>.contains('--root'), '--agent --help 转发到 Agent 入口';

my $req = to-json({ id => 1, token => 'tk', op => 'write_file',
                    path => 'agent.txt', content => '转发-ok' }, :!pretty) ~ "\n";
my %ag = invoke($BIN, '--agent', '--root', $tmp.Str, '--token', 'tk', :stdin($req));
is %ag<rc>, 0, '--agent 转发正常退出';
my @lines = %ag<out>.trim.lines.grep(*.starts-with('{'));
is @lines.elems, 1, '转发后 stdout 仍是一行 JSON（启动信息没混进 stdout）';
my %resp = @lines.elems ?? from-json(@lines[0]) !! ();
is %resp<id>, 1,  'Agent 响应带回请求 id（stdin 被正确继承）';
ok %resp<ok>,     'Agent 结构化 op 执行成功';
ok $tmp.add('agent.txt').e, 'Agent 写入落在 --root 沙箱内';

# 不复用 %bad-opt：同一词法作用域重复 my 声明会让 zef 的 Testing 阶段
# 报 "Redeclaration of symbol" 编译警告（0.72.2 顺手清理）。
my %bad-allow = invoke($BINA, '--root', $tmp.Str, '--allowlist', 'git');
is %bad-allow<rc>, 2, '未知 --allowlist 选项拒绝启动';
ok %bad-allow<err>.contains('未知选项'), '未知选项有明确错误';

done-testing;
