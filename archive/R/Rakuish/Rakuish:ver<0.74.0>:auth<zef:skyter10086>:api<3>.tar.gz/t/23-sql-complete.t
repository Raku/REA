use Test;

# 23-sql-complete.t —— Engine 元数据驱动的 SQL 上下文补全
# （0.68 / ADR-0005 §3；0.71 调用形态扩展 / ADR-0008 §3.2）
#
# 纯函数测试，不依赖数据库驱动或 TTY：用假 Engine 提供 tables()/schema()，
# 验证上下文识别、候选生成、完整替换行、异常优雅退化，以及 Session 联动。
# 唯一真实引擎的用例是 DSL.open-db 的会话注册链路，带 skip 护栏。

use Rakuish::Data::Table;
use Rakuish::REPL::SqlComplete;
use Rakuish::REPL::Session;

class FakeEngine {
    method tables() {
        Rakuish::Data::Table.from-rows([
            %(name => 'sales'), %(name => 'users'),
        ])
    }
    method schema($t) {
        Rakuish::Data::Table.from-rows([
            %(name => 'id'), %(name => 'amount'), %(name => 'region'),
        ])
    }
}

class BrokenEngine {
    method tables()   { die 'database is locked' }
    method schema($t) { die 'database is locked' }
}

my @lines = q:to/END/.lines;
$db.query('select * from sa
$db.query('select am
$db.cursor('select * from sales where re
$db.query('sel
ls a
say 1 + 1
END

my ($tbl, $col, $where, $kw, $shell, $plain) = @lines;
my $e = FakeEngine.new;

# ── 1. 上下文识别 ───────────────────────────────────────────────────
{
    my %c = sql-context($tbl, $tbl.chars);
    is %c<frag>, 'sa', 'from 后识别当前词 sa';
    is %c<mode>, 'table', 'from 后是表名上下文';
    is %c<word-start>, $tbl.chars - 2, '当前词起点正确';
    is %c<tail>, '', '行尾补全的 tail 为空';
    is sql-context($col, $col.chars)<mode>, 'column',
        'select 后是列名上下文';
    is sql-context($where, $where.chars)<mode>, 'column',
        'where 后是列名上下文';
    ok !sql-context($shell, $shell.chars).elems, '普通 shell 行不是 SQL 上下文';
    ok !sql-context($plain, $plain.chars).elems, '普通 Raku 行不是 SQL 上下文';
}

# ── 2. 候选生成与完整替换行 ─────────────────────────────────────────
{
    my @r = sql-completions($tbl, $tbl.chars, :engine($e));
    is @r.elems, 1, 'sa 只命中一个表名';
    is @r[0], q{$db.query('select * from sales},
        '表名补全返回完整替换行';

    my @c = sql-completions($col, $col.chars, :engine($e));
    is @c.elems, 1, 'am 只命中一个列名';
    is @c[0], q{$db.query('select amount}, '列名补全返回完整替换行';

    my @w = sql-completions($where, $where.chars, :engine($e));
    ok @w.grep({ .contains('region') }).elems == 1,
        'where 上下文补出 region 列';

    my @k = sql-completions($kw, $kw.chars);
    ok @k.grep({ .ends-with('select') }).elems == 1,
        '无 Engine 时仍补 SQL 关键字 select';
    nok sql-completions($tbl, $tbl.chars).elems,
        '无 Engine 且词不匹配关键字时不伪造表名';

    # 光标在字符串中间：tail 必须原样保留
    my Str $mid = q{$db.query('select * from saXYZ};
    my Int $pos = $mid.chars - 3;   # 光标停在 sa 之后、XYZ 之前
    my @m = sql-completions($mid, $pos, :engine($e));
    ok @m.grep({ .contains('salesXYZ') }).elems == 1,
        '光标在行中时补全保留 tail';

    ok !sql-completions($shell, $shell.chars, :engine($e)).elems,
        '非 SQL 行即使有 Engine 也不补全';
    ok !sql-completions(q{say('select * from sa}, 23, :engine($e)).elems,
        '非 query/cursor/execute 调用不触发 SQL 补全';
    my Str $closed = q{$db.query('select * from sales')};
    ok !sql-completions($closed, $closed.chars, :engine($e)).elems,
        '光标在已闭合字符串之后不补全';
    ok !sql-completions(q{q[select * from sa}, 19, :engine($e)).elems,
        '裸 q[...] 没有白名单调用前缀时不触发补全';
}

# ── 3. Engine 异常优雅退化 ──────────────────────────────────────────
{
    my @r = sql-completions($kw, $kw.chars, :engine(BrokenEngine.new));
    ok @r.grep({ .ends-with('select') }).elems == 1,
        'Engine 抛异常时关键字补全仍可用（不崩 REPL）';
    my @t = sql-completions($tbl, $tbl.chars, :engine(BrokenEngine.new));
    is @t.elems, 0, 'Engine 抛异常时不返回半截表名';
}

# ── 4. Session 联动：SQL 优先、Shell 回退不变 ─────────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    ok $s.completions('c', 1).List.grep(* eq 'cat ').elems == 1,
        '无 Engine 时命令名补全不变';
    ok !$s.engine.defined, '默认没有会话 Engine';
    $s.set-engine($e);
    ok $s.engine.defined, 'set-engine 注册会话 Engine';
    my @r = $s.completions($tbl, $tbl.chars);
    ok @r.grep({ .contains('sales') }).elems == 1,
        'Session 把 SQL 字符串交给了元数据补全';
    ok $s.completions('c', 1).List.grep(* eq 'cat ').elems == 1,
        '注册 Engine 后命令名补全仍然不变';
    ok $s.completions('help ', 5).List.grep(* eq 'help ls ').elems == 1,
        '注册 Engine 后 help 参数补全仍然不变';
}

# ── 5. DSL.open-db 真实注册链路（可选驱动）───────────────────────────
my $mod = try { require ::('DB::DuckDB') };
my Bool $have = try { $mod.^name eq 'DB::DuckDB' } // False;
if !$have {
    skip 'DB::DuckDB 未安装，跳过 open-db 注册链路', 2;
}
else {
    my $s = Rakuish::REPL::Session.new;
    my $r = $s.eval-line(q{open-db(':memory:')});
    ok $r.ok, 'open-db 在 REPL 里求值成功';
    ok $s.engine.defined, 'DSL.open-db 自动注册当前会话 Engine';
}

# ── 6. 0.71 调用形态：q[...] 与具名参数（ADR-0008 §3.2）──────────────
# 用 heredoc 放测试行，避免 q[...] / 单引号互相嵌套造成引号地狱。
{
    my @forms = q:to/END/.lines;
$db.query(q[select * from sa
$db.query(q{select * from sa
$db.query(q<select * from sa
$db.query(q(select * from sa
$db.query(sql => 'select * from sa
$db.query(:sql('select * from sa
$db.query(q[select * from sales where region = 'east' and am
$db.query(q[select * from saXYZ
$db.query(qq[select * from sa
say(q[select * from sa
$db.query("select * from sa
END
    my ($qb, $qbr, $qa, $qp, $named, $colon,
        $with-quote, $mid, $qq, $say, $dbl) = @forms;
    my @labels = <q-bracket q-brace q-angle q-paren named colon>;
    my @six = ($qb, $qbr, $qa, $qp, $named, $colon);
    for @labels.kv -> $i, $label {
        my Str $line = @six[$i];
        my %c = sql-context($line, $line.chars);
        is %c<frag>, 'sa', "$label 识别当前词 sa";
        is %c<mode>, 'table', "$label 处在表名上下文";
        ok sql-completions($line, $line.chars, :engine($e))
            .grep({ .ends-with('sales') }).elems == 1,
            "$label 返回以 sales 结尾的完整替换行";
    }

    is sql-context($qb, $qb.chars)<quote-style>, 'q',
        'q[...] 的 quote-style 是 q';
    is sql-context($named, $named.chars)<quote-style>, 'single',
        '具名参数仍是单引号字符串';
    is sql-context($dbl, $dbl.chars)<quote-style>, 'double',
        '双引号的 quote-style 是 double';
    ok sql-completions($dbl, $dbl.chars, :engine($e))
        .grep({ .ends-with('sales') }).elems == 1,
        '双引号原行为回归（0.68 形态未被破坏）';

    my %qc = sql-context($with-quote, $with-quote.chars);
    is %qc<frag>, 'am', 'q[...] 内嵌单引号不打断 SQL 上下文';
    ok sql-completions($with-quote, $with-quote.chars, :engine($e))
        .grep({ .ends-with('amount') }).elems == 1,
        'q[...] 内嵌单引号时仍能补列名';

    my Int $pos = $mid.chars - 3;   # 光标停在 sa 之后、XYZ 之前
    ok sql-completions($mid, $pos, :engine($e))
        .grep({ .ends-with('salesXYZ') }).elems == 1,
        'q[...] 光标在行中时仍保留 tail';

    ok !sql-completions($qq, $qq.chars, :engine($e)).elems,
        'qq[...] 明确不在支持形态内';
    ok !sql-completions($say, $say.chars, :engine($e)).elems,
        '非白名单调用不因 q[...] 误触发';
}

done-testing;
