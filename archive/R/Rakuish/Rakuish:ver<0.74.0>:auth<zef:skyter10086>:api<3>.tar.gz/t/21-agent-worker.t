use Test;

# 21-agent-worker.t —— 连接级常驻 worker 与 OS 硬取消（0.67.0 / ADR-0004 §4）
#
# 真实子进程 + 真实 TCP，不做进程内替身。核心卖点：
#   1. 一次连接只启动一次 worker，请求走 stdin/stdout JSONL；
#   2. 卡住的请求由父进程 watchdog kill 整个进程（不只是「响应提前」）；
#   3. 审计集中在父进程且脱敏；新连接不受被 kill 的连接影响。
# 默认不开启 worker，0.63 路径由 t/16 守护。

use JSON::Fast;
use Rakuish::Sandbox;
use Rakuish::Agent::Server;
use Rakuish::Agent::Worker;

my $dir = $*CWD.add('tmp').add('agent-worker-test');
$dir.mkdir unless $dir.e;
$dir.add('a.txt').spurt('hello 中文');

my @cmd = $*EXECUTABLE.Str, $*CWD.add('bin/rakuish-agent').Str, '--worker-child';

sub req(Int $id, Str $op = 'read_file', *%o) {
    to-json({ id => $id, token => 'TOKEN', op => $op,
              path => 'a.txt', |%o }, :!pretty)
}

sub read-reply($c, Int $secs = 15) {
    my $p = start { $c.get };
    await Promise.anyof($p, Promise.in($secs));
    $p.status ~~ Kept ?? $p.result !! Nil;
}

my $sandbox = Rakuish::Sandbox.new(
    :root($dir), :token('TOKEN'),
    :request-timeout-ms(0),      # 子进程不自行 504，交给父进程 watchdog
    :timeout-ms(5000),           # exec 底层 5s，足够让硬取消先到
    :allow-exec, :allowlist(<raku>),
);
my %cfg = worker-config($sandbox, :session-id('worker-test'));

# ── 1. 配置与启动：token 只走 stdin，不进命令行 ───────────────────────
{
    is %cfg<token>, 'TOKEN', 'worker 配置携带 token';
    ok %cfg<__rakuish_worker_config>, '配置带模式标记';
    nok %cfg<audit>:exists, '配置不含审计路径（审计由父进程统一写）';
    nok @cmd.grep({ .Str.contains('TOKEN') }).elems,
        '启动命令行不含 token（不出现在进程列表）';
    is %cfg<root>, $dir.Str, '配置携带 root';
}

# ── 2. 直接转发链路与真实 kill ───────────────────────────────────────
{
    my %w = spawn-worker(@cmd, %cfg);
    ok %w<ready>, 'worker 握手成功（启动成本隔离在连接建立阶段）';
    my %r = worker-request(%w, req(9), :hard-timeout-ms(8000));
    nok %r<timeout>, '直接转发未超时';
    my %resp = from-json(%r<reply>);
    ok %resp<ok>, '直接转发拿到成功响应';
    is %resp<value>, 'hello 中文', '值往返不变';
    kill-worker(%w);
    await Promise.anyof(%w<started>, Promise.in(6));
    ok %w<started>.status ~~ Kept, 'kill 后子进程确实退出（OS 级）';
}

# 非法配置不能悄悄变成可用的 worker
{
    my $p = Proc::Async.new($*EXECUTABLE.Str,
                            $*CWD.add('bin/rakuish-agent').Str,
                            '--worker-child', :w);
    $p.stdout.lines.tap(-> $ { });
    $p.stderr.lines.tap(-> $ { });
    my $started = $p.start;
    $p.say('not-json');
    await Promise.anyof($started, Promise.in(10));
    ok $started.status ~~ Kept, '非法配置时 worker 子进程退出';
    my $code = $started.status ~~ Kept ?? $started.result.exitcode !! -1;
    is $code, 2, '非法配置退出码 2';
}

# worker 缺 command/config 时明确拒绝，不静默回退到进程内模式
{
    my $stop = Promise.new;
    $stop.keep;
    my %i = Rakuish::Agent::Server.new(:sandbox($sandbox)).serve(
        :port(0), :worker, :stop($stop));
    nok %i<ok>, 'worker 缺 command/config 时拒绝启动';
    like %i<err>, /'worker-command'/, '给出明确原因';
}

# ── 3. 真实 TCP：正常请求 → 硬取消 → 新连接不受影响 ────────────────────
my $srv = Rakuish::Agent::Server.new(:sandbox($sandbox),
                                     :session-id('worker-test'));
my $stop = Promise.new;
my $ready = Promise.new;
my $task = start {
    $srv.serve(:port(0), :stop($stop), :worker,
               :worker-command(@cmd), :worker-config(%cfg),
               :worker-hard-timeout-ms(300),
               :max-connections(8), :idle-timeout-ms(3000),
               :on-ready(-> $p { $ready.keep($p) }));
};
await Promise.anyof($ready, Promise.in(6));

if $ready.status !~~ Kept {
    skip 'TCP worker 服务未在 6s 内就绪（平台限制）', 11;
}
else {
    my $port = $ready.result;
    my $c1 = IO::Socket::INET.new(:host<127.0.0.1>, :port($port));
    ok $c1.defined, 'worker 服务可接受连接';

    $c1.say(req(1));
    my $l1 = read-reply($c1);
    if $l1.defined {
        my %r1 = from-json($l1);
        is %r1<id>, 1, '正常请求响应 id 正确';
        is %r1<value>, 'hello 中文', 'worker 子进程读文件往返';
    }
    else { skip 'worker 首个请求响应超时', 2 }

    # 慢 exec：子进程没有 deadline，父进程 watchdog 必须 kill 整个进程。
    $c1.say(req(10, 'exec', argv => ['raku', '-e', 'sleep 2']));
    my $slow = read-reply($c1, 8);
    ok $slow.defined, '卡住的请求有响应（连接没被拖死）';
    if $slow.defined {
        is from-json($slow)<code>, 504, '监督者硬取消返回 504';
    }
    else { skip '硬取消无响应', 1 }

    # kill 后该连接立即关闭（与 0.63「连接继续可用」的差别）
    my $eof = start { $c1.get };
    await Promise.anyof($eof, Promise.in(5));
    ok $eof.status ~~ Kept && !$eof.result.defined,
        'worker 被 kill 后连接随即关闭';
    try $c1.close;

    my $c2 = IO::Socket::INET.new(:host<127.0.0.1>, :port($port));
    ok $c2.defined, '被 kill 的连接不影响 accept loop';
    $c2.say(req(2));
    my $l2 = read-reply($c2);
    if $l2.defined {
        my %r2 = from-json($l2);
        ok %r2<ok>, '新连接的新 worker 正常响应';
        is %r2<value>, 'hello 中文', '新连接值往返';
    }
    else { skip '新连接响应超时', 2 }
    try $c2.close;

    my @audit = $sandbox.entries;
    ok @audit.grep({ .<stage> eq 'timeout' }).elems >= 1,
        '父进程审计记录 stage=timeout';
    ok @audit.grep({ .<session> eq 'worker-test-c2' }).elems >= 1,
        '每连接独立 session 审计';
    nok @audit.grep({
        .keys.grep({ $_ eq 'token' || $_ eq 'content' || $_ eq 'sql' }).elems
    }).elems, '审计不含 token / content / SQL 原文';

    $stop.keep;
    await Promise.anyof($task, Promise.in(8));
    if $task.status ~~ Kept {
        my %i = $task.result;
        ok %i<worker>, 'serve 报告 worker 模式已启用';
        ok %i<worker_killed> >= 1, '统计到被 kill 的 worker';
        ok %i<worker_timeouts> >= 1, '统计到硬取消次数';
    }
    else { skip 'serve 未在 8s 内收尾（平台限制）', 3 }
}

# ── 清理 ─────────────────────────────────────────────────────────────
$dir.add('a.txt').unlink if $dir.add('a.txt').e;
try { $dir.rmdir };

done-testing;
