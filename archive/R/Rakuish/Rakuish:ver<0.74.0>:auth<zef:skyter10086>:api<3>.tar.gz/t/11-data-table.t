use Test;
use JSON::Fast;
use Rakuish::Sys;
use Rakuish::Data;
use Rakuish::Data::Table;

# t/11 —— 结构化数据层：Table / JSON / CSV / ls-table

my $t = Rakuish::Data::Table.from-rows([
    { name => 'b.txt', type => 'file', size => 2 },
    { name => 'a.txt', type => 'file', size => 1 },
    { name => 'sub',   type => 'dir',  size => 0 },
]);

is $t.elems, 3, 'Table 行数';
is $t.columns.List, <name size type>, 'Table 列';
is $t.column-type('size'), 'int', '列类型推断为 int';
is $t.schema.columns.List, <name type nullable>, 'schema 列';
is $t.schema.where({ .<name> eq 'size' }).get('type').List, ('int',),
    'schema 报告 size 类型';
like $t.to-text, /'name'/ && /'a.txt'/, 'Table text 渲染';
like $t.to-markdown, /'| name | size | type |'/, 'Table markdown';
my $json = from-json($t.to-json);
is $json.elems, 3, 'Table JSON 行数';
is $json[1]<name>, 'a.txt', 'Table JSON 内容';

is $t.where({ .<type> eq 'file' }).elems, 2, 'where 过滤';
is $t.where({ .<size> > 1 }).get('name').List, ('b.txt',), 'where + get';
is $t.select('name').columns.List, ('name',), 'select 列';
is $t.sort-by('size').get('name').List, ('sub', 'a.txt', 'b.txt'),
    'sort-by size';
is $t.sort-by('size', :reverse).get('name').List, ('b.txt', 'a.txt', 'sub'),
    'sort-by reverse';
is $t.first(2).elems, 2, 'first';
is $t.last(1).get('name').List, ('sub',), 'last';

is $t.limit(2).elems, 2, 'limit';
is $t.offset(1).get('name').List, ('a.txt', 'sub'), 'offset';
is $t.each({ .<name> }).List, ('b.txt', 'a.txt', 'sub'), 'each';
is $t.count, 3, 'count';
is $t.sum('size'), 3, 'sum';
is $t.mean('size'), 1, 'mean';
is $t.min('size'), 0, 'min';
is $t.max('size'), 2, 'max';
is $t.distinct('type').elems, 2, 'distinct';

my $joined = $t.join(
    Rakuish::Data::Table.from-rows([{ name => 'a.txt', owner => 'alice' }]),
    :on<name>,
);
is $joined.elems, 3, 'left join 行数';
is $joined.where({ .<name> eq 'a.txt' }).get('owner').List, ('alice',),
    'left join 匹配';

# ── CSV ─────────────────────────────────────────────────────────────
my Str $csv = q:to/CSV/;
name,note
a,"x,y"
b,"he said ""hi"""
CSV
my $ct = Rakuish::Data::from-csv-data($csv);
is $ct.elems, 2, 'CSV 行数';
is $ct.get('note').List, ('x,y', 'he said "hi"'), 'CSV 引号/逗号';
my Str $round = Rakuish::Data::to-csv-data($ct);
is Rakuish::Data::from-csv-data($round).get('name').List, ('a', 'b'),
    'CSV 写回可再解析';

# ── open-data / save-data ───────────────────────────────────────────
my $base = $*TMPDIR.IO.add("rakuish-data-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }
my $sys = Rakuish::Sys.new(:root($base), :cwd($base));

$sys.write('x.json', to-json([
    { name => 'a', size => 1 }, { name => 'b', size => 2 },
]));
my $jt = Rakuish::Data::open-data($sys, 'x.json');
isa-ok $jt, Rakuish::Data::Table, 'open .json 对象数组 → Table';
is $jt.elems, 2, 'open json 行数';

Rakuish::Data::save-data($sys, 'y.csv', $jt);
my $back = Rakuish::Data::open-data($sys, 'y.csv');
isa-ok $back, Rakuish::Data::Table, 'open .csv → Table';
is $back.get('name').List, ('a', 'b'), 'save/open csv roundtrip';

Rakuish::Data::save-data($sys, 'z.json', $jt);
is from-json($sys.read('z.json')).elems, 2, 'save json';

# ── ls-table ────────────────────────────────────────────────────────
$base.add('d').mkdir;
$base.add('d/f.txt').spurt('x');
$base.add('a.txt').spurt('a');
my $lt = $sys.ls-table('.', :recursive);
isa-ok $lt, Rakuish::Data::Table, 'ls-table 返回 Table';
ok $lt.columns.List.elems >= 4, 'ls-table 有结构化列';
ok $lt.get('name').List.grep(* eq 'f.txt').elems == 1, 'ls-table 递归含文件';
ok $lt.get('type').List.grep(* eq 'dir').elems >= 1, 'ls-table 识别目录';

done-testing;
