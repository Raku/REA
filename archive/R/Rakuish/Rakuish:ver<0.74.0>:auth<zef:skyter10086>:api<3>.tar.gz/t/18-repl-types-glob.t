use Test;
use Rakuish::Sys;
use Rakuish::REPL::Session;

# 18-repl-types-glob.t —— class/role/grammar 跨格持久 + glob 转义/嵌套 brace
# （0.65.0，SPEC V-124 / V-135 / V-903 / V-904）
#
# 红线：类型持久靠「只重放纯声明」，绝不重放整份历史（V-124 / 审计 P0-1）。

my $base = $*TMPDIR.IO.add("rakuish-types-glob-{$*PID}");
$base.mkdir;
LEAVE {
    try {
        for $base.dir -> $e {
            if $e.d { try { $e.dir>>.unlink; $e.rmdir } }
            else    { try { $e.unlink } }
        }
        $base.rmdir;
    }
}

sub sess(--> Rakuish::REPL::Session) {
    Rakuish::REPL::Session.new(
        sys => Rakuish::Sys.new(:root($base), :cwd($base)))
}

# ── 一、纯类型声明格跨格持久 ─────────────────────────────────────────
my $t = sess();

ok $t.eval-line('class Box { has $.n; method twice { $!n * 2 } }').ok,
    '纯 class 声明格求值成功';
my $c2 = $t.eval-line('Box.new(n=>21).twice');
ok $c2.ok, 'class 跨格可见';
is $c2.value, 42, 'class 方法跨格可用';
# 词法化会带上外层包名（Rakuish::REPL::Session::Box），短名仍可解析；
# 这是不污染 GLOBAL 的代价，见 SPEC V-124。
like $t.eval-line('Box.^name').value, /'Box'/, '词法化后类型短名仍可用';

ok $t.eval-line('role Tag { method tag { "T" } }').ok, 'role 声明格成功';
ok $t.eval-line('class Tagged is Box does Tag { }').ok, '继承 + 组合声明格成功';
is $t.eval-line('Tagged.new(n=>5).twice ~ Tagged.new(n=>5).tag').value,
    '10T', 'role / class 组合跨格可用';

ok $t.eval-line('grammar Digits { token TOP { \d+ } }').ok,
    'grammar 声明格成功';
ok $t.eval-line('Digits.parse("123").Bool').value, 'grammar 跨格可 parse';

# 重定义同名类型：新定义生效，且依赖它的声明顺序不能乱
ok $t.eval-line('class Box { has $.n; method twice { $!n * 3 } }').ok,
    '同名 class 重定义成功';
is $t.eval-line('Box.new(n=>2).twice').value, 6, '重定义后使用新方法';
is $t.eval-line('Tagged.new(n=>2).twice').value, 6,
    '依赖 Box 的 class 仍按原声明顺序可见';

# my 变量与类型声明共存
ok $t.eval-line('my $k = 9;').ok, 'type 会话里的 my 仍可用';
is $t.eval-line('Box.new(n=>$k).twice').value, 27, 'my 与类型声明共存';

# 显式作用域关键字不能把类型装回 GLOBAL
my $ex = sess();
ok $ex.eval-line('my class L { method v { 5 } }').ok, '显式 my class 成功';
is $ex.eval-line('L.new.v').value, 5, '显式 my class 跨格可用';
ok $ex.eval-line('our class G2 { method v { 6 } }').ok,
    'our class 被统一词法化（不污染 GLOBAL）';
is $ex.eval-line('G2.new.v').value, 6, 'our class 跨格可用';

# ── 二、边界：不是历史重放 ───────────────────────────────────────────
my $side = sess();
$side.eval-line('class Side { has $.x }');
$side.eval-line('my $k = 7;');
$side.eval-line('append("log.txt", "x")');
$side.eval-line('Side.new(x=>1)');
is $side.eval-line('read("log.txt")').value, 'x',
    '前置纯声明不重跑上一格 append（V-124 红线）';

my $mix = sess();
ok $mix.eval-line('class Mixed { has $.v }; Mixed.new(v=>1)').ok,
    '混合格当前格可求值';
nok $mix.eval-line('Mixed.new(v=>2)').ok,
    '混合格的类型不缓存（避免把副作用带进后续格）';

my $ph = sess();
ok $ph.eval-line('class Ph { has $.x; BEGIN { } }').ok,
    '含编译期 phaser 的声明格仍可求值';
nok $ph.eval-line('Ph.new(x=>1)').ok,
    '含 phaser 的声明不缓存（避免副作用每格重放）';

my $rb = sess();
ok $rb.eval-line('class Old { method v { 1 } }').ok, '旧声明成功';
nok $rb.eval-line('class Old { method v { ] } }').ok, '语法错误的新声明失败';
is $rb.eval-line('Old.new.v').value, 1, '失败后回滚，旧声明仍可用';

my $su = sess();
$su.eval-line('sub dbl($x) { $x * 2 }');
is $su.eval-line('dbl(4)').value, 8, 'sub 缓存未受影响';
$su.eval-line('use JSON::Fast;');
ok $su.eval-line('to-json({a=>1}).contains("a")').value,
    'use 缓存未受影响';

# ── 三、glob：转义 / 嵌套 brace / 字符集 ────────────────────────────
for <a.txt b.md c.txt x.dat> -> $f { $base.add($f).spurt($f) }
$base.add('{a,b}.txt').spurt('brace');
$base.add('a,b.txt').spurt('comma');
$base.add('a[1].txt').spurt('bracket');
$base.add('sub').mkdir;
$base.add('sub/x.txt').spurt('deep');

my $g = Rakuish::Sys.new(:root($base), :cwd($base));
sub hit(Str $p, Str $f --> Bool) { so $g.glob($p).first({ .basename eq $f }) }
sub cnt(Str $p --> Int)          { $g.glob($p).elems }

ok hit('*.txt', 'a.txt'), '基础 *.txt 仍命中';
nok hit('*.txt', 'x.txt'), '* 不跨目录';
ok hit('{a,b}.md', 'b.md'), '单层 brace';
is cnt('{a,{b,c}}.txt'), 2, '嵌套 brace 展开成 a.txt / c.txt';
ok hit('*.{txt,md}', 'b.md'), '通配符 + brace 组合';
ok hit('[a-c].txt', 'c.txt'), '字符集范围';
nok hit('[a-c].txt', 'x.dat'), '字符集不误命中';

ok hit('\{a,b\}.txt', '{a,b}.txt'), '转义花括号按字面匹配';
is cnt('\{a,b\}.txt'), 1, '转义花括号不再展开';
ok hit('a\[1\].txt', 'a[1].txt'), '转义方括号按字面匹配';
is cnt('\*.txt'), 0, '转义星号不再当通配符';
is cnt('{a,b'), 0, '未闭合 brace 按字面处理';
is cnt('[a\-c].txt'), 2, '字符集里转义的 - 是字面字符';
is cnt('{a\,b,c}.txt'), 2, 'brace 内转义的逗号不切分';

ok hit('sub\x.txt', 'x.txt'), '裸反斜杠仍归一化为路径分隔符';
ok hit('sub\x*.txt', 'x.txt'), '归一化后通配符继续生效';
ok hit('sub\\\\x.txt', 'x.txt'), '双反斜杠归一化后命中深层文件';

# DSL / Shell 薄层的入口
my $sh = sess();
sub out(Str $line --> Str) { $sh.render($sh.eval-line($line)) }

my $dsl = $sh.eval-line(q[glob('\{a,b\}.txt')]);
ok $dsl.ok, 'Raku glob() 可传转义模式';
ok $dsl.value.map(*.basename).grep(* eq '{a,b}.txt').elems == 1,
    'Raku glob() 命中字面花括号文件';

like out('glob {a,{b,c}}.txt'), /'a.txt'/, 'glob 命令支持嵌套 brace';
like out('glob [a-c].txt'), /'c.txt'/, 'glob 命令支持字符集';
is $sh.eval-line('ls {a,b}.txt').op, 'eval',
    '非 glob 命令的花括号参数仍交回 Raku';

# 0.71.5 回归：*.jpg 只扫当前目录，不把子树也走一遍。
my $glob-fast = $base.add('glob-fast');
$glob-fast.mkdir;
$glob-fast.add('a.jpg').spurt('x');
my $glob-deep = $glob-fast.add('deep');
$glob-deep.mkdir;
for ^5 -> $i { $glob-deep.add("f{$i}.jpg").spurt('x') }
LEAVE {
    try { $glob-deep.dir>>.unlink; $glob-deep.rmdir }
    try { $glob-fast.add('a.jpg').unlink; $glob-fast.rmdir }
}
my $fast-sys = Rakuish::Sys.new(
    :root($glob-fast), :cwd($glob-fast), :max-entries(2));
my $fast-hits = try { $fast-sys.glob('*.jpg') };
ok $fast-hits.defined, '普通 glob 不因深层子目录超限';
is $fast-hits.elems, 1, '*.jpg 只命中当前目录';
is $fast-hits[0].basename, 'a.jpg', '当前目录的 jpg 正确返回';

# ── 0.69.1 回归：失败格不得污染 stderr ──────────────────────────────
# 混合格 / 带 phaser 的声明不缓存后，下一格引用未声明类型会走编译期异常。
# 曾因异常对象内部字符串化未定义值，在 zef test / REPL 的 stderr 打出
# "Use of uninitialized value of type Any in string context"。
my $probe = q:to/PROBE/;
    use Rakuish::REPL::Session;
    my $s = Rakuish::REPL::Session.new;
    $s.eval-line('class Mixed { has $.v }; Mixed.new(v=>1)');
    $s.eval-line('Mixed.new(v=>2)');
    $s.eval-line('class Ph { has $.x; BEGIN { } }');
    $s.eval-line('Ph.new(x=>1)');
    PROBE
my $child = run($*EXECUTABLE.Str, '-Ilib', '-e', $probe, :out, :err);
my $child-out = $child.out.slurp(:close);
my $child-err = $child.err.slurp(:close);
nok $child-err.contains('uninitialized value'),
    '失败格不在 stderr 打印未初始化值警告';
ok $child.exitcode == 0, '失败格子进程正常结束';

done-testing;
