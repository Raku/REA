use Test;
use JSON::Fast;
use Rakuish::Sandbox;
use Rakuish::Agent;
use Rakuish::Agent::Server;
use Rakuish::Data::Table;

# Phase 4 · Sandbox / 类型化 Agent / JSONL + TCP（设计 §6、ADR 决策 5）
# 重点都是反向断言：默认拒绝、越界拦截、上限不可调大、审计不泄密。

my $base  = $*TMPDIR.IO.add("v3-agent-t-{$*PID}");
$base.mkdir;
my Str $token = 'test-token-123';
my Str $EXE   = $*EXECUTABLE.Str;

sub sbx(*%o) { Rakuish::Sandbox.new(:root($base), :token($token), |%o) }
sub ag($s, :$engine, Str :$id = 's1') {
    Rakuish::Agent.new(:sandbox($s), :session-id($id), :$engine)
}
sub call($a, *%req) {
    from-json($a.handle-line(to-json({ token => $token, |%req }, :!pretty)))
}

my class FakeEngine {
    method query(Str $sql, *@params, Int :$max-rows --> Rakuish::Data::Table) {
        my @rows = [
            { n => 1, sql => $sql },
            { n => 2, sql => $sql },
            { n => 3, sql => $sql },
        ];
        Rakuish::Data::Table.from-rows(
            $max-rows.defined ?? @rows.head($max-rows).List !! @rows);
    }
}

my class SlowEngine {
    method query(Str $sql, *@params, Int :$max-rows --> Rakuish::Data::Table) {
        sleep 0.15;
        Rakuish::Data::Table.from-rows([{ n => 1 }]);
    }
}

# ── Sandbox 默认值 ───────────────────────────────────────────────────
my $s = sbx();
is $s.host, '127.0.0.1', '默认只绑 127.0.0.1';
ok $s.root.is-absolute, 'root 被绝对化';
is $s.token, $token, '显式 token 生效';
is $s.token.chars, 14, 'token 长度';
nok $s.allow-exec, 'exec 默认关闭（ADR 决策 5）';
is $s.max-bytes, 1048576, '读写默认 1 MiB';
is $s.timeout-ms, 30000, '超时默认 30s';
is $s.max-output, 1048576, '输出默认 1 MiB';
ok $s.op-allowed('read_file'), 'read_file 在白名单';
ok $s.op-allowed('exec'), 'exec 是一个 op（但默认被策略拒绝）';
ok $s.op-allowed('sql_query'), 'sql_query 是一个 op（但默认关闭）';
nok $s.allow-sql, 'sql_query 默认关闭';
is $s.authorize('sql_query', { sql => 'select 1' }).code, 403,
    '未 --allow-sql 时 sql_query 403';
nok $s.op-allowed('eval'), 'eval 不开放（任意代码会绕过沙箱）';
nok $s.op-allowed('rm -rf'), '任意 op 不在白名单';

my $auto = Rakuish::Sandbox.new(:root($base));
is $auto.token.chars, 64, '未指定时生成 64 位 hex token';
nok $auto.token eq $token, '生成值不是硬编码';
is $auto.summary<host>, '127.0.0.1', 'summary 可序列化';
is $auto.summary<token>, '<redacted>', 'summary 不回显 token';
is $auto.token.chars, 64, '默认 token 是 64 位 hex（OS CSPRNG）';

my $cap-sb = Rakuish::Sandbox.new(:root($base), :max-audit-entries(2));
$cap-sb.audit({ op => 'a' });
$cap-sb.audit({ op => 'b' });
$cap-sb.audit({ op => 'c' });
is $cap-sb.entries.elems, 2, '审计内存条目有上限';
is $cap-sb.entries[1]<op>, 'c', '保留最新审计条目';

is $s.clamp-bytes(10), 10, '调小上限生效';
is $s.clamp-bytes(99999999), 1048576, '调大上限被钳住';
is $s.clamp-timeout(99), 99, '调小超时生效';
is $s.clamp-timeout(99999999), 30000, '超时不可调大';
is $s.clamp-output(512), 512, '输出上限可下调';

# ── authorize：exec 的三道门 ────────────────────────────────────────
is $s.authorize('exec', { argv => [$EXE, '-e', 'say 1'] }).code, 403,
    'exec 默认 403（未开启）';
my $on = sbx(:allow-exec, :allowlist($EXE, 'git'));
ok $on.authorize('exec', { argv => [$EXE, '-e', 'say 1'] }).ok,
    '显式开启 + 白名单内绝对路径放行';
is $on.authorize('exec', { argv => ['rm', '-rf'] }).code, 403,
    '白名单外命令拒绝';
is $on.authorize('exec', { argv => ['x'] }).code, 403,
    '白名单外命令拒绝（短名）';
is $on.authorize('exec', { argv => 'not-an-array' }).code, 400,
    'argv 不是数组 → 400';
is $on.authorize('unknown', {}).code, 403, '未知 op 拒绝';

my $win-name = sbx(:allow-exec, :allowlist('raku.exe'));
nok $win-name.exe-allowed('C:/tools/raku.exe'),
    '裸名白名单不能放行任意绝对路径（防 basename 冒充）';
ok $win-name.exe-allowed('raku.exe'), '裸名白名单匹配裸命令名';
my $abs-only = sbx(:allow-exec, :allowlist($EXE));
ok $abs-only.exe-allowed($EXE), '绝对路径白名单精确匹配';
nok $abs-only.exe-allowed($EXE.IO.basename.Str), '绝对路径白名单不接受裸名';

# ── 审计：内存 + JSONL 单行 ──────────────────────────────────────────
my $audit-file = $base.add('audit.jsonl');
my $as = Rakuish::Sandbox.new(:root($base), :token($token),
                                  :audit-log($audit-file));
$as.audit({ op => 'read_file', path => 'a.txt', ok => True, code => 0 });
$as.audit({ op => 'exec', argv => ['git', 'status'], ok => False, code => 403 });
is $as.entries.elems, 2, '审计内存记录 2 条';
ok $as.entries[0]<ts>.chars > 0, '审计带时间戳';
my @audit-lines = $audit-file.slurp.lines;
is @audit-lines.elems, 2, 'JSONL 每行一条（:!pretty 生效）';
my %a0 = from-json(@audit-lines[0]);
is %a0<op>, 'read_file', 'JSONL 可解析且 op 正确';
my %a1 = from-json(@audit-lines[1]);
is %a1<argv>[0], 'git', 'JSONL 记录 argv';

# 并发审计：共享 Sandbox 时 entries 不能丢行/写坏结构。
my $concurrent-audit = sbx();
my @audit-jobs = (^50).map: -> $i {
    start { $concurrent-audit.audit({ op => "c{$i}" }) }
};
await @audit-jobs;
is $concurrent-audit.entries.elems, 50, '并发审计条目数正确';

# ── Agent：认证 / op 白名单 / 坏 JSON ────────────────────────────────
my $a = ag($s);
my %no-token = from-json($a.handle-line(to-json({ id => 1, op => 'ls' }, :!pretty)));
is %no-token<code>, 401, '缺 token → 401';
nok %no-token<ok>, '缺 token 失败';
my %bad-token = call($a, :id(2), :op<ls>, :token('wrong'));
is %bad-token<code>, 401, '错 token → 401';
my %bad-op = call($a, :id(3), :op<eval>, :code('say 1'));
is %bad-op<code>, 403, 'eval 被拒（不执行任意代码）';
my %bad-json = from-json($a.handle-line('{not json'));
is %bad-json<code>, 400, '坏 JSON → 400';
ok %bad-json<err>.chars > 0, '坏 JSON 有错误说明';

# ── 类型化 op 往返 ───────────────────────────────────────────────────
my %w = call($a, :id(10), :op<write_file>, :path<a.txt>, :content('中文 hello'));
ok %w<ok>, 'write_file 成功';
is %w<value><bytes>, 12, 'write_file 返回字节数（中文 UTF-8 3 字节/字）';
ok %w<value><path>.contains('a.txt'), 'write_file 返回路径';
nok %w<value><path>.contains('\\'), '响应路径统一用 / 分隔';

my %r = call($a, :id(11), :op<read_file>, :path<a.txt>);
is %r<value>, '中文 hello', 'read_file 中文往返';
my %short = call($a, :id(12), :op<read_file>, :path<a.txt>, :offset(3), :limit(5));
is %short<value>, 'hello', 'read_file offset/limit 生效';
my %bin = call($a, :id(13), :op<read_file>, :path<a.txt>, :binary(True));
ok %bin<value> ~~ Positional, 'binary 读返回字节数组';
ok %bin<value>.elems > 0, 'binary 有内容';

my %ls = call($a, :id(14), :op<list_dir>, :path<.>);
ok %ls<ok>, 'list_dir 成功';
ok %ls<value>.elems >= 1, 'list_dir 返回条目';
my %st = call($a, :id(15), :op<stat>, :path<a.txt>);
is %st<value><type>, 'file', 'stat 返回类型化结果';
is %st<value><size>, 12, 'stat 大小';
my %gl = call($a, :id(16), :op<glob>, :pattern('*.txt'));
ok %gl<value>.grep(*.contains('a.txt')).elems >= 1, 'glob 命中';

my %no-path = call($a, :id(17), :op<read_file>);
nok %no-path<ok>, '缺 path 被拒';
is %no-path<code>, 500, '参数错误收敛为 500';

# ── 上限：读 / 写都不可绕过 ─────────────────────────────────────────
my %big = call($a, :id(20), :op<read_file>, :path<a.txt>, :max_bytes(3));
nok %big<ok>, '读超过 max_bytes 失败';
ok %big<err>.contains('读取超限') || %big<err>.contains('超限'), '错误信息含超限原因';
my %bigw = call($a, :id(21), :op<write_file>, :path<big.txt>,
                :content('x' x 200), :max_bytes(4));
nok %bigw<ok>, '写超过 max_bytes 失败';
nok $base.add('big.txt').e, '超限写入没有落盘';

# ── root 越界 ────────────────────────────────────────────────────────
my %esc = call($a, :id(25), :op<read_file>, :path('../etc/passwd'));
nok %esc<ok>, '../ 越界被拒';
is %esc<code>, 500, '越界收敛为 500';
ok %esc<err>.contains('root'), '越界错误说明 root';

# ── exec：默认拒绝 / 白名单 / Result 透传 / 注入防护 ─────────────────
my %off = call($a, :id(30), :op<exec>, :argv([$EXE, '-e', 'say 1']));
is %off<code>, 403, 'exec 默认拒绝';
ok %off<err>.contains('--allow-exec'), '提示显式开启';

my $a2 = ag(sbx(:allow-exec, :allowlist($EXE)));
my %ex = call($a2, :id(31), :op<exec>,
              :argv([$EXE, '-e', 'say "proc-ok 中文"']));
ok %ex<ok>, '开启后白名单命令可执行';
is %ex<out>.trim, 'proc-ok 中文', 'exec 的 out 未被外层 Result 吞掉';
ok %ex<value>.defined, 'exec 保留审计 value';

my %inject = call($a2, :id(32), :op<exec>,
                  :argv([$EXE, '-e', 'say @*ARGS.raku', '$(echo pwned)', 'a|b', 'x y']));
ok %inject<ok>, '注入串作为普通参数执行';
ok %inject<out>.contains('$(echo pwned)'), '$() 原样传入不被解释';
ok %inject<out>.contains('a|b'), '| 原样传入不被解释';
ok %inject<out>.contains('x y'), '带空格的参数原样保留';

my %deny = call($a2, :id(33), :op<exec>, :argv(['definitely-not-allowed', 'x']));
is %deny<code>, 403, '白名单外 exe 被拒';

# ── sql_query：默认关闭 / 只读 / 行数上限 ───────────────────────────
my %sqoff = call($a, :id(35), :op<sql_query>, :sql('select 1'));
is %sqoff<code>, 403, '未 --allow-sql 时 sql_query 403';

my $sql-sbx = sbx(:allow-sql, :max-rows(2));
my $sql-agent = ag($sql-sbx, :engine(FakeEngine.new));
my %sq = call($sql-agent, :id(36), :op<sql_query>, :sql('select n'), :params([]));
ok %sq<ok>, 'allow-sql + engine 时 sql_query 成功';
is %sq<value>.elems, 2, 'sql_query 结果受 max-rows 限制';
is %sq<value>[0]<sql>, 'select n', 'sql 原样传给引擎';
my %sqaudit = $sql-sbx.entries[*-1];
ok %sqaudit<sql-fingerprint>.chars, '审计记录 SQL 指纹';
nok %sqaudit<sql-fingerprint> eq 'select n', '审计不含 SQL 原文';
is %sqaudit<sql-params>, 0, '审计只记参数个数';

my %sqno = call(ag(sbx(:allow-sql)), :id(37), :op<sql_query>, :sql('select 1'));
nok %sqno<ok>, '没有 engine 时 sql_query 失败';
is %sqno<code>, 500, '没有 engine 收敛为 500';

my $slow-sbx = sbx(:allow-sql, :request-timeout-ms(20));
my $slow-agent = ag($slow-sbx, :engine(SlowEngine.new));
my %slow = call($slow-agent, :id(38), :op<sql_query>, :sql('select 1'));
nok %slow<ok>, '超过 request deadline 不返回成功';
is %slow<code>, 504, 'request timeout 返回 504';
is $slow-sbx.entries[*-1]<stage>, 'timeout', '审计标记 timeout';

my %to = call($a2, :id(34), :op<exec>,
              :argv([$EXE, '-e', 'sleep 20']), :timeout_ms(400));
nok %to<ok>, '超时命令失败';
ok %to<err>.chars >= 0, '超时有结构化响应';

my %cwd-escape = call($a2, :id(35), :op<exec>,
                      :argv([$EXE, '-e', 'say 1']), :cwd('../../etc'));
nok %cwd-escape<ok>, 'exec cwd 越界被 root 校验拦下';

my %path-hijack = call($a2, :id(36), :op<exec>,
                       :argv([$EXE, '-e', 'say 1']),
                       :env({ PATH => '/tmp/evil' }));
nok %path-hijack<ok>, '请求级 env 覆盖 PATH 被拒（防白名单劫持）';

my %ld-hijack = call($a2, :id(36), :op<exec>,
                     :argv([$EXE, '-e', 'say %*ENV<LD_PRELOAD> // "none"']),
                     :env({ LD_PRELOAD => '/tmp/evil.so' }));
nok %ld-hijack<ok>, '请求级 env 注入 LD_PRELOAD 被拒';
is %ld-hijack<code>, 403, '危险 env 返回 403';

my %safe-env = call($a2, :id(36), :op<exec>,
                    :argv([$EXE, '-e', 'say %*ENV<LANG> // "none"']),
                    :env({ LANG => 'C.UTF-8' }));
ok %safe-env<ok>, '安全 env（LANG）仍可透传';
is %safe-env<out>.trim, 'C.UTF-8', 'LANG 真的传给了子进程';

my %clip = call($a2, :id(37), :op<exec>,
                :argv([$EXE, '-e', 'say "x" x 100']), :max_output(10));
ok %clip<ok>, '大输出命令仍执行成功';
ok %clip<out>.chars <= 10, '输出被 max_output 裁剪';

# ── 每会话一个 Sys：cwd / 文件互不影响 ─�────────────────────────────
my $s3 = sbx();
$a = ag($s3, :id('A'));
my $b = ag($s3, :id('B'));
call($a, :id(40), :op<mkdir>, :path<onlyA>);
my %lsb = call($b, :id(41), :op<list_dir>, :path<.>);
ok %lsb<ok>, 'B 会话可列目录';
my %cdA = call($a, :id(42), :op<write_file>, :path<onlyA/a.txt>, :content('A'));
ok %cdA<ok>, 'A 会话写入子目录';
ok $a.sys.cwd.Str eq $b.sys.cwd.Str, '两个会话 cwd 互不污染';
is $a.session-id, 'A', '会话 id 独立';
is $b.session-id, 'B', '会话 id 独立';

# ── 审计不泄密 ───────────────────────────────────────────────────────
# 用 $s：它经历了全部请求（含 401 / 403），$s3 只有 A/B 会话的 3 条正常 op。
my $audit-json = to-json($s.entries, :!pretty);
nok $audit-json.contains($token), '审计不含 token';
nok $audit-json.contains('中文 hello'), '审计不含文件内容';
ok $s.entries.elems > 5, '审计记录了多次请求';
ok $s.entries.grep(*<stage> eq 'auth').elems >= 1, '认证失败也进审计';
ok $s.entries.grep(*<stage> eq 'policy').elems >= 1, '策略拒绝也进审计';

# ── Server：JSONL 端到端 ─────────────────────────────────────────────
my $srv = Rakuish::Agent::Server.new(:sandbox(sbx()), :session-id('pipe'));
my $in-file  = $base.add('in.jsonl');
my $out-file = $base.add('out.jsonl');
$in-file.spurt(
    to-json({ id => 50, token => $token, op => 'write_file',
              path => 'pipe.txt', content => 'pipe 中文' }, :!pretty) ~ "\n"
  ~ to-json({ id => 51, token => $token, op => 'read_file',
              path => 'pipe.txt' }, :!pretty) ~ "\n");
my $fi = $in-file.open;
my $fo = $out-file.open(:w);
my $n = $srv.run-jsonl($fi, $fo);
$fi.close;
$fo.close;
is $n, 2, 'run-jsonl 处理 2 行';
my @out = $out-file.slurp.lines;
is @out.elems, 2, '输出 2 行 JSONL';
my %o1 = from-json(@out[1]);
is %o1<value>, 'pipe 中文', 'JSONL 端到端中文往返';

my $listener = $srv.listen(:port(0));
is $listener.localhost.Str, '127.0.0.1', 'listen 只绑 127.0.0.1';
$listener.close;

# ── Server：TCP 真往返（带超时护栏，平台不支持则如实 skip）────────────
my $tcp-sbx = sbx();
my $tcp-srv = Rakuish::Agent::Server.new(:sandbox($tcp-sbx));
my $ready = Promise.new;
my $task = start {
    $tcp-srv.serve-once(:on-ready(-> $p { $ready.keep($p) }));
};
await Promise.anyof($ready, Promise.in(5));
if $ready.status ~~ Kept {
    my $client = IO::Socket::INET.new(:host<127.0.0.1>, :port($ready.result));
    $client.say(to-json({ id => 60, token => $token,
                          op => 'list_dir', path => '.' }, :!pretty));
    my %resp = from-json($client.get);
    is %resp<id>, 60, 'TCP 往返保留 id';
    ok %resp<ok>, 'TCP 往返成功';
    nok %resp<value>.grep(*.contains('\\')).elems, 'TCP 响应路径也统一 /';
    $client.close;
    await Promise.anyof($task, Promise.in(8));
    if $task.status ~~ Kept {
        is $task.result<host>, '127.0.0.1', 'serve-once 报告绑定地址';
        ok $task.result<lines> >= 1, 'serve-once 处理了请求';
    }
    else { skip 'TCP server 未在 8s 内收尾（平台限制）', 2 }
}
else {
    skip 'TCP 未在 5s 内就绪（平台限制）', 5;
}

# ── serve-once idle timeout：连接后不发请求，也必须收尾 ───────────────
my $idle-srv = Rakuish::Agent::Server.new(:sandbox(sbx()));
my $idle-ready = Promise.new;
my $idle-task = start {
    $idle-srv.serve-once(:idle-timeout-ms(300),
                         :on-ready(-> $p { $idle-ready.keep($p) }));
};
await Promise.anyof($idle-ready, Promise.in(5));
if $idle-ready.status ~~ Kept {
    my $client = IO::Socket::INET.new(
        :host<127.0.0.1>, :port($idle-ready.result));
    await Promise.anyof($idle-task, Promise.in(3));
    ok $idle-task.status ~~ Kept, 'idle timeout 后 server 收尾';
    ok $idle-task.result<timed_out>, '结果标记 timed_out';
    is $idle-task.result<lines>, 0, 'idle 超时没有处理请求';
    $client.close;
}
else {
    skip 'idle timeout 测试未就绪（平台限制）', 3;
}

# ── 清理 ─────────────────────────────────────────────────────────────
for <a.txt big.txt pipe.txt in.jsonl out.jsonl audit.jsonl> -> $f {
    $base.add($f).unlink if $base.add($f).e;
}
$base.add('onlyA').add('a.txt').unlink if $base.add('onlyA').add('a.txt').e;
$base.add('onlyA').rmdir if $base.add('onlyA').d;
try { $base.rmdir };

done-testing;
