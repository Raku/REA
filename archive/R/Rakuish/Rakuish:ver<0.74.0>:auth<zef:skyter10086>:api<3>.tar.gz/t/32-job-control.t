#!/usr/bin/env raku
use lib 'lib';
use Test;

# 32-job-control.t —— `tty-exec` 的 POSIX 进程组交接（0.73.0 / SPEC V-175 / ADR-0010）。
#
# 为什么必须在真 controlling terminal 里测：进程组交接依赖 tcsetpgrp，
# 而 tcsetpgrp 只对「调用者所在会话的控制终端」有效；pty.openpty 造出来的
# slave 不是 controlling terminal（TIOCGPGRP 直接 ENOTTY）。所以驱动用
# pty.fork()，让被测进程成为 session leader 并持有 ctty。
#
# 覆盖：自成一组 / 拿到前台 / 退出码映射 / 信号码映射 / cwd 动作 /
# 子进程 kill(0) 不波及宿主 / Ctrl-C 只打前台子进程组 / 返回后前台收回。
#
# Windows 无 POSIX 进程组，整段 skip（那条路径由 t/26 的非 TTY 守卫覆盖）。

my Bool $posix-ok = !$*DISTRO.is-win;
my Str $py = '';
if $posix-ok {
    my $probe = try {
        my $p = run('python3', '-c', 'import pty, os; print("ok")', :out, :err);
        $p.out.slurp(:close).trim
    };
    $py = ($probe // '');
}

if $posix-ok && $py eq 'ok' {

    my IO::Path $tmp = $*CWD.add('tmp');
    $tmp.mkdir unless $tmp.e;
    my Str $tag = $*PID.Str;
    my $probe  = $tmp.add("jobctl-probe-{$tag}.raku");
    my $driver = $tmp.add("jobctl-driver-{$tag}.py");

    $probe.spurt(q:to/PROBE/);
        use Rakuish::Sys;

        my $sys = Rakuish::Sys.new(:root($*TMPDIR), :cwd($*CWD));

        # 场景 1：子进程应自成一组，并且拿到终端前台。
        # tpgid 是「该 tty 的前台进程组」——等于自己的 pgid 才说明真的在前台。
        my $r1 = $sys.proc.tty-exec('/bin/sh', '-c',
            'echo "PROBE child pid=$$ pgid=$(ps -o pgid= -p $$ | tr -d \' \') tpgid=$(ps -o tpgid= -p $$ | tr -d \' \')"');
        say "PROBE s1 code={$r1.code} jc={$r1.value<job-control>.Int} fg={$r1.value<fg-restored>.Int}";
        my Bool $back = Rakuish::Sys::PosixSpawn::foreground-of(0)
                        == Rakuish::Sys::PosixSpawn::group-of(0);
        say "PROBE fg-back {$back.Int}";

        # 场景 2：退出码映射。
        my $r2 = $sys.proc.tty-exec('/bin/sh', '-c', 'exit 7');
        say "PROBE s2 code={$r2.code} sig={$r2.value<signal>} ok={$r2.ok.Int}";

        # 场景 3：信号终止 → code = 128 + sig。
        my $r3 = $sys.proc.tty-exec('/bin/sh', '-c', 'kill -TERM $$');
        say "PROBE s3 code={$r3.code} sig={$r3.value<signal>}";

        # 场景 4：cwd 动作（与当前目录不同，走 addchdir 分支）。
        my $cwd-file = "/tmp/rakuish-jc-cwd-{$*PID}.txt";
        my $r4 = $sys.proc.tty-exec('/bin/sh', '-c', "pwd > {$cwd-file}",
                                    :cwd('/tmp'.IO));
        my Str $got-cwd = $cwd-file.IO.e ?? $cwd-file.IO.slurp.trim !! 'MISSING';
        $cwd-file.IO.unlink if $cwd-file.IO.e;
        say "PROBE s4 code={$r4.code} cwd={$got-cwd}";

        # 场景 5：子进程对**自己所在进程组**发 SIGTERM。
        # 0.72.x（父子同组）会把宿主 REPL 一起打死；切组后父进程必须存活。
        my $r5 = $sys.proc.tty-exec('/bin/sh', '-c', 'sleep 0.2; kill -TERM 0');
        say "PROBE s5 code={$r5.code} sig={$r5.value<signal>}";

        # 场景 6：Ctrl-C 只投递给前台子进程组。
        # 先让子进程确认「已经在前台」再通知驱动发键，避开 spawn 与
        # tcsetpgrp 之间的微秒级窗口（那窗口由内部的 SIGINT tap 兜住）。
        say "READY-CTRLC";
        $*OUT.flush;
        my $r6 = $sys.proc.tty-exec('/bin/sh', '-c',
            'sleep 0.3; echo FG-READY; sleep 30');
        say "PROBE s6 code={$r6.code} sig={$r6.value<signal>}";

        say "DONE";
        $*OUT.flush;
        PROBE

    $driver.spurt(q:to/PYTHON/);
        import os, pty, select, signal, sys, time

        root, raku, script = sys.argv[1], sys.argv[2], sys.argv[3]
        os.chdir(root)

        pid, master = pty.fork()
        if pid == 0:
            os.execv(raku, [raku, '-Ilib', script])

        buf = bytearray()

        def pump(seconds):
            end = time.time() + seconds
            while time.time() < end:
                readable, _, _ = select.select([master], [], [], 0.08)
                if not readable:
                    continue
                try:
                    data = os.read(master, 65536)
                except OSError:
                    return
                if not data:
                    return
                buf.extend(data)
                end = max(end, time.time() + 0.15)

        def wait_for(marker, timeout):
            deadline = time.time() + timeout
            while time.time() < deadline:
                if marker in buf:
                    return True
                pump(0.3)
            return False

        wait_for(b'FG-READY', 40)
        pump(0.4)                      # 余量：让 tcsetpgrp 完成
        try:
            os.write(master, b'\x03')  # 真终端：行规程 -> SIGINT 给前台组
        except OSError:
            pass

        wait_for(b'DONE', 25)
        pump(0.3)

        text = buf.decode('utf-8', 'replace')
        for line in text.splitlines():
            stripped = line.strip()
            if 'PROBE' in stripped:
                print(stripped[stripped.index('PROBE'):])
        print('PROBE done %d' % (1 if b'DONE' in buf else 0))

        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            os.close(master)
        except OSError:
            pass
        PYTHON

    my $ran = try {
        my $p = run('python3', $driver.Str, $*CWD.Str, $*EXECUTABLE.Str,
                    $probe.relative($*CWD).Str, :out, :err);
        ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
    };
    my Str $text = $ran // '';
    # 行格式是 `PROBE <key> <k=v k=v ...>`：第一个词是键，**其余整体**是值。
    # 直接 split('=') 会把 `s1 code` 当成键（踩过）。
    my %p;
    for $text.lines -> $line {
        next unless $line.starts-with('PROBE ');
        my @parts = $line.substr(6).split(' ', 2);
        %p{@parts[0]} = (@parts[1] // '');
    }

    is %p<done>, '1', '真 PTY：整段探针跑完（宿主全程存活）';

    # ── 场景 1：自成一组 + 拿到前台 ──
    is %p<s1>, 'code=0 jc=1 fg=1',
        '场景 1：退出码 0，value<job-control> 与 fg-restored 均为真';
    my %child;
    for (%p<child> // '').split(' ') -> $tok {
        next unless $tok.contains('=');
        my @kv = $tok.split('=', 2);
        %child{@kv[0]} = @kv[1];
    }
    ok %child<pid>.defined && %child<pgid>.defined && %child<tpgid>.defined,
        '场景 1：子进程报告了 pid / pgid / tpgid';
    is %child<pgid>, %child<pid>, '场景 1：子进程自成一组（pgid == pid）';
    is %child<tpgid>, %child<pgid>, '场景 1：子进程拿到终端前台（tpgid == pgid）';
    is %p<fg-back>, '1', '场景 1：返回后宿主重新成为前台进程组';

    # ── 场景 2 / 3：状态映射 ──
    is %p<s2>, 'code=7 sig=0 ok=0', '场景 2：exit 7 原样回传、ok 为假';
    is %p<s3>, 'code=143 sig=15', '场景 3：被 SIGTERM 打死 → code = 128 + 15';

    # ── 场景 4：cwd ──
    is %p<s4>, 'code=0 cwd=/tmp', '场景 4：spawn 时切换 cwd 生效';

    # ── 场景 5：组信号隔离 ──
    is %p<s5>, 'code=143 sig=15', '场景 5：子进程 kill(0,SIGTERM) 打死的是它自己';

    # ── 场景 6：Ctrl-C 归属 ──
    # 能走到 s6 说明场景 5 的组信号没带走宿主，所以这一条同时覆盖两件事。
    is %p<s6>, 'code=130 sig=2', '场景 5/6：宿主存活，且 Ctrl-C 只投递给前台子进程组';

    try { .unlink for ($probe, $driver) };
}
else {
    skip 'Windows / 无 POSIX 进程组：job control 为 POSIX-only（ADR-0010 §3）', 11;
}

done-testing;
