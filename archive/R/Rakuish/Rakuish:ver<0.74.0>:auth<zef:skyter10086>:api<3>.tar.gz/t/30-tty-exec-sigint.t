#!/usr/bin/env raku
use lib 'lib';
use Test;

# 30-tty-exec-sigint.t —— `tty-exec` 期间 Ctrl-C 的归属契约
# （0.72.3 / ADR-0009 / SPEC V-173）。
#
# 0.73.0 起这里改用 `pty.fork()` + 写 `\x03`：它是**真的 controlling
# terminal**（setsid + TIOCSCTTY），行规程会把 `\x03` 解释成 SIGINT 并投递给
# **前台进程组** —— 也就是 tty-exec 期间那个独立子进程组（V-175 / ADR-0010）。
# 之前的写法是 openpty + Popen + killpg(父进程组) 的**模拟**：父子同组时凑巧
# 等价，切组后信号就打不到子进程了，所以必须换成真实路径。
# 实测依据：tty-exec 期间子进程读到的是 canonical（ISIG=1 ICANON=1 ECHO=1），
# 行编辑器在 prompt() 返回时已经 leave-raw-mode，所以 `\x03` 有效。
#
# Windows 无 pty 模块，整段 skip（非 TTY 守卫由 t/26 覆盖）。

my Bool $pty-ok = !$*DISTRO.is-win;
my Str $py = '';
if $pty-ok {
    my $probe = try {
        my $p = run('python3', '-c', 'import pty, termios; print("ok")', :out, :err);
        $p.out.slurp(:close).trim
    };
    $py = ($probe // '');
}

if $pty-ok && $py eq 'ok' {

    my IO::Path $tmp = $*CWD.add('tmp');
    $tmp.mkdir unless $tmp.e;
    my Str $tag = $*PID.Str;
    my $child  = $tmp.add("sigint-child-{$tag}.raku");
    my $driver = $tmp.add("sigint-driver-{$tag}.py");

    $child.spurt(q:to/CHILD/);
        say 'NESTED-READY tty=' ~ $*IN.t;
        signal(SIGINT).tap(-> $ { say 'NESTED-SIGINT'; exit 130 });
        loop {
            my $l = $*IN.get;
            last unless $l.defined;
            last if $l.trim eq 'exit';
            say "NESTED-GOT[{$l.trim}]";
        }
        say 'NESTED-BYE';
        CHILD

    # 驱动只往 stdout 打 PROBE 行；PTY 的原始字节留在内存里判定。
    $driver.spurt(q:to/PYTHON/);
        import fcntl, os, pty, re, select, signal, struct
        import sys, termios, time

        root, raku, child_rel = sys.argv[1], sys.argv[2], sys.argv[3]
        home = '/tmp/rakuish-sigint-%d' % os.getpid()
        os.makedirs(home, exist_ok=True)
        env = os.environ.copy()
        env.update(
            RAKUISH_CONFIG=home + '/config.json',
            TERM='xterm-256color',
            LANG='C.UTF-8',
            PATH=os.path.dirname(raku) + ':' + env.get('PATH', ''),
        )

        # pty.fork 让子进程成为 session leader 并持有 controlling terminal；
        # 这是 tcsetpgrp / 前台进程组语义成立的前提，也是 \x03 能变成信号的前提。
        os.chdir(root)
        pid, master = pty.fork()
        if pid == 0:
            os.execve(raku, [raku, '-Ilib', 'bin/rakuish'], env)
        fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack('HHHH', 24, 110, 0, 0))

        exit_state = {'code': None}

        def poll():
            if exit_state['code'] is not None:
                return exit_state['code']
            wpid, status = os.waitpid(pid, os.WNOHANG)
            if wpid == 0:
                return None
            try:
                exit_state['code'] = os.waitstatus_to_exitcode(status)
            except ValueError:
                exit_state['code'] = -1
            return exit_state['code']

        raw = bytearray()
        esc = b''
        size_pending = False
        dsr_count = 0
        deadline = time.time() + 90
        probe = {}

        def feed(data):
            global esc, size_pending, dsr_count
            for byte in data:
                esc += bytes((byte,))
                if len(esc) > 24:
                    esc = esc[-24:]
                if esc.endswith(b'\x1b[9999;9999H'):
                    size_pending = True
                elif esc.endswith(b'\x1b[6n'):
                    dsr_count += 1
                    os.write(master, b'\x1b[24;110R' if size_pending else b'\x1b[1;1R')
                    size_pending = False
                    esc = b''

        def pump(seconds):
            end = time.time() + seconds
            while time.time() < end and time.time() < deadline:
                readable, _, _ = select.select([master], [], [], 0.08)
                if not readable:
                    continue
                try:
                    data = os.read(master, 65536)
                except OSError:
                    break
                if not data:
                    break
                raw.extend(data)
                feed(data)
                end = max(end, time.time() + 0.2)

        def send(text, wait=0.8):
            os.write(master, text.encode() if isinstance(text, str) else text)
            pump(wait)

        def prompts():
            return raw.count(b'\xe2\x9d\xaf')

        def has(marker):
            return (marker.encode() if isinstance(marker, str) else marker) in raw

        def clean():
            # 0.74.0 起 `Out[n] =` 标签会着色（ADR-0011），raw 字节里标签与值
            # 之间夹着 \e[0m。文本断言必须先去掉转义序列，否则会误判失败。
            return re.sub(rb'\x1b\[[0-9;?]*[A-Za-z]', b'', bytes(raw))

        def wait_for(marker, timeout=20):
            end = time.time() + timeout
            while time.time() < end:
                if has(marker):
                    return True
                pump(0.2)
            return False

        def wait_new_prompt(before, timeout=15):
            end = time.time() + timeout
            while time.time() < end:
                pump(0.2)
                if prompts() > before:
                    return True
            return False

        ready = wait_for('\u276f', 30) or dsr_count >= 2
        probe['ready'] = 1 if ready else 0
        if ready:
            before = prompts()
            send('1 + 1\r', 0.7)
            wait_new_prompt(before)
            probe['first_eval'] = 1 if b'Out[1] = 2' in clean() else 0

            cmd = '! --tty %s %s\n' % (raku, child_rel)
            send(cmd, 1.0)
            probe['nested_ready'] = 1 if wait_for('NESTED-READY tty=True', 20) else 0

            # 真终端路径：写 \x03，行规程把它变成 SIGINT 投给前台进程组。
            try:
                os.write(master, b'\x03')
                probe['signal_sent'] = 1
            except OSError:
                probe['signal_sent'] = 0
            pump(2.0)
            probe['child_sigint'] = 1 if has('NESTED-SIGINT') else 0
            probe['handoff'] = 1 if (has('\u21a9') or has('已退出')) else 0
            probe['host_alive'] = 1 if poll() is None else 0

            before = prompts()
            send('40 + 2\n', 1.2)
            wait_new_prompt(before, 8)
            probe['next_eval'] = 1 if re.search(rb'Out\[\d+\] = 42', clean()) else 0

            send("say 'leftover", 0.3)
            send('\x03', 0.7)
            probe['later_ctrlc'] = 1 if has('已中断当前输入') else 0

            send('exit\n', 1.0)
        pump(0.5)
        if poll() is None:
            try:
                os.kill(pid, signal.SIGTERM)
                pump(0.6)
            except ProcessLookupError:
                pass
            if poll() is None:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                poll()
        probe['clean_exit'] = 1 if poll() == 0 else 0
        os.close(master)
        for k, v in probe.items():
            print('PROBE %s=%s' % (k, v))
        PYTHON

    my $ran = try {
        my $p = run('python3', $driver.Str, $*CWD.Str, $*EXECUTABLE.Str,
                    $child.relative($*CWD).Str, :out, :err);
        ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
    };
    my Str $text = $ran // '';
    my %p;
    for $text.lines -> $line {
        next unless $line.starts-with('PROBE ');
        my @kv = $line.substr(6).split('=', 2);
        %p{@kv[0]} = (@kv[1] // '');
    }

    is %p<ready>, '1', '真 PTY：REPL 出现第一个 prompt';
    is %p<first_eval>, '1', '前置：中断前求值正常';
    is %p<nested_ready>, '1', '前置：tty-exec 子进程拿到 TTY';
    is %p<signal_sent>, '1', 'SIGINT 已发给前台进程组';
    is %p<child_sigint>, '1', '契约 1：子进程收到 SIGINT 并退出';
    is %p<handoff>, '1', '契约 1：tty-exec 返回交接摘要';
    is %p<host_alive>, '1', '契约 2：同一个 SIGINT 没有带走宿主 REPL';
    is %p<next_eval>, '1', '契约 3：重画 prompt 后下一格可输入并求值';
    is %p<later_ctrlc>, '1', '契约 4：LEAVE 后普通 Ctrl-C 仍是输入中断';
    is %p<clean_exit>, '1', '契约 5：之后仍可正常退出（rc=0）';

    try { .unlink for ($child, $driver) };
}
else {
    skip 'Windows / 无 pty 模块：中断归属契约由 tools/tty-check.py 在 WSL 验收', 10;
}

done-testing;
