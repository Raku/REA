use Test;

# 20-data-cursor.t —— 流式查询 Cursor（0.67.0 / ADR-0004 §3）
#
# 与 0.64 的 `Table.batches` 区别：这里是**惰性执行**，只在被拉取时向驱动
# 要下一批行。测试分三层：纯逻辑 Cursor（不依赖数据库）、两驱动集成、
# 引擎契约与回归（不支持的引擎明确拒绝、query() 行为不变）。
# 可选驱动缺失时如实 skip，核心安装不被 NativeCall 依赖拖住。

use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Data::Cursor;
use Rakuish::Data::Engine::DuckDB;
use Rakuish::Data::Engine::SQLite;
use Rakuish::Sandbox;

# ── 1. 纯逻辑：用可计数的 fetch 闭包证明「没被拉就不执行」──────────
# 返回 (Cursor, @stats)，@stats[0] 是 fetch 调用次数（可变容器，实时可见）。
sub fake-cursor(Int $n, Int :$batch = 3, :$max-rows, :$before-batch) {
    my @stats = 0;
    my Int $i = 0;
    my &fetch = -> {
        @stats[0]++;
        $i >= $n ?? Nil !! { x => ++$i, label => "r$i" };
    };
    my %args = :columns(<x label>), :fetch(&fetch), :batch-size($batch),
               :source<fake>;
    %args<max-rows> = $max-rows if $max-rows.defined;
    %args<before-batch> = $before-batch if $before-batch.defined;
    (Rakuish::Data::Cursor.new(|%args), @stats);
}

{
    my ($c) = fake-cursor(10);
    isa-ok $c, Rakuish::Data::Cursor, 'Cursor 构造成功';
    is-deeply $c.columns.List, <x label>.List, '列名来自驱动结果';
    is $c.fetched, 0, '构造时不拉任何行';
    ok !$c.eof, '构造时未结束';
    ok $c.gist.contains('fake'), 'gist 带来源标识';
}

{
    my ($c, $stats) = fake-cursor(10);
    my $b = $c.next-batch;
    isa-ok $b, Rakuish::Data::Table, 'next-batch 返回 Table';
    is $b.elems, 3, '按 batch-size 取 3 行';
    is-deeply $b.get('x').List, (1, 2, 3).List, '行内容正确';
    is $c.fetched, 3, 'fetched 累计';
    ok !$c.eof, '还没到末尾';
    my @rest = $c.batches.List;
    is @rest.elems, 3, '剩余 3 批';
    is-deeply @rest.map(*.elems).List, (3, 3, 1).List, '最后一批是部分批';
    is $c.fetched, 10, '全部 10 行';
    ok $c.eof, '拉完自动 close';
    is $c.next-batch.elems, 0, 'close 后再取为空';
}

{
    # 关键断言：只消费第一批时，fetch 调用次数恰好等于批次大小。
    my ($c, $stats) = fake-cursor(1000, :batch(2));
    my $first = $c.batches.first;
    is $first.elems, 2, '惰性分批：只拿到第一批';
    is $stats[0], 2, '没有预取剩余 998 行（真惰性，不是分批视图）';
    ok !$c.eof, '提前退出后游标仍开着';
    $c.close;
    $c.close;
    ok $c.eof, 'close 幂等';
    is $stats[0], 2, 'close 不会触发额外读取';
}

{
    my ($c, $stats) = fake-cursor(1000);
    my $t = $c.take(5);
    is $t.elems, 5, 'take(5) 只取 5 行';
    is $stats[0], 5, 'take 不读多余行';
    ok $c.eof, 'take 后立即 close';
}

{
    my ($c) = fake-cursor(10, :batch(3));
    my @rows = $c.rows.List;
    is @rows.elems, 10, 'rows 逐行视图覆盖全部';
    is @rows[0]<x>, 1, '第一行';
    is @rows[9]<label>, 'r10', '最后一行';
}

{
    my ($c) = fake-cursor(20, :batch(3), :max-rows(7));
    my @sizes = $c.batches.map(*.elems).List;
    is-deeply @sizes.List, (3, 3, 1).List, 'Cursor 自身 max-rows 截断总行数';
    is $c.fetched, 7, 'fetched 不越过 max-rows';
    ok $c.eof, '达到上限自动 close';
}

{
    my &deadline = -> { X::Rakuish::Limit.new(:detail('deadline')).throw };
    my ($c) = fake-cursor(10, :before-batch(&deadline));
    throws-like { $c.next-batch }, X::Rakuish::Limit,
        'before-batch 抛出的 V3 异常原样透传';
    ok $c.eof, '异常后自动 close，不泄漏驱动结果';
}

{
    my &boom = -> { X::AdHoc.new(:payload<driver exploded>).throw };
    my $c = Rakuish::Data::Cursor.new(
        :columns(['x']), :fetch(&boom), :batch-size(2));
    throws-like { $c.next-batch }, X::Rakuish::Data,
        '驱动异常统一包装为 X::Rakuish::Data';
    ok $c.eof, '包装后仍然 close';
}

# ── 2. 引擎契约：不支持的引擎必须明确拒绝，不静默物化 ─────────────────
{
    class Bare does Rakuish::Data::Engine {
        method query(|c)    { Rakuish::Data::Table.new }
        method execute(|c)  { 0 }
        method begin(|c)    { Nil }
        method commit(|c)   { Nil }
        method rollback(|c) { Nil }
        method tables(|c)   { Rakuish::Data::Table.new }
        method schema(|c)   { Rakuish::Data::Table.new }
        method close(|c)    { Nil }
    }
    throws-like { Bare.new.cursor('select 1') },
        X::Rakuish::Unsupported, '角色默认实现明确拒绝流式游标';
    ok !Rakuish::Sandbox.new(:root($*CWD)).op-allowed('cursor'),
        'Agent op 白名单不开放 cursor';
}

# Table.batches（0.64 的分批视图）仍是独立能力，没有被 Cursor 破坏。
{
    my $t = Rakuish::Data::Table.from-rows(
        (1..7).map({ %(x => $_) }).List);
    is-deeply $t.batches(:size(3)).map(*.elems).List, (3, 3, 1).List,
        'Table.batches 回归：仍是物化 Table 的分批视图';
}

# ── 3. DuckDB 集成（:stream + chunks 真流式）──────────────────────────
my $duck-mod = try { require ::('DB::DuckDB') };
my Bool $have-duck = try { $duck-mod.^name eq 'DB::DuckDB' } // False;
if !$have-duck {
    skip 'DB::DuckDB 未安装，跳过 DuckDB 游标集成', 9;
}
else {
    my $db = Rakuish::Data::Engine::DuckDB.new(
        :path<:memory:>, :!read-only, :!safe);
    $db.execute('create table t (x int, s varchar)');
    for 1..10 -> $i { $db.execute('insert into t values (?, ?)', $i, "r$i") }

    my $c = $db.cursor('select * from t order by x', :batch-size(3));
    isa-ok $c, Rakuish::Data::Cursor, 'DuckDB.cursor 返回 Cursor';
    is-deeply $c.columns.List, <x s>.List, 'DuckDB 列名';
    is $c.source, 'DuckDB', '来源标记';

    my $head = $c.batches.first;
    is $head.elems, 3, 'DuckDB 只推进第一批 chunk';
    is $c.fetched, 3, 'DuckDB 未物化剩余行';
    ok !$c.eof, 'DuckDB 游标仍开着';
    $c.close;

    is-deeply $db.cursor('select * from t order by x', :max-rows(4), :batch-size(3))
                .batches.map(*.elems).List, (3, 1).List,
        'DuckDB :max-rows 下推 LIMIT';
    throws-like {
        Rakuish::Data::Engine::DuckDB.new.cursor('delete from t')
    }, X::Rakuish::Unsupported, 'DuckDB 只读引擎拒绝写 SQL 的 cursor';
    throws-like { $db.cursor('select * from no_such_table_xyz') },
        X::Rakuish::Data, 'DuckDB 游标错误统一包装';
    $db.close;
}

# ── 4. SQLite 集成（Result.hash 逐行 sqlite3_step）─────────────────────
my $lite-mod = try { require ::('DB::SQLite') };
my Bool $have-lite = try { $lite-mod.^name eq 'DB::SQLite' } // False;
if !$have-lite {
    skip 'DB::SQLite 未安装，跳过 SQLite 游标集成', 11;
}
else {
    my $db = Rakuish::Data::Engine::SQLite.new(
        :path<:memory:>, :!read-only, :!safe);
    $db.execute('create table q (x int, s text)');
    for 1..10 -> $i { $db.execute('insert into q values (?, ?)', $i, "q$i") }

    my $c = $db.cursor('select * from q order by x', :batch-size(4));
    isa-ok $c, Rakuish::Data::Cursor, 'SQLite.cursor 返回 Cursor';
    is-deeply $c.columns.List, <x s>.List, 'SQLite 列名';
    is $c.source, 'SQLite', '来源标记';

    my $first = $c.next-batch;
    is $first.elems, 4, 'SQLite 逐行拉取一批';
    is-deeply $first.get('s').List, <q1 q2 q3 q4>.List, 'SQLite 行内容';
    is $c.fetched, 4, 'SQLite 未物化剩余行';
    is-deeply $c.batches.map(*.elems).List, (4, 2).List, 'SQLite 剩余批次';
    ok $c.eof, 'SQLite 拉完自动 close';

    is-deeply $db.cursor('select * from q order by x', :max-rows(3), :batch-size(2))
                .batches.map(*.elems).List, (2, 1).List,
        'SQLite :max-rows 下推 LIMIT';
    throws-like {
        Rakuish::Data::Engine::SQLite.new.cursor('delete from q')
    }, X::Rakuish::Unsupported, 'SQLite 只读引擎拒绝写 SQL 的 cursor';
    throws-like { $db.cursor('select * from no_such_table_xyz') },
        X::Rakuish::Data, 'SQLite 游标错误统一包装';
    $db.close;
}

done-testing;
