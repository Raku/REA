#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys;

# 02-sys-session.t —— API v3 会话语义（ADR-0001 / Phase 1）
#
# 核心命题：cwd / env 是 Sys 对象的值，不是进程全局状态。
# v2 的 JSONServer 多 client 共享 chdir / %*ENV 正是这里要消灭的问题。

sub rmtree(IO::Path $d) {
    return unless $d.e || $d.l;
    unless $d.l {
        for (try { $d.dir } // ()) -> $c { rmtree($c) }
    }
    $d.d ?? (try $d.rmdir) !! (try $d.unlink);
}

my IO::Path $base = $*TMPDIR.IO.add("rakuish-v3-session-{$*PID}");
$base.mkdir;
END { rmtree($base) if $base.e }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
$sys.mkdir('work');
$sys.write('work/inner.txt', 'cwd-based');

# ── cwd 是会话值 ──────────────────────────────────────────────────────
my Str $proc-cwd = $*CWD.Str;
my IO::Path $d = $sys.cd('work');
ok $d.d, 'cd 返回目标目录';
ok $sys.cwd.Str.subst(:g, '\\', '/').ends-with('/work'), 'cd 改的是会话 cwd';
is $*CWD.Str, $proc-cwd, 'cd 不改变进程 $*CWD（关键：不 chdir）';
ok $base.add('work/inner.txt').e, '相对路径基于会话 cwd 解析';
is $sys.read('inner.txt'), 'cwd-based', 'cd 之后相对读落在 work 下';

my Str $norm = $sys.resolve('inner.txt').Str.subst(:g, '\\', '/');
ok $norm.ends-with('/work/inner.txt'), 'resolve 拼上会话 cwd';
nok $norm.contains('/../'), 'resolve 结果不含 .. 段';

# ── env 是会话值 ──────────────────────────────────────────────────────
my Str $k = 'RAKUISH_V3_SESSION_TEST';
%*ENV{$k}:delete;
is $sys.set-env($k, 'session-only'), 'session-only', 'set-env 返回设置值';
is $sys.get-env($k), 'session-only', 'set-env 在会话内可见';
nok %*ENV{$k}:exists, 'set-env 不改进程 %*ENV（关键）';

my %snapshot = $sys.env;
%snapshot{$k} = 'mutated';
is $sys.get-env($k), 'session-only', 'env() 返回副本，外部改动不影响会话';
$sys.unset-env($k);
nok $sys.get-env($k).defined, 'unset-env 生效';
nok %*ENV{$k}:exists, 'unset-env 也不碰进程环境';

# ── 多会话隔离 ────────────────────────────────────────────────────────
my $other = Rakuish::Sys.new(:root($base), :cwd($base));
isnt $other.cwd.Str, $sys.cwd.Str, '另一个会话 cwd 独立';
nok $other.get-env($k).defined, '另一个会话看不到本会话的 env';
$other.set-env($k, 'other');
nok $sys.get-env($k).defined, '本会话也看不到另一会话的 env';
is $other.read('work/inner.txt'), 'cwd-based', '另一会话从 root 出发读同一文件';

# ── root 沙箱 ─────────────────────────────────────────────────────────
$sys.cd('..');
throws-like { $sys.resolve('../outside.txt') }, X::Rakuish::Sandbox,
    'resolve 拒绝 .. 越出 root';
throws-like { $sys.resolve('/etc/passwd') }, X::Rakuish::Sandbox,
    'resolve 拒绝 root 外绝对路径';
throws-like { $sys.write('../escape.txt', 'x') }, X::Rakuish::Sandbox,
    'write 也走 resolve，越界即拒绝';
nok $base.parent.add('escape.txt').e, '越界写入没有产生任何文件';

my Str $inside = $sys.resolve('work/../work/inner.txt').Str.subst(:g, '\\', '/');
ok $inside.ends-with('/work/inner.txt'), 'root 内的 .. 归一化后仍可用';
ok $sys.ls('.').elems > 0, 'root 内正常列目录';

if $*DISTRO.is-win {
    ok $sys.resolve($base.Str.uc).defined,
       'Windows root 大小写不敏感校验通过';
}
else {
    skip '根路径大小写校验仅 Windows 适用', 1;
}

# ── try-op：Agent 边界的异常收敛 ──────────────────────────────────────
my $good = $sys.try-op('read', { $sys.read('work/inner.txt') });
isa-ok $good, Result, 'try-op 返回 Result';
ok $good.ok, 'try-op 成功 ok=True';
is $good.code, 0, 'try-op 成功 code=0';
is $good.value, 'cwd-based', 'try-op 保留返回值';
ok $good.elapsed.defined, 'try-op 记录耗时';
is $good.to-hash<op>, 'read', 'try-op 结果可序列化为 op';

my $bad = $sys.try-op('read', { $sys.read('missing.txt') });
nok $bad.ok, 'try-op 把异常收敛成 ok=False';
is $bad.code, 1, 'try-op 失败 code=1';
ok $bad.err.chars > 0, 'try-op 保留错误消息';
nok $bad.Bool, 'Result.Bool 在失败时为 False（Raku && 可直接用）';

# ── 默认构造 ──────────────────────────────────────────────────────────
my $default = Rakuish::Sys.new;
is $default.root.Str, $default.cwd.Str, '未指定 root 时默认等于 cwd';
ok $default.env.elems > 0, 'env 默认从 %*ENV 拷贝';

# ── Windows 跨盘：REPL 默认 all-drives，Agent 默认仍受 root 约束 ──────
if $*DISTRO.is-win && 'F:/'.IO.d {
    my $cross = Rakuish::Sys.new(
        :root(IO::Path.new('C:\\')), :cwd($*CWD.IO), :all-drives);
    ok $cross.resolve('F:/').defined, 'all-drives 允许访问其他盘符';

    my $guarded = Rakuish::Sys.new(
        :root(IO::Path.new('C:\\')), :cwd($*CWD.IO));
    throws-like { $guarded.resolve('F:/') }, X::Rakuish::Sandbox,
        '未打开 all-drives 时跨盘仍被拒绝';
}
else {
    skip '跨盘测试需要 Windows 且存在 F: 盘', 2;
}

done-testing;
