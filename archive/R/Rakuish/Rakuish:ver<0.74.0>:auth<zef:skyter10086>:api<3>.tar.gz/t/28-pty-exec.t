use Test;
use JSON::Fast;
use Rakuish::Sys;
use Rakuish::Sandbox;
use Rakuish::Agent;
use Rakuish::Result;

# 0.72.0：PTY 捕获层（Sys.pty-exec / Agent pty_exec）
# 0.72.2：能力探测与「先剥离后截断」的细节回归在 t/29，本文件保持入口契约。
# 重点：看到终端、捕获输出、超时杀掉、默认 Agent 不开放。

my $base = $*TMPDIR.IO.add("rakuish-pty-{$*PID}");
$base.mkdir;
LEAVE {
    try {
        for $base.dir -> $e { $e.d ?? $e.rmdir !! $e.unlink }
        $base.rmdir;
    }
}
my Str $EXE = $*EXECUTABLE.Str;
my $sys = Rakuish::Sys.new(:root($base), :cwd($base));

my $ok = $sys.pty-exec($EXE, '-e',
    'say "PTY-OK"; say "SECOND"; say "TTY=" ~ $*IN.t;',
    :timeout-ms(8000));
ok $ok.ok, 'pty-exec 成功';
is $ok.code, 0, 'pty-exec code=0';
like $ok.out, /'PTY-OK'/, 'PTY 捕获到 stdout';
like $ok.out, /'SECOND'/, 'PTY 捕获到多行';
like $ok.out, /'TTY=True'/, '子进程看到 TTY';
nok $ok.out.contains("\e["), '控制序列已剥离';
ok $ok.value<pty>, 'value 标记 pty';
ok $ok.value<tty>, 'value 标记 tty';

my $slow = $sys.pty-exec($EXE, '-e', 'sleep 5; say "NO"',
    :timeout-ms(250));
nok $slow.ok, 'pty-exec 超时不成功';
is $slow.code, 124, 'pty-exec 超时 code=124';
ok $slow.value<timed-out>, 'value 标记 timed-out';

my $big = $sys.pty-exec($EXE, '-e', 'print "x" x 400',
    :timeout-ms(8000), :max-bytes(80));
ok $big.ok, 'pty-exec 大输出仍返回';
ok $big.value<truncated>, 'max-bytes 标记 truncated';
ok $big.out.chars <= 80, '输出被截断';

# Agent：默认拒绝；显式 allow-exec + allow-pty 才开放。
my $no = Rakuish::Sandbox.new(:root($base), :token('tk'),
    :allow-exec, :allowlist($EXE));
my $no-agent = Rakuish::Agent.new(:sandbox($no));
my %denied = from-json($no-agent.handle-line(to-json({
    id => 1, token => 'tk', op => 'pty_exec',
    argv => [$EXE, '-e', 'say "NO"'],
}, :!pretty)));
nok %denied<ok>, '默认 pty_exec 被拒绝';
is %denied<code>, 403, '默认 pty_exec 403';

my $sb = Rakuish::Sandbox.new(:root($base), :token('tk'),
    :allow-exec, :allow-pty, :allowlist($EXE));
my $agent = Rakuish::Agent.new(:sandbox($sb));
my %res = from-json($agent.handle-line(to-json({
    id => 2, token => 'tk', op => 'pty_exec',
    argv => [$EXE, '-e', 'say "AGENT-PTY"'],
    timeout_ms => 8000, cols => 100, rows => 30,
}, :!pretty)));
ok %res<ok>, 'allow-pty 后 pty_exec 成功';
like %res<out>, /'AGENT-PTY'/, 'Agent 捕获 PTY 输出';

done-testing;
