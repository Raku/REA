#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys;
use Rakuish::Sys::FS;

# 01-sys-fs.t —— API v3 文件 API 契约（ADR-0001 / Phase 1）
#
# 断言纪律（HANDOFF §7.18）：每条「不含 X」都要配一条「必须含 Y」，
# 每条异常路径都要用**当前**异常类型断言，不用文案匹配。

sub rmtree(IO::Path $d) {
    return unless $d.e || $d.l;
    unless $d.l {
        for (try { $d.dir } // ()) -> $c { rmtree($c) }
    }
    $d.d ?? (try $d.rmdir) !! (try $d.unlink);
}

my IO::Path $base = $*TMPDIR.IO.add("rakuish-v3-fs-{$*PID}");
$base.mkdir;
END { rmtree($base) if $base.e }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my Str $text = '中文 hello';

# ── write / read ──────────────────────────────────────────────────────
isa-ok $sys, Rakuish::Sys, 'Sys 构造成功';
my $w = $sys.write('a.txt', $text);
isa-ok $w, WriteResult, 'write 返回 WriteResult';
is $w.bytes, $text.encode('utf-8').elems, 'write 返回真实字节数（中文按 UTF-8）';
ok $w.atomic, 'write 首次写入走原子 rename';
is $sys.read('a.txt'), $text, 'read 中文 UTF-8 roundtrip';

my $blob = $sys.read('a.txt', :bin);
ok $blob ~~ Blob, 'read :bin 返回 Blob';
is $blob.elems, $text.encode('utf-8').elems, 'read :bin 字节数正确';
is $sys.read('a.txt', :offset(2), :limit(3)), $text.substr(2, 3),
   'read :offset/:limit 按字符切片';
is $sys.read('a.txt', :bin, :offset(3), :limit(3)).elems, 3,
   'read :bin :offset/:limit 按字节切片';
is $sys.read('a.txt', :offset(999)), '', 'read :offset 超出文本长度返回空串';
is $sys.read('a.txt', :bin, :offset(999)).elems, 0,
   'read :bin :offset 超出字节长度返回空 Blob';
throws-like { $sys.read('a.txt', :offset(-1)) }, X::Rakuish::Path,
    'read 负 offset 抛 X::Path';
throws-like { $sys.read('a.txt', :limit(-1)) }, X::Rakuish::Path,
    'read 负 limit 抛 X::Path';

my $w2 = $sys.write('a.txt', 'second');
is $sys.read('a.txt'), 'second', 'write 覆盖已有文件后内容正确';
isa-ok $w2.atomic, Bool, 'write 覆盖时 atomic 如实标注（平台可能降级）';

my $ap = $sys.append('a.txt', '!');
is $sys.read('a.txt'), 'second!', 'append 追加到尾部';
nok $ap.atomic, 'append 不宣称原子';
is $sys.append('a.txt', '?').bytes, 1, 'append 返回写入字节数';

my $w3 = $sys.write('sub/deep/deep.txt', 'deep', :mkdir);
is $sys.read('sub/deep/deep.txt'), 'deep', 'write :mkdir 自动建父目录';
ok $w3.path.e, 'WriteResult.path 指向真实文件';

my $w4 = $sys.write('a.txt', 'third', :backup);
ok $base.add('a.txt.bak').e, 'write :backup 生成备份文件';
is $base.add('a.txt.bak').slurp, 'second!?', '备份内容是覆盖前的值';
is $sys.read('a.txt'), 'third', '备份不干扰新内容';

my $tiny = Rakuish::Sys::FS.new(:max-bytes(4));
throws-like { $tiny.write($base.add('a.txt'), 'x', :backup) },
    X::Rakuish::Limit, ':backup 旧文件超过 max-bytes 时拒绝，不整文件读入';

# ── 异常路径 ──────────────────────────────────────────────────────────
throws-like { $sys.read('nope.txt') }, X::Rakuish::NotFound,
    'read 不存在抛 X::NotFound';
throws-like { $sys.read('a.txt', :max-bytes(2)) }, X::Rakuish::Limit,
    'read 超 max-bytes 抛 X::Limit';
my $small = Rakuish::Sys.new(:root($base), :cwd($base), :max-bytes(4));
throws-like { $small.write('a.txt', 'over four bytes') },
    X::Rakuish::Limit, '会话 max-bytes 限制写入';
throws-like { $small.read('a.txt') }, X::Rakuish::Limit,
    '会话 max-bytes 限制读取';

# ── ls / stat ─────────────────────────────────────────────────────────
$sys.write('.hidden', 'h');
my @top = $sys.ls('.');
ok @top.elems > 0, 'ls 返回非空列表（反向断言的配对）';
is @top.grep(* ~~ IO::Path).elems, @top.elems, 'ls 每项都是 IO::Path';
is @top.grep(*.basename eq 'a.txt').elems, 1, 'ls 必须含 a.txt';
is @top.grep(*.basename eq '.hidden').elems, 0, 'ls 默认不列隐藏项';
is $sys.ls('.', :all).grep(*.basename eq '.hidden').elems, 1,
   'ls :all 必须列出隐藏项';
is $sys.ls('.', :recursive).grep(*.basename eq 'deep.txt').elems, 1,
   'ls :recursive 含深层文件';
is $sys.ls('.', :recursive, :max-depth(1)).grep(*.basename eq 'deep.txt').elems, 0,
   'ls :max-depth(1) 不下钻';
my @one = $sys.ls('a.txt');
is @one.elems, 1, 'ls 文件目标返回单个路径（shell ls file 语义）';
is @one[0].basename, 'a.txt', 'ls 文件目标 basename 正确';

my $st = $sys.stat('a.txt');
isa-ok $st, Stat, 'stat 返回 Stat';
is $st.type, 'file', 'stat.type = file';
is $st.size, 'third'.encode.elems, 'stat.size 正确';
nok $st.is-symlink, 'stat.is-symlink 对普通文件为 False';
isa-ok $st.mode, Int, 'stat.mode 是 Int（Windows 可为 0）';
is $st.to-hash<path>, $st.path.Str, 'Stat.to-hash 含 path';
is $sys.stat('sub').type, 'dir', 'stat.type = dir';

# ── mkdir / cp / mv / glob ────────────────────────────────────────────
ok $sys.mkdir('mvdir').ok, 'mkdir 返回 ok Result';
ok $base.add('mvdir').d, 'mkdir 真的建出了目录';
ok $sys.cp('a.txt', 'copy.txt').ok, 'cp 返回 ok';
is $sys.read('copy.txt'), $sys.read('a.txt'), 'cp 内容一致';
throws-like { $sys.cp('a.txt', 'copy.txt') }, X::Rakuish::Exists,
    'cp 目标已存在且不 overwrite 抛 X::Exists';
ok $sys.cp('a.txt', 'copy.txt', :overwrite).ok, 'cp :overwrite 成功';
ok $sys.cp('sub', 'sub-copy', :recursive).ok, 'cp :recursive 复制目录树';
ok $sys.read('sub-copy/deep/deep.txt') eq 'deep', '递归复制内容正确';
my $tiny-cp = Rakuish::Sys::FS.new(:max-entries(1));
throws-like { $tiny-cp.cp($base.add('sub'), $base.add('sub-copy2'), :recursive) },
    X::Rakuish::Limit, 'cp -r 条目上限预检';

ok $sys.mv('copy.txt', 'moved.txt').ok, 'mv 返回 ok';
ok $base.add('moved.txt').e, 'mv 目标存在';
nok $base.add('copy.txt').e, 'mv 源已消失';

is $sys.glob('*.txt').grep(*.basename eq 'a.txt').elems, 1,
   'glob *.txt 命中根目录文件';
is $sys.glob('*.txt').grep(*.basename eq 'deep.txt').elems, 0,
   'glob * 不跨目录（深层文件不被 *.txt 命中）';
is $sys.glob('sub/deep/*.txt').grep(*.basename eq 'deep.txt').elems, 1,
   'glob 相对 root 的子目录模式命中';
is $sys.glob('sub?deep.txt').elems, 0,
   'glob ? 不跨目录分隔符';
ok $sys.glob('**/*.txt').grep(*.basename eq 'deep.txt').elems >= 1,
   'globstar **/ 匹配任意深度';
ok $sys.glob('sub/**/deep.txt').elems >= 1, 'glob foo/**/bar';
ok $sys.glob('**/*.{txt,md}').grep(*.basename eq 'deep.txt').elems >= 1,
   'brace 展开';
ok $sys.glob('sub/**/[d]eep.txt').grep(*.basename eq 'deep.txt').elems >= 1,
   '字符集匹配';

my $limited = Rakuish::Sys.new(:root($base), :cwd($base), :max-entries(2));
throws-like { $limited.ls('.', :recursive) }, X::Rakuish::Limit,
    '递归目录条目上限';
throws-like { $limited.rm('sub', :recursive) }, X::Rakuish::Limit,
    'rm -r 遍历时提前中止';

# ── rm：dry-run / 递归 / 护栏 ─────────────────────────────────────────
my $dry = $sys.rm('sub', :recursive, :dry-run);
ok $dry.ok, 'rm :dry-run 返回 ok';
ok $dry.value.elems > 1, 'rm :dry-run 给出删除计划';
ok $base.add('sub').d, 'rm :dry-run 一个字节都没删';
ok $base.add('sub/deep/deep.txt').e, 'rm :dry-run 深层文件仍在';

throws-like { $sys.rm('sub') }, X::Rakuish::Path,
    'rm 非递归删目录抛 X::Path';
throws-like { $sys.rm('missing.txt') }, X::Rakuish::NotFound,
    'rm 不存在且不 force 抛 X::NotFound';
ok $sys.rm('missing.txt', :force).ok, 'rm :force 对不存在返回 ok';
throws-like { $sys.rm('.') }, X::Rakuish::Sandbox,
    'rm 拒绝删除会话 root';

my $removed = $sys.rm('sub', :recursive);
ok $removed.ok, 'rm :recursive 成功';
is $removed.err, '', 'rm 没有静默吞掉删除错误（防假绿）';
nok $base.add('sub').e, 'rm :recursive 真的删掉了非空目录';
ok $base.add('a.txt').e, 'rm 只删目标，不误伤同级文件';

# ── 符号链接：只删链接，不跟随目标（能创建 symlink 的平台才测）────────
my $target = $base.add('link-target.txt');
$target.spurt('keep me');
my $link = $base.add('link.txt');
my Bool $can-link = so try { symlink($target.Str, $link.Str); True };
if $can-link {
    is $sys.stat('link.txt').type, 'symlink', 'stat 认出符号链接';
    ok $sys.rm('link.txt', :dry-run).ok, 'rm 链接 dry-run 可预览';
    ok $sys.rm('link.txt').ok, 'rm 链接成功';
    nok $link.e, '链接本身已删除';
    is $target.slurp, 'keep me', '链接目标内容未被删除（不跟随）';

    my $cp-src = $base.add('cp-src');
    mkdir $cp-src;
    $cp-src.add('real.txt').spurt('real');
    symlink($target.Str, $cp-src.add('child-link').Str);
    throws-like { $sys.cp($cp-src.Str, 'cp-dst', :recursive) },
        X::Rakuish::Unsupported, 'cp -r 遇到目录内 symlink 拒绝，不跟随到目标';

    # 中间目录 symlink 指向 root 外：读写都必须被 canonical 校验拦下
    my $outside = $*TMPDIR.IO.add("rakuish-outside-{$*PID}");
    $outside.mkdir;
    $outside.add('secret.txt').spurt('outside');
    symlink($outside.Str, $base.add('escape-dir').Str);
    throws-like { $sys.read('escape-dir/secret.txt') },
        X::Rakuish::Sandbox, '中间 symlink 读 root 外被拒';
    throws-like { $sys.write('escape-dir/written.txt', 'x') },
        X::Rakuish::Sandbox, '中间 symlink 写 root 外被拒';
    nok $outside.add('written.txt').e, 'root 外没有被写入';

    $base.add('bk.txt').spurt('old');
    symlink($target.Str, $base.add('bk.txt.bak').Str);
    throws-like { $sys.write('bk.txt', 'new', :backup) },
        X::Rakuish::Unsupported, '拒绝覆盖符号链接备份';
}
else {
    skip '本机无法创建符号链接（Windows 需开发者模式）', 8;
}

# ── root=/ 的根路径边界：不能把 '/' 判成 '//' ─────────────────────
if $*DISTRO.is-win {
    skip 'Windows 没有 /bin 这类 usrmerge 符号链接', 1;
}
else {
    my $root-sys = Rakuish::Sys.new(
        :root(IO::Path.new('/')), :cwd(IO::Path.new('/')));
    my $st = try { $root-sys.stat('/bin/ls') };
    ok $st.defined, 'root=/ 时含中间 symlink 的 /bin/ls 可通过';
}

# ── Result / FS 独立使用 ──────────────────────────────────────────────
my $r = Result.new(:ok, :out("a\nb"), :op<exec>);
ok $r.Bool, 'Result.Bool 跟随 .ok';
is $r.lines.elems, 2, 'Result.lines 按行切分';
is $r.to-hash<op>, 'exec', 'Result.to-hash 含 op';
nok Result.new(:!ok).Bool, 'Result.Bool 失败时为 False';

my $bare = Rakuish::Sys::FS.new;
is $bare.read($base.add('a.txt')), $sys.read('a.txt'),
   'Sys::FS 可脱离 Sys 独立使用（默认 resolver）';

done-testing;
