use Test;

# 17-data-parquet.t —— Parquet / 惰性大结果 / SQL 错误统一（0.64.0）
#
# Parquet 依赖 DuckDB 外部文件访问，必须显式 :allow-external 且路径经 Sys root
# 校验；Agent 的 op 白名单不开放这条路（V-130 / V-152）。

use JSON::Fast;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Data;
use Rakuish::Data::Table;
use Rakuish::Data::Engine::DuckDB;
use Rakuish::Sandbox;

my $mod = try { require ::('DB::DuckDB') };
my Bool $have = try { $mod.^name eq 'DB::DuckDB' } // False;

if !$have {
    skip 'DB::DuckDB 未安装，跳过 Parquet / LIMIT 下推测试', 18;
    done-testing;
}
else {
    my $dir = $*CWD.add('tmp').add('parquet-test');
    $dir.mkdir unless $dir.e;
    my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
    my $file = 'sample.parquet';
    my $abs  = $dir.add($file).Str;

    my $table = Rakuish::Data::Table.from-rows([
        { id => 1, name => 'alpha', ok => True,  score => 1.5 },
        { id => 2, name => 'beta',  ok => False, score => 2.5 },
        { id => 3, name => 'gamma', ok => True,  score => 3.5 },
    ]);

    # ── 写入 / 读回 ─────────────────────────────────────────────────
    ok Rakuish::Data::save-data($sys, $file, $table, :allow-external),
        'save-data 写出 .parquet';
    ok $dir.add($file).e, 'Parquet 文件确实落盘';
    ok $dir.add($file).s > 0, 'Parquet 文件非空';

    my $back = Rakuish::Data::open-data($sys, $file, :allow-external);
    isa-ok $back, Rakuish::Data::Table, 'open-data 读回 Table';
    is $back.elems, 3, '读回 3 行';
    is $back.get('name').List.sort.List, <alpha beta gamma>.List,
        'Parquet 字符串列往返';
    is $back.get('id').List.sort.List, (1, 2, 3).List, 'Parquet 整数列往返';
    is $back.column-type('id'), 'int', 'Parquet 保留整数类型';

    # ── 显式受控：默认拒绝 / 路径仍过 Sys ───────────────────────────
    throws-like { Rakuish::Data::open-data($sys, $file) },
        X::Rakuish::Unsupported, '默认拒绝 Parquet（未给 :allow-external）';
    throws-like { Rakuish::Data::save-data($sys, $file, $table) },
        X::Rakuish::Unsupported, '默认拒绝写 Parquet';
    throws-like {
        Rakuish::Data::open-data($sys, '../outside.parquet', :allow-external)
    }, X::Rakuish::Sandbox, 'Parquet 路径仍受 Sys root 校验';

    my $sbx = Rakuish::Sandbox.new(:root($dir), :token('T'));
    nok $sbx.allowed-ops.grep({ .contains('parquet') }).elems,
        'Agent op 白名单不暴露 Parquet / 外部访问';

    # ── Engine 层的开关 ─────────────────────────────────────────────
    my $safe = Rakuish::Data::Engine::DuckDB.new;
    throws-like { $safe.read-parquet($abs) },
        X::Rakuish::Unsupported, 'safe 引擎拒绝 read-parquet';
    throws-like { $safe.write-parquet($abs, 'select 1') },
        X::Rakuish::Unsupported, 'safe 引擎拒绝 write-parquet';
    $safe.close;

    my $db = Rakuish::Data::Engine::DuckDB.new(:!read-only, :!safe);
    my $limited = $db.read-parquet($abs, :max-rows(2));
    is $limited.elems, 2, 'read-parquet :max-rows 下推 LIMIT';

    $db.execute('create table big (x int)');
    $db.execute('insert into big values (1),(2),(3),(4),(5)');
    my $q = $db.query('select * from big order by x', :max-rows(2));
    is $q.elems, 2, 'query :max-rows 只物化前 2 行';
    is $q.get('x').List, (1, 2), 'LIMIT 下推后取到前两行';

    throws-like { $db.query('select * from no_such_table_xyz') },
        X::Rakuish::Data, 'DuckDB 驱动错误统一为 X::Rakuish::Data';
    throws-like { $db.write-parquet($abs, 'select 1; drop table big') },
        X::Rakuish::Data, 'Parquet 导出 SQL 拒绝分号';
    $db.close;

    # ── Table 大结果保护 ────────────────────────────────────────────
    my $batches = $table.batches(:size(2));
    isa-ok $batches, Seq, 'batches 返回惰性 Seq';
    is $batches.map(*.elems).List, (2, 1).List, '分批大小 2 + 1';
    like $table.to-text(:max-rows(2)),
        /'共 3 行，只显示前 2 行'/, 'to-text 标注截断';
    like $table.to-markdown(:max-rows(2)),
        /'只显示前 2 行'/, 'to-markdown 标注截断';
    is from-json($table.to-json(:max-rows(2))).elems, 2,
        'to-json 截断后仍是合法 JSON';
    is from-json($table.to-json).elems, 3, '不传 max-rows 时行为不变';

    # ── SQLite 的 LIMIT 下推 / 错误统一（可选依赖）───────────────────
    my $smod = try { require ::('DB::SQLite') };
    my Bool $shave = try { $smod.^name eq 'DB::SQLite' } // False;
    if $shave {
        require ::('Rakuish::Data::Engine::SQLite');
        my $sdb = ::('Rakuish::Data::Engine::SQLite').new(:!read-only);
        $sdb.execute('create table big (x int)');
        $sdb.execute('insert into big values (1),(2),(3)');
        is $sdb.query('select * from big order by x', :max-rows(2)).elems,
            2, 'SQLite query :max-rows 下推 LIMIT';
        throws-like { $sdb.query('select * from no_such_table_xyz') },
            X::Rakuish::Data, 'SQLite 驱动错误统一为 X::Rakuish::Data';
        $sdb.close;
    }
    else { skip 'DB::SQLite 未安装，跳过 SQLite LIMIT / 错误统一', 2 }

    # ── 清理 ─────────────────────────────────────────────────────────
    $dir.add($file).unlink if $dir.add($file).e;
    try { $dir.rmdir };
    done-testing;
}
