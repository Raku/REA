use Test;

# 24-csv-dialect.t —— CSV 方言白名单、SQL 注入防护与 REPL 名字解析修复
# （0.69.0 / ADR-0006 §2、SPEC V-162 / V-165）
#
# 纯函数部分不依赖任何数据库驱动；真实 DuckDB 往返部分带 skip 护栏。
# 关键回归：不加 :allow-external 时默认 .csv 行为与 0.68 逐字一致。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Data;
use Rakuish::Data::Table;
use Rakuish::Data::CsvOptions;
use Rakuish::Data::Engine::DuckDB;
use Rakuish::Sandbox;
use Rakuish::REPL::Session;

my $dir = $*CWD.add('tmp').add('csv-dialect-test');
$dir.mkdir unless $dir.e;
$dir.add('semi.csv').spurt(
    "id;name;score\n1;alpha;1.5\n2;beta;2.5\n3;gamma;3.5\n");
$dir.add('plain.csv').spurt("id,name\n1,alpha\n2,beta\n");
my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));

# ── 1. 选项白名单（纯函数）─────────────────────────────────────────
ok csv-option-names().grep(* eq 'delimiter').elems == 1,
    '选项名清单含 delimiter';
ok csv-option-names().elems == 7, '选项白名单共 7 项';

my @p = normalize-csv-options({ delimiter => ';', header => False });
is @p.elems, 2, '两个选项归一化成两个 Pair';
is @p[0].key, 'delim', 'delimiter 映射为 DuckDB delim';
is @p[0].value, ';', '分号是合法分隔符（不被黑名单误伤）';
is @p[1].key, 'header', 'header 选项名保留';
is @p[1].value, False, 'Bool False 原样保留';

my %empty = csv-read-clause({});
is %empty<clause>, '', '空选项不生成任何 SQL 片段';
is %empty<values>.elems, 0, '空选项不生成绑定值';
is csv-write-options({}), '(FORMAT CSV, HEADER)',
    '空选项的 COPY 与 0.68 逐字一致';

my %dialect = csv-read-clause({
    delimiter => ';', quote => '"', escape => '"',
    nullstr => 'NA', header => False, skip => 1, all-varchar => True,
});
ok %dialect<clause>.contains('delim => ?'), '读选项全部用 ? 绑定';
nok %dialect<clause>.contains("';'"), '读选项的 SQL 片段里没有拼入值';
is %dialect<values>.elems, 7, '七个绑定值';
is %dialect<values>[0], ';', '绑定值顺序与选项顺序一致';

my Str $write-opts = csv-write-options({
    delimiter => ';', header => False, nullstr => 'NA',
});
ok $write-opts.contains("DELIMITER ';'"), '写选项含 DELIMITER 字面量';
ok $write-opts.contains('HEADER false'), '写选项支持无表头';
ok $write-opts.contains("NULL 'NA'"), '写选项支持空值字符串';
ok $write-opts.contains('FORMAT CSV'), '写选项始终带 FORMAT CSV';

# ── 2. 拒绝非法 / 注入性选项（纯函数）──────────────────────────────
throws-like { normalize-csv-options({ delimeter => ';' }) },
    X::Rakuish::Unsupported, '拼错的选项名明确拒绝，不静默忽略';
throws-like { normalize-csv-options({ delimiter => ';;' }) },
    X::Rakuish::Unsupported, '分隔符必须是单字符';
throws-like { normalize-csv-options({ delimiter => "'" }) },
    X::Rakuish::Unsupported, '单引号分隔符拒绝（会截断 COPY 字面量）';
throws-like { normalize-csv-options({ nullstr => "x'; drop table t" }) },
    X::Rakuish::Unsupported, 'nullstr 含引号 / 分号拒绝';
throws-like { normalize-csv-options({ header => 'yes' }) },
    X::Rakuish::Unsupported, 'header 只接受 Bool';
throws-like { normalize-csv-options({ skip => -1 }) },
    X::Rakuish::Unsupported, 'skip 越界拒绝';
throws-like { csv-write-options({ skip => 1 }) },
    X::Rakuish::Unsupported, '写出明确拒绝仅读选项 skip';
throws-like { csv-write-options({ 'all-varchar' => True }) },
    X::Rakuish::Unsupported, '写出明确拒绝仅读选项 all-varchar';
lives-ok { csv-write-options({ delimiter => ';' }) },
    '分号分隔符在引号内是合法字面量';

# ── 3. 默认路径与授权约束（无需驱动）──────────────────────────────
my $plain = Rakuish::Data::open-data($sys, 'plain.csv');
isa-ok $plain, Rakuish::Data::Table, '默认 .csv 仍返回 Table';
is $plain.column-type('id'), 'str', '默认路径仍是 Raku 解析器（str）';
throws-like { Rakuish::Data::open-data($sys, 'plain.csv',
                                       :csv-options({ delimiter => ';' })) },
    X::Rakuish::Unsupported, '方言选项不带 :allow-external 明确拒绝';
throws-like { Rakuish::Data::save-data($sys, 'x.csv', $plain,
                                       :csv-options({ delimiter => ';' })) },
    X::Rakuish::Unsupported, '写出方言选项同样要求显式授权';

my $sbx = Rakuish::Sandbox.new(:root($dir), :token('TOKEN'));
ok 'sql_query' (elem) $sbx.allowed-ops, 'Agent op 白名单未删既有项';
nok 'describe' (elem) $sbx.allowed-ops, 'Agent 不开放 describe';
nok 'plugin' (elem) $sbx.allowed-ops, 'Agent 不开放插件 / 方言开关';

# ── 4. V-165：REPL 里 open-data / save-data 解析到 DSL 版本 ─────────
# Session 曾同时 use DSL 与 Data，后者的同名导出覆盖了 DSL，
# 导致文档示例的单参数形态一直报「参数太少」。改 need 后回归守护。
my $sess = Rakuish::REPL::Session.new(:sys($sys));
my $r1 = $sess.eval-line(q{open-data('plain.csv')});
ok $r1.ok, 'REPL 里 open-data(单参数) 求值成功';
isa-ok $r1.value, Rakuish::Data::Table, 'REPL open-data 返回 Table';
my $r2 = $sess.eval-line(q{save-data('repl-out.csv', open-data('plain.csv'))});
ok $r2.ok, 'REPL 里 save-data(两个位置参数) 求值成功';
ok $dir.add('repl-out.csv').e, 'REPL save-data 确实落盘';

# ── 5. 真实 DuckDB 方言往返（可选驱动）─────────────────────────────
my $mod = try { require ::('DB::DuckDB') };
my Bool $have = try { $mod.^name eq 'DB::DuckDB' } // False;
if !$have {
    skip 'DB::DuckDB 未安装，跳过 CSV 方言真实往返', 19;
}
else {
    my $semi = Rakuish::Data::open-data(
        $sys, 'semi.csv', :allow-external,
        :csv-options({ delimiter => ';' }));
    is $semi.elems, 3, '分号方言读到 3 行';
    is-deeply $semi.columns.List, <id name score>.List,
        '分号方言列名正确';
    is $semi.column-type('id'), 'int', 'DuckDB 推断 id 为 int';
    is $semi.column-type('score'), 'num', 'DuckDB 推断 score 为 num';

    my $nohead = Rakuish::Data::open-data(
        $sys, 'semi.csv', :allow-external,
        :csv-options({ delimiter => ';', header => False,
                       skip => 1, 'all-varchar' => True }));
    is $nohead.elems, 3, 'header=false + skip=1 得到 3 条数据行';
    is $nohead.columns[0], 'column0', '无表头时 DuckDB 生成 column0';
    is $nohead.column-type('column0'), 'str', 'all-varchar 让列保持 str';

    is Rakuish::Data::save-data(
           $sys, 'semi-out.csv', $semi, :allow-external,
           :csv-options({ delimiter => ';', header => False })), True,
        '方言写出返回 True';
    my @lines = $dir.add('semi-out.csv').slurp.lines;
    is @lines.elems, 3, '无表头写出只有 3 行数据';
    ok @lines[0].contains(';'), '写出使用分号分隔符';
    nok @lines[0].contains('id'), '写出没有表头行';

    my $back = Rakuish::Data::open-data(
        $sys, 'semi-out.csv', :allow-external,
        :csv-options({ delimiter => ';' }));
    is $back.elems, 3, '往返读回 3 行';

    my $engine = Rakuish::Data::Engine::DuckDB.new(
        :path<:memory:>, :safe(False), :!read-only);
    is $engine.read-csv($dir.add('semi.csv').Str,
                        :csv-options({ delimiter => ';' }),
                        :max-rows(2)).elems, 2,
        'Engine.read-csv 方言 + LIMIT 下推生效';
    throws-like { $engine.write-csv($dir.add('bad.csv').Str,
                                    'select 1; drop table t',
                                    :csv-options({ delimiter => ';' })) },
        X::Rakuish::Data, '方言写出仍拒绝含分号的导出 SQL';
    $engine.close;

    throws-like { Rakuish::Data::open-data(
                      $sys, 'semi.csv', :allow-external,
                      :csv-options({ bogus => 1 })) },
        X::Rakuish::Unsupported, '未知选项经 open-data 明确拒绝';
    throws-like { Rakuish::Data::open-data(
                      $sys, 'semi.csv', :allow-external,
                      :csv-options({ delimiter => "'; drop" })) },
        X::Rakuish::Unsupported, '注入式分隔符经 open-data 拒绝';
    throws-like { Rakuish::Data::open-data(
                      $sys, '../outside.csv', :allow-external,
                      :csv-options({ delimiter => ';' })) },
        X::Rakuish::Sandbox, '方言路径仍经 Sys root 校验';

    my $s2 = Rakuish::REPL::Session.new(:sys($sys));
    my $rr = $s2.eval-line(
        q{open-data('semi.csv', :allow-external, :csv-options({ delimiter => ';' }))});
    ok $rr.ok, 'REPL 里方言参数完整链路可用';
    is $rr.value.elems, 3, 'REPL 方言读取行数正确';
}

for <semi.csv plain.csv repl-out.csv semi-out.csv> -> $f {
    try { $dir.add($f).unlink }
}
try { $dir.rmdir };
done-testing;
