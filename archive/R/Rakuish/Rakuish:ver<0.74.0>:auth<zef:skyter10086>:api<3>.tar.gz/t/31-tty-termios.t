#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Sys::Proc;

# 31-tty-termios.t —— `tty-exec` 交接期间的宿主 termios 快照恢复
# （0.72.4 / ADR-0009 修订 / SPEC V-174）。
#
# 为什么不用 tools/tty-check.py 那套 raw 基线：raw 下 ICANON/ECHO/ISIG
# 全是 0，「污染前 / 污染后」位图相同，测不出恢复。这里用 Python pty
# 建一个 canonical 基线（显式开 ICANON|ECHO|ISIG），让子进程跑
# `stty raw -echo` 真的把宿主那份 termios 改掉。
#
# 三个场景：
#   1. 默认路径：tty-exec 返回后位图必须等于基线，Result 标记恢复成功；
#   2. 注入对照：子类覆盖 termios-snapshot 返回 Nil，同样污染必须留下
#      痕迹 —— 否则场景 1 可能只是「stty 没生效」的假绿；
#   3. 子进程非零退出：LEAVE 兜底仍要恢复。
# Windows 无 pty 模块，PTY 段整段 skip；非 TTY 的退化断言双平台都跑。

# ── 0. 不依赖 PTY 的安全退化 ─────────────────────────────────────────
my $plain = Rakuish::Sys::Proc.new;
nok $plain.termios-snapshot(-1).defined, 'fd 无效时快照安全返回 Nil';
nok $plain.termios-restore(Nil, -1), '无快照时恢复返回 False 且不抛';

my Bool $pty-ok = !$*DISTRO.is-win;
my Str $py = '';
if $pty-ok {
    my $probe = try {
        my $p = run('python3', '-c', 'import pty, termios; print("ok")', :out, :err);
        $p.out.slurp(:close).trim
    };
    $py = ($probe // '');
}

if $pty-ok && $py eq 'ok' {

    my IO::Path $tmp = $*CWD.add('tmp');
    $tmp.mkdir unless $tmp.e;
    my Str $tag = $*PID.Str;
    my $parent = $tmp.add("termios-parent-{$tag}.raku");
    my $driver = $tmp.add("termios-driver-{$tag}.py");

    $parent.spurt(q:to/PARENT/);
        use lib 'lib';
        use Terminal::API;
        use Rakuish::Sys::Proc;

        my $fd = $*IN.native-descriptor;
        sub bits(--> Str) {
            my $c = Terminal::API::get-config($fd);
            "{$c.lflag}:{$c.iflag}:{$c.oflag}:{$c.cc_VINTR}"
        }
        my $base-config = Terminal::API::get-config($fd);
        my $base = bits();
        say "PROBE base=$base";

        my $r1 = Rakuish::Sys::Proc.new.tty-exec(
            '/bin/sh', '-c', 'stty raw -echo; sleep 0.1');
        say "PROBE normal_after=" ~ bits();
        say "PROBE normal_restored=" ~ ($r1.value<termios-restored> // 'NA');
        say "PROBE normal_ok=" ~ $r1.ok;
        say "PROBE normal_op=" ~ $r1.op;

        class NoSnapshot is Rakuish::Sys::Proc {
            method termios-snapshot($fd) { Nil }
        }
        my $r2 = NoSnapshot.new.tty-exec(
            '/bin/sh', '-c', 'stty raw -echo; sleep 0.1');
        say "PROBE nosnap_after=" ~ bits();
        say "PROBE nosnap_restored=" ~ ($r2.value<termios-restored> // 'NA');

        Terminal::API::restore-config($base-config, $fd,
                                      :when(Terminal::API::DRAIN));
        my $r3 = Rakuish::Sys::Proc.new.tty-exec(
            '/bin/sh', '-c', 'stty raw -echo; exit 7');
        say "PROBE nonzero_after=" ~ bits();
        say "PROBE nonzero_code=" ~ $r3.code;
        say "PROBE nonzero_restored=" ~ ($r3.value<termios-restored> // 'NA');

        Terminal::API::restore-config($base-config, $fd,
                                      :when(Terminal::API::DRAIN));
        say "PROBE done=1";
        PARENT

    $driver.spurt(q:to/PYTHON/);
        import os, pty, select, subprocess, sys, termios, time

        root, raku, parent_rel = sys.argv[1], sys.argv[2], sys.argv[3]
        master, slave = pty.openpty()
        a = termios.tcgetattr(slave)
        a[3] |= termios.ICANON | termios.ECHO | termios.ISIG
        a[6][termios.VINTR] = b'\x03'
        a[6][termios.VEOF] = b'\x04'
        termios.tcsetattr(slave, termios.TCSANOW, a)

        proc = subprocess.Popen(
            [raku, '-Ilib', parent_rel], cwd=root,
            stdin=slave, stdout=slave, stderr=slave, close_fds=True)
        os.close(slave)

        out = bytearray()
        deadline = time.time() + 60
        while time.time() < deadline:
            readable, _, _ = select.select([master], [], [], 0.1)
            if readable:
                try:
                    data = os.read(master, 65536)
                except OSError:
                    break
                if not data:
                    break
                out.extend(data)
            if proc.poll() is not None and not readable:
                break
        if proc.poll() is None:
            proc.kill()
        os.close(master)
        sys.stdout.write(out.decode('utf-8', 'replace'))
        PYTHON

    my $ran = try {
        my $p = run('python3', $driver.Str, $*CWD.Str, $*EXECUTABLE.Str,
                    $parent.relative($*CWD).Str, :out, :err);
        ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
    };
    my Str $text = $ran // '';
    my %p;
    for $text.lines -> $line {
        next unless $line.starts-with('PROBE ');
        my @kv = $line.substr(6).split('=', 2);
        %p{@kv[0]} = (@kv[1] // '');
    }

    ok (%p<base> // '').contains(':'), 'canonical 基线的 termios 位图可读';
    is %p<normal_after>, %p<base>, '场景 1：子进程污染后，tty-exec 返回时已恢复';
    is %p<normal_restored>, 'True', '场景 1：Result.value 标记恢复成功';
    is %p<normal_ok>, 'True', '场景 1：直通本身仍成功';
    is %p<normal_op>, 'tty-exec', '场景 1：op 未变';
    ok (%p<nosnap_after> // '') ne (%p<base> // ''),
        '场景 2：禁用快照时污染确实留下痕迹（断言敏感）';
    is %p<nosnap_restored>, 'False', '场景 2：Result.value 不谎报已恢复';
    is %p<nonzero_after>, %p<base>, '场景 3：子进程非零退出，LEAVE 仍恢复';
    is %p<nonzero_code>, '7', '场景 3：非零退出码照常回传';
    is %p<nonzero_restored>, 'True', '场景 3：异常路径也标记恢复成功';
    is %p<done>, '1', '父脚本跑完（未被污染态卡住）';

    try { .unlink for ($parent, $driver) };
}
else {
    skip 'Windows / 无 pty 模块：termios 快照回归在 WSL 验收', 11;
}

done-testing;
