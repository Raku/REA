use Test;
use Rakuish::Sys::Proc;
use Rakuish::Result;

# 29-pty-capability.t —— 0.72.2 / AUDIT-FIXES-0.72.2
# R-1（能力探测，绝不静默当 PTY）+ R-3（先剥离后截断、结果标记）。
# 用子类覆盖 pty-capability 注入「旧 Rakudo」，无需真的装旧版。

my $dir = $*TMPDIR.IO.add("rakuish-pty-cap-{$*PID}");
$dir.mkdir;
LEAVE {
    try {
        for $dir.dir -> $e { $e.d ?? $e.rmdir !! $e.unlink }
        $dir.rmdir;
    }
}
my Str $EXE = $*EXECUTABLE.Str;

# ── 1. 当前环境：版本 + isatty 双检必须可用 ──────────────────────────
my $proc = Rakuish::Sys::Proc.new;
my %cap = $proc.pty-capability();
ok %cap<capable>, '本机 Rakudo 的 :pty 能力探测通过';
ok %cap<version>.chars, '探测结果带编译器版本';
is %cap<reason>, '', '能力可用时 reason 为空';
ok $proc.pty-capability<capable>, '进程级缓存返回同一结果';

# ── 2. 注入失败：明确失败、不启动子进程、不撒谎 ──────────────────────
class NoPtyProc is Rakuish::Sys::Proc {
    method pty-capability(--> Hash) {
        %(capable => False, version => 'v2025.11',
          reason  => 'stub: 旧 Rakudo 静默吞掉 :pty')
    }
}
my $bad = NoPtyProc.new.pty-exec($EXE, '-e', 'say "SHOULD-NOT-RUN"');
nok $bad.ok, '能力探测失败时 pty-exec 不成功';
is $bad.code, 127, '收敛成 code=127 的 Result（不抛穿 Agent）';
ok $bad.err.contains('PTY 不可用'), 'err 明确说明 PTY 不可用';
ok $bad.err.contains('stub'), 'err 带上探测 reason';
nok $bad.value<pty>, '不标 pty=True';
nok $bad.value<tty>, '不标 tty=True';
nok $bad.value<pty-capable>, 'pty-capable 为假';
nok $bad.out.contains('SHOULD-NOT-RUN'), '失败时根本没有启动子进程';
ok $bad.value<reason>.contains('stub'), 'value 保留失败原因';

# ── 3. 成功路径：把 PTY 的结构性事实写进 value ───────────────────────
my $ok = $proc.pty-exec($EXE, '-e', 'say "CAP-OK"', :timeout-ms(8000));
ok $ok.ok, '能力可用时 pty-exec 成功';
like $ok.out, /'CAP-OK'/, '仍捕获 stdout';
ok $ok.value<pty-capable>, 'value<pty-capable> 为真';
ok $ok.value<stderr-merged>, '标记 stderr 已合流（err 恒空不是遗漏）';
ok $ok.value<stdin-unavailable>, '标记 stdin 不可写（不是完整交互会话）';
is $ok.value<strip-ansi>, True, '标记默认剥离 ANSI';

# ── 4. 先剥离后截断：不再残留半截 CSI 序列 ───────────────────────────
for 62, 63, 64, 70 -> $cap-bytes {
    my $cut = $proc.pty-exec($EXE, '-e',
        q{print 'A' x 60; print "\e[31mRED\e[0m"; print 'B' x 60;},
        :timeout-ms(8000), :max-bytes($cap-bytes));
    ok $cut.out.chars <= $cap-bytes, "max-bytes=$cap-bytes 限制生效";
    nok $cut.out.contains("\e") || $cut.out.contains('['),
        "max-bytes=$cap-bytes 剥离后不残留控制序列碎片";
    ok $cut.value<truncated>, "max-bytes=$cap-bytes 标记 truncated";
}

# ── 5. 显式 :!strip-ansi 仍保留原始控制序列 ──────────────────────────
my $raw = $proc.pty-exec($EXE, '-e', 'say "\e[31mRED\e[0m";',
    :timeout-ms(8000), :!strip-ansi);
ok $raw.out.contains("\e["), '关闭剥离时保留 CSI 序列';
is $raw.value<strip-ansi>, False, 'value 标记 strip-ansi=False';

# ── 6. 大输出冒烟（tap 内不再反复拼接全量字符串）────────────────────
# 不断言「字节完整」：Windows ConPTY 在大输出时可能在驱动层丢尾部 chunk
# （裸 Proc::Async + Supply done 也能复现，等待无用；Linux 无此现象）。
# 这里只钉住「不崩、返回主要部分、未误报 truncated」。
my $big = $proc.pty-exec($EXE, '-e', 'print "x" x 400000;',
    :timeout-ms(30000), :max-bytes(2 * 1024 * 1024));
ok $big.ok, '400KB 输出仍成功返回';
ok $big.out.chars > 100000, "大输出捕获到主要部分（实际 {$big.out.chars} chars）";
nok $big.value<truncated>, '未超限时 truncated 为假';

done-testing;
