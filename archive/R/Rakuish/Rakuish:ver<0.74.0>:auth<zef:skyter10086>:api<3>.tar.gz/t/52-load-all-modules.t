use Test;

# ══════════════════════════════════════════════════════════════════
# 52-load-all-modules.t —— 跨平台冒烟：lib 下每个模块都必须能被 require
# ══════════════════════════════════════════════════════════════════
# 存在的理由：编译期错误（编译单元本身挂掉）一旦发生在底层模块里，会顺着
# 依赖链把十几个上层模块一起带死；而 POSIX 专用用例在 Windows 上整文件
# SKIP，Windows 侧就永远看不到这类问题。本文件不依赖任何 POSIX 命令、
# 不执行平台动作，两平台都照跑，且 14 个失败用例当场点名"谁编译不过"。
#
# ⚠ 用运行时 require 而不是编译期 use：Engine / Builtins 那群模块在 Windows
#   上编译期 need 会 precomp 互锁挂死，require 逐个加载才是安全的。

# 仓库根：Windows 上 $?FILE 会丢盘符，靠 CWD 向上找 META6.json 推算。
sub repo-root(--> IO::Path) {
    my $d = $*CWD;
    loop {
        return $d if $d.add('META6.json').e;
        my $up = $d.parent;
        return $*CWD if $up.Str eq $d.Str;
        $d = $up;
    }
}

my $root = repo-root();
my $lib  = $root.add('lib');

sub mod-name(IO::Path $f --> Str) {
    $f.relative($lib).Str.subst('\\', '/', :g)
     .subst(/ '.rakumod' $/, '').subst('/', '::', :g)
}

my @mods;
sub walk(IO::Path $d) {
    for $d.dir {
        when .d { walk($_) }
        when .f { @mods.push: mod-name($_) if .extension eq 'rakumod' }
    }
}
walk($lib);
@mods = @mods.sort;

# 平台专属后端在"对面"平台上同样必须能加载（模块只定义类，不执行平台动作）。
plan @mods.elems + 1;

ok @mods.elems > 0, "扫到 {+@mods} 个模块（lib/ 递归）";

my $failed = 0;
for @mods -> $m {
    my Bool $loaded = True;
    my Str  $err    = '';
    {
        require ::($m);
        CATCH {
            default {
                $loaded = False;
                $err = .message.subst(/\s+/, ' ', :g);
                $err = $err.substr(0, 200) ~ '…' if $err.chars > 200;
            }
        }
    }
    $failed++ unless $loaded;
    ok $loaded, "require $m" ~ ($loaded ?? '' !! " ⇒ $err");
}

diag "共 {+@mods} 个模块，加载失败 $failed 个";
