use Test;
use Rakuish::Sys;
use Rakuish::REPL::Session;

# t/10 —— REPL 的日常 shell 观感层
# 目标：cd/ls/cat/rm/cp/... 的常用写法符合用户习惯，但底层仍是 Sys。

my $base = $*TMPDIR.IO.add("rakuish-shell-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my $s = Rakuish::REPL::Session.new(:sys($sys));

sub out(Str $line --> Str) { $s.render($s.eval-line($line)) }

$base.add('a.txt').spurt("one\ntwo\nthree\n");
$base.add('b.md').spurt('md');
$base.add('big.txt').spurt('x' x 2048);
$base.add('.hidden').spurt('h');
$base.add('sub').mkdir;
$base.add('sub/c.txt').spurt('c');
$base.add('data.json').spurt('[{"name":"x","size":1}]');
$base.add('ADR-0001.md').spurt('adr text');

# ── cd / pwd / ls ────────────────────────────────────────────────────
is out('pwd').subst('\\', '/', :g),
    $base.Str.subst('\\', '/', :g), 'pwd 输出当前目录';
is out('cd sub'), '', 'cd 成功且安静（shell 习惯）';
is $s.sys.cwd.Str.subst('\\', '/', :g),
    $base.add('sub').Str.subst('\\', '/', :g), 'cd 真的切到 sub';
is out('pwd').subst('\\', '/', :g),
    $base.add('sub').Str.subst('\\', '/', :g), 'cd 后 pwd 正确';
is out('cd -'), '', 'cd - 成功且安静';
is $s.sys.cwd.Str.subst('\\', '/', :g),
    $base.Str.subst('\\', '/', :g), 'cd - 回到上一个目录';

my Str $ls = out('ls');
like $ls, /'a.txt'/, 'ls 列出文件';
nok $ls.contains('IO::Path'), 'ls 不显示 IO::Path';
nok $ls.contains('Out['), 'ls 不套 Out[n]';
like out('ls -a'), /'.hidden'/, 'ls -a 列出隐藏项';
ok out('ls -F').contains('sub/'), 'ls -F 给目录加 /';
like out('ls -l'), /'a.txt'/, 'ls -l 显示长格式';
like out('ls -alh'), /'2.0K'/, 'ls -alh 支持人类可读大小';
ok out('ls -d sub').contains('sub'), 'ls -d 只列目录本身';
like out('ls *.md'), /'b.md'/, 'ls 展开 glob';
like out('ls **/*.txt'), /'c.txt'/, 'ls 支持 globstar **/';
like out('ls a.txt b.md'), /'a.txt'/, 'ls 支持多个路径（1）';
like out('ls a.txt b.md'), /'b.md'/, 'ls 支持多个路径（2）';
is out('clear'), '', 'clear 在非 TTY 下不输出控制码';

# ── 结构化 open / ls --json ───────────────────────────────────────────
like out('open data.json'), /'name'/ && /'x'/, 'open json 渲染为表格';
like out('open --raw data.json'), /'"name"'/, 'open --raw 保留原始文本';
like out('ls --json data.json'), /'"type": "file"'/, 'ls --json 输出结构化字段';
like out('help open'), /^ '用法: open'/, 'open --help/help 有用法';

# ── 内置命令帮助 ────────────────────────────────────────────────────
like out('ls --help'), /^ '用法: ls'/, 'ls --help 显示用法';
like out('ls --help'), /'-h'/, 'ls --help 列出 -h';
like out('rm --help'), /^ '用法: rm'/, 'rm --help 显示用法';
like out('help cp'), /^ '用法: cp'/, 'help cp 显示用法';
like out('help'), /'Shell 日常命令'/, 'help 列出全部命令组';
like out('help read'), /^ '用法: read'/, 'help read 覆盖 Raku API';
like out('help --find 读取'), /'read'/, 'help --find 搜索用法';
like out('which ls'), /'shell: ls'/, 'which 查 Shell 内置';
like out('which definitely-missing'), /'未找到'/, 'which 未找到报错';
like out('read --help'), /^ '用法: read'/, 'read --help 也可用';
like out('env --help'), /^ '用法: env'/, 'env --help 也可用';
nok out('ls --help').contains('IO::Path'), '帮助不显示对象结构';

# ── cat / head / tail / echo ─────────────────────────────────────────
is out('cat a.txt'), "one\ntwo\nthree", 'cat 原样输出（显示层去掉末尾换行）';
is out('read ADR-0001.md'), 'adr text', 'read 按 shell 路径读取（带连字符）';
is out('head -n 2 a.txt'), "one\ntwo", 'head -n 输出前两行';
is out('tail -n 1 a.txt'), 'three', 'tail -n 输出最后一行';
is out('echo hello world'), 'hello world', 'echo 输出参数';
is out('echo -n hi'), 'hi', 'echo -n 不追加换行';
is out('echo "a;b"'), 'a;b', '引号内标点作为字面参数';
is out('echo "file(1).txt"'), 'file(1).txt', '引号内括号作为字面参数';

# ── mkdir / touch / cp / mv / rm ────────────────────────────────────
is out('mkdir -p d/e'), '', 'mkdir 成功且安静';
ok $base.add('d/e').d, 'mkdir 真的建好了';
is out('touch t.txt'), '', 'touch 成功且安静';
ok $base.add('t.txt').e, 'touch 创建空文件';
is out('cp a.txt c.txt'), '', 'cp 成功且安静';
is $base.add('c.txt').slurp, "one\ntwo\nthree\n", 'cp 内容正确';
is out('cp -r d d2'), '', 'cp -r 成功且安静';
ok $base.add('d2/e').d, 'cp -r 复制了子目录';
is out('mv c.txt m.txt'), '', 'mv 成功且安静';
ok $base.add('m.txt').e, 'mv 目标存在';
nok $base.add('c.txt').e, 'mv 源消失';
is out('rm -rf d2'), '', 'rm -rf 成功且安静';
nok $base.add('d2').e, 'rm -rf 真的删了';
is out('rm -f missing.txt'), '', 'rm -f 不存在也成功且安静';

# ── export / unset / glob ───────────────────────────────────────────
is out('export RAKUISH_SHELL_X=yes'), '', 'export 成功且安静';
is $sys.get-env('RAKUISH_SHELL_X'), 'yes', 'export 真的写进会话环境';
is out('echo $RAKUISH_SHELL_X'), 'yes', '参数里的 $NAME 按会话 env 展开';
is out('unset RAKUISH_SHELL_X'), '', 'unset 成功且安静';
nok $sys.get-env('RAKUISH_SHELL_X').defined, 'unset 真的删了';
like out('glob *.md'), /'b.md'/, 'glob 输出 basename';
is out('grep two a.txt'), 'two', 'grep 逐行匹配';
is out('grep -n three a.txt'), '3:three', 'grep -n 带行号';
is out('grep "^one" a.txt'), 'one', 'grep 支持正则锚点';
is out('grep -F "^one" a.txt'), '', 'grep -F 按字面匹配';
is out('grep -i ONE a.txt'), 'one', 'grep -i 忽略大小写';
is out('wc -l a.txt'), '3 a.txt', 'wc -l 统计行数并带文件名';
like out('history'), /'pwd'/, 'history 显示本会话命令';

# ── Tab 补全 provider ────────────────────────────────────────────────
ok $s.completions('c', 1).List.grep(* eq 'cat ').elems == 1, '命令名补全 cat';
ok $s.completions('ls ', 3).List.grep(* eq 'ls a.txt').elems == 1,
    '路径补全 a.txt';
nok $s.completions('ls ', 3).List.grep(* eq 'ls .hidden').elems,
    '默认不补全隐藏项';
ok $s.completions('help ', 5).List.grep(* eq 'help ls ').elems == 1,
    'help 补全命令名';

# ── jobs shell 视图 ─────────────────────────────────────────────────
my $jh = $s.sys.spawn($*EXECUTABLE.Str, '-e', 'sleep 1');
like out('jobs'), /'running'/, 'jobs 列出后台进程';
ok $s.sys.cancel($jh), '取消后台进程';
like out('jobs'), /'没有后台任务'/, '取消后 jobs 为空';

# ── Raku 变量参数不被 shell 层误吞 ──────────────────────────────────
$base.add('var-file.txt').spurt('v');
$s.eval-line('my $vp = "var-file.txt";');
is out('cat $vp'), 'v', '带 $var 的 cat 交回 Raku 变量';
$s.eval-line('my $ev = "hello-var";');
is out('echo $ev'), 'hello-var', '带 $var 的 echo 交回 Raku 变量';

done-testing;
