#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys;
use Rakuish::DSL;
use Rakuish::Sandbox;
use Rakuish::REPL::Session;
use Rakuish::REPL::Hints;

# 26-nested-repl.t —— 交互式子进程的 TTY 直通（0.70.0 / ADR-0007）
#
# 断言纪律：
#   1. 非 TTY 下必须明确拒绝，绝不悄悄退化成 30s 捕获式执行；
#   2. `! --tty` / `-t` / `--` 是 ! 分发层的元选项，不进入子进程 argv；
#   3. 默认 `!` 的超时 / 捕获语义一字未改；
#   4. Agent op 白名单不暴露交互式入口；
#   5. 真 PTY 集成只在有 pty 的平台跑（Windows 跳过），用真实子进程验证
#      首字符不被吞、输出实时、退出码回传。

my IO::Path $dir = $*TMPDIR.IO.add("rakuish-v3-tty-{$*PID}");
$dir.mkdir;
my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
my $session = Rakuish::REPL::Session.new(:sys($sys));

# ── 1. 非 TTY 守卫 ──────────────────────────────────────────────────
{
    my Str $err = '';
    try {
        $sys.tty-exec($*EXECUTABLE.Str, '-e', 'say 1');
        CATCH { default { $err = .message } }
    }
    ok $err.contains('TTY'), 'Sys.tty-exec 在无 TTY 时抛明确错误';
    ok $err.contains('exec(...)'), '错误指向普通 exec(...) 的退路';
}

{
    my Str $line = "! --tty {$*EXECUTABLE.Str} -e 'say 1'";
    my $t0 = now;
    my $r = $session.eval-line($line);
    ok !$r.ok, '! --tty 在非 TTY 下不成功';
    is $r.code, 127, '! --tty 收敛成 code=127 的 Result（不抛穿 eval-line）';
    is $r.op, 'tty-exec', 'op 标记为 tty-exec';
    ok $r.err.contains('TTY'), '错误信息说明需要 TTY';
    ok (now - $t0) < 2, '没有卡住等待超时';
}

{
    my $r = $session.eval-line("! -t {$*EXECUTABLE.Str} -e 'say 1'");
    is $r.code, 127, '-t 别名同样走 TTY 守卫';
    ok $r.err.contains('TTY'), '-t 的错误信息一致';
}

{
    my $r = $session.eval-line('! --tty');
    is $r.code, 127, '光秃秃的 ! --tty 报「没有命令」';
    ok $r.err.contains('没有命令'), '错误信息是缺命令而不是 TTY';
}

# cwd 仍过 Sys.resolve 的 root 校验（不因新入口绕过沙箱）。
throws-like { $sys.tty-exec($*EXECUTABLE.Str, '-e', 'say 1',
                            :cwd('../outside')) },
            X::Rakuish::Sandbox,
            'TTY 入口的 cwd 仍受 root 校验';

# ── 2. 元选项解析：-- 之后全按字面 argv ──────────────────────────────
{
    my $r = $session.eval-line("! -- {$*EXECUTABLE.Str} -e 'say 42'");
    ok $r.ok, '! -- 走普通捕获式 exec';
    is $r.code, 0, '退出码 0';
    ok $r.out.contains('42'), '输出被正常捕获';
    is $r.op, 'exec', 'op 仍是 exec，不是 tty-exec';
}

# ── 3. 默认 ! 的超时/捕获语义不变 ────────────────────────────────────
{
    # 故意不依赖 stdin：CI / heredoc 下 stdin 可能立即 EOF，
    # 用 sleep 才能保证「子进程不会自己结束」这个前提成立。
    my $child = q:to/CHILD/;
        say 'NESTED-READY';
        sleep 3;
        say 'SHOULD-NOT-APPEAR';
        CHILD
    my $r = $sys.exec($*EXECUTABLE.Str, '-e', $child, :timeout-ms(400));
    is $r.code, 124, '默认捕获式 exec 仍按超时返回 124';
    ok !$r.ok, '超时结果是失败格';
    ok $r.out.contains('NESTED-READY'), '输出被 Channel 捕获到进程结束才交付';
    is $sys.proc.default-timeout-ms, 30_000, '默认超时仍是 30s';
}

# ── 4. 超时提示把用户引到新入口 ──────────────────────────────────────
{
    my $timeout = Result.new(:!ok, :code(124), :op<exec>, :out('x'));
    my $advice = result-hint($timeout, '! rakupp');
    ok $advice.contains('tty-exec'), '! 命令超时提示指向 tty-exec';
    ok $advice.contains('--tty'), '提示同时给出 ! --tty 写法';
    is result-hint($timeout, 'sleep 100'), '', '非 ! 输入不误报交互式提示';
    ok hint-for('! --tty rakupp').contains('TTY'), 'hint-for 识别 --tty 元选项';
    ok hint-for('! git status').contains('argv-only'), '普通 ! 的提示未改变';
}

# ── 5. Agent 边界 ────────────────────────────────────────────────────
{
    my $sb = Rakuish::Sandbox.new(:root($dir), :token('TOKEN'));
    ok $sb.op-allowed('exec'), 'Agent 仍允许受控 exec';
    nok $sb.op-allowed('tty_exec'), 'Agent op 白名单不含 tty_exec';
    nok $sb.op-allowed('tty-exec'), 'Agent op 白名单不含 tty-exec';
}

# ── 6. 真 PTY 集成（无 pty 的平台跳过）────────────────────────────────
# 用 Python 的 pty 起一个真终端，让 Raku 父进程调用 Sys.tty-exec 拉起
# 「嵌套 REPL」替身；验证 stdin 直通、首字符不丢、退出码回传。
{
    my Bool $pty-ok = !$*DISTRO.is-win;
    my $py = '';
    if $pty-ok {
        my $probe = try {
            my $p = run('python3', '-c', 'import pty; print("ok")', :out, :err);
            $p.out.slurp(:close).trim
        };
        $py = ($probe // '');
    }
    if $pty-ok && $py eq 'ok' {

        my IO::Path $tmp = $*CWD.add('tmp');
        $tmp.mkdir unless $tmp.e;
        my Str $tag = $*PID.Str;
        my $child  = $tmp.add("tty-child-{$tag}.raku");
        my $parent = $tmp.add("tty-parent-{$tag}.raku");
        my $driver = $tmp.add("tty-driver-{$tag}.py");
        my $raku   = $tmp.add("tty-raku-{$tag}.txt");

        $child.spurt(q:to/CHILD/);
            say 'NESTED-READY tty=' ~ $*IN.t;
            loop {
                my $l = $*IN.get;
                last unless $l.defined;
                last if $l.trim eq 'exit';
                say "NESTED-GOT[$l]";
            }
            say 'NESTED-BYE';
            CHILD

        # 父进程：只经由 Sys 调用 tty-exec，别引入 REPL / 行编辑器。
        $parent.spurt(
            'use lib "lib";' ~ "\n"
            ~ 'use Rakuish::Sys;' ~ "\n"
            ~ 'my $child = $*CWD.add("' ~ $child.relative($*CWD).subst(:g, '\\', '/') ~ '");' ~ "\n"
            ~ 'my $r = Rakuish::Sys.new(:root($*CWD), :cwd($*CWD))'
              ~ '.tty-exec($*EXECUTABLE.Str, $child.Str);' ~ "\n"
            ~ 'say "PARENT ok={$r.ok} code={$r.code} op={$r.op}";' ~ "\n"
        );

        $raku.spurt($*EXECUTABLE.Str);

        $driver.spurt(q:to/PYTHON/);
            import os, pty, select, subprocess, sys, time, tty
            here = os.path.dirname(os.path.abspath(__file__))
            root = os.path.dirname(here)
            tag = os.path.basename(sys.argv[0]).replace('tty-driver-', '').replace('.py', '')
            raku = open(os.path.join(here, 'tty-raku-%s.txt' % tag)).read().strip()
            master, slave = pty.openpty()
            tty.setraw(slave)
            proc = subprocess.Popen(
                [raku, '-Ilib', os.path.join('tmp', 'tty-parent-%s.raku' % tag)],
                cwd=root, stdin=slave, stdout=slave, stderr=slave, close_fds=True)
            os.close(slave)
            out = bytearray()
            deadline = time.time() + 25
            sent = False
            while time.time() < deadline:
                readable, _, _ = select.select([master], [], [], 0.1)
                if readable:
                    try:
                        data = os.read(master, 65536)
                    except OSError:
                        break
                    if not data:
                        break
                    out.extend(data)
                if not sent and time.time() > deadline - 23:
                    os.write(master, b'hello\nexit\n')
                    sent = True
                if proc.poll() is not None and not readable:
                    break
            if proc.poll() is None:
                proc.kill()
            os.close(master)
            sys.stdout.write(out.decode('utf-8', 'replace'))
            PYTHON

        my $ran = try {
            my $p = run('python3', $driver.Str, :out, :err);
            ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
        };
        my Str $text = $ran // '';
        ok $text.contains('NESTED-READY tty=True'),
            '真 PTY：子进程拿到的是 TTY';
        ok $text.contains('NESTED-GOT[hello]'),
            '真 PTY：stdin 直通且首字符未被吞';
        ok $text.contains('NESTED-BYE'), '真 PTY：子进程正常退出';
        ok $text.contains('PARENT ok=True code=0 op=tty-exec'),
            '真 PTY：退出码与 op 回传父进程';

        # 清理本测试生成的临时文件（只删自己 PID 命名的那几个）。
        try { .unlink for ($child, $parent, $driver, $raku) };
    }
    else {
        skip '本机 Python 无 pty 模块（Windows）；真 TTY 集成由 tools/tty-check.py 人工验收', 4;
    }
}

done-testing;
