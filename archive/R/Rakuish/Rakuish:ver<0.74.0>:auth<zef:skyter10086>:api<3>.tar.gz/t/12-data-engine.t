use Test;
use Rakuish::Result;
use Rakuish::Data::Engine::DuckDB;
use Rakuish::Data::Table;

# t/12 —— DuckDB 数据引擎适配器（可选依赖）
# 没安装 DB::DuckDB 时如实 skip，不让核心测试失败。

my $mod = try { require ::('DB::DuckDB') };
my Bool $have = try { $mod.^name eq 'DB::DuckDB' } // False;

if !$have {
    skip 'DB::DuckDB 未安装，跳过 DuckDB 引擎测试', 11;
    done-testing;
}
else {
    my $ro = Rakuish::Data::Engine::DuckDB.new;
    my $t = $ro.query('select 1 as n, 2 as m');
    isa-ok $t, Rakuish::Data::Table, 'query 返回 Table';
    is $t.get('n').List, (1,), 'query 列值';
    is $ro.query(q{select 'copy' as x}).get('x').List, ('copy',),
        'DuckDB 字符串里的 write 关键字不误拒';
    throws-like { $ro.execute('create table t (x int)') },
        X::Rakuish::Unsupported, '只读引擎拒绝 execute';
    throws-like { $ro.query('create table t (x int)') },
        X::Rakuish::Unsupported, '只读引擎拒绝 DDL query';
    my $outside-csv = $*TMPDIR.add("duck-safe-{$*PID}.csv");
    $outside-csv.spurt("x\n1\n");
    my Str $csv-path = $outside-csv.Str.subst(:g, '\\', '/')
        .subst("'", "''", :g);
    dies-ok {
        $ro.query("select * from read_csv_auto('{$csv-path}')")
    }, '默认 safe DuckDB 真应用 enable_external_access=false';
    try { $outside-csv.unlink };
    $ro.close;

    my $db = Rakuish::Data::Engine::DuckDB.new(:!read-only, :!safe);
    is $db.execute('create table t (x int)'), 0, '建表';
    is $db.execute('insert into t values (1), (2)'), 2, '插入行数';
    is $db.query('select * from t order by x').get('x').List, (1, 2),
        '查询写后的数据';
    is $db.query('select * from t order by x;', :max-rows(1)).elems, 1,
        'DuckDB :max-rows 下推且容忍尾分号';
    like $db.tables.to-text, /'t'/, 'tables 列出表';
    like $db.schema('t').to-text, /'x'/, 'schema 列出列';
    $db.execute('create table tx (x int)');
    $db.begin;
    $db.execute('insert into tx values (1)');
    $db.rollback;
    is $db.query('select count(*) as n from tx').get('n').List, (0,),
        'DuckDB rollback';
    $db.begin;
    $db.execute('insert into tx values (2)');
    $db.commit;
    is $db.query('select count(*) as n from tx').get('n').List, (1,),
        'DuckDB commit';
    $db.close;

    my $timed = Rakuish::Data::Engine::DuckDB.new(
        :max-execution-time-ms(50));
    dies-ok {
        $timed.query('select sum(sqrt(i::DOUBLE)) from range(1000000000) t(i)')
    }, 'DuckDB max_execution_time 中断慢查询';
    $timed.close;
    done-testing;
}
