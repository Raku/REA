#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys;

# 03-sys-proc.t —— API v3 进程 API 契约（ADR-0001 / Phase 2）
#
# 断言纪律：每条「不含 X」配一条「必须含 Y」；失败路径断言的是
# 结构化结果（code / value），不是 stderr 文案。

sub rmtree(IO::Path $d) {
    return unless $d.e || $d.l;
    unless $d.l {
        for (try { $d.dir } // ()) -> $c { rmtree($c) }
    }
    $d.d ?? (try $d.rmdir) !! (try $d.unlink);
}

my IO::Path $base = $*TMPDIR.IO.add("rakuish-v3-proc-{$*PID}");
$base.mkdir;
$base.add('work').mkdir;
END { rmtree($base) if $base.e }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my Str $R = $*EXECUTABLE.Str;       # 用当前解释器，避免依赖 PATH 里有没有 raku

# ── 基础执行 ──────────────────────────────────────────────────────────
isa-ok $sys, Rakuish::Sys, 'Sys 构造成功（已装配 Proc）';
my $r = $sys.exec($R, '-e', 'say "hello 中文"; note "errline"');
isa-ok $r, Result, 'exec 返回 Result';
ok $r.ok, '正常执行 ok=True';
is $r.code, 0, '正常执行 code=0';
is $r.out.trim, 'hello 中文', 'stdout 中文 UTF-8 无损';
is $r.err.trim, 'errline', 'stderr 与 stdout 分离';
is $r.lines.elems, 1, 'Result.lines 可用';
ok $r.value<exe>.chars > 0, 'value 记录 exe';
is $r.value<argv>.elems, 2, 'value 记录 argv';
ok $r.elapsed.defined, 'Result 记录耗时';
is $r.to-hash<op>, 'exec', 'Result 可序列化为 op';

# ── 会话级 cwd / env（V3 的核心承诺）─────────────────────────────────
my Str $host-cwd = $*CWD.Str;
my Str $k = 'RAKUISH_V3_PROC_TEST';
%*ENV{$k}:delete;
$sys.set-env($k, 'session-value');
$sys.cd('work');
my $s1 = $sys.exec($R, '-e', 'say %*ENV<RAKUISH_V3_PROC_TEST> // "none"; say $*CWD.Str');
my @lines = $s1.out.lines;
is @lines[0], 'session-value', '会话 env 显式传给子进程';
ok @lines[1].subst(:g, '\\', '/').ends-with('/work'), '会话 cwd 显式传给子进程';
is $*CWD.Str, $host-cwd, '宿主 $*CWD 未被改变（关键）';
nok %*ENV{$k}:exists, '宿主 %*ENV 未被改变（关键）';
$sys.cd('..');

my $other = Rakuish::Sys.new(:root($base), :cwd($base));
my $s2 = $other.exec($R, '-e', 'say %*ENV<RAKUISH_V3_PROC_TEST> // "none"');
is $s2.out.trim, 'none', '另一个会话看不到本会话 env';

my $s3 = $sys.exec($R, '-e', 'say %*ENV<RAKUISH_V3_PROC_TEST> // "none"',
                   :env(%( $k => 'override', |%*ENV )));
is $s3.out.trim, 'override', '显式 :env 覆盖会话 env';
my $s4 = $sys.exec($R, '-e', 'say $*CWD.Str', :cwd($base.add('work')));
ok $s4.out.trim.subst(:g, '\\', '/').ends-with('/work'), '显式 :cwd 覆盖会话 cwd';

# ── argv 注入防护：元字符一律不解释 ───────────────────────────────────
my @evil = '$(echo pwned)', 'a;b', 'x|y', '*.txt', '>pwned.txt', '&& echo bad', '$HOME';
my $inj = $sys.exec($R, '-e', 'say @*ARGS.join("|")', |@evil);
is $inj.out.trim, @evil.join('|'), 'shell 元字符全部原样作为 argv';
nok $base.add('pwned.txt').e, '> 没被解释成重定向（没产生文件）';
is $inj.value<argv>.elems, @evil.elems + 2, 'argv 数量与传入一致';

# ── stdin ─────────────────────────────────────────────────────────────
my $si = $sys.exec($R, '-e', 'say $*IN.slurp.uc', :in("héllo 中文\n"));
is $si.out.trim, 'HÉLLO 中文', 'stdin 中文往返';

# ── 退出码与启动失败 ─────────────────────────────────────────────────
my $ex = $sys.exec($R, '-e', 'exit 3');
nok $ex.ok, '非 0 退出 ok=False';
is $ex.code, 3, '退出码原样透传';

my $bad = $sys.exec('definitely-not-a-real-exe-xyz', 'arg');
nok $bad.ok, '命令不存在 ok=False';
is $bad.code, 127, '命令不存在 code=127（不是超时）';
ok $bad.err.chars > 0, '命令不存在保留错误原因';
ok $bad.value<start-failed>, 'value 标记 start-failed';
nok $bad.value<timed-out>, '命令不存在不被误判为超时';
is $sys.exec('', 'arg').code, 127, '空 exe 收敛成 Result 而非抛异常';

# ── timeout / cancel ─────────────────────────────────────────────────
my $to = $sys.exec($R, '-e', 'sleep 20', :timeout-ms(400));
nok $to.ok, '超时 ok=False';
is $to.code, 124, '超时 code=124';
ok $to.value<timed-out>, 'value 标记 timed-out';
nok $to.value<start-failed>, '超时不是启动失败';
ok $to.elapsed < 15, '超时真的终止了进程（没挂死）';

my $h = $sys.spawn($R, '-e', 'sleep 20');
ok $h.defined, 'spawn 返回句柄';
isa-ok $h.stdout, Supply, '句柄暴露 stdout Supply（真流式）';
ok $sys.cancel($h), 'cancel 成功';
my $cr = $sys.wait($h);
nok $cr.ok, 'cancel 后 wait 的 ok=False';
is $cr.code, 137, 'cancel 后 code=137';
ok $cr.value<cancelled>, 'value 标记 cancelled';
nok $sys.cancel($h), '对已结束句柄 cancel 返回 False';

# ── jobs 视图：spawn 注册、wait/cancel 清理 ─────────────────────────
my $jh = $sys.spawn($R, '-e', 'sleep 20');
is $sys.jobs.elems, 1, 'spawn 注册为后台 job';
is $sys.jobs.get('status').List, ('running',), 'job 状态 running';
my $jid = $sys.jobs.get('id').List[0];
ok $sys.job($jid).defined, 'job(id) 取回句柄';
ok $sys.cancel($jh), '取消后台 job';
is $sys.jobs.elems, 0, 'cancel 后 job 清理';

# ── 输出上限（按 UTF-8 字节，且不切坏多字节字符）─────────────────────
my $cap = $sys.exec($R, '-e', 'say "x" x 100', :max-bytes(10));
is $cap.out.trim.chars, 10, 'stdout 按字节上限裁剪';
ok $cap.value<truncated>, 'value 标记 truncated';
my $cap2 = $sys.exec($R, '-e', 'say "中文" x 40', :max-bytes(7));
ok $cap2.value<truncated>, '中文输出超限被标记';
ok $cap2.out.chars > 0 && $cap2.out.chars < 80, '裁剪结果是有效前缀';
ok $cap2.out.encode('utf-8').elems <= 7, '裁剪不切坏 UTF-8 且不超过字节上限';

# 无限输出必须在达到 max-bytes 时被杀，而不是先吃满内存/等到超时
my $inf = $sys.exec($R, '-e', 'loop { print "x" x 1000 }',
                    :max-bytes(128), :timeout-ms(5000));
ok $inf.value<truncated>, '无限输出被标记 truncated';
ok $inf.out.encode('utf-8').elems <= 128, '无限输出按字节上限截断';

# ── Result.Bool ──────────────────────────────────────────────────────
ok Result.new(:ok).Bool, 'Result.Bool 成功为 True';
nok $bad.Bool, 'Result.Bool 失败为 False（可直接用 && 短路）';

done-testing;
