use Test;

# 15-repl-ui.t —— 界面展示层与计时能力（0.62.0）
#
# 全部是纯函数 / 会话对象的断言，不依赖 TTY：管道下 Chrome 也必须给出
# 无 ANSI 的纯文本，颜色只在显式开启时出现。

use Rakuish::REPL::Chrome;
use Rakuish::REPL::Session;
use Rakuish::DSL;
use Rakuish::Sys;

# 颜色测试必须独立于宿主环境；CI / 终端可能预置 NO_COLOR=1。
my $saved-no-color = %*ENV<NO_COLOR>;
my $saved-force-color = %*ENV<FORCE_COLOR>;
%*ENV<NO_COLOR>:delete;
%*ENV<FORCE_COLOR>:delete;
LEAVE {
    %*ENV<NO_COLOR> = $saved-no-color if $saved-no-color.defined;
    %*ENV<FORCE_COLOR> = $saved-force-color if $saved-force-color.defined;
}

# ── 颜色能力 ────────────────────────────────────────────────────────
nok color-mode('auto', :tty(False)), '非 TTY 自动关闭颜色';
ok  color-mode('auto', :tty(True)),  'TTY 下 auto 开启颜色';
nok color-mode('off',  :tty(True)),  '配置 off 覆盖 TTY';
ok  color-mode('on',   :tty(True)),  '配置 on 在 TTY 下开启';
nok color-mode('on',   :tty(False)), '非 TTY 时 on 也不输出颜色';

{
    temp %*ENV<NO_COLOR> = '1';
    nok color-mode('on', :tty(True)), 'NO_COLOR 强制关闭颜色';
}
{
    temp %*ENV<FORCE_COLOR> = '1';
    ok color-mode('off', :tty(False)), 'FORCE_COLOR=1 强制开启颜色';
}

# ── banner ──────────────────────────────────────────────────────────
my Str $plain-banner = banner-text(:version<9.9.9>, :cwd('C:/work/rakuish'));
my Str $color-banner = banner-text(:version<9.9.9>, :cwd('C:/work/rakuish'),
                                   :color);
like $plain-banner, /'  Rakuish'/, 'banner 是极简字标，不拼大字';
like $plain-banner, /'9.9.9'/,      'banner 带版本';
like $plain-banner, /'─'/,          'banner 带细分割线';
like $plain-banner, /\d**4 '-' \d**2 '-' \d**2/, 'banner 带日期';
nok $plain-banner.contains("\e["), '纯文本 banner 无 ANSI';
ok  $color-banner.contains("\e["), '彩色 banner 有 ANSI';
nok $plain-banner.contains('ASCII art'), 'banner 不含字符画噪点';

# ── prompt ──────────────────────────────────────────────────────────
my Str $p = prompt-text(:cwd('C:/Users/Admin/rakuish'), :index(3),
                        :elapsed(Duration.new(0.012)), :branch<main>,
                        :color(False), :clock, :timing);
like $p, /\d**2 ':' \d**2 ':' \d**2/, 'prompt 显示 HH:MM:SS';
ok  $p.contains('rakuish'),            'prompt 显示 cwd';
ok  $p.contains('git:main'),           'prompt 显示 git 分支';
ok  $p.contains('[3]'),                'prompt 显示格号';
ok  $p.contains('12.0ms'),             'prompt 显示上格耗时';
ok  $p.ends-with('> '),                '纯文本箭头';
nok $p.contains("\e["),                '纯文本 prompt 无 ANSI';

my Str $no-clock = prompt-text(:cwd('/x'), :clock(False), :timing(False));
nok $no-clock ~~ /\d**2 ':' \d**2 ':' \d**2/, 'clock off 不显示时间';
nok $no-clock.contains('ms'),                  'timing off 不显示耗时';

my Str $colored = prompt-text(:cwd('/x'), :color, :index(2),
                              :elapsed(Duration.new(0.5)));
ok  $colored.contains("\e["), '彩色 prompt 有 ANSI';
ok  $colored.contains('❯'),   '彩色 prompt 用 ❯ 箭头';

my Str $plain-style = prompt-text(:cwd('/x'), :color, :style<plain>);
nok $plain-style.contains("\e["), 'prompt-style=plain 关闭颜色';
nok $plain-style.contains('❯'),   'prompt-style=plain 用 ASCII 箭头';

my Str $compact = prompt-text(:cwd('/x'), :style<compact>, :clock,
                             :timing, :elapsed(Duration.new(0.01)));
nok $compact ~~ /\d**2 ':' \d**2 ':' \d**2/, 'compact 省略时间';
nok $compact.contains('ms'),                  'compact 省略耗时';

my Str $more = prompt-text(:cwd('/x'), :continuing);
ok $more.contains('···'), '续行提示符';

my Str $failed = prompt-text(:cwd('/x'), :ok(False), :code(127));
ok $failed.contains('[exit=127]'), '失败格显示退出码';

# ── 路径 / 耗时格式化 ───────────────────────────────────────────────
ok shorten-path('/a/b/c/d/e/f').contains('.../'), '长路径折叠尾部三段';
is shorten-path('/a/b'), '/a/b', '短路径不折叠';
is format-elapsed(Duration.new(0.0004)), '<1ms', '亚毫秒不显示成 0ms';
is format-elapsed(Duration.new(0.012)), '12.0ms', '毫秒格式';
is format-elapsed(Duration.new(1.5)),   '1.50s',  '秒格式';

# ── git 分支只读 .git/HEAD，且经 Sys ────────────────────────────────
{
    my $dir = $*CWD.add('tmp').add('chrome-git-test');
    $dir.add('.git').mkdir;
    $dir.add('.git').add('HEAD').spurt("ref: refs/heads/feature/ui\n");
    my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
    is git-branch($sys, $dir), 'feature/ui', '从 .git/HEAD 读分支';
    $dir.add('.git').add('HEAD').spurt("cafebabe\n");
    forget-branch-cache();
    is git-branch($sys, $dir), '(detached)', 'detached HEAD';
    $dir.add('.git').add('HEAD').unlink;
    $dir.add('.git').rmdir;
    $dir.rmdir;
}

# ── 计时能力：timed / bench / perf ──────────────────────────────────
my $t = timed({ 1 + 1 });
is $t.value, 2, 'timed 返回值仍可组合';
ok $t.elapsed.defined, 'timed 带耗时';
my $t3 = timed({ 1 + 1 }, :repeat(3));
is $t3.value, 2, 'timed :repeat 仍返回最后一次值';
ok $t3.elapsed.defined, 'timed :repeat 记录总耗时';

my $b = bench({ 1 + 1 }, :repeat(3));
is $b.value<repeat>, 3, 'bench 记录次数';
ok $b.value<mean>.defined, 'bench 给出平均值';
like $b.out, /'mean'/, 'bench 输出人读摘要';
ok $b.elapsed.defined, 'bench 带总耗时';

my $s = Rakuish::REPL::Session.new;
$s.eval-line('1 + 1');
$s.note-timing(Duration.new(0.012), '1 + 1', True);
$s.eval-line('2 + 2');
$s.note-timing(Duration.new(0.025), '2 + 2', True);
my $perf = $s.eval-line('perf 5');
ok $perf.ok, 'perf 命令成功';
like $perf.out, /'共 2 格'/, 'perf 汇总格数';
like $perf.out, /'平均'/,    'perf 汇总平均值';
like $perf.out, /'25 ms'/,   'perf 列出逐格耗时';
like $s.eval-line('perf --help').out, /'用法: perf'/, 'perf --help 给出用法';

done-testing;
