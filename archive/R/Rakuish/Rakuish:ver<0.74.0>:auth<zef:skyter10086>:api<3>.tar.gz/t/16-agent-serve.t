use Test;

# 16-agent-serve.t —— 常驻多客户端与请求级取消（0.63.0 / ADR-0002）
#
# 三条主线：
#   1. deadline 到点立即 504，且审计 stage=timeout（同步 handle 即可验）；
#   2. 常驻 serve 能同时持有多个连接、每连接独立 session / engine-factory；
#   3. 慢请求不会拖死同一连接的后续请求。
# serve-once 的兼容语义由 t/06 守护，这里不重复。

use JSON::Fast;
use Rakuish::Sandbox;
use Rakuish::Agent;
use Rakuish::Agent::Server;

my $dir = $*CWD.add('tmp').add('agent-serve-test');
$dir.mkdir unless $dir.e;
$dir.add('a.txt').spurt('hello 中文');

sub sbx(*%o) { Rakuish::Sandbox.new(:root($dir), :token('TOKEN'), |%o) }
sub req(Int $id, Str $op = 'read_file', *%o) {
    to-json({ id => $id, token => 'TOKEN', op => $op,
              path => 'a.txt', |%o }, :!pretty)
}
my &read-reply = -> $c {
    my $p = start { $c.get };
    await Promise.anyof($p, Promise.in(8));
    $p.status ~~ Kept ?? $p.result !! Nil;
};

# ── 1. 请求级 504：不再等 dispatch 自己结束 ─────────────────────────
{
    # 注入一个确定慢的只读 Engine：job 250ms，deadline 60ms。
    # 这样验证的是「deadline 先到 → 立即 504」，不依赖线程调度竞态。
    class SlowTable  { method limit($n) { 42 } }
    class SlowEngine { method query($sql, *@p) { sleep 0.25; SlowTable.new } }
    my $s = sbx(:request-timeout-ms(60), :allow-sql);
    my $a = Rakuish::Agent.new(:sandbox($s), :engine(SlowEngine.new));
    my %r = $a.handle({ id => 7, token => 'TOKEN', op => 'sql_query',
                        sql => 'select 1', params => [] });
    is %r<code>, 504, 'deadline 到点立即返回 504';
    ok $s.entries.grep({ .<stage> eq 'timeout' }).elems >= 1,
        '审计标记 stage=timeout';
    ok (%r<elapsed_ms> // 0) < 200, '没有等慢查询自己跑完';
}

# 正常请求仍走原路径（防止把成功路径改坏）
{
    my $s = sbx(:request-timeout-ms(5000));
    my %r = Rakuish::Agent.new(:sandbox($s)).handle(
        { id => 8, token => 'TOKEN', op => 'read_file', path => 'a.txt' });
    ok %r<ok>, '正常请求仍成功';
    is %r<value>, 'hello 中文', '值往返不变';
    ok $s.entries.grep({ .<stage> eq 'op' }).elems >= 1, '成功响应审计 stage=op';
}

# ── 2. 共享 Engine 且无 factory：拒绝进入常驻模式 ───────────────────
{
    my $srv = Rakuish::Agent::Server.new(:sandbox(sbx()), :engine(42));
    my %i = $srv.serve(:port(0));
    nok %i<ok>, '常驻模式拒绝共享 Engine 连接';
    like %i<err>, /'engine-factory'/, '给出明确原因';
}

# ── 3. 常驻多客户端 ─────────────────────────────────────────────────
my $sandbox = sbx(:request-timeout-ms(400), :allow-exec,
                  :allowlist(<raku>));
my $made = 0;
my &factory = -> { $made++; 42 };
my $srv = Rakuish::Agent::Server.new(:sandbox($sandbox));
my $stop = Promise.new;
my $ready = Promise.new;
my $task = start {
    $srv.serve(:port(0), :stop($stop), :engine-factory(&factory),
               :max-connections(8), :idle-timeout-ms(2000),
               :on-ready(-> $p { $ready.keep($p) }));
};
await Promise.anyof($ready, Promise.in(5));

if $ready.status !~~ Kept {
    skip 'TCP 常驻服务未在 5s 内就绪（平台限制）', 9;
}
else {
    my $port = $ready.result;
    my $c1 = IO::Socket::INET.new(:host<127.0.0.1>, :port($port));
    my $c2 = IO::Socket::INET.new(:host<127.0.0.1>, :port($port));
    ok $c1.defined && $c2.defined, 'accept loop 同时持有两个连接';

    $c1.say(req(1));
    my $l1 = read-reply($c1);
    $c2.say(req(2));
    my $l2 = read-reply($c2);
    if $l1.defined && $l2.defined {
        my %r1 = from-json($l1);
        my %r2 = from-json($l2);
        is %r1<id>, 1, '连接 1 的响应 id 正确';
        is %r2<id>, 2, '连接 2 的响应 id 正确';
        is %r2<value>, 'hello 中文', '连接 2 往返正常';
    }
    else { skip '并发连接响应超时', 3 }

    my @sessions = $sandbox.entries
        .grep({ .<stage> eq 'op' }).map({ .<session> }).unique;
    ok @sessions.elems >= 2, '每连接独立 session-id 审计';
    ok $made >= 2, 'engine-factory 每连接各调用一次（不共享连接）';

    # 慢 exec（底层超时被压到 deadline）不应挂住同一连接。
    $c1.say(req(10, 'exec', argv => ['raku', '-e', 'sleep 2']));
    my $slow = read-reply($c1);
    ok $slow.defined, '慢请求有响应（未挂住连接）';
    if $slow.defined {
        my %rs = from-json($slow);
        ok %rs<code> == 504 || %rs<code> == 124 || !%rs<ok>,
            '慢请求以 504 / 124 / 失败收场';
    }
    else { skip '慢请求无响应', 1 }
    $c1.say(req(11));
    my $after = read-reply($c1);
    if $after.defined {
        ok from-json($after)<ok>, '超时后同一连接仍可处理请求';
    }
    else { flunk '超时后同一连接仍能响应' }

    $c1.close;
    $c2.close;
    $stop.keep;
    await Promise.anyof($task, Promise.in(5));
    if $task.status ~~ Kept {
        my %i = $task.result;
        ok %i<ok>, 'stop 后 serve 正常收尾';
        ok %i<connections> >= 2, '统计到多个连接';
    }
    else { skip 'serve 未在 5s 内收尾（平台限制）', 2 }
}

# ── 清理 ─────────────────────────────────────────────────────────────
$dir.add('a.txt').unlink if $dir.add('a.txt').e;
try { $dir.rmdir };

done-testing;
