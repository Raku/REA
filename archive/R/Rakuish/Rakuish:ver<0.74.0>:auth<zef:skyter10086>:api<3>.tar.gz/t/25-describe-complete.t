use Test;

# 25-describe-complete.t —— describe 值 API 与 SQL 补全启发式增强
# （0.69.0 / ADR-0006 §3 §4、SPEC V-163 / V-164）
#
# 结构化值断言为主；真实引擎部分带可选驱动 skip 护栏。
# 补全部分全是纯函数、不依赖 TTY 或数据库。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Data::Engine;
use Rakuish::REPL::Session;
use Rakuish::REPL::Shell;
use Rakuish::REPL::Hints;
use Rakuish::REPL::SqlComplete;

my $dir = $*CWD.add('tmp').add('describe-test');
$dir.mkdir unless $dir.e;
$dir.add('t25.csv').spurt("id,name,score\n1,alpha,1.5\n2,beta,2.5\n");
my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));

# ── 1. Table.describe 是值，不是文本报告 ───────────────────────────
my $t = Rakuish::Data::Table.from-rows([
    { id => 1, name => 'alpha', score => 1.5 },
    { id => 2, name => 'beta',  score => 2.5 },
    { id => 3, name => Nil,     score => 3.5 },
]);
my $d = $t.describe;
isa-ok $d, Rakuish::Data::Table, 'Table.describe 返回 Table';
is-deeply $d.columns.List,
    <name type nullable non_null distinct total sample>.List,
    '摘要列集合固定（与 Engine.describe 一致）';
is $d.elems, 3, '每个源列一行摘要';
is $d.rows[0]<name>, 'id', '首列是 id';
is $d.rows[0]<total>, 3, 'total 是总行数';
is $d.rows[0]<non_null>, 3, 'id 无空值';
is $d.rows[0]<distinct>, 3, 'id 三个不同值';
nok $d.rows[0]<nullable>, 'id 不 nullable';
ok $d.rows[1]<nullable>, 'name 含 Nil，nullable 为 True';
is $d.rows[1]<non_null>, 2, 'name 只有 2 个非空值';
ok $d.rows[0]<sample>.contains('1'), 'sample 含实际值';
is $t.describe(:sample(0)).rows[0]<sample>, '',
    ':sample(0) 不取样';
isa-ok $d.where({ .<name> eq 'name' }), Rakuish::Data::Table,
    '摘要可继续组合（.where 返回 Table）';
ok $d.to-json.contains('"name"'), '摘要可 to-json';

# ── 2. Engine.describe 角色默认实现（假引擎，不依赖驱动）───────────
class FakeEngine does Rakuish::Data::Engine {
    method query(Str $sql, *@params, Int :$max-rows --> Rakuish::Data::Table) {
        return Rakuish::Data::Table.from-rows([
            { __total => 3, nn_0 => 2, dc_0 => 2, nn_1 => 3, dc_1 => 3 },
        ]) if $sql.contains('__total');
        Rakuish::Data::Table.from-rows([
            { id => 1, name => 'alpha' }, { id => 2, name => 'beta' },
        ])
    }
    method execute(Str $sql, *@params --> Int) { 0 }
    method begin()    { Nil }
    method commit()   { Nil }
    method rollback() { Nil }
    method tables(--> Rakuish::Data::Table) {
        Rakuish::Data::Table.from-rows([{ name => 'sales' }])
    }
    method schema(Str $name --> Rakuish::Data::Table) {
        Rakuish::Data::Table.from-rows([
            { column_name => 'id',   column_type => 'INTEGER', null => 'YES' },
            { column_name => 'name', column_type => 'VARCHAR', null => 'NO'  },
        ])
    }
    method close(--> Nil) { Nil }
}
my $fake = FakeEngine.new;
my $fd = $fake.describe('sales');
isa-ok $fd, Rakuish::Data::Table, 'Engine.describe 返回 Table';
is-deeply $fd.columns.List,
    <name type nullable non_null distinct total sample>.List,
    '角色实现与 Table.describe 列集合一致';
is $fd.elems, 2, '两列各一行';
is $fd.rows[0]<total>, 3, '统计 total 来自聚合查询';
is $fd.rows[0]<non_null>, 2, '统计 non_null 来自聚合查询';
is $fd.rows[0]<distinct>, 2, '统计 distinct 来自聚合查询';
is $fd.rows[0]<type>, 'INTEGER', '列类型来自 schema()';
ok $fd.rows[0]<nullable>, 'DESCRIBE 的 YES 映射为 nullable';
nok $fd.rows[1]<nullable>, 'NO 映射为不可空';
throws-like { $fake.describe('sales; drop table x') },
    X::Rakuish::Unsupported, '注入式表名明确拒绝';
throws-like { $fake.describe('1bad') },
    X::Rakuish::Unsupported, '数字开头表名拒绝';

class BrokenEngine does Rakuish::Data::Engine {
    method query(Str $sql, *@params, Int :$max-rows --> Rakuish::Data::Table) {
        die 'locked'
    }
    method execute(Str $sql, *@params --> Int) { 0 }
    method begin()    { Nil }
    method commit()   { Nil }
    method rollback() { Nil }
    method tables(--> Rakuish::Data::Table) { Rakuish::Data::Table.new }
    method schema(Str $name --> Rakuish::Data::Table) {
        Rakuish::Data::Table.from-rows([{ column_name => 'c', column_type => 'INT' }])
    }
    method close(--> Nil) { Nil }
}
my $bd = BrokenEngine.new.describe('t');
isa-ok $bd, Rakuish::Data::Table, '聚合查询失败时仍返回摘要 Table';
nok $bd.rows[0]<total>.defined, '统计不可用时留空，不编造数字';

# ── 3. DSL / Session 的 describe 入口 ──────────────────────────────
my $sess = Rakuish::REPL::Session.new(:sys($sys));
my $e1 = $sess.eval-line(q{my $tbl = open-data('t25.csv')});
ok $e1.ok, '准备一格 Table 值成功';
my $e2 = $sess.eval-line(q{describe($tbl)});
ok $e2.ok, 'DSL.describe(Table) 求值成功';
isa-ok $e2.value, Rakuish::Data::Table, 'DSL.describe 返回 Table';
is $e2.value.rows[0]<name>, 'id', 'DSL.describe 摘要内容正确';

my $e3 = $sess.eval-line('describe');
ok $e3.ok, '会话命令 describe（无参数）成功';
ok $e3.out.contains('name'), '命令输出包含摘要表头';
isa-ok $e3.value, Rakuish::Data::Table, '命令 value 仍是结构化 Table';

my $e4 = $sess.eval-line('describe sales');
nok $e4.ok, '没有 Engine 时 describe 表名明确失败';
ok $e4.err.contains('open-db'), '错误提示给出下一步';

my $e5 = $sess.eval-line(
    q{my $db = open-db(':memory:', :!read-only, :!safe); $db.execute('create table sales (id int, region text)')});
ok $e5.ok, '注册会话 Engine 并建表成功';
my $e6 = $sess.eval-line(q{describe('sales')});
ok $e6.ok, 'DSL.describe(表名) 求值成功';
isa-ok $e6.value, Rakuish::Data::Table, '表名形态返回 Table';
my $e7 = $sess.eval-line('describe sales');
ok $e7.ok, '会话命令 describe 表名成功';
my $e8 = $sess.eval-line(q{describe(42)});
nok $e8.ok, 'describe 不接受无关类型';
ok $e8.err.contains('Table'), '错误说明可接受的类型';

my $shell = Rakuish::REPL::Shell.new(:sys($sys));
ok $shell.usage('describe').contains('结构化 Table'),
    'help describe 说明返回结构化值';
ok $sess.eval-line('help describe').out.contains('describe'),
    'REPL 里 help describe 可用';
ok $sess.completions('des', 3).List.grep(* eq 'describe ').elems == 1,
    'describe 进入命令名补全';
ok hint-for('describe').contains('describe'),
    'hints 收录 describe';

# ── 4. SQL 补全：别名 / 表前缀列 / 大小写风格 ──────────────────────
class CompleteEngine {
    method tables() {
        Rakuish::Data::Table.from-rows([
            { name => 'sales' }, { name => 'users' },
        ])
    }
    method schema($name) {
        Rakuish::Data::Table.from-rows(
            $name eq 'sales'
                ?? [{ name => 'amount' }, { name => 'region' }]
                !! [{ name => 'uid' }, { name => 'email' }])
    }
}
my $ce = CompleteEngine.new;

my @lines = q:to/END/.lines;
$db.query('select * from sales s where s.am
$db.query('select * from sales s join users as u on u.ui
$db.query('SEL
$db.query('Sel
$db.query('sel
$db.query('select * from sa
END
my Str $a1 = @lines[0];
my %c1 = sql-context($a1, $a1.chars);
is %c1<aliases><s>, 'sales', 'from sales s 解析出别名 s';
is %c1<alias-table>, 'sales', 's. 前缀指向 sales';
is %c1<frag>, 'am', '前缀后的当前词是 am';
my @r1 = sql-completions($a1, $a1.chars, :engine($ce));
is @r1.elems, 1, 's.am 只补 sales 的列';
ok @r1[0].ends-with('s.amount'), '补全返回完整替换行 s.amount';
nok @r1[0].contains('SELECT'), '别名前缀不塞关键字';

my Str $a2 = @lines[1];
is sql-context($a2, $a2.chars)<aliases><u>, 'users',
    'join users as u 解析出 as 别名';
my @r2 = sql-completions($a2, $a2.chars, :engine($ce));
is @r2.elems, 1, 'u.ui 只补 users 的列';
ok @r2[0].ends-with('u.uid'), 'as 别名补全正确';

my @r3 = sql-completions(@lines[2], @lines[2].chars, :engine($ce));
ok @r3[0].ends-with('SELECT'), '全大写片段补出全大写关键字';
my @r4 = sql-completions(@lines[3], @lines[3].chars, :engine($ce));
ok @r4[0].ends-with('Select'), '首字母大写片段补出首字母大写关键字';
my @r5 = sql-completions(@lines[4], @lines[4].chars, :engine($ce));
ok @r5[0].ends-with('select'), '小写片段仍是小写关键字';

my @r6 = sql-completions(@lines[5], @lines[5].chars, :engine($ce));
ok @r6.grep({ .ends-with('sales') }).elems == 1,
    '无别名前缀时表名补全不受影响';
ok !sql-completions(q{q[select * from sa}, 19, :engine($ce)).elems,
    'q[...] 不是 SQL 上下文（不做 AST / heredoc）';
ok !sql-completions(q{say('select * from sa}, 23, :engine($ce)).elems,
    '非 SQL 调用名不补全';
my Str $closed = q{$db.query('select * from sales')};
ok !sql-completions($closed, $closed.chars, :engine($ce)).elems,
    '已闭合字符串之后不补全';

class BadCompleteEngine {
    method tables()   { die 'database is locked' }
    method schema($t) { die 'database is locked' }
}
ok !sql-completions($a1, $a1.chars, :engine(BadCompleteEngine.new)).elems,
    '元数据异常时安静退化成不补全';
ok !sql-completions($a1, $a1.chars).elems,
    '没有 Engine 时别名前缀不崩也不乱补';

# ── 5. 真实引擎的 describe（可选驱动）──────────────────────────────
my $duck-mod = try { require ::('DB::DuckDB') };
my Bool $have-duck = try { $duck-mod.^name eq 'DB::DuckDB' } // False;
if !$have-duck {
    skip 'DB::DuckDB 未安装，跳过 DuckDB describe', 3;
}
else {
    need Rakuish::Data::Engine::DuckDB;
    my $db = Rakuish::Data::Engine::DuckDB.new(
        :path<:memory:>, :read-only(False), :safe(False));
    $db.execute('create table sales (id int, region varchar, amount double)');
    $db.execute("insert into sales values (1, 'east', 2.5), (2, 'west', 3.5), (3, ?, 4.5)", Nil);
    my $rd = $db.describe('sales');
    is $rd.elems, 3, 'DuckDB describe 三列';
    is $rd.rows[0]<total>, 3, 'DuckDB describe total 正确';
    is $rd.rows[1]<non_null>, 2, 'DuckDB describe 统计空值列';
    $db.close;
}

my $lite-mod = try { require ::('DB::SQLite') };
my Bool $have-lite = try { $lite-mod.^name eq 'DB::SQLite' } // False;
if !$have-lite {
    skip 'DB::SQLite 未安装，跳过 SQLite describe', 2;
}
else {
    need Rakuish::Data::Engine::SQLite;
    my $db = Rakuish::Data::Engine::SQLite.new(
        :path<:memory:>, :read-only(False), :safe(False));
    $db.execute('create table q (id int, label text)');
    $db.execute("insert into q values (1, 'a'), (2, 'b')");
    my $rd = $db.describe('q');
    is $rd.elems, 2, 'SQLite describe 两列（角色默认实现跨引擎可用）';
    is $rd.rows[0]<total>, 2, 'SQLite describe total 正确';
    $db.close;
}

try { $dir.add('t25.csv').unlink }
try { $dir.rmdir };
done-testing;
