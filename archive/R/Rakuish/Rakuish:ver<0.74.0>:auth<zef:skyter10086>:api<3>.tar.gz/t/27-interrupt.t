#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::REPL::Session;

# 27-interrupt.t —— Ctrl-C 只中断输入、不退出 REPL（0.71 / ADR-0008 §3.1）
#
# 1) 值 API：Session.handle-key('Ctrl-C') 清掉续行缓冲，下一格能独立求值；
# 2) 真 PTY：半行输入 → Ctrl-C → 进程仍活 → 下一格 Out[1] = 42 →
#    Ctrl-D 才退出（Windows 无 pty，跳过）。
# 行编辑器解码 / take-interrupt 的纯逻辑断言在 t/19，这里不重复。

# ── 1. 值 API：中断后不把上一段残行拼进新格 ──────────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    my Str $incomplete = 'my $x = (';   # 不用 q{}：内容里的 ( 会触发括号配对
    is $s.eval-line($incomplete).op, 'more', '不完整行进入续行缓冲';
    my $k = $s.handle-key('Ctrl-C');
    is $k.value, 'interrupted', 'handle-key 返回 interrupted';
    ok $s.interrupt-requested, '会话记录中断请求';
    my $r = $s.eval-line('say 40 + 2');
    ok $r.ok, '中断后的下一格求值成功（残行未被拼接）';
    is $r.out.trim, '42', '结果仍是 42';
    ok $s.key-bindings<Ctrl-C>.contains('不退出'),
        '快捷键帮助明确写「不退出」';
    ok $s.key-bindings<Ctrl-D>.contains('EOF'), 'Ctrl-D 仍是退出入口';
}

# ── 2. 真 PTY 集成（无 pty 的平台跳过）────────────────────────────────
{
    my Bool $pty-ok = !$*DISTRO.is-win;
    my $py = '';
    if $pty-ok {
        my $probe = try {
            my $p = run('python3', '-c', 'import pty; print("ok")', :out, :err);
            $p.out.slurp(:close).trim
        };
        $py = ($probe // '');
    }
    if $pty-ok && $py eq 'ok' {

        my IO::Path $tmp = $*CWD.add('tmp');
        $tmp.mkdir unless $tmp.e;
        my Str $tag = $*PID.Str;
        my $driver = $tmp.add("irq-driver-{$tag}.py");
        my $raku   = $tmp.add("irq-raku-{$tag}.txt");

        $driver.spurt(q:to/PYTHON/);
            import fcntl, os, pty, re, select, struct, subprocess, sys, termios, time, tty
            from pathlib import Path

            raku = sys.argv[1]
            root = Path(__file__).resolve().parent.parent
            env = os.environ.copy()
            env.update(
                RAKUISH_CONFIG="/tmp/rakuish-irq-%d.json" % os.getpid(),
                TERM="xterm-256color",
                LANG="C.UTF-8",
            )
            master, slave = pty.openpty()
            fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 24, 110, 0, 0))
            # raw 模式：Ctrl-C / Ctrl-D 是字节，不会被终端转成信号。
            tty.setraw(slave)
            proc = subprocess.Popen(
                [raku, "-Ilib", "bin/rakuish"], cwd=str(root), env=env,
                stdin=slave, stdout=slave, stderr=slave, close_fds=True)
            os.close(slave)

            raw = bytearray()
            esc = b""
            size_pending = False
            dsr = 0

            def feed(data):
                global esc, size_pending, dsr
                for byte in data:
                    esc += bytes((byte,))
                    if len(esc) > 24:
                        esc = esc[-24:]
                    if esc.endswith(b"\x1b[9999;9999H"):
                        size_pending = True
                    elif esc.endswith(b"\x1b[6n"):
                        dsr += 1
                        os.write(master, b"\x1b[24;110R" if size_pending
                                 else b"\x1b[1;1R")
                        size_pending = False
                        esc = b""

            def pump(seconds):
                end = time.time() + seconds
                while time.time() < end:
                    readable, _, _ = select.select([master], [], [], 0.08)
                    if not readable:
                        continue
                    try:
                        data = os.read(master, 65536)
                    except OSError:
                        return
                    if not data:
                        return
                    raw.extend(data)
                    feed(data)
                    end = max(end, time.time() + 0.2)

            def send(data, wait=0.5):
                os.write(master, data)
                pump(wait)

            def prompts():
                return raw.count(b"\xe2\x9d\xaf")

            def wait_ready(timeout=25):
                end = time.time() + timeout
                while time.time() < end:
                    pump(0.3)
                    if prompts() or dsr >= 2:
                        return True
                return False

            def wait_new_prompt(before, timeout=10):
                end = time.time() + timeout
                while time.time() < end:
                    pump(0.2)
                    if prompts() > before:
                        return True
                return False

            print("READY", wait_ready(), flush=True)
            before = prompts()
            send(b"say 'half-line", 0.4)       # 故意不按回车
            send(b"\x03", 0.7)                 # Ctrl-C
            print("ALIVE_AFTER_CTRL_C", proc.poll() is None, flush=True)
            print("NEW_PROMPT", wait_new_prompt(before), flush=True)

            before2 = prompts()
            # 裸表达式：say 会渲染成 "42\nOut[n] = Bool::True"，不便于断言格号。
            send(b"40 + 2\r", 0.8)
            wait_new_prompt(before2)
            print("ALIVE_AFTER_EVAL", proc.poll() is None, flush=True)
            send(b"\x04", 0.6)                 # Ctrl-D 才退出
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            print("EXIT_RC", proc.returncode, flush=True)
            os.close(master)

            text = raw.decode("utf-8", "replace")
            text = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", text)
            text = re.sub(r"\x1b[=>]", "", text).replace("\r", "")
            print("TEXT_BEGIN")
            print(text)
            print("TEXT_END")
            PYTHON

        $raku.spurt($*EXECUTABLE.Str);

        my $ran = try {
            my $p = run('python3', $driver.Str, $*EXECUTABLE.Str, :out, :err);
            ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
        };
        my Str $text = $ran // '';
        ok $text.contains('READY True'), '真 PTY：REPL 正常启动到第一个 prompt';
        ok $text.contains('ALIVE_AFTER_CTRL_C True'),
            '真 PTY：Ctrl-C 后宿主进程仍存活';
        ok $text.contains('NEW_PROMPT True'), '真 PTY：中断后重画了新 prompt';
        ok $text.contains('已中断当前输入'), '真 PTY：给出中断提示';
        ok $text.contains('ALIVE_AFTER_EVAL True'),
            '真 PTY：中断后仍可继续求值';
        ok $text.contains('Out[1] = 42'),
            '真 PTY：Ctrl-C 没产生空 Out[n] 格，下一格是 Out[1] = 42';
        ok $text.contains('EXIT_RC 0'), '真 PTY：Ctrl-D 才退出，退出码 0';
        nok $text.contains('Unhandled exception'),
            '真 PTY：没有未捕获异常';

        try { .unlink for ($driver, $raku) };
    }
    else {
        skip '本机 Python 无 pty 模块（Windows）；Ctrl-C 交互由 tools/tty-check.py 验收', 8;
    }
}

done-testing;
