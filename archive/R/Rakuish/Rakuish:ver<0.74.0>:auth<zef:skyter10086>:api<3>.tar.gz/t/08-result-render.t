use v6.d;
use Test;
use JSON::Fast;
use lib 'lib';

use Rakuish::Result;
use Rakuish::Result::Renderer;

# t/08 —— Result 多格式渲染层（text / json / markdown）
#
# 约束：
#   · json 必须能被 JSON::Fast 解析，路径统一 / 分隔；
#   · markdown 必须用足够长的代码围栏，内容里的 ``` 不能把文档截断；
#   · text 是稳定的人读格式，不掺 ANSI；
#   · 未知格式必须抛 X::Rakuish::Render，而不是静默回落 text。

my $r = Result.new(
    :ok, :code(0), :op<exec>,
    :out("hello\n中文\n"), :err("warn\n"),
    :value({ name => 'demo', count => 3, path => 'C:\tmp\x' }),
    :elapsed(Duration.new(0.012)),
);

# ── 默认 / 别名 ─────────────────────────────────────────────────────
is $r.render, $r.render('text'), '默认格式是 text';
is $r.render(:format<json>), $r.render('json'), 'render(:format<json>) 也生效';
is $r.render('text'), $r.to-text, 'to-text 等价 render(text)';
is $r.render('txt'), $r.render('text'), 'txt 是 text 的别名';
is $r.render('plain'), $r.render('text'), 'plain 是 text 的别名';
is $r.render('md'), $r.render('markdown'), 'md 是 markdown 的别名';
is $r.to-json, $r.render('json'), 'to-json 等价 render(json)';
is $r.to-markdown, $r.render('markdown'), 'to-markdown 等价 render(markdown)';
is $r.text, $r.render('text'), 'text 等价 render(text)';
is $r.gist, $r.text, 'gist 走 text 渲染';
is Result.new(:ok, :out("stdout\n")).display, 'stdout', 'display 优先 stdout';
is Result.new(:!ok, :err("boom\n")).display, 'boom', 'display 失败时给 stderr';
is Result.new(:ok, :value(42)).display, '42', 'display 简单 value';
is Result.new(:!ok, :out("partial\n"), :err("warn\n")).display, "partial\nwarn",
    'display 同时保留 stdout / stderr';
my $cached = Result.new(:ok, :rendered("cached text\n"));
is $cached.text, "cached text\n", '预渲染的 rendered 优先返回';
is $cached.render('text'), $cached.text, 'render(text) 命中预渲染缓存';
is $cached.render('json') ~~ Str, True, 'render(json) 不受 text 缓存影响';
is available-formats(), <text json markdown>, 'available-formats 列出三种格式';

# ── text ─────────────────────────────────────────────────────────────
my Str $text = $r.render('text');
like $text, /^ 'ok: true'/, 'text 首行是 ok';
like $text, /'op: exec'/, 'text 含 op';
like $text, /'code: 0'/, 'text 含 code';
like $text, /'elapsed: 0.012'/, 'text 含 elapsed';
like $text, /'out:'/ && /hello/, 'text 含 stdout';
like $text, /'err:'/ && /warn/, 'text 含 stderr';
like $text, /'value:'/ && /'name: demo'/, 'text 含结构化 value';
like $text, /'path: C:\\tmp\\x'/, 'text 中路径保持原样（不强制 /）';
nok $text.contains("\e["), 'text 不含 ANSI 转义';

# ── json ─────────────────────────────────────────────────────────────
my Str $json = $r.render('json');
my %j = from-json($json);
is %j<ok>, True, 'json.ok 是 Bool';
is %j<code>, 0, 'json.code 是数字';
is %j<op>, 'exec', 'json.op';
is %j<out>, "hello\n中文\n", 'json.out 保留换行与中文';
is %j<err>, "warn\n", 'json.err';
is %j<value><name>, 'demo', 'json.value 嵌套 Hash';
is %j<value><count>, 3, 'json.value 数字';
is %j<value><path>, 'C:/tmp/x', 'json 中路径统一 / 分隔';
ok %j<elapsed>.defined, 'json 含 elapsed';

my Str $pretty = $r.render('json', :pretty);
ok $pretty.contains("\n  "), ':pretty 输出多行';
is from-json($pretty)<code>, 0, 'pretty JSON 仍可解析';

# 空结果也必须能序列化、能被 JSON 解析
my $empty = Result.new(:ok);
my %ej = from-json($empty.render('json'));
is %ej<ok>, True, '空 Result 的 json.ok';
is %ej<code>, 0, '空 Result 的 json.code';
nok %ej<value>:exists, '未定义 value 不写进 JSON';

# ── markdown ─────────────────────────────────────────────────────────
my Str $md = $r.render('markdown');
like $md, /^ '# Result'/, 'markdown 以标题开头';
like $md, /'**ok**: `true`'/, 'markdown 状态';
like $md, /'## stdout'/, 'markdown 有 stdout 段';
like $md, /'## stderr'/, 'markdown 有 stderr 段';
like $md, /'## value'/, 'markdown 有 value 段';
like $md, /'```text'/, '普通文本用 text 围栏';
like $md, /'```json'/, '结构化 value 用 json 围栏';

# 内容里含 ``` 时，围栏必须加长，不能截断文档
my $tricky = Result.new(:ok, :value({ code => "```\ninside\n```" }));
my Str $tmd = $tricky.render('markdown');
ok $tmd.contains('````json'), '内容含 ``` 时围栏自动加长到 4 个反引号';
nok $tmd.contains("\n```json\n"), '不会用 3 个反引号提前闭合围栏';

# ── 嵌套 Result / IO::Path / Blob ────────────────────────────────────
my $inner = Result.new(:ok, :value(42));
my $outer = Result.new(:ok, :value($inner));
my %nj = from-json($outer.render('json'));
is %nj<value><ok>, True, '嵌套 Result 保留 ok';
is %nj<value><value>, 42, '嵌套 Result 递归序列化 value';

my $path-result = Result.new(:ok, :value($*CWD));
my %pj = from-json($path-result.render('json'));
is %pj<value>, $*CWD.Str.subst('\\', '/', :g), 'IO::Path 序列化为 / 分隔字符串';

my $list-result = Result.new(:ok, :value([
    $*CWD.add('README.md'), $*CWD.add('META6.json'),
]));
my Str $list-text = $list-result.render('text');
like $list-text, /'README.md'/, 'List[IO::Path] 的 text 用 basename';
nok $list-text.contains('IO::Path'), 'List[IO::Path] 的 text 不显示对象结构';
nok $list-text.contains($*CWD.Str), 'List[IO::Path] 的 text 不显示绝对路径前缀';

my $blob-result = Result.new(:ok, :value(Blob.new(1, 2, 3)));
my %bj = from-json($blob-result.render('json'));
is %bj<value>, [1, 2, 3], 'Blob 序列化为字节数组';

# ── 未知格式 ─────────────────────────────────────────────────────────
throws-like { $r.render('yaml') }, X::Rakuish::Render,
    '未知格式抛 X::Rakuish::Render';
throws-like { $r.render('yaml') }, X::Rakuish::Render,
    message => /'不支持的渲染格式'/,
    '错误消息说明可用格式';

done-testing;
