use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::REPL::Session;

# Phase 3 · V3 REPL 会话（ADR-0001 §2.3）
# 反向断言是重点：没有 magic 分流、没有 auto-shell 回退、没有反引号 shellq、
# ! 不解释任何 shell 元字符。

my $R = $*EXECUTABLE.Str;

# ── 两类输入：Raku 与 ! argv ────────────────────────────────────────
my $s = Rakuish::REPL::Session.new;
my $r = $s.eval-line('1 + 1');
ok $r.ok, 'Raku 表达式求值成功';
is $r.value, 2, '表达式值';
is $r.op, 'eval', 'op = eval';
is $s.index, 1, '格号递增';

# ── % 开头一律按 Raku，不是 magic ───────────────────────────────────
$s.eval-line('my %h = a => 7;');
my $hp = $s.eval-line('%h<a>');
ok $hp.ok, '% 开头成功求值';
is $hp.value, 7, '%h<a> 是 Raku 哈希访问';
nok $hp.err.contains('未知 magic'), '没有 magic 分流';
is $hp.op, 'eval', 'op 仍是 eval，不是 magic';

my $unknown-magic = $s.eval-line('%not-a-command');
nok $unknown-magic.ok, '未知 %xxx 是 Raku 编译错误';
ok $unknown-magic.err.contains('%not-a-command')
   || $unknown-magic.err.chars > 0, '错误信息来自 Raku 编译器';

# ── 没有 auto-shell 回退 ────────────────────────────────────────────
my $g = $s.eval-line('git status');
nok $g.ok, 'git status 求值失败（不猜、不回退）';
ok $g.err.contains('git'), '错误来自 Raku 未声明例程';
nok $g.out.contains('On branch'), '没有偷偷执行外部 git';
is $g.op, 'eval', '失败格仍是 eval';

# ── 副作用只执行一次（不能整份历史重 EVAL）────────────────────────
my $side-dir = $*TMPDIR.IO.add("rakuish-side-{$*PID}");
$side-dir.mkdir;
LEAVE { try { $side-dir.dir>>.unlink; $side-dir.rmdir } }
my $side = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
$side.eval-line('append("log.txt", "one\n")');
$side.eval-line('1 + 1');
$side.eval-line('2 + 2');
is $side-dir.add('log.txt').lines.elems, 1, 'REPL 后续格不重放 append 副作用';
$side.eval-line('my $x = append("log.txt", "two\n");');
$side.eval-line('3 + 3');
is $side-dir.add('log.txt').lines.elems, 2,
    '声明初始化里的 append 也只执行一次';

# ── 顶层 my/数组/哈希跨格持久，且是同一容器 ───────────────────────
my $st = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
$st.eval-line('my $x = 1;');
$st.eval-line('$x = 5;');
is $st.eval-line('$x + 1').value, 6, 'my 标量跨格保留修改';
$st.eval-line('my @a = (1, 2);');
$st.eval-line('@a.push(3);');
is $st.eval-line('@a.elems').value, 3, 'my 数组跨格是同一容器';
$st.eval-line('my %h = a => 1;');
$st.eval-line('%h<b> = 2;');
is $st.eval-line('%h.keys.sort.join(",")').value, 'a,b',
    'my 哈希跨格保留新增键';
$st.eval-line('my $word = "my fake";');
is $st.eval-line('$word').value, 'my fake',
    '字符串里的 my 不被扫描器误当声明';

# ── set -e / strict：失败格请求退出 ─────────────────────────────────
my $strict = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
ok $strict.eval-line('set -e').ok, 'set -e 成功';
ok $strict.strict, 'set -e 打开 strict';
my $bad = $strict.eval-line('ls definitely-missing');
nok $bad.ok, 'strict 下失败命令仍返回错误 Result';
ok $strict.exit-requested, 'strict 下失败请求退出';
is $strict.exit-code, 1, 'strict 退出码为 1';
my $loose = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
$loose.eval-line('set -e');
$loose.eval-line('set +e');
nok $loose.eval-line('ls definitely-missing').ok, 'set +e 后普通失败仍返回错误';
nok $loose.exit-requested, 'set +e 后不请求退出';

my $bang = $loose.eval-line('! echo "unterminated');
nok $bang.ok, '! 未闭合引号不执行';
is $bang.code, 127, '! 未闭合引号返回 127';
like $bang.err, /'引号'/, '! 未闭合引号有明确错误';

# ── _ / Out[n] / cmd 桥 ─────────────────────────────────────────────
my $oo = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
is $oo.eval-line('1 + 1').value, 2, '第一格值';
is $oo.eval-line('_ + 1').value, 3, '_ 指向上一格';
is $oo.eval-line('Out[1]').value, 2, 'Out[1] 是第一格';
is $oo.eval-line('Out[2]').value, 3, 'Out[2] 是第二格';

my $ls-out = $oo.eval-line('ls --json .');
isa-ok $ls-out.value, Rakuish::Data::Table, 'ls --json 值是 Table';
is $oo.eval-line('_.elems').value, $ls-out.value.elems,
    '_ 可接上一格 shell 结果';
is $oo.eval-line('cmd("ls --json .").elems').value,
    $ls-out.value.elems, 'cmd 桥返回结构化 Table';

my $badcmd = $oo.eval-line('cmd("definitely-missing")');
nok $badcmd.ok, 'cmd 失败不返回成功';
like $badcmd.err, /'失败'/, 'cmd 失败有明确错误';

# ── 历史替换 ─────────────────────────────────────────────────────────
my $hs = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
is $hs.eval-line('3 + 4').value, 7, '历史替换前置';
is $hs.eval-line('!!').value, 7, '!! 重跑上一条';
is $hs.eval-line('5 + 6').value, 11, '历史替换第二条';
is $hs.eval-line('!1').value, 7, '!1 取第 1 条';
is $hs.eval-line('!$').value, 4, '!$ 取上一条最后参数';
nok $hs.eval-line('!999').ok, '越界历史项报错';

# ── config / alias ──────────────────────────────────────────────────
my $cfg-path = $*TMPDIR.add("rakuish-cfg-{$*PID}.json");
%*ENV<RAKUISH_CONFIG> = $cfg-path.Str;
my $cfg = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
ok $cfg.eval-line('alias e=echo hi').ok, '设置 alias';
is $cfg.eval-line('e').out.trim, 'hi', 'alias 展开后执行';
ok $cfg.eval-line('config set theme dark').ok, '设置 config';
is $cfg.eval-line('config get theme').out.trim, 'dark', '读取 config';
ok $cfg.eval-line('unalias e').ok, '删除 alias';
ok $cfg.eval-line('alias check=echo ok').ok, 'alias 写入后仍可设置';
ok $cfg-path.e, 'config 文件已落盘';
my $cfg2 = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
is $cfg2.eval-line('config get theme').out.trim, 'dark', '新会话加载 config';
ok $cfg2.eval-line('hook add start echo hook-ok').ok, '添加启动 hook';
is $cfg2.run-hooks('start').map(*.out).join('|').trim, 'hook-ok',
    'run-hooks 执行 start';
is $cfg2.eval-line('hook run start').out.trim, 'hook-ok', 'hook run start';
ok $cfg2.eval-line('hook clear start').ok, '清除启动 hook';
is $cfg2.run-hooks('start').elems, 0, '清除后无 hook';
%*ENV<RAKUISH_CONFIG>:delete;

# ── 多 Session：DSL 必须落到各自动态 Sys ────────────────────────────
my $da = $*TMPDIR.IO.add("multi-a-{$*PID}"); $da.mkdir;
my $db = $*TMPDIR.IO.add("multi-b-{$*PID}"); $db.mkdir;
$da.add('which.txt').spurt('A');
$db.add('which.txt').spurt('B');
my $sa = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($da), :cwd($da)));
my $sb = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($db), :cwd($db)));
is $sa.eval-line('read("which.txt")').value, 'A', 'Session A DSL';
is $sb.eval-line('read("which.txt")').value, 'B', 'Session B DSL';
is $sa.eval-line('read("which.txt")').value, 'A', '再次调用 A 不串到 B';

# ── shell 习惯的裸路径参数：cd .. / ls .. / stat . ─────────────────
my $sd = $*TMPDIR.IO.add("rakuish-shellish-{$*PID}");
my $sd-sub = $sd.add('sub'); mkdir $sd; mkdir $sd-sub;
LEAVE { try { $sd-sub.dir>>.unlink; $sd.dir>>.unlink; $sd-sub.rmdir; $sd.rmdir } }
my $sh = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($sd), :cwd($sd-sub)));
my $cd-dotdot = $sh.eval-line('cd ..');
ok $cd-dotdot.ok, 'cd .. 按 shell 习惯解析';
is $sh.sys.cwd.Str.subst('\\', '/', :g), $sd.Str.subst('\\', '/', :g),
    'cd .. 真的切到父目录';
ok $sh.eval-line('ls sub').ok, 'ls 裸路径参数按 shell 习惯解析';
ok $sh.eval-line('stat .').ok, 'stat . 按 shell 习惯解析';

# ── 默认 REPL 是文件系统根，不是启动 cwd ───────────────────────────
my $default = Rakuish::REPL::Session.new;
my $up = $default.eval-line('cd(".."); sys.cwd.Str');
ok $up.ok, '默认 REPL 可 cd 到父目录';
nok $up.err.contains('路径越出 root'), '默认 REPL root 不是启动 cwd';

# ── 多 Session：DSL 跟随当前求值会话，不串最后一个 bind-session ─────
my $d1 = $*TMPDIR.IO.add("rakuish-s1-{$*PID}"); $d1.mkdir;
my $d2 = $*TMPDIR.IO.add("rakuish-s2-{$*PID}"); $d2.mkdir;
LEAVE { try { $d1.dir>>.unlink; $d2.dir>>.unlink; $d1.rmdir; $d2.rmdir } }
my $s1 = Rakuish::REPL::Session.new(sys => Rakuish::Sys.new(:root($d1), :cwd($d1)));
my $s2multi = Rakuish::REPL::Session.new(sys => Rakuish::Sys.new(:root($d2), :cwd($d2)));
$s1.eval-line('write("only-s1.txt", "S1")');
$s2multi.eval-line('write("only-s2.txt", "S2")');
is $s1.eval-line('read("only-s1.txt")').value, 'S1',
    '先创建的 Session 的 DSL 仍绑定自己的 Sys';
is $s2multi.eval-line('read("only-s2.txt")').value, 'S2',
    '后创建的 Session 的 DSL 绑定自己的 Sys';

# ── 纯 sub / use 声明跨格；只要声明，不重放其它语句 ─────────────────
my $decl = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($d1), :cwd($d1)));
$decl.eval-line('sub twice($x) { $x * 2 }');
is $decl.eval-line('twice(21)').value, 42, '纯 sub 声明跨格可用';
$decl.eval-line('use JSON::Fast;');
ok $decl.eval-line('to-json({ a => 1 }).contains("a")').value,
    '纯 use 声明跨格可用';

# ── 没有反引号 shellq ───────────────────────────────────────────────
my $bq = $s.eval-line('`echo pwned`');
nok $bq.ok, '反引号不再被解释成 shell 捕获';
nok $bq.out.contains('pwned'), '没有执行 shell';

# 行首 != 是 Raku 运算符，不是 argv 入口
my $ne = $s.eval-line('!= 1');
is $ne.op, 'eval', '行首 != 按 Raku 处理';

# ── ! argv 分词：元字符原样、引号保护空格 ───────────────────────────
my $s2 = Rakuish::REPL::Session.new;
my $argv-line = q{! } ~ $R ~ q{ -e "say @*ARGS.raku" 'a|b' 'x y'};
my $ar = $s2.eval-line($argv-line);
ok $ar.ok, '! 执行外部程序成功';
ok $ar.out.contains('a|b'), '| 原样当参数，不被解释';
ok $ar.out.contains('x y'), '引号内空格被保留';
is $ar.op, 'exec', 'op = exec';

# 带 | 的 ! 行不触发管道：| 只是 argv 里的普通字符串
my $pipe = $s2.eval-line(q{! } ~ $R ~ q{ -e "say 9" | grep md});
ok $pipe.ok, '带 | 的 ! 行仍执行了 argv 中的程序';
is $pipe.out.trim, '9', '| 没触发管道，子进程只输出 9';
ok $pipe.value<argv>.grep(* eq '|').elems > 0, '| 作为普通 argv 传入';

my $empty = $s2.eval-line('!');
nok $empty.ok, '空 ! 报错';
is $empty.code, 127, '空 ! code = 127';
ok $empty.err.contains('没有命令'), 'err 说明原因';

# ── 跨格 my / 多行续行 / stdout delta ───────────────────────────────
my $s3 = Rakuish::REPL::Session.new;
is $s3.eval-line('my $x = 41;').value, 41, '第一格声明 my';
is $s3.eval-line('$x + 1').value, 42, 'my 跨格持久';
my $mo = $s3.eval-line('my @a = (');
is $mo.op, 'more', '括号未配平进入续行';
is $mo.value, 1, '续行缓冲 1 行';
my $fin = $s3.eval-line('1, 2); @a.elems');
ok $fin.ok, '续行合并后求值';
is $fin.value, 2, '续行结果正确';
my $say1 = $s3.eval-line('say "once 中文"');
is $say1.out.trim, 'once 中文', 'say 输出可见';
my $say2 = $s3.eval-line('1');
is $say2.out.trim, '', '历史 say 不重复回显（delta 去重）';

# ── EVAL 内的 sys / repl / registry / DSL ───────────────────────────
my $s4 = Rakuish::REPL::Session.new;
$s4.eval-line('1');
$s4.eval-line('2');
my $h = $s4.eval-line('repl.history.elems');
is $h.value, 2, 'EVAL 内可访问 repl.history';
my $cw = $s4.eval-line('sys.cwd.Str.chars > 0');
is $cw.value, True, 'EVAL 内可访问 sys';
my $rg = $s4.eval-line('registry.names.elems');
is $rg.value, 13, 'EVAL 内可访问 registry';
my $hlp = $s4.eval-line('help().elems');
is $hlp.value, 13, 'DSL 短 sub 在 REPL 表达式里可见';
my $tr = $s4.eval-line('repl.trace = True');
ok $tr.ok, 'repl 状态可在 EVAL 内赋值';
ok $s4.trace, 'repl.trace 真的被改了';

# ── 快捷键：纯交互动作不占文本命令 ─────────────────────────────────
is $s4.key-bindings.elems, 7, '按键绑定表 7 项';
is $s4.handle-key('Ctrl-C').value, 'interrupted', 'Ctrl-C 中断';
ok $s4.interrupt-requested, '中断标记置位';
is $s4.handle-key('Ctrl-D').value, 'exit', 'Ctrl-D 退出';
ok $s4.exit-requested, '退出标记置位';
my $sr = $s4.handle-key('Ctrl-R', :query('1'));
ok $sr.value.elems >= 1, 'Ctrl-R 搜到含 1 的历史';
ok $s4.handle-key('Up').value.chars > 0, 'Up 取回历史';
is $s4.handle-key('Ctrl-X Ctrl-E').value, 'edit-request', '外部编辑请求';
nok $s4.handle-key('F99').ok, '未绑定按键失败';

# ── exit 与渲染 ─────────────────────────────────────────────────────
my $s5 = Rakuish::REPL::Session.new;
my $ex = $s5.eval-line('exit 3');
is $ex.op, 'exit', 'exit 映射为退出请求（不杀进程）';
ok $s5.exit-requested, '退出标记置位';
is $s5.exit-code, 3, 'exit N 保留退出码';
nok $s5.render($ex).contains('Out['), 'exit 不渲染假的 Out[n]';

my $s6 = Rakuish::REPL::Session.new;
my $rr = $s6.eval-line('42');
ok $s6.render($rr).contains('Out[1] = 42'), 'render 输出 Out[n]';
my $skip = $s6.eval-line('   ');
is $skip.op, 'skip', '空行被跳过';

# 内置命令返回的是 Result 时，REPL 展示它的 text 渲染，而不是 Result 的 raku 结构
my $inner = Result.new(:ok, :out("done\n"), :op<read>);
my $outer = Result.new(:ok, :op<eval>, :value($inner));
my Str $rendered = $s6.render($outer);
is $rendered, 'done', 'REPL 内置 Result 优先显示 stdout';
nok $rendered.contains('Result.new'), '不展示 Result 的 raku 结构';

my $struct = Result.new(:ok, :value({ a => 1 }));
my $struct-outer = Result.new(:ok, :op<eval>, :value($struct));
like $s6.render($struct-outer), /^ 'ok: true'/, '无 stdout 的内置 Result 回退 text';

# ls / glob / recent 返回 List[IO::Path]：展示成 shell 风格的名字，而不是 IO::Path 对象
my $paths = [$*CWD.add('README.md'), $*CWD.add('META6.json')];
my $ls-result = Result.new(:ok, :op<eval>, :value($paths));
my Str $ls-text = $s6.render($ls-result);
like $ls-text, /'README.md'/, 'List[IO::Path] 显示 basename';
like $ls-text, /'META6.json'/, 'List[IO::Path] 多个文件都显示';
nok $ls-text.contains('IO::Path'), '不显示 IO::Path 的 raku 结构';
nok $ls-text.contains($*CWD.Str), '不显示绝对路径前缀';

my $one-path = Result.new(:ok, :op<eval>, :value($*CWD));
is $s6.render($one-path), $*CWD.Str, '单个 IO::Path 直接显示路径';

done-testing;
