use Test;

# 22-data-csv.t —— CSV 受控外部读写（0.68.0 / ADR-0005 §2）
#
# 与 Parquet 共用一套显式授权：必须 :allow-external、路径经 Sys.resolve、
# Agent 不开放。**不带开关的 .csv 行为完全不变**（走 Sys.read/write）。
# 显式授权时由 DuckDB 做类型推断 / COPY 写出。
# 可选驱动缺失时如实 skip，核心安装不被 NativeCall 依赖拖住。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Data;
use Rakuish::Data::Table;
use Rakuish::Data::Engine::DuckDB;
use Rakuish::Sandbox;

my $mod = try { require ::('DB::DuckDB') };
my Bool $have = try { $mod.^name eq 'DB::DuckDB' } // False;
if !$have {
    skip 'DB::DuckDB 未安装，跳过 CSV 外部读写测试', 33;
    done-testing;
}
else {
    my $dir = $*CWD.add('tmp').add('csv-test');
    $dir.mkdir unless $dir.e;
    my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
    my $src = 'sample.csv';
    $dir.add($src).spurt(
        "id,name,score\n1,alpha,1.5\n2,beta,2.5\n3,gamma,3.5\n");

    # ── 1. 默认路径：行为与 0.64 一致，不经 DuckDB ───────────────────
    my $plain = Rakuish::Data::open-data($sys, $src);
    isa-ok $plain, Rakuish::Data::Table, '默认 .csv 读取返回 Table';
    is $plain.elems, 3, '默认读取 3 行';
    is-deeply $plain.columns.List, <id name score>.List, '默认读取列名';
    is $plain.column-type('id'), 'str',
        '默认路径由 Raku 解析器处理，类型仍是 str（没有偷偷走 DuckDB）';

    Rakuish::Data::save-data($sys, 'plain-out.csv', $plain);
    ok $dir.add('plain-out.csv').e, '默认 .csv 写入经 Sys.write 落盘';
    is $dir.add('plain-out.csv').slurp.lines[0], 'id,name,score',
        '默认写入带表头';
    is $sys.read('plain-out.csv').lines.elems, 4,
        '默认写入内容可被 Sys.read 回读';

    # ── 2. 显式授权读取：DuckDB 类型推断 ─────────────────────────────
    my $ext = Rakuish::Data::open-data($sys, $src, :allow-external);
    isa-ok $ext, Rakuish::Data::Table, ':allow-external 读取返回 Table';
    is $ext.elems, 3, '外部读取 3 行';
    is $ext.column-type('id'), 'int', '外部读取推断出 int 列';
    is $ext.column-type('score'), 'num', '外部读取推断出 num 列';
    is-deeply $ext.get('name').List, <alpha beta gamma>.List,
        '外部读取字符串列内容正确';

    # ── 3. 显式授权写出 + 往返 ───────────────────────────────────────
    my $written = Rakuish::Data::save-data($sys, 'duck-out.csv', $ext,
                                           :allow-external);
    is $written, True, ':allow-external 写入返回 True';
    ok $dir.add('duck-out.csv').e, 'DuckDB COPY 生成 CSV 文件';
    is $dir.add('duck-out.csv').slurp.lines[0], 'id,name,score',
        'DuckDB 导出带 HEADER';
    my $back = Rakuish::Data::open-data($sys, 'duck-out.csv',
                                        :allow-external);
    is $back.elems, 3, '导出文件可被外部读取往返';
    is $back.column-type('id'), 'int', '往返后类型推断仍正确';

    # 接受非 Table 值：内部转成 Table（与 Parquet 导出一致）
    ok Rakuish::Data::save-data($sys, 'duck-rows.csv',
                                [{ x => 1, y => 'a' }, { x => 2, y => 'b' }],
                                :allow-external),
        '数组值也能走外部 CSV 导出';

    # ── 4. 安全边界：root 校验 / 默认拒绝 / Agent 白名单 ───────────────
    throws-like { Rakuish::Data::open-data($sys, '../outside.csv',
                                           :allow-external) },
        X::Rakuish::Sandbox, '外部读取路径越 root 被拒';
    throws-like { Rakuish::Data::save-data($sys, '../outside.csv', $ext,
                                           :allow-external) },
        X::Rakuish::Sandbox, '外部写入路径越 root 被拒';
    throws-like { Rakuish::Data::open-data($sys, 'x.parquet') },
        X::Rakuish::Unsupported, 'Parquet 不带开关仍拒绝（0.64 行为不变）';
    ok Rakuish::Data::open-data($sys, $src).elems == 3,
        'CSV 不带开关不拒绝（默认文本路径仍然可用）';

    my $sb = Rakuish::Sandbox.new(:root($dir));
    nok $sb.op-allowed('read_csv'), 'Agent op 白名单不含 read_csv';
    nok $sb.op-allowed('write_csv'), 'Agent op 白名单不含 write_csv';
    nok $sb.allowed-ops.grep({ .contains('csv') }).elems,
        'Agent op 白名单不含任何 csv 相关 op';

    # ── 5. 引擎契约：不支持的引擎明确拒绝、错误统一 ───────────────────
    {
        class Bare does Rakuish::Data::Engine {
            method query(|c)    { Rakuish::Data::Table.new }
            method execute(|c)  { 0 }
            method begin(|c)    { Nil }
            method commit(|c)   { Nil }
            method rollback(|c) { Nil }
            method tables(|c)   { Rakuish::Data::Table.new }
            method schema(|c)   { Rakuish::Data::Table.new }
            method close(|c)    { Nil }
        }
        throws-like { Bare.new.read-csv('x.csv') },
            X::Rakuish::Unsupported, '角色默认拒绝 read-csv';
        throws-like { Bare.new.write-csv('x.csv', 'select 1') },
            X::Rakuish::Unsupported, '角色默认拒绝 write-csv';
    }
    throws-like { Rakuish::Data::open-data($sys, 'missing.csv',
                                           :allow-external) },
        X::Rakuish::Data, '外部读取驱动错误统一为 X::Rakuish::Data';

    my $engine = Rakuish::Data::Engine::DuckDB.new(
        :path<:memory:>, :safe(False), :!read-only);
    is $engine.read-csv($dir.add($src).Str, :max-rows(2)).elems, 2,
        'Engine.read-csv 支持 :max-rows LIMIT 下推';
    throws-like { $engine.write-csv($dir.add('bad.csv').Str,
                                    'select 1; drop table t') },
        X::Rakuish::Data, 'write-csv 拒绝含分号的导出 SQL';
    throws-like { Rakuish::Data::Engine::DuckDB.new.read-csv($dir.add($src).Str) },
        X::Rakuish::Unsupported, ':safe 引擎拒绝 CSV 外部读取';
    $engine.close;

    # ── 6. Parquet 导出流程回归（export-table 抽出后不能坏）────────────
    my $pq = Rakuish::Data::save-data($sys, 'roundtrip.parquet', $ext,
                                      :allow-external);
    is $pq, True, 'Parquet 导出仍成功';
    is Rakuish::Data::open-data($sys, 'roundtrip.parquet',
                                :allow-external).elems, 3,
        'Parquet 往返行数正确';

    # ── 清理 ─────────────────────────────────────────────────────────
    for <sample.csv plain-out.csv duck-out.csv duck-rows.csv roundtrip.parquet>
        -> $f { try { $dir.add($f).unlink } }
    try { $dir.rmdir };
    done-testing;
}
