use Test;
use Rakuish::Result;
use Rakuish::Data::Engine::SQLite;
use Rakuish::Data::Table;
use Rakuish::DSL;
use Rakuish::Sys;

bind-session(Rakuish::Sys.new(:root($*CWD), :cwd($*CWD)));

# t/13 —— SQLite 数据引擎适配器（可选依赖）

my $mod = try { require ::('DB::SQLite') };
my Bool $have = try { $mod.^name eq 'DB::SQLite' } // False;

if !$have {
    skip 'DB::SQLite 未安装，跳过 SQLite 引擎测试', 17;
    done-testing;
}
else {
    my $ro = Rakuish::Data::Engine::SQLite.new;
    is $ro.query('select 1 as n').get('n').List, (1,), '只读查询';
    is $ro.query(q{select 'copy' as x}).get('x').List, ('copy',),
        '字符串里的 write 关键字不误拒';
    is $ro.query('select 1 /* drop */ as x').get('x').List, (1,),
        '注释里的 write 关键字不误拒';
    throws-like { $ro.execute('create table t (x int)') },
        X::Rakuish::Unsupported, '只读拒绝 execute';
    throws-like { $ro.query('create table t (x int)') },
        X::Rakuish::Unsupported, '只读拒绝 DDL query';
    $ro.close;

    my $db = Rakuish::Data::Engine::SQLite.new(:!read-only);
    is $db.execute('create table t (x int)'), 0, '建表';
    is $db.execute('insert into t values (?)', 1), 1, '参数化插入 1';
    is $db.execute('insert into t values (?)', 2), 1, '参数化插入 2';
    is $db.query('select x from t order by x').get('x').List, (1, 2),
        '参数化写入后可查询';
    like $db.tables.to-text, /'t'/, 'tables';
    like $db.schema('t').to-text, /'x'/, 'schema';
    $db.execute('create table tx (x int)');
    $db.begin;
    $db.execute('insert into tx values (?)', 1);
    $db.rollback;
    is $db.query('select count(*) as n from tx').get('n').List, (0,),
        'SQLite rollback';
    $db.begin;
    $db.execute('insert into tx values (?)', 2);
    $db.commit;
    is $db.query('select count(*) as n from tx').get('n').List, (1,),
        'SQLite commit';
    $db.close;

    my $slow = Rakuish::Data::Engine::SQLite.new(
        :max-execution-time-ms(20));
    dies-ok {
        $slow.query(q{WITH RECURSIVE cnt(x) AS (
            SELECT 1 UNION ALL SELECT x+1 FROM cnt WHERE x<100000000
        ) SELECT count(*) FROM cnt});
    }, 'SQLite 查询超时可中断';
    $slow.close;

    my $fac = open-db(':memory:', :engine<sqlite>, :!read-only);
    is $fac.query('select 7 as n').get('n').List, (7,), 'open-db engine 选择 sqlite';
    $fac.close;

    my $ro-path = $*TMPDIR.add("rakuish-ro-{$*PID}.db");
    my $rw = Rakuish::Data::Engine::SQLite.new(:path($ro-path.Str), :!read-only);
    $rw.execute('create table meta (id int, name text)');
    $rw.close;
    my $readonly = Rakuish::Data::Engine::SQLite.new(:path($ro-path.Str));
    is $readonly.schema('meta').elems, 2,
        '默认只读 SQLite 可读 schema（pragma table_info）';
    is $readonly.describe('meta').elems, 2,
        '默认只读 SQLite 可 describe 表名';
    $readonly.close;
    try { $ro-path.unlink };
    done-testing;
}
