use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Command;
use Rakuish::Sandbox;
use Rakuish::REPL::Session;
use Rakuish::REPL::Shell;
use Rakuish::REPL::Keymap;
use Rakuish::REPL::Hints;
use Rakuish::REPL::Plugins;
use Rakuish::REPL::Chrome;
use Terminal::LineEditor;
use Terminal::LineEditor::RawTerminalInput;

# 19-repl-experience.t —— Vi/Helix 模式、hints、本地 Raku 插件（0.66 / ADR-0003）
# 重点：默认不改变既有行为、插件默认拒绝且不进 Agent、管道下不输出任何装饰。

my $base = $*TMPDIR.IO.add("rakuish-exp-{$*PID}");
$base.mkdir;
LEAVE {
    try {
        for $base.dir -> $e { try { $e.unlink } }
        $base.rmdir;
    }
}

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my $shell = Rakuish::REPL::Shell.new(:sys($sys));
my $reg = default-registry();

# ── 一、ViState 语义层 ───────────────────────────────────────────────
my $v = vi-state();
isa-ok $v, ViState, 'vi-state 返回 ViState';
$v.start-line(:text(''), :mode<insert>);
is $v.mode-label, 'INSERT', '默认 insert 模式';
is $v.handle('Z'), 'insert', 'insert 模式直接插入字符';
is $v.buffer, 'Z', '插入后缓冲正确';
is $v.handle('Escape'), 'normal', 'Esc 切到 normal';
is $v.mode-label, 'NORMAL', '模式标签 NORMAL';

$v.start-line(:text<abc>, :mode<normal>);
is $v.cursor, 3, 'start-line 光标在行尾';
is $v.handle('h'), 'move-left', 'h 左移';
is $v.cursor, 2, 'h 后光标位置';
is $v.handle('0'), 'move-start', '0 到行首';
is $v.cursor, 0, '0 后光标为 0';
is $v.handle('$'), 'move-end', '$ 到行尾';
$v.handle('h');
is $v.handle('x'), 'delete-char', 'x 删除字符';
is $v.buffer, 'ab', 'x 后缓冲少一个字符';
is $v.yank, 'c', 'x 记住被删字符';
is $v.handle('u'), 'undo', 'u 撤销';
is $v.buffer, 'abc', 'u 恢复缓冲';
is $v.handle('p'), 'paste', 'p 粘贴';
is $v.handle('i'), 'insert-mode', 'i 回到 insert';
$v.handle('Escape');
is $v.handle('d'), 'pending-d', '第一次 d 进入 pending';
is $v.handle('d'), 'delete-line', 'dd 删整行';
is $v.buffer, '', 'dd 后缓冲为空';

$v.start-line(:text('one two'), :mode<normal>);
$v.handle('0');
$v.handle('w');
ok $v.cursor > 0 && $v.cursor < 7, 'w 前进到下一个词';
$v.handle('b');
is $v.cursor, 0, 'b 回到词首';
is $v.handle('D'), 'delete-to-end', 'D 删到行尾';
$v.start-line(:text<abc>, :mode<normal>);
is $v.handle('j'), 'history-next', 'j 映射历史下一格';
is $v.handle('k'), 'history-prev', 'k 映射历史上一格';

# ── 二、键位预设与行编辑器子类 ───────────────────────────────────────
is keymap-preset('emacs').elems, 0, 'emacs 不改默认 keymap';
is keymap-preset('vi')<Alt-h>, 'move-char-back', 'vi 预设 Alt-h 左移';
is keymap-preset('helix')<Alt-x>, 'delete-to-end', 'helix 预设 Alt-x 删到行尾';
ok vi-actions()<Escape> eq 'vi-normal', 'ESC 绑定 vi-normal';
ok vi-actions()<vi-i> eq 'vi-insert', 'i 绑定 vi-insert';

my $plain = try { Terminal::LineEditor::CLIInput.new(:get-completions(-> $l, $p { () })) };
if $plain.defined {
    my Int $ok-count = 0;
    for keymap-preset('vi').kv -> $k, $a {
        try { $plain.bind-key($k, $a); $ok-count++ }
    }
    is $ok-count, keymap-preset('vi').elems, 'vi 预设的每个 action 都是合法 edit action';
    my Int $hx = 0;
    for keymap-preset('helix').kv -> $k, $a {
        try { $plain.bind-key($k, $a); $hx++ }
    }
    is $hx, keymap-preset('helix').elems, 'helix 预设的每个 action 也合法';
}
else {
    skip '行编辑器不可构造，跳过预设绑定验证', 2;
}

my $emacs-cli = make-cli(:style<emacs>, :get-completions(-> $l, $p { () }));
ok $emacs-cli.defined, 'emacs 模式构造行编辑器';
ok $emacs-cli.^name.contains('InterruptCLIInput'),
    'emacs 也走中断子类（0.71 / ADR-0008）';

my $vi-cli = make-cli(:style<vi>, :start-mode<normal>,
                      :get-completions(-> $l, $p { () }));
ok $vi-cli.defined, 'vi 模式构造行编辑器';
ok $vi-cli.^name.contains('ViCLIInput'), 'vi 模式走模态子类';
is vi-state().start-mode, 'normal', 'start-mode 配置为 normal';
is $vi-cli.decode-keyname('h'), 'vi-h', 'normal 模式下 h 映射成 vi-h';
is $vi-cli.decode-keyname("\e"), 'Escape', 'ESC 解码成 Escape';
vi-state().set-mode('insert');
nok $vi-cli.decode-keyname('h').defined, 'insert 模式下 h 不当按键（直接插入）';
ok bind-vi-keys($vi-cli) > 0, 'vi 键位全部可绑定';

# ── 二·b、Ctrl-C 中断标志（0.71 / ADR-0008 §3.1）────────────────────
# 真 PTY 下的「进程不退出」由 t/27 验证；这里只测可纯逻辑判定的解码 / 标志。
ok $emacs-cli.^can('take-interrupt'), '行编辑器暴露 take-interrupt';
nok $emacs-cli.take-interrupt, '未经 Ctrl-C 时没有中断标志';
is $emacs-cli.decode-keyname(chr(3)), 'Ctrl-C', 'Ctrl-C 字节解码成 Ctrl-C';
ok $emacs-cli.take-interrupt, 'Ctrl-C 置中断标志';
nok $emacs-cli.take-interrupt, '中断标志一次性消费';
is $emacs-cli.decode-keyname(chr(4)), 'Ctrl-D', 'Ctrl-D 仍解码成 Ctrl-D';
nok $emacs-cli.take-interrupt, 'Ctrl-D 不误报中断';
ok $vi-cli.^can('take-interrupt'), 'vi 子类继承中断入口';
is $vi-cli.decode-keyname(chr(3)), 'Ctrl-C', 'vi 模式 Ctrl-C 也解码';
ok $vi-cli.take-interrupt, 'vi 模式 Ctrl-C 置标志';
nok $vi-cli.take-interrupt, 'vi 模式标志同样一次性';
if $plain.defined {
    nok $plain.^can('take-interrupt'), '原生 CLIInput 没有中断入口（回退边界）';
}

# ── 三、hints ────────────────────────────────────────────────────────
ok hint-for('config').contains('config'), '会话命令提示给出用法';
ok hint-for('ls', :$shell).contains('用法: ls'), 'Shell 命令提示取 usage 首行';
ok hint-for('! git status').contains('argv-only'), '! 外部命令提示 argv 语义';
ok hint-for('--help').contains('启动参数'), '--xxx 提示启动参数';
is hint-for('no_such_cmd_xyz', :$shell, :registry($reg)), '', '未知输入没有提示';
ok hint-for('plugin').contains('load PATH'), 'plugin 命令有提示';

my $bad = Result.new(:!ok, :code(1), :op<eval>, :err('Undeclared routine: foo'));
ok result-hint($bad, 'foo()').contains('Raku 求值'), '未声明例程给下一步建议';
my $nf = Result.new(:!ok, :code(127), :op<eval>, :err('not found'));
ok result-hint($nf, 'foo').contains('which'), '127 提示查 which';
is result-hint(Result.new(:ok, :op<eval>), '1+1'), '', '成功格不打扰用户';

my $hs = Rakuish::REPL::Session.new(:sys($sys));
ok $hs.hint-text('config').chars > 0, 'Session.hint-text 可用';
my $ok-result = Result.new(:ok, :op<eval>);
ok $hs.next-hint('ls', $ok-result).chars > 0, 'next-hint 首次给出命令提示';
is $hs.next-hint('ls', $ok-result), '', 'next-hint 同一首词只提示一次';

# ── 四、插件：默认拒绝、注册、卸载、边界 ─────────────────────────────
$base.add('demo.rakumod').spurt(q:to/PLUGIN/);
use Rakuish::Command;
use Rakuish::Result;
say 'loading demo';
(
    BuiltinCommand.new(:cmd-name<hello>, :summary('示例插件 A'),
        :handler(-> $s, |c { Result.new(:ok, :out('hello')) })),
    BuiltinCommand.new(:cmd-name<shout>, :summary('示例插件 B'),
        :handler(-> $s, |c { Result.new(:ok, :out('SHOUT')) })),
)
PLUGIN
$base.add('conflict.rakumod').spurt(q:to/PLUGIN/);
use Rakuish::Command;
use Rakuish::Result;
BuiltinCommand.new(:cmd-name<read>, :summary('想覆盖内建'),
    :handler(-> $s, |c { Result.new(:ok) }))
PLUGIN
$base.add('bad.rakumod').spurt('42');
$base.add('bad.txt').spurt('42');

my $ps = Rakuish::REPL::Session.new(:sys($sys));
is $ps.plugins.names.elems, 0, '初始没有插件';
ok $ps.eval-line('plugin list').out.contains('未加载插件'), 'plugin list 显示空';

my $denied = $ps.eval-line('plugin load demo.rakumod');
nok $denied.ok, '默认拒绝加载插件';
is $denied.code, 403, '拒绝码 403';
ok $denied.err.contains('默认关闭'), '提示需要显式开启';

$ps.config<plugins> = 'on';
my $loaded = $ps.eval-line('plugin load demo.rakumod');
ok $loaded.ok, '开启后加载成功';
ok $loaded.out.contains('loading demo'), '插件 stdout 被捕获而非污染终端';
ok $ps.commands.has('hello'), '插件命令注册进会话 registry';
is $ps.commands.run('hello', $sys).out, 'hello', '插件命令可真实执行';
is $ps.plugins.names.elems, 1, '插件列表有一项';
ok $ps.eval-line('plugin info demo.rakumod').out.contains('hello'),
    'plugin info 列出命令';
ok $ps.eval-line('plugin list').out.contains('demo.rakumod'),
    'plugin list 列出已加载插件';

my $conflict = $ps.eval-line('plugin load conflict.rakumod');
nok $conflict.ok, '不能覆盖内建命令';
is $conflict.code, 409, '冲突码 409';
nok $ps.eval-line('plugin load bad.rakumod').ok, '非 Command 返回值被拒绝';
nok $ps.eval-line('plugin load bad.txt').ok, '错误扩展名被拒绝';
nok $ps.eval-line('plugin load ../outside.rakumod').ok, 'root 越界被拒绝';

ok $ps.eval-line('plugin unload demo.rakumod').ok, '卸载插件成功';
nok $ps.commands.has('hello'), '卸载后命令被移除';
nok $ps.eval-line('plugin unload demo.rakumod').ok, '重复卸载报错';
ok $ps.eval-line('plugin help').out.contains('用法'), 'plugin help 给用法';
ok $ps.eval-line('hint perf').out.contains('perf'), 'hint 命令可查询';
ok $ps.eval-line('help plugin').out.contains('load PATH'), 'help plugin 给用法';

my $sb = Rakuish::Sandbox.new(:root($base), :token('t'));
nok $sb.op-allowed('plugin'), 'Agent op 白名单不含 plugin';
nok $sb.op-allowed('hint'), 'Agent op 白名单不含 hint';
ok $sb.op-allowed('glob'), '既有 Agent op 未被破坏';

# ── 五、展示层与管道纯文本 ───────────────────────────────────────────
ok banner-text(:version<9.9.9>, :mode<vi>).contains('编辑模式 vi'),
    'banner 显示非默认编辑模式';
nok banner-text(:version<9.9.9>, :mode<emacs>).contains('编辑模式'),
    'emacs 不显示编辑模式徽标';
ok banner-text(:version<9.9.9>, :plugins('2')).contains('插件 2'),
    'banner 显示已加载插件数';
ok prompt-text(:cwd</x>, :mode('VI·NORMAL')).contains('VI·NORMAL'),
    'prompt 显示模式徽标';
nok prompt-text(:cwd</x>, :mode('VI·NORMAL'), :style<compact>).contains('VI·NORMAL'),
    'compact 风格不显示模式徽标';

my $root = $*CWD.IO.absolute.IO;
loop {
    last if $root.add('META6.json').e;
    my $up = $root.parent;
    last if $up.absolute.Str eq $root.absolute.Str;
    $root = $up;
}
my $in = $*TMPDIR.IO.add("rakuish-exp-pipe-{$*PID}.txt");
$in.spurt("ls --help\n1 + 1\nexit\n");
my $fh = $in.open(:r);
my $proc = run($*EXECUTABLE.Str, '-Ilib', $root.add('bin/rakuish').Str,
               :in($fh), :out, :err);
my $pipe-out = $proc.out.slurp(:close);
$proc.err.slurp(:close);
$fh.close;
try $in.unlink;
ok $pipe-out.contains('Out['), '管道下仍正常求值';
nok $pipe-out.contains("\e["), '管道下没有 ANSI 控制码';
nok $pipe-out.contains('  · '), '管道下没有 hint 装饰行';

done-testing;
