#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::REPL::Highlight;
use Rakuish::REPL::Chrome;
use Rakuish::REPL::Session;

# 33-colors.t —— 结果着色与输入行语法高亮（0.74.0 / SPEC V-176 / V-177 / ADR-0011）。
#
# 这里只测**不依赖终端**的部分：着色器的纯文本等价、色表、以及「无色时
# 逐字节不变」。真 PTY 下的实际观感（列对齐、输入区不错位）由
# `tools/tty-check.py` 覆盖 —— prove6 跑在管道里，$*OUT.t 恒为假。

sub strip-ansi(Str $s --> Str) {
    $s.subst(/ \e \[ <[0..9;]>* m /, :g, '');
}

# ── 一、高亮器的核心不变式：纯文本逐字符等价 ────────────────────────
# 行编辑器用 display-width 定位光标与清屏，着色串的纯文本部分多一个或少一个
# 字符都会让输入区错位（ADR-0011 §4.2）。这条断言就是那条不变式。
my @samples =
    '',
    '1 + 1',
    q{say "hello"},
    q{'single quoted'},
    q{my $x = 42; # trailing comment},
    q{for @list -> $v { say $v }},
    q{my %h = (a => 1, b => 2);},
    q|say "escaped \" quote"|,
    q{"unclosed string},
    q{1.abs},
    q{$},
    q{a-b},
    q{中文 "字符串" 混排},
    q{  leading and trailing  },
    q{if $x > 0 && $y < 10 { say True }},
    q{class Foo is Bar { has $.x }},
    q{# only a comment},
    q{},
    q{say "日本語テキスト" # コメント},
    q{$*CWD.Str},
    q{$!private-attr},
    q{%*ENV<HOME>},
    q{@*ARGS[0]},
    q{&some-sub(1, 2)},
    q{0x1F + 1_000 + 3.14e-2},
    q{a # b " c},
    q{"a" # "b"},
    ;

for @samples.kv -> $i, $s {
    is strip-ansi(highlight-line($s)), $s,
       "样本 {$i} 的纯文本等价（{ $s.chars } 字符）";
}

# ── 二、关闭着色时逐字节相同（不经过任何扫描） ──────────────────────
for @samples.kv -> $i, $s {
    is highlight-line($s, :!color), $s, "样本 {$i} 在 :!color 下原样返回";
}

# ── 三、各类 token 确实命中了对应颜色 ──────────────────────────────
sub painted(Str $s, Str $probe --> Bool) { highlight-line($s).contains($probe) }

ok painted('say 1', %CLR{'b-blue'}), '关键字 → 粗蓝';
ok painted('"x"', %CLR<green>), '字符串 → 绿';
ok painted('# note', %CLR<gray>), '注释 → 灰';
ok painted('42', %CLR<yellow>), '数字 → 黄';
ok painted('$x', %CLR<cyan>), '变量 → 青';
ok painted('my $x', %CLR{'b-blue'}), 'my 也被识别为关键字';

nok painted('a-b', %CLR{'b-blue'}), '普通标识符不当作关键字';
nok painted('$', %CLR<cyan>), '孤立的 $ 不吞成变量';
ok painted("'a#b'", %CLR<green>), '字符串里的 # 不当注释';
nok painted("'a#b'", %CLR<gray>), '字符串里的 # 没有注释色';

# ── 四、色表与路径分类 ────────────────────────────────────────────
is %CLR<reset>, "\e[0m", '色表有 reset';
is paint('x', %CLR<red>, True), %CLR<red> ~ 'x' ~ %CLR<reset>, 'paint 包住两端';
is paint('x', %CLR<red>, False), 'x', 'paint 关闭时原样';
is paint('x', Nil, True), 'x', 'paint 遇到空色码不抛异常';

my $dir = $*CWD.add('lib');
is path-color($dir), %CLR{'b-blue'}, '目录 → 粗蓝';
my $file = $*CWD.add('META6.json');
is path-color($file), '', '普通文件 → 无色';

# ── 五、Session：非 TTY 下即使 color=True 也不输出 ANSI ───────────
# 这一条守的是 SPEC V-116：管道里的 stdout 只能是求值结果。
my $cs = Rakuish::REPL::Session.new(:color(True));
my $rr = $cs.eval-line('ls');
my Str $rendered = $cs.render($rr);
nok $rendered.contains("\e["), '非 TTY：ls 结果不含 ANSI（即使 color=True）';
ok $rendered.chars > 0, '非 TTY：ls 仍正常输出文件名';

my $rl = $cs.eval-line('ls -l');
nok $cs.render($rl).contains("\e["), '非 TTY：ls -l 结果不含 ANSI';

my $rh = $cs.eval-line('help()');
nok $cs.render($rh).contains("\e["), '非 TTY：help() 结果不含 ANSI';

my $re = $cs.eval-line('1 + 1');
nok $cs.render($re).contains("\e["), '非 TTY：Out[n] 标签不含 ANSI';

# ── 六、默认构造（未传 color）也必须是纯文本 ─────────────────────
my $plain = Rakuish::REPL::Session.new;
my $pr = $plain.eval-line('ls');
nok $plain.render($pr).contains("\e["), '默认 Session 不带颜色（安全的默认值）';
nok $plain.color, '默认 color 为假（安全的默认值，别改成 True）';

done-testing;
