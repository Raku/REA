use Test;
use Rakuish::Sys;
use Rakuish::REPL::Session;

# t/09 —— REPL 内置命令的“人读展示”契约
#
# 目标不是改变值类型，而是让交互输出符合 shell 习惯：
#   help()      → 命令 + 说明
#   env()       → KEY=VALUE
#   stat()      → path/type/size...
#   write()     → wrote N bytes to PATH
#   read()/pwd()→ 直接内容/路径
#   rm()        → 命令自己的 out
#   glob()      → basename 列表

my $base = $*TMPDIR.IO.add("rakuish-display-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my $s = Rakuish::REPL::Session.new(:sys($sys));

sub rendered(Str $line --> Str) {
    $s.render($s.eval-line($line))
}

# ── help：命令 + 摘要，不是 $("...") ───────────────────────────────
my Str $help = rendered('help()');
like $help, /'read'/ && /'读取文件'/, 'help 显示命令名与摘要';
like $help, /'write'/ && /'写入文件'/, 'help 覆盖多个命令';
nok $help.contains('$('), 'help 不显示 List 的 raku 结构';
nok $help.contains('Out['), 'help 不套 Out[n]';

# ── registry.names：一行一个 ──────────────────────────────────────
my Str $names = rendered('registry.names');
like $names, /^ 'append'/, 'registry.names 首行是 append';
ok $names.contains('read'), 'registry.names 含 read';
nok $names.contains('$('), 'registry.names 不是 List raku';

# ── env：KEY=VALUE ───────────────────────────────────────────────
$s.eval-line('set-env("RAKUISH_DISPLAY_TEST", "yes")');
my Str $env = rendered('env()');
ok $env.lines.grep(* eq 'RAKUISH_DISPLAY_TEST=yes').elems == 1,
    'env 是 KEY=VALUE';
nok $env.contains(':RAKUISH_DISPLAY_TEST'), 'env 不是 Raku Pair/Hash 结构';

# ── write / stat / read / pwd / rm / glob ────────────────────────
my Str $w = rendered('write("a.txt", "hello")');
like $w, /^ 'wrote 5 bytes to '/, 'write 显示字节数与路径';
nok $w.contains('WriteResult.new'), 'write 不显示 WriteResult 结构';

my Str $st = rendered('stat("a.txt")');
like $st, /^ 'path:'/, 'stat 首行是 path';
like $st, /'type: file'/, 'stat 显示类型';
like $st, /'size: 5'/, 'stat 显示大小';
nok $st.contains('Stat.new'), 'stat 不显示 Stat 结构';

my Str $r = rendered('read("a.txt")');
is $r, 'hello', 'read 直接显示内容，不带 Raku 引号';

my Str $pwd = rendered('pwd()');
is $pwd.subst('\\', '/', :g), $base.Str.subst('\\', '/', :g),
    'pwd 直接显示路径';

my Str $g = rendered('glob("*.txt")');
like $g, /'a.txt'/, 'glob 显示 basename';
nok $g.contains('IO::Path'), 'glob 不显示 IO::Path 结构';
$base.add('sub').mkdir;
$base.add('sub/c.txt').spurt('c');
ok rendered('ls -R sub').contains('sub/c.txt'),
    '递归 ls 显示相对路径，保留目录上下文';
ok rendered('ls -R sub').contains('sub:'),
    '递归 ls 显示目录头';

my Str $rm = rendered('rm("a.txt")');
like $rm, /'removed 1 项'/, 'rm 显示命令自己的 out';
nok $rm.contains('ok: true'), 'rm 不强行套完整 Result text';

done-testing;
