use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Command;
use Rakuish::DSL;

# Phase 3 · Command 协议 + DSL 短 sub（ADR-0001 §2.3）
# 覆盖：spec / schema、注册表扩展、Result 不套娃、DSL 全部短命令、
# timed、以及「用户自己加常用命令」的 recent 示范。

my $base = $*TMPDIR.IO.add("v3-dsl-cmd-{$*PID}");
$base.mkdir;
my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
bind-session($sys);

# ── CommandSpec / JSON Schema ────────────────────────────────────────
my $reg = default-registry();
is $reg.elems, 13, '默认注册表 13 个命令';
ok $reg.has('read'), 'read 已注册';
ok $reg.has('exec'), 'exec 已注册';
nok $reg.has('magic'), '注册表里没有 magic';
nok $reg.has('shell'), '注册表里没有 %shell 类命令';

my $spec = $reg.get('read').spec;
is $spec.name, 'read', 'spec.name = read';
is $spec.params.elems, 1, 'read 一个参数';
is $spec.params[0].name, 'path', '参数名 path';
ok $spec.params[0].required, 'path 必填';
my $schema = $spec.to-json-schema;
is $schema<type>, 'object', 'schema type = object';
ok 'path' (elem) $schema<required>, 'schema required 含 path';
is $schema<properties><path><type>, 'string', 'path 映射为 string';
is $reg.to-json-schema.elems, 13, '注册表整体 schema 列表';
ok $spec.to-hash<summary>.chars > 0, 'spec 可序列化';

# ── 注册表 run ───────────────────────────────────────────────────────
my $w = $reg.run('write', $sys, 'a.txt', '中文 hello');
ok $w.ok, 'write 命令成功';
is $sys.read('a.txt'), '中文 hello', 'write 真的落盘（中文 UTF-8）';
my $rd = $reg.run('read', $sys, 'a.txt');
is $rd.value, '中文 hello', 'read 返回值在 Result.value';
is $rd.op, 'read', 'op 来自命令名';

my $e = $reg.run('exec', $sys, $*EXECUTABLE.Str, '-e', 'say "proc-ok"');
ok $e.ok, 'exec 命令成功';
is $e.out.trim, 'proc-ok', 'exec 的 out 未被外层 Result 吞掉';
my $nested = ($e.value ~~ Result);
nok $nested, 'exec 不套两层 Result';
ok $e.value<argv>.defined, 'value 保留 argv 供审计';

my $bad = $reg.run('read', $sys, 'missing-xyz.txt');
nok $bad.ok, '读不存在文件失败';
ok $bad.err.chars > 0, '异常被 try-op 收敛为 err';

# ── 内置命令统一附带 text 渲染 ───────────────────────────────────────
# 结构化 value/out 仍保留；text/rendered/gist 是同一份预渲染文本。
sub assert-text($r, Str $label) {
    ok $r.rendered.chars > 0, "{$label}: 有预渲染 text";
    ok $r.text.contains('ok:'), "{$label}: text 含状态";
    is $r.text, $r.rendered, "{$label}: text 与 rendered 一致";
    is $r.render('text'), $r.rendered, "{$label}: render(text) 命中缓存";
    is $r.gist, $r.rendered, "{$label}: gist 走 text";
}
assert-text($w,  'write');
assert-text($rd, 'read');
assert-text($e,  'exec');

my $ls = $reg.run('ls', $sys, '.');
my $st = $reg.run('stat', $sys, 'a.txt');
my $gl = $reg.run('glob', $sys, '*.txt');
my $ap = $reg.run('append', $sys, 'a.txt', '');
my $mk = $reg.run('mkdir', $sys, 'text-dir');
my $cp = $reg.run('cp', $sys, 'a.txt', 'text-dir/copy.txt');
my $mv = $reg.run('mv', $sys, 'text-dir/copy.txt', 'text-dir/moved.txt');
my $cd = $reg.run('cd', $sys, 'text-dir');
my $cw = $reg.run('cd', $sys, '..');
my $en = $reg.run('env', $sys);
my $rmd = $reg.run('rm', $sys, 'text-dir', :recursive);

for ($ls, 'ls'), ($st, 'stat'), ($gl, 'glob'), ($ap, 'append'),
    ($mk, 'mkdir'), ($cp, 'cp'), ($mv, 'mv'), ($cd, 'cd'), ($cw, 'cd ..'),
    ($en, 'env'), ($rmd, 'rm') -> ($res, $label) {
    assert-text($res, $label);
}
ok $rd.value eq '中文 hello', 'read 的 value 仍是结构化内容（不是 text）';
ok $e.out.trim eq 'proc-ok', 'exec 的 out 仍是纯 stdout（不是整份 text）';
ok $e.rendered.contains('proc-ok'), 'exec 的 text 包含 stdout';

my $unknown = $reg.run('nope', $sys);
nok $unknown.ok, '未知命令失败';
is $unknown.code, 127, '未知命令 code=127';
ok $unknown.err.contains('未知命令'), 'err 说明原因';

# ── 用户扩展：不改动任何分支表 ───────────────────────────────────────
my $custom = BuiltinCommand.new(
    :cmd-name<double>, :summary('两倍'),
    :handler(-> $s, $x { $x * 2 })
);
$reg.register($custom);
ok $reg.has('double'), '自定义命令注册成功';
is $reg.run('double', $sys, 21).value, 42, '自定义命令可运行';
is $reg.get('double').spec.to-json-schema<title>, 'double', '自定义命令也有 schema';
ok $reg.remove('double'), '可注销';
nok $reg.has('double'), '注销后不存在';
nok $reg.remove('double'), '重复注销返回 False';

my $ext = ExternalCommand.new(:exe($*EXECUTABLE.Str), :summary('raku'));
is $ext.name, $*EXECUTABLE.Str, 'ExternalCommand.name = exe';
ok $ext.run($sys, '-e', 'say 1').ok, 'ExternalCommand 只走 argv';

# ── DSL 短 sub ───────────────────────────────────────────────────────
is read('a.txt'), '中文 hello', 'DSL read';
is write('b.txt', 'B').bytes, 1, 'DSL write';
is append('b.txt', '!').bytes, 1, 'DSL append';
is read('b.txt'), 'B!', 'DSL append 生效';
is ls('.').map(*.basename).sort.join(','), 'a.txt,b.txt', 'DSL ls 返回 IO::Path 列表';
is glob('*.txt').elems, 2, 'DSL glob';
is stat('a.txt').type, 'file', 'DSL stat';
my $txt = read('a.txt');
ok ($txt ~~ Str), 'read 返回 Str 而非文本行';
ok pwd().chars > 0, 'DSL pwd';
ok cwd() ~~ IO::Path, 'DSL cwd 返回 IO::Path';
is set-env('DSL_K', 'v'), 'v', 'DSL set-env';
is get-env('DSL_K'), 'v', 'DSL get-env';
is env()<DSL_K>, 'v', 'DSL env 是会话 Hash';
ok unset-env('DSL_K').defined, 'DSL unset-env';
nok env()<DSL_K>:exists, 'unset 后键消失';
is help().elems, 13, 'DSL help 来自注册表';
ok commands().has('exec'), 'DSL commands 返回注册表';
ok session() === $sys, 'DSL session 绑定的是同一个 Sys';

my $t = timed({ 1 + 1 });
is $t.value, 2, 'timed 返回值可组合';
ok $t.elapsed.defined, 'timed 带耗时';
is $t.op, 'timed', 'timed op';

is peach(1..6, { $_ * 2 }).List, (2, 4, 6, 8, 10, 12), 'peach 并行 map 保序';
is peach(1..3, { $_ + 1 }, :degree(2)).List, (2, 3, 4), 'peach :degree';

# ── recent：用户自己写的「常用命令」示范 ────────────────────────────
# Linux 上做真时间过滤，Windows 上 modified 不可靠时如实降级为全量；
# 两种情况下刚创建的文件都应命中（不编造 1970 假时间）。
write('c.md', 'md');
is recent(7, 'txt').elems, 2, 'recent 按扩展名过滤';
is recent(7, 'md').elems, 1, 'recent md';
is recent(7, 'zzz').elems, 0, 'recent 无匹配';
ok recent(7, 'txt')[0] ~~ IO::Path, 'recent 返回 IO::Path，可继续 .map / .grep';

# ── 破坏性操作仍返回 Result ──────────────────────────────────────────
my $rm = rm('b.txt');
ok $rm.ok, 'DSL rm 返回 Result';
nok $base.add('b.txt').e, 'rm 真的删掉了文件';

for <a.txt c.md> -> $n { $base.add($n).unlink if $base.add($n).e }
$base.rmdir;

done-testing;
