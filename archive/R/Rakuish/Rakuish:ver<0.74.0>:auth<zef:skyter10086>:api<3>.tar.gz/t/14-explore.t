use Test;
use Rakuish::Sys;
use Rakuish::REPL::Session;
use Rakuish::Data::Table;
use Rakuish::Data::Pager;

# t/14 —— explore / 结构化分页器

my $base = $*TMPDIR.IO.add("rakuish-explore-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }
%*ENV<RAKUISH_PAGER> = 'never';
LEAVE { %*ENV<RAKUISH_PAGER>:delete }
$base.add('data.csv').spurt("name,size\na,1\nb,2\n");

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my $s = Rakuish::REPL::Session.new(:sys($sys));

my $e = $s.eval-line('explore data.csv');
ok $e.ok, 'explore CSV 成功';
like $e.out, /'name'/, 'explore 输出表头';
like $e.out, /'a'/, 'explore 输出数据';

$s.eval-line('ls --json .');
my $last = $s.eval-line('explore');
ok $last.ok, 'explore 无参数探索上一格';
like $last.out, /'data.csv'/, 'explore 上一格 Table 内容';

nok $s.eval-line('explore no-such-file.csv').ok, 'explore 缺失文件报错';

my $p = Rakuish::Data::Pager.new(:page-size(2));
my $text = $p.page(Rakuish::Data::Table.from-rows([
    { x => 1 }, { x => 2 }, { x => 3 },
]), :interactive(False));
like $text, /'x'/, 'Pager 非 TTY 返回完整文本';

done-testing;
