# Rakuish 交接文档

- **版本**：`0.74.0`（API v3）
- **日期**：2026-11-11
- **面向**：接手开发者 / 下一个 AI
- **先读**：[`docs/MANUAL.md`](docs/MANUAL.md) → 本文 → [`SPEC.md`](SPEC.md) → [`docs/ADR-0001-raku-native.md`](docs/ADR-0001-raku-native.md) → [`docs/ADR-0002-agent-serve.md`](docs/ADR-0002-agent-serve.md) → [`docs/ADR-0003-repl-experience.md`](docs/ADR-0003-repl-experience.md) → [`docs/ADR-0004-cursor-worker.md`](docs/ADR-0004-cursor-worker.md) → [`docs/ADR-0005-data-workbench.md`](docs/ADR-0005-data-workbench.md) → [`docs/ADR-0006-data-profile.md`](docs/ADR-0006-data-profile.md) → [`docs/ADR-0007-tty-passthrough.md`](docs/ADR-0007-tty-passthrough.md)

---

## 1. 一句话

Rakuish 是一个 **Raku 原生的命令、脚本与数据环境**：

- REPL 里可以写 Raku，也可以用 shell 习惯的 `cd/ls/read/rm/...`；
- 系统操作收敛到会话级 `Sys`，外部命令只接 argv；
- 数据能力用 `Table` + DuckDB/SQLite，不把一切变成文本；
- Agent 只接结构化 op，不接 shell 字符串。

**它不是 bash，不是 POSIX，不是“Raku 写的 shell 模拟器”。**
凡是看起来像“再补一个 bash 语义”的需求，先回到 ADR-0001。

---

## 2. 当前基线（0.74.0）

```bash
git clone <repo>
cd rakuish
raku -Ilib t/01-sys-fs.t     # 单文件
bash tools/run-all.sh        # 全套
zef install . --force-install
rakuish --version            # 0.74.0
```

| 项 | 当前值 |
|---|---|
| Windows 测试 | 35 个文件 / 1672 条断言 |
| Linux 测试 | `run-all.sh` 35 文件、问题总数 0 |
| `META6.api` | 3 |
| 模块 provides | 27 |
| 入口 | `bin/rakuish`、`bin/rakuish-agent` |
| 可选依赖 | `DB::DuckDB`、`DB::SQLite` |
| 核心依赖 | `JSON::Fast`、`Terminal::LineEditor` |

**安装时如果 precomp 或 `rakuish.exe` 被锁**：先结束残留 `rakuish` / `rakudo`
进程；Windows 上测试/交互进程可能持有 precomp 内存映射。不是代码 bug。

---

## 3. 架构地图

```text
bin/rakuish
  ├─ REPL 模式 ──> Rakuish::REPL::Session
  │                  ├─ 输入分类（! / Shell 薄层 / Raku）
  │                  ├─ 当前格 EVAL + 顶层状态扫描
  │                  ├─ Shell 薄层（REPL/Shell）
  │                  └─ 渲染 / 历史 / 配置 / hooks
  ├─ -e / 脚本 ──> 同一个 Session（整份源码一个 cell）
  └─ --agent ───> bin/rakuish-agent

lib/Rakuish/
  Sys                  会话 cwd/env/root + resolve + try-op + jobs
  Sys::FS              文件 API（IO::Path）
  Sys::Proc            argv-only 进程 API（Proc::Async 真流式）
  Result               Result/Stat/WriteResult/异常族 + render 门面
  Result::Renderer     text/json/markdown
  Data                  open/save + JSON/CSV
  Data::Table           结构化值 + where/select/join/schema/types
  Data::Engine          引擎角色（query/execute/tx/tables/schema）
  Data::Engine::DuckDB  可选 DuckDB 适配器
  Data::Engine::SQLite  可选 SQLite 适配器
  Data::Pager           explore 分页
  DSL                   普通 sub + bind-session + cmd 桥
  Command               Command/CommandSpec/Registry
  REPL::Chrome          banner/prompt/颜色/耗时格式（纯展示，0.62）
  REPL::Session         会话、扫描器、渲染、配置、_ / Out
  REPL::Shell           日常命令薄层
  Sandbox               op 白名单/token/限制/审计
  Agent                 结构化 op 处理
  Agent::Server         JSONL/TCP 传输
  Incomplete            多行续行
```

### 3.1 三条边界

1. **所有文件/进程操作必须过 `Sys`**。REPL 对象、快捷键、Shell 薄层都不能
   绕过 `Sys` 直接 `spurt` / `Proc::Async`，否则 Agent 的 Sandbox 失效。
2. **外部命令只接 argv**，永不拼 shell 字符串。
3. **Agent 只接结构化 op**，没有 `eval`，`exec`/`sql_query`/`pty_exec` 默认关闭。

### 3.2 求值模型（重要）

REPL 不重放历史。每格：

1. 扫描当前源码的顶层 `my/our/state`，转成 `%STATE` 别名；
2. 顶层 `class` / `role` / `grammar` 统一改写成 `my class` / `my role` /
   `my grammar`，避免 `EVAL` 把包装进 `GLOBAL` 导致重放时 Redeclaration；
3. 缓存纯 `sub` / `use` / `class` / `role` / `grammar` 声明格；类型声明
   **原位替换**缓存以保持继承/组合的依赖顺序，失败时回滚；含 phaser 或
   混有其它语句的格不缓存；
4. 只 EVAL **当前格 + 纯声明 prelude**，绝不重放执行语句；
5. 成功值进入 `@!out`，供 `_` / `Out[n]`。

不要通过“重放整份历史”来修任何状态问题，会重新引入 P0-1 的副作用问题。
持久的是**名字可见性，不是类型对象身份**（SPEC V-153）。

---

## 4. 从 v1 到 v3：为什么换架构

### 4.1 v1：Raku eval 环境

最早仓库是 `raku-eval`，后来改名 Rakuish。v1 的结构大致是：

- `RakuEval::Incomplete`：多行输入判定；
- `Rakuish::Platform`：平台差异隔离；
- `Rakuish::Eval`：求值 + `Out[n]` 渲染；
- `Rakuish::Loop`：交互循环、历史、补全、`%magic`；
- `Rakuish::Slow`：慢档/真 `sh` 后端；
- 后续加入 shell 引擎、后台 daemon、JSON server、`.repl` 重放、配置/alias。

v1 的产品形态是 **IPython 式 Raku 环境 + shell 逃生口**：
`!` 走 shell，反引号捕获，`%run/%load/%time/%config` 等 magic，
auto-shell 会把“看起来像命令”的输入交给 shell。

**贡献**：`Out[n]`、行编辑/补全、历史、配置、`%time`、脚本运行这些交互体验
方向是正确的；问题在于它逐渐长成“两套语言 + 两套执行栈”。

### 4.2 v2：API v2 的 bash 子集

v2 是 v1 的“新栈”：

```text
Parser → AST → Executor → Builtin
```

- 用 Raku 实现 bash 子集：`$VAR`、`|`、`>`、`&&`、`test`、`export`、
  heredoc、glob、`[[ ]]` 等；
- 独立 shell 引擎进程 `bin/rakuish-sh`，真 `bash` / `native` 双后端；
- `%magic` 第二套命令语言；
- 后台 daemon、JSON batch / TCP server；
- 自建 `Platform::Path` / `Stat`；
- v2 与 v1 legacy 栈可切换，长期并存。

**为什么失败**：不是差几个 bug，而是底座选择错误。v2 审计列出的 7 个 P0
（`rm -r`、`test -L`、`ls -la`、管道挂死、TCP 无认证、双栈漂移等）是
“自建 bash 语义”的必然产物：

- 自建 Path 丢 `IO::Path` 能力；
- 自建 Lexer 要自己解析 flag；
- 用临时文件模拟管道，挂死/撑盘；
- shell 字符串协议 + 手写 socket，认证/编码都难；
- 两套语言、两套执行栈长期漂移。

**贡献**：v2 的 `Result` 化、错误展示、配置/alias、补全、JSON 传输思路被保留；
但它不应被“修好”，而应被删除。

### 4.3 v3：Raku 原生（当前）

0.29–0.34 逐步落地，0.34.0 删除 v2：

- `Rakuish::Sys` 会话级系统出口；
- `IO::Path` 替代自建 Path；
- argv-only 进程 API；
- `Result` 类型 + 多格式渲染；
- DSL / Command 注册表；
- 无 magic 的 REPL；
- Agent 结构化 op + Sandbox；
- 0.39 以后加数据层、DuckDB/SQLite、`explore`、配置/hooks。

**关键提交**（Git 历史可查）：

- `6c04f15` 建仓，`c547827` Incomplete；
- `71860a9` v1 真 sh Slow 后端；
- `29de8c4` API v2 新栈接管；
- `278b4ee` 删除 v2，0.34.0；
- `3ee1980` / `360eb38` / `3275149` / `dfd1cb6` v3 Phase 1–4；
- 0.39–0.61 见 `git log --oneline`。

---

## 5. 现在这套架构是最优的吗？

### 5.1 对“Agent 系统操作 + 数据环境”这个目标：是正确底座

**优点**：

- 单一语义：输入落到哪一层明确，没有 auto-shell / magic 歧义；
- `Sys` 是唯一出口，Sandbox 可以集中审计；
- `IO::Path` / `Proc::Async` 直接使用 Raku/OS 能力，不自建半套；
- 结构化 Result / Table 对 Agent 和 REPL 都友好；
- 数据层与系统层分离，DuckDB/SQLite 可选，不拖核心安装。

### 5.2 但它不是“绝对最优”

以下是下一任接手者应该知道的真实弱点：

1. **REPL 状态扫描器是权宜方案**
   - 顶层 `my/our/state` 与纯声明格（含 `class/role/grammar`）可跨格；混合格、
     嵌套块内声明、含 phaser 的声明仍不持久。
   - 类型声明每格前置重放，生成**新** type object：对象身份不跨格，`.^name`
     带外层包名。持久编译器/常驻 cell 服务是更彻底的方案，但工程量大。
2. **Shell 薄层是影子 API**
   - `ls/read/...` 在 `Sys` 之上又有一套参数解析；要持续防止两套语义漂移。
   - 新命令应先问：这是 `Sys` API，还是 Shell 观感？不要两边都加。
3. **Agent 取消的两条路径**（0.63 默认 / 0.67 可选 worker）
   - 默认（0.63）：dispatch 在独立任务里执行，deadline 到点立即 504，连接继续
     可用；`exec`/SQL 因底层超时会真的终止（ADR-0002 / SPEC V-148）。
   - Raku 线程无法强杀：默认模式下纯文件 I/O 被判超时后仍在后台跑完
     （结果丢弃）。别把「响应及时」当成「已 kill」。
   - 0.67 起 `--worker`（默认 off）每连接一个常驻子进程，超时 `kill` 整个进程
     （ADR-0004 / V-159）。代价是该连接关闭、需重连，且不保证杀掉孙进程。
4. **Sandbox 是同用户文件策略，不是 OS 隔离**
   - canonical symlink 校验能挡路径逃逸，但挡不住同用户任意代码/内核级问题。
5. **Table / query() 仍以物化为主**（0.67 提供 Cursor 旁路）
   - `query(:max-rows)` 把 LIMIT 下推进 SQL、`batches` 惰性分批、
     渲染有 `:max-rows` 上限，大结果不再一次拼成巨型字符串 / JSON。
   - `query()` 与 `Table` 仍是全量行 Hash；0.67 起需要惰性执行时改用
     `Engine.cursor()`（DuckDB `:stream` / SQLite 逐行，V-158 / ADR-0004）。
     两者并存，不要把 `Table.batches` 当成惰性查询。
   - Parquet 是显式授权的外部访问例外（V-152），Agent 不开放，别把它当默认能力。
6. **常驻服务仍不是 daemon**
   - 0.63 起 `--mode tcp --serve` 支持多客户端，每连接独立 Sys / Engine / 审计；
     `serve-once` 保留为单连接兼容入口（语义未改，t/06 守护）。
   - 仍是本地可信服务：无开机自启、无跨进程 Engine 共享、无速率限制。

### 5.3 建议的方向

- **保留 v3 底座**，不要回退到 bash/parser；
- 0.67 已交付 **流式 Cursor / 连接级 worker 硬取消**（ADR-0004），
  0.68 已交付 **CSV 受控外部读写 / Engine 元数据补全**（ADR-0005），
  0.69 已交付 **CSV 方言 / describe 值 API / 补全增强**（ADR-0006），
  0.66 已交付 Vi/hints / 插件；**SQL AST 级补全与可恢复游标已明确不做**，
  剩余未排期方向只有 CSV 方言精细控制、SQL 元数据 `describe` 的扩展统计，
  不是再加 shell flag；
- REPL 若要彻底解决状态，做 **持久求值器**，而不是历史重放；
- 不要为了“像 shell”恢复 `%magic` 或 auto-shell。

---

## 6. v1/v2 中值得保留的东西

| 来自 | 东西 | 现状 |
|---|---|---|
| v1 | `Out[n]` / 历史 | 已完成，且补了 `_` |
| v1 | 行编辑 / Tab 补全 / 历史文件 | 已接 `Terminal::LineEditor` |
| v1 | 配置 / alias / 启动配置 | 已做 `config`/`alias`/`hook` |
| v1 | `%time` 计时 | 变成 `timed` / `bench` / `perf` + prompt 每格耗时（0.62），不恢复 magic |
| v1 | `%load` 载入文件 | 用 Raku `EVALFILE` / 脚本；未做专用命令 |
| v1/v2 | 错误展示 / 结果渲染 | 收敛到 `Result.render` |
| v2 | `Result` 化、JSON 传输 | 保留并重做 |
| v2 | Shell 日常观感 | 保留为薄层，但不接 bash 语义 |

**不要复活**：

- `Parser` / `Pipeline` / 临时文件管道；
- 自建 `Platform::Path` / `Stat`；
- 独立 shell 引擎 / daemon / shell 字符串协议；
- `%magic` / auto-shell / 反引号 shellq；
- v1/v2 双栈并存；
- 无界历史重放。

---

## 7. 必须守住的契约

1. **入口不猜**：`--agent` / `!` / Raku 表达式由用户显式选择。
2. **argv-only**：外部命令不经过 shell。
3. **会话级 cwd/env**：不 `chdir`、不改 `%*ENV`。
4. **一条出口**：所有文件/进程操作过 `Sys`。
5. **Agent 无 eval**：`exec`/`pty_exec`/`sql_query` 默认关闭；`pty_exec` 还需
   `--allow-pty`；请求参数只能调小上限。
6. **Result 双形态**：结构化 `value/out` + text 渲染缓存。
7. **不重放历史副作用**。
8. **Shell 薄层不绕过 Sandbox**。

违反其中任何一条，先停下来改设计，不要用测试“修绿”。

---

## 8. 文件与职责

| 文件 | 职责 | 改动注意 |
|---|---|---|
| `bin/rakuish` | 入口、REPL、`-e`、脚本、hooks | 版本常量与 META 同步 |
| `bin/rakuish-agent` | Agent 入口、参数 | 默认安全值 |
| `Sys.rakumod` | cwd/env/root/resolve/try-op/jobs | 任何路径操作过 resolve；中间 symlink 逐段 readlink 校验（V-157）；Windows REPL 用 `all-drives`，Agent 不用 |
| `Sys/FS.rakumod` | 文件 API | 读/写/stat 抛异常；rm/cp 返回 Result |
| `Sys/Proc.rakumod` | argv 进程 / `tty-exec` 直通 / `pty-exec` 捕获 | `Proc::Async.start(:cwd,:ENV)`；直通用 `bind-stdio`、无超时；PTY 用 `:pty`、可超时/截断 |
| `Result.rakumod` | 类型 + 异常 | 不破坏 render 契约 |
| `Result/Renderer` | text/json/markdown | 稳定键序、路径 `/` |
| `Data.rakumod` | JSON/CSV/Parquet open/save | 只经 Sys；Parquet/CSV 外部读写需显式 `:allow-external` |
| `Data/Table.rakumod` | Table 值/schema/types/describe/batches | 单行 Hash 归一化、类型保留 |
| `Data/Cursor.rakumod` | 惰性游标（batches/rows/take/close） | 显式 Iterator + fetch；不嵌套 gather |
| `Data/CsvOptions.rakumod` | CSV 方言白名单 | 纯函数；读用 ? 绑定、写只拼校验过的字面量 |
| `Data/Engine*` | 数据库适配 | 可选依赖、只读默认、超时、`cursor()`、`describe()`、CSV/Parquet 外部读写 |
| `Data/Pager.rakumod` | 分页 | 非 TTY 返回文本 |
| `DSL.rakumod` | 短 sub / cmd | 不引第二套语法 |
| `REPL/Chrome.rakumod` | banner/prompt/颜色/耗时格式 | 纯展示，不求值、不解析输入 |
| `REPL/Keymap.rakumod` | Vi/Helix 模态语义 + 行编辑器子类 | 只绑已有 edit action；构造失败自动回退 |
| `REPL/Hints.rakumod` | 上下文提示 | 纯函数；管道下不输出 |
| `REPL/Plugins.rakumod` | 显式本地 Raku 插件 | 默认关闭；加载即执行本地代码，不是沙箱 |
| `REPL/SqlComplete.rakumod` | SQL 上下文补全 | 纯函数；别名/前缀列/大小写；异常退化成空补全 |
| `REPL/Session.rakumod` | 输入分类/EVAL/渲染 | 不重放历史；顶层类型词法化；`need Rakuish::Data` 避免同名导出覆盖（V-165） |
| `REPL/Shell.rakumod` | shell 观感 | 只翻译成 Sys；文件名参数只展开 `* ?` |
| `Sandbox.rakumod` | 安全策略 | 默认拒绝 |
| `Agent.rakumod` | op 分派 | 无 eval；`pty_exec` 需双开关；审计 |
| `Agent/Server.rakumod` | 传输（JSONL / serve-once / serve 常驻 / worker 开关） | 只绑 127.0.0.1；idle timeout；每连接独立 Agent |
| `Agent/Worker.rakumod` | 连接级 worker 子进程 | 配置经 stdin、握手、watchdog kill、父进程审计 |
| `Incomplete.rakumod` | 续行 | 纯逻辑 |

测试：

- `t/01` FS、`t/02` Sys、`t/03` Proc、`t/04` DSL/Command；
- `t/05` REPL、`t/06` Agent/Sandbox、`t/07` 入口；
- `t/08` 渲染、`t/09` 展示、`t/10` Shell、`t/11` Table；
- `t/12` DuckDB、`t/13` SQLite、`t/14` explore、`t/15` 界面与计时、
  `t/16` 常驻多客户端 / 请求取消、`t/17` Parquet / 大结果、
  `t/18` 类型声明跨格 / glob 转义与嵌套 brace、
  `t/19` Vi/Helix 模式 / hints / 插件、
  `t/20` 流式 Cursor、`t/21` 连接级 worker / 硬取消、
  `t/22` CSV 受控外部读写、`t/23` SQL 上下文补全、
  `t/24` CSV 方言 / V-165 名字解析、`t/25` describe 值 API / 补全增强、
  `t/26` 交互式子进程 TTY 直通（非 TTY 守卫 / 元选项 / 真 PTY 集成）、
  `t/27` Ctrl-C 中断输入（值 API + 真 PTY）、
  `t/28` PTY 捕获 / 超时 / Agent 双开关、
  `t/29` PTY 能力探测失败路径 / 先剥离后截断 / 结果标记、
  `t/30` `tty-exec` 期间 SIGINT 归属契约（真 controlling terminal + `\x03`，
  Windows skip）、
  `t/32` 进程组交接（`posix_spawnp` SETPGROUP，Windows skip）、
  `t/33` 结果着色与输入行高亮的纯文本等价 / 非 TTY 零 ANSI、
  `t/31` `tty-exec` 交接期 termios 快照恢复（canonical 基线 PTY，
  Windows 只跑 2 条退化断言）；
  `t/18` 另含 0.69.1 失败格 stderr 回归；
- `t/51` provides/版本、`t/52` 全模块加载。

---

## 9. 开发流程

```bash
# 1. 改代码
# 2. 单测
raku -Ilib t/xx.t
# 3. 全量
bash tools/run-all.sh
# 4. 安装验证
zef install . --force-install
# 5. 版本
# META6.json + bin/rakuish + bin/rakuish-agent
# 6. 文档三联
# README / MANUAL / SPEC / ROADMAP / HANDOFF
# 7. 提交
```

规则：

- 新模块必须加入 `META6.provides`（`t/51`）。
- 新能力必须有正向 + 反向断言。
- `lib/` 改动后跑全模块 `require`（`t/52`）。
- 版本常量与 `META6` 同步；`t/51` 守护。
- Windows/Linux 都跑 `tools/run-all.sh`；Linux/WSL 另跑
  `python3 tools/tty-check.py` 做真 TTY 交互自检；Windows 的**控制台模式**
  （termios 对应物）不在 `prove6` 覆盖范围内，跑
  `python3 tools/tty-termios-win.py`（真 ConPTY，退出码 0/1/2）。

---

## 10. 已知缺口与风险

| 项 | 现状 | 风险 |
|---|---|---|
| Agent OS 级硬取消 | 0.67 `--worker` 每连接独立进程，超时真 kill（默认 off） | 硬取消后该连接关闭；不保证杀掉孙进程；非 worker 模式仍是 0.63 语义 |
| 多客户端 daemon | `--serve` 常驻 + 连接数上限（0.63） | 无开机自启 / 速率限制 / 跨进程 Engine |
| worker 模式 | 默认关闭；配置经 stdin、审计集中父进程（0.67） | 每连接付一次 Rakudo 启动；不是 daemon |
| CSV 外部读写 | 与 Parquet 共用 `:allow-external`（0.68）+ 7 项方言白名单（0.69，V-162） | 不做编码 / 多行字段精细控制 / 分区写出；方言只在 Raku 层 |
| describe 值 API | Table.describe + Engine.describe 默认实现（0.69，V-163） | 大表 count(distinct) 不承诺性能；不做直方图 |
| SQL 上下文补全 | 纯函数 + 别名/前缀列/大小写（0.68 / 0.69） | 只识别 '...'/"..."；**不做 SQL AST 解析**（V-908） |
| REPL 同名导出 | Session 改 `need Rakuish::Data`（0.69，V-165） | 新增导出同名 sub 时仍需留意 EVAL 词法作用域 |
| Table 大结果 | 0.67 `Engine.cursor()` 真惰性；`query()` 仍物化 | 游标一次性、无事务一致性快照 |
| `class/role/grammar` 跨格 | 纯声明格可持久（0.65） | 混合格 / 类型对象身份仍受限 |
| glob 转义/嵌套 brace | 已实现（0.65，`Sys.glob` / Raku `glob()`） | Shell 薄层文件名参数只展开 `* ?` |
| Vi/Helix 模态 | 已实现（0.66，ADR-0003）；0.70 `tools/tty-check.py` 自动验收 | 真实终端光标手感仍需人工确认；子类依赖 LineEditor 0.0.23 内部 |
| 交互式子进程 | 0.70 `tty-exec` / `! --tty` 显式 TTY 直通（V-167 / ADR-0007） | 输出不进 `_`；无超时需自行结束；行编辑器挂起读理论上可能吞首字符（PTY 测试已验证未发生） |
| PTY 捕获 | 0.72 `pty-exec` / Agent `pty_exec`；0.72.2 版本+isatty 双检、先剥离后截断（V-170 / V-172） | 只捕获 stdout，stderr 合流（`value<stderr-merged>`）；**没有 stdin 写入**，跑交互式 REPL 会挂到超时；超时 kill 直接子进程、不承诺杀孙进程；需 Rakudo ≥ 2025.12，旧版返回 `code=127` 而非静默降级；Agent 默认双开关关闭 |
| Ctrl-C 中断 | 0.71 `InterruptCLIInput` + `take-interrupt`，Ctrl-C 只清输入 / 续行缓冲（V-168 / ADR-0008） | 只作用于输入阶段；求值中的 SIGINT 仍按 Rakudo 默认；子类构造失败回退原生 `CLIInput` 时是 0.70 行为 |
| `tty-exec` 期间 Ctrl-C | 0.72.3 真 PTY 契约（V-173 / ADR-0009）；0.73.0 起由进程组交接实现，Ctrl-C 由终端驱动直接投给前台子进程组 | SIGINT tap 只剩交接窗口；Windows 与降级路径仍是同组 + tap；子进程忽略 SIGINT 时按无超时边界一直等 |
| job control / 进程组切换 | **0.73.0 已实施**（V-175 / ADR-0010 §6）：`posix_spawnp` + `SETPGROUP` + `tcsetpgrp` + 自建 `waitpid`，真 PTY 11 断言（`t/32`） | 只做前台交接：**不做 `&` / `jobs` / `fg` / `bg` / Ctrl-Z 作业管理**，Ctrl-Z 会把子进程停住而 REPL 等在那儿；不做 SIGWINCH 转发与孙进程树回收（V-905）；Windows 无对应语义（`CTRL_C_EVENT` 不能投递给进程组）；`cwd` 依赖 `posix_spawn_file_actions_addchdir_np`，缺失时降级并标 `job-control=False` |
| 结果着色 | 0.74.0：`Session` 按入口的颜色能力着色路径列表 / `ls -l` / `Out[n]` / 错误行 / `help()` / `env()` / `stat` / 写入结果（V-176 / ADR-0011） | 列宽按纯文本算，颜色只插零宽转义；`Result.render-result(text)` 与 Table 仍不掺 ANSI；Agent 输出不着色 |
| 输入行高亮 | 0.74.0：覆盖 `visible-input-field-string`（`HlField`），emacs / vi / helix 共用（V-177 / ADR-0011 §4） | 只做单行词法，不碰 `q[...]` / heredoc / 多行字符串；**依赖 LineEditor 内部**（scroll-cursor / available-width）；回退到原生 `CLIInput` 时无高亮 |
| `tty-exec` 的 termios | 0.72.4 交接前快照、正常路径与 `LEAVE` 幂等恢复（V-174 / ADR-0009 §0） | 整份配置恢复、不猜测子进程改了哪些位；Windows 的 `GetConsoleMode` 分支 0.72.5 已在真 ConPTY 与 conhost 下实测（`tools/tty-termios-win.py`），vim / less 自身的恢复时序仍需人工 |
| SQL 补全形态 | 0.71 `q[...]` 与 `sql =>` / `:sql(`（V-169 / ADR-0008） | 不识别 `qq` / `Q` / heredoc / 嵌套 `q[]`；仍无 SQL AST；别名是词法启发式 |
| 本地 Raku 插件 | 已实现（0.66，默认 off） | 加载即执行本地代码，不是沙箱；只加载可信文件 |
| OS 隔离 | 同用户文件策略 | 不是容器级安全 |
| Windows 时间戳 | 可能 1969 | 已如实降级 |
| SQLite 连接并发 | 单连接 | 单写者 |
| `cmd` 递归 | 仅 REPL | 不用于脚本 |

---

## 11. 下一任 AI 的工作方式

1. **先读** `docs/MANUAL.md`、`SPEC.md`、本文件；不要凭文件名猜行为。
2. **先跑** `bash tools/run-all.sh`，确认基线；不要把已有失败当自己引入。
3. **不要重写架构**：v3 是刻意选的；要改先写 ADR/设计。
4. **不要加 bash**：新需求先问能否用 Raku/结构化值表达。
5. **不要重放历史**：修 REPL 状态用声明持久/持久求值器。
6. **不要绕过 Sys**：文件/进程一律经 `Sys`。
7. **默认拒绝**：Agent/Sandbox 新 op 默认关闭，显式开关 + 上限 + 审计。
8. **小步提交**：每个能力带测试、文档、版本；不要一次性大重构。
9. **保持诚实**：Windows/超时/安全边界的不确定性写进文档，不假装解决。

### 接手检查清单

- [ ] `prove6 -Ilib t` 全绿
- [ ] `tools/run-all.sh` 退出 0
- [ ] `python3 tools/tty-check.py` 全 PASS（Linux/WSL）
- [ ] `zef install . --force-install` 通过
- [ ] 版本/`provides` 同步
- [ ] README/MANUAL/SPEC/ROADMAP 同步
- [ ] 没有新增 shell 字符串解析
- [ ] 新 op 默认关闭、审计、限额
- [ ] 没有重放历史副作用

---

## 12. 术语

- **Session**：`Rakuish::REPL::Session`，一格 REPL。
- **Sys**：会话级系统出口。
- **Result**：结构化结果；`ok/code/value/out/err/op/elapsed`。
- **Table**：行 Hash + 列 + 类型。
- **Engine**：数据库适配器。
- **Shell 薄层**：日常命令翻译层，不是第二套 shell。
- **Sandbox**：Agent 的 op 策略/限额/审计。
- **v1/v2/v3**：历史架构代际；只有 v3 在仓库中。
