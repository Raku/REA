# Rakuish 规格（Raku 原生命令与脚本环境，API v3）

> **本文件是唯一真值**（0.34.0 / Phase 5b 起，当前 0.74.0）。
> v2 的双语言 REPL（`!` bash 子集 + `%magic` + 独立 shell 引擎）已于 0.34.0 整体删除，
> 仓库里**只有这一套语义**：没有兼容入口、没有 `--v2` 开关、没有 daemon。
> 测试用例的标注必须能在这里找到对应条款（编号 `V-xxx`）。
> 使用说明见 [`docs/MANUAL.md`](docs/MANUAL.md)。
>
> 方向依据：[ADR-0001](docs/ADR-0001-raku-native.md) · 原始设计：[DESIGN-RAKU-NATIVE.md](docs/DESIGN-RAKU-NATIVE.md)。
> `META6.api` 为 `3`，与实际宣称一致。

---

## 1. 适用范围与术语

| 术语 | 含义 |
|---|---|
| **会话（Session）** | 一个 `Rakuish::REPL::Session` 或 `Rakuish::Sys` 实例；`cwd` / `env` / `root` 是它的对象属性，**不是进程全局** |
| **Sys** | 唯一系统出口：文件、进程、路径解析、环境 |
| **Result** | `ok / code / value / out / err / elapsed / op`，`.Bool` 供 `&&` 短路 |
| **argv** | 外部命令的参数数组；**永不经过 shell** |
| **op** | Agent 请求里的结构化操作名，每个 op 对应一个 `Sys` 方法 |

**V-101**：V3 不实现、不扩展 bash / POSIX 语法。`$VAR` / `|` / `>` / `2>` /
`&&` / `||` / glob / heredoc / 命令替换 / `$?` / `$$` 都不是 V3 语法。
需要这些能力时用 Raku 本身（方法链、`Supply`、`&&`、`.subst`、正则）。

**V-102**：脚本就是 Raku 脚本。`.raku` / `.rakuish` 交给默认入口时，
整份源码作为**一个 cell** 求值，预加载 DSL 与 `sys` / `repl` / `registry` 词法绑定；
不解析 shebang、不模拟 `%magic`、不打印 `Out[n]`。
相对路径跟随**调用者 cwd**（与 shell 惯例一致），不是脚本所在目录。

---

## 2. 入口契约（V-11x）

| 条款 | 规则 |
|---|---|
| V-111 | `bin/rakuish`（唯一入口）：无参数 → REPL；`-e <code>` → 求值后退出；`<file> [args...]` → 跑 Raku 脚本；`--help` / `--version` |
| V-112 | `bin/rakuish --agent [args...]`：转发到 `bin/rakuish-agent`，stdio 全继承、退出码原样带回 |
| V-113 | `bin/rakuish-agent`：Agent 入口（JSONL / TCP），见 §6 |
| V-114 | 入口只有这两个；v2 的 `rakuish-v2` / `rakuish-v3` / `rakuish-sh` 已随 0.34.0 删除（`t/07` 断言其不存在） |
| V-115 | 入口**不猜参数形态**：参数该落在哪一层由用户显式写出；猜测等于把 `auto-shell` 换成「猜入口」 |
| V-116 | 管道（非 TTY）下不打印提示符，stdout 只有求值结果；TTY 下才显示 banner 与 `rakuish> ` |
| V-117 | 两个入口的版本常量必须与 `META6.version` 一致（`t/51` 与 `t/07` 守护） |
| V-118 | 转发用 argv 数组调用，参数里的空格、引号、`|`、`$`、`&&` 一律不解释 |

---

## 3. 输入分类（V-12x）

**V-121**：REPL 每行只有两类输入，没有第三套语言：

| 首字符 | 处理 |
|---|---|
| `!` | argv 分词（空格 + 引号），交给 `sys.exec`；`!=` / `!~~` 仍按 Raku 运算符求值 |
| 其它（**含 `%`**） | Raku 表达式，直接 EVAL；编译 / 运行失败就是失败，**不回退 shell** |

日常命令 `cd` / `ls` / `cat` / `read` / `rm` 等由 Shell 薄层翻译成 `Sys`
调用（V-127），这是**命令别名层**，不是第三套语法；带 Raku 表达式或复杂引号的
输入仍交回 Raku。

**V-122**：`%foo<a>` / `%STORE{...}` 是 Raku 哈希访问，不是魔法命令。
V3 没有 `kind-of` 的 `%` 分支、没有 magic handler、没有 magic help 表。

**V-123**：`!` 的分词只处理空格与引号；`$()`、反引号、`;`、`|`、`>`、`*`、`&&`、
heredoc 全部原样作为 argv 元素传入。要管道 / 过滤 / 重定向就写 Raku：

```raku
my $r = sys.exec('git', 'status', '--short');
say $r.out.lines.grep(*.contains('.md'));
```

**V-124**：多行续行用纯 Raku 的括号平衡判定；跨格顶层 `my` / `our` / `state`
由只读扫描器转成 `%STATE` 别名，**每格只 EVAL 当前源码，不重放历史副作用**。
嵌套块里的 `my` 仍是块内局部；纯 `sub` / `use` / `class` / `role` / `grammar`
声明格会缓存并在后续格前置（机制与边界见 V-153）。stdout 直接回显当前格输出，
不打印历史重复内容。

> 历史实现（0.35.2 及以前）靠累积整份源码重 EVAL 保留 `my`，会把上一格的
> `append` / `write` / `exec` 重跑一遍；V-124 已禁止这种做法。

**V-125**：REPL 元能力不是文本命令：`repl.history` / `repl.config<k>` / `repl.trace`
是对象 API，纯交互动作走快捷键（Up / Down / Ctrl-R / Ctrl-C / Ctrl-D /
Ctrl-X Ctrl-E / Tab）。**repl 对象与快捷键禁止直接读写文件、启动进程**——
所有系统操作必须过 `Sys`，否则 Agent 的 Sandbox 会被绕过。

**V-128**：TTY 交互入口使用 `Terminal::LineEditor` 提供行编辑与历史：
Up/Down 翻历史、Ctrl-R 搜索、Ctrl-D 退出；历史默认保存在
`~/.rakuish-history`。Tab 补全命令名、路径和 `help <命令>`。
管道 / 脚本输入仍走普通逐行读取，不输出提示符或终端控制序列。

**V-129**：结构化数据层：
- `Rakuish::Data::Table`：行是 Hash，列为字符串；支持 `where/get/select/sort-by/
  first/last/limit/offset/each/count/sum/mean/min/max/distinct/join`、
  `schema/column-type`、`to-text/to-json/to-markdown`。
- `Table` 类型集合 `int / num / str / bool / datetime / list / map / any`；
  构造时推断，链式操作保留，`join` 合并右表类型。
- `Rakuish::Data`：`open-data` / `save-data` / `from-json-data` / `to-json-data` /
  `from-csv-data` / `to-csv-data`。
- `Sys.ls-table` / `DSL.ls-table` 返回 `Table`，字段至少
  `name/type/size/modified/path`。
- REPL 支持 `open [--raw] 文件`、`ls --json`、`explore [路径]`；
  `glob` 支持 `**/` 递归前缀。
- 数据层只经 `Sys` 读写文件，不绕过 Sandbox
  （Parquet 的显式授权例外见 V-152）。

**V-130**：数据引擎是可选能力：
- `Rakuish::Data::Engine` 定义 `query/execute/tables/schema/close` 契约。
- `Rakuish::Data::Engine::DuckDB` 通过**运行时 require** 使用 `DB::DuckDB`，
  不成为核心依赖；缺失时明确报安装提示。
- 默认只读；只读下 `execute` 和 DDL query 抛 `X::Rakuish::Unsupported`。
- 默认 `enable_external_access=false`；SQL 不能借 DuckDB 的文件函数绕过
  `Sys` 的 root/Sandbox。
- Agent 的 `sql_query` 默认关闭；显式 `--allow-sql --db` 后只允许参数化只读查询，
  不开放 `sql_exec` / DDL / 任意 SQL。

**V-131**：SQLite 是可选的小型事务引擎：
- `Rakuish::Data::Engine::SQLite` 运行时 require `DB::SQLite`，不成为核心依赖。
- 适配器固定一个连接（`:memory:` 不能走连接池，否则每个连接一个库）。
- 参数化 `query/execute` 使用 prepared statement。
- 默认只读；只读下拒绝 `execute` 和 DDL query。
- SQLite 用于小表/应用状态，不作为大分析引擎。

**V-132**：`Table` 值管道至少包含：
`where/get/select/sort-by/first/last/limit/offset/each/count/sum/mean/min/max/
distinct/join`。`join` 默认是左连接，列名冲突时右表列加 `_right` 后缀；
`from-rows` 必须把单行 Hash / Pair 列表归一化成一行 Hash。

**V-133**：REPL 支持 `set -e` / `set +e`：
- `set -e` 打开 strict；任一 shell、`!` 或 Raku 求值失败后设置
  `exit-requested`，退出码取该结果的 `code`（无则 1）。
- `set +e` 关闭 strict；失败只返回错误 `Result`，不退出。
- strict 是会话级状态，不改变单个 `Result` 的 `ok/code/err`。

**V-134**：Agent 可选 `sql_query`：
- 默认关闭；需 `Sandbox.allow-sql` 和已配置只读 Engine。
- `sql` 必须参数化 `params[]`；结果转 `Table`，再按 `max-rows` 截断。
- 不开放 `sql_exec` / DDL；未知 op 仍 404，策略拒绝是 403。

**V-135**：资源与递归边界：
- `ls -R` 在 TTY 下按目录流式输出，每个目录先打 `目录:` 头再输出条目；
  非 TTY 返回完整分组文本。`--json` 仍返回扁平 Table。
- 普通 `glob`（如 `*.jpg`）只扫当前目录；按模式段数限制 `max-depth`，
  只有包含 `**` 时才无界递归。
- `ls` 递归结果超过 `Sys.max-entries`（默认 100000）抛 `X::Rakuish::Limit`；
  `cp -r` 在复制前预检源树条目数，超限直接拒绝。
- `write` 的原子临时文件使用 `spurt(:exclusive)`，不再可预测地覆盖已有临时文件。
- `!` 命令的未闭合引号直接返回 127，不把残片当 argv 执行。
- `peach` 是 DSL 的并行 map，`:degree` 控制并发度，结果保序。
- `glob` 支持 `*` / `?`（不跨 `/`）、`**/`、`foo/**/bar`、`foo/**`、
  `[abc]` / `[a-z]` / `[!x]`、`{a,b}` 与嵌套 `{a,{b,c}}`；`\` + 元字符
  （`* ? [ ] { } , \`）按字面匹配，裸 `\` 归一化为 `/`（V-153）。

**V-136**：`Sys` 记录本会话 `spawn` 的后台任务：
- `jobs` 返回 `Table`（id/status/exe/argv/started），REPL 有同名 shell 命令。
- `wait` / `cancel` 成功后清理；`job(id)` 可取回 Handle。
- 任务记录不跨 `Sys` 会话，不写全局进程表。

**V-137**：Agent 审计 `sql_query` 只记录 FNV-1a SQL 指纹和参数个数，
不记录 SQL 原文、参数值或结果行内容。

**V-138**：文件替换临时名：
- `write` / `mv` 的临时名使用时间 + 随机 + PID，降低可预测性。
- 原子写仍用 `spurt(:exclusive)`；写入前拒绝覆盖 `.bak` 符号链接。
- 失败路径保持原有回滚语义，不先删除目标。

**V-139**：超时：
- `serve-once` 使用 `IO::Socket::Async`，支持 `idle-timeout-ms`；超时后关闭连接并返回
  `timed_out => True`。
- DuckDB Engine 支持 `max-execution-time-ms`，映射到 DuckDB `max_execution_time`；
  超时查询抛数据库中断错误。
- SQLite 超时见 V-147；Agent `--sql-timeout-ms` 对两种引擎一致生效。

**V-140**：REPL 值历史：
- `_` 是上一成功格的值；`Out[1]` 起是成功格结果历史（首个元素为占位）。
- `cmd('shell 文本')` 执行 shell 薄层并返回结构化值；失败抛
  `X::Rakuish::CommandFailed`，`cmd-result` 则返回完整 Result。
- `cmd` 只在 REPL/绑定 Session 的上下文可用；不把 shell 文本变成第二套 Raku 语法。

**V-141**：`read` 作为 REPL shell 命令支持 `read 文件...`，按字面路径读取
（含 `-` 的文件名不再交给 Raku 当表达式解析）；与 `cat` 同源，输出文本。

**V-142**：0.53 命令查找：
- `which 命令` 优先报告 Shell 内置，其次按会话 `PATH` 查外部可执行文件。
- `help --find 文本` 在全部 usage 中做子串搜索，返回命令名 + 用法。
- 历史替换只识别整行 `!!` / `!$` / `!n` / `!-n`；`!cmd` 仍是外部命令。
  替换后立即求值，替换结果再入历史；用 `expanding` 标志防递归。

**V-143**：会话配置与 alias：
- 配置默认 `~/.rakuish-config.json`，`RAKUISH_CONFIG` 可覆盖；启动时加载。
- `config [get KEY|set KEY VALUE|unset KEY]` 读写顶层键。
- `alias name=command` / `alias name command` 写入配置；`unalias` 删除。
- alias 只展开 Shell 命令行的首个词，最多 10 层，防循环。

**V-144**：启动 hook：
- `hook add EVENT CODE`、`hook clear EVENT`、`hook run EVENT`；
  hook 存在配置 `hooks.EVENT` 数组。
- `bin/rakuish` 在 `-e` / 脚本 / 交互模式求值前运行 `start` hook。
- hook 失败时打印错误并停止启动；hook 内容是本地可信配置。

**V-145**：`Table` schema/types：
- 类型集合：`int / num / str / bool / datetime / list / map / any`。
- 构造时推断；`select/where/limit/...` 保留，`join` 合并右表类型。
- `column-type(NAME)` 与 `schema`（name/type/nullable）是稳定 API。

**V-146**：`Data::Engine` 写事务：
- `begin` / `commit` / `rollback` 是 Engine 角色方法；DuckDB、SQLite 都实现。
- 只读引擎调用事务抛 `X::Rakuish::Unsupported`。
- 事务属于引擎连接，不跨 Session/Agent 共享。

**V-147**：SQLite 查询超时：
- Engine `max-execution-time-ms` 通过看门狗调用 `sqlite3_interrupt` 中断。
- 超时抛 `X::Rakuish::Limit`；Agent `--sql-timeout-ms` 对两种引擎一致生效。
- 中断是连接级操作，不跨连接共享。

**V-148**：Agent 请求 deadline：
- `--request-timeout-ms` 默认 30000；超时响应 504，审计 stage=timeout。
- `exec` 和 SQL 会把实际执行超时压到不超过请求 deadline。
- 0.63 起 dispatch 在独立任务中执行，deadline 到点**立即**返回 504，
  超时任务的结果丢弃，连接继续可用（ADR-0002）；不再是「等操作返回后再检查」。
- Raku 线程无法强杀：不可取消的纯文件 I/O 仍会在后台跑完；exec / SQL 因底层
  超时被压进参数会真的终止。默认模式不宣称 OS 级进程硬取消，边界见 ADR-0002 §2；
  0.67 起 `--worker` 提供可选的进程级硬取消（V-159，默认关闭）。

**V-149**：`explore` 结构化分页：
- 无参数时探索上一格 Table；带路径时加载 JSON/CSV/目录为 Table。
- TTY 下按页输出（Enter 下一页、q 退出）；非 TTY 直接返回完整文本。
- `RAKUISH_PAGER=never` 强制非交互；不引入分页器第二套数据解释。

**V-150**：REPL 展示层与计时（0.62）：

- `Rakuish::REPL::Chrome` 是**纯展示模块**：banner / prompt / 颜色能力 /
  路径缩写 / 耗时格式化 / git 分支（只读 `.git/HEAD`，经 `Sys`）。
  它不求值、不注册命令、不解析输入，可在非 TTY 下被直接断言。
- TTY 下 banner 为极简字标 + 细分割线（**禁止字符拼字**）；prompt 显示时间、
  cwd、git 分支、格号、上格状态与耗时；续行提示符为 `···`。
  非 TTY 不打印 banner / prompt 与任何 ANSI（V-116）。
- 颜色：`NO_COLOR` 强制关、`FORCE_COLOR=1` 强制开，否则按 TTY + `config color`；
  `clock` / `timing` / `git` / `prompt-style` / `banner` 每格重读，`config set` 即时生效。
- 计时数据是会话级 `repl.perf-hist`，由入口对**每一格**（shell / `!` / Raku）
  统一调用 `note-timing` 写入，不重放历史、不引入第二套计时口径。
  `perf [N]` 展示；`timed` / `bench` 是普通 Raku sub，返回 `Result`。
- **不恢复 `%magic`**：不存在 `%time` 分流，`%` 始终是 Raku 哈希（V-122）。
  计时需求由「每格自动计时 + 状态行 + 值 API」满足。
- 测试：`t/15-repl-ui.t`（颜色、banner、prompt、格式、git 分支、timed/bench/perf）。

**V-152**：Parquet / 大结果 / SQL 错误统一（0.64）：

- `open-data` / `save-data` 支持 `.parquet` / `.pq`，返回 / 接受 `Table`；
  DSL 的 `:allow-external` 与 Shell 的 `open --external` 暴露该能力。
- **外部访问是显式例外**：读写 Parquet 必须给 `:allow-external`（人类 REPL），
  路径一律先经 `Sys.resolve` 做 root 校验；DuckDB 的 `read_parquet` / `COPY`
  由受控的 `:!safe` 引擎执行。**Agent 的 op 白名单不暴露该开关**，
  引擎默认 `enable_external_access=false` 不变。这是 V-129「只经 Sys」在
  显式授权下的例外；0.68 起 CSV 纳入同一模型（V-160），Parquet / CSV 是
  **全部**例外，不扩大到 Agent、不开放任意 SQL 文件函数。0.69 的 CSV 方言
  参数（V-162）只是给这两个例外加选项，不新增第三个例外。
- `Engine.query(:$max-rows)` 把 `LIMIT` 下推进 SQL，在物化前截断；
  DuckDB / SQLite 一致。`Table.batches(:size)` 返回惰性分批 `Seq`；
  `to-text` / `to-markdown` / `to-json(:$max-rows)` 是展示上限
  （`to-json` 只截行、不加文本，保持合法 JSON）。
- **Table 本身仍是物化值**：0.67 起真正的惰性查询由 `Engine.cursor()` 提供
  （V-158）；`query()` 的物化语义不变。
- SQL 驱动异常统一包装为 `X::Rakuish::Data`；只读 / 沙箱 / 超时等
  `X::Rakuish::V3` 子类原样抛，不泄漏驱动堆栈。
- 测试：`t/17-data-parquet.t`（Parquet 往返、默认拒绝、root 校验、
  LIMIT 下推、分批、渲染上限、错误统一、Agent 白名单）。

**V-153**：类型声明跨格与 glob 完整语法（0.65）：

- 纯声明格（`sub` / `use` / `class` / `role` / `grammar`）缓存进 `@decls`，
  每格前置重放**只重放声明**，不重放任何执行语句（V-124 红线不变）。
- 顶层类型声明统一改写为 `my class` / `my role` / `my grammar`：裸声明在
  `EVAL` 里会装进 `GLOBAL`，跨格前置重放时触发 `Redeclaration of symbol`。
  代价是 `.^name` 带外层包名（`Rakuish::REPL::Session::Foo`），短名仍可解析；
  持久的是**名字可见性，不是类型对象身份**（每格重放生成新 type object）。
- 类型声明在缓存中**原位替换**（不是移除后追加），保证 `role R` →
  `class C does R` 的依赖顺序在重定义后仍成立；声明求值失败时回滚缓存。
- 含 `BEGIN` / `INIT` / `CHECK` / `END` / `START` / `FIRST` 的声明格**不缓存**，
  避免 phaser 副作用每格重放；该格仍照常求值。混有其它语句的格不缓存。
- glob：`\` + 元字符按字面匹配；嵌套 brace 按最外层逗号切分；字符集支持
  转义的 `]` / `-`；未闭合 brace 按字面处理；裸 `\` 仍归一化为 `/`。
- Shell 薄层只展开 `* ?`：含 `{ } [ ]` 的参数交回 Raku（`glob` 命令除外），
  且 `!split` 会把 `\` 当转义前缀吃掉；完整语法请用 Raku `glob('...')`。
- 测试：`t/18-repl-types-glob.t`（50 断言：三类声明、重定义顺序、副作用不
  重放、失败回滚、转义 / 嵌套 brace / 字符集 / Shell 入口）。

**V-154**：Vi/Helix 编辑模式与键位预设（0.66，ADR-0003 §3.1）：

- `config set edit-mode emacs|vi|helix`（默认 `emacs`，完全不碰原生键位）；
  `config set vi-start insert|normal` 决定每行起始模式。配置当格生效：
  重建行编辑器并迁移历史。
- `REPL::Keymap::ViState` 是纯逻辑的单行模态模型（insert / normal / select、
  缓冲 / 光标 / 撤销 / yank），`repl.vi` 可访问；单行 REPL 里 `j` / `k` 映射
  历史上下格。
- TTY 下 `ViCLIInput` 子类覆盖 `decode-keyname` / `special-actions` /
  `input-class`：normal 模式把可打印字符映射成 `vi-<char>` 键名，只绑定依赖
  已有的 edit action 或少数自定义 `edit-vi-*`，**不复制 `read-input`**。构造 /
  绑定失败自动回退原生 `CLIInput` + `Alt-*` 预设。
- **边界**：0.70 `tools/tty-check.py` 已在 WSL 真 PTY 下自动验证 Vi 徽标、
  Tab 补全、SQL 补全、describe 与嵌套 REPL 直通；真实终端模拟器的光标手感
  仍需人工确认。normal 模式下 bracketed paste 会被当 vi 键吞掉（粘贴前按
  `i`）；不做多行 buffer / 可视块 / `.` 重复。子类化依赖
  `Terminal::LineEditor` 0.0.23 内部结构。

**V-155**：上下文提示（0.66，ADR-0003 §3.2）：

- `hint [输入行]` 查询；TTY 下 `config set hints on|off`（默认 `on`）在 prompt
  前打印一行暗灰提示；**管道 / 非 TTY 完全不输出**（V-116 不变）。
- 提示来自 `hint-for`（命令 usage 首行 / registry spec 参数 / `!` argv 说明 /
  启动参数误用）与 `result-hint`（失败格下一步建议）；同一首词只提示一次。
- 不做「输入中实时弹窗」：行编辑器没有输入变化 hook，硬塞补全列表会污染补全。

**V-156**：显式本地 Raku 插件（0.66，ADR-0003 §3.3）：

- `config set plugins on`（默认 **off**）后可用 `plugin load PATH`；
  `plugin list | info NAME | unload NAME | help`。
- 路径经 `Sys.resolve` root 校验、源码经 `Sys.read`；插件是 Raku 文件，最后一个
  表达式求值为 `Command` 对象或 `List[Command]`，注册进会话 `CommandRegistry`
  （`registry.names` / `help()` / `cmd('name', ...)` 可见），**不进 Shell 文本
  命令表**。重名冲突（内建 / 其它插件）返回 409；`unload` 只移除自己的命令。
- **加载即执行本地 Raku 代码**，等同 `use` 一个本地模块，不是沙箱：只加载可信
  文件。不自动扫描目录、不联网、不持久化、不开机加载。
- Agent 的 op 白名单不暴露 `plugin`，Sandbox 不加载插件；插件的
  `run($sys, ...)` 拿到会话 `Sys`，必须经它做文件 / 进程操作（V-129）。
- 测试：`t/19-repl-experience.t`（89 断言：模态语义、预设合法性、行编辑器
  子类与回退、hints、插件默认拒绝 / 冲突 / 越界 / 卸载、Agent 白名单、管道）。

**V-157**：符号链接逐段 root 校验（0.67，安全修复）：

- `Sys.resolve` 在 `!canonical` 之外，对路径链上每一级 `.l` 做 `readlink`
  并校验真实目标在 root 内；root 自身允许是链接。
- 原因：Windows 上 `IO::Path.resolve` **不跟随文件类型的符号链接**（指向目录时
  `.e=False` / `.l=True`，但 OS 的 open/slurp 会跟随），只靠 canonical 会让
  `escape-dir/secret.txt` 读到 root 外内容。
- dangling symlink / 无法 readlink 一律按 `X::Rakuish::Sandbox` 拒绝，不放行。
- 测试：`t/01-sys-fs.t`（中间 symlink 读 / 写越界均被拒）。

**V-158**：流式查询 Cursor（0.67，[ADR-0004](docs/ADR-0004-cursor-worker.md) §3）：

- `Engine.cursor($sql, *@params, :$batch-size, :$max-rows)` 返回一次性
  `Rakuish::Data::Cursor`；`next-batch` / `batches` / `rows` / `take` / `close`。
  只有被拉取时才向驱动要下一批行，`close` 幂等、拉完或达上限自动释放。
- DuckDB 用 `DB.query(:$stream)` + 惰性 `chunks`（驱动一次只持有一个 chunk）；
  SQLite 用 `Result.hash` 逐行 `sqlite3_step`。**不复用 `.hashes` 物化**。
- 不支持的引擎抛 `X::Rakuish::Unsupported`，**不静默退化成 `query()`**；
  只读判据、LIMIT 下推、`X::Rakuish::Data` 错误包装与 `query()` 一致；
  V3 异常族原样抛。`query()` 与 `Table.batches` 行为不变。
- 刻意不用 `gather/take` 嵌套：两层惰性 continuation 跨调用帧会触发
  `continuationreset` 错误，改用显式 `Iterator` + fetch 闭包。
- **边界**：一次性单连接，不提供可恢复游标 / 事务一致性快照 / 并发修改下的
  稳定视图；提前退出惰性 Seq 需显式 `close`（`DESTROY` 只作兜底）。
- Agent 的 `sql_query` **不暴露** Cursor（流式对象无法安全序列化进 JSONL），
  `query(:max-rows)` 的 LIMIT 下推保证物化前截断。
- 测试：`t/20-data-cursor.t`（56 断言：惰性计数、分批、上限、close、错误包装、
  DuckDB streaming / SQLite 逐行两后端、角色默认拒绝、Agent 白名单）。

**V-159**：连接级 worker 与 OS 硬取消（0.67，ADR-0004 §4）：

- `--worker` **默认关闭**，必须与 `--mode tcp --serve` 同用；不开时 `serve()`
  与 V-151 完全一致。每连接启动一个常驻 worker 子进程（不是按请求 fork）。
- 配置（含 token）走子进程 **stdin 第一行**，不进命令行参数；就绪握手行由
  父进程消费，启动成本隔离在连接建立阶段。stdout 只有响应 JSONL，诊断走 stderr。
- 子进程返回 504 或父进程 watchdog 到点 → `kill` 整个 worker 进程；卡在
  不可取消文件 I/O 里的线程随进程消失。审计集中在父进程并脱敏，子进程
  不写审计文件；每连接独立 session。
- **边界**：硬取消后该连接随即关闭（客户端需重连），与 V-151「连接继续可用」
  不同；不保证杀掉 worker 派生的孙进程（无 job object / 进程组）；
  不提供跨连接会话状态或 Engine 缓存共享。
- `--worker-hard-timeout-ms` 可显式设置监督者硬超时，默认
  `request-timeout-ms + 1000`（无 deadline 时 30s）。
- 测试：`t/21-agent-worker.t`（29 断言：真实子进程 + TCP、握手、非法配置、
  kill 后进程退出、504 后连接关闭、新连接不受影响、审计脱敏、默认拒绝）。

**V-160**：CSV 受控外部读写（0.68，[ADR-0005](docs/ADR-0005-data-workbench.md) §2）：

- `open-data` / `save-data` 的 `.csv` 在显式 `:allow-external` 时走 DuckDB
  `read_csv_auto(?)` / `COPY (...) TO ... (FORMAT CSV, HEADER)`；与 Parquet
  共用 V-152 的授权模型：路径经 `Sys.resolve`、受控 `:!safe` 引擎、
  Agent 的 op 白名单不暴露该开关。
- **默认行为不变**：不带开关的 `.csv` 仍走 `Sys.read` + `from-csv-data` /
  `Sys.write` + `to-csv-data`（V-129 路径）。
- `Engine.read-csv(:$max-rows)` 支持 LIMIT 下推；`write-csv` 拒绝含分号的
  导出 SQL；驱动异常统一 `X::Rakuish::Data`，V3 异常族原样抛。
- 导出流程与 Parquet 共用 `export-table`（建临时表 → 参数化 insert → COPY），
  空值规则一致，不写 SQL NULL。
- **不承诺**：CSV 方言全兼容（分隔符 / 编码 / 多行字段精细控制）、按 schema
  强制类型、分区写出。
- 测试：`t/22-data-csv.t`（33 断言：默认路径类型仍 str、外部路径推断
  int/num、写入往返、root 越界、Agent 白名单、角色默认拒绝、错误统一、
  Parquet 导出流程回归）。

**V-161**：Engine 元数据驱动的 SQL 上下文补全（0.68，ADR-0005 §3）：

- `Rakuish::REPL::SqlComplete` 是纯函数：仅当光标位于 `'...'` / `"..."`
  字符串内、且该字符串是 `query/cursor/execute/sql(...)` 参数时激活；
  否则返回空，`Shell.completions` 原路径一字不改。
- `DSL.open-db` 通过 `$*RAKUISH-SESSION` 把新建 Engine 注册为当前会话
  Engine（`repl.engine` 可读，最后一次 `open-db` 生效）。
- 候选来自只读 `tables()` / `schema()` 元数据加固定 SQL 关键字；按「最近
  关键字」启发式决定补表名还是列名；返回**完整替换行**（与 Shell 约定一致）。
- 所有 Engine 调用包在 `try` 里：驱动缺失 / 库被锁 / 元数据查询失败都优雅
  退化成空补全，不让 Tab 崩 REPL。非 TTY / 管道下不创建行编辑器，不触发。
- **边界（0.71 修订）**：`q[...]` 等不插值引号算子与 `sql =>` / `:sql(`
  具名形态已由 V-169 支持；仍不识别 `qq` / `Q` / heredoc / 嵌套 `q[...]`，
  不解析 SQL AST，不引 `\d` / 裸 SQL 命令等第二套语法；SQL 仍是字符串参数。
- 测试：`t/23-sql-complete.t`（30 断言：上下文识别、关键字/表名/列名、
  完整替换行与 tail、异常退化、Session 联动、Shell 回退、open-db 注册链路）。

**V-162**：CSV 方言参数（0.69，[ADR-0006](docs/ADR-0006-data-profile.md) §2）：

- `open-data` / `save-data` 增加 `:%csv-options`，`Data::CsvOptions` 是纯函数
  白名单：`delimiter` / `quote` / `escape` / `nullstr` / `header` / `skip` /
  `all-varchar`。未知键明确抛 `X::Rakuish::Unsupported`，不静默忽略。
- **读路径**：选项一律写成 `name => ?` 并用参数绑定，值不进 SQL 字符串；
  选项名只来自常量表。**写路径**：`COPY` 选项不支持绑定，字面量须先过
  「单字符可打印 ASCII / 长度 ≤64、不含单引号、反斜杠、换行、NUL」校验；
  `skip` / `all-varchar` 在写路径明确拒绝，不假装生效。
- 方言选项**只在 Raku 层**且必须 `.csv` + `:allow-external`；默认路径仍走
  `Sys.read` / `Sys.write` + Raku 解析器（V-129）。空选项生成的 SQL 与 0.68
  逐字一致。Shell 薄层 `open --external` 不做第二套参数语法。
- 路径仍经 `Sys.resolve` root 校验；Agent 的 `OPS` 白名单不变、不新增 op。
- **不承诺**：编码 / 多行字段精细控制、按 schema 强制类型、分区写出。
- 测试：`t/24-csv-dialect.t`（57 断言：白名单纯函数、注入拒绝、方言往返、
  默认行为不变、Agent 白名单、REPL 链路）。

**V-163**：`describe` 值 API（0.69，ADR-0006 §3）：

- `Table.describe(:$sample)` 与 `Engine.describe(Str $table, :$sample)` 都返回
  **Table**，列集合固定为 `name/type/nullable/non_null/distinct/total/sample`；
  不返回文本报告，可继续组合。
- `Engine.describe` 是**角色默认实现**，只依赖契约里的 `schema()` / `query()`
  聚合（`count(*)` / `count(col)` / `count(distinct col)`），因此 DuckDB /
  SQLite 与第三方引擎自动获得。表名限定 `[A-Za-z_][A-Za-z0-9_]*` 并加双引号；
  单列聚合失败时该列统计留空、整表不失败、不编造数字。
- DSL `describe($value)`：Table → 值摘要；Str → 当前会话 Engine 的表摘要；
  其它类型明确抛 `X::Rakuish::Unsupported`。REPL `describe [表名]` 是会话
  命令（与 `hint` / `plugin` / `perf` 同级，**不是 `%magic`**）：无参数取上一格
  成功值（Table 直接摘要，否则列出 `tables()`），有参数需已注册 Engine。
- **不承诺**：大表 `count(distinct ...)` 性能（可用既有查询超时限制）、
  文本直方图、关联分析。
- 测试：`t/25-describe-complete.t`（69 断言）。

**V-164**：SQL 上下文补全增强（0.69，ADR-0006 §4）：

- 在 V-161 启发式上增加：`from sales s` / `join users as u` 的**别名映射**；
  `s.am` 前缀只补 `sales` 的列且不塞关键字，返回完整替换行 `s.amount`；
  关键字大小写跟随输入片段（`SEL` → `SELECT`、`Sel` → `Select`）；扩展调用名。
- 仍**不解析 SQL AST**：不引解析器依赖、不处理 `qq` / `Q` / heredoc
  （`q[...]` 由 V-169 以纯词法方式支持）、不承诺方言完整性；所有 Engine
  元数据调用继续包在 `try` 里优雅退化。
- 理由见 ADR-0006 §4：DuckDB / SQLite 方言不同、Tab 热路径成本不划算、
  启发式已覆盖主要场景。SQL AST 级补全列为 V-908「不做」。

**V-165**：REPL 的 `open-data` / `save-data` 名字解析（0.69，缺陷修复）：

- `REPL::Session` 同时 `use Rakuish::DSL` 与 `use Rakuish::Data` 时，后者导出的
  同名 sub（带 `$sys` 首参）会覆盖 DSL 版本，导致文档示例的单参数形态在
  EVAL 里报参数错误。Session 内部只用全限定名，故改为 `need Rakuish::Data`。
- 此后 REPL 中 `open-data('x.csv')` / `save-data('x.csv', $t)` 解析到 DSL 的
  会话级版本；`Rakuish::Data::open-data($sys, ...)` 仍可供脚本显式调用。
- 测试：`t/24-csv-dialect.t` 的 V-165 回归段。

**V-166**：失败格不污染 stderr（0.69.1，缺陷修复）：

- 症状：`zef test` / REPL 中，混合格或含 phaser 的声明格之后引用未声明类型时，
  stderr 出现两次 `Use of uninitialized value of type Any in string context`
  （`REPL::Session` 的 `CATCH` 取异常消息处）。
- 根因：部分编译期异常的 `.message` / `.gist` 在**方法内部**字符串化未定义值并
  抛 `CX::Warn`；仅在调用侧判断 `.defined` 拦不住。
- 修法：用 `quietly` 只包住「构造异常文本」这一小块，结果仍显式收敛成 `Str`，
  最后以 `$ex.^name` 兜底；错误消息内容不变、不吞掉其它警告。
- 测试：`t/18-repl-types-glob.t` 新增子进程断言——失败格 stderr 不含
  `uninitialized value` 且子进程正常退出。

**V-167**：交互式子进程的 TTY 直通（0.70，[ADR-0007](docs/ADR-0007-tty-passthrough.md)）：

- 症状：`! rakupp` 这类嵌套 REPL 的输出被 `Sys::Proc` 的 Channel 捕获，
  30s 后被默认超时杀成 `code=124`，失败格不进 `_` / `Out[n]`。
- 显式入口：`! --tty <exe> [args]` / `! -t <exe> [args]`，Raku 里是
  `tty-exec(...)`；`! -- <exe> ...` 之后全部按字面 argv，不解析元选项。
  元选项属于 `!` 分发层，子进程收到的仍只有 argv 数组。
- `Sys::Proc.tty-exec`：`bind-stdin($*IN)` / `bind-stdout($*OUT)` /
  `bind-stderr($*ERR)`，输出实时可见、**无超时**、不捕获、不进 `_`；
  只返回退出码 / 耗时 / exe / argv 的结构化 `Result`（`op=tty-exec`）。
- 守卫：`$*IN.t && $*OUT.t` 必须为真；非 TTY 抛
  `X::Rakuish::Unsupported`，`Session` 收敛成 `code=127` 的失败 Result，
  不污染 V-116 的管道纯净输出。`cwd` 仍经 `Sys.resolve` root 校验、
  `env` 仍是会话 Hash。
- Ctrl-C 归属：0.73.0 起 POSIX 上用**进程组交接**（`posix_spawnp`
  `SETPGROUP` + `tcsetpgrp`）让子进程成为终端前台，Ctrl-C 由终端驱动直接
  投给它，父进程收不到；`SIGINT tap` 只保留在 spawn 与切前台之间的
  微秒级窗口。Windows 与降级路径仍是「父进程临时吞 SIGINT」（见
  **V-175 / ADR-0010**）。行编辑器 `prompt()` 返回时已 `leave-raw-mode`，
  无需手工改终端模式。中断期间的完整契约与真 PTY 回归见
  **V-173 / ADR-0009**（0.72.3）。
- 默认 `!` 的捕获 / 截断 / 30s 超时 / `Result.value` 语义**一字未改**；
  `code=124` 的失败格提示改用 `tty-exec(...)`。
- Agent op 白名单不暴露 `tty_exec`；不自动探测交互式程序、不捕获交互式输出、
  不注册后台 job、不提供嵌套子进程的多路复用（ADR-0007 §4）。
- 测试：`t/26-nested-repl.t`（32 断言；Windows 跳过 4 条真 PTY 集成，
  WSL/Linux 用 Python `pty` 起真实子进程验证首字符不丢、退出码回传）、
  `t/30-tty-exec-sigint.t`（中断归属契约，V-173）；
  `tools/tty-check.py` 是完整交互自检工具。

**V-168**：Ctrl-C 中断输入而非退出 REPL（0.71，[ADR-0008](docs/ADR-0008-input-interrupt-sql-forms.md) §3.1）：

- 问题：`Terminal::LineEditor` 默认把 `Ctrl-C` 绑成 `abort-input`，
  `prompt()` 返回未定义 `Str`；`bin/rakuish` 把未定义当 EOF，于是整个会话
  退出，与 `Session.key-bindings` 的「中断当前 cell / 清空续行缓冲」及
  `handle-key('Ctrl-C')` 的值 API 不一致。
- `REPL::Keymap::InterruptCLIInput`（继承 `CLIInput`）在 `decode-keyname`
  记本次 prompt 的 Ctrl-C 标志，`prompt` 把「abort 且标志为真」收敛成
  **定义的空串**；`take-interrupt` 一次性供宿主查询。真 EOF 与 Ctrl-D
  仍返回未定义 `Str`，退出语义不变。`ViCLIInput` 继承该子类，`make-cli`
  在 emacs 模式也构造它；构造失败回退原生 `CLIInput` 时如实记录为 0.70 行为。
- 宿主命中中断标志后调用 `$session.handle-key('Ctrl-C')` 复用值 API 清
  `@!pending`，不 `eval-line`、不进历史、不产生空 `Out[n]` 格，打印暗灰
  提示并 `next` 重画 prompt。`Ctrl-D` / `exit N` 仍是退出入口。
- **边界**：只处理输入阶段的 Ctrl-C；cell 求值中行编辑器不读键，SIGINT
  仍按 Rakudo 默认行为，不承诺中断运行中的 cell。不复制 `read-input`、
  不用哨兵字符串、不装全局 SIGINT handler（ADR-0008 §4）。
- 测试：`t/19-repl-experience.t`（解码 / 一次性标志 / 三模式类接线）、
  `t/27-interrupt.t`（值 API + 真 PTY：半行 → Ctrl-C → 仍活 →
  `Out[1] = 42` → Ctrl-D 退出；Windows 跳过 8 条）、`tools/tty-check.py` 增 2 项。

**V-169**：SQL 补全的调用形态扩展（0.71，ADR-0008 §3.2）：

- `sql-context` 的扫描器除 `'...'` / `"..."` 外，还支持**不插值**
  `q[...]` / `q{...}` / `q(...)` / `q<...>`；`q` 前须词边界，反斜杠跳过
  下一字符，不处理嵌套分隔符。SQL 内含单引号时不再打断上下文。
- 调用检测放宽为「CALLS 白名单名字 + `(`，其后可跟 `:sql(` 或 `sql =>`」
  的紧邻前缀；不扫描整行、不做括号配对回溯。返回结构新增 `quote-style`
  （`single` / `double` / `q`）。
- 候选生成、完整替换行与 `tail` 保留、别名映射、大小写风格、Engine 异常
  优雅退化、Shell 回退**全部不变**；仍不做 SQL AST（V-908 不变），
  不识别 `qq` / `Q` / `qx` / heredoc。
- 测试：`t/23-sql-complete.t` 新增 q 四种分隔符 / 两种具名形态 / 内嵌单引号 /
  tail 保留 / 双引号回归 / `qq` 与非白名单负向。

**V-170**：PTY 捕获层（0.72）：

- `Sys.pty-exec` / `DSL.pty-exec` 用 `Proc::Async.new(:pty(:cols,:rows))`
  给子进程分配伪终端；stdout 由父进程捕获，stderr 合流（PTY 语义）。
- 默认 `strip-ansi=True`，去掉 CSI / OSC / 非换行控制字符；`Result.out`
  是干净文本，`value` 标记 `pty/tty/timed-out/truncated/cols/rows`，
  0.72.2 增 `pty-capable/stderr-merged/stdin-unavailable/strip-ansi`。
- `timeout-ms` 到点 kill 子进程，返回 `code=124`、`err='PTY 请求超时'`；
  `max-bytes` 限制的是**剥离后文本**的字节数：0.72.2 起先对完整输出剥离
  控制序列、再做 UTF-8 安全截断（控制序列不占配额，也不会被截成半截残留）；
  tap 内只按 chunk 计数，累积上限 `4 × max-bytes`。
- **能力探测（V-172）**：`pty-exec` 先过版本 + isatty 双检，失败返回
  `code=127` 且 `value<pty>/<tty>` 为 `False`，绝不静默当 PTY 用。
- **不提供 stdin 写入**：当前 Rakudo 的 `Proc::Async :pty` 没有可靠的
  stdin 通道；不要把它伪装成完整交互会话。
- Agent `pty_exec` 默认关闭；必须同时显式 `--allow-exec --allow-pty`，
  argv[0] 过 canonical 白名单，cwd 过 root，env 只允许安全键；
  请求参数只能调小 timeout / output / 尺寸。
- 测试：`t/28-pty-exec.t`（PTY 捕获、TTY 可见、控制序列剥离、超时 124、
  max-bytes、Agent 默认 403、显式开关成功）。

**V-171**：Windows 的“文件系统根”（0.72.1）：

- POSIX 的 `root=/` 表示整个文件系统；Windows 的 `C:\` 只是当前盘根。
- REPL / 脚本默认构造 `Sys.new(:all-drives)`，允许 `D:/`、`F:/` 等其他盘；
  root 仍记录启动盘，用于默认 cwd / 显示。
- Agent / 显式 `Sys.new` 默认 `all-drives=False`，跨盘目标仍按 root 拒绝。
- `all-drives` 时跳过逐段 symlink root 校验（语义等同 POSIX root=/）；
  不是 OS 隔离，Agent 不应打开。
- 测试：`t/02-sys-session.t` 在 Windows 有 F: 时验证跨盘允许/默认拒绝。

**V-172**：PTY 能力探测与捕获层收尾（0.72.2，[AUDIT-FIXES-0.72.2](docs/AUDIT-FIXES-0.72.2.md)）：

- 起因：`Proc::Async.new` 用 `*%_` 吞掉未知命名参数，旧 Rakudo 传 `:pty`
  不报错、不生效；0.72.0/0.72.1 的 `Result.value<pty>/<tty>` 却硬编码
  `True`，等于结果撒谎（任务书 R-1，`[确证]`）。
- `Rakuish::Sys::Proc.pty-capability()` 做「`$*RAKU.compiler.version >=
  v2025.12` + 用 `:pty` 起 `raku -e 'print $*OUT.t …'` 真探针」双检，
  结果 `Lock` + 进程级缓存（一次/进程），失败带 `reason`。
  `META6.json` 的 `raku` 字段是语言版本，不能当 Rakudo 下限用；
  最低 Rakudo 版本写进 MANUAL / AUDIT-FIXES，不塞未识别元数据键。
- 探测失败时 `pty-exec` 返回 `Result.new(:!ok, :code(127))`，`err` 写明
  原因、`value<pty>/<tty>` 为 `False`；**不降级成普通 exec、不抛穿 Agent**。
  方法为 public，可被子类覆盖以注入失败路径（`t/29`，无需装旧 Rakudo）。
- 捕获层（任务书 R-3，`[需复核]` → 已实证）：tap 内改「数组追加 + 仅对
  新 chunk 计 UTF-8 字节」，结束一次 `join`；先 `strip-terminal-controls`
  再 `clip-bytes`；超过 `4 × max-bytes` 停止累积但继续消费并标 `truncated`；
  drain 改为等 stdout Supply 的 `done/quit`（0.5s 兜底、超时标 `truncated`）
  而非固定 `sleep 0.02`；Windows ConPTY 大输出仍可能在驱动层丢尾部 chunk
  （裸 `Proc::Async` 同样复现，非本版回归，见 AUDIT-FIXES-0.72.2 §3）。
- **边界不变**：`:!strip-ansi` 仍按原始字节截断（半截序列是该模式已知边界）；
  stderr 合流、`err` 恒空（超时除外），用 `value<stderr-merged>` 标记；
  不提供 stdin 写入（交互式 REPL 请用 `tty-exec`），用
  `value<stdin-unavailable>` 标记；超时只 kill 直接子进程，不承诺杀孙进程。
- 测试：`t/28-pty-exec.t`（18 断言）+ `t/29-pty-capability.t`（36 断言：
  能力探测、注入失败、结果标记、截断无 CSI 残片、`:!strip-ansi`、大输出）。

**V-173**：`tty-exec` 期间 Ctrl-C 的归属契约（0.72.3，[ADR-0009](docs/ADR-0009-tty-exec-sigint-contract.md)）：

- `! --tty` / `tty-exec(...)` 期间，前台进程组收到 SIGINT（真终端的 Ctrl-C）
  时，子进程按自身 SIGINT 语义退出，`tty-exec` 返回交接摘要与
  `Result.value<exit>`；**父进程存活**，之后重画 prompt，下一格可正常
  输入并求值；`LEAVE` 关闭临时 tap 后，普通 Ctrl-C 仍是 V-168 的输入中断。
- 实现不变：`Sys::Proc.tty-exec` 的 `signal(SIGINT).tap(-> $ { })` +
  `LEAVE` 这一对行为已满足契约（0.72.2 实测）。本版只把契约钉成断言，
  **不改产品代码**。
- 回归用「`start_new_session` + `killpg(pgrp, SIGINT)`」模拟前台进程组。
  **0.73.0 起改为真终端路径**（`pty.fork` + 写 `\x03`）：进程组交接落地后，
  那个模拟写法不再成立 —— 切组后信号打不到子进程（见 V-175）。
- **边界**：0.72.3 当时不做 `setpgid` / `tcsetpgrp`；**该边界已由 V-175
  在 0.73.0 解除**（POSIX-only）。仍不做 `&` / `jobs` / `fg` / `bg` /
  Ctrl-Z 作业管理。子进程忽略 SIGINT 时 `tty-exec` 仍按无超时边界一直等；
  不承诺求值中 SIGINT 的 Rakudo 默认行为；Windows 无 pty 时整段跳过。
  终端状态恢复 0.72.4 起单独由 V-174 覆盖（0.72.3 曾误判为「本驱动不可观测」）。
- 测试：`t/30-tty-exec-sigint.t`（Linux/WSL 真 PTY，5 条契约断言；
  Windows skip）、`tools/tty-check.py` 增 2 项。

**V-174**：`tty-exec` 交接期的宿主 termios 快照恢复（0.72.4，
[ADR-0009 §0](docs/ADR-0009-tty-exec-sigint-contract.md)）：

- 背景：`tty-exec` 将宿主 TTY 三条 fd 直接 bind 给子进程；子进程
  （vim / less / `stty raw -echo`）改动 termios 后不还原时，行编辑器
  下一轮 prompt 会把污染态当成新基准「保存并恢复」，污染固化（实测
  `c_lflag` 35387 → 35376，关掉 `ICANON + ECHO + ISIG`）。
- `Sys::Proc.tty-exec` 在 `bind-stdin` **之前**调用
  `termios-snapshot($fd)` 保存宿主配置，正常路径与 `LEAVE` 幂等恢复
  （`Terminal::API::restore-config(..., :when(DRAIN))`）。`LEAVE` 是块级
  phaser，非 TTY 守卫抛异常时也会触发，故恢复前必须判 `$saved.defined`
  并整体包 `try`，不得覆盖原异常。
- 复用 `Terminal::API`（`Terminal::LineEditor` 的传递依赖，0.72.4 起在
  `META6.depends` 显式声明）：Linux / macOS / BSD 三套 CStruct 与
  Windows `GetConsoleMode` / `SetConsoleMode` 均已封装，不重写 NativeCall。
- `Result.value<termios-restored>` 如实标记恢复成败；快照不可用
  （非 TTY / API 失败 / 子类注入）时**不阻断直通**，只标 `False`。
- **边界**：不猜测子进程改了哪些位，整份配置恢复。
- Windows 无 POSIX termios，走 `GetConsoleMode` / `SetConsoleMode`。
  0.72.5 用真 ConPTY 实测通过：输入模式 `503` → 子进程 `make-raw` 后
  `1008` → 返回后 `503`（`termios-restored=True`），关掉快照的对照保持
  `1008`；conhost（winpty）下数值一致。`prove6` 环境无控制台，该分支不进
  `t/`，由 `tools/tty-termios-win.py` 自查（ADR-0009 §7）。
- 测试：`t/31-tty-termios.t`（canonical 基线 PTY，13 断言：正常恢复 /
  注入禁用快照的对照证明污染真实发生 / 非零退出路径 LEAVE 兜底；
  Windows 只跑 2 条非 TTY 退化断言）。

**V-175**：`tty-exec` 的 POSIX 进程组交接（0.73.0，
[ADR-0010](docs/ADR-0010-job-control-feasibility.md) §6）：

- 背景：0.72.x 用 `Proc::Async` 起子进程，父子**同属一个进程组**，
  靠父进程临时吞 SIGINT 保命。后果是子进程一句 `kill(0, SIGTERM)`
  （现实中清理进程组的工具会这么做）会把宿主 REPL 一起打死 —— 真 PTY
  实测 `alive=False`。而 POSIX 只允许父进程对**尚未 exec** 的子进程
  `setpgid`，`Proc::Async` 交出 pid 时子进程早已 exec（实测 60/60 失败、
  `EACCES`），所以只能在 spawn 时定组。
- 实现：POSIX 上改用 `posix_spawnp` + `POSIX_SPAWN_SETPGROUP(0)`
  （新模块 `Rakuish::Sys::PosixSpawn`），spawn 后 `tcsetpgrp(0, child-pgid)`
  把终端前台交给子进程；`waitpid` 自己回收并解出 `exit` / `sig`。
  返回时把前台还给宿主，再恢复 termios。
- **SIGTTOU 必须真 `SIG_IGN`**（`signal(2)` + handler `(void*)1`），并在
  `LEAVE` 还原旧 handler。用 Raku 的 `signal(SIGTTOU).tap` 是捕获语义，
  会让恢复那次 `tcsetpgrp` 返回 `ENOTTY`（ADR-0010 §2.3 实测）。
- SIGINT tap 缩到**交接窗口**（spawn 后、切前台前）：那段时间前台仍是父组，
  不兜住会被 Ctrl-C 带走；切前台成功立即关闭。正常运行**不依赖**该 tap。
- `cwd`：`posix_spawn` 无 cwd 参数，用
  `posix_spawn_file_actions_addchdir_np`；与当前目录相同的请求直接跳过该动作。
  符号不可用（glibc < 2.29 / macOS < 10.15）时**降级**回 `Proc::Async`，
  `value<job-control>=False` 且写 `value<job-control-reason>`，
  **绝不改父进程 `chdir`**。
- 状态映射：`WIFSIGNALED` → `code = 128 + sig`；`posix_spawnp` 返回
  `ENOENT(2)` → `code=127`；`waitpid` 拿不到状态 → `code=1`（不谎报成功）。
- `Result.value` 新增 `job-control` / `job-control-reason` / `fg-restored` /
  `pgid`；原有 `exit` / `signal` / `elapsed` / `termios-restored` 语义不变。
- **边界**：只做进程组交接。不做 `&` 后台、`jobs` / `fg` / `bg`、Ctrl-Z
  作业管理（那是 shell 语法，需另立议题，且与 V-90x「不引 bash 语法」冲突）；
  不做信号转发（SIGWINCH 由子进程组自己处理）；不做孙进程树回收（V-905）。
  Ctrl-Z 会把子进程停住而 REPL 等在那儿 —— 这是明确划出去的已知行为。
- Windows 无 POSIX 前台进程组（`CTRL_C_EVENT` 不能投递给进程组，属 MSDN
  明确语义），走老路径，`value<job-control>=False` 并带原因。
- 测试：`t/32-job-control.t`（真 `pty.fork` controlling terminal，11 断言：
  自成一组 / 拿到前台 / 退出码与信号码映射 / cwd 动作 / `kill(0)` 不波及
  宿主 / Ctrl-C 只投给前台组 / 前台收回；Windows skip）。
  `t/30` 的驱动同步改用真终端路径（`pty.fork` + 写 `\x03`）。

**V-176**：内置命令结果的着色（0.74.0，
[ADR-0011](docs/ADR-0011-highlight-colors.md) §2–§3）：

- 开关链唯一：`config color` / `NO_COLOR` / `FORCE_COLOR` / `$*OUT.t`
  → `Chrome::color-mode()` → `Session.new(:color)` 与 `make-cli` 的高亮开关。
  `Session` 的默认值是 `False`（忘记传参的调用点一律纯文本）。
- 着色点与样式：路径列表与 `ls -l` 的名字列（目录粗蓝 / 可执行粗绿 /
  符号链接青）、`Out[n] =` 标签（dim）、`错误:` 整行（红）、`help()`
  的命令名（粗青）与摘要（dim）、`env()` 的 KEY（青）、`stat` 的字段名
  （dim）、写入结果的 `wrote`（绿）与 `[non-atomic]`（黄）。
- **不变式**：颜色只插入零宽转义。列宽、列数、padding 一律按**纯文本**算，
  否则多列 `ls` 会错位；`strip-ansi(着色结果)` 必须与不着色时逐字符相同。
- **渲染层必须同时判 TTY**：只问 `color` 开关会让 `rakuish -e 'ls' | cat`
  混进 ANSI，违反 V-116。统一走 `Session!color-on`（开关 ∧ `$*OUT.t`）。
- **不做**：`Result` 的 `render-result(format => 'text')` 仍不掺 ANSI
  （SPEC 747 不变）；`Table.to-text`（describe / `ls --json`）不着色；
  Agent 输出不着色（JSONL 没有终端语义）。
- 测试：`t/33-colors.t`（非 TTY 零 ANSI、色表、路径分类）；
  `tools/tty-check.py` 在 raw 字节上断言真 PTY 下 `ls` 目录确实着色。

**V-177**：REPL 输入行的语法高亮（0.74.0，
[ADR-0011](docs/ADR-0011-highlight-colors.md) §4）：

- 实现方式：行编辑器不提供高亮钩子，覆盖
  `ScrollingSingleLineInput::ANSI.visible-input-field-string` —— 它是
  「左滚动标记 + 内容 + padding + 右标记」那一层，只给中间的内容段上色。
  新增 `Rakuish::REPL::Keymap::HlField` 作为基类，`ViField` 继承它，
  `InterruptCLIInput` 覆盖 `input-class` 让 emacs 模式也走同一个字段类。
- **硬不变式**：着色串的**纯文本部分**必须与不染色时逐字符相同。父类用
  `display-width`（对 buffer 内容算出的显示宽度）定位光标与清屏，多一个
  可见字符就会让输入区错位。`$.mask.defined`（掩码输入）时直接短路。
- 词法范围（`Rakuish::REPL::Highlight`，纯函数）：注释 `#…`、单双引号
  字符串（含 `\` 转义、未闭合染到行尾）、数字、`$ @ % &` 变量（含 twigil）、
  关键字表。**不做** `q[...]` / `qq[...]` / heredoc / 正则字面量 /
  多行字符串 / pod —— 它们需要跨行状态或真正的 Raku 词法器。
- 回退：`make-cli` 在子类构造失败时回退到原生 `CLIInput`，那条路径
  **没有高亮**（与 Ctrl-C 的回退同理，如实标注，不假装）。
- 开关与 V-176 同源，`config set color off` 当格生效；非 TTY 与
  `NO_COLOR` 下不进入着色分支。
- 测试：`t/33-colors.t`（27 个样本的纯文本等价、`:!color` 逐字节相同、
  各 token 命中）；`tools/tty-check.py` 在 raw 上断言真 PTY 输入
  `say "hi"` 时字符串与关键字确实着色。


**V-126**：REPL 对常见返回值做 shell 习惯的展示，而不是一律 `.raku`:

| 返回值 | 展示 |
|---|---|
| `List[IO::Path]`（`ls` / `glob` / `recent`） | basename 列表；TTY 多列，管道一行一个 |
| `CommandSpec` 列表（`help()`） | 命令名 + 摘要对齐 |
| `List[Str]`（如 `registry.names`） | 一行一个 |
| `Hash`（如 `env()`） | `KEY=VALUE`，按 key 排序 |
| `Str`（如 `read()` / `pwd()`） | 原样内容/路径，不显示 Raku 引号 |
| `Stat` | `path/type/size/mode/modified/...` 字段 |
| `WriteResult` | `wrote N bytes to PATH` |
| `IO::Path` | 路径字符串 |
| `Result` | 优先命令 stdout / stderr，回退 `text` |
| 其它 | `Out[n] = .raku` |

这些只是展示层，值本身仍是原来的类型，`.grep` / `.map` / `.value` 不受影响。

**V-127**：REPL 提供“日常 shell 观感”薄层，但**不是第二套 shell**：
支持 `cd [dir|-]` / `pwd [-L|-P]` / `clear` / `history` / `set -e|+e` /
`jobs` / `which` / `alias` / `unalias` / `config` / `hook` / `explore` /
`ls [-a -l -h -F -R -t -S -r -d]` / `cat` / `read` / `head|tail [-n N]` /
`echo [-n]` / `mkdir [-p]` / `touch` / `cp [-r]` / `mv` / `rm [-r] [-f]` /
`stat` / `export` / `unset` / `glob` / `grep [-inv]` / `wc [-lwc]`。
命令只翻译成直接 `Sys` 调用；每个命令支持 `--help` / `-?`
查看自己的用法，也支持 `help <命令>`。不支持管道、重定向、子 shell。
参数中的 `$NAME` 按会话 env 展开，`~` 展开到 `$*HOME`；带 Raku 表达式或
非字面参数的输入仍交给 Raku。实现位于 `Rakuish::REPL::Shell`，不改变底层
`Sys` / DSL API。

---

## 4. Sys API（V-20x）

**V-201**：路径一律 `IO::Path`，不自建 `Platform::Path`。
`resolve` 做词法归一化 + **中间 symlink canonical 校验**，`../` 或真实目标越界
抛 `X::Rakuish::Sandbox`。

**V-202**：文件 API（经 `Sys` 委托到 `Sys::FS`）：
`read` / `write` / `append` / `ls` / `stat` / `rm` / `cp` / `mv` / `mkdir` / `glob`。
`write` 默认原子写（Windows 降级失败必须回滚，不先丢目标）；`rm` 不跟随符号链接、
拒绝删会话 root、支持 `:dry-run`；`cp -r` 遇到 symlink 直接拒绝；`ls file` 返回
单元素列表；`glob` 支持 `*` / `?`，`*` 不跨目录分隔符。

**V-203**：进程 API（`Sys::Proc`）：`exec` / `spawn` / `wait` / `cancel`；
`Handle.stdout` / `.stderr` 是 `Channel.Supply` 真流式输出。
`cwd` / `env` 经 `Proc::Async.start(:cwd, :ENV)` 显式下传，宿主 `$*CWD` / `%*ENV` 不变。

**V-204**：`exec` 永不抛：正常 `0`、启动失败 `127`、超时 `124`、取消 `137`；
`Result.value` 带 `exe / argv / timed-out / cancelled / truncated / start-failed` 供审计。
输出由 `Handle.wait` 边读边按 UTF-8 **字节**限流，超过 `max-bytes` 保留安全前缀并
丢弃后续（内存不随输出增长），且不切坏中文。

**V-205**：错误模型——读 / 写 / 列目录 / stat **抛异常**（Raku 风格）；
`rm` / `cp` / `mv` / `mkdir` 返回 `Result`；Agent 边界用 `Sys.try-op` 统一收敛。

**V-206**：Windows 只承诺 argv 外部命令 + 文件 API，不承诺 bash / POSIX 语法。
`IO::Path.mode` / `.modified` 在 Windows 上可能返回 0 或 1969 年假值，
`Stat` 如实返回、不编造时间；`DSL.recent` 检测到不可信时间就降级为全量。

**V-207**：`Result` 提供多格式渲染层 `render(Str $format = 'text', *%opts --> Str)`：

| 格式 | 别名 | 说明 |
|---|---|---|
| `text` | `txt` / `plain` | 默认人读格式；`ok/op/code/elapsed/out/err/value`，不掺 ANSI |
| `json` | — | JSON；默认紧凑，`:pretty` 展开；键序稳定（按 key 排序），路径统一 `/` |
| `markdown` | `md` | 标题 + 元信息 + `stdout` / `stderr` / `value` 代码围栏；围栏会自动加长 |

`to-text` / `to-json` / `to-markdown` 是等价便捷方法。未知格式抛
`X::Rakuish::Render`（定义在 `Rakuish::Result::Renderer`），不静默回落 `text`。
渲染层不读文件、不起进程、不改 `Result`。

---

## 5. DSL 与 Command（V-30x）

**V-301**：`Rakuish::DSL` 导出短 sub：
`ls / read / write / append / stat / rm / cp / mv / mkdir / glob / exec /
cd / pwd / cwd / resolve / env / get-env / set-env / unset-env /
try-op / timed / help / recent`。
它们委托给会话绑定的 `Sys`；用户想加「常用命令」就再写一个普通 Raku sub，
返回可组合的值，无需注册表、无需改分支表。

**V-302**：`Rakuish::Command` 提供 `role Command { name / spec / run(Sys, @args --> Result) }`、
`CommandSpec`（参数 schema → JSON Schema）、`ExternalCommand` / `BuiltinCommand`、
可扩展 `CommandRegistry`（默认 13 个命令）。加命令只需 `register(...)`。

**V-303**：`BuiltinCommand.run` 必须**透传** handler 已返回的 `Result`，
否则外层 `try-op` 会把子进程退出码伪装成 0、`out` 吞成空串。

**V-304**：内置命令统一附带 text 渲染：`BuiltinCommand.run` 返回的 `Result`
保留结构化 `value/out/err/op`，同时把 `render('text')` 写入 `Result.rendered`。
`Result.text` / `.to-text` / `.gist` 优先返回该缓存；`say $result` 与 REPL
展示内置命令结果时走 text，而不是对象的 raku 结构。`render('json')` /
`render('markdown')` 不受 text 缓存影响。

---

## 6. Agent 结构化 op（V-50x）

**V-501**：请求是 **JSONL**（一行一个 JSON 对象），不是 shell 字符串：

```text
{"id":1,"token":"SECRET","op":"write_file","path":"a.txt","content":"hi"}
{"id":2,"token":"SECRET","op":"read_file","path":"a.txt"}
{"id":3,"token":"SECRET","op":"exec","argv":["git","status"]}
```

**V-502**：处理顺序固定：解析 → 认证 → 策略 → 分派 → 审计 → 结构化响应。
响应码：`400` 坏 JSON / `401` token 错误 / `403` 策略拒绝 / `404` 未知 op /
`500` 执行异常；成功 `0`。响应里的路径统一为 `/`。

**V-503**：op 白名单（含别名）：
`read_file|read`、`write_file|write`、`list_dir|list|ls`、`stat`、`exec`、
`rm`、`mkdir`、`cp`、`mv`、`glob`、`sql_query`。**没有 `eval` op** —— 任意 Raku
代码会绕过 root / 白名单 / 审计。`sql_query` 还需 `Sandbox.allow-sql` 和只读 Engine。

**V-504**：每个会话一个独立 `Sys`；多会话 cwd / env 互不污染。
`exec.cwd` 必须过 `Sys.resolve` 的 root 校验；请求级 `env` 只允许
`LANG` / `LANGUAGE` / `TZ` / `LC_*`，禁止 `PATH`、`LD_PRELOAD` 等危险键。
exec 白名单的绝对路径必须 canonicalize 后精确匹配，不能只比 basename。

**V-505**：传输层两种，默认 JSONL over stdin/stdout；TCP **只绑 127.0.0.1**，
启动信息走 stderr，不污染 stdout。

**V-151**：Agent 常驻多客户端（0.63 / [ADR-0002](docs/ADR-0002-agent-serve.md)）：
- `Agent::Server.serve()` 是常驻 accept loop；`serve-once` **保留**为单连接兼容入口，
  语义不变（`t/06` 守护）。`--serve` 显式开启，默认仍是单连接。
- 每连接独立 `Rakuish::Agent`（独立 `Sys` / cwd / env / jobs，独立 `session` 审计）；
  Engine 连接不共享：常驻模式必须由 `engine-factory` 每连接新建，
  否则拒绝启动，不静默共享。
- `--max-connections` 只做**拒绝**（超限关闭新连接并计数），不放宽已有能力；
  `$stop` Promise 优雅停止；每连接独立 idle timeout。
- 安全契约不变：默认拒绝、`exec` / `sql_query` 默认关闭、token / root / 白名单 /
  env 安全键 / 审计脱敏 / 请求级参数只能调小。
- 0.67 起 `--worker` 是可选的 OS 硬取消模式，见 V-159；默认路径不变。
- 测试：`t/16-agent-serve.t`（504 即时、并发连接、session 隔离、engine-factory
  每连接调用、慢请求后连接仍可用、stop 收尾）。

---

## 7. Sandbox 默认安全（V-60x）

| 条款 | 默认值 |
|---|---|
| V-601 | 显式 `--root`（无默认值，不传就起不来） |
| V-602 | 监听 `127.0.0.1`；入口刻意不暴露 `--host` |
| V-603 | 启动时生成 token；OS CSPRNG（Windows `RtlGenRandom` / POSIX `/dev/urandom`）生成 64 位 hex；生产也可显式 `--token` 传入外部生成值 |
| V-604 | `exec` **默认关闭**；开启需 `--allow-exec` + `--allow <命令>` 白名单；带路径的 argv 必须与白名单绝对路径精确匹配 |
| V-605 | 读写 1 MiB、超时 30 s、输出 1 MiB；请求级参数**只能调小，不能调大** |
| V-606 | 审计 JSONL：只记 op / path / argv / 结果与时间戳，**不含 token 与文件内容** |

---

## 8. 明确不支持 / 待办（V-90x）

| 编号 | 内容 | 归属 |
|---|---|---|
| V-901 | bash / POSIX 语法（管道、重定向、变量展开、glob、heredoc、`&&` 短路语义、`$?`） | 永不支持；用 Raku 表达 |
| V-902 | `%magic` 分流、auto-shell 回退、反引号 shellq | 已删除（Phase 3） |
| V-903 | glob 转义、brace 嵌套等剩余完整语法 | 已实现（0.65，V-153）；Shell 薄层文件名参数仍只展开 `* ?` |
| V-904 | `class` / `role` / `grammar` 的跨格持久 | 已实现（0.65，V-153）；类型对象身份不跨格 |
| V-905 | worker 派生孙进程的强杀、跨连接状态共享、可恢复/事务一致性游标 | 不做（worker 仍不引入 job object / 进程树跟踪；`tty-exec` 的进程组交接只覆盖前台交接，见 V-175） |
| V-906 | 持久求值器 / 常驻编译单元 | 不做（现有声明缓存已覆盖主要场景；换底座须独立 ADR，且仍禁止历史重放） |
| V-907 | CSV 方言参数 | 已实现（0.69，V-162 / ADR-0006 §2）；不做编码 / 多行字段精细控制 |
| V-908 | SQL AST 级补全 | 不做（ADR-0006 §4）：不引解析器依赖，启发式已覆盖主要场景 |
| V-909 | 交互式子进程自动探测、Agent 的 `tty_exec`、无开关的交互式捕获 | 不做（ADR-0007 §4）；`pty_exec` 是 0.72 的显式、双开关、带超时捕获入口，不等同于 `tty_exec` |

---

## 9. 验收

- `raku -Ilib t/*.t`：Windows / Linux 双平台 `not ok = 0`；
  `t/07` 专门守护入口契约（只有两个入口、无 v2 痕迹、转发继承 stdio、版本一致、`api = 3`）。
- `bash tools/run-all.sh`：任意一条 `not ok` / 非零退出码 / 缺 TAP plan 都算问题，
  脚本退出码即 `问题总数 == 0`。
- `python3 tools/tty-check.py`（Linux / WSL）：真 PTY 交互自检，覆盖 banner、
  彩色 prompt、Vi 徽标、Tab / SQL 补全、describe、Ctrl-C 中断后继续求值、
  嵌套 REPL 的 TTY 直通，以及 `tty-exec` 期间前台进程组 SIGINT 的归属
  （ADR-0009 / ADR-0011，25 项）；`t/27-interrupt.t` / `t/30-tty-exec-sigint.t` /
  `t/32-job-control.t` 在 Linux/WSL 也跑真 PTY 断言。
- `t/28` / `t/29`：PTY 捕获与能力探测双平台回归；`t/29` 用子类注入
  「不支持 PTY」的失败路径，不需要真的安装旧 Rakudo。
- `t/32`：进程组交接（V-175）的真 controlling terminal 回归，Windows
  整段 skip（POSIX-only）。
- 每个条款有对应断言；正向（必须含 Y）与反向（不得含 X）成对出现。
