unit class Rakuish::Data::Pager;

# 结构化分页器：只负责把已经渲染好的文本分页，不重新解释数据。
# 非 TTY 下不暂停，直接完整输出；TTY 下按页输出并等待 Enter。

use Rakuish::Data::Table;

has Int $.page-size = 20;

method summary(Rakuish::Data::Table $t --> Str) {
    "{ $t.elems } 行 × { $t.columns.elems } 列\n" ~ $t.schema.to-text;
}

method page($value, :$in = $*IN, :$out = $*OUT,
           Bool :$interactive = (so try { $in.t }) --> Str) {
    my Str $text = $value ~~ Rakuish::Data::Table
        ?? $value.to-text
        !! $value.Str;
    my @lines = $text.lines;
    return '' unless @lines.elems;

    unless $interactive {
        return $text;
    }

    my Int $size = $!page-size max 1;
    my Int $start = 0;
    while $start < @lines.elems {
        my Int $end = ($start + $size - 1) min (@lines.elems - 1);
        for @lines[$start .. $end] -> $line { $out.say($line) }
        $start = $end + 1;
        last if $start >= @lines.elems;
        $out.print("-- more ({$start}/@lines.elems; Enter=下一页, q=退出) -- ");
        $out.flush;
        my $answer = $in.get;
        last unless $answer.defined;
        last if $answer.trim.lc eq 'q';
    }
    $text
}
