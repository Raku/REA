use Rakuish::Data::Table;
use Rakuish::Data::Cursor;
use Rakuish::Result;

unit role Rakuish::Data::Engine;

# Rakuish::Data::Engine —— 数据引擎契约（DuckDB / SQLite 适配器实现）。
# 上层只依赖这个角色 + Table/Cursor；不直接依赖某个数据库驱动。
#
# :max-rows 是 0.64 的大结果保护：引擎在物化前把 LIMIT 下推进 SQL，
# 避免 `select *` 一次性把全部行读进内存。不传时行为与旧版完全一致。
# 0.67 的 cursor() 则是真正的惰性执行：只在被拉取时向驱动要下一批行。

method query(Str $sql, *@params, Int :$max-rows --> Rakuish::Data::Table) { ... }
method execute(Str $sql, *@params --> Int) { ... }
method begin() { ... }
method commit() { ... }
method rollback() { ... }
method tables(--> Rakuish::Data::Table) { ... }
method schema(Str $table --> Rakuish::Data::Table) { ... }
method close(--> Nil) { ... }

# 流式游标是可选能力：给默认「明确拒绝」实现，而不是 stub。
# 不支持的引擎不能静默退化成 query() 一次性物化，否则「惰性」就是假承诺。
method cursor(Str $sql, *@params, Int :$batch-size = 1000,
              Int :$max-rows --> Rakuish::Data::Cursor) {
    X::Rakuish::Unsupported.new(
        :detail('当前引擎不支持流式游标；请用 DuckDB/SQLite 引擎的 cursor() 或 query()')
    ).throw
}

# describe 是值 API（0.69 / ADR-0006 §3）：默认实现只依赖契约里的
# schema() / query()，因此任何实现该角色的引擎都自动获得，不必各自写一遍。
# 返回结构化 Table，不是文本报告；调用方可继续 .where / .to-json / .sort-by。
method describe(Str $table, Int :$sample = 3 --> Rakuish::Data::Table) {
    my Str $name = $table.trim;
    X::Rakuish::Unsupported.new(
        :detail('describe 表名只允许字母/数字/下划线，且不以数字开头')
    ).throw unless $name ~~ /^ <[A..Za..z_]> <[A..Za..z0..9_]>* $/;

    my $schema = try { self.schema($name) };
    X::Rakuish::Data.new(
        :detail("describe 无法读取表 $name 的元数据")
    ).throw unless $schema.defined;

    my @cols;
    my @types;
    my @nullable;
    for $schema.rows.List -> $r {
        next unless $r ~~ Associative;
        my $cn = $r<column_name> // $r<name> // $r<Name> // $r.values[0];
        next unless $cn.defined && $cn.Str.chars;
        my $ct = $r<column_type> // $r<type> // $r<Type> // 'any';
        my $nl = $r<null> // $r<notnull> // '';
        @cols.push($cn.Str);
        @types.push($ct.Str);
        @nullable.push(so ($nl.Str.lc eq 'yes' || $nl.Str eq '0'));
    }
    X::Rakuish::Data.new(:detail("表 $name 没有可读的列")).throw unless @cols.elems;

    my Str $quoted = '"' ~ $name.subst('"', '""', :g) ~ '"';
    my @agg = @cols.kv.map(-> $i, $c {
        my Str $q = '"' ~ $c.subst('"', '""', :g) ~ '"';
        "count($q) as \"nn_$i\", count(distinct $q) as \"dc_$i\""
    });
    my Str $stats-sql = 'select count(*) as __total, '
                        ~ @agg.join(', ') ~ " from $quoted";
    my $stats = try { self.query($stats-sql) };
    my %s = $stats.defined && $stats.rows.List.elems
            ?? ($stats.rows[0]<>).Hash
            !! %();

    my Int $n = ($sample max 0) min 20;
    my $head = $n > 0 ?? try { self.query("select * from $quoted limit $n") }
                      !! Nil;
    my @sample-rows = $head.defined ?? ($head.rows.List) !! ();

    my @out;
    for @cols.kv -> $i, $c {
        my @vals = @sample-rows.map(-> $r {
            my $v = $r ~~ Associative ?? $r{$c} !! Nil;
            $v.defined ?? $v.Str !! ''
        }).grep(*.chars).unique;
        @out.push({
            name     => $c,
            type     => @types[$i],
            nullable => @nullable[$i],
            non_null => %s{"nn_$i"} // Nil,
            distinct => %s{"dc_$i"} // Nil,
            total    => %s<__total> // Nil,
            sample   => @vals.head($n).join(' | '),
        });
    }
    Rakuish::Data::Table.from-rows(@out,
        :columns<name type nullable non_null distinct total sample>)
}

# 外部文件读写只有 DuckDB 实现；其它引擎给出明确「不支持」而不是静默按文本处理。
# $path 必须是**调用方经 Sys.resolve 校验过的绝对路径**：引擎自身不碰 Sys，
# 也不替 Agent 开放外部访问（V-130 / V-152 / V-160）。
# :%csv-options 是 0.69 的方言白名单（ADR-0006 §2），默认空 = 0.68 行为。
method read-parquet(Str $path, Int :$max-rows --> Rakuish::Data::Table) {
    X::Rakuish::Unsupported.new(
        :detail('当前引擎不支持 Parquet 读取；请用 DuckDB 引擎')
    ).throw
}

method write-parquet(Str $path, Str $sql --> Int) {
    X::Rakuish::Unsupported.new(
        :detail('当前引擎不支持 Parquet 写入；请用 DuckDB 引擎')
    ).throw
}

method read-csv(Str $path, :%csv-options = {}, Int :$max-rows --> Rakuish::Data::Table) {
    X::Rakuish::Unsupported.new(
        :detail('当前引擎不支持 CSV 外部读取；请用 DuckDB 引擎')
    ).throw
}

method write-csv(Str $path, Str $sql, :%csv-options = {} --> Int) {
    X::Rakuish::Unsupported.new(
        :detail('当前引擎不支持 CSV 外部写入；请用 DuckDB 引擎')
    ).throw
}
