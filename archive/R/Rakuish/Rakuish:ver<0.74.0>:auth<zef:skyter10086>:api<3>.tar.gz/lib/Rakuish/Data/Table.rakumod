unit class Rakuish::Data::Table;

# Rakuish::Data::Table —— 结构化表格值（Nushell/Elvish 风格的“数据优先”）。
#
#   my $t = Table.from-rows([{name => 'a', size => 1}, ...]);
#   $t.where({ .<size> > 0 }).select('name').sort-by('name').to-text
#
# 这不是 shell 文本表格：rows 是真 Hash，get/where/select 可继续组合。

use JSON::Fast;

has @.columns is rw;
has @.rows is rw;
has %.types is rw;              # column => int/num/str/bool/datetime/list/map/any

method new(:$columns = [], :$rows = [], :$types) {
    my $obj = self.bless;
    my @r = self!normalize-rows($rows);
    my @cols = $columns ~~ Positional ?? $columns.List !! ($columns,);
    @cols = @r[0].keys.sort unless @cols.elems || !@r.elems;
    $obj.columns = @cols;
    $obj.rows = @r;
    my %t;
    if $types ~~ Hash {
        %t = $types.Hash;
    }
    if %t.elems == 0 {
        for @cols -> $c {
            %t{$c.Str} = self!infer-type(@r.map({ $_{$c} }).List);
        }
    }
    $obj.types = %t;
    $obj;
}

method !infer-type(@values --> Str) {
    my @v = @values.grep({ .defined });
    return 'any' unless @v.elems;
    return 'bool'  if @v.all ~~ Bool;
    return 'int'   if @v.all ~~ Int;
    return 'num'   if @v.all ~~ (Int | Num | Rat);
    return 'datetime' if @v.all ~~ (DateTime | Instant);
    return 'list'  if @v.all ~~ Positional;
    return 'map'   if @v.all ~~ Associative;
    return 'str'   if @v.all ~~ Str;
    'any';
}

method !normalize-rows($rows --> List) {
    my @raw = $rows ~~ Associative
        ?? ($rows,)
        !! $rows.List;
    my @out;
    my @pairs;
    for @raw -> $r {
        if $r ~~ Pair {
            @pairs.push($r);
            next;
        }
        if @pairs {
            my %h;
            for @pairs -> $p { %h{$p.key} = $p.value }
            @out.push(%h);
            @pairs = ();
        }
        @out.push($r.Hash) if $r ~~ Associative;
    }
    if @pairs {
        my %h;
        for @pairs -> $p { %h{$p.key} = $p.value }
        @out.push(%h);
    }
    @out.List;
}

submethod TWEAK() {
    if @!columns.elems == 0 && @!rows.elems {
        @!columns = @!rows[0].keys.sort;
    }
}

method from-rows(@rows, :@columns, :$types --> Rakuish::Data::Table) {
    my @normalized = self!normalize-rows(@rows);
    my @cols = @columns.elems
        ?? @columns
        !! (@normalized.elems ?? @normalized[0].keys.sort !! ());
    Rakuish::Data::Table.new(:columns(@cols), :rows(@normalized), :$types);
}

method elems(--> Int) { @!rows.elems }

# ── 0.64 大结果保护 ─────────────────────────────────────────────────
# batches 是惰性 Seq of Table：调用方可以逐批处理 / 提前退出，不必先把
# 全部批次物化。渲染的 :max-rows 则是展示上限，避免一次拼出巨大字符串。
method batches(Int :$size = 1000 --> Seq) {
    my Int $n = $size max 1;
    @!rows.rotor($n, :partial).map(-> @chunk {
        Rakuish::Data::Table.new(:columns(@!columns), :rows(@chunk),
                                 :types(%!types));
    });
}

method !row-limit($max-rows) {
    $max-rows.defined && $max-rows.Int >= 0 ?? $max-rows.Int !! Nil
}

method !display-rows(:$max-rows --> List) {
    my $n = self!row-limit($max-rows);
    return @!rows.List unless $n.defined;
    return @!rows.List if @!rows.elems <= $n;
    @!rows.head($n).List
}

method !truncation-note(:$max-rows --> Str) {
    my $n = self!row-limit($max-rows);
    ($n.defined && @!rows.elems > $n)
        ?? "\n... 共 {@!rows.elems} 行，只显示前 $n 行"
        !! ''
}

method schema(--> Rakuish::Data::Table) {
    my @rows;
    for @!columns -> $c {
        my Str $name = $c.Str;
        my Bool $nullable = @!rows.elems
            && @!rows.grep({ !$_{$name}.defined }).elems > 0;
        @rows.push({
            name     => $name,
            type     => %!types{$name} // 'any',
            nullable => $nullable,
        });
    }
    Rakuish::Data::Table.new(
        :columns<name type nullable>,
        :rows(@rows),
        :types({ name => 'str', type => 'str', nullable => 'bool' }),
    );
}

# 0.69 / ADR-0006 §3：列级摘要仍是**值**（Table），不是文本报告。
# 与 Engine.describe 返回同样的 name/type/nullable/non_null/distinct/total/sample
# 列集合，方便把「文件读进来的 Table」与「数据库里的表」用同一套代码处理。
method describe(Int :$sample = 3 --> Rakuish::Data::Table) {
    my Int $n = ($sample max 0) min 20;
    my @rows;
    for @!columns -> $c {
        my Str $name = $c.Str;
        my @defined = @!rows.map({ $_{$name} }).grep({ .defined }).List;
        my @distinct = @defined.map(*.Str).unique.List;
        @rows.push({
            name     => $name,
            type     => %!types{$name} // 'any',
            nullable => @defined.elems < @!rows.elems,
            non_null => @defined.elems,
            distinct => @distinct.elems,
            total    => @!rows.elems,
            sample   => @distinct.head($n).join(' | '),
        });
    }
    Rakuish::Data::Table.from-rows(@rows,
        :columns<name type nullable non_null distinct total sample>)
}

method column-type(Str $col --> Str) { %!types{$col} // 'any' }

method limit(Int $n --> Rakuish::Data::Table) {
    my @rows = @!rows.head($n);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method offset(Int $n --> Rakuish::Data::Table) {
    my @rows = @!rows.skip($n).List;
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method each(&f --> List) {
    @!rows.map(&f).List;
}

method count(--> Int) { @!rows.elems }

method !numeric(Str $col --> List) {
    @!rows.map({ $_{$col} })
         .grep({ .defined && $_ ~~ Numeric })
         .map(*.Num)
         .List;
}

method sum(Str $col --> Num) {
    self!numeric($col).sum;
}

method mean(Str $col --> Num) {
    my @v = self!numeric($col);
    @v.elems ?? @v.sum / @v.elems !! 0e0;
}

method min(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? @v.min !! Nil;
}

method max(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? @v.max !! Nil;
}

method distinct(*@cols --> Rakuish::Data::Table) {
    my @keep = @cols.elems ?? @cols.map(*.Str) !! @!columns;
    my @rows;
    my %seen;
    for @!rows -> $row {
        my Str $key = @keep.map({ ($row{$_} // '') ~ "\x[1F]" }).join('');
        next if %seen{$key};
        %seen{$key} = True;
        @rows.push($row);
    }
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method join(Rakuish::Data::Table $other, Str :$on!,
            Str :$left-on = $on, Str :$right-on = $on
            --> Rakuish::Data::Table) {
    my @left = @!rows;
    my @right = $other.rows;
    my %idx;
    for @right -> $r {
        my Str $k = ($r{$right-on} // '').Str;
        %idx{$k} //= [];
        %idx{$k}.push($r);
    }
    my @rows;
    for @left -> $l {
        my Str $k = ($l{$left-on} // '').Str;
        if %idx{$k}:exists {
            for %idx{$k}.List -> $r {
                my %merged = $l.Hash;
                for $r.keys -> $c {
                    my Str $name = $c.Str;
                    $name ~= '_right' if %merged{$name}:exists;
                    %merged{$name} = $r{$c};
                }
                @rows.push(%merged);
            }
        }
        else {
            @rows.push($l.Hash);
        }
    }
    my @cols = @!columns.map(*.Str);
    my %types = %!types;
    for $other.columns -> $c {
        my Str $name = $c.Str;
        $name ~= '_right' if @cols.grep(* eq $name).elems;
        @cols.push($name) unless @cols.grep(* eq $name);
        %types{$name} = $other.column-type($c.Str);
    }
    Rakuish::Data::Table.new(:columns(@cols), :rows(@rows), :types(%types));
}

method where(&pred --> Rakuish::Data::Table) {
    my @rows = @!rows.grep(&pred);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method get(Str $col --> List) {
    @!rows.map({ $_{$col} }).List;
}

method select(*@cols --> Rakuish::Data::Table) {
    my @keep = @cols.map(*.Str);
    my @rows = @!rows.map(-> $row {
        my %r;
        for @keep -> $c { %r{$c} = $row{$c} if $row{$c}:exists }
        %r;
    });
    my %t;
    for @keep -> $c { %t{$c.Str} = %!types{$c.Str} // 'any' }
    Rakuish::Data::Table.new(:columns(@keep), :rows(@rows), :types(%t));
}

method sort-by(Str $col, Bool :$reverse = False --> Rakuish::Data::Table) {
    my @rows = @!rows.sort(-> $a, $b {
        my $av = $a{$col};
        my $bv = $b{$col};
        my $c = ($av.defined ?? $av !! '') cmp ($bv.defined ?? $bv !! '');
        $reverse ?? (($bv.defined ?? $bv !! '') cmp ($av.defined ?? $av !! '')) !! $c;
    });
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method first(Int $n = 1 --> Rakuish::Data::Table) {
    my @rows = @!rows.head($n);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method last(Int $n = 1 --> Rakuish::Data::Table) {
    my @rows = @!rows.tail($n);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method !cell($v --> Str) {
    return '' unless $v.defined;
    given $v {
        when IO::Path { $v.Str }
        when Hash | Positional { JSON::Fast::to-json($v, :!pretty) }
        default { $v.Str }
    }
}

method to-text(:$max-rows --> Str) {
    my @headers = @!columns.map(*.Str);
    return '' unless @headers.elems;
    my @matrix = self!display-rows(:$max-rows).map(-> $row {
        @headers.map({ self!cell($row{$_}) });
    });
    my @widths = @headers.kv.map(-> $i, $h {
        my Int $w = $h.chars;
        for @matrix -> $r { $w = $r[$i].chars if $r[$i].chars > $w }
        $w;
    });
    my Str $line = @widths.map(-> $w { '-' x $w }).join('  ');
    my Str $head = @headers.kv.map(-> $i, $h { $h ~ (' ' x (@widths[$i] - $h.chars)) }).join('  ');
    my @lines = $head, $line;
    for @matrix -> $r {
        @lines.push($r.kv.map(-> $i, $v { $v ~ (' ' x (@widths[$i] - $v.chars)) }).join('  '));
    }
    @lines.join("\n") ~ self!truncation-note(:$max-rows);
}

# JSON 里不能插入「省略」文本，否则不再是合法 JSON：这里只截断行数。
method to-json(Bool :$pretty = False, :$max-rows --> Str) {
    JSON::Fast::to-json(self!display-rows(:$max-rows).Array, :$pretty);
}

method to-markdown(:$max-rows --> Str) {
    my @headers = @!columns.map(*.Str);
    return '' unless @headers.elems;
    my @lines;
    @lines.push('| ' ~ @headers.join(' | ') ~ ' |');
    @lines.push('| ' ~ @headers.map({ '---' }).join(' | ') ~ ' |');
    for self!display-rows(:$max-rows) -> $row {
        @lines.push('| ' ~ @headers.map({ self!cell($row{$_}) }).join(' | ') ~ ' |');
    }
    @lines.join("\n") ~ self!truncation-note(:$max-rows);
}

method gist(--> Str) { self.to-text }
