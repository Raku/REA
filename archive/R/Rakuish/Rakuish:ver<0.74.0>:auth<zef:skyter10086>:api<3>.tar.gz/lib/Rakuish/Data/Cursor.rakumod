unit class Rakuish::Data::Cursor;

# Rakuish::Data::Cursor —— 惰性查询结果（0.67 / ADR-0004 §3）。
#
# 与 0.64 的区别：`Table.batches` 是**已物化 Table** 的分批视图；
# Cursor 持有驱动结果对象，只有被拉取时才向驱动要下一批行。
# 因此 `my @first = $c.batches.head(2)` 不会把整张表读进内存，也不会
# 执行完剩余查询。
#
# 实现说明：刻意不用 gather/take。Cursor.batches / 引擎的 chunks 都曾是
# gather，两层惰性 continuation 跨调用帧会触发
# "continuationreset requires a continuation or a code handle"。
# 这里改用显式 Iterator + fetch 闭包，行为确定、可跨帧恢复。
#
# 一次性、单连接：close 幂等；拉完 / 达到 max-rows / take() 自动 close。
# 提前退出惰性 Seq 时请显式 close（DESTROY 只作兜底，不保证 GC 时机）。

use Rakuish::Data::Table;
use Rakuish::Result;

# 惰性分批视图：pull-one 时才调一次 next-batch。
my class BatchIterator does Iterator {
    has $.cursor is required;
    has $.size;
    method pull-one() {
        my $t = $!cursor.next-batch(:size($!size));
        $t.elems ?? $t !! IterationEnd;
    }
}

# 惰性逐行视图：内部缓冲一批，避免每行都走一次 Table 构造。
my class RowIterator does Iterator {
    has $.cursor is required;
    has @!buffer;
    method pull-one() {
        unless @!buffer.elems {
            my $t = $!cursor.next-batch;
            return IterationEnd unless $t.elems;
            @!buffer = $t.rows;
        }
        @!buffer.elems ?? @!buffer.shift !! IterationEnd;
    }
}

has @.columns;
has Int  $.batch-size = 1000;
has Bool $.closed = False;
has Int  $!fetched = 0;
has      $!fetch;             # Callable：返回一行 Hash，或 Nil 表示结束
has      $!max-rows;
has      $!on-close;
has      $!before-batch;
has Str  $!source = '';

submethod BUILD(:@columns!, :&fetch!, Int :$batch-size = 1000,
                :$max-rows, :$on-close, :$before-batch, Str :$source = '') {
    @!columns      = @columns.List;
    $!batch-size   = $batch-size max 1;
    $!fetch        = &fetch;
    $!max-rows     = $max-rows.defined ?? $max-rows.Int !! Nil;
    $!on-close     = $on-close;
    $!before-batch = $before-batch;
    $!source       = $source;
    $!closed       = False;
    $!fetched      = 0;
}

method !empty(--> Rakuish::Data::Table) {
    Rakuish::Data::Table.new(:columns(@!columns), :rows([]));
}

# 拉下一批。返回空 Table 表示结束；结束或达到上限时自动 close。
method next-batch(Int :$size --> Rakuish::Data::Table) {
    CATCH { default {
        self.close;
        .throw if $_ ~~ X::Rakuish::V3;   # 只读 / 沙箱 / 超时原样抛
        X::Rakuish::Data.new(
            :detail('游标读取失败: ' ~ .message.chomp)
        ).throw;
    } }

    return self!empty if $!closed;
    $!before-batch.() if $!before-batch.defined;   # SQLite 超时检查挂这里

    my Int $want = (($size.defined ?? $size.Int !! $!batch-size) max 1);
    if $!max-rows.defined {
        my Int $left = $!max-rows - $!fetched;
        $want = $left if $left < $want;
    }
    if $want <= 0 {
        self.close;
        return self!empty;
    }

    my @rows;
    while @rows.elems < $want {
        my $v = $!fetch.();
        last unless $v.defined;          # Nil = 驱动已耗尽
        @rows.push($v);
    }
    $!fetched += @rows.elems;
    self.close if @rows.elems < $want
                  || ($!max-rows.defined && $!fetched >= $!max-rows);

    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows));
}

# 惰性 Seq of Table：消费到哪一批，查询就走到哪一批。
method batches(Int :$size --> Seq) {
    Seq.new(BatchIterator.new(:cursor(self), :$size));
}

# 惰性 Seq of Hash（逐行）。
method rows(--> Seq) {
    Seq.new(RowIterator.new(:cursor(self)));
}

# 只要前 N 行：取够立即 close，不给驱动继续跑的机会。
method take(Int $n = 1 --> Rakuish::Data::Table) {
    my Int $want = $n max 0;
    $want = $!max-rows if $!max-rows.defined && $want > $!max-rows;
    my @rows;
    while @rows.elems < $want && !$!closed {
        my $t = self.next-batch(:size($want - @rows.elems));
        last unless $t.elems;
        @rows.append($t.rows);
    }
    self.close;
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows));
}

method close(--> Nil) {
    return if $!closed;
    $!closed = True;
    try { $!on-close.() } if $!on-close.defined;
    Nil
}

method eof(--> Bool)       { $!closed }
method fetched(--> Int)    { $!fetched }
method max-rows            { $!max-rows }
method source(--> Str)     { $!source }
method gist(--> Str) {
    'Cursor[' ~ @!columns.join(',') ~ '] fetched=' ~ $!fetched
        ~ ' closed=' ~ $!closed ~ ($!source.chars ?? " ($!source)" !! '');
}

submethod DESTROY { try { self.close } }
