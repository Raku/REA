use Rakuish::Data::Engine;
use Rakuish::Data::Table;
use Rakuish::Data::Cursor;
use Rakuish::Result;
use NativeCall;

sub sqlite3_interrupt(Pointer) is native('sqlite3') {*}

unit class Rakuish::Data::Engine::SQLite does Rakuish::Data::Engine;

# SQLite 适配器：适合应用状态/小表，不做大分析。
# DB::SQLite 同样是运行时可选依赖；默认只读，写操作显式 :!read-only。

has Str  $.path = ':memory:';
has Bool $.read-only = True;
has Bool $.safe = True;
has Int  $.busy-timeout = 10_000;
has Int  $.max-execution-time-ms = 0;
has      $!db;
has      $!conn;

submethod TWEAK() {
    my $mod = try { require ::('DB::SQLite') };
    my Bool $loaded = try { $mod.^name eq 'DB::SQLite' } // False;
    X::Rakuish::Unsupported.new(
        :detail('SQLite 引擎未安装；请先 zef install DB::SQLite')
    ).throw unless $loaded;
    $!db = $mod.new(:filename($!path), :$!busy-timeout);
    # 固定一个连接：SQLite 的 :memory: 是 per-connection 的，不能走池。
    $!conn = $!db.connect;
    # 词法只读判据只是第一道门；连接级 query_only 才是数据库层的保证。
    try { $!conn.execute('PRAGMA query_only = ON') } if $!read-only;
}

method !sql-code(Str $sql --> Str) {
    # 只读判定只看代码，不看注释/字符串里的关键字；避免
    # `select 'copy' as x`、`select 1 /* drop */` 被误拒。
    my Str $s = $sql;
    my Str $out = '';
    my Str $quote = '';
    my Int $i = 0;
    while $i < $s.chars {
        my Str $c = $s.substr($i, 1);
        my Str $next = $i + 1 < $s.chars ?? $s.substr($i + 1, 1) !! '';
        if $quote ne '' {
            if $c eq $quote {
                if $next eq $quote { $i += 2; next }
                $quote = '';
            }
            $i++;
            next;
        }
        if $c eq "'" || $c eq '"' || $c eq '`' {
            $quote = $c;
            $out ~= ' ';
            $i++;
            next;
        }
        if $c eq '-' && $next eq '-' {
            $i += 2;
            $i++ while $i < $s.chars && $s.substr($i, 1) ne "\n";
            next;
        }
        if $c eq '/' && $next eq '*' {
            $i += 2;
            while $i + 1 < $s.chars
                  && !($s.substr($i, 1) eq '*' && $s.substr($i + 1, 1) eq '/') {
                $i++;
            }
            $i += 2;
            next;
        }
        $out ~= $c;
        $i++;
    }
    $out;
}

method !read-query(Str $sql --> Bool) {
    my Str $s = self!sql-code($sql).trim.lc;
    return False if $s ~~ /<?wb>(insert|update|delete|create|drop|alter|attach|detach|pragma\s+query_only)<?wb>/;
    # schema() 用的是只读的 pragma table_info；只放行元数据类 pragma。
    so $s ~~ /^ (select|with|show|explain|values|pragma\s+(table_info|table_xinfo|table_list|index_list|index_info|foreign_key_list))<?wb>/;
}

method query(Str $sql, *@params, Int :$max-rows --> Rakuish::Data::Table) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;
        X::Rakuish::Data.new(
            :detail('SQLite query 失败: ' ~ .message.chomp)
        ).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('只读 SQLite 引擎只允许 SELECT/WITH/EXPLAIN')
    ).throw if $!read-only && !self!read-query($sql);

    # LIMIT 下推（0.64 大结果保护）；不传 :max-rows 时 SQL 与参数完全不变。
    my Str $stmt = $sql;
    my @args = @params;
    if $max-rows.defined && $max-rows >= 0 {
        my Str $inner = $sql.trim.subst(/ ';' \s* $ /, '');
        $stmt = "select * from ($inner) as __rakuish_limited limit ?";
        @args.push($max-rows);
    }

    my Bool $done = False;
    my Bool $interrupted = False;
    my $watchdog;
    if $!max-execution-time-ms > 0 {
        my Instant $started = now;
        $watchdog = start {
            while !$done {
                sleep 0.005;
                next if $done;
                if (now - $started) > ($!max-execution-time-ms / 1000) {
                    $interrupted = True;
                    try sqlite3_interrupt($!conn.conn);
                    last;
                }
            }
        };
    }

    my $res;
    my @columns;
    my @rows;
    my $failure;
    {
        CATCH { default { $failure = $_ } }
        $res = @args.elems
            ?? $!conn.prepare($stmt).execute(|@args)
            !! $!conn.query($stmt);
        @columns = $res.keys.List;
        @rows = $res.hashes.List;
    }
    $done = True;

    X::Rakuish::Limit.new(
        :detail("SQLite 查询超时: {$!max-execution-time-ms}ms")
    ).throw if $interrupted;
    $failure.throw if $failure.defined;
    Rakuish::Data::Table.new(:columns(@columns), :rows(@rows));
}

# ── 流式游标（0.67 / ADR-0004 §3）───────────────────────────────────
# SQLite 的 Result.hash 是逐行 sqlite3_step；gather 不预取，
# 只在 Cursor 拉下一批时才前进。超时检查挂在每批之前（before-batch）。
method cursor(Str $sql, *@params, Int :$batch-size = 1000,
              Int :$max-rows --> Rakuish::Data::Cursor) {
    X::Rakuish::Unsupported.new(
        :detail('只读 SQLite 引擎只允许 SELECT/WITH/EXPLAIN')
    ).throw if $!read-only && !self!read-query($sql);

    my Str $stmt = $sql;
    my @args = @params;
    if $max-rows.defined && $max-rows >= 0 {
        my Str $inner = $sql.trim.subst(/ ';' \s* $ /, '');
        $stmt = "select * from ($inner) as __rakuish_limited limit ?";
        @args.push($max-rows);
    }

    my $res;
    {
        CATCH { default {
            .throw if $_ ~~ X::Rakuish::V3;
            X::Rakuish::Data.new(
                :detail('SQLite cursor 失败: ' ~ .message.chomp)
            ).throw;
        } }
        $res = @args.elems
            ?? $!conn.prepare($stmt).execute(|@args)
            !! $!conn.query($stmt);
    }
    my @columns = $res.keys.List;

    my Instant $t0 = now;
    my Int $limit-ms = $!max-execution-time-ms;
    my &before-batch = -> {
        if $limit-ms > 0 && ((now - $t0) * 1000) > $limit-ms {
            try sqlite3_interrupt($!conn.conn);
            X::Rakuish::Limit.new(
                :detail("SQLite 游标超时: {$limit-ms}ms")
            ).throw;
        }
    };

    my &fetch = -> {
        CATCH { default {
            .throw if $_ ~~ X::Rakuish::V3;
            X::Rakuish::Data.new(
                :detail('SQLite 游标读取失败: ' ~ .message.chomp)
            ).throw;
        } }
        my $h = $res.hash;
        # pointy block 不是 Routine，不能用 return；用三元表达式收尾。
        ($h ~~ IterationEnd || !$h.defined || !$h.elems)
            ?? Nil
            !! ($h<>).Hash
    };

    Rakuish::Data::Cursor.new(
        :@columns, :fetch(&fetch), :$batch-size, :$max-rows,
        :source<SQLite>, :before-batch(&before-batch),
        :on-close(-> { try { $res.finish } }),
    );
}

method execute(Str $sql, *@params --> Int) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;
        X::Rakuish::Data.new(
            :detail('SQLite execute 失败: ' ~ .message.chomp)
        ).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('只读 SQLite 引擎不允许 execute；请用 :!read-only 新建引擎')
    ).throw if $!read-only;
    @params.elems
        ?? $!conn.prepare($sql).execute(|@params)
        !! $!conn.execute($sql);
}

method begin() {
    X::Rakuish::Unsupported.new(
        :detail('只读 SQLite 引擎不允许事务')
    ).throw if $!read-only;
    $!conn.begin;
}

method commit() {
    X::Rakuish::Unsupported.new(
        :detail('只读 SQLite 引擎不允许事务')
    ).throw if $!read-only;
    $!conn.commit;
}

method rollback() {
    X::Rakuish::Unsupported.new(
        :detail('只读 SQLite 引擎不允许事务')
    ).throw if $!read-only;
    $!conn.rollback;
}

method tables(--> Rakuish::Data::Table) {
    self.query("select name from sqlite_master where type = 'table' order by name");
}

method schema(Str $table --> Rakuish::Data::Table) {
    my Str $safe-name = $table.subst("'", "''", :g);
    self.query("pragma table_info('{$safe-name}')");
}

method close(--> Nil) {
    $!db.finish if $!db.defined;
    $!db = Nil;
}
