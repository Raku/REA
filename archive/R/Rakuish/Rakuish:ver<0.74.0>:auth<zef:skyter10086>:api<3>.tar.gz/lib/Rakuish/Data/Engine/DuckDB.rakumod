use Rakuish::Data::Engine;
use Rakuish::Data::Table;
use Rakuish::Data::Cursor;
use Rakuish::Data::CsvOptions;
use Rakuish::Result;

unit class Rakuish::Data::Engine::DuckDB does Rakuish::Data::Engine;

# DuckDB 适配器：默认只读、禁止外部文件访问；DB::DuckDB 是运行时可选依赖。
#
# 不在这里 `use DB::DuckDB`：核心 rakuish 安装不应被 DuckDB 的 NativeCall
# 库拖住。第一次 new 时才 require；缺失时给出明确安装提示。

has Str  $.path = ':memory:';
has Bool $.read-only = True;
has Bool $.safe = True;
has Int  $.threads;
has Str  $.memory-limit;
has Int  $.max-execution-time-ms = 0;
has      $!db;

submethod TWEAK() {
    my $mod = try { require ::('DB::DuckDB') };
    my Bool $loaded = try { $mod.^name eq 'DB::DuckDB' } // False;
    X::Rakuish::Unsupported.new(
        :detail('DuckDB 引擎未安装；请先 zef install DB::DuckDB（它依赖 Alien::Libduckdb）')
    ).throw unless $loaded;

    my %opts;
    # DuckDB 的外部访问是绕过 Sys root 的主要入口；默认关闭。
    %opts<enable_external_access> = 'false' if $!safe;
    %opts<max_execution_time> = $!max-execution-time-ms
        if $!max-execution-time-ms > 0;

    $!db = $mod.new(
        :$!path,
        :$!threads,
        :$!memory-limit,
        :session-options(%opts),
    );
}

method !sql-code(Str $sql --> Str) {
    my Str $s = $sql;
    my Str $out = '';
    my Str $quote = '';
    my Int $i = 0;
    while $i < $s.chars {
        my Str $c = $s.substr($i, 1);
        my Str $next = $i + 1 < $s.chars ?? $s.substr($i + 1, 1) !! '';
        if $quote ne '' {
            if $c eq $quote {
                if $next eq $quote { $i += 2; next }
                $quote = '';
            }
            $i++;
            next;
        }
        if $c eq "'" || $c eq '"' || $c eq '`' {
            $quote = $c;
            $out ~= ' ';
            $i++;
            next;
        }
        if $c eq '-' && $next eq '-' {
            $i += 2;
            $i++ while $i < $s.chars && $s.substr($i, 1) ne "\n";
            next;
        }
        if $c eq '/' && $next eq '*' {
            $i += 2;
            while $i + 1 < $s.chars
                  && !($s.substr($i, 1) eq '*' && $s.substr($i + 1, 1) eq '/') {
                $i++;
            }
            $i += 2;
            next;
        }
        $out ~= $c;
        $i++;
    }
    $out;
}

method !read-query(Str $sql --> Bool) {
    my Str $s = self!sql-code($sql).trim.lc;
    return False if $s ~~ /<?wb>(insert|update|delete|copy|create|drop|alter|attach|detach|install|load)<?wb>/;
    so $s ~~ /^ (select|with|show|describe|pragma|explain|values)<?wb>/;
}

method query(Str $sql, *@params, Int :$max-rows --> Rakuish::Data::Table) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;   # 自己的异常族原样抛（只读 / 沙箱 / 限制）
        X::Rakuish::Data.new(
            :detail('DuckDB query 失败: ' ~ .message.chomp)
        ).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎只允许 SELECT/SHOW/DESCRIBE/EXPLAIN')
    ).throw if $!read-only && !self!read-query($sql);

    # LIMIT 下推：在物化之前截断，不让大结果一次进内存。
    my Str $stmt = $sql;
    my @args = @params;
    if $max-rows.defined && $max-rows >= 0 {
        # 用户 SQL 常带尾分号；包成子查询前必须去掉，否则 Parser Error。
        my Str $inner = $sql.trim.subst(/ ';' \s* $ /, '');
        $stmt = "select * from ($inner) as __rakuish_limited limit ?";
        @args.push($max-rows);
    }
    my $res = $!db.query($stmt, |@args);
    my @columns = $res.keys.List;
    my @rows = $res.hashes.List;
    Rakuish::Data::Table.new(:columns(@columns), :rows(@rows));
}

# ── 流式游标（0.67 / ADR-0004 §3）───────────────────────────────────
# :stream 让 DB::DuckDB 一次只持有一个 data chunk，chunks 是惰性 Seq；
# 拉到哪一批，查询才走到哪一批。构造 Cursor 时绝不调用 .hashes 物化。
method cursor(Str $sql, *@params, Int :$batch-size = 1000,
              Int :$max-rows --> Rakuish::Data::Cursor) {
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎只允许 SELECT/SHOW/DESCRIBE/EXPLAIN')
    ).throw if $!read-only && !self!read-query($sql);

    my Str $stmt = $sql;
    my @args = @params;
    if $max-rows.defined && $max-rows >= 0 {
        # 用户 SQL 常带尾分号；包成子查询前必须去掉，否则 Parser Error。
        my Str $inner = $sql.trim.subst(/ ';' \s* $ /, '');
        $stmt = "select * from ($inner) as __rakuish_limited limit ?";
        @args.push($max-rows);
    }

    my $res;
    {
        CATCH { default {
            .throw if $_ ~~ X::Rakuish::V3;
            X::Rakuish::Data.new(
                :detail('DuckDB cursor 失败: ' ~ .message.chomp)
            ).throw;
        } }
        $res = $!db.query($stmt, |@args, :stream);
    }
    my @columns = $res.keys.List;

    # fetch 闭包：一次 pull-one 只推进一个驱动 chunk，转成 Hash 后立刻
    # 放进缓冲（chunk 在下次 pull 时会失效，不能跨 chunk 持有视图）。
    my $chunks = $res.chunks.iterator;
    my @pending;
    my &fetch = -> {
        CATCH { default {
            .throw if $_ ~~ X::Rakuish::V3;
            X::Rakuish::Data.new(
                :detail('DuckDB 游标读取失败: ' ~ .message.chomp)
            ).throw;
        } }
        unless @pending.elems {
            my $chunk = $chunks.pull-one;
            # IterationEnd 是 Mu 实例（defined=True），且被 Scalar 容器包裹时
            # `=:=` 会失效；实测 `~~ IterationEnd` 才是可靠判定。
            unless $chunk ~~ IterationEnd {
                for $chunk.to-rows -> $r {
                    my @r = $r.List;
                    my %row;
                    for @columns.kv -> $j, $name { %row{$name} = @r[$j] }
                    @pending.push(%row);
                }
            }
        }
        # pointy block 不是 Routine，不能用 return；末尾表达式即返回值。
        @pending.elems ?? @pending.shift !! Nil
    };

    Rakuish::Data::Cursor.new(
        :@columns, :fetch(&fetch), :$batch-size, :$max-rows,
        :source<DuckDB>,
        :on-close(-> { try { $res.finish }; try { $res.free } }),
    );
}

method execute(Str $sql, *@params --> Int) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;
        X::Rakuish::Data.new(
            :detail('DuckDB execute 失败: ' ~ .message.chomp)
        ).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎不允许 execute；请用 :!read-only 新建引擎')
    ).throw if $!read-only;
    $!db.execute($sql, |@params);
}

method begin() {
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎不允许事务')
    ).throw if $!read-only;
    $!db.session.begin;
}

method commit() {
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎不允许事务')
    ).throw if $!read-only;
    $!db.session.commit;
}

method rollback() {
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎不允许事务')
    ).throw if $!read-only;
    $!db.session.rollback;
}

method tables(--> Rakuish::Data::Table) {
    self.query('show tables');
}

method schema(Str $table --> Rakuish::Data::Table) {
    my Str $safe-name = $table.subst('"', '""', :g);
    self.query(qq{DESCRIBE SELECT * FROM "$safe-name"});
}

method close(--> Nil) {
    $!db.close if $!db.defined;
    $!db = Nil;
}

# ── CSV 外部读写（0.68 / ADR-0005 §2）─────────────────────────────────
# 与 Parquet 共用授权模型：只有 :!safe 的受控引擎可以调用，路径由调用方
# 经 Sys.resolve 校验过。read_csv_auto 让 DuckDB 做类型推断，不再由 Raku
# 手写解析器把一切当字符串。
# :%csv-options 是 0.69 的白名单方言（ADR-0006 §2）。空选项时 clause 为空、
# COPY 选项仍是 (FORMAT CSV, HEADER)，与 0.68 逐字一致。
method read-csv(Str $path, :%csv-options = {},
                Int :$max-rows --> Rakuish::Data::Table) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;
        X::Rakuish::Data.new(:detail('CSV 读取失败: ' ~ .message.chomp)).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('CSV 读取需要显式允许外部访问（:!safe / open-data :allow-external）')
    ).throw if $!safe;
    X::Rakuish::Sandbox.new(:detail('CSV 路径不能为空')).throw unless $path.chars;
    my %dialect = csv-read-clause(%csv-options);
    my Str $sql = 'select * from read_csv_auto(?' ~ %dialect<clause> ~ ')';
    my @args = ($path, |%dialect<values>.List);
    return self.query($sql, |@args) unless $max-rows.defined;
    self.query($sql, |@args, :max-rows($max-rows))
}

method write-csv(Str $path, Str $sql, :%csv-options = {} --> Int) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;
        X::Rakuish::Data.new(:detail('CSV 导出失败: ' ~ .message.chomp)).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('CSV 写入需要显式允许外部访问（:!safe）')
    ).throw if $!safe;
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎不允许写 CSV；请用 :!read-only')
    ).throw if $!read-only;
    X::Rakuish::Data.new(
        :detail('CSV 导出 SQL 不允许包含分号')
    ).throw if $sql.contains(';');
    my Str $opts = csv-write-options(%csv-options);
    my Str $esc = $path.subst("'", "''", :g);
    $!db.execute("COPY ($sql) TO '$esc' $opts");
    0
}

# ── Parquet（0.64）───────────────────────────────────────────────────
# 只有显式 :!safe 才允许 DuckDB 触碰文件；$path 必须是调用方经 Sys.resolve
# 校验过的绝对路径（引擎自身不碰 Sys，也不替 Agent 开放外部访问）。
method read-parquet(Str $path, Int :$max-rows --> Rakuish::Data::Table) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;
        X::Rakuish::Data.new(:detail('Parquet 读取失败: ' ~ .message.chomp)).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('Parquet 读取需要显式允许外部访问（:!safe / open-data :allow-external）')
    ).throw if $!safe;
    X::Rakuish::Sandbox.new(:detail('Parquet 路径不能为空')).throw unless $path.chars;
    return self.query('select * from read_parquet(?)', $path)
        unless $max-rows.defined;
    self.query('select * from read_parquet(?)', $path, :max-rows($max-rows))
}

method write-parquet(Str $path, Str $sql --> Int) {
    CATCH { default {
        .throw if $_ ~~ X::Rakuish::V3;
        X::Rakuish::Data.new(:detail('Parquet 导出失败: ' ~ .message.chomp)).throw;
    } }
    X::Rakuish::Unsupported.new(
        :detail('Parquet 写入需要显式允许外部访问（:!safe）')
    ).throw if $!safe;
    X::Rakuish::Unsupported.new(
        :detail('只读 DuckDB 引擎不允许写 Parquet；请用 :!read-only')
    ).throw if $!read-only;
    X::Rakuish::Data.new(
        :detail('Parquet 导出 SQL 不允许包含分号')
    ).throw if $sql.contains(';');
    my Str $esc = $path.subst("'", "''", :g);
    $!db.execute("COPY ($sql) TO '$esc' (FORMAT PARQUET)");
    0
}
