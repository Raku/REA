unit module Rakuish::Data::CsvOptions;

# Rakuish::Data::CsvOptions —— CSV 方言选项的白名单与 SQL 翻译（0.69 / ADR-0006 §2）。
#
# 纯函数：无文件 I/O、无进程、不碰 Sys。只有调用方显式 :allow-external 时
# 才会用到；默认 .csv 仍走 Sys.read/write + Raku 解析器（V-129）。
#
# 两条安全线：
#   1. 读路径 read_csv_auto(?, opt => ?, ...) 一律用 ? 绑定，值不进 SQL 字符串；
#   2. 写路径 COPY ... (...) 的选项不支持绑定，只能拼字面量，因此这里先做
#      严格字符校验（单字符 / 短字符串 / 不含引号、分号、反斜杠、换行）。
# 选项名全部来自下表常量，用户不能注入任意标识符。

use Rakuish::Result;

# 固定顺序保证生成的 SQL 稳定可测；kind 决定校验规则。
my @ORDER = <delimiter quote escape nullstr header skip all-varchar>;
my %SPEC = (
    'delimiter'   => { sql => 'delim',        kind => 'char',  write => True  },
    'quote'       => { sql => 'quote',        kind => 'char',  write => True  },
    'escape'      => { sql => 'escape',       kind => 'char',  write => True  },
    'nullstr'     => { sql => 'nullstr',      kind => 'text',  write => True  },
    'header'      => { sql => 'header',       kind => 'bool',  write => True  },
    'skip'        => { sql => 'skip',         kind => 'int',   write => False },
    'all-varchar' => { sql => 'all_varchar',  kind => 'bool',  write => False },
);

our sub csv-option-names(--> List) is export { @ORDER.List }

# 字面量里绝不接受的字符：单引号（会截断 COPY 选项）、反斜杠、换行、NUL。
# 分号不禁用：它是合法分隔符，且只出现在引号内的字面量 / 绑定值里，
# 不会终止语句（读路径全部 ? 绑定，写路径在 '...' 中）。
sub unsafe-chars(Str $s --> Bool) {
    so $s.ords.first(-> $o { $o == 39 || $o == 92
                             || $o == 10 || $o == 13 || $o == 0 }, :k).defined
}

sub validate(Str $key, $v) {
    my %spec = %SPEC{$key};
    given %spec<kind> {
        when 'char' {
            X::Rakuish::Unsupported.new(
                :detail("CSV 选项 $key 需要单个可打印 ASCII 字符")
            ).throw unless $v ~~ Str && $v.chars == 1
                          && $v.ord >= 32 && $v.ord <= 126;
            X::Rakuish::Unsupported.new(
                :detail("CSV 选项 $key 不能是引号 / 分号 / 反斜杠")
            ).throw if unsafe-chars($v);
            $v.Str
        }
        when 'text' {
            X::Rakuish::Unsupported.new(
                :detail("CSV 选项 $key 需要长度 ≤ 64 的字符串")
            ).throw unless $v ~~ Str && $v.chars <= 64;
            X::Rakuish::Unsupported.new(
                :detail("CSV 选项 $key 含不允许的字符")
            ).throw if unsafe-chars($v);
            $v.Str
        }
        when 'bool' {
            X::Rakuish::Unsupported.new(
                :detail("CSV 选项 $key 需要 Bool（True / False）")
            ).throw unless $v ~~ Bool;
            $v
        }
        when 'int' {
            X::Rakuish::Unsupported.new(
                :detail("CSV 选项 $key 需要 0..100000 的整数")
            ).throw unless $v ~~ Int && $v >= 0 && $v <= 100000;
            $v.Int
        }
        default { $v }
    }
}

# 返回 List of Pair：key 是 DuckDB 选项名，value 是校验过的 Raku 值。
# 顺序按 @ORDER 固定，未知键明确抛异常而不是静默忽略。
our sub normalize-csv-options(%opts --> List) is export {
    my @unknown = %opts.keys.grep({ !(%SPEC{$_}:exists) }).sort;
    X::Rakuish::Unsupported.new(
        :detail('未知 CSV 选项: ' ~ @unknown.join(', ')
                ~ '；可用: ' ~ @ORDER.join(', '))
    ).throw if @unknown.elems;

    my @pairs;
    for @ORDER -> $key {
        next unless %opts{$key}:exists;
        @pairs.push(%SPEC{$key}<sql> => validate($key, %opts{$key}));
    }
    @pairs.List
}

# 读：生成 ", delim => ?, header => ?" 片段与对应绑定值。
# 调用方把片段接在 read_csv_auto(?) 的第一个 ? 之后，并把 values 追加到参数表。
our sub csv-read-clause(%opts --> Hash) is export {
    my @pairs = normalize-csv-options(%opts);
    my Str $clause = @pairs.map({ ', ' ~ .key ~ ' => ?' }).join('');
    my @values = @pairs.map(*.value);
    %( :$clause, values => @values.List )
}

# 写：生成 COPY 的完整括号选项列表（含 FORMAT CSV）。
# 空选项时与 0.68 完全一致： (FORMAT CSV, HEADER)
our sub csv-write-options(%opts --> Str) is export {
    my @pairs = normalize-csv-options(%opts);
    my @parts = 'FORMAT CSV';
    my Bool $header-seen = False;

    for @pairs -> $p {
        my Str $name = $p.key.lc;
        my $v = $p.value;
        given $name {
            when 'header' {
                @parts.push($v ?? 'HEADER' !! 'HEADER false');
                $header-seen = True;
            }
            when 'delim' {
                @parts.push("DELIMITER '" ~ $v ~ "'");
            }
            when 'quote' {
                @parts.push("QUOTE '" ~ $v ~ "'");
            }
            when 'escape' {
                @parts.push("ESCAPE '" ~ $v ~ "'");
            }
            when 'nullstr' {
                @parts.push("NULL '" ~ $v ~ "'");
            }
            default {
                # skip / all_varchar 对 COPY 没有意义：明确拒绝，不假装生效。
                X::Rakuish::Unsupported.new(
                    :detail("CSV 写出不支持选项 $name（仅读取可用）")
                ).throw;
            }
        }
    }
    @parts.push('HEADER') unless $header-seen;
    '(' ~ @parts.join(', ') ~ ')'
}
