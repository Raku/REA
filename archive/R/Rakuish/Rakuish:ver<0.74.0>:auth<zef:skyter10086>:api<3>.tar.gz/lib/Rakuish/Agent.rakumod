unit class Rakuish::Agent;

# Rakuish::Agent —— 类型化 op 处理器（设计 §6.1 / §6.2）。
#
# 一个 Agent 实例 = 一个会话 = 一个 Sys，cwd / env 互不串（设计 §6.2）。
# 本类**不碰网络**：handle() 收结构化请求、返回结构化响应；传输层在
# Agent::Server（JSONL / TCP）。这样安全策略与协议都能在不起 socket 的情况下验收。
#
# 请求：{"id":1,"token":"...","op":"read_file","path":"a.txt","max_bytes":1024}
# 响应：{"id":1,"ok":true,"code":0,"op":"read_file","value":"...","elapsed_ms":3}
#
# 刻意的安全收紧（相对设计 §6.1 的字段表）：
#   · 不开放 eval op —— 任意 Raku 代码会绕过 root / allowlist / 审计；
#   · exec 的 cwd 必须过 Sys.resolve 的 root 校验，不直接交给 Proc；
#   · exec 拒绝请求级覆盖 PATH —— 否则白名单里的 `git` 会被 PATH 指向任意程序；
#   · 审计只记 op / path / argv / 结果，不记 token 与文件内容。

use JSON::Fast;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Result::Renderer;
use Rakuish::Command;
use Rakuish::Sandbox;

has Rakuish::Sandbox $.sandbox is required;
has Rakuish::Sys $.sys;
has CommandRegistry $.commands;
has $.engine;                    # 可选数据引擎（只读 SQL）
has Str $.session-id = 'default';

submethod TWEAK() {
    $!sys = Rakuish::Sys.new(
        :root($!sandbox.root), :cwd($!sandbox.root),
        :max-bytes($!sandbox.max-bytes),
    ) unless $!sys.defined;
    $!commands = default-registry() unless $!commands.defined;
}

method token(--> Str) { $!sandbox.token }

method !token-ok($t --> Bool) {
    $t.defined && $t.Str eq $!sandbox.token
}

# ── 单行 JSONL 协议（纯逻辑，便于测试与 stdin/stdout 复用）────────────
method handle-line(Str $line --> Str) {
    my $id = 0;
    my Str $op = '';
    my Instant $t0 = now;
    my %r;
    {
        CATCH { default {
            %r = self!reply({ id => $id, op => $op }, :!ok, :code(400),
                            :err('请求解析失败: ' ~ .message), :$t0);
        } }
        my %req = from-json($line);
        $id = %req<id> // 0;
        $op = (%req<op> // '').Str;
        %r = self.handle(%req, :$t0);
    }
    to-json(%r, :!pretty)
}

# ── 主流程：认证 → 策略 → 分派 → 审计 → 响应 ─────────────────────────
method handle(%req, Instant :$t0 = now --> Hash) {
    my $id = %req<id> // 0;
    my Str $op = (%req<op> // '').Str;
    my %base = (id => $id, op => $op);
    my Instant $deadline = $!sandbox.request-timeout-ms > 0
        ?? now + ($!sandbox.request-timeout-ms / 1000)
        !! Instant;

    unless self!token-ok(%req<token>) {
        my %r = self!reply(%base, :!ok, :code(401),
                           :err('token 缺失或无效'), :$t0);
        self!audit($op, %req, %r, 'auth');
        return %r;
    }

    my $policy = $!sandbox.authorize($op, %req);
    unless $policy.ok {
        my %r = self!reply(%base, :!ok, :code($policy.code),
                           :err($policy.err), :$t0);
        self!audit($op, %req, %r, 'policy');
        return %r;
    }

    # 请求执行搬到独立任务（ADR-0002 §3.3）：deadline 到点立即回 504，
    # 连接不再被一个卡住的 op 占住。exec / SQL 的底层超时仍按 V-148 压进
    # 参数，它们会真的被终止；纯文件 I/O 这类不可取消操作跑完后结果直接丢弃
    # （Raku 线程无法强杀，这个边界写在 ADR-0002 §2，不假装解决）。
    my $job = start { self!dispatch($op, %req) };
    if $deadline.defined {
        my $remaining = ($deadline - now).Num;
        $remaining = 0e0 if $remaining < 0;
        await Promise.anyof($job, Promise.in($remaining));
    }
    else {
        try { await $job };
    }

    if $job.status ~~ Broken {
        my Str $msg = (try { $job.cause.message } // 'unknown').Str;
        my %r = self!reply(%base, :!ok, :code(500),
                           :err("请求执行异常: $msg"), :$t0);
        self!audit($op, %req, %r, 'op');
        return %r;
    }
    if $job.status !~~ Kept {
        my %r = self!reply(%base, :!ok, :code(504),
                           :err('request timeout'), :$t0);
        self!audit($op, %req, %r, 'timeout');
        return %r;
    }

    my %d = $job.result;
    my %r = self!reply(%base,
                       :ok(%d<ok>), :code(%d<code>),
                       :err(%d<err> // ''), :out(%d<out> // ''),
                       :value(%d<value>), :$t0);
    self!audit($op, %req, %r, 'op');
    %r
}

method !reply(%base, Bool :$ok, Int :$code, Str :$err = '',
              Str :$out = '', :$value, Instant :$t0 --> Hash) {
    my %r = %base;
    %r<ok>   = $ok;
    %r<code> = $code;
    %r<err>  = $err;
    %r<out>  = $out if $out.chars;
    %r<value> = $value if $value.defined;
    %r<elapsed_ms> = ((now - $t0) * 1000).Int;
    %r
}

method !audit(Str $op, %req, %r, Str $stage --> Nil) {
    my %e = session => $!session-id, op => $op, stage => $stage,
            ok => %r<ok>, code => %r<code>;
    %e<path> = %req<path>.Str if %req<path>.defined;
    %e<argv> = %req<argv>.map(*.Str).List
        if $op eq 'exec' && %req<argv>.defined;
    if $op eq 'sql_query' && %req<sql>.defined {
        %e<sql-fingerprint> = self!sql-fingerprint(%req<sql>.Str);
        %e<sql-params> = (%req<params> // ()).elems;
    }
    %e<err>  = %r<err> if %r<err>.chars;
    $!sandbox.audit(%e);   # 绝不传 token / content / SQL 原文
    Nil
}

method !sql-fingerprint(Str $sql --> Str) {
    # FNV-1a：审计只需稳定指纹，不引入额外加密依赖。
    my uint64 $h = 1469598103934665603;
    for $sql.encode('utf-8').list -> uint8 $b {
        $h = (($h +^ $b) * 1099511628211) +& 0xFFFFFFFFFFFFFFFF;
    }
    $h.base(16);
}

# ── 值转成纯 JSON：复用 Result::Renderer，避免两套路径/嵌套规则漂移 ──
method !json-value($v) {
    Rakuish::Result::Renderer::json-value($v);
}

method !dispatch(Str $op, %req --> Hash) {
    my $r = $!sys.try-op($op, { self!run-op($op, %req) });
    my %d = ok => $r.ok, code => $r.ok ?? 0 !! 500, err => $r.err;
    if $r.ok {
        my $v = $r.value;
        if ($v ~~ Result) {
            # exec / rm / cp / mv / mkdir 本身返回 Result：透传 ok/code/out/err，
            # 不能让外层 try-op 把子进程的失败伪装成成功（Phase 3 同类坑）。
            %d<ok>   = $v.ok;
            %d<code> = $v.ok ?? 0 !! ($v.code || 500);
            %d<err>  = $v.err;
            %d<out>  = $v.out if $v.out.chars;
            %d<value> = self!json-value($v.value) if $v.value.defined;
        }
        else {
            %d<value> = self!json-value($v) if $v.defined;
            %d<out>   = $r.out if $r.out.chars;
        }
    }
    %d
}

# ── 结构化 op → Sys 方法（唯一映射处）────────────────────────────────
method !run-op(Str $op, %req) {
    my Str $path = (%req<path> // '').Str;
    my $sys = $!sys;

    given $op {
        when 'read_file' | 'read' {
            X::Rakuish::Unsupported.new(:detail('read_file 需要 path')).throw
                unless $path.chars;
            my %o = :max-bytes($!sandbox.clamp-bytes(%req<max_bytes>)),
                    :enc((%req<encoding> // 'utf-8').Str);
            %o<bin>    = True if %req<binary>;
            %o<offset> = %req<offset>.Int if %req<offset>.defined;
            %o<limit>  = %req<limit>.Int  if %req<limit>.defined;
            $sys.read($path, |%o);
        }
        when 'write_file' | 'write' {
            X::Rakuish::Unsupported.new(:detail('write_file 需要 path')).throw
                unless $path.chars;
            my $content = %req<content>;
            X::Rakuish::Unsupported.new(:detail('write_file 需要 content')).throw
                unless $content.defined;
            my Int $n   = $content.Str.encode('utf-8').elems;
            my Int $cap = $!sandbox.clamp-bytes(%req<max_bytes>);
            X::Rakuish::Limit.new(:detail("写入超限: $n > $cap 字节")).throw
                if $n > $cap;
            $sys.write($path, $content,
                :atomic(%req<atomic> // True),
                :append(?%req<append>),
                :mkdir(?%req<mkdir>),
                :backup(?%req<backup>),
                :enc((%req<encoding> // 'utf-8').Str));
        }
        when 'list_dir' | 'list' | 'ls' {
            my %o = :recursive(?%req<recursive>), :all(?%req<hidden>);
            %o<max-depth> = %req<max_depth>.Int if %req<max_depth>.defined;
            $sys.ls($path.chars ?? $path !! '.', |%o);
        }
        when 'stat' {
            X::Rakuish::Unsupported.new(:detail('stat 需要 path')).throw
                unless $path.chars;
            $sys.stat($path);
        }
        when 'exec' {
            my @argv = %req<argv>.map(*.Str);
            my Int $cap-ms = $!sandbox.clamp-timeout(%req<timeout_ms>);
            if $!sandbox.request-timeout-ms > 0
               && ($cap-ms == 0 || $!sandbox.request-timeout-ms < $cap-ms) {
                $cap-ms = $!sandbox.request-timeout-ms;
            }
            my %o = :timeout-ms($cap-ms),
                    :max-bytes($!sandbox.clamp-output(%req<max_output>));
            if %req<cwd>.defined && %req<cwd>.Str.chars {
                %o<cwd> = $sys.resolve(%req<cwd>.Str);   # 过 root 校验
            }
            my %env = $sys.env.Hash;
            if %req<env> ~~ Hash {
                for %req<env>.kv -> $k, $val {
                    # 复用 Sandbox 的唯一安全 env 白名单，避免这里再维护一套
                    # 只挡 PATH 的旧逻辑。
                    X::Rakuish::Sandbox.new(
                        :detail("exec 不允许请求级 env: {$k.Str}")).throw
                        unless $!sandbox.env-allowed($k.Str);
                    %env{$k} = $val.Str;
                }
            }
            %o<env> = %env;
            $sys.exec(@argv[0], |@argv[1..*], |%o);
        }
        when 'pty_exec' {
            my @argv = %req<argv>.map(*.Str);
            my Int $cap-ms = $!sandbox.clamp-timeout(%req<timeout_ms>);
            if $!sandbox.request-timeout-ms > 0
               && ($cap-ms == 0 || $!sandbox.request-timeout-ms < $cap-ms) {
                $cap-ms = $!sandbox.request-timeout-ms;
            }
            my Int $cols = min(300, max(20, (%req<cols> // 80).Int));
            my Int $rows = min(120, max(5, (%req<rows> // 24).Int));
            my %o = :timeout-ms($cap-ms),
                    :max-bytes($!sandbox.clamp-output(%req<max_output>)),
                    :$cols, :$rows;
            if %req<cwd>.defined && %req<cwd>.Str.chars {
                %o<cwd> = $sys.resolve(%req<cwd>.Str);
            }
            my %env = $sys.env.Hash;
            if %req<env> ~~ Hash {
                for %req<env>.kv -> $k, $val {
                    X::Rakuish::Sandbox.new(
                        :detail("pty_exec 不允许请求级 env: {$k.Str}")).throw
                        unless $!sandbox.env-allowed($k.Str);
                    %env{$k} = $val.Str;
                }
            }
            %o<env> = %env;
            $sys.pty-exec(@argv[0], |@argv[1..*], |%o);
        }
        when 'rm' {
            X::Rakuish::Unsupported.new(:detail('rm 需要 path')).throw
                unless $path.chars;
            $sys.rm($path, :recursive(?%req<recursive>),
                    :force(?%req<force>), :dry-run(?%req<dry_run>));
        }
        when 'mkdir' {
            X::Rakuish::Unsupported.new(:detail('mkdir 需要 path')).throw
                unless $path.chars;
            $sys.mkdir($path);
        }
        when 'cp' | 'mv' {
            my Str $to = (%req<to> // '').Str;
            X::Rakuish::Unsupported.new(:detail("$op 需要 path 与 to")).throw
                unless $path.chars && $to.chars;
            $op eq 'cp'
                ?? $sys.cp($path, $to, :recursive(?%req<recursive>))
                !! $sys.mv($path, $to, :overwrite(?%req<overwrite>));
        }
        when 'glob' {
            my Str $pat = (%req<pattern> // '').Str;
            X::Rakuish::Unsupported.new(:detail('glob 需要 pattern')).throw
                unless $pat.chars;
            $sys.glob($pat, $path.chars ?? $path !! '.');
        }
        when 'sql_query' {
            X::Rakuish::Unsupported.new(
                :detail('sql_query 未配置数据引擎')
            ).throw unless $!engine.defined;
            my Str $sql = (%req<sql> // '').Str;
            X::Rakuish::Unsupported.new(:detail('sql_query 需要 sql')).throw
                unless $sql.chars;
            my $params = %req<params> // ();
            X::Rakuish::Unsupported.new(
                :detail('sql_query.params 必须是数组')
            ).throw unless $params ~~ Positional;
            my $table = $!engine.query(
                $sql, |$params.List,
                :max-rows($!sandbox.max-rows));
            $table
        }
        default {
            X::Rakuish::Unsupported.new(:detail("未实现 op: $op")).throw
        }
    }
}
