unit class Rakuish::Sandbox;

# Rakuish::Sandbox —— Agent 边界的安全策略集中地（设计 §6.3 / ADR 决策 5）。
#
# 设计 §6.3 要求：「这些都应该在 Sandbox 里实现，而不是在业务代码里
# 写 is-win 或 if」。所以 op 白名单、exec 开关、命令白名单、大小 / 超时 /
# 输出上限、token、审计全部在这里，Agent 只做「结构化 op → Sys 方法」的映射。
#
# 默认值（全部按设计推荐值）：
#   监听 127.0.0.1 · 启动时生成 token · 显式 root · exec 默认关闭
#   读写 1 MiB · 超时 30s · 输出 1 MiB · 审计 JSONL
#
# 路径越界不在这里重写一套：Sys.resolve 已有词法归一化 + root 校验，
# Agent 用 try-op 把 X::Rakuish::Sandbox 收敛成响应，避免两套判据。

use JSON::Fast;
use NativeCall;
use Rakuish::Result;

# Windows CSPRNG（advapi32!SystemFunction036）；POSIX 走 /dev/urandom。
sub RtlGenRandom(Buf, uint32 --> int32)
    is native('advapi32') is symbol('SystemFunction036') { * }

has $.root is required;
has Str  $.host       = '127.0.0.1';
has Str  $.token;
has Bool $.allow-exec = False;
has Bool $.allow-pty = False;
has @.allowlist;
has Int  $.max-bytes  = 1024 * 1024;
has Int  $.timeout-ms = 30_000;
has Int  $.max-output = 1024 * 1024;
has Int  $.max-rows = 1000;
has Int  $.sql-timeout-ms = 30_000;
has Int  $.request-timeout-ms = 30_000;
has Bool $.allow-sql = False;
has Int  $.max-audit-entries = 10_000;
has Int  $.max-audit-bytes   = 10 * 1024 * 1024;
has $.audit-log;
has @!entries;

# 审计是安全控制；多客户端共享 Sandbox 时 entries / JSONL append 必须串行。
my Lock $AUDIT-LOCK .= new;

# eval 刻意不开放：Agent 边界不执行任意 Raku 代码（设计把它标为「可选」，
# 且开放后 root / allowlist / 审计全部可被绕过）。
my constant OPS = <
    read_file read write_file write list_dir list ls stat exec pty_exec
    rm mkdir cp mv glob sql_query
>;

submethod TWEAK() {
    $!root = $!root.Str.IO.absolute.IO;
    $!token = self!fresh-token unless $!token.defined && $!token.chars;
    if $!audit-log.defined {
        $!audit-log = $!audit-log.Str.IO unless ($!audit-log ~~ IO::Path);
    }
}

method !fresh-token(--> Str) {
    # 32 字节 OS CSPRNG：Windows 用 RtlGenRandom，POSIX 用 /dev/urandom。
    # 不静默回落到 rand；拿不到安全随机源就拒绝启动（SANDBOX 初始化失败）。
    my Buf $bytes;
    if $*DISTRO.is-win {
        my Buf $buf = Buf.allocate(32);
        my Int $ok = RtlGenRandom($buf, 32);
        X::Rakuish::Unsupported.new(
            :detail('无法从 Windows CSPRNG 生成 sandbox token')
        ).throw unless $ok == 1;
        $bytes = $buf;
    }
    else {
        my $fh = try { '/dev/urandom'.IO.open(:bin, :r) };
        X::Rakuish::Unsupported.new(
            :detail('无法打开 /dev/urandom，拒绝用弱随机生成 sandbox token')
        ).throw unless $fh.defined;
        $bytes = $fh.read(32);
        $fh.close;
        X::Rakuish::Unsupported.new(
            :detail('从 /dev/urandom 读取 token 失败')
        ).throw unless $bytes.defined && $bytes.elems == 32;
    }
    $bytes.list.map({ .fmt('%02x') }).join;
}

method allowed-ops(--> List) { OPS.List }
method op-allowed(Str $op --> Bool) { so ($op (elem) OPS.List) }

# Windows 上 exe 常带 .exe 后缀，白名单里既可以写 `git` 也可以写绝对路径。
method !basename(Str $s --> Str) {
    $s.IO.basename.lc.subst(/ '.exe' $ /, '')
}

method !path-qualified(Str $s --> Bool) {
    $s.contains('/') || $s.contains('\\')
}

# 把可执行文件解析成真实路径；解析不到（不存在 / 坏链接）返回空串。
method !real-exe(Str $s --> Str) {
    my $r = try { $s.IO.resolve };
    return '' unless $r ~~ IO::Path;
    $r.Str;
}

method !same-path(Str $a, Str $b --> Bool) {
    my Str $x = $a.subst(:g, '\\', '/');
    my Str $y = $b.subst(:g, '\\', '/');
    $x = $x.lc if $*DISTRO.is-win;
    $y = $y.lc if $*DISTRO.is-win;
    $x eq $y;
}

# 安全规则：
#   · 请求里带路径分隔符（/ 或 \）⇒ 必须与白名单里的绝对路径
#     canonicalize 后精确匹配；不能拿 basename 冒充。
#   · 请求里是裸命令名 ⇒ 只和裸命令名白名单条目按 basename 匹配。
method exe-allowed(Str $exe --> Bool) {
    return False unless @!allowlist.elems;

    my Bool $exe-qualified = self!path-qualified($exe);
    if $exe-qualified {
        my Str $real = self!real-exe($exe);
        return False unless $real.chars;
        for @!allowlist -> $a {
            my Str $entry = $a.Str;
            next unless self!path-qualified($entry);
            my Str $allowed-real = self!real-exe($entry);
            next unless $allowed-real.chars;
            return True if self!same-path($real, $allowed-real);
        }
        return False;
    }

    my Str $b = self!basename($exe);
    for @!allowlist -> $a {
        my Str $entry = $a.Str;
        next if self!path-qualified($entry);
        return True if self!basename($entry) eq $b;
    }
    False;
}

# 请求级 env 不是“任意透传”：只允许语言/时区这类安全键。
# LD_PRELOAD / LD_LIBRARY_PATH / DYLD_* / BASH_ENV / PYTHONPATH / NODE_OPTIONS
# 等都能让白名单程序加载任意代码，必须拒绝。
method env-allowed(Str $key --> Bool) {
    my Str $k = $key.uc;
    return True if $k eq 'LANG' || $k eq 'LANGUAGE' || $k eq 'TZ';
    return True if $k.starts-with('LC_');
    False;
}

method authorize(Str $op, %req --> Result) {
    return Result.new(:!ok, :code(403), :op($op), :err("op 不允许: $op"))
        unless self.op-allowed($op);

    if $op eq 'exec' || $op eq 'pty_exec' {
        my $a = %req<argv>;
        return Result.new(:!ok, :code(400), :op($op),
                          :err("{$op} 需要 argv 数组"))
            unless $a ~~ Positional && $a.elems > 0;
        my Str $exe = $a[0].Str;
        # ADR 决策 5：默认不允许 exec，必须显式开启。
        return Result.new(:!ok, :code(403), :op($op),
                          :err("{$op} 未开启：需显式 --allow-exec"))
            unless $!allow-exec;
        if $op eq 'pty_exec' && !$!allow-pty {
            return Result.new(:!ok, :code(403), :op($op),
                :err('pty_exec 未开启：需显式 --allow-pty'));
        }
        return Result.new(:!ok, :code(403), :op($op),
                          :err("命令不在白名单: $exe"))
            unless self.exe-allowed($exe);

        # 请求级 env：只允许安全键；危险变量会让白名单程序执行任意代码。
        with %req<env> {
            return Result.new(:!ok, :code(400), :op($op),
                              :err("{$op}.env 必须是对象"))
                unless $_ ~~ Associative;
            for $_.kv -> $k, $v {
                return Result.new(:!ok, :code(403), :op($op),
                                  :err("env 不允许: {$k.Str}"))
                    unless self.env-allowed($k.Str);
            }
        }
    }
    if $op eq 'sql_query' {
        return Result.new(:!ok, :code(403), :op($op),
                          :err('sql_query 未开启：需显式 --allow-sql'))
            unless $!allow-sql;
    }

    Result.new(:ok, :op($op))
}

# 请求可以调小，但永远调不大（防止绕过默认上限）。
method clamp-bytes($n --> Int) {
    my Int $v = ($n // $!max-bytes).Int;
    $v > 0 && $v <= $!max-bytes ?? $v !! $!max-bytes
}
method clamp-timeout($n --> Int) {
    my Int $v = ($n // $!timeout-ms).Int;
    $v > 0 && $v <= $!timeout-ms ?? $v !! $!timeout-ms
}
method clamp-output($n --> Int) {
    my Int $v = ($n // $!max-output).Int;
    $v > 0 && $v <= $!max-output ?? $v !! $!max-output
}

method audit(%entry --> Nil) {
    $AUDIT-LOCK.protect({
        my %e = %entry;
        %e<ts> = DateTime.now.Str;
        @!entries.push(%e);
        if $!max-audit-entries > 0 && @!entries.elems > $!max-audit-entries {
            @!entries.splice(0, @!entries.elems - $!max-audit-entries);
        }
        if $!audit-log.defined {
            # 单行 JSONL：必须 :!pretty，默认 pretty 会把一条记录拆成多行。
            if $!max-audit-bytes > 0
               && $!audit-log.e
               && $!audit-log.s > $!max-audit-bytes {
                my IO::Path $bak = IO::Path.new($!audit-log.Str ~ '.1');
                try $bak.unlink;
                try $!audit-log.rename($bak);
            }
            try { $!audit-log.spurt(to-json(%e, :!pretty) ~ "\n", :append) }
        }
    });
    Nil
}

method entries(--> List) { @!entries.List }

method summary(--> Hash) {
    { host => $!host, root => $!root.Str, allow_exec => $!allow-exec,
      allow_pty => $!allow-pty,
      allowlist => @!allowlist.List, max_bytes => $!max-bytes,
      timeout_ms => $!timeout-ms, max_output => $!max-output,
      max_rows => $!max-rows, sql_timeout_ms => $!sql-timeout-ms,
      request_timeout_ms => $!request-timeout-ms,
      allow_sql => $!allow-sql,
      max_audit_entries => $!max-audit-entries,
      max_audit_bytes => $!max-audit-bytes,
      # summary 是诊断/日志对象，绝不回显 token；启动器需要时直接读 .token。
      token => '<redacted>' }
}
