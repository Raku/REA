unit class Rakuish::Sys;

# Rakuish::Sys —— API v3 的会话级系统上下文（ADR-0001 / Phase 1）。
#
# 与 v2 最根本的差别：cwd / env 是**对象属性**，不是进程全局状态。
#   · cd 不调用 chdir，不影响 $*CWD；
#   · set-env 不改 %*ENV，只改会话 Hash；
#   · 多个 Agent / REPL 会话各持一个 Sys，互不污染；
#   · resolve 做词法归一化 + root 沙箱校验，所有 FS 操作都过它。

use Rakuish::Sys::FS;
use Rakuish::Sys::Proc;
use Rakuish::Result;
use Rakuish::Data::Table;

has IO::Path $.cwd  = $*CWD.IO;
has IO::Path $.root;
# Windows 没有 POSIX 的单一 `/`；REPL/脚本默认允许所有盘符。
# Agent 显式 root 不打开，仍按给定目录做文件级约束。
has Bool $.all-drives = False;
has %.env    = %*ENV.Hash;
has Int  $.max-bytes = 1024 * 1024;
has Int  $.max-entries = 100_000;
has Rakuish::Sys::FS   $.fs;
has Rakuish::Sys::Proc $.proc;
has Int  $.job-seq = 0;
has %.jobs;                 # job-id => { handle, exe, argv, started }
has %.job-of;               # Handle.WHICH => job-id

submethod TWEAK() {
    $!root = $!cwd unless $!root.defined;
    # root 本身也可能是符号链接；先 canonicalize，后续所有比较都以真实路径为准。
    my $real-root = try { $!root.resolve };
    $!root = $real-root if $real-root ~~ IO::Path;
    my $self = self;
    $!fs = Rakuish::Sys::FS.new(
        :resolver(-> $p { $self.resolve($p) }),
        :max-bytes($!max-bytes),
        :max-entries($!max-entries),
    );
    $!proc = Rakuish::Sys::Proc.new(:max-bytes($!max-bytes));
}

# ── 路径解析 / 沙箱 ───────────────────────────────────────────────────
# 词法归一化：统一分隔符、消解 . 与 ..，保留盘符 / UNC 前缀。
method !norm(Str $s --> Str) {
    my Str $x = $s.subst(:g, '\\', '/');
    my Str $prefix = '';
    my Str $rest   = $x;
    my Bool $is-abs = $x.starts-with('/');

    if $x.chars >= 2 && $x.substr(1, 1) eq ':'
       && so($x.substr(0, 1) ~~ /^<[A..Za..z]>$/) {
        $prefix  = $x.substr(0, 2);
        $rest    = $x.substr(2);
        $is-abs  = True;
    }
    elsif $x.starts-with('//') {
        my @p = $x.substr(2).split('/').grep(*.chars);
        if @p.elems >= 2 {
            $prefix = '//' ~ @p[0] ~ '/' ~ @p[1];
            $rest   = @p.elems > 2 ?? @p[2..*].join('/') !! '';
            $is-abs = True;
        }
    }

    my @stack;
    for $rest.split('/').grep(*.chars) -> $seg {
        next if $seg eq '.';
        if $seg eq '..' { @stack.pop if @stack; next }
        @stack.push($seg);
    }
    my Str $tail = @stack.join('/');

    return $prefix eq ''
        ?? ($is-abs ?? '/' ~ $tail !! ($tail.chars ?? $tail !! '.'))
        !! ($prefix ~ ($tail.chars ?? '/' ~ $tail !! '/'));
}

# 把路径的真实目标（至少是最近的已存在祖先）解析出来。
# - 已存在的路径：.resolve 会跟随所有 symlink；
# - 不存在的新文件：解析最近的已存在父目录，再把不存在的尾部拼回去；
# - dangling symlink：.resolve 失败 → 拒绝（不能借它写 root 外）。
# 注意：本方法只用于“校验”，不替换调用方要操作的词法路径；
# 这样 `rm symlink` 仍然删链接本身，而不是删目标。
method !canonical(IO::Path $p --> IO::Path) {
    my IO::Path $cur = $p;
    my @tail;
    my Int $guard = 0;
    while !($cur.e || $cur.l) {
        my $parent = $cur.parent;
        last if $parent.Str eq $cur.Str;
        @tail.unshift($cur.basename);
        $cur = $parent;
        X::Rakuish::Sandbox.new(:detail("路径层级过深: {$p.Str}")).throw
            if ++$guard > 256;
    }

    my $base = $cur;
    if $cur.l || $cur.e {
        my $resolved = try { $cur.resolve };
        X::Rakuish::Sandbox.new(
            :detail("无法解析符号链接/路径: {$cur.Str}")
        ).throw unless $resolved ~~ IO::Path;
        $base = $resolved;
    }

    for @tail -> $seg { $base = $base.add($seg) }
    $base;
}

method !assert-in-root(IO::Path $p) {
    my IO::Path $real = self!canonical($p);
    my IO::Path $root-real = self!canonical($!root);
    my Str $r = self!norm($root-real.Str);
    my Str $a = self!norm($real.Str);
    my Bool $win = so $*DISTRO.is-win;
    $r = $r.lc if $win;
    $a = $a.lc if $win;
    # 根路径 '/' 不能 chop 成空串；前缀也必须保持 '/' 而不是 '//'。
    my Str $base = ($r.ends-with('/') && $r.chars > 1) ?? $r.chop !! $r;
    my Str $prefix = $base eq '/' ?? '/' !! $base ~ '/';
    X::Rakuish::Sandbox.new(
        :detail("路径越出 root: {$p.Str} (root={$!root.Str})")).throw
        unless $a eq $base || $a.starts-with($prefix);
}

# Windows 上 IO::Path.resolve **不会跟随文件类型的符号链接**：symlink 指向
# 目录时 .e=False / .l=True / .resolve 原样返回词法路径，但 OS 的 open/slurp
# 会跟随。只靠 !canonical 会让 `escape-dir/secret.txt` 读到 root 外的内容。
# 因此逐段 readlink 校验：任何一级链接的真实目标必须在 root 内。
method !assert-links-in-root(IO::Path $p --> Nil) {
    my Bool $win = so $*DISTRO.is-win;
    my Str $base = self!norm(self!canonical($!root).Str);
    my Str $root-word = self!norm($!root.Str);
    $base      = $base.lc      if $win;
    $root-word = $root-word.lc if $win;
    $base      = $base.chop      if $base.ends-with('/')      && $base.chars > 1;
    $root-word = $root-word.chop if $root-word.ends-with('/') && $root-word.chars > 1;
    my Str $prefix = $base eq '/' ?? '/' !! $base ~ '/';

    my IO::Path $cur = $p;
    my @chain;
    my Int $guard = 0;
    loop {
        my Str $cur-word = self!norm($cur.Str);
        $cur-word = $cur-word.lc if $win;
        $cur-word = $cur-word.chop if $cur-word.ends-with('/') && $cur-word.chars > 1;
        last if $cur-word eq $root-word;   # root 自身允许是链接
        @chain.unshift($cur);
        X::Rakuish::Sandbox.new(:detail("路径层级过深: {$p.Str}")).throw
            if ++$guard > 256;
        my $parent = $cur.parent;
        last if $parent.Str eq $cur.Str;
        $cur = $parent;
    }

    for @chain -> $seg {
        next unless $seg.l;
        my $target = try { $seg.readlink };
        X::Rakuish::Sandbox.new(
            :detail("无法解析符号链接: {$seg.Str}")
        ).throw unless $target ~~ IO::Path;
        my IO::Path $real = $target.is-absolute
            ?? $target
            !! $seg.parent.add($target.Str);
        my Str $t = self!norm(self!canonical($real).Str);
        $t = $t.lc if $*DISTRO.is-win;
        X::Rakuish::Sandbox.new(
            :detail("符号链接指向 root 外: {$seg.Str} -> {$real.Str}")
        ).throw unless $t eq $base || $t.starts-with($prefix);
    }
    Nil
}

method resolve($p --> IO::Path) {
    my Str $raw = $p.Str;
    my IO::Path $io = IO::Path.new($raw);
    my Str $abs = $io.is-absolute ?? $io.Str !! $io.absolute($!cwd.Str).Str;
    my IO::Path $norm = IO::Path.new(self!norm($abs));

    # 校验真实路径（含每一级中间 symlink），而不是只做字符串前缀比较。
    # !assert-links-in-root 补上 Windows .resolve 不跟随文件符号链接的缺口。
    # all-drives 是“Windows 文件系统根”的 REPL 语义，直接跳过 root 约束；
    # Agent 不会打开它。
    unless $!all-drives {
        self!assert-links-in-root($norm);
        self!assert-in-root($norm);
    }
    $norm
}

# ── 会话状态 ──────────────────────────────────────────────────────────
method cd($p --> IO::Path) {
    my IO::Path $d = self.resolve($p);
    X::Rakuish::NotFound.new(:detail("目录不存在: {$d.Str}")).throw unless $d.d;
    $!cwd = $d;                 # 只改会话值，不 chdir
    $d
}

method get-env(Str $k)       { %!env{$k} }
method set-env(Str $k, Str $v) { %!env{$k} = $v; $v }
method unset-env(Str $k)     { %!env{$k}:delete }
method env(--> Hash)         { %!env.Hash }

# ── Agent 边界：异常 → Result ─────────────────────────────────────────
method try-op(Str $op, &body --> Result) {
    my Instant $t0 = now;
    my $value;
    my Bool $ok = True;
    my Str  $err = '';
    {
        CATCH { default { $ok = False; $err = .message } }
        $value = body();
    }
    Result.new(:ok($ok), :code($ok ?? 0 !! 1), :value($value),
               :err($err), :op($op), :elapsed(now - $t0))
}

# ── 委托给 Sys::FS ───────────────────────────────────────────────────
method read(|c)   { $!fs.read(|c) }
method write(|c)  { $!fs.write(|c) }
method append(|c) { $!fs.append(|c) }
method ls(|c)     { $!fs.ls(|c) }
method ls-table(|c) { $!fs.ls-table(|c) }
method stat(|c)   { $!fs.stat(|c) }
method cp(|c)     { $!fs.cp(|c) }
method mv(|c)     { $!fs.mv(|c) }
method mkdir(|c)  { $!fs.mkdir(|c) }
method glob(|c)   { $!fs.glob(|c) }

# ── 进程 API（Phase 2）───────────────────────────────────────────────
# 把会话的 cwd / env 显式塞进 start() 的参数，不改进程全局状态。
method !proc-opts(%opts --> Hash) {
    my %o = %opts;
    %o<cwd> //= $!cwd;
    # 显式 :cwd 也必须过 root 校验，不能让 DSL/宿主用 cwd 绕过 Sandbox。
    %o<cwd> = self.resolve(%o<cwd>) if %o<cwd>.defined;
    %o<env> //= %!env;
    %o
}

method exec(Str $exe, *@args, *%opts --> Result) {
    my %o = self!proc-opts(%opts);
    $!proc.exec($exe, |@args, |%o)
}

# 0.70 / ADR-0007：交互式子进程（嵌套 REPL / 编辑器）走 TTY 直通。
# 与 exec 同样过 !proc-opts：cwd 过 root 校验、env 用会话 Hash。
# timeout-ms / max-bytes 等捕获式参数在这里没有意义，由 Proc 侧吞掉。
method tty-exec(Str $exe, *@args, *%opts --> Result) {
    my %o = self!proc-opts(%opts);
    $!proc.tty-exec($exe, |@args, |%o)
}

# PTY 捕获：子进程看到终端，父进程拿回 stdout；Agent 只在显式开关下使用。
method pty-exec(Str $exe, *@args, *%opts --> Result) {
    my %o = self!proc-opts(%opts);
    $!proc.pty-exec($exe, |@args, |%o)
}

method spawn(Str $exe, *@args, *%opts) {
    my %o = self!proc-opts(%opts);
    my $h = $!proc.spawn($exe, |@args, |%o);
    $!job-seq = $!job-seq + 1;
    my Int $id = $!job-seq;
    %!jobs{$id} = {
        handle  => $h,
        exe     => $exe,
        argv    => @args.List,
        started => $h.started,
    };
    %!job-of{$h.WHICH} = $id;
    $h
}

method wait($handle --> Result) {
    my $r = $!proc.wait($handle);
    self!drop-job($handle);
    $r
}

method cancel($handle --> Bool) {
    my Bool $ok = $!proc.cancel($handle);
    self!drop-job($handle);
    $ok
}

method !drop-job($handle --> Nil) {
    my $key = $handle.WHICH;
    my $id = %!job-of{$key}:delete;
    %!jobs{$id}:delete if $id.defined;
}

method jobs(--> Rakuish::Data::Table) {
    my @rows;
    for %!jobs.keys.sort({ $_.Int }) -> $id {
        my %j = %!jobs{$id};
        my Str $status = %j<handle>.promise.status ~~ Planned ?? 'running' !! 'done';
        @rows.push({
            id      => $id.Int,
            status  => $status,
            exe     => %j<exe>,
            argv    => %j<argv>.join(' '),
            started => %j<started>.DateTime.Str,
        });
    }
    Rakuish::Data::Table.from-rows(
        @rows, :columns<id status exe argv started>);
}

method job(Int $id) {
    %!jobs{$id}<handle> // Nil;
}

# 会话 root 本身不允许被删除（文件系统根由 FS 侧再挡一道）
method rm($p, *%opts --> Result) {
    my IO::Path $d = self.resolve($p);
    X::Rakuish::Sandbox.new(:detail("拒绝删除会话 root: {$d.Str}")).throw
        if self!norm($d.Str) eq self!norm($!root.Str);
    $!fs.rm($p, |%opts)
}
