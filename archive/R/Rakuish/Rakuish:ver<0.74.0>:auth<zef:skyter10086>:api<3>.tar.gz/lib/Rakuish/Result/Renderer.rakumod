unit module Rakuish::Result::Renderer;

use Rakuish::Data::Table;

# Rakuish::Result::Renderer —— Result 的多格式渲染层（text / json / markdown）。
#
# 设计约束：
#   · 不依赖 Rakuish::Result，避免和 Result.rakumod 形成 use 循环；
#     它只按「结果对象 + 结构化值」做鸭子类型渲染。
#   · 只负责“值 → 文本”，不读文件、不起进程、不改 Result。
#   · json 必须能被 JSON::Fast 解析；markdown 必须能被代码围栏安全包裹；
#     text 是给人看的稳定格式，不掺 ANSI。
#
# 典型用法：
#   $result.render('text');
#   $result.render('json', :pretty);
#   $result.render('markdown');
#   $result.to-json / .to-markdown / .to-text

use JSON::Fast;

class X::Rakuish::Render is Exception is export {
    has Str $.format is required;
    has Str $.detail = '';

    method message(--> Str) {
        my Str $base = "不支持的渲染格式: {$!format}（可用: text / json / markdown）";
        $!detail.chars ?? "{$base}: {$!detail}" !! $base
    }
}

our sub available-formats(--> List) is export { <text json markdown> }

sub norm-path(Str $s --> Str) { $s.subst('\\', '/', :g) }

# ── 结构化值 → JSON 安全值 ───────────────────────────────────────────
# IO::Path → 统一 / 分隔的 Str；Blob → 数字数组；Stat / WriteResult /
# Result → to-hash（Result 的 value 再递归）；其余对象兜底成 Str。
# 该函数导出给 Agent 等其他“需要纯 JSON 值”的边界复用。
our sub json-value($v) is export {
    return Nil unless $v.defined;

    given $v {
        when Str | Int | Num | Bool { return $v }
        when IO::Path              { return norm-path($v.Str) }
        when Blob                  { return $v.list.List }
        when Pair                  { return { $v.key.Str => json-value($v.value) } }
        when Rakuish::Data::Table  { return $v.rows.List }
        when Positional            { return $v.map({ json-value($_) }).List }
        when Hash {
            my %out;
            for $v.keys.sort({ .Str }) -> $k {
                my $val = $v{$k};
                my Str $key = $k.Str;
                %out{$key} = ($key eq 'path' || $key eq 'backup')
                    ?? (($val ~~ Str) ?? norm-path($val) !! json-value($val))
                    !! json-value($val);
            }
            return %out;
        }
        when Instant | Duration | DateTime { return $v.Str }
    }

    # Stat / WriteResult / Result 都有 to-hash；Result 另外有 value。
    if $v.^can('to-hash') {
        my %h = $v.to-hash;
        if $v.^can('value') {
            my $nested = $v.value;
            %h<value> = json-value($nested) if $nested.defined;
        }
        my %out;
        for %h.keys.sort({ .Str }) -> $k {
            my $val = %h{$k};
            my Str $key = $k.Str;
            %out{$key} = ($key eq 'path' || $key eq 'backup')
                ?? (($val ~~ Str) ?? norm-path($val) !! json-value($val))
                !! json-value($val);
        }
        return %out;
    }

    ~$v;
}

# ── 结构化值 → 人读文本 ─────────────────────────────────────────────
sub text-value($v, Int $indent = 0 --> Str) {
    return '' unless $v.defined;
    my Str $pad = ' ' x $indent;

    given $v {
        when Str | Int | Num | Bool { return $v.Str }
        when IO::Path              { return $v.Str }
        when Blob                  { return $v.list.join(' ') }
        when Pair                  { return $v.key.Str ~ ': ' ~ text-value($v.value, $indent + 2) }
        when Rakuish::Data::Table  { return $v.to-text }
        when Positional            {
            # ls / glob 这类 List[IO::Path] 的 text 展示用 basename，
            # 与 REPL 的 shell 风格一致；JSON 仍保留完整路径。
            if $v.elems && $v.all ~~ IO::Path {
                return $v.map(*.basename).sort({ .lc }).join("\n");
            }
            return $v.map({ text-value($_, $indent) }).join("\n");
        }
        when Hash {
            return '' unless $v.elems;
            return $v.keys.sort.map({
                "{$pad}{$_}: " ~ text-value($v{$_}, $indent + 2)
            }).join("\n");
        }
        when Instant | Duration | DateTime { return $v.Str }
    }

    if $v.^can('to-hash') {
        my %h = $v.to-hash;
        if $v.^can('value') {
            my $nested = $v.value;
            %h<value> = $nested if $nested.defined;
        }
        return '' unless %h.elems;
        return %h.keys.sort.map({
            "{$pad}{$_}: " ~ text-value(%h{$_}, $indent + 2)
        }).join("\n");
    }

    ~$v;
}

# ── text ──────────────────────────────────────────────────────────────
sub render-text($r, *%_ --> Str) {
    my @lines;
    @lines.push('ok: ' ~ ($r.ok ?? 'true' !! 'false'));
    @lines.push('op: ' ~ $r.op) if $r.op.chars;
    @lines.push('code: ' ~ $r.code);
    @lines.push('elapsed: ' ~ $r.elapsed) if $r.elapsed.defined;

    if $r.out.chars {
        @lines.push('out:');
        @lines.push($r.out.chomp);
    }
    if $r.err.chars {
        @lines.push('err:');
        @lines.push($r.err.chomp);
    }
    if $r.value.defined {
        @lines.push('value:');
        @lines.push(text-value($r.value));
    }

    @lines.join("\n");
}

# ── json ──────────────────────────────────────────────────────────────
# 不用 JSON::Fast 直接序列化 Hash：Raku 的 Hash 迭代顺序不保证，
# 同一结果渲染两次可能出现不同的键序，diff / 审计 / 测试都会抖。
# 这里用 JSON::Fast 只负责标量转义，容器自己按 key 排序输出。
sub json-text($v, Bool :$pretty = False, Int :$depth = 0 --> Str) {
    return 'null' unless $v.defined;

    if $v ~~ Associative {
        my @keys = $v.keys.map(*.Str).sort;
        return '{}' unless @keys;
        my @parts;
        for @keys -> $k {
            my $encoded = json-text($v{$k}, :$pretty, :depth($depth + 1));
            @parts.push(to-json($k, :!pretty) ~ ($pretty ?? ': ' !! ':') ~ $encoded);
        }
        if $pretty {
            my Str $pad = '  ' x ($depth + 1);
            my Str $close = '  ' x $depth;
            return '{' ~ "\n" ~ @parts.map({ $pad ~ $_ }).join(",\n") ~ "\n$close}";
        }
        return '{' ~ @parts.join(',') ~ '}';
    }

    if $v ~~ Positional {
        my @parts = $v.map({ json-text($_, :$pretty, :depth($depth + 1)) }).List;
        return '[]' unless @parts;
        if $pretty {
            my Str $pad = '  ' x ($depth + 1);
            my Str $close = '  ' x $depth;
            return "[\n" ~ @parts.map({ $pad ~ $_ }).join(",\n") ~ "\n$close]";
        }
        return '[' ~ @parts.join(',') ~ ']';
    }

    to-json($v, :!pretty);
}

sub render-json($r, Bool :$pretty = False, *%_ --> Str) {
    json-text(json-value($r), :$pretty);
}

# ── markdown ──────────────────────────────────────────────────────────
sub fence(Str $text, Str $lang --> Str) {
    my Int $n = 3;
    $n++ while $text.contains('`' x $n);
    my Str $f = '`' x $n;
    my Str $body = $text;
    $body ~= "\n" unless $body.ends-with("\n");
    $f ~ $lang ~ "\n" ~ $body ~ $f;
}

sub markdown-value($v --> Str) {
    my Str $json;
    my Bool $ok = so try { $json = json-text(json-value($v), :pretty); True };
    return $json if $ok;
    text-value($v);
}

sub markdown-value-lang($v --> Str) {
    my Bool $ok = so try { json-text(json-value($v), :pretty); True };
    $ok ?? 'json' !! 'text';
}

sub render-markdown($r, *%_ --> Str) {
    my @l;
    my Str $title = 'Result' ~ ($r.op.chars ?? ' · ' ~ $r.op !! '');
    @l.push('# ' ~ $title);
    @l.push('');
    @l.push('- **ok**: `' ~ ($r.ok ?? 'true' !! 'false') ~ '`');
    @l.push('- **op**: `' ~ $r.op ~ '`') if $r.op.chars;
    @l.push('- **code**: `' ~ $r.code ~ '`');
    @l.push('- **elapsed**: `' ~ $r.elapsed ~ '`') if $r.elapsed.defined;

    if $r.out.chars {
        @l.push('', '## stdout', '', fence($r.out.chomp, 'text'));
    }
    if $r.err.chars {
        @l.push('', '## stderr', '', fence($r.err.chomp, 'text'));
    }
    if $r.value.defined {
        @l.push('', '## value', '',
                fence(markdown-value($r.value), markdown-value-lang($r.value)));
    }

    @l.join("\n");
}

# ── 统一入口 ──────────────────────────────────────────────────────────
our sub render-result($r, Str $format = 'text', *%opts --> Str) is export {
    given $format.lc {
        when 'text' | 'txt' | 'plain' { render-text($r, |%opts) }
        when 'json'                    { render-json($r, |%opts) }
        when 'markdown' | 'md'         { render-markdown($r, |%opts) }
        default {
            X::Rakuish::Render.new(:format($format)).throw;
        }
    }
}
