unit module Rakuish::Agent::Worker;

# Rakuish::Agent::Worker —— 连接级常驻 worker 与 OS 硬取消（0.67 / ADR-0004 §4）。
#
# 父进程（监督者）持 accept loop / Sandbox / 审计；每个 TCP 连接启动一个
# 常驻 worker 子进程，双方用 stdin/stdout JSONL 通信。一次连接只付一次
# Rakudo 启动成本，不是按请求 fork。
#
# 硬取消：子进程返回 504（0.63 的 deadline 逻辑）或父进程 watchdog 到点，
# 立刻 kill 整个 worker 进程 —— 卡在不可取消文件 I/O 里的线程随进程消失。
# 代价是该连接随即关闭，客户端需重连；非 worker 模式仍保持连接可用。
#
# 配置（含 token）走子进程 stdin 第一行，不进命令行参数（不出现在进程列表）。
# 审计集中在父进程，子进程 Sandbox 不配 audit-log，避免多进程并发追加。

use JSON::Fast;
use Rakuish::Sandbox;

my constant MAX-LINE = 1_048_576;

# 传给子进程的完整配置。字段名与 bin/rakuish-agent 的 --worker-child 对齐。
our sub worker-config(Rakuish::Sandbox $s, Str :$session-id = 'default',
                      Str :$db = '', Str :$engine = 'duckdb',
                      --> Hash) is export {
    %(
        __rakuish_worker_config => True,
        root               => $s.root.Str,
        token              => $s.token,
        allow_exec         => so($s.allow-exec),
        allow_pty          => so($s.allow-pty),
        allow_sql          => so($s.allow-sql),
        allowlist          => $s.allowlist.List,
        max_bytes          => $s.max-bytes,
        timeout_ms         => $s.timeout-ms,
        max_output         => $s.max-output,
        max_rows           => $s.max-rows,
        sql_timeout_ms     => $s.sql-timeout-ms,
        request_timeout_ms => $s.request-timeout-ms,
        session            => $session-id,
        db                 => $db,
        engine             => $engine,
    )
}

sub timeout-reply($id --> Str) {
    to-json({ id => $id, ok => False, code => 504, op => '',
              err => 'request timeout (worker killed)' }, :!pretty)
}

# 启动一个 worker，写入配置第一行。返回可变 Hash 句柄（killed 由本模块维护）。
our sub spawn-worker(@command, %config,
                     Int :$startup-timeout-ms = 15_000 --> Hash) is export {
    my $proc = Proc::Async.new(|@command, :w);
    my $channel = Channel.new;
    $proc.stdout.lines.tap(
        -> $l { $channel.send($l) },
        done => { try { $channel.close } },
    );
    # 子进程的诊断信息只走 stderr，绝不污染 stdout 的 JSONL 协议。
    $proc.stderr.lines.tap(-> $l { try { $*ERR.say("[worker] $l") } });
    my $started = $proc.start;
    my %w = proc => $proc, channel => $channel, started => $started,
            killed => False, ready => False;
    my $wrote = so try { $proc.say(to-json(%config, :!pretty)); True };
    if $wrote {
        # 等 worker 的就绪握手，把 Rakudo 启动 + precomp 成本隔离在连接建立阶段。
        my $hello = start { try { $channel.receive } };
        await Promise.anyof($hello, Promise.in($startup-timeout-ms / 1000));
        if $hello.status ~~ Kept && $hello.result.defined {
            my %h = try { from-json($hello.result.Str) } // {};
            %w<ready> = so %h<__rakuish_worker_ready>;
        }
    }
    %w
}

our sub kill-worker(%w --> Bool) is export {
    return False if (%w<killed> // False);
    %w<killed> = True;
    try { %w<proc>.kill('SIGKILL') };
    try { %w<channel>.close };
    True
}

# 转发一行请求并等待应答。返回 { reply, timeout }；timeout 时已 kill worker。
our sub worker-request(%w, Str $line, Int :$hard-timeout-ms = 30_000,
                       --> Hash) is export {
    my $id = 0;
    try { my %q = from-json($line); $id = %q<id> // 0 };

    if (%w<killed> // False) || !(%w<ready> // False) {
        return { reply => timeout-reply($id), timeout => True };
    }

    my $wrote = so try { %w<proc>.say($line); True };
    unless $wrote {
        kill-worker(%w);
        return { reply => timeout-reply($id), timeout => True };
    }

    my $p = start { try { %w<channel>.receive } };
    my $guard = $hard-timeout-ms > 0 ?? $hard-timeout-ms / 1000 !! 30;
    await Promise.anyof($p, Promise.in($guard));
    if $p.status ~~ Kept && $p.result.defined {
        return { reply => $p.result.Str, timeout => False };
    }
    kill-worker(%w);
    { reply => timeout-reply($id), timeout => True }
}

# 一个连接的完整生命周期：读客户端行 → 转发 → 回写 → 审计 → 超时 kill。
our sub serve-connection($conn, :@command!, :%config!,
                         Rakuish::Sandbox :$sandbox!,
                         Int :$request-timeout-ms = 30_000,
                         Int :$idle-timeout-ms = 30_000,
                         Int :$max-lines = 1000,
                         Int :$hard-timeout-ms,
                         --> Hash) is export {
    my Int $hard = $hard-timeout-ms.defined
        ?? $hard-timeout-ms
        !! ($request-timeout-ms > 0 ?? $request-timeout-ms + 1000 !! 30_000);

    my %w = spawn-worker(@command, %config);
    my Int $lines = 0;
    my Int $timeouts = 0;
    my Bool $killed = False;
    my $in = Channel.new;
    my $tap = $conn.Supply.lines.tap(
        -> $l { try { $in.send($l) } },
        done => { try { $in.close } },
    );

    LEAVE {
        try $tap.close;
        try $conn.close;
        kill-worker(%w);   # 每连接一个进程，连接结束即回收
    }

    loop {
        my $next = start { try { $in.receive } };
        if $idle-timeout-ms > 0 {
            await Promise.anyof($next, Promise.in($idle-timeout-ms / 1000));
            last unless $next.status ~~ Kept;
        }
        else {
            try { await $next };
        }
        my $line = $next.status ~~ Kept ?? $next.result !! Nil;
        last unless $line.defined;
        next if $line.Str.trim.chars == 0;
        last if $lines >= $max-lines;

        my %q = try { from-json($line.Str) } // {};
        my Str $reply;
        my Bool $timed-out = False;
        if $line.Str.chars > MAX-LINE {
            $reply = to-json({ id => 0, ok => False, code => 400,
                               err => 'JSONL 行过长' }, :!pretty);
        }
        else {
            $lines++;
            my %r = worker-request(%w, $line.Str, :hard-timeout-ms($hard));
            $reply = %r<reply>;
            $timed-out = so %r<timeout>;
            $timeouts++ if $timed-out;
        }

        $conn.print($reply ~ "\n");
        my %resp = try { from-json($reply) } // {};

        # 审计集中在父进程：不含 token / 文件内容 / SQL 原文。
        my Int $code = (%resp<code> // 0).Int;
        my Str $stage = $code == 401 ?? 'auth'
                      !! $code == 403 ?? 'policy'
                      !! $code == 504 ?? 'timeout'
                      !! 'op';
        my %e = session => (%config<session> // 'default'),
                op => (%q<op> // '').Str, stage => $stage,
                ok => so(%resp<ok>), code => $code;
        %e<path> = %q<path>.Str if %q<path>.defined;
        %e<argv> = %q<argv>.map(*.Str).List
            if (%q<op> // '').Str eq 'exec' && %q<argv>.defined;
        %e<err> = %resp<err>.Str
            if %resp<err>.defined && %resp<err>.Str.chars;
        try { $sandbox.audit(%e) };

        # 子进程自己报 504，或父进程 watchdog 到点：都 kill worker 并断连。
        if $timed-out || $code == 504 {
            kill-worker(%w);
            $killed = True;
            last;
        }
    }

    { lines => $lines, timeouts => $timeouts, killed => $killed }
}
