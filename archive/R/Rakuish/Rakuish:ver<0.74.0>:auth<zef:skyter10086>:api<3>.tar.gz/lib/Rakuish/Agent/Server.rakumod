unit class Rakuish::Agent::Server;

# Rakuish::Agent::Server —— 传输层（设计 §6，只借用 v2 的 JSONL 思路）。
#
# 两种通道，共用同一个 Agent.handle-line：
#   · run-jsonl：stdin/stdout 或任意 IO 句柄，逐行请求-响应（默认，CI 友好）；
#   · serve-once：TCP 只绑 sandbox.host（默认 127.0.0.1），一个连接 = 一个会话。
#   · serve：常驻多客户端；:worker 时每连接交给一个独立子进程（ADR-0004）。
#
# 传输层**不实现任何策略**：认证、白名单、上限、审计都在 Sandbox / Agent 里。
# 这里也没有 shell 字符串解析 —— 每行必须是结构化 JSON。

use JSON::Fast;
use Rakuish::Agent;
use Rakuish::Agent::Worker;
use Rakuish::Sandbox;

has Rakuish::Sandbox $.sandbox is required;
has Str $.session-id = 'default';
has $.engine;

my constant MAX-LINE = 1_048_576;

# 多客户端模式下每连接必须拿到独立 Sys / Engine：:&engine-factory 由入口
# 提供，每次调用新建一个只读连接；单会话路径仍用共享 $!engine。
method new-agent(Str :$session-id = $!session-id,
                 :$engine = $!engine,
                 :&engine-factory --> Rakuish::Agent) {
    my $e = &engine-factory.defined ?? &engine-factory.() !! $engine;
    Rakuish::Agent.new(:sandbox($!sandbox), :session-id($session-id),
                       :engine($e))
}

# 逐行 JSONL；返回处理的请求数。
method run-jsonl($in = $*IN, $out = $*OUT,
                 Rakuish::Agent :$agent = self.new-agent --> Int) {
    my Int $n = 0;
    for $in.lines -> $line {
        next if $line.trim.chars == 0;
        if $line.chars > MAX-LINE {
            $out.say(to-json({ id => 0, ok => False, code => 400,
                               err => 'JSONL 行过长' }, :!pretty));
            $out.flush;
            next;
        }
        $out.say($agent.handle-line($line));
        $out.flush;
        $n = $n + 1;
    }
    $n
}

# 只绑 sandbox.host（默认 127.0.0.1，绝不用 INADDR_ANY）。
method listen(Int :$port = 0) {
    IO::Socket::INET.new(:listen, :localhost($!sandbox.host), :localport($port))
}

# 接受一个连接、处理到 EOF 后关闭。:on-ready 在 accept 之前回调端口，
# 让调用方（测试 / 启动器）能在不阻塞的情况下知道实际监听端口。
method serve-once(Int :$port = 0,
                  Rakuish::Agent :$agent = self.new-agent,
                  Int :$max-lines = 1000,
                  Int :$idle-timeout-ms = 30_000,
                  :&on-ready --> Hash) {
    my Str $host = $!sandbox.host;
    my Int $real-port = $port;
    if $real-port == 0 {
        # 异步 listen 不直接暴露 0 端口分配结果；先用同步 socket 探一个端口。
        my $probe = IO::Socket::INET.new(
            :listen, :localhost($host), :localport(0));
        $real-port = $probe.localport.Int;
        $probe.close;
    }

    my $server = IO::Socket::Async.listen($host, $real-port);
    my Int $n = 0;
    my Bool $timed-out = False;
    my Bool $announced = False;
    react {
        # 等事件循环真正开始监听后再回调，避免 Linux 上 on-ready 后立刻
        # connect 吃到 connection refused。
        whenever Promise.in(0.05) {
            unless $announced {
                $announced = True;
                &on-ready.($real-port) if &on-ready.defined;
            }
        }
        whenever $server -> $conn {
            my $done = Promise.new;
            my $tap = $conn.Supply.lines.tap(
                -> $line {
                    return if $n >= $max-lines;
                    return if $line.trim.chars == 0;
                    if $line.chars > MAX-LINE {
                        $conn.print(to-json({ id => 0, ok => False, code => 400,
                                              err => 'JSONL 行过长' }, :!pretty) ~ "\n");
                        return;
                    }
                    $n = $n + 1;
                    $conn.print($agent.handle-line($line) ~ "\n");
                },
                done => { $done.keep('eof') },
            );

            if $idle-timeout-ms > 0 {
                my $winner = await Promise.anyof(
                    $done, Promise.in($idle-timeout-ms / 1000));
                $timed-out = True unless $done.status ~~ Kept;
            }
            else {
                await $done;
            }

            try $tap.close;
            try $conn.close;
            done;
        }
        whenever Promise.in(60) { done }   # accept 本身也有上限
    }

    { host => $host, port => $real-port, lines => $n,
      timed_out => $timed-out }
}

# ── 常驻多客户端服务（ADR-0002 §3.1）──────────────────────────────────
# 与 serve-once 的区别：accept loop 不 done；每连接独立 Agent（独立 Sys /
# session-id / Engine）；每个连接在自己的任务里串行处理 JSONL，互不阻塞。
# :$stop 是外部停止信号，keep 后不再接受新连接并结束 react。
# :$worker（0.67 / ADR-0004）时每连接换成独立子进程，超时可 OS 级 kill；
# 不开时下面这条路径与 0.63 完全一致，一字不改。
method serve(Int :$port = 0,
             Int :$idle-timeout-ms = 30_000,
             Int :$max-connections = 16,
             Int :$max-lines = 1000,
             :&engine-factory,
             Promise :$stop,
             Bool :$worker = False,
             :@worker-command,
             :%worker-config,
             Int :$worker-hard-timeout-ms,
             :&on-ready --> Hash) {
    if $!engine.defined && !(&engine-factory.defined) {
        return { ok => False,
                 err => '常驻模式需要 engine-factory，不能共享 Engine 连接' };
    }
    if $worker && (!@worker-command.elems || !%worker-config.elems) {
        return { ok => False,
                 err => 'worker 模式需要 worker-command 与 worker-config' };
    }

    my Str $host = $!sandbox.host;
    my Int $real-port = $port;
    if $real-port == 0 {
        my $probe = IO::Socket::INET.new(
            :listen, :localhost($host), :localport(0));
        $real-port = $probe.localport.Int;
        $probe.close;
    }

    my $server = IO::Socket::Async.listen($host, $real-port);
    my $lock  = Lock.new;
    my Int $active   = 0;
    my Int $lines    = 0;
    my Int $rejected = 0;
    my Int $total    = 0;
    my Int $worker-killed = 0;
    my Int $worker-timeouts = 0;
    my Bool $announced = False;
    my $stop-p = $stop // Promise.new;
    my $idle = $idle-timeout-ms > 0 ?? $idle-timeout-ms / 1000 !! 0;

    react {
        whenever Promise.in(0.05) {
            unless $announced {
                $announced = True;
                &on-ready.($real-port) if &on-ready.defined;
            }
        }
        whenever $stop-p { done }
        whenever $server -> $conn {
            my Int $cid = 0;
            my Bool $admit = $lock.protect({
                if $active < $max-connections {
                    $total++;
                    $cid = $total;
                    $active++;
                    True
                }
                else { False }
            });
            if !$admit {
                $lock.protect({ $rejected++ });
                try $conn.close;
            }
            else {
                my Str $sid = "{$!session-id}-c{$cid}";
                if $worker {
                    my %cfg = %worker-config.Hash;
                    %cfg<session> = $sid;
                    start {
                        # 无论 serve-connection 正常返回还是抛异常，都必须归还
                        # 连接计数；否则累计到 max-connections 后永久拒绝。
                        LEAVE {
                            $lock.protect({ $active-- });
                        }
                        my %info = Rakuish::Agent::Worker::serve-connection(
                            $conn,
                            :command(@worker-command),
                            :config(%cfg),
                            :sandbox($!sandbox),
                            :request-timeout-ms($!sandbox.request-timeout-ms),
                            :idle-timeout-ms($idle-timeout-ms),
                            :max-lines($max-lines),
                            :hard-timeout-ms($worker-hard-timeout-ms),
                        );
                        $lock.protect({
                            $lines += %info<lines>;
                            $worker-killed += %info<killed>;
                            $worker-timeouts += %info<timeouts>;
                        });
                    }
                }
                else {
                    my $agent = self.new-agent(:session-id($sid), :&engine-factory);
                    # tap 必须在 accept 线程立刻建立，否则会丢掉连接后马上到达的数据。
                    my $channel = Channel.new;
                    my $tap = $conn.Supply.lines.tap(
                        -> $l { $channel.send($l) },
                        done => { $channel.close },
                    );
                    start {
                        my Int $n = 0;
                        loop {
                            my $next = start { try { $channel.receive } };
                            if $idle > 0 {
                                await Promise.anyof($next, Promise.in($idle));
                                last unless $next.status ~~ Kept;
                            }
                            else {
                                try { await $next };
                            }
                            my $line = $next.status ~~ Kept ?? $next.result !! Nil;
                            last unless $line.defined;
                            next if $line.trim.chars == 0;
                            last if $n >= $max-lines;
                            if $line.chars > MAX-LINE {
                                $conn.print(to-json({ id => 0, ok => False, code => 400,
                                                      err => 'JSONL 行过长' }, :!pretty) ~ "\n");
                                next;
                            }
                            $n++;
                            $lock.protect({ $lines++ });
                            $conn.print($agent.handle-line($line) ~ "\n");
                        }
                        try $tap.close;
                        try $conn.close;
                        $lock.protect({ $active-- });
                    }
                }
            }
        }
    }

    { ok => True, host => $host, port => $real-port,
      lines => $lines, connections => $total, rejected => $rejected,
      timed_out => False, worker => $worker,
      worker_killed => $worker-killed, worker_timeouts => $worker-timeouts }
}
