unit module Rakuish::Result;

use Rakuish::Result::Renderer;

# Rakuish::Result —— API v3 的类型化结果（ADR-0001）。
#
# 约定：
#   · 读 / 写 / 列目录 / stat 这类文件 API **抛异常**（Raku 风格）；
#   · rm / cp / mv 等破坏性或带 dry-run 的操作直接返回 Result；
#   · Agent 边界一律用 Sys.try-op 把异常收敛成 Result，再序列化。
#   · 这里没有 $? / $$ / $0：退出码只作为 Result.code。
#
# 与 v2 的 Rakuish::Result 完全无关：那个类吃 shell 字符串，本模块只吃 Raku 值。

# ── 异常族 ────────────────────────────────────────────────────────────
class X::Rakuish::V3 is Exception is export {
    has Str $.detail is required;
    method message(--> Str) { $!detail }
}

class X::Rakuish::NotFound is X::Rakuish::V3 is export { }
class X::Rakuish::Path    is X::Rakuish::V3 is export { }
class X::Rakuish::Limit   is X::Rakuish::V3 is export { }
class X::Rakuish::Sandbox is X::Rakuish::V3 is export { }
class X::Rakuish::Exists  is X::Rakuish::V3 is export { }
class X::Rakuish::Unsupported is X::Rakuish::V3 is export { }
# 数据引擎错误统一门面：不把驱动堆栈原样抛给 REPL / Agent（0.64）。
class X::Rakuish::Data is X::Rakuish::V3 is export { }

# ── 文件元数据 ────────────────────────────────────────────────────────
class Stat is export {
    has IO::Path $.path is required;
    has Int  $.size       = 0;
    has Bool $.is-file    = False;
    has Bool $.is-dir     = False;
    has Bool $.is-symlink = False;
    has Bool $.readable   = False;
    has Bool $.writable   = False;
    has Bool $.executable = False;
    has Int  $.mode       = 0;
    has Instant $.modified;          # 取不到时保持未定义，绝不编 1970 年假值

    method type(--> Str) {
        return 'symlink' if $!is-symlink;
        return 'dir'     if $!is-dir;
        return 'file'    if $!is-file;
        'other'
    }

    method to-hash(--> Hash) {
        my %h = path       => $!path.Str,
                size       => $!size,
                type       => self.type,
                is-file    => $!is-file,
                is-dir     => $!is-dir,
                is-symlink => $!is-symlink,
                readable   => $!readable,
                writable   => $!writable,
                executable => $!executable,
                mode       => $!mode;
        %h<modified> = ~$!modified if $!modified.defined;
        %h
    }
}

# ── 写入结果 ──────────────────────────────────────────────────────────
class WriteResult is export {
    has IO::Path $.path is required;
    has Int  $.bytes  = 0;
    has Bool $.atomic = False;   # 是否真的走了 rename；Windows 覆盖降级时为 False
    has Str  $.backup = '';

    method to-hash(--> Hash) {
        my %h = path => $!path.Str, bytes => $!bytes, atomic => $!atomic;
        %h<backup> = $!backup if $!backup.chars;
        %h
    }
}

# ── 统一结果 ──────────────────────────────────────────────────────────
class Result is export {
    has Bool $.ok is required;
    has Int  $.code = 0;
    has Any  $.value;
    has Str  $.out  = '';
    has Str  $.err  = '';
    has Str  $.op   = '';
    has Duration $.elapsed;
    # shell 层的 echo -n：调用方打印时不要追加换行（不影响 value/out）。
    has Bool $.no-newline = False;
    # 内置命令统一预渲染的 text 结果。空串表示“还没有缓存”，由 text 方法
    # 按需用 render('text') 计算；结构化 value/out/err 仍然保留。
    has Str  $.rendered = '';

    method Bool(--> Bool) { $!ok }                 # Raku 的 && / || 直接可用
    method lines(--> List) { $!out.lines.List }

    method to-hash(--> Hash) {
        my %h = ok => $!ok, code => $!code, out => $!out, err => $!err;
        %h<value>   = $!value   if $!value.defined;
        %h<op>      = $!op      if $!op.chars;
        %h<elapsed> = ~$!elapsed if $!elapsed.defined;
        %h
    }

    # ── 多格式渲染 ────────────────────────────────────────────────────
    # text / json / markdown；别名 txt / plain、md。未知格式抛
    # X::Rakuish::Render（在 Rakuish::Result::Renderer 里定义）。
    # json 默认紧凑，:pretty 可展开；其余格式忽略额外选项。
    method render(Str $format = 'text', *%opts --> Str) {
        # 同时接受 `render('json')` 与 `render(:format<json>)`：Raku 的
        # 位置参数不会自动接住同名命名参数，这里显式合并一次。
        my Str $fmt = (%opts<format> // $format).Str;
        # 内置命令已经预渲染过 text：直接返回缓存，避免重复扫描 value。
        return $!rendered if $!rendered.chars
            && ($fmt.lc eq 'text' || $fmt.lc eq 'txt' || $fmt.lc eq 'plain');
        Rakuish::Result::Renderer::render-result(self, $fmt, |%opts);
    }

    # 内置命令的 text 结果入口：优先返回预渲染缓存，否则按需计算。
    method text(--> Str) {
        $!rendered.chars ?? $!rendered !! self.render('text');
    }

    method to-text(--> Str)     { self.text }
    method to-json(Bool :$pretty = False --> Str) { self.render('json', :$pretty) }
    method to-markdown(--> Str) { self.render('markdown') }

    # `say $result` / REPL 默认展示统一走 text，而不是对象的默认 gist。
    method gist(--> Str) { self.text }

    # REPL 的“内置命令结果”展示口径：优先显示命令自己的 stdout；失败时显示
    # stderr；路径/计数这类简单 value 直接给出；复杂结构回退到 text 全量。
    # 完整诊断仍可用 .text / .render('text')，这里只影响交互展示。
    method display(--> Str) {
        if $!out.chars {
            my Str $s = $!out.chomp;
            $s ~= "\n" ~ $!err.chomp if $!err.chars;
            return $s;
        }
        return $!err.chomp if !$!ok && $!err.chars;
        if $!value.defined && ($!value ~~ Str | Int | Num | Bool | IO::Path) {
            my Str $v = $!value.Str;
            return $v if $v.chars;
        }
        self.text;
    }
}

class X::Rakuish::CommandFailed is X::Rakuish::V3 is export {
    has Result $.result is required;
    method message(--> Str) {
        my Str $op = $!result.op.chars ?? $!result.op !! 'command';
        "{$op} 失败" ~ ($!result.err.chars ?? ": {$!result.err.chomp}" !! '');
    }
}
