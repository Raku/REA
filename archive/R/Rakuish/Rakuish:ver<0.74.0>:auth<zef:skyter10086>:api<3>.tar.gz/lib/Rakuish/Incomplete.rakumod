# Rakuish::Incomplete —— 判断一段输入是否"还没写完"
#
# 为什么必须自己写（而不是靠编译错误判断）：
#   · rakupp 的编译错误里**没有 `<HERE>` 位置标记**
#   · 更糟的是它**不区分"未写完"与"写错了"**（实测）：
#       1 +      -> Missing required term after infix
#       1 +)     -> Missing required term after infix   （一模一样）
#       sub f {  -> Missing block
#       {        -> Missing block                       （也一模一样）
#     所以"caret 标记落在行尾就算没写完"那套启发式在 rakupp 上完全失效。
#
# 判定由两部分组成（都是纯逻辑，与任何实现无关，因此两个实现上行为一致）：
#   1. **括号 / 引号配对**：有未闭合 -> 没写完；
#      **错配**（多出闭括号）-> 判定"写错了"，让 REPL 报错而不是傻等下一行。
#   2. **行尾悬空运算符**：括号配平但最后停在 `+` / `=` / `,` 上——
#      这是配平做不到的那一半（`1 +` 括号是平的，但不写完没法执行）。
#      借用 shell 的续行传统。
#
# 已知边界（有意不处理，报错好过卡住）：
#   · **heredoc 不等待**。原本这里是识别 `<<TAG` / `qq:to TAG` 并等到终止行，
#     但实测发现**两个后端都不支持 heredoc**（走 eval-cell 通道）：
#       `say <<END`  -> 被当成 quote-words 下标，报 "couldn't find '>>'"（rakupp）
#       `say qq:to END` -> "Two terms in a row"（rakupp）
#     带不带尾换行都一样。而继续等待只会让用户多打两行再看同一个错。
#     当当「不等待」，让它立即报错。
#   · `my` / `if` 这类"后面还需要东西"的关键字单独一行 -> 判为写完，然后编译报错
#   · 引号内的括号不当括号（与所有 shell 一致）
#   · 反引号不算引号（实测 rakupp 不支持反引号）

unit module Rakuish::Incomplete;

# 用 %( ) 而不是 %[ ]：后者会被字面量里的 '[' 提前终止。
our %OPEN-TO-CLOSE = %( '(' => ')', '[' => ']', '{' => '}' );

# 反斜杠。用 chr(92) 而不是写 '\' —— 单引号串里 '\' 里的 \' 会被当成转义单引号，
# 字符串直接不闭合（q{\} 同理：反斜杠把闭合花括号吃掉了）。
our $BS = chr(92);

# smart quote 的 :adverb 里可能出现的字符
our $ADVERB-CHARS = q{abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,};

# **故意不放 `/` `<` `>`**（而不是因为它们不是运算符）。这三个字符在 REPL 里
# 的典型**非运算符用法**很常见，放进来就会误判（实测过）：
#   `ls lib/`   -> 以 `/` 结尾的路径，被当成「还没写完」，吃掉下一行输入
#   `<a b>`     -> quote-words 词表以 `>` 结尾，同样被误判
# 而它们真正的用法（`1 /`、`cmd >`）在 REPL 里极少。同理，`..` / `...` 也被移除。
# 这个列表是**启发式判定**：它要回答的是「这个表达式清楚地还没写完」，
# 而不是「语法上能不能执行」。决定因素是**频率**，不是严格度。
# 若将来出现更多误判（比如某个分隔符也被当运算符），同样减掉。
# 行尾停在这些记号上就算没写完。
# 用 q{} 而不是 <...>：列表里有裸的 `<` 和 `>`，`<...>` 引用会被提前终止。
#
# **故意不放 `..` 与 `...`**。它们确实是需要右操作数的运算符，但它们也是
# 元素字面常用的字面：`cd ..` 是一条**5个字**的完整命令，却会被当成「还没写完」，
# 后果是它吃掉下一行输入、命令不生效（t/19 曾因此失败）。而只写 `1..` 这种行尾悬空
# 的写法在 REPL 里极少，即使误判定为「写完」，立即报错也比卡住不动更好。
# 这里是一个启发式判定（不读 token 流），必须按**REPL 里的频率**而不是语法严格度取舍。
our @TRAILING = q{ + - * // ** %% == != <= >= = := += -= *= //= .= => , && || ^^ and or but so }.split(' ');

# 扫描器的状态：一个"还没闭合的东西"栈
#   kind   = 'code'（代码：括号/花括号要配对）或 'quote'（引号内：只认闭合记号）
#   want   = 期望的闭合字符
#   interp = 该引号是否**可插值**（`"..."` / `qq(...)`）。
#
# **为什么引号帧要带 interp（P4-1 的根因）**：可插值引号里的 `{...}` 是**代码**，
# 必须压一个 code 帧进去配对。老实现只用一个「是否在引号内」的布尔量，而且
# 一旦进了任何帧就把后续字符**全跳过**（连 `"` 都不认），于是块体里
# `say "v={$i}"` 的那个 `}` 被当成**代码块的收尾**，把外层 `for ... {` 的帧
# 弹掉 —— cell 边界就此判错。结局取决于切在哪儿：`Missing block`，
# 或者在"引号"里一路吃到文件尾 ⇒ 整段被吞、rc=0、零输出（静默终止）。
class Frame is Mu {
    has Str  $.kind   = 'code';
    has Str  $.want   = '';
    has Bool $.interp = False;
}

# 扫完整个源码，返回还开着的帧。
# Hash：frames = 未闭合的帧（空 = 全配平）；mismatch = 出现了多余的闭括号。
# mismatch 为真表示「确定写错了」，调用方应立刻报错而不是继续等输入。
sub scan-frames(Str $src --> Hash) {
    my @stack;

    for $src.split("\n", :keepempty) -> $line {
        my Int $len = $line.chars;
        my Int $i   = 0;

        while $i < $len {
            my $top = @stack.elems ?? @stack[*-1] !! Nil;
            my $c   = $line.substr($i, 1);

            # ── 引号内：只认闭合记号 / 转义 / 内插起点 ──
            if $top.defined and $top.kind eq 'quote' {
                if $c eq $BS { $i += 2; next }          # 转义：连下一个字符一起跳过
                if $top.interp and $c eq '{' {          # `"a-{$x}"`：内插表达式按代码配对
                    @stack.push: Frame.new(:kind('code'), :want('}'));
                    $i++; next;
                }
                if $c eq $top.want { @stack.pop; $i++; next }
                # 括号当分隔符的引号（`q{...}` / `qq(...)`）里，**同种括号是可嵌套的**：
                #   q{/*.dat | awk '{ a += NF } END { b }'}
                # 不数这一层，内层第一个 `}` 就把引号关了，后面全错位 ——
                # 10-pipeline-glue 就是这样被判成"文件读完了还没写完"。
                if $top.want ne q{} and %OPEN-TO-CLOSE{$c}:exists
                   and %OPEN-TO-CLOSE{$c} eq $top.want {
                    @stack.push: Frame.new(:kind('quote'), :want($top.want),
                                           :interp($top.interp));
                    $i++; next;
                }
                $i++; next;
            }

            # ── 代码态 ──
            last if $c eq '#';                          # 行注释：本行剩下的都不用管

            if $c eq 'q' or $c eq 'Q' {
                my $pair = smart-quote-at($line, $i);
                if $pair {
                    @stack.push: Frame.new(:kind('quote'), :want($pair<close>),
                                           :interp($pair<interp>));
                    $i = $pair<next-index>;
                    next;
                }
            }
            if $c eq "'" {
                @stack.push: Frame.new(:kind('quote'), :want("'"));
                $i++; next;
            }
            if $c eq '"' {
                @stack.push: Frame.new(:kind('quote'), :want('"'), :interp(True));
                $i++; next;
            }
            if %OPEN-TO-CLOSE{$c}:exists {
                @stack.push: Frame.new(:kind('code'), :want(%OPEN-TO-CLOSE{$c}));
                $i++; next;
            }
            if $c eq ')' or $c eq ']' or $c eq '}' {
                # 闭括号必须和栈顶**对得上**才算配平。对不上（或栈已空）就是
                # 确定写错了：立刻返 mismatch，别让调用方傻等下一行。
                return %( frames => ().List, mismatch => True )
                    unless $top.defined and $top.want eq $c;
                @stack.pop;
                $i++; next;
            }
            $i++;
        }
    }
    %( frames => @stack.List, mismatch => False )
}

# 主判定。
# `is export` 不能省：Raku 2018.04 起模块成员**默认私有**，不写这一句
# 调用方会得到 `Undeclared routine: is-incomplete`。
our sub is-incomplete(Str $src --> Bool) is export {
    my %scan = scan-frames($src);

    # 多出来的闭括号：**立刻**说写错了，不要傻等下一行
    return False if %scan<mismatch>;
    return True if %scan<frames>.elems;

    # 括号/引号都配平：还剩"行尾悬空运算符"那一半（见文件头）。
    # 取**最后一行非空**，不是 @lines[*-1]。原因：调用方 join-lines 会在源码
    # 末尾补一个 "\n"，拆行后最后一项是空串，直接用它会让行尾运算符
    # 判定被跳过。后果很隐蔽：`my $x = 1 +` 永远不续行。
    my @non-empty = $src.split("\n", :keepempty).grep(*.trim ne q{});
    return False unless @non-empty.elems;
    ends-on-trailing-token(@non-empty[*-1].trim)
}

# 报错用：还差什么没闭合（例：`}` 与 `"`）。全配平返回空串。
# 有了它，P4-2 的「文件读完还没写完」才能给出**可行动**的提示，不只是行号。
our sub unclosed-hint(Str $src --> Str) is export {
    my %scan = scan-frames($src);
    return q{} if %scan<mismatch>;
    my @w = %scan<frames>.map({ .want }).unique;
    return q{} unless @w.elems;
    @w.join(' ')
}

# 【已删除】原 heredoc-tag-at-end：两后端的 EVAL 都不支持 heredoc，
# 识别它只会把用户引向一个永远不会成功的续行（详见文件头说明）。
sub _removed-heredoc-tag-at-end(Str $line --> Str) {
    my $l = $line.trim;
    return Nil if $l eq '';
    $l = $l.substr(0, $l.chars - 1) if $l.substr($l.chars - 1, 1) eq ';';
    return Nil if $l.chars < 3;

    # 找最后一个 '<<'（排除 '<<<'）
    my Int $start = -1;
    my Int $i    = 0;
    while $i < $l.chars - 1 {
        if $l.substr($i, 2) eq '<<' {
            $start = $i if $i == 0 or $l.substr($i - 1, 1) ne '<';
        }
        $i++;
    }
    return Nil if $start < 0;

    my $tag = $l.substr($start + 2);
    return Nil if $tag eq '';
    # 允许一个前缀字符（'-' 或引号）
    my $first = $tag.substr(0, 1);
    if $tag.chars > 1 and ($first eq q{-} or $first eq q{'} or $first eq q{"}) {
        $tag = $tag.substr(1);
    }
    $tag = $tag.trim;
    $tag eq '' ?? Nil !! $tag;
}

# 位置 i 处若是 smart quote，返回
#   %( close => 闭合记号, next-index => 下一个要扫的字符下标, interp => 是否可插值 )
sub smart-quote-at(Str $line, Int $i --> Hash) {
    return Nil unless $line.substr($i, 1) eq 'q' or $line.substr($i, 1) eq 'Q';

    # 前一个字符必须是「一个式子的开头」。否则 `unique(...)` 里的 `q`
    # 会被当成 `q(` 引号，整行从此按字符串算（连带把后面的 `{` 一起吃掉）。
    if $i > 0 {
        my $prev = $line.substr($i - 1, 1);
        return Nil if $prev ~~ /\w/ or $prev eq '_' or $prev eq '.' or $prev eq '$';
    }

    # 10 足够覆盖 `qq:to<...>` 这类最长的前缀；不够就让下面的 return Nil 兜住。
    my $rest = $line.substr($i, ($line.chars - $i) min 10);
    return Nil if $rest.chars < 2;

    my Int $j   = 1;
    my Str $var = $line.substr($i, 1);       # q / Q
    # 区分 q / qq / qw / qx / Q / QQ —— **只有 qq / QQ / qx 会插值**
    while $j < $rest.chars {
        my $c1 = $rest.substr($j, 1);
        last unless $c1 eq 'q' or $c1 eq 'Q' or $c1 eq 'w' or $c1 eq 'x';
        $var ~= $c1;
        $j++;
    }
    # 跳过 :adverb（形如 :s :x :2,4 —— 冒号后是字母数字逗号）
    my Str $adv = q{};
    if $j < $rest.chars and $rest.substr($j, 1) eq ':' {
        $j++;
        while $j < $rest.chars {
            my $ch = $rest.substr($j, 1);
            # 用查表而不是字符类/正则：Raku 里 `[a-zA-Z0-9,]` 的 `-` 会被当元字符报错。
            # 注意 Raku 的 `index` **找不到时返回 Nil 而不是 -1**，直接 `< 0` 会报
            # "Use of Nil in numeric context" —— 要先判 defined。
            last unless index($ADVERB-CHARS, $ch).defined;
            $adv ~= $ch;
            $j++;
        }
    }
    return Nil if $j >= $rest.chars;

    my $opener = $rest.substr($j, 1);
    # `// q{}` important: Hash lookup miss returns Nil, and `Nil eq q{}` warns
    # "Use of uninitialized value $close". A plain empty-string fallback keeps
    # the warning away and still returns Nil right below (no bogus frame).
    my $close = %OPEN-TO-CLOSE{$opener} // q{};
    $close = '>' if $opener eq '<';
    return Nil if $close eq '';

    my Bool $interp = ($var eq 'qq' or $var eq 'QQ' or $var eq 'qx'
                       or $adv.contains('x'));
    %( close => $close, next-index => $i + $j + 1, interp => $interp );
}

# 一行以运算符 / 逗号结尾 -> 没写完
sub ends-on-trailing-token(Str $line --> Bool) {
    return False if $line eq '';
    if $line.chars >= 2 {
        my $two = $line.substr($line.chars - 2, 2);
        return True if @TRAILING.first(* eq $two);
    }
    my $one = $line.substr($line.chars - 1, 1);
    return True if @TRAILING.first(* eq $one);
    False
}