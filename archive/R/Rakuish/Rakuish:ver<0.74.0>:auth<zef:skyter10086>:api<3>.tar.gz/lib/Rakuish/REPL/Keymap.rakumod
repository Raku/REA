unit module Rakuish::REPL::Keymap;

# Rakuish::REPL::Keymap —— Vi/Helix 模态编辑与键位预设（0.66 / ADR-0003），
# 以及 Ctrl-C 输入中断（0.71 / ADR-0008）。
#
# 三层：
#   · ViState            纯逻辑的单行模态编辑模型（缓冲/光标/撤销/yank）；
#   · InterruptCLIInput  CLIInput 子类：把 Ctrl-C 的 abort 收敛成「中断输入」
#                        而不是宿主 EOF（0.71 / ADR-0008 §3.1）；
#   · ViCLIInput         继承 InterruptCLIInput，把模态接进真实行编辑器。
#
# 行编辑器 0.0.23 的 keymap 只接受「已存在的 edit action」，dispatch 是硬编码
# when 链、没有自定义回调。因此这里覆盖 decode-keyname / special-actions /
# input-class / prompt 四个方法，不复制 read-input、不 fork 依赖。构造失败由
# make-cli 自动回退到原生 CLIInput + Alt-* 键位预设（回退后 Ctrl-C 是 0.70
# 行为，HANDOFF §10 如实记录）。

use Terminal::LineEditor;
use Rakuish::REPL::Highlight;   # 输入行着色（0.74.0 / ADR-0011 §4）

# 高亮开关：入口按颜色能力每格刷新。默认开，但非 TTY 时入口会关掉。
my Bool $HL-ON = True;
our sub set-highlight(Bool $on --> Nil) is export { $HL-ON = $on }
use Terminal::LineEditor::RawTerminalInput;

# ── 会话级模态状态（单例；一个 REPL 进程只有一个行编辑器）─────────────
class ViState is export {
    has Str  $.mode       is rw = 'insert';   # insert / normal / select
    has Str  $.start-mode is rw = 'insert';   # 每行起始模式
    has Str  $.buffer     is rw = '';
    has Int  $.cursor     is rw = 0;
    has Bool $.pending-d  is rw = False;
    has Str  $.yank       is rw = '';
    has @!undo;

    method mode-label(--> Str) {
        given $!mode {
            when 'normal' { 'NORMAL' }
            when 'select' { 'SELECT' }
            default       { 'INSERT' }
        }
    }

    method set-mode(Str $m --> Str) {
        $!mode = ($m eq 'normal' || $m eq 'select') ?? $m !! 'insert';
        $!pending-d = False;
        $!mode
    }

    method start-line(Str :$text = '', Str :$mode = $!start-mode --> Nil) {
        @!undo = ();
        $!buffer = $text;
        $!cursor = $text.chars;
        $!pending-d = False;
        $!mode = $mode;
        Nil
    }

    method !snapshot(--> Nil) {
        @!undo.push([$!buffer, $!cursor]);
        @!undo.shift while @!undo.elems > 100;
        Nil
    }

    method insert(Str $s --> Str) {
        self!snapshot;
        $!buffer = $!buffer.substr(0, $!cursor) ~ $s ~ $!buffer.substr($!cursor);
        $!cursor += $s.chars;
        $!buffer
    }

    method move(Int $d --> Int) {
        my Int $c = $!cursor + $d;
        $!cursor = $c < 0 ?? 0 !! ($c > $!buffer.chars ?? $!buffer.chars !! $c);
        $!cursor
    }

    method move-start(--> Int) { $!cursor = 0 }
    method move-end(--> Int)   { $!cursor = $!buffer.chars }

    method backspace(--> Str) {
        return $!buffer if $!cursor == 0;
        self!snapshot;
        $!buffer = $!buffer.substr(0, $!cursor - 1) ~ $!buffer.substr($!cursor);
        $!cursor--;
        $!buffer
    }

    method delete-char(--> Str) {
        return $!buffer if $!cursor >= $!buffer.chars;
        self!snapshot;
        $!yank = $!buffer.substr($!cursor, 1);
        $!buffer = $!buffer.substr(0, $!cursor) ~ $!buffer.substr($!cursor + 1);
        $!buffer
    }

    method delete-to-end(--> Str) {
        return $!buffer if $!cursor >= $!buffer.chars;
        self!snapshot;
        $!yank = $!buffer.substr($!cursor);
        $!buffer = $!buffer.substr(0, $!cursor);
        $!buffer
    }

    method delete-line(--> Str) {
        self!snapshot;
        $!yank = $!buffer;
        $!buffer = '';
        $!cursor = 0;
        $!buffer
    }

    method word-forward(--> Int) {
        my @c = $!buffer.comb;
        my Int $i = $!cursor;
        $i++ while $i < @c.elems && @c[$i] ~~ /\s/;
        $i++ while $i < @c.elems && @c[$i] !~~ /\s/;
        $!cursor = $i < @c.elems ?? $i !! @c.elems;
    }

    method word-back(--> Int) {
        my @c = $!buffer.comb;
        my Int $i = $!cursor;
        $i-- while $i > 0 && @c[$i - 1] ~~ /\s/;
        $i-- while $i > 0 && @c[$i - 1] !~~ /\s/;
        $!cursor = $i < 0 ?? 0 !! $i;
    }

    method undo(--> Str) {
        return $!buffer unless @!undo.elems;
        my $prev = @!undo.pop;
        $!buffer = $prev[0];
        $!cursor = $prev[1];
        $!buffer
    }

    method paste(--> Str) { self.insert($!yank) }

    # 处理一个 Vi 键，返回动作名；宿主可用它驱动自己的前端。
    method handle(Str $key --> Str) {
        if $!mode eq 'insert' {
            if $key eq 'Escape' || $key eq 'Ctrl-[' {
                self.set-mode('normal');
                return 'normal';
            }
            given $key {
                when 'Backspace'        { self.backspace; 'backspace' }
                when 'Enter' | 'Ctrl-M' | 'Ctrl-J' { 'submit' }
                default {
                    return 'ignore' unless $key.chars == 1;
                    self.insert($key);
                    'insert'
                }
            }
        }
        else {
            if $key eq 'Escape' || $key eq 'Ctrl-[' {
                self.set-mode('normal');
                return 'normal';
            }
            given $key {
                when 'i'    { self.set-mode('insert'); 'insert-mode' }
                when 'a'    { self.move(1); self.set-mode('insert'); 'append' }
                when 'A'    { self.move-end; self.set-mode('insert'); 'append-end' }
                when 'I'    { self.move-start; self.set-mode('insert'); 'insert-start' }
                when 'o' | 'O' { self.delete-line; self.set-mode('insert'); 'open' }
                when 'v'    { self.set-mode('select'); 'select' }
                when 'd'    {
                    if $!pending-d {
                        $!pending-d = False;
                        self.delete-line;
                        'delete-line'
                    }
                    else { $!pending-d = True; 'pending-d' }
                }
                default {
                    $!pending-d = False;
                    given $key {
                        when 'h' { self.move(-1); 'move-left' }
                        when 'l' { self.move(1);  'move-right' }
                        when '0' { self.move-start; 'move-start' }
                        when '$' { self.move-end;   'move-end' }
                        when 'w' { self.word-forward; 'word-forward' }
                        when 'b' { self.word-back;    'word-back' }
                        when 'e' { self.word-forward; 'word-end' }
                        when 'x' { self.delete-char;  'delete-char' }
                        when 'D' { self.delete-to-end; 'delete-to-end' }
                        when 'u' { self.undo;         'undo' }
                        when 'p' { self.paste;        'paste' }
                        when 'j' { 'history-next' }
                        when 'k' { 'history-prev' }
                        when 'Enter' | 'Ctrl-M' | 'Ctrl-J' { 'submit' }
                        default  { 'ignore' }
                    }
                }
            }
        }
    }
}

my ViState $VI = ViState.new;
sub vi-state(--> ViState) is export { $VI }

# ── Ctrl-C 中断（0.71 / ADR-0008 §3.1）──────────────────────────────
# 依赖的 read-input 把 `Ctrl-C => abort-input` 变成「返回未定义 Str」，宿主
# 会当 EOF 退出。这里不碰 read-input：只在解码层记下这次 abort 是 Ctrl-C，
# 在 prompt 层把它收敛成「定义的空行 + 一次性可查询标志」。
# 真 EOF 与 Ctrl-D 依旧返回未定义 Str，退出语义一字未改。
# 带语法着色的输入字段（0.74.0 / ADR-0011 §4）。
#
# 为什么覆盖 visible-input-field-string 而不是 render：
#   render 还负责 recompute-widths / scroll-to-insert-pos，覆盖它风险更大；
#   visible-input-field-string 恰好是「左标记 + 内容 + padding + 右标记」的
#   那一层，只有中间那段该上色。
#
# 为什么要复制父类的截取逻辑：要着色就必须知道内容段在 buffer 里的边界，
# 而父类不把这个位置暴露出来。这里用的 scroll-cursor / available-width /
# substring-width 都是公开访问器，复制的是**同一个算法**。代价是依赖
# LineEditor 内部（HANDOFF 已记录的已知缺口），升级依赖时要回头看这里。
#
# 不变式：着色串的**纯文本部分**必须与不染色时逐字符相同。父类用
# display-width（对 buffer 内容算出的显示宽度）定位光标与清屏，多一个可见
# 字符就会错位。
my class HlField is Terminal::LineEditor::ScrollingSingleLineInput::ANSI {
    method visible-input-field-string() {
        # 关掉高亮、或这是掩码输入（密码）时，原样交给父类。
        return callsame() unless $HL-ON && !$.mask.defined;

        my Int $sp    = $.scroll-cursor.pos;
        my Str $buf   = $.buffer.contents;
        my Int $avail = self.available-width;

        my Int $last = $.insert-cursor.pos;
        my Int $end  = $.insert-cursor.end;
        ++$last while $last < $end && self.substring-width($sp, $last) < $avail;
        --$last if self.substring-width($sp, $last) > $avail;

        my Str $shown = highlight-line(substr($buf, $sp, $last - $sp));

        my Str $string = $sp ?? $.left-scroll-mark !! $.left-no-scroll-mark;
        $string ~= $shown;
        $string ~= ' ' x ($avail - self.substring-width($sp, $last));
        $string ~= $last < $end ?? $.right-scroll-mark !! $.right-no-scroll-mark;
        $string;
    }
}

my class InterruptCLIInput is Terminal::LineEditor::CLIInput {
    has Bool $!interrupted = False;

    method decode-keyname($input) {
        my $key = callsame();
        $!interrupted = True if $key.defined && $key eq 'Ctrl-C';
        $key
    }

    # 一次性消费；宿主借它区分「Ctrl-C 中断」与「用户真的敲了空行」。
    method take-interrupt(--> Bool) {
        return False unless $!interrupted;
        $!interrupted = False;
        True
    }

    method prompt(Str:D $prompt = '', Str :$mask --> Str) {
        $!interrupted = False;
        my $in = callsame();
        $in.defined ?? $in !! ($!interrupted ?? '' !! Str)
    }

    # 0.74.0：CLIInput 的 input-class 是个属性（默认原生字段类），这里用方法
    # 覆盖掉，让 emacs 模式也走带高亮的字段类。三种 edit-mode 表现一致。
    method input-class() { HlField }
}

# ── 真实行编辑器接线 ─────────────────────────────────────────────────
my class ViField is HlField {
    method edit-vi-normal()       { vi-state().set-mode('normal'); False }
    method edit-vi-insert()       { vi-state().set-mode('insert'); False }
    method edit-vi-select()       { vi-state().set-mode('select'); False }
    method edit-vi-append() {
        self.edit-move-char-forward();
        vi-state().set-mode('insert');
        True
    }
    method edit-vi-append-end() {
        self.edit-move-to-end();
        vi-state().set-mode('insert');
        True
    }
    method edit-vi-insert-start() {
        self.edit-move-to-start();
        vi-state().set-mode('insert');
        True
    }
    method edit-vi-open() {
        self.edit-delete-to-start();
        self.edit-delete-to-end();
        vi-state().set-mode('insert');
        True
    }
    method edit-vi-d() {
        if vi-state().pending-d {
            vi-state().pending-d = False;
            self.edit-delete-to-start();
            self.edit-delete-to-end();
            True
        }
        else { vi-state().pending-d = True; False }
    }
}

my class ViCLIInput is InterruptCLIInput {
    method input-class() { ViField }

    method special-actions() {
        my %s = callsame().keys.map({ $_ => True });
        %s{$_} = True for <vi-normal vi-insert vi-select vi-append
                           vi-append-end vi-insert-start vi-open vi-d>;
        set(%s.keys)
    }

    method decode-keyname($input) {
        return 'Escape' if $input ~~ Str && $input.chars == 1 && $input.ord == 27;
        if vi-state().mode ne 'insert' && $input ~~ Str
           && $input.chars == 1 && $input.ord >= 32 && $input.ord < 127 {
            vi-state().pending-d = False if $input ne 'd';
            return 'vi-' ~ $input;
        }
        callsame()
    }

    method prompt(Str:D $prompt = '', Str :$mask --> Str) {
        vi-state().start-line(:mode(vi-state().start-mode));
        callsame()
    }
}

# 模态键位：可打印字符在 normal 模式下由 decode-keyname 变成 vi-<char>。
sub vi-actions(--> Hash) is export {
    %(
        'Escape' => 'vi-normal',
        'vi-i'   => 'vi-insert',
        'vi-a'   => 'vi-append',
        'vi-A'   => 'vi-append-end',
        'vi-I'   => 'vi-insert-start',
        'vi-o'   => 'vi-open',
        'vi-O'   => 'vi-open',
        'vi-v'   => 'vi-select',
        'vi-d'   => 'vi-d',
        'vi-h'   => 'move-char-back',
        'vi-l'   => 'move-char-forward',
        'vi-0'   => 'move-to-start',
        'vi-$'   => 'move-to-end',
        'vi-w'   => 'move-word-forward',
        'vi-b'   => 'move-word-back',
        'vi-e'   => 'move-word-forward',
        'vi-x'   => 'delete-char-forward',
        'vi-D'   => 'delete-to-end',
        'vi-u'   => 'undo',
        'vi-p'   => 'yank',
        'vi-j'   => 'history-next',
        'vi-k'   => 'history-prev',
    )
}

# Alt-* 预设：即使回退到原生 CLIInput 也能用（全部是依赖已有的 edit action）。
sub keymap-preset(Str $style --> Hash) is export {
    my %common = (
        'Alt-h' => 'move-char-back',
        'Alt-l' => 'move-char-forward',
        'Alt-j' => 'history-next',
        'Alt-k' => 'history-prev',
        'Alt-a' => 'move-to-start',
        'Alt-e' => 'move-to-end',
        'Alt-w' => 'move-word-forward',
        'Alt-b' => 'move-word-back',
        'Alt-u' => 'undo',
    );
    given $style.lc {
        when 'vi' {
            %common<Alt-x> = 'delete-char-forward';
            %common<Alt-d> = 'delete-word-forward';
            %common
        }
        when 'helix' {
            %common<Alt-x> = 'delete-to-end';
            %common<Alt-d> = 'delete-to-start';
            %common<Alt-c> = 'move-word-forward';
            %common
        }
        default { %() }   # emacs：不改默认 keymap
    }
}

sub apply-keymap($cli, Str $style --> Int) is export {
    return 0 unless $cli.defined && $cli.^can('bind-key');
    my Int $n = 0;
    for keymap-preset($style).kv -> $k, $v {
        try { $cli.bind-key($k, $v); $n++ }
    }
    $n
}

sub bind-vi-keys($cli --> Int) is export {
    return 0 unless $cli.defined;
    my Int $n = 0;
    for vi-actions().kv -> $k, $v {
        try { $cli.bind-key($k, $v); $n++ }
    }
    $n
}

# 构造行编辑器：vi/helix 用子类；任何异常都回退到原生 CLIInput。
sub make-cli(Str :$style = 'emacs', Str :$start-mode = 'insert',
             :&get-completions --> Any) is export {
    vi-state().start-mode = $start-mode.lc eq 'normal' ?? 'normal' !! 'insert';
    vi-state().set-mode(vi-state().start-mode);

    my $cli;
    if $style.lc eq 'vi' || $style.lc eq 'helix' {
        $cli = try { ViCLIInput.new(:&get-completions) };
        if $cli.defined {
            my Int $bound = bind-vi-keys($cli);
            # 一个都没绑上说明依赖内部结构变了，退回安全路径。
            $cli = Nil if $bound == 0;
        }
    }
    unless $cli.defined {
        # emacs 也走中断子类：三种 edit-mode 的 Ctrl-C 语义必须一致。
        $cli = try { InterruptCLIInput.new(:&get-completions) };
    }
    # 依赖升级导致子类构造失败时仍给出可用的行编辑器；此时 Ctrl-C 退回
    # 0.70 行为（abort == EOF），由 HANDOFF §10 如实记录，不假装修好。
    unless $cli.defined {
        $cli = try { Terminal::LineEditor::CLIInput.new(:&get-completions) };
    }
    apply-keymap($cli, $style) if $cli.defined;
    $cli
}
