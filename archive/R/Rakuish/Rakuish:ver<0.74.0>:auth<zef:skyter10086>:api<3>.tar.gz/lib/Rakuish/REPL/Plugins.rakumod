unit module Rakuish::REPL::Plugins;

# Rakuish::REPL::Plugins —— 显式本地 Raku 插件（0.66 / ADR-0003 §3.3）。
#
# 插件就是一个 Raku 文件，最后一个表达式求值为 Command 对象或 List[Command]。
# 加载即执行本地 Raku 代码（等同 use 一个本地模块），因此：
#   · 默认关闭，必须 config set plugins on；
#   · 路径经 Sys.resolve 做 root 校验，源码经 Sys.read，不联网、不自动扫描；
#   · 只注册到会话 CommandRegistry，不进 Shell 薄层文本命令表；
#   · Agent 的 op 白名单不暴露 plugin，Sandbox 不加载插件。
#
# 插件的 run($sys, ...) 拿到会话 Sys，必须用它做文件/进程操作（HANDOFF §7）。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Command;
use Rakuish::Data::Table;

my class Sink {
    has @.buf is rw;
    method print(*@a) { @!buf.push(@a.map(*.Str).join); True }
    method say(*@a)   { @!buf.push(@a.map(*.Str).join ~ "\n"); True }
    method put(*@a)   { @!buf.push(@a.map(*.Str).join("\n") ~ "\n"); True }
    method flush()    { Nil }
    method nl-out()   { "\n" }
    method text()     { @!buf.join }
}

class PluginManager is export {
    has %.loaded is rw;

    method enabled(%config --> Bool) {
        (%config<plugins> // 'off').Str.lc eq 'on'
    }

    method names(--> List) { %!loaded.keys.sort.List }

    method commands(Str $name --> List) {
        my $p = %!loaded{$name};
        $p.defined ?? ($p<commands> // []).List !! ().List
    }

    method info(Str $name --> Str) {
        my $p = %!loaded{$name};
        return "未加载插件: $name" unless $p.defined;
        ("插件 $name",
         "  路径: {$p<path>}",
         "  命令: {($p<commands> // []).join(', ')}",
         "  加载: {$p<at>}").join("\n")
    }

    method list(--> Rakuish::Data::Table) {
        Rakuish::Data::Table.from-rows(
            self.names.map(-> $n {
                my $p = %!loaded{$n};
                { name => $n, commands => ($p<commands> // []).join(', '),
                  path => $p<path>, loaded => $p<at> }
            }).List
        )
    }

    method load(Rakuish::Sys $sys, CommandRegistry $reg, Str $path,
                Bool :$enabled = False --> Result) {
        return Result.new(:!ok, :code(403), :op<plugin>,
            :err('插件加载默认关闭；先 config set plugins on（加载即执行本地 Raku 代码）'))
            unless $enabled;
        return Result.new(:!ok, :code(2), :op<plugin>,
            :err('用法: plugin load PATH')) unless $path.chars;

        my $resolved = try { $sys.resolve($path) };
        return Result.new(:!ok, :code(403), :op<plugin>,
            :err("插件路径越界: $path")) unless $resolved.defined;
        my Str $ext = $resolved.extension.lc;
        return Result.new(:!ok, :code(2), :op<plugin>,
            :err('插件必须是 .rakumod / .raku 文件'))
            unless $ext eq 'rakumod' || $ext eq 'raku';
        return Result.new(:!ok, :code(2), :op<plugin>,
            :err("插件文件不存在: $path")) unless $resolved.e;

        my Str $src = try { $sys.read($path) };
        return Result.new(:!ok, :code(2), :op<plugin>,
            :err("读取插件失败: $path")) unless $src.defined;

        my $sink = Sink.new;
        my Str $err = '';
        my $obj;
        {
            CATCH { default { $err = .message } }
            temp $*OUT = $sink;
            $obj = EVAL $src;
        }
        return Result.new(:!ok, :code(2), :op<plugin>,
                          :err("插件求值失败: $err"), :out($sink.text))
            if $err.chars || !$obj.defined;

        my @cmds = ($obj ~~ Positional ?? $obj.List !! ($obj,))
            .grep({ $_ ~~ Command }).List;
        return Result.new(:!ok, :code(2), :op<plugin>,
            :err('插件必须返回 Command 对象或 List[Command]'), :out($sink.text))
            unless @cmds.elems;

        my Str $name = $resolved.basename;
        # 重名文件重加载：先卸载自己注册的命令，再检查是否与内建/其它插件冲突。
        self.unload($reg, $name) if %!loaded{$name}:exists;
        for @cmds -> $c {
            return Result.new(:!ok, :code(409), :op<plugin>,
                :err("命令名冲突: {$c.name}（不能覆盖内建或其它插件命令）"),
                :out($sink.text))
                if $reg.has($c.name);
        }

        for @cmds -> $c { $reg.register($c) }
        %!loaded{$name} = {
            path => $resolved.Str,
            commands => @cmds.map(*.name).List,
            at => DateTime.now.Str,
        };
        my Str $note = "已加载 $name: " ~ @cmds.map(*.name).join(', ');
        $note ~= "\n" ~ $sink.text.trim if $sink.text.trim.chars;
        Result.new(:ok, :op<plugin>, :value(@cmds.map(*.name).List), :out($note))
    }

    method unload(CommandRegistry $reg, Str $name --> Result) {
        my $p = %!loaded{$name};
        return Result.new(:!ok, :code(2), :op<plugin>,
                          :err("未加载插件: $name")) unless $p.defined;
        for ($p<commands> // []).List -> $c { $reg.remove($c) }
        %!loaded{$name}:delete;
        Result.new(:ok, :op<plugin>, :value($name),
                   :out("已卸载 $name"));
    }
}
