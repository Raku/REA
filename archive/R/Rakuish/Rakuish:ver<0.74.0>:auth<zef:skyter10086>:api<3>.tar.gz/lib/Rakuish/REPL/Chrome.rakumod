unit module Rakuish::REPL::Chrome;

# Rakuish::REPL::Chrome —— REPL 的展示层（banner / prompt / 时间 / 耗时）
#
# 这里只有**纯展示逻辑**：拼字符串、判断颜色能力、缩短路径、格式化耗时。
# 不求值、不注册命令、不解析输入，也不绕过 Sys 读写文件（git 分支查询用
# 传入的 Sys 实例）。因此它可以在非 TTY 的测试里被直接断言。
#
# 风格约定（产品确认过，别改回字符拼字）：
#   · 字标就是 `  Rakuish` + 一条细分割线，不用 ASCII art / 制表符拼大字；
#   · 颜色只在 TTY 且未设置 NO_COLOR 时出现，管道/脚本一律纯文本；
#   · `%` 是 Raku 哈希，这里没有任何 magic 分流。

use Rakuish::Sys;

my constant RESET     = "\e[0m";
my constant BOLD-CYAN = "\e[1m\e[36m";
my constant DIM       = "\e[2m";
my constant GRAY      = "\e[90m";
my constant RED       = "\e[31m";
my constant GREEN     = "\e[32m";
my constant YELLOW    = "\e[33m";

my %BRANCH-CACHE;

# 0.74.0 / ADR-0011：结果渲染与输入行高亮共用的一张色表。
# 导出的是色表而不是我的私有常量，让「哪种东西该是什么颜色」只有一份定义；
# 渲染层只做 `paint($s, %CLR<dir>, $color)`，不自己拼转义序列。
our constant %CLR is export =
    reset    => RESET,
    dim      => DIM,
    gray     => GRAY,
    red      => RED,
    green    => GREEN,
    yellow   => YELLOW,
    blue     => "\e[34m",
    cyan     => "\e[36m",
    'b-cyan'  => BOLD-CYAN,
    'b-blue'  => "\e[1m\e[34m",
    'b-green' => "\e[1m\e[32m";

our sub paint(Str $s, $code, Bool $color --> Str) is export {
    # $code 允许是 Any：渲染层常从色表按条件取值，取不到就该原样输出，
    # 而不是在这里抛类型错误（那会把「不着色」变成「渲染崩掉」）。
    my Str $c = $code.defined ?? $code.Str !! '';
    $color && $c.chars ?? $c ~ $s ~ RESET !! $s
}

# 路径按类型取色（0.74.0 / ADR-0011）。顺序必须是 链接 → 目录 → 可执行：
# 目录通常也带执行位，先判可执行会把目录染成绿色。不存在的路径（glob 之后
# 被删）退化为无色，不抛异常 —— 列个目录不该因为一个失效条目而失败。
our sub path-color(IO::Path $p --> Str) is export {
    return %CLR<cyan>    if (try { $p.l });
    return %CLR<b-blue>  if (try { $p.d });
    return %CLR<b-green> if (try { $p.x });
    '';
}

# 颜色能力：NO_COLOR 强制关，FORCE_COLOR 非 0 强制开，否则看 TTY + 偏好。
# $tty 由入口传入（$*IN.t / $*OUT.t 在嵌入式宿主里可能不可靠）。
our sub color-mode(Str $pref = 'auto', Bool :$tty = False --> Bool) is export {
    return False if (%*ENV<NO_COLOR> // '').Str.chars;
    my Str $fc = (%*ENV<FORCE_COLOR> // '').Str;
    return True if $fc.chars && $fc ne '0';
    return False unless $tty;
    return True  if $pref.lc eq 'on'    || $pref.lc eq 'always';
    return False if $pref.lc eq 'off'   || $pref.lc eq 'never';
    True                                  # auto：TTY 即开
}

our sub stamp(--> Str) is export {
    DateTime.now.Str.substr(0, 19).subst('T', ' ')
}

our sub clock(--> Str) is export {
    DateTime.now.Str.substr(11, 8)
}

# 家目录缩成 ~，长路径只保留尾部三段，避免 prompt 吃掉半行。
our sub shorten-path(Str $p --> Str) is export {
    return $p if $p eq '';
    my Str $s = $p.subst(:g, '\\', '/');
    my Str $home = (try { $*HOME.Str }) // '';
    if $home.chars {
        my Str $h = $home.subst(:g, '\\', '/');
        $s = '~' ~ $s.substr($h.chars) if $s eq $h || $s.starts-with($h ~ '/');
    }
    my @segs = $s.split('/').grep({ .chars });
    return $s if @segs.elems <= 3;
    my Str $tail = @segs.tail(3).join('/');
    $s.starts-with('~/') ?? '~/.../' ~ $tail !! '/.../' ~ $tail
}

# 接受 Duration 或数值秒；不做四舍五入到 0（亚毫秒给 `<1ms`）。
our sub format-elapsed($d --> Str) is export {
    my $s = (try { $d.Num }) // 0e0;
    return '<1ms'                    if $s < 0.001;
    return sprintf('%.1fms', $s * 1000) if $s < 1;
    return sprintf('%.2fs',  $s)        if $s < 60;
    sprintf('%.1fm', $s / 60)
}

# git 分支：只读 .git/HEAD，不启动进程、不拼 shell 命令；文件访问一律走 Sys。
# 结果按 cwd 缓存，默认最多向上找 12 层。
our sub git-branch(Rakuish::Sys $sys, IO::Path $cwd --> Str) is export {
    my Str $key = $cwd.Str;
    return %BRANCH-CACHE{$key} if %BRANCH-CACHE{$key}:exists;
    my Str $found = '';
    my $dir = $cwd;
    for ^12 {
        my $git = $dir.add('.git');
        if (try { $sys.stat($git).is-dir }) {
            my $head = try { $sys.read($git.add('HEAD').Str) };
            if $head.defined && $head.chars {
                my Str $line = $head.lines[0] // '';
                $found = $line.starts-with('ref: refs/heads/')
                    ?? $line.substr(16).trim
                    !! '(detached)';
                $found = '(detached)' if $found eq 'HEAD';
            }
            last;
        }
        my $up = $dir.parent;
        last if $up.Str eq $dir.Str;
        $dir = $up;
    }
    %BRANCH-CACHE{$key} = $found;
    $found
}

our sub forget-branch-cache(--> Nil) is export {
    %BRANCH-CACHE = Hash.new;
    Nil
}

our sub banner-text(Str :$version!, Str :$cwd = '', Str :$editor = '',
                    Str :$mode = '', Str :$plugins = '',
                    Bool :$color = False --> Str) is export {
    my Str $raku = (try { $*RAKU.version.Str }) // '';
    my Str $vm   = (try { $*VM.config<name> })  // (try { $*VM.name }) // 'MoarVM';
    my @lines;
    @lines.push(paint('  Rakuish', BOLD-CYAN, $color)
                ~ paint('  v' ~ $version, GRAY, $color));
    @lines.push(paint('  ────────────────────────────────────────────────────────',
                      DIM, $color));
    @lines.push(paint('  Raku 原生命令与数据环境 · 输入即 Raku · ! 外部命令 · help() 帮助',
                      GRAY, $color));
    my @meta = stamp();
    @meta.push('Raku ' ~ $raku) if $raku.chars;
    @meta.push(~$vm);
    @meta.push(shorten-path($cwd)) if $cwd.chars;
    @meta.push('行编辑 ' ~ $editor) if $editor.chars;
    @meta.push('编辑模式 ' ~ $mode) if $mode.chars && $mode.lc ne 'emacs';
    @meta.push('插件 ' ~ $plugins) if $plugins.chars && $plugins ne '0';
    @lines.push(paint('  ' ~ @meta.join('  ·  '), GRAY, $color));
    @lines.join("\n") ~ "\n"
}

# 单行 prompt：时间 · cwd · git 分支 · 格号 · 状态/耗时 · 箭头。
# 状态与耗时来自入口记录的上格结果，Chrome 自己不持有会话状态。
our sub prompt-text(Str :$cwd!, Int :$index = 0, :$elapsed,
                    Bool :$ok = True, Int :$code = 0,
                    Str :$branch = '', Bool :$color = False,
                    Bool :$clock = True, Bool :$timing = True,
                    Bool :$continuing = False, Str :$style = 'full',
                    Str :$mode = '',
                    --> Str) is export {
    my Bool $use-color = $color && $style.lc ne 'plain';
    my Bool $compact   = $style.lc eq 'compact';
    return paint('  ··· ', DIM, $use-color) if $continuing;

    my @parts;
    @parts.push(paint(clock(), GRAY, $use-color)) if $clock && !$compact;
    @parts.push(paint(shorten-path($cwd), BOLD-CYAN, $use-color));
    @parts.push(paint('git:' ~ $branch, GREEN, $use-color))
        if $branch.chars && !$compact;
    @parts.push(paint("[{$index}]", GRAY, $use-color))
        if $index > 0 && !$compact;
    @parts.push(paint("[exit={$code}]", RED, $use-color))
        if !$ok && $code != 0 && !$compact;
    @parts.push(paint(format-elapsed($elapsed),
                      (!$ok ?? RED !! YELLOW), $use-color))
        if $timing && $elapsed.defined && !$compact;
    @parts.push(paint($mode, GREEN, $use-color))
        if $mode.chars && !$compact;

    my Str $arrow = $use-color ?? paint('❯ ', BOLD-CYAN, True) !! '> ';
    @parts.join('  ') ~ '  ' ~ $arrow
}
