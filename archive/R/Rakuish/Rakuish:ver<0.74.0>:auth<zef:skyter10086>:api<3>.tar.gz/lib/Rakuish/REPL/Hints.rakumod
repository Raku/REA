unit module Rakuish::REPL::Hints;

# Rakuish::REPL::Hints —— 上下文提示层（0.66 / ADR-0003 §3.2）。
#
# 行编辑器没有「输入变化」回调，所以 hints 不是输入中弹窗，而是「一格结束时
# 给下一格的提示」：命令用法摘要、结构化命令参数、失败格的下一步建议。
# 纯函数、无副作用、可测试；TTY 下的显示由入口决定。

use Rakuish::Result;

my constant SESSION-HINTS = %(
    'config'  => 'config get KEY | set KEY VALUE | unset KEY（会话级，写入 ~/.rakuish-config.json）',
    'alias'   => 'alias [name=命令]；unalias name 删除',
    'hook'    => 'hook add EVENT CODE | clear EVENT | run EVENT',
    'perf'    => 'perf [N] 查看每格耗时；timed { ... } / bench({ ... }) 手动计时',
    'explore' => 'explore [路径] 分页查看 Table；无参数看上一格',
    'plugin'  => 'plugin list | load PATH | unload NAME | info NAME（需 config set plugins on）',
    'hint'    => 'hint [输入行] 查看上下文提示；config set hints on|off',
    'history' => 'history 显示本会话输入；!! / !N / !$ 重跑历史',
    'describe' => 'describe [表名] 返回列摘要 Table；无参数摘要上一格 Table，表名需先 open-db(...)',
    'open-data' => 'open-data 文件 :allow-external :csv-options({ delimiter => ";" })；方言只在 Raku 层',
);

sub hint-for(Str $line, :$shell, :$registry --> Str) is export {
    my Str $t = $line.trim;
    return '' unless $t.chars;

    return '提示: --help / --version / --agent 是启动参数，在 shell 里用 `rakuish --help`'
        if $t ~~ /^ '--' \w+ $/;

    if $t.starts-with('!') {
        my Str $next = $t.chars > 1 ?? $t.substr(1, 1) !! '';
        return '交互式子进程：TTY 直通、无超时、输出不捕获；退出后回到 Rakuish'
            if $t.starts-with('! --tty') || $t.starts-with('! -t ');
        return '外部命令：argv-only，| > $ * && 原样当参数；不做 shell 解释'
            if $next ne '=' && $next ne '~';
    }

    my Str $cmd = $t.words[0] // '';
    return SESSION-HINTS{$cmd} if SESSION-HINTS{$cmd}:exists;

    if $shell.defined {
        my Str $usage = try { $shell.usage($cmd) } // '';
        return $usage.lines[0].trim if $usage.chars;
    }

    if $registry.defined && $registry.has($cmd) {
        my $spec = $registry.get($cmd).spec;
        my @p = $spec.params.map({ .name ~ (.required ?? '*' !! '') });
        return ($spec.summary.chars ?? $spec.summary !! $cmd)
            ~ (@p.elems ?? ' · 参数 ' ~ @p.join(', ') !! '');
    }

    ''
}

sub result-hint(Result $r, Str $line --> Str) is export {
    return '' if $r.ok;
    my Str $err = ($r.err // '').Str;
    my Str $t   = $line.trim;
    my Str $cmd = $t.words[0] // '';

    return '提示: 输入一律按 Raku 求值；查命令用 help() / registry.names，外部程序写 ! <exe>'
        if $err.contains('Undeclared') || $err.contains('未声明');
    # 0.70：普通 ! 命令超时最常见的真实原因就是想跑交互式 REPL。
    return '提示: 跑嵌套 REPL / 编辑器请用 tty-exec(\'<exe>\') 或 ! --tty <exe>（TTY 直通、无 30s 超时）'
        if $r.code == 124 && $t.starts-with('!');
    return '提示: 找不到命令；用 which <name> 查 PATH，或写 ! <exe> <args...>'
        if $r.code == 127;
    return '提示: .parquet 读写需要显式 :allow-external（Agent 不开放）'
        if $err.contains('allow-external') || $err.contains('Parquet');
    return '提示: 类型声明要单独成格才跨格持久；混合语句格不缓存'
        if $err.contains('class') || $err.contains('role') || $err.contains('grammar');
    return '提示: 参数形态不对；help ' ~ $cmd ~ ' 看用法，或 help --find 搜索'
        if $err.contains('用法') || $err.contains('参数');
    return '提示: 空行提交多行输入；config set hints off 可关闭这些提示'
        if $r.op eq 'more';
    ''
}
