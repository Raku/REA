unit module Rakuish::REPL::SqlComplete;

# Rakuish::REPL::SqlComplete —— SQL 字符串上下文补全
# （0.68 / ADR-0005 §3；0.69 增强 / ADR-0006 §4；
#  0.71 调用形态扩展 / ADR-0008 §3.2）。
#
# 纯函数：无文件 I/O、无进程、**不解析 SQL AST**、不碰 $*OUT。
# 只在「光标位于 '...' / "..." / q[...] 等不插值字符串内，且该字符串是
# query/cursor/execute/sql(...) 的参数（含 sql => / :sql( 具名形态）」时
# 给出候选；其它输入一律返回空，让 Shell 补全原样工作。
#
# 所有 Engine 调用都包在 try 里：驱动缺失 / 库被锁 / 元数据查询失败时
# 优雅退化成「没有补全」，绝不让 Tab 把 REPL 弄崩。
#
# 返回的是**完整替换行**（与 Shell.completions 的约定一致），不是词后缀。
#
# 0.69 明确不做 SQL AST 级补全：引解析器会拖住核心安装、DuckDB/SQLite 方言
# 不同、Tab 热路径不划算。这里只做启发式增强（别名、表前缀列、大小写风格）。
# 0.71 新增的 q[...] / 具名参数同样只是词法前缀判定，不碰候选生成；
# qq / Q / qx / heredoc 与嵌套 q[...] 仍是明确边界（ADR-0008 §4）。

my constant KEYWORDS = <
    select from where group by order having limit offset join left right inner
    outer on as and or not null is in like between asc desc distinct count sum
    avg min max insert into values update set delete create table describe show
    with union all case when then else end cast coalesce nullif round abs lower
    upper length trim substr date interval exists using natural cross full
>;

my constant CALLS = <
    query cursor execute sql sql_query sql-query query-sql
    read-csv read_csv write-csv write_csv
    read-parquet read_parquet write-parquet write_parquet
>;

# 别名解析的停用词：这些词出现在表名后时是子句，不是别名。
my constant STOP = <
    where join left right inner outer full cross natural on group order having
    limit offset union and or select set with by asc desc as using values
    insert update delete from lateral qualify when then else
>;

# 把关键字按用户已输入的片段大小写风格输出：sel→select、SEL→SELECT、Sel→Select。
sub style-keyword(Str $kw, Str $frag --> Str) {
    return $kw unless $frag.chars && $frag ~~ /<[A..Z]>/;
    return $kw.uc if $frag eq $frag.uc;
    return $kw.substr(0, 1).uc ~ $kw.substr(1)
        if $frag.substr(0, 1) eq $frag.substr(0, 1).uc;
    $kw
}

# from sales s / join users as u → { s => sales, u => users, sales => sales }。
# 没有别名时表名自身也能作前缀（sales.）。纯词法，不做 SQL 解析。
sub alias-map(Str $sql --> Hash) {
    my @t = $sql.words;
    my %map;
    for @t.kv -> $i, $tok {
        my Str $lead = $tok.lc.subst(/ ',' $ /, '');
        next unless $lead eq 'from' || $lead eq 'join';
        my Str $tbl = (@t[$i + 1] // '').subst(/ ',' $ /, '');
        next unless $tbl.chars && $tbl ~~ /^ <[A..Za..z_]> <[A..Za..z0..9_ .]>* $/;
        my Str $next = @t[$i + 2] // '';
        my Str $alias = '';
        if $next.lc eq 'as' {
            $alias = @t[$i + 3] // '';
        }
        elsif $next.chars && !($next.lc (elem) STOP)
              && $next ~~ /^ <[A..Za..z_]> \w* $/ {
            $alias = $next;
        }
        %map{$tbl.lc} = $tbl;
        %map{$alias.lc} = $tbl if $alias.chars;
    }
    %map
}

# 0.71 / ADR-0008 §3.2：不插值 q[...] 的分隔符对。
# qq / Q / qx / heredoc 明确不在此列（插值与转义语义不同）。
my %QPAIRS = (
    '[' => ']', '{' => '}', '(' => ')', '<' => '>',
);

# 返回空 Hash 表示「不是 SQL 上下文」。
# 命中时给出 frag（当前词）、word-start（该词在整行的起点）、mode、tail、
# quote-style（single / double / q）、aliases（别名→表）与 alias-table。
our sub sql-context(Str $line, Int $pos --> Hash) is export {
    my Int $at = ($pos max 0) min $line.chars;
    my Str $prefix = $line.substr(0, $at);

    # 扫描未闭合的字符串：'...' / "..."（0.68 原有）与
    # q[...] / q{...} / q(...) / q<...>（0.71 新增）。
    # 反斜杠按「跳过下一个字符」处理；不处理嵌套分隔符。
    my @c = $prefix.comb;
    my Str $closer = '';
    my Str $style  = '';
    my Int $open   = -1;
    my Int $start  = -1;
    my Int $i = 0;
    while $i < @c.elems {
        my Str $ch = @c[$i];
        if $closer eq '' {
            if $ch eq "'" || $ch eq '"' {
                $closer = $ch;
                $style  = $ch eq "'" ?? 'single' !! 'double';
                $open   = $i;
                $start  = $i + 1;
            }
            elsif $ch eq 'q'
                  && $i + 1 < @c.elems
                  && %QPAIRS.EXISTS-KEY(@c[$i + 1])
                  && ($i == 0 || !(@c[$i - 1] ~~ /<[\w]>/)) {
                # q 前必须是词边界，避免把标识符尾部的 q 当引号算子。
                $closer = %QPAIRS{@c[$i + 1]};
                $style  = 'q';
                $open   = $i;
                $start  = $i + 2;
                $i++;                      # 跳过开括号
            }
        }
        else {
            if $ch eq '\\' { $i += 2; next }
            if $ch eq $closer {
                $closer = '';
                $style  = '';
                $open   = -1;
                $start  = -1;
            }
        }
        $i++;
    }
    return %() if $closer eq '' || $open < 0 || $start < 0;

    my Str $before = $prefix.substr(0, $open);
    # 调用形态：name( / name(:sql( / name(sql => ；名字须在 CALLS 白名单。
    # 仍是「紧邻前缀」的词法判定，不扫描整行、不做括号配对回溯。
    my Str $tail-call = $before.substr(($before.chars - 100) max 0);
    return %() unless $tail-call ~~ m:ignorecase/
        (<[a..z A..Z _ -]>+) \s* '(' \s*
        [ ':sql' \s* '(' \s* | 'sql' \s* '=>' \s* ]? $
    /;
    my Str $call = ~$0;
    return %() unless $call.lc (elem) CALLS;

    my Str $sql = $prefix.substr($start);
    my $m = $sql ~~ / (<[\w]>* ) $/;
    my Str $frag = $m.defined ?? ~$m[0] !! '';
    my Int $word-start = $at - $frag.chars;

    # `s.am` → frag 是 am，前缀 s. 指向别名 s 对应的表；此时只补该表的列。
    my Str $pre = $sql.substr(0, $sql.chars - $frag.chars).lc;
    my %aliases = alias-map($pre);
    my $pm = $pre ~~ / (<[\w .]>+) '.' $/;
    my Str $alias-table = '';
    if $pm.defined {
        my Str $key = (~$pm[0]).lc;
        $alias-table = %aliases{$key} // '';
    }

    # 最近关键字启发式：from/join 后面补表名，select/where/... 后面补列名。
    my @tokens = $pre.words;
    my Str $last = @tokens.tail // '';
    my Str $mode = $alias-table.chars
                    ?? 'column'
                    !! $last eq 'from' | 'join' | 'into' | 'update' | 'table'
                       | 'describe' ?? 'table'
                    !! ($last eq 'select' | 'where' | 'having' | 'on' | 'set'
                        | 'by' | 'and' | 'or' || $pre.ends-with(',')) ?? 'column'
                    !! 'all';

    %( :$frag, :$word-start, :$mode, :$sql, :%aliases, :$alias-table,
       :quote-style($style), tail => $line.substr($at) )
}

sub table-names($engine --> List) {
    my $t = try { $engine.tables() };
    return () unless $t.defined;
    my @rows = try { $t.rows.List } // ();
    @rows.map(-> $r {
        my $v = $r ~~ Associative
            ?? ($r<name> // $r<Name> // $r<table_name> // $r.values[0])
            !! $r;
        ($v.defined ?? $v.Str !! '')
    }).grep(*.chars).List
}

sub column-names($engine, Str $sql, :@only --> List) {
    my @tables;
    if @only.elems {
        @tables = @only.List;
    }
    else {
        for $sql.lc.match(/ <|w> (from|join) \s+ (<[\w .]>+) /, :g) -> $hit {
            @tables.push(~$hit[1]) if $hit[1].defined;
        }
        @tables = table-names($engine).head(8) unless @tables.elems;
    }

    my @out;
    for @tables.unique -> $name {
        my $s = try { $engine.schema($name) };
        next unless $s.defined;
        my @rows = try { $s.rows.List } // ();
        for @rows -> $r {
            next unless $r ~~ Associative;
            my $v = $r<name> // $r<column_name> // $r<Name> // $r.values[0];
            @out.push($v.Str) if $v.defined && $v.Str.chars;
        }
    }
    @out.unique.List
}

our sub sql-completions(Str $line, Int $pos, :$engine --> List) is export {
    my %c = sql-context($line, $pos);
    return () unless %c<frag>:exists;

    my Str $frag = %c<frag>;
    my Str $mode = %c<mode>;
    my Str $alias-table = %c<alias-table> // '';
    my @cand;

    # `s.am` 只补 s 指向那张表的列，不塞关键字 / 其它表名。
    if $alias-table.chars {
        @cand.append(column-names($engine, %c<sql>, :only([$alias-table])))
            if $engine.defined;
    }
    else {
        @cand.append(KEYWORDS.map({ style-keyword($_, $frag) })
                              .grep({ .lc.starts-with($frag.lc) }))
            if $frag.chars || $mode eq 'all';

        if $engine.defined {
            @cand.append(table-names($engine))  if $mode ne 'column';
            @cand.append(column-names($engine, %c<sql>)) if $mode ne 'table';
        }
    }

    my Str $head = $line.substr(0, %c<word-start>);
    my Str $tail = %c<tail>;
    @cand.grep({ .defined })
         .map(*.Str)
         .grep({ .lc.starts-with($frag.lc) })
         .unique
         .sort
         .head(50)
         .map({ $head ~ $_ ~ $tail })
         .List
}
