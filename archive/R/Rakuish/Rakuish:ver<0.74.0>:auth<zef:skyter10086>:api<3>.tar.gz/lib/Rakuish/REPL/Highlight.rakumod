unit module Rakuish::REPL::Highlight;

# Rakuish::REPL::Highlight —— 输入行的轻量语法着色（0.74.0 / ADR-0011 §4）。
#
# 纯函数：单行、无状态、不 IO、不解析 AST、不碰 $*OUT。
#
# **唯一硬约束**（ADR-0011 §4.2）：
#   `strip-ansi(highlight-line($s)) eq $s` 必须恒成立。
# 因为行编辑器用 `display-width`（对 buffer 内容算出的显示宽度）定位光标和
# 清屏，而不是用绘制结果。着色只能插入**零宽**转义序列；一旦多出或少掉一个
# 可见字符，输入区就会错位。
#
# 刻意不做（不是遗漏）：`q[...]` / `qq[...]` / heredoc / 正则字面量 /
# 多行字符串 / pod。它们要么需要跨行状态（每次按键只看得见一行），要么需要
# 真正的 Raku 词法器；把半截输入染错色比不染更烦人。边界写进 MANUAL。
use Rakuish::REPL::Chrome;

my constant S-RESET   = %CLR<reset>;
my constant S-STRING  = %CLR<green>;
my constant S-COMMENT = %CLR<gray>;
my constant S-NUMBER  = %CLR<yellow>;
my constant S-VAR     = %CLR<cyan>;
my constant S-KEYWORD = %CLR{'b-blue'};

# 关键字表：只收「单独出现时几乎一定是关键字」的词。变量有 $/@/%/& 前缀，
# 走变量分支，不会被这里误伤；`say` / `put` 这类看起来像函数名的也收进来，
# 因为 Raku 里它们确实是关键字（不需要括号）。
my constant KEYWORDS = set <
    my our has sub method class role module grammar package
    use need require import export also is does but
    if else elsif unless with without given when default
    for loop while until repeat return last next redo
    die fail try CATCH CONTROL LEAVE ENTER KEEP UNDO
    say put print note warn dd
    True False Nil Any Mu Str Int Num Rat Bool Array Hash Set Bag Mix
    anon state constant subset enum multi proto only
    and or not so xor eq ne lt gt le ge cmp before after
    take gather lazy eager start await react supply whenever emit
    where of returns handles
>;

# 变量名里可能出现的字符（Raku 的 twigil 与二级 sigil 都在这里）。
# 不含 `(` / `[` / `{`：那三种是「$ 后跟表达式」的写法，不该被吞进变量名。
my constant VAR-CHARS = set <
    a b c d e f g h i j k l m n o p q r s t u v w x y z
    A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
    0 1 2 3 4 5 6 7 8 9 _ - * ! ? ^ . : < > +
>;

my sub seg(Str $s, Str $code --> Str) {
    return $s unless $s.chars && $code.chars;
    $code ~ $s ~ S-RESET;
}

# 单行着色。$color 为假时**逐字节原样返回**（不经过任何扫描）。
our sub highlight-line(Str $text, Bool :$color = True --> Str) is export {
    return $text unless $color;
    return $text unless $text.chars;

    my @c = $text.comb;
    my Int $n = @c.elems;
    my Str @out;
    my Int $i = 0;

    while $i < $n {
        my Str $ch = @c[$i];

        # ── 注释：吞到行尾 ──
        if $ch eq '#' {
            @out.push(seg(@c[$i ..^ $n].join, S-COMMENT));
            last;
        }

        # ── 字符串：单/双引号；`\` 跳过下一个字符；未闭合就染到行尾 ──
        # 未闭合（用户刚敲了引号）也照样上色，视觉上更像"字符串还开着"。
        if $ch eq "'" || $ch eq '"' {
            my Str $q = $ch;
            my Int $j = $i + 1;
            while $j < $n {
                if @c[$j] eq '\\' { $j += 2; next }
                if @c[$j] eq $q    { $j++; last }
                $j++;
            }
            $j = $n if $j > $n;
            @out.push(seg(@c[$i ..^ $j].join, S-STRING));
            $i = $j;
            next;
        }

        # ── 数字：整数 / 小数 / 下划线分组 / 指数 ──
        if $ch ~~ /^<digit>$/ {
            my Int $j = $i + 1;
            $j++ while $j < $n && @c[$j] ~~ /^<[0..9._eE]>$/;
            # 末尾的点不算数字的一部分（`1.` 是方法调用起点，Raku 里 1.abs）
            $j-- while $j > $i + 1 && @c[$j - 1] eq '.';
            @out.push(seg(@c[$i ..^ $j].join, S-NUMBER));
            $i = $j;
            next;
        }

        # ── 变量：$foo / @arr / %h / &code / $*CWD / $!attr ──
        if $ch eq any('$', '@', '%', '&') {
            my Int $j = $i + 1;
            $j++ while $j < $n && VAR-CHARS{@c[$j]};
            if $j > $i + 1 {
                @out.push(seg(@c[$i ..^ $j].join, S-VAR));
                $i = $j;
                next;
            }
            # 单独的 `$`（如 `$(...)` 的 sigil）原样输出
            @out.push($ch);
            $i++;
            next;
        }

        # ── 标识符 / 关键字 ──
        if $ch ~~ /^<[a..z A..Z _]>$/ {
            my Int $j = $i + 1;
            $j++ while $j < $n && (@c[$j] ~~ /^<[\w]>$/ || @c[$j] eq '-');
            my Str $w = @c[$i ..^ $j].join;
            @out.push(KEYWORDS{$w} ?? seg($w, S-KEYWORD) !! $w);
            $i = $j;
            next;
        }

        # ── 其余：逐字符原样输出（含空白、操作符、括号） ──
        @out.push($ch);
        $i++;
    }

    @out.join;
}
