unit class Rakuish::REPL::Session;

# Rakuish::REPL::Session —— API v3 的会话与求值器（ADR-0001 §2.3 / 设计 §5）。
#
# 输入只有两类，没有第三套语言：
#   · `!` 开头（第二个字符不是 = / ~）→ argv 便利入口，等价于 sys.exec(...)
#   · 其余全部（含 `%` 开头）        → Raku 表达式，直接 EVAL
#
# 明确**不做**的事（这是 Phase 3 的产品决策，别再加回来）：
#   · 没有 %magic 分流：`%STORE{...}` / `%RC<...>` 就是 Raku 哈希访问；
#   · 没有 auto-shell：Raku 求值失败就是失败，不偷偷转交外部程序；
#   · 没有反引号 shellq / 管道 / 重定向 / 变量展开 / glob 展开；
#   · 求值器自带，不复用 v2 的 eval-cell（它内置 expand-backticks）。
#
# 原 %magic 的 REPL 状态由本对象承载，用户写 `repl.history` / `repl.config`
# / `repl.trace = True`；纯交互动作（历史回调、外部编辑、中断）走快捷键，
# 见 key-bindings() / handle-key()。本对象**不提供文件 / 进程的旁路**。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Command;
use Rakuish::DSL;
use Rakuish::Data::Table;
use Rakuish::Data::Pager;
# 必须只加载、不导入：Rakuish::Data 也导出 open-data/save-data，但那是带
# $sys 的底层签名。若用 use 会覆盖 DSL 的同名导出，使 EVAL 里文档示例的
# open-data('x.csv') / save-data(...) 变成参数错误（0.69 修，V-165）。
need Rakuish::Data;
use Rakuish::REPL::Shell;
use Rakuish::REPL::Chrome;        # banner/prompt/耗时格式化（纯展示层）
use Rakuish::REPL::Keymap;        # Vi/Helix 模态与键位预设（ADR-0003）
use Rakuish::REPL::Hints;         # 上下文提示（纯函数）
use Rakuish::REPL::Plugins;       # 显式本地 Raku 插件
use Rakuish::REPL::SqlComplete;   # SQL 字符串上下文补全（ADR-0005，纯函数）
use Rakuish::Incomplete;          # 纯 Raku 多行续行，设计 §5.1 允许复用
use JSON::Fast;

my class CapturingOut {
    has @.buf is rw;
    method print(*@a) { @!buf.push(@a.map(*.Str).join); True }
    method say(*@a)   { @!buf.push(@a.map(*.Str).join ~ "\n"); True }
    method put(*@a)   { @!buf.push(@a.map(*.Str).join("\n") ~ "\n"); True }
    method flush()    { Nil }
    method nl-out()   { "\n" }
    method text()     { @!buf.join }
}

has Rakuish::Sys $.sys;
has CommandRegistry $.commands;
has Rakuish::REPL::Shell $.shell;
has PluginManager $.plugins;
has $.engine is rw;               # 当前会话数据引擎（open-db 注册，SQL 补全用）

method set-engine($e --> Nil) { $!engine = $e; Nil }

# ── 原 %magic 的 REPL 运行时状态（会话级，可读写）────────────────────
has @.history is rw;
has %.config  is rw;
has Bool $.trace is rw = False;
has Bool $.watch is rw = False;
has Bool $.perf  is rw = True;
# 0.74.0 / ADR-0011：结果渲染层的颜色开关，由入口按 Chrome::color-mode 传入。
# 默认 False 是刻意的 —— 忘记传参的调用点（测试、库内构造）一律退回纯文本，
# 绝不因为「代码路径没覆盖到」就给数据管道塞 ANSI。
has Bool $.color is rw = False;
has Bool $.bt    is rw = False;
has @.perf-hist is rw;
has Int  $.index is rw = 0;
has Bool $.exit-requested is rw = False;
has Int  $.exit-code      is rw = 0;
has Bool $.interrupt-requested is rw = False;
has Bool $.strict is rw = False;   # set -e 等价：失败格请求退出
has Bool $!expanding = False;      # 防历史替换递归

# ── 求值器内部状态 ───────────────────────────────────────────────────
has Str $.accum is rw = '';      # 兼容旧字段；不再用于整份重 EVAL
has Int $.shown is rw = 0;       # 已展示过的 stdout 长度（当前格）
has %.state;                    # 跨格持久化的顶层 my/our/state 变量
has @!decls;                    # 跨格持久化的纯 sub/class/use 声明
has @!pending;                  # 多行续行缓冲
has @!out;                      # 成功结果历史；Out[1] 是第一个成功格
has %!hinted;                   # hints 去重：同一首词只提示一次

submethod TWEAK() {
    unless $!sys.defined {
        # REPL/脚本是可信的本地环境：默认 root 是文件系统根，而不是启动 cwd。
        # 否则用户连 `cd ..` / 读绝对路径都做不到；Agent 入口仍要求显式 root。
        my IO::Path $root = $*DISTRO.is-win
            ?? IO::Path.new($*CWD.volume ~ '\\')
            !! IO::Path.new('/');
        # Windows 的 C:\ 只是当前盘根，不是“文件系统根”；REPL 应像 POSIX
        # root=/ 一样允许用户访问 D:/F: 等其他盘。Agent 走自己的 root，不受影响。
        $!sys = Rakuish::Sys.new(
            :root($root), :cwd($*CWD.IO),
            :all-drives($*DISTRO.is-win),
        );
    }
    $!commands = default-registry()  unless $!commands.defined;
    $!shell = Rakuish::REPL::Shell.new(:sys($!sys), :color($!color)) unless $!shell.defined;
    $!plugins = PluginManager.new unless $!plugins.defined;
    self!load-config;
    bind-session($!sys);
}

# ── 配置 / alias ─────────────────────────────────────────────────────
method config-path(--> IO::Path) {
    my $env = %*ENV<RAKUISH_CONFIG>;
    return IO::Path.new($env) if $env.defined && $env.chars;
    my $home = try { $*HOME } // $*CWD;
    $home.add('.rakuish-config.json');
}

method !load-config(--> Nil) {
    my $p = self.config-path;
    return unless $p.e;
    my $data = try { from-json($p.slurp) };
    %!config = $data.Hash if $data ~~ Hash;
    Nil
}

method !save-config(--> Nil) {
    my $p = self.config-path;
    try { $p.parent.mkdir unless $p.parent.d; $p.spurt(to-json(%!config, :pretty)); }
    Nil
}

method !aliases(--> Hash) {
    my $a = %!config<aliases>;
    $a ~~ Hash ?? $a !! %();
}

method !expand-alias(Str $line --> Str) {
    my Str $out = $line;
    my %a = self!aliases;
    for ^10 {
        my @parts = $out.split(/\s+/, 2);
        last unless @parts.elems;
        my Str $name = @parts[0];
        last unless %a{$name}:exists;
        my Str $rest = @parts.elems > 1 ?? @parts[1] !! '';
        $out = %a{$name}.Str ~ ($rest.chars ?? ' ' ~ $rest !! '');
    }
    $out
}

method !cmd-alias(Str $raw --> Result) {
    my Str $t = $raw.trim;
    if $t eq 'alias' {
        my @lines = self!aliases.keys.sort.map({ "{$_}={self!aliases{$_}}" });
        return Result.new(:ok, :op<alias>, :value(self!aliases),
                          :out(@lines.join("\n")));
    }
    my Str $rest = $t.substr(5).trim;
    if $rest.starts-with('--') {
        return Result.new(:!ok, :code(2), :op<alias>,
                          :err('用法: alias [name=command]'));
    }
    my Int $eq = $rest.index('=');
    my Str $name;
    my Str $value;
    if $eq.defined {
        $name  = $rest.substr(0, $eq).trim;
        $value = $rest.substr($eq + 1).trim;
    }
    else {
        my @p = $rest.split(/\s+/, 2);
        $name = @p[0] // '';
        $value = @p.elems > 1 ?? @p[1] !! '';
    }
    return Result.new(:!ok, :code(2), :op<alias>,
                      :err('用法: alias name=command')) unless $name.chars;
    if !$value.chars {
        %!config<aliases>{$name}:delete;
    }
    else {
        %!config<aliases>{$name} = $value;
    }
    self!save-config;
    Result.new(:ok, :op<alias>, :value($name), :out("alias {$name}={$value}"));
}

method !cmd-unalias(Str $raw --> Result) {
    my Str $name = $raw.trim.substr(8).trim;
    return Result.new(:!ok, :code(2), :op<unalias>,
                      :err('用法: unalias name')) unless $name.chars;
    %!config<aliases>{$name}:delete;
    self!save-config;
    Result.new(:ok, :op<unalias>, :value($name), :out("unalias {$name}"));
}

method !cmd-config(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines = %!config.keys.sort.map({
            my $v = %!config{$_};
            "{$_}={$v ~~ Str ?? $v !! to-json($v, :!pretty)}"
        });
        return Result.new(:ok, :op<config>, :value(%!config),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'get' && @args.elems >= 3 {
        my Str $k = @args[2];
        return Result.new(:!ok, :code(1), :op<config>, :err("没有配置: {$k}"))
            unless %!config{$k}:exists;
        return Result.new(:ok, :op<config>, :value(%!config{$k}),
                          :out(%!config{$k}.Str));
    }
    if $sub eq 'set' && @args.elems >= 4 {
        my Str $k = @args[2];
        my Str $v = @args[3..*].join(' ');
        %!config{$k} = $v;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($v), :out("{$k}={$v}"));
    }
    if $sub eq 'unset' && @args.elems >= 3 {
        my Str $k = @args[2];
        %!config{$k}:delete;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($k), :out("unset {$k}"));
    }
    Result.new(:!ok, :code(2), :op<config>,
               :err('用法: config [get KEY|set KEY VALUE|unset KEY]'))
}

method !hooks(--> Hash) {
    my $h = %!config<hooks>;
    $h ~~ Hash ?? $h !! %();
}

method run-hooks(Str $event --> List) {
    my %h = self!hooks;
    return () unless %h{$event} ~~ Positional;
    my @res;
    for %h{$event}.List -> $code {
        @res.push(self.eval-line($code.Str));
        last if $!exit-requested;
    }
    @res.List;
}

method !cmd-hook(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines;
        for self!hooks.keys.sort -> $e {
            @lines.push("{$e}:");
            @lines.push("  {$_}") for self!hooks{$e}.List;
        }
        return Result.new(:ok, :op<hook>, :value(self!hooks),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'add' && @args.elems >= 4 {
        my Str $event = @args[2];
        my Str $code = @args[3..*].join(' ');
        my %h = self!hooks;
        %h{$event} //= [];
        %h{$event}.push($code);
        %!config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($code),
                          :out("hook {$event} += {$code}"));
    }
    if $sub eq 'clear' && @args.elems >= 3 {
        my Str $event = @args[2];
        my %h = self!hooks;
        %h{$event}:delete;
        %!config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($event),
                          :out("hook {$event} cleared"));
    }
    if $sub eq 'run' && @args.elems >= 3 {
        my Str $event = @args[2];
        my @rs = self.run-hooks($event);
        my Str $out = @rs.map({ $_.out.chomp }).grep(*.chars).join("\n");
        my Str $err = @rs.map({ $_.err.chomp }).grep(*.chars).join("\n");
        my Bool $all-ok = so @rs.map(*.ok).all;
        return Result.new(:ok($all-ok), :op<hook>,
                          :value(@rs.List), :out($out), :err($err));
    }
    Result.new(:!ok, :code(2), :op<hook>,
               :err('用法: hook [add EVENT CODE|clear EVENT|run EVENT]'))
}

method !cmd-explore(Str $raw --> Result) {
    my Str $arg = $raw.trim.substr(7).trim;
    my $value;
    if $arg.chars {
        my $path = try { $!sys.resolve($arg) };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err("路径不存在: {$arg}")) unless $path.defined;
        my $loaded = try {
            $path.d
                ?? $!sys.ls-table($arg)
                !! Rakuish::Data::open-data($!sys, $arg)
        };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err($!.message)) unless $loaded.defined;
        $value = $loaded;
    }
    else {
        $value = @!out.elems ?? @!out[*-1] !! Nil;
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err('没有可探索的上一格结果')) unless $value.defined;
    }

    $value = Rakuish::Data::tableify($value)
        if $value ~~ Hash | Positional && $value !~~ Rakuish::Data::Table;
    return Result.new(:!ok, :code(1), :op<explore>,
                      :err('explore 需要 Table / 可表格化的数据'))
        unless $value ~~ Rakuish::Data::Table | Str;

    my $pager = Rakuish::Data::Pager.new;
    my Bool $tty = so try { $*IN.t };
    $tty = False if (%*ENV<RAKUISH_PAGER> // '') eq 'never';
    my Str $text = $pager.page($value, :interactive($tty));
    Result.new(:ok, :op<explore>, :value($value),
               :out($tty ?? '' !! $text));
}

# ── `!` 的 argv 分词：只处理空格与引号，元字符一律原样当参数 ──────────
# 不做 $VAR / * / ? / | / > / && / ; / heredoc / 命令替换。
method !unclosed-quote(Str $s --> Bool) {
    my Str $q = '';
    my Bool $escape = False;
    for $s.comb -> $ch {
        if $escape { $escape = False; next }
        if $q eq '' {
            if $ch eq '\\' { $escape = True; next }
            $q = $ch if $ch eq "'" || $ch eq '"';
        }
        else {
            if $ch eq '\\' { $escape = True; next }
            $q = '' if $ch eq $q;
        }
    }
    $q ne '';
}

method !split-argv(Str $s --> List) {
    my @out;
    my Str $cur   = '';
    my Str $quote = '';
    my Bool $has  = False;
    for $s.comb -> $ch {
        if $quote eq '' {
            if $ch eq "'" || $ch eq '"' {
                $quote = $ch;
                $has = True;
            }
            elsif so($ch ~~ /\s/) {
                if $has { @out.push($cur); $cur = ''; $has = False }
            }
            else { $cur ~= $ch; $has = True }
        }
        else {
            if $ch eq $quote { $quote = '' }
            else             { $cur ~= $ch }
        }
    }
    @out.push($cur) if $has;
    @out.List
}

# ── 顶层声明状态化（替代整份历史重 EVAL）────────────────────────────
# Raku 的 EVAL 不能跨调用保留词法 my；为了同时做到「my 跨格」和
# 「副作用只执行一次」，这里只把**顶层声明**转成状态 Hash 的别名：
#
#   my $x = 41;      →  $x = 41;        （$x 已别名到 %STATE<$x>）
#   my @a = (1,2);   →  @a = (1,2);
#   my %h = a=>1;    →  %h = a=>1;
#
# 当前格里的普通语句只执行一次；不再把上一格的 sys.write / append / exec
# 重新跑一遍。已知边界：嵌套块里的 my 保持局部（正确）；复杂类型约束/
# 自定义 trait 会被简化掉；sub/class 的跨格持久仍不在本状态层内。

method !take-name(Int $at, @ch, Int $n --> Str) {
    return '' if $at >= $n;
    my Str $sig = @ch[$at];
    return '' unless $sig ~~ /^<[$@%&]>$/;
    return '' if $at + 1 >= $n;
    return '' unless @ch[$at + 1] ~~ /^<[A..Za..z_]>$/;
    my Str $name = $sig;
    my Int $j = $at + 1;
    while $j < $n && @ch[$j] ~~ /^<[A..Za..z0..9_-]>$/ {
        $name ~= @ch[$j];
        $j++;
    }
    $name;
}

method !scan-cell(Str $src --> Hash) {
    my @ch = $src.comb;
    my Int $n = @ch.elems;
    my Str $out = '';
    my @names;
    my Str $quote = '';
    my Bool $esc = False;
    my Int $brace = 0;
    my Int $paren = 0;
    my Int $bracket = 0;
    my Bool $stmt-start = True;
    my Int $i = 0;

    while $i < $n {
        my Str $c = @ch[$i];

        if $quote ne '' {
            $out ~= $c;
            if $quote eq '"' && $esc {
                $esc = False;
            }
            elsif $quote eq '"' && $c eq '\\' {
                $esc = True;
            }
            elsif $c eq $quote {
                $quote = '';
            }
            $i++;
            next;
        }

        if $c eq q{'} || $c eq q{"} {
            $quote = $c;
            $out ~= $c;
            $stmt-start = False;
            $i++;
            next;
        }

        if $c eq '#' {
            while $i < $n {
                $out ~= @ch[$i];
                last if @ch[$i] eq "\n";
                $i++;
            }
            $i++;
            next;
        }

        if $stmt-start && $brace == 0 && $paren == 0 && $bracket == 0 {
            my Str $rest = $src.substr($i);
            my Str $kw = '';
            for <my our state> -> $cand {
                next unless $rest.starts-with($cand);
                my Str $after = $rest.substr($cand.chars, 1);
                next if $after ~~ /^<[A..Za..z0..9_-]>$/;
                $kw = $cand;
                last;
            }
            # 顶层类型声明必须留在词法作用域：裸 class/role/grammar 会被 EVAL
            # 安装到 GLOBAL，跨格前置重放时触发 "Redeclaration of symbol"。
            # 统一改写为 my；同时不能让下面的 %STATE 扫描把 my/our/state 剥掉
            # （剥离只适用于带 sigil 的变量声明）。
            if $kw.chars {
                my Str $ahead = $rest.substr($kw.chars).trim-leading;
                if $ahead ~~ /^ (class|role|grammar|subset|enum|constant) \s / {
                    $out ~= 'my';
                    $i += $kw.chars;
                    $stmt-start = False;
                    next;
                }
            }
            my $tm = $kw.chars ?? Nil !! ($rest ~~ /^ (class|role|grammar) \s /);
            if $tm {
                my Str $tk = ~$tm[0];
                $out ~= 'my ' ~ $tk;
                $i += $tk.chars;
                $stmt-start = False;
                next;
            }
            if $kw.chars {
                my Int $j = $i + $kw.chars;
                $j++ while $j < $n && @ch[$j] ~~ /\s/;

                # 可选类型约束：`my Int $x` / `my IO::Path $p`
                if $j < $n && @ch[$j] ne '(' && @ch[$j] !~~ /^<[$@%&]>/ {
                    while $j < $n && @ch[$j] ~~ /^<[A..Za..z0..9_:]>$/ { $j++ }
                    $j++ while $j < $n && @ch[$j] ~~ /\s/;
                }

                my @new;
                if $j < $n && @ch[$j] eq '(' {
                    my Int $k = $j + 1;
                    while $k < $n && @ch[$k] ne ')' {
                        my Str $name = self!take-name($k, @ch, $n);
                        if $name.chars {
                            @new.push($name);
                            $k += $name.chars;
                        }
                        else {
                            $k++;
                        }
                    }
                }
                else {
                    my Int $k = $j;
                    while $k < $n && @ch[$k] ne '=' && @ch[$k] ne ';' && @ch[$k] ne "\n" {
                        if @ch[$k] eq ',' { $k++; next }
                        my Str $name = self!take-name($k, @ch, $n);
                        if $name.chars {
                            @new.push($name);
                            $k += $name.chars;
                        }
                        else {
                            $k++;
                        }
                    }
                }

                @names.append(@new);
                $i = $j;
                $stmt-start = False;
                next;
            }
        }

        $out ~= $c;
        given $c {
            when '{' { $brace++ }
            when '}' { $brace-- if $brace > 0 }
            when '(' { $paren++ }
            when ')' { $paren-- if $paren > 0 }
            when '[' { $bracket++ }
            when ']' { $bracket-- if $bracket > 0 }
        }

        if $c eq ';' && $brace == 0 && $paren == 0 && $bracket == 0 {
            $stmt-start = True;
        }
        elsif $c eq "\n" {
            $stmt-start = True;
        }
        elsif $c !~~ /\s/ {
            $stmt-start = False;
        }
        $i++;
    }

    %( code => $out, names => @names.unique.List );
}

method !state-alias(Str $name --> Str) {
    given $name.substr(0, 1) {
        when '$' { 'my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;' }
        when '@' {
            '%STATE<' ~ $name ~ '> //= []; my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;'
        }
        when '%' {
            '%STATE<' ~ $name ~ '> //= {}; my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;'
        }
        default { '' }
    }
}

# 只接受“纯声明格”：整个 cell 就是一个 sub/class/role/grammar 或 use。
# 混有其它语句的 cell 不缓存，避免把副作用也带进后续格。
# 编译期/运行期 phaser 也不缓存：prelude 每格前置重放一次，BEGIN/INIT/END
# 之类的副作用会被反复执行；拒绝缓存后该格仍照常求值，只是不跨格持久。
method !pure-decl(Str $src --> Hash) {
    my Str $t = $src.trim;
    return Nil unless $t.chars;

    if $t ~~ /^ use \s+ \S+ \s* ';'? $/ {
        return %( key => "use:$t", src => $t );
    }

    for <BEGIN INIT CHECK END START FIRST> -> $phaser {
        return Nil if $t ~~ / << $phaser >> /;
    }

    my $m = $t ~~ /^ [multi \s+]? [my \s+]? (sub|class|role|grammar) \s+ (\S+) /;
    return Nil unless $m;
    my Str $kind = ~$m[0];
    my Str $name = (~$m[1]).subst(/<[{;(]>.*$/, '');
    return Nil unless $name.chars;
    my Int $open = $t.index('{');
    return Nil unless $open.defined;

    my @ch = $t.comb;
    my Int $n = @ch.elems;
    my Str $quote = '';
    my Bool $esc = False;
    my Int $depth = 0;
    my Int $i = $open;
    my Int $close = -1;
    while $i < $n {
        my Str $c = @ch[$i];
        if $quote ne '' {
            if $quote eq '"' && $esc { $esc = False }
            elsif $quote eq '"' && $c eq '\\' { $esc = True }
            elsif $c eq $quote { $quote = '' }
            $i++;
            next;
        }
        if $c eq q{'} || $c eq q{"} { $quote = $c; $i++; next }
        if $c eq '#' {
            while $i < $n && @ch[$i] ne "\n" { $i++ }
            next;
        }
        if $c eq '{' { $depth++ }
        elsif $c eq '}' {
            $depth--;
            if $depth == 0 { $close = $i; last }
        }
        $i++;
    }
    return Nil if $close < 0;
    my Str $tail = $t.substr($close + 1).trim;
    return Nil if $tail.chars && $tail ne ';';

    %( key => "{$kind}:{$name}", src => $t, :name($name),
       is-type => ($kind eq 'class' || $kind eq 'role' || $kind eq 'grammar') );
}

# ── Raku 求值：只执行当前格；顶层声明用 %STATE / @decls 持久化 ──────
method !remember(Result $r --> Nil) {
    return unless $r.ok;
    return if $r.op eq 'more' || $r.op eq 'exit' || $r.op eq 'skip';
    @!out.push($r.value);
    @!out.shift while @!out.elems > 1000;
    Nil
}

method !eval-raku(Str $src --> Result) {
    my %scanned = self!scan-cell($src);
    my @new-names = %scanned<names>.List;
    my Str $cell-code = %scanned<code>;
    my %decl = self!pure-decl($cell-code) // %();
    my Bool $is-type = so %decl<is-type>;

    # 声明进入 prelude 的方式：
    #   · sub / use：当前 cell 自己声明，成功后按原位插回缓存；
    #   · class / role / grammar：直接原位替换缓存，当前 cell 只引用类型名。
    #     否则重定义被继承的类型时，依赖它的声明会排在它前面（编译失败）。
    my Int $slot = -1;
    my @saved-decls = @!decls.List;
    if %decl<key> {
        $slot = @!decls.first({ .<key> eq %decl<key> }, :k) // -1;
        if $is-type {
            if $slot >= 0 { @!decls[$slot] = %decl }
            else          { @!decls.push(%decl) }
            $cell-code = %decl<name>;
        }
        elsif $slot >= 0 {
            @!decls = @!decls.grep({ .<key> ne %decl<key> }).List;
        }
    }

    for @new-names -> $name {
        next if %!state{$name}:exists;
        given $name.substr(0, 1) {
            when '$' { %!state{$name} = Any }
            when '@' { %!state{$name} = [] }
            when '%' { %!state{$name} = {} }
        }
    }

    my @prelude;
    for @!decls -> $d {
        @prelude.push($d<src>);
    }
    for %!state.keys.sort -> $name {
        my Str $alias = self!state-alias($name);
        @prelude.push($alias) if $alias.chars;
    }
    my Str $code = @prelude.join("\n")
        ~ (@prelude.elems ?? "\n" !! '')
        ~ $cell-code;

    my $cap  = CapturingOut.new;
    my $t0   = now;
    my $value;
    my Str $err = '';
    my Bool $ok = True;
    my $last = @!out.elems ?? @!out[*-1] !! Any;
    my @out  = (Any, |@!out);

    {
        # 部分编译期异常（典型：跨格引用未声明类型）的 .message / .gist
        # 在**方法内部**字符串化未定义值并抛 CX::Warn，仅在外面判断
        # .defined 拦不住（0.69.1 实测：警告行号就落在取消息这一行）。
        # quietly 只包住「构造异常文本」这一小块，抑制驱动自身的警告；
        # 结果仍显式收敛成 Str，最后用异常类名兜底，$err 绝不接收 Any。
        CATCH { default {
            $ok = False;
            my $ex = $_;
            my Str $text = (quietly {
                my $m = try { $ex.message };
                my Str $s = $m.defined ?? (try { ~$m } // '') !! '';
                $s.chars ?? $s !! (try { ~$ex.gist } // '')
            }) // '';
            $err = $text.chars ?? $text !! $ex.^name;
        } }
        # 无 sigil 词法绑定：EVAL 里可直接写 sys.read(...) / repl.history /
        # registry.names（实测 MoarVM 上 EVAL 能看到调用处的词法绑定）。
        my \sys      = $!sys;
        my \repl     = self;
        my \registry = $!commands;
        my \_        = $last;
        my \Out      = @out;
        my $*RAKUISH-SESSION = self;
        my $*RAKUISH-SYS = $!sys;
        my %STATE := %!state;
        temp $*OUT = $cap;
        $value = EVAL "no worries; do \{ $code \n }";
    }

    my Str $all = $cap.text;
    $!shown = $all.chars;

    if $ok {
        if %decl<key> && !$is-type {
            if $slot >= 0 && $slot <= @!decls.elems {
                @!decls.splice($slot, 0, %decl);
            }
            else {
                @!decls.push(%decl);
            }
        }
        $!accum = $src;
        $!index = $!index + 1;
        @!history.push($src);
        # 耗时由入口 note-timing() 统一记录（覆盖 shell / ! / Raku 三类格），
        # 这里不再重复推入，否则 perf 报表会出现双倍条目。
    }
    else {
        # 声明格求值失败时回滚，不能把上一格可用的旧声明弄丢。
        @!decls = @saved-decls.List if %decl<key>;
    }
    my $res = Result.new(:ok($ok), :code($ok ?? 0 !! 1), :value($value),
                         :out($all), :err($err), :op<eval>,
                         :elapsed(now - $t0));
    self!remember($res);
    $res;
}

# ── 主入口 ────────────────────────────────────────────────────────────
method !strict-result(Result $r --> Result) {
    if $!strict && !$r.ok {
        $!exit-requested = True;
        $!exit-code = $r.code || 1;
    }
    $r;
}

method eval-line(Str $line --> Result) {
    return Result.new(:ok, :op<skip>) if $line.trim.chars == 0;

    my Str $t = $line.trim-leading;

    # set -e / set +e：失败格请求退出（脚本/REPL 的 strict 模式）。
    if $t.trim ~~ /^ 'set' \s+ <[-+]> 'e' ';'? $/ {
        $!strict = $t.trim.contains('-e');
        my Str $msg = $!strict ?? 'errexit on' !! 'errexit off';
        return Result.new(:ok, :op<set>, :value($!strict), :out($msg));
    }

    # shell 习惯的 history：显示本会话已执行行。
    if $t.trim eq 'history' {
        my Str $text = @!history.kv.map(-> $i, $v { "{$i + 1}  {$v}" }).join("\n");
        return Result.new(:ok, :op<history>, :value(@!history.List), :out($text));
    }

    # perf：查看每格耗时。不引入 %magic —— 耗时是会话数据，prompt 也读它。
    if $t.trim eq 'perf' || $t.trim.starts-with('perf ') {
        return self!cmd-perf($t);
    }

    # 0.66：hints（会话数据查询）与 plugin（显式本地 Raku 插件）。
    # 仍然不是 %magic：它们是普通会话命令，与 config/alias/hook 同级。
    if $t.trim eq 'hint' || $t.trim.starts-with('hint ') {
        return self!cmd-hint($t);
    }
    if $t.trim eq 'plugin' || $t.trim.starts-with('plugin ') {
        return self!cmd-plugin($t);
    }

    # 0.69：describe 是值 API 的会话入口（不是 %magic、不是文本报告）。
    # 只拦「首词是 describe 且后面是普通参数」；describe(...) 这类 Raku 调用
    # 仍交给 EVAL，由 DSL.describe 处理。
    if $t.trim eq 'describe' || $t.trim.starts-with('describe ') {
        return self!cmd-describe($t);
    }

    # 配置 / alias：会话级命令，不交给 Shell 参数解析。
    if $t.trim eq 'alias' || $t.trim.starts-with('alias ') {
        return self!cmd-alias($t);
    }
    if $t.trim.starts-with('unalias ') {
        return self!cmd-unalias($t);
    }
    if $t.trim eq 'config' || $t.trim.starts-with('config ') {
        return self!cmd-config($t);
    }
    if $t.trim eq 'hook' || $t.trim.starts-with('hook ') {
        return self!cmd-hook($t);
    }
    if $t.trim eq 'explore' || $t.trim.starts-with('explore ') {
        return self!cmd-explore($t);
    }
    # 历史替换只认整行 !! / !$ / !n；`!cmd` 仍是外部命令。
    if !$!expanding && $t.trim ~~ /^ '!' ('!' | '$' | '-'? \d+) $/ {
        return Result.new(:!ok, :code(127), :op<history>,
                          :err('历史为空')) unless @!history.elems;
        my Str $spec = $t.trim;
        my Str $expanded;
        if $spec eq '!!' {
            $expanded = @!history[*-1];
        }
        elsif $spec eq '!$' {
            $expanded = @!history[*-1].words.tail // '';
        }
        else {
            my Int $n = $spec.substr(1).Int;
            my Int $idx = $n < 0 ?? @!history.elems + $n !! $n - 1;
            return Result.new(:!ok, :code(127), :op<history>,
                              :err("没有历史项: {$spec}"))
                unless $idx >= 0 && $idx < @!history.elems;
            $expanded = @!history[$idx];
        }
        return Result.new(:!ok, :code(127), :op<history>,
                          :err("历史项为空: {$spec}")) unless $expanded.chars;
        $!expanding = True;
        my $r = self.eval-line($expanded);
        $!expanding = False;
        return $r;
    }

    # 1) `!` argv 便利入口。`!=` / `!~~` 是 Raku 运算符，仍按 Raku 求值。
    if $t.starts-with('!') {
        my Str $next = $t.chars > 1 ?? $t.substr(1, 1) !! '';
        if $next ne '=' && $next ne '~' {
            my Str $cmdline = $t.substr(1).trim;
            if self!unclosed-quote($cmdline) {
                return self!strict-result(
                    Result.new(:!ok, :code(127), :op<exec>,
                               :err('! 命令的引号未闭合')));
            }
            my @argv = self!split-argv($cmdline);
            # 0.70 / ADR-0007：`! --tty` / `! -t` 是显式 TTY 直通的元选项，
            # 只认首个 token；`! -- ...` 之后全部按字面 argv，不再解析元选项。
            # 这不是第二套语法：`--tty` 属于 rakuish 的 ! 分发层，子进程
            # 收到的仍然只有 argv 数组。
            my Bool $tty-mode = False;
            if @argv.elems && (@argv[0].Str eq '--tty' || @argv[0].Str eq '-t') {
                $tty-mode = True;
                @argv.shift;
            }
            elsif @argv.elems && @argv[0].Str eq '--' {
                @argv.shift;
            }
            return self!strict-result(Result.new(:!ok, :code(127), :op<exec>,
                              :err('! 后面没有命令'))) unless @argv.elems;
            my $exe = @argv.shift;
            $!index = $!index + 1;
            @!history.push($line);
            my $r;
            if $tty-mode {
                # 非 TTY 时 Sys 会抛 X::Rakuish::Unsupported；收敛成失败 Result，
                # 不让异常穿透 eval-line（管道/脚本必须保持干净）。
                my Str $start-err = '';
                {
                    CATCH { default { $start-err = .message } }
                    $r = $!sys.tty-exec($exe, |@argv);
                }
                $r = Result.new(:!ok, :code(127), :op<tty-exec>,
                                :err($start-err)) unless $r.defined;
            }
            else {
                $r = $!sys.exec($exe, |@argv);
            }
            self!remember($r);
            return self!strict-result($r);
        }
    }

    # 2) shell 习惯的常用命令：必须在续行判定前处理 `cd -`（Raku 会把它当
    #    不完整表达式）。只处理单行、无待续行的输入。
    if !@!pending && !$line.contains("\n") {
        my $shell-result = $!shell.handle(self!expand-alias($line));
        if $shell-result.defined {
            $!index = $!index + 1;
            @!history.push($line);
            self!remember($shell-result);
            return self!strict-result($shell-result);
        }
    }

    # 3) 其余一律 Raku（% 开头不再分流）。先处理多行续行。
    my @parts = @!pending.List;
    @parts.push($line);
    my Str $src = @parts.join("\n");

    # Raku 的 `exit` 会真的终止 REPL 进程（v2 用 prelude 覆盖）。这里显式
    # 映射成会话退出请求；这不是新命令表，不改变「只有两类输入」的分流。
    my Str $trim = $src.trim;
    my Bool $is-exit = $trim eq 'exit'
        || so($trim ~~ /^ 'exit' \s+ <[0..9]>+ $/);
    if $is-exit {
        $!exit-requested = True;
        $!exit-code = $trim eq 'exit' ?? 0 !! $trim.split(/\s+/)[*-1].Int;
        @!pending = ();
        return Result.new(:ok, :op<exit>, :value<exit>);
    }

    if is-incomplete($src) {
        @!pending = @parts;
        return Result.new(:ok, :op<more>, :value(@parts.elems));
    }
    @!pending = ();
    self!strict-result(self!eval-raku($src))
}

# ── 渲染：值用 .raku，先 decont 避免 Scalar 多打 $ 前缀 ────────────────
method !fmt($v --> Str) {
    my $x = $v<>;
    (try { $x.raku } // $x.Str) // ''
}

# `ls` / `glob` / `recent` 返回的是 List[IO::Path]，不能按默认 .raku 展示成
# `$(IO::Path.new(...), ...)`。这里给一个 shell `ls` 风格的展示：
#   · 只显示 basename，按名字排序；
#   · 非 TTY / 管道下每行一个（与 ls 管道行为一致）；
#   · TTY 下按 COLUMNS 排成多列（与 ls 默认视觉一致）。
method !render-path-list(@paths --> Str) {
    # 递归 ls 的条目来自不同目录时，只显示 basename 会丢上下文；
    # 这种情况改用相对 cwd 的路径。单目录列表仍保持 shell ls 的 basename。
    my @parents = @paths.map({ .parent.Str }).unique;
    my Str $cwd = $!sys.cwd.Str;
    my Bool $multi = @parents.elems > 1 || @parents.first({ $_ ne $cwd }).defined;

    # 0.74.0 / ADR-0011：每个条目同时保留「纯文本」与「路径」。
    # 列宽、列数、padding 一律按纯文本算 —— 着色只插入零宽转义，
    # 一旦把它算进宽度，多列就会错位。
    my @items = @paths.map(-> $p {
        my Str $plain = $multi
            ?? do {
                my Str $rel = $p.relative($!sys.cwd).Str.subst(:g, '\\', '/');
                $rel.starts-with('..') ?? $p.Str.subst(:g, '\\', '/') !! $rel;
            }
            !! $p.basename;
        %( plain => $plain, path => $p );
    }).sort({ .<plain>.lc });

    return '' unless @items.elems;

    my Bool $tty = False;
    try { $tty = $*OUT.t };
    my Bool $color = $tty && self!color-on;

    my &shown = -> $it { paint($it<plain>, path-color($it<path>), $color) };

    return @items.map(&shown).join("\n") unless $tty && @items.elems > 1;

    my Int $width = (%*ENV<COLUMNS> // 0).Int;
    $width = 80 if $width <= 0;
    my Int $max = @items.map({ .<plain>.chars }).max;
    my Int $cols = (($width + 2) div ($max + 2)) max 1;
    return @items.map(&shown).join("\n") if $cols <= 1;

    my Int $rows = (@items.elems + $cols - 1) div $cols;
    my @lines;
    for ^$rows -> $r {
        my @cells;
        for ^$cols -> $c {
            my $i = $r * $cols + $c;
            last if $i >= @items.elems;
            my Str $plain = @items[$i]<plain>;
            @cells.push(shown(@items[$i]) ~ (' ' x ($max - $plain.chars)));
        }
        # 尾部填充是纯空格，替换不会碰到中间的转义序列。
        @lines.push(@cells.join('  ').subst(/\s+$/, ''));
    }
    @lines.join("\n");
}

# help() / registry.names：命令列表给人看，不要显示成 $("...")。
method !render-command-help(@specs --> Str) {
    my Int $w = @specs.map(*.name.chars).max // 0;
    my Bool $c = self!color-on;
    # padding 按纯文本名字长度算；着色不参与对齐。
    @specs.sort({ .name }).map({
        paint(.name, %CLR{'b-cyan'}, $c)
        ~ (' ' x ($w - .name.chars + 2))
        ~ paint(.summary, %CLR<dim>, $c)
    }).join("\n");
}

# env()：按 shell `env` 的习惯输出 KEY=VALUE，而不是 Raku Hash 的 raku 结构。
method !render-env-hash(%h --> Str) {
    my Bool $c = self!color-on;
    %h.keys.sort({ .Str }).map({
        paint($_.Str, %CLR<cyan>, $c) ~ '=' ~ %h{$_}.Str
    }).join("\n");
}

method !render-stat(Stat $s --> Str) {
    my Bool $c = self!color-on;
    # $value 可能是 IO::Path / Int / Bool，统一在这里 stringify —— 原来用
    # 字符串插值自动转了，包成函数后必须显式做。
    my sub k(Str $name, $value --> Str) {
        paint($name, %CLR<dim>, $c) ~ ': ' ~ $value.Str
    }
    my @lines;
    @lines.push(k('path', $s.path));
    @lines.push(k('type', $s.type));
    @lines.push(k('size', $s.size.Str));
    @lines.push(k('mode', '0' ~ $s.mode.fmt('%o'))) if $s.mode > 0;
    # Windows 的 modified 可能是 1969 年假值；不可信就不显示，别给用户看 -0.15。
    my $y2k = Instant.from-posix(946684800);
    @lines.push(k('modified', $s.modified.DateTime.Str))
        if $s.modified.defined && $s.modified >= $y2k;
    @lines.push(k('readable', $s.readable.Str)
                ~ '  ' ~ k('writable', $s.writable.Str)
                ~ '  ' ~ k('executable', $s.executable.Str));
    @lines.join("\n");
}

method !render-write(WriteResult $w --> Str) {
    my Bool $c = self!color-on;
    my Str $text = paint('wrote', %CLR<green>, $c) ~ " {$w.bytes} bytes to {$w.path}";
    $text ~= ' (backup: ' ~ $w.backup ~ ')' if $w.backup.chars;
    $text ~= ' ' ~ paint('[non-atomic]', %CLR<yellow>, $c) unless $w.atomic;
    $text;
}

# 0.74.0 / ADR-0011：入口每格按 config 重算颜色能力后调它。
# 必须同时同步 Shell —— ls 的长格式 / 普通列表在 Shell 里渲染，
# 只改 Session 会出现「路径列表彩色、ls -l 无色」的半截状态。
# 渲染层唯一该问的一句话：开关开着**且**当前 stdout 是终端。
# 只问 $!color 会漏掉管道：`rakuish -e 'ls' | cat` 的 stdout 不是 TTY，
# 混进 ANSI 就违反了 SPEC V-116（管道输出只能是求值结果）。
method !color-on(--> Bool) {
    return False unless $!color;
    (so try { $*OUT.t });
}

method set-color(Bool $on --> Nil) {
    $!color = $on;
    $!shell.color = $on if $!shell.defined;
}

method render(Result $r --> Str) {
    my @lines;
    @lines.push($r.out.chomp) if $r.out.chars;
    # Shell 薄层的 Result 也按普通值展示；exec 的 value 是审计 Hash，不能套。
    my constant SHELL-OPS = <
        ls cat cd pwd clear rm mkdir cp mv stat echo head tail export unset touch glob shell history help jobs read which
    >;
    my Bool $value-op = $r.op eq 'eval' || $r.op (elem) SHELL-OPS;
    my Bool $shell-op = $r.op (elem) SHELL-OPS;
    my Bool $shell-value = $r.op eq 'ls' && $r.out.chars == 0;
    if $r.ok && $r.value.defined && $value-op && (!$shell-op || $shell-value) {
        my $v = $r.value;
        if $v ~~ Result {
            @lines.push($v.display);
        }
        elsif $v ~~ Rakuish::Data::Table {
            @lines.push($v.to-text);
        }
        elsif $r.op eq 'ls' && $v ~~ Positional && $v.elems == 0 {
            # 空目录：shell ls 不打印任何东西
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ IO::Path {
            # ls / glob / recent 的 shell 风格列表
            @lines.push(self!render-path-list($v));
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ CommandSpec {
            # help() 的命令列表
            @lines.push(self!render-command-help($v));
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ Str {
            # registry.names 这类字符串列表，一行一个
            @lines.push($v.join("\n"));
        }
        elsif $v ~~ Str {
            # read / pwd：shell 习惯是直接显示内容/路径，不显示 Raku 引号
            @lines.push($v);
        }
        elsif $v ~~ Hash {
            # env()：shell `env` 风格
            @lines.push(self!render-env-hash($v));
        }
        elsif $v ~~ Stat {
            @lines.push(self!render-stat($v));
        }
        elsif $v ~~ WriteResult {
            @lines.push(self!render-write($v));
        }
        elsif $v ~~ IO::Path {
            # cd / pwd 等单路径结果
            @lines.push($v.Str);
        }
        else {
            @lines.push(paint("Out[{$!index}] =", %CLR<dim>, self!color-on)
                        ~ ' ' ~ self!fmt($v));
        }
    }
    @lines.push(paint('错误: ' ~ $r.err.trim, %CLR<red>, self!color-on)) if $r.err.chars;
    @lines.join("\n")
}

# ── 计时：入口对每一格统一写入，perf 命令读 ─────────────────────────
# 这是「%time 的 Raku 原生替代」的一半：不用文本魔法，耗时是会话数据，
# 既能显示在 prompt 上，也能作为值查（repl.perf-hist）。
method note-timing(Duration $d, Str $src, Bool $ok = True --> Nil) {
    if $!perf {
        @!perf-hist.push([$!index, ($d.Num * 1000).Int, $src.substr(0, 60), $ok]);
    }
}

method perf-report(Int :$limit = 10 --> Str) {
    return '还没有计时记录。' unless @!perf-hist.elems;
    my @rows = @!perf-hist.tail($limit max 1);
    my @lines;
    for @rows -> $row {
        my ($idx, $ms, $src, $ok) = @$row;
        my Str $text = $src.subst(:g, "\n", ' ');
        $text = $text.substr(0, 42) ~ '...' if $text.chars > 43;
        my Str $flag = $ok ?? 'ok' !! 'ERR';
        @lines.push(sprintf('#%-4d %8d ms  %-3s %s', $idx, $ms, $flag, $text));
    }
    my @all = @!perf-hist.map({ .[1] });
    my Str $avg = @all.elems ?? sprintf('%.1f', @all.sum / @all.elems) !! '0';
    my Int  $max = @all.elems ?? @all.max !! 0;
    @lines.push("共 {@!perf-hist.elems} 格 · 平均 {$avg} ms · 最慢 {$max} ms");
    @lines.join("\n")
}

method !cmd-perf(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('perf'),
                          :out($!shell.usage('perf')));
    }
    my Int $n = @args.elems ?? ((try { @args[0].Int }) // 10) !! 10;
    $n = 1   if $n < 1;
    $n = 200 if $n > 200;
    Result.new(:ok, :op<perf>, :value(@!perf-hist.List),
               :out(self.perf-report(:limit($n))))
}

# ── 0.66：Vi/Helix 状态、hints、插件（ADR-0003）─────────────────────
method vi(--> ViState)   { vi-state() }
method vi-keys(--> Hash) { vi-actions() }

method hint-text(Str $line = '' --> Str) {
    my Str $t = $line.chars ?? $line
              !! (@!history.elems ?? @!history[*-1] !! '');
    hint-for($t, :shell($!shell), :registry($!commands))
}

# 入口每格调用：失败优先给下一步建议；成功时给一次性的命令用法提示。
method next-hint(Str $line, Result $r --> Str) {
    unless $r.ok {
        my Str $advice = result-hint($r, $line);
        return $advice if $advice.chars;
    }
    my Str $ctx = hint-for($line, :shell($!shell), :registry($!commands));
    return '' unless $ctx.chars;
    my Str $key = $line.trim.words[0] // '';
    return '' if %!hinted{$key}:exists;
    %!hinted{$key} = True;
    $ctx
}

method !cmd-hint(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $h = self.hint-text(@p[1] // '');
    Result.new(:ok, :op<hint>, :value($h),
               :out($h.chars ?? $h !! '（该输入没有上下文提示）'))
}

method !cmd-describe(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $arg = (@p[1] // '').trim;
    my Str $usage = '用法: describe [表名]'
        ~ "\n  无参数：摘要上一格 Table；否则列出已注册 Engine 的表"
        ~ "\n  有参数：describe('表名') 的结构摘要（需先 open-db(...)）";

    my $table;
    if $arg.chars {
        return Result.new(:!ok, :code(2), :op<describe>,
                          :err('还没有会话 Engine，先用 open-db(...) 打开数据库'))
            unless $!engine.defined;
        $table = try { $!engine.describe($arg) };
    }
    else {
        my $last = @!out.elems ?? @!out[*-1] !! Nil;
        if $last ~~ Rakuish::Data::Table {
            $table = try { $last.describe };
        }
        elsif $!engine.defined {
            $table = try { $!engine.tables };
        }
        else {
            return Result.new(:!ok, :code(2), :op<describe>, :err($usage));
        }
    }
    return Result.new(:!ok, :code(2), :op<describe>,
                      :err(($! ?? $!.message !! 'describe 失败').Str))
        unless $table.defined;

    Result.new(:ok, :op<describe>, :value($table),
               :out($table.to-text(:max-rows(50))))
}

method !cmd-plugin(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 3);
    my Str $sub = @p[1] // 'list';
    my Str $arg = (@p[2] // '').trim;
    my Str $usage = '用法: plugin [list|load PATH|unload NAME|info NAME]';
    given $sub {
        when 'list' {
            my $table = $!plugins.list;
            Result.new(:ok, :op<plugin>, :value($table),
                       :out($table.elems ?? $table.to-text !! '（未加载插件）'))
        }
        when 'info' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            Result.new(:ok, :op<plugin>, :value($arg),
                       :out($!plugins.info($arg)))
        }
        when 'load' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $!plugins.load($!sys, $!commands, $arg,
                           :enabled($!plugins.enabled(%!config)))
        }
        when 'unload' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $!plugins.unload($!commands, $arg)
        }
        when 'help' | '--help' | '-?' {
            Result.new(:ok, :op<help>, :value<plugin>, :out($usage))
        }
        default {
            Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
        }
    }
}

method completions(Str $line, Int $pos --> List) {
    # SQL 字符串上下文优先（纯函数、engine 缺失/异常时返回空），
    # 否则原样交给 Shell；这样 0.68 之前的所有补全行为不变。
    my @sql = sql-completions($line, $pos, :engine($!engine));
    return @sql.List if @sql.elems;
    $!shell.completions($line, $pos);
}

# ── 快捷键：纯交互动作不占文本命令 ────────────────────────────────────
method key-bindings(--> Hash) {
    {
        'Up'          => '历史上一格',
        'Down'        => '历史下一格',
        'Ctrl-R'      => '搜索历史（带 :query）',
        'Ctrl-C'      => '中断当前输入 / 清空续行缓冲（不退出）',
        'Ctrl-D'      => '退出会话（EOF）',
        'Ctrl-X Ctrl-E' => '用外部编辑器编辑当前输入',
        'Tab'         => '补全（Raku 名字 / 路径 / 命令 spec）',
    }
}

method handle-key(Str $key, Str :$query = '', Int :$at --> Result) {
    given $key {
        when 'Ctrl-C' {
            $!interrupt-requested = True;
            @!pending = ();
            Result.new(:ok, :op<key>, :value<interrupted>)
        }
        when 'Ctrl-D' {
            $!exit-requested = True;
            $!exit-code = 0;
            Result.new(:ok, :op<key>, :value<exit>)
        }
        when 'Ctrl-R' {
            my @hits = @!history.grep({ .contains($query) });
            Result.new(:ok, :op<key>, :value(@hits.List))
        }
        when 'Up' | 'Down' {
            my $i = $at.defined ?? $at !! @!history.elems - 1;
            $i = $i - 1 if $key eq 'Up';
            $i = $i + 1 if $key eq 'Down';
            $i = 0 if $i < 0;
            $i = @!history.elems - 1 if $i >= @!history.elems;
            Result.new(:ok, :op<key>,
                       :value(@!history.elems ?? @!history[$i] !! ''))
        }
        when 'Ctrl-X Ctrl-E' {
            Result.new(:ok, :op<key>, :value<edit-request>)
        }
        default {
            Result.new(:!ok, :code(1), :op<key>,
                       :err("未绑定按键: $key"))
        }
    }
}
