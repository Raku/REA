unit class Rakuish::REPL::Shell;

# Rakuish::REPL::Shell —— REPL 的“日常 shell 观感”薄层。
#
# 它不是第二套 shell 引擎：不执行管道/重定向/子 shell，也不把命令变成
# 字符串协议。它只把最常见的**命令 + 参数**翻译成直接的 Sys 调用，让
# `cd ..`、`ls -la`、`rm -rf`、`cat file` 这类日常输入符合用户习惯。
# 带 `$var`、表达式、引号或非字面参数的输入仍交给 Raku。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::REPL::Chrome;   # 色表与 paint（0.74.0 / ADR-0011）
use Rakuish::Data;
use Rakuish::Data::Table;

has Rakuish::Sys $.sys is required;
# 0.74.0 / ADR-0011：结果着色开关，由 Session 按入口的颜色能力注入。
has Bool $.color is rw = False;
has IO::Path $.prev-cwd;

my constant COMMANDS = <
    cd pwd clear history set jobs which alias unalias config hook explore ls cat rm mkdir cp mv stat echo head tail export unset touch
    glob grep wc help perf read write append exec env open ls-table open-data save-data describe
>;

# 真正由 Shell 分发的命令；COMMANDS 还包含仅用于 help/补全的 Raku API 名。
my constant SHELL-COMMANDS = <
    cd pwd clear ls cat read rm mkdir cp mv stat echo head tail export unset
    touch glob grep wc help jobs which open
>;

# ── 分词：空格 + 单/双引号 + 反斜杠转义 ─────────────────────────────
method !split(Str $s --> List) {
    my @out;
    my Str $cur = '';
    my Str $quote = '';
    my Bool $esc = False;
    my Bool $started = False;

    for $s.comb -> $c {
        if $quote ne '' {
            if $quote eq '"' && $esc {
                $cur ~= $c;
                $esc = False;
            }
            elsif $quote eq '"' && $c eq '\\' {
                $esc = True;
            }
            elsif $c eq $quote {
                $quote = '';
            }
            else {
                $cur ~= $c;
            }
            $started = True;
            next;
        }
        if $c eq q{'} || $c eq q{"} {
            $quote = $c;
            $started = True;
            next;
        }
        if $c eq '\\' {
            $esc = True;
            $started = True;
            next;
        }
        if $esc {
            $cur ~= $c;
            $esc = False;
            $started = True;
            next;
        }
        if $c ~~ /\s/ {
            if $started {
                @out.push($cur);
                $cur = '';
                $started = False;
            }
            next;
        }
        $cur ~= $c;
        $started = True;
    }
    @out.push($cur) if $started;
    @out.List;
}

method !expand-home(Str $arg --> Str) {
    return $arg unless $arg eq '~'
        || $arg.starts-with('~/') || $arg.starts-with('~\\');
    my Str $home = (try { $*HOME.Str }) // '';
    return $arg unless $home.chars;
    $arg eq '~' ?? $home !! $home ~ $arg.substr(1);
}

method !expand-env(@args --> List) {
    my @out;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s ~~ /^ '$' (<[A..Za..z_]> <[A..Za..z0..9_]>*) $/ {
            my $v = $!sys.get-env(~$0);
            @out.push($v.defined ?? $v.Str !! $s);
        }
        else {
            @out.push($s);
        }
    }
    @out.List;
}

method !is-glob(Str $s --> Bool) {
    $s.contains('*') || $s.contains('?');
}

# shell 的 glob 展开；没有匹配时保留原 token（与 shell 一致）。
# 注意：这里只处理 * / ?。brace、字符集、反斜杠转义属于 Sys.glob 的
# 模式语法（见 t/18），Shell 薄层不猜参数：含 { } [ ] 的参数会交回 Raku，
# 且 !split 会把 '\' 当转义前缀吃掉。要用完整语法请写 Raku glob('...')。
method !expand-globs(@args --> List) {
    my @out;
    for @args -> $a {
        my Str $s = $a.Str;
        next if $s eq '';
        if self!is-glob($s) {
            my @hits = try { $!sys.glob($s) } // ();
            if @hits.elems {
                @out.append(@hits.map(*.Str));
                next;
            }
        }
        @out.push($s);
    }
    @out.List;
}

method !err(Str $op, Str $msg, Int $code = 1 --> Result) {
    Result.new(:!ok, :$code, :$op, :err($msg));
}

method !ok(Str $op, $value, Str :$out = '', Bool :$no-newline = False --> Result) {
    Result.new(:ok, :$op, :$value, :$out, :$no-newline);
}

method !stat-text(Rakuish::Result::Stat $st --> Str) {
    my @lines;
    @lines.push("path: {self!native-path($st.path.Str)}");
    @lines.push("type: {$st.type}");
    @lines.push("size: {$st.size}");
    @lines.push("mode: 0{$st.mode.fmt('%o')}") if $st.mode > 0;
    my $y2k = Instant.from-posix(946684800);
    @lines.push("modified: {$st.modified.DateTime.Str}")
        if $st.modified.defined && $st.modified >= $y2k;
    @lines.join("\n");
}

method !human-size(Int $n --> Str) {
    return $n.Str if $n < 1024;
    my Str @units = <K M G T P>;
    my Num $v = $n.Num;
    my Int $i = -1;
    while $v >= 1024 && $i < @units.elems - 1 {
        $v /= 1024;
        $i++;
    }
    my Str $num = $v < 10 ?? $v.fmt('%.1f') !! $v.fmt('%.0f');
    $num ~ @units[$i];
}

method !ls-text(@entries, Bool :$classify, Bool :$long, Bool :$human,
                Str :$sort = 'name', Bool :$reverse,
                Bool :$full-paths = False --> Str) {
    # 0.74.0 / ADR-0011：只有 TTY 且入口开了色才上色。着色只作用于名字列
    # （行尾），前面的 size / date 用 fmt 对齐，不受影响。
    my Bool $tty = False;
    try { $tty = $*OUT.t };
    my Bool $color = $tty && $!color;

    my @sorted = @entries.sort(-> $a, $b {
        given $sort {
            when 'time' {
                my $am = (try { $!sys.stat($a).modified }) // Instant.from-posix(0);
                my $bm = (try { $!sys.stat($b).modified }) // Instant.from-posix(0);
                $bm <=> $am;
            }
            when 'size' {
                my $as = (try { $!sys.stat($a).size }) // 0;
                my $bs = (try { $!sys.stat($b).size }) // 0;
                $bs <=> $as;
            }
            default { $a.basename.lc cmp $b.basename.lc }
        }
    });
    @sorted = @sorted.reverse if $reverse;

    if $long {
        my @rows;
        for @sorted -> $e {
            my $st = try { $!sys.stat($e) };
            my Str $mode = $st.defined && $st.mode > 0
                ?? '0' ~ $st.mode.fmt('%o') !! '----------';
            my Int $size = $st.defined ?? $st.size !! 0;
            my Str $size-text = $human ?? self!human-size($size) !! $size.Str;
            my Str $date = '';
            if $st.defined && $st.modified.defined
               && $st.modified >= Instant.from-posix(946684800) {
                $date = $st.modified.DateTime.Str.substr(0, 10);
            }
            my Str $kind = $e.d ?? 'd' !! ($e.l ?? 'l' !! '-');
            my Str $name = $full-paths
                ?? $e.relative($!sys.cwd).Str.subst(:g, '\\', '/')
                !! $e.basename;
            $name ~= '/' if $classify && $e.d;
            @rows.push($kind ~ ' ' ~ $mode ~ ' ' ~ $size-text.fmt('%8s')
                       ~ ' ' ~ $date ~ ' ' ~ paint($name, path-color($e), $color));
        }
        return @rows.join("\n");
    }
    my @names = @sorted.map({
        my Str $name = $full-paths
            ?? .relative($!sys.cwd).Str.subst(:g, '\\', '/')
            !! .basename;
        $name ~= '/' if $classify && .d;
        paint($name, path-color($_), $color)
    });
    @names.join("\n");
}

method !ls-tree(@paths, Bool :$all, Bool :$classify, Bool :$long,
                 Bool :$human, Str :$sort = 'name', Bool :$reverse,
                 Bool :$full-paths = False,
                 :&emit --> Hash) {
    my @blocks;
    my @all;
    my sub block(Str $s) {
        if &emit.defined { emit($s) } else { @blocks.push($s) }
    }
    my sub walk(IO::Path $d) {
        my @entries = try { $!sys.ls($d, :$all, :!recursive) } // ();
        @all.append(@entries) unless &emit.defined;
        my Str $label = $d.relative($!sys.cwd).Str;
        $label = '.' unless $label.chars;
        block("{$label}:");
        my Str $body = self!ls-text(@entries, :$classify, :$long,
                                     :$human, :$sort, :$reverse,
                                     :$full-paths);
        block($body) if $body.chars;
        for @entries.grep({ $_.d && !$_.l }).sort({ .basename.lc }) -> $child {
            walk($child);
        }
    }
    for @paths -> $path {
        my $p = try { $!sys.resolve($path) };
        next unless $p.defined;
        if $p.d && !$p.l {
            walk($p);
        }
        else {
            @all.push($p) unless &emit.defined;
            my Str $body = self!ls-text(($p,), :$classify, :$long,
                                        :$human, :$sort, :$reverse,
                                        :$full-paths);
            block($body) if $body.chars;
        }
    }
    { blocks => @blocks.List, entries => @all.List };
}

method !cmd-ls(@args --> Result) {
    my Bool $all = False;
    my Bool $long = False;
    my Bool $recursive = False;
    my Bool $classify = False;
    my Bool $human = False;
    my Bool $reverse = False;
    my Bool $dirs-as-files = False;
    my Bool $json = False;
    my Str $sort = 'name';
    my @paths;

    for @args -> $a {
        my Str $s = $a.Str;
        if $s eq '--json' { $json = True; next }
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'a' | 'A' { $all = True }
                    when 'l' { $long = True }
                    when 'R' { $recursive = True }
                    when 'F' | 'p' { $classify = True }
                    when 'h' { $human = True }
                    when 'r' { $reverse = True }
                    when 't' { $sort = 'time' }
                    when 'S' { $sort = 'size' }
                    when 'd' { $dirs-as-files = True }
                    when 'j' { $json = True }
                    when '1' | 'C' | 'x' { } # 默认列/一行；-C 不需要额外处理
                    default {
                        return self!err('ls', "不支持的 ls 选项: -{$f}");
                    }
                }
            }
        }
        else {
            @paths.push($s);
        }
    }

    my @input-paths = @paths.elems ?? @paths !! ('.');
    if $recursive && !$json {
        my %tree;
        my Bool $tty = False;
        try { $tty = $*OUT.t };
        if $tty {
            # 终端模式：每找到一个目录就输出并 flush，不再等整棵树。
            %tree = self!ls-tree(@input-paths, :$all, :$classify,
                :$long, :$human, :$sort, :$reverse,
                :emit(-> Str $s { $*OUT.print($s ~ "\n"); $*OUT.flush }));
            return self!ok('ls', (), :out(''));
        }
        %tree = self!ls-tree(@input-paths, :$all, :$classify,
            :$long, :$human, :$sort, :$reverse, :full-paths);
        return self!ok('ls', %tree<entries>,
                       :out(%tree<blocks>.join("\n\n")));
    }

    my @entries;
    for @input-paths -> $path {
        if $dirs-as-files {
            if self!is-glob($path) {
                @entries.append(try { $!sys.glob($path) } // ());
            }
            else {
                my $p = try { $!sys.resolve($path) };
                return self!err('ls', $!.message) unless $p.defined;
                @entries.push($p);
            }
        }
        elsif self!is-glob($path) {
            @entries.append(try { $!sys.glob($path) } // ());
        }
        else {
            my $r = try { $!sys.ls($path, :$all, :$recursive) };
            return self!err('ls', $!.message) unless $r.defined;
            @entries.append($r.List);
        }
    }
    if $json {
        my @rows;
        for @entries -> $e {
            my $st = try { $!sys.stat($e) };
            my Str $type = $e.l ?? 'symlink' !! ($e.d ?? 'dir' !! 'file');
            my Str $modified = '';
            if $st.defined && $st.modified.defined
               && $st.modified >= Instant.from-posix(946684800) {
                $modified = $st.modified.DateTime.Str;
            }
            @rows.push({
                name => $e.basename, type => $type,
                size => ($st.defined ?? $st.size !! 0),
                modified => $modified, path => $e.Str,
            });
        }
        my $table = Rakuish::Data::Table.from-rows(@rows);
        return self!ok('ls', $table, :out($table.to-json(:pretty)));
    }
    my Str $text = ($long || $classify || $reverse || $sort ne 'name')
        ?? self!ls-text(@entries, :$classify, :$long, :$human, :$sort, :$reverse)
        !! '';
    self!ok('ls', @entries.List, :out($text));
}

method !cmd-cat(@args --> Result) {
    return self!err('cat', '用法: cat 文件...') unless @args.elems;
    my Str $text = '';
    for self!expand-globs(@args) -> $p {
        my $v = try { $!sys.read($p) };
        return self!err('cat', $!.message) unless $v.defined;
        $text ~= $v.Str;
    }
    self!ok('cat', $text, :out($text));
}

method !cmd-read(@args --> Result) {
    return self!err('read', '用法: read 文件...') unless @args.elems;
    my Str $text = '';
    for self!expand-globs(@args) -> $p {
        my $v = try { $!sys.read($p) };
        return self!err('read', $!.message) unless $v.defined;
        $text ~= $v.Str;
    }
    self!ok('read', $text, :out($text));
}

method !cmd-cd(@args --> Result) {
    return self!err('cd', '用法: cd [目录|-]') if @args.elems > 1;
    my Str $target;
    if @args.elems == 0 {
        $target = (try { $*HOME.Str }) // '';
        return self!err('cd', '无法确定 HOME') unless $target.chars;
    }
    elsif @args[0] eq '-' {
        return self!err('cd', '没有上一个目录') unless $!prev-cwd.defined;
        $target = $!prev-cwd.Str;
    }
    else {
        $target = self!expand-home(@args[0].Str);
    }
    my $old = $!sys.cwd;
    my $p = try { $!sys.cd($target) };
    return self!err('cd', $!.message) unless $p.defined;
    $!prev-cwd = $old;
    self!ok('cd', $p, :out(''));
}

method !native-path(Str $p --> Str) {
    $*DISTRO.is-win ?? $p.subst(:g, '/', '\\') !! $p;
}

method !help-index(--> Str) {
    q:to/HELP/
        Shell 日常命令:
          cd pwd clear history set jobs which alias unalias config hook explore ls cat head tail echo
          mkdir touch cp mv rm stat export unset glob grep wc help perf open hint plugin

        Raku / 文件 API:
          read write append exec env
          ls-table open-data save-data

        计时（Raku 原生，不是 magic）:
          timed { ... } / bench({ ... }, :repeat(5)) / perf

        用 `help <命令>` 或 `<命令> --help` 查看具体参数。
        HELP
}

method usage(Str $cmd --> Str) {
    given $cmd {
        when 'cd' { q:to/USAGE/
        用法: cd [目录|-]
          cd           回到 $*HOME
          cd ..        上一级
          cd -         上一个目录
          cd ~/x       展开家目录
        USAGE
        }
        when 'pwd' { "用法: pwd [-L|-P]\n  显示当前会话目录（当前实现两种都等价）" }
        when 'clear' { "用法: clear\n  清屏；非 TTY 下不输出控制码" }
        when 'history' { "用法: history\n  显示本会话已执行的命令行（带编号）" }
        when 'hint' { "用法: hint [输入行]\n  查看该输入的上下文提示；不带参数查上一格\n  config set hints on|off 控制 TTY 下自动显示" }
        when 'plugin' { "用法: plugin [list|load PATH|unload NAME|info NAME]\n  加载显式本地 Raku 插件（返回 Command 对象）；需 config set plugins on\n  加载即执行本地 Raku 代码，只加载可信文件；Agent 不开放" }
        when 'which' { "用法: which 命令\n  查 Shell 内置或 PATH 上的外部命令" }
        when 'alias' { "用法: alias [name=command]\n  查看或设置会话别名（写入 ~/.rakuish-config.json）" }
        when 'unalias' { "用法: unalias name\n  删除别名" }
        when 'config' { "用法: config [get KEY|set KEY VALUE|unset KEY]\n  查看/修改会话配置" }
        when 'hook' { "用法: hook [add EVENT CODE|clear EVENT|run EVENT]\n  管理启动等事件 hook（写入配置）" }
        when 'explore' { "用法: explore [路径]\n  分页查看上一格 Table，或从 JSON/CSV/目录加载" }
        when 'set' { "用法: set [-e|+e]\n  -e 失败时请求退出（errexit）；+e 关闭" }
        when 'jobs' { "用法: jobs\n  列出本会话通过 sys.spawn 启动的后台进程" }
        when 'ls' {
            q:to/USAGE/
        用法: ls [选项] [路径...]
          -a, -A        显示隐藏项
          -l            长格式（类型/权限/大小/日期/名称）
          -h            人类可读大小（配合 -l）
          -F, -p        目录后加 /
          -R            递归
          -t            按修改时间排序
          -S            按大小排序
          -r            反向排序
          -d            只列目录本身
          -1            一行一个
          --json        输出结构化 JSON（name/type/size/modified/path）
        USAGE
        }
        when 'open' { "用法: open [--raw] [--external] 文件\n  .json → Record/Table；.csv → Table；.parquet/.pq → Table（必须 --external）；其它按文本\n  CSV 方言参数只在 Raku 层：open-data(path, :allow-external, :csv-options(...))" }
        when 'cat' { "用法: cat 文件...\n  原样输出文件内容" }
        when 'head' { "用法: head [-n N] 文件\n  输出前 N 行（默认 10）" }
        when 'tail' { "用法: tail [-n N] 文件\n  输出后 N 行（默认 10）" }
        when 'echo' { "用法: echo [-n] 文字...\n  输出参数，空格分隔；参数中的 \$NAME 按会话 env 展开" }
        when 'mkdir' { "用法: mkdir [-p] 目录...\n  创建目录" }
        when 'touch' { "用法: touch 文件...\n  文件不存在时创建空文件" }
        when 'cp' { "用法: cp [-r] 源 目标\n  -r, -R 复制目录树" }
        when 'mv' { "用法: mv 源 目标\n  移动/重命名；目标存在时覆盖" }
        when 'rm' { "用法: rm [-r] [-f] [-n] 路径...\n  -r, -R 递归\n  -f 不存在也成功\n  -n dry-run" }
        when 'stat' { "用法: stat 路径\n  显示 path/type/size/mode/modified" }
        when 'export' { "用法: export KEY=VALUE...\n  写入会话 env" }
        when 'unset' { "用法: unset KEY...\n  删除会话 env 变量" }
        when 'glob' {
            '用法: glob 模式 [目录]' ~ "\n"
              ~ '  * 不跨目录；? 单字符；**/ 任意深度；[a-z] 字符集；{a,{b,c}} 嵌套 brace' ~ "\n"
              ~ '  反斜杠转义请写 Raku glob(...)；Shell 薄层会把 \ 当转义前缀吃掉'
        }
        when 'grep' { "用法: grep [-inv] [-F|-E] 模式 文件...\n  -i 忽略大小写\n  -n 行号\n  -v 反向匹配\n  -F 字面量，-E 正则（默认）" }
        when 'wc' { "用法: wc [-l] [-w] [-c] 文件...\n  -l 行数，-w 词数，-c 字符数" }
        when 'read' { "用法: read 文件...\n  原样读取文本文件（与 cat 同源；二进制请用 sys.read :bin）" }
        when 'write' { "用法: write 路径 数据 [:append] [:mkdir] [:backup] [:atomic]\n  写入文件，默认原子替换" }
        when 'append' { "用法: append 路径 数据\n  追加写入；不宣称原子" }
        when 'exec' { "用法: exec 程序 [参数...]\n  argv-only，不经过 shell；返回 Result" }
        when 'env' { "用法: env\n  显示会话环境变量（KEY=VALUE）" }
        when 'ls-table' { "用法: ls-table [路径]\n  返回 Rakuish::Data::Table（name/type/size/modified/path）" }
        when 'open-data' { "用法: open-data 文件 [--raw] [:allow-external] [:csv-options]\n  .parquet/.pq 需 :allow-external；.csv + :allow-external 可传 delimiter/quote/escape/header/skip/all-varchar/nullstr" }
        when 'save-data' { "用法: save-data 文件 值 [:allow-external] [:csv-options]\n  按扩展名写 JSON/CSV/Parquet；写出方言仅支持 delimiter/quote/escape/header/nullstr" }
        when 'describe' { "用法: describe [表名]\n  返回结构化 Table（name/type/nullable/non_null/distinct/total/sample）\n  无参数摘要上一格 Table；有参数需先 open-db(...)" }
        when 'perf' { "用法: perf [N]\n  显示最近 N 格耗时（默认 10，上限 200）与平均/最慢；耗时由 prompt 同源数据记录" }
        when 'help' { "用法: help [命令]\n  不带参数列出全部内置命令；带命令显示该命令帮助" }
        default { '' }
    }
}

method !cmd-pwd(@args --> Result) {
    for @args -> $a {
        return self!err('pwd', "不支持的 pwd 选项: {$a.Str}")
            unless $a.Str eq '-L' || $a.Str eq '-P';
    }
    my Str $p = self!native-path($!sys.cwd.Str);
    self!ok('pwd', $p, :out($p));
}

method !cmd-clear(@args --> Result) {
    return self!err('clear', 'clear 不接受参数') if @args.elems;
    # 只在真实 TTY 下发送 ANSI；管道/重定向时不污染输出。
    my Bool $tty = False;
    try { $tty = $*OUT.t };
    self!ok('clear', '', :out($tty ?? "\e[2J\e[H" !! ''));
}

method !cmd-rm(@args --> Result) {
    my Bool $recursive = False;
    my Bool $force = False;
    my Bool $dry = False;
    my @paths;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'r' | 'R' { $recursive = True }
                    when 'f' { $force = True }
                    when 'n' { $dry = True }
                    default { return self!err('rm', "不支持的 rm 选项: -{$f}") }
                }
            }
        }
        else { @paths.push($s) }
    }
    return self!err('rm', '用法: rm [-r] [-f] 路径...') unless @paths.elems;

    my Int $count = 0;
    my @outs;
    for self!expand-globs(@paths) -> $p {
        my $r = try { $!sys.rm($p, :$recursive, :$force, :dry-run($dry)) };
        return self!err('rm', $!.message) unless $r.defined;
        return $r unless $r.ok;
        $count += ($r.value // 0).Int;
        @outs.push($r.out) if $r.out.chars;
    }
    self!ok('rm', $count, :out(''));
}

method !cmd-mkdir(@args --> Result) {
    my @paths;
    for @args -> $a {
        if $a.Str eq '-p' || $a.Str eq '--parents' { next }
        return self!err('mkdir', "不支持的 mkdir 选项: {$a.Str}")
            if $a.Str.starts-with('-');
        @paths.push($a.Str);
    }
    return self!err('mkdir', '用法: mkdir [-p] 目录...') unless @paths.elems;
    my @made;
    for @paths -> $p {
        my $r = try { $!sys.mkdir($p) };
        return self!err('mkdir', $!.message) unless $r.defined;
        return $r unless $r.ok;
        @made.push($r.value // $p);
    }
    self!ok('mkdir', @made.List, :out(''));
}

method !cmd-cp(@args --> Result) {
    my Bool $recursive = False;
    my @paths;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s eq '-r' || $s eq '-R' || $s eq '--recursive' {
            $recursive = True;
        }
        elsif $s.starts-with('-') {
            return self!err('cp', "不支持的 cp 选项: {$s}");
        }
        else { @paths.push($s) }
    }
    return self!err('cp', '用法: cp [-r] 源 目标') unless @paths.elems == 2;
    my $r = try { $!sys.cp(@paths[0], @paths[1], :$recursive) };
    return self!err('cp', $!.message) unless $r.defined;
    return $r unless $r.ok;
    self!ok('cp', $r.value, :out(''));
}

method !cmd-mv(@args --> Result) {
    return self!err('mv', '用法: mv 源 目标') unless @args.elems == 2;
    my $r = try { $!sys.mv(@args[0], @args[1]) };
    return self!err('mv', $!.message) unless $r.defined;
    return $r unless $r.ok;
    self!ok('mv', $r.value, :out(''));
}

method !cmd-stat(@args --> Result) {
    return self!err('stat', '用法: stat 路径') unless @args.elems == 1;
    my $st = try { $!sys.stat(@args[0]) };
    return self!err('stat', $!.message) unless $st.defined;
    self!ok('stat', $st, :out(self!stat-text($st)));
}

method !cmd-echo(@args --> Result) {
    my Bool $no-newline = False;
    my @words;
    for @args -> $a {
        if $a.Str eq '-n' && !$no-newline { $no-newline = True; next }
        @words.push($a.Str);
    }
    my Str $text = @words.join(' ');
    self!ok('echo', $text, :out($text), :no-newline($no-newline));
}

method !cmd-head-tail(Str $op, @args --> Result) {
    my Int $n = 10;
    my Str $file = '';
    my Int $i = 0;
    while $i < @args.elems {
        my Str $a = @args[$i].Str;
        if $a eq '-n' {
            return self!err($op, '用法: head|tail [-n N] 文件') if $i + 1 >= @args.elems;
            $n = @args[$i + 1].Int;
            $i += 2;
        }
        elsif $a ~~ /^ '-' (<[0..9]>+) $/ {
            $n = $0.Int;
            $i++;
        }
        else {
            return self!err($op, '用法: head|tail [-n N] 文件') if $file.chars;
            $file = $a;
            $i++;
        }
    }
    return self!err($op, '用法: head|tail [-n N] 文件')
        unless $file.chars && $n >= 0;
    my $text = try { $!sys.read($file) };
    return self!err($op, $!.message) unless $text.defined;
    my @lines = $text.Str.lines;
    my @selected = $op eq 'head' ?? @lines.head($n) !! @lines.tail($n);
    my Str $out = @selected.join("\n");
    self!ok($op, $out, :out($out));
}

method !cmd-export(@args --> Result) {
    return self!err('export', '用法: export KEY=VALUE ...') unless @args.elems;
    for @args -> $a {
        my Str $s = $a.Str;
        my Int $eq = $s.index('=');
        return self!err('export', "需要 KEY=VALUE: {$s}") unless $eq.defined;
        $!sys.set-env($s.substr(0, $eq), $s.substr($eq + 1));
    }
    self!ok('export', @args.List, :out(''));
}

method !cmd-unset(@args --> Result) {
    return self!err('unset', '用法: unset KEY...') unless @args.elems;
    for @args -> $a { $!sys.unset-env($a.Str) }
    self!ok('unset', @args.List, :out(''));
}

method !cmd-touch(@args --> Result) {
    return self!err('touch', '用法: touch 文件...') unless @args.elems;
    for @args -> $a {
        my $p = try { $!sys.resolve($a.Str) };
        return self!err('touch', $!.message) unless $p.defined;
        if !($p.e || $p.l) {
            my $r = try { $!sys.write($a.Str, '', :atomic) };
            return self!err('touch', $!.message) unless $r.defined;
        }
    }
    self!ok('touch', @args.List, :out(''));
}

method !cmd-glob(@args --> Result) {
    return self!err('glob', '用法: glob 模式 [目录]') unless @args.elems;
    my $r = try {
        @args.elems > 1
            ?? $!sys.glob(@args[0].Str, @args[1].Str)
            !! $!sys.glob(@args[0].Str)
    };
    return self!err('glob', $!.message) unless $r.defined;
    my @names = $r.List.map(*.basename);
    self!ok('glob', $r.List, :out(@names.join("\n")));
}

method !cmd-grep(@args --> Result) {
    my Bool $ignore = False;
    my Bool $line-no = False;
    my Bool $invert = False;
    my Bool $fixed = False;
    my @rest;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'i' { $ignore = True }
                    when 'n' { $line-no = True }
                    when 'v' { $invert = True }
                    when 'F' { $fixed = True }
                    when 'E' { $fixed = False }
                    default { return self!err('grep', "不支持的 grep 选项: -{$f}") }
                }
            }
        }
        else { @rest.push($s) }
    }
    return self!err('grep', '用法: grep [-inv] 模式 文件...') unless @rest.elems >= 2;
    my Str $pat = @rest.shift;
    my @files = self!expand-globs(@rest);
    my $rx = $fixed ?? Nil !! (try {
        $ignore ?? rx:i/ <$pat> / !! rx/ <$pat> /
    });
    return self!err('grep', "无效正则: {$pat}") if !$fixed && !$rx.defined;
    my @out;
    for @files -> $file {
        my $text = try { $!sys.read($file) };
        return self!err('grep', $!.message) unless $text.defined;
        for $text.Str.lines.kv -> $i, $line {
            my Bool $hit;
            if $fixed {
                $hit = $ignore
                    ?? $line.lc.contains($pat.lc)
                    !! $line.contains($pat);
            }
            else {
                $hit = so($line ~~ $rx);
            }
            $hit = !$hit if $invert;
            next unless $hit;
            my Str $row = '';
            $row ~= "{$i + 1}:" if $line-no;
            $row ~= "{$file}:" if @files.elems > 1;
            @out.push($row ~ $line);
        }
    }
    self!ok('grep', @out.List, :out(@out.join("\n")));
}

method !cmd-wc(@args --> Result) {
    my Bool $lines = False;
    my Bool $words = False;
    my Bool $chars = False;
    my @files;
    for @args -> $a {
        my Str $s = $a.Str;
        if $s.starts-with('-') && $s ne '-' {
            for $s.substr(1).comb -> $f {
                given $f {
                    when 'l' { $lines = True }
                    when 'w' { $words = True }
                    when 'c' { $chars = True }
                    default { return self!err('wc', "不支持的 wc 选项: -{$f}") }
                }
            }
        }
        else { @files.push($s) }
    }
    $lines = $words = $chars = True
        unless $lines || $words || $chars;
    @files = self!expand-globs(@files);
    return self!err('wc', '用法: wc [-l] [-w] [-c] 文件...') unless @files.elems;

    my @rows;
    for @files -> $file {
        my $text = try { $!sys.read($file) };
        return self!err('wc', $!.message) unless $text.defined;
        my Str $t = $text.Str;
        my Int $l = $t.lines.elems;
        my Int $w = $t.words.elems;
        my Int $c = $t.chars;
        my @cols;
        @cols.push($l) if $lines;
        @cols.push($w) if $words;
        @cols.push($c) if $chars;
        @cols.push($file);
        @rows.push(@cols.join(' '));
    }
    self!ok('wc', @rows.List, :out(@rows.join("\n")));
}

method !cmd-open(@args --> Result) {
    my Bool $raw = False;
    my Bool $external = False;
    my @paths;
    for @args -> $a {
        if $a.Str eq '--raw' { $raw = True }
        elsif $a.Str eq '--external' { $external = True }
        elsif $a.Str.starts-with('-') {
            return self!err('open', "不支持的 open 选项: {$a.Str}");
        }
        else { @paths.push($a.Str) }
    }
    return self!err('open', '用法: open [--raw] [--external] 文件')
        unless @paths.elems == 1;
    my $data = try {
        Rakuish::Data::open-data($!sys, @paths[0], :$raw,
                                 :allow-external($external))
    };
    return self!err('open', $!.message) unless $data.defined;
    my Str $out = $data ~~ Rakuish::Data::Table
        ?? $data.to-text
        !! $data ~~ Str
            ?? $data
            !! Rakuish::Data::to-json-data($data, :pretty);
    self!ok('open', $data, :out($out));
}

method !cmd-which(@args --> Result) {
    return self!err('which', '用法: which 命令') unless @args.elems == 1;
    my Str $name = @args[0].Str;
    if $name (elem) COMMANDS {
        return self!ok('which', "shell: {$name}", :out("shell: {$name}"));
    }
    my Str $path = $!sys.env<PATH> // '';
    my Str $sep = $*DISTRO.is-win ?? ';' !! ':';
    my Str $suffix = $*DISTRO.is-win ?? '.exe' !! '';
    for $path.split($sep) -> $dir {
        next unless $dir.chars;
        my $candidate = IO::Path.new($dir).add($name ~ $suffix);
        if $candidate.e && ($candidate.x || $*DISTRO.is-win) {
            return self!ok('which', $candidate.Str, :out($candidate.Str));
        }
    }
    self!err('which', "未找到: {$name}");
}

method !cmd-help(@args --> Result) {
    if @args.elems && @args[0].Str eq '--find' {
        my Str $needle = @args.skip(1).map(*.Str).join(' ');
        return self!err('help', '用法: help --find 文本') unless $needle.chars;
        my @hits;
        for COMMANDS.sort -> $c {
            my Str $u = self.usage($c);
            if $u.contains($needle) {
                @hits.push($c);
            }
        }
        my Str $out = @hits.elems
            ?? @hits.map({ "{$_}\n" ~ self.usage($_) }).join("\n\n")
            !! "没有匹配: {$needle}";
        return self!ok('help', @hits.List, :out($out));
    }
    return self!ok('help', '', :out(self!help-index)) unless @args.elems;
    my Str $cmd = @args[0].Str;
    my Str $usage = self.usage($cmd);
    return self!err('help', "没有这个内置命令: {$cmd}") unless $usage.chars;
    self!ok('help', $cmd, :out($usage));
}

method completions(Str $line, Int $pos --> List) {
    my Int $at = $pos min $line.chars;
    my Str $prefix = $line.substr(0, $at);
    return () if $prefix.starts-with('!');
    return () if $prefix ~~ /<[$@%&()\[\]{};|<>]>/;

    # 命令名补全：还没输入空格，或刚输入 help。
    if $prefix !~~ /\s/ {
        return COMMANDS.grep({ .starts-with($prefix) })
            .sort.map({ $_ ~ ' ' }).List;
    }

    my Str $cmd = ($prefix.split(/\s+/))[0] // '';
    return () unless $cmd (elem) COMMANDS;

    if $cmd eq 'help' && $prefix ~~ /^ 'help' \s+ (\S*)$/ {
        my Str $frag = ~$0;
        return COMMANDS.grep({ .starts-with($frag) })
            .sort.map({ 'help ' ~ $_ ~ ' ' }).List;
    }

    my Int $start = $prefix.chars;
    while $start > 0 && $prefix.substr($start - 1, 1) !~~ /\s/ {
        $start--;
    }
    my Str $before = $prefix.substr(0, $start);
    my Str $frag = $prefix.substr($start);
    return () if $frag.contains('$');

    my Str $dir = '';
    my Str $base = $frag;
    if $frag.contains('/') || $frag.contains('\\') {
        my Int $slash = max($frag.rindex('/') // -1, $frag.rindex('\\') // -1);
        $dir = $frag.substr(0, $slash + 1);
        $base = $frag.substr($slash + 1);
    }
    my @entries = try {
        $!sys.ls($dir.chars ?? $dir !! '.', :all($base.starts-with('.')))
    } // ();
    my @out;
    for @entries -> $e {
        my Str $name = $e.basename;
        next unless $name.starts-with($base);
        @out.push($before ~ $dir ~ $name ~ ($e.d ?? '/' !! ''));
    }
    @out.sort.List;
}

method !cmd-jobs(@args --> Result) {
    my $t = $!sys.jobs;
    my Str $out = $t.elems ?? $t.to-text !! '没有后台任务';
    self!ok('jobs', $t, :$out);
}

method !has-unquoted-meta(Str $s, Bool :$braces = False --> Bool) {
    my Str $quote = '';
    my Bool $esc = False;
    for $s.comb -> $c {
        if $esc { $esc = False; next }
        if $quote ne '' {
            if $quote eq '"' && $c eq '\\' { $esc = True }
            elsif $c eq $quote { $quote = '' }
            next;
        }
        if $c eq q{'} || $c eq q{"} { $quote = $c; next }
        if $c eq '\\' { $esc = True; next }
        return True if $c ~~ /<[%@&();|<>]>/;
        return True if $braces && $c ~~ /<[\[\]{}]>/;
    }
    False;
}

method handle(Str $line --> Result) {
    my Str $trim = $line.trim;
    return Nil unless $trim.chars;
    my @args = self!split($trim);
    return Nil unless @args.elems;

    my Str $cmd = @args.shift.Str;
    @args = @args.map({ self!expand-home(.Str) }).List;
    @args = self!expand-env(@args);

    return Nil unless $cmd (elem) COMMANDS;

    # 未展开的 $NAME 仍是 Raku 变量，交回 Raku；已由会话 env 展开的没有 $。
    return Nil if @args.elems && @args.grep({ .Str.contains('$') }).elems;

    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        my Str $usage = self.usage($cmd);
        return self!ok('help', $cmd, :out($usage)) if $usage.chars;
    }

    # 只处理真正实现的 Shell 命令；其余（write/append/exec/...）是 Raku API，
    # 保留 help/补全条目，但执行时交回 Raku。
    return Nil unless $cmd (elem) SHELL-COMMANDS;

    if @args.grep({ $_ eq '|' || $_ eq '>' || $_ eq '>>' || $_ eq '<' }).elems {
        return self!err('shell', '不支持管道/重定向；用 ! 交给外部 argv 程序');
    }

    # 只看引号外的元字符。`echo "a;b"`、`cat "file(1).txt"` 是字面参数，
    # 不应因为引号内的标点被误交给 Raku。
    if $cmd ne 'export' && $cmd ne 'grep'
       && self!has-unquoted-meta($line) {
        return Nil;
    }
    if $cmd ne 'glob' && $cmd ne 'export' && $cmd ne 'grep'
       && self!has-unquoted-meta($line, :braces) {
        return Nil;
    }

    given $cmd {
        when 'cd'    { self!cmd-cd(@args) }
        when 'pwd'   { self!cmd-pwd(@args) }
        when 'clear' { self!cmd-clear(@args) }
        when 'ls'    { self!cmd-ls(@args) }
        when 'cat'   { self!cmd-cat(@args) }
        when 'read'  { self!cmd-read(@args) }
        when 'rm'    { self!cmd-rm(@args) }
        when 'mkdir' { self!cmd-mkdir(@args) }
        when 'cp'    { self!cmd-cp(@args) }
        when 'mv'    { self!cmd-mv(@args) }
        when 'stat'  { self!cmd-stat(@args) }
        when 'echo'  { self!cmd-echo(@args) }
        when 'head'  { self!cmd-head-tail('head', @args) }
        when 'tail'  { self!cmd-head-tail('tail', @args) }
        when 'export' { self!cmd-export(@args) }
        when 'unset'  { self!cmd-unset(@args) }
        when 'touch'  { self!cmd-touch(@args) }
        when 'glob'   { self!cmd-glob(@args) }
        when 'grep'   { self!cmd-grep(@args) }
        when 'wc'     { self!cmd-wc(@args) }
        when 'help'   { self!cmd-help(@args) }
        when 'jobs'   { self!cmd-jobs(@args) }
        when 'which'  { self!cmd-which(@args) }
        when 'open'   { self!cmd-open(@args) }
        default       { Nil }
    }
}
