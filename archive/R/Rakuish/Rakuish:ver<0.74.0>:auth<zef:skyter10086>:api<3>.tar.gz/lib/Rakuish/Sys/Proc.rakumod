unit class Rakuish::Sys::Proc;

# Rakuish::Sys::Proc —— API v3 的进程 API（ADR-0001 / Phase 2）。
#
# 铁律：
#   · 只接 argv 数组，**永不经过 shell**；不解析 $, |, >, *, &&, heredoc；
#   · cwd / env 是 start() 的参数，不改宿主的 $*CWD / %*ENV；
#   · 用 Proc::Async 真流式 + timeout/cancel，不再用临时文件冒充管道；
#   · exec 永远返回 Result，启动失败也收敛成 code=127，不往外抛。
#
# ⚠ Raku API 陷阱（本机 2026.09 实测）：
#   Proc::Async.new 用 *%_ 吞掉多余命名参数 —— 把 :cwd / :env 传给 new
#   不报错但**完全不生效**。必须传给 start(:cwd(...), :ENV(...))，且 ENV 大写。
#   write 返回 Promise（要 await），close-stdin 返回 Bool（不能 await）。

use Rakuish::Result;
use Terminal::API;
# 0.73.0：`tty-exec` 的进程组交接（NativeCall / ADR-0010）。
# native 符号是**调用时**解析的，Windows 上加载本模块不会碰 libc ——
# 那条路径由 `$*DISTRO.is-win` 挡在所有调用之前。
use Rakuish::Sys::PosixSpawn;

# ── 宿主 termios 快照（0.72.4 / ADR-0009 修订）────────────────────────
# `tty-exec` 把宿主 TTY 的三条 fd 直接 bind 给子进程。子进程（vim / less /
# stty …）把它改成 raw / 关掉 ISIG 后不还原时，行编辑器下一轮 prompt 会把
# 污染态当成新基准「保存并恢复」，污染就此固化（实测 lflag 35387→35376）。
# 这里在交接前多存一份，方法返回时无条件恢复。
# Terminal::API 已封装 Linux / macOS / BSD 三套 CStruct 与 Windows console
# API，不在 Rakuish 里重写 NativeCall。public 且可被子类覆盖，便于回归
# 注入「快照不可用」的对照场景。
method termios-snapshot($fd) {
    return Nil if !$fd.defined || $fd < 0;
    (try { Terminal::API::get-config($fd) }) // Nil
}

method termios-restore($saved, $fd --> Bool) {
    return False unless $saved.defined;
    so (try {
        Terminal::API::restore-config($saved, $fd,
                                      :when(Terminal::API::DRAIN));
        True
    })
}

# 去掉 PTY 输出里的终端控制序列；保留换行/Tab。ConPTY 会额外塞入
# `ESC[?9001h` 这类模式序列，Agent 不应把它们当业务输出。
sub strip-terminal-controls(Str $s --> Str) {
    my Str $t = $s;
    $t = $t.subst(:g, /\e\[ .*? <[A..Z a..z]>/, '');
    $t = $t.subst(:g, /\e\] .*? \x07/, '');
    $t = $t.subst(:g, /<[ \x00..\x08 \x0B \x0C \x0E..\x1F \x7F ]>/, '');
    $t = $t.subst("\r\n", "\n", :g);
    $t.subst(:g, "\r", "\n");
}

# 按 UTF-8 字节上限截断，但不切坏多字节字符（二分找最大安全前缀）。
sub clip-bytes(Str $s, Int $cap, Bool $trunc is rw --> Str) {
    return $s if $cap <= 0 || $s.encode('utf-8').elems <= $cap;
    $trunc = True;
    my Int $lo = 0;
    my Int $hi = $s.chars;
    while $lo < $hi {
        my Int $mid = ($lo + $hi + 1) div 2;
        if $s.substr(0, $mid).encode('utf-8').elems <= $cap { $lo = $mid }
        else { $hi = $mid - 1 }
    }
    $s.substr(0, $lo)
}

# ── 异步句柄 ─────────────────────────────────────────────────────────
class Handle is export {
    has Proc::Async $.proc      is required;
    has Promise     $.promise   is required;
    has Channel     $.out-ch    is required;
    has Channel     $.err-ch    is required;
    has Instant     $.started   is required;
    has Int  $.timeout-ms = 0;
    has Int  $.max-bytes  = 0;
    has Str  $.op    = 'exec';
    has Str  $.exe   = '';
    has      $.argv = ();
    has Bool $.cancelled is rw = False;
    has Bool $.timed-out is rw = False;

    # 真流式：调用方可以 .tap 逐块消费，而不是等进程结束
    method stdout(--> Supply) { $!out-ch.Supply }
    method stderr(--> Supply) { $!err-ch.Supply }

    method cancel(--> Bool) {
        # 只有仍 Planned 才能取消；被 kill 的 Promise 是 Broken，不是 Kept。
        return False unless $!promise.status ~~ Planned;
        $!cancelled = True;
        so try { $!proc.kill; True }
    }

    method wait(--> Result) {
        # 先并发消费 stdout/stderr，再等进程。否则子进程输出超过管道缓冲时
        # 会阻塞，`max-bytes` 也只能在进程结束后才生效（无限输出会先吃内存）。
        my Str $raw-out = '';
        my Str $raw-err = '';
        my Bool $truncated = False;

        my $out-task = start {
            loop {
                my $chunk;
                my Bool $got = so try { $chunk = $!out-ch.receive; True };
                last unless $got && $chunk.defined;
                my Str $piece = $chunk.Str;
                if $!max-bytes > 0 {
                    my Str $combined = $raw-out ~ $piece;
                    if $combined.encode('utf-8').elems > $!max-bytes {
                        $truncated = True;
                        $raw-out = clip-bytes($combined, $!max-bytes, $truncated);
                    }
                    else {
                        $raw-out = $combined;
                    }
                }
                else {
                    $raw-out ~= $piece;
                }
            }
        };
        my $err-task = start {
            loop {
                my $chunk;
                my Bool $got = so try { $chunk = $!err-ch.receive; True };
                last unless $got && $chunk.defined;
                my Str $piece = $chunk.Str;
                if $!max-bytes > 0 {
                    my Str $combined = $raw-err ~ $piece;
                    if $combined.encode('utf-8').elems > $!max-bytes {
                        $truncated = True;
                        $raw-err = clip-bytes($combined, $!max-bytes, $truncated);
                    }
                    else {
                        $raw-err = $combined;
                    }
                }
                else {
                    $raw-err ~= $piece;
                }
            }
        };

        # ⚠ Raku 坑（实测）：sink 上下文的 `try { await $broken };` **不会**吞掉
        #   异常，脚本会直接终止；必须把 try 的结果赋值给变量，强制非 sink 上下文。
        if $!timeout-ms > 0 {
            my $any = (try {
                await Promise.anyof($!promise, Promise.in($!timeout-ms / 1000));
                True
            }) // False;
            # 只有仍 Planned 才算超时：Kept 是正常结束，Broken 是启动/执行失败。
            # 把 Broken 误判成超时会报出 code=124 且 err 为空（实测踩过）。
            if $!promise.status ~~ Planned {
                $!timed-out = True;
                self.cancel;
                my $settled = try { await $!promise; True };
            }
        }
        else {
            my $settled = try { await $!promise; True };
        }

        # 进程结束后 channel 会关闭；给 5s 护栏，防止某个平台异常收尾挂死。
        my $drain = start { await Promise.allof($out-task, $err-task); True };
        my $drained = (try {
            await Promise.anyof($drain, Promise.in(5));
            True
        }) // False;
        my Bool $drain-timeout = !($drain.status ~~ Kept);
        $truncated = True if $drain-timeout;

        my Str $broken-msg = '';
        if $!promise.status ~~ Broken {
            $broken-msg = (try { $!promise.cause.Str } // '进程启动或执行失败');
        }

        # 正常情况下在上面的流式循环里已按 max-bytes 截断；这里再兜底一次。
        my Str $out = clip-bytes($raw-out, $!max-bytes, $truncated);
        my Str $err = clip-bytes($raw-err, $!max-bytes, $truncated);

        my $p = try { $!promise.result };
        my Int $exit = $p.defined ?? ($p.exitcode // 1) !! ($broken-msg.chars ?? 127 !! 1);
        my Int $code = $!timed-out ?? 124 !! ($!cancelled ?? 137 !! $exit);
        my Bool $ok  = !$!timed-out && !$!cancelled && $code == 0;
        $err ~= ($err.chars ?? "\n" !! '') ~ $broken-msg
            if $broken-msg.chars && !$!timed-out && !$!cancelled;

        my %info = exe        => $!exe,
                   argv       => $!argv.List,
                   timed-out  => $!timed-out,
                   cancelled  => $!cancelled,
                   truncated  => $truncated,
                   start-failed => ($broken-msg.chars > 0),
                   signal     => ($p.defined ?? ($p.signal // 0) !! 0),
                   out-bytes  => $out.encode('utf-8').elems,
                   err-bytes  => $err.encode('utf-8').elems;

        Result.new(:$ok, :$code, :$out, :$err, :value(%info),
                   :op($!op), :elapsed(now - $!started))
    }
}

# ── Proc 门面 ────────────────────────────────────────────────────────
has Int $.max-bytes          = 1024 * 1024;
has Int $.default-timeout-ms = 30_000;

method spawn(Str $exe, *@args,
             IO::Path :$cwd,
             :%env,
             :$in,
             Int :$timeout-ms,
             Int :$max-bytes,
             Str :$op = 'exec' --> Handle) {

    X::Rakuish::Path.new(:detail("exec: 可执行文件不能为空")).throw
        unless $exe.chars;

    my Str $child-cwd = $cwd.defined ?? $cwd.Str !! $*CWD.Str;
    my %child-env = %env.elems ?? %env.Hash !! %*ENV.Hash;
    my Bool $has-in = $in.defined;

    my $proc = $has-in
        ?? Proc::Async.new($exe, |@args, :w)
        !! Proc::Async.new($exe, |@args);

    my $out-ch = $proc.stdout.Channel;
    my $err-ch = $proc.stderr.Channel;

    # cwd / env 只在子进程生效，宿主进程全局状态一个字节都不动
    my $promise = $proc.start(:cwd($child-cwd), :ENV(%child-env));

    my $handle = Handle.new(
        :$proc, :$promise, :$out-ch, :$err-ch,
        :started(now),
        :timeout-ms($timeout-ms // $!default-timeout-ms),
        :max-bytes($max-bytes // $!max-bytes),
        :$op, :$exe, :argv(@args),
    );

    # stdin 写入不能阻塞 spawn：子进程不读 stdin 时，await write 会永久卡住，
    # 而 timeout 要等 Handle 返回后才生效。放到后台任务，wait()/cancel() 仍能工作。
    if $has-in {
        my $bytes = $in ~~ Blob ?? $in !! $in.Str.encode('utf-8');
        start {
            try { await $proc.write($bytes) };
            try { $proc.close-stdin };
        }
    }

    $handle
}

method exec(Str $exe, *@args, *%opts --> Result) {
    my $handle;
    my Str $start-err = '';
    {
        CATCH { default { $start-err = .message } }
        $handle = self.spawn($exe, |@args, |%opts);
    }
    return Result.new(:!ok, :code(127), :op<exec>, :err($start-err),
                      :value({ exe => $exe, argv => @args.List }))
        unless $handle.defined;
    $handle.wait
}

# ── 交互式子进程直通（0.70 / ADR-0007）──────────────────────────────
# 与 exec() 的根本差别：不捕获输出、不设超时、把当前 TTY 的三条标准流
# 直接交给子进程。适用于嵌套 REPL / 编辑器 / 分页器等「自己会结束」的程序。
# 默认 exec() 一行未改；这里也不是后台 job（同步等待，结束即返回）。
method tty-exec(Str $exe, *@args,
                IO::Path :$cwd,
                :%env,
                Str :$op = 'tty-exec',
                *%_ --> Result) {

    # V-116：非 TTY 一律拒绝，绝不在管道里塞控制序列或无限等待 stdin。
    X::Rakuish::Unsupported.new(
        :detail('交互式命令需要 stdin 与 stdout 都是 TTY；管道/脚本请用 exec(...)（ADR-0007）')
    ).throw unless (so try { $*IN.t }) && (so try { $*OUT.t });

    X::Rakuish::Path.new(:detail('tty-exec: 可执行文件不能为空')).throw
        unless $exe.chars;

    my Str $child-cwd = $cwd.defined ?? $cwd.Str !! $*CWD.Str;
    my %child-env = %env.elems ?? %env.Hash !! %*ENV.Hash;

    # 0.72.4：交接前保存宿主 termios。此刻 prompt() 已 leave-raw-mode，
    # 取到的是规范态；必须在把终端交出去之前取，否则存的是子进程污染态。
    # 正常路径显式恢复一次（让 Result 拿到准确标记），LEAVE 幂等兜底
    # 异常 / 早退路径；全部走 try，快照失败绝不毁掉直通本身。
    my $tty-fd = (try { $*IN.native-descriptor } // -1);
    my $term-saved = self.termios-snapshot($tty-fd);
    my Bool $term-restored = False;
    my $sig-tap;

    # 0.73.0：进程组交接状态（V-175 / ADR-0010）。
    # $jc-active 的含义是「本次真的把子进程放进独立进程组**并且**切了前台」，
    # 任何一步失败都置 False 并把原因写进 $jc-reason —— 不假装成功。
    my Bool $jc-active   = False;
    my Bool $fg-restored = False;
    my Int  $my-pgid     = 0;
    my Int  $child-pgid  = 0;
    my Any  $ttou-old    = Nil;
    my Str  $jc-reason   = '';
    my Bool $need-chdir  = False;
    my Bool $spawned     = False;

    my Str $run-err = '';
    my Int $code = 127;
    my Int $sig  = 0;

    # LEAVE 是块级 phaser：非 TTY 守卫在方法开头抛异常时同样会触发，此时
    # 各状态还是类型对象。所有恢复动作都用 .defined / 布尔短路兜住，绝不
    # 让恢复动作覆盖原本的 X::Rakuish::Unsupported 异常消息。
    # 顺序有讲究：前台还给宿主 → 还原 SIGTTOU → 恢复 termios。termios 用
    # DRAIN 会丢弃排队输入，在后台做既无意义又容易踩 SIGTTOU。
    LEAVE {
        try { $sig-tap.close } if $sig-tap.defined;
        try {
            if $jc-active && !$fg-restored {
                $fg-restored = Rakuish::Sys::PosixSpawn::set-foreground($tty-fd, $my-pgid);
            }
        }
        try { Rakuish::Sys::PosixSpawn::restore-sigttou($ttou-old) };
        try {
            $term-restored = self.termios-restore($term-saved, $tty-fd)
                if $term-saved.defined && !$term-restored;
        }
    }

    # 先刷出 prompt / hint，再把终端交出去。
    try { $*OUT.flush };
    try { $*ERR.flush };

    my Instant $t0 = now;

    # ── 路径选择（V-175）────────────────────────────────────────────
    # POSIX 上优先用 posix_spawnp 做进程组交接；只有「能力确实缺失」才降级
    # 回 Proc::Async（父子同组 + SIGINT tap），并在 value 里如实标记原因。
    if !$*DISTRO.is-win {
        $need-chdir = $child-cwd ne $*CWD.Str;
        if $need-chdir {
            # 相对路径 / 冗余分隔符不该触发 chdir 动作，先做一次绝对化比较。
            my Str $abs-want = (try { $child-cwd.IO.absolute.Str }) // $child-cwd;
            my Str $abs-now  = (try { $*CWD.absolute.Str }) // $*CWD.Str;
            $need-chdir = $abs-want ne $abs-now;
        }
        if $need-chdir
           && !(try { Rakuish::Sys::PosixSpawn::addchdir-available } // False) {
            $jc-reason = 'posix_spawn_file_actions_addchdir_np 不可用'
                       ~ '（glibc < 2.29 / macOS < 10.15），无法在 spawn 时切换 cwd';
        }
        else {
            $jc-active = True;
        }
    }
    else {
        $jc-reason = 'Windows 没有 POSIX 前台进程组，Ctrl-C 由 SIGINT tap 兜住';
    }

    # ── POSIX：进程组交接 ───────────────────────────────────────────
    if $jc-active {
        # 交接后父进程就是后台进程，tcsetpgrp 会吃 SIGTTOU —— 必须**真**
        # SIG_IGN。用 Raku 的 signal().tap 是捕获语义，会让恢复那次调用
        # 返回 ENOTTY（ADR-0010 §2.3）。
        $ttou-old = Rakuish::Sys::PosixSpawn::ignore-sigttou();
        $my-pgid  = Rakuish::Sys::PosixSpawn::group-of(0);

        # 交接窗口（spawn 之后、切前台之前）前台仍是父进程组，用户此刻按
        # Ctrl-C 会打到宿主。先挂 tap 兜住，切前台成功后立刻摘掉 —— 正常
        # 运行期间**不依赖** tap，那只是这个微秒级窗口的保险。
        $sig-tap = try { signal(SIGINT).tap(-> $ { }) };

        my $sp = try {
            Rakuish::Sys::PosixSpawn::spawn-in-group(
                $exe, @args.List, %child-env, $child-cwd, $need-chdir)
        };

        if !$sp.defined {
            # NativeCall 完全不可用（异常）：退回原路径，行为等同 0.72.x。
            $jc-active = False;
            $jc-reason = 'posix_spawn 不可用，已回退到 Proc::Async（同组语义）';
        }
        elsif $sp<rc> == 0 {
            $spawned    = True;
            $child-pgid = Rakuish::Sys::PosixSpawn::group-of($sp<pid>.Int);
            if $child-pgid > 0
               && Rakuish::Sys::PosixSpawn::set-foreground($tty-fd, $child-pgid) {
                try { $sig-tap.close };
                $sig-tap = Nil;
            }
            else {
                # 切前台失败：保留 SIGINT tap 兜住宿主，如实退回同组语义。
                $jc-active = False;
                $jc-reason = 'tcsetpgrp 失败，Ctrl-C 仍会打到整个进程组';
            }
            my %w = Rakuish::Sys::PosixSpawn::wait-exit($sp<pid>.Int);
            $sig  = %w<sig>.Int;
            $code = %w<signaled> ?? (128 + $sig) !! (%w<reaped> ?? %w<exit>.Int !! 1);
        }
        else {
            $spawned = True;              # 已尝试启动，不再回退重跑
            $code = 127;
            my Int $rc = $sp<rc>.Int;
            $run-err = $rc == 2
                ?? "子进程启动失败: 找不到可执行文件 $exe"
                !! "子进程启动失败: posix_spawnp rc=$rc（阶段 $sp<stage>）";
        }
    }

    # ── 老路径：Proc::Async（Windows / 降级）────────────────────────
    if !$spawned {
        my $proc = Proc::Async.new($exe, |@args);
        my Str $bind-err = '';
        {
            CATCH { default { $bind-err = .message } }
            $proc.bind-stdin($*IN);
            $proc.bind-stdout($*OUT);
            $proc.bind-stderr($*ERR);
        }
        if $bind-err.chars {
            $term-restored = self.termios-restore($term-saved, $tty-fd)
                if $term-saved.defined;
            return Result.new(:!ok, :code(127), :op($op),
                              :err('TTY 绑定失败: ' ~ $bind-err),
                              :value({ exe => $exe, argv => @args.List, tty => False,
                                       termios-restored => $term-restored,
                                       job-control => False,
                                       'job-control-reason' => $jc-reason,
                                       'fg-restored' => False, pgid => 0 }));
        }

        # 等待期间吞掉父进程的 SIGINT：Ctrl-C 属于前台子进程，不能把宿主
        # REPL 一起带走。LEAVE 关闭 tap 后恢复默认行为。
        $sig-tap = try { signal(SIGINT).tap(-> $ { }) };

        my $p = Nil;
        {
            CATCH { default { $run-err = '子进程启动失败: ' ~ .message } }
            my $promise = $proc.start(:cwd($child-cwd), :ENV(%child-env));
            $p = await $promise;         # 故意不设超时：交互时长由用户决定
        }
        $code = $p.defined ?? ($p.exitcode // 1) !! 127;
        $sig  = $p.defined ?? ($p.signal // 0) !! 0;
    }

    # 前台还给宿主（POSIX 分支）。放在 termios 恢复之前：DRAIN 会丢弃排队
    # 输入，而且后台进程改终端属性会踩 SIGTTOU。
    if $jc-active && !$fg-restored {
        $fg-restored = Rakuish::Sys::PosixSpawn::set-foreground($tty-fd, $my-pgid);
    }
    $term-restored = self.termios-restore($term-saved, $tty-fd)
        if $term-saved.defined;

    my Duration $d = now - $t0;
    my Bool $ok = $code == 0 && !$run-err.chars;

    # 子进程输出不进 Result（无法捕获，也不该伪造）。只给一行交接摘要，
    # 前导换行把光标从嵌套 REPL 的任意列拉回行首。
    my Str $summary = sprintf("\n↩ %s 已退出 · code=%d · %.2fs",
                              $exe, $code, $d.Num);
    my %info = exe       => $exe,
               argv      => @args.List,
               tty       => True,
               timed-out => False,
               exit      => $code,
               signal    => $sig,
               elapsed   => ~$d,
               termios-restored => $term-restored,
               job-control      => so $jc-active,
               fg-restored      => $fg-restored,
               pgid             => $child-pgid;
    %info<job-control-reason> = $jc-reason if $jc-reason.chars;

    Result.new(:$ok, :$code, :op($op),
               :out($run-err.chars ?? '' !! $summary),
               :err($run-err), :value(%info), :elapsed($d))
}

# ── PTY 能力探测（0.72.2 / R-1）──────────────────────────────────────
# `Proc::Async.new` 用 `*%_` 吞掉未知命名参数：旧 Rakudo 传 :pty 不报错、
# 不生效。只靠 META6 拦不住（zef 没有可靠的 Rakudo 下限字段），所以做
# 「版本 + 真 isatty 探针」双检，结果按进程缓存一次。
# 该方法是 public 且可被子例覆盖，便于在测试里注入「不支持」而无需装旧版。
my $PTY-CAPABILITY;
my Lock $PTY-LOCK .= new;

method pty-capability(--> Hash) {
    $PTY-LOCK.protect({
        $PTY-CAPABILITY //= self!probe-pty-capability();
        $PTY-CAPABILITY
    })
}

method !probe-pty-capability(--> Hash) {
    my $ver = try { $*RAKU.compiler.version };
    return %(
        capable => False,
        version => ($ver.defined ?? ~$ver !! 'unknown'),
        reason  => 'Rakudo 版本未知或低于 2025.12（:pty 从 2025.12 起提供）',
    ) unless $ver.defined && $ver >= v2025.12;

    # 真探针：让子进程自己报告 $*OUT.t。:pty 被吞掉时会打印 PTY-NO。
    my Bool $probe-ok = False;
    my Str  $probe-reason = 'isatty 探针失败';
    my $probe-tap;
    {
        CATCH { default { $probe-reason = .message } }
        my $probe = Proc::Async.new(
            $*EXECUTABLE.Str, '-e',
            'print $*OUT.t ?? "RAKUISH-PTY-OK" !! "RAKUISH-PTY-NO"',
            :pty(:cols(80), :rows(24)),
        );
        my Str $probe-out = '';
        my $probe-done = Promise.new;
        $probe-tap = $probe.stdout.tap(
            -> $c { $probe-out ~= $c.Str },
            done => { try { $probe-done.keep(True) } },
            quit => -> $ex { try { $probe-done.keep(True) } },
        );
        my $started = $probe.start;
        await Promise.anyof($started, Promise.in(3));
        if $started.status ~~ Planned {
            try { $probe.kill('SIGKILL') };
            try { await $started };
        }
        await Promise.anyof($probe-done, Promise.in(0.5));
        $probe-ok = $probe-out.contains('RAKUISH-PTY-OK')
                    && !$probe-out.contains('RAKUISH-PTY-NO');
        $probe-reason = ':pty 未生效，子进程没有看到 TTY' unless $probe-ok;
    }
    try { $probe-tap.close } if $probe-tap.defined;

    %(
        capable => $probe-ok,
        version => ~$ver,
        reason  => ($probe-ok ?? '' !! $probe-reason),
    )
}

# PTY 捕获：子进程看到一个真正的终端，但 stdout 由父进程捕获。
# 适用于 Agent 的“跑一个交互式程序并拿回输出”，不提供实时 stdin。
method pty-exec(Str $exe, *@args,
                IO::Path :$cwd,
                :%env,
                Int :$timeout-ms = 30_000,
                Int :$max-bytes = 1024 * 1024,
                Int :$cols = 80,
                Int :$rows = 24,
                Bool :$strip-ansi = True,
                Str :$op = 'pty-exec' --> Result) {

    X::Rakuish::Path.new(:detail('pty-exec: 可执行文件不能为空')).throw
        unless $exe.chars;

    # 0.72.2 / R-1：绝不把「可能是 PTY」写成「一定是 PTY」。
    my %cap = self.pty-capability();
    unless %cap<capable> {
        return Result.new(:!ok, :code(127), :op($op),
            :err("PTY 不可用: {%cap<reason>}；需要 Rakudo ≥ 2025.12 且 :pty 生效"),
            :value({
                exe => $exe, argv => @args.List,
                pty => False, tty => False,
                pty-capable => False, reason => %cap<reason>,
            }));
    }

    my Str $child-cwd = $cwd.defined ?? $cwd.Str !! $*CWD.Str;
    my %child-env = %env.elems ?? %env.Hash !! %*ENV.Hash;

    my $p = Proc::Async.new(
        $exe, |@args,
        :pty(:cols($cols), :rows($rows)),
    );

    # 0.72.2 / R-3：tap 内只做 O(chunk) 的追加与计数，不再反复拼接全量
    # 字符串；超过硬上限后停止累积但继续消费，内存有界。
    my @chunks;
    my Int  $raw-bytes = 0;
    my Bool $overflow = False;
    my Int  $hard-cap = $max-bytes > 0 ?? ($max-bytes * 4) !! (4 * 1024 * 1024);
    my $stdout-done = Promise.new;
    my $tap = $p.stdout.tap(
        -> $chunk {
            my Str $piece = $chunk.Str;
            $raw-bytes += $piece.encode('utf-8').elems;
            if $max-bytes > 0 && $raw-bytes > $hard-cap {
                $overflow = True;
            }
            else {
                @chunks.push($piece);
            }
        },
        done => { try { $stdout-done.keep(True) } },
        quit => -> $ex { try { $stdout-done.keep(True) } },
    );

    my $started;
    my Str $start-err = '';
    {
        CATCH { default { $start-err = .message } }
        $started = $p.start(:cwd($child-cwd), :ENV(%child-env));
    }
    unless $started.defined {
        try { $tap.close };
        return Result.new(:!ok, :code(127), :op($op),
                          :err("PTY 启动失败: {$start-err}"));
    }

    my Bool $timed-out = False;
    if $timeout-ms > 0 {
        await Promise.anyof($started, Promise.in($timeout-ms / 1000));
        if $started.status ~~ Planned {
            $timed-out = True;
            try { $p.kill('SIGKILL') };
            my $settled = try { await $started; True };
        }
    }
    else {
        my $settled = try { await $started; True };
    }

    # 0.72.2：等 stdout Supply 真正 done/quit（所有 chunk 已交付），
    # 0.5s 只是异常兜底；不再靠固定 sleep 赌最后一块。全量回归下
    # 400KB 输出曾因时间窗不足而少收，这里从机制上消除竞态。
    await Promise.anyof($stdout-done, Promise.in(0.5));
    $overflow = True unless $stdout-done.status ~~ Kept;

    my $proc = Nil;
    $proc = try { $started.result } if $started.status ~~ Kept;
    my Int $code = $timed-out ?? 124
        !! ($proc.defined ?? ($proc.exitcode // 1) !! 127);
    my Bool $ok = !$timed-out && $code == 0;

    # 先对完整输出剥离控制序列，再按 UTF-8 安全截断：控制序列既不占
    # max-bytes 配额，也不会被截成半截残留（Linux 实测 0.72.1 会留 `[31`）。
    my Str $raw   = @chunks.join;
    my Str $clean = $strip-ansi ?? strip-terminal-controls($raw) !! $raw;
    my Bool $truncated = $overflow;
    my Str $out = $max-bytes > 0
        ?? clip-bytes($clean, $max-bytes, $truncated)
        !! $clean;
    my Str $err = $timed-out ?? 'PTY 请求超时' !! '';
    try { $tap.close };

    Result.new(:$ok, :$code, :$op, :$out, :$err,
        :value({
            exe => $exe,
            argv => @args.List,
            tty => True,
            pty => True,
            pty-capable => True,
            'stderr-merged' => True,
            'stdin-unavailable' => True,
            'strip-ansi' => $strip-ansi,
            timed-out => $timed-out,
            truncated => $truncated,
            cols => $cols,
            rows => $rows,
        }),
    );
}

method wait(Handle $h --> Result)  { $h.wait }
method cancel(Handle $h --> Bool) { $h.cancel }
