unit module Rakuish::Sys::PosixSpawn;

# Rakuish::Sys::PosixSpawn —— POSIX 进程组交接的 NativeCall 薄封装
# （0.73.0 / ADR-0010 §4）。
#
# 为什么需要它：`Sys::Proc.tty-exec` 原本用 `Proc::Async` 起子进程，父子同组；
# 子进程一句 `kill(0, SIGTERM)` 就能把宿主 REPL 一起打死（ADR-0010 §2.4 实测）。
# 而 POSIX 只允许父进程对**尚未 exec** 的子进程 setpgid，`Proc::Async` 交出 pid
# 时子进程早已 exec，父侧 setpgid 60/60 失败（EACCES）。所以只能在 spawn 时
# 就把进程组定下来 —— `posix_spawnp` + `POSIX_SPAWN_SETPGROUP`。
#
# 三条实测得来的硬约束（写进代码，别再踩一遍）：
#
#   1. 必须用 `posix_spawnp`（带 p），不是 `posix_spawn`：后者不搜索 PATH，
#      `! --tty vim` 这种靠 PATH 的调用会直接 ENOENT。
#   2. 交接后父进程变成**后台进程**，调 `tcsetpgrp` 会吃 SIGTTOU。必须用
#      `signal(2)` 把它设成**真 SIG_IGN**（handler = (void*)1）。用 Raku 的
#      `signal(SIGTTOU).tap`（捕获语义）会让恢复那次 `tcsetpgrp` 返回 -1 /
#      ENOTTY，看着像「控制终端丢了」，换新开的 /dev/tty 也一样失败。
#   3. `posix_spawn` 没有 cwd 参数，只能靠 `posix_spawn_file_actions_addchdir_np`
#      （glibc ≥ 2.29 / macOS 10.15+）。符号缺失时**降级**，绝不改父进程 chdir
#      —— 那是进程级全局状态，会污染整个 REPL（ADR-0007 §2）。
#
# 本模块只在 `tty-exec` 的 POSIX 分支被调用；Windows 上没有调用点。所有
# native 符号都是**调用时**解析，加载模块本身不 dlopen 任何东西。
use NativeCall;

constant POSIX-SPAWN-SETPGROUP = 0x02;
constant SIGTTOU                = 22;
constant EINTR                  = 4;
constant ECHILD                 = 10;

# `posix_spawnattr_t` 在 glibc 是 336 字节的 struct，在 macOS 是 `void *`
# （8 字节，内部堆分配）。512 字节缓冲两边都够用：mac 侧函数把指针写进前
# 8 字节，我们只传地址、不解引用。
my constant ATTR-BYTES = 512;
my constant FA-BYTES   = 512;

sub posix_spawnp(Pointer[uint32] $pid, Str $file, Pointer[void] $file-actions,
                 Pointer[void] $attrp, CArray[Str] $argv, CArray[Str] $envp --> int32)
    is native { * }

sub posix_spawn_file_actions_init(Pointer[void] $fa --> int32) is native { * }
sub posix_spawn_file_actions_destroy(Pointer[void] $fa --> int32) is native { * }
sub posix_spawn_file_actions_addchdir_np(Pointer[void] $fa, Str $path --> int32)
    is native { * }

sub posix_spawnattr_init(Pointer[void] $attr --> int32) is native { * }
sub posix_spawnattr_destroy(Pointer[void] $attr --> int32) is native { * }
sub posix_spawnattr_setpgroup(Pointer[void] $attr, int32 $pgroup --> int32) is native { * }
sub posix_spawnattr_setflags(Pointer[void] $attr, int16 $flags --> int32) is native { * }

sub waitpid(int32 $pid, Pointer[int32] $status, int32 $options --> int32) is native { * }
sub tcsetpgrp(int32 $fd, int32 $pgrp --> int32) is native { * }
sub tcgetpgrp(int32 $fd --> int32) is native { * }
sub getpgid(int32 $pid --> int32) is native { * }

# 裸 `is native` + `is symbol<...>` 必须是两个独立 trait：写成
# `is native(:symbol<signal>)` 会把 symbol 当成库名。
sub c-signal(int32 $sig, Pointer[void] $handler --> Pointer[void])
    is native is symbol<signal> { * }

# glibc 用 `__errno_location`，macOS 是 `__error`。拿不到就返回 -1（调用方
# 按「未知错误」处理，最多重试有限次数，绝不无限等待）。
sub c-errno-location(--> Pointer[int32]) is native is symbol<__errno_location> { * }

sub errno(--> Int) {
    (try { c-errno-location().deref }) // -1
}

# ── spawn ────────────────────────────────────────────────────────────

# 起一个**自成进程组**的子进程。返回 Hash：
#   rc     posix_spawnp 的返回码（0 成功；否则是 errno 值，ENOENT=2）
#   pid    子进程 pid（失败时 0）
#   stage  失败发生在哪一步（诊断用）
our sub spawn-in-group(Str $exe, @args, %env, Str $cwd, Bool $need-chdir --> Hash) {

    my $argv = CArray[Str].new;
    $argv[0] = $exe;
    for @args.kv -> $i, $v { $argv[$i + 1] = $v.Str }
    $argv[@args.elems + 1] = Str;                 # NULL 终止

    my @kv = %env.pairs.map({ "{.key}={.value}" });
    my $envp = CArray[Str].new;
    for @kv.kv -> $i, $v { $envp[$i] = $v }
    $envp[@kv.elems] = Str;

    my $fa-buf = buf8.allocate(FA-BYTES);
    my $fa = nativecast(Pointer[void], $fa-buf);
    my Int $rc = posix_spawn_file_actions_init($fa);
    return %( rc => $rc, pid => 0, stage => 'file-actions-init' ) if $rc != 0;

    if $need-chdir {
        $rc = posix_spawn_file_actions_addchdir_np($fa, $cwd);
        if $rc != 0 {
            try { posix_spawn_file_actions_destroy($fa) };
            return %( rc => $rc, pid => 0, stage => 'addchdir' );
        }
    }

    my $attr-buf = buf8.allocate(ATTR-BYTES);
    my $attr = nativecast(Pointer[void], $attr-buf);
    $rc = posix_spawnattr_init($attr);
    if $rc != 0 {
        try { posix_spawn_file_actions_destroy($fa) };
        return %( rc => $rc, pid => 0, stage => 'attr-init' );
    }
    # pgroup = 0 ⇒ 子进程自成一组、组号就是它自己的 pid。
    posix_spawnattr_setpgroup($attr, 0);
    posix_spawnattr_setflags($attr, POSIX-SPAWN-SETPGROUP);

    my $pid-buf = buf8.allocate(4);
    my $pidp = nativecast(Pointer[uint32], $pid-buf);
    $rc = posix_spawnp($pidp, $exe, $fa, $attr, $argv, $envp);
    my Int $pid = $pidp.deref;

    try { posix_spawnattr_destroy($attr) };
    try { posix_spawn_file_actions_destroy($fa) };

    %( rc => $rc, pid => ($rc == 0 ?? $pid !! 0),
       stage => ($rc == 0 ?? 'ok' !! 'spawn') )
}

# `posix_spawn_file_actions_addchdir_np` 是否可用（glibc 2.29+ / macOS 10.15+）。
# 探测一次并缓存：不能靠「调用失败再降级」，因为那时子进程还没起，但
# 失败路径与「路径不存在」的 ENOENT 混在一起，分不清是能力缺失还是用户写错。
our sub addchdir-available(--> Bool) {
    state Bool $ok = do {
        my $buf = buf8.allocate(FA-BYTES);
        my $fa = nativecast(Pointer[void], $buf);
        my Bool $r = False;
        if (try { posix_spawn_file_actions_init($fa) } // -1) == 0 {
            # 用当前目录做探针：它一定存在，成功即说明符号存在且能工作。
            $r = (try { posix_spawn_file_actions_addchdir_np($fa, $*CWD.Str) } // -1) == 0;
            try { posix_spawn_file_actions_destroy($fa) };
        }
        $r;
    };
    $ok;
}

# ── 等待与状态 ───────────────────────────────────────────────────────

# 回收子进程并解出退出状态。返回 Hash：
#   rc         waitpid 的返回（>=0 成功；-1 表示最终失败）
#   reaped     是否真的回收到了
#   raw        原始 status 字
#   exit       WIFEXITED 时的退出码（否则 -1）
#   sig        WIFSIGNALED 时的信号号（否则 0）
#   signaled   是否被信号终止
#
# 为什么自己 waitpid：posix_spawn 出来的子进程不是 Rakudo 的进程对象，
# `await $promise` 那条路不存在。EINTR 必须重试，但重试有上限 —— 卡死
# 比拿不到退出码更糟。
our sub wait-exit(Int $pid --> Hash) {
    my $status = CArray[int32].new;
    $status[0] = 0;
    my Int $rc = -1;
    my Int $tries = 0;
    loop {
        $rc = waitpid($pid, nativecast(Pointer[int32], $status), 0);
        last if $rc >= 0;
        my Int $e = errno();
        last if $e == ECHILD;          # 已被别人回收，再等也没用
        last if $tries >= 200;         # ≈2s 上限
        $tries++;
        sleep 0.01;
    }
    return %( rc => $rc, reaped => False, raw => 0, exit => -1, sig => 0,
              signaled => False ) if $rc < 0;

    my Int $raw = $status[0];
    my Int $sig = $raw +& 0x7f;
    my Int $exit = $sig == 0 ?? (($raw +> 8) +& 0xff) !! -1;
    %( rc => $rc, reaped => True, raw => $raw, exit => $exit, sig => $sig,
       signaled => so $sig != 0 )
}

# ── 前台进程组 ───────────────────────────────────────────────────────

our sub set-foreground(Int $fd, Int $pgid --> Bool) {
    return False if $fd < 0 || $pgid <= 0;
    (try { tcsetpgrp($fd, $pgid) } // -1) == 0
}

our sub foreground-of(Int $fd --> Int) {
    (try { tcgetpgrp($fd) } // -1)
}

our sub group-of(Int $pid --> Int) {
    (try { getpgid($pid) } // -1)
}

# ── SIGTTOU ─────────────────────────────────────────────────────────

# 把 SIGTTOU 设成 SIG_IGN，返回旧的 handler（供 restore 用）。
# 为什么不 `signal(SIGTTOU).tap`：见本文件头第 2 条。
our sub ignore-sigttou(--> Any) {
    (try { c-signal(SIGTTOU, Pointer[void].new(1)) }) // Nil
}

our sub restore-sigttou($old) {
    return unless $old.defined;
    try { c-signal(SIGTTOU, nativecast(Pointer[void], $old)) };
}
