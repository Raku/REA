unit module Rakuish::Command;

# Rakuish::Command —— 可扩展命令协议（ADR-0001 §2.3 / 设计 §4.4）。
#
# 这是「常用命令」与「Agent 工具面」的单一来源：
#   · 每个命令自带 CommandSpec（参数 schema），Phase 4 可据此生成 JSON Schema；
#   · run() 统一返回 Result，参数结构化，不接自由文本 shell 字符串；
#   · ExternalCommand 只包 argv，BuiltinCommand 只委托 Sys，二者都不解析语法；
#   · 注册表允许用户 / 插件注册新命令，无需改任何 given 分支或 help 表。
#
# 与 %magic 的根本区别：magic 是「文本行 → 独立解析器 → 打印字符串」，
# 这里是「类型化参数 → 同一个 Sys → 可序列化的值」。

use Rakuish::Sys;
use Rakuish::Result;

class ParamSpec is export {
    has Str  $.name is required;
    has Str  $.type = 'string';      # string / int / bool / path / argv / any
    has Bool $.required = False;
    has Any  $.default;

    method to-hash(--> Hash) {
        { name => $!name, type => $!type, required => $!required,
          default => $!default }
    }
}

class CommandSpec is export {
    has Str $.name is required;
    has Str $.summary = '';
    has @.params;                    # ParamSpec
    has Str $.returns = 'Result';

    method to-hash(--> Hash) {
        { name => $!name, summary => $!summary,
          params => @!params.map(*.to-hash).List, returns => $!returns }
    }

    # Phase 4 的 Agent 边界直接消费这个结构；本轮先落好，不做网络层。
    method to-json-schema(--> Hash) {
        my %props;
        my @required;
        for @!params -> ParamSpec $p {
            my %one;
            given $p.type {
                when 'int'    { %one<type> = 'integer' }
                when 'bool'   { %one<type> = 'boolean' }
                when 'argv'   { %one<type> = 'array'; %one<items> = { type => 'string' } }
                when 'any'    { }
                default       { %one<type> = 'string' }   # string / path
            }
            %one<description> = $p.name;
            %one<default> = $p.default if $p.default.defined;
            %props{$p.name} = %one;
            @required.push($p.name) if $p.required;
        }
        { type => 'object', title => $!name, description => $!summary,
          properties => %props, required => @required.List }
    }
}

role Command is export {
    method name(--> Str) { ... }
    method spec(--> CommandSpec) { ... }
    method run(Rakuish::Sys $sys, *@args, *%opts --> Result) { ... }
}

# 外部程序：exe 固定，其余全是 argv / 命名选项，永不经过 shell。
class ExternalCommand does Command is export {
    has Str $.exe is required;
    has Str $.summary = '';
    has @.params;

    method name(--> Str) { $!exe }
    method spec(--> CommandSpec) {
        CommandSpec.new(:name($!exe), :summary($!summary),
                        :params(@!params), :returns<Result>)
    }
    method run(Rakuish::Sys $sys, *@args, *%opts --> Result) {
        $sys.exec($!exe, |@args, |%opts)
    }
}

# 内建命令：handler 只调 Sys，异常由 try-op 收敛成 Result。
class BuiltinCommand does Command is export {
    has Str      $.cmd-name is required;
    has Str      $.summary  = '';
    has @.params;
    has Callable $.handler is required;

    method name(--> Str) { $!cmd-name }
    method spec(--> CommandSpec) {
        CommandSpec.new(:name($!cmd-name), :summary($!summary),
                        :params(@!params), :returns<Result>)
    }
    method run(Rakuish::Sys $sys, *@args, *%opts --> Result) {
        my $r = $sys.try-op($!cmd-name, { $!handler.($sys, |@args, |%opts) });
        # exec / rm / cp 等 Sys 方法本身已返回 Result：直接透传，不能套两层。
        # 否则外层 try-op 会把子进程的 exit code 伪装成 0、把 out/err 吞成空串
        # （实测 `exec` 明明成功却 out=[]），Agent 拿到的审计信息全丢。
        my $res = ($r.ok && $r.value ~~ Result) ?? $r.value !! $r;

        # 内置命令的统一返回口径：结构化字段原样保留（value/out/err/op/...），
        # 另外附带一份 text 渲染（Result.rendered / .text / .gist）。
        # 不把 value 替换成文本 —— DSL 仍要能 .grep/.map/继续组合。
        return Result.new(
            :ok($res.ok), :code($res.code), :value($res.value),
            :out($res.out), :err($res.err), :op($res.op),
            :elapsed($res.elapsed), :rendered($res.render('text')),
        );
    }
}

class CommandRegistry is export {
    has %!commands;

    method register(Command $c --> Command) {
        X::Rakuish::Unsupported.new(
            :detail("命令名不能为空")).throw unless $c.name.chars;
        %!commands{$c.name} = $c;
        $c
    }
    method get(Str $n)            { %!commands{$n} }
    method has(Str $n --> Bool)   { %!commands{$n}:exists }
    method names(--> List)        { %!commands.keys.sort.List }
    method elems(--> Int)         { %!commands.elems }
    method specs(--> List)        { self.names.map({ %!commands{$_}.spec }).List }
    method remove(Str $n --> Bool) {
        return False unless %!commands{$n}:exists;
        %!commands{$n}:delete;
        True
    }

    # 注册表级别也给一份 schema 列表，给 Phase 4 的 tools 数组用。
    method to-json-schema(--> List) {
        self.names.map({ %!commands{$_}.spec.to-json-schema }).List
    }

    method run(Str $n, Rakuish::Sys $sys, *@args, *%opts --> Result) {
        my $c = %!commands{$n};
        return Result.new(:!ok, :code(127), :op($n),
                          :err("未知命令: $n（可用: {self.names.join(', ')}）"))
            unless $c.defined;
        $c.run($sys, |@args, |%opts)
    }
}

# 默认注册表：把 Sys 的能力全部登记为结构化命令。
# 用户可用 $reg.register(...) 叠加自己的命令；DSL 短 sub 与本表共享同一个 Sys，
# 不存在两套语义实现。
sub default-registry(--> CommandRegistry) is export {
    my $r = CommandRegistry.new;

    # ⚠ 不要写「元数据 Hash + my ($summary, @params) = %meta{$op}」：
    #   List 赋给数组变量在本项目两个后端上都不摊平，整个 List 会变成
    #   @params 的单个元素（实测 spec.to-hash 会对 List 调 to-hash 报错）。
    #   改用 slurpy *@params 收集，交给 has @.params 属性（属性接收会摊平）。
    sub reg-builtin(Str $op, Str $summary, *@params --> Nil) {
        $r.register(BuiltinCommand.new(
            :cmd-name($op), :summary($summary), :params(@params.List),
            :handler(-> $s, |c { $s."$op"(|c) })
        ));
        Nil
    }

    reg-builtin('read',   '读取文件',
        ParamSpec.new(:name<path>, :type<path>, :required));
    reg-builtin('write',  '写入文件',
        ParamSpec.new(:name<path>, :type<path>, :required),
        ParamSpec.new(:name<data>, :type<any>,  :required));
    reg-builtin('append', '追加写入',
        ParamSpec.new(:name<path>, :type<path>, :required),
        ParamSpec.new(:name<data>, :type<any>,  :required));
    reg-builtin('ls',     '列出目录',
        ParamSpec.new(:name<path>, :type<path>));
    reg-builtin('stat',   '文件信息',
        ParamSpec.new(:name<path>, :type<path>, :required));
    reg-builtin('rm',     '删除',
        ParamSpec.new(:name<path>, :type<path>, :required));
    reg-builtin('cp',     '复制',
        ParamSpec.new(:name<from>, :type<path>, :required),
        ParamSpec.new(:name<to>,   :type<path>, :required));
    reg-builtin('mv',     '移动',
        ParamSpec.new(:name<from>, :type<path>, :required),
        ParamSpec.new(:name<to>,   :type<path>, :required));
    reg-builtin('mkdir',  '创建目录',
        ParamSpec.new(:name<path>, :type<path>, :required));
    reg-builtin('glob',   '通配查找',
        ParamSpec.new(:name<pattern>, :type<string>, :required));
    reg-builtin('cd',     '切换会话目录',
        ParamSpec.new(:name<path>, :type<path>, :required));
    reg-builtin('env',    '会话环境');

    # exec 单独注册：第一个参数是 exe，其余是 argv。
    $r.register(BuiltinCommand.new(
        :cmd-name<exec>, :summary('执行外部命令（argv，无 shell）'),
        :params(ParamSpec.new(:name<exe>, :type<string>, :required),
                ParamSpec.new(:name<args>, :type<argv>)),
        :handler(-> $s, $exe, *@args, *%opts { $s.exec($exe, |@args, |%opts) })
    ));
    $r
}
