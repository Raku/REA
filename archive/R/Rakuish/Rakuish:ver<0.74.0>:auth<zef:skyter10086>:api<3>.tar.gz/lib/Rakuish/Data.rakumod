unit module Rakuish::Data;

# Rakuish::Data —— 结构化数据读写（JSON / CSV / Table）的最小公共层。
#
# 命令层（REPL / DSL）会把这里的能力暴露成 open/save；底层仍然只经 Sys
# 读写文件，不绕过 Sandbox。

use JSON::Fast;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Data::Table;
need Rakuish::Data::Engine::DuckDB;   # 只加载适配器；DB::DuckDB 仍由 TWEAK 运行时 require

# ── Parquet 支撑（0.64）─────────────────────────────────────────────
# DuckDB 的 read_parquet / COPY 属于「外部文件访问」：默认 :safe 引擎是关掉的。
# 这里只在调用方显式 :allow-external 时开启，且路径一律先经 Sys.resolve 做
# root 校验；Agent 的 op 白名单不暴露这个开关（V-130 / V-152）。
sub with-duckdb(&body) {
    my $db = try {
        Rakuish::Data::Engine::DuckDB.new(:safe(False), :!read-only)
    };
    X::Rakuish::Unsupported.new(
        :detail('受控外部数据读写需要 DuckDB 引擎；请先 zef install DB::DuckDB（依赖 Alien::Libduckdb）')
    ).throw unless $db.defined;
    LEAVE { try { $db.close } }
    body($db)
}

sub sql-type(Str $t --> Str) {
    given $t {
        when 'int'  { 'BIGINT'  }
        when 'num'  { 'DOUBLE'  }
        when 'bool' { 'BOOLEAN' }
        default     { 'VARCHAR' }   # str / datetime / list / map / any 都转字符串
    }
}

sub parquet-value($v, Str $type) {
    unless $v.defined {
        return $type eq 'int'  ?? 0
            !! $type eq 'num'  ?? 0e0
            !! $type eq 'bool' ?? False
            !! '';
    }
    return $v if $v ~~ Int | Num | Rat | Bool;
    return $v.Str if $v ~~ Str | DateTime | Instant | IO::Path;
    to-json($v, :!pretty);
}

# Parquet / CSV 共用的导出流程（0.68）：建临时表 → 参数化 insert → COPY。
# 只有显式 :allow-external 才会调到这里；$abs 已由调用方经 Sys.resolve 校验。
sub export-table($db, Rakuish::Data::Table $table, Str $abs, Str $format,
                 :%csv-options = {} --> Nil) {
    my @cols = $table.columns.map(*.Str);
    X::Rakuish::Data.new(
        :detail('外部格式导出需要至少一列')
    ).throw unless @cols.elems;
    my Str $ddl = 'create table __rakuish_export ('
        ~ @cols.map({
            '"' ~ .subst('"', '""', :g) ~ '" '
                ~ sql-type($table.column-type($_))
          }).join(', ')
        ~ ')';
    $db.execute($ddl);
    my Str $ins = 'insert into __rakuish_export values ('
        ~ @cols.map({ '?' }).join(', ') ~ ')';
    for $table.rows -> $r {
        my @vals = @cols.map({
            parquet-value($r{$_}, $table.column-type($_))
        });
        $db.execute($ins, |@vals);
    }
    my Str $sql = 'select * from __rakuish_export';
    $format eq 'csv'
        ?? $db.write-csv($abs, $sql, :%csv-options)
        !! $db.write-parquet($abs, $sql);
    Nil
}

our sub from-json-data(Str $text) is export {
    from-json($text);
}

our sub to-json-data($value, Bool :$pretty = False --> Str) is export {
    given $value {
        when Rakuish::Data::Table { $value.to-json(:$pretty) }
        default { to-json($value, :$pretty) }
    }
}

# 行数组 → Table；非“对象数组”原样返回。
our sub tableify($value) {
    if $value ~~ Positional && $value.elems
       && $value.all ~~ Associative {
        return Rakuish::Data::Table.from-rows($value);
    }
    $value;
}

our sub from-csv-data(Str $text --> Rakuish::Data::Table) is export {
    my @ch = $text.subst(/^ "\x[FEFF]"/, '').comb;
    my Int $n = @ch.elems;
    my Int $i = 0;
    my @records;
    my @row;
    my Str $cur = '';
    my Bool $quoted = False;

    while $i < $n {
        my Str $c = @ch[$i];
        if $quoted {
            if $c eq '"' {
                if $i + 1 < $n && @ch[$i + 1] eq '"' {
                    $cur ~= '"';
                    $i += 2;
                    next;
                }
                $quoted = False;
                $i++;
                next;
            }
            $cur ~= $c;
            $i++;
            next;
        }
        if $c eq '"' {
            $quoted = True;
            $i++;
            next;
        }
        if $c eq ',' {
            @row.push($cur);
            $cur = '';
            $i++;
            next;
        }
        if $c eq "\r" {
            $i++;
            next;
        }
        if $c eq "\n" {
            @row.push($cur);
            @records.push(@row.List);
            @row = ();
            $cur = '';
            $i++;
            next;
        }
        $cur ~= $c;
        $i++;
    }
    @row.push($cur) if $cur.chars || @row.elems;
    @records.push(@row.List) if @row.elems;

    return Rakuish::Data::Table.new(:columns(), :rows()) unless @records.elems;
    my @headers = @records.shift.map(*.Str);
    my @rows;
    for @records -> $rec {
        my %r;
        for @headers.kv -> $idx, $h {
            %r{$h} = $rec[$idx] // '';
        }
        @rows.push(%r);
    }
    Rakuish::Data::Table.new(:columns(@headers), :rows(@rows));
}

our sub to-csv-data(Rakuish::Data::Table $table --> Str) is export {
    my sub cell($v --> Str) {
        my Str $s = $v.defined ?? $v.Str !! '';
        my Bool $need-quote = $s.contains(',') || $s.contains('"')
            || $s.contains("\n") || $s.contains("\r");
        $need-quote ?? '"' ~ $s.subst('"', '""', :g) ~ '"' !! $s;
    }
    my @headers = $table.columns.map(*.Str);
    return '' unless @headers.elems;
    my @lines;
    @lines.push(@headers.map({ cell($_) }).join(','));
    for $table.rows -> $row {
        @lines.push(@headers.map({ cell($row{$_}) }).join(','));
    }
    @lines.join("\n") ~ "\n";
}

our sub open-data(Rakuish::Sys $sys, Str $path, Bool :$raw = False,
                  Bool :$allow-external = False,
                  :%csv-options = {}) is export {
    my Str $ext = $path.IO.extension.lc;
    # 0.69 方言选项只在「.csv + 显式授权」时有意义；其余组合明确拒绝，
    # 不静默忽略（否则拼错开关会以为生效了）。
    X::Rakuish::Unsupported.new(
        :detail('CSV 方言选项只在 .csv 且显式 :allow-external 时可用（默认路径仍由 Raku 解析器读取）')
    ).throw if %csv-options.elems
              && !($allow-external && $ext eq 'csv');
    # 显式授权时 Parquet / CSV 走受控 DuckDB 外部访问（V-152 / V-160）。
    # 路径一律先经 Sys.resolve；Agent 的 op 白名单不暴露这个开关。
    if $allow-external && ($ext eq 'parquet' || $ext eq 'pq' || $ext eq 'csv') {
        my Str $abs = $sys.resolve($path).Str;
        return with-duckdb(-> $db {
            $ext eq 'csv'
                ?? $db.read-csv($abs, :%csv-options)
                !! $db.read-parquet($abs)
        });
    }
    # 二进制 Parquet 没有「按文本读取」的退路，必须显式开启。
    if $ext eq 'parquet' || $ext eq 'pq' {
        X::Rakuish::Unsupported.new(
            :detail('读取 .parquet 需要显式 :allow-external（路径仍经 Sys root 校验；Agent 不开放）')
        ).throw;
    }
    my Str $text = $sys.read($path);
    return $text if $raw;
    return $text unless $ext.chars;
    given $ext {
        when 'json' { tableify(from-json($text)) }
        when 'csv'  { from-csv-data($text) }
        default     { $text }
    }
}

our sub save-data(Rakuish::Sys $sys, Str $path, $value,
                  Bool :$pretty = True,
                  Bool :$allow-external = False,
                  :%csv-options = {}) is export {
    my Str $ext = $path.IO.extension.lc;
    X::Rakuish::Unsupported.new(
        :detail('CSV 方言选项只在 .csv 且显式 :allow-external 时可用')
    ).throw if %csv-options.elems
              && !($allow-external && $ext eq 'csv');
    my Bool $external-format = $ext eq 'parquet' || $ext eq 'pq' || $ext eq 'csv';
    if $external-format && $allow-external {
        my $table = $value ~~ Rakuish::Data::Table
            ?? $value
            !! Rakuish::Data::Table.from-rows($value);
        my Str $abs = $sys.resolve($path).Str;
        with-duckdb(-> $db {
            export-table($db, $table, $abs,
                         $ext eq 'csv' ?? 'csv' !! 'parquet',
                         :%csv-options)
        });
        return True;
    }
    if $ext eq 'parquet' || $ext eq 'pq' {
        X::Rakuish::Unsupported.new(
            :detail('写入 .parquet 需要显式 :allow-external（路径仍经 Sys root 校验；Agent 不开放）')
        ).throw;
    }
    # 不带开关的 .csv 仍走 Sys.write（V-129 默认路径），行为与 0.64 一致。
    my Str $text;
    given $ext {
        when 'json' { $text = to-json-data($value, :$pretty) }
        when 'csv'  {
            my $table = $value ~~ Rakuish::Data::Table
                ?? $value
                !! Rakuish::Data::Table.from-rows($value);
            $text = to-csv-data($table);
        }
        default { $text = $value.Str }
    }
    $sys.write($path, $text);
}
