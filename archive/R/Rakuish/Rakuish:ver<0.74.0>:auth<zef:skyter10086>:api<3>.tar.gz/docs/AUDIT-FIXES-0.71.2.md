# 0.71.2 审计修复记录

- **日期**：2026-11-12
- **对象**：`main` @ 0.71.2（基于 0.71.1）
- **范围**：审计 M-1 / M-2 / M-3

## M-1 · 请求级 env 双实现

- 删除 `Agent!run-op` 只挡 `PATH` 的旧逻辑。
- exec 请求 env 现在统一复用 `Sandbox.env-allowed` 白名单：
  `LANG` / `LANGUAGE` / `TZ` / `LC_*`，其余 403。
- 已有 `t/06` 的 `LD_PRELOAD` / `PATH` 403 回归继续覆盖。

## M-2 · 并发审计

- `Sandbox.audit` 的 `@!entries` 更新与 JSONL append 放进模块级 `Lock`。
- 多客户端共享 Sandbox 时不会并发写坏 entries / JSONL。
- `t/06` 新增 50 个并发 audit 条目计数断言。

## M-3 · worker 连接计数

- worker 分支用 `LEAVE` 归还 `$active--`。
- `serve-connection` 抛异常时不会泄漏连接计数。
- 正常路径不再重复 `$active--`。

## 验证

```bash
prove6 -Ilib t
bash tools/run-all.sh
zef install . --force-install
```
