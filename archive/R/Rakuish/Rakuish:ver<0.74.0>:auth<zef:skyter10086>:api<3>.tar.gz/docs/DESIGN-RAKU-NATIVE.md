# 方向调整建议：Raku 原生命令 / 脚本引擎

- **日期**：2026-11-09
- **背景**：目标不是兼容 bash / POSIX，而是**从 Raku 语法出发**，做一套更适合 shell、脚本和 Agent 系统操作的命令引擎。
- **结论**：当前仓库的 `SPEC.md` / `Parser` / `Engine::Pipeline` 仍然是“bash 子集”的设计，和新目标方向相反。**不建议继续在现有 shell 语法上打补丁，应该把“命令语言”的底座换成 Raku 本身。**

---

## 1. 一句话判断

**当前项目是“用 Raku 实现了一个 bash 子集”，目标应该是“用 Raku 做命令与系统操作，不需要 bash 子集”。**

这不是“再修几个 bug”的差异，而是产品定位的差异：

| 维度 | 当前 v2 | 目标 |
|---|---|---|
| 命令语法 | `!` 后的 bash 子集 | Raku 函数调用 / 方法调用 |
| 管道 | `\|` + 自建 `Pipeline` | Raku 惰性列表 / 方法链 / `Supply` |
| 重定向 | `>` `>>` `2>` `&>` | `write` / `append` / `exec :out` |
| 变量 | `$VAR` shell 变量 | Raku `$var` |
| 控制流 | `&&` `\|\|` `;` | Raku `&&` `\|\|` + `Result.Bool` |
| 引号 / glob | 自建 Lexer / Expand | Raku 字符串 / `dir` / `glob` |
| 内建命令 | 模拟 bash（`cd` `test` `echo`…） | 类型化的 `Sys` API |
| 脚本 | `.rakuish` 命令格 | 普通 Raku 脚本 + DSL |
| Agent 接口 | shell 字符串 | 类型化 JSON RPC |
| 引擎进程 | 独立 shell 引擎 + daemon | 可选 sandbox worker，不再有 shell parser |

现在这套设计里，**Parser、Lexer、AST、Pipeline、Redirect、Shell::Exec、daemon、`rakuish-sh` 都是在为“bash 子集”服务**。如果目标变了，这些模块不是“需要优化”，而是“需要退出主路径”。

---

## 2. 当前设计与目标的具体冲突

### 2.1 `SPEC.md` 本身就是 bash 子集规范

`SPEC.md` 开头写的是：

> 适用范围：`!` 前缀之后的内容（命令模式）与 `.rakush` 脚本里的命令格。

它定义的是：

- `&&` / `||` / `;`
- `|` 管道
- `>` / `>>` / `2>` / `&>` 重定向
- `$name` / `$ENV{KEY}` / `$?` / `$$` / `$0`
- `test` / `[` / `echo` / `cd` / `export`
- `$(( ))` / `${}` / heredoc 等“不支持但要报错”的 bash 构造

这整套东西都是在**模拟另一个语言**。  
而 Raku 已经有：

- `&&` / `||`
- 方法链 / 惰性列表 / `Supply`
- `IO::Path` 的文件操作
- `try` / `CATCH`
- 正则 / 语法
- 类型系统
- `Proc` / `Proc::Async`

继续维护一套 shell 语法，只会持续产生“shell 语义 vs Raku 语义”的双栈问题（当前仓库已经很明显：`dispatch-kind` 没被调用、`Printer` 没被使用、`run`/反引号仍走 legacy）。

### 2.2 内建命令在重复 Raku 已有能力

| 当前内建 | Raku 原生替代 |
|---|---|
| `cd` / `pwd` | `IO::Path` / `chdir` / `$*CWD` |
| `export` / `unset` | `%*ENV` / `Env` API |
| `ls` | `dir` / `IO::Path.dir` |
| `test -f/-d/-e` | `.f` / `.d` / `.e` |
| `test -r/-w/-x` | `.r` / `.w` / `.x` |
| `test -L` | `.l` |
| `read` | `.slurp` / `read` |
| `echo` | `say` / `print` / `write` |
| `grep` / `sort` / `where` | `.grep` / `.sort` / `.grep` |
| `which` | `Platform.lookup-executable` |
| `rm` / `mv` / `cp` | `IO::Path` / 类型化 `Sys` |

这些“命令”如果继续按 bash 语义实现，就会不断出现当前这种 bug：`test -L` 永远 False、`rm -r` 对非空目录失败、`ls -la` 被当成路径。  
**正确做法不是修 bash 语义，而是不要造这套 bash 语义。**

### 2.3 引擎进程是在为错误的问题做隔离

当前 `bin/rakuish-sh` + `Engine::Pipeline` + daemon 的设计目标是：

- 隔离 `Shell::Exec` 的裸 libc 调用；
- 让 bash 语法和 Raku 语法分居两个进程；
- 通过临时文件传命令、环境、heredoc。

如果命令语言改成 Raku 函数调用：

- 没有自建 shell parser；
- 没有 `posix_spawn` / `pipe` / `dup2` 的裸 libc 执行层；
- 外部命令本来就天然是独立 OS 进程；
- 不需要“每条命令起一个 Raku 引擎进程”；
- 不需要 daemon、PID 文件、`env -0`、协议临时文件。

**两个进程的复杂度可以整体删掉。**  
如果 Agent 需要沙箱/超时，可以保留一个 **sandbox worker**，但它执行的是类型化 API，不是 shell 文本。

### 2.4 `run` / 反引号 / `%shell` 的双栈已经证明不可持续

当前：

- `!` 走 `Shell::NewStack`；
- `run()` 和反引号仍走 legacy `Shell::Engine`；
- `%shell` 只改 legacy `$SHELL-BACKEND`，对 new stack 无效；
- Windows 上 `run` / 反引号测试整文件跳过。

这不是“实现细节”，是**两个产品共存在一个仓库**。  
新方向下应该只有一个执行模型：**Raku 函数/命令对象**。

---

## 3. 设计原则

### 3.1 Raku 是唯一的命令语言

- 脚本就是 Raku 脚本；
- REPL 输入就是 Raku 表达式/语句；
- 命令是 Raku sub / method / object，不是字符串；
- 不引入第二套引号、变量、glob、管道语法。

### 3.2 命令 = 类型化函数，不是“文本行”

```raku
my @md = sys.ls('docs', :recursive)
            .grep(*.extension eq 'md')
            .sort(*.modified);

my $text = sys.read('README.md');
sys.write('README.md', $text.subst(/TODO/, 'DONE'), :atomic);

my $r = sys.exec('git', 'status', '--short');
```

参数是 Raku 值：

- 路径是 `IO::Path`；
- 内容是 `Str` / `Blob`；
- 选项是 Raku 命名参数；
- 结果是类型化对象；
- 没有“空格分隔”“引号转义”“变量展开”的问题。

### 3.3 管道 = Raku 链，不是进程语法

```raku
sys.exec('git', 'log', '--oneline')
   .lines
   .grep(/fix/)
   .head(5)
   .join("\n")
   .say;
```

- 对象管道：Raku `List` / `Seq` 的 `.grep` / `.map` / `.sort` / `.head`；
- 字节管道：`Proc::Async` / `Supply` / `Channel`；
- 需要真进程管道时，由 `exec` 的 `:pipe-to` / `:stdin` 选项处理，而不是自建 `Pipeline` 语法。

### 3.4 控制流 = Raku 控制流

```raku
my $r = sys.exec('git', 'status');
if $r.ok { say $r.out } else { note $r.err }

# Result.Bool 返回 .ok，所以 Raku 的 && / || 直接可用
sys.exec('test', '-f', 'x') && sys.exec('echo', 'ok');
```

不需要 `&&` / `||` 的 shell 解析器；Raku 已经会短路。

### 3.5 重定向 = 显式参数，不是语法

```raku
sys.exec('git', 'status', :out('status.txt'));
sys.exec('git', 'status', :err('status.err'), :append);
sys.write('out.txt', $text, :append);
```

### 3.6 文件操作 = 类型化 API，不是命令

```raku
sys.read('a.txt')                 # Str
sys.read('a.bin', :bin)           # Blob
sys.read('a.txt', :max-bytes(1MB))
sys.write('a.txt', 'hello', :atomic)
sys.append('a.txt', "more\n")
sys.ls('src', :recursive, :hidden)
sys.stat('a.txt')                 # Stat
sys.rm('tmp', :recursive, :force)
sys.cp('a', 'b', :recursive, :overwrite)
sys.mv('a', 'b')
sys.mkdir('x/y', :parents)
```

### 3.7 会话状态属于 `Sys` 对象，不属于进程

这是从 Agent 场景出发最重要的一条：

```raku
my $sys = Rakuish::Sys.new(
    cwd     => '/work',
    env     => %(PATH => ...),
    sandbox => Rakuish::Sandbox.new(...),
);
```

- `cwd` 是**会话值**，不调用全局 `chdir`；
- `env` 是**会话值**，不直接改 `%*ENV`；
- `exec` 时把 `cwd` / `env` 传给子进程；
- 多 client / 多 Agent 会话互不污染；
- 不再需要“进程级 cd/export 全局状态”。

当前 `JSONServer` 的多 client 共享进程 cwd / `%*ENV` / 单例 `Executor`，正是这个问题。

---

## 4. 目标架构

```
Rakuish::Sys                 会话上下文：cwd / env / sandbox / limits
  ├─ Sys::FS                 read / write / ls / stat / rm / cp / mv ...
  ├─ Sys::Proc               exec / spawn / stream / timeout / cancel
  ├─ Sys::Env                env / get / set / unset / path
  └─ Sys::Sandbox            roots / allowlist / max-bytes / audit

Rakuish::Command             命令协议（给外部命令/插件/Agent 工具）
  ├─ External                argv，无 shell
  └─ Builtin                 Raku 内建命令（可选）
Rakuish::Result               ok / code / value / out / err / elapsed

Rakuish::DSL                  导出给 REPL/脚本的 Raku 函数
Rakuish::REPL                 Raku 输入 / 补全 / 打印 / 历史
Rakuish::Agent                JSON-RPC：read_file / write_file / exec / eval
```

### 4.1 `Sys` 是唯一系统出口

`Sys` 取代当前的 `Platform` + `Engine` + `Shell::*`：

- 文件：`read/write/append/ls/stat/rm/cp/mv/mkdir/glob`
- 进程：`exec/spawn/stream/wait/cancel`
- 环境：`env/get/set/unset/path`
- 路径：`resolve/absolute/relative`
- 限制：`max-bytes/max-time/max-processes`

`Platform` 可以作为 `Sys` 的内部后端保留（POSIX/Win32 差异），但**不再暴露 bash 语义**。

### 4.2 使用 `IO::Path`，不要自建 `Path`

当前 `Rakuish::Platform::Path` 是重复发明：

- `child` 硬编码 `/`；
- 没有 UNC 语义；
- `rm -r` 因为它没有 `.d` 而直接失败；
- `is-symlink` 永远 False。

Raku 自带 `IO::Path` 已经有 `.e/.f/.d/.l/.r/.w/.x/.s/.modified/.dir/.slurp/.spurt`。  
**直接使用 `IO::Path`，只在外层加 `Sys` 的沙箱/限制/原子写。**

### 4.3 `Result` 统一外部命令结果

```raku
class Result {
    has Bool $.ok;
    has Int  $.code;
    has Any  $.value;
    has Str  $.out;
    has Str  $.err;
    has Duration $.elapsed;

    method Bool(--> Bool) { $!ok }
    method lines(--> List) { $!out.lines.List }
    method json(--> Any) { ... }
}
```

- `exec` / 外部命令返回 `Result`；
- 文件 API 可以直接返回值/抛异常；在 Agent 边界再包成 `Result`；
- 不再有 `$?` / `$$` / `$0`；
- 退出码只作为 `Result.code`，不进入 Raku 变量命名空间。

### 4.4 `Command` 只给外部命令/插件用

```raku
role Command {
    method name(--> Str) { ... }
    method spec(--> CommandSpec) { ... }   # 参数 schema，给 Agent/补全用
    method run(Sys $sys, @args --> Result) { ... }
}
```

- `ExternalCommand`：`argv`，不含 shell；
- `BuiltinCommand`：可选，用于 `ls` / `read` 等；
- Agent 可以从 `spec` 生成工具定义（JSON Schema）。

### 4.5 核心 API 一览（建议签名）

```raku
# 文件
sys.read(IO::Path $p, :$enc = 'utf-8', Bool :$bin = False,
         Int :$max-bytes, Int :$offset, Int :$limit --> Str|Blob)
sys.write(IO::Path $p, Str|Blob $data, Bool :$append = False,
          Bool :$atomic = True, Bool :$mkdir = False,
          Bool :$backup = False, :$enc = 'utf-8' --> WriteResult)
sys.ls(IO::Path $p = '.', Bool :$all = False, Bool :$recursive = False,
       Int :$max-depth, Bool :$follow-symlinks = False --> List[IO::Path])
sys.stat(IO::Path $p --> Stat)
sys.rm(IO::Path $p, Bool :$recursive = False, Bool :$force = False,
       Bool :$dry-run = False --> Result)
sys.cp(IO::Path $from, IO::Path $to, Bool :$recursive = False,
       Bool :$overwrite = False --> Result)
sys.mv(IO::Path $from, IO::Path $to, Bool :$overwrite = False --> Result)
sys.mkdir(IO::Path $p, Bool :$parents = True --> Result)

# 进程（argv，永远不过 shell）
sys.exec(Str $exe, *@args, IO::Path :$cwd, :%env,
         :$in, :$out, :$err, Int :$timeout-ms,
         Bool :$capture = True --> Result)

# 环境 / 路径（会话级）
sys.cwd(--> IO::Path)
sys.cd(IO::Path $p --> IO::Path)
sys.env(--> Hash)
sys.get-env(Str $key --> Str)
sys.set-env(Str $key, Str $value)
sys.unset-env(Str $key)
sys.resolve(Str $path --> IO::Path)      # 沙箱内规范化/校验
```

这些方法就是 Agent 的工具面：每个参数都能映射到 JSON Schema，每个返回值都能序列化。

---

## 5. REPL / 脚本入口

### 5.1 REPL 就是 Raku REPL

```text
> ls 'src'
> read 'README.md' |> .lines.head(3)
> sys.exec 'git', 'status'
> $r = sys.exec 'git', 'diff'
> $r.ok ?? say($r.out) !! note($r.err)
```

- 输入是 Raku；
- `ls` / `read` / `write` / `exec` 是 `Rakuish::DSL` 导出的普通 sub；
- 不再需要 `kind-of` / `auto-shell` / `%magic` 三套分流；
- 多行输入继续用 `Incomplete`（这是纯 Raku 逻辑，可以保留）。

### 5.2 `!` 是否保留：建议保留为“argv 转义”，不保留 shell 语义

如果完全去掉 `!`，用户从 shell 过来会不适应。建议：

```text
! git status
! rg TODO src
```

规则：

- 只做 **argv 分词**（空格 + 引号），不做：
  - `$VAR` 展开
  - `*` / `?` glob
  - `|` 管道
  - `>` / `>>` / `2>` 重定向
  - `&&` / `||` / `;`
  - heredoc
- 元字符原样作为参数传给程序；
- 需要管道/重定向/变量时，写 Raku：

```raku
sys.exec('git', 'log')
   .lines
   .grep(/fix/)
   .head(5)
   .say;
```

这样 `!` 只是一个“人类便利入口”，不是第二套语言。

### 5.3 脚本就是 Raku 脚本

`foo.rakuish`：

```raku
#!/usr/bin/env rakuish
use Rakuish::DSL;

my @files = sys.ls('src', :recursive)
                .grep(*.extension eq 'rakumod');

for @files -> $f {
    my $text = sys.read($f);
    sys.write($f, $text.subst(/TODO/, 'DONE'), :atomic);
}
```

`rakuish run foo.rakuish` 等价于：

```raku
use Rakuish::DSL;
EVALFILE 'foo.rakuish';
```

- 不需要 `Rakuish::Script` 的“命令格 + 拼装”；
- 不需要 shebang 解释器选择；
- 不需要 `%magic` 在脚本模式下模拟；
- `@*ARGS`、`MAIN`、`exit` 都是 Raku 原生。

---

## 6. Agent 接口

### 6.1 不要再用 shell 字符串

当前：

```json
{"cmd":"! ls -la | grep md"}
```

目标：

```json
{"id":1,"op":"list","path":"src","recursive":true}
{"id":2,"op":"read","path":"README.md","max_bytes":1048576}
{"id":3,"op":"write","path":"out.txt","content":"...","atomic":true}
{"id":4,"op":"exec","argv":["git","status"],"cwd":".","timeout_ms":30000}
```

每个 op 对应 `Sys` 方法，参数是结构化 JSON：

- `read_file`：`path` / `encoding` / `binary` / `offset` / `max_bytes`
- `write_file`：`path` / `content` / `encoding` / `atomic` / `mkdir` / `backup`
- `list_dir`：`path` / `recursive` / `hidden` / `max_depth`
- `stat`：`path`
- `exec`：`argv` 数组 / `cwd` / `env` / `timeout_ms` / `max_output`
- `grep`：`pattern` / `paths` / `glob` / `max_matches`
- `eval`（可选）：`code` / `timeout_ms`

### 6.2 每个会话一个 `Sys`

```raku
my $sys = Rakuish::Sys.new(
    cwd     => $session-cwd,
    env     => %$session-env,
    sandbox => $sandbox,
);
```

- 不再共享进程 `chdir` / `%*ENV`；
- 并发会话互不干扰；
- `exec` 用 `:cwd` / `:env`，不改进程全局状态。

### 6.3 默认安全策略

| 项 | 默认 |
|---|---|
| 监听地址 | `127.0.0.1`（不是 INADDR_ANY） |
| 认证 | 启动时生成 token，客户端必须带 |
| 文件根 | 显式 `--root`，路径必须在 root 内 |
| 符号链接 | 默认不跟随（或 `resolve` 后检查） |
| 命令 | 默认只允许白名单；`exec` 需显式开启 |
| 读大小 | `max_bytes` 默认 1 MiB |
| 写大小 | `max_bytes` 默认 1 MiB |
| 超时 | `timeout_ms` 默认 30s |
| 输出 | 超过 `max_output` 截断并标记 |
| 审计 | JSONL 记录 op / path / argv / 结果 |

这些都应该在 `Sandbox` 里实现，而不是在业务代码里写 `is-win` 或 `if`。

---

## 7. Read / Write 的详细设计（Agent 最常用）

### 7.1 `read`

```raku
sys.read('a.txt')                       # Str，UTF-8
sys.read('a.txt', :enc<gb18030>)        # 指定编码
sys.read('a.bin', :bin)                 # Blob
sys.read('a.txt', :max-bytes(1MB))      # 超限报错/截断
sys.read('a.txt', :offset(100), :limit(200))
sys.read('a.txt', :lines)               # List[Str]，惰性
```

要求：

- 二进制安全；
- 非法 UTF-8 不崩（替换 U+FFFD 或报错，由参数决定）；
- 大文件不一次性读入（`:stream` / `:lines`）；
- 明确返回 `Str` / `Blob`，不做隐式字符串化。

### 7.2 `write`

```raku
sys.write('a.txt', 'hello')
sys.write('a.txt', 'hello', :append)
sys.write('a.txt', 'hello', :atomic)    # 临时文件 + rename
sys.write('a.txt', 'hello', :mkdir)     # 自动建父目录
sys.write('a.txt', $blob, :bin)
sys.write('a.txt', 'hello', :backup)    # 覆盖前备份
```

要求：

- 原子写默认开启（Agent 写代码/配置最怕半截文件）；
- 明确权限（默认 0644 或 0600，按产品定）；
- 返回写入字节数 / `WriteResult`；
- 不把内容拼进 shell 命令，杜绝注入。

### 7.3 `list` / `stat` / `rm`

```raku
sys.ls('.', :all, :recursive, :max-depth(3))   # List[IO::Path]
sys.stat('a.txt')                               # Stat: size/type/mtime/mode/link
sys.rm('tmp', :recursive, :force, :dry-run)
```

- `ls` 返回 `IO::Path`，不是字符串；
- `stat` 返回类型化 `Stat`，`is-symlink` 必须真实；
- `rm` 不跟随符号链接；拒绝删根；`dry-run` 给 Agent 预览。

---

## 8. 需要删除 / 降级的模块

| 模块 | 处理 |
|---|---|
| `Parser` / `Parser::Lexer` / `Parser::AST` / `Parser::Parser` | **删除**（shell 语法不再需要） |
| `Engine::Pipeline` / `Engine::Redirect` / `Engine::Executor` | **删除或重写为 `Sys::Proc`** |
| `Shell::Exec` / `Shell::Posix` / `Shell::NewStack` / `Shell::Engine` / `Shell::Session` / `Shell::Platform` | **退出主路径**（legacy 归档） |
| `bin/rakuish-sh` / daemon / PID / env 协议 | **删除**（没有 shell engine） |
| `Builtin` 的 bash 语义命令 | 重写为 `Sys` 类型化 API |
| `SPEC.md` 的 bash 语法 | **重写**为 Raku Native API SPEC |
| `JSONServer` 的 shell 字符串模式 | 改为类型化 JSON-RPC |
| `Loop` 的 `kind-of` / auto-shell / magic | 简化；magic 只保留 REPL 辅助 |
| `META6` 的旧描述 / 依赖 | 更新；API v3 |
| `t/parser` / bash 对拍测试 | 删除；改为 `t/sys` / `t/dsl` / `t/agent` |

**保留并复用**：

- `Platform` 的 POSIX/Win32 差异（作为 `Sys` 内部后端）；
- `IO::Path`（替代自建 `Path`）；
- `REPL` 的行编辑 / 补全 / 打印 / 历史；
- `Result` 概念（重写为类型化）；
- `Config`（用户配置）；
- `Incomplete`（多行判定，纯逻辑）；
- `JSONServer` 的 JSONL 传输思路（但 op 要类型化）。

---

## 9. 迁移路线（建议 API v3）

### Phase 0：定方向（1 天）

- 写 ADR：**Rakuish 不再实现 bash/POSIX 子集**；
- 把当前 v2 SPEC 标记为 legacy；
- 确定 `Sys` / `Result` / `Command` 三个核心类型。

### Phase 1：`Sys` + 文件 API（2–3 天）

- `Sys::FS`：read/write/append/ls/stat/rm/cp/mv/mkdir/glob；
- `Result` / `Stat` / `WriteResult`；
- 全部用 `IO::Path`；
- 单测 + Windows/Linux 双平台测试。

### Phase 2：`exec` + 流（2–3 天）

- `Sys::Proc`：argv、cwd、env、stdin/out/err、timeout、cancel；
- `Result` + `.lines` / `.json`；
- 大输出流式处理；
- 不做 shell 解析。

### Phase 3：DSL + REPL（2 天）

- `Rakuish::DSL` 导出 `ls` / `read` / `write` / `exec` / `cd` / `pwd`；
- REPL 直接求值 Raku；
- `!` 只做 argv 分词；
- 删除 `kind-of` / auto-shell / `%shell` 的旧分流。

### Phase 4：Agent RPC（2–3 天）

- JSONL / TCP：类型化 op；
- 每会话 `Sys`；
- `Sandbox`：root / allowlist / max-bytes / timeout / audit；
- 默认 127.0.0.1 + token。

### Phase 5：清理（1–2 天）

- 删除 `Parser` / `Pipeline` / `Shell::*` / `rakuish-sh` / daemon；
- 重写 README / SPEC / META6；
- 删除 bash 对拍测试；
- CI Windows + Linux。

---

## 10. 需要产品先拍板的 6 个问题

1. **脚本还是 Raku 脚本吗？**
   推荐：是。`.rakuish` = Raku + 预加载 DSL，不再有独立命令语法。
2. **`!` 是否保留？**
   推荐：保留，但只做 argv 分词，不做任何 shell 元字符。
3. **文件 API 错误模型：抛异常还是返回 `Result`？**
   推荐：文件 API 抛异常（Raku 风格）；Agent 边界统一转 `Result`。
4. **`Sys` 是会话级还是进程级？**
   推荐：会话级。`cwd`/`env` 不改进程全局，多 Agent 会话安全。
5. **Agent 默认允许 `exec` 吗？**
   推荐：默认不允许；显式 `--allow-exec` + 命令白名单。
6. **Windows 支持范围？**
   推荐：argv 外部命令 + 文件 API；不承诺 bash/POSIX 语法；`!` 不做管道/重定向。

---

## 11. 一句话总结

**当前仓库的 Parser/Engine 是在“让 Raku 看起来像 bash”；新目标应该是“让 Raku 直接成为命令与脚本语言”。**

需要调整的不是某个模块，而是**命令语言的底座**：

- 删除 shell grammar（Parser / Pipeline / Redirect / shell engine）；
- 用 `Sys` 类型化 API 替代 bash 内建；
- 用 Raku 函数调用 / 方法链 / `Result` 替代 `$VAR` / `|` / `&&` / 重定向；
- 脚本就是 Raku；
- Agent 接口用结构化 op，不用 shell 字符串；
- 默认安全：本地绑定、token、沙箱、路径根、超时、大小限制。

这样做之后，`ls`、`read`、`write`、`exec` 对 Agent 来说是**类型化、可校验、可审计**的，不再需要“猜一行字符串是什么意思”。
