# ADR-0001：Rakuish 不再实现 bash / POSIX 子集（API v3）

- **日期**：2026-11-09
- **状态**：Accepted（**Phase 0–5 全部落地**：0.29.0 → 0.34.0；v2 已于 0.34.0 整体删除）
- **依据**：`docs/DESIGN-RAKU-NATIVE.md`、`docs/REVIEW-2026-11-09.md`（v2 时期的评审，已随 v2 删除）
- **影响范围**：命令语言底座、文件 / 进程 API、REPL、脚本、Agent 接口

---

## 1. 背景

v2（`api = 2`，0.28.x）的 `SPEC.md` / `Parser` / `Engine::Pipeline` / `Shell::*` /
`bin/rakuish-sh` 是一套**用 Raku 实现的 bash 子集**：`$VAR`、`|`、`>`、`&&`、
`test`、`export`、`cd`、heredoc……

`docs/REVIEW-2026-11-09.md` 列出的 7 个 P0 不是零散 bug，而是这套底座的必然产物：

| 现象 | 根因 |
|---|---|
| `rm -r` 对非空目录失败 | 自建 `Platform::Path` 没有 `.d`；`IO::Path` 本来就有 |
| `test -L` 恒 False、`test -r` 只看存在 | 自建 `Stat.is-symlink` 硬编码 False |
| `ls -la` 被当路径 | 自建 Lexer 要自己解析 flag |
| `yes \| head -1` 挂死、撑盘 | 自建 Pipeline 用临时文件模拟管道 |
| TCP server 无认证、中文损坏 | shell 字符串协议 + 手写 socket 编解码 |
| `dispatch-kind` 无调用点、`run`/反引号走 legacy | 两套语言、两套执行栈长期并存 |

继续在这套语法上补 bash 语义，只会持续制造「实现 vs 文档 vs 测试」三处漂移。
**问题不是还差几个 bug，而是底座选错了。**

## 2. 决策

**Raku 是唯一的命令语言。** 命令是 Raku 函数 / 方法 / 对象，不是文本行。

1. 不再实现、不再扩展 bash / POSIX 语法；
2. 系统操作收敛到会话级 `Sys` 对象，路径一律用 `IO::Path`；
3. 外部命令只接 **argv 数组**，永不经过 shell；
4. 脚本就是 Raku 脚本（`.rakuish` = Raku + 预加载 DSL）；
5. Agent 接口用结构化 op，不用 shell 字符串；
6. 默认安全：本地绑定、token、root 沙箱、大小 / 超时上限、审计；
7. REPL **不保留 `%magic` 分流**：`%` 开头一律按 Raku 求值，元能力迁到
   会话级 `repl` 对象与按键绑定（2026-11-09 产品确认，见 §2.3）。

### 2.1 采纳的 7 条拍板结论（设计 §10 推荐值 + 1 条补充）

| # | 问题 | 本 ADR 采纳 | 落地阶段 |
|---|---|---|---|
| 1 | `.rakuish` 是否就是 Raku 脚本 | **是**，不再有独立命令语法 | Phase 3 |
| 2 | `!` 是否保留 | **保留，仅做 argv 分词**；不做 `$` / `*` / `\|` / `>` / `&&` / heredoc | Phase 3 |
| 3 | 文件 API 错误模型 | **读 / 写 / 列目录 / stat 抛异常**（Raku 风格）；`rm` / `cp` / `mv` 等破坏性或带 `dry-run` 的操作返回 `Result`；Agent 边界一律用 `Sys.try-op` 转 `Result` | Phase 1 |
| 4 | `Sys` 作用域 | **会话级**；`cwd` / `env` 是对象属性，不调 `chdir`、不改 `%*ENV` | Phase 1 |
| 5 | Agent 默认允许 `exec` | **默认不允许**；显式开启 + 白名单 | Phase 4 |
| 6 | Windows 支持范围 | **argv 外部命令 + 文件 API**；不承诺 bash / POSIX 语法 | Phase 2 |
| 7 | `%magic` 是否保留 | **不保留分流**；`repl` 对象承载会话状态，纯交互动作走快捷键，禁止 magic 直接读写文件 / 启动进程 | Phase 3 |

> 第 1–6 条按设计文档 §10 推荐值采纳，第 7 条为 Phase 3 开工前的产品补充决策；
> 如需改动，改本表并同步根目录 `SPEC.md`。

### 2.2 命名空间策略（迁移期取舍，已完成）

迁移期（Phase 1–5a）v2 与 v3 并存，P0 修复已在 `2952261` 单独合入。
**当时 Phase 1–4 不删任何旧模块、不覆盖任何旧类**：

```
Rakuish::V3::Result        Result / Stat / WriteResult / X::Rakuish::V3::*
Rakuish::V3::Sys::FS       read / write / ls / stat / rm / cp / mv / mkdir / glob
Rakuish::V3::Sys           会话级 cwd / env / root / resolve / try-op
```

- 与 v2 完全隔离，`META6.provides` 追加条目即可加载；
- `api` 字段当时保持 `2`，否则等于宣称 v2 已消失（且 `t/e2e/55-api-v2.t` 有硬断言）。

**0.34.0（5b）已收尾**：v2 整体删除后，`Rakuish::V3::*` 全部提升为 `Rakuish::*`
（`Rakuish::Result` / `Sys` / `Sys::FS` / `Sys::Proc` / `Command` / `DSL` /
`REPL::Session` / `Sandbox` / `Agent` / `Agent::Server`），`META6.api = 3`，
`Rakuish::V3` 目录已不存在（`t/07` 断言）。

这是**并行迁移**而不是「半吊子兼容层」：v3 从来不复用任何 v2 语义，也不接受 shell 字符串。

### 2.4 Phase 5 拆分决策（2026-11-09 产品确认）

产品指令：「开 P5，**保留一个兼容入口**，等我做好试试再说整体下线 v2 的事」。
因此原路线表里「Phase 5 = 删除 legacy + 顶层名提升 + `api = 3`」这个**原子步骤拆成两步**：

| | 范围 | 状态 |
|---|---|---|
| **5a（0.33.0）** | `bin/rakuish` 收口为 V3 默认入口（REPL / `-e` / Raku 脚本）；原启动器原样保留为 `bin/rakuish-v2`，只能显式 `rakuish --v2` 进入；`--agent` 转发 Agent；`SPEC-v3.md` 成为 V3 规格真值、`SPEC.md` 标 legacy；README 主次对调；`t/v3/07-entrypoints.t` 双平台锁住两入口隔离 | ✅ |
| **5b（0.34.0，2026-11-09 确认）** | 删除 v2 的 61 个模块、5 个入口、44 个 `.t`、对拍 / 压测工具与 v2 文档；`Rakuish::V3::*` 提升为 `Rakuish::*`；`META6.api = 3`；`SPEC-v3.md` 升为根 `SPEC.md`；README / HANDOFF 重写为 v3-only；`t/07` 改锁「只有两个入口、无 v2 痕迹」 | ✅ |

**为什么 5a 不做顶层名提升**：v2 兼容入口仍在，顶层命名空间已被占用 ——
`Rakuish::Result`（v2）、`Rakuish::REPL::*` 下 8 个 v2 子模块、
`Rakuish::Config` / `Eval` / `Loop` / `Script` 等都与 v3 目标名冲突。
此时把 `Rakuish::V3::Result` 提升成 `Rakuish::Result` 会**直接覆盖 v2 的类**，
把刚承诺保留的兼容入口弄坏；只提升无冲突的那几个又会让同一套 API 出现两个名字。
所以 5b 必须与「删 v2」同批原子完成（0.34.0 已按此执行）。

**为什么 5a 时 `api` 仍是 `2`**：`api` 描述的是**发行版对外契约**。5a 之后 v2 代码、
v2 兼容入口、v2 的 44 个 `.t` 都还在仓库里且可运行；写 `api = 3` 等于向 zef / 依赖方
宣称 v2 已消失，是虚假宣称。5b 删干净后改 `3`，宣称与实际一致。

**5a 时 v2 兼容入口的硬契约**（当时由 `t/v3/07-entrypoints.t` 守护，现随 v2 一并删除）：
`bin/rakuish-v2` 是原 `bin/rakuish` 的完整副本，`run <脚本>` / `<脚本>` / `--json` /
`--daemon` / `%magic` / `!` bash 子集全部可用；默认入口**不猜参数形态**自动转发——
「输入落到哪一层永远明确」是 v3 的承诺，猜测参数形态等于把 `auto-shell` 换成「猜入口」。
这条「不猜」的结论在 5b 之后仍然成立：入口只剩 `rakuish` 与 `rakuish --agent`，
没有按参数形态自动分流的逻辑。

### 2.3 `%magic` 全删的归属与边界（Phase 3 决策）

产品确认（2026-11-09）：选「严格按设计」，并进一步确认**有了 DSL 之后不再保留魔法命令**。
理由不是「DSL 什么都能做」，而是「剩下的能力本来就不该是文本命令」：只要 `%` 分支存在，
`kind-of` 就仍是多套分流；且 `%` 与 Raku 的 `%hash` 语法天然冲突——v2 的 `Dispatcher`
专门写了「`%STORE{...}` / `%RC<...>` 首个 token 含 `{` / `<` 才按 Raku 求值」的特例。
删掉 magic，这整段歧义连同 `%` 分支一起消失，设计 §348 的「不再需要三套分流」才兑现。

当前 v2 的 **21 个** magic 按四类安置：

| 去向 | 命令 | 替代 |
|---|---|---|
| DSL / Sys / Raku 原生（8） | `help` `time` `load` `run` `quit` `exit` `repl` `cd` | 短 sub / `EVALFILE` / `exit` / `sys.cd` / 启动配置 |
| V3 架构变化后消失（3） | `shell` `engine` `eval-engine` | 只有一个后端，没有引擎可切 |
| REPL 运行时状态 → `repl` 对象（6） | `config` `inspect` `trace` `watch` `perf` `bt` | `repl.config<...>` / `repl.trace` / `repl.history` |
| 纯交互动作 → 快捷键（4） | `hist` `edit` `commit` `cancel` | ↑ / Ctrl-R、Ctrl-X Ctrl-E、Ctrl-C |

**硬边界**：`repl` 对象与快捷键只操作 REPL 自身状态，**不允许直接读文件或启动进程**；
所有文件 / 进程操作必须经 `Sys`，否则 Phase 4 的 `Sandbox`（root / allowlist / 审计）
会被绕过。`Command` 注册表（设计 §4.4 的 `role Command` + `CommandSpec`）按产品决定
**从 Phase 4 提前到 Phase 3**，一次把可扩展结构做对；`CommandSpec → JSON Schema`
仍留到 Phase 4。

**求值器自带，不复用 v2 `Rakuish::Eval::eval-cell`**：后者内置 `expand-backticks`，
会把成对的 `` `cmd` `` 静默转成 shell 捕获，等于把第二套语言偷带进 V3。V3 只复用
纯 Raku 逻辑的 `Rakuish::Incomplete::is-incomplete`（多行续行）。

## 3. Phase 1–4 已落地的范围与当时明确不做的事

**做**：

- `Result` / `Stat` / `WriteResult` 类型化；
- `Sys::FS`：`read` / `write` / `append` / `ls` / `stat` / `rm` / `cp` / `mv` / `mkdir` / `glob`，
  全部基于 `IO::Path`；
- `Sys::Proc`（Phase 2）：argv-only `exec` / `spawn` / `wait` / `cancel`，
  真流式 Supply、timeout / cancel、UTF-8 安全的输出上限；`cwd` / `env` 通过
  `Proc::Async.start(:cwd, :ENV)` 下传，宿主进程全局不变；
- `Sys`：会话级 `cwd` / `env` / `root`，`resolve()` 做词法归一化 + root 沙箱校验，
  `try-op()` 把异常转成 `Result`；
- Windows + Linux 双平台回归 `t/`（迁移期在 `t/v3/`，0.34.0 起平移到 `t/`；01 / 02 / 03 共 73 + 36 + 49 条断言）。

**不做**（写清楚，避免下一位接手者误判为「漏了」）：

| 不做 | 原因 / 阶段 |
|---|---|
| ~~`Rakuish::DSL`、`Command` 注册表、V3 REPL~~ | ✅ 已于 Phase 3（0.31.0）落地；决策见 §2.3、路线见 §4 |
| ~~JSON-RPC 结构化 op、`Sandbox`、token、审计~~ | ✅ 已于 Phase 4（0.32.0）落地 |
| 删除 `Parser` / `Pipeline` / `Shell::*` / `rakuish-sh` | **5b**；用户要求先保留 v2 兼容入口试用，整体下线待确认，见 §2.4 |
| `read` 的流式 / `:lines` 惰性读取、非法 UTF-8 替换策略 | Phase 2；本轮用 `max-bytes` 上限 + 明确异常兜住，不静默截断 |
| 完整 glob（`**`、字符集、brace） | Phase 2；本轮只支持 `*` / `?` 的基础匹配 |
| 符号链接中间目录的逐级沙箱校验 | Phase 4 `Sandbox`；本轮只校验路径本身是链接时的解析目标 |

**已知的跨平台诚实边界**：`IO::Path.mode` / `.modified` 在 Windows 上可能返回 0 或不可靠值
（v2 的 HANDOFF §7.17 已记录同类问题）。V3 `Stat` 如实返回，不编造 1970 年假时间；
取不到时 `modified` 未定义、`mode` 为 0，由调用方判断。

## 4. 迁移路线

| Phase | 内容 | 状态 |
|---|---|---|
| 0 | 本 ADR、v2 SPEC 标记 legacy、确定三核心类型 | ✅ 本轮 |
| 1 | `Sys::FS` + `Result` + `Stat` + `IO::Path`，双平台测试 | ✅ 本轮 |
| 2 | `Sys::Proc`（argv / stream / timeout / cancel） | ✅ 本轮（0.30.0） |
| 3 | `Rakuish::V3::{DSL, Command, REPL::Session}` + `bin/rakuish-v3`；`%magic` 全删、`!` 只做 argv | ✅ 本轮（0.31.0） |
| 4 | Agent 类型化 op + `Sandbox`（root / token / allowlist / 审计）+ JSONL / TCP | ✅ 本轮（0.32.0） |
| 5a | 默认入口收口为 V3、`bin/rakuish-v2` 兼容入口、`--agent` 转发、`SPEC-v3.md`、README 主次对调 | ✅ 本轮（0.33.0） |
| 5b | 删除 legacy、顶层名提升、`api = 3`、重写 SPEC / README | ✅ 0.34.0（2026-11-09） |

## 5. 后果

**正面**

- 文件 API 直接解决 `rm -r` / `test -L` / `ls -la` 这一类 bug 的**根因**：不再自建 Path / Stat；
- Agent 拿到的是可校验的类型化参数，不再有 shell 注入面；
- 多会话 cwd / env 互不污染。

**代价 / 风险**

- ~~5a 之后默认入口已是 V3，但仓库里仍并存 v2 代码与兼容入口，文档必须标注主线~~ ——
  **0.34.0 起 v2 已删除，只剩一套实现**，文档不再需要「主次」标注；
- Phase 3 改 REPL 会动到 `%magic` / `auto-shell` 等用户习惯；**产品已于 2026-11-09
  确认「严格设计 + 全删 magic + `repl` 对象 + 快捷键」**，迁移成本与边界见 §2.3；
- 删 v2 是一次**破坏性变更**：依赖 `Rakuish::Parser` / `Shell::*` / `Result`（v2 语义）
  或 `rakuish --v2` 的用法全部失效，只能 `api = 3` + 大版本号通知下游；
- v2 时期积累的测试资产（44 个 `.t`，含 bash 对拍）随之下线，其中仍有价值的断言
  已在迁移期陆续移植进 v3 的 `t/01–07`。

## 6. 验收口径（Phase 1–5b）

- `raku -Ilib t/*.t`：Windows 与 Linux 均 `not ok = 0`；
  （01 文件 API 73 / 02 会话语义 36 / 03 进程 API 49 /
  04 DSL+Command 62 / 05 REPL 会话 56 / 06 Sandbox+Agent 96 /
  07 入口契约 63 条，另 51 / 52 为元数据与全模块加载护栏）；
- `t/07-entrypoints.t` 额外钉住：**只有两个入口**、v2 入口文件与模块必须不存在、
  无 magic / 无 auto-shell、`!` argv 原样、Raku 脚本无 `Out[n]`、
  转发继承 stdio 与退出码、两个入口版本常量与 META6 一致、`api = 3`；
- `bash tools/run-all.sh`：任意 `not ok` / 非零退出码 / 缺 TAP plan 都计为问题，
  脚本退出码即「问题总数是否为 0」；
- `zef install .` 的 staging 阶段不应出现 `Potential difficulties`（改完 `lib/`
  跑一遍全模块 `raku -c` 自检）；
- `META6.json` 版本按 semver 递增，`provides` 覆盖所有模块；
- 每个新增能力有对应 `.t`；断言同时包含正向（必须含 Y）与反向（不得含 X）。
