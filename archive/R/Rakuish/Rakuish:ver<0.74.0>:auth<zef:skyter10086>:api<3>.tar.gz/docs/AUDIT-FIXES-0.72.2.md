# 0.72.2 修复记录

- **日期**：2026-11-13
- **对象**：`main` @ 0.72.1 → 0.72.2
- **能力**：PTY 能力探测（R-1）+ 捕获层正确性/性能收尾（R-3）
- **输入**：《Rakuish 0.72.1 剩余问题与改进任务书》R-1 / R-3，
  《Rakuish 终端层（TTY / PTY）补齐方案》§5 阶段 0

## 1. R-1：不再把「可能是 PTY」写成「一定是 PTY」 `[确证]`

- 问题：`Sys/Proc.rakumod` 直接 `Proc::Async.new(..., :pty(...))`，而该构造器用
  `*%_` 吞掉未知命名参数 —— 旧 Rakudo 不报错但完全不生效；
  `Result.value<pty>/<tty>` 却硬编码 `True`，等于结果撒谎。实测
  `Proc::Async.new(..., :bogus-option(1))` 不抛异常、exit=0，前提成立。
- `META6.json` 的 `raku` 字段是语言版本（6.c/6.d），**不是 Rakudo 编译器版本**，
  zef 没有可靠的 Rakudo 下限字段；硬塞未识别键只会让安装元数据失真。
  因此采用文档给的第二个选项：**运行时双检 + 明确失败**，并在 MANUAL/SPEC
  写明「需要 Rakudo ≥ 2025.12」。
- 新增 `Rakuish::Sys::Proc.pty-capability()`：
  1. `$*RAKU.compiler.version >= v2025.12`；
  2. 用 `:pty` 起一个 `raku -e 'print $*OUT.t ?? ... !! ...'` 探针，
     断言子进程真的看到 TTY（3s 超时、SIGKILL 兜底）；
  3. 结果用 `Lock` + 进程级缓存，一次/进程，不拖慢后续每格。
- 失败时 `pty-exec` 返回 `Result.new(:!ok, :code(127))`，
  `err` 写明原因，`value<pty>/<tty>` 明确为 `False` 并带 `reason`；
  **不降级成普通 exec、不抛穿 Agent**（`Agent.handle-line` 的 CATCH 仍是最后护栏）。
- 测试可以子类覆盖 `pty-capability` 注入失败，无需装旧 Rakudo（`t/29`）。

## 2. R-3：捕获层重构 `[需复核 → 已实证]`

| 项 | 0.72.1 | 0.72.2 |
|---|---|---|
| tap 内累积 | `$raw = $raw ~ $piece` + 每 chunk 全量 `.encode` | `@chunks.push` + 仅对**新 chunk** 计数；结束一次 `join` |
| 复杂度实测（Windows，净耗时） | 50k→0.08s，800k→**3.815s**（超线性） | 50k→0.064s，800k→**0.583s**（近线性，约 6.5× 改善）；Linux 本来就近线性，不夸大为跨平台缺陷 |
| 内存 | 全量字符串常驻 | 超过 `4 × max-bytes` 后停止累积、继续消费，内存有界并标 `truncated` |
| 控制序列 | 先按 raw 字节截断，再剥离 → 半截 `ESC[` 序列残留（`[3` / `[31` / `RED[`） | **先对完整输出剥离一次，再按 UTF-8 安全截断**；控制序列不占 `max-bytes` 配额 |
| drain | 固定 `sleep 0.02` | 等 stdout Supply 的 `done/quit`（0.5s 兜底），不再赌固定时间；兜底超时标 `truncated` |
| 结果标记 | `pty/tty/timed-out/truncated/cols/rows` | 增 `pty-capable` / `stderr-merged` / `stdin-unavailable` / `strip-ansi` / `reason`（失败时） |

- 文档 R-3 说「ANSI 剥离按 chunk 做，跨 chunk 控制序列可能残留」**与源码不符**：
  0.72.1 已是对完整 `$raw` 调用一次 `strip-terminal-controls`。真正产生残片的是
  `max-bytes` 截断，本版按「先剥离后截断」从机制上消除。
- `:!strip-ansi` 时仍按原始字节截断（调用方明确要求保留控制序列，半截序列是
  该模式的已知边界，不假装兜底）。

## 3. 边界（不变）

- 仍**不提供 stdin 写入**：`pty-exec` 跑需要键盘的 REPL 会挂到超时（`code=124`），
  交互式程序请用 `tty-exec`；`value<stdin-unavailable>` 现在把这个事实写进结果。
- PTY 下 stderr 与 stdout 合流，`Result.err` 恒为空（超时除外）；
  `value<stderr-merged>` 供审计/调用方判断，不伪造独立的 err 通道。
- 超时只 `kill` 直接子进程；**不承诺杀孙进程**（B / V-905 仍是后续项）。
- **Windows ConPTY 大输出可能丢尾部 chunk**：裸 `Proc::Async.new(:pty)` +
  `Supply.tap(done => ...)` 同样能复现（实测 3 次里 1 次），`done` 之后再等
  250ms 也补不回来，属驱动层行为，0.72.1 / 0.72.2 一致；Linux POSIX PTY
  未复现。要逐字节完整输出时让子进程写文件再读，不要依赖 PTY 捕获。
  这不是本版引入的回归，测试只钉住「不崩、有主要输出、不误报 truncated」。
- 不实现 REPL `! --pty` 元选项、SIGINT 归属 / termios 快照、job control
  （《补齐方案》§5 阶段 2；任务书 §4.4 L3 明确列为剩余项，本版不动）。

## 4. 验证

```bash
prove6 -Ilib t                 # Windows，含 t/28 / t/29
bash tools/run-all.sh          # WSL / Linux
python3 tools/tty-check.py     # 真 TTY 自检
zef install . --force-install
```

双平台都用真 Raku `v2026.09` 跑过 isatty、stderr 合流、超时、非零退出码、
大输出耗时、ANSI 截断边界与普通 `exec` 对照组（`TTY=False`）。

顺手清理 `t/07-entrypoints.t` 里重复的 `my %bad-opt` 声明 —— 它会让
`zef install` 的 Testing 阶段打印 `Redeclaration of symbol` 编译警告
（0.72.x 遗留，与 PTY 无关，但冒烟输出不该带警告）。
