# 审计清单清零记录（0.61.0）

- **日期**：2026-11-11
- **对象**：`Rakuish` `main` @ 0.61.0
- **原始审计**：[AUDIT-2026-11-11.md](AUDIT-2026-11-11.md)
- **结论**：P0/P1 全部关闭；P2 除两项明确“接受的设计限制”外全部关闭。
  没有未决的发布阻断项。

## 关闭状态

### P0（发布阻断）

| # | 状态 | 证据 |
|---|---|---|
| P0-1 REPL 重放历史副作用 | 关闭 | 只执行当前格；`t/05` 副作用/状态测试；`t/05` `_`/`Out` |
| P0-2 中间 symlink 逃逸 | 关闭 | `Sys.resolve` 每级 canonical；`t/01` 中间 symlink 读写拒绝 |
| P0-3 exec 白名单 basename 绕过 | 关闭 | 绝对路径精确匹配、裸名按 PATH；`t/06` |
| P0-4 请求级危险 env | 关闭 | 安全 env 白名单；`t/06` `LD_PRELOAD`/`PATH` 拒绝 |

### P1

| # | 状态 | 证据 |
|---|---|---|
| P1-1 REPL 默认 root=cwd | 关闭 | REPL root 默认文件系统根；`t/05` `cd ..` |
| P1-2 read offset/limit 边界 | 关闭 | `t/01` 边界断言 |
| P1-3 Proc 输出上限 | 关闭 | 边读边计数/裁剪；`t/03` 无限输出 |
| P1-4 spawn stdin 阻塞 | 关闭 | 写入走后台任务；`t/03` |
| P1-5 Windows 原子写丢目标 | 关闭 | 备份后替换、失败回滚；`t/01` |
| P1-6 cp 跟随目录内 symlink | 关闭 | 拒绝 symlink；`t/01` |
| P1-7 ls 文件目标 | 关闭 | `t/01` |
| P1-8 DSL 全局 Session 串会话 | 关闭 | 每格动态 `$*RAKUISH-SYS`；`t/05` 多 Session |
| P1-9 JSONL 行长/idle/flush | 关闭 | `run-jsonl` 行长与 flush；`serve-once` async idle；`t/06` |
| P1-10 Agent/Renderer 两套 JSON | 关闭 | Agent 直接调用 `Renderer::json-value` |

### P2

| # | 状态 | 说明 |
|---|---|---|
| 1 summary 回显 token | 关闭 | `summary.token = '<redacted>'` |
| 2 弱随机 token | 关闭 | OS CSPRNG；失败拒绝启动 |
| 3 exec :cwd 绕过 | 关闭 | `Sys!proc-opts` 对 cwd 做 resolve |
| 4 临时文件可预测/非独占 | 关闭 | 随机名 + `spurt(:exclusive)`；`.bak` symlink 拒绝 |
| 5 backup 不检查大小 | 关闭 | `max-bytes` 预检 |
| 6 递归/cp 无总上限 | 关闭 | `max-entries`；`t/01` |
| 7 glob `?` 跨目录 | 关闭 | 不跨 `/`；完整 glob 扩展 |
| 8 audit 无上限/无轮转 | 关闭 | 条目上限 + JSONL 轮转 |
| 9 递归 basename 丢上下文 | 关闭 | 不同目录时显示相对 cwd 路径；`t/09` |
| 10 `!` 未闭合引号 | 关闭 | 返回 127；`t/05` |
| 11 嵌套 `exit` 与 REPL 退出差异 | **接受** | Raku 的 `exit` 是进程级；仅整行 `exit`/`exit N` 映射为会话退出。脚本内嵌套 `exit` 保持 Raku 语义，文档已说明。 |
| 12 serve-once 单连接 | **接受** | 传输层命名即 `serve-once`；多客户端不是当前产品承诺。 |

## 验证

- Windows：`prove6 -Ilib t` → **16 个文件 / 879 条断言**
- Linux：`bash tools/run-all.sh` → **0**
- `zef install . --force-install` → 通过

## 备注

- 审计原文保留为历史记录，不再逐条改写；本文件是关闭状态的真值。
- “接受”不是“已修”：它们是明确的产品/语言边界，后续如改变承诺需重新开项。
