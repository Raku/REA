# ADR-0002：Agent 多客户端服务与请求级取消（0.63.0）

- **日期**：2026-11-11
- **状态**：Accepted（0.63.0 实现）
- **影响范围**：`Rakuish::Agent`、`Rakuish::Agent::Server`、`bin/rakuish-agent`、SPEC §6、ROADMAP P1
- **前置**：[ADR-0001](ADR-0001-raku-native.md)、`SPEC.md` V-148 / V-505

---

## 1. 背景

0.62.0 及以前，Agent 有两个明确记录在 `ROADMAP` / `HANDOFF` §5.2 的弱点：

1. **单连接**：`serve-once` 是 `react` 里 `whenever $server` 收到一个连接后 `done`，
   一个进程只服务一个客户端，名字里就写着 once。
2. **超时是事后检查**：`Agent.handle` 先同步跑完 `!dispatch`，再判断 `now > $deadline`。
   一个卡住的操作要等它自己返回才回 504；期间该连接被完全占住，
   `--request-timeout-ms` 只保证「响应不早于操作结束」，不能保证响应及时。

`ROADMAP` P1 原文写的是「把单请求执行搬到可终止的 worker/进程；超时真正 kill」。
本 ADR 采纳其目标（**及时响应、连接不被拖死**），但**不采纳按请求 fork 进程的实现**。

## 2. 为什么不按请求 fork worker

| 方案 | 问题 |
|---|---|
| 每请求 fork 一个 Raku worker | 本地 Agent 一次 `read_file` 也要付一次 Rakudo 启动 + precomp 加载（百毫秒级）；`Sandbox` / `Engine` 要序列化重建；审计文件被多进程并发追加；Windows 上更慢。为「能 kill」把常态延迟抬高两个数量级，产品上不划算。 |
| 常驻 worker 进程池 | 需要任务队列、心跳、结果回传、kill 后重建、跨进程 Engine 归属；远超「小步提交」的边界，且引入新的失败域。 |
| **Raku 线程内 `start {}` + 底层硬超时**（本 ADR） | 常态零额外开销；`exec`（`Proc::Async` timeout/kill）与 SQL（`max_execution_time` / `sqlite3_interrupt`）本来就**可以真终止**；只剩纯文件 I/O 这类不可取消操作。 |

**诚实边界**：Raku 线程无法被强制 kill。0.63.0 保证的是
「超时到点立即返回 504、该请求结果被丢弃、连接继续可用、可取消的底层操作真的终止」；
**不保证**卡在不可取消文件 I/O 里的线程立刻消失。这个差异写进 SPEC / HANDOFF / MANUAL，
不假装解决。OS 级进程隔离若将来需要，另开 0.67 与独立 ADR。

## 3. 决策

### 3.1 传输层

- **新增 `serve()` 常驻 accept loop**（`Rakuish::Agent::Server`）：
  - 不 `done`；每连接一个独立任务，互不阻塞；
  - `Promise :$stop` 可优雅停止（生产入口 Ctrl-C / 测试用）；
  - `:max-connections`（默认 16）限制并发连接数，超限直接关闭新连接并计数；
  - 每连接独立 `idle-timeout-ms`；`on-ready` 仍在真正监听后回调端口。
- **`serve-once` 原样保留**：单连接语义由 `t/06` 守护，不改、不删除、不偷偷改行为。
- 入口新增 `--serve`（配合 `--mode tcp`）走常驻；默认 `--mode tcp` 仍是 `serve-once`。

### 3.2 会话隔离

- 每连接 `self.new-agent(:session-id(...))`：**独立 `Rakuish::Sys`**（cwd / env / jobs 不串）、
  独立审计 `session` 字段（形如 `<base>-c3`）。
- `Sandbox` 策略对象仍共享（它只放不可变策略 + token + 审计入口），符合「策略集中」；
  审计条目靠 `session` 区分来源。
- **Engine（SQL 连接）不共享**：`serve()` 接受 `:&engine-factory`，每连接新建只读连接；
  若配置了 `--db` 却没给 factory，常驻模式直接拒绝启动（不静默共享）。
  `jsonl` / `serve-once` 仍可用原共享 engine（单会话，无并发写者问题）。

### 3.3 请求级取消

- `Agent.handle` 把 `!dispatch` 放进 `start {}`；
  `await Promise.anyof($job, Promise.in(remaining))`：
  - 任务先完成 → 正常响应 + 审计 stage=op；
  - deadline 先到 → **立即**回 504 + 审计 stage=timeout，后台任务结果丢弃；
  - 任务抛异常 → 收敛成 500，不泄漏异常到传输层。
- `exec` / `sql_query` 的 deadline 仍按 V-148 压进 `:timeout-ms` /
  `max-execution-time-ms`，因此这两类操作会**真的被终止**，不只是响应提前。
- 请求级参数仍然「只能调小」（V-605），超时路径不改变任何上限语义。

## 4. 不变的安全契约

默认拒绝、`exec` / `sql_query` 默认关闭、显式 `--root`、`127.0.0.1` 绑定、
token 认证、白名单 canonical 匹配、请求级 env 安全键、审计不含 token / 内容 / SQL 原文
—— 全部不动。新增的 `--max-connections` 只做**拒绝**，不放宽任何已有能力。

## 5. 验收

- `t/06` 全绿（serve-once / idle timeout / 单连接语义不变）；
- 新增 `t/16-agent-serve.t`：两个并发连接各自拿到响应、session 隔离、
  超时 504 后同一连接仍能处理下一个请求、连接数上限、stop 能收尾；
- `Agent.handle` 的同步调用（JSONL / 嵌入宿主）行为保持：
  正常响应不变，只是超时从「等操作结束」变成「立即」；
- 双平台 `prove6 -Ilib t` / `tools/run-all.sh`；版本与文档同步。

## 6. 后果

**正面**：一个进程可服务多个 Agent 客户端；卡住的请求不再拖死连接；
每连接 cwd / env / Engine 不串；超时响应时间可预期。

**代价 / 已知限制**：
- 不可取消的纯文件 I/O 在被判定超时后仍会在后台线程跑完，结果丢弃；
- 常驻服务需要显式的停止信号，入口在 Ctrl-C 下退出（不是 daemon，不做开机自启）；
- 连接数上限是「同时打开的连接数」，不是速率限制；
- `--db` 在常驻模式下每连接一个只读连接，连接数受 `--max-connections` 约束。
