# 0.72.0 交付记录

- **日期**：2026-11-12
- **对象**：`main` @ 0.72.0
- **能力**：PTY 捕获层 + Agent `pty_exec`

## 新增 API

```raku
sys.pty-exec('python', '-c', 'print("hi")',
             :timeout-ms(5_000), :cols(100), :rows(30));
pty-exec(...);   # DSL 导出
```

- 使用 `Proc::Async.new(:pty(:cols,:rows))`；
- 捕获 stdout，stderr 按 PTY 语义合流；
- 默认剥离 ANSI / OSC / 非换行控制字符；
- `timeout-ms` 到点 kill，`code=124`；
- `max-bytes` 按 UTF-8 安全截断；
- 返回值标记 `pty/tty/timed-out/truncated/cols/rows`。

## Agent op

```json
{"op":"pty_exec","argv":["python","-c","print('hi')"],"timeout_ms":5000}
```

- 默认关闭；
- 必须同时 `--allow-exec --allow-pty`，并过同一命令白名单；
- cwd 过 root，env 只允许安全键；
- 请求的超时/输出/尺寸只能调小；
- 审计沿用 Agent 的 op/argv/结果规则。

## 明确边界

- **没有 PTY stdin 写入**：Rakudo 的 `Proc::Async :pty` 没有可靠 stdin
  通道；`pty-exec` 不是完整交互会话；
- `pty_exec` **不是** `tty_exec`：Agent 仍不开放实时接管终端的 op；
- 超时 kill 直接子进程；不承诺杀孙进程（进程组/Job Object 是后续项）。

## 验证

```bash
prove6 -Ilib t
bash tools/run-all.sh
zef install . --force-install
```

新增 `t/28-pty-exec.t`（18 断言：捕获、TTY 可见、控制序列剥离、超时、
max-bytes、Agent 默认 403、双开关成功）。
