# ADR-0011 · 结果着色与输入行语法高亮

- **日期**：2026-11-13
- **对象**：`main` @ 0.73.0 → 0.74.0
- **状态**：已实施
- **输入**：用户提问「内置 ls 结果能带彩色吗，还有 REPL 输入 Raku 表达式能
  语法高亮吗」→ 追加「内置命令返回结果还有什么需要高亮的一起做了」
- **相关**：[ADR-0003](ADR-0003-repl-experience.md)（Vi/Helix 模态与键位）、
  [ADR-0007](ADR-0007-tty-passthrough.md) §3.4（渲染与退出语义）、SPEC V-116

## 1. 问题

0.73.0 之前，颜色只出现在 banner / prompt / hint / 时钟（`REPL::Chrome`）。
带来的实际观感问题是：

1. `ls` 输出与 `cat` 文本没有区别，目录、可执行文件、符号链接靠肉眼分辨；
2. `help()`、`env()`、`stat`、写入结果都是纯文本，字段名与值混在一起；
3. 输入行是纯白，长表达式里的字符串 / 注释 / 关键字不突出。

## 2. 范围

### 2.1 做

| 位置 | 元素 | 样式 |
|---|---|---|
| `!render-path-list`（ls / glob / recent） | 目录 | `b-blue`（粗蓝） |
| | 可执行 | `b-green`（粗绿） |
| | 符号链接 | `cyan` |
| `!ls-text`（`ls -l` / `-F` / `-R`） | 同上，作用于名字列 | 同上 |
| `Out[n] =` 标签 | 标签本身 | `dim` |
| `错误:` 行 | 整行 | `red` |
| `!render-command-help`（`help()`） | 命令名 | `b-cyan` |
| | 摘要 | `dim` |
| `!render-env-hash`（`env()`） | `KEY` | `cyan` |
| `!render-stat` | 字段名 | `dim` |
| `!render-write` | `wrote` | `green` |
| | `[non-atomic]` | `yellow` |
| 输入行（REPL 编辑中） | 字符串 / 注释 / 数字 / 变量 / 关键字 | 见 §4 |

### 2.2 明确不做

- **`Result` 的 `render-result(format => 'text')` 不掺 ANSI**（SPEC 747 的
  既有条款不变）：那是脚本 / Agent 消费的数据格式，混色会破坏 diff 与解析。
- **Table 的 `to-text`**（`describe` / `ls --json` 的表格）不着色：列宽由
  数据算，着色会引入「可见宽度 ≠ 字符数」的第二次实现；收益与风险不划算。
- **Agent 的所有输出**：Agent 走 JSONL，端上没有终端语义。
- **`NO_COLOR` / 非 TTY / `config set color off`**：一律走原纯文本路径，
  不经过任何着色分支。

## 3. 颜色开关的传递链

0.73.0 的 `color-mode()` 结果只在 `bin/rakuish` 里用于 banner / prompt / hint，
**没有传给 Session**，所以渲染层根本不知道能否着色。本版把它补齐：

```
config color / NO_COLOR / FORCE_COLOR / $*OUT.t
        └─ Chrome::color-mode(pref, :tty)
              ├─ bin/rakuish        （banner / prompt / hint，原有）
              ├─ Session.new(:color)（结果渲染，本版新增）
              └─ make-cli(:highlight)（输入行高亮，本版新增）
```

`Session` 新增 `has Bool $.color = False`。默认 `False` 是刻意的：任何忘记
传参的调用点（测试、库内构造）都退回纯文本，不会意外给数据管道塞 ANSI。

## 4. 输入行语法高亮

### 4.1 为什么能覆盖

`Terminal::LineEditor` 不提供高亮钩子（method 表里没有 `render-input` /
`highlight`）。但它的绘制链路是虚方法：

```
refresh-string → self.render(:$edited) → self.visible-input-field-string
```

`visible-input-field-string` 由 `scroll-pos` 起截取 buffer 的一段，前后加
滚动标记与 padding。我们的 `ViField` 已经是 `ScrollingSingleLineInput::ANSI`
的子类（ADR-0003），覆盖 `visible-input-field-string` 即可，只多一行着色。

### 4.2 唯一硬约束：显示宽度必须一列不差

父类用 `display-width`（对 buffer 内容算出的**显示宽度**）来定位光标与清屏，
而不是用绘制结果。因此：

> **高亮只能往纯文本里插入零宽转义序列，纯文本部分必须逐字符相同。**

实现上分两层保证：
- 词法器 `highlight-line()` 返回的串，`strip-ansi` 后与原串 `eq`；
- 覆盖的方法是「先按父类逻辑算出内容段 → 只对内容段着色 → 再拼前后标记与
  padding」，padding 用**纯文本**宽度算。

`$.mask.defined`（密码类输入）时高亮直接短路，避免把掩码字符泄露成结构信息。

### 4.3 词法范围

单行、无状态、纯函数。识别：注释 `#…`、单双引号字符串（含 `\` 转义）、
数字、`$ @ % &` 变量、关键字表。

**不做**：`q[...]` / `qq[...]` / heredoc / 正则字面量 / 多行字符串 /
pod。它们要么需要跨行状态，要么需要真正的 Raku 词法器；在「每次按键重算
一行」的热路径上不值得，也容易把半截输入染成错的颜色。边界如实写进
MANUAL。

### 4.4 回退

`make-cli` 在 `ViCLIInput` 构造失败时回退到原生 `CLIInput`，那条路径
**没有高亮**（不是原生类的方法）。与 0.73.0 的「Ctrl-C 退回 0.70 行为」
同类，如实标注、不假装。

## 5. 性能

- 高亮：每次编辑重算可见窗口（≈ 终端宽度字符）。扫描是单次线性，无正则
  回溯。实测 120 字符 < 0.2 ms，低于一个按键间隔。
- `ls` 着色：每个条目多做一次 `d` / `l` / `x` 判断（都是文件系统元数据查询）。
  列表通常 < 200 项，未引入可见延迟；`-R` 递归不受影响（逐目录输出）。

## 6. 回归

- `t/33-colors.t`：词法器的**纯文本等价**（`strip-ansi(hl(x)) eq x` 对随机
  样本与边界字符）、关键字/字符串/注释/数字/变量的样式命中、`color=False`
  时逐字节相同；
- 着色后的列宽：多列 `ls` 的列数、每列起点与纯文本版一致；
- `Session.new(:!color)` 时所有渲染函数输出与 0.73.0 逐字节相同（快照对照）；
- `tools/tty-check.py` 增交互检查：真 PTY 下 `ls` 有颜色、输入 `say "hi"`
  时字符串被着色、且**输入不出现字符错位**（比对最终 buffer 内容）。
