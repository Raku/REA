# 0.71.3 审计修复记录

- **日期**：2026-11-12
- **对象**：`main` @ 0.71.3（基于 0.71.2）
- **范围**：审计 M-4 / M-5

## M-4 · 遍历过程中提前中止

- `Sys::FS!walk` 现在携带计数，超过 `max-entries` 立即抛
  `X::Rakuish::Limit`，不再先物化整棵树。
- `Sys::FS!rm-plan` 同样在递归规划时计数并提前中止；`rm -r` 不再无界遍历。
- `t/01` 新增 `rm -r` 超限用例。

## M-5 · mv 跨设备回退检查结果

- `mv` 在 rename 失败后的 cp/rm 回退不再丢弃 `Result`。
- `cp` 失败返回 `ok=False`，错误包含“跨设备复制失败”。
- 复制成功但删除源失败返回 `ok=False`，错误包含“复制成功但删除源失败”。
- 不再出现“目标已复制、源仍在”却报成功。

## 验证

```bash
prove6 -Ilib t
bash tools/run-all.sh
zef install . --force-install
```
