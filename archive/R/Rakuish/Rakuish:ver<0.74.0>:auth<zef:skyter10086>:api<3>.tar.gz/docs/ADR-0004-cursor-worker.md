# ADR-0004：流式查询 Cursor 与连接级 worker 硬取消（0.67.0）

- **日期**：2026-11-11
- **状态**：Accepted（0.67.0 实现）
- **影响范围**：`Rakuish::Data::Cursor`（新）、`Data::Engine` 角色 + DuckDB/SQLite 适配器、
  `Rakuish::Agent::Worker`（新）、`Agent::Server`、`bin/rakuish-agent`、SPEC §6/§8、ROADMAP
- **前置**：[ADR-0002](ADR-0002-agent-serve.md)、`SPEC.md` V-148 / V-152 / V-505

---

## 1. 背景

`ROADMAP` 在 0.67 留了两个候选，都是 0.63 / 0.64 明确没有解决、且写进文档的
「诚实边界」：

1. **Table 仍物化**：0.64 的 `Engine.query(:max-rows)` 是 LIMIT 下推，
   `Table.batches` 是「已物化 Table 的分批视图」，两者都不等于惰性查询执行。
2. **Agent 超时不是 OS 级硬取消**：0.63 的 `start {}` + deadline 保证响应及时、
   结果丢弃，但 Raku 线程无法强杀，卡住的纯文件 I/O 仍会在后台跑完。

本 ADR 分别给出可落地方案，并明确各自**不承诺**什么。

## 2. 驱动能力实测（决策依据，不是想象）

| 驱动 | 逐行 / 流式能力 | 结论 |
|---|---|---|
| `DB::DuckDB` | `DB.query($sql, :stream)` → `Result.is-streaming == True`；`.chunks` 惰性产出 `Chunk`，驱动「一次只持有一个 chunk，峰值内存与结果大小无关」；`Chunk.to-rows` 可转行 | **真流式**，用 `:stream` + `chunks` |
| `DB::SQLite` | `Result.hash` 逐行（`sqlite3_step`），耗尽返回空 | **真流式**，用 `.hash` 循环 |
| 两驱动 | 非 streaming 的 `.hashes` 会一次物化 | Cursor 不复用 `.hashes` |

`Proc::Async.new(..., :w)` 双向 JSONL 管道 + `.kill` 在 Windows 本机实测可用
（stdin 写、stdout 逐行读、kill 后 `start` Promise 变 Kept）。

## 3. 决策一：Cursor 是「惰性拉取」，不是「分页 SQL」

- 新增 `Rakuish::Data::Cursor`：`next-batch` / `batches` / `rows` / `take` / `close`；
  持有驱动结果对象与显式释放回调，**只有被拉取时才向驱动要下一批行**。
- `Engine.cursor($sql, *@params, :$batch-size, :$max-rows)` 进角色契约；
  不支持的引擎抛 `X::Rakuish::Unsupported`，**不静默退化成 `query()` 物化**。
- DuckDB 走 `:stream` + `chunks`，SQLite 走 `.hash` 循环；两者都复用
  `!read-query` 只读判据、`X::Rakuish::Data` 错误包装、`LIMIT ?` 下推。
- Cursor 是**一次性、单连接**对象：`close` 幂等，提前退出即释放驱动结果。
- **不承诺**：跨连接可恢复游标 / 事务一致性快照 / 并发修改下的稳定视图。
  这些需要数据库原生可滚动游标与事务隔离，当前驱动接口不提供。
- **不改变** `Engine.query()`：默认路径行为与 0.64 完全一致，避免回归。

## 4. 决策二：连接级常驻 worker，而不是按请求 fork

ADR-0002 §2 否决「每请求 fork」的理由（每请求付一次 Rakudo 启动 + precomp、
Sandbox/Engine 序列化、审计并发追加）依然成立。0.67 采纳的是**按连接 fork 一次**：

```text
TCP client ──JSONL──> supervisor（父进程，持 Sandbox / 审计 / accept loop）
                          │ 每连接启动一个常驻 worker 子进程
                          └──stdin JSONL──> worker（Agent.handle-line）
                          <──stdout JSONL─┘
```

- `--worker` **默认关闭**，且必须与 `--mode tcp --serve` 同时给出；不开时
  `serve()` 走 0.63 原路径，一字不改。
- 配置（含 token）通过子进程的 **stdin 第一行**传入，不进命令行参数
  （避免出现在进程列表里）。子进程模式 `--worker-child` 只从 stdin 读配置 +
  请求，启动信息不写 stdout。
- 子进程常驻处理该连接的所有请求，**一次连接只付一次 Rakudo 启动成本**。
- **硬取消的触发点**：子进程 `Agent.handle` 在 deadline 到点返回 504（0.63 逻辑），
  父进程识别 `code == 504` 后立刻 `kill` 整个 worker 进程 —— 这样卡在
  不可取消文件 I/O 里的后台线程随进程一起消失，而不只是「响应提前」。
  若子进程连 504 都没返回（死锁 / 驱动卡死），父进程自己的 watchdog
  超时后同样 kill 并回 504。
- **审计集中在父进程**：子进程 Sandbox 不带 `audit-log`（不落盘），父进程按
  请求/响应统一写 `op/path/argv/ok/code/err/stage`；避免多进程并发追加同一文件。
  `stage` 从响应 code 推断（`401→auth`、`403→policy`、`504→timeout`、其余 `op`）。
- **不承诺**：
  - 超时后连接继续可用 —— worker 已被杀，**该连接随即关闭**，客户端需重连；
    0.63 非 worker 模式仍保持「响应及时 + 连接可用」。这是硬取消的代价。
  - 杀掉 worker 派生出的孙进程（例如 `exec` 启动的子进程）。没有 job object /
    进程组管理，OS 级隔离边界是 **worker 进程本身**。
  - 跨连接的会话状态、Engine 缓存共享；每个 worker 独立 Sys / Sandbox / Engine。

## 5. 不变的安全契约

`eval` 不开放；`exec` / `sql_query` 默认关闭；显式 `--root`；只绑 `127.0.0.1`；
token 认证；白名单 canonical 匹配；请求级 env 不覆盖 PATH；审计不含 token /
文件内容 / SQL 原文；worker 模式不新增任何 op，也不放宽 Sandbox 上限。
`sql_query` 仍走 `query().limit(max-rows)`，**不**暴露 Cursor 给 Agent
（流式对象无法安全序列化进 JSONL 响应）。

## 6. 备选与否决

| 方案 | 否决原因 |
|---|---|
| 用 LIMIT/OFFSET 分页模拟 Cursor | 重复查询、并发修改会重复/漏行，且不是驱动级流式；实测两驱动都有真流式接口，没必要 |
| Cursor 对象直接暴露为 Agent op | 跨进程不可序列化，且给 Agent 开了绕过 `max-rows` 的新面 |
| 每请求 fork worker | ADR-0002 §2 的成本论证仍成立 |
| 线程池 + `Thread.kill` | Raku 没有可安全强杀线程的 API；这正是 0.63 的缺口 |
| worker 与父进程共享审计文件 | 多进程并发追加 + Windows 文件锁，日志可能交错 |

## 7. 验收

- `t/20-data-cursor.t`：惰性（提前退出不读完）、分批、上限、close 幂等、
  只读 / 错误包装、DuckDB streaming + SQLite 逐行两后端、未安装驱动时 skip。
- `t/21-agent-worker.t`：真实子进程 + 真实 TCP 的正常请求、504 后 worker 被 kill
  且连接关闭、新连接不受影响、默认关闭、配置不落命令行、审计字段脱敏。
- 两个可选驱动缺失时测试 skip，核心安装不被 NativeCall 依赖拖住。
