# 0.72.1 修复记录

- **日期**：2026-11-12
- **对象**：`main` @ 0.72.1
- **问题**：Windows REPL 下 `cp *.mp4 F:/迅雷下载/` 报
  `路径越出 root: F:/... (root=C:\)`

## 根因

POSIX 的 `root=/` 表示整个文件系统；Windows 的 `C:\` 只是 **C 盘根**，
不是“所有盘符的根”。REPL 默认 root 设为 `C:\`，于是 F: 被当成 root 外。

## 修复

- `Rakuish::Sys` 增加 `all-drives`（默认 `False`）。
- REPL / 脚本默认构造在 Windows 打开 `all-drives`，允许 `D:/`、`F:/`；
  语义等同 POSIX `root=/`。
- Agent / 显式 `Sys.new` 默认不打开，跨盘仍被 root 拒绝。
- `all-drives` 时跳过逐段 symlink root 校验（因为 root 已是全盘）；
  这不是 OS 隔离，Agent 不应打开。
- `t/02` 在 Windows 有 F: 时验证：REPL 风格跨盘放行、默认构造跨盘拒绝。

## 验证

```bash
prove6 -Ilib t
bash tools/run-all.sh
zef install . --force-install
```
