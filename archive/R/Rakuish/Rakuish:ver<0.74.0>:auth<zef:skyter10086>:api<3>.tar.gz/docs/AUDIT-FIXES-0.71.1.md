# 0.71.1 审计修复记录

- **日期**：2026-11-12
- **对象**：`main` @ 0.71.1（基于 0.71.0 / `12841b2`）
- **范围**：独立审计报告的高优先级 H-1 / H-2 / H-3；H-4b 的安全冒烟
- **验证**：Windows `prove6 -Ilib t`；Linux `tools/run-all.sh`

## H-1 · root=`/` 的 symlink 误拒

- 修正 `Sys!assert-in-root`：`/` 不再被 chop 成空串；根路径前缀使用 `/` 而非 `//`。
- 修正 `Sys!assert-links-in-root`：同样使用根路径前缀。
- 新增 `t/01` 用例：Linux 下 `root=/` 读取 `/bin/ls` 必须通过。
- WSL 验证 `/bin -> /usr/bin` 的路径可通过。

## H-2 · SQLite 只读 schema/describe 与误拒

- 只读 SQLite 连接建立后执行 `PRAGMA query_only = ON`，不只依赖词法黑名单。
- `schema()` 使用的 `pragma table_info` 属于允许的只读元数据 pragma。
- 新增 SQL 代码提取：判定前去掉注释与字符串字面量，避免
  `select 'copy' as x`、`select 1 /* drop */` 被误拒。
- 新增只读文件库用例：`schema('meta')` / `describe('meta')` 均可用。
- 新增只读查询误拒回归。

## H-3 · Agent `sql_query` 的 LIMIT 下推

- `Agent.sql_query` 现在把 `:max-rows($!sandbox.max-rows)` 传给 Engine。
- DuckDB/SQLite 包装 SQL 前 trim 尾部 `;`，避免
  `select * from (select 1;) ...` 的 Parser Error。
- `FakeEngine` 同步接受 `:max-rows`；Agent 测试改为验证引擎侧截断。
- README/SPEC/MANUAL 统一为“Engine `query(:max-rows)` 下推 LIMIT”。

## H-4b · `enable_external_access=false` 冒烟

- `t/12` 新增：默认 `safe` DuckDB 查询 `read_csv_auto(<path>)` 必须失败。
- 该用例锁定 Raku 驱动应用 session option，而不是只相信文档。

## 未包含

以下仍按审计报告保留为后续任务：

- H-4 504 的 at-least-once 语义 / 幂等键
- N-1 exec 绕过 root（已接受的文件策略边界）
- M-1 旧 env 合并、M-2 audit 锁、M-3 worker LEAVE
- M-4/M-5 限额与 mv Result
- `v/` 归档、测试残留、文档真值收敛、CI

## 验证命令

```bash
prove6 -Ilib t
bash tools/run-all.sh
zef install . --force-install
```
