# Rakuish 数据引擎设计（DuckDB / SQLite / Table）

- **日期**：2026-11-11
- **当前版本**：`0.74.0`
- **问题**：数据化 / 结构化层能否用 SQLite 或 DuckDB？以后想做成类似 IPython 的数据环境，应该怎么设计？
- **结论**：**能，而且应该用；但 DuckDB 当分析引擎，SQLite 只在需要事务型应用状态时用；不要让 SQL 绕过 Sandbox。**
- **参考**：
  - [Nushell Cheat Sheet](https://www.nushell.sh/book/cheat_sheet.html)
  - [Nushell: Coming from Bash](https://www.nushell.sh/book/coming_from_bash.html)
  - [Elvish: Scripting case studies](https://elv.sh/learn/scripting-case-studies.html)
  - [DuckDB Safe Mode](https://duckdb.org/docs/1.4/clients/cli/safe_mode)
  - [Securing DuckDB](https://duckdb.org/docs/1.4/operations_manual/securing_duckdb/overview)
  - [DB::DuckDB](https://gitee.com/skyter10086/DB-DuckDB)、[Alien::Libduckdb](https://raku.land/zef:skyter10086/Alien::Libduckdb)

> **0.40–0.69 已落地**：`Data::Engine` 角色 + DuckDB/SQLite 适配器；默认只读、
> DuckDB 默认 `enable_external_access=false`；`open-db`、事务、查询超时、`_`/`Out`、
> Agent `sql_query` 和 `explore` 均已实现；0.64 加了 Parquet 读写（显式授权）、
> `LIMIT` 下推 / `batches` / 渲染上限与统一错误模型；0.67 加了真正的流式
> `Engine.cursor()`（DuckDB `:stream` / SQLite 逐行）、连接级 worker 硬取消
> （[ADR-0004](ADR-0004-cursor-worker.md)）；0.68 把 CSV 纳入同一套显式外部
> 访问模型并接入 SQL 上下文补全（[ADR-0005](ADR-0005-data-workbench.md)）；
> 0.69 加了 CSV 方言白名单、`describe()` 值 API 与补全启发式增强
> （[ADR-0006](ADR-0006-data-profile.md)）。
> `Table` 本身仍是物化值（惰性查询走 `cursor()`）；可恢复 / 事务一致性游标与
> SQL AST 级补全明确不做。

---

## 1. 先给结论

### 推荐组合

| 层 | 选择 | 理由 |
|---|---|---|
| 小数据 / 当前工作集 | `Rakuish::Data::Table`（内存） | 零依赖、可 `.where/.get/.select`，适合 REPL 少量数据 |
| 分析 / 大表 / Parquet / CSV | **DuckDB** | 列存、向量化、直接扫 CSV/JSON/Parquet、SQL 聚合/窗口/join |
| 应用元数据 / 事务状态 | **SQLite**（可选） | 单文件、ACID、并发读、小写入；适合 catalog/history/config |
| 交换格式 | JSON / CSV / Parquet | 不把数据库当唯一格式 |

### 不要做的事

- 不要把所有数据都塞进 SQLite：它是行存 B-tree，不是分析引擎。
- 不要用 DuckDB 做高并发 OLTP 写入：它更适合批量/分析型写入。
- **不要让 SQL 直接读文件**：`read_csv('/etc/passwd')`、`ATTACH`、`INSTALL/LOAD` 能绕过 `Sys` 的 root/Sandbox。
- 不要把 SQL 字符串拼进 Agent 请求；Agent 不开放任意 SQL。

---

## 2. SQLite 与 DuckDB 的定位

| 维度 | SQLite | DuckDB |
|---|---|---|
| 存储模型 | 行存 B-tree | 列存、vectorized |
| 强项 | 事务、CRUD、小数据、单文件、并发读 | 扫描、聚合、join、窗口、Parquet/CSV |
| 弱项 | 大表分析慢 | 高并发写弱，单写者模型 |
| 进程 | 嵌入式 | 嵌入式 |
| 典型用途 | 应用配置、catalog、审计、队列 | 数据探索、ETL、分析、DataFrame 后端 |
| 安全面 | `ATTACH`、`load_extension`、`readfile/writefile` | `ATTACH`、`INSTALL/LOAD`、`read_csv/parquet/json`、外部访问 |
| Raku 接口 | DBIish + DBD::SQLite（可选） | `DB::DuckDB`（已有，`DB` 接口） |

### 建议

1. **0.40 先接 DuckDB**，因为你的目标是“数据处理环境”，DuckDB 的收益最大。
2. SQLite 等到需要“持久化 catalog / 事务型 app state”时再加，不要一开始双引擎。
3. 两者都实现同一个 `Rakuish::Data::Engine` 角色，上层不感知具体数据库。

---

## 3. 分层架构

```text
REPL / DSL / Agent
        │
        ▼
Rakuish::Data::Table        ← 统一值（行 Hash + 列类型）
        │
        ▼
Rakuish::Data::Engine       ← 角色：query/execute/tables/schema/load/save/tx
        │
        ├── Engine::DuckDB  ← DB::DuckDB / Duckie（可选依赖）
        └── Engine::SQLite  ← DBIish + DBD::SQLite（可选依赖）
```

### 核心原则

1. **`Table` 是交换格式**：查询结果、CSV、JSON、`ls` 都转成 Table。
2. **Engine 只做数据库，不碰文件系统**：文件路径由 `Sys` 校验后再交给 engine。
3. **SQL 是能力，不是文本命令**：参数化、限额、只读/读写模式显式。
4. **数据库连接是 Session 级资源**：随 Session 创建/关闭，不全局。
5. **Agent 与人类 REPL 权限不同**：人类可交互 SQL；Agent 默认只读、结构化、无外部访问。

---

## 4. Engine API 草案

```raku
role Rakuish::Data::Engine {
    method query(Str $sql, *@params --> Rakuish::Data::Table) { ... }
    method execute(Str $sql, *@params --> Int) { ... }
    method tables(--> Rakuish::Data::Table) { ... }
    method schema(Str $table --> Rakuish::Data::Table) { ... }
    method load(Str $path, Str :$table, Str :$format) { ... }
    method save(Str $path, Str $sql, Str :$format) { ... }
    method begin/commit/rollback { ... }
    method close(--> Nil) { ... }
}
```

### DuckDB 实现

```raku
use DB::DuckDB;

my $db = Rakuish::Data::Engine::DuckDB.new(
    :path<work.duckdb>,       # 或 :memory:
    :read-only(False),
    :threads(4),
    :memory-limit<2GB>,
);

my $t = $db.query('select region, sum(amount) s from sales group by region');
$t.sort-by('s', :reverse).to-text;

$db.execute('insert into sales values (?, ?, ?)', 'east', '2026-11-11', 42.5);
$db.load('sales.csv', :table<sales>);
$db.save('sales.parquet', 'select * from sales');
```

`DB::DuckDB` 已经提供 `query` / `execute` / `insert-rows` / `appender` / `read-parquet`，
不需要自己写 NativeCall；把 `DB::Result.hashes` / `.columns` 转成 `Table` 即可。

### SQLite 实现

```raku
use DBIish;

my $dbh = DBIish.connect('SQLite', :database<app.db>);
my $sth = $dbh.prepare('select * from runs where id = ?');
$sth.execute($id);
```

先做只读/小表；不要用它跑大分析。

---

## 5. 安全设计（最关键）

> SQL 不是“查询字符串”，它是**可执行代码 + 文件访问能力**。  
> 如果 Agent 能发 SQL，`Sys` 的 root、allowlist、审计都可能被绕过。

### 人类 REPL

- 可读写；默认 `work.duckdb` 或 `:memory:`。
- 打开数据库路径必须过 `Sys.resolve`。
- 可显式 `--allow-external` 才允许 DuckDB 读 CSV/Parquet 外部文件。
- 默认 `enable_external_access=false`，需要导入文件时用 Rakuish 的 `load`（经 `Sys` 校验）。

### Agent

**默认不开放任意 SQL。** 如果以后开放：

1. 只允许 `sql_query` 结构化 op，不允许 `sql_exec` DDL/DML。
2. **只读连接**。
3. 只允许查询已注册的 views/tables，不允许原始表名白名单外访问。
4. 禁止：
   - `ATTACH` / `DETACH`
   - `INSTALL` / `LOAD`
   - `COPY`
   - `read_csv` / `read_parquet` / `read_json` / `read_text`
   - `getenv`
   - 扩展加载
5. 查询超时、最大行数、最大列数、内存上限。
6. 参数化查询，禁止字符串拼接。
7. 审计：SQL 指纹 + 参数摘要（不记录敏感参数）。

DuckDB 的 safe mode 文档明确：`enable_external_access=false` 会让 `ATTACH`、`COPY`、
`read_csv/parquet/json` 等不能访问外部文件；嵌入式使用也要显式设置并锁定配置。
参考：[DuckDB Safe Mode](https://duckdb.org/docs/1.4/clients/cli/safe_mode)、
[Securing DuckDB](https://duckdb.org/docs/1.4/operations_manual/securing_duckdb/overview)。

SQLite 需要禁止 `ATTACH`、`load_extension`、`readfile`/`writefile`，并使用只读连接。

### 并发与生命周期

- **DuckDB**：一个进程一个数据库实例、单写者；每个 `Rakuish::Sys`/Session 持有一个连接，
  不要跨线程共享同一 connection。写操作串行化，分析查询可以用 `threads` 但连接仍归 Session。
- **SQLite**：建议 WAL + busy timeout；读连接和写连接分开；Agent 会话使用独立 db 文件。
- 连接随 Session 关闭；不建全局连接池，不把 connection 放进 DSL 全局单例。
- 查询超时/取消要在 Engine 层做；DuckDB 的 `interrupt` 和 SQLite 的 `busy_timeout`
  不能只靠 Raku `Promise` 超时（底层 query 仍在跑）。
- 大结果默认有 `max-rows`；Table 物化前先 `limit`，避免 REPL 被一个 `select *` 卡死。

---

## 5.1 Table 与 SQL 的分工

- **小于几万行、交互式组合**：`Table.where/get/select/sort-by`，不写 SQL。
- **大表、join、聚合、Parquet/CSV 扫描**：交给 DuckDB SQL，结果回 `Table`。
- 不自动把 Raku 表达式编译成 SQL（第一版不做 ORM/查询生成器）；
  需要 SQL 时显式 `$db.query`，这样执行计划和权限都清楚。
- 后续可加 `DataFrame` 作为 lazy 层，但 `Table` 仍是结果交换格式。

---

## 6. IPython 式数据环境

目标不是“再做一个 SQL CLI”，而是：

```text
> my $sales = open-data('sales.csv')
> $sales.where({ .<amount> > 100 }).select('region', 'amount').first(10)
> my $db = open-db('work.duckdb')
> $db.load('sales.csv', :table<sales>)
> $db.query('select region, sum(amount) s from sales group by region').sort-by('s')
> $db.schema('sales')
> $db.save('sales.parquet', 'select * from sales')
```

### 关键体验

| 能力 | 设计 |
|---|---|
| 变量 | 用 Raku `my`，已有跨格持久化 |
| 结果 | 查询返回 `Table`，REPL 自动表格渲染 |
| 上次结果 | `_` / `Out[n]`（已实现 0.52） |
| 帮助 | `help db` / `$db.schema` / `?` 命令 |
| 自动补全 | 表名、列名、SQL 关键字（基于 engine 元数据） |
| SQL 执行 | 优先 `$db.query(...)`，不做 bash 管道 |
| 数据预览 | `head` / `tail` / `describe` / `tables` |
| 导入导出 | `load` / `save`，格式由扩展名决定 |
| 事务 | `$db.begin/commit/rollback` |
| 计时 | 已有 `timed` / `elapsed` |
| 可视化 | 后续 Table → Markdown/HTML/图像，不在核心 |

### 是否要 `%sql` magic？

不建议一开始做 `%sql`。IPython 的 `%sql` 是文本魔法；Rakuish 的优势是值。
更自然的形态：

```raku
my $t = $db.query: q:to/SQL/;
    select region, sum(amount) as total
    from sales
    where year = 2026
    group by region
    order by total desc
SQL
```

如果以后要更短，可加 `sql` 命令/宏，但仍返回 `Table`，不进入第二套语言。

---

## 7. Table 的升级

当前 `Table` 只有 columns/rows；接数据库前要补：

- `schema` / `column-types`：DuckDB 类型映射。
- nullable 值：`Nil`/`Any` 的明确表示。
- 大结果：`Cursor` / lazy `ResultSet`，先 `limit` 再物化。
- `to-parquet` / `to-csv` / `to-json`。
- `Table.from-result($db-result)`。
- 错误：SQL 错误 → `X::Rakuish::Data`，不泄漏连接字符串。

---

## 8. 依赖策略

**核心不强制安装 DuckDB。**

- 核心：JSON::Fast、Terminal::LineEditor。
- 可选：`Rakuish::Data::Engine::DuckDB`，依赖 `DB::DuckDB` / `Alien::Libduckdb`。
- 可选：`Rakuish::Data::Engine::SQLite`，依赖 `DBIish` + `DBD::SQLite`。
- 用 `require` 懒加载；没装时给出明确安装提示，不让 `rakuish` 启动失败。

这符合“核心稳定、能力按需”的原则。

---

## 9. 实施状态与下一步

### 已完成（0.40–0.64）

- `Data::Engine` 角色 + DuckDB/SQLite 适配器；
- 默认只读、SQLite 参数化、单连接、事务；
- `open-db`、`query/execute/tables/schema/close`；
- DuckDB `max_execution_time` 与 SQLite `sqlite3_interrupt` 查询超时；
- `_` / `Out[n]`、Table schema/types、`explore` 分页；
- Agent `sql_query`（只读、参数化、行数上限、审计指纹）；
- 0.64：`open-data` / `save-data` 的 `.parquet` / `.pq`（`:allow-external` +
  `Sys.resolve`，Agent 不开放）；Engine `read-parquet` / `write-parquet`；
- 0.64：`query(:max-rows)` LIMIT 下推、`Table.batches` 惰性分批、
  渲染 `:max-rows` 上限；SQL 驱动错误统一为 `X::Rakuish::Data`；
- 0.67：`Data::Cursor` —— DuckDB `:stream` + `chunks`、SQLite `Result.hash`
  逐行；`batches` / `rows` / `take` / `close`，只有被拉取才推进查询；
  显式 Iterator 而非嵌套 `gather`（跨帧 continuation 会崩）。

- 0.68：`open-data` / `save-data` 的 `.csv` 在显式 `:allow-external` 时走
  DuckDB `read_csv_auto` / `COPY FORMAT CSV`，与 Parquet 共用 `export-table`
  导出流程；默认文本路径不变（V-160）。`REPL::SqlComplete` 读 `tables()` /
  `schema()` 补关键字 / 表名 / 列名（V-161）。
- 0.69：`Data::CsvOptions` 白名单（读路径 `?` 绑定、写路径校验过的字面量）；
  `Table.describe` 与角色默认 `Engine.describe` 统一列集合；`SqlComplete`
  支持别名 / 表前缀列 / 大小写风格；Session 改 `need Rakuish::Data` 修掉
  REPL 同名导出覆盖（V-162…165 / ADR-0006）。

### 下一步

1. ✅ ~~真正的流式 Cursor~~：0.67 已交付（见上）。`Table` 与 `query()`
   仍保持物化，调用方按需改用 `cursor()`。
2. ✅ ~~可取消 worker~~：0.67 的 `--worker` 连接级子进程已提供 OS 硬取消
   （ADR-0004 §4）；默认关闭，非 worker 模式仍是 0.63 的「响应及时 + 结果丢弃」。
3. ✅ ~~表名/列名补全~~：0.68 已交付（V-161），基于 Engine 元数据。
4. ✅ ~~CSV 的受控外部读取~~：0.68 已交付（V-160），与 Parquet 共用授权。
5. **可恢复 / 事务一致性游标**：**不做**（ADR-0005 §4）—— 驱动不暴露可滚动
   游标或 CHECKPOINT，OFFSET 模拟会重复 / 漏行。
6. ✅ ~~CSV 方言参数~~：0.69 已交付 7 项白名单（V-162）；编码 / 多行字段
   精细控制仍不做，方言只在 Raku 层。
7. **SQL AST 级补全**：**不做**（ADR-0006 §4）—— 不引解析器依赖，启发式
   别名 / 前缀列已覆盖主要场景。
8. **可恢复 / 事务一致性游标**：**不做**（同上）。

---

## 10. 一句话建议

**DuckDB 作为 Rakuish 的数据分析引擎，SQLite 只作为可选的事务型应用状态库；`Table` 保持为统一交换层；SQL 必须走独立的 Engine 能力，并默认对 Agent 关闭外部访问。**

这比“在 REPL 里再加一堆 grep/ls 参数”更关键，也是 Rakuish 从 shell 走向数据环境的分水岭。
