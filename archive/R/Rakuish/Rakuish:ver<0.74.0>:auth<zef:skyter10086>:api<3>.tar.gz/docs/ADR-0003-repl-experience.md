# ADR-0003：REPL 交互体验（Vi/Helix 模式、hints、插件）

- **日期**：2026-11-11
- **版本**：0.66.0
- **状态**：已实现
- **相关**：[ADR-0001](ADR-0001-raku-native.md)、[ROADMAP](ROADMAP-2026-11-11.md) P3、
  [SPEC](../SPEC.md) V-154 / V-155 / V-156

## 1. 背景

ROADMAP 的 0.66 是「Vi/Helix 编辑模式、hints、状态行、插件/命令市场」。
状态行（时间 / cwd / git 分支 / 格号 / 上格耗时）已在 0.62 交付，本 ADR 只处理
剩下三块。约束沿用 ADR-0001 与 HANDOFF §7：

- 不引入第二套语法 / 配置语言；
- 所有文件与进程操作只经会话级 `Sys`；
- 默认拒绝：新能力默认不改变既有行为，Agent 侧不自动获得；
- 不为了「像 shell」恢复 `%magic` 或 auto-shell。

## 2. 行编辑器的能力边界（实测）

`Terminal::LineEditor::CLIInput` 0.0.23：

- `%!keymap` 是「解码后的键名 → edit action 字符串」，`bind-key($key, $action)`
  只接受 `special-actions()` 里的名字或 `input-class.^can("edit-$action")`；
- `read-input` 的 dispatch 是硬编码 `when` 链，末端 `default { self.do-edit($_) }`，
  **没有自定义回调 hook**，也没有 hint / 模式切换回调；
- `decode-keyname` 对可打印字符返回 `Nil`（直接插入），对 ESC（0x1B）返回 `Ctrl-[`；
- `do-edit($action)` 在 input-field 上调 `"edit-$action"()`，返回 Bool 交给
  `refresh-string`。

结论：**不能靠 `bind-key` 一个调用就实现模态**，但可以子类化并覆盖三个方法，
不复制 `read-input`、不 fork 依赖。

## 3. 决策

### 3.1 Vi/Helix 模式：子类化 + 会话级语义层

1. `Rakuish::REPL::Keymap` 提供 `ViState`（模式 `insert` / `normal` / `select`、
   缓冲、光标、撤销、yank）作为**纯逻辑语义层**：可单测、可被任何宿主前端复用，
   也支持脚本化编辑（`repl.vi`）。
2. 交互前端 `ViCLIInput is Terminal::LineEditor::CLIInput`：
   - 覆盖 `decode-keyname`：normal 模式下把可打印字符映射成 `vi-<char>` 键名，
     未绑定的字符被吞掉（不插入）；insert 模式保持父类行为；
   - 覆盖 `special-actions` / `input-class`：新增 `vi-insert`、`vi-append`、
     `vi-open`、`vi-normal` 等少数 action，由 input-field 子类的 `edit-vi-*`
     切换共享 `ViState` 并返回 `False`（不改缓冲、只重绘）；
   - 其余 `vi-h / vi-l / vi-0 / vi-$ / vi-w / vi-b / vi-x / vi-u / vi-D` 直接绑到
     依赖已有的 edit action，`dd` 用一次 pending `d` 状态实现；
   - `prompt()` 覆盖：每行按 `vi-start` 配置重置模式。
3. `emacs`（默认）/ `vi` / `helix` 三套预设：`emacs` 完全不碰 keymap；`vi` / `helix`
   除模态外还重绑 `Alt-*` 到已有 edit action，作为「非模态也能用的 Vi 风味键位」。
4. **构造失败自动回退**：`ViCLIInput.new` 用 `try` 包住，异常时退回原
   `CLIInput` + `apply-keymap`（只绑合法 action），不阻塞 REPL。

被否方案：自己写 raw-mode 前端（要重写历史 / 补全 / 光标，跨平台成本高）；
给依赖打补丁或复制 `read-input`（升级即碎）。

### 3.2 hints：上下文提示层，不做输入中弹窗

依赖没有「输入变化」回调，所以 hints 定义为**一格结束时对下一格的提示**：

- `hints.hint-for($line, :$shell, :$registry)`：已知 Shell 命令给 usage 首行、
  registry 命令给 `spec.summary` 与参数名、`!` 给 argv 说明、`--xxx` 给启动参数提示；
- `hints.result-hint($r, $line)`：失败格给下一步建议（未声明例程、127、
  Parquet 外部访问等）；
- TTY 且 `config hints on` 时在 prompt 前打印一行暗灰提示；**管道 / 非 TTY 完全不输出**
  （V-116 不被破坏）；
- `config set hints off` 或 `hint()` 命令可关闭 / 手动查询。

被否方案：把 hint 塞进 Tab 补全返回列表（会污染补全项）；往 `$*ERR` 打实时提示
（污染输出且不可测）。

### 3.3 插件：显式本地 Raku 文件 → Command 对象

1. 插件就是一个 Raku 文件，最后一个表达式求值为 `Command` 对象或 `List[Command]`
   （`BuiltinCommand` / `ExternalCommand` / 自定义 `does Command`）。文件里可以
   `use` 自己的模块；**插件即 Raku，不引入第二套语法**。
2. `plugin load <path>`：
   - 必须 `config set plugins on`（默认 **off**）；
   - 路径先经 `$sys.resolve`（root 沙箱校验），源码经 `$sys.read`；
   - `EVAL` 源码得到 Command 对象，`registry.register(...)` 注册；
   - 记录来源 / 命令名，`plugin unload <name>` 只移除该插件注册的命令，
     **不能删内建命令**；`plugin list` / `plugin info` 查询。
3. **加载即执行本地 Raku 代码**，安全等级等同 `use` 一个本地模块：
   只加载你信任的文件。不自动扫描目录、不联网、不持久化、不写启动项。
4. Agent 的 op 白名单**不暴露** `plugin`，`Sandbox` 也不加载插件；插件的
   `run($sys, ...)` 拿到的是同一个会话 `Sys`，必须用它做文件 / 进程操作。
5. 插件命令进 `registry.names` / `help()` / `cmd('name', ...)`，但**不进 Shell
   薄层的文本命令表**（避免两套语义漂移，HANDOFF §5.2）。

被否方案：JSON/YAML 描述插件（等于第二套配置语言）；从 Gitee / zef 自动安装
（供应链风险，超出本地工具定位）；允许插件注册任意文本命令（两套语法）。

## 4. 诚实边界

- 本机（Windows / Git Bash）`winpty` 无法起真 TTY，**模态输入的光标行为未做
  端到端验证**；已验证的是：子类可构造、`bind-key` 全部合法、
  `decode-keyname` 在两种模式下的映射、模式切换的纯逻辑。用户实际开一次 REPL
  最准；`config set edit-mode emacs` 可随时退回。
- 子类化依赖 `Terminal::LineEditor` 0.0.23 的内部结构（`edit-*` 命名、
  `special-actions`、`decode-keyname`）。升级若不兼容，构造会失败并自动回退到
  `emacs` 预设，不会让 REPL 崩溃。
- 插件代码拥有完整 Raku 能力，可以绕过 `Sys`；这是「本地可信代码」的显式授权，
  不是沙箱。文档必须写明，不能把插件说成安全隔离。
- Vi 语义层是单行 buffer 的编辑模型：不做多行 buffer、不做可视块、不做 `.` 重复、
  不做寄存器命名。`j` / `k` 映射到历史上下格（单行 REPL 的合理映射）。

## 5. 验收

- `t/19-repl-experience.t`：ViState 语义、键位预设合法性、子类构造与回退、
  hints 正反断言、插件默认拒绝 / root 越界 / 注册 / 卸载 / Agent 白名单、
  Chrome 新参数、管道无 ANSI。
- `prove6 -Ilib t` 全绿；版本 `0.66.0` 同步 META6 / 两个入口 / 文档五联。
