# ADR-0006：CSV 方言、describe 值 API 与补全启发式（0.69.0）

- **状态**：已接受（2026-11-11）
- **后续**：`0.69.1` 是 patch（修复失败格的 stderr 警告，SPEC V-166），
  不改变本 ADR 的任何决策。
- **前置**：[ADR-0005](ADR-0005-data-workbench.md)（CSV 受控外部读写 / SQL 上下文补全）、
  [ADR-0004](ADR-0004-cursor-worker.md)、[SPEC.md](../SPEC.md) V-152 / V-160 / V-161
- **影响面**：`Rakuish::Data::CsvOptions`（新）、`Data`、`Data::Engine` 角色与
  DuckDB 适配器、`Data::Table`、`DSL`、`REPL::Session`、`REPL::Shell`、
  `REPL::Hints`、`REPL::SqlComplete`、入口 `--help`

---

## 1. 背景

`ROADMAP-2026-11-11.md` §3 把 0.69 列为三个未排期候选：

1. CSV 方言参数（`0.68` 只交付了 `read_csv_auto` 的默认方言）；
2. SQL AST 级补全（`0.68` 交付的是启发式字符串上下文补全）；
3. 基于元数据的 `describe` 值 API。

实测（`tmp/probe-dialect69*.raku`，DuckDB 驱动）确认：

- `read_csv_auto(?, delim => ?, quote => ?, escape => ?, header => ?, skip => ?,
  all_varchar => ?, nullstr => ?)` 全部命名参数可**参数绑定**，不会把值拼进 SQL；
- `COPY ... (FORMAT CSV, HEADER, DELIMITER ';', QUOTE '"', ESCAPE '"', NULL 'NA')`
  可用，但 COPY 选项**不支持参数绑定**，只能放字面量；
- `DESCRIBE SELECT ...` 与 `count(*) / count("c") / count(distinct "c")` 聚合可用。

## 2. 决策一：CSV 方言参数，白名单 + 绑定优先

**新增纯函数模块 `Rakuish::Data::CsvOptions`**，把「用户选项」翻译成 DuckDB 选项：

| Raku 键 | DuckDB 选项 | 类型 | 读 | 写 |
|---|---|---|---|---|
| `delimiter` | `delim` | 单字符 Str | ✅ 绑定 | ✅ 字面量 |
| `quote` | `quote` | 单字符 Str | ✅ 绑定 | ✅ 字面量 |
| `escape` | `escape` | 单字符 Str | ✅ 绑定 | ✅ 字面量 |
| `nullstr` | `nullstr` / `NULL` | Str（≤64） | ✅ 绑定 | ✅ 字面量 |
| `header` | `header` / `HEADER` | Bool | ✅ 绑定 | ✅ 字面量 |
| `skip` | `skip` | Int 0..100000 | ✅ 绑定 | ❌ 拒绝 |
| `all-varchar` | `all_varchar` | Bool | ✅ 绑定 | ❌ 拒绝 |

约束：

- **未知键明确抛 `X::Rakuish::Unsupported`**，不静默忽略（拼错 `delimeter` 要能发现）；
- 读路径一律 `name => ?` + 参数绑定；写路径的字面量必须先过
  「单个可打印 ASCII 且不含 `' ; \` 换行」或「长度 ≤64 且同类字符过滤」校验；
- `skip` / `all-varchar` 在写路径明确拒绝，而不是假装生效；
- 选项只在 **`:allow-external` 已开启** 时生效；默认 `.csv` 仍完全走
  `Sys.read` / `Sys.write` + Raku 解析器（V-129 不变）；
- **方言参数只在 Raku 层**（`open-data()` / `save-data()` / Engine），
  Shell 薄层 `open --external` 保持原样。与 0.65 glob 完整语法只在
  `Sys.glob()` 层的先例一致：薄层不做第二套参数语法。

Agent 的 `OPS` 白名单不变、不增加任何 op；`open-data` 的 `:allow-external`
仍不在 Agent 侧暴露。V-152 的「外部访问例外」仍只有 Parquet / CSV 两个。

## 3. 决策二：describe 是值 API，不是又一条文本命令

- `Table.describe(:$sample)` 返回 **Table**（`name / type / nullable /
  non_null / distinct / sample`），纯值计算、不碰文件与进程，可继续
  `.where` / `.to-json` / `.sort-by`；
- `Engine.describe(Str $table)` 作为**角色默认实现**：调用契约里的
  `schema()` 与 `query()` 聚合统计（`count(*) / count("c") /
  count(distinct "c")`），因此 DuckDB / SQLite 与任何第三方引擎都自动获得，
  不需要各自实现。表名/列名严格限定 `[A-Za-z_][A-Za-z0-9_.]*` 并加双引号，
  拒绝含引号 / 分号的标识符；单列聚合失败时该列统计留空、整表不失败。
- DSL `describe($value)`：Table → 值方法；Str → 当前会话 Engine 的表摘要；
  其它类型明确 `X::Rakuish::Unsupported`。
- REPL `describe [表名]` 是**会话命令**（与 `hint` / `plugin` / `perf` 同级，
  不是 `%magic`）：无参数取上一格成功值（Table 直接摘要；否则若有 Engine
  列出表清单），有参数走 `Engine.describe`。返回值仍是结构化 Table，
  `render` 按既有 Table 规则显示。

**不做**：`describe` 的文本报告 / 直方图 / 关联分析。这些东西应作为普通 Raku
函数组合，不进 REPL 命令表（避免 0.61 之前的「文本表格替代结构化值」回潮）。

## 4. 决策三：补全继续用启发式，明确不做 SQL AST

`0.68` 的 `SqlComplete` 是纯函数、无依赖，Tab 延迟稳定。`0.69` 增强：

- **表别名映射**：识别 `from sales s` / `join users as u`，
  `s.` 前缀只补 `sales` 的列，返回完整替换行 `s.amount`；
- **关键字大小写跟随输入片段**（`SEL` → `SELECT`，`sel` → `select`），
  不再一律小写；
- 扩展调用名（`read_csv` / `read_parquet` / `query_sql` 等别名）、
  细化 select 列表 / `order by` / `on` 的列上下文；
- 所有 Engine 元数据调用继续包在 `try` 里，驱动异常安静退化。

**明确不做 SQL AST 级补全**，理由：

1. 要真正「AST 级」就得引入 SQL 解析器依赖（DuckDB 与 SQLite 方言不同、
   还各有 `read_csv_auto` / `PRAGMA` 扩展），核心安装会被拖住；自写一个
   半成品解析器只会把启发式错误包装得更难调试；
2. REPL 补全处在按键热路径，解析器构建 AST 的成本与失败模式都不划算；
3. 现有启发式已覆盖表名/列名/关键字的主要场景，0.69 补上别名后收益递减。

因此 `ROADMAP` 里这条从「候选」移到 §5「明确不做」，不再是待办。

## 5. 风险与边界

| 风险 | 处理 |
|---|---|
| COPY 选项只能拼字面量，可能注入 | 白名单 + 字符/长度校验；只允许单字符分隔符与短字符串；不拼表名、不拼用户 SQL |
| `read_csv_auto` 选项拼进 SQL | 一律 `?` 绑定，值不进 SQL 字符串；选项名来自白名单常量 |
| `Engine.describe` 在大表上做 `count(distinct ...)` | 只读 SELECT、可用既有 `max-execution-time-ms` 与 `--sql-timeout-ms` 限制；不承诺大表性能，文档写明 |
| 方言选项破坏 0.68 默认行为 | 空选项时生成的 SQL 与 0.68 完全一致（HEADER 保持），t/22 全量回归守护 |
| `describe` 与 Raku 标识符冲突 | `describe` 不是 Raku 内建；仅整行首词命中会话命令，SQL 字符串内不受影响 |

## 6. 验收

- 新增 `t/24-csv-dialect.t`（选项校验、读写方言往返、未知键拒绝、注入拒绝、
  默认行为不变、Agent 白名单）；
- 新增 `t/25-describe-complete.t`（`Table.describe` 值、`Engine.describe`
  默认实现、DSL / Session 命令、别名/前缀/大小写补全、AST 不做的边界）；
- `prove6 -Ilib t` 全绿；`META6.provides` 与 `lib/` 模块数一致；
- 版本 `0.69.0` 同步 META6 / 两个入口 / README / MANUAL / SPEC /
  ROADMAP / HANDOFF / DESIGN-DATA-ENGINE / 入口 `--help`。
