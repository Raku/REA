# ADR-0009 · `tty-exec` 期间 Ctrl-C 的归属契约与真 PTY 回归

- **日期**：2026-11-13
- **对象**：`main` @ 0.72.2 → 0.72.3
- **状态**：已接受（0.72.3 决策 + 回归，未改产品代码）；0.72.4 订正了
  termios 相关边界并实现快照恢复，见 §0；**§2 D1「不做进程组切换」已于
  0.73.0 被 [ADR-0010](ADR-0010-job-control-feasibility.md) §6 取代**
  （POSIX-only，选项 A 实施），本文其余契约不变
- **输入**：《Rakuish 终端层（TTY / PTY）补齐方案》§2「仍未做」/ §5 阶段 3 /
  §5 测试清单末项；《Rakuish 0.72.1 剩余问题与改进任务书》L3；
  [ADR-0007](ADR-0007-tty-passthrough.md) §3.3、[ADR-0008](ADR-0008-input-interrupt-sql-forms.md) §3.1

## 0. 修订记录（0.72.4，2026-11-13）

本文 §2 D3 / §3 / §5 / §6 原本把「不做 termios 快照」写成已接受的边界，
理由是「PTY 驱动基线是 raw，不可观测；要自己写 NativeCall，跨平台成本高」。
**复核后这两个前提都不成立**：

- `META6.json` 依赖的 `Terminal::LineEditor` 传递依赖 `Terminal::API`，
  后者已封装 Linux / macOS / BSD 三套 `struct termios` CStruct 与 Windows
  `GetConsoleMode` / `SetConsoleMode`，`get-config` / `restore-config` 现成可用；
- 行编辑器 `enter-raw-mode` 是「进 prompt 时保存**当前**状态 → 切 raw →
  退出时恢复」，不是覆盖式设置。子进程把终端改坏后，下一轮 prompt 会把
  **污染态当成新基准**存下来再恢复，污染被固化；
- 「不可观测」只针对 `tools/tty-check.py` 的 raw 基线。改用 canonical 基线
  （显式开 `ICANON|ECHO|ISIG`）的 PTY 驱动即可直接测位图：实测子进程
  `stty raw -echo` 让 `c_lflag` 从 `35387` 掉到 `35376`（关掉
  `ICANON+ECHO+ISIG`），且下一轮 prompt 后仍是 `35376`。

0.72.4 因此**实现**了交接期快照恢复，并新增 `t/31-tty-termios.t` 自动化回归。
本 ADR 保留 0.72.3 的 Ctrl-C 归属契约（V-173）与实测证据，只订正上述错误
结论；新条款见 SPEC **V-174**。

## 1. 背景

`tty-exec`（0.70 / ADR-0007）把当前 TTY 的三条标准流直接交给子进程，
同步等待、无超时。ADR-0007 §3.3 只做了一件事：等待期间用
`signal(SIGINT).tap(-> $ { })` 临时吞掉**父进程**的 SIGINT，让 Ctrl-C
归前台子进程，`LEAVE` 关闭 tap 恢复默认。0.71 / ADR-0008 解决的是另一个
场景——**输入阶段**把行编辑器的 `abort-input` 收敛成「清行、不退出」。

两篇审计文档都把「`tty-exec` 期间 Ctrl-C 的真 PTY 回归」列为仍未做，
并给出验收标准：

> 真 PTY 下：`! --tty` 期间 Ctrl-C → 子进程退出、REPL 存活且可继续输入、
> 终端回到可输入状态。

0.72.2 交付时复核过：`tty-check.py` 的 Ctrl-C 检查只覆盖 0.71 的输入中断，
`t/26` 的 4 条真 PTY 断言只覆盖首字符不丢 / 正常退出 / 退出码回传。
**契约没有被任何断言钉住**——这正是本版要补的。

## 2. 决策

### D1：维持「不做进程组切换」的否决

> **⚠ 0.73.0 起本决策已失效。** 可行性评估（ADR-0010）证明可以只换
> `tty-exec` 的 spawn 路径（`posix_spawnp` + `SETPGROUP` + `tcsetpgrp`）
> 而不碰 shell 语法，用户选了选项 A 并实施（V-175）。下文保留为当时的
> 决策记录；D2 的「用 `\x03` 模拟」也被 0.73.0 的真终端路径取代。

不引入 `setpgid` / `tcsetpgrp` / `fg` / `bg`。理由沿用 ADR-0007 §3.3 与
补齐方案 §0：Raku 没有跨平台稳定的 job control，本地单连接 REPL 不需要，
且与现有 `%!jobs`（spawn/wait 句柄表）语义冲突。父子进程留在同一进程组，
真实终端的 Ctrl-C 会同时打到两者；父进程靠临时 tap 存活，子进程按自己的
SIGINT 语义退出。

### D2：回归用「前台进程组收 SIGINT」，不写 `\x03` 字节

这是本 ADR 最关键的一条。Python `pty.openpty()` 的 slave 不是任何进程的
controlling terminal，`tty.setraw(slave)` 又会关掉 `ISIG`。在这套 harness
里：

- 直接写 `\x03` 只是**普通字节**，终端行规程不会把它变成 SIGINT；
- 仅把 `ISIG` 位打开也**不够**——没有前台进程组（`tty->pgrp`），
  `n_tty` 无处投递信号。

两者都会让子进程继续读 stdin，后续测试输入全被它吃掉，测出来的「失败」
是 harness 假象。因此回归驱动给 `rakuish` 设 `start_new_session=True`，
再用 `os.killpg(os.getpgid(proc.pid), signal.SIGINT)` 模拟真实终端把
SIGINT 发给前台进程组。这不是绕过产品逻辑：产品侧被验证的仍是
`signal(SIGINT).tap` + `LEAVE` 这一对行为。

### D3：把验收标准落成 5 条可观测断言（0.72.4 修订）

「终端回到可输入状态」在 0.72.3 的 raw 驱动里只能取**可观测代理**：子进程
退出后宿主重画 prompt、下一格能输入并求值、且之后的普通 Ctrl-C 仍是输入
中断语义。当时把 termios 字节级快照列为后续项，理由不成立（见 §0）。
0.72.4 起由 SPEC V-174 / `t/31` 单独覆盖：canonical 基线直接比对位图，
不再只依赖代理。

## 3. 实测证据（WSL Ubuntu / Rakudo 2026.09，真 PTY）

| 驱动机制 | 子进程退出 | 宿主存活 | 交接摘要 | 下一格求值 | 后续 Ctrl-C |
|---|---|---|---|---|---|
| raw，写 `\x03`（ISIG=0） | ✗ | ✓ | ✗ | ✗（输入被子进程吃掉） | ✗ |
| 开 `ISIG`，写 `\x03` | ✗ | ✓ | ✗ | ✗ | ✗ |
| `start_new_session` + `killpg(SIGINT)` | ✓ `code=130` | ✓ | ✓ `↩ … 已退出` | ✓ `Out[3] = 42` | ✓ `已中断当前输入` |

补充观察（同一驱动，`postsig` 变体）：在 `tty-exec` **结束后**再次
`killpg(SIGINT)`，REPL 按 Rakudo 默认行为退出（`rc=-2`）。这直接证明
`LEAVE` 关闭 tap 后默认 SIGINT 处理器确实恢复了，临时 tap 没有泄漏。
该行为依赖 Rakudo 默认 SIGINT 语义（SPEC V-168 明确「不承诺」），
因此**只作实证记录，不钉成产品断言**。

termios 观测（0.72.4 修订）：`ICANON / ECHO / ISIG` 在上述 raw 驱动里三处
均为 0，只能说明**该驱动**分不出污染前后，不能推出「快照不可观测」。
换成 canonical 基线（不 `setraw`，显式开三位）后实测：子进程
`stty raw -echo` 把 `c_lflag` 从 `35387` 改成 `35376`，模拟的下一轮 prompt
之后仍是 `35376`；在交接前存快照、返回时恢复则回到 `35387`。该探针已转正
为 `t/31-tty-termios.t`。

## 4. 契约：SPEC V-173

`! --tty` / `tty-exec(...)` 期间，前台进程组收到 SIGINT（真终端的 Ctrl-C）时：

1. 子进程按自身 SIGINT 语义退出，`tty-exec` 返回并把 `code` / `elapsed`
   写进交接摘要与 `Result.value`；
2. 父进程**存活**，不会被同一个 SIGINT 带走；
3. 宿主重画 prompt，下一格可正常输入并求值；
4. `LEAVE` 关闭临时 tap，之后的普通 Ctrl-C 仍是 V-168 的输入中断；
5. 未中断的普通求值 / `exit` 路径一字未改。

回归落点：`t/30-tty-exec-sigint.t`（Linux/WSL 真 PTY，Windows 整段 skip）
与 `tools/tty-check.py` 的检查项。终端状态恢复另见 0.72.4 的
`t/31-tty-termios.t` / SPEC V-174。

## 5. 边界 / 明确不做

- **不做** job control（`setpgid` / `tcsetpgrp` / `fg` / `bg`）：D1。
- **0.72.4 起做** termios 快照恢复（订正 0.72.3 的错误边界）：`tty-exec`
  在 `bind-stdin` 之前存一份宿主配置，正常路径与 `LEAVE` 幂等恢复；
  `Result.value<termios-restored>` 如实标记成败，快照不可用不阻断直通。
  仍**不**由父进程猜测子进程改了哪些位。见 SPEC V-174。进程组切换自
  0.73.0 起由 ADR-0010 §6 / SPEC V-175 另行实施。
- **不做** SIGINT 归属的精确化：0.72.3 时父子同组意味着信号同时到达（0.73.0
  的进程组交接已改变这一点，见 V-175）；但子进程忽略 SIGINT 时 `tty-exec`
  仍会一直等（ADR-0007 §3.4 的无超时边界不变），由用户自行结束。
- **不承诺** kill 孙进程（B / V-905 仍是后续项）、不承诺求值中 SIGINT 的
  Rakudo 默认行为（V-168）。
- Windows 原生无 `pty` 模块，真 PTY 回归只在 Linux/macOS/WSL 跑；
  Windows 的**控制台模式**分支另见 §7（0.72.5 用真 ConPTY 补测）。
- 0.72.3 **没有改动 `Sys::Proc.tty-exec` 的实现**：0.72.2 的代码已满足
  Ctrl-C 归属契约，缺的是断言。0.72.4 为补 termios 快照才首次改动该方法，
  两个版本号都按 patch 递增。

## 6. 后续项（0.72.4 修订后的剩余清单）

| 项 | 出处 | 状态 / 为什么没一起做 |
|---|---|---|
| termios 快照 / `LEAVE` 恢复 | 补齐方案 §5 阶段 3 | ✅ **已实现（0.72.4 / SPEC V-174）**：复用 `Terminal::API` 封装，canonical 基线回归见 `t/31`；原「需自己写 NativeCall、跨平台成本高」的理由不成立 |
| REPL `! --pty` 元选项 | 补齐方案 §2 | 与 V-909 / ADR-0007 §2 的显式入口契约冲突，需独立决策 |
| `tty-exec` 期间 Ctrl-C 的**真实终端模拟器**人工确认 | `tmp/TTY-CHECK.md` §7 | 自动化只能验证信号语义，不能验证 vim/less 这类程序自己的终端恢复 |
| B / V-905 孙进程回收 | 0.72.1 任务书 | 进程组 / Job Object，独立设计 |

## 7. Windows 控制台模式实测（0.72.5，真 ConPTY）

0.72.4 交付时把 Windows 的 `GetConsoleMode` / `SetConsoleMode` 分支写成
「由 `Terminal::API` 处理、真机未验证」。0.72.5 用 ctypes 直接调
`CreatePseudoConsole` 造出真伪控制台，把这块补上；可重复运行的入口是
`tools/tty-termios-win.py`（探针 `tools/tty-termios-probe.raku` +
污染者 `tools/tty-polluter.raku`）。

测量环境：Windows 11 26300 / Rakudo 2026.09，ConPTY 110×30。

| 时点 | 输入模式 | 说明 |
|---|---|---|
| BEFORE | `503` (0x1F7) | `PROCESSED_INPUT + LINE_INPUT + ECHO_INPUT` 等 |
| 子进程 `make-raw` 后 | `1008` (0x3F0) | 清掉 `0x007`，置上 `ENABLE_VIRTUAL_TERMINAL_INPUT`(0x200) |
| `tty-exec` 返回 | `503` (0x1F7) | `termios-restored=True` |
| 对照（关掉快照） | `1008` 保持 | `termios-restored=False` —— 证明断言敏感，不是假绿 |

`503 −(清位)→ 496 →(置 VT input)→ 1008`，与 `Terminal::API::make-raw` 的
Windows 分支逐位吻合。REPL 层端到端同样通过：ConPTY 里跑 `bin/rakuish`，
`! --tty <polluter>` 之后读回 `503`，下一格 `40 + 2` → `Out[5] = 42`。
同一份探针在 conhost（`winpty` 提供）下数值完全一致。

三个驱动层坑（都已写进工具文件头，避免下次重踩）：

1. **ConPTY 属性只在驱动进程自己已有控制台时生效**。没有控制台时
   `CreateProcess` 会给子进程新建一个隐式控制台：返回值成功、`isatty` 为真，
   但输出不进伪控制台管道——表现为「静默不生效」。工具因此先检测控制台，
   没有就用 `winpty` 把自己重新拉起来。
2. `UpdateProcThreadAttribute` 的 `lpValue` 要传 HPCON **句柄值本身**
   （MS EchoCon 样例写法）；传 `byref(hPC)` 同样静默不生效，且
   `CreatePseudoConsole` 依然返回 `S_OK`。
3. `winpty` 不透传子进程退出码（实测把 `exit 5` 变成 `0`），所以工具用裁决
   文件回传；它还会往 stderr 打一行无害的 `Assertion failed: ... cols > 0`。

结论：V-174 的 Windows 分支在 conhost 与 ConPTY 两种控制台上都实测通过。
Windows 仍无进程组交接（POSIX-only，见 V-175）；vim / less 这类程序自己的
终端恢复时序不属自动化范围（§6 的人工项保留）。
