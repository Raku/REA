# ADR-0008：输入中断语义与 SQL 补全调用形态（0.71）

- **状态**：已接受（2026-11-12）
- **相关**：ADR-0001（纯交互动作走快捷键 / 值 API）、ADR-0003（行编辑器子类）、
  ADR-0006（SQL 补全启发式、不做 AST）、SPEC V-161 / V-164 / V-168 / V-169

## 1. 问题

### 1.1 Ctrl-C 会悄悄退出整个 REPL

`Terminal::LineEditor` 0.0.23 的默认 keymap 把 `Ctrl-C` 绑成 `abort-input`，
`read-input` 在该分支里 `set-done; $aborted = True; done`，最终 `prompt()`
返回**未定义的 `Str` 类型对象**。而 `bin/rakuish` 的取行代码把「未定义」
一律当成 EOF：

```raku
my $in = try { $cli.prompt($prompt) };
elsif !$in.defined { last }          # ← Ctrl-C 落到这里，退出进程
```

同时 `Session.key-bindings()` 与 MANUAL 都写着「`Ctrl-C` 中断当前 cell /
清空续行缓冲」，`Session.handle-key('Ctrl-C')` 也确实实现了清 `@!pending`
的值 API，但它**从未接到真实行编辑器上**。于是文档承诺、值 API、终端行为
三者不一致：用户按 Ctrl-C 想丢掉半行输入，结果是整个会话没了。
0.70 的 `! --tty` 嵌套 REPL 让这个缺陷更容易被踩到。

### 1.2 SQL 补全只认两种字符串

V-161 / V-164 的 `sql-context` 只识别 `'...'` / `"..."`，且要求引号前
**紧接**白名单调用名 + `(`。Raku 里写 SQL 有两个很常见的形态都不覆盖：

```raku
$db.query(q[select * from sales where region = 'east' and am   # q[] 避开单引号
$db.query(sql => 'select * from sa                            # 具名参数
$db.query(:sql('select * from sa                              # :sql(...) 具名
```

SQL 里出现字符串字面量时用户几乎必然改用 `q[...]`，但 0.68/0.69 明确把
`q[...]` 写成「不识别」的边界，Tab 在这些行上什么也不给。

## 2. 约束（不可突破）

- **V-116**：非 TTY / 管道下 stdout 纯净，行编辑器根本不构造；中断语义
  只在真 TTY 生效，不能改 `$*IN.get` 回退路径。
- **ADR-0003 §2**：不复制 / fork `Terminal::LineEditor::read-input`，
  只覆盖 `decode-keyname` / `prompt` / `special-actions` / `input-class`
  这类公开扩展点；依赖升级导致子类构造失败时仍要能回退。
- **默认行为不变**：`Ctrl-D`（EOF / `abort-or-delete`）仍退出；捕获式
  `exec`、`!` 的 argv 语义、`Session.eval-line` 一格一值不变。
- **ADR-0006 §4 / V-908**：**不引 SQL 解析器、不做 AST 级补全**。新增形态
  只能是可判定的词法前缀，不能把「猜 SQL」变成「解析 SQL」。
- **不改 `q` 的语义**：只支持不插值的 `q`，不碰 `qq` / `Q` / `qx` /
  heredoc；补全返回的是「已输入前缀的替换」，不替用户闭合引号。

## 3. 决策

### 3.1 Ctrl-C = 中断输入，不等于 EOF

新增 `InterruptCLIInput`（继承 `CLIInput`），做三件最小的事：

| 覆盖点 | 行为 |
|---|---|
| `decode-keyname` | 解码结果为 `Ctrl-C` 时记一个**本次 prompt 内**的中断标志；其余按键原样交给 `callsame` |
| `take-interrupt` | 返回并清空该标志，供宿主查询（一次性） |
| `prompt` | 开始时清标志；若 `callsame` 返回未定义且中断标志为真，返回**定义的空串**，否则原样返回（真 EOF / Ctrl-D 仍是未定义 `Str`） |

`ViCLIInput` 改为继承 `InterruptCLIInput`，`make-cli` 在 emacs 模式也构造
`InterruptCLIInput`（不再是原生 `CLIInput`）。这样 vi / helix / emacs
三种键位下 Ctrl-C 语义一致，且没有复制 `read-input`。

宿主侧（`bin/rakuish`）：取到行后先查 `take-interrupt`，命中则

1. 调 `$session.handle-key('Ctrl-C')` —— **复用已有值 API**，清掉
   `@!pending` 续行缓冲、记录中断请求，不新开命令分支；
2. 不调用 `eval-line`，因此**不产生空 `Out[n]` 格**、不进历史、不记耗时；
3. 打印一行暗灰提示（含「Ctrl-D 退出」），`next` 重画 prompt。

`Session.key-bindings()` 的文案同步改成「中断当前输入 / 清空续行缓冲
（不退出）」，把「中断当前 cell」这个做不到的承诺删掉。

**明确边界**：这里处理的是**输入阶段**的 Ctrl-C。cell 正在求值时行编辑器
不在读键，Ctrl-C 是终端交给进程组的 SIGINT，仍按 Rakudo 默认行为处理；
本版不装 SIGINT handler、不承诺中断运行中的 cell（`tty-exec` 等待期间的
临时 tap 是 ADR-0007 的既有逻辑，未改）。

### 3.2 SQL 补全：两种新调用形态，仍是纯词法

`sql-context` 的扫描器从「只找未闭合 `'`/`"`」扩成一张小表：

| 形态 | 内容起点 | 结束符 | 说明 |
|---|---|---|---|
| `'...'` / `"..."` | 引号后 | 同引号 | 0.68 原有行为，逐字不变 |
| `q[...]` / `q{...}` / `q(...)` / `q<...>` | 开括号后 | 配对闭括号 | 仅不插值 `q`，`q` 前须是词边界 |

引号起点之前的调用检测放宽为「白名单调用名 + `(`，其后可跟
`:sql(` 或 `sql =>` 具名参数前缀」，仍然要求**紧邻**：不扫描整行、
不做括号配对回溯、不识别 `qq` / `Q` / heredoc / 嵌套 `q[...]`。
`sql-context` 额外返回 `quote-style`（`single` / `double` / `q`）便于测试
与未来扩展；候选生成、`tail` 保留、别名映射、大小写风格、Engine 异常
退化路径**一行不改**。

### 3.3 文档一致性（不是新功能）

0.70 收尾时发现 ROADMAP §2 把「CSV 编码 / 多行字段精细控制」「扩展统计
（直方图）」列为候选，但 SPEC V-907 / V-163 与 HANDOFF §10 都明确写了
「不做」；HANDOFF §10 又把「无开机自启 / 速率限制」列为风险，而
ADR-0002 §4 明确「不是 daemon」。本版把 ROADMAP 的候选清单收敛到与规格
一致，不偷偷扩范围；要真做这些，得另开 ADR 改规格。

## 4. 明确不做

| 不做 | 理由 |
|---|---|
| 把 Ctrl-C 绑成 `delete-to-start` 等编辑动作 | 只清半行，且留在同一 `read-input` 里必须再按 Enter 才回 REPL；「中断」应是立即回到新 prompt |
| 覆盖 / 复制 `read-input` | 依赖内部 `react whenever` 循环，ADR-0003 已定下「只走扩展点」 |
| 用哨兵字符串表示中断 | 会污染历史 / 求值 / `Out[n]`，且可能和用户真输入的空行混淆 |
| 中断运行中的 cell / 全局 SIGINT handler | 需要取消语义与 EVAL 中断点，超出本版；见 §3.1 边界 |
| `qq` / `Q` / heredoc / 嵌套 `q[...]` | 插值与转义语义不同、需要真解析；不做假能力 |
| SQL AST 级补全（V-908 不变） | 引解析器会拖住核心安装、两引擎方言不同、Tab 热路径不划算 |

## 5. 验证

- `t/19-repl-experience.t`：`make-cli` 三种模式的类、Ctrl-C 标志、
  `take-interrupt` 一次性、Ctrl-D / 普通键不误报。
- `t/23-sql-complete.t`：`q[...]` / `q{...}` / `sql =>` / `:sql(` 的上下文
  与完整替换行、双引号原行为回归、非白名单调用仍不触发。
- `t/27-interrupt.t`：真 PTY 下起 `bin/rakuish`，半行输入 → Ctrl-C →
  进程仍活 → 下一格可正常求值 → Ctrl-D 才退出（Windows 跳过）。
- `tools/tty-check.py`：增加 Ctrl-C 相关检查项；双平台全量回归 +
  `zef install --force-install` 冒烟。

## 6. 后果

正面：Ctrl-C 与帮助文本、值 API 终于一致，嵌套 REPL 场景不再因误按
Ctrl-C 丢掉整个会话；`q[...]` 让用户能按 Raku 习惯写含引号的 SQL 并继续
享受元数据补全。

负面 / 代价：emacs 模式不再用原生 `CLIInput`，多一层子类（依赖升级时
回退路径仍在，但回退后 Ctrl-C 会退回 0.70 行为，需如实记录）；
`interrupt-requested` 是「最近一次中断」的会话状态，本版不自动清除；
`q[...]` 的补全仍是启发式，不处理嵌套分隔符。
