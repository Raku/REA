# 审计修复记录（0.36.0）

> **历史记录**：本文件记录 0.36.0 批次的修复；完整关闭状态见
> [`AUDIT-STATUS-2026-11-11.md`](AUDIT-STATUS-2026-11-11.md)。

- **基线**：`docs/AUDIT-2026-11-11.md`，审计对象 `b2aa789`（0.35.1）
- **修复版本**：`0.36.0` / `0.36.1`
- **测试**：Windows 11 个文件 / 647 条断言；Linux `tools/run-all.sh` 问题总数 0；`zef install . --dry` 通过

---

## 1. P0 修复

| # | 问题 | 修复 |
|---|---|---|
| P0-1 | REPL 每格重放全部历史，`append` / `write` / `exec` 副作用重复 | 不再整份重 EVAL；只执行当前格。顶层 `my/our/state` 由扫描器转成 `%STATE` 别名持久化；纯 `sub` / `use` 声明缓存后前置。新增回归：连续三格后文件只有 1 行 |
| P0-2 | Sandbox 可被中间目录 symlink 绕过 | `Sys.resolve` 对最近已存在前缀做 canonicalize，校验每一级中间 symlink；`write` 的新文件也校验父目录真实路径。新增 Linux symlink 读写逃逸测试 |
| P0-3 | exec 白名单只按 basename 匹配 | 带 `/` 或 `\` 的 argv[0] 必须和白名单里的绝对路径 canonicalize 后精确匹配；裸命令名只匹配裸白名单项。`/tmp/evil/git` 不再被 `git` 白名单放行 |
| P0-4 | Agent 请求级 env 可注入 `LD_PRELOAD` | `exec.env` 改为安全键白名单：只允许 `LANG` / `LANGUAGE` / `TZ` / `LC_*`；`PATH`、`LD_*`、`DYLD_*`、`BASH_ENV`、`PYTHONPATH`、`NODE_OPTIONS` 等一律 403 |

## 2. P1 修复

| 问题 | 修复 |
|---|---|
| REPL 默认 root = cwd，`cd ..` 都被拒 | `Session` 默认 root 改为文件系统根（Windows 为当前盘根）；`Sys` 直接构造仍可显式 root；Agent 仍要求显式 root |
| `read` offset/limit 越界抛底层 `substr` / `subbuf` 错误 | 负 offset/limit 抛 `X::Rakuish::Path`；超长度返回空串 / 空 Blob；不再泄漏底层错误 |
| `Proc` 在进程结束前不消费输出，`max-bytes` 只事后裁剪 | `Handle.wait` 先并发消费 stdout/stderr；超过 `max-bytes` 只保留前缀并丢弃后续，内存不再随输出增长；无限输出在超时后结束 |
| `spawn` 在返回 Handle 前 await stdin 写入，可能永久阻塞 | stdin 写入移到后台任务；`wait` / `cancel` / 超时仍可用 |
| `write` Windows 原子降级先 unlink 目标，rename 失败会丢文件 | 先 rename 目标到同目录备份；新文件替换成功后才删备份；失败回滚并抛错 |
| `cp -r` 跟随目录内 symlink | `!copy-one` 遇到 symlink 直接抛 `X::Rakuish::Unsupported`，不再递归到 root 外 |
| `ls file` 报“目录不存在” | `ls` 对文件/链接目标返回单元素列表，符合 shell `ls file` 习惯 |
| DSL `$SESSION` 全局单例，多 Session 串 | `Session` EVAL 时绑定动态 `$*RAKUISH-SYS`；`session()` 优先动态，回退 `bind-session` |
| Agent JSON 与 Result Renderer 两套序列化 | Agent 的 `!json-value` 直接复用 `Rakuish::Result::Renderer::json-value` |
| JSONL / TCP 输出未 flush、无行长度上限 | 每行 flush；单行超过 1 MiB 返回 400，不进入 Agent 解析 |

## 3. 行为变化 / 迁移提示

1. **REPL 不再重放历史**  
   顶层 `my` / `our` / `state` 仍可跨格；嵌套块里的 `my` 仍是块内局部。  
   纯 `sub` / `use` 声明格会缓存；`class` / `role` / `grammar` 的跨格声明不在状态层内
   （Raku 的 EVAL 不能简单重定义类）。

2. **REPL / 脚本默认 root 是文件系统根**  
   `rakuish` 不再把用户限制在启动 cwd。Agent 入口仍要求显式 `--root`。

3. **exec 白名单更严格**  
   `--allow git` 只允许裸命令名 `git`；如果 argv 写绝对路径，白名单也必须写同一个
   绝对路径。带路径的 `argv[0]` 不再用 basename 匹配。

4. **请求级 env 只允许安全键**  
   `Agent` 的 `exec` 请求不能覆盖 `PATH`，也不能注入 `LD_PRELOAD` 等；需要环境变量
   请通过会话 `sys.set-env`（Agent 目前不开放该 op）或启动环境配置。

5. **`ls` 文件目标**  
   `sys.ls('README.md')` 现在返回 `(README.md,)`；不再抛“目录不存在”。

## 4. 测试增量

- `t/01`：read offset/limit、ls 文件目标、cp 目录 symlink、中间 symlink 读写逃逸
- `t/03`：无限输出截断
- `t/05`：副作用只执行一次、my 标量/数组/哈希持久、多 Session DSL、默认 root、纯 sub/use
- `t/06`：绝对路径白名单、`LD_PRELOAD` 拒绝、安全 `LANG` 透传
- `t/09`：REPL 内置命令展示（上一版）

## 5. 仍然保留的 P2（不阻断发布）

- `serve-once` 仍只处理一个连接，缺少 idle/read timeout（Raku 同步 `IO::Socket`
  没有现成的读取超时，需换异步 transport 才能做）。
- `class` / `role` / `grammar` 的跨格声明不持久；纯 `sub` / `use` 已支持。
- `rm` 指向 root 外的 symlink 会被 canonical 校验拒绝（安全优先，链接本身无法删除）。

### 本轮额外收尾

- 默认 token 改用 OS CSPRNG：Windows `RtlGenRandom`，POSIX `/dev/urandom`；
  拿不到安全随机源直接拒绝启动，不再静默回落 `rand`。
- `Sandbox.summary` 的 token 改为 `<redacted>`；入口需要时直接读 `$sandbox.token`。
- 审计内存条目默认上限 10000；JSONL 审计文件超过 10 MiB 时轮转为 `.1`。
- `write :backup` 先检查旧文件大小，超过 `max-bytes` 抛 `X::Rakuish::Limit`。
- `glob` 的 `?` 不再跨 `/`。
