# 0.71.5 修复记录

- **日期**：2026-11-12
- **对象**：`main` @ 0.71.5
- **问题**：`ls *.jpg` 卡顿，普通 glob 进入了整棵子树

## 根因

`Sys::FS.glob` 对所有模式都调用：

```raku
self.ls($root, :recursive)
```

`*.jpg` 本来只应看当前目录，却先把整棵目录树物化，再按相对路径过滤；
目录大或子目录深时非常慢，也更容易撞上 `max-entries`。

## 修复

- 只有模式包含 `**` 时才无界递归。
- 普通模式按路径段数设置 `max-depth`：
  - `*.jpg` → depth 1
  - `sub/*.jpg` → depth 2
  - `**/*.jpg` → 无界递归
- brace 展开后的多个模式取最大深度。
- 新增 t/18 回归：子目录条目数超过 `max-entries` 时，
  `*.jpg` 仍只扫当前目录并正常返回。

## 验证

```bash
prove6 -Ilib t
bash tools/run-all.sh
zef install . --force-install
```
