# ADR-0005：CSV 受控外部读写与 Engine 元数据补全（0.68.0）

- **日期**：2026-11-11
- **状态**：Accepted（0.68.0 实现）
- **影响范围**：`Rakuish::Data`、`Data::Engine` 角色 + DuckDB 适配器、
  `Rakuish::REPL::SqlComplete`（新）、`REPL::Session`、`Rakuish::DSL`、
  SPEC V-152 / V-160 / V-161、ROADMAP
- **前置**：[ADR-0001](ADR-0001-raku-native.md)、[ADR-0004](ADR-0004-cursor-worker.md)、
  `SPEC.md` V-129 / V-152

---

## 1. 背景

`ROADMAP` 在 0.67 交付后剩四个未排期候选：持久求值器、可恢复 / 事务一致性
游标、表名列名补全、CSV 受控外部读取。本 ADR 决定这一批做后两个，并明确
**不做**前两个的理由，避免把「暂缓」写成「待办」。

## 2. 决策一：CSV 与 Parquet 共用一套显式授权

0.64（V-152）把「DuckDB 直接读写文件」定为 V-129「数据层只经 Sys」的
**唯一显式例外**，当时只覆盖 Parquet。0.68 把 CSV 纳入同一模型，不再新造
第二套开关：

| 维度 | 约定 |
|---|---|
| 开关 | 仍是 `:allow-external`（DSL / `open-data` / `save-data`），Shell 是 `open --external` |
| 路径 | 一律先经 `Sys.resolve` 做 root 校验，越界抛 `X::Rakuish::Sandbox` |
| 引擎 | 受控的 `:!safe` 只读 DuckDB；`enable_external_access` 仅在这个临时引擎里开 |
| Agent | op 白名单**不暴露**该开关，默认仍 `enable_external_access=false` |
| 默认行为 | **完全不变**：不带开关的 `.csv` 仍走 `Sys.read` + `from-csv-data` / `Sys.write` + `to-csv-data` |
| 错误 | 驱动异常统一 `X::Rakuish::Data`；V3 异常族原样抛 |

带开关时的差异（这是用户显式换取的能力）：

- 读：`read_csv_auto(?)`，由 DuckDB 做**类型推断**（`int` / `double` / `varchar`），
  不再由 Raku 手写解析器把一切当字符串；大文件不整份读进 Raku 内存。
- 写：`COPY (...) TO ... (FORMAT CSV, HEADER)`，复用 0.64 导出的
  「建临时表 → 参数化 insert → COPY」流程，空值规则与 Parquet 一致。
- `Engine` 角色加 `read-csv` / `write-csv` 默认「明确拒绝」，不静默按文本处理；
  只有 DuckDB 实现。

**不承诺**：CSV 方言全兼容（分隔符 / 编码 / 嵌套引号 / 多行字段的精细控制）、
按 schema 强制类型、分区写出。需要这些时直接用 `Engine.query` 写 SQL。

## 3. 决策二：补全读 Engine 元数据，不引第二套语法

`Session.completions` 目前只转发给 `Shell.completions`，而后者对含 `(` 的输入
直接返回空 —— 恰好是 `$db.query('select ...')` 这类最常见的数据操作。

- 新增纯函数模块 `Rakuish::REPL::SqlComplete`：仅在**光标位于引号字符串内
  且该字符串属于 `query/cursor/execute/sql(...)` 调用**时激活；否则返回空，
  原 Shell 补全路径一字不改。
- `open-db` 把新建的 Engine 注册为**当前会话 Engine**（`repl.engine` 可读）。
  补全时只读 `tables()` / `schema()` 元数据，按 SQL 上下文补关键字 / 表名 /
  列名，返回**完整替换行**（与 Shell 补全约定一致）。
- 所有 Engine 调用包在 `try` 里：驱动缺失、库被锁、元数据查询失败都**优雅退化
  成空补全**，绝不让 Tab 把 REPL 弄崩。
- 纯函数、无 I/O 副作用，可脱离 TTY 与数据库单测；非 TTY / 管道下入口根本不
  创建行编辑器，补全回调不会被调用。
- **不引** `\d`、`%sql`、裸 SQL 命令等第二套语法；SQL 仍是字符串参数。

**边界**：只识别 `'...'` / `"..."` 字符串，不解析 `q[...]` / heredoc；
表名列名来自当前会话最后一次 `open-db` 的引擎；不解析 SQL AST，
关键字上下文用「最近一个关键字」启发式判断。

## 4. 不做（写清理由，不留在待办里假装能做）

| 候选 | 结论 | 理由 |
|---|---|---|
| 持久求值器 / 常驻编译单元 | **不做** | 现有「顶层 my 扫描 + 纯声明格缓存」已覆盖主要场景（0.65 补了类型声明）；换成常驻编译单元要重做 `EVAL` 作用域、副作用与失败回滚，收益不匹配风险。若将来做，须独立 ADR，且仍禁止历史重放（审计 P0-1）。 |
| 可恢复 / 事务一致性游标 | **不做** | `DB::DuckDB` / `DB::SQLite` 都不暴露可滚动游标或 CHECKPOINT 句柄；ADR-0004 §3 已把「一次性单连接」写进边界。用 OFFSET 模拟会重复/漏行，是把假能力包装成真能力。 |

剩余候选：表名列名补全后的**上下文感知排序**、基于元数据的 `describe` 值 API、
CSV 方言参数（显式 `:delimiter` 等）。这些按实际需求再排期。

## 5. 不变的安全契约

`eval` 不开放；所有文件操作仍只经 `Sys`（外部读写是显式授权的两个例外）；
外部命令 argv-only；Agent 默认拒绝且 op 白名单不变；审计脱敏不变；
`--worker` / Cursor 行为不变。

## 6. 验收

- `t/22-data-csv.t`：默认路径回归、显式开关往返与类型推断、默认拒绝、
  root 越界、Agent 白名单、错误统一、Parquet 导出流程回归、驱动缺失 skip。
- `t/23-sql-complete.t`：上下文识别、关键字 / 表名 / 列名候选、完整替换行、
  无 Engine / 非 SQL 行 / 驱动异常优雅退化、Session 联动、Shell 路径不变。
- `prove6 -Ilib t` 全绿；新模块进 `META6.provides`；版本与文档同步。
