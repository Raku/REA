# 0.71.4 审计修复记录

- **日期**：2026-11-12
- **对象**：`main` @ 0.71.4（基于 0.71.3）
- **范围**：审计 M-8 / M-9；测试环境 NO_COLOR 隔离

## M-8 · Shell 参数启发式误伤

- 引号内的 `;`、`(`、`)`、`|` 等不再触发“交回 Raku”：
  `echo "a;b"`、`echo "file(1).txt"` 作为字面参数处理。
- 只检查**引号外**的元字符；`$NAME` 仍按会话 env 展开，未展开的 `$var`
  继续交回 Raku。
- 新增 `SHELL-COMMANDS`：只包含真正由 Shell 分发的命令；
  `write` / `append` / `exec` / `env` / `ls-table` 等 Raku API 保留在
  `COMMANDS` 中用于 `help` / 补全，但执行时交回 Raku。
- `t/10` 新增引号内标点回归。

## M-9 · Agent 未知选项

- `bin/rakuish-agent` 增加 `AGENT-OPTIONS` 白名单。
- 未知选项（如 `--allowlist git`）直接退出 2，并给出“未知选项”提示，
  不再静默变成空配置。
- `t/07` 新增未知选项回归。

## 测试环境

- `t/15-repl-ui.t` 在测试期间临时移除 `NO_COLOR` / `FORCE_COLOR`，
  避免宿主环境导致 `zef install` 误报颜色测试失败。

## 验证

```bash
prove6 -Ilib t
bash tools/run-all.sh
zef install . --force-install
```
