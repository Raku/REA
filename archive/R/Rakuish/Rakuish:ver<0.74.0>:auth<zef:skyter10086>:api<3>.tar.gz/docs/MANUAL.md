# Rakuish Manual

适用版本：**0.74.0**（API v3）

本文是使用手册；规格真值见 [`SPEC.md`](../SPEC.md)，架构与接手说明见
[`HANDOFF.md`](../HANDOFF.md)。Rakuish 不是 bash 兼容层：**命令是 Raku，
外部命令只接 argv，Shell 薄层只负责日常文件操作的观感**。

---

## 目录

1. [安装与依赖](#1-安装与依赖)
2. [入口模式](#2-入口模式)
3. [REPL 基本模型](#3-repl-基本模型)
4. [Shell 薄层命令](#4-shell-薄层命令)
5. [Raku 表达式与外部命令](#5-raku-表达式与外部命令)
6. [脚本与 DSL](#6-脚本与-dsl)
7. [结构化数据](#7-结构化数据)
8. [数据引擎：DuckDB / SQLite](#8-数据引擎duckdb--sqlite)
9. [文件与进程 API](#9-文件与进程-api)
10. [配置、alias、hook](#10-配置aliashook)
11. [Agent 结构化服务](#11-agent-结构化服务)
12. [错误、限制与安全边界](#12-错误限制与安全边界)
13. [故障排查](#13-故障排查)
14. [API 速查](#14-api-速查)

---

## 1. 安装与依赖

```bash
zef install .
rakuish --version
```

要求：

- Rakudo / MoarVM（实测 2026.09 系列）
- `zef`
- 核心依赖：`JSON::Fast`、`Terminal::LineEditor`
- 可选：`DB::DuckDB`（分析引擎）、`DB::SQLite`（事务型小库）

源码运行：

```bash
raku -Ilib bin/rakuish
```

Windows 上若 `rakuish.exe` / precomp 文件被残留 `raku` 进程占用，先结束残留进程再安装。

---

## 2. 入口模式

| 命令 | 行为 |
|---|---|
| `rakuish` | 交互 REPL；TTY 有提示符，管道下逐行求值 |
| `rakuish -e '1 + 1'` | 求值一段 Raku，打印结果后退出 |
| `rakuish script.raku a b` | 把整份源码当一个 cell 跑；参数进 `@*ARGS` |
| `rakuish --help` | 启动参数帮助 |
| `rakuish --version` | 版本 |
| `rakuish --agent ...` | 转发到 `rakuish-agent` |

**启动参数必须在 shell 里传给 `rakuish`**；REPL 内敲 `--help` 是 Raku 的 `--`
运算符，不是启动参数。

脚本模式：

- 预加载 `Rakuish::DSL`、`sys`、`repl`、`registry`
- 不打印 `Out[n]`
- 相对路径跟随调用者 cwd
- REPL/脚本默认 root 是文件系统根；Agent 必须显式 `--root`

---

## 3. REPL 基本模型

REPL 每行只有两类输入：

| 输入 | 处理 |
|---|---|
| `! git status` | 去 `!`，只做 argv 分词，调用 `sys.exec`；`|`、`>`、`$`、`*`、`&&` 原样作为参数 |
| `! --tty rakupp` | 显式 TTY 直通，跑嵌套 REPL / 编辑器（0.70 / V-167） |
| 其它（含 `%`） | Raku 表达式；失败就是失败，不回退 shell |

另外有**日常命令薄层**：`cd`、`ls`、`cat` 等，只把常见 shell 输入翻译成
`Sys` 调用；它不是第三套语言，也不支持管道/重定向/子 shell。

```text
rakuish> 1 + 1
Out[1] = 2
rakuish> %h = a => 7; %h<a>     # % 是哈希
Out[2] = 7
rakuish> ! git status --short    # 外部命令，argv-only
rakuish> help ls                 # 命令帮助
```

### `_` / `Out[n]`

- `_`：上一成功格的值
- `Out[1]`：第一个成功结果；`Out[2]` 第二个……
- 失败格不增加 `Out` 编号
- 值可以是 `Table`、`List[IO::Path]`、`Str`、`Stat` 等

```raku
ls --json .
_.where({ .<type> eq 'file' }).select('name').to-text
Out[1]
```

### 多行输入与声明持久

括号 / 引号未闭合时进入续行；空行提交。

**纯声明格跨格持久**（0.65）：整格只写一个 `sub` / `use` / `class` / `role` /
`grammar` 声明时，它会被缓存并在后续每格前置，下一格可直接使用：

```raku
class Box { has $.n; method twice { $!n * 2 } }
Box.new(n => 21).twice            # 42
role Tag { method tag { "T" } }
class Tagged is Box does Tag { }
Tagged.new(n => 5).twice          # 10
grammar Digits { token TOP { \d+ } }
Digits.parse('123').Bool          # True
```

机制是**只重放纯声明**，不重放任何执行语句；顶层类型声明统一改写成
`my class` / `my role` / `my grammar`，避免装进 `GLOBAL` 后重放冲突。
边界：混有其它语句的格、含 `BEGIN` / `INIT` 等 phaser 的格不缓存；
持久的是**名字可见性，不是类型对象身份**（每格重放生成新 type object），
`.^name` 会带外层包名。详见 SPEC V-124 / V-153。

### 行编辑

TTY 下使用 `Terminal::LineEditor`：

- Up / Down 历史
- Ctrl-R 搜索
- Ctrl-A / Ctrl-E 行首 / 行尾
- **Ctrl-C 中断当前输入 / 清空续行缓冲（0.71 起不退出会话）**：丢弃半行、
  重画 prompt，不产生一格输出；退出仍用 Ctrl-D 或 `exit`
- Ctrl-D 退出
- Tab 补全命令、路径、`help <cmd>`
- 0.68 起在 `$db.query('...')` / `$db.cursor('...')` 的 SQL 字符串里，
  Tab 还会补关键字 / 表名 / 列名（见下「SQL 上下文补全」）
- 0.69 起支持表别名前缀（`s.am` → `s.amount`）与关键字大小写跟随
  （`SEL` → `SELECT`）；仍不解析 SQL AST
- 0.71 起 SQL 补全还认 `q[...]` 与 `sql =>` / `:sql(` 具名形态
- 历史文件 `~/.rakuish-history`

Ctrl-C 只作用于**输入阶段**：cell 正在求值时行编辑器不在读键，此时 Ctrl-C
是终端交给进程的 SIGINT，仍按 Rakudo 默认行为处理，不承诺中断运行中的 cell。
设计见 [ADR-0008](ADR-0008-input-interrupt-sql-forms.md) §3.1 / SPEC V-168。

### 编辑模式与 hints（0.66 / ADR-0003）

默认 `emacs` 键位，完全不改 `Terminal::LineEditor` 的原生行为。想用 Vi/Helix：

```text
config set edit-mode vi|helix|emacs
config set vi-start insert|normal     # 每行起始模式
config set hints on|off               # 上下文提示（默认 on）
config set plugins on|off             # 本地 Raku 插件（默认 off）
```

`edit-mode` 当格生效（重建行编辑器并迁移历史）。非 emacs 时 prompt 显示
`VI·NORMAL` / `HELIX·INSERT` 之类的模式徽标，banner 也列出编辑模式。

| 键 | 动作 |
|---|---|
| `Esc` | 进 normal |
| `i` / `a` / `A` / `I` / `o` / `O` | 进 insert（各自带光标定位） |
| `h` / `l` / `0` / `$` | 左 / 右 / 行首 / 行尾 |
| `w` / `b` / `e` | 词移动 |
| `x` / `D` / `dd` | 删字符 / 删到行尾 / 清空整行 |
| `u` / `p` | 撤销 / 粘贴 |
| `j` / `k` | 历史下 / 上一格（单行 REPL 的映射） |

`repl.vi` 是同一套语义的纯逻辑对象（缓冲 / 光标 / 模式 / 撤销），可脚本化；
`repl.vi-keys` 是键位表。构造行编辑器失败会自动回退到原生 `CLIInput` 的
`Alt-*` 预设（`Alt-h/j/k/l` 移动、`Alt-w/b` 词移动、`Alt-x` 删除等）。

**hints** 是「上一格给下一格的提示」：命令用法首行、registry 参数摘要、
`!` 的 argv 说明、失败格的下一步建议。同一首词只提示一次，`hint <输入行>`
可手动查询。TTY 下在 prompt 前显示一行暗灰文字；管道 / 非 TTY 完全不输出。

边界：`tools/tty-check.py`（0.74.0 起 25 项）已在 WSL 真 PTY 下自动验证
banner / 彩色 prompt / Vi 徽标 / Tab 补全 / SQL 补全 / Ctrl-C 中断 /
describe / 嵌套 REPL / `tty-exec` 期间 SIGINT 归属；但**真实终端模拟器**
（Windows Terminal、Konsole、tmux 等）的光标手感仍需人工确认。normal 模式下
bracketed paste 的字符会被当 vi 键吞掉，粘贴前先按 `i`；不做多行 buffer /
可视块 / `.` 重复。

### 界面与计时（0.62）

TTY 下的 banner 是**极简字标**（`  Rakuish` + 细分割线，不用字符拼字），
第二行给出版本、Raku / VM、启动时间、cwd 与行编辑状态。prompt 单行显示：

```text
12:37:06  ~/rakuish  git:main  [3]  1.2ms  ❯
```

依次是时间、会话 cwd（长路径折叠）、git 分支、格号、上格耗时、箭头；
失败格额外显示 `[exit=N]`，多行续行的提示符是 `···`。
**管道 / 脚本下不打印 banner 与 prompt，也不输出任何 ANSI**（SPEC V-116）。

计时能力全部是 Raku 原生的值，不是文本魔法命令：

| 写法 | 结果 |
|---|---|
| `timed { ... }` | `Result`，`value` 是返回值，`elapsed` 是耗时；`:repeat(N)` 连跑 N 次 |
| `bench({ ... }, :repeat(5))` | `Result`，`value<min/mean/max/total/repeat>` 可组合，`out` 是人读摘要 |
| `perf [N]` | 最近 N 格耗时 + 平均 / 最慢（默认 10，上限 200） |
| `repl.perf-hist` | 会话级原始记录 `[格号, 毫秒, 源码, 是否成功]` |

`%time` 这类魔法命令**没有恢复**：`%` 始终是 Raku 哈希（SPEC V-122），
耗时改由每格自动记录 + prompt 显示，覆盖所有输入类型。

界面配置（`config set KEY VALUE`，当格即生效）：

| 键 | 值 | 默认 |
|---|---|---|
| `color` | `auto` / `on` / `off` | `auto`（TTY 即开） |
| `clock` / `timing` / `git` / `banner` | `on` / `off` | `on` |
| `prompt-style` | `full` / `compact` / `plain` | `full` |

`NO_COLOR`（任意值）强制关色，`FORCE_COLOR=1` 强制开；`compact` 只留路径，
`plain` 去掉 ANSI 与 `❯`。git 分支只读 `.git/HEAD`，经 `Sys`，不启动进程。

### 颜色与高亮（0.74 / ADR-0011）

`config set color off`（或 `NO_COLOR`、管道）会让**所有**着色同时失效；
开关是同一个，不区分「结果」和「输入」。

结果侧的着色点：

| 内容 | 样式 |
|---|---|
| `ls` / `glob` 的路径列表、`ls -l` 的名字列 | 目录粗蓝 · 可执行粗绿 · 符号链接青 |
| `Out[n] =` 标签 | dim |
| `错误:` 整行 | 红 |
| `help()` | 命令名粗青 · 摘要 dim |
| `env()` | `KEY` 青，`=` 与值保持默认 |
| `stat` | 字段名 dim |
| 写入结果 | `wrote` 绿 · `[non-atomic]` 黄 |

输入行（`emacs` / `vi` / `helix` 一致）：字符串绿、注释灰、数字黄、
变量青（含 `$*CWD` / `$!attr` 这类 twigil）、关键字粗蓝。

两条边界要知道：

- **列宽永远按纯文本算**。着色只插入零宽转义，`strip-ansi` 后与不染色时
  逐字符相同 —— 否则多列 `ls` 会错位、输入区光标会漂。
- 词法只覆盖**单行**的字符串 / 注释 / 数字 / 变量 / 关键字。
  `q[...]` / `qq[...]` / heredoc / 正则字面量 / 多行字符串**不会**被着色，
  这是刻意的（半截输入染错色比不染更烦人）。
- `Result` 的 `render-result(format => 'text')` 与 Table 表格**不掺 ANSI**：
  那是给脚本和 Agent 消费的数据格式。
- 行编辑器子类构造失败回退到原生 `CLIInput` 时**没有高亮**，与 Ctrl-C 的
  回退路径同理。

### strict

```text
set -e     # 下一个失败请求退出
set +e     # 关闭
```

适用于 shell、`!` 外部命令、Raku 求值失败。

### 历史替换

```text
!!        重跑上一条
!3        重跑第 3 条
!-1       重跑倒数第一条
!$        重跑上一条最后一个词
```

只有整行 `!!` / `!$` / `!n` / `!-n` 做替换；`!cmd` 仍是外部命令。
替换后立即求值，结果再入历史；`expanding` 标志防递归。

---

## 4. Shell 薄层命令

这些命令由 `Rakuish::REPL::Shell` 处理，参数是字面路径/简单 flag；带 Raku
表达式、变量或复杂引号时会交回 Raku。每个命令支持 `--help` 或 `help <cmd>`。

### 文件与目录

| 命令 | 说明 |
|---|---|
| `pwd [-L|-P]` | 当前会话目录 |
| `cd [dir|-]` | 切换会话 cwd；不 `chdir` 进程 |
| `ls [-a -A -l -h -F -p -R -t -S -r -d -1 --json] [paths]` | 目录列表；`-l` 长格式，`--json` 返回 `Table` |
| `cat 文件...` | 原样输出 |
| `read 文件...` | 与 `cat` 同源；二进制用 `sys.read(..., :bin)` |
| `head [-n N]` / `tail [-n N]` | 前/后 N 行 |
| `mkdir [-p]` | 建目录 |
| `touch` | 建空文件 |
| `cp [-r]` | 复制；目录需要 `-r` |
| `mv` | 移动/重命名 |
| `rm [-r] [-f] [-n]` | 删除；`-n` 是 dry-run |
| `stat 路径` | 元数据 |
| `glob 模式 [目录]` | 返回 `List[IO::Path]` |
| `grep [-inv] [-F|-E] 模式 文件...` | 行匹配 |
| `wc [-lwc] 文件...` | 行/词/字符数 |
| `which 命令` | Shell 内置或 PATH 外部命令 |

`ls` 的 `-h` 需要配合 `-l`；`-F` 给目录加 `/`；`-R` 在 TTY 下按目录流式输出
（找到一层显示一层，带 `目录:` 头），非 TTY 仍返回完整分组文本。

### 其他日常命令

| 命令 | 说明 |
|---|---|
| `clear` | 清屏；非 TTY 无控制码 |
| `history` | 本会话命令行 |
| `export KEY=VALUE...` | 写会话 env |
| `unset KEY...` | 删会话 env |
| `help [cmd]` / `help --find TEXT` | 帮助 / 搜索 usage |
| `jobs` | 后台任务表 |
| `open [--raw] [--external] 文件` | JSON/CSV → Table；Parquet 需 `--external` |
| `explore [路径]` | 结构化分页；无参数看上一格 |
| `describe [表名]` | 列摘要 Table；无参数摘要上一格 Table，表名需 `open-db(...)` |
| `hint [输入行]` | 上下文提示；不带参数查上一格 |
| `plugin list\|load PATH\|unload NAME\|info NAME` | 本地 Raku 插件（默认关闭，见下文） |
| `set -e/+e` | strict |
| `alias` / `unalias` / `config` / `hook` | 见 §10 |

### 路径与展开

- 参数里的 `$NAME` 按会话 env 展开
- `~` 展开到 `$*HOME`
- **Windows**：REPL/脚本默认允许访问其他盘符（`D:/`、`F:/`）；
  Agent 的显式 `--root` 仍只允许该 root 内，跨盘会报 `X::Rakuish::Sandbox`
- glob 由命令自己展开；不经过 shell
- **不支持**：管道 `|`、重定向 `>`、子 shell、heredoc、`&&` 的 shell 语义

#### glob 模式语法（0.65）

`Sys.glob` / Raku `glob('...')` / `glob` 命令支持：

| 写法 | 含义 |
|---|---|
| `*` / `?` | 不跨 `/` 的通配；`?` 只匹配一个非分隔符字符 |
| `**/`、`foo/**/bar`、`foo/**` | 任意深度 |
| `[abc]` / `[a-z]` / `[!x]` | 字符集（范围与取反） |
| `{a,b}` / `{a,{b,c}}` | brace 展开，支持嵌套 |
| `\` + `* ? [ ] { } , \` | 按字面匹配，不当元字符 |
| 裸 `\` | 归一化为 `/`（Windows 路径兼容） |

```raku
glob('*.{txt,md}')        # txt / md 两类文件
glob('{a,{b,c}}.txt')     # a.txt / b.txt / c.txt
glob('\{a,b\}.txt')       # 名字就叫 {a,b}.txt 的文件
```

Shell 薄层（`ls` / `cat` / `rm` 等）的文件名参数**只展开 `* ?`**：含
`{ } [ ]` 的参数会交回 Raku 求值（`glob` 命令除外），且 `!split` 会把 `\`
当转义前缀吃掉。要用转义或嵌套 brace，请写 Raku `glob('...')`。

#### 本地 Raku 插件（0.66 / ADR-0003）

插件就是一个本地 Raku 文件，最后一个表达式求值为 `Command` 对象（或
`List[Command]`）。**加载即执行本地 Raku 代码**，等同 `use` 一个本地模块，
所以默认关闭、只加载你信任的文件。

```text
config set plugins on
plugin load ./mytools.rakumod
plugin list
plugin info mytools.rakumod
plugin unload mytools.rakumod
```

```raku
# mytools.rakumod —— 注意 Result / BuiltinCommand 是模块导出的短名
use Rakuish::Command;
use Rakuish::Result;
BuiltinCommand.new(
    :cmd-name<hello>, :summary('示例插件'),
    :handler(-> $sys, |args { Result.new(:ok, :out('hello')) })
)
```

- 路径先经 `Sys.resolve` 做 root 校验，源码经 `Sys.read`，扩展名限
  `.rakumod` / `.raku`；不自动扫描目录、不联网、不持久化、不开机加载。
- 注册进会话 `CommandRegistry`：`registry.names` / `help()` /
  `cmd('hello', ...)` 可见；**不进** Shell 薄层的文本命令表。
- 与内建或其它插件重名返回 409；`unload` 只移除自己注册的命令。
- 插件的 `run($sys, ...)` 拿到会话 `Sys`，必须经它做文件 / 进程操作。
- Agent 的 op 白名单不暴露 `plugin`，Sandbox 不加载插件。

---

## 5. Raku 表达式与外部命令

### 外部命令

```raku
sys.exec('git', 'status', '--short');
```

或 REPL 便捷写法：

```text
! git status --short
```

argv-only：

- 参数原样传入，不解释 `$()`、反引号、`|`、`>`、`*`、`&&`
- 启动失败 `127`、超时 `124`、取消 `137`
- `Result` 永不抛，失败看 `ok/code/err`

### 交互式子进程（0.70 / ADR-0007）

默认 `!` 会捕获输出并在 30s 后超时，跑 `rakupp` / `python` / 编辑器这类
「自己不结束」的程序会卡住并被杀成 `code=124`。显式请求 TTY 直通：

```text
! --tty rakupp                  # 也可写 ! -t rakupp
! -- --tty foo                  # -- 之后 --tty 只是普通 argv
```

```raku
tty-exec('rakupp');             # Raku 原生入口，表达式里可用
```

- stdin / stdout / stderr 直接绑定当前 TTY，子进程输出**实时可见**；
- **没有超时**，由子进程的 `exit` / Ctrl-C 决定何时回来。0.73.0 起在 POSIX
  上做**进程组交接**：子进程自成一组并成为终端前台，Ctrl-C 由终端驱动直接
  投给它，父进程根本收不到（V-175 / [ADR-0010](ADR-0010-job-control-feasibility.md)）。
  之前的「父进程临时吞 SIGINT」只保留在 spawn 与切前台之间的微秒级窗口，
  Windows 与降级路径仍走那套。0.72.3 用真 PTY 回归钉住的契约不变：
  子进程退出、宿主存活、下一格仍可输入求值、之后 Ctrl-C 仍是输入中断
  （V-173 / [ADR-0009](ADR-0009-tty-exec-sigint-contract.md)）；
- 进程组交接带来的实际差别：子进程执行 `kill(0, SIGTERM)`（对自己所在
  进程组发信号，现实中清理进程组的工具会这么做）**不再打死宿主 REPL**；
  `Result.value<job-control>` / `<fg-restored>` / `<pgid>` 可查。
  `cwd` 与当前目录不同时依赖 `posix_spawn_file_actions_addchdir_np`
  （glibc ≥ 2.29 / macOS 10.15+），缺失则降级回同组语义并标
  `job-control=False` + `job-control-reason`；
- 0.72.4 起，交接前保存宿主 termios，子进程退出（含非零 / 被信号打断）后
  自动恢复，子进程留下的 raw mode 不会固化到下一轮 prompt；
  `Result.value<termios-restored>` 标记成败（V-174 / ADR-0009 §0）；
  Windows 用 `GetConsoleMode` / `SetConsoleMode`，0.72.5 已在真 ConPTY 与
  conhost 下实测（`503 → 1008 → 503`），见 `tools/tty-termios-win.py`；
- 结束后给一行交接摘要（`↩ exe 已退出 · code=N · 耗时`），然后回到 Rakuish；
- 子进程输出**不进** `_` / `Out[n]`，`Result.value` 只有退出码 / 耗时 / exe / argv；
- `cwd` 仍过 `Sys.resolve` root 校验，`env` 仍是会话属性；
- 非 TTY（管道 / 脚本 / Agent）明确报错 `code=127`，提示改用 `exec(...)`；
- 普通 `!` 超时（`code=124`）时 hints 会提示改用 `tty-exec(...)`。

不做自动探测：只有你显式写了 `--tty` / `tty-exec` 才走直通。
边界见 §12 与 [ADR-0007](ADR-0007-tty-passthrough.md)。

### PTY 捕获（0.72 / 0.72.2，SPEC V-170 / V-172）

`tty-exec` 是“把当前终端借给子进程”，不捕获输出。需要“子进程看到 TTY，
但父进程拿回输出、超时、取消”时用 PTY：

```raku
my $r = pty-exec('python', '-c', 'print("hello")',
                 :timeout-ms(5_000), :cols(100), :rows(30));
$r.out;       # 捕获的 stdout（stderr 已按 PTY 语义合流）
$r.code;      # 124 = 超时；0 = 正常
$r.value<pty>; # True
```

```text
pty-exec('cmd', '/c', 'echo hi')   # DSL / 表达式里可用
```

- 分配 `Proc::Async` 的 `:pty(:cols,:rows)`；**需要 Rakudo ≥ 2025.12**。
  0.72.2 起先用版本 + isatty 探针双检，不支持时直接返回 `code=127`
  （`value<pty>/<tty>` 为 `False`），不会静默把普通管道当 PTY 用；
- 默认剥离 ANSI / OSC / 非换行控制字符，保留文本与换行；
  `max-bytes` 限制的是**剥离后文本**的字节数（0.72.2 起先剥离再截断，
  控制序列不占配额、不会留半截 `ESC[` 残片）；
- `timeout-ms` 到点 kill，`code=124`；
- `Result.value` 带 `pty-capable` / `stderr-merged` / `stdin-unavailable` /
  `strip-ansi`：PTY 下 stderr 与 stdout 合流，`err` 恒为空不是遗漏；
- **当前不提供 stdin 写入**：Rakudo 的 `Proc::Async :pty` 没有可靠 stdin
  通道；拿它跑 `rakupp` 这类需要键盘的 REPL 会一直等到超时（`code=124`），
  那种场景请用 `tty-exec` / `! --tty`；
- **Windows ConPTY 大输出可能丢尾部 chunk**（驱动层行为，Linux 未复现）；
  需要逐字节完整输出时让子进程写文件再读，见
  [AUDIT-FIXES-0.72.2](AUDIT-FIXES-0.72.2.md) §3；
- Agent 的 `pty_exec` 是显式双开关 op，见 §11。

### 方法链

```raku
my $t = ls-table('.');
$t.where({ .<type> eq 'file' })
  .select('name', 'size')
  .sort-by('size', :reverse)
  .first(10)
  .to-text;
```

### `cmd` 桥

只在 REPL / 绑定 Session 的上下文可用：

```raku
my $t = cmd('ls --json .');
$t.where({ .<type> eq 'file' }).elems;
```

`cmd` 失败抛 `X::Rakuish::CommandFailed`；`cmd-result` 返回完整 `Result`。

### `==>` 的边界

`==>` 是 Raku feed 操作符，只接**例程调用**，左值作为最后一个参数；
它不能写 `.where(...)`。多参数 Table 操作继续用方法链。

```raku
sub files($t) { $t.where({ .<type> eq 'file' }) }
cmd('ls --json .') ==> files();
```

---

## 6. 脚本与 DSL

```raku
#!/usr/bin/env rakuish
use Rakuish::DSL;

for ls('.', :recursive).grep(*.extension eq 'rakumod') -> $f {
    my $text = read($f);
    write($f, $text.subst(/TODO/, 'DONE'), :atomic);
}
```

### DSL 导出

`ls / ls-table / read / cat / write / append / stat / rm / cp / mv / mkdir /
glob / exec / cmd / cmd-result / cd / pwd / cwd / resolve / env / get-env /
set-env / unset-env / echo / try-op / timed / peach / help / recent`

### 事务 / 并行

```raku
my $db = open-db(':memory:', :!read-only);
$db.begin;
$db.execute('insert into t values (?)', 1);
$db.commit;

my @sizes = peach(ls('docs'), { .s }, :degree(4));
```

---

## 7. 结构化数据

### Table

```raku
my $t = ls-table('.');          # name/type/size/modified/path
$t.where({ .<type> eq 'file' });
$t.get('name');
$t.select('name', 'size');
$t.sort-by('size', :reverse);
$t.first(10);
$t.limit(10).offset(5);
$t.distinct('type');
$t.join($other, :on<name>);
$t.count;
$t.sum('size');
$t.mean('size');
$t.to-text;
$t.to-json;
$t.to-markdown;
```

类型：

`int / num / str / bool / datetime / list / map / any`

```raku
$t.column-type('size');   # int
$t.schema.to-text;        # name/type/nullable
```

### JSON / CSV

```raku
my $json = open-data('data.json');
my $csv  = open-data('data.csv');
save-data('out.json', $json);
save-data('out.csv', $csv);
```

REPL：

```text
open data.json
open --raw README.md
ls --json .
```

### explore

```text
explore data.csv
explore docs/
ls --json .
explore
```

TTY 下 Enter 翻页、`q` 退出；`RAKUISH_PAGER=never` 强制非交互。

### Parquet 与大结果（0.64）

```raku
my $t = open-data('sales.parquet', :allow-external);   # → Table
save-data('out.parquet', $t, :allow-external);
my $small = $db.query('select * from big', :max-rows(100));
$t.batches(:size(1000)).map({ .to-text });             # 惰性分批 Seq
$t.to-text(:max-rows(20));                             # 展示上限
```

| 项 | 规则 |
|---|---|
| 扩展名 | `.parquet` / `.pq` → `Table` |
| 开关 | 必须显式 `:allow-external`；Shell 命令是 `open --external` |
| 路径 | 先经 `Sys.resolve` 做 root 校验；越界抛 `X::Rakuish::Sandbox` |
| Agent | op 白名单不暴露该开关；引擎默认 `enable_external_access=false` |
| 空值 | 导出时按列类型写成 0 / 0.0 / False / 空串（不写 NULL） |

`:max-rows` 在 DuckDB / SQLite 里都把 `LIMIT` 下推进 SQL，物化前截断；
`Table.batches` 是惰性分批 `Seq`，`to-text` / `to-markdown` / `to-json(:$max-rows)`
是展示上限（`to-json` 只截行，保持合法 JSON）。**`Table` 本身仍是物化值**；
0.67 起真正的惰性查询由 `Engine.cursor()` 提供（见 §8「流式 Cursor」）。

---

## 8. 数据引擎：DuckDB / SQLite

DuckDB 是可选分析引擎；SQLite 是可选事务/小数据引擎。核心不强制安装。

### DuckDB

```raku
my $db = open-db(':memory:', :!read-only);
$db.execute('create table t (x int)');
$db.execute('insert into t values (?)', 1);
$db.query('select * from t').to-text;
$db.close;
```

### SQLite

```raku
my $db = open-db(':memory:', :engine<sqlite>, :!read-only);
$db.execute('create table t (x int)');
$db.execute('insert into t values (?)', 1);
$db.query('select * from t').to-text;
$db.close;
```

### 流式 Cursor（0.67）

```raku
my $c = $db.cursor('select * from big_table', :batch-size(500), :max-rows(5000));
for $c.batches -> $batch { say $batch.elems }   # 惰性 Seq of Table
$c.rows.head(3);            # 惰性逐行 Hash
$c.take(10).to-text;        # 只取前 10 行并立即释放
$c.close;                   # 幂等；拉完 / 达到上限自动 close
```

- DuckDB 用 `:stream` + 惰性 `chunks`，SQLite 用逐行 `hash`；**不预先物化整表**。
- 消费到哪一批，查询就走到哪一批；提前退出时请显式 `close`（`DESTROY` 只兜底）。
- 一次性、单连接；不提供可恢复游标、事务一致性快照或并发修改下的稳定视图。
- 不支持的引擎抛 `X::Rakuish::Unsupported`，不静默退化成 `query()`；
  `query()` 与 `Table.batches` 行为不变。
- Agent `sql_query` 不暴露 Cursor，但 `query(:max-rows)` 会在物化前下推 LIMIT。
- 设计取舍见 [ADR-0004](ADR-0004-cursor-worker.md) §3 / SPEC V-158。

### CSV 受控外部读写（0.68）

```raku
my $t = open-data('sales.csv', :allow-external);   # DuckDB 推断 int / num
save-data('out.csv', $t, :allow-external);          # COPY ... FORMAT CSV, HEADER
```

- 不加 `:allow-external` 时 `.csv` 仍走 `Sys.read` / `Sys.write`，
  列值都是 `Str`；加了开关才由 DuckDB 做类型推断与写出。
- 路径经 `Sys.resolve` root 校验，Agent 的 op 白名单不开放；与 Parquet
  共用同一套显式授权（V-152 / V-160）。
- `Engine.read-csv(:max-rows)` 会下推 `LIMIT`；驱动错误统一为
  `X::Rakuish::Data`。不做分区写出或按 schema 强制类型。
- 设计取舍见 [ADR-0005](ADR-0005-data-workbench.md) §2。

### CSV 方言参数（0.69 / ADR-0006 §2）

```raku
my $t = open-data('semi.csv', :allow-external,
                  :csv-options({ delimiter => ';', header => False,
                                 skip => 1, 'all-varchar' => True }));
save-data('out.csv', $t, :allow-external,
          :csv-options({ delimiter => ';', header => False }));
```

| 选项 | 读 | 写 | 说明 |
|---|---|---|---|
| `delimiter` | ✅ | ✅ | 单字符，如 `';'`；分号合法 |
| `quote` / `escape` | ✅ | ✅ | 单字符 |
| `nullstr` | ✅ | ✅ | ≤64 字符，写出时映射为 `NULL '...'` |
| `header` | ✅ | ✅ | Bool；`False` 写出时无表头 |
| `skip` | ✅ | ❌ | 0..100000，写出时明确拒绝 |
| `all-varchar` | ✅ | ❌ | Bool，写出时明确拒绝 |

- 未知键明确报错（拼错 `delimeter` 会被发现），不静默忽略。
- 读路径选项全部 `?` 参数绑定，值不进 SQL；写路径是 `COPY` 字面量，
  先过字符校验（不接受单引号 / 反斜杠 / 换行 / NUL）。
- **方言只在 Raku 层**：Shell `open --external` 不做第二套参数语法；
  必须 `.csv` + `:allow-external`，否则明确拒绝。默认文本路径不变。
- 空选项生成的 SQL 与 0.68 完全一致；路径仍经 `Sys.resolve`，Agent 不开放。

### describe 值 API（0.69 / ADR-0006 §3）

```raku
my $t = open-data('sales.csv', :allow-external);
describe($t).where({ .<nullable> })       # 摘要本身也是 Table
describe('sales')                         # 需先 open-db(...)
describe                                  # 会话命令：无参数摘要上一格 Table
```

- 返回结构化 Table，列固定为
  `name / type / nullable / non_null / distinct / total / sample`；不是文本报告，
  可继续 `.where` / `.sort-by` / `.to-json`。`:sample(N)` 控制样例值个数（0..20）。
- `Engine.describe` 是角色默认实现，只调用 `schema()` / `query()`，DuckDB 与
  SQLite 都可用；聚合失败时该列统计留空，不编造数字。
- 表名只允许字母 / 数字 / 下划线且不以数字开头（防注入）；未注册 Engine 时
  表名形态明确报错并提示 `open-db(...)`。
- 不承诺大表 `count(distinct ...)` 的性能，可用既有查询超时限制。


### SQL 上下文补全（0.68 / 0.71）

`open-db` 会把新建引擎注册为当前会话 Engine（`repl.engine` 可读）。在
`$db.query('select * from sa` 里按 Tab，`Session.completions` 会先识别 SQL
字符串上下文，从 `tables()` / `schema()` 取元数据补表名 / 列名 / 关键字。

- 识别 `'...'` / `"..."` 字符串，以及 0.71 起的不插值 `q[...]` / `q{...}` /
  `q(...)` / `q<...>`；调用名是 `query/cursor/execute/sql(...)` 等白名单，
  也接受 `query(sql => '...')` / `query(:sql('...'))` 具名形态
  （不解析 `qq` / `Q` / heredoc / 嵌套 `q[...]` 或 SQL AST）。
- 0.69：`from sales s` / `join users as u` 建立别名映射，`s.am` 只补该表的列；
  关键字按片段大小写输出（`SEL` → `SELECT`、`Sel` → `Select`）。
- `q[...]` 适合 SQL 里含字符串字面量的场景：`$db.query(q[select * from sales
  where region = 'east' and am` 里按 Tab 仍能补 `amount`。
- **SQL AST 级补全明确不做**（ADR-0006 §4）：不引解析器依赖、两引擎方言不同、
  Tab 热路径不划算。
- 纯函数、只读元数据；驱动缺失 / 库被锁时安静退化，不让 Tab 崩 REPL。
- 原 Shell 补全（命令名 / 路径 / help 参数）完全不变；非 TTY 不触发。
- 见 [ADR-0005](ADR-0005-data-workbench.md) §3 / [ADR-0008](ADR-0008-input-interrupt-sql-forms.md) §3.2 /
  SPEC V-161 / V-169。

### 只读与安全

- 默认只读；`execute` / DDL / 事务会拒绝
- DuckDB 默认 `enable_external_access=false`
- SQL 不能借引擎文件函数绕过 `Sys` root

### 事务

```raku
$db.begin;
$db.execute('insert into t values (?)', 1);
$db.rollback;    # 或 $db.commit
```

### 查询超时

```raku
my $db = Rakuish::Data::Engine::DuckDB.new(
    :max-execution-time-ms(1000),
);
```

SQLite 同样支持 `max-execution-time-ms`（通过 `sqlite3_interrupt`）。
Agent 用 `--sql-timeout-ms` 统一配置。

**错误模型（0.64）**：SQL 驱动抛出的异常统一包装成 `X::Rakuish::Data`，
不把驱动堆栈直接暴露给 REPL / Agent；只读拒绝、沙箱越界、查询超时仍分别是
`X::Rakuish::Unsupported` / `X::Rakuish::Sandbox` / `X::Rakuish::Limit`。

---

## 9. 文件与进程 API

### Sys

```raku
my $sys = Rakuish::Sys.new(:root('/work'), :cwd('/work'));
my $text = $sys.read('README.md');
$sys.write('README.md', $text, :atomic);
my @md = $sys.ls('docs', :recursive);
my $r = $sys.exec('git', 'status', '--short');
```

| 方法 | 说明 |
|---|---|
| `read / write / append` | 文本或 `:bin`；`write` 默认原子 |
| `ls / glob / stat` | `IO::Path` |
| `rm / cp / mv / mkdir` | 返回 `Result` |
| `exec / spawn / wait / cancel` | argv-only |
| `tty-exec` | 交互式子进程：TTY 直通、无超时、不捕获输出（0.70 / V-167） |
| `cd / get-env / set-env / env` | 会话级 |
| `resolve` | canonical + root 校验 |
| `jobs / job` | 后台任务 |
| `try-op` | 异常收敛为 Result |

### 错误模型

- 读/写/列目录/stat：抛异常
- `rm/cp/mv/mkdir`：返回 `Result`
- `exec`：永不抛；看 `ok/code`
- Agent 边界：`try-op` 收敛

### Result 渲染

```raku
$r.render('text');
$r.render('json', :pretty);
$r.render('markdown');
$r.to-json;
```

---

## 10. 配置、alias、hook

配置文件默认 `~/.rakuish-config.json`，`RAKUISH_CONFIG` 可覆盖。

```text
alias ll=ls -alh
alias
unalias ll

config set theme dark
config get theme
config unset theme
config

hook add start echo "hello"
hook
hook run start
hook clear start
```

- alias 只展开 Shell 命令行第一个词，最多 10 层
- `start` hook 在 `-e` / 脚本 / 交互求值前运行
- hook 是**本地可信配置**，不要放不可信内容

---

## 11. Agent 结构化服务

Agent 不是 shell 字符串服务；请求是 JSON 对象，每行一个。

```bash
raku bin/rakuish-agent --root /work --token SECRET
raku bin/rakuish-agent --root /work --token SECRET --mode tcp
raku bin/rakuish-agent --root /work --token SECRET --allow-exec --allow git
raku bin/rakuish-agent --root /work --token SECRET --allow-exec --allow-pty --allow git
raku bin/rakuish-agent --root /work --token SECRET \
  --allow-sql --db analytics.duckdb --engine duckdb
```

请求：

```json
{"id":1,"token":"SECRET","op":"read_file","path":"a.txt"}
{"id":2,"token":"SECRET","op":"write_file","path":"b.txt","content":"hi"}
{"id":3,"token":"SECRET","op":"exec","argv":["git","status"]}
{"id":4,"token":"SECRET","op":"sql_query","sql":"select * from t where id = ?","params":[7]}
{"id":5,"token":"SECRET","op":"pty_exec","argv":["python","-c","print('hi')"],"timeout_ms":5000,"cols":100,"rows":30}
```

op：

`read_file/read`、`write_file/write`、`list_dir/list/ls`、`stat`、`exec`、
`pty_exec`、`rm`、`mkdir`、`cp`、`mv`、`glob`、`sql_query`

码：

`400` 坏 JSON、`401` token、`403` 策略、`404` 未知 op、`500` 执行异常、
`504` 请求 deadline。

### 默认安全

- 显式 `--root`
- 只绑 `127.0.0.1`
- OS CSPRNG token；不指定时生成并打印到 stderr
- `exec` 默认关闭；白名单绝对路径 canonical 匹配
- `pty_exec` 默认关闭；需同时 `--allow-exec --allow-pty`，并过同一命令白名单
- `sql_query` 默认关闭；只读、参数化、行数上限
- 请求级 env 只允许 `LANG/LANGUAGE/TZ/LC_*`
- 审计 JSONL；SQL 只记指纹和参数个数
- `serve-once` 单连接，支持 idle timeout
- `--worker` 默认关闭；配置（含 token）经子进程 stdin 传入，不进命令行

### 超时

```bash
--idle-timeout-ms 30000
--sql-timeout-ms 30000
--request-timeout-ms 30000
```

请求 deadline 到点**立即**返回 504（0.63 起）：dispatch 在独立任务里执行，
超时响应不等待底层操作结束，后台结果直接丢弃，连接继续可用。
`exec` / SQL 会把实际执行超时压到 deadline 内，因此这两类操作会真的被终止；
Raku 线程无法强杀，纯文件 I/O 这类不可取消操作仍会在后台跑完
（[ADR-0002](ADR-0002-agent-serve.md) §2，不宣称 OS 级进程隔离）。
这一段描述的是**默认（非 worker）模式**；0.67 的 `--worker` 提供真正的
OS 硬取消，见下节。

### 常驻多客户端（0.63）

```bash
raku bin/rakuish-agent --root /work --token SECRET --mode tcp --serve
raku bin/rakuish-agent --root /work --token SECRET --mode tcp --serve \
  --max-connections 8 --idle-timeout-ms 30000
```

- 默认 `--mode tcp` 仍是**单连接** `serve-once`；`--serve` 才启动常驻 accept loop。
- 每连接独立 `Sys`（cwd / env / jobs）、独立审计 `session`（`<base>-cN`）；
  配置 `--db` 时每连接新建只读 Engine，不共享连接。
- `--max-connections` 默认 16，超限关闭新连接并计数；Ctrl-C 优雅停止。
- 安全默认不变：token / root / 白名单 / 审计脱敏 / 参数只能调小。

### 连接级 worker 与硬取消（0.67）

```bash
raku bin/rakuish-agent --root /work --token SECRET --mode tcp --serve --worker
# 可选：--worker-hard-timeout-ms N（默认 request-timeout-ms + 1000）
```

- 每连接启动**一个常驻** worker 子进程（不是按请求 fork），请求经 stdin/stdout
  JSONL 转发；一次连接只付一次 Rakudo 启动成本。
- 子进程报 504 或父进程 watchdog 到点 → `kill` 整个 worker，卡住的纯文件 I/O
  也随进程消失，而不只是「响应提前」。
- 审计集中在父进程并脱敏（不含 token / 内容 / SQL 原文），子进程不写审计文件；
  每连接独立 session。
- **边界**：硬取消后该连接随即关闭，客户端需重连（非 worker 模式连接继续可用）；
  不保证杀掉 worker 派生的孙进程；不是 daemon、不做开机自启。
- 默认关闭；不开时与 0.63 行为完全一致。见 [ADR-0004](ADR-0004-cursor-worker.md) §4。

---

## 12. 错误、限制与安全边界

- root 是同用户文件策略，不是 OS 级隔离
- symlink 逐段 `readlink` + canonical 双重校验（0.67 / V-157）；Windows 创建 symlink 需权限
- `ls` 递归默认 `max-entries=100000`；`cp -r` 预检条目数
- 读写默认 1 MiB；`exec` 输出上限 1 MiB
- `serve-once` 只处理一个连接；常驻多客户端请用 `--serve`（0.63）
- 嵌套 `exit` 保持 Raku 进程语义；只有整行 `exit` / `exit N` 映射为会话退出
- 类型声明跨格只覆盖**纯声明格**：混合格、含 phaser 的格不缓存；
  类型对象身份不跨格，`.^name` 带外层包名（SPEC V-153）
- glob 完整语法在 `Sys.glob` / Raku `glob()` 层；Shell 薄层文件名参数只展开 `* ?`
- Vi/Helix 模态依赖 `Terminal::LineEditor` 0.0.23 内部结构；构造失败自动回退
  `emacs`；`tools/tty-check.py` 已自动验到第一个 prompt 之后的交互，真实终端
  光标手感仍需人工确认；normal 模式下粘贴前先按 `i`
- 本地 Raku 插件**不是沙箱**：加载即执行本地代码，默认 `off`，只加载可信文件；
  Agent 不开放 `plugin` op（ADR-0003 / SPEC V-156）
- Table 类型按值推断；混合列可能降为 `any`
- Parquet 读写是显式授权的外部访问例外（`:allow-external`），Agent 不开放
- `query()` 仍返回物化 `Table`；惰性查询用 `Engine.cursor()`（0.67 / V-158），
  游标一次性、单连接，无事务一致性快照
- SQL 驱动错误统一为 `X::Rakuish::Data`；只读 / 沙箱 / 超时异常原样抛
- `--worker` 默认关闭；开启后超时会 kill 整个连接进程并断连，不保证杀孙进程
- Parquet / CSV 的 `:allow-external` 是 V-129 的两个显式例外，Agent 不开放；
  0.69 的 CSV 方言只是给这两个例外加选项，不新增第三个例外
- CSV 方言选项只在 Raku 层；Shell 薄层不解析方言；写路径不支持 `skip` /
  `all-varchar`，不承诺编码 / 多行字段精细控制
- `describe` 返回结构化 Table，无 Engine 时表名形态报错；大表统计不承诺性能
- SQL 补全不解析 AST（V-908），不识别 `qq` / `Q` / heredoc / 嵌套 `q[...]`；
  别名是词法启发式（0.71 起支持单层 `q[...]`）
- REPL 的 `open-data` / `save-data` 解析到 DSL 版本（V-165 修复）；脚本里
  显式调 `Rakuish::Data::open-data($sys, ...)` 仍可用
- SQL 补全只识别引号字符串 + 元数据启发式；不做 SQL AST 级补全或方言参数
- Ctrl-C 只中断输入阶段，不中断正在求值的 cell；行编辑器子类构造失败时
  回退到原生 `CLIInput`，此时 Ctrl-C 退回「abort == EOF」的 0.70 行为
- `tty-exec` / `! --tty` 的输出不可捕获、不进 `_` / `Out[n]`；没有超时保护，
  必须自己结束子进程；不自动探测交互式程序，Agent 不开放该入口（V-167 / ADR-0007）
- `tty-exec` 期间 Ctrl-C 的归属契约见 V-173 / ADR-0009：0.73.0 起 POSIX 上
  已做进程组交接（V-175），不再依赖「父进程吞 SIGINT」；终止符仍是窗口内
  的 tap 与 Windows 老路径。**不做** `&` / `jobs` / `fg` / `bg` / Ctrl-Z
  作业管理 —— Ctrl-Z 会把子进程停住而 REPL 等在那儿，这是明确划出范围外的；
  termios 快照 0.72.4 起已实现（V-174），canonical 基线的位图回归见 `t/31`，
  Windows 控制台模式在 ConPTY / conhost 下由 `tools/tty-termios-win.py` 自查
  （0.72.5，`503 → 1008 → 503`）；
  真终端模拟器里的手感仍建议人工确认（`tmp/TTY-CHECK.md` §7.1）；
  子进程忽略 SIGINT 时仍会一直等
- TTY 直通期间行编辑器的 `start-parser` 理论上仍有一次挂起读；PTY 集成测试
  验证首字符不丢，若某平台确实吞键，退路是 `config set edit-mode emacs`
- `! --tty` 在管道 / 脚本里返回 `code=127`，不会退化成 30s 捕获式执行

---

## 13. 故障排查

### `!` 里的程序 30 秒后被杀（code=124）

这通常是想跑交互式程序（REPL / 编辑器 / 分页器）。默认 `!` 会捕获输出并设
30s 超时；改用 `! --tty <exe>` 或 `tty-exec('<exe>')`，输出会实时出现且不再
超时，退出后回到 Rakuish。非 TTY 环境两者都会明确拒绝（V-167）。

### `zef install .` 报 precomp / exe locked

先结束残留 `rakuish` / `rakudo` 进程，再：

```bash
zef install . --force-install
```

### `read docs/ADR-0001.md` 被当 Raku 表达式

0.52.1 起 `read` 是 Shell 命令，按字面路径读取；确认版本 >= 0.52.1。

### `explore` 在测试/管道下没有分页

非 TTY 直接返回全文；要强制关闭交互：

```text
RAKUISH_PAGER=never
```

### Windows 时间戳异常

`IO::Path.modified` 可能不可信；`Stat` 如实返回，`recent` 降级，不编造时间。

### Agent 403

- 未 `--allow-exec` / `--allow`
- argv 绝对路径不在白名单
- 请求 env 含危险键
- 未 `--allow-sql` / `--db`

---

## 14. API 速查

```raku
# Sys
$sys.read / write / append / ls / stat / rm / cp / mv / mkdir / glob
$sys.exec / tty-exec / spawn / wait / cancel / jobs / job
$sys.cd / get-env / set-env / env / resolve / try-op

# Data
ls-table / open-data / save-data
Table: where/get/select/sort-by/first/last/limit/offset/each/count/
       sum/mean/min/max/distinct/join/schema/describe/column-type/
       to-text/to-json/to-markdown

# Engine
open-db(:engine<duckdb|sqlite>)
query/execute/tables/schema/begin/commit/rollback/close

# REPL
_ / Out[n] / cmd / cmd-result / explore
alias / unalias / config / hook / which / help --find
perf [N] / timed { ... } / bench({ ... }) / repl.perf-hist
tty-exec('rakupp') / ! --tty rakupp
```

更完整的条款和测试对应关系见 [`SPEC.md`](../SPEC.md) 与 [`HANDOFF.md`](../HANDOFF.md)。
