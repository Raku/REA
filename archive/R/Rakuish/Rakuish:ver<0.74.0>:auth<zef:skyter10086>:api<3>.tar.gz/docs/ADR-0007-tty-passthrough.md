# ADR-0007：交互式子进程的 TTY 直通（0.70）

- **状态**：已接受（2026-11-12）
- **相关**：ADR-0001（argv-only / Sys 收敛）、ADR-0002（请求级取消）、
  SPEC V-116 / V-129 / V-167、ROADMAP §5

## 1. 问题

在 REPL 里跑另一个交互式程序（`rakupp`、`python`、`psql`、编辑器 …）时，
输入 `! rakupp` 会：

1. 卡住看不到任何输出 —— `Sys::Proc.spawn` 把 stdout/stderr 接进 `Channel`，
   `Handle.wait` 要等进程结束才把文本交给渲染层；
2. 30 秒后被 `default-timeout-ms` 杀掉，返回 `code=124`；
3. 失败格不进 `_` / `Out[n]`，界面看起来「退回上一格」。

实测复现（把超时压到 2s）：

```
NESTED> ready            # 子进程已输出，但被父进程收在 Channel 里
elapsed=2057ms ok=False code=124
```

根因不是「超时太短」，而是**捕获式执行模型不适合交互式子进程**：
它假设子进程会自己结束、输出是有限的、stdin 由调用方提供。交互式 REPL
三条都不满足。

## 2. 约束（不可突破）

- **V-129 / ADR-0001**：所有进程操作只经 `Sys`；外部命令永远 argv-only，
  不拼 shell 字符串；`cwd` / `env` 是会话属性，不改宿主全局状态。
- **V-116**：管道 / 非 TTY 下 stdout 必须保持纯净，不能出现控制序列或
  交互提示。
- **默认行为不变**：`! git status`、`exec('...')`、`Handle.wait` 的捕获、
  截断、超时、审计、`Result` 值语义全部保持原样。
- **Agent op 白名单不暴露交互式入口**：JSONL 服务没有 TTY，也不该让远程
  请求接管终端。

## 3. 决策

### 3.1 新增「显式 TTY 直通」，不做自动探测

不猜子进程是不是 REPL。用户显式声明：

```raku
tty-exec('rakupp')                  # Raku 原生（DSL）
! --tty rakupp                      # REPL 的 ! 便利入口（也可写 -t）
! -- --tty foo                      # -- 之后是字面 argv，不解析元选项
```

自动探测（按 exe 名白名单、按「多久没输出」推断、按 stdin 是否可读）
都不可靠且会悄悄改变 `!` 的语义，明确不做。

### 3.2 `Sys::Proc.tty-exec` 的四条差异

| | `exec()`（默认） | `tty-exec()` |
|---|---|---|
| stdin | 继承 / 可 `:in` 注入 | `bind-stdin($*IN)`，真终端直通 |
| stdout/stderr | `Channel` 捕获、可截断 | `bind-stdout($*OUT)` / `bind-stderr($*ERR)`，实时可见 |
| 超时 | `default-timeout-ms`（30s） | **无超时**，由用户 `exit` / Ctrl-C 结束 |
| 返回值 | `Result.value` 含输出字节数与审计字段 | `Result` 只含退出码 / 耗时 / exe / argv；**不捕获子进程输出** |

- 入口守卫：`$*IN.t && $*OUT.t` 必须都为真，否则抛
  `X::Rakuish::Unsupported` 并收敛成 `code=127` 的 `Result`，明确告诉用户
  「管道/脚本请用 `exec(...)`」。这保证 V-116 不被破坏。
- `cwd` / `env` 仍经 `Sys.!proc-opts`：`cwd` 过 `Sys.resolve` root 校验，
  `env` 用会话 Hash，传给 `Proc::Async.start(:cwd, :ENV)`（大写 ENV 是
  Rakudo 的坑，见 `Sys/Proc.rakumod` 顶部注释）。
- 不注册后台 job（`%!jobs` 是给 `spawn/wait` 的异步句柄），因为本调用
  是同步等待、进程结束即返回。

### 3.3 TTY 所有权交接

`Terminal::LineEditor` 的 `read-input` 是
`self.enter-raw-mode; LEAVE self.leave-raw-mode;`，所以 `cli.prompt()`
**返回后端子已回到规范模式**——这正是交接终端的正确时机，不需要在
`bin/rakuish` 里手工 `stty sane`。父进程在等待期间：

- 用 `signal(SIGINT).tap` 临时吞掉 SIGINT，避免用户按 Ctrl-C 时
  **父进程**被默认处理器带走；Ctrl-C 由前台子进程自己处理；
  `LEAVE` 关闭 tap 恢复默认行为。0.72.3 用真 PTY 回归把这条契约钉住
  （[ADR-0009](ADR-0009-tty-exec-sigint-contract.md) / SPEC V-173），
  实测 `LEAVE` 后默认处理器确实恢复；0.72.4 在同一 `LEAVE` 里加了宿主
  termios 快照恢复（V-174）。
- **0.73.0 起 POSIX 上改为进程组交接**（[ADR-0010](ADR-0010-job-control-feasibility.md) §6 /
  SPEC V-175）：`posix_spawnp(SETPGROUP)` + `tcsetpgrp` 让子进程成为终端
  前台，Ctrl-C 由终端驱动直接投给它，父进程收不到；上面的 SIGINT tap 只
  保留在 spawn 与切前台之间的微秒级窗口。Windows 与降级路径仍走本节原方案。
- 仍然**不做**完整的 job control：没有 `&` / `jobs` / `fg` / `bg` / Ctrl-Z
  作业管理。Raku 没有跨平台稳定的 job control，本地单连接 REPL 也不需要
  shell 语法（与 V-90x 一致）。

已知边界：`CLIInput` 的 `start-parser` 在 `leave-raw-mode` 后可能仍有
一次挂起的 `$*IN.read(1)`。理论上它会与子进程争抢第一个按键；0.70 的
真 PTY 回归专门验证了「首字符不被吞」。若某个平台确实丢键，退路是
`config set edit-mode emacs` + 直接 `tty-exec(...)`，不做 fd 级 dup2
劫持（那会改进程全局状态，违反 §2）。

### 3.4 渲染与退出语义

- `Result.op = 'tty-exec'`：不在 `SHELL-OPS` 里，渲染器不会套 `Out[n] =`。
- 子进程结束后 `out` 给一行短摘要（`↩ exe 已退出 · code=N · 耗时`），
  前面带换行，把光标从嵌套 REPL 的任意列位置拉回行首。
- `ok` = 子进程退出码 0；失败时也照常走 `strict-result`（`set -e` 会
  退出 REPL，与 `!` 一致）。
- `!` 命令超时（`code=124`）时入口补一条提示，把用户引到
  `tty-exec(...)`，而不是让他反复撞 30s 墙。

### 3.5 0.72：PTY 捕获（与 tty-exec 并存）

`tty-exec` 解决“把终端借出去”，不解决“子进程看到 TTY、父进程还要输出”。
0.72 增加 `Sys.pty-exec`，用 `Proc::Async.new(:pty(:cols,:rows))`：

- stdout 捕获；PTY 的 stderr 与 stdout 合流；
- 默认剥离 ANSI/OSC/C0（保留换行/Tab）；
- `timeout-ms` 到点 kill，`code=124`；
- `max-bytes` 流式截断；
- Agent `pty_exec` 默认关闭，必须 `--allow-exec --allow-pty` +
  命令白名单，且 cwd/root/env 继续过 Sandbox。

**边界**：Rakudo 的 `Proc::Async :pty` 没有可靠 stdin 写入通道，所以
`pty-exec` 不是完整交互会话，不能替代 `tty-exec` 的实时键盘。它的目的
是“程序以为自己有终端 + 父进程拿到可截断输出 + 可超时/杀”。不要把它
宣传成 Agent 的 `tty_exec`：Agent 仍不开放 `tty_exec`。

## 4. 明确不做

| 不做 | 理由 |
|---|---|
| 自动识别交互式程序 | 不可靠，且会改变 `!` 的默认语义 |
| 捕获交互式输出做 `_` / `Out[n]` | 与「实时可见」冲突，且无限输出无法截断 |
| 交互式子进程参与后台 `jobs` / `cancel` | 同步等待，句柄生命周期就是这一格 |
| Agent 暴露 `tty_exec` op | 无 TTY、无法审计输出、等价于让远程请求接管终端 |
| 嵌套子进程的多路复用 / 会话恢复 | 超出本地 REPL 范围 |
| 为 Windows 特殊处理控制台模式 | `Proc::Async.bind-stdio` 已是跨平台下限；实测不了的部分如实记录 |

## 5. 验证

- `t/26-nested-repl.t`：非 TTY 拒绝、默认 `!` 超时语义不变、元选项解析、
  cwd/env 经 Sys、Agent 白名单、真 PTY 下嵌套子进程（WSL `script` 或
  Python PTY 代理）首字符不丢、输出实时、退出码回传。
- 双平台全量回归 + `zef install` 冒烟。
- `tools/tty-check.py`（Linux / WSL）：字节级 DSR 应答的真 PTY 自检，
  25 项检查覆盖 banner / 彩色 prompt / Vi 徽标 / Tab 与 SQL 补全 /
  Ctrl-C 中断 / describe / 嵌套 REPL 直通，以及 0.72.3 新增的
  `tty-exec` 期间前台进程组 SIGINT 归属（子进程退出、宿主存活、下一格
  仍可求值，见 ADR-0009）；退出码 1 表示有 FAIL。

## 6. 后果

正面：终于能在 rakuish 里直接跑 `rakupp` 等嵌套 REPL，不再 30 秒被杀；
`!` 的默认路径一行未改，结构化值语义保留。

负面 / 代价：多了一个必须显式选择的入口；`tty-exec` 的输出不可捕获、
不可进入 `_`；无超时意味着用户必须自己结束子进程；真 TTY 光标行为
仍依赖 `Terminal::LineEditor` 0.0.23 的内部实现。
