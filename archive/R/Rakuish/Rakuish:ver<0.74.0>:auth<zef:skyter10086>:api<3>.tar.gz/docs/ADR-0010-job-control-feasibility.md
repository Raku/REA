# ADR-0010 · job control（进程组切换 / 前台进程组）可行性评估

- **日期**：2026-11-13
- **对象**：`main` @ 0.72.5
- **状态**：**选项 A 已实施**（0.73.0，见 §6）；评估与实测证据保留在 §1–§4
- **输入**：[ADR-0007](ADR-0007-tty-passthrough.md) §3.3「不做 tcsetpgrp / 进程组切换」、
  [ADR-0009](ADR-0009-tty-exec-sigint-contract.md) §5/§6、SPEC V-167；
  用户提问「进程组切换 / job control 看看能不能做」

## 1. 现状与「不做」的确切含义

`Sys::Proc.tty-exec` 用 `Proc::Async` 起子进程，父子**同属一个进程组**，
父进程靠 `signal(SIGINT).tap` 临时吞掉 Ctrl-C 来保命（ADR-0007 §3.3）。
所以 ADR-0007 写的「不做 tcsetpgrp / 进程组切换」落到可观测行为是四条：

1. Ctrl-C / Ctrl-Z / 终端 resize 都发给**整个前台进程组**，父进程只是靠 tap 躲开 SIGINT；
2. 子进程 `kill(0, SIG)` 会把宿主 REPL 一起打死（同组）；
3. `tcgetpgrp(0)` 返回的是**父进程的组**，子进程若按 POSIX 惯例判断「我是不是前台」
   只是碰巧成立，一旦涉及作业挂起就会错；
4. Ctrl-Z 语义缺失（父进程没有 recovery 流程，`fg`/`bg` 无从谈起）。

## 2. 实验与结论

### 2.1 能不能「起完再 setpgid」？——不能

`Proc::Async` 起子进程后，父进程侧 `setpgid(pid, pid)` **60/60 全部失败**，
`errno=13 (EACCES)`：POSIX 规定父进程只能对**尚未 exec** 的子进程 setpgid，
而我们拿到 pid 时子进程早已 exec（Rakudo 2026.09 的 `$p.pid` 是个 Promise，
`await` 之后才拿到值，那时更晚）。

→ 想切进程组，**必须替换 spawn 路径**，不能靠事后补救。

### 2.2 posix_spawn + POSIX_SPAWN_SETPGROUP ——可行

用 NativeCall 直接调 `posix_spawn` + `posix_spawnattr_setpgroup(attr, 0)`
（`POSIX_SPAWN_SETPGROUP = 0x02`），进程组在**fork/exec 之间**就定好，无竞态：

| 用例 | 结果 |
|---|---|
| `pgroup = 0`（自成一组） | 子进程 pgid == 自己的 pid；`exit=7` 正确回传 |
| `pgroup = 父进程组` | 子进程留在父组，行为与现状一致 |
| `waitpid` 回收 | 返回子进程 pid、状态正确——**没被 Rakudo 自己的回收机制抢走** |

附带好处：`posix_spawn` 直接继承 fd 0/1/2，不需要 `bind-stdin/out/err`。

### 2.3 真 PTY 全链路 ——跑通

`pty.fork()`（有 controlling terminal，`tcsetpgrp` 的前提）里跑原型：
`posix_spawn(SETPGROUP)` → `tcsetpgrp(0, child_pgid)` → 等子进程 → `tcsetpgrp(0, my_pg)`。

单次 5/5 全过，连跑 3 次稳定：

| 检查 | 实测 |
|---|---|
| 子进程自成一组 | `pgid == pid` |
| 前台切给子进程 | `tcgetpgrp(0) == child_pgid` |
| 终端 Ctrl-C 只打死子进程 | 子进程 `signaled=1 sig=2` |
| **父进程收到 0 次 SIGINT** | `parent-sigints=0` —— 不再需要 SIGINT tap |
| 退出后前台收回 | `tcsetpgrp` 返回 0，`tcgetpgrp(0) == 父进程组` |

**踩到一个 Raku 专属的坑**：交接后父进程是后台进程，调用 `tcsetpgrp`
会吃 `SIGTTOU`。必须用 NativeCall 把 SIGTTOU **真正 `SIG_IGN`**；
用 Raku 的 `signal(SIGTTOU).tap`（捕获语义）会让**恢复那次 `tcsetpgrp`
返回 -1 / `errno=25 (ENOTTY)`**，看起来像是「控制终端没了」，极难排查
（换成新开的 `/dev/tty` fd 也一样失败，只有真忽略才正常）。
对照：同样逻辑用 Python + `signal.SIG_IGN` 一次通过。

### 2.4 现状到底错在哪：可复现的 A/B

子进程执行 `os.kill(0, signal.SIGTERM)`（对自己所在进程组发信号，现实中
清理进程组的工具会这么做）：

| 实现 | 结果 |
|---|---|
| 现状（父子同组） | **宿主 REPL 一起被 SIGTERM 打死**（真 PTY 实测 `alive=False`） |
| 切进程组后 | 子进程 `sig=15` 退出，父进程存活、前台正常收回 |

这不是风格问题：同组意味着子进程的一次组信号能带走整个 REPL。

## 3. Windows 侧：没有对应物

- Windows 没有 POSIX 进程组 / 前台进程组概念。`CreateProcess` 的
  `CREATE_NEW_PROCESS_GROUP` 只影响 `GenerateConsoleCtrlEvent`，而 MSDN 对
  `CTRL_C_EVENT` 的说明是：*该信号不能投递给进程组；传非零 groupId 时函数
  会成功，但组内进程收不到 CTRL+C*。
- 键盘 Ctrl-C 在 Windows 上是发给**整个 console** 的，没有「前台」可以限定。
- `Proc::Async` 也不暴露任何创建标志，Rakudo 侧拿不到等价开关。

→ **job control 只能是 POSIX-only**；Windows 继续用现在的 SIGINT tap。
这一条来自 API 文档的明确语义，本版**未做真机实验**（贸然向宿主 console
发 Ctrl-C 会波及当前会话），如实标注为「文档结论」。

## 4. 若要实施：范围、改动面、风险

**建议范围（最小可用）**：只做 `tty-exec` 的**进程组交接**——用户界面不变，
只是语义变正确。**不做** `&` 后台、`jobs` / `fg` / `bg` / Ctrl-Z 作业管理：
那是 shell 语法，与 SPEC V-90x「不引 bash 语法」冲突，需要另立议题。

| 项 | 内容 |
|---|---|
| 改动点 | `Sys::Proc.tty-exec` 新增 POSIX 分支：`posix_spawn(SETPGROUP)` → `tcsetpgrp` → `waitpid` → 恢复；Windows 走现有 `Proc::Async` |
| 体量 | 约 150 行（spawn 封装、argv/env marshalling、状态码映射、TIGTTOU 忽略、清理） |
| 必要细节 | SIGTTOU 必须 `SIG_IGN`（见 §2.3）；`WIFSIGNALED` → `code=128+sig`；`ENOENT` → `code=127`；`LEAVE` 里恢复前台（异常路径也要） |
| **cwd 麻烦** | `posix_spawn` 没有 cwd 参数，要用 `posix_spawn_file_actions_addchdir_np`（glibc ≥ 2.29 / macOS 10.15+）。符号缺失时**降级**：走 `Proc::Async` 且 `value<job-control>` 标 `False`，绝不改父进程 `chdir`（会改进程全局状态，违反 ADR-0007 §2） |
| 风险 | ① 自己 `waitpid` 与 Rakudo 内部回收理论上可能打架（实测 2/2 正常，但需在 `t/32` 里反复跑）；② 恢复前台失败时的兜底（重试一次 + `Result.value<fg-restored>` 如实标记）；③ Windows 语义分叉要在文档写清 |
| 回归 | 新增 `t/32-job-control.t`（真 PTY：Ctrl-C 只到 child、`kill(0)` 不波及、前台恢复、退出码/信号码映射、cwd 仍生效）；`t/26` / `t/30` / `t/31` 必须不回归 |
| 版本 | minor（0.73.0），`api` 不变 |

## 5. 待决策

| 选项 | 含义 | 代价 |
|---|---|---|
| **A** | 做最小范围（进程组交接，POSIX-only） | 约 150 行 + `t/32` + 双平台验收 |
| **B** | 只把 §2.4 的缺陷修掉（例如给子进程挡住组信号），不切组 | 小，但治标：Ctrl-Z / `tcgetpgrp` 语义仍不对 |
| **C** | 不做，继续用 SIGINT tap，把 §2.4 写进已知缺口 | 0，但「子进程组信号打死 REPL」保留 |

**倾向 A**：机制已被实测证明可行、改动局限在一个方法内、Windows 不受影响；
且它顺带去掉 SIGINT tap 这个权宜之计。若选 A，建议单独开 0.73.0，
先写 `t/32` 的失败断言再动实现。

**决策**：用户选 **A**，于 0.73.0 实施，范围严格按 §4 —— 只做 `tty-exec`
的进程组交接，不做 `&` / `jobs` / `fg` / `bg` / Ctrl-Z 作业管理。

## 6. 实施记录（0.73.0）

### 6.1 新增模块

`lib/Rakuish/Sys/PosixSpawn.rakumod`（provides 27 → 28）：NativeCall 薄封装，
把 spawn / 等待 / 前台切换 / SIGTTOU 全部收在一处，`Sys::Proc` 只调用不实现。
符号都是**调用时**解析，Windows 上加载该模块不会碰 libc（已实测）。

| 导出 | 作用 |
|---|---|
| `spawn-in-group` | `posix_spawnp` + `POSIX_SPAWN_SETPGROUP(0)`；可选 `addchdir_np` |
| `wait-exit` | 自己 `waitpid`，EINTR 重试（上限 ≈2s），解出 `exit` / `sig` |
| `set-foreground` / `foreground-of` / `group-of` | `tcsetpgrp` / `tcgetpgrp` / `getpgid` |
| `ignore-sigttou` / `restore-sigttou` | 真 `SIG_IGN` 并保存旧 handler |
| `addchdir-available` | 能力探测，`state` 缓存一次 |

### 6.2 `tty-exec` 的变化

1. **路径选择**：POSIX 且（cwd 相同 **或** `addchdir_np` 可用）→ 进程组交接；
   否则走原 `Proc::Async`，`value<job-control> = False` 并给
   `value<job-control-reason>`。降级绝不改父进程 `chdir`。
2. **SIGINT tap 缩到交接窗口**：`spawn` 后、`tcsetpgrp` 前前台仍是父进程组，
   这个微秒级窗口保留 tap；切前台成功立刻 `close`。正常运行期间**不依赖**它。
3. **`LEAVE` 恢复顺序**：前台还给宿主 → 还原 SIGTTOU → 恢复 termios。
   termios 用 `DRAIN` 会丢弃排队输入，在后台做既无意义又容易踩 SIGTTOU。
4. **状态映射**：`WIFSIGNALED` → `code = 128 + sig`；`posix_spawnp` 返回
   `ENOENT(2)` → `code=127`；`waitpid` 拿不到 → `code=1` 而非 0（不谎报成功）。
5. **新增 `value` 字段**：`job-control` / `job-control-reason` / `fg-restored` / `pgid`。

### 6.3 回归

`t/32-job-control.t`（真 PTY，Windows skip 11 条）11 条断言，连跑 3 次稳定：

| 断言 | 实测 |
|---|---|
| 子进程自成一组 | `pgid == pid` |
| 子进程拿到前台 | `tpgid == pgid` |
| 返回后前台收回 | `tcgetpgrp(0) == 宿主组`，`fg-restored=1` |
| `exit 7` | `code=7 sig=0` |
| `kill -TERM $$` | `code=143 sig=15` |
| cwd 动作 | 子进程 `pwd` = `/tmp` |
| `kill -TERM 0` | 打死自己（143/15），**宿主存活** |
| Ctrl-C | 只投给前台子进程组（130/2），宿主存活 |

**`t/30` 的驱动被迫改判据**：它原来用 `killpg(父进程组, SIGINT)` 模拟真终端，
切组后这个信号根本到不了子进程（那是模拟写法，不是真实路径）。改成
`pty.fork()` + 写 `\\x03` —— 真 controlling terminal 由行规程投递给前台组，
既更真实也不再依赖「父子同组」这个被推翻的前提。0.72.3 的契约断言全部保留。

### 6.4 已知边界

- **Windows 无对应能力**（§3）：走老路径，`value<job-control>=False` 且带原因。
- **Ctrl-Z 仍无作业管理**：切组后子进程会被 SIGTSTP 停住，但没有 `fg`/`bg`
  能把它捞回来（REPL 会等在那儿）。这是 §4 明确划出去的范围。
- **只切前台，不做信号转发**：`tty-exec` 期间终端 resize（SIGWINCH）由子进程
  组自己处理，父进程不转发。
- **子进程 fork 出的孙进程**仍归子进程组，随组一起收信号 —— 这正是期望行为，
  但仍不做进程树回收（B / V-905 依旧是后续项）。
