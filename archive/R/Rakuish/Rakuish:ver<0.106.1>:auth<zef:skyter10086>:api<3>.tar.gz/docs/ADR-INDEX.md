# ADR 决策索引（0.106.1）

> **本文件是仓库内 36 份 ADR 的目录与状态真值**；条款真值仍是 [`SPEC.md`](../SPEC.md)，
> 逐条理由看各 ADR 原文。资料库另有一篇《Rakuish 0.80.0 状态与决策索引》，
> 它是外部分析文档，**不作为仓库真值源**。
>
> 更新：2026-11-19 · 版本：0.106.1 · 条目数：36

## 1. 决策总表

| ADR | 主题 | 版本 | 状态 | 一句话结论 |
|---|---|---|---|---|
| [0001](ADR-0001-raku-native.md) | 不再实现 bash / POSIX 子集 | 0.29–0.34 | Accepted | 删双栈，Raku 是唯一命令语言；v2 的 `v/` 遗骸 0.80.1 已清除 |
| [0002](ADR-0002-agent-serve.md) | Agent 多客户端服务与请求级取消 | 0.63.0 | **已撤销**（0.81.0） | 每连接独立 Sys / Engine / 审计；**Agent 线整体删除，本文仅存档**（ADR-0019） |
| [0003](ADR-0003-repl-experience.md) | Vi/Helix 模态、hints、插件 | 0.66.0 | 已实施 | 插件加载即执行本地代码，不是沙箱 |
| [0004](ADR-0004-cursor-worker.md) | 流式 Cursor 与连接级 worker 硬取消 | 0.67.0 | Accepted | `--worker` 默认关闭；超时真 kill 进程，不保证杀孙进程（V-159 / V-905） |
| [0005](ADR-0005-data-workbench.md) | CSV 受控外部读写 + Engine 元数据 | 0.68.0 | Accepted | 与 Parquet 共用 `:allow-external`，Agent 不开放（V-152）；§4 反对持久求值器 |
| [0006](ADR-0006-data-profile.md) | CSV 方言 / describe / 补全启发式 | 0.69.0 | 已接受 | 7 项方言白名单；不做 SQL AST 级补全 |
| [0007](ADR-0007-tty-passthrough.md) | 交互式子进程 TTY 直通 | 0.70 / §3.5 补于 0.72.0 | 已接受 | `! --tty` 零捕获直通；`pty_exec` 是显式双开关的捕获入口，不等同实时 `tty_exec` |
| [0008](ADR-0008-input-interrupt-sql-forms.md) | 输入中断语义与 SQL 补全形态 | 0.71 | 已接受 | Ctrl-C 中断输入而非退出 REPL；`q[...]` / `sql =>` / `:sql(` |
| [0009](ADR-0009-tty-exec-sigint-contract.md) | `tty-exec` 期间 Ctrl-C 归属契约 | 0.72.3 / 0.72.4 订正 | 已接受 | 真 PTY 回归 + 交接期宿主 `termios` 快照恢复 |
| [0010](ADR-0010-job-control-feasibility.md) | job control 可行性评估 | 0.73.0 | 已实施（有边界） | `posix_spawnp` + `SETPGROUP` + `tcsetpgrp` + 自建 `waitpid`；**只到前台交接**，无 `&`/`jobs`/`fg`/`bg`/Ctrl-Z |
| [0011](ADR-0011-highlight-colors.md) | 结果着色与输入行高亮 | 0.74.0 | 已实施 | V-176 / V-177 / `t/33`；高亮只做单行词法，依赖 LineEditor 内部 |
| [0012](ADR-0012-userland-commands.md) | 用户层四项能力 + 三处订正 | 0.75.0 | 已实施 | 选项补全、`doc` 零 EVAL 内省、目录栈/书签、会话日志；顺手清掉 FEATURE-GAP 的 A1/A2/A3 |
| [0013](ADR-0013-kernel-frontends.md) | 人机共用内核与显示协议 | 0.76.0 | **部分实施，Agent 半边已作废** | `Kernel` / `Request` / `Policy` 统一 REPL 三入口；Agent 入口已删除（ADR-0019），「两者合并」不再有对象 |
| [0014](ADR-0014-console-codepage.md) | Windows 控制台码页收口 | 0.76.1 | 已实施 | 交互前切 UTF-8、退出还原；`tools/tty-cjk-win.py` |
| [0015](ADR-0015-command-table-and-cell-record.md) | 命令名单一数据源 + 输入序/格号分离 | 0.77.0 | 已实施 | `COMMAND-GROUPS` 派生全部视图；`!finish` 收口记账 |
| [0016](ADR-0016-display-bundle.md) | 展示包与格式协商 | 0.78.0 | 已实施（Agent 半边撤销） | text / markdown / json；Agent `display` 字段已删，bundle 本身保留；`html` 明确没有 |
| [0017](ADR-0017-stream-cancel.md) | 流式分帧与请求取消 | 0.79.0 | **已撤销**（0.81.0） | `stream` / `cancel` 只对 `exec` 生效；协议删除后无作用对象 |
| [0018](ADR-0018-audit-and-no-agent-scripts.md) | 统一审计 + 不给 Agent 脚本路径 | 0.79.2 / 0.80.0 | **部分撤销**（0.81.0） | V-607 与「不给 Agent 脚本路径」随 Agent 线撤销；**V-194…196 统一审计保留并成为唯一写入点** |
| [0019](ADR-0019-local-full-privilege-shell.md) | 放弃 Agent 线，做全权限本地 shell | 0.81.0 | **Accepted** | 删 Agent / Sandbox / 协议；Raku 源码直接 EVAL、`!` 直接起进程；**不设权限闸门**；审计保留 |
| [0020](ADR-0020-policy-slim.md) | Policy 只留有执行点的字段 | 0.82.0 | **Accepted** | 7 → 3（profile / allow-source / root）；删 allow-exec / read-only / allow-ops / limits —— 无执行点的声明就是牌子 |
| [0021](ADR-0021-eval-worker.md) | 求值引擎住子进程 | 0.83.0 | **Accepted** | 交互式 REPL 的 `EVAL` 在 `raku` 子进程里；`exit` / 段错误 / 死循环只带走引擎，父进程重启并如实告知状态丢失；`! --tty` 交回父进程 |
| [0022](ADR-0022-session-snapshot.md) | 会话快照：声明与纯值跨崩溃存活 | 0.84.0 | **Accepted** | 每成功格写 `%!state` + `@!decls`；崩溃重启重放声明与纯值；**语句格不重放**（副作用不幂等）；资源/闭包/超大值明确标失效 |
| [0023](ADR-0023-interrupt.md) | 求值期间的 Ctrl-C | 0.85.0 | **Accepted** | `Eval::Client` 在等响应时接管 SIGINT、主动 kill 引擎；归因为 `op=interrupted` / `code=130`（不是「引擎崩溃」）；清掉行编辑器的 `take-interrupt` 以免吞掉下一格 |
| [0024](ADR-0024-exec-stream.md) | `!` 的流式输出与超时选项 | 0.90.0 | **Accepted** | 终端里 `! cmd` 边跑边出（引擎发 chunk 帧、父进程打印）；`--capture` / `--timeout-ms` / `--no-timeout`；`Result.streamed` 保证不重放 |
| [0025](ADR-0025-startup-layer.md) | 启动文件 / 可编程 prompt / `set -o` | 0.90.0 | **Accepted** | `~/.rakuish/rc.raku` 在引擎里逐格执行且不占 `Out[n]`；`repl.prompt = -> {...}` 每格求值；5 个有执行点的选项（errexit / histexpand / noglob / noexpand / xtrace） |
| [0026](ADR-0026-structured-pipe.md) | 结构化管道：`Stream` 与记录喂给子进程 | 0.91.0 | **Accepted** | 惰性记录流 `stream()`（文本 / `!` 的 Result / Table / Cursor → `Seq of Hash`）；阶段方法链，惰性边界写明；`.exec` 写子进程 stdin。**不加管道语法**：`|` 属 V-901，`|>` 在 Raku 语法里不可定义 |
| [0027](ADR-0027-frontend-pager.md) | 前端分页：`explore` 的 `-- more --` 搬到父进程 | 0.92.0 | **Accepted** | 引擎只回文本、不判断分页（它的 stdout 是协议流）；`Pager.paginate` 注入读/写回调，入口按终端高度切页；`RAKUISH_PAGER=auto/always/never`（默认只给 `explore`）。真 PTY 验收接进 `tools/ci.sh` |
| [0028](ADR-0028-streaming-exec-stdin.md) | `Stream.exec` 的 stdin 流式化 | 0.93.0 | **Accepted** | `spawn` 新增 `:&in-chunks`（与 `:in` 互斥）；写一块 await 一块 = 背压，攒 16 KiB；子进程提前关 stdin 记 `in-early`、生成器抛记 `feed-error`；一次性来源的二次消费在 `exec` 调用点同步抛 |
| [0029](ADR-0029-zip-join-tee.md) | 两条流：`zip` / `join` / `tee` | 0.94.0 | **Accepted** | `zip` 按位置（默认短、`:longest` 补齐）；`join` 是 hash join（右表物化、左表惰性），`:how` 四档但**默认 left**（与 `Table.join` 一致）；`tee` 是 Unix 语义（写文件 + 透传），路径过会话 root，格式与 `exec` 共用。列命名只有 `Table.join-columns` 一份 |
| [0030](ADR-0030-interleave-append.md) | 按顺序收拢两条流：`interleave` / `append` | 0.95.0 | **Accepted** | `interleave` 交替（默认吐完长侧、`:shortest` 取短）；`append` 首尾接（同构契约，左读完才碰右）。两者每行原样、**不改列名**，不调用 `Table.join-columns`（那是合成一行时用的） |
| [0031](ADR-0031-job-control-api.md) | MoarVM 下的作业控制 API | 0.96.0 | **Accepted** | `bg-exec` / `bg-jobs` / `fg` / `bg` 是**普通 Raku 函数**，不碰 V-901；作业表建在父进程（引擎重启不丢孤儿），DSL 经 job 帧转过去；复用 ADR-0010 原语 + `wait-state`(WUNTRACED)/`signal-group`；Ctrl-Z 时 fg 归还前台不卡死；POSIX-only |
| [0032](ADR-0032-exit-linger-and-render-contract.md) | 退出残留线程消解与展示契约收口 | 0.98.2 | **Accepted** | linger guard（看门狗 `trap '' HUP` + 父子核验 + `kill -9`，退出码仍 `exit(N)`）；`Proxy.render` 只信 `rendered`（空串=刻意不展示，不再 dump 字段）；Windows NUL 的 `$*OUT.t` 误判改 CSBI 探真控制台 |
| [0033](ADR-0033-tail-follow.md) | `tail -f` 跟随：循环放父进程 | 0.99.0 | **Accepted** | 轮询跟随（0.2s，半行缓冲，截断/轮转重读）走 job 帧 `tail-follow` 在父进程跑；Ctrl-C 只停跟随（job-interactive 置停止标志，code=130），引擎不重启；`head -f` 拒绝 |
| [0034](ADR-0034-interaction-handfeel.md) | 交互手感层：建议/菜单/错误态/模糊/Ctrl-R | 0.100.0 | **Accepted** | 渲染管线「词法→语义标记→灰字建议」压在 `visible-input-field-string` 单点（宽度不变式不动）；ShiftTab 菜单打印后重画 prompt；Ctrl-R 循环历史检索（鱼式模态搜索推迟，需拥有输入循环）；补全前缀优先、零命中子序列回退 |
| [0035](ADR-0035-handfeel-followups.md) | 手感后续：逐词接受/建议来源/In·Out 引用/名字精确判定 | 0.101.0 | **Accepted** | ADR-0034 §4 五项后续落地四项：`Alt-→` 逐词接受、补全候选做灰字建议（历史优先+缓存）、`In[`/`Out[` 引用补全、引擎侧名字判定消除 listop 误标；第五项（鱼式模态+Tab-Tab）仍推迟 |
| [0036](ADR-0036-input-loop-ownership.md) | 输入循环自研评估：成本 / 触发条件 / 决策 | 0.101.0 | **Accepted（暂不实施）** | "输入循环"= 上游 `read-input` 的 `react whenever` 分发链（词法闭包不可从外部改）；三路线对比（fork / 推上游 / 近似体验），决策维持 ③；重开 ① 的五步清单与三个触发条件钉死，不许当补丁做 |

## 2. 决策演变链

| 阶段 | 输入 | 决策 | 结果 |
|---|---|---|---|
| v2 → v3 | 两套语言、两套执行栈，7 个 P0 | ADR-0001 整体删双栈 | Raku 唯一命令语言 |
| 0.71–0.72 | 代码审计 4 高 / 11 中 / 11 工程项 | 逐条修，写 8 份 `AUDIT-FIXES` | 基本清零，TTY/PTY 层补齐 |
| 0.73–0.75 | TTY / 进程组 / 交互手感 | 前台交接、着色高亮、用户层命令 | 不碰 `EVAL` 作用域 |
| 0.76–0.79 | 三份自审（FEATURE-GAP / ARCH-REVIEW / PROPOSAL） | Kernel / Display / stream / cancel 陆续落地 | +8k 行，ADR 8 → 17 |
| 0.79.2–0.80 | 跨平台 OS 隔离四轮讨论 | V-607 结构性闸门 + V-194…196 统一审计 | `execute` 删除、VM 隔离整体搁置 |
| 0.80.1 | 发布工程化 | 打 `v0.80.0` tag、`tools/ci.sh`、清残留、收敛文档真值 | 无新能力，不改任何对外语义 |
| 0.80.2 | 按《愿景溯源》§6 重开方向议题 | 两条最小探针实测（Sandbox 短路 / rakupp 常驻求值），报告 `PROBE-2026-11-15-persistent-engine.md` | **结论待定**，未动主干，未改 V-906 |
| 0.80.3 | 判断 B 第二层验证 | 6 个新探针 + 报告 `PROBE-2026-11-16-rakupp-integration.md`；34/34 模块、双引擎一格一致、全套件 27/42、并发 SIGSEGV | **结论待定**，仍未动主干 |
| 0.80.4 | 判断 B 第三层适配归因 | `rakupp-diff.raku` + `rakupp-adapt.sh` + 报告 `PROBE-2026-11-16-rakupp-adaptation.md`；副本改两处即 27→30/42，七类归因，上限 36/42 | **结论待定**，仍未动主干 |
| 0.83–0.85 | 崩溃隔离 | 引擎子进程 + 会话快照 + 求值中 Ctrl-C（ADR-0021 / 0022 / 0023） | 交互式 REPL 开始有「重启后继续」语义 |
| 0.90.0 | shell 差距清单 | `!` 流式 + 超时选项 + rc / prompt / `set -o`（ADR-0024 / 0025） | 长任务可见、会话可配置 |
| 0.91.0 | 同一清单的优先级 2 | 结构化管道 `Stream`（ADR-0026） | 文本↔记录↔子进程 stdin 打通；不加 shell 语法 |
| 0.92.0 | 同一清单的优先级 3 的前置 | 前端分页（ADR-0027） | `explore` 在交互式 REPL 里真的能分页；`-- more --` 不再只在进程内出现 |
| 0.93.0 | 结构化管道的收尾 | `.exec` 的 stdin 流式化（ADR-0028） | 管道两端都真惰性：大流不吃内存，子进程提前走就不白算 |
| 0.94.0 | 同一清单的优先级 3 之后 | `zip` / `join` / `tee`（ADR-0029） | 两条流的合并与落地：字典连接、按位对齐、边流边存 |
| 0.95.0 | 两条流的收尾 | `interleave` / `append`（ADR-0030） | 交替与首尾接：不合成行、不改列名，收拢而非配对 |
| 0.96.0 | 「只用 MoarVM 能否做作业控制」重开 ADR-0010 | B 档：`bg-exec`/`bg-jobs`/`fg`/`bg`（ADR-0031） | 纠正前提：ADR-0010 本就是 MoarVM 实测；障碍是 V-901 + 双进程架构，不是运行时。作业表落父进程，Ctrl-Z 不再卡死 REPL |
| 0.98.2 | 复核报告 P0/P1 修复集 | linger guard + 展示契约收口 + Windows NUL TTY 判定（ADR-0032） | 退出残留线程用看门狗消解（不绕开 `exit()`）；`Proxy.render` 只信 `rendered`；`$*OUT.t` 的 NUL 误判改 CSBI 探测 |
| 0.99.0 | 内置 tail 缺 -f | `tail -f` 跟随（ADR-0033） | 轮询循环放父进程（job 帧同构 tty-exec）；Ctrl-C 归属是「停跟随」不是「中断求值」 |
| 0.100.0 | 补全 / 交互弱于 fish | 交互手感层（ADR-0034） | 灰字建议 / 候选菜单 / 错误态高亮 / 模糊回退 / Ctrl-R 循环检索一次落地；鱼式模态搜索仍为边界（需拥有输入循环） |
| 0.101.0 | ADR-0034 §4 后续清单 | 手感后续四项（ADR-0035） | 逐词接受 / 补全候选建议 / In·Out 引用补全 / 引擎侧名字精确判定；均走既有 RPC，不扩协议；鱼式模态仍推迟 |
| 0.101.1 | 真机 + SPEC 审计 | junction 结果契约（V-287）+ 文档订正 | `Result.value` 改 `Mu`、渲染在调用点转字符串、`value-defined`；SPEC 头部版本与 V-122 的 `%STORE` 订正；ctrl-c 探针输入竞态、cjk winpty 误报（详见 AUDIT-2026-11-18） |
| 0.101.2 | 0.101.1 文档核对复检 | junction 结果契约补齐 `Result.display` | 同一 bug 的第三处出口（`display` 的标量分支用 `.defined`/`~~`，对 junction autothread 后在 `my Str` 处抛 Type check）；t/61 17→20 断言，SPEC V-287 同步 |
| 0.101.3 | 外部评测（Windows 文件读写） | 跨平台可执行判定（V-288） | Windows 上 `IO::Path.x` 对存在文件也抛 `rindex ... got null`：`which` 崩且中止输入、`stat.executable` 恒假；改走扩展名白名单（Win）/ x 位（POSIX），`write/append/read` 帮助文案改成 Raku 调用形式 |
| 0.101.4 | 真机反馈（`! --tty` + Ctrl-C） | tty 直通的信号归属（V-289） | 宿主 SIGINT handler 在 `in-request` 分支 SIGKILL 引擎，导致「引擎进程已退出 → 重启」+ 光标错位/回车无响应；新增 `tty-interactive` 状态（Ctrl-C 归前台子进程），引擎侧 tty-handler 加纵深 tap；探针加 `engine_survived` 并反证 |
| 0.102.0 | 外部评测跟进 + `!` 补全 | 上限就地抬高 / 异常族归位 / shell 补全（V-290、V-291） | 1 MiB 默认值不变；`cat`/`read` 加 `--max-bytes=N`（K/M/G）、`write`/`append` 加单次 `:max-bytes`；二进制当文本读改抛 `X::Rakuish::Encoding` 并给 `:bin`/`:enc`/`read-lines` 三条出路；`!` 前缀走同一套 argv 补全（路径/选项，首词可为外部程序） |
| 0.103.0 | `!` 的 PATH 命令补全 | 外部程序名入补全（V-292） | 首词补 PATH 可执行文件（Windows 去 .exe 后缀、按 V-288 口径判可执行），`! --tty` 第二词同样；PATH 扫描并行 + 按 PATH 缓存 + 入口后台预热 |
| 0.104.0 | 中文编码别名 | `gbk`/`cp936` → `gb18030`（V-293） | Rakudo 内建 gb18030 被外部评测漏查；read/write/read-lines 加别名映射，shell `cat`/`read` 加 `--enc`；GBK 不再是「无解」，big5/shift-jis 仍须 `:bin` |
| 0.105.0 | 文件锁 with-lock | 劝告锁（V-294） | 锁独立 `.lock` 伴生文件（不锁数据文件，避免 rename 换 inode 失效）；Raku 内建 IO::Handle.lock 跨平台；异常自动解锁；`:shared`/`:non-blocking`（冲突抛 X::Rakuish::LockConflict，名字避开内建 Lock） |
| 0.106.0 | 性能审计的一、二项 | 管道与 CSV 收口（V-295） | `where` 未定义列值告警只提示一次（用户 `warn` 透传）；已知行数不重扫、Hash 行免重复 coerce；CSV 无引号行走行级切分，20 万行错列名从 77s → 5s |
| 0.106.1 | `-e` / 单行模式启动慢 | 入口预编译 + 按模式懒加载（V-296） | `bin/rakuish` 薄启动器 + `Rakuish::CLI` 预编译模块；`--version` 直读 META6；Kernel 构造走 `Rakuish::Kernel::Factory`；`-e '1+1'` 1.35s → 0.69s |

## 3. 一次「品类变更」的补登记（0.80.1）

ADR-0017 的 `stream` / `cancel` 在 0.79.0 落地时，作用对象是 `exec`
（`STREAM-OPS = <exec>`）。0.79.2 的 V-607 把 `exec` / `pty_exec`
**默认**关成 403，于是：

> **默认配置下 `stream` 不发任何帧、`cancel` 恒为 409**，
> 只有显式给 `--allow-code-exec --allow-exec` 的不安全 profile 才用得上。

这不是缺陷，也没有回退 0.79.0 的实现；但它改变了这两项能力的定位
（从「默认能力」变成「可选 profile 能力」），而此前没有任何文档标记这件事。
这里补登记，`HANDOFF` 缺口表与 `MANUAL` 同步标注。
**若将来要恢复默认流式，须先回答 V-607 是否放宽，并另开 ADR。**

## 4. 改之前要新 ADR 的清单

- 不实现 bash / POSIX、`%magic`、auto-shell、第二套脚本语言（ADR-0001 / V-901/902）。
- 不让 Agent 接 shell 字符串或 `eval` op（V-503 / V-607 / ADR-0018）。
- 不做持久求值器 / 常驻编译单元（V-906 / ADR-0005 §4）。
- 不承诺杀孙进程、不做完整 job control（V-905 / ADR-0010 §6）。
- OS 级隔离若将来要跑不可信源码，须独立立项 + 威胁模型，不从审计这条路上长出来。
- `html` 富输出、SQL AST 补全、post-mortem 调试等 P2/P3 项：先改规格再开 ADR，
  **不把「不做」伪装成「未排期」**。

## 5. 三份自审文档的定位（0.80.1 校准）

| 文档 | 基线 | 现在的定位 |
|---|---|---|
| [`FEATURE-GAP-2026-11-13.md`](FEATURE-GAP-2026-11-13.md) | 0.74.0 | 历史快照。四者横向对比与 C 类护栏仍有效；A1/A2/A3 已在 0.75 订正，B 类多项已在 0.75/0.77/0.78 落地 |
| [`ARCH-REVIEW-2026-11-13.md`](ARCH-REVIEW-2026-11-13.md) | 0.75.0 开发中 | 历史快照。三处技术债里「命令名 9 处登记」与「会话级命令旁路」已由 0.77 收敛；L5 单一覆盖点仍在 |
| [`PROPOSAL-HUMAN-AGENT-KERNEL.md`](PROPOSAL-HUMAN-AGENT-KERNEL.md) | 0.75.0 开发中 | **部分已实施**：0.76 Kernel、0.78 Display 已落地；「Agent 也走 Kernel」仍未做，且 V-607 后前提已变，不应照原提案继续推 |

## 6. §6 方向议题（0.80.2 重开 → **0.81.0 终结**）

《Rakuish 愿景溯源》§6 的两个判断——**A 权限交给系统 / 撤应用层安全壳**、
**B 拿回 rakupp 常驻引擎 / 恢复跨格连续状态**——已通过 §6.6 的两条最小探针
拿到实测数据，见 [`PROBE-2026-11-15-persistent-engine.md`](PROBE-2026-11-15-persistent-engine.md)。

第二层验证（0.80.3）补充：**34/34 模块可加载、同一格在 MoarVM 与 rakupp 上逐字节一致**，
但全套件只有 **27/42** 通过；**并发 `rk_eval` 稳定 SIGSEGV**。

第三层归因（0.80.4）修正了第二层的两个粗略判断，并把成本拆成可估算的七类：
副本里只改 `Sys::Proc.spawn`（tap→Channel）与 `Sys.%.env`（TWEAK 复制）两处，
即 **27 → 30/42**、ok 行 1856 → 1980。其中 **A 通道空 / B 环境共享 / C spawn 失败 /
F 报错形态四类可绕过**；**D `:pty` 未实现 / E `CPointer` repr out 参数 /
G async accept 收尾三类受引擎限制**。理论上限 **36/42**，剩下 6 个文件恰好是
PTY、中断与 socket 收尾 —— 一个 shell / REPL 工作台最核心的宿主能力。

要点：**A 在本机 REPL 上基本已是事实**（root 已是 `/`、Policy 是 local、
本机三入口不构造 Sandbox）；**B 的技术前提成立**（跨 eval 的 `my` 存活已由
C ABI 与 Raku NativeCall 双路径确证），但 V-906 未改、34 个模块能否在 rakupp
上加载未测，且「一进程一 live 解释器」与 Agent 每连接并发模型不能共存。

### 6.1 结论（0.81.0）

三层探针做完之后，用户的判断是：**放弃 Agent 线，做全权限的本地 shell**
（[ADR-0019](ADR-0019-local-full-privilege-shell.md)）。理由是探针自己给出来的：

> 判断 B 的失败不在「Raku 语义兼容」，而在 **rakupp 缺的恰好是这个产品最核心的
> 两项宿主能力**（`:pty`、可靠 socket 收尾）。而这两项之所以成为问题，
> 只是因为在给 Agent 找一个「安全执行环境」。

于是两个判断一起落地：

| 判断 | 结论 |
|---|---|
| A（权限交给系统 / 撤应用层安全壳） | **做到极致**：不只是撤 Sandbox，连 Agent 线一起删；本机全权限（V-197…V-199） |
| B（拿回 rakupp 常驻引擎） | **不做了**：驱动力（Agent 并发）消失；V-906 标为「不做且已终结」 |

**因此本索引中凡与 Agent 相关的状态都已更新**：ADR-0002 撤销、ADR-0017 撤销、
ADR-0018 部分撤销（审计保留）、ADR-0013 的 Agent 半边作废。
探针脚本与报告保留在 `tools/probe/` 与 `docs/PROBE-2026-11-1*.md`，作为
「为什么不做」的证据，不再作为「待办提案」。
