# Rakuish 变更日志（CHANGELOG）

本文件按**版本**记录对外可见的变化：新增命令 / API、行为变更、缺陷修复，
以及对应的规格条款（SPEC `V-nnn`）与决策记录（`docs/ADR-####`）。
每个版本都有 annotated tag（`v0.x.y`），提交级细节用 `git log v0.122.3..v0.140.0`。

格式遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 的简化版：
`新增` / `变更` / `修复` / `文档`。**没有**「未发布」区段——
版本号只在 `META6.json` 一处为准，发版同时打 tag。

> 记录范围：本文件从 **0.123.0** 起逐版本记录。更早的版本（0.1 起的 90 余个 tag）
> 只保留 `git tag` 与 `git log`，不在此重复誊写——它们由 0.123.0 之前的
> `docs/AUDIT-FIXES-*.md` 与 `docs/ROADMAP-2026-11-11.md` 覆盖。

---

## 0.156.0 — 2026-11-27

混合格里的声明、字符串里的路径、可调用对象的显示（V-364 / ADR-0070）

**新增**
- 字符串字面量里的路径补全：`open-data('pkg/al<Tab>` 现在给 `open-data('pkg/alpha.raku`。Shell 新增公开入口 `path-completions(Str $frag, Str :$before)`（复用 0.154.0 的 `!path-candidates`），`Completion` 新增 `!string-path-prefix`（只认未闭合的单引号；片段含空白放弃；双引号字符串不猜，因为会插值）。顺序在 SQL 之后、会话名字之前。
- `Display` 给 `Callable` 单独一支：`sub helper-demo(Int $x --> Int) { … }` / `block($a, $b) { … }`，kind 为 `callable`，markdown 用 ```raku 围栏、html 用 `pre-block`，`json` 只放这段文本摘要。notebook 里显示 `&f` / `&MAIN` 不再是空白格。

**修复**
- **声明不在格首时跨格丢失**（严重）：`my $a = 1; sub f { 42 }` 之前整格不进 `@.decls`（`!pure-decl` 的正则锚在格首），而词法声明随 `EVAL` 块结束消失，于是下一格 `f` 直接 `Undeclared routine`。现在 `!eval-raku` 在非纯声明格上按**顶层分号**切语句（引号 / 注释 / 括号内不算边界），逐条试 `!pure-decl`，带 `key` 的在**成功**后记入 `@.decls`（同 key 原位替换）。同一个 bug 顺带修好了 `who` 少列、`store` 少存、快照少一条的连带症状。纯声明格的处理路径（类型格改写、`$slot` 顺序、失败回滚）一行未动。
- 块内声明（`if True { sub inner {…} }`）仍**不**记录；失败格里的声明不留痕。
- `bundle-of(sub { 42 })` 的 `text` 从空串变成可读摘要，stderr 也不再打 `Sub object coerced to string`。

**测试**
- 新增 `t/94-mixed-decl.t` **27 条**：混合格 sub / class / our sub / constant 存活、下一格可调用、补全与 `who -l` 可见、声明在格首仍是声明格（`value` 为 `Any`）、块内不记、失败格不记、纯语句格零声明、字符串里的分号不是语句边界。
- `t/92-completion-paths.t` 31 → **35 条**（字符串路径有候选、保留开引号、双引号不给、含空白不给）；`t/80-display-protocol.t` 41 → **52 条**（含子进程复跑确认 stderr 无 `coerced to string`）。
- 全套件 `prove6 -Ilib t/`：90 个文件 / 4,422 条断言 / 全部通过（0.155.2 是 89 / 4,380）。

**文档**
- 新 ADR-0070（八节：取证 / 三个决定 / 六个没采用的方案 / 不变量 / 结构守卫 / 下一步），SPEC 新增 **§3.90**（3.90.1 改动点表 / 3.90.2 混合格规则与边界表 / 3.90.3 字符串路径的三个拒绝条件 / 3.90.4 Callable 显示与 `"{ … }"` 块插值陷阱 / 3.90.5 不变量 / 3.90.6 本版不做）。
- 顺手把 A 类文档漂移修掉：`docs/DEVELOPMENT.md` 的「选型理由」表与踩坑表第 34 条不再说「Duckula `ipc-buf` 产坏流」是现在不选它的理由（0.53.0 起已修，理由改为「不新增耦合」）；`HANDOFF.md` 顶部版本行改成 0.156.0 / DB::DuckDB 1.4.3 / Duckula 0.54.0。

---
## 0.155.2 — 2026-11-27

Duckula 上游回音：地板提到 0.54.0，ipc-buf 的旧注释作废（V-363）

**变更**
- `DUCKULA-MIN-VERSION` 从 `v0.38.0` 提到 **`v0.54.0`**（`lib/Rakuish/Data/Duck.rakumod` 顶部）。0.38.0 只说明「有 `columns-typed`」；0.54.0 起它的 docstring 才是三条硬契约（List 长度 == `names.elems`、每列长度 == `elems`、NULL 是 `Any`）。桥依赖的是形状，不是方法的存在性。
- `lib/Rakuish/Data.rakumod` 的安装提示从 `Duckula:ver<0.38+>` 改为 `0.54+`；`HANDOFF.md`、`README.md`、`docs/MANUAL.md` 里同一个地板一并改齐（README / MANUAL 之前还停在 0.36+）。

**修复**
- `lib/Rakuish/Data/Duck.rakumod` 头部注释里「0.33.1 的 `ipc-buf` 产坏流……等上游修」作废：Duckula 0.53.0 已修好（上游用 pyarrow 26.0.1 回归，`write-ipc(:format<file>)` / `(:format<stream>)` / `ipc-buf` 三路都能读 TIMESTAMPTZ，DATE 为 `date32[day]`，微秒未被截断）。桥**仍然不写 IPC**，但理由从「上游坏了」改成「不新增耦合」——编码侧是自研的 `Rakuish::Data::Arrow`（纯 Raku、零原生依赖），让上游写 IPC 等于把桥的正确性绑到别人的序列化细节上。
- 顺带把同一段头部注释里过时的路径描述改准：主路径早已是 0.134.0 的 `CREATE TABLE` + Appender 直插（老路径降为兜底），不是「一律写临时 Arrow 文件」。

**测试**
- `t/93-duck-boundary.t` 39 → **42 条**：新增「`Duckula:ver<0.38+>` 也已清掉」「旧注释『等上游修』已消失」「注释记下了上游修好的版本 0.53.0」三条，地板断言改成 `0.54.0`。

**文档**
- `docs/ADR-0069-rakuish-duckula-boundary.md` 新增 §9「上游回音」：五件契约的逐条结果（含 `append-arrow` 用严格列集比对的原因——DuckDB `INSERT ... BY NAME` 对缺失列静默填 NULL），以及「没跟着改的两条」。
- `SPEC.md` §3.89.5 更新地板与理由；新增 §3.89.8「上游回音」；§3.89.6 计数 39 → 42。

## 0.155.1 — 2026-11-27

Linux / WSL 上 `zef install .` 因测试跨平台问题失败（V-362）

**修复**
- `t/90-exec-split.t` 的管道断言写死 `!echo a | findstr a`。`findstr` 是 Windows 命令，Linux 上没有 —— Windows 上全绿，`zef install .` 在 WSL / Linux 上红在 t/90（zef 遇第一个失败文件即中断，用户看到的是「安装失败」）。
  现在按平台选过滤器：`my Str $filter = $*DISTRO.is-win ?? 'findstr a' !! 'grep a';`，断言消息里带上实际用的命令。
- 顺带核对整个测试目录里其它 Windows 专属命令：`t/10` 的 `! dir /b` 整段在 `if $*DISTRO.is-win` 里；`t/83` 的 `findstr` 只出现在「预期失败（无执行器）」与「注入假执行器（不真 spawn）」两处，平台无关。唯一真会 spawn 的元凶是 t/90。

**测试**
- Linux / WSL 实测：89 个测试文件逐个跑，`not ok` 全部为 **0**（扫描脚本 `tmp/scan-linux.sh`，结果 `0 t/01…0 t/93`）。
- Windows 全套件与之前一致：89 个文件 / 4,377 条断言。
- 记入 `docs/DEVELOPMENT.md` §8.7：**测试不许依赖某一平台独有的外部命令**（`findstr`/`grep`、`dir`/`ls`），管道类断言按 `$*DISTRO.is-win` 选命令或整段 skip。

**文档**
- `docs/DEVELOPMENT.md` §8.7 新增平台命令规范；HANDOFF 最新 tag 行更新。无新增 ADR（计数仍 69）。

---
## 0.155.0 — 2026-11-27

与 Duckula 的边界：关系代数归 Duckula（V-361 / ADR-0069）

**变更**
- **空列的聚合改成 NULL**（`Table.sum` / `mean` / `min` / `max`）。之前空列 `sum` / `mean` 答 `0e0`、`min` / `max` 答 `Nil` —— 同一个「没有值」在 `Table` 里有两个答案，而 SQL / Duckula 回的是 NULL。现在统一返回 `Any`，与 `$t.sql(...)` 拿回的空值同口径。`--> Num` 标注随之改为 `--> Any`（旧标注会强行把 NULL 变 0）。非空列结果不变。
- **SQL 报错不再截断。** `X::Rakuish::V3` 新增可选 `has Str $.hint`，`message` 在 hint 存在时返回 `detail ~ "\n" ~ hint`。`Table.sql` 的 DuckDB 报错拆成两段：第一行进 `detail`（保留 `SQL 执行失败:` 前缀），`Candidate bindings` / `LINE 1: ...` + `^^^^` 进 `hint`。没有 hint 的异常文本与 0.154.1 **逐字相同**。
- **依赖地板收成三个常量**（`lib/Rakuish/Data/Duck.rakumod` 顶部）：`DUCKULA-MIN-VERSION = v0.38.0`（`columns-typed` 的引入版本）、`DUCKULA-DB-VERSION = v1.4.3`（Duckula 自己 META6 的地板）、`ENGINE-DB-VERSION = v1.3.1`（Engine 直连路径）。报错文案引用常量，不再写裸版本号。
- **`Table` 的关系代数冻结**：不新增 `group-by` / `having` / 窗口 / `pivot` / `rolling`；需要时走 `$t.sql(...)`。边界宪章写进 SPEC §3.89.1。

**修复**
- `lib/Rakuish/Data.rakumod` 两处过期的依赖提示：`Duckula:ver<0.36+>` → `0.38+`（`columns-typed` 是 0.38.0 才有的，写 0.36 会装出静默降级的组合）、`DB::DuckDB:ver<1.2.2+>` → `1.3.1+`（与同文件另一处一致）。
- `Table.describe` **没有**改名（审计建议过、查证后自我推翻）：它是跨层契约（`DSL.describe`、`Engine` 角色、REPL `describe` 命令、`t/25` 的 20+ 条断言、ADR-0006）。SPEC §3.89.4 写清两套 schema 分属 `Table` 与 `Frame`，而 Rakuish 从不把 `Frame` 交给用户。

**测试**
- 新增 `t/93-duck-boundary.t` **39 条**：空列/零行聚合 9、非空不变 4、`hint` 语义 6、`describe` schema 3、冻结 6、依赖地板 7、与 SQL 对齐 8（Duckula 缺席时 `skip`）。
- 全套件 89 个文件 / 4,377 条断言 / PASS（0.154.1 是 88 / 4,338）。

**文档**
- 新建 [`docs/ADR-0069-rakuish-duckula-boundary.md`](docs/ADR-0069-rakuish-duckula-boundary.md)（八节：审计结果全表、边界宪章、三处行为变更、`describe` 的反转记录、没采用的四个方案、不变量、守卫清单、给 Duckula 的五件契约）。
- SPEC 新增 §3.89（3.89.1 边界宪章 / 3.89.2 空列即 NULL / 3.89.3 `hint` / 3.89.4 两套 describe / 3.89.5 地板常量 / 3.89.6 39 条不变量 / 3.89.7 本版不做）；ADR-INDEX 69 份；HANDOFF 与 README 版本链。

---
## 0.154.1 — 2026-11-27

真终端下 `zef install .` 卡死（V-360）

**修复**
- `t/88-replay-split.t` 的两条 `paste` 断言直接读真 `$*IN`：`zef install .` 在 WSL 里把终端（`/dev/pts/6`）交给测试进程，于是 `paste` 一直等回车——安装看起来像卡死（实测卡了 30 分钟，同一条测试进程 `wait_woken`）。
  现在用 `class Test-EOF-In { method get(--> Nil) { Nil } }` + `my $*IN = ...` 遮蔽后再断言。Windows 的 `prove6` 恰好给的是 EOF 句柄，所以一直没暴露。
- 附带记入 [`docs/DEVELOPMENT.md`](docs/DEVELOPMENT.md) §8.7 的测试规范与 SPEC §3.83.3 的第 4 条陷阱：**测试不许读真 stdin**。

**测试**
- 断言数量不变（88 个文件 / 4,338 条）。新增验证方式是「在真 pty 下跑」：`t/88` 在 pty 下由挂死变为 3 秒 64/64。

---

## 0.154.0 — 2026-11-27

Tab 补全的路径面（V-358）+ 启动账本（V-359 / ADR-0068）

**新增**
- 补全补上三个历史洞：`cd .<Tab>` / `cd ..<Tab>`（Rakudo 的 `dir` 不返回 `.` / `..`，候选由补全层合成）、`~/<Tab>`（扫描目录换成 `$*HOME`，候选仍保留 `~/` 前缀，不把绝对路径吐回输入框）、`~<Tab>` → `~/`。
- 命令位现在也看得见当前目录的文件名：候选 = 命令名（含 `!` 模式的 PATH 程序）在前、当前 cwd 的文件在后，各限 50、去重。之前 `alpha<Tab>` 零候选，`src/` 永远被 `set` / `source` / `store` 吃掉。
- 首词本身就是路径形态（含 `/`、`\`，或以 `.`、`~` 开头）时直接走路径补全，不再拿命令名模糊匹配。
- 命令位文件名过滤大小写不敏感（`c<Tab>` 能看到 `CHANGELOG.md`），参数位保持文件系统语义（区分大小写）。
- 目录读的是**活的 cwd**，文件名侧没有任何缓存，`cd` 之后下一次性调用立刻生效。

**修复**
- 会话层候选表首位是 Array：`lib/Rakuish/REPL/Session/Completion.rakumod` 原写 `(@names, |@shell)`，`@names` 整个数组成了一个候选元素（`c<Tab>` 首位 `["class","constant"]`）。改为 `(|@names, |@shell)` 并按 `.Str` 去重。
- `~` 单独敲时补 `~/`，而不是去 HOME 里找名字以 `~` 开头的文件。

**测试**
- 新增 `t/92-completion-paths.t`（**31 条**）：`.` / `..` / `~/` / `~` 四类候选、隐藏文件开关、参数位大小写敏感、命令位大小写不敏感、命令在前文件在后、`./` 与 `dir/` 短路、切目录后命令位与参数位都跟新 cwd、`!` 前缀保留、无 Array 型候选。
- 回归：`t/10` 164/164、`t/23` 57/57、`t/25` 69/69、`t/19` 98/98、`t/05` 160/160、`t/34` 59/59。
- 全套件 `prove6 -Ilib t/`：**88 个文件 / 4,338 条断言 / 全部通过**（0.153.0 是 87 / 4,307）。

**文档**
- 新建 `docs/ADR-0068-startup-budget.md`（八节：测量数据 / 固定成本归因 / 已做的按模式惰性 `require` / 方案 A 与 B 的否决理由 / 什么情况下重看 / 不变量）。
- SPEC 新增 §3.87（补全的路径面）与 §3.88（启动账本与不拆脚本通路）；ADR-INDEX 68 份。
## 0.153.0 — 2026-11-27

会话命令改为数据驱动命令表（V-357 / ADR-0067）

**变更**
- `!eval-line-body` 里分派 22 条会话命令的 106 行 `if` / `elsif` 链改成 `SESSION-COMMANDS` 数据表 + 单个 `!dispatch-command` 分派器。表项字段：`name` / `mode`（`exact` | `argv` | `only-argv`）/ `alias`（仅 `tb`：`debug`、`backtrace`）/ `arg`（`raw` | `trim` | `const` | `none`）/ `m`（方法名，不带 `!`）。新增命令从「改一个 547 行的方法、手抄命中条件」变成「加一行」。
- `history` 的内联文本逻辑提成 `method !cmd-history(--> Result)`，表项统一走「名字 → 方法」。
- 表项存方法名字符串而非闭包：`self!"$m"(...)` 对类内方法、以及 role 组合进来的私有方法都可达（21 个方法里 12 个住在八个 role 里）。
- 返回值语义与 `!dispatch-bang` 一致：`Result` = 已处理，`Nil` = 未命中且继续往下走。`set` 家族 / `名字?` / 历史替换 / `!` 分发 / shell 兜底 / Raku 五段仍留在链上，顺序不变。
- `lib/Rakuish/REPL/Session.rakumod` **2,376 → 2,352 行**（82 insertions / 106 deletions）。无新模块，`META6.json` provides 仍 55。

**修复**
- Raku 字符类 `<[...]>` 里 `\t` 不展开：分派器初版写 `/^ $name <[ \t ]> /`，对 `'recall 1'` 不匹配，导致所有带参命令（`recall 1` / `source x` / `store -l` / `unalias nosuch`）落回 Raku 报 `Undeclared routine`。改为 `[ ' ' | \t ]`。

**测试**
- 新增 `t/91-command-table.t`（**159 条**）：表存在且 22 项、无重名、名字集合固定；每项 `mode` / `arg` / `m` 合法（66 条）；每个 `m` 在 9 个文件里都有定义（22 条）；`tb` 的 `alias`、`whos` 的 `const` 特例；分派器存在且只出现一次；22 条「旧 `if` 链分支已消失」；规模 `> 2,200` 且 `< 2,400`；运行时 24 条逐命令 `op` 断言，以及 `set` 三形态 / `set -x` / `history?` / `!echo` / 裸 `unalias` 仍按原路径、`!!` 不进 history、`rerun 1` 带回值。
- 等价性另用 35 条输入与 0.152.0 逐条对比 `op` / `ok` / `code` / `out`（`git stash` 切换版本），`Compare-Object` 零差异。
- 回归：`t/05` 160/160、`t/19` 98/98、`t/34` 59/59、`t/40` 51/51、`t/67` 19/19、`t/82` 88/88、`t/84` 34/34、`t/85` 50/50、`t/86` 41/41、`t/87` 46/46、`t/88` 64/64、`t/89` 51/51、`t/90` 63/63、`t/53` 4/4。
- 全套件 `prove6 -Ilib t/`：**87 个文件 / 4,307 条断言 / 全部通过**（0.152.0 是 86 / 4,148）。

**文档**
- 新建 `docs/ADR-0067-session-command-table.md`（八节；§3 记录两条语言层取证：`self!"$n"` 动态分派、`<[ \t ]>` 不展开转义）。
- SPEC 新增 §3.86（表与分派器 / 命中模式与参数传递 / 表项存方法名 / 结构不变量 159 条 / 本版不做）；ADR-INDEX 67 份。
## 0.152.0 — 2026-11-27

Session 拆分第七步：`!` 命令行分发 role（V-356 / ADR-0066）+ `follow` 的 GC 噪声修复

**变更**
- `lib/Rakuish/REPL/Session.rakumod` **2,679 → 2,376 行**（5 insertions / 313 deletions）。新增 `lib/Rakuish/REPL/Session/Exec.rakumod`（`unit role Rakuish::REPL::Session::Exec`，**343 行 / 1 个方法** `!dispatch-bang`）：
  - `!` 行的元选项：`--` / `--tty|-t` / `--pipe|-P` / `--pipefail` / `--capture` / `--stdin FILE` / `--no-timeout` / `--timeout-ms N`；
  - `--pipe` 与 `--capture` 互斥（127）、空命令（127）、Windows cmd 内建重写；
  - 四类执行分支：引擎内管道、父进程管道、单命令透传、`--tty` 直通。逻辑一行未改。
- `Session` 改 `unit class … does …Commands …Config …Diagnostics …Persistence …Cells …Replay …Completion …Exec`。`META6.json` provides 54 → 55。
- 退出语义改为返回值表达：`Result` = 已处理，`Nil` = 不是 `!` 命令。`!=` / `!~~` 仍落回 Raku 求值。Session 侧只剩四行委派。
- 零新增公开面：区间只引用 `$.sys`（8/8）、`$.index`（2/15）、`$.stream-out`（2/2），三者早已公开。六个共享辅助（`!split-argv` / `!split-pipeline` / `!unclosed-quote` / `!remember` / `!strict-result` / `!emit-chunk`）留 Session。

**修复**
- `lib/Rakuish/Sys/FS.rakumod` 的 `follow` 轮询不再引用 `.l`：`.l` 对不存在的路径返回 **Failure 而不是抛**，布尔链里一求值就抛、`try` 接住后仍偶尔留到 GC，于是每次全套件都在 stderr 冒 `unhandled Failure detected in DESTROY … while trying to do '.l'`（`t/55` ④ 场景必现）。改为只认 `.e`（悬空符号链接本就按「文件还没回来」处理）：`my $size = $f.e ?? (try { $f.f ?? $f.s.Int !! Nil }) !! Nil;`。`t/55` 连跑 8 次与 `prove6` 单跑均无警告。

**测试**
- 新增 `t/90-exec-split.t`（**63 条**结构守卫）：role 头 / 八条 `does` 与 `use`；`!dispatch-bang` 归属正反两向；六个共享辅助留 Session；role 零私有属性引用且自带 `use`；`--> Any` + `Nil`；规模 `< 2,450` 且 `> 2,200`；provides 55。运行时覆盖：空 `!` 127、`!echo hi` 走 cmd 内建、`--capture` 非 streamed、`--pipe`+`--capture` 互斥、`--stdin` 不存在 127、`--timeout-ms nope` 127、`!echo a | findstr a`、`--tty` / `--pipe` 经注入执行器、`!=` 不是 `exec`。
- `t/89-completion-split.t` 的反空跑下界由 `> 2,600` 放宽为 `> 2,200`（Session 已降到 2,376）。
- 回归：`t/83` 53/53、`t/10` 164/164、`t/44` 34/34、`t/48` 24/24、`t/03` 56/56、`t/05` 160/160、`t/32` 11/11、`t/28` 14/14、`t/26` 29/29、`t/55` 21/21（stderr 干净）。
- 全套件 `prove6 -Ilib t/`：**86 个文件 / 4,148 条断言 / 全部通过**（0.151.0 是 85 / 4,084）。

**文档**
- 新建 `docs/ADR-0066-session-exec-split.md`（八节；§4 记录 `follow` 那个 Failure 的真因与修法）。
- `SPEC.md` 新增 **§3.85**（3.85.1 文件划分 / 3.85.2 退出语义 / 3.85.3 零新增公开面 / 3.85.4 结构不变量 63 条 / 3.85.5 顺带修复 / 3.85.6 本版不做）。
- `docs/ADR-INDEX.md` 66 份、条目数 66、新增 0066 行；`README.md` 同步 66 份。

## 0.151.0 — 2026-11-27

Session 拆分第六步：补全层 role（V-355 / ADR-0065）

**变更**
- `lib/Rakuish/REPL/Session.rakumod` **2,868 → 2,679 行**（17 insertions / 203 deletions）。新增 `lib/Rakuish/REPL/Session/Completion.rakumod`（`unit role Rakuish::REPL::Session::Completion`，**225 行 / 5 个方法**）：
  - `completions`（公开 API：CLI 的 `get-completions`、LineEditor 的 Tab）；
  - `!session-name-completions` / `!method-completions` / `!completion-value` / `!resolve-type`。
- `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells does ...Replay does ...Completion`。`META6.json` provides 53 → 54。
- **本簇零新增公开面**：`@.out` / `@.history` / `@.decls` / `%.state` / `$.shell` / `$.engine` 都是前几刀公开的。唯一的新入口是私有方法 `method !type-cache(--> Hash) { %!type-cache }` —— role 绑定活容器读写缓存；清空缓存那句仍留在 `!eval-raku`。
- `!resolve-type` 的 EVAL 改走 `self!eval-in-session(...)`（SPEC §3.81.3 的硬约束）。
- 留在 Session：`error-marks` / `!known-name` / `!path-names` —— 服务错误态标红，不属于补全管线。

**修复**
- 规则再进一步（SPEC §3.84.2）：**role 需要的是「能读写那块状态」，不是「那块状态对用户可见」** —— 私有方法当活容器入口，比公开属性便宜（不进 API、不留兼容包袱）。

**测试**
- 新增 `t/89-completion-split.t`（**51 条**结构守卫）：七条 `does` / `use`；5 个补全方法不在 Session、`error-marks` 三兄弟留在 Session；类型缓存三处仍在 Session 且 role 只经 `self!type-cache`；role 零私有属性引用、无裸 EVAL、三个 `use` 自带；`< 2,750` 且 `> 2,600`；provides 54；运行时 9 条补全路径（含 `Box.` 走通整条方法链、`Out[n]` / `In[n]`）。
- 回归：`t/10` 164/164、`t/23` 57/57、`t/25` 69/69、`t/63` 41/41、`t/20` 55/55、`t/88` 64/64、`t/53` 4/4。
- 全套件 `prove6 -Ilib t/`：**85 个文件 / 4,084 条断言 / 全部通过**（0.150.0 是 84 / 4,032）。

**文档**
- 新建 `docs/ADR-0065-session-completion-split.md`（八节，含「私有方法也是复合面」与管线的优先级图）。
- `SPEC.md` 新增 **§3.84**（3.84.1 文件划分 / 3.84.2 状态与私有活容器 / 3.84.3 EVAL 与依赖 / 3.84.4 结构不变量 51 条 / 3.84.5 本版不做）。
- `docs/ADR-INDEX.md` 65 份、条目数 65、新增 0065 行。
## 0.150.0 — 2026-11-27

Session 拆分第五步：输入重放簇 role（V-354 / ADR-0064）

**变更**
- `lib/Rakuish/REPL/Session.rakumod` **3,093 → 2,868 行**（17 insertions / 242 deletions）。新增 `lib/Rakuish/REPL/Session/Replay.rakumod`（`unit role Rakuish::REPL::Session::Replay`，**267 行 / 3 个方法**）：`!cmd-recall` / `!cmd-source` / `!cmd-paste`。
- `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells does ...Replay`。`META6.json` provides 52 → 53。
- **本簇没有新增任何公开属性**。仍私有的 `$!prefill` / `$!skip-record` / `@!pending` 在求值核心里还有引用（4 / 5 / 9 处），role 只做写入，所以用三个窄私有入口代替公开属性：`!set-prefill` / `!mark-recorded` / `!clear-pending`。读侧 `take-prefill` 留 Session（前端公开 API）。
- `&!input-handler` / `&!read-line` 无需改动：本来就是公开可调用属性，role 直接 `self.input-handler` / `self.read-line`。

**修复**
- 规则细化（写进 SPEC §3.83.2）：**属性公开与否看「外部是否该看见」，不看「role 是否需要」。** role 需要写、外部不需要看 → 私有窄入口；比公开一个 `is rw` 属性便宜，也不扩大界面。
- **拆分引入的回归（已修）**：`paste` 的读行从 `&!read-line()` 改写成 `self.read-line()` 时，后者仍然是**调访问器、返回 `Block`**，不是调用闭包 —— 于是 `--` 永不匹配、`paste` 死循环，全套件跑满 600 s 超时。修法是先 `my $reader = self.read-line;` 再 `$reader()`。`t/88` 62–64 三条断言钉住它（ADR-0064 §4.3）。
- 记录两个测试预期陷阱（不是行为变更）：值格的 `.out` 为空（值在 `.value`，`render` 才产出 `Out[n]`）；`recall` 的编号随历史增长漂移，守卫里必须按 `$s.history.elems` 动态算。`paste` 的两条路径 —— `input-handler` 已定义 = 引擎 / notebook 模式 → 「不可用」；未定义 → 读 `$*IN`，EOF → 「没有读到内容」。

**测试**
- 新增 `t/88-replay-split.t`（**64 条**结构守卫）：六条 `does` 与 `use`；三条命令不在 Session 而在 Replay；`take-prefill` 留 Session；三个窄入口在 Session 且 role 以 `self!name(` 调用；role 零 `$!` / `@!` / `%!` / `&!` 引用；`cmp-ok $sess-lines, '<', 2900`；provides 53；运行时 recall / source / paste 三条路径。
- 回归：`t/68` 59/59、`t/82` 88/88、`t/79` 45/45、`t/51` 32/32、`t/53` 4/4。
- 全套件 `prove6 -Ilib t/`：**84 个文件 / 4,032 条断言 / 全部通过**（0.149.0 是 83 / 3,967）。

**文档**
- 新建 `docs/ADR-0064-session-replay-split.md`（八节，含「窄入口 vs 公开属性」规则、两个测试预期陷阱、`self.read-line()` 死循环的教训）。
- `SPEC.md` 新增 **§3.83**（3.83.1 文件划分 / 3.83.2 窄入口规则 / 3.83.3 测试预期陷阱 / 3.83.4 结构不变量 64 条 / 3.83.5 本版不做）。
- `docs/ADR-INDEX.md` 64 份、条目数 64、新增 0064 行。
## 0.149.0 — 2026-11-27

Session 拆分第四步：格记录 / 导出簇 role（V-353 / ADR-0063）

**变更**
- `lib/Rakuish/REPL/Session.rakumod` **3,250 → 3,093 行**（5 insertions / 162 deletions）。新增 `lib/Rakuish/REPL/Session/Cells.rakumod`（`unit role Rakuish::REPL::Session::Cells`，**182 行 / 4 个方法**）：`!cmd-cells` / `!render-cells-list` / `!render-cells-text` / `!render-cells-json`。
- `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells`。`META6.json` provides 51 → 52。
- **本版不新增任何公开状态**：`cells` 要的 `@.cells` 与 `$.skip-cell` 在 0.147.0 就已公开（前者是诊断簇 `log-line` 的需求，后者是当时的预备项）。只把 3 处 `$!sys` 改 `$.sys`。
- `!split-argv` 留在 Session（输入层），Cells 按名调用（role 调类私有方法合法，ADR-0060 §2）。

**修复**
- Cells 自己写 `use JSON::Fast;`：Session 的 `use` 不泄漏进 role 的编译单元，`to-json` 漏了只在运行时才报 `Undeclared routine`。规则写进 SPEC §3.82.3。
- **编号规则改进**：ADR-0058（草案）不再预占条款号与测试文件名。它在 0.146.0 / 0.147.0 / 0.148.0 三轮里被顺延三次（V-350→V-351→V-352→V-353），每次改五处，而实施一次都没发生。改为「实施时取当时的下一个空位」，草案本身不再跟着动（ADR-0063 §6）。

**测试**
- 新增 `t/87-cells-split.t`（**46 条**结构守卫）：role 头 / 五条 `does` 与 `use`；4 个方法不在 Session 而在 Cells；`!split-argv` 留 Session；`@.cells` / `$.skip-cell` 公开；Cells 无私有属性引用；`cmp-ok $sess-lines, '<', 3150`；provides 52；运行时列表 / `--text` / `--json` / 写文件 / `skip-cell` 不自指 / 未知选项 `code=2`。
- 回归：`t/69` 59/59（cells 主要行为覆盖）、`t/73` 16/16、`t/37` 91/91、`t/53` 4/4、`t/84` 34/34、`t/85` 50/50、`t/86` 41/41、`t/51` 32/32。
- 全套件 `prove6 -Ilib t/`：**83 个文件 / 3,967 条断言 / 全部通过**（0.148.0 是 82 / 3,920）。

**文档**
- 新建 `docs/ADR-0063-session-cells-split.md`（七节：复利效应、零新增公开面、role 自备 `use`、结构不变量 46 条、草案编号规则改进）。
- `SPEC.md` 新增 **§3.82**（3.82.1 文件划分 / 3.82.2 状态：不新增公开面 / 3.82.3 role 自备依赖 / 3.82.4 结构不变量 46 条 / 3.82.5 本版不做）。
- `docs/ADR-INDEX.md` 63 份、条目数 63、新增 0063 行；ADR-0058 行改为「草案不预占号」。
- `docs/ADR-0058-process-handle-stream.md`：五处预留改成「号在实施时分配」，并加一段规则说明。
## 0.148.0 — 2026-11-27

Session 拆分第三步：快照 / store 层 role（V-352 / ADR-0062）

**变更**
- `lib/Rakuish/REPL/Session.rakumod` **3,630 → 3,250 行**（15 insertions / 395 deletions）。新增 `lib/Rakuish/REPL/Session/Persistence.rakumod`（`unit role Rakuish::REPL::Session::Persistence`，**417 行 / 7 个方法**）：
  - 快照（ADR-0022）：`!init-snapshot` / `save-snapshot` / `restore-snapshot` / `restored`；
  - 跨会话变量库（ADR-0053）：`!cmd-store` / `!store-candidates` / `!store-decl-src`。
- `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence`。`META6.json` provides 50 → 51。
- 按 §3.79.2 的规则只公开两个属性：`%!restored` → `%.restored-info`（不能叫 `%.restored`：与公开方法 `restored` 撞名）、`@!restore-failed` → `@.restore-failed`。其余全部走既有公开面（`$.snapshot-on` / `$.snapshot-path` / `$.store-path` / `$.index` / `$.sys` / `%.state` / `@.decls`）。
- 恢复用的 EVAL 留在 Session：新增 `method !eval-in-session(Str $code) { EVAL $code }`，role 调它。

**修复**
- 拆分中钉死一条硬约束：**role 里 EVAL，用户 `my class Foo` 会落到 role 包名下**（实测 `R1::Foo`）。快照 `.raku` 的前缀是 `Rakuish::REPL::Session::`，在 role 里 EVAL 会得到 `…::Persistence::Foo`，剥不干净 → 恢复出的用户类型找不到。这是 SPEC §3.81.3 的由来。
- 编号顺延：本版用掉 V-352 / `t/86`，ADR-0058（草案）的预留再顺延为 **V-353 / `t/87-spawn-stream.t`**。

**测试**
- 新增 `t/86-persistence-split.t`（**41 条**结构守卫）：role 头 / 四条 `does` 与 `use`；7 个方法不在 Session 而在 Persistence；`!state-alias` / `!eval-in-session` 留在 Session；`%.restored-info` / `@.restore-failed` 公开且无私有残留；`cmp-ok $sess-lines, '<', 3300`；provides 51；运行时 `restored` 空 Hash、`snapshot-path` 含 `session-`、`store -l` / `--help` / `-d` 走 role。
- 回归：`t/84` 34/34、`t/85` 50/50、`t/14` 7/7、`t/18` 70/70、`t/19` 98/98、`t/34` 59/59、`t/40` 51/51、`t/42` 58/58、`t/45` 48/48、`t/51` 32/32、`t/64` 63/63、`t/67` 19/19、`t/81` 54/54、`t/82` 88/88。
- 全套件 `prove6 -Ilib t/`：**82 个文件 / 3,920 条断言 / 全部通过**（0.147.0 是 81 / 3,878）。

**文档**
- 新建 `docs/ADR-0062-session-persistence-split.md`。
- `SPEC.md` 新增 **§3.81**（3.81.1 文件划分 / 3.81.2 状态暴露 / 3.81.3 EVAL 词法包 / 3.81.4 结构不变量 41 条 / 3.81.5 本版不做）。
- `docs/ADR-INDEX.md` 62 份、条目数 62、新增 0062 行；ADR-0058 行的预留改 V-353 / `t/87`。
- `docs/ADR-0058-process-handle-stream.md` 的预留（V-352 / `t/86`）全文顺延为 V-353 / `t/87`。

## 0.147.0 — 2026-11-27

Session 拆分第二步：诊断 / 渲染簇 role（V-351 / ADR-0061）

**变更**
- `lib/Rakuish/REPL/Session.rakumod` **4,035 → 3,630 行**（93 insertions / 498 deletions）。新增 `lib/Rakuish/REPL/Session/Diagnostics.rakumod`（`unit role Rakuish::REPL::Session::Diagnostics`，**436 行 / 17 个方法**）：
  - 命令：`!cmd-explore` / `!cmd-perf` / `!cmd-tb` / `!cmd-audit` / `!cmd-log` / `!cmd-hint` / `!cmd-who`；
  - 辅助：`perf-report` / `!render-trace` / `collect-traceback` / `!source-line` / `log-line` / `hint-text` / `next-hint` / `!sigil-rank` / `!value-type` / `!value-size`。
- `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics`。`META6.json` provides 49 → 50。
- 按 §3.79.2 的规则把诊断簇要用的 8 个私有状态改公开：`$!log-on` / `$!log-path` / `$!log-seq` / `@!log-lines` / `@!decls` / `@!out` / `@!cells` / `%!hinted` → `$.` / `@.` / `%.`；顺带公开 `$.expanding` / `$.skip-cell`（不在本簇，属预备）。`$!last-error` / `$!last-error-text` 保持私有，role 改调公开的 `last-error` / `last-error-text`。
- 日志访问器收敛：`log-active` 留在 Session（读 `$!log-on`）；`log-path` / `log-lines` 删掉手写只读方法，由 `has Str $.log-path is rw` / `has @.log-lines is rw` 的属性访问器承担。`log-lines` 因此返回活 Array 而非 List 拷贝（无代码/测试依赖旧形状）。

**修复**
- 拆分中撞到两个访问器陷阱，已写进 SPEC §3.80.3 作为硬约束：
  - `method log-path { $.log-path }` 自递归（`$.x` 是方法调用）→ `MoarVM panic: Memory allocation failed; could not allocate 131072 bytes`；
  - 手写只读 `log-path` 遮蔽 `is rw` 属性的写访问器 → role 写 `$.log-path` 报 `Cannot modify an immutable Str ()`。
- 编号顺延：本版用掉 V-351 / `t/85`，ADR-0058（草案）的预留再顺延为 **V-352 / `t/86-spawn-stream.t`**（0.148.0 用掉 V-352 / `t/86` 后，草案再顺延为 **V-353 / `t/87`**）。

**测试**
- 新增 `t/85-diagnostics-split.t`（**50 条**结构守卫）：四文件 / 三个 role 头 / 三条 `does` 与 `use`；7 条命令与 10 个辅助不在 Session；`log-active` 留在 Session 且不在 role；`log-path` 无手写方法；`cmp-ok $sess-lines, '<', 3700`；provides 50 与 Diagnostics 条目；运行时 `who` / `perf` / `tb` / `log` / `hint` 与空 `collect-traceback`。
- 回归：`t/84` 34/34、`t/14` 7/7、`t/19` 98/98、`t/34` 59/59、`t/40` 51/51、`t/64` 63/63、`t/67` 19/19、`t/82` 88/88。
- 全套件 `prove6 -Ilib t/`：**81 个文件 / 3,878 条断言 / 全部通过**（0.146.0 是 80 / 3,827）。

**文档**
- 新建 `docs/ADR-0061-session-diagnostics-split.md`。
- `SPEC.md` 修正编号：Session 拆分第一步由误编的 §3.76 改为 **§3.79**（子节 3.79.1–3.79.5）；新增 **§3.80**（诊断 / 渲染簇，其中 §3.80.3 是访问器陷阱的硬约束）。
- `docs/ADR-INDEX.md` 61 份、条目数 61、新增 0061 行。
- `docs/ADR-0060-session-split.md` 的 `SPEC §3.76` 引用改 §3.79。

## 0.146.0 — 2026-11-27

Session 拆分第一步：两个 role + 公开访问器（V-350 / ADR-0060）

**变更**
- `lib/Rakuish/REPL/Session.rakumod` **4,304 → 4,035 行**。拆出两个 role：
  - `lib/Rakuish/REPL/Session/Commands.rakumod`（`unit role ...::Commands`）：
    `!cmd-errors` 与它独占的三个属性（`$.error-mode` / `$!last-error-kind` /
    `$!last-error-loc`）—— 后者是唯一搬走的属性，因为 `!eval-raku` 的 `CATCH`
    在类里写它们，而命令在 role 里读。
  - `lib/Rakuish/REPL/Session/Config.rakumod`（`unit role ...::Config`）：
    配置 / 别名 / `set -o` 选项 / hook / plugin 共 **16 个方法**（`config-path`
    `!load-config` `!save-config` `!option-names` `!option-table` `!set-option`
    `options` `!aliases` `!expand-alias` `!cmd-alias` `!cmd-unalias` `!cmd-config`
    `!hooks` `run-hooks` `!cmd-hook` `!cmd-plugin`）。
- `Session` 改成 `unit class Rakuish::REPL::Session does ...Commands does ...Config;`
  （`use` 两条写在 `unit` 之前 —— `does` 在声明处就要解析到 role 名）。
- **定下往后拆分的属性归属规则**：属性一律留在 `Session.rakumod`，role 方法经
  公开访问器（`$.x` / `%.x` / `@.x`）读写；只有「类方法也必须写」的属性才随方法
  搬进 role。依据是四条实测：`trusts` 在 Rakudo v2026.11 **未实现**（四种写法
  全部 `Unable to parse class definition`）；role 方法读**类声明**的私有属性报
  `Attribute %!h not declared in role R1`；role 方法读**类公开访问器** → 读、写
  标量、写哈希、改数组、写布尔、调另一对象方法**六项全过**，且写回落到原对象。
- 划分依据是可测量的耦合度：`%!config` 在命令内 18 次、命令外 **0** 次（天然
  子系统），而 `@!decls` 5/33、`%!state` 9/26、`@!history` 15/23 与求值核心强
  耦合，**不许**整组搬走。
- `META6.json` provides 加两条（`Rakuish::REPL::Session::Commands` /
  `...::Config`），47 → 49 条。行为完全不变。

**修复**
- 编号冲突：`docs/ADR-0058-process-handle-stream.md`（草案）原写「实现时新增
  V-350 起条款、回归 `t/84`」，与本次实际用掉的 V-350 / `t/84` 撞车，草案里的
  预留改为 **V-351 / `t/85-spawn-stream.t`**（草案尚未实施，改预留无成本）。0.147.0 用掉 V-351 / `t/85` 后，草案再顺延为 **V-352 / `t/86-spawn-stream.t`**。

**测试**
- 新增 `t/84-session-split.t`（**34 条**结构守卫）：三文件存在、两个 `unit role`
  头正确、`Session` 的两条 `does` 与两条 `use` 都在；**反方向**断言
  `!cmd-errors` 不在 Session、7 个搬走的命令/辅助方法不在 Session 而在 Config
  （`run-hooks` / `options` 同理）；规模上限 `cmp-ok $sess-lines, '<', 4150`
  （比拆分前的 4,304 小、比现在的 4,035 宽松 —— 允许增长，不允许把命令搬回来）；
  运行时 `$s.options` 仍 5 项且名字不变、`run-hooks('no-such-event')` 为空、
  `$s.histexpand` 为真。
- 回归：`t/82` 88/88、`t/37` 91/91、`t/51` 32/32、`t/05`/`t/10`/`t/18` 全绿。

**文档**
- 新建 `docs/ADR-0060-session-split.md`（七节：背景 / 四次探针 / 决定 /
  没采用的三个方案 / 不变量 / 结构守卫清单 / 下一步）。
- `SPEC.md` 新增 §3.79（五个小节；当时误编为 §3.76，0.147.0 修正），其中 §3.79.2 的属性归属规则是往后拆分的
  硬约束。
- `docs/ADR-INDEX.md` 60 份、条目数 60、新增 0060 行。

## 0.145.0 — 2026-11-27

管道透传：`! --pipe a | b`、`--pipefail`、`--stdin FILE`（V-349 / ADR-0059）

**新增**
- `! --pipe`（`-P`）：末段 stdout / stderr **不捕获**，逐块直写当前进程的
  stdout / stderr。`Result.out` / `.err` 为空、`streamed=True`，结束不重放；
  `ok` / `code` / `value<stages>` 照旧。`start-failed` 例外，`err` 保留。
  与 `--capture` **互斥**，同时出现 → `127`。
- 执行位置：交互式 REPL（worker）经 `pipe-exec` 中间帧交**父进程**执行
  （引擎 stdout 是协议流）；`-e` / 脚本 / stdin 管道在**本进程**执行。
  worker 下无执行器 → `127`，绝不把原始输出写进协议流。
- `--pipe` 默认 `timeout-ms=0`（不设总时限），显式 `--timeout-ms N` 仍生效。
- `--pipefail`：退出码取**最右**非零段（全 0 才 0），捕获式管道同样可用；
  超时 `124` / 取消 `137` / 启动失败 `127` 优先于段码。
- `--stdin FILE`：首段 stdin 从文件流式接入。路径经 `Sys.resolve` 解析为
  绝对路径（root 沙箱）；缺参 / 路径无效 / 文件不存在 → `127`。
- `Sys::Proc.spawn` 新增 `:stdin-file`（16 KiB 分块 + `await` 背压；
  与 `:in` / `:&in-chunks` 三来源互斥）；`spawn-pipeline` 新增
  `:pipefail` / `:stdin-file` / `:no-capture`，段数下限放宽到 1
  （单命令按一段管道处理）。
- 协议：`pipe-exec` 中间帧新增四个**可选**键 `no-capture` / `pipefail` /
  `stdin-file` / `timeout-ms`；`PROTOCOL-VERSION` 仍为 2。hook 无附加选项时
  仍按老签名调用（兼容旧闭包）。

**变更**
- `!` 元选项从 `--tty` / `--capture` / `--timeout-ms` / `--no-timeout`
  扩展为另加 `--pipe` / `--pipefail` / `--stdin`；默认行为（捕获、取末段码、
  30 s 总时限）完全不变。

**边界**
- 这是**数据层**透传：子进程 stdout 仍是管道（`isatty=0`），颜色 / 进度条 /
  TUI 仍不成立；真终端语义走 `--tty` / `pty-exec`。不做 dup2 / PTY。
- 不做 ADR-0058 的 C 方案（公开 `sys.spawn` 流式 API）；ADR-0058 仍是草案。

**文档**
- 新增 [`docs/ADR-0059-pipe-passthrough.md`](docs/ADR-0059-pipe-passthrough.md)；
  `ADR-0058` 的条款号改为 V-350（避免占号）。
- SPEC 新增 §3.78 / V-349，并同步 V-118 / V-203 / V-901；
  MANUAL 新增「透传与 pipefail」小节；DEVELOPMENT §5.3 补实现说明。

**测试**
- `t/83-pipe.t` 53 条（新增 ⑤ 组 21 条）：互斥 127；`--pipefail` 的
  `3|0` 与 `0|4|2`；`--stdin` 读文件 / 不存在 127；fake hook 收到四个选项、
  `out == ''`、`streamed`；`-e` 端到端末段直写 stdout。
- 全量（Windows `prove6 -Ilib t`）：79 个文件 / 3791 条断言，全绿。

---

## 0.144.0 — 2026-11-26

交互式管道：`! --tty a | b`（V-348 / ADR-0057）

**新增**
- `! --tty`（`-t`）**且**有顶层管道时，整条管道由**父进程**执行：引擎子进程
  的 stdin 是协议流，只有父进程能把真终端 stdin 交给第 0 段，
  `! --tty more | findstr x` 因此可用。普通 `! a | b` 仍是引擎内管道
  （V-347），语义不动。
- 仅第 0 段继承终端 stdin，段间仍是同一套 Channel 泵；末段 stdout/stderr
  **捕获**进 `Result`（`Out[n]` / `_` 可用），v1 不做父→引擎的块流式。
- 无父进程执行器（notebook / 测试）或 stdin 非 TTY → `code=127` 并说明；
  **绝不回退引擎内**（第 0 段会吃掉协议 stdin，REPL 当场错位）。
- 交互式管道固定 `timeout-ms=0`；`--timeout-ms` 在 `--tty` 下无效。
- Ctrl-C：POSIX 子进程与父同 pgid，随终端收 SIGINT；Windows 父侧把整组
  收养进命令级 Job 并 terminate；引擎不重启，最终 `code=130`。
- 协议：新增中间帧 `event=pipe-exec`（`seq` + `stages`），回包沿用
  `cmd=resume` + 嵌套 `pipe` Hash；`PROTOCOL-VERSION` 仍为 2。
- Windows：`--tty` + 管道时第 1 段也过 cmd 内建重写（V-333 条件放宽）。
- 被信号收掉的段：退出码归一为 `128+signal`（SIGINT → 130），不再记 1。

**测试**
- `t/83-pipe.t`（32 条）：原「`--tty` 与管道互斥」两条改写为「无执行器 →
  127」「fake 执行器调用一次 / 2 段 / 输出透传 / 非流式」。
- `t/41-eval-worker.t` ④b（+8 条）：真引擎 + fake `:pipe-exec` 往返，
  argv 不拼 shell 串；未注册 → 127。
- 全量（Windows `prove6 -Ilib t`）：79 个文件 / 3770 条断言，全绿。

---

## 0.143.0 — 2026-11-26

`!` 行支持管道：`! a | b | c`（V-347 / ADR-0056）

**新增**
- `!` 行支持**顶层单个** `|` 串联外部命令，只切**引号外**的 `|`：
  `! dir | findstr lib`。语法糖只落在 `!` 行 —— 这一行不经过 Raku 解析，
  零 grammar 代价；Raku 表达式侧仍没有管道语法（V-243 不松动）。
- 语义是「进程串联」，不是 shell：stage[i] 的 stdout 接 stage[i+1] 的 stdin；
  stderr 各段独立收集后拼接；退出码取**末段**（不做 `pipefail`）；各段的码
  与启动失败记在 `Result.value<stages>`，整体标 `value<pipeline>`。
- `Sys.pipe-exec(@stages, :&on-out, :&on-err)` + `Sys::Proc.spawn-pipeline`：
  段间复用 `:&in-chunks` 做 Channel 泵（写一块 `await` 一块 = 背压，下游提前
  关 stdin 就停喂，EOF 自动关 stdin）。大输出不会整份进内存，2 万行 0.5 s。
- Windows：整条管道**一次性**收养进一个 Job —— `child` 帧新增 `pids`，
  父侧 `!adopt-children` 走 `WinJob.assign-many`。逐段收养会因
  `KILL_ON_JOB_CLOSE` 与每次 `drop` 把前一段连带杀掉。
- `||` 报「管道里有空段」而不是猜；`--tty` 与管道互斥并明确报错。

**测试**
- 新增 `t/83-pipe.t`（26 条）：数据通路 / 三段 / 2 万行早停 / 退出码取末段 /
  各段码 / stderr 不合流 / 末段 127 + start-failed / `!` 行切段 / 引号内
  `|` 不切 / `--tty` 与 `||` 拒绝。
- 全量（Windows `prove6 -Ilib t`）：79 个文件 / 3756 条断言，全绿。

**文档**
- 新增 `docs/ADR-0056-engine-pipeline.md`，并更新 ADR 索引、SPEC（3.76 / V-203 /
  V-243 / V-901）、MANUAL「管道」小节、README 输入表格、`!` 提示条。

## 0.142.1 — 2026-11-26

文档守卫补漏：SPEC 自述版本停在 0.124.0（V-345）

**修复**
- `SPEC.md` 开头「本文件是唯一真值（…，当前 x.y.z）」自 0.124.0 起就没再更新，
  而实际版本已到 0.142.0。`t/51` 从 0.130.0 起守着 README / MANUAL / HANDOFF /
  ADR-INDEX 四处版本，唯独漏了这份「真值」本身 —— 越是被当作真值的文件，
  越不该只靠人肉同步。现在改为 0.142.1，并纳入断言。

**测试**
- `t/51` 新增一条：解析 `SPEC.md` 的「Phase 5b 起，当前 x.y.z」，要求等于
  `META6.json` 的当前版本。

## 0.142.0 — 2026-11-26

启动不再后台扫 PATH（V-346 / ADR-0055）

**修复**
- 「刚启动就卡」：CLI 一直在启动时 `start { path-executables() }` 预热 `! <Tab>`
  的补全表。本机 25 个 PATH 目录 / 5,980 个条目（`system32` 一个目录就 4,667）
  扫一遍 1.1–1.3 s，于是每个会话的前一秒都在和用户输入抢线程、抢磁盘。
  现在删掉预热，改成三级查找：进程内缓存 → 磁盘缓存
  （默认 `$*HOME/.rakuish/path-executables.json`，键 = 平台 + PATH + PATHEXT）
  → 真扫描。端到端启动 **1.03 s → 0.60–0.65 s**，后台扫盘降为 0；
  首次 Tab 仍付 1.1 s（只此一次），之后跨进程 **13 ms**。
- 缓存**按 PATH 失效**、不按时间：装了新工具或改了 PATH，下一次 Tab 就能看到。
  过期（TTL 一天）时先返回旧表、后台刷新一次，不让任何人为了新鲜度等 1 秒。
- `RAKUISH_PATH_CACHE=<路径>` 改缓存文件；`off` / `none` / `0` 关闭（既不读也不写）。
  缓存文件损坏 / 版本不符 / 键不匹配一律当空缓存，写盘失败静默 —— 缓存问题
  不该让补全失败。

**测试**
- `t/10` 156 → **164** 条：缓存组四条行为（冷扫描写盘、命中读盘（哨兵替换
  证明没有回去重扫）、PATH 变则失效、`off` 不读不写）。**不测时间**。

**文档**
- 新增 `docs/ADR-0055-path-executable-cache.md`；SPEC §3.75 V-346；
  MANUAL §14 环境变量表补 `RAKUISH_PATH_CACHE`。

## 0.141.1 — 2026-11-26

跨平台测试修复：Linux 安装与「PATH 上有 dir.exe」的 Windows（V-331 / V-332）

**修复**
- `t/10` 的「`env-var` 对大小写不敏感」无条件跑了：大小写不敏感是 **Windows 专属**
  口径（V-331 明写「POSIX 行为不变」），Linux 上 `env-var('path')` 本来就该是空串。
  0.136.1 的 Linux `zef install .` 就红在这一条：期望整条 PATH，实得 `''`。
  现在按平台分支——Windows 断「大小写不敏感」，POSIX 断「不跨大小写偷值
  （`path` 与 `PATH` 各自独立）」。
- `t/10` 的「`! dir` 能列当前目录」假定 PATH 上没有真 `dir.exe`。有的机器
  （Git for Windows / MSYS 的 coreutils）有，按 ADR-0049 §2 的「真 exe 优先」
  回落不参与，于是断言的前提本身不成立（0.140.0 在一台这样的机器上红）。
  现在先问实现「这次会回落吗」：会回落 → 断「交给 `cmd.exe`」+ 列出 `a.txt`；
  不会 → 断「spawn 的就是 `dir`、argv 原样两项」。失败消息会带出 `code` / `err` / `out`。

**文档**
- SPEC §3.60 V-331 / §3.61 V-332 补记两条平台分支的理由与这次的实测红。

## 0.141.0 — 2026-11-26

文档入口：变更日志 + 英文 README，并把「不漂移」变成断言（V-345）

**新增**
- `CHANGELOG.md`（本文件）：从 0.123.0 起逐版本记录新增 / 变更 / 修复 / 文档，
  标出对应的 SPEC 条款与 ADR；更早的版本只指 `git tag` / `git log`（评审 P3.4：
  「46 天 93 个 tag，用户无法跟踪」）。
- `README.en.md`：英文入口，含安装、快速开始、两种输入、核心 API、
  **英文的 MANUAL 目录**（逐节指向 `docs/MANUAL.md` 的行号）、测试、明确不支持、
  平台、许可（评审 P3.5 的最低要求）。
- `SPEC.md` §3.74 V-345：文档契约——每版必须有一节日志、最新一节必须等于
  `META6.json` 的版本且带日期、中英 README 必须互链。

**变更**
- 中文 `README.md` 增加两行入口：英文 README 与 CHANGELOG。

**测试 / 文档**
- `t/51` 从 18 条扩到 **31 条**：CHANGELOG 有版本节 / 第一节等于当前版本 / 带日期 /
  有「发布节奏」节 / 说明了格式约定 / 英文 README 存在且三条链接在 / 有英文目录 /
  中文 README 反向链接 / MANUAL 仍自称使用手册。
- 英文 README 刻意**不写版本号**：版本号唯一来源是 META6，四处已由 `t/51` 守着，
  不给自己多加一个要同步的地方。

## 0.140.0 — 2026-11-26

错误分级 `errors short|full` + 历史预填 `recall [n]`（V-344 / [ADR-0054](docs/ADR-0054-error-modes-and-recall.md)）

**新增**
- 会话命令 `errors [short|full]`：失败格头一行给出**类型**——编译错误 / 运行错误 /
  被拒绝，并附位置「第 N 格第 M 行」。`full` 额外附完整回放帧；`short` 是默认。
- 会话命令 `recall [n]`：把历史第 n 条（负数从末尾算，默认上一条）放进预填缓冲
  并回显，**不执行**；`take-prefill()` 读一次即清、且只活到下一格。与 `rerun` 共用编号。

**变更**
- 失败格的 `err` 文本统一变成 `类型: 消息（位置）`。判据是异常类型，不看消息文本；
  `X::Rakuish` 族用包含判定（实际类名带 `Rakuish::Result::` 前缀）。
- 位置只从 `EVAL_k` 帧折算（`行 = 帧行 - (prelude 行数 + 1)`），折算不出有效行只报格号，
  不硬造行号，也不把驱动 / 调用方的文件行报给用户。

**修复**
- `errors full` 在 `repl.trace = False` 的会话里原本只有头没有回放帧（记录异常的判据
  只看 `$!bt`），已按 `error-mode` 放宽。

**测试 / 文档**
- 新增 `t/82-errors-recall.t`（88 断言）；全量 **78 文件 / 3705 断言**。
- SPEC §3.73 V-344；ADR-0054；README / MANUAL / ADR-INDEX（54 份）同步。

## 0.139.0 — 2026-11-26

跨会话变量库 `store`（V-343 / [ADR-0053](docs/ADR-0053-cross-session-store.md)）

**新增**
- `store $x @rows %cfg`：按名保存到 `$*HOME/.rakuish/store.json`（`RAKUISH_STORE`
  或 `store -f PATH` 可改）；`store -l` 列库、`store -r x` 读回、`store -d x` 删除、
  `store --clear` 清空。
- 新模块 `lib/Rakuish/Store.rakumod`（信封版本 / 原子写 / 坏文件回落到空库）。
- 条目带**声明源码**，所以用户类实例读回时能重建类型（`$p.show` 仍可用）。

**变更**
- 不可保存的值（闭包 / 句柄 / 超上限）**当场拒绝并给理由**，与快照的「标记失效」
  相反——变量库是显式动作，静默丢弃不可接受。

**测试 / 文档**
- 新增 `t/81-store.t`（54 断言）；全量 **77 文件 / 3617 断言**。
- SPEC §3.72 V-343；ADR-0053；MANUAL 新增「跨会话变量库」；provides 46→47。

## 0.138.0 — 2026-11-26

块输入 `paste`（V-342 / [ADR-0052](docs/ADR-0052-block-input-paste.md)）

**新增**
- 会话命令 `paste`：读 stdin 到一行恰为 `--` 或 EOF，整段源码当**一个格**执行；
  只产生一个 `Out[n]`、一条 history、一条 `cells` 记录。

**变更**
- `Session` 新增可注入的 `read-line`（不是 `input-handler`：后者是协议通道），
  测试与前端可替换 stdin。
- vi 模式下 bracketed paste 仍会被当键吞掉的说法，MANUAL 改为指向 `paste` 命令。

**修复**
- 四种拒绝面各有明确文案：空块 / 参数 / 源码不完整 / 引擎模式（stdin 是协议流）。

**测试 / 文档**
- `t/05` +15 断言；全量 **76 文件 / 3562 断言**。SPEC §3.71 V-342；MANUAL 新增章节。

## 0.137.0 — 2026-11-26

数据层：`to-text` 可选行 + CSV 补 `bool` / `datetime`（V-341）

**新增**
- `Table.to-text(:index, :dtype, :shape)`：行号（表内 0 基，`limit`/`offset` 后重数）、
  `dtypes: a int, b str`、`(N rows × M cols)` 三行可选；默认全关，老输出逐字节不变。
- `from-csv-data` 逐列推断补齐 `bool`（只认 `true`/`false`）与 `datetime`
  （`YYYY-MM-DD hh:mm:ss`，且 `DateTime.new` 能解析才认）。

**变更**
- 截断提示移出表头，改到数据行之后、`dtypes`/`shape` 之前；`shape` 报整表行数。
- 推断**只改类型标签**，单元格原值一律保留。

**测试 / 文档**
- `t/11` 48→71 断言；全量 **76 文件 / 3544 断言**。SPEC §3.70 V-341。

## 0.136.1 — 2026-11-26

修复 `prompt()` 把引擎卡死（V-340 / ADR-0051 v3 + ADR-0037 §11）

**修复**
- 引擎里 `prompt()` 无限递归：`read-msg` 读的是动态 `$*IN`，而格内 `$*IN` 已被换成
  转发到 `input-handler` 的替身，于是「handler 发帧 → 再读协议 → 又进 handler」。
  现在协议流在 `serve-engine()` 入口抓成模块级 `$PROTO-IN`/`$PROTO-OUT`，
  用户代码对 `$*IN`/`$*OUT` 的替换影响不到它（ttc / notebook 两种入口都覆盖）。
- 格内 `emit` 原本写进该格的捕获缓冲，帧到不了父进程——同上修复。
- notebook 主循环的读端线程化：`ops` Channel 由读线程投递，`input_reply` 在读线程
  直投 `$input-reply`，主循环不再被读阻塞。
- `prompt` 文案现在真的到 handler（Rakudo 的 `prompt` 会先 `print` 再读，之前文案被
  `print` 进捕获缓冲，handler 收到空串）。

**测试 / 文档**
- `t/05` +5、`t/65` 第 12 组 +7；全量 **76 文件 / 3521 断言**。
- SPEC §3.69 V-340；ADR-0051 v3、ADR-0037 §11。
- 另：补齐 0.130.0–0.136.0 共 8 个漏打的 annotated tag（此前最新只到 v0.129.0）。

## 0.136.0 — 2026-11-26

Notebook `serve()` 传输回调化（V-339 / ADR-0037 §10）

**变更**
- `Kernel::Notebook.serve(:$lib, :&read-line, :&write-frame)`：传输由调用方注入，
  `serve` 不再自己抓 `$*IN`/`$*OUT`；写帧回调收到一帧 JSON 本体（不带换行）。
- emit 收进 `serve` 闭包并包 try，坏帧不再掀掉主循环。

**测试**
- `t/65` 新增第 11 组：内存闭包驱动整个 serve 生命周期。

## 0.135.0 — 2026-11-26

错误详情走独立 `error_info` 帧（V-338 / ADR-0051 v2）

**变更**
- `PROTOCOL-VERSION` 1→2：失败格不再把 `ename`/`evalue`/`traceback` 塞进 result 终帧，
  改为先发一帧 `error_info` 中间帧；`EvalReply` 与 `Rakuish::Result` 都删掉这三个字段。
- Client 把 error_info 收进 `last-error-info`；Proxy 透传；Notebook 前端拼回 Jupyter
  `error` 消息（`ename`/`evalue`/`traceback` 语义不变）。

## 0.134.0 — 2026-11-26

审计四项（V-336 / V-337）

**修复 / 变更**
- `open-data(:max-rows)`：CSV / Parquet 读入口把上限下推给引擎，物化前截断；
  没有默认值，避免静默截断。
- `Sys::FS` 的复制 / 写入上限：`cp(:max-bytes)` 可单次抬高，条目上限扫描**边数边失败**，
  报错文案给出两条退路（`Sys.new(:max-bytes/:max-entries)`）。
- SQL 桥（`Rakuish::Data::Duck`）去掉临时文件交换：改为 `CREATE TABLE` DDL +
  Duckula Appender 直插（50k 行稳态 ~1.5 s；>int64 现在显式报错而不是溢出成负数）。
- `Table` 属性私有化 + 只读视图 `columns` / `rows` / `types`（`types` 返回克隆，
  防止外部改内部状态）。

**文档**
- SPEC §3.65 V-336、§3.66 V-337；ADR-0043 §6/§7；`docs/analysis/README.md` 给 8 份
  同行分析文档标注「已落地 / 已过期」。

## 0.133.0 — 2026-11-26

引擎协议契约（V-335 / [ADR-0051](docs/ADR-0051-engine-protocol-contract.md)）

**新增**
- `lib/Rakuish/Eval/Protocol.rakumod`：`PROTOCOL-VERSION`（独立于 META6 `api`）、
  `EvalReply`（`to-hash`/`from-hash`）、`FRAME-FIELDS`、`check-ready` / `check-frame`。
- 引擎 ready 帧带 `protocol`；握不上就明确报「残留旧引擎进程 / 协议版本不符」。
- 帧校验失败抛 `X::Rakuish::Protocol`（带原始帧 JSON）；`event=error` 折叠成只含
  `seq/event/ok/op/code/text/out/err` 的失败结果帧，避免 Proxy 的默认值把 `Out[n]` 归零。

## 0.132.1 — 2026-11-26

**修复**：裸 `enum` / `subset` 声明把整个会话锁死（V-334）
- `!scan-cell` 的「给裸类型声明补 `my`」名单只有 `class|role|grammar`，漏了
  `enum|subset|constant`，于是裸 enum/subset 进了 GLOBAL，之后每格都报
  `Redeclaration of symbol` / `Invalid typename`。
- 名单补齐；读旧快照时同样补 `my`，所以老会话文件不会把新版本锁死。

## 0.132.0 — 2026-11-26

§4.9 的四项 IPython 差距（CSV 类型推断、`help()` 列表、错误回放、notebook）
- `t/18` 增枚举 / 子集 / 常量跨格与新会话可用性断言（0.132.1 的回归就在这组里）。

## 0.131.0 — 2026-11-25

长会话前奏按需裁剪（V-333 / [ADR-0050](docs/ADR-0050-eval-prelude-slicing.md)）
- 每格不再无条件重放全部别名与缓存声明，只挑「本格点名」的，并沿源码做传递闭包。
- 40 声明会话每格 48–70 ms → 9–13 ms；`use` 与运算符类声明仍总是重放。

## 0.130.0 — 2026-11-25

Windows 的 cmd 内建命令（V-332 / [ADR-0049](docs/ADR-0049-windows-cmd-builtins.md)）
- `! echo hi` / `! dir /b` 这类磁盘上没有同名 exe 的命令，改走
  `cmd.exe /d /c`（固定白名单 + 逐个 `^` 转义）：`&`/`|`/`>` 仍是字面参数、
  `%VAR%` 不展开；`Sys.exec` 与 `--tty` 不走这层回落。
- `t/51` 扩到 18 断言：README / MANUAL / HANDOFF / ADR-INDEX 的版本必须与 META6 一致，
  ADR 条目数必须等于真实文件数，META6 的每个依赖都要在 README 里露面。

## 0.129.1 — 2026-11-25

**修复**：Windows 上 `PATH` / `HOME` 的大小写（V-331）
- Windows 进程环境里的键是 `Path` 而不是 `PATH`，Rakudo 的 `%*ENV` 大小写敏感：
  `%*ENV<PATH>` 为 Nil → `which`、PATH 补全全部空。新增 `env-var()` 做大小写无关查找，
  `get-env`/`set-env`/`unset-env` 也按同一口径解析键。
- Windows 没有 `HOME`（只有 `USERPROFILE`），会话 env 缺 `HOME` 时从 `$*HOME` 补。

## 0.129.0 — 2026-11-25

§4.9 e / g / i：`doc` 走内置例程、`Table` 的 `head`/`tail`、`html` 渲染。

## 0.128.0 — 2026-11-25

§4.7 会话名字补全：变量 / sub / class / 模块名。

## 0.127.0 — 2026-11-25

混合语句格里的 `sub` 与 `constant` 声明也能持久（§3.2c 的后续）。

## 0.126.0 — 2026-11-25

`constant` / `enum` / `subset` 声明持久（§3.2c）。

## 0.125.0 — 2026-11-25

对标 IPython 评审的 §4.9 b / c / d / f 散项。

## 0.124.0 — 2026-11-24

显示协议 P1（V-326…V-330 / [ADR-0048](docs/ADR-0048-display-protocol.md)）
- `display($v)` 在同一格多次输出：终端立即显示降级文本，不产生 `Out[n]`、不改 `_`；
  notebook 里走 `display_data`。
- `HTML` / `Markdown` / `JSON` 三种内置包装；任何类型实现 `method to-mime(--> Hash)`
  即可自带渲染（SVG / LaTeX 原样透传）。

## 0.123.0 — 2026-11-24

对标 IPython 评审的 P0「止血」（V-319…V-325、`t/79`）
- 起点：`docs/REVIEW-VS-IPYTHON-2026-11-24.md`（四路实测复核）把差距分成 P0–P3；
  本版只修会让用户直接踩坑的那一档。

---

## 发布节奏

- 版本号只在 `META6.json` 一处为准；`bin/rakuish`、`lib/Rakuish/CLI.rakumod`
  （`FALLBACK_VERSION`）、`lib/Rakuish/Kernel/Notebook.rakumod`（`KERNEL-VERSION`）
  以及 README / MANUAL / HANDOFF / ADR-INDEX 的标题必须同步，由 `t/51` 守着。
- 每个版本一个 annotated tag，tag 消息 = 该版本一句话标题；
  `git tag --list 'v0.*'` 应能对上 CHANGELOG 的每一节。
- 缺陷修复升补丁号（`0.132.1`），新增命令 / API / 行为变更升次版本号（`0.138.0`）。
