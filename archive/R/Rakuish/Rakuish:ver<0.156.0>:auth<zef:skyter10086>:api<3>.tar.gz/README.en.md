# Rakuish

**A Raku-native command and scripting environment**: a REPL plus a programmable
system API. No bash subset, no `%magic`, no second syntax — **commands are Raku**.

Rakuish is **local and full-privilege**: no sandbox, no tokens, no permission gates
([ADR-0019](docs/ADR-0019-local-full-privilege-shell.md)). Raku source is evaluated
directly and `!` starts processes directly — anything the current user may do, Rakuish
may do.

**Standard Rakudo (MoarVM) only.** This is a pure Raku module: no compatibility
work for other Raku implementations, no "dual backend" claims
([ADR-0046](docs/ADR-0046-rakudo-only.md)).

> Chinese is the primary documentation language of this project. This file is the
> English entry point; the detailed specification is [`SPEC.md`](SPEC.md), the full
> manual is [`docs/MANUAL.md`](docs/MANUAL.md), and the primary README is
> [`README.md`](README.md). Per-release history is in [`CHANGELOG.md`](CHANGELOG.md).

The version of record is `META6.json` (`api = 3`); `rakuish --version` prints it.

---

## Install

Requires Raku (Rakudo / MoarVM) with the bundled `zef`.

```bash
zef install .          # or: bash tools/install.sh
rakuish --version
```

Runtime dependencies: `JSON::Fast`, `Terminal::LineEditor` (line editing / history),
`Terminal::API` (host termios snapshot since 0.72.4), `Arrow::IPC` (Arrow IPC I/O;
optional at runtime — `Data` degrades with a clear install hint when it is missing).
Tests use `Test`, which ships with Rakudo.

## Quick start

```bash
raku bin/rakuish                      # REPL (prompt on a TTY; line-by-line under a pipe)
raku bin/rakuish -e '1 + 1'           # evaluate a snippet and exit
raku bin/rakuish foo.raku a b         # run a Raku script (DSL preloaded; one-shot process)
raku bin/rakuish-notebook              # notebook protocol entry (one JSON per line)
```

If a script has `sub MAIN`, argument handling is delegated to Rakudo's own `RUN-MAIN`
(positionals, named args, coercion, `multi MAIN`, `--help`, custom `sub USAGE`, exit
codes) — the only difference is that `sys` / `repl` / the DSL are in scope.

## REPL input has exactly two kinds

| What you type | How it is handled |
|---|---|
| `! git status` | argv splitting (spaces + quotes) then `sys.exec`; `\|` `>` `$` `*` `&&` are **literal arguments** |
| `cd ..` / `ls docs` / `stat .` / `read file` | built-in command + bare literal paths rewritten into function calls; `$var` / expressions / quoted args stay Raku |
| Anything else (**including `%`-prefixed**) | a Raku expression, evaluated as-is; failure is failure, no silent shell fallback |

```text
rakuish> 1 + 1
Out[1] = 2
rakuish> ! git status --short     # external command: argv, no shell
rakuish> help()                   # commands + one-line summaries
rakuish> source lib.raku          # run a script in-session: its subs / vars stay in scope
rakuish> paste                    # block input: read stdin until "--", evaluate as one cell
rakuish> store $rows              # save variables across sessions (store -r / -l / -d)
rakuish> errors full              # full traceback on failures (short is the default)
rakuish> recall 3                 # put history entry 3 back into the input line (no execution)
```

There is **no auto-shell**: typing a bare `git status` yields Raku's
"undeclared routine" compile error. That is the point — which layer your input lands
on is always explicit.

## What makes it different

**Commands are Raku functions.** `ls`, `read`, `write`, `stat`, `exec` are ordinary
subs returning ordinary values (`IO::Path` lists, `Str`, `Result`), so they compose
with `.grep`, `.map`, `.sort` and everything else. File API errors throw (Raku style);
`rm`/`cp`/`mv`/`mkdir` return `Result`; `exec` never throws (exit codes `0` / `127`
start failure / `124` timeout / `137` cancel).

**A separate evaluation engine process (0.83).** Interactive `EVAL` runs in a child
process ([ADR-0021](docs/ADR-0021-eval-worker.md)). An accidental `exit;`, a NativeCall
segfault or a runaway `while 1 { }` no longer takes the REPL with it: the parent
restarts the engine, reports honestly what was lost, and restores declarations plus
plain values from a snapshot ([ADR-0022](docs/ADR-0022-session-snapshot.md)).
The engine protocol now has an explicit contract: version handshake plus frame
validation ([ADR-0051](docs/ADR-0051-engine-protocol-contract.md)).

**Ctrl-C interrupts evaluation (0.85).** The engine is killed and restarted, then the
snapshot is replayed — attribution is explicit (`op=interrupted`, code `130`) so an
interrupt is never confused with an engine crash.

**Display protocol (0.124).** `display($v)` may emit multiple rich outputs in one cell
without touching `Out[n]` or `_`; `HTML` / `Markdown` / `JSON` wrappers are built in and
any type implementing `to-mime` can render itself ([ADR-0048](docs/ADR-0048-display-protocol.md)).

**Session commands that do not allocate `Out[n]`.**
`who` / `whos` (variables, types, sizes, declarations), `cells` (cell log, exportable
as a replayable script), `paste` (block input, 0.138), `store` (cross-session variables,
0.139), `errors short|full` (error classes: compile / runtime / denied, with a
cell-relative location, 0.140), `recall [n]` (history into the prefill buffer, 0.140).

**Structured pipelines.** `stream(...)` turns text, `!` output, a `Table` or a `Cursor`
into a lazy record stream; `zip` / `join` / `tee` / `interleave` / `append` cover the
two-stream cases; a `Cursor` streams batches from the driver instead of materialising
the table ([ADR-0026](docs/ADR-0026-structured-pipe.md), [ADR-0029](docs/ADR-0029-zip-join-tee.md), [ADR-0004](docs/ADR-0004-cursor-worker.md)).

**Windows specifics.** cmd built-ins (`echo`, `dir`, `type`, `set`, …) are routed
through `cmd.exe /d /c` with a fixed whitelist and per-argument `^` escaping, so `&`,
`|`, `>` stay literal arguments and `%VAR%` is not expanded
([ADR-0049](docs/ADR-0049-windows-cmd-builtins.md)). Environment lookups are
case-insensitive on Windows (`Path` vs `PATH`) and `HOME` falls back to `$*HOME`.

## Core API

### `Rakuish::Sys` — the single system exit

```raku
use Rakuish::Sys;

my $sys = Rakuish::Sys.new(:root('/work'), :cwd('/work'));

my $text = $sys.read('README.md');
$sys.write('README.md', $text.subst(/TODO/, 'DONE'), :atomic);

my @md = $sys.ls('docs', :recursive).grep(*.extension eq 'md').sort(*.modified);
my $r  = $sys.exec('git', 'status', '--short');   # argv-only
say $r.out if $r.ok;
```

| Method | Notes |
|---|---|
| `read` / `write` / `append` | text (`utf-8`) or `:bin`; `write` is atomic by default |
| `ls` / `glob` / `stat` | always `IO::Path`; `glob` supports `*` `?` `**` `foo/**/bar` `[a-z]` `{a,b}` |
| `rm` / `cp` / `mv` / `mkdir` | return `Result`; `rm` has `:recursive` / `:dry-run`, never follows symlinks; `cp -r` has an entry cap |
| `exec` / `spawn` / `wait` / `cancel` | argv arrays only; `Handle.stdout` / `.stderr` are real streaming `Channel.Supply` |
| `cd` / `get-env` / `set-env` / `env` | **session-level**: no `chdir`, no `%*ENV` mutation |
| `resolve` | lexical normalisation + canonical symlink check; out-of-root throws `X::Rakuish::Bound` |
| `try-op` | turns exceptions into `Result` (used by the DSL / command layer) |

`Result` renders itself: `$r.render('text' | 'json' | 'markdown')` and `$r.to-json`.
Unknown formats throw `X::Rakuish::Render` instead of silently degrading.

### `Rakuish::Data` — structured data layer

```raku
use Rakuish::Data;
use Rakuish::Data::Table;

my $t = ls-table('.');                       # name/type/size/modified/path
$t.where({ .<type> eq 'file' }).select('name', 'size').sort-by('size').to-text;

my $json = open-data('data.json');           # .json  → Record/Table
my $csv  = open-data('data.csv');            # .csv   → Table
my $arr  = open-data('events.arrow');        # .arrow → Table
save-data('out.arrow', $arr, :batch-size(50_000));

$arr.sql('select kind, count(*) c from t group by 1 order by c desc');
sql({ a => $arr, b => $csv }, 'select * from a join b using (id)');
```

`Table` is real `Hash` rows, not a text table: `where` / `select` / `sort-by` /
`first` / `last` / `limit` / `offset` / `each` / `count` / `sum` / `mean` / `min` / `max` /
`distinct` / `join` / `sql` / `schema` / `column-type` / `to-text` / `to-json` /
`to-markdown` / `to-html`. Types are inferred per column (`int` / `num` / `str` /
`bool` / `datetime` / `list` / `map` / `any`) and preserved across operations;
`to-text(:index, :dtype, :shape)` adds optional row numbers, a dtype line and a shape
line (0.137).

`.parquet` / `.pq` require explicit `:allow-external` (outer paths still pass
`Sys.resolve`); `:max-rows` is pushed down as `LIMIT` before materialisation.

### `Rakuish::Data::Engine` — DuckDB / SQLite

`DB::DuckDB` is optional: without it the core is unaffected and `open-db` prints an
install hint.

```raku
my $db = open-db(':memory:', :!read-only);   # read-only is the default
$db.execute('create table sales (region varchar, amount double)');
$db.execute('insert into sales values (?, ?)', 'east', 42.5);
my $t = $db.query('select region, sum(amount) s from sales group by region');
$t.sort-by('s', :reverse).to-text;

my $c = $db.cursor('select * from big_table', :batch-size(500), :max-rows(5000));
for $c.batches -> $batch { ... }             # lazy Seq of Table
```

CSV external read/write goes through DuckDB `read_csv_auto` / `COPY ... FORMAT CSV`
with a whitelisted 7-option dialect; SQL completion is lexical (no AST parsing);
transactions (`begin` / `commit` / `rollback`) share one API across engines.

### `Rakuish::DSL` and `Rakuish::Command`

```raku
use Rakuish::DSL;
say read('a.txt');
write('b.txt', 'hi', :atomic);
my @sizes = peach(ls('docs'), { .s });      # order-preserving parallel map

# new commands are just subs returning composable values
sub todo-files { ls('.', :recursive).grep({ read($_) ~~ /'TODO'/ }) }
```

The DSL exports `ls / read / cat / write / append / stat / rm / cp / mv / mkdir /
glob / exec / tty-exec / pty-exec / cmd / cmd-result / cd / pwd / cwd / resolve / env /
get-env / set-env / unset-env / echo / try-op / timed / peach / help / recent`.
`Rakuish::Command` holds the command registry: registering a `BuiltinCommand` gives both
the completer and `help` a parameter schema (`CommandSpec.to-json-schema`).

## Documentation index (English table of contents)

The manual is written in Chinese; headings map to these topics (line numbers point into
[`docs/MANUAL.md`](docs/MANUAL.md)):

| § | Topic |
|---|---|
| 1 (L35) | Install and dependencies |
| 2 (L62) | Entry modes (REPL / `-e` / scripts / notebook / [Jupyter kernel L103](docs/MANUAL.md)) |
| 3 (L168) | REPL model: process architecture, input classification, `_` / `In[n]` / `Out[n]`, `display()`, multi-line + declaration persistence, line editing, interaction feel, engine crash & snapshot, startup file / prompt / `set -o`, edit modes and hints, UI and timing, colours, `strict`, history substitution |
| 4 (L666) | Shell thin layer: files & directories, everyday commands, path expansion, Windows CJK input, `cells`, introspection / directory stack / log, `source`, **[`paste` L837](docs/MANUAL.md)**, **[`store` L866](docs/MANUAL.md)**, **[`errors` L896](docs/MANUAL.md)**, **[`recall` L922](docs/MANUAL.md)** |
| 5 (L1018) | Raku expressions and external commands: streaming and timeouts, interactive subprocesses, Windows Job Objects, PTY capture, method chaining, `cmd` bridge, `==>` boundaries |
| 6 (L1210) | Scripts and the DSL |
| 7 (L1241) | Structured data: `Table`, `stream`, background jobs, JSON / CSV, `explore`, Parquet, Arrow IPC, SQL on tables |
| 8 (L1599) | Data engines: DuckDB, SQLite, streaming `Cursor`, CSV external I/O, dialect options, `describe`, SQL completion, read-only rules, transactions, query timeouts |
| 9 (L1751) | File and process API: `Sys`, counter-intuitive file semantics, file locks, error model, `Result` rendering |
| 10 (L1836) | Configuration, aliases, hooks |
| 11 (L1866) | Audit, display bundle, runtime limits |
| 12 (L1956) | Errors, limits and security boundaries |
| 13 (L2024) | Troubleshooting |
| 14 (L2116) | API quick reference |

Design decisions live in [`docs/ADR-INDEX.md`](docs/ADR-INDEX.md) (59 ADRs, Chinese).

## Project layout (condensed)

```text
bin/rakuish                 single entry: REPL / -e / scripts
lib/Rakuish/
  Sys.rakumod               session object: cwd / env / root / resolve / try-op
  Sys/FS.rakumod            file API (read/write/ls/stat/rm/cp/mv/mkdir/glob)
  Sys/Proc.rakumod          process API (exec/spawn/wait/cancel/tty-exec/pty-exec)
  Result.rakumod            Result / Stat / exception families
  Data.rakumod              open/save + JSON/CSV/Parquet
  Data/Table.rakumod        Table (value methods / schema / types / rendering)
  Data/Stream.rakumod       structured pipelines
  Data/Engine/*.rakumod     DuckDB / SQLite engines
  DSL.rakumod               short subs + session binding + cmd bridge
  Command.rakumod           command protocol / registry
  REPL/Session.rakumod      the session: evaluation, continuation, rendering, history
REPL/Session/Commands.rakumod  session commands, extracted as a role (0.146 / ADR-0060)
REPL/Session/Config.rakumod    config / aliases / set -o / hooks / plugins (role; 0.146)
  REPL/Shell.rakumod        daily-command thin layer (single command-name source)
  Eval.rakumod              engine client: protocol / crash detection / restart
  Eval/Server.rakumod       engine process entry (Session lives here)
  Eval/Protocol.rakumod     protocol contract: version, frames, validation (0.133)
  Snapshot.rakumod          session snapshots: serialisability, capture, atomic write
  Store.rakumod             cross-session variable library (0.139)
  Kernel/Notebook.rakumod   notebook protocol front end
t/01…t/82                   one file per contract area (see README.md for the map)
```

## Tests

```bash
raku -Ilib t/01-sys-fs.t          # one file
bash tools/run-all.sh             # preferred full entry (exit code = any problem)
python3 tools/tty-check.py        # real-TTY interaction self-check (Linux/WSL + python3)
```

Windows and Linux run the same assertions; the Windows differences that remain are
reported honestly rather than papered over (symlink creation needs a privilege → the
case is skipped; `IO::Path.modified` may return a 1969 placeholder → `DSL.recent`
degrades to a full scan instead of inventing timestamps).

## Explicitly not supported

bash / POSIX syntax itself: pipes, redirection, variable expansion, globs, here-docs,
`&&` short-circuit semantics, `$?`. Reach for Raku instead (method chains, `Supply`,
`.subst`, regexes). The full list is SPEC §7.

Three more things are deliberately out of scope for the engine process
([ADR-0021](docs/ADR-0021-eval-worker.md) §9): hard interruption without killing, silent
session-state recovery, and passing Raku value objects across the process boundary.
"Looks like nothing was lost" is worse than an honest loss.

## Platform

**Linux is the primary target; Windows 11 works.** File API and argv-based external
commands are verified on both platforms; no POSIX shell semantics are promised.
On Windows the REPL and scripts may access all drives by default; pass
`Sys.new(:root(...))` for a directory boundary (accident prevention, not isolation).

## License

MIT — see [`LICENSE`](LICENSE).
