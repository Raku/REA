#!/usr/bin/env python3
"""End-to-end smoke test for the Rakuish Jupyter kernel.

Starts a real kernel via jupyter_client (no browser needed), runs a handful of
cells and checks the messages.  Requires the kernelspec installed by
``install_kernel.py`` and ``rakuish-notebook`` on PATH (or RAKUISH_NOTEBOOK set).

    python tools/jupyter/smoke.py
"""

from __future__ import annotations

import sys
import time
from queue import Empty

from jupyter_client.manager import KernelManager


def collect_iopub(kc, parent: str, timeout: float = 90) -> list[dict]:
    messages: list[dict] = []
    deadline = time.monotonic() + timeout
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            msg = kc.get_iopub_msg(timeout=remaining)
        except Empty:
            break
        if msg["parent_header"].get("msg_id") != parent:
            continue
        messages.append(msg)
        if (
            msg["msg_type"] == "status"
            and msg["content"]["execution_state"] == "idle"
        ):
            break
    return messages


def shell_reply(kc, msg_id: str) -> dict:
    # wait_for_ready leaves its kernel_info_reply in the shell queue; skip any
    # reply that does not belong to our request.
    while True:
        reply = kc.get_shell_msg(timeout=90)
        if reply["parent_header"].get("msg_id") == msg_id:
            return reply


def run_cell(kc, code: str) -> tuple[list[dict], dict]:
    msg_id = kc.execute(code)
    iopub = collect_iopub(kc, msg_id)
    return iopub, shell_reply(kc, msg_id)


def result_data(iopub: list[dict]) -> dict:
    for msg in iopub:
        if msg["msg_type"] == "execute_result":
            return msg["content"]["data"]
    return {}


def streams(iopub: list[dict], name: str) -> str:
    return "".join(
        msg["content"]["text"]
        for msg in iopub
        if msg["msg_type"] == "stream" and msg["content"]["name"] == name
    )


def main() -> int:
    km = KernelManager(kernel_name="rakuish")
    km.start_kernel()
    kc = km.client()
    kc.start_channels()
    try:
        kc.wait_for_ready(timeout=90)
        print("ready")

        # 1. expression: MIME bundle carried over from display.mime
        iopub, shell = run_cell(kc, "1+1")
        assert shell["content"]["status"] == "ok", shell
        assert shell["content"]["execution_count"] == 1, shell
        data = result_data(iopub)
        assert data["text/plain"] == "2", data
        assert "<pre" in data["text/html"], data
        assert data["application/json"] == [2], data
        print("execute 1+1: ok, mime keys =", sorted(data))

        # 2. stdout goes to a stream event, not into the value
        iopub, shell = run_cell(kc, "say 7")
        assert streams(iopub, "stdout") == "7\n", iopub
        print("say 7: stdout stream ok")

        # 3. session state survives cells
        run_cell(kc, "my $x = 42")
        iopub, shell = run_cell(kc, "$x * 2")
        assert result_data(iopub)["text/plain"] == "84", iopub
        assert shell["content"]["execution_count"] == 4, shell
        print("cross-cell state: ok (execution_count = 4)")

        # 4. failure produces an iopub error event, not a kernel crash
        iopub, shell = run_cell(kc, 'die "boom"')
        assert shell["content"]["status"] == "error", shell
        assert any(m["msg_type"] == "error" for m in iopub), iopub
        print("error cell: ok (failed cell did not take a number)")

        # 5. completion: whole-line candidates, cursor_start = 0
        run_cell(kc, "my $obj = 42")
        msg_id = kc.complete("$obj.ab", 7)
        content = shell_reply(kc, msg_id)["content"]
        assert content["status"] == "ok", content
        assert content["cursor_start"] == 0, content
        assert any(m.endswith(".abs") for m in content["matches"]), content
        print("complete: ok (%d matches)" % len(content["matches"]))

        # 6. inspect reuses the `名字?` implementation
        msg_id = kc.inspect("$obj", 4)
        reply = shell_reply(kc, msg_id)
        assert reply["content"]["found"], reply
        assert "42" in reply["content"]["data"]["text/plain"], reply
        print("inspect: ok")

        # 7. continuation check is local to the Raku side
        msg_id = kc.is_complete("for 1..3 {")
        reply = shell_reply(kc, msg_id)
        assert reply["content"]["status"] == "incomplete", reply
        msg_id = kc.is_complete("1+1")
        reply = shell_reply(kc, msg_id)
        assert reply["content"]["status"] == "complete", reply
        print("is_complete: ok")

        # 8. shutdown through the protocol, not by killing the process
        # shutdown_request/reply travel on the control channel, not shell.
        msg_id = kc.shutdown()
        reply = kc.get_control_msg(timeout=90)
        assert reply["parent_header"].get("msg_id") == msg_id, reply
        assert reply["content"]["status"] == "ok", reply
        print("shutdown: ok")
        return 0
    finally:
        kc.stop_channels()
        km.shutdown_kernel(now=True)


if __name__ == "__main__":
    sys.exit(main())
