"""ipykernel wrapper that bridges Jupyter messages to ``rakuish-notebook``.

Design notes
------------
* We do NOT re-implement MIME negotiation.  ``rakuish-notebook`` already returns
  a complete ``display.mime`` bundle (text/plain, text/markdown, text/html,
  application/json).  The wrapper just forwards it; the only conversion is
  ``application/json``, whose wire value is a JSON *string* while Jupyter wants
  the decoded object.
* ``execution_count`` comes from the Raku session, never from the base class:
  Rakuish does not number failed cells, so letting ipykernel increment its own
  counter would desynchronise ``In[n]`` / ``Out[n]``.
* The bridge is a long-lived process, so variables, ``use`` imports and ``Out``
  persist across cells.  A single lock serialises stdio access.
* Since 0.113.0 the bridge also *pushes* frames (``busy`` / ``idle`` /
  ``engine``).  Frames are told apart by field: a **reply** carries ``op``, a
  **push** carries ``event``.  ``_ask`` therefore loops until it sees a reply
  and hands every push to ``_on_event`` first.
"""

from __future__ import annotations

import json
import os
import shlex
import subprocess
import threading
from typing import Any

from ipykernel.kernelbase import Kernel

DEFAULT_BRIDGE = "rakuish-notebook"


class RakuishKernel(Kernel):
    implementation = "rakuish"
    language = "raku"
    language_info = {
        "name": "raku",
        "mimetype": "text/x-raku",
        "file_extension": ".raku",
        "codemirror_mode": "raku",
        "pygments_lexer": "raku",
    }
    banner = "Rakuish — Raku 交互式内核"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)

        # RAKUISH_NOTEBOOK may be a command line, e.g.
        #   "raku -Ilib bin/rakuish-notebook"
        # for running straight from a source tree.  shlex.split handles quotes.
        command = shlex.split(os.environ.get("RAKUISH_NOTEBOOK", DEFAULT_BRIDGE))
        if not command:
            raise RuntimeError("RAKUISH_NOTEBOOK 是空命令")

        try:
            self.bridge = subprocess.Popen(
                command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                bufsize=1,
            )
        except OSError as exc:
            raise RuntimeError(f"无法启动 rakuish 桥 {command!r}: {exc}") from exc

        self._lock = threading.RLock()
        self._stderr_tail: list[str] = []
        # Push frames seen so far.  Only deaths discovered *while idle* are
        # republished (see _on_event); the rest are kept for diagnostics.
        self._engine_events: list[dict] = []
        self._bridge_state = "idle"
        self._closing = False
        threading.Thread(target=self._pump_stderr, name="rakuish-stderr", daemon=True).start()

        # The Raku side emits one `ready` frame before any request.
        ready = self._read_frame()
        if ready.get("event") != "ready":
            raise RuntimeError(f"桥接器首帧不是 ready: {ready!r}")
        self.implementation_version = str(ready.get("version", "0.0.0"))
        self.engine_pid = int(ready.get("engine_pid") or 0)
        self.banner = (
            f"Rakuish {self.implementation_version} — Raku 交互式内核\n"
            f"  {ready.get('banner') or ''}"
        ).rstrip()

    @property
    def kernel_info(self) -> dict:
        # ipykernel 7 advertises "debugger" whenever debugpy happens to be
        # installed, and "kernel subshells" by default.  Neither works here:
        # don't claim a capability the Raku side does not implement.
        info = super().kernel_info
        info["supported_features"] = []
        return info

    # ── stdio plumbing ─────────────────────────────────────────────────
    def _pump_stderr(self) -> None:
        assert self.bridge.stderr is not None
        for raw in self.bridge.stderr:
            line = raw.rstrip()
            self._stderr_tail.append(line)
            del self._stderr_tail[:-20]
            try:
                self.log.warning("[rakuish-notebook] %s", line)
            except Exception:
                pass

    def _read_frame(self) -> dict:
        assert self.bridge.stdout is not None
        line = self.bridge.stdout.readline()
        if not line:
            tail = " | ".join(self._stderr_tail[-5:])
            raise RuntimeError(f"rakuish-notebook 已退出（stderr: {tail}）")
        try:
            frame = json.loads(line)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"桥接器返回了非 JSON 行: {line[:200]!r}") from exc
        if not isinstance(frame, dict):
            raise RuntimeError(f"桥接器返回的不是对象: {frame!r}")
        return frame

    def _ask(self, request: dict) -> dict:
        assert self.bridge.stdin is not None
        with self._lock:
            self.bridge.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
            self.bridge.stdin.flush()
            while True:
                frame = self._read_frame()
                # A reply always has `op`; a push always has `event`.
                if frame.get("event"):
                    self._on_event(frame)
                    continue
                return frame

    def _on_event(self, frame: dict) -> None:
        """Handle a push frame coming from the Raku bridge (0.113.0).

        ``busy`` / ``idle`` deliberately are **not** forwarded: ipykernel
        already publishes its own status messages around ``do_execute``, so
        republishing would double every transition on iopub.  They are only
        recorded, which is enough to explain a hang in the logs.

        ``engine`` frames are only republished when they report a death
        discovered while the kernel was idle — an engine that dies mid-cell is
        already described by the execute reply's traceback, and saying it twice
        in two different ways is worse than saying it once.
        """
        kind = frame.get("event")
        if kind in ("busy", "idle"):
            self._bridge_state = kind
            return
        if kind != "engine":
            return

        self._engine_events.append(frame)
        del self._engine_events[:-20]
        if self._closing or frame.get("kind") != "dead":
            return
        text = "[rakuish] " + str(frame.get("reason") or "引擎进程已退出") + "\n"
        try:
            self.send_response(
                self.iopub_socket, "stream", {"name": "stderr", "text": text}
            )
        except Exception:  # noqa: BLE001 - iopub may already be gone
            pass

    def _mime_payload(self, display: dict) -> dict:
        """Wire 的 bundle → Jupyter 的 data 字典。

        ``application/json`` 在线上是 JSON *字符串*，Jupyter 要解码后的对象；
        解不开就保留字符串（丢一档比整条消息坏掉好）。
        """
        data = dict(display.get("mime") or {})
        raw_json = data.get("application/json")
        if isinstance(raw_json, str):
            try:
                data["application/json"] = json.loads(raw_json)
            except (ValueError, TypeError):
                pass
        data.setdefault("text/plain", display.get("content") or "")
        return data

    # ── ipykernel hooks ────────────────────────────────────────────────
    def do_execute(
        self,
        code: str,
        silent: bool,
        store_history: bool = True,
        user_expressions: dict | None = None,
        allow_stdin: bool = False,
    ) -> dict:
        reply = self._ask({"op": "execute", "code": code, "silent": bool(silent)})
        count = int(reply.get("execution_count") or self.execution_count)
        ok = bool(reply.get("ok"))
        out = reply.get("out") or ""
        err = reply.get("err") or ""

        if silent:
            return {
                "status": "ok" if ok else "error",
                "execution_count": count,
                "payload": [],
                "user_expressions": {},
            }

        # stdout/stderr are stream events; display is a separate execute_result.
        if out:
            self.send_response(
                self.iopub_socket, "stream", {"name": "stdout", "text": out}
            )
        if err:
            self.send_response(
                self.iopub_socket, "stream", {"name": "stderr", "text": err}
            )

        display = reply.get("display") or {}
        meta = display.get("meta") or {}
        # 0.123.0 / V-323：引擎用 meta.source 说明这份 display 的来源。
        #   value —— 这一格的值（execute_result）
        #   out   —— 命令的 stdout；它已经作为 stream 发过，别再发一次
        #   error —— 走下面的 error 消息，不发 execute_result
        # 老引擎没有这个键，按旧行为处理。
        source = str(meta.get("source") or "")
        data = self._mime_payload(display)

        # 0.124.0 / ADR-0048 P1：一格里的 `display()`。引擎按调用顺序收集，
        # 这里按序发 display_data；cell 末尾的值仍是下面的 execute_result。
        for item in display.get("displays") or []:
            if not isinstance(item, dict):
                continue
            payload = self._mime_payload(item)
            if any(str(value).strip() for value in payload.values()):
                self.send_response(
                    self.iopub_socket,
                    "display_data",
                    {"data": payload, "metadata": {}},
                )

        # An empty cell (e.g. `cd`) has no display payload — don't draw a blank box.
        if source not in ("out", "error") and any(
            str(value).strip() for value in data.values()
        ):
            self.send_response(
                self.iopub_socket,
                "execute_result",
                {"data": data, "metadata": {}, "execution_count": count},
            )

        if not ok:
            message = err or display.get("content") or "执行失败"
            self.send_response(
                self.iopub_socket,
                "error",
                {
                    "ename": "RakuishError",
                    "evalue": message,
                    "traceback": [message],
                },
            )
            return {
                "status": "error",
                "ename": "RakuishError",
                "evalue": message,
                "traceback": [message],
                "execution_count": count,
                "payload": [],
                "user_expressions": {},
            }

        return {
            "status": "ok",
            "execution_count": count,
            "payload": [],
            "user_expressions": {},
        }

    def do_complete(self, code: str, cursor_pos: int) -> dict:
        reply = self._ask({"op": "complete", "code": code, "cursor_pos": cursor_pos})
        return {
            "status": "ok",
            "matches": list(reply.get("matches") or []),
            # Rakuish candidates replace the whole line, so start is always 0.
            "cursor_start": int(reply.get("cursor_start", 0)),
            "cursor_end": int(reply.get("cursor_end", cursor_pos)),
            "metadata": {},
        }

    def do_inspect(
        self,
        code: str,
        cursor_pos: int,
        detail_level: int = 0,
        omit_sections: tuple[str, ...] = (),
    ) -> dict:
        reply = self._ask(
            {"op": "inspect", "code": code, "cursor_pos": cursor_pos}
        )
        return {
            "status": "ok",
            "found": bool(reply.get("found")),
            "data": {"text/plain": reply.get("text") or ""},
            "metadata": {},
        }

    def do_is_complete(self, code: str) -> dict:
        reply = self._ask({"op": "is_complete", "code": code})
        return {
            "status": reply.get("status", "complete"),
            "indent": reply.get("indent", ""),
        }

    def do_shutdown(self, restart: bool) -> dict:
        self._closing = True
        try:
            self._ask({"op": "shutdown"})
        except Exception:
            pass
        try:
            assert self.bridge.stdin is not None
            self.bridge.stdin.close()
            self.bridge.wait(timeout=5)
        except Exception:
            pass
        return {"status": "ok", "restart": restart}
