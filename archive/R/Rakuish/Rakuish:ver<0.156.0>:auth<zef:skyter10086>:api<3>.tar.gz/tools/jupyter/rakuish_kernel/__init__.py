"""Jupyter wrapper kernel for Rakuish.

The only Python-side dependency is ipykernel (ZMQ/HMAC/heartbeat are handled by
its base class).  This package talks to ``rakuish-notebook`` over one-JSON-line
stdio; all evaluation state stays in the Raku session.
"""

from .kernel import RakuishKernel

__all__ = ["RakuishKernel"]
