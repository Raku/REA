"""Entry point: ``python -m rakuish_kernel -f {connection_file}``."""

from ipykernel.kernelapp import IPKernelApp

from .kernel import RakuishKernel

if __name__ == "__main__":
    IPKernelApp.launch_instance(kernel_class=RakuishKernel)
