#!/usr/bin/env python3
"""Install the Rakuish Jupyter kernelspec into the current user's Jupyter data dir.

    python tools/jupyter/install_kernel.py
    python tools/jupyter/install_kernel.py --bridge "raku -Ilib bin/rakuish-notebook"

The Python wrapper package is copied next to kernel.json, so Jupyter can start
it with ``python -m rakuish_kernel`` without touching PYTHONPATH globally.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

from jupyter_core.paths import jupyter_data_dir

HERE = Path(__file__).resolve().parent
PACKAGE = HERE / "rakuish_kernel"
DEFAULT_BRIDGE = "rakuish-notebook"
KERNEL_NAME = "rakuish"


def make_spec(kernel_dir: Path, bridge: str) -> dict:
    return {
        "argv": [
            sys.executable,
            "-m",
            "rakuish_kernel",
            "-f",
            "{connection_file}",
        ],
        "display_name": "Raku (rakuish)",
        "language": "raku",
        # We do not implement a lossless interrupt: killing the engine loses
        # session state.  "message" keeps ipykernel from sending SIGINT to the
        # bridge process and pretending the session survived.
        "interrupt_mode": "message",
        "env": {
            "PYTHONPATH": str(kernel_dir),
            "RAKUISH_NOTEBOOK": bridge,
        },
    }


def install(bridge: str, name: str = KERNEL_NAME) -> Path:
    if not PACKAGE.is_dir():
        raise SystemExit(f"找不到 wrapper 包: {PACKAGE}")
    kernel_dir = Path(jupyter_data_dir()) / "kernels" / name
    kernel_dir.mkdir(parents=True, exist_ok=True)

    target = kernel_dir / "rakuish_kernel"
    shutil.copytree(PACKAGE, target, dirs_exist_ok=True)
    # Keep installed copies clean between runs.
    for stale in target.rglob("__pycache__"):
        shutil.rmtree(stale, ignore_errors=True)

    (kernel_dir / "kernel.json").write_text(
        json.dumps(make_spec(kernel_dir, bridge), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return kernel_dir


def uninstall(name: str = KERNEL_NAME) -> Path:
    kernel_dir = Path(jupyter_data_dir()) / "kernels" / name
    if kernel_dir.is_dir():
        shutil.rmtree(kernel_dir)
    return kernel_dir


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--bridge",
        default=os.environ.get("RAKUISH_NOTEBOOK", DEFAULT_BRIDGE),
        help="启动 rakuish-notebook 的命令（默认 rakuish-notebook）",
    )
    parser.add_argument("--name", default=KERNEL_NAME, help="kernelspec 目录名")
    parser.add_argument("--uninstall", action="store_true", help="删除已安装的 kernelspec")
    args = parser.parse_args()

    if args.uninstall:
        print(f"removed {uninstall(args.name)}")
        return
    print(f"installed {install(args.bridge, args.name)}")


if __name__ == "__main__":
    main()
