# Rakuish 规格（Raku 原生命令与脚本环境，API v3）

> **本文件是唯一真值**（0.34.0 / Phase 5b 起，当前 0.156.0）。
> v2 的双语言 REPL（`!` bash 子集 + `%magic` + 独立 shell 引擎）已于 0.34.0 整体删除，
> 仓库里**只有这一套语义**：没有兼容入口、没有 `--v2` 开关、没有 daemon。
> 测试用例的标注必须能在这里找到对应条款（编号 `V-xxx`）。
> 使用说明见 [`docs/MANUAL.md`](docs/MANUAL.md)。
>
> 正文含 0.81 之前 Agent / Sandbox 时代的条款：Agent 线已随 0.81.0 整体删除
> （ADR-0019），那些条款标了历史语境，**不作为现行契约**；现行契约看
> 各节里带「当前」标注的条目与 `docs/ADR-INDEX.md` 的状态列。
>
> 方向依据：[ADR-0001](docs/ADR-0001-raku-native.md) · 原始设计：[DESIGN-RAKU-NATIVE.md](docs/DESIGN-RAKU-NATIVE.md)。
> `META6.api` 为 `3`，与实际宣称一致。

---

## 1. 适用范围与术语

> **读法（0.81.0 起）**：本文正文里凡提到「Agent 的 X」「Agent op 白名单」
> 「Sandbox」的地方，除 §3.12 与 §6 以外，都是**历史记录**（描述 0.80.x 及更早）。
> Agent 线已于 0.81.0 整体撤销，见 §6.1 与
> [ADR-0019](docs/ADR-0019-local-full-privilege-shell.md)。
> 当前实现只有一个入口、没有协议、没有沙箱、没有权限闸门（V-197…V-199）。

| 术语 | 含义 |
|---|---|
| **会话（Session）** | 一个 `Rakuish::REPL::Session` 或 `Rakuish::Sys` 实例；`cwd` / `env` / `root` 是它的对象属性，**不是进程全局** |
| **Sys** | 唯一系统出口：文件、进程、路径解析、环境 |
| **Result** | `ok / code / value / out / err / elapsed / op`，`.Bool` 供 `&&` 短路 |
| **argv** | 外部命令的参数数组；**永不经过 shell** |
| **op** | 结构化操作名（`Kernel` 的 `kind=op` 请求）。0.81.0 起只剩 `capabilities`，其余 501 |

**V-101**：V3 不实现、不扩展 bash / POSIX 语法。`$VAR` / `|` / `>` / `2>` /
`&&` / `||` / glob / heredoc / 命令替换 / `$?` / `$$` 都不是 V3 语法。
需要这些能力时用 Raku 本身（方法链、`Supply`、`&&`、`.subst`、正则）。

**V-102**：脚本就是 Raku 脚本。`.raku` / `.rakuish` 交给默认入口时，
整份源码作为**一个 cell** 求值，预加载 DSL 与 `sys` / `repl` / `registry` 词法绑定；
不解析 shebang、不模拟 `%magic`、不打印 `Out[n]`。
相对路径跟随**调用者 cwd**（与 shell 惯例一致），不是脚本所在目录。

---

## 2. 入口契约（V-11x）

| 条款 | 规则 |
|---|---|
| V-111 | `bin/rakuish`（唯一入口）：无参数 → REPL；`-e <code>` → 求值后退出；`<file> [args...]` → 跑 Raku 脚本；`--help` / `--version` |
| V-112 | ~~`bin/rakuish --agent [args...]` 转发到 Agent 入口~~ —— **0.81.0 撤销**（ADR-0019）：`--agent` 不再是启动参数，输入里写它会被当成 Raku 运算符 |
| V-113 | ~~`bin/rakuish-agent`：Agent 入口（JSONL / TCP）~~ —— **0.81.0 撤销**，入口文件已删除（`t/07` 断言其不存在） |
| V-114 | 入口**只有一个**（`bin/rakuish`）；v2 的 `rakuish-v2` / `rakuish-v3` / `rakuish-sh` 随 0.34.0 删除、Agent 入口随 0.81.0 删除（`t/07` 断言都不存在） |
| V-115 | 入口**不猜参数形态**：参数该落在哪一层由用户显式写出；猜测等于把 `auto-shell` 换成「猜入口」 |
| V-116 | 管道（非 TTY）下不打印提示符，stdout 只有求值结果；TTY 下才显示 banner 与 `rakuish> ` |
| V-117 | 入口的版本常量必须与 `META6.version` 一致（`t/51` 与 `t/07` 守护） |
| V-118 | ~~转发用 argv 数组调用~~ —— 0.81.0 起没有转发（唯一入口）；`!` 的 argv 分词仍不解释空格 / 引号 / `$` / `&&`；`|` 是唯一例外：0.143.0 起顶层、引号外才切管道（V-347）；`--tty` + 管道由父进程执行（0.144.0，V-348）；`--pipe` 透传末段输出（0.145.0，V-349） |

---

## 3. 输入分类（V-12x）

**V-121**：REPL 每行只有两类输入，没有第三套语言：

| 首字符 | 处理 |
|---|---|
| `!` | argv 分词（空格 + 引号），交给 `sys.exec`；`!=` / `!~~` 仍按 Raku 运算符求值 |
| 其它（**含 `%`**） | Raku 表达式，直接 EVAL；编译 / 运行失败就是失败，**不回退 shell** |

日常命令 `cd` / `ls` / `cat` / `read` / `rm` 等由 Shell 薄层翻译成 `Sys`
调用（V-127），这是**命令别名层**，不是第三套语法；带 Raku 表达式或复杂引号的
输入仍交回 Raku。

**V-122**：`%foo<a>` / `%STATE{...}` 是 Raku 哈希访问，不是魔法命令。
（`%STATE` 是跨格变量的底层哈希，可直接读写；v2 时代的 `%STORE` / `%RC`
已随 0.34.0 删除，`%STORE` 现在会报「未声明变量」。）
V3 没有 `kind-of` 的 `%` 分支、没有 magic handler、没有 magic help 表。

**V-123**：`!` 的分词只处理空格与引号；`$()`、反引号、`;`、`|`、`>`、`*`、`&&`、
heredoc 全部原样作为 argv 元素传入。要管道 / 过滤 / 重定向就写 Raku：

```raku
my $r = sys.exec('git', 'status', '--short');
say $r.out.lines.grep(*.contains('.md'));
```

**V-124**：多行续行用纯 Raku 的括号平衡判定；跨格顶层 `my` / `our` / `state`
由只读扫描器转成 `%STATE` 别名，**每格只 EVAL 当前源码，不重放历史副作用**。
嵌套块里的 `my` 仍是块内局部；纯 `sub` / `use` / `class` / `role` / `grammar`
声明格会缓存并在后续格前置（机制与边界见 V-153）。stdout 直接回显当前格输出，
不打印历史重复内容。

> 历史实现（0.35.2 及以前）靠累积整份源码重 EVAL 保留 `my`，会把上一格的
> `append` / `write` / `exec` 重跑一遍；V-124 已禁止这种做法。

**V-125**：REPL 元能力不是文本命令：`repl.history` / `repl.config<k>` / `repl.trace`
是对象 API，纯交互动作走快捷键（Up / Down / Ctrl-R / Ctrl-C / Ctrl-D / Tab）。
**repl 对象与快捷键禁止直接读写文件、启动进程**——所有系统操作必须过 `Sys`，
否则 Agent 的 Sandbox 会被绕过。**0.75.0 订正**：`Ctrl-X Ctrl-E / edit-request`
曾只在 `handle-key` 返回值、`Keymap` 从未绑定、入口也不消费；补实现又会撞上
本条硬边界（外部编辑器要起进程 + 读写临时文件），故从快捷键表、入口 help 与
ADR-0001 设计表中一并删除（ADR-0012 §1）。

**V-128**：TTY 交互入口使用 `Terminal::LineEditor` 提供行编辑与历史：
Up/Down 翻历史、Ctrl-R 搜索、Ctrl-D 退出；历史默认保存在
`~/.rakuish-history`。Tab 补全命令名、路径和 `help <命令>`。
管道 / 脚本输入仍走普通逐行读取，不输出提示符或终端控制序列。

**V-129**：结构化数据层：
- `Rakuish::Data::Table`：行是 Hash，列为字符串；支持 `where/get/select/sort-by/
  first/last/limit/offset/each/count/sum/mean/min/max/distinct/join`、
  `schema/column-type`、`to-text/to-json/to-markdown`。
- `Table` 类型集合 `int / num / str / bool / datetime / list / map / any`；
  构造时推断，链式操作保留，`join` 合并右表类型。
- `Rakuish::Data`：`open-data` / `save-data` / `from-json-data` / `to-json-data` /
  `from-csv-data` / `to-csv-data`。
- `Sys.ls-table` / `DSL.ls-table` 返回 `Table`，字段至少
  `name/type/size/modified/path`。
- REPL 支持 `open [--raw] 文件`、`ls --json`、`explore [路径]`；
  `glob` 支持 `**/` 递归前缀。
- 数据层只经 `Sys` 读写文件，不绕过 Sandbox
  （Parquet 的显式授权例外见 V-152）。

**V-130**：数据引擎是可选能力：
- `Rakuish::Data::Engine` 定义 `query/execute/tables/schema/close` 契约。
- `Rakuish::Data::Engine::DuckDB` 通过**运行时 require** 使用 `DB::DuckDB`，
  不成为核心依赖；缺失时明确报安装提示。
- 默认只读；只读下 `execute` 和 DDL query 抛 `X::Rakuish::Unsupported`。
- 默认 `enable_external_access=false`；SQL 不能借 DuckDB 的文件函数绕过
  `Sys` 的 root/Sandbox。
- Agent 的 `sql_query` 默认关闭；显式 `--allow-sql --db` 后只允许参数化只读查询，
  不开放 `sql_exec` / DDL / 任意 SQL。

**V-131**：SQLite 是可选的小型事务引擎：
- `Rakuish::Data::Engine::SQLite` 运行时 require `DB::SQLite`，不成为核心依赖。
- 适配器固定一个连接（`:memory:` 不能走连接池，否则每个连接一个库）。
- 参数化 `query/execute` 使用 prepared statement。
- 默认只读；只读下拒绝 `execute` 和 DDL query。
- SQLite 用于小表/应用状态，不作为大分析引擎。

**V-132**：`Table` 值管道至少包含：
`where/get/select/sort-by/first/last/limit/offset/each/count/sum/mean/min/max/
distinct/join`。`join` 默认是左连接，列名冲突时右表列加 `_right` 后缀；
`from-rows` 必须把单行 Hash / Pair 列表归一化成一行 Hash。

**V-133**：REPL 支持 `set -e` / `set +e`：
- `set -e` 打开 strict；任一 shell、`!` 或 Raku 求值失败后设置
  `exit-requested`，退出码取该结果的 `code`（无则 1）。
- `set +e` 关闭 strict；失败只返回错误 `Result`，不退出。
- strict 是会话级状态，不改变单个 `Result` 的 `ok/code/err`。

**V-134**：Agent 可选 `sql_query`：
- 默认关闭；需 `Sandbox.allow-sql` 和已配置只读 Engine。
- `sql` 必须参数化 `params[]`；结果转 `Table`，再按 `max-rows` 截断。
- 不开放 `sql_exec` / DDL；未知 op 仍 404，策略拒绝是 403。

**V-135**：资源与递归边界：
- `ls -R` 在 TTY 下按目录流式输出，每个目录先打 `目录:` 头再输出条目；
  非 TTY 返回完整分组文本。`--json` 仍返回扁平 Table。
- 普通 `glob`（如 `*.jpg`）只扫当前目录；按模式段数限制 `max-depth`，
  只有包含 `**` 时才无界递归。
- `ls` 递归结果超过 `Sys.max-entries`（默认 100000）抛 `X::Rakuish::Limit`；
  `cp -r` 在复制前预检源树条目数，超限直接拒绝。
- `write` 的原子临时文件使用 `spurt(:exclusive)`，不再可预测地覆盖已有临时文件。
- `!` 命令的未闭合引号直接返回 127，不把残片当 argv 执行。
- `peach` 是 DSL 的并行 map，`:degree` 控制并发度，结果保序。
- `glob` 支持 `*` / `?`（不跨 `/`）、`**/`、`foo/**/bar`、`foo/**`、
  `[abc]` / `[a-z]` / `[!x]`、`{a,b}` 与嵌套 `{a,{b,c}}`；`\` + 元字符
  （`* ? [ ] { } , \`）按字面匹配，裸 `\` 归一化为 `/`（V-153）。

**V-136**：`Sys` 记录本会话 `spawn` 的后台任务：
- `jobs` 返回 `Table`（id/status/exe/argv/started），REPL 有同名 shell 命令。
- `wait` / `cancel` 成功后清理；`job(id)` 可取回 Handle。
- 任务记录不跨 `Sys` 会话，不写全局进程表。

**V-137**：Agent 审计 `sql_query` 只记录 FNV-1a SQL 指纹和参数个数，
不记录 SQL 原文、参数值或结果行内容。

**V-138**：文件替换临时名：
- `write` / `mv` 的临时名使用时间 + 随机 + PID，降低可预测性。
- 原子写仍用 `spurt(:exclusive)`；写入前拒绝覆盖 `.bak` 符号链接。
- 失败路径保持原有回滚语义，不先删除目标。

**V-139**：超时：
- `serve-once` 使用 `IO::Socket::Async`，支持 `idle-timeout-ms`；超时后关闭连接并返回
  `timed_out => True`。
- DuckDB Engine 支持 `max-execution-time-ms`，映射到 DuckDB `max_execution_time`；
  超时查询抛数据库中断错误。
- SQLite 超时见 V-147；Agent `--sql-timeout-ms` 对两种引擎一致生效。

**V-140**：REPL 值历史：
- `_` 是上一成功格的值；`Out[1]` 起是成功格结果历史（首个元素为占位）。
- `cmd('shell 文本')` 执行 shell 薄层并返回结构化值；失败抛
  `X::Rakuish::CommandFailed`，`cmd-result` 则返回完整 Result。
- `cmd` 只在 REPL/绑定 Session 的上下文可用；不把 shell 文本变成第二套 Raku 语法。

**V-141**：`read` 作为 REPL shell 命令支持 `read 文件...`，按字面路径读取
（含 `-` 的文件名不再交给 Raku 当表达式解析）；与 `cat` 同源，输出文本。

**V-142**：0.53 命令查找：
- `which 命令` 优先报告 Shell 内置，其次按会话 `PATH` 查外部可执行文件。
- `help --find 文本` 在全部 usage 中做子串搜索，返回命令名 + 用法。
- 历史替换只识别整行 `!!` / `!$` / `!n` / `!-n`；`!cmd` 仍是外部命令。
  替换后立即求值，替换结果再入历史；用 `expanding` 标志防递归。

**V-143**：会话配置与 alias：
- 配置默认 `~/.rakuish-config.json`，`RAKUISH_CONFIG` 可覆盖；启动时加载。
- `config [get KEY|set KEY VALUE|unset KEY]` 读写顶层键。
- `alias name=command` / `alias name command` 写入配置；`unalias` 删除。
- alias 只展开 Shell 命令行的首个词，最多 10 层，防循环。

**V-144**：启动 hook：
- `hook add EVENT CODE`、`hook clear EVENT`、`hook run EVENT`；
  hook 存在配置 `hooks.EVENT` 数组。
- `bin/rakuish` 在 `-e` / 脚本 / 交互模式求值前运行 `start` hook。
- hook 失败时打印错误并停止启动；hook 内容是本地可信配置。

**V-145**：`Table` schema/types：
- 类型集合：`int / num / str / bool / datetime / list / map / any`。
- 构造时推断；`select/where/limit/...` 保留，`join` 合并右表类型。
- `column-type(NAME)` 与 `schema`（name/type/nullable）是稳定 API。

**V-146**：`Data::Engine` 写事务：
- `begin` / `commit` / `rollback` 是 Engine 角色方法；DuckDB、SQLite 都实现。
- 只读引擎调用事务抛 `X::Rakuish::Unsupported`。
- 事务属于引擎连接，不跨 Session/Agent 共享。

**V-147**：SQLite 查询超时：
- Engine `max-execution-time-ms` 通过看门狗调用 `sqlite3_interrupt` 中断。
- 超时抛 `X::Rakuish::Limit`；Agent `--sql-timeout-ms` 对两种引擎一致生效。
- 中断是连接级操作，不跨连接共享。

**V-148**：Agent 请求 deadline：
- `--request-timeout-ms` 默认 30000；超时响应 504，审计 stage=timeout。
- `exec` 和 SQL 会把实际执行超时压到不超过请求 deadline。
- 0.63 起 dispatch 在独立任务中执行，deadline 到点**立即**返回 504，
  超时任务的结果丢弃，连接继续可用（ADR-0002）；不再是「等操作返回后再检查」。
- Raku 线程无法强杀：不可取消的纯文件 I/O 仍会在后台跑完；exec / SQL 因底层
  超时被压进参数会真的终止。默认模式不宣称 OS 级进程硬取消，边界见 ADR-0002 §2；
  0.67 起 `--worker` 提供可选的进程级硬取消（V-159，默认关闭）。

**V-149**：`explore` 结构化分页：
- 无参数时探索上一格 Table；带路径时加载 JSON/CSV/目录为 Table。
- TTY 下按页输出（Enter 下一页、q 退出）；非 TTY 直接返回完整文本。
- `RAKUISH_PAGER=never` 强制非交互；不引入分页器第二套数据解释。

**V-150**：REPL 展示层与计时（0.62）：

- `Rakuish::REPL::Chrome` 是**纯展示模块**：banner / prompt / 颜色能力 /
  路径缩写 / 耗时格式化 / git 分支（只读 `.git/HEAD`，经 `Sys`）。
  它不求值、不注册命令、不解析输入，可在非 TTY 下被直接断言。
- TTY 下 banner 为极简字标 + 细分割线（**禁止字符拼字**）；prompt 显示时间、
  cwd、git 分支、格号、上格状态与耗时；续行提示符为 `···`。
  非 TTY 不打印 banner / prompt 与任何 ANSI（V-116）。
- 颜色：`NO_COLOR` 强制关、`FORCE_COLOR=1` 强制开，否则按 TTY + `config color`；
  `clock` / `timing` / `git` / `prompt-style` / `banner` 每格重读，`config set` 即时生效。
- 计时数据是会话级 `repl.perf-hist`，由入口对**每一格**（shell / `!` / Raku）
  统一调用 `note-timing` 写入，不重放历史、不引入第二套计时口径。
  `perf [N]` 展示；`timed` / `bench` 是普通 Raku sub，返回 `Result`。
- **不恢复 `%magic`**：不存在 `%time` 分流，`%` 始终是 Raku 哈希（V-122）。
  计时需求由「每格自动计时 + 状态行 + 值 API」满足。
- 测试：`t/15-repl-ui.t`（颜色、banner、prompt、格式、git 分支、timed/bench/perf）。

**V-152**：Parquet / 大结果 / SQL 错误统一（0.64）：

- `open-data` / `save-data` 支持 `.parquet` / `.pq`，返回 / 接受 `Table`；
  DSL 的 `:allow-external` 与 Shell 的 `open --external` 暴露该能力。
- **外部访问是显式例外**：读写 Parquet 必须给 `:allow-external`（人类 REPL），
  路径一律先经 `Sys.resolve` 做 root 校验；DuckDB 的 `read_parquet` / `COPY`
  由受控的 `:!safe` 引擎执行。**Agent 的 op 白名单不暴露该开关**，
  引擎默认 `enable_external_access=false` 不变。这是 V-129「只经 Sys」在
  显式授权下的例外；0.68 起 CSV 纳入同一模型（V-160），Parquet / CSV 是
  **全部**例外，不扩大到 Agent、不开放任意 SQL 文件函数。0.69 的 CSV 方言
  参数（V-162）只是给这两个例外加选项，不新增第三个例外。
- `Engine.query(:$max-rows)` 把 `LIMIT` 下推进 SQL，在物化前截断；
  DuckDB / SQLite 一致。`Table.batches(:size)` 返回惰性分批 `Seq`；
  `to-text` / `to-markdown` / `to-json(:$max-rows)` 是展示上限
  （`to-json` 只截行、不加文本，保持合法 JSON）。
- **Table 本身仍是物化值**：0.67 起真正的惰性查询由 `Engine.cursor()` 提供
  （V-158）；`query()` 的物化语义不变。
- SQL 驱动异常统一包装为 `X::Rakuish::Data`；只读 / 沙箱 / 超时等
  `X::Rakuish::V3` 子类原样抛，不泄漏驱动堆栈。
- 测试：`t/17-data-parquet.t`（Parquet 往返、默认拒绝、root 校验、
  LIMIT 下推、分批、渲染上限、错误统一、Agent 白名单）。

**V-153**：类型声明跨格与 glob 完整语法（0.65）：

- 纯声明格（`sub` / `use` / `class` / `role` / `grammar`）缓存进 `@decls`，
  每格前置重放**只重放声明**，不重放任何执行语句（V-124 红线不变）。
- 顶层类型声明统一改写为 `my class` / `my role` / `my grammar`：裸声明在
  `EVAL` 里会装进 `GLOBAL`，跨格前置重放时触发 `Redeclaration of symbol`。
  代价是 `.^name` 带外层包名（`Rakuish::REPL::Session::Foo`），短名仍可解析；
  持久的是**名字可见性，不是类型对象身份**（每格重放生成新 type object）。
- 类型声明在缓存中**原位替换**（不是移除后追加），保证 `role R` →
  `class C does R` 的依赖顺序在重定义后仍成立；声明求值失败时回滚缓存。
- 含 `BEGIN` / `INIT` / `CHECK` / `END` / `START` / `FIRST` 的声明格**不缓存**，
  避免 phaser 副作用每格重放；该格仍照常求值。混有其它语句的格不缓存。
- glob：`\` + 元字符按字面匹配；嵌套 brace 按最外层逗号切分；字符集支持
  转义的 `]` / `-`；未闭合 brace 按字面处理；裸 `\` 仍归一化为 `/`。
- Shell 薄层只展开 `* ?`：含 `{ } [ ]` 的参数交回 Raku（`glob` 命令除外），
  且 `!split` 会把 `\` 当转义前缀吃掉；完整语法请用 Raku `glob('...')`。
- 测试：`t/18-repl-types-glob.t`（50 断言：三类声明、重定义顺序、副作用不
  重放、失败回滚、转义 / 嵌套 brace / 字符集 / Shell 入口）。

**V-154**：Vi/Helix 编辑模式与键位预设（0.66，ADR-0003 §3.1）：

- `config set edit-mode emacs|vi|helix`（默认 `emacs`，完全不碰原生键位）；
  `config set vi-start insert|normal` 决定每行起始模式。配置当格生效：
  重建行编辑器并迁移历史。
- `REPL::Keymap::ViState` 是纯逻辑的单行模态模型（insert / normal / select、
  缓冲 / 光标 / 撤销 / yank），`repl.vi` 可访问；单行 REPL 里 `j` / `k` 映射
  历史上下格。
- TTY 下 `ViCLIInput` 子类覆盖 `decode-keyname` / `special-actions` /
  `input-class`：normal 模式把可打印字符映射成 `vi-<char>` 键名，只绑定依赖
  已有的 edit action 或少数自定义 `edit-vi-*`，**不复制 `read-input`**。构造 /
  绑定失败自动回退原生 `CLIInput` + `Alt-*` 预设。
- **边界**：0.70 `tools/tty-check.py` 已在 WSL 真 PTY 下自动验证 Vi 徽标、
  Tab 补全、SQL 补全、describe 与嵌套 REPL 直通；真实终端模拟器的光标手感
  仍需人工确认。normal 模式下 bracketed paste 会被当 vi 键吞掉（粘贴前按
  `i`）；不做多行 buffer / 可视块 / `.` 重复。子类化依赖
  `Terminal::LineEditor` 0.0.23 内部结构。

**V-155**：上下文提示（0.66，ADR-0003 §3.2）：

- `hint [输入行]` 查询；TTY 下 `config set hints on|off`（默认 `on`）在 prompt
  前打印一行暗灰提示；**管道 / 非 TTY 完全不输出**（V-116 不变）。
- 提示来自 `hint-for`（命令 usage 首行 / registry spec 参数 / `!` argv 说明 /
  启动参数误用）与 `result-hint`（失败格下一步建议）；同一首词只提示一次。
- 不做「输入中实时弹窗」：行编辑器没有输入变化 hook，硬塞补全列表会污染补全。

**V-156**：显式本地 Raku 插件（0.66，ADR-0003 §3.3）：

- `config set plugins on`（默认 **off**）后可用 `plugin load PATH`；
  `plugin list | info NAME | unload NAME | help`。
- 路径经 `Sys.resolve` root 校验、源码经 `Sys.read`；插件是 Raku 文件，最后一个
  表达式求值为 `Command` 对象或 `List[Command]`，注册进会话 `CommandRegistry`
  （`registry.names` / `help()` / `cmd('name', ...)` 可见），**不进 Shell 文本
  命令表**。重名冲突（内建 / 其它插件）返回 409；`unload` 只移除自己的命令。
- **加载即执行本地 Raku 代码**，等同 `use` 一个本地模块，不是沙箱：只加载可信
  文件。不自动扫描目录、不联网、不持久化、不开机加载。
- Agent 的 op 白名单不暴露 `plugin`，Sandbox 不加载插件；插件的
  `run($sys, ...)` 拿到会话 `Sys`，必须经它做文件 / 进程操作（V-129）。
- 测试：`t/19-repl-experience.t`（89 断言：模态语义、预设合法性、行编辑器
  子类与回退、hints、插件默认拒绝 / 冲突 / 越界 / 卸载、Agent 白名单、管道）。

**V-157**：符号链接逐段 root 校验（0.67，安全修复）：

- `Sys.resolve` 在 `!canonical` 之外，对路径链上每一级 `.l` 做 `readlink`
  并校验真实目标在 root 内；root 自身允许是链接。
- 原因：Windows 上 `IO::Path.resolve` **不跟随文件类型的符号链接**（指向目录时
  `.e=False` / `.l=True`，但 OS 的 open/slurp 会跟随），只靠 canonical 会让
  `escape-dir/secret.txt` 读到 root 外内容。
- dangling symlink / 无法 readlink 一律按 `X::Rakuish::Sandbox` 拒绝，不放行。
- 测试：`t/01-sys-fs.t`（中间 symlink 读 / 写越界均被拒）。

**V-158**：流式查询 Cursor（0.67，[ADR-0004](docs/ADR-0004-cursor-worker.md) §3）：

- `Engine.cursor($sql, *@params, :$batch-size, :$max-rows)` 返回一次性
  `Rakuish::Data::Cursor`；`next-batch` / `batches` / `rows` / `take` / `close`。
  只有被拉取时才向驱动要下一批行，`close` 幂等、拉完或达上限自动释放。
- DuckDB 用 `DB.query(:$stream)` + 惰性 `chunks`（驱动一次只持有一个 chunk）；
  SQLite 用 `Result.hash` 逐行 `sqlite3_step`。**不复用 `.hashes` 物化**。
- 不支持的引擎抛 `X::Rakuish::Unsupported`，**不静默退化成 `query()`**；
  只读判据、LIMIT 下推、`X::Rakuish::Data` 错误包装与 `query()` 一致；
  V3 异常族原样抛。`query()` 与 `Table.batches` 行为不变。
- 刻意不用 `gather/take` 嵌套：两层惰性 continuation 跨调用帧会触发
  `continuationreset` 错误，改用显式 `Iterator` + fetch 闭包。
- **边界**：一次性单连接，不提供可恢复游标 / 事务一致性快照 / 并发修改下的
  稳定视图；提前退出惰性 Seq 需显式 `close`（`DESTROY` 只作兜底）。
- Agent 的 `sql_query` **不暴露** Cursor（流式对象无法安全序列化进 JSONL），
  `query(:max-rows)` 的 LIMIT 下推保证物化前截断。
- 测试：`t/20-data-cursor.t`（56 断言：惰性计数、分批、上限、close、错误包装、
  DuckDB streaming / SQLite 逐行两后端、角色默认拒绝、Agent 白名单）。

**V-159**：连接级 worker 与 OS 硬取消（0.67，ADR-0004 §4）：

- `--worker` **默认关闭**，必须与 `--mode tcp --serve` 同用；不开时 `serve()`
  与 V-151 完全一致。每连接启动一个常驻 worker 子进程（不是按请求 fork）。
- 配置（含 token）走子进程 **stdin 第一行**，不进命令行参数；就绪握手行由
  父进程消费，启动成本隔离在连接建立阶段。stdout 只有响应 JSONL，诊断走 stderr。
- 子进程返回 504 或父进程 watchdog 到点 → `kill` 整个 worker 进程；卡在
  不可取消文件 I/O 里的线程随进程消失。审计集中在父进程并脱敏，子进程
  不写审计文件；每连接独立 session。
- **边界**：硬取消后该连接随即关闭（客户端需重连），与 V-151「连接继续可用」
  不同；不保证杀掉 worker 派生的孙进程（无 job object / 进程组）；
  不提供跨连接会话状态或 Engine 缓存共享。
- `--worker-hard-timeout-ms` 可显式设置监督者硬超时，默认
  `request-timeout-ms + 1000`（无 deadline 时 30s）。
- 测试：`t/21-agent-worker.t`（29 断言：真实子进程 + TCP、握手、非法配置、
  kill 后进程退出、504 后连接关闭、新连接不受影响、审计脱敏、默认拒绝）。

**V-160**：CSV 受控外部读写（0.68，[ADR-0005](docs/ADR-0005-data-workbench.md) §2）：

- `open-data` / `save-data` 的 `.csv` 在显式 `:allow-external` 时走 DuckDB
  `read_csv_auto(?)` / `COPY (...) TO ... (FORMAT CSV, HEADER)`；与 Parquet
  共用 V-152 的授权模型：路径经 `Sys.resolve`、受控 `:!safe` 引擎、
  Agent 的 op 白名单不暴露该开关。
- **默认行为不变**：不带开关的 `.csv` 仍走 `Sys.read` + `from-csv-data` /
  `Sys.write` + `to-csv-data`（V-129 路径）。
- `Engine.read-csv(:$max-rows)` 支持 LIMIT 下推；`write-csv` 拒绝含分号的
  导出 SQL；驱动异常统一 `X::Rakuish::Data`，V3 异常族原样抛。
- 导出流程与 Parquet 共用 `export-table`（建临时表 → 参数化 insert → COPY），
  空值规则一致，不写 SQL NULL。
- **不承诺**：CSV 方言全兼容（分隔符 / 编码 / 多行字段精细控制）、按 schema
  强制类型、分区写出。
- 测试：`t/22-data-csv.t`（33 断言：默认路径类型仍 str、外部路径推断
  int/num、写入往返、root 越界、Agent 白名单、角色默认拒绝、错误统一、
  Parquet 导出流程回归）。

**V-161**：Engine 元数据驱动的 SQL 上下文补全（0.68，ADR-0005 §3）：

- `Rakuish::REPL::SqlComplete` 是纯函数：仅当光标位于 `'...'` / `"..."`
  字符串内、且该字符串是 `query/cursor/execute/sql(...)` 参数时激活；
  否则返回空，`Shell.completions` 原路径一字不改。
- `DSL.open-db` 通过 `$*RAKUISH-SESSION` 把新建 Engine 注册为当前会话
  Engine（`repl.engine` 可读，最后一次 `open-db` 生效）。
- 候选来自只读 `tables()` / `schema()` 元数据加固定 SQL 关键字；按「最近
  关键字」启发式决定补表名还是列名；返回**完整替换行**（与 Shell 约定一致）。
- 所有 Engine 调用包在 `try` 里：驱动缺失 / 库被锁 / 元数据查询失败都优雅
  退化成空补全，不让 Tab 崩 REPL。非 TTY / 管道下不创建行编辑器，不触发。
- **边界（0.71 修订）**：`q[...]` 等不插值引号算子与 `sql =>` / `:sql(`
  具名形态已由 V-169 支持；仍不识别 `qq` / `Q` / heredoc / 嵌套 `q[...]`，
  不解析 SQL AST，不引 `\d` / 裸 SQL 命令等第二套语法；SQL 仍是字符串参数。
- 测试：`t/23-sql-complete.t`（30 断言：上下文识别、关键字/表名/列名、
  完整替换行与 tail、异常退化、Session 联动、Shell 回退、open-db 注册链路）。

**V-162**：CSV 方言参数（0.69，[ADR-0006](docs/ADR-0006-data-profile.md) §2）：

- `open-data` / `save-data` 增加 `:%csv-options`，`Data::CsvOptions` 是纯函数
  白名单：`delimiter` / `quote` / `escape` / `nullstr` / `header` / `skip` /
  `all-varchar`。未知键明确抛 `X::Rakuish::Unsupported`，不静默忽略。
- **读路径**：选项一律写成 `name => ?` 并用参数绑定，值不进 SQL 字符串；
  选项名只来自常量表。**写路径**：`COPY` 选项不支持绑定，字面量须先过
  「单字符可打印 ASCII / 长度 ≤64、不含单引号、反斜杠、换行、NUL」校验；
  `skip` / `all-varchar` 在写路径明确拒绝，不假装生效。
- 方言选项**只在 Raku 层**且必须 `.csv` + `:allow-external`；默认路径仍走
  `Sys.read` / `Sys.write` + Raku 解析器（V-129）。空选项生成的 SQL 与 0.68
  逐字一致。Shell 薄层 `open --external` 不做第二套参数语法。
- 路径仍经 `Sys.resolve` root 校验；Agent 的 `OPS` 白名单不变、不新增 op。
- **不承诺**：编码 / 多行字段精细控制、按 schema 强制类型、分区写出。
- 测试：`t/24-csv-dialect.t`（57 断言：白名单纯函数、注入拒绝、方言往返、
  默认行为不变、Agent 白名单、REPL 链路）。

**V-163**：`describe` 值 API（0.69，ADR-0006 §3）：

- `Table.describe(:$sample)` 与 `Engine.describe(Str $table, :$sample)` 都返回
  **Table**，列集合固定为 `name/type/nullable/non_null/distinct/total/sample`；
  不返回文本报告，可继续组合。
- `Engine.describe` 是**角色默认实现**，只依赖契约里的 `schema()` / `query()`
  聚合（`count(*)` / `count(col)` / `count(distinct col)`），因此 DuckDB /
  SQLite 与第三方引擎自动获得。表名限定 `[A-Za-z_][A-Za-z0-9_]*` 并加双引号；
  单列聚合失败时该列统计留空、整表不失败、不编造数字。
- DSL `describe($value)`：Table → 值摘要；Str → 当前会话 Engine 的表摘要；
  其它类型明确抛 `X::Rakuish::Unsupported`。REPL `describe [表名]` 是会话
  命令（与 `hint` / `plugin` / `perf` 同级，**不是 `%magic`**）：无参数取上一格
  成功值（Table 直接摘要，否则列出 `tables()`），有参数需已注册 Engine。
- **不承诺**：大表 `count(distinct ...)` 性能（可用既有查询超时限制）、
  文本直方图、关联分析。
- 测试：`t/25-describe-complete.t`（69 断言）。

**V-164**：SQL 上下文补全增强（0.69，ADR-0006 §4）：

- 在 V-161 启发式上增加：`from sales s` / `join users as u` 的**别名映射**；
  `s.am` 前缀只补 `sales` 的列且不塞关键字，返回完整替换行 `s.amount`；
  关键字大小写跟随输入片段（`SEL` → `SELECT`、`Sel` → `Select`）；扩展调用名。
- 仍**不解析 SQL AST**：不引解析器依赖、不处理 `qq` / `Q` / heredoc
  （`q[...]` 由 V-169 以纯词法方式支持）、不承诺方言完整性；所有 Engine
  元数据调用继续包在 `try` 里优雅退化。
- 理由见 ADR-0006 §4：DuckDB / SQLite 方言不同、Tab 热路径成本不划算、
  启发式已覆盖主要场景。SQL AST 级补全列为 V-908「不做」。

**V-165**：REPL 的 `open-data` / `save-data` 名字解析（0.69，缺陷修复）：

- `REPL::Session` 同时 `use Rakuish::DSL` 与 `use Rakuish::Data` 时，后者导出的
  同名 sub（带 `$sys` 首参）会覆盖 DSL 版本，导致文档示例的单参数形态在
  EVAL 里报参数错误。Session 内部只用全限定名，故改为 `need Rakuish::Data`。
- 此后 REPL 中 `open-data('x.csv')` / `save-data('x.csv', $t)` 解析到 DSL 的
  会话级版本；`Rakuish::Data::open-data($sys, ...)` 仍可供脚本显式调用。
- 测试：`t/24-csv-dialect.t` 的 V-165 回归段。

**V-166**：失败格不污染 stderr（0.69.1，缺陷修复）：

- 症状：`zef test` / REPL 中，混合格或含 phaser 的声明格之后引用未声明类型时，
  stderr 出现两次 `Use of uninitialized value of type Any in string context`
  （`REPL::Session` 的 `CATCH` 取异常消息处）。
- 根因：部分编译期异常的 `.message` / `.gist` 在**方法内部**字符串化未定义值并
  抛 `CX::Warn`；仅在调用侧判断 `.defined` 拦不住。
- 修法：用 `quietly` 只包住「构造异常文本」这一小块，结果仍显式收敛成 `Str`，
  最后以 `$ex.^name` 兜底；错误消息内容不变、不吞掉其它警告。
- 测试：`t/18-repl-types-glob.t` 新增子进程断言——失败格 stderr 不含
  `uninitialized value` 且子进程正常退出。

**V-167**：交互式子进程的 TTY 直通（0.70，[ADR-0007](docs/ADR-0007-tty-passthrough.md)）：

- 症状：`! raku` 这类嵌套 REPL 的输出被 `Sys::Proc` 的 Channel 捕获，
  30s 后被默认超时杀成 `code=124`，失败格不进 `_` / `Out[n]`。
- 显式入口：`! --tty <exe> [args]` / `! -t <exe> [args]`，Raku 里是
  `tty-exec(...)`；`! -- <exe> ...` 之后全部按字面 argv，不解析元选项。
  元选项属于 `!` 分发层，子进程收到的仍只有 argv 数组。
- `Sys::Proc.tty-exec`：`bind-stdin($*IN)` / `bind-stdout($*OUT)` /
  `bind-stderr($*ERR)`，输出实时可见、**无超时**、不捕获、不进 `_`；
  只返回退出码 / 耗时 / exe / argv 的结构化 `Result`（`op=tty-exec`）。
- 守卫：`$*IN.t && $*OUT.t` 必须为真；非 TTY 抛
  `X::Rakuish::Unsupported`，`Session` 收敛成 `code=127` 的失败 Result，
  不污染 V-116 的管道纯净输出。`cwd` 仍经 `Sys.resolve` root 校验、
  `env` 仍是会话 Hash。
- Ctrl-C 归属：0.73.0 起 POSIX 上用**进程组交接**（`posix_spawnp`
  `SETPGROUP` + `tcsetpgrp`）让子进程成为终端前台，Ctrl-C 由终端驱动直接
  投给它，父进程收不到；`SIGINT tap` 只保留在 spawn 与切前台之间的
  微秒级窗口。Windows 与降级路径仍是「父进程临时吞 SIGINT」（见
  **V-175 / ADR-0010**）。行编辑器 `prompt()` 返回时已 `leave-raw-mode`，
  无需手工改终端模式。中断期间的完整契约与真 PTY 回归见
  **V-173 / ADR-0009**（0.72.3）。
- 默认 `!` 的捕获 / 截断 / 30s 超时 / `Result.value` 语义**一字未改**；
  `code=124` 的失败格提示改用 `tty-exec(...)`。
- Agent op 白名单不暴露 `tty_exec`；不自动探测交互式程序、不捕获交互式输出、
  不注册后台 job、不提供嵌套子进程的多路复用（ADR-0007 §4）。
- 测试：`t/26-nested-repl.t`（32 断言；Windows 跳过 4 条真 PTY 集成，
  WSL/Linux 用 Python `pty` 起真实子进程验证首字符不丢、退出码回传）、
  `t/30-tty-exec-sigint.t`（中断归属契约，V-173）；
  `tools/tty-check.py` 是完整交互自检工具。

**V-168**：Ctrl-C 中断输入而非退出 REPL（0.71，[ADR-0008](docs/ADR-0008-input-interrupt-sql-forms.md) §3.1）：

- 问题：`Terminal::LineEditor` 默认把 `Ctrl-C` 绑成 `abort-input`，
  `prompt()` 返回未定义 `Str`；`bin/rakuish` 把未定义当 EOF，于是整个会话
  退出，与 `Session.key-bindings` 的「中断当前 cell / 清空续行缓冲」及
  `handle-key('Ctrl-C')` 的值 API 不一致。
- `REPL::Keymap::InterruptCLIInput`（继承 `CLIInput`）在 `decode-keyname`
  记本次 prompt 的 Ctrl-C 标志，`prompt` 把「abort 且标志为真」收敛成
  **定义的空串**；`take-interrupt` 一次性供宿主查询。真 EOF 与 Ctrl-D
  仍返回未定义 `Str`，退出语义不变。`ViCLIInput` 继承该子类，`make-cli`
  在 emacs 模式也构造它；构造失败回退原生 `CLIInput` 时如实记录为 0.70 行为。
- 宿主命中中断标志后调用 `$session.handle-key('Ctrl-C')` 复用值 API 清
  `@!pending`，不 `eval-line`、不进历史、不产生空 `Out[n]` 格，打印暗灰
  提示并 `next` 重画 prompt。`Ctrl-D` / `exit N` 仍是退出入口。
- **边界**：只处理输入阶段的 Ctrl-C；cell 求值中行编辑器不读键，SIGINT
  仍按 Rakudo 默认行为，不承诺中断运行中的 cell。不复制 `read-input`、
  不用哨兵字符串、不装全局 SIGINT handler（ADR-0008 §4）。
- 测试：`t/19-repl-experience.t`（解码 / 一次性标志 / 三模式类接线）、
  `t/27-interrupt.t`（值 API + 真 PTY：半行 → Ctrl-C → 仍活 →
  `Out[1] = 42` → Ctrl-D 退出；Windows 跳过 8 条）、`tools/tty-check.py` 增 2 项。

**V-169**：SQL 补全的调用形态扩展（0.71，ADR-0008 §3.2）：

- `sql-context` 的扫描器除 `'...'` / `"..."` 外，还支持**不插值**
  `q[...]` / `q{...}` / `q(...)` / `q<...>`；`q` 前须词边界，反斜杠跳过
  下一字符，不处理嵌套分隔符。SQL 内含单引号时不再打断上下文。
- 调用检测放宽为「CALLS 白名单名字 + `(`，其后可跟 `:sql(` 或 `sql =>`」
  的紧邻前缀；不扫描整行、不做括号配对回溯。返回结构新增 `quote-style`
  （`single` / `double` / `q`）。
- 候选生成、完整替换行与 `tail` 保留、别名映射、大小写风格、Engine 异常
  优雅退化、Shell 回退**全部不变**；仍不做 SQL AST（V-908 不变），
  不识别 `qq` / `Q` / `qx` / heredoc。
- 测试：`t/23-sql-complete.t` 新增 q 四种分隔符 / 两种具名形态 / 内嵌单引号 /
  tail 保留 / 双引号回归 / `qq` 与非白名单负向。

**V-170**：PTY 捕获层（0.72）：

- `Sys.pty-exec` / `DSL.pty-exec` 用 `Proc::Async.new(:pty(:cols,:rows))`
  给子进程分配伪终端；stdout 由父进程捕获，stderr 合流（PTY 语义）。
- 默认 `strip-ansi=True`，去掉 CSI / OSC / 非换行控制字符；`Result.out`
  是干净文本，`value` 标记 `pty/tty/timed-out/truncated/cols/rows`，
  0.72.2 增 `pty-capable/stderr-merged/stdin-unavailable/strip-ansi`。
- `timeout-ms` 到点 kill 子进程，返回 `code=124`、`err='PTY 请求超时'`；
  `max-bytes` 限制的是**剥离后文本**的字节数：0.72.2 起先对完整输出剥离
  控制序列、再做 UTF-8 安全截断（控制序列不占配额，也不会被截成半截残留）；
  tap 内只按 chunk 计数，累积上限 `4 × max-bytes`。
- **能力探测（V-172）**：`pty-exec` 先过版本 + isatty 双检，失败返回
  `code=127` 且 `value<pty>/<tty>` 为 `False`，绝不静默当 PTY 用。
- **不提供 stdin 写入**：当前 Rakudo 的 `Proc::Async :pty` 没有可靠的
  stdin 通道；不要把它伪装成完整交互会话。
- Agent `pty_exec` 默认关闭；必须同时显式 `--allow-exec --allow-pty`，
  argv[0] 过 canonical 白名单，cwd 过 root，env 只允许安全键；
  请求参数只能调小 timeout / output / 尺寸。
- 测试：`t/28-pty-exec.t`（PTY 捕获、TTY 可见、控制序列剥离、超时 124、
  max-bytes、Agent 默认 403、显式开关成功）。

**V-171**：Windows 的“文件系统根”（0.72.1）：

- POSIX 的 `root=/` 表示整个文件系统；Windows 的 `C:\` 只是当前盘根。
- REPL / 脚本默认构造 `Sys.new(:all-drives)`，允许 `D:/`、`F:/` 等其他盘；
  root 仍记录启动盘，用于默认 cwd / 显示。
- Agent / 显式 `Sys.new` 默认 `all-drives=False`，跨盘目标仍按 root 拒绝。
- `all-drives` 时跳过逐段 symlink root 校验（语义等同 POSIX root=/）；
  不是 OS 隔离，Agent 不应打开。
- 测试：`t/02-sys-session.t` 在 Windows 有 F: 时验证跨盘允许/默认拒绝。

**V-172**：PTY 能力探测与捕获层收尾（0.72.2，[AUDIT-FIXES-0.72.2](docs/AUDIT-FIXES-0.72.2.md)）：

- 起因：`Proc::Async.new` 用 `*%_` 吞掉未知命名参数，旧 Rakudo 传 `:pty`
  不报错、不生效；0.72.0/0.72.1 的 `Result.value<pty>/<tty>` 却硬编码
  `True`，等于结果撒谎（任务书 R-1，`[确证]`）。
- `Rakuish::Sys::Proc.pty-capability()` 做「`$*RAKU.compiler.version >=
  v2025.12` + 用 `:pty` 起 `raku -e 'print $*OUT.t …'` 真探针」双检，
  结果 `Lock` + 进程级缓存（一次/进程），失败带 `reason`。
  `META6.json` 的 `raku` 字段是语言版本，不能当 Rakudo 下限用；
  最低 Rakudo 版本写进 MANUAL / AUDIT-FIXES，不塞未识别元数据键。
- 探测失败时 `pty-exec` 返回 `Result.new(:!ok, :code(127))`，`err` 写明
  原因、`value<pty>/<tty>` 为 `False`；**不降级成普通 exec、不抛穿 Agent**。
  方法为 public，可被子类覆盖以注入失败路径（`t/29`，无需装旧 Rakudo）。
- 捕获层（任务书 R-3，`[需复核]` → 已实证）：tap 内改「数组追加 + 仅对
  新 chunk 计 UTF-8 字节」，结束一次 `join`；先 `strip-terminal-controls`
  再 `clip-bytes`；超过 `4 × max-bytes` 停止累积但继续消费并标 `truncated`；
  drain 改为等 stdout Supply 的 `done/quit`（0.5s 兜底、超时标 `truncated`）
  而非固定 `sleep 0.02`；Windows ConPTY 大输出仍可能在驱动层丢尾部 chunk
  （裸 `Proc::Async` 同样复现，非本版回归，见 AUDIT-FIXES-0.72.2 §3）。
- **边界不变**：`:!strip-ansi` 仍按原始字节截断（半截序列是该模式已知边界）；
  stderr 合流、`err` 恒空（超时除外），用 `value<stderr-merged>` 标记；
  不提供 stdin 写入（交互式 REPL 请用 `tty-exec`），用
  `value<stdin-unavailable>` 标记；超时只 kill 直接子进程，不承诺杀孙进程。
- 测试：`t/28-pty-exec.t`（18 断言）+ `t/29-pty-capability.t`（36 断言：
  能力探测、注入失败、结果标记、截断无 CSI 残片、`:!strip-ansi`、大输出）。

**V-173**：`tty-exec` 期间 Ctrl-C 的归属契约（0.72.3，[ADR-0009](docs/ADR-0009-tty-exec-sigint-contract.md)）：

- `! --tty` / `tty-exec(...)` 期间，前台进程组收到 SIGINT（真终端的 Ctrl-C）
  时，子进程按自身 SIGINT 语义退出，`tty-exec` 返回交接摘要与
  `Result.value<exit>`；**父进程存活**，之后重画 prompt，下一格可正常
  输入并求值；`LEAVE` 关闭临时 tap 后，普通 Ctrl-C 仍是 V-168 的输入中断。
- 实现不变：`Sys::Proc.tty-exec` 的 `signal(SIGINT).tap(-> $ { })` +
  `LEAVE` 这一对行为已满足契约（0.72.2 实测）。本版只把契约钉成断言，
  **不改产品代码**。
- 回归用「`start_new_session` + `killpg(pgrp, SIGINT)`」模拟前台进程组。
  **0.73.0 起改为真终端路径**（`pty.fork` + 写 `\x03`）：进程组交接落地后，
  那个模拟写法不再成立 —— 切组后信号打不到子进程（见 V-175）。
- **边界**：0.72.3 当时不做 `setpgid` / `tcsetpgrp`；**该边界已由 V-175
  在 0.73.0 解除**（POSIX-only）。仍不做 `&` / `jobs` / `fg` / `bg` /
  Ctrl-Z 作业管理。子进程忽略 SIGINT 时 `tty-exec` 仍按无超时边界一直等；
  不承诺求值中 SIGINT 的 Rakudo 默认行为；Windows 无 pty 时整段跳过。
  终端状态恢复 0.72.4 起单独由 V-174 覆盖（0.72.3 曾误判为「本驱动不可观测」）。
- 测试：`t/30-tty-exec-sigint.t`（Linux/WSL 真 PTY，5 条契约断言；
  Windows skip）、`tools/tty-check.py` 增 2 项。
- **0.101.4 补充**：双进程架构（ADR-0021）下「父进程存活」还必须包括
  **引擎子进程存活**——宿主自己的 SIGINT handler 曾在 `in-request` 分支
  SIGKILL 引擎，Ctrl-C 后显示「引擎进程已退出 → 重启」。见 V-289。

**V-174**：`tty-exec` 交接期的宿主 termios 快照恢复（0.72.4，
[ADR-0009 §0](docs/ADR-0009-tty-exec-sigint-contract.md)）：

- 背景：`tty-exec` 将宿主 TTY 三条 fd 直接 bind 给子进程；子进程
  （vim / less / `stty raw -echo`）改动 termios 后不还原时，行编辑器
  下一轮 prompt 会把污染态当成新基准「保存并恢复」，污染固化（实测
  `c_lflag` 35387 → 35376，关掉 `ICANON + ECHO + ISIG`）。
- `Sys::Proc.tty-exec` 在 `bind-stdin` **之前**调用
  `termios-snapshot($fd)` 保存宿主配置，正常路径与 `LEAVE` 幂等恢复
  （`Terminal::API::restore-config(..., :when(DRAIN))`）。`LEAVE` 是块级
  phaser，非 TTY 守卫抛异常时也会触发，故恢复前必须判 `$saved.defined`
  并整体包 `try`，不得覆盖原异常。
- 复用 `Terminal::API`（`Terminal::LineEditor` 的传递依赖，0.72.4 起在
  `META6.depends` 显式声明）：Linux / macOS / BSD 三套 CStruct 与
  Windows `GetConsoleMode` / `SetConsoleMode` 均已封装，不重写 NativeCall。
- `Result.value<termios-restored>` 如实标记恢复成败；快照不可用
  （非 TTY / API 失败 / 子类注入）时**不阻断直通**，只标 `False`。
- **边界**：不猜测子进程改了哪些位，整份配置恢复。
- Windows 无 POSIX termios，走 `GetConsoleMode` / `SetConsoleMode`。
  0.72.5 用真 ConPTY 实测通过：输入模式 `503` → 子进程 `make-raw` 后
  `1008` → 返回后 `503`（`termios-restored=True`），关掉快照的对照保持
  `1008`；conhost（winpty）下数值一致。`prove6` 环境无控制台，该分支不进
  `t/`，由 `tools/tty-termios-win.py` 自查（ADR-0009 §7）。
- 测试：`t/31-tty-termios.t`（canonical 基线 PTY，13 断言：正常恢复 /
  注入禁用快照的对照证明污染真实发生 / 非零退出路径 LEAVE 兜底；
  Windows 只跑 2 条非 TTY 退化断言）。

**V-175**：`tty-exec` 的 POSIX 进程组交接（0.73.0，
[ADR-0010](docs/ADR-0010-job-control-feasibility.md) §6）：

- 背景：0.72.x 用 `Proc::Async` 起子进程，父子**同属一个进程组**，
  靠父进程临时吞 SIGINT 保命。后果是子进程一句 `kill(0, SIGTERM)`
  （现实中清理进程组的工具会这么做）会把宿主 REPL 一起打死 —— 真 PTY
  实测 `alive=False`。而 POSIX 只允许父进程对**尚未 exec** 的子进程
  `setpgid`，`Proc::Async` 交出 pid 时子进程早已 exec（实测 60/60 失败、
  `EACCES`），所以只能在 spawn 时定组。
- 实现：POSIX 上改用 `posix_spawnp` + `POSIX_SPAWN_SETPGROUP(0)`
  （新模块 `Rakuish::Sys::PosixSpawn`），spawn 后 `tcsetpgrp(0, child-pgid)`
  把终端前台交给子进程；`waitpid` 自己回收并解出 `exit` / `sig`。
  返回时把前台还给宿主，再恢复 termios。
- **SIGTTOU 必须真 `SIG_IGN`**（`signal(2)` + handler `(void*)1`），并在
  `LEAVE` 还原旧 handler。用 Raku 的 `signal(SIGTTOU).tap` 是捕获语义，
  会让恢复那次 `tcsetpgrp` 返回 `ENOTTY`（ADR-0010 §2.3 实测）。
- SIGINT tap 缩到**交接窗口**（spawn 后、切前台前）：那段时间前台仍是父组，
  不兜住会被 Ctrl-C 带走；切前台成功立即关闭。正常运行**不依赖**该 tap。
- `cwd`：`posix_spawn` 无 cwd 参数，用
  `posix_spawn_file_actions_addchdir_np`；与当前目录相同的请求直接跳过该动作。
  符号不可用（glibc < 2.29 / macOS < 10.15）时**降级**回 `Proc::Async`，
  `value<job-control>=False` 且写 `value<job-control-reason>`，
  **绝不改父进程 `chdir`**。
- 状态映射：`WIFSIGNALED` → `code = 128 + sig`；`posix_spawnp` 返回
  `ENOENT(2)` → `code=127`；`waitpid` 拿不到状态 → `code=1`（不谎报成功）。
- `Result.value` 新增 `job-control` / `job-control-reason` / `fg-restored` /
  `pgid`；原有 `exit` / `signal` / `elapsed` / `termios-restored` 语义不变。
- **边界**：只做进程组交接。不做 `&` 后台、`jobs` / `fg` / `bg`、Ctrl-Z
  作业管理（那是 shell 语法，需另立议题，且与 V-90x「不引 bash 语法」冲突）；
  不做信号转发（SIGWINCH 由子进程组自己处理）；不做孙进程树回收（V-905）。
  Ctrl-Z 会把子进程停住而 REPL 等在那儿 —— 这是明确划出去的已知行为。
- Windows 无 POSIX 前台进程组（`CTRL_C_EVENT` 不能投递给进程组，属 MSDN
  明确语义），走老路径，`value<job-control>=False` 并带原因。
- 测试：`t/32-job-control.t`（真 `pty.fork` controlling terminal，11 断言：
  自成一组 / 拿到前台 / 退出码与信号码映射 / cwd 动作 / `kill(0)` 不波及
  宿主 / Ctrl-C 只投给前台组 / 前台收回；Windows skip）。
  `t/30` 的驱动同步改用真终端路径（`pty.fork` + 写 `\x03`）。

**V-176**：内置命令结果的着色（0.74.0，
[ADR-0011](docs/ADR-0011-highlight-colors.md) §2–§3）：

- 开关链唯一：`config color` / `NO_COLOR` / `FORCE_COLOR` / `$*OUT.t`
  → `Chrome::color-mode()` → `Session.new(:color)` 与 `make-cli` 的高亮开关。
  `Session` 的默认值是 `False`（忘记传参的调用点一律纯文本）。
- 着色点与样式：路径列表与 `ls -l` 的名字列（目录粗蓝 / 可执行粗绿 /
  符号链接青）、`Out[n] =` 标签（dim）、`错误:` 整行（红）、`help()`
  的命令名（粗青）与摘要（dim）、`env()` 的 KEY（青）、`stat` 的字段名
  （dim）、写入结果的 `wrote`（绿）与 `[non-atomic]`（黄）。
- **「可执行」分平台判定**（0.77.0 订正）：POSIX 看执行位；Windows 看扩展名
  （`exe/bat/cmd/com/ps1/msi`）。依据是 `IO::Path.x` 在本版 Rakudo 的 Win32 上
  会抛（`rindex ... got null`），旧实现把它包在 `try` 里 —— 异常被吞成「不是
  可执行」，于是 **Windows 上从未把 exe 标绿过**，且不报错、看不出来。
- **不变式**：颜色只插入零宽转义。列宽、列数、padding 一律按**纯文本**算，
  否则多列 `ls` 会错位；`strip-ansi(着色结果)` 必须与不着色时逐字符相同。
- **渲染层必须同时判 TTY**：只问 `color` 开关会让 `rakuish -e 'ls' | cat`
  混进 ANSI，违反 V-116。统一走 `Session!color-on`（开关 ∧ `$*OUT.t`）。
- **不做**：`Result` 的 `render-result(format => 'text')` 仍不掺 ANSI
  （SPEC 747 不变）；`Table.to-text`（describe / `ls --json`）不着色；
  Agent 输出不着色（JSONL 没有终端语义）。
- 测试：`t/33-colors.t`（非 TTY 零 ANSI、色表、路径分类；普通文件用**自建
  夹具**而非仓库文件 —— 文件模式取决于检出方式，从 drvfs 拷来的树满是 `+x`）；
  `tools/tty-check.py` 在 raw 字节上断言真 PTY 下 `ls` 目录确实着色。

**V-177**：REPL 输入行的语法高亮（0.74.0，
[ADR-0011](docs/ADR-0011-highlight-colors.md) §4）：

- 实现方式：行编辑器不提供高亮钩子，覆盖
  `ScrollingSingleLineInput::ANSI.visible-input-field-string` —— 它是
  「左滚动标记 + 内容 + padding + 右标记」那一层，只给中间的内容段上色。
  新增 `Rakuish::REPL::Keymap::HlField` 作为基类，`ViField` 继承它，
  `InterruptCLIInput` 覆盖 `input-class` 让 emacs 模式也走同一个字段类。
- **硬不变式**：着色串的**纯文本部分**必须与不染色时逐字符相同。父类用
  `display-width`（对 buffer 内容算出的显示宽度）定位光标与清屏，多一个
  可见字符就会让输入区错位。`$.mask.defined`（掩码输入）时直接短路。
- 词法范围（`Rakuish::REPL::Highlight`，纯函数）：注释 `#…`、单双引号
  字符串（含 `\` 转义、未闭合染到行尾）、数字、`$ @ % &` 变量（含 twigil）、
  关键字表。**不做** `q[...]` / `qq[...]` / heredoc / 正则字面量 /
  多行字符串 / pod —— 它们需要跨行状态或真正的 Raku 词法器。
- 回退：`make-cli` 在子类构造失败时回退到原生 `CLIInput`，那条路径
  **没有高亮**（与 Ctrl-C 的回退同理，如实标注，不假装）。
- 开关与 V-176 同源，`config set color off` 当格生效；非 TTY 与
  `NO_COLOR` 下不进入着色分支。
- 测试：`t/33-colors.t`（27 个样本的纯文本等价、`:!color` 逐字节相同、
  各 token 命中）；`tools/tty-check.py` 在 raw 上断言真 PTY 输入
  `say "hi"` 时字符串与关键字确实着色。

**V-270**：跨行引号高亮（0.97.0）。

- 词法范围扩到**跨行引号**：Session 判定续行（`is-incomplete`）时，把已提交
  的续行源码经 `Highlight.set-continuation($src)` 传给高亮器；下一行开头若
  仍在未闭合的 `"..."` / `q[...]` / `qq(...)` 内，整段染成字符串色，遇闭合
  记号后恢复正常 token 着色。提交完成 / 清空续行 / Ctrl-C 时置空状态。
- 这是**轻量**跨行：只回答「在哪个引号里、等什么闭合」，复用单行那套闭合
  与 `q[...]` 同类嵌套规则；**仍不做**正则字面量 / heredoc / pod / 插值块
  `{$x}` 里的代码着色（需真正的 Raku 词法器）。
- **硬不变式在跨行下同样成立**：着色只走 `seg`（零宽 ANSI），
  `strip-ansi(highlight-line($s)) eq $s` 恒成立（`t/33` 10 断言守）。

**V-271**：大文件的 `head` / `tail`（0.97.0）。

- `head -n N` / `tail -n N` 走 `Sys.read-lines(:head/:tail)` 流式按行读，
  只留 N 行、不 slurp 全文，**不受 `read` 的 `max-bytes` 全文上限**——
  读的量与文件总大小无关，大日志也能看首尾。
- 路径仍过 `Sys.resolve`（root 校验与 `read` 同一条路），不另开口子。
- `read` 整份读的 1 MiB 上限**保留**（防 slurp 吃爆内存）；超限错误给出
  三条出路：`read-lines` / `head`·`tail` / `stream('路径')`，或显式
  `:max-bytes(N)` 自行承担内存。
- `tail` 仍扫到文件尾（内存只留 N 行）；O(n) 尾部 seek 不做。

**V-178**：命令选项的 Tab 补全（0.75.0，
[ADR-0012](docs/ADR-0012-userland-commands.md) §2）：

- 选项信息来自 `Shell` 的模块级常量 `OPTIONS`（`命令名 => 选项列表`），
  **不解析 `usage()` 的自由文本** —— 帮助文案随时会调，反推 flag 太脆。
- 触发条件：光标前的片段以 `-` 开头。此时**不进入路径补全分支**
  （否则 `ls --j` + Tab 会去当前目录找名为 `--j` 的文件），直接返回
  「完整替换行」候选，前缀匹配、排序、去重。
- `--help` / `-?` 对所有命令通用，补全时统一追加。
- **不做**：选项值补全（`--color=` 之后的枚举）、子命令补全、候选菜单。

**V-179**：`doc` 命令的对象内省（0.75.0，ADR-0012 §3）：

- `doc <内置命令>` 走 `Shell.usage()`，权威帮助优先于元对象；
  `doc <Raku 名字>` 走 `Rakuish::REPL::Introspect`（纯函数），输出类型名 /
  `WHY` / 例程签名 / 局部方法列表。
- **零 EVAL**：只用 `::($name)` 查符号表，绝不把参数当代码求值。
  因此**看不到跨格 `my` / `our`**（它们在 `Session` 的 `LexState` 里，
  不在全局符号表）—— 这是能力边界，不是缺陷。
- 名字校验：只放行标识符与 `&例程名`（`valid-name`）；`doc 1+1`、
  `doc a;rm -rf` 必须失败。
- 符号查找必须同时收口两条路：抛出 `X::NoSuchSymbol`，或返回**延迟
  Failure**。**不能用 `try`** —— `try` 会把块值（Failure）留在返回位置，
  之后在 GC 里 DESTROY 时吐 `unhandled Failure detected in DESTROY`；
  用裸块 + `CATCH`，并对返回值再做一次 `~~ Failure` 兜底。
  **也不能用 `.defined` 判断**（异常对象的 `.defined` 是 False，
  `Str` 这类类型对象的 `.defined` 同样是 False，两头都会误判）。
- `doc &say` 这类带 sigil 的参数要加入 Shell「未加引号元字符」闸门的白名单
  （与 `export` / `grep` / `glob` 同处），否则会被交回 Raku 求值。
- 测试：`t/34-userland.t`（合法/非法名字、类型与例程内省、`doc 1+1` 失败、
  `doc --help`）。

**V-180**：目录栈与书签（0.75.0，ADR-0012 §4）：

- `pushd DIR` / `popd` / `dirs` 维护 `Shell` 上的 `@!dir-stack`；
  `bookmark add NAME [DIR] | list | go NAME | del NAME` 维护 `%!bookmarks`。
- **所有改当前目录的入口收口到 `Shell!change-dir`**（`cd` / `pushd` / `popd` /
  `bookmark go`），`prev-cwd` 只在这一处更新 —— 否则 `cd -` 与目录栈会各说各话。
- 书签是**会话内**状态，不落盘；名字限 `[A-Za-z0-9_]`。
- 失败语义：栈空 `popd`、未知书签名、非法书签名都给错误 `Result`，不静默。

**V-181**：会话日志（0.75.0，ADR-0012 §5）：

- `log [start [路径]|stop|show|status]`，状态在 `Session`
  （`log-on` / `log-path` / `log-seq` / `log-lines`）。
- **写入点只有一个**：入口主循环里同时拿到「输入行 + Result + 渲染文本」的那一处。
  `log-line` 内部剥掉 SGR，**日志恒为纯文本**（TTY 渲染带颜色，直写文件会污染）。
- **落盘一律经 `Sys.write` / `Sys.append`**（V-125）；不复制 `!save-config`
  的裸 `.spurt` —— 那是配置文件的历史例外，不扩散到新能力。
- 默认路径 `~/.rakuish-session.log`。内存里同时保留记录，`log show` 不依赖文件。
- **不做**：日志重放、多会话合并、JSONL 结构化格式（等 `DisplayBundle`）。


**V-126**：REPL 对常见返回值做 shell 习惯的展示，而不是一律 `.raku`:

| 返回值 | 展示 |
|---|---|
| `List[IO::Path]`（`ls` / `glob` / `recent`） | basename 列表；TTY 多列，管道一行一个 |
| `CommandSpec` 列表（`help()`） | 命令名 + 摘要对齐 |
| `List[Str]`（如 `registry.names`） | 一行一个 |
| `Hash`（如 `env()`） | `KEY=VALUE`，按 key 排序 |
| `Str`（如 `read()` / `pwd()`） | 原样内容/路径，不显示 Raku 引号 |
| `Stat` | `path/type/size/mode/modified/...` 字段 |
| `WriteResult` | `wrote N bytes to PATH` |
| `IO::Path` | 路径字符串 |
| `Result` | 优先命令 stdout / stderr，回退 `text` |
| 其它 | `Out[n] = .raku` |

这些只是展示层，值本身仍是原来的类型，`.grep` / `.map` / `.value` 不受影响。

**V-127**：REPL 提供“日常 shell 观感”薄层，但**不是第二套 shell**：
支持 `cd [dir|-]` / `pwd [-L|-P]` / `clear` / `history` / `set -e|+e` /
`jobs` / `which` / `alias` / `unalias` / `config` / `hook` / `explore` /
`ls [-a -l -h -F -R -t -S -r -d]` / `cat` / `read` / `head|tail [-n N]` /
`echo [-n]` / `mkdir [-p]` / `touch` / `cp [-r]` / `mv` / `rm [-r] [-f]` /
`stat` / `export` / `unset` / `glob` / `grep [-inv]` / `wc [-lwc]`；
0.75.0 补 `doc` / `pushd` / `popd` / `dirs` / `bookmark` / `log`
（ADR-0012；`log` 是会话级命令，其余在 `Shell` 薄层）。
命令只翻译成直接 `Sys` 调用；每个命令支持 `--help` / `-?`
查看自己的用法，也支持 `help <命令>`。不支持管道、重定向、子 shell。
参数中的 `$NAME` 按会话 env 展开，`~` 展开到 `$*HOME`；带 Raku 表达式或
非字面参数的输入仍交给 Raku。实现位于 `Rakuish::REPL::Shell`，不改变底层
`Sys` / DSL API。

---

## 3.5 内核与前端（V-18x，0.76 / ADR-0013）

**V-182**：`Rakuish::Kernel` 是前端与执行之间的**唯一入口**（0.76.0）：

- 前端（TTY / 将来的 Agent、Notebook）只构造 `Request`：
  `kind`（`source` / `op`）、`payload`、`origin`（human / agent / notebook /
  script）、可选的 `policy`；执行一律走 `Kernel.execute`。
- **前端不得直接调 `Session.eval-line` / `Sys.*` / `Agent.!dispatch`**；
  `t/35-kernel.t` 对 `bin/rakuish` 做静态断言（不得出现 `.eval-line(`、
  必须出现 `kernel.execute`）。
- 0.76 只接 `source` 通道；`op` 返回 `501`（明确未实现，不伪装成空成功）。
- 拒绝也是结构化结果：`Result(:!ok, :code(403), :op<kernel>)`，
  不把策略异常穿透给前端（前端只认 `ok/code/err`）。
- **行为不变**是这一版的硬门槛：同一批样本在「直连 Session」与
  「经 Kernel」两条路径上 `ok/code/op/out/err/value` 必须逐字段相同，
  `Out[n]` 编号也必须同步（`t/35` 十个样本对账）。

**V-183**：`Policy` 由内核强制执行，**前端只能收窄**（0.76.0；0.82.0 收敛，ADR-0020）：

- 字段**只有三个**（0.82.0 起）：
  `allow-source`（内外**与**）、`root`（更窄者胜；越界直接 403）、
  `profile`（标签）。
- 0.76 的 `allow-exec` / `read-only` / `allow-ops` / `limits` **已删除**：
  全仓库没有任何执行点读取它们，留着就是「声明禁止、实际放行」的牌子
  （ADR-0019 的同一把尺子，见 V-211）。
- `profile` 只是**日志标签**（`local` / `analyst`），不参与判定 ——
  加新 profile 不该在 Kernel 里加 `when` 分支。
- `root` 的包含判断是**词法**的（绝对化 + 分隔符边界 + Windows 小写化），
  不用 `IO::Path.contains`（它按真实路径解析，路径不存在即返回 False，
  策略判定不该依赖目录存在）；符号链接逃逸仍由 `Sys.resolve` 负责（V-201）。
- 拒绝路径**不推进** `Out[n]`、不写 `@!out`（`t/35` 断言 `index` 不变）。

> `DisplayBundle`（V-184）、人机能力矩阵（V-185）、Agent 协议 v2（V-186）
> 分别随 0.77 / 0.78 落地，本版不写进验收。

---

## 3.6 Windows 控制台编码（V-187，0.76.1 / ADR-0014）

**V-187**：Windows 上进入交互前把**控制台码页**切到 UTF-8（65001），退出还原。

- **问题**：中文环境的控制台默认 936（GBK），而 Rakudo 的控制台 I/O 按 UTF-8
  解析。输入中文抛 `Malformed UTF-8`；`Terminal::LineEditor` 的字节循环
  「读到解码成功为止」，于是**一直等**（字不显示、回车不生效）。输出同样乱码。
- 实现：`Rakuish::Sys::Console`（`ensure-utf8-console` / `restore-console` /
  `console-cp` / `describe`），走 `SetConsoleCP` / `SetConsoleOutputCP`。
- **必须放在所有入口分发之前**（`-e` / 脚本 / REPL 全部覆盖），并用 `END`
  兜底还原 —— 曾经的错法是放进 `if @*ARGS { given ... }`，无参数启动（正常
  REPL）根本不进那个分支，修复等于没生效。
- **硬闸门**：只有「stdin 是终端」才切换。码页是控制台全局状态，父 shell 也
  看得见；管道 / 脚本不该改用户的终端。
- **不用 `chcp`**：那要起外部进程（与 V-604 / 沙箱边界冲突），且无法可靠还原。
- 非 Windows 一律 no-op。回归：`t/36-console-utf8.t`（平台闸门 / 无副作用 /
  入口顺序 / 管道中文）；真控制台由 `tools/tty-cjk-win.py` 自检（4 项）。

---

## 3.7 命令表与格记账（V-188 / V-189，0.77.0 / ADR-0015）

**V-188**：命令名只有一个声明处（`Shell` 的 `COMMAND-GROUPS`），其余派生。

- 分组：`shell`（`handle()` 真正分发）/ `session`（`eval-line` 早返回处理）/
  `api`（只有 Raku 侧 API、无同名文本命令）。`COMMANDS`、`SHELL-COMMANDS`、
  帮助索引的分类、Tab 补全候选、渲染层的 shell-op 名单**全部由它生成**。
- **必须保留手写、且有测试守着的两处**：`usage()` 的文案（太长，塞进数据表会
  淹没结构）；`handle()` 的 `given` 分发体（要调私有方法，无法从数据生成）。
  `t/37` 双向断言：表里每个名字都要有分支，分发表里不许有表外分支。
- **历史教训**：`hint` / `plugin` 自 0.66 起有完整 `usage`、`help hint` 可查，
  却从不在 `COMMANDS` 里 —— Tab 永远补不出来。任何「新命令要手工登记 N 处」
  的设计都会重演这个错误，所以宁可用测试守两处，也不再加第三张名单。
- 新增命令的登记点从 ~9 处降到 4 处（组声明 / 用法文案 / `OPTIONS`（仅当真有
  flag）/ 分发体）。

**V-189**：输入序与格号是两个计数，**不得共用一个写点**。

- `@!history` = 输入序：`history` 显示与 `!n` / `!!` 的编号来源。**每一行提交
  都给**：会话级命令、失败的 Raku 格、`!` 外部命令一律入册。
- `$!index` = 格号：`Out[n]` 与 `perf` 用它，只在**成功的求值/执行格**递增。
  会话级命令不占格号（否则 `Out[n]` 跳号）；失败的 Raku 格不占格号
  （既有契约，`t/07` 有断言）。
- **记账必须收口**：`eval-line` 是 `!eval-line-body`（执行）+ `!finish`（记账）
  两段。`!eval-line-body` 内有十几处 `return`，逐个补 `@!history.push` 正是
  0.77 之前漏掉一半的成因。
- 规则：空行与续行中间态（`op<more>`）不记；多行格记**完整源码**不记最后一行；
  `!!` 的外层不记（内层已记展开后的真实命令）。
- 回归：`t/37-command-table.t`（`!!` 重放上一行而非上一格、`!n` 与 `history`
  编号同源、多行格只记一条且含中间行、失败格入册但不占格号）。

---

## 3.8 展示包与 op 通道（V-184…V-186，0.78.0 / ADR-0016）

**V-184**：`Rakuish::Display::Bundle` 是结果的**内容级**展示包。

- 字段：`text`（必有，**零 ANSI**）、`markdown`（`''` = 不提供）、
  `json`（空 = 不提供；内容是**值本身**，不含 `ok`/`code`/`op` 外壳）、
  `meta`（`kind`/`ok`/`code`/`op`/`rows`/`truncated`）。
- 能力：`available` / `pick(@accepts)` / `render($fmt)`。`render` 遇到不可用
  格式**回退 `text` 而不抛** —— 展示层不该让调用方崩。
- **分工不可混**：Bundle 只管内容；颜色、`Out[n]` 标签、`COLUMNS` 分列属于
  `Session.render`（前端装饰）。把装饰塞进 Bundle 会让它退化成 TTY 专用。
- **不复制渲染逻辑**：`records`（`Positional of Hash`）先 `Table.from-rows`
  再取 `to-text` / `to-markdown`；表格对齐、单元格转义、截断提示只有一份实现。
- `kind` 取值固定为
  `error` / `text` / `table` / `records` / `paths` / `rows` / `record` /
  `scalar` / `empty`（V-185 的 `kinds` 必须与之一致）。

**V-185**：`capabilities()` 只列**真的能用**的能力。

- `Kernel.capabilities` 报 `formats` / `kinds` / `request-kinds` / `ops` /
  `profiles` / `policy-fields`；Agent 的 `capabilities` op 另报限额与开关，
  0.79.0 起再报 `protocol`（=2）/ `stream_ops` / `cancel`。
- **不写进清单的东西**：`html`（没有任何渲染路径能产出）、`execute` op
  （V-503 不变）。声明做不到的格式比不声明更糟。
- `stream_ops` 必须**只列真的会发帧的 op**（0.79.0 只有 `exec`）；
  请求里带 `stream` 但 op 不在清单内时不得发任何帧（V-192）。

**V-186**：op 通道与协议向后兼容。

- `kind => 'op'` 的载荷固定为 `payload => %(op => 'name', ...)`；
  非 Hash → `2`，缺 `op` → `2`，不做隐式转换。
- 0.78 只开 `capabilities`（不碰文件、不起进程、不执行源码）；其余 `501`
  且错误信息写明原因与计划版本。**不允许出现第二个含糊的空成功**。
- `Policy.allow-ops` **先于** 501 判定：不在名单里 → `403`。
  **0.82.0 撤销**：该字段已删（V-205 / ADR-0020）—— op 通道只剩
  `capabilities`，名字级白名单没有可挡的对象，直接按下面的 501 规则处理。
- Agent 的每条回复附加 `display`（同 V-184 形状）；请求可选 `format`。
  **附加字段不得改变既有键语义**：`ok`/`code`/`value`/`out`/`err` 一字未改，
  老客户端忽略 `display` 即可。失败回复（401/403/504/400）同样带 `display`，
  `kind` 为 `error`。
- **降级必须如实**：请求 `markdown` 而内容不支持时，`format` 必须回填
  `text` 而不是请求值，否则客户端会把纯文本当 markdown 渲染且无从查错。
- **0.81.0**：`Display::Bundle` 本身保留（本地渲染 / `-e` 输出都在用），
  但 **V-186 的「Agent 响应带 `display` 字段」随 Agent 线撤销**。

---

## 3.9 流式分帧与请求取消（V-190…V-193，0.79.0 / ADR-0017 —— **0.81.0 撤销**）

> ⚠ 本节四条（V-190…V-193）已随 Agent 协议删除，见 §6.1 与
> [ADR-0019](docs/ADR-0019-local-full-privilege-shell.md)。下文保留原文
> 作为历史记录，**当前实现不存在流式帧**。

**V-190**：**帧有且只有两种**，客户端靠 `event` 键区分。

| 行 | 形状 | 含义 |
|---|---|---|
| 中间帧 | `{"id":N,"event":"start"\|"chunk",...}` | 只在流式请求期间出现 |
| 响应行 | 与 0.78 完全相同的响应（**没有 `event` 键**） | 每个请求恰好一行 |

- `start` 帧：`id` / `op`。每个流式请求**恰好一帧**，且在第一个 `chunk` 之前。
- `chunk` 帧：`id` / `seq`（本次请求内从 0 递增、跨 fd 共用、不重号）/
  `fd`（`stdout` \| `stderr`）/ `data`（字符串）。
- 响应行附加 `streamed: true`、`chunks: N`；被取消时 `cancelled: true`；
  因超限停止发块时 `truncated: true`。**这些键只在真的发过帧时出现**。
- **不发半套帧**：`stream` 为假、op 不支持、或传输层给不出 emit 通道时，
  一律退回单帧，且不得声称 `streamed`。

**V-191**：**流式不改结果语义**。响应行里的 `out` / `value` / `code` 仍是
完整结果（与不带 `stream` 时同一个 `Handle.wait`）；流只是**多给了中间过程**。
超限时以 `max-output` 为界停止发块（不无限灌连接），已发内容不再收回。

**V-192**：`capabilities.stream_ops` 是**唯一**的流式能力声明。
0.79.0 只含 `exec`。新增可流式 op 必须先改这张表，再改实现 ——
顺序反过来就会出现「客户端发 stream 却收不到帧」。

**V-193**：`cancel` 是 op，语义边界必须如实：

- 载荷 `target`（被取消请求的 `id`）。目标不存在/已结束 → `409 cancelled=false`。
- **只有 `exec` 可取消**；其余 op 在跑时取消 → `409 cancelled=false` + 原因
  （不假装成功，也不谎称已停）。
- `exec` 已 spawn → 立即 `kill`，被取消请求以 `code=137`（128+SIGKILL）、
  `ok=false`、`cancelled=true` 收场，与 `Sys.cancel` 同一套码。
- `exec` 尚未 spawn 完（取消来得太早）→ 记 `cancel-requested`，spawn 后补杀，
  回 `cancelled=true` + `deferred=true`。
- `cancel` **不进串行执行队列**：读循环就地处理，否则它只能排在长请求后面，
  等于没取消。取消本身进审计（`stage=cancel`）。

---

## 3.10 统一审计（V-194…V-196，0.80.0 / ADR-0018）

**V-194**：`Rakuish::Audit.record` 是**唯一写入函数**。

- 字段白名单：`token` / 文件内容 / SQL 全文 / 源码全文**结构上进不来**，
  不靠调用点自觉（V-606）。源码只记 FNV-1a 指纹 + 字节数；编译错误消息
  也不记（Rakudo 常把源码片段带进消息）。
- 自动补 `seq` / `ts` / `origin`；内存 10k 条上限、JSONL 单行追加、
  10MB 轮转、跨实例锁。落盘失败只退化为内存，不影响业务。
- 新实例以现有 JSONL 行数为 `seq` 起点，多进程追加时保持连续。

**V-195**：**每次操作恰好一条**。

| 前端 | 调用点 | 覆盖 |
|---|---|---|
| 人（REPL / `-e` / 脚本） | `Kernel.execute` 的 `LEAVE` | 成功、失败、会话级命令、坏请求、策略拒绝、root 越界早返回、异常 |
| Agent（结构化 op） | `Sandbox.audit` | 成功、401 / 403 / 409、504、cancel、op 执行 |

- `Kernel` 必须用 `LEAVE`（不是末尾调用）：0.76 的
  `return $r if $denied` 会绕过末尾记账，安全事件反而漏了。
  `t/40` 用这条路径做变异护栏。
- 两个调用点可注入**同一个 Audit 实例**做双前端对账；`Sandbox.entries`
  代理到它，不再维护第二套。
- 默认开启，默认落盘 `$*HOME/.rakuish/audit.jsonl`；
  `RAKUISH_AUDIT` 覆盖路径，`RAKUISH_NO_AUDIT=1` 关闭。

**V-196**：分工与诚实边界。

- `Audit`（机器 / 安全）、`Session.log-line`（人类可读会话抄本，含渲染文本）、
  `Kernel.trail`（200 条内存调试视图）、`display`（结果内容）**四者不合并**。
- 审计是**事后可查**，不是事前阻止；本地 REPL 是同用户可信环境，
  日志文件同用户可写，**本版不防篡改**（需外部追加-only 时另立项目）。
- `execute` op 不做；Agent 默认无脚本路径见 V-607。

---

## 3.11 能力定位变更登记（0.80.1，不新增条款、不改行为）

> **0.81.0 终结**：本节登记的 `stream` / `cancel` 已随 Agent 线整体撤销
> （ADR-0019）。保留此节只为记录「这两项能力曾在 0.79.0 存在、0.79.2 被收窄、
> 0.81.0 删除」的完整链条，**不要再按本节实现或放宽 V-607** —— V-607 已撤销。

0.79.0 的 `stream` / `cancel` 作用对象是 `exec`（`STREAM-OPS = <exec>`）；
0.79.2 的 **V-607** 让 `exec` / `pty_exec` 默认 403。因此
**默认配置下 `stream` 不发任何帧、`cancel` 恒为 409**，只有显式
`--allow-code-exec --allow-exec` 启动的不安全 profile 才用得上。

这改变了两项能力的定位（默认能力 → 可选 profile 能力），不是缺陷，
也不回退 0.79.0 的实现；但此前没有任何文档标记这次变更，0.80.1 在此
补登记（`docs/ADR-INDEX.md` §3、`HANDOFF` 缺口表、`docs/MANUAL.md`）。
**若要恢复默认流式，须先决定 V-607 是否放宽并另开 ADR。**

---

## 3.12 本机全权限（V-197…V-199，0.81.0 / ADR-0019）

**V-197**：Rakuish 是**单入口、全权限**的本地 shell。

- 唯一入口 `bin/rakuish`；REPL / `-e` / 脚本三种模式共用同一个 `Kernel`（V-182）。
- **没有 Agent 协议**：无 JSONL / TCP / token / op 白名单 / `--agent` 转发
  （0.81.0 删除，见 §6.1）。
- **没有沙箱**：`Rakuish::Sandbox` 已删除；不存在 `--root`（除非测试或用户显式
  给 `Sys.new(:root(...))` 做工作目录限定）。

**V-198**：**不设权限闸门**，且不保留「默认关闭 + 开关打开」的形态。

- Raku 源码直接 `EVAL`，不需要 pragma；`!` 直接 `Sys.exec` 起进程。
- **不存在** `allow-exec` / `allowlist` / `allow-code-exec` / `allow-sql` 这类开关。
  删掉而不是默认关：留一个默认关闭的开关，等于承认「打开就安全」，那正是
  ADR-0018 / ADR-0019 反复否掉的「牌子」。
- 注：0.81.0 时 `Policy` 上还留着 `allow-exec` / `read-only` 两个**无执行点**
  的字段（声明禁止、实际放行），0.82.0 已按 V-211 删除。
- 因而 V-503（无 eval op）与 V-604 / V-607（exec 白名单、代码执行闸门）
  失去适用对象，已撤销（见 §6.1）。

**V-199**：**唯一保留的越界检查是防误操作，不是安全边界。**

| 检查 | 行为 | 定位 |
|---|---|---|
| `Sys.resolve` 工作目录边界 | 越出会话 root 抛 `X::Rakuish::Bound` | 防手滑；root 默认 `/`（Windows 当前盘根 + all-drives），此时恒真 |
| 路径层级过深 | 抛 `X::Rakuish::Bound` | 防病态路径 |
| 拒绝删除文件系统根 / 会话 root | 抛 `X::Rakuish::Bound` | 防灾难性误操作 |

`X::Rakuish::Bound` 原名 `X::Rakuish::Sandbox`，0.81.0 改名 —— 全权限之后
再叫 Sandbox 就是误导。**这三条都不构成安全隔离**：同一用户能做的事，
Rakuish 里都能做，这是设计目标而不是缺口。

**V-211**：**一个策略字段要么有执行点，要么不许存在**（0.82.0 / ADR-0020）。

- 判据：`Policy` 的每个字段必须在 `lib/` 里至少有一处**判定语句**读取它，
  且该判定能改变 `Result`（拒绝 / 收窄 / 越界 403）。
- 做不到就不要加字段。需要「记录意图」时用 `profile` 标签，
  不要用布尔开关 —— 布尔开关会被读成保护承诺。
- 推论：`allow-exec` / `read-only` / `allow-ops` / `limits` 已于 0.82.0 删除；
  `capabilities.policy-fields` 只报 `<profile allow-source root>`。
- 护栏：`t/35` 用 `^can` 断言这四个方法**不存在**。不用「值为 False」——
  字段被加回来且默认为假值时那种断言仍然通过，等于没有护栏。

---

## 3.13 求值引擎子进程（V-212…V-216、V-226…V-228，0.83.0 / 0.87.0 / 0.88.0 / 0.89.0 / ADR-0021）

**V-212**：**交互式 REPL 的 `EVAL` 跑在 `raku` 子进程里**（0.83.0）。

- 父进程（`bin/rakuish`）保留行编辑、prompt、banner、渲染输出与审计；
  引擎子进程持有 `REPL::Session` 的全部求值状态（`%STATE` / `@decls` /
  `Out[n]` / `Sys` / Shell / 内建命令）。
- 理由：同进程 `EVAL` 下，用户代码 `exit`、段错误、`while 1 {}` 三条都会
  带走整个 REPL，且第三条**无法**用 SIGINT 打断（本版实测）。
- `Kernel` 与审计**不感知**这层：`Rakuish::Eval::Proxy` 冒充
  `REPL::Session`，`Kernel.execute` 的实现一行未改（V-182 不变）。
- 模块：`Rakuish::Eval::Server`（子进程入口）/ `Rakuish::Eval`（Client）/
  `Rakuish::Eval::Proxy`（门面）。

**V-213**：协议是**一行一个 JSON、串行请求/响应**。

- 所有帧强制 `:!pretty`。`JSON::Fast` 的 `to-json` 默认会输出多行，
  按行切帧会把一帧切成多条残缺 JSON —— `t/41` 有专门断言。
- 同一时刻只有一条请求在飞；`seq` 必须对齐，不做并发、不做多路复用。
- 响应里的 `text` 是引擎**渲染好的最终文本**（含 `Out[n]` 与颜色）；
  父进程不二次渲染，也不接收 Raku 值对象。
- 用户代码的 stdout 进 `out` 字段（`CapturingOut`），**不混进协议流**；
  `$*ERR` 走子进程 stderr，父进程原样转发。

**V-214**：**崩溃是失败结果，不假装成功**。

- 引擎退出 ⇒ 请求抛 `X::Rakuish::Eval::Dead` ⇒ `Proxy` 重启一次 ⇒ 返回
  `Result(:!ok, :code(500), :op<engine-restart>)`。
- 结果文本**必须**同时说明「已自动重启」与「会话状态已丢失」两件事，
  缺一件就是误导（`t/41` 两条独立断言）。
- 重启成功后 `Out[n]` 从 1 重新开始；`%STATE` / `@decls` / 数据引擎连接
  全部丢失。**不做状态恢复** —— 让它看起来没丢等于骗用户。
- 崩溃的那一格仍被审计记一条（`LEAVE` 在 `Kernel.execute` 里，与引擎死活无关）。

**V-215**：`! --tty` **交回父进程执行**。

- 引擎的 stdio 是协议管道，`Sys.tty-exec` 在里面只能报「无 TTY」。
  `Session` 通过 `&tty-handler` 注入点把 `(exe, argv)` 交给父进程。
  0.144.0 起 `&pipe-handler` 同构地承接 `! --tty a | b` 的整条管道（V-348）。
- 父进程用自己的 `Sys`（真终端、cwd 与引擎同步）执行，结果经 `resume`
  帧回传；引擎继续走原来的 `!remember` / `strict-result` 流程。
- argv 仍是数组，不拼 shell 字符串（V-153 / ADR-0001 不变）。
- 未注册执行器时必须**明确失败**（`127` + 说明），不能静默当成功。
- 回归：`t/30`（POSIX 真 PTY）+ `tools/ctrl-c-win.py` 的场景二（Windows
  真 ConPTY，0.87.0 补齐）。两者都验：子进程收到 SIGINT 并退出、
  宿主 REPL 未被带走、交接后 prompt 回来且能继续求值。

**V-216**：**只有 TTY 交互 REPL 走 worker**。

- `-e` / 脚本 / 管道保持进程内 `Session`：它们没有「会话要继续」这回事，
  崩了就崩了，多一层进程只是多一处出错点。
- 分流依据是 `$*IN.t`；管道模式的输出契约（V-116：stdout 只有求值结果）
  不受影响。
- 求值中的硬中断由 0.85.0 补上（V-221…V-224），本节该条已作废。

**V-226**：**真实终端是不是 TTY，由入口注入，引擎不许自己探测**（0.87.0）。

- 引擎子进程的 `$*IN` / `$*OUT` 是**协议管道**，`.t` 恒为 False。任何
  「在引擎里问 `$*OUT.t`」的判定都会得到错误结论，且错得很安静。
- `Session.tty` / `Shell.tty` 是会话属性，入口经协议每格推送
  （`Client.eval(:tty)` → Server → `set-tty`）。`set-tty` 必须**同时**
  同步 Shell：只改 Session 会出现「路径列表彩色、`ls -l` 无色」的半截状态。
- 已知曾因此退化的行为：`clear` 静默不输出（0.83 起，0.87.0 修复）；
  shell 彩色全灭；多列 `ls` 退化成单列。回归见 `t/10`、`t/41`。
- 管道 / `-e` / 脚本仍是进程内 `Session`，其 `tty` 由自己的 `$*OUT.t` 判定，
  输出契约（V-116）不变。

**V-227**：**终端尺寸与 TTY 同源，也必须由入口下发**（0.88.0）。

- `Session.width` / `Session.height` / `Shell.width` / `Shell.height`，
  经 `Client.eval(:width, :height)` 每格推送；`0` 表示未知，**不覆盖**已知值。
- 取数来源是**问终端**，不是读环境：POSIX `ioctl(TIOCGWINSZ)`（stdout，
  失败再用 stderr），Windows `GetConsoleScreenBufferInfo`。
- `%*ENV<COLUMNS>` 只作最后兜底：它是 shell 变量，bash 只在交互式 shell
  里赋值且默认不导出，`resize` 之后还会陈旧。实测过的错误：40 列终端里
  `ls` 按 80 列排出 76 字符宽的行。
- 未知宽度时排版回落 80 列 —— 这是**渲染策略**，所以放在 Session，
  不放在 `Rakuish::Sys::Term`（后者只回答事实，不知道默认值该是多少）。
- 已知未覆盖：不做 SIGWINCH 订阅（每格查一次已足够，ioctl 是微秒级）；
  `COLUMNS` 若被用户显式覆盖，仍以真实终端为准。
- `height` 的执行点是分页器每页行数（`pager-page-size` = 高度 − 2，
  未知时 20）。**没有执行点的字段不许留**（V-211 的同一把尺子）。

**V-228**：`tty` 与 `live-out` 是**两件事**，混用会写进协议流（0.89.0）。

| 谓词 | 含义 | 用于 |
|---|---|---|
| `tty` | 用户面前有终端（前端下发） | 排版：颜色、列数、`clear` 的 ANSI |
| `live-out` | **本进程的 stdout 就是那个终端**（`$*OUT.t`） | 分页、逐行流式输出 |

- 引擎子进程里 `live-out` 恒 False（stdout 是协议管道），`tty` 可以 True。
- 分页器（`explore`）与 `ls -R` 的流式分支必须判 `live-out`：
  它们要往真 stdout 写、再读真 stdin。
- **0.87 的实测事故**：`tty` 注入后这两处改判 `tty`，于是引擎里的分页器把
  表格文本插进 JSON 协议流、又把父进程的下一个请求当「按键」吃掉 ——
  REPL 直接卡死（`explore` 一个大表即可复现，见 `t/41` ⑧⑨）。
- 推论：**「能写到终端」不等于「用户能看见终端」**。凡是涉及 fd 的副作用，
  都要问 fd 本身，而不是问前端下发的意图。

---

## 3.14 会话快照（V-217…V-220，0.84.0 / ADR-0022）

**V-217**：引擎在**每次成功格之后**写一份会话快照（0.84.0）。

- 内容只有两样：`%!state`（跨格变量的纯值）与 `@!decls`（纯声明源码）。
- **只在成功格后写**：失败格没有改变可持久状态，写了会冲掉上一份好快照。
- **语句格不重放**：副作用不幂等（`write(...)` / `! rm` 会执行第二次）。
- 覆盖路径：`RAKUISH_SNAPSHOT=<path>` → `$*HOME/.rakuish/session-<cwd指纹>.json`
  → 空（纯内存）。`RAKUISH_NO_SNAPSHOT=1` 同时关闭**读与写**。

**V-218**：可序列化边界是**三类判定**，不是「能/不能」。

- 纯值（标量 / 集合 / DateTime / IO::Path / 枚举 / 属性可序列化的类实例）：
  存 `.raku`，恢复时 `EVAL`。实测 14/14 常见类型往返成功。
- **资源**（`Proc` / `IO::Handle` / `IO::Socket` / `Supply` / `Channel` /
  `Promise` / `Lock` / `DB::*` / `Rakuish::Data::Engine::*`）：**标记失效**。
  它们能「恢复成功」但语义是全新对象（`DB::SQLite.new(...)` 重连空库），
  静默的错误状态比崩溃更难查。
- **闭包 / Code**：标记失效（无反序列化）。
- 单值 `.raku` 超过上限标记失效，避免每格写几十 MB。上限**可配置**
  （0.87.0）：`RAKUISH_SNAPSHOT_MAX` 为字符数，`0` / `off` / `none` /
  `unlimited` 表示不限制；未设置时默认 `1_000_000`。
  **非法值（负数、非数字）回落到默认**，不许把「写错了」解释成「关掉保护」。
- `classify()` 本身是纯函数（`:max` 由 `capture` 传入），不读环境 ——
  谁读环境，谁就没法被单测稳定覆盖。

**V-219**：恢复是**显式发起**的，且必须如实报告。

- 只有 `Eval::Proxy` 的崩溃重启路径发 `restore` 命令；正常启动不自动恢复。
- 摘要必须同时给出：恢复的声明数、变量数、**失效变量名列表**。
- 恢复失败时（无快照 / 版本不符）仍走「会话状态已丢失」，**不假装恢复过**。
- 失效变量置为 `Any`（未定义），不是「保留一个旧值」。
- 引用别名（`my $a := $b`）恢复为两个独立拷贝；不承诺引用语义。

**V-220**：快照格式**不迁移**。

- `snapshot-version` 不符时整体忽略（当作没有快照），不猜字段、不做转换。
- 坏 JSON / 不可读文件一律返回空 Hash，启动流程不被它挡住。
- POSIX 上文件权限收紧到 `0600`；**不承诺**防住同用户进程 ——
  要更严格用 `RAKUISH_NO_SNAPSHOT=1`。

---

## 3.15 求值期间的中断（V-221…V-224，0.85.0 / ADR-0023）

**V-221**：`Eval::Client` 在**等待响应期间**接管 SIGINT（0.85.0）。

- 不在求值时，handler 什么都不做，Ctrl-C 仍归行编辑器（输入中断 / 清续行）。
- 在求值时，handler 标记 `interrupted` 并**主动 kill 引擎**（SIGKILL）。
  不依赖「终端信号恰好也打到 worker」这个巧合 —— 同组只是当前现状。
- 引擎死 ⇒ `receive` 抛 ⇒ 标记为真则抛 `X::Rakuish::Eval::Interrupted`
  （与 `Dead` 分开的异常类）。
- 引擎**不能**自己处理：SIGINT 打不断 `while 1 { }`（MoarVM 不在纯 VM
  循环里检查信号，实测）。

**V-222**：中断与崩溃**必须分开归因**。

| 情形 | `op` | `code` | 文案 |
|---|---|---|---|
| 用户 Ctrl-C | `interrupted` | `130`（128+SIGINT） | 「已中断当前求值（Ctrl-C）」 |
| 引擎自己退出 | `engine-restart` | `500` | 「引擎进程已退出（…）」 |

- 中断**不许**说「引擎进程已退出」——会让用户以为出故障；
  崩溃**不许**说「已中断」——那是掩盖故障。
- 中断的那一格不产生 `Out[n]`，但 `perf` 记录其耗时。

**V-223**：中断后的恢复与崩溃**共用同一条路径**。

- 引擎重启 → 从快照恢复声明与纯值（V-217…V-220）→ 报告恢复摘要。
- 快照是上一格成功时写的，正好是「中断前那一刻」的状态。
- 重启失败时仍报 `op=interrupted` / `code=130`，但文案说明重启失败。

**V-224**：前端必须**消费**行编辑器的 `take-interrupt` 标志。

- 求值期间的 SIGINT 会让行编辑器也记一个标志；不清理的话，它会在**下一轮**
  被当成「输入中断」执行 `next`，吞掉用户输入的下一格。
- 条件：仅当结果 `op=interrupted` 时消费，其余情况保持既有语义（V-168）。

**V-225**：中断契约必须有一层**真终端**验收，不能只有单测（0.86.0）。

- 位置：`tools/ctrl-c-posix.py`（真 PTY）/ `tools/ctrl-c-win.py`（真 ConPTY）。
- 两者的步骤与断言名**保持一致**，便于跨平台比对：
  `ready` / `baseline` / `control_input_intr` / `control_no_eval_intr` /
  `cell_started` / `spinning` / `alive_after_ctrlc` / `says_interrupted` /
  `says_crashed` / `says_input_intr` / `prompt_back` / `state_survived`。
- **两条必备的反假绿措施**：
  1. 用 `note 'SPIN'` 作门闩，看到它才发 Ctrl-C —— 否则测到的是输入中断；
  2. 不在求值时先按一次 Ctrl-C 作对照，必须得到「已中断当前输入」。
- 由 `tools/ci.sh` 的 `console` 层执行：退出码 0 = pass，2 = skip（环境不具备），
  其余 = FAIL。`skip` **不算通过**，报告里单独一行可见。
- 单测（`t/43`）与真终端层**不是替代关系**：前者验 handler 逻辑与归因字段，
  后者验「`\x03` 到底会不会变成信号」。

**平台**：Linux / WSL 与 **Windows 真控制台（ConPTY）** 均已验证（0.86.0）。

- 单测层：`t/43` 18 断言（POSIX 用 `kill -INT` 触发父进程 handler；
  Windows 用不了 `kill`，skip 12 条）。
- 真终端层：`tools/ctrl-c-posix.py` / `tools/ctrl-c-win.py`，在真 PTY / 真
  ConPTY 里敲 `note 'SPIN'; loop { }` 再按 Ctrl-C，断言四件事：
  归因是「已中断当前求值」、`code=130`、REPL 存活、`$keep` 经快照恢复。
- 两侧都带**对照**：不在求值时按 Ctrl-C 必须是「已中断当前输入」——
  没有这一步，「出现『已中断当前求值』」可能只是文案恒真。
- 两个探针由 `tools/ci.sh` 的 `console` 层调用，退出码 2（无控制台且无
  winpty）记 `skip`，其余非 0 记 FAIL。

Windows 上的注意点（实测，写在这里省一次排查）：`\x03` 只有在控制台输入
模式为 cooked 时才会变成 `CTRL_C_EVENT`。行编辑器在 `prompt` 返回时恢复
模式，所以「求值中」这个窗口里是对的；但探针若在格子还没开始时就发
`\x03`，会落到行编辑器手里、表现为「输入中断」——这是**假阴性**，
不是平台不支持。

---

## 3.16 `!` 的流式输出与超时（V-229…V-231，0.90.0 / ADR-0024）

**V-229**：**外命令的输出默认在终端里边跑边出**，但「是不是终端」由入口判。

| 形态 | 行为 |
|---|---|
| 交互式 REPL（父进程 stdout 是终端） | 引擎发 `chunk` 帧，父进程立刻写 stdout / stderr |
| `-e` / 脚本 / 管道 | 流式关闭，保持 0.89 的「收完再显示」 |

- 判据是**父进程**的 stdout 是否终端（`$*OUT.t`），不是引擎的 `live-out`
  （引擎恒 False）也不是 `tty`（那是排版意图）。
- 引擎不得直接打印：它的 stdout 是协议流。块只能走 `chunk` 帧。
- `chunk` 帧带 `seq`；父进程只接受当前请求的块，stale 块丢弃。
- 块边界是**读到的字节块**，不是行、不是字符边界；实现不得假设对齐。

**V-230**：`!` 的分发层新增三个元选项，语义固定。

| 写法 | 含义 |
|---|---|
| `! --capture cmd ...` | 强制不流式，输出回到 `Result.out`（0.89 行为） |
| `! --timeout-ms N cmd ...` | 本次超时 N 毫秒；`0` = 不超时 |
| `! --no-timeout cmd ...` | 等价于 `--timeout-ms 0` |
| `! --` | 之后的 token 全部按字面 argv，不再解析元选项 |

- 非数字 / 负数 / 缺参数的 `--timeout-ms` 返回 `code=127` 并给明确错误，
  **不许**静默回落到默认。
- 元选项属于 rakuish 分发层；子进程收到的仍然只有 argv 数组（V-901 不松动）。

**V-231**：流式结果必须**不重放**。

- `Result.streamed` 为真时，`out` / `err` 清空（启动失败除外：此时没有块，
  错误必须保留），`Session.render` 跳过 `out`。
- 超时（`code=124`）与非零退出不影响归因；`code` 原样保留。
- 引擎终帧必须带 `streamed` 布尔；父进程不得根据「out 为空」猜。

---

## 3.17 启动层：rc / prompt / 选项（V-232…V-236，0.90.0 / ADR-0025）

**V-232**：交互式 REPL 启动时执行**一个**启动文件。

- 路径优先级：`RAKUISH_RC=<path>` → `$*HOME/.rakuish/rc.raku`；不存在就跳过。
  **不读 `~/.rakuishrc`**（v2 的 KEY=VALUE 配置，格式不兼容）。
- `RAKUISH_NO_RC=1` 关闭（任意非空值）。`-e` / 脚本 / 管道**不执行** rc：
  它们必须可重复，不受用户 HOME 影响。
- rc 由**引擎**执行（声明 / alias / 选项 / prompt 都在引擎里），父进程只
  解析路径并显示输出。
- **逐行喂给 `eval-line`**，续行缓冲由 Session 持有；rc 写完后执行续行
  缓冲必须为空，否则报「文件结束时仍有未闭合结构」。
- rc 的格**不占** `Out[n]` / `history` / `perf`：执行完把 `index` 归零、
  三个历史容器清空；`exit` 请求也一并复位。状态（变量 / 声明 / alias /
  cwd / env / 选项）保留。

**V-233**：rc 的错误**如实上报、不阻断后续行**。

- 失败行计入 `failed`，错误文本带 `<path>:<行号>:` 前缀。
- 一行失败不终止整份 rc（shell 的 source 语义）；只有未闭合结构在文件末尾
  单独报一次。
- 崩溃重启后 **rc 重新执行**（不是从快照恢复）：它定义的是会话策略，
  重放一次才符合 shell 语义。重启摘要必须说明这件事。

**V-234**：`repl.prompt` 是可编程 prompt，返回值就是完整 prompt。

- 类型是 Callable，签名无参、返回 Str（`Nil` / 未定义视为空）。
- **每次取 prompt 都重新调用**：时间 / git 这类信息必须是当下的。
- 函数里写到 `$*OUT` / `$*ERR` 的内容被吞掉，不污染结果流 / 协议流。
- 异常返回空串，前端回退默认样式 —— 坏 prompt 不能让 REPL 无法输入。
- 返回值中的换行压成空格（行编辑器按行算光标）。
- **续行期间不调用**：续行固定用默认的 `···`，否则用户分不清是否在续行。
- 引擎经 `prompt` 命令返回；父进程每格问一次。

**V-235**：`set` 是选项系统，不是字符串开关。

| 选项 | 默认 | 执行点 |
|---|---|---|
| `errexit` | off | 失败格请求退出（`set -e` 的别名） |
| `histexpand` | on | 是否认整行 `!!` / `!$` / `!n` |
| `noglob` | off | Shell 薄层不展开 `* ?`（`glob` 命令不受影响） |
| `noexpand` | off | Shell 薄层不展开 `$NAME` / `~` |
| `xtrace` | off | 求值前把 `+ <源码>` 写到 stderr |

- `set` / `set -o` 列出全部；`set -o NAME` 开、`set +o NAME` 关。
- 未知选项返回失败并列出可用名字，**不静默接受**。
- 选项只在会话内有效；要跨会话就写进 rc（rc 会在重启后重跑）。

**V-236**：每个选项必须有执行点；没有执行点的键不许进表（V-211 同一把尺子）。

- `noglob` / `noexpand` 由 Session 同步到 Shell 薄层；Shell 不另存一份配置。
- `xtrace` 走 stderr，不进 `Result.out` / `Out[n]`；rc 里开启后，后续 rc 行
  也会被 trace。
- `histexpand` 关闭后 `!!` 落回外部命令（通常 `code=127`），这是显式结果，
  不是「静默退化」。

---

## 3.18 结构化管道（V-237…V-244，0.91.0 / ADR-0026）

**V-237**：`stream(...)` 是结构化管道的**唯一入口**，返回
`Rakuish::Data::Stream`（惰性 `Seq` of `Hash`）。

| 入参 | 行为 |
|---|---|
| `Str` | 按 `:format` 解析，默认 `lines` |
| `IO::Path` | 读文件后同 `Str`（文件不存在抛 `X::Rakuish::NotFound`） |
| `Result` | 取 `out` 按行；**失败 Result 抛 `X::Rakuish::CommandFailed`** |
| `Table` | 逐行展开 |
| `Cursor` | 真惰性；标记为一次性（V-240） |
| `Positional` | 元素是 Hash 就展开，否则包成 `value` 列 |
| `Hash` | 单行 |

- `:format` 取值固定六种：`lines` / `csv` / `tsv` / `json` / `jsonl` / `pattern`；
  其它值抛 `X::Rakuish::Unsupported`，**不静默回落 lines**。
- `pattern` 必须给 `:pattern`（Regex），否则抛 `X::Rakuish::Unsupported`。
- `json` 只接受对象数组；`jsonl` 逐行解析，坏行报出**行号**。
- 抛出的 `CommandFailed` 必须同时带 `:detail`：`X::Rakuish::V3` 族的 `detail`
  是 required 属性，只给 `:result` 会变成 `X::Attribute::Required`（实测）。

**V-238**：文本解析的**列顺序由解析器给出**，不依赖 Hash 键顺序。

- `lines` 的列是 `n, line`（行号从 1 起）；`csv` 用表头顺序（复用
  `Rakuish::Data::from-csv-data`，不写第二份引号状态机）；`tsv` 同理；
  `pattern` 是 `n` + 给定 `:names`，不给名字时用 `c0 / c1…` 与正则具名捕获。
- 列顺序错了会直接体现在 `select` / `to-text` 上，所以这条是契约不是实现细节。

**V-239**：惰性边界必须写明，不许假装。

- 惰性：`where` / `select` / `drop` / `map` / `add-column` / `limit` / `skip`。
- 物化：`sort-by` / `unique` / `count-by` / `group-by`（排序 / 去重 / 分组本来
  就要看完全部记录）。
- 断言方式：上游是生成器时，`limit(3).count` 只允许拉 3 行（`t/46` 用计数器守）。

**V-240**：一次性来源只能消费一次。

- `repeatable=False` 的流（Cursor / 进程通道）第二次取会抛 `X::Rakuish::Data`，
  错误信息要指回来源；**不许**返回空流（空流会被误读成「没有数据」）。
- 文本 / Table / List 来源可重复消费；`$!taken` 只在 `repeatable` 为假时生效。

**V-241**：数字口径。`sum` / `mean` / `min` / `max` 先收 `Numeric`，再收
字面量数字字符串 `/^ '-'? \d+ [ '.' \d+ ]? $/`；不做进制 / 千分位 /
科学计数法（那些归数据引擎）。

**V-242**：`.exec($exe, *@args, :format<lines|csv|tsv|json>, :column)` 把记录写成
子进程 **stdin**，返回 `Result`。

- 必须走 `$*RAKUISH-SYS` 的 `Sys.exec`（cwd / env / 超时 / 审计与 `!` 同一条路）；
  没有会话上下文时抛 `X::Rakuish::Unsupported`，**不许**自己起进程绕过审计。
- `:format<lines>` 取 `:column` 或第一列，每行一个值；`csv` / `tsv` / `json`
  使用对应序列化（CSV 复用 `Table.csv-line`）。
- 子进程的 stdout/stderr 仍是 `Result.out` / `Result.err`，可以再喂给 `stream`。
- 0.93 起 stdin 是**流式**写的（见 §3.20），不再先把整份文本物化。

**V-243**：**Raku 表达式侧不新增管道语法**。

- `|` / `>` / `&&` / `$?` 仍属 V-901「永不支持」——唯一例外是 `!` 行的
  顶层 `|`（0.143.0，V-347），它不经 Raku 语法、只做进程串联。
- `|>` 在 Raku 语法里不可定义（实测 `sub infix:<|>` 报
  "Preceding context expects a term, but found infix >"），因此不作为候选。
- 管道 = 方法链；`==>` 是原生 feed（左值作为**最后一个**参数），可用于把流喂给
  自定义阶段 sub。

**V-244**：展示只有一套排版。

- `Session.render` 与 `Display.bundle-from` 遇到 Stream 一律先 `.table`，再走
  现有 Table 渲染 / 序列化；不许为流写第二套表格。
- 展示会消费一次流；一次性来源展示后再取按 V-240 报错。

---

## 3.19 前端分页（V-245…V-249，0.92.0 / ADR-0027）

**V-245**：交互式 REPL 的分页在**父进程**执行。

- 引擎只把整份文本放进 `Result.out`（0.89 起的既有契约），**不判断是否分页**，
  也不得把页面写到终端 —— 它的 stdout 是协议流（0.87 事故的根因）。
- 父进程每格取一次 `term-size()` 的 rows，每页行数 = rows − 2（至少 1）。
- 读「下一页」用真 stdin 的一行；读之前必须 flush 输出，否则观感是「卡住」。

**V-246**：`RAKUISH_PAGER` 有三档，每格读一次。

| 值 | 行为 |
|---|---|
| `auto`（默认 / 空值 / 未知值） | 只对 `explore`，且超过一页 |
| `always`（`on` / `1` / `yes`） | 任何超过一页的结果 |
| `never`（`off` / `0` / `no`） | 不分页 |

- 未知值**回落 auto**，不许回落 always：写错环境变量不该改变 `cat` 的行为。
- 非 TTY（管道 / `-e` / 脚本 / 重定向）一律不分页。

**V-247**：分页器只切页，策略与执行分离。

- `Pager.paginate($text, &read, &emit, :size)` 不碰 `$*IN` / `$*OUT`：读一行、
  写一行都由调用方注入，因此分支可单测。
- `Pager.wants-page(:op, :lines, :height, :mode, :tty)` 是纯函数，同一条策略
  不许在入口与测试里各写一份。

**V-248**：一页装得下时的行为，两条路径相反且都必须成立。

- `paginate`：返回 False 且**一个字节都不写**，调用方走原来的打印路径
  （没有分页的格在观感与测试里完全不变）。
- `page`（进程内、已接管输出）：交互路径下**必须打印**，哪怕只有一行 ——
  否则 `explore` 小文件会静默无输出（0.92 开发中漏过一次）。

**V-249**：分页期间的输入语义。

- `q` / `Q` / `quit` → 停止，剩余页不打印；其它任意输入（含空行）→ 下一页。
- 读键被中断（Ctrl-C）或遇到 EOF → 按 EOF 处理：停在当前页，异常不得抛进主循环。
- 不提供「上一页」/ 搜索 / 全屏备用屏。

---

## 3.20 流式 stdin（V-250…V-254，0.93.0 / ADR-0028）

**V-250**：`Sys::Proc.spawn` 接受 `:&in-chunks`（Callable → Iterable），与
`:in` **互斥**；同时给两个抛 `X::Rakuish::Unsupported`，不静默挑一个。

- 写入方每块 `await $proc.write(...)`：**这就是背压**，子进程不读则生成器不前进。
- 缓冲到 16 KiB 再写；循环结束后**必须**写出最后不足一块的尾巴。
- 子进程提前关闭 stdin 时立刻停止 pull；不得把剩下的流跑完。

**V-251**：两种「停下来」必须分开报告，且都不许抛。

| 现象 | 字段 |
|---|---|
| 子进程先关 stdin（`head -1` / `grep -q` / 自身崩溃） | `Result.value<in-early>` |
| 生成器自己抛（解析失败 / 一次性来源二次消费） | `Result.value<feed-error>`（带原始消息） |

`Handle.wait` 在生成 `Result` 前等喂入任务收尾（上限 2 s），否则这两个字段是
竞态产物。

**V-252**：`Stream.exec` 必须把**生成器**交给 `Sys.exec`，不得先物化。

- `lines` 取 `:column` 或第一列，每行一个值 + `\n`；`csv` / `tsv` 出表头再逐行，
  转义复用 `Table.csv-cell` / `csv-line`（**不写第二份引号规则**）。
- `json` 自己拼 `[` … `]`，元素单独序列化且紧凑（`:!pretty`）；**键序不作承诺**
  （Raku 的 Hash 没有插入序），只保证 JSON 语义等价。
- `:format` 只接受 `lines` / `csv` / `tsv` / `json`，其它值抛
  `X::Rakuish::Unsupported`，不回落 `lines`。

**V-253**：一次性来源的二次消费必须在 **`exec` 调用点**同步抛出
`X::Rakuish::Data`，不得退化成 `feed-error` + 子进程收到空输入（V-240）。

- 实现方式：`exec` 先 `self!seq` 取一次 Seq（只建不拉），再把这个 Seq 交给
  生成器，避免后台线程里才第一次取。

**V-254**：喂 stdin 不吃 `max-bytes`（那是限制子进程输出的）；`:timeout-ms`
仍作用于整个子进程，超时 cancel 之后写入方因 broken pipe 自然停止，不额外报错。

---

## 3.21 两条流：zip / join / tee（V-255…V-260，0.94.0 / ADR-0029）

**V-255**：`Stream.zip($other, :$suffix, :$longest)` 按**位置**配对。

- 默认取较短的一条（与 Raku 的 `Z` 一致）；`:longest` 补齐，缺的一侧留空。
- 右列与左列重名时加 `:suffix`（默认 `_right`）；不冲突不改名。
- 两侧都有列元数据时，结果列顺序 = 左列 + 右列；否则留给 `.table` 推断。
- `$other` 可以是 `Stream` / `Table` / 记录列表（`Positional` of `Hash`）。

**V-256**：`Stream.join($other, :$on | :$left-on/:$right-on, :$how, :$suffix)`
是 hash join：**右表物化**、左表流式。

- `:how` 取值 `inner` / `left` / `right` / `outer`，**默认 `left`** ——
  与 `Table.join` 的历史行为一致；两个同名 API 不允许有两个默认值。
- 一对多出笛卡尔积；`right` / `outer` 在左表耗尽后补出右表的未匹配行。
- 键比较 `(值 // '').Str`：CSV 的 `"1"` 与 `1` 必须能对上；缺失当空串。
- 右表只物化**一次**（不是每来一条左行重建索引），`t/49` 用计数器守。

**V-257**：列合并规则只有一份实现 —— `Table.join-columns`（纯函数）。

- 左列在前、右列其次、重名右列加 `:suffix`，**不丢列**。
- `Table.join` / `Stream.join` / `Stream.zip` 三处都调它，不许各写一套后缀规则。
- 右表没有列元数据（json 来源 / `map` 之后 / 行列表）时**右列统一加后缀**：
  判断不了冲突时宁可多改，也不让右值覆盖左值。

**V-258**：`Stream.tee($path, :$format, :$column, :$append)` 是 Unix `tee`：
写一份副本并照常把行送下去。

- **不是** fan-out（不把一条流同时喂给两个消费者）。
- 路径经 `$*RAKUISH-SYS.resolve` 解析（root 约束同 `!` / `save`）；无会话时抛
  `X::Rakuish::Unsupported`。
- 格式与 `Stream.exec` **共用** `!fmt-head` / `!fmt-row`：`:format<csv>` 的字节
  与 `.csv` 一致（含引号转义）。
- `:append` 用 `open(:a)`（`:w` 会截断），且**不重写表头**。
- 写多少取决于下游读多少：`limit` 放在 tee **上游**才会得到「正好 N 行且已 close」
  的文件；放在下游会留下半截未关闭的文件（手册写明）。
- 结果恒为一次性（有副作用）。

**V-259**：入参错误必须当场抛，不许猜。

- `join` 缺 `:on`（且未同时给 `:left-on` / `:right-on`）→ `X::Rakuish::Unsupported`。
- `:how` / `:format` 取值非法 → `X::Rakuish::Unsupported`。
- `$other` 不是 `Stream` / `Table` / 记录列表 → `X::Rakuish::Unsupported`。
- 路径越出 root → `X::Rakuish::Bound`（与 `Sys.resolve` 同一道门）。

**V-260**：`repeatable` 取两侧的与。

- 任一侧是一次性来源（游标 / 进程通道）→ 结果一次性；`tee` 恒一次性。
- 第二次消费给出「已经读过一次」，不得静默重写文件或返回空流（V-240 的延伸）。

---

## 3.22 按顺序收拢两条流：interleave / append（V-261…V-264，0.95.0 / ADR-0030）

**V-261**：`Stream.interleave($other, :$shortest = False)` 按**位置**交替取
左1、右1、左2、右2……（round-robin，不是 zip 的配对）。

- 默认**吐完长侧**：一方耗尽后继续把另一方剩余吐完（收拢不是配对，不丢记录）；
  `:shortest` 才在任一侧耗尽时停。这是与 V-255 `zip` 默认取短的分界。
- 完全惰性：每轮两侧各 `pull-one` 一行；短侧耗尽后继续 pull 靠 `IterationEnd`
  的幂等性跳过。
- `$other` 可以是 `Stream` / `Table` / 记录列表（`Positional` of `Hash`）。

**V-262**：`Stream.append($other)` 先吐完左流再吐右流（Unix `cat` 对同构流）。

- 完全惰性，且左流耗尽之前**不碰**右流：`!rows-of($other)` 在左侧循环之后才
  调用。一次性右来源若被提前标记已消费，`limit` 左流就会无故毁掉右流。
- 列元数据取左侧，左侧未知（json / `map` 之后）才取右侧；**不取并集** ——
  异构流并集会让「接错流」隐形，沿用左列则让右侧多出的列显成缺值。

**V-263**：两个动作都**不改行、不改名**，与 `zip` 的合成一行分道扬镳。

- `zip` 合成一行 → 同名列加 `_right`（`Table.join-columns`）。
- `interleave` / `append` 每行保持原样 → 不存在同一行里的撞名，**不调用**
  `Table.join-columns`。`interleave` 列取两侧并集（保序、不改名），`append`
  取左侧。任意一侧列未知时留空，交给 `.table` 从实际行推断。

**V-264**：一次性来源传播与错误口径与 V-260 / V-259 一致。

- `repeatable` 取两侧的与；二次消费给「已经读过一次」，不静默给空。
- `$other` 类型非法与 `zip` / `join` 一样在**消费时**由 `!rows-of` 抛
  `X::Rakuish::Unsupported`，不猜、不回落（SPEC V-259 的「当场」指不回落，
  不是构造期）。
- 不引入 shell 管道语法（V-901）。

---

## 3.23 TTY 后台作业 API（V-265…V-269，0.96.0 / ADR-0031）

**V-265**：四个普通 Raku 函数 `bg-exec($exe, *@args)` / `bg-jobs()` / `fg($id)` /
`bg($id)` 提供作业控制，**不引入 shell 语法**（V-901 不松动）。

- 返回真值：`bg-exec` / `fg` / `bg` 给 `Result`，`bg-jobs` 给 `Table`。
- 不解析 shell 字符串，argv-only，与 `exec()` 同一类东西。
- 不做 `&` 后缀、不做 `jobs` 保留字。

**V-266**：`bg-exec` 起一个自成进程组的后台作业并**立即返回** job id。

- 复用 `spawn-in-group`（SETPGROUP，无竞态），但**不**调 `tcsetpgrp`——
  前台仍是宿主，子进程继承 fd 0/1/2 直接写终端。
- 登记进父进程的 `JobTable`（id → pid/pgid/cmd/state/时间）。
- cwd / env 走会话 `Sys`，与 `!` 同一条路。

**V-267**：作业表建在**父进程**，不建在引擎。

- 引擎会因 Ctrl-C / 崩溃重启（ADR-0021 / 0023）；表若在引擎，后台进程重启后
  成孤儿。父进程持有真终端 + 作业表，是唯一落点。
- 引擎侧 DSL 函数经 `Sys.job-op` → `job-dispatch` hook → `event => 'job'` 帧
  转到父进程（与 `tty-exec` hook 同构，同一条请求/响应管道）。
- hook 未注入时（`-e` / 脚本 / 单进程）回落到本地方法。
- 与 `Sys.spawn()/jobs()`（捕获式后台、Promise/Handle）**分工不合并**：
  新 API 叫 `bg-jobs()`，不覆盖 `jobs()`，`!cmd-jobs` 不动。

**V-268**：`fg(id)` / `bg(id)` 的语义与 Ctrl-Z 边界。

- `fg`：切前台 → `SIGCONT` → 轮询等待 → 退出或再次被停 → **收回前台**。
  用 `wait-state`（`WNOHANG|WUNTRACED|WCONTINUED`）非阻塞轮询，**不装 SIGCHLD
  handler**（避免和 Rakudo 的回收抢信号，V-175）。
- Ctrl-Z（SIGTSTP）停住时返回 `state=stopped` 并立即归还前台，**不让 REPL
  卡死**（补 ADR-0010 §6.4 的已知边界）；不放行 `\x1a`、不改行编辑器。
- `bg`：只发 `SIGCONT`，前台不动。
- `fg` 的 `ok` 表示「带回动作成功」，不是「子进程 exit 0」；后者在
  `code` / `value<exit>`。

**V-269**：POSIX-only 与错误口径。

- Windows 上四个方法返回 `code=127` + 明确错误（无前台进程组，ADR-0010 §3），
  不退化成捕获式后台——那是 `spawn()` 的职责。
- 非法 id / 已结束作业 / 启动失败都返回失败 `Result`，不抛异常穿透。
- `repeatable` / 一次性来源语义不适用（作业表是父进程长生命周期对象）。
- 不做 SIGWINCH 转发、不做孙进程树回收（V-905 不变）。

## 3.24 tail -f 跟随（V-272…V-276，0.99.0 / ADR-0033）

**V-272**：`tail [-n N] [-f|--follow] 文件` 的跟随模式：先打末 N 行
（默认 10；`-n 0` 只看新增），然后**轮询**文件增长（0.2s 间隔，不用
inotify/kqueue——一个实现跨平台）。只吐完整行（`\n` 结尾），半行进
缓冲补齐再吐；缓冲按字节拼，整行才解码（跨 poll 的多字节 UTF-8 安全）。
紧凑形式 `-5f` / `-f5` 与 `-n N` 同时可写。CRLF 的行尾 `\r` 剥掉。

**V-273**：截断 / 轮转语义：文件变小（截断、被替换）→ 当作新文件从 0
重读；文件消失 → 等它回来，重现后按新文件处理。不做 inode 级
`tail -F` 跟踪——轮询 + 大小比较已覆盖日志轮转的常见形态。

**V-274**：执行位置与 Ctrl-C 归属：跟随循环在**持有真终端的父进程**里跑
（引擎经 `job-op('tail-follow')` 转过去，与 tty-exec / bg-exec 同构；
单进程模式回落本地，自装 SIGINT tap 当停止信号）。跟随期间 Ctrl-C 的
语义是**停止跟随**（code=130，128+SIGINT，用户意图不是故障），**不**重启
引擎——会话现场（my / our）原样保留。`head -f` 明确拒绝并指路 `tail -f`。

**V-275**：输出契约：跟随的行经专用通道**实时显示**，不进 `Result.out`
（render 不重放）；`Result.out` 只有一行停止摘要（`已停止跟随（Ctrl-C）·
输出 N 行`），`value => %(lines, stopped)`。`op` 恒为 `tail`。

**V-276**：文件不存在 / 不是普通文件 / 负行数：与 `read-lines` 同口径抛
`X::Rakuish::NotFound` / `X::Rakuish::Path`，Shell 层收敛成失败 `Result`。

---

## 3.25 交互手感层（V-277…V-282，0.100.0 / ADR-0034）

**V-277**：autosuggestion 灰字：输入行渲染在**内容段之后、padding 区内**
追加灰色建议后缀（宽度截断到 padding，总显示宽恒等于 display-width；
光标定位仍按 buffer 几何独立计算，建议串本身不参与）。来源是**历史**
（最近一条以当前行为前缀的记录，多行只取首行）；空行不给建议；仅
光标在行尾、尾段整段可见、非掩码输入、高亮开启时出现。`CursorRight` /
`Ctrl-F` 整句接受；无建议或不在行尾时退化为 `move-char-forward`
（不改既有键义）。建议来源扩展（补全候选 / 路径）明确留待后续——
建议是每键重算的热路径。

**V-278**：Tab 补全公共前缀优先：多候选共享**长于已输入文本**的公共
前缀时，候选序列首位放公共前缀补全（无尾随空格），其后才是逐个候选
（完整替换行契约不变）；单候选或前缀等长时不插入前缀项。上游 Tab
循环（`do-complete`）不动，靠候选排序实现。

**V-279**：候选菜单：`ShiftTab`（动作 `complete-list`）把候选去重
（按去尾空格归一——公共前缀候选与同词候选不重复显示）、按列排布打印
在输入行**下方**，最多 6 行、超出记 `…(+N)`；随后重打 prompt 并在新行
重绘输入区（避开底部滚屏后的存盘光标错位，等价 readline 列表行为）。
掩码输入（密码）与空候选不出菜单。

**V-280**：错误态标记：`Highlight.error-marks`（回调注入的纯函数）返回
`(start, end, kind)` 区间，`highlight-line :@marks` 把相交**段**改错误色
——**只换色不增删可见字符**（strip-ansi 等价不变式恒成立）。三个探测器：
① 括号失配 / 落单闭合（跳过字符串与注释；行尾未闭合开括号是续行常态
**不标**；跨行闭合由续行括号净数吸收）；② 命令不存在（shell 形行的首
词，跳过 Raku 关键字，查 COMMANDS / 用户层注册表 / PATH 一次性缓存）；
③ 路径不存在（shell 形行里 `./` `../` `~/` `/` 或含 `/` 的参数，引号内
不标、`-` 开头的选项跳过）。shell 形 = 无未引号
`$ @ % & ( ) [ ] { } ; | < >`。残余误报（用户自定义无括号 listop 形
调用）与精确化路径（引擎侧名字查询）记录在 ADR-0034 §2.4 / §4。

**V-281**：Ctrl-R 循环历史检索：首按把当前缓冲区内容存为查询串（可为
空 = 匹配一切），替换为「最近一条包含查询串」的历史记录；连按逐次走向
更旧的匹配（到头回绕）；任何其它编辑动作复位查询态。0.100.0 前
`key-bindings()` 宣称 Ctrl-R 搜索但真实键表未绑定——本版订正宣称与
实际一致。鱼式模态增量搜索（搜索行占 prompt、逐键过滤）明确**不做**：
需要拥有输入循环，与 V-155 边界一并在后续改造里做（ADR-0034 §3）。

**V-282**：补全模糊回退：前缀匹配（大小写不敏感）优先、命中时排序与
0.68 一致；**零前缀命中时**才做子序列回退（rank = 匹配跨度 + 缺口数，
升序、同分字典序，上限 50）。范围：Shell 命令名、SQL 表名 / 列名 /
关键字；**选项与路径保持前缀匹配**（带 `-` / `/` 的串做子序列噪声大于
收益）。公共辅助（`common-prefix` / `subsequence-rank` / `fuzzy-words` /
`suggest-suffix`）收在 `Rakuish::REPL::Complete`。

## 3.26 手感后续清单（V-283…V-286，0.101.0 / ADR-0035）

ADR-0034 §4 五项后续落地四项；第五项（鱼式模态增量搜索 + Tab-Tab 菜单）
仍推迟——需 fork 上游 `read-input`（0.0.23 里 170 行词法闭包），依赖升级
即漂移，与「不叠补丁」相悖，与 V-155 一起留待「拥有输入循环」的改造。

**V-283**：逐词接受建议——`Alt-CursorRight` 绑定
`edit-accept-suggestion-word`，吞掉灰字建议的前导空白 + 第一个词，剩余
留待再按；无建议时退化为 `move-word-forward`（不吞键）。`→`/Ctrl-F 整句
接受语义不变。上游 `decode-keyname` 对 CSI 修饰方向键（`\e[1;3C` →
`Alt-CursorRight`）有解，键名零障碍。

**V-284**：建议来源扩展——灰字建议除历史外，历史无命中时退到补全候选
（含路径，来自 Shell.completions）。用 `(buf,pos) → 候选` 缓存避免每键
扫盘 / 引擎往返；仍只进 padding 区，ADR-0011 宽度账本不变式不动。

**V-285**：`In[n]` / `Out[n]` 结果引用补全——光标前 prefix 形如
`(In|Out)[数字*` 时补出完整替换行候选（编号 1…结果历史长度，上限 50），
边界 `In`/`Out` 前不紧跟标识符字符。在引擎侧 Session 读 `@!out`，走既有
`complete` RPC，不扩协议。

**V-286**：命令不存在的引擎侧精确判定——`Session.error-marks` 的
`known-command` 回调加一层名字可见性：跨格 `sub`/`class`/`use` 声明
（`@!decls` 的 `<name>`）与跨格 `my` 变量（`%!state` 带 sigil 键）视为
已知，不标红。只消除误报，不把任意名字当命令补进表；判定在引擎内完成，
走既有 `error-marks` RPC，无新增往返。

## 3.27 结果渲染的 junction 边界（V-287，0.101.1 引入 / 0.101.2 补齐 display）

**V-287**：junction（`1|2` / `any(...)` / `all(...)`）是合法 Raku 值，
REPL 必须能承载，**不得崩在结果构造或渲染层**（0.101.0 及之前会崩）：

- `Result.value` 类型是 **`Mu`**（不是 `Any`）——`Junction` 是 `Mu` 的
  子类型、不是 `Any` 的子类型，用 `Any` 会在 `Result.new` 处抛 Type check。
- 「有没有值」用 `Result.value-defined`（junction 恒 True）；**不用**
  `.defined`（对 junction 会 autothread，在布尔上下文 splat）。
- 三种渲染格式（text / json / markdown）、`Session.render` 与内置命令展示口径
  `Result.display` 都把 junction 显示为它的 `.raku`（`any(1, 2)`）；`_` /
  `Out[n]` 里**保留 junction 原对象**，不降级成字符串。
- 检测必须在**调用点**做：Raku 对 junction 参数会逐分支调用函数体，
  函数内部看到的已是分支值（`$v.WHAT` 是 `Int` 而非 `Junction`），
  `$v ~~ Junction` / `.isa` 在函数内一律失效；只有 `$v.WHAT === Junction`
  在调用点才可靠。

## 3.28 可执行判定与 `IO::Path.x`（V-288，0.101.3 / 外部评测）

**V-288**：跨平台判断「可执行」不得直接依赖 `IO::Path.x`——Windows 上
Rakudo 2026.11 对**存在的文件**也会抛 `rindex search target requires a
concrete string, but got null`（`try` 兜住会静默成假值）。

- **Windows**：用扩展名白名单（`exe/bat/cmd/com/ps1/msi`）；NTFS 本无
  执行位，白名单是唯一有意义的口径。
- **POSIX**：仍用 `x` 位；异常（并发删除等竞态）按不可执行处理。
- 受影响的两处：`Sys.stat.executable`（旧实现静默恒假）、shell `which`
  （异常穿透 `handle` 会中止整段输入）。`ls` 上色早已走白名单，不受影响。
- shell `which` 只认普通文件（`.f`），不把同名目录当命令。

## 3.29 tty 直通期间 Ctrl-C 不得杀引擎（V-289，0.101.4 / 真机反馈）

**V-289**：双进程架构（ADR-0021）下，V-173 的「父进程存活」还必须包括
**引擎子进程存活**。

- 宿主（父进程）的 SIGINT handler 在 `in-request` 期间按「中断求值」处理，
  会 `kill(SIGKILL)` 引擎——这是为了让 `while 1 {}` 这类打不断的循环有出路。
  但 `! --tty` 恰好长期处于该状态：Ctrl-C 先把**引擎**打死，于是用户看到
  「引擎进程已退出 → 重启」，而终端刚被直通交接改过状态（raw / 光标 /
  排队输入），容易落进**光标错位、回车无响应**的死角。
- 修复：把「tty 直通」单列为一种信号归属状态（`tty-interactive`）——
  期间 Ctrl-C 只归属前台子进程，宿主与引擎都不动；直通结束立刻复位。
- 归属顺序（`arm-signal`）：`job-interactive`（停止跟随）→
  `tty-interactive`（直通）→ `in-request`（中断求值）→ 其余（输入中断）。
- 引擎侧 `tty-handler` 在等父侧 resume 期间也挂 SIGINT tap，作为纵深防御：
  Windows 的 `CTRL_C_EVENT` 发给整个控制台，没有 POSIX 的前台组隔离。
- 回归：`tools/ctrl-c-win.py` 场景二新增 `engine_survived`（输出里不得出现
  「引擎进程已退出」）。**反证过**：撤掉修复该检查必 FAIL——旧探针只验
  「下一格能否求值」，引擎被重启后仍能求值，所以一直假绿。
- POSIX 侧契约不变：有进程组交接，引擎本来就不在前台组；t/30 五条照旧。

## 3.30 读写上限与编码错误的出路（V-290，0.102.0 / 外部评测跟进）

**V-290**：1 MiB 默认上限**保留**（防 slurp 吃爆内存），但每条入口都必须
有「就地抬高」或「换读法」的出路，且失败必须在 Rakuish 异常族内。

- `cat` / `read` 接受 `--max-bytes=N`（`K/M/G`，1024 进制；也接受空格分隔）；
  撞上限的消息追加「本命令也能抬」，不再只把人引向 Raku 调用。
- `Sys.write` / `Sys.append` 接受单次 `:max-bytes(N)`，不必 `Sys.new` 重建。
- 文本接口读到「不是该编码的文本」（典型：二进制）抛
  **`X::Rakuish::Encoding`**——此前是 `X::AdHoc`「Malformed UTF-8 near
  bytes ...」，既不在异常族里、也不给用户任何出路。消息给出三条路：
  `:bin` / 换 `:enc` / `read-lines`。
- 只拦**解码类**失败：`resolve` 之后文件被删之类的 IO 错误原样抛，
  不误分类成编码问题。
- 默认值**不改**：口径是「默认可读、大文件显式抬」，不是「默认可吞」。

## 3.31 `!` 模式的补全（V-291，0.102.0）

**V-291**：`!` 前缀的输入走**同一套** argv 补全，不再直接放弃。

- `Shell.completions` 以前遇到 `!` 开头直接 `return ()`：`! ls tmp/<Tab>`
  与 `! raku script/<Tab>` 都没有任何反应。
- 现在剥掉 `!`（连同其后的空白，原样记着），按普通 argv 补全：首词补
  内置命令名，参数位补路径 / 选项。
- `!` 模式下首词**允许是外部程序**（`raku` / `python` / `--tty` 这类元
  选项），不再要求命中内置命令表；参数位照常补路径。
- 返回值仍是「完整替换行」契约（`! ls docs/` → `! ls docs/ADR-0001-...`），
  与 V-278 的公共前缀、选项补全一致。
- 只有 `!` / `! `（还没敲内容）时不猜，留给用户继续输入。
- 首词范围在 0.103.0 扩到 PATH 外部程序（V-292）。

## 3.32 `!` 的 PATH 外部命令补全（V-292，0.103.0）

**V-292**：`!` 的首词补全范围从「内置命令表」扩到「内置命令 + PATH 可执行文件」。

- `path-executables()` 扫 PATH 各目录，用 `is-executable()` 判定（V-288 口径：
  Windows 扩展名白名单、POSIX x 位，**不碰会抛异常的 `IO::Path.x`**）。
  Windows 去掉后缀（`! raku` 就能跑，CreateProcess 会自动补 `.exe`），
  按 PATH 顺序去重取先出现者，字典序。
- 按 PATH 字符串缓存；目录间并行遍历。本机 100+ 目录串行约 2.2 s、并行
  约 1.6 s，仍有感，因此入口在 REPL 启动前后台预热（`start`，不 join、
  不阻塞退出），用户敲到第一个 `! <Tab>` 时通常已经缓存好。
- 归属：`! <前缀><Tab>` 补命令名；`! --tty <前缀><Tab>` / `! -t ...`
  的第二词也补命令名（带 `/` / `\` 时仍走 V-291 的路径补全）；
  `! ls dir/<Tab>` 的路径补全不变。
- 非 `!` 模式不补 PATH 命令（内置命令表不变）；只有 `!` 时不猜。
- 测试：t/10 从真实 `path-executables()` 取一个字母开头的命令名做正向断言，
  并反向断言非 `!` 模式不会把它混进内置命令候选。

## 3.33 中文编码别名（V-293，0.104.0）

**V-293**：`Sys::FS` 的 `read` / `write` / `read-lines` 支持编码别名归一化——
`gbk` / `cp936` / `windows-936` / `ms936` → `gb18030`（GB18030 向下兼容 GBK /
GB2312），`gb2312` 原样；其余编码名交给 Rakudo 自行判断。Rakudo 内建确实
支持 `gb18030` / `gb2312`（外部评测 §3.4 说「GBK 无解」是查漏了），但**不**
支持 `big5` / `shift-jis`。

- shell 层 `cat` / `read` 增 `--enc=编码`（也吃 `--enc 编码`），默认 utf-8；
  `help cat` / `help read` 说明 `gbk` 用法。
- `X::Rakuish::Encoding` 的消息在 V-290 三条出路之外，补一句「Rakudo 内建
  不含 big5 / shift-jis；这类只能 `:bin` 后自行转码」，并把换编码示例从
  `:enc<utf-16>` 改成 `:enc<gb18030>`（中文用户最高频）。
- `read-lines` 保持 head 惰性（`$f.lines(:enc)`），加 `:enc` 不破坏早停。
- 测试：t/01 用 `encode('gb18030')` 造 GBK 字节，验五种写法解码 + GBK
  写读往返 + `read-lines :enc` + big5 抛 `X::Encoding`；t/10 验 shell `--enc`。
- 边界：不引入 iconv / NativeCall / 外部依赖；big5 / shift-jis 仍须 `:bin`。

## 3.34 文件锁 with-lock（V-294，0.105.0）

**V-294**：`Sys.with-lock(路径, &block, Bool :$shared = False,
Bool :$non-blocking = False)` 提供**劝告锁**（Raku 内建 `IO::Handle.lock`，
POSIX/Windows 同一 API，不引入模块）：

- 锁的是**独立伴生文件 `路径.lock`**，不是数据文件本身——`write` 是
  `.tmp` + rename 换 inode，锁数据文件会把锁留在旧 inode 上失效；锁文件
  inode 稳定。`锁文件故意不删除`（删了会让两个进程各锁一个 inode，互斥失效）。
- `LEAVE { $fh.close }` 确保正常返回与 `&block` 抛异常**都解锁**；回调返回值
  与异常原样透传。
- `:$shared` 共享读锁 / 默认独占写锁；`:$non-blocking` 拿不到锁抛
  `X::Rakuish::LockConflict`（异常族；名字避开 Raku 内建 `Lock`，否则遮蔽
  内建类使 `Proc` 里的 `my Lock $PTY-LOCK .= new` 编译失败）。
- DSL 导出 `with-lock`；shell 层不暴露（编程 API，非命令）。
- 边界：劝告锁——只有同样调用 `with-lock` 的进程互相等待，直接读写文件的
  进程不受拦；不做强制锁、记录锁、死锁检测、超时参数。
- 测试：t/01 验返回值 / 锁文件生成 / 锁内原子写 / 异常后解锁 / 共享锁 /
  non-blocking 冲突与释放；两进程抢锁无丢失更新已手工验证（真并发时序
  脆弱，不塞进单测）。

## 3.35 结构化管道的性能收口（V-295，0.106.0）

**V-295**：`stream` 与 CSV 入口的三处性能/可用性收口，行为契约不变：

- **`where` 的列值告警抑制**：写错列名时 `.<2>.Int` 在每行打一条
  `Use of uninitialized value`（实测 20 万行 = 20 万条 stderr，把 5 秒的
  过滤拖到 77 秒）。谓词求值处拦 `CX::Warn`：首次给一条可操作提示
  （能抓到列名就带上，并提示用 `.columns` 核对），后续同类抑制；
  其它警告（用户自己的 `warn`、非未初始化告警）用 `.gist` 原样转出并
  `resume`，不吞。谓词仍按未定义值求假，不抛异常。
- **已知行数不重扫**：源头已把行物化（文本 / CSV / Table / List / Hash）
  时记下行数，`count` 直接返回；`limit` / `skip` 能推算行数；派生阶段
  （`where` / `map` 等）不猜，仍走真实消费。`Stream.new(:make)` 外部来源
  默认未知且逐行 `coerce-row`，保持兼容。
- **行已是 Hash 免重复判定**：源头与产出 Hash 的阶段（select / drop /
  map / add-column / count-by / group-by）标记 `hash-rows`，`!seq` 直接放行；
  其它来源仍走 `!coerce-row`（Hash / Pair 列表 / 标量值三分支）。
- **CSV 行级解析**：无引号的行直接 `.split(',')`，不再把整份文本 `.comb`
  成字符数组逐字符 `~=`；含引号（可能跨行）的行才进原状态机。BOM、CRLF、
  双写引号、字段内逗号/换行、行尾空字段语义不变；单元格都是 `Str`，
  显式给 Table 类型避免逐列再扫一遍做推断。
- 实测（4.3 MB / 20 万行 CSV，Windows 2026.11）：`count` 约 19.4s → 4.5s，
  `where+count`（正确列名）约 8.1s → 5.1s，错列名 77s → 5.1s，
  `limit(1000)→table` 约 7.7s → 3.7s。冷启动与 RPC 往返不在本条范围内。
- 测试：t/46 验行数推算 / 外部 `:make` 的 coerce 兼容 / 警告只提示一次 /
  用户 `warn` 透传；t/11 验 BOM + CRLF + 引号内换行 + 行尾空字段。

## 3.36 入口启动成本（V-296，0.106.1）

**V-296**：`-e` / 脚本 / `--version` 不再为 REPL 前端付全价：

- **入口脚本极小化**：`bin/rakuish` 只加 lib 路径、`require Rakuish::CLI`、
  调 `Rakuish::CLI::run()`。原来 700 行入口每次启动都要重新编译（Rakudo
  不缓存脚本），实测固定成本约 0.7s；现在入口逻辑在 `Rakuish::CLI`
  模块里，走预编译缓存。
- **`--version` 直读 META6.json**，不加载 CLI 模块。
- **按模式 require**：`Rakuish::CLI` 内部只在对应分支加载 Session /
  Kernel / Chrome / Sys::Term / Sys::Console / Audit；交互式才加载
  Eval / Eval::Proxy / Keymap / Pager / LineEditor。
- **Kernel 构造放到 `Rakuish::Kernel::Factory`**：`require Rakuish::Kernel`
  拿到的是与导出类同名的模块桩，不能 `.new`；Factory 用正常的 `use`
  导入后再以工厂函数交给入口，只有 `-e` / 脚本 / REPL 才加载。
- 实测（Windows 2026.11，热缓存）：`rakuish -e '1+1'` 1.35s → 0.69s，
  `rakuish --version` 1.2s → 约 0.3s；冷启动仍在 1s 量级，属于 Rakudo 启动
  与 Session 加载的固有成本。
- 边界：不引入 daemon、不改 `-e` 的语义（仍是「跑一个 REPL 格」并打印
  `Out[1] =`，`say` 照常只出 stdout，退出码规则不变）。

## 3.37 `use` 的跨格可见性（V-297，0.106.2）

**V-297**：REPL 里的 `use` 必须像脚本里一样「导入即生效」，且对后续格有效：

- **背景**：EVAL 在包 `Rakuish::REPL::Session` 里编译，`Foo::Bar` 会先按
  `Rakuish::REPL::Session::Foo::Bar` 解析；只有同一编译单元里出现过
  `use Foo::Bar`，编译器才把这个名字连到 GLOBAL 下的类型。跨格时 prelude
  重放 `use` 本是为此，但被下一条的解析行为抵消了。
- **Rakudo 行为（2026.09 实测）**：`do { use X⏎X::Y }` 里 `use` 不带分号时，
  同一编译单元也认不到导入名（`Could not find symbol '&Y' in '<pkg>::X'`）；
  写成 `use X;⏎X::Y` 就正常。rakuish 的 prelude 用换行拼接，于是重放的
  `use` 形同虚设 —— 真实报障是 `use DB::DuckDB` 之后 `DB::DuckDB.new`
  报 `assign requires a concrete object (got a VMNull type object instead)`。
- **修法**：`!scan-cell` 在顶层遇到 `use` 语句就补 `;`（括号未闭合的多行
  `use` 不动；`use X # 注释` 的分号补在注释之前）；prelude 重放时对旧快照
  里没分号的 `use` 再补一次，老会话恢复后同样可用。
- **混合格**：`use X; say 1` 不算纯声明格（副作用不缓存），但其中的顶层
  `use` 由 `!collect-uses` 单独收进 prelude —— `use` 只是加载 + 导入，
  重放无副作用。其它语句的「只执行一次」语义不变。
- **测试**：t/62 覆盖跨格类型、同格换行写法、混合格、行内注释、导出 sub、
  重复 `use`、带引号的 `use lib`，以及 `my` / `sub` 的原有跨格行为。

## 3.38 方法名补全（V-298，0.107.0）

**V-298**：`.` 之后按 Tab 补方法名，覆盖「实例 / 类型 / 结果引用」三类左值：

- **形态**：`$obj.` `@arr.` `%h.`（跨格 my 变量）、`_.`（上一格值）、
  `Out[n].`（第 n 格结果）、`Type::Name.`（`use` 进来的类）。已输入半截时
  按片段前缀过滤；多候选沿用 V-278 的公共前缀口径（前缀等于某候选时不重复）。
- **解析在纯函数里**（`Rakuish::REPL::Methods.method-context`）：只认「点在
  光标处」的尾巴，`1.5` / `foo.bar` / `!` 行都不命中。**链式调用不补**——
  `$x.foo.` 需要在补全路径上真求值一次，代价与风险都不值（写进边界）。
- **取值在 Session**：变量查 `%!state`（带 sigil 的键），`_` / `Out[n]` 查
  `@!out`（显示口径 `Out[n]` = `@!out[n-1]`，EVAL 里给用户的 `Out` 前面那个
  `Any` 只是占位）。类型名走 `!resolve-type`：`::("DB::DuckDB")` 是**相对包名**
  查找，方法自己的编译单元看不到 EVAL 里 `use` 进来的符号（实测返回 Nil），
  所以拼一条「已有 use 行 + 类型名」的 EVAL，结果按名字缓存（约 4ms/次）；
  新的 `use` 成功时整块清缓存。
- **候选表**：`^methods` 去私有（`!` 开头）去重排序，再用 `^can` 补
  `new` / `clone` / `gist` / `perl` / `raku` —— `submethod new` 不在
  `^methods` 里，而 `Type.new` 恰恰是最常用的入口。
- **占位值不给补全**：类型对象本身 `.defined` 为假但方法表有效，照补；
  只有 `Any` / `Mu` 这种「没有值」的占位返回空，`$未赋值.` 不会刷一屏。
- **测试**：t/63（41 条）覆盖四种形态的解析、实例/类型方法表、跨格 `use`
  之后的 `TestNS::Box.`、`$b.`、`_`、`Out[2]`、未知目标、`!` 行与既有
  命令补全不回归。

## 3.39 会话自省与重跑（V-299，0.108.0）

**V-299**：把「会话里有什么、刚才跑了什么」变成可查的普通命令。四个入口
都只读会话数据（`%!state` / `@!decls` / `@!history`），**不 EVAL、不碰 Sys、
不推进 `Out[n]`**：

| 输入 | 行为 |
|---|---|
| `who` | 变量名（带 sigil），`$` → `@` → `%` 分组后按名排序；空会话给提示 |
| `who -l` / `whos` | 变量（类型 / 大小）+ 声明（sub / class / role / grammar / use） |
| `名字?` | `$x?` 给类型与一行值摘要；`ls?` 等价 `doc ls`；`Box?` 列本会话 class 的方法 |
| `rerun [n]` | 重跑 `history` 第 n 条（负数从末尾；缺省 = 上一条） |

- **`?` 不抢语义**：Raku 没有后缀 `?` 运算符，`整行 = 名字?` 今天本来就是
  语法错误。只匹配「整行只有 名字?」，`1 ?? 2 !! 3`、`'a?'`、`/a?/` 都不命中。
- **`rerun` 走真实求值**：内层照常 `eval-line`（生成新的 `Out[n]`、历史里记
  **被重跑的那条**），外层 `rerun 3` 本身不记（与 `!!` 同一套路），否则历史
  会被自己的回放污染。
- **`doc` 的边界照旧**：Introspect 零 EVAL，看不到跨格 `use` 的模块与跨格
  声明的 sub —— 这两种情况给**明确说明**，不假装成功。
- **例外是类型**：本会话声明的 class/role/grammar 走 `!resolve-type` 重放声明
  取值，因此 `Box?` 能列方法。同一处改动让 **prelude 从「只重放 use」变成
  「重放全部声明」**，顺带把 `class Box{}` 之后的 `Box.<Tab>` 补全修好；
  结果仍按名字缓存，失败仍静默退化成 `Any`。
- **元方法不入表**：Rakudo 自动挂的 `POPULATE` 在 `whos`、`Box?`、方法补全里
  都不出现（它不是用户 API）。
- **测试**：t/64（63 条）覆盖变量排序、类型/大小、声明与 use 列表、四种 `?`
  形态、不误伤三元/字符串/正则、`rerun` 的格号与历史语义、help/Tab/doc 同步。

## 3.40 Notebook 协议层（V-300，0.109.0）

**V-300**：把 notebook 前端需要的消息映射成 Kernel 调用，**传输与语义分离**：
`Rakuish::Kernel::Notebook::Frontend.handle(%msg --> %reply)` 只处理 Hash，
`bin/rakuish-notebook` 负责「一行一 JSON」的 I/O。ZMQ 桥不在本版（ADR-0037）。

- **协议**：`kernel_info` / `execute` / `complete` / `is_complete` / `inspect` /
  `shutdown`；启动先发一帧 `event: ready`（带 version / cwd / rc 输出）。
  任何 `say` 不得进协议流 —— 用户 stdout 由引擎捕获进 `out`。
- **`text` 与 `display` 分工**：`text` 给 TTY（含 `Out[n]` 与颜色）；`display` 是
  `Display::Bundle.to-hash`（零 ANSI、text/markdown/json）。执行请求带
  `display:true` 才算这一份，TTY 路径不付它的成本。承载字段叫 `bundle` ——
  `Result` 已有 `method display`（文本摘要），同名属性会被遮蔽。
- **complete**：候选是整行替换 → `cursor_start = 0`、`cursor_end = 光标位`；
  按单词边界给 start 会让前端把 `$db.` 再拼一次。
- **is_complete**：本地调 `is-incomplete`（纯函数），不往返引擎；只给
  complete / incomplete 两态，不猜 invalid。
- **inspect**：复用 `名字?` 的实现（`Session.inspect-name`），经 Server 的
  `cmd:'inspect'` → Client → Proxy → `Kernel.inspect` 暴露；`?` 命令与
  notebook 的 Shift+Tab 是同一份实现。
- **边界**：无流式（`say` 一次性随 `out` 回来）、无 stdin、`! --tty` 与后台作业
  一律报错、富 HTML/PNG 不在本版；中断仍是「杀掉重启 + 状态丢失」，与 TTY 一致。
- **测试**：t/65（50 条）覆盖内核信息、值 / stdout / 错误的分工、跨格变量、
  补全口径、续行判定、inspect、未知 op，以及真实 `bin/rakuish-notebook` 子进程的
  ready 帧与行协议；t/51 增加 `KERNEL-VERSION` 与 META6 版本一致性的守护。

## 3.41 展示层的 HTML 与 MIME 分档（V-301，0.110.0）

**V-301**：`Display::Bundle` 增加 `html`，并把「一次给齐所有 MIME」做成显式能力。
这是**展示层**的格式，不是富媒体渲染 —— 内联图片 / HTML 小组件仍按 V-901/902 卡着。

- **格式集**：`text / markdown / html / json`（`FORMATS` 与 `capabilities` 同步，
  `text` 仍必有）。`available` / `has` / `pick` / `render` 全部认识 `html`；
  内容协商按调用方给的偏好顺序挑第一个可用项，都不认才回退 `text`。
- **各 kind 的 HTML**：table / records 走 `Table.to-html`（`<thead>` + `<tbody>`，
  内联最小样式 —— Jupyter 不会替我们加 CSS，裸 `<table>` 在页面上没有边框）；
  paths / rows 给 `<ul>`；record 先转成两列表再走同一实现（不手拼第三套）；
  scalar / text / error 给 `<pre>`（错误带 `class="err"`）。空内容（`cd` 之类）
  不提供 html —— 空的 `<pre>` 只会让页面多一块空白。
- **转义只有一份**：`Table.html-escape`（先 `&`→`&amp;`，再 `<` `>` `"`），
  Display 借用同一个方法。用户内容里的 `<script>` 不会变成标签。
- **MIME 分档**：`Bundle.to-mime` 给 `text/plain` / `text/markdown` / `text/html` /
  `application/json`（只含可用项）。键必须用花括号索引 —— `%m<"text/plain">`
  会把引号写进键名（实测序列化出 `"\"text/plain\""`，前端一个都对不上）。
- **按需才付成本**：`to-hash(:mime)` 默认关，`Kernel.present` 与 TTY 路径不带；
  只有 notebook 的 `result-frame` 传 `:mime`。`execute` 的 `display` 因此多一个
  `mime` 字段，原有 `content` / `format` / `formats` / `meta` 不变 —— 0.109 的
  客户端不受影响。
- **不做文件**：本版不写 `.html` / `.png`。PNG 需要浏览器或 rsvg 渲染，属于
  「导出动作」，与 `Display` 的纯函数约束冲突（ADR-0037 §7 记录了代价）。
- **测试**：t/38（95 条，含转义 / pick / mime / 默认不带 mime）+ t/65（60 条，
  含 notebook `display.mime` 的四档与表格 HTML）。

---

## 3.42 Jupyter wrapper kernel（V-302，0.111.0）

**V-302**：传输层落地。`ipykernel.kernelbase.Kernel` 的子类负责 ZMQ 五通道、
HMAC 与心跳；`tools/jupyter/` 只写「消息翻译」，Raku 侧一行一 JSON 的
`bin/rakuish-notebook` 是 0.109 就做好的，本版不改它的语义。

- **不重写 MIME**：0.110 的 `display.mime` 已经给齐四档，Python 侧直接转发；
  唯一转换是 `application/json` —— 线上值是 JSON **字符串**，Jupyter 要对象，
  所以必须 `json.loads`。原先设计稿里的 `_mime()` 删掉，避免两套规则漂移。
- **格号口径**：`execution_count` 取桥返回的值，不让 ipykernel 自行递增 ——
  否则失败格会计号，与 `In[n]` / `Out[n]` 不一致（t/65 的既有契约）。
- **通道分工**：execute / complete / inspect / is_complete 走 shell；
  `shutdown_request` / `shutdown_reply` 走 **control**（实测，读错通道会超时）。
  stdout / stderr 是 iopub `stream`，结果是 `execute_result`，二者分开。
- **能力如实**：ipykernel 7 在 debugpy 存在时会虚报 `debugger`，还默认报
  `kernel subshells`；覆盖 `kernel_info` 清空 `supported_features`。
  kernelspec 用 `interrupt_mode: "message"`，不声称无损中断（重启会丢会话）。
- **首帧握手**：wrapper 启动桥后先读 `event:ready`，用它带回来的 version/banner
  填 `kernel_info`；首帧不是 ready 就直接报错，不假装内核可用。
- **安装与验证**：`python tools/jupyter/install_kernel.py` 把 wrapper 包与
  kernel.json 装进 Jupyter 用户目录；`python tools/jupyter/smoke.py` 用
  `BlockingKernelClient` 起真内核，覆盖值 / stdout / 跨格状态 / 错误 /
  complete / inspect / is_complete / shutdown（无需浏览器）。
- **边界**：无流式输出（cell 结束才一次性回 `out`）；`input()` 与 `! --tty`
  不支持；中断会丢状态；不提供 debugger，也不自带前端（JupyterLab / Notebook
  由用户侧安装）。WebSocket 自写前端是另一条路线，不共享传输层。
- **测试**：t/66（24 条）守护 Python 文件、语法可编译与关键口径不漂；
  端到端由 smoke 脚本手工验证（依赖 ipykernel，不进双平台 t/ 套件）。

---

## 3.43 按 origin 分账（V-303，0.112.0）

**V-303**：把「notebook 里跑过什么」变成可查的事实，而不是翻日志文件猜。

- **origin 约束**：`valid-origin` 只认 `human / agent / notebook / script`，
  `x-` 前缀是显式 escape hatch（如 `x-web-ui`）。`Request` 的 `TWEAK` 直接拒绝
  其它值，错误里列出允许值 —— 拼错一个字母不再悄悄进账本，否则将来按来源
  查时会永远漏掉那几条。
- **审计查询**：`Audit.by-origin` / `Audit.origin-summary` 同时看进程内条目与
  `$path` 的 JSONL（上几个 REPL / `-e` / 脚本进程写的），按 `seq` 去重再按时间
  排序；汇总按来源给 `total / ok / failed`。
- **`audit` 命令**：`audit`（各来源计数）/ `audit notebook` / `audit --origin human`
  / `audit --help`。与 `log` 不是一回事：后者是给人看的文本会话抄本，前者查
  结构化账本。分账命令本身不记账（和 `history` / `who` 同级）。
- **注入**：Session 默认有一本纯内存账；Kernel 构造时把共享审计实例交给
  Session，调用方不必在两个构造点各传一遍。
- **测试**：t/35（合法 / 非法 origin 与 escape hatch）、t/40（跨进程磁盘分账）、
  t/67（命令与注入）、t/37（命令表与补全可发现）。

---

## 3.44 服务端主动推送（V-305，0.113.0）

**V-305**：把 notebook 协议从「一问一答」扩成**双向**：桥可以在两条请求之间
插帧。分界线是字段 —— **带 `op` 的是响应，带 `event` 的是推送**。

- **两类推送**：`busy` / `idle` 包住每一格 `execute`（带 `op`、`id`、`idle` 另带
  `ms`）；`engine` 报引擎生死（`dead` / `restart` / `interrupted` / `restart-failed`，
  带 `ok` / `reason` / `restarts` / `index` / `restored` / `rc`）。
- **id 认领**：一旦中间会插帧，「下一行就是我的响应」不再成立。请求带 `id`
  就原样回显（所有 op，不只 execute），前端按 id 归位。不带 id 的旧客户端
  仍可用 —— 推送帧不影响它们按顺序读响应（它们只是要多跳过几行）。
- **`busy`/`idle` 只包 execute**：补全与 inspect 是按键触发的，每敲一个字符
  播一次忙只会让状态栏闪。`idle` 在**响应之后**发，与 Jupyter 的
  busy → 输出 → reply → idle 同序，前端据此解锁输入。
- **空闲期死亡必须主动报**：主循环阻塞在读 stdin 上，引擎死在没有请求的
  时刻，前端要等下一条输入才知道（那时它已自动重启，看起来像「刚跑就失败」）。
  所以起一条独立 OS 线程（`Thread.start`，不用 `start` —— 别占调度器线程池）
  每 250ms 读一次 `Client.alive`；`$busy` 期间不报，那一段由 `!revive` 负责。
- **修掉一个潜伏 bug**：`Client.alive` 从 0.83 起就不会因进程退出而翻假 ——
  `$!proc =:= $proc` 判的是**容器同一性**，两个变量各装一份引用永远是 False。
  改成代际计数（`$!generation`），重启时旧进程的回调不会把新进程标成死。
  t/41 之前能过是因为求值中的崩溃走 `!receive` 的 CATCH 另一条路。
- **事件载荷只带业务字段**：`%!restored` 存的是引擎整条 restore 回复（含
  `event` / `seq` / `path`），直接塞进事件帧会让前端看到嵌套的
  `"event":"restored"` 而分类错；所以挑 `decls` / `vars` / `failed` / `saved-at`。
- **订阅者是旁观者**：`Proxy.on-engine-event` 抛异常不影响「已重启」这个
  事实（整段包在 `try` 里）；TTY 侧暂不订阅 —— 它本来就把这段文字打在
  结果里，再播一次是噪音。
- **Jupyter 桥的取舍**：`busy`/`idle` 只记录不转播（ipykernel 自己已经发
  status，转发会让每次忙碌出现两条）；`engine` 只转播 **kind=dead**（空闲期
  死亡没有 reply 可以携带），执行中的那次已经写在 execute 回复的 traceback 里。
- **测试**：t/65（108 条，含 id 回显、busy→响应→idle 顺序、杀掉引擎 pid 后
  的空闲期死亡与重启推送、Proxy 事件载荷与「订阅者炸了也不影响重启」）、
  t/66（33 条，锁住 Python 侧「按 event 分帧、只转播 dead」的口径）。
  端到端仍由 `tools/jupyter/smoke.py` 手工验证（真内核 + ZMQ 五通道）。

---

## 3.45 `source`：在会话里跑脚本（V-306，0.114.0）

**V-306**：`source <文件> [参数...]` 把脚本文件喂给**当前会话**执行 —— 脚本
看得到会话的变量，脚本里的 `sub` / `class` / `use` / 顶层 `my` 也留在会话里。

- **名字不用 `run`**：`run` 是 Raku 自带的 sub（`run 'git', 'status'`），抢过来
  等于把语言拆掉半边。`source` 与 shell 的 `source` 同义，也不冲突。
- **逐行执行，不是整份一个 cell**：`!pure-decl` 只在「一格恰好是一条声明」时
  持久化声明。整份文件当一个 cell 跑，里面的 `sub` 只活在那次 EVAL 里，跑完就
  没了 —— 那正好废掉 `source` 最主要的用途。代价：脚本语义比「一个编译单元」
  弱一点（`BEGIN` 按行触发、声明必须先于使用），与 REPL 的既有语义一致。
- **双向共享**：脚本经 `%!state` 别名看到会话变量；脚本声明进 `%!state` /
  `@!decls`，跑完仍在。
- **参数**：`@*ARGS`（`temp` 绑定，跑完还原）、`$*PROGRAM` / `$*PROGRAM-NAME`
  指向该文件。文件里声明了 `sub MAIN` **且给了参数**时按位置参数调用一次；
  调不上（命名参数 / 类型转换）如实报错并说明「MAIN 的用法分派只在脚本入口
  生效」。不给参数就只加载，不触发 MAIN —— `source lib.raku` 是「装库」。
- **记账边界**：脚本内部的行不占 `Out[n]` / `history` / `perf`（进入前快照、
  退出时还原）；`source` 这一行本身按普通命令记一条 history。`@!decls` /
  `%!state` 不回滚，那是要留下的东西。
- **错误**：按 `文件:行` 报出，整体 `ok=False`、`code=1`；某一行失败**不中止**
  后续行（shell 的 `source` 语义，也是 `run-rc` 的语义）。文件结束时仍处于
  续行态则报「未闭合结构」，并**清空续行缓冲** —— 不清会把后面每一格都毒死。
- **`exit` 就是退出**：与 shell 一致，但之前的输出照常返回，且不会真的杀掉
  引擎（`exit` / `exit N` / `exit;` 都映射成会话退出请求，0.114 补上了分号）。
- **与脚本模式的分工**：`source` 是「装库 / 调试」—— 会话里不做完整的
  RUN-MAIN 分派（用法错误分支会 `exit 2`，那会带走引擎），有参数时只按
  位置参数调用 `MAIN`。完整的命令行分派属于一次性入口 `rakuish 文件 参数`
  （0.118.0 / V-311，见 §3.50）。
- **顺带修掉的两个既有缺陷**（都在 `!scan-cell` / `!pure-decl`）：
  `our sub f {}` 曾被当成变量声明扫描，`sub` 被吃掉后 cell 变成 `f(...) {...}`
  报 infix 错误；`our` 也算不出现在「顶层声明」清单里，下一格看不见它。
- **测试**：t/68（59 条，含用法 / 找不到 / 不是文件、双向共享、Out 与 history
  边界、错误行号与继续执行、MAIN 三种情形、exit、CRLF、空文件）。

---

## 3.46 格记录与导出（V-307，0.115.0）

**V-307**：`cells` 把「这一会话跑过什么」变成一条条**结构化格记录**：
不带参数列出来，`--text` / `--json` 导出。

- **三个邻居的分工**：`history` 只有输入；`log` 是人读的文本抄本（受 log
  on/off 影响）；`cells` 是记录（输入 + 渲染文本 + 成败 + 耗时），与日志开关
  无关。
- **名字不叫 `export`**：`export` 是 Shell 薄层的环境变量导出（`export FOO=1`），
  抢过来等于把 shell 习惯拆掉半边（t/10 立刻红）。
- **记账点只有一处**：`!finish`（历史的同一处）落 `seq / index / input / ok /
  op / code / ms`，`log-line` 再补 `rendered` —— 渲染文本只有前端算得出来。
  上限 500 条，超出丢最旧的。
- **`cells` 自己不进记录**：`$!skip-cell` 在方法出口置位，`!finish` 消费它。
  否则每导出一次就多一格，继续导出时把上一次的 `cells ...` 也写进文件（自指），
  `count` 与用户看到的格数永远差一。
- **`--text` 是可重放脚本**，两条必要的修补：
  1. **每格补语句结束符** —— REPL 里一格是一次独立 EVAL，`1+1` 不带 `;` 也行；
     拼成整份脚本后 `1+1` 紧跟 `my $x = 42;` 会被读成「两个项连写」。
     行尾有注释时分号另起一行（否则落进注释里）。
  2. **`no worries;`** —— 脚本模式下裸表达式报 "Useless use ... in sink context"，
     几十格导出来就是几十条噪音。
  两种重放方式都验证过：`rakuish 文件`（脚本模式）与 `source 文件`（会话模式）。
- **`--json` 是机器格式**：`format: rakuish-cells` + `format-version: 1`（格式版本，
  不是产品版本 —— 只有 schema 变才动它），`cells[]` 每项含
  `seq / index / input / rendered / ok / op / code / ms`；前端没调 `log-line`
  的路径（`-e` / 管道）`rendered` 是空串而不是缺字段。
- **列表编号用 `seq` 而不是 Out 号**：失败的格不占 `Out[n]`（既定契约），
  拿 index 当编号会出现两个「2」；脚注里写明这个差异。
- **测试**：t/69（59 条，含用法、空会话、`--text` 的两种修补、脚本模式与会话
  模式两种重放、`--json` 字段与 `rendered` 的补全、相对路径、参数错误、
  行尾注释）。

---

## 3.47 Arrow IPC 读写（V-308，0.116.0）

**V-308**：`.arrow` / `.feather` / `.ipc` 走内置的 Arrow IPC 解析，落成
`Table`；`save-data` 反向写出。

- **为什么自己实现**：DuckDB 只能扫内存里的 Arrow，**读不了 IPC 文件**
  （`read_parquet` 是另一回事）；Duckula 能读，但要拖进 `DB::DuckDB` /
  原生 libduckdb —— 只为了解一个文件格式，这份依赖太重。FlatBuffers 的读取
  代码不到 200 行，写到我们需要的形状也就 300 行。
- **文件与流**：文件 = `ARROW1` + 两条 0 填充 + 消息流 + Footer +
  `int32 footer 长度` + `ARROW1`；流 = 消息流，没有头尾。消息以
  `0xFFFFFFFF` 续行标记开头（V5 起），随后是元数据长度、FlatBuffers 元数据、
  body。`ipc-format` 靠头 6 字节判断文件模式，靠首条消息是不是 Schema 判断流。
- **FlatBuffers 的三个坑**（都踩过，写在这里省下次）：
  1. 缓冲区开头是指向**根表**的 uoffset，不是表本身；当表解析会读出
     「vtable 长度 5」这种怪值。
  2. FlatBuffers 从后往前构建：新字节落在更低地址，所以内部缓冲用「插在最前」，
     最后**不要**再翻一次（翻了根偏移会跑到末尾）。
  3. 字段引用的 uoffset 是「目标绝对位置 − 字段绝对位置」，目标总是更高地址。
  表头 soffset 要等 vtable 写完才能回填，先占 4 字节位置、结束时按
  「距末尾偏移」算回绝对下标。
- **支持的类型**：`null` / `int`（8/16/32/64，有符号无符号）/ `float`
  （half/single/double）/ `bool` / `utf8` / `large-utf8` / `binary` /
  `large-binary` / `date` / `time` / `timestamp` / `decimal` / `duration`。
  写只出 `int64` / `double` / `bool` / `utf8` / `timestamp[ms]`（够给
  pandas / polars / duckdb 吃）。
- **明确拒绝而不是猜**：字典编码、`BodyCompression`、`List` / `Struct` / `Map` /
  `Union` / `FixedSizeBinary` / `FixedSizeList` / `RunEndEncoded` / `Interval`
  都抛 `X::Rakuish::Arrow` 并说明原因（压缩那条会告诉你「请用未压缩导出」）。
  静默降级成空列比报错危险得多。
- **类型映射到 Table**：`int→int`、`float/decimal/time/duration→num`、
  `date/timestamp→datetime`、`utf8/binary→str`、`bool→bool`。
  `time` / `duration` 没有跨日语义，换算成秒保留成数字，不伪装成 `DateTime`；
  `date32` 用 `Date + 天数`（负数天数 = 1970 之前），`timestamp` 按单位换算后
  走 `Instant.from-posix`。
- **时间戳的闰秒陷阱**：写 `DateTime` 时**不能**用 `Instant.Num` —— 它按 TAI
  计、含闰秒，2020 年的值会多 37 秒。用 `posix + (second - whole-second)`。
- **接进 open/save**：`open-data` / `save-data` 按扩展名分发，走 `Sys.resolve`
  做 root 校验；**不需要** `:allow-external`（不经过外部引擎）。二进制没有文本
  形态，`:raw` 明确拒绝而不是解码一堆乱码。
- **验证**：读的方向用 pyarrow 26 生成的真实文件（t/fixtures/arrow/，随仓库提交，
  测试不依赖 pyarrow）；写的方向人工用 pyarrow `open_file` / `open_stream` 读回
  核对过（含文件与流两种模式、UTF-8、null、时间戳）。t/70 共 68 条断言。
- **已知边界**：不支持字典编码与压缩；不支持嵌套类型；整份文件读进内存
  （超大文件请走 Parquet + DuckDB 那条路）。

---

## 3.48 Windows 子树回收与 Ctrl 事件更正（V-309，0.117.0）

**V-309**：引擎（`Eval::Client` 起的子进程）被 Ctrl-C 杀掉或崩溃重启时，
它启动的前台命令与孙进程由 **Job Object** 一并回收；同时更正 ADR-0010 §3
里「Ctrl 事件不能投递给进程组」这个只对 `CTRL_C_EVENT` 成立的结论。

- **原来的缺口**：Windows 没有 POSIX 进程组，也没有「父进程死了孩子跟着死」。
  引擎被 kill 时，它 spawn 出来的命令行进程原地变孤儿，谁都不收（ADR-0031
  的 V-905 当年就是这么写进「不做」的）。
- **做法**：`Rakuish::Sys::WinJob`（kernel32 三个函数的 NativeCall 薄封装）。
  `Client.start` 起好引擎立刻 `CreateJobObjectW` + 设
  `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE` + `AssignProcessToJobObject`；之后引擎
  spawn 的命令、命令 spawn 的孙进程**自动继承 job 归属**，不用逐个登记。
  杀引擎的三条路（Ctrl-C 中断、`restart`、`shutdown`）统一走
  `TerminateJobObject` 再关句柄。宿主退出时句柄自动关闭，
  `KILL_ON_JOB_CLOSE` 兜住最后一种情况——不留孤儿。
- **不涉及 fg/bg**：这只是回收，不是作业控制。ADR-0031「POSIX-only」的立场
  不变，两者并列存在。
- **降级**：非 Windows、32 位 Rakudo、建 job 或归类失败，一律回到旧路径
  （只 kill 进程），不阻塞引擎启动。t/71 在 POSIX 上整段 skip。
- **三个坑**（都实测过）：
  1. **嵌套 CStruct 算错尺寸**：`nativesizeof` 对嵌套 CStruct 报 48 而不是 144，
     `SetInformationJobObject` 于是静默失败——job 建出来却没有任何限制。
     改成**平铺**一张表并断言 144 字节。
  2. **Pointer 判空不能写 `!~~ Pointer`**：Pointer 的实例也满足类型检查，
     那样会把有效句柄一起拒掉；只判 `.defined`（NULL 回来的是类型对象）。
  3. **`IsProcessInJob` 要 `PROCESS_QUERY_LIMITED_INFORMATION`**，否则返回 0
     而不是「不在 job 里」，诊断会一直假阴性；出参得用 `CArray[int32]`，
     传裸 `int32` 报 "expected CPointer representation, got a NativeRef"。
- **ADR-0010 §3 的更正（真机实验）**：原结论把两种事件合并了。独立 console 里
  对照实测：

  | 事件 | 目标 | 子进程 | 结果 |
  |---|---|---|---|
  | `CTRL_C_EVENT` | pgid | 无 handler | 存活（没投递） |
  | `CTRL_C_EVENT` | pgid | 有 handler | 存活，handler 未触发 |
  | `CTRL_BREAK_EVENT` | pgid | 无 handler | 终止，`0xC000013A` |
  | `CTRL_BREAK_EVENT` | pgid | 有 handler | handler 触发（`SIGBREAK`），进程继续 |

  即：**`CTRL_BREAK` 能定向投递，语义近 SIGQUIT**（默认终止、可拦截），
  而 `CTRL_C` 确实不能定向。两种事件下 API 都返回 TRUE、`GetLastError()==0`，
  所以「调用成功」不能当作「信号送到」的证据。
  job control 仍然不成立：没有前台组、没有挂起、`Proc::Async` 不暴露
  `CREATE_NEW_PROCESS_GROUP`（要走原生 `CreateProcess`）。这条能力记作
  「已验证、未采用」。
- **resize 仍轮询**：`term-size()` 每格查一次 `GetConsoleScreenBufferInfo`。
  `WINDOW_BUFFER_SIZE_EVENT` 需要常驻 console 输入监听线程，会和 Ctrl-C 的
  事件 tap 抢同一个输入队列，代价大于收益——明确不做（ADR-0010 §3.3）。
- **测试**：t/71（17 条，Windows 真机：结构体尺寸、归类、`TerminateJobObject`、
  `KILL_ON_JOB_CLOSE`、引擎孙进程在重启后被回收、句柄释放；POSIX 整段 skip）。

---

## 3.49 `!` 的测试夹具必须是真可执行文件（V-310，0.117.1）

**V-310**：`!` 只执行**真正的可执行文件**（argv-only，不经 shell，也不查
内置命令表），所以测试与文档示例不能拿 shell 内置命令当夹具。

- **现象**：t/65 用 `! echo hi` 验 notebook 的 `!` 路径。`echo` 在 cmd /
  PowerShell 里是内置命令、没有 `echo.exe`；只有 Git Bash 的 `usr/bin` 才带。
  于是同一份代码在 Git Bash 里全绿、在 PowerShell（或任何不含 Git `usr/bin`
  的 PATH）里 `zef install .` 红两条：`ok=false`、`out=""`。
- **夹具**：改用 `$*EXECUTABLE`（测试进程自己的 raku 路径）跑 `-e 'say 42'`。
  路径必须用**单引号**包住 —— `!` 的分词把双引号里的 `\` 当转义，
  `C:\rakudo\bin\raku.exe` 会被吃成 `C:rakudobinraku.exe`；单引号内不处理转义。
- **反面也锁住**：名字不是可执行文件时必须 `code=127` + `err` 带命令名
  （`Failed to spawn process ...: no such file or directory`），不允许出现
  `ok=true` / `out=""` 的假成功。这条同时说明「`!` 不认 shell 内置命令」
  是**规格**而不是平台缺陷；日常 `echo` / `cat` / `ls` 走 Shell 薄层的内置实现。
- **测试**：t/65 105 → 108 条（+3 反面断言）；在没有 Git `usr/bin` 的 PATH 上
  67 文件 / 3077 断言全绿。

---

## 3.50 脚本模式的 MAIN 分派（V-311，0.118.0）

**V-311**：`rakuish 文件 参数` 与 `raku 文件 参数` 的差别只剩「预加载了
DSL / 会话 Sys」。文件里有 `sub MAIN` 时，参数解析、类型强转、`multi MAIN`
候选、`--help`、`sub USAGE`、退出码全部交给 **Rakudo 自己的 `RUN-MAIN`**，
不抄第二套 CLI 解析。

- **为什么不用子进程**：`raku 文件` 能天然分派，但那样脚本就看不到 Rakuish
  预加载的 `sys` / `repl` / DSL（`echo` / `ls` / `open-data` …），还会多一次
  Rakudo 启动。保持「同一个词法环境」比省事更重要。
- **怎么拿到 `&MAIN`**：Rakudo 的分派绑在 mainline 上，EVAL 里定义 `MAIN`
  不会被调用（0.114 起只给一行提示）。但 `RUN-MAIN` 是个普通 sub，把 EVAL
  里的 `&MAIN` 显式交给它即可 —— 它内部仍然走 `ARGS-TO-CAPTURE` /
  `GENERATE-USAGE` / `USAGE` 这一整套，语义与真 mainline 逐字段一致。
- **尾巴必须在 EVAL 内部**：`RUN-MAIN` 用 `callframe(1).my` 取调用者的词法域
  里的 `&ARGS-TO-CAPTURE` / `&GENERATE-USAGE` / `&USAGE` / `&MAIN`。把
  `RUN-MAIN(...)` 追加到源码末尾，`callframe(1).my` 正好是脚本顶层 —— 脚本
  自定义的 `sub USAGE` 会被采用，顶层 `my %*SUB-MAIN-OPTS` 的动态作用域也
  还在。放到调用方（Session/CLI）就会丢掉这些。
- **软查找，不硬引用**：`::('&MAIN')` 在没有 MAIN 时返回 `Failure`。不能绑到
  `my &m`（`Type check failed: expected Callable`），也不能让它闲置 sink
  （程序结束时冒 "Earlier failure"）。做法是 `(::('&MAIN') !~~ Failure) &&
  RUN-MAIN(::('&MAIN'), Nil)`：认领 Failure、有才分派。
- **`$*PROGRAM-NAME` 用绝对路径**：Rakudo 2026.11 的默认 USAGE 生成器在程序名
  没有目录成分时（`raku foo.raku` 这种）会在 `strip_path_prefix` 里炸
  （`rindex search target requires a concrete string, but got null`）。脚本
  模式把 `$*PROGRAM` / `$*PROGRAM-NAME` 设成 `$file.absolute`，既绕开这个
  坑，也让脚本里以脚本为基准的相对 IO 更明确。
- **输出不捕获**：脚本的 `$*OUT` 直通终端。捕获模式（REPL 的 `Out[n]`）下，
  `MAIN` 里先 `say` 再 `exit 3`，退出时缓冲里的内容会一起丢 —— 实测过的坑。
  `-e` / REPL 仍然捕获，`set-code-stream` 只被 `eval-script` 打开。
- **Kernel 的 `script` 通道**：`kind<script>` 与 `source` 共用 `allow-source`
  策略门（拒绝一律 403）与审计口径（只记源码指纹 / 字节数，不记文本），但
  不走续行 / `!` / 会话命令那套 —— 它是「一次性程序」，不是「一格」。
  `capabilities` 的 `request-kinds` 增加 `script`。
- **口径与 `raku` 一致的地方（含不那么直觉的）**：
  · 顶层语句先执行，MAIN 之后执行，MAIN 能看到顶层 `my`；
  · 默认**命名参数必须在位置参数之前**（`42 --name=x` 里的 `--name` 会被当成
    第二个位置参数）；`%*SUB-MAIN-OPTS` 要 `my` 声明才能改这个默认；
  · 参数不匹配时用法打 stderr、退出码 2；`--help` 打 stdout、退出码 0；
  · 自定义 `sub USAGE` 会取代默认用法。
- **`source` 不跟**：会话里跑 `RUN-MAIN` 会因为用法错误直接 `exit 2` 把引擎
  带走；`source` 保持「按位置参数调用 MAIN」的 0.114 语义（§3.45）。
- **已知边界：`=finish` / `$=finish` 不可用**。finish 数据段是**编译单元**的
  属性，而脚本源码是在 `do { }` 里 EVAL 的，`=finish` 在块里直接报
  "Missing block"（0.118.0 之前就是这样，不是 MAIN 引入的回归）。需要数据段
  就用 `raku 文件` 或普通文件 IO。
- **上游怪癖（Rakudo 2026.11）**：**cwd 恰好是脚本所在目录**时，默认 USAGE
  生成器会抛 `rindex search target requires a concrete string, but got null`
  —— plain `raku 文件` 用同一个脚本、同一个目录同样复现（实测），所以
  Rakuish 不拦、不改写，保持与 `raku` 一致。绕开办法：换个目录运行，或在
  脚本里自带 `sub USAGE`。t/72 的 `invoke` 因此把 cwd 固定在仓库根。
- **测试**：t/72（42 条：顶层与 MAIN 的顺序 / 词法可见性、强转、命名与默认、
  命名位置顺序、multi、Bool 标志、缺参 USAGE、`--help`、`sub USAGE`、`exit 3`
  且输出保留、无 MAIN 回归、未闭合拒绝、DSL 可用、`script` 通道的策略与
  capabilities）。

---

## 3.51 二进制值的显示摘要（V-312，0.118.2）

**V-312**：`Buf` / `Blob` 进 `Out[n]` 时只显示摘要，不再打印完整元素列表。

- **问题**：`!fmt` 走 `.raku`，而 Buf 的 raku 是**全部元素**——
  `Buf.new(1..4000)` 是 14 250 字符，`slurp(:bin)` 一格就能把屏幕刷掉，
  还会原样进 `cells` 记录（`rendered` 字段与屏幕一致）。
- **格式**：`Buf[uint8] 4000 字节 · Arrow IPC 文件  0x<41 52 52 4F 57 31 …>`；
  空缓冲显示 `Buf 空`；超过 16 字节时尾部 ` …`。
- **只认 magic，不解析内容**：`ARROW1` 头 → 标注 Arrow IPC 文件（附
  `open-data` / `save-data` 的提示）。渲染是每格都要走的路，必须 O(1)；
  读结构是 `open-data` / `decode-ipc` 的**显式动作**，不在显示路径上做。
  也因此渲染层**不 require** `Arrow::IPC` 或 `Rakuish::Data::Arrow`——
  不把编解码依赖拖进每一次回车。
- **类型名归一**：`'x'.encode` 的 `WHAT` 是裸别名 `utf8` / `utf16`，直接印
  出来像编码名；补成 `Buf[utf8]`，与 `Buf[uint8]` 同一读法。`Blob.new`
  保持 `Blob`。
- **只改显示**：`_` / `Out[n]` 里仍是原 `Buf`，`.elems` 不截断；t/73 断言
  「4 000 字节的值渲染成 75 字符，但值本身仍是 4 000 元素的 Blob」。
- **测试**：t/73（16 条：长度有界、前 16 字节十六进制、省略号、空缓冲、
  utf8 别名、Blob、ARROW1 标注与真实字节数、值未被截断、整数/数组回归）。

---

## 3.52 Arrow 读侧改走 Arrow::IPC（V-313，0.118.3）

**V-313**：`open-data` 的 `.arrow` / `.feather` / `.ipc` 读侧交给独立包
`Arrow::IPC`；写侧与内存 `Buf` 读仍由 `Rakuish::Data::Arrow` 负责。

- **为什么换读侧**：0.116.0 自研的那份明确拒绝 `List` / `Struct` / `Map` 与
  字典编码，而 `Arrow::IPC` 0.1.0 支持这些，且是纯 Raku、**零运行依赖**。
  读侧 API 是「路径 → names / formats / cols」，适配成 `Table` 约 90 行。
- **为什么写侧不换**：`write-ipc` 吃 Arrow C Data 视图（`.schema` /
  `.chunks(&code)`，schema 节点要 `.addr`、chunk 列要能取 `ArrowArray`）。
  `Table` 没有这套视图；要喂进去得先写 CData 导出器（手工分配指针 + release
  回调），代码量与崩溃面都超过现有纯 Raku 写入器。等上游提供「普通列数据写入」再合并。
- **内存 `Buf` 读不换**：`Arrow::IPC` 只提供路径入口，没有 `Buf` 解码 API；
  `read-ipc($buf)` 继续用自研实现（t/70 仍覆盖它）。
- **语义还原**：`decode-ipc` 给的是格式化字符串。适配层把 `date` / `timestamp`
  还原成 `DateTime`（空格换 `T` 再解析）、`time` 换算成当天秒数、`decimal` 还原成
  `Rat`、`duration` 保留原单位数值；`struct` / `map` 对象转成 `Hash`。
  **还原失败就把字符串原样留下、列类型退回 `str`**，不伪装成 datetime/num。
- **压缩必须拦截**：`Arrow::IPC` 0.1.0 完全不处理 `BodyCompression`，也**不报错**
  —— 实测 `compressed.arrow`（真值 `[1,2,3]`）解出 `24 / 46469901123040552 /
  844433520156672`。读之前用 `ipc-compressed-file` 扫 Footer 的 block 偏移与
  RecordBatch 第 4 个字段，命中就抛 `X::Rakuish::Unsupported`。代价是文件读两遍
  （检测 + 解码）；静默错数据比多读一遍危险。
- **依赖**：`META6.json` 增 `Arrow::IPC:ver<0.1.0+>`（纯 Raku，不引入原生库）；
  缺失时 `open-data` 给出 `zef install Arrow::IPC` 的提示，不抛 No such method。
  **口径（0.134.0 明确）**：它是**硬 `depends`**，但只有「嵌套 / 字典编码的
  `.arrow`」这条回退路径真正调用它 —— 标量列走自研读入器或 DuckDB 快路，
  从不碰 `Arrow::IPC`。之所以仍列硬依赖：它是同作者的配套包（纯 Raku、无原生库），
  而「装了却读不了嵌套 arrow」比「多装一个纯 Raku 包」更糟；README 的依赖段已同步列全 4 个（t/51 守）。
- **测试**：t/74（34 条：basic / 流格式 / 各类标量 / time·duration·带时区时间·
  date / list·struct·map·字典 / 空表 / 压缩拦截 / 检测函数 / 写读往返 / `--raw`）。
  t/70 的 68 条继续覆盖写侧与 `Buf` 读。
- **0.120.1 起改为分流**（V-316，见 §3.55）：标量文件不再走本包的 `decode-ipc`，
  只有嵌套 / 字典等「自研没实现」的类型才回退到这里。

---

## 3.55 Arrow 读侧按类型分流 + 坏文件护栏（V-316，0.120.1）

**V-316**：`open-data` 的 `.arrow` 先把字节交给自研读入器；只有它明确报
「文件合法、但这个类型没实现」（`X::Rakuish::Arrow::UnsupportedType`）才回退
到 `Arrow::IPC`。**解析失败绝不回退。**

- **为什么改**：0.118.3 把读侧整个交给 `Arrow::IPC`，实测两个问题。
  ① **会段错误**：`decode-ipc` 对越界元数据没有边界检查，坏文件直接 SIGSEGV
  （截断到一半 600 KB、Duckula 0.33.1 的 `ipc-buf` 产物都是 rc=139），
  段错误连 `try` 都接不住 —— 一次坏文件 = 整个 REPL 没了。
  ② **慢**：5 万行 × 5 列，`decode-ipc` 14.5 s + 适配 5.5 s ≈ 20 s；
  自研读入器 4.2 s（约 4.6 倍差距）。
- **分流规则**：`read-ipc-file` 成功 → 直接用；抛
  `X::Rakuish::Arrow::UnsupportedType`（嵌套 / 字典 / 压缩）→ 才 `require
  Arrow::IPC` 走包；其它异常（越界、截断、坏 FlatBuffers）→ 原样抛出。
  这条规则把「坏字节」挡在会崩的解析器之外，同时让常见标量文件走快路径。
- **异常分类**：新增 `X::Rakuish::Arrow::UnsupportedType is X::Rakuish::Arrow`。
  自研读入器的 4 处「暂不支持」改抛它：字典字段、未知类型 kind、字典批、
  `BodyCompression`。结构错误仍抛 `X::Rakuish::Arrow`。
- **顺带修的错**：`ipc-format` 里 `my %m = try { read-message(...) }` 会在
  **try 之外**抛 `X::Hash::Store::OddNumber`（把 Nil / 奇数长度 List 塞进 Hash），
  于是「文本文件改名 `.arrow`」得到的是一条看不懂的哈希错误。现在先绑标量、
  判完类型再取值，报「不是 Arrow IPC 数据」。
- **语义不变**：两条路径对 `kinds.arrow` / `temporal.arrow` 的列类型与首行值
  逐项一致（int/num/str/bool/datetime、time 秒数、duration 原单位、decimal Rat）。
- **依赖**：`Arrow::IPC` 仍是 `depends`（嵌套文件要用），但标量读取不再加载它。
- **测试**：t/74 增 8 条（嵌套归类为 UnsupportedType、回退仍可读、截断文件
  干净报错且不被标成 UnsupportedType、文本伪装 `.arrow`）；共 42 条。

---

## 3.53 Windows 上 Ctrl-C 只收外部命令（V-314，0.119.0）

**V-314**：`!` 外部命令运行期间按 Ctrl-C，只终止这条命令的进程子树，
**引擎不重启、会话状态不丢**，退出码报 130。

- **问题**：旧行为是父进程收到 SIGINT 就 `SIGKILL` 引擎并重启（约 4~5 秒），
  `Out[n]` 从 1 重来、变量丢失；重启窗口里敲的键被控制台缓存，回来时行编辑器
  按旧光标重绘 —— 用户看到「卡死 + 输入错位」。
- **根因**：Windows 没有 POSIX 前台进程组；Raku 给子进程建了**独立进程组**，
  控制台的 `CTRL_C_EVENT` 只到宿主与引擎，**到不了命令**。所以「让子进程自己
  退出」和「引擎侧的 signal tap」都等不到信号，旧代码只能杀引擎。
- **做法**：引擎 spawn 成功后把 pid 通过 `child` 帧发给前端；前端
  `CreateJobObject` + `OpenProcess` + `AssignProcessToJobObject` 把这条命令收进
  **命令级 job**。Ctrl-C → `TerminateJobObject`，命令与孙进程一起收掉，`exec`
  正常返回；终帧把 `code` 改成 130（128+SIGINT）、`ok=false`。
- **兜底**：3 秒内还没回来（job 建不起来 / 命令拖住终止）才回到「杀引擎重启」，
  保证不会永久卡死。job 创建或归类失败时静默降级，不拒绝执行命令。
- **不变的部分**：Raku 求值（`sleep 60`、`loop {}`）没有子进程，仍按 §3.21
  杀引擎重启；`! --tty` 期间信号仍归前台子进程（ADR-0010 §3.3）。
- **验证**：`tools/ctrl-c-win.py` 新增场景三（ConPTY 真控制台）：
  `killed_engine=False`、`prompt_back`、`exit_130`、`state_survived` 全过；
  场景一（`loop {}`）与场景二（`! --tty`）同时复跑通过。

---

## 3.54 Table 上跑 SQL：DuckDB / Duckula 联合（V-315，0.120.0）

**V-315**：`Table.sql($query)` 把表交给 DuckDB 执行 SQL，结果仍是 `Table`；
多表用 `Rakuish::Data::Duck::query(%tables, $sql)`。

```raku
my $t = open-data('events.arrow');           # Arrow::IPC 解码（§3.52）
$t.sql('select kind, count(*) c from t group by 1 order by c desc');
sql($t, 'select ...');                        # 同上的短命令形态
sql({ a => $t1, b => $t2 }, 'select * from a join b using (k)');
```

- **表名**：单表默认 `t`（`:name` 可改）；`%tables` 的键就是 SQL 里的表名。
  名字必须是 SQL 标识符（字母/数字/下划线、非数字开头），否则拒绝 ——
  名字会拼进会话，不做转义猜测。
- **分工**：读 `.arrow` → `Arrow::IPC`；写 `.arrow` → `Rakuish::Data::Arrow`；
  计算 → Duckula 的 `Session` / `Frame`。
- **交换方式（0.134.0 改）**：~~桥用 `$*TMPDIR` 下的临时 Arrow 文件做交换~~
  → 现在**不写任何临时文件**：从 `Table` 的 `columns` / `types` 生成
  `CREATE TABLE` DDL（标识符双写引号转义），再用 `Duckula::Session.insert`
  （Appender）逐行写，然后执行用户 SQL。类型映射固定
  `int→BIGINT`、`num→DOUBLE`、`str/any→VARCHAR`、`bool→BOOLEAN`、
  `datetime→TIMESTAMP`；值按声明类型转换，`NULL` 传 `Any`。
  5 万行 × 5 列稳态 4,797 ms → ~1,530 ms（3.1×）；`t/76` 断言临时文件数为 0。
  细节与踩坑见 ADR-0043 §7。
- **超 int64 明确报错**（0.134.0）：老路径的写侧会**静默溢出**成负数；直插后
  DuckDB 直接报 `Could not convert string ... to INT64`。这是行为修正，
  `t/76` 已钉住「报错 + 原表不被改写」。
- **回读不走 IPC**：`Frame.ipc-buf` 在 Duckula 0.33.1 上对 **TIMESTAMP WITH TIME
  ZONE** 列产出坏字节流（pyarrow 报 Not an Arrow file / Invalid flatbuffers，
  `Arrow::IPC` 解码段错误 rc=139），所以结果从 `Frame.rows` + `Frame.dtypes`
  还原，不碰那条路径（ADR-0043）。0.121.0 逐列复核过：BIGINT / DOUBLE / BOOLEAN /
  VARCHAR / DATE / TIME / DECIMAL 都正常，只有带时区的 timestamp 坏；已按此
  整理成上游 issue（`tmp/upstream-issues/`）。
- **类型还原**：DuckDB `TIMESTAMP*` / `DATE` → `DateTime`（整列有一格解析失败
  就整列退回 `str`）；`TINYINT…HUGEINT`/无符号整数 → `int`；
  `DECIMAL`/`DOUBLE`/`FLOAT`/`REAL` → `num`；`BOOLEAN` → `bool`；
  `VARCHAR` 等 → `str`；`xxx[]` → `list`；`STRUCT`/`MAP`/`UNION` → `map`。
- **NULL**：SQL `NULL` 回到 `Table` 是 `undef`，不替换成 0 / 空串；列类型不变。
- **只读**：Duckula 的守卫拒绝 `DROP` / `INSERT` 等写语句，错误转成
  `X::Rakuish::Data` 并保留原文（`statement is not read-only`）。
- **嵌套列**：`Table` 没有嵌套类型表达式，进 SQL 前显式 `to-json` 成文本列
  （类型记 `str`）；可以 `like`、可以 `from-json` 解回，但不能在 SQL 里取
  struct 字段 —— 如实的能力边界。
- **写侧拒嵌套**：`fields-of` 对 `list` / `map`（以及类型标错、值为嵌套结构的
  列）抛 `X::Rakuish::Arrow`，不再落进 `default → utf8` 写成 `.Str` 噪声。
- **可选依赖**：Duckula 不在 `depends`，`Table.sql` 走运行时 `require`；
  缺失时抛 `X::Rakuish::Unsupported` 并提示 `zef install Duckula`。
- **测试**：t/76（43 条：聚合 / 计算列 / NULL / 浮点序 / 空表 / 时间往返 /
  多表 left join / 嵌套转 JSON / 只读守卫 / 非法表名 / 空 SQL / 原表不可变 /
  临时文件清理 / 写侧拒嵌套）。

---

## 3.56 Arrow 写侧：多批与流式（V-317，0.121.0）

**V-317**：写侧原来只有「整表 → 一个 RecordBatch → 一份 `Buf`」这一条路
（0.116.0 / ADR-0038）。50 万行时峰值内存 ≈ 表本身 + 整份文件，而且生成的
文件只有一个批，别的工具想并行扫描只能整块读。

0.121.0 把写入器拆成 `start / add-batch / finish`（`Rakuish::Data::Arrow::IpWriter`），
对外三个入口：

```raku
write-ipc($t);                          # 一个批（0.120 及以前的行为，不变）
write-ipc($t, :batch-size(1000));       # 多批，编码峰值 = 一批
write-ipc-file($t, 'a.arrow', :batch-size(1000));
write-ipc-stream($rows, 'a.arrow');      # 真流式：边拉边写，不物化全表
write-ipc-stream($t.batches(:size(5000)), 'a.arrow', :batch-size(5000));
```

- **批边界**：`batch-size` 是每个 RecordBatch 的行数；最后一批可以更小。
  `batch-size ≥ 行数` 或省略 → 一批（与旧行为逐字节同构）。`batch-size=0`
  明确报错，不隐式当 1。
- **流式源**：接受「行的迭代器」（Hash / Pair，攒够 `batch-size` 行就编一批）
  或「`Table` 的迭代器」（每张表按 `batch-size` 再切）。两种都只保留一批在
  内存里；返回写入的总行数。
- **schema 只推断一次**：流式的第一批决定列与类型（列顺序按 `Table` 的规则：
  首行键排序，与 `save-data` 从 rows 建表一致），之后每批复用。**不能回改**。
- **类型冲突必须报错**：`"abc".Int` 在 Raku 里是 `0`（不抛），流式若放任
  `cast` 就是把脏数据写进文件。`check-batch` 在每批编码前逐列核类型，
  不符抛 `X::Rakuish::Arrow`，消息带「第几行 / 列名 / 期望类型 / 实际类型」。
  中途出现 `Positional` / `Associative`（嵌套值）同样拒绝，不给 `.Str` 噪声。
- **表流列必须一致**：第二张表少一列或多一列都报错，不静默补 `null`。
- **空流**：没有行就无法推断 schema → 报错并说明出路（`save-data` 写空表，
  或给 `:columns`）。给了 `:columns` 就写一个 0 行的合法文件。
- **落盘原子性**：`write-ipc-file` / `write-ipc-stream` 先写 `<名字>.part`，
  成功后才改名为目标；失败（类型冲突、磁盘满）不会留下半截 Arrow 文件，
  `.part` 由 `LEAVE` 清掉。t/77 对此有断言。
- **`save-data` 透传**：`save-data('x.arrow', $t, :batch-size(400))`。
- **诊断**：`ipc-batch-count($buf)` 直接数批（文件读 Footer 的 Block 向量，
  流数消息头），不用装 pyarrow 也能确认「确实是 3 批」。
- **实测**（Windows，Rakudo 2026.11）：

  | 场景 | 耗时 | 文件 |
  |---|---|---|
  | 5 万行 × 3 列，单批 | 2.65 s | 1.44 MB |
  | 5 万行 × 3 列，10 批 | 2.70 s | 1.44 MB |
  | 50 万行 × 3 列，100 批（流式） | 23.9 s | 14.9 MB |

  多批相比单批几乎没有额外开销（除首批外的 Table 构造已省掉，否则 50 万行
  多花约 8 秒）。pyarrow 26 读回：`num_record_batches` = 100、行数/列类型全对。
- **坑**（Rakudo 2026.11）：
  - `$x =:= IterationEnd` **返回 False**（`IterationEnd.WHAT` 是 `Mu`，
    但 `=:=` 不比同一个值）。判耗尽要写 `$x ~~ IterationEnd`。
  - block（`-> $x { ... }`）里的 `return` 是 **non-local**，会直接返回外层
    `sub`。流式循环最初在 `flush` 里写 `return unless @pending.elems`，结果
    第一批写完整个函数就返回、文件都没落地。block 内一律用 `if` 包裹。
  - `($first, |$iter)` 对 `Iterator` 做 slip，元素会变成 `List`
    （`$t.rows` 立刻炸）。手写 `pull-one` 循环。
- **测试**：t/77（46 条：批数边界 / 文件与流格式 / `save-data` 透传 /
  行流与表流 / 类型冲突与嵌套 / 空流 / 列不一致 / 失败不留文件）。

---

## 3.57 .arrow 读侧：标量列交给 DuckDB（V-318，0.122.0）

**V-318**：读 `.arrow` 一直是 Rakuish 自己解码（0.116 自研、0.118.3 换
Arrow::IPC、0.120.1 再分流回自研）。但这条路上的数据最终要进 `Table`、要能
`sql` —— 而 SQL 那头本来就有 DuckDB。等于「Raku 把字节解成值，DuckDB 再装
回去」。0.122.0 把标量列的那一半交还给 DuckDB。

### 分流

```
open-data('x.arrow')
 ├─ 只读 schema（ipc-column-kinds-file：file 只读尾部 Footer，
 │   流只读开头 64KB）—— 大文件不为「看一眼类型」整份进内存
 ├─ 类型全在白名单 && (文件 ≥ 1 MB 或 压缩)？
 │    └─ Duckula.read-arrow → CREATE TEMP TABLE AS SELECT * FROM read_arrow(?)
 │       → table-from-frame（与 Table.sql 结果同一套类型口径）
 └─ 否则：原路（自研读入器 → UnsupportedType 才回退 Arrow::IPC）
```

- **这是纯优化，不是新语义**：白名单是按「两条路逐值 `eqv`」验证出来的
  （t/78 逐列断言），不在名单里的一律走原路。名单：
  `int / float / bool / utf8 / date / timestamp(无时区) / decimal`。
- **不进来的五类**（每条都有实测理由）：
  - `time` / `duration`：自研读入器给「秒数」，DuckDB 给 `"01:02:03"` 文本；
  - `timestamp` 带时区：DuckDB 保留 `+08:00` 偏移，自研读入器归一到 UTC；
  - `binary`：自研给 `Buf`，SQL 出口是带 `\x` 转义的 `Str`；
  - 嵌套（list / struct / map）与字典：SQL 出口只剩文本渲染。
    真正的旁路要用 `DB::DuckDB::Arrow` 的 C data 逐层读，留到后面单独做。
- **1 MB 阈值**：DuckDB 那条链首次使用要装载 libduckdb + Duckula + nanoarrow
  （实测约 0.7 s），小文件走快路反而更慢。**压缩文件是例外** —— 自研读入器
  不解压，交给 DuckDB 是唯一能读的路，所以无脑走快路。
- **静默回落**：Duckula / DB::DuckDB / nanoarrow 缺一个，或者读失败，都返回
  到原路，不向用户抛新错误。`Rakuish::Data::Duck::arrow-native-available`
  把「三者齐不齐」按进程缓存，测试与错误信息都靠它。
- **开关**（排查 / 测试）：`RAKUISH_ARROW_NATIVE=1` 强制快路（不看体积），
  `RAKUISH_ARROW_RAKU=1` 强制原路。

### 顺带修掉的一处精度问题

老路把 timestamp 的秒数用 `Num` 传给 `Instant.from-posix`，毫秒会变成
`…59.12300006`；DuckDB 那条路给的是 `…59.123`。两条路必须逐值一致，所以
改成直接传 `Rat`（`$v / 1000` 本来就是精确的 Rat，别 `.Num`）。

### 顺带修掉的一处上游 bug（DB::DuckDB 1.3.1）

`decimal` 最初也被挡在白名单外，因为经过 DuckDB 读出来是错的：

```
(-0.0001)::DECIMAL(20,4)  →  34028236692093846346337460743176821.1455
```

原因是 `DB::DuckDB::ColumnView.int64` 拼 128 位时把高字当无符号读，补码负数
（高字全 1）就变成天文数字。`Result.hashes` / `Result.row` 走 DuckDB 的文本
转换，所以一直是对的 —— 只有从 `ColumnView` 物化列（Duckula 的 `Frame.rows`、
以及 Rakuish 的 `Table.sql` 结果）才会踩到。1.3.1 按补码修好后 `decimal` 才
进白名单，t/78 与 DB::DuckDB 的 `t/03` 各有一条「负 DECIMAL」断言钉住。

### 能力变化

- **压缩的标量 Arrow 现在能读**（以前直接抛 `BodyCompression`）。压缩 + 嵌套
  仍报错，错误里给出安装提示与「先用 duckdb 解压」的出路。
- **实测**（Windows，Rakudo 2026.11）：

  | 场景 | 原路 | 快路 |
  |---|---:|---:|
  | 5 万行 × 3 列（1.44 MB） | 2.60 s | 1.2–1.6 s |
  | 50 万行 × 3 列（14.9 MB） | 23.4 s | 13.1 s |
  | 3 行小文件 | 0.02 s | 0.10 s（首次还要 +0.7 s 装载） |

  剩下的开销几乎全在「把列物化成 Raku 的 `Hash`」：`Frame.rows` 50 万行
  约 6 s、`table-from-columns` 约 4 s，而 DuckDB 真正读文件只花 20–300 ms。
  也就是说**这一版之后瓶颈已经不是 Arrow 解码**，是 `Table` 的行式模型 ——
  再要提速只有 C data 直读（少一层 `Array`/`Hash` 中转）。
- **测试**：t/78（35 条：schema 扫描、8 份文件两路逐值一致、压缩可读、
  负 DECIMAL 不被解错、空文件、小数秒精度）；t/74 的压缩断言改成
  「标量列能读 / 纯 Raku 读入器仍拒绝」。

---

## 3.58 对标 IPython 的 P0 修复（V-319…V-325，0.123.0）

> 输入：`docs/REVIEW-VS-IPYTHON-2026-11-24.md`（0.122.3 对标评审）。本节七条全部是
> **行为订正**，不新增产品方向；每条在 0.122.3 上都可复现，`t/79` 逐条反向断言钉住。

**V-319**：前奏（每格重放的声明缓存）里，**`%STATE` 别名必须先于声明**。
声明体可以引用会话变量（`my $n = 10` 之后 `sub f { $n }`）；旧顺序把声明放在
别名之前，于是第二格起重放时 sub 先于 `$n` 编译，报
`Variable '$n' is not declared`，且此后**每一格**都在同一处失败（会话被锁死）。
别名不引用任何声明，整体前置安全。`t/79` 覆盖单变量、多变量与「声明之后仍能
继续求值」三种形态。

**V-320**：**纯声明格不占 `Out[n]`、不进 `_`、不渲染值**。
纯 `sub` / `use` 格过去会显示 `Out[n] = sub f (...) {...}` 并吞掉一个编号，
与 IPython 的 `def` 不一致（`def` 只推进输入序）。输入序仍由 `!finish` 的
`@!history` / `$!cell-seq` 记录，所以跳过格号不会让历史断号。
失败格不占号的既有契约不变（`t/07`）。

**V-321**：**内省是只读查询**。`名字?` 内部复用 `doc`（Shell 命令），旧路径会
`$!index++` 且 `!remember`，导致 `ls?` 之后 `_` 变成字符串 `"ls"`、`Out[n]`
跳号 —— 既违反 V-299 的「不占格」宣称，也在用户查错时改变结果历史。
`Session.inspect-name` 在调用点隔离格号与 `@!out`；`history` 仍记这一行。

**V-322**：**`In[n]` 是输入历史**，与 `Out[n]` 对称（下标从 1 开始，第 0 位
是占位）。`In` 只在当前格的 EVAL 作用域可见，不重放、无副作用；当前行要等
`!finish` 才进 history，所以 `In` 永远指「这一格之前」。
`In[` / `Out[` 的补全分别按 `@!history.elems` 与 `@!out.elems` 计算 ——
失败格与会话命令进 history 但不进 `@!out`，两者长度本来就会分叉。

**V-323**：**`display` 描述值，`out` 描述 stdout**。
`op=eval` 且值存在时，展示包的正文是值；stdout 仍走响应的 `out` 字段。
`out` 只在「op 不是 eval」或「eval 没有值」时充当正文（`ls` / `doc` 这类命令
的输出就是它的展示）。`Bundle.to-hash` 的 `meta.source` 如实标注来源：
`value` / `out` / `error` / `empty`；Jupyter 桥据此决定发不发 `execute_result`
（`out` 已经作为 stream 发过，不能再发一次）。
旧行为下 `say "hi"; 42` 的 42 永远到不了前端，且 stdout 会被显示两遍。

**V-324**：**展示层不得因序列化失败杀死引擎**。
`Bundle` 的 JSON 档先探测可序列化性（`Complex` / `Sub` / 自定义对象会在
`JSON::Fast` 抛），不可序列化时 `application/json` 与 `formats` 都**不提供**
该档（不伪装成功）；`Bundle.render('json')` 降级为 `text`。
`Eval::Server.result-frame` 对 `bundle-from` 再加一层 `try`，
`emit` 在 `to-json` 失败时回一个错误帧而不是抛穿 `serve-engine`。
实测：`3+4i`、自定义类实例不再触发「引擎已重启」。

**V-325**：文档与脚本的可执行性属于契约。
`README` 的哈希示例必须带 `my`（`%h = a => 7` 在 Raku 里是未声明变量，跑不通）；
`tools/install.sh` 不得引用已删除的 `bin/rakuish-agent` / `--agent`，
依赖说明不得再写「只有 JSON::Fast」。`t/79` 对这三条做静态断言。

---

## 3.59 显示协议 P1：对象级 MIME 与 `display()`（V-326…V-330，0.124.0 / ADR-0048）

> 输入：ADR-0048（P1 范围）。目标是把显示从「Session 里的九个分支」换成
> 「值自己声明的 MIME 包」，同时不改变旧值的内置识别与 TTY 字节数。

**V-326**：**`to-mime` 鸭子类型**。任意值实现 `method to-mime(--> Hash)` 即可
声明自己的 MIME 档（`MIME => payload`）。分派顺序：**`to-mime` 优先**于内置识别
（Table / 记录集 / 路径 / Hash / 标量）；`to-mime` 抛异常或返回非 Hash 时
**静默降级**到内置识别（展示层不得把异常带到 `Eval::Server.emit`）。
`text/plain` 缺失时用值的 `.Str` 兜底；连 `.Str` 都没有时用
`[mime]` 摘要占位，保证 TTY 不空白。junction 必须排除在探测之外
（`.defined` / `.can` / 方法调用都会 autothread）。

**V-327**：**额外 MIME 透传**。`Bundle` 新增 `%.extra-mime`；`available` /
`has` / `pick` / `render` / `to-mime` 五处对额外档口径一致：能取到、能协商、
能列出。`application/json` 仍是「可序列化才提供」——解析失败不列该档
（V-324 的原则不因多档而放宽）。

**V-328**：**`display($value)`**。语义是语句，不是值：
- TTY / 管道 / 脚本：立即把 bundle 的 `text` 写 stdout（终端降级），
  不产生 `Out[n]` 条目、不改变 `_`；
- notebook（`want-display` 为真）：把 `Bundle.to-hash(:mime)` 收集进会话，
  随结果帧交给前端，由前端发 `display_data`；
- 返回值是哨兵 `Rakuish::Display::Shown`。`Session` 的 `!remember` / `render` /
  `bundle-from` 三处统一忽略它 —— 因为 Raku 没有 `None`，返回 `Nil` 会把 `_`
  改成 Nil（V-321 同一条原则）。
- `:$id` 为 P3 的 `update_display_data` 预留，P1 忽略。

**V-329**：**包装类型**：`HTML` / `Markdown` / `JSON`（`Rakuish::DSL` 导出）。
`HTML` 同时给 `text/html` 与去标签的 `text/plain`；`Markdown` 给
`text/markdown` + 原文 `text/plain`；`JSON` 给紧凑 `application/json` 与展开的
`text/plain`。终端只显示降级文本，不打印标签 / 不打印二进制。

**V-330**：**notebook 一次执行可带多条展示**。引擎结果帧的 `display` 可含
`displays`（按调用顺序）；`Kernel::Notebook` 原样透传；Jupyter 桥在
`execute_result` 之前逐条发 `display_data`。cell 末尾的值仍是 `execute_result`，
`display()` 不冒充结果。没有 `displays` 键时旧前端行为完全不变。

---

## 3.60 Windows 环境变量大小写与 PATH 解析（V-331，0.129.1）

**V-331**：Windows 的环境变量名大小写不敏感，但 Rakudo 的 `%*ENV` 是普通 Hash。
两者错位会让「本机能跑、别的机器也绿」的功能在特定机器上整体失效：

- 进程环境里 PATH 的键名是 **`Path`**（`PATHEXT` 却是全大写）。以前
  `! which` 与 `path-executables()` 直接读 `%*ENV<PATH>`，得到 Nil：
  `which cmd` 报「未找到」，`! ` 的 PATH 补全表整张为空，而 `--tty` 外部
  程序补全同样静默失效。`t/10` 的 `which cmd` / `PATH 可执行文件扫描非空`
  两条断言在这种机器上必红（zef 装不上）。
- 修复口径收敛到一处：`Rakuish::Sys::env-var($name)` 先按字面查，未命中且
  在 Windows 上再按 `lc` 扫一遍键（POSIX 行为不变）。`Shell::!cmd-which` /
  `Shell::path-executables` / `Session::!path-names` 全部改走它；
  `which` 同时改读**会话** env（`get-env`），这样 `export PATH=...` 仍然生效。
- `Sys.get-env` / `set-env` / `unset-env` 在 Windows 上也按同一口径匹配键：
  `export PATH=...` 覆盖的是 `Path` 而不是新增一个 `PATH`；`%.env` 里不会
  出现仅大小写不同的重复键。
- 同一类问题的第二处：Windows 进程环境没有 `HOME`（只有 `USERPROFILE`），
  而 Rakudo 的 `$*HOME`、`~` 展开一直可用。会话 env 照抄 `%*ENV` 后，
  `echo $HOME` 因「不是会话变量」退回 Raku，报 `Variable '$HOME' is not
  declared`——同一个 home，`cd ~` 能走、`$HOME` 不能。现在 `Sys` 初始化
  `%.env` 时仅在 Windows 且进程未给 `HOME` 时补一条 `$*HOME`；显式
  `:env(...)` 仍完全覆盖，不注入。
- 测试：`t/10` 直接断言 `env-var('PATH')` 命中进程里那个键的值（大小写无关），
  `which cmd` 与 PATH 扫描恢复；`t/02` 在 Windows 上断言 get/set/unset 的
  大小写不敏感且不产生重复键；`t/45` 的 `echo $HOME` 重新成立。
- 0.141.1 补记：`t/10` 那条「大小写不敏感」断言**必须按平台分支**。0.129.1
  起它无条件跑，在本机（Windows，键名 `Path`）为真，在 Linux 的
  `zef install .` 上恒红（期望整条 `PATH`，实得 `''`）—— 因为 POSIX 的环境
  变量名大小写敏感，`env-var('path')` 就该是空串。现在 Windows 断
  「`env-var('path')` 等于 PATH」，POSIX 断「不跨大小写偷值」。

---

## 3.61 Windows cmd 内建（V-332，0.130.0 / ADR-0049）

**V-332**：`!` 在 Windows 上遇到 cmd.exe 内建（`echo` / `dir` / `type` / `copy` /
`set` / …）时，回落到 `cmd.exe /d /c`；`!` 仍是 argv-only。

- 背景：这些名字**没有同名 exe**，`Proc::Async`（CreateProcess）必然 ENOENT，
  `! echo hi` 只能得到 `[exit=127] Failed to spawn process echo`（评审 §4.9 j）。
- 触发条件（全部满足）：Windows；argv[0] 不含 `/` / `\`；命中固定白名单
  （`echo ver vol cls title color date time chcp dir type copy move del erase
  md rd ren set path mklink`）；PATH 与当前目录都没有同名文件或 `.exe`。
  同名 exe 优先，白名单不会盖住真实程序。
- 重写形态：`cmd.exe /d /c <line>`，`line` 由已分好的 argv 逐 token 把
  `& | < > ^ ( ) %` 前置 `^` 转义后以空格拼接。因此 `! echo a & b` 打印
  `a & b`、`! echo a>b` 打印 `a>b`（不重定向）、`! echo %PATH%` 打印
  `%PATH%`（**不展开**）——V-123「完全 argv-only、无 shell 解释」不变。
- 参数含 `"` / `\r` / `\n` / NUL 时**不回落**，保留原生 127（cmd 对这些
  没有可靠转义，宁可报原始错误）。
- token 以 `\` 结尾时（`! dir C:\`），整行末尾补一个空格，避免命令行收尾
  引号被反斜杠吃掉；代价是 `echo` 类输出多一个尾随空格。
- 边界：不做 `for` / `if` / `goto` / `start` / `&&` / 管道 / 重定向；
  不接管 `cd` / `pushd` / `exit`；`! --tty` 不经过这层；`Sys.exec`（含 DSL /
  脚本）**不加**这层回落。
- 测试：`t/10`（Windows 段）覆盖 `! echo hi`、`&` 字面量、`>` 不写文件、
  `%VAR%` 不展开、`! dir /b`、非白名单仍失败；Linux 段整体跳过。
- 0.141.1 补记：`! dir /b` 这条要按「回落会不会生效」分支。有的机器 PATH 上
  真有 `dir.exe`（Git for Windows / MSYS 的 coreutils），按「同名 exe 优先」
  回落不参与，此时断言「交给 `cmd.exe`」的前提不成立（0.140.0 实测红）。
  断言改为：先问 `win-cmd-builtin-argv('dir', ('/b',))` 是否给出 argv ——
  给出就断「spawn 的是 `cmd.exe` 且列出 `a.txt`」，没给出就断「spawn 的是
  `dir` 本身、argv 原样两项」。

---

## 3.62 前奏按需裁剪（V-333，0.131.0 / ADR-0050）

**V-333**：跨格持久化的前奏（`%STATE` 别名 + 声明重放）按「本格会用到」裁剪。

- 背景：以前每格把所有声明与全部变量别名拼进源码再 `EVAL`，成本随会话长度
  线性增长（评审实测 40 个 sub 后 ~109 ms/格，干净会话 ~5 ms）。
- 别名：只为「本格源码 + 本次重放的声明源码」里出现过的变量名生成
  `my $x := %STATE<'$x'>;`。
- 声明：只为「本格点名的声明」及其源码里点名的声明（**传递闭包**）重放，
  输出保持 `@!decls` 原顺序（依赖序）。f 调 g ⇒ 重放 f 必带 g；没被点名的
  f 不需要在场。
- 总是重放：`use`（编译期导入）；名字不是普通标识符的声明（`sub infix:<+>`
  这类，格内是运算符不是名字）；`enum` / `subset` 沿用原行为。
- 安全前提（实测）：跨 EVAL 的**值**仍可调方法（方法编译期已绑定），所以
  「值带着会话类型」不需要重放那个类；只有源码点了类型名才重放。
- 过近似：token 集合用宽正则（字符串/注释里的名字也收），只多留不少留；
  动态拼名字（`::('f')`）无法静态解析，字面量出现时仍会被收进集合。
- 观测：`Session.prelude-aliases` / `prelude-decls` 记录上一格实际生成 /
  重放的条数（测试与 perf 排查用，不是语义契约）。
- 边界：`enum` / `subset` 的跨格重放本身有既有缺陷（第二格起
  `Redeclaration of symbol`），与本条无关；「命名空间近似」的结构问题仍在
  （评审 §3.2b），本条只优化重放成本。
- 实测（本机 40 声明均值）：40 vars 62 → 13 ms；40 subs 48 → 13 ms；
  10 classes 70 → 9 ms；干净会话 ~10–13 ms。
- 测试：`t/05` 计数断言（decls 0/1/2、aliases 0/1/2、闭包、use 常重放、
  类依赖）。

---

## 3.63 裸 enum / subset / constant 的声明作用域（V-334，0.132.1）

**V-334**：跨格声明里的 `enum` / `subset` / `constant` 与 `class` / `role` /
`grammar` 同口径——扫描时统一改写成 `my`，重放旧快照里的裸声明时也补 `my`。

- 症状：裸 `enum Color <Red Green>` 没被改写，于是装进 **GLOBAL**；下一格
  前奏重放 `enum Color ...` 直接 `Redeclaration of symbol 'Color'`，而且
  **此后每一格都失败**（整场会话锁死），枚举成员 `Red` 永远不可见。
  `subset` 同型（`sub tiny(Small $x)` 报 `Invalid typename`）；`constant`
  在 EVAL 的 `do` 块里恰好是词法的，所以之前没暴露（本次一并收编）。
- 修复：`!scan-cell` 的「裸类型声明补 `my`」清单从 `class|role|grammar`
  扩到 `subset|enum|constant`；前奏重放时，对以裸
  `class|role|grammar|subset|enum|constant` 开头的旧 `src` 补 `my`
  （升级前留下的快照/会话不会一恢复就锁死）。
- 语义：仍按 V-904，每次重放生成新的类型对象，`~~` / 类型身份不跨格；
  本条只保证「声明可见、成员可用、会话不被锁死」。
- 测试：`t/18` 覆盖裸 `enum` 成员可见且不锁死、`subset` 作参数类型且越界
  被拒、`constant` 跨格、旧快照里的裸 `enum` 重放。

---

## 3.64 引擎协议契约（V-335，0.133.0 / ADR-0051）

**V-335**：父进程 ↔ 求值子进程的协议有版本号与帧校验，契约只在
`Rakuish::Eval::Protocol` 一处定义。

- `PROTOCOL-VERSION`，**独立于** META6 的 `api<3>`（模块 API 与线格式
  各自演进）。0.133.0 为 1，0.135.0 升到 2（错误详情移出 result 帧，见 §3.67）。
- 握手：引擎 `ready` 帧带 `protocol`，Client 启动时比对；缺失/不符抛
  `X::Rakuish::Protocol`（缺失的文案直指「升级残留的旧引擎进程」）。
  Client 的每个请求也带 `protocol`，Server 分发前校验，不符发 `fatal` 并退出。
- 帧形状：`result` 帧由 `EvalReply` 类定义（`to-hash` / `from-hash`，
  含 `display` / `displays` / `exit-code`）；其余终帧（completions / marks /
  key / inspect / info / history / prompt / rc / restored）由 `FRAME-FIELDS`
  表列出必填字段。中间帧 `error_info` 的字段由 `ERROR-INFO-FIELDS` 定义。
- 校验：缺字段、未知终帧类型 → `X::Rakuish::Protocol`（异常带原始帧 JSON）。
  `event=error` 帧折成一条失败 `result`（`ok=False`，消息进 `err`）——
  以前它被当普通终帧，Proxy 读不到 `ok`/`err`，前端显示空结果。
- 不做兼容映射：同安装两端必然同版本，不一致就是「重启或升级」。
- 边界：中间帧（`chunk` / `tty` / `job` / `child` / `input_request` /
  `error_info`）仍就地处理。v1 的线格式与 0.132 完全一致（只加校验）；
  v2 把 `ename` / `evalue` / `traceback` 从 result 帧移到 `error_info`（§3.67）。
- 测试：`t/41` 第 ⑤ 组：版本常量、真引擎握手、ready 缺字段/版本
  不符、`EvalReply` 往返、缺字段/未知终帧、`error` 帧折叠、错误详情帧。

---

## 3.65 Table / Sys::FS / SQL 桥的三处收口（V-336，0.134.0）

**V-336**：把「属性可写但没有不变式」「上限消息不给路」「大文件全量物化」
这三类一直靠自觉的问题收进条款。

- **Table 属性只读**：`@!columns` / `@!rows` / `%!types` 改为内部私有，
  对外只有 `columns()` / `rows()` / `types()` 三个只读视图。以前三个都是
  `is rw`，任何代码可以改其中一个而不改另外两个 —— 表就可能自相矛盾
  （列名说 3 列、行里 4 个键）。全库 37 处只读消费、0 处写入，所以这是零破坏。
  两个实现细节：`types` 必须 `.clone`（`Hash.Hash` 返回**本体**，不克隆的话
  `$t.types = %()` 会把内部清空 —— 实测踩到）；`rows` 不克隆（热点路径，
  且 `Array.List` 不会把本体交出去）。
- **`cp` 超限消息给路**：`Sys::FS` 的另外三条上限消息都带「路径 + 上限 + 出路」，
  只有 `cp` 是光秃秃的 `复制超限: {字节} 字节`。现在补齐路径、上限值，并说明
  `:max-bytes(N)` / `Sys.new(:max-bytes(N))` 都能抬。`cp` 也接受单次 `:max-bytes`。
- **`cp -r` 预检吃上限**：`!count-entries` 以前对超大目录是全量递归、不吃任何
  上限 —— 预检本身成了新的内存/时间炸弹。现在边数边判，超过即抛（与 `!walk`
  同口径）。
- **`write :backup` 用本次上限**：备份判断原来读 `$!max-bytes`（默认值），
  忽略调用方传的 `:max-bytes`，于是 `write(..., :backup, :max-bytes(64M))`
  仍会被 1 MiB 卡住 —— 参数看起来生效了其实没生效。
- **`open-data` 接上 `:max-rows`**：`Engine.read-csv` / `read-parquet` 一直支持
  它，但 `open-data` **根本没传**，于是「DuckDB 那条链」恰恰是全量物化的
  （100 万行 CSV 38 s 才回一张 Table）。现在透传，且**不给默认值** —— 默认
  截断会让用户拿到「看起来完整、其实少一半」的表，而 `Table` 没有
  `truncated` 载体（与 V-271 同一条原则）。Shell 侧新增 `open --limit N`
  （0 = 不限），并在输出末尾写明「只取了前 N 行」。
- **测试**：`t/11`（只读视图与 `.clone`）、`t/01`（cp / 备份 / 条目上限消息）、
  `t/10`（`open --limit`、非法值）、`t/76`（SQL 桥 DDL 直插，见 V-337）。

---

## 3.66 SQL 桥改 DDL + Appender 直插（V-337，0.134.0 / ADR-0043 §7）

**V-337**：`Table.sql` / `sql(%tables, ...)` 不再写临时 Arrow 文件，改为
`CREATE TABLE` + Appender 直插。

- 背景：老路径「Table → 自研 Arrow 写 `$*TMPDIR` 临时 IPC → `read-arrow` 建视图
  → SQL」的 **99.7%** 成本在序列化（5 万行 4,784 ms，SQL 本身 4–5 ms）。这是
  六笔「图省事」里唯一净亏且可立即纠正的一笔（省了 DDL 拼装约 50 行）。
- 做法：从 `columns` / `types` 生成 DDL（标识符双写引号转义），
  `Duckula::Session.insert`（Appender）逐行写，再执行用户 SQL。
  类型固定：`int→BIGINT`、`num→DOUBLE`、`str/any→VARCHAR`、`bool→BOOLEAN`、
  `datetime→TIMESTAMP`；值按声明类型转换，`NULL` 传 `Any`
  （传类型对象会触发 `MoarVM syscall kind obj, should be num`）。
- **不再有临时文件**（`t/76` 断言数量为 0，比「创建了再清理」更强）；
  也**不再依赖 nanoarrow**（Appender 走原生 C 接口）。
- **行为变化（如实记录）**：超 int64 现在**明确报错**（老路径静默溢出成负数）；
  `typeof` 从 `TIMESTAMP_MS` 变 `TIMESTAMP`（值语义等价，UTC naive）。
- 性能细节（实测踩出来的）：抽「每列首个非空值」必须**一次遍历**拿全
  （按列各扫一遍是 O(列数 × 行数)，5 万行 × 5 列多花 2.5 s）；值已是声明类型时
  整表直通 + hash 切片，不逐值调转换器（每值都转的版本 7.6 s vs 1.5 s）。
- 实测（本机 5 万行 × 5 列稳态）：4,797 ms → **1,530 ms（3.1×）**。
  `REVIEW-ARROW-COST` 报的 5.6× 是「行列表已就绪」的口径，我们还要从 `Table`
  的 Hash 行搬一次，故实际 3.1×。
- 测试：`t/76` 48 条（新增：不产生临时文件、关键字/引号/空格列名转义、
  超 int64 报错且不改写原值）。

---

## 3.67 Result 净化：错误详情走独立 error_info 帧（V-338，0.135.0 / ADR-0051 v2）

**V-338**：`Rakuish::Result` 不再携带 `ename` / `evalue` / `traceback`，
错误详情改由协议中间帧 `error_info` 传给 notebook 前端。

- 背景：0.132.0（P2.5）为 Jupyter error reply 把三个字段塞进 Result。
  它们只有 notebook 前端用，TTY 完全不用 —— 同一个结果类型长出两套前端
  语义，每个 Result 还要多构造三个字段。这是架构审计的第 3 个硬伤。
- 协议 v2：`PROTOCOL-VERSION = 2`。失败格由 Server 在 result 终帧**之前**
  emit `event=error_info`（`seq` / `ename` / `evalue` / `traceback`）；
  result 帧与 `EvalReply` 不再有这三个字段。形状由
  `Protocol::ERROR-INFO-FIELDS` + `check-error-info` 定义与校验。
- 链路：Client 的 `request()` 循环消费 `error_info`，存 `last-error-info`
  （每个请求开头清空，成功格必为空）；Proxy 在 `eval-line` 结束后转存同名
  属性；Notebook Frontend 从 `session.last-error-info` 拼 Jupyter 形状。
  TTY 路径不读它，零成本。
- 语义不变：notebook 的 execute reply 仍是 `ename` / `evalue` /
  `traceback` 三键（前端不用改）；拿不到异常时不带这三键（与 0.132 同口径）。
- 测试：`t/41` 第 ⑤ 组改为断言版本 2、result 帧**不含** ename、
  `last-error-info` 有 ename 与非空 traceback；`t/65` 新增三条 Jupyter
  形状断言（ename / evalue / traceback 均非空）。

---

## 3.68 Notebook 传输回调化（V-339，0.136.0 / ADR-0037 §10）

**V-339**：`Kernel::Notebook.serve()` 不再直接读写 `$*IN` / `$*OUT`，
读请求与写响应改成参数（`:&read-line` / `:&write-frame`），默认值仍是
进程标准流。

- 背景：`serve()` 把传输（stdin/stdout）、组装（引擎 / Proxy / Kernel）、
  启动文件、看门狗与协议循环焊死在一个 sub 里。换传输（web UI / socket）
  就得复制整个循环，连「用内存队列把一轮协议跑完」这种测试都做不到 ——
  架构审计第 4 个硬伤。
- 契约：`read-line()` 返回一行请求，`Nil` = EOF；`write-frame(Str)` 收到
  **一帧 JSON 本体**（不带换行），换行与 flush 由传输自己决定。默认实现
  是 `$*IN.get` 与 `$*OUT.print($json ~ "\n"); $*OUT.flush`。
- 不变式：序列化只做一次（`to-json` 在 `serve` 内），写锁仍在 `serve`
  内 —— 主线程与看门狗线程的帧不会交错；两个回调抛异常都只丢掉这一帧，
  不弄崩循环（与 0.113.0 同口径）。
- `bin/rakuish-notebook` 与 Jupyter 桥零改动；`t/65` 新增一组用内存闭包
  驱动 `serve()` 的断言（ready → busy → 响应 → idle → shutdown 全链路，
  且 `write-frame` 收到的是不带换行的 JSON）。

---

## 3.69 协议流与 stdin 通道的两处断点（V-340，0.136.1 / ADR-0051 v3 + ADR-0037 §11）

**V-340**：引擎发出协议帧、读取下一行请求，一律走 `serve-engine()` 启动时
捕获的两个句柄；`prompt()` 与所有 stdin 消费走 Session 注入的 input-handler；
notebook 的读端脱离主循环所在线程。

- 断点一（引擎侧）：`emit` 写动态 `$*OUT`、`read-msg` 读动态 `$*IN`，而
  `Session.!eval-raku` 对每一格 `temp $*OUT = $cap`，并在 prompt 所在的
  `do {}` 块里 `temp $*IN = _RakuishIn`。后果两个：
  ① 从格内部发出的 `input_request` 被写进该格的**捕获缓冲**，前端永远收不到；
  ② `read-msg` 读回的正是 `_RakuishIn`，于是 `get → handler → read-msg` 无限
  递归（实测 45 秒内刷满 handler 调用后栈溢出，会话卡死）。
  契约：`emit` / `read-msg` 不参与用户代码的动态变量替换，句柄在
  `serve-engine` 入口捕获一次（那时还没有任何人 temp）。
- 断点二（notebook 侧）：`serve()` 在主循环里同步 `read-line()`，而主循环会被
  `execute` 整格阻塞 —— 引擎正等 `input_reply`，前端回的那条却没人读，死锁。
  契约：读端在独立线程里跑，把 `input_reply` 直接投进 `$input-reply` Channel
  （其余请求经 Channel 排队给主循环）；`busy/idle/execute_input` 的语义不变。
- 提示文案：内建 `prompt` 是 `print $msg; $*IN.get`，文案只会 print 进捕获缓冲，
  handler 收到永远是空串。格内因此 shadow 一个 `my sub prompt`，把文案交给
  `_RakuishIn.prompt`（`_RakuishIn` 记 `$!msg`，`.get` 再带给 handler）；
  裸 `$*IN.get` 行为不变。
- 反向约束：TTY 模式下 `input-handler` 同样注入，所以这三条对交互 REPL 也生效；
  不许靠「引擎侧只在 notebook 模式才设置 handler」这类分支绕过。
- 断言：`t/05`（格内 `prompt` 正常返回、文案到达 handler、文案不落进 `out`、
  一格两次 `prompt` 值不串、裸 `$*IN.get` 同源）；`t/65` 第 12 组（真 serve +
  真引擎：`input_request` 帧出现且带文案、`input_reply` 之后该格返回、
  提示文案不进 `out`）。

---

## 3.70 Table.to-text 可选行 + CSV bool/datetime 推断（V-341，0.137.0）

**V-341**：`to-text` 支持 pandas 风格的三条可选行；CSV 列类型推断补上
`bool` 与 `datetime`。

- `to-text(:max-rows, Bool :$index, Bool :$dtype, Bool :$shape)`：
  `:index` 前置 `#` 行号列（**表内** 0 基序号，limit/offset 之后重新数，
  不对应原始行号）；`:dtype` 追加 `dtypes: c1 int, c2 str`；`:shape` 追加
  `(N rows × M cols)`，N 是**整表**行数，不随 `:max-rows` 变。
- 三个开关默认全关：不带参数时的输出形态是既有契约（`gist` / `Str` /
  notebook 降级都走它），新增能力不许改变老输出。
- 省略提示的位置：数据行之后、`dtypes` / `shape` 之前。贴在最后一行
  后面会被读成「shape 是被截断的」，而 shape 讲的是整表。
- CSV 推断（只判类型、**不改单元格原值**，0.132.0 起的不变式）：
  `true` / `false` → `bool`（`1` / `0` 归 int，`yes` / `TRUE` 不猜）；
  `YYYY-MM-DD` + `T`/空格 + `HH:MM:SS` 且能真解析成 `DateTime` → `datetime`
  （带时区偏移、只有日期、`2020-13-45 99:99:99` 这类语义不成立的写法一律
  退回 `str`）。空格子不参与判定。
- 判定顺序 `int → num → bool → datetime → str`；整空列仍为 `str`。
- 断言：`t/11` 第 52–71 条（`to-text` 三开关的开/关成对断言、offset 后
  行号从 0 数、截断与 shape 互不污染、bool/datetime 正例与五条反例、
  单元格原值不变）。

---

## 3.71 块输入 paste（V-342，0.138.0 / ADR-0052）

**V-342**：会话命令 `paste` 把整段源码当成一个格执行，不经过行编辑器的
逐行循环。

- 输入：读进程 stdin 的行，直到**某一行去空白后恰为 `--`**，或流 EOF
  （Ctrl-D / 管道结束）。读到的行原样累积（保留空行与缩进）。
- 端点：整段文本一次交给 `eval-line`。因此只产生**一个** `Out[n]`、一条
  history（内容是整段源码）、一条 `cells` 记录；`!pure-decl` 的判定不受
  影响 —— 纯声明块（如整段 `class`）照常留下且跨格可用。
- `--` 之后的行**不属于** paste 块，照常按命令 / 表达式解释。
- 记账：内层 `eval-line` 之后设 `$!skip-record`，`paste` 这一行自身记一条
  历史；失败时只记命令本身（与 `rerun` / `!!` 同一口径）。
- 四类拒绝（都给明确文案，都不改动会话状态）：
  ① 不接受参数（除 `--help` / `-h`）；② 空块（没读到任何内容）；
  ③ 源码不完整（`is-incomplete` 命中：括号 / quote / heredoc 未闭合）；
  ④ 引擎 / notebook 模式（`input-handler` 已注入，stdin 是协议流，报不可用）。
- 反向约束：`paste` 不得依赖行编辑器的任何状态（ADR-0036 的输入循环所有权
  不变），也不得把 stdin 读循环做成常驻后台线程 —— 它是一次性、同步、可中断的。
- 可注入读端：`Session.read-line` 是 `rw` 回调（默认 `$*IN.get`，EOF 返回
  Nil），测试与前端可在不打桩 stdin 的情况下驱动它；它**不是** `input-handler`
  （后者是协议通道，两者语义不可混用）。
- 断言：`t/05` 第 152–166 条（整块 class 一次执行且跨格可用、history 1 条且
  为整段源码、index 只 +1、`--` 终止后剩余行未被吃掉、空块 / 不完整块 /
  参数 / 引擎模式四类拒绝、失败后会话仍可用）；`t/37`（`paste` 在
  命令表内且有 usage）。

---

## 3.72 跨会话变量库 store（V-343，0.139.0 / ADR-0053）

**V-343**：会话命令 `store` 把点名的变量写进一份跨目录共享的库，
换一个会话 `store -r` 读回；存不下的值必须拒绝并给出理由。

- 默认库 `$*HOME/.rakuish/store.json`，`RAKUISH_STORE` 覆盖，
  命令级 `-f 文件` 更高优先；**不按 cwd 分文件**（与快照的分工差别）。
- 信封 `{ "store-version": 1, "saved-at": Str, "vars": { 键 => 条目 } }`；
  版本独立于快照版本，结构不符的旧文件按「空库」处理，不许猜字段。
- 条目字段：`raku`（`.raku` 表示）、`type`、`saved-at`、`cwd`、
  `decls`（重放该值需要的声明，形状同快照的 decls）。
- 可序列化判定复用 `Rakuish::Snapshot::classify`；`invalid`（闭包 /
  资源 / 超单值上限）**拒绝整个操作**并原文报出 reason —— 与快照的
  「标记失效、恢复成 Any」是相反取舍（用户点了名，静默跳过等于骗人）。
- 名字解析：带 sigil 原样比对；不带 sigil 时按 `$ @ % &` 收集候选，
  0 个报「没有 / 库里没有」，多于 1 个报「名字不唯一」，不替用户挑。
- 读回：prelude = 本会话声明 + 条目声明（去重），连同剥掉
  `Rakuish::REPL::Session::` 前缀的 repr 在同一个 EVAL 块里求值
  （ADR-0022 §4 的同一约束）；裸 `enum` / `subset` / `constant` 重放前补
  `my`（V-334）。读回的值进 `%!state`，因此是真会话变量。
- 记账：`store` 命令本身不占 `Out[n]`，`history` 记一条命令行。
- 参数面：`-l` / `-r` / `-d` 互斥；`-l` 与 `--clear` 不接受名字；
  `--clear` 不与模式合用；未知选项报用法。
- 断言：`t/81`（54 条：保存/列表/空库/无 sigil/不唯一/不存在/闭包/
  `Channel`/超限/跨会话读回标量·数组·哈希·类实例/覆盖/删除/清空/
  坏参数/`-f`）；`t/37`（命令表与 usage 双向）。

---

## 3.73 错误分级 errors + recall 预填（V-344，0.140.0 / ADR-0054）

**V-344**：失败格的错误头一行必须说清是哪一层，默认不刷 backtrace；
`recall n` 把历史放回输入缓冲，只回显不执行。

- `errors`（无参）= 回显当前分级；`errors short|full` 切换；`--help` 给用法；
  其它参数报用法且 `code=2`；参数大小写不敏感；命令本身不占 `Out[n]`。
- 分级头：`short` 一行 `类型: 消息（位置）`，`full` 同一行 + 完整回放帧
  （等价 `repl.trace = True`，只是不要求用户先开会话选项）。
- 三种类型（判据写死在 `!error-kind`，不靠消息文本猜）：
  - `编译错误`：`$ex ~~ X::Comp`，或 `^name` 命中 `X::Comp|Syntax|Undeclared|
    Obsolete|Redeclaration|Declaration|Attribute` 前缀（不同 Rakudo 版本把
    `X::Undeclared::Symbols` 归族的行为不一致，实测它是独立族）；
  - `被拒绝`：`^name` **包含** `X::Rakuish` —— 这些类声明在
    `Rakuish::Result`，实际名字是 `Rakuish::Result::X::Rakuish::NotFound`
    之类，前缀判定会漏（实测踩过）；
  - `运行错误`：其余。
- 位置口径：格内代码经 `EVAL "no worries; do { prelude + 本格 }"` 编译，
  `EVAL_k` 帧的行号是**整段拼接源码**的行号，故
  `行 = 帧行 - (prelude 行数 + 1)`。折算结果 `<= 0` 时只报「第 N 格」，
  不硬造行号。真文件名（SETTING:: / `src/` / `.nqp` / 驱动自身 / 调用方）
  一律不用：那是用户改不了的地方。`source` 的文件:行由 `!cmd-source`
  自己加 `{$label}:{$n}:` 前缀，这里不重复。
- `last-error-kind` / `last-error-loc` 是可读属性（前端与测试的观察口，
  不是语义契约的一部分）。
- `recall [n]`：编号与 `rerun` 完全一致（1 基、负数从末尾算、默认上一条）；
  越界 `code=127` 并点名该编号，非数字 `code=2` 给用法，空历史明确说；
  `--help` 在「有没有历史」之前处理（空会话也能查）。
- recall 的**契约**是「预填缓冲 + 回显」，不是执行：`$!prefill` 由
  `take-prefill()` 读走（读后即清），且只活到下一格 —— 用户敲了别的行，
  它就是过期的。本机行编辑器（Terminal::LineEditor 0.0.23）没有预填 API，
  所以非 TTY 下的回显**如实说明退路**（`rerun n` / 复制那行），
  不用按键注入假装塞进了输入行（ADR-0036）。
- 断言：`t/82`（88 条：分级命令/三种类型/格内行号/两行格/full 帧数/
  recall 编号与预填一次性/预填过期/越界与非数字/会话仍可用）；
  `t/37`（命令表与 usage 双向）；`t/05`、`t/08` 不回归。

---

## 3.74 文档契约：CHANGELOG 与英文 README（V-345，0.141.0）

评审 P3.4 / P3.5 的落点不是「多写两份文档」，而是**让文档漂移能被测试抓住**。

**V-345**：仓库根必须有两份对外入口文档，且互相指得到。

- `CHANGELOG.md`：从 0.123.0 起**逐版本**一节的变更日志，节标题形如
  `## 0.140.0 — 2026-11-26`；每节只在四类里记（新增 / 变更 / 修复 / 文档），
  并标出对应的 `V-nnn` 与 ADR。**最新一节必须是 `META6.json` 的当前版本**，
  且带日期 —— 发版与写日志不能只做一半。更早的版本不誊写，只指 `git tag` / `git log`。
  文件末尾必须有「发布节奏」一节（版本号唯一来源、tag 规矩、补丁号 vs 次版本号的判定）。
- `README.en.md`：英文入口，至少包含安装、快速开始、输入模型、核心 API、
  英文的 MANUAL 目录（逐节指向 `docs/MANUAL.md` 的行号）、测试、明确不支持、平台、许可；
  必须链接 `README.md` / `docs/MANUAL.md` / `CHANGELOG.md`，反过来 `README.md`
  也必须链接 `README.en.md` 与 `CHANGELOG.md`。
- 英文 README **不重复**版本号（版本号唯一来源是 META6；中文 README、MANUAL、
  HANDOFF、ADR-INDEX 四处已经由 `t/51` 守着），避免多一个要同步的地方。
- `SPEC.md` 开头「唯一真值（…，当前 x.y.z）」的自述版本同样由 `t/51` 守住。
  0.142.1 之前它停在 0.124.0 而无人发现：四份外围文档都守住了，偏偏真值文件
  漏在检查之外 —— 越是「真值」越不能只靠人肉同步。

- 断言：`t/51` 文档守卫组（CHANGELOG 存在且有版本节 / 第一节等于当前版本 /
  带日期 / 有发布节奏节 / 英文 README 存在且三条链接在 / 有英文目录 /
  中文 README 反向链接 / SPEC 自述版本）。
- 边界：这是**文档存在性与互链**的护栏，不查正文内容是否准确 ——
  「文档说得对不对」仍要靠评审，测试只保证「该写的那节存在且没落后一个版本」。

---

## 3.75 启动不再后台扫 PATH：可执行表落盘缓存（V-346，0.142.0 / ADR-0055）

**V-346**：PATH 可执行名表（`! <Tab>` 的首词补全）必须是三级查找，
且**启动时不做任何扫描**。

- 背景：本机 25 个 PATH 目录 / 5,980 个条目（`C:\Windows\system32` 一个目录
  就 4,667 个），全表扫描 1.1–1.3 s。0.105.0 起 CLI 用
  `start { path-executables() }` 预热，于是**每个会话的前一秒都在扫盘**，
  与用户输入抢线程和磁盘 —— 用户侧表现就是「刚启动就卡」。
- 三级：进程内缓存 → 磁盘缓存 → 真扫描。磁盘缓存默认
  `$*HOME/.rakuish/path-executables.json`，`RAKUISH_PATH_CACHE=<路径>` 改路径，
  `off` / `none` / `0` 关闭（既不读也不写）。
- 键 = 平台 + PATH + PATHEXT；键一变就重新扫描（**按 PATH 失效**，不按时间），
  这样「装了新工具 / 改了 PATH」之后下一次 Tab 就能看到。
- 过期（TTL 一天）时**先返回旧表**，后台刷新一次（每进程每 PATH 最多一次）。
  理由：补全的第一属性是快；为 24 小时的新鲜度让用户按 Tab 等 1.2 秒，
  是拿最不该慢的动作换最不该在意的属性。
- 缓存只存名字（不含路径），按 PATH 顺序去重（先出现的赢），与真扫描语义一致；
  解析失败 / 版本不符 / 键不匹配 / 名字含 `/` `\` 一律当空缓存。
- 实测：启动从 ~1.03 s 降到 ~0.60–0.65 s（后台扫盘降为 0）；首次 Tab
  仍付 1.1 s（只此一次），之后跨进程 13 ms。
- 断言：`t/10` 末尾缓存组（冷扫描写盘 / 命中（哨兵替换证明真读盘）/
  PATH 变则失效 / `off` 不读不写）。**不测时间**：CI 机器差异大，
  性能回归用 `tmp/bench-*` 手动测。

- 副作用：`RAKUISH_PATH_CACHE` 进了环境变量表（MANUAL §14）；
  `Rakuish::REPL::Shell::forget-path-cache()` 是给测试/诊断的公开钩子，
  不是语义契约。

---

## 3.76 引擎内管道：`! a | b`（V-347，0.143.0 / ADR-0056）

**V-347**：`!` 行支持**顶层单个** `|` 串联多个外部命令，`|` 只接 stdout。

- 范围：只解析 `!` 行，且只切**引号外**的 `|`（`'a|b'` / `"a|b"` 是字面量）。
  Raku 表达式侧不加任何管道语法（V-243 不松动）；`||`、`>`、`>>`、`<`、
  `&&`、`;`、`$()`、glob、变量展开**都不支持**，保持「只接 argv」的铁律。
- 语义：stage[i] 的 stdout 直接成为 stage[i+1] 的 stdin；stderr 各段独立收集
  后拼接（不改道、不混进 stdout）；退出码取**末段**，不实现 `pipefail`；
  各段自己的码 / 是否启动失败记在 `Result.value<stages>`，整体标
  `value<pipeline> = True`。
- 段间是**引擎内**的 Channel 泵（复用 `:&in-chunks`，写一块 `await` 一块 =
  背压），不是 `dup2` —— `Proc::Async` 没有 fd 级重定向。下游提前关 stdin
  时上游停喂（`in-early`），大流量不挂死；末段输出仍按 `--capture` /
  `max-bytes` 规则处理，流式模式下逐块转发。
- 失败：某段 exe 不存在 → 整条管道收敛成 `code=127` +
  `value<start-failed> = True`，err 里带原因；**不重试、不降级**。
- 与 `--tty`：单命令 `--tty` 仍是 TTY 直通；`--tty` + 管道在 0.144.0 起由
  父进程执行（V-348，见 §3.77），本条引擎内语义不变。
- 组管理：Windows 上整条管道**一次性**收养进一个 Job（`child` 帧带
  `pids`），避免逐段收养时 `!adopt-child` 的 `drop` 把前面的段一起杀掉
  （`KILL_ON_JOB_CLOSE`，V-905）。
- 断言：`t/83`（数据通路 / 三段 / 2 万行早停 / 退出码取末段 / 各段码 /
  stderr 不合流 / 末段 127 + start-failed / `!` 行切段 / 引号内 `|` 不切 /
  `--tty` 与 `||` 拒绝）；`t/41` 的 child 帧不回归。
- 边界：**普通管道不**支持 `! cat | wc -l` 这类需要键盘输入的用法 —— 引擎的
  stdin 是协议流。要交互请显式写 `! --tty cat | wc -l`（0.144.0，V-348，
  父进程执行；仍不是 shell）。

---

## 3.77 交互式管道：`! --tty a | b`（V-348，0.144.0 / ADR-0057）

**V-348**：`! --tty`（或 `-t`）**且**有顶层管道时，整条管道由**父进程**执行。

- 触发：只有 `--tty` + 管道走父进程；普通 `! a | b` 仍是引擎内管道
  （§3.76 / V-347），语义、审计、历史、快照都不动。
- stdin：只有第 0 段继承真终端；段间仍是同一套 Channel 泵（`in-chunks`，
  背压 / 早停 / EOF）。v1 **不做**父→引擎的块流式。
- stdout / stderr：末段输出**捕获**进 `Result`（`Out[n]` / `_` 可用），
  `Result.streamed = False`；不进入流式分支，避免与结束重放重复。
- 失败：无父进程执行器（`&pipe-handler` 未注入，如 notebook）或父进程
  stdin 非 TTY → `code=127` + 明确说明；**绝不回退引擎内**（第 0 段会把
  协议 stdin 吃掉，REPL 当场错位）。
- 超时：交互式固定 `timeout-ms=0`；`--timeout-ms` 在 `--tty` 下无效。
- Ctrl-C：POSIX 子进程与父同 pgid，随终端收 SIGINT；Windows 父侧把整组
  收养进命令级 Job 并 terminate；`pipe-exec` 期间不杀引擎，最终 `code=130`。
- 段退出码归一：`exitcode` 为 Nil 且 `signal > 0` 时记 `128+signal`
  （SIGINT → 130），其余取不到码的异常情况仍记 1。
- 协议：中间帧 `event=pipe-exec`（`seq` + `stages=[[exe, argv...], …]`），
  回包沿用 `cmd=resume` + 嵌套 `pipe` Hash（`ok/code/op/out/err/value`）；
  `PROTOCOL-VERSION` 保持 2，`FRAME-FIELDS` 不变。
- Windows：`--tty` + 管道时第 1 段也过 cmd 内建重写（V-333 条件放宽）。
- 测试：`t/83`（无执行器 → 127；fake 执行器调用一次、2 段、输出透传、
  非流式）；`t/41` ④b（真引擎 + fake `:pipe-exec` 往返、argv 不拼 shell
  串、未注册 → 127）。

---

## 3.78 管道透传：`! --pipe a | b`（V-349，0.145.0 / ADR-0059）

**V-349**：`!` 元选项新增 `--pipe`（`-P`）、`--pipefail`、`--stdin FILE`，
与 `--tty` / `--capture` / `--timeout-ms` 同层，只解析第 1 段开头的 token，
作用于整条管道。

- `--pipe`：末段 stdout / stderr **不捕获**，逐块直写当前进程的 stdout / stderr。
  `Result.out` / `.err` 为空串、`streamed = True`（结束不重放）；`ok` / `code` /
  `value` / `elapsed` 照旧，`value<stages>` 仍是每段退出码。`start-failed` 是
  例外：没有输出，`err` 原样保留。
- 互斥：`--pipe` 与 `--capture` 同时出现 → `127` +「透传就是不捕获」。
- 执行位置：交互式（worker）由**父进程**经 `pipe-exec` 中间帧执行（引擎
  `$*OUT` 是协议流）；`-e` / 脚本 / stdin 管道在**本进程**执行。worker 下无
  执行器 → `127`，绝不把原始输出写进协议流。单命令 `! --pipe cmd` 按
  「一段的管道」走同一路径（`spawn-pipeline` 下限放宽到 1）。
- 超时：`--pipe` 默认 `timeout-ms = 0`（不设总时限）；显式 `--timeout-ms N`
  仍生效。`--tty` 的固定 0 不变。
- `--pipefail`：退出码取**最右**非零段（全 0 才 0）；对捕获式管道同样生效。
  超时 `124`、取消 `137`、启动失败 `127` 优先于段码。
- `--stdin FILE`：首段 stdin 从文件流式接入。路径经 `Sys.resolve` 解析为
  绝对路径（root 沙箱）；缺参 / 解析失败 / 不存在 → `127`。读取为 16 KiB
  分块 + `await` 背压，不整份读入内存；`:in` / `:&in-chunks` / `:stdin-file`
  三来源互斥。
- 协议：`pipe-exec` 中间帧新增**可选**键 `no-capture` / `pipefail` /
  `stdin-file` / `timeout-ms`；`PROTOCOL-VERSION` 保持 2。hook 无附加选项时
  仍按老签名调用（向后兼容）。
- **诚实边界**：这是**数据层**透传，子进程 stdout 仍是管道（`isatty = 0`），
  颜色 / 进度条 / TUI 仍不成立；真终端语义走 `--tty` / `pty-exec`。
- 测试：`t/83` ⑤（互斥 127；`--pipefail` 的 `3|0` 与 `0|4|2`；`--stdin`
  读文件 / 不存在 127；fake hook 收到的四个选项与 `out == ''`、`streamed`；
  `-e` 端到端输出）。

---

## 3.79 Session 拆分（第一步）：两个 role + 公开访问器（V-350，0.146.0 / ADR-0060）

V-349 之前的 `lib/Rakuish/REPL/Session.rakumod` 是 4,304 行、65 个属性、126 个方法的单文件。本条把其中两块按**子系统边界**搬出成 role，并定下往后拆分必须遵守的规则。

### 3.79.1 文件划分

| 文件 | 角色 | 内容 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Commands.rakumod` | `unit role Rakuish::REPL::Session::Commands` | 会话命令层；当前含 `!cmd-errors` 与它独占的三个属性 |
| `lib/Rakuish/REPL/Session/Config.rakumod` | `unit role Rakuish::REPL::Session::Config` | 配置 / 别名 / `set -o` 选项 / hook / plugin，共 16 个方法 |
| `lib/Rakuish/REPL/Session.rakumod` | `unit class Rakuish::REPL::Session does ...Commands does ...Config` | 其余（求值、状态、快照、渲染、补全、按键） |

`use` 语句必须写在 `unit` 之前 —— `does` 在声明处就要解析到 role 名。三个文件都要登记进 `META6.json` 的 `provides`（`t/51` 守着「lib 下有文件但 provides 里没有」）。

### 3.79.2 属性归属规则（**新增，后续拆分一律遵守**）

> **属性默认留在 `Session.rakumod`，role 方法经公开访问器（`$.x` / `%.x` / `@.x`）读写。**
> 只有「类方法也必须写」的属性才随方法搬进 role。

依据是 Rakudo v2026.11 的语言事实（四条实测见 ADR-0060 §2）：

- `trusts` 未实现 —— 四种写法全部 `Unable to parse class definition`，**跨类访问私有属性不存在**；
- role 方法读**类声明**的私有属性 → `Attribute %!h not declared in role R1`；
- role 方法读**类的公开访问器** → 读、写标量、写哈希、改数组、写布尔、调另一对象方法**六项全过**，且写回落到原对象。

因此 `$!x` 改写成 `$.x` 即可，不需要把状态搬家。语法注意：`$.h{k}`（裸词/变量键）会被当 block 解析而报 `Undeclared routine: k`；字面量键用 `$.h<k>`，变量键用 `my %h := $.h; %h{$k}`。

唯一搬走的属性是 `$.error-mode` / `$!last-error-kind` / `$!last-error-loc` —— `!eval-raku` 的 `CATCH` 在类里写后两个，而 `!cmd-errors` 在 role 里读它们。类方法读 role 声明属性是允许的。

### 3.79.3 划分依据是可测量的耦合度

拆哪儿不靠感觉。对 45 个可搬方法统计「属性引用落在命令内 / 命令外」：

- `%!config` 18 / **0** → 天然子系统，先切它；
- `@!decls` 5 / **33**、`%!state` 9 / **26**、`@!history` 15 / **23**、`@!sys` 11 / 19、`@!out` 4 / 14 → 与求值核心强耦合，**不许**整组搬走（否则 role 反向拥有会话核心状态）。

### 3.79.4 结构不变量（`t/84-session-split.t`，34 条）

1. 三个文件都在；两个 role 的 `unit role` 头正确；Session 的两条 `does` 与两条 `use` 都在。
2. **反方向**：`!cmd-errors` 不在 Session；`!cmd-alias` / `!cmd-unalias` / `!cmd-config` / `!cmd-hook` / `!cmd-plugin` / `!expand-alias` / `!save-config` 不在 Session 而在 Config；`run-hooks` / `options` 同理。
3. 规模上限 `cmp-ok $sess-lines, '<', 4150` —— 比拆分前的 4,304 小、比现在的 4,035 宽松：允许正常增长，不允许把命令搬回来。
4. 运行时：`$s.options` 仍是 5 项且名字不变；`run-hooks('no-such-event')` 为空；`$s.histexpand` 为真 —— 证明 role 真的读到了公开访问器，不是只搬了文本。

### 3.79.5 本版不做

把 21 条 `!cmd-*` 整体搬走需要先决定「`%!state` / `@!decls` 等私有状态要不要成为公开 API，或改成闭包宿主传给协作者对象」。那是独立决策，留给后续版本（ADR-0060 §7 已列出下一个簇与阻塞点）。

## 3.80 Session 拆分（第二步）：诊断 / 渲染簇 role（V-351，0.147.0 / ADR-0061）

§3.79 之后 `Session.rakumod` 仍有 4,035 行。本条把诊断 / 渲染这一族搬成第三个 role：**4,035 → 3,630 行**（93 insertions / 498 deletions），新文件 `Diagnostics.rakumod` **436 行**。

### 3.80.1 文件划分

| 文件 | 角色 | 内容 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Diagnostics.rakumod` | `unit role Rakuish::REPL::Session::Diagnostics` | 诊断 / 渲染层，17 个方法 |
| `lib/Rakuish/REPL/Session.rakumod` | `unit class ... does ...Commands does ...Config does ...Diagnostics` | 其余（求值、状态、快照、渲染、补全、按键） |

搬走的 7 条命令：`!cmd-explore` / `!cmd-perf` / `!cmd-tb` / `!cmd-audit` / `!cmd-log` / `!cmd-hint` / `!cmd-who`；
随行的 10 个辅助：`perf-report` / `!render-trace` / `collect-traceback` / `!source-line` / `log-line` / `hint-text` / `next-hint` / `!sigil-rank` / `!value-type` / `!value-size`。

`use` 三条写在 `unit` 之前；`META6.json` provides 49 → 50。

### 3.80.2 状态暴露与访问器（§3.79.2 规则的第一次实战）

- 诊断簇要用 `@.decls` / `@.out` / `@.cells` / `%.hinted` / `%.state` / `@.perf-hist` / `@.history` / `$.bt` / `$.audit` / `$.sys` / `$.shell` / `$.commands` / `$.live-out` / 日志四属性。0.147.0 把仍是私有的 8 个（`@!decls` / `@!out` / `@!cells` / `%!hinted` 与 `$!log-on` / `$!log-path` / `$!log-seq` / `@!log-lines`）改成 `has` 公开属性并全文改写引用；顺带公开 `$.expanding` / `$.skip-cell`（不在本簇，属预备）。
- `$!last-error` / `$!last-error-text` **不公开**：tb / traceback 改调既有公开方法 `self.last-error` / `self.last-error-text`。
- 三条历史日志访问器只留一条：`log-active` 留在 Session（`method log-active(--> Bool) { $!log-on }`，名字与属性 `log-on` 不同，无冲突）；`log-path` / `log-lines` **删掉手写方法**，由 `has Str $.log-path is rw` / `has @.log-lines is rw` 的属性访问器承担读写。

### 3.80.3 两个访问器陷阱（**硬约束**）

1. **自递归**：`method log-path(--> Str) { $.log-path }` 里 `$.x` 是方法调用而非属性读取，方法调自己 → 递归到内存耗尽，MoarVM 报 `Memory allocation failed; could not allocate 131072 bytes`（不是 "too much recursion"）。
2. **只读方法遮蔽写访问器**：手写只读 `log-path` 后，role 里 `$.log-path = $path` → `Cannot modify an immutable Str ()`；方法体改 `$!log-path` 也不行，role 读不到类的私有属性。

规则：**不要给 `is rw` 公开属性手写同名只读访问器**；需要只读别名时另起名字（`log-active` ↔ `log-on`）。

### 3.80.4 结构不变量（`t/85-diagnostics-split.t`，50 条）

1. 四个文件都在；三个 role 的 `unit role` 头正确；Session 的三条 `does` 与三条 `use` 都在。
2. **反方向**：7 条命令不在 Session；10 个辅助不在 Session 而在 Diagnostics；`log-active` 留在 Session 且不在 role；`log-path` 没有手写方法。
3. 规模上限 `cmp-ok $sess-lines, '<', 3700`（比现在的 3,630 宽松，比拆分前的 4,035 紧）。
4. `META6.json` provides 50 条且有 Diagnostics 条目。
5. 运行时：`who` / `perf` / `tb` / `log` / `hint` 可用，无异常时 `collect-traceback` 返回空 —— 证明 role 真的读到了公开状态。

### 3.80.5 本版不做

`!cmd-rerun` / `!cmd-cells` / vi / 求值核心仍留 Session；下一个候选簇与阻塞点见 ADR-0061 §7。唯一可观察差异：`log-lines` 返回活 Array 而非 List 拷贝（无代码/测试依赖旧形状）。

## 3.81 Session 拆分（第三步）：快照 / store 层 role（V-352，0.148.0 / ADR-0062）

§3.80 之后 `Session.rakumod` 是 3,630 行。本条把「跨会话保存 / 恢复」这一族搬成第四个 role：**3,630 → 3,250 行**（15 insertions / 395 deletions），新文件 `Persistence.rakumod` **417 行**。行为不变。

### 3.81.1 文件划分

| 文件 | 角色 | 内容 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Persistence.rakumod` | `unit role Rakuish::REPL::Session::Persistence` | 快照（ADR-0022）+ 跨会话变量库（ADR-0053），7 个方法 |
| `lib/Rakuish/REPL/Session.rakumod` | `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence` | 其余（求值、状态、渲染、补全、按键） |

搬走：`!init-snapshot` / `save-snapshot` / `restore-snapshot` / `restored` / `!cmd-store` / `!store-candidates` / `!store-decl-src`。
留下：`!state-alias`（求值状态别名，`!eval-raku` 调它，不属于快照）与 `!eval-in-session`（见 §3.81.3）。
`META6.json` provides 50 → 51。

### 3.81.2 状态暴露

- `%!restored` → 公开属性 **`%.restored-info`**：它不能直接叫 `%.restored` —— 会与既有公开方法 `restored` 撞名（同名方法/属性访问器只能留一个）。改名只动内部，`restored` 的返回形状不变。
- `@!restore-failed` → 公开属性 `@.restore-failed`。
- 其余全部走既有公开面：`$.snapshot-on` / `$.snapshot-path` / `$.store-path` / `$.index` / `$.sys` / `%.state` / `@.decls`。

### 3.81.3 EVAL 的词法包（**硬约束**）

role 里 `EVAL` 出来的用户声明落在 **role 的包名**下。实测：

```raku
role R1 { method m { EVAL 'my class Foo { ... }; Foo.new' } }; class C1 does R1 { }
C1.new.m.WHAT.^name;   # R1::Foo（不是 C1::Foo）
```

快照恢复要把值里的 `Rakuish::REPL::Session::Foo.new(...)` 剥成本类前缀再交给 prelude 里的 `my class Foo`。若在 role 里 EVAL，新值会写成 `Rakuish::REPL::Session::Persistence::Foo.new(...)`，前缀剥不干净 → 恢复出的类型找不到。所以：

- EVAL 只留在 Session：`method !eval-in-session(Str $code) { EVAL $code }`；
- Persistence 的两处恢复调用 `self!eval-in-session(...)`（role 调类私有方法合法，ADR-0060 §2 实测）。

### 3.81.4 结构不变量（`t/86-persistence-split.t`，41 条）

1. 文件都在；`unit role ...::Persistence` 头正确；Session 的四条 `does` 与四条 `use` 都在。
2. **反方向**：`!init-snapshot` / `save-snapshot` / `restore-snapshot` / `!cmd-store` / `!store-candidates` / `!store-decl-src` / `restored` 不在 Session 而在 Persistence；`!state-alias` / `!eval-in-session` 留在 Session 且不在 role。
3. 状态：`%.restored-info` / `@.restore-failed` 是公开属性；Session 里没有 `%!restored` / `@!restore-failed`；role 里没有任何类私有属性引用。
4. 规模上限 `cmp-ok $sess-lines, '<', 3300`（比现在的 3,250 宽松，比拆分前的 3,630 紧）。
5. `META6.json` provides 有 Persistence 条目（总 51 条）。
6. 运行时：`save-snapshot` / `restore-snapshot` / `restored` 在实例上；`restored` 空 Hash；TWEAK 里的 `!init-snapshot` 跑过（`snapshot-path` 含 `session-`）；`store -l` / `store --help` / `store -d` 走 role。

### 3.81.5 本版不做

`!cmd-cells` / 补全 / 渲染 / recall 仍留 Session；下一个候选簇与阻塞点见 ADR-0062 §8。可观察差异：无 —— 快照文件格式、`store` 输出、`restored` 返回值都没变。

## 3.82 Session 拆分（第四步）：格记录 / 导出簇 role（V-353，0.149.0 / ADR-0063）

§3.81 之后 `Session.rakumod` 是 3,250 行。本条把 `cells` 一式四件搬成第五个 role：**3,250 → 3,093 行**，新文件 `Cells.rakumod` **182 行**。行为不变。

### 3.82.1 文件划分

| 文件 | 角色 | 内容 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Cells.rakumod` | `unit role Rakuish::REPL::Session::Cells` | 格记录的查看与导出，4 个方法 |
| `lib/Rakuish/REPL/Session.rakumod` | `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells` | 其余（求值、状态、渲染、补全、按键） |

搬走：`!cmd-cells` / `!render-cells-list` / `!render-cells-text` / `!render-cells-json`。
留下：`!split-argv`（输入层，role 按名调用）、`@.cells` 的写入方（`!finish` / `!eval-line-body`）—— role 只读格表。
`META6.json` provides 51 → 52。

### 3.82.2 状态：这一刀不新增公开面

`cells` 需要两样状态，**都在 0.147.0 就已公开**：

- `@.cells`（0.147.0 公开，诊断簇的 `log-line` 要写 `@.cells[*-1]<rendered>`）；
- `$.skip-cell`（0.147.0 作为 `!cmd-cells` 的预备项顺手公开）。

只把 3 处 `$!sys` 改 `$.sys`。**这是拆分复利**：上一刀为别人的需求公开的属性，这一刀白拿。反例是「每刀只公开刚好要的」，成本会线性累加。

### 3.82.3 role 里要自己 `use` 依赖

`!render-cells-json` 用 `to-json`。Session 里的 `use JSON::Fast;` **不会**泄漏进 role 的编译单元 —— 漏写会在运行时才报 `Undeclared routine: to-json`（编译期不报，因为 `to-json` 在 role 里是未声明的裸子例程调用，只有走到那行才失败）。所以 Cells 自己写了 `use JSON::Fast;`。

规则：**凡 role 里用到的导出子例程 / 类型，role 文件自己 `use`**，不要假设宿主类导入过。

### 3.82.4 结构不变量（`t/87-cells-split.t`，46 条）

1. 文件都在；`unit role ...::Cells` 头正确；Session 四条既有 `does` 未被回退，第五条 `does ...Cells` 与 `use` 都在。
2. **反方向**：`!cmd-cells` / `!render-cells-list` / `!render-cells-text` / `!render-cells-json` 不在 Session，而在 Cells。
3. `!split-argv` 留在 Session 且不在 Cells；Cells 经 `self!split-argv` 调用。
4. `@.cells` / `$.skip-cell` 是公开属性；Cells 无任何 `$!` / `@!` / `%!` 引用；Cells 不写 `$!sys`。
5. `cmp-ok $sess-lines, '<', 3150`。
6. `META6.json` provides 52 条，含 Cells。
7. 运行时：空会话列表文案；`1+1` 后格数为 1；列表含输入与 `ok`；连跑 `cells` 后格数仍为 1（`skip-cell` 不自指）；`--json -` 的 `format` / `count`；`--text -` 的 `no worries;` 与句末 `;`；写文件的 `--text` / `--json` 两条路径；未知选项 `code=2`。

### 3.82.5 本版不做

补全（`completions` 系）、recall / source / paste、`render` 与 `!fmt` 系仍留 Session；下一个候选与阻塞点见 ADR-0063 §7。可观察差异：无 —— `cells` 的列表、两个导出格式、退出码都没变。

## 3.83 Session 拆分（第五步）：输入重放簇 role（V-354，0.150.0 / ADR-0064）

§3.82 之后 `Session.rakumod` 是 3,093 行。本条把「把已有文本重新喂给求值器」的三条命令搬成第六个 role：**3,093 → 2,868 行**（17 insertions / 242 deletions），新文件 `Replay.rakumod` **267 行 / 3 个方法**。行为不变。

### 3.83.1 文件划分

| 文件 | 角色 | 内容 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Replay.rakumod` | `unit role Rakuish::REPL::Session::Replay` | `!cmd-recall` / `!cmd-source` / `!cmd-paste` |
| `lib/Rakuish/REPL/Session.rakumod` | `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells does ...Replay` | 其余（求值、状态、渲染、补全、按键） |

搬走：`!cmd-recall`（ADR-0020 / V-344）、`!cmd-source`（V-306）、`!cmd-paste`（V-342）。
留下：`take-prefill`（前端读预填的公开 API）与三个窄私有入口（§3.83.2）。
`META6.json` provides 52 → 53。

### 3.83.2 状态：写侧用窄入口，不公开属性

本簇**没有新增任何公开属性**。区间里仍私有的三个状态在求值核心里还有引用（`$!prefill` 4 处、`$!skip-record` 5 处、`@!pending` 9 处），按 §3.79.2 留在 Session；role 只做写入，而写入不是对外 API，所以用三个私有方法表达意图：

```raku
method !set-prefill(Str $s --> Nil) { $!prefill = $s; Nil }
method !mark-recorded(--> Nil) { $!skip-record = True; Nil }
method !clear-pending(--> Nil) { @!pending = (); Nil }
```

规则由此细化：**属性公开与否看「外部是否该看见」，不看「role 是否需要」。** role 需要写、外部不需要看 → 私有窄入口。读侧 `take-prefill` 留 Session。

`&!input-handler` / `&!read-line` 无需任何改动：它们本来就是公开可调用属性（`self.input-handler` / `self.read-line`）。

### 3.83.3 测试预期陷阱（不是行为变更）

1. **值格的 `.out` 是空的**：`eval-line('$x + 1').out` 为 `''`，值在 `.value`；`render` 才把它格式化成 `Out[n] = …`。断言 `source` 带回输出时，脚本里要写 `say`。
2. **`recall` 的编号随历史增长漂移**：守卫里写死 `recall 2`，前面多跑一条 `recall --help` 就取到别的行。要按 `$s.history.elems` 动态算编号。
3. **`paste` 的两种判定**：`self.input-handler.defined` 表示引擎 / notebook 模式（stdin 是协议流）→ 「不可用」；未定义时读 `$*IN`，EOF → 「没有读到内容」。两者都是 `code=1`。
4. **测试不许读真 stdin**（0.154.1）：没有 `read-line` 时 `paste` 会落回 `$*IN.get`。`zef install .` 在真终端下把 tty 交给测试（WSL 实测 stdin = `/dev/pts/6`），断言会一直等回车，安装看起来像卡死。断言前先 `my $*IN = Test-EOF-In.new`（`method get(--> Nil) { Nil }`）遮蔽。

### 3.83.4 结构不变量（`t/88-replay-split.t`，64 条）

1. 两个文件都在；`unit role ...::Replay` 头正确；Session 的六条 `does` 与六条 `use` 都在。
2. **反方向**：三条命令不在 Session 而在 Replay；`take-prefill` 在 Session 不在 role。
3. 三个窄入口在 Session、不在 role，且 role 以 `self!name(` 调用。
4. role 零 `$!` / `@!` / `%!` / `&!` 引用；`self.input-handler` / `self.read-line` 与自身 `use` 都在。
5. `cmp-ok $sess-lines, '<', 2900`。
6. `META6.json` provides 53 条，含 Replay。
7. 运行时：`recall` 空历史 127、按历史长度算编号、`-1` 取末尾、预填只给一次；`source` 的 `say` 进 `out`、`index` 与 `history` 各只 +1、脚本里的 `my` 留存；`paste` 两种模式判定。

### 3.83.5 本版不做

- 渲染辅助（`!fmt` / `!render-bytes` / `!render-path-list`）与补全簇（`completions` 系列）仍留 Session；它们的写侧（`%!type-cache`）同样可以走窄入口，见 ADR-0064 §8。
- 可观察差异：无。
## 3.84 Session 拆分（第六步）：补全层 role（V-355，0.151.0 / ADR-0065）

§3.83 之后 `Session.rakumod` 是 2,868 行。本条把补全管线搬成第七个 role：**2,868 → 2,679 行**（17 insertions / 203 deletions，含接线），新文件 `Completion.rakumod` **225 行 / 5 个方法**。对外行为不变。

### 3.84.1 文件划分

| 文件 | 角色 | 内容 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Completion.rakumod` | `unit role Rakuish::REPL::Session::Completion` | 补全管线，5 个方法 |
| `lib/Rakuish/REPL/Session.rakumod` | `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells does ...Replay does ...Completion` | 其余 |

搬走：`completions`（公开 API：CLI 的 `get-completions` 回调、LineEditor 的 Tab）+ `!session-name-completions` / `!method-completions` / `!completion-value` / `!resolve-type`。
留下：`error-marks` / `!known-name` / `!path-names` —— 它们服务**错误态标红**（`Highlight.error-marks` 的回调注入），与补全只是碰巧都读 `@.decls`。
`META6.json` provides 53 → 54。

管线形状（顺序即优先级）：

```
completions(line, pos)
  ├─ in-out-completions        In[n] / Out[n]
  ├─ !method-completions       $obj. / Type::Name.
  ├─ sql-completions           SQL 字符串上下文
  └─ !session-name-completions + $.shell.completions
```

### 3.84.2 状态：零新增公开面，类型缓存给私有活容器

本条没有公开任何新属性 —— `@.out` / `@.history` / `@.decls` / `%.state` / `$.shell` / `$.engine` 都在更早的刀里公开过（这条是 §3.82.2「拆分复利」的又一次验证）。

唯一需要新入口的是 `%!type-cache`（约 4 ms/次解析，新 `use` 时整块作废）。它**不公开**，而是加一个私有方法：

```raku
method !type-cache(--> Hash) { %!type-cache }
```

role 里 `my %cache := self!type-cache;` 绑定同一个 Hash 容器。规则因此再进一步（ADR-0065 §3）：

> **role 需要的是「能读写那块状态」，不是「那块状态对用户可见」。** 私有方法完全够用。

配套：清空缓存的那句 `%!type-cache = %() if @uses.elems;` 仍在 `!eval-raku` 里（缓存的生命周期归求值核心，不归补全）。

### 3.84.3 EVAL 与依赖

- `!resolve-type` 要重放会话声明再解析类型名。EVAL 走 `self!eval-in-session(...)`（§3.81.3 的硬约束：role 里 EVAL 会把用户声明落到 role 包名下）。这里虽说只取类型对象、不写快照，仍保持「role 不 EVAL」一条线。
- role 自己 `use`：`Rakuish::REPL::Complete`（`common-prefix` / `in-out-completions`）、`Rakuish::REPL::Methods`（`method-context` / `method-names` / `filter-names`）、`Rakuish::REPL::SqlComplete`（`sql-completions`）。Session 的 `use` 不泄漏进 role 的编译单元（§3.82.3）。

### 3.84.4 结构不变量（`t/89-completion-split.t`，51 条）

1. 文件都在；`unit role ...::Completion` 头正确；Session 的七条 `does` 与七条 `use` 都在。
2. **反方向**：5 个补全方法不在 Session 而在 Completion；`error-marks` / `!known-name` / `!path-names` 留在 Session 且不在 role。
3. 类型缓存：`has %!type-cache;`、`method !type-cache(--> Hash)`、`%!type-cache = %()` 三处都仍在 Session；role 只经 `self!type-cache`。
4. role 零类私有属性引用；无裸 `EVAL "`；三个 `use` 都在。
5. 规模：`< 2,750` 且 `> 2,600`（下限防空跑）。
6. `META6.json` provides 54，含 Completion。
7. 运行时：内置例程 / 会话变量 / 数组 / `&sub` / `use 模块` / `Box.` 方法链 / `Out[n]` / `In[n]` / 空行 List。

### 3.84.5 本版不做

渲染辅助（`!fmt` / `!render-bytes` / `!render-path-list`）仍留 Session —— 它们被 `render` 与诊断 role 同时调用，切出来会形成反向依赖。下一个候选的判据见 ADR-0065 §8。可观察差异：无。

## 3.85 Session 拆分（第七步）：`!` 命令行分发 role（V-356，0.152.0 / ADR-0066）

§3.84 之后 `Session.rakumod` 是 2,679 行，剩下两块大的：`!eval-line-body`（547 行，其中 `!` 命令行分发 313 行）与渲染段（346 行）。本条切 `!` 分发：**2,679 → 2,376 行**（5 insertions / 313 deletions），新文件 `Exec.rakumod` **343 行 / 1 个方法**。

### 3.85.1 文件划分

| 文件 | 角色 | 内容 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Exec.rakumod` | `unit role Rakuish::REPL::Session::Exec` | `method !dispatch-bang(Str $t --> Any)` |
| `lib/Rakuish/REPL/Session.rakumod` | `unit class … does …Commands …Config …Diagnostics …Persistence …Cells …Replay …Completion …Exec` | 分流点 + 其余 |

搬走的是 `!eval-line-body` 里的 `if $t.starts-with('!') { … }` 整块：元选项解析（`--` / `--tty|-t` / `--pipe|-P` / `--pipefail` / `--capture` / `--stdin FILE` / `--no-timeout` / `--timeout-ms N`）、`--pipe` 与 `--capture` 互斥、Windows cmd 内建重写、以及四类执行分支（引擎内管道 / 父进程管道 / 透传 / `--tty`）。逻辑一行未改。

留下的六个辅助不是 `!` 的私产，按调用闭包留在 Session：`!split-argv`（补全也用）/ `!split-pipeline` / `!unclosed-quote` / `!remember`（所有格共享记账）/ `!strict-result` / `!emit-chunk`。role 按名字调用它们（ADR-0060 §2 实测）。

### 3.85.2 退出语义：`Result` = 已处理，`Nil` = 不是 `!` 命令

以前「不是 `!` 命令」靠「嵌套 if 不命中就自然下落」表达。搬进方法后必须显式：

- 返回 `Result` → Session 直接 `return`；
- 返回 `Nil` → 落回后面的 Raku 求值（`!=` / `!~~` 是 Raku 运算符，不能当外部命令）。

Session 侧只剩四行委派，`if $t.starts-with('!')` 仍留在分流点：

```raku
if $t.starts-with('!') {
    my $bang = self!dispatch-bang($t);
    return $bang if $bang.defined;
}
```

### 3.85.3 零新增公开面

属性引用只有三处，且都已公开：`$.sys`（8 次段内 / 8 次段外）、`$.index`（2 / 15）、`$.stream-out`（2 / 2）。这是前六刀持续公开化状态的分红（ADR-0063 §2）。对照渲染段的 13 个属性（6 个仍私有）+ 8 个私有辅助，同样的行数量级，边界宽一倍以上。

`META6.json` provides 54 → 55。

### 3.85.4 结构不变量（`t/90-exec-split.t`，63 条）

1. 两文件都在；`unit role …::Exec` 头正确；Session 的八条 `does` 与八条 `use` 都在。
2. **反方向**：`!dispatch-bang` 不在 Session 而在 Exec；六个共享辅助留在 Session 且不在 role。
3. role 卫生：零私有属性引用；自带 `use Rakuish::Result;` 与 `use Rakuish::REPL::Shell;`；经 `$.sys` / `$.index` / `$.stream-out` / `self.pipe-handler` / `self.tty-handler` 读写状态；`--> Any` 且显式 `Nil`。
4. 规模：`< 2,450` 且 `> 2,200`。
5. `META6.json` provides 登记 Exec。
6. 运行时：空 `!` 127；`!echo hi` 走 cmd 内建重写；`--capture` 非 streamed；`--pipe` + `--capture` 互斥；`--stdin` 不存在 127；`--timeout-ms nope` 127；`!echo a | findstr a`；`--tty` / `--pipe` 经注入执行器校验；`!=` 不是 `exec`。

### 3.85.5 顺带修复：`Sys::FS.follow` 的 GC 噪声

`FS.rakumod` 的轮询行原用 `$f.e || $f.l` —— `.l` 对不存在的路径返回 **Failure 而不是抛**，布尔上下文一求值就抛、`try` 接住，但该 Failure 会偶尔留到 GC，在 DESTROY 时冒 `unhandled Failure detected in DESTROY … while trying to do '.l'`（每轮全套件 stderr 都有）。改为只认 `.e`（悬空符号链接本就按「还没回来」处理）：

```raku
my $size = $f.e ?? (try { $f.f ?? $f.s.Int !! Nil }) !! Nil;
```

`t/55` 连跑 8 次、`prove6` 单跑均无 stderr 警告。规则：**布尔链里不要引用可能返回 Failure 的 `.l` / `.d` 这类谓词**；要么先 `.Bool` 消费，要么改判据。

### 3.85.6 本版不做

渲染段（346 行）仍是唯一成块候选，但朝外 13 个属性 / 8 个辅助，边界宽一倍；求值核心（`!eval-raku` / `!pure-decl` / `!scan-cell`）不动。另一种收尾是把 `!eval-line-body` 的 if 链改成数据驱动命令表（不跨文件）。可观察差异：无。

## 3.86 会话命令表：if 链 → 数据（V-357，0.153.0 / ADR-0067）

`!eval-line-body` 原本用 106 行 `if` / `elsif` 分派 22 条会话命令，每一支手抄命中条件
（`$t eq 'perf' || $t.starts-with('perf ')`）。本版把它变成**一张表 + 一个分派器**：命令清单
成为可读数据，新增命令只需加一行，且不再可能「裸名能用、带参失效」。

### 3.86.1 表与分派器

`SESSION-COMMANDS`（`lib/Rakuish/REPL/Session.rakumod`，插在 `!eval-line-body` 之前）共 **22 项**，
字段：`name`（命令名，不带 `!`）、`mode`、`alias`（额外名字，仅 `tb`）、`arg`、`m`（方法名，不带 `!`）。

分派器 `!dispatch-command(Str $t)`：规范化 `$head = $t.trim`，逐项按 `mode` 判命中（别名只按精确匹配），
未命中 `next`；命中后按 `arg` 调 `self!"$m"(...)`；全部未命中返回 `Nil`。
`!eval-line-body` 侧只剩两行：

```raku
my $cmd = self!dispatch-command($t);
return $cmd if $cmd.defined;      # Nil = 不是会话命令，继续往下走
```

返回值语义与 ADR-0066 的 `!dispatch-bang` 一致：`Result` = 已处理，`Nil` = 未命中。
**表可任意重排**：22 个名字互不前缀（`argv` 模式要求名字后跟空白，故 `who` 不会吃掉 `whos`）。

### 3.86.2 命中模式与参数传递

| `mode` | 命中条件 | 用于 |
|---|---|---|
| `exact` | `$head eq $name` | `history` / `who` / `whos` / `rerun` |
| `only-argv` | `$head ~~ /^ $name [ ' ' \| \t ] /` | 必须带参数的命令 |
| `argv` | 两者或 | 带参可选（`perf` / `log` / `cells` …） |

| `arg` | 传给方法的实参 | 例子 |
|---|---|---|
| `raw` | 整行 `$t`（含前导空白） | `!cmd-perf($t)` |
| `trim` | `$t.trim` | `!cmd-recall($head)` |
| `const` | 表里的固定串 | `whos` → `!cmd-who('who -l')` |
| `none` | 无参 | `history` |

**语言层硬约束**：Raku 字符类的 `<[...]>` 里 `\t` **不**展开成制表符。`/^ $name <[ \t ]> /` 对
`'recall 1'` 不匹配（初版即因此让所有带参命令落回 Raku）。必须写 `[ ' ' | \t ]`（或 `<[ \x20 \t ]>`）。

### 3.86.3 表项存方法名，不存闭包

`self!"$n"(...)` 是动态私有方法分派的正确写法：`self."!$n"(...)` 会报
`No such method '!hi' … did you mean 'self!"hi"()'?`，从类外调 `!dyn` 会报
`Calling private method 'dyn' must be fully qualified …`（后者是外部调用的限制）。
`self!"$n"` 在类内、以及**对 role 组合进来的私有方法**都可达 —— 21 个方法里 12 个住在八个 role 里。
因此表项是纯数据（字符串），`t/91` 才能「读表 + 断言每个方法真实存在」。

### 3.86.4 结构不变量（`t/91` 159 条）

- 表存在、以 `\n);` 正常结束、22 项、无重名，名字集合固定为 22 个；
- 每项 `mode` / `arg` / `m` 合法（66 条）；每个 `m` 在 9 个文件（Session + 八个 role）里都有定义（22 条）；
- 特例：`tb` 的 `alias` = `<debug backtrace>`；`whos` 的 `arg=const` 且 `const='who -l'`；
- 分派器存在、含 `self!"$m"`、`!eval-line-body` 含 `self!dispatch-command($t)`、全文件只出现一次；
- 22 条逐命令断言「旧 `if` 链分支已消失」（`starts-with('<name> ')` 与 `eq '<name>'` 都不再出现）；
- 规模：Session 行数 `> 2,200` 且 `< 2,400`；
- 运行时：24 条逐命令 `op` 断言；`set` / `set -o` / `set -e` 仍 `op=set`、`set -x` 仍落回 `eval`、
  `history?` 仍 `op=doc`、`!echo table-ok` 仍 `exec`、裸 `unalias` 落回 Raku；`!!` 仍能重跑且不进 history；
- 等价性不靠断言覆盖率：35 条输入与 0.152.0（`git stash`）逐条对比 `op` / `ok` / `code` / `out`，零差异。

### 3.86.5 本版不做

`set` 家族（解析型三条正则）、`名字?`（任意标识符正则）、历史替换（受两个开关控制、要重走 `eval-line`）、
`!` 分发（ADR-0066）、shell 兜底与 Raku 本身 —— 这五段仍留在 `!eval-line-body` 的链上，顺序不变。
`!help` 自动生成命令列表留到后续版本（那属于 `!help` 输出变更，不是纯重构）。
## 3.87 补全的路径面（V-358，0.154.0）

补全在 0.154.0 之前只补「命令名 + 参数位路径」，`. ` / `..` / `~` 与「命令位的文件名」
三处是空的。本条款把路径候选收敛到 `lib/Rakuish/REPL/Shell.rakumod` 的
`!path-candidates` 一处。

### 3.87.1 三个历史洞

| 输入 | 0.153.0 | 0.154.0 | 原因 |
|---|---|---|---|
| `cd ..<Tab>` / `ls .<Tab>` | 零候选 | `../` / `./` | Rakudo 的 `dir` 不返回 `.` / `..`，由 `!path-candidates` 合成 |
| `~/<Tab>` | 零候选 | HOME 下的条目，候选仍带 `~/` | 扫描目录换成 `$*HOME`，但不把绝对路径吐回输入框 |
| `~<Tab>` | 零候选 | `~/` | 光敲 `~` 的人想补的是分隔符 |

隐藏文件规则不变：基名以 `.` 开头才 `:all`，否则不列。

### 3.87.2 命令位：命令在前，当前目录文件名在后

首词不含空格时，候选 = `fuzzy-words`（命令名 + `!` 模式的 PATH 程序）**加**当前
cwd 的文件名（各限 50，去重后命令在前）。为什么不是「命令零命中才回退文件」：
`set` / `source` / `store` 会吃掉 `s` 前缀，用户 cd 进项目后敲 `src/` 永远出不来。

首词本身是路径形态（含 `/`、`\`，或以 `.`、`~` 开头）时**直接走路径**，不跟命令名
较劲。命令位文件名过滤大小写不敏感（命令名都是小写，`c<Tab>` 要能看到
`CHANGELOG.md`），参数位保持文件系统语义（区分大小写）。

目录读的是**活的 cwd**，文件名侧没有任何缓存，切目录后下一次性调用就生效。

### 3.87.3 一个展平 bug

`lib/Rakuish/REPL/Session/Completion.rakumod` 原写 `(@names, |@shell)`：`@names`
未被展平，整个 Array 成为候选表的第一个元素，`c<Tab>` 首位是
`["class","constant"]`（不是 Str）。改为 `(|@names, |@shell)` 并按 `.Str` 去重。

### 3.87.4 不变量

`t/92-completion-paths.t` 31 条：`.`/`..`/`~/`/`~` 四类候选、隐藏文件开关、
参数位大小写敏感、命令位大小写不敏感、命令在前文件在后、`./` 与 `dir/` 短路、
切目录后命令位与参数位都跟新 cwd、`!` 前缀保留、无 Array 型候选。

### 3.87.5 本版不做

- 不缓存目录内容（活 cwd 优先于响应速度）；
- 不改 `glob` / `ls` 的 `List[IO::Path]` 渲染（§4 规定为 basename 列表）；
- 不做命令位「文件名优先于命令」的开关。

## 3.88 启动账本与「不拆脚本通路」（V-359，0.154.0 / ADR-0068）

### 3.88.1 数据（Windows，precomp 预热，3 次取最快）

| 命令 | 用时 |
|---|---|
| `raku -e 1` | 137–147 ms |
| `raku -Ilib -e 'use 3 行模块'` | 333 ms（仓库索引 ≈ +186 ms） |
| `use Rakuish::REPL::Session` | 420 ms |
| `use Rakuish::CLI`（13 个 eager use） | 444 ms |
| `rakuish --version` | 220 ms |
| `rakuish -e '1 + 1'` | 630 ms |
| `rakuish 脚本.rako` | 601–608 ms |

进程内插桩：`require CLI` 305 ms、`require Session` +3 ms、其余七模块 +19 ms、
`Session.new` 17 ms；剩约 286 ms 是 Rakudo 启动 + 编译 `bin/rakuish` + 收尾。

### 3.88.2 归因

固定成本约 406 ms（占脚本模式 68%）：Rakudo 启动 147 + 仓库索引 186 + 编译
`bin/rakuish` 73。仓库索引是**源码检出**特有：site 仓库加载一个模块只 +40 ms
（`use Test` 181、`use JSON::Fast` 179，基线 138），装机态脚本约 450 ms。
Session 自身模块加载约 108 ms（444 − 312）。

预编译必须保留：`RAKUDO_NO_PRECOMPILATION=1` 时 `use Rakuish::Result` 要 2,189 ms、
`use Rakuish::CLI` 超过 9 秒。

### 3.88.3 决定

- 不做「CLI 的 13 个 eager use 改成按模式 require」（上限 24 ms）；
- 不做「脚本走一条不经过 Session 的薄通路」（省 108 ms，但脚本模式的意义就是
  跑在同一条 Session 上：who / store / 快照 / audit / 历史 / hook / `set -o`）；
- 已在 0.106.1 做过的按模式 `require`（`lib/Rakuish/CLI.rakumod:3-11`、`:28-31`）
  是这条路线的上限，本版不再加码。

下次重看这件事的条件：用户抱怨的是**装机态**启动、Session 的传递依赖图变化、
或 Rakudo 改进了 `-Ilib` 仓库索引。

## 3.89 与 Duckula 的边界：关系代数归 Duckula（V-361，0.155.0 / ADR-0069）

Duckula 是借用 DuckDB 的 DataFrame 层。两个项目都在处理表格数据，本节把「谁
说了算」写死，往后加功能先看这一节。

### 3.89.1 边界宪章

> **Duckula 拥有关系代数，Rakuish 拥有值的表示、显示、交互与格式边界。**

`Rakuish::Data::Table` 是「列类型 + Hash 行 + 显示/导出」的最小容器，**不是**
DataFrame。`where` / `select` / `join` / `sort-by` / `limit` / `offset` /
`distinct` 是小数据糖（表行数在上百量级），需要 `group-by` / `having` / 窗口时
走 `$t.sql(...)`。

| 能力 | 归谁 | 位置 |
|---|---|---|
| 关系代数 | Duckula（SQL） | `$t.sql` / `DSL.sql` → `lib/Rakuish/Data/Duck.rakumod` |
| 值表示 / NULL 语义 | Rakuish | `lib/Rakuish/Data/Table.rakumod` |
| 显示 / 导出（CSV / Arrow / Markdown） | Rakuish | `Table.render` / `Display` |
| 类型系统（`types`、CSV 推断） | Rakuish | `lib/Rakuish/Data/Table.rakumod` |
| SQL 类型 ↔ Rakuish 类型 | 过渡期两份 | `duck-type`（Rakuish）vs `dtype-from-sql`（Duckula） |
| `Frame` 的生命周期 | Duckula | 只在 `table-from-frame` 内部出现，绝不出现在返回值 |

**冻结清单**：`Table` 不再新增 `group-by` / `having` / `window` / `pivot` /
`rolling`。新增这些名字的需求一律回答「用 `.sql`」。

### 3.89.2 空列的聚合是 NULL

| 列内容 | `sum` | `mean` | `min` / `max` |
|---|---|---|---|
| `1, NULL, 3` | `4` | `2` | `1` / `3` |
| `NULL, NULL` | `Any` | `Any` | `Any`（0.155.0 之前：`0`/`0`/`Nil`） |
| 零行 | `Any` | `Any` | `Any` |

与 `$t.sql('select sum(x) from t')` 同口径（SQL 的空列聚合就是 NULL）。
调用方用 `.defined` 判断，别用 `+ 0` 或 `// 0` —— 那正是 0.155.0 之前 Table
单方面发明的语义。`--> Num` 标注改成 `--> Any`：`Any` 不是 `Num`，旧标注会
强行把 NULL 变成 0。

### 3.89.3 报错不截断：`detail` 一行 + `hint` 后半

`X::Rakuish::V3`（`lib/Rakuish/Result.rakumod:16-19`）：

```raku
class X::Rakuish::V3 is Exception is export {
    has Str $.detail is required;
    has Str $.hint;                      # 0.155.0 / ADR-0069
    method message(--> Str) {
        return $!detail unless $!hint.defined && $!hint.chars;
        $!detail ~ "\n" ~ $!hint;
    }
}
```

SQL 桥把 DuckDB 的报错拆两段：第一行进 `detail`（保留 `SQL 执行失败:` 前缀），
其余（`Candidate bindings: ...` / `LINE 1: ...` + `^^^^`）进 `hint`。**没有
hint 时 `message` 与 0.154.1 逐字相同** —— 日志、单行状态栏、`Result.err`
的消费方不受影响。

### 3.89.4 `describe` 的两套 schema 不合并

| 对象 | 列 |
|---|---|
| `Table.describe`（也 `describe($t)`） | `name type nullable non_null distinct total sample` |
| Duckula `Frame.describe`（SQL `SUMMARIZE`） | `column_name column_type min max approx_unique avg std q25 q50 q75 count null_percentage` |

它们是**两种对象的同名方法**。Rakuish 从不把 `Frame` 交给用户（`table-from-frame`
是唯一出口，返回 `Table`），所以用户在 Rakuish 里只会看到第一种。

`Table.describe` **不改名**（ADR-0069 §3.4 记录了这条建议的自我推翻）：它是跨层
契约 —— `DSL.describe`（`lib/Rakuish/DSL.rakumod:140`）、`Engine` 角色的
`describe` 契约（`lib/Rakuish/Data/Table.rakumod:161`）、REPL `describe` 命令
（`lib/Rakuish/REPL/Session.rakumod:2211`、`:2216`）、`t/25-describe-complete.t`
的 20+ 条断言、`docs/DEVELOPMENT.md:541` 的用法。

### 3.89.5 依赖地板只有一个真相

`lib/Rakuish/Data/Duck.rakumod` 顶部：

```raku
our constant DUCKULA-MIN-VERSION = v0.54.0;   # columns-typed 的签名成为硬契约
our constant DUCKULA-DB-VERSION  = v1.4.3;    # Duckula 自己 META6 的地板
our constant ENGINE-DB-VERSION   = v1.3.1;    # Engine 直连路径的地板
```

报错文案引用常量；`lib/Rakuish/Data.rakumod` 里过期的 `Duckula:ver<0.36+>`、
`Duckula:ver<0.38+>` 与 `DB::DuckDB:ver<1.2.2+>` 都已清掉，现为 `0.54+` / `1.3.1+`。
两条路径地板不同**是有意的**：走 Duckula 就满足 Duckula 的地板，走 Engine 直连只要
1.3.1（decimal 修正）。

地板从 0.38.0 提到 0.54.0 的理由不是「多了功能」，而是**形状被承诺**了：0.54.0 起
`columns-typed` 的 docstring 写成三条硬契约（List 长度 == `names.elems`、每列长度
== `elems`、NULL 是 `Any`）。桥依赖的是形状，不是方法的存在性。

### 3.89.6 结构不变量（`t/93-duck-boundary.t`，42 条）

1. 空列/零行聚合 9 条：`sum` / `mean` / `min` / `max` 全部 `.defined` 为假。
2. 非空列聚合 4 条：数值结果与 0.154.1 一致（NULL 单元格被跳过，不参与计数）。
3. `hint` 语义 6 条：无 hint 逐字相同；有 hint 时行数 = `detail.lines + hint.lines`；
   `message` 以 detail 开头；`detail` 自身仍是单行；`hint` 不是必填。
4. `describe` 3 条：列集合恒为 7 列、逐列一行、没有 `column_name`。
5. 冻结 6 条：`Table` 源码里没有 `method group-by|having|window|pivot|rolling`，
   但仍有 `method sql`（逃生口）。
6. 地板 9 条：三个常量的值、三处过期字面量已清除（`0.36` / `0.38` / `1.2.2`）、
   `Data.rakumod` 的提示与常量同值、`Duck.rakumod` 的报错引用常量、旧注释
   「等上游修」已消失且记下了上游修好的版本（`0.53.0`）。
7. 与 SQL 对齐 8 条（Duckula 缺席时 `skip`）：SQL 的空列 `sum` 也是 NULL、
   `count(*)` 不受 NULL 影响、未知列报错仍是 `X::Rakuish::Data`、`detail` 单行、
   `hint` 带候选行、`message` 两段。

### 3.89.7 本版不做

- `duck-type` 退役改用 `Duckula::Dtype::dtype-from-sql`（要么改上游导出面，要么
  把 Duckula 变成编译期依赖）。
- 合并 `Engine::DuckDB` 与 `Duck.rakumod` 两个适配层（前者服务行流，后者服务
  列式 Table；合并 = Duckula 变必选）。
- 统一 `join` 默认值（`Table` 是 `left`、SQL 是 `inner`）：改默认会静默改变既有
  脚本结果，保留差异并在使用时显式传 `:how`。
- 把 `Frame` 交给用户（会把 Duckula 类型漏进 `store` / `snapshot` / `cells`）。

### 3.89.8 上游回音（0.155.2）

ADR-0069 给 Duckula 的五件契约在上游 v0.54.0 全部回应（Duckula 侧 commit
`665fb1d` + `0719544`，Windows 53 文件 / 1,855 项、WSL 同样 1,855 项全绿）：

| 契约 | 上游结果 | 对 Rakuish 的影响 |
|---|---|---|
| `columns-typed` 转正 | 补成三条硬契约，注明 v0.54.0 起签名稳定 | 地板 0.38.0 → **0.54.0** |
| `ipc-buf` 修 TIMESTAMPTZ | **0.53.0 已修**；pyarrow 26.0.1 回归：`write-ipc(:format<file>)` / `(:format<stream>)` / `ipc-buf` 三路都能读 TIMESTAMPTZ，DATE 为 `date32[day]`，微秒 `.123456` 未截 | 桥仍不写 IPC，但注释里的「等上游修」必须删掉——理由改为「不新增耦合」 |
| 惰性 `head(n)` | 本来就有（`plan-limit`，`explain` 里可见 `LIMIT`） | 无 |
| 类型映射表 | 进 Duckula 的 `ARCHITECTURE.md §8.63` 与 README。值得记：Arrow 没有 int128，`HUGEINT → decimal128(38,0)` | 无 |
| `read-arrow` / `append-arrow` | 前者冻结签名，后者新增；`append-arrow` 用**严格列集比对**，因为 DuckDB `INSERT ... BY NAME` 对缺失列静默填 NULL | 无（Rakuish 只用 `read-arrow`） |

三处不一致按 ADR 保持各自默认：`join` 默认值（`Table` 是 `left`、SQL 是 `inner`）、
`describe` 的两套 schema、两个 DuckDB 适配层。

## 3.90 混合格声明 / 字符串路径 / 可调用显示（V-364，0.156.0 / ADR-0070）

### 3.90.1 改了哪三个点（没有新模块）

| 位置 | 改动 | 性质 |
|---|---|---|
| `lib/Rakuish/REPL/Session.rakumod` | 新增 `!top-statements` / `!decls-in-cell` / `!put-decl`，`!eval-raku` 加一条混合格旁路 | 修状态丢失 |
| `lib/Rakuish/REPL/Shell.rakumod` | 新增公开 `path-completions(Str $frag, Str :$before)` | 补全入口 |
| `lib/Rakuish/REPL/Session/Completion.rakumod` | 新增 `!string-path-prefix`，`completions` 在 SQL 之后接字符串路径 | 补全入口 |
| `lib/Rakuish/Display.rakumod` | 标量分支前加 `Callable` 分支 | 修空白格 |

provides 不变（55），ADR 计数 69 → 70。

### 3.90.2 声明不在格首时也要跨格存活

规则：`!eval-raku` 在 `%decl` 为空（即不是纯声明格）时，把 `$cell-code` 按**顶层分号**切成若干语句，逐条试 `!pure-decl`，带 `key` 的记进 `@.decls` —— 只在求值成功后写。

顶层分号的判据：深度 0 且不在引号 / 注释里。`(`/`[`/`{` 增加深度，`)`/`]`/`}`` 减少深度；`#` 到行尾全部跳过。

| 输入 | `@.decls` |
|---|---|
| `my $a = 1; sub f { 42 }` | `sub:f` |
| `sub f { 42 }; say 1` | 走纯声明格老路（`sub:f`，本格不产出 `Out[n]`） |
| `my $a = 1; class C { }` | 不记（类型声明体是声明期求值，重放会带副作用） |
| `my $a = 1; constant K = 7` | 不记（同一条理由） |
| `if True { sub inner { 1 } }` | 不记（不是顶层） |
| `sub bad { 1 }; no-such-routine` | 不记（格失败） |
| `my $t = 'a;b'; sub q1 { 7 }` | `sub:q1`（字符串里的分号不是边界） |

历史理由与取证见 ADR-0070 §2.1：这条不是补全缺口，是**求值核心的跨格可见性**缺口，`who` / `store` / 快照 / prelude 全部受同一个 `@.decls` 支配。

### 3.90.3 字符串字面量里的路径补全

入口分工：

- 参数位的路径仍走 `Shell.completions`（0.154.0 的 `!path-candidates`）。
- 字符串内的路径走 `Shell.path-completions($frag, :$before)` —— `:before` 是**开引号及其之前**的原文，候选把它原样拼回去。

`Completion.completions` 的顺序：`In/Out` 引用 → 方法名 → SQL → **字符串路径** → 会话名字 + Shell。

三个拒绝条件（都是 `!string-path-prefix` 里的硬判据）：

1. 双引号字符串 —— 会插值，候选是幻觉；
2. 片段含空白 —— 是句子不是路径；
3. 引号已闭合 —— 不在字符串里，交给原流程。

### 3.90.4 可调用对象的显示

`Bundle` 对 `$v ~~ Callable` 产出：`sub helper-demo(Int $x --> Int) { … }` 这样的文本摘要；markdown 用 ```raku 围栏，html 用 `pre-block`，`json` 只放文本摘要（代码对象不可序列化，也会漏地址），`meta<kind>` = `callable`。

种类词用小写分类（`sub` / `method` / `routine` / `block` / `callable`）而不是 `.WHAT.^name`：后者对带签名的 sub 给出 `Sub+{Callable[Int]}`。

实现注意：`"{ … }"` 在双引号里是块插值（`…` 是 stub 操作符），运行期会 `Stub code executed`；必须用单引号串拼 `$head ~ ' { … }'`。

### 3.90.5 结构不变量

- `t/94-mixed-decl.t` 27 条：混合格 sub 存活（值 / `key` / `src` / 下一格可调）、补全与 `who -l` 可见、声明在格首仍是声明格（`value` 为 `Any`）、`our sub` 存活而 `class` / `constant` 不记、块内不记、失败格不记、纯语句格零声明、字符串分号不是边界。
- `t/92-completion-paths.t` 35 条（+4）：字符串路径有候选、保留开引号、双引号不给、含空白不给。
- `t/80-display-protocol.t` 52 条（+11）：`text` 非空、`meta<kind>` 为 `callable`、具名 sub 带名字与签名、`Block` 分类、`json` 是字符串、子进程 stderr 无 `coerced to string`。

### 3.90.6 本版不做

- 不改 `EVAL` 的块作用域（`do { }` 是整个会话设计的根）。
- 不把顶层声明提升成 `our` / GLOBAL 符号（重定义会 `Redeclaration of symbol`）。
- 双引号字符串不做路径补全。
- 纯声明格的处理路径一行不动（类型格改写、`$slot` 顺序、失败回滚保持原样）。

## 4. Sys API（V-20x）

**V-201**：路径一律 `IO::Path`，不自建 `Platform::Path`。
`resolve` 做词法归一化 + **中间 symlink canonical 校验**，`../` 或真实目标越界
抛 `X::Rakuish::Sandbox`。

**V-202**：文件 API（经 `Sys` 委托到 `Sys::FS`）：
`read` / `write` / `append` / `ls` / `stat` / `rm` / `cp` / `mv` / `mkdir` / `glob`。
`write` 默认原子写（Windows 降级失败必须回滚，不先丢目标）；`rm` 不跟随符号链接、
拒绝删会话 root、支持 `:dry-run`；`cp -r` 遇到 symlink 直接拒绝；`ls file` 返回
单元素列表；`glob` 支持 `*` / `?`，`*` 不跨目录分隔符。

**V-203**：进程 API（`Sys::Proc`）：`exec` / `spawn` / `spawn-pipeline` /
`wait` / `cancel`；`Sys.pipe-exec(@stages, :&on-out, :&on-err)` 是 `! a | b`
的底层（0.143.0，V-347），父进程的交互式管道 hook 也调它（0.144.0，V-348），
`--pipe` 透传同样经它（`:no-capture` + `on-out/on-err`，0.145.0，V-349）；
`spawn-pipeline` 自 0.145.0 起允许 1 段（单命令按一段管道处理），并支持
`:pipefail` 与 `:stdin-file`。`spawn` 另支持 `:stdin-file`（16 KiB 分块 + 背压）。
`Handle.stdout` / `.stderr` 是 `Channel.Supply` 真流式输出。
`wait(:&on-out, :&on-err)` 可在进程还在跑时逐块回调（0.79.0，Agent 的
`chunk` 帧就建立在它上面）；回调抛异常只让该路停止转发，不影响最终结果。
`cwd` / `env` 经 `Proc::Async.start(:cwd, :ENV)` 显式下传，宿主 `$*CWD` / `%*ENV` 不变。

**V-204**：`exec` 永不抛：正常 `0`、启动失败 `127`、超时 `124`、取消 `137`；
`Result.value` 带 `exe / argv / timed-out / cancelled / truncated / start-failed` 供审计。
输出由 `Handle.wait` 边读边按 UTF-8 **字节**限流，超过 `max-bytes` 保留安全前缀并
丢弃后续（内存不随输出增长），且不切坏中文。

**V-205**：错误模型——读 / 写 / 列目录 / stat **抛异常**（Raku 风格）；
`rm` / `cp` / `mv` / `mkdir` 返回 `Result`；Agent 边界用 `Sys.try-op` 统一收敛。

**V-206**：Windows 只承诺 argv 外部命令 + 文件 API，不承诺 bash / POSIX 语法。
`IO::Path.mode` / `.modified` 在 Windows 上可能返回 0 或 1969 年假值，
`Stat` 如实返回、不编造时间；`DSL.recent` 检测到不可信时间就降级为全量。

**V-207**：`Result` 提供多格式渲染层 `render(Str $format = 'text', *%opts --> Str)`：

| 格式 | 别名 | 说明 |
|---|---|---|
| `text` | `txt` / `plain` | 默认人读格式；`ok/op/code/elapsed/out/err/value`，不掺 ANSI |
| `json` | — | JSON；默认紧凑，`:pretty` 展开；键序稳定（按 key 排序），路径统一 `/` |
| `markdown` | `md` | 标题 + 元信息 + `stdout` / `stderr` / `value` 代码围栏；围栏会自动加长 |

`to-text` / `to-json` / `to-markdown` 是等价便捷方法。未知格式抛
`X::Rakuish::Render`（定义在 `Rakuish::Result::Renderer`），不静默回落 `text`。
渲染层不读文件、不起进程、不改 `Result`。

---

## 5. DSL 与 Command（V-30x）

**V-301**：`Rakuish::DSL` 导出短 sub：
`ls / read / write / append / stat / rm / cp / mv / mkdir / glob / exec /
cd / pwd / cwd / resolve / env / get-env / set-env / unset-env /
try-op / timed / help / recent`。
它们委托给会话绑定的 `Sys`；用户想加「常用命令」就再写一个普通 Raku sub，
返回可组合的值，无需注册表、无需改分支表。

**V-302**：`Rakuish::Command` 提供 `role Command { name / spec / run(Sys, @args --> Result) }`、
`CommandSpec`（参数 schema → JSON Schema）、`ExternalCommand` / `BuiltinCommand`、
可扩展 `CommandRegistry`（默认 13 个命令）。加命令只需 `register(...)`。

**V-303**：`BuiltinCommand.run` 必须**透传** handler 已返回的 `Result`，
否则外层 `try-op` 会把子进程退出码伪装成 0、`out` 吞成空串。

**V-304**：内置命令统一附带 text 渲染：`BuiltinCommand.run` 返回的 `Result`
保留结构化 `value/out/err/op`，同时把 `render('text')` 写入 `Result.rendered`。
`Result.text` / `.to-text` / `.gist` 优先返回该缓存；`say $result` 与 REPL
展示内置命令结果时走 text，而不是对象的 raku 结构。`render('json')` /
`render('markdown')` 不受 text 缓存影响。

---

## 6. Agent 与 Sandbox（**0.81.0 整体撤销**，V-50x / V-60x）

> 本节全部条款已于 **0.81.0 / [ADR-0019](docs/ADR-0019-local-full-privilege-shell.md)**
> 随 Agent 线一并撤销。保留编号与摘要只为**可追溯**：老客户端 / 旧文档提到这些
> 条款时，能查到「它曾经是什么、为什么没了」。
> **不要按本节实现任何东西** —— 代码里已经没有对应模块。

### 6.1 撤销清单

| 条款 | 原内容（摘要） | 撤销原因 |
|---|---|---|
| V-501 | 请求为 JSONL（一行一个 JSON） | 结构化 op 协议随 Agent 删除 |
| V-502 | 解析 → 认证 → 策略 → 分派 → 审计 → 结构化响应 | 无请求方 |
| V-503 | op 白名单；**没有 `eval` op** | 本机全权限，Raku 源码直接 EVAL |
| V-504 | 每会话独立 `Sys`；`exec.cwd` 过 root；请求级 env 白名单 | 全权限：`!` 直接起进程，不做 argv/env 审查 |
| V-505 | 传输层 JSONL over stdio / TCP 只绑 127.0.0.1 | 没有传输层 |
| V-151 | 常驻多客户端 / `serve-once` / 每连接独立 Agent / worker | 没有常驻服务 |
| V-601 | 显式 `--root`（无默认值，不传就起不来） | 本机会话 root 默认 `/`（Windows 为当前盘根 + all-drives） |
| V-602 | 只监听 127.0.0.1 | 不监听 |
| V-603 | 启动时生成 token（CSPRNG） | 没有认证面 |
| V-604 | `exec` 默认关闭 + argv 白名单精确匹配 | 全权限，无白名单 |
| V-605 | 读写 1 MiB / 超时 30 s / 输出 1 MiB，请求级只能调小 | 限额是 Agent 的防护，本机保留超时（V-155）但不做请求级降级 |
| V-606 | 审计不含 token 与文件内容 | **保留其精神**，见 V-194…V-196（审计仍在） |
| V-607 | `allow-code-exec` 闸门（默认 False，启动期双开关） | 全权限：本机本来就能跑 Raku，闸门失去对象 |
| V-190…V-193 | `stream` / `cancel` 分帧与取消 | 分帧是协议能力，协议没了它就没有作用对象 |

### 6.2 唯一被继承下来的东西

**审计**。V-606 的「不记 token / 不记文件内容 / 源码只记指纹」被 V-194…V-196
继承，并升级为**全进程唯一写入点**（`Kernel.execute` 的 `LEAVE`）。
审计与安全壳是两件独立的事：壳撤了，账不能撤。

---

## 7. 明确不支持 / 待办（V-90x）

| 编号 | 内容 | 归属 |
|---|---|---|
| V-901 | bash / POSIX 语法（重定向、变量展开、glob、heredoc、`&&` 短路语义、`$?`、`||` 与多段式管道） | 永不支持；用 Raku 表达。**唯一例外**：`!` 行顶层单个 `\|` 串联外部命令（0.143.0，V-347；`--tty` 下的交互式变体见 0.144.0 / V-348，`--pipe` 透传与 `--pipefail` / `--stdin` 见 0.145.0 / V-349），仍不是 shell |
| V-902 | `%magic` 分流、auto-shell 回退、反引号 shellq | 已删除（Phase 3） |
| V-903 | glob 转义、brace 嵌套等剩余完整语法 | 已实现（0.65，V-153）；Shell 薄层文件名参数仍只展开 `* ?` |
| V-904 | `class` / `role` / `grammar` 的跨格持久 | 已实现（0.65，V-153）；类型对象身份不跨格 |
| V-905 | worker 派生孙进程的强杀、跨连接状态共享、可恢复/事务一致性游标 | 不做（worker 仍不引入 job object / 进程树跟踪；`tty-exec` 的进程组交接只覆盖前台交接，见 V-175） |
| V-906 | **服务侧**持久求值器 / 常驻编译单元（rakupp 常驻引擎、每连接一个） | **不做**：0.81.0 放弃 Agent 线后驱动力（Agent 并发）消失；三层探针亦证明 rakupp 缺 `:pty` 与 async socket 收尾（[PROBE-2026-11-16-adaptation](docs/PROBE-2026-11-16-rakupp-adaptation.md)）。**0.83.0 收窄适用域**：单用户会话的**引擎子进程**（V-212 / [ADR-0021](docs/ADR-0021-eval-worker.md)）不是本条对象 —— 它换的是崩溃隔离而不是启动时间，且跨格状态正是产品要的特性。**0.121.1**：该线彻底终结 —— 只支持标准 Rakudo（MoarVM），不再考虑 rakupp（[ADR-0046](docs/ADR-0046-rakudo-only.md)） |
| V-907 | CSV 方言参数 | 已实现（0.69，V-162 / ADR-0006 §2）；不做编码 / 多行字段精细控制 |
| V-908 | SQL AST 级补全 | 不做（ADR-0006 §4）：不引解析器依赖，启发式已覆盖主要场景 |
| V-909 | 交互式子进程自动探测、无开关的交互式捕获 | 不做（ADR-0007 §4）；本地 `tty-exec`（V-116）负责真交互，`pty-exec` 负责带超时的捕获 |

---

## 8. 验收

- `raku -Ilib t/*.t`：Windows / Linux 双平台 `not ok = 0`；
  `t/07` 专门守护入口契约（**只有一个入口**、无 v2 / Agent 痕迹、版本一致、`api = 3`）。
- `bash tools/run-all.sh`：任意一条 `not ok` / 非零退出码 / 缺 TAP plan 都算问题，
  脚本退出码即 `问题总数 == 0`。
- `python3 tools/tty-check.py`（Linux / WSL）：真 PTY 交互自检，覆盖 banner、
  彩色 prompt、Vi 徽标、Tab / SQL 补全、describe、Ctrl-C 中断后继续求值、
  嵌套 REPL 的 TTY 直通，以及 `tty-exec` 期间前台进程组 SIGINT 的归属
  （ADR-0009 / ADR-0011，25 项）；`t/27-interrupt.t` / `t/30-tty-exec-sigint.t` /
  `t/32-job-control.t` 在 Linux/WSL 也跑真 PTY 断言。
- `t/28` / `t/29`：PTY 捕获与能力探测双平台回归；`t/29` 用子类注入
  「不支持 PTY」的失败路径，不需要真的安装旧 Rakudo。
- `t/32`：进程组交接（V-175）的真 controlling terminal 回归，Windows
  整段 skip（POSIX-only）。
- `t/33`：结果着色与输入行高亮（V-176 / V-177 / V-270）：着色纯文本等价、
  `:!color` 逐字节相同、非 TTY 零 ANSI、跨行引号染色与不变式。
- `t/10`：日常 shell 观感（含 V-271 / V-274）：大文件 head/tail 流式读、
  `read` 超限的三条出路提示、tail -f 解析与路由（mock job-dispatch）。
- `t/34`：用户层命令（V-178…V-181）与 P0 三处订正：选项补全、`doc` 零 EVAL、
  目录栈、会话日志；反向断言覆盖「日志不含 ANSI」「未绑定键必须失败」
  「`doc 1+1` / `doc a;rm -rf` 必须失败」。
- `t/35`：内核与前端（V-182 / V-183）：双路径逐字段对账、策略拒绝不推进
  `Out[n]`、前端不能放宽策略、root 越界 403、`op` 通道 501、
  以及 `bin/rakuish` 的静态断言（不得直连 `eval-line`）。
- `t/36`：Windows 控制台编码（V-187）：非交互不许改码页、`restore` 幂等、
  切换调用必须在参数分发之前、管道下中文输入输出完好。
- `python3 tools/tty-cjk-win.py`（Windows 真控制台）：中文回显、`ls 中文目录`、
  `say "中文"`、无 crash 四项；无控制台时自动经 winpty 重启。
- `t/37`：命令名单一数据源（V-188）与输入序/格号分离（V-189）：名单三视图
  一致、`hint`/`plugin` 可补全、分发表双向一致、`OPTIONS` 键合法；会话命令与
  失败格进 `history` 但不占格号、多行格记完整源码、`!!` 不重复记。
- `t/38`：展示包与 op 通道（V-184…V-186）：9 种 kind 的格式可用性、text 零
  ANSI、协商顺序、未知格式回退、**降级时 `format` 如实回填 `text`**、
  `max-rows` 截断标记、`Kernel.bundle`/`present`、op 通道
  （capabilities / 501 / 2 / 403）、Agent 回复带 `display`（成功/失败/401）、
  `format=markdown` 生效且不改动既有键。
- `t/44`：`!` 流式与超时（V-229…V-231）：`Proc` 回调先于结束、Session
  stream-out 多块且不重放、`--capture` 回到捕获、`--timeout-ms` / `--no-timeout`、
  非法参数、引擎 chunk 帧到父进程、终帧 `streamed`。
- `t/45`：启动层（V-232…V-236）：rc 多行 / 变量 / alias / 选项且不占格号、
  错误带行号不中断、`set -o` 五选项各自执行点、prompt 吞噪声与异常回退、
  引擎 rc / prompt 协议、崩溃重启后 rc 重跑。
- `t/55`：tail -f 跟随循环（V-272…V-276）：初始末行 / lines=0、半行缓冲与
  跨 poll 多字节 UTF-8、截断轮转重读、消失重现、CRLF 剥 `\r`、
  should-stop 停止码 130、错误路径（should-stop 回调当情景驱动器，确定性）。
- `t/56`：tail -f 交互契约（V-272…V-275，真 PTY）：实时出现新增行、
  Ctrl-C 停跟随且引擎不重启（$*PID 不变）、my 变量保留、head -f 拒绝、
  之后干净退出；Windows 整段 skip（解析与循环由 t/10 / t/55 覆盖）。
- `t/57`：交互手感纯函数（V-277…V-282）：公共前缀、子序列 rank、
  fuzzy-words 前缀优先与回退、suggest-suffix 来源优先级、error-marks
  三探测器与跨行括号吸收、highlight-line :@marks 不变式。
- `t/58`：HlField 渲染与动作（V-277…V-281，不经 TTY）：灰字建议与宽度
  不变式、accept 退化、Ctrl-R 循环 / 回绕 / 复位、菜单去重与空候选、
  标记进渲染、掩码静默、键绑定接线。
- `t/59`：交互手感真 PTY 冒烟（V-277 / V-279…V-281）：灰字建议出现且
  → 接受、ShiftTab 菜单打印在输入行下方、未知命令标红、Ctrl-R 拉回
  历史、干净退出；Windows 整段 skip（t/58 覆盖渲染与动作契约）。
- `t/60`：手感后续清单引擎侧集成（V-285 / V-286）：真实 `@!out` 历史喂
  `Session.completions` 的 `In[`/`Out[` 引用补全（含边界与上限）、跨格
  `sub`/`my` 声明消除命令误标（真未知命令仍标红）。
- `t/61`：junction 结果契约（V-287）：Result 能装 `1|2`、`value-defined`、
  text/json/markdown/to-hash/**display** 均渲染为 `any(...)`（display 的
  标量/stdout 路径不变）、Session 求值与 `_`/`Out[n]` 保留原对象、普通标量
  渲染不变。
- `t/79`：对标 IPython 的 P0 修复（V-319…V-325）：前奏顺序（单/多变量、声明后仍可求值）、
  纯声明格不占格号且不渲染、内省不记账不改 `_`、`In[n]` 绑定与 In/Out 补全长度分叉、
  display 的 `source` 与 out/value 分工、不可 JSON 化值的降级（`Complex` / 自定义类）、
  README 与 `tools/install.sh` 的静态一致性。
- `t/80`：显示协议 P1（V-326…V-330）：`to-mime` 优先级与失败降级、额外 MIME
  五处口径一致、HTML/Markdown/JSON 包装与终端降级、`display()` 不产生 Out[n]
  且不改 `_`、notebook 一格多条 display 与 execute_result 分离。
- 每个条款有对应断言；正向（必须含 Y）与反向（不得含 X）成对出现。
