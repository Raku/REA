# 测试夹具（t/62 跨格 use / t/63 方法补全）：模块名即类名，和 DB::DuckDB
# 那种包形态一致；带公有方法、一个 submethod new 和一个私有方法。
unit class TestNS::Box;

submethod new(--> TestNS::Box) { self.bless }

method hi(--> Int) { 42 }
method hello(--> Str) { 'hello' }
method !secret(--> Str) { 'nope' }
