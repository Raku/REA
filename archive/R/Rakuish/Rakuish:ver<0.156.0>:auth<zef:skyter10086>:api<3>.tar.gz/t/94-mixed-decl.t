use v6.d;
use Test;
use lib 'lib';
use Rakuish::REPL::Session;

plan 27;

# 0.156.0 / V-364 / ADR-0070：声明不在格首时（`my $a = 1; sub f { 42 }`）过去
# 整格不进 @.decls —— 词法声明随 EVAL 块结束消失，下一格 `f` 就 Undeclared
# routine。现在按顶层 `;` 切一遍，逐条试 !pure-decl。

# ── 1. 混合格里的 sub 存活 ───────────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    my $r = $s.eval-line('my $alpha = 1; my @arr = 1,2; sub helper2 { 42 }');
    ok $r.ok, '混合格里声明 sub 的格子求值成功';
    is $s.decls.elems, 1, '只记下那一条声明（变量不进 @.decls）';
    is ($s.decls[0]<key> // ''), 'sub:helper2', 'key 是 sub:helper2';
    ok $s.decls[0]<src>.Str.contains('sub helper2'), 'src 是可重放的声明源码';

    my $r2 = $s.eval-line('helper2');
    ok $r2.ok, '下一格能调用混合格里声明的 sub';
    is $r2.value, 42, '值正确';
}

# ── 2. 补全与 who 也能看见它 ─────────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    $s.eval-line('my $a = 1; sub helper2 { 42 }');
    my @c = $s.completions('helpe', 5);
    ok @c.first({ .Str.contains('helper2') }).defined, '补全能出混合格里的 sub 名';
    my $who = $s.eval-line('who -l');
    ok $who.out.contains('helper2'), 'who -l 列出混合格里的 sub';
}

# ── 3. 声明在中间、后面还有语句 ──────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    # 格首是声明时仍按「声明格」处理（沿用 0.126.0 的约定：不占 Out[n]），
    # 后面的语句照常执行，只是它们的值不当结果。
    my $r = $s.eval-line('sub mid { 3 }; my $tail = 5; $tail + 1');
    ok $r.ok, '声明在格首时整格仍求值';
    is $r.value, Any, '声明格不产出结果值（Out[n] 不推进）';
    is $s.eval-line('mid').value, 3, '中间的 sub 存活到下一格';

    # 非声明语句在前时，整格是普通结果格 —— 值要出来。
    my $s2 = Rakuish::REPL::Session.new;
    my $r2 = $s2.eval-line('my $q = 5; sub mid2 { 3 }; $q + 1');
    ok $r2.ok, '语句在前时整格求值成功';
    is $r2.value, 6, '后面的表达式值就是结果';
    is $s2.eval-line('mid2').value, 3, '中间的 sub 同样存活';
}

# ── 4. 混合格里的 our sub 记；类型与 constant 不记（ADR-0050 红线）────
{
    my $s = Rakuish::REPL::Session.new;
    my $r = $s.eval-line('my $v = 1; class Box { method hi { "box" } }');
    ok $r.ok, '混合格里声明 class 成功';
    nok $s.eval-line('Box.new.hi').ok,
        '混合格里的 class 下一格看不见（沿用 ADR-0050 的「混合格类型不缓存」红线）';
    nok $s.decls.first({ (.<key> // '').starts-with('class:') }).defined,
        '混合格里的 class 不进 @.decls（声明体求值有副作用，重放会带进后续格）';

    my $s2 = Rakuish::REPL::Session.new;
    $s2.eval-line('my $x = 2; our sub ours { $x }');
    is $s2.eval-line('ours').value, 2, 'our sub 在混合格里存活';

    my $s3 = Rakuish::REPL::Session.new;
    $s3.eval-line('my $y = 1; constant KC = 7');
    nok $s3.decls.first({ (.<key> // '').starts-with('constant:') }).defined,
        'constant 同样不记（声明期求值，同一条红线）';
}

# ── 5. 不该记的三种：块内声明、失败格、纯语句格 ──────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    my $r = $s.eval-line('my $n = 1; if True { sub inner { 1 } }');
    ok $r.ok, '嵌套声明格求值成功';
    nok $s.decls.first({ (.<key> // '').contains('inner') }).defined,
        '块内声明的 sub 不进 @.decls（不是顶层）';

    my $s2 = Rakuish::REPL::Session.new;
    my $bad = $s2.eval-line('sub bad { 1 }; no-such-routine-here');
    nok $bad.ok, '失败格果然失败';
    nok $s2.decls.first({ (.<key> // '').eq('sub:bad') }).defined,
        '失败格里的声明不留下（下一格不该看见半截状态）';

    my $s3 = Rakuish::REPL::Session.new;
    $s3.eval-line('my $p = 1; $p + 1');
    is $s3.decls.elems, 0, '纯语句格不产生任何声明';
}

# ── 6. 字符串里的分号不是语句边界 ────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    my $r = $s.eval-line(q{my $t = 'a;b'; sub q1 { 7 }});
    ok $r.ok, '字符串含分号的格子求值成功';
    is $s.decls.elems, 1, '字符串里的分号没有被当成语句边界';
    is $s.eval-line('q1').value, 7, 'sub 正常存活';
}

done-testing;
