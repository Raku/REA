use Test;
use Rakuish::Sys;
use Rakuish::REPL::Session;

# t/10 —— REPL 的日常 shell 观感层
# 目标：cd/ls/cat/rm/cp/... 的常用写法符合用户习惯，但底层仍是 Sys。

my $base = $*TMPDIR.IO.add("rakuish-shell-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my $s = Rakuish::REPL::Session.new(:sys($sys));

sub out(Str $line --> Str) { $s.render($s.eval-line($line)) }

$base.add('a.txt').spurt("one\ntwo\nthree\n");
$base.add('b.md').spurt('md');
$base.add('big.txt').spurt('x' x 2048);
$base.add('.hidden').spurt('h');
$base.add('sub').mkdir;
$base.add('sub/c.txt').spurt('c');
$base.add('data.json').spurt('[{"name":"x","size":1}]');
$base.add('ADR-0001.md').spurt('adr text');
# 0.104.0：GBK 字节样本（Rakudo 内建 gb18030 编码，跨平台一致）
$base.add('gbk.txt').spurt('GBK 中文'.encode('gb18030'));

# ── cd / pwd / ls ────────────────────────────────────────────────────
is out('pwd').subst('\\', '/', :g),
    $base.Str.subst('\\', '/', :g), 'pwd 输出当前目录';
is out('cd sub'), '', 'cd 成功且安静（shell 习惯）';
is $s.sys.cwd.Str.subst('\\', '/', :g),
    $base.add('sub').Str.subst('\\', '/', :g), 'cd 真的切到 sub';
is out('pwd').subst('\\', '/', :g),
    $base.add('sub').Str.subst('\\', '/', :g), 'cd 后 pwd 正确';
is out('cd -'), '', 'cd - 成功且安静';
is $s.sys.cwd.Str.subst('\\', '/', :g),
    $base.Str.subst('\\', '/', :g), 'cd - 回到上一个目录';

my Str $ls = out('ls');
like $ls, /'a.txt'/, 'ls 列出文件';
nok $ls.contains('IO::Path'), 'ls 不显示 IO::Path';
nok $ls.contains('Out['), 'ls 不套 Out[n]';
like out('ls -a'), /'.hidden'/, 'ls -a 列出隐藏项';
ok out('ls -F').contains('sub/'), 'ls -F 给目录加 /';
like out('ls -l'), /'a.txt'/, 'ls -l 显示长格式';
like out('ls -alh'), /'2.0K'/, 'ls -alh 支持人类可读大小';
ok out('ls -d sub').contains('sub'), 'ls -d 只列目录本身';
like out('ls *.md'), /'b.md'/, 'ls 展开 glob';
like out('ls **/*.txt'), /'c.txt'/, 'ls 支持 globstar **/';
like out('ls a.txt b.md'), /'a.txt'/, 'ls 支持多个路径（1）';
like out('ls a.txt b.md'), /'b.md'/, 'ls 支持多个路径（2）';
is out('clear'), '', 'clear 在非 TTY 下不输出控制码';

# 0.87.0：TTY 由入口注入，不再让 Shell 看 `$*OUT.t`。引擎子进程的 stdout
# 是协议管道，那份探测恒 False —— `clear` 曾在 REPL 里静默失效（用户报的 bug）。
{
    my $t = Rakuish::REPL::Session.new;
    nok $t.tty, '新会话在管道下 tty=False';
    is $t.eval-line('clear').out, '', 'tty=False 时 clear 无输出';
    $t.set-tty(True);
    ok $t.tty, 'set-tty 生效';
    is $t.shell.tty, True, 'set-tty 同步给 Shell（否则 clear 与 ls 判定不一致）';
    is $t.eval-line('clear').out, "\e[2J\e[H", 'tty=True 时 clear 发 ANSI 清屏';
    $t.set-tty(False);
    is $t.eval-line('clear').out, '', '再关掉又回到无输出（不是单向开关）';
}

# ── 结构化 open / ls --json ───────────────────────────────────────────
like out('open data.json'), /'name'/ && /'x'/, 'open json 渲染为表格';
like out('open --raw data.json'), /'"name"'/, 'open --raw 保留原始文本';
like out('ls --json data.json'), /'"type": "file"'/, 'ls --json 输出结构化字段';
like out('help open'), /^ '用法: open'/, 'open --help/help 有用法';

# ── open --limit（0.134.0 / V-336）───────────────────────────────────
# 以前 open-data → DuckDB 这条路**根本没接线 max-rows**，大 CSV 只能全量
# 物化。现在可以用 --limit 在 DuckDB 里就截断，而且「只取了前 N 行」必须
# 写到输出里（限流是显式请求，但截断不能只藏在数据里）。
{
    my $many = $base.add('many-rows.csv');
    $many.spurt("id,name\n" ~ (1..50).map({ "{$_},n{$_}" }).join("\n") ~ "\n");
    my $r = $s.eval-line('open --external --limit 5 many-rows.csv');
    ok $r.ok, 'open --limit 成功';
    is $r.value.rows.elems, 5, '--limit 真的只取 5 行';
    like $r.out, /'只取了前 5 行'/, '输出里写明只取了前 5 行';
    my $all = $s.eval-line('open --external many-rows.csv');
    is $all.value.rows.elems, 50, '不带 --limit 仍是全量（不静默截断）';
    my $zero = $s.eval-line('open --external --limit 0 many-rows.csv');
    is $zero.value.rows.elems, 50, '--limit 0 = 不限';
    my $bad = $s.eval-line('open --external --limit abc many-rows.csv');
    nok $bad.ok, '非法 --limit 明确报错';
    like $bad.err, /'需要非负整数'/, '错误说明 --limit 的要求';
    # 空格与等号两种写法都认
    my $eq = $s.eval-line('open --external --limit=3 many-rows.csv');
    is $eq.value.rows.elems, 3, '--limit=N 等号写法也生效';
}

# ── 内置命令帮助 ────────────────────────────────────────────────────
like out('ls --help'), /^ '用法: ls'/, 'ls --help 显示用法';
like out('ls --help'), /'-h'/, 'ls --help 列出 -h';
like out('rm --help'), /^ '用法: rm'/, 'rm --help 显示用法';
like out('help cp'), /^ '用法: cp'/, 'help cp 显示用法';
like out('help'), /'Shell 日常命令'/, 'help 列出全部命令组';
like out('help read'), /^ '用法: read'/, 'help read 覆盖 Raku API';
like out('help --find 读取'), /'read'/, 'help --find 搜索用法';
like out('which ls'), /'shell: ls'/, 'which 查 Shell 内置';
like out('which definitely-missing'), /'未找到'/, 'which 未找到报错';

# ── which 在 PATH 里查找（0.101.3）：不再走 IO::Path.x ───────────────
# Windows 上 Rakudo 2026.11 的 IO::Path.x 对**存在的文件**也会抛
# 「rindex search target requires a concrete string, but got null」，
# 而 which 当时用 `.x` 判定可执行，异常穿透 handle 会中止后续输入。
{
    my Str $real = $*DISTRO.is-win ?? 'cmd' !! 'sh';
    my $r = $s.eval-line("which {$real}");
    ok $r.ok, "which {$real} 不崩（PATH 命中不再走 .x）";
    like $s.render($r), /:i $real/, "which {$real} 给出路径";
    ok $s.eval-line('pwd').ok, 'which 之后会话仍可继续求值';
}
like out('read --help'), /^ '用法: read'/, 'read --help 也可用';

# ── cat / read 的 --max-bytes（0.102.0）──────────────────────────────
# 以前 shell 层没有这个开关：`cat` 撞上 1 MiB 上限后，错误只说
# 「read(..., :max-bytes(N))」，用户敲的是 cat，等于没有出路。
{
    my $big = $base.add('big.txt');
    my Int $n = 1024 * 1024 + 100;
    $big.spurt('y' x $n);
    like out('cat big.txt'), /'读取超限'/, 'cat 默认上限拒绝大文件';
    like out('cat big.txt'), /'--max-bytes'/, '超限消息提示本命令也能抬';
    is $s.eval-line('cat --max-bytes=2M big.txt').out.chars, $n,
        'cat --max-bytes 抬上限生效';
    is $s.eval-line('read --max-bytes=2M big.txt').out.chars, $n,
        'read --max-bytes 同样生效';
    is $s.eval-line('cat --max-bytes 2M big.txt').out.chars, $n,
        '也支持空格分隔的写法';
    like out('cat --max-bytes=abc big.txt'), /'需要正整数'/, '非法值报用法';
    try { $big.unlink };
}
like out('env --help'), /^ '用法: env'/, 'env --help 也可用';
nok out('ls --help').contains('IO::Path'), '帮助不显示对象结构';

# ── cat / head / tail / echo ─────────────────────────────────────────
is out('cat a.txt'), "one\ntwo\nthree", 'cat 原样输出（显示层去掉末尾换行）';
is out('read ADR-0001.md'), 'adr text', 'read 按 shell 路径读取（带连字符）';
is out('head -n 2 a.txt'), "one\ntwo", 'head -n 输出前两行';
is out('tail -n 1 a.txt'), 'three', 'tail -n 输出最后一行';

# 0.97.0：大文件（>1MB 上限）head/tail 仍可读，read 报错但给出路。
my Str $huge = (1 .. 120_000).map({ "line{$_}" }).join("\n");   # > 1MB
$base.add('huge.txt').spurt($huge);
is out('head -n 2 huge.txt'), 'line1' ~ "\n" ~ 'line2',
    'head -n 2：超过 1MB 的大文件仍能读前两行';
is out('tail -n 2 huge.txt'), 'line119999' ~ "\n" ~ 'line120000',
    'tail -n 2：超过 1MB 的大文件仍能读末两行';
my $big-read = $s.eval-line('read huge.txt');
nok $big-read.ok, 'read：整份读超大文件仍失败（保护不删）';
like $big-read.err, /'read-lines'/, 'read：超限错误给出 read-lines 出路';

# 0.99.0：tail -f 的解析与路由（跟随循环本身在 t/55，这里只验命令层）。
# mock job-dispatch：记录路由参数，返回一个假的跟随结果。
{
    my @route;
    my $sys2 = Rakuish::Sys.new(:root($base), :cwd($base));
    my $s2 = Rakuish::REPL::Session.new(:sys($sys2));
    $sys2.job-dispatch = -> Str $op, *@a {
        @route.push([$op, |@a.map(*.Str)]);
        Rakuish::Result::Result.new(:ok, :code(130), :op('tail'),
            :out('已停止跟随（Ctrl-C）· 输出 0 行'));
    };
    my Str $r1 = $s2.render($s2.eval-line('tail -f a.txt'));
    is-deeply @route[0].List, ('tail-follow', 'a.txt', '10').List,
        'tail -f 路由为 tail-follow（默认 10 行）';
    like $r1, /'已停止跟随'/, '跟随结果的摘要正常渲染';

    @route = ();
    $s2.render($s2.eval-line('tail -5f a.txt'));
    is-deeply @route[0].List, ('tail-follow', 'a.txt', '5').List,
        'tail -5f 解析紧凑计数 + 跟随';

    @route = ();
    $s2.render($s2.eval-line('tail --follow -n 3 a.txt'));
    is-deeply @route[0].List, ('tail-follow', 'a.txt', '3').List,
        'tail --follow -n 3 解析长短两种选项';

    @route = ();
    my $rh = $s2.eval-line('head -f a.txt');
    nok $rh.ok, 'head -f 明确失败';
    like $rh.err, /'head 不支持'/, 'head -f 指路 tail -f';
    is @route.elems, 0, 'head -f 不发起跟随';

    like out('help tail'), /'-f'/, 'help tail 列出 -f';
}
is out('echo hello world'), 'hello world', 'echo 输出参数';
is out('echo -n hi'), 'hi', 'echo -n 不追加换行';
is out('echo "a;b"'), 'a;b', '引号内标点作为字面参数';
is out('echo "file(1).txt"'), 'file(1).txt', '引号内括号作为字面参数';

# ── mkdir / touch / cp / mv / rm ────────────────────────────────────
is out('mkdir -p d/e'), '', 'mkdir 成功且安静';
ok $base.add('d/e').d, 'mkdir 真的建好了';
is out('touch t.txt'), '', 'touch 成功且安静';
ok $base.add('t.txt').e, 'touch 创建空文件';
is out('cp a.txt c.txt'), '', 'cp 成功且安静';
is $base.add('c.txt').slurp, "one\ntwo\nthree\n", 'cp 内容正确';
is out('cp -r d d2'), '', 'cp -r 成功且安静';
ok $base.add('d2/e').d, 'cp -r 复制了子目录';
is out('mv c.txt m.txt'), '', 'mv 成功且安静';
ok $base.add('m.txt').e, 'mv 目标存在';
nok $base.add('c.txt').e, 'mv 源消失';
is out('rm -rf d2'), '', 'rm -rf 成功且安静';
nok $base.add('d2').e, 'rm -rf 真的删了';
is out('rm -f missing.txt'), '', 'rm -f 不存在也成功且安静';

# ── export / unset / glob ───────────────────────────────────────────
is out('export RAKUISH_SHELL_X=yes'), '', 'export 成功且安静';
is $sys.get-env('RAKUISH_SHELL_X'), 'yes', 'export 真的写进会话环境';
is out('echo $RAKUISH_SHELL_X'), 'yes', '参数里的 $NAME 按会话 env 展开';
is out('unset RAKUISH_SHELL_X'), '', 'unset 成功且安静';
nok $sys.get-env('RAKUISH_SHELL_X').defined, 'unset 真的删了';
like out('glob *.md'), /'b.md'/, 'glob 输出 basename';
is out('grep two a.txt'), 'two', 'grep 逐行匹配';
is out('grep -n three a.txt'), '3:three', 'grep -n 带行号';
is out('grep "^one" a.txt'), 'one', 'grep 支持正则锚点';
is out('grep -F "^one" a.txt'), '', 'grep -F 按字面匹配';
is out('grep -i ONE a.txt'), 'one', 'grep -i 忽略大小写';
is out('wc -l a.txt'), '3 a.txt', 'wc -l 统计行数并带文件名';
like out('history'), /'pwd'/, 'history 显示本会话命令';

# ── Tab 补全 provider ────────────────────────────────────────────────
ok $s.completions('c', 1).List.grep(* eq 'cat ').elems == 1, '命令名补全 cat';
ok $s.completions('ls ', 3).List.grep(* eq 'ls a.txt').elems == 1,
    '路径补全 a.txt';
nok $s.completions('ls ', 3).List.grep(* eq 'ls .hidden').elems,
    '默认不补全隐藏项';
ok $s.completions('help ', 5).List.grep(* eq 'help ls ').elems == 1,
    'help 补全命令名';

# ── jobs shell 视图 ─────────────────────────────────────────────────
my $jh = $s.sys.spawn($*EXECUTABLE.Str, '-e', 'sleep 1');
like out('jobs'), /'running'/, 'jobs 列出后台进程';
ok $s.sys.cancel($jh), '取消后台进程';
like out('jobs'), /'没有后台任务'/, '取消后 jobs 为空';

# ── Raku 变量参数不被 shell 层误吞 ──────────────────────────────────
$base.add('var-file.txt').spurt('v');
$s.eval-line('my $vp = "var-file.txt";');
is out('cat $vp'), 'v', '带 $var 的 cat 交回 Raku 变量';
$s.eval-line('my $ev = "hello-var";');
is out('echo $ev'), 'hello-var', '带 $var 的 echo 交回 Raku 变量';

# ── live-out：分页要看「stdout 是不是那个终端」（0.89.0 / V-228）──
# tty 说「用户面前有终端」，live-out 说「我写 stdout 就写到它」。
# 混用会让引擎里的分页器把表格写进协议流并吞掉下一个请求。
{
    my $x = Rakuish::REPL::Session.new;
    nok $x.live-out, '管道下 live-out=False';
    $x.set-tty(True);
    ok $x.tty, 'tty 被注入为 True（用户面前确实有终端）';
    nok $x.live-out, 'live-out 仍是 False（本进程 stdout 是管道）';

    $x.eval-line('my $tt = Rakuish::Data::Table.from-rows((1..40).map({ %(n => $_) }))');
    $x.eval-line('$tt');
    my $r = $x.eval-line('explore');
    ok $r.ok, 'explore 成功（不尝试分页）';
    ok $r.out.contains('40'), '整份文本返回，末行也在（40）';
    nok $r.out.contains('-- more'), '没有分页提示';
}

# ── 终端尺寸注入（0.88.0 / V-227）────────────────────────────────
# `COLUMNS` 不是终端属性：bash 只在交互 shell 里赋值、默认不导出，
# `resize` 之后还会变陈旧。40 列终端里按 80 列排，输出会乱序换行。
{
    my $d = $*TMPDIR.add("width-{$*PID}");
    $d.mkdir unless $d.e;
    $d.add("file-{$_}.txt").spurt('x') for 1..24;

    my $t = Rakuish::REPL::Session.new;
    is $t.width, 0, '默认宽度未知（0）';
    is $t.pager-page-size, 20, '高度未知时每页 20 行（Pager 默认）';
    $t.set-size(:height(30));
    is $t.pager-page-size, 28, '每页行数由高度推出（留 2 行）';
    $t.set-size(:height(2));
    is $t.pager-page-size, 20, '高度过小不产生 0 行页';
    $t.set-size(:width(40), :height(20));
    is $t.width, 40, 'set-size 生效';
    is $t.height, 20, '高度同样生效';
    is $t.shell.width, 40, '尺寸同步给 Shell（与 tty 同理）';
    $t.set-size(:width(0), :height(0));
    is $t.width, 40, '0 表示「未知」，不覆盖已知尺寸';

    $t.set-tty(True);                       # 多列只在 TTY 下成立
    is $t.eval-line("cd " ~ $d.Str.subst('\\', '/', :g)).ok, True, '切到夹具目录';

    my &rendered = -> Int $w {
        $t.set-size(:width($w));
        my $r = $t.eval-line("dir('.').list");
        $t.render($r).lines.grep({ .chars && !.contains('Out[') });
    };

    my @narrow = rendered(40);
    my @wide   = rendered(120);
    ok @narrow.elems > @wide.elems,
       "窄终端行数更多（40 列 {@narrow.elems} 行 vs 120 列 {@wide.elems} 行）";
    ok @narrow.map(*.chars).max <= 40,
       "40 列下没有超宽行（最宽 {@narrow.map(*.chars).max}）";

}

# ── `!` 模式的补全（0.102.0）────────────────────────────────────────
# 以前 Shell.completions 对 `!` 开头直接 return ()，`! cat a.t<Tab>` 无反应。
{
    $s.eval-line('cd ' ~ $base.Str);
    my @c = $s.completions('! cat a.t', 9);
    ok @c.grep({ $_ eq '! cat a.txt' }).elems > 0,
        '! 模式补出文件路径（保留 ! 前缀）';
    my @u = $s.completions('! raku a.t', 10);
    ok @u.grep({ $_ eq '! raku a.txt' }).elems > 0,
        '! 模式首词不是内置命令时也补路径';
    my @opt = $s.completions('! ls --', 7);
    ok @opt.elems > 0, '! 模式选项补全仍可用';
    is $s.completions('!', 1).elems, 0, '只有 ! 时不猜';
    is $s.completions('cat a.t', 7).elems > 0, True, '非 ! 模式行为不变';

    # 0.129.1：Windows 进程环境里 PATH 的键名是 `Path`（`PATHEXT` 又是大写），
    # 而 Rakudo 的 `%*ENV` 是大小写敏感 Hash —— 以前这里直接 `%*ENV<PATH>`，
    # 在本机得到 Nil，`which cmd` 和整张外部命令表一起变成空的。
    my Str $p = Rakuish::Sys::env-var('PATH');
    ok $p.chars > 0, 'env-var 取到 PATH（Windows 键名为 Path 时也能取到）';
    my Str $key = %*ENV.keys.first({ .lc eq 'path' }) // '';
    is $p, (%*ENV{$key} // '').Str, 'env-var 返回的就是进程里那个键的值';

    # 大小写不敏感是 **Windows 专属**口径（SPEC V-331 明写「POSIX 行为不变」）。
    # 0.129.1 这里曾无条件断言 `env-var('path')` 等于 PATH —— 在本机（Windows，
    # 键名是 `Path`）为真，在 Linux 上却恒红：POSIX 的环境变量名大小写敏感，
    # `path` 与 `PATH` 是两个键，`env-var('path')` 就该是空串。
    # 这条断言在 0.136.1 的 Linux `zef install .` 上真的红过，所以按平台分支。
    if $*DISTRO.is-win {
        is Rakuish::Sys::env-var('path'), $p, 'Windows 上 env-var 对大小写不敏感';
    }
    else {
        is Rakuish::Sys::env-var('path'), (%*ENV<path> // '').Str,
            'POSIX 上 env-var 不跨大小写偷值（path 与 PATH 各自独立）';
    }

    # 0.103.0：PATH 里的外部命令本身也要补（首词 + `--tty` 第二词）。
    # 取一个字母开头的候选，避开 `$` 之类被补全器视为 Raku 语法的字符。
    my @ex = Rakuish::REPL::Shell::path-executables();
    ok @ex.elems > 0, 'PATH 可执行文件扫描非空';
    my Str $name = @ex.first({ $_ ~~ /^<[a..zA..Z]>/ }) // '';
    ok $name.chars > 0, '能取到字母开头的外部命令名';
    if $name.chars {
        my Str $frag = $name.substr(0, 2);
        my @c1 = $s.completions('! ' ~ $frag, 2 + $frag.chars);
        ok @c1.grep({ $_ eq '! ' ~ $name ~ ' ' }).elems > 0,
            '! 首词补 PATH 外部命令（保留 ! 前缀）';
        my @c2 = $s.completions('! --tty ' ~ $frag, 8 + $frag.chars);
        ok @c2.grep({ $_ eq '! --tty ' ~ $name ~ ' ' }).elems > 0,
            '! --tty 第二词补外部命令';
        my @c3 = $s.completions($frag, $frag.chars);
        is @c3.grep({ $_ eq $name ~ ' ' }).elems, 0,
            '非 ! 模式不把 PATH 命令混进内置命令候选';
    }
}

# ── Windows cmd 内建（0.130.0 / ADR-0049 / V-332）────────────────────
# `echo` / `dir` / `type` 这些是 cmd.exe 内建，没有同名 exe，CreateProcess 必然
# ENOENT —— 以前 `! echo hi` 只能拿到「Failed to spawn process echo」。
# 现在白名单 + 逐个 token 转义后交 `cmd.exe /d /c`；`!` 仍然是 argv-only：
# 元字符是字面参数，`%VAR%` 不展开。
if $*DISTRO.is-win {
    my $e = $s.eval-line('! echo hi');
    ok $e.ok, '! echo hi 走 cmd 内建回落并成功';
    like $e.out, /'hi'/, '! echo hi 拿到子进程输出';
    like $s.eval-line('! echo a & b').out, /'a & b'/,
        'cmd 内建参数里的 & 是字面量（不当命令分隔）';
    is $s.eval-line('! echo a>b').out.trim, 'a>b',
        '> 是字面参数（不重定向、不写文件）';
    like $s.eval-line('! echo %PATH%').out, /'%PATH%'/,
        '%VAR% 不展开（V-123 的 argv-only 不变）';
    # `! dir` 的回落只在「PATH 上没有真 dir.exe」时生效（真 exe 优先，ADR-0049 §2）。
    # 有的机器 PATH 里确实有 dir.exe（Git for Windows / MSYS 的 coreutils），
    # 那台机器上这条断言测的就不是回落本身：0.140.0 在一台这样的机器上红过。
    # 所以先问实现「这次会回落吗」，再断言对应的那一面；失败时把 code/err/out 带出来。
    my @argv = Rakuish::REPL::Shell::win-cmd-builtin-argv('dir', ('/b',));
    my $d = $s.eval-line('! dir /b');
    if @argv.elems {
        ok $d.ok, "! dir /b 成功（code={$d.code} err={$d.err.chomp}）";
        is $d.value<exe>.Str.lc, 'cmd.exe', '回落确实把 dir 交给 cmd.exe';
        like $d.out, /'a.txt'/,
            "! dir 能列当前目录（out={$d.out.substr(0, 300).chomp}）";
    }
    else {
        # PATH 上有同名真 exe：断言「不插手」这条设计本身 —— spawn 的就是 dir
        is $d.value<exe>.Str.lc, 'dir', 'PATH 上有 dir.exe 时不插 cmd 回落（真 exe 优先）';
        diag "PATH 上有 dir.exe —— 本机测不到 cmd 回落，这里改断「真 exe 优先」";
        is $d.value<argv>.List.elems, 2, "真 dir.exe 收到原样 argv(2 项：dir /b)";
    }
    nok $s.eval-line('! definitely-not-cmd-builtin').ok,
        '非白名单命令仍按原样失败（不扩张成任意 shell）';
}

# ── 中文编码别名（0.104.0 / V-293）：shell 层 --enc ───────────────────
{
    is out('cat --enc=gbk gbk.txt'), 'GBK 中文',
       'cat --enc=gbk 能读 GBK 文件';
    is out('read --enc gbk gbk.txt'), 'GBK 中文',
       'read --enc gbk（空格写法）也能读';
    like out('help cat'), /'--enc=编码'/, 'help cat 说明 --enc 选项';
}

# ── PATH 可执行表的磁盘缓存（0.142.0 / V-346）────────────────────────
# 背景：本机 system32 一个目录就 4667 个条目，全表扫一遍 ~1.2 s；以前 CLI 在
# 启动时 `start { path-executables() }` 预热，于是「刚启动就卡」。现在表落盘，
# 键 = 平台 + PATH + PATHEXT。这里只断行为，不断时间（CI 不测性能）。
{
    use JSON::Fast;
    my $cache  = $*TMPDIR.IO.add("rakuish-path-cache-{$*PID}.json");
    my $dir-a  = $*TMPDIR.IO.add("rakuish-pathdir-a-{$*PID}");
    my $dir-b  = $*TMPDIR.IO.add("rakuish-pathdir-b-{$*PID}");
    $cache.unlink if $cache.e;
    for ($dir-a, $dir-b) -> $d {
        $d.mkdir unless $d.e;
    }
    LEAVE { try { for ($dir-a, $dir-b) -> $d { $d.dir>>.unlink; $d.rmdir } } }
    my @files-a = ("{$dir-a}/foo.exe", "{$dir-a}/bar.cmd");
    my @files-b = ("{$dir-b}/baz.exe",);
    for (|@files-a, |@files-b) -> $f {
        my $p = $f.IO;
        $p.spurt('');
        try { $p.chmod(0o755) };   # POSIX 要可执行位；Windows 只看扩展名
    }

    my Str $old-path  = (%*ENV<PATH> // '').Str;
    my Bool $had-cache = (%*ENV<RAKUISH_PATH_CACHE>:exists);
    my Str $old-cache = (%*ENV<RAKUISH_PATH_CACHE> // '').Str;
    LEAVE {
        %*ENV<PATH> = $old-path;
        %*ENV<RAKUISH_PATH_CACHE> = $old-cache if $had-cache;
        %*ENV<RAKUISH_PATH_CACHE>:delete unless $had-cache;
        Rakuish::REPL::Shell::forget-path-cache();
        $cache.unlink if $cache.e;
    }

    %*ENV<PATH> = $dir-a.Str;
    %*ENV<RAKUISH_PATH_CACHE> = $cache.Str;
    Rakuish::REPL::Shell::forget-path-cache();

    my @cold = Rakuish::REPL::Shell::path-executables();
    my Str $want-a = $*DISTRO.is-win ?? 'foo' !! 'foo.exe';
    ok @cold.grep({ $_ eq $want-a }).elems > 0, "冷扫描列出 {$want-a}";
    ok $cache.e, '冷扫描把表写进磁盘缓存';

    # 命中：把缓存里的名字换成哨兵再忘掉进程内缓存 —— 若真的读了盘，
    # 返回的就是哨兵（而不是重新扫描出来的 foo）。
    my %c = try { from-json($cache.slurp) } // %();
    $cache.spurt(to-json %( |%c, names => ('z-cache-sentinel',) ));
    Rakuish::REPL::Shell::forget-path-cache();
    my @hit = Rakuish::REPL::Shell::path-executables();
    is @hit.elems, 1, '命中磁盘缓存（没有回去重新扫描）';
    is @hit[0], 'z-cache-sentinel', '返回的是缓存里的名字';

    # PATH 一变（键里的 PATH 变了）→ 缓存失效，重新扫描。
    %*ENV<PATH> = $dir-b.Str;
    Rakuish::REPL::Shell::forget-path-cache();
    my @changed = Rakuish::REPL::Shell::path-executables();
    my Str $want-b = $*DISTRO.is-win ?? 'baz' !! 'baz.exe';
    ok @changed.grep({ $_ eq $want-b }).elems > 0, 'PATH 变了就重新扫描（缓存按 PATH 失效）';
    nok @changed.grep({ $_ eq 'z-cache-sentinel' }).elems, '旧表的哨兵没有漏进来';

    # `RAKUISH_PATH_CACHE=off`：既不读也不写。
    %*ENV<PATH> = $dir-a.Str;
    %*ENV<RAKUISH_PATH_CACHE> = 'off';
    Rakuish::REPL::Shell::forget-path-cache();
    my @off = Rakuish::REPL::Shell::path-executables();
    ok @off.grep({ $_ eq $want-a }).elems > 0, 'off 时直接扫描（不读缓存）';

    $cache.unlink if $cache.e;
    %*ENV<RAKUISH_PATH_CACHE> = 'off';
    Rakuish::REPL::Shell::forget-path-cache();
    Rakuish::REPL::Shell::path-executables();
    nok $cache.e, 'off 时不写磁盘缓存';
}

done-testing;
