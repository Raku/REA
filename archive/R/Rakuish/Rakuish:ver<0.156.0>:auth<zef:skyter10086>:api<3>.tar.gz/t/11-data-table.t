use Test;
use JSON::Fast;
use Rakuish::Sys;
use Rakuish::Data;
use Rakuish::Data::Table;

# t/11 —— 结构化数据层：Table / JSON / CSV / ls-table

my $t = Rakuish::Data::Table.from-rows([
    { name => 'b.txt', type => 'file', size => 2 },
    { name => 'a.txt', type => 'file', size => 1 },
    { name => 'sub',   type => 'dir',  size => 0 },
]);

is $t.elems, 3, 'Table 行数';
is $t.columns.List, <name size type>, 'Table 列';
is $t.column-type('size'), 'int', '列类型推断为 int';
is $t.schema.columns.List, <name type nullable>, 'schema 列';
is $t.schema.where({ .<name> eq 'size' }).get('type').List, ('int',),
    'schema 报告 size 类型';
like $t.to-text, /'name'/ && /'a.txt'/, 'Table text 渲染';
like $t.to-markdown, /'| name | size | type |'/, 'Table markdown';
my $json = from-json($t.to-json);
is $json.elems, 3, 'Table JSON 行数';
is $json[1]<name>, 'a.txt', 'Table JSON 内容';

is $t.where({ .<type> eq 'file' }).elems, 2, 'where 过滤';
is $t.where({ .<size> > 1 }).get('name').List, ('b.txt',), 'where + get';
is $t.select('name').columns.List, ('name',), 'select 列';
is $t.sort-by('size').get('name').List, ('sub', 'a.txt', 'b.txt'),
    'sort-by size';
is $t.sort-by('size', :reverse).get('name').List, ('b.txt', 'a.txt', 'sub'),
    'sort-by reverse';
is $t.first(2).elems, 2, 'first';
is $t.last(1).get('name').List, ('sub',), 'last';

is $t.limit(2).elems, 2, 'limit';
is $t.offset(1).get('name').List, ('a.txt', 'sub'), 'offset';
is $t.each({ .<name> }).List, ('b.txt', 'a.txt', 'sub'), 'each';
is $t.count, 3, 'count';
is $t.sum('size'), 3, 'sum';
is $t.mean('size'), 1, 'mean';
is $t.min('size'), 0, 'min';
is $t.max('size'), 2, 'max';
is $t.distinct('type').elems, 2, 'distinct';

my $joined = $t.join(
    Rakuish::Data::Table.from-rows([{ name => 'a.txt', owner => 'alice' }]),
    :on<name>,
);
is $joined.elems, 3, 'left join 行数';
is $joined.where({ .<name> eq 'a.txt' }).get('owner').List, ('alice',),
    'left join 匹配';

# ── CSV ─────────────────────────────────────────────────────────────
my Str $csv = q:to/CSV/;
name,note
a,"x,y"
b,"he said ""hi"""
CSV
my $ct = Rakuish::Data::from-csv-data($csv);
is $ct.elems, 2, 'CSV 行数';
is $ct.get('note').List, ('x,y', 'he said "hi"'), 'CSV 引号/逗号';
my Str $round = Rakuish::Data::to-csv-data($ct);
is Rakuish::Data::from-csv-data($round).get('name').List, ('a', 'b'),
    'CSV 写回可再解析';
# 0.106.0 行级快速通道的边界：BOM / CRLF / 引号内换行 / 行尾空字段
is Rakuish::Data::from-csv-data("\x[FEFF]a,b\r\n1,\"x\ny\"\r\n").get('b').List,
    ("x\r\ny",), 'CSV：BOM + CRLF + 字段内换行（保留原状态机的 CRLF）';
is Rakuish::Data::from-csv-data("a,b,c\n1,2,\n").get('c').List, ('',),
    'CSV：行尾空字段保留';
is Rakuish::Data::from-csv-data("a,b\n\"x\"\"y\",\"p,q\"\n").get('b').List,
    ('p,q',), 'CSV：双写引号与字段内逗号';

# ── open-data / save-data ───────────────────────────────────────────
my $base = $*TMPDIR.IO.add("rakuish-data-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }
my $sys = Rakuish::Sys.new(:root($base), :cwd($base));

$sys.write('x.json', to-json([
    { name => 'a', size => 1 }, { name => 'b', size => 2 },
]));
my $jt = Rakuish::Data::open-data($sys, 'x.json');
isa-ok $jt, Rakuish::Data::Table, 'open .json 对象数组 → Table';
is $jt.elems, 2, 'open json 行数';

Rakuish::Data::save-data($sys, 'y.csv', $jt);
my $back = Rakuish::Data::open-data($sys, 'y.csv');
isa-ok $back, Rakuish::Data::Table, 'open .csv → Table';
is $back.get('name').List, ('a', 'b'), 'save/open csv roundtrip';

Rakuish::Data::save-data($sys, 'z.json', $jt);
is from-json($sys.read('z.json')).elems, 2, 'save json';

# ── ls-table ────────────────────────────────────────────────────────
$base.add('d').mkdir;
$base.add('d/f.txt').spurt('x');
$base.add('a.txt').spurt('a');
my $lt = $sys.ls-table('.', :recursive);
isa-ok $lt, Rakuish::Data::Table, 'ls-table 返回 Table';
ok $lt.columns.List.elems >= 4, 'ls-table 有结构化列';
ok $lt.get('name').List.grep(* eq 'f.txt').elems == 1, 'ls-table 递归含文件';
ok $lt.get('type').List.grep(* eq 'dir').elems >= 1, 'ls-table 识别目录';

# ── 契约收口：三个属性只读（0.134.0）────────────────────────────────
# 以前 `@.columns` / `@.rows` / `%.types` 都是 `is rw`：任何代码都能改其中
# 一个而不改另外两个，表就可能自相矛盾。现在内部私有，对外只给只读视图 ——
# 赋值要么抛、要么 no-op，**但绝不能改坏本体**（这才是断言的真对象）。
{
    my $ro = Rakuish::Data::Table.new(
        :columns(<a b>), :rows([{ a => 1, b => 'x' }]), :types({ a => 'int', b => 'str' }),
    );
    try { $ro.rows = [] };
    try { $ro.columns = [] };
    try { $ro.types = %() };
    is $ro.rows.elems, 1, '三次赋值之后行数没变';
    is $ro.columns.List, ('a', 'b'), '列没变';
    is $ro.types.raku, '{:a("int"), :b("str")}', 'types 没被清空（Hash.Hash 会返回本体，故用 .clone）';
    isa-ok $ro.rows, List, 'rows 返回 List（不是可变 Array）';
    isa-ok $ro.types, Hash, 'types 返回 Hash';
    # 只读视图是**副本**：改它不影响表本体。
    my $snap = $ro.types;
    $snap<a> = 'changed';
    is $ro.types<a>, 'int', '改返回的 Hash 不影响表（视图不是内部容器）';
}

# ── 0.137.0 / V-341：to-text 的 pandas 式可选行 + CSV bool/datetime 推断 ──
# to-text 的三个开关默认全关（老输出形态不能变），所以这里成对断言：
# 打开时出现、关闭时不出现。
{
    my @lines = $t.to-text(:index).lines;
    ok @lines[0].starts-with('#'), ':index 前置了行号列';
    like @lines[2], /^ '0  ' /, ':index 从 0 开始（表内序号，不是原始行号）';
    like $t.offset(1).to-text(:index).lines[2], /^ '0  ' /,
        ':index 在 offset 之后仍从 0 数（Table 没有可命名的 index）';
    like $t.to-text(:dtype), /'dtypes: name str, size int, type str'/, ':dtype 追一行 dtypes';
    like $t.to-text(:shape), /'(3 rows × 3 cols)'/, ':shape 追一行形状';
    nok $t.to-text.contains('dtypes:'), '默认不输出 dtypes 行';
    nok $t.to-text.contains('rows ×'), '默认不输出 shape 行';
    isnt $t.to-text(:index, :dtype, :shape), $t.to-text, '三个开关确实改变了输出';
    # 截断只说显示了多少行；shape 讲整表有多大 —— 两者不能互相污染。
    my @five-rows;
    for 1..5 -> $i { @five-rows.push({ a => $i, b => 'x' }) }
    my $five = Rakuish::Data::Table.from-rows(@five-rows);
    my Str $trunc = $five.to-text(:max-rows(2), :dtype, :shape);
    ok $trunc.contains('只显示前 2 行'), '截断提示仍在';
    ok $trunc.contains('(5 rows × 2 cols)'), 'shape 报整表行数而不是显示行数';
    ok !$trunc.lines[0].contains('dtypes'), 'dtypes 行不在表头';
}

{
    my $csv = Rakuish::Data::from-csv-data(
        "name,n,b,flag,when,mixed\na,1,2.5,true,2020-01-01 12:00:00,x\n"
        ~ "b,2,3.5,false,2021-06-30T23:59:59,7\n");
    is $csv.types<flag>, 'bool', 'CSV：只有 true/false 的列判 bool';
    is $csv.types<when>, 'datetime', 'CSV：ISO 时刻列判 datetime（空格与 T 都认）';
    is $csv.types<n>, 'int', 'CSV：int 推断没被新规则挤掉';
    is $csv.types<mixed>, 'str', 'CSV：混排列仍是 str';
    # 只推断类型、不改单元格原值（0.132.0 起的不变式，别被新分支带跑）。
    is $csv.get('flag').List, ('true', 'false'), 'bool 列的单元格仍是原字符串';
    is $csv.get('n').List, ('1', '2'), 'int 列的单元格仍是原字符串';
    # 反向：不该猜成 bool / datetime 的写法。
    is Rakuish::Data::from-csv-data("x\ntrue\n\nfalse\n").types<x>, 'bool',
        '空格子不参与判定';
    is Rakuish::Data::from-csv-data("x\n1\n0\n").types<x>, 'int',
        'CSV：1/0 是 int，不是 bool';
    is Rakuish::Data::from-csv-data("x\nyes\nyes\n").types<x>, 'str',
        'CSV：yes/no 不猜 bool';
    is Rakuish::Data::from-csv-data("d\n2020-13-45 99:99:99\n").types<d>, 'str',
        'CSV：正则能过但语义不成立的时刻退回 str';
    is Rakuish::Data::from-csv-data("d\n2020-01-01 12:00:00+08:00\n").types<d>, 'str',
        'CSV：带时区偏移的时刻不猜（有歧义）';
    is Rakuish::Data::from-csv-data("d\n2020-01-01\n").types<d>, 'str',
        'CSV：只有日期没有时刻不判 datetime';
}

done-testing;
