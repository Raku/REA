use v6.d;
use Test;
use lib 'lib';

use Rakuish::Sys::Proc;

# 0.119.0 / V-314：`!` 命令的 pid 回调。
#
# 前端靠这个 pid 把命令收进独立 Job Object，Ctrl-C 时只收命令子树，
# 引擎不重启（真控制台三场景见 tools/ctrl-c-win.py）。
# 回调本身是非 Windows 也能声明的接口；实际触发只在 Windows（V-314 只
# 处理 Windows 的前台进程组缺失问题）。

plan 3;

my $proc = Rakuish::Sys::Proc.new;
ok $proc.^can('set-child-cb'), 'Proc 提供子进程回调入口';

if !$*DISTRO.is-win {
    skip 'child 帧只在 Windows 触发（POSIX 用前台进程组）', 2;
}
else {
    my @pids;
    # 0.143.0 / V-347：回调统一收 List（单条命令 `($pid,)`，管道是整组）。
    $proc.set-child-cb(-> @group { @pids.append(@group) });
    my $h = $proc.spawn($*EXECUTABLE.Str, '-e', 'sleep 1');
    my $deadline = now + 5;
    while now < $deadline && !@pids.elems { sleep 0.05 }
    ok @pids.elems >= 1, 'spawn 后回调一次子进程 pid';
    ok (@pids[0] // 0) > 0, '回调拿到的是有效 pid';
    try { $proc.cancel($h) };
    try { $proc.wait($h) };
}
