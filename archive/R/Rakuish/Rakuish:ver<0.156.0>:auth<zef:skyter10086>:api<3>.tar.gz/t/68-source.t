use Test;
use lib 't/lib';
use Rakuish::REPL::Session;
use Rakuish::REPL::Shell;

# ══════════════════════════════════════════════════════════════════
# 68-source.t —— source：在会话里跑脚本文件（0.114.0 / V-306）
# ══════════════════════════════════════════════════════════════════
# 与 `rakuish 文件` 的分工：
#   · 那是一次性进程，跑完什么都没留下；
#   · `source` 在**当前会话**里跑 —— 脚本看得到会话的变量，脚本里的
#     sub / class / use / 顶层 my 也留在会话里。
#
# 断言分四组：
#   ① 参数与错误（用法、找不到、不是文件）；
#   ② 双向共享（会话 → 脚本、脚本 → 会话）；
#   ③ 记账边界（脚本内部的行不占 Out[n] / history）；
#   ④ 脚本语义（错误行号、继续执行、MAIN、exit、CRLF）。

my $dir = $*TMPDIR.IO.add("rakuish-src-{$*PID}");
$dir.mkdir;
for $dir.dir -> $f { $f.unlink if $f.f }
my $s = Rakuish::REPL::Session.new;

sub write-src(Str $name, Str $body --> IO::Path) {
    my $p = $dir.add($name);
    $p.spurt($body);
    $p;
}

# ── 1. 参数与错误 ───────────────────────────────────────────────────
my $u = $s.eval-line('source');
ok $u.ok, 'source 不带参数不报错（给用法）';
like $u.out, /'用法: source'/, '不带参数给出用法';
like $u.out, /'@*ARGS'/, '用法里说明参数去哪了';
is $s.index, 0, 'source 不占格号';

like $s.eval-line('source --help').out, /'用法: source'/, '--help 给用法';

my $missing = $s.eval-line('source ' ~ $dir.add('nope.raku').Str);
nok $missing.ok, '文件不存在时失败';
is $missing.code, 127, '不存在用 127（与 shell 的 not found 对齐）';
like $missing.err, /'找不到文件'/, '错误说清楚是找不到文件';

my $dirres = $s.eval-line('source ' ~ $dir.Str);
nok $dirres.ok, '目录不是脚本';
is $dirres.code, 126, '不是普通文件用 126';

# 0.111 起 Shell 的命令表是 help / Tab 的真值：登记了就必须有用法。
ok (Rakuish::REPL::Shell.usage('source')).chars > 0, 'Shell.usage 认识 source';
is $s.completions('sou', 3), ('source ',),
   '命令名补全认识 source';
ok $s.completions('source t/68', 11).grep(*.contains('68-source.t')).elems > 0,
   '`source ` 之后补的是文件路径';

# ── 2. 双向共享 ─────────────────────────────────────────────────────
my $basic = write-src('basic.raku', q:to/SRC/);
say "hello from file";
SRC
my $r1 = $s.eval-line('source ' ~ $basic.Str);
ok $r1.ok, '普通脚本执行成功';
is $r1.out, 'hello from file', '脚本的 say 进 out';
is $s.index, 0, '脚本内部的行不推进格号（Out[n] 还停在 0）';

# 脚本声明的变量留在会话里
my $vars = write-src('vars.raku', q:to/SRC/);
my $fromfile = 7;
my @fromlist = <a b>;
SRC
ok $s.eval-line('source ' ~ $vars.Str).ok, '带声明的脚本执行成功';
is $s.eval-line('$fromfile').value, 7, '脚本里的 my 变量留在会话里';
is $s.eval-line('@fromlist.elems').value, 2, '数组也一样';

# 脚本声明的 sub 留在会话里（这是 source 最主要的用途）
my $lib = write-src('lib.raku', q:to/SRC/);
sub double($n) { $n * 2 }
our sub triple($n) { $n * 3 }
my sub quad($n) { $n * 4 }
SRC
ok $s.eval-line('source ' ~ $lib.Str).ok, '带 sub 的脚本执行成功';
is $s.eval-line('double(21)').value, 42, '裸 sub 留在会话里';
is $s.eval-line('triple(3)').value, 9, '`our sub` 也留在会话里（0.114 修复点）';
is $s.eval-line('quad(2)').value, 8, '`my sub` 也留在会话里';

# 脚本里的 use 也要留下（与跨格 `use` 同一套机制）
my $uses = write-src('uses.raku', q:to/SRC/);
use TestNS::Box;
SRC
ok $s.eval-line('source ' ~ $uses.Str).ok, '脚本里的 use 执行成功';
is $s.eval-line('TestNS::Box.new.hi').value, 42,
   '脚本 use 的模块类型在会话里可用';

# 反方向：会话的变量脚本看得见
$s.eval-line('my $secret = 42');
my $peek = write-src('peek.raku', q:to/SRC/);
say "secret is $secret";
SRC
is $s.eval-line('source ' ~ $peek.Str).out, 'secret is 42',
   '脚本看得到会话的变量（同一个词法环境）';

# 参数：进 @*ARGS 与 $*PROGRAM-NAME，跑完不残留
my $args = write-src('args.raku', q:to/SRC/);
say "args=", @*ARGS.raku;
say "prog=", $*PROGRAM-NAME;
SRC
my $ar = $s.eval-line('source ' ~ $args.Str ~ ' a b');
ok $ar.ok, '带参数的 source 成功';
like $ar.out, /'args=["a", "b"]'/, '参数原样进 @*ARGS';
like $ar.out, /'prog=args.raku'/, '$*PROGRAM-NAME 是文件名';
is $s.eval-line('@*ARGS.elems').value, 0, '跑完后会话自己的 @*ARGS 没被改';

# 相对路径：相对**会话 cwd**，不是进程 cwd。
# （`cd` 的参数走 Shell 的 argv 解析，反斜杠会被当转义吃掉；测试里统一给 /。）
my Str $dir-slash = $dir.Str.subst(:g, "\\", '/');
$s.eval-line('cd ' ~ $dir-slash);
my $rel = $s.eval-line('source args.raku x');
ok $rel.ok, '相对会话 cwd 的路径可用';
like $rel.out, /'args=["x"]'/, '相对路径拿到的是同一个文件';
$s.eval-line('cd ' ~ $*CWD.Str);

# ── 3. 记账边界：Out[n] / history / perf ────────────────────────────
my $noise = write-src('noise.raku', q:to/SRC/);
say "one";
say "two";
say "three";
SRC
my Int $before-idx  = $s.index;
my Int $before-hist = $s.history.elems;
my $nr = $s.eval-line('source ' ~ $noise.Str);
is $nr.out, "one\ntwo\nthree", '多行输出按行拼起来';
is $s.index, $before-idx, '三行脚本没有顶高格号';
is $s.history.elems, $before-hist + 1, 'history 只多了 source 这一条';
is $s.history[*-1], 'source ' ~ $noise.Str, 'history 记的是命令行本身';
is $s.perf-hist.elems, 0,
   'perf 不记脚本内部的行（这里直接调 eval-line，本来就没人 note-timing）';

# ── 4. 脚本语义 ────────────────────────────────────────────────────
# 错误带 文件:行，且后续行继续执行（shell 的 source 语义，不是编译单元）
my $bad = write-src('bad.raku', q:to/SRC/);
my $ok1 = 1;
say $nope;
say "still here";
SRC
my $br = $s.eval-line('source ' ~ $bad.Str);
nok $br.ok, '有错误行时整体失败';
like $br.err, /'bad.raku:2'/, '错误带 文件名:行号';
like $br.out, /'still here'/, '出错那行之后的行仍然执行';
is $s.index, $before-idx, '失败的脚本也不推进格号';

# 未闭合结构：文件结束时如实报，不静默吞掉
my $open = write-src('open.raku', q:to/SRC/);
sub broken(
SRC
my $orr = $s.eval-line('source ' ~ $open.Str);
nok $orr.ok, '未闭合的脚本失败';
like $orr.err, /'未闭合结构'/, '错误说清楚是未闭合';

# MAIN：只有给了参数才调用（不给参数 = 只加载，别把库的执行跑起来）
my $main = write-src('main.raku', q:to/SRC/);
say "top-level";
sub MAIN(Str $who) { say "hello $who" }
SRC
my $m-noarg = $s.eval-line('source ' ~ $main.Str);
is $m-noarg.out, 'top-level', '没给参数时不调用 MAIN（只是加载）';
my $m-arg = $s.eval-line('source ' ~ $main.Str ~ ' 世界');
like $m-arg.out, /'top-level'/, '给参数时先跑顶层语句';
like $m-arg.out, /'hello 世界'/, '然后按位置参数调用 MAIN';

# MAIN 调不上时如实说清楚边界（命名参数不在这里解析）
my $main2 = write-src('main2.raku', q:to/SRC/);
sub MAIN(Str $who, Bool :$loud) { say "hi $who" }
SRC
my $m-bad = $s.eval-line('source ' ~ $main2.Str ~ ' bob --loud');
nok $m-bad.ok, 'MAIN 参数对不上时失败';
like $m-bad.err, /'调用 MAIN 失败'/, '错误标明是调用 MAIN 失败';
like $m-bad.err, /'位置参数'/, '提示只支持位置参数';

# exit：脚本里的 exit 就是退出会话（与 shell 的 source 一致），
# 但**之前**的输出要留下，且不能把引擎真的杀掉。
my $ex = write-src('exit.raku', q:to/SRC/);
say "before exit";
exit 3;
say "after exit";
SRC
my $er = $s.eval-line('source ' ~ $ex.Str);
is $er.out, 'before exit', 'exit 之前的输出保留';
ok $s.exit-requested, '脚本的 exit 变成会话退出请求';
is $s.exit-code, 3, '退出码原样带出';
$s.exit-requested = False;
$s.exit-code = 0;

# `exit;`（带分号）在 REPL 里也只请求退出 —— 漏掉分号那一路会把引擎杀掉
ok $s.eval-line('1+1').ok, 'exit 之后会话仍然可用（引擎没死）';
$s.eval-line('exit;');
ok $s.exit-requested, '`exit;` 也被认成退出请求';
$s.exit-requested = False;
$s.exit-code = 0;

# CRLF：`.lines` 只按 \n 切，留着 \r 会让最后一行变成 `}\r`
my $crlf = $dir.add('crlf.raku');
$crlf.spurt("say \"crlf\";\r\nmy \$cr = 5;\r\n");
my $cr = $s.eval-line('source ' ~ $crlf.Str);
ok $cr.ok, 'CRLF 文件能跑';
is $cr.out, 'crlf', 'CRLF 的 say 正常';
is $s.eval-line('$cr').value, 5, 'CRLF 里的声明也留下了';

# 空文件不报错
my $empty = write-src('empty.raku', '');
my $emp = $s.eval-line('source ' ~ $empty.Str);
ok $emp.ok, '空文件不报错';
is $emp.out, '', '空文件没有输出';

done-testing;
