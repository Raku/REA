use Test;
use Rakuish::Result;
use Rakuish::Kernel;
use Rakuish::REPL::Session;

# 0.76.0 / ADR-0013：Kernel 是前端与执行之间的唯一入口。
#
# 这一版的验收标准是**行为零变化**：TTY 前端改走 Kernel 之后，
# 每一格的 Result 必须与直接调 eval-line 逐字段相同。
# 所以本文件一半是「新能力」（策略拒绝、请求校验），
# 一半是「双路径对账」——后者才是 0.76 的真正门槛。

# ── 1. Request / Policy 的形状 ────────────────────────────────────
my $req = Request.new(:kind<source>, :payload('1'));
is $req.origin, 'human', 'Request 默认 origin=human';
is $req.kind, 'source', 'Request 保留 kind';
nok $req.policy.defined, '未传 policy 时为未定义（表示不收窄）';
is $req.describe.contains('kind=source'), True, 'Request.describe 含 kind';

# 0.112.0：origin 从注释约定变成真约束，拼错的字不能悄悄进账本。
for <human agent notebook script> -> $o {
    ok valid-origin($o), "$o 是合法 origin";
    lives-ok { Request.new(:kind<source>, :payload('1'), :origin($o)) },
        "Request 接受 origin=$o";
}
ok valid-origin('x-web-ui'), 'x- 前缀是自定义来源的 escape hatch';
nok valid-origin('x-'), 'x- 后面必须有名字';
nok valid-origin('numbook'), '拼错的 origin 不被接受';
throws-like { Request.new(:kind<source>, :payload('1'), :origin<numbook>) },
    X::Rakuish::Origin, message => /'非法 origin'/,
    '非法 origin 直接拒绝，并说清楚允许值';

my $local = Policy.new;
ok $local.allow-source, '默认策略允许源码';
nok $local.root.defined, '默认策略 root 不限制';
is $local.profile, 'local', '默认 profile=local';
is $local.describe.contains('profile=local'), True, 'Policy.describe 可读';

# 0.82.0 / ADR-0020：没有执行点的字段已拆掉，不再用「牌子」声明权限。
# 断言用 ^can（方法是否真的不存在），而不是「值为 False」——
# 后者会让字段被重新加回来时测试仍然通过。
nok $local.^can('allow-exec'), 'allow-exec 已拆（无执行点）';
nok $local.^can('read-only'),  'read-only 已拆（无执行点）';
nok $local.^can('allow-ops'),  'allow-ops 已拆（op 通道只剩 capabilities）';
nok $local.^can('limits'),     'limits 已拆（无读取者）';

# ── 2. source 通道：与 eval-line 逐字段对账 ───────────────────────
# 两边各自一个 Session（同一份代码、同一 cwd），避免 index/Out 互相干扰。
my $via-session = Rakuish::REPL::Session.new;
my $via-kernel  = Rakuish::REPL::Session.new;
my $kernel = Rakuish::Kernel.new(:session($via-kernel));

my @lines =
    '1 + 1',
    '"abc".uc',
    'my $q = 7',
    '$q * 2',
    'say "hi"',
    'pwd',
    'help',
    'perf',
    'NoSuchNameAbc()',
    '1 / 0';

my Int $bad = 0;
for @lines -> $line {
    my $a = $via-session.eval-line($line);
    my $b = $kernel.execute(Request.new(:kind<source>, :payload($line), :origin<human>));
    # 只比契约字段：elapsed 之类的计时不属于语义。
    my @diff;
    @diff.push('ok')  if $a.ok  != $b.ok;
    @diff.push('code') if $a.code != $b.code;
    @diff.push('op')   if $a.op   ne $b.op;
    @diff.push('out')  if $a.out  ne $b.out;
    @diff.push('err')  if $a.err  ne $b.err;
    # value 可能不可比较（Failure / 类型对象），用 raku 表示比。
    @diff.push('value') if $a.value.raku ne $b.value.raku;
    $bad++ if @diff;
    is @diff.elems, 0, "双路径一致：$line" ~ (@diff ?? "（差异: {@diff.join(',')}）" !! '');
}
is $bad, 0, '所有样本双路径零差异';

is $via-kernel.index, $via-session.index, '两侧 Out[n] 编号一致';

# ── 3. 策略：拒绝源码时不能悄悄执行 ───────────────────────────────
my $deny-session = Rakuish::REPL::Session.new;
my $deny-kernel = Rakuish::Kernel.new(
    :session($deny-session),
    :policy(Policy.new(:profile<agent>, :!allow-source)),
);
my $denied = $deny-kernel.execute(
    Request.new(:kind<source>, :payload('1 + 1'), :origin<agent>));
nok $denied.ok, '禁止源码的策略下请求失败';
is $denied.code, 403, '拒绝码 403';
is $denied.op, 'kernel', '拒绝结果的 op 是 kernel（不会被当成 eval 渲染）';
ok $denied.err.contains('不允许执行源码'), '错误信息说明原因';
is $deny-session.index, 0, '被拒绝的请求不推进 Out[n]';

# 前端只能收窄：请求自己写 allow-source 也放宽不了内核策略
# 拒绝只该记一条 trail（!deny 与 execute 末尾都记过 → 双记录，已修）
my Int $trail-before = $deny-kernel.trail.elems;
$deny-kernel.execute(Request.new(:kind<source>, :payload('0'), :origin<agent>));
is $deny-kernel.trail.elems - $trail-before, 1, '一次拒绝只记一条 trail';

my $sneaky = $deny-kernel.execute(Request.new(
    :kind<source>, :payload('2 + 2'), :origin<agent>,
    :policy(Policy.new(:allow-source))));
nok $sneaky.ok, '前端传 allow-source 不能放宽内核策略（V-183）';

# 反方向：内核允许、请求禁止 → 以更严为准
my $permissive = Rakuish::Kernel.new(:session(Rakuish::REPL::Session.new));
my $narrowed = $permissive.execute(Request.new(
    :kind<source>, :payload('3 + 3'),
    :policy(Policy.new(:!allow-source))));
nok $narrowed.ok, '请求可以自行收窄到不允许源码';

# profile 只影响标签，不影响判定
my $tagged = $permissive.execute(Request.new(
    :kind<source>, :payload('4'), :origin<agent>,
    :policy(Policy.new(:profile<analyst>))));
ok $tagged.ok, 'agent 传 profile 不改允许性';
is $permissive.trail.tail<profile>, 'analyst', 'trail 记录请求的 profile';

# ── 4. root 收紧与越界 ───────────────────────────────────────────
my $rooted = Rakuish::Kernel.new(
    :session(Rakuish::REPL::Session.new),
    :policy(Policy.new(:root($*TMPDIR))),
);
my $inner = $rooted.execute(Request.new(
    :kind<source>, :payload('5'), :policy(Policy.new(:root($*TMPDIR.add('sub'))))));
ok $inner.ok, '更窄的 root（在内核 root 内）被接受';

my $escape = $rooted.execute(Request.new(
    :kind<source>, :payload('6'), :policy(Policy.new(:root(IO::Path.new('/'))))));
nok $escape.ok, '越出内核 root 的请求被拒绝';
is $escape.code, 403, 'root 越界也是 403';

# ── 5. 请求校验：坏请求不能变成「执行了别的东西」 ─────────────────
my $op-req = $permissive.execute(Request.new(:kind<op>, :payload({ :op<read_file> })));
nok $op-req.ok, 'op 通道在 0.76 未接入';
is $op-req.code, 501, 'op 通道返回 501（明确未实现，不是空成功）';

my $unknown = $permissive.execute(Request.new(:kind<teleport>));
nok $unknown.ok, '未知 kind 失败';
is $unknown.code, 2, '未知 kind 是用法错误';

my $bad-payload = $permissive.execute(Request.new(:kind<source>, :payload(42)));
nok $bad-payload.ok, '非 Str 的 source payload 被拒绝';
is $bad-payload.code, 2, 'payload 类型错误是用法错误';
ok $bad-payload.err.contains('Str'), '错误信息指出类型要求';

# ── 6. trail：审计雏形（0.78 接进审计流）──────────────────────────
ok $permissive.trail.elems > 0, 'trail 有记录';
my %last = $permissive.trail.tail;
ok %last<seq> > 0, 'trail 带自增序号';
is %last<kind>, 'source', 'trail 记录 kind';
ok %last<origin>.defined, 'trail 记录 origin';

# ── 7. 前端不得直连 eval-line（V-182 的静态护栏）─────────────────
# 0.106.1：入口逻辑移到 Rakuish::CLI 模块，bin 只剩启动器。
my Str $front = $*CWD.add('lib/Rakuish/CLI.rakumod').slurp;
# 只禁「调用」，不禁注释里提这个名字 —— 注释正是要解释为什么不许调。
nok $front.contains('.eval-line('), 'TTY 前端不再直接调 eval-line';
ok $front.contains('kernel.execute'), 'TTY 前端经 kernel.execute';
ok $front.contains('make-request('), 'TTY 前端构造 Request';

# ── 8. 三个入口共用同一构造点（否则 policy 会各写一套）────────────
is $front.comb('make-kernel($sess').elems, 3, '三个入口都用 make-kernel';

done-testing;
