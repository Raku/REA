use Test;

# 0.111.0 / V-302：Jupyter wrapper kernel 的静态守护。
# 端到端需要 ipykernel + 装好的 kernelspec，那是 tools/jupyter/smoke.py 的事；
# 这里只锁「代码在仓库里、语法能编、关键口径没漂」，双平台都能跑。

my $root = $*CWD;
my @py =
    'tools/jupyter/rakuish_kernel/__init__.py',
    'tools/jupyter/rakuish_kernel/kernel.py',
    'tools/jupyter/rakuish_kernel/__main__.py',
    'tools/jupyter/install_kernel.py',
    'tools/jupyter/smoke.py';

for @py -> $p {
    ok $root.add($p).e, "$p 存在";
}

# 用 compile() 而不是 py_compile：不写 __pycache__ 到源码树。
sub py-syntax-ok(Str $path --> Bool) {
    my $p = run 'python3', '-c',
        'import sys; compile(open(sys.argv[1], encoding="utf-8").read(), sys.argv[1], "exec")',
        $root.add($path).Str, :out, :err;
    return False unless $p;
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    diag "python compile $path: $err" if $p.exitcode != 0;
    $p.exitcode == 0;
}

for @py -> $p {
    ok py-syntax-ok($p), "$p 语法可编译";
}

my $kernel = $root.add('tools/jupyter/rakuish_kernel/kernel.py').slurp;
my $install = $root.add('tools/jupyter/install_kernel.py').slurp;

# 关键口径：MIME 直接用桥给的，不在 Python 侧重写一套协商。
ok $kernel.contains('display.get("mime")'), 'wrapper 直接转发 display.mime';
nok $kernel.contains('def _mime('), '没有重写 MIME 协商（0.110 已给齐四档）';
ok $kernel.contains('json.loads(raw_json)'), 'application/json 解成对象再给 Jupyter';
ok $kernel.contains('reply.get("execution_count")'), '格号用会话口径，不让基类自己递增';
ok $kernel.contains('"cursor_start"'), 'complete 回 cursor_start';
ok $kernel.contains('omit_sections'), 'do_inspect 接受 ipykernel 7 的第五个参数';
ok $kernel.contains('supported_features'), '不虚报 debugger / subshells 能力';
ok $kernel.contains('do_shutdown'), 'shutdown 走协议而不是 kill';

# 0.113.0 / V-305：桥会主动推帧，wrapper 必须能区分「响应」与「推送」，
# 否则 busy 帧会被当成某条请求的回复（desync）。
ok $kernel.contains('if frame.get("event")'), '按 event 字段识别推送帧';
ok $kernel.contains('def _on_event'), '推送帧有单独的处理器';
ok $kernel.contains('if kind in ("busy", "idle")'), 'busy/idle 只记录不转播（基类已在发 status）';
ok $kernel.contains('frame.get("kind") != "dead"'), '只有空闲期死亡才转播（执行中的已写在 traceback 里）';
ok $kernel.contains('engine_pid'), 'ready 帧的引擎 pid 有落脚处（便于排障）';

# kernelspec 的边界如实写进配置。
ok $install.contains('"interrupt_mode": "message"'), '不假装支持无损中断';
ok $install.contains('RAKUISH_NOTEBOOK'), '桥命令可配置（源码树 / 安装版）';
ok $install.contains('"-m",'), '用 python -m 启动 wrapper';
ok $install.contains('rakuish_kernel'), 'wrapper 包随 kernelspec 一起装';

# 静态守护：入口脚本必须还在，wrapper 只搬消息不重新求值。
ok $root.add('bin/rakuish-notebook').e, 'Raku 侧 stdio 桥存在';
my $bridge = $root.add('lib/Rakuish/Kernel/Notebook.rakumod').slurp;
ok $bridge.contains("when 'execute'"), '桥仍走 Notebook 协议层';
ok $bridge.contains("event => 'busy'"), 'execute 前推 busy';
ok $bridge.contains("event => 'idle'"), 'execute 后推 idle';
ok $bridge.contains('Thread.start'), '空闲期死亡由看门狗线程发现（主循环阻塞在读 stdin）';
ok $bridge.contains('on-engine-event'), '引擎生死接到 Proxy 的事件回调';

done-testing;
