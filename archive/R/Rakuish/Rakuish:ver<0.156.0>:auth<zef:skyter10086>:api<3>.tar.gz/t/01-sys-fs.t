#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys;
use Rakuish::Sys::FS;

# 01-sys-fs.t —— API v3 文件 API 契约（ADR-0001 / Phase 1）
#
# 断言纪律（HANDOFF §7.18）：每条「不含 X」都要配一条「必须含 Y」，
# 每条异常路径都要用**当前**异常类型断言，不用文案匹配。

sub rmtree(IO::Path $d) {
    return unless $d.e || $d.l;
    unless $d.l {
        for (try { $d.dir } // ()) -> $c { rmtree($c) }
    }
    $d.d ?? (try $d.rmdir) !! (try $d.unlink);
}

my IO::Path $base = $*TMPDIR.IO.add("rakuish-v3-fs-{$*PID}");
$base.mkdir;
END { rmtree($base) if $base.e }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my Str $text = '中文 hello';

# ── write / read ──────────────────────────────────────────────────────
isa-ok $sys, Rakuish::Sys, 'Sys 构造成功';
my $w = $sys.write('a.txt', $text);
isa-ok $w, WriteResult, 'write 返回 WriteResult';
is $w.bytes, $text.encode('utf-8').elems, 'write 返回真实字节数（中文按 UTF-8）';
ok $w.atomic, 'write 首次写入走原子 rename';
is $sys.read('a.txt'), $text, 'read 中文 UTF-8 roundtrip';

my $blob = $sys.read('a.txt', :bin);
ok $blob ~~ Blob, 'read :bin 返回 Blob';
is $blob.elems, $text.encode('utf-8').elems, 'read :bin 字节数正确';
is $sys.read('a.txt', :offset(2), :limit(3)), $text.substr(2, 3),
   'read :offset/:limit 按字符切片';
is $sys.read('a.txt', :bin, :offset(3), :limit(3)).elems, 3,
   'read :bin :offset/:limit 按字节切片';
is $sys.read('a.txt', :offset(999)), '', 'read :offset 超出文本长度返回空串';
is $sys.read('a.txt', :bin, :offset(999)).elems, 0,
   'read :bin :offset 超出字节长度返回空 Blob';
throws-like { $sys.read('a.txt', :offset(-1)) }, X::Rakuish::Path,
    'read 负 offset 抛 X::Path';
throws-like { $sys.read('a.txt', :limit(-1)) }, X::Rakuish::Path,
    'read 负 limit 抛 X::Path';

my $w2 = $sys.write('a.txt', 'second');
is $sys.read('a.txt'), 'second', 'write 覆盖已有文件后内容正确';
isa-ok $w2.atomic, Bool, 'write 覆盖时 atomic 如实标注（平台可能降级）';

my $ap = $sys.append('a.txt', '!');
is $sys.read('a.txt'), 'second!', 'append 追加到尾部';
nok $ap.atomic, 'append 不宣称原子';
is $sys.append('a.txt', '?').bytes, 1, 'append 返回写入字节数';

my $w3 = $sys.write('sub/deep/deep.txt', 'deep', :mkdir);
is $sys.read('sub/deep/deep.txt'), 'deep', 'write :mkdir 自动建父目录';
ok $w3.path.e, 'WriteResult.path 指向真实文件';

my $w4 = $sys.write('a.txt', 'third', :backup);
ok $base.add('a.txt.bak').e, 'write :backup 生成备份文件';
is $base.add('a.txt.bak').slurp, 'second!?', '备份内容是覆盖前的值';
is $sys.read('a.txt'), 'third', '备份不干扰新内容';

my $tiny = Rakuish::Sys::FS.new(:max-bytes(4));
throws-like { $tiny.write($base.add('a.txt'), 'x', :backup) },
    X::Rakuish::Limit, ':backup 旧文件超过 max-bytes 时拒绝，不整文件读入';

# ── 异常路径 ──────────────────────────────────────────────────────────
throws-like { $sys.read('nope.txt') }, X::Rakuish::NotFound,
    'read 不存在抛 X::NotFound';
throws-like { $sys.read('a.txt', :max-bytes(2)) }, X::Rakuish::Limit,
    'read 超 max-bytes 抛 X::Limit';
my $small = Rakuish::Sys.new(:root($base), :cwd($base), :max-bytes(4));
throws-like { $small.write('a.txt', 'over four bytes') },
    X::Rakuish::Limit, '会话 max-bytes 限制写入';
throws-like { $small.read('a.txt') }, X::Rakuish::Limit,
    '会话 max-bytes 限制读取';

# ── ls / stat ─────────────────────────────────────────────────────────
$sys.write('.hidden', 'h');
my @top = $sys.ls('.');
ok @top.elems > 0, 'ls 返回非空列表（反向断言的配对）';
is @top.grep(* ~~ IO::Path).elems, @top.elems, 'ls 每项都是 IO::Path';
is @top.grep(*.basename eq 'a.txt').elems, 1, 'ls 必须含 a.txt';
is @top.grep(*.basename eq '.hidden').elems, 0, 'ls 默认不列隐藏项';
is $sys.ls('.', :all).grep(*.basename eq '.hidden').elems, 1,
   'ls :all 必须列出隐藏项';
is $sys.ls('.', :recursive).grep(*.basename eq 'deep.txt').elems, 1,
   'ls :recursive 含深层文件';
is $sys.ls('.', :recursive, :max-depth(1)).grep(*.basename eq 'deep.txt').elems, 0,
   'ls :max-depth(1) 不下钻';
my @one = $sys.ls('a.txt');
is @one.elems, 1, 'ls 文件目标返回单个路径（shell ls file 语义）';
is @one[0].basename, 'a.txt', 'ls 文件目标 basename 正确';

my $st = $sys.stat('a.txt');
isa-ok $st, Stat, 'stat 返回 Stat';
is $st.type, 'file', 'stat.type = file';
is $st.size, 'third'.encode.elems, 'stat.size 正确';
nok $st.is-symlink, 'stat.is-symlink 对普通文件为 False';
isa-ok $st.mode, Int, 'stat.mode 是 Int（Windows 可为 0）';
is $st.to-hash<path>, $st.path.Str, 'Stat.to-hash 含 path';
is $sys.stat('sub').type, 'dir', 'stat.type = dir';

# stat.executable（0.101.3）：Windows 上 IO::Path.x 对存在的文件也会抛
# 「rindex ... got null」，旧实现 `so(try { $f.x })` 静默成 False 让
# executable 恒假。现在 Windows 走扩展名白名单、POSIX 走 x 位。
nok $sys.stat('a.txt').executable, '普通文本不是可执行';
$base.add('fake.exe').spurt('x');
if $*DISTRO.is-win {
    ok $sys.stat('fake.exe').executable, 'Windows：.exe 判为可执行（白名单）';
} else {
    nok $sys.stat('fake.exe').executable, 'POSIX：无 x 位判为不可执行';
}

# ── 0.102.0：大文件上限与二进制读的报错出路 ──────────────────────────
{
    my Str $big = 'x' x (1024 * 1024 + 16);
    my $lim;
    try { $sys.write('big.txt', $big); CATCH { default { $lim = $_ } } }
    isa-ok $lim, X::Rakuish::Limit, '默认 1 MiB：写大字符串抛 Limit';

    my $ok = try { $sys.write('big.txt', $big, :max-bytes(4 * 1024 * 1024)) };
    ok $ok.defined, 'write 可用 :max-bytes 单次抬高（不必重建 Sys）';
    is $base.add('big.txt').s, 1024 * 1024 + 16, '单次抬高后确实写全';
    try { $base.add('big.txt').unlink };
}
{
    $base.add('bin.dat').spurt(Blob.new(0x7e, 0x7f, 0x80, 0x00));
    my $enc;
    try { $sys.read('bin.dat'); CATCH { default { $enc = $_ } } }
    isa-ok $enc, X::Rakuish::Encoding,
        '二进制当文本读抛 Rakuish::Encoding（不再是 X::AdHoc）';
    like $enc.message, /':bin'/, '错误消息给出「用 :bin」的出路';
    is $sys.read('bin.dat', :bin).elems, 4, ':bin 仍能读原始字节';
}

# ── mkdir / cp / mv / glob ────────────────────────────────────────────
ok $sys.mkdir('mvdir').ok, 'mkdir 返回 ok Result';
ok $base.add('mvdir').d, 'mkdir 真的建出了目录';
ok $sys.cp('a.txt', 'copy.txt').ok, 'cp 返回 ok';
is $sys.read('copy.txt'), $sys.read('a.txt'), 'cp 内容一致';
throws-like { $sys.cp('a.txt', 'copy.txt') }, X::Rakuish::Exists,
    'cp 目标已存在且不 overwrite 抛 X::Exists';
ok $sys.cp('a.txt', 'copy.txt', :overwrite).ok, 'cp :overwrite 成功';
ok $sys.cp('sub', 'sub-copy', :recursive).ok, 'cp :recursive 复制目录树';
ok $sys.read('sub-copy/deep/deep.txt') eq 'deep', '递归复制内容正确';
my $tiny-cp = Rakuish::Sys::FS.new(:max-entries(1));
throws-like { $tiny-cp.cp($base.add('sub'), $base.add('sub-copy2'), :recursive) },
    X::Rakuish::Limit, 'cp -r 条目上限预检';

# 0.134.0 / V-336：上限消息要给「路径 + 上限 + 出路」，别只报个字节数；
# 以及 cp 也接受单次 :max-bytes（以前只有 write / read 能抬）。
# 注意 `try` 会把异常收进 `$!`，块里的 CATCH 看不到 —— 所以要显式读 `$!`。
sub limit-msg(&code --> Str) {
    my Str $m = '';
    { try { code() }; $m = ($! ?? $!.message !! '') }
    $m;
}
{
    my $small2 = Rakuish::Sys.new(:root($base), :cwd($base), :max-bytes(4));
    my Str $cp-err = limit-msg({ $small2.cp('a.txt', 'cp-limit.txt') });
    ok $cp-err.chars, 'cp 超限时抛异常';
    like $cp-err, /'复制超限'/, '消息点明是复制超限';
    like $cp-err, /'a.txt'/, '消息带路径（以前只有字节数）';
    like $cp-err, /'> 4'/, '消息带上限值';
    like $cp-err, /'max-bytes'/, '消息给出路（:max-bytes(N) / Sys.new）';
    nok $base.add('cp-limit.txt').e, '超限时没有留下半个目标文件';
    # 单次抬高之后同一份文件能复制
    my $raised = try { $small2.cp('a.txt', 'cp-raised.txt', :max-bytes(1024)) };
    ok ($raised.defined && $raised.ok), 'cp 接受单次 :max-bytes 抬高';
}

# `cp -r` 的预检自己吃上限：数到上限外一个就停，不会先把整棵树数完。
{
    my $deep = $base.add('many');
    $deep.mkdir;
    for 1..9 -> $i { $deep.add("f{$i}").spurt('x') }
    my $cap3 = Rakuish::Sys.new(:root($base), :cwd($base), :max-entries(3));
    my Str $msg = limit-msg({ $cap3.cp('many', 'many-copy', :recursive) });
    like $msg, /'已数到 4 > 3'/, '预检数到上限外一个就抛（早停，不是全量递归）';
    nok $base.add('many-copy').e, '早停之后没有开始复制';
}

ok $sys.mv('copy.txt', 'moved.txt').ok, 'mv 返回 ok';
ok $base.add('moved.txt').e, 'mv 目标存在';
nok $base.add('copy.txt').e, 'mv 源已消失';

is $sys.glob('*.txt').grep(*.basename eq 'a.txt').elems, 1,
   'glob *.txt 命中根目录文件';
is $sys.glob('*.txt').grep(*.basename eq 'deep.txt').elems, 0,
   'glob * 不跨目录（深层文件不被 *.txt 命中）';
is $sys.glob('sub/deep/*.txt').grep(*.basename eq 'deep.txt').elems, 1,
   'glob 相对 root 的子目录模式命中';
is $sys.glob('sub?deep.txt').elems, 0,
   'glob ? 不跨目录分隔符';
ok $sys.glob('**/*.txt').grep(*.basename eq 'deep.txt').elems >= 1,
   'globstar **/ 匹配任意深度';
ok $sys.glob('sub/**/deep.txt').elems >= 1, 'glob foo/**/bar';
ok $sys.glob('**/*.{txt,md}').grep(*.basename eq 'deep.txt').elems >= 1,
   'brace 展开';
ok $sys.glob('sub/**/[d]eep.txt').grep(*.basename eq 'deep.txt').elems >= 1,
   '字符集匹配';

my $limited = Rakuish::Sys.new(:root($base), :cwd($base), :max-entries(2));
throws-like { $limited.ls('.', :recursive) }, X::Rakuish::Limit,
    '递归目录条目上限';
throws-like { $limited.rm('sub', :recursive) }, X::Rakuish::Limit,
    'rm -r 遍历时提前中止';

# ── rm：dry-run / 递归 / 护栏 ─────────────────────────────────────────
my $dry = $sys.rm('sub', :recursive, :dry-run);
ok $dry.ok, 'rm :dry-run 返回 ok';
ok $dry.value.elems > 1, 'rm :dry-run 给出删除计划';
ok $base.add('sub').d, 'rm :dry-run 一个字节都没删';
ok $base.add('sub/deep/deep.txt').e, 'rm :dry-run 深层文件仍在';

throws-like { $sys.rm('sub') }, X::Rakuish::Path,
    'rm 非递归删目录抛 X::Path';
throws-like { $sys.rm('missing.txt') }, X::Rakuish::NotFound,
    'rm 不存在且不 force 抛 X::NotFound';
ok $sys.rm('missing.txt', :force).ok, 'rm :force 对不存在返回 ok';
throws-like { $sys.rm('.') }, X::Rakuish::Bound,
    'rm 拒绝删除会话 root';

my $removed = $sys.rm('sub', :recursive);
ok $removed.ok, 'rm :recursive 成功';
is $removed.err, '', 'rm 没有静默吞掉删除错误（防假绿）';
nok $base.add('sub').e, 'rm :recursive 真的删掉了非空目录';
ok $base.add('a.txt').e, 'rm 只删目标，不误伤同级文件';

# ── 符号链接：只删链接，不跟随目标（能创建 symlink 的平台才测）────────
my $target = $base.add('link-target.txt');
$target.spurt('keep me');
my $link = $base.add('link.txt');
my Bool $can-link = so try { symlink($target.Str, $link.Str); True };
if $can-link {
    is $sys.stat('link.txt').type, 'symlink', 'stat 认出符号链接';
    ok $sys.rm('link.txt', :dry-run).ok, 'rm 链接 dry-run 可预览';
    ok $sys.rm('link.txt').ok, 'rm 链接成功';
    nok $link.e, '链接本身已删除';
    is $target.slurp, 'keep me', '链接目标内容未被删除（不跟随）';

    my $cp-src = $base.add('cp-src');
    mkdir $cp-src;
    $cp-src.add('real.txt').spurt('real');
    symlink($target.Str, $cp-src.add('child-link').Str);
    throws-like { $sys.cp($cp-src.Str, 'cp-dst', :recursive) },
        X::Rakuish::Unsupported, 'cp -r 遇到目录内 symlink 拒绝，不跟随到目标';

    # 中间目录 symlink 指向 root 外：读写都必须被 canonical 校验拦下
    my $outside = $*TMPDIR.IO.add("rakuish-outside-{$*PID}");
    $outside.mkdir;
    $outside.add('secret.txt').spurt('outside');
    symlink($outside.Str, $base.add('escape-dir').Str);
    throws-like { $sys.read('escape-dir/secret.txt') },
        X::Rakuish::Bound, '中间 symlink 读 root 外被拒';
    throws-like { $sys.write('escape-dir/written.txt', 'x') },
        X::Rakuish::Bound, '中间 symlink 写 root 外被拒';
    nok $outside.add('written.txt').e, 'root 外没有被写入';

    $base.add('bk.txt').spurt('old');
    symlink($target.Str, $base.add('bk.txt.bak').Str);
    throws-like { $sys.write('bk.txt', 'new', :backup) },
        X::Rakuish::Unsupported, '拒绝覆盖符号链接备份';
}
else {
    skip '本机无法创建符号链接（Windows 需开发者模式）', 8;
}

# ── root=/ 的根路径边界：不能把 '/' 判成 '//' ─────────────────────
if $*DISTRO.is-win {
    skip 'Windows 没有 /bin 这类 usrmerge 符号链接', 1;
}
else {
    my $root-sys = Rakuish::Sys.new(
        :root(IO::Path.new('/')), :cwd(IO::Path.new('/')));
    my $st = try { $root-sys.stat('/bin/ls') };
    ok $st.defined, 'root=/ 时含中间 symlink 的 /bin/ls 可通过';
}

# ── Result / FS 独立使用 ──────────────────────────────────────────────
my $r = Result.new(:ok, :out("a\nb"), :op<exec>);
ok $r.Bool, 'Result.Bool 跟随 .ok';
is $r.lines.elems, 2, 'Result.lines 按行切分';
is $r.to-hash<op>, 'exec', 'Result.to-hash 含 op';
nok Result.new(:!ok).Bool, 'Result.Bool 失败时为 False';

my $bare = Rakuish::Sys::FS.new;
is $bare.read($base.add('a.txt')), $sys.read('a.txt'),
   'Sys::FS 可脱离 Sys 独立使用（默认 resolver）';

# ── 中文编码别名（0.104.0 / V-293）─────────────────────────────────────
# Rakudo 内建 gb18030 向下兼容 GBK/GB2312，但不认 gbk/cp936 这些写法。
# 用 encode('gb18030') 造真 GBK 字节，验证别名映射与读回。
{
    my Str $src = '中文测试 汉字';
    my $gbk-bytes = $src.encode('gb18030');
    $base.add('gbk.txt').spurt($gbk-bytes);

    for <gbk cp936 windows-936 gb18030 gb2312> -> $enc {
        is $sys.read('gbk.txt', :enc($enc)), $src,
           ":enc<$enc> 能解码 GBK 字节（别名→gb18030）";
    }

    # 写 GBK 再读回：字节数与别名解码都对
    my $w = $sys.write('gbk-out.txt', $src, :enc<gbk>);
    is $w.bytes, $gbk-bytes.elems, 'write :enc<gbk> 写出真实 GBK 字节数';
    is $base.add('gbk-out.txt').slurp(:bin).list, $gbk-bytes.list,
       'write :enc<gbk> 落盘字节与 gb18030 编码一致';
    is $sys.read('gbk-out.txt', :enc<gbk>), $src, 'GBK 写→读往返正确';
    is $sys.read-lines('gbk.txt', :head(1), :enc<gbk>)[0], $src,
       'read-lines :enc<gbk> 按行解码正确';

    # 真不支持的编码抛 X::Encoding，且消息给出 gb18030 出路（V-290 原则）
    throws-like { $sys.read('gbk.txt', :enc<big5>) }, X::Rakuish::Encoding,
        'Rakudo 不支持的 big5 抛 X::Rakuish::Encoding';
}

# ── 文件锁 with-lock（0.105.0 / V-294）────────────────────────────────
{
    my Str $p = 'lockme.txt';
    is $sys.with-lock($p, { 42 }), 42, 'with-lock 透传回调返回值';
    ok $base.add("$p.lock").e, '创建独立 .lock 伴生文件（不锁数据文件本身）';

    # 锁内写数据（原子替换）+ 读回：锁文件 inode 不受 rename 影响
    $sys.with-lock($p, { $sys.write($p, 'in-lock') });
    is $sys.read($p), 'in-lock', '锁内 write 后可读回';

    # 异常路径：回调抛异常后锁照常释放（LEAVE），下一把仍拿得到
    throws-like { $sys.with-lock($p, { die 'boom' }) }, Exception,
        '回调异常原样抛出';
    is $sys.with-lock($p, { 'after-exception' }), 'after-exception',
        '异常后锁自动释放，下一把可拿';

    # 共享锁
    is $sys.with-lock($p, { 'shared' }, :shared), 'shared', ':shared 共享锁可用';

    # :non-blocking 无冲突路径（跨平台稳定）
    is $sys.with-lock('contend.txt', { 'free' }, :non-blocking), 'free',
        '无冲突时 :non-blocking 正常拿到锁';

    # non-blocking 冲突抛 X::Rakuish::LockConflict **只做手工验证**：
    # 同进程两句柄在 POSIX flock 下不冲突、Windows 冲突（平台差异），跨进程
    # 持锁又要靠子进程握手（stdout tap / 旗标轮询都试过，跨平台不稳）。
    # 真并发两进程抢锁已手工验证无丢失更新；单测只锁稳定的语义，不塞时序。
    ok X::Rakuish::LockConflict.^name.ends-with('X::Rakuish::LockConflict'),
        '锁冲突异常类存在（避免与 Raku 内建 Lock 撞名）';
}

done-testing;
