use Test;
use JSON::Fast;
use Rakuish::Result;
use Rakuish::Display;
use Rakuish::Data::Table;
use Rakuish::Kernel;
use Rakuish::REPL::Session;

# 0.78.0 / ADR-0016：DisplayBundle（V-184）、Agent display（V-186）、
# Kernel op 通道（V-186）。重点在**降级要如实**：拿不到 markdown 就给 text，
# 但 `format` 字段必须说明实际给的是哪一种，不能骗客户端。

my $dir = $*TMPDIR.IO.add("rakuish-display-{$*PID}");
$dir.mkdir;
$dir.add('a.txt').spurt("hello\n");
$dir.add('b.txt').spurt("world\n");
LEAVE {
    try { $dir.add('a.txt').unlink };
    try { $dir.add('b.txt').unlink };
    try { $dir.rmdir };
}

sub R(Bool :$ok = True, Int :$code = 0, :$value, Str :$out = '', Str :$err = '',
      Str :$op = 'eval' --> Rakuish::Result::Result) {
    Rakuish::Result::Result.new(:$ok, :$code, :$value, :$out, :$err, :$op);
}

my $table = Rakuish::Data::Table.from-rows(
    [{ name => 'a', n => 1 }, { name => 'b', n => 2 }]);

# ── 一、各类内容的 kind 与格式可用性 ─────────────────────────────────
my %cases = (
    table   => (R(:value($table)),                              'table'),
    records => (R(:value([{ a => 1 }, { a => 2 }])),            'records'),
    paths   => (R(:value(<x.txt y.txt>.map({ $_.IO }).List)),   'paths'),
    rows    => (R(:value(<x y>.List)),                          'rows'),
    record  => (R(:value({ K => 'v' })),                        'record'),
    scalar  => (R(:value(42)),                                  'scalar'),
    text    => (R(:out("line1\nline2\n")),                      'text'),
    error   => (R(:!ok, :code(1), :err('boom')),                'error'),
    empty   => (R(),                                            'empty'),
);

for %cases.keys.sort -> $k {
    my ($res, $want) = %cases{$k}.list;
    my $b = bundle-from($res);
    is $b.meta<kind>, $want, "$k 的 kind = $want";
    ok $b.text.defined, "$k 有 text";
    nok $b.text.contains("\e["), "$k 的 text 不含 ANSI";
    is $b.available[0], 'text', "$k 至少可用 text";
}

# 表格类：markdown + html + json 都可用；两列标题必须在 markdown 里出现。
my $tb = bundle-from(R(:value($table)));
ok $tb.has('markdown'), 'table 提供 markdown';
ok $tb.has('html'), 'table 提供 html（0.110.0）';
ok $tb.has('json'), 'table 提供 json';
ok $tb.html.contains('<th'), 'html 有表头单元格';
ok $tb.html.contains('</table>'), 'html 是完整 table';
nok $tb.html.contains('Out['), 'html 不带终端装饰';
ok $tb.markdown.contains('| n | name |'), 'markdown 有表头（列序按 Table 的规范序）';
is $tb.json.elems, 2, 'json 是行数组（不是 Result 外壳）';
nok $tb.json[0]<ok>:exists, 'json 不含 ok/code 这类外壳字段';

# 标量：只有 text + json，没有 markdown。
my $sc = bundle-from(R(:value(42)));
nok $sc.has('markdown'), '标量不提供 markdown';
ok $sc.has('json'), '标量提供 json';

# 错误：只有 text，且 text 就是错误信息。
my $er = bundle-from(R(:!ok, :code(3), :err('  boom  ')));
is $er.text, 'boom', '错误 text 去空白';
nok $er.has('markdown'), '错误不提供 markdown';
is $er.meta<code>, 3, '错误保留 code';

# ── 一·五、HTML 与 MIME 分档（0.110.0 / V-301）──────────────────────
# 错误也要能上网页：唯一要求是**转义**，不能让用户内容变成标签。
my $esc = bundle-from(R(:!ok, :code(1), :err('bad <x> & "q"')));
like $esc.html, /'&lt;x&gt;'/, '错误 HTML 转义尖括号';
like $esc.html, /'&amp;'/, '错误 HTML 转义 &';
like $esc.html, /'&quot;q&quot;'/, '错误 HTML 转义引号';
ok $esc.html.contains('<pre'), '错误用 pre 块';
nok $esc.has('markdown'), '错误仍不提供 markdown';

my $shtml = bundle-from(R(:value(42))).html;
ok $shtml.contains('<pre'), '标量用 pre 块';

my %mime = $tb.to-mime;
is %mime.keys.elems, 4, 'table 的 MIME 有 4 档';
ok %mime<text/plain>.defined, 'MIME 键是 text/plain（不是带引号的）';
ok %mime<text/html>.contains('<table'), 'MIME 里的 text/html 是真表格';
ok %mime<application/json>.starts-with('['), 'application/json 是 JSON 文本';
nok $tb.to-hash.keys.first({ $_ eq 'mime' }).defined, '默认 to-hash 不带 mime（TTY 不付体积）';
ok $tb.to-hash(:mime)<mime><text/html>, ':mime 时才附全部分档';

# ── 二、协商与降级 ───────────────────────────────────────────────────
is $tb.pick(['markdown', 'text']), 'markdown', '按客户端偏好顺序挑';
is $tb.pick(['html', 'markdown']), 'html', 'html 与 markdown 都在时按给定偏好';
is $tb.pick(['application/x-foo', 'json']), 'json', '不认识的格式跳过';
is $sc.pick(['markdown', 'text']), 'text', '标量降级到 text';
is $sc.render('markdown'), $sc.text, 'render 未知/缺失格式回退 text（不抛）';
is $tb.render('json').substr(0, 1), '[', 'render json 是 JSON 文本';
ok $tb.render('html').contains('<table'), 'render html 是真标签（不是 text）';
is $tb.render('application/x-foo'), $tb.text, '完全不认识的格式仍回退 text';

my %wire = $tb.to-hash(:format<markdown>);
is %wire<format>, 'markdown', 'wire 里 format 说明实际格式';
is %wire<content>, $tb.markdown, 'wire 的 content 就是选中那份';
ok %wire<formats>.elems == 4, 'wire 列出所有可用格式（text/markdown/html/json）';

my %wire2 = $sc.to-hash(:format<markdown>);
is %wire2<format>, 'text', '降级时 format 如实写 text';
is %wire2<content>, '42', '降级后仍是能显示的内容';

# ── 三、截断：max-rows 要能被看见 ────────────────────────────────────
# 注意 `{ n => $_ }` 在 map 块里是 Pair，不是 Hash —— 必须写 %( ... )，
# 否则 from-rows 只认出一行（这个坑在写测试时踩过一次）。
my $big = Rakuish::Data::Table.from-rows((1..50).map({ %(n => $_) }).List);
my $tb2 = bundle-from(R(:value($big)), :max-rows(3));
is $tb2.meta<rows>, 50, 'meta 报总行数';
ok $tb2.meta<truncated>, '超过 max-rows 时标 truncated';
nok bundle-from(R(:value($big)), :max-rows(100)).meta<truncated>:exists,
    '未超限时不标 truncated';

# ── 四、Kernel：present / bundle / op 通道 ───────────────────────────
my $kb = Rakuish::Kernel.new(:session(Rakuish::REPL::Session.new));
my $kres = $kb.execute(Request.new(
    :kind<source>, :payload('40 + 2'), :origin<human>));
my $kbd = $kb.bundle($kres);
is $kbd.meta<kind>, 'scalar', 'Kernel.bundle 走同一个构造器';
my %ph = $kb.present($kres, :format<markdown>);
is %ph<format>, 'text', '标量要 markdown 时降级并标注';
is %ph<content>, '42', 'present 内容正确';

my $cap = $kb.execute(Request.new(
    :kind<op>, :payload(%(op => 'capabilities'))));
ok $cap.ok, 'op 通道：capabilities 可用';
ok $cap.value<formats>.elems == 4, 'capabilities 报送格式（含 html）';
# 0.124.0 / ADR-0048：多了 `mime`（对象自带 to-mime 的档），9 → 10。
ok $cap.value<kinds>.elems == 10, 'capabilities 报送 kind';
ok $cap.value<ops>.first({ $_ eq 'capabilities' }).defined,
    'capabilities 在 ops 清单里';

my $unk = $kb.execute(Request.new(
    :kind<op>, :payload(%(op => 'rm'))) );
is $unk.code, 501, '其余 op 仍明确 501（不伪装空成功）';
nok $unk.ok, '501 是失败';

my $np = $kb.execute(Request.new(:kind<op>, :payload('ls')));
is $np.code, 2, 'op 的 payload 必须是 Hash';
my $nm = $kb.execute(Request.new(:kind<op>, :payload(%())));
is $nm.code, 2, 'op 缺少 payload<op> → 2';

# 0.82.0 / ADR-0020：allow-ops 已拆 —— op 通道只剩 capabilities，名字级白名单
# 没有可挡的对象。这里改断言「capabilities 自报的字段清单」与 Policy 一致，
# 防止文档与实现再次漂移（以前 policy-fields 列了四个没有执行点的字段）。
my %fields = $cap.value<policy-fields>.Set;
is %fields.elems, 3, 'policy-fields 只报 3 个字段';
ok %fields<allow-source>, 'policy-fields 含 allow-source';
ok %fields<root>, 'policy-fields 含 root';
ok %fields<profile>, 'policy-fields 含 profile';
nok %fields<allow-exec>, 'policy-fields 不再含 allow-exec';
nok %fields<limits>, 'policy-fields 不再含 limits';

# ── 五、Agent display 已随 Agent 线删除（0.81.0 / ADR-0019）──────────
# Display::Bundle 本身是本机能力：Session 渲染、`-e`、脚本都在用，
# 上面的 §一–§四 覆盖它的全部契约；Agent 的 `display` 字段与
# `capabilities` op 随结构化 op 协议一并撤销。

done-testing;
