use v6.d;
use Test;
use lib 'lib';

# 0.148.0 / V-352 / ADR-0062：Session 拆分第三步的**结构守卫**。
#
# 与 t/84（配置层）、t/85（诊断层）同一套路：不测行为（行为由 t/42 快照、
# t/81 store、t/18 旧快照、t/45 启动覆盖），只钉住「快照 / store 真的搬进
# Persistence role、Session 没有又长回去」。
# 0.147.0 的 Session 是 3,630 行；这一刀再切掉约 380 行后是 3,250 行 ——
# 上限 3,300 允许正常增长，但不允许把快照 / store 写回 Session。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my IO::Path $pers = $root.add('Session/Persistence.rakumod');

ok $sess.e, 'Session.rakumod 在';
ok $pers.e, '持久化层文件在（Session/Persistence.rakumod）';

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str $pers-text = $pers.slurp.subst("\x[FEFF]", '');

# ── 声明的形状：role + does + use ────────────────────────────────────
my Str $pers-head = $pers-text.lines.first({ .trim && !.trim.starts-with('#') }).trim;
is $pers-head, 'unit role Rakuish::REPL::Session::Persistence;',
     '持久化层是 unit role Rakuish::REPL::Session::Persistence';

like $sess-text, /'does Rakuish::REPL::Session::Commands'/,
     'Session 仍声明 does ...Commands（第一步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Diagnostics'/,
     'Session 仍声明 does ...Diagnostics（第二步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Persistence'/,
     'Session 声明了 does ...Persistence';
like $sess-text, /'use Rakuish::REPL::Session::Persistence;'/,
     'Session 在 unit 之前 use 了 Persistence（否则 does 解析不到）';

# ── 反方向：快照 / store 不许留在 Session ────────────────────────────
for <!init-snapshot save-snapshot restore-snapshot !cmd-store
     !store-candidates !store-decl-src> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    nok $sess-text.contains($sig), "$m 不在 Session（否则就是又长回去了）";
    ok $pers-text.contains($sig), "$m 在持久化层";
}

# `restored` 是公开读取方法，也随快照一起搬走
nok $sess-text.contains('method restored('), 'restored 不在 Session';
ok $pers-text.contains('method restored('), 'restored 在持久化层';

# ── 必须留在 Session 的两件东西 ─────────────────────────────────────
# ① !state-alias：求值状态别名，被 !eval-raku 调用，不是快照功能。
ok $sess-text.contains('method !state-alias('), '!state-alias 留在 Session';
nok $pers-text.contains('method !state-alias('), '!state-alias 不在持久化层（不是快照的活）';

# ② !eval-in-session：EVAL 的词法包决定用户 `my class Foo` 的命名空间；
#    在 role 里 EVAL 会得到 `…::Persistence::Foo`，快照 `.raku` 前缀剥不干净。
ok $sess-text.contains('method !eval-in-session('), '!eval-in-session 留在 Session（EVAL 词法包）';
nok $pers-text.contains('method !eval-in-session('), '!eval-in-session 不在持久化层';
ok $pers-text.contains('self!eval-in-session('), '持久化层经 !eval-in-session 做恢复 EVAL';

# ── 状态公开：role 只能走访问器 ─────────────────────────────────────
ok $sess-text.contains('has      %.restored-info;'), '恢复摘要是公开属性 %.restored-info（与 restored 方法不撞名）';
ok $sess-text.contains('has      @.restore-failed;'), '恢复失败名单是公开属性 @.restore-failed';
nok $sess-text.contains('%!restored'), 'Session 里没有 %!restored（私有引用已清）';
nok $sess-text.contains('@!restore-failed'), 'Session 里没有 @!restore-failed';
nok $pers-text ~~ /<[$@%]>\!<[A..Za..z]>/, '持久化层没有任何类私有属性引用';

# ── 规模上限：拆分后不该再长回去 ─────────────────────────────────────
# 拆分前 3,630 行（0.147.0 实测）；切掉 380 行后 3,250 行。
my Int $sess-lines = $sess-text.lines.elems;
cmp-ok $sess-lines, '<', 3300,
       "Session 行数 {$sess-lines} 低于 3,300（不再把持久化层长回来）";

# ── META6 provides：新增文件必须登记（t/51 也会查，这里显式钉住）─────
my Str $meta = 'META6.json'.IO.slurp;
ok $meta.contains('"Rakuish::REPL::Session::Persistence": "lib/Rakuish/REPL/Session/Persistence.rakumod"'),
     'META6 provides 登记了 Persistence';

# ── 运行时：role 组合后真的能用，不是只搬了文本 ─────────────────────
use Rakuish::REPL::Session;
my IO::Path $store = $*TMPDIR.add("rakuish-t86-store-{$*PID}.json");
my $s = Rakuish::REPL::Session.new(:snapshot-on(False), :store-path($store.Str));

ok $s.^can('save-snapshot'), 'Session 实例上有 save-snapshot（role 组合生效）';
ok $s.^can('restore-snapshot'), 'Session 实例上有 restore-snapshot';
ok $s.^can('restored'), 'Session 实例上有 restored';
is $s.restored.elems, 0, '还没恢复过时 restored 是空 Hash（role 读 %.restored-info）';
like $s.snapshot-path, /'session-'/, 'TWEAK 里的 !init-snapshot 真的跑了（路径已算好）';

is $s.eval-line('store -l').out, "库是空的（{$store.Str}）", 'store -l 可用（走 role）';
ok $s.eval-line('store --help').out.contains('用法: store'), 'store --help 给用法';
ok $s.eval-line('store -d').err.contains('要删哪些变量'), 'store -d 无名字时报错（role 实现）';

done-testing;
