use lib 'lib';
use Test;
use Rakuish::Kernel;
use Rakuish::REPL::Session;
use Rakuish::Result;

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';

# ════════════════════════════════════════════════════════════════════
# t/72 — 脚本模式的 MAIN 分派（0.118.0 / V-311）
#
# `rakuish 文件 参数` 以前只跑顶层语句，`sub MAIN` 永远不被调用（0.114 起
# 至少给一行提示）。现在把 EVAL 里的 `&MAIN` 交给 Rakudo 自己的 RUN-MAIN：
# 参数解析 / 类型强转 / multi 分派 / USAGE / 退出码都与 `raku 文件` 一致。
#
# 这里全部走真实子进程（不 mock），因为分派依赖 `@*ARGS`、`$*PROGRAM-NAME`
# 与进程退出码；另有几条进程内断言盯 Kernel 的 `script` 通道。
# ════════════════════════════════════════════════════════════════════

# 测试从哪个目录跑都能用：先向上找 META6.json，找不到再退回 `$?FILE`。
# （Win32 上 `$?FILE` 偶发丢盘符，所以前者优先；t/07 有同样的取舍。）
sub repo-root(--> IO::Path) {
    my IO::Path $d = $*CWD.IO.absolute.IO;
    loop {
        return $d if $d.add('META6.json').e;
        my IO::Path $up = $d.parent;
        return $?FILE.IO.parent.parent.absolute.IO if $up.absolute.Str eq $d.absolute.Str;
        $d = $up;
    }
}

my $root = repo-root();
my $BIN = $root.add('bin/rakuish');
ok $BIN.e, '入口 bin/rakuish 存在';

my $tmp = $*TMPDIR.IO.add("rk-main-{$*PID}");
$tmp.mkdir;
END {
    if $tmp.d {
        for $tmp.dir -> $f { try { $f.d ?? $f.rmdir !! $f.unlink } }
        try $tmp.rmdir;
    }
}

my $seq = 0;
sub tmp-file(Str $name, Str $body --> IO::Path) {
    my $f = $tmp.add($name);
    $f.spurt($body);
    $f
}

sub invoke(IO::Path $script, *@args --> Hash) {
    # cwd 固定在仓库根：Rakudo 2026.11 的 USAGE 生成器在「cwd 恰好是脚本所在
    # 目录」时会炸（`rindex ... got null`，plain `raku` 同样复现），固定 cwd
    # 让这组断言与运行位置无关。
    my $p = run($*EXECUTABLE.Str, $BIN.Str,
                $script.Str, |@args, :out, :err, :cwd($root.Str));
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    { out => $out, err => $err, rc => $p.exitcode }
}

# ── 1. 顶层语句 + MAIN：都与真 `raku 文件` 一致 ─────────────────────
my $basic = tmp-file('basic.raku', q:to/SRC/);
my $base = 10;
sub MAIN(Int $x, Str :$name = "d") {
    say "MAIN x={$x + $base} name=$name";
    say "args=", @*ARGS.join(',');
    say "prog=", $*PROGRAM-NAME.IO.basename;
}
say "TOP";
SRC

my %r1 = invoke($basic, '42');
ok %r1<rc> == 0, '有 MAIN 的脚本正常退出';
ok %r1<out>.contains('TOP'), '顶层语句照常执行（不是「有 MAIN 就整份跳过」）';
ok %r1<out>.contains('MAIN x=52'), 'MAIN 被调用且能读到顶层词法（$base=10）';
ok %r1<out>.contains('MAIN x=52 name=d'), '缺省命名参数取默认值';
ok %r1<out>.contains('args=42'), 'MAIN 里 @*ARGS 是原始字符串（未强转）';
ok %r1<out>.contains('prog=basic.raku'), '$*PROGRAM-NAME 指向脚本本身';
ok %r1<out>.index('TOP') < %r1<out>.index('MAIN x='),
    '执行顺序：顶层在前、MAIN 在后（与 raku 一致）';

my %r2 = invoke($basic, '--name=hi', '42');
ok %r2<rc> == 0, '命名参数 + 位置参数可以一起给';
ok %r2<out>.contains('name=hi'), '命名参数绑定到 :$name';
ok %r2<out>.contains('x=52'), '位置参数仍按签名强转成 Int';

# 0.118.0 记录的口径：Rakudo 默认「命名参数必须在位置参数之前」
# （`%*SUB-MAIN-OPTS` 在 EVAL 里可以 my 声明成 named-anywhere，但默认不是）。
# `42 --name=hi` 里的 --name 会被当成第二个位置参数 → 参数不匹配 → USAGE。
my %r3 = invoke($basic, '42', '--name=hi');
ok %r3<rc> == 2, '命名参数放在位置参数之后不算命名（Rakudo 默认口径）';
ok %r3<err>.contains('Usage:'), '参数不匹配时打印 USAGE 到 stderr';
ok %r3<err>.contains('basic.raku'), 'USAGE 里带脚本名';

# ── 2. 多候选 / 标志位 / 无参数 ────────────────────────────────────
my $multi = tmp-file('multi.raku', q:to/SRC/);
multi MAIN('add', Int $n) { say "ADD $n" }
multi MAIN('del', Int $n) { say "DEL $n" }
SRC
my %m1 = invoke($multi, 'add', '3');
is %m1<out>.trim, 'ADD 3', 'multi MAIN 按字面量候选分派（add）';
my %m2 = invoke($multi, 'del', '3');
is %m2<out>.trim, 'DEL 3', 'multi MAIN 按字面量候选分派（del）';
my %m3 = invoke($multi, 'nope', '3');
is %m3<rc>, 2, '没有候选匹配时退出码 2';
ok %m3<err>.contains('add') && %m3<err>.contains('del'),
    '没有候选匹配时 USAGE 列出全部候选';

my $flag = tmp-file('flag.raku', q:to/SRC/);
sub MAIN(Bool :$verbose) { say $verbose ?? "verbose-on" !! "verbose-off" }
SRC
is invoke($flag, '--verbose')<out>.trim, 'verbose-on', 'Bool 标志位绑定为 True';
is invoke($flag)<out>.trim, 'verbose-off', 'Bool 标志位缺省为 False';

my $noarg = tmp-file('noarg.raku', q:to/SRC/);
sub MAIN() { say "RAN" }
SRC
is invoke($noarg)<out>.trim, 'RAN', 'sub MAIN() 无参数时直接执行';

# ── 3. 缺参数 / --help / 自定义 USAGE ───────────────────────────────
my $req = tmp-file('req.raku', q:to/SRC/);
sub MAIN(Int $x) { say "x=$x" }
SRC
my %req = invoke($req);
is %req<rc>, 2, '缺少必需位置参数时退出码 2';
ok %req<err>.contains('Usage:'), '缺少参数时给出 USAGE';
ok %req<err>.contains('req.raku'), 'USAGE 用脚本名（不是 rakuish 自己）';

my %help = invoke($req, '--help');
is %help<rc>, 0, '--help 退出码 0';
ok %help<out>.contains('Usage:'), '--help 打印 USAGE';

my $usage = tmp-file('usage.raku', q:to/SRC/);
sub USAGE { say "CUSTOM-USAGE" }
sub MAIN(Int $x) { say "x=$x" }
SRC
my %u1 = invoke($usage, 'nope');
is %u1<rc>, 2, '自定义 sub USAGE 时失败退出码仍是 2';
ok %u1<out>.contains('CUSTOM-USAGE'), '脚本里的 sub USAGE 被 RUN-MAIN 采用';

# ── 4. 脚本里 exit：退出码要传播，已经打印的内容不能丢 ─────────────
my $ex = tmp-file('exit.raku', q:to/SRC/);
sub MAIN(Str $who) {
    say "before-exit:$who";
    exit 3;
}
SRC
my %ex = invoke($ex, 'bob');
is %ex<rc>, 3, 'MAIN 里的 exit 3 变成进程退出码 3';
ok %ex<out>.contains('before-exit:bob'),
    'exit 之前已经 say 的内容保留（脚本输出不经过 Out 捕获缓冲）';

# ── 5. 没有 MAIN：行为与 0.117 完全一致 ────────────────────────────
my $plain = tmp-file('plain.raku', q:to/SRC/);
say "plain-top";
SRC
my %pl = invoke($plain);
is %pl<rc>, 0, '没有 MAIN 的脚本照常跑顶层语句';
is %pl<out>.trim, 'plain-top', '没有 MAIN 时不打印任何分派提示';

my $incomplete = tmp-file('incomplete.raku', "my \@a = (\n");
my %inc = invoke($incomplete);
is %inc<rc>, 2, '未闭合结构仍然拒绝执行（不被 MAIN 尾巴凑完整）';
ok %inc<err>.contains('未闭合结构'), '未闭合结构有明确提示';

# ── 6. DSL 在 MAIN 里仍然可用（脚本与 REPL 共用词法环境）───────────
my $dsl = tmp-file('dsl.raku', q:to/SRC/);
sub MAIN(Str $who) { say echo("hi", $who) }
SRC
is invoke($dsl, 'bob')<out>.trim, 'hi bob', 'MAIN 里能调用 DSL 短命令 echo';

# ── 7. 进程内：Kernel 的 script 通道 ───────────────────────────────
my $sess = Rakuish::REPL::Session.new;
my $kernel = Kernel.new(:session($sess));
ok $kernel.capabilities<request-kinds>.grep(* eq 'script').elems,
    'capabilities 的 request-kinds 里声明了 script';

my $deny-sess = Rakuish::REPL::Session.new;
my $deny = Kernel.new(
    :session($deny-sess),
    :policy(Policy.new(:profile<agent>, :!allow-source)),
);
my $denied = $deny.execute(
    Request.new(:kind<script>, :payload('1 + 1'), :origin<script>));
nok $denied.ok, '禁止源码的策略下 script 请求失败';
is $denied.code, 403, 'script 与 source 用同一条 403 拒绝口径';
is $deny-sess.index, 0, '被拒绝的 script 请求不推进格号';

# 未闭合结构走 eval-script 的独立判据（不经过 eval-line）
my $more = $sess.eval-script("for 1..3 \{\n");
is $more.op, 'more', 'eval-script 对未闭合结构返回 op=more';
my $plain-eval = $sess.eval-script('1 + 1');
ok $plain-eval.ok, '没有 MAIN 的源码在 eval-script 下也能求值';
is $plain-eval.op, 'eval', '普通求值的 op 仍是 eval';

done-testing;
