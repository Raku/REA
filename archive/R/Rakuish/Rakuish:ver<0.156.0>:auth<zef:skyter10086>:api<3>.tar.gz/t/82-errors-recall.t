use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::REPL::Session;

# t/82 — errors 分级 + recall 预填（0.140.0 / V-344 / ADR-0054，评审 P2.2 + P2.7）
#
# 三层要守：① 错误头一行必须说清是哪一层（编译 / 运行 / 被拒绝），且默认
# short 不刷屏；② 位置口径是「第 N 格第 M 行」—— 格内错误没有真文件名，
# 不许把 EVAL_3 或驱动自己的行号报给用户；③ recall 只回显 + 预填，不执行，
# 且预填只能被读一次、只活到下一格。

# ── ① errors 分级命令本身
my $s = Rakuish::REPL::Session.new;
is $s.error-mode, 'short', '默认分级是 short';

my $r0 = $s.eval-line('errors');
ok $r0.ok, 'errors 无参：成功';
like $r0.out, /'错误显示: short'/, '无参时说明当前是 short';
is $s.index, 0, 'errors 命令不占 Out[n]';
is $s.history.List.tail, 'errors', 'history 记一条命令行';

my $r1 = $s.eval-line('errors full');
ok $r1.ok, 'errors full：成功';
is $r1.out, '错误显示: full', '切到 full 有回执';
is $s.error-mode, 'full', '模式真的切过去了';

my $r2 = $s.eval-line('errors');
like $r2.out, /'错误显示: full'/, '无参回显 full';
like $r2.out, /'完整回放'/, 'full 的描述是完整回放';

my $bad = $s.eval-line('errors nonsense');
nok $bad.ok, '非法参数：不是成功';
is $bad.code, 2, '非法参数：code=2';
like $bad.err, /'用法: errors'/, '非法参数：给出用法';
is $s.error-mode, 'full', '非法参数不改模式';

my $help = $s.eval-line('errors --help');
ok $help.ok, 'errors --help：成功';
like $help.out, /'用法: errors [short|full]'/, '--help 给出用法签名';
like $help.out, /'编译错误'/, '用法里说明三种类型';
like $help.out, /'被拒绝'/, '用法里提到被拒绝';
is $s.error-mode, 'full', '--help 不改模式';

is $s.eval-line('errors SHORT').out, '错误显示: short', '参数大小写不敏感';

# ── ② 运行错误：类型前缀 + 格内行号
my $s2 = Rakuish::REPL::Session.new;
my $rt = $s2.eval-line('die "boom"');
nok $rt.ok, 'die 是失败格';
like $rt.err, /^ '运行错误: boom'/, '运行错误带类型前缀';
is $s2.last-error-kind, '运行错误', 'last-error-kind 记为运行错误';
is $s2.last-error-loc, '第 1 格第 1 行', 'die 在第 1 格第 1 行';
like $rt.err, /'（第 1 格第 1 行）'/, '错误行尾带位置';
is $rt.err.lines.elems, 1, 'short 模式只有一行（不刷 backtrace）';

# 两行格：位置必须报第 2 行，而不是永远 1。
my $two = $s2.eval-line("my \$q = 1;\ndie \"two\"");
nok $two.ok, '两行格的第二行失败';
like $two.err, /'第 2 格第 2 行'/, '两行格报第 2 行';
is $s2.last-error-loc, '第 2 格第 2 行', 'last-error-loc 与错误文本一致';

# 运行错误里常见的一类：库方法吐出的 Raku 异常（不是 Rakuish 自己的）。
# 语法：先在会话里造一个「看起来对、跑起来不对」的表达式。
my $div = $s2.eval-line('say 1/0');
nok $div.ok, '除零是失败格';
like $div.err, /^ '运行错误: ' /, '除零归运行错误';
like $div.err, /'第 3 格第 1 行'/, '除零的位置在第 3 格';

# ── ③ 编译错误：不给行号（Rakudo 的消息里自己带「at line N」），只给格
my $s3 = Rakuish::REPL::Session.new;
my $ce = $s3.eval-line('say foo');
nok $ce.ok, '未声明 routine 是失败格';
like $ce.err, /^ '编译错误: ' /, '未声明 routine 归编译错误';
is $s3.last-error-kind, '编译错误', 'last-error-kind 记为编译错误';
like $ce.err, /'（第 1 格）'/, '编译错误只报格号';
nok $ce.err.contains('第 1 格第'), '编译错误不硬造行号';

# 语法残缺（`my $y = 1 +`）会被 REPL 当成续行（op=more），不是错误格，
# 所以这里用「完整但非法」的单行：两个 term 并排。
my $syntax = $s3.eval-line('say 1 2');
nok $syntax.ok, '两个 term 并排是失败格';
like $syntax.err, /^ '编译错误: ' /, '两个 term 并排归编译错误';
like $syntax.err, /'（第 2 格）'/, '两 term 并排报第 2 格';

my $more = $s3.eval-line('my $y = 1 +');
is $more.op, 'more', '语法残缺走续行，不算错误格';
$s3.eval-line('2');

my $dep = $s3.eval-line('use DefinitelyNotAModule');
nok $dep.ok, '缺模块是失败格';
like $dep.err, /^ '编译错误: ' /, '缺模块归编译错误（复合类型 X::Comp 命中）';

# ── ④ 被拒绝：Rakuish 自己判定的失败（X::Rakuish::*），改代码没用
my $s4 = Rakuish::REPL::Session.new;
my $deny = $s4.eval-line('sys.read("tmp/t82-nope.txt")');
nok $deny.ok, '读不存在的文件是失败格';
like $deny.err, /^ '被拒绝: ' /, 'X::Rakuish 归被拒绝';
is $s4.last-error-kind, '被拒绝', 'last-error-kind 记为被拒绝';
like $deny.err, /'（第 1 格第 1 行）'/, '被拒绝也有位置';

# 判别口径不能漏掉包名限定：Result.rakumod 里声明的异常 `^name` 是
# `Rakuish::Result::X::Rakuish::NotFound`，前缀判定会漏。
is $s4.last-error.^name, 'Rakuish::Result::X::Rakuish::NotFound',
   '异常真名带 Rakuish::Result:: 前缀（判定必须用包含）';

# ── ⑤ full 模式：同一行头 + 回放帧
my $s5 = Rakuish::REPL::Session.new;
$s5.eval-line('errors full');
my $full = $s5.eval-line('die "full"');
nok $full.ok, 'full 模式下 die 仍是失败格';
like $full.err, /^ '运行错误: full' /, 'full 模式保头一行';
like $full.err, /'异常: X::AdHoc'/, 'full 模式带异常类名';
is $full.err.lines.elems, 11, 'full 模式给出完整回放（11 行）';

# 切回 short 之后不该再带帧。
$s5.eval-line('errors short');
my $back = $s5.eval-line('die "short"');
is $back.err.lines.elems, 1, '切回 short 后不再带帧';

# ── ⑥ recall：只回显 + 预填，不执行
# 空历史单独一个会话：后面编号要干净，别让这条失败命令混进 history。
my $se = Rakuish::REPL::Session.new;
my $none = $se.eval-line('recall');
nok $none.ok, '空历史 recall 不是成功';
is $none.code, 127, '空历史 recall code=127';
like $none.err, /'还没有可召回的历史'/, '空历史有明确文案';
my $help-empty = $se.eval-line('recall --help');
ok $help-empty.ok, '空历史里也能查 --help';

my $sr = Rakuish::REPL::Session.new;
$sr.eval-line('my $a = 7');
my Int $idx0 = $sr.index;

my $rc = $sr.eval-line('recall');
ok $rc.ok, 'recall：成功';
like $rc.out, /'recalled 第 1 条'/, '回显编号';
like $rc.out, /'my $a = 7'/, '回显原文';
is $rc.value, 'my $a = 7', 'value 是原文（供前端预填）';
is $sr.index, $idx0, 'recall 不执行代码、不占 Out[n]';
is $sr.take-prefill(), 'my $a = 7', 'take-prefill 给出这一行';
is $sr.take-prefill(), '', '预填只给一次（读完即清）';

# 预填只活到下一格：用户敲了别的行，旧预填作废。
my $i1 = $sr.index;
$sr.eval-line('1 + 1');
is $sr.take-prefill(), '', '下一格执行后旧预填作废';
is $sr.index, $i1 + 1, '普通格照常占 Out[n]';

# 编号规则与 rerun 一致：正数 1 基、负数从末尾算、0 越界。
$sr.eval-line('my $b = 8');
my $last = $sr.eval-line('recall -1');
ok $last.ok, 'recall -1：成功';
is $last.value, 'my $b = 8', 'recall -1 拿到上一条';
like $last.out, /'recalled 第 4 条'/, 'recall -1 回显的是最后一条的编号';
is $sr.take-prefill(), 'my $b = 8', 'recall -1 也放预填';

my $one = $sr.eval-line('recall 1');
ok $one.ok, 'recall 1：成功';
is $one.value, 'my $a = 7', 'recall 1 拿到第一条';
is $sr.take-prefill(), 'my $a = 7', 'recall 1 放预填';

my $zero = $sr.eval-line('recall 0');
nok $zero.ok, 'recall 0：越界';
is $zero.code, 127, 'recall 0 code=127';
like $zero.err, /'没有历史项: 0'/, 'recall 0 的文案点名 0';

my $far = $sr.eval-line('recall 99');
nok $far.ok, 'recall 99：越界';
like $far.err, /'没有历史项: 99'/, 'recall 99 的文案点名 99';
like $far.err, /'用 history 查编号'/, '越界文案指出怎么查编号';

my $junk = $sr.eval-line('recall abc');
nok $junk.ok, 'recall 非数字：不是成功';
is $junk.code, 2, 'recall 非数字 code=2';
like $junk.err, /'用法: recall'/, 'recall 非数字给用法';

my $rh = $sr.eval-line('recall --help');
ok $rh.ok, 'recall --help：成功';
like $rh.out, /'用法: recall [n]'/, '--help 给出用法签名';
like $rh.out, /'不执行'/, '--help 说明不执行（要跑用 rerun）';

# 非交互模式的说明必须诚实：没有预填能力就直说退路，不假装塞进了输入行。
like $rc.out, /'rerun 1'/, '非 TTY 的回显给出 rerun 退路';

# ── ⑦ 两个命令都不影响会话可用性
my $after = $sr.eval-line('$a + $b');
ok $after.ok, 'recall 之后会话仍可求值';
is $after.value, 15, '变量仍是原值（recall 没有执行任何东西）';

done-testing;
