use Test;
use lib 't/lib';
use Rakuish::REPL::Session;

# ══════════════════════════════════════════════════════════════════
# 64-who-rerun.t —— 会话自省三件套（0.108.0 / V-299）
# ══════════════════════════════════════════════════════════════════
# IPython 的 `who` / `whos` / `%rerun` / `x?` 在 Rakuish 里没有对应物：
#   · 状态其实一直都在（%!state / @!decls / @!history），只是没有出口；
#   · 这次只加「出口」，不加求值语义：不 EVAL、不碰 Sys、不占 Out 格号。
# 所以断言的重点是**读取的准确性**和**不误伤**（三元 ?? / 字符串 / 正则）。

# ── 1. who：空会话与变量名 ───────────────────────────────────────────
my $s = Rakuish::REPL::Session.new;
my $empty = $s.eval-line('who');
ok $empty.ok, '空会话里 who 不报错';
like $empty.out, /'还没有变量'/, '空会话给出提示而不是空白';
is $s.index, 0, 'who 不占格号';

$s.eval-line('my $x = 42');
$s.eval-line('my @rows = 1, 2, 3');
$s.eval-line('my %cfg = a => 1, b => 2');
$s.eval-line('my $later');

my $w = $s.eval-line('who');
ok $w.ok, 'who 成功';
is $w.value, ('$later', '$x', '@rows', '%cfg'),
   'who 的值是变量名列表（$ → @ → % 分组后按名排序）';
like $w.out, /'$x'/, '输出里有 $x';
is $s.index, 4, 'who 只读，不推进格号';

# ── 2. whos：类型与大小 ─────────────────────────────────────────────
my $ws = $s.eval-line('whos');
ok $ws.ok, 'whos 成功';
like $ws.out, /'$x' \s+ 'Int'/, '标量显示 Int';
like $ws.out, /'@rows' \s+ 'Array' \s+ '3 项'/, '数组按「项」计大小';
like $ws.out, /'%cfg' \s+ 'Hash' \s+ '2 键'/, '哈希按「键」计大小';
like $ws.out, /'$later' \s+ 'Any（未赋值）'/, '声明未赋值的变量标明未赋值';
nok $ws.out.contains('POPULATE'), 'Rakudo 的元方法 POPULATE 不出现';

# ── 3. whos：声明与模块 ─────────────────────────────────────────────
$s.eval-line('sub greet($who) { "hi $who" }');
$s.eval-line('class Box { method hi { 42 } }');
$s.eval-line('use JSON::Fast');
my $ws2 = $s.eval-line('whos');
like $ws2.out, /'sub' \s+ 'greet'/, 'whos 列出 sub 声明';
like $ws2.out, /'class' \s+ 'Box'/, 'whos 列出 class 声明';
like $ws2.out, /'use' \s+ 'JSON::Fast'/, 'whos 列出 use';

# ── 4. 参数校验 ─────────────────────────────────────────────────────
my $bad = $s.eval-line('who -x');
nok $bad.ok, 'who 拒绝未知选项';
is $bad.code, 2, '用法错误用 code 2';
like $bad.err, /'用法: who'/, '错误里带用法';

# ── 5. `名字?`：变量 / 声明 / 命令 ──────────────────────────────────
my $qx = $s.eval-line('$x?');
ok $qx.ok, '$x? 成功';
like $qx.out, /'$x : Int'/, '变量? 给出名字与类型';
like $qx.out, /'= 42'/, '变量? 给出一行值摘要';

my $ql = $s.eval-line('$later?');
like $ql.out, /'未赋值'/, '未赋值变量的? 标明未赋值';

my $qn = $s.eval-line('$nope?');
nok $qn.ok, '不存在的变量? 报错';
like $qn.err, /'没有这个变量'/, '错误说明是变量不存在';

my $qa = $s.eval-line('@rows?');
like $qa.out, /'Array（3 项）'/, '数组? 给出类型与大小';

my $qb = $s.eval-line('Box?');
ok $qb.ok, '本会话声明的 class 也能 ?';
like $qb.out, /'class（本会话声明）'/, '标明是本会话声明';
like $qb.out, /'hi'/, '列出用户方法';

my $qg = $s.eval-line('greet?');
nok $qg.ok, '本会话 sub 的? 不假装成功';
like $qg.err, /'声明'/, '错误解释 doc 看不到跨格声明';

my $qm = $s.eval-line('JSON::Fast?');
nok $qm.ok, 'use 进来的模块? 有明确说法';
like $qm.err, /'use'/, '错误提示该模块确实已导入';

my $qls = $s.eval-line('ls?');
ok $qls.ok, '命令? 等价 doc';
like $qls.out, /'用法: ls'/, '命令? 显示 usage';

my $qi = $s.eval-line('Int?');
ok $qi.ok, '内置类型? 走 Introspect';
like $qi.out, /'Int'/, '输出类型名';

# ── 6. 不误伤 Raku 语法 ─────────────────────────────────────────────
my $tern = $s.eval-line('1 ?? 2 !! 3');
ok $tern.ok, '三元 ?? !! 仍是 Raku';
is $tern.value, 2, '三元结果正确';

my $str = $s.eval-line(q{my $t = 'a?'});
ok $str.ok, q{'a?' 字符串不被当成 doc 请求'};
is $s.eval-line('$t').value, 'a?', '字符串值完好';

my $re = $s.eval-line(q{'a' ~~ /a?/});
ok $re.ok, '正则 /a?/ 不被当成 doc 请求';

# ── 7. rerun：重跑历史 ──────────────────────────────────────────────
my $rr = Rakuish::REPL::Session.new;
my $c1 = $rr.eval-line('40 + 2');
is $c1.value, 42, '第一格求值';
is $rr.index, 1, '格号 1';

my $c2 = $rr.eval-line('rerun');
is $c2.value, 42, 'rerun 重跑上一条';
is $rr.index, 2, 'rerun 产生新的 Out 格号';
is $rr.eval-line('history').out.lines.elems, 2, 'rerun 本身不额外记一条历史';

is $rr.eval-line('6 * 7').value, 42, '再跑一格';
is $rr.eval-line('rerun 1').value, 42, 'rerun 1 重跑第一条';
is $rr.eval-line('rerun -1').value, 42, 'rerun -1 重跑最后一条';

nok $rr.eval-line('rerun 0').ok, 'rerun 0 越界';
nok $rr.eval-line('rerun 99').ok, 'rerun 99 越界';
nok $rr.eval-line('rerun abc').ok, '非数字参数报用法';
like $rr.eval-line('rerun abc').err, /'用法: rerun'/, '用法文本可读';

nok Rakuish::REPL::Session.new.eval-line('rerun').ok, '空历史报错';

# ── 8. 命令表 / 补全 / help 一起更新 ────────────────────────────────
my $help = $s.eval-line('help').out;
like $help, /'who'/, 'help 列表含 who';
like $help, /'rerun'/, 'help 列表含 rerun';

ok $s.completions('wh', 2).grep(* eq 'who ').elems, 'Tab 能补出 who';
ok $s.completions('rr', 2).elems >= 0, '补全路径不因新命令报错';
ok $s.eval-line('doc who').out.contains('who [-l]'), 'doc who 有用法';
ok $s.eval-line('doc rerun').out.contains('rerun [n]'), 'doc rerun 有用法';
ok $s.eval-line('doc whos').out.contains('whos'), 'doc whos 有用法';

# rerun 之后 `who` 仍只读
my $before = $rr.index;
$rr.eval-line('who');
is $rr.index, $before, 'rerun 会话里 who 也不推动格号';

done-testing;
