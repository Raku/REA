use v6.d;
use Test;
use lib 'lib';

# 0.147.0 / V-351 / ADR-0061：Session 拆分第二步的**结构守卫**。
#
# 与 t/84 同一套路：不测行为（行为由 t/14 / t/19 / t/34 / t/40 / t/64 /
# t/67 / t/82 测），只钉住「诊断/渲染层真的搬出去了、没有走回头路」。
# 0.146.0 的 Session 是 4,035 行；这一刀再切掉约 420 行后是 3,630 行 ——
# 上限 3,700 允许正常增长，但不允许把命令写回 Session。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my IO::Path $diag = $root.add('Session/Diagnostics.rakumod');

ok $sess.e, 'Session.rakumod 在';
ok $diag.e, '诊断层文件在（Session/Diagnostics.rakumod）';

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str $diag-text = $diag.slurp.subst("\x[FEFF]", '');

# ── 声明的形状：role + does + use ────────────────────────────────────
# 第一行代码（跳过文件头注释）必须是 unit role 声明。
my Str $diag-head = $diag-text.lines.first({ .trim && !.trim.starts-with('#') }).trim;
is $diag-head, 'unit role Rakuish::REPL::Session::Diagnostics;',
     '诊断层是 unit role Rakuish::REPL::Session::Diagnostics';

like $sess-text, /'unit class Rakuish::REPL::Session does Rakuish::REPL::Session::Commands'/,
     'Session 仍声明 does ...Commands（第一步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Config'/,
     'Session 仍声明 does ...Config（第一步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Diagnostics'/,
     'Session 声明了 does ...Diagnostics';
like $sess-text, /'use Rakuish::REPL::Session::Diagnostics;'/,
     'Session 在 unit 之前 use 了 Diagnostics（否则 does 解析不到）';

# ── 反方向：7 条命令不许留在 Session ────────────────────────────────
for <!cmd-explore !cmd-perf !cmd-tb !cmd-audit !cmd-log !cmd-hint !cmd-who> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    nok $sess-text.contains($sig), "$m 不在 Session（否则就是又长回去了）";
}

# 辅助方法同样搬走：它们是命令的实现体，留一个在 Session 就是把耦合留下
for <perf-report !render-trace collect-traceback !source-line log-line
     hint-text next-hint !sigil-rank !value-type !value-size> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    nok $sess-text.contains($sig), "$m 不在 Session";
    ok $diag-text.contains($sig), "$m 在诊断层";
}

# 三条历史访问器**必须留在 Session**：它们与同名属性访问器同名，
# 搬进 role 后 `$.log-path` 会解析回 role 自己的方法形成自递归。
ok $sess-text.contains('method log-active('), 'log-active 留在 Session（对外 API 的形状）';
nok $diag-text.contains('method log-active('), 'log-active 不在诊断层（同名自递归陷阱）';
nok $sess-text.contains('method log-path('), 'log-path 不再手写覆盖（改用属性的读写访问器）';

# ── 规模上限：拆分后不该再长回去 ─────────────────────────────────────
# 拆分前 4,035 行（0.146.0 实测）；拆出 420 行后 3,630 行。
my Int $sess-lines = $sess-text.lines.elems;
cmp-ok $sess-lines, '<', 3700,
       "Session 行数 {$sess-lines} 低于 3,700（不再把诊断层长回来）";

# ── META6 provides：新增文件必须登记（t/51 也会查，这里显式钉住）─────
my Str $meta = 'META6.json'.IO.slurp;
ok $meta.contains('"Rakuish::REPL::Session::Diagnostics": "lib/Rakuish/REPL/Session/Diagnostics.rakumod"'),
     'META6 provides 登记了 Diagnostics';

# ── 运行时：role 组合后真的能用，不是只搬了文本 ─────────────────────
use Rakuish::REPL::Session;
my $s = Rakuish::REPL::Session.new(:snapshot-on(False));

ok $s.^can('perf-report'), 'Session 实例上有 perf-report（role 组合生效）';
ok $s.^can('collect-traceback'), 'Session 实例上有 collect-traceback';
ok $s.^can('log-line'), 'Session 实例上有 log-line';

ok $s.eval-line('who').ok, 'who 仍可用（读 @.decls / %.state 的公开面）';
is $s.collect-traceback.elems, 0, '没有上一格异常时 collect-traceback 返回空';

is $s.perf-report, '还没有计时记录。', 'perf-report 走的是 role 里的公开方法';
ok $s.eval-line('perf').out.contains('还没有计时记录'), 'perf 命令可用';

ok $s.eval-line('tb').ok, 'tb 在无异常时也成功（给出「还没有」的说明）';
ok $s.eval-line('tb').out.contains('还没有异常可回放'), 'tb 的说明来自诊断层';

ok $s.eval-line('log').out.contains('日志未开启'), 'log 状态行仍可用';
ok $s.eval-line('hint ls').ok, 'hint 命令可用（hint-for 仍加载）';

done-testing;
