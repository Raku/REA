use v6.d;
use Test;
use lib 'lib';

# 0.150.0 / V-354 / ADR-0064：Session 拆分第五步的**结构守卫**。
#
# 与 t/84..t/87 同一套路：不测行为本身（行为由 t/82 的 recall / t/68 的
# source / t/79 的 paste 覆盖），只钉住「输入重放这一簇真的搬进 Replay
# role、Session 没有又长回去」，以及**三个窄私有入口**还在 Session 里。
# 0.149.0 的 Session 是 3,093 行；这一刀切掉 243 行后是 2,856 行 ——
# 上限 2,900 允许正常增长，但不允许把 recall / source / paste 写回 Session。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my IO::Path $replay = $root.add('Session/Replay.rakumod');

ok $sess.e, 'Session.rakumod 在';
ok $replay.e, '重放层文件在（Session/Replay.rakumod）';

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str $replay-text = $replay.slurp.subst("\x[FEFF]", '');

# ── 声明的形状：role + does + use ────────────────────────────────────
my Str $replay-head = $replay-text.lines.first({ .trim && !.trim.starts-with('#') }).trim;
is $replay-head, 'unit role Rakuish::REPL::Session::Replay;',
     '重放层是 unit role Rakuish::REPL::Session::Replay';

like $sess-text, /'does Rakuish::REPL::Session::Commands'/,
     'Session 仍声明 does ...Commands（第一步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Config'/,
     'Session 仍声明 does ...Config（第一步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Diagnostics'/,
     'Session 仍声明 does ...Diagnostics（第二步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Persistence'/,
     'Session 仍声明 does ...Persistence（第三步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Cells'/,
     'Session 仍声明 does ...Cells（第四步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Replay'/,
     'Session 声明了 does ...Replay';
like $sess-text, /'use Rakuish::REPL::Session::Replay;'/,
     'Session 在 unit 之前 use 了 Replay（否则 does 解析不到）';

# ── 反方向：三条命令不许留在 Session ─────────────────────────────────
for <!cmd-recall !cmd-source !cmd-paste> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    nok $sess-text.contains($sig), "$m 不在 Session（否则就是又长回去了）";
    ok $replay-text.contains($sig), "$m 在重放层";
}

# ── 预填缓冲的读侧留在 Session（前端 API）────────────────────────────
ok $sess-text.contains('method take-prefill('), 'take-prefill 留在 Session（前端读预填的公开 API）';
nok $replay-text.contains('method take-prefill('), 'take-prefill 不在重放层';

# ── 三个窄私有入口：写侧留在 Session，不变成公开属性 ─────────────────
for <!set-prefill !mark-recorded !clear-pending> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    ok $sess-text.contains($sig), "$m 留在 Session（写侧不是 API）";
    nok $replay-text.contains($sig), "$m 不在重放层";
    ok $replay-text.contains('self' ~ $m ~ '('), "重放层经 self{$m}(…) 调用它";
}

# ── 状态公开：role 只能走访问器 ─────────────────────────────────────
for <@.history @.out @.perf-hist> -> $a {
    ok $sess-text.contains("has {$a} is rw;"), "$a 是公开属性";
}
for <$.index $.exit-requested> -> $a {
    ok $sess-text.contains("has Bool {$a}" ) || $sess-text.contains("has Int  {$a}"),
       "$a 是公开属性";
}
nok $replay-text ~~ /<[$@%&]>\!<[A..Za..z]>/, '重放层没有任何类私有属性引用（含 &! 可调用属性）';
ok $replay-text.contains('self.input-handler'), '重放层经 self.input-handler 读输入回调';
ok $replay-text.contains('self.read-line'), '重放层经 self.read-line 读行';
ok $replay-text.contains('use Rakuish::REPL::Highlight;'), '重放层自己 use 了 Highlight（set-continuation）';
ok $replay-text.contains('use Rakuish::Incomplete;'), '重放层自己 use 了 Incomplete（is-incomplete）';

# ── 规模上限：拆分后不该再长回去 ─────────────────────────────────────
# 拆分前 3,093 行（0.149.0 实测）；切掉 243 行、补回 12 行（三个入口）后 2,856 行。
my Int $sess-lines = $sess-text.lines.elems;
cmp-ok $sess-lines, '<', 2900,
       "Session 行数 {$sess-lines} 低于 2,900（不再把重放层长回来）";

# ── META6 provides：新增文件必须登记（t/51 也会查，这里显式钉住）─────
my Str $meta = 'META6.json'.IO.slurp;
ok $meta.contains('"Rakuish::REPL::Session::Replay": "lib/Rakuish/REPL/Session/Replay.rakumod"'),
     'META6 provides 登记了 Replay';

# ── 运行时：role 组合后真的能用，不是只搬了文本 ─────────────────────
use Rakuish::REPL::Session;
my $s = Rakuish::REPL::Session.new(:snapshot-on(False));

my $empty = $s.eval-line('recall');
is $empty.ok, False, '空会话里 recall 报错';
is $empty.code, 127, '空会话 recall 的退出码是 127';
like $s.eval-line('recall --help').out, /'用法: recall'/, 'recall --help 在空会话里也给用法';

$s.eval-line('my $a = 7');
# 编号按当前历史长度算：前面 recall / recall --help 也各占一条，
# 写死 recall 2 会取到 recall --help，测的就不是「最近一条」了。
my Int $recall-n = $s.history.elems;
my $r = $s.eval-line("recall {$recall-n}");
is $r.ok, True, 'recall <最近一条的编号> 成功（走 role）';
is $s.take-prefill(), 'my $a = 7', 'recall 把源码放进了预填缓冲';
is $s.take-prefill(), '', '预填只给一次（读完即清）';

$s.eval-line('1 + 1');
my $neg = $s.eval-line('recall -1');
is $neg.ok, True, '负数编号从末尾算';
is $s.take-prefill(), '1 + 1', 'recall -1 取到的是最后一条';
is $s.eval-line('recall abc').code, 2, '非法参数的退出码是 2';

like $s.eval-line('source').out, /'用法: source'/, 'source 无参数给用法';
is $s.eval-line('source no-such-file.raku').code, 127, 'source 找不到文件返回 127';

# 临时脚本：验证 source 的语义（逐行喂 eval-line，声明留在会话里）。
# 脚本里用 `say` 而不是裸表达式：值格的 `.out` 是空的（值在 `.value`），
# 只有 say 出来的东西才会进 `.out`。
my IO::Path $script = $*TMPDIR.add("rakuish-t88-src-{$*PID}.raku");
$script.spurt("my \$x = 5;\nsay \$x + 1;\n");
LEAVE { .unlink if .e for $script }

my Int $idx-before = $s.index;
my Int $hist-before = $s.history.elems;
my $src = $s.eval-line("source {$script.Str}");
is $src.ok, True, 'source 执行临时脚本成功';
is $src.out.trim, '6', 'source 把脚本的输出带回来';
# 这两条必须在再 eval 一次之前查：eval 自己会占 Out[n] 与历史。
is $s.index, $idx-before, '脚本的行不占 Out[n]（计数器回滚）';
is $s.history.elems, $hist-before + 1, '只记了 source 这一行，不是脚本的每一行';
is $s.eval-line('$x').value, 5, '脚本里的顶层 my 留在会话里（source 的主要用途）';

like $s.eval-line('paste --help').out, /'用法: paste'/, 'paste --help 给用法';
is $s.eval-line('paste x').code, 2, 'paste 带参数返回 2';
# 普通 Session 没有输入回调 → 走 $*IN。这里**必须遮蔽 $*IN**：测试进程的
# stdin 不保证是 EOF —— zef / prove 在真终端下会把终端交给测试，`paste`
# 就会一直等回车，整个安装看起来像卡死（0.154.0 在 WSL 里就是这样）。
# 遮蔽成「立刻 EOF 的假 stdin」，断言的是 paste 的分支，不是测试进程的 fd。
class Test-EOF-In { method get(--> Nil) { Nil } }
{
    my $*IN = Test-EOF-In.new;
    is $s.eval-line('paste').code, 1, '无输入回调且 stdin 为空时 paste 报错';
    like $s.eval-line('paste').err, /'没有读到内容'/, '报的是「没有读到内容」，不是「不可用」';
}

# 引擎 / notebook 模式会挂输入回调（stdin 是协议流）→ 必须拒绝。
my $engine-like = Rakuish::REPL::Session.new(:snapshot-on(False),
                                            :input-handler(-> { 'x' }));
is $engine-like.eval-line('paste').code, 1, '有输入回调时 paste 拒绝';
like $engine-like.eval-line('paste').err, /'不可用'/, '拒绝理由说清了不可用的原因';

# 注入 read-line（前端 / 测试注入的读行闭包）：paste 必须调用**闭包本身**。
# 0.150.0 首版写成 `self.read-line()`，那仍然是在调访问器、拿到的是 Block，
# 于是 `.Str` 每轮告警、`--` 永远不匹配 → 死循环。这条断言钉住那个修法。
my @feed = ('my $pv = 5', '--', 'my $after = 9');
my $with-reader = Rakuish::REPL::Session.new(:snapshot-on(False));
$with-reader.read-line = -> { @feed.elems ?? @feed.shift !! Nil };
is $with-reader.eval-line('paste').ok, True, '注入 read-line 时 paste 读到 -- 并执行';
is $with-reader.eval-line('$pv').value, 5, 'paste 的块进了同一个格（$pv 可用）';
is $with-reader.eval-line('$after').ok, False, '-- 之后的行没被 paste 吃掉';

done-testing;
