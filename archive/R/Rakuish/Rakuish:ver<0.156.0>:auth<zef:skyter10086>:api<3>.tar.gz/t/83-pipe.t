#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys;
use Rakuish::REPL::Session;

# 83-pipe.t —— 引擎内管道（0.143.0 / V-347 / ADR-0056）
#
# 主张：`! a | b | c` 只把 **stdout** 串起来，其余全是普通 exec 语义。
# 断言分四组：
#   ① 数据通路：后一段收到前一段的 stdout，多段同样成立；
#   ② 退出码：取**末段**，各段码在 value<stages>（不实现 pipefail）；
#   ③ 失败诚实：末段起不来是 127 + start-failed，不留半条管道；
#   ④ REPL 接线：`!` 行切段、引号里的 `|` 不切、`--tty` 走父进程执行器、
#      `||` 明确拒绝。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';
%*ENV<RAKUISH_NO_RC> = '1';

my Str $raku = $*EXECUTABLE.Str;
my $sys = Rakuish::Sys.new;

# ── ① 数据通路 ──────────────────────────────────────────────────────
{
    my $r = $sys.pipe-exec((($raku, '-e', 'print "b\nc\na\n"'),
                            ($raku, '-e', 'say $*IN.lines.sort.join(",")')));
    ok $r.ok, '两段：末段正常退出 → ok';
    is $r.out.trim, 'a,b,c', '两段：后一段确实读到了前一段的 stdout';
    ok ?$r.value<pipeline>, 'value<pipeline> 标记这是管道';
    is $r.value<stages>.elems, 2, 'value<stages> 每段一条记录';

    # 三段：中间段同时是下游的上游。
    my $r3 = $sys.pipe-exec((($raku, '-e', 'print "1\n2\n3\n4\n"'),
                             ($raku, '-e', 'for $*IN.lines { say $_ if $_ % 2 == 0 }'),
                             ($raku, '-e', 'say $*IN.lines.join("+")')));
    is $r3.out.trim, '2+4', '三段：中间段的输出继续往后传';
    is $r3.value<stages>.elems, 3, '三段：stages 记录三段';

    # 大流量不挂死：2 万行进 / 末段只取第一行（下游提前关 stdin）。
    my $rbig = $sys.pipe-exec((($raku, '-e', 'for 1..20000 { say $_ }'),
                               ($raku, '-e', 'say $*IN.lines.head; exit')));
    is $rbig.out.trim, '1', '早停：末段只读一行也能正常收尾（不挂死）';
}

# ── ② 退出码 ────────────────────────────────────────────────────────
{
    # shell 默认语义：成功与否只看末段。
    my $r = $sys.pipe-exec((($raku, '-e', 'say "x"; exit 3'),
                            ($raku, '-e', 'say $*IN.slurp.trim')));
    ok $r.ok, '退出码：前段非零、末段成功 → ok（不实现 pipefail）';
    is $r.code, 0, '退出码：取末段';
    is $r.value<stages>[0]<code>, 3, '退出码：前段的码记在 stages';
    is $r.value<stages>[1]<code>, 0, '退出码：末段的码记在 stages';
    is $r.out.trim, 'x', '退出码：前段非零不影响数据通路';

    my $bad = $sys.pipe-exec((($raku, '-e', 'say "x"'),
                              ($raku, '-e', '$*IN.slurp; exit 5')));
    nok $bad.ok, '退出码：末段非零 → 失败 Result';
    is $bad.code, 5, '退出码：末段的码原样透出';
}

# ── ③ 失败诚实 ──────────────────────────────────────────────────────
{
    my $r = $sys.pipe-exec((($raku, '-e', 'say "x"'),
                            ('rakuish-no-such-exe-xyz',)));
    is $r.code, 127, '启动失败：末段 exe 不存在 → 127';
    ok ?$r.value<start-failed>, '启动失败：value<start-failed> = True';
    like $r.err, /'no-such-exe'|'Failed to spawn'/, '启动失败：err 里有原因';

    my $rerr = $sys.pipe-exec((($raku, '-e', '$*ERR.say("up"); say "o"'),
                               ($raku, '-e', '$*ERR.say("down"); say $*IN.slurp.trim')));
    like $rerr.err, /'up'/, 'stderr：前段自己的 stderr 不被吞掉';
    like $rerr.err, /'down'/, 'stderr：末段自己的 stderr 也在';
    is $rerr.out.trim, 'o', 'stderr：stderr 不混进 stdout 通路';
}

# ── ④ REPL 接线 ─────────────────────────────────────────────────────
{
    my $sess = Rakuish::REPL::Session.new(:color(False));
    my Str $q = q{'} ~ $raku ~ q{'};

    my Str $line = '! ' ~ $q ~ q{ -e 'print "a\nb\n"'} ~ ' | '
                 ~ $q ~ q{ -e 'say $*IN.lines.elems'};
    my $r = $sess.eval-line($line);
    is $r.out.trim, '2', '! 行：顶层 | 切段并执行（两段）';

    # 引号里的 | 是普通字符，不切段。
    my $rq = $sess.eval-line('! ' ~ $q ~ q{ -e 'say "a|b"'} ~ ' | '
                             ~ $q ~ q{ -e 'say $*IN.slurp.trim'});
    is $rq.out.trim, 'a|b', '! 行：引号里的 | 不切段';

    # 0.144.0 / V-348：`--tty` + 管道交给父进程（ADR-0057）。没有执行器时
    # 必须明确失败 —— **不能**回退引擎内：第 0 段会把协议 stdin 吃掉。
    my $rtty = $sess.eval-line('! --tty echo x | findstr x');
    nok $rtty.ok, '! 行：--tty 管道没有父进程执行器 → 失败';
    like $rtty.err, /'执行器'|'父进程'/, '! 行：失败说明指向父进程执行器';

    # 注入 fake 执行器：验调用次数、段数、输出透传、非流式。
    my $sess2 = Rakuish::REPL::Session.new(:color(False));
    my Int $pip-calls = 0;
    my @pip-stages;
    $sess2.pipe-handler = -> @stages {
        ++$pip-calls;
        @pip-stages = @stages;
        Rakuish::Result::Result.new(:ok, :code(0), :op<exec>,
            :out("PIPE-OUT {@stages.elems}"));
    };
    my $rp = $sess2.eval-line('! --tty echo x | findstr x');
    is $pip-calls, 1, '! 行：--tty 管道的父进程执行器被调用一次';
    ok ?$rp.ok, '! 行：执行器结果原样成为本格结果';
    is $rp.out, 'PIPE-OUT 2', '! 行：执行器输出原样返回（Out[n] 可用）';
    is @pip-stages.elems, 2, '! 行：执行器收到两段';
    is @pip-stages[1][0], 'findstr', '! 行：段的 exe 按 argv 传（不拼 shell 串）';
    nok $rp.streamed, '! 行：交互式管道结果不标记流式';

    my $rbar = $sess.eval-line('! echo x || echo y');
    nok $rbar.ok, '! 行：|| 不支持';
    like $rbar.err, /'空段'|'不支持'/, '! 行：|| 报「空段」而不是静默当两段';
}

# ── ⑤ P1/P2：--pipe / --pipefail / --stdin（0.145.0 / V-349）────────
#
# P1 的边界写在 ADR-0059：Windows 上没法把真终端 fd 交给子进程，所以「透传」
# 是**数据层**的 —— 父进程/本进程泵出直写，不攒、不截断、默认不设总超时。
{
    my $sess = Rakuish::REPL::Session.new(:color(False));
    my Str $q = q{'} ~ $raku ~ q{'};

    # --pipe + --capture 是自相矛盾的要求，必须明确拒绝。
    my $rc = $sess.eval-line('! --pipe --capture ' ~ $q ~ ' --version');
    nok $rc.ok, '--pipe --capture：互斥 → 失败';
    is $rc.code, 127, '--pipe --capture：冒号口径 127';
    like $rc.err, /'互斥'/, '--pipe --capture：说明是互斥而不是静默挑一个';

    # --pipefail：退出码取最右非零段（默认取末段）。
    my $rf = $sess.eval-line('! --pipefail ' ~ $q ~ q{ -e 'exit 3'} ~ ' | '
                             ~ $q ~ q{ -e 'print $*IN.slurp'});
    is $rf.code, 3, '--pipefail：3|0 → 取前段的 3';
    nok $rf.ok, '--pipefail：非零即失败';
    my $rdef = $sess.eval-line('! ' ~ $q ~ q{ -e 'exit 3'} ~ ' | '
                               ~ $q ~ q{ -e 'print $*IN.slurp'});
    is $rdef.code, 0, '默认：3|0 → 仍取末段的 0';

    my $rl = $sess.eval-line('! --pipefail ' ~ $q ~ q{ -e 'exit 0'} ~ ' | '
                             ~ $q ~ q{ -e '$*IN.slurp; exit 4'} ~ ' | '
                             ~ $q ~ q{ -e '$*IN.slurp; exit 2'});
    is $rl.code, 2, '--pipefail：全非零取最右那个（0|4|2 → 2）';

    # --stdin：首段 stdin 从文件流式接入（路径经 Sys 解析成绝对路径）。
    my $tmp = $*CWD.add(".rakuish-t83-stdin-{$*PID}.txt");
    $tmp.spurt("alpha\nbeta\n");
    LEAVE { try { unlink $tmp } }
    my $rs = $sess.eval-line('! --stdin ' ~ $tmp.Str ~ ' ' ~ $q
                             ~ q{ -e 'say $*IN.lines.join("|")'});
    ok $rs.ok, '--stdin：命令正常退出';
    is $rs.out.trim, 'alpha|beta', '--stdin：首段确实从文件读到了 stdin';

    my $rn = $sess.eval-line('! --stdin ' ~ $tmp.Str ~ '-nope ' ~ $q ~ ' --version');
    nok $rn.ok, '--stdin：文件不存在 → 失败';
    is $rn.code, 127, '--stdin：文件不存在 → 127';
    like $rn.err, /'不存在'/, '--stdin：错误说明指向文件不存在';

    # --pipe 的开关要**原样**过协议交给父进程执行器（worker 模式真正跑管道的是它）。
    my $sess2 = Rakuish::REPL::Session.new(:color(False));
    my %seen;
    my @seen-stages;
    my Int $calls = 0;
    $sess2.pipe-handler = -> @stages, *%opts {
        ++$calls;
        %seen = %opts;
        @seen-stages = @stages;
        Rakuish::Result::Result.new(:ok, :code(0), :op<exec>,
            :out('should-not-replay'));
    };
    my $rp = $sess2.eval-line('! --pipe --pipefail --stdin ' ~ $tmp.Str ~ ' '
                              ~ $q ~ q{ -e 'print $*IN.slurp'} ~ ' | '
                              ~ $q ~ q{ -e 'print $*IN.slurp'});
    is $calls, 1, '--pipe：交父进程执行器一次';
    ok ?%seen<no-capture>, '--pipe：no-capture 传到父进程';
    ok ?%seen<pipefail>, '--pipefail：pipefail 传到父进程';
    # 路径经 Sys.resolve 归一化（Windows 上分隔符统一成 /），比较用同一口径。
    is %seen<stdin-file>, $sess2.sys.resolve($tmp.Str).Str, '--stdin：绝对路径传到父进程';
    is %seen<timeout-ms>, 0, '--pipe：默认不设总超时（timeout-ms=0）';
    is @seen-stages.elems, 2, '--pipe：父进程收到两段';
    is $rp.out, '', '--pipe：父进程已直写终端，Result.out 不再复述';
    ok $rp.streamed, '--pipe：结果标 streamed，render 不重放';

    # 真端到端：单进程模式下 `--pipe` 的输出必须落到 stdout（不是 Result.out）。
    my $e2e = $sys.exec($raku, '-I', 'lib', 'bin/rakuish', '-e',
        '! --pipe ' ~ $q ~ q{ -e 'print "e2e-out"'} ~ ' | '
        ~ $q ~ q{ -e 'print $*IN.slurp'});
    is $e2e.out.trim, 'e2e-out', '--pipe（-e）：末段输出直写 stdout';
}

done-testing;
