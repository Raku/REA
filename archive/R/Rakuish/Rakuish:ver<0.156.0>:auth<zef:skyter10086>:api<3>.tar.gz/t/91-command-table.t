use v6.d;
use Test;
use lib 'lib';
use Rakuish::Result;
use Rakuish::REPL::Session;

# 0.153.0 / V-357 / ADR-0067：`!eval-line-body` 的命令 if 链 → 数据驱动命令表。
#
# 这一版不搬文件、不改对外行为，只把「有哪些会话命令」从控制流变成数据。
# 所以这里守的不是「拆到哪去了」，而是三件事：
#   1. 表真的存在、字段完整、名字集合与旧 if 链一致（不多不少）；
#   2. 表里每个 m 都指向一个真实存在的 `method !m(`（拼错名字是运行期才炸的坑）；
#   3. 旧 if 链的形态没有残留在 Session 里（否则等于两套分叉）。
# 行为本身由 t/03..t/10、t/19、t/34、t/40 等守；这里只逐条确认「表项确实能通到」。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my @role-names = <Commands Config Diagnostics Persistence Cells Replay Completion Exec>;
my @role-files = @role-names.map({ $root.add("Session/{$_}.rakumod") });

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str @all-text  = ($sess-text, |@role-files.map({ $_.slurp.subst("\x[FEFF]", '') }));

# ── 1. 表的存在与形状 ───────────────────────────────────────────────
my Int $start = $sess-text.index('my constant SESSION-COMMANDS');
ok $start.defined, 'Session 里有 SESSION-COMMANDS 命令表';
my Int $end = $start.defined ?? $sess-text.index("\n);", $start) !! Nil;
ok $end.defined, '命令表有正常的结束（不是被截断的半张表）';

my Str $table = ($start.defined && $end.defined)
    ?? $sess-text.substr($start, $end - $start)
    !! '';
ok $table.chars > 400, '命令表不是空壳';

# 表项声明成一行一个 `%( ... )`；先压平空白，再按 `%(` 切开。
my Str $flat = $table.subst(/\s+/, ' ', :g);
my @chunks = $flat.split('%(').skip;

sub field(Str $chunk, Str $key --> Str) {
    my $m = $chunk ~~ / $key \s* '=>' \s* \x27 (.*?) \x27 /;
    $m.defined ?? ~$m[0] !! '';
}

my Str @names   = @chunks.map({ field($_, 'name') });
my Str @modes   = @chunks.map({ field($_, 'mode') });
my Str @args    = @chunks.map({ field($_, 'arg') });
my Str @methods = @chunks.map({ field($_, 'm') });

is @chunks.elems, 22, '命令表有 22 项';
is @names.unique.elems, @names.elems, '命令表里没有重名（重名会让后一项永远不可达）';

my Str @want = <history perf tb errors log audit hint plugin describe who whos rerun
                recall source paste store cells alias unalias config hook explore>;
is @names.join(' '), @want.join(' '), '表项的名字与顺序与旧 if 链完全一致（行为不变的前提）';

for @chunks.kv -> $i, $c {
    ok @modes[$i] (elem) <exact argv only-argv>, "第 {$i + 1} 项的 mode 合法（{@names[$i]}）";
    ok @args[$i]  (elem) <raw trim const none>, "第 {$i + 1} 项的 arg 合法（{@names[$i]}）";
    like @methods[$i], /^ 'cmd-' <[a..z-]>+ $/, "第 {$i + 1} 项的 m 指向一个 !cmd-* 方法（{@names[$i]}）";
}

# ── 2. 每个 m 都真实存在（拼错名字只在运行到那行时才炸）─────────────
for @methods.kv -> $i, $m {
    my Str $sig = "method !{$m}(";
    ok @all-text.first({ $_.contains($sig) }).defined,
       "命令表项 {@names[$i]} 的 !{$m} 真的有定义（同类或 role 里）";
}

# ── 3. 别名与固定实参这两处特例没被表压平 ───────────────────────────
my Str $tb-chunk  = @chunks[@names.first('tb', :k)];
my Str $whos-chunk = @chunks[@names.first('whos', :k)];
like $tb-chunk, /'alias' \s* '=>' \s* '<debug backtrace>'/, 'tb 保留 debug / backtrace 两个精确别名';
like $whos-chunk, /'const' \s* '=>' \s* \x27 'who -l' \x27/, 'whos 保留「就是 who -l」的固定实参';

# ── 4. 分流器在，且只有一个 ─────────────────────────────────────────
ok $sess-text.contains('method !dispatch-command('), 'Session 有 !dispatch-command 分流器';
like $sess-text, /'self!"$m"'/, '分流器用动态私有方法调用（self!"$m"）派发';
ok $sess-text.contains('self!dispatch-command($t)'), '!eval-line-body 经分流器处理会话命令';
is $sess-text.indices('method !dispatch-command(').elems, 1, '分流器只有一处（不散落）';

# ── 5. 旧 if 链没有残留（否则就是两套分叉）──────────────────────────
for @want -> $n {
    nok $sess-text.contains("starts-with('{$n} ')") || $sess-text.contains("eq '{$n}'"),
        "旧 if 链里 {$n} 的分支已消失";
}

# `set` 家族是解析（三条正则各自产出 Result），不是名字→方法映射，按设计留在链上。
ok $sess-text.contains(q{'set' \s+ <[-+]> 'o'}),
   'set 家族仍留在 !eval-line-body（解析型，不进表）';
# ── 6. 规模与历史上的 if 链 ────────────────────────────────────────
my Int $sess-lines = $sess-text.lines.elems;
ok $sess-lines > 2200, "Session 行数 {$sess-lines} 仍大于 2,200（防空跑）";
# 0.156.0：混合格声明那三个辅助方法（!top-statements / !decls-in-cell /
# !put-decl）加进来 +70 行上下，上界从 2,400 放到 2,500。命令表本身没有变长，
# 这条断言的意图是「if 链没有偷偷回来」，不是「文件不许涨行」。
ok $sess-lines < 2500, "Session 行数 {$sess-lines} 低于 2,500（没有又长回去）";

# ── 7. 逐条走一遍：表项确实能通到各自的处理方法 ────────────────────
my $s = Rakuish::REPL::Session.new;

my %fresh = (
    history  => 'history',
    perf     => 'perf',
    tb       => 'tb',
    debug    => 'debug',
    backtrace => 'backtrace',
    errors   => 'errors',
    log      => 'log',
    audit    => 'audit',
    hint     => 'hint',
    plugin   => 'plugin',
    describe => 'describe',
    who      => 'who',
    whos     => 'whos',
    rerun    => 'rerun',
    recall   => 'recall 1',
    source   => 'source definitely-no-such-file-xyz.raku',
    paste    => 'paste --help',
    store    => 'store -l',
    cells    => 'cells',
    alias    => 'alias',
    unalias  => 'unalias nosuch',
    config   => 'config',
    hook     => 'hook',
    explore  => 'explore /definitely/no/such/path',
);

my %op-for = (
    history => 'history', perf => 'perf', tb => 'tb', debug => 'tb', backtrace => 'tb',
    errors => 'errors', log => 'log', audit => 'audit', hint => 'hint', plugin => 'plugin',
    describe => 'describe', who => 'who', whos => 'who', rerun => 'rerun', recall => 'recall',
    source => 'source', paste => 'paste', store => 'store', cells => 'cells',
    alias => 'alias', unalias => 'unalias', config => 'config', hook => 'hook', explore => 'explore',
);

for @want -> $n {
    # rerun 会重跑上一格，共用会话时它的 op 来自重跑的那一行；单独测。
    next if $n eq 'rerun';
    my $r = $s.eval-line(%fresh{$n});
    is $r.op // '', %op-for{$n}, "{$n} 经命令表派发到 !cmd-*（op={%op-for{$n}}）";
}

my $empty-rerun = Rakuish::REPL::Session.new.eval-line('rerun');
is $empty-rerun.op // '', 'rerun', 'rerun 经命令表派发到 !cmd-rerun（空历史也认）';
is $empty-rerun.code, 127, '空历史时 rerun 仍是 127';

# 表里没有的形态仍走原来的路：set 家族、`名字?`、`!` 分发、Raku
is $s.eval-line('set').op // '', 'set', 'set 仍由内联的 set 家族处理';
is $s.eval-line('set -o errexit').op // '', 'set', 'set -o 仍由内联的 set 家族处理';
is $s.eval-line('set -e').op // '', 'set', 'set -e 兼容别名仍可用';
my $unknown-set = $s.eval-line('set -x');
is $unknown-set.op // '', 'eval', 'set -x 仍落回 Raku（不认识的形态不抢）';
is $s.eval-line('history?').op // '', 'doc', '`名字?` 仍走 doc（表之后的正则）';
is $s.eval-line('!echo table-ok').out.trim, 'table-ok', '`!` 分发仍在表之后';

# unalias 的裸写保持老行为：落回 Raku，而不是被当成「列出别名」
my $bare-unalias = $s.eval-line('unalias');
nok ($bare-unalias.op // '') eq 'unalias', '裸写 unalias 仍落回 Raku（only-argv 口径保住了）';

# 历史替换仍按「整行语法」处理，且自身不进 history
my $h = Rakuish::REPL::Session.new;
$h.eval-line('my $z = 41');
my Int $before = $h.history.elems;
my $bang = $h.eval-line('!!');
ok $bang.ok, '!! 仍能重跑上一行';
is $h.history.elems, $before + 1, '!! 自身不写进 history（只记展开后的真实命令）';

# rerun 仍按编号重跑（表项 whos 的固定实参不加进 history）
my $rr = Rakuish::REPL::Session.new;
$rr.eval-line('1 + 2');
my $rerun = $rr.eval-line('rerun 1');
ok $rerun.ok, 'rerun 1 仍可重跑第 1 条';
is $rerun.value, 3, 'rerun 带回重跑那一格的值';

done-testing;
