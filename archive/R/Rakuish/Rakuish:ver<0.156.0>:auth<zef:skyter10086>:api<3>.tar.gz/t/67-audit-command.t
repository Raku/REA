use Test;

# 0.112.0 / V-303：`audit` 会话命令 —— 按 origin 查结构化账本。
# 与 `log`（给人看的文本抄本）是两个东西；这里只测命令与 Kernel 注入，
# Audit 自身的跨进程查询在 t/40。

use Rakuish::Kernel;
use Rakuish::REPL::Session;
use Rakuish::Audit;

my $audit = Rakuish::Audit.new;
my $s = Rakuish::REPL::Session.new;
my $k = Rakuish::Kernel.new(:session($s), :audit($audit));

ok $s.audit === $audit, 'Kernel 把共享审计实例注入 Session';

for <human notebook notebook script> -> $o {
    $k.execute(Request.new(:kind<source>, :payload('1 + 1'), :origin($o)));
}

my $sum = $s.eval-line('audit');
ok $sum.ok, 'audit 成功';
is $sum.op, 'audit', 'op=audit';
ok $sum.out.contains('notebook'), '摘要列出 notebook';
ok $sum.out.contains('human'), '摘要列出 human';
ok $sum.out.contains('failed'), '摘要有失败计数列';
is $sum.value<notebook><total>, 2, 'value 是结构化汇总';

my $nb = $s.eval-line('audit notebook');
ok $nb.ok, 'audit notebook 成功';
ok $nb.out.contains('origin=notebook（2 条）'), '条目视图带来源与条数';
is $nb.value.elems, 2, 'value 是两条记录';

my $flag = $s.eval-line('audit --origin human');
ok $flag.ok, '--origin 形式成功';
is $flag.value.elems, 1, '--origin 与直接写来源等价';

my $none = $s.eval-line('audit unknown-origin');
ok $none.ok, '查不到的来源不是错误';
ok $none.out.contains('没有记录'), '空结果如实说明';

my $help = $s.eval-line('audit --help');
is $help.op, 'help', '--help 走 usage';
ok $help.out.contains('audit'), 'usage 文本里有命令名';

my $bad = $s.eval-line('audit --origin');
nok $bad.ok, 'audit --origin 缺参数报错';
ok $bad.err.contains('用法'), '错误里给出用法';

# 会话命令本身不进审计：查完之后总数不变。
is $audit.origin-summary<notebook><total>, 2, 'audit 命令自身不记账';

done-testing;
