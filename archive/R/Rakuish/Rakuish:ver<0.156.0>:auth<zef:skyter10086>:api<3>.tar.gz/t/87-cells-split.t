use v6.d;
use Test;
use lib 'lib';
use JSON::Fast;

# 0.149.0 / V-353 / ADR-0063：Session 拆分第四步的**结构守卫**。
#
# 与 t/84（配置层）、t/85（诊断层）、t/86（持久化层）同一套路：不测行为
# （行为由 t/53? 不，由 t/37 命令表、t/80 display、t/18 类型渲染覆盖），
# 只钉住「格记录这一簇真的搬进 Cells role、Session 没有又长回去」。
# 0.148.0 的 Session 是 3,250 行；这一刀切掉 162 行后是 3,091 行 ——
# 上限 3,150 允许正常增长，但不允许把 cells 写回 Session。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my IO::Path $cells-file = $root.add('Session/Cells.rakumod');

ok $sess.e, 'Session.rakumod 在';
ok $cells-file.e, '格记录层文件在（Session/Cells.rakumod）';

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str $cells-text = $cells-file.slurp.subst("\x[FEFF]", '');

# ── 声明的形状：role + does + use ────────────────────────────────────
my Str $cells-head = $cells-text.lines.first({ .trim && !.trim.starts-with('#') }).trim;
is $cells-head, 'unit role Rakuish::REPL::Session::Cells;',
     '格记录层是 unit role Rakuish::REPL::Session::Cells';

like $sess-text, /'does Rakuish::REPL::Session::Commands'/,
     'Session 仍声明 does ...Commands（第一步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Diagnostics'/,
     'Session 仍声明 does ...Diagnostics（第二步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Persistence'/,
     'Session 仍声明 does ...Persistence（第三步没被回退）';
like $sess-text, /'does Rakuish::REPL::Session::Cells'/,
     'Session 声明了 does ...Cells';
like $sess-text, /'use Rakuish::REPL::Session::Cells;'/,
     'Session 在 unit 之前 use 了 Cells（否则 does 解析不到）';

# ── 反方向：cells 四件套不许留在 Session ─────────────────────────────
for <!cmd-cells !render-cells-list !render-cells-text !render-cells-json> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    nok $sess-text.contains($sig), "$m 不在 Session（否则就是又长回去了）";
    ok $cells-text.contains($sig), "$m 在格记录层";
}

# ── 必须留在 Session 的：argv 切分属于输入层 ─────────────────────────
ok $sess-text.contains('method !split-argv('), '!split-argv 留在 Session（输入层，不是导出层）';
nok $cells-text.contains('method !split-argv('), '!split-argv 不在格记录层';
ok $cells-text.contains('self!split-argv('), '格记录层经 self!split-argv 切参数（role 调类私有方法）';

# ── 状态公开：role 只能走访问器 ─────────────────────────────────────
ok $sess-text.contains('has @.cells is rw;'), '格表是公开属性 @.cells';
ok $sess-text.contains('has Bool $.skip-cell is rw'), 'skip-cell 是公开属性';
nok $cells-text ~~ /<[$@%]>\!<[A..Za..z]>/, '格记录层没有任何类私有属性引用';
nok $cells-text.contains('$!sys'), '格记录层不写 $!sys（走 $.sys）';
ok $cells-text.contains('$.sys'), '格记录层经 $.sys 调 resolve / write / cwd';

# ── 规模上限：拆分后不该再长回去 ─────────────────────────────────────
# 拆分前 3,250 行（0.148.0 实测）；切掉 162 行后 3,091 行。
my Int $sess-lines = $sess-text.lines.elems;
cmp-ok $sess-lines, '<', 3150,
       "Session 行数 {$sess-lines} 低于 3,150（不再把 cells 长回来）";

# ── META6 provides：新增文件必须登记（t/51 也会查，这里显式钉住）─────
my Str $meta = 'META6.json'.IO.slurp;
ok $meta.contains('"Rakuish::REPL::Session::Cells": "lib/Rakuish/REPL/Session/Cells.rakumod"'),
     'META6 provides 登记了 Cells';

# ── 运行时：role 组合后真的能用，不是只搬了文本 ─────────────────────
use Rakuish::REPL::Session;
my $out-file = $*TMPDIR.add("rakuish-t87-cells-{$*PID}.txt");
my $json-file = $*TMPDIR.add("rakuish-t87-cells-{$*PID}.json");
LEAVE {
    .unlink if .e for $out-file, $json-file;
}
my $s = Rakuish::REPL::Session.new(:snapshot-on(False));

is $s.eval-line('cells').out, '（还没有格记录）', '新会话里 cells 说没有记录';
like $s.eval-line('cells --help').out, /'用法: cells'/, 'cells --help 给用法';

is $s.eval-line('1+1').ok, True, '先求值一格（造一条记录）';
is $s.cells.elems, 1, '格记录已落进 @.cells';

my $list = $s.eval-line('cells');
ok $list.out.contains('1+1'), 'cells 列出刚求值的那一格';
ok $list.out.contains('ok'), '列表带成功状态';

# cells 自己不留痕（LEAVE { $.skip-cell = True }）
is $s.eval-line('cells').out.contains('1+1'), True, '再跑一次 cells 仍能列出（表没被清）';
is $s.cells.elems, 1, 'cells 自己没被记进格表（skip-cell 生效）';

my $json = $s.eval-line('cells --json -');
is $json.ok, True, 'cells --json - 打到 stdout';
from-json($json.out);
is from-json($json.out)<format>, 'rakuish-cells', '--json 的 format 标记正确';
is from-json($json.out)<count>, 1, '--json 的 count 与格数一致';

my $text = $s.eval-line('cells --text -');
is $text.ok, True, 'cells --text - 打到 stdout';
ok $text.out.contains('no worries;'), '--text 导出带 no worries 头（脚本模式不刷 sink 警告）';
ok $text.out.contains('1+1;'), '--text 给每格补了语句结束符';

my $to-file = $s.eval-line("cells --text {$out-file.Str}");
is $to-file.ok, True, 'cells --text <文件> 写入成功';
ok $out-file.e && $out-file.slurp.contains('1+1;'), '导出文件里确实有那格的源码';

my $to-json = $s.eval-line("cells --json {$json-file.Str}");
is $to-json.ok, True, 'cells --json <文件> 写入成功';
is from-json($json-file.slurp)<count>, 1, '写出的 JSON 也能解析';

my $bad = $s.eval-line('cells --nope');
is $bad.ok, False, '未知选项报错';
is $bad.code, 2, '未知选项的退出码是 2';

done-testing;
