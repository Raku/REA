use Test;
use Rakuish::REPL::Session;

# t/81 — store：跨会话变量库（0.139.0 / V-343 / ADR-0053，评审 P2.6）
#
# 三层要守：① 存的边界（闭包 / 资源 / 超大值必须拒绝并给理由，不能静默跳过）；
# ② 读回后是真·会话变量（%!state 里、能参与后续求值、类实例跨会话可用）；
# ③ 记账口径（命令本身不占 Out[n]，history 记一条命令行）。
#
# 路径一律走 `:store-path`（等价 `-f`），不碰用户真实的 ~/.rakuish/store.json。

my $dir = $*CWD.add('tmp');
$dir.mkdir unless $dir.e;
my $sp  = $dir.add('t81-store.json');
my $sp2 = $dir.add('t81-store-alt.json');
$sp.unlink if $sp.e;
$sp2.unlink if $sp2.e;

my $s = Rakuish::REPL::Session.new(:store-path($sp.Str));
$s.eval-line('my $x = 41');
$s.eval-line('my @rows = 1..3');
$s.eval-line('my %cfg = a => 1');
my Int $idx0 = $s.index;

# ── ① 保存与枚举
my $r = $s.eval-line('store $x @rows %cfg');
ok $r.ok, 'store 保存三个变量';
like $r.out, /'保存 3 个变量'/, '输出说明保存了几个';
ok $sp.e, '库文件已写出';
is $s.index, $idx0, 'store 命令本身不占 Out[n]';
is $s.history.List.tail, 'store $x @rows %cfg', 'history 记一条命令行';

my $rl = $s.eval-line('store -l');
ok $rl.ok, 'store -l 成功';
like $rl.out, /'$x'/, '列表里有 $x';
like $rl.out, /'@rows'/, '列表里有 @rows';
like $rl.out, /'Int'/, '列表给出类型';

# 空库的列表不是错误，而是一句说明。
my $empty = Rakuish::REPL::Session.new(:store-path($sp2.Str));
like $empty.eval-line('store -l').out, /'库是空的'/, '空库列表给出说明';

# ── ② 名字解析：带 sigil / 不带 sigil / 不唯一 / 不存在
is $s.eval-line('store x').ok, True, '不带 sigil 也能保存（$x 唯一匹配）';
my $s2 = Rakuish::REPL::Session.new(:store-path($sp.Str));
$s2.eval-line('my $v = 1');
$s2.eval-line('my @v = 2,3');
my $ramb = $s2.eval-line('store v');
nok $ramb.ok, '同名的 $v / @v 不带 sigil 时拒绝';
like $ramb.err, /'名字不唯一'/, '拒绝理由点名名字不唯一';
is $s2.eval-line('store $v').ok, True, '带 sigil 就不歧义';
nok $s2.eval-line('store $nosuch').ok, '本会话没有的变量拒绝保存';
like $s2.eval-line('store $nosuch').err, /'本会话没有变量'/, '拒绝理由说明没有该变量';

# ── ③ 存的边界：闭包 / 资源 / 超大值 —— 拒绝且说清为什么
$s2.eval-line('my $blk = -> { 42 }');
my $rc = $s2.eval-line('store $blk');
nok $rc.ok, '闭包拒绝保存';
like $rc.err, /'closure'/, '理由点名 closure';

$s2.eval-line('my $ch = Channel.new');
my $rch = $s2.eval-line('store $ch');
nok $rch.ok, 'Channel 拒绝保存';
like $rch.err, /'resource'/, '理由点名 resource';

# 单值上限走 RAKUISH_SNAPSHOT_MAX（快照与 store 共用同一口径）。
my $old = %*ENV<RAKUISH_SNAPSHOT_MAX>;
%*ENV<RAKUISH_SNAPSHOT_MAX> = '40';
$s2.eval-line('my $big = "x" x 200');
my $rbig = $s2.eval-line('store $big');
%*ENV<RAKUISH_SNAPSHOT_MAX> = $old if $old.defined;
unless $old.defined { %*ENV<RAKUISH_SNAPSHOT_MAX>:delete }
nok $rbig.ok, '超过单值上限的变量拒绝保存';
like $rbig.err, /'值过大'/, '理由说明值过大';

# 拒绝的变量不落库：库里只有前面成功保存的 $v。
my $rl2 = $s2.eval-line('store -l');
unlike $rl2.out, /'$blk'/, '被拒的变量没有进库';

# ── ④ 跨会话读回：标量 / 数组 / 哈希 / 用户类实例
my $s3 = Rakuish::REPL::Session.new(:store-path($sp.Str));
my $rr = $s3.eval-line('store -r x');
ok $rr.ok, '新会话能读回 $x';
is $s3.eval-line('$x + 1').value, 42, '读回的值是真会话变量，能参与后续求值';
my $rarr = $s3.eval-line('store -r @rows');
ok $rarr.ok, '新会话能读回 @rows';
is $s3.eval-line('@rows.elems').value, 3, '数组内容完整';
is $s3.eval-line('store -r %cfg').ok, True, '新会话能读回 %cfg（不带 sigil 也行）';

# 用户类实例：值的 `.raku` 是 `Rakuish::REPL::Session::Pt.new(...)`，
# 条目里必须带着 `my class Pt` 的声明源码，否则新会话里构造不出来。
$s3.eval-line('class Pt { has $.x; method show { "pt {$!x}" } }');
$s3.eval-line('my $p = Pt.new(:x(3))');
is $s3.eval-line('store $p').ok, True, '保存用户类实例';
my $s4 = Rakuish::REPL::Session.new(:store-path($sp.Str));
my $rp = $s4.eval-line('store -r p');
ok $rp.ok, '另一个新会话能读回用户类实例（带类声明）';
is $s4.eval-line('$p.show').value, 'pt 3', '读回的对象方法可用';
is $s4.eval-line('$p.x').value, 3, '读回的对象属性完整';

# ── ⑤ 覆盖 / 删除 / 清空
is $s4.eval-line('store $p').ok, True, '同名再存 = 覆盖';
my $rd = $s4.eval-line('store -d p');
ok $rd.ok, 'store -d 删除';
like $rd.out, /'删了 1 个变量'/, '删除输出说明删了几个';
nok $s4.eval-line('store -r p').ok, '删掉之后读不回';
like $s4.eval-line('store -r p').err, /'库里没有'/, '读不回的理由点名库里没有';
nok $s4.eval-line('store -d p').ok, '删不存在的变量不是成功';
my $rc2 = $s4.eval-line('store --clear');
ok $rc2.ok, 'store --clear 成功';
like $rc2.out, /'已清空'/, '清空给出数量说明';
like $s4.eval-line('store -l').out, /'库是空的'/, '清空之后列表为空';

# ── ⑥ 参数面：坏选项 / 模式冲突 / -l 带名字 / 空名单 / -f 换文件时默认库不动
nok $s4.eval-line('store --nope').ok, '未知选项拒绝';
like $s4.eval-line('store --nope').err, /'未知选项'/, '未知选项给出用法';
nok $s4.eval-line('store -r -d x').ok, '两个模式同时用拒绝';
like $s4.eval-line('store -r -d x').err, /'一次只能用一个模式'/, '模式冲突点名原因';
nok $s4.eval-line('store -l x').ok, '-l 不接受名字';
nok $s4.eval-line('store').ok, '不给名字拒绝保存';
nok $s4.eval-line('store -r').ok, '不给名字拒绝读回';
nok $s4.eval-line('store --clear -r').ok, '--clear 不跟模式一起用';
like $s4.eval-line('store --help').out, /'用法: store'/, 'store --help 有用法';

my $s5 = Rakuish::REPL::Session.new(:store-path($sp.Str));
$s5.eval-line('my $k = 5');
my $rf = $s5.eval-line('store -f tmp/t81-store-alt.json $k');
ok $rf.ok, '-f 指定另一个库文件';
ok $sp2.e, '-f 的文件被写出';
is $sp.e, True, '默认库文件仍在（-f 没有动它）';
my $altr = Rakuish::REPL::Session.new(:store-path($sp2.Str));
is $altr.eval-line('store -r k').ok, True, '-f 写出的库能被另一会话读回';

$sp.unlink  if $sp.e;
$sp2.unlink if $sp2.e;

done-testing;
