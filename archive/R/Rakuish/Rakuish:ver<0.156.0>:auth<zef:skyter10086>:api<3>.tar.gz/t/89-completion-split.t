use v6.d;
use Test;
use lib 'lib';

# 0.151.0 / V-355 / ADR-0065：Session 拆分第六步的**结构守卫**。
#
# 与 t/84..t/88 同一套路：不测补全行为本身（行为由 t/10 的 shell 补全、
# t/23 的 SQL 补全、t/25 的 describe 补全、t/63 的方法补全覆盖），只钉住
# 「补全这一簇真的搬进 Completion role、Session 没有又长回去」。
# 0.150.0 的 Session 是 2,868 行；这一刀切掉 203 行后是 2,672 行 ——
# 上限 2,750 允许正常增长，但不允许把补全管线写回 Session。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my IO::Path $comp = $root.add('Session/Completion.rakumod');

ok $sess.e, 'Session.rakumod 在';
ok $comp.e, '补全层文件在（Session/Completion.rakumod）';

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str $comp-text = $comp.slurp.subst("\x[FEFF]", '');

# ── 声明的形状：role + does + use ────────────────────────────────────
my Str $comp-head = $comp-text.lines.first({ .trim && !.trim.starts-with('#') }).trim;
is $comp-head, 'unit role Rakuish::REPL::Session::Completion;',
     '补全层是 unit role Rakuish::REPL::Session::Completion';

for <Commands Config Diagnostics Persistence Cells Replay> -> $r {
    like $sess-text, /"does Rakuish::REPL::Session::{$r}"/,
         "Session 仍声明 does ...{$r}（前面的拆分没被回退）";
}
like $sess-text, /'does Rakuish::REPL::Session::Completion'/,
     'Session 声明了 does ...Completion';
like $sess-text, /'use Rakuish::REPL::Session::Completion;'/,
     'Session 在 unit 之前 use 了 Completion（否则 does 解析不到）';

# ── 反方向：补全管线不许留在 Session ─────────────────────────────────
for <completions session-name-completions method-completions
     completion-value resolve-type> -> $m {
    my Str $sig = 'method ' ~ ($m.starts-with('!') ?? $m !! '!' ~ $m) ~ '(';
    # 公开的 completions 没有 `!` 前缀，单独处理
    my Str $sig2 = $m eq 'completions' ?? 'method completions(' !! $sig;
    nok $sess-text.contains($sig2), "$m 不在 Session（否则就是又长回去了）";
    ok $comp-text.contains($sig2), "$m 在补全层";
}

# ── 错误态标红留在 Session：它跟补全只是都读 @.decls，不是同一条管线 ──
for <error-marks !known-name !path-names> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    ok $sess-text.contains($sig), "$m 留在 Session（错误态标红用）";
    nok $comp-text.contains($sig), "$m 不在补全层";
}

# ── 类型缓存：属性留 Session，role 拿活容器 ──────────────────────────
ok $sess-text.contains('has %!type-cache;'), '类型缓存仍是 Session 的私有属性';
ok $sess-text.contains('method !type-cache(--> Hash)'),
   'Session 提供 !type-cache 活容器入口（私有，不是公开 API）';
ok $comp-text.contains('self!type-cache'), '补全层经 self!type-cache 拿缓存';
ok $sess-text.contains('%!type-cache = %()'), '新 use 时清空缓存的那句仍在 Session';

# ── role 的卫生：不许碰类私有属性、不许裸 EVAL ───────────────────────
nok $comp-text ~~ /<[$@%&]>\!<[A..Za..z]>/, '补全层没有任何类私有属性引用';
ok $comp-text.contains('self!eval-in-session'),
   '类型解析的 EVAL 走 Session 的 !eval-in-session（ADR-0062 §3）';
nok $comp-text.contains(' EVAL "'), '补全层没有裸 EVAL（会把用户声明落到 role 包名下）';
for <Complete Methods SqlComplete> -> $m {
    ok $comp-text.contains("use Rakuish::REPL::{$m};"),
       "补全层自己 use 了 {$m}（Session 的 use 不泄漏进 role）";
}

# ── 规模上限：拆分后不该再长回去 ─────────────────────────────────────
my Int $sess-lines = $sess-text.lines.elems;
cmp-ok $sess-lines, '<', 2750,
       "Session 行数 {$sess-lines} 低于 2,750（不再把补全层长回来）";
cmp-ok $sess-lines, '>', 2200,
       "Session 行数 {$sess-lines} 仍大于 2,200（防空跑：文件没被截断）";

# ── META6 provides：新增文件必须登记（t/51 也会查，这里显式钉住）─────
my Str $meta = 'META6.json'.IO.slurp;
ok $meta.contains('"Rakuish::REPL::Session::Completion": "lib/Rakuish/REPL/Session/Completion.rakumod"'),
     'META6 provides 登记了 Completion';

# ── 运行时：role 组合后真的能用，不是只搬了文本 ─────────────────────
use Rakuish::REPL::Session;
my $s = Rakuish::REPL::Session.new(:snapshot-on(False));

ok $s.^can('completions').elems > 0, 'Session 实例上有 completions（role 组合生效）';

# 内置例程补全（!session-name-completions 的上下文 3）
is $s.completions('pri', 3).List.grep(* eq 'print').elems, 1,
   '内置例程补全：pri → print';

# 会话变量补全（%!state → %.state）
$s.eval-line('my $alice = 5;');
is $s.completions('$ali', 4).List.grep(* eq '$alice').elems, 1,
   '会话变量补全：$ali → $alice';

# 数组 / sub 带 sigil 的形式
$s.eval-line('my @rows = 1, 2, 3;');
is $s.completions('@ro', 3).List.grep(* eq '@rows').elems, 1,
   '数组补全也带 sigil';
$s.eval-line('sub frob { 1 }');
is $s.completions('&fro', 4).List.grep(* eq '&frob').elems, 1,
   '& 补全给出 &sub';

# use 语句上下文（模块名补全）
is $s.completions('use JSON', 8).List.grep(* eq 'use JSON::Fast').elems, 1,
   'use 上下文补出模块名';

# 方法名补全（!method-completions → !completion-value → !resolve-type 全链）
$s.eval-line('class Box { method hi { 42 } }');
my @meth = $s.completions('Box.', 4).List;
ok @meth.grep(* eq 'Box.hi').elems >= 1, '类型名后的方法补全走通整条链';
ok @meth.grep(* eq 'Box.clone').elems >= 1, '类型对象本身的方法也在候选里';

# In[n] / Out[n] 引用补全（@.out 与 @.history 的口径不同）
$s.eval-line('1 + 1');
$s.eval-line('say 3');
ok $s.completions('Out[', 4).List.grep(* eq 'Out[1]').elems == 1,
   'Out[n] 引用补全（@.out）';
ok $s.completions('In[', 3).List.grep(* eq 'In[1]').elems == 1,
   'In[n] 引用补全（@.history）';

# 空行 / 纯空白不该崩（契约：永远返回 List）
my @blank = $s.completions('', 0).List;
ok @blank ~~ List, '空行补全返回 List（不崩、不返回 Nil）';

done-testing;
