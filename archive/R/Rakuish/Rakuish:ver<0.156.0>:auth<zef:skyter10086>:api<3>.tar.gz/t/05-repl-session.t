use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::REPL::Session;

# Phase 3 · V3 REPL 会话（ADR-0001 §2.3）
# 反向断言是重点：没有 magic 分流、没有 auto-shell 回退、没有反引号 shellq、
# ! 不解释任何 shell 元字符 —— 唯一的例外是顶层、引号外的 `|`（0.143.0 /
# V-347 引擎内管道，ADR-0056）。

my $R = $*EXECUTABLE.Str;

# ── 两类输入：Raku 与 ! argv ────────────────────────────────────────
my $s = Rakuish::REPL::Session.new;
my $r = $s.eval-line('1 + 1');
ok $r.ok, 'Raku 表达式求值成功';
is $r.value, 2, '表达式值';
is $r.op, 'eval', 'op = eval';
is $s.index, 1, '格号递增';

# ── % 开头一律按 Raku，不是 magic ───────────────────────────────────
$s.eval-line('my %h = a => 7;');
my $hp = $s.eval-line('%h<a>');
ok $hp.ok, '% 开头成功求值';
is $hp.value, 7, '%h<a> 是 Raku 哈希访问';
nok $hp.err.contains('未知 magic'), '没有 magic 分流';
is $hp.op, 'eval', 'op 仍是 eval，不是 magic';

my $unknown-magic = $s.eval-line('%not-a-command');
nok $unknown-magic.ok, '未知 %xxx 是 Raku 编译错误';
ok $unknown-magic.err.contains('%not-a-command')
   || $unknown-magic.err.chars > 0, '错误信息来自 Raku 编译器';

# ── 没有 auto-shell 回退 ────────────────────────────────────────────
my $g = $s.eval-line('git status');
nok $g.ok, 'git status 求值失败（不猜、不回退）';
ok $g.err.contains('git'), '错误来自 Raku 未声明例程';
nok $g.out.contains('On branch'), '没有偷偷执行外部 git';
is $g.op, 'eval', '失败格仍是 eval';

# ── 副作用只执行一次（不能整份历史重 EVAL）────────────────────────
my $side-dir = $*TMPDIR.IO.add("rakuish-side-{$*PID}");
$side-dir.mkdir;
LEAVE { try { $side-dir.dir>>.unlink; $side-dir.rmdir } }
my $side = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
$side.eval-line('append("log.txt", "one\n")');
$side.eval-line('1 + 1');
$side.eval-line('2 + 2');
is $side-dir.add('log.txt').lines.elems, 1, 'REPL 后续格不重放 append 副作用';
$side.eval-line('my $x = append("log.txt", "two\n");');
$side.eval-line('3 + 3');
is $side-dir.add('log.txt').lines.elems, 2,
    '声明初始化里的 append 也只执行一次';

# ── 顶层 my/数组/哈希跨格持久，且是同一容器 ───────────────────────
my $st = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
$st.eval-line('my $x = 1;');
$st.eval-line('$x = 5;');
is $st.eval-line('$x + 1').value, 6, 'my 标量跨格保留修改';
$st.eval-line('my @a = (1, 2);');
$st.eval-line('@a.push(3);');
is $st.eval-line('@a.elems').value, 3, 'my 数组跨格是同一容器';
$st.eval-line('my %h = a => 1;');
$st.eval-line('%h<b> = 2;');
is $st.eval-line('%h.keys.sort.join(",")').value, 'a,b',
    'my 哈希跨格保留新增键';
$st.eval-line('my $word = "my fake";');
is $st.eval-line('$word').value, 'my fake',
    '字符串里的 my 不被扫描器误当声明';

# ── set -e / strict：失败格请求退出 ─────────────────────────────────
my $strict = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
ok $strict.eval-line('set -e').ok, 'set -e 成功';
ok $strict.strict, 'set -e 打开 strict';
my $bad = $strict.eval-line('ls definitely-missing');
nok $bad.ok, 'strict 下失败命令仍返回错误 Result';
ok $strict.exit-requested, 'strict 下失败请求退出';
is $strict.exit-code, 1, 'strict 退出码为 1';
my $loose = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
$loose.eval-line('set -e');
$loose.eval-line('set +e');
nok $loose.eval-line('ls definitely-missing').ok, 'set +e 后普通失败仍返回错误';
nok $loose.exit-requested, 'set +e 后不请求退出';

my $bang = $loose.eval-line('! echo "unterminated');
nok $bang.ok, '! 未闭合引号不执行';
is $bang.code, 127, '! 未闭合引号返回 127';
like $bang.err, /'引号'/, '! 未闭合引号有明确错误';

# ── _ / Out[n] / cmd 桥 ─────────────────────────────────────────────
my $oo = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
is $oo.eval-line('1 + 1').value, 2, '第一格值';
is $oo.eval-line('_ + 1').value, 3, '_ 指向上一格';
is $oo.eval-line('Out[1]').value, 2, 'Out[1] 是第一格';
is $oo.eval-line('Out[2]').value, 3, 'Out[2] 是第二格';

my $ls-out = $oo.eval-line('ls --json .');
isa-ok $ls-out.value, Rakuish::Data::Table, 'ls --json 值是 Table';
is $oo.eval-line('_.elems').value, $ls-out.value.elems,
    '_ 可接上一格 shell 结果';
is $oo.eval-line('cmd("ls --json .").elems').value,
    $ls-out.value.elems, 'cmd 桥返回结构化 Table';

my $badcmd = $oo.eval-line('cmd("definitely-missing")');
nok $badcmd.ok, 'cmd 失败不返回成功';
like $badcmd.err, /'失败'/, 'cmd 失败有明确错误';

# ── 历史替换 ─────────────────────────────────────────────────────────
my $hs = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
is $hs.eval-line('3 + 4').value, 7, '历史替换前置';
is $hs.eval-line('!!').value, 7, '!! 重跑上一条';
is $hs.eval-line('5 + 6').value, 11, '历史替换第二条';
is $hs.eval-line('!1').value, 7, '!1 取第 1 条';
is $hs.eval-line('!$').value, 4, '!$ 取上一条最后参数';
nok $hs.eval-line('!999').ok, '越界历史项报错';

# ── config / alias ──────────────────────────────────────────────────
my $cfg-path = $*TMPDIR.add("rakuish-cfg-{$*PID}.json");
%*ENV<RAKUISH_CONFIG> = $cfg-path.Str;
my $cfg = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
ok $cfg.eval-line('alias e=echo hi').ok, '设置 alias';
is $cfg.eval-line('e').out.trim, 'hi', 'alias 展开后执行';
# config 是通用 KV 存取；用中性键测持久化，别拿一个入口根本不读的键
# （旧示例 `theme`）当特性示例 —— 那样只会制造「能存 = 生效」的假绿。
ok $cfg.eval-line('config set probe-key dark').ok, '设置 config';
is $cfg.eval-line('config get probe-key').out.trim, 'dark', '读取 config';
ok $cfg.eval-line('unalias e').ok, '删除 alias';
ok $cfg.eval-line('alias check=echo ok').ok, 'alias 写入后仍可设置';
ok $cfg-path.e, 'config 文件已落盘';
my $cfg2 = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($side-dir), :cwd($side-dir)));
is $cfg2.eval-line('config get probe-key').out.trim, 'dark', '新会话加载 config';
ok $cfg2.eval-line('hook add start echo hook-ok').ok, '添加启动 hook';
is $cfg2.run-hooks('start').map(*.out).join('|').trim, 'hook-ok',
    'run-hooks 执行 start';
is $cfg2.eval-line('hook run start').out.trim, 'hook-ok', 'hook run start';
ok $cfg2.eval-line('hook clear start').ok, '清除启动 hook';
is $cfg2.run-hooks('start').elems, 0, '清除后无 hook';
%*ENV<RAKUISH_CONFIG>:delete;

# ── 多 Session：DSL 必须落到各自动态 Sys ────────────────────────────
my $da = $*TMPDIR.IO.add("multi-a-{$*PID}"); $da.mkdir;
my $db = $*TMPDIR.IO.add("multi-b-{$*PID}"); $db.mkdir;
$da.add('which.txt').spurt('A');
$db.add('which.txt').spurt('B');
my $sa = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($da), :cwd($da)));
my $sb = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($db), :cwd($db)));
is $sa.eval-line('read("which.txt")').value, 'A', 'Session A DSL';
is $sb.eval-line('read("which.txt")').value, 'B', 'Session B DSL';
is $sa.eval-line('read("which.txt")').value, 'A', '再次调用 A 不串到 B';

# ── shell 习惯的裸路径参数：cd .. / ls .. / stat . ─────────────────
my $sd = $*TMPDIR.IO.add("rakuish-shellish-{$*PID}");
my $sd-sub = $sd.add('sub'); mkdir $sd; mkdir $sd-sub;
LEAVE { try { $sd-sub.dir>>.unlink; $sd.dir>>.unlink; $sd-sub.rmdir; $sd.rmdir } }
my $sh = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($sd), :cwd($sd-sub)));
my $cd-dotdot = $sh.eval-line('cd ..');
ok $cd-dotdot.ok, 'cd .. 按 shell 习惯解析';
is $sh.sys.cwd.Str.subst('\\', '/', :g), $sd.Str.subst('\\', '/', :g),
    'cd .. 真的切到父目录';
ok $sh.eval-line('ls sub').ok, 'ls 裸路径参数按 shell 习惯解析';
ok $sh.eval-line('stat .').ok, 'stat . 按 shell 习惯解析';

# ── 默认 REPL 是文件系统根，不是启动 cwd ───────────────────────────
my $default = Rakuish::REPL::Session.new;
my $up = $default.eval-line('cd(".."); sys.cwd.Str');
ok $up.ok, '默认 REPL 可 cd 到父目录';
nok $up.err.contains('路径越出 root'), '默认 REPL root 不是启动 cwd';

# ── 多 Session：DSL 跟随当前求值会话，不串最后一个 bind-session ─────
my $d1 = $*TMPDIR.IO.add("rakuish-s1-{$*PID}"); $d1.mkdir;
my $d2 = $*TMPDIR.IO.add("rakuish-s2-{$*PID}"); $d2.mkdir;
LEAVE { try { $d1.dir>>.unlink; $d2.dir>>.unlink; $d1.rmdir; $d2.rmdir } }
my $s1 = Rakuish::REPL::Session.new(sys => Rakuish::Sys.new(:root($d1), :cwd($d1)));
my $s2multi = Rakuish::REPL::Session.new(sys => Rakuish::Sys.new(:root($d2), :cwd($d2)));
$s1.eval-line('write("only-s1.txt", "S1")');
$s2multi.eval-line('write("only-s2.txt", "S2")');
is $s1.eval-line('read("only-s1.txt")').value, 'S1',
    '先创建的 Session 的 DSL 仍绑定自己的 Sys';
is $s2multi.eval-line('read("only-s2.txt")').value, 'S2',
    '后创建的 Session 的 DSL 绑定自己的 Sys';

# ── 纯 sub / use 声明跨格；只要声明，不重放其它语句 ─────────────────
my $decl = Rakuish::REPL::Session.new(
    sys => Rakuish::Sys.new(:root($d1), :cwd($d1)));
$decl.eval-line('sub twice($x) { $x * 2 }');
is $decl.eval-line('twice(21)').value, 42, '纯 sub 声明跨格可用';
$decl.eval-line('use JSON::Fast;');
ok $decl.eval-line('to-json({ a => 1 }).contains("a")').value,
    '纯 use 声明跨格可用';

# ── 没有反引号 shellq ───────────────────────────────────────────────
my $bq = $s.eval-line('`echo pwned`');
nok $bq.ok, '反引号不再被解释成 shell 捕获';
nok $bq.out.contains('pwned'), '没有执行 shell';

# 行首 != 是 Raku 运算符，不是 argv 入口
my $ne = $s.eval-line('!= 1');
is $ne.op, 'eval', '行首 != 按 Raku 处理';

# ── ! argv 分词：元字符原样、引号保护空格 ───────────────────────────
my $s2 = Rakuish::REPL::Session.new;
my $argv-line = q{! } ~ $R ~ q{ -e "say @*ARGS.raku" 'a|b' 'x y'};
my $ar = $s2.eval-line($argv-line);
ok $ar.ok, '! 执行外部程序成功';
ok $ar.out.contains('a|b'), '| 原样当参数，不被解释';
ok $ar.out.contains('x y'), '引号内空格被保留';
is $ar.op, 'exec', 'op = exec';

# 0.143.0 / V-347：顶层、引号外的 | 是管道（ADR-0056）——
# 段间真串流（第 2 段读到第 1 段的 stdout），不是单条 argv 里的普通字符。
my $pipe = $s2.eval-line(
    '! ' ~ $R ~ q{ -e "print 'ab'" | } ~ $R ~ q{ -e "print slurp.uc"});
ok $pipe.ok, '顶层 | 组成管道并执行成功';
is $pipe.out.trim, 'AB', '管道串联 stdout：末段读到前段输出';
is $pipe.value<pipeline>, True, 'value<pipeline> = True';
is $pipe.value<stages>.elems, 2, '两段都在 value<stages> 里';

my $empty = $s2.eval-line('!');
nok $empty.ok, '空 ! 报错';
is $empty.code, 127, '空 ! code = 127';
ok $empty.err.contains('没有命令'), 'err 说明原因';

# ── 跨格 my / 多行续行 / stdout delta ───────────────────────────────
my $s3 = Rakuish::REPL::Session.new;
is $s3.eval-line('my $x = 41;').value, 41, '第一格声明 my';
is $s3.eval-line('$x + 1').value, 42, 'my 跨格持久';
my $mo = $s3.eval-line('my @a = (');
is $mo.op, 'more', '括号未配平进入续行';
is $mo.value, 1, '续行缓冲 1 行';
my $fin = $s3.eval-line('1, 2); @a.elems');
ok $fin.ok, '续行合并后求值';
is $fin.value, 2, '续行结果正确';
my $say1 = $s3.eval-line('say "once 中文"');
is $say1.out.trim, 'once 中文', 'say 输出可见';
my $say2 = $s3.eval-line('1');
is $say2.out.trim, '', '历史 say 不重复回显（delta 去重）';

# ── EVAL 内的 sys / repl / registry / DSL ───────────────────────────
my $s4 = Rakuish::REPL::Session.new;
$s4.eval-line('1');
$s4.eval-line('2');
my $h = $s4.eval-line('repl.history.elems');
is $h.value, 2, 'EVAL 内可访问 repl.history';
my $cw = $s4.eval-line('sys.cwd.Str.chars > 0');
is $cw.value, True, 'EVAL 内可访问 sys';
my $rg = $s4.eval-line('registry.names.elems');
is $rg.value, 13, 'EVAL 内可访问 registry';
my $hlp = $s4.eval-line('help().elems');
ok $hlp.value > 30, 'DSL 短 sub 在 REPL 表达式里可见';
my $tr = $s4.eval-line('repl.trace = True');
ok $tr.ok, 'repl 状态可在 EVAL 内赋值';
ok $s4.trace, 'repl.trace 真的被改了';

# ── 快捷键：纯交互动作不占文本命令 ─────────────────────────────────
is $s4.key-bindings.elems, 9, '按键绑定表 9 项（0.100 加建议/菜单/检索键）';
is $s4.handle-key('Ctrl-C').value, 'interrupted', 'Ctrl-C 中断';
ok $s4.interrupt-requested, '中断标记置位';
is $s4.handle-key('Ctrl-D').value, 'exit', 'Ctrl-D 退出';
ok $s4.exit-requested, '退出标记置位';
my $sr = $s4.handle-key('Ctrl-R', :query('1'));
ok $sr.value.elems >= 1, 'Ctrl-R 搜到含 1 的历史';
ok $s4.handle-key('Up').value.chars > 0, 'Up 取回历史';
nok $s4.handle-key('Ctrl-X Ctrl-E').ok, '外部编辑器按键未绑定（V-125 硬边界）';
nok $s4.handle-key('F99').ok, '未绑定按键失败';

# ── exit 与渲染 ─────────────────────────────────────────────────────
my $s5 = Rakuish::REPL::Session.new;
my $ex = $s5.eval-line('exit 3');
is $ex.op, 'exit', 'exit 映射为退出请求（不杀进程）';
ok $s5.exit-requested, '退出标记置位';
is $s5.exit-code, 3, 'exit N 保留退出码';
nok $s5.render($ex).contains('Out['), 'exit 不渲染假的 Out[n]';

my $s6 = Rakuish::REPL::Session.new;
my $rr = $s6.eval-line('42');
ok $s6.render($rr).contains('Out[1] = 42'), 'render 输出 Out[n]';
my $skip = $s6.eval-line('   ');
is $skip.op, 'skip', '空行被跳过';

# 内置命令返回的是 Result 时，REPL 展示它的 text 渲染，而不是 Result 的 raku 结构
my $inner = Result.new(:ok, :out("done\n"), :op<read>);
my $outer = Result.new(:ok, :op<eval>, :value($inner));
my Str $rendered = $s6.render($outer);
is $rendered, 'done', 'REPL 内置 Result 优先显示 stdout';
nok $rendered.contains('Result.new'), '不展示 Result 的 raku 结构';

my $struct = Result.new(:ok, :value({ a => 1 }));
my $struct-outer = Result.new(:ok, :op<eval>, :value($struct));
like $s6.render($struct-outer), /^ 'ok: true'/, '无 stdout 的内置 Result 回退 text';

# ls / glob / recent 返回 List[IO::Path]：展示成 shell 风格的名字，而不是 IO::Path 对象
my $paths = [$*CWD.add('README.md'), $*CWD.add('META6.json')];
my $ls-result = Result.new(:ok, :op<eval>, :value($paths));
my Str $ls-text = $s6.render($ls-result);
like $ls-text, /'README.md'/, 'List[IO::Path] 显示 basename';
like $ls-text, /'META6.json'/, 'List[IO::Path] 多个文件都显示';
nok $ls-text.contains('IO::Path'), '不显示 IO::Path 的 raku 结构';
nok $ls-text.contains($*CWD.Str), '不显示绝对路径前缀';

my $one-path = Result.new(:ok, :op<eval>, :value($*CWD));
is $s6.render($one-path), $*CWD.Str, '单个 IO::Path 直接显示路径';

# ── 长会话：前奏按需裁剪（0.131.0 / §4.9l）──────────────────────────
# 评审实测：40 个 sub 后每格 ~109 ms（干净会话 ~5 ms）—— 每格把所有声明和
# `%STATE` 别名重新编译一遍。现在别名与声明都只为「本格点名」的东西生成，
# 依赖按「声明源码里点了谁」做传递闭包。这里断言机制本身（计数），不靠计时，
# 免得 CI 抖动。
{
    my $long = Rakuish::REPL::Session.new;
    for 1..40 -> $i { $long.eval-line("sub lf{$i} \{ $i \}") }
    $long.eval-line('1 + 1');
    is $long.prelude-decls, 0, '长会话：无关格子不重放任何声明';
    is $long.eval-line('lf40()').value, 40, '点名时才重放，值仍然正确';
    is $long.prelude-decls, 1, '只重放被点名的那一条声明';
}
{
    my $long = Rakuish::REPL::Session.new;
    for 1..40 -> $i { $long.eval-line("my \$lv{$i} = $i;") }
    $long.eval-line('1 + 1');
    is $long.prelude-aliases, 0, '长会话：无关格子不生成变量别名';
    is $long.eval-line('$lv1 + $lv40').value, 41, '点名的会话变量仍然可见';
    is $long.prelude-aliases, 2, '只为点名的两个变量生成别名';
}
{
    # 传递闭包：ch() 的源码里点了 cg，重放 ch 时必须连 cg 一起，否则
    # 编译期就 Undeclared routine（这正是不能只按「本格点名」裁的原因）。
    my $c = Rakuish::REPL::Session.new;
    $c.eval-line('sub cg { 5 }');
    $c.eval-line('sub ch { cg() * 2 }');
    is $c.eval-line('ch()').value, 10, '依赖被一并重放（闭包）';
    is $c.prelude-decls, 2, '闭包选中 h + g 两条';
}
{
    # `use` 是编译期导入，必须一直重放；否则后面的格子看不见导入的名字。
    my $u = Rakuish::REPL::Session.new;
    $u.eval-line('use Rakuish::Data::Table');
    $u.eval-line('1 + 1');
    ok $u.prelude-decls >= 1, 'use 声明总是重放';
    my $ok = $u.eval-line('Rakuish::Data::Table.new(:columns(), :rows()).rows.elems').ok;
    ok $ok, '导入的类型跨格可用';
}
{
    # 类的依赖同理；值本身不靠重放它的类也能调方法（方法在编译期已绑定）。
    my $k = Rakuish::REPL::Session.new;
    $k.eval-line('class LA { method hi { "A" } }');
    $k.eval-line('class LB { has LA $.a; method hi { $!a.hi ~ "B" } }');
    $k.eval-line('1 + 1');
    is $k.prelude-decls, 0, '与类型无关的格子不重放类声明';
    is $k.eval-line('LB.new(:a(LA.new)).hi').value, 'AB', '类依赖按点名重放';
    is $k.prelude-decls, 2, 'LB 与它依赖的 LA 一起重放';
}

{
    # 0.136.1 / V-340：格内 prompt() 必须真的走 input-handler，而且**不能**把
    # 提示文案 print 进本格的捕获缓冲（内建 prompt 是 `print $msg; $*IN.get`，
    # 所以格里 shadow 了它，把文案交给 _RakuishIn.prompt）。
    my @asked;
    my $p = Rakuish::REPL::Session.new;
    $p.input-handler = -> Str $msg = '' { @asked.push($msg); 'raku' };
    my $r = $p.eval-line('my $n = prompt "name? "; "hi, $n"');
    ok $r.ok, '格内 prompt 正常返回（不递归、不挂死）';
    like $r.text, /'hi, raku'/, 'prompt 拿到的值进了表达式结果';
    is @asked.join('|'), 'name? ', 'handler 收到提示文案（不是空串）';
    nok $r.out.contains('name? '), '提示文案没有混进该格的 stdout 捕获';
    # 一格里连续两次 prompt：每次都要独立的往返，值不能串。
    my $m = $p.eval-line('my $a = prompt "a? "; my $b = prompt "b? "; $a ~ "/" ~ $b');
    like $m.text, /'raku/raku'/, '一格两次 prompt 各取各的值';
    is @asked.join('|'), 'name? |a? |b? ', '两次提问的文案依次送到 handler';
    # 纯 `$*IN.get` 仍然可用（不经 prompt），且不受 shadow 影响。
    is $p.eval-line('$*IN.get').value, 'raku', '裸 $*IN.get 也走同一个 handler';
}

{
    # 0.138.0 / V-342：块输入 paste（评审 P1.4）。读行直到 `--` / EOF，
    # 累积成**一个格**——这正是它存在的理由：带空行与缩进的 class / 多行
    # for 一次执行，而不是被续行状态机切成碎片。
    my $b = Rakuish::REPL::Session.new;
    my @feed = ('class PA {', '    has $.x;', '', '    method hi { "hi {$!x}" }', '}', '--');
    $b.read-line = -> { @feed.elems ?? @feed.shift !! Nil };
    my $r = $b.eval-line('paste');
    ok $r.ok, 'paste 成功执行整段块';
    is $b.history.elems, 1, '粘贴的 N 行只记 1 条 history（不是 N 条）';
    like $b.history[*-1], /'class PA'/, 'history 记的是整段源码';
    is $b.eval-line('PA.new(:x(9)).hi').value, 'hi 9',
        '纯声明块经 paste 之后跨格可用（与单行声明同一条持久化路径）';
    is $b.index, 1, 'paste 只占一个格号';

    # 终止行 `--` 本身不进格；EOF 也终止（且不报错）。
    my $t2 = Rakuish::REPL::Session.new;
    my @f2 = ('my $pv = 5', '--', 'my $after = 9');
    $t2.read-line = -> { @f2.elems ?? @f2.shift !! Nil };
    ok $t2.eval-line('paste').ok, '以 -- 收尾的 paste 成功';
    is $t2.eval-line('$pv').value, 5, '-- 之前的内容进了同一个格';
    nok $t2.eval-line('$after').ok, '-- 终止后剩余行没有被 paste 吃掉';

    # 空块：明确失败，不占格号、不污染 history。
    my $t3 = Rakuish::REPL::Session.new;
    $t3.read-line = -> { Nil };
    my $r3 = $t3.eval-line('paste');
    nok $r3.ok, 'EOF 立即结束的 paste 是失败';
    like $r3.err, /'没有读到内容'/, '空 paste 的报错说清怎么结束';
    is $t3.index, 0, '空 paste 不占格号';
    # 失败时没有块可记，但用户确实敲了 `paste` —— 与其它失败命令一致，
    # 只记这一行（成功的情况记的是整段源码，而不是 `paste` 这个命令名）。
    is $t3.history.elems, 1, '空 paste 只留命令本身一条 history';

    # 不完整块：拒绝而不是丢给 EVAL，且会话之后照常可用。
    my $t4 = Rakuish::REPL::Session.new;
    my @f4 = ('class PB {',);
    $t4.read-line = -> { @f4.elems ?? @f4.shift !! Nil };
    nok $t4.eval-line('paste').ok, '括号没闭合的块被拒绝';
    is $t4.eval-line('1 + 1').value, 2, '拒绝之后会话仍然可用';

    # 参数与帮助：不接受参数（免得把用户误敲的东西当源码），--help 有文案。
    like $t4.eval-line('paste foo').err, /'不接受参数'/, 'paste 不接受参数';
    like $t4.eval-line('paste --help').out, /'用法: paste'/, 'paste --help 有用法';

    # 引擎 / notebook 模式：stdin 是协议流，明确拒绝而不是读协议帧当源码。
    my $e = Rakuish::REPL::Session.new;
    $e.input-handler = -> Str $msg = '' { 'x' };
    my $re = $e.eval-line('paste');
    nok $re.ok, '引擎模式下 paste 不可用';
    like $re.err, /'协议流'/, '拒绝原因点名协议流';
}

done-testing;
