use v6.d;
use Test;
use lib 'lib';
use Rakuish::Result;   # Result 是 Rakuish::Result 模块导出的类

# 0.152.0 / V-356 / ADR-0066：Session 拆分第七步的**结构守卫**。
#
# 与 t/84..t/89 同一套路：不重测 `!` 命令的行为（那是 t/10 的 cmd 内建、
# t/44 的流式与超时、t/83 的管道与透传的活），只钉住两件事：
#   1. `!` 分发这一簇真的搬进 Exec role，Session 没有又长回去；
#   2. role 组合后这一簇仍然可用（不是只搬了文本）。
# 0.151.0 的 Session 是 2,679 行；这一刀切掉 313 行后约 2,368 行。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my IO::Path $exec = $root.add('Session/Exec.rakumod');

ok $sess.e, 'Session.rakumod 在';
ok $exec.e, '`!` 分发层文件在（Session/Exec.rakumod）';

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str $exec-text = $exec.slurp.subst("\x[FEFF]", '');

# ── 声明的形状：role + does + use ────────────────────────────────────
my Str $exec-head = $exec-text.lines.first({ .trim && !.trim.starts-with('#') }).trim;
is $exec-head, 'unit role Rakuish::REPL::Session::Exec;',
     '`!` 分发层是 unit role Rakuish::REPL::Session::Exec';

for <Commands Config Diagnostics Persistence Cells Replay Completion> -> $r {
    like $sess-text, /"does Rakuish::REPL::Session::{$r}"/,
         "Session 仍声明 does ...{$r}（前面的拆分没被回退）";
}
like $sess-text, /'does Rakuish::REPL::Session::Exec'/,
     'Session 声明了 does ...Exec';
like $sess-text, /'use Rakuish::REPL::Session::Exec;'/,
     'Session 在 unit 之前 use 了 Exec（否则 does 解析不到）';

# ── 反方向：`!` 分发不许留在 Session ─────────────────────────────────
nok $sess-text.contains('method !dispatch-bang('),
    '!dispatch-bang 不在 Session（否则就是又长回去了）';
ok $exec-text.contains('method !dispatch-bang('),
   '!dispatch-bang 在 `!` 分发层';
ok $sess-text.contains('self!dispatch-bang('),
   'Session 经 self!dispatch-bang 委派（role 组合后按名字解析）';

# ── 留在 Session 的：分词 / 补全记账 / 结果收敛 ───────────────────────
# 这些不是 `!` 一簇的私产：分词服务管道与补全，!remember / !strict-result
# 服务所有格，!emit-chunk 服务渲染。
for <!split-argv !split-pipeline !unclosed-quote !remember !strict-result
     !emit-chunk> -> $m {
    ok $sess-text.contains('method ' ~ $m ~ '('), "$m 留在 Session";
    nok $exec-text.contains('method ' ~ $m ~ '('), "$m 不在 `!` 分发层";
}

# ── role 的卫生：不许碰类私有属性、依赖自己 use ──────────────────────
nok $exec-text ~~ /<[$@%&]>\!<[A..Za..z]>/, '`!` 分发层没有任何类私有属性引用';
for (('Result', 'use Rakuish::Result;'), ('Shell', 'use Rakuish::REPL::Shell;')) -> ($m, $line) {
    ok $exec-text.contains($line),
       "`!` 分发层自己 use 了 {$m}（Session 的 use 不泄漏进 role）";
}
ok $exec-text.contains('$.sys'), '`!` 分发层经公开访问器 $.sys 执行';
ok $exec-text.contains('$.index'), '`!` 分发层经公开访问器 $.index 记账';
ok $exec-text.contains('$.stream-out'), '`!` 分发层经公开属性 $.stream-out 决定流式';
ok $exec-text.contains('self.pipe-handler'), '父进程管道执行器经公开访问器取';
ok $exec-text.contains('self.tty-handler'), 'TTY 执行器经公开访问器取';
ok $exec-text.contains('--> Any'), '入口返回 Any：Nil = 不是 ! 命令（!= / !~~ 落回 Raku）';
ok $exec-text.contains('Nil'), '未命中的分支明确返回 Nil，不吞掉 Raku 运算符';

# ── 规模上下限：拆分后不该再长回去，也不能被截断 ─────────────────────
my Int $sess-lines = $sess-text.lines.elems;
cmp-ok $sess-lines, '<', 2450,
       "Session 行数 {$sess-lines} 低于 2,450（不再把 `!` 分发长回来）";
cmp-ok $sess-lines, '>', 2200,
       "Session 行数 {$sess-lines} 仍大于 2,200（防空跑：文件没被截断）";

# ── META6 provides：新增文件必须登记（t/51 也会查，这里显式钉住）─────
my Str $meta = 'META6.json'.IO.slurp;
ok $meta.contains('"Rakuish::REPL::Session::Exec": "lib/Rakuish/REPL/Session/Exec.rakumod"'),
    'META6 provides 登记了 Exec';

# ── 运行时：role 组合后真的能用 ─────────────────────────────────────
use Rakuish::REPL::Session;
my $s = Rakuish::REPL::Session.new(:snapshot-on(False));

# 空命令与 Windows cmd 内建（$*DISTRO 分支就在 role 里）
my $empty = $s.eval-line('!');
nok $empty.ok, '! 后面没有命令是失败';
is $empty.code, 127, '空 ! 的退出码 127';

my $echo = $s.eval-line('!echo hi');
ok $echo.ok, '!echo hi 执行成功（Windows cmd 内建重写在 role 里生效）';
is $echo.out.trim, 'hi', '!echo hi 拿回 stdout';
is $echo.op, 'exec', '! 结果的 op 是 exec';

# --capture：强制捕获，不流式
my $cap = $s.eval-line('! --capture echo hi');
ok $cap.ok, '! --capture echo hi 成功';
is $cap.out.trim, 'hi', '--capture 仍拿到 stdout';
nok $cap.streamed, '--capture 的结果不是 streamed';

# 互斥与参数校验（都在 role 的元选项解析里）
my $both = $s.eval-line('! --pipe --capture echo hi');
is $both.code, 127, '--pipe 与 --capture 互斥';
like $both.err, /'互斥'/, '互斥的报错说清楚原因';

my $bad-stdin = $s.eval-line('! --stdin definitely-no-such-file-xyz echo hi');
is $bad-stdin.code, 127, '--stdin 指向不存在的文件是 127';
like $bad-stdin.err, /'不存在'/, '--stdin 的报错点名文件不存在';

my $bad-timeout = $s.eval-line('! --timeout-ms nope echo hi');
is $bad-timeout.code, 127, '--timeout-ms 非整数是 127';

# 引擎内管道（@pipe-segs > 1 的分支）。第二段必须是**两端都跑得动**的过滤器：
# `findstr` 只有 Windows 有、`grep` 只有类 Unix 有。0.155.0 这里写死 findstr，
# 于是 `zef install .` 在 Linux / WSL 上必然红（0.155.1 修）。
my Str $filter = $*DISTRO.is-win ?? 'findstr a' !! 'grep a';
my $pipe = $s.eval-line('!echo a | ' ~ $filter);
ok $pipe.ok, "!echo a | {$filter} 执行成功（管道分支在 role 里）";
is $pipe.out.trim, 'a', '管道末段的输出被捕获';

# `--tty` 走注入的执行器（不碰真终端）
my Str $tty-seen = '';
$s.tty-handler = -> $exe, @argv {
    $tty-seen = $exe.Str ~ ' ' ~ @argv.join(' ');
    Result.new(:ok, :op<tty-exec>, :out('tty-ok'));
};
my $tty = $s.eval-line('! --tty some-prog a b');
ok $tty.ok, '--tty 经注入的执行器成功';
like $tty.out, /'tty-ok'/, '--tty 用执行器的结果';
is $tty-seen, 'some-prog a b', '--tty 把 exe 与 argv 原样交给执行器';

# 透传：同样经注入的 pipe-handler，避免把内容写到测试的 stdout
my Int $pipe-seen = 0;
$s.pipe-handler = -> @stages, *%opts {
    $pipe-seen = @stages.elems;
    Result.new(:ok, :op<exec>, :out('should-be-dropped'));
};
my $pass = $s.eval-line('! --pipe echo hi');
ok $pass.ok, '! --pipe 经注入的执行器成功';
is $pipe-seen, 1, '单条命令的透传按「一段的管道」交给执行器';
is $pass.out, '', '透传的输出不在 Result 里（已直写终端）';
ok $pass.streamed, '透传的结果标 streamed，render 不会重放';

# `!=` / `!~~` 必须落回 Raku 求值，不能被当成外部命令
my $ne = $s.eval-line('!= 1');
nok ($ne.op // '') eq 'exec', '!= 落回 Raku 求值（不是外部命令）';

done-testing;
