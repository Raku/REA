use Test;
use lib 't/lib';
use Rakuish::Data::Table;
use Rakuish::Data::Duck;
use Rakuish::Result;

# ══════════════════════════════════════════════════════════════════
# 93-duck-boundary.t —— Rakuish ⟷ Duckula 的边界契约（0.155.0 / V-361 / ADR-0069）
# ══════════════════════════════════════════════════════════════════
# 两个库都在做的事，必须有明确的「谁说了算」。这个文件钉住 ADR-0069 的五条：
#   1. 空列的聚合是 NULL（不是 0），与 SQL / Duckula 同口径
#   2. SQL 报错不截断（detail 一行 + hint 后半，message 两段）
#   3. describe 有两套 schema，但它们属于两种对象（Table vs Frame）
#   4. Table 的关系代数**冻结**：不再往里加 group-by / 窗口 / pivot
#   5. 依赖地板只在一个地方定义（不再出现 0.36 / 1.2.2 这种过期数字）

# 捕获异常：`try { ... }` 拿到的是 Nil（异常被吞），要看对象必须自己 catch。
sub caught(&code) {
    my $err;
    {
        CATCH { default { $err = $_ } }
        code();
    }
    $err;
}

# ── 1. 空列聚合 = NULL ────────────────────────────────────────────
my $t = Rakuish::Data::Table.new(
    :columns(<a b>),
    :rows([{ a => 1, b => 1 }, { a => 2, b => Any }, { a => 3, b => 3 }]),
);
cmp-ok $t.sum('a'),  '==', 6, '非空列 sum 不变';
cmp-ok $t.mean('a'), '==', 2, '非空列 mean 不变';
cmp-ok $t.min('b'),  '==', 1, 'NULL 单元格被跳过：min 取有值的那个';
cmp-ok $t.max('b'),  '==', 3, 'NULL 单元格被跳过：max 取有值的那个';

my $nulls = Rakuish::Data::Table.new(
    :columns(<x>), :rows([{ x => Any }, { x => Any }]),
    :types({ x => 'num' }),
);
nok $nulls.sum('x').defined,  '整空列 sum 是 NULL（0.155.0 之前是 0e0）';
nok $nulls.mean('x').defined, '整空列 mean 是 NULL（0.155.0 之前是 0e0）';
nok $nulls.min('x').defined,  '整空列 min 是 NULL（与 sum/mean 统一，之前是 Nil）';
nok $nulls.max('x').defined,  '整空列 max 是 NULL（同上）';

my $zero-rows = Rakuish::Data::Table.new(:columns(<e>), :rows());
nok $zero-rows.sum('e').defined, '零行表的 sum 也是 NULL（不是 0）';

# ── 2. 异常带 hint ────────────────────────────────────────────────
my $plain = X::Rakuish::Data.new(:detail('只有一行'));
is $plain.message, '只有一行', '没有 hint 时 message 与 0.154.1 逐字相同';

my $two = X::Rakuish::Data.new(
    :detail('SQL 执行失败: 第一行'),
    :hint("Candidate bindings: \"a\"\nLINE 1: select nope from t"),
);
is $two.message.lines.elems, 3, 'hint 拼在 detail 后面，行数 1 + 2';
ok $two.message.starts-with('SQL 执行失败: 第一行'), 'message 仍以 detail 开头（单行消费方不受影响）';
ok $two.message.contains('Candidate bindings'), 'message 里能看到列名候选';
is $two.detail, 'SQL 执行失败: 第一行', 'detail 自己仍是一行';
is $plain.hint, Str, 'hint 未设置时是空 Str，不是必须参数';

# ── 3. describe：两套 schema 属于两种对象 ──────────────────────────
my $d = $t.describe;
is-deeply $d.columns.List, <name type nullable non_null distinct total sample>,
    'Table.describe 的 7 列 profile（不是 Duckula 的 SUMMARIZE schema）';
is-deeply $d.rows.map(*<name>).List, <a b>, 'Table.describe 逐列一行，覆盖所有列';
ok $d.columns.List.first('column_name').not.defined,
    '没有 SUMMARIZE 的 column_name —— 两套 schema 不互相冒充';

# ── 4. 关系代数冻结 ──────────────────────────────────────────────
my Str $tbl-src = 'lib/Rakuish/Data/Table.rakumod'.IO.slurp;
for <group-by having window pivot rolling> -> $m {
    nok $tbl-src.contains('method ' ~ $m), "Table 不提供 $m（冻结：关系代数归 Duckula）";
}
ok $tbl-src.contains('method sql'),
    '需要关系代数时走 .sql（唯一的逃生口）';

# ── 5. 依赖地板只有一个真相 ──────────────────────────────────────
# v0.54.0 是 Duckula 把 `columns-typed` 的签名写成硬契约的版本（形状被承诺）。
is Rakuish::Data::Duck::DUCKULA-MIN-VERSION.Str, '0.54.0',
    'Duckula 地板 = v0.54.0（columns-typed 的签名从这版起是硬契约）';
is Rakuish::Data::Duck::DUCKULA-DB-VERSION.Str, '1.4.3',
    '走 Duckula 时 DB::DuckDB 地板 = Duckula 自己 META6 的 1.4.3';
is Rakuish::Data::Duck::ENGINE-DB-VERSION.Str, '1.3.1',
    '走 Engine 直连时 DB::DuckDB 地板 = 1.3.1（decimal 修正）';

my Str $data-src = 'lib/Rakuish/Data.rakumod'.IO.slurp;
nok $data-src.contains('Duckula:ver<0.36+>'), '过期的 Duckula 地板 0.36 已清掉';
nok $data-src.contains('Duckula:ver<0.38+>'), '过期的 Duckula 地板 0.38 已清掉';
nok $data-src.contains('DB::DuckDB:ver<1.2.2+>'), '过期的 DB::DuckDB 地板 1.2.2 已清掉';
ok $data-src.contains('Duckula:ver<0.54+>'), 'Data.rakumod 的安装提示与常量同值';

my Str $duck-src = 'lib/Rakuish/Data/Duck.rakumod'.IO.slurp;
ok $duck-src.contains('DUCKULA-MIN-VERSION'), '桥的报错引用常量，不写字面量';
# 0.155.2：上游在 0.53.0 修好了 ipc-buf（TIMESTAMPTZ 三路可读），桥仍不写
# IPC，但理由已经从「上游坏了」改成「不新增耦合」。旧注释不能留。
nok $duck-src.contains('等上游修'),
    '「等上游修 ipc-buf」的旧注释已清掉（上游 0.53.0 已修）';
ok $duck-src.contains('0.53.0'),
    '桥注释记下了上游修好的版本（0.53.0），不是含糊的「已修」';

# ── 6. 与 SQL 的对齐（需要 Duckula / DuckDB）──────────────────────
my $probe = try { $t.sql('select count(*) as c from t') };
if !$probe.defined {
    skip 'Duckula / DuckDB 未安装，跳过 SQL 边界对齐测试', 8;
    done-testing;
}

my $sq = $nulls.sql('select sum(x) as s, count(*) as c from t');
nok $sq.rows[0]<s>.defined, 'SQL 的 sum 空列也是 NULL —— 与 Table.sum 同口径';
cmp-ok $sq.rows[0]<c>, '==', 2, 'count(*) 仍是 2：NULL 只影响聚合，不影响计数';

my $err = caught { $t.sql('select nope from t') };
ok $err.defined, '未知列会报错';
isa-ok $err, X::Rakuish::Data, '仍是 X::Rakuish::Data（异常族不变）';
ok $err.detail.contains('SQL 执行失败'), 'detail 带统一前缀';
nok $err.detail.contains('Candidate bindings'), 'detail 只有一行，不塞多行';
ok $err.hint.defined && $err.hint.chars > 0, 'hint 带上了后半段（0.155.0 之前被 lines[0] 截掉）';
ok $err.message.contains('Candidate bindings') || $err.message.contains('LINE 1'),
    'message 里能看到列名候选或行号';

done-testing;
