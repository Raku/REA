use Test;
use Rakuish::Sys;
use Rakuish::REPL::Session;

# t/92 —— 补全的路径面（0.154.0 / V-358）
#
# 三件事在这条测试里钉住：
#   1. `.` / `..` / `~` 三个历史洞：Rakudo 的 dir 不返回 `.`/`..`，于是
#      `cd ..<Tab>` 与 `ls .<Tab>` 永远零候选；`~/` 也没人把扫描目录换成 HOME。
#   2. 命令位要能看到当前目录的文件名（用户 cd 进目录后敲文件名，Tab 不能哑）。
#   3. 会话层合并候选时必须展平：`(@names, |@shell)` 会让首位变成 Array。

my $base = $*TMPDIR.IO.add("rakuish-comp-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }

my $pkg = $base.add('pkg');
$pkg.mkdir;
$pkg.add('alpha.raku').spurt('1');
$pkg.add('beta.txt').spurt('2');
$pkg.add('.hidden').spurt('3');
$pkg.add('Gamma.md').spurt('4');
my $sub = $pkg.add('sub');
$sub.mkdir;
$sub.add('inner.raku').spurt('5');

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my $s = Rakuish::REPL::Session.new(:sys($sys));

# ── 1. 参数位：`.` / `..` ──────────────────────────────────────────────
my @dot = $s.completions('cd .', 4);
ok @dot.grep(* eq 'cd ./').elems, '`cd .` 给出 ./';
ok @dot.grep(* eq 'cd ../').elems, '`cd .` 给出 ../';
is-deeply $s.completions('cd ..', 5).List, ('cd ../',),
    '`cd ..` 只给 ../';
ok $s.completions('cd pkg/.', 8).grep(* eq 'cd pkg/./').elems,
    '`cd pkg/.` 在子路径上同样给 ./';
is-deeply $s.completions('ls ..', 5).List, ('ls ../',),
    '`ls ..` 同理';

# ── 2. 参数位：普通条目 / 隐藏文件 ─────────────────────────────────────
my @root = $s.completions('cd ', 3);
ok @root.grep(* eq 'cd pkg/').elems, '`cd ` 列出目录（带 /）';
ok $s.completions('cat pkg/al', 10).grep(* eq 'cat pkg/alpha.raku').elems,
    '参数位补文件名';

# ── 3. 切到 pkg 之后：命令位要看得见文件名 ─────────────────────────────
my $r = $s.eval-line('cd pkg');
ok $r.ok, 'cd pkg 成功';
is $s.sys.cwd.basename, 'pkg', 'cwd 已切到 pkg';

nok $s.completions('cd ', 3).grep(*.contains('.hidden')).elems,
    '`cd ` 不列隐藏文件';
ok $s.completions('cd .h', 5).grep(* eq 'cd .hidden').elems,
    '`.` 前缀才列隐藏文件';

ok $s.completions('alpha', 5).grep(* eq 'alpha.raku ').elems,
    '命令位补出文件名（带尾随空格）';
ok $s.completions('al', 2).grep(* eq 'alpha.raku ').elems,
    '命令命中时文件名仍进候选表';
ok $s.completions('al', 2).grep(* eq 'alias ').elems, '命令本身仍在';
ok $s.completions('./alpha', 7).grep(* eq './alpha.raku ').elems,
    '`./` 前缀直接走路径';
ok $s.completions('sub/', 4).grep(* eq 'sub/inner.raku ').elems,
    '`dir/` 前缀直接走路径';
ok $s.completions('gam', 3).grep(* eq 'Gamma.md ').elems,
    '命令位文件名大小写不敏感';
nok $s.completions('cat g', 5).elems, '参数位保持大小写敏感';
is-deeply $s.completions('cd', 2).List.head(1).List, ('cd ',),
    '精确命令名仍是首位';
is-deeply $s.completions('..', 2).List, ('../',), '在 pkg 里 `..` 仍然可用';
ok $s.completions('cat a', 5).grep(* eq 'cat alpha.raku').elems,
    '参数位用新 cwd 补文件名';

# ── 4. 再切回上层：候选跟着变（文件名侧无缓存）──────────────────────────
$s.eval-line('cd ..');
is $s.sys.cwd.basename, $base.basename, 'cd .. 回到 $base';
ok $s.completions('cd ', 3).grep(* eq 'cd pkg/').elems,
    '回到 $base 后候选是 $base 的内容';
nok $s.completions('alpha', 5).grep(* eq 'alpha.raku ').elems,
    '$base 里没有 alpha.raku，候选表也变了';

# ── 5. `~` 补全：扫描 HOME，但候选保留 `~/` 前缀 ───────────────────────
if $*HOME.defined && $*HOME.d {
    my $home-sys = Rakuish::Sys.new(:root($*HOME), :cwd($*HOME));
    my $hs = Rakuish::REPL::Session.new(:sys($home-sys));
    my @home = $hs.completions('~/', 2);
    ok @home.elems > 0, '`~/` 有候选';
    ok @home.all.starts-with('~/'), '候选都保留 `~/` 前缀（不吐绝对路径）';
    is-deeply $hs.completions('~', 1).List, ('~/',), '`~` 补成 `~/`';
}
else {
    pass '无 HOME 时跳过 ~ 补全（1/3）';
    pass '无 HOME 时跳过 ~ 补全（2/3）';
    pass '无 HOME 时跳过 ~ 补全（3/3）';
}

# ── 6. `!` 模式仍然带感叹号 ────────────────────────────────────────────
ok $s.completions('! ls ', 5).grep(* eq '! ls pkg/').elems,
    '`!` 参数位补路径且保留前缀';

# ── 7. 会话层候选必须展平（`(@names, |@shell)` 会留一个 Array）──────────
my @c = $s.completions('c', 1);
ok @c.elems > 0, '`c` 有候选';
ok @c.all ~~ Str, '每个候选都是 Str（没有嵌套 Array）';
nok @c.first({ $_.WHAT ~~ Array }).defined, '没有 Array 型候选';

# ── 8. 字符串字面量里的路径（0.156.0 / V-364）──────────────────────────
$s.eval-line('cd ' ~ $base.absolute);
my @sp = $s.completions("open-data('pkg/", 15);
ok @sp.elems > 0, '字符串里的路径有候选';
ok @sp.first({ .Str eq "open-data('pkg/alpha.raku" }).defined,
    '候选把开头的引号原样拼回去';
nok $s.completions('open-data("pkg/', 15).elems,
    '双引号字符串不猜（会插值，候选全是幻觉）';
nok $s.completions("say 'hello world", 16).elems,
    '片段里有空白时不当路径补';

done-testing;
