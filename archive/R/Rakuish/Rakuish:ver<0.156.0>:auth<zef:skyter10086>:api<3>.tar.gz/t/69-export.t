use Test;
use lib 't/lib';
use JSON::Fast;
use Rakuish::REPL::Session;
use Rakuish::REPL::Shell;

# ══════════════════════════════════════════════════════════════════
# 69-export.t —— 格记录与导出（0.115.0 / V-307）
# ══════════════════════════════════════════════════════════════════
# `export` 与邻居的分工：
#   · `history` 只有输入；
#   · `log` 是人读的抄本，还受 log on/off 影响；
#   · `cells` 是结构化格记录：不带参数列出来，--text / --json 导出。
#   （不叫 `export`：那是 Shell 的 `export FOO=1`，t/10 守着。）
#
# 断言的重点是**导出的东西真的能重放**（不是「写了个文件」），以及
# 生成时的两条修补（补语句结束符、no worries）确实到位。

my $dir = $*TMPDIR.IO.add("rakuish-export-{$*PID}");
$dir.mkdir;
for $dir.dir -> $f { $f.unlink if $f.f }

my $s = Rakuish::REPL::Session.new;

# ── 1. 用法与空会话 ─────────────────────────────────────────────────
my $u = $s.eval-line('cells');
ok $u.ok, '空会话里 cells 不报错';
like $u.out, /'还没有格记录'/, '空会话如实说明没有格';

my $h = $s.eval-line('cells --help');
ok $h.ok, 'cells --help 成功';
like $h.out, /'用法: cells'/, '--help 给出用法';
ok (Rakuish::REPL::Shell.usage('cells')).chars > 0, 'Shell.usage 认识 cells';
is $s.completions('cell', 4), ('cells ',), '命令名补全认识 cells';

my $empty = $s.eval-line('cells ' ~ $dir.add('empty.raku').Str);
nok $empty.ok, '没有格时导出失败';
like $empty.err, /'还没有可导出的格'/, '错误说清楚原因';

# ── 2. 攒几格 ───────────────────────────────────────────────────────
$s.eval-line('1 + 1');
$s.eval-line('my $x = 42');
$s.eval-line('say $x');
$s.eval-line('sub twice($n) { $n * 2 }');
$s.eval-line('for 1..2 {' ~ "\n" ~ '  say twice($_)' ~ "\n" ~ '}');
$s.eval-line('die "boom"');
my Int $idx-before = $s.index;

# 不带参数 = 列表（最常用的入口）
my $list = $s.eval-line('cells');
ok $list.ok, 'cells 不带参数是列表';
like $list.out, /'共 6 格'/, '列表给总数';
like $list.out, /'1 + 1'/, '列表里有输入';
like $list.out, /'ERR'/, '失败的格标 ERR';
like $list.out, /'失败格不占 Out[n]'/, '列表脚注说明编号与 Out 号的差异';

# ── 3. --text：可重放的脚本 ─────────────────────────────────────────
my $txt-path = $dir.add('sess.raku');
my $tr = $s.eval-line('cells --text ' ~ $txt-path.Str);
ok $tr.ok, '导出 text 成功';
is $s.index, $idx-before, 'cells 不占格号';
like $tr.out, /'已导出 6 格（text）'/, '回报导出的格数';

my Str $txt = $txt-path.slurp;
like $txt, /^ '# rakuish 会话导出'/, '文件以注释头开始';
like $txt, /'6 格'/, '头里写了格数';
like $txt, /'no worries'/, '用 no worries 压住 sink 警告';
like $txt, /"1 + 1;"|"1 + 1;\n"/, '裸表达式补了语句结束符';
like $txt, /'my $x = 42;'/, '本来就带分号的格不重复补';
like $txt, /'say $x;'/, '普通语句也补';
like $txt, /'sub twice($n) { $n * 2 };'/, 'sub 声明补在最后一行';
# 用单引号拼接：双引号里 `{ ... }` 是插值块，`\$_` 会被当成代码解析（Confused）。
ok $txt.contains('for 1..2 {' ~ "\n" ~ '  say twice($_)' ~ "\n" ~ '};'),
   '多行格原样保留，分号补在收尾的 } 后';
like $txt, /'die "boom";'/, '失败的格也照原样导出';
nok $txt.contains('cells --'), '导出不含 cells 自己这一格（不自指）';

# ── 4. 重放：脚本模式 ───────────────────────────────────────────────
my $replay = run $*EXECUTABLE.Str, '-Ilib', 'bin/rakuish', $txt-path.Str, :out, :err;
my Str $r-out = $replay.out.slurp(:close);
my Str $r-err = $replay.err.slurp(:close);
is $replay.exitcode, 1, '重放里有失败格 → 退出码 1';
like $r-out, /"42\n2\n4"/, '重放跑出了 say 与循环的输出';
nok $r-err.contains('Useless use'), 'no worries 压住了 sink 警告';

# ── 5. 重放：会话模式（source）──────────────────────────────────────
my $s2 = Rakuish::REPL::Session.new;
my $sr = $s2.eval-line('source ' ~ $txt-path.Str);
nok $sr.ok, '重放时那一格 die 仍然失败（语义不粉饰）';
is $s2.eval-line('$x').value, 42, 'source 重放后变量还在';
is $s2.eval-line('twice(5)').value, 10, 'source 重放后 sub 还在';

# ── 6. --json：结构化记录 ───────────────────────────────────────────
my $jr = $s.eval-line('cells --json -');
ok $jr.ok, '导出 json 到 stdout 成功';
my $doc = from-json($jr.out);
is $doc<format>, 'rakuish-cells', '格式标签';
# 注意：`<>` 里加引号会把引号算进键名（`$doc<'format-version'>` 是别的键）。
is $doc<format-version>, 1, '格式版本';
is $doc<count>, 6, 'count 与格数一致';
is $doc<cells>.elems, 6, 'cells 数组长度一致';
ok $doc<cwd>.chars > 0, '带 cwd';

my %c1 = $doc<cells>[0];
is %c1<seq>, 1, '第一格 seq 从 1 开始';
is %c1<index>, 1, '第一格 index 是 Out[1]';
is %c1<input>, '1 + 1', '输入原样';
is %c1<op>, 'eval', 'op=eval';
ok %c1<ok>, '成功格 ok=true';
ok %c1<ms> ~~ Int, '毫秒是整数';

my %cbad = $doc<cells>[*-1];
nok %cbad<ok>, '失败格 ok=false';
is %cbad<code>, 1, '失败格 code=1';
is %cbad<input>, 'die "boom"', '失败格输入原样';

# rendered 只有前端调过 log-line 才有；没调就是空串，不是缺字段。
# （log-line 补的是**最近一格** —— 它由前端在每格结束后调一次。）
is %c1<rendered>, '', '没调 log-line 时 rendered 是空串（字段仍在）';

my $s4 = Rakuish::REPL::Session.new;
my $r4 = $s4.eval-line('1 + 1');
$s4.log-line('1 + 1', $r4, 'Out[1] = 2');
my %c4 = (from-json($s4.eval-line('cells --json -').out))<cells>[0];
is %c4<rendered>, 'Out[1] = 2', 'log-line 之后 rendered 补上了';

# ── 7. 写文件与路径 ─────────────────────────────────────────────────
my $json-path = $dir.add('sess.json');
ok $s.eval-line('cells --json ' ~ $json-path.Str).ok, '导出 json 到文件成功';
my $on-disk = from-json($json-path.slurp);
is $on-disk<count>, 6, '文件里的 count 正确';

# 相对会话 cwd 的路径
my Str $dir-slash = $dir.Str.subst(:g, "\\", '/');
$s.eval-line('cd ' ~ $dir-slash);
ok $s.eval-line('cells --text rel.raku').ok, '相对会话 cwd 的路径可用';
ok $dir.add('rel.raku').e, '文件真的写到了那个目录';

# ── 8. 参数错误 ─────────────────────────────────────────────────────
my $bad-opt = $s.eval-line('cells --yaml out.yaml');
nok $bad-opt.ok, '未知选项失败';
like $bad-opt.err, /'未知选项'/, '说明是未知选项';

my $two = $s.eval-line('cells a.raku b.raku');
nok $two.ok, '两个输出文件失败';
like $two.err, /'只接受一个输出文件'/, '说明只接受一个文件';

# ── 9. 行尾注释：分号另起一行 ───────────────────────────────────────
my $s3 = Rakuish::REPL::Session.new;
$s3.eval-line('1 + 1 # 算式');
my $cpath = $dir.add('comment.raku');
ok $s3.eval-line('cells --text ' ~ $cpath.Str).ok, '带注释的格也能导出';
like $cpath.slurp, /"1 \+ 1 # 算式\n;"/, '分号另起一行，没落进注释';

done-testing;
