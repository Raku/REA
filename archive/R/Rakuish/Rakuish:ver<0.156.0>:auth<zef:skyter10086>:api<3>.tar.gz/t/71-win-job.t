use Test;
use lib 't/lib';
use NativeCall;
use Rakuish::Eval;
use Rakuish::Sys::WinJob;

# ══════════════════════════════════════════════════════════════════
# 71-win-job.t —— Windows Job Object 与子树回收（0.117.0 / V-309）
# ══════════════════════════════════════════════════════════════════
# 要证的是 ADR-0031 里 V-905 那句「不做孙进程树回收」在 Windows 侧
# 现在做得到：引擎被 Ctrl-C 杀掉 / 重启时，它启动的前台命令与孙进程
# 一并被回收，不留孤儿。
#
# 判活用 OpenProcess（拿到句柄 = 活着），不解析 tasklist ——
# 后者受控制台代码页影响，中文 Windows 上会解码失败。

my Bool $win = $*DISTRO.is-win;
my Bool $x64 = $win && $*KERNEL.bits == 64;

sub alive(Int $pid --> Bool) {
    return False unless $pid > 0;
    my $h = Rakuish::Sys::WinJob::OpenProcess(0x1000, 0, $pid.UInt);
    return False unless $h.defined;
    Rakuish::Sys::WinJob::CloseHandle($h);
    True;
}

sub spawn-sleeper(--> Hash) {
    my $p = Proc::Async.new($*EXECUTABLE.Str, '-e', 'sleep 60', :r);
    my $done = $p.start;
    %( proc => $p, pid => $p.pid.result.Int, done => $done );
}

if !$win {
    skip "Job Object 是 Windows 专有；POSIX 侧本来就有进程组", 17;
} else {
    # ── 1. 布局：结构体尺寸错了会「静默不生效」 ──────────────────────
    ok supported(), 'Windows 上 supported 为真';
    ok layout-ok(), 'ExtendedLimitInformation 是 144 字节（x64 口径）';
    is nativesizeof(Rakuish::Sys::WinJob::ExtendedLimitInformation), 144,
       'nativesizeof 与 winnt.h 一致';

    # ── 2. 建 job / 归类 / 查询 ──────────────────────────────────────
    my $job = create();
    ok valid($job), 'create 拿到有效句柄';

    my %s1 = spawn-sleeper();
    ok alive(%s1<pid>), '子进程先证明是活的';
    ok assign($job, %s1<pid>), 'assign 成功';
    ok in-job($job, %s1<pid>), 'IsProcessInJob 确认归类成功';

    ok terminate($job, 1), 'TerminateJobObject 成功';
    sleep 1;
    nok alive(%s1<pid>), 'TerminateJobObject 之后子进程没了（子树回收）';
    close($job);

    # ── 3. KILL_ON_JOB_CLOSE：宿主退出时不留孤儿 ─────────────────────
    my $job2 = create();
    my %s2 = spawn-sleeper();
    ok assign($job2, %s2<pid>), '第二个 job 归类成功';
    close($job2);                       # 只关句柄，不显式 terminate
    sleep 1;
    nok alive(%s2<pid>), '关掉最后一个句柄就把 job 里的进程收掉（KILL_ON_JOB_CLOSE）';

    # ── 4. 端到端：引擎的孙进程在重启时被回收 ───────────────────────
    my $c = Rakuish::Eval::Client.new(:lib($*CWD.add('lib')));
    $c.start;
    ok $c.job-active, '引擎起来后 job 已启用';

    my $pid-file = $*CWD.add("tmp/job-gc-{$*PID}.pid");
    my Str $code = 'my $p = Proc::Async.new($*EXECUTABLE.Str, "-e", "sleep 60", :r);'
                 ~ ' $p.start; ' ~ $pid-file.Str.raku ~ '.IO.spurt($p.pid.result.Str)';
    my %r = $c.request(%( cmd => 'eval', line => $code ));
    ok %r<ok>, '引擎里起的子进程被接受';
    ok $pid-file.e, '引擎把孙进程 pid 写出来了';

    my Int $gc = $pid-file.e ?? $pid-file.slurp.trim.Int !! 0;
    ok alive($gc), '孙进程先证明是活的';

    $c.restart;
    sleep 1;
    nok alive($gc), '引擎重启后孙进程被回收（原来会变孤儿）';

    $c.shutdown;
    nok $c.job-active, 'shutdown 之后 job 句柄已释放';
    $pid-file.unlink if $pid-file.e;
}

done-testing;
