use v6.d;
use Test;
use lib 'lib';

use Rakuish::REPL::Session;

# 0.118.2 / V-312：Buf / Blob 的显示摘要。
#
# 之前 `!fmt` 直接走 `.raku`，而 Buf 的 raku 是**完整元素列表**——
# `Buf.new(1..4000)` 一次就是 14k 字符，`slurp(:bin)` 一格就能把屏幕刷掉，
# 还会原样写进 `cells` 记录。这里锁住三件事：
#   1) 大缓冲区只显示「类型 + 字节数 + 前 16 字节」；
#   2) Arrow IPC 文件（ARROW1 magic）额外标注，但不解析内容；
#   3) 只改**显示**：`Out[n]` / `_` 里的值仍是原来的 Buf。

plan 16;

my $s = Rakuish::REPL::Session.new(:!color);

sub run-cell(Str $code --> Any) {
    $s.eval-line($code);
}

sub shown(Str $code --> Str) {
    $s.render(run-cell($code));
}

my $big-r = run-cell('Buf.new(1..4000)');
my Str $big = $s.render($big-r);
like $big, /'4000 字节'/, '大 Buf 显示字节数';
like $big, /'0x<01 02 03 04'/, '大 Buf 显示前几字节的十六进制';
like $big, /'…>'/, '截断处有省略号';
ok $big.chars < 120, "渲染长度有界（实得 {$big.chars} 字符）";
unlike $big, /'1,2,3,4'/, '不再输出完整元素列表';
unlike $big, /'Buf.new('/, '不走 .raku 的构造器写法';
ok $big-r.value ~~ Blob, '值本身仍是 Blob（只换显示）';
is $big-r.value.elems, 4000, '值的字节数没被截断';

like shown('Buf.new()'), /'Buf 空'/, '空 Buf 显示「空」而不是 0x<>';

my Str $enc = shown(q{'hi'.encode});
like $enc, /'Buf[utf8] 2 字节'/, 'encode 的裸别名补成 Buf[utf8]';
like $enc, /'0x<68 69>'/, 'utf8 字节按字节显示';

like shown('Blob.new(1,2,3)'), /'Blob 3 字节'/, 'Blob 同样走摘要';

my Str $arrow = 't/fixtures/arrow/basic.arrow';
my Int $size = $arrow.IO.s;
# 路径用绝对形式 + 正斜杠：反斜杠在 Raku 字符串里是转义，不能直接拼。
my Str $abs = $arrow.IO.absolute.trans('\\' => '/');
my Str $ar = shown('slurp("' ~ $abs ~ '", :bin)');
like $ar, /"$size 字节"/, 'Arrow 缓冲区显示真实字节数';
like $ar, /'Arrow IPC 文件'/, 'ARROW1 magic 被识别';
like $ar, /'41 52 52 4F 57 31'/, 'magic 本身出现在预览里';

like shown('42'), /^ 'Out[' \d+ '] = 42' $/, '整数渲染不变';
