use Test;
use lib 't/lib';
use Rakuish::Data::Table;
use Rakuish::Data::Duck;
use Rakuish::Data::Arrow;
use Rakuish::Result;
use Rakuish::DSL;
use JSON::Fast;

# ══════════════════════════════════════════════════════════════════
# 76-duck-sql.t —— Table ⟷ DuckDB（Duckula）的联合处理（0.120.0 / V-315）
# ══════════════════════════════════════════════════════════════════
# 三方分工：
#   · 读 .arrow → Table：Arrow::IPC（0.118.3）
#   · Table → .arrow：Rakuish::Data::Arrow（自研，纯 Raku）
#   · Table → SQL → Table：Duckula / DuckDB（本文件）
# 桥用临时 Arrow 文件当交换格式：写走自研、读走 Duckula 的 read-arrow，
# 回读走 Frame 的 Raku 值（不碰 Duckula 0.33.1 有问题的 ipc-buf 路径）。


# 捕获异常的 helper：`try { ...; Nil }` 永远返回 Nil，别用那个写法。
sub caught(&code) {
    my $err;
    {
        CATCH { default { $err = $_ } }
        code();
    }
    $err;
}

my $probe = try {
    Rakuish::Data::Table.new(:columns(<a>), :rows([{ a => 1 }]), :types({ a => 'int' }))
        .sql('select count(*) as c from t');
};
my Bool $have = $probe.defined;
if !$have {
    skip 'Duckula / DuckDB 未安装，跳过 Table.sql 联合处理测试', 43;
    done-testing;
}

my $t = Rakuish::Data::Table.new(
    :columns(<kind n score>),
    :rows([
        %(kind => 'red',   n => 3, score => 1.5),
        %(kind => 'green', n => 1, score => 2.25),
        %(kind => 'red',   n => 2, score => Any),
        %(kind => 'blue',  n => 4, score => 4.0),
    ]),
    :types({ kind => 'str', n => 'int', score => 'num' }),
);

# ── 1. 聚合 ───────────────────────────────────────────────────────
my $agg = $t.sql('select kind, sum(n) as total, count(*) as c from t group by 1 order by total desc');
is $agg.columns.List, ('kind', 'total', 'c'), 'group by 返回期望的列';
is $agg.types<total>, 'int', 'sum(int) 是 int';
is $agg.types<c>, 'int', 'count(*) 是 int';
is $agg.types<kind>, 'str', '分组列是 str';
is $agg.rows.elems, 3, '三组';
is $agg.rows[0]<kind>, 'red', '按 total 降序第一组是 red';
is $agg.rows[0]<total>, 5, 'red 的 n 合计 5';
is $agg.rows[0]<c>, 2, 'red 有两行';

# ── 2. 计算列与过滤 ───────────────────────────────────────────────
my $calc = $t.sql('select n * 10 as big from t where kind = \'red\' and n > 2');
is $calc.rows.elems, 1, 'where 过滤后一行';
is $calc.rows[0]<big>, 30, '计算列 3 * 10';
is $calc.types<big>, 'int', '计算列类型是 int';

# ── 3. NULL 原样带回 ──────────────────────────────────────────────
my $nulls = $t.sql('select kind, score from t where score is null');
is $nulls.rows.elems, 1, 'IS NULL 命中一行';
ok !$nulls.rows[0]<score>.defined, 'SQL NULL 仍是 undef';
is $nulls.types<score>, 'num', 'NULL 列类型仍是 num';

# ── 4. 浮点与 ORDER BY ───────────────────────────────────────────
my $nums = $t.sql('select score from t where score is not null order by score');
is $nums.rows.map({ $_{'score'}.Num }).List, (1.5e0, 2.25e0, 4.0e0), '浮点值按序返回';

# ── 5. 空表 ──────────────────────────────────────────────────────
my $empty = Rakuish::Data::Table.new(:columns(<a>), :rows([]), :types({ a => 'int' }));
is $empty.sql('select count(*) as c from t').rows[0]<c>, 0, '空表 count(*) = 0';

# ── 6. 时间列往返 ────────────────────────────────────────────────
my $dt = Rakuish::Data::Table.new(
    :columns(<id ts>),
    :rows([
        %(id => 1, ts => DateTime.new('2020-01-01T00:00:00Z')),
        %(id => 2, ts => DateTime.new('2021-06-15T12:30:00Z')),
    ]),
    :types({ id => 'int', ts => 'datetime' }),
);
my $dtr = $dt.sql('select id, ts from t order by ts desc');
is $dtr.types<ts>, 'datetime', '时间列回来仍是 datetime';
isa-ok $dtr.rows[0]<ts>, DateTime, '单元格是 DateTime 对象';
is $dtr.rows[0]<ts>.year, 2021, '降序第一个是 2021';
is $dtr.rows[1]<ts>.year, 2020, '第二个是 2020';

# ── 7. 多表 join ─────────────────────────────────────────────────
my $left = Rakuish::Data::Table.new(
    :columns(<k v>), :rows([{ k => 1, v => 'a' }, { k => 2, v => 'b' }]),
    :types({ k => 'int', v => 'str' }));
my $right = Rakuish::Data::Table.new(
    :columns(<k w>), :rows([{ k => 1, w => 10 }, { k => 3, w => 30 }]),
    :types({ k => 'int', w => 'int' }));
my $joined = query({ 'l' => $left, 'r' => $right },
    'select l.k, v, w from l left join r using (k) order by l.k');
is $joined.columns.List, ('k', 'v', 'w'), 'join 的列';
is $joined.rows.elems, 2, '左连接保留两行';
is $joined.rows[0]<w>, 10, 'k=1 匹配到 w=10';
ok !$joined.rows[1]<w>.defined, 'k=2 没有匹配 → NULL';
is $joined.types<w>, 'int', 'NULL 不改变列类型';

# ── 8. 嵌套列按 JSON 文本过 SQL ──────────────────────────────────
my $nested = Rakuish::Data::Table.new(
    :columns(<id tags>),
    :rows([{ id => 1, tags => ['a', 'b'] }, { id => 2, tags => [] }]),
    :types({ id => 'int', tags => 'list' }),
);
my $nr = $nested.sql('select id, tags from t order by id');
is $nr.types<tags>, 'str', '嵌套列在 SQL 侧是 JSON 文本';
like $nr.rows[0]<tags>, /'["a","b"]'/, 'list 序列化成 JSON 数组';
is from-json($nr.rows[0]<tags>).List, ('a', 'b'), 'JSON 能解回原值';

# ── 9. 只读守卫 ──────────────────────────────────────────────────
my $ddl-err = caught { $t.sql('drop table t') };
ok $ddl-err.defined, 'DROP TABLE 被拒绝';
like $ddl-err.message, /'read-only'/, '错误里说明只读';
is $t.sql('select count(*) as c from t').rows[0]<c>, 4, '拒绝后表还在（4 行）';

# ── 10. 参数校验 ─────────────────────────────────────────────────
my $bad-name = caught { $t.sql('select 1', :name('bad name; --')) };
ok $bad-name.defined, '非法表名被拒绝';
like $bad-name.message, /'表名'/, '错误里点名表名';
my $bad-sql = caught { $t.sql('   ') };
ok $bad-sql.defined, '空 SQL 被拒绝';

# ── 11. 原表不可变 ───────────────────────────────────────────────
is $t.rows.elems, 4, '原表行数不变';
is $t.types<score>, 'num', '原表类型不变';

# ── 12. 不再写临时 Arrow 文件（0.134.0 / ADR-0043 §7）───────────────
# 老路径「Table → 自研 Arrow 写临时 IPC → read-arrow 建视图」的 99% 成本在
# 序列化（5 万行 4.8 s，而 SQL 本身 4 ms）。现在走 CREATE TABLE + Appender
# 直插，**一张临时文件都不产生** —— 这里断言的是「根本没有创建」，
# 比以前「创建了再清理」更强。
my @before = $*TMPDIR.dir.grep({ .basename.starts-with('rakuish-duck-') });
$t.sql('select 1 as one');
my @after = $*TMPDIR.dir.grep({ .basename.starts-with('rakuish-duck-') });
is @after.elems, @before.elems, 'SQL 桥不再产生临时 Arrow 文件';
is @before.elems, 0, '基线本身没有残留的临时文件';

# ── 12b. 列名进 DDL：关键字 / 带引号 / 带空格都要能建表 ──────────────
{
    my $kw = Rakuish::Data::Table.new(
        :columns('group', 'select', 'weird name', 'has"quote'),
        :rows([{ 'group' => 1, 'select' => 'a', 'weird name' => 'w', 'has"quote' => 2 }]),
        :types({ 'group' => 'int', 'select' => 'str', 'weird name' => 'str',
                 'has"quote' => 'int' }),
    );
    my $got = caught { $kw.sql('select "group", "select", "weird name", "has""quote" from t') };
    ok !$got.defined, '关键字/引号/空格列名能进 DDL（标识符已转义）';
    my $r = $kw.sql('select "group" as g from t');
    is $r.rows[0]<g>, 1, '转义后的列名仍可查询';
}

# ── 12c. 超 int64 现在明确报错（老路径是静默溢出）─────────────────
{
    my $big = Rakuish::Data::Table.new(
        :columns(<v>), :rows([{ v => 9223372036854775808 }]), :types({ v => 'int' }),
    );
    my $err = caught { $big.sql('select sum(v) as s from t') };
    ok $err.defined, '超 int64 明确报错（不再静默溢出成负数）';
    is $big.rows[0]<v>, 9223372036854775808, '原表的值没有被改写';
}

# ── 13. 写侧拒绝嵌套（不再静默写成 .Str）────────────────────────
my $write-err = caught { write-ipc($nested) };
ok $write-err.defined, '写嵌套列被拒绝';
isa-ok $write-err, X::Rakuish::Arrow, '异常类型是 X::Rakuish::Arrow';
like $write-err.message, /'tags'/, '错误里点名列';

# ── 14. DSL 短命令：sql(Table, …) 与 sql(%tables, …) ─────────────
is sql($t, 'select count(*) as c from t').rows[0]<c>, 4, 'sql(Table, …) 短命令';
my $both = sql({ 'x' => $left, 'y' => $right },
    'select count(*) as c from x join y using (k)');
is $both.rows[0]<c>, 1, 'sql(Hash, …) 多表短命令';
my $wrong = caught { sql(42, 'select 1') };
ok $wrong.defined, 'sql 的第一个参数类型不对时报错';

done-testing;
