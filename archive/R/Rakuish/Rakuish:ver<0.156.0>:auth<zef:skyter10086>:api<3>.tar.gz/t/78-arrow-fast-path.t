use Test;
use lib 't/lib';
use Rakuish::Sys;
use Rakuish::Data;
use Rakuish::Data::Arrow;
use Rakuish::Data::Table;
use Rakuish::Data::Duck;
use Rakuish::Result;

# ══════════════════════════════════════════════════════════════════
# 78-arrow-fast-path.t —— 标量列交给 DuckDB 读（0.122.0 / V-318）
# ══════════════════════════════════════════════════════════════════
# `open-data` 的 .arrow 分支现在先问一句「这个文件能不能交给 DuckDB」：
#   · 只看 schema（`ipc-column-kinds-file` 只读尾部 Footer，不整份读）；
#   · 类型全在白名单里才走快路（int/float/bool/utf8/date/timestamp/decimal）；
#   · 白名单外（time/duration/带时区/嵌套/字典/二进制）照旧走纯 Raku 读入器；
#   · Duckula / DB::DuckDB / nanoarrow 缺一个，或者读失败，就静默回落。
#
# 这是**纯优化**，所以这里的核心断言是「两条路逐值一致」：同一份文件分别用
# RAKUISH_ARROW_NATIVE=1（强制快路）与 RAKUISH_ARROW_RAKU=1（强制老路）读，
# 列名、类型、每一行都必须 eqv。
#
# 顺带钉住两个能力变化：
#   · 压缩的标量文件现在能读（自研读入器不解压，以前直接报错）；
#   · timestamp 的小数秒不再有浮点毛刺（老路改传 Rat 给 Instant.from-posix）。

plan 35;

my $sys = Rakuish::Sys.new(:root($*CWD));

sub op(Str $name, Str :$mode = '' --> Rakuish::Data::Table) {
    my $saved-n = %*ENV<RAKUISH_ARROW_NATIVE>;
    my $saved-r = %*ENV<RAKUISH_ARROW_RAKU>;
    LEAVE {
        %*ENV<RAKUISH_ARROW_NATIVE> = $saved-n if $saved-n.defined;
        %*ENV<RAKUISH_ARROW_RAKU>   = $saved-r if $saved-r.defined;
        %*ENV<RAKUISH_ARROW_NATIVE>:delete unless $saved-n.defined;
        %*ENV<RAKUISH_ARROW_RAKU>:delete   unless $saved-r.defined;
    }
    %*ENV<RAKUISH_ARROW_NATIVE> = '1' if $mode eq 'native';
    %*ENV<RAKUISH_ARROW_RAKU>   = '1' if $mode eq 'raku';
    open-data($sys, "t/fixtures/arrow/$name");
}

# ---------- schema 扫描：只读 Footer，不碰 body ----------
{
    my @k = ipc-column-kinds-file('t/fixtures/arrow/basic.arrow');
    is-deeply @k.map(*<name>).List, <n x s b>, 'schema 扫描拿到列名';
    is-deeply @k.map(*<kind>).List, <int float utf8 bool>, 'schema 扫描拿到类型';
}
{
    my @k = ipc-column-kinds-file('t/fixtures/arrow/temporal.arrow');
    is-deeply @k.map(*<kind>).List.grep({ $_ eq 'time' | 'duration' }).List,
        <time duration>, 'time / duration 能被识别出来（快路不收）';
    is @k.first(*<name> eq 'tsz')<tz>.chars > 0, True,
        '带时区的 timestamp 带 tz（快路不收）';
}
{
    my $p = $*TMPDIR.add("rakuish-bogus-{$*PID}.arrow");
    $p.spurt("this is not arrow\n");
    LEAVE { $p.unlink if $p.e }
    is ipc-column-kinds-file($p.Str).elems, 0, '不是 IPC 的文件返回空表而不是抛';
}

# ---------- 两条路逐值一致 ----------
# basic/kinds/datetime/decimal/stream 都在白名单内（快路真的走了）；
# temporal/nested 被类型挡下 —— 一起比是为了证明「挡下之后没有第二套行为」。
# empty 是 0 行的边界。
# compressed 单独测：它要 DuckDB 才读得出来，没有就得跳过（见下）。
for <basic kinds datetime decimal stream temporal nested empty> -> $name {
    my $fast = op("$name.arrow", :mode<native>);
    my $slow = op("$name.arrow", :mode<raku>);
    is-deeply $fast.columns.List, $slow.columns.List, "$name：列名一致";
    is-deeply $fast.types.Hash,   $slow.types.Hash,   "$name：列类型一致";
    is-deeply $fast.rows.List,    $slow.rows.List,    "$name：逐行值一致";
}

# ---------- 快路带来的能力变化 ----------
# 压缩文件必须有人解压：DuckDB + nanoarrow 缺一个就只能报错（老行为）。
my Bool $native = Rakuish::Data::Duck::arrow-native-available;
{
    if $native {
        my $c = op('compressed.arrow', :mode<native>);
        is $c.rows.elems, 3, '压缩的标量 Arrow 现在能读';
        is-deeply $c.rows.map(*<a>).List, (1, 2, 3), '解压后的值正确';
    }
    else {
        skip 'DuckDB / nanoarrow 不可用：压缩文件解不开', 2;
    }
}

# 负的 DECIMAL 曾经被解成无符号大数（-0.0001 → 3.4e34）：那是 DB::DuckDB
# 的 ColumnView 没做 128 位补码扩展，1.3.1 修好后才把 decimal 放进白名单。
# 这条断言就是那个回归的看门人。
{
    my $d = op('decimal.arrow', :mode<native>);
    is $d.rows[1]<dec>, -0.0001, '负的 DECIMAL 不会被解成无符号大数';
}

{
    my $e = op('empty.arrow', :mode<native>);
    is $e.rows.elems, 0, '零批次的空文件按空表读';
}

# ---------- 小数秒不再有浮点毛刺（老路改传 Rat） ----------
{
    my $t = op('datetime.arrow', :mode<raku>);
    is $t.rows[1]<ts>.second, 59.123,
        'timestamp 的小数秒精确到毫秒（不再出现 .12300006）';
    is $t.rows[2]<ts>.defined, False, 'NULL timestamp 仍是 undef';
}
