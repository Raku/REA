use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Display;
use Rakuish::REPL::Session;

# 0.123.0 / P0：对标 IPython 评审（docs/REVIEW-VS-IPYTHON-2026-11-24.md）里的
# 七个缺陷。每条先在 0.122.3 上是红的，再被实现改绿 —— 本文件是回归护栏。
#
#   V-319 前奏顺序：引用 REPL 变量的 sub 不再锁死会话
#   V-320 纯声明格不占 Out[n]、不改 `_`
#   V-321 内省（`名字?` / doc）不占 Out[n]、不改 `_`
#   V-322 `In[n]` 是输入历史（与 `Out[n]` 对称）
#   V-323 display 与 out 分工：有值时 display 给值，stdout 另走 out
#   V-324 不可 JSON 化的值不得打死引擎（降级，不抛）
#   V-325 README / install.sh 的宣称与实际一致

# 测试不写会话快照：它们是临时会话，不该污染 $HOME/.rakuish。
BEGIN { %*ENV<RAKUISH_NO_SNAPSHOT> = '1' }

my IO::Path $repo = $*CWD;
sub session(--> Rakuish::REPL::Session) { Rakuish::REPL::Session.new }

# ── V-319：前奏顺序 ──────────────────────────────────────────────────
# 修复前：`my $n` 之后定义引用 `$n` 的 sub，后续每一格都在重放前奏时编译失败。
{
    my $s = session;
    is $s.eval-line('my $n = 10').value, 10, 'V-319 基准：变量格';
    ok $s.eval-line('sub addn($v) { $v + $n }').ok, 'V-319 引用 REPL 变量的 sub 可声明';
    my $call = $s.eval-line('addn(5)');
    ok $call.ok, 'V-319 该 sub 在后续格可调用（前奏里别名先于声明）';
    is $call.value, 15, 'V-319 闭包捕获的是会话变量的值';
    ok $s.eval-line('1 + 1').ok, 'V-319 前奏不再被毒化，任意格仍可执行';

    # 多个声明 + 多个变量：别名整体前置，不是只对第一个变量生效。
    my $s2 = session;
    $s2.eval-line('my $a = 2');
    $s2.eval-line('my $b = 3');
    $s2.eval-line('sub sum2() { $a + $b }');
    is $s2.eval-line('sum2()').value, 5, 'V-319 多变量前奏顺序同样正确';
}

# ── V-320：纯声明格不占 Out[n] ───────────────────────────────────────
# IPython 的 `def` 不产生 Out；Rakuish 之前会显示 `Out[1] = sub ...` 并吞掉编号。
{
    my $s = session;
    my $decl = $s.eval-line('sub twice($x) { $x * 2 }');
    ok $decl.ok, 'V-320 纯声明格求值成功';
    is $s.index, 0, 'V-320 纯声明格不推进格号';
    nok $s.render($decl).contains('Out['), 'V-320 声明格不渲染 Out[n]';

    my $use = $s.eval-line('use JSON::Fast;');
    ok $use.ok, 'V-320 纯 use 格成功';
    is $s.index, 0, 'V-320 纯 use 格也不推进格号';

    my $v = $s.eval-line('twice(21)');
    is $v.value, 42, 'V-320 声明仍跨格可用';
    is $s.index, 1, 'V-320 第一个有值的格才是 Out[1]';
    ok $s.render($v).contains('Out[1] ='), 'V-320 有值格照常渲染 Out[1]';

    # 失败格本来就不占号，这条不能被顺手改坏。
    my $bad = $s.eval-line('die "x"');
    nok $bad.ok, 'V-320 基准：失败格';
    is $s.index, 1, 'V-320 失败格不推进格号';
}

# ── V-321：内省不占格、不改 `_` ──────────────────────────────────────
{
    my $s = session;
    is $s.eval-line('40 + 2').value, 42, 'V-321 基准：有值格';
    my Int $before = $s.index;
    my $q = $s.eval-line('ls?');
    ok $q.ok, 'V-321 `ls?` 成功';
    ok $q.out.contains('ls'), 'V-321 给出命令用法';
    is $s.index, $before, 'V-321 内省不推进格号';
    is $s.eval-line('_').value, 42, 'V-321 内省不改 `_`';
    is $s.index, $before + 1, 'V-321 读 `_` 的格才占下一个编号（内省没占）';
    is $s.eval-line('Out[2]').value, 42, 'V-321 Out[2] 就是读 `_` 的那格，没有跳号';
}

# ── V-322：In[n] 是输入历史 ──────────────────────────────────────────
{
    my $s = session;
    $s.eval-line('1 + 1');
    $s.eval-line('2 + 2');
    # 失败格进 history 但不进 @!out —— 这正是 In/Out 长度会分叉的地方。
    $s.eval-line('die "boom"');

    # 补全必须按各自的长度算：不能拿 Out 的长度去补 In，反之亦然。
    my @in-c = $s.completions('In[', 3);
    ok @in-c.grep({ $_ eq 'In[3]' }).elems, 'V-322 In[ 补到第 3 条输入（含失败格）';
    my @out-c = $s.completions('Out[', 4);
    nok @out-c.grep({ $_ eq 'Out[3]' }).elems, 'V-322 Out[ 不补出不存在的结果';

    my $in = $s.eval-line('In[1]');
    ok $in.ok, 'V-322 In[1] 可求值';
    is $in.value, '1 + 1', 'V-322 In[1] 是第一条输入';
    is $s.eval-line('In[2]').value, '2 + 2', 'V-322 In[2] 是第二条输入';
    is $s.eval-line('Out[1]').value, 2, 'V-322 Out[1] 仍是结果值（两条互不干扰）';
}

# ── V-323：display 与 out 分工 ───────────────────────────────────────
# 契约：`out` 是 stdout 流，`display` 是这一格的值。
# 之前 `out` 抢先返回，导致 `say "hi"; 42` 的 42 永远到不了前端。
{
    my $both = Result.new(:ok, :op<eval>, :value(42), :out("hi\n"));
    my $b = Rakuish::Display::bundle-from($both);
    is $b.text, '42', 'V-323 有 stdout 也有值时，display 给值';
    isnt $b.text, 'hi', 'V-323 display 不吞掉 stdout 冒充结果';

    my $out-only = Result.new(:ok, :op<ls>, :value(Any), :out("a\nb\n"));
    is Rakuish::Display::bundle-from($out-only).text, "a\nb",
       'V-323 命令的 stdout 就是它的展示（op 不是 eval）';

    my $eval-out-only = Result.new(:ok, :op<eval>, :value(Any), :out("hi\n"));
    is Rakuish::Display::bundle-from($eval-out-only).text, 'hi',
       'V-323 eval 没有值时才退回 stdout';

    my %h = Rakuish::Display::bundle-from($both).to-hash(:mime);
    is %h<meta><source>, 'value', 'V-323 meta 标明 display 来源是值';
    is Rakuish::Display::bundle-from($out-only).to-hash(:mime)<meta><source>,
       'out', 'V-323 meta 标明 display 来源是 stdout';
}

# ── V-324：不可 JSON 化的值不得打死引擎 ──────────────────────────────
{
    my $c = Result.new(:ok, :op<eval>, :value(3 + 4i));
    my %h;
    lives-ok { %h = Rakuish::Display::bundle-from($c).to-hash(:mime) },
        'V-324 Complex 值不抛异常（修复前 JSON::Fast 直接抛）';
    is %h<mime><text/plain>, '3+4i', 'V-324 仍给出 text/plain 降级';
    nok %h<mime><application/json>:exists,
        'V-324 不能序列化就不提供 application/json（不伪装成功）';
    nok %h<formats>.grep('json').elems,
        'V-324 formats 也不谎称有 json';

    # 用户自定义对象：`.Str` 可渲染，JSON 不可序列化。
    class Pt { has $.x = 1; has $.y = 2; method Str { "Pt(1,2)" } }
    my $p = Result.new(:ok, :op<eval>, :value(Pt.new));
    lives-ok { Rakuish::Display::bundle-from($p).to-hash(:mime) },
        'V-324 自定义对象不抛异常';
}

# ── V-325：README / install.sh 的宣称与实际一致 ──────────────────────
# 这几条不是功能，是「文档不能教用户写出错误代码」。
{
    my Str $readme = $repo.add('README.md').slurp;
    nok $readme.contains('rakuish> %h = a => 7'),
        'V-325 README 不再给未声明的 %h 赋值示例';
    ok $readme.contains('my %h = a => 7'),
        'V-325 README 的哈希示例带 my';

    my Str $install = $repo.add('tools/install.sh').slurp;
    nok $install.contains('rakuish-agent'),
        'V-325 install.sh 不引用已删除的 agent 入口';
    nok $install.contains('--agent'),
        'V-325 install.sh 不再宣传 --agent';
    nok $install.contains('只有 JSON::Fast'),
        'V-325 install.sh 的依赖说明不再谎称「只有 JSON::Fast」';
}

done-testing;
