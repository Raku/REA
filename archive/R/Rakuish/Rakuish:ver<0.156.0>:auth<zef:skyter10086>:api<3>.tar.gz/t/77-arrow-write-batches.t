use Test;
use lib 't/lib';
use Rakuish::Data::Arrow;
use Rakuish::Data::Table;
use Rakuish::Data;
use Rakuish::Sys;
use Rakuish::Result;

# ══════════════════════════════════════════════════════════════════
# 77-arrow-write-batches.t —— 多批 / 流式写（0.121.0 / V-317）
# ══════════════════════════════════════════════════════════════════
# 0.120 及以前，写侧只有「整表 → 一个 RecordBatch → 一份 Buf」。
# 0.121.0 把写入器拆成 start / add-batch / finish：
#   · write-ipc(:batch-size)     分多批，编码峰值 = 一批
#   · write-ipc-file(:batch-size) 同上，直接写文件句柄
#   · write-ipc-stream(流, 路径)  真流式：边拉边写，内存里只留一批
# 读侧本来就循环所有 block / 所有 BATCH 消息，所以这里只验写侧与往返。
#
# pyarrow 26 已确认能读这些文件（batches 数、行数、类型都对），
# 但测试本身不依赖 pyarrow —— 用 ipc-batch-count 验批数。

plan 46;

sub caught(&code) {
    my $err;
    {
        CATCH { default { $err = $_ } }
        code();
    }
    $err;
}

my IO::Path $dir = $*CWD.add("t/tmp-arrow-{$*PID}");
$dir.mkdir;
my $sys = Rakuish::Sys.new(:root($*CWD));
LEAVE {
    .unlink for $dir.dir;
    $dir.rmdir;
}

my @rows = (^2500).map({ %(id => $_, name => "n{$_}", ok => ($_ % 2 == 1)) });
my $t = Rakuish::Data::Table.new(:rows(@rows));

# ── 1. 多批（内存）────────────────────────────────────────────────
my Buf $b = write-ipc($t, :batch-size(1000));
my $back = read-ipc($b);
is ipc-format($b), 'file', '多批仍是文件格式';
is ipc-batch-count($b), 3, '2500 行 / 1000 → 3 批';
is $back.rows.elems, 2500, '多批读回行数一致';
is $back.rows[0]<id>, 0, '首批首行值';
is $back.rows[1499]<name>, 'n1499', '第二/三批交界处值（1000 行一批）';
is $back.rows[2499]<ok>, True, '末批末行值';
is $back.types<id>, 'int', 'schema 只写一次、类型不变';

# ── 2. 批大小边界 ─────────────────────────────────────────────────
is ipc-batch-count(write-ipc($t, :batch-size(10_000))), 1,
   'batch-size 大于行数 → 仍是一批';
is ipc-batch-count(write-ipc($t)), 1, '不传 batch-size = 旧行为（一批）';
my $seven = Rakuish::Data::Table.new(:rows((^7).map({ %(v => $_) })));
is ipc-batch-count(write-ipc($seven, :batch-size(1))), 7, 'batch-size=1 每行一批';
my $empty = Rakuish::Data::Table.new(:columns(<a b>), :rows([]),
                                     :types(a => 'int', b => 'str'));
is ipc-batch-count(write-ipc($empty)), 1, '0 行但有列：仍写一个空批（与 0.120 一致）';

# ── 3. stream 格式也支持多批 ──────────────────────────────────────
my Buf $s = write-ipc($t, :format<stream>, :batch-size(700));
is ipc-format($s), 'stream', 'stream 格式判定正确';
is ipc-batch-count($s), 4, '2500 / 700 → 4 批（最后一批 400）';
is read-ipc($s).rows.elems, 2500, 'stream 格式多批读回一致';

# ── 4. 写文件 + save-data 透传 ────────────────────────────────────
my Str $multi = $dir.add('multi.arrow').Str;
write-ipc-file($t, $multi, :batch-size(1000));
ok $multi.IO.e, 'write-ipc-file 写出了文件';
my $m = read-ipc-file($multi);
is $m.columns, ('id', 'name', 'ok'), '列名与顺序保留';
is $m.rows.elems, 2500, '文件读回行数一致';
is $m.rows[2400]<name>, 'n2400', '文件末批的值正确';
is ipc-batch-count(slurp($multi, :bin)), 3, '落盘后批数仍是 3';

ok save-data($sys, "t/tmp-arrow-{$*PID}/saved.arrow", $t, :batch-size(400)),
   'save-data 接受 :batch-size';
my Str $saved = $dir.add('saved.arrow').Str;
is ipc-batch-count(slurp($saved, :bin)), 7, 'save-data：2500 / 400 → 7 批';
is read-ipc-file($saved).rows.elems, 2500, 'save-data 多批读回行数一致';

# ── 5. 流式写：行的迭代器 ────────────────────────────────────────
my Str $stream = $dir.add('stream.arrow').Str;
my Int $n = write-ipc-stream((^1000).map({ %(a => $_, b => "x{$_}") }),
                             $stream, :batch-size(300));
is $n, 1000, '流式写返回写入总行数';
ok $stream.IO.e, '流式文件落地';
is ipc-batch-count(slurp($stream, :bin)), 4, '300×3 + 100 → 4 批';
my $st = read-ipc-file($stream);
is $st.rows.elems, 1000, '流式读回行数一致';
is $st.columns, ('a', 'b'), '列名按首批推断';
is $st.rows[999]<a>, 999, '流式末行值正确';

# ── 6. 流式写：Table 的迭代器 ────────────────────────────────────
my Str $tstream = $dir.add('tables.arrow').Str;
my Int $tn = write-ipc-stream($t.batches(:size(600)), $tstream, :batch-size(600));
is $tn, 2500, '表流返回总行数';
is ipc-batch-count(slurp($tstream, :bin)), 5, '表流 600×4 + 100 → 5 批';
is read-ipc-file($tstream).rows.elems, 2500, '表流读回行数一致';

# ── 7. 流式写 stream 格式 ────────────────────────────────────────
my Str $ss = $dir.add('streamfmt.arrow').Str;
my Int $sn = write-ipc-stream((^50).map({ %(n => $_) }), $ss,
                              :batch-size(20), :format<stream>);
is $sn, 50, 'stream 格式流式写返回行数';
is ipc-format(slurp($ss, :bin)), 'stream', '流式写也能产出 stream 格式';
is read-ipc-file($ss).rows.elems, 50, 'stream 格式流式读回一致';

# ── 8. 类型冲突 / 嵌套 / 空流 / 参数 ──────────────────────────────
my Str $bad = $dir.add('bad.arrow').Str;
my $err = caught { write-ipc-stream((%(a => 1), %(a => 'boom')), $bad, :batch-size(1)) };
ok $err ~~ X::Rakuish::Arrow, '首批 int、第二批 str → 抛 X::Rakuish::Arrow';
like $err.message, /类型对不上/, '错误点明类型冲突';
nok $bad.IO.e, '失败不留半截目标文件';
nok $dir.add('bad.arrow.part').IO.e, '失败也不留 .part 临时文件';

my $nerr = caught { write-ipc-stream((%(a => 1), %(a => (1, 2))),
                                     $dir.add('n.arrow').Str, :batch-size(1)) };
like $nerr.message, /嵌套/, '中途出现嵌套值 → 明确拒绝，不写 .Str 噪声';

my $eerr = caught { write-ipc-stream((), $dir.add('e.arrow').Str) };
ok $eerr ~~ X::Rakuish::Arrow, '空流没有行可推断 schema → 报错';
ok $eerr.message.contains('无法推断 schema'), '空流错误说明原因';

my $berr = caught { write-ipc($t, :batch-size(0)) };
ok $berr ~~ X::Rakuish::Arrow, 'batch-size=0 被拒';

# ── 9. 空流 + :columns：写 0 行 ──────────────────────────────────
my Str $ce = $dir.add('empty.arrow').Str;
is write-ipc-stream((), $ce, :columns(<a b>)), 0, '空流 + :columns 返回 0 行';
my $ce-back = read-ipc-file($ce);
is $ce-back.rows.elems, 0, '0 行文件可读回';
is $ce-back.columns, ('a', 'b'), '0 行文件保留列名';

# ── 10. 表流列不一致 ─────────────────────────────────────────────
my $c1 = Rakuish::Data::Table.new(:rows([%(a => 1)]));
my $c2 = Rakuish::Data::Table.new(:rows([%(b => 2)]));
my $cerr = caught { write-ipc-stream(($c1, $c2), $dir.add('c.arrow').Str, :batch-size(10)) };
like $cerr.message, /列对不上/, '表流中途换列 → 报错而不是静默补 null';
