use v6.d;
use Test;
use lib 'lib';

# 0.146.0 / V-350 / ADR-0060：Session 拆分后的**结构守卫**。
#
# 这套断言不测行为（行为由 t/05 / t/37 / t/82 测），只钉住「拆分这件事
# 本身没有走回头路」：命令层与配置层各自留在自己的文件里，Session 不再
# 把它们长回去。为什么值得测 —— 0.14x 的事实是 Session 从 3,519 行长到
# 4,304 行，只靠人眼和 review 挡不住增长；把它写成断言，下一次有人把
# 命令写回 Session 时会当场红。

my IO::Path $root = 'lib/Rakuish/REPL'.IO;
my IO::Path $sess = $root.add('Session.rakumod');
my IO::Path $cmds = $root.add('Session/Commands.rakumod');
my IO::Path $conf = $root.add('Session/Config.rakumod');

ok $sess.e, 'Session.rakumod 在';
ok $cmds.e, '命令层文件在（Session/Commands.rakumod）';
ok $conf.e, '配置层文件在（Session/Config.rakumod）';

my Str $sess-text = $sess.slurp.subst("\x[FEFF]", '');
my Str $cmds-text = $cmds.slurp.subst("\x[FEFF]", '');
my Str $conf-text = $conf.slurp.subst("\x[FEFF]", '');

# ── 声明的形状：两个 role + 一个 does 了两者的 class ─────────────────
ok $cmds-text.starts-with('unit role Rakuish::REPL::Session::Commands;'),
     '命令层是 unit role Rakuish::REPL::Session::Commands';
ok $conf-text.starts-with('unit role Rakuish::REPL::Session::Config;'),
     '配置层是 unit role Rakuish::REPL::Session::Config';

like $sess-text, /'unit class Rakuish::REPL::Session does Rakuish::REPL::Session::Commands'/,
     'Session 声明了 does ...Commands';
like $sess-text, /'does Rakuish::REPL::Session::Config'/,
     'Session 声明了 does ...Config';
like $sess-text, /'use Rakuish::REPL::Session::Commands;'/,
     'Session 在 unit 之前 use 了 Commands（否则 does 解析不到）';
like $sess-text, /'use Rakuish::REPL::Session::Config;'/,
     'Session 在 unit 之前 use 了 Config';

# ── 反方向：搬走的东西不许留在 Session ─────────────────────────────
nok $sess-text.contains('method !cmd-errors('),
    '!cmd-errors 不在 Session（否则就是又长回去了）';
ok $cmds-text.contains('method !cmd-errors('),
    '!cmd-errors 在命令层';

for <!cmd-alias !cmd-unalias !cmd-config !cmd-hook !cmd-plugin !expand-alias !save-config> -> $m {
    my Str $sig = 'method ' ~ $m ~ '(';
    nok $sess-text.contains($sig),
        "$m 不在 Session";
    ok $conf-text.contains($sig),
        "$m 在配置层";
}

ok $conf-text.contains('method run-hooks('), 'run-hooks 在配置层';
nok $sess-text.contains('method run-hooks('), 'run-hooks 不在 Session';
ok $conf-text.contains('method options('), 'options 在配置层';

# ── 规模上限：拆分后不该再变回去 ─────────────────────────────────────
# 4,304 行是拆分前的实际值（0.145.0 实测）。上限给到 4,150 —— 比拆分前
# 小，比现在（约 4,035）宽松，允许正常增长但不允许把命令搬回来。
my Int $sess-lines = $sess-text.lines.elems;
cmp-ok $sess-lines, '<', 4150,
       "Session 行数 {$sess-lines} 仍低于拆分前的 4,304（不再长出 God Class）";

# ── 运行时：组合后的东西真的能用（不是只搬了文本）─────────────────
use Rakuish::REPL::Session;
my $s = Rakuish::REPL::Session.new(:snapshot-on(False));
ok $s.^can('options'), 'Session 实例上仍有 options 方法（role 组合生效）';

my %opts = $s.options;
is %opts.elems, 5, 'set -o 选项表仍是 5 项';
my Str $names = %opts.keys.sort.join(',');
is $names, 'errexit,histexpand,noexpand,noglob,xtrace',
   '选项名没变（errexit,histexpand,noexpand,noglob,xtrace）';

# `run-hooks` 搬走后仍是公开方法，且对未注册的事件返回空列表
is $s.run-hooks('no-such-event').elems, 0, 'run-hooks 对未注册事件返回空';

# `!expand-alias` 搬走后历史展开照旧（公开面 histexpand 可读）
ok $s.histexpand, 'histexpand 默认仍为真（role 读到公开访问器）';

done-testing;
