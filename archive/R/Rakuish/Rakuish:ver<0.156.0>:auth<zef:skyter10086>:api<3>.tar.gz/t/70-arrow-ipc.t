use Test;
use lib 't/lib';
use Rakuish::Data::Arrow;
use Rakuish::Data::Table;
use Rakuish::Result;
use Rakuish::Data;
use Rakuish::Sys;

# ══════════════════════════════════════════════════════════════════
# 70-arrow-ipc.t —— Arrow IPC 读写（0.116.0 / V-308）
# ══════════════════════════════════════════════════════════════════
# t/fixtures/arrow/ 里的文件是 **pyarrow 26 生成的真实产物**，随仓库提交，
# 所以这套测试不依赖 pyarrow / DuckDB（WSL 侧没有它们也能跑）。
# 我们自己写出的东西是否合规，靠「pyarrow 能读」验证过（记在 SPEC 里），
# 这里只做往返与结构断言 —— 测试不该要求装了 pyarrow。

my constant DIR = $*CWD.add('t/fixtures/arrow');

# ── 1. 基本文件：四种常见类型 + 一个 null ────────────────────────────
my $basic = read-ipc-file(DIR.add('basic.arrow').Str);
is $basic.columns, ('n', 'x', 's', 'b'), '列名与顺序按 schema 保留';
is $basic.rows.elems, 3, '行数正确';
is $basic.types< n >, 'int', 'int64 → int';
is $basic.types<x>, 'num', 'double → num';
is $basic.types<s>, 'str', 'string → str';
is $basic.types<b>, 'bool', 'bool → bool';
is $basic.rows[0]<n>, 1, '第一行 int 值';
is $basic.rows[2]<n>, 3, '第三行 int 值';
is $basic.rows[0]<x>, 1.5, '浮点值';
is $basic.rows[1]<s>, 'b', '字符串值';
nok $basic.rows[2]<s>.defined, '空字符串位是 null，不是 ""';
is $basic.rows[1]<b>, False, 'bool 位图里的 0 读成 False';

# ── 2. 各类标量：宽度 / 有符号 / 精度 / 日期 / 大字符串 / 小数 ──────
my $kinds = read-ipc-file(DIR.add('kinds.arrow').Str);
is $kinds.rows[0]<i32>, -5, 'int32 有符号';
is $kinds.rows[2]<i32>, 2147483647, 'int32 上界';
is $kinds.rows[1]<u8>, 128, 'uint8 无符号（128 不会读成 -128）';
is $kinds.rows[2]<u8>, 255, 'uint8 上界';
is $kinds.rows[0]<f32>, 0.5, 'float32 半精度转 num';
is $kinds.rows[1]<f32>, -1.25, 'float32 负值';
nok $kinds.rows[2]<f32>.defined, 'float32 的 null';
is $kinds.rows[0]<ts>.Str, '2020-01-01T12:00:00Z', 'timestamp[ms] → DateTime（UTC）';
is $kinds.rows[1]<ts>.Str, '1970-01-01T00:00:00Z', '时间戳零点';
is $kinds.types<ts>, 'datetime', 'timestamp 归为 datetime';
is $kinds.rows[0]<d32>.Str, '2020-01-01T00:00:00Z', 'date32（1970 之后）';
is $kinds.rows[1]<d32>.Str, '1969-12-31T00:00:00Z', 'date32（1970 之前，负数天）';
is $kinds.rows[2]<big>, 'zzz', 'large_string（int64 offsets）';
is $kinds.rows[0]<dec>, 1.25, 'decimal128(10,2) 按 scale 还原';
is $kinds.rows[1]<dec>, -3.5, 'decimal 负值';

# ── 3. 多个记录批：按顺序拼成一个表 ──────────────────────────────────
my $multi = read-ipc-file(DIR.add('multi.arrow').Str);
is $multi.rows.elems, 3, '两个记录批拼成 3 行';
is $multi.rows».<i32>, (1, 2, 3), '批间顺序不乱';

# ── 4. 流格式（没有头尾 magic）────────────────────────────────────────
my $stream = read-ipc-file(DIR.add('stream.arrow').Str);
is $stream.rows.elems, 3, '流格式也能读';
is $stream.rows[0]<s>, 'a', '流格式的值正确';
is ipc-format(DIR.add('stream.arrow').slurp(:bin)), 'stream', 'ipc-format 认出流格式';
is ipc-format(DIR.add('basic.arrow').slurp(:bin)), 'file', 'ipc-format 认出文件格式';

# ── 5. 空表：schema 还在，行数为 0 ───────────────────────────────────
my $empty = read-ipc-file(DIR.add('empty.arrow').Str);
is $empty.rows.elems, 0, '空表 0 行';
is $empty.columns, ('a', 'b'), '空表保留列';

# ── 6. 明确拒绝而不是静默降级 ────────────────────────────────────────
throws-like { read-ipc-file(DIR.add('compressed.arrow').Str) },
    X::Rakuish::Arrow,
    message => /'压缩'/,
    'BodyCompression 明确报错（不说「读到了空表」）';

throws-like { read-ipc(Buf.new(0, 1, 2, 3)) },
    X::Rakuish::Arrow,
    message => /'不是 Arrow IPC'/,
    '非 Arrow 数据明确报错';

throws-like { read-ipc-file(DIR.add('nope.arrow').Str) },
    X::Rakuish::Arrow,
    message => /'文件不存在'/,
    '路径不存在时报清楚';

# ── 7. 写：往返 + 结构 ───────────────────────────────────────────────
my $t = Rakuish::Data::Table.new(
    :columns(<i s v flag when>),
    :rows([
        %(i => 1, s => 'a',  v => 1.5, flag => True,  when => DateTime.new('2021-06-01T10:00:00Z')),
        %(i => 2, s => Any,  v => -2.5e0, flag => False, when => DateTime.new('1970-01-01T00:00:00Z')),
        %(i => 3, s => '中文', v => 0e0,  flag => True,  when => Any),
    ]),
    :types({ i => 'int', s => 'str', v => 'num', flag => 'bool', when => 'datetime' }),
);
my Buf $bytes = write-ipc($t);
ok $bytes.elems > 100, '写出了非空缓冲区';
is Buf.new($bytes.subbuf(0, 6).list).decode('ascii'), 'ARROW1', '文件头是 ARROW1';
is Buf.new($bytes.subbuf($bytes.elems - 6, 6).list).decode('ascii'), 'ARROW1', '文件尾是 ARROW1';

my $back = read-ipc($bytes);
is $back.columns, ('i', 's', 'v', 'flag', 'when'), '往返：列名与顺序';
is $back.rows.elems, 3, '往返：行数';
is $back.rows[0]<i>, 1, '往返：int';
is $back.rows[1]<v>, -2.5, '往返：num（负数）';
is $back.rows[2]<s>, '中文', '往返：UTF-8 字符串';
nok $back.rows[1]<s>.defined, '往返：null 仍是 null';
is $back.rows[0]<flag>, True, '往返：bool';
is $back.rows[0]<when>.Str, '2021-06-01T10:00:00Z', '往返：时间戳（毫秒）';
nok $back.rows[2]<when>.defined, '往返：时间戳的 null';

# 值一样就够了，不算类型：读回来的 datetime 一律带 UTC 时区
is $back.types<i>, 'int', '往返：类型标签 int 保留';
is $back.types<s>, 'str', '往返：类型标签 str 保留';

# ── 8. 写：流格式 ────────────────────────────────────────────────────
my Buf $sbytes = write-ipc($t, :format<stream>);
is ipc-format($sbytes), 'stream', '写出的流格式能被认出';
is read-ipc($sbytes).rows.elems, 3, '流格式往返';
nok $sbytes.subbuf(0, 6).list.map(*.chr).join.contains('ARROW1'), '流格式没有 magic';

# ── 9. 空表与全 null 列 ──────────────────────────────────────────────
my $empty-t = Rakuish::Data::Table.new(:columns(<a b>), :rows([]),
                                       :types({a => 'int', b => 'str'}));
my Buf $ebytes = write-ipc($empty-t);
my $eback = read-ipc($ebytes);
is $eback.rows.elems, 0, '空表往返 0 行';
is $eback.columns, ('a', 'b'), '空表往返保留列';

my $nulls = Rakuish::Data::Table.new(
    :columns(<a>), :rows([%(a => Any), %(a => Any)]), :types({a => 'str'}));
my $nback = read-ipc(write-ipc($nulls));
is $nback.rows.elems, 2, '全 null 列也能往返';
nok $nback.rows[0]<a>.defined, '全 null 列读回来还是 null';

# ── 10. 规模：500 行不丢数据 ─────────────────────────────────────────
my @rows = (^500).map({ %(i => $_, s => ($_ % 7 ?? "r$_" !! Any)) });
my $big = Rakuish::Data::Table.new(:columns(<i s>), :rows(@rows),
                                   :types({i => 'int', s => 'str'}));
my Buf $bbytes = write-ipc($big);
my $bback = read-ipc($bbytes);
is $bback.rows.elems, 500, '500 行往返';
is $bback.rows[499]<i>, 499, '末行值正确';
is $bback.rows.grep({ !$_{'s'}.defined }).elems, 72, 'null 数量正确（500 里 72 个）';
# 500 行 × (int64 + int32 偏移 + 文本) ≈ 8KB；不写死具体数字（换个平台
# 压缩/对齐策略就可能变），只锁量级：既没退化成 JSON，也不是空壳。
ok 4_000 < $bbytes.elems < 20_000, "体积在合理量级（{$bbytes.elems} 字节）";

# ── 11. 接进 open-data / save-data ───────────────────────────────────
# Sys 有自己的 root（会话工作目录），所以集成测试的文件必须落在仓库里。
my $dir = $*CWD.IO.add("tmp/arrow-{$*PID}");
$dir.mkdir;
my $sys = Rakuish::Sys.new(:root($*CWD));
my Str $rel = $dir.Str;
save-data($sys, $rel ~ '/rt.arrow', $t);
ok ($rel ~ '/rt.arrow').IO.e, 'save-data 写出 .arrow 文件';
my $rt = open-data($sys, $rel ~ '/rt.arrow');
is $rt.rows.elems, 3, 'open-data 读回 .arrow';
is $rt.types<v>, 'num', '类型标签经 open-data 也保留';

# .feather 是同一种格式的旧名字
save-data($sys, $rel ~ '/rt.feather', $t);
is open-data($sys, $rel ~ '/rt.feather').rows.elems, 3, '.feather 走同一条路';

throws-like { open-data($sys, $rel ~ '/rt.arrow', :raw) },
    X::Rakuish::Unsupported,
    message => /'二进制'/,
    '--raw 对二进制文件明确拒绝';

done-testing;
