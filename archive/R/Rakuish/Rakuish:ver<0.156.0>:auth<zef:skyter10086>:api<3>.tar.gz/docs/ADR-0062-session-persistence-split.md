# ADR-0062：Session 拆分第三步 —— 快照 / store 簇与 EVAL 的词法包

- 状态：已实施（0.148.0 / SPEC V-352）
- 相关：ADR-0060（属性归属规则）、ADR-0061（第二步与访问器陷阱）、ADR-0022（快照）、ADR-0053（跨会话变量库）、SPEC §3.81（本条条款）、`t/86-persistence-split.t`
- 取证方式：Rakudo Star **v2026.11**（本机 Windows）；探针 `tmp/probe-eval-pkg.raku` + `t/42` / `t/81` / `t/18` / `t/45` 回归 + 全套件

## 1. 背景

0.147.0（ADR-0061）把 `Session.rakumod` 压到 3,630 行，诊断 / 渲染簇搬成了 `Session::Diagnostics`。当时留下的下一步判断是：`@.decls` / `%.state` / `@.out` / `@.history` 现在都是公开属性，**快照 / 历史簇**从「被私有状态卡住」变成可评估的下一刀。

本条选了其中语义最闭合的一半：**快照（ADR-0022）+ 跨会话变量库（ADR-0053）**。7 个方法 / 417 行搬进 `Session::Persistence`，`Session.rakumod` **3,630 → 3,250 行**（相对 0.147.0 的 diff 是 15 insertions / 395 deletions）。

## 2. 为什么是这一簇：同一条重放管线

两族命令看起来是两件事，实际共用同一条管线：

```
抓取状态（%!state + @.decls） → 分类（kind / value / nil / 其它）
  → 存盘（.raku 文本） → 恢复时剥前缀 → EVAL prelude + 值
```

- 快照：`save-snapshot` 调 `Rakuish::Snapshot::capture(%!state, @.decls, ...)`，`restore-snapshot` 把 `%snap<decls>` 填回 `@.decls`、按 `kind` 恢复 `%!state`；
- store：`!cmd-store` 用 `Rakuish::Store::load/save/entry/empty-store` 与 `Rakuish::Snapshot::classify` / `max-value-chars`，recall 时同样 `EVAL` prelude + 值。

两者还共享同一条**失败记账**：`@!restore-failed` 记录恢复失败的变量，`%!restored` 记录成功恢复的键值。拆开搬任何一半，另一半都要反向依赖新 role。

耦合测量（区间内 / 区间外引用次数）：

| 区间 | 行数 | 属性引用（内/外） |
|---|---|---|
| 快照 669–782 | 117 | `@!restore-failed` 1/1、`%!restored` 3/1、`%!state` 7/25、`$!index` 1/19、`$!snapshot-on` 2/0、`$!snapshot-path` 3/0、`$!sys` 2/21 |
| store 2689–2964 | 276 | `%!state` 3/29、`$!store-path` 2/0、`$!sys` 1/22 |

私有方法调用全部落在两个区间内部（快照只调自己的 `!init-snapshot`；store 一个 `self!` 都没有），朝外的边只有公开属性。这与 0.146.0 拒绝搬的 `@!decls`（5/33）、`%!state`（9/26）相反。

`!state-alias`（784–795）**不搬**：名字像快照，实际是 `!eval-raku`（1186 行调用）的求值状态别名，属于求值内核。

## 3. 决定性发现：role 里的 `EVAL` 落在 role 的包名下

恢复用户声明靠「剥前缀 + prelude 里 `my class Foo {...}`」。前缀来自 `self.WHAT.^name ~ '::'`，也就是 `Rakuish::REPL::Session::`。第一版把恢复代码整体搬进 role 后，探针给出：

```raku
role R1 { method m { EVAL 'my class Foo { has $.x }; Foo.new' } }
class C1 does R1 { }
C1.new.m.WHAT.^name;   # R1::Foo
```

`EVAL` 的词法包是**写 `EVAL` 的那个 role**，不是组合后的类。后果不是报错，而是静默错位：恢复出的 `Foo` 注册成 `Rakuish::REPL::Session::Persistence::Foo`，而后续值里的 `.raku` 仍写 `Rakuish::REPL::Session::Foo.new(...)`，剥前缀后对不上 → `X::TypeCheck::Assignment` 或「未定义」。

试过的替代：用 `package X { ... }` 包住 EVAL —— 块的值变成包对象而不是最后表达式，不能当恢复结果用。所以结论是硬约束：

> **凡是要让用户声明落在 `Rakuish::REPL::Session::` 下的 `EVAL`，必须留在 Session 类里。**

落法：Session 新增

```raku
method !eval-in-session(Str $code) { EVAL $code }
```

Persistence 的两处恢复调 `self!eval-in-session("no worries; do \{ $pre \n %( $body ) }")`。role 调类私有方法合法（ADR-0060 §2 实测），所以这里不需要公开任何东西。

## 4. 决定

1. 新增 `lib/Rakuish/REPL/Session/Persistence.rakumod`：`unit role Rakuish::REPL::Session::Persistence;`，7 个方法 / 417 行，`use Rakuish::Result; use Rakuish::Audit; use Rakuish::Snapshot; use Rakuish::Store;`。
2. `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence;`，第四条 `use` 写在 `unit` 之前。
3. 只公开两个属性：
   - `%!restored` → **`%.restored-info`**。它不能直接公开成 `%.restored`：属性访问器本身就是一个叫 `restored` 的方法，与已有公开方法 `restored` 同名只能留一个。改名只动内部，`restored` 的返回形状不变。
   - `@!restore-failed` → `@.restore-failed`。
4. 其余全部走既有公开面：`$.snapshot-on` / `$.snapshot-path` / `$.store-path` / `$.index` / `$.sys` / `%.state` / `@.decls`。
5. 恢复用 EVAL 留 Session（§3），新增 `!eval-in-session`。
6. `META6.json` provides 50 → 51（`t/51` 守着 provides 与 lib 下文件数一致）。
7. store 的注释头随方法一起搬走，Session 原位置留指针注释，避免「代码不在、说明还在」的漂移。

## 5. 没采用的方案

- **在 role 里 `EVAL`。** §3 的实测：用户类型会落到 role 包名下，前缀剥不干净。这是本条唯一一处「语言层不允许」，不是风格选择。
- **给 EVAL 套 `package Rakuish::REPL::Session { ... }`。** 块返回值变成包对象；且 `package` 是声明不是作用域表达式，拿不到恢复值。
- **把 `!state-alias` 一起搬。** 它服务 `!eval-raku` 的状态别名，搬走等于把求值内核的一角塞进持久化 role，名字相近但语义无关。
- **只搬 store、留下快照。** 两者共用 `@!restore-failed` / `%!restored` / `classify` / EVAL 管线，拆开会让 Session 与 role 互相反向依赖。
- **把 65 个属性全公开。** 与 ADR-0060 / 0061 同一理由：diff 会淹掉结构改动，`%!state`（29 处区间外引用）改名收益为零。

## 6. 不变量

- `Session.rakumod` < 3,300 行；Persistence 恰好含那 7 个方法，不含 `!state-alias` / `!eval-in-session` / 求值核心。
- Persistence 里**没有任何** `$!` / `@!` / `%!` 私有属性引用（只有 `EVAL` 串里的文本）。
- Session 里没有 `%!restored` / `@!restore-failed`；公开的是 `%.restored-info` / `@.restore-failed`。
- 四条 `does` 与四条 `use` 都在；`META6.json` 有 Persistence 条目。
- 行为：快照文件格式、`store` 的 list/save/recall/delete 输出、`restored` 返回值形状都不变；用户声明的类型名仍是 `Rakuish::REPL::Session::Foo`。

## 7. 结构守卫清单（`t/86-persistence-split.t`，41 条）

1. 文件都在；`unit role ...::Persistence` 头正确；Session 的四条 `does` 与四条 `use` 都在。
2. **反方向**：`!init-snapshot` / `save-snapshot` / `restore-snapshot` / `restored` / `!cmd-store` / `!store-candidates` / `!store-decl-src` 不在 Session，而在 Persistence；`!state-alias` / `!eval-in-session` 留在 Session 且不在 role。
3. 状态：`%.restored-info` / `@.restore-failed` 是公开属性；Session 无 `%!restored` / `@!restore-failed`；role 无任何类私有属性引用。
4. `cmp-ok $sess-lines, '<', 3300` —— 比现在的 3,250 宽松，比拆分前的 3,630 紧。
5. `META6.json` provides 51 条，含 Persistence。
6. 运行时：三个公开入口在实例上；新实例 `restored` 为空 Hash；`snapshot-path` 含 `session-`（TWEAK 里 `!init-snapshot` 确实跑过）；`store -l` / `store --help` / `store -d` 都走 role。

**测试环境坑（记一笔）**：`t/53-line-endings.t` 会抓 CRLF —— PowerShell 的 `WriteAllLines` 默认写 CRLF，生成 role 文件后必须归一为 LF，否则全套件会出现一条「只跟换行有关」的红。

## 8. 下一步

- 剩下的候选簇里，`!cmd-cells`（3027–3182）耦合最低：除 `$!sys` 外只依赖 `!split-argv`（留在 Session 可按名调），可作第四刀。
- 补全簇（3315–3560）与 recall / source / paste（2498–3026）都重度依赖 `@!history`（1/37、8/30）与 `%!state`，建议放到 `@.history` 的记账逻辑先收敛之后。
- 编号沿用先例：本版用掉 V-352 / `t/86`，ADR-0058（草案）的预留再顺延为 V-353 / `t/87-spawn-stream.t`。草案已连续三次让号 —— 下次可以考虑「草案不锁版本号，实施时才分配」，省掉每轮五处替换。
