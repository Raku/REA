# ADR-0059：管道透传 —— `! --pipe a | b`、`--pipefail`、`--stdin FILE`

- 状态：已实施（0.145.0 / V-349）
- 相关：[ADR-0024](ADR-0024-exec-stream.md)（`!` 流式与超时）、
  [ADR-0056](ADR-0056-engine-pipeline.md)（引擎内管道）、
  [ADR-0057](ADR-0057-parent-pipeline.md)（父进程交互式管道）、
  [ADR-0028](ADR-0028-streaming-exec-stdin.md)（`:&in-chunks` 背压）、
  V-901（不实现 bash 语法）
- 影响文件：`lib/Rakuish/Sys/Proc.rakumod`、`lib/Rakuish/REPL/Session.rakumod`、
  `lib/Rakuish/Eval/Server.rakumod`、`lib/Rakuish/Eval.rakumod`、
  `lib/Rakuish/CLI.rakumod`、`t/83-pipe.t`

---

## 1. 背景

ADR-0024 / 0056 / 0057 之后，`!` 与 `! a | b` 已经能跑，但**输出终点只有一种**：
捕获进 `Result`。这套捕获模型有三处硬限制：

| 限制 | 来源 | 后果 |
|---|---|---|
| 输出上限 1 MiB | `Sys::Proc.$.max-bytes` | 大输出被截断（`truncated=True`），用户只看到前缀 |
| `Handle.wait` 无条件累积 `raw-out` | `Sys::Proc` 的读循环 | 即使已经逐块显示，内存仍随输出增长到上限 |
| 整条管道共享一个 30 s 总时限 | `$.default-timeout-ms` | `make` / `tail -f` 这类长任务被误杀成 `124` |

另外，捕获模式下 `! cmd` 的 stdout 永远是**管道**：`git` 不上色、进度条退化成
整块。ADR-0007 的 `! --tty` 解决了这一点，但它是「把终端借给子进程」，
不产生 `Result`，也不能串联管道。

用户要的是第三种形态：**像 shell 一样把末段输出直接漏到终端**，同时保留
`!` 的 argv-only 与 `Result` 契约。本 ADR 补这一层。

## 2. 决定

新增三个元选项，与 `--tty` / `--capture` / `--timeout-ms` **同层**，
只解析第 1 段开头的 token，作用于整条管道：

```text
! --pipe make
! --pipe git log --oneline | head -n 20
! -P cat log.txt | findstr error
! --pipefail a | b | c
! --stdin input.txt wc -l
```

| 选项 | 语义 | 默认 |
|---|---|---|
| `--pipe` / `-P` | 末段 stdout / stderr **不捕获**，逐块直写当前进程的 stdout / stderr | 关（保持现有捕获） |
| `--pipefail` | 退出码取**最右**非零段（全部为 0 才是 0） | 关（取末段） |
| `--stdin FILE` | 首段 stdin 从文件流式接入（16 KiB 分块 + 背压），替代键盘 | 不设 |

### 2.1 `Result` 契约

`--pipe` 下输出已经在跑的时候写掉，因此：

- `out` / `err` 置空串，`streamed = True` —— 与 ADR-0024 的流式约定一致，
  `render` 不会重放（`Session.render` 只在 `err.chars` 时打印）。
- `ok` / `code` / `value` / `elapsed` 照旧；`value<stages>` 仍是每段退出码。
- **启动失败是例外**：`start-failed` 时没有任何输出，`err` 原样保留给 `render`。
- `--pipe` 与 `--capture` **互斥**：同时出现直接 `127` +
  「透传就是不捕获」。不让两个相反意图静默二选一（V-115）。

### 2.2 执行位置

| 模式 | 谁执行 | 原因 |
|---|---|---|
| 交互 REPL（worker） | **父进程**，经既有 `pipe-exec` 中间帧 | 引擎的 `$*OUT` 是协议管道，直写会冲垮 NDJSON |
| `-e` / 脚本 / stdin 管道（单进程） | **本进程**，`$*OUT` 就是 stdout | 没有协议流，本地 `pipe-exec` 直写即可 |

两条路径复用同一个 `Sys.pipe-exec`（`no-capture` 开关），不另写一套直写逻辑：

- Session → `pipe-handler` →（worker）`pipe-exec` 帧 → 父进程 `CLI` hook；
- 无 hook（单进程）→ `$!sys.pipe-exec(@stages, :no-capture, :&on-out, :&on-err)`，
  `on-out` 写 `$*OUT.print + flush`，`on-err` 写 `$*ERR`。
- worker 模式下**没有**执行器时明确 `127`，绝不把原始输出写进协议管道。

单条命令 `! --pipe cmd` 统一按「一段的管道」走同一路径 —— 为此把
`spawn-pipeline` 的段数下限从 2 放宽到 1。

### 2.3 `--pipefail`

`spawn-pipeline` 原先只记末段码。现在逐段记录：

```raku
my Int $last-code = 0;   # 末段
my Int $fail-code = 0;   # 遍历中最后一个非零段
...
my Int $code = $pipefail ?? $fail-code !! $last-code;
$code = 124 if $timed-out;
```

`3|0` 在 `--pipefail` 下返回 3、默认返回 0；`0|4|2` 返回 **2**（最右非零）。
超时仍统一 `124`，取消 `137`，启动失败 `127` —— 这些整体状态优先于段码。

`--pipefail` 对捕获式管道同样生效（不是 `--pipe` 专属）。

### 2.4 `--stdin FILE`

- 路径在 Session 侧用 `Sys.resolve` 解析成**绝对路径**（root 沙箱 + 会话 cwd）；
  worker 模式下真正读文件的是父进程，所以不能留相对路径。
- 缺参 / 解析失败 / 文件不存在 → `127` + 明确文案，不静默回落键盘。
- 读取走 `spawn` 新增的 `:stdin-file`：内部生成器 `open :bin` + 16 KiB 分块，
  写一块 `await` 一块（背压），下游提前关 stdin 就停；**不整份读入内存**。
- `:in` / `:&in-chunks` / `:stdin-file` 三来源互斥。

## 3. 协议

`pipe-exec` 中间帧新增四个**可选**键，旧父进程不发也不会收到：

| 键 | 类型 | 含义 |
|---|---|---|
| `no-capture` | `true` | 末段输出不捕获，父进程直写终端 |
| `pipefail` | `true` | 退出码取最右非零段 |
| `stdin-file` | 绝对路径 `Str` | 首段 stdin 来源 |
| `timeout-ms` | `Int` | 0 = 不设总时限 |

`PROTOCOL-VERSION` 保持 **2**，没有破坏性变更。hook 调用保持向后兼容：
无附加选项时仍按老签名 `$hook(@stages.List)` 调用（旧闭包没有 slurpy）。

## 4. 诚实边界：这是**数据层**透传

`--pipe` 不改变子进程对 stdout 的认知：

- 子进程的 stdout 仍是**管道**，`isatty = false`：颜色 / 进度条 / TUI 仍不成立。
  要 TTY 语义请用 `! --tty`（ADR-0007），两者目的不同。
- 所谓「直写终端」是 Rakuish 这一侧把**读到的块**立刻写到自己的 stdout，
  不是把终端 fd 交给子进程。Windows 上没有可注入的 fd，Rakudo `Proc::Async`
  也不支持句柄注入 —— 真 dup2 / PTY 明确不做（ADR-0056 §2 同结论）。
- 因此 `--pipe` 解决的是「不截断、不累积、不误杀长任务」，不是「让子进程
  以为自己在终端里」。

## 5. 与现有条款的关系

| 现有 | 关系 |
|---|---|
| ADR-0024 | 捕获式 `!` 的 `--capture` / `--timeout-ms` / `--no-timeout` 全部不变；`--pipe` 默认 `timeout-ms=0`，显式 `--timeout-ms N` 仍生效 |
| ADR-0056 / V-347 | 引擎内管道的切段、段间泵、stderr 不合流不变；只多三个开关 |
| ADR-0057 / V-348 | `--tty` + 管道仍由父进程执行、末段捕获；`--pipe` 是另一条正交入口（不继承终端 stdin，默认无超时） |
| ADR-0028 | `--stdin` 复用同一套 `in-chunks` 生成器 + `await write` 背压 |
| V-901 | 只是 `!` 元选项，不新增管道语法、不拼 shell 串 |
| V-115 | `--pipe` / `--capture` 冲突显式报错，不猜 |

## 6. 拒绝过的方案

| 方案 | 拒绝理由 |
|---|---|
| dup2 / 内核管道直连 | `Proc::Async` 句柄不可注入；要 NativeCall + 平台分支，成本与风险不成比例 |
| 伪造 `isatty` / 内置 PTY | 需要 `pty-exec` 的整套终端语义，与「不捕获」相悖；`--tty` 已覆盖 |
| 默认开启透传 | 会破坏现有 `Result.out` 契约与 `Out[n]`；默认捕获，显式 `--pipe` |
| `--pipe` + `--capture` 共存 | 两个相反意图，静默取一个就是「入口在猜」 |
| 把透传做成新语法（`|>` 等） | V-901 不松动；元选项与 `--tty` 同层，零 grammar 代价 |
| `--stdin` 整份读入再喂 | 大文件直接吃掉内存；分块 + 背压才是与 ADR-0028 一致的口径 |

## 7. 测试

`t/83-pipe.t` 第 ⑤ 组（新增）：

- `--pipe --capture` 互斥 → `127`；
- `--pipefail`：`3|0 → 3`、默认 `3|0 → 0`、`0|4|2 → 2`；
- `--stdin`：读临时文件得到预期字节；文件不存在 → `127`；
- fake `pipe-handler`：收到 `no-capture` / `pipefail` / `stdin-file`（绝对路径）/
  `timeout-ms=0`、2 段，回包 `out == ''` 且 `streamed`；
- `-e` 端到端：`! --pipe … | …` 的输出出现在 stdout。

既有 53 条断言全绿；`t/41`（协议）、`t/51`（版本一致性）、`t/52`（模块加载）
无回归。

## 8. 版本

- 0.145.0 / V-349 / ADR-0059，协议仍为 v2。
- 刻意不做：ADR-0058 草案里的 C 方案（公开 `sys.spawn` 流式 API），
  本 ADR 只补 `!` 这一层的透明性，不新增编程接口。
