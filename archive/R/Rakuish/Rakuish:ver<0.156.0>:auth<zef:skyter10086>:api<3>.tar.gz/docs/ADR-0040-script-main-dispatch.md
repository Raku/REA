# ADR-0040 · 脚本模式的 MAIN 分派交给 RUN-MAIN，而不是自己解析参数

- **日期**：2026-11-23
- **对象**：0.118.0（`Session.eval-script` + Kernel 的 `script` 通道 + CLI 脚本入口）
- **状态**：**已实施**（t/72 42 条，双平台子进程真跑）
- **输入**：用户提出「让脚本模式也支持 MAIN 分派（RUN-MAIN 在 EVAL 里拿不到
  mainline，得另找方案）」
- **相关**：SPEC V-311（§3.50）、V-306（§3.45 `source`）、
  [ADR-0013](ADR-0013-kernel-as-sole-entry.md)（Kernel 是唯一入口）

## 1. 问题

`rakuish 文件 参数` 把整份源码当一个 cell `EVAL`，因此与 REPL 共用词法环境
（`sys` / `repl` / DSL）。代价是 **`sub MAIN` 永远不被调用**：Rakudo 的
CLI 分派绑在 mainline 上，只在真正的主程序编译单元里生效。0.114.0 起给一行
提示，但提示不是功能。

要同时保住「预加载 DSL」和「MAIN 语义」，有三条路：

| 方案 | 问题 |
|---|---|
| 子进程 `raku 文件 参数` | 丢掉 DSL / 会话 Sys；多一次 Rakudo 启动；`sys` 变成另一个实例 |
| 自己解析 argv + 调 `MAIN` | 必须重写类型强转、null 候选处理、`sub USAGE`、`%*SUB-MAIN-OPTS`…… 迟早与 Rakudo 走偏 |
| **显式调用 Rakudo 的 `RUN-MAIN`** | 需要拿到 EVAL 里的 `&MAIN`，且让 `RUN-MAIN` 的调用者词法域是脚本顶层 |

## 2. 决定

在**源码末尾追加一条尾巴**，在同一个 EVAL 里把 `&MAIN` 交给 `RUN-MAIN`：

```raku
; (::('&MAIN') !~~ Failure) && RUN-MAIN(::('&MAIN'), Nil);
```

三个关键点：

1. **尾巴在 EVAL 内部**（不是 Session / CLI 调用完再分派）。`RUN-MAIN` 用
   `callframe(1).my` 取调用者词法域里的 `&ARGS-TO-CAPTURE` / `&GENERATE-USAGE`
   / `&USAGE` / `&MAIN`。追加在源码末尾时，`callframe(1).my` 正好是脚本顶层：
   脚本自定义的 `sub USAGE` 会被采用，顶层 `my %*SUB-MAIN-OPTS` 的动态作用域
   也还在。放到调用方就全丢。
2. **软查找 `::('&MAIN')`**：没有 MAIN 时返回 `Failure`。不能绑到 `my &m`
   （`Type check failed: expected Callable`），也不能让它闲置 sink（程序结束
   时冒 "Earlier failure"）。先 `~~ Failure` 认领再决定是否分派。
3. **`$*PROGRAM-NAME` 用绝对路径**：Rakudo 2026.11 的默认 USAGE 生成器在
   程序名没有目录成分时会在 `strip_path_prefix` 里抛
   `rindex search target requires a concrete string, but got null`
   —— `raku foo.raku` 这种裸文件名会直接崩。设成 `$file.absolute` 绕开，
   与「脚本相对 IO 以脚本为基准」也一致。

Kernel 增加 `kind<script>`：与 `source` 共用 `allow-source` 策略门与审计口径
（只记指纹 / 字节数），但不走续行 / `!` / 会话命令那条路 —— 它是一次性程序，
不是一格。`capabilities.request-kinds` 随之加 `script`。

## 3. 输出：脚本不捕获 `$*OUT`

REPL 的 `Out[n]` 依赖捕获；脚本不需要。捕获模式实测：`MAIN` 里先 `say` 再
`exit 3`，退出码传出去了，但**已经打印的内容随捕获缓冲一起丢**。所以
`eval-script` 走 `set-code-stream(True)` 直通 stdout；`-e` / REPL 不受影响。

## 4. 口径（与 `raku 文件` 对齐，包括不直觉的部分）

- 顶层语句先执行，MAIN 后执行，MAIN 能看到顶层 `my`（实测 `raku` 就是这样，
  不是「有 MAIN 就跳过 mainline」）；
- 默认**命名参数必须在位置参数之前**（`42 --name=x` 的 `--name` 会被当作第二个
  位置参数）；改这个默认要 `my %*SUB-MAIN-OPTS = ...`；
- 参数不匹配：USAGE 到 stderr、退出码 2；`--help`：USAGE 到 stdout、退出码 0；
- `sub USAGE` 取代默认用法；`multi MAIN` 多候选、字面量首参、`Bool` 标志位、
  类型强转全部由 Rakudo 负责。

## 5. 不做的事

- **不给 `source`（会话内跑脚本）上 RUN-MAIN**：用法错误分支会 `exit 2`，
  那是真退出进程 —— 会把求值引擎带走。`source` 保持 0.114 的「按位置参数
  调用 MAIN」，需要完整分派就用 `rakuish 文件 参数`。
- **不拦截 `--help` / `--version`**：`--version` 是 `rakuish` 自己的启动参数
  （进不了脚本分支）；`--help` 交给 RUN-MAIN，与 `raku 文件 --help` 一致。
- **不重写 `%*SUB-MAIN-OPTS`**：Rakudo 2026.11 里它需要 `my` 声明才能赋值，
  与独立脚本一致；Rakuish 不做额外魔法。

## 6. 验证

t/72（42 条，真实子进程）：顶层与 MAIN 的顺序 / 词法可见性、`Int` 强转、命名
参数与默认值、命名参数位置顺序、`multi MAIN` 字面量分派与候选列表、`Bool`
标志、缺参 USAGE 与脚本名、`--help`、`sub USAGE`、`exit 3` 且先前输出保留、
无 MAIN 的脚本零变化、未闭合结构仍拒绝、DSL 在 MAIN 内可用、
`kind<script>` 的 403 策略与 capabilities 声明。
