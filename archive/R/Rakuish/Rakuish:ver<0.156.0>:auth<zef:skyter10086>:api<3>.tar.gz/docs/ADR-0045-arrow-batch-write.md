# ADR-0045 · Arrow 写侧支持多批与流式

- **日期**：2026-11-24
- **对象**：0.121.0（`Rakuish::Data::Arrow` 的写入路径）
- **状态**：**已实施**
- **输入**：用户问「多批 / 流式写这个能实现一下吗」
- **相关**：SPEC V-317、[ADR-0038](ADR-0038-arrow-ipc.md)（自研读写）、
  [ADR-0041](ADR-0041-arrow-read-via-package.md)（读侧）、
  [ADR-0044](ADR-0044-arrow-read-routing.md)（读侧分流）

## 1. 原来的写侧只有一条路

`write-ipc($t)` 的顺序是：

```
fields-of(Table)  → 逐列 encode-column  → 拼成一个 body
                 → Schema 消息 + 一个 RecordBatch + Footer  → 一个 Buf
```

三个问题：

1. **峰值内存 = 表 + 整份文件**。50 万行 × 3 列 ≈ 表 200 MB，文件 15 MB；
   写 1000 万行时这条路的账根本算不过来。
2. **只有一个批**。Arrow 的价值之一是可并行扫描（每个 RecordBatch 是独立
   单元），单批文件把这个优势抹平了。
3. **没有失败保护**。`spurt` 直接写目标路径，中途抛错就留下半截文件 ——
   读者拿到的是"合法的 ARROW1 头 + 断掉的 body"，读侧只能报越界。

## 2. 决定：拆成 start / add-batch / finish

`IpWriter` 只管三件事：写 Schema（一次）、加批（多次）、收尾（Footer 或
什么都不做），sink 可以是内存 `Buf`（`write-ipc`）或文件句柄
（`write-ipc-file` / `write-ipc-stream`）。

```
                    ┌── sink = Buf      → write-ipc 返回 Buf
IpWriter.start ─────┤
IpWriter.add-batch ─┼── sink = IO::Handle → 写 <path>.part
IpWriter.finish ────┘                     → rename 到目标
```

对外 API：

| 入口 | 内存行为 | 适用 |
|---|---|---|
| `write-ipc($t)` | 表 + 输出 Buf | 小表 / 要 Buf 继续用 |
| `write-ipc($t, :batch-size(N))` | 表 + 一批的 body | 想要多批但表已在内存 |
| `write-ipc-file($t, $path, :batch-size(N))` | 表 + 一批 | 落盘，原子替换 |
| `write-ipc-stream($rows, $path)` | 一批（不物化表） | 大/无界数据 |

## 3. 流式写：schema 只能推断一次

流式的第一批必须建一次 `Table`（复用它的列推断与类型推断，保证和
`save-data` 从 rows 建表的行为一致），之后每批复用这份 schema。

这带来一个硬约束：**类型不能回改**。于是每批编码前必须校验。为什么不能
依赖 `encode-column` 自己报错？因为 Raku 的 cast 太宽容：

```raku
say "abc".Int;      # 0  ← 不抛
say "abc".Num;      # 0e0
```

流式把 `"abc"` 写进 `int64` 列，文件本身合法、读回来是 `0` —— 数据已经毁了
但没有任何信号。所以 `check-batch` 逐列核类型，抛
`X::Rakuish::Arrow: 流式写第 7 行的列「id」类型对不上：schema 按首批定为 int，
这行是 Str（"abc"）……`。

嵌套值（`Positional` / `Associative`）同样拒绝：`fields-of` 的单批路径在
0.120.0 已经这么做了（ADR-0043），流式沿用同一口径。

## 4. 原子落盘

```raku
my $part = $target.parent.add($target.basename ~ '.part');
my $fh = $part.open(:w, :bin);
LEAVE { $fh.close if $fh.opened; $part.unlink if !$done && $part.e }
writer($fh);
$fh.close;
$target.unlink if $target.e;
$part.rename($target);
```

要点：
- 失败路径（类型冲突、磁盘满、Ctrl-C）不会碰到目标文件；
- `.part` 由 `LEAVE` 清掉，t/77 断言「目标不存在、`.part` 也不存在」；
- 先 `unlink` 目标再 `rename`：Windows 的 `rename` 在目标存在时会失败
  （POSIX 会覆盖），两边行为统一到这里。

## 5. 三个 Raku 坑（都踩了）

| 写法 | 结果 | 正确写法 |
|---|---|---|
| `$x =:= IterationEnd` | **False**（`.WHAT` 是 `Mu`，但 `=:=` 不比同一枚举值） | `$x ~~ IterationEnd` |
| block 里 `return unless ...` | **non-local**：直接从外层 `sub` 返回（第一批写完整个函数就退，文件没落地） | block 内用 `if` 包裹 |
| `my $seq = ($first, \|$iter)` | `Iterator` 被 slip 成元素，`$t` 拿到 `List`，`.rows` 炸 | 手写 `pull-one` 循环 |

第一条还有一个反直觉的细节：`IterationEnd.raku` 打印 `IterationEnd`、
`.WHAT.^name` 打印 `Mu`，而 `=:=` 对它俩都返回 False —— 只有 `~~`（或
`===` 之外的值比较）可靠。

## 6. 验证

- 5 万行 × 3 列：单批 2.65 s / 10 批 2.70 s（多批几乎零额外开销）。
- 50 万行 × 3 列，流式 100 批：23.9 s、14.9 MB。
  首版 30.5 s —— 因为每批都 `Table.new` 重推一次类型，去掉后省 22%。
- pyarrow 26：`num_record_batches` 分别 3 / 4 / 5 / 100，行数与列类型全对。
- t/77 46 条：批数边界、文件/流格式、`save-data` 透传、行流/表流、
  类型冲突、嵌套、空流、表流列不一致、失败不留文件。

## 7. 没做的

- **压缩（BodyCompression）**：`Arrow::IPC` 0.1.0 不解压也不报错，写侧
  同样不做 —— 宁可没有，也不要产出别人读错的字节。
- **嵌套列写出**：`list` / `map` 仍拒绝（README 里写明能力边界），
  要写先 `to-json` 成字符串列。
- **并发批写**：多线程/多进程同时写一个 `.part` 会互相覆盖。当前没有并发
  写同一路径的用例，真需要时按 pid 生成 `.part` 名字。
