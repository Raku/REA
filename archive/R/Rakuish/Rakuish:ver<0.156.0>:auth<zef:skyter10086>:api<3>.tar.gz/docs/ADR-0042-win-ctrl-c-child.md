# ADR-0042 · Windows 上 Ctrl-C 只收外部命令，不重启引擎

- **日期**：2026-11-24
- **对象**：0.119.0（`!` 外部命令的中断路径）
- **状态**：**已实施**（真控制台 ConPTY 三场景探针全过）
- **输入**：用户报「Windows 下运行超时程序会卡死，Ctrl-C 之后输入卡顿、字符错位」
- **相关**：SPEC V-314、[ADR-0023](ADR-0023-interrupt.md)（求值期 Ctrl-C 归父进程）、
  [ADR-0010](ADR-0010-job-control-feasibility.md)（Ctrl 事件与作业控制）、
  [ADR-0039](ADR-0039-win-job-subtree.md)（引擎子树回收）

## 1. 现象与实测

`! ping -n 30 127.0.0.1` 跑起来之后按 Ctrl-C，旧行为是：**引擎被杀 → 重启**，
耗时 4~5 秒，终端里出现「已中断当前求值 / 引擎已重启 / 会话状态已丢失」，
`Out[n]` 从 1 重新计数。这 4~5 秒里敲的字被控制台缓存，回来时行编辑器按
「光标在行首」重绘 —— 用户看到的就是「卡顿 + 字符错位」。

实测（`tools/ctrl-c-win.py` 场景一/三，ConPTY 真控制台）：`loop { }` 走这条路
是对的（Raku 纯 VM 循环不吃 SIGINT，只能外部杀）；但 `!` 命令完全不必 ——
它有一个可以单独收掉的子进程。

## 2. 为什么子进程收不到 Ctrl-C

Windows 没有 POSIX 前台进程组。Raku 的 `Proc::Async` 给子进程建了**独立进程组**，
控制台按下 Ctrl-C 时 `CTRL_C_EVENT` 只到宿主与引擎，**到不了命令**。
引擎侧的 `signal(SIGINT).tap` 因此也等不到（同一原因），旧代码干脆把信号吞掉，
父进程只好 SIGKILL 引擎 —— 这就是「一次中断丢整场 + 慢 4 秒」的来源。

## 3. 决定：命令级 Job Object + child 帧

- **引擎**（`Sys::Proc.spawn`）：spawn 成功、拿到 pid 后调用 `child-cb`；
  `Eval::Server` 把它变成协议帧 `{"event":"child","pid":N}`。
- **前端**（`Eval::Client`）：收到 child 帧就 `CreateJobObject` +
  `OpenProcess` + `AssignProcessToJobObject`，把**这一条命令**收进独立 job
  （Windows 8+ 支持嵌套 job；引擎自己那个 job 不受影响）。
- **Ctrl-C**：`TerminateJobObject(命令 job)` —— 命令与它派生的孙进程一起收掉，
  引擎继续活着，`exec` 正常返回。
- **收尾**：终帧把 `code` 改成 **130**（128 + SIGINT）、`ok=false`，
  语义是「用户中断」，不是「程序自己失败」。
- **兜底**：发出终帧前 3 秒还没回来（极端情况：job 建不起来、或命令把
  TerminateJobObject 也拖住），才回到老路径杀引擎重启 —— 保证不会永久卡死。

## 4. 明确不做的

- **不靠子进程自己死**：它收不到 `CTRL_C_EVENT`（见 §2），实测等 8 秒也不退。
- **不在引擎里杀**：引擎也收不到信号，tap 不触发；内核里没有可用的信号入口。
- **不改 Raku 求值路径**：`sleep 60` / `loop {}` 没有子进程，仍按 ADR-0023
  杀引擎重启；否则 `loop {}` 根本停不下来。
- **不动 `! --tty`**：直通期间 Ctrl-C 归前台子进程（ADR-0010 §3.3），
  `$!tty-interactive` 原样保留。

## 5. 代价与边界

- 每条 `!` 命令多一次 `CreateJobObject / OpenProcess / Assign / Close`，
  往返在微秒级；命令结束就关句柄，孙进程不会因为句柄泄漏而残留。
- `!` 命令的 stdin 仍是管道（不是控制台），TUI 类程序要用 `! --tty`。
- 非 Windows 不调用 `child-cb`；job 建不起来（或权限不足）时静默退回旧路径，
  不因为「优化没生效」而拒绝执行命令。

## 6. 验证

`tools/ctrl-c-win.py` 新增场景三（真 ConPTY）：

```
ready=True  killed_engine=False  prompt_back=True  exit_130=True  state_survived=True
```

场景一（`loop { }` 仍重启、快照恢复）与场景二（`! --tty` 子进程收 SIGINT、
宿主存活）同时复跑通过。
