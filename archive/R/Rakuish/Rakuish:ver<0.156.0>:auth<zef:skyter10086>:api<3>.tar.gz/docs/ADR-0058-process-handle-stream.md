# ADR-0058：进程句柄与流式 stdout（`sys.spawn`）

- 状态：**草案**（未实施，待评审；本文件只定接口与边界，不含代码）
- 日期：2026-11-27
- 相关：[ADR-0024](ADR-0024-exec-stream.md)（`!` 流式与超时）、
  [ADR-0026](ADR-0026-structured-pipe.md)（`Stream` 与 `stream.exec`）、
  [ADR-0028](ADR-0028-streaming-exec-stdin.md)（`:&in-chunks` 背压）、
  [ADR-0056](ADR-0056-engine-pipeline.md) / [ADR-0057](ADR-0057-parent-pipeline.md)（`!` 管道）、
  V-136（jobs）、V-140（`_` / `Out[n]`）、V-901（不实现 bash 语法）
- 影响文件（预计）：`lib/Rakuish/Sys/Proc.rakumod`、`lib/Rakuish/Sys.rakumod`、
  `lib/Rakuish/DSL.rakumod`、`SPEC.md`（新增条款，号在实施时分配）、`docs/MANUAL.md`、
  `docs/DEVELOPMENT.md`、`t/spawn-stream.t`（文件号在实施时分配）

---

## 1. 背景

### 1.1 现状

| 层 | 现在的形状 | 缺口 |
|---|---|---|
| 用户输入 `!` | 捕获成 `Result`；TTY 下靠 `on-out` 回调逐块显示（ADR-0024） | 拓扑固定线性；输出终点是终端或 `Out[n]`，不能插 Raku 变换 |
| `Stream.exec` | 只解决 **stdin 侧**：惰性记录流写进子进程（ADR-0026 / ADR-0028） | stdout 侧没有公开 API |
| `Sys` 公开面 | `exec` / `pipe-exec` / `tty-exec` / `pty-exec` / `bg-exec` | 全部以 `Result` 收尾，拿不到「还在跑的输出」 |
| `Sys::Proc.spawn` | 已返回 `Handle`，带 `.stdout`（Supply）、`.cancel`、`.wait` | **只在内部用**（管道泵、bg-exec）；未公开 |

结果是：`cmd | Raku 变换 | cmd`、边读边算、按条件早停、一段输出喂给多个消费者，
这些 shell 管道的**组合能力**在 Raku 层写不出来。用户只能退回到 `!` 的固定
线性拓扑，或者先 `Result.out` 全量收完再处理（1MB 截断、内存翻倍）。

### 1.2 两条互不替代的轴

前一轮评估把候选改动分成两类，本 ADR 只做第二类：

| 轴 | 内容 | 归属 |
|---|---|---|
| **透明性** | `!` 的末段直通终端、不累积、idle 超时、`pipefail` | A/B 方案（另议，不在本 ADR） |
| **组合性** | 把活着的进程 stdout 交给 Raku 代码，任意拓扑 | **C 方案（本文）** |

两者不能互相替代：C 拿不到终端透明性（子进程看到的 stdout 永远是管道，
`isatty=0`，颜色 / 列宽 / TUI 仍然要靠 `! --tty`）；A/B 拿不到任意拓扑。
完整形态是「手敲走 `!`，编程走 `sys.spawn`」。

---

## 2. 决定

### 2.1 公开 `sys.spawn`，与 `exec` 显式二选一

```raku
my $h = sys.spawn('git', 'log', '--oneline');   # → Handle，不累积
for $h.stdout-lines -> $line {
    last if $line ~~ /fix/;                     # 早停：下面必须 cancel
}
$h.cancel;                                      # 幂等
my $r = $h.wait;                                # Result：ok/code/err/streamed
```

| 项 | 决定 |
|---|---|
| 返回类型 | `spawn` → `Proc::Handle`；`exec` → `Result`。**不存在「按参数返回不同类型」** |
| 默认累积 | **不累积**（`Result.out` 为空串、`streamed=True`）；要留全文显式 `:capture` |
| `:capture` | 沿用 `max-bytes`（默认 1MB）截断；与流式消费并存，但会多一份内存 |
| 超时 | `spawn` **默认 `timeout-ms => 0`**（不设总时限），调用方自己 `cancel`；显式传值才生效 |
| 命名 | 只公开 `sys.spawn` 方法，不新增顶层 sub，不新增语法 |

**为什么默认不累积。** 流式 API 的第一诉求是「数据不落在 Rakuish 手里」。
默认累积等于把 1MB 锁死成上限、再加一份与消费者并行的内存；`exec` 已经承担
「要一份完整输出」的场景，`spawn` 再默认累积就是重复。

**为什么默认不超时。** `exec` 的总时限是防「一条命令卡死 REPL」；`spawn` 的
调用方本人就在循环里，随时能 `cancel`，再叠一个整段 wall-clock 只会把
`tail -f`、`make` 这类长任务误杀。这是与 `exec` 有意的口径差异，必须写进
MANUAL，不能让用户以为是 bug。

### 2.2 stdout 是**拉模型**（惰性 Seq），不是 `Supply`

| 方案 | 背压 | 结论 |
|---|---|---|
| `Supply`（push） | 无：`.tap` 不阻塞生产者，`yes` 几秒打爆内存 | 只做事件通知，不做数据通道 |
| `Channel` 直出 | 无界缓冲、可多消费者、EOF 语义弱 | 不公开，契约不稳 |
| **惰性 `Seq` / 迭代器** | `pull-one` 阻塞到有数据 = 真背压 | **采用** |

公开成员：

| 成员 | 形状 | 契约 |
|---|---|---|
| `.stdout-chunks` | `Seq` of `Buf` | 块大小由 `Proc::Async` 决定，不承诺固定；块边界可切在多字节字符中间 |
| `.stdout-lines` | `Seq` of `Str` | 按 `\n` 懒切、去 `\r`；跨块的半行留到下一块；EOF 交出残行 |
| `.stderr-lines` | `Seq` of `Str` | 独立缓冲，**不自动合并**到 stdout |
| `.pid` | `Int` | 供日志 / Job / 诊断 |
| `.done` | `Bool` | promise 是否已结束 |

`.stdout-lines` 必须按**字节**保留残行再解码，不能对半截 UTF-8 调 `.decode`——
这是 Windows 与 CJK 输出的必踩项，实现时写进测试。

### 2.3 生命周期与收尾

| 规则 | 内容 |
|---|---|
| `wait` | 幂等，返回 `Result`，**永不抛**（与 `exec` 同契约） |
| `cancel` | 幂等；只在 running 时 `Proc.kill`（POSIX 默认 TERM），Windows 走 terminate；`code` 非零（POSIX 128+signal） |
| 未收尾 | 句柄没 `wait` 就丢弃 = **未定义行为**；提供块形式兜底 |
| 块形式 | `sys.with-spawn(...) -> $h { … }`：`LEAVE` 里 `cancel unless $h.done`，正常结束不 kill |
| 会话结束 | 引擎退出 / 会话销毁时统一 reap（复用现有 jobs 收尾路径） |
| 审计 | 每次 `spawn` 记一条，字段白名单与 `exec` 一致；**不记输出内容** |

### 2.4 显示、`Out[n]` 与 `_`

- REPL 里一行 `sys.spawn(...)` 的返回值是 Handle：display 显示
  `#<proc 1234 git log> running` 摘要，`Out[n]` 照常占号（它是值），`_` 指向 Handle。
- `Result` 不会自动进 `Out[n]`：要值就 `say $r.out` 或显式把 `$r` 写出来。
- 失败格不占 `Out[n]` 的既有规则不变。

### 2.5 边界

| 场景 | 行为 |
|---|---|
| `isatty` | stdout **恒为管道**（`isatty=0`）；颜色 / 宽度 / TUI 一律走 `! --tty` 或 `pty-exec` |
| 交互式引擎内 | 可用。消费循环在引擎里跑，`say` 走正常显示；**不新增协议帧**，协议仍 v2 |
| Notebook | 可用（纯代码路径）；无终端，交互式程序不可用 |
| `input()` / 前台键盘 | 不可用：stdin 归属见 §5 未决项 |
| Windows | 可用；无 PTY；TERM 语义为 terminate，退出码由系统给出 |
| 与 `jobs` 表 | **不混用**：`spawn` 不进 `Sys.jobs`（那是 `bg-exec` 的记账），避免两套所有权 |

---

## 3. 与现有条款的关系

| 现有 | 关系 |
|---|---|
| V-901 / ADR-0026 | 不新增 `\|>` 或其它管道语法；`sys.spawn` 是方法调用，不是语法糖 |
| ADR-0024 | `!` 的 chunk 帧、`--capture`、`--timeout-ms` **完全不变**；本 ADR 不碰入口层 |
| ADR-0028 | `:&in-chunks` 已实现「生成器写 stdin + await 背压」；本 ADR 是它的 stdout 对偶 |
| ADR-0056 / 0057 | `!` 管道的触发条件、段间泵、退出码取末段、Ctrl-C 归组全部不变 |
| V-136 | 不把 `spawn` 塞进 jobs 表；两套生命周期不混 |
| V-140 | `_` / `Out[n]` 规则不变；只多一种「值是 Handle」 |
| ADR-0021 | 引擎崩溃会留下孤儿进程：句柄随引擎死亡失效，父进程重启后无法回收——写进已知边界，不承诺跨崩溃存活 |

> **编号规则（0.149.0 起）**：本 ADR 是草案，**不再预占条款号与测试文件名**。
> 0.146.0 / 0.147.0 / 0.148.0 三轮里它被顺延了三次（V-350→V-351→V-352→V-353），
> 每次都要改五处，而每次实施都还没发生。现在改为「实施时取当时的下一个空位」，
> 由实施者一次性分配，草案本身不跟着动。
**版本与协议**：纯新增 API，不需要升协议版本；实现时按次版本（0.145.0）升，
SPEC 新增条款（号在实施时分配，取当时的下一个空位），回归放 `t/spawn-stream.t`（同上）。

---

## 4. 拒绝过的方案

| 方案 | 拒绝理由 |
|---|---|
| 只暴露 `Supply` | push 不背压，`yes`/大日志直接打爆内存；`Supply` 只保留作事件通知 |
| 直接公开内部 `Channel` | 多消费者、无界缓冲、EOF 语义都要重新定义；契约不稳 |
| `exec` 同时能返回 `Result` 或 `Handle` | 静默二选一，违反「入口不猜」（V-115）；调用方永远猜不到拿到什么 |
| 用 `! --stream` 代替 | `!` 是用户输入层，不是编程 API；无法在段间插入 Raku 逻辑 |
| 公开 `spawn-pipeline` 做任意拓扑 | 为假想需求设计；等出现真实的多阶段用例再加 |
| 在 `spawn` 里默认捕获 | 1MB 上限 + 双份内存，与流式目的相反 |
| 段间改 dup2 内核管道 | Rakudo 的 `Proc::Async` 句柄不可注入；要 NativeCall + 平台分支，成本与风险不成比例（ADR-0056 §2 同结论） |

---

## 5. 未决问题（评审点）

1. **默认超时**：`spawn` 用 0（本文建议）还是沿用 `exec` 的 30s？
2. **REPL 遗留句柄**：会话结束时直接 `cancel`，还是先告警一次？（建议 cancel + 审计记一条）
3. **stdin 入口**：是否顺手公开 `:in` / `:&in-chunks`？内部已支持，公开成本低，
   但会与 `stream.exec` 的职责重叠——需要先定「谁负责喂数据」。
4. **Windows 分块**：`Proc::Async` 在 Windows 的 stdout 分块粒度与 EOF 时机需要
   实测；`.stdout-lines` 的残行逻辑按字节实现是否足够。
5. **多消费者**：是否提供 `.tee(*@targets)`？（建议不做，用户自己写循环）
6. **审计粒度**：`spawn` + `wait` 只记一条（建议）还是两条？

---

## 6. 实施计划（获准后）

### P1：最小可用

- `Sys.spawn` 公开（薄封装内部 `Sys::Proc.spawn`），加 `:capture`、`timeout-ms => 0` 默认。
- `Handle` 公开 `stdout-chunks` / `stdout-lines` / `stderr-lines` / `pid` / `done`；
  `wait` / `cancel` 保持现有语义并对契约补注释。
- `t/spawn-stream.t`（号在实施时分配）断言：
  - 逐行计数与预期一致；`>\ 1MB` 输出流式读完不截断；
  - 提前 `last` + `cancel` → `code` 非零、进程已收、无残留；
  - `:capture` 时 `out` 与流内容一致；默认时 `out` 为空、`streamed=True`；
  - `wait` 幂等；stderr 不混入 stdout；
  - 半截 UTF-8 / CJK 跨块不炸（`stdout-lines`）。
- `docs/MANUAL.md` 新增一节（含「何时用 `spawn`、何时用 `!`」对照表）。

### P2：收尾与兜底

- `sys.with-spawn` 块形式 + `LEAVE` 兜底。
- 会话结束 reap；审计补一条 warning（若采用未决项 2 的建议）。
- SPEC 条款（号在实施时分配）；`docs/DEVELOPMENT.md` §5.2 追加一段。

### 不做

- 多阶段编程 API、`|>` 语法、Arrow 化管道、dup2 直连。
- 任何对 `!` 现有行为的修改（那是 A/B 方案的范围）。

---

## 7. 验收标准（草稿）

1. 能在脚本里写出「`git log` 边读边过滤，命中即停」且进程确实被终止。
2. 输出 100MB 的命令流式消费，Rakuish 侧内存不随输出增长（用 `out` 为空 +
   进程 RSS 观察双重验证）。
3. `spawn` 的失败、取消、正常结束三种收尾都给出 `ok/code/err`，且 `Result`
   契约与 `exec` 一致。
4. 全部既有测试不变；新增测试通过；ADR 计数与文档互链由 `t/51` 守护。
