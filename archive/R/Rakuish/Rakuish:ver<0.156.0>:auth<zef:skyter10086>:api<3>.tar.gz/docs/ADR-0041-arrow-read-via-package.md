# ADR-0041 · Arrow 读侧改依赖 Arrow::IPC，写侧保留自研

- **日期**：2026-11-23
- **对象**：0.118.3（`open-data` 的 `.arrow` / `.feather` / `.ipc`）
- **状态**：**已实施**（读侧切包；写侧不变；压缩批在读之前拦截）
- **输入**：用户指出 Arrow IPC 已抽成独立包 `Arrow::IPC` 0.1.0（同一作者、纯 Raku、
  零运行依赖），希望「读用 Arrow::IPC，写用自研」
- **相关**：SPEC V-313、[ADR-0038](ADR-0038-arrow-ipc.md)（0.116.0 的自研决定，
  读侧被本文件取代）、`Rakuish::Data::Table`

## 1. 背景：算法从项目里搬走了

0.116.0 把 Arrow IPC 的 FlatBuffers 读写做进了 `Rakuish::Data::Arrow`（约 1000 行），
当时的理由是「不想为了读一个文件拖 DuckDB + 原生库」（ADR-0038）。后来这份实现
被抽成独立包 `Arrow::IPC` 0.1.0：6 个模块、纯 Raku、**零运行依赖**，并且能力更强
——支持 `list` / `struct` / `map` 的任意嵌套与 DictionaryBatch（自研那份明确拒绝）。

于是 Rakuish 这边的问题从「缺算法」变成「算法重复」：同一份 FlatBuffers 逻辑
两处维护，而且项目里那份还是弱的那份。

## 2. 决定

| 方向 | 谁负责 | 理由 |
|---|---|---|
| 读（`.arrow` / `.feather` / `.ipc` 文件） | `Arrow::IPC::decode-ipc` | API 是「路径 → names / formats / cols」，适配成 `Table` 约 90 行 |
| 写（`save-data`） | `Rakuish::Data::Arrow::write-ipc-file` | 见下：迁过去反而更贵 |
| 内存 `Buf` 读（`read-ipc`） | 仍用自研 | `Arrow::IPC` 只提供**路径**入口，没有 `Buf` 解码 API |

**为什么写侧不迁**：`Arrow::IPC::write-ipc` 吃的是 Arrow C Data 视图 ——
对象要有 `.schema` / `.chunks(&code)`，schema 节点要 `.column($i).format/.name/.addr`，
chunk 列要能取到 `ArrowArray`。`Rakuish::Data::Table` 没有这套东西；要喂给它，
先得写一个 C Data 导出器（手工分配指针、挂 release 回调），代码量和崩溃面都
超过现有纯 Raku 写入器。等 `Arrow::IPC` 提供「从普通列数据写」的入口再谈。

## 3. 适配层要还原的语义

`decode-ipc` 把「时刻」解码成**格式化字符串**（`"2020-01-01 12:00:00"`），
而 `Table` 一直用 `DateTime` / 秒数 / `Rat`。适配层按旧语义还原，还原不了就
**原样保留字符串**并把列类型退回 `str` —— 不假装成功：

| 类型 | `decode-ipc` 给什么 | 适配后 |
|---|---|---|
| `date` | `"2020-01-01"` | `DateTime`（当天 0 点） |
| `timestamp` | `"2020-01-01 12:00:00[+00]"` | `DateTime`（空格换 `T` 再解析） |
| `time` | `"01:02:03"` | 当天秒数（3723，与旧读法一致） |
| `duration` | 该单位下的整数 | 原样保留（旧读法也是原单位数值） |
| `decimal` | `"1.25"` | `Rat` |
| `struct` / `map` | `StructVal` / `MapVal` 对象 | `Hash`（`Table` 的 to-text 用 JSON 展示，`where` 可继续用） |
| `list` | 数组 | 原样 |

## 4. 风险：压缩批会被解成垃圾

`Arrow::IPC` 0.1.0 **完全不处理 BodyCompression，也不报错**：压缩的 body 会被当成
裸 buffer 解码。实测 `t/fixtures/arrow/compressed.arrow`（pyarrow 写入，真值
`[1,2,3]`）解出 `24 / 46469901123040552 / 844433520156672` —— 静默错数据比报错危险。

因此读之前先用 `Rakuish::Data::Arrow::ipc-compressed-file` 扫一遍：只读 Footer 的
block 偏移与 RecordBatch 的第 4 个字段（`BodyCompression`），不碰 body，成本 O(批数)。
命中就抛 `X::Rakuish::Unsupported`，并说明「请用未压缩导出」。
代价是文件被读两次（检测一次、`decode-ipc` 一次）；在「静默错数据」与「多读一遍」
之间选前者。

## 5. 依赖与后果

- `META6.json` 增加 `Arrow::IPC:ver<0.1.0+>`。它是纯 Raku、零运行依赖，不引入
  原生库，`zef install` 不会因此需要编译器。
- 自研模块保留：写侧 + 内存 `Buf` 读 + 压缩检测。它的读路径（`read-ipc`）仍被
  t/70 覆盖，但 `open-data` 不再调用。
- 逐条边界：`Arrow::IPC` 缺失时 `open-data` 给出可执行提示（`zef install Arrow::IPC`），
  不抛「No such method」。
- 待办：上游支持 BodyCompression 后可以删掉拦截；上游若提供「普通列数据写入」，
  写侧也能合并过去。
