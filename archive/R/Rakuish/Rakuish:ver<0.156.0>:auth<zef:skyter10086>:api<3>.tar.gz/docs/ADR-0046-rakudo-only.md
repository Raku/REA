# ADR-0046 · 只支持标准 Rakudo，终止 rakupp 兼容线

- **日期**：2026-11-24
- **对象**：0.121.1（全仓库：代码注释、帮助文本、示例、文档承诺）
- **状态**：**已实施**
- **输入**：用户明确要求「Rakuish 不要再考虑 rakupp 了，这个就是个 raku 模块」
- **相关**：[ADR-0019](ADR-0019-local-full-privilege-shell.md)（放弃 Agent 线）、
  [ADR-0021](ADR-0021-eval-worker.md)（引擎子进程，当初就是绕开 rakupp 的方案）、
  SPEC V-906

## 1. 为什么要终止

rakupp 出现在项目里有两个来源，现在都不成立了：

1. **0.80 的常驻引擎探针**。当时为了给 Agent 找一个可嵌入的执行环境，试过
   rakupp 的 C ABI（同进程多实例）。结论是缺 `:pty`、并发求值会崩，
   于是改用「`raku` 子进程当引擎」（ADR-0021）。Agent 线在 0.81.0 整体删除后，
   这个探针的唯一驱动力就没了。
2. **「两个后端都要验证」的习惯**。早期写注释、写帮助、写测试时，总拿
   rakupp 当第二个参照物（「rakupp 的编译错误没有 `<HERE>`」「两个后端都不支持
   heredoc」）。这些话对今天没有任何指导价值，却会让人以为项目还要维护兼容线。

Rakuish 是一个**纯 Raku 模块**（`META6.json` 的 `depends` 只有 Raku 模块），
跑在标准 Rakudo / MoarVM 上。它没有原生 ABI、没有按实现分支的代码路径，
所以「支持另一个实现」从来不是能力问题，而是不该背的承诺。

## 2. 决定

- **单一运行时**：只支持标准 Rakudo（MoarVM）。不做运行时检测、不做能力探测、
  不建第二套 CI。
- **示例与帮助统一用 `raku`**：`! --tty raku`、`tty-exec('raku')` 是「嵌套 REPL」
  的标准例子，不再用 `rakupp`。
- **注释只写结论，不写双实现对比**。原本解释「为什么这么实现」的地方，
  改成与实现无关的表述（例如「编译器对未写完和写错了常给同一句话」）。
- **历史档案保留但标注终结**：`docs/PROBE-2026-11-16-rakupp-*.md`、
  `tools/probe/rakupp-*`、ADR-0019 / 0021 的原文都不删 —— 它们是「为什么不做」
  的证据。但 README 与 SPEC 要明确标注 **rakupp 线已终结**，避免后来者
  （包括下一个 AI）再去跑那些探针。

## 3. 具体改动（0.121.1）

| 位置 | 改动 |
|---|---|
| `README.md` | 开头加「只支持标准 Rakudo（MoarVM）」声明；示例 `! --tty rakupp` → `raku`；探针链接标注「历史归档」 |
| `docs/MANUAL.md` | 6 处示例换成 `raku` |
| `lib/Rakuish/CLI.rakumod` | 帮助文本里的 TTY 直通示例换成 `raku` |
| `lib/Rakuish/Incomplete.rakumod` | 头部注释重写：去掉 rakupp 对比，只留「为什么用词法启发式」 |
| `lib/Rakuish/Eval/Server.rakumod` | 「rakupp 的 C ABI 同进程多实例」→「同进程多实例的 C ABI 方案试过」 |
| `lib/Rakuish/Data/Stream.rakumod` | 警告消息取列名的注释，去掉实现对比 |
| `lib/Rakuish/Command.rakumod` | 「本项目两个后端」→「Rakudo」 |
| `t/26-nested-repl.t` | 提示断言里的示例命令换成 `raku`（断言逻辑不变） |
| `SPEC.md` | V-167 症状示例换成 `! raku`；V-906 标注该线已终结 |

## 4. 边界与代价

- **不承诺在 rakupp 上可用**。如果有人在 rakupp 上跑，报错就报错，不修。
  特别是 `Rakuish::Incomplete` 的启发式：它本来与实现无关，但只在 MoarVM 上
  验证过，不保证在别处的编译错误文本上同样准。
- **不删历史证据**。探针脚本留着，是为了回答「为什么当初不用常驻 C ABI」，
  不是为了将来复跑。
- **没有行为变化**：0.121.1 只改文案与示例，套件断言数不变（`t/26` 的字符串
  替换不影响断言逻辑）。
