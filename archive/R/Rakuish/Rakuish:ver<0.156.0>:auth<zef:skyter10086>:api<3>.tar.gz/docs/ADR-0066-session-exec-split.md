# ADR-0066：Session 拆分第七步 —— `!` 命令行分发 role，与一个 GC 噪声的真因

- 状态：已实施（0.152.0 / SPEC V-356）
- 相关：ADR-0060（属性归属规则）、ADR-0061…0065（前六步）、ADR-0007（TTY 直通）、ADR-0024（exec 元选项）、ADR-0056/0057/0059（管道 / 父进程管道 / 透传）、SPEC §3.85（本条条款）、`t/90-exec-split.t`
- 取证方式：Rakudo Star **v2026.11**（本机 Windows）；区间耦合测量 + `t/83` / `t/44` / `t/10` 回归 + 全套件

## 1. 背景

0.151.0（ADR-0065）之后 `Session.rakumod` 是 2,679 行。前六刀切掉的是「命令族」：命令层、配置、诊断、持久化、格记录、重放、补全。剩下的 2,679 行里最大的两块是：

| 块 | 行数 | 性质 |
|---|---|---|
| `!eval-line-body` | 547 | 会话命令的 if 链 + **`!` 命令行分发（313 行）** |
| 渲染段 | 346 | `render` + 8 个辅助 |

本条选 `!` 分发，不选渲染，理由在 §2 的测量表里：不是「谁大」，是「谁的朝外边更窄」。

拆分结果：`Session.rakumod` **2,679 → 2,376 行**（5 insertions / 313 deletions），新增 `lib/Rakuish/REPL/Session/Exec.rakumod`（**343 行 / 1 个方法**）。

## 2. 为什么是这一簇：朝外的边只有三条

`!` 分发段的区间是 `!eval-line-body` 里的 `if $t.starts-with('!') { … }`（原 1616–1927）。属性引用测量（段内 / 段外）：

| 属性 | 引用 | 可见性 |
|---|---|---|
| `$.sys` | 8 / 8 | 已公开 |
| `$.index` | 2 / 15 | 已公开 |
| `$.stream-out` | 2 / 2 | 已公开 |

零新增公开面 —— 这是前几刀持续把状态公开化的直接分红（ADR-0063 §2 的「拆分复利」）。朝外的方法调用有六个，全部留在 Session、由 role 按名字调用（ADR-0060 §2 实测）：

- `!split-argv` / `!split-pipeline` / `!unclosed-quote`：分词与管道切分，补全与 shell 层也在用，不是 `!` 的私产；
- `!remember` / `!strict-result` / `!emit-chunk`：所有格共享的结果记账、strict 收敛与流式回显。

对照渲染段（346 行）：13 个属性里 6 个还是私有的，另有 8 个私有辅助。同样的行数量级，边界宽一倍以上。

## 3. 决定

1. 新增 `lib/Rakuish/REPL/Session/Exec.rakumod`：`unit role Rakuish::REPL::Session::Exec;`，只含 `method !dispatch-bang(Str $t --> Any)`。
2. **退出语义用返回值表达，不用异常**：返回 `Result` = 这一行已处理；返回 `Nil` = 不是 `!` 命令。`!=` / `!~~` 是 Raku 运算符，必须原样落回后面的 Raku 求值分支 —— 这条以前靠「嵌套 if 不命中就自然下落」，搬进方法后必须显式建模，否则运算符会被当成外部命令。
3. Session 侧只剩四行委派：

   ```raku
   if $t.starts-with('!') {
       my $bang = self!dispatch-bang($t);
       return $bang if $bang.defined;
   }
   ```

   保留 `if $t.starts-with('!')` 是为了让「谁是 `!` 行」这个判断留在分流点：`!dispatch-bang` 只回答「这条 `!` 行怎么执行」。
4. 元选项解析、Windows cmd 内建重写、引擎内管道 / 父进程管道 / 透传 / `--tty` 三类分支全部原样搬过去，一行逻辑没改。role 自己 `use Rakuish::REPL::Result` 与 `use Rakuish::REPL::Shell`（`win-cmd-builtin-argv`）—— 0.149.0 的教训：Session 的 `use` 不泄漏进 role 的编译单元。
5. `META6.json` provides 54 → 55。

## 4. 顺带修掉的一个 GC 噪声（`t/55`）

每次全套件都在 stderr 里留一段：

```
WARNING: unhandled Failure detected in DESTROY. …
Failed to find '…\rakuish-follow-…\gone.txt' while trying to do '.l'
  in block at lib/Rakuish/Sys/FS.rakumod line 215
  in method follow at lib/Rakuish/Sys/FS.rakumod line 212
  in method tail-follow at lib/Rakuish/Sys.rakumod line 284
  in block <unit> at t/55-follow.t line 116
```

真因不是 `follow` 的语义，而是轮询那一行：

```raku
my $size = try { (($f.e || $f.l) && $f.f) ?? $f.s.Int !! Nil };
```

`.l` 对**不存在**的路径返回的是 `Failure` 而不是抛 —— 在布尔链里一求值就抛，`try` 接住；但这个 Failure 在被接住的过程中仍会偶尔留到 GC，于是 DESTROY 时冒警告。`t/55` 的 ④ 场景（文件删掉、两拍后重生）正好每次都会走到这条路径，所以警告每次都出现；单独跑 `raku t/55-follow.t` 反而不出现，靠 `prove6` 的进程生命周期才稳定复现。

修法：轮询里只认 `.e`。悬空符号链接本来就读不出内容，按「文件还没回来」处理在语义上是正确的，而且不产生 Failure：

```raku
my $size = $f.e ?? (try { $f.f ?? $f.s.Int !! Nil }) !! Nil;
```

验证：`t/55` 连跑 8 次、每次 `not ok` = 0、stderr 警告 = 0；`prove6 -Ilib t/55-follow.t` 的 stderr 为空。

这条记在这里而不是单独开 ADR：它是 §3 那次改动顺手发现的既有缺陷，影响面只有一行代码与一条 stderr，不改变任何对外行为。

## 5. 没采用的方案

- **把 `!eval-line-body` 整条命令链一起搬进 role。** 那条链是分流器本身（会话命令 → 历史替换 → `!` → shell 习惯命令 → 续行 → Raku），搬走等于把 `eval-line` 的核心搬走，role 与类会互相反向依赖。
- **让 `!dispatch-bang` 用异常表示「没命中」。** 要新增一个内部异常类型、在 Session 侧 catch，比返回 `Nil` 多一层看不见的控制流；而且 `!=` 不是错误。
- **把 `!split-argv` 等六个辅助一起搬。** 它们被补全（`!split-argv`）、shell 层、所有格共用；按调用闭包它们不属于 `!` 分发。
- **先修 `t/55` 再拆分。** 顺序反过来更好：拆完 `!` 分发后 FS 的调用栈变短，那个 `line 212/215` 的帧更容易读，也更确定不是拆分引起的。

## 6. 不变量

- `Session.rakumod` < 2,450 行；Exec 恰好含 `!dispatch-bang`，不含六个共享辅助。
- Exec 里没有 `$!` / `@!` / `%!` 任何类私有属性引用。
- `!=` / `!~~` 仍然落回 Raku 求值（`op` 不是 `exec`）。
- 元选项、cmd 内建重写、三类执行分支的行为逐项与 0.151.0 相同。`t/83` 53 条、`t/44` 34 条、`t/10` 164 条、`t/48` 24 条全绿是这一条的实测凭据。
- `t/55` 的 stderr 在全套件里为空。

## 7. 结构守卫清单（`t/90-exec-split.t`，63 条）

1. 两个文件都在；Exec 的 `unit role` 头正确；Session 的八条 `does` 与 `use` 都在（前七步没被回退）。
2. **反方向**：`!dispatch-bang` 不在 Session 而在 Exec；六个共享辅助留在 Session 且不在 role。
3. role 卫生：零私有属性引用；自己 `use` Result / Shell；经 `$.sys` / `$.index` / `$.stream-out` / `self.pipe-handler` / `self.tty-handler` 读写状态；入口 `--> Any` 且未命中分支显式 `Nil`。
4. `cmp-ok $sess-lines, '<', 2450` 与 `'>', 2200`（上界防长回去，下界防空跑）。
5. `META6.json` provides 登记 Exec。
6. 运行时：`!` 空命令 127；`!echo hi` 走 cmd 内建重写；`--capture` 拿到 stdout 且非 streamed；`--pipe` 与 `--capture` 互斥；`--stdin` 不存在 127；`--timeout-ms` 非整数 127；`!echo a | findstr a` 管道分支；`--tty` 经注入执行器（exe/argv 原样）；`--pipe` 单命令经注入 pipe-handler（Result.out 为空、streamed）；`!=` 不是 `exec`。

**测试陷阱（记一笔）**：注入执行器时写 `Rakuish::Result.new(...)` 会失败 —— `Rakuish::Result` 是**模块**，`Result` 才是它导出的类；测试文件要 `use Rakuish::Result;` 再用 `Result.new`。`^can('!dispatch-bang')` 永远返回空：私有方法不在方法缓存里，role 组合是否生效只能靠行为断言。

## 8. 下一步

- 剩下的 2,376 行里，渲染段（346 行，6 个私有属性 + 8 个辅助）是唯一还成块的候选；但它被 Session、诊断 role、重放 role 同时调用，朝外的边比 `!` 分发宽一倍。
- 求值核心（`!eval-raku` 279 / `!pure-decl` 224 / `!scan-cell` 222）按前七刀的标准不该动：它们与 `%STATE` / `@decls` 的生命周期同生共死。
- 另一种收尾方式：不再切 role，而是把 `!eval-line-body` 的 547 行 if 链改成数据驱动的命令表（纯重构、不跨文件）。风险比切 role 高（它没有调用闭包可以量），收益是可读性。
