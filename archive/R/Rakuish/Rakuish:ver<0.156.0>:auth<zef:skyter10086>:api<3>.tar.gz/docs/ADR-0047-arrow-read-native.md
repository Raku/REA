# ADR-0047 · .arrow 读侧把标量列交还给 DuckDB

- **日期**：2026-11-24
- **对象**：0.122.0（`open-data` 的 `.arrow` 分支、`Rakuish::Data::Duck`）
- **状态**：**已实施**
- **输入**：用户「Arrow 的底层 API 放 DB::DuckDB，高级 API 让 Duckula，
  Rakuish 为了性能可以牺牲一些灵活度；数据分析的活是 Duckula 的本职工作」
- **相关**：[ADR-0038](ADR-0038-arrow-ipc.md)（自研 Arrow 的由来）、
  [ADR-0041](ADR-0041-arrow-read-via-ipc.md)（读侧第一次交给 Arrow::IPC）、
  [ADR-0044](ADR-0044-arrow-read-routing.md)（读侧分流 + 坏文件护栏）、
  [ADR-0045](ADR-0045-arrow-batch-write.md)（写侧多批 / 流式）、SPEC V-318

## 1. 问题

`.arrow` 的读路径是 Rakuish 自己实现的，三条历史决策叠在一起：

| 版本 | 决定 | 结果 |
|---|---|---|
| 0.116.0 | 自研读写（ADR-0038） | 1300 行解码器 + 编码器 |
| 0.118.3 | 读侧交给 `Arrow::IPC`（ADR-0041） | 5 万行 20 s，坏文件 SIGSEGV |
| 0.120.1 | 读侧再分流回自研（ADR-0044） | 4.3 s，仍需规避上游 bug |

同时 `Table.sql` 已经在用 DuckDB —— 于是同一次分析里，数据被**两套 Raku
解码器**搬了两遍：读文件解一次，进 SQL 前再编码一次，DuckDB 真正执行只花
12 ms。这不是取舍失误，是「没有第四条路」的后果：当时没查到 DuckDB 有
社区扩展 `nanoarrow`（`read_arrow` / `COPY … FORMAT ARROW` / `to_arrow_ipc`）。

## 2. 决定

**标量列的 `.arrow` 读交给 DuckDB，嵌套/特殊类型维持原路。**

- `open-data` 先只读 schema（`ipc-column-kinds-file`：file 格式读尾部 Footer，
  流格式读开头 64KB），拿到列名与 Arrow 类型；
- 类型全在白名单（`int / float / bool / utf8 / date / timestamp` 无时区 /
  `decimal`）时，
  走 `Duckula.read-arrow` → `CREATE TEMP TABLE … AS SELECT * FROM read_arrow(?)`
  → `table-from-frame`（与 `Table.sql` 结果同一套类型口径）；
- 否则与以前完全一致：自研读入器优先，只有 `UnsupportedType` 才回退
  `Arrow::IPC`（坏文件绝不交给会段错误的解析器，ADR-0044 的结论不变）；
- Duckla / DB::DuckDB / nanoarrow 缺一个，或读取失败，**静默回落**原路。

### 为什么是白名单，而不是「能读就读」

这是纯优化，不是新语义，所以判据只能是「两条路逐值一致」，而不是「DuckDB
能读」。逐列验证后不放进来的六类：

| 类型 | 差异 |
|---|---|
| `time` / `duration` | 自研给「秒数」，DuckDB 给 `"01:02:03"` 文本 |
| `timestamp` 带时区 | DuckDB 保留 `+08:00` 偏移，自研归一到 UTC |
| `decimal` | ~~Duckula 0.36 把**负**值按无符号 128 位解~~ —— 实为 `DB::DuckDB::ColumnView` 没做 128 位补码扩展；1.3.1 修好后已放进白名单 |
| `binary` | 自研给 `Buf`，SQL 出口是带 `\x` 转义的 `Str` |
| 嵌套 / 字典 | SQL 出口只剩文本渲染（`[a, b]`、`{'name': ann}`） |

嵌套列的结构化读取需要 `DB::DuckDB::Arrow` 的 C data 逐层读，属于独立一块，
不在本 ADR 范围。

### 1 MB 阈值

DuckDB 那条链首次使用要装载 libduckdb + Duckula + nanoarrow（约 0.7 s）。
1 MB 以下自研读入器本来就快，付这个装载代价不划算，所以设阈值；
**压缩文件例外**——自研读入器不解压，DuckDB 是唯一能读的路，无脑走快路。

## 3. 结果

| 场景 | 原路 | 快路 |
|---|---:|---:|
| 5 万行 × 3 列（1.44 MB） | 2.60 s | 1.2–1.6 s |
| 50 万行 × 3 列（14.9 MB） | 23.4 s | 13.1 s |
| 压缩的标量文件 | 报错 | 能读（zstd 1.44 MB → 310 KB） |
| 3 行小文件 | 0.02 s | 走原路（阈值） |

顺带修了一处精度问题：老路用 `Num` 调 `Instant.from-posix`，毫秒会算成
`…59.12300006`；改成传 `Rat` 后与 DuckDB 一致，t/78 有断言。

## 4. 代价与遗留

- **两套读路径并存**（白名单内 DuckDB、白名单外纯 Raku）。这是刻意的：
  离线 / 没装 DuckDB 的机器必须还能读 `.arrow`，所以纯 Raku 读入器不能删。
  代价是每次改动读侧语义都要在 t/78 里跑两路比对。
- **瓶颈已经转移**：快路里 DuckDB 读文件只花 20–300 ms，剩下全是
  「把列物化成 Raku `Hash`」（50 万行 `Frame.rows` ≈ 6 s、
  `table-from-columns` ≈ 4 s）。再要提速只能走 C data 直读，不再有
  「换个解码器」的余地。
- **上游 bug**：Duckula 0.36 / `ColumnView.to-list` 的负 DECIMAL 解码错误
  已经定位（`Result.hashes` 同一列是对的），修好后可以把 `decimal` 放进白名单。
