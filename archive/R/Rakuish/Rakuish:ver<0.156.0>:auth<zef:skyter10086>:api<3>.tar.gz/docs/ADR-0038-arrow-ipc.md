# ADR-0038 · Arrow IPC 自己解析，不引 DuckDB 依赖

- **日期**：2026-11-23
- **对象**：0.116.0（`Rakuish::Data::Arrow`）
- **状态**：**读写已实施；读侧自 0.118.3 起由 [ADR-0041](ADR-0041-arrow-read-via-package.md)
  接管**（`open-data` 改用独立包 `Arrow::IPC`，写侧与内存 `Buf` 读仍在本模块）。
  0.116.0 当时的验证：读用 pyarrow 真实产物，写用 pyarrow 读回
- **输入**：用户提出「cell 导出和 Arrow IPC」，目标是给数据侧一个能跟 pandas /
  polars / duckdb 交换的二进制格式，顺带为图表准备数据入口
- **相关**：SPEC V-308、[ADR-0021](ADR-0021-engine-subprocess.md)（引擎子进程）、
  `Rakuish::Data::Table`（0.91 起统一的表格值）

## 1. 问题：箭头文件没人能读

需求很朴素：`open x.arrow` 得到一张表，`save-data x.arrow $t` 写回去。
先看现成的三条路：

| 方案 | 能读 IPC 文件吗 | 代价 |
|---|---|---|
| DuckDB `read_parquet` | **不能**（它只认 Parquet，Arrow 仅支持内存扫描） | 现有 `with-duckdb` 那条路走不通 |
| Duckula `read-arrow` | 能 | 依赖 `DB::DuckDB` + `Alien::Libduckdb`（原生库） |
| 自己解析 | 能 | 约 500 行 FlatBuffers 读写 + 类型解码 |

Duckula 的接口是 `read-arrow($session, $path)` —— 为了读一个文件要先起一个
DuckDB 会话。对「教学型、纯 Raku、依赖越少越好」的 rakuish 来说，这笔交易不划算：
**Arrow IPC 只是一个文件格式，不是一种查询能力**。而 Parquet 不同 —— 它带
编码、压缩、列统计，自己实现是另一个量级，所以那条路继续走 DuckDB。

## 2. 决定

自己实现 Arrow IPC 的读写，范围**收窄并写死**：

- **读**：`null` / `int`(8/16/32/64) / `float`(half/single/double) / `bool` /
  `utf8` / `large-utf8` / `binary` / `large-binary` / `date` / `time` /
  `timestamp` / `decimal` / `duration`。
- **写**：`int64` / `double` / `bool` / `utf8` / `timestamp[ms]`。
- **一律拒绝**（抛 `X::Rakuish::Arrow` 并说明原因）：字典编码、`BodyCompression`、
  `List` / `Struct` / `Map` / `Union` / `FixedSizeBinary` / `FixedSizeList` /
  `RunEndEncoded` / `Interval`。

拒绝比降级重要：读不出来的列悄悄变成空列，用户会以为数据坏了。

## 3. 实现要点（都是踩过的坑）

1. **FlatBuffers 缓冲区开头是根表 uoffset**，不是表本身。直接当表解析会读出
   「vtable 长度 5」这类怪值。
2. **从后往前构建**：新字节落在更低地址，内部缓冲「插在最前」，收尾时**不要**
   再翻转（翻了根偏移会跑到缓冲区末尾，pyarrow 报 "Verification of
   flatbuffer-encoded Footer failed"）。
3. **表头 soffset 要回填**：写完字段才能知道 vtable 位置，所以先占 4 字节，
   结束时按「距末尾偏移」换算成绝对下标回填。
4. **`Message.bodyLength` 必须等于 `Block.bodyLength`**，否则 pyarrow 拒收
   （"Mismatching body length for IPC message"）。
5. **有效性位图的边界是位图长度**，不是 `null_count`。拿 `null_count` 当下标
   上限会让「一列有 null」之后的每个位置都变 null。
6. **时间戳别用 `Instant.Num`**：它按 TAI 计、含闰秒，2020 年的值会多 37 秒。
   用 `posix + (second - whole-second)`。
7. **`=>` 会 itemize 右值**：`%( buffers => ($a, $b) )` 里 `%h<buffers>` 是一个
   标量容器，`for` 只迭代一次拿到整个 List —— 要写 `.list`。

## 4. 接入面

- `open-data` / `save-data` 按扩展名分发（`.arrow` / `.feather` / `.ipc`），
  路径仍经 `Sys.resolve` 做 root 校验。
- **不需要 `:allow-external`**：那条开关是给「经外部引擎读文件」准备的
  （Parquet / CSV 走 DuckDB）。Arrow 在进程内解析，没有外部访问面。
- `:raw` 对二进制明确报错：没有文本形态，解码出一堆乱码比报错更糟。

## 5. 验证方式

- **读**：`t/fixtures/arrow/` 里是 pyarrow 26 生成的真实文件（basic / kinds /
  multi / stream / compressed / empty），随仓库提交，所以 CI 不需要 pyarrow。
- **写**：人工用 pyarrow 的 `open_file` / `open_stream` 读回核对（含 UTF-8、
  null、时间戳、空表、500 行）。这一条不进 CI —— 双平台都没装 pyarrow，
  塞进去只会假失败；但它记在 SPEC 里，改编码器时要重跑一遍。
- t/70 共 68 条断言，覆盖各类型、批合并、流格式、空表、全 null 列、
  压缩拒绝、非 Arrow 数据、往返、`open-data` / `save-data` 接入。

## 6. 后果

- 好处：零依赖，WSL / CI 都能跑；格式透明，出错时能指到字节位置。
- 代价：不支持字典编码与压缩（pandas 的 `to_feather` 默认不压缩，多数情况下够用）；
  不支持嵌套类型；整份文件读进内存。
- 后续若要支持压缩，最省事的是只加 `BodyCompression` 的 zstd 分支（FlatBuffers
  部分不用改）；嵌套类型要动解码器的递归结构，属于另一次改动。
