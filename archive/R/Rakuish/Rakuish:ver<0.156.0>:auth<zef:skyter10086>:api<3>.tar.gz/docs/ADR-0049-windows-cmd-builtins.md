# ADR-0049 · Windows cmd 内建：`!` 回落到 `cmd.exe /d /c`

- **日期**：2026-11-25
- **对象**：`Rakuish::REPL::Session`（`!` 分发）、`Rakuish::REPL::Shell`（`win-cmd-builtin-argv`）
- **状态**：**已实施（0.130.0）**。条款：SPEC V-332；回归见 `t/10`。
- **输入**：[`REVIEW-VS-IPYTHON-2026-11-24.md`](REVIEW-VS-IPYTHON-2026-11-24.md) §4.9 j
  （`! echo hi` 在 Windows 上不可用）
- **相关**：V-123（`!` 完全 argv-only、无 shell 解释）、V-167（`--tty` 直通）、
  ADR-0024（`!` 流式与超时）、ADR-0019（本地全权限）

## 1. 问题

`echo` / `dir` / `type` / `copy` / `set` 这些是 **cmd.exe 的内建命令**，磁盘上
没有同名 `.exe`。`!` 走 `Proc::Async`（CreateProcess），只能启动可执行文件，
所以 `! echo hi` 的结局是一句与用户意图无关的错误：

```text
[exit=127] Failed to spawn process echo: no such file or directory (error code -4058)
```

用户看到的是「spawn 失败」，而不是「echo 得用内置写法」。在 POSIX 侧 `echo`
通常有 `/bin/echo`，所以这个问题只在 Windows 暴露；评审把它记为 §4.9 j。

## 2. 决策

**在 `!` 的分发层做一次 argv 重写，不改 `Sys.exec` 的契约。**

1. 只有当 argv[0] **不含路径分隔符**、命中一张固定的内置白名单
   （`echo ver vol cls title color date time chcp dir type copy move del erase
   md rd ren set path mklink`），**并且** PATH / 当前目录里确实没有同名
   `exe` 或同名文件时，才重写为：
   ```text
   cmd.exe /d /c <把每个 token 用 ^ 转义后用空格拼成的一行>
   ```
   同名 exe 优先——有 `echo.exe` 的地方仍然是那个程序，白名单不会盖住它。
2. 转义集合是 cmd 的元字符 `& | < > ^ ( ) %`，逐个前置 `^`。因此：
   - `! echo a & b` → 打印 `a & b`（`&` 不是命令分隔符）；
   - `! echo a>b` → 打印 `a>b`（不重定向、不写文件）；
   - `! echo %PATH%` → 打印 `%PATH%`（**不展开**）。
3. `!` 的语义没有变成 shell：**参数仍然是字面 argv**，只是最后由 cmd 而不是
   CreateProcess 来「跑这个词」。V-123「`!` 完全 argv-only、无 shell 解释」
   因此仍然成立，`Sys.exec` / DSL / 脚本里的 `exec` 一律不加这层。
4. 不给 `"` 和换行做「尽力转义」：cmd 对这两个没有可靠口径（实测 `\"` 会把
   反斜杠一起打印出来）。参数里出现 `"` 或 `\r` / `\n` / NUL 时**不回落**，
   保留原来的 127 —— 宁可给出原始错误，也不静默改变语义。
5. token 以反斜杠结尾时（`! dir C:\`），在整行末尾补一个空格再交给 `/c`：
   Windows 命令行里收尾引号会被反斜杠吃掉（实测 `dir C:\` 变
   「The filename, directory name, or volume label syntax is incorrect」）。
   代价是 `echo` 这类输出多一个尾随空格，比语法错误可接受。

## 3. 边界（明确不做）

- **不做 shell 语法**：`for` / `if` / `goto` / `call` / `start` / `&&` 串联 /
  管道 / 重定向 / `%VAR%` 展开，全都不认（白名单里没有它们；元字符都被转义）。
- **不做 `cd` / `pushd` / `popd`**：Rakuish 的 `cd` 是会话级 cwd，和 cmd 进程的
  cwd 是两套东西，混起来会让「我在哪」变得不可预测。
- **不做 `exit`**：Rakuish 的 `exit` 是会话退出请求，不能被 `!` 借走。
- **不扩大到任意命令**：不在白名单里的名字仍然走原生 spawn，失败就是 127。
- **不覆盖 `! --tty`**：`--tty` 走父进程的终端交接，那条路不经过这层重写
  （`! --tty echo hi` 仍按原生规则失败）。
- **不改变 `Sys.exec`**：`sys.exec('echo', 'hi')` 仍是 argv-only 的原生调用。

## 4. 代价

- 多一个 `cmd.exe` 进程（约 10 ms 量级），只在内建命令上发生。
- 尾反斜杠场景多一个空格（见 §2.5）。
- 白名单要维护：新增 cmd 内建时得显式加进来，否则就是原生 127。

## 5. 验收

`t/10`（Windows 段）钉住六条：`! echo hi` 成功且有输出；`&` 是字面量；
`>` 不写文件；`%VAR%` 不展开；`! dir /b` 能列目录；非白名单命令仍是失败。
Linux 上这段整体跳过（`echo` 有 `/bin/echo`，走原路径即可）。
