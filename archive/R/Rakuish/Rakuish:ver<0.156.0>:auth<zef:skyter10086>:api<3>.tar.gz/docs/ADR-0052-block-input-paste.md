# ADR-0052 · 块输入 `paste`：整段源码当一个格

- 状态：已实施（0.138.0 / V-342）
- 日期：2026-11-26
- 相关：[ADR-0036](ADR-0036-input-loop-ownership.md)（输入循环所有权）、
  [ADR-0025](ADR-0025-startup-layer.md)（会话命令与 `set -o` 的分层）、
  SPEC §3.71

## 1. 背景

评审（`docs/REVIEW-VS-IPYTHON-2026-11-24.md` P1.4）指出：粘贴一段带空行
与缩进块的 `class` / `multi sub` 时，REPL 会把每一行当成独立的格送进
`eval-line`，缩进块被 Continuation 状态机切碎，粘一段代码要手动补续行。
bracketed paste 在 vi 模式下更糟：字符被当 vi 键吞掉（SPEC V-154 的老
限制）。

两年前定的边界是「不做多行 buffer」：行编辑循环的所有权在
[ADR-0036](ADR-0036-input-loop-ownership.md)，Session 不该去碰它。

## 2. 决定

新增会话级命令 `paste`：

- 读 stdin 的行，直到**一行恰为 `--`**（去空白后比较）或 EOF；
- 把累积的整段文本当作**一个格**交给 `eval-line`；
- 不修改行编辑循环，也不引入多行 buffer 状态。

于是 block input 与行编辑是**两个互不干涉的输入阶段**：行编辑器交还
输入权之后，`paste` 才读 stdin（TTY 的 canonical 行输入与管道都是
`$*IN`），所以 TTY 与管道同语义。

## 3. 为什么不是「逐行喂给 eval-line」

`source` 走的就是逐行喂（这样每行都能单独持久化声明）。块输入的价值
恰好相反：`class` 里的大括号、空行、缩进必须由**一个编译单元**消化，
逐行喂会：

1. 触发 Session 自己的续行状态机，把同一段源码拆成 N 个格；
2. 让 `!pure-decl` 的「一格恰好是一条声明」判据失效，声明不持久化；
3. 在 history / `Out[n]` 里留下 N 条噪声。

因此 `paste` 用一次 `eval-line($src)`，history 只记一条（整段源码）。

## 4. 边界与拒绝的面

- **参数**：`paste` 不接受参数（`paste --help` 除外）。误敲参数宁可报错，
  也不把参数当源码前缀拼进去。
- **不完整的块**：`is-incomplete($src)` 命中就拒绝，不丢给 EVAL 制造奇怪的
  语法错误；拒绝后不碰 `@!pending`、不占 `Out[n]`，会话仍可用。
- **空块**：立即 EOF 时报「没有读到内容（用 -- 结束，或 Ctrl-D）」。
- **引擎 / notebook 模式**：`input-handler` 已注入时 stdin 是协议流，读它
  等于把协议帧当源码 —— 明确拒绝，而不是给出一个会吃掉协议的实现。

## 5. 测试

`t/05` 第 152–166 条（15 条断言）：整块 `class` 一次执行且跨格可用、
`--` 终止后剩余行没被吃掉、空块 / 不完整块 / 参数 / 引擎模式四类拒绝、
history 与 `Out[n]` 的记账口径（成功记整段源码一条、失败只记命令本身）。
`t/37` 守着「每个 COMMANDS 名字都有 usage」。
