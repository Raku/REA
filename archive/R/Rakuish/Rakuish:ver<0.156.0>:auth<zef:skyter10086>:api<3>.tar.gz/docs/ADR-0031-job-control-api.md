# ADR-0031：MoarVM 下的作业控制 API —— `bg-exec` / `jobs` / `fg` / `bg`

- 状态：**Accepted**
- 版本：0.96.0
- 关联：V-265…V-269；ADR-0010（进程组交接可行性，选项 A 已实施）、ADR-0021（求值引擎子进程）、V-175、V-901、V-905

## 1. 问题

ADR-0010 当年把作业管理划出范围，理由写的是「那是 shell 语法，与 V-90x 冲突」。
用户后来问：**现在不用 rakupp、只用 MoarVM，能不能做？**

先纠正一个被反复误解的前提：ADR-0010 的评估**本来就是在 MoarVM 2026.09 上
做的真 PTY 实测**，与 rakupp 无关。换后端不解锁任何新东西——当年卡住它的
从来不是运行时能力，而是三条产品/架构约束：

1. `&` / `fg` / `bg` 是 shell 语法，V-901 明写「永不支持」；
2. Windows 没有前台进程组（`CTRL_C_EVENT` 不能投递给进程组 —— 注意
   `CTRL_BREAK_EVENT` **可以**，0.117.0 真机实测并更正，见 ADR-0010 §3.1）；
3. 双进程架构下，真终端与作业表只在父进程手里（引擎的 stdio 是协议管道）。

## 2. 决策

### 2.1 走非语法的 Raku 方法，不碰 V-901

实现成四个普通 Raku 函数：`bg-exec($exe, *@args)` / `bg-jobs()` / `fg($id)` /
`bg($id)`。它们是真值返回（Result / Table），可赋值、可进方法链，不解析
shell 字符串——和 `exec()` / `stream()` 是同一类东西，不是 bash 内建。

**不引入** `&` 后缀语法、不引入 `jobs` 保留字。V-901 不松动。

### 2.2 作业表建在父进程，不建在引擎

引擎会因 Ctrl-C / 崩溃重启（ADR-0021 / 0023）。作业表若在引擎里，重启后
后台进程就成了没人能 `fg` / `kill` 的孤儿。所以：

- 父进程 `Rakuish::Sys` 持有一张 `JobTable`（id → pid/pgid/cmd/state/时间）；
- 引擎侧 DSL 函数经 `Sys.job-op` → `job-dispatch` hook → `event => 'job'` 帧
  转到父进程（与 `tty-exec` 的 hook 完全同构，同一条请求/响应管道）；
- hook 未注入时（`-e` / 脚本 / 单进程直调）回落到本地方法。

### 2.3 复用 ADR-0010 的底层原语，只补两处

| 已有（0.73.0） | 新增（0.96.0） |
|---|---|
| `spawn-in-group`（SETPGROUP，无竞态） | `wait-state`（WNOHANG \| WUNTRACED \| WCONTINUED 轮询） |
| `tcsetpgrp` / `foreground-of` | `signal-group`（`kill(-pgid, SIG)`） |
| SIGTTOU 真 `SIG_IGN` | `JobTable` 状态机 |

**不用 SIGCHLD handler**：那会和 Rakudo 自己的子进程回收抢信号（V-175 已在
`waitpid` 上踩过一次）。用 `wait-state` 非阻塞轮询，简单且无竞态。

### 2.4 Ctrl-Z 不再让 REPL 卡死

0.73 的已知边界（ADR-0010 §6.4）：子进程被 SIGTSTP 停住时没有 `fg` 捞它，
REPL 等在那儿。本版 `fg` 用 `WUNTRACED` 察觉 stopped，**立刻把前台还给宿主**
并返回 `state=stopped`，用户可再 `fg(id)` 或 `bg(id)`。

注意这里没有放行 `\x1a`、没有改行编辑器：Ctrl-Z 是终端行规程直接给**前台
进程组**发 SIGTSTP，`fg` 只是在等待循环里观察到它。这是 B 档与 C 档的分界。

### 2.5 与现有 `spawn()/jobs()` 分工，不合并

`Rakuish::Sys` 早有一张 `%.jobs` 表（`spawn()` 起、**捕获输出**、`wait()` 收
Result、Promise/Handle 语义）。新表是**真终端作业**（继承 fd、进程组、SIGCONT）。
两套生命周期完全不同，强行合并只会得到「看起来一样、语义分叉」的 API。
所以新 API 叫 `bg-jobs()` 而不是覆盖 `jobs()`，`!cmd-jobs` 命令不动。

## 3. 验证

- `t/54-job-api.t`（21 断言，真 `pty.fork()` controlling terminal）：
  后台启动立即返回、子进程自成进程组、前台不交给后台、后台真的在跑、
  `bg-jobs` 状态、退出码带回、前台收回、作业移除、stopped/bg 恢复、
  Ctrl-Z 时 `fg` 不卡死、非法 id 报错。
- Windows：整段 skip（POSIX-only 边界，与 ADR-0010 §3 一致）；但**子树回收**
  在 Windows 上是另一条路（Job Object，t/71），两者不冲突。
- 双平台 CI：50 文件 / 2236 断言 / `console=pass`。

## 4. 边界

- **POSIX-only**：Windows 上四个方法都返回 `code=127` + 明确错误，不退化成
  捕获式后台（那是 `spawn()` 的职责）。
- 不做 `&` 语法、不做 `Ctrl-Z` 键绑定、不做 SIGWINCH 转发。
- **孙进程树回收（V-905）在 Windows 侧已落地**（0.117.0 / V-309）：只解决
  「引擎死了，它起的命令行与孙进程没人收」这个问题，与 fg/bg 语义无关 ——
  用 Job Object + `KILL_ON_JOB_CLOSE`，引擎归类进 job，重启 / Ctrl-C 时
  `TerminateJobObject` 连子树一起收（`Rakuish::Sys::WinJob`，t/71）。
  POSIX 侧本来就靠进程组，V-905 的剩余部分仍然不做。
- `fg` 的 `ok` 表示「带回动作成功」，不是「子进程退出码为 0」；后者在
  `code` / `value<exit>` 里。
- `bg-jobs` 返回 `Table`，`bg-exec` / `fg` / `bg` 返回 `Result`。
