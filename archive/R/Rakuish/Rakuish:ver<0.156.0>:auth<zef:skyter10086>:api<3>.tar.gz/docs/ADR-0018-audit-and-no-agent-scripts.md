# ADR-0018 · 不给 Agent 脚本权限，改为统一审计

- **日期**：2026-11-15
- **对象**：`main` @ 0.79.2 → 0.80.0
- **状态**：已实施
- **输入**：0.79 / 0.80 关于「跨平台 OS 级隔离」的四轮讨论，
  以及用户给出的两条硬约束
- **相关**：[ADR-0001](ADR-0001-raku-native.md)、
  [ADR-0002](ADR-0002-agent-serve.md)、
  [ADR-0013](ADR-0013-kernel-frontends.md)、
  [ADR-0016](ADR-0016-display-bundle.md)
- **对应条款**：SPEC **V-607**（0.79.2）、**V-194…V-196**（0.80.0）

## 1. 为什么推翻了「把解释器关进 VM」

前面几轮沿着「让 Agent 能跑 `execute`」往下推，结论是要 OS 级隔离；
再往下推发现 Windows 没有 namespace、AppContainer 与 Linux 模型不对称，
只有 VM 能同时满足「跨平台」和「**不要挂个禁止通行的牌子**」。而 VM 的
代价（每连接一个、Windows 家庭版只有 WSL2、CI 需嵌套虚拟化）已经不是
应用层能消化的。

用户给的解套是：

> 不给 Agent 运行脚本的权限，只有本机 REPL 模式才有权限执行 Raku 脚本，
> 同时 Rakuish 对每次操作都要有日志记录。

这条把问题从「怎么关住不可信代码」换成「**根本不给不可信代码入口** +
操作可追溯」。V-503 不用改，`execute` 从路线图删除，不用碰 OS 隔离。
这是本项目一直走的路（能力清单），不是妥协。

## 2. 但「Agent 不能跑脚本」当时是假的

实测：只配 `--allow-exec --allow raku`，Agent 就能

```
op=exec, argv=[raku, -e, 'say "PWNED-BY-AGENT"']  →  ok=True
```

因为 `Sandbox.exe-allowed` 只做路径 canonical 匹配，不区分解释器；
而 `t/06` / `t/16` / `t/21` 本来就常用 `raku` 当白名单夹具。

按程序名拉黑名单（`raku` / `python` / `sh` / …）**仍然是块牌子**：
复制成 `helper.exe` 就绕，`git -c core.pager=...` 也一样。诚实的结论是
**只要 Agent 能起任意外部进程，白名单就挡不住它跑代码**。

### 0.79.2 的做法：启动期结构性闸门

- `Sandbox.allow-code-exec` 默认 False，`exec` / `pty_exec` 在
  `authorize` 里直接 403，**先于** argv / 白名单 / `allow-exec` 判定。
- 请求里**没有任何字段**能打开它（t/06 反向断言）。
- 要开必须同时给 `--allow-code-exec` + `--allow-exec` 两个独立启动开关，
  启动时 stderr 打醒目警告「root / 白名单不构成脚本边界」。
- `bin/rakuish-agent` 不 import `Session.eval-line`、不调 `EVAL`；
  Raku 源码只有本机 REPL / `-e` / 脚本模式能执行。

「结构性」与「牌子」的区别在这里很具体：牌子是运行期按参数检查、
客户端能想办法绕过；闸门是**启动期决定的进程级策略，请求改不了，
而且默认那条路径根本不通**。

## 3. 审计：0.80 之前三套账本，没有一处能保证不漏

| 通道 | 当时 | 问题 |
|---|---|---|
| `Sandbox.audit` | Agent 请求，结构化，落盘 + 轮转 | 只记 Agent |
| `Session.log-line` | 人类可读会话抄本，`$!log-on = False` | **默认关**、纯文本、只在交互主循环调一次，`-e` / 脚本 / 会话级命令全漏 |
| `Kernel.@!trail` | 内存 200 条 | 调试视图，不落盘 |

而且 `Kernel.execute` 是**末尾** `!record`，策略越界分支
`return $r if $denied` 会绕过它——注释写着「不能在这里直接 return」，
代码却偏偏 return 了。安全事件最该留痕的一条反而漏了。

## 4. 决定：一个写入函数、两个调用点、一套字段白名单

```text
人：  REPL / -e / 脚本 ──> Kernel.execute ──┐
                                            ├─> Rakuish::Audit.record ─> 内存 + JSONL
Agent：结构化 op ──> Sandbox.audit ────────┘
```

1. **`Rakuish::Audit.record` 是唯一写入函数**：字段白名单、`seq` / `ts`
   补齐、内存上限、单行 JSONL 追加、10MB 轮转、跨实例锁都在这里。
   `Sandbox.entries` 代理到它，原来的那套逻辑删掉（不再复制会漂移的代码）。
2. **`Kernel.execute` 用 `LEAVE` 记账**：正常 / 策略拒绝 / 早返回 /
   异常都恰好一条。整个块包在 `try` 里——审计自己抛异常不能弄崩求值。
3. **字段白名单**：`token` / 文件内容 / SQL 全文 / 源码全文**结构上进不来**，
   不靠每个调用点自觉。源码只记 FNV-1a 指纹 + 字节数；连编译错误消息
   也不记（Rakudo 常把源码片段带进消息）。FNV-1a 只有一份实现。
4. **共享实例**：两个入口都默认构造 `Audit` 并注入；测试可直接注入同一
   实例做双前端对账。默认落盘 `$*HOME/.rakuish/audit.jsonl`，
   `RAKUISH_AUDIT` 改路径、`RAKUISH_NO_AUDIT=1` 关闭。
5. **`seq` 跨进程连续**：新实例以现有 JSONL 行数为起点。

### 四个东西不合并

| 东西 | 给谁 | 为什么留着 |
|---|---|---|
| `Audit` | 机器 / 安全 | 结构化、默认开、覆盖所有操作 |
| `Session.log-line` | 人 | 会话抄本含渲染文本与 `Out[n]`，`log` 命令是查看器；格式完全不同 |
| `Kernel.trail` | 调试 | 200 条内存摘要，t/35 的契约 |
| `display` | 前端 | 结果内容（ADR-0016），与审计无关 |

把它们硬塞进一个结构，会让 Bundle 重新变成 TTY 专用，或让审计抄本
带上颜色——0.78 已经为这条分过一次界，这里不重犯。

## 5. 明确不做（写清楚，免得以后有人以为解决了）

- **日志防篡改**：本地 REPL 是本人可信用户，日志文件同用户可写。
  要防篡改得写外部追加-only（syslog / 管道 / WORM），本版没做。
- **日志当成事前阻止**：它只保证「每次操作有记录」，不阻止操作发生。
- **Agent 执行任意源码**：`execute` op 不做，从 ROADMAP 删除。
  只有显式双开关启动的「不安全 profile」才允许 `exec`——那是运维的
  显式选择，启动时有警告，不是默认能力。
- **OS 级沙箱 / VM 隔离**：0.79 讨论过的路线整体搁置。若将来真要跑
  不可信代码，单独立项，别从「审计」这条路上悄悄长出来。

## 6. 验收

- `t/40-audit.t`（51 断言）：字段白名单、seq / ts、关闭开关、轮转、
  6 次 `execute` 恰好 6 条（含失败 / 501 / 坏请求）、源码不进日志、
  **root 越界早返回也记一条**（变异护栏）、Agent 四种结果各一条、
  双前端共享账本、JSONL 单行与跨进程 seq、入口静态护栏、
  `-e` 模式默认落盘的端到端验证。
- `t/06` +6 条（0.79.2）：默认拒绝、请求级打不开、双开关才放行。
- 既有 40 个文件全绿（尤其 `t/35` 的 trail 契约、`t/07` 的入口、
  `t/38` 的 capabilities）。
- 双平台：Windows `prove6`、WSL `run-all.sh`、真 TTY 自检、
  `zef install` 安装期测试。

## 0.112.0 扩展：按 origin 分账

原先 `origin` 只是审计记录里的一个字段，写入时取 `Request.origin`，但没有任何
查询口；而且 `Request.origin` 是自由字符串，拼错也照记不误。0.112 补上两半：

- `Request.origin` 受 `valid-origin` 约束（四种已知值 + `x-` 前缀自定义），
  非法值在构造时就拒绝，不让脏来源进账本。
- `Audit.by-origin` / `origin-summary` 合并内存条目与磁盘 JSONL（按 seq 去重），
  Session 的 `audit` 命令暴露出来。`log` 保持原义（给人看的会话抄本），两者不混。

代价：读盘查询会随日志体积线性增长；账本有 10k 条 / 10MB 轮转上限，所以
实际查询范围有界。不引入索引 —— 审计是低频排查工具，不为它加一套存储结构。
