# ADR-0043 · Table 的 SQL 计算交给 DuckDB（Duckula），交换格式用 Arrow IPC

- **日期**：2026-11-24
- **对象**：0.120.0（`Table.sql` / `Rakuish::Data::Duck::query`）
- **状态**：**已实施**
- **输入**：用户问「Arrow IPC 做好了吗，和 Arrow::IPC 以及 Duckula 联合处理」
- **相关**：SPEC V-315、[ADR-0038](ADR-0038-arrow-ipc.md)（自研 Arrow IPC）、
  [ADR-0041](ADR-0041-arrow-read-via-package.md)（读侧走 Arrow::IPC）

## 1. 三层现状（回答前半句）

| 环节 | 谁做 | 状态 |
|---|---|---|
| `.arrow` → `Table`（读、含 list/struct/map/字典） | `Arrow::IPC` 0.1.0 | 0.118.3 起（ADR-0041） |
| `Table` → `.arrow`（写） | `Rakuish::Data::Arrow`（纯 Raku，零原生依赖） | 0.116.0 起（ADR-0038） |
| `Table` → SQL → `Table` | Duckula / DuckDB | **本 ADR** |

前两层已经互通，但缺「一起用」的入口：拿 Arrow 文件读到 `Table` 之后，只能
用 `where` / `select` / `join` 这套 Raku 方法，做不了聚合窗口、`group by`、
多源 join。补的就是这一段。

## 2. 决定：Arrow IPC 当交换格式，计算交给 DuckDB

```
Table ──自研写──▶ .arrow(临时) ──Duckula read-arrow──▶ DuckDB 表
                                                          │ SQL
Table ◀──Frame.rows / dtypes── Duckula Frame ◀────────────┘
```

- **不自己实现 SQL**：`where` / `select` 是数据形状操作，`group by` 窗口函数
  是查询引擎的活；重写一遍只会和 DuckDB 越走越偏。
- **不让 Duckula 写 IPC**：0.33.1 的 `ipc-buf` 在 timestamp/date 列上产出的是
  坏字节流 —— pyarrow `open_file` 报 `Not an Arrow file`，pyarrow `open_stream`
  与 `Arrow::IPC.decode-ipc` 在同一个文件上都会**段错误**（实测
  `t/fixtures/arrow/temporal.arrow` 经 `Frame.ipc-buf` 再解码，rc=139）。
  （0.121.0 逐列复核修正了这里的表述：坏的是 **TIMESTAMP WITH TIME ZONE**；
  `DATE` / `TIME` / 无时区 `TIMESTAMP` / `DECIMAL` 都正常。详见
  `tmp/upstream-issues/duckula-ipcbuf-timestamptz.md`。）
  回读改走 `Frame.rows` + `Frame.dtypes` 的 Raku 值，绕开这条路径；
  上游修好后这条绕行可以撤。
- **写侧复用自研**：它写出的文件 DuckDB 能直接读（时间戳、日期、NULL 都对），
  这也顺便成了自研写入器的第三方兼容性验证。
- **多表**：`sql({ a => $t1, b => $t2 }, 'select ... from a join b using (k)')`
  一次注册多张表；`$t.sql(...)` / `sql($t, ...)` 是单表糖（表名默认 `t`）。
  短命令不叫 `query`：引擎侧已有 `query(sql => '...')` 的具名参数约定，
  抢这个名字会把「少传参数」变成看不懂的错误；模块层仍叫 `Duck::query`。

## 3. 边界（都在 SPEC §3.54 写死）

- **只读**：`Session.sql` 的守卫会拒绝 `DROP` / `INSERT` 等；错误原样转成
  `X::Rakuish::Data`，点名「statement is not read-only」。
- **嵌套列**：`Table` 没有嵌套类型的表达式，进 DuckDB 前显式 `to-json` 成
  文本列（类型记 `str`）。可以 `like`、可以再 `from-json` 解回来，但**不能**
  在 SQL 里 `tags[1]` 或取 struct 字段 —— 这是如实的能力边界，不是 bug。
- **时间列**：SQL 结果里的 TIMESTAMP/DATE 还原成 `DateTime`；整列有一格解析
  失败就整列退回 `str`（和 `open-data` 口径一致）。
- **临时文件（0.134.0 已删除）**：原先是 `$*TMPDIR` 下每张表一个
  `rakuish-duck-*.arrow`，`LEAVE` 里删掉；现在改 DDL + Appender 直插，
  **一张临时文件都不产生**（t/76 断言数量为 0，比「创建了再清理」更强）。
  详见 §7。
- **可选依赖**：Duckula 不在 `depends` 里，没装时抛 `X::Rakuish::Unsupported`
  并给 `zef install Duckula` 提示；`Table.sql` 走 `require`，不会把原生
  libduckdb 拖进核心安装。
- **性能**：0.120.0 时是整表写一次 IPC 再读一次，O(行数) 的拷贝。0.134.0 起
  改为 DDL + Appender 直插（见 §7）：5 万行稳态 4,797 ms → ~1,530 ms（3.1×）。
  「省得自己维护查询引擎」这条理由不变。

## 4. 顺带修掉的静默损坏

`fields-of` 对未知类型落到 `default → utf8`，嵌套列的值走 `.Str`：Hash 的
`Str` 是 `age\t30\nname\tann`，于是 `save-data` 对嵌套表**看起来成功**、
写出来的却是噪声（0.119.0 之前一直如此）。0.120.0 起写侧对 `list` / `map`
（以及类型标错、值却是嵌套结构的列）明确抛 `X::Rakuish::Arrow`，报错里点名
列名并给出路（`select` 掉 / `to-json`）。

## 5. 验证

- `t/76-duck-sql.t` 48 条：聚合 / 计算列 / NULL / 浮点序 / 空表 / 时间往返 /
  多表 left join / 嵌套转 JSON / 只读守卫 / 非法表名 / 空 SQL / 原表不可变 /
  **不产生临时文件** / **关键字·引号·空格列名的 DDL 转义** /
  **超 int64 明确报错** / 写侧拒嵌套。
- 双平台套件与 `zef install`；WSL 侧 Duckula 已装（MoarVM）。

## 6. 代价（0.120.0 时）

见 §3「性能」。当时的结论是「大表场景后续可以换 create-table + Appender」——
§7 就是兑现这句。

## 7. 0.134.0 修订：去临时文件，改 DDL + Appender 直插

**触发**：`REVIEW-ARROW-COST-2026-11-25.md` 把六笔「图省事」的选择逐笔对账，
结论是这一笔**净亏且可立即纠正**：省下 DDL 拼装约 50 行，付出每张表一次
O(行数) 全量序列化 —— 5 万行 4,784 ms（占端到端 99.7%），而 SQL 执行本身
4–5 ms。

**做法**：

1. `Rakuish::Data::Duck::query` 不再写临时 Arrow 文件，改为
   ① 从 `Table` 的 `columns` / `types` 生成 `CREATE TABLE` DDL（标识符一律
   双写引号转义；`list`/`map` 在 `duck-ready` 之后已是 JSON 文本，存 `VARCHAR`）；
   ② `Duckula::Session.insert`（Appender）逐行写；
   ③ 再执行用户 SQL。DDL 走 `sql(:unsafe)`，因为 Guard 只放行只读语句。
2. **类型映射固定**：`int→BIGINT`、`num→DOUBLE`、`str/any→VARCHAR`、
   `bool→BOOLEAN`、`datetime→TIMESTAMP`。值按声明类型转换（VARCHAR 就 `.Str`，
   DOUBLE 就 `.Num`…），不再靠猜；`NULL` 用 `Any`（**不能**用类型对象 ——
   Appender 会触发 `MoarVM syscall kind obj, should be num`）。
3. **性能细节**（都是实测踩出来的）：
   - 抽「每列首个非空值」必须**一次遍历**拿全；按列各扫一遍是
     O(列数 × 行数)，5 万行 × 5 列多花 2.5 s（`duck-ready` 里曾埋着这个坑）。
   - 值已经是声明类型时（绝大多数）整表走直通分支 + hash 切片，不逐值调
     转换器；每值都转的版本实测 7.6 s，直通 1.5 s。
   - `require Duckula` 的模块加载约 1.9 s 是**一次性**成本（进程级），
     不在每格；对比时要看稳态。
4. **两个行为变化（如实记录）**：
   - **超 int64 现在报错**（老路径静默溢出成负数）。这是修正，不是回归；
     `t/76` 已钉住「明确报错 + 原表不被改写」。
   - 时间列声明显式 `TIMESTAMP`（老路径是写侧推断的 `TIMESTAMP_MS`）——
     值的语义等价（UTC naive，`Hour` 无时区），`typeof` 会从
     `TIMESTAMP_MS` 变 `TIMESTAMP`。
5. **兜底**：临时文件路径整体删除，不再保留双路径 —— 两条路都留会让「哪条
   在跑」变成运行时黑箱；回滚靠 git，不靠开关。

**实测（本机 5 万行 × 5 列，稳态）**：4,797 ms → 1,530 ms（**3.1×**）。
其中建表 + Appender 1,092 ms、SQL 42 ms、封表 ~50 ms；余下是行 reshaping。
（`REVIEW-ARROW-COST` 报的 5.6× 是「行列表已就绪」的口径，我们还要从
`Table` 的 Hash 行搬一次，故实际 3.1×。）
