# ADR-0067：会话命令改为数据驱动命令表（V-357 / 0.153.0）

- **状态**：已实施（0.153.0）
- **条款**：SPEC §3.86
- **结构守卫**：`t/91-command-table.t` 159 条
- **关联**：ADR-0060（role 拆分与属性归属）、ADR-0066（`!` 分发 role）

## 1. 背景

`lib/Rakuish/REPL/Session.rakumod` 的 `!eval-line-body` 里有一串 106 行的 `if` / `elsif`，
每一支的形状几乎都一样：

```raku
if $t eq 'perf' || $t.starts-with('perf ') {
    return self!cmd-perf($t);
}
elsif $t eq 'tb' || $t eq 'debug' || $t eq 'backtrace' {
    return self!cmd-tb($t);
}
```

这串链有两个成本：

1. **新增一条会话命令要改一个 547 行的方法**，而且要照着邻居手抄命中条件。抄漏 `starts-with`
   就变成「命令不带参数能用、带参数落回 Raku」——这类错不会在编译期出现，只在某个参数形态下出现。
2. **没有任何一处能回答「会话有哪些命令」**。`!help` 不列它们、SPEC 里散在十几节、连测试也是
   一命令一条各写一遍。想查「`whos` 还不存在」只能全文搜。

ADR-0066 把 `!` 那一整段搬进 role 之后，`!eval-line-body` 还是 235 行，命令链仍是其中最长的一段。

## 2. 决定

把这 22 条命令变成**一张数据表 + 一个分派器**，两条控制流变一条。

```raku
my constant SESSION-COMMANDS = (
    %(name => 'history', mode => 'exact',  arg => 'none', m => 'cmd-history'),
    %(name => 'perf',    mode => 'argv',   arg => 'raw',  m => 'cmd-perf'),
    %(name => 'tb',      mode => 'argv',   arg => 'raw',  m => 'cmd-tb',
      alias => <debug backtrace>),
    ...
    %(name => 'whos',    mode => 'exact',  arg => 'const', m => 'cmd-who',
      const => 'who -l'),
);
```

字段：

| 字段 | 含义 |
|---|---|
| `name` | 命令名（不带 `!`） |
| `mode` | `exact` 只认裸名字；`only-argv` 只认「名字 + 空白 + 参数」；`argv` 两者都认 |
| `alias` | 额外名字，**只按精确匹配**（仅 `tb`：`debug` / `backtrace`） |
| `arg` | `raw` 传整行 `$t`；`trim` 传 `$t.trim`；`const` 传固定串；`none` 不传参 |
| `m` | 方法名，**不带 `!`** |

分派器：

```raku
method !dispatch-command(Str $t) {
    my Str $head = $t.trim;
    for SESSION-COMMANDS -> %c {
        my Str $name = %c<name>;
        my Bool $hit = given %c<mode> {
            when 'exact'     { $head eq $name }
            when 'only-argv' { so $head ~~ /^ $name [ ' ' | \t ] / }
            default          { $head eq $name || so $head ~~ /^ $name [ ' ' | \t ] / }
        };
        $hit ||= so %c<alias>.defined && %c<alias>.list.first({ $head eq $_ }).defined;
        next unless $hit;
        my Str $m = %c<m>;
        given %c<arg> {
            when 'none'  { self!"$m"() }
            when 'trim'  { self!"$m"($head) }
            when 'const' { self!"$m"(%c<const>) }
            default      { self!"$m"($t) }
        }
        return;   # Nil：已处理
    }
    Nil;          # 未命中，调用方继续往下走
}
```

`!eval-line-body` 里剩下三行：

```raku
my $cmd = self!dispatch-command($t);
return $cmd if $cmd.defined;
```

**顺序无关**：22 个名字互不前缀（`who` 与 `whos` 也不冲突——`argv` 模式要求名字后跟空白，
`whos` 不带空白），所以表可以任意重排而不改变行为。这一点写进了测试：名字集合与顺序无关，
只断言集合与每个名字的方法存在。

## 3. 语言层取证

### 3.1 动态私有方法调用可行

表里存方法名字符串、运行时 `self!"$m"`——这条路径先验证过。三次探针：

```raku
class C {
    method !dyn(Str $x) { "dyn $x" }
    method !call(Str $n, Str $x) { self!"$n"($x) }
    method run { self!call('dyn', 'ok') }
}
```

外部调用 `C.new!dyn(...)` 报
`Calling private method 'dyn' must be fully qualified with the package containing that private method.`
（这是**外部调用**的限制，不是动态分派的问题）。

换 `.` 语法：`self."!$n"($x)` 报
`No such method '!hi' for invocant of type 'C'. Method name starts with '!', did you mean 'self!"hi"()'?`
——公开方法按名字调用不接受 `!` 前缀。

`self!"$n"($x)` 在类内、含 role 组合时都成功：

```raku
role R { method !hi(Str $x) { "hi $x" } }
class C does R {
    method !via-bang(Str $n, Str $x) { self!"$n"($x) }
    method !via-bang0(Str $n) { self!"$n"() }
}
# → "hi there" / "noarg-called"
```

**结论**：表项可以是纯数据（方法名字符串），不需要每项写成闭包。21 个方法里 12 个住在
八个 role 里，动态分派一样到达——这一点是本 ADR 能成立的前提。

### 3.2 `<[ \t ]>` 匹配不到制表符

初版分派器写 `/^ $name <[ \t ]> /`，结果所有带参命令全部落回 Raku（`Undeclared routine: recall`）。
逐项探针：

| 写法 | `'recall 1'` |
|---|---|
| `/^ recall <[ \t ]> /` | **不匹配** |
| `/^ recall <[ \x20 \t ]> /` | 匹配 |
| `/^ recall [ ' ' \| \t ] /` | 匹配 |
| `/^ recall \s /` | 匹配 |

Raku 的字符类 `<[...]>` 里 `\t` 不展开成制表符。最终用 `[ ' ' | \t ]`（可读且不依赖转义细节）。

## 4. 哪些**没有**进表

- **`set` 家族**：`set` / `set -o NAME` / `set -e` 是三条正则、语义是解析而不是分派，且第二条要
  把参数再拆一次。硬塞进表得给表加一个 `parse` 字段，等于把控制流换个地方写。
- **`名字?`**：`$` / `@` / `%` 可选 + 可选 `::` 的正则，命中的是任意用户标识符，不是固定命令名。
- **历史替换**（`!!` / `!$` / `!-n` / `!n`）：受 `!$.expanding` 与 `$!histexpand` 两个开关控制，
  命中后要再走一遍 `eval-line`，不是「调一个方法就返回」。
- **`!` 分发**：已由 ADR-0066 的 `!dispatch-bang` 负责，返回值语义与命令表相同（`Nil` = 未命中）。
- **shell 习惯命令与 Raku 本身**：兜底路径，不是命令名形态。

这五段仍按原来的顺序留在 `!eval-line-body` 里。命令表插在它们之前——位置与原来 106 行链完全一致。

## 5. 行为等价怎么验的

只跑测试不够：测试覆盖的是想得到的行为，`if` 链改写最容易错的是「某个参数形态下命中条件变了」。
所以做了逐条对比：

1. 写 35 条输入脚本（22 条命令各一条带参与裸名、`set` 三条、`set -x`、`1 + 1?`、`!!`、`!echo hi`、
   纯 Raku、裸 `unalias`），打印每条 `op` / `ok` / `code` / `out`；
2. `git stash push -- lib/Rakuish/REPL/Session.rakumod` 回到 0.152.0 跑同一脚本；
3. `Compare-Object` **零差异**。

这一步抓到的唯一问题就是 §3.2 的 `<[ \t ]>`：修之前带参命令全部落回 Raku，逐条对比一眼能看出来，
而 `t/91` 的第一版只测了裸名，全绿。**等价性靠对比，不靠断言覆盖率。**

## 6. 没采用的方案

- **每项存闭包**（`run => -> $s, Str $raw { $s!cmd-perf($raw) }`）：能work，但表就不再是数据了——
  22 个字段里 22 个是代码，`t/91` 也没法「读表 + 断言每个方法真实存在」。§3.1 的探针让纯字符串可行。
- **表放在 role 里**：命令表是会话级的（22 条命令分属八个 role 的方法），放任何一个 role 都会让
  那个 role 依赖其余七个。留在 Session。
- **顺手把 `set` 表驱动**：见 §4。
- **给表加 `help` 字段做 `!help` 命令列表**：现在 `!help` 的文本是手工维护的；能自动生成是好事，
  但那是行为变更（`!help` 输出会变），不属于「纯重构」这一刀。

## 7. 结构不变量（`t/91` 159 条）

- `SESSION-COMMANDS` 存在、以 `\n);` 正常结束、**22 项**、无重名；
- 名字集合 = `history perf tb errors log audit hint plugin describe who whos rerun recall
  source paste store cells alias unalias config hook explore`；
- 每项的 `mode` ∈ {`exact`,`argv`,`only-argv`}、`arg` ∈ {`raw`,`trim`,`const`,`none`}、`m` 非空
  （22 × 3 = 66 条）；
- 每个 `m` 在 9 个文件（Session + 八个 role）里都能找到 `method !m(`（22 条）；
- 特例：`tb` 的 `alias` 恰好是 `<debug backtrace>`；`whos` 的 `arg` 是 `const` 且 `const` 是 `'who -l'`；
- 分派器：`!dispatch-command` 存在、含 `self!"$m"`、`!eval-line-body` 里含
  `self!dispatch-command($t)`、全文件**只出现一次** `!dispatch-command(`；
- 旧链已消失：22 条断言逐命令检查 `starts-with('<name> ')` 与 `eq '<name>'` 都不再出现
  （`set` 家族除外——它有单独断言证明还在）；
- 规模：Session 行数 `> 2,200` 且 `< 2,400`；
- 运行时：24 条逐命令 `op` 断言；`set` / `set -o` / `set -e` 仍 `op=set`、`set -x` 仍落回 `eval`、
  `history?` 仍 `op=doc`、`!echo table-ok` 仍 `exec`、裸 `unalias` 落回 Raku；
  `!!` 仍能重跑且自身不进 history；`rerun 1` 带回值 3。

## 8. 下一步

拆分侧只剩渲染段（346 行，13 个属性 / 6 个私有、8 个辅助）一个成块候选，边界比已拆的七刀都宽。
另一条线是启动时间：`rakuish -e '1+1'` 623 ms，其中约 470 ms 在模块加载，可做惰性加载——
那是运行时改动，不是重构，收益可测（`raku -e 1` 是 156 ms）。
