# ADR-0061：Session 拆分第二步 —— 诊断 / 渲染簇与两个访问器陷阱

- 状态：已实施（0.147.0 / SPEC V-351）
- 相关：ADR-0060（属性归属规则）、SPEC §3.79（第一步与规则）、SPEC §3.80（本条条款）、`t/85-diagnostics-split.t`
- 取证方式：Rakudo Star **v2026.11**（本机 Windows）；两轮失败探针 + `t/34` / `t/19` 回归 + 全套件

## 1. 背景

0.146.0（ADR-0060）把 `Session.rakumod` 从 4,304 行压到 4,035 行，拆出 `Session::Commands` 与 `Session::Config`，并定下规则：**属性留在 Session，role 方法走公开访问器**。

下一个天然子系统是诊断 / 渲染：`!cmd-explore` / `!cmd-perf` / `!cmd-tb` / `!cmd-audit` / `!cmd-log` / `!cmd-hint` / `!cmd-who`，加 10 个只服务它们的辅助（`perf-report` / `!render-trace` / `collect-traceback` / `!source-line` / `log-line` / `hint-text` / `next-hint` / `!sigil-rank` / `!value-type` / `!value-size`）。共 17 个方法，本条把整簇搬成第三个 role。

结果：`Session.rakumod` **4,035 → 3,630 行**（相对 0.146.0 的 diff 是 93 insertions / 498 deletions），新文件 `Diagnostics.rakumod` **436 行**。

## 2. 为什么是这一簇：调用闭包，不是行数

拆分的判据是**耦合度**，不是「看着像一块」。诊断簇的 17 个方法互相调用成一个几乎闭合的图：

- `!cmd-tb` → `!render-trace` → `collect-traceback` → `!source-line`；
- `!cmd-hint` → `hint-text` / `next-hint`；
- `!cmd-who` → `!sigil-rank` / `!value-type` / `!value-size`；
- `!cmd-log` → `log-line`（`!cmd-audit` 也调 `log-line`）。

朝外的边只有三条，而且都指向公开 API：`!cmd-explore` 用 `$.sys` 与 `Rakuish::Data::*`，`!cmd-who` 读 `%.state` / `@.decls`，`log-line` 写 `@.cells[*-1]<rendered>`。

对比 0.146.0 拒绝搬的 `@!decls`（5 / 33）、`%!state`（9 / 26）、`@!history`（15 / 23）：那些属性的引用**大半落在命令外**的求值核心里，整组搬走会让 role 反向拥有会话核心状态。诊断簇则是反过来 —— 方法引用密集在簇内，属性引用稀疏地落在少数几个公开点上。

## 3. 决定性发现：两个访问器陷阱

第一版机械地把 `$!x` 全改成 `$.x`，然后把三条历史访问器也原样搬/恢复，撞了两个坑。两次都不是「风格问题」，是运行时崩溃。

### 3.1 `$.x` 在方法体里是**方法调用**，不是属性读取

```raku
method log-path(--> Str) { $.log-path }
```

`$.log-path` 等价于 `self.log-path`，于是方法调自己。`t/34-userland.t` 在第 50 条 `log start` 处死掉：

```
MoarVM panic: Memory allocation failed; could not allocate 131072 bytes
```

注意报错**不是**「too much recursion」，而是内存分配失败 —— 131072 字节这种小额分配失败极容易被误判成环境问题。判据是：同一条路径只在 `log start` 触发，且栈上没有业务代码。

### 3.2 手写只读方法会**遮蔽** `is rw` 属性的写访问器

把方法体改回 `$!log-path` 后，换成第二种崩法：

```
Cannot modify an immutable Str ()
  in block at t/34-userland.t line 272
  in method cmd-log at t/34-userland.t line 250
  in method eval-line-body at lib/Rakuish/REPL/Session.rakumod line 1585
  in method eval-line at lib/Rakuish/REPL/Session.rakumod line 1374
  in block <unit> at t/34-userland.t line 96
```

原因：`has Str $.log-path is rw` 生成读写访问器，但类里手写的 `method log-path` 覆盖了它。role 里 `$.log-path = $path` 走的是手写的只读方法。方法体写 `$!log-path` 也救不了 —— role 读不到类的私有属性（ADR-0060 §2.2 的方向仍然成立）。

### 3.3 由此得到的硬规则

> **不要给 `is rw` 公开属性手写同名访问器。** 需要只读别名时另起名字。

本条的落法：

- 删掉手写的 `method log-path` / `method log-lines`，读写都交给 `has Str $.log-path is rw` / `has @.log-lines is rw` 自带的访问器；
- 保留 `method log-active(--> Bool) { $!log-on }` —— 名字与属性 `log-on` 不同，无遮蔽，方法体必须用 `$!`（`$.log-on` 会再次变成自递归）。

副作用：`log-lines` 现在返回活 `Array` 而非 `List` 拷贝。全仓库无代码/测试依赖旧形状（`SPEC.md` 只把 `log-lines` 列为属性名），可接受。

## 4. 决定

1. 新增 `lib/Rakuish/REPL/Session/Diagnostics.rakumod`：
   `unit role Rakuish::REPL::Session::Diagnostics;`，7 条命令 + 10 个辅助，共 17 个方法 / 436 行。
2. `Session` 改 `unit class Rakuish::REPL::Session does ...Commands does ...Config does ...Diagnostics;`，三条 `use` 写在 `unit` 之前。
3. 属性仍全部留在 Session。把诊断簇要用的 8 个私有状态改公开：`$!log-on` / `$!log-path` / `$!log-seq` / `@!log-lines` / `@!decls` / `@!out` / `@!cells` / `%!hinted` → `$.` / `@.` / `%.`，并全文改写引用。
   顺带公开 `$.expanding`（`!cmd-rerun` 用）与 `$.skip-cell`（`!cmd-cells` 用）—— 不在本簇，属预备。
4. `$!last-error` / `$!last-error-text` **保持私有**：它们已有公开只读方法 `last-error` / `last-error-text`，role 直接调方法。
5. 日志访问器按 §3.3 收敛：`log-active` 留 Session；`log-path` / `log-lines` 删手写方法，由 `is rw` 属性访问器承担。
6. `META6.json` provides 49 → 50（`t/51` 守着 provides 与 lib 下文件数一致）。
7. 簇内方法用到的私有辅助若留在 Session（如 `note-timing`），role 可以按名字调用 —— 实测 role 方法调类私有方法成功。**但属性不行**，这条不对称是本条全部麻烦的来源。

## 5. 没采用的方案

- **把 65 个属性一次性全公开 / 全改名。** diff 会淹掉真正的结构改动，而且 `@!history` 等属性在求值核心里有 15–33 处引用，改名收益为零、回归面最大。只公开被搬走的方法真正读写的那些。
- **属性随方法一起搬进 role。** ADR-0060 §2.3 证明这条路语言上可行（role 声明、类 `does` 后两边都能读），但诊断簇与求值核心共享 `@.decls` / `%.state` / `@.history`，搬走就变成 role 拥有核心状态、Session 反向依赖 role，耦合只是换了个方向。
- **保留三条手写日志访问器。** 就是 §3 的两个崩溃。
- **让 role 用 `self.%!x` 之类的间接写法。** 不存在这种语法；`trusts` 在 v2026.11 仍未实现（ADR-0060 §2.1）。

## 6. 不变量

- `Session.rakumod` < 3,700 行；Diagnostics 恰好含那 17 个方法、不含 `!cmd-rerun` / `!cmd-cells` / vi / 求值核心。
- Session 里不存在手写的 `method log-path` / `method log-lines`；`log-active` 仍在 Session 且读 `$!log-on`。
- 三条 `does` 与三条 `use` 都在；`META6.json` 有 Diagnostics 条目。
- 行为：`who` / `perf` / `tb` / `log` / `hint` 与空 `collect-traceback` 的对外形状不变。
- 调度点（`Session.rakumod` 的 `eval-line` → `!cmd-*`）不动，只是被调方法现在来自 role。

## 7. 结构守卫清单（`t/85-diagnostics-split.t`，50 条）

1. 四个文件都在；三个 `unit role` 头正确；Session 的三条 `does` 与三条 `use` 都在。
2. 7 条命令不在 Session；10 个辅助不在 Session 而在 Diagnostics。
3. `log-active` 留在 Session 且不在 role；`log-path` 没有手写方法（用 `nok` 断文本 `method log-path`）。
4. `cmp-ok $sess-lines, '<', 3700` —— 比现在的 3,630 宽松，比拆分前的 4,035 紧。
5. `META6.json` provides 50 条，含 Diagnostics。
6. 运行时：`^can` 覆盖 17 个方法名前缀检查；`who` / `perf` / `tb` / `log` / `hint` 可跑；无异常时 `collect-traceback` 返回空。

**测试环境坑（记一笔，防误判）**：`t/19` 的「管道下仍正常求值」在本机 `workspace-write` 沙箱下必红 —— 任何子进程的 stdio 捕获都被杀（`run(..., :out, :err)` 返回 `exit=-16`，连 `raku -e 'say 42'` 也一样；全继承则 0）。换 `danger-full-access` 后 `t/19` **98/98**。这不是 Rakuish 的缺陷，别去改代码。

## 8. 下一步

- 诊断簇搬走后，`@.decls` / `%.state` / `@.history` / `@.out` 都已是公开属性，**快照 / 历史簇**（`!cmd-snapshot` 系、`@.history` 相关）从「被私有状态卡住」变成可评估的下一刀。
- 仍不建议整组搬 `!cmd-rerun` / `!cmd-cells`：它们直接改 `$.expanding` / `$.skip-cell` 与 `@.cells` 的记账，和 `eval-line` 的 `Out[n]` 分配同生共死。
- 每次拆完都该问同一句：这一簇的调用是不是闭合的？闭合度比行数更能预测 diff 的可读性。
