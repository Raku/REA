# ADR-0069 Rakuish ⟷ Duckula 的边界：关系代数归 Duckula，值表示归 Rakuish（V-361）

- 状态：已实施（三处行为变更：空列聚合 → NULL、SQL 报错带 `hint`、依赖地板统一）
- 版本：0.155.0
- 条款：`SPEC.md` §3.89
- 相关：[ADR-0043](ADR-0043-table-sql-via-duckula.md)（`Table.sql` 走 Duckula）、
  [ADR-0006](ADR-0006-data-csv-dialect.md)（`describe` 的 profile 契约）、
  [ADR-0022](ADR-0022-snapshot.md)（值/状态的口径先例）

## 1. 背景

用户同时在维护 **Duckula**（借 DuckDB 的 DataFrame 层）与 **Rakuish**。两个库
都在做「表格数据」，于是同一个动作有两个入口、两个默认值、两套 schema。用户
问的是：「目前两个项目有没有边界不清的问题？」

这不是读文档能回答的问题。做法是两边源码各读一遍 + 探针对照实测：同一份数据
同时喂 `Rakuish::Data::Table` 和 Duckula 的 Frame，看两边对同一个问题给出的答案。

## 2. 审计结果

### 2.1 依赖方向：干净

- Duckula 仓库里**没有** `use Rakuish`；只有
  `C:\Users\Administrator\duckula\lib\Duckula\Frame.rakumod:193` 一句 docstring
  提到 `Rakuish::Data::Duck`（说明 `columns-typed` 是给谁用的）。
- Rakuish 从不把 `Frame` 漏给用户：`lib/Rakuish/Data/Duck.rakumod:71-80` 的
  `table-from-frame` 是唯一的出口，返回的永远是 `Table`。
- 所以**不存在循环依赖**，也不存在「用户手里同时有两种表」。

### 2.2 能力面重叠：5 类

| 能力 | Rakuish `Table` | Duckula `Frame` | 判定 |
|---|---|---|---|
| 关系代数 | `where` / `select` / `join` / `sort-by` / `limit` / `offset` / `distinct` | 同名 + `group-by` / `having` / 窗口 | **归 Duckula**（Rakuish 冻结） |
| 聚合 | `sum` / `mean` / `min` / `max` | `sum` / `mean` / `min` / `max`（SQL） | 同名不同语义 → 本次对齐 |
| 摘要 | `describe`（7 列 profile） | `describe`（SQL `SUMMARIZE`，11 列） | **两种对象，两套 schema** |
| 类型系统 | `types`（int/num/bool/datetime/str/list/map）+ `duck-type` | `Duckula::Dtype`（241 行）+ `dtype-from-sql` | 重叠，本版不动 |
| SQL 适配 | `Engine::DuckDB` 直连 + `Duck.rakumod` 走 Duckula | Duckula 自己持 DuckDB | 两条路径，本版不合并 |

### 2.3 三处用户可见的不一致（实测）

**空列聚合**（列值 `1, NULL, 3` 与整列 `NULL, NULL`）：

```
TABLE sum=4 mean=2 count=3
TABLE all-null sum=0 mean=0        ← Rakuish：空列答 0
DUCK  agg rows=([4 2 2 3])
DUCK  all-null=([(Any) (Any)])     ← DuckDB / SQL：空列答 NULL
```

`lib/Rakuish/Data/Table.rakumod:234-242` 的 `@v.elems ?? @v.sum !! 0e0` 是来源；
`min` / `max`（`:244-252`）又答 `Nil` —— 同一个「没有值」在 Table 里有三种表现。

**join 默认值相反**：`lib/Rakuish/Data/Table.rakumod:296` 是 `:how = 'left'`，
`C:\Users\Administrator\duckula\lib\Duckula\LazyFrame.rakumod:1023` 是
`:how = 'inner'`。Table 那行的注释已经自认了这个坑：「两个默认值不同的 API 比
一个会静默改变既有脚本行为的 API 更糟……保持历史默认」。

**describe 两套 schema**：Table → `name type nullable non_null distinct total sample`；
Frame（`SUMMARIZE`）→ `column_name column_type min max approx_unique avg std q25
q50 q75 count null_percentage`。同一个名字，两种表。

### 2.4 三个隐式契约

1. **`columns-typed` 是 Duckula 为 Rakuish 写的 API** —— docstring 原文「给
   Rakuish::Data::Duck 的 table-from-frame 用」
   （`C:\Users\Administrator\duckula\lib\Duckula\Frame.rakumod:189-194`）。Rakuish
   用 `$frame.^can('columns-typed')` 探测（`lib/Rakuish/Data/Duck.rakumod:75`），
   版本不符时**静默降级**到行式回读（5 万行走 4 s 量级）。
2. **版本地板互相矛盾**：`lib/Rakuish/Data.rakumod` 一处写 `Duckula:ver<0.36+>`，
   但 `columns-typed` 是 **v0.38.0** 引入的（`git log -S columns-typed` →
   `ca7cfb9`，`git tag --contains` → v0.38.0）；`DB::DuckDB` 的地板同时出现
   1.2.2+ 与 1.3.1+，而 Duckula 自己的 META6 要求 `DB::DuckDB:ver<1.4.3+>`。
3. **标识符校验各写一份**：`lib/Rakuish/Data/Duck.rakumod:31` 的 `check-name`、
   `:278` 的 `quote-ident`；Duckula 侧 `ArrowRead.rakumod` 等也有 `quote-ident`。
   （不合并：两份实现都很小，合并会逼出一个公共依赖。）

### 2.5 报错被截断

`lib/Rakuish/Data/Duck.rakumod:417-419` 只取 `.lines[0]`：

```
# Rakuish 实际看到（0.154.1）
SQL 执行失败: cannot prepare statement: Binder Error: Referenced column "nope" not found in FROM clause!

# DuckDB 原文里还有
        Candidate bindings: "a"
LINE 1: select nope from d
               ^^^^
```

也就是说，最有用的一半（「你是不是想写 a」「错在第几列」）被扔掉了。

## 3. 决定

### 3.1 边界宪章（写进 SPEC §3.89）

> **Duckula 拥有关系代数，Rakuish 拥有值的表示、显示、交互与格式边界。**

Rakuish 的 `Table` 是「一列类型 + 一批 Hash 行 + 显示/导出」的最小容器，不是
DataFrame。需要 `group-by` / 窗口 / `having` 时走 `$t.sql(...)`，不要在 Table 上
造第二套关系代数。

### 3.2 空列聚合 = NULL

`sum` / `mean` / `min` / `max` 在无值列上统一返回 `Any`（Rakuish 里 NULL 的值
表示），与 `$t.sql(...)` 拿回的空值同口径。`--> Num` 标注随之改成 `--> Any`
（`Any` 不是 `Num`，旧标注会强行把 `Any` 变成 0 —— 这正是要消灭的行为）。

### 3.3 报错不截断：`detail` 一行 + `hint` 后半

`X::Rakuish::V3`（`lib/Rakuish/Result.rakumod:16-19`）加一个可选 `has Str $.hint`，
`message` 在 hint 存在时返回 `detail ~ "\n" ~ hint`。没有 hint 的异常文本与
0.154.1 **逐字相同**——日志与单行状态栏的消费方不受影响。

SQL 桥把 DuckDB 报错拆成两段：第一行进 `detail`（保留 `SQL 执行失败:` 前缀），
其余行进 `hint`。

### 3.4 `describe` 不改名（自我推翻）

我在审计建议里写了「`Table.describe` 改名 `profile`」，查证后撤回。它不是
孤立方法，而是**跨层契约**：

- `lib/Rakuish/DSL.rakumod:140` — `return $value.describe(:$sample) if $value ~~ Rakuish::Data::Table;`
- `Engine` 角色文档要求 `describe` 返回与 `Table.describe` 相同的 7 列
  （`lib/Rakuish/Data/Table.rakumod:161`）
- `lib/Rakuish/REPL/Session.rakumod:2211` 与 `:2216` — `describe` 会话命令两侧都调它
- `t/25-describe-complete.t` 有 20+ 条断言钉这套 schema（`t/25:29-46`、`75-89`、`106-146`）
- `docs/DEVELOPMENT.md:541`（`$t.describe;` 的用法）、`:1271`（t/25 行）、`:1341`（ADR-0006 行）

改名会同时动 DSL、角色契约、REPL 命令、测试与文档，换来的只是「名字更准确」。
两个 `describe` 属于两种对象（`Table` vs `Frame`），而 **Rakuish 从不把 Frame
交给用户** —— 用户根本不会看到冲突。所以保留名字，在 SPEC 里写清两套 schema
各属其主。

### 3.5 依赖地板只在一个地方定义

`lib/Rakuish/Data/Duck.rakumod` 顶部新增三个导出常量：

```raku
our constant DUCKULA-MIN-VERSION = v0.38.0;   # columns-typed 的引入版本
our constant DUCKULA-DB-VERSION  = v1.4.3;    # Duckula 自己 META6 的地板
our constant ENGINE-DB-VERSION   = v1.3.1;    # Engine 直连路径的地板
```

报错文案改为引用常量；`lib/Rakuish/Data.rakumod` 里两处过期的字面量
（`Duckula:ver<0.36+>`、`DB::DuckDB:ver<1.2.2+>`）改正。**两条路径地板不同是
有意的**：走 Duckula 就要满足 Duckula 的地板，走 Engine 直连只要 1.3.1。

## 4. 本版没做的两条

| 建议 | 为什么没做 |
|---|---|
| `duck-type` 退役，改用 `Duckula::Dtype::dtype-from-sql` | 要么改 Duckula 的导出面，要么把 Duckula 变成编译期依赖（现在是可选依赖、运行时加载）。留给上游拍板 |
| 合并两个 DuckDB 适配层 | `Engine::DuckDB` 服务行流（`stream` / `open-data --allow-external`），`Duck.rakumod` 服务列式 Table。合并 = 让 Duckula 变必选依赖，与「可选生态」的定位相反 |

## 5. 没采用的方案

1. **`Table.describe` 改名 `profile`** —— 见 §3.4，跨层契约成本远大于收益。
2. **在 `Table` 上补 `group-by` / `having` / 窗口** —— 那是把 Rakuish 变成第二个
   DataFrame，两边语义必然再次分叉。用户已明确「生态借 Python、底座用 Raku」，
   关系代数就借 DuckDB 一家。
3. **把 `join` 默认值统一成 `inner`** —— 会让既有脚本静默改变结果。保留 `left`
   并在 SPEC 写明「Table 默认 left、SQL 默认 inner，跨层搬运时显式传 `:how`」。
4. **把 `Frame` 直接交给用户**（省一次转换） —— 会把 Duckula 的类型/生命周期
   漏进 Rakuish 的 API 面，`store` / `snapshot` / `cells` 全部要处理新类型。

## 6. 不变量

1. `Table.sum` / `mean` / `min` / `max` 在无值列上一律 `Any`（`.defined` 为假）。
2. 非空列的聚合结果与 0.154.1 完全一致。
3. `X::Rakuish::V3` 无 `hint` 时 `message` 与旧版逐字相同；有 hint 时行数 =
   `detail.lines + hint.lines`。
4. `Table.describe` 的列集合恒为 `name type nullable non_null distinct total sample`。
5. `Table` 不新增 `group-by` / `having` / `window` / `pivot` / `rolling` 方法。
6. `DUCKULA-MIN-VERSION` / `DUCKULA-DB-VERSION` / `ENGINE-DB-VERSION` 是地板的
   唯一来源；报错文案不得再出现裸版本字面量。
7. 依赖方向：Duckula 仓库不得 `use Rakuish`；Rakuish 不得把 `Frame` 作为返回值。
8. `Table.sql` 仍返回 `Table`，不返回 `Frame`。

## 7. 测试与守卫

新增 `t/93-duck-boundary.t`（**39 条**）：

- 空列/零行聚合 9 条；非空列不变 4 条。
- `hint` 语义 6 条（无 hint 逐字相同、拼行数、开头、detail 单行、hint 可选）。
- `describe` schema 3 条（7 列、逐列一行、无 `column_name`）。
- 关系代数冻结 6 条（5 个方法名不存在 + `.sql` 仍是逃生口）。
- 依赖地板 7 条（三个常量 + 两处过期字面量已清 + 提示同值 + 报错引用常量）。
- 与 SQL 对齐 8 条（Duckula 缺席时 `skip`）：空列 `sum` 在 SQL 侧也是 NULL、
  `count(*)` 不受 NULL 影响、未知列报错仍是 `X::Rakuish::Data`、detail 单行、
  hint 带候选、message 两段。

## 8. 下一步

- **给 Duckula 的五件契约**（待上游决定）：`columns-typed` 转正成公共 API、
  `ipc-buf` 修 TIMESTAMPTZ、惰性 `head(n)`、类型映射表、`read-arrow` /
  `append-arrow` 的稳定签名。
- 若哪天 Rakuish 要用 `dtype-from-sql`，条件是把 Duckula 从「运行时可选」
  改成「编译期可选」的一层薄适配；那是另一个 ADR。
- `Table.describe` 与 `SUMMARIZE` 的差异目前只在 SPEC 里写；如果将来 Rakuish
  暴露 Duckula 的 Frame（本 ADR 明确不做），这条要重新审。

## 9. 上游回音（0.155.2，2026-11-27）

Duckula 侧在 v0.54.0 回应了本 ADR 第 8 节的五件契约（Duckula commit `665fb1d` +
`0719544`，HEAD = `origin/master`；Windows 53 文件 / 1,855 项、WSL 同样 1,855 项，
`tools/check-cookbook.raku` 87/87）。逐条：

1. **`columns-typed` 转正**：不新增代码，把 docstring 写成三条硬契约（List 长度
   == `names.elems`、每列长度 == `elems`、NULL 是 `Any`），注明「v0.54.0 起签名
   稳定」。→ 本 ADR 的地板从 `v0.38.0` 提到 **`v0.54.0`**：桥依赖的是形状，
   而形状从这一版起才被承诺。
2. **`ipc-buf` 不用修**：上游用 pyarrow 26.0.1 做了回归——`write-ipc(:format<file>)`、
   `(:format<stream>)`、`ipc-buf` 三路都能读 TIMESTAMPTZ（`timestamp[us, tz=Asia/Shanghai]`），
   DATE 是 `date32[day]`，微秒 `.123456` 未被截断；DuckDB 读回仍是 TIMESTAMPTZ。
   §2.4 里「0.33.1 读不了」从现在起只能当**历史**读，不能当现状引用。
   → 本桥仍然不写 IPC，但 `lib/Rakuish/Data/Duck.rakumod` 头部注释必须改：理由
   从「上游坏了」换成「不新增耦合」（编码侧是自研的 `Rakuish::Data::Arrow`，
   零原生依赖；让上游写 IPC 等于把桥的正确性绑到别人的序列化细节上）。
3. **惰性 `head(n)`**：本来就有（`plan-limit`，`explain` 里能看到 `LIMIT`；
   `head(3).head(1)`、`head(0)` 都成立），上游只补了测试。
4. **类型映射表**：进 Duckula 的 `ARCHITECTURE.md §8.63` 与 README。值得记的一条：
   Arrow 没有 int128，`HUGEINT` → `decimal128(38,0)`。
5. **`read-arrow` / `append-arrow`**：前者冻结签名，后者新增。`append-arrow` 的
   实现有个值得抄的教训——DuckDB 的 `INSERT ... BY NAME` 对**缺失列静默填 NULL**
   （实测 `insert into t by name select 1 as a` 在 `t(a,b)` 上得到 `(1, None)`），
   所以它先比列名集合再插入（`missing in file: b` / `not in table: c`）。

**没有跟着改的两条**（仍是本 ADR 的结论）：

- `join` 默认值（`Table` 是 `left`、SQL 是 `inner`）、`describe` 两套 schema：
  维持各自默认，只补文档。上游同此结论。
- `duck-type` 退役与两个 DuckDB 适配层合并：仍卡在「Duckula 是运行时可选还是
  编译期可选」这个前提上（§8 第二条）。

测试随之从 39 条增至 **42 条**：新增「`0.38+` 也已清掉」「旧注释『等上游修』已消失」
「注释里记下了上游修好的版本 0.53.0」三条。地板断言改成 `0.54.0`。

