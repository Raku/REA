# ADR-0048 · 显示协议：对象级 MIME 与 `display()`

- **日期**：2026-11-24
- **对象**：`Rakuish::Display` / `Result::Renderer` / `Session.render` / `Kernel::Notebook`
- **状态**：**P1 已实施（0.124.0）**；P2/P3 仍为草案，见 §6。
  P1 落地条款：SPEC V-326…V-330；回归见 `t/80`。
  本文其余部分仍是 P2/P3 的设计依据，未实施部分不得当成现行契约。
- **输入**：[`REVIEW-VS-IPYTHON-2026-11-24.md`](REVIEW-VS-IPYTHON-2026-11-24.md) §3.1 / §5.2
  （「没有对象级显示协议」是对标 IPython 差距里杠杆最高的一处）
- **相关**：[ADR-0016](ADR-0016-display-bundle.md)（Bundle 与格式协商）、
  [ADR-0037](ADR-0037-notebook-frontend.md)（notebook 协议与 `display` / `text` 分工）、
  [ADR-0019](ADR-0019-local-full-privilege-shell.md)（本地全权限：不做 HTML 净化）、
  [ADR-0047](ADR-0047-arrow-read-native.md)（前一版决策链）
- **现行条款**：V-184…V-186、V-300…V-302、V-323 / V-324（0.123.0 的 display 与 out 分工）

## 1. 问题

0.122.3 的显示层是**闭集**：`Display::Bundle` 有四种格式（text / markdown / html / json），
`bundle-from` 按**具体类型**分派（Table / `Positional[Hash]` / `IO::Path` 列表 / Hash /
标量 / 空），其余一律 `$v.Str`（`Display.rakumod:144-260`）。`Session.render` 另有
9 个 `!render-*` 分支。由此产生四个后果：

1. **第三方类型无法声明自己怎么显示。** 想加一种输出（图、公式、地图），必须改核心分支。
2. **没有 `display()`。** 一格只能有一个结果（exectute_result），不能在 cell 中间输出多个对象。
3. **没有图片 / 公式 / JS。** MIME 只有四种；`image/png`、`image/svg+xml`、`text/latex`、
   `application/javascript` 全部缺席，因此没有图表、没有公式、没有控件。
4. **终端与内核各自扩张。** TTY 的 `!render-*` 与 Bundle 的类型分支是两套判断，
   每次新增一种值都要同时改两处（`Session.rakumod:1819` 与 `Display.rakumod:146`）。

0.123.0 已经修掉这条路上最危险的两个 bug（display 不再丢值、不可 JSON 化不再杀引擎），
但**形状没有变**：仍是闭集。本 ADR 要换的是形状。

### IPython 的做法与可移植性

IPython 用**鸭子类型**：对象定义 `_repr_html_` / `_repr_png_` / `_repr_svg_` /
`_repr_latex_` / `_repr_json_` / `_repr_markdown_`…，`DisplayFormatter` 探测这些方法，
拼成 MIME bundle；`IPython.display.display()` 把一个 bundle 直接发给前端。

Raku 能表达同样的东西，但**一 MIME 一方法**在 Raku 里不自然：
`_repr_html_` 这种名字可以用，但每加一种 MIME 就多一个方法，且无法一次性协商
（"我支持这些，你挑"）。Raku 的惯用法是一个返回 Hash 的方法。

## 2. 决策

### 2.1 一个鸭子类型方法：`to-mime`

```raku
# 任何类型都可实现；不实现就退回内置识别。
method to-mime(--> Hash) { ... }   # { 'text/html' => Str, 'image/svg+xml' => Str, ... }
```

协议规则：

1. **优先级**：对象自带 `to-mime` > 内置识别（Table / 记录集 / 路径列表 / Hash / 标量）> `$v.Str` 降级。
2. **形状**：返回 `MIME => payload` 的 Hash；**`text/plain` 必须由 Bundle 兜底**，
   对象不提供也可以（Bundle 用 `.Str` 补），所以实现者只需关心"额外的那几档"。
3. **纯函数**：`to-mime` 不接受位置参数，**不得**写 `$*OUT`、不得依赖当前会话；
   需要会话的渲染（例如 `Table`）由对象自己持有数据，不再回读全局。
4. **失败即降级**：`to-mime` 抛异常 = 该对象没有富表示，Bundle 退回 `$v.Str` + 一条 warning，
   **不能**让异常穿到 `Eval::Server.emit`（V-324 的教训）。
5. **只读**：Bundle 只读取 Hash；不写回对象、不缓存到全局注册表。

`Bundle.to-mime` 已经存在（`Display.rakumod:109`），形状一致 —— 这是有意的：
`Bundle` 自己也可以是一个值，实现了 `to-mime` 的对象与它同构。

### 2.2 `display()` 与包装类型

`Rakuish::DSL` 导出：

```raku
display($value);                 # 立即产出一个展示（可在 cell 中间多次调用）
display($value, :id<progress>);  # 可选：同一 id 的后续调用在 notebook 里原地更新（P3）
```

以及六个薄包装类型，都实现 `to-mime`：

| 类型 | 产出 MIME | TTY 降级 |
|---|---|---|
| `HTML.new($str)` | `text/html` | 去标签后的纯文本（`<pre>` 也可以） |
| `Markdown.new($str)` | `text/markdown` + `text/plain` | 原文 |
| `SVG.new($str)` | `image/svg+xml` | `[image/svg+xml N 字节]` + `<title>`/`<desc>`（若有） |
| `PNG.new($bytes)` | `image/png`（base64） | `[image/png WxH? N 字节]` |
| `Latex.new($str)` | `text/latex` | 原文 |
| `JSON.new($value)` | `application/json` | 缩进后的文本 |

`display()` 的语义分前端：

- **TTY**：立即把降级文本写到 stdout；不占 `Out[n]`、不改 `_`（与 V-321 同一条原则）。
- **notebook**：发一条 `display_data`（不是 `execute_result`），可多次；
  cell 末尾的值仍是 `execute_result`。
- **`Kernel.present` / op 通道**：返回 bundle，由调用方挑格式。

### 2.3 MIME 阶梯与终端降级

每增加一档 MIME，**必须同时定义终端降级**，否则 TTY 会收到不可读输出：

| MIME | 优先级 | 终端降级 | 大小上限（默认） | 状态 |
|---|---|---|---|---|
| `text/plain` | 必有 | 原文 | 1 MiB | 已有 |
| `text/markdown` | P1 | 原文 | 1 MiB | 已有 |
| `text/html` | P1 | 去标签文本 | 1 MiB | 已有 |
| `application/json` | P1 | 缩进文本 | 1 MiB | 已有 |
| `image/svg+xml` | P2 | 摘要 + `<title>`/`<desc>` | 2 MiB | 草案 |
| `text/latex` | P2 | 原文 | 1 MiB | 草案 |
| `application/javascript` | P3 | `[javascript N 字节，仅 notebook 执行]` | 256 KiB | 草案 |
| `image/png` | P3 | `[image/png N 字节]`（不解码、不打印 base64） | 4 MiB | 草案 |

四条硬约束：

1. **TTY 永不打印二进制**（PNG / PDF / 任意 `application/*` 的二进制载荷）。
2. **JS 只发给 notebook**，终端只显示摘要；本地全权限（ADR-0019）意味着不净化，
   但也不在终端里"假装执行"。
3. **单档上限**：超限截断并标 `truncated => True`，与 `Bundle.meta` 的既有约定一致。
4. **不主动取远端资源**：HTML 里出现 `<img src="http://...">` 原样交给前端；
   Rakuish 不代理、不下载、不验证。

### 2.4 与 `out` / `text` 的分工（延续 V-323）

```text
Result.out    stdout 流（`say` / 子进程）        → 前端按 stream 处理
Result.value  这一格的值                         → display（bundle / execute_result）
display()     额外的、显式的展示                 → display_data（可多次）
Session.render TTY 的装饰（颜色 / Out[n] / 分页）→ 只用于 TTY 正文
```

`Bundle.meta.source` 保留 `value` / `out` / `error` / `empty`，再加 `display`（来自 `display()`）。
notebook 桥据此决定发 `execute_result`、`display_data` 还是只发 stream。

### 2.5 协商与能力

- `Bundle.pick(@accepts)` 已有；扩展为按 MIME 全名匹配（`image/svg+xml`），
  并保留 `html` / `json` / `md` 这些短名兼容。
- `Display.capabilities` 与 `Kernel.capabilities` 的 `formats` **必须只列真正能产出的档位**；
  对象自己产出的 MIME 不改变进程能力（那两个字段描述内核，不描述某个值）。
- notebook 的 `kernel_info` 增 `supported_mime`；前端可传 `accept`（P2）。

### 2.6 P1 的落地形态（0.124.0）

- **`display()` 返回哨兵** `Rakuish::Display::Shown`：`Session` 的 `!remember` /
  `render` / `bundle-from` 三处统一忽略。Raku 没有 `None`，返回 `Nil` 会把
  `_` 顶掉（与 V-321 同一条原则）。
- **收集而非流式**：`Session.add-display` / `take-displays`；`Eval::Server` 把
  `displays` 塞进结果帧的 `display` 哈希；`Proxy` 原样装进 `Result.bundle`；
  `Kernel::Notebook` 透传；Jupyter 桥在 `execute_result` **之前**逐条发
  `display_data`。代价是 stdout 与 display 的交错是近似的（P2 若要真流式，
  再走 chunk 帧那条路）。
- **额外 MIME**：`Bundle.%.extra-mime`，`available` / `has` / `pick` / `render` /
  `to-mime` 五处口径一致；`application/json` 仍是「真的能序列化才提供」。
- **终端降级**：`HTML` 去标签（先剥 script/style、再解实体、压空白）、
  `Markdown` 原文、`JSON` 展开；终端只显示 `text`，永不打印二进制。

## 3. 为什么不是一个全局 MIME 注册表

备选方案是 `Display.register-mime('image/svg+xml', &renderer)` 之类的进程级注册表。否决：

- 与「一切皆值、渲染跟着值走」的架构相反；Bundle 是纯数据，不该依赖进程全局状态。
- 两套会话（引擎子进程 / 进程内脚本）注册表不同步，跨进程时行为漂移。
- 注册表是可变全局，测试之间会互相污染。

鸭子类型让「谁能渲染」跟着**值**走，跨进程自然正确 —— 引擎只要把值渲染成 MIME 即可。

## 4. 为什么保留内置识别

`Table`、`List[IO::Path]`、`Hash`（env）这些是**核心值**，几乎每个用户都会碰到。
要求它们各自实现 `to-mime` 也可以，但：

- `Table` 已经有三套渲染（text / markdown / html），迁移是独立的体力活；
- 内置识别保证「不实现 `to-mime` 的旧值」行为不变（向后兼容）；
- 顺序明确：鸭子类型优先，内置兜底。用户想覆盖 `Table` 的渲染，用子类 + `to-mime` 即可。

## 5. 影响

**正向**

- 绘图库 / 图表库可以只实现 `to-mime`，返回 SVG 或 PNG；Rakuish 不需要内置绘图。
- 第三方类型（数据库游标、地理对象、图像）能自带富表示。
- `display()` 补上 IPython 的核心 API；notebook 支持多输出与（P3）原地更新。
- 终端与内核的分支收敛：`Session.render` 只处理 text，富输出统一走 Bundle。

**负向 / 成本**

- `Display.rakumod` 会从 ~250 行涨到 ~450 行；新增 6 个包装类型。
- 每个 MIME 都要定终端降级与大小上限，测试矩阵变大（至少 TTY / notebook 两路）。
- notebook 桥要新增 `display_data` / `update_display_data`；
  `tools/jupyter/rakuish_kernel/kernel.py` 的 `do_execute` 要能处理"一格多条展示"。
- `formats` 的探测成本：现在为了如实报告 json 可用性会真的序列化一次（0.123.0 已如此）；
  加 SVG/PNG 后要避免在 TTY 路径上做昂贵序列化 —— 建议 `to-hash(:mime)` 才探测。

**不做**

- 不做前端渲染引擎（SVG rasterize、HTML layout 都不是本仓库的事）。
- 不做 HTML 净化：本地全权限，净化会给"看起来安全"的错觉（ADR-0019）。
- 不做图片解码 / 缩放 / 格式转换。
- 不做 `_repr_*_` 式的一 MIME 一方法。

## 6. 实施分阶段

> 版本号与 V 编号是**提案**，落地时按当时版本改。

| 阶段 | 内容 | 验收 |
|---|---|---|
| **P1**（0.124.0） | `to-mime` 鸭子类型；`bundle-from` 优先探测；`display()` + `HTML`/`Markdown`/`JSON`；`text/plain` 兜底；额外 MIME 透传；notebook 一格多条 `display_data` | **已实施**：`t/80` 41 条；`display()` 不占 `Out[n]`、不改 `_`；notebook `displays` 与 `execute_result` 分离 |
| **P2** | `SVG` / `Latex`；大小上限；`image/svg+xml` / `text/latex` 的终端降级；`kernel_info.supported_mime` | notebook 里一张 SVG 能渲染、TTY 只显示摘要；超限截断有 `truncated` 标记 |
| **P3** | `PNG`（base64）；`display(:id)` → `update_display_data`；`application/javascript` | 同一 id 的进度条能原地更新；终端不打印二进制 |

建议 **P1 单独一个 ADR 落地版本**，不要与 P2/P3 合并评审 —— P1 已经能覆盖 80% 的用例，
且它是唯一会动 `bundle-from` 分派顺序的一步。

## 7. 验收（P1 已实现）

`t/80-display-protocol.t`（41 条）：

1. 自定义类实现 `to-mime` → `bundle-from` 优先用它；不再落 `.Str`。**已实现**
2. `to-mime` 抛异常 → 降级到 `.Str`，**不抛**（V-324 的延伸）。**已实现**
3. 额外 MIME（svg / latex …）**原样透传**：`available` / `has` / `pick` /
   `render` / `to-mime` 五处一致；P1 不定义它的终端渲染（P2 再定）。**已实现**
4. `display($v)` 在 TTY：写 stdout、不产生 `Out[n]` 条目、不改 `_`。**已实现**
5. `display($v)` 在 notebook：随结果帧收集成 `displays`，桥按序发
   `display_data`；cell 末尾的值仍是 `execute_result`。**已实现**
   （P1 是「执行后转发」，不是执行中流式；顺序对流/结果的交错是近似的。）
6. 各包装类型的终端降级：HTML 去标签、Markdown 原文、JSON 展开。**已实现**
7. SVG / PNG 专用包装的降级与大小上限 —— **P2**
8. `capabilities.formats` 与实际产出一致（负向断言：不谎称）。**已实现**
9. 旧路径回归：`t/38` / `t/65` 全绿；无 `to-mime` 的值 TTY 字节数不变。**已实现**

## 8. 开放问题

### 8.1 P1 已采用的默认（评审否决就改这里，再改实现）

| # | 问题 | P1 的选择 | 理由 |
|---|---|---|---|
| 1 | 方法名 | **`to-mime`** | 与 `Bundle.to-mime` 同形；一个 Hash 比一 MIME 一方法更 Raku |
| 2 | 懒载荷 | **不做**（eager Hash） | 先保证「渲染纯函数」；要懒载荷需先定义"渲染可有副作用"的语义 |
| 3 | TTY 多展示 | **逐次写 stdout**（天然分段） | 与 `say` 同一条通道，顺序自然正确 |
| 4 | PNG 形态 | **P3 再定** | 不进 P1 范围 |
| 5 | `display(:id)` | **接受但忽略** | 为 P3 的 `update_display_data` 留签名 |
| 6 | `formats` 判定成本 | **接受序列化一次** | 只影响 `present` / `to-hash`，TTY 路径不经过 |
| 7 | `Result.render('html')` | **不动**（html 只在 Bundle） | 统一它属于 P2，避免 P1 扩大面 |

### 8.2 仍需评审回答

1. **冲突风险**：`to-mime` 会不会撞上用户对象已有的同名方法？要不要提供
   `rakuish-mime` 作为别名（先查 `to-mime`，再查别名）？
2. **懒载荷**（P2 再议）：大图 / 大表是否允许返回闭包，由 Bundle 按需调用？
3. **`display_id` 语义**（P3）：只在 notebook 有效？TTY 上重复打印还是忽略？
4. **`formats` 的判定成本**：现在是"如实报告所以先序列化一次"；
   如果 Table 很大，`present(:format<text>)` 会多付一次 JSON 序列化。
   要不要把 `formats` 改成惰性字段？
5. **HTML 的边界**：`text/html` 已经存在，但 `Result.render('html')` 仍抛异常
   （`Renderer.rakumod:258`）；P2 要不要统一成"html 只在 Bundle 里有"？

## 9. 与现有文档的关系

- **ADR-0016** 说 `html` 明确没有；0.110.0 已加，ADR-0016 §2/§7 因此过时。
  本 ADR 落地时应在 ADR-0016 顶部标 `Superseded in part by ADR-0048`，而不是继续维护两套说法。
- **ADR-0037** §4 说"富 HTML / 图片是独立议题"，§7 又记录 0.110.0 的 html —— 同一份文档内部矛盾。
  本 ADR 就是那个"独立议题"的落点。
- **SPEC V-176 / V-177** 只约束 text 零 ANSI 与高亮；不阻止新增 MIME。
- **V-324**（0.123.0）是本文的前置：没有它，任何新 MIME 的序列化失败都会杀引擎。

## 10. 一句话

**把"显示"从 Session 里的九个分支，变成一个可由值自己声明的 MIME 包；
终端只承诺 text 降级，富输出交给前端。** 这是 Rakuish 从"能算的 REPL"走向
"能看的计算环境"最短的一步，也是绘图 / 富媒体 / Jupyter 控件的共同前置。
