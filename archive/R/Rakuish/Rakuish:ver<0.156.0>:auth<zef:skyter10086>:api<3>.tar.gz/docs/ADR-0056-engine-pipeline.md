# ADR-0056：引擎内管道 —— `! a | b`

- 状态：已实施（0.143.0 / V-347）
- 相关：V-243（不新增 Raku 管道语法）、ADR-0026（结构化管道 `Stream`）、
  ADR-0028（`:&in-chunks` 流式 stdin）、ADR-0021（引擎子进程）、
  ADR-0031 / ADR-0042（Windows Job Object）、V-901（不支持 bash 语法）
- 影响文件：`lib/Rakuish/Sys/Proc.rakumod`、`lib/Rakuish/Sys.rakumod`、
  `lib/Rakuish/Sys/WinJob.rakumod`、`lib/Rakuish/Eval.rakumod`、
  `lib/Rakuish/Eval/Server.rakumod`、`lib/Rakuish/REPL/Session.rakumod`、`t/83-pipe.t`

## 1. 背景

`!` 一直是「只接 argv 的单进程」：没有管道、没有重定向，`|` 在 argv 里
只是普通字符。用户能用 `Stream` / `.exec` 在 Raku 里拼出数据流，但
`! dir | findstr lib` 这种日常动作做不到，得退回系统 shell。

把 `|` 加在哪，是这件事真正难的部分：

- **Raku 表达式侧**（`|>` 或 `!{...}`）：`|>` 在 Raku 语法里不可定义
  （`sub infix:<|>` 直接编译错误）；`!{a} => !{b}` 会被解析成前缀否定加
  Pair，要改就得动 grammar —— 这是全局代价，换一个可选的便利，不值。
- **`!` 行**：这一行**不经过 Raku 解析**，切段是纯字符串处理，零语法风险。
  因此语法糖只落在 `!` 行。

## 2. 决定

`!` 行支持**顶层单个** `|`：

```
! dir | findstr lib
! echo hi | findstr h | findstr h
```

- 只切 **引号外** 的 `|`；`! echo "a|b"` 仍是一个参数。
- stage[i] 的 **stdout** 是 stage[i+1] 的 **stdin**；stderr 各段独立收集
  后拼接，不改道、不混进 stdout。
- 退出码取**末段**，不实现 `pipefail`；每段自己的码与启动失败记在
  `Result.value<stages>`，整条结果标 `value<pipeline> = True`。
- `||`、`>`、`&&`、`;`、`$()`、glob、变量展开仍然不支持（V-901）；
  `||` 会被当作「空段」明确报错，而不是静默当成两段。

**段间不 dup2，用 Channel 泵。** `Proc::Async` 全平台都没有 fd 级重定向
（`spawn` 的 stdin 只有 `:in` 或 `:&in-chunks` 两条路），所以：

```
stage[0].stdout ──Channel──► in-chunks 生成器 ──await write──► stage[1].stdin
```

复用 ADR-0028 的 `:&in-chunks` 拿到三件现成的东西：

1. 写一块 `await` 一块 = **背压**，不会把上游整条流拉进内存；
2. 下游提前关 stdin（`head` / `grep -q` 那类）时停喂，记 `in-early`；
3. 上游 EOF 自动 `close-stdin`，末段不会永远等输入结束。

**Windows 的 Job 必须整组收养。** 每段都上报 `child` 帧的话，父进程会
逐段 `!adopt-child`，而这个方法每次都先 `drop` 掉旧 job —— 在
`KILL_ON_JOB_CLOSE` 下 `drop` 就是**杀进程**，于是第二段一收养就把第一段
杀了。所以管道用 `announce => False` 抑制逐段上报，`spawn-pipeline`
一次性把整组 `pids` 放进同一个 `child` 帧；`Client` 侧改为
`!adopt-children(@pids)`，内部走 `assign-many`（任一段失败则整组不放行）。

## 3. 拒绝过的方案

- **父进程做管道**：父进程持真终端，确实能支持 `! cat | wc -l` 这类需要
  键盘的场景。但 `!` 的语义在引擎里（cwd / env / 审计 / 快照 / 历史都在那一侧），
  父进程另起一套管道等于把「`!` 是什么」复制成两份。本次只做引擎内，
  交互式管道的入口留给以后。
- **改 Raku grammar 支持 `!{a} => !{b}`**：语法代价全局化，且 `!` 本来就是
  前缀否定，读起来是二义。收益只是好看一点。
- **手写泵（自己 `$proc.write` + `close-stdin`）**：`spawn` 不给 `:w` 时
  `write` 直接失败，还得自己管 EOF 与早停；本质上是在 `in-chunks` 之外
  复刻一份更容易漏关 fd 的东西。
- **`pipefail`**：与 shell 默认语义不一致，用户不按 `set -o pipefail` 就
  不会预期；等有真实需求再以选项形式加。
- **每段独立超时**：整条管道是一个作业，共用一个预算才有意义
  （逐段计时会让「上游慢」变成「上游超时」而末段还在跑）。

## 4. 边界

- **只支持 `!` 行**。Raku 表达式里的管道仍是方法链（V-243）；
  `Stream`（ADR-0026）仍是处理记录流的地方。
- **不支持需要键盘输入的管道**：引擎的 stdin 是协议流，把键盘给前段就
  收不到帧了。（0.144.0 起改由父进程执行：`! --tty a | b`，见 ADR-0057。）
- **不做重定向**：`> out.txt` 请用 `! cmd > ...` 之外的方式（Raku 侧
  拿 `Result.out` 自己写文件）。
- **不做多行 / 续行管道**：`|` 只在一行内切。
- 与 `--tty` 互斥：`--tty` 是把宿主终端直通给**一个**子进程，和接管
  各段 stdin/stdout 冲突，直接报错。（0.144.0 起 `--tty` + 管道改由父进程
  执行，见 ADR-0057；单命令 `--tty` 仍是直通。）

## 5. 实测

Windows 11 + Rakudo 2026.09 本机：

| 场景 | 结果 |
|---|---|
| `cmd /c echo hello` → `findstr ell` | `hello`，code 0，stages 2 |
| 三段（中间段过滤偶数） | `2+4`，stages 3 |
| 上游 `exit 3`、末段成功 | `ok=True code=0`，stages 码 `3,0` |
| 末段 exe 不存在 | `code=127`、`start-failed=True`、err 带原因 |
| 2 万行进 → 末段只读一行 | 正常收尾，不挂死（早停生效） |
| 2 万行进 → `findstr /c:999` | 0.5 s 内完成，无死锁 |

实现时踩到一个 Raku 陷阱，记在这里免得重犯：`@parts.map(*.Str)` 是惰性
`Seq`，存进列表后再用 `my ($exe, @args) = …` 解构，`@args` 会收集成
**一个 Seq** 而不是它的元素，于是 `|@args` 只滑入一个列表参数，
`Proc::Async` 把整串当单个 argv —— 表现为 `cmd /c "echo hello"` 多出一个
引号。`spawn-pipeline` 里改成先 `@parts».Str` 落成 Array，再 `.List`。

## 6. 留给下一版

- 父进程侧 `pipe-exec`：已由 ADR-0057（0.144.0 / V-348）实现，
  入口是 `! --tty a | b`。
- 若真实需求出现，再考虑 `pipefail` 选项、`2>&1` 这类改道。
- 不做 `! a && b`、`! a > f`：那是 shell，不是本项目的方向（ADR-0001）。
