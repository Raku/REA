# Rakuish Cookbook

适用版本：**0.153.0**（API v3）

这本 cookbook 不讲「语言教程」，只讲**具体想干一件事时怎么写**。每个配方都按
「场景 → 直接可抄的代码 → 关键点 / 坑 / 边界」组织，示例默认在交互式 REPL 里执行，
脚本模式只多一句说明。

真值仍以 [`SPEC.md`](../SPEC.md) 与 [`MANUAL.md`](MANUAL.md) 为准；本书只是把它们
翻译成日常用法。

---

## 0. 先分清四种输入

Rakuish 里只有四类东西，混用是最常见的错误来源：

| 你写的东西 | 例子 | 由谁处理 |
|---|---|---|
| Raku 表达式 | `1 + 1`、`ls(:recursive)`、`save-data("a.csv", $t)` | 引擎直接求值 |
| `!` 外部命令 | `! git status --short` | 只做 argv 分词，起进程 |
| Shell 薄层命令 | `cd`、`ls -lh`、`cp -r`、`grep -n` | 翻译成 `Sys` 调用 |
| `!` 管道（0.143+） | `! git log --oneline \| head -n 5` | 顶层、引号外的 `\|` 才切段 |

三条硬规则，记住能省掉 80% 的困惑：

1. **非 `!` 行是 Raku 表达式，路径必须加引号。**
   `save-data(tmp/a.csv, $t)` 会把 `tmp/a.csv` 当除法表达式，报
   `Undeclared routine: tmp`；写成 `save-data("tmp/a.csv", $t)`。
2. **`!` 只接 argv，不是 shell。** 重定向、`$VAR`、`&&`、glob、命令替换都不解释；
   `|` 是唯一例外（0.143 起，且必须在顶层、引号外）。
3. **Shell 薄层不是第三套语言。** 它没有变量、没有管道、没有 `for`；需要这些就用
   Raku 写。

> 本书输出里的 `Out[n] = ...` 是 REPL 的编号结果，脚本模式不会打印这些标签。

---

## 目录

- [0. 先分清四种输入](#0-先分清四种输入)
- [1. 安装与三个入口](#1-安装与三个入口)
- [2. 第一次打开 REPL](#2-第一次打开-repl)
- [3. 文件与目录](#3-文件与目录)
- [4. 外部命令与管道](#4-外部命令与管道)
- [5. 文本处理](#5-文本处理)
- [6. 结构化数据与 CSV/JSON](#6-结构化数据与-csvjson)
- [7. SQL：DuckDB 与 SQLite](#7-sqlduckdb-与-sqlite)
- [8. 脚本与自动化](#8-脚本与自动化)
- [9. 会话管理：历史、快照、配置](#9-会话管理历史快照配置)
- [10. Notebook 与 Jupyter](#10-notebook-与-jupyter)
- [11. 插件](#11-插件)
- [12. 常见坑与排错表](#12-常见坑与排错表)
- [13. 速查表](#13-速查表)

---

## 1. 安装与三个入口

### 1.1 安装并确认版本

```bash
zef install .
rakuish --version
```

**关键点**

- 需要 Rakudo / MoarVM + `zef`；核心依赖 `JSON::Fast`、`Terminal::LineEditor`、
  `Terminal::API`。
- 没有 TTY 的构建机 / 容器里，`Terminal::API` 的上游测试会中断安装，按
  [`CI.md`](CI.md) §2.1 的 `--force-test --force-install` 顺序先装依赖。
- 不想安装时，源码树里直接 `raku -Ilib bin/rakuish`。

### 1.2 三种入口怎么选

| 你想做的事 | 用这个 | 说明 |
|---|---|---|
| 边试边改、保留变量 | `rakuish` | 交互 REPL，会话状态持续 |
| 跑一行就退出 | `rakuish -e '...'` | 当前进程求值，无 `Out[n]` |
| 跑一个可复用脚本 | `rakuish task.raku --flag x` | 整份文件当一个 cell，参数走 `@*ARGS` / `MAIN` |
| 给 Jupyter / notebook 桥接 | `rakuish-notebook` | 一行一 JSON，不接 ZMQ |

```bash
rakuish
rakuish -e 'say (1..10).sum'
rakuish tools/report.raku --top 20
echo '1 + 1' | rakuish
```

**关键点**

- 只有**交互式** REPL 把求值放在引擎子进程里；`-e`、脚本、管道都在当前进程求值，
  崩了就崩了，也没有快照恢复。
- 管道输入（stdin 不是 TTY）不打印 banner / prompt / ANSI，逐行求值。
- 启动参数必须在 shell 里传给 `rakuish`；REPL 里敲 `--help` 是 Raku 的 `--`
  运算符，不是启动参数。

### 1.3 脚本模式预加载了什么

```bash
rakuish task.raku
```

脚本里可直接用 `sys`、`repl`、`registry` 和 [`Rakuish::DSL`](../lib/Rakuish/DSL.rakumod)
导出的 `ls` / `read` / `write` / `stream` / `open-data` / `save-data` 等函数，
不用手写 `use`。相对路径跟随**调用者 cwd**，不是脚本所在目录。

**边界**

- 不支持 `=finish` / `$=finish`（源码在 `do { }` 里编译，没有数据段可挂）；
  需要数据段就用普通文件 IO。
- `use Foo::Bar` 之后，后续格可以直接写 `Foo::Bar.new`；`use` 不写分号也行。

---

## 2. 第一次打开 REPL

### 2.1 认提示符

```text
rakuish 0.153.0
────────────────────────────────────────
14:32:07  ~/work/demo  main  3  0.42s
rakuish>
```

从左到右：时间、当前目录、git 分支、格号（第几次执行）、上一格耗时。
续行提示符是 `···`。非 TTY 下这些全都没有。

```raku
1 + 1
Out[1] = 2
```

### 2.2 `_`、`Out[n]`、`In[n]` 怎么用

```raku
40 + 2
Out[1] = 42

_ + 8
Out[2] = 50

Out[1]
Out[3] = 42

In[2]
Out[4] = "_ + 8"
```

| 符号 | 含义 |
|---|---|
| `_` | 上一个**成功**格的值 |
| `Out[n]` | 第 n 个成功结果；失败格不占号 |
| `In[n]` | 第 n 条输入（含失败格与会话命令） |

**关键点**

- 纯声明格（整格只有一个 `sub` / `class` / `role` / `grammar` / `use`）不占
  `Out` 编号，也不改变 `_`。
- `display(...)` 产生的额外输出不是结果，同样不影响 `_` 和 `Out`。

### 2.3 多行输入

括号或引号没闭合时自动续行，空行提交：

```raku
my %user =
    name => 'Ada',
    age  => 36;

%user<name>
Out[1] = Ada
```

粘贴一整段代码也行：

```text
rakuish> paste
… 粘贴代码
--
```

**关键点**：`paste` 读到一行恰好是 `--`（或 Ctrl-D / EOF）才结束，把整段当一个格
执行；带空行、缩进块的 `class` / `multi sub` / `for` 都适合这样粘。
Notebook / 引擎模式下不可用。

**坑**：粘贴的代码里如果有 `my $x`，必须一次粘完；分两次粘时第二次看不到第一次的
`my`（跨格要依赖只读扫描器能识别的顶层 `my`，复杂结构建议粘成整格）。

### 2.4 声明跨格持久

整格只写一个声明时，后续格可以直接用：

```raku
class Box { has $.n; method twice { $!n * 2 } }
Out[1] = (Box)

Box.new(n => 21).twice
Out[2] = 42
```

```raku
role Tag { method tag { 'T' } }
class Tagged is Box does Tag { }
Tagged.new(n => 5).twice
Out[1] = 10
```

**边界**

- 持久的是**名字可见性**，不是 type object 身份；每格重放会生成新类型，
  `.^name` 可能带外层包名。
- 混有其它执行语句的格、含 `BEGIN` / `INIT` 的格不会被缓存。
- 嵌套块里的 `my` 仍是块内局部，不会跨格。

### 2.5 中断、退出、清屏

| 操作 | 效果 |
|---|---|
| Ctrl-C | 丢弃当前半行 / 清空续行缓冲，不退出会话 |
| Ctrl-C（求值中） | 中断当前格（0.85+） |
| Ctrl-D | 退出 |
| `exit` | 退出；格内其它输出仍然保留 |
| `clear` | 清屏（TTY） |

**坑**：在表达式里调用 `exit`（比如 `my $x = (exit)`）会让求值引擎退出并被重启，
当前会话变量可能丢失。要退出就单独一行写 `exit`。

### 2.6 终端里能按的键

| 键 | 作用 |
|---|---|
| Up / Down | 历史上下条 |
| Ctrl-R | 循环搜索历史（首按用当前输入作查询串） |
| Ctrl-A / Ctrl-E | 行首 / 行尾 |
| Ctrl-F / → | 接受灰字建议 |
| ShiftTab | 列出补全候选 |
| Tab | 补命令、路径、`help <cmd>`；`!` 模式下也补程序和路径 |

`!` 模式下首词也能补：`! gi<Tab>`、`! --tty ra<Tab>`。

### 2.7 富输出：`display()`

普通结果走 `Out[n]`；想额外输出一块富内容用 `display()`，一格可以调用多次：

```raku
display(HTML.new('<b>构建成功</b>'));
display(Markdown.new("# 报告\n- 通过 12 项"));
display(JSON.new({ ok => True, rows => 42 }));
42
Out[1] = 42
```

**关键点**

- `display` 不产生 `Out[n]`、不改变 `_`。
- 终端立即显示降级文本；notebook 里走 `display_data`。
- 自定义类型只要实现 `to-mime(--> Hash)` 就能自带富表示；抛异常会降级到 `.Str`，
  不会崩。

### 2.8 查文档，不离开 REPL

```raku
help ls            # 命令用法
help --find csv    # 在所有命令用法里搜子串
which python       # 先查内置，再查 PATH
ls?                # 等价于 help ls
Box?               # 看类型 / WHY / 签名 / 方法（零 EVAL）
$x?                # 看变量类型与值摘要
doc open-data      # 看 Raku routine 的文档
```

**坑**：`名字?` 看不到跨格 `my` / `our`，因为它是零 EVAL 的元信息查询。

---

## 3. 文件与目录

### 3.1 看目录：从「够用」到「可编程」

```bash
ls                    # 当前目录，彩色、目录带 /
ls -lah               # 全部（含隐藏）+ 长格式 + 人类可读大小
ls -R src             # 递归；TTY 下按目录流式打印
ls --json .           # 返回 Table，而不是文本
```

```raku
ls                                  # List[IO::Path]
ls('src', :recursive)               # 递归列表
ls('.').grep(*.f)                   # 只要文件
ls('.').grep(*.extension eq 'md')   # 按扩展名
ls-table('.')                       # Table：name/type/size/modified/path
```

```raku
ls-table('.').where({ .<type> eq 'file' })
             .sort-by('size', :reverse)
             .select('name', 'size')
             .limit(10)
             .to-text
```

**关键点**

- `ls` 返回 `List[IO::Path]`，`.f` / `.d` / `.s` / `.modified` 都是原生属性。
- `ls --json` / `ls-table` 返回扁平 Table，递归也一样；列至少
  `name/type/size/modified/path`。
- 普通 glob 只扫当前目录；`**` 才无界递归。
- 递归条目超过 `Sys.max-entries`（默认 100000）会抛 `X::Rakuish::Limit`，
  不会悄悄截断。

### 3.2 换目录与返回

```bash
cd src
cd ..            # 支持 ..
pwd
pushd /tmp       # 压栈后切换
dirs             # 看栈
popd             # 回上一个目录
bookmark add proj ~/work/proj
bookmark list
bookmark go proj
```

```raku
sys.cwd                       # IO::Path
sys.chdir('docs')             # 会话级 cwd
sys.cwd.Str
```

**关键点**

- `cwd` 是**会话对象属性**，不是进程全局；后台作业、脚本、REPL 各看各的。
- `bookmark` 只在会话内有效，不落盘；要持久化就写进 `~/.rakuish/rc.raku`。
- Windows 上 `cd D:` 这类盘符切换由薄层处理；跨盘路径建议直接写绝对路径。

### 3.3 找最近改过的文件

```raku
recent(7, 'md', :path('docs'))          # 最近 7 天的 .md
recent(1, 'log', :path('logs')).sort(-*.modified).head(5)
```

```raku
recent(30, 'raku', :path('.'))
    .map({ "{.modified.DateTime}  {.relative}" })
    .join("\n")
    .say
```

**关键点**

- 签名：`recent(Int $days = 7, Str $ext = 'md', :$path = '.')`，返回 `List[IO::Path]`。
- 只按扩展名过滤，不递归隐藏目录之外的特殊规则；大目录先缩 `:path`。

### 3.4 读文件：小文件、大文件、按行

```raku
read('README.md')                       # 整份读，默认上限 1 MiB
read('README.md', :max-bytes(5_000_000))
read('data.bin', :bin)                  # Buf
read('gbk.txt', :enc('gbk'))
```

```raku
read-lines('access.log', :head(20))     # 前 20 行
read-lines('access.log', :tail(20))     # 后 20 行
```

```bash
cat README.md
head -n 20 access.log
tail -n 20 access.log
tail -f app.log          # 跟随新增，Ctrl-C 停止
read notes.txt
```

**关键点**

- 整份 `read` 超过上限会抛 `X::Rakuish::Limit`，并给出三条出路（`read-lines` /
  `head` / `stream`）。不会静默截断。
- `read-lines(:head)` / `(:tail)` 是流式的，不整份载入；`tail -f` 会轮询跟随，
  截断 / 轮转后从新内容继续。
- 文本读取会统一换行（CRLF → LF）；需要保留原始字节就用 `:bin`。
- `cat` / `read` 走薄层，路径含 `-` 也不会被当选项。

### 3.5 写文件：原子、追加、建目录

```raku
write('out/report.txt', "hello\n", :mkdir);
write('out/report.txt', "more\n", :append);
write('out/report.txt', $text, :atomic);       # 默认就是原子
write('out/report.txt', $text, :backup);       # 覆盖前留 .bak
write('out/report.txt', $text, :max-bytes(20_000_000));
```

**关键点**

- 原子写 = 同目录临时文件 + rename；Windows 上目标存在时可能降级为
  「先删再 rename」，返回的 `WriteResult.atomic` 会如实标 `False`。
- `:mkdir` 只建父目录，不负责清理中途失败的文件。
- 写入默认也有 1 MiB 上限；大内容显式 `:max-bytes`，或分批 `:append`。
- `write` 返回 `WriteResult`，`.ok` / `.bytes` / `.atomic` 可检查。

### 3.6 复制、移动、删除：先看清楚再动手

```bash
cp a.txt b.txt
cp -r src backup/src
mv old.txt new.txt
rm -n tmp/*.log        # dry-run，只列出将删什么
rm -r tmp/build
```

```raku
cp('a.txt', 'b.txt');
cp('src', 'backup/src', :recursive);
mv('old.txt', 'new.txt');                 # 目标存在会报错
mv('old.txt', 'new.txt', :overwrite);     # Raku API 显式覆盖
rm('tmp/build', :recursive);
rm('tmp/x.log', :force => True);
```

**坑**

- `Sys.cp` / `Sys.mv` 默认**不覆盖**：目标存在抛 `X::Rakuish::Exists`。
  薄层 `mv` 也没有 `-f`；要覆盖就用 Raku API 的 `:overwrite`，或先 `rm` 目标。
- `rm -n` 是唯一安全的批量删除预演；生产脚本先 `-n` 再真删。
- `cp -r` 会在复制前预检源树条目数，超 `max-entries` 直接拒绝。

### 3.7 文件元信息

```raku
stat('README.md')
Out[1] = %(path => ..., type => 'file', size => 12345, mode => ..., modified => ...)
```

```raku
my $st = stat('build');
"{$st<type>}  {$st<size>}  {$st<modified>}"
```

**关键点**

- `stat` 返回 Hash，不是 Table；字段 `path/type/size/mode/modified`。
- 判断类型优先用 `IO::Path` 的 `.f` / `.d` / `.l`，比字符串比较可靠。

### 3.8 glob：比 `ls` 更适合批量

```raku
glob('*.md')                       # 当前目录
glob('docs/**/*.md')               # 递归
glob('src/**/test_*.raku')         # 中间任意层
glob('img/*.{png,jpg}')            # 花括号
glob('[abc]*.txt')                 # 字符集
glob('*.log', 'logs')              # 指定根目录
glob('report-2026-??.csv')         # 单字符
```

**关键点**

- 支持 `*` / `?`（不跨 `/`）、`**/`、`[abc]`、`[a-z]`、`[!x]`、`{a,b}`、嵌套
  `{a,{b,c}}`。
- 反斜杠 + 元字符按字面匹配；裸 `\` 归一化为 `/`。
- glob 是**大小写敏感**的；Windows 上想忽略大小写就先生成列表再
  `.grep({ .lc ~~ ... })`。
- 只扫指定根目录；`**` 才无界递归。

### 3.9 多进程同时写一个文件

```raku
with-lock('data.json', {
    my $t = open-data('data.json') // [];
    save-data('data.json', $t);
});
```

**关键点**

- 锁文件是 `data.json.lock`；**故意不删除**，删了会让两个进程各锁一个 inode。
- `:shared` 共享锁、`:non-blocking` 立即返回失败。
- 这是协作式锁：不遵守这个约定的程序不会自动被挡住。

### 3.10 文件名批量整理

```raku
for glob('photos/*.jpeg') -> $f {
    my $new = $f.parent.add($f.basename.subst('.jpeg', '.jpg'));
    mv($f.Str, $new.Str);
    say "{$f.basename} -> {$new.basename}";
}
```

**坑**

- `mv` 遇到同名目标会报错；先检查 `$new.e`，或用 `:overwrite`。
- `$f.parent.add(...)` 比字符串拼路径安全，能正确处理空格与分隔符。
- 在 REPL 里 `for` 循环是一整格；Ctrl-C 能中断，但已经改过的文件不会回滚。

---

## 4. 外部命令与管道

### 4.1 `!` 到底怎么分词

```raku
! git status --short
! raku -e "say 1 + 1"
! python -c "import sys; print(sys.version)"
```

`!` 只按空格与引号切 argv，然后直接起进程：

- 引号只是用来保住空格，**不会**做变量展开、命令替换、转义序列。
- `>`、`>>`、`2>`、`$VAR`、`&&`、`*`、`?`、`$(...)` 全部原样作为参数。
- 未闭合的引号直接返回 `127`，不会把残片当命令执行。
- 要重定向 / 过滤 / 循环，用 Raku 写（见 4.3、4.7）。

```raku
# 错：这不是 shell，> 会原样传给程序
! echo hi > out.txt

# 对：在 Raku 里写
my $r = exec('echo', 'hi');
write('out.txt', $r.out);
```

**Windows**

- `dir` / `type` / `copy` / `del` / `where` / `echo` 这类 cmd 内建命令由白名单
  包一层 `cmd /c`；其它命令必须是 PATH 上的可执行文件。
- `! cat` 在 Windows 上通常不存在，用薄层 `cat` 或 Raku 的 `read`。
- PATH 扫描会在第一次 Tab 补全时后台预热，之后即时。

### 4.2 拿到结果，而不是只看屏幕

```raku
my $r = exec('git', 'status', '--short');
$r.ok
$r.code
$r.out
$r.err
$r.elapsed
$r.value
```

`exec` 永远返回 `Result`，**不抛异常**；启动失败也收敛成 `code=127`：

```raku
my $r = exec('no-such-program');
$r.ok          # False
$r.code        # 127
$r.err         # 启动失败原因
```

按行处理输出：

```raku
my $r = exec('git', 'status', '--porcelain');
my @changed = $r.out.lines.grep(*.chars);
say "共 {+@changed} 个改动";
@changed.head(5).join("\n").say;
```

**关键点**

- `exec` 的 stdout / stderr 默认各最多 1 MiB；超出会截断并标记。
- 默认超时 30 秒，超时 `code=124`、`Result.timed-out` 为 True。
- `Result.value` 是结构化附加信息（例如 `exe` / `argv` / `truncated`）。
- 想测命令实际跑了多久就看 `$r.elapsed`（墙钟）；多次基准用 `timed` /
  `bench` / `perf`，见 §8.8。
- 不在 `!` 行里的 `$` 是 Raku 变量；`!` 行里的 `$VAR` 不会展开。

### 4.3 管道：`! a | b | c`

```raku
! git log --oneline | head -n 5
! raku -e "say 42" | grep 42
```

**语义**

- 只有**顶层、引号外**的单个 `|` 才切段；`||`、引号里的 `|`、重定向都不算。
- 每一段仍只做 argv 分词，不经过 shell。
- 默认捕获**末段**的 stdout / stderr，整条管道的超时仍是 30 秒。
- 退出码默认取末段；`--pipefail` 取最右非零段。

```raku
my $r = cmd-result('! ls | grep .raku');
$r.out.lines.elems;
```

**不支持**：`&&`、`||`、`;`、`2>`、`tee`、进程替换。需要这些就用 Raku 串起来。

### 4.4 大输出直写终端：`! --pipe` / `! -P`

```raku
! --pipe make
! -P git log --oneline | head -n 50
! --pipe raku -e "for 1..100000 { say $_ }" | tail -n 3
```

**语义**

- 末段 stdout **直写终端**，不攒进 `Result`，所以 1 MiB 上限不再限制你。
- stderr 照常转发到终端；不需要额外写 `2>&1`（而且 `!` 也不解释它）。
- 没有总超时；长任务不会被 30 秒掐掉。
- 也不捕获：不能用 `$r.out` 再处理输出。
- `--pipe` 与 `--capture` 互斥。

**什么时候用**：构建日志、长时间运行的测试、训练进度条——你只想看，不想存。

### 4.5 管道里要问「谁失败了」：`--pipefail`

```raku
! --pipefail sh -c "exit 3" | cat
# 退出码 3，而不是 cat 的 0

! --pipefail a | b | c
# 取最右一个非零段的退出码
```

**关键点**

- 默认语义和 shell 一样：只看末段。
- 超时仍然优先：任一段超时 → `124`。
- 启动失败 → `127`；被取消 → `137`。

### 4.6 首段从文件吃 stdin：`--stdin`

```raku
! --stdin input.csv wc -l
! --stdin records.jsonl python tools/parse.py
! --stdin data.txt grep -c ERROR
```

**关键点**

- 路径由会话 `Sys.resolve` 解析，受会话 cwd / root 约束，必须是普通文件。
- 只接首段；后面的段由管道自然连接。
- 和 `! --pipe` 可以一起用：`! --pipe --stdin big.log grep ERROR | tail`。

### 4.7 需要真正终端：`! --tty`

有些程序必须有 TTY：分页器、编辑器、嵌套 REPL、彩色构建工具、读密码的程序。

```raku
! --tty raku
! --tty python
! --tty vim notes.md
! --tty less README.md
```

**语义**

- 由**持有终端的父进程**执行，stdin / stdout / stderr 直接交接。
- 不捕获输出、不设超时；退出后终端状态会恢复。
- 只能在交互式 REPL 用；`-e` / 脚本 / notebook 里没有终端，会明确拒绝。
- 管道场景要读 stdin 也必须加 `--tty`：

```raku
# POSIX：让 cat 读你的键盘，而不是引擎的协议 stdin
! --tty cat | wc -l

# Windows
! --tty more | findstr Rakuish
```

`! --tty a | b`（0.144+）整条管道都在父进程执行，仍捕获末段；再加 `--pipe`
则不捕获。

### 4.8 超时、取消、长任务

```raku
! --timeout-ms 120000 make
! --no-timeout make
! --timeout-ms 0 make          # 0 = 不超时
```

```raku
my $r = exec('slow-tool', :timeout-ms(5000));
if $r.timed-out { say '超时了' }
```

**关键点**

- 默认 30 秒；`!` 层与 `exec` 共用这套语义。
- 超时 `code=124`；取消 `code=137`。
- `! --tty` / `! --pipe` 不设总超时，Ctrl-C 交给子进程处理。

### 4.9 边跑边看：流式回调

```raku
sys.exec('ping', '-n', '3', '127.0.0.1',
         :on-out(-> $chunk { print $chunk }),
         :on-err(-> $chunk { note $chunk }));
```

**关键点**

- `:on-out` / `:on-err` 在进程还在跑时逐块回调；不传就是收完再返回。
- 回调里不要做重活，否则会拖慢读管道。
- 这不是 `! --pipe` 的替代：回调仍然走捕获路径，仍有上限。

### 4.10 把数据喂给外部命令

```raku
# 整份写入 stdin
my $r = exec('python', 'tools/parse.py', :in($csv-text));

# 从文件流式喂
my $r = exec('wc', '-l', :stdin-file('big.log'));

# 边算边喂（惰性）
my $r = exec('sort', :in-chunks(-> {
    gather {
        for 1..100_000 -> $i { take "line $i\n" }
    }
}));
```

**关键点**

- `:in` / `:in-chunks` / `:stdin-file` 三者只能选一个。
- `:in-chunks` 是惰性生成器；子进程提前关闭 stdin（`head -1`、`grep -q`）会
  正常停止喂，不报错。
- 生成器自己抛异常会写进 `Result.value<feed-error>`，不会静默吞掉。

### 4.11 改环境变量、改工作目录

```raku
my $r = exec('raku', '-e', 'say %*ENV<APP_ENV>',
             :env(%('APP_ENV' => 'prod')));
```

**坑**

- 显式 `:env` 是**整份替换**，不是合并；只传一个变量会导致子进程看不到 PATH。
  需要保留环境就显式合并：`:env(%*ENV, APP_ENV => 'prod')`。
- `:cwd` 也过会话 root 校验；不能借子进程绕过目录边界。
- 会话 `sys.cwd` / `sys.env` 默认自动带上，不需要每次传。

### 4.12 后台跑，稍后收

```raku
my $h = sys.spawn('raku', '-e', 'sleep 3; say "done"');
say "已启动";

# 干别的……

my $r = sys.wait($h);          # 收 Result
say $r.out;
```

```raku
sys.jobs                       # Table：id/status/exe/argv/started
my $h2 = sys.job(3);           # 按 id 取回
sys.cancel($h2);               # 取消
```

**关键点**

- `spawn` 的后台任务归**当前 `Sys` 会话**，不写全局进程表，不跨会话。
- `wait` / `cancel` 成功后会把记录从 `jobs` 清掉。
- 这是「捕获式后台」；需要真终端作业控制用 `bg-exec`。

### 4.13 真终端后台作业：`bg-exec` / `fg` / `bg` / `bg-jobs`

```raku
my $r = bg-exec('bash', '-c', 'sleep 30');
$r.value<job>;                  # 作业 id
bg-jobs;                        # Table：id/state/exe/cmd/pid/pgid/exit/since
fg($r.value<job>);              # 带回前台
bg($r.value<job>);              # 再放回后台
```

**关键点**

- **POSIX only**；Windows 上返回 `code=127` 和明确原因，不会假装支持。
- 作业表在 `Sys` 上，引擎崩溃重启也不丢。
- `bg-exec` 立即返回；`fg` 会等到前台作业结束。

### 4.14 需要伪终端：`pty-exec`

```raku
my $r = pty-exec('python', '-c', 'import sys; print(sys.stdout.isatty())');
say $r.out;    # True
```

**关键点**

- 仅 POSIX，需 Rakudo ≥ 2025.12 与 `Terminal::API`。
- 输出是捕获的，但子进程看到的是伪终端（`isatty` 为真）。
- 目前不接 stdin 输入；要交互请用 `! --tty`。

### 4.15 把 shell 脚本翻译成 Rakuish

| shell | Rakuish |
|---|---|
| `for f in *.txt; do ...; done` | `for glob('*.txt') -> $f { ... }` |
| `if cmd; then ...; fi` | `if exec('cmd').ok { ... }` |
| `cmd > out` | `write('out', exec('cmd').out)` |
| `cmd1 \| cmd2` | `! cmd1 \| cmd2`（或 `cmd-result`） |
| `out=$(cmd)` | `my $out = exec('cmd').out` |
| `xargs grep foo` | `glob('*').map({ exec('grep', 'foo', $_.Str) })` |
| `find . -name '*.log'` | `glob('**/*.log')` |
| `VAR=x cmd` | `exec('cmd', :env(%*ENV, VAR => 'x'))` |
| `sleep 10 && rm x` | `sleep 10; rm('x')`（失败检查用 `.ok`） |
| `cmd &` | `sys.spawn('cmd')` |
| `$?` | `Result.code` |

---

## 5. 文本处理

### 5.1 快速过滤：薄层 `grep`

```bash
grep ERROR app.log
grep -n ERROR app.log
grep -i error app.log
grep -v DEBUG app.log
grep -F 'a.b' app.log        # 字面量，不当正则
grep -E 'ERROR|WARN' app.log
grep -n ERROR *.log
```

**关键点**

- 默认按正则（`-E`），`-F` 按字面量。
- `-n` 带行号，`-v` 反向，`-i` 忽略大小写。
- 这是薄层，不支持递归 `-r`；递归用 `glob('**/*.log')` 再逐个 `grep` 或
  Raku 里处理。

### 5.2 行数、词数、字符数

```bash
wc -l app.log
wc -w notes.txt
wc -c data.json
wc -l *.log
```

```raku
read('app.log').lines.elems
read('notes.txt').words.elems
read('data.json').chars
```

### 5.3 用 Raku 方法链处理文本

```raku
my @lines = read('app.log').lines;

@lines.grep({ .contains('ERROR') }).elems
@lines.grep({ .contains('ERROR') }).head(5).join("\n").say
@lines.map(*.trim).grep(*.chars).unique.sort.join("\n").say
```

**关键点**

- `.lines` 不带换行符；空文件得到空列表。
- `.words` 按空白切；`.comb(/\w+/)` 按模式切。
- `.unique` 保序去重；`.sort` 默认字符串排序，数字要 `sort(*.Int)` 或
  `sort({ +$_ })`。

### 5.4 提取字段：正则捕获

从日志里抽 IP、状态码、路径：

```raku
my $line = '10.1.2.3 - - [27/Nov/2026:14:03:11 +0800] "GET /api/users HTTP/1.1" 200 512';

if $line ~~ /^(\S+) \s+ \S+ \s+ \S+ \s+ \[([^\]]+)\] \s+ "(\w+) \s+ (\S+)/ {
    say "ip={~$0} time={~$1} method={~$2} path={~$3}";
}
```

批量统计 Top 10 路径：

```raku
my %count;
for read('access.log').lines -> $l {
    %count{~$0}++ if $l ~~ /"GET "\s+(\S+)/;
}
%count.sort({ -.value }).head(10)
      .map({ "{$_.value}\t{$_.key}" })
      .join("\n").say
```

**关键点**

- `$0` / `$1` 是捕获组；`~$0` 转字符串。
- 正则里 `\s+` 匹配一段空白，日志常用多个空格对齐，别写死单空格。
- 匹配失败时 `$0` 是 Nil；先 `if ... ~~ ...` 再取值。

### 5.5 按分隔符拆行、拆列

```raku
read('passwd.txt').lines.map(*.split(':')[0]).join("\n").say
read('data.tsv').lines.head(3).map({ .split("\t").elems }).say
```

**坑**

- 手工 `split(',')` 只适合「确定没有引号、逗号和跨行字段」的简单文件。
- 真正的 CSV 请直接用 `open-data` / `stream(:format<csv>)`，它们处理 BOM、
  CRLF、双写引号、字段内逗号与换行、行尾空字段。

### 5.6 批量替换文本

```raku
my $f = 'config.ini';
my $old = read($f);
write($f, $old.subst('localhost', '127.0.0.1', :g));
```

```raku
# 只替换整词，避免 localhost 命中 localhost2
write($f, $old.subst(/\b 'localhost' \b/, '127.0.0.1', :g));
```

**关键点**

- `:g` 全局；不写只替换第一处。
- `write` 默认原子，但**不自动备份**；要回滚就加 `:backup`。
- 大文件不要整份 `read`，用 `read-lines` + `write(:append)` 流式改写。

### 5.7 大小写、trim、空白规整

```raku
read('names.txt').lines
    .map({ .trim.uc })
    .grep(*.chars)
    .unique
    .join("\n").say
```

```raku
my $s = "  a   b  \n";
$s.trim;                  # 'a   b'
$s.trim.subst(/\s+/, ' ', :g);   # 'a b'
```

**关键点**

- `.trim` 去掉首尾空白；中间空白用 `subst(/\s+/, ' ', :g)`。
- `.uc` / `.lc` / `.tc` / `.fc` 分别是全大写 / 全小写 / 词首 / 折叠大小写。

### 5.8 对齐打印表格

```raku
my @rows = (
    ('name',  'size'),
    ('a.txt', 12),
    ('longer.txt', 34567),
);

@rows.map({ sprintf "%-14s %8d", .[0], .[1] }).join("\n").say
```

输出：

```text
name                  size
a.txt                   12
longer.txt           34567
```

**关键点**

- `%-14s` 左对齐、`%8d` 右对齐；中文字符宽度不算双宽，终端可能仍错位。
- 真正需要列宽自适应就用 `Table.to-text`，它会按内容计算。

### 5.9 排序与去重

```raku
my @nums = read('nums.txt').lines.map(*.Int);
@nums.sort;
@nums.sort({ -$_ }).head(5);
@nums.unique.sort;
```

```raku
my @words = read('words.txt').lines.map(*.trim).grep(*.chars);
my %freq = @words.Bag;
%freq.sort({ -.value }).head(10).map({ "{$_.value}\t{$_.key}" }).join("\n").say
```

**关键点**

- `Bag` 直接做词频；`Set` 做存在性。
- 数字排序必须转数值，否则 `'10'` 会排在 `'2'` 前面。

### 5.10 按行处理大文件，不爆内存

```raku
my $fh = open 'huge.log', :r;
my $n = 0;
for $fh.lines -> $l {
    $n++ if $l.contains('ERROR');
}
$fh.close;
say $n;
```

文件不算特别大时，用 `stream` 更省代码：

```raku
my $c = stream('app.log').where({ .<line>.contains('ERROR') }).count;
say $c;
```

**关键点**

- `stream` 的文件 / 文本来源会先**整份读进内存**再解析，适合中等大小；
  真正逐条流式的是数据库 `Cursor`。超大日志用上面的 `IO.lines` /
  `read-lines`（详见 §6.9）。
- 手工 `open ... :r` 绕过了 `Sys` 的 root 约束，脚本里可以，但别用它处理
  不可信路径。
- `read-lines(:head/:tail)` 是更省事的首尾读取。

### 5.11 生成文本报告

```raku
my @lines = ls('logs').grep(*.f).map(-> $f {
    sprintf "%-24s %8d  %s", $f.basename, $f.s, $f.modified.DateTime
});
write('report.txt', "文件\t大小\t修改时间\n" ~ @lines.join("\n") ~ "\n");
```

**关键点**

- 写文件时自己补最后的换行，`join` 不会自动加。
- 需要 CSV 就给字段加引号并转义，或直接用 `save-data('report.csv', $t)`。

---

## 6. 结构化数据与 CSV/JSON

### 6.1 `open-data` / `open` 会返回什么

```raku
open-data('users.json')       # [{...}, {...}] → Table；单个 {...} → Hash
open-data('users.csv')        # Table（默认全部按 Str）
open-data('README.md')        # Str
open-data('run.parquet')      # 报错：必须显式授权
open-data('run.parquet', :allow-external)
open-data('big.csv', :allow-external, :max-rows(1_000_000))
open-data('run.arrow')        # Table（二进制，内置解析）
```

```bash
open users.csv
open --raw README.md
open --limit 50 big.csv
open --external run.parquet
```

| 扩展名 | 默认行为 | 备注 |
|---|---|---|
| `.json` | 对象数组 → Table；单对象 → Hash | 嵌套值保留为 list/map |
| `.csv` | Table，所有列 Str | 要类型推断加 `:allow-external` |
| `.tsv` | 按文本 | 用 `stream(:format<tsv>)` 解析 |
| `.parquet` / `.pq` | 拒绝 | 必须 `:allow-external` 或 `open --external` |
| `.arrow` / `.feather` / `.ipc` | Table | 二进制，不支持 `--raw` |
| 其它 | Str | `open --raw` 强制文本 |

**关键点**

- `open-data` 的路径走 `Sys.resolve`；不能借它越过会话 root。
- `.csv` 默认按 Raku 解析器读，不依赖 DuckDB；因此没有 DuckDB 也能用。
- `.csv` + `:allow-external` 才支持 `:csv-options` 和类型推断。
- `:max-rows` 只对 DuckDB 外部读取路径生效（csv/parquet）；普通 JSON 读取
  不支持截断。

### 6.2 手工构造 Table

```raku
my $t = Rakuish::Data::Table.from-rows([
    %(name => 'Ada', age => 36, dept => 'eng'),
    %(name => 'Bob', age => 41, dept => 'ops'),
    %(name => 'Cara', age => 29, dept => 'eng'),
]);
```

```raku
my $t = Rakuish::Data::Table.new(
    columns => <name age>,
    rows    => [ %(name => 'Ada', age => 36), ],
);
```

**坑**

- 不要写 `Table.new(rows => [...])` 再指望自动推断列：单行 Hash 会被当成
  Pair 列表。用 `from-rows`。
- `from-rows` 的列顺序取**第一行**的键（排序后）。行之间字段不一致时，
  显式传 `:columns(<a b c>)`，否则后面的新字段不会出现在表里。
- 单行 Hash、Pair 列表 `[:a(1), :b(2)]` 都会被 `from-rows` 归一化成一行。

### 6.3 看结构：schema / describe

```raku
$t.columns
$t.schema.to-text
$t.column-type('age')
describe($t).to-text
```

`describe` 返回 Table，列包括 `name/type/nullable/non_null/distinct/total/sample`：

```raku
describe($t).where({ .<nullable> })
            .select('name', 'non_null', 'total')
            .to-text
```

**关键点**

- 类型集合只有 `int / num / str / bool / datetime / list / map / any`。
- 类型在构造时推断，链式操作会保留；`join` 合并右表类型。
- 推断看值本身，不看你「以为」的类型；混合列会退化成 `any`。

### 6.4 筛选、投影、排序、分页

```raku
$t.where({ .<age> >= 35 }).to-text
$t.where({ .<dept> eq 'eng' }).select('name', 'age').to-text
$t.sort-by('age', :reverse).to-text
$t.sort-by('dept').sort-by('age').to-text
$t.limit(10).offset(20).to-text      # 第 21–30 行
$t.first(3).to-text                 # 前 3 行（Table）
$t.last(3).to-text                  # 后 3 行（Table）
$t.distinct('dept').to-text
$t.each({ say .<name> })             # 逐行回调
```

**关键点**

- `where` 的块收到一行 Hash，用 `.<列名>` 取字段。
- `first` / `last` 返回的是 **Table**，不是单行；要取一行用
  `$t.first(1).rows[0]`。
- `sort-by` 的开关是 `:reverse`，不是 `:desc`。
- 多次 `sort-by` 是稳定排序，后写的优先级更低（先按 dept，再按 age）。

### 6.5 聚合

```raku
$t.count
$t.sum('age')
$t.mean('age')
$t.min('age')
$t.max('age')
```

分组要自己写（Table 没有 group-by）：

```raku
my %sum;
my %n;
$t.each({
    %sum{$_<dept>} += $_<age>;
    %n{$_<dept>}++;
});
%sum.keys.sort.map({ "{$_}\t{%sum{$_}}\t{%n{$_}}\t{%sum{$_}/%n{$_}}" }).join("\n").say
```

**关键点**

- `sum` / `mean` 只对数值列有意义；对 Str 列会得到 0 / 报错。
- 空表时 `min` / `max` 返回 `Nil`，先判空再格式化。
- 复杂聚合直接用 SQL（§7），别在 Raku 里手搓。

### 6.6 两表合并：join / zip / append / interleave

```raku
my $orders = Rakuish::Data::Table.from-rows([
    %(user_id => 1, amount => 99),
    %(user_id => 2, amount => 30),
]);
my $users = Rakuish::Data::Table.from-rows([
    %(id => 1, name => 'Ada'),
]);

$orders.join($users, :on<user_id>)                 # 左连接，默认
$orders.join($users, :left-on<user_id>, :right-on<id>, :how<inner>)
$orders.join($users, :on<user_id>, :how<outer>, :suffix('_u'))
```

**语义**

- `:how` 支持 `inner / left / right / outer`，默认 `left`。
- 默认同名列在右表加 `_right` 后缀，可用 `:suffix` 改。
- 连接键统一转成字符串比较；`1` 和 `'1'` 能连上。

```raku
$t.zip($other)             # 按位置对齐，短的一侧结束
$t.append($other)          # 纵向追加，列取左表
$t.interleave($other)      # 交替取行
$t.tee('snapshot.csv')     # 转交一份出去，自己不消费
```

**关键点**

- `zip` 只适合「行数一致且顺序有意义」的表。
- `append` 的列以左表为准；右表多出来的列会丢。
- `tee` 只是转发，不会消耗当前表；别把它当 `save-data` 的替代（它不返回
  Table）。

### 6.7 导出：JSON / CSV / Parquet / Arrow

```raku
save-data('out.json', $t)                       # 默认 pretty
save-data('out.json', $t, :pretty(False))
save-data('out.csv', $t)                        # 纯 Raku CSV，值全按文本
save-data('out.csv', $t, :allow-external)       # DuckDB 写出，保留类型
save-data('out.parquet', $t, :allow-external)
save-data('out.arrow', $t, :batch-size(50_000))
```

```raku
$t.to-text
$t.to-markdown
$t.to-json(:pretty)
$t.to-csv
```

**关键点**

- `save-data` 返回 `True`，不返回 Table。
- `.parquet` 必须 `:allow-external`；`.arrow` 不需要。
- `.csv` 不带 `:allow-external` 时走 `Sys.write`，所有值按文本写；日期、
  Null、bool 的写法与 DuckDB 路径不同。
- Arrow 嵌套列写不出（`list/map` 会明确报错），先拍平成标量列。
- 写 Arrow 时 `:batch-size` 控制 RecordBatch 大小，不是行数上限。

### 6.8 CSV 方言：分号、引号、无表头

```raku
open-data('semi.csv', :allow-external,
          :csv-options(%(delimiter => ';')))

open-data('no-header.csv', :allow-external,
          :csv-options(%(header => False)))

open-data('quoted.csv', :allow-external,
          :csv-options(%(quote => '"', escape => '"')))

open-data('all-text.csv', :allow-external,
          :csv-options(%(all-varchar => True)))

open-data('nulls.csv', :allow-external,
          :csv-options(%(nullstr => 'NULL')))
```

**关键点**

- 可用键：`delimiter / quote / escape / header / skip / all-varchar / nullstr`。
- 这些键只在 `.csv` + `:allow-external` 时生效；其它组合会明确报错，不会
  静默忽略。
- 写出方言只支持 `delimiter / quote / escape / header / nullstr`。

### 6.9 Stream：逐条处理，不先建整张表

```raku
stream('app.log')                              # 每行一条 %(n, line)
stream('users.csv', :format<csv>)
stream('users.tsv', :format<tsv>)
stream('users.json', :format<json>)            # 必须是对象数组
stream('events.jsonl', :format<jsonl>)         # 一行一个对象
stream('access.log', :format<pattern>,
       :pattern(/^(\S+) \s+ \S+ \s+ \S+ \s+ \[([^\]]+)\] \s+ "(\w+)/),
       :names(<ip time method>))
```

```raku
stream('users.csv', :format<csv>)
    .where({ .<age>.Int >= 30 })
    .map({ %(name => .<name>, age => .<age>.Int) })
    .limit(100)
    .table
    .to-text
```

**关键点**

- 文本来源（文件 / 字符串 / `Result`）会先**整份读进内存**再解析；真正的
  逐条流式只有 Cursor / 进程通道。超大文件请用 `read-lines` 或 `Cursor`。
- 下游阶段是惰性的：`where` / `map` / `limit` 不会提前拉完全部行。
- Stream 是**一次性**的：`table` / `text` / `json` / `csv` / `count` 消费后
  再消费会报错；需要复用先 `.table`。
- `:format<json>` 只接受对象数组；单个对象请 `stream(record)`。

### 6.10 Stream 的常用出口

```raku
my $s = stream('users.csv', :format<csv>);

$s.count
$s.rows                        # 逐条 Hash 的 Seq
$s.column('name')              # 单列 Seq
$s.lines                       # 拼接成文本行
$s.text                        # 整份文本
$s.json                        # JSON 文本
$s.csv                         # CSV 文本
$s.table                       # 物化成 Table
$s.first-row
$s.sum('age'); $s.mean('age'); $s.min('age'); $s.max('age')
```

**坑**

- `rows` / `column` 也是消费；别在一个 Stream 上既 `rows` 又 `table`。
- `count` 会走完整条流；对进程通道意味着要等子进程结束。

### 6.11 把流喂给外部命令

```raku
stream('users.csv', :format<csv>)
    .exec('grep', 'Ada', :format<csv)
    .table
    .to-text
```

```raku
my $r = stream('big.csv', :format<csv>)
    .exec('python', 'tools/clean.py', :format<csv);
$r.out.lines.elems;
```

**关键点**

- `exec` 把流按 `:format` 序列化到子进程 stdin，再把 stdout 按 `:format`
  解析回来。
- `Stream.exec` 的 `:format` 只支持 `lines / csv / tsv / json`。
- 子进程提前退出（`head -1`、`grep -q`）会停止喂数据，不会白跑完整条流。
- 需要在 REPL / Session 上下文里用；裸脚本没有 `$*RAKUISH-SYS` 会明确报错。

### 6.12 流的分流与拼接

```raku
stream('input.csv', :format<csv>)
    .tee('raw-copy.csv')
    .where({ .<ok> eq '1' })
    .csv
```

```raku
my $a = stream('a.csv', :format<csv>);
my $b = stream('b.csv', :format<csv>);

$a.zip($b)             # 按位置配对，产生 (left, right) 记录
$a.join($b, :on<id>)   # 流式连接，右侧必须物化
$a.interleave($b)
$a.append($b)
```

**关键点**

- `tee` 放在链条任意位置都行，它把当前形态写一份出去，再原样往下传。
- 流式 `join` 会把右表建成索引，所以右表必须能完整读入。
- `append` 的列取左流；右流多出的列不会出现。

### 6.13 分页查看：`explore`

```bash
explore                     # 探索上一格 Table
explore users.csv
explore --limit 100 big.csv
```

- TTY 下 Enter 下一页、`q` 退出。
- 非 TTY 直接输出完整文本（没有交互）。
- `RAKUISH_PAGER=never` 强制不分页，适合脚本 / CI。
- `explore` 没有第二套数据解释，仍然走 `open-data`。

### 6.14 Arrow 大文件：边生成边写

```raku
write-ipc-stream((^1_000_000).map({ %(n => $_, s => "u{$_}") }),
                 'big.arrow', :batch-size(50_000));
```

```raku
read-ipc-file('big.arrow').limit(5).to-text
read-ipc(read('big.arrow', :bin))          # 从 Buf 读
```

**关键点**

- `write-ipc-stream` 返回写入行数。
- 空流无法推断 schema：要么给 `:columns`，要么先建空 Table 用 `save-data`。
- `read-ipc-file` 是整份读入；要看几行就用 `.limit(5)`，但文件仍已被读入。

---

## 7. SQL：DuckDB 与 SQLite

### 7.1 先选引擎

| 场景 | 引擎 | 理由 |
|---|---|---|
| CSV / Parquet 分析、复杂 join、窗口函数 | DuckDB | 列式、快、能直接读文件 |
| 小应用状态、事务、单文件库 | SQLite | 单连接、事务可靠、部署简单 |
| 没装任何数据库依赖 | 纯 Raku Table / Stream | 核心功能不依赖可选引擎 |

```raku
open-db(':memory:')                                   # DuckDB 内存库
open-db('analytics.duckdb')                           # 只读打开
open-db('app.db', :engine<sqlite>)                    # SQLite 只读
open-db('app.db', :engine<sqlite>, :read-only(False)) # 可写
```

**关键点**

- 两个引擎都是**可选依赖**，缺失时报安装提示，不会静默降级。
- `open-db` 默认 `read-only=True`；写库必须显式关掉。
- `:memory:` 不解析成路径；其它路径按会话 cwd / root 解析。
- `open-db` 会把引擎注册为当前会话引擎，供 SQL 补全与 `describe('表名')` 用。

### 7.2 查询：参数化，别拼字符串

```raku
my $db = open-db('sales.duckdb');

$db.tables.to-text
$db.schema('orders').to-text
$db.describe('orders').to-text

$db.query('select * from orders limit 5').to-text
$db.query('select * from orders where amount > ?', 100).to-text
$db.query('select * from orders where user_id = ? and amount > ?', 7, 50).to-text
```

**关键点**

- `query` 返回 Table；参数用 `?` 占位，按位置传。
- `:max-rows` 会在 SQL 层加 `LIMIT`，不是取回再截断：

```raku
$db.query('select * from big', :max-rows(100)).to-text
```

- 默认 `enable_external_access=false`：SQL 里的 `read_csv` 等文件函数不能
  绕过 `Sys` 的目录边界。

### 7.3 建表、写入、更新

```raku
my $db = open-db('app.db', :engine<sqlite>, :read-only(False));

$db.execute('create table if not exists notes (id integer primary key, body text)');
$db.execute('insert into notes (body) values (?)', 'hello');
$db.execute('update notes set body = ? where id = ?', 'hi', 1);
$db.execute('delete from notes where id = ?', 1);
```

**关键点**

- `execute` 返回受影响行数（DDL 通常 0）。
- 只读引擎上 `execute` 和 DDL 会抛 `X::Rakuish::Unsupported`。
- SQLite 适配器固定一个连接；`:memory:` 不会因为连接池变成多个库。
- DuckDB 的 `execute` 适合批量 DDL / 导入；大结果仍用 `query`。

### 7.4 事务

```raku
my $db = open-db('app.db', :engine<sqlite>, :read-only(False));

$db.begin;
my $ok = True;
try {
    $db.execute('insert into notes (body) values (?)', 'a');
    $db.execute('insert into notes (body) values (?)', 'b');
    CATCH { default { $ok = False; .rethrow } }
}
if $ok { $db.commit } else { $db.rollback }
```

**关键点**

- `begin / commit / rollback` 是引擎连接级，不跨会话共享。
- 只读引擎调用事务直接抛 `Unsupported`。
- 事务里抛异常后一定要 `rollback`，否则连接会停在未完成事务上。

### 7.5 大结果：Cursor 分批取

```raku
my $c = $db.cursor('select * from events order by id', :batch-size(1000));

for $c.batches -> $batch {
    say "本批 {$batch.elems} 行，累计 {$c.fetched}";
    # 处理这一批，不要攒起来
}
$c.close;
```

```raku
my $first = $c.take(10);       # 取前 10 行，返回 Table
```

**关键点**

- Cursor 是真正的流式路径：不会先把整张结果物化。
- Cursor 是一次性来源；二次消费会明确报错。
- 提前退出循环记得 `close`，否则底层结果集可能占着连接。
- `:max-rows` 在 Cursor 上也有上限保护。

### 7.6 查询超时

```raku
my $db = Rakuish::Data::Engine::DuckDB.new(
    :path(':memory:'),
    :max-execution-time-ms(2000),
);

my $r = try { $db.query('select * from huge, huge2') };
say $r.defined ?? '完成' !! '超时或失败';
```

**关键点**

- `open-db` 没有超时参数；要超时就直接构造引擎。
- DuckDB 映射到 `max_execution_time`；SQLite 通过看门狗调 `sqlite3_interrupt`。
- 超时抛数据库中断错误（SQLite 侧是 `X::Rakuish::Limit`），不是返回空表。
- 中断是连接级操作，不跨连接共享。

### 7.7 用 SQL 直接读 CSV / Parquet

```raku
my $db = Rakuish::Data::Engine::DuckDB.new(:path(':memory:'), :safe(False));

my $t = $db.read-csv('/abs/path/users.csv',
                     :csv-options(%(delimiter => ',')),
                     :max-rows(1000));
$t.to-text

$db.read-parquet('/abs/path/events.parquet', :max-rows(1000)).to-text
```

**更省事的入口**：

```raku
open-data('users.csv', :allow-external).to-text
open-data('events.parquet', :allow-external).limit(10).to-text
save-data('clean.parquet', $t, :allow-external)
```

**关键点**

- 直接调引擎的 `read-csv` / `read-parquet` 时，路径是 DuckDB 自己打开的，
  **不经过** `Sys.resolve`；用户输入路径请先 `sys.resolve`。
- `open-data(:allow-external)` 会先 resolve，再交给 DuckDB，安全边界更完整。
- `:safe(False)` 才允许外部文件访问；默认 `safe=True`。

### 7.8 多表在 SQL 里 join

```raku
my $t1 = open-data('orders.csv');
my $t2 = open-data('users.csv');

my $joined = sql({ o => $t1, u => $t2 }, q:to/SQL/);
    select u.name, sum(o.amount) as total
    from o join u on o.user_id = u.id
    group by u.name
    order by total desc
SQL

$joined.to-text
```

**关键点**

- `sql` 是 DuckDB 的快捷入口；它把 Hash 里的每个 Table 注册成同名表。
- 只支持一个 SELECT 语句；DDL / 多语句请用 `open-db` + `execute`。
- 没有 DuckDB 时会明确报安装提示。

### 7.9 单个 Table 直接跑 SQL

```raku
my $t = open-data('sales.csv');

$t.sql('select region, count(*) as n, sum(amount) as total
        from t group by region order by total desc').to-text
```

```raku
$t.sql('select * from t where amount > 100', :name('sales')).to-text
```

**关键点**

- 表名默认是 `t`，可用 `:name` 改。
- 适合「我已经有一张 Table，想用 SQL 做分组 / 窗口」的场景。
- 它内部也要求 DuckDB；没有就报错。

### 7.10 把查询结果变成 Table 后继续链式处理

```raku
$db.query('select * from orders')
   .where({ .<amount> > 100 })
   .sort-by('amount', :reverse)
   .select('id', 'amount')
   .to-text
```

**关键点**

- `query` 已经返回 Table，后面和 §6 的 API 完全一样。
- 能在 SQL 里做的过滤尽量在 SQL 做；`WHERE` 比取回再 `.where` 快得多。

### 7.11 实战：CSV → 清洗 → Parquet

```raku
my $raw = open-data('raw/orders.csv', :allow-external);

my $clean = $raw
    .where({ .<amount> ne '' })
    .select('id', 'user_id', 'amount', 'created_at');

save-data('clean/orders.parquet', $clean, :allow-external);
say "写出 {$clean.elems} 行";
```

**关键点**

- `:allow-external` 读和写都要给；路径仍受会话 root 约束。
- 列类型来自 DuckDB 推断；空值 / 空字符串的处理要先用 `describe` 看清楚。
- 目录不存在时先 `mkdir`，`save-data` 不会替你建父目录。

### 7.12 关闭与资源

```raku
$db.close;
```

**关键点**

- 长会话里打开很多引擎会占文件句柄；不用了就 `close`。
- 关闭后再 `query` 会报错，不会静默重连。
- `open-data(:allow-external)` 的临时引擎由内部 `LEAVE` 自动关闭，不用你管。

---

## 8. 脚本与自动化

### 8.1 最小脚本

```raku
#!/usr/bin/env rakuish
# tools/hello.raku

say "cwd  = {sys.cwd}";
say "args = {@*ARGS.join(', ')}";
```

```bash
rakuish tools/hello.raku a b
```

**关键点**

- 脚本模式预加载 DSL、`sys`、`repl`、`registry`，不用手写 `use`。
- Shebang 只是注释，Raku 和 Rakuish 都不靠它启动；Windows 上直接
  `rakuish tools/hello.raku`。
- 输出不带 `Out[n]`，`exit` 也不会丢已打印内容。
- 相对路径跟随**调用者 cwd**，不是脚本所在目录。

### 8.2 有 `sub MAIN` 就按命令行分派

```raku
#!/usr/bin/env rakuish
# tools/list-big.raku

sub MAIN(Str $dir = '.', Int :$top = 10, Bool :$json) {
    my $t = ls-table($dir).where({ .<type> eq 'file' })
                          .sort-by('size', :reverse)
                          .limit($top);

    $json ?? $t.to-json(:pretty)!! $t.to-text.say;
}
```

```bash
rakuish tools/list-big.raku
rakuish tools/list-big.raku src --top 5
rakuish tools/list-big.raku . --top=3 --json
rakuish tools/list-big.raku --help
```

**关键点**

- 位置参数、命名参数、类型强转、`multi MAIN`、`--help`、`sub USAGE`、退出码
  都交给 Rakudo 的 `RUN-MAIN`，与 `raku 文件 参数` 一致。
- 顶层语句先执行，MAIN 能看到脚本顶层的 `my` 变量。
- 没给参数而 MAIN 需要参数时，会打用法并 `exit 2`。
- `Bool :$json` 是开关；`Int :$top` 支持 `--top=3` 或 `--top 3`。

### 8.3 `multi MAIN` 做子命令

```raku
multi MAIN('clean', Str $dir = '.') {
    say "清理 $dir";
}

multi MAIN('report', Str $dir = '.', Int :$days = 7) {
    say "报告 $dir 最近 $days 天";
}

multi MAIN($other, *@rest) {
    note "未知子命令: $other";
    exit 2;
}
```

```bash
rakuish tool.raku clean tmp
rakuish tool.raku report logs --days 30
```

**坑**：`multi MAIN($other, *@rest)` 会兜底所有输入；不想兜底就删掉它，让
Rakudo 打用法。

### 8.4 退出码与失败处理

```raku
sub MAIN(Str $file) {
    unless $file.IO.e {
        note "找不到文件: $file";
        exit 2;
    }

    my $r = exec('git', 'status', '--porcelain');
    unless $r.ok {
        note "git 失败({$r.code}): {$r.err}";
        exit $r.code;
    }

    say $r.out;
}
```

**关键点**

- `note` 写 stderr，适合错误信息；`say` 写 stdout。
- 脚本模式没有 `set -e`；每一步自己判 `.ok` 或让它抛异常。
- `exit` 的码就是进程退出码；0 表示成功。
- 不要在表达式里 `exit`（如 `my $x = (exit 2)`），可读性差且容易误伤。

### 8.5 `source`：在会话里跑另一个文件

```raku
source('scripts/common.raku');
source('tools/import.raku', 'data.csv');
```

**关键点**

- `source` 在**当前会话**执行，脚本能看到会话变量；文件里的 `sub` / `class` /
  `use` / 顶层 `my` 也会留在会话里。
- 报错带 `文件:行号`；失败的行不会中断后面的行（与 rc 一样）。
- 给了参数会调用脚本的 `sub MAIN`，但它不是 `rakuish 文件` 的完整命令行
  分派；复杂 MAIN 建议直接跑文件。
- `source` 的行不占 `Out[n]` / 历史。

### 8.6 把会话存成可重放脚本：`cells`

```bash
cells                       # 列出本会话的格
cells --text -              # 打印可重放的 Raku 脚本到 stdout
cells --text session.raku   # 写到文件
cells --json -              # 结构化导出
```

```bash
rakuish session.raku        # 以后直接重放
```

**关键点**

- `cells --text` 只导出**成功执行**的格，并补上分号 / `no worries;`，
  避免重放时因缺分号失败。
- 失败的格、纯声明格的缓存不在导出里；需要哪些就重跑一遍再导出。
- 导出的是「会话历史」，不是「项目源码」，别把它当版本控制替代品。

### 8.7 并行：`peach`

```raku
my @nums = (1..200_000).List;

my @squares = peach(@nums, { $_**2 }, :degree(8));
@squares.elems
```

**关键点**

- `peach` 是并行 `map`，`:degree` 控制并发度，结果**保序**。
- 只适合纯计算 / 无共享副作用的任务；不要在块里改同一个 Hash / 文件。
- IO 密集任务并发度别开太大，磁盘和进程启动会成为瓶颈。

### 8.8 计时：`timed` / `bench` / `perf`（Raku 代码与外部命令）

Raku 代码：

```raku
my $r = timed { (1..1_000_000).sum };
$r.value
$r.elapsed
```

```raku
my $b = bench({ (1..100_000).sum }, :repeat(5));
$b.value<min>
$b.value<mean>
$b.value<max>
```

外部命令不需要另一套 API：`exec` 返回的 `Result` 上就有 `elapsed`。

```raku
my $r = exec('ping', '-n', '3', '127.0.0.1');   # 裸命令名走 PATH
$r.elapsed            # Duration，例如 2.066s：spawn → 收割的墙钟
$r.elapsed.Num        # 秒
```

要跑多次看分布，就用 `timed` / `bench` 包住 `exec`：

```raku
timed { exec('ping', '-n', '3', '127.0.0.1') }.elapsed.Num

my $b = bench { exec('ping', '-n', '1', '127.0.0.1') }, :repeat(5);
$b.out                  # 5 次 · min … ms · mean … ms · max … ms · 总 … ms
$b.value<mean> * 1000   # 毫秒
```

`!` 行（含管道、`! --pipe`）不把 `Result` 交到你手上，但整格照样被入口计时，
看 prompt 或 `perf` 即可；要用 shell 语法又想要 `Result`，就换成 `cmd-result`：

```raku
timed { cmd-result('! git log --oneline | head -n 5') }.elapsed
```

（`cmd-result` 要有 REPL 会话；裸脚本里没有，见 §6.11 的同类限制。）

```bash
perf 20        # 最近 20 格耗时与平均/最慢
```

**关键点**

- `timed` 返回 `Result`，`.elapsed` 是 `Duration`，`.value` 是块的结果；
  `.elapsed` 是**总和**，`:repeat(N)` 时单次时长约除以 N。
- `bench` 的 `min/mean/max` 单位是秒，`out` 里是排好版的毫秒摘要。
- `perf` 的数据来自入口对每格的统一计时（shell / `!` / Raku 三类格都算），
  不含历史重放；`repl.perf-hist` 是原始记录。
- 计时包含求值本身，不含你在 REPL 里打字的时间。
- `elapsed` 是**墙钟**：含进程启动、管道泵送、`await`，不是子进程 CPU 时间；
  要纯进程耗时，用外部 `Measure-Command` / `hyperfine` 交叉验证。
- 失败 / 超时也照样有 `elapsed`：先看 `$r.ok` / `$r.code`（启动失败 `127`、
  超时 `124`、取消 `137`），否则会把一个无意义的数字当成结论。
- `exec` 默认 30 秒超时、stdout/stderr 各 1 MiB，两者都会影响测量；长任务显式
  给 `:timeout-ms`，测吞吐时别拿被截断的输出做基准。
- REPL 不保留上一格的 `Result`，`_` / `Out[n]` 里也拿不到 `elapsed`；要精确数字
  就当场 `exec` / `timed`，事后查 `perf` 或 `repl.perf-hist`。

### 8.9 把可能失败的操作收敛成 `Result`：`try-op`

```raku
my $r = try-op('read', { read('nope.txt') });
$r.ok
$r.code
$r.err
```

**关键点**

- `try-op` 捕获块里的异常，转成失败 `Result`；`$r.code` 来自
  `X::Rakuish::*` 的 `code`（没有就用 1）。
- 适合脚本里「失败要记日志但不想中断」的场景。
- 不要用它掩盖编程错误（拼错方法名、类型错误），那些应该让脚本失败。

### 8.10 实战：每日清理报告

```raku
#!/usr/bin/env rakuish
# tools/cleanup-report.raku

sub MAIN(Str $dir = '.', Int :$days = 7, Bool :$delete) {
    my $cutoff = DateTime.now.Instant - $days * 86400;

    my @old = ls($dir, :recursive)
        .grep({ .f && .modified < $cutoff })
        .sort(-*.s);

    my $bytes = @old.map(*.s).sum;

    say "目录: {$dir}";
    say "阈值: 早于 {$cutoff.DateTime}";
    say "文件: {+@old} 个，合计 {sprintf '%.2f', $bytes / 1e6} MB";

    @old.head(20).map({ sprintf "%10d  %s", .s, .Str }).join("\n").say;

    if $delete {
        rm($_.Str) for @old;
        say "已删除 {+@old} 个文件";
    } else {
        say "（预演模式；加 --delete 真正删除）";
    }
}
```

```bash
rakuish tools/cleanup-report.raku logs --days 30
rakuish tools/cleanup-report.raku logs --days 30 --delete
```

**关键点**

- `ls(:recursive)` 会先做条目数上限检查，超限直接拒绝。
- `*.s` 是字节数；`sprintf` 里先转浮点，避免整数除法。
- 删除是不可逆的；默认预演，显式 `--delete` 才动手。

### 8.11 实战：目录轮询处理

```raku
#!/usr/bin/env rakuish
# tools/watch-inbox.raku

sub MAIN(Str $in = 'inbox', Str $out = 'outbox') {
    my %seen;

    loop {
        for glob('*.csv', $in) -> $f {
            next if %seen{$f.Str};
            %seen{$f.Str} = True;

            my $t = open-data($f.Str);
            my $target = "$out/{$f.basename}.json";
            save-data($target, $t);
            say "处理 {$f.basename} → {$target}（{$t.elems} 行）";
        }
        sleep 5;
    }
}
```

**关键点**

- 这是一个前台循环，Ctrl-C 结束；生产环境交给系统定时器 / 服务管理器。
- `%seen` 只记本进程见过的文件；重启会重新处理已有文件。
- 处理失败会让整轮中断；要容错就把单个文件包进 `try-op`。
- 输出目录要先存在，`save-data` 不建父目录。

### 8.12 实战：批量生成周报

```raku
#!/usr/bin/env rakuish
# tools/weekly.raku

sub MAIN(Str $dir = 'logs', Str :$out = 'weekly.md') {
    my @files = glob('*.log', $dir).sort;

    my @lines = @files.map(-> $f {
        my $errors = stream($f.Str)
            .where({ .<line>.contains('ERROR') })
            .count;
        "| {$f.basename} | {$f.s} | $errors |"
    });

    my $md = "| 文件 | 字节 | ERROR |\n|---|---:|---:|\n"
           ~ @lines.join("\n") ~ "\n";

    write($out, $md);
    say "已写 $out";
}
```

```bash
rakuish tools/weekly.raku logs --out reports/week-47.md
```

**关键点**

- `stream(file)` 会整份读入；日志不大时最省代码，超大日志用 `read-lines`
  逐行计数。
- Markdown 表格第一行后必须有分隔行；这里手写，别忘。
- `write` 默认原子，读到一半的读者不会看到半个文件。

### 8.13 让脚本可重复：环境、随机、时间

```raku
my $stamp = DateTime.now.formatted('%Y%m%d-%H%M%S');
my $tmp = "tmp/run-$stamp";
mkdir($tmp);

my $r = exec('raku', '-e', 'say 1');
write("$tmp/out.txt", $r.out);
```

**关键点**

- 时间戳用 `DateTime.now.formatted`，不要手拼 `%s`。
- 需要可重复测试时，别把随机数藏进文件名；用参数传入种子。
- `mkdir` 默认不报已存在；要严格就 `mkdir($tmp, :parents)` 并检查结果。

---

## 9. 会话管理：历史、快照、配置

### 9.1 历史：看、搜、重跑、改

```bash
history            # 最近若干条
history 50         # 最近 50 条
rerun 3            # 直接重跑第 3 条
recall 3           # 把第 3 条放回输入行，不执行
!!                 # 重跑上一条
!$                 # 上一条的最后一个参数
!-2                # 倒数第 2 条
```

**关键点**

- `rerun` / `recall` 的编号与 `history` 一致；`recall` 只预填，方便改一个字。
- 整行 `!!` / `!$` / `!n` / `!-n` 才做历史替换；`!cmd` 仍是外部命令。
- 替换结果会再进历史；内部用 `expanding` 标志防递归。
- `set +o histexpand` 可关掉历史替换。

### 9.2 看当前会话里有什么

```bash
who            # 变量名
who -l         # 等价 whos：类型 / 大小 / 声明
```

```raku
whos
```

**关键点**

- 只列顶层 `my` / `our` / `%STATE` 里的名字；嵌套块里的局部变量看不到。
- `who -l` 会显示类型、长度和原始声明，适合排查「这个变量到底是什么」。

### 9.3 会话日志：把每格记成纯文本

```bash
log start
log start ./session.log
log show
log stop
```

**关键点**

- 默认写 `~/.rakuish-session.log`；路径经 `Sys` 写。
- 记录每格输入与结果，纯文本，不结构化；要结构化用 `audit`。
- 日志文件没有自动轮转；长期开启记得自己清理。

### 9.4 审计：按来源看谁执行了什么

```bash
audit                     # 各来源计数
audit --origin human      # 人手动输入的明细
audit notebook            # notebook 来源的明细
```

**关键点**

- 审计是结构化 JSONL 账本；其它进程写下的记录也会被读进来。
- `--origin` 过滤来源；不带参数只给汇总，不打印全部明细。
- 审计记录的是动作与结果元信息，不是完整文件内容。

### 9.5 `store`：跨会话保存变量

```raku
my $cfg = %(env => 'prod', retries => 3);
my @rows = (1, 2, 3);

store $cfg @rows          # 存
store -l                  # 看库里有什么
store -r cfg rows         # 读回（名字可不带 sigil）
store -d cfg              # 删一个
store --clear             # 清空
store -f other.json $cfg  # 换一个库文件
```

**关键点**

- 默认库 `$*HOME/.rakuish/store.json`，跨会话、跨目录。
- 只存可序列化的纯值；闭包 / 连接句柄 / 进程 / 锁 / 超大值会被拒绝，
  并给出具体理由，不会静默跳过。
- `store -r` 会把变量重新定义到当前会话；同名变量会被覆盖。
- 与快照相反：快照自动、按 cwd 分文件、只用于崩溃恢复；`store` 是你显式
  选择的持久化。

### 9.6 快照：崩溃后接着干

快照是**自动**的，没有命令：

- 每格成功后写一次；失败格不写，避免冲掉上一份好快照。
- 按 **cwd 指纹**分文件：`$*HOME/.rakuish/session-<指纹>.json`。
- 引擎崩溃 / Ctrl-C 中断 / `exit` 写在表达式里导致重启时，自动恢复。

```text
引擎进程已退出（连接已断开）
  · 已自动重启：REPL 本身没有退出，可以继续输入
  · 已从快照恢复：5 条声明、3 个变量（2026-11-16T17:00:00）
  · 无法恢复：$db（连接 / 闭包 / 超大值，已置为 Any；重新赋值即可）
```

**边界**

- 只恢复纯值与顶层声明；数据库连接、文件句柄、进程、锁、闭包全部置
  `Any`，需要重新 `open-db(...)` / 重新打开文件。
- 语句副作用**不会重放**；恢复的是值，不是「把写文件再执行一遍」。
- 快照有单值上限（`RAKUISH_SNAPSHOT_MAX`，默认 1,000,000 字符），
  **没有总量上限**。
- `RAKUISH_NO_SNAPSHOT=1` 同时停读停写；`RAKUISH_SNAPSHOT=<path>` 换位置。
- 快照里有变量值，可能含凭据；POSIX 上权限收紧到 `600`，仍要自己注意。

### 9.7 启动文件 `rc.raku`

```raku
# ~/.rakuish/rc.raku
my $project = 'demo';

alias ll=ls -alh
set -o noglob

repl.prompt = -> {
    my $r = try { sys.exec('git', 'rev-parse', '--abbrev-ref', 'HEAD') };
    my $branch = $r.defined && $r.ok ?? $r.out.trim !! '';
    "{sys.cwd.basename}{$branch.chars ?? " [$branch]" !! ''} ❯ ";
};
```

**关键点**

- 路径优先级：`RAKUISH_RC` > `$*HOME/.rakuish/rc.raku`；
  `RAKUISH_NO_RC=1` 关闭。
- **不是** `~/.rakuishrc`：那是 v2 的 `KEY=VALUE` 配置，v3 不读。
- `-e` / 脚本 / 管道不执行 rc；rc 只在交互式 REPL 启动时跑。
- rc 逐行执行，一行失败不中断后面的行；rc 的格不占 `Out[n]` / 历史。
- 崩溃重启后 rc 会重新执行（prompt / 选项 / alias 是策略，不是数据）。

### 9.8 `config`：会话配置

```bash
config get color
config set color false
config set edit-mode vi
config set vi-start insert
config set hints off
config set plugins on
config unset plugins
```

**关键点**

- 配置默认写 `~/.rakuish-config.json`；`RAKUISH_CONFIG` 可覆盖。
- `edit-mode` 当格生效；`color` / `hints` / `clock` / `timing` / `git` /
  `prompt-style` / `banner` 每格重读，`config set` 立即生效。
- 只改「入口真的会读」的键；未知键会报错并列出可用项。

### 9.9 `alias`：只展开首个词

```bash
alias ll=ls -alh
alias gs=git status
alias ll              # 查看
unalias ll            # 删除
```

**关键点**

- alias 只展开 Shell 命令行的**首个词**，最多 10 层，防循环。
- `alias` 写进配置文件，跨会话保留。
- 别名后面的部分按薄层规则继续解析；不要把整段 Raku 表达式塞进 alias。

### 9.10 `hook`：启动前后自动做事

```bash
hook add start 'echo "session ready"'
hook run start
hook clear start
```

**关键点**

- hook 存在配置的 `hooks.EVENT` 数组里；`start` 在 `-e` / 脚本 / 交互式求值前
  运行。
- hook 失败会打印错误并**停止启动**；内容是本地可信配置，别从不可信来源
  导入。
- `hook run EVENT` 手动触发，适合调试。

### 9.11 `set -o`：会话级开关

```bash
set -o                 # 列出全部
set -e                 # 失败即退出（= set -o errexit）
set +e
set -o noglob          # 薄层不展开 * ?
set +o noglob
set -o noexpand        # 薄层不展开 $NAME / ~
set -o xtrace          # 求值前把 + <源码> 写 stderr
```

**关键点**

- 选项只在会话内有效；要跨会话写进 rc。
- `errexit` 遇到失败格会请求退出，退出码取该结果的 `code`（无则 1）。
- `xtrace` 走 stderr，不进 `Out` / `Result.out`。
- `noglob` 只影响薄层，不影响 `glob` 命令本身。

### 9.12 错误、提示、性能

```bash
errors             # 当前错误显示分级
errors short       # 一行类型 + 消息 + 位置
errors full        # 再加完整回放帧（等价 repl.trace = True）
hint               # 看上一格的上下文提示
hint git status    # 看某行会提示什么
perf 20            # 最近 20 格耗时
```

```raku
repl.trace = True
repl.history
repl.perf-hist
```

**关键点**

- 错误分三类：编译错误、运行错误、被拒绝（`X::Rakuish::*` 自己判定）。
- `errors full` 只影响显示，不改变错误对象。
- `hint` 与灰色自动提示同源；`config set hints off` 关自动显示。

### 9.13 把「能跑的会话」变成「可交付脚本」

1. 在 REPL 里把流程跑通，确认每一步的输出；
2. `cells --text -` 看导出的脚本，删掉探索性的格；
3. 把参数改成 `sub MAIN`；
4. 保存到 `tools/xxx.raku`，用 `rakuish tools/xxx.raku --help` 验证分派；
5. 用 `rakuish tools/xxx.raku ...` 在干净目录再跑一遍。

**关键点**

- 会话里依赖的 `my` 变量，导出后仍在；但依赖的**资源句柄**（`$db`、
  文件句柄）不会自动重建，脚本里要显式 `open-db` / `open`。
- 导出的脚本仍假设调用者 cwd；要改成就地找文件，用 `$?FILE` 或
  `$*PROGRAM.parent` 自己拼路径。

## 10. Notebook 与 Jupyter

Notebook 不是另一套语言：它和 REPL 共用同一个 `Session`、同一套 Kernel / 审计 /
`Out[n]` / `_`。区别只在**谁来显示结果**——终端由 REPL 打印，notebook 由前端
按 MIME 渲染。

### 10.1 两个角色：协议入口与 Jupyter 桥

| 角色 | 位置 | 负责什么 |
|---|---|---|
| 协议入口 | `bin/rakuish-notebook` | 一行一条 JSON 的请求 / 响应，不接 ZMQ |
| Jupyter 桥 | `tools/jupyter/rakuish_kernel/` | 把 Jupyter 的 ZMQ 消息翻译成上面的 JSON 行 |

协议入口只做「Raku 侧」：起引擎、跑格、回 `out` / `err` / `display`。真正的
传输层（ZMQ 五通道、HMAC、heartbeat）由 Python 的 ipykernel 基类负责。

### 10.2 手工跑一遍协议

```bash
echo '{"op":"execute","code":"1+1"}' | raku bin/rakuish-notebook
```

第一行永远是 ready 帧：

```json
{"event":"ready","language":"raku","pid":12345,"engine_pid":12399}
```

之后每行一条响应。PowerShell 里 `echo` 是 `Write-Output`，效果相同；注意
JSON 里的双引号要用单引号包住整串：

```powershell
'{"op":"execute","code":"1+1"}' | raku bin/rakuish-notebook
```

**关键点**

- 一条请求必须**压成一行**；JSON 里自己带 `\n` 会被当成两条帧。
- 进程是常驻的：可以连续喂多行，`shutdown` 之后才退出。
- 未知 `op` 不崩，返回 `ok:false` 并列出支持的 op。

### 10.3 支持哪些 `op`

| `op` | 用途 | 主要字段 |
|---|---|---|
| `kernel_info` | 协议版本、语言、banner | `protocol_version` / `language_info` / `banner` |
| `execute` | 跑一格 | `code` → `ok` / `code` / `out` / `err` / `display` |
| `complete` | 补全 | `code` / `cursor_pos` → `matches` / `cursor_start` / `cursor_end` |
| `is_complete` | 判断是否还缺闭合 | `code` → `status`（complete / incomplete） |
| `inspect` | 看符号 | `code` / `cursor_pos` → `found` / `text` |
| `history_request` | 取历史 | `hist_access_type` = tail / range |
| `interrupt_request` | 请求中断 | 单线程内核，只会在两格之间生效 |
| `input_request` / `input_reply` | 前端要输入 | 自定义前端用 |
| `shutdown` | 关会话 | 关引擎后退出 |

### 10.4 `execute` 到底回了什么

```json
{
  "op": "execute",
  "ok": true,
  "code": 0,
  "out": "",
  "err": "",
  "display": {
    "content": "2",
    "format": "text",
    "formats": ["text", "markdown", "html", "json"],
    "meta": {"source": "value"},
    "mime": {
      "text/plain": "2",
      "application/json": "2"
    }
  },
  "streamed": false,
  "execution_count": 1,
  "cwd": "C:/work/demo"
}
```

`display` 是这一格「值」的呈现，规则和终端完全一样：

- `meta.source` 说明来源：
  - `value` —— 这格的结果，前端应显示成 `execute_result`；
  - `out` —— 命令的 stdout，已经走过 `out`，别再显示一遍；
  - `error` —— 失败格的错误，走错误通道。
- `mime` 是**所有可用档**，前端挑自己会渲染的那一档；`text/plain` 永远在。
- 四档是 `text/plain` / `text/markdown` / `text/html` / `application/json`。
  值不能被 JSON 化时就不提供 `application/json`，而不是塞一个坏字符串。
- `out` / `err` 是用户看到的原始标准流（不含 `Out[n]` 标签、零 ANSI），
  和 `display` 不重复。

**关键点**

- 失败格的 `ok` 是 `false`，`code` 是退出码（Raku 异常通常 1）。notebook 回复
  里还会带 `ename` / `evalue` / `traceback`，Jupyter 用它画错误块。
- 失败格**不占** `execution_count`，和 REPL 里「纯声明格不占 Out」是同一口径。
- `silent:true` 的格不产生显示输出，但照样执行、照样改会话状态。

### 10.5 主动推送帧：`busy` / `idle` / `engine`

协议不严格一问一答，推送帧可以插在任意两条响应之间。**帧靠字段区分**：

| 帧 | 时机 | 说明 |
|---|---|---|
| `{"event":"busy","op":"execute","id":"c1"}` | 一格开始 | 前端可以锁输入 / 转圈 |
| `{"event":"execute_input","code":"...","execution_count":2}` | busy 之后、执行之前 | Jupyter 用来更新 `In[n]` 标签 |
| `{"event":"display_data","data":{"text/plain":"..."}}` | 回复之后、idle 之前 | 这一格里每次 `display()` 发一条 |
| `{"event":"idle","op":"execute","id":"c1","ms":12}` | 该格所有输出发完之后 | 彻底结束，可解锁 |
| `{"event":"engine","kind":"dead"}` | 引擎死亡 / 重启 / 恢复 | `dead` / `restart` / `interrupted` / `restart-failed` |

请求里带 `id`，响应与推送都会原样回显，前端按 id 认领。不带 `id` 的旧客户端
也能用，只是要记得「跳过 `event` 帧」。

**关键点**

- 客户端不能假设「发一条请求就收到一条回复」；中间会夹推送帧。
- `busy` / `execute_input` / `idle` 只包 `execute`；补全和 inspect 是按键触发
  的，不包。
- 顺序固定为 `busy → execute_input → 回复 → display_data* → idle`。
- `engine: dead` 是**空闲期**死亡（看门狗 250ms 内发现）；执行中死亡会在
  `execute` 回复的错误里体现，桥不再重复播报。

### 10.6 `display()`：一格里多次输出

```raku
my $t = open-data("sales.csv");
display($t);                       # 立刻发一份 display_data
say "共 { $t.rows.elems } 行";      # 这行走 stdout
$t;                                # 格末尾的值仍是 execute_result
```

在 notebook 里会依次出现：表格、一行文本、再一个表格（末尾值）。
在终端 / 管道里，`display($t)` 直接打印，`display` 的返回值是哨兵，**不改 `_`**。

**关键点**

- `display()` 是语句，不是值；不要写 `my $x = display($t)` 然后指望拿到表格。
- 一次执行里的多个 `display()` 按调用顺序收集，前端按序发多条 `display_data`。
- 自己实现了 `to-mime` 的对象可以额外提供 `image/svg+xml`、`text/latex` 等档；
  同名时以对象自己声明的为准。

### 10.7 装上 Jupyter kernel

```bash
python -m pip install ipykernel jupyter_client
python tools/jupyter/install_kernel.py
python tools/jupyter/smoke.py
jupyter lab
```

- `install_kernel.py` 把 wrapper 包和 `kernel.json` 复制到当前用户的 Jupyter
  数据目录（`jupyter_data_dir()/kernels/rakuish`），不改全局 `PYTHONPATH`。
- 用源码树、还没把 `rakuish` 装进 PATH 时，显式指定桥命令：

```bash
python tools/jupyter/install_kernel.py --bridge "raku -Ilib bin/rakuish-notebook"
```

- `smoke.py` 用 `BlockingKernelClient` 做端到端自检（启动、执行、读结果），
  装完先跑它，比在 Jupyter Lab 里瞎点快。
- 卸载：`python tools/jupyter/install_kernel.py --uninstall`。

**关键点**

- Jupyter 里的内核名是 `Raku (rakuish)`，语言标记 `raku`，文件扩展名 `.raku`。
- kernelspec 用 `interrupt_mode: "message"`：中断走消息而不是 SIGINT，因为
  Rakuish 的中断等于杀引擎重启，**会丢会话状态**，不能假装会话还活着。
- 桥只转播**空闲期**的 `engine: dead`，执行中的失败已经写在格子的错误里。

### 10.8 notebook 里不能做什么

| 能力 | 状态 | 原因 / 替代 |
|---|---|---|
| 流式输出 | 没有 | `out` 在一格结束后一次性回；要进度就 `display()` 中间结果 |
| `! --tty` | 不可用 | 没有终端；需要交互的程序别放进 notebook |
| 后台作业 `bg-exec` / `fg` | 不可用 | 需要持终端的父进程 |
| `input()` / `prompt`（Jupyter 桥） | 不可用 | 协议层有 `input_request`，但自带桥没接 stdin |
| 中断后保留会话 | 不行 | 中断 = 重启引擎，`my` 变量、`$db` 全没 |
| 自定义 `rc.raku` | 可用 | 启动时执行，输出进 ready 帧 |

**关键点**

- notebook 里**不要**在表达式中间写 `exit`：它会把引擎进程结束掉，前端只会
  看到「引擎已重启」，那一格的会话状态全丢。
- 需要长任务时，把中间结果 `display()` 出来，而不是等最后一次性打印。
- 需要终端交互、后台进程、超大文件流式处理时，回 REPL 或写成脚本。

---

## 11. 插件

插件是「把一组自定义命令注册进当前会话」的机制。它不是包管理器：不联网、
不扫描目录、不持久化，**加载即执行本地 Raku 代码**。

### 11.1 默认关闭

```bash
config set plugins on
config get plugins        # on
```

- 关闭时 `plugin load` 返回 403，并提示先打开。
- 打开只是允许加载；加载哪个文件仍由你显式给出路径。
- 只加载你信任的文件——插件文件会被 `EVAL`，等同 `use` 一个本地模块。

### 11.2 写第一个插件

```raku
# mytools.rakumod
use Rakuish::Command;
use Rakuish::Result;

BuiltinCommand.new(
    :cmd-name<hello>,
    :summary('示例插件：向指定的人打招呼'),
    :params(
        ParamSpec.new(:name<who>, :type<string>),
    ),
    :handler(-> $sys, *@args, *%opts {
        my Str $who = @args.elems ?? @args[0].Str !! 'world';
        Result.new(:ok, :op<hello>, :out("hello, $who"), :value($who));
    }),
)
```

加载后，`hello` 就和内建命令一样出现在 `help()` 与 `registry.names` 里。

**关键点**

- 文件最后一个表达式必须是 `Command` 对象，或 `List[Command]`（一次注册多个）。
- `:cmd-name` 是调用名；`name` 方法由它提供。
- `handler` 的第一个参数是**会话的 `Sys`**，文件 / 进程操作必须走它，不要
  自己 `shell` 或直接 `IO`。
- `:params` 只是 schema，用来生成 JSON Schema / 帮助；`run` 收到的是原始参数。

### 11.3 一次注册多个命令

```raku
use Rakuish::Command;
use Rakuish::Result;

my $hello = BuiltinCommand.new(
    :cmd-name<hello>,
    :summary('打招呼'),
    :handler(-> $sys, *@a, *%o { Result.new(:ok, :out('hello')) }),
);

my $lines = BuiltinCommand.new(
    :cmd-name<count-lines>,
    :summary('数文件行数'),
    :params(ParamSpec.new(:name<path>, :type<path>, :required)),
    :handler(-> $sys, *@args, *%opts {
        my Str $path = @args[0].Str;
        my $text = $sys.read($path);
        Result.new(:ok, :op<count-lines>, :value($text.lines.elems));
    }),
);

($hello, $lines)          # List[Command]
```

### 11.4 加载、查看、卸载

```bash
plugin load ./mytools.rakumod
plugin list
plugin info mytools.rakumod
plugin unload mytools.rakumod
```

`plugin list` 是一张表：

```text
name                 commands              path
mytools.rakumod      hello, count-lines    C:/work/mytools.rakumod
```

**关键点**

- 插件名就是**文件名**（含扩展名），不是文件里声明的名字。
- 扩展名只接受 `.rakumod` / `.raku`；路径经 `Sys.resolve` 做 root 校验。
- 同一个文件重复 `load` 会先卸掉旧命令再重新注册，适合边改边试。
- `unload` 只移除这个插件注册的命令，不碰内建或其它插件。

### 11.5 从会话里调用

插件命令不走 Shell 薄层的文本命令表，而是走 `CommandRegistry`：

```raku
registry.run('hello', sys, 'Ada')
# => Result(ok=True, out="hello, Ada", value="Ada")

registry.run('count-lines', sys, 'README.md').value
```

也可以先看它注册了什么：

```raku
registry.names
registry.get('hello').spec.to-hash
help()                    # 帮助里会带上插件命令
```

**关键点**

- `registry.run` 的参数是结构化的：命令名、`Sys`、位置参数、命名选项。
- 想从脚本里用同一套命令，先 `plugin load`（脚本里也能调 Shell 命令），
  再 `registry.run`；或者干脆写成普通 `sub`，别为一次性需求写插件。

### 11.6 冲突与生命周期

| 情况 | 结果 |
|---|---|
| 命令名和内建重名 | 409，整个插件不加载 |
| 命令名和别的插件重名 | 409 |
| 路径越出会话根 | 403 |
| 文件不存在 | 失败，提示路径 |
| 求值报错 | 失败，附带插件里 `say` 的输出 |
| 插件文件返回的不是 `Command` | 失败，提示必须返回 `Command` 或 `List[Command]` |

**关键点**

- 插件**不持久化**：下次打开 REPL 要重新 `plugin load`。想自动加载就写进
  `rc.raku`（同样只放可信路径）。
- 插件注册的是命令对象，不是别名；不要指望 `alias` 能展开它。
- 插件里不要依赖会话里的 `my` 变量——它拿到的只有 `$sys`。

### 11.7 什么时候该写插件

- **该写**：一组带参数、要跨格复用、希望出现在 `help()` 里的操作。
- **不该写**：一次性的数据清洗（直接写 Raku）；完整自动化流程（写
  `sub MAIN` 脚本，见第 8 章）；只是想少打几个字（用 `alias`）。

---

## 12. 常见坑与排错表

### 12.1 输入与分词

| 现象 | 原因 | 改法 |
|---|---|---|
| `Undeclared routine: tmp` | 非 `!` 行里写了裸路径 `tmp/a.csv` | 路径加引号：`"tmp/a.csv"` |
| `!` 后面的 `>` 没重定向 | `!` 只做 argv 分词，不是 shell | 用 `sys.exec` 的 `:on-out`，或写 Raku 落盘 |
| `! echo $HOME` 打出字面量 | `!` 不做变量展开 | 用 `sys.exec('echo', $*HOME)`，或写 Raku 表达式 |
| `! a && b` 报错 | 不认 `&&` | 分两次调用，按 `ok` 判断 |
| `! cat a.txt` 退出码 127 | Windows 没有 `cat.exe` | 不带 `!` 写 `cat a.txt`（Shell 薄层），或 `read("a.txt")` |
| 管道没切开 | `\|` 在引号里，或不在顶层 | 只在顶层、引号外切；需要字面量 `\|` 就转义 |

### 12.2 文件

| 现象 | 原因 | 改法 |
|---|---|---|
| 读到的内容被截断 | `read` 默认上限 1 MiB | `read($p, :max-bytes(10_000_000))` 或 `read-lines` |
| 二进制读成乱码 | 默认按 UTF-8 文本读 | `read($p, :bin)` |
| `cp` / `mv` 报已存在 | 默认**不覆盖** | 显式 `:overwrite`，或先 `rm` |
| `write` 把文件写坏一半 | 默认原子写，但目标目录不存在 | 加 `:mkdir` |
| 想追加却整份覆盖 | 没加 `:append` | `write($p, $s, :append)` |
| 路径越界异常 | 解析后跑出会话根 | 用会话内相对路径；确实要外部路径时改工作目录 |
| 并发写冲突 | 两个进程同时写同一文件 | `with-lock($p, { ... })` |

### 12.3 外部命令与管道

| 现象 | 原因 | 改法 |
|---|---|---|
| 超时退出码 124 | 触发了默认总超时 | 加 `--timeout-ms N`，或 `--no-timeout` |
| 启动失败 127 | exe 不在 PATH | 用绝对路径，或改用 Shell 薄层命令 |
| 取消退出码 137 | 被 `sys.cancel` / Ctrl-C 终止 | 正常现象，按 137 处理 |
| `--pipe` 之后拿不到 `Result.out` | 末段直写终端、不捕获 | 要捕获就别用 `--pipe` |
| `--pipefail` 没生效 | 只看**最右**非零退出码 | 需要逐段判断就拆成多次 `exec` |
| `--stdin` 只喂了第一段 | 设计如此，只接首段 stdin | 中间段要输入就自己在 Raku 里写 |
| `:env` 之后环境变量全没了 | `:env` 是**整份替换**，不是合并 | 先取 `env()`，合并后再传 |
| 子进程读不到输出 | 用了 `:on-out` 却还等 `Result.out` | 回调式输出不落 `Result`，二选一 |
| `--tty` 在 notebook / 无终端环境里 127 | 没有真终端或父进程执行器 | 回 REPL 用，或改成非交互程序 |
| `-e` 里 `! --tty` 被拒 | 单行模式把 `$*OUT` 换成了捕获缓冲 | 用 `run(...)`，或见 12.8 的 `temp $*OUT = $*ERR` |

### 12.4 数据

| 现象 | 原因 | 改法 |
|---|---|---|
| JSON 对象读出来是 `Hash` 不是 `Table` | `open-data` 按顶层形状决定：对象 → Hash，对象数组 → Table | 取值后 `Table.from-rows(...)` |
| 表格列为空 | `Table.new(:rows)` 没给 `:columns` | 用 `Table.from-rows(@rows)`，或同时给 `:columns` / `:rows` |
| `sort-by` 的 `:desc` 无效 | 命名参数是 `:reverse` | `sort-by('size', :reverse)` |
| `join` 之后列名撞车 | 默认加后缀 | 用 `:suffix` 区分 |
| 第二次遍历 `stream` 是空的 | Stream 一次性 | 需要多次就用 `Table` / 数组 |
| 大文件把内存吃满 | 文件来源的 `stream` 会**整份读入** | 真流式用 `open-db(...).cursor` 或 `IO.lines` |
| CSV 少一列 / 多一列 | 方言不对 | 用 `:%csv-options` 指定 delimiter / header / skip 等 |
| 读 `.parquet` / `.pq` 被拒绝 | Parquet 走外部引擎，必须显式允许 | `open-data($p, :allow-external)`（读会话根外的 CSV 同理） |

### 12.5 SQL

| 现象 | 原因 | 改法 |
|---|---|---|
| `open-db` 写不进去 | 默认 `:read-only(True)` | `open-db($p, :read-only(False))` |
| 找不到 DuckDB | 驱动是可选依赖 | 换 `:engine<sqlite>`，或安装 DuckDB 驱动 |
| DuckDB 查询一直跑 | 没设超时 | 构造时给 `max-execution-time-ms` |
| `:memory:` 两张表互相看不见 | 内存库按连接隔离 | 用同一个 `$db`，或落到临时文件 |
| 事务没生效 | 没在 `begin` / `commit` 之间 | 显式 `begin` → `execute` → `commit`，失败 `rollback` |
| Cursor 第二次读是空的 | Cursor 一次性 | 重新 `query` / `cursor` |
| `Table.sql` 找不到表 | 表名不是 `t` | 传 `:name<your_table>`，或用多表 `sql({...}, ...)` |
| 外部文件读不了 | `:safe(True)` 禁止 | 明确 `:safe(False)`，只对你信任的路径 |

### 12.6 会话、脚本、notebook、插件

| 现象 | 原因 | 改法 |
|---|---|---|
| 新会话变量没了 | 快照只恢复**成功格**的状态，不恢复连接 / 闭包 / 句柄 | 用 `store` 存值，或写 `rc.raku` |
| `store` 拒绝某个变量 | 句柄、Sub、Lock 等不可序列化 | 只存数据；连接在脚本里重建 |
| 换个目录后历史 / 快照不对 | 快照按 cwd 指纹分文件 | 在目标目录重开会话，或显式 `cd` |
| `~/.rakuishrc` 没生效 | 配置文件叫 `rc.raku` | 用 `RAKUISH_RC` 指定，或放默认位置 |
| 表达式里写 `exit` 后会话重启 | `exit` 结束的是引擎进程 | 退出 REPL 单独写 `exit`，别在格中间写 |
| notebook 里 `input()` 卡住 / 失败 | 自带 Jupyter 桥没接 stdin | 改成参数或读文件 |
| 中断后变量全丢 | 中断 = 重启引擎 | 重要状态先 `store` / 落盘 |
| `plugin load` 返回 403 | 插件默认关闭 | `config set plugins on` |
| 插件命令名冲突 409 | 与内建或其它插件重名 | 换名，或先卸载旧插件 |
| 脚本里 `open-data` 参数错 | 脚本预加载的是 DSL 版（无 `$sys`） | 直接用 `open-data("a.csv")`，不要传 `sys` |

### 12.7 几个最容易被误判的报错

**`Undeclared routine: tmp`**

不是「没有这个命令」，而是把路径当成了函数调用。Raku 表达式里字符串必须加引号：

```raku
save-data(tmp/a.csv, $t)      # 错：解析成 tmp 除以 a.csv
save-data("tmp/a.csv", $t)    # 对
```

**退出码 124 不是「程序失败」**

它是 Rakuish 自己的超时码。看到 124 先看命令是不是本来就要跑很久，再决定
放宽 `--timeout-ms` 还是加 `--no-timeout`。

**`X::Rakuish::Bound`**

路径解析后跑出了会话工作目录。这不是安全沙箱，是防误操作边界：先 `cd` 到
目标目录，或把文件放进当前根下。

**notebook 里「引擎已重启」**

通常是格子里写了 `exit`，或者中断了一个正在跑的格。重启后 `my` 变量、打开的
数据库连接都没了；前端会收到 `engine: restart` 帧，不是普通报错。

### 12.8 `!` 与 `tty-exec`：换个入口就换规则

`!` 只在**交互式 REPL**、`rakuish -e`、以及 REPL 里的 `source` 中生效。
`rakuish foo.raku` 的整份源码是一个普通 Raku 程序，`!` 不参与分发 —— 写了
只会得到「未声明例程」一类的编译错误，要直通终端请直接调 `tty-exec(...)`。

| 入口 | `! cmd` | `! --tty cmd` | `tty-exec(...)` |
|---|---|---|---|
| 交互式 REPL | 可以 | 可以（引擎子进程下由父进程执行） | 可以 |
| `rakuish -e '...'` | 可以 | **被拒** | **被拒**（守卫） |
| `rakuish foo.raku` | 不识别 | 不识别 | 可以（真终端下） |
| notebook / 管道 / 重定向 | 可以 | 127 / 被拒 | 被拒 |

`-e` 被拒不是 bug：单行模式为了打印 `Out[1]` 会把 `$*OUT` 临时换成捕获缓冲，
而 `tty-exec` 的守卫要求 stdin 与 stdout 都是真终端。要么绕开它，要么在格内
把 stdout 换回一个真句柄。

**变通一：用 `run`（最简单，跨平台）**

```powershell
rakuish -e 'run("vim", "notes.md")'
rakuish -e 'my $p = run("less", "big.log"); note "exit=", $p.exitcode'
```

`run` 不经过 `$*OUT`，子进程直接继承 OS 的 fd 0/1/2，`-e` 的捕获对它无效。
代价是没有 `tty-exec` 的附加保障：不存/还原宿主 termios，POSIX 上不切前台
进程组（Ctrl-C 会一起打到 rakuish）。

**变通二：借 `$*ERR` 过守卫，保留 `tty-exec` 语义**

`-e` 只捕获 `$*OUT`，从不碰 `$*ERR`；把 `$*OUT` 临时指到 `$*ERR` 即可：

```powershell
rakuish -e 'temp $*OUT = $*ERR; tty-exec("vim", "notes.md").code.say'
```

POSIX 上 posix_spawn 分支根本不读 `$*OUT`；Windows 上 `tty-exec` 会把子进程
stdout 绑到 `$*ERR` 的真句柄，仍是同一块控制台。termios 快照、Ctrl-C 隔离
这些能力都保留。

**不要伪造 `.t`**：给假句柄只实现 `t` / `flush` 看似能过守卫，但 Windows 上
`tty-exec` 会拿它去 `bind-stdout`，得到「TTY 绑定失败」，比原始报错更难懂。

**边界**：两个变通都要求 `$*IN` 是真终端，`rakuish -e '...' < file` 一律拒绝；
`$*ERR` 被重定向时变通二同样失败。真能落文件的话，`rakuish foo.raku` 里直接
写 `tty-exec("vim", "notes.md")` 最省事。

---

## 13. 速查表

### 13.1 REPL 常用命令

| 命令 | 作用 |
|---|---|
| `help` / `help NAME` | 命令与函数帮助 |
| `NAME?` / `doc NAME` | 快速查文档（零 EVAL，看不到跨格 `my`） |
| `which NAME` | 这个名字解析到什么 |
| `history` / `history 20` | 输入历史 |
| `rerun N` / `recall N` | 重跑 / 预填第 N 格 |
| `!!` / `!$` / `!n` | 历史展开（`set +o histexpand` 可关） |
| `who` / `who -l` | 当前会话里绑定了什么 |
| `log` / `audit` / `audit --origin` | 执行日志 / 审计 / 按来源分账 |
| `cells --text -` | 把会话导出成脚本文本 |
| `source FILE` | 在当前会话里执行文件 |
| `paste` | 多行粘贴，单独一行 `--` 结束 |
| `store` / `store -r NAME` / `store -l` | 跨会话变量库 |
| `config` / `config set K V` | 配置 |
| `alias` / `hook` | 别名 / 启动钩子 |
| `set -o` / `set +o` | 会话选项（errexit / noglob / noexpand / xtrace） |
| `errors` / `hint` / `perf` | 错误分级 / 提示 / 耗时 |
| `tb` / `debug` / `repl.bt` | 回放失败格的异常 / 开关异常记录 |

### 13.2 `!` 的旗标与退出码

| 写法 | 作用 |
|---|---|
| `! cmd arg...` | argv 执行，返回 `Result` |
| `! a \| b` | 顶层管道，逐段执行 |
| `! --pipe a \| b` | 末段直写终端，不捕获、无总超时 |
| `! --pipefail a \| b` | 取最右非零退出码 |
| `! --stdin FILE a \| b` | 把文件接到首段 stdin |
| `! --capture a \| b` | 管道结果全部捕获（默认行为） |
| `! --timeout-ms N a \| b` | 设总超时 |
| `! --no-timeout a \| b` | 关总超时 |
| `! --tty prog` | 在父进程的真终端里跑，不捕获 |

| 退出码 | 含义 |
|---|---|
| `0` | 成功 |
| `1` | 程序自身失败 / Raku 异常 |
| `124` | Rakuish 超时 |
| `127` | 启动失败（exe 不存在） |
| `137` | 被取消 / 中断 |

### 13.3 文件 API

| 调用 | 说明 |
|---|---|
| `ls` / `ls-table` | 列目录（`ls-table` 直接给表） |
| `glob('**/*.raku')` | 通配查找 |
| `recent(7, 'csv')` / `recent(7, 'csv', :path('.'))` | 最近修改的文件 |
| `read($p)` | 读文本，默认上限 1 MiB |
| `read($p, :max-bytes(N))` / `:bin` / `:enc` | 放宽上限 / 二进制 / 指定编码 |
| `read-lines($p, :head(10))` / `:tail(10)` | 首 / 尾若干行 |
| `write($p, $s)` | 原子写；`:append` / `:mkdir` / `:backup` / `:max-bytes` |
| `cp($a, $b)` / `mv($a, $b)` | 默认不覆盖；`:overwrite` |
| `rm($p)` | 删除 |
| `stat($p)` | 大小、类型、权限 |
| `with-lock($p, { ... })` | 文件锁 |

### 13.4 进程 API

| 调用 | 说明 |
|---|---|
| `exec($exe, |@args, :$env, :$cwd, :$in, :$in-chunks, :$stdin-file, :$on-out, :$on-err, :$timeout-ms)` | 同步执行 |
| `spawn(...)` | 后台起进程，返回句柄 |
| `sys.jobs` / `sys.wait($h)` / `sys.cancel($h)` / `sys.job($id)` | 作业管理 |
| `bg-exec(...)` / `fg` / `bg` / `bg-jobs` | 真终端作业（POSIX） |
| `pty-exec(...)` | PTY 执行（POSIX，Rakudo ≥ 2025.12） |

### 13.5 数据 API

| 调用 | 说明 |
|---|---|
| `open-data($p)` | JSON / CSV / TSV / Parquet → Hash 或 Table |
| `open-data($p, :raw)` / `:allow-external` / `:%csv-options` | 原始文本 / 允许外部路径 / 方言 |
| `save-data($p, $v)` | 按扩展名写（`:pretty` / `:batch-size` / `:%csv-options`） |
| `Table.from-rows(@rows)` | 行数组 → 表 |
| `where` / `select` / `sort-by(:reverse)` / `limit` / `offset` | 查询链 |
| `first` / `last` / `distinct` / `each` / `count` | 取行与遍历 |
| `sum` / `mean` / `min` / `max` | 聚合 |
| `join($other, :on, :how, :suffix)` | 连接 |
| `zip` / `append` / `interleave` / `tee` | 组合 |
| `describe` | 列统计 |
| `to-text` / `to-json` / `to-markdown` / `to-csv` | 导出 |

### 13.6 Stream

| 调用 | 说明 |
|---|---|
| `stream($x)` | 文本 / 文件 / Result / Table → 记录流 |
| `stream($x, :format<lines\|csv\|tsv\|json\|jsonl\|pattern>)` | 指定解析方式 |
| `:pattern(/.../)` / `:@names` / `:%csv-options` | 正则、列名、CSV 方言 |
| `where` / `map` / `limit` / `each` / `count` | 流式处理 |
| `rows` / `column` / `lines` / `text` / `json` / `csv` / `table` | 出口 |
| `first-row` / `sum` / `mean` / `min` / `max` | 聚合出口 |
| `exec` / `tee` / `zip` / `join` / `interleave` / `append` | 组合出口 |

### 13.7 SQL

| 调用 | 说明 |
|---|---|
| `open-db($p)` | 默认 DuckDB、只读、`:memory:` |
| `open-db($p, :engine<sqlite>)` / `:read-only(False)` / `:safe(False)` | 换引擎 / 可写 / 允许外部文件 |
| `$db.query('select ...')` | 参数化查询 → Table |
| `$db.execute('insert ...')` | 执行写操作 → Result |
| `$db.tables` / `$db.schema` / `$db.describe('t')` | 元数据 |
| `$db.cursor('select ...', :batch-size(1000))` | 流式游标 |
| `$db.batches(...)` / `$db.take(N)` | 分批取 |
| `$db.begin` / `$db.commit` / `$db.rollback` | 事务 |
| `$db.close` | 关闭 |
| `sql($t, 'select ...')` / `sql({ a => $t1, b => $t2 }, '...')` | 表当临时表直接查 |
| `$t.sql('select ...', :name<...>)` | 表格方法形态 |

### 13.8 脚本与会话

| 调用 | 说明 |
|---|---|
| `rakuish file.raku args...` | 脚本模式，预加载 DSL |
| `sub MAIN(...)` / `multi MAIN` | 参数分派与 `--help` |
| `source FILE` | 在当前会话执行 |
| `cells --text -` / `cells --json -` | 导出会话 |
| `peach @items, { ... }` | 并行 map |
| `timed { ... }` / `timed(:repeat(10)) { ... }` | 计时 |
| `bench { ... }` / `perf` | 基准 / 最近耗时 |
| `exec(...).elapsed` | 单次外部命令的墙钟 |
| `try-op('op', { ... })` | 把异常收敛成 `Result` |
| `store NAME` / `store -r NAME` | 跨会话存取 |
| `RAKUISH_SNAPSHOT` / `RAKUISH_NO_SNAPSHOT` / `RAKUISH_SNAPSHOT_MAX` | 快照控制 |
| `RAKUISH_RC` / `RAKUISH_NO_RC` | rc 文件控制 |

### 13.9 Notebook 与插件

| 调用 | 说明 |
|---|---|
| `rakuish-notebook` | 一行一 JSON 的协议入口 |
| `{"op":"execute","code":"1+1"}` | 跑一格 |
| `{"event":"busy"}` / `{"event":"idle"}` / `{"event":"engine"}` | 推送帧 |
| `display($v)` | 格内立即显示，不改 `_` |
| `python tools/jupyter/install_kernel.py` | 安装 Jupyter kernelspec |
| `python tools/jupyter/smoke.py` | 端到端自检 |
| `config set plugins on` | 允许加载本地插件 |
| `plugin load PATH` / `list` / `info NAME` / `unload NAME` | 插件管理 |
| `registry.run('cmd', sys, ...)` | 调用插件 / 注册表命令 |

---

到这里，日常使用 Rakuish 的主要路径都覆盖了。遇到本书没写的细节，先查
[`MANUAL.md`](MANUAL.md) 的对应章节，再看 [`SPEC.md`](../SPEC.md) 的条款；
两者冲突时以 SPEC 为准。
