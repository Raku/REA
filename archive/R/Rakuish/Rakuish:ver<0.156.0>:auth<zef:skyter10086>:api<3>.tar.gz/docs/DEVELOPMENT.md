# Rakuish 完整开发文档

- **版本**：0.145.0（API v3，协议 v2）
- **日期**：2026-11-27
- **对象**：接手开发者、长期维护者、想理解「为什么是现在这样」的人
- **定位**：本文是**开发视角**的总文档。用户视角看 [`MANUAL.md`](MANUAL.md)；条款真值看 [`SPEC.md`](../SPEC.md)；决策原文看 [`ADR-INDEX.md`](ADR-INDEX.md) 与各 ADR。

> 阅读顺序建议：
> 只想改一个功能 → §5 对应小节 + §8.2；
> 刚接手 → §1 → §2 → §3 → §4 → §7 → §8；
> 想推翻某个设计 → 先读 §6 和对应的 ADR，那里记录了「为什么没选另一条路」。

**本文的事实口径**：0.145.0 的仓库状态。测试 79 个 `.t`、Windows 侧 3791 条断言；模块 `provides` 47 项；ADR 59 份（0001–0059）。数值若与代码冲突，以代码和 `SPEC.md` 为准，并请顺手修正本文。

---

## 目录

1. [项目定位与设计哲学](#1-项目定位与设计哲学)
2. [总体架构](#2-总体架构)
3. [进程模型与线协议](#3-进程模型与线协议)
4. [求值内核](#4-求值内核)
5. [功能实现与使用手册](#5-功能实现与使用手册)
6. [方案选型：为什么是这套架构](#6-方案选型为什么是这套架构)
7. [走过的弯路与踩过的坑](#7-走过的弯路与踩过的坑)
8. [开发指南](#8-开发指南)
9. [附录](#9-附录)

---

## 1. 项目定位与设计哲学

### 1.1 一句话

Rakuish 是一个 **Raku 原生的命令、脚本与数据环境**：一个 REPL，加上一套可编程的系统/数据 API。命令行输入只有两种显式形态——**Raku 表达式**，或 **`!` 开头的 argv 命令**。没有 bash 子集，没有 `%magic`，没有第二套语法。

它**不是**：

- 不是 bash/POSIX 兼容层，也不是「Raku 写的 shell 模拟器」；
- 不是沙箱、不是 Agent 服务、不是远程执行网关（Agent 线 0.81.0 已整体删除）；
- 不是多后端运行时（只支持标准 Rakudo/MoarVM，ADR-0046）。

### 1.2 六条设计哲学

| # | 原则 | 具体表现 | 反面教材 |
|---|---|---|---|
| 1 | **入口不猜** | `!` 才是外部命令；不带 `!` 的 `ls`/`cat` 是 Rakuish 自己实现的内置命令；其余一律 Raku | v1 的 auto-shell 会把「看起来像命令」的输入交给 shell，语义不可预测 |
| 2 | **单一语义** | 只有 Raku 一种语言；`Sys` 一种系统出口；`Result` 一种结果形态 | v2 双栈：两套语言、两套执行栈，修 A 坏 B |
| 3 | **不重放副作用** | 跨格持久靠声明与纯值，绝不重跑历史语句 | 重放 `rm`/写文件会重复执行，不可幂等 |
| 4 | **一切结果皆 `Result`** | `ok/code/out/err/value`；失败不抛（显式 `cmd()` 才抛）；可渲染为 text/json/markdown | 每个命令各返回一种形状，脚本无法统一处理 |
| 5 | **边界只有一个写点** | 文件/进程只过 `Sys`；前端只调 `Kernel.execute`；审计只走 `Audit.record`；命令名只在 `COMMAND-GROUPS` 声明 | 多处登记必然漂移（`hint`/`plugin` 曾经 Tab 补不出来） |
| 6 | **诚实的失败** | 崩溃如实说「状态丢了」；超时是 124、启动失败 127、取消 137；不支持的能力明确 501/127，不假装能用 | 把中断报成崩溃；把「打开就安全」当安全 |

### 1.3 「本地、全权限」的含义

ADR-0019 之后，**没有权限闸门**：Raku 源码直接 `EVAL`，`!` 直接起进程。`Policy` 只剩三个真有执行点的字段：`profile`、`allow-source`、`root`（ADR-0020）。审计仍然保留，但它是**记录**，不是**阻止**——不要把审计误读成沙箱。

---

## 2. 总体架构

### 2.1 一张图

```text
                       ┌──────────────────────── 父进程（持终端）────────────────────────┐
bin/rakuish → Rakuish::CLI
   │                   │  行编辑 / prompt / banner / 补全 UI / 高亮 / 键位            │
   │                   │  Kernel.execute(Request) → Result → 渲染 / 分页 / 审计        │
   │  TTY              │  `! --tty` 的真实执行、`! --tty a | b` 整条管道               │
   ├──────────────► Rakuish::Eval::Proxy  ── 冒充 REPL::Session，前端不感知进程边界   │
   │                   │        │                                                       │
   │                   │        │  JSON 帧（一行一帧，串行）                            │
   │                   │        ▼                                                       │
   │                   │  Rakuish::Eval::Client ──────────┐                            │
   └───────────────────┴──────────────────────────────────┼────────────────────────────┘
                                                          │ stdin/stdout 管道
                       ┌──────────────────────────────────▼────────────────────────────┐
                       │ 引擎子进程：bin/rakuish --engine（Rakuish::Eval::Server）    │
                       │   Rakuish::REPL::Session（真正的求值器）                     │
                       │     ├─ 输入分类：会话命令 / 历史替换 / `!` / Shell 薄层 / Raku│
                       │     ├─ 当前格 EVAL + 顶层状态扫描 + prelude 裁剪             │
                       │     ├─ rc / prompt / set -o                                  │
                       │     └─ Sys / Data / Display / Snapshot                       │
                       └──────────────────────────────────────────────────────────────┘

非 TTY：`-e` / 脚本 / 管道 → 进程内直接 Kernel.execute → Session.eval-line（不起子进程）
```

### 2.2 为什么是「父进程 + 引擎子进程」

同进程 `EVAL` 有三个无解问题（ADR-0021）：

1. 用户敲 `exit` → 整个 REPL 退出；
2. MoarVM 段错误 → 会话全灭；
3. `while 1 {}` → Raku 线程无法强杀，Ctrl-C 收不到。

把求值放进 `raku` 子进程后，这三件事只带走引擎：父进程的行编辑、渲染、审计、作业表都活着；随后重启引擎并从快照恢复。代价是**协议与串行化**——所有跨进程能力都必须设计成帧。

交互式终端里 `! --tty` 不走引擎：终端 stdin 是协议流，子进程不能用它当键盘。这类能力交回父进程执行。

### 2.3 分层职责

| 层 | 模块 | 职责 | 不该做的事 |
|---|---|---|---|
| 入口 | `CLI`、`bin/rakuish` | 解析 `-e`/脚本/REPL，装配 Kernel、审计、终端 | 不实现求值语义 |
| 前端 | `REPL::Chrome`、`Keymap`、`Highlight`、`Hints`、`Complete`、`Plugins`、`Data::Pager` | 展示、键位、补全、分页 | 不碰文件/进程 |
| 门面 | `Eval::Proxy` | 让 Kernel 以为在跟本地 Session 说话 | 不解析输入 |
| 协议 | `Eval::Protocol`、`Eval::Client`、`Eval::Server` | 帧校验、请求/响应、崩溃检测 | 不决定业务语义 |
| 内核 | `Kernel`、`Kernel::Factory`、`Kernel::Notebook` | 唯一执行入口、Request/Policy、审计落点 | 不做输入分类之外的业务 |
| 会话 | `REPL::Session` | 输入分类、EVAL、状态扫描、渲染、历史、配置 | 不直接 `spurt` / `Proc::Async` |
| 薄层 | `REPL::Shell`、`DSL` | shell 观感命令、短函数 | 不另建一套系统 API |
| 系统 | `Sys`、`Sys::FS`、`Sys::Proc`、`Sys::JobTable`、`Sys::PosixSpawn`、`Sys::WinJob`、`Sys::Console`、`Sys::Term` | 唯一文件/进程出口、平台差异 | 不打印、不决定展示 |
| 数据 | `Data`、`Data::Table`、`Data::Stream`、`Data::Cursor`、`Data::Engine*`、`Data::Arrow`、`Data::Duck`、`Data::CsvOptions`、`Data::Pager` | 结构化值、惰性流、SQL、格式 | 不绕过 `Sys` 的 root 校验 |
| 结果 | `Result`、`Result::Renderer`、`Display` | 统一值形态、多格式、MIME 档 | 不在数据层掺 ANSI |
| 持久化 | `Snapshot`、`Store`、`Audit` | 崩溃恢复、跨会话变量、账本 | 不序列化闭包/资源 |

### 2.4 五条边界（改动前先看）

1. **文件/进程只过 `Sys`**：不是为了安全，而是为了审计单点、`Result` 语义一致、root 边界与超时/上限只有一套实现。
2. **前端只调 `Kernel.execute(Request)`**：不直接调 `Session.eval-line`（V-182）；`Policy` 由内核强制，前端只能收窄（V-183）。
3. **外部命令只接 argv**：永不拼 shell 字符串。唯一例外是 `!` 的 Windows cmd 内建白名单（固定集合、逐 token 转义，ADR-0049）。
4. **显示分两层**：`Display::Bundle` 管**内容**（text + markdown/json/html），`Session.render` 管**装饰**（颜色、`Out[n]`、分列）。混在一起会让 bundle 退化成 TTY 专用。
5. **审计只有一个写入函数**：`Audit.record`，Kernel 在 `LEAVE` 里调用（正常/拒绝/异常都恰好一条）。`Audit`（安全账本）、`log-line`（人读抄本）、`trail`（调试）、`display`（内容）四者刻意不合并（V-196）。

### 2.5 一次输入的一生（TTY 路径）

```text
用户按键
  → Keymap/LineEditor 编辑缓冲区（高亮、灰字建议、菜单）
  → Enter
  → Proxy.eval-line(text)
  → Client.request({op:eval, code, color, tty, width, height, ...})
  → Server 读帧、校验、调用 Session.eval-line
      ├─ 会话命令（config/alias/hook/log/store/cells/errors/...）
      ├─ 历史替换（!! / !n / !$）
      ├─ `!` argv（元选项、顶层 |、流式 chunk 回传）
      ├─ Shell 薄层（ls/cd/cat/...）
      ├─ exit → 退出请求
      ├─ 不完整 → op=more（继续续行）
      └─ Raku → 扫描声明 → prelude → EVAL → 快照 → Result
  → 回帧（ok/code/text/index/streamed/...）
  → Proxy 包成 Result（失败/中断/引擎死亡在父侧归因）
  → 父进程渲染（颜色、Out[n]、分页） + 审计 + 历史 + 会话日志
```

注意：**引擎的 stdout 是协议流**，任何打印都必须走帧；这正是「引擎里不许分页」的原因（0.89 事故）。

---

## 3. 进程模型与线协议

### 3.1 启动矩阵

| 调用方式 | 是否起引擎子进程 | 谁持有终端 | 说明 |
|---|---|---|---|
| `rakuish`（stdin 是 TTY） | 是 | 父进程 | 完整 REPL；`! --tty` 由父执行 |
| `rakuish`（stdin 是管道） | 否 | 无 | 逐行求值，无 banner/prompt/ANSI |
| `rakuish -e '...'` | 否 | 无 | 单次求值后退出 |
| `rakuish script.raku a b` | 否 | 无 | 整份源码一个 cell；`@*ARGS`；末尾交给 `RUN-MAIN` |
| `rakuish-notebook` | 进程内 Session | 无 | 一行一 JSON；无终端能力 |
| 引擎自举 | — | — | `Eval::Client` 以 `--engine` 起 `raku` 子进程 |

### 3.2 帧格式

- 传输：stdin/stdout 各一行一条 JSON（NDJSON），UTF-8。
- 请求帧：`{"op": "...", ...}`；响应帧：同一 `op` + `ok/code/...`。
- 中间帧：`{"op":"chunk"|"tty"|"pipe-exec"|"job"|"input"|"error_info"|"child", ...}`，由引擎在**处理当前请求期间**插入；父侧 `Client` 在等待响应时按帧类型分发。
- 串行：一个请求处理完才处理下一个；中间帧属于当前请求。没有多路复用，也不需要锁。
- 版本：`PROTOCOL-VERSION = 2`。0.144 新增 `pipe-exec` 中间帧时**没有升版本**，因为它是纯增量、旧父进程不会发也不会收到；破坏性变更才升。

`EvalReply` 的主要字段：`seq/op/ok/code/text/out/err/index/cwd/elapsed/exit/hint/streamed/no-newline`，以及 `error-info`（结构化错误）。

### 3.3 请求 op 一览

| op | 方向 | 作用 | 备注 |
|---|---|---|---|
| `eval` | 父→引擎 | 求值一格 | 带 `color/tty/width/height/want-display` 等终端事实 |
| `complete` | 父→引擎 | 补全候选 | 整行替换语义（`cursor_start=0`，ADR-0037） |
| `inspect` | 父→引擎 | `名字?` 内省 | 复用 REPL 的内省实现 |
| `history` | 父→引擎 | 取历史 | notebook/`recall` 用 |
| `key` | 父→引擎 | 处理一个按键 | 行编辑器的可编程钩子 |
| `info` | 父→引擎 | 引擎状态 | pid、cwd、格号、重启次数、协议版本 |
| `rc` | 父→引擎 | 执行启动文件 | 逐格执行，不占 `Out[n]` |
| `shutdown` | 父→引擎 | 优雅退出 | 引擎侧收尾后退出 |
| `input-reply` | 父→引擎 | 回填 `input()` | notebook/交互输入通道 |

### 3.4 引擎 → 父进程的中间帧

| 帧 | 何时 | 用途 | 处理方 |
|---|---|---|---|
| `chunk` | `!` 边跑边出 | stdout/stderr 文本块 | 父进程立即写终端；`Result.streamed=True`，结束不重放 |
| `tty` | `! --tty` 单命令 | 请求父进程真正执行 | `Proxy` 交 CLI 的 tty 执行器 |
| `pipe-exec` | `! --tty a \| b` | 请求父进程执行整条管道 | 父进程用 `Sys.pipe-exec`；末段输出作为响应回传 |
| `job` | `bg-exec/fg/bg/bg-jobs/tail -f` | 作业表在父进程 | 父侧 `JobTable` + `PosixSpawn` |
| `input` | 引擎需要键盘 | 向父进程要一行输入 | 父侧行编辑器 |
| `child` | 引擎启动外部命令后 | 上报子进程 pid | 父进程把该 pid 收进命令级 Job Object（Windows Ctrl-C 只收命令） |
| `error_info` | 失败格 | 结构化错误（类型/位置/帧） | 父侧存 `last-error-info`，`errors full` / notebook 使用 |

### 3.5 崩溃、重启、快照恢复

```text
父进程等响应
  ├─ 收到正常响应 → 继续
  ├─ 等到 EOF / 心跳失败 → 引擎死亡
  │    → Proxy 标 revived，Client.restart
  │    → 新引擎启动 → 读快照 → 重放 @!decls 与纯值 → 重跑 rc
  │    → 下一格开头如实提示「引擎已重启，状态已恢复 N 项 / 丢失 M 项」
  └─ 等待期间 Ctrl-C → Client 接管 SIGINT → kill 引擎
       → 归因 op=interrupted, code=130（不是「引擎崩溃」）
       → 重启 + 快照恢复；清行编辑器的 take-interrupt 标志
```

快照**只重放声明与可序列化纯值**，语句格不重放（副作用不幂等）。资源（文件句柄、DB 连接）、闭包、超过 `RAKUISH_SNAPSHOT_MAX` 的值明确标失效（ADR-0022）。

### 3.6 协议纪律

- 所有帧先过 `check-frame` / `check-error-info`；字段白名单，未知字段不静默透传。
- 引擎侧任何用户输出不得直接写 stdout，只能 `emit`。
- 新增中间帧：先改 `Protocol`，再改 `Server`（发）与 `Client`（收），最后补 `t/41`（协议）与功能测试。
- 不承诺向后兼容旧协议；同版本内只做增量。

## 4. 求值内核

核心实现集中在 `Rakuish::REPL::Session`（约 3900 行）。读懂下面五件事，基本就能改它。

### 4.1 输入分类（严格顺序）

`Session.eval-line` 不是「先试 Raku，失败再试 shell」，而是一个有序分派：

1. **会话命令**：`plugin`、`describe`、`who/whos`、`rerun`、`recall`、`source`、`paste`、`store`、`cells`、`名字?`、`alias/config/hook/log/explore/audit/errors/hint/set/...`。命中即处理，**不占 `Out[n]`**。
2. **历史替换**：整行 `!!`、`!n`、`!-n`、`!$`。展开后立即求值；`expanding` 标志防递归；展开后的真实命令入历史，`!!` 本身不入。
3. **`!` 外部命令**：解析开头的元选项（`--tty/-t`、`--capture`、`--timeout-ms`、`--no-timeout`、`--`），再在**引号外顶层**切单个 `|` 成段；每段按 argv 执行。
4. **Shell 薄层**：仅当输入是**单行、无 pending**时才尝试；带 Raku 表达式、变量、复杂引号时交回 Raku。
5. **`exit`**：映射成退出请求，不真在引擎里 `exit`（否则带不走父进程）。
6. **续行判定**：`is-incomplete` 为真则存 `@!pending`，返回 `op<more>`。
7. **Raku 求值**：`!eval-raku`。

分类器只看**结构**，不看「像不像命令」。`read docs/ADR-0001.md` 这种输入会被当作 Raku 表达式（`read` 是 Raku 内置），要读文件用 `cat`/`read()` 或 `sys.read`。这是刻意的：猜入口就会重演 v1 的 auto-shell。

### 4.2 续行判定

`Rakuish::Incomplete.is-incomplete` 扫描引号（含智能引号）、括号、heredoc 等未闭合结构，返回布尔；`unclosed-hint` 给出「还差什么」的人类提示。它是**词法级**判断，不解析语法树——宁可多问一行，也不把半截代码送进 `EVAL`。

多行输入的边界：

- 续行提示符是 `···`（Chrome 负责渲染）；
- 多行格在历史里记**完整源码**，不是最后一行；
- `paste` 绕过续行机：整段读到一个 `--` 行，作为**一格**执行，历史只记一条。

### 4.3 跨格持久：为什么不重放历史

REPL 不保存「已执行的所有代码」。每格只做四件事（ADR-0022 / SPEC V-153）：

1. **扫描本格顶层 `my/our/state`**，把名字登记到 `%!state`，下一格用别名恢复可见性；
2. **改写顶层类型声明**：`class/role/grammar` → `my class/my role/my grammar`，避免 `EVAL` 把它们塞进 `GLOBAL` 导致第二次声明时 Redeclaration；
3. **维护纯声明缓存 `@!decls`**：纯 `sub`、`use`、`class/role/grammar`、`enum/subset/constant` 可缓存；类型声明**原位替换**以保持继承/组合顺序，失败时回滚；含 phaser（`BEGIN/END/...`）或混有其它语句的格**不缓存**；
4. **只 EVAL 当前格 + prelude**：prelude 是缓存声明的**按需切片**——本格点名的变量 + 声明传递闭包；`use`、运算符、`enum/subset` 永远全量重放。

prelude 切片是性能关键：全量重放 40 个声明约 109ms/格，切片后 9–13ms/格（ADR-0050）。

**必须记住的边界**：

- 持久的是**名字可见性，不是类型对象身份**。类型声明每格重放会生成新 type object，`$x ~~ Foo` 跨格可能为假、`.^name` 带外层包名。只承诺「名字与纯值可用」。
- 混合格（声明 + 副作用语句）、嵌套块内声明、含 phaser 的声明不持久。
- `our` 子集/`enum` 的裸声明要补 `my`，否则第二格报重声明。
- **不要用「重放整份历史」修任何状态问题**，那会重新引入副作用 P0。

### 4.4 `Out[n]`、`In[n]`、`_` 与历史

这是两套**刻意分离**的编号（ADR-0015 §3）：

| 概念 | 何时增加 | 内容 |
|---|---|---|
| `Out[n]` | 只有**成功**的求值/执行格 | 结果值；`_` 等价于最新一项 |
| `In[n]` | 同上 | 产生该结果的**输入源码** |
| history 序号 | **每一行**提交都进（含失败格、会话命令） | 原始输入 |
| `!n` / `!!` | 读 history | 与 `history` 编号同源 |

所以 `Out[3]` 是「第 3 个成功格」，不是「第 3 行」。失败格不占格号；会话命令不占格号。`@!out` / `$!index` 仍写在原来的三个执行点（Raku / `!` / Shell），不要为了「统一记账」硬挪进 `!finish`，否则编号全面漂移——要动就必须同时改 `t/07` 的契约断言。

`rerun n` 走真实求值，生成新的 `Out[n]`，但 `rerun` 这一行本身不进历史（与 `!!` 一致）。`recall n` 只把历史放回预填缓冲，**不执行**。

### 4.5 渲染与 `rendered` 契约

`Session.render(Result)` 只相信 `Result.rendered`：

- `rendered` 是 `Str`：按它显示（含空串）；
- 空串表示**刻意不展示**（例如 `config set` 成功、`!` 已流式输出）；
- 不要再「看 `out` 是否为空 / 有没有 `value`」来猜——0.98 之前就是这么猜的，结果流式输出被重放、空结果被 dump。

装饰层（颜色、`Out[n] =`、`COLUMNS` 分列）只在这里做；`Result::Renderer` 的 text/json/markdown 与 `Table.to-text` 一律**不掺 ANSI**，因为它们是给脚本消费的数据格式。

### 4.6 错误模型与 `error_info`

失败格返回：

- `ok=False`、`code`（127 启动失败 / 124 超时 / 130 中断 / 137 取消 / 其它为进程退出码）；
- `err`：给人看的一行；
- `error-info`：结构化字段（异常类型、消息、位置、回放帧），经 `error_info` 中间帧交给父进程，存在 `last-error-info`。

展示分级（0.140 / ADR-0054）：

```text
errors          # 默认 short：类型 + 位置，一行
errors full     # 附回放帧
```

`Result` 本身**永不抛**（系统操作/外部命令）；只有显式 `cmd()` 在失败时抛 `X::Rakuish::CommandFailed`。这是为了让脚本可以统一 `if !$r.ok { ... }`。

### 4.7 脚本模式与 `MAIN`

脚本入口不自己解析 argv，也不起子进程：整份源码作为一个 cell 在引擎/进程内 EVAL，并在末尾追加：

```raku
(::('&MAIN') !~~ Failure) && RUN-MAIN(::('&MAIN'), Nil)
```

要点（ADR-0040）：

- 尾巴在 `EVAL` 内部，`RUN-MAIN` 的 `callframe(1).my` 正好是脚本顶层，`sub USAGE` / `%*SUB-MAIN-OPTS` 仍然有效；
- 软查找 `::('&MAIN')` 避开 `Failure` 绑定与 sink 爆炸；
- `$*PROGRAM-NAME` 用**绝对路径**，绕开 Rakudo 2026.11 在 USAGE 里的 `rindex ... null` 崩溃；
- 脚本输出**不捕获**（否则 `exit` 前的 `say` 全丢）；
- `source` 命令**不做** MAIN 分派：脚本里的 `exit 2` 会杀掉引擎。

### 4.8 启动层：rc、prompt、`set -o`

| 能力 | 用法 | 实现点 |
|---|---|---|
| 启动文件 | 默认 `~/.rakuish/rc.raku`；`RAKUISH_RC=PATH` 改路径；`RAKUISH_NO_RC=1` 关闭 | 父进程解析路径，引擎逐格执行，**不占 `Out[n]`**；崩溃重启后重跑 |
| 可编程 prompt | `repl.prompt = -> { "λ " }` | 每格求值一次；抛错回落默认 |
| `errexit` | `set -e` / `set +e` | 下一个失败请求退出（Shell、`!`、Raku 都算） |
| `histexpand` | `set -o histexpand` | 控制 `!!`/`!n` 展开 |
| `noglob` | `set -o noglob` | 关闭 Shell 薄层的 glob 展开 |
| `noexpand` | `set -o noexpand` | 关闭 `$VAR` / `~` 展开 |
| `xtrace` | `set -o xtrace` | 打印实际执行的 argv/源码 |

这些选项都有**真实执行点**；没有执行点的开关不要加（ADR-0020 的教训：`Policy` 里 7 个字段有 4 个只是牌子）。

## 5. 功能实现与使用手册

本节按「用户看到的功能」组织。每条都给出：**怎么用** → **怎么实现** → **边界/坑**。更细的用户说明见 `MANUAL.md`。

### 5.1 Raku 求值、`display()` 与富输出

**用法**

```raku
1 + 1;                    # Out[1] = 2
my $t = (1..10).map(*²);  # 名字跨格可见
display(<<<HTML>>>);      # 显式声明 MIME，Notebook 按档渲染
```

**实现**

- 输入 → `Session!eval-raku`：扫描声明 → 组 prelude → `EVAL` → 成功后写 `@!out` / `$!index` / `%!state` / `@!decls` → 触发快照。
- 结果值 → `Result`（`value`），展示文本由 `Session.render` 生成；`display:true` 时额外算 `Display::Bundle`。
- `Display::Bundle` 支持 `text/plain` 必有，`text/markdown`、`text/html`、`application/json` 可选；JSON 档缓存「是否可序列化」，失败降级 text。
- 显式包装类型：`HTML` / `Markdown` / `JSON` / `SVG` / `PNG` / `Latex` / `JS`（`DSL` 提供）。

**边界**

- `html` 在 0.78 时明确「不承诺」，0.124 起通过 `display()` 走 `text/html`；普通值不自动转 HTML。
- 词法高亮只做单行（多行引号可延续），不染正则/heredoc/pod/插值块。
- 类型对象身份不跨格，见 §4.3。

### 5.2 `!`：外部命令

**用法**

```text
! git status --short
! --timeout-ms 300000 make
! --capture make          # 强制收完再显示
! -- make --version       # -- 之后全是字面 argv
! --tty raku              # TTY 直通（见 5.4）
```

**实现**

- `Session` 解析元选项后只保留 argv，调 `Sys.exec(exe, *@args, ...)`。
- `Sys::Proc.exec` 用 `Proc::Async`：stdout/stderr 各一个 Channel，`Handle.wait` 边读边回调；REPL 里回调把块包成 `chunk` 帧发给父进程，父进程立即写终端；结束时 `Result.streamed=True`。
- 超时默认 30s（`--timeout-ms N`，0 = 不超时）；捕获上限 1 MiB；启动失败 127、超时 124、取消 137。
- Windows cmd 内建（`echo/dir/type/set/...`）按**固定白名单**回落到 `cmd.exe /d /c`，逐 token `^` 转义；`Sys.exec` 不加这一层。

**边界**

- 永不解释 `$()`、反引号、`>`、`*`、`&&`；`|` 是唯一被识别的管道符（且只在顶层引号外）。
- 不做 shell 查找/别名：`! cat a.txt` 在 Windows 上没有 `cat.exe` 就是 127。日常文件操作**不带 `!`**：`cat a.txt`、`ls`。
- 子进程 stdout 是管道，不是终端：`git` 不上色、进度条可能退化；需要 TTY 用 `! --tty`。
- 流式显示不改变 `Result.out` 契约：`out` 仍是最终捕获内容（受 1 MiB 上限），`streamed=True` 只表示「已经实时显示过，不要重放」。

### 5.3 管道：三种完全不同的东西

| 形态 | 语法 | 执行者 | 数据形态 | 适用 |
|---|---|---|---|---|
| 文本管道（引擎内） | `! a \| b` | 引擎子进程 | 字节流 | 普通命令串联 |
| 交互式文本管道 | `! --tty a \| b` | **父进程** | 字节流，首段吃真终端 | 首段需要键盘（`more`、`fzf`） |
| 透传文本管道 | `! --pipe a \| b` | 父进程 / 本进程 | 字节流，末段直写终端 | 大输出、长任务、不截断 |
| 结构化管道 | `stream(...).where(...).exec(...)` | 引擎内 | 记录/`Hash` 流 | 过滤、连接、喂回子进程 |

**引擎内 `! a | b`（0.143 / ADR-0056）**

- 只在 `!` 行、引号外、**顶层**切单个 `|`；`! echo "a|b"` 是一个参数。
- 段间用 Channel 泵：写一块读一块，有背压；下游提前关 stdin（`head`）时上游立刻停。
- stderr 不改道，各段自己收，按段序拼进 `Result.err`；退出码取**末段**（不做 pipefail）。
- 元信息：`Result.value<pipeline>=True`，`value<stages>` 是每段码。
- 不支持 `||`、`>`、`&&`、`;`、`$()`、glob（V-901）；`||` 明确报「空段」而不是猜。
- 普通管道的 stdin 是协议流，**不能边打字边过滤**：`! cat | wc -l` 要写 `! --tty cat | wc -l`。

**父进程 `! --tty a | b`（0.144 / ADR-0057）**

- 引擎发 `pipe-exec` 中间帧，父进程用 `Sys.pipe-exec` 执行整条管道。
- 只有第 0 段继承真终端 stdin；段间仍是同一套泵。
- 末段输出**捕获**进 `Result`（`Out[n]`/`_` 可用），不是直通；v1 不做父→引擎块流式。
- 固定无超时（`--timeout-ms` 在 `--tty` 下无效）。
- stdin 不是 TTY / 没有父执行器（notebook）→ `code=127`，**绝不**回退引擎内（会吃掉协议 stdin）。
- Ctrl-C：POSIX 整组同 pgid，终端直接发信号；Windows 父侧收整组 Job 并 terminate；引擎不重启，`code=130`。

**透传 `! --pipe a | b`（0.145 / V-349 / ADR-0059）**

- 末段 stdout / stderr **不捕获**：`spawn-pipeline(:no-capture)` 读一块就经
  `on-out` / `on-err` 写当前进程的 `$*OUT` / `$*ERR`，`Result.out` / `.err`
  为空、`streamed=True`，结束不重放。
- 执行位置：worker 里引擎发 `pipe-exec` 帧（带 `no-capture`），父进程执行；
  `-e` / 脚本 / stdin 管道没有 hook，`Session` 直接调本进程的 `pipe-exec`。
- 单命令 `! --pipe cmd` 按「一段的管道」走同一路径，因此 `spawn-pipeline`
  的段数下限放宽到 1。
- 默认 `timeout-ms=0`（不设总时限），显式 `--timeout-ms N` 仍生效。
- `--pipefail` 在 `spawn-pipeline` 内逐段记码，取**最右**非零段；
  捕获式管道同样可用。`124` / `137` / `127` 优先于段码。
- `--stdin FILE`：Session 用 `Sys.resolve` 解析绝对路径（worker 读文件的是
  父进程），`spawn` 的 `:stdin-file` 以 16 KiB 分块 + `await write` 背压喂入；
  文件缺失 / 路径无效 → `127`。
- `--pipe` 与 `--capture` 互斥 → `127`；worker 无执行器同样 `127`，
  **绝不**把原始输出写进协议管道。
- 协议：`pipe-exec` 帧新增四个**可选**键（`no-capture` / `pipefail` /
  `stdin-file` / `timeout-ms`），`PROTOCOL-VERSION` 仍为 2；hook 无选项时
  按老签名调用，兼容旧闭包。
- **诚实边界**：数据层透传，子进程 stdout 仍是管道（`isatty=0`），
  上色 / 进度条 / TUI 仍要靠 `--tty`；不是 dup2 / PTY。

**结构化管道**见 §5.6.4。

### 5.4 终端：`--tty`、PTY、前后台作业、Windows Job

**a) `! --tty` / `tty-exec`（零捕获直通）**

```text
! --tty raku
```
```raku
tty-exec('raku');
```

- 子进程直接绑定当前终端，输出实时可见；**无超时**，由子进程退出或 Ctrl-C 结束。
- POSIX：`posix_spawnp` + `SETPGROUP` + `tcsetpgrp`，子进程成为终端前台，Ctrl-C 由终端直接投给它（ADR-0010）；交接前保存 termios，结束后恢复（ADR-0009）。
- Windows/降级：没有进程组交接，Ctrl-C 同时到达子进程、宿主与引擎；契约是**子进程退出、宿主重画 prompt、引擎保持存活**（V-289）。
- 子进程输出**不进** `Out[n]`；`Result.value` 只有退出码/耗时/exe/argv。
- 非 TTY 明确 127，提示改用 `exec(...)`；`job-control`/`termios-restored` 等字段可查。

**b) `pty-exec`（捕获 + 伪终端）**

```raku
my $r = pty-exec('python', '-c', 'print("hi")', :timeout-ms(5_000), :cols(100), :rows(30));
```

- `Proc::Async :pty`，需要 Rakudo ≥ 2025.12；不满足直接 127（`value<pty>=False`），不静默降级。
- 默认剥离 ANSI/OSC/控制字符；`max-bytes` 限制**剥离后**文本；stderr 与 stdout 合流（`err` 为空是语义，不是 bug）。
- 不提供 stdin 写入；跑交互式 REPL 会等到超时。
- Windows ConPTY 大输出可能丢尾部 chunk（驱动行为）；要字节级完整就让子进程写文件。

**c) POSIX 前后台作业（`bg-exec`/`bg-jobs`/`fg`/`bg`）**

```raku
my $r = bg-exec('/usr/bin/slow-job');
bg-jobs();          # Table：id/state/exe/pid...
fg($r.value<job>);
bg($r.value<job>);
```

- 普通 Raku 函数，不是 shell 语法（不碰 V-901）。
- 作业表建在**父进程**，引擎重启不丢孤儿；DSL 函数经 `job` 帧转到父侧。
- `fg` 切前台 + `SIGCONT` + `wait-state(WUNTRACED)`；Ctrl-Z 停住时归还前台并返回 `state=stopped`，可再 `fg`/`bg`。
- 与 `spawn()`/`jobs()`（捕获输出、`wait` 收 `Result`）是两套语义。
- Windows 无前台进程组：四个方法返回 127 + 明确原因。

**d) Windows Job Object（回收，不是作业控制）**

- 引擎启动后被放进 Job（`KILL_ON_JOB_CLOSE`）；它 spawn 的命令及孙进程自动继承。
- Ctrl-C 中断、`restart`、`shutdown` 都走 `TerminateJobObject`，整棵子树一起收；宿主退出关句柄兜底。
- 与 fg/bg 无关；非 Windows/32 位/创建失败自动降级。
- 0.119 起 Ctrl-C **只收外部命令**：引擎发 `child` 帧上报 pid，父进程把命令收进命令级 Job；Raku 求值（`sleep`/`loop{}`）没有子进程，仍按 ADR-0023 杀引擎。

### 5.5 Shell 薄层：shell 观感，Raku 语义

**用法**

```text
ls -la
cd .. / cd - / pushd / popd / dirs
cat --enc=gbk a.txt
head -n 5 huge.log
tail -f app.log
cp -r src dst
rm -r -f tmp
stat a.txt
glob '**/*.raku'
grep -inv 'error' *.log
wc -l *.md
which raku
bookmark add proj ~/work
```

**实现**

- `REPL::Shell.handle` 解析字面参数与简单 flag；`$NAME` 用会话 env 展开，`~` 用 `$*HOME`；glob 由命令自己展开（不经过 shell），只展开 `*`/`?`，受 `noglob` 控制。
- 所有文件操作最终走 `Sys`，返回 `Result`；`ls --json` / `ls-table` 返回 `Table`。
- 命令名只在 `Shell::COMMAND-GROUPS` 声明一处，派生：`COMMANDS`、`SHELL-COMMANDS`、`help` 索引、Tab 补全、渲染层 op 名单。新增命令从约 9 处降到 4 处（组声明、`usage` 文案、`OPTIONS`（仅当有 flag）、`given` 分发）。
- `t/37` 双向守：每个名字必须有 `usage` 文案；`given` 分发表不许有表外分支、表里每个名字必须有分支。

**边界（反直觉点）**

- `cp`/`mv` **目标存在即报错**（Raku `copy`/`move` 语义），不像 `cp -f`；要覆盖先删或换名。
- `read` 整份有 1 MiB 上限；`head`/`tail` 流式按行读，不受限；大文件按记录处理用 `stream(path)`。
- Windows glob 大小写敏感度受实现影响，不要假设 `*.TXT` 命中 `a.txt`。
- 读入按行归一化换行，写出保持调用者换行；不全局偷转 CRLF。
- `ls -h` 需要配合 `-l`；`-R` 在 TTY 下逐层流式输出。

### 5.6 数据层

#### 5.6.1 `Table`（急值）

```raku
my $t = open-data('data.csv');          # CSV → Table
$t.where({ .<score> > 80 })
  .select('name', 'score')
  .sort-by('score', :reverse)
  .head(10)
  .to-text;
$t.schema;  $t.describe;  $t.sql('select count(*) as n from t');
```

- 列式存储：`@columns`、`@rows`（`Hash`）、`@types`；`from-rows` 推断 schema。
- 变换：`limit/head/tail/offset/sort-by/select/where/distinct/join`；统计：`sum/mean/min/max/count`。
- 输出：`to-text/to-markdown/to-json/to-html/to-csv/gist`。
- `sql($query, :$name)` 走 DuckDB（见 5.6.5）。

#### 5.6.2 `Cursor`（来自数据库的惰性分批）

```raku
my $c = $db.cursor('select * from big');
while $c.next-batch(:size(1000)) -> @rows { ... }
```

- 只能读一次；`eof`/`fetched`/`close`；表流/`stream` 可以消费它，但第二次取会报错（不是空流）。

#### 5.6.3 引擎：DuckDB / SQLite（可选依赖）

```raku
my $db = open-db('analytics.duckdb');   # 缺 DB::DuckDB 时明确报错
$db.query('select ...');                # → Table
$db.execute('create table ...');
$db.begin; ...; $db.commit;             # 事务
$db.tables;  $db.schema('t');  $db.describe('t');
```

- 角色 `Data::Engine` 统一接口；DuckDB 支持 CSV/Parquet 读写、`threads`/`memory-limit`/`read-only`/`max-execution-time-ms`；SQLite 支持 `busy-timeout` 与 `sqlite3_interrupt` 超时。
- 可选依赖缺失时命令返回明确错误/跳过测试，不拖垮核心安装。
- 查询超时、只读、事务的边界见 MANUAL §8；只读守卫在引擎适配器层。

#### 5.6.4 `Stream`（惰性记录流）

```raku
stream(cmd-result('! find . -name "*.raku"'))
    .where({ .<line> ~~ /Result/ })
    .limit(5)
    .table;

stream('a,b' ~ "\n" ~ '1,2', :format<csv>)
    .exec('wc', '-l', :format<csv>);
```

- 入口：`Str`/`IO::Path`（`:format<lines|csv|tsv|json|jsonl|pattern>`，默认 lines）、`Result`（失败直接抛）、`Table`/`Cursor`、`List`/`Hash`。
- 惰性阶段：`where/select/drop/map/add-column/limit/skip`；物化阶段：`sort-by/unique/count-by/group-by`。
- 出口：`table/text/json/csv/lines/count/sum/mean/min/max/each`。
- `.exec` 把记录流写进子进程 stdin：`:in-chunks` 与写一块 await 一块 = 背压，攒 16 KiB；子进程提前关 stdin 记 `in-early`；一次性来源二次消费在调用点同步抛。
- 组合：`zip`（默认取短，`:longest` 补齐）、`join`（hash join，右表物化，默认 `left`）、`tee`（写文件 + 透传）、`interleave`（交替，默认吐完长侧）、`append`（首尾接，同构，左侧列为准）。
- 列名规则只有两份：`Table.join-columns`（合成一行时用）与各阶段自己的原样语义；`interleave`/`append` **不改列名**。
- 性能：列名写错只提示一次（0.106 前会每行 warn，20 万行拖成 77 秒）；来源已知行数时 `count`/`limit` 可推算。

#### 5.6.5 Table 上的 SQL（DuckDB/Duckula 桥）

```raku
$t.sql('select name, sum(score) as total from t group by name order by total desc');
table-sql([$users, $orders], 'select ...');   # 多表
```

- 桥只做「Table → 临时 `.arrow` → DuckDB `read-arrow` → SQL → `Frame.rows`」；不让 Duckula 写 IPC（0.33.1 对 timestamp/date 产坏流）。
- 标量列走 DuckDB 快路；嵌套列转 JSON 文本；NULL/时间类型还原；只读守卫。
- 写侧对嵌套列明确报错，不静默写成 `.Str`。

#### 5.6.6 Arrow IPC（读三路、写自研）

```raku
my $t = read-ipc('x.arrow');
write-ipc($t, 'y.arrow', :batch-size(10_000));
write-ipc-stream($stream, 'z.arrow');       # 真流式，内存只留一批
save-data('x.arrow');  ipc-batch-count('x.arrow');
```

- 写侧：自研 `IpWriter`（`start/add-batch/finish`），支持 `Buf` 或文件句柄；schema 首批推断后固定；`check-batch` 逐列核类型（`"abc".Int` 是 0，不核就写脏数据）；落盘 `.part` → rename。
- 读侧：**先走自研**（边界检查齐全），只在 `X::Rakuish::Arrow::UnsupportedType`（嵌套/字典/压缩）时回退 `Arrow::IPC`；结构错误绝不回退。
- 明确拒绝：字典编码、压缩（包 0.1.0 不解压也不报错，会把 `[1,2,3]` 解成 24/4.6e16）、嵌套写入。
- 按扩展名分发（`.arrow`/`.ipc`），不需要 `:allow-external`；Parquet 走引擎。

#### 5.6.7 `explore` 与分页

```text
explore data.csv
RAKUISH_PAGER=always rakuish
```

- 引擎只回文本、**不判断分页**（它的 stdout 是协议流）；父进程 `Data::Pager.paginate` 注入读/写回调，按终端高度切页。
- `RAKUISH_PAGER=auto`（默认，只给 `explore`）/`always`（任何超一页结果）/`never`。
- 真 PTY 验收接进 `tools/ci.sh`。

### 5.7 Notebook / Jupyter

**用法**

```bash
echo '{"op":"execute","code":"1+1"}' | rakuish-notebook
python tools/jupyter/install_kernel.py
jupyter lab
```

**实现**

- `Kernel::Notebook::Frontend.handle(%msg) → %reply`，与传输层（ZMQ）解耦（ADR-0037）；传输层可回调化（V-339）。
- op：`kernel_info/execute/complete/is_complete/inspect/history/interrupt/input_request/input_reply/shutdown/cwd`。
- `execute` 回两份：`out/err`（用户可见标准流）与 `display`（MIME 分档，零 ANSI、不带 `Out[n]`）；`display.formats` 抽象格式，`display.mime` 直接 MIME 表。
- 主动推送：带 `op` 的是响应，带 `event` 的是推送。`busy`（每格开始）、`idle`（响应后，附 ms）、`engine`（dead/restart/interrupted/restart-failed，附 restarts/index/restored/rc）。空闲期死亡靠 250ms 看门狗发现。
- `tools/jupyter/` 是 ipykernel wrapper：ZMQ/HMAC/heartbeat 交给基类，wrapper 只做消息翻译。

**边界**

- 无终端：`! --tty`、后台作业、`input()` 不可用（如实返回错误）。
- v1 不做流式/stdin/富媒体；complete 走整行替换（`cursor_start=0`）。
- `serve()` 只提供协议桥，不内置网络服务。

### 5.8 会话快照与跨会话变量库

**a) 崩溃快照（自动）**

- 路径：`RAKUISH_SNAPSHOT` 显式指定 → 否则 `$*HOME/.rakuish/session-<cwd指纹>.json`（按目录分开）。
- 开关：`RAKUISH_NO_SNAPSHOT=1` 同时停读停写；单值上限 `RAKUISH_SNAPSHOT_MAX`（默认 1,000,000 字符；`0/off/none` 不限）。
- 每成功格写：`%!state`（变量名→值）+ `@!decls`（可重放声明）。`Snapshot.classify` 把每个值分为 `nil`（无值）/`value`（可序列化）/`invalid`（资源、闭包、超限）。
- 恢复时只重放声明与纯值；`invalid` 的项打印「已失效」清单，不假装恢复。语句格**不重放**。
- 原子写：tmp + rename；Windows 先 unlink 目标再 rename。

**b) 跨会话变量库（手动）**

```text
store $x @rows        # 保存（名字不带 sigil 时按 $ @ % & 找唯一匹配）
store -l              # 名字 / 类型 / 长度 / 保存时间
store -r x            # 读回为真·会话变量
store -d $x           # 删除一项
store --clear         # 清空
store -f other.json $x
```

- 默认 `$*HOME/.rakuish/store.json`，`RAKUISH_STORE` 覆盖；按 cwd 分桶，值复用 `Snapshot::classify/save`。
- 只存纯值，不存资源/闭包；读回不触发 rc。

### 5.9 交互层：补全、键位、高亮、建议、历史

**能力与实现**

| 能力 | 用法 | 实现 |
|---|---|---|
| 命令/路径/选项补全 | Tab | `REPL::Complete` + `Shell` 的命令表；前缀优先，零命中做子序列模糊回退 |
| 方法补全 | `$obj.` + Tab | `REPL::Methods.method-context` + `method-names` |
| SQL 补全 | `q[...]` 内 Tab | `REPL::SqlComplete` 词法上下文 + 引擎表/列名（不建 SQL AST） |
| `In[`/`Out[` 补全 | 输入到括号内 | `in-out-completions` |
| 名字判定 | `foo?` | `REPL::Introspect`，引擎侧判定消除 listop 误标 |
| 灰字建议 | 自动 | 历史优先 + 补全候选缓存；`Alt-→` 逐词接受 |
| 候选菜单 | 多次 Tab / ShiftTab | 打印菜单后重画 prompt（不拥有输入循环，见 ADR-0036） |
| 历史检索 | Ctrl-R | 鱼式循环检索；ESC 退出 |
| Vi/Helix | `config set edit-mode vi\|helix\|emacs`；`vi-start insert\|normal` | `REPL::Keymap` 绑定；模式状态由前端维护 |
| 输入行高亮 | 自动 | `REPL::Highlight.highlight-line`，单行词法 |
| 结果着色 | 自动 | `Chrome`/render；`NO_COLOR`、`RAKUISH_PAGER=never` 等会关色 |
| 上下文提示 | `config set hints off` 可关 | `REPL::Hints.hint-for` |

**关键约束**

- 高亮/建议压在 `visible-input-field-string` 这一个点上，宽度不变式（光标列 = 可见字符数）不能破。
- `Highlight`/`Keymap` 依赖 `Terminal::LineEditor` 的内部字段（`scroll-cursor`、`available-width` 等）；升级上游要先跑「重开清单」。
- 行编辑器是上游的 `react whenever` 闭包，**不从外部改输入循环**。要重开（fork/推上游）需满足 ADR-0036 的三个触发条件，并按其五步清单做，不许当补丁。

### 5.10 本地插件

```text
config set plugins on
plugin load ./mytools.rakumod
plugin list / plugin info / plugin unload
```

```raku
# mytools.rakumod
use Rakuish::Command;
use Rakuish::Result;
BuiltinCommand.new(
    :cmd-name<hello>, :summary('示例插件'),
    :handler(-> $sys, |args { Result.new(:ok, :out('hello')) })
)
```

- 插件是一个本地 Raku 文件，最后求值为 `Command` 或 `List[Command]`；**加载即执行本地代码**，等同 `use`，不是沙箱。
- 路径先过 `Sys.resolve`（root 校验），源码经 `Sys.read`，只认 `.rakumod`/`.raku`；不扫目录、不联网、不持久化、不开机加载。
- 注册进会话 `CommandRegistry`；**不进** Shell 文本命令表；重名 409；`unload` 只移除自己注册的命令。
- 插件 handler 拿到的 `$sys` 是会话 `Sys`，必须经它做文件/进程操作。

### 5.11 审计与展示包

**审计**

- 每次 `Kernel.execute` 恰好一条：`Audit.record` 在 `LEAVE` 中写（正常/拒绝/异常）。
- origin：`repl` / `script` / `notebook`（V-303 起分账）；同账不同来源可筛。
- 字段白名单：只写固定字段（时间、origin、op、ok、code、耗时、cwd、fingerprint 等）；**源码全文、token、任意用户数据进不来**。
- 落点：`RAKUISH_AUDIT=PATH` → 默认 `$*HOME/.rakuish/audit.jsonl` → 都失败退化为纯内存；`RAKUISH_NO_AUDIT=1` 关闭。落盘失败绝不弄崩 REPL。
- 多进程共享锁；按条数/字节轮转 `.1`。
- 查询：`audit`、`audit --origin repl`、`audit -n 20`。
- **不要**把审计当阻止层；也不要把它与 `log`（人读抄本）、`trail`（调试）、`display`（内容）合并（V-196）。

**展示包**

- `Display::Bundle`：`text` 必有，`markdown/json/html` 可选；`available/has/pick/render/to-mime`。
- 内容层不掺 ANSI、不带 `Out[n]`；装饰由 `Session.render` 做。
- Notebook 的 `display` 字段与 REPL 的 `bundle` 同源，但 notebook 额外做 MIME 协商。

### 5.12 内省、记录与重跑

| 命令 | 作用 | 实现/边界 |
|---|---|---|
| `who` | 变量名清单 | 读 `%!state` |
| `who -l` / `whos` | 加类型/大小，`sub/class/use` 一览 | 零 `EVAL`，不执行用户代码 |
| `rerun` / `rerun 3` / `rerun -2` | 重跑历史条目 | 走真实求值；`rerun` 行自身不入历史 |
| `cells` | 本会话格记录（编号/状态/耗时/输入） | 记账独立于 `Out[n]` |
| `cells --text sess.raku` | 导出可重放脚本 | 直接 `rakuish` 或 `source` |
| `cells --json -` | 结构化记录到 stdout | 给工具消费 |
| `source lib.raku [args]` | 在当前会话装库/执行脚本 | 文件里的 `sub/class/use/顶层 my` 留下；有 `sub MAIN` 时按位置参数调用；**不做**脚本式 `RUN-MAIN`（`exit` 会杀引擎） |
| `paste` | 多行整段粘贴 | 读到单独 `--` 行/EOF，作为一格执行；历史只记一条 |
| `errors [short\|full]` | 错误分级 | `full` 附回放帧 |
| `recall [n]` | 把历史放回预填缓冲 | 不执行 |
| `log start [path]` / `log show` / `log stop` | 会话日志 | 默认 `~/.rakuish-session.log`；`show` 不依赖文件 |

### 5.13 配置、别名、钩子

```text
alias ll=ls -alh
unalias ll
config set edit-mode vi
config set color off
config get color
config unset color
hook add start echo "hello"
hook run start
hook clear start
```

- 配置持久化在 `~/.rakuish/config.json`（`RAKUISH_CONFIG` 可覆盖）；未知键拒绝，不做静默容忍。
- 别名只对 Shell 文本命令生效，不改变 Raku 语义。
- 钩子按事件（`start` 等）存命令串；`hook run` 显式触发；钩子失败不阻断主流程。
- 所有配置键必须有真实执行点；加键前先问「谁读它」。

### 5.14 其余常用能力

| 能力 | 用法 | 说明 |
|---|---|---|
| `timed` / `bench` | `timed { ... }`、`bench 5 => {...}` | 计时/基准，输出 `Result` |
| `recent` | `recent 10` | 最近格摘要 |
| `head/tail -f` | `tail -f app.log` | 轮询 0.2s，半行缓冲，截断/轮转重读；循环在父进程（job 帧） |
| `grep/wc/which` | Shell 薄层 | `grep` 支持 `-i/-n/-v/-l`、`-E` 正则；`which` 查 PATH |
| `bookmark` / `dirs` | `bookmark add proj ~/work` | 目录栈与书签（ADR-0012） |
| `help` / `doc` / `hint` | `help ls`、`doc Str.uc` | `doc` 零 `EVAL` 内省；`help --find` 搜索 |
| `clear` | 清屏 | 只清显示，不清历史/状态 |

---

## 6. 方案选型：为什么是这套架构

完整 57 条见 [`ADR-INDEX.md`](ADR-INDEX.md)；这里只讲最影响架构的决策，以及**当时拒绝过什么**。

### 6.1 重大决策总表

| 决策 | 版本 | 当时的问题 | 选了什么 | 拒绝/放弃及原因 |
|---|---|---|---|---|
| Raku 原生替代 bash 子集 | 0.29–0.34 | v2 的 7 个 P0：`rm -r` 不删非空、`test -L` 恒假、`ls -la` 被当路径、`yes \| head` 卡死、中文损坏、错误分派无调用点、双栈漂移 | 删双栈；`Sys`+`IO::Path`；argv-only；脚本就是 Raku 脚本 | 继续补 bash 语义（三方漂移）；保留 `%magic`（与 `%hash` 冲突、三处分派）；`Eval::eval-cell`（反引号仍走私 shell） |
| 删除 Agent 线 | 0.81 | 沙箱/白名单/操作协议/流取消成本高；rakupp 探针 27/42、并发 SIGSEGV | 全权限本地 shell；不设权限闸门；审计保留 | 保留 Sandbox/allowlist（无执行点，只是牌子）；常驻 daemon（没有第二客户端） |
| Policy 7→3 | 0.82 | `allow-exec/read-only/allow-ops/limits` 没有执行点 | 只留 `profile/allow-source/root` | 保留无执行点字段 |
| 求值引擎子进程化 | 0.83 | `exit` 带走 REPL、段错误全灭、死循环杀不掉 | `Eval::Server/Client/Proxy`，单行 JSON 串行；`! --tty` 交回父进程 | rakupp C ABI（缺 `:pty`、并发崩）；线程 worker（无 `Thread.kill`、EVAL 非线程安全） |
| 快照不重放语句 | 0.84 | 崩溃丢状态；重放语句副作用不幂等 | 声明 + 纯值重放；资源/闭包/超大值标失效 | 全量重放；SQLite 序列化（难点不在存储） |
| Ctrl-C 归因 | 0.85 | 中断被误报成崩溃；行编辑器吞下一格 | 等待期接管 SIGINT、kill 引擎；`op=interrupted/code=130`；清 `take-interrupt` | 立即中断保证/部分结果；把中断当 crash |
| `!` 流式输出 | 0.90 | 捕获模式长时间无屏显；超时杀 124；`--tty` 又不捕获 | chunk 帧 + 父进程实时打印；`--capture/--timeout-ms/--no-timeout`；`streamed` 防重放 | 默认 tty-exec（无 `Result.out`）；靠空 `out` 猜流式 |
| 前端分页 | 0.92 | 0.89 引擎内分页写进 JSON 协议流并吞下一请求，REPL 卡死 | 引擎只回文本；父进程 `Pager` 注入读/写回调 | 引擎侧分页；`--tty` 交还（需交替读写）；全屏 pager |
| 结构化管道不加语法 | 0.91 | 文本/记录/子进程 stdin 不互通；`\|>` 在 Raku 语法不可定义 | `Stream` 方法链；惰性边界写明；`.exec` 写 stdin | 管道语法（`\|` 属 V-901，`\|>` 不可定义） |
| 后台作业用普通函数 | 0.96 | 想补 fg/bg 又不想加 shell 语法；作业表放哪 | `bg-exec/bg-jobs/fg/bg` 普通函数；表在父进程；`wait-state(WUNTRACED)` | `&` 语法、`jobs` 关键字；SIGCHLD handler（与 Rakudo 回收竞态） |
| Windows Job Object | 0.117 | 引擎被杀后命令/孙进程成孤儿 | `KILL_ON_JOB_CLOSE` + `TerminateJobObject` | 依赖子进程自杀；把 Job 与 fg/bg 混为一谈 |
| Win Ctrl-C 只收命令 | 0.119 | Ctrl-C 杀并重启引擎 4–5s，丢状态 | `child` 帧上报 pid，命令级 Job；只杀命令子树，`code=130` | 等子进程自己死（独立进程组收不到 `CTRL_C_EVENT`）；引擎侧杀 |
| Arrow 读写三路 | 0.116/0.120.1 | 包读慢 4.6 倍且越界段错误；包写需 CData 视图 | 写自研；读先自研、只在 `UnsupportedType` 回退；SQL 交 DuckDB | 全交 `Arrow::IPC`（坏文件段错误）；让 Duckula 写 IPC（坏流）；自研嵌套/字典解码 |
| 只支持 Rakudo | 0.121.1 | 文档/测试处处拿 rakupp 当第二参照物 | 纯 Raku、单运行时；示例统一 `raku` | 运行时探测、能力分支、第二套 CI |
| 引擎内管道 | 0.143 | `!` 只能单进程，`\|` 是普通字符 | 只在 `!` 行切顶层 `\|`；stderr 各段独立；退出码取末段 | 管道语法；dup2（`Proc::Async` 无重定向）；pipefail |
| 交互式管道 | 0.144 | `--tty` 要真终端，但引擎 stdin 是协议流 | 父进程执行整条管道；新增 `pipe-exec` 帧，协议仍 v2 | 回退引擎（吃掉协议 stdin）；父子 chunk 流（与 `Out[n]` 回放冲突）；升协议版本 |
| job control 只做前台 | 0.73 | 子进程与 REPL 同组，Ctrl-C 双杀 | `posix_spawnp` + `SETPGROUP` + `tcsetpgrp` + 自建 `waitpid` | 换后端（不解决）；Windows 作业控制（`CTRL_C_EVENT` 不可定向） |
| TTY 直通 | 0.70/0.72 | 交互式子进程要真键盘/终端 | `! --tty` 零捕获直通；`pty-exec` 是显式双开关的捕获入口 | 进程内 PTY 模拟（与行编辑器冲突）；默认 tty-exec |
| 审计唯一写入 | 0.80 | 多出口记账易漏、字段失控 | `Audit.record` 唯一写入；四出口不合并 | 合并四出口；把审计当事前阻止 |
| 命令名单一数据源 | 0.77 | 约 9 处登记；`hint/plugin` 有用法却 Tab 补不出 | `COMMAND-GROUPS` 派生全部视图；`t/37` 双向守 | 继续「新命令手工登记 N 处」 |
| 输入循环不自研 | 0.101 | 上游 `read-input` 是私有闭包，fork 成本高 | 维持近似路线；写明重开前置五步与触发条件 | 当场 fork LineEditor / 强推上游 |

### 6.2 四个关键「为什么不」

**① 为什么不做 bash 子集？**

因为「实现 bash 语义」不是少几个 bug，而是**底座错误**：自建 Path 会丢 `IO::Path` 能力；自建 Lexer 要自己解析 flag；临时文件模拟管道会挂死/撑盘。v2 的 7 个 P0 全是这条路的必然产物。Raku 本身有 `IO::Path`、`Proc::Async`、正则、数据结构和模块系统——再写一套等于放弃它们，还要维护两套语义。

**② 为什么求值要进子进程？**

Raku 线程无法强杀，`EVAL` 也不保证线程安全；`exit`、段错误、死循环只能靠**进程边界**隔离。子进程方案让父进程独占终端/行编辑/审计，代价是协议串行——这个代价换来「崩溃只丢引擎、状态可恢复」，值得。

**③ 为什么快照不重放历史？**

重放 `rm -rf`、写文件、`curl` 都不幂等。0.84 明确只重放**声明与纯值**；语句格的副作用不可恢复，如实告知。要「完全恢复」需要事务化整个 OS，不现实。

**④ 为什么结构化管道不加 `|` 语法？**

`|` 在 Raku 里是 `any` junction / 参数分隔语义（V-901 明确禁止当 shell 管道），`|>` 也无法在语法层定义。硬加会破坏 Raku 语法或引入第二个解析器。`Stream` 用方法链，惰性/物化边界写在文档里，既不打语法补丁，也能链到 `.exec`。

### 6.3 被否决但值得知道的方案

| 方案 | 为什么看起来可行 | 为什么没选 |
|---|---|---|
| 常驻 daemon / Agent 多客户端 | 可以远程、可多前端 | 没有第二个客户端；引入认证/协议/沙箱成本，0.81 整体删除 |
| 线程 worker + 超时 | 不需要进程协议 | 无 `Thread.kill`；EVAL 非线程安全；超时只能等 |
| 把所有输出都捕获再显示 | 实现简单、`Result` 完整 | 长命令长时间无输出；流式与超时体验不可接受 |
| 引擎内分页 | 代码集中 | 引擎 stdout 是协议流，会写坏帧并吞请求（0.89 事故） |
| 全量重放声明 | prelude 逻辑简单 | 40 声明约 109ms/格；切片后 9–13ms |
| 自研 Arrow 全栈 | 无依赖、类型可控 | 嵌套/字典/压缩工程量过大；读写分路更划算 |
| 用 DuckDB 写 Arrow | 少写一个写入器 | 当年是因为 Duckula `ipc-buf` 对时间类型产坏流（pyarrow 报 Not an Arrow file）。**0.53.0 起上游已修**，现在仍不选它的理由换成「不新增耦合」：写侧是自研纯 Raku（零原生依赖），让上游写 IPC 就把桥的正确性绑到别人的序列化细节上（ADR-0069 §9） |
| Windows 上也做 fg/bg | 体验一致 | `CTRL_C_EVENT` 不能定向到进程组；Job 只解决回收，不解决作业控制 |

## 7. 走过的弯路与踩过的坑

这一节不是考古，而是**避免重犯**。每条都尽量写成「现象 → 原因 → 现在的做法」。

### 7.1 三个阶段

**阶段一：v1（raku-eval）——IPython 式 Raku 环境**

贡献了 `Out[n]`、行编辑/补全、历史、配置、`%time`、脚本运行等交互方向。问题在于它逐渐长成「两套语言 + 两套执行栈」：`!` 走 shell、反引号捕获、`%run/%load/%time/%config` 等 magic、auto-shell 自动猜测输入归属。

**阶段二：v2（API v2）——用 Raku 实现 bash 子集**

`Parser → AST → Executor → Builtin`，支持 `$VAR`、`|`、`>`、`&&`、`test`、`export`、heredoc、glob、`[[ ]]`；独立 `rakuish-sh` 引擎、真 bash/native 双后端、`%magic` 第二套命令语言、后台 daemon、JSON/TCP server、自建 `Platform::Path`/`Stat`。

失败不是「差几个 bug」，而是**底座选错**：七个 P0（`rm -r` 不删非空、`test -L` 恒假、`ls -la` 被当路径、管道挂死、TCP 无认证、双栈漂移等）都是自建 shell 语义的必然产物。0.34.0 整体删除。

**阶段三：v3（Raku 原生，当前）**

0.29–0.34 逐步落地：`Sys` 会话出口、`IO::Path`、argv-only 进程 API、`Result`、DSL/Command、无 magic REPL。此后 0.81 删 Agent 线、0.83 引擎子进程化、0.84 快照、0.90 流式与启动层、0.91–0.96 数据流与作业、0.100 手感层、0.109–0.136 Notebook/Arrow/协议、0.137–0.144 中文/表格/错误/paste/store/管道。

### 7.2 坑清单（按领域）

#### 架构与求值

| # | 现象 | 原因 | 现在的做法 |
|---|---|---|---|
| 1 | 修 A 坏 B，语义两头漂移 | v1/v2 双栈共存 | 删双栈，只留 Raku 一套 |
| 2 | `rm -r` 不删非空、`test -L` 恒假、`ls -la` 被当路径 | 自建 Path/Lexer/命令解析 | 全用 `IO::Path`/`Stat`，外部命令 argv-only |
| 3 | `yes \| head` 永久写盘、无背压 | 临时文件模拟管道 | Channel 泵 / `:&in-chunks` |
| 4 | 第二格必报 Redeclaration | `enum/subset/constant` 裸声明进 `GLOBAL` | 声明前补 `my`；类型改写 `my class/role/grammar` |
| 5 | `$x ~~ Foo` 跨格偶尔假 | 类型每格重放生成新 type object | 只承诺名字/纯值，不承诺身份（V-153） |
| 6 | 每格 100ms+ 卡顿 | 全量重放 40 个声明 | prelude 按点名 + 传递闭包切片（9–13ms） |
| 7 | 修状态问题时越修越乱 | 想靠「重放历史」兜底 | 绝不重放语句；只恢复声明与纯值 |
| 8 | 顶层 `class` 包装进 GLOBAL | `EVAL` 的字符串作用域 | 统一改写为 `my` |
| 9 | 声明格缓存后继承顺序错 | 原位替换会打乱依赖 | 按源码顺序原位替换，失败回滚 |

#### `Out[n]`、历史与记账

| # | 现象 | 原因 | 现在的做法 |
|---|---|---|---|
| 10 | `Out[n]` 与 `history` 编号对不上 | 两套编号被混为一谈 | 成功格才占 `Out[n]`；每行都进 history |
| 11 | 失败格把 `Out[n]` 顶掉 | 记账点写错 | 失败只进 history，不占格号 |
| 12 | 「统一记账」后编号全面漂移 | 把 `@!out` 挪进 `!finish` | 保持三个执行点；要动先改 `t/07` 契约 |
| 13 | `!!` 递归展开死循环 | 展开结果再次被展开 | `expanding` 标志；真实命令入历史，`!!` 不入 |

#### 输入、展示与终端

| # | 现象 | 原因 | 现在的做法 |
|---|---|---|---|
| 14 | 命令有用法但 Tab 永远补不出 | 命令在约 9 处分别登记，漏了 `COMMANDS` | `COMMAND-GROUPS` 单一数据源，`t/37` 双向守 |
| 15 | 中断后下一格输入被吃掉 | `take-interrupt` 标志残留 | `Client` 每次清标志 |
| 16 | 子进程退出后终端留在 raw 模式 | 只恢复「猜到的」termios 位 | 交接前快照整份，正常/`LEAVE` 幂等恢复 |
| 17 | 中文输入触发 Malformed UTF-8 后死循环 | Windows 控制台仍是 GBK 码页 | 交互前切 65001，`END` 还原 |
| 18 | 输出到 NUL 也判成 TTY，颜色/流式误开 | CRT `_isatty` 对 NUL 为真 | `GetConsoleScreenBufferInfo` 探真控制台 |
| 19 | ConPTY 大输出偶尔丢尾块 | 驱动行为，等 250ms 也补不回 | 字节级完整就让子进程写文件 |
| 20 | 大输出把表格写进 JSON 流，REPL 卡死 | 引擎内分页写了协议 stdout | 分页搬到父进程（`Pager.paginate` 注入回调） |
| 21 | 引擎里颜色全灭、`ls` 退单列 | 引擎看不到 fd/尺寸 | tty/宽高/颜色由前端每格注入 |
| 22 | `=:= IterationEnd` 判断失效 | 容器同一性判据错 | 用 `~~` |
| 23 | block 内 `return` 跳过后面的落盘 | 非局部返回外层 sub | 显式 `last/next` |
| 24 | `\|@args` 只滑进一个列表 | `@parts.map(*.Str)` 解构错 | `».Str` 再 `.List` |

#### 进程与作业

| # | 现象 | 原因 | 现在的做法 |
|---|---|---|---|
| 25 | Ctrl-C 把 REPL 和子进程一起杀 | 同一进程组 | `SETPGROUP` + `tcsetpgrp` + 自建 `waitpid` |
| 26 | 引擎被杀后命令/孙进程成孤儿 | 没有子树回收 | Windows Job + `KILL_ON_JOB_CLOSE`；POSIX 进程组 |
| 27 | Ctrl-C 重启引擎 4–5 秒，状态丢 | Windows 上信号不可定向 | `child` 帧 + 命令级 Job，只收命令子树 |
| 28 | 等子进程「自己死」等不到 | Raku 建了独立进程组，收不到 `CTRL_C_EVENT` | 父侧 `TerminateJobObject` |
| 29 | `fg` 后 Ctrl-Z 卡死 | 停止状态没归还前台 | fg 归还 + `wait-state(WUNTRACED)`，可再 fg/bg |
| 30 | 超时后文件 I/O 还在后台跑 | Raku 线程无法强杀 | 文档写明「超时不是 kill」，结果丢弃 |

#### 数据、Arrow 与 SQL

| # | 现象 | 原因 | 现在的做法 |
|---|---|---|---|
| 31 | Arrow 写出脏数据 | `"abc".Int` 是 0，不核类型 | `check-batch` 逐列核，报行列 |
| 32 | 截断 Arrow 文件让进程 SIGSEGV（rc=139） | `decode-ipc` 对越界元数据无边界检查，`try` 接不住 | 先走自研读（边界齐全），只在 `UnsupportedType` 回退 |
| 33 | 压缩 Arrow 读出 24 / 4.6e16 怪值 | `Arrow::IPC` 0.1.0 不解压也不报错 | 读前检查 `BodyCompression`，直接拒绝 |
| 34 | Duckula 写出的 IPC 任何库都读不了 | `ipc-buf` 对 timestamp/date 产坏流（0.53.0 已修，此坑已失效，保留作历史） | 只让 Duckula 读/算，写侧自研（理由现为「不新增耦合」） |
| 35 | `my %m = try {...}` 抛 `X::Hash::Store::OddNumber` | try 返回 Nil，赋值在 try 外的 `%m` 上 | 先绑标量再查 Hash |
| 36 | 5 万行 Arrow 解码慢 4.6 倍 | 全交包解码 | 标量走自研，嵌套才回退 |
| 37 | `stream` 列名写错刷 20 万条警告 | 每行 warn | 每个来源只提示一次 |
| 38 | `tee` 写出的文件不完整 | 下游提前停，透传中断 | 文档明确「写多少看下游」，它不是 fan-out |
| 39 | 断电后 `.arrow` 半截 | 直接写目标文件 | `.part` → rename；Windows 先 unlink |
| 40 | `cp`/`mv` 覆盖行为与 Unix 不同 | Raku `copy/move` 目标存在即失败 | 文档写明；要覆盖先删 |
| 41 | `IO::Path.modified` 时间不可靠 | Windows 实现限制 | 不伪造 1970，如实降级 |

#### Windows 与工程

| # | 现象 | 原因 | 现在的做法 |
|---|---|---|---|
| 42 | 刚启动就卡 1.1 秒 | 启动预热扫 6000 个 PATH 项 | 三级查找 + 磁盘缓存，过期先给旧表后台补 |
| 43 | `! cat a.txt` 报 127 | Windows 没有 `cat.exe` | 日常文件操作不带 `!`；用 `type`/`Get-Content` |
| 44 | `! echo` 找不到 exe | cmd 内建没有同名可执行文件 | 固定白名单回落 `cmd /d /c`，逐 token 转义 |
| 45 | 安装时 precomp/exe 被锁 | 残留 `rakuish`/`rakudo` 进程持有映射 | 先结束残留进程再 `zef`；不是代码 bug |
| 46 | 脚本 `sub MAIN` 不执行 | `EVAL` 不会自动跑 `MAIN` | 末尾追加软查找 + `RUN-MAIN`，绝对路径 `$*PROGRAM-NAME` |
| 47 | 裸 `$*PROGRAM-NAME` 触发 Rakudo USAGE 崩溃 | 2026.11 的 `rindex ... null` | 用绝对路径 |
| 48 | 删了 Agent 后文档还在教 `--serve` | 文档滞后 | 旧文只作历史，SPEC 标撤销；新增功能同步 MANUAL |
| 49 | 多行粘贴被续行机拆坏 | 逐行喂触发 incomplete | `paste` 整段读 `--`/EOF，一格执行 |
| 50 | 测试机装了 Git，测试「借」到 `usr/bin` 的 exe | PATH 夹具不干净 | 去掉 Git `usr/bin` 复跑；测试自带夹具 |

### 7.3 设计红线（再犯就是回退）

1. 不新增「默认关闭 + 开关打开」的权限形态——那等于承认「打开就安全」。
2. 不拼 shell 字符串；不引入第二套语法解析器；`|` 不是 shell 管道（V-901）。
3. 不重放历史副作用；不用测试「修绿」设计问题。
4. 不让引擎写协议 stdout 之外的任何东西（包括分页、进度条）。
5. 不在没有执行点的地方加字段/开关/文案。
6. 不让展示层（ANSI、`Out[n]`）渗进 `Result`/`Display`/`Table` 的数据格式。
7. 新命令必须进 `COMMAND-GROUPS`，否则 Tab 补不出——这不是 cosmetics，是契约。

## 8. 开发指南

### 8.1 本地起步

```bash
git clone <repo>
cd rakuish
raku -Ilib t/01-sys-fs.t       # 单文件（最快反馈）
prove6 -Ilib t                  # Windows 全量
bash tools/run-all.sh           # Linux/WSL 全套（首选）
bash tools/ci.sh                # 平台无关 CI 入口 → tmp/ci-report.txt
zef install . --force-install
rakuish --version
```

无 TTY 的构建机：`Terminal::API` 上游测试会中断 `zef install .`，先按 `docs/CI.md` §2.1 `--force-test --force-install` 装依赖，再装本包。安装时若 precomp/`rakuish.exe` 被锁，先结束残留 `rakuish`/`rakudo` 进程。

Windows 上 `prove6` 建议在**去掉 Git `usr/bin` 的 PATH** 下再跑一遍，防止测试夹具「借」到 Git 自带 exe。

### 8.2 新增一个 Shell 薄层命令

以 `foo` 为例，只改 4 处（`REPL::Shell`）：

1. **组声明**：在 `COMMAND-GROUPS` 对应组里加 `foo`（这是唯一命令名单）。
2. **usage 文案**：`usage()` 里加一行（`t/37` 强制）。
3. **OPTIONS**（仅当有 flag）：加 `foo => {...}`。
4. **分发体**：在 `given $name` 里加 `when 'foo' { ... }`（`t/37` 禁止表外分支/表内缺分支）。

约束：

- 参数解析在薄层做，但文件/进程操作必须调 `Sys`；
- 返回 `Result`，不要直接 `print`；
- 需要多行/流式输出时用 `Sys.read-lines`/`stream`，不要整份读；
- 新增 flag 要有执行点，不要「预留」；
- 若该能力也适合脚本，考虑同时提供 `DSL` 函数（见 8.3），但不要两份实现。

### 8.3 新增一个 DSL 函数

以 `foo` 为例（`lib/Rakuish/DSL.rakumod` + `REPL::Session` 的 prelude）：

1. 在 `DSL` 写普通 `sub foo(...)`，签名尽量显式，返回 `Result`/`Table`/`Stream`；
2. 需要会话时从 `session()` 取，不要全局单例；
3. 导出（`is export`）并加入 `Session` 的 prelude 导入；
4. 若它是「命令型」能力，同时在 `CommandRegistry` 注册（脚本/`cmd()` 可用）；
5. 补 `t/04-dsl-command.t` 或新文件；涉及文件系统时用临时目录夹具。

不要为 DSL 发明新语法（宏、运算符重载）；它是普通 Raku 函数。

### 8.4 新增一种数据格式

1. `Data.open-data`/`save-data` 的扩展名分发表加分支；
2. 读侧返回 `Table`（小）或 `Stream`/`Cursor`（大）；写侧接受 `Table`/`Stream`；
3. 外部文件读写要过会话 `root` 校验；需要显式放开的走 `:allow-external`（CSV/Parquet 已有先例，V-152）；
4. 嵌套/不支持的类型必须**明确报错**，不静默 `.Str`；
5. 补真实夹具 + 往返断言；跨平台注意换行/编码。

### 8.5 新增协议 op 或中间帧

顺序不能反：

1. `Eval::Protocol`：加字段/常量、`check-frame` 校验、`EvalReply` 编解码；
2. `Eval::Server`：分发与 `emit`；
3. `Eval::Client`：等待循环里的帧分发（中间帧不能当响应）；
4. `Eval::Proxy`：翻译成 `Result`/回调；
5. 测试：`t/41` 补协议断言，再补功能测试；
6. 判断是否需要升 `PROTOCOL-VERSION`：纯增量（旧端不会发/收）不升；改字段语义/删除字段必须升。

中间帧的纪律：**只在当前请求处理期间出现**；父侧必须能区分「响应」与「中间帧」；中间帧不得改变请求的串行性。

### 8.6 新增 Kernel op

`Kernel.execute` 的 `kind` 目前有 `source`/`script`/`op`。加 op 前先问：

- 它是否只是 `capabilities` 的自描述？是 → 不要加。
- 它是否需要绕过 `Session.eval-line`？如果是，说明设计有问题（V-182）。
- 它是否会产生文件/进程副作用？是 → 必须走 `Sys`，并确保 `LEAVE` 审计字段完整。

### 8.7 测试规范

- **一个能力一个 `t/NN-name.t`**，编号递增；断言数写进 ADR/CHANGELOG。
- 不用 `subtest`（仓库约定），用注释分节 + 平铺断言；默认 `done-testing`，需要精确计数才写 `plan N`。
- 先写复现测试再修 bug；回归测试命名指向条款（如 `t/79-p0-regressions.t`）。
- 真终端契约用 `tools/` 下的 PTY 探针接进 `tools/ci.sh` 的 console 层，不能只用伪 TTY；Windows 专属用 `t/71` 这类整段 skip。
- 夹具在**测试开头**清理（`$*PID` 会复用；中断时结尾清理不执行）。
- 涉及 `Failure` 的断言用压力循环 + `$*ERR` 重定向（`Failure` 在 DESTROY 时才吐）。
- 平台条件块要写清楚：Windows/Linux 断言数不同是正常的，不要强行统一数字。
- **测试不许依赖某一平台独有的外部命令**：`findstr` 只有 Windows 有、`grep` 只有类 Unix 有、`dir` 只有 Windows 的 cmd 内建。管道/过滤器类断言要么按 `$*DISTRO.is-win` 选命令，要么整段 `if $*DISTRO.is-win`。0.155.1 的成因：`t/90` 写死 `!echo a | findstr a`，Windows 绿、`zef install .` 在 WSL 上红在第一个测试文件（zef 遇到失败即中断，用户看到的就是「安装失败」）。
- **测试不许读真 stdin**：`paste` 在没有 `read-line` 时落回 `$*IN.get`。`zef install .` 会把终端交给测试进程（WSL 下实测 stdin = `/dev/pts/6`），断言会一直等回车——整个安装看起来像卡死（0.154.1 的成因）。要先用 `my $*IN = Test-EOF-In.new`（`class Test-EOF-In { method get(--> Nil) { Nil } }`）遮蔽，再断言分支。
- 新模块必须进 `META6.json` 的 `provides`（`t/51` 守）；`t/52` 会 require 每个模块做编译冒烟。

### 8.8 ADR 与 SPEC 规范

**ADR**

- 四位编号，标题即决定句（英文 slug + 中文主题）。
- 头部固定：日期 / 对象（版本）/ 状态 / 输入 / 相关。
- 正文：问题（含方案对比表）→ 决定（可验证细节）→ 不做的事 → 验证（`t/NN` 条数）→ 边界与代价。
- 实施后回写 `docs/ADR-INDEX.md` 的状态与一句话结论。
- 撤销**不删原文**：标「已撤销」，指向替代 ADR；旧代码在对应 tag 里取回。

**SPEC**

- 条款编号 `V-xxx` **只增不改号**，按 §3.x 分节。
- ADR 与条款双向引用；行为变更必须同改条款与测试。
- 失效条款标「已终结」，不删除、不复用编号。
- `SPEC.md` 是条款真值；`ADR-INDEX.md` 是决策目录真值；外部资料库的文章**不是**真值源。

### 8.9 版本同步与发布

版本号出现在至少五处，必须一致：

1. `META6.json` 的 `version`；
2. `bin/rakuish` 的 `$VERSION`；
3. `CLI.FALLBACK_VERSION`；
4. `Kernel::Notebook.KERNEL-VERSION`；
5. README/MANUAL/HANDOFF/ADR-INDEX 的标题与日期。

`t/51` 只覆盖一部分，其余靠肉眼核对。

发布 checklist：

```text
[ ] prove6 -Ilib t 全绿（Windows）
[ ] tools/run-all.sh 退出 0（Linux/WSL）
[ ] 真终端验收：tty-check.py / tty-termios-win.py
[ ] zef install . --force-install 通过
[ ] 版本五处一致；provides 与 lib/ 一一对应
[ ] README / MANUAL / SPEC / CHANGELOG / ADR-INDEX 同步
[ ] 无新增 shell 字符串解析；无历史副作用重放
[ ] 新能力带审计、上限、失败态
[ ] tag 与 CHANGELOG 顶条一致（annotated tag）
```

补打旧 tag 要标「补打」，并使用各自发布提交的日期。

### 8.10 平台差异速查

| 能力 | POSIX | Windows |
|---|---|---|
| 前台进程组 / `tcsetpgrp` | 有 | 无（返回 127 + 原因） |
| fg/bg 作业 | 有 | 不支持 |
| 子树回收 | 进程组 | Job Object（`KILL_ON_JOB_CLOSE`） |
| Ctrl-C 归属 | 终端投递给前台组 | `child` 帧 + 命令级 Job |
| PTY | `posix_openpt` | ConPTY（可能丢尾块） |
| 控制台编码 | UTF-8 常态 | 交互前切 65001，退出还原 |
| 路径大小写 | 敏感 | 不敏感（glob 仍受实现影响） |
| `.exe` 解析 | 无 | `PATHEXT`；`which` 要认 |
| Home | `$HOME` | `%USERPROFILE%`（Raku `$*HOME` 已抹平） |

写平台分支时：**行为差异要落成文档与测试**，不要让同一个函数在两端语义漂移。

### 8.11 调试与排障

| 手段 | 用法 | 适用 |
|---|---|---|
| 单测 | `raku -Ilib t/NN.t` | 最快复现 |
| 日志 | `log start /tmp/x.log` → `log show` | 会话级输入/结果 |
| 调试轨迹 | `repl.trace = True`（或 `errors full`） | 看回放帧 |
| 审计 | `audit -n 20` / `audit --origin repl` | 谁在什么时候做了什么 |
| 关闭审计 | `RAKUISH_NO_AUDIT=1` | 排查审计本身 |
| 关闭快照 | `RAKUISH_NO_SNAPSHOT=1` | 排查「恢复导致状态怪」 |
| 指定 rc | `RAKUISH_RC=/tmp/rc.raku` | 排除启动文件干扰 |
| PATH 缓存 | `RAKUISH_PATH_CACHE=off` | 排查「命令找不到/找到旧的」 |
| Arrow 路由 | `RAKUISH_ARROW_NATIVE=1` / `RAKUISH_ARROW_RAKU=1` | 对比两条读路径 |
| 分页 | `RAKUISH_PAGER=never` | 排除分页交互 |
| 引擎状态 | `info`（notebook）/ `Proxy.info` | pid/restarts/index/protocol |

排障原则：**先分层定位**——是输入分类、求值、进程、协议，还是展示？每层都有独立可测的入口；不要一上来就改 `Session`。

### 8.12 性能注意事项

- prelude 切片已把每格从 ~109ms 降到 9–13ms；再加声明时关注传递闭包大小。
- PATH 查找三级缓存：进程内 → 磁盘 → 真扫；缓存键含平台/PATH/PATHEXT。
- 大文件：`read` 有 1 MiB 上限，优先 `read-lines`/`stream`/`head`/`tail`。
- 表格：小数据 `Table`，大数据 `Cursor`/`Stream`；`sort-by`/`unique` 会物化。
- Arrow：单批写入内存占用高时用 `:batch-size` 或 `write-ipc-stream`。
- SQL：把过滤下推到 SQL（`LIMIT` 下推已支持）；不要把大表读成 `Table` 再 `where`。
- 渲染：大结果在 TTY 下会分页；`RAKUISH_PAGER=never` 可跳过交互。

## 9. 附录

### 9.A 模块地图（`lib/Rakuish/`，47 个 provide）

| 模块 | 职责 | 关键入口 |
|---|---|---|
| `CLI` | 进程入口、参数分发、装配 | `run`、`help-text`、`rc-path`、`setup-console`、`page-result` |
| `Kernel` | 唯一执行入口与策略/审计边界 | `Request`、`Policy`、`Kernel.execute`、`capabilities`、`inspect` |
| `Kernel::Factory` | 装配辅助 | `make-kernel`、`make-request` |
| `Kernel::Notebook` | Notebook 协议前端 | `Frontend.handle`、`serve` |
| `Eval` | 父侧引擎客户端 | `Client.start/request/eval/complete/restart` |
| `Eval::Protocol` | 线协议 | `PROTOCOL-VERSION`、`EvalReply`、`check-frame` |
| `Eval::Proxy` | 对前端的 Session 形状门面 | `eval-line`、`render`、`completions`、`!revive` |
| `Eval::Server` | 引擎子进程主循环 | `serve-engine`、`emit` |
| `REPL::Session` | 会话核心：分类/求值/扫描/渲染/配置 | `eval-line`、`!eval-raku`、`eval-script`、`run-rc` |
| `REPL::Shell` | shell 观感命令层 | `handle`、`COMMAND-GROUPS`、`usage` |
| `REPL::Chrome` | banner/prompt/颜色/耗时 | `banner-text`、`prompt-text`、`paint` |
| `REPL::Complete` | 补全算法 | `common-prefix`、`subsequence-rank`、`suggest-suffix` |
| `REPL::Hints` | 上下文提示/结果提示 | `hint-for`、`result-hint` |
| `REPL::Highlight` | 单行词法高亮/错误标记 | `highlight-line`、`error-marks` |
| `REPL::Keymap` | 键位与编辑模式 | `make-cli`、`apply-keymap`、`bind-vi-keys` |
| `REPL::Methods` | `.` 方法补全 | `method-context`、`method-names` |
| `REPL::SqlComplete` | SQL 上下文补全 | `sql-context`、`sql-completions` |
| `REPL::Introspect` | `name?` 内省 | `introspect` |
| `REPL::Plugins` | 插件加载/注册 | `PluginManager` |
| `Incomplete` | 续行判定 | `is-incomplete`、`unclosed-hint` |
| `Sys` | 会话级文件/进程/env 门面 | `resolve`、`exec`、`tty-exec`、`bg-exec`、`try-op` |
| `Sys::FS` | 文件 API | `read`、`read-lines`、`write`、`ls`、`glob`、`stat` |
| `Sys::Proc` | argv-only 进程 API | `spawn`、`exec`、`pipe-exec`、`Handle.wait` |
| `Sys::PosixSpawn` | POSIX 进程组/前台交接 | `spawn-in-group`、`signal-group`、`set-foreground` |
| `Sys::JobTable` | 后台作业表 | 登记/查询/清理 |
| `Sys::WinJob` | Win32 Job Object | `create`、`assign`、`terminate` |
| `Sys::Console` | Windows 控制台 UTF-8 | `ensure-utf8-console`、`restore-console` |
| `Sys::Term` | 终端尺寸/真控制台判定 | `term-size`、`stdout-is-console` |
| `Result` | 统一结果值 | `ok/code/out/err/value/rendered/streamed` |
| `Result::Renderer` | text/json/markdown/html | `render-result`、`available-formats` |
| `Display` | 内容级 MIME 展示包 | `Bundle`、`bundle-from`、`capabilities` |
| `Audit` | 每操作一条 JSONL | `record`、`entries`、`by-origin` |
| `Snapshot` | 快照判定/捕获/落盘 | `classify`、`capture`、`save/load` |
| `Store` | 跨会话变量库 | `load/save`、`entry` |
| `Command` | 命令元数据/注册表 | `CommandSpec`、`CommandRegistry`、`BuiltinCommand` |
| `DSL` | 注入 REPL 的短函数 | `exec`、`open-data`、`stream`、`sql`、`display` |
| `Data` | 数据文件读写总入口 | `open-data`、`save-data`、`tableify` |
| `Data::Table` | 列式表格 | `where/select/join/sql/to-text` |
| `Data::Stream` | 惰性记录流 | `where/select/exec/zip/join/tee` |
| `Data::Cursor` | 分批游标 | `next-batch`、`batches`、`close` |
| `Data::Engine` | 引擎角色 | `query/execute/begin/commit` |
| `Data::Engine::DuckDB` | DuckDB 适配器 | 同上 + CSV/Parquet/线程/内存限制 |
| `Data::Engine::SQLite` | SQLite 适配器 | 同上 + `busy-timeout`/interrupt |
| `Data::Duck` | DuckDB/Duckula 桥 | `query`、`table-sql`、`read-arrow-native` |
| `Data::Arrow` | Arrow IPC 读写 | `read-ipc`、`write-ipc`、`write-ipc-stream` |
| `Data::CsvOptions` | CSV 方言白名单 | `normalize-csv-options` |
| `Data::Pager` | 前端分页 | `paginate`、`wants-page`、`mode` |

另有 `bin/rakuish`、`bin/rakuish-notebook` 两个入口。

### 9.B 环境变量

| 变量 | 默认 | 作用 |
|---|---|---|
| `RAKUISH_AUDIT` | `$*HOME/.rakuish/audit.jsonl` | 审计文件路径；都不可用则纯内存 |
| `RAKUISH_NO_AUDIT` | 空 | 非空即关闭审计 |
| `RAKUISH_SNAPSHOT` | `$*HOME/.rakuish/session-<cwd指纹>.json` | 快照路径 |
| `RAKUISH_NO_SNAPSHOT` | 空 | 非空即停读停写 |
| `RAKUISH_SNAPSHOT_MAX` | `1000000` | 单值字符上限；`0/off/none` 不限 |
| `RAKUISH_RC` | `~/.rakuish/rc.raku` | 启动文件；旧 `~/.rakuishrc` 需显式指定 |
| `RAKUISH_NO_RC` | 空 | 非空即跳过启动文件 |
| `RAKUISH_PAGER` | `auto` | `auto` / `always` / `never` |
| `RAKUISH_STORE` | `~/.rakuish/store.json` | 跨会话变量库路径 |
| `RAKUISH_CONFIG` | `~/.rakuish/config.json` | 配置路径 |
| `RAKUISH_PATH_CACHE` | 开 | `off/none/0` 关闭 PATH 磁盘缓存 |
| `RAKUISH_ARROW_NATIVE` | 空 | 强制 Arrow 读走原生/包路径（诊断） |
| `RAKUISH_ARROW_RAKU` | 空 | 强制 Arrow 读走纯 Raku 路径（诊断） |
| `NO_COLOR` | 空 | 标准约定：非空即关色 |

### 9.C 公开 API 速查（DSL / `Sys`）

```raku
# 文件
sys.read($path);            sys.read-lines($path);     sys.write($path, $text);
sys.append($path, $text);   sys.ls($path);             sys.ls-table($path);
sys.stat($path);            sys.glob($pattern);        sys.rm($path, :r, :f);
sys.cp($src, $dst);         sys.mv($src, $dst);        sys.mkdir($path);
sys.cd($path);              sys.pwd;                   sys.resolve($path);

# 进程
sys.exec($exe, *@args, :$timeout-ms, :$max-bytes, :$stdin);
sys.tty-exec($exe, *@args);
sys.pty-exec($exe, *@args, :$timeout-ms, :$cols, :$rows);
bg-exec($exe, *@args);      bg-jobs();                 fg($job);   bg($job);

# 数据
open-data($path, :$raw);    save-data($path, $value, :$batch-size);
open-db($path);             $db.query($sql);            $db.execute($sql);
stream($src, :$format);     table-sql(@tables, $sql);
read-ipc($path);            write-ipc($table, $path, :$batch-size);

# 展示/工具
display($value);            timed { ... };              bench 5 => { ... };
recent(10);                 cmd('hello', @args);        help('api');
```

`Result` 的稳定字段：`ok`、`code`、`out`、`err`、`value`、`op`、`elapsed`、`streamed`、`no-newline`、`rendered`。失败不抛；需要异常用 `cmd()`。

### 9.D 测试矩阵（79 个文件）

| 文件 | 覆盖 | 备注 |
|---|---|---|
| `t/01-sys-fs.t` | Sys 文件 API、symlink、编码、锁 | 符号链接失败 skip |
| `t/02-sys-session.t` | 会话 cwd/env、root、try-op | Windows 专属 env 断言 |
| `t/03-sys-proc.t` | spawn/exec/stdin/超时/jobs/上限 | 真实子进程 |
| `t/04-dsl-command.t` | Command/注册表/DSL/timed/recent | — |
| `t/05-repl-session.t` | 求值语义、历史、Out、prelude | — |
| `t/07-entrypoints.t` | 唯一入口、无 v2/Agent/magic、`-e` | 真实子进程 |
| `t/08-result-render.t` | text/json/markdown | — |
| `t/09-repl-display.t` | 内置命令人读展示 | — |
| `t/10-repl-shell.t` | Shell 观感层、裸路径参数 | 平台分支 |
| `t/11-data-table.t` | Table/JSON/CSV/ls-table | — |
| `t/12-data-engine.t` | DuckDB 适配器 | 缺依赖 skip |
| `t/13-data-sqlite.t` | SQLite 适配器 | 缺依赖 skip |
| `t/14-explore.t` | `explore` + 非 TTY 全文 | — |
| `t/15-repl-ui.t` | Chrome/计时、管道无 ANSI | 接管 `NO_COLOR` |
| `t/17-data-parquet.t` | Parquet、LIMIT 下推、SQL 错误 | 缺依赖 skip |
| `t/18-repl-types-glob.t` | class/role/grammar 跨格、glob | — |
| `t/19-repl-experience.t` | Vi/Helix、hints、插件 | 行编辑器失败 skip |
| `t/20-data-cursor.t` | Cursor 三层 | 缺依赖 skip |
| `t/22-data-csv.t` | CSV 受控外部读写 | 缺依赖 skip |
| `t/23-sql-complete.t` | SQL 补全 | `open-db` 链路 skip |
| `t/24-csv-dialect.t` | CSV 方言/注入防护 | — |
| `t/25-describe-complete.t` | `describe` + 补全启发式 | 缺依赖 skip |
| `t/26-nested-repl.t` | 嵌套 REPL/TTY 直通 | PTY 段 Windows skip |
| `t/27-interrupt.t` | Ctrl-C 清续行 | Windows skip |
| `t/28-pty-exec.t` | `pty-exec` 契约 | 依赖本机 pty |
| `t/29-pty-capability.t` | PTY 能力探测/127 | 子类注入旧 Rakudo |
| `t/30-tty-exec-sigint.t` | tty-exec 的 Ctrl-C 归属 | Windows 整段 skip |
| `t/31-tty-termios.t` | termios 快照/恢复 | PTY 段 Windows skip |
| `t/32-job-control.t` | POSIX 进程组交接 | Windows skip |
| `t/33-colors.t` | 结果着色 + 行高亮 | 平台分支 |
| `t/34-userland.t` | 选项补全、doc、日志、目录栈 | — |
| `t/35-kernel.t` | Kernel/Request/Policy 双路径 | — |
| `t/36-console-utf8.t` | Windows 码页收口 | 非 Windows no-op |
| `t/37-command-table.t` | 命令名单单一数据源 | — |
| `t/38-display.t` | DisplayBundle/op 通道降级 | — |
| `t/40-audit.t` | 三种 origin 同账 | — |
| `t/41-eval-worker.t` | 协议帧/崩溃重启/状态告知 | 真实 worker |
| `t/42-snapshot.t` | 快照 classify/capture/恢复 | — |
| `t/43-interrupt.t` | 求值期 Ctrl-C 归因 | Windows skip |
| `t/44-exec-stream.t` | `!` 流式/元选项 | — |
| `t/45-startup.t` | rc/prompt/`set -o` | — |
| `t/46-stream.t` | 结构化管道与惰性边界 | — |
| `t/47-pager.t` | 分页策略/切页 | 注入读写 |
| `t/48-exec-stdin.t` | `Stream.exec` stdin | 字节一致 |
| `t/49-merge.t` | zip/join/tee | — |
| `t/50-interleave-append.t` | interleave/append | — |
| `t/51-meta-provides.t` | `provides` 与 `lib/` 对应 | — |
| `t/52-load-all-modules.t` | 每模块 require | 编译冒烟 |
| `t/53-line-endings.t` | 文本不得 CRLF | — |
| `t/54-job-api.t` | bg-exec/bg-jobs/fg/bg | Windows skip |
| `t/55-follow.t` | `tail -f` 回调跟随 | — |
| `t/56-follow-pty.t` | `tail -f` 真 PTY | Windows skip |
| `t/57-feel-complete.t` | 补全纯函数 | — |
| `t/58-feel-field.t` | 灰字/菜单/Ctrl-R | — |
| `t/59-feel-pty.t` | 手感真 PTY 冒烟 | Windows skip |
| `t/60-followups.t` | In/Out 补全、名字判定 | — |
| `t/61-junction.t` | Junction 值契约 | — |
| `t/62-use-import.t` | `use` 跨格 | — |
| `t/63-method-complete.t` | 方法补全 | — |
| `t/64-who-rerun.t` | who/whos/rerun/`x?` | — |
| `t/65-notebook-frontend.t` | Notebook 协议/子进程/死亡推送 | 真实子进程 |
| `t/66-jupyter-wrapper.t` | Jupyter wrapper 静态守护 | — |
| `t/67-audit-command.t` | `audit` 查询 | — |
| `t/68-source.t` | `source` 双向共享 | — |
| `t/69-export.t` | `cells` 导出可重放 | — |
| `t/70-arrow-ipc.t` | Arrow 读写 | 仓内夹具 |
| `t/71-win-job.t` | Windows Job 子树回收 | POSIX skip |
| `t/72-main-dispatch.t` | 脚本 `sub MAIN` | 真实子进程 |
| `t/73-buf-render.t` | Buf/Blob 摘要 | — |
| `t/74-arrow-read.t` | Arrow 读侧分流 | 依赖缺失 skip |
| `t/75-ctrl-c-child.t` | `child` 帧 pid 回调 | 非 Windows skip |
| `t/76-duck-sql.t` | Table ⟷ DuckDB SQL | 缺依赖 skip |
| `t/77-arrow-write-batches.t` | Arrow 多批/流式写 | — |
| `t/78-arrow-fast-path.t` | DuckDB 标量快路一致性 | 缺依赖 skip |
| `t/79-p0-regressions.t` | IPython 对照 7 个 P0 | — |
| `t/80-display-protocol.t` | to-mime/额外 MIME | — |
| `t/81-store.t` | 跨会话变量库 | — |
| `t/82-errors-recall.t` | 错误分级/recall | — |
| `t/83-pipe.t` | 引擎内 `! a \| b` | 真实子进程 |

真实子进程/PTY 冒烟：`03/07/10/26/27/28/29/30/31/32/41/42/43/44/45/54/56/59/65/71/72/75/83`。其中 26/27/30/31/32/54/56/59 由 Python `pty.fork()` 驱动真 controlling terminal（Windows 整段 skip）。

### 9.E ADR 全表（57 条）

| ADR | 主题 | 状态 |
|---|---|---|
| 0001 | 不再实现 bash / POSIX 子集 | Accepted |
| 0002 | Agent 多客户端服务与请求级取消 | 已撤销（0.81） |
| 0003 | Vi/Helix 模态、hints、插件 | 已实施 |
| 0004 | 流式 Cursor 与连接级 worker 硬取消 | Accepted |
| 0005 | CSV 受控外部读写 + Engine 元数据 | Accepted |
| 0006 | CSV 方言 / describe / 补全启发式 | 已接受 |
| 0007 | 交互式子进程 TTY 直通 | 已接受 |
| 0008 | 输入中断语义与 SQL 补全形态 | 已接受 |
| 0009 | `tty-exec` 期间 Ctrl-C 归属契约 | 已接受 |
| 0010 | job control 可行性评估 | 已实施（有边界） |
| 0011 | 结果着色与输入行高亮 | 已实施 |
| 0012 | 用户层四项能力 + 三处订正 | 已实施 |
| 0013 | 人机共用内核与显示协议 | 部分实施（Agent 半边作废） |
| 0014 | Windows 控制台码页收口 | 已实施 |
| 0015 | 命令名单一数据源 + 输入序/格号分离 | 已实施 |
| 0016 | 展示包与格式协商 | 已实施（Agent 半边撤销） |
| 0017 | 流式分帧与请求取消 | 已撤销 |
| 0018 | 统一审计 + 不给 Agent 脚本路径 | 部分撤销 |
| 0019 | 放弃 Agent 线，做全权限本地 shell | Accepted |
| 0020 | Policy 只留有执行点的字段 | Accepted |
| 0021 | 求值引擎住子进程 | Accepted |
| 0022 | 会话快照：声明与纯值跨崩溃存活 | Accepted |
| 0023 | 求值期间的 Ctrl-C | Accepted |
| 0024 | `!` 的流式输出与超时选项 | Accepted |
| 0025 | 启动文件 / 可编程 prompt / `set -o` | Accepted |
| 0026 | 结构化管道：`Stream` 与记录喂子进程 | Accepted |
| 0027 | 前端分页 | Accepted |
| 0028 | `Stream.exec` 的 stdin 流式化 | Accepted |
| 0029 | `zip` / `join` / `tee` | Accepted |
| 0030 | `interleave` / `append` | Accepted |
| 0031 | MoarVM 下的作业控制 API | Accepted |
| 0032 | 退出残留线程消解与展示契约收口 | Accepted |
| 0033 | `tail -f` 跟随 | Accepted |
| 0034 | 交互手感层 | Accepted |
| 0035 | 手感后续 | Accepted |
| 0036 | 输入循环自研评估 | Accepted（暂不实施） |
| 0037 | Notebook 前端：协议层先于传输层 | Accepted |
| 0038 | Arrow IPC 自己解析 | Accepted |
| 0039 | Windows 子树回收用 Job Object | Accepted |
| 0040 | 脚本模式 MAIN 分派交给 RUN-MAIN | Accepted |
| 0041 | Arrow 读侧依赖 Arrow::IPC | Accepted |
| 0042 | Windows Ctrl-C 只收外部命令 | Accepted |
| 0043 | Table SQL 交 DuckDB/Duckula | Accepted |
| 0044 | Arrow 读侧按类型分流 | Accepted |
| 0045 | Arrow 写侧多批与流式 | Accepted |
| 0046 | 只支持标准 Rakudo | Accepted |
| 0047 | Arrow 原生读（标量走自研） | Accepted |
| 0048 | 显示协议：`display` 与 MIME | 已实施 |
| 0049 | Windows cmd 内建白名单 | 已实施 |
| 0050 | prelude 按需切片 | 已实施 |
| 0051 | 引擎协议契约与校验 | 已实施 |
| 0052 | 块输入 paste | 已实施 |
| 0053 | 跨会话变量库 | 已实施 |
| 0054 | 错误分级与 recall | 已实施 |
| 0055 | PATH 可执行文件缓存 | 已实施 |
| 0056 | 引擎内 `! a \| b` 管道 | Accepted |
| 0057 | 父进程交互式管道 | Accepted |

### 9.F 术语表

| 术语 | 含义 |
|---|---|
| 格（cell） | 一次提交的输入单元；多行算一格 |
| `Out[n]` | 第 n 个**成功**结果；`_` 是最新值 |
| `In[n]` | 产生 `Out[n]` 的输入源码 |
| prelude | 每格前置重放的声明切片 |
| 声明格 | 只含 `sub/use/class/role/grammar/enum/...` 的格，可缓存 |
| 引擎 | `raku` 子进程，承载真正的 `Session`/`EVAL` |
| 父进程 | 持有终端、行编辑、审计、作业表的进程 |
| 中间帧 | 处理请求期间由引擎插入的 `chunk/tty/pipe-exec/job/input/child/error_info` |
| 结构化管道 | `Stream` 方法链，不是 `\|` 语法 |
| 惰性边界 | 阶段何时真正消费上游；`sort-by/unique/group-by` 会物化 |
| 物化 | 把流全部读入内存（`Table`/`Array`） |
| root | 会话允许访问的根目录，`Sys.resolve` 强制 |
| origin | 审计来源：`repl` / `script` / `notebook` |
| 失效值 | 快照中不可序列化的项（资源、闭包、超限） |
| 纯值 | 可 JSON 序列化的值；快照只恢复这一类 |

### 9.G 相关文档

| 文档 | 用途 |
|---|---|
| [`MANUAL.md`](MANUAL.md) | 用户手册：所有命令/选项/示例 |
| [`SPEC.md`](../SPEC.md) | 条款真值（`V-xxx`），行为变更的最终依据 |
| [`ADR-INDEX.md`](ADR-INDEX.md) | 57 份 ADR 的目录、状态、一句话结论 |
| [`ADR-0001-raku-native.md`](ADR-0001-raku-native.md) | 为什么删 bash 子集（必读） |
| [`ADR-0019-local-full-privilege-shell.md`](ADR-0019-local-full-privilege-shell.md) | 为什么删 Agent 线 |
| [`ADR-0021-eval-worker.md`](ADR-0021-eval-worker.md) | 引擎子进程 |
| [`ADR-0022-session-snapshot.md`](ADR-0022-session-snapshot.md) | 快照边界 |
| [`ADR-0036-input-loop-ownership.md`](ADR-0036-input-loop-ownership.md) | 输入循环为何不自研 |
| [`ADR-0037-notebook-frontend.md`](ADR-0037-notebook-frontend.md) | Notebook 协议 |
| [`ADR-0044-arrow-read-routing.md`](ADR-0044-arrow-read-routing.md) | Arrow 读侧分流 |
| [`ADR-0057-parent-pipeline.md`](ADR-0057-parent-pipeline.md) | 0.144 交互式管道 |
| [`ADR-0058-process-handle-stream.md`](ADR-0058-process-handle-stream.md) | 进程句柄与流式 stdout（草案） |
| [`ADR-0059-pipe-passthrough.md`](ADR-0059-pipe-passthrough.md) | 0.145 管道透传 |
| [`HANDOFF.md`](../HANDOFF.md) | 交接：现状、规则、剩余缺口 |
| [`docs/CI.md`](CI.md) | 构建机/无 TTY 安装 |
| [`docs/HANDOFF-2026-11-24-arrow.md`](HANDOFF-2026-11-24-arrow.md) | Arrow 三仓库交接 |

---

### 维护本文

- 版本号、测试数、ADR 数变化时，更新开头的「事实口径」。
- 新增一个功能：在 §5 加一小节（怎么用/怎么实现/边界），并在 §9.D 测试矩阵补一行。
- 新增一个 ADR：在 §9.E 补一行，并回写 `ADR-INDEX.md`。
- 新增一个坑：加进 §7.2 对应领域，写清「现象/原因/现在做法」——不要只写结论。
- 本文不替代 `SPEC.md`；两者冲突时以 `SPEC.md` 为准。

<!-- END -->







