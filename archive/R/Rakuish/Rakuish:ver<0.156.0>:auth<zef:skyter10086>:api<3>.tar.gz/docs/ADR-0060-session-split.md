# ADR-0060：Session 拆分步 —— 语言层允许什么、不允许什么

- 状态：已实施（0.146.0 / SPEC V-350）
- 相关：[ADR-0036](ADR-0036-line-editor.md)（不做行编辑注入）、[ADR-0051](ADR-0051-engine-protocol-contract.md)（协议帧）、SPEC §3.79
- 取证方式：Rakudo Star **v2026.11**（本机 Windows）四次探针 + 全套件回归

## 1. 背景

`lib/Rakuish/REPL/Session.rakumod` 在 0.14x 期间从 **3,519 行**涨到 **4,304 行**，同时带着 **65 个 `has` 属性** 和 **126 个方法**。它同时负责：求值调度、跨格状态（`%!state` / `@!decls`）、`Out[n]` 记账、快照、错误分级、21 条会话命令、补全、按键分发。

评审里「Session 是上帝类」不是审美问题，而是**可维护性事故的温床**：任何一条命令的改动都要在一份 4,300 行的文件里定位，而 git 的 diff 也失去可读性。

拆分的困难不在「怎么拆」而在 **Raku 的语言层**：Raku 的私有属性（`$!x` / `%!x`）只在声明它的类内可见，没有 Java 那种 `package-private`，也没有 C++ 的 `friend`。所以「把方法搬到另一个类，让它继续用原来的私有状态」这件事，取决于语言允许什么。

## 2. 取证：四次探针，逐条钉死

### 2.1 `trusts` —— 完全不可用

Raku 规范里有 `class A trusts B` 这个 trait，用于跨类访问私有属性。本机实测**四种写法全部解析失败**：

| 写法 | 结果 |
|---|---|
| `class A trusts B {` | `Unable to parse class definition`，箭头停在 `class A<HERE> trusts B {` |
| `class A is Mu trusts B {` | 同上 |
| `class A trusts (B) {` | 同上 |
| `class C2 trusts R2 does R2 { }` | 同上 |

**结论**：`trusts` 在 Rakudo v2026.11 未实现。这条路不存在，不要再试。

### 2.2 role 方法读「类声明的」私有属性 —— 失败

```raku
role R1 { method read-class-attr() { %!h<a> } }
class C does R1 { has %!h = %(a => 7) }
```

→ `Attribute %!h not declared in role R1`。反方向也对称：类方法调 role 的私有方法 → `No such private method '!role-priv' for invocant of type 'C'`。

**结论**：`does` 不会让 role 看见类的私有属性。私有属性是「声明者专属」，不是「对象专属」。

### 2.3 role 自己声明属性、类 `does` 它 —— 两边都能读

```raku
role R { has %!cfg = %(a => 1); method role-reads() { %!cfg<a> } }
class C does R { method class-reads() { my $v = try { %!cfg<a> }; $v } }
```

→ role 读到 `1`，**类方法也读到 `1`**。因为属性归属 role，组合时进了同一个对象的名字空间。

这条是可行的拆法之一：**属性跟着方法一起搬进 role**。

### 2.4 决定性发现 —— role 方法走**公开访问器**，效果等同私有属性

```raku
role R {
    method r-read()     { $.pub }              # 读
    method r-write()    { $.pub-rw = 5 }       # 写标量
    method r-hashset()  { $.h<k> = 'v' }       # 写哈希
    method r-arrpush()  { $.arr.push(9) }      # 改数组
    method r-callmeth() { $.helper.usage }     # 调另一个对象的公开方法
    method r-flag()     { $.flag = True }      # 写布尔
}
class C does R {
    has $.pub = 1;  has $.pub-rw is rw = 0;
    has %.h is rw = %();  has @.arr is rw;
    has $.helper;  has Bool $.flag is rw = False;
}
```

六项**全部通过**，而且写回真的落到原对象上（类的 `check-*` 方法读到 5 / `k,k2` / 1 / True）。

**结论（本 ADR 的核心）**：只要属性是 `$.x` / `%.x` / `@.x`（公开），role 方法就可以用 `$.x = v` / `%.x<k> = v` / `@.x.push(v)` 读写它 —— 和类内部用 `$!x` 的最终效果一致。

于是拆分从「搬状态」降级成「搬方法 + 把 `$!x` 改写成 `$.x`」，**风险量级完全不同**。

一个语法坑：`$.h{k} = 'v'`（键是裸词或变量）会报 `Undeclared routine: k` —— `{...}` 被当成 block 而不是下标。字面量键写成 `$.h<k>`，变量键写成 `my %h := $.h; %h{$k} = v`。

### 2.5 `unit class Foo does Bar;` 可用

不必把 `unit class` 改成带花括号的具名 class（那需要给 4,000 行文件补一对括号）。`use` 语句可以写在 `unit` 之前，`does` 在声明处解析得到。

## 3. 决定

### 3.1 抽两个 role

| 文件 | 内容 | 行数 |
|---|---|---|
| `lib/Rakuish/REPL/Session/Commands.rakumod` | `!cmd-errors` + 它独占的三个属性 | 49 |
| `lib/Rakuish/REPL/Session/Config.rakumod` | 配置 / 别名 / `set -o` 选项 / hook / plugin，共 16 个方法 | 295 |
| `lib/Rakuish/REPL/Session.rakumod` | 其余 | 4,304 → **4,035** |

Session 的声明改成：

```raku
use Rakuish::REPL::Session::Commands;
use Rakuish::REPL::Session::Config;

unit class Rakuish::REPL::Session does Rakuish::REPL::Session::Commands
                                  does Rakuish::REPL::Session::Config;
```

### 3.2 属性归属规则（本 ADR 定下的唯一规矩）

> **属性一律留在 Session，role 方法经公开访问器读写。**
> 只有「类方法也必须写」的属性才跟着方法搬进 role。

按这条规矩，第一刀只搬走了三个属性（`$.error-mode` / `$!last-error-kind` / `$!last-error-loc`）—— 因为 `!eval-raku` 的 `CATCH` 在**类里**写后两个，而 role 方法又要读它们。

其余 34 个被命令引用的属性全部留在 Session，Config role 里 11 类 `$!x` 改写成 `$.x`：

| 私有写法 | 访问器写法 | 引用数 |
|---|---|---|
| `%!config` | `%.config` | 20 |
| `$!plugins` | `$.plugins` | 5 |
| `$!shell` | `$.shell` | 4 |
| `$!commands` / `$!sys` / `$!exit-requested` | `$.commands` / `$.sys` / `$.exit-requested` | 2 / 1 / 1 |
| `$!xtrace` / `$!noglob` / `$!noexpand` / `$!histexpand` / `$!strict` | 同名 `$.x` | 各 2 |

### 3.3 为什么先搬配置组

用脚本对 45 个可搬方法做了「属性引用内外分布」统计：

| 属性 | 命令内 | 命令外 | 能整组搬吗 |
|---|---|---|---|
| `%!config` | 18 | **0** | 能 |
| `$!store-path` / `$!audit` | 1 | 0 | 能 |
| `@!decls` | 5 | **33** | 不能 |
| `%!state` | 9 | **26** | 不能 |
| `@!history` | 15 | **23** | 不能 |
| `$!sys` | 11 | 19 | 不能 |
| `@!out` | 4 | 14 | 不能 |

`%!config` 是**唯一**一个「命令内 18 次、命令外 0 次」的大簇 —— 它天然自成一个子系统。所以第一刀切在配置/别名/选项/hook 上，而不是切「所有 `!cmd-*`」。

## 4. 没有采用的方案

### 4.1 「一个 `Commands` 类，构造时把 Session 传进去」

看起来最干净（真正的依赖倒置），但按上表，21 条命令共需约 30 个跨对象访问器，而这些属性里 `%!state` / `@!decls` 是**私有**的。要么把它们全部改成公开（等于把内部状态做成 API），要么给协作者传一个「闭包宿主」（`state-get` / `hist-push` / `prefill-set` …）。后者用探针验证过可行（写回真的落回原对象，连 `%!state` 的容器都是真的），但 30 个访问器的 plumbing 会让「搬命令」变成「重写命令」，与本版「行为不变」的目标冲突。

**这一步留到下一个版本**，并且应该先有独立 ADR 讨论「内部状态要不要成为公开 API」。

### 4.2 「把 `!cmd-*` 连 `%!state` / `@!decls` 一起搬进一个角色」

机械上可行（role 拥有属性即可），但结果是 **role 反向拥有会话核心状态**，类方法去读 role 声明 —— 文件小了，耦合反而更隐蔽。拒绝。

### 4.3 「把 Session 改成 `class ... { }` 具名形态，好让文件末尾补括号」

4,000 行文件补一对括号的收益是零，风险是把缩进/heredoc 弄坏。`unit class ... does ...;` 已验证可用，用它。

## 5. 不变量（本版必须成立）

- **行为完全不变**：全套件 79 文件 / 3,827 条断言 problems=0；`t/82` 88/88（`errors`）、`t/37` 91/91（命令表）、`t/05`/`t/10`/`t/18` 全绿。
- 不改协议帧、不改快照格式、不改 `Out[n]` 记账、不改 `!` 命令路由。
- 公开面只增不减：`options` / `run-hooks` / `config-path` 等搬走后仍是可调用方法（role 组合进来）。
- `META6.json` provides 加两条（`t/51` 会拦「lib 下有文件、provides 里没有」）。

## 6. 结构守卫：`t/84-session-split.t`

拆分本身也要有断言，否则下一个人会把命令写回 Session。34 条：

1. 三个文件都在；两个 role 的 `unit role` 头正确；Session 的 `does` 两条都在，且 `use` 在 `unit` 之前。
2. **反方向**：`!cmd-errors` 不在 Session；7 个搬走的命令/辅助方法不在 Session 而在 Config；`run-hooks` / `options` 同理。
3. 规模上限：`cmp-ok $sess-lines, '<', 4150` —— 比拆分前的 4,304 小，比现在的 4,035 宽松。允许正常增长，不允许把命令搬回来。
4. 运行时：`$s.options` 仍是 5 项且名字不变、`run-hooks('no-such-event')` 返回空、`$s.histexpand` 为真（证明 role 真的读到了公开访问器，而不是只搬了文本）。

## 7. 下一步（明确留给后续版本）

- 配置层之后，下一个天然簇是**诊断/渲染**（`!cmd-tb` / `!cmd-audit` / `!cmd-log` / `!cmd-perf` / `!cmd-who` / `!cmd-hint` / `!render-trace` / `collect-traceback` / `!sigil-rank` / `!value-type` / `!value-size`，约 250 行）。阻塞点是 `@!decls` / `@!out` / 日志三兄弟仍是私有 —— 需要先决定「公开还是传闭包宿主」。
- `:!cmd-store` / `:!cmd-cells` / `:!cmd-source` 是最大的一块（约 570 行），依赖 `%!state` / `@!decls` / `@!cells` / `@!pending` / `$!sys`，应当最后动。
