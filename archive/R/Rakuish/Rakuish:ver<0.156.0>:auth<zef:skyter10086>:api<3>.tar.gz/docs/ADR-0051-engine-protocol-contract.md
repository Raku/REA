# ADR-0051 · 引擎协议契约：版本握手与帧校验

- **日期**：2026-11-26
- **对象**：`Rakuish::Eval`（Client）、`Rakuish::Eval::Server`、新增 `Rakuish::Eval::Protocol`
- **状态**：**已实施（0.133.0）**。条款：SPEC V-335；回归见 `t/41`。
- **输入**：V3 架构审计「硬伤 2：Engine 协议无契约、无版本、无 schema」
- **相关**：ADR-0021（引擎子进程）、ADR-0024（chunk 帧）、ADR-0048（display 帧）、
  ADR-0037（notebook 前端）

## 1. 问题

引擎协议（一行一个 JSON）从 0.83 起长到 0.132：`ready` / `result` / `chunk` /
`tty` / `job` / `child` / `input_request` / `completions` / `marks` / `key` /
`inspect` / `info` / `history` / `prompt` / `rc` / `restored` / `error` / `fatal`，
字段一路加。但：

1. **没有版本**。升级后 REPL 不重启引擎，就会「新前端 + 旧引擎」；第三方前端
   或远程引擎更是无从判断。两端没有任何协商机制。
2. **没有 schema**。字段名只存在于 Server 的 Hash 字面量与 Client 的
   `// 默认值` 里。改一个名字（`text` → `rendered`），Client 读到 `Any`，
   `// ''` 兜底 → 前端显示空字符串，**不抛异常、不报错**。
3. **error 帧被当普通终帧**。引擎自己报的协议/序列化错误（`event=error`）
   走到 `Client.request` 时没有对应分支，落在「seq 匹配就返回」那条路上；
   Proxy 读不到 `ok`/`err`，用户看到一个空结果。
4. 帧形状散落：0.132 的 P2.5 往 `result-frame` 里塞 `ename/evalue/traceback`
   时连函数签名都没改 —— 没有任何地方能 review「契约变了」。

## 2. 决策

**把协议收成一个模块：`Rakuish::Eval::Protocol`。**

1. **`PROTOCOL-VERSION`**（当前 `2`；本 ADR 落地时为 `1`，v2 见 §6）独立于
   META6 的 `api<3>`：api 是模块 API，协议是进程间线格式，各自演进。
   协议版本从 1 开始（0.83–0.132 的既有线格式，本 ADR 首次把它写成契约）。
2. **双向握手**：
   - 引擎的 `ready` 帧带 `protocol`；Client 启动时比对，不符/缺失抛
     `X::Rakuish::Protocol`。缺字段的提示是「多半是升级残留的旧引擎进程，
     退出 REPL 重开即可」——这正是运维时最常踩的那种。
   - Client 的**每个请求**带 `protocol`；Server 在分发前校验，不符就发
     `fatal` 帧并退出循环（不猜、不降级）。
3. **帧形状单一来源**：
   - `EvalReply` 类：`result` 帧的字段、默认值、`to-hash` / `from-hash`。
     Server 用它构造，Client 用它解构。带连字符的字段（`exit-code`）
     用 Hash 摊平传（`:exit-code` 在 Raku 里不是合法命名参数）。
   - `FRAME-FIELDS` 表：其余终帧（completions / marks / key / inspect / info /
     history / prompt / rc / restored）的必填字段。
   - `check-frame`：终帧校验入口。缺字段、未知帧类型 → `X::Rakuish::Protocol`
     （异常里带原始帧 JSON）；`error` 帧 → 折成一条失败的 `result` 帧。
4. 版本不匹配时**不做兼容映射**：同一份安装里两端必然同版本；出现不一致就是
   「该重启/该升级」，明确报错比猜测安全。

## 3. 边界

- **只管终帧与握手**。中间帧（`chunk` / `tty` / `job` / `child` /
  `input_request`）仍在 `Client.request` 的 `given` 里就地处理 —— 它们的
  消费点是父进程的副作用（打印、终端交接、stdin），不是数据契约。
  v2 的 `error_info` 是例外：它同样在 `given` 里消费，但字段表
  （`ERROR-INFO-FIELDS`）与终帧同等对待 —— notebook 的错误渲染依赖它。
- **不做 typed class 全覆盖**。只有 `result` 帧值得 typed（字段最多、跨
  3 个前端消费）；其余用字段表校验，避免为 8 个 2~9 字段的帧各造一个类。
- **v1 不改线格式**：字段名/嵌套（`display.displays`）与 0.132 完全一致，
  升级不需要迁移；变的只是「两端都按同一份定义检查」。v2 有意改了线格式
  （见 §6）—— 版本号升到 2，正是让「两端不一致」显式失败而不是静默读空。
- **不做远程引擎的防御性校验**：今天引擎是同机同版本子进程。真要支持远程，
  才需要在 Client 侧校验 JSON 类型（现在 `from-hash` 只验存在性与基本类型
  转换）。

## 4. 代价

- `result` 帧多一次 `from-hash` → `to-hash` 的往返（十几微秒，跑在每格一次
  的路径上，实测无感）。
- 新增一个模块与一条 META6 provides（`t/51` 守护）。
- 协议再改字段时，必须同时改 `EvalReply` 与（若语义变了）`PROTOCOL-VERSION`。

## 5. 验收

`t/41` 第 ⑤ 组（17 条）：

| 场景 | 期望 |
|---|---|
| `PROTOCOL-VERSION` | 存在且为 2 |
| 真引擎启动 | `client.protocol == PROTOCOL-VERSION`（握手成功） |
| ready 缺 `protocol` / 版本 99 | `X::Rakuish::Protocol` |
| `EvalReply` 往返 | `text` / `display` / `displays` / `exit-code` 都不丢 |
| result 缺字段 / 未知终帧 | `X::Rakuish::Protocol` |
| `event=error` 帧 | 折成 `result`、`ok=False`、消息进 `err` |
| 真引擎 `die` | result 帧**不含** ename；`last-error-info` 带 ename 与 traceback |

## 6. 0.135.0 修订（v2）：错误详情移出 result 帧

**动机**：0.132.0（P2.5）为 Jupyter error reply 在 `Result` 上加了
`ename` / `evalue` / `traceback`。这三个是**前端形状**，TTY 完全不用；
放在通用结果类型上等于让一个对象同时承载两套前端语义（架构审计硬伤 3）。

**变更**：

- `PROTOCOL-VERSION` 1 → 2。
- `EvalReply` 与 result 帧删除 `ename` / `evalue` / `traceback`。
- 失败格由 Server 在 result 终帧之前 emit `event=error_info`
  （`seq` / `ename` / `evalue` / `traceback`），形状由
  `ERROR-INFO-FIELDS` + `check-error-info` 定义并校验。
- `Rakuish::Result` 删除这三个字段。
- Client 在每个请求开头清空 `last-error-info`，循环里消费 `error_info`；
  Proxy 暴露同名属性；Notebook Frontend 从 `session.last-error-info`
  拼 Jupyter 形状（execute reply 的三键不变，前端零改动）。TTY 不读它。

**边界**：`error_info` 仍**不在**终帧字段表里 —— 它没有 `ok` / `code`
这类终态语义，只是错误渲染的附加信息；缺了它，失败格仍然是失败格
（`err` 已有文本），前端退化成无红色回溯。

## v3 修订（0.136.1 / V-340）：协议流句柄不参与用户代码的动态替换

**问题**：`emit` 写 `$*OUT`、`read-msg` 读 `$*IN`，而 Session 在求值一格时
`temp $*OUT = $cap`（捕获缓冲），并在 prompt 所在的 `do {}` 块里
`temp $*IN = _RakuishIn`。于是引擎**从格内部**发出的帧写进该格的捕获缓冲
（前端收不到），而 `read-msg` 读回的是 `_RakuishIn` → `get` → input-handler
→ `read-msg` → … 无限递归（实测 45 秒栈溢出）。

**决定**：协议流不属于「用户代码可见的动态变量」。`Server` 模块持有
`$PROTO-IN` / `$PROTO-OUT` 两个模块级句柄，`serve-engine()` 入口处重新捕获
（那一刻还没有任何人 temp），`emit` 与 `read-msg` 只用它们。
不做「格求值前后成对保存/恢复动态变量」那种补丁 —— 那要求每个求值入口
都记得加，漏一处就复发，而且 `prompt` 恰恰就是在求值**内部**发帧的。

**代价**：`serve-engine()` 之外调用 `emit`（目前没有，`emit` 只被本模块与
tty/job/input 三个闭包用）会写到底层进程 stdout —— 这与「引擎的 stdout
就是协议流」一致，不需要额外约定。
