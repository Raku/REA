# ADR-0063：Session 拆分第四步 —— 格记录 / 导出簇与「最低耦合的一刀」

- 状态：已实施（0.149.0 / SPEC V-353）
- 相关：ADR-0060（属性归属规则）、ADR-0061（访问器陷阱）、ADR-0062（第三步）、ADR-0060 §2（role 调类私有方法）、SPEC §3.82、`t/87-cells-split.t`
- 取证方式：区间内 / 区间外属性引用计数 + 运行时夹具（`t/87`）+ 全套件

## 1. 背景

0.148.0（ADR-0062）把 `Session.rakumod` 压到 3,250 行。ADR-0062 §8 留的下一刀是 `!cmd-cells` 一族，理由是耦合最低。本条实施它。

`cells` 是 0.115.0（V-307）引入的**结构化格记录**导出：不带参数列出来，`--text` 导可重放脚本，`--json` 导结构化记录。它与 `history`（只有输入）、`log`（人读的文本抄本、受开关影响）三足鼎立，是很自然的一簇。

结果：`Session.rakumod` **3,250 → 3,093 行**（5 insertions / 162 deletions），新文件 `Cells.rakumod` **182 行**（含注释头 20 行）/ 4 个方法。

## 2. 为什么这一簇是「最低耦合」

测量（区间 2638–2799，162 行）：

| 依赖 | 区间内 | 区间外 | 性质 |
|---|---|---|---|
| `$!sys` | 3 | 17 | 改 `$.sys`（公开属性） |
| `@!cells` | 0 | — | 上一版已公开为 `@.cells` |
| `$!skip-cell` | 1（`LEAVE`） | — | 上一版已公开为 `$.skip-cell` |
| `self!split-argv` | 1 | 大量 | 私有方法，role 可按名调用（ADR-0060 §2） |

对比前三刀：诊断簇要公开 8 个属性，持久化簇要公开 2 个属性并解决 EVAL 的词法包问题。**这一刀不需要公开任何状态** —— 它要的两样东西在第二步就已经公开了，`skip-cell` 甚至是那次「顺手公开」的预备项。

这也是一个值得记下来的模式：**拆分有复利**。上一刀为了让 role 能读某个属性而公开它，下一刀就白拿。反过来，如果每次都只公开「这一簇刚好要的」，就会陷入「每刀都要再公开一批」的线性成本。

朝外的调用只有一条：`!split-argv`。它属于**输入层**（把一行文本切成 argv），不是导出层的一部分 —— 留在 Session，role 调它。这与 ADR-0061 里 `note-timing` 留 Session、诊断 role 调它同型。

## 3. 决定

1. 新增 `lib/Rakuish/REPL/Session/Cells.rakumod`：`unit role Rakuish::REPL::Session::Cells;`，4 个方法 / 182 行。
   - `use Rakuish::Result;`
   - `use JSON::Fast;` —— `!render-cells-json` 用 `to-json`。这一条不能省：Session 里的 `use JSON::Fast;` 不会泄漏进 role 的编译单元，漏了会在运行时才报「Undeclared routine: to-json」。
2. `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells;`，第五条 `use` 写在 `unit` 之前。
3. 不新增任何公开状态。`$!sys` 的三处引用改 `$.sys`。
4. 原位置留指针注释（含「原 0.115.0 / V-307」），避免「代码不在、说明还在」的漂移。
5. `META6.json` provides 51 → 52。
6. 编号：本版用掉 **V-353 / `t/87`**。同时改了草案的编号规则 —— 见 §6。

## 4. 不变量

- `Session.rakumod` < 3,150 行；Cells 恰好含那 4 个方法，不含 `!split-argv` / `@.cells` 的写入方（`!finish`）/ `log-line`。
- Cells 里没有任何 `$!` / `@!` / `%!` 类私有属性引用。
- 格表的所有权仍在 Session：`@.cells` 的 push / 截断 / `Out[n]` 编号全在 `!finish` 与 `!eval-line-body` 里，role 只读。
- 行为：`cells`（列表）/ `--text` / `--json` / `--help` / 未知选项退出码 2 / `skip-cell` 不自指，全部不变；导出文件格式（`rakuish-cells`、`format-version: 1`）不变。

## 5. 结构守卫清单（`t/87-cells-split.t`，46 条）

1. 文件都在；`unit role ...::Cells` 头正确；Session 的四条既有 `does` 没被回退，第五条 `does ...Cells` 与 `use` 都在。
2. **反方向**：`!cmd-cells` / `!render-cells-list` / `!render-cells-text` / `!render-cells-json` 不在 Session，而在 Cells。
3. `!split-argv` 留在 Session、不在 Cells；Cells 经 `self!split-argv` 调用它。
4. 状态：`@.cells` / `$.skip-cell` 是公开属性；Cells 无私有属性引用；Cells 不写 `$!sys`。
5. `cmp-ok $sess-lines, '<', 3150`。
6. `META6.json` provides 52 条，含 Cells。
7. 运行时：新会话 `cells` 说没有记录；`1+1` 后 `@.cells` 有 1 条；列表含 `1+1` 与 `ok`；连跑两次 `cells` 后格数仍是 1（`skip-cell` 生效）；`--json -` 的 `format` / `count` 正确；`--text -` 带 `no worries;` 并给每格补 `;`；写文件两条路径成功且可回读；未知选项 `code=2`。

## 6. 附带改进：草案不再预占编号

ADR-0058（`sys.spawn` 流式 stdout）从 0.146.0 起被顺延了三次：V-350 → V-351 → V-352 → V-353，每次五个位置全改，而它一次都还没实施。这一版把规则改成：

> 草案 ADR **不预占**条款号与测试文件名；实施时取当时的下一个空位，由实施者一次性分配。

改的是规则而不是再顺延一次 —— 顺延没有成本上限，规则有。`docs/ADR-0058-process-handle-stream.md` 里五处预留已改成「号在实施时分配」，并在文件里留了这条规则的说明。

## 7. 下一步

- Session 还剩 3,093 行：求值核心（`!eval-raku` / `!eval-line-body` / `!finish`）、渲染（`render` / `!fmt` 系）、补全（`completions` 系）、recall / source / paste、vi 与按键。
- 补全簇（现约 2935–3180）依赖 `@!history`（区间外 37 处）、`%!type-cache`、`$!engine`、`$!shell`，仍然偏重；recall / source / paste 依赖 `@!pending` / `$!prefill` / `$.store-path`，需要先把多行续行的记账收敛。
- 下一刀更现实的目标是 **recall / source / paste**（输入重放）或 **`render` 的纯展示辅助**（`!fmt` / `!render-bytes` / `!render-path-list`）—— 后者无状态，但被 `render` 与多个命令调用，搬走会让「渲染」分裂成两处，需要先想清楚边界。
