# ADR-0057：父进程交互式管道 —— `! --tty a | b`

- 状态：已实施（0.144.0 / V-348）
- 相关：ADR-0056（引擎内管道）、ADR-0007（TTY 直通）、ADR-0021（引擎子进程）、
  ADR-0028（`:&in-chunks` 流式 stdin）、ADR-0031 / ADR-0042（Windows Job Object）、
  V-901（不支持 bash 语法）
- 影响文件：`lib/Rakuish/Sys/Proc.rakumod`、`lib/Rakuish/REPL/Session.rakumod`、
  `lib/Rakuish/Eval/Server.rakumod`、`lib/Rakuish/Eval.rakumod`、
  `lib/Rakuish/CLI.rakumod`、`lib/Rakuish/REPL/Hints.rakumod`、
  `t/83-pipe.t`、`t/41-eval-worker.t`

## 1. 背景

ADR-0056 把顶层 `|` 做成了引擎内管道，`! dir | findstr lib` 可用；但引擎
子进程的 stdin 是协议流（每行一个 JSON 帧），`! cat | wc -l` 这种「边打字
边过滤」的用法做不了 —— 把键盘交给第 0 段，引擎就收不到帧了。ADR-0056 §6
把这条留成了「父进程侧 pipe-exec」。

父进程持有真终端，且 `Proc::Async` 在**不传** `:in` / `:w` 时子进程直接继承
父进程 stdin（本机实测成立）。技术前提已经具备，本轮只补这一个入口。

## 2. 决定

`! --tty`（或 `-t`）**且**有顶层管道时，整条管道由**父进程**执行：

```
! --tty more | findstr hello
! -t cat | wc -l
```

| 项 | 决定 |
|---|---|
| 触发 | 只有 `--tty` + 管道走父进程；普通 `! a | b` 保持 ADR-0056 不变 |
| stdin | 仅第 0 段继承真终端；中间段照旧 Channel 泵 |
| stdout / stderr | 末段**捕获**进 `Result`（`Out[n]` 可用），`streamed=False` |
| 无 hook / 非 TTY | `127` + 明确文案；**绝不回退引擎内**（第 0 段会吃掉协议 stdin） |
| 超时 | 固定 `timeout-ms=0`；`--timeout-ms` 在 `--tty` 下无效 |
| Ctrl-C | POSIX 同 pgid 由终端广播；Windows 父侧收养整组 Job 并 terminate；`code=130` |
| 协议 | 中间帧 `event=pipe-exec`；回包 `cmd=resume` + 嵌套 `pipe` Hash |
| Notebook | 不注入 `&pipe-handler`（Jupyter 没有终端 stdin），落到 127 |

链路：

```
Session（引擎）──pipe-exec 帧──► Client（父进程）──&pipe-exec hook──► Sys.pipe-exec
       ▲                                                        │
       └────────────── resume{pipe: …} ◄────────────────────────┘
```

- `Session.pipe-handler` 发中间帧并同步等 resume，形状与 `tty-handler` 相同。
- 父侧 `Client!answer-pipe` 校验 `stages` 形状，调注入的 hook，把
  `ok/code/op/out/err/value` 打包回引擎。
- hook（`CLI`）重设 child-cb 后调 `$sess.sys.pipe-exec(@stages, :timeout-ms(0))`；
  每次重设是因为 `cd` 会与引擎同步并重建 Proxy 的 `Sys`。
- 引擎拿回 `Result` 后继续走 `!remember` / `strict-result`，与普通 `!` 一致。

**为什么第 0 段只接 stdin，输出仍捕获。** v1 不做父→引擎的块流式：一是
父进程的 stdout 是用户终端，管道末段的输出必须回到引擎才能进 `Out[n]`；
二是逐块流式会让「结束重放」与「流式回显」重复。末段捕获是最小可用语义，
需要真正的实时代码可以 `! --tty <程序>` 单命令直通。

**为什么无 hook 不降级。** 引擎内执行时第 0 段会把协议 stdin 读走，
REPL 下一条帧就错位 —— 比报错危险得多，所以宁可不做。

## 3. 与 ADR-0056 的关系

只推翻 ADR-0056 §3 对「父进程做管道」的否决，以及 §4「与 `--tty` 互斥」的
边界：0.144 起 `--tty` + 管道是明确入口，单命令 `--tty` 仍是 TTY 直通。
引擎内管道的触发条件、段间泵、退出码取末段、不实现 `pipefail` 全部不变。

## 4. 拒绝过的方案

- **父→引擎 chunk 流式**：需要新增一条长连接的输出帧与背压，且与
  `Out[n]` 的「结束重放」语义冲突；v1 不做，留待有真实需求。
- **无 hook 时回退引擎内**：第 0 段吃掉协议 stdin，REPL 直接错位；拒绝。
- **Notebook 注入**：Jupyter 没有终端 stdin，注入只会把「不可用」拖到
  运行期；直接 127 更诚实。
- **升协议版本**：新帧只是中间帧，终帧形状未变；`PROTOCOL-VERSION` 保持 2。
- **单独做一套父侧 shell**：`!` 的分词 / 审计 / 历史在引擎里，父侧只接
  argv 段（协议里就是 `[[exe, argv...], …]`），不拼 shell 串。

## 5. 实测

Windows 11 + Rakudo 2026.09 本机：

| 场景 | 结果 |
|---|---|
| `Proc::Async` 不传 `:in` 起子进程 | 子进程读到父进程 stdin（继承成立） |
| `! --tty more \| findstr x`（键入数行，Ctrl-D） | 输出只出现一次，不挂死 |
| Ctrl-C（交互式管道中） | 回到 prompt，引擎未重启，`code=130` |
| 无 `&pipe-handler`（notebook / 测试） | `code=127`，err 指向父进程执行器 |
| `t/41` fake `:pipe-exec` 往返 | 2 段 argv 原样，不拼 shell 串 |

## 6. 坑

- Windows 的 `CTRL_C_EVENT` 会广播给同控制台的所有进程：管道整组必须收进
  命令级 Job，只 terminate 这一组；引擎保持存活。
- `Proc::Async` 的 `:ENV` 传参在本版 Rakudo 上不生效，交互式管道因此**继承**
  父进程环境（与引擎内管道一致）。
- 父进程不接管 termios：第 0 段是继承 stdin 的普通子进程，不是 `tcsetpgrp`
  式的前台交接；`! --tty <单命令>` 仍走 ADR-0007 的直通路径。
- `@stages` 从引擎发出时要把每段落成 Array 再发（惰性 `Seq` 会被 JSON 编码成
  单个值）；父侧再按 `$s.List` 解包。
