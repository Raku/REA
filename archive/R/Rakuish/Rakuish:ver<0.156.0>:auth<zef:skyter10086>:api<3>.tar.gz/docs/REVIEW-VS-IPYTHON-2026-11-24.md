# Rakuish 对标 IPython 评审（0.122.3）

> 日期：2026-11-24 · 基线：`HEAD = 2db01d2`（0.122.3）· 平台：Windows 11 + Rakudo Star 2026.11
> 方法：通读 `lib/` 全部 45 个模块、`SPEC.md` / `MANUAL.md` / 47 份 ADR，逐条对照 IPython 9.x 与 ipykernel，
> 并用真进程复现（`raku -Ilib bin/rakuish`、`bin/rakuish-notebook`）。
> 本文只做评审，**未改动任何产品代码**。
> 评分是判断不是测量，证据列给出可复核的 `file:line`。

---

## 0. 结论先行

### 0.1 三句话

1. **Rakuish 已经不是"玩具 REPL"，它是一个有规格、有 3306 条断言、有崩溃隔离的成熟 0.x 项目。**
   终端交互层（高亮 / 灰字建议 / 候选菜单 / Ctrl-R / 错误态标红）已经接近 fish，局部超过 IPython。
2. **它和 IPython 的差距不在"命令数量"，而在四处接口形态**：值没有显示协议、命名空间是近似持久、
   失败之后没有下一步、内核只做了最小协议。这四处是结构性的，补功能解决不了；反过来，
   一旦补上，后面每个功能都会变便宜。
3. **按"IPython 用户的期待"打分约 55/100；按"Raku 的交互式 REPL"打分约 75/100。**
   前者受 Raku 生态（无 numpy/matplotlib/Jedi 对应物）拖累，后者才是这个仓库能独立决定的部分。

### 0.2 分维度评分（vs IPython 9.x）

| 维度 | 权重 | 得分 | 一句话 |
|---|---:|---:|---|
| 输入与编辑（高亮/建议/菜单/多行/粘贴） | 15% | **65** | 高亮和建议很强，**块编辑与粘贴是短板** |
| 补全与内省（Jedi 级补全、`?`/`??`） | 15% | **45** | 方法/SQL/路径能补，**变量、sub、模块名补不了** |
| 历史与会话（`In`/`Out`/`_`/store/log/profile/hook） | 10% | **55** | 有 `Out`/`_`/log/rc/hook，**无 `In`/`__`/跨会话 store** |
| 执行与错误（中断/回溯/调试） | 15% | **40** | 中断与崩溃隔离做得比 IPython 好，**调试器完全没有** |
| 显示与富输出（MIME/repr/`display`/图片/表格 repr） | 15% | **35** | 表格漂亮，**无对象级 repr、无图片、notebook 路径会崩** |
| 数据计算（Table / pandas 级 / SQL） | 10% | **45** | SQL 是强项，**CSV 类型推断与 DataFrame 语义偏薄** |
| 内核与 notebook（协议完整度） | 10% | **50** | 6 个消息能跑，**缺 stdin/interrupt/comm/history/display_data** |
| 工程与生态（CI/文档/分发/扩展） | 10% | **40** | 规格与测试罕见地严，**无云端 CI、中文独档、扩展面很窄** |
| **加权总分** | | **≈ 47** | 作为"IPython 替代品"；作为"Raku REPL"则是另一个数 |

> 补充口径：终端 REPL 体验 **~75**；Jupyter 内核 **~55**；数据工作台（对 pandas 生态）**~50**；
> 工程成熟度（对 IPython 的 20 年积累）**~40**。

---

## 1. 先对齐口径：拿什么和 IPython 比

IPython 是四样东西叠在一起，混着比会得出错误结论：

| 层 | IPython 的形态 | Rakuish 的对应物 | 可比性 |
|---|---|---|---|
| A. 交互壳 | prompt_toolkit + Jedi + `%magic` | Terminal::LineEditor + 自研高亮/建议/补全 + 62 条文本命令 + Raku 函数 | 高，直接可比 |
| B. 语言运行时 | CPython 的 namespace | 引擎子进程里的 `EVAL` + 扫描器/前奏重放 | 高，但 Raku 的 `EVAL` 语义更粗 |
| C. 显示与内核 | `_repr_*_` + MIME + ipykernel | `Display::Bundle` + 自研 notebook 协议 + Python 桥 | 中，**这是最大差距所在** |
| D. 生态 | numpy/pandas/matplotlib/PyPI extensions | 内置 Table/DuckDB/Arrow；无绘图、无扩展市场 | 低，**很多"缺"不在本仓库能力范围内** |

同时必须承认三处**刻意的不同**，它们不是欠账（`SPEC.md:2897-2905`）：

- **V-901**：不做 bash/POSIX 语法（管道、重定向、`$?`、heredoc）。`!` 只接 argv。
- **V-902**：不做 `%magic`。Raku 里 `%` 是哈希 sigil，语法上撞车，这不是偏好问题。
- **V-909**：不做无开关的交互式子进程自动探测。

所以本文的"差距"分三类：**该修的 bug**、**该补的结构**、**不该追的生态**。第 7 节按这个分类排。

---

## 2. 能力矩阵（对照 IPython 9.x）

标记：`✓` 有完整闭环 · `△` 部分/受限 · `—` 无或明确不做。

### 2.1 交互壳

| 能力 | IPython | Rakuish | 证据 |
|---|:--:|:--:|---|
| 语法高亮 | ✓ | ✓ | `Highlight.rakumod:146-269`；词法级，`q[]`/正则/heredoc 不染（`ADR-0011`） |
| **错误态高亮**（未知命令/缺路径/括号） | — | ✓ | `Highlight.rakumod:285-404`、`Session.rakumod:2834-2851`；**IPython 没有** |
| 灰字自动建议 | ✓ | ✓ | `Keymap.rakumod:277-339`；来源=历史+补全候选，支持 `Alt-→` 逐词 |
| 候选菜单 | ✓ | △ | `Keymap.rakumod:366-397`；ShiftTab 只打印，不能用方向键选 |
| Tab 补全：命令/路径 | ✓ | ✓ | `Shell.rakumod:1266-1348` |
| Tab 补全：方法链 | ✓ | ✓ | `Methods.rakumod:21-81`、`Session.rakumod:2721` |
| Tab 补全：**变量 / sub / class / 模块名 / kwargs** | ✓ | **—** | `Session.rakumod:2691-2716` 分派只有四条；实测 `$al`、`hel`(用户 sub)、`use JSO`、`open-data('tmp/` 全为空 |
| 多行块编辑 / 回改上一格 | ✓ | — | 单行 buffer（`SPEC V-154`），续行提示符固定无缩进 |
| **粘贴多行代码** / bracketed paste / `%paste` | ✓ | — | 无 `paste`/`cpaste`；粘贴按行提交 |
| Ctrl-R 历史检索 | ✓ | ✓ | `Keymap.rakumod:345-359`；循环检索 |
| 外部编辑器 `%edit` | ✓ | — | 刻意删除（`SPEC V-125:95-101`） |
| `!` shell 转义 | ✓（真 shell） | △（argv-only） | 刻意不同；`Session.rakumod:1450-1542` |
| `! --tty` 嵌套 REPL | — | ✓ | `ADR-0007`；IPython 做不到干净交接 |

### 2.2 内省、历史、会话

| 能力 | IPython | Rakuish | 证据 |
|---|:--:|:--:|---|
| `?` 名字内省 | ✓ | ✓ | `$x?`→类型+值；`ls?`→用法 |
| `??` 源码查看 | ✓ | **—** | 实测 `Int??` → `Confused` |
| 内置例程文档（`?len`） | ✓ | **—** | 实测 `doc pick` → "未找到该名字"（只认类型/会话内名字） |
| `%psearch` 通配 | ✓ | — | `help --find` 只搜命令 usage |
| `In[n]` / `__` / `_i` / `_ih` | ✓ | **—** | 实测 `In[1]`、`__` → `Undeclared routine` |
| `Out[n]` / `_` | ✓ | ✓ | `Session.rakumod:1053-1054` |
| 历史持久化 + `%history` 过滤/导出 | ✓ | △ | 有 `history`/`!!`/`!n`/`rerun`；无过滤/区间；文件历史与 `@!history` 两套不互通 |
| `%recall`（放回输入行） | ✓ | — | 只能 `rerun` 重跑 |
| `%store` 跨会话变量 | ✓ | **—** | 快照只在崩溃恢复时读，**正常启动不加载** |
| `%logstart` | ✓ | ✓ | `log start/stop/show/status` |
| `%save` / `%macro` | ✓ | —/— | `cells --text` 是近似物 |
| `%who`/`%whos`/`%who_ls` | ✓ | △ | `who`/`whos` 有；不能当函数取列表 |
| `%reset` | ✓ | — | — |
| `%env`/`%cd`/`%pushd`/`%bookmark` | ✓ | ✓ | `DSL.rakumod:199`、`Shell.rakumod:545-646`；bookmark 不落盘 |
| profiles / `%config` | ✓ | △ | 单份 config + rc + hook；无 profile 目录 |
| `timed`/`bench`/`perf` | `%time`/`%timeit` | ✓ | `DSL.rakumod:208-240`；**每格耗时默认显示，比 IPython 主动** |
| `%prun` / 行级 profile | ✓ | — | 无 |

### 2.3 执行、显示、内核

| 能力 | IPython/ipykernel | Rakuish | 证据 |
|---|:--:|:--:|---|
| 求值中断后**保命名空间** | ✓（KeyboardInterrupt） | △（杀引擎+重启+快照恢复） | `ADR-0023`；代价是状态可能丢 |
| 崩溃隔离 | — | ✓ | 引擎子进程，`exit`/段错误只带走引擎（`ADR-0021`） |
| 崩溃后恢复声明与纯值 | — | ✓ | `ADR-0022`；但闭包/连接/`Out[n]` 丢，且 `.raku` 重放可能触发构造副作用 |
| 命名空间跨格持久 | ✓（真解释器） | △（扫描器+前奏重放） | **有洞**，见 §3.2 |
| `display()` | ✓ | **—** | 实测 `display("x")` → `Undeclared routine` |
| 对象级 `_repr_html_` 等 | ✓ | **—** | 分支写死在 `Display.rakumod:146-228` |
| MIME 种类 | 8+ | 4 | `Display.rakumod:29,90-99`：text/markdown/html/json；**无 png/svg/latex/js** |
| 图片内联 | ✓ | **—** | 无 image/* MIME |
| `%%capture` | ✓ | — | 只有 `! --capture` |
| 结构化 traceback + `%xmode` | ✓ | **—** | 只显示异常的 `.message`（`Session.rakumod:1062-1070`） |
| post-mortem `%debug` / `%pdb` | ✓ | **—** | 无 |
| Jupyter 消息 | ~20 | **6** | execute/complete/inspect/is_complete/kernel_info/shutdown（`Notebook.rakumod:52-64`） |
| `history_request` | ✓ | **—** | 无 |
| `interrupt_request` | ✓ | **—** | 无；kernelspec 却声明 `interrupt_mode: message` |
| `input_request`（`prompt`） | ✓ | **—** | `prompt` 会**挂死内核**（`$*IN` 是协议管道） |
| comm / ipywidgets | ✓ | **—** | 无 |
| `display_data` / `update_display_data` | ✓ | **—** | 只有 `execute_result` |

### 2.4 数据工作台（对照 pandas，而非 IPython 本体）

| 能力 | pandas | Rakuish | 证据 |
|---|:--:|:--:|---|
| 表格渲染 | ✓ | △ | 有网格，无 index/dtype/shape/head-tail 省略；CJK 列宽错位 |
| CSV 类型推断 | ✓ | **✗** | 默认 CSV 全列 `str`（`Data.rakumod:187-190`）→ `sum` 抛异常、`mean` 返回 0（已复现） |
| groupby / pivot / window | ✓ | **—** | Table 无 group-by；只有 `Stream.group-by` 单列 |
| 多键 join / 多列排序 | ✓ | — | `join` 单键、`sort-by` 单列 |
| `fillna`/`dropna`/`assign`/`rename` | ✓ | — | — |
| SQL 作为值操作 | 外部 | ✓ | `Table.sql` / `sql({...})`，元数据驱动补全（**强于 ipython-sql**） |
| 惰性游标 + LIMIT 下推 | 部分 | ✓ | `Cursor`，`DuckDB.rakumod:102-110` |
| Arrow / Parquet 互操作 | ✓ | ✓ | 自研 Arrow 写 + 读侧分流（`ADR-0038…0047`） |
| Excel / HDF5 / HTML 表格 / URL | ✓ | — | `open-data` 扩展名闭集（`Data.rakumod:436-440`） |
| 绘图 | ✓ | **—** | 无 |

---

## 3. 四个结构性差距（补命令解决不了）

### 3.1 值没有"显示协议"——显示是 Session 里的闭集分支

这是**最高杠杆**的一处。

现状：`Session.rakumod:1592-1737` 有 9 个 `!render-*`/`!fmt` 分支，`Display.bundle-from`
（`Display.rakumod:121-232`）按**具体类型**分派：Table、`Positional[Hash]`、`IO::Path` 列表、
Hash、标量，**其余一律 `$v.Str`**。第三方类型无法声明"我怎么被显示"。

后果不是"少了个 API"，而是一连串：

- `display()` 不存在（实测 `Undeclared routine`），一个 cell 不能产出多个输出；
- 无 `image/png`/`svg`/`latex`/`javascript` MIME → **没有图表、没有公式、没有控件**；
- notebook 里 `to-mime` 对不可 JSON 化的值直接抛异常，**把引擎打死**（见 §4.2）；
- 容器值的退化为 `.raku`：`ls("t").head(3)` 打印整个 `IO::Path.new(...)` 结构（实测），
  大 `Seq` 会整段倾倒（5000 元素 = 28,909 字符，**无任何预算**）；
- 类型对象渲染为空：`Int.WHAT` 输出空行（实测）。

对比 IPython：`DisplayFormatter` + `_repr_*_` 鸭子类型，任何包都能加一种渲染；
`display()` 是普通函数；Jupyter 侧 `display_data`/`update_display_data` 是独立消息。

> 这一处修好，绘图、富媒体、Jupyter 控件、第三方格式化**全部变成"下游的事"**。
> 不修，每加一种输出都要改核心分支。

### 3.2 命名空间是"近似持久"，而且有会锁死会话的洞

Raku 没有 IPython 那种"一个 namespace 反复 EVAL"。Rakuish 的近似做法是：
扫描顶层声明 → 缓存纯声明格 → 每格把**声明前奏 + `%STATE` 别名**拼进源码再 EVAL
（`Session.rakumod:1027-1046`、`:895-960`）。

这个近似有三个可复现的洞：

**（a）前奏顺序 bug——最严重，会锁死整个会话**

```text
rakuish> my $n = 10
Out[1] = 10
rakuish> sub addn($v) { $v + $n }
Out[2] = sub addn ($v) { ... }
rakuish> addn(5)
错误: Variable '$n' is not declared.
rakuish> 1 + 1
错误: Variable '$n' is not declared.      ← 之后每一格都失败
```

根因：前奏是"**所有声明在前、所有 `%STATE` 别名在后**"。定义那一格，别名在 sub 之前所以编译通过；
后续格重放声明时，sub 在 `$n` 别名之前，编译失败。**这不是边角案例**——"先存一个配置变量，
再写个引用它的函数"是交互式使用的日常动作。一旦发生，只有重新定义那个 sub 才能解封。

**（b）混合格里的声明不持久**

```text
rakuish> sub sq2($n) { $n*$n }; sq2(3)
Out[1] = 9
rakuish> sq2(4)
错误: Undeclared routine: sq2
```

`!pure-decl` 只缓存"整格恰好一条声明"（`Session.rakumod:895-960`）。IPython 里 `def f(): ...; f()`
当然两件事都成立。

**（c）`constant` / `enum` / `subset` 不持久**

```text
rakuish> constant K = 42
Out[1] = 42
rakuish> K
错误: Undeclared routine: K
```

扫描器会规范化它们（`Session.rakumod:660-665`），但缓存只认 `sub|class|role|grammar`。

另外两个附带问题：

- **声明格占 `Out[n]`**：`sub f($n){...}` 会显示 `Out[1] = sub f (...) {...}`。
  IPython 的 `def` 不产生输出。这会污染结果编号与 `_`。
- **前奏随声明数线性变慢**：实测 40 个 sub 后约 **109 ms/格**，干净会话约 5 ms/格。
  这是长会话越用越慢的隐性税。

### 3.3 失败之后没有"下一步"

Rakuish 的异常处理只做一件事：取 `.message` 打印成 `错误: ...`（`Session.rakumod:1062-1070`、`:1866`）。

- 没有 backtrace，没有 `文件:行`；
- 没有 `%debug`/`%pdb` post-mortem；
- 没有 `%tb`/`%xmode` 控制回溯详略；
- `repl.trace` / `repl.bt` 是**死属性**：`Session.rakumod:100,122` 声明，全仓库无读取点，
  但 `CLI.rakumod:150` 的 `--help` 与 `SPEC V-125:95` 仍在宣传它。

对探索性编程，这是比"少几个 magic"严重得多的缺口：IPython 的核心循环是
**试 → 报错 → `%debug` 进去看帧 → 改**。Rakuish 的循环在"报错"处就断了。

而且 Raku 自己的编译错误信息冗长（"Perhaps you forgot a 'sub' if this was intended..."），
一行 `错误:` 前缀无法把"编译失败/运行失败/被拒"区分开。

### 3.4 多行输入是"逐行行编辑"，不是块编辑

- 单行 buffer（`SPEC V-154`），续行提示符固定 `  ··· `，无自动缩进；
- **空行不提交**：`Session.rakumod:1300` 在续行判定**之前**就 `skip` 空行，
  与 `MANUAL.md:258` / `Hints.rakumod:83` 的"空行提交"相反（已复现）；
- 没有 bracketed paste，没有 `%paste`/`%cpaste`。粘贴一个含空行/多行的 `class` 时，
  靠 `Incomplete` 的行尾运算符与括号平衡启发式拼接，容易半截执行；
- `rerun` 只能重跑，不能把历史放回输入行编辑（IPython 的 `%recall`）。

在 IPython 里"从文档粘一段代码"是 Top-3 高频动作。这里它是**最不可靠**的动作。

---

## 4. 可复现的正确性缺陷（建议直接开 issue）

> 以下每条都在本机 0.122.3 复现过。前三条属于"会让用户丢工作"的级别。

### 4.1 前奏顺序锁死会话（严重）

见 §3.2(a)。触发条件：先 `my $x = ...`，再定义引用 `$x` 的 `sub`/`class`。之后每格失败。

### 4.2 notebook 遇到不可 JSON 化的值会杀引擎（严重）

```text
{"op":"execute","code":"3+4i","display":true}
→ Don't know how to jsonify Complex
→ {"event":"engine","kind":"restart",...}
→ {"ok":false,"code":500,"err":"引擎已重启: 连接已断开"}
```

根因：`bundle-from` 把原值塞进 `@.json`（`Display.rakumod:220-228`），`to-mime` 调 `to-json`
（`:90-99`），`Eval::Server` 的 `emit` 没有 `CATCH`（`Eval/Server.rakumod:31-35`），异常穿出
`serve-engine` → 进程死。`Sub`、自定义类实例同样触发。**普通 Raku 值在 Jupyter 里是不安全的。**

### 4.3 打印过的 cell 丢结果（严重）

```text
{"op":"execute","code":"say \"hi\"; 42","display":true}
→ out:"hi\n", display.content:"hi"      ← 42 不见了
```

`bundle-from` 在检查 `value` **之前**就按 `out` 返回（`Display.rakumod:133-137`）。
TTY 路径两者都显示（`Session.rakumod:1799-1868`），所以两个前端行为不一致；
Jupyter 侧还会把 `hi` 同时作为 stream 与 execute_result 显示两遍。

### 4.4 默认 CSV 全列 `str`，数值聚合坏掉（严重）

```text
rakuish> my $t = open-data("x.csv"); $t.sum("amt")
错误: Type check failed for return value; expected Num but got Int (0)
rakuish> $t.mean("amt")
0e0                                        ← 静默错误
```

`Data.rakumod:187-190` 把 CSV 列一律标 `str`；`Table.!numeric` 过滤后为空；
`@v.sum` 返回 `Int 0` 而签名要求 `Num`（`Table.rakumod:182-191`）。
而 `Stream` 层有另一套"数字字符串按数字处理"的逻辑（`Stream.rakumod:475-491`），两层不一致。
这是数据工作台的门面功能，**CSV 是最常见的入口**。

### 4.5 内省会污染 `_` 与 `Out[n]`

```text
rakuish> 40 + 2
Out[1] = 42
rakuish> ls?
<用法...>
rakuish> _
ls                                          ← `_` 变成了字符串 "ls"
```

`inspect-name` 走 `eval-line-body('doc …')`（`Session.rakumod:2554`），`doc` 命中 Shell 分支后
`$!index++` 且 `remember`（`Session.rakumod:1550-1551`）。这违反
`MANUAL.md:761-762` 与 `SPEC V-299:2069-2071` 的"不占 `Out[n]`"，
并在**最需要安全查错的时刻改变了结果历史**。

### 4.6 `help` 与 `help()` 是两套表

`help`（命令）打印 3 组共 62 条命令；`help()`（Raku 函数）走另一个 registry，只出 13 条。
插件命令两个表都不出现（`DSL.rakumod:42-46` 的模块级 registry ≠ 会话 registry）。
这正是 `FEATURE-GAP` A6"影子 API"的残留。

### 4.7 变量/sub/模块名补全为空

实测（直接调 `Session.completions`，会话里已有 `$alpha` / `@arr` / `sub helper`）：

| 输入 | 候选 |
|---|---|
| `$al` | `()` |
| `@ar` | `()` |
| `hel` | `("help ",)` ← 只有内置命令，没有用户的 `helper` |
| `use JSO` | `()` |
| `open-data('tmp/` | `()` |
| `Out[` | `("Out[1]", …)` ✓ |
| `ls --` | `("ls --help ", "ls --json ")` ✓ |
| `cd ../t` | 路径候选 ✓ |

分派只有四条（`Session.rakumod:2691-2716`）：`In`/`Out` 引用 → `.` 方法 → SQL 字符串 → Shell。
而 Shell 分支一遇 `$ @ % & ( ) [ ] { } ; | < >` 就返回空（`Shell.rakumod:1283`），
所以**Raku 调用和字符串里的路径也不补**。`%STATE` 和 `@!decls` 现成就有，这是低成本高收益。

### 4.8 `In[` 补全会给出执行必报错的候选

`In[` 有补全候选（`Session.rakumod:2707`），但 `In` 从未绑定（只绑 `_` 与 `Out`，
`Session.rakumod:1074-1078`）。接受候选后执行 → `Undeclared routine: In`。
要么绑 `In`（历史 list），要么去掉这个补全。

### 4.9 其他确认项

| # | 现象 | 证据 |
|---|---|---|
| a | `README.md:115` 的 `%h = a => 7; %h<a>` 示例**跑不通**（`%h` 未声明，需 `my %h`） | 实测 |
| b | 类型对象渲染为空：`Int.WHAT` → 空行 | `Session.rakumod:1591-1598` |
| c | `Seq`/`List` 形式的 `IO::Path` 退化成 `.raku` 全量 dump | 实测 `ls("t").head(3)` |
| d | 无输出预算：`(1..5000).Seq` → 28,909 字符；`"x" x 20000` 原样 | 实测 |
| e | `doc pick` 找不到内置例程（只认类型/会话内名字） | 实测 |
| f | `timed { ... }` 渲染只给值，不给耗时（要 `.elapsed`） | 实测 |
| g | Table 无 `head`/`tail`；`$t.head(2)` 走 `Any.head` 静默返回包着整表的 `Seq` | 实测 |
| h | 默认渲染把未知容器交 `.raku` 而非 `.gist`（大对象放大） | `Result/Renderer` + `Session:1592` |
| i | `Result.render('html')` 抛异常，但 `Display` 的 capabilities 宣告 html | 实测 + `Renderer.rakumod:258-266` |
| j | Windows 上 `! echo hi` 不可用（cmd 内建，argv 直接 spawn 失败） | 实测 |
| k | `config set color off` 会连灰字建议/错误标红一起关（共用开关） | `Keymap.rakumod:253`、`CLI.rakumod:587` |
| l | `long` 会话性能：40 个声明后 ~109 ms/格 vs 5 ms/格 | 实测 |

---

## 5. 差距量化：到底差多少

### 5.1 数量层面（不是差距所在）

| 指标 | IPython 9.x | Rakuish 0.122.3 |
|---|---|---|
| 文本命令 / magic | ~80 line + ~20 cell ≈ **100** | **62** 条文本命令 + ~50 个 DSL 函数 |
| 显示 MIME | **8+** | **4** |
| Jupyter 消息 | **~20** | **6** |
| 文档 | Sphinx 站 + 英文手册 + changelog | 中文 SPEC 2974 行 + MANUAL 2021 行 + **47 ADR**，无站点/英文/changelog |
| 测试 | 大套件 + coverage | **74 文件 / 3306 断言 / 双平台全绿**，无 coverage |
| 发布 | 20 年 ~150 个 release | **46 天 93 个 tag / 319 commits** |
| 平台 | 全平台 + PyPI | Windows + Linux/WSL，Gitee 源 |

命令数量并不落后。**落后的是"接口形状"与"交付形态"。**

### 5.2 结构性层面

| 差距 | 本质 | 修它的成本 | 不修的代价 |
|---|---|---|---|
| 无显示协议 | 架构 | 中（定义接口 + 改 Display/Session 两处） | 每加一种输出改核心；无绘图/富媒体 |
| 命名空间近似 | 架构 | 中高（前奏顺序可先修；彻底解需重新设计扫描器） | 会话会被锁定；长会话变慢 |
| 无调试子系统 | 新建 | 高（Raku 异常/帧模型受限） | "试→查→改"循环断裂 |
| 内核协议残缺 | 补协议 | 中（history/stdin/interrupt 便宜，comm/debug 贵） | Jupyter 只能跑"能算的 cell" |

### 5.3 时间判断（判断，不是承诺）

- **修完 §4 的 bug + P1 显示协议与补全**（约 3–5 个版本）：权重分从 47 → **~60**，
  终端体验接近 85，Jupyter 可用性显著提升。
- **再补调试与内核协议**（约 2–3 个月）：→ **~68**。
- **85+ 需要生态**：绘图库、数值栈、扩展市场、英文文档与 CI。这不是本仓库单独能做完的，
  但它可以**定义接口让生态长出来**——这也是为什么 §3.1 排第一。

---

## 6. Rakuish 真正比 IPython 强的地方（公平起见）

1. **崩溃隔离 + 会话快照**：`exit`、段错误、`while 1 {}` 只带走引擎，父进程重启并**如实报告**
   丢了什么（`ADR-0021` / `ADR-0022`）。ipykernel 一死，namespace 全没。
2. **执行前的错误态标记**：未知命令、缺失路径、括号失配在输入行上标红（`Highlight.rakumod:285-404`）。
   IPython 没有等价物。
3. **`!` 完全 argv-only**：无 shell 解释、无注入面、参数边界确定（`SPEC V-123`）。
   加上 `! --tty` 的终端交接，嵌套 REPL/编辑器是 IPython 做不干净的事。
4. **一切皆结构化值**：命令返回 `Result`/`Table`/`Stream`，`_`/`Out[n]` 保留原对象，
   TTY/JSON/notebook 共用一套 `Result`。IPython 大量 magic 只回字符串。
5. **SQL 是值操作**：`Table.sql` / `sql({a=>$t1,b=>$t2}, ...)` 往返都是 Table，
   补全读活库的 `tables()`/`schema()`（`SqlComplete.rakumod:214-244`）。ipython-sql 没有后者。
6. **数据与系统的统一管道**：命令输出 → 记录流 → 过滤 → 回灌子进程 stdin（`Stream`），
   pandas 完全没有"进程输出即数据"这一层。
7. **规格与决策记录**：47 份带状态/回滚的 ADR、2974 行带 V 编号的唯一真值、
   `t/51` 守元数据一致、`t/52` 全模块加载冒烟。这在 0.x 项目里罕见。
8. **每格耗时默认可见 + `perf` 历史 200 格**，不需要先想到 `%timeit`。

---

## 7. 接下来怎么打磨

分四档，按"影响力 ÷ 成本"排。每条给落点与验收方式。

### P0 · 先止血（1 个版本，1–3 天）

| # | 事项 | 落点 | 验收 |
|---|---|---|---|
| 0.1 | 修前奏顺序：声明重放时把 `%STATE` 别名前置，或把别名放进同一作用域 | `Session.rakumod:1027-1046` | 新测试：`my $n` → `sub f { $n }` → `f(1)` 通过；之后任意格仍可执行 |
| 0.2 | notebook display 对不可 JSON 值降级为 `.Str`，并给 `emit` 加 `CATCH` | `Display.rakumod:220-228`、`Eval/Server.rakumod:31-35` | `3+4i` / `Sub` / 自定义类实例不再重启引擎 |
| 0.3 | `out` 与 `value` 同时存在时两者都进 bundle | `Display.rakumod:133-137` | `say "hi"; 42` 的 notebook 回复同时有 `out` 与 `value=42` |
| 0.4 | 内省不再占 `Out[n]`、不改 `_` | `Session.rakumod:1550-1551`、`:2554` | `40+2` → `ls?` → `_` 仍是 42，下格 `Out[2]` |
| 0.5 | 声明格不产生 `Out[n]` | `Session.rakumod:1266` 附近 | `sub f(){}` 后 `Out` 编号不前进 |
| 0.6 | 修 README 的 `%h` 示例；`install.sh` 去掉 `rakuish-agent` 与 `--agent` | `README.md:115`、`tools/install.sh:9,24` | 示例可跑；`bash tools/install.sh` 不因 chmod 失败 |
| 0.7 | `In` 要么绑定、要么撤掉 `In[` 补全 | `Session.rakumod:1074-1078,2707` | 二者之一 |

> 这一档不新增能力，只是让"宣称 = 实际"。成本极低，但它决定别人是否信这份文档。

### P1 · 补结构与手感（2–4 周，建议 2 个版本）

| # | 事项 | 设计要点 | 验收 |
|---|---|---|---|
| 1.1 | **显示协议**：值可声明自己的 MIME | 鸭子类型：有 `to-mime`/`display-mime` 就调用（`Display.bundle-from` 加一个 `if` 分支）；`FORMATS` 扩到 `svg/png/latex/js`；DSL 导出 `display($v)` 与 `HTML`/`Markdown`/`SVG`/`PNG`/`Latex` 薄包装 | 第三方类实现 `to-mime` 后，TTY/notebook 都能渲染；`display()` 可在 cell 中间产出输出 |
| 1.2 | **输出预算** | `max-display-chars`（默认 ~4000）、`max-seq-elems`（默认 1000），超限截断并标 `…（共 N 项）`；未知容器用 `.gist` 而非 `.raku` | `(1..5000).Seq` 输出 ≤ 预算；`ls(...).head(3)` 输出 basename |
| 1.3 | **补全补全** | `%STATE` 键（按 sigil 过滤）+ `@!decls` 名字 + `use` 模块名（扫 `$*REPO`/已加载模块）+ `sub` 签名 kwargs；`In[` 绑定或移除 | `$al`、`hel`、`use JSO` 均有候选 |
| 1.4 | **块输入 `paste`** | 新命令：读 stdin 直到 `--`/EOF，累积成一个 cell 再 `eval-line`。不改行编辑循环（避开 `ADR-0036` 的输入循环所有权） | 粘贴含空行的 `class` 一次执行；TTY 与管道同语义 |
| 1.5 | **修 CSV 类型推断** | `from-csv-data` 逐列推断 int/num/bool/datetime（可复用 `Table.!infer-type`）；`sum` 空集返回 `0e0` 而非 `Int 0` | CSV 的 `sum`/`mean` 正确；新测试覆盖全 `str` 列 |
| 1.6 | Table 加 `head`/`tail`，并让 `to-text` 支持 index/dtype/shape 可选行 | `Table.rakumod` | pandas 用户的 `.head()` 直觉可用；不再静默返回怪 `Seq` |
| 1.7 | 合并 `help` 与 `help()` 的名单 | 单一 `COMMAND-GROUPS` 派生；`help --api` 列出 `timed`/`bench`/`stream`/`sql` | 两处命令数一致；插件命令出现 |

### P2 · 补"失败之后"与内核（1–2 个月）

| # | 事项 | 说明 |
|---|---|---|
| 2.1 | **post-mortem lite**：`debug` / `tb` | 引擎在 `CATCH` 里保留异常对象；`debug` 打印异常族、`.message`、`.backtrace`（帧+源码行）、可继续 `$!` 检查。**先做"看得见"，不要先做帧内求值**——MoarVM 的帧词法访问受限，这是研究项 |
| 2.2 | 错误分级 `errors short|full` | 区分编译/运行/被拒；默认给文件:行 |
| 2.3 | 清死属性 `repl.trace` / `repl.bt` | 要么接线，要么从 `--help`/SPEC 删掉 |
| 2.4 | notebook：`history_request`、真实 `cursor_start/end`、`interrupt_request`、`execute_input`、`display_data` | 前三个便宜且立刻可用（补全不再整行替换、⏹ 能停）；`input_request` 必须做，否则 `prompt` 挂死内核 |
| 2.5 | notebook `error` 带结构化 `ename/evalue/traceback` | Jupyter 才能渲染红色回溯 |
| 2.6 | `store`（跨会话变量） | 复用 `Snapshot` 的可序列化判定；`store -r/-d/-l`；启动可选加载 |
| 2.7 | `%recall` 等价：`recall n` 把历史放回输入行 | 需要行编辑器支持预填；若成本高，退化为 `edit n` 打开临时文件 |

### P3 · 工程与生态（持续）

| # | 事项 | 为什么值得 |
|---|---|---|
| 3.1 | **打开云端 CI**（已有 `tools/ci.sh`） | 当前 `tmp/ci-report.txt` 是 **0.117.1 的 FAIL**（`console=fail`），与"双平台实测"的叙事不符；这是投入产出比最高的一项 |
| 3.2 | **文档版本守卫** | 5 份文档的版本/依赖/ADR 数互相矛盾（README 0.122.1、HANDOFF 0.122.1、ADR-INDEX 0.120.1/44 条、META6 0.122.3/45 模块/47 ADR、README 说 3 个依赖实际 4 个）。把 `t/51` 扩成"文档版本 = META6" |
| 3.3 | **`Arrow::IPC` 改为可选依赖**或写进文档 | 现在是硬 `depends`，但代码按可选处理（`Data.rakumod:426-430`），README 又说只有 3 个依赖 |
| 3.4 | **CHANGELOG + 收敛发布节奏** | 46 天 93 个 tag，用户无法跟踪；按里程碑发版，`AUDIT-FIXES-*` 归并成 changelog |
| 3.5 | **英文 README + 文档站** | 中文独档是采用率的天花板；至少 README + MANUAL 目录 + 快速开始 |
| 3.6 | **扩展面**：`~/.rakuish/plugins/*.raku` 自动发现 + 生命周期；允许注册**补全器/渲染器/hook**，不只是 `Command` | 现在插件命令连 REPL 文本命令都执行不了（registry 与 eval 路径未接线） |
| 3.7 | **一张 IPython→Rakuish 对照表**放进 MANUAL | 最便宜的"降低迁移成本"：`%timeit`→`bench`、`%run`→`source`/`rakuish file`、`%who`→`who`、`%logstart`→`log start`、`display`→（P1 后）`display`、`%debug`→`debug`。直接回答"我该按哪个键" |
| 3.8 | **`tmp/` 清理**（141 MB / 4786 文件）与 `t/15` 的硬编码作者路径 | 工作区卫生 + 测试可移植 |

---

## 8. 不该追的东西（守住定位）

1. **不要加 bash 语法**（管道/重定向/`$?`/heredoc）。一旦开始，就回到 v2 的七类 P0。
   需要组合就用 `Stream`/`sys.exec`/Raku 本身。
2. **不要加 `%magic`**。`%` 在 Raku 里是 sigil。要的是"统一发现"，不是"再起一套语法"。
3. **不要自研绘图/数值库**。定义显示协议，让 `SVG`/`HTML`/`PNG` 成为出口；
   绘图交给 gnuplot/Graphviz/vega 之类，返回 MIME 即可。Raku 生态的数值栈不是这个仓库的仗。
4. **不要追 Jedi 级静态分析**。Raku 的强项是运行时内省；把 `%STATE`/`@!decls`/`^methods` 用足，
   比做类型推断划算得多。
5. **不要为了"对齐 IPython"加 `%prun`/`%lprun`**，除非先把 `debug` 做出来——
   没有回溯的 profiler 只能给数字，不能定位。

---

## 9. 如果只能做五件事

1. **修前奏顺序 bug**（§3.2a）——它会把会话锁死，是唯一的"数据丢失级"语义缺陷。
2. **修 notebook display 三连**（不可 JSON 降级、out+value 并存、错误结构化）——现在普通 Raku 值会让内核重启。
3. **做显示协议 + `display()`**（§3.1）——一处接口，解锁绘图、富媒体、第三方渲染、Jupyter 控件。
4. **补全变量/sub/模块名 + 输出预算**（§4.7、§4.9d）——最高频的两个日常动作。
5. **打开云端 CI，并把文档版本纳入断言**——让"3306 条断言全绿""双平台实测"变成可复核的事实，
   而不是一份 0.117.1 的 FAIL 报告。

做完这五件，加权分会从 ~47 到 ~60，而"值得推荐给别人"的门槛大约就在 60。

---

## 附录 A：复现命令

```bash
# 前奏顺序锁死会话
printf 'my $n = 10\nsub addn($v) { $v + $n }\naddn(5)\n1 + 1\n' | raku -Ilib bin/rakuish

# notebook 遇到 Complex 杀引擎
echo '{"op":"execute","code":"3+4i","display":true}' | raku -Ilib bin/rakuish-notebook

# 打印过的 cell 丢值
echo '{"op":"execute","code":"say \"hi\"; 42","display":true}' | raku -Ilib bin/rakuish-notebook

# CSV 数值聚合
printf 'name,amt\nalice,10\nbob,20\n' > /tmp/p.csv
printf 'my $t = open-data("/tmp/p.csv"); $t.sum("amt")\n' | raku -Ilib bin/rakuish

# 内省污染 _
printf '40 + 2\nls?\n_\n' | raku -Ilib bin/rakuish

# 无输出预算 / Seq 退化
printf '(1..5000).Seq\n' | raku -Ilib bin/rakuish | wc -c
printf 'ls("t").head(3)\n' | raku -Ilib bin/rakuish
```

## 附录 B：核对来源

仓库内：`lib/` 45 个模块、`t/` 74 个测试、`META6.json`、`SPEC.md`、`HANDOFF.md`、
`README.md`、`docs/MANUAL.md`、`docs/ADR-INDEX.md`、`docs/ADR-0016/0021/0022/0023/0034/0037/0047`、
`tools/ci.sh`、`tools/install.sh`、`tmp/ci-report.txt`。

外部对照（2026-11-24，按公开文档）：IPython 9.x 的 magic 列表、`DisplayFormatter`/`_repr_*_`、
Jupyter kernel 消息集、`%debug`/`%xmode`、`%store`/`%logstart`、`%paste`/`%cpaste`。

方法说明：本文由四个并行子评审（REPL 交互层 / 求值内核层 / 数据与显示层 / 工程层）
加主评审的独立复现汇总而成；凡是标"实测"的结论都在本机 0.122.3 上重跑过。
