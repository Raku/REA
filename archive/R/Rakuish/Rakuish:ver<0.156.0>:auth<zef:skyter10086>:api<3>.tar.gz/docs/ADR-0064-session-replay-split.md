# ADR-0064：Session 拆分第五步 —— 输入重放簇与「窄入口」而不是公开属性

- 状态：已实施（0.150.0 / SPEC V-354）
- 相关：ADR-0060（属性归属规则）、ADR-0061 / 0062 / 0063（第二至四步）、ADR-0053（跨会话变量库）、SPEC §3.83（本条条款）、`t/88-replay-split.t`
- 取证方式：Rakudo Star **v2026.11**（本机 Windows）；区间引用测量 + `t/82` / `t/68` / `t/79` 回归 + 全套件

## 1. 背景

0.149.0（ADR-0063）把 `Session.rakumod` 压到 3,093 行，格记录（`cells`）搬成了 `Session::Cells`。剩下的候选里，`recall` / `source` / `paste` 是一组语义相连的命令（都是「把已有文本重新喂给求值器」），用户点名先做这一簇。

结果：`Session.rakumod` **3,093 → 2,868 行**（17 insertions / 242 deletions，含三个窄入口），新文件 `Replay.rakumod` **267 行 / 3 个方法**（`!cmd-recall` / `!cmd-source` / `!cmd-paste`）。

## 2. 为什么是这一簇：共用「历史 → 文本 → 求值」的管线

三条命令各自看着独立，实际共用同一组状态：

- `!cmd-recall`：读 `@.history` 取原文 → 写预填缓冲（`take-prefill` 读走）→ 不执行、不占 `Out[n]`；
- `!cmd-source`：读文件 → 逐行 `eval-line` → **把 `$.index` / `@.out` / `@.history` / `@.perf-hist` 回滚**（脚本内部的行不算会话的格）；
- `!cmd-paste`：从 stdin 续行读块 → 走与求值器相同的续行判定（`is-incomplete` / `set-continuation`）。

朝外的边很少：`self!split-argv`（参数切分，留 Session 可按名调用）、`self.input-handler` / `self.read-line`（可调用属性，已公开）、`$.sys`（解析路径）。

耦合测量（区间 2401–2638，238 行）：

| 引用 | 区间内 / 区间外 | 处理 |
|---|---|---|
| `@!history` | 8 / 30 | 已是公开 `@.history`（0.147.0 公开） |
| `$!index` | 2 / 17 | 已是公开 `$.index` |
| `$!exit-requested` | 3 / 4 | 已是公开 `$.exit-requested` |
| `@!perf-hist` | 2 / 2 | 已是公开 `@.perf-hist` |
| `$!tty` | 1 / 5 | 已是公开 `$.tty` |
| `$!sys` | 1 / 16 | 已是公开 `$.sys` |
| `&!input-handler` / `&!read-line` | 1 / 0、2 / 0 | 已有公开可调用属性 `self.input-handler` / `self.read-line` |
| `$!prefill` | 1 / 4 | **仍私有** → 走 `!set-prefill` |
| `$!skip-record` | 1 / 5 | **仍私有** → 走 `!mark-recorded` |
| `@!pending` | 2 / 9 | **仍私有** → 走 `!clear-pending` |

对比前四刀：这一簇**没有让任何一个新属性变成公开**。原因见 §3。

## 3. 决定性决定：写侧给窄入口，不公开属性

`$!prefill` / `$!skip-record` / `@!pending` 这三个状态在区间外分别还有 4 / 5 / 9 处引用，都在求值核心（提示符、格记录、续行）里。按 ADR-0060 §3.2，它们该留在 Session；但 role 里只做**写入**，而写入不是对外 API —— 把它做成 `has ... is rw` 会把内部记账暴露成公开可改的界面，以后想收回就难了。

所以改成三个私有方法，只表达意图、不暴露存储：

```raku
method !set-prefill(Str $s --> Nil) { $!prefill = $s; Nil }
method !mark-recorded(--> Nil) { $!skip-record = True; Nil }
method !clear-pending(--> Nil) { @!pending = (); Nil }
```

读侧 `take-prefill`（前端读走预填的唯一入口）**留在 Session**，因为它是真 API：CLI 与测试都靠它，搬进 role 反而让「读一次即清」的语义离调用点更远。

这条细化了 ADR-0060 的规则：

> **属性公开与否，看的是「外部是否该看见」，不是「role 是否需要」。** role 需要写、外部不需要看 → 用私有方法做窄入口。

## 4. 另外三个发现

### 4.1 `&!` 可调用属性早就有公开孪生

区间里的 `&!input-handler` / `&!read-line` 不需要新公开任何东西 —— 它们已经是 `has &.input-handler` / `has &.read-line`，访问器 `self.input-handler` / `self.read-line` 一直可用。role 里直接 `self.input-handler.defined` / `self.read-line()`。

顺带验证了 `paste` 的语义没变：

- `self.input-handler.defined` → **引擎 / notebook 模式**（stdin 是协议流）→ 拒绝，`code=1`，文案「不可用」；
- 未定义 → 普通终端 → 读 `$*IN`，读到 EOF 无内容 → 「没有读到内容」。

t/88 一开始把两种情况的断言写反了（以为「无回调」才是不可用），修测试而不是修代码 —— 这是**测试预期**错误，不是行为回归。

### 4.2 值格的 `.out` 是空的

写守卫测试时踩到的第二个坑：`eval-line('$x + 1')` 的 `.out` 是空串，值在 `.value`；只有 `say` 出来的东西才进 `.out`（`render` 负责把 `.value` 格式化成 `Out[n] = …`）。`source` 的断言因此改成脚本里写 `say $x + 1`，并另用 `.value` 验声明留存。

### 4.3 访问器方法 ≠ 可调用变量：`paste` 死循环

第一版把 `paste` 的读行从私有可调用属性改写成公开访问器时，机械替换成了：

```raku
my $l = self.read-line.defined ?? self.read-line() !! $*IN.get;
```

原代码是 `&!read-line.defined ?? &!read-line() !! $*IN.get`。两者不等价：

- `&!read-line()` 是**调用变量里存的那个闭包**；
- `self.read-line()` 仍然是**调访问器方法**，返回值就是那个 `Block` 本身。

后果不是报错而是失控：每轮 `$l` 都是 `Block` → `Block object coerced to string` 刷屏警告 → `$s.trim` 永远不等于 `--` → `paste` **死循环**。全套件 `prove6 -Ilib t/` 因此跑满 600 s 超时（单跑 `t/05` 也会卡在 paste 段）。

修法：先把闭包取出来，再调用它。

```raku
my $reader = self.read-line;
loop {
    my $l = $reader.defined ?? $reader() !! $*IN.get;
```

**教训**：`has &.foo` 的公开访问器返回的是 `Block` 值，不是「调用结果」。从 `&!foo()` 改写过去时，必须保留一层「取出再调」。`t/88` 的 62–64 三条断言（注入 `read-line` 读 `--`、块内变量可用、`--` 后行不被吃掉）现在钉住这个修法；在此之前全套件是超时而非红，**超时同样是回归信号，别当环境问题重跑**。

## 5. 没采用的方案

- **公开 `$!prefill` / `$!skip-record` / `@!pending`。** §3 的理由：写侧不是 API；而这三个在求值核心里还有引用，公开后既扩大了界面又没减少耦合。
- **把 `take-prefill` 一起搬进 role。** 它是前端读预填的公开 API，搬走会让「读一次即清」与写入方分居两个文件。
- **把 `source` 留在 Session。** `source` 与 `recall` / `paste` 共用续行与历史回滚，且它占区间一半行数；留下它这一刀等于没切。
- **给 role 传 `$!index` 这类可变计数器的引用。** 不需要 —— `$.index = …` 走公开读写访问器，写回真落到对象（ADR-0060 §2.3 已实测）。

## 6. 不变量

- `Session.rakumod` < 2,900 行；Replay 恰好含三条命令，不含 `take-prefill`。
- Replay 里没有任何类私有属性引用（含 `&!`）；三个窄入口留在 Session 且只被 role 以 `self!` 调用。
- 三条命令的对外行为不变：`recall` 回显编号 + 预填、不执行不占格；`source` 逐行求值 + 计数器回滚 + 错误带 `文件:行号`；`paste` 的两种模式判定。
- 两条 `does`（Cells / Replay）与 `use` 都在；`META6.json` 有 Replay 条目（provides 53）。

## 7. 结构守卫清单（`t/88-replay-split.t`，64 条）

1. 文件都在；`unit role ...::Replay` 头正确；Session 的六条 `does` 与六条 `use` 都在。
2. **反方向**：`!cmd-recall` / `!cmd-source` / `!cmd-paste` 不在 Session，而在 Replay；`take-prefill` 在 Session 不在 role。
3. 三个窄入口在 Session、不在 role，且 role 以 `self!name(` 调用。
4. role 零 `$!` / `@!` / `%!` / `&!` 引用；`self.input-handler` / `self.read-line` / 自身 `use` 都在。
5. `cmp-ok $sess-lines, '<', 2900`。
6. `META6.json` provides 有 Replay。
7. 运行时：`recall` 空历史 127；按历史长度算编号取到最近一条；`-1` 取最后一条；预填只给一次；`source` 的 `say` 进 `out`、`index` 与 `history` 只 +1、脚本里的 `my` 留存；`paste` 的两种模式判定各一条，外加 §4.3 的注入 `read-line` 三条（读到 `--`、块内变量可用、`--` 后行不被吃掉）。

## 8. 下一步

- 剩下的大块是 **render 辅助**（`!fmt` / `!render-bytes` / `!render-path-list` 等）与 **补全簇**（`completions` 系列）。补全簇仍被 `@!history`（1/37）与 `%!type-cache`（3/2）压着，但这一刀证明「窄入口」能替代属性公开，所以补全簇的门槛降低了：写 `%!type-cache` 同样可以只给一个 `!cache-type` 私有方法。
- 越往后越该先问：这一簇的写侧是否真需要对外可见？如果不需要，窄入口比公开属性便宜得多 —— 本刀零新增公开面，diff 也更小。
