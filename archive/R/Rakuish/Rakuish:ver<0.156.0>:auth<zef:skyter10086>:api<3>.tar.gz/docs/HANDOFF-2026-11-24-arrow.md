# Arrow 数据通路交接（2026-11-24）

> 面向：接手继续做 Arrow 这条线的开发者 / 下一个 AI。
> 范围：**三个仓库**（Rakuish、DB::DuckDB、Duckula）的 Arrow 读写分层，以及唯一遗留的
> 「C data 逐层读」旁路。
> 通用架构、REPL、Sys、Kernel 这些**不在本文范围**，看 [`../HANDOFF.md`](../HANDOFF.md)。
> 交接时点：2026-11-24 18:40，三个仓库工作区干净、都已推送。

---

## 0. 交接时点：三个仓库的状态

| 仓库 | 路径 | 版本 | HEAD | 分支 | 推送 |
|---|---|---|---|---|---|
| Rakuish | `C:/Users/Admin/rakuish` | `0.122.1` | `ef0f116` | `main` | `origin`（gitee.com/skyter10086/rakuish） |
| DB::DuckDB | `C:/Users/Admin/DB-DuckDB` | `1.3.1` | `a5939ab` | `master` | `origin`（gitee.com/skyter10086/DB-DuckDB） |
| Duckula | `C:/Users/Admin/Duckula` | `0.36.2` | `200e2a7` | `master` | `origin`（gitee.com/skyter10086/duckula） |

测试基线（最近一次全量，改动前后都应复核）：

| 仓库 | 入口 | 结果 |
|---|---|---|
| Rakuish | `bash tools/run-all.sh` | Windows 74 文件 / 3306 断言 0 失败；WSL 74 文件问题 0 |
| DB::DuckDB | `prove6 -Ilib t` | 20 文件 / 632 顶层断言（含子测试 808） |
| Duckula | `prove6 -Ilib t` | 43 文件 / 1616 项 PASS |

本文交付时刚复跑过一次 `raku -Ilib t/78-arrow-fast-path.t`，35 条全绿，环境可用。

依赖链（**顺序不能反**）：`DB::DuckDB` → `Duckula` → `Rakuish`。
每改一层都要 `zef install . --force-install`，否则上层 `require` 到的还是旧版。

- DuckDB 二进制：`DB::DuckDB` 1.2.2 起依赖 `Alien::Libduckdb:ver<1.2.1+>`（DuckDB 2.0）。
- Arrow 文件能力：靠 DuckDB 社区扩展 `nanoarrow`（本机两平台都装了 0.10）。
  扩展是**实例级 `LOAD`**，默认不联网安装，只有 `:install` 才 `INSTALL nanoarrow FROM community`。

---

## 1. 用户这轮要什么（以及已经定下的分层）

起点是「Rakuish 的 Arrow 读写和 IPython 对标还有多少缺口」。讨论到中途用户连续否掉了
两个方向，最终定下的结论是下面这张分层图 —— **这是这条线的宪法，别再改了**：

```text
Rakuish            表语义 / open-data / save-data / 分发 / 展示 / REPL 交互
   │  只调 API，不碰 Arrow 字节，不碰 C
Duckula            DataFrame 门面：read-arrow / write-arrow / ipc-buf / Frame
   │  只调连接层方法
DB::DuckDB         C data + 文件级 IO：Result / ColumnView / read_arrow / COPY
   │  FFI
DuckDB + nanoarrow C++ 里解 Arrow，Raku 侧零拷贝
```

三条被明确否决或纠正过的路线，写下来防止下一任重走：

1. **「让 Rakuish 自己解 Arrow」** —— 用户原话：「不是有 Duckula 和 DB-DuckDB 吗？
   怎么也轮不到 Rakuish 啊，你这设计上是不是不切实际了」。现在的 1300 行自研
   `Rakuish::Data::Arrow` 只是**降级兜底**（零原生依赖、边界检查齐全），不是主路。
2. **「Arrow::IPC 反过来依赖 DB::DuckDB」** —— 它在分层里是**零依赖的格式层**，
   桥的是「值」不是「依赖」：Rakuish 把 Table 写成 IPC 字节、Duckula 把 Frame 读成
   IPC 字节，两边都用它，但它谁都不 `use`。别为了省事把它接到 DB::DuckDB 上。
3. **「Arrow 底层 API 放 DB::DuckDB、高级 API 放 Duckula、Rakuish 只写接口」** ——
   用户最后确认的方案，就是这个（原话「更合理」）。

用户还明确说过的取舍：**Rakuish 为了性能可以牺牲一些灵活度**。即白名单外的东西宁可
走慢路，也不要在 Rakuish 里做通用 Arrow 解码。

---

## 2. 已经落地的（按版本）

### Rakuish

| 版本 | commit | 内容 |
|---|---|---|
| `0.121.0` | `c38142e` | 写侧多批 / 流式：`IpWriter.start/add-batch/finish`、`write-ipc(:batch-size)`、`write-ipc-file`、`write-ipc-stream`、`ipc-batch-count`、`save-data :batch-size`（ADR-0045） |
| `0.121.1` | `745cfad` | 只支持标准 Rakudo，清掉 rakupp 叙述（ADR-0046） |
| `0.122.0` | `1acae9b` | `.arrow` **读侧标量列交给 DuckDB**，其余原路（V-318 / ADR-0047） |
| `0.122.1` | `ef0f116` | `decimal` 进快路白名单（依赖 DB::DuckDB 1.3.1） |

读侧快路的判定在 `lib/Rakuish/Data.rakumod`：

- `:318` `FAST-ARROW-KINDS = <int float bool utf8 large-utf8 date timestamp decimal>`
- `:326` `fast-arrow-wanted($abs)` —— 环境开关 + **≥1 MB 阈值**（压缩文件例外）
- `:333` `fast-arrow-ok(@kinds)` —— 所有列类型都在白名单
- `:391` 真正分流；失败静默回落，绝不因为快路抛错

快路本体在 `lib/Rakuish/Data/Duck.rakumod`：

- `:142` `arrow-native-available`（进程级缓存三件套是否齐全）
- `:157` `read-arrow-native($path)` → `table-from-frame`
- `:78` `table-from-columns(@names, %dtypes, @raw)` —— 列名 + SQL 类型名 + 行 → Table

**不在白名单里、故意不进的**：`time`、`duration`（DuckDB 出口是秒数，自研是文本）、
带时区 `timestamp`（偏移 vs 归一 UTC）、`binary`（Buf vs `\x` 转义 Str）、嵌套 / 字典。
原因只有一个：**SQL 文本出口和自研读入器的值不一致**，快路只收「逐值一致」的类型。

### DB::DuckDB

| 版本 | commit | 内容 |
|---|---|---|
| `1.3.0` | `8e0d1bb` | 新增 `lib/DB/DuckDB/ArrowFile.rakumod` + `Connection.read-arrow/write-arrow/to-arrow-ipc/arrow-available/nanoarrow-version` |
| `1.3.1` | `a5939ab` | 修 `ColumnView.int64` 拼 128 位时高字没做补码扩展（负 DECIMAL 变天文数字） |

50k × 3 列实测：读 4 ms、写 44 ms（纯 Raku 编解码是 1.58 s / 2.79 s）。
设计文档在 `DB-DuckDB/docs/DESIGN-arrow-file-api.md`（338 行，§13 有四处落地偏差，
先读 §13 再读正文，否则会以为设计没实现）。

### Duckula

| 版本 | commit | 内容 |
|---|---|---|
| `0.36.0` | `8119335` | `read-arrow` 默认走 DuckDB（`CREATE TEMP TABLE ... AS SELECT * FROM read_arrow(?)`），纯 Raku 解码降为兜底；`DUCKULA_ARROW_RAKU=1` / `:native(False)` 可强制 |
| `0.36.1` | `45b8878` | excel crc32 复用 `Compress::Zlib::Raw`，消除双 zlib 实例 |
| `0.36.2` | `200e2a7` | `Frame.column()` 只查那一列，不再整表算 |

5 万行 × 3 列：2.75 s → 8 ms。嵌套列还原成真 `STRUCT` / `MAP` / `T[]`，
`FixedSizeList` 从报错变可读（DuckDB `ARRAY`）。

---

## 3. 现在一条 `.arrow` 读进来到底走哪条路

`open-data("x.arrow")` 的决策顺序（改代码前先把这张表背下来）：

```text
1. 只读 schema（ipc-column-kinds-file：file 读尾部 Footer、stream 读开头 64KB）
2. fast-arrow-wanted?  否 → 3
   ├─ RAKUISH_ARROW_RAKU 有值 → 3
   └─ 体积 < 1 MB 且非压缩 → 3
3. fast-arrow-ok?      否 → 4
   └─ 任一列类型不在白名单 → 4
4. 走 Duckula.read-arrow → Frame → table-from-frame    （快路，DuckDB 解码）
5. 走 Rakuish::Data::Arrow 自研读入器
6. 自研抛 X::Rakuish::Arrow::UnsupportedType（嵌套/字典/压缩）→ 回退 Arrow::IPC
7. 结构错误绝不回退 —— 直接抛，防止把坏文件静默读成空表
```

当前的实际效果（Windows 实测）：

| 场景 | 走哪条 | 耗时 |
|---|---|---|
| 5 万行标量 | 快路 | 1.2–1.6 s（原 2.60 s） |
| 50 万行标量 | 快路 | 13.1 s（原 23.4 s） |
| 嵌套列（list/struct/map） | 自研读入器 | 5 万行 × 5 列约 4.3 s |
| 压缩（zstd）标量 | 快路 | 从「报错」变「能读」 |
| 3 行小文件 | 自研（阈值内） | 毫秒级 |

写侧只有一条路：`Rakuish::Data::Arrow`（纯 Raku）。**这是刻意的** —— Duckula 的
`ipc-buf` 早期在 temporal 列上产出过坏字节流，现在虽然 Arrow::IPC 0.1.2 已修好，
但写侧换底没有收益（44 ms vs 2.65 s 只在 5 万行以上才显眼），所以没动。

---

## 4. 唯一待办：C data 逐层读旁路

用户原话（2026-11-24 最后一轮）：

> 「好，真正的旁路要用 DB::DuckDB::Arrow 的 C data 逐层读，那个随后再做」

### 4.1 为什么还要做：瓶颈已经不在解码

50 万行标量文件，13.1 s 的构成（实测拆解）：

| 阶段 | 耗时 | 说明 |
|---|---|---|
| DuckDB 读文件 | 20–300 ms | 已经可以忽略 |
| `Frame.rows` | **≈ 6 s** | 把每行物化成 `Array`，50 万 × N 个容器 |
| `table-from-columns` | **≈ 4 s** | 每格再包一层 `Hash`，再扫一遍做 datetime 还原 |
| 其余 | 约 3 s | 协议、类型判断、Table 构造 |

结论：**再快的解码器也没用**，钱花在「Raku 侧物化」上。而物化是 Duckula 的
`Frame` 语义（行 Hash）强加的。要跳过去，只能从 `Result` 的 `ColumnView` 一列一列
直接读 C 数据，按列构造 Table —— 这正是用户说的「逐层读」。

### 4.2 目标（用来判断做完没有）

| 指标 | 现在 | 目标 |
|---|---|---|
| 50 万行标量 `.arrow` | 13.1 s | ≤ 5 s |
| 5 万行嵌套 `.arrow` | 4.3 s（自研） | ≤ 1.5 s，且**结构保真** |
| 嵌套列的值 | 自研给 `Hash`/`Array`，快路给文本 | 两条路**逐值相同** |
| 内存峰值 | 行 Hash 全量常驻 | 列式读出后再建行，峰值不高于现在 |

### 4.3 分三步改（顺序不能反）

#### 第一步：DB::DuckDB —— `ColumnView` 支持嵌套类型

现状：`raw-type` 白名单只有标量（`ColumnView.rakumod:49` 的 `%WIDTH`），
`LIST` / `STRUCT` / `MAP` / `ENUM` 保留 chunk 句柄、每次按段解码成**文本**。
这就是「嵌套列一过 SQL 就只剩文本」的根源。

要做的：

- `DB::DuckDB::ColumnView` 增加 `at($i)` 对 `DUCKDB_TYPE_LIST` / `STRUCT` / `MAP`
  的真值解码，递归到子 vector：
  - `LIST`：`duckdb_list_vector_get_child` + `duckdb_list_vector_get_size`，
    父层给的是 `duckdb_list_entry { offset, length }`（16 字节，直接按 `CArray` 读）。
  - `STRUCT`：`duckdb_struct_vector_get_child(vec, i)`，子列名走
    `duckdb_struct_type_child_name`。
  - `MAP`：物理上是 `LIST<STRUCT(key, value)>`，按 LIST 走再拆两个子列。
  - `ARRAY`（`FixedSizeList`）：`duckdb_array_vector_get_child` + 定长切分。
- **子 vector 取句柄的 FFI 已经绑好了**（`Native.rakumod:563` list、
  `:572` array、`:584` struct），**还缺两样**：`duckdb_list_entry`
  （`{ uint64 offset; uint64 length }`，16 字节，按 `CArray` 读）这个结构体声明，
  以及 `duckdb_list_vector_get_size` 的绑定。别以为不用补 FFI 就开工。
- 递归要有深度上限（建议 16）和节点预算，防止恶意/畸形列把 Raku 拖死。
- NULL 必须在**每一层**都判：`is-null($i)` 只说了父值，LIST 里的 NULL 元素、
  STRUCT 里的 NULL 字段要各自看子 vector 的 validity。
- `to-list(:typed)` 与 `column()` 的口径必须一致 —— 这是 1.3.0 就立下的契约
  （`t/03` 的「与文本渲染一致」）。**不要顺手改 `BLOB` 的默认解码**，
  `to-arrow-ipc` 依赖它现在的行为（见 §4.5）。

测试：`DB-DuckDB/t/20-arrow-file.rakutest` 加一组嵌套往返，
断言用 `EXCEPT ALL` 双向比对（Duckula t/17 的写法可以直接抄），
再加一条「深层嵌套 + 每层都有 NULL」的用例。**别只测顶层**。

#### 第二步：Duckula —— 从 `Result` 直接建 `Frame`，绕过 `rows`

现状：`Frame.rows`（`lib/Duckula/Frame.rakumod:167`）返回 Array of Array，
是 6 秒的大头。

要做的：

- 新增 `Duckula::Frame.from-result($result, :@names, :%dtypes)`（名字可改，
  但**不要**改成 `read-arrow` 的默认行为）：内部走 `Result.column-views`，
  每列一次 `to-list`，再按列填进 Frame 的列存储。
- `Frame` 目前是行式的吗？先读 `Frame.rakumod` 再动手 —— 如果底层就是
  行数组，这一步只能做到「少一次中间 `rows`」，收益约 6 s → 2 s；
  要彻底列式化，属于 Duckula 的内部重构，**评估后再决定要不要做**，
  别为了 Rakuish 一个调用方把 Duckula 主干拆了。
- `Session.read-arrow` 加 `:materialize('rows'|'columns')`，默认保持 `rows`。
- `t/17` 现有 42 条两路比对必须继续绿；新路径补一组 `columns` 与 `rows`
  的 `EXCEPT ALL` 等价断言。

⚠️ `Result.column-views` **只能叫一次**（第一个读者独占，`t/03` 与
1.3.0 的测试都踩过），要多个读者就 `column-arrays` 一次取完。

#### 第三步：Rakuish —— 白名单放开嵌套，并省掉逐行 Hash

- `table-from-columns` 增加「已是列」的入口（例如 `Table.from-columns(:@columns,
  :@types, :%column-data)`），避免 `for @raw -> $r { my %h; ... }` 那 4 秒。
  如果没必要动 Table 的构造器，也可以在 `Duck.rakumod` 里先建列再一次性组行。
- 白名单扩到 `list` / `map` / `struct` / `large-list` 等 —— **前提是第一步做完**，
  且 `t/78` 的「逐值一致」比对能覆盖嵌套。快路和自研对同一个文件的输出必须
  完全一致，不一致的类型继续留在白名单外（这是 0.122 立下的规矩）。
- 白名单扩容必须同时改 `t/78`（35 条）与 `SPEC.md §3.57` / ADR-0047，
  并在 `HANDOFF.md` 的版本行里写清「哪些类型进来了、哪些还在外面、为什么」。

### 4.4 明确不要做的

- 不要让 Rakuish 反过来自己解析 Arrow（§1 已否决）。
- 不要用「DuckDB 的文本出口」当嵌套列的值（`[a, b]` / `{'name': ann}` 是不可逆的）。
- 不要为了快路改 `BLOB` 的默认解码（`t/03` 契约 + `to-arrow-ipc` 依赖）。
- 不要把 `Frame` 的默认物化方式改掉（Duckula 有别的调用方）。
- 不要不加开关就改默认行为：保留 `RAKUISH_ARROW_NATIVE` / `RAKUISH_ARROW_RAKU`
  两个强制开关，出问题时要能一条命令回到旧路。

### 4.5 顺手可以做的（低风险，但不属于这条线）

- `to-arrow_ipc` 必须传子查询，裸表名会触发扩展内部断言
  `Expected struct child 1 to have length >= 1 but found child with length 0`
  —— 这是 nanoarrow 的行为，已在 `DESIGN-arrow-file-api.md §13` 记过，
  别当 bug 修。
- `read-arrow(:$schema)` 没做：扩展要求 `MAP(VARCHAR, STRUCT(name, type,
  default_value))`，拼 SQL 注入面大、收益低。要做先评估注入面。

---

## 5. 环境与验证命令

```bash
# 依赖顺序：改了下层一定要重装
cd C:/Users/Admin/DB-DuckDB && zef install . --force-install
cd C:/Users/Admin/Duckula     && zef install . --force-install
cd C:/Users/Admin/rakuish     && zef install . --force-install

# 单测
raku -Ilib t/78-arrow-fast-path.t          # Rakuish 快路 35 条
raku -Ilib t/74-arrow-read.t               # 读侧原路
raku -Ilib t/77-arrow-write-batches.t      # 写侧多批 46 条

# 下层（注意扩展名是 .rakutest）
cd C:/Users/Admin/DB-DuckDB && raku -Ilib t/20-arrow-file.rakutest   # 13 子测试
cd C:/Users/Admin/Duckula   && raku -Ilib t/17-arrow-read.rakutest   # 两路比对
cd C:/Users/Admin/Duckula   && raku -Ilib t/20-arrow-cache.rakutest  # 强制兜底

# 全量
bash tools/run-all.sh                      # Rakuish，Windows 与 WSL 都跑
prove6 -Ilib t                            # DB-DuckDB / Duckula

# 强制走某一条路（排查用）
$env:RAKUISH_ARROW_RAKU=1                  # PowerShell：强制自研
$env:RAKUISH_ARROW_NATIVE=1                # 强制快路（忽略阈值）
$env:DUCKULA_ARROW_RAKU=1                  # Duckula 强制纯 Raku 解码
```

WSL 注意：

- 用 `wsl -d Ubuntu bash -lc '...'`，**不要** `wsl -d Ubuntu -- /home/...`
  （wsl.exe 会做路径转换，给路径加前缀）。
- 看快路是否真跑：`arrow-native-available` 要 `:conn.arrow-available` 为真，
  即 `nanoarrow` 扩展装好。WSL 与 Windows 是两套 DuckDB 实例，各自要装。
- WSL 里编辑 `\\wsl$` 路径的工具会失效，用 heredoc 写文件。

---

## 6. 坑清单（都踩过，别再踩）

### Rakudo 2026.11 语言层

| 坑 | 正确写法 |
|---|---|
| `=:= IterationEnd` 恒 False | 用 `~~ IterationEnd` |
| block 里 `return` 是 non-local | 直接退出外层 sub；循环里用 `last` 或手写 pull |
| `($first, \|$iter)` 把 Iterator slip 成 List | 手写 pull 循环 |
| `now-$t0` 被解析成 routine `now-` | 写 `now - $t0` |
| `my @x = try {...}` 失败得 `[Any]` | `my @x = (try {...}) // ()` |
| `my %m = try { ... }` 得 Nil 后塞 Hash | 先绑标量、`$m ~~ Hash` 再取值 |
| `try { ...; Nil }` 永返回 Nil，测「应抛异常」会假绿 | 用 `caught { }` helper |
| `use Mod :name` 是 tag 导入 | `use Mod;` 或 `<&sub>` |
| `Buf[range]` 给 List，`spurt` 会写成字符串 | 切字节用 `subbuf` |
| `Buf.subbuf(4,6).decode('ascii')` 对二进制抛错 | 比 list，别 decode |
| `"abc".Int == 0` | 核类型时先看值是不是 Int |
| `require ::('Duckula')` 静默 Nil | 字面 `require Duckula;`，类从 `Duckula.WHO<Session>` 取 |
| 类对象 `.defined` 为 False | 用 `^can('new').elems` 判存在 |
| `Result.column-views` 只能叫一次 | 一次取完 |

### 上游 / 工具

- **Arrow::IPC `decode-ipc` 遇非法 FlatBuffers 直接段错误（rc=139）**，`try` 接不住
  —— 已报 issue `#IKXKJU`。Rakuish 的护栏是「先自研、只有 `UnsupportedType`
  才回退」（ADR-0044），**结构错误绝不回退**。
- Duckula `ipc-buf` 的 timestamptz 坏流**已由 Arrow::IPC 0.1.2 修好**，
  issue `#IKXKJW` 可以直接关（0.36.0 复核过 t/39、t/40）。
- 零 record batch 的合法空文件：DuckDB 报 `Expected continuation token
  (0xFFFFFFFF) but got 16`，pyarrow 认为没问题 —— Duckula 已做自动回落。
- `LOAD nanoarrow` 是**实例级**；每个新建连接都要它自己 `LOAD`（1.3.0 已处理）。
- `FORMAT ARROW` 产 file 格式（pandas `read_feather` 可读），`ARROWS` 产 stream
  （pandas 读不了）。官方文档只写了 ARROWS，**每升级一版 DuckDB 都要复核**。
- `open(:bin).read` 不关句柄会让 Windows 上后续覆盖写失败 —— 用 `slurp(:bin)`。
- Windows 覆盖写失败还可能因为残留 `rakuish.exe` / `rakudo` 进程锁 precomp，
  不是代码 bug。
- 测试夹具里的字节文件不能用 Python `write_text`（会翻成 CRLF），要 `write_bytes`。

### Gitee API（提 issue 用）

- 创建 issue 走**扁平路径**：`POST /api/v5/repos/{owner}/issues` + 表单
  `repo={name}`。标准路径 `/repos/{owner}/{repo}/issues` 一律 404
  `Not Found Project`，和权限不足报同一句，极易误判。
- 令牌在 `C:/Users/Admin/private-token.txt`，用完别写进仓库（0.121.1 就误提交
  过一个 `r2.json`）。提交前逐个看 `git status --short`。

---

## 7. 文档地图（哪份管什么）

| 文档 | 内容 | 状态 |
|---|---|---|
| `DB-DuckDB/docs/DESIGN-arrow-file-api.md` | 文件级 Arrow API 设计 + §13 四处落地偏差 | **当前**，先读 §13 |
| `rakuish/docs/ADR-0044-arrow-read-routing.md` | 读侧分流与坏文件护栏 | 当前 |
| `rakuish/docs/ADR-0045-arrow-batch-write.md` | 写侧多批 / 流式 | 当前 |
| `rakuish/docs/ADR-0047-arrow-read-native.md` | 标量列交给 DuckDB | 当前 |
| `rakuish/SPEC.md §3.57` | 读侧分流的规格化描述 | 当前 |
| `rakuish/docs/MANUAL.md` | 面向用户的数据层用法 | 当前 |
| `rakuish/HANDOFF.md` | 通用交接（REPL/Sys/Kernel） | 当前，本文的父文档 |
| `rakuish/docs/ADR-0038` / `ADR-0041` / `ADR-0043` | 早期 Arrow 决策 | 部分被 0044/0047 取代，读时注意顶部注记 |
| `rakuish/tools/probe/*` | rakupp 相关探针 | **历史归档**，不是待办（ADR-0046） |

---

## 8. 接手第一小时做什么

1. `cd` 三个仓库，`git log --oneline -3` + `git status -sb`，确认与 §0 一致。
2. `zef install . --force-install` 三个仓库（顺序 DB::DuckDB → Duckula → Rakuish），
   否则你测的是旧代码。
3. 跑 `raku -Ilib t/78-arrow-fast-path.t` 与 `raku -Ilib t/74-arrow-read.t`，
   确认 35 条 + 全绿，再跑一次 `bash tools/run-all.sh` 确认基线。
4. 用 `RAKUISH_ARROW_NATIVE=1` / `RAKUISH_ARROW_RAKU=1` 对同一个 5 万行文件各跑一次
   `open-data`，亲眼看到两条路输出一致 —— 这是后面所有改动的判据。
5. 读 `DB-DuckDB/lib/DB/DuckDB/ColumnView.rakumod` 的头部注释（寿命、flat 假设、
   哪些类型不 take risk），再读 §4.3 第一步。
6. 动手前先写 ADR（编号 0048），把「快路扩到嵌套」的判据写死在文档里，
   再改代码 —— 这条线已经因为「先写码后补文档」返工过两次。

**不要做的事**：不要重写 Arrow 编解码；不要把 Arrow::IPC 接到 DB::DuckDB；
不要为了跑绿测试放宽「逐值一致」的比对；不要在 Rakuish 里加第二套解码。
