# ADR-0039 · Windows 子树回收用 Job Object，不动 fg/bg

- **日期**：2026-11-23
- **对象**：0.117.0（`Rakuish::Sys::WinJob` + `Eval::Client`）
- **状态**：**已实施**（Windows 真机 t/71；POSIX 整段 skip）
- **输入**：用户指出「引擎被 Ctrl-C 终止再重建时，它启动的前台命令和孙进程由谁回收？
  Windows 上没有任何机制能回收它们」，并建议 Job Object + `KILL_ON_JOB_CLOSE`
- **相关**：[ADR-0010](ADR-0010-job-control-feasibility.md)（§3 本次一并更正）、
  [ADR-0031](ADR-0031-job-control-api.md)（V-905 的出处）、SPEC V-309

## 1. 问题

引擎是 `Eval::Client` 起的子进程。用户按 Ctrl-C 时，父进程 kill 掉引擎、重启、
从快照恢复。**引擎在死之前 spawn 出来的东西没人管**：

- 引擎里 `! long-command` 起的命令行进程；
- 那条命令自己再起的孙进程（编译器、测试跑起的 worker…）。

POSIX 上这部分由进程组兜住（ADR-0010 的进程组交接）。Windows 没有进程组，
也没有「父进程死了孩子跟着死」——进程是独立的，父进程一死，子进程原地变孤儿。
ADR-0031 因此把「孙进程树回收」写进「不做（V-905）」。

## 2. 决定

用 **Job Object** 解决「回收」，不碰「作业控制」：

| 项 | 做法 |
|---|---|
| 归属 | `Client.start` 起好引擎后立刻 `CreateJobObjectW` + `AssignProcessToJobObject` |
| 限制 | `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`（`JobObjectExtendedLimitInformation`） |
| 杀 | Ctrl-C 中断 / `restart` / `shutdown` → `TerminateJobObject` 再关句柄 |
| 兜底 | 宿主退出 → 句柄自动关闭 → `KILL_ON_JOB_CLOSE` 收掉整棵子树 |
| 降级 | 非 Windows / 32 位 / 建 job 或归类失败 → 旧行为（只 kill 进程），不阻塞启动 |

**为什么这不算 job control**：没有前台进程组、没有挂起、没有 `fg`/`bg`。
它只回答「这些进程该由谁杀」，不回答「谁该收到键盘信号」。ADR-0031 的
POSIX-only 立场与此并列存在，不需要改。

## 3. 实现要点（三个坑）

1. **嵌套 CStruct 的 `nativesizeof` 算错**：把 `JOBOBJECT_BASIC_LIMIT_INFORMATION`
   与 `IO_COUNTERS` 嵌进 `JOBOBJECT_EXTENDED_LIMIT_INFORMATION` 时，Rakudo 报
   48 而不是 144，`SetInformationJobObject` 于是**静默失败** —— job 建出来了，
   但没有任何限制，最坏的一种错法（看起来启用、实际不回收）。改成平铺一张
   144 字节的表，并在 `layout-ok` 里断言。
2. **Pointer 判空不能写 `!~~ Pointer`**：Pointer 的实例也满足类型检查，
   那样连有效句柄一起拒掉（`create` 永远返回类型对象）。只判 `.defined`
   —— NULL 回来的是类型对象。
3. **`IsProcessInJob` 要 `PROCESS_QUERY_LIMITED_INFORMATION`**，否则返回 0，
   诊断永远假阴性；出参必须是 `CArray[int32]`，传裸 `int32` 会报
   "expected CPointer representation, but got a NativeRef"。

这三条都是「调用成功但语义没生效」的类型，靠返回值判断不出来，只能靠
端到端行为验证（t/71 用 `OpenProcess` 判活）。

## 4. 与 ADR-0010 §3 的更正

用户同时指出 ADR-0010 §3 的措辞可能把两种 Ctrl 事件合并了。实测确认：

| 事件 | 定向到 pgid | 无 handler | 有 handler |
|---|---|---|---|
| `CTRL_C_EVENT` | 函数返回 TRUE | **不投递**，子进程存活 | 不投递，handler 不触发 |
| `CTRL_BREAK_EVENT` | 函数返回 TRUE | **终止**（`0xC000013A`） | handler 触发（`SIGBREAK`），进程继续 |

即 MSDN 那条限制只针对 `CTRL_C_EVENT`；`CTRL_BREAK_EVENT` 在
`dwProcessGroupId` 非零时是可投递的，语义近 **SIGQUIT**。但它换不来前台组与
挂起语义，所以「job control 只能 POSIX-only」的结论不变，只是理由要说准。
详见 ADR-0010 §3.1–§3.2。

## 5. 不做的事

- 不做 `WINDOW_BUFFER_SIZE_EVENT` 常驻监听：`ReadConsoleInput` 会和 Ctrl-C 的
  事件 tap 抢同一个 console 输入队列，抢队列的代价大于「下一格才刷新宽度」的
  损失。`term-size()` 每格轮询继续用（ADR-0010 §3.3）。
- 不把 `tty-exec` 换成 `CreateProcess` + `CREATE_NEW_PROCESS_GROUP` + 定向
  `CTRL_BREAK`：能力已经验证可用，但 `! --tty` 期间用户按 Ctrl-C 期待的是
  中断（SIGINT），换成默认终止（近 SIGQUIT）行为差异肉眼可见，且要再写一条
  spawn 路径。记为「已验证、未采用」。

## 6. 验证

t/71（17 条，Windows 真机）：结构体尺寸、`create`/`assign`/`in-job`、
`TerminateJobObject` 回收、`KILL_ON_JOB_CLOSE` 关句柄回收、**引擎里的孙进程在
`restart` 后消失**、`shutdown` 后句柄释放。POSIX 整段 skip；Linux 上模块可加载
（native 符号调用时才解析）。
