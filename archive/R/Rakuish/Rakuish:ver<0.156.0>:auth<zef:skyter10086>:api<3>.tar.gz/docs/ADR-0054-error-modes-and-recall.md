# ADR-0054 错误分级 `errors` 与 `recall` 预填

- 状态：已实施（0.140.0 / V-344）
- 日期：2026-11-26
- 相关：[ADR-0036](ADR-0036-input-loop-ownership.md)（输入循环所有权，决定了 recall 不做按键注入）、
  [ADR-0051](ADR-0051-engine-protocol-contract.md)（结果帧字段，决定了分级只改文本不改协议）、
  SPEC §3.73

## 1. 背景

评审（`docs/REVIEW-VS-IPYTHON-2026-11-24.md` 行 457 / 462）两项：

- **P2.2**：错误分级 `errors short|full` —— 区分编译 / 运行 / 被拒，默认给位置。
  IPython 的 `%xmode` 是同一件事：用户先要知道「是我写错了语法、数据跑炸了、
  还是工具不让我这么干」，然后才想看帧。
- **P2.7**：`%recall` 等价物 —— `recall n` 把历史放回输入行；「需要行编辑器
  支持预填；若成本高，退化为 `edit n` 打开临时文件」。

现状（0.139.0）：所有失败格都把 `Exception.message` 直接塞进 `Result.err`，
不看类型、不给位置；`%tb` 只在用户显式开 `repl.trace`/按 `tb` 时才出现。
于是「`say foo` 和 `say 1/0` 长得一样」，而位置信息其实拿得到（EVAL 帧有行号），
只是从来没人折算过。

## 2. 决定（A）：错误头一行带类型，位置折算成「第 N 格第 M 行」

```raku
$err = "{$kind}: {$shown}";            # kind ∈ 编译错误 / 运行错误 / 被拒绝
$err ~= "（{$loc}）" if $loc.chars;    # loc = 第 N 格第 M 行（或只有格号）
```

**类型判据写死在代码里，不解析消息文本**：

| 类型 | 判据 |
|---|---|
| 被拒绝 | `$ex.^name` **包含** `X::Rakuish` |
| 编译错误 | `$ex ~~ X::Comp`，或 `^name` 命中 `X::Comp\|Syntax\|Undeclared\|Obsolete\|Redeclaration\|Declaration\|Attribute` |
| 运行错误 | 其余 |

两个坑各踩了一次：

1. Rakuish 自己的异常类声明在 `Rakuish::Result` 里，实际 `^name` 是
   `Rakuish::Result::X::Rakuish::NotFound` —— `starts-with('X::Rakuish')`
   永远不命中，`sys.read` 的不存在文件被误报成「运行错误」（t/82 断言 47 正是钉这条）。
   改成**包含**判定。
2. `X::Undeclared::Symbols`（`say foo`）在不同 Rakudo 版本被不同地归入
   `X::Comp`。本机 `X::Comp::AdHoc` 命中类型判定、`X::Undeclared::Symbols` 不命中，
   所以既要类型判定也要类名前缀兜底。

**位置为什么不是 `文件:行`**：格内代码是 `EVAL "no worries; do { prelude + 本格 }"`
编译出来的，帧文件名是 `EVAL_k`，行号是**整段拼接源码**的行号（wrapper 1 行 +
prelude 若干行 + 本格）。于是：

```
行 = 帧行 - (prelude 行数 + 1)
```

折算结果 `<= 0` 时只报「第 N 格」，不硬造行号（编译错误的行号本来就在
Rakudo 消息里，如 `foo used at line 2`）。真文件帧（`SETTING::` / `src/` /
`.nqp` / 驱动自身 / **调用方**）一律不用：调用方是 CLI 主循环或测试脚本，
报它等于把用户领到我们自己的代码里（实测第一版就报出了
`tmp\probe-err3.raku:9`）。`source` 的文件:行由 `!cmd-source` 自己加
`{$label}:{$n}:` 前缀，这里不重复。

`full` 只是「同一行头 + 完整回放」，实现上把记录异常的判据从
`if $!bt` 放宽成 `if $!bt || $!error-mode eq 'full'`，回放追加同理 ——
否则 `bt = False` 的会话切到 full 也只有头没有帧（就成了一纸空文）。

## 3. 决定（B）：`recall` 交付「预填缓冲 + 回显」，不执行、不按键注入

`recall n` 与 `rerun n` 共用编号（1 基、负数从末尾算、默认上一条），但语义相反：

```raku
$!prefill = $src;                                     # 下一次提示符前被 take-prefill 读走
Result.new(:ok, :op<recall>, :value($src), :out(...)); # 回显，不执行
```

- `take-prefill()` 读一次就清空，并且 `!eval-line-body` 在**任何新格**开头
  都会清掉过期预填 —— 用户敲了别的行，recall 的内容就作废，
  否则下次提示符会莫名带出旧代码。
- 空历史 `code=127`（明确文案），越界 `code=127` 并点名编号，非数字
  `code=2` 给用法；`--help` 在「有没有历史」之前处理，空会话也能查。
- **为什么不真的塞进输入行**：本机 `Terminal::LineEditor` 是 0.0.23，`provides`
  里只有 `LineEditor/Core/DuospaceInput/EditableBuffer/History/RawTerminalInput`，
  **没有 CLIInput**（Keymap 里那句 `try { Terminal::LineEditor::CLIInput.new(...) }`
  就是为此兜底的），也没有任何预填 API。想做只能靠按键注入（往 stdin 里塞字符），
  那是 ADR-0036 明令不走的路：输入循环归前端。
- 于是给出**可被前端消费的契约**：今天 Notebook / 未来的行编辑器实现
  `take-prefill` 就能真预填；其余情况回显**如实说明退路**
  （非 TTY：`rerun n` 或复制那行；TTY：按 ↑ 或 `rerun n`），
  不假装做完了一件没做的事。

## 4. 边界

- 分级只改 `Result.err` 的文本，**不改协议帧字段**（ADR-0051 v2 的
  `error_info` 仍然只带 ename/evalue/traceback）：前端拿到的错误文本照旧一行。
- `error-mode` 是会话属性、默认 `short`，不写进快照（跨会话不继承：
  调试模式是当下的、不是永久的）。
- `last-error-kind` / `last-error-loc` 是观察口，不是语义契约；它们只在失败格更新。
- `recall` 不碰 `%!state` / `@!decls` / 快照：它不执行任何代码。

## 5. 测试

`t/82`（88 条）：分级命令面（无参/切换/非法参数/`--help`/大小写）、
三种类型各自的正例、格内行号（1 行格、2 行格、除零在第 3 格）、
编译错误只报格号不造行号、`X::Rakuish` 真名带 `Rakuish::Result::` 前缀、
`full` 的帧数（11 行）与切回 `short` 后不再带帧、
recall 的空历史/编号/预填一次性/预填过期/越界/非数字/`--help`、
会话在 recall 之后仍可用且变量是原值。
`t/37` 守着命令表与 usage 双向一致。
