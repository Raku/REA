# ADR-0070：混合格里的声明、字符串里的路径、可调用对象的显示（V-364）

- **状态**：已采纳（0.156.0）
- **日期**：2026-11-27
- **相关**：ADR-0006（`t/25` 的 describe 契约）、ADR-0022（快照）、ADR-0048（`display()` 哨兵）、ADR-0053（store）、ADR-0067（命令表）、ADR-0069（Duckula 边界）
- **测试**：`t/94-mixed-decl.t`（26 条）、`t/92-completion-paths.t`（35 条，本轮 +4）、`t/80-display-protocol.t`（52 条，本轮 41 → 52）

## 1. 背景

0.156.0 收的是一批「用户已经撞上、但一直没归因」的体验缺口。三件事在代码里毫无关联，但都属于同一种形状：**会话的核心不变量（跨格可见）在某条不常走的路径上没有被维持**。

1. `my $a = 1; sub f { 42 }` 之后，下一格敲 `f` 报 `Undeclared routine`。
2. `open-data('tmp/` 按 Tab 没有任何候选（变量、模块名、shell 参数位的路径都正常）。
3. `sub { 42 }` 显示成空白格，stderr 同时打 `Sub object coerced to string`。

## 2. 取证

### 2.1 混合格里的声明（最严重）

```
$ raku -Ilib -e 'use Rakuish::REPL::Session; my $s=...;
    $s.eval-line("my \$alpha = 1; my \@arr = 1,2; sub helper2 { 42 }");
    say $s.decls.elems;'
0
$ $s.eval-line('helper2')
ok=False  err=编译错误: Undeclared routine:
    helper2 used at line 2
```

但把同一条声明单独成格就一切正常（`sub helper2 { 42 }` → `@.decls` 有 `sub:helper2`，`helpe<Tab>` 能补出来）。

根因在 `!pure-decl`：它的正则锚在**格首**（`^ [['my'|'our'] \s+ ]? [multi \s+]* (sub|class|…)`），格子只要不是「一条声明」就返回空，于是整格不进 `@.decls`。而 Raku 的词法声明随 `EVAL` 块结束而消失，跨格唯一的延续手段就是 prelude 重放 —— 没进 `@.decls`，下一格就真的没有了。

这不是补全的问题，是**求值核心的状态丢失**：同一条 bug 同时让 `who` 少列一条、`store` 少存一条、快照少一条。

### 2.2 字符串里的路径

```
$s.completions("open-data('tmp/", 15)   # ()
$s.completions('ls tmp/', 7)            # ("ls tmp/floor.raku ", …)   ← 参数位正常
```

Shell 的路径补全挂在「词」上：它把输入按空白切词，只看最后一个词。`open-data('tmp/` 的最后一个词是 `'tmp/`，带引号不是合法路径前缀，于是零候选。引号内是字符串字面量，需要另一条入口。

### 2.3 可调用对象

```
$ bundle-of(sub { 42 })<text>    # ""（空串）
stderr: Sub object coerced to string (please use .gist or .raku to do that)
        in sub bundle-from at lib/Rakuish/Display.rakumod line 388
```

`Display` 的 `Bundle` 分支按「值种类」分发，代码对象落进标量分支，`~$v` 触发 Raku 的 coercion 警告并得到空串。notebook 里显示 `sub`／`block`（比如 `&f`、`&MAIN`）就是空白格。

## 3. 决定

### 3.1 按顶层语句切分，逐条试 `!pure-decl`（`Session.rakumod`）

`!eval-raku` 里新增一条旁路：

```raku
my @mixed-decls = %decl<key> ?? () !! self!decls-in-cell($cell-code);
…
if $ok {
    …
    for @mixed-decls -> %d { self!put-decl(%d) }
}
```

三个新私有方法：

- `!top-statements(Str $src --> List)`：只在**深度 0** 的 `;` 处切，引号、`#` 注释、`()`/`[]`/`{}` 里的分号不算边界，末尾非空段也收。
- `!decls-in-cell(Str $src --> List)`：对每段跑 `!pure-decl`，带 `key` 的收集。
- `!put-decl(%decl --> Nil)`：同 `key` 原位替换，否则 push。

三条硬边界：

| 形状 | 记不记 | 理由 |
|---|---|---|
| `my $a = 1; sub f { 42 }` | 记 `sub:f` | 顶层声明，跨格必须可见 |
| 格首就是声明（`sub f {…}; say 1`） | 走老路 `%decl`（声明格，不产出结果值） | 保持 0.126.0 的既有约定，别在同一版改两件事 |
| `my $a = 1; class C { }` | **不记** | 类型的声明体在声明期求值，混合格每格重放会把副作用带进后续每一格（ADR-0050 红线，`t/18` 第 21 条钉着） |
| `my $a = 1; constant K = 7` | **不记** | 同上：常量的初始化表达式也在声明期求值 |
| `if True { sub inner {…} }` | **不记** | 不是顶层；记了会让 prelude 在块外重放它，语义就变了 |
| 失败格（`sub bad {…}; boom`） | **不记** | 只在 `$ok` 分支写入，失败格没有半截状态 |
| `my $a = 1; $a + 1` | 不记（本来就没有声明） | `!pure-decl` 返回空 |

只在 `%decl<key>` 为空时扫：纯声明格的处理（类型格改写 `$cell-code`、`$slot` 顺序敏感、失败回滚）一行没动。

### 3.2 字符串里的路径走 Shell 的公开入口（`Shell.rakumod` + `Completion.rakumod`）

Shell 新增一个公开方法：

```raku
method path-completions(Str $frag, Str :$before = '' --> List) {
    self!path-candidates('', $before, $frag).List;
}
```

`!path-candidates` 是 0.154.0 加的私有实现（`.`/`..`、`~/`、隐藏文件三条规则都在里面）。补全 role 是**另一个类的 role**，不能跨对象调私有方法，所以要一个窄公开入口 —— 它不是命令 API，只是「给补全用的路径候选」，与 `completions` 同级。

Completion 侧新增 `!string-path-prefix(Str $line, Int $pos --> List)`：扫光标前的文本，找**未闭合的单引号**，返回 `(引号之前含引号的原文, 引号之后的片段)`。三个拒绝条件：

- 双引号 → 放弃。`"$dir/file"` 会插值，补出来的候选全是幻觉。
- 片段里有空白 → 放弃。`say 'hello world` 的 `hello world` 是句子不是路径。
- 引号已闭合 → 不在字符串里，走原来的分支。

命中后把 `$before`（含引号）原样拼回候选，用户输入框里得到的是完整行 `open-data('pkg/alpha.raku`。

顺序：`In/Out` 引用 → 方法名 → **SQL** → **字符串路径** → 会话名字 + Shell。SQL 在路径之前，因为 SQL 字符串是另一种语言上下文，先让它接管。

### 3.3 代码对象有自己的显示分支（`Display.rakumod`）

在标量分支之前加 `if $v ~~ Callable`：

- 种类词用小写分类（`sub` / `method` / `routine` / `block` / `callable`），**不用** `.WHAT.^name` —— 对带签名的 sub，后者给出 `Sub+{Callable[Int]}` 这种内部类型名。
- 具名例程带上名字与签名：`sub helper-demo(Int $x --> Int) { … }`。
- `json` 只放这段文本摘要，**不放代码对象**（不可序列化，也会漏内存地址）。
- `meta<kind>` = `callable`，另带 `type` / `name`。

一个 Raku 陷阱值得记下来：`"{ … }"` 在双引号里是**块插值**，`…` 是 stub 操作符，于是运行期 `Stub code executed`。必须用单引号串拼：`$head ~ ' { … }'`。

## 4. 没采用的方案

| 方案 | 否决理由 |
|---|---|
| 让 `EVAL` 不再包 `do { }`（声明进 GLOBAL） | 这是整个会话设计的根（prelude 重放、失败回滚、`%STATE` 别名都依赖块作用域）；改动面比收益大一个数量级 |
| 把顶层声明提升成 `our` / `package` 里的符号 | 污染 GLOBAL，重定义触发 `Redeclaration of symbol`（ADR-0050 §4 记过 `enum` 的这个坑） |
| 纯声明格也走切分路径 | 类型格要改写 `$cell-code`、`$slot` 有顺序敏感性、失败要回滚 —— 一次改两件事，回归定位会失真 |
| 字符串里也用 Shell 现成的 `completions` | 它按空白切词，`'tmp/` 带引号永远不是合法前缀；与其在 Shell 里加「引号感知」的隐式规则，不如让调用方明确给一次 `path-completions` |
| 双引号字符串也补 | 插值会让候选与真实路径不一致（`"$dir/x"`），补错比不补更糟 |
| 用 `.raku` 显示代码对象 | 会打出整段源码或 `-> ;; $_? is raw { #`(Block|…) }` 这类地址噪声，不是人看的 |

## 5. 不变量

1. 顶层 **sub / use** 声明无论出现在一格的第几条语句，都必须进 `@.decls`（因此 `who` / `store` / 快照 / prelude 全部同步受益）。类型与 `constant` / `enum` / `subset` 只在格首（纯声明格）缓存 —— 声明期求值的副作用不能每格重放。
2. 非顶层（块内）声明不进 `@.decls`；失败格的声明不留痕。
3. 纯声明格的既有行为（不占 `Out[n]`、类型格改写、失败回滚）逐字不变。
4. 字符串路径补全只认单引号、片段不含空白、SQL 上下文优先。
5. `Bundle` 对任何 `Callable` 都产出非空 `text`，且 stderr 不再出现 `coerced to string`。
6. 代码对象不进 `json`。

## 6. 结构守卫

`t/94-mixed-decl.t` 27 条：

- 混合格 sub 存活（值、`key`、`src`、下一格可调）、补全与 `who -l` 都能看见；
- 声明在格首时仍是声明格（`value` 为 `Any`、`Out[n]` 不推进），语句在前时值正常出来；
- 混合格里的 `our sub` 存活；`class` 与 `constant` **不**记录（下一格看不见，ADR-0050 红线）；
- 块内 sub 不记；失败格不记；纯语句格零声明；字符串里的 `;` 不是语句边界。

`t/92-completion-paths.t` 新增 4 条：字符串路径有候选、候选保留开引号、双引号不给候选、含空白不给候选。

`t/80-display-protocol.t` 新增 11 条：匿名 sub 的 `text` 非空、`meta<kind>` 为 `callable`、具名 sub 带名字与签名、`Block` 分类、`json` 是字符串摘要；子进程复跑确认 stderr 无 `coerced to string`。

## 7. 下一步

- `duck-type` 退役与两个 DuckDB 适配层的分工（ADR-0069 第 4/5 条，等「Duckula 运行时可选还是编译期可选」拍板）。
- `rakuish --help` 的 133 行压成一页 quickstart。
- 云端 CI（仓库目前只有 `tools/ci.sh` 本地两层）。
