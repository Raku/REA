# ADR-0068 启动账本与「不拆脚本通路」的决定（V-359）

- 状态：已实施（文档 + 决定；无行为变化）
- 版本：0.154.0
- 条款：`SPEC.md` §3.88
- 相关：[ADR-0055](ADR-0055-path-executable-cache.md)（PATH 表落盘，去掉启动预热）、
  0.106.1 的按模式惰性 `require`（`lib/Rakuish/CLI.rakumod:3-11`、`:28-31`）

## 1. 背景

`rakuish -e '1 + 1'` 在本机要 **630 ms**，跑一个脚本 **601–608 ms**，而裸
`raku -e 1` 只要 137–147 ms。用户问过两件事：

1. 「我记得好像之前做过冷启动的惰性加载了」——**做过**，但做的是「按模式延迟 require
   前端模块」（`lib/Rakuish/CLI.rakumod:28-31`），不是「把 Session 本身拆薄」；
2. 「脚本模式是不是可以按需加载」——这条要拿数字回答，不能凭印象。

于是先把 601 ms 拆开量，再决定要不要动。

## 2. 测量方法与数据

Windows，precomp 预热，3 次取最快。基线 `raku -e 1` = 137–147 ms。

| 命令 | 用时 | 相对基线 |
|---|---|---|
| `raku -e 1` | 137–147 ms | — |
| `raku -Ilib -e 1` | 147 ms | +0 |
| `raku -Ilib -e 'use ZzTiny'`（3 行模块） | **333 ms** | +186 ms |
| `-Itmp/lib1`（仓库里 1 个模块） | 208 ms | +61 ms |
| `-Itmp/lib50`（50 个空模块） | 287 ms | +144 ms |
| `use Rakuish::Result` | 312–371 ms | +175 |
| `use Rakuish::REPL::Session` | 420 ms | +283 |
| `use Rakuish::CLI`（13 个 eager use，含 Session） | **444 ms** | +307 |
| `rakuish --version`（不 require CLI） | 220 ms | +73 |
| `rakuish -e '1 + 1'` | **630 ms** | +493 |
| `rakuish 脚本.rako` | 601–608 ms | +464 |

进程内插桩（`tmp/probe-startup.raku`，wall 630 ms）：

```
require Rakuish::CLI   305 ms
require Session        +3 ms   （已被 CLI 带进来）
其余七个模块           +19 ms
Session.new            17 ms
剩下的 ~286 ms          Rakudo 启动 + 编译 bin/rakuish + 收尾
```

## 3. 归因：哪些是固定成本

1. **Rakudo 进程启动** ≈ 147 ms，不可省；
2. **仓库索引扫描** ≈ 186 ms：只要 `-Ilib` 下用到**任何一个**模块，Rakudo 就要扫
   整个 `lib/.precomp`。规模相关：1 个模块 +61 ms、50 个 +144 ms、本仓 55 个
   `.rakumod` 约 +186 ms。这是**源码检出的本地开发成本**（`lib/.precomp` 在
   `.gitignore:3`，不随仓库分发）。对照 site 仓库（`raku -e 'use Test'` 181 ms、
   `use JSON::Fast` 179 ms，基线 138 ms）：**装机态加载一个模块只 +40 ms 左右**。
   也就是说用户 `zef install` 之后跑脚本约 **450 ms**，不是 601 ms。
3. **编译 `bin/rakuish`** ≈ 73 ms（`rakuish --version` 220 − 147）；
4. **Session 模块加载** ≈ 108 ms（444 − 312）。

1–3 合计约 **406 ms**，占脚本模式 601 ms 的 **68%**，与「惰性加载」无关。

另外：**预编译必须保留**。`RAKUDO_NO_PRECOMPILATION=1` 时 `use Rakuish::Result`
要 **2,189 ms**、`use Rakuish::CLI` 超过 9 秒——任何「去掉预编译换更快启动」的想法
都是反的。

## 4. 已做的惰性加载（回答「之前是不是做过」）

`bin/rakuish` 只 `require` `Rakuish::CLI` 并调 `run()`（`lib/Rakuish/CLI.rakumod:3-11`，
0.106.1）；`CLI.rakumod:28-31` 写明「补全、分页、引擎客户端全部装进来时
`rakuish --version` 也要 1.2 s…现在只有交互式 REPL 才 require 前端模块」。
分支内 `require ::("Rakuish")::REPL::Session` 分别在 REPL（`:329-331`）、脚本
（`:381-383`）、交互前端（`:416-421`）。

所以「按模式延迟」这一层已经吃到上限；再往下只有拆模块依赖图这一条路。

## 5. 两个备选方案与否决理由

### A. 把 CLI 的 13 个 eager `use` 改成按模式 require

理论上限 **24 ms**（`use CLI` 444 − `use Session` 420）。脚本路径本来就需要
Session / Chrome / Term / Factory / Kernel / Audit / Result / Console，真正能跳过的
只有 Shell / Keymap / Eval / Proxy / Pager 五个，合计 10–19 ms。

**否决**：用 13 处 `::("Rakuish")::X` 条件 require + `Renderer`/`Audit` 的
`JSON::Fast` 惰性化，换 2% 启动时间。而且 `Renderer` 的 text 模式也会调
`json-text` 选格式，惰性化点必须放到第一次真正序列化处——收益太小、风险不对等。

### B. 给脚本路径一条不经过完整 Session 的求值通路

新模块（只依赖 Kernel / Factory / Result / Term / Data::Table），能省 Session 的
**108 ms**，脚本启动 601 → 约 493 ms（−18%）。REPL 一分不省。

**否决（产品理由，不是技术理由）**：脚本模式存在的意义就是「脚本跑在同一条
Session 上」——`who`、`store`、快照、`audit`、历史、hook、`set -o` 都来自它。
绕开 Session 等于把脚本降级成裸 Raku，Rakuish 的存在理由随之消失。要保证
`sys` / `repl` / `registry` 注入、start hooks、audit、`$*PROGRAM`、`&MAIN`、
`kind<script>` 一次性语义、DSL 可见性都不变，也要付出等量复杂度。

## 6. 决定

1. **不动 Session 的模块边界**，脚本与 REPL 共用一条会话；
2. **不做方案 A**（13 处条件 require）；
3. 启动开销按 §2 的账本接受：本机 601 ms 里 68% 是 Rakudo 固定成本，装机态约 450 ms；
4. 真要再快，方向是「减少 Session 的**传递依赖**」而不是「绕开 Session」——
   例如把某个重依赖（DuckDB / 前端）改成首次使用时 require。这条留作将来的候选，
   需要单独测量，不在本版做。

## 7. 什么情况下该重新看这件事

- 用户抱怨冷了：先量**装机态**（`zef install` 后）而不是检出目录；
- Session 的传递依赖图发生变化（新增重型模块）时，重新量 §2 的 108 ms 那一段；
- Rakudo 改进 `-Ilib` 仓库索引（把 186 ms 降下来）时，本账本的前三项都要重测。

## 8. 不变量

- `rakuish --version` 不 require Session / 前端模块（`t/07-entrypoints.t` 钉 `--version`，`t/52-load-all-modules.t` 钉每个模块可 require）；
- 预编译保持开启，不引入 `RAKUDO_NO_PRECOMPILATION` 一类的运行前提；
- 脚本模式与 REPL 共用 `Rakuish::REPL::Session`，`kind<script>` 与 `kind<repl>` 只在
  会话配置上分叉。
