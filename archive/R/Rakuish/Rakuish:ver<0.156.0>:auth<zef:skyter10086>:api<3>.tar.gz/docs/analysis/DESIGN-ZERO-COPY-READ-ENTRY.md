---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4f3455b5e94811f1b0c5525400cd780f
    ReservedCode1: K9p2K/FgqSlmR8b1P1sGzTfq9Sk3Bk5RJ9GGnv0H2EAqkfqJnJm60Ajfm4SnX9jn840raWohhw1GJVp5saCM/8C8U1wdWs3qhn/82yquvJPmNJSNtA16CzQP8+eFtYKANJYPouVeBDu0w0/uCAIA6rGGO6jT3TvSN9A1IkyXZD8Ft1OeTWzu0+ffBH8=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4f3455b5e94811f1b0c5525400cd780f
    ReservedCode2: K9p2K/FgqSlmR8b1P1sGzTfq9Sk3Bk5RJ9GGnv0H2EAqkfqJnJm60Ajfm4SnX9jn840raWohhw1GJVp5saCM/8C8U1wdWs3qhn/82yquvJPmNJSNtA16CzQP8+eFtYKANJYPouVeBDu0w0/uCAIA6rGGO6jT3TvSN9A1IkyXZD8Ft1OeTWzu0+ffBH8=
---



# 大数据量零拷贝直读入口：选型、代码骨架与边界

> 目标：回答「这块（大数据量零拷贝直读）怎么实现，用 Duckula 做吗？」
> 结论前置，证据附 `file:line`。所有实测数据来自本机（Windows 11 / Rakudo Star 2026.11 / Duckula 0.50.0 / DB::DuckDB 2.0.0 / nanoarrow 已装），1,000,000 行 CSV。

---

## 0. 结论速览

1. **用 Duckula，但不是现在这条桥。** 现有 `Rakuish::Data::Duck` 的桥是「Table → 自研 Arrow 写临时 IPC → `read-arrow` 建视图 → sql → Frame → Table」（`Duck.rakumod:212` `:259`），对「**文件 → 计算 → 小结果**」这个场景方向反了：数据本来就在磁盘上，却先绕进 Raku 堆再绕出去。
2. **新增一个只管"把手"的入口，不重造 DSL。** 新模块 `Rakuish::Data::Scan`，只做四件事：路径授权、`scan-csv`/`scan-parquet` 建惰性计划、把调用方的 DuckDB SQL/算子组合交给 DuckDB、**只把结果**按上限物化成 `Table`。
3. **不要碰 Duckula 的惰性算子去包一层 Rakuish 版 `filter/groupby`。** Duckula `LazyFrame` 本身已有 79 个惰性方法（`LazyFrame.rakumod:189/384/438/471/975/462`…），rakuish 再包一层只会制造第二套方言；入口只暴露 `.sql(...)` 和 `.frame`，复杂计算让调用方直接用 Duckula 的 `Expr`。
   > 注意 `.sql` 的方言约定：用标识符 **`self`** 指代当前计划（`LazyFrame.rakumod:1073-1090`），且它会立刻建临时视图——计划树里唯一先执行一步的算子。
4. **实测收益极大（同一份 1M 行 CSV）**：
   - 惰性三段式（scan → filter → group-by → agg，97 行结果）：**建计划 1ms + collect 75ms + 封表 241ms ≈ 0.32s**；
   - 全量物化成 `Table`：**38,665ms**（10 万行时 2,272ms，**超线性**）；
   - 惰性直写 Parquet（919,000 行，一行不进 Raku）：**266ms**。
   即：**结果集大小**才是成本函数，不是输入体积。入口的唯一硬约束就是"结果必须小"。
5. **骨架已跑通，不是纸上方案**：`Rakuish::Data::Scan` 落到 `temp/lib` 后 `raku -c` 通过，1M 行 CSV 实测 `open-lazy` 9ms、`sql+封表` 595ms/97 行、`to-parquet` 280ms，上限门禁按预期拒绝（详见 §2.7）。
6. **必须加物化上限（建议 50,000 行）+ 超限显式报错**，否则入口会把 38s 的灾难包装成"优化"。
7. **`Table → DuckDB` 方向仍然是装箱路径，入口不解决它**：两库都无 Arrow C Data / 内存表注册 API，唯一现实路径是 `create-table` + `Appender` 逐值写（`Session.rakumod:436` `:445`）。入口只买"文件→DuckDB"这一段的零拷贝。

---

## 1. 现场事实：版本与可用性（先纠正一条过期记忆）

| 项 | 实测值 | 证据 |
|---|---|---|
| Duckula | **0.50.0**（历史记忆里的 0.33.1 / 0.36 已过期） | `duckula/lib/Duckula.rakumod:60` |
| Duckula 设计边界 | 不写 FFI / 不写列式模型 / 不写计算引擎，全部翻译为 SQL 交 DuckDB | `Duckula.rakumod` 模块文档段 |
| DB::DuckDB | 2.0.0（Duckula 依赖 1.2.2+） | 本机 zef 已装；`Session.rakumod:68` `conn` 返回 `DB::DuckDB` |
| nanoarrow | 已装，`read-arrow` 默认 `:native` | `Session.rakumod:380` |
| 离线兜底 | `DUCKULA_ARROW_RAKU=1` 回落纯 Raku 解码 | `Duckula.rakumod` 文档段 |
| 已知坑 | `DB::DuckDB v2.0.0` 的 `arrow-available(:install)` 误返回 False（探测 bug），实现层需自己诊断 | 历史经验记忆 + `Duck.rakumod:143` `arrow-native-available` |

> 版本差异的实操影响：0.50.0 的 `Frame.dtypes` 仍是**每次 `DESCRIBE` 现算、无缓存**（`Frame.rakumod:1512-1515`），这是下面所有"封表"耗时的隐藏大头。

---

## 2. Duckula 实际 API 能力（逐条回答追问）

### 2.1 直读入口：有，且是惰性的

| API | 行为 | 是否搬数据 | 证据 |
|---|---|---|---|
| `Session.scan-csv(Str $path)` | 建 `LazyFrame` 计划，**不读数据** | 否 | `Session.rakumod:251` |
| `Session.scan-parquet(Str $path)` | 同上 | 否 | `Session.rakumod:259` |
| `Session.read-csv` / `read-parquet` | 急切 `Frame`（执行 `read_csv_auto(?)` / `read_parquet(?)`，参数绑定） | 计划层不搬 | `Session.rakumod:165` `:170` |
| `Session.read-arrow` | 需非 sandboxed，默认走 nanoarrow，**急切建表** | 是（建表） | `Session.rakumod:380` |
| `Session.sql(Str, *@args)` | 参数化 SQL → `Frame` | 视 SQL | `Session.rakumod:148` |

**关键点**：`scan-csv` / `scan-parquet` 不需要临时文件、不需要 Table、不需要 Arrow，直接吃磁盘路径——这正是"零拷贝直读"要的形态。

### 2.2 链式算子 / 惰性 / 表达式

`LazyFrame` 共 79 个 `method`，**全部惰性**，`collect()` 才执行（`LazyFrame.rakumod:90`）。任务点名要核对的算子：

| 能力 | 支持 | 证据 |
|---|---|---|
| `filter`（Expr 版 + SQL 串版） | ✅ | `LazyFrame.rakumod:189` `:194` |
| `select` | ✅ | `LazyFrame.rakumod:384` |
| `with-column` | ✅ | `LazyFrame.rakumod:361` |
| `group-by` → `agg` | ✅ | `LazyFrame.rakumod:471` / `:438` |
| `join`（inner/left/right/outer，`$on`/`$how`/`$suffix`） | ✅ | `LazyFrame.rakumod:975` |
| `limit` / `head` / `tail` / `slice` | ✅ | `LazyFrame.rakumod:462` `:464` |
| `sort-values` / `unique` / `cast` / `pivot` / `sample` | ✅ | `:451` `:561` `:654` |
| 表达式 | `col()` / `lit()` / `case-when` / `least` / `greatest` / 比较与算术运算符 / `.sum .mean .count .alias` | `Duckula::Expr` 导出 |
| `sql`（在帧上接任意 SQL） | ✅ | `LazyFrame.rakumod:1073` |

> `LazyFrame.sql` 是入口设计的关键杠杆：**它让 rakuish 不必翻译任何算子**——调用方想写什么，直接把 SQL 甩进去，仍是同一个惰性计划。

### 2.3 能否避免逐行物化

能。三条出口都不经过 Raku 行对象：

| 出口 | 行为 | 实测（1M 行 CSV → 919,000 行结果） |
|---|---|---|
| `LazyFrame.to-parquet` | DuckDB 内部 `COPY`，一行不进 Raku | **266ms / 1,138,035 字节** |
| `LazyFrame.to-csv` | 同上 | 未单测 |
| `LazyFrame.write-ipc` | Arrow IPC 落盘 | `LazyFrame.rakumod:109` |
| `LazyFrame.collect` → `Frame` | 结果集变 `Frame`（列式，仍不逐行） | 97 行：75ms |

必须逐行/逐值的那一刻只有一个：**封成 `Table`**（`Table` 内部是 `@rows` 的 Hash 数组）。

### 2.4 `Frame` 上的读法差异（决定封表成本）

| 读法 | 语义 | 实测（97 行结果） | 证据 |
|---|---|---|---|
| `names` | `LIMIT 0` 取列名，不搬数据 | 0ms（collect 后命中缓存） | `Frame.rakumod:161` |
| `columns-typed` | DB::DuckDB 1.4 `:typed` 真值列式，一次拿整齐列 | **7ms** | `Frame.rakumod:138` |
| `rows` | v0.37 起是惰性 `RowsView`，访问才解码 | 5ms（97 行） | `Frame.rakumod:169` |
| `dtypes` | **每次 `DESCRIBE SELECT * FROM (...)` 现算，不缓存** | **首 108ms / 二次 38ms** | `Frame.rakumod:1512-1515` |
| `to-table` | Duckula 自带封表（与 rakuish 口径不同，不采用） | — | `Frame.rakumod:376` |

结论：**封表路径选对了（列式），隐藏成本只剩 `dtypes` 的 `DESCRIBE`。**

### 2.5 写回能力

`LazyFrame.to-parquet(:compression)` / `to-csv` / `write-ipc`，`Session.execute`（`Session.rakumod:424`）、`create-table`（`Session.rakumod:445`）、`insert`（`Session.rakumod:436`）。**写回不构成瓶颈**，且无需经过 `Table`。

### 2.6 明确"做不到"的（不要在设计里假设）

- ❌ 没有 `register` / `from-rows` / `from-columns` / 内存表注册 API：跨进程序交换 Arrow 只接受**文件路径**。
- ❌ `Frame.ipc-buf` 在 `TIMESTAMPTZ` 列上产坏字节（rc=139）。
- ❌ 无 `DESCRIBE` 之外的类型元数据通道（prepare metadata 未暴露），所以类型一定有一次 `DESCRIBE` 成本。

### 2.7 骨架实测验证（不是纸上推演）

§4.3 的骨架已落到 `temp/lib/Rakuish/Data/Scan.rakumod` 并通过 `raku -c`（Syntax OK），再用 1,000,000 行 / 36.9MB CSV 跑通全链路：

| 步骤 | 实测 | 说明 |
|---|---|---|
| `open-lazy` 建计划 | **9ms** | 只做扩展名校验 + `scan-csv`，未触碰数据 |
| `names` | 立即返回 `("id","city","amount","day")` | 计划推进到 `LIMIT 0` |
| `.sql(GROUP BY).table` | **595ms**，97 行 | 含 `bind-view` + 聚合 + `DESCRIBE` 类型 + 封表 |
| 封表类型 | `{:city("int"), :n("int"), :total("num")}` | 与 `duck-type`（`Duck.rakumod:30`）口径一致；CSV 里 `city` 本身是数字，故推断为 `BIGINT` |
| 上限门禁 `:max-rows(10)` | **命中并拒绝** | 计划层 `limit(11)` 先探针，再判是否超限 |
| `to-parquet`（97×3） | **280ms** / 1.19MB | `COPY` 直写，无行对象 |

同一次验证还固定下两条**代码级事实**（此前只知文档，未实测）：

1. **`LazyFrame.sql` 用标识符 `self` 指代当前计划**，不是表名 `t`：内部把上游渲染成 SQL、`bind-view` 建临时视图，再把用户 SQL 里的 `self` 替换成视图名（`LazyFrame.rakumod:1073-1090`）。写错表名会在 `Guard.check-sql` 的 prepare 阶段直接报 `Catalog Error: Table with name t does not exist`。**这也是计划树里唯一"会先执行一步"的算子**（建视图无法推迟），`Source.sql` 的注释已写明。
2. **`Sys` 根沙箱对直读同样生效**：`Sys.resolve` 会走 `!assert-in-root`（`Sys.rakumod:219` / `:231` / `:155`），把数据文件放在 Sys 根之外会直接被拒（实测报 `路径越出 root: .../Temp/xxx.csv (root=...)`）。所以直读入口**天然继承**一层路径白名单，`:allow-external` 不是最后一道闸。

顺带一条对"必要性"的补强：**现在的 `open-data` 根本读不了这个文件**——`Sys::FS.read` 默认 `max-bytes = 1MB`（`Sys/FS.rakumod:15` / `:89`），36.9MB CSV 直接抛 `X::Rakuish::Limit`（`open-data` 调 `read` 的路径，`Data.rakumod:370` 起），必须先手动抬上限；即便抬了，全量物化仍是 38.7s。这就是"大数据量"在现状下无处可去的原因。

---

## 3. Duckula vs DB::DuckDB 原生 API：正面比较

场景固定为「**大数据量直读 + 表内计算 + 只把结果物化成 Table**」。

| 维度 | Duckula `LazyFrame` | DB::DuckDB 原生（`Connection.query` / `read-arrow` / `Appender`） | 该场景下谁赢 |
|---|---|---|---|
| 建惰性计划 | 原生支持，`scan-csv`/`scan-parquet` + 79 算子 | 无计划对象，只有"给 SQL 得 Result" | **Duckula** |
| 参数绑定 | `sql($q, *@args)`、算子自动出 `?` 占位 | 有，但需自己拼 SQL 与参数顺序 | **Duckula** |
| SQL 组合 | `LazyFrame.sql` 任意嵌入 | 同样可以，但需自管 SQL 串 | 平 |
| 结果列式取数 | `columns-typed`（`Frame.rakumod:138`）已封装 `:typed` | `column-views` 需自己拿 Result、自己判类型 | **Duckula** |
| 类型元数据 | `dtypes` 走 `DESCRIBE`（108ms，不缓存） | 无便捷 API，仍需 `DESCRIBE` | 平（都付一次） |
| 直接落 Parquet/CSV | `to-parquet` / `to-csv` 一行调用 | `COPY ... TO` 自己写 | **Duckula** |
| Arrow IPC 读写 | `read-arrow`（nanoarrow 或 `DUCKULA_ARROW_RAKU` 纯 Raku 回落） | `read-arrow` / `write-arrow` / `to-arrow-ipc`，写侧**必须先有表在库内** | Duckula（回落更可控） |
| 沙箱/授权 | `Session.new(:sandbox)` → `SET enable_external_access=false`，**不可撤销**（`Session.rakumod:71-86`） | 直接设 DuckDB 选项，但没人帮你守 SQL 白名单 | Duckula（`Guard` 默认 strict 只读） |
| 依赖面 | 依赖 DB::DuckDB + 可选 nanoarrow | 只有 DB::DuckDB | 平 |
| 维护成本 | 一层 SQL 翻译，HTTP 式小 | 大量样板（Result → 列 → Table） | **Duckula** |
| 与 Rakuish 现有代码一致性 | 已是被 `Duck.rakumod` 采用的路径 | 只被 `Engine::DuckDB` 用来跑用户 SQL（`Engine/DuckDB.rakumod:91`） | **Duckula** |

**结论**：直读入口走 Duckula；DB::DuckDB 原生只在两处保留——(a) `Engine::DuckDB` 执行用户手写 SQL（现状，不动），(b) `read-arrow-native`（`Duck.rakumod:158`）与 `Appender` 装箱路径（Table → DuckDB 方向）。

**一条额外的架构收益**：现有 `query()` 对每张 Table 都要写临时 Arrow 文件再注册视图（`Duck.rakumod:212` 起），直读入口把这些临时文件彻底消掉——不仅是快，还少了一处磁盘写与清理风险。

---

## 4. 推荐实现路径

### 4.1 模块与命名

| 项 | 取值 | 理由 |
|---|---|---|
| 新模块 | `lib/Rakuish/Data/Scan.rakumod` → `Rakuish::Data::Scan` | 与 `Data::Duck`（桥）平级，语义是"扫描入口"，不是"又一个引擎" |
| 主入口 | `open-lazy(Rakuish::Sys $sys, Str $path, ...) --> Source` | 与 `open-data`（`Data.rakumod:370`）成对，命名可预测 |
| 句柄类 | `Rakuish::Data::Scan::Source` | 承载 `LazyFrame` + 授权结果 |
| DSL 短命令 | `scan($path, :$allow-external, :%csv-options)` | 与 `open-data` 并列，放在 `DSL.rakumod:86` 之后 |
| 不做 | `Source.filter/groupby/...` 的 Rakuish 镜像 | 第二套方言，维护地狱 |

### 4.2 与现有代码的衔接点

| 衔接点 | 现状 | 变更 |
|---|---|---|
| `Rakuish::Data::open-data` | `Data.rakumod:370`，按扩展名分派，parquet/csv 需 `:allow-external`（`Data.rakumod:381`） | **不改**。它是"取回内存值"的入口；`open-lazy` 是"留在磁盘上算"的入口，二者并存 |
| `Rakuish::Data::Duck` | `table-from-frame:57` / `table-from-columns:72` / `duck-type:30` | **复用**，不复制：`Source.table` 内部调 `table-from-frame` |
| `Rakuish::Data::Table` | 具 `@columns/@rows/%.types` | **不改**。出口永远回落 `Table`，下游 34 处读 `.rows` 与 24 个测试不动 |
| `Rakuish::REPL::Session` | `has $.engine is rw`（`Session.rakumod:44`）、`set-engine:74` | **加一个** `has Rakuish::Data::Scan::Source @.scans` 与 `submethod DESTROY`/`close` 时 `release`，保证 Duckula 会话与临时视图随会话收尾 |
| `Engine::DuckDB` | `safe=True` 默认 `enable_external_access=false`（`Engine/DuckDB.rakumod:31`） | **不动**。它是给用户手写 SQL 的封闭引擎；`open-lazy` 是另一条显式授权通道 |
| `DSL` | `open-data:86` / `save-data` / `sql` | 新增 `scan`；`sql` 不变 |
| CLI / Agent op 白名单 | `Hints.rakumod:21`、`Session.rakumod:1975` 等 | **不暴露** `:allow-external`（沿用 `Data.rakumod:381` 的既有立场） |

### 4.3 代码骨架

```raku
# lib/Rakuish/Data/Scan.rakumod
unit module Rakuish::Data::Scan;

use Rakuish::Sys;
use Rakuish::Result;              # X::Rakuish::Unsupported / X::Rakuish::Data（Result.rakumod:29 / :47）
use Rakuish::Data::Table;
use Rakuish::Data::Duck;          # duck-type / table-from-frame / arrow-native-available
use Duckula;                      # LazyFrame / Session
use Duckula::Expr;                # 仅当调用方用算子，本模块不依赖

# 结果物化上限：> 5 万行就说明"该留在 DuckDB 里，别搬回 Raku"
constant SCAN-MAX-ROWS      = 50_000;
constant SCAN-CSV-EXT       = <csv tsv>;
constant SCAN-PARQUET-EXT   = <parquet pq>;
constant SCAN-ARROW-EXT     = <arrow feather ipc>;

class Source {
    has Duckula::LazyFrame $.lf is required;
    has Str $.path is required;
    has Bool $.allow-external = False;
    has %!types;                  # 缓存 dtypes：DESCRIBE 一次就够（108ms → 0）
    has $!frame;

    # 唯一"执行"点（除非调用方自己 to-parquet / to-csv）
    method frame(--> Duckula::Frame) { $!frame //= $!lf.collect }

    method names(--> List) { self.frame.names.List }

    method types(--> Hash) {
        %!types.elems ?? %!types.Hash !! (%!types = self.frame.dtypes)
    }

    # 帧上接 SQL：不翻译算子，直接交给 Duckula 计划
    # 注意：Duckula 约定用标识符 `self` 指代当前计划（LazyFrame.rakumod:1073-1090），
    # 且 `.sql` 会立刻建临时视图 —— 这是计划树里唯一"会先执行一步"的算子。
    method sql(Str $q, *@args --> Source) {
        Source.new(lf => $!lf.sql($q, |@args), path => $!path,
                   allow-external => $!allow-external)
    }

    # 结果 → Table（唯一逐值物化点），行数上限在**计划层**下推
    method table(Int :$max-rows = SCAN-MAX-ROWS --> Rakuish::Data::Table) {
        my Duckula::LazyFrame $probe =
            $max-rows.defined && $max-rows >= 0 ?? $!lf.limit($max-rows + 1) !! $!lf;
        my $f = $probe.collect;
        my Int $n = $f.elems;                 # count(*)，不搬数据（Frame.rakumod:254）
        if $max-rows.defined && $max-rows >= 0 && $n > $max-rows {
            X::Rakuish::Unsupported.new(
                :detail("直读结果 {$n} 行超过物化上限 {$max-rows}："
                      ~ '请先在 DuckDB 内聚合/过滤，或用 .to-parquet 落盘'
                      ~ '（open-data 全量取回会慢 100× 以上）')
            ).throw;
        }
        $!frame = $f;
        Rakuish::Data::Duck::table-from-frame($f);
    }

    method to-parquet(Str $out, Str :$compression = 'zstd') {
        $!lf.to-parquet($out, :$compression);   # LazyFrame.rakumod:134
    }
    method to-csv(Str $out) { $!lf.to-csv($out) }        # :140
}

# ── 入口 ────────────────────────────────────────────────────────────
our sub open-lazy(Rakuish::Sys $sys, Str $path,
                  Bool :$allow-external = False,
                  :%csv-options = {},
                  :$session,                 # 复用 Rakuish::REPL::Session 的 Duckula 会话
                  --> Source) is export {

    my Str $ext = $path.IO.extension.lc;

    # ① 授权：与 open-data 完全同一条口径（Data.rakumod:381），并补 arrow
    my Bool $needs-grant =
        $ext (elem) SCAN-PARQUET-EXT.Bool
        || ($ext (elem) SCAN-CSV-EXT && %csv-options.elems.Bool);
    if $needs-grant && !$allow-external {
        X::Rakuish::Unsupported.new(
            :detail("直读 .{$ext} 需要显式 :allow-external（路径仍由 Sys 根校验；Agent 不开放）")
        ).throw;
    }

    # ② 路径：一律先经 Sys 校验（与 Data.rakumod:380 一致，杜绝 ../ 逃逸）
    my Str $abs = $sys.resolve($path).Str;

    # ③ 会话：可选传入，否则临时自建（用完由 Source 持有）
    my $sess = $session // Duckula::Session.new;

    # ④ 建惰性计划：这是"零拷贝"的实质——磁盘文件直接成为 DuckDB 关系
    my Duckula::LazyFrame $lf = do {
        if $ext (elem) SCAN-CSV-EXT         { $sess.scan-csv($abs) }        # Session:251
        elsif $ext (elem) SCAN-PARQUET-EXT  { $sess.scan-parquet($abs) }    # Session:259
        elsif $ext (elem) SCAN-ARROW-EXT    {
            # Arrow IPC 无 scan 形态：先 read-arrow 建视图，再 sql 取计划（Session:380）
            die X::Rakuish::Unsupported.new(
                :detail('Arrow IPC 暂无惰性直读；请用 open-data（有纯 Raku 退路）或先转 Parquet')
            ) unless Rakuish::Data::Duck::arrow-native-available;
            $sess.sql('SELECT * FROM ' ~ $sess.read-arrow($abs).relation-sql)
        }
        else {
            X::Rakuish::Unsupported.new(
                :detail("直读只支持 {$ext} 之外的 CSV/Parquet/Arrow；.{$ext} 请用 open-data")
            ).throw
        }
    };

    Source.new(:$lf, path => $abs, :$allow-external);
}
```

**使用形态（三行，零临时文件）**：

```raku
use Rakuish::Data::Scan;

my $src = open-lazy($*RAKUISH-SYS, 'sales-10m.csv', :allow-external);
my $t   = $src.sql('SELECT region, count(*) AS n, sum(amount) AS total
                    FROM self WHERE amount > ? GROUP BY 1', 100).table;
my $src2 = open-lazy($sys, 'events.parquet', :allow-external);
$src2.sql('SELECT * FROM self WHERE level = ?', 'WARN').to-parquet('warn.parquet');
```

> 若调用方更想用算子而非 SQL，把 `$src.frame`/`$src.lf` 交给 Duckula 的 `Expr` 即可：
> `$src.lf.group-by('region').agg(col('amount').sum.alias('total'))` —— rakuish 不再定义第二套。

---

## 5. 入口边界

### 5.1 何时仍然必须物化（不许用本入口）

| 场景 | 原因 | 正确做法 |
|---|---|---|
| 结果 > 50,000 行 | 实测 1M 行封表 **38,665ms**，10 万行 2,272ms，超线性 | 先在 DuckDB 内聚合；或 `.to-parquet` 落盘 |
| 需要 Raku 闭包谓词（`Table.where({...})`） | 谓词是 Raku 代码，DuckDB 无法执行 | `open-data` 取回后再算（并对数据量负责） |
| 需要 `Table` 的交互式方法链（`.get/.select/.sort-by`） | 这些是值 API | 小数据集：`open-data`；大数据集：改写成 SQL |
| 目标引擎是 SQLite | 无 Duckula | 走 `Engine::SQLite` |
| Arrow IPC 且无 nanoarrow / 离线 | `read-arrow` 不可用（无 scan 形态） | `open-data` 的纯 Raku 退路（`Data.rakumod:408` 起） |
| 需要 REPL 表格里逐行看 1M 行 | 渲染必然物化 | `LIMIT` 后再看（参考 `Engine/DuckDB.rakumod:105` 的 `:max-rows` 下推） |

### 5.2 类型映射

复用 `Duck.rakumod:30` 的 `duck-type`：`int`→Int，`num`→Num，`str`→Str，`bool`→Bool，`datetime`→DateTime，`list/map`→ 结构。已知缺口（**新增入口要显式拒绝，不许静默降级**）：

| DuckDB 类型 | 现状 | 建议 |
|---|---|---|
| `BIGINT` / `DOUBLE` / `VARCHAR` / `BOOLEAN` / `TIMESTAMP` | 正常 | 保持 |
| `HUGEINT` / `DECIMAL(38,x)` | 可能溢出 Int | 入口层 `DESCRIBE` 后检测，超 64 位转 Str 并在 `Table` 上留类型标注 |
| `DATE` / `TIME` / `INTERVAL` | `datetime` 列整列尝试，失败整列退 Str（`Duck.rakumod:57-72` + `table-from-columns`） | 保持现状，但在文档里写明"混合列退 Str" |
| `LIST` / `MAP` / `STRUCT` | 转 JSON 文本存 Str（`Duck.rakumod:203-235` 的 `duck-ready` 反向） | 直读入口同样处置；若调用方要结构，建议 `.to-parquet` 而非封 Table |
| `UUID` / `BLOB` / `TIMESTAMPTZ` | 未覆盖 | `duck-type` 补 `str`/`blob`；`TIMESTAMPTZ` 避开 `ipc-buf`（已知坏字节） |

**一条必须写进文档的一句**：`dtypes` 每次 `DESCRIBE` 是 108ms，`Source.types` 做进程内缓存；**同一 `Source` 反复封表不要重复 `DESCRIBE`**。

### 5.3 错误处理

| 情况 | 处置 |
|---|---|
| 文件不存在 / 无权限 | 交给 `Sys.resolve` 抛（与 `open-data` 同源），不另造错误类型 |
| 路径越出 Sys 根 | 由 `Sys!assert-in-root` 抛 `X::Rakuish::Bound`（`Sys.rakumod:155` / `:231`），入口不捕获、不改写 |
| 结果封表触到 `Sys` 读上限 | 与本入口无关（不经过 `Sys.read`）；但同场景若有人误用 `open-data`，会先撞 `Sys/FS.rakumod:15` 的 1MB 上限 |
| 扩展名不支持 | `X::Rakuish::Unsupported`，消息里直说"请用 open-data" |
| 未授权访问 parquet/csv 方言 | `X::Rakuish::Unsupported`（`Result.rakumod:29`），与 `Data.rakumod:376-379`（`:allow-external` 方言拒绝）同措辞 |
| 结果超上限 | `X::Rakuish::Unsupported`，消息里给出**实测对比数字**（38.7s vs 0.3s），让用户理解为什么拒绝 |
| Duckula 未安装 | 模块加载用 `require`（照 `DSL.rakumod:124` 的 `require Rakuish::Data::Duck` 惯例），调用点抛"直读需要 Duckula；请用 open-data" |
| SQL 语法/类型错误 | 透传 DuckDB 原文（含列名与位置），不包装成"未知错误" |

### 5.4 与 `:allow-external` 授权模型的关系

- **语义完全继承**：`:allow-external` 的含义是"允许 DuckDB 触碰文件系统路径"，`open-data` 里它目前只对 parquet/csv 生效（`Data.rakumod:381`）；`open-lazy` 沿用同一开关，**不新增名字、不新增默认值**。
- **为什么 Arrow 不要求**（`Data.rakumod:399` 起的既有立场）：Arrow 永远有纯 Raku 退路，且路径已经 `Sys.resolve`；同理 `open-lazy` 对 Arrow 分支也不要求，但因为无 scan 形态**直接拒绝**，不会形成绕过。
- **沙箱是另一层，且不可逆**：`Duckula::Session.new(:sandbox)` 会 `SET enable_external_access=false`（`Session.rakumod:71-86`），**一旦开启，`scan-csv`/`read_csv_auto` 也读不了文件**。因此：直读入口的会话**不能**是 sandboxed 会话；若上层要沙箱（如 Agent 模式），正确顺序是「先建 Source 并完成读取 → 再在同一连接设沙箱」，或干脆让 Agent 走 `Engine::DuckDB`（`Engine/DuckDB.rakumod:31` 已经默认 `safe`）而不是 `open-lazy`。
- **两层闸门，别混为一谈**：`:allow-external` 是"允许 DuckDB 摸文件系统"，`Sys` 根校验是"允许摸哪些路径"（`Sys.rakumod:219-231`）。两者都过才读得到；只放开前者不等于放开后者。
- **Agent 白名单不暴露该开关**（`Hints.rakumod:21` / `Session.rakumod:1975` 的既有 op 列表），维持现状：Agent 只能读它被授予的路径。

---

## 6. 新增测试清单（建议 `t/81-lazy-scan.t`，共 12 项）

参照现有 `t/76-duck-sql.t`、`t/78-arrow-fast-path.t` 的写法（`t/` 现有 76 个文件，最大编号 `80-display-protocol.t`）：

| # | 用例 | 断言 |
|---|---|---|
| 1 | `scan-csv` 建计划 | 返回 `Source`；`names` 正确；**执行前后文件 mtime 不变**（未写临时文件） |
| 2 | 惰性验证 | 用坏 CSV/不存在列构造计划不报错，`.table` 时才报（证明计划惰性） |
| 3 | 聚合封表 | 1 万行 CSV → `GROUP BY` 结果 `Table` 的 `.elems`/`.types` 与 `open-data` 全量参照实现**逐值一致** |
| 4 | 上限门禁 | 结果超 `SCAN-MAX-ROWS` 抛 `X::Rakuish::Unsupported`，消息含"上限"与"to-parquet" |
| 5 | 上限下推 | 传入 `:max-rows(10)` 时 `limit(11)` 已进计划（用 `sql` 文本断言含 `LIMIT`，或对比 `elems`） |
| 6 | 授权 | 无 `:allow-external` 读 parquet 抛错；有则通过；`csv` + `%csv-options` 同规则 |
| 7 | 路径逃逸 | `../../etc/passwd` 被 `Sys.resolve` 拦（对照 `Data.rakumod:380` 的既有用例） |
| 8 | 落盘直写 | `.to-parquet` 产物可被 `open-data(:allow-external)` 读回，行数一致（证明一行没丢） |
| 9 | 类型映射 | 覆盖 `BIGINT/DOUBLE/VARCHAR/BOOLEAN/TIMESTAMP`，逐列比对 `Table.types`；`TIMESTAMPTZ` 归入 `str` |
| 10 | 无 Duckula 环境 | 用 `require` 失败模拟（或 `%*ENV` 开关），错误信息指向 `open-data` |
| 11 | Sys 根外路径 | 数据文件放在 Sys 根外 → 抛 `X::Rakuish::Bound`（证明第二道闸生效，`Sys.rakumod:155`） |
| 12 | `self` 占位符 | 用表名 `t` 写 SQL → `Guard` 报 `Catalog Error`（钉住 `LazyFrame.rakumod:1073` 的语义，防止上游改成别的约定） |

---

## 7. 要补的文档条款

1. **新增 `docs/ADR-0051-lazy-scan-entry.md`**（现 ADR 编号到 `ADR-0050-eval-prelude-slicing.md`）
   - 决策：直读走 Duckula `scan-*` + 单点物化；不建 Rakuish 版算子方言。
   - 备选与否决理由：DB::DuckDB 原生（样板多、无计划对象）、把 `Table` 改成 DuckDB 存储（上轮已否决）、`Frame` 全量桥（38.7s）。
   - 附本机实测表（本文第 0/2 节数据）。
2. **`docs/DESIGN-DATA-ENGINE.md` §5.1**（现有条款：小数据用 `Table`、大表交 DuckDB、Table 仍是交换格式，见 `DESIGN-DATA-ENGINE.md:139`）
   - 追加一条：**"直读入口（`open-lazy`）只在小结果时封 `Table`；结果超过 `SCAN-MAX-ROWS` 是设计错误，不是性能问题"**。
   - 把原文"后续可加 DataFrame 作为 lazy 层"（`DESIGN-DATA-ENGINE.md:143` 附近）改写为"lazy 层由 Duckula `LazyFrame` 承担，rakuish 只提供入口与封表"，避免后人再造 `DataFrame`。
3. **`docs/MANUAL.md`**：新增 `scan <path>` 短命令说明 + 与 `open-data` 的一句话区别（"留在磁盘上算" vs "取回内存"）+ `:allow-external` 的适用表。
4. **`META6.json`**：版本 `0.132.0` → `0.133.0`，新增 provides 项 `Rakuish::Data::Scan`（现有 provides 已列 `Data::Duck` / `Data::Table` 等）。
5. **`HANDOFF.md`**：写明"Arrow IPC 无 scan 形态"这一遗留，指向上游 Duckula 若要支持 `scan-arrow` 的诉求。
6. **反哺上游（可选）**：给 Duckula 提一条 `Frame.column-types`（复用 `DB::Result` 的 typed 列信息，省掉 `DESCRIBE` 的 108ms）——一旦落地，`Source.types` 可零成本。

---

## 8. 风险与明确"不做"的事

| 风险 | 缓解 |
|---|---|
| 用户把 `open-lazy` 当"更快的 `open-data`"用，拿回 1M 行 | 上限门禁 + 错误消息直接给数字对比（第 5.3 节） |
| Duckula 0.50 API 变动（`LazyFrame` 79 方法，历史上多次重命名） | 只依赖 6 个方法：`scan-csv`/`scan-parquet`/`sql`/`limit`/`collect`/`to-parquet`；`t/81` 覆盖 |
| 会话泄漏（Duckula 连接 + 视图） | `Source` 由 `Rakuish::REPL::Session` 持有，`close` 时统一 `release` |
| 双入口导致用户困惑 | MANUAL 用一张两行表说清；DSL 提示里互相指向 |

**不做**：

- ❌ 不把 `Table` 改成 DuckDB 存储（上轮结论，`DESIGN-DATA-ENGINE.md:139` 支持）。
- ❌ 不在 rakuish 里实现 `filter/groupby/join` 的 Raku 表达式翻译层。
- ❌ 不试图绕过"Table → DuckDB 必须装箱"的限制（无 API，见 §2.6）。
- ❌ 不给 Agent 模式开放 `:allow-external`。
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
