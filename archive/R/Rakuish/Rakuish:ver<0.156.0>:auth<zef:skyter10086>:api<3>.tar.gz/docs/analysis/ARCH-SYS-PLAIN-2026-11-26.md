---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_510809c2e94811f1b0c5525400cd780f
    ReservedCode1: UiG+6SvUgYel5MlPlhJqF/EIzGO1pKDSzKj5mIFk3N5DK4Y/Sbpv/AwdeXp4g4leyNYuajaF4v0f0RutTRQ66o5MsEV+SqhbFHLfsc9fbvs4xyrZrNSynqSjJuRmY8K8UB4yAe5y0tc8eyaagWoljZAipxm+Hv24S8vnLIpF3E6NIlNniomdg9KsB+Q=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_510809c2e94811f1b0c5525400cd780f
    ReservedCode2: UiG+6SvUgYel5MlPlhJqF/EIzGO1pKDSzKj5mIFk3N5DK4Y/Sbpv/AwdeXp4g4leyNYuajaF4v0f0RutTRQ66o5MsEV+SqhbFHLfsc9fbvs4xyrZrNSynqSjJuRmY8K8UB4yAe5y0tc8eyaagWoljZAipxm+Hv24S8vnLIpF3E6NIlNniomdg9KsB+Q=
---



# Rakuish 长什么样，Sys 到底在干嘛

> 配套两张图：`ARCH-DIAGRAM-LAYERS-L0-L6-2026-11-26.png`、`ARCH-DIAGRAM-SYS-BOUNDARY-2026-11-26.png`
> 所有结论都对着仓库实测（模块行数、`file:line`），不是凭印象画的。

---

## 先看图（点开放大）

**图 1：分层架构 L0–L6**

![Rakuish 分层架构图](ARCH-DIAGRAM-LAYERS-L0-L6-2026-11-26.png)

**图 2：Sys 边界图**

![Rakuish Sys 边界图](ARCH-DIAGRAM-SYS-BOUNDARY-2026-11-26.png)

---

## 0. 三句话结论

1. **Rakuish 分 7 层（L0–L6），但主线只有一条**：一行输入 → 判类 → 变成命令 → 落到 Sys → 变成结果 → 回到你眼前。
2. **`Rakuish::Sys` 是这门语言里唯一能碰文件和进程的对象**。别的地方想读写文件、想跑命令，都得跟它打招呼。
3. 所以它同时干了三件"警察活"：**查路条**（路径不许跑出项目根目录）、**限数量**（一次别读太多）、**统一口径**（错就报错，别各写一套）。

---

## 1. 第一张图怎么读：7 层，一条线

图上是从上往下走的。颜色和编号只是"这属于哪一类事"，不代表调用顺序——`L5`/`L6` 是输入进来的两扇门，`L4` 是结果回去的路。

| 层 | 这一层实际在干什么 | 你在 REPL 里的感受 |
|---|---|---|
| **L0 入口** | `bin/rakuish` → `Rakuish::CLI`(535 行) → `Kernel`(244 行) 组装会话 | 敲 `rakuish` 就进去了，没有第二个入口 |
| **L1 输入分类** | `Session.eval-line`(2833 行) 是**唯一**判类的地方：这行是没写完？是内建动作？是短命令？还是裸 Raku？ | `1 +` 回车会等你写完，而不是骂你语法错误 |
| **L2 命令观感** | `DSL`(313)、`Command`(163)、`open-data`/`sql`/`scan` 这些命令 | `ls`、`cd`、`run` 用起来像命令，但返回值是真值，能赋值、能 `.grep` |
| **L3 系统操作** | `Sys`(354) 派发 → `Sys::FS`(733) 文件 / `Sys::Proc`(732) 进程 | 这张图里最粗的那根箭头，全系统只有这一条通到操作系统 |
| **L4 结果展示** | `Display`(324)、`Result`(149)、`Renderer`(219)、`Data::Table`(418) | 表格自动分页、超 200 行给提示，而不是刷屏 |
| **L5 输入行 UI** | `Keymap`(518)、`Highlight`(312)、`Chrome`、`Complete`、`Hints`、`SqlComplete` | 高亮、补全、Ctrl-R 那些手感，都在这层 |
| **L6 前端协议** | `Eval`(451)+`Eval::Server`(300)：一行一个 JSON；`Notebook`(329) 给 Jupyter | 用编辑器/Jupyter 连它时，走的就是这扇门 |
| **Data（横切）** | `Data`(434)+`Engine::DuckDB`/`SQLite`/`Duck`+`Arrow`(1260)+`Stream`(760)… | 读 csv/parquet/arrow、`sql` 查询，都是这层干的 |

**两个容易搞混的点：**

- **Data 不是一层，是横切**：它横跨 L2 和 L3。命令层调它取数，它自己又要找 Sys 验路径。所以图上画成一条横带，不从属某一层。
- **L5 和 L6 是两扇并列的门**：终端一扇、协议一扇。两扇门都**不认识 Raku 语义**——`L6` 那边刻意的（`Eval.rakumod` 头注释写了：不解析 `!`、不判续行、不碰 `Out[n]`），语义全在 L1 之后。这样换前端不用重写求值逻辑。

---

## 2. 第二张图怎么读：Sys 是"门卫 + 限流器 + 统一口径"

图横着分三块：

### 左：谁在敲 Sys 的门（全库 grep 实测）

| 调用方 | 调用点 |
|---|---|
| `REPL::Shell`(1334 行) | 49 处 |
| `REPL::Session`(2833 行) | 17 处 |
| `Data`(434 行) | 6 处 |
| `Data::Stream`(760 行) | 4 处 |
| `Command` / `DSL` / `Chrome` / `Plugins` | 各 2 处 |

`DSL` 和 `Command` 是**纯委派**：它们只负责"这个命令长什么样、参数是什么"，自己不拼路径、不起进程（`DSL.rakumod` 头注释原话：全部委托给会话级 Sys，不直接碰文件/进程，root 校验与审计不会漏）。

### 中：Sys 自己有什么

- **会话级属性**：`cwd` / `env` / `root` 是对象上的字段。**它不 `chdir`、不改 `%*ENV`**（`ADR-0001:50`）。所以 Rakuish 里 `cd` 只改"这个会话认为的当前目录"，你外面那个终端一点没动。
- **`resolve()`**（`Sys.rakumod:219`）：把路径归一化（处理 `..`、处理符号链接），再跟 root 比对，越界就抛 `X::Rakuish::Bound`。
- **`try-op()`**（`Sys.rakumod:262`）：把异常转成 `Result`。ADR 的错误模型是：读/写/列目录/stat **抛异常**，`rm`/`cp`/`mv` 返回 `Result`（`ADR-0001:49`）。
- **上限注入点**（`Sys.rakumod:80-81`）：建对象时把两个数钉进 `Sys::FS`——
  - `max-bytes = 1 MiB`（`FS.rakumod:15`）
  - `max-entries = 100 000`（`FS.rakumod:16`）
- **两个子模块**：`Sys::FS` 管文件（read/read-lines/write/append/ls/stat/glob/mkdir/rm/cp/mv），`Sys::Proc` 管进程（exec/spawn/wait/cancel/前后台/pty）。加一票小弟：`Console`、`Term`、`JobTable`、`PosixSpawn`、`WinJob`。

### 右：Sys 被允许碰到什么

① 文件系统（只在 root 沙箱内）　② 子进程（只接 `exe + argv`）　③ 终端与环境（tty 模式、会话内环境变量）

**"只接 exe + argv" 是关键**：`Sys.exec(Str $exe, *@args)`（`Sys.rakumod:309`）——第一个参数是可执行文件名，后面是参数数组。**没有 shell 字符串，也就没有 shell 解释器参与**。`FS.rakumod:9` 的注释写得更硬：不接受任何 shell 字符串、不解析 flag、不 spawn 进程。

带来两个后果（都是好事）：

- 你在命令里写 `*` 不会突然被 shell 展开成文件列表；管道也得显式写，不会被偷偷塞给 shell。
- 没有"字符串拼命令"这一层，就没有引号逃逸、没有 `; rm -rf` 注入。

---

## 3. Sys 管什么，不管什么

### 管（写在这层，别的地方不许重复实现）

| 类别 | 具体内容 | 位置 |
|---|---|---|
| 路径安全 | 归一化 + root 边界校验 + 符号链接跟出 root 就拒 | `Sys.rakumod:129/155/175/219` |
| 文件操作 | read/read-lines/write/append/ls/ls-table/stat/cp/mv/mkdir/glob/rm/with-lock/tail-follow | `Sys.rakumod:276-296,447` |
| 进程操作 | exec/tty-exec/bg-exec/fg/bg/bg-jobs/pty-exec/spawn/wait/cancel/jobs | `Sys.rakumod:309-442` |
| 会话环境 | cwd、env 读写、cd | `Sys.rakumod:237-259` |
| 资源上限 | read/write/backup/cp 单文件受 `max-bytes`；ls 递归/rm/cp -r 受 `max-entries` | `FS.rakumod:15-16,84,283,305,592` |
| 错误口径 | 统一异常类型 + `try-op` 转 `Result` | `Sys.rakumod:262`、`Result.rakumod` |

### 不管（这些是别人的活，硬塞给它反而乱）

| 不管什么 | 归谁 |
|---|---|
| 语法怎么解析、是不是没写完 | `Incomplete` + `Session.eval-line`（L1） |
| 输出长什么样、要不要分页 | `Display` / `Result::Renderer`（L4） |
| 用 DuckDB 还是 SQLite 读数据 | `Data::Engine`（横切层） |
| `Out[n]`、`my` 变量、历史记录 | `Session`（L1/L2） |
| 补全、高亮、键位 | L5 那堆 `REPL::*` |
| 审计账本本身 | `Rakuish::Audit`，由 `Kernel` 在每次执行后写（`Kernel.rakumod:135-146,303`） |

**一句诚实的话**：`ADR-0001:125` 当年写的护栏是"root / allowlist / 审计"三件套，但**今天仓库里的 Sys 实际只有 root 校验 + 上限 + 统一错误**，`Sandbox` 模块在 0.81.0 就随 Agent 线删掉了（`Audit.rakumod:6`、`Result.rakumod:24` 有明确记录）。所以别把"allowlist"当成现在的功能。

---

## 4. 为什么所有文件/进程操作必须过它

### 理由一：路径不归一化，`..` 和符号链接就是现成的后门

`resolve()` 干的事：先词法归一化，再逐级 `canonical`（跟符号链接），最后 `!assert-in-root` 比对。Windows 上还专门补了一刀——`!assert-links-in-root`（`Sys.rakumod:175`），因为 Rakudo 在 Windows 上 `IO::Path.resolve` **不跟随文件类型的符号链接**，但操作系统 `open` 会跟。所以不补这一刀，就能拿一个指向 root 外的符号链接把整个沙箱绕过去。这段逻辑写在 Sys 里，所有调用方自动受益；写在别处，就会有第二个、第三个版本，迟早有一个忘了补。

### 理由二：没有上限，一个 2G 的日志就能把 REPL 干死

`read` 会把整个文件读进内存（slurp）。1 MiB 这个数不是随便定的：它是 `ADR-0001:155` 和 `SPEC V-271` 的口径——**宁可在门口明确拒绝，也不静默截断**。静默截断更坏：你拿到半份数据，还以为是真的。

而且报错不是甩一句"超限"就完事，`FS.rakumod` 给了三条出路（见下一节真实文案）。

### 理由三：口径统一，用户和上层代码只需要懂一套规则

`rm`/`cp`/`mv` 一律返回 `Result`，读/写/stat 一律抛异常，Agent 边界用 `try-op` 统一转。这条线一松，每个模块就会自创一套"失败返回 nil / 返回 false / 返回空字符串"，最后没人知道失败长什么样。

---

## 5. 绕过 Sys 会发生什么

图 2 下方那条红色虚线路，就是"绕过"：

```
模块自己 slurp / spurt / Proc::Async  ──✕──>  操作系统
```

具体代价四条：

1. **路径校验没了**：`../..` 和符号链接都能直接读到你项目外的东西，`root` 形同虚设。
2. **上限没了**：`slurp` 一个大文件就是一次内存赌博，REPL 会被 OOM 带走（连带丢掉整个会话状态）。
3. **审计断了**：`Kernel` 那本"每次操作一条"的账本会出现空洞（`Kernel.rakumod:303` 是唯一写入点）。
4. **错误形态分裂**：同一个"文件不存在"，这里抛异常、那里返回 `False`，上层没法统一处理。

这就是为什么 `ADR-0001:124-126` 把话说成硬边界：`repl` 对象和快捷键**只许操作 REPL 自身状态，不允许直接读文件或启动进程**。

---

## 6. 在 REPL 里，你怎么感知到 Sys 的存在

Sys 平时是透明的，你能感到它，基本都在它"拦人"的时候。

### ① `open-data` 读大 CSV 被拦（你问的就是这个）

完整链路：

```
open-data("big.csv")
  └─ Data.rakumod:370  签名第一参数就是 Sys（open-data(Rakuish::Sys $sys, …)）
      └─ Data.rakumod:459  my Str $text = $sys.read($path)
          └─ Sys.rakumod:276  → $!fs.read(...)
              └─ FS.rakumod:84  比对 $f.s 与 max-bytes
                  └─ 超过 → 抛 X::Rakuish::Limit
```

真实报错长这样（`FS.rakumod` 里的原文模板）：

```
读取超限: 3355443 > 1048576 字节 (/home/you/big.csv)；
大文件请用 read-lines(:head/:tail) 或 head -n / tail -n，
或 stream('路径') 惰性记录流；
确实要整份读就 read(..., :max-bytes(N)) 显式抬高上限
```

1 MiB ≈ 100 万字节。按一行 100 字节算，**大约一万行的 CSV 就会撞线**。这不是 bug，是设计：整份读进来是要吃内存的。

出路三条，原文都给了：

- `open-data` 时**显式授权** `:allow-external` → 走 DuckDB 外部读（`Data.rakumod:382-388`），路径**仍然**先过 `$sys.resolve`（`:383`），而且这个开关**不在 Agent 白名单里**（`:381` 注释写明）。
- 换成按行读：`read-lines` / `head -n` / `tail -n`。
- 真要整份读：`read(..., :max-bytes(N))` 自己把上限抬高，内存自己担。

> 顺带一个**已知缺口**（来自之前那份核查报告）：`Data.rakumod:386-387` 调 `read-csv`/`read-parquet` 时**没传 `:max-rows`**，也就是说走 DuckDB 这条路时行数上限没下推。行数上限目前只在 `Display(max-rows 200)`、`Engine(LIMIT 下推)`、`Scan(SCAN-MAX-ROWS 50000)` 三处存在。

### ② `read` 大文件被拦，但 `head`/`tail`/`stream` 能读

`read-lines` 是**刻意豁免** `max-bytes` 的（`FS.rakumod:145-151`）：它按行流式读，只读你要的那几行。所以同一个文件，"整份读"不行、"看前 20 行"可以——这个差别就是 Sys 在按"内存风险"而不是按"文件大小"做判断。

### ③ `ls` 一个巨型目录被拦

`max-entries = 100 000`（`FS.rakumod:16`）管三处：`ls` 递归（`:427`）、`rm`（`:528`）、`cp -r` 预检（`:561`）。`rm` 和 `cp -r` 是**先预检再动手**——不会删了一半才报错。

### ④ 想读项目外的路径，直接被拒

```
路径越出 root: /etc/passwd (root=/home/you/rakuish)
```

类型是 `X::Rakuish::Bound`（`Sys.rakumod:155`）。注意它对比的是**归一化之后**的路径，所以写 `../..` 没用。

### ⑤ `cd` 之后相对路径跟着走，但外面的终端没动

`cd` 只改 Sys 对象上的 `cwd`（`Sys.rakumod:237`）。宿主进程没有 `chdir`（`ADR-0001:50`）。所以你退出 Rakuish，shell 的 `pwd` 还是原来的位置。

### ⑥ 参数里的 `*` 不会自己展开

因为进程层只接 `exe + argv`，没有 shell 参与。这一点在写脚本时最明显：想要通配符就自己 `glob`，想要管道就显式串。

---

## 7. 几个常见误解

**Q：Sys 是不是就是把 Raku 的 `IO::Path` 包了一层？**
不完全是。`IO::Path` 只解决"怎么表示一个路径"，Sys 解决"这个路径**准不准**用、用起来**有没有上限**、失败**长什么样**"。它是策略层，不是 API 层。

**Q：既然 Sys 这么严格，为什么不让大家直接调 `IO::Path`、跑得更快？**
因为那些"严格"是**唯一一份**。放开之后，每个模块要各自实现 root 校验、各自定上限、各自处理符号链接——Windows 那个符号链接的坑（`Sys.rakumod:171-175`）就得每个调用方自己踩一遍。

**Q：上限不能干脆去掉吗？**
能按次调高（`:max-bytes(N)`），不能全局默认去掉。默认值是给"手滑读到 2G 日志"这种情况兜底的。

**Q：Data 层不是也自己读文件吗？算绕过吗？**
不算。它读之前先 `$sys.resolve`（`Data.rakumod:383/403/459/484/505`、`Stream.rakumod:784`），路径校验这一步没跳过；跳过的只是"用哪个引擎读"这个实现选择。

---

## 8. 证据索引

| 结论 | 出处 |
|---|---|
| 所有文件/进程操作必须经 Sys（硬边界） | `docs/ADR-0001-raku-native.md:124-126` |
| 系统操作收敛到会话级 Sys，路径用 IO::Path | `docs/ADR-0001-raku-native.md:35` |
| Sys 会话级，不 chdir、不改 `%*ENV` | `docs/ADR-0001-raku-native.md:50` |
| 错误模型：读抛异常、rm/cp/mv 返回 Result | `docs/ADR-0001-raku-native.md:49` |
| 上限常量 1 MiB / 100 000 | `lib/Rakuish/Sys/FS.rakumod:15-16` |
| 上限注入点 | `lib/Rakuish/Sys.rakumod:80-81` |
| read 超限抛 `X::Rakuish::Limit` + 三条出路 | `lib/Rakuish/Sys/FS.rakumod:84-99` |
| read-lines 豁免 max-bytes | `lib/Rakuish/Sys/FS.rakumod:145-151` |
| resolve / 越界 / 符号链接补刀 | `lib/Rakuish/Sys.rakumod:219 / 155 / 175` |
| exec 只收 exe + argv | `lib/Rakuish/Sys.rakumod:309`；`FS.rakumod:9` |
| FS 不收 shell 字符串、不解析 flag | `lib/Rakuish/Sys/FS.rakumod:9` |
| open-data 第一参数即 Sys | `lib/Rakuish/Data.rakumod:370` |
| 默认读走 `$sys.read` | `lib/Rakuish/Data.rakumod:459` |
| `:allow-external` 才走 DuckDB，路径仍 resolve | `lib/Rakuish/Data.rakumod:381-388` |
| DuckDB 路径未传 `:max-rows`（缺口） | `lib/Rakuish/Data.rakumod:386-387` |
| Sandbox 已随 Agent 线删除 | `lib/Rakuish/Audit.rakumod:6`；`lib/Rakuish/Result.rakumod:24` |
| 审计唯一写入点 | `lib/Rakuish/Kernel.rakumod:135-146, 303` |

---

## 9. 图本身

- 横版 200 DPI，手机横屏或双指放大都清楚；字体用系统自带中文字体，不会出方块。
- 每张图里的数字都是 `lib/` 下 `.rakumod` 的**实际行数**，不是估的。
- 想改图：绘图脚本在本次会话的中间产物目录，改完重跑即可。
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
