---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4bd26cd3e94811f1b13a525400de85a5
    ReservedCode1: NYp0RpsBSIrb3bZV3+IPx1xRD5S3BxqTqUWgyUfKC6bWXFEY5DPZVeLI7oMbUxgeXBQx4A0dbquLA2D6+HRJbR17HF9BREBo7Svb2wghLwHtxLCIv/qdwAqDWI4pbJ03G6PwrrOSvcbDCY06oxfbABuYeP47KtwhAw+c2xPFWGJ0Tb4pGRciFXSs680=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4bd26cd3e94811f1b13a525400de85a5
    ReservedCode2: NYp0RpsBSIrb3bZV3+IPx1xRD5S3BxqTqUWgyUfKC6bWXFEY5DPZVeLI7oMbUxgeXBQx4A0dbquLA2D6+HRJbR17HF9BREBo7Svb2wghLwHtxLCIv/qdwAqDWI4pbJ03G6PwrrOSvcbDCY06oxfbABuYeP47KtwhAw+c2xPFWGJ0Tb4pGRciFXSs680=
---



# Rakuish 0.130.0 未清项核对报告

- 核对日期：2026-11-25
- 工作树：`C:\Users\Administrator\rakuish`，`META6.version = 0.130.0` / API v3
- 基线文档：`docs/REVIEW-VS-IPYTHON-2026-11-24.md`（0.122.3）、`docs/AUDIT-2026-11-17.md`（0.98.1）、`docs/AUDIT-2026-11-18.md`（0.101.0）
- 方法：逐条对照文档条目与当前源码，证据均为 `file:line`；未做运行时实测的条目在备注中标注"静态判定"

## 0. 总览

| 来源 | 条目数 | 已修 | 部分实施 | 未修 |
|---|---:|---:|---:|---:|
| REVIEW §7 P0 | 7 | 7 | 0 | 0 |
| REVIEW §7 P1 | 7 | 0 | 4 | 3 |
| REVIEW §7 P2 | 7 | 0 | 1 | 6 |
| REVIEW §7 P3 | 8 | 0 | 3 | 5 |
| REVIEW §4.9 a–l | 12 | 9 | 0 | 3 |
| AUDIT-2026-11-17 | 4 | 4 | 0 | 0 |
| AUDIT-2026-11-18 | 4 | 4 | 0 | 0 |
| **合计** | **49** | **24** | **8** | **17** |

结论：P0 全部清空、§4.9 只剩 e/k/l、两份 AUDIT 全部闭环；**剩余 17 条未修 + 8 条半成品全部集中在 P1/P2/P3**，即"结构能力、调试子系统、内核协议、工程交付"四块。

## 1. P0（7/7 已修）

| # | 事项 | 状态 | 证据 |
|---|---|---|---|
| 0.1 | 前奏顺序锁死会话 | 已修 | `REPL/Session.rakumod:1189-1203`（V-319/0.123.0，别名整体前置并注明原因） |
| 0.2 | 不可 JSON 值杀引擎 | 已修 | `Display.rakumod:130-146`（`json-text` 对不可序列化值返回 Nil，不再塞原值）；`Eval/Server.rakumod:38-50`（`try to-json` + 降级 error 帧） |
| 0.3 | 打印过的 cell 丢值 | 已修 | `Display.rakumod:243-258`（V-323，`out` 与 `value` 并存时优先 value 作为 execute_result） |
| 0.4 | 内省污染 `_`/`Out[n]` | 已修 | `Session.rakumod:2894-2898`（`名字?` 直接构造 Result，不经 eval-line-body 与 `!remember`） |
| 0.5 | 声明格产生 `Out[n]` | 已修 | `Session.rakumod:1281-1288`（`%decl<key>` 存在时不推进 `$!index`、不 `!remember`） |
| 0.6 | README `%h` 示例 / install.sh agent | 已修 | `README.md:116`（`my %h = a => 7`）；`tools/install.sh:9`（仅 `chmod +x bin/rakuish`，无 `rakuish-agent`/`--agent`） |
| 0.7 | `In` 未绑定但补全存在 | 已修 | `Session.rakumod:1254-1256`（`my @in-history` + `my \In = @in-history` 注入 EVAL） |

## 2. P1（0 已修 / 4 部分 / 3 未修）

| # | 事项 | 状态 | 证据 | 缺口 |
|---|---|---|---|---|
| 1.1 | 显示协议（值声明自己 MIME） | 部分 | `Display.rakumod:200-215`（鸭子类型 `to-mime`）、`:29-40`（extra-mime 透传）；`DSL.rakumod:284-320`（`HTML`/`Markdown` + `display()`） | 缺 `SVG`/`PNG`/`Latex` 薄包装与内置 FORMATS 扩展；无"TTY 也走 to-mime"的统一入口测试 |
| 1.2 | 输出预算 | 部分 | `Display.rakumod:421-425`（`budgeted-text`，4000 字符）、`:295-310`（Seq 展开上限 200 元素） | 预算写死，无 `max-display-chars`/`max-seq-elems` 配置项；元素上限 200 ≠ 文档建议 1000；TTY/notebook 是否共用未断言 |
| 1.3 | 补全变量/sub/模块名 | 部分 | `Session.rakumod:2691-2705`（内置关键字 + `@core-mods` 模块名候选） | 无 sigil 分支（`$al`/`@ar` 仍空）、无 `%STATE` 键、无用户 `sub` 名（`hel` 不出现 `helper`）、无 `@!decls` |
| 1.4 | `paste` 块输入 | 未修 | 全库 grep `paste` = 0 命中 | 无任何段落粘贴入口（多行 `class` 仍需手工续行） |
| 1.5 | CSV 类型推断 | 未修 | `Data.rakumod:193-196`（显式 `%types` 全列 `str`，注释仍写"结果本来也只会是 str"） | `sum`/`mean` 对 CSV 列仍走 `Stream` 另一套数字逻辑；`Table.!numeric` 空集仍可能返回 `Int 0` |
| 1.6 | Table `head`/`tail` | 部分 | `Table.rakumod:174-183`（`head`/`tail` 已存在）；`:380`（`to-text(:max-rows)`） | 缺 index/dtype/shape 可选行；`to-text` 仅支持 `:max-rows` |
| 1.7 | `help` 与 `help()` 两套表 | 未修 | `DSL.rakumod:44-48`（`commands()` → 模块级 `default-registry()`）；`Session.rakumod:205`（会话自己的 `$!commands`）；无 `bind-registry` 绑定点 | 插件注册进的是会话 registry，`help()` 看不到；命令数仍不一致 |

## 3. P2（0 已修 / 1 部分 / 6 未修）

| # | 事项 | 状态 | 证据 | 缺口 |
|---|---|---|---|---|
| 2.1 | post-mortem `debug`/`tb` | 未修 | `lib/**` grep `when 'debug'`/`when 'tb'` = 0 | 无异常对象保留、无回溯打印 |
| 2.2 | 错误分级 `errors short|full` | 未修 | grep `errors short|full` = 0 | 无编译/运行/被拒分级开关 |
| 2.3 | 死属性 `repl.trace`/`repl.bt` | 未修 | `Session.rakumod:101`（`$.trace`）、`:123`（`$.bt`）；`CLI.rakumod:150`（`--trace` 仍在 help 中宣传）；全文无读取点 | 属性/开关仍在，消费者缺失——"宣称 ≠ 实际" |
| 2.4 | notebook 消息集 | 部分 | `Kernel/Notebook.rakumod:54-64`（仅 6 op）；`:124-129`（`cursor_start => 0, cursor_end => $pos`，注释明写"整行替换"） | 无 `history_request`/`interrupt_request`/`input_request`/`execute_input`/`display_data`；`interrupt_mode:message` 与实现不一致；补全仍整行替换 |
| 2.5 | notebook 结构化 error | 未修 | `Kernel/Notebook.rakumod:100-115`（execute 回复仅 `ok/code/err/out/display/value`） | 无 `ename/evalue/traceback`，Jupyter 无法渲染红色回溯 |
| 2.6 | `store` 跨会话变量 | 未修 | grep `when 'store'` = 0 | 无 `store -r/-d/-l`、无启动加载 |
| 2.7 | `recall n` | 未修 | grep `when 'recall'` = 0 | 历史无法回填输入行/临时文件 |

## 4. P3（0 已修 / 3 部分 / 5 未修）

| # | 事项 | 状态 | 证据 | 缺口 |
|---|---|---|---|---|
| 3.1 | 云端 CI | 未修 | `tools/ci.sh` 存在；仓库无 `.github/workflows`；无近期 `tmp/ci-report` | 报告数字仍不可复核（本地跑 ≠ CI 门槛） |
| 3.2 | 文档版本守卫 | 部分 | README `0.130.0`、`HANDOFF.md:3` `0.130.0`、`docs/MANUAL.md:3` `0.130.0`、`docs/ADR-INDEX.md:1,7` `0.130.0 / 49 份`（版本已同步）；`t/51-meta-provides.t` 仅守模块 provides 数 | 无"文档版本 = META6.version"断言，下次升版仍会漂移 |
| 3.3 | `Arrow::IPC` 可选依赖 | 未修 | `META6.json:19` `depends` 仍硬列 `Arrow::IPC`；`README.md:63-65` 已说明"没装时降级" | 声明与实现相反，README 依赖数与 META6 不一致风险仍在 |
| 3.4 | CHANGELOG | 未修 | 根目录无 `CHANGELOG*` | `AUDIT-FIXES-*` 未归并，用户无法跟踪 |
| 3.5 | 英文 README / 文档站 | 未修 | 仅中文 `README.md` + `docs/MANUAL.md` | 采用率天花板未破 |
| 3.6 | 扩展面（自动发现/补全器/渲染器/hook） | 部分 | `Session.rakumod:2582`（`plugin load` 写入 `$!commands`，文本命令可命中 `:3223 $!commands.has($w)`）；`Plugins.rakumod:14`（注释明写"不自动扫描"） | 无 `~/.rakuish/plugins/*.raku` 自动发现、无生命周期、无注册补全器/渲染器/hook API |
| 3.7 | IPython→Rakuish 对照表 | 未修 | `docs/MANUAL.md` 仅 1 处 IPython 提及 | 迁移成本仍高 |
| 3.8 | `tmp/` 清理 + `t/15` 硬编码 | 部分 | `tmp/` 由 141 MB/4786 文件降至 37 文件/0 MB；`t/15-repl-ui.t` 已无 `Administrator` 硬编码 | `tmp/` 仍有 `arrow-*`、`r41-*`、`off-trace-*.log`、`snap-mark-*` 残留 |

## 5. REVIEW §4.9 a–l（9 已修 / 3 未修）

| # | 现象 | 状态 | 证据 |
|---|---|---|---|
| a | README `%h` 示例跑不通 | 已修 | `README.md:116`（`my %h = a => 7;`） |
| b | 类型对象渲染为空 | 已修 | `Display.rakumod:379-387`（⑨-0「类型对象」分支输出 `Int +{...}`） |
| c | `Seq` 形式 `IO::Path` 退化为 `.raku` | 已修 | `Display.rakumod:295-310`（Iterable 切片）+ `:330-360`（⑤ 路径分支按 basename 成表） |
| d | 无输出预算 | 已修 | `Display.rakumod:421-425`（`MAX-DISPLAY-CHARS = 4000` + 截断注记） |
| e | `doc pick` 找不到内置例程 | **未修** | `REPL/Introspect.rakumod:11-14`（只查 `@decls`/类型，注释明说"要看命令用法请用 doc <命令名>"）；`:52` |
| f | `timed` 不显示耗时 | 已修 | `Display.rakumod:266-270`（`elapsed-line` 渲染 `<1ms`/`12.3ms`/`1.20s`） |
| g | Table 无 `head`/`tail` | 已修 | `Table.rakumod:174-183` |
| h | 未知容器用 `.raku` | 已修 | `Display.rakumod:390-396`（`.gist` 兜底，超预算走 `budgeted-text`） |
| i | `Result.render('html')` 抛异常 | 已修 | `Renderer.rakumod:263,270-272`（`markdown-value` + 最小 `<table>` 输出，0.128.0） |
| j | Windows `! echo hi` 不可用 | 已修 | `SPEC.md:2912-2914`（V-332/0.130.0，ADR-0049，cmd 内建走 `cmd /c`） |
| k | `color off` 连建议/错误一起关 | **未修** | `CLI.rakumod:534`（单一 `conf('color')` 传入 Session）、`Chrome.rakumod:100,207`（`color-mode` → 单一 `$use-color`，无 hints/error 独立开关） |
| l | 长会话性能（40 声明后 ~109 ms/格） | **未修** | 无前奏缓存（`@!prelude` 相关 grep = 0）；`Session.rakumod:1189-1206` 每格全量重放声明 |

## 6. AUDIT-2026-11-17 / 11-18（全部闭环）

| 来源 | 条目 | 状态 | 证据 |
|---|---|---|---|
| 11-17 P0 | Linux `t/30` clean-exit | 已闭环 | docs 头部处置块（0.98.2，ADR-0032 linger guard）；`CLI.rakumod:33,47,715` |
| 11-17 P1 | 非 TTY 安装链 `Terminal::API` | 已文档化 | `README.md:67`、`docs/CI.md`；**依赖仍硬声明，与 P3.3 同一根因** |
| 11-17 P1 | 文档版本/测试数过期 | 已修 | 四份文档均 `0.130.0`（见 P3.2 证据） |
| 11-17 P2 | README 测试入口 / 历史横幅 | 已修 | 文档头部处置块 |
| 11-18 | junction 崩溃、SPEC 版本、`%STORE`、测试竞态 | 已修 | docs 头部处置块（0.101.1/0.101.2） |

## 7. 仍未处理清单（按建议优先级）

| 优先级 | 条目 | 一句话建议 |
|---|---|---|
| 高 | 1.5 CSV 类型推断 | `from-csv-data` 复用 `Table.!infer-type` 逐列推断；`sum` 空集返回 `0e0`。数据工作台门面功能 |
| 高 | 1.3 补全 | 加 sigil 分支读 `%!state` 键 + `@!decls` 名字；成本最低收益最大 |
| 高 | 1.7 help 双表 | 让 `Session` 构造时把 `$!commands` 注入 DSL（新增 `bind-registry`），单一来源派生两组视图 |
| 高 | 2.3 死属性 | 保留则接线进 traceback 渲染，否则从 `CLI.rakumod:150` 与 SPEC 删除 |
| 高 | 2.5 notebook 结构化 error | 在 execute 回复加 `ename/evalue/traceback`，Jupyter 侧立即可用 |
| 中 | 1.4 `paste` | 读 stdin 到 `--`/EOF，累积后单次 `eval-line`，不改行编辑循环（避开 ADR-0036） |
| 中 | 2.4 notebook 消息 | 先补 `history_request`/`interrupt_request`/`input_request`（便宜）；`prompt` 缺 `input_request` 会挂内核 |
| 中 | 2.1/2.2 调试 | `CATCH` 保留异常 + `debug` 打印族/message/backtrace；`errors short|full` 分级 |
| 中 | 1.2 预算可配 | 提取 `max-display-chars`/`max-seq-elems` 到 config，默认 4000/1000，TTY 与 notebook 共用 |
| 中 | 4.9e `doc pick` | `Introspect` 增一条"核心例程"查询（`Rakudo::Internals`/`$*REPO` 符号表或内置名清单） |
| 中 | 4.9k color 分档 | `color` 拆成 `color.output` / `color.hints` / `color.error`（或 `--no-hints`） |
| 低 | 2.6/2.7 `store`/`recall` | `store` 复用 `Snapshot` 可序列化判定；`recall` 可退化为 `edit n` |
| 低 | 3.1 云端 CI | 直接接 `tools/ci.sh`，把 `t/` 全绿作为 PR 门槛 |
| 低 | 3.2 版本守卫 | `t/51` 增断言：README/HANDOFF/MANUAL/ADR-INDEX 版本串 = `META6.version` |
| 低 | 3.3 Arrow 可选 | `META6.json` 移到 `depends` 之外（`recommends` 或文档声明），与 README 对齐 |
| 低 | 3.4/3.5/3.7 交付形态 | CHANGELOG、英文 README、MANUAL 对照表（三件可一次性提交） |
| 低 | 3.6 扩展面 | `~/.rakuish/plugins/*.raku` 目录扫描 + 生命周期 + 补全器/渲染器注册点 |
| 低 | 3.8 残渣 | 清 `tmp/` 剩余 37 个 `arrow-*`/`r41-*`/`off-trace-*`/`snap-mark-*` |
| 低 | 4.9l 长会话性能 | 前奏重放做"增量 + 缓存"：声明未变时复用同一 `preamble` 编译单元 |
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
