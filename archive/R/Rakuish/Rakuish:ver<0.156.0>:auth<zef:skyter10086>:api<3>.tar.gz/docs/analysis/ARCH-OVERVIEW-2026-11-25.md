---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4ab0902ee94811f1b0c5525400cd780f
    ReservedCode1: DkrQ0HUYZNPKN6gT4cQlKyYHbx6uTAJWqgbNpcILCNpWC38UHmnN+5kAwokIRZXXPfO9ZijEcEWu+TOab0qGQ8Ia2fTX9aI9C01n685jWB2HW8Z3tTLxfuH1LCqgO3WIY5Lz9dOy0WbnXQW3Rsy5k5od6lXdtyBfCWxGSvK7TT6VIoJU4DrsUV54TMg=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4ab0902ee94811f1b0c5525400cd780f
    ReservedCode2: DkrQ0HUYZNPKN6gT4cQlKyYHbx6uTAJWqgbNpcILCNpWC38UHmnN+5kAwokIRZXXPfO9ZijEcEWu+TOab0qGQ8Ia2fTX9aI9C01n685jWB2HW8Z3tTLxfuH1LCqgO3WIY5Lz9dOy0WbnXQW3Rsy5k5od6lXdtyBfCWxGSvK7TT6VIoJU4DrsUV54TMg=
---



# Rakuish 架构说明

> 对象：`C:\Users\Administrator\rakuish`（META6.version 0.131.0）
> 规模：`lib/**/*.rakumod` 共 **45 个模块 / 19,310 行**（含注释与空行），`t/` 下 **76 个测试文件**，入口 `bin/rakuish` 33 行
> 口径：所有结论附 `file:line`；代码行数以工作树当前文件为准
> 说明：仓库里没有成文的「L1–L5」章节，分层模型来自 `docs/ARCH-REVIEW-2026-11-13.md:24-31` 的评审表（0.75 快照），本文按当前代码校准（Agent 线已于 0.81 删除）

---

## 一、分层模型

### 1.1 六层职责表（校准后）

| 层 | 职责 | 权威入口（file:line） | 规模 | 边界（不做什么） |
|---|---|---|---|---|
| **L0 入口** | 进程启动、模式分派 | `bin/rakuish:1-33`（`--version` 快路 + `require Rakuish::CLI`）、`lib/Rakuish/CLI.rakumod:303` `run()` | 33 + 717 | 不做输入分类，只决定「一次性脚本 / `-e` / 交互 REPL」 |
| **L1 输入分类** | 把一行文本分成"会话命令 / shell 命令 / Raku 代码" | `lib/Rakuish/REPL/Session.rakumod:1416` `eval-line`、`:1577` `!eval-line-body` | 3,372（含 L1+L4+会话状态） | 只有**三类输入**，没有管道/重定向语法（V-901） |
| **L2 命令与观感** | 命令表、argv 解析、补全、usage/help | `lib/Rakuish/REPL/Shell.rakumod:72` `COMMANDS`、`:1319` `completions`；`lib/Rakuish/Command.rakumod:115` `CommandRegistry` | 1,500 + 203 | 不做系统调用，一律下派 L3 |
| **L3 系统操作** | 文件/进程/TTY/作业/环境变量，唯一系统出口 | `lib/Rakuish/Sys.rakumod:309` `exec`、`:447` `rm`；`Sys/FS.rakumod`(873)、`Sys/Proc.rakumod`(924)、`Sys/PosixSpawn.rakumod`(271)、`Sys/WinJob.rakumod`(144)、`Sys/Term.rakumod`(136) | 2,900+ | 不做命令解析，不渲染 |
| **L4 结果与展示** | `Result` 值、文本/Markdown/JSON 渲染、展示包、MIME | `lib/Rakuish/Result.rakumod:1`、`Result/Renderer.rakumod`(276)、`Display.rakumod:42` `Bundle`、`:130` `to-mime`、`REPL/Session.rakumod:2127` `render` | 203+276+448 | 不重新求值，不改 `Result` 语义 |
| **L5 输入行 UI** | 行编辑、语法着色、vi 模式、hint、补全菜单 | `lib/Rakuish/REPL/Keymap.rakumod:250` `HlField`、`:251` `visible-input-field-string`；`REPL/Highlight.rakumod:146` `highlight-line` | 637 + 404 | 不执行任何求值（纯文本等价，V-176） |
| **L6 前端协议** | 把 L1–L4 暴露给编辑器/notebook/GUI/子进程引擎 | `lib/Rakuish/Kernel.rakumod:153` `execute`、`Kernel/Notebook.rakumod:52` `handle`、`Eval.rakumod:516` `eval`、`Eval/Server.rakumod:113` `serve-engine`、`Eval/Proxy.rakumod:91` `eval-line` | 333+314+573+357+289 | 只能复用 `Kernel.execute`，不得绕过 Policy/审计（V-182） |

**横切子层：Data（数据引擎）** — `Data.rakumod`(497) / `Data/Table.rakumod`(494) / `Data/Stream.rakumod`(929) / `Data/Arrow.rakumod`(1,438) / `Data/Duck.rakumod`(300) / `Data/Engine.rakumod`(124) + `Engine/DuckDB`(307)、`Engine/SQLite`(256) / `Data/Cursor`(148)、`Data/Pager`(113)、`Data/CsvOptions`(139)。
它不被 L1–L6 单向调用，而是"被任意层用"：DSL 生成表（`DSL.rakumod:93` `sql`、`:109` `describe`），L4 渲染表（`Session.rakumod:2154` `Table.to-text`），持久化读写（`Data.rakumod:344` `open-data`、`:443` `save-data`）。约 4,700 行，是项目最大的单一子系统。

### 1.2 层间依赖方向

```
L0 入口 → L1 输入分类 → { 会话命令 → L2/L3
                        | shell 命令 → L2 → L3
                        | Raku 代码 → DSL/Raku 运行时 → L3(经 sys 绑定) / Data 层 }
L1/L2/L3 → L4 结果 → L6 前端协议
L5 只读 L1 的状态，不写回
Data 层：被 DSL / L4 / L6 使用；自身只经 Sys 落盘（V-125）
```

**禁止反向依赖的四条实证：**

1. **L3 不认识上层**：`Sys` 只做 op 与资源，命令名字符串不在 `Sys` 里出现（`Sys.rakumod:309` 收 `exe` + argv，不解析命令行）。
2. **L4 不重新求值**：`Display.bundle-from`（`Display.rakumod:224`）只读 `Result` 字段；渲染函数不 EVAL。
3. **L5 不求值**：`highlight-line`（`Highlight.rakumod:146`）是纯函数，输入文本输出带 ANSI 的文本，`V-176`（`SPEC.md:702`）要求着色后**纯文本等价**。
4. **L6 不得绕过 L1**：notebook 的 `execute` 显式走 `Kernel.execute`（`Kernel/Notebook.rakumod:100-102` 注释 "走 Kernel：Policy / 审计 / trail 一个都不绕过（V-182）"）。

---

## 二、核心模块清单与职责

### 2.1 入口与外壳

| 模块 | 行数 | 职责 | 关键行 |
|---|---|---|---|
| `bin/rakuish` | 33 | 唯一入口：加 `lib`、`--version` 快路、`require CLI::run` | `:1-33` |
| `CLI.rakumod` | 717 | 参数解析与模式分派（`-e` / 脚本 / REPL）；REPL 下按 `$tty` 决定是否启子进程引擎；分页 `page-result` | `run():303`、`page-result():551` |
| `Kernel.rakumod` | 333 | 唯一执行入口 `execute(Request) → Result`；Policy 收窄；单点审计（`LEAVE` 块）；展示包 `bundle`；`capabilities` | `execute():153`、`!run-op():239`、`bundle():267`、`capabilities():262` |
| `Kernel/Notebook.rakumod` | 314 | Jupyter 式协议：`kernel_info / execute / complete / is_complete / inspect / shutdown`，`protocol_version 5.3` | `handle():52`、`!execute():93`、`serve():198` |
| `Kernel/Factory.rakumod` | 18 | 组装 Kernel/Session 的工厂（测试与 notebook 共用） | `:1-18` |

### 2.2 REPL 层

| 模块 | 行数 | 职责 | 关键行 |
|---|---|---|---|
| `REPL/Session.rakumod` | **3,372** | 会话状态机：输入分类、会话命令、前奏重放、EVAL、结果收口、渲染、历史、日志、补全、hint、inspect | `eval-line():1416`、`eval-script():1448`、`!finish():1544`、`!eval-line-body():1577`、`!eval-raku():1166`、`render():2127`、`log-line():2273`、`completions():3057` |
| `REPL/Shell.rakumod` | 1,500 | shell 薄层：命令表（单源 `COMMAND-GROUPS`）、argv 解析、`cd/pushd`、`win-cmd-builtin-argv`、补全 | `COMMANDS:72`、`SHELL-COMMANDS:75`、`completions():1319`、`command-names():658` |
| `REPL/Keymap.rakumod` | 637 | 行编辑器子类：着色绘制、vi 模式（`ViField`）、中断处理 | `HlField:250`、`ViField:447`、`ViState:49` |
| `REPL/Highlight.rakumod` | 404 | 词法着色与错误标记（纯函数） | `set-continuation():137`、`highlight-line():146`、`error-marks():285` |
| `REPL/Complete.rakumod` | 123 | 纯补全算法：模糊匹配、排序、建议后缀 | `common-prefix():14`、`subsequence-rank():31`、`fuzzy-words():58`、`suggest-suffix():110` |
| `REPL/SqlComplete.rakumod` | 245 | SQL 方言补全（关键字/表/列） | `:1-245` |
| `REPL/Introspect.rakumod` | 108 | `名字?` 文档内省，**零 EVAL**（V-179） | `:1-108` |
| `REPL/Plugins.rakumod` | 132 | 插件管理：显式加载本地 `.raku` 插件、命令注册、卸载 | `load():62`、`unload():123`、`list():52` |
| `REPL/Hints.rakumod` | 86 | `hint` 数据查询 | `:1-86` |
| `REPL/Chrome.rakumod` | 228 | 提示符、欢迎语、颜色主题等"门面装饰" | `:1-228` |
| `REPL/Methods.rakumod` | 87 | REPL 元能力方法（`repl.history` 等，V-125） | `:1-87` |

### 2.3 数据层

| 模块 | 行数 | 职责 | 关键行 |
|---|---|---|---|
| `Data.rakumod` | 497 | 格式门面：CSV/JSON 文本编解码、`open-data`/`save-data`、Arrow 桥、Parquet 导出 | `open-data():344`、`save-data():443`、`from-csv-data():100`、`to-csv-data():193`、`export-table():52` |
| `Data/Table.rakumod` | 494 | 行式统一表格值（46 个方法），交换格式 | `new():16`、`from-rows():82`、`!infer-type():36` |
| `Data/Stream.rakumod` | 929 | 惰性/游标式数据流，内存预算与外部排序 | `:1-929` |
| `Data/Arrow.rakumod` | 1,438 | 自研 Arrow IPC 读写（纯 Raku 手写 FlatBuffers，零原生依赖）——**仅降级兜底** | `:1-1438` |
| `Data/Duck.rakumod` | 300 | DuckDB 门面 + SQL 桥（Table→临时 Arrow 文件→Duckula→Frame→Table） | `:71`、`:89-156`、`:244-298` |
| `Data/Engine.rakumod` + `Engine/DuckDB`(307) + `Engine/SQLite`(256) | 687 | 引擎抽象与两套实现 | `Engine.rakumod:124` |
| `Data/Cursor`(148)、`Data/Pager`(113)、`Data/CsvOptions`(139) | 400 | 游标、分页、CSV 选项解析 | — |

### 2.4 求值引擎与前端的双进程结构

| 模块 | 行数 | 职责 | 关键行 |
|---|---|---|---|
| `Eval.rakumod` | 573 | 父进程侧的"引擎客户端"：起子进程、帧收发、信号/job 转发、TTY 让渡 | `start():100`、`restart():175`、`request():372`、`eval():516`、`!answer-job():475` |
| `Eval/Server.rakumod` | 357 | 子进程内 loop：读帧→`Session.eval-line`→回帧（`emit():35`、`serve-engine():113`） | `:35`、`:113` |
| `Eval/Proxy.rakumod` | 289 | 前端可替换的会话代理：TTY 直连 or 子进程；提供 `eval-line/render/completions/inspect-name/handle-key` | `eval-line():91`、`render():235`、`handle-key():283` |

### 2.5 其他基础设施

| 模块 | 行数 | 职责 | 关键行 |
|---|---|---|---|
| `Sys.rakumod` | 452 | 唯一系统出口：路径收敛、root 校验、env、文件/进程/TTY 委托 | `!assert-in-root():155`、`resolve():219`、`exec():309`、`tty-exec():317` |
| `Sys/FS.rakumod` | 873 | 文件读写的真实实现（原子写、锁、glob、`ls-table`） | `:1-873` |
| `Sys/Proc.rakumod` | 924 | 子进程、超时、流式输出、进程组回收 | `:1-924` |
| `Sys/PosixSpawn.rakumod` / `Sys/WinJob.rakumod` | 271 / 144 | 平台原生的进程组/作业对象绑定 | — |
| `Audit.rakumod` | 136 | 结构化审计账本（JSONL，单点记账） | `record():58`、`origin-summary():120` |
| `Snapshot.rakumod` | 183 | 会话状态快照的捕获/落盘/恢复 | `capture():108`、`save():137`、`load():174` |
| `Incomplete.rakumod` | 266 | 续行判定（纯函数，跨行字符串/块） | `is-incomplete:1-266` |
| `DSL.rakumod` | 326 | 用户在会话里直接改用的 API 面（`read/ls/sql/table/describe/display/...`） | `bind-session():30`、`open-data():57`、`sql():93`、`display():314` |
| `Result.rakumod` / `Result/Renderer.rakumod` | 203 / 276 | 结果值 + 三种格式的渲染 | `Renderer:1-276` |
| `Display.rakumod` | 448 | 内容级展示包 `Bundle`、MIME 协商、`Shown` 哨兵 | `Bundle:42`、`to-mime():130`、`Shown:173`、`capabilities():436` |

---

## 三、一条完整数据流的走向

以「用户在 TTY 里敲 `sql(open-data('x.csv'), 'SELECT ...')` 并看到表格」为例。

### 3.1 启动阶段（进程拓扑先成型）

1. `bin/rakuish:1-33`：`use lib`、`--version` 快路、`require Rakuish::CLI`，调 `CLI::run()`。
2. `CLI.rakumod:303` `run()`：读参数，判定进入 REPL。若 `$tty` 为真 → `Eval::Client` 起**子进程引擎**（父进程只持前端），否则同进程直跑。
3. 子进程：`Eval/Server.rakumod:113` `serve-engine()` 建 `Session`，进入帧循环 `emit():35`。
4. 父进程：`Eval/Proxy.rakumod:91` `eval-line()` 把每格转发给引擎（`Eval.rakumod:372` `request()`）。

### 3.2 输入阶段（L5 → L1）

5. `REPL/Keymap.rakumod:250` `HlField` 接管按键；每帧重绘走 `visible-input-field-string():251`，内部调 `Highlight.highlight-line():146` 着色（纯文本等价）。
6. 回车后 `Eval::Proxy.eval-line():91` → `Eval.request():372` → 子进程 `Session.eval-line():1416`。

### 3.3 分类阶段（L1）

7. `Session.eval-line():1416` 包装 `!eval-line-body():1577`，后者是一串**顺序 `if` 闸门**：
   - 空行 → `op<skip>`（`:1578`）；
   - 会话命令：`set`（`:1583`）、`history`（`:1608`）、`perf`、`log`、`audit`、`hint`、`plugin`、`describe`、`who/whos/rerun`、`source`、`cells`、`名字?`、`alias/config/hook/explore` 等，全部早返回（`Session.rakumod:1577-1740`）；
   - `!` 前缀命令（`:1727`）：拆 argv、Windows cmd 内建重写（`Shell::win-cmd-builtin-argv`）、`--tty/--capture/--timeout-ms` 元选项 → `Sys.exec():309` 或 `Sys.tty-exec():317`；
   - shell 内建命令（`:1861` 附近）：`Shell.handle()`，查 `COMMANDS:72` 命中则执行并早返回；
   - 其余进 Raku：先 `is-incomplete()`（`Incomplete.rakumod`）判续行，再 `!eval-raku():1166`。

### 3.4 求值阶段（L1 → DSL → Data → L3）

8. `!eval-raku():1166`：`!scan-cell` 扫出本格新名字 → 声明缓存 `@!decls` 维护 → **前奏按需裁剪**（`:1197-1240`，只重放本格点名的声明与别名）→ 装 `%!state` 别名。
9. 词法绑定（`:1328-1342`）：`my \sys = $!sys; my \repl = self; my \registry = $!commands; my \_ = $last; my \In / \Out`。
10. `EVAL "no worries; do \{ $code \n }"`（`:1346`）——**全项目唯一的 Raku 求值点**。
11. 格内 `open-data`：`DSL.rakumod:57` → `Data.open-data():344` → `Sys.read`（`Sys.rakumod:276`）→ `from-csv-data():100` → `Data::Table`。
12. 格内 `sql(...)`：`DSL.rakumod:93` → `Data/Duck.rakumod:89-156`；若入参是 `Table` 则走 SQL 桥 `:244-298`（Table → 临时 Arrow → Duckula → Frame → Table，`ADR-0043:25-27`）。
13. 任何系统动作只经 `sys.*` → `Sys` → `Sys::FS` / `Sys::Proc`（V-125 硬约束）。

### 3.5 收口与渲染（L1 → L4）

14. `Session.!finish():1544`：`index++`、`@!history.push`、`@!out.push`、纯声明格不产生 `Out[n]`（V-320）、`In[n]` 只读（V-322）。
15. `Session.render():2127`：按值类型分派 —— `Table → .to-text`（`:2154`）、`Stream → .text`（`:2161`）、`Result → .display`、其他 `Out[n] = ` + `!fmt`（`.gist` + **4000 字符预算**，`:1888` `MAX-RENDER-CHARS`）；错误走 `paint('错误: ', red)`；`timed/bench/perf` 追加耗时。
16. 前端拿到字符串写屏；同一 `Result` 也会被包成内容级展示包：`Kernel.bundle():267` → `Display.bundle-from():224` → `Bundle.to-mime():130`（text/markdown/json/html），供 notebook / GUI 用 `pick():100` 协商。

### 3.6 持久化（三条独立链路）

17. **审计**：`Kernel.execute():153` 的 `LEAVE` 块是唯一记账点（`:161-170`，正常/拒绝/异常各一条）→ `Audit.record():58` 写 JSONL。
18. **会话日志**：`Session.log-line():2273` → 一律经 `Sys.append`（V-125，`SPEC.md:820`）。
19. **数据落盘**：`DSL.save-data():78` → `Data.save-data():443` → `Sys.write`（原子写见 `Sys/FS.rakumod`）；快照走 `Snapshot.save():137`。

> notebook 路径的差别只有一处：`Kernel/Notebook.rakumod:93` `!execute` 把 `code` 包成 `Request(:kind<source>, :origin<notebook>)` 交给同一个 `Kernel.execute`，响应里附 `display`（`:104`）。

---

## 四、扩展点

| 扩展点 | 位置 | 怎么加 | 约束 |
|---|---|---|---|
| **命令注册（对象式）** | `Command.rakumod:118` `CommandRegistry.register`；`BuiltinCommand:86`、`ExternalCommand:70` | 实现 `Command` role（`name/spec/run`，`:64-66`）后注册 | `run` 只拿到 `$sys` + argv，不得绕过 L3 |
| **命令表（单源）** | `REPL/Shell.rakumod:72` `COMMANDS = (|COMMAND-GROUPS<shell>, |COMMAND-GROUPS<session>, |COMMAND-GROUPS<api>)` | 加 `COMMAND-GROUPS` 条目，补全/help 自动跟进 | 0.77 起"9 处登记"已收敛为此单源（`:39-45` 注释） |
| **会话级命令** | `Session.rakumod:!eval-line-body()` 顺序闸门（`:1577-1740`） | 插一个 `if` 分支，返回 `Result` | 必须经 `!finish` 收口才能进 history/Out；不得新增 `%magic`（V-902） |
| **用户 API（DSL）** | `DSL.rakumod:30` `bind-session`；导出 sub 列表 `:51-314` | 加 `our sub` 并在 `bind-session` 里绑到当前 `Sys` | 只能通过 `session()` 拿 `Sys`，不许直写文件 |
| **显示协议** | `Display.rakumod:42` `Bundle`：`available():72`、`has():88`、`pick():100`、`to-mime():130` | 新格式 = 扩 `Bundle` 的 kind + `to-mime` 映射 | text 必存在、不得掺 ANSI（V-176/V-184，`SPEC.md:951`） |
| **`display()` 命令** | `DSL.rakumod:314` → `Display::Shown:173` 哨兵 | 用于在会话里主动推一次富内容 | 内容一次性写出，`render` 不再重复套 `Out[n]` |
| **补全器** | `Session.completions():3057` → `Shell.completions():1319` + `Complete`（`fuzzy-words():58`）+ `SqlComplete`(245) | 新上下文（如 SQL）加一个分支/模块 | 候选是**整行替换**（`Notebook.rakumod:120-124` 注释） |
| **文档内省** | `REPL/Introspect.rakumod`（零 EVAL）+ `Session.inspect-name` | 加 introspection 源 | 不得 EVAL（V-179） |
| **notebook op** | `Kernel/Notebook.rakumod:52` `handle` 的 `given` 分支（6 个 op） | 加 `when` 分支 + 一处文档 | 未知 op 必须明确报错（`:63-67`），不得静默成功 |
| **插件** | `REPL/Plugins.rakumod:62` `load($sys, $registry, $path)` | `plugin load <path>` 显式加载本地 `.raku`，内部用 `CommandRegistry` 注册 | 默认关闭、显式路径、不沙箱（V-156），`enabled():32` 由 config 控制 |
| **`op` 通道** | `Kernel.rakumod:239` `!run-op` | 目前只开 `capabilities`（`:240-243`） | 未接入的 op 返回 501 并写明原因；**禁止 `eval` op**（V-503） |
| **数据引擎** | `Data/Engine.rakumod`(124) + `Engine/DuckDB`(307)/`Engine/SQLite`(256) | 实现引擎接口后挂到 `open-db` | 引擎差异必须收敛在门面（`Data/Duck.rakumod`）内 |
| **前端代理** | `Eval/Proxy.rakumod`（TTY 直连 / 子进程） | 新前端实现同一组方法（`eval-line/render/completions/inspect-name/handle-key`） | 必须落回 `Kernel.execute`（V-182） |

---

## 五、架构硬约束（不能轻改的条款）与原因

### 5.1 ADR-0001 的七条拍板

`docs/ADR/ADR-0001-raku-native-shell.md` 采纳七条（0.81 后部分被后续 ADR 收敛，见括号）：

| # | 决策 | 现状 | 原因 |
|---|---|---|---|
| 1 | 不实现 bash/POSIX 子集（管道、重定向、`$VAR`、heredoc、`&&`） | **仍然有效**，`SPEC.md` V-901 | v2 正是"在错误底座上补 bash 语义"死掉的，ADR-0001 §1 列了 7 个 P0 |
| 2 | `Sys` 是会话级唯一系统出口 | **仍然有效**，V-125（`SPEC.md:95`、`:820`） | 让"哪些动作碰了系统"可审计、可测试、可单点收口 |
| 3 | 外部命令 argv-only | **仍然有效**（`Session.rakumod:1727-1770` 只拆 argv，Windows cmd 内建也只重写 argv，ADR-0049） | 不做 shell 语法解释，就没有引号/转义/注入的语义 bug 面 |
| 4 | Agent 用结构化 op 而非自由代码 | 0.81 起 **Agent 协议整条删除**（`Kernel.rakumod:239-250` 只留 `capabilities`） | 自由 `eval` op 会绕过 root/白名单/审计——V-503 |
| 5 | 默认安全 | 0.81 起改为 **本机全权限**（V-197…V-199，`SPEC.md:1095/1103/1114`） | 定位改为"单入口本地 shell"，安全模型从"闸门"退到"防误操作" |
| 6 | REPL 不保留 `%magic` | **仍然有效**，V-902 | `%` 在 Raku 是哈希 sigil，语法上不可行；会话能力一律走 `repl.*` 或普通命令 |
| 7 | 入口唯一 | **仍然有效**，V-111~V-118 | 多入口会导致状态与审计分叉 |

### 5.2 五条"绝对不能悄悄删一行"的条款

`docs/ARCH-REVIEW-2026-11-13.md:44-47` 明确点名：

| 条款 | 内容 | 位置 | 若改的代价 |
|---|---|---|---|
| **V-901** | 永不支持 bash/POSIX 语法（管道/重定向/变量展开） | `SPEC.md` V-901 | 推翻性：重写 L1 输入分类，恢复 v2 的 `Parser`/`Engine::Pipeline` |
| **V-902** | 不保留 `%magic` | `SPEC.md` V-902 | 语法不可行；换 sigil 等于改语言约定 |
| **V-905** | worker 不引入进程树跟踪等 | `SPEC.md` V-905 | 需新增作业表 + SIGTSTP/SIGCONT + 进程树回收，独立 ADR |
| **V-906** | 不做常驻求值器/持久编译单元（配合 V-124） | `SPEC.md` V-906 | 换底座，独立 ADR |
| **V-503** | 不提供 `eval` op | `SPEC.md` V-503；代码侧 `Kernel.rakumod:239-250` | **不要做**：会绕过 root/白名单/审计，是安全模型地基 |

改这五条的正确姿势：先把 `ADR-0001` 状态改成 `Superseded`，再重写设计文档 —— 不是改 SPEC 表格里的一行字。

### 5.3 实现层面的"硬骨头"约定

| 约定 | 证据 | 为什么硬 |
|---|---|---|
| 落盘一律 `Sys.write` / `Sys.append` | V-125（`SPEC.md:820`）；`Session.log-line():2273`、`Snapshot.save():137` 都如此 | 绕过去就没有原子写/锁/root 校验 |
| 唯一 EVAL 点 | `Session.rakumod:1346` | 多一个 EVAL 点 = 多一处无法审计的代码执行 |
| 唯一记账点 | `Kernel.rakumod:161-170` 的 `LEAVE` 块 | 0.76 显式记账曾漏掉"策略拒绝"分支；`LEAVE` 保证正常/拒绝/异常各一条 |
| 着色纯文本等价 | V-176（`SPEC.md:702`）、V-177 | 着色是装饰，不能改变语义/可复制文本 |
| 纯声明格不产生 `Out[n]` | V-320（`Session.rakumod:1362-1366` 注释） | 与 IPython 口径一致，避免 `Out` 编号被 `sub`/`use` 污染 |
| 别名必须先于声明重放 | V-319（`Session.rakumod:1199-1205` 注释） | 否则第二格起 `sub f { $n }` 编译失败且**每格都失败**，会话锁死 |
| `In[n]` 只读 | V-322（`Session.rakumod:1335`） | 历史不可被 EVAL 复用，避免副作用重放 |

---

## 六、当前架构的已知薄弱点

按"会不会拖慢以后每一个功能"排序。

### 6.1 L5 行编辑仍是单一覆盖点（结构性债，未解）

`REPL/Keymap.rakumod:250` 的 `HlField` 通过覆盖 `visible-input-field-string():251` 一个方法同时承担"着色 + 左边距 + padding + 右标记"。`ARCH-REVIEW:66` 已把它列为三处技术债之一（"`autosuggestion` / 候选菜单会互抢同一个方法"），并指出依赖 `scroll-cursor`/`available-width` 等内部访问器（V-154 已记缺口）。0.74 的着色高亮（`Highlight.rakumod`）**又加深**了对 LineEditor 内部的依赖。要加 autosuggestion 或候选菜单，必须先把 `HlField` 升级成"渲染策略组合"，否则只能叠补丁。

### 6.2 `Session` 是 3,372 行的上帝对象

L1 输入分类、会话状态、前奏重放、渲染、日志、补全、hint、inspect 全在一个类里（`Session.rakumod`）。单文件占全项目 17.5%。分层图上的 L1 与 L4 事实上被同一个类承载，`!eval-line-body():1577-1886` 的 300 行顺序 `if` 是每次新命令都要碰的地方。

### 6.3 前奏重放的编译成本（已缓解，未根治）

每格把所有声明与 `%STATE` 别名重新编译一遍：评审实测 40 个 `sub` 后约 **109 ms/格**（`Session.rakumod:1197-1200` 注释）。0.131 引入"按需裁剪"（只重放本格点名者 + 传递闭包，`:1230-1260`），但 `use` / `enum` / 非普通标识符声明仍无条件重放，且 `enum`/`subset` 跨格重放本身有既存缺陷（第二格起 `Redeclaration`，见 ADR-0050 §4，注释里明确"这里只是不裁它，并没有修它"）。

### 6.4 数据层：Table 是行式物化值，SQL 桥靠临时文件

- `Data/Table.rakumod`（494 行 / 46 方法）是 `@.columns/@.rows` 行式结构，统计 `O(n)`、`join` 内存 Hash 全量复制、类型不强制、无列式。适合几万行以内交互，大表必须走 SQL/`Engine.query`。
- `Table.sql` 与 SQL 桥是 **O(行数) 拷贝**：Table → 临时 Arrow 文件 → Duckula → Frame → Table（`ADR-0043:25-27`、`:60-63`；实现 `Data/Duck.rakumod:244-298`）。实测 5 万行 4,797 ms vs 直插 853 ms（5.6×）。
- `Data/Stream.rakumod` 929 行承担了本应由引擎承担的预算/排序职责，是"没有列式引擎"的补偿性复杂度。

### 6.5 Arrow：1,438 行自研模块与文档口径不一致

- 用户裁定（`docs/HANDOFF-2026-11-24-arrow.md`）：自研 `Rakuish::Data::Arrow` 只作**零原生依赖的降级兜底**，路线是 `Rakuish API → Duckula DataFrame → DB::DuckDB C data → DuckDB+nanoarrow`，不要在 Rakuish 里做通用 Arrow 解码。
- 但 `ADR-0038/0044` 与 SPEC 仍把自研模块表述为读侧主路、CPAN `Arrow::IPC` 为嵌套/字典回退；`SPEC §3.52` 还写着"读 `.arrow → Arrow::IPC`"，与实现不一致（P3.3 未清）。
- `Arrow::IPC` 仍是硬依赖（读侧回退用），且坏文件绝不能交给它（无越界检查会 SIGSEGV）——这是一条靠约定维持的安全边界，不是结构保证。

### 6.6 双进程引擎带来的"能力降级面"

父进程 `Eval/Proxy.rakumod` 是前端代理，若干方法在代理态只能返回空/降级：`history():66` 返回 `()`、`run-hooks():79` 返回 `()`、`note-timing():82`、`log-line():86` 为空实现。结果是"TTY 直连"与"子进程引擎"两种模式下，历史、hook、计时的可用性并不一致（功能上靠子进程侧补，前端不再重复）。同时两套异常体系（MoarVM/JVM 类型名不同，0.72 已踩过）使 `Eval/Server` 的帧边界成为必须长期维护的兼容层。

### 6.7 notebook 与 TTY 两套前端各自实现 execute 语义

`Kernel/Notebook.rakumod:93` `!execute` 与 `Session.eval-line():1416` 各自组装"一次执行"的周边（`execution_count`、`cwd`、`display`、`streamed`），共享的只有 `Kernel.execute`（V-182 保证不绕过审计）。任何涉及"格语义"的改动（如 V-320 的声明格、V-322 的 `In[n]`）都要在两个前端各确认一次。

### 6.8 文档债本身也是架构债

`docs/ARCH-REVIEW-2026-11-13.md:1-15` 头部自标"**历史快照**、基线 0.75.0、排期表已过期"；ADR-0001 的"默认安全"已被 V-197…199 取代、Agent 线已删除，但 ADR 正文未标 Superseded。结果是"读 ADR 得出的结论可能是过时视角"——Arrow 那次排查就是这么踩到的。

---

## 附：一句话总结

Rakuish 的架构是**一条单向管道**：`入口(CLI) → 输入分类(Session/Shell) → 系统出口(Sys) → 结果与展示(Result/Display) → 前端协议(Kernel/Notebook/Eval)`，横切一个以 `Table` 为统一交换格式的数据子层；管道的四道闸门（唯一 EVAL 点、唯一审计点、唯一系统出口、唯一入口）由 ADR-0001 七条与 V-901/902/905/906/503 五条钉死。**能"加代码"扩展的是 L1–L4 与 Data 层；L5 是独占插槽；L6 是另一套协议。** 当前最该治理的不是架构而是三件事：`Session` 的体量、`HlField` 的单点、Arrow/SPEC 的口径漂移。
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
