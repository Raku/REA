---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_50321019e94811f1b0c5525400cd780f
    ReservedCode1: NrVHnOhOH6LHZOwCankYRMXv5saAxbA/iGr2/Q6DSOBAwU/E49iyQpgidgMvWy3CE9nY16b5IO7MYiF7hm92F9U+ePNdRptmilhA+N0jaKxjBNDQOLYHuAXofVATHjTFHY3RrmRCAzfty3GGYrbeodV8cpmd2GucMHQ85oJCYaQql0zTwtBBu+d/jfg=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_50321019e94811f1b0c5525400cd780f
    ReservedCode2: NrVHnOhOH6LHZOwCankYRMXv5saAxbA/iGr2/Q6DSOBAwU/E49iyQpgidgMvWy3CE9nY16b5IO7MYiF7hm92F9U+ePNdRptmilhA+N0jaKxjBNDQOLYHuAXofVATHjTFHY3RrmRCAzfty3GGYrbeodV8cpmd2GucMHQ85oJCYaQql0zTwtBBu+d/jfg=
---



# Sys::FS 上限机制核查 与「默认 limit 100」可行性评估

核查对象：`C:\Users\Administrator\rakuish`（Rakuish）
核查日期：2026-11-26
结论口径：所有行号取自当前工作树实际文件，消息文本为源码原文。

---

## 0. 结论速览

1. `Sys::FS` 只有**两个**上限常量：`$.max-bytes`（默认 1 MiB）与 `$.max-entries`（默认 100 000），定义在 `lib/Rakuish/Sys/FS.rakumod:15-16`。
2. 上限**不是**授权/沙箱模型的一部分，是「防止 eager slurp 把内存吃爆」+「防止递归遍历巨型目录耗尽内存与时间」的资源保护；依据 `docs/ADR-0001-raku-native.md:155`、`FS.rakumod:72-73`、`SPEC.md` V-271。
3. 「默认 limit 100 行」**不能直接替代**体积上限：两者防的不是同一件事（字节 vs 行），且 `read` 的返回类型（`Str`/`Blob`）没有「已截断」载体，默认截断会违反 ADR-0001 明示的「不静默截断」原则。
4. 但**行数上限这件事本身已经在项目里存在且成熟**：`read-lines(:head N)`（`FS.rakumod:152`）、显示层 `max-rows=200`（`Display.rakumod:224`）、引擎 `:max-rows` 的 LIMIT 下推（`Data/Engine.rakumod:10-14`、`Data/Engine/DuckDB.rakumod:102-109`）、Scan 骨架 `SCAN-MAX-ROWS=50_000`。
5. 真正缺口的不是 `Sys::FS`，而是 **`Data.rakumod:386-387`**：`open-data` 调用 `read-csv` / `read-parquet` 时**不传 `:max-rows`**，于是大 CSV/Parquet 全量物化。这里补 `:max-rows` 才是「像 DuckDB 那样默认 limit」的正解。

---

## 1. 常量清单（含出处）

| 常量 | 默认值 | 定义位置 | 生效判据 |
|---|---|---|---|
| `$.max-bytes`（属 `Rakuish::Sys::FS`） | `1024 * 1024` = 1 MiB | `lib/Rakuish/Sys/FS.rakumod:15` | `if $cap > 0 && ...`，即 **≤0 视为关闭** |
| `$.max-entries`（属 `Rakuish::Sys::FS`） | `100_000` | `lib/Rakuish/Sys/FS.rakumod:16` | `if $max-entries > 0 && ...`，同上 |

同名常量的上游副本与注入链（改默认值必须同步这里）：

| 位置 | 内容 |
|---|---|
| `lib/Rakuish/Sys.rakumod:55` | `has Int $.max-bytes = 1024 * 1024;` |
| `lib/Rakuish/Sys.rakumod:56` | `has Int $.max-entries = 100_000;` |
| `lib/Rakuish/Sys.rakumod:79-82` | 构造 `Sys::FS` 时注入 `:max-bytes($!max-bytes), :max-entries($!max-entries)` |
| `lib/Rakuish/Sys.rakumod:83` | 同一 `max-bytes` **又**注入 `Rakuish::Sys::Proc`（子进程输出捕获上限）→ 一处抬高，两处放宽 |

周边（非 `Sys::FS`，勿混淆）：`lib/Rakuish/Audit.rakumod:34` 另有 `$.max-bytes = 10 * 1024 * 1024`，只管审计预览体积（`:79`）。

---

## 2. 逐个上限：管什么操作、抛什么、消息长什么样

异常族统一为 `X::Rakuish::Limit`（`lib/Rakuish/Result.rakumod:17`），继承 `X::Rakuish::V3`（`:10-13`，唯一必填 `$.detail`，`message` 直接返回它）。因此所有超限都是**中文单行短语 + 数值 + 路径**，无错误码。

### 2.1 `max-bytes` 管的 4 个点

| # | 操作 | 判断行 | 抛错行 | 消息原文 |
|---|---|---|---|---|
| 1 | `read`：**整份读**（文本或 `:bin`），含 `cat` / `read` 命令 | `FS.rakumod:84`（`:79` 取 `$cap = $max-bytes // $!max-bytes`） | `:89` | `读取超限: {实际字节} > {上限} 字节 ({路径})；大文件请用 read-lines(:head/:tail) 或 head -n / tail -n，或 stream('路径') 惰性记录流；确实要整份读就 read(..., :max-bytes(N)) 显式抬高上限` |
| 2 | `write` / `append`：单次写入 | `:283` | `:280` | `写入超限: {n} > {cap} 字节 ({路径})；可传 :max-bytes(N) 单次抬高，或 Rakuish::Sys.new(:max-bytes(N))` |
| 3 | `write :backup`：覆盖前备份旧文件 | `:305` | `:304` | `备份超限: {旧文件字节} > {上限} 字节 ({路径})` |
| 4 | `cp`：单个普通文件 | `:592` | `:591` | `复制超限: {源文件字节} 字节`（**无路径、无上限值、无出路**） |

### 2.2 `max-entries` 管的 3 个点

| # | 操作 | 判断行 | 抛错行 | 消息原文 |
|---|---|---|---|---|
| 5 | `ls` / `ls -R` / `ls-table` / `glob` 的递归遍历（`!walk`） | `:427` | `:426` | `目录条目超限: {计数} > {上限} ({当前目录})` |
| 6 | `rm` 的删除计划（`!rm-plan`，含 `:dry-run`） | `:528` | `:527` | `删除条目超限: {计数} > {上限} ({路径})` |
| 7 | `cp -r` 的**预检**条目数（`!count-entries`） | `:561` | `:560` | `复制条目超限: {entries} > {上限} ({源目录})` |

调用链与继承关系：

- `ls` → `:414` 传 `:max-entries($!max-entries)` → `!walk`（`:418`）；`glob`（`:848`）在 `:864-867` 复用了 `ls`，故 `glob` 与 `ls-table`（`:439`）自动继承同一上限，无独立判断。
- `rm` → `:497` 传参 → `!rm-plan`（`:522`）。**抛错发生在执行前**，`rm` 本身不会删一半才炸（计划阶段即抛）。
- `cp -r` → `:558-561` 先 `!count-entries` 全量数一遍再抛，**保证不会复制一半**；但 `!count-entries`（`:567-573`）自身**不吃任何上限**，对超大目录是 O(n) 无界递归。

### 2.3 明确豁免上限的路径（这是关键设计）

| 入口 | 位置 | 为什么不设限 |
|---|---|---|
| `read-lines(:head/:tail)` | `FS.rakumod:152`，注释见 `:145-151` | 注释原文：「`read()` 用**整份文件大小**对比 max-bytes……但 head -n 10 只要前 10 行、tail -n 10 只要末 10 行，跟文件多大无关；拿整文件大小卡它们是把保护用错了地方」「**不受 max-bytes 约束**（这是刻意的豁免：读的量与文件总大小无关）」 |
| `follow`（`tail -f`） | `FS.rakumod:179-181` | 轮询增量读，与文件总大小无关 |
| `stream()` 记录流 | 见 `FS.rakumod:89` 消息中给出的出路 | 惰性记录流 |

注意 `read-lines` 当前的**硬前置**：`FS.rakumod:158-160` —— `head` / `tail` 都不给就直接抛 `X::Rakuish::Path`「head / tail 必须给正的 n」。也就是说它**没有默认行数**，必须显式给 N。

---

## 3. 设计意图：为什么是「体积 + 抛异常」而不是「默认截断」

### 3.1 一手依据

| 依据 | 原文要点 |
|---|---|
| `lib/Rakuish/Sys/FS.rakumod:72-73` | 「Phase 1 用『大小上限 + 明确异常』兜住大文件，**不做静默截断**；流式 / `:lines` 留给 Phase 2（ADR-0001 §3）」 |
| `docs/ADR-0001-raku-native.md:155` | 「`read` 的流式 / `:lines` 惰性读取、非法 UTF-8 替换策略 → Phase 2；**本轮用 `max-bytes` 上限 + 明确异常兜住，不静默截断**」 |
| `SPEC.md:764-775`（V-271，0.97.0） | 「`head`/`tail` …… **不受 `read` 的 `max-bytes` 全文上限**——读的量与文件总大小无关」；「`read` 整份读的 1 MiB 上限**保留**（防 slurp 吃爆内存）；超限错误给出三条出路」 |
| `FS.rakumod:85-88`（0.97.0 注释） | 「报错要给**出路**，别让用户对着『超限』干瞪眼…… 大文件整份 slurp 会吃爆内存，所以上限保留」 |
| `docs/DESIGN-RAKU-NATIVE.md:224`、`:244` | 早期设计把 `max-bytes` 归入 `Sys::Sandbox`（roots / allowlist / max-bytes / audit）的「限制：max-bytes / max-time / max-processes」一族 |
| `docs/AUDIT-FIXES-0.71.3.md:9`、`docs/AUDIT-STATUS-2026-11-11.md:46-47` | `!walk` 改为携带计数、超 `max-entries` 立即抛；审计项「递归 / cp 无总上限」已关闭 |
| `docs/AUDIT-FIXES-0.36.0.md:78` | `write :backup` 改为先查旧文件大小，超 `max-bytes` 抛 `X::Rakuish::Limit` |

### 3.2 定性（避免误判）

- **不是权限边界**：0.81.0 / ADR-0019 之后已无「沙箱」概念，`X::Rakuish::Bound` 只表示「越出会话工作目录 / 拒绝删除根」这类**误操作边界**（`lib/Rakuish/Result.rakumod:18-19` 注释明说「不是安全隔离」）。路径根校验由 `Sys.rakumod:219/231/155` 独立负责，与 `max-bytes` 无关。
- **是资源保护**：`max-bytes` 防的是「一次调用把整份文件读进 Raku 字符串/Blob」的内存放大；`max-entries` 防的是「递归遍历巨型目录」的内存与 CPU 放大（典型受害者：`node_modules`、`C:\Windows`）。
- **是产品性选择**：宁可报错 + 给三条出路，也不默默少给数据。这条原则贯穿全项目（`Proc` 的 `clip-bytes` 也带 `truncated` 标记，`SPEC.md:565/603`）。

---

## 4. 能不能「像 DuckDB 那样默认 limit 100」

### 4.1 两者防的不是同一件事

| 维度 | 字节上限（1 MiB） | 行数上限（100 行） |
|---|---|---|
| 真正防什么 | 单次调用的**内存放大**（eager slurp 整份文件） | **结果集规模**放大（物化行数、渲染、下游逐行处理） |
| 防不了什么 | 「只想看表头/前几行」的**合理**大文件需求（一刀拦死，即使只需几百字节） | 单行超长：minified JSON/JS、一行 base64、无换行的二进制——100 行可能是 500 MB |
| 误伤 | 36.9 MB CSV 想读表头 → 抛异常（上一轮已实测撞 `max-bytes`） | 宽行小表（1 KB × 100 = 100 KB）其实毫无内存风险，却被截断，反而丢数据 |
| 判定成本 | O(1)：`stat` 拿大小即判，**不用读内容** | O(N)：必须读到第 N+1 行才知「确实截断」，需早停（`head` 已具备） |
| 截断载体 | 不需要（抛异常，语义诚实） | **必须有**（否则就是静默少数据） |

### 4.2 为什么 DuckDB 能直接 `limit 100` 而 `Sys::FS` 不能

1. DuckDB 的 `limit` 作用在**惰性算子树**上：它按块（vector）从文件里拉取，读到 100 行就停止扫描，全程没有「把整份文件变成一个 Raku 字符串」这一步。`Sys::FS.read` 是**eager slurp**，两者处在不同的抽象层。
2. `read` 的返回类型是 `Str` / `Blob`（`FS.rakumod:74-99`），**没有地方放 `truncated`**。默认截断就等于用户拿到一份「看起来完整、其实少了一半」的文本 —— 直接违反 ADR-0001:155。
3. 而且 `read` 本身**看不懂「行」**：`:bin` 分支（`:97-103`）返回原始字节，二进制文件根本没有行的概念。

### 4.3 结论

- ❌ 不建议把 `read` 的默认行为改成「只取前 100 行」。
- ✅ 「只取前 N 行」这个能力**已经存在**，只是入口叫 `read-lines(:head N)` / `head -n N` / `stream()`（SPEC V-271），并且被刻意从 `max-bytes` 里豁免。
- ✅ 「像 DuckDB 那样默认 limit」应当落在**数据侧**（`open-data` → `read-csv`/`read-parquet` 的 `:max-rows`）与**展示侧**（已有 `Display` 的 `max-rows=200`），而不是文件字节侧。

### 4.4 项目内已存在的行数上限先例（说明范式成熟）

| 层 | 位置 | 默认 | 机制 |
|---|---|---|---|
| 渲染 / Display | `lib/Rakuish/Display.rakumod:224`、`:298`、`:316` | `max-rows = 200` | 超出行数置 `truncated => True`，Table 渲染只出前 200 行 |
| 引擎查询 | `lib/Rakuish/Data/Engine.rakumod:10-14` | 不传则无限制 | 「0.64 的大结果保护：物化前把 `LIMIT` 下推进 SQL」 |
| DuckDB 实现 | `lib/Rakuish/Data/Engine/DuckDB.rakumod:102-109`、`:128-132` | — | `select * from (...) as __rakuish_limited limit ?` 参数化下推 |
| 引擎外部读 | `Engine.rakumod:102`、`:114`；`DuckDB.rakumod:236-250`、`:276-287` | **调用方传** | `read-csv` / `read-parquet` 均接受 `:max-rows` 并转给 `query(:max-rows)` |
| 游标 | `lib/Rakuish/Cursor.rakumod:15`、`:86-103`、`:121` | `batch-size=1000` | 拉够 `max-rows` 即自动 close |
| 扫描（上轮骨架） | `temp/lib/Rakuish/Data/Scan.rakumod:12`、`:40-45` | `SCAN-MAX-ROWS = 50_000` | `limit(max-rows + 1)` 探针判「是否还有更多」 |

**关键缺口**：`lib/Rakuish/Data.rakumod:386-387` ——

```
386:        ?? $db.read-csv($abs, :%csv-options)
387:        !! $db.read-parquet($abs)
```

两处**都没有传 `:max-rows`**，而契约明明支持（`Engine.rakumod:102/114`）。即「DuckDB 那条链」在 Rakuish 里恰恰是全量物化的。这就是「像 DuckDB 那样默认 limit」唯一真正该补的地方。

---

## 5. 若要落地「默认只取前 N 行」：改点与风险

### 5.1 方案分级

| 方案 | 内容 | 破坏面 | 建议 |
|---|---|---|---|
| A | **不动** `Sys::FS` 默认值；仅在超限消息里对 `.csv/.json/.parquet` 追加「改用 `open-data` / `scan` + `:max-rows`」提示 | 极小 | ✅ 优先 |
| B | `read-lines` 增加 `$.max-lines = 100`，`head`/`tail` 都不给时用它，并返回**带 `truncated` 的 Result** | 中（改返回类型） | ⚠ 可选，需签名兼容层 |
| C | `Data.rakumod` 的 `open-data` 补 `:max-rows`（默认 100 或 `SCAN-DEFAULT-ROWS`） | 小 | ✅ 强烈建议 |
| D | 改 `read` 默认为「前 N 行」 | **大**（50 处调用点 + `t/01` 22 条断言 + 语义反转） | ❌ 不做 |

### 5.2 Sys::FS 侧落点

| # | 文件:行 | 现状 | 改什么 | 风险 |
|---|---|---|---|---|
| S1 | `Sys/FS.rakumod:15-16` | 只有 `max-bytes` / `max-entries` | 方案 B 可加 `has Int $.max-lines = 100;`；**必须保持 ≤0 = 关闭**的既有约定 | 与 `Sys.rakumod:55-56` 双份常量需同步，漏一处就出现「实例上的值和注入值不一致」 |
| S2 | `Sys.rakumod:79-83` | 只注入 `max-bytes` / `max-entries` | 新增属性需在此注入 FS | `Sys.new(:max-bytes(N))` 已经同时放宽 FS 和 Proc，再加一个参数会加剧「一个开关管两件事」的耦合 |
| S3 | `Sys/FS.rakumod:152-160` | `head`/`tail` 都不给 → 抛 `X::Rakuish::Path`「head / tail 必须给正的 n」 | 允许缺省 = `$!max-lines` | 这是**语义放宽**，不会破现有调用；但「默认只给前 100 行」若不给 `truncated` 标记，就是静默少数据 |
| S4 | `Sys/FS.rakumod:171` | 返回 `List` | 若做截断需新载体（`Result` 或 `%(lines, truncated, total-probe)`） | 改返回类型会破 `Shell.rakumod:1031-1032`、`FS.rakumod:190-191`（`follow` 内部调用）等调用点 |
| S5 | `Sys/FS.rakumod:74-99` | `read` eager slurp + 抛 `Limit` | **不改**（方案 D 的落点，风险最高：`lib` 内 50 处 `.read(`/`read-lines(`/`.write(`/`.ls(` 调用、`t/01-sys-fs.t` 22 条上限断言） | 一旦默认截断，`cat`/`read` 命令（`Shell.rakumod:497-531`）的输出会与 POSIX 语义分叉 |
| S6 | `Shell.rakumod:507-511`、`:530-534` | 超限时追加「本命令也能抬：`cat --max-bytes=64M`」 | 可按扩展名再追加「数据文件改用 `open-data` / `scan`」 | 仅字符串拼接，风险低 |
| S7 | `Sys/FS.rakumod:591` | `复制超限: {字节} 字节` —— 无路径、无上限、无出路 | 补齐 `({路径})` 与「传更大的 `Sys.new(:max-bytes)`」 | 消息变更会被 `t/01` 的正则断言影响，需同步改测试 |
| S8 | `Sys/FS.rakumod:567-573` | `!count-entries` 全量递归、不吃上限 | 边加边判，超 `max-entries` 立即抛（与 `!walk` 对齐） | 会把「大目录复制」从「先数完再抛」变成「数到上限就抛」，属行为改良，但更快失败可能让用户以为目录较小 |
| S9 | `Sys/FS.rakumod:304-305` | 备份判断用 `$!max-bytes`，**忽略**单次 `:max-bytes` | 与 `:283` 对齐用 `$cap` | 现状是隐性不一致：`write(..., :backup, :max-bytes(64M))` 仍可能因旧文件 > 1 MiB 抛备份超限 |

### 5.3 Data::Scan 侧落点

| # | 文件:行 | 现状 | 改什么 | 风险 |
|---|---|---|---|---|
| D1 | `temp/lib/Rakuish/Data/Scan.rakumod:12` | `constant SCAN-MAX-ROWS = 50_000;`（**门禁**语义） | 拆成 `SCAN-DEFAULT-ROWS = 100`（默认展示）+ `SCAN-MAX-ROWS = 50_000`（硬上限） | 直接把 `SCAN-MAX-ROWS` 从 50 000 降到 100，会让 `table()` 从「最多 5 万行」变「最多 100 行」，现有断言行数的测试会破 |
| D2 | `Scan.rakumod:40-45` | `table(Int :$max-rows = SCAN-MAX-ROWS)`，`limit($max-rows + 1)` 探针 | 默认值换成 `SCAN-DEFAULT-ROWS`，探针逻辑不变 | 探针 +1 是**判「是否被截断」的唯一手段**，不能省；省了就退化成静默截断 |
| D3 | `Scan.rakumod:34-38` | `sql(Str $q, *@args --> Source)` 不追加 `limit` | **建议不改**：用户显式写 SQL 时替他加 `LIMIT` 会改变语义（尤其带 `order by` 的取尾场景） | 若强加，`order by ... desc` 再取 100 会变成「前 100 再排序」的错觉 |
| D4 | `lib/Rakuish/Data.rakumod:370-372` | `open-data` 签名无 `:max-rows` | 加 `Int :$max-rows` | 加可选参数不破现有调用 |
| D5 | `lib/Rakuish/Data.rakumod:386-387` | `read-csv` / `read-parquet` 未传 `:max-rows` | 传 `:max-rows($max-rows)`（缺省 = 新默认） | **最推荐的一处改动**；上游 `Engine.rakumod:102/114`、`DuckDB.rakumod:236-250/276-287` 已完整支持，属纯接线 |
| D6 | `Shell.rakumod:1192`、`DSL.rakumod:87-91`、`Session.rakumod:478` | `open-data` 调用点 | 透传 `:max-rows` / 新增 `--limit` 选项 | `Shell.rakumod:802`、`:828` 的 `usage()` 与 `OPTIONS` 补全需同步 |

### 5.4 全局风险清单

1. **测试牵连**：`t/01-sys-fs.t` 有 22 条上限相关断言（`max-bytes`/`max-entries`/`Limit`/「读取超限」），改默认值或消息文本会直接红。
2. **一个开关管两件事**：`Sys.rakumod:83` 让同一个 `max-bytes` 同时约束「文件读取」与「子进程输出捕获」。用户为读大文件抬到 64 MiB，会顺带把子进程输出上限也抬到 64 MiB。
3. **`0` 的特殊语义**：所有判断都是 `> 0` 才生效，`:max-bytes(0)` 目前等于「关闭限制」。新增 `max-lines` 若写成 `>= 0`，会让既有「0 = 关闭」的肌肉记忆踩坑。
4. **`read-lines` 早停依赖惰性**：`FS.rakumod:166-169` 靠 `IO::Path.lines` 的惰性 `Seq` + `head($n)` 早停。任何「为了判断 truncated 先 `.elems` 一下」的改写都会把 O(N 早停) 变成 O(全文)，等于把豁免变成新的内存炸弹。
5. **落实顺序建议**：D5（`open-data` 补 `:max-rows`）→ S6（错误消息指路）→ S7/S8/S9（消息与预检一致性）→ 最后才讨论 S3/S4（`read-lines` 默认值），因为前三步零破坏面，后一步要动返回类型。

---

## 6. 证据清单

- `lib/Rakuish/Sys/FS.rakumod`（874 行）：`:15-16` 常量；`:72-99` `read`；`:145-171` `read-lines` 与豁免注释；`:179-181` `follow`；`:267-283` `write`；`:303-305` 备份；`:403-427` `ls`/`!walk`；`:485-528` `rm`/`!rm-plan`；`:548-592` `cp`/`!count-entries`/`!copy-one`；`:848-867` `glob`。
- `lib/Rakuish/Sys.rakumod`（453 行）：`:55-56` 同名常量；`:79-83` 注入 FS 与 Proc；`:278`/`:281` 转发 `read`/`read-lines`。
- `lib/Rakuish/Result.rakumod:10-19`：`X::Rakuish::V3` 与 `X::Rakuish::Limit`、`X::Rakuish::Bound` 定义。
- `lib/Rakuish/Display.rakumod:224/298/316`：`max-rows = 200` 与 `truncated` 标记。
- `lib/Rakuish/Data/Engine.rakumod:10-14`、`:102`、`:114`：`:max-rows` 契约（LIMIT 下推）。
- `lib/Rakuish/Data/Engine/DuckDB.rakumod:102-109`、`:236-250`、`:276-287`：真实下推实现。
- `lib/Rakuish/Data.rakumod:370-387`：`open-data` 分派与**缺失的 `:max-rows`**。
- `lib/Rakuish/REPL/Shell.rakumod:441-531`、`:1024-1035`：`cat`/`read` 的 `--max-bytes` 解析与 `head`/`tail` 流式分支。
- `docs/ADR-0001-raku-native.md:155`：`max-bytes` 上限 + 不静默截断的原始决策。
- `SPEC.md:764-775`（V-271，0.97.0）：`read` 1 MiB 保留、`head`/`tail` 豁免。
- `docs/MANUAL.md:699-708`：面向用户的 0.97 说明。
- `docs/DESIGN-RAKU-NATIVE.md:224`、`:244`：`max-bytes` 早期归属（Sandbox 资源限制）。
- `docs/AUDIT-FIXES-0.71.3.md:9`、`docs/AUDIT-STATUS-2026-11-11.md:46-47`、`docs/AUDIT-FIXES-0.36.0.md:78`：上限的历史补丁记录。

---

## 7. 一句话回答

`Sys::FS` 限制的是「一次性吃进内存的量」——1 MiB 的整份读写、10 万条目的遍历；它不能像 DuckDB 那样默认 `limit 100`，因为 `read` 是全量 slurp 的字节 API，没有行概念、也没有「已截断」载体，而项目明确选择「报错 + 给三条出路」而不是「静默少给」。**行数上限该加，但加在 `Data::Scan` 与 `open-data` 的 `:max-rows` 上，不是加在 `Sys::FS.read` 上**——前者零破坏面，后者要反转语义并重写 22 条测试。
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
