---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4d853edee94811f1b0c5525400cd780f
    ReservedCode1: /jH2ggM0jyD6KCFzBnOcGhZhO/sYr0ZlyDs2+MPeK8ZVyG/SR5lHpdMg5V/QS+lftcgiRn75CpCvLm6VQEHOhpgZfPNzCpsjL7yGF2REviDfwz8X+vd59m053qOv3AAsSx8M3NVuO+p9O1bv8KRAcl95I7SqByREV4iPywAUpYStj9NK5QbMVqqyrNI=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4d853edee94811f1b0c5525400cd780f
    ReservedCode2: /jH2ggM0jyD6KCFzBnOcGhZhO/sYr0ZlyDs2+MPeK8ZVyG/SR5lHpdMg5V/QS+lftcgiRn75CpCvLm6VQEHOhpgZfPNzCpsjL7yGF2REviDfwz8X+vd59m053qOv3AAsSx8M3NVuO+p9O1bv8KRAcl95I7SqByREV4iPywAUpYStj9NK5QbMVqqyrNI=
---



# rakuish SQL 桥为什么写临时 Arrow 文件、能否改用 Appender 直插

- 日期：2026-11-25
- 对象：`Rakuish::Data::Duck::query` / `Rakuish::Data::Table.sql`（0.120.0 起的 V-315）
- 结论：**临时文件不是技术上必须的**，是当时"复用已验证的自研 Arrow 写侧 + 不改 Duckula"的省事选择；ADR 里已明确把 `create-table` + Appender 直插列为后续可选优化。实测直插快 4.8–5.6 倍，且顺带修掉一个静默整数溢出缺陷。真正的不可行项是"内存 Arrow 直接注册"，两库都没有这个 API。

---

## 1. 现状：临时 Arrow 文件是怎么走出来的

链路（每张表一个临时文件）：

```
Table ──duck-ready（嵌套列 to-json）──▶
      ──Rakuish::Data::Arrow::write-ipc-file──▶ $*TMPDIR/rakuish-duck-*.arrow
      ──Duckula Session.read-arrow($path, :name)──▶ CREATE TEMP TABLE AS SELECT * FROM read_arrow(?)
      ──$sess.sql($query)──▶ Frame ──table-from-frame（Raku 值，非 IPC）──▶ Table
      LEAVE：unlink 临时文件
```

证据：

| 位置 | 内容 |
|---|---|
| `lib/Rakuish/Data/Duck.rakumod:244` | `our sub query(%tables, Str $query --> Rakuish::Data::Table) is export` 主入口 |
| `lib/Rakuish/Data/Duck.rakumod:259-261` | `LEAVE` 块中 unlink 本批临时文件 |
| `lib/Rakuish/Data/Duck.rakumod:270-277` | 每张表 `write-ipc-file(duck-ready(%tables{$name}), $path)` 写 `$*TMPDIR/rakuish-duck-*.arrow` |
| `lib/Rakuish/Data/Duck.rakumod:283` 前后 | 每次调用新建 `Duckula::Session` |
| `lib/Rakuish/Data/Duck.rakumod:289` | `$sess.sql($query)` 执行（错误堆栈实证行号） |
| `lib/Rakuish/Data/Duck.rakumod:297-299` | `table-sql` 单表糖 → `query` |
| `lib/Rakuish/Data/Table.rakumod:346-348` | `method sql(Str $query, Str :$name = 't')` → `Duck::table-sql` |
| `lib/Rakuish/DSL.rakumod:93-99` | `sql($source, $query)` 短命令 → `table-sql` / `query` |
| `duckula/lib/Duckula/Session.rakumod:380-384` | `method read-arrow(Str:D $path, Str :$name, Bool :$native = True)` —— **只接受文件路径** |
| `DB-DuckDB/lib/DB/DuckDB/Connection.rakumod:894` | `multi method read-arrow(Str:D $path, ...)` 同为路径式 |
| `SPEC.md:2726-2727` | `Duckula.read-arrow → CREATE TEMP TABLE AS SELECT * FROM read_arrow(?)` |
| `SPEC.md:2623-2624` | "桥用 `$*TMPDIR` 下的临时 Arrow 文件做交换（每张表一个，`LEAVE` 删除，t/76 断言不残留）" |

### 当初选临时文件的三条明确理由

1. **不让 Duckula 回写 IPC**：`Frame.ipc-buf` 在 Duckula 0.33.1 上对 TIMESTAMP WITH TIME ZONE 列产出坏字节流（pyarrow 报 Not an Arrow file，`Arrow::IPC` 解码段错误 rc=139）。见 `docs/ADR-0043-table-sql-via-duckula.md:37-46`、`SPEC.md:2625-2630`、模块头注释 `lib/Rakuish/Data/Duck.rakumod:11-16`。**注意这只排除了"让 Duckula 写 IPC"，没排除"用 Appender 灌值"。**
2. **复用已验证的自研写侧**：ADR-0043 原文「写侧复用自研：它写出的文件 DuckDB 能直接读（时间戳、日期、NULL 都对），这也顺便成了自研写入器的第三方兼容性验证」。
3. **不改 Duckula、不做 SQL 生成**：`%tables` 键即表名，`check-name`（`Duck.rakumod:31-38`）只校验标识符，不拼 DDL；表结构由 Arrow schema 自带，桥不需要知道列类型 → 少一层类型映射代码。

ADR 自己承认这是暂时方案：`docs/ADR-0043-table-sql-via-duckula.md:66-68`「**性能**：整表写一次 IPC 再读一次，是 O(行数) 的拷贝；换来的是不用自己维护查询引擎。大表场景后续可以换 `create-table` + Appender 直插（Duckula 已有 `insert`），接口不用变。」

---

## 2. "直接注入内存表"为什么做不到（排除项）

| 候选 | 是否存在 | 证据 |
|---|---|---|
| Arrow C Data / 内存 buffer 注册表 | **不存在** | 对 `duckula/lib/Duckula/*.rakumod`、`DB-DuckDB/lib/DB/DuckDB/*.rakumod` 宽模式检索 `register / from-rows / from-columns / from-data / in-memory` 全部零命中；`Connection.rakumod:861-876` 注释明确 Arrow IPC 由 nanoarrow 扩展的 `read_arrow` / `COPY ... (FORMAT ARROW)` 承担，均走文件 |
| Duckula 内存 Arrow 写侧 | 存在但**已知坏** | `Frame.ipc-buf`，TIMESTAMPTZ 列 rc=139（ADR-0043:37-45） |
| 从 Raku 数据造 Frame 再 `create-table` | 无直接入口 | Duckula `create-table`（`Session.rakumod:445`）只接受 SQL / Frame 源，Frame 全部来自文件或 SQL |

因此"内存直插"在现有 API 下的唯一实现就是 **Appender 逐值写入**（`Duckula::Session.insert` → `Duckula::Write::append-rows`，`Session.rakumod:436`；`DB::DuckDB::Connection.appender`，`Connection.rakumod:277`）。想保留 Arrow 内存传递，只能自己在 Raku 里实现 Arrow C Data Interface（nanoarrow）导出——那等于把自研序列化搬到另一个 ABI，既有原生依赖，也违背"不要在 Rakuish 里做通用 Arrow 解码"的既定裁定。

---

## 3. 实测对比（Windows 11 / rakudo / 5 列：int, num, str, bool, datetime）

脚本：`temp/bench4.raku`；A = 现状（写 IPC → read-arrow → SQL），B = 直插（CREATE TABLE → Appender → SQL），同进程交替，SQL 均为 `select ok, count(*), sum(id), sum(score), count(ts) from t group by 1 order by 1`。

| 行数 | A 总计 | ├ 写 IPC | ├ read-arrow | ├ SQL | B 总计 | ├ DDL | ├ Appender | ├ SQL | 加速 |
|---|---|---|---|---|---|---|---|---|---|
| 1,000 | 182 ms | 100 | 63 | 4 | **36 ms** | 16 | 16 | 4 | 5.1× |
| 10,000 | 946 ms | 945 | 76 | 5 | **199 ms** | 18 | 176 | 4 | 4.8× |
| 50,000 | 4,797 ms | 4,784 | 76 | 4 | **853 ms** | 19 | 830 | 4 | 5.6× |

- 两条路径的查询结果**位级一致**：`False/25000/625000000/…/25000` 与 `True/25000/624975000/…/25000` 完全相同（含 bool、double、timestamptz 列）。
- A 的开销几乎全在自研写 IPC：约 **0.096 ms/行**（≈10.4 万行/秒），随行数线性增长；`read-arrow` 固定 ~76 ms（nanoarrow 扩展首次加载），SQL 执行本身 4-5 ms。
- B 的 Appender 约 **0.0166 ms/行**，DDL 固定 16-19 ms。
- 附带收益：B 路径**不需要 nanoarrow 扩展**（Appender 是原生 C 接口），而 A 路径的 `read-arrow` 依赖它（`Connection.rakumod:872` `!arrow-gate` → `ensure-arrow`，缺扩展时会提示两条命令或需 `:install` 联网）。

---

## 4. 改用直插的可行性与障碍（逐项实测）

| 项 | 现状（A） | 直插（B）实测 | 结论 |
|---|---|---|---|
| bool / double / str | Arrow 标量 | 一致 | 无需处理 |
| 时间类型 | `typeof(d)` = **TIMESTAMP_MS**（自研写 ms 精度） | DDL 写 `TIMESTAMP` + 传 UTC naive 字符串 = **TIMESTAMP**（µs），值逐格相同 | **必须**显式选 `TIMESTAMP` 且 `.utc` 化；若图省事写 `TIMESTAMPTZ`，带时区 DateTime 会整体偏移（实测 `2026-03-01 10:00:00` → `2026-03-01 18:00:00+08`） |
| NULL | `undef` → SQL NULL | 一致（`coalesce(...)` 均回 NULL） | 无需处理 |
| 嵌套 list/map | `duck-ready` 先 `to-json` 成 `str`（`Duck.rakumod:204-240`） | 同样传 JSON 文本进 VARCHAR 列，`[1,2,3]` / `"a"` / `[null,5]` / `[]` 全部一致 | 保留 `duck-ready` 即可，零改动 |
| 超过 int64 的整数 | **静默溢出**：`9223372036854775808` → `-9223372036854775808`（实测） | `BIGINT` 明确报错 `Could not convert string ... to INT64`；`HUGEINT` 正确存 `9223372036854775808` | 顺带修 bug，但属**行为变化**（原先静默成功） |
| 空表（0 行） | `count=0` 正常 | `insert` 0 行 + `count=0` 正常 | 无差异 |
| 列名含 SQL 关键字 | 只进 Arrow schema，不经 SQL，无风险 | `create table k1 (group BIGINT)` **失败**；`("group" BIGINT)` 成功 | **必须新增标识符双引号转义 + 遇 `"` 加倍**，否则关键字列名/引号列名直接炸或注入 |
| 表名 | 已有 `check-name`（`Duck.rakumod:31-38`） | 同样可用 | 复用 |
| 只读守卫 | 用户 SQL 走 `$sess.sql`，被 Duckula 拒绝写语句 | 不变；但内部 DDL/Appender 绕开守卫 | DDL 必须由类型映射表生成，禁止拼接任何用户可控字符串 |

类型映射（B 需要的 DDL 表，全部来源自 `duck-type` 反向映射，`Duck.rakumod:41-68`）：

```
int → BIGINT /num → DOUBLE /str → VARCHAR /bool → BOOLEAN
datetime → TIMESTAMP（UTC naive；不写 WITH TIME ZONE）/ list|map → VARCHAR（JSON 文本）
```

---

## 5. 去掉临时文件要改的代码、测试与文档

### 代码（单点收敛，接口不变）

1. `lib/Rakuish/Data/Duck.rakumod:244-295` `query()`
   - 删掉 259-261 的 `LEAVE` unlink 与 270-277 的写文件循环，去掉 `require Rakuish::Data::Arrow` 与本模块对写侧的依赖（`Duck.rakumod:5` 注释同步）
   - 保留 `duck-ready`（嵌套列 JSON 化）
   - 新增：`ddl-for(%tables{$name}, col-types)` 生成 `create table "view" ("col" TYPE, ...)`；列名走新增的 `check-column-name`/`quote-ident`（`"` → `""`）
   - 新增：按列顺序把 `rows` 摊成位置数组传 `$sess.insert($view, @rows)`；datetime 列先 `.utc` 再格式化为 `YYYY-MM-DD HH:MM:SS`（注意 `strftime` 禁中文字符串）
   - 保留 `$sess.sql($query)` 与 `table-from-frame` 回读（回读路径完全不变，类型还原逻辑复用）
2. `lib/Rakuish/Data/Table.rakumod:346`、`lib/Rakuish/DSL.rakumod:93-99`：**零改动**（签名与语义不变）
3. 顺带清理：`lib/Rakuish/Data/Duck.rakumod:1-16` 模块头注释里"桥用临时 Arrow 文件"的表述

### 测试

- `t/76-duck-sql.t:141-146`「临时文件不残留」——断言对象消失，应改为"调用后 `$*TMPDIR` 无 `rakuish-duck-*` 残留"的恒真兜底断言，或替换为"直插后 column type 断言"。
- `t/76-duck-sql.t` 现有 41 条断言（SPEC:2648 记 43 条）：其中**时间往返**用例要复核是否断言了 `typeof` 或毫秒精度（A=TIMESTAMP_MS → B=TIMESTAMP 会让这类断言失败）。
- 建议新增 4 条：①关键字列名 `group`；②含 `"` 的列名；③`datetime` 带 `:timezone` 的 UTC 归一化；④超过 int64 的行为（改后应报错而非静默溢出）。
- `t/74-arrow-read.t`、`t/78-arrow-fast-path.t` 引用 Duck 模块但不经 SQL 桥，预期不受影响，跑一遍回归即可。

### 文档

- `SPEC.md:2607-2650` §3.54：删"临时 Arrow 文件做交换"、删"回读不走 IPC"里与文件桥绑定的表述、改"可选依赖"措辞（直插后 `arrow` 侧依赖消失，但 Duckula 仍可选）
- `docs/ADR-0043-table-sql-via-duckula.md:60-68`：新增"修订"段落或另写 ADR-0048 记录改用 `create-table` + Appender 的实测数据与时间类型口径
- `MANUAL.md` / `README.md` 中凡"临时 IPC 文件"描述
- `SPEC.md:2740`「1 MB 阈值」段落里首次使用的固定成本构成（libduckdb + Duckula + nanoarrow）需修正为不含量 nanoarrow

---

## 6. 回归风险清单（按严重度）

1. **时间列语义漂移（高）**：`TIMESTAMPTZ` 误用导致 8 小时位移（实测 10:00 → 18:00+08）；`TIMESTAMP_MS → TIMESTAMP` 使 `typeof` 与毫秒截断行为变化，下游若有 `typeof` 依赖或毫秒断言会翻。
2. **标识符注入/语法（高）**：列名现在必须进 SQL，未转义时 `group` 直接 DDL 失败；带 `"` 的列名可造成语句破碎。必须强制双引号 + 加倍转义。
3. **静默溢出变为报错（中）**：`> int64` 的整数原先静默损坏（`9223372036854775808 → -9223372036854775808`），改后 BIGINT 会抛错。属修 bug，但用户可见行为变化，需要 CHANGELOG 明说。
4. **Appender 类型覆盖（中）**：`DB::DuckDB::Appender` 的快速路径只覆盖 integer/float/text/boolean，其余走通用字符串路径（`Appender.rakumod:9-29`）。当前 Table 的 5 种标量全部落在快路径或可 cast，DECIMAL/TIME/BLOB 目前 Table 并不产出，风险可控；将来加 `time`/`decimal` 类型时要同步映射。
5. **只读守卫的边界（低）**：用户 SQL 仍受 `$sess.sql` 守卫约束；内部 DDL/Appender 不受守卫，但输入只来自 Table 元数据。
6. **内存峰值改善与行为一致（低）**：A 峰值 ≈ 表 + 整份文件 buf（50k 行 1.76 MB）；B 逐行灌入，峰值更低，但行数极大时 Appender 事务/提交策略需注意（当前实测 5 万行 830 ms，未做分批事务）。

---

## 7. 建议

- **值得改**：临时文件路径的固定成本（nanoarrow 加载 76 ms、DDL 16-19 ms）对千行级小表就是 4-5 倍差距，而 SQL 桥的典型用法恰恰是小表聚合/join；同时可去掉对 nanoarrow 扩展的隐式依赖。
- **改前先把时间口径定死**：显式 `TIMESTAMP` + UTC naive（与现状值等价），并在 CHANGELOG 里写明 `typeof` 从 `TIMESTAMP_MS` 变 `TIMESTAMP`。
- **不要试图"内存 Arrow 注册"**：两库均无此 API，现存的只有已损坏的 `ipc-buf`；Appender 是唯一落地的内存直插方式（ADR-0043:66-68 早有此判断）。
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
