---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4cac4a86e94811f1b0c5525400cd780f
    ReservedCode1: ihu3TepKuxsqxfpjWUFJxq9/rinLT2th7IbRvpvCiUKcx8KpQVBb+CeRCJk3mXA6ZTzvaJJn0CyuU44r4NpxMwC8SgwhS3tHBb95x81HZ7cHWd4UYwJzuC+6vxJGu0Aq9zT78wLgJSe3gLtn9Ls+fKAcsmpzSOrWQ4gb9vYu0yWKpbRXrGe0iX7Cbqo=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4cac4a86e94811f1b0c5525400cd780f
    ReservedCode2: ihu3TepKuxsqxfpjWUFJxq9/rinLT2th7IbRvpvCiUKcx8KpQVBb+CeRCJk3mXA6ZTzvaJJn0CyuU44r4NpxMwC8SgwhS3tHBb95x81HZ7cHWd4UYwJzuC+6vxJGu0Aq9zT78wLgJSe3gLtn9Ls+fKAcsmpzSOrWQ4gb9vYu0yWKpbRXrGe0iX7Cbqo=
---



# rakuish Arrow 路线成本对账（2026-11-25）

> 性质：**只读决策文档**。不改任何代码、不改任何源文件，仅汇总已核实结论并成表，供"省事 vs 代价"决策使用。
> 口径：所有行号/计数均为本机对 `C:\Users\Administrator\rakuish` 实测（Rakudo 2026.11、DB::DuckDB v2.0.0、Duckula 0.33.1、nanoarrow 已装）。
> 项目状态：META6.version = 0.130.0。

---

## 0. 一句话结论

六笔"图省事"的选择已经全部付过账：最大的一笔是**自研写入器 1,438 行**（唯一零原生依赖兜底，值得保留），第二笔是**SQL 桥每表一次全量 IPC 序列化**（省了约 50 行 DDL 拼装，付了 5.6 倍端到端时间 + 一个静默整数溢出缺陷）。三条路线中：**仅改 SQL 桥直插**投入最小、收益最高（省 78–82%，改动约 50 行 + 4 个测试点）；**全量改走 DB::DuckDB** 方向正确但要重写 `Table` 物化契约，不建议在 0.13x 与前者捆绑做。

---

## 1. 省事动机 → 实付成本对账

| # | 当初图省事的选择 | 动机原文/证据 | 实际付出的代价 | 代价证据 | 账目评价 |
|---|---|---|---|---|---|
| 1 | 读 `.arrow` 的嵌套/字典解码不自研，交给 CPAN `Arrow::IPC` | 「读侧适配成 Table 约 90 行」`SPEC.md:2524-2526` | ①硬依赖进 `depends`；②上游不处理 `BodyCompression` 且不报错 → 必须自写 Footer/block 扫描并**读两遍**拦截，否则静默错数据（真值 `[1,2,3]` 解出 `24/46469901123040552/...`）；③上游越界无检查 → 坏文件回退会 rc=139，必须自带"坏文件绝不回退"判定 | `META6.json:11-15`；`SPEC.md:2537-2541`；`lib/Rakuish/Data.rakumod:409-421`；`lib/Rakuish/Data/Arrow.rakumod:27-28,478`；`lib/Rakuish/Result.rakumod:35` | **已收，仍欠**（依赖口径 + 两道防线维护） |
| 2 | 写侧不换 `Arrow::IPC`，继续自研 | 「`write-ipc` 吃 Arrow C Data 视图，要喂进去得先写 CData 导出器（手工分配指针 + release 回调），代码量与崩溃面都超过现有纯 Raku 写入器」`SPEC.md:2527-2531` | **1,438 行 / 59,737 B / 98 个 sub+method** 的长期维护面；只覆盖 5 种标量；`>int64` 静默溢出；50k 行写入 4.8 s | `lib/Rakuish/Data/Arrow.rakumod`（实测 1,438 行 / 1,340 非空行）；本轮实测 `9223372036854775808 → -9223372036854775808` | **已收**（理由成立：这是唯一零原生依赖兜底，见 §5 路线 A） |
| 3 | SQL 桥用「临时 Arrow 文件」交换，不改 Duckula、不拼 DDL | ADR：「写侧复用自研…顺便成了自研写入器的第三方兼容性验证」`ADR-0043:44-46`；桥不必知道列类型（表结构随 Arrow schema 自带） | 省下 **DDL 拼装 ≈ 50 行**（类型映射 ~7 + 标识符转义 ~15 + 行展开 ~20 + 事务/清理 ~8，原型实测 DDL 生成 12 行）；付出 **每表一次 O(行数) 全量序列化**：50k 行 4,784 ms，而 SQL 执行本身只 4–5 ms → 端到端 4,797 ms vs 直插 853 ms（**5.6×**） | `lib/Rakuish/Data/Duck.rakumod:244-295`（写 270-277、unlink 259-261）；`ADR-0043:66-68` 自认「后续可以换 create-table + Appender 直插」 | **明显亏**：省 50 行，付 5.6 倍时间 + 一个静默溢出缺陷 |
| 4 | 回读绕开 `Frame.ipc-buf`，改走 `Frame.rows` + `dtypes`（因上游 TIMESTAMPTZ 产坏字节流） | `ADR-0043:37-46`；`SPEC.md:2625-2630` | 每行 Hash 物化：HANDOFF 实测 50 万行 `Frame.rows` ≈ 6 s（`HANDOFF-2026-11-24-arrow.md:162-172`）；类型还原依赖字符串解析（timestamptz → DateTime，整列一格失败即退回 `str`） | `lib/Rakuish/Data/Duck.rakumod:73`（`table-from-frame`）；`SPEC.md:2630-2634` | **已收，无法省**（上游 bug 未修） |
| 5 | Table 不引入嵌套类型表达式，进 SQL 前 `to-json` 成文本列 | `SPEC.md:2641-2643`「如实的能力边界」；`ADR-0043:56-59` | SQL 里不能 `tags[1]`、不能取 struct 字段，只能 `like` / `from-json` 解回 | `lib/Rakuish/Data/Duck.rakumod:204-240`（`duck-ready`） | **已收**（占位设计，非缺陷） |
| 6 | 表名只做标识符白名单校验，不做 SQL 转义；列名完全不进 SQL | 「名字会拼进会话，不做转义猜测」`SPEC.md:2621-2622`；`lib/Rakuish/Data/Duck.rakumod:31-38` | 现状零成本（表名只当 `read-arrow(:name)`）；**一旦改直插，列名必须进 DDL**，未转义时关键字列名直接失败、带 `"` 列名可破碎语句 | 本轮实测：`create table k1 (group BIGINT)` 失败、`("group" BIGINT)` 成功 | **欠账转嫁**：路线 B 必须补这一层 |

**对账小结**：6 笔里 3 笔（#2/#4/#5）属"必须付"，2 笔（#1/#6）属"口径/债务转嫁"，1 笔（#3）属**净亏且可立即纠正**。

---

## 2. 三条实现路径账面

| 维度 | ① 自研 `Rakuish::Data::Arrow` | ② CPAN `Arrow::IPC` | ③ DuckDB + nanoarrow |
|---|---|---|---|
| 定位 | 写侧主力 + 内存 `Buf` 读 + 零原生依赖降级兜底 | 读侧嵌套/字典/Map 回退 | 读侧标量列快路（按类型分流） |
| 代码量 | **1,438 行 / 59,737 B / 98 个 sub+method** | 外部包；本仓适配层 ~90 行 + 语义还原 ~100 行（`Data.rakumod:197-300`） | 本仓 0 行解码；分流判定 ~25 行（`Data.rakumod:380-410`）+ 快路调用（`Duck.rakumod:170-183`） |
| 引用数 | **40 处 / 16 文件**（t: 70/74/76/77/78） | **96 处 / 21 文件**（t: 51/74/76；SPEC 17、ADR-0041 12、ADR-INDEX 6、HANDOFF 6） | ~6 处（`Data.rakumod:387,390,406` 探测 + `Duck.rakumod:170-183`） |
| 外部依赖 | 0（纯 Raku） | 1 个**硬** `depends`（`META6.json:15` `Arrow::IPC:ver<0.1.0+>`） | nanoarrow 扩展 **30.3 MB**（`~/.duckdb/extensions/v2.0.0/windows_amd64`）+ libduckdb；需联网 `INSTALL nanoarrow FROM community` |
| 维护成本 | **高**：手写 FlatBuffers，Schema / RecordBatch / BodyCompression / 编码全自扛 | 低：上游维护；但上游 0.1.0 功能缺口要本仓兜 | 低：上游维护；装载失败需回落判定 |
| 已知缺陷 | 只写 5 种标量；`>int64` **静默溢出**；5 万行写 4.8 s；50 万行峰值内存 ≈ 表 + 整份文件 | `BodyCompression` 不报错（静默错数）；越界无检查（截断/随机/中部损坏 → rc=139） | 本机 `arrow-available(:install)` 返回 False 但不报错（手动 INSTALL 才成功）；`Frame.ipc-buf` 写侧 TIMESTAMPTZ 坏（属 Duckula，非本层） |
| 是否可删 | **不可**：删了就没有零原生依赖路径（离线/无 DuckDB 场景塌） | 可（路线 C） | 不可（是唯一高性能读路） |

---

## 3. 性能对账

测量：`temp/bench4.raku`，同进程交替，5 列（int / num / str / bool / datetime），SQL 均为 `select ok, count(*), sum(id), sum(score), count(ts) from t group by 1 order by 1`。A = 现状（写 IPC → read-arrow → SQL），B = 直插（CREATE TABLE → Appender → SQL）。

| 行数 | A 总计 | ├ 写 IPC | ├ read-arrow | ├ SQL | B 总计 | ├ DDL | ├ Appender | ├ SQL | 加速 |
|---|---|---|---|---|---|---|---|---|---|
| 1,000 | 182 ms | 100 | 63 | 4 | **36 ms** | 16 | 16 | 4 | 5.1× |
| 10,000 | 946 ms | 945 | 76 | 5 | **199 ms** | 18 | 176 | 4 | 4.8× |
| 50,000 | **4,797 ms** | **4,784** | **76** | **5** | **853 ms** | 19 | 830 | 4 | **5.6×** |

拆解结论（5 万行）：

- **写 IPC = 4,784 ms，占 99.7%**，约 **0.096 ms/行**（≈10.4 万行/秒），随行数线性；
- **read-arrow = 76 ms 恒定**，是 nanoarrow 扩展首次装载的固定成本，不随行数变（1k/1w/5w 三档都是 63–76 ms）；
- **SQL 执行本身 = 4–5 ms**，与 A/B 无关 —— 即"桥的成本 99% 在把数据搬进 DuckDB，不在查询"；
- **Appender = 830 ms ≈ 0.0166 ms/行**，DDL 固定 16–19 ms；
- 两路查询结果**位级一致**（`False/25000/625000000/…/25000` 与 `True/25000/624975000/…/25000` 全同，含 bool / double / timestamptz 列）；
- 附带收益：B 路径不依赖 nanoarrow（Appender 走原生 C 接口），少一个 30.3 MB 扩展与联网安装面。

> 注：分项为同一轮内计时、总计为同轮总耗时，二者相加会比总计略高（抖动 + `read-arrow` 计入语句准备），不影响"写 IPC 主导"的结论。

---

## 4. 影响面统计（实测）

### 4.1 测试文件（6 个）

| 文件 | `Arrow::IPC` 命中 | `Rakuish::Data::Arrow` 命中 | 与本决策关系 |
|---|---|---|---|
| `t/51-meta-provides.t` | 1 | — | META6 provides/依赖口径（路线 C 需改） |
| `t/70-arrow-ipc.t` | — | 1 | 自研内存 Buf 读写（路线 C 需删/改） |
| `t/74-arrow-read.t` | 5 | 5 | 读侧类型分流 + 回退（路线 C 需重写） |
| `t/76-duck-sql.t` | 1 | 2 | **SQL 桥（路线 B 唯一必改）**，41 条断言，含临时文件不残留 `:141-146` |
| `t/77-arrow-write-batches.t` | — | 1 | 写侧多批（路线 C 需改） |
| `t/78-arrow-fast-path.t` | — | 1 | DuckDB 标量快路 |

### 4.2 符号引用

- **`Arrow::IPC`：96 处 / 21 文件**（top：`Data.rakumod` 19、`SPEC.md` 17、`ADR-0041` 12、`ADR-INDEX` 6、`HANDOFF` 6、`ADR-0044` 5、`t/74` 5）
- **`Rakuish::Data::Arrow`：40 处 / 16 文件**（top：`Data.rakumod` 8、`t/74` 5、`SPEC.md` 4、`Duck.rakumod` 4）

### 4.3 文档

| 类别 | 数量与清单 |
|---|---|
| 专述 Arrow 的 ADR | **6 篇**：ADR-0038（22 处）、ADR-0041（18）、ADR-0044（19）、ADR-0047（18）、ADR-0043（14）、ADR-0045（10）；另 ADR-INDEX 12 处、ADR-0013/0020/0048 各 1–3 处顺带提及 |
| SPEC 条款 | **6 处**：§3.47（`SPEC.md:2313` 读写基础）、**§3.52（2518，读侧走 Arrow::IPC）**、§3.55（2551，类型分流 + 坏文件护栏）、**§3.54（2607，SQL 桥临时文件，2623-2624）**、§3.56（2651，写侧多批）、**§3.57（2712，标量列交 DuckDB）** —— 其中 §3.47 / §3.52 / §3.55 / §3.57 是 Arrow 读写路线核心四处 |

---

## 5. 决策对照表

| | **路线 A：保留自研（维持现状）** | **路线 B：仅改 SQL 桥直插** | **路线 C：全量改走 DB::DuckDB（删自研 + 删 Arrow::IPC）** |
|---|---|---|---|
| 动作 | 不动 | `Duck.rakumod:244-295` 去掉临时文件，改 `CREATE TABLE` + `Session.insert`（Appender），新增类型映射 + 列名转义；回读链路不变 | 删 `Arrow.rakumod`（1,438 行）、删 `t/70`、改 `t/74/77/78`、改 `Data.rakumod:197-430` 读侧分流为"全走 DuckDB"、`META6.json:15` 移除 Arrow::IPC、改写 6 篇 ADR + SPEC 四处条款 |
| 收益 | 零风险；离线/无 DuckDB 仍可用 | SQL 桥端到端 **省 78–82%**（1k: 182→36；1w: 946→199；5w: 4,797→853）；去掉 nanoarrow 隐式依赖；顺带修 `>int64` 静默溢出；兑现 ADR-0043:66-68 的自认改进 | 再省 `Arrow::IPC` 硬依赖与 96 处引用；`>int64`/嵌套/时间类型交 DuckDB 统一；维护面 −1,438 行 |
| 代价 | 每表一次全量序列化（5.6×）；静默溢出缺陷留存 | 约 50 行新代码（类型映射 / 标识符转义 / 行展开）+ `t/76` 4 个测试点改写 + SPEC §3.54、ADR-0043 修订 | 巨大：`Table` 是行式 `@!rows`（`Table.rakumod` 494 行、29 处依赖行式结构），值必须 Raku 对象 → 想"不装箱"就得重写物化契约；`t/70/74/77/78` 重写；6 ADR + 4 条款重写；**且失去零原生依赖兜底**（违背 HANDOFF 只把它降级为兜底的裁定） |
| 风险 | 性能债持续；用户感知"SQL 桥慢" | 中：时间口径漂移（`TIMESTAMP_MS`→`TIMESTAMP`；误用 `TIMESTAMPTZ` 会 10:00→18:00+08）；列名转义遗漏 → DDL 失败/注入；溢出由静默变报错（需 CHANGELOG） | 高：单点依赖 DuckDB 原生栈；离线不可用；改动面横跨 6 测试 + 6 ADR；与用户"不要再做通用 Arrow 解码"裁定方向一致但**执行成本远超收益** |
| 建议 | 作为兜底保留（符合用户 2026-11-24 裁定） | **首选，先做** | 分阶段，不与此轮捆绑；先做 B，再评估读侧是否还有自研必要 |

**组合建议**：A（保留自研为兜底）+ B（SQL 桥直插）→ 观察 0.13x 后再评估 C。理由：B 的收益是确定的（5 倍级、可实测）、代价是最小的（约 50 行、单函数收敛、`Table.sql` / `DSL.sql` 签名零改动）；C 的收益主要是"少 1,438 行维护面"，但代价是重写 `Table` 物化契约与 6 篇 ADR，两者量级不对等。

---

## 6. 待清项与本次决策的关联

| 待清项 | 现状证据 | 与三条路线的关系 |
|---|---|---|
| **P3.3 依赖口径矛盾** | `META6.json:11-15` 硬列 `Arrow::IPC:ver<0.1.0+>`；README 称只有 3 个依赖/可选口径；代码按可选处理（`Data.rakumod:426-430`）；REVIEW 明列「现在是硬 `depends`，但代码按可选处理」`docs/REVIEW-VS-IPYTHON-2026-11-24.md:470` | 路线 C **直接消解**（删依赖）；路线 A/B 必须二选一改口径（改 `:optional` 或补装说明），否则一直是文档失真项 |
| **SPEC §3.52 口径滞后** | `SPEC.md:2518-2522`「读侧交给独立包 `Arrow::IPC`」；实际已被 V-316（`§3.55:2551` 类型分流）与 V-318（`§3.57:2712` 标量交 DuckDB）取代 | **三条路线都要改**（纯文档债，与代码无关） |
| **SPEC §3.54 临时文件表述** | `SPEC.md:2623-2624`「桥用 `$*TMPDIR` 下的临时 Arrow 文件做交换…t/76 断言不残留」；`t/76:141-146` 对应断言 | 路线 B **直接使之过时**（断言对象消失） |
| **ADR-0043 自认的改进项** | `ADR-0043:66-68`「大表场景后续可以换 `create-table` + Appender 直插（Duckula 已有 `insert`），接口不用变」 | 路线 B 就是兑现这句，属于"补上当时留的口子" |
| **用户裁定：不做通用 Arrow 解码** | `HANDOFF-2026-11-24-arrow.md:56`「现在的 1300 行自研…只应作零原生依赖的降级兜底」 | 路线 C 方向正确但属"读侧全量替换"，与本轮 B 不冲突；B 先把最亏的一笔（临时文件）纠正 |
| **文档版本守卫矛盾** | REVIEW:469（README/HANDOFF/ADR-INDEX/META6 版本互不一致） | 三条路线任意一条落地时都会动文档，建议顺带统一版本行 |

---

## 7. 数据来源与测量口径

| 数据 | 来源 |
|---|---|
| 1,438 行 / 59,737 B / 98 sub+method | `lib/Rakuish/Data/Arrow.rakumod`（Python 逐行实测） |
| 300 行桥模块、`query` 主体 | `lib/Rakuish/Data/Duck.rakumod:244-295` |
| 三档性能、位级一致、边界行为（时间/大整数/空表/关键字列名） | `temp/bench4.raku`、`temp/bench5.raku`、`temp/bench6.raku` 实测输出（`temp/out4.txt`、`out5.txt`、`out6.txt`） |
| 符号引用数（96 / 40） | 对 `lib,t,docs,META6.json,README.md,MANUAL.md,SPEC.md` 全量检索 `Arrow::IPC` / `Rakuish::Data::Arrow`，按文件计数 |
| ADR 篇数与命中数 | `docs/ADR-*.md` 检索 `arrow` 分组计数 |
| 依赖与体积 | `META6.json:11-15`；`~/.duckdb/extensions/v2.0.0/windows_amd64/nanoarrow.duckdb_extension` = 30.3 MB |
| 上游缺陷 | `ADR-0043:37-46`、`SPEC.md:2537-2541`、`lib/Rakuish/Result.rakumod:35`、`lib/Rakuish/Data/Arrow.rakumod:27-28,478` |
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
