---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4e6146c6e94811f1b0c5525400cd780f
    ReservedCode1: 4BFiE+A1D+lrYWWjtfckSRJZup0usEDcuM5Kyc3EE6f8sIIifc0LUqxGSJH7h901+N2F7xEXtX264YioYaaSwE6elyxdpPE90rVL0kQ8Zz9MlW4ilf4kJ30QSOpAg/vR8/8XWfdb1m27fvTW7n3zcoUNDU9J7adCG3EwSRM83AH83/DRAmNurBXqS0U=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: aed9bd2c2f3c6f83a54981e0ddb92ca2_4e6146c6e94811f1b0c5525400cd780f
    ReservedCode2: 4BFiE+A1D+lrYWWjtfckSRJZup0usEDcuM5Kyc3EE6f8sIIifc0LUqxGSJH7h901+N2F7xEXtX264YioYaaSwE6elyxdpPE90rVL0kQ8Zz9MlW4ilf4kJ30QSOpAg/vR8/8XWfdb1m27fvTW7n3zcoUNDU9J7adCG3EwSRM83AH83/DRAmNurBXqS0U=
---



# Table 改用 DuckDB 作为底层存储的可行性评估

> 评估对象：`lib/Rakuish/Data/Table.rakumod`（506 行）及其 20 个下游模块、24 个测试
> 评估环境：Rakudo Star v2026.11 / Windows 11 / DuckDB via Duckula（本机可用）
> 全部耗时为本机实测，脚本见文末「复现方式」

---

## 0. 结论摘要

**不建议把 `Rakuish::Data::Table` 改成以 DuckDB 为底层存储、只做方法封装。**

理由不是"DuckDB 不够快"，而是三点被实测数据推翻的假设：

1. **痛点定位错位。** 「量一大就不行」的真实来源是 **Raku 侧的行物化**（每行一个 Hash + 每次变换全量复制），不是计算速度。100 万行在 DuckDB 里做过滤/分组/自连接只要 **11 ms / 12 ms / 28 ms**；而把这些行变成 Raku 值再变回去要 **47 s + 2.3 s/10 万行**。把存储换成 DuckDB 只搬走了 1% 的成本，还额外增加一道序列化。
2. **Table 的契约本身就是"行式物化值"。** `has @.rows`（`Table.rakumod:11`）是 `Array[Hash]`，模块内 29 处直接依赖 `@!rows`，模块外 **34 处**直接读 `.rows`（Display / Stream / Arrow / Cursor / Engine / Eval / Renderer …）。只要方法还得返回行，物化就无法避免——这与存储放在哪里无关。
3. **方案与既有设计决策冲突。** `docs/DESIGN-DATA-ENGINE.md:196-199` 已明确：Table 负责"小于几万行、交互式组合"，大表交给 DuckDB SQL，且"后续可加 **DataFrame 作为 lazy 层，但 Table 仍是结果交换格式"、"不自动把 Raku 表达式编译成 SQL"。

**推荐路线：保留 Table 作为物化值，分三阶段做（详见 §7）**：①先做"零拷贝直读"（CSV/Parquet 直接在 DuckDB 里查，实测 100 万行 309 ms vs Raku 物化 10.7 s，**34×**）；②新增 lazy `DataFrame` 类型承载 DuckDB 句柄，`collect(n)` 才回 Table；③Table 只补 `to-dataset` / `Table.from` 这类桥，不动存储与契约。

---

## 1. 基线：当前 Table 的数据模型契约

| 契约项 | 证据 | 说明 |
|---|---|---|
| 列名列表 | `Table.rakumod:10` `has @.columns is rw` | 公开可写 |
| **行是 Hash 数组** | `Table.rakumod:11` `has @.rows is rw` | 核心契约：`Array[Hash]`，行内键即列名 |
| 列类型标注 | `Table.rakumod:12` `has %.types is rw` | 仅 `int/num/str/bool/datetime/list/map/any`，**不强制** |
| 类型推断可退化到 `any` | `!infer-type` `Table.rakumod:34-45` | 列内混装类型 → `'any'`；`Hash`/`Positional` 值原样保留 |
| 行归一化不校验 | `!normalize-rows` `Table.rakumod:47-72` | 只做 `Hash` 化与 Pair 补齐，**不裁列、不转类型** |
| 一切变换都是新建表 | `limit:161`、`tail:174`、`offset:179`、`where:314`、`select:323`、`sort-by:343`、`distinct:224`、`join:259` | 每个方法都 `Table.new(:rows(新数组))`，O(n) 复制 |
| 物化、非惰性 | `schema:118-136`（要扫全列判 nullable）、`describe:143-157`（要 distinct/non_null/sample） | 读属性即得结果，无延迟计算 |

> 关键点：Table 的"值语义"不是实现细节，而是被下游当契约用——`Renderer.rakumod:51` 直接 `$v.rows.List`，`Eval.rakumod:496-497` 把 `columns/rows` 拆进 JSON 结果，`Arrow.rakumod:1081/1222/1390` 按 `.rows` 分块编码。

---

## 2. 46 个方法逐个可达性判定

共 **46** 个声明：公开 38（`head` 的 `Int`/`Range` 两个 multi 计 1）+ 私有 7 + `TWEAK` 1。
判定口径：**能否在"不把全表变成 Raku Hash"的前提下完成该方法的语义**。

### 2.1 可直接下推（语义不变，改动只在实现）

| # | 方法 | 行号 | 下推方式 | 备注 |
|---|---|---|---|---|
| 1 | `elems` | 88 | `count(*)` | 1M 行 9 ms |
| 2 | `count` | 188 | 同上 | 与 `elems` 重复实现，可合并 |
| 3 | `column-type` | 159 | 读列类型元数据 | 需在 `types` 与 DuckDB 类型间双向映射 |
| 4 | `schema` | 118 | `DESCRIBE` / `information_schema` | `nullable` 当前靠 `grep` 扫全列（:121-123），下推后口径来自 DDL，可能与"值里有 undef"不一致 |
| 5 | `limit` / `head(Int)` | 161 / 167 | `LIMIT` | |
| 6 | `head(Range)` | 170 | `LIMIT + OFFSET` | 依赖 `limit`+`offset`，两者都下推即可 |
| 7 | `offset` | 179 | `OFFSET` | |
| 8 | `first` | 353 | `LIMIT n` | 与 `head` 语义重复 |
| 9 | `batches` | 92 | `LIMIT/OFFSET` 分页 | 返回 `Seq of Table`，**每批仍物化**，只是把峰值摊薄 |
| 10 | `sql` | 339 | 本来就是 DuckDB | 变成原生调用，`Duck.rakumod:299-301` 的临时文件桥可删 |
| 11 | `html-escape` / `csv-cell` / `csv-header` / `csv-line` | 412 / 447 / 454 / 458 | 纯字符串函数 | 与存储无关，不碰属性 |

### 2.2 可下推但**语义会变**（需要逐条裁定是否接受）

| # | 方法 | 行号 | 当前语义（证据） | 下推后的偏差 |
|---|---|---|---|---|
| 12 | `where` | 314-317 | 接收**任意 Raku 闭包** `&pred`，`@!rows.grep(&pred)` | **无法通用翻译成 SQL**，见 §4.1。只有在闭包是"列比较字面量"时才能改写；`t/11-data-table.t` 就有 `where({ .<name> eq 'a.txt' })` |
| 13 | `sort-by` | 343-351 | `cmp` 比较、`undef → ''` | 变成**字符串序**：`'10' cmp '9'` 得 `'10' < '9'`；DuckDB 按列类型排序 → 数值列顺序不同，空值位置也不同（DuckDB 默认 `NULLS LAST`） |
| 14 | `distinct` | 224-236 | 按 `"\x[1F]"` 拼字符串键去重 | `1` 与 `"1"` 视为同一值；DuckDB 按类型比较 → 结果集可能变大 |
| 15 | `join` | 259-312 | 键是 `($r{$right-on} // '').Str`（:278、:285），**左表顺序保序**，`right/outer` 未命中追加到尾部（:301-305），重名列加 `:suffix`（:251-257） | DuckDB 不保证行序、不做字符串化键匹配；保序需要额外 `ORDER BY` 或行号列，`suffix` 规则要在 SQL 里复刻 |
| 16 | `sum/mean/min/max` | 204 / 209 / 214 / 219 | 走 `!numeric`（:192-202），能把 CSV 来源的 `"123"` 字符串也当数字 | 需要在 SQL 里复刻 `NUMERIC-LITERAL` 正则口径；纯 `CAST` 会在脏值上直接报错或丢行 |
| 17 | `describe` | 143-157 | `distinct` 用 `.unique`、`sample` 取前 N 个 distinct 值拼接 | `count(distinct)` 可下推；`sample` 的取值与顺序在 DuckDB 下不确定 → 输出文本会变 |
| 18 | `select` | 323-336 | 投影并重建 Hash | 语义等价，但当前 10 万行耗时 539 ms 主要花在**重建 Hash** 上——存储换了也省不掉 |
| 19 | `to-text` / `to-markdown` / `to-html` / `to-json` | 372 / 396 / 420 / 392 | 走 `!display-rows`（:104-109），受 `:max-rows` 限制 | 可下推为 `LIMIT`，但列宽计算（:376-382）仍需把展示行物化；有界，可接受 |
| 20 | `TWEAK` | 74-78 | 列名按首行 `keys.sort` 兜底 | 换成 DDL 后此逻辑失效，需在写入口处理 |

### 2.3 **不可下推**（必然物化，与存储无关）

| # | 方法 | 行号 | 原因 |
|---|---|---|---|
| 21 | `new` / `from-rows` | 14 / 80 | 构造即 ingest：把 Raku 值写入 DuckDB 本身是 O(n) 序列化。实测 10 万行 = 4.4 s（Arrow 编码），100 万行 = 47.4 s |
| 22 | `get` | 319-321 | 返回 `List`，O(n) 行值 |
| 23 | `each` | 184-186 | 接受任意闭包，逐行调用 |
| 24 | `to-csv` | 462-471 | 全量逐行输出（不带 `:max-rows`） |
| 25 | `gist` | 473 | 调 `to-text` → 见 19 的例外（无 `:max-rows` 时全量） |
| 26 | `join-columns` / `join-merge` | 251 / 265 | 纯列名规则 + 行合并，服务于 `join` 的内存实现；下推后成为 SQL 生成器的辅助函数 |
| 27 | 私有 `!infer-type` / `!normalize-rows` / `!cell` / `!row-limit` / `!display-rows` / `!truncation-note` / `!numeric` | 34 / 47 / 363 / 100 / 104 / 111 / 192 | 纯 Raku 值逻辑，只能留在写入口/展示层 |

**可达性汇总：可下推 11，语义会变 9，不可下推 7 类（含 7 个私有方法）。**
即：**约 22% 的方法能"无痛下推"，约 39% 会改变可观测行为**——这决定了任何"只加一层存储"的方案都做不到悄悄替换。

---

## 3. 三种候选方案比较

### 方案 A：每个变量一张 DuckDB 表（Table 持有 session + 表名）

每个 `Table` 对象内部持有 `{session, table-name}`，所有变换发 `CREATE TABLE ... AS SELECT`。

- 实现难度：中。46 个方法里 ~20 个改写，29 处 `@!rows` 全部替换。
- 致命问题：**每次变换产生一张新表**。REPL 里 `$t.where(..).select(..).sort-by(..)` 一格 3 张表；`Session.rakumod:194-195` 的会话快照只存"声明 + 纯值"，句柄型变量会落进 `@!restore-failed`，重启后大表全丢。
- 语义变化：排序、连接、去重、`describe` 全部走 §2.2 的偏差清单。

### 方案 B：单库多视图（每个 Table 是一个 `VIEW`）

变换发 `CREATE VIEW v_n AS SELECT ... FROM v_{n-1}`，视图可被优化器折叠，避免数据复制。

- 实现难度：中高。要管理视图名分配、引用计数、清理时机、跨格重放（`ALWAYS-REPLAY`，`Session.rakumod:1251-1259`）时的重名。
- 优点：变换零拷贝，多次链式调用的计划能被 DuckDB 整体优化。
- 缺点：视图绑定会话，`Session` 关闭即失效；一旦用户 `my $t2 = $t1` 共享视图，生命周期判断变复杂；行序仍不保证。

### 方案 C：双形态（小表行式 / 大表代理）+ 新增 lazy `DataFrame`

`Table` 保持现状不变；新增 `DataFrame`（或 `Dataset`）持有 DuckDB 句柄与惰性算子链，`collect(:$max-rows)` 才回 `Table`。

- 实现难度：中（新增类型 ≈ 400–600 行），**改动 Table 仅 2 个方法**（`to-dataset`、`Table.from(df)`），`Cl` 层无需感知。
- 语义变化：**零**——既有 24 个测试、34 处 `.rows` 读取全部不动。
- 与既有决策一致：`DESIGN-DATA-ENGINE.md:199` 原文即"后续可加 DataFrame 作为 lazy 层，但 Table 仍是结果交换格式"。

| 维度 | A 每变量一张表 | B 单视图链 | C 双形态 + DataFrame |
|---|---|---|---|
| 实现工作量 | 中（重写 20 方法 + 29 处 `@!rows`） | 中高（+ 视图生命周期） | 中（新增类型，Table 几乎不动） |
| 语义破坏 | 高（§2.2 全部 9 项） | 高 | 无 |
| 现有 24 个测试 | 大部分需改断言（顺序/类型） | 同 A | 全绿 |
| 大表计算收益 | 有，但每次 ingest 仍 4.4 s/10 万行 | 有（视图折叠后可近零成本） | 有（数据一次入池，后续查询 11–28 ms） |
| REPL 变量/快照 | 破坏（句柄不可序列化） | 破坏 | 兼容（Table 仍是纯值） |
| 依赖风险 | 全 shell 强依赖 libduckdb | 同 A | 隔离在 DataFrame，Table 零依赖 |

---

## 4. 关键障碍逐条分析

### 4.1 `where(&pred)` 无法翻译成 SQL（最硬的墙）

`Table.rakumod:314-317`：

```raku
method where(&pred --> Rakuish::Data::Table) {
    my @rows = @!rows.grep(&pred);
    ...
}
```

`&pred` 是任意 Raku 闭包，可访问外部词法变量、调用任意方法（`t/11-data-table.t` 用 `. <name> eq 'a.txt'`，`bench` 里用 `.<score> > 500`）。DuckDB 只能执行 SQL，闭包必须被**解释**或**回落到 Raku**。前者等于自研 Raku→SQL 编译器（`DESIGN-DATA-ENGINE.md:198` 已明确"第一版不做"），后者意味着"where 仍全量物化"，方案 A/B 的最大卖点当场失效。

### 4.2 `each` / `get` 返回行值

`each:184`、`get:319` 返回 `List`。实测把 10 万行从 DuckDB Frame 取成 Raku 值需 **2,272 ms**——比 Raku 自己的 `sum`（242 ms）还慢一个量级。**任何"取回行"的方法都把 DuckDB 的 9 ms 优势抹掉。**

### 4.3 类型映射：`any` 列在 DuckDB 里不存在

`!infer-type:34-45` 对混装列返回 `'any'`，`!normalize-rows:47-72` 不做类型转换。DuckDB 列必须单一类型。把 `Int` 与 `Str` 混装列塞进去的唯一办法是转成 `VARCHAR`，于是：

- `get('score')` 从 `(1, 2, 3)` 变成 `('1', '2', '3')`；
- `where({ .<score> > 0 })` 因字符串比较而报错或全假；
- `sum` 的 `!numeric` 正则还能兜住，但 `min/max` 返回 `Str`。

现成的妥协就在代码里：`Duck.rakumod:203-235` 的 `duck-ready` 把嵌套列**转成 JSON 文本**、类型记 `str`，并在注释里承认"不假装 DuckDB 能直接取结构体字段"。这是桥接层的合理取舍，但若把它变成 Table 的存储语义，就是把"可读的降级"固化成"默认行为"。

### 4.4 连接语义：字符串键 + 强制保序

`join:259-312` 用 `($r{$right-on} // '').Str` 作哈希键（:278、:285），且明确"**左表顺序保序**、未匹配行尾追加"（:297-305 注释亦写明 `left / outer` 的未匹配分支）。DuckDB 的 hash join 不保证输出顺序，`1` 与 `"1"` 也不会互相匹配。要等价就得加行序号列 + `ORDER BY`，等于把 Raku 的语义再实现一遍。

### 4.5 排序语义不同

`sort-by:343-351` 用 `cmp`，未定义值替换成 `''`。这是**字符串序**：`'10'` 排在 `'9'` 前。DuckDB 按列类型排，数值列结果不同，且默认 `NULLS LAST`。`t/11-data-table.t:31-32` 有 `sort-by` 正向/反向断言，会直接暴露。

### 4.6 可变性与公开可写属性

`@.columns is rw` / `@.rows is rw`（:10-11）。存在两种用法：外部直接读（34 处）与潜在的直接写（`@.columns is rw` 有意暴露）。一旦存储换成外部引擎，读写都要加同步逻辑；而 34 处读取点分布在 Display / Stream / Arrow / Cursor / Engine / Eval / Renderer / Pager / SqlComplete，逐一改造的回归面极大。

### 4.7 REPL 变量重绑定与快照

- **快照**：`Session.rakumod:194-195` 注释明确"快照只存**声明 + 纯值**"，并有 `@!restore-failed` 记录恢复失败的变量。DuckDB 句柄不是纯值 → 重启后所有大表变量丢失，用户感知为"表不见了"。
- **重绑定**：`my $t = $t.where(..)` 让旧 Table 变成 GC 垃圾，但 DuckDB 侧的表不会随之释放；REPL 一个会话几十格、每格几次变换，表数量线性膨胀，直到 `Session` 关闭。
- **重放**：`ALWAYS-REPLAY`（`Session.rakumod:1251-1259`）会在每格前置重放 `use` / `enum` 等声明；声明格里的 `CREATE TABLE` 若被重放会重复建表/重名冲突。

### 4.8 连接归属违反既有并发约束

`DESIGN-DATA-ENGINE.md:183-190` 已规定："每个 `Rakuish::Sys`/Session 持有一个连接，不要跨线程共享"、"连接随 Session 关闭；**不建全局连接池，不把 connection 放进 DSL 全局单例**"。让每个 Table 持有连接即与该约束冲突：Table 会跨越 DSL/Session/Worker 边界流动（`Eval.rakumod:496`、`Renderer:51` 都会把它序列化/传递）。MoarVM 的 GC 也不保证及时 `DESTROY`，临时表与临时文件泄漏风险真实存在。

### 4.9 错误抛出时机改变

今天 `where` / `join` 的错误在**调用点**抛（`X::Rakuish::Unsupported`，`Duck.rakumod` 与 `Data` 层均有抛出）。变成惰性后，错误会推迟到读取或 `collect` 时抛出，甚至被 `try` 吞掉后表现为"空表"。这属于用户可见的行为变化，且难以在测试里定位。

### 4.10 依赖门槛从"可选"变成"必需"

`Duck.rakumod:34-47` 的 `duck-session-class` 是**运行时** `require`，没装 Duckula 时抛 `X::Rakuish::Unsupported` 并给安装提示（:238-241 注释明确"不会在 `use` 阶段就把原生 libduckdb 拖进来"）。若 Table 需要 DuckDB 才能构造，则 `use Rakuish::Data::Table` 从零原生依赖变成需要 `libduckdb`；读写 `.arrow` 还要 `nanoarrow` 社区扩展（首次联网 INSTALL），且 `DB::DuckDB v2.0.0` 的 `arrow-available(:install)` 会误返回 `False`（项目已记录该探测 bug）。**shell 的基础数据结构不应该有一个原生可选依赖做底座。**

---

## 5. 性能预期与实测

### 5.1 Raku 侧（Table 当前实现）

| 操作 | 1 万行（推算） | **10 万行（实测）** | **100 万行（实测/推算）** |
|---|---|---|---|
| `from-rows` 建表 | ~60 ms | **643 ms** | 10,667 ms（CSV→Table 实测） |
| `where` | — | **164 ms** | ~1.6 s |
| `select` 2 列 | — | **539 ms** | ~5.4 s |
| `sort-by` | — | **1,800 ms** | ~18 s |
| `sum` | — | **242 ms** | **1,535 ms** |
| `join` 自连接（唯一键） | — | **2,249 ms** | 不可行（内存 + 复制） |
| `limit(20) + to-text` | — | **5 ms** | 5 ms（与行数无关） |

结论：**除 `limit/head/first` 外，所有算子都是超线性或线性全量**；`sum` 已是最轻的（242 ms/10 万），`join` 已到秒级。

### 5.2 DuckDB 侧（同一份数据）

| 操作 | 10 万行 | 100 万行 |
|---|---|---|
| `read_arrow`（文件→库内） | **276 ms** | **332 ms** |
| `count(*) where score > 500` | 9 ms | **11 ms** |
| `group by` + `sum` | — | **12 ms** |
| 自连接 `on id` | — | **28 ms** |
| `read_csv_auto` 直读 + 聚合（不经 Raku） | — | **309 ms** |

### 5.3 边界穿越成本（决定成败的数字）

`$t.sql('select count(*), sum(score) from t')` 在 10 万行上实测 **10,190 ms**，分解为：

| 阶段 | 耗时 | 说明 |
|---|---|---|
| Table → 临时 Arrow 文件（纯 Raku 编码） | **4,389 ms** | `Duck.rakumod:244-298` 的桥内 Arrow 写 |
| DuckDB `read_arrow` | 276 ms | |
| SQL 聚合 | **9 ms** | 真正的计算 |
| Frame 回传 | 5 ms | 惰性 |
| `Frame.rows` 取 10 万行 | **2,272 ms** | 物化成 Raku 行 |

**这就是全案的量化核心：DuckDB 计算 9 ms，而数据来回搬运 6.6 s。** 换句话说，只要每次调用都要"把表交给 DuckDB 再取回来"，方案 A 在 10 万行规模上是**净亏 40 倍**（对比 Raku `sum` 242 ms）。

### 5.4 是否真能解决"大数据量"

- **能解决的部分**：库内多次查询/聚合/连接——数据一次入池后，11–28 ms 完成 100 万行级计算，Raku 永远做不到。
- **不能解决的部分**：入池与出池。1 亿行时 Raku 侧连 `from-rows` 都建不起来，物化仍是硬墙。
- **因此真正的杠杆在"绕过物化"**：`read_csv_auto` 直读 100 万行 + 聚合 309 ms，比 Raku 物化（10,667 ms）快 **34×**，且完全不占 Raku 内存。这条路径不需要改造 Table 的存储，只需要一个"不经过 Table 的入口"。

---

## 6. 改造面清单

| 项目 | 规模 | 证据 |
|---|---|---|
| 核心模块 | **506 行 / 46 个方法声明** | `Table.rakumod` |
| 模块内 `@!rows` 直接依赖 | **29 处** | `Select-String '@!rows'` |
| 模块外 `.rows` 直接读取 | **34 处 / 15 个文件** | 见下表 |
| 引用 Table 的库文件 | **20 个** | `Data/Duck`、`Data/Cursor`、`Data/Stream`、`Data/Arrow`、`Data/Engine*`、`Data/Pager`、`Display`、`DSL`、`Data`、`Eval`、`Eval/Server`、`REPL/*`、`Result/Renderer`、`Sys*` |
| 依赖 Table 的测试 | **24 个 `.t`** | 密集：`t/11-data-table.t`、`t/25-describe-complete.t`、`t/76-duck-sql.t`、`t/77-arrow-write-batches.t`、`t/20-data-cursor.t`、`t/22-data-csv.t` |

模块外 `.rows` / `.columns` 读取点（改造时必须逐一确认）：

| 文件 | 行号 |
|---|---|
| `Data.rakumod` | 54, 67 |
| `Display.rakumod` | 315, 321, 330（HTML/records 渲染要全量 `rows`） |
| `Eval.rakumod` | 496, 497（把 rows 塞进返回 JSON） |
| `Data/Arrow.rakumod` | 1081, 1222, 1390（分块编码写侧） |
| `Data/Cursor.rakumod` | 39, 126 |
| `Data/Stream.rakumod` | 61, 63, 69, 144, 617, 618, 630, 631 |
| `Data/Engine.rakumod` | 49, 69, 76 |
| `Data/Duck.rakumod` | 205, 214, 222 |
| `Data/Pager.rakumod` | 20 |
| `Result/Renderer.rakumod` | 51 |
| `REPL/SqlComplete.rakumod` | 179, 204 |

> 关键判断：这 34 处**没有一处**能接受"代理表"——它们全都要求拿到具体行。这也是 §2.3 存在的原因。

---

## 7. 结论与建议

### 结论

| 问题 | 回答 |
|---|---|
| 技术上可行吗？ | 可行（DuckDB 已集成、类型映射已存在、`sql` 已下推），但**只有约 22% 的方法能无痛下推**，39% 会改变可观测行为。 |
| 值得做吗？ | **不值得，按现有目标不值得。** 用户痛点是"大数据量"，而方案把成本从 Raku 计算搬到了序列化（10 万行 +6.6 s），且在 `where(&pred)`、`each`、`get` 这些最常用的路径上收益为零。 |
| 会解决大数据量吗？ | 只解决"库内算"，不解决"进出库"。真正见效的是"数据不经过 Raku"。 |

### 推荐路线（分阶段）

**阶段 0（1–2 天，收益最大）——零拷贝直读入口**
在 `Data.rakumod` / `DSL` 增加 `open-lazy(path)`：CSV/Parquet 交给 DuckDB `read_csv_auto` / `read_parquet`，返回一个小结果 `Table`（`LIMIT :max-rows`）。
验收：100 万行 CSV 查询 < 500 ms（当前 `open-data` 物化 10,667 ms）；`t/*` 全绿。

**阶段 1（3–5 天）——`DataFrame` 惰性类型**
新增 `lib/Rakuish/Data/DataFrame.rakumod`：持有 `{session, query}`，算子 `where-sql / select / sort / join / group-by / agg` 均拼接而非执行；`collect(:$max-rows)` 回 `Table`；`close` / `DESTROY` 释放。
验收：`df.where-sql(...).group-by('grp').sum('score').collect` 在 1000 万行上 < 1 s，且 Raku 内存不随行数增长。

**阶段 2（半天）——Table 只加桥**
`Table.to-dataset` / `Table.from(dataframe)`；**不改** `@.rows`、不改任何现有方法。24 个测试无需改动。

**阶段 3（可选，仅在确有必要时）——收敛 `where` 语法子集**
若确实想让 `Table.where` 走 DuckDB，唯一可行方向是**新增谓词 DSL**（如 `where-cols(score: { .> 500 })`）而非解释闭包；这是新 API，不是替换存储。

### 不做的事

- 不让 `Table` 持有连接或表名（违反 `DESIGN-DATA-ENGINE.md:183-190`）；不改 `@.rows` 契约（34 处消费点 + 24 个测试）；不把 `where(&pred)` 私下回落到"先物化再 grep"（会造成"看起来下推了其实没有"的性能谎言）。

---

## 附：复现方式

```raku
# 10 万行基线（各算子）
my $t = Rakuish::Data::Table.from-rows(@rows, :columns(<id grp score>),
        :types({ id => 'int', grp => 'str', score => 'num' }));
$t.where({ .<score> > 500 });  $t.sum('score');  $t.sort-by('score');
$t.join($t, :on('id'), :how('inner'));  $t.sql('select count(*), sum(score) from t');

# 边界成本分解
Rakuish::Data::Arrow::write-ipc-file($t, $path);        # 4,389 ms / 10 万行
$sess.read-arrow($path, :name('t'));                     #   276 ms
$sess.sql('select count(*) from t').rows.List;           # 2,272 ms（含物化）

# 100 万行直读对比
$sess.sql("select count(*), sum(score) from read_csv_auto('bench1m.csv')");  # 309 ms
```

实测脚本位于会话中间产物目录：`temp/bench2_*.raku`、`temp/bench4_*.raku`、`temp/bench5_*.raku`、`temp/bench6_*.raku`。
*（内容由AI生成，仅供参考）*
*（内容由AI生成，仅供参考）*
