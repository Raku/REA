# ADR-0065：Session 拆分第六步 —— 补全层与「私有方法也是复合面」

- 状态：已实施（0.151.0 / SPEC V-355）
- 相关：ADR-0060（属性归属规则）、ADR-0062（EVAL 的词法包）、ADR-0064（窄入口规则）、SPEC §3.84、`t/89-completion-split.t`、行为回归 `t/10` / `t/23` / `t/25` / `t/63`
- 取证方式：区间内 / 区间外引用计数 + 运行时夹具（`t/89`）+ 全套件

## 1. 背景

0.150.0（ADR-0064）把 `Session.rakumod` 压到 2,868 行。当时留下的两个候选里，用户选了补全簇（另一候选是渲染辅助 `!fmt` / `!render-bytes` / `!render-path-list`，被 `render` 大量调用，切起来更碎）。

补全是一条完整的管线，不是一个函数：

```
completions(line, pos)                       # 公开 API：CLI 的 get-completions 回调
  ├─ in-out-completions(...)                 # In[n] / Out[n] 引用（纯函数，REPL::Complete）
  ├─ !method-completions                     # `$obj.` / `Type::Name.`
  │    ├─ method-context / method-names      # 纯函数（REPL::Methods）
  │    ├─ !completion-value                  # 变量 / Out[n] / 类型名 → 值
  │    └─ !resolve-type                      # 重放声明 + EVAL + 缓存
  ├─ sql-completions(...)                    # SQL 上下文（纯函数，REPL::SqlComplete）
  └─ !session-name-completions               # 变量 / sub / class / 模块名
       + $.shell.completions                 # Shell 命令 / 路径
```

结果：`Session.rakumod` **2,868 → 2,679 行**（17 insertions / 203 deletions，含 7 行接线），新文件 `Completion.rakumod` **225 行**（含注释头 20 行）/ 5 个方法。

## 2. 为什么这一簇：一条管线，一个出口

`completions` 是唯一对外的入口（CLI 的 `get-completions` 回调、`Terminal::LineEditor` 的 Tab、`t/10` / `t/23` / `t/25` / `t/63` 都只调它）。内部四个方法互相调用成一条链，朝外的边只有三类：

| 依赖 | 区间内 | 区间外 | 结论 |
|---|---|---|---|
| `@.out` | 4 | 多 | 已是公开属性 |
| `@.history` | 1 | 多 | 已是公开属性 |
| `@.decls` | 7 | 多 | 已是公开属性 |
| `%.state` | 4 | 多 | 已是公开属性 |
| `$.shell` / `$.engine` | 1 / 1 | 多 | 早已公开 |
| `%!type-cache` | 3 | 1（新 use 时清空） | 仍私有 → 活容器入口 |
| `EVAL` | 1（`!resolve-type`） | — | 走 Session 的 `!eval-in-session` |
| `error-marks` / `!known-name` / `!path-names` | 0 | 定义在区间外 | **不搬**（见 §5） |

## 3. 决定性观察：私有方法也是「复合面」

前几刀的经验是「属性必须公开成访问器，role 才读得到」。这一刀只需要**一个**新入口，而且它不必是属性：

```raku
method !type-cache(--> Hash) { %!type-cache }     # Session 里，带 `!`
```

role 里 `my %cache := self!type-cache;` 绑定同一个 Hash 容器，读写都落到 Session 的属性上。

关键点是：`!type-cache` 是**私有**方法，所以它不扩大公开 API，也不需要 `is rw`、不需要改名冲突检查（不像 0.148.0 的 `%.restored-info`）。ADR-0064 的规则「公开与否看外部是否该看见」由此再进一步：

> **role 需要的是「能读写那块状态」，不是「那块状态对用户可见」。** 私有方法完全够用，而且比公开属性便宜：不进 API、不留兼容包袱。

这条与 ADR-0064 的三个窄入口（`!set-prefill` 等）是同一条思路 —— 那里窄入口是为了**写**，这里活容器入口是为了**读+写**（缓存要 `:exists` / 读 / 写三种操作，包成三个方法不如一个容器自然）。

## 4. 决定

1. 新增 `lib/Rakuish/REPL/Session/Completion.rakumod`：`unit role Rakuish::REPL::Session::Completion;`，5 个方法 / 225 行。
   自己 `use Rakuish::REPL::Complete;`（`common-prefix` / `in-out-completions`）、`use Rakuish::REPL::Methods;`（`method-context` / `method-names` / `filter-names`）、`use Rakuish::REPL::SqlComplete;`（`sql-completions`）—— Session 的 `use` 不泄漏进 role（ADR-0063 §3 的教训）。
2. `Session` 改 `unit class ... does ...Commands does ...Config does ...Diagnostics does ...Persistence does ...Cells does ...Replay does ...Completion;`，第七条 `use` 写在 `unit` 之前。
3. 状态：**零新增公开面**。`@.out` / `@.history` / `@.decls` / `%.state` / `$.shell` / `$.engine` 都已在更早的刀里公开。`%!type-cache` 仍私有，新增私有方法 `!type-cache(--> Hash)` 返回活容器。
4. `!resolve-type` 的 EVAL 改走 `self!eval-in-session(...)`（ADR-0062 §3 的硬约束）。虽然这里只解析类型名、不做快照 `.raku` 前缀剥离，但保持「role 不 EVAL」一条线，免得下次有人以为是可选项。
5. `META6.json` provides 53 → 54。
6. 留在 Session：`error-marks` / `!known-name` / `!path-names`。它们服务于**错误态标红**（`Highlight.error-marks` 的回调注入），只是碰巧也读 `@.decls` / `%.state`。按调用闭包它们更靠近高亮层，不该塞进补全 role。

## 5. 没采用的方案

- **把 `!known-name` / `!path-names` 一起搬进补全 role。** 名字解析看起来同源，实际调用方是 `error-marks`；搬进去等于让「补全」拥有「标红」的状态，耦合换方向。`%path-names-cache` 还是文件级 `my`（不是属性），搬过去会让 role 文件里出现与补全无关的 PATH 扫描。
- **公开 `%!type-cache`。** 它是纯缓存（约 4 ms/次，新 `use` 整块作废），对用户没有任何意义；公开后还得解释「为什么它会自己变空」。
- **把 `completions` 留在 Session 当薄壳，只搬内部四个方法。** 那样 Session 里会留一个 3 行转发方法，收益为零（role 反正要组合），还多一处「为什么这里有个转发」。
- **在 role 里直接 EVAL。** §4.4 的理由：能跑通，但破坏「role 不 EVAL」的一致性；下次有人照抄就会踩 ADR-0062 §3 的坑。

## 6. 不变量

- `Session.rakumod` < 2,750 行；Completion 恰好含 `completions` + 四个内部方法，不含 `error-marks` / `!known-name` / `!path-names`。
- Completion 里没有任何类私有属性引用；EVAL 只经 `self!eval-in-session`。
- `%!type-cache` 仍是 Session 的私有属性；新 `use` 时清空的那句仍在 Session。
- 七条 `does` 与七条 `use` 都在；`META6.json` 有 Completion 条目（provides 54）。
- 行为：`completions` 的返回形状与优先级（In/Out → 方法 → SQL → 会话名字 + Shell → 公共前缀）完全不变。

## 7. 结构守卫清单（`t/89-completion-split.t`，51 条）

1. 文件都在；`unit role ...::Completion` 头正确；Session 的七条 `does` 与 `use` 都在。
2. **反方向**：`completions` / `!session-name-completions` / `!method-completions` / `!completion-value` / `!resolve-type` 不在 Session，而在 Completion。
3. `error-marks` / `!known-name` / `!path-names` 留在 Session，不在 role。
4. 类型缓存：`has %!type-cache;` 仍在 Session；`!type-cache(--> Hash)` 在 Session；role 经 `self!type-cache` 读它；`%!type-cache = %()` 仍在 Session。
5. role 零 `$!` / `@!` / `%!` / `&!` 引用；无裸 `EVAL "`；三个 `use` 都在。
6. 规模：`< 2,750` 且 `> 2,600`（后者防空跑 —— 文件被截断时行数也会变小）。
7. `META6.json` provides 有 Completion。
8. 运行时：内置例程 `pri → print`；会话变量 `$ali → $alice`；数组 / `&sub` 带 sigil；`use JSON` → `use JSON::Fast`；`Box.` 出 `Box.hi` 与 `Box.clone`（整条 `!method-completions → !completion-value → !resolve-type` 链）；`Out[1]` / `In[1]` 两种引用补全；空行返回 List。

## 8. 下一步

- 剩下的候选：渲染辅助（`!fmt` / `!render-bytes` / `!render-path-list`，约 166 行）—— 它们被 `render` 与诊断 role 大量调用，切出来是「反向依赖」（role 被 Session 和 Diagnostics 同时调），收益要看会不会带出 `$!color` / `$!width` / `$!tty` 的公开面。
- 不再建议按「行数最多」选刀，而按**调用闭包**选：闭合度高的一刀 diff 可读、回归面小；闭合度低的即使行数多，也会以「一堆访问器 + 反向调用」的形式把复杂度还回来。
- 目前 Session 2,679 行 / 6 个 role（Commands 49 + Config 295 + Diagnostics 437 + Persistence 417 + Cells 182 + Replay 267 + Completion 225）。累计 4,304 → 2,679（−38%）。
