# ADR-0053 · 跨会话变量库：`store`

- 状态：已实施（0.139.0 / V-343）
- 日期：2026-11-26
- 相关：[ADR-0022](ADR-0022-session-snapshot.md)（会话快照的判定边界）、
  [ADR-0052](ADR-0052-block-input-paste.md)（同期新增的另一个会话命令）、
  SPEC §3.72

## 1. 背景

评审（`docs/REVIEW-VS-IPYTHON-2026-11-24.md` P2.6）指出 IPython 的 `%store`
是「跨会话的轻量持久化」：`%store x` 把变量 pickle 进 profile 目录，
换个会话 `%store -r x` 拿回来。Rakuish 有一套**每格自动**的快照
（[ADR-0022](ADR-0022-session-snapshot.md)，`session-<cwd 指纹>.json`），
但没有「点名导出到一份共享库」的能力 —— 快照按 cwd 分文件、整体覆盖、
且从不问用户想留什么。

两个需求因此对不上：快照要的是「崩溃后还能接着干」，`%store` 要的是
「我只要这一个值，下个项目里也要用」。

## 2. 决定

新增会话命令 `store`：

```
store $x @rows %cfg     # 保存点名的变量
store -l                # 库里有什么
store -r x              # 读回（名字不带 sigil 时按 $ @ % & 找唯一匹配）
store -d x              # 删掉
store --clear           # 清空
store -f 路径 ...       # 换一个库文件
```

- 默认库路径 `$*HOME/.rakuish/store.json`（`RAKUISH_STORE` 覆盖）；
  **故意不按 cwd 分文件** —— 跨目录可用正是它与快照的分工差别。
- 值是 `.raku` 表示（快照用同一套）。可序列化的判定**直接复用**
  `Rakuish::Snapshot::classify`：闭包 / 资源（连接、句柄、进程、锁）/
  超过单值上限（`RAKUISH_SNAPSHOT_MAX`）一律拒绝。
- 信封独立于快照：`{ "store-version": 1, "saved-at": …, "vars": { … } }`，
  版本号与快照版本**故意不绑**（快照改结构不该让库文件失效）。
- 落盘复用 `Rakuish::Snapshot::save`（先写 `.tmp` 再 rename；POSIX 收紧到 600）。

## 3. 为什么是「拒绝」而不是快照那套「标记失效」

快照每格自动跑，一个闭包不能让它整体失败，也不能因此让每格的耗时抖动，
所以 `classify` 把不可序列化的值记为 `invalid`，恢复时填 `Any` 并在
摘要里报告 —— 这是对的取舍。

`store` 相反：用户**点了名**。悄悄跳过、只留一句「有 1 个变量没存」，
用户下次 `store -r` 会拿到一个 `Any` 还以为是自己的数据。所以这里
拒绝整个操作、把 `classify` 给出的理由原样报出来（`closure（代码对象
无法反序列化）` / `resource（连接/句柄/进程/锁…）` / `值过大（N 字符 > M）`）。

## 4. 条目里为什么要带声明

值的 `.raku` 是 `Rakuish::REPL::Session::Pt.new(x => 3)`，而用户写的是
`my class Pt { … }`。换一个会话直接 `EVAL` 那段 repr 会「找不到类型」——
快照恢复早就踩过这个坑（ADR-0022 §4：`.raku` 带着本会话包名前缀，
恢复时要剥掉，并让声明与值在**同一个 EVAL 块**里）。

`store` 的做法是：保存时把「这个值可能用到的声明」一起存进条目
（名字等于类型的短名，或 repr 里出现 `::<声明名>.` 的），读回时把
条目声明与本会话声明拼成 prelude，连同剥掉包名前缀的 repr 一次 EVAL。
`enum` / `subset` / `constant` 这类裸声明在重放前补 `my`（0.132.1 / V-334
的同一条规则）—— 否则第二次 EVAL 会把会话锁死。

## 5. 边界

- 不是安全边界：库文件里有值（可能有凭据），所以 POSIX 上 600；
  但它不做加密，也不隔离不同用户。
- 不同步、不合并：后写覆盖先写；`-f` 换文件就是换一个库，不做迁移。
- 不存语句格、不存 `Out[n]`、不存 `_`：只存 `%!state` 里点名的变量。
- 引擎 / notebook 模式下可用（不读 stdin，与 `paste` 不同）。
- 名字解析不做拼写建议：不带 sigil 且两个 sigil 都命中时报
  「名字不唯一」，而不是替他挑一个。

## 6. 测试

`t/81-store.t` 54 条断言：保存 / 列表 / 空库 / 无 sigil 解析 / 不唯一 /
不存在 / 闭包 / `Channel` / 超限（`RAKUISH_SNAPSHOT_MAX` 临时调小）/
跨会话读回标量·数组·哈希·用户类实例 / 覆盖 / 删除 / 清空 /
未知选项 / 模式冲突 / `-l` 带名字 / 空名单 / `-f` 换文件不动默认库；
`t/37` 守着命令表与 usage 的双向一致。
