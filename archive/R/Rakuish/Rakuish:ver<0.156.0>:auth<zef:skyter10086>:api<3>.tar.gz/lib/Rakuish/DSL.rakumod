unit module Rakuish::DSL;

# Rakuish::DSL —— 给 REPL 与脚本用的短命令（ADR-0001 §2.3 / 设计 §5）。
#
# 这些是**普通 Raku sub**，不是 magic、不是 bash 内建：
#   · 返回值是真值（IO::Path / Stat / Result / List），可赋值、可 .grep/.map、
#     可 && 短路、可写进脚本，不需要解析文本行；
#   · 扩展方式就是 Raku 本身：写个 sub、use 一个模块，无需改任何 given 分支
#     或 help 表（文件末尾的 `recent` 就是一个示范）；
#   · 全部委托给会话级 Sys，不直接碰文件 / 进程，root 校验与审计不会漏。
#
# REPL 里还可以直接写 `sys.read(...)` / `repl.history`：由 V3 REPL 在 EVAL
# 上下文注入 `my \sys` / `my \repl` 无 sigil 绑定（实测 EVAL 可见）。

use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Command;
use Rakuish::REPL::Shell;      # 0.132.0：help() 与文本 help 共用命令表
use Rakuish::Display;          # 0.124.0：display() / 包装类型（ADR-0048）
use JSON::Fast;
need Rakuish::Data;
need Rakuish::Data::Table;
need Rakuish::Data::Stream;
need Rakuish::Data::Engine::DuckDB;
need Rakuish::Data::Engine::SQLite;

my $SESSION;
my $REGISTRY;

# 由 V3 REPL 的 Session 在构造时调用；脚本可自行 bind-session($sys)。
our sub bind-session(Rakuish::Sys $s --> Rakuish::Sys) is export {
    $SESSION = $s;
    $s
}

our sub session(--> Rakuish::Sys) is export {
    # Session 求值时会绑定动态 $*RAKUISH-SYS；脚本/裸用时回退到 bind-session。
    my $s = $*RAKUISH-SYS // $SESSION;
    return $s if $s.defined;
    X::Rakuish::Unsupported.new(
        :detail('DSL 尚未绑定 Sys：先 bind-session($sys)，或用 Rakuish::REPL::Session 启动')
    ).throw
}

our sub commands(--> CommandRegistry) is export {
    # 0.132.0 / §4.6：REPL 求值时注入会话 registry（Session 里的
    # `$*RAKUISH-COMMANDS`），插件注册的命令因此也进 help()；纯脚本没有
    # 注入时回退到模块级默认表。
    my $reg = $*RAKUISH-COMMANDS;
    return $reg if $reg.defined;
    $REGISTRY //= default-registry()
}

# 0.132.0 / §4.6：help() 与文本 `help` 共用 Shell 的 COMMAND-GROUPS ——
# 以前 help() 只出注册表里的 13 条，文本 `help` 出 60+ 条，是两套影子 API。
our sub help(Bool :$api = False --> List) is export {
    my $reg = commands();
    my %groups = ::Rakuish::REPL::Shell.command-groups;
    my @names = $api
        ?? %groups<api>.List
        !! (|%groups<shell>, |%groups<session>, |%groups<api>).List;
    # 会话 registry 里额外注册的（插件 / 用户命令）也要出现。
    @names = (|@names, |$reg.names.grep({ !($_ (elem) @names) })).List
        unless $api;
    my @specs;
    for @names -> $n {
        my $c = $reg.get($n);
        if $c.defined {
            @specs.push($c.spec);
            next;
        }
        @specs.push(CommandSpec.new(
            :name($n),
            :summary(::Rakuish::REPL::Shell.command-summary($n)),
        ));
    }
    @specs.List;
}

# ── 文件 / 目录 ──────────────────────────────────────────────────────
our sub ls(|c)     is export { session().ls(|c) }
our sub ls-table(|c) is export { session().ls-table(|c) }
our sub read(|c)   is export { session().read(|c) }
our sub cat(|c)    is export { session().read(|c) }
our sub echo(*@args) is export { @args.join(' ') }

our sub open-data($path, Bool :$raw = False,
                  Bool :$allow-external = False,
                  :%csv-options = {}) is export {
    Rakuish::Data::open-data(session(), $path.Str, :$raw,
                             :$allow-external, :%csv-options);
}

# 0.91.0 / ADR-0026：结构化管道的入口。传入什么就按什么取记录：
#   · Str / IO::Path → 文本解析（:format 决定 lines / csv / tsv / json / jsonl / pattern）
#   · Result（`!` 的输出）→ 按行
#   · Table / Cursor / Positional / Hash → 直接展开成记录流
# 其余的格式选项只对文本有意义；对值传了就是调用方写错了，直接忽略会掩盖 bug，
# 所以这里只在文本分支接受它们。
our sub stream($x, Str :$format = '', Regex :$pattern, :@names,
               :%csv-options = {} --> Rakuish::Data::Stream) is export {
    if $x ~~ Str | IO::Path {
        return Rakuish::Data::Stream.from($x, :$format, :$pattern,
                                          :@names, :%csv-options);
    }
    Rakuish::Data::Stream.from($x);
}
our sub save-data($path, $value, Bool :$pretty = True,
                  Bool :$allow-external = False,
                  Int :$batch-size,
                  :%csv-options = {}) is export {
    Rakuish::Data::save-data(session(), $path.Str, $value, :$pretty,
                             :$allow-external, :$batch-size, :%csv-options);
}

# 0.120.0 / V-315：SQL 的短命令形态。
#   sql($t, 'select ... from t')             单表（表名默认 t）
#   sql({ a => $t1, b => $t2 }, 'select ...') 多表，键就是 SQL 里的表名
# 底层都是 Rakuish::Data::Duck：Table → 临时 Arrow IPC → Duckula → Table。
# 用 require 而不是 use：Duckula 是可选依赖，没装时不该在加载 DSL 时就炸。
# 不叫 `query`：`query(sql => '...')` 这种具名参数形态在引擎侧已有约定，
# 抢这个名字会把「少传一个参数」变成看不懂的错误。
our sub sql($source, Str $query, Str :$name = 't') is export {
    require Rakuish::Data::Duck;
    if $source ~~ Rakuish::Data::Table {
        return Rakuish::Data::Duck::table-sql($source, $query, :$name);
    }
    if $source ~~ Associative {
        return Rakuish::Data::Duck::query($source.Hash, $query);
    }
    X::Rakuish::Data.new(
        :detail('sql 的第一个参数要是 Table，或 名字 => Table 的 Hash')
    ).throw;
}

# 0.69 / ADR-0006 §3：describe 是值 API —— Table 走纯值摘要，表名走会话
# Engine 的元数据摘要；两者都返回 Table，可继续组合。脚本里没有 REPL 会话时
# 表名形态明确报错，不静默返回空表。
our sub describe($value, Int :$sample = 3) is export {
    return $value.describe(:$sample) if $value ~~ Rakuish::Data::Table;
    if $value ~~ Str {
        my $sess = try { $*RAKUISH-SESSION };
        my $engine = $sess.defined ?? (try { $sess.engine }) !! Nil;
        X::Rakuish::Unsupported.new(
            :detail('describe 表名需要先在 REPL 里 open-db(...) 注册会话 Engine')
        ).throw unless $engine.defined;
        return $engine.describe($value.Str, :$sample);
    }
    X::Rakuish::Unsupported.new(
        :detail('describe 只接受 Table 值，或已注册 Engine 的表名')
    ).throw;
}

our sub open-db($path = ':memory:', Str :$engine = 'duckdb',
                Bool :$read-only = True, Bool :$safe = True) is export {
    my Str $p = $path eq ':memory:'
        ?? ':memory:'
        !! session().resolve($path.Str).Str;
    my $e;
    given $engine.lc {
        when 'sqlite' {
            $e = Rakuish::Data::Engine::SQLite.new(:path($p), :$read-only, :$safe);
        }
        when 'duckdb' {
            $e = Rakuish::Data::Engine::DuckDB.new(:path($p), :$read-only, :$safe);
        }
        default {
            X::Rakuish::Unsupported.new(
                :detail("未知数据引擎: {$engine}（可选 duckdb / sqlite）")
            ).throw;
        }
    }
    # 注册为当前会话 Engine，供 SQL 上下文补全读取 tables()/schema() 元数据
    # （ADR-0005 §3）。脚本 / 非 REPL 场景没有这个动态变量，try 安静跳过。
    try { $*RAKUISH-SESSION.set-engine($e) };
    $e
}
our sub peach(@items, &code, Int :$degree = 4) is export {
    @items.hyper(:degree(($degree max 1)), :batch(1)).map(&code).List;
}

our sub write(|c)  is export { session().write(|c) }
our sub append(|c) is export { session().append(|c) }
# 0.105.0：with-lock(路径, { ... }) —— 劝告锁，异常/正常都自动解锁
our sub with-lock(|c) is export { session().with-lock(|c) }
our sub stat(|c)   is export { session().stat(|c) }
our sub rm(|c)     is export { session().rm(|c) }
our sub cp(|c)     is export { session().cp(|c) }
our sub mv(|c)     is export { session().mv(|c) }
our sub mkdir(|c)  is export { session().mkdir(|c) }
our sub glob(|c)   is export { session().glob(|c) }

# ── 进程（argv-only）─────────────────────────────────────────────────
our sub exec(|c)   is export { session().exec(|c) }
# 0.70 / ADR-0007：显式 TTY 直通，用于嵌套 REPL / 编辑器。
our sub tty-exec(|c) is export { session().tty-exec(|c) }
# PTY 捕获：子进程看到终端，调用方拿回输出；与 tty-exec 的“直通”不同。
our sub pty-exec(|c) is export { session().pty-exec(|c) }

# 0.96.0 / ADR-0031：TTY 后台作业（POSIX-only）。不是 shell 语法，是普通
# Raku 函数 —— 不碰 V-901。与上面的 spawn()/jobs()（捕获式后台）分工：
# bg-exec 起真终端作业并立即返回 job id，fg/bg 切换，bg-jobs 列表。
# 引擎里这些函数经 Sys.job-dispatch 转到持有终端的父进程。
our sub bg-exec(|c) is export { session().job-op('bg-exec', |c) }
our sub fg(|c)      is export { session().job-op('fg', |c) }
our sub bg(|c)      is export { session().job-op('bg', |c) }
our sub bg-jobs(|c) is export { session().job-op('bg-jobs', |c) }

# ── shell 文本 → 结构化值：给 `==>` / 方法链用的桥 ───────────────────
our sub cmd-result(Str $line) is export {
    my $repl = $*RAKUISH-SESSION;
    X::Rakuish::Unsupported.new(
        :detail('cmd 只在 Rakuish REPL/绑定了 REPL Session 的脚本里可用')
    ).throw unless $repl.defined;
    $repl.eval-line($line);
}

our sub cmd(Str $line) is export {
    my $r = cmd-result($line);
    X::Rakuish::CommandFailed.new(
        :result($r), :detail("cmd 失败: {$r.err.chomp}")
    ).throw unless $r.ok;
    $r.value;
}

# ── 会话状态 ─────────────────────────────────────────────────────────
our sub cd(|c)          is export { session().cd(|c) }
our sub pwd(--> Str)    is export { session().cwd.Str }
our sub cwd(--> IO::Path) is export { session().cwd }
our sub resolve(|c)     is export { session().resolve(|c) }
our sub env(--> Hash)   is export { session().env }
our sub get-env($k)     is export { session().get-env($k) }
our sub set-env($k, $v) is export { session().set-env($k, $v) }
our sub unset-env($k)   is export { session().unset-env($k) }
our sub try-op($op, &b) is export { session().try-op($op, &b) }

# ── 计时：%time 的 Raku 原生替代（普通 sub，返回可组合的 Result）──────
# 不是 magic、不是文本命令：返回值和耗时都是结构化值，能被赋值 / .grep /
# .<mean> / 写进脚本。timed 保留原语义，:repeat(N) 连跑 N 次取总耗时。
our sub timed(&body, Int :$repeat = 1 --> Result) is export {
    my Int $n = $repeat max 1;
    my Instant $t0 = now;
    my $v;
    $v = body() for ^$n;
    Result.new(:ok, :value($v), :op<timed>, :elapsed(now - $t0))
}

# bench 逐次计时，给 min / mean / max；value 是 Hash，可继续 .<mean>。
our sub bench(&body, Int :$repeat = 5 --> Result) is export {
    my Int $n = $repeat max 1;
    my Instant $t0 = now;
    my @secs;
    my $v;
    for ^$n {
        my Instant $s = now;
        $v = body();
        @secs.push((now - $s).Num);
    }
    my $total = (now - $t0).Num;
    my %stat = repeat => $n,
               min    => @secs.min,
               max    => @secs.max,
               mean   => (@secs.sum / @secs.elems),
               total  => $total,
               value  => $v;
    my Str $text = sprintf(
        '%d 次 · min %.2f ms · mean %.2f ms · max %.2f ms · 总 %.2f ms',
        $n, @secs.min * 1000, (@secs.sum / @secs.elems) * 1000,
        @secs.max * 1000, $total * 1000);
    Result.new(:ok, :value(%stat), :op<bench>, :out($text),
               :elapsed(Duration.new($total)))
}

# ── 示范：用户自己加一个「常用命令」────────────────────────────────
# 这正是「内建 / magic 更方便」的正确形态：一个普通 sub，返回 List[IO::Path]，
# 可被 .map / .grep / 赋值 / 写进脚本，无需注册到任何命令表。
# modified 取不到时如实跳过（Windows 上可能不可靠，不编造 1970 假时间）。
our sub recent(Int $days = 7, Str $ext = 'md', :$path = '.' --> List) is export {
    my $sys = session();
    my @files = $sys.ls($path, :recursive).grep({ .f && .extension eq $ext });

    # Windows 上 IO::Path.modified 可能返回不可靠的 Instant（实测开发期拿到
    # Instant.from-posix(-8.2)，约 1969 年，ADR §3 已记录）。如实降级：时间源
    # 不可信时返回全量匹配，不编造时间，也不假装「最近」真的算过。
    my $y2k = Instant.from-posix(946684800);
    my @hits;
    for @files -> $f {
        my $m = try { $sys.stat($f).modified };
        return @files.List unless $m.defined && $m >= $y2k;
        @hits.push($f) if (now - $m) < $days * 86400;
    }
    @hits.List
}

# ── 显示协议：display() 与三个包装类型（0.124.0 / ADR-0048 P1）──────
# 这是 IPython `display()` / `HTML` / `Markdown` / `JSON` 的 Raku 对应物。
# 协议本身在 Rakuish::Display：值实现 `method to-mime(--> Hash)` 即可自渲染，
# 优先级高于内置类型分派。这里只提供入口与最常用的三个包装。

# HTML 的终端降级：去标签 + 解实体 + 压空白（够读，不假装是渲染）。
my sub strip-html-tags(Str $s --> Str) {
    my Str $t = $s;
    $t = $t.subst(:g, /'<script' .*? '<\/script>'/, ' ', :i);
    $t = $t.subst(:g, /'<style'  .*? '<\/style>'/,  ' ', :i);
    $t = $t.subst(:g, /'<' <-[>]>* '>'/, ' ');
    $t = $t.subst(:g, /'&nbsp;'/, ' ');
    $t = $t.subst(:g, /'&lt;'/, '<');
    $t = $t.subst(:g, /'&gt;'/, '>');
    $t = $t.subst(:g, /'&amp;'/, '&');
    $t = $t.subst(:g, /\s+/, ' ').trim;
    $t
}

our class HTML is export {
    has Str $.text is required;
    multi method new(Str $text) { self.bless(:$text) }
    method Str(--> Str)        { strip-html-tags($!text) }
    method gist(--> Str)       { self.Str }
    method to-mime(--> Hash)   { %('text/html' => $!text, 'text/plain' => self.Str) }
}

our class Markdown is export {
    has Str $.text is required;
    multi method new(Str $text) { self.bless(:$text) }
    method Str(--> Str)        { $!text }
    method gist(--> Str)       { $!text }
    method to-mime(--> Hash)   { %('text/markdown' => $!text, 'text/plain' => $!text) }
}

our class JSON is export {
    has Mu $.value is required;
    multi method new($value)   { self.bless(:$value) }
    method Str(--> Str)        { to-json($!value, :pretty) }
    method gist(--> Str)       { self.Str }
    method to-mime(--> Hash)   {
        %('application/json' => to-json($!value, :!pretty),
          'text/plain'       => to-json($!value, :pretty))
    }
}

# ── 0.132.0 / ADR-0048 P1.1 收尾：富媒体薄包装 ──────────────────────
# 评审 P1.1 说"FORMATS 扩到 svg/png/latex/js"，HTML/Markdown/JSON 在 0.124.0
# 已有，这四个是收尾。与前三个保持同一形状：带 .to-mime + text/plain 降级，
# 终端里能看懂但不假装渲染；notebook 直接拿 MIME 档用。

our class SVG is export {
    has Str $.text is required;
    multi method new(Str $text) { self.bless(:$text) }
    method Str(--> Str)        { $!text }
    method gist(--> Str)       { "<svg>（{$!text.chars} 字节，用 HTML 前端渲染）" }
    method to-mime(--> Hash)   { %('image/svg+xml' => $!text, 'text/plain' => self.gist) }
}

# PNG：接收**已编码的 base64 字符串**。zef install Base64 后用户可
# `PNG(encode-base64($buf))`；不在这里硬拉新依赖 —— 薄包装不该引入安装链。
our class PNG is export {
    has Str $.base64 is required;
    multi method new(Str $base64) { self.bless(:$base64) }
    method Str(--> Str)          { "<png image, {$!base64.chars} base64 chars>" }
    method gist(--> Str)         { self.Str }
    method to-mime(--> Hash)     { %('image/png' => $!base64, 'text/plain' => self.Str) }
}

our class Latex is export {
    has Str $.text is required;
    multi method new(Str $text) { self.bless(:$text) }
    method Str(--> Str)        { $!text }
    method gist(--> Str)       { $!text }
    method to-mime(--> Hash)   { %('text/latex' => $!text, 'text/plain' => $!text) }
}

our class JS is export {
    has Str $.text is required;
    multi method new(Str $text) { self.bless(:$text) }
    method Str(--> Str)        { "<javascript block, {$!text.chars} chars>" }
    method gist(--> Str)       { self.Str }
    method to-mime(--> Hash)   { %('application/javascript' => $!text, 'text/plain' => self.Str) }
}

# `display($v)` 是**语句**，返回哨兵（Session 三处忽略它，不改 `_` / Out[n]）。
# 前端分工：notebook 收集成 display_data；TTY / 管道直接写 stdout。
# `:$id` 为 ADR-0048 P3 的 `update_display_data` 预留，P1 忽略。
our sub display($value, Str :$id = '') is export {
    my $b = Rakuish::Display::bundle-of(
        $value, :meta(%(source => 'display')));
    my $sess = try { $*RAKUISH-SESSION };
    if $sess.defined && $sess.want-display {
        $sess.add-display($b.to-hash(:mime));
    }
    else {
        my Str $t = $b.text;
        $*OUT.say($t) if $t.chars;
    }
    Rakuish::Display::Shown.new;
}
