unit module Rakuish::Data;

# Rakuish::Data —— 结构化数据读写（JSON / CSV / Table）的最小公共层。
#
# 命令层（REPL / DSL）会把这里的能力暴露成 open/save；底层仍然只经 Sys
# 读写文件，一律走会话级 Sys（0.81.0 起没有沙箱，边界只剩工作目录）。

use JSON::Fast;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::Data::Table;
need Rakuish::Data::Engine::DuckDB;   # 只加载适配器；DB::DuckDB 仍由 TWEAK 运行时 require

# ── Parquet 支撑（0.64）─────────────────────────────────────────────
# DuckDB 的 read_parquet / COPY 属于「外部文件访问」：默认 :safe 引擎是关掉的。
# 这里只在调用方显式 :allow-external 时开启，且路径一律先经 Sys.resolve 做
# root 校验；Agent 的 op 白名单不暴露这个开关（V-130 / V-152）。
sub with-duckdb(&body) {
    my $db = try {
        Rakuish::Data::Engine::DuckDB.new(:safe(False), :!read-only)
    };
    X::Rakuish::Unsupported.new(
        :detail('受控外部数据读写需要 DuckDB 引擎；请先 zef install DB::DuckDB:ver<1.3.1+>（依赖 Alien::Libduckdb:ver<1.2.1+>）')
    ).throw unless $db.defined;
    LEAVE { try { $db.close } }
    body($db)
}

sub sql-type(Str $t --> Str) {
    given $t {
        when 'int'  { 'BIGINT'  }
        when 'num'  { 'DOUBLE'  }
        when 'bool' { 'BOOLEAN' }
        default     { 'VARCHAR' }   # str / datetime / list / map / any 都转字符串
    }
}

sub parquet-value($v, Str $type) {
    unless $v.defined {
        return $type eq 'int'  ?? 0
            !! $type eq 'num'  ?? 0e0
            !! $type eq 'bool' ?? False
            !! '';
    }
    return $v if $v ~~ Int | Num | Rat | Bool;
    return $v.Str if $v ~~ Str | DateTime | Instant | IO::Path;
    to-json($v, :!pretty);
}

# Parquet / CSV 共用的导出流程（0.68）：建临时表 → 参数化 insert → COPY。
# 只有显式 :allow-external 才会调到这里；$abs 已由调用方经 Sys.resolve 校验。
sub export-table($db, Rakuish::Data::Table $table, Str $abs, Str $format,
                 :%csv-options = {} --> Nil) {
    my @cols = $table.columns.map(*.Str);
    X::Rakuish::Data.new(
        :detail('外部格式导出需要至少一列')
    ).throw unless @cols.elems;
    my Str $ddl = 'create table __rakuish_export ('
        ~ @cols.map({
            '"' ~ .subst('"', '""', :g) ~ '" '
                ~ sql-type($table.column-type($_))
          }).join(', ')
        ~ ')';
    $db.execute($ddl);
    my Str $ins = 'insert into __rakuish_export values ('
        ~ @cols.map({ '?' }).join(', ') ~ ')';
    for $table.rows -> $r {
        my @vals = @cols.map({
            parquet-value($r{$_}, $table.column-type($_))
        });
        $db.execute($ins, |@vals);
    }
    my Str $sql = 'select * from __rakuish_export';
    $format eq 'csv'
        ?? $db.write-csv($abs, $sql, :%csv-options)
        !! $db.write-parquet($abs, $sql);
    Nil
}

our sub from-json-data(Str $text) is export {
    from-json($text);
}

our sub to-json-data($value, Bool :$pretty = False --> Str) is export {
    given $value {
        when Rakuish::Data::Table { $value.to-json(:$pretty) }
        default { to-json($value, :$pretty) }
    }
}

# 行数组 → Table；非“对象数组”原样返回。
our sub tableify($value) {
    if $value ~~ Positional && $value.elems
       && $value.all ~~ Associative {
        return Rakuish::Data::Table.from-rows($value);
    }
    $value;
}

our sub from-csv-data(Str $text --> Rakuish::Data::Table) is export {
    # 0.106.0：原来把整份文本 .comb 成 Str 数组再逐字符 ~=，4MB / 20 万行
    # 实测要 16s。绝大多数 CSV 行没有引号，直接按行 .split(',') 走 C 级
    # 切分；只有含引号（可能跨行）的行才进原来的状态机。语义保持一致：
    # BOM、CRLF、双写引号、字段内逗号/换行、行尾空字段都照旧。
    my Str $src = $text.subst(/^ "\x[FEFF]"/, '');
    my @records;
    my @row;
    my Str $cur = '';
    my Bool $quoted = False;
    # 引号内跨行时要把原状态机看到的换行补回去；CRLF 文件保留 \r。
    my Str $eol = $src.contains("\r\n") ?? "\r\n" !! "\n";

    for $src.lines -> $line {
        unless $quoted || $line.contains('"') {
            @records.push($line.split(',').List);
            next;
        }
        my Str $chunk = $quoted ?? "{$eol}{$line}" !! $line;
        my @ch = $chunk.comb;
        my Int $n = @ch.elems;
        my Int $i = 0;
        while $i < $n {
            my Str $c = @ch[$i];
            if $quoted {
                if $c eq '"' {
                    if $i + 1 < $n && @ch[$i + 1] eq '"' {
                        $cur ~= '"';
                        $i += 2;
                        next;
                    }
                    $quoted = False;
                    $i++;
                    next;
                }
                $cur ~= $c;
                $i++;
                next;
            }
            if $c eq '"' {
                $quoted = True;
                $i++;
                next;
            }
            if $c eq ',' {
                @row.push($cur);
                $cur = '';
                $i++;
                next;
            }
            if $c eq "\r" {
                $i++;
                next;
            }
            if $c eq "\n" {
                @row.push($cur);
                @records.push(@row.List);
                @row = ();
                $cur = '';
                $i++;
                next;
            }
            $cur ~= $c;
            $i++;
        }
        # .lines 吃掉了行尾的 \n；引号已闭合时在这里补上原状态机的收行动作。
        # 引号仍开着则跨到下一行，不能提前记录。
        unless $quoted {
            @row.push($cur);
            @records.push(@row.List);
            @row = ();
            $cur = '';
        }
    }
    @row.push($cur) if $cur.chars || @row.elems;
    @records.push(@row.List) if @row.elems;

    return Rakuish::Data::Table.new(:columns(), :rows()) unless @records.elems;
    my @headers = @records.shift.map(*.Str);
    my @rows;
    # 0.132.0：CSV 单元格都是 Str，但列类型不该一律写成 str —— 否则
    # `$t.sum('size')` 永远是 0、schema 显示全 str（评审 §4.9 CSV 类型）。
    # 这里边建行边累计：全由整数字面量组成的列标 int，全由数字字面量组成
    # 的列标 num。**只推断类型、不改单元格原值**，而且只认「规范写法」：
    # '007' 的前导零、'1.50' 的尾零、超出 BIGINT 的整数都退回 str ——
    # 这样 :allow-external 导出经 DuckDB 的 BIGINT/DOUBLE 列时值不会被改写。
    my constant INT-LITERAL = /^ '-'? \d+ $/;
    my constant NUM-LITERAL = /^ '-'? \d+ [ '.' \d+ ]? $/;
    # bool 只认 CSV 规范写法 `true` / `false`：`1` / `0` 属于 int 列，
    # `yes` / `T` / `TRUE` 都不算 —— 猜宽了就会把用户的标识符列判成 bool。
    my constant BOOL-LITERAL = /^ [ 'true' | 'false' ] $/;
    # datetime 只认 `YYYY-MM-DD` + `T`/空格 + `HH:MM:SS`，且必须能真解析成
    # DateTime（`2020-13-45 99:99:99` 正则能过、语义不成立）；带时区偏移
    # 或分数的退回 str —— 那两种写法各自有歧义，不在这里猜。
    my constant DT-LITERAL = /^ \d**4 '-' \d**2 '-' \d**2 [ 'T' | ' ' ]
                               \d**2 ':' \d**2 ':' \d**2 $/;
    my constant INT64-MAX = 9_223_372_036_854_775_807;

    my sub dt-ok(Str $s --> Bool) {
        return False unless $s ~~ DT-LITERAL;
        my Bool $ok = False;
        try { DateTime.new($s.subst(' ', 'T')); $ok = True };
        $ok;
    }

    my %is-int = @headers.map({ $_ => True }).Hash;
    my %is-num = %is-int;
    my %is-bool = %is-int;
    my %is-dt = %is-int;
    my %saw = @headers.map({ $_ => False }).Hash;
    for @records -> $rec {
        my %r;
        for @headers.kv -> $idx, $h {
            my Str $v = ($rec[$idx] // '').Str;
            %r{$h} = $v;
            next unless %is-int{$h} || %is-num{$h}
                     || %is-bool{$h} || %is-dt{$h};
            my Str $s = $v.trim;
            # 空格子不参与判定（整空列最后仍是 str）：与 0.132.0 同口径。
            next unless $s.chars;
            %saw{$h} = True;
            if %is-int{$h} {
                %is-int{$h} = $s ~~ INT-LITERAL
                              && $s.Int.abs <= INT64-MAX
                              && $s.Int.Str eq $s;
            }
            if %is-num{$h} {
                %is-num{$h} = $s ~~ NUM-LITERAL && $s.Num.Str eq $s;
            }
            if %is-bool{$h} { %is-bool{$h} = $s ~~ BOOL-LITERAL }
            if %is-dt{$h}   { %is-dt{$h}   = dt-ok($s) }
        }
        @rows.push(%r);
    }
    my %types;
    for @headers -> $h {
        %types{$h} = !%saw{$h}       ?? 'str'
                   !! %is-int{$h}    ?? 'int'
                   !! %is-num{$h}    ?? 'num'
                   !! %is-bool{$h}   ?? 'bool'
                   !! %is-dt{$h}     ?? 'datetime'
                   !! 'str';
    }
    Rakuish::Data::Table.new(:columns(@headers), :rows(@rows), :%types);
}

our sub to-csv-data(Rakuish::Data::Table $table --> Str) is export {
    $table.to-csv;      # 0.91.0：实现在 Table，这里只保留旧名字
}

# ── Arrow IPC 读：交给 Arrow::IPC，这里只做 Table 适配（0.118.3 / V-313）
# 读侧的 FlatBuffers/类型解码全部由 Arrow::IPC 负责（它是独立包，零运行依赖，
# 支持 list / struct / map / 字典；自研那份明确拒绝这些）。写侧仍用
# Rakuish::Data::Arrow —— 那边 Arrow::IPC 要的是 Arrow C Data 视图，
# Table 喂不进去，改造成本更高（ADR-0038 / V-313）。
my constant %ARROW-TYPE-OF-TAG = (
    1  => 'any',        2  => 'int',      3  => 'num',     4  => 'str',
    5  => 'str',        6  => 'bool',     7  => 'num',     8  => 'datetime',
    9  => 'num',        10 => 'datetime', 11 => 'num',     12 => 'list',
    13 => 'map',        15 => 'str',      17 => 'map',     18 => 'num',
    19 => 'str',        20 => 'str',      21 => 'list',
);

# `Arrow::IPC` 把「时刻」解码成格式化字符串（"2020-01-01 12:00:00"），
# 而 Rakuish 的 Table 一直用 DateTime / 秒数 / Rat。这里按旧语义还原；
# 还原不了就**原样保留字符串**，类型退回 str —— 不假装成功。
sub arrow-clock-seconds(Str $s --> Any) {
    my @p = $s.split(':');
    return $s unless @p.elems == 3;
    my $sec = try @p[2].Numeric;
    return $s unless $sec.defined;
    @p[0].Int * 3600 + @p[1].Int * 60 + $sec;
}

sub arrow-ipc-value($v, Str $fmt --> Any) {
    return Any unless $v.defined;

    # 嵌套值在 Arrow::IPC 里是 StructVal / MapVal 对象；Table 只认
    # Hash / Positional（to-text 会用 JSON 展示，where/select 也能继续组合）。
    my Str $name = $v.^name;
    if $name eq 'Arrow::IPC::Read::StructVal' {
        my %h;
        my @keys = $v.names.List;
        my @vals = $v.vals.List;
        for @keys.kv -> $i, $k {
            %h{$k.Str} = arrow-ipc-value(@vals[$i], '');
        }
        return %h;
    }
    if $name eq 'Arrow::IPC::Read::MapVal' {
        my %h;
        for $v.pairs.Hash.pairs -> $p {
            %h{$p.key.Str} = arrow-ipc-value($p.value, '');
        }
        return %h;
    }

    given $fmt {
        when /^ 'ts' / {
            # 带时区是 "...+00" / "...+08:00"：空格换成 T 才认。
            my $d = try DateTime.new($v.Str.subst(' ', 'T'));
            return $d.defined ?? $d !! $v;
        }
        when /^ 'tt' / { return arrow-clock-seconds($v.Str) }
        when /^ 'tD' $<u>=<[smun]>/ {
            # duration：Arrow::IPC 给的是「该单位下的整数」，旧语义是秒。
            my %div = s => 1, m => 1_000, u => 1_000_000, n => 1_000_000_000;
            my $d = %div{~$<u>} // 1;
            return $d == 1 ?? $v !! ($v.Numeric / $d);
        }
        when /^ 'td' / {
            my $d = try DateTime.new($v.Str);
            return $d.defined ?? $d !! $v;
        }
        when /^ 'd:' / {
            my $r = try $v.Str.Rat;
            return $r.defined ?? $r !! $v;
        }
    }
    $v;
}

sub arrow-column-type(Str $fmt, @values --> Str) {
    my $info = try { Arrow::IPC::Format::parse-format($fmt) };
    my Str $t = %ARROW-TYPE-OF-TAG{($info.defined ?? $info<tag> !! 0)} // 'any';
    my @def = @values.grep(*.defined);
    return $t unless @def.elems;
    # 声明是 datetime / num，但还原失败（值还是 Str）就不要撒谎。
    given $t {
        when 'datetime' { return (@def.all ~~ DateTime) ?? 'datetime' !! 'str' }
        when 'num'      { return (@def.all ~~ Numeric)  ?? 'num'      !! 'str' }
        default         { return $t }
    }
}

sub table-from-arrow-hash(%d --> Rakuish::Data::Table) {
    my @names = (%d<names> // ()).List.map(*.Str);
    my @formats = (%d<formats> // ()).List.map(*.Str);
    my @cols = (%d<cols> // ()).List.map(-> $c { $c.defined ?? $c.List !! () });
    my Int $n = @cols.elems ?? @cols[0].elems !! 0;
    my @rows;
    for ^$n -> $i {
        my %r;
        for @names.kv -> $ci, $name {
            %r{$name} = arrow-ipc-value(@cols[$ci][$i], @formats[$ci] // '');
        }
        @rows.push(%r);
    }
    my %types;
    for @names.kv -> $ci, $name {
        # 类型按**转换后**的值判定：raw 是 Arrow::IPC 的格式化字符串，
        # 拿它去比对 DateTime/Numeric 永远不成立。
        my @vals = @rows.map({ $_{$name} });
        %types{$name} = arrow-column-type(@formats[$ci] // '', @vals);
    }
    Rakuish::Data::Table.new(:columns(@names), :rows(@rows), :%types);
}

# ── 快路白名单（0.122.0 / V-318）─────────────────────────────────────
# 交给 DuckDB 读的前提是「两路逐值 eqv」—— t/78 逐列断言钉住这件事。
# 进来的：
#   int / float / bool / utf8（含 large-utf8）→ 标量值本身
#   date / timestamp（不带时区）             → 两边都是 UTC 的 DateTime
#   decimal                                  → 两边都是 Rat。DB::DuckDB 1.3.1
#       之前这里坏过：ColumnView 的 128 位拼装把高字当无符号，-0.0001 变成
#       3.4e34（DB::DuckDB 1.3.1 已按补码修好，t/78 有负数断言钉住）
# 不进来的：
#   time / duration   → 自研读入器给「秒数」，DuckDB 给 "01:02:03" 文本
#   timestamp 带时区  → DuckDB 保留 +08:00 偏移，自研读入器归一到 UTC
#   binary            → 自研给 Buf，DuckDB 的 SQL 出口是带 \x 转义的 Str
#   嵌套 / 字典       → SQL 出口只剩文本渲染（等 C data 旁路）
my constant FAST-ARROW-KINDS = <int float bool utf8 large-utf8 date timestamp decimal list map struct>;

# 1 MB 以下不走快路：DuckDB 那条链第一次用要装载 libduckdb + Duckula +
# nanoarrow（实测约 0.7 s），而 1 MB 的 Arrow 自研读入器 2 s 出头，
# 小文件走快路反而更慢。大于这条线才划算（50 万行 23.4 s → 13.1 s）。
my constant FAST-ARROW-MIN-BYTES = 1024 * 1024;

# auto（默认）/ on / off；on/off 是给排查与测试用的，不看体积。
sub fast-arrow-wanted(Str $abs --> Bool) {
    return False if (%*ENV<RAKUISH_ARROW_RAKU> // '').chars;
    return True  if (%*ENV<RAKUISH_ARROW_NATIVE> // '').chars;
    my $io = $abs.IO;
    $io.e && $io.s >= FAST-ARROW-MIN-BYTES;
}

sub fast-arrow-ok(@kinds --> Bool) {
    return False unless @kinds.elems;
    for @kinds -> %c {
        return False if %c<dictionary>;
        my Str $k = (%c<kind> // '').Str;
        return False unless FAST-ARROW-KINDS.first(* eq $k).defined;
        return False if $k eq 'timestamp' && (%c<tz> // '').chars;
    }
    True;
}

our sub open-data(Rakuish::Sys $sys, Str $path, Bool :$raw = False,
                  Bool :$allow-external = False,
                  Int :$max-rows,
                  :%csv-options = {}) is export {
    my Str $ext = $path.IO.extension.lc;
    # 0.69 方言选项只在「.csv + 显式授权」时有意义；其余组合明确拒绝，
    # 不静默忽略（否则拼错开关会以为生效了）。
    X::Rakuish::Unsupported.new(
        :detail('CSV 方言选项只在 .csv 且显式 :allow-external 时可用（默认路径仍由 Raku 解析器读取）')
    ).throw if %csv-options.elems
              && !($allow-external && $ext eq 'csv');
    # 显式授权时 Parquet / CSV 走受控 DuckDB 外部访问（V-152 / V-160）。
    # 路径一律先经 Sys.resolve；Agent 的 op 白名单不暴露这个开关。
    if $allow-external && ($ext eq 'parquet' || $ext eq 'pq' || $ext eq 'csv') {
        my Str $abs = $sys.resolve($path).Str;
        # 0.134.0 / AUDIT-FS-LIMITS D5：`:max-rows` 以前**根本没接线** ——
        # Engine.read-csv / read-parquet 一直支持，但这里不传，于是「DuckDB
        # 那条链」恰恰是全量物化的（100 万行 CSV 实测 38 s 才回一张 Table）。
        # 只做透传，**不给默认值**：默认截断会让用户拿到一份「看起来完整、
        # 其实少一半」的表，而 Table 没有 truncated 载体（与 V-271「不静默
        # 截断」同一条原则）。要限流就显式写 :max-rows(N)，或 Shell 的
        # `open --limit N`（那里会把「只取了前 N 行」打进输出文本）。
        return with-duckdb(-> $db {
            my %lim = $max-rows.defined ?? %(:max-rows($max-rows)) !! %();
            $ext eq 'csv'
                ?? $db.read-csv($abs, :%csv-options, |%lim)
                !! $db.read-parquet($abs, |%lim)
        });
    }
    # 二进制 Parquet 没有「按文本读取」的退路，必须显式开启。
    if $ext eq 'parquet' || $ext eq 'pq' {
        X::Rakuish::Unsupported.new(
            :detail('读取 .parquet 需要显式 :allow-external（路径仍经 Sys root 校验；Agent 不开放）')
        ).throw;
    }
    # 0.116.0 / V-308：Arrow IPC 是**二进制**，不能走 Sys.read（文本解码会炸）。
    # 0.122.0 起标量列可能会交给 DuckDB（V-318），但路径先经 Sys.resolve 校验，
    # 而且永远有纯 Raku 退路 —— 所以这条分支仍然不需要 :allow-external。
    if $ext eq 'arrow' | 'feather' | 'ipc' {
        X::Rakuish::Unsupported.new(
            :detail('Arrow IPC 是二进制，没有 --raw 的文本形态；要原始字节请用 slurp(:bin) 或 read-ipc')
        ).throw if $raw;
        my Str $abs = $sys.resolve($path).Str;
        require Rakuish::Data::Arrow;
        # 0.122.0 / V-318：标量列先交给 DuckDB（Duckula → read_arrow）。
        # 这是**纯优化**：类型不在白名单、体积太小、或 Duckula / nanoarrow
        # 缺一个时就静默回落下面的纯 Raku 读入器，对外行为不变（t/78 逐列
        # 比对）。排查时可强制：RAKUISH_ARROW_NATIVE=1 / RAKUISH_ARROW_RAKU=1。
        my Bool $want-fast = fast-arrow-wanted($abs);
        # 小文件本来不该付装载代价，但**压缩文件**自研读入器根本读不了，
        # 交给 DuckDB 是唯一的路，这时候多等 0.7 s 是划算的。
        if !$want-fast && $abs.IO.s < FAST-ARROW-MIN-BYTES {
            $want-fast = Rakuish::Data::Arrow::ipc-compressed-file($abs);
        }
        if $want-fast {
            my @kinds = (try { Rakuish::Data::Arrow::ipc-column-kinds-file($abs) }) // ();
            if fast-arrow-ok(@kinds) {
                require Rakuish::Data::Duck;
                my $fast = try { Rakuish::Data::Duck::read-arrow-native($abs) };
                return $fast if $fast.defined;
            }
        }
        # 压缩批先拦：自研读入器不处理 BodyCompression，也**不报错**，
        # 压缩 body 会被当裸 buffer 解成垃圾（V-313 实测）。扫描只看元数据。
        # （标量列的压缩文件上一段已经由 DuckDB 读掉了，走到这里的只有
        # 嵌套 / 时区这类快路不收的。）
        X::Rakuish::Unsupported.new(
            :detail('压缩的 Arrow IPC 只有标量列能读，而且要 DuckDB 解压：'
                ~ 'zef install DB::DuckDB:ver<1.3.1+> Duckula:ver<0.54+>，'
                ~ '再装 nanoarrow 扩展（INSTALL nanoarrow FROM community）。'
                ~ '也可以用 duckdb 先解压成未压缩文件')
        ).throw if Rakuish::Data::Arrow::ipc-compressed-file($abs);
        # 读侧分流（0.120.1 / V-316）：先走自研读入器（标量列，快约 4 倍，
        # 且有边界检查）；只有它明确说「文件合法、但这个类型没实现」
        # （嵌套 / 字典 / 压缩）才交给 Arrow::IPC。
        #
        # **坏文件绝不回退**：`Arrow::IPC.decode-ipc` 对越界元数据没有边界
        # 检查，会直接段错误（实测截断文件 / Duckula 的坏 IPC 都是 rc=139），
        # 段错误连 `try` 都接不住。所以这里只认 UnsupportedType 这一种。
        my $own;
        my $own-err;
        {
            CATCH { default { $own-err = $_ } }
            $own = Rakuish::Data::Arrow::read-ipc-file($abs);
        }
        return $own if $own.defined;
        $own-err.throw unless $own-err ~~ X::Rakuish::Arrow::UnsupportedType;

        # 合法但自研读不了：交给 Arrow::IPC（支持 list / struct / map / 字典）。
        # 注意 `require` 是语句、返回值不是模块对象，别写 `my $m = require ...`
        # （会被解析成「调用 require 这个 routine」直接编译失败）。
        my Bool $have-ipc = (try { require Arrow::IPC; True }) // False;
        X::Rakuish::Unsupported.new(
            :detail('这个 .arrow 用了嵌套 / 字典编码，需要 Arrow::IPC 0.1.0+（zef install Arrow::IPC）')
        ).throw unless $have-ipc;
        return table-from-arrow-hash(Arrow::IPC::decode-ipc($abs));
    }

    my Str $text = $sys.read($path);
    return $text if $raw;
    return $text unless $ext.chars;
    given $ext {
        when 'json' { tableify(from-json($text)) }
        when 'csv'  { from-csv-data($text) }
        default     { $text }
    }
}

our sub save-data(Rakuish::Sys $sys, Str $path, $value,
                  Bool :$pretty = True,
                  Bool :$allow-external = False,
                  Int :$batch-size,
                  :%csv-options = {}) is export {
    my Str $ext = $path.IO.extension.lc;
    X::Rakuish::Unsupported.new(
        :detail('CSV 方言选项只在 .csv 且显式 :allow-external 时可用')
    ).throw if %csv-options.elems
              && !($allow-external && $ext eq 'csv');
    my Bool $external-format = $ext eq 'parquet' || $ext eq 'pq' || $ext eq 'csv';
    if $external-format && $allow-external {
        my $table = $value ~~ Rakuish::Data::Table
            ?? $value
            !! Rakuish::Data::Table.from-rows($value);
        my Str $abs = $sys.resolve($path).Str;
        with-duckdb(-> $db {
            export-table($db, $table, $abs,
                         $ext eq 'csv' ?? 'csv' !! 'parquet',
                         :%csv-options)
        });
        return True;
    }
    if $ext eq 'parquet' || $ext eq 'pq' {
        X::Rakuish::Unsupported.new(
            :detail('写入 .parquet 需要显式 :allow-external（路径仍经 Sys root 校验；Agent 不开放）')
        ).throw;
    }
    # 0.116.0：Arrow IPC 写出（同样是二进制，不能走 Sys.write 的文本路径）。
    if $ext eq 'arrow' | 'feather' | 'ipc' {
        require Rakuish::Data::Arrow;
        my $table = $value ~~ Rakuish::Data::Table
            ?? $value
            !! Rakuish::Data::Table.from-rows($value);
        # :batch-size 让 .arrow 也走多批（0.121.0 / V-317）；不传就是旧行为
        # （一个 RecordBatch），read-ipc 两条路都能读回。
        Rakuish::Data::Arrow::write-ipc-file($table, $sys.resolve($path).Str,
                                             :$batch-size);
        return True;
    }

    # 不带开关的 .csv 仍走 Sys.write（V-129 默认路径），行为与 0.64 一致。
    my Str $text;
    given $ext {
        when 'json' { $text = to-json-data($value, :$pretty) }
        when 'csv'  {
            my $table = $value ~~ Rakuish::Data::Table
                ?? $value
                !! Rakuish::Data::Table.from-rows($value);
            $text = to-csv-data($table);
        }
        default { $text = $value.Str }
    }
    $sys.write($path, $text);
}
