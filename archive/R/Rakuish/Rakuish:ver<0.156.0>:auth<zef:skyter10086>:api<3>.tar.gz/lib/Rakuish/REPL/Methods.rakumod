unit module Rakuish::REPL::Methods;

# Rakuish::REPL::Methods —— `.` 之后的方法名补全（0.107.0 / V-298）。
#
# 这里只有**纯函数**：从「光标前的文本」判断用户在补什么，以及从一个
# 对象/类型对象上收集公开方法名。真正的取值（%!state、@!out、按名字
# 解析类型）在 Session 侧完成 —— 只有它持有会话状态。
#
# 支持形态（光标紧跟 `.` 或半截方法名）：
#   $db.            @rows.          %h.
#   Out[2].         In[1].          _.
#   DB::DuckDB.     Cro::HTTP::Client.
#
# 边界：链式调用（`$x.foo.`）不补 —— 那需要在补全路径上真的求值一次
# `$x.foo`，代价和风险都不值；先按左值形态覆盖日常用法。

# 从光标前的文本解析出补全上下文。命中返回
#   %( head => 目标之前的原文, target => '$db' / 'DB::DuckDB' / 'Out[2]',
#      frag => 已输入的方法名片段, kind => 'var' | 'ref' | 'type' )
# 否则返回空 Hash。
our sub method-context(Str $line, Int $pos --> Hash) is export {
    my Int $at = $pos min $line.chars;
    my Str $pre = $line.substr(0, $at);
    return %() unless $pre.chars;
    return %() if $pre.starts-with('!');      # `!` 行是 shell，不补方法

    # Out[2]. / In[1]. —— 结果引用，取值由 Session 从 @!out 拿。
    if $pre ~~ / $<sep> = (^ | <-[\w:.-]>) $<tgt> = ((In|Out) '[' \d+ ']')
                 '.' $<frag> = (<[\w-]>*) $ / {
        return %( head   => $pre.substr(0, $/.from + $<sep>.Str.chars),
                  target => ~$<tgt>, frag => ~$<frag>, kind => 'ref' );
    }

    # _. —— 上一格的值。
    if $pre ~~ / $<sep> = (^ | <-[\w:.-]>) '_' '.' $<frag> = (<[\w-]>*) $ / {
        return %( head   => $pre.substr(0, $/.from + $<sep>.Str.chars),
                  target => '_', frag => ~$<frag>, kind => 'ref' );
    }

    # $var. / @arr. / %hash. —— 跨格 my 变量（%!state 里带 sigil 的键）。
    if $pre ~~ / $<sep> = (^ | <-[\w\$@%&:.-]>) $<tgt> = (<[$@%]> <[\w-]>+)
                 '.' $<frag> = (<[\w-]>*) $ / {
        return %( head   => $pre.substr(0, $/.from + $<sep>.Str.chars),
                  target => ~$<tgt>, frag => ~$<frag>, kind => 'var' );
    }

    # Type::Name. —— 只认大写开头的包名，避免把 `1.` / `foo.bar` 当类型。
    if $pre ~~ / $<sep> = (^ | <-[\w:.\-]>) $<tgt> = (<[A..Z]> <[\w-]>* [ '::' <[\w-]>+ ]*)
                 '.' $<frag> = (<[\w-]>*) $ / {
        return %( head   => $pre.substr(0, $/.from + $<sep>.Str.chars),
                  target => ~$<tgt>, frag => ~$<frag>, kind => 'type' );
    }

    %()
}

# 公开方法名：去重、去私有（`!` 开头）、按字典序。
# 类型对象和实例都走 `^methods`（后者含继承与 role 合成的方法）。
our sub method-names($obj --> List) is export {
    my @m = try { $obj.^methods.List } // ();
    my %seen;
    my @out;
    for @m -> $m {
        my Str $n = (try { $m.name.Str }) // '';
        next unless $n.chars;
        next if $n.starts-with('!');
        # Rakudo 给新类自动挂的元方法，不是用户能调的 API（0.108.0）。
        next if $n eq 'POPULATE';
        next if %seen{$n}++;
        @out.push($n);
    }
    # `submethod new` 不在 ^methods 里，但 `Type.new` 是最常用的入口；
    # 只对几个固定名字查 ^can，避免又是全量枚举。
    for <new clone gist perl raku> -> $n {
        next if %seen{$n};
        next unless (try { $obj.^can($n).elems }) // 0;
        %seen{$n} = True;
        @out.push($n);
    }
    @out.sort.List;
}

# 按已输入片段过滤；片段为空时原样返回（Tab 一下列出全部）。
our sub filter-names(List $names, Str $frag --> List) is export {
    return $names.List unless $frag.chars;
    $names.grep({ .Str.starts-with($frag) }).List;
}
