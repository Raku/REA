unit module Rakuish::REPL::Introspect;

# Rakuish::REPL::Introspect —— `doc` 命令的纯函数核心（0.75.0 / ADR-0012 §3）。
#
# 硬边界：**零 EVAL、零 I/O、不碰 $*OUT**。只做
#   「严格校验过的名字 → 动态符号表查找 → 元对象读取」。
# 为什么不复用 Plugins 的 EVAL：那是「显式加载可信本地文件」，而 doc 的参数
# 来自用户随手敲的一行字，拼进 EVAL 就是任意代码执行（连 BEGIN phaser 都挡不住）。
#
# 因此本模块看不到 REPL 跨格声明的 my/our/class（它们在 Session 的 %STATE /
# @decls 里，不是包符号）。要看命令用法请用 `doc <命令名>` —— Shell 会先查
# usage()，那才是权威帮助。这个边界是刻意的，不要「顺手补上」。

# 只允许 [&]?Ident(::Ident)* —— 没有空白、引号、分号、$、括号。
# 字符类范围必须写 `..`（写 `a-z` 会被 Raku 当成字符范围语法报错）。
my sub valid-name(Str $raw --> Bool) {
    so $raw ~~ /^ <[&]>? <[A..Z a..z _]> <[A..Z a..z 0..9 _]>*
                  [ '::' <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* ]* $/;
}

my sub not-found(Str $name --> Hash) {
    { :!ok, :name($name), :reason("未找到该名字: $name"), :text('') }
}

my sub describe-object($obj, Str $name --> Str) {
    my @lines;
    my Str $kind = $obj.^name;
    # 类型对象（如 Str）的 .defined 是 False，不能用它区分「找不到」。
    my Bool $instance = $obj.defined && $kind ne 'Any';
    @lines.push("名称: $name");
    @lines.push("类型: $kind" ~ ($instance ?? '（实例）' !! '（类型对象）'));

    my $why = try { $obj.WHY };
    @lines.push('文档: ' ~ ($why.defined && $why.Str.chars
                           ?? $why.Str.trim !! '（无 WHY 文档）'));

    if $obj ~~ Callable {
        my $sig = try { $obj.signature.gist };
        @lines.push('签名: ' ~ ($sig.defined ?? $sig !! '（不可读）'));
    }

    my @methods = try { $obj.^methods(:local).map(*.name).grep(*.chars).sort.unique.List } // ();
    if @methods.elems {
        my Int $shown = @methods.elems min 20;
        @lines.push('方法（' ~ @methods.elems ~ ' 个，前 ' ~ $shown ~ ' 个）: '
                    ~ @methods.head($shown).join(', '));
    }
    @lines.join("\n");
}

# 返回纯数据 Hash：:ok / :name / :reason / :text。
# 调用方（Shell!cmd-doc）据此构造 Result；本函数不产生副作用。
our sub introspect(Str $raw --> Hash) is export {
    my Str $name = $raw.trim;
    unless valid-name($name) {
        return { :!ok, :name($name), :reason('非法名字：只允许标识符或 &例程名'),
                 :text('') };
    }

    # 查符号这一步踩过两个坑，都跟「异常对象有没有被消费」有关：
    #
    #   1. **不能用 `try`**。`try { $obj = ::($name) }` 会把块值（这里是
    #      Failure）留在返回位置，`$!` 置 Nil 或 `$_` 上 `.Bool` 都管不到它，
    #      于是它在之后的某次 GC 里 DESTROY，往 stderr 吐
    #      「unhandled Failure detected in DESTROY」。改用裸块 + CATCH，
    #      块没有返回值语义，Failure 当场被 `.Bool` 消费掉。
    #   2. **不能用 `.defined` 判断**。异常/Failure 的 `.defined` 返回 False
    #      （看起来「一切正常」），而 `Str` 这类类型对象的 `.defined` 同样是
    #      False —— 两头都会误判。所以这里只看 `$found` 标志。
    my $obj;
    my Bool $found = True;
    {
        CATCH { default { .Bool; $found = False } }
        $obj = ::($name);
    }
    # 另一条路：`::($name)` 也可能**不抛**，而是把延迟 Failure 直接当值返回。
    # 这种 Failure 不能拿去做内省（`Str.WHY` 之类都会静默给出空值，看起来
    # 像「这个类型没有文档」），必须同样 `.Bool` 消费掉并判为未找到。
    if $found && $obj ~~ Failure {
        $obj.Bool;
        $found = False;
    }
    # 0.128.0 / §4.9e：内置例程（say、print、for...）不是包符号，`::say` 查到的
    # 是 Nil。fallback 用 `::("&name")` 取 Callable — 能拿到签名。
    # 注意：不能用 `.defined` 判，类型对象（Int、Str）的 `.defined` 也是 False。
    unless $found {
        my $callable;
        {
            CATCH { default { .Bool } }
            $callable = ::("&" ~ $name);
        }
        if $callable.defined && $callable ~~ Callable {
            $obj = $callable;
            $found = True;
        }
    }
    unless $found {
        return not-found($name);
    }

    my Str $text = try { describe-object($obj, $name) } // '';
    unless $text.chars {
        return { :!ok, :name($name), :reason("无法内省: $name"), :text('') };
    }
    { :ok, :name($name), :reason(''), :text($text) }
}

our sub introspect-name-ok(Str $raw --> Bool) is export { valid-name($raw) }
