# Rakuish::REPL::Session::Exec —— `!` 命令行分发（0.152.0 / ADR-0066 / V-356）
#
# 这里只做一件事：把以 `!` 开头的一行解释成一次外部命令 / 管道 / 透传，并返回
# Result。会话命令、shell 习惯命令、Raku 求值都留在 Session 的 !eval-line-body。
#
# 退出语义：**返回 Result = 已处理**；返回 Nil = 这一行不是 `!` 命令（`!=` / `!~~`
# 是 Raku 运算符，必须落回 Raku 求值），由调用方继续往下分流。
#
# 元选项（只认第 1 段开头的 token，作用在整条管道上）：
#   --tty / -t        把终端借给交互式程序（ADR-0007；0.144.0 起可与管道共存）
#   --capture         强制捕获（关掉流式）
#   --pipe / -P       末段输出直写终端，不攒进 Result（透传，V-349）
#   --pipefail        退出码取最右非零段
#   --stdin FILE      首段 stdin 从文件流式接入
#   --timeout-ms N / --no-timeout
#   --                之后全部按字面 argv
#
# 状态一律经公开访问器读写（ADR-0060 §3.2）：$.sys / $.index / $.stream-out /
# &.tty-handler / &.pipe-handler。依赖的 !split-argv / !split-pipeline /
# !unclosed-quote / !remember / !strict-result / !emit-chunk 留在 Session，
# role 方法按名字调用它们（ADR-0060 §2 实测可行）。

unit role Rakuish::REPL::Session::Exec;

use Rakuish::Result;
use Rakuish::REPL::Shell;      # win-cmd-builtin-argv
use Rakuish::REPL::Highlight;  # 与 Session 保持同一份高亮配置（仅为一致性）

method !dispatch-bang(Str $t --> Any) {
    my Str $next = $t.chars > 1 ?? $t.substr(1, 1) !! '';
    if $next ne '=' && $next ne '~' {
        my Str $next = $t.chars > 1 ?? $t.substr(1, 1) !! '';
        if $next ne '=' && $next ne '~' {
            my Str $cmdline = $t.substr(1).trim;
            if self!unclosed-quote($cmdline) {
                return self!strict-result(
                    Result.new(:!ok, :code(127), :op<exec>,
                               :err('! 命令的引号未闭合')));
            }
            # 0.143.0 / V-347：先按顶层 `|` 切段，再解析第 1 段的 argv。
            # 切分不引入 shell 语法：只认单个 `|`，`||` / 重定向 / 展开仍不支持。
            my @pipe-segs = self!split-pipeline($cmdline);
            my @argv = self!split-argv(@pipe-segs[0].Str);
            # 0.70 / ADR-0007：`! --tty` / `! -t` 是显式 TTY 直通的元选项，
            # 只认首个 token；`! -- ...` 之后全部按字面 argv，不再解析元选项。
            # 0.90.0 / ADR-0024：同一层新增 `--capture` / `--timeout-ms` /
            # `--no-timeout`。它们仍属于 rakuish 的分发层，子进程只收到 argv。
            my Bool $tty-mode = False;
            my Bool $capture  = False;
            # 0.145.0 / V-349：P1/P2 的三个元选项，与上面几个一样只作用于整条
            # 管道（都只认第 1 段开头的 token）。
            #   --pipe      末段输出不捕获，直写终端（透传）
            #   --pipefail  退出码取最右非零段
            #   --stdin F   首段 stdin 从文件流式接入
            my Bool $pipe-mode  = False;
            my Bool $pipefail   = False;
            my Str  $stdin-file = '';          # 已按会话 cwd / root 解析成绝对路径
            my Int  $timeout-ms = -1;          # -1 = 用 Sys 的默认（30s）
            while @argv.elems {
                my Str $head = @argv[0].Str;
                if $head eq '--' { @argv.shift; last }
                if $head eq '--tty' || $head eq '-t' {
                    $tty-mode = True; @argv.shift; next;
                }
                if $head eq '--pipe' || $head eq '-P' {
                    $pipe-mode = True; @argv.shift; next;
                }
                if $head eq '--pipefail' {
                    $pipefail = True; @argv.shift; next;
                }
                if $head eq '--capture' {
                    $capture = True; @argv.shift; next;
                }
                if $head eq '--stdin' {
                    @argv.shift;
                    my $raw = @argv.shift;
                    unless $raw.defined && $raw.Str.chars {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('! --stdin 需要一个文件路径')));
                    }
                    # 路径解析交给 Sys（root 沙箱 + 会话 cwd）；解析结果必须是
                    # **绝对路径**：worker 模式下真正读文件的是父进程。
                    my $path;
                    my Str $perr = '';
                    {
                        CATCH { default { $perr = .message } }
                        $path = $.sys.resolve($raw.Str);
                    }
                    unless $path.defined {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('! --stdin 的路径无效: '
                                 ~ ($perr.chars ?? $perr !! $raw.Str))));
                    }
                    unless $path.e && $path.f {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('! --stdin 的文件不存在: ' ~ $path.Str)));
                    }
                    $stdin-file = $path.Str;
                    next;
                }
                if $head eq '--no-timeout' {
                    $timeout-ms = 0; @argv.shift; next;
                }
                if $head eq '--timeout-ms' {
                    @argv.shift;
                    my $raw = @argv.shift;
                    my $n = $raw.defined ?? (try { $raw.Str.Int }) !! Nil;
                    unless $n.defined && $n >= 0 {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('! --timeout-ms 需要一个非负整数（毫秒；0 = 不超时）')));
                    }
                    $timeout-ms = $n.Int;
                    next;
                }
                last;
            }
            if $pipe-mode && $capture {
                return self!strict-result(Result.new(
                    :!ok, :code(127), :op<exec>,
                    :err('! --pipe 与 --capture 互斥（透传就是不捕获）')));
            }
            return self!strict-result(Result.new(:!ok, :code(127), :op<exec>,
                              :err('! 后面没有命令'))) unless @argv.elems;
            my $exe = @argv.shift;
            # 0.130.0 / ADR-0049：Windows cmd 内建（echo / dir / …）没有同名
            # exe。只重写 argv，不引入 shell 语法 —— 细节（白名单 / 转义 /
            # `%VAR%` 不展开）在 Shell::win-cmd-builtin-argv。
            # `--tty` 是「把终端借给交互式程序」，不经过这层（ADR §3）。
            # 0.144.0 / V-348：`--tty` + 管道例外 —— 第 0 段不再独占终端，
            # 只是接上 stdin，仍要按 cmd 内建重写（`! --tty dir | findstr x`）。
            if $*DISTRO.is-win && (!$tty-mode || @pipe-segs.elems > 1) {
                my @cmd = Rakuish::REPL::Shell::win-cmd-builtin-argv($exe.Str, @argv);
                if @cmd.elems {
                    $exe = @cmd.shift;
                    @argv = @cmd;
                }
            }
            $.index = $.index + 1;
            my $r;
            # 0.143.0 / V-347：顶层 `|` → 引擎内管道（ADR-0056）。
            # 0.144.0 / V-348：`--tty` + 管道 → 父进程执行（ADR-0057）。
            # 元选项仍只认第 1 段开头的 token，作用在整条管道上。
            # `--tty` 不再与管道互斥 —— 那正是本版新增的入口。
            if @pipe-segs.elems > 1 {
                my @stages = ([$exe.Str, |@argv.map(*.Str)],);
                for @pipe-segs[1 .. *] -> $seg {
                    my @a = self!split-argv($seg.Str);
                    unless @a.elems {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('管道里有空段：不支持 || 与行尾多余的 |')));
                    }
                    my Str $x = @a.shift.Str;
                    # 每段都要过 Windows cmd 内建重写（`! dir | findstr x`）。
                    if $*DISTRO.is-win {
                        my @cmd = Rakuish::REPL::Shell::win-cmd-builtin-argv($x, @a);
                        if @cmd.elems {
                            $x = @cmd.shift.Str;
                            @a = @cmd;
                        }
                    }
                    @stages.push([$x, |@a.map(*.Str)]);
                }
                my %popt = :no-capture, :pipefail($pipefail);
                %popt<stdin-file> = $stdin-file if $stdin-file.chars;
                if $pipe-mode {
                    # 0.145.0 / V-349（P1）：透传 —— 末段输出直写终端、不攒进
                    # Result、默认不设总超时。worker 模式必须交父进程（只有它的
                    # stdout 是真终端）；单进程模式在本进程跑，$*OUT 就是 stdout。
                    # worker 里没有执行器时明确 127，**绝不**把原始输出写进协议
                    # 管道（那会把 REPL 的 NDJSON 流冲垮）。
                    %popt<timeout-ms> = $timeout-ms >= 0 ?? $timeout-ms !! 0;
                    my $hook = self.pipe-handler;
                    if $hook.defined {
                        my $got = try { $hook(@stages.List, |%popt) };
                        $r = ($got.defined && $got ~~ Result)
                            ?? $got
                            !! Result.new(:!ok, :code(127), :op<exec>,
                                    :err('管道执行器返回了非 Result: '
                                         ~ ($got // 'Any').raku));
                    }
                    else {
                        my &on-out = -> Str $t { try { $*OUT.print($t); $*OUT.flush } };
                        my &on-err = -> Str $t { try { $*ERR.print($t); $*ERR.flush } };
                        $r = $.sys.pipe-exec(@stages, |%popt,
                                             :on-out(&on-out), :on-err(&on-err));
                    }
                    # 输出已在跑的时候写掉了；out/err 留空，避免 render 重放。
                    # 启动失败是例外 —— 那时没有任何输出，err 必须留给 render。
                    my %v = ($r.value ~~ Hash) ?? %($r.value) !! %();
                    unless ?(%v<start-failed> // False) {
                        $r = Result.new(:ok($r.ok), :code($r.code), :op($r.op),
                                        :out(''), :err(''),
                                        :value($r.value), :elapsed($r.elapsed),
                                        :streamed(True));
                    }
                    self!remember($r);
                    return self!strict-result($r);
                }
                if $tty-mode {
                    # 0.144.0 / V-348：只有父进程的 stdin 是真终端 —— 把整条
                    # 管道交给它，首段继承终端、段间照旧泵、末段输出捕获回来
                    # （Out[n] 可用）。无 handler 时明确 127，**绝不**回退引擎
                    # 内：第 0 段会把协议 stdin 吃掉，REPL 当场错位。
                    my $hook = self.pipe-handler;
                    unless $hook.defined {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('交互式管道需要父进程执行器，但当前没有注册'
                                 ~ '（引擎内不能把终端交给首段）')));
                    }
                    my %topts;
                    %topts<pipefail> = True if $pipefail;
                    %topts<stdin-file> = $stdin-file if $stdin-file.chars;
                    %topts<timeout-ms> = $timeout-ms if $timeout-ms >= 0;
                    # 无附加选项时仍按老签名调用 —— 旧的 hook 闭包没有 slurpy。
                    my $got = %topts.elems
                        ?? (try { $hook(@stages.List, |%topts) })
                        !! (try { $hook(@stages.List) });
                    $r = $got.defined && $got ~~ Result
                        ?? $got
                        !! Result.new(:!ok, :code(127), :op<exec>,
                                :err('管道执行器返回了非 Result: '
                                     ~ ($got // 'Any').raku));
                    # v1 不做父→引擎的块流式：末段输出一次性随结果回来，
                    # 结果必须是非 streamed，否则 render 不会重放 Out[n]。
                    if $r.streamed {
                        $r = Result.new(:ok($r.ok), :code($r.code), :op($r.op),
                                        :out($r.out), :err($r.err),
                                        :value($r.value), :elapsed($r.elapsed),
                                        :streamed(False));
                    }
                    self!remember($r);
                    return self!strict-result($r);
                }
                my %pto = $timeout-ms >= 0 ?? ('timeout-ms' => $timeout-ms) !! %();
                # 0.145.0 / V-349：另两个开关对「捕获式管道」同样生效。
                %pto<pipefail> = True if $pipefail;
                %pto<stdin-file> = $stdin-file if $stdin-file.chars;
                my Bool $pstream = $.stream-out && !$capture;
                if $pstream {
                    my &emit-out = -> Str $t { self!emit-chunk('out', $t) };
                    my &emit-err = -> Str $t { self!emit-chunk('err', $t) };
                    $r = $.sys.pipe-exec(@stages, |%pto,
                                         :on-out(&emit-out), :on-err(&emit-err));
                    my %v = ($r.value ~~ Hash) ?? %($r.value) !! %();
                    unless ?(%v<start-failed> // False) {
                        $r = Result.new(:ok($r.ok), :code($r.code), :op($r.op),
                                        :out(''), :err(''),
                                        :value($r.value), :elapsed($r.elapsed),
                                        :streamed(True));
                    }
                }
                else {
                    $r = $.sys.pipe-exec(@stages, |%pto);
                }
                self!remember($r);
                return self!strict-result($r);
            }
            if $pipe-mode {
                # 0.145.0 / V-349（P1）：单条命令也按「一段的管道」透传 ——
                # 走同一个 pipe-exec 执行器，语义与 `a | b` 完全一致，不必
                # 为一条命令再写一套直写逻辑。
                my @stages = ([$exe.Str, |@argv.map(*.Str)],);
                my %popt = :no-capture, :pipefail($pipefail);
                %popt<stdin-file> = $stdin-file if $stdin-file.chars;
                %popt<timeout-ms> = $timeout-ms >= 0 ?? $timeout-ms !! 0;
                my $hook = self.pipe-handler;
                if $hook.defined {
                    my $got = try { $hook(@stages.List, |%popt) };
                    $r = ($got.defined && $got ~~ Result)
                        ?? $got
                        !! Result.new(:!ok, :code(127), :op<exec>,
                                :err('管道执行器返回了非 Result: '
                                     ~ ($got // 'Any').raku));
                }
                else {
                    my &on-out = -> Str $t { try { $*OUT.print($t); $*OUT.flush } };
                    my &on-err = -> Str $t { try { $*ERR.print($t); $*ERR.flush } };
                    $r = $.sys.pipe-exec(@stages, |%popt,
                                         :on-out(&on-out), :on-err(&on-err));
                }
                my %v = ($r.value ~~ Hash) ?? %($r.value) !! %();
                unless ?(%v<start-failed> // False) {
                    $r = Result.new(:ok($r.ok), :code($r.code), :op($r.op),
                                    :out(''), :err(''),
                                    :value($r.value), :elapsed($r.elapsed),
                                    :streamed(True));
                }
            }
            elsif $tty-mode {
                my $hook = self.tty-handler;
                if $hook.defined {
                    # worker 模式：交回父进程执行（ADR-0021 §4）。
                    # hook 自己不抛：它把父进程的结果包装成 Result。
                    $r = $hook($exe, @argv);
                }
                else {
                    # 非 TTY 时 Sys 会抛 X::Rakuish::Unsupported；收敛成失败 Result，
                    # 不让异常穿透 eval-line（管道/脚本必须保持干净）。
                    my Str $start-err = '';
                    {
                        CATCH { default { $start-err = .message } }
                        $r = $.sys.tty-exec($exe, |@argv);
                    }
                    $r = Result.new(:!ok, :code(127), :op<tty-exec>,
                                    :err($start-err)) unless $r.defined;
                }
            }
            else {
                my %to = $timeout-ms >= 0 ?? ('timeout-ms' => $timeout-ms) !! %();
                # 0.145.0 / V-349（P2）：单条命令的 stdin 也可以从文件来。
                %to<stdin-file> = $stdin-file if $stdin-file.chars;
                my Bool $want-stream = $.stream-out && !$capture;
                if $want-stream {
                    my &emit-out = -> Str $t { self!emit-chunk('out', $t) };
                    my &emit-err = -> Str $t { self!emit-chunk('err', $t) };
                    $r = $.sys.exec($exe, |@argv, |%to,
                                    :on-out(&emit-out), :on-err(&emit-err));
                    # 启动失败时没有任何 chunk，err 必须留给 render；
                    # 正常结束则输出已经实时写过，不能再由 render 重放一遍。
                    my %v = ($r.value ~~ Hash) ?? %($r.value) !! %();
                    unless ?(%v<start-failed> // False) {
                        $r = Result.new(:ok($r.ok), :code($r.code), :op($r.op),
                                        :out(''), :err(''),
                                        :value($r.value), :elapsed($r.elapsed),
                                        :streamed(True));
                    }
                }
                else {
                    $r = $.sys.exec($exe, |@argv, |%to);
                }
            }
            self!remember($r);
            return self!strict-result($r);
        }
    }
    Nil
}