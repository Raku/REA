# Rakuish::REPL::Session::Cells —— 格记录的查看与导出（0.149.0 / ADR-0063 / V-353）
#
# 与 log / history 的分工：
#   · history 只有输入；
#   · log 是人读的文本抄本（受 log on/off 影响）；
#   · cells 是**结构化**的格记录：输入 + 渲染文本 + 成败 + 耗时。
#     不带参数列出来，`--text` / `--json` 导出。
#
# 状态归属（ADR-0060 §3.2 的规矩）：属性都在 Session 类上，本 role 只经
# 公开访问器读写 —— @.cells（格表本体）、$.skip-cell（本命令不留痕）、
# $.sys（resolve / write / cwd）。
#
# 唯一朝外的私有调用是 Session 的 !split-argv：argv 切分属于求值器的
# 输入层，不是导出层的一部分（role 调类私有方法合法，ADR-0060 §2）。

unit role Rakuish::REPL::Session::Cells;

use Rakuish::Result;
use JSON::Fast;        # --json 导出（to-json）

# ── cells：查看 / 导出本会话的格记录（0.115.0 / V-307）──────────────────
# 与 `log` / `history` 的分工：
#   · `history` 只有输入；
#   · `log` 是人读的文本抄本（还受 log on/off 影响）；
#   · `cells` 是**结构化**的格记录：输入 + 渲染文本 + 成败 + 耗时。
#     不带参数就列出来，带 `--text` / `--json` 就导出。
#
# 名字不叫 `export`：那是 Shell 薄层的环境变量导出（`export FOO=1`），
# 抢过来等于把 shell 习惯拆掉半边（t/10 立刻会红）。
method !cmd-cells(Str $raw --> Result) {
    # 无论成功失败都不把自己记进格表（见 $.skip-cell 的注释）。
    LEAVE { $.skip-cell = True }
    my Str $usage = '用法: cells [--json|--text] [<文件|->]'
        ~ "\n  不带参数：列出本会话的格记录（编号 / 状态 / 耗时 / 输入）"
        ~ "\n  --text  导出可重放脚本：只写输入，可直接 `rakuish 文件` 或 `source 文件`"
        ~ "\n  --json  导出结构化记录：input / rendered / ok / op / code / ms / index"
        ~ "\n  `-` 代替文件名 = 打到 stdout；格数上限 500（最近的）；与 log 开关无关";

    my Str $trimmed = $raw.trim;
    my Str $body = $trimmed.chars > 5 ?? $trimmed.substr(5).trim !! '';
    my @argv = $body.chars ?? self!split-argv($body) !! ();
    my Str $fmt = 'text';
    my Str $path = '';
    for @argv -> $a {
        my Str $s = $a.Str;
        given $s {
            when '--json' { $fmt = 'json' }
            when '--text' { $fmt = 'text' }
            when '--help' | '-h' {
                return Result.new(:ok, :op<cells>, :out($usage));
            }
            when '-' { $path = $s }
            default {
                return Result.new(:!ok, :code(2), :op<cells>,
                    :err("cells: 未知选项 {$s}\n{$usage}")) if $s.starts-with('-');
                return Result.new(:!ok, :code(2), :op<cells>,
                    :err("cells: 只接受一个输出文件\n{$usage}")) if $path.chars;
                $path = $s;
            }
        }
    }

    # 不带输出文件 = 看记录（这是最常用的；导出要求显式给路径或 `-`）。
    if !$path.chars {
        return Result.new(:ok, :op<cells>,
                          :out(self!render-cells-list(@.cells.List)));
    }
    unless @.cells.elems {
        return Result.new(:!ok, :code(1), :op<cells>,
                          :err('cells: 还没有可导出的格'));
    }

    my @cells = @.cells.List;
    my Str $text = $fmt eq 'json' ?? self!render-cells-json(@cells)
                                  !! self!render-cells-text(@cells);

    if $path eq '-' {
        return Result.new(:ok, :op<cells>, :out($text),
                          :value(%( cells => @cells.elems, format => $fmt )));
    }

    my IO::Path $target;
    my Str $perr = '';
    {
        CATCH { default { $perr = .message } }
        $target = $.sys.resolve($path);
    }
    return Result.new(:!ok, :code(127), :op<cells>,
                      :err("cells: {$perr}")) if $perr.chars;

    my Str $werr = '';
    {
        CATCH { default { $werr = .message } }
        $.sys.write($target, $text);
    }
    return Result.new(:!ok, :code(1), :op<cells>,
                      :err("cells: 写入失败（{$werr}）")) if $werr.chars;

    Result.new(:ok, :op<cells>,
        :out("已导出 {@cells.elems} 格（{$fmt}）→ {$target.Str}"),
        :value(%( cells => @cells.elems, format => $fmt, path => $target.Str )));
}

# 不带参数时的列表：编号 / 状态 / 耗时 / 输入（多行只留首行）。
# 列宽按实际内容算，中文输入不会把表撑歪（宽度按字符数，不按显示宽度：
# 这一列是代码，中文只出现在注释里，凑合够用 —— 不做 wcwidth 那一套）。
method !render-cells-list(@cells --> Str) {
    return '（还没有格记录）' unless @cells.elems;
    my @out;
    for @cells -> %c {
        my Str $in = (%c<input> // '').Str;
        # 多行格只留首行：列表是索引，不是抄本。
        my Str $first = $in.contains("\n") ?? $in.lines[0] ~ ' …' !! $in;
        # 编号用 seq 而不是 Out 号：失败的格不占 Out[n]（既定契约），
        # 拿 index 当编号会出现两个「2」。
        @out.push(sprintf('%-3d %-4s %4dms  %s',
                          (%c<seq> // 0).Int,
                          ?(%c<ok> // False) ?? 'ok' !! 'ERR',
                          (%c<ms> // 0).Int,
                          $first));
    }
    @out.push('');
    @out.push("共 {@cells.elems} 格 · 列依次是 编号 / 状态 / 耗时 / 输入"
              ~ "（失败格不占 Out[n]，所以编号与 Out 号会错开）");
    @out.push('导出：cells --text 文件（可重放）· cells --json 文件（结构化）');
    @out.join("\n");
}

# `--text`：只写输入。多行格原样保留（`!finish` 存的就是完整源码）。
# 开头给一段注释，说明怎么重放 —— 导出的文件本身就该能跑。
#
# 两条必要的修补：
#   · **每格补语句结束符**：REPL 里一格是一次独立 EVAL，`1+1` 后面不带 `;`
#     也没事；拼成整份脚本后 `1+1` 紧跟 `my $x = 1;` 会被读成「两个项连写」
#     （实测：Two terms in a row）。补 `;` 后两种重放方式都成立。
#   · **`no worries;`**：脚本模式下裸表达式会报 "Useless use ... in sink
#     context"，几十格导出来就是几十条噪音。REPL 里这些值本来就展示了。
method !render-cells-text(@cells --> Str) {
    my Str $when = DateTime.now.Str;
    my @lines;
    @lines.push("# rakuish 会话导出 · {$when} · {@cells.elems} 格");
    @lines.push('# 重放：rakuish 本文件（或会话里 source 本文件）');
    @lines.push('# 只含输入、不含输出；失败的格也照原样保留；每格补了语句结束符');
    @lines.push('');
    @lines.push('no worries;   # 脚本模式下表达式的 sink 警告是噪音');
    @lines.push('');
    for @cells -> %c {
        my Str $src = (%c<input> // '').Str;
        @lines.push($src);
        next if !$src.chars || $src.trim.ends-with(';');
        my Str $last = $src.lines.grep({ .trim.chars }).tail // '';
        # 行尾有注释：分号只能另起一行，否则会落进注释里。
        if $last.contains('#') { @lines.push(';') }
        else { @lines[*-1] = $src ~ ';' }
    }
    @lines.join("\n") ~ "\n";
}

# `--json`：结构化记录。字段名用短横线（与审计账本、快照保持同一风格），
# `rendered` 缺失时给空串 —— 前端没调 log-line 的路径（`-e` / 管道）不会崩。
method !render-cells-json(@cells --> Str) {
    my @rows = @cells.map(-> %c {
        %(
            seq      => (%c<seq>   // 0).Int,
            index    => (%c<index> // 0).Int,
            input    => (%c<input> // '').Str,
            rendered => (%c<rendered> // '').Str,
            ok       => ?(%c<ok> // False),
            op       => (%c<op>    // '').Str,
            code     => (%c<code>  // 0).Int,
            ms       => (%c<ms>    // 0).Int,
        );
    });
    to-json(%(
        format         => 'rakuish-cells',
        'format-version' => 1,
        'exported-at'  => DateTime.now.Str,
        cwd            => $.sys.cwd.Str,
        count          => @rows.elems,
        cells          => @rows,
    ), :pretty);
}
