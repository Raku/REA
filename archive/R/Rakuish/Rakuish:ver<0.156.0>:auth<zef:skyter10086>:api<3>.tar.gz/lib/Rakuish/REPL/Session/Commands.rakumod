unit role Rakuish::REPL::Session::Commands;

# Rakuish::REPL::Session 的会话命令层（0.146.0 / V-350 / ADR-0060）。
#
# 这里只放**命令实现**，不放求值核心。所有方法都是 `!` 私有的，由
# Session 的 `!eval-line-body` 在识别出命令首词后调用；对用户可见的
# 仍然只有「一行命令」这一种入口。
#
# 为什么是 role 而不是「外部协作者类」：Rakudo v2026.11 的 `trusts`
# 根本没有实现（`class A trusts B { }` 直接 `Unable to parse class
# definition`），跨类访问私有属性这条路不存在；而 role 自己声明的私有
# 属性会被组合进类，**role 的方法和类自己的方法都能读到**（0.146.0
# 拆分前用探针实测过，见 ADR-0060 §2）。所以属性跟着方法一起搬进来，
# 原地组合，行为不变。

use Rakuish::Result;

# 错误分级（0.140.0 / V-344）。属性跟着 `!cmd-errors` 搬进来：
# `!eval-raku` 里的 CATCH 也要写它们，而类方法读 role 私有属性是允许的。
has Str $.error-mode is rw = 'short';
has Str $!last-error-kind = '';
has Str $!last-error-loc  = '';

# ── 0.140.0 / P2.2 / V-344：errors [short|full] ──────────────────────
# 只切**显示**，不改判定：求值行为、Result.ok/code、异常对象都照旧。
method !cmd-errors(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my Str $arg = $t.chars > 6 ?? $t.substr(6).trim !! '';
    my Str $usage = '用法: errors [short|full]'
        ~ "\n  不带参数：显示当前分级"
        ~ "\n  short（默认）：一行「类型: 消息（第 N 格第 M 行）」，不跟 backtrace"
        ~ "\n  full：同一行 + 完整回放帧（等价 repl.trace = True）"
        ~ "\n  类型分三种：编译错误 / 运行错误 / 被拒绝（X::Rakuish::* 自己判定的失败）";
    return Result.new(:ok, :op<errors>, :value($usage), :out($usage))
        if $arg eq '--help' || $arg eq '-h';
    if !$arg.chars {
        my Str $desc = $!error-mode eq 'full'
            ?? '完整回放（错误头 + backtrace 帧）'
            !! '一行（类型: 消息，能定位时附 第 N 格第 M 行）';
        my Str $out = "错误显示: {$!error-mode} —— {$desc}";
        return Result.new(:ok, :op<errors>, :value($!error-mode), :out($out));
    }
    my Str $mode = $arg.lc;
    unless $mode eq 'short' || $mode eq 'full' {
        return Result.new(:!ok, :code(2), :op<errors>, :err($usage));
    }
    $!error-mode = $mode;
    Result.new(:ok, :op<errors>, :value($mode), :out("错误显示: {$mode}"));
}
