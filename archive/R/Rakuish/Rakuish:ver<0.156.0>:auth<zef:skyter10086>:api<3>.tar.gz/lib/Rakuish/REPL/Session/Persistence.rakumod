# Rakuish::REPL::Session::Persistence —— 快照 + store（0.148.0 / ADR-0062 / V-352）
#
# 两个功能都是「跨会话保存 / 恢复」，共用同一套重放语义：先把用户声明当
# prelude 重编译，再在同一 EVAL 里求值（Raku 的 EVAL 定义的类型不跨 EVAL
# 存活，ADR-0022 §4 记过）。区别在触发方式：
#   · 快照：每格成功后自动写，按 cwd 分文件，只存声明 + 纯值；
#   · store：用户点名的显式导出，跨目录共用一份，拒绝要带理由。
#
# 状态归属（ADR-0061 §3.2 的规矩）：属性都在 Session 类上，本 role 只经
# 公开访问器读写 —— $.snapshot-on / $.snapshot-path / $.store-path /
# $.index / $.sys / %.state / @.decls / %.restored-info / @.restore-failed。
#
# EVAL 不在本文件里做：EVAL 的词法包决定用户 `my class Foo` 的命名空间，
# 在 role 里 EVAL 会得到 `…::Persistence::Foo`，快照里 `.raku` 的前缀就
# 剥不干净。所以恢复统一走 Session 的 !eval-in-session（ADR-0062 §3）。

unit role Rakuish::REPL::Session::Persistence;

use Rakuish::Result;
use Rakuish::Audit;       # 快照路径用同一个 FNV 指纹（ADR-0022）
use Rakuish::Snapshot;    # 会话快照（ADR-0022）
use Rakuish::Store;       # 跨会话变量库（ADR-0053）

# ── 会话快照（0.84.0 / ADR-0022）─────────────────────────────────────
# 路径：RAKUISH_SNAPSHOT 显式指定 → $*HOME/.rakuish/session-<cwd指纹>.json
# → 空（纯内存）。按 cwd 分文件是为了让不同项目的会话互不覆盖。
method !init-snapshot(--> Nil) {
    $.snapshot-on = !(%*ENV<RAKUISH_NO_SNAPSHOT> // '').Str.chars;
    my Str $p = (%*ENV<RAKUISH_SNAPSHOT> // '').Str;
    unless $p.chars {
        my $home = try { $*HOME };
        if $home.defined {
            my $d = $home.add('.rakuish');
            my Str $key = Rakuish::Audit::fingerprint($.sys.cwd.Str).substr(0, 12);
            $p = $d.add("session-{$key}.json").Str;
        }
    }
    $.snapshot-path = $p;
    Nil
}

# 每格成功后调用。任何失败都吞掉：快照是**附加价值**，
# 不能因为它写不出去就让求值失败。
method save-snapshot(--> Nil) {
    return unless $.snapshot-on && $.snapshot-path.chars;
    my %snap = Rakuish::Snapshot::capture(
        %.state, @.decls,
        :cwd($.sys.cwd.Str),
        :session('local'),
        :rakuish(($?DISTRIBUTION.meta<version> // '').Str),
    );
    try { Rakuish::Snapshot::save(%snap, $.snapshot-path.IO) };
    Nil
}

# 从快照恢复。只做两件事：把声明填回缓存、把纯值灌回 %.state。
# 返回摘要 %( decls, vars, failed, saved-at )。
#
# 值必须**带着 prelude 一起 EVAL**：Raku 的 `EVAL` 定义的类型不会跨 EVAL
# 存活（实测），所以 `Foo.new(...)` 单独求值只会得到「Undeclared routine」。
method restore-snapshot(%snap --> Hash) {
    my @decls = (%snap<decls> // []).List;
    my %values = (%snap<state> // %{}).Hash;
    return %( decls => 0, vars => 0, failed => ().List, 'saved-at' => '' )
        unless @decls.elems || %values.elems;

    my @srcs;
    for @decls -> %d {
        my Str $src = (%d<src> // '').Str;
        next unless $src.chars;
        @srcs.push($src);
        @.decls.push(%(
            key       => (%d<key>  // '').Str,
            src       => $src,
            name      => (%d<name> // '').Str,
            'is-type' => ?(%d{'is-type'} // False),
        ));
    }

    my Int $ok-vars = 0;
    my @failed;
    my @pairs;          # (name, raku)
    for %values.kv -> $k, %c {
        given (%c<kind> // '').Str {
            when 'value' { @pairs.push(($k, (%c<raku> // '').Str)) }
            when 'nil'   { %.state{$k} = Any; ++$ok-vars }
            default      { %.state{$k} = Any; @failed.push($k) }
        }
    }

    if @pairs.elems {
        my Str $pre = @srcs.join("\n");
        # 用户在会话里定义的类由本类的 EVAL 定义，`.raku` 会写成
        # `Rakuish::REPL::Session::Foo.new(...)`。但声明源码是 `my class Foo`
        # —— `my` 类型不以全名注册，直接用全名构造会「找不到类型」。
        # 所以恢复前把本类前缀剥掉，让它按短名解析（同一 EVAL 块内可见）。
        my Str $pkg = self.WHAT.^name ~ '::';
        my Str $body = @pairs.map({ "'{.[0]}' => { .[1].subst($pkg, '', :g) }" }).join(",\n");
        my $bag;
        my Str $batch-err = '';
        {
            CATCH { default { $batch-err = .message } }
            $bag = self!eval-in-session("no worries; do \{ $pre \n %( $body ) }");
        }
        if $bag.defined && $bag ~~ Hash {
            for $bag.kv -> $k, $v { %.state{$k} = $v; ++$ok-vars }
        }
        else {
            # 批量失败（某个值依赖恢复不回来的东西）就逐个来：
            # 能救几个是几个，救不回的进 failed 列表。
            for @pairs -> $p {
                my $v;
                {
                    CATCH { default { } }
                    $v = self!eval-in-session("no worries; do \{ $pre \n { $p[1].subst($pkg, '', :g) } }");
                }
                if $v.defined || $p[1] eq 'Any' {
                    %.state{$p[0]} = $v;
                    ++$ok-vars;
                }
                else {
                    %.state{$p[0]} = Any;
                    @failed.push($p[0]);
                }
            }
        }
    }

    $.index = 0;
    %.restored-info = %(
        decls    => @srcs.elems,
        vars     => $ok-vars,
        failed   => @failed.List,
        'saved-at' => (%snap{'saved-at'} // '').Str,
    );
    @.restore-failed = @failed.List;
    %.restored-info;
}

method restored(--> Hash) { %.restored-info }

# ── store：跨会话变量库（0.139.0 / V-343，评审 P2.6）────────────────────
# IPython 的 `%store`：点名保存几个变量，换个会话 `store -r` 拿回来。
# 判定复用 Rakuish::Snapshot::classify —— 闭包 / 资源 / 超限一律拒绝并给理由。
# 快照里「标记失效、恢复成 Any」是对的（它每格自动跑，不能因为一个闭包就
# 让整次快照失败）；这里反过来：用户点了名，静默跳过等于骗他，必须说清楚
# 为什么存不下。
#
# 为什么不直接复用快照：快照是整个 %.state 的自动镜像、按 cwd 分文件、每次
# 成功格都重写；`store` 是显式导出，跨目录共用一份，只写用户点名的那几个。
#
# 名字解析（`$x` / `x` 都认）：IPython 没有 sigil，Raku 有。用户不带 sigil 时
# 按 $ @ % & 找唯一匹配；两个都命中就报「名字不唯一」，而不是替他挑一个。
method !cmd-store(Str $raw --> Result) {
    my Str $usage = '用法: store [-r|-d|-l] [--clear] [-f 文件] [名字...]'
        ~ "\n  不带模式：把变量存进库（跨会话、跨目录；默认 \$*HOME/.rakuish/store.json）"
        ~ "\n  -r（--recall）：从库里读回变量    -d（--delete）：从库里删掉"
        ~ "\n  -l（--list）：库里有什么          --clear：清空库"
        ~ "\n  名字可带 sigil（\$x / @rows / %cfg）；不带 sigil 时自动找唯一匹配";

    my @tok = $raw.trim.split(/\s+/);
    my @names;
    my Str $mode = 'save';
    my Str $file = '';
    my Bool $clear = False;
    my Bool $help = False;
    my Str $bad = '';
    my Int $i = 1;
    while $i < @tok.elems {
        my Str $a = @tok[$i];
        if $a eq '--help' || $a eq '-h' {
            $help = True;
        }
        elsif $a eq '-r' || $a eq '--recall' {
            if $mode ne 'save' && $mode ne 'recall' { $bad = 'store: 一次只能用一个模式（-r / -d / -l）'; }
            else { $mode = 'recall'; }
        }
        elsif $a eq '-d' || $a eq '--delete' {
            if $mode ne 'save' && $mode ne 'delete' { $bad = 'store: 一次只能用一个模式（-r / -d / -l）'; }
            else { $mode = 'delete'; }
        }
        elsif $a eq '-l' || $a eq '--list' {
            if $mode ne 'save' && $mode ne 'list' { $bad = 'store: 一次只能用一个模式（-r / -d / -l）'; }
            else { $mode = 'list'; }
        }
        elsif $a eq '--clear' {
            $clear = True;
        }
        elsif $a eq '-f' || $a eq '--file' {
            ++$i;
            if $i < @tok.elems { $file = @tok[$i] }
            else { $bad = 'store: -f 后面要给文件路径'; }
        }
        elsif $a.starts-with('-') {
            $bad = "store: 未知选项 {$a}";
        }
        else {
            @names.push($a);
        }
        last if $bad.chars;
        ++$i;
    }
    return Result.new(:ok, :op<store>, :out($usage)) if $help;
    if $bad.chars {
        return Result.new(:!ok, :code(2), :op<store>, :err($bad ~ "\n" ~ $usage));
    }
    if $clear && $mode ne 'save' {
        return Result.new(:!ok, :code(2), :op<store>,
            :err('store: --clear 不跟 -r / -d / -l 一起用' ~ "\n" ~ $usage));
    }

    my $path = $file.chars ?? $file.IO
             !! ($.store-path.chars ?? $.store-path.IO !! Rakuish::Store::store-path);
    my Str $where = $path.Str;
    my %data = Rakuish::Store::load($path);
    my %vars = (%data<vars> // %{}).Hash;

    # --clear：清空库里所有变量（文件本身留着，只是 vars 变空）。
    if $clear {
        my Int $before = %vars.keys.elems;
        my Bool $ok2 = Rakuish::Store::save(Rakuish::Store::empty-store(), $path);
        return $ok2
            ?? Result.new(:ok, :op<store>, :value(().List),
                          :out("store: 已清空 {$where}（原来 {$before} 个变量）"))
            !! Result.new(:!ok, :code(1), :op<store>, :err("store: 写不进去: {$where}"));
    }

    # -l：只读，一行一个变量（名字 / 类型 / 长度的量级 / 保存时间）。
    if $mode eq 'list' {
        if @names.elems {
            return Result.new(:!ok, :code(2), :op<store>,
                :err("store: -l 不接受名字（{@names.join(' ')}）" ~ "\n" ~ $usage));
        }
        unless %vars.elems {
            return Result.new(:ok, :op<store>, :value(().List),
                              :out("库是空的（{$where}）"));
        }
        my @rows;
        my Int $wn = 0;
        my Int $wt = 0;
        for %vars.keys.sort -> $k {
            my %e = (%vars{$k} // %{}).Hash;
            my Str $tp = (%e<type> // 'Any').Str;
            my Str $rk = (%e<raku> // '').Str;
            my Str $at = (%e<saved-at> // '').Str;
            $wn = $k.chars if $k.chars > $wn;
            $wt = $tp.chars if $tp.chars > $wt;
            @rows.push([$k, $tp, $rk.chars, $at]);
        }
        my @lines = ("库: {$where}（{%vars.keys.elems} 个变量）",);
        for @rows -> $r {
            @lines.push('  ' ~ $r[0] ~ (' ' x ($wn - $r[0].chars + 2))
                             ~ $r[1] ~ (' ' x ($wt - $r[1].chars + 2))
                             ~ "{$r[2]} 字符  {$r[3]}");
        }
        return Result.new(:ok, :op<store>, :value(%vars.keys.List), :out(@lines.join("\n")));
    }

    # -d：从库里删掉点名的变量。库里没有的名字照常报出来（删不到 ≠ 成功）。
    if $mode eq 'delete' {
        unless @names.elems {
            return Result.new(:!ok, :code(2), :op<store>,
                :err('store: 要删哪些变量？' ~ "\n" ~ $usage));
        }
        my @gone;
        my @miss;
        for @names -> $given {
            my @cand = self!store-candidates($given, %vars.keys.List);
            if !@cand.elems { @miss.push($given); }
            elsif @cand.elems > 1 { @miss.push("{$given}（名字不唯一: {@cand.join(' / ')}）"); }
            else { %vars{@cand.head}:delete; @gone.push(@cand.head); }
        }
        my Bool $ok2 = Rakuish::Store::save(%( vars => %vars ), $path);
        my Str $msg = $ok2
            ?? "store: 从 {$where} 删了 {@gone.elems} 个变量" ~ (@gone.elems ?? ": {@gone.join(' ')}" !! '')
            !! "store: 写不进去: {$where}";
        my Str $err = @miss.elems ?? "库里没有: {@miss.join(', ')}（store -l 看有什么）" !! '';
        return Result.new(:ok($ok2 && !@miss.elems), :code($ok2 && !@miss.elems ?? 0 !! 1),
                          :op<store>, :value(@gone.List), :out($msg), :err($err));
    }

    # -r：读回。值带着 prelude 一起 EVAL —— Raku 的 EVAL 定义的类型不跨 EVAL
    # 存活（快照恢复踩过这个坑，ADR-0022 §4）。prelude = 本会话声明 + 条目里
    # 存的声明（条目声明让「换个会话」也能还原用户类实例）。
    if $mode eq 'recall' {
        unless @names.elems {
            return Result.new(:!ok, :code(2), :op<store>,
                :err('store: 要读回哪些变量？（store -l 看有什么）' ~ "\n" ~ $usage));
        }
        my Int $n = 0;
        my @err;
        my @restored;
        my Str $pkg = self.WHAT.^name ~ '::';
        for @names -> $given {
            my @cand = self!store-candidates($given, %vars.keys.List);
            if !@cand.elems {
                @err.push("库里没有: {$given}（store -l 看有什么）");
                next;
            }
            if @cand.elems > 1 {
                @err.push("{$given} 名字不唯一: {@cand.join(' / ')}（请带 sigil）");
                next;
            }
            my Str $key = @cand.head;
            my %e = (%vars{$key} // %{}).Hash;
            my Str $raku = (%e<raku> // '').Str;
            if !$raku.chars {
                @err.push("{$key} 的条目是空的（store -d 删掉重存）");
                next;
            }
            my @srcs;
            for @.decls -> $d {
                my Str $s = self!store-decl-src($d);
                @srcs.push($s) if $s.chars;
            }
            for (%e<decls> // []).List -> $d {
                my Str $s = self!store-decl-src($d);
                @srcs.push($s) if $s.chars;
            }
            my Str $pre = @srcs.join("\n");
            my $v;
            my Str $why = '';
            {
                CATCH { default { $why = .message } }
                $v = self!eval-in-session("no worries; do \{ $pre \n { $raku.subst($pkg, '', :g) } }");
            }
            if $v.defined || $raku eq 'Any' {
                %.state{$key} = $v;
                @restored.push($key);
                ++$n;
            }
            else {
                @err.push("{$key} 读不回来" ~ ($why.chars ?? "：{$why}" !! '（依赖的声明 / 模块不在本会话？）'));
            }
        }
        my Str $msg = "store: 从 {$where} 读回 {$n} 个变量";
        return Result.new(:ok($n > 0 && !@err.elems), :code($n > 0 && !@err.elems ?? 0 !! 1),
                          :op<store>, :value(@restored.List), :out($msg), :err(@err.join("\n")));
    }

    # 默认：保存。先判可序列化，拒绝的带理由；然后一次性落盘。
    unless @names.elems {
        return Result.new(:!ok, :code(2), :op<store>,
            :err('store: 要保存哪些变量？' ~ "\n" ~ $usage));
    }
    my Int $saved = 0;
    my @err;
    my @saved-lines;
    my Int $max = Rakuish::Snapshot::max-value-chars();
    for @names -> $given {
        my @cand = self!store-candidates($given, %.state.keys.List);
        if !@cand.elems {
            @err.push("本会话没有变量: {$given}");
            next;
        }
        if @cand.elems > 1 {
            @err.push("{$given} 名字不唯一: {@cand.join(' / ')}（请带 sigil）");
            next;
        }
        my Str $key = @cand.head;
        my %c = Rakuish::Snapshot::classify(%.state{$key}, :max($max));
        if (%c<kind> // '').Str eq 'invalid' {
            @err.push("{$key} 不能保存: {(%c<reason> // '不可序列化').Str}");
            next;
        }
        my Str $type = (%c<type> // 'Any').Str;
        my Str $raku = (%c<raku> // 'Any').Str;
        my Str $short = $type.split('::').tail;
        my @dep = @.decls.grep(-> $d {
            my Str $n = ($d<name> // '').Str;
            $n.chars && ($n eq $short || $raku.contains('::' ~ $n ~ '.'));
        }).List;
        %vars{$key} = Rakuish::Store::entry(%c, $.sys.cwd.Str, @dep);
        @saved-lines.push("{$key} ({$type}, {$raku.chars} 字符)");
        ++$saved;
    }
    my Bool $ok2 = $saved > 0 ?? Rakuish::Store::save(%( vars => %vars ), $path) !! False;
    my Str $msg = $ok2
        ?? "store: 保存 {$saved} 个变量到 {$where}"
        !! ($saved > 0 ?? "store: 写不进去: {$where}" !! '');
    my @out;
    @out.push($msg) if $msg.chars;
    for @saved-lines -> $l { @out.push("  {$l}") }
    return Result.new(:ok($ok2 && !@err.elems), :code($ok2 && !@err.elems ?? 0 !! 1),
                      :op<store>, :value(%vars.keys.List), :out(@out.join("\n")),
                      :err(@err.join("\n")));
}

# 名字 → 库 / 会话里的键：带 sigil 就原样比对，不带就按 $ @ % & 找候选。
# 返回候选列表而不是一个答案 —— 「不唯一」是必须报出来的情况，不是选择题。
method !store-candidates(Str $given, @keys --> List) {
    my Str $c0 = $given.substr(0, 1);
    my @out;
    if $c0 ~~ /^ <[ $ @ % & ]> $/ {
        @out.push($given) if @keys.first(-> $k { $k eq $given }).defined;
        return @out.List;
    }
    for <$ @ % &> -> $sig {
        my Str $k = $sig ~ $given;
        @out.push($k) if @keys.first(-> $x { $x eq $k }).defined;
    }
    @out.List;
}

# 重放声明前的归一化：与 !eval-raku / 快照恢复同一套（0.132.1 / V-334）。
# 不给 `my` 的 enum / subset 会装进 GLOBAL，第二次 EVAL 直接
# 「Redeclaration of symbol」把会话锁死 —— 对旧快照和别的会话的条目同样适用。
method !store-decl-src($d --> Str) {
    my Str $s = ($d<src> // '').Str;
    return '' unless $s.chars;
    if $s ~~ /^ (class|role|grammar|subset|enum|constant) \s / {
        'my ' ~ $s;
    }
    else {
        $s;
    }
}
