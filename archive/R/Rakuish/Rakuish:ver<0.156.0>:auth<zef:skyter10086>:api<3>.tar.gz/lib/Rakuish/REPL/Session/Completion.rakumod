# Rakuish::REPL::Session::Completion —— 补全层（0.151.0 / ADR-0065 / V-355）
#
# 搬走的 5 个方法：
#   completions（公开 API：CLI 的 get-completions 回调、LineEditor、t/10 / t/23 / t/25）
#   !session-name-completions / !method-completions / !completion-value / !resolve-type
#
# 状态归属（ADR-0060 §3.2 / ADR-0064 §3：公开与否看「外部是否该看见」）：
#   @.out / @.history / @.decls / %.state / $.shell / $.engine 本来就是公开面；
#   类型缓存仍是 Session 的私有属性 —— role 经 self!type-cache 拿活容器读写。
#   缓存不能跟着搬：!eval-raku 出现新 use 时要整块作废，那句留在 Session。
#
# EVAL：!resolve-type 要重放会话声明再解析类型名，走 Session 的
#   !eval-in-session（ADR-0062 §3：role 里 EVAL 会把用户声明落到 role 包名下）。
#
# 留在 Session：error-marks / !known-name / !path-names —— 错误态标红用，
#   与补全管线不共用状态（名字解析只是碰巧都读 @.decls）。
unit role Rakuish::REPL::Session::Completion;

use Rakuish::REPL::Complete;      # common-prefix / in-out-completions
use Rakuish::REPL::Methods;       # method-context / method-names / filter-names
use Rakuish::REPL::SqlComplete;   # sql-completions
method completions(Str $line, Int $pos --> List) {
    # In[n] / Out[n] 引用补全（V-285 / V-322）：两者长度不同 —— `In` 是输入
    # 历史（含失败格与会话命令），`Out` 只记成功结果，所以分开传。
    my @refs = in-out-completions($line, $pos, @.out.elems,
                                  :in-count(@.history.elems));
    return @refs.List if @refs.elems;

    # 0.107.0 / V-298：`$obj.` / `Type::Name.` 的方法名补全。命中就接管，
    # 不再往 Shell 走（Shell 对含 `$` 的前缀本来就返回空）。
    my @meth = self!method-completions($line, $pos);
    return @meth.List if @meth.elems;

    # SQL 字符串上下文优先（纯函数、engine 缺失/异常时返回空）。
    my @sql = sql-completions($line, $pos, :engine($.engine));
    return @sql.List if @sql.elems;

    # 0.156.0 / V-364：字符串字面量里的路径（`open-data('tmp/`）。
    # Shell 对含引号的前缀返回空，这里把引号之后的部分当路径补，并把引号
    # 原样拼回去。只认单引号 —— 双引号里 `$var/` 会插值，候选全是幻觉。
    my @str-path = self!string-path-prefix($line, $pos);
    if @str-path.elems {
        my @c = $.shell.path-completions(@str-path[1], :before(@str-path[0]));
        return @c.List if @c.elems;
    }

    # 0.127.0 / §4.7：会话名字补全（变量 / sub / class / 模块名）+ Shell 补全合并。
    # 会话名字在前（用户声明的优先），Shell 命令/路径在后，统一去重。
    my @names = self!session-name-completions($line, $pos);
    my @shell = $.shell.completions($line, $pos).List;
    # 0.154.0 / V-358：这里必须两个都带 `|`。写成 `(@names, |@shell)` 时
    # @names 不会被展平——候选表首位会是一个 Array（如 ["class","constant"]），
    # 编辑器把它插进输入行就成了 `class constant`。实测：`my @x=<a b>; (@x, |@y)`
    # 得到 `(["a","b"], ...)`。
    my @c = (|@names, |@shell).grep({ .defined && .Str.chars }).unique(:as(*.Str));

    # 公共前缀优先（V-278）：多候选共享更长前缀时，Tab 序列首位放前缀
    # 补全（首位无尾随空格），其后才是逐个候选——等价 fish 的「先补最长
    # 公共前缀」。上游 do-complete 按序循环，不动它的循环逻辑。
    if @c.elems > 1 {
        my Str $cp = common-prefix(@c);
        my Str $typed = $line.substr(0, $pos min $line.chars);
        @c = ($cp, |@c) if $cp.chars > $typed.chars
                        && !@c.first({ .Str eq $cp });
    }
    @c.List;
}

# 0.156.0 / V-364：光标前的「未闭合单引号」前缀。
# 返回 (引号之前含引号的原文, 引号之后的片段)；不在字符串里、或用双引号
# （会插值 $var/...，补出来全是错的）、或片段里有空白（多半是句子不是路径）
# 都返回空列表。
method !string-path-prefix(Str $line, Int $pos --> List) {
    my Str $pre = $line.substr(0, $pos min $line.chars);
    my Int $open = -1;
    my Bool $in = False;
    my Int $i = 0;
    my @ch = $pre.comb;
    while $i < @ch.elems {
        my Str $c = @ch[$i];
        if $c eq '"' { return () }                 # 双引号字符串：不猜
        if $c eq q{'} {
            if $in { $in = False; $open = -1 }
            else   { $in = True;  $open = $i }
        }
        $i++;
    }
    return () unless $in && $open >= 0;
    my Str $frag = $pre.substr($open + 1);
    return () if $frag ~~ /\s/;
    ($pre.substr(0, $open + 1), $frag).List;
}

# ── 会话名字补全（0.127.0 / §4.7）──────────────────────────────────────
# 来源：%.state（变量，含 sigil）、@.decls（sub/class/role/grammar/constant/enum/subset/use）。
# 只补全「用户自己声明过的」名字 —— 比 Jedi/raku-lang server 窄，但零外部依赖。
method !session-name-completions(Str $line, Int $pos --> List) {
    my Str $prefix = $line.substr(0, $pos min $line.chars);
    return () unless $prefix.chars;

    # ── 上下文 1：`use XXX` → 模块名补全 ──
    if $prefix ~~ /^ use \s+ (\S*) $/ {
        my Str $frag = ~$0;
        my @mods;
        for @.decls -> $d {
            next unless ($d<key> // '') ~~ /^ use:/;
            my Str $src = ~($d<src> // '');
            if $src ~~ /^ use \s+ (\w+ [ '::' \w+ ]*) \s* ';'? \s* $/ {
                push @mods, ~$0;
            }
        }
        # 加上已加载的 Raku 内置模块（CORE 里能 resolve 的）
        my @core-mods = <JSON::Fast DB::DuckDB Duckula CSV::Fast HTTP::Tiny
                         Text::Table Digest::SHA Math::Complex
                         NativeCall Terminal::ANSIColor>;
        push @mods, |@core-mods;
        my @filtered = @mods.grep({ .starts-with($frag) }).unique.sort;
        return (@filtered.map({ "use $_" })).List if @filtered.elems;
        return ();
    }

    # ── 上下文 2：以 sigil 开头 → 变量 / &sub 补全 ──
    if $prefix ~~ /^ (<[$@%&]>) (\S*) $/ {
        my Str $sigil = ~$0;
        my Str $frag  = ~$1;
        my @out;
        # %.state 里的变量已经带 sigil
        for %.state.keys.grep({ $_.starts-with($sigil ~ $frag) }) {
            push @out, $_;
        }
        # sub 名加 & 前缀（Raku sub 可以 &name() 调用）
        if $sigil eq '&' {
            for @.decls.grep({ ($_<key> // '') ~~ /^ sub:/ }) -> $d {
                my Str $n = ($d<key> // '') ~~ /^ sub ':' (\w+) $/ ?? ~$0 !! next;
                push @out, "&$n" if $n.starts-with($frag);
            }
        }
        return @out.sort.List if @out.elems;
        return ();
    }

    # ── 上下文 3：普通标识符 → sub/class/role/grammar/constant/enum/subset + 变量名（去 sigil）──
    if $prefix ~~ /^ (<[A..Z a..z _]> \S*) $/ {
        my Str $frag = ~$0;
        my @out;
        # 声明过的类型 / 例程 / 常量
        for @.decls -> $d {
            my Str $k = ~($d<key> // '');
            next if $k ~~ /^ use:/;
            my Str $n = $k ~~ /^ \w+ ':' (\w+) $/ ?? ~$0 !! next;
            push @out, $n if $n.starts-with($frag);
        }
        # 变量名（去 sigil 后匹配，如 $alice → alice）
        for %.state.keys -> $k {
            my Str $n = $k ~~ /^ (<[$@%&]>) (\S+) $/ ?? ~$1 !! next;
            push @out, $n if $n.starts-with($frag);
        }
        # 已 use 的模块名（JSON::Fast, DB::DuckDB ...）—— 支持 bare 标识符
        for @.decls -> $d {
            next unless ($d<key> // '') ~~ /^ use:/;
            my Str $src = ~($d<src> // '');
            if $src ~~ /^ use \s+ (\w+ [ '::' \w+ ]*) / {
                push @out, ~$0 if $0.starts-with($frag);
            }
        }
        # Raku 内置模块（和 use 上下文一致的那批）
        my @core-mods = <JSON::Fast DB::DuckDB Duckula CSV::Fast HTTP::Tiny
                         Text::Table Digest::SHA Math::Complex
                         NativeCall Terminal::ANSIColor>;
        push @out, |@core-mods.grep({ .starts-with($frag) });
        # Raku 内置例程（top 常用的几十条，不然全列出来 100+ 条噪音）
        my @builtins = <say print note warn die exit return if elsif else
                        for while until repeat loop given when where
                        my our constant state has method sub
                        class role grammar subset enum multi
                        use require import
                        True False Nil Any Mu Bool
                        Int Str Num Rat Complex
                        Array Hash List Seq Range Bag Set
                        IO Path Cwd Env>;
        push @out, |@builtins.grep({ .starts-with($frag) });
        my @uniq = @out.unique.sort;
        return @uniq.List if @uniq.elems;
        return ();
    }

    ();
}

# ── 方法名补全（0.107.0 / V-298）─────────────────────────────────────
# `$db.` / `DB::DuckDB.` 之后 Tab 出方法名。解析规则在 Methods（纯函数），
# 取值和类型解析在这里：只有会话知道 %.state、@.out 和已 use 的模块。
method !method-completions(Str $line, Int $pos --> List) {
    my %ctx = method-context($line, $pos);
    return () unless %ctx<target>:exists;

    my Str $target = %ctx<target>.Str;
    my $obj = self!completion-value($target);
    my @names = method-names($obj);
    return () unless @names.elems;

    # 类型对象本身 `.defined` 为假，但方法表是有效的；只有 Any / Mu 这种
    # 「没有值」的占位才不该给补全（否则 `$未赋值.` 会刷一屏 Mu 的方法）。
    unless $obj.defined {
        my Str $tn = (try { $obj.^name.Str }) // '';
        return () if $tn eq 'Any' || $tn eq 'Mu';
    }

    @names = filter-names(@names, %ctx<frag>.Str);
    return () unless @names.elems;

    my Str $base = (%ctx<head>.Str) ~ $target ~ '.';
    my @out = @names.head(120).map({ $base ~ $_ });

    # 与 Shell 的口径一致：多候选时把公共前缀放首位（V-278）；
    # 前缀恰好等于某个候选时不重复塞一份。
    if @out.elems > 1 {
        my Str $cp = common-prefix(@out);
        my Str $typed = $line.substr(0, $pos min $line.chars);
        @out = ($cp, |@out) if $cp.chars > $typed.chars
                            && !@out.first({ .Str eq $cp });
    }
    @out.List;
}

# 目标值：跨格变量 / 结果引用走会话状态，类型名走 !resolve-type。
method !completion-value(Str $target --> Any) {
    return %.state{$target} if %.state{$target}:exists;
    return (@.out.elems ?? @.out[*-1] !! Any) if $target eq '_';
    # 与显示口径一致：显示 `Out[n]` 对应 @.out[n-1]（EVAL 里给用户看到的
    # `Out` 是 `(Any, |@.out)`，前面的 Any 只是占位）。
    # `In[n]` 是输入历史、没有值，不参与方法补全。
    if $target ~~ /^ 'Out' '[' (\d+) ']' $/ {
        my Int $n = +$0;
        return ($n >= 1 && $n <= @.out.elems) ?? @.out[$n - 1] !! Any;
    }
    self!resolve-type($target);
}

# 名字 → 类型对象。必须在 EVAL 里解析：`::("DB::DuckDB")` 是**相对包名**
# 查找，方法自身的编译单元看不到 EVAL 里 use 进来的符号（实测返回 Nil）。
# 所以把已有的 use 行连同名字一起 EVAL 一次；结果按名字缓存（约 4ms/次），
# 新增 use 时整块清缓存。
method !resolve-type(Str $name --> Any) {
    my %cache := self!type-cache;   # Session 里那个私有缓存的活容器
    return %cache{$name} if %cache{$name}:exists;
    my $v = Any;
    if $name ~~ /^ <[A..Z]> <[\w-]>* [ '::' <[\w-]>+ ]* $/ {
        # 0.108.0：prelude 从「只重放 use」扩到「重放全部声明」——
        # 本会话里 `class Box {}` 之后，`Box.<Tab>` 和 `Box?` 都要能用。
        # 失败的声明在 try 里静默，和以前一样退化成 Any（不给候选）。
        my @pre = @.decls.map({ (.<src> // '').Str }).grep({ .chars });
        my Str $prelude = @pre.map(-> $s {
            $s ~~ /^ use \s / && !$s.trim-trailing.ends-with(';') ?? $s ~ ';' !! $s
        }).join("\n");
        # 不能用 `//` 兜底：类型对象本身 `.defined` 为假，会被直接吞成 Any。
        my $r = Any;
        try { $r = self!eval-in-session("no worries; do \{ $prelude \n do \{ $name } \n }") }
        $v = $r unless $r.WHAT.^name eq 'Nil';
    }
    %cache{$name} = $v;
    $v;
}
