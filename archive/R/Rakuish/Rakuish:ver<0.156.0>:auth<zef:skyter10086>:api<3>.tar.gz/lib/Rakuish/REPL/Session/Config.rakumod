unit role Rakuish::REPL::Session::Config;

# Rakuish::REPL::Session 的配置层（0.146.0 / V-350 / ADR-0060）。
#
# 覆盖面：配置文件（config-path / load / save）、`set -o` 选项表、
# alias 与历史展开、hook 表、以及管理它们的四条会话命令
# （alias / unalias / config / hook / plugin）。
#
# 为什么是 role：Rakudo v2026.11 的 `trusts` 没有实现，跨类访问私有属性
# 这条路不存在；而 role 自己声明的私有属性会被组合进类，
# **role 的方法和类自己的方法都能读到**。所以 `%.config` 等状态跟着
# 这一组方法一起搬进来，原地组合，行为不变（探针与全套件实测见 ADR-0060）。

use Rakuish::Result;
use JSON::Fast;
use Rakuish::REPL::Shell;

# ── 本组自有的状态 ────────────────────────────────────────────────────
# `%.config` 在搬走前只被这一组方法引用（脚本统计：移内 18 次 / 移外 0 次），
# 所以整组搬走不牵动求值核心。其余四个是 `set -o` 的开关，同样只属于这一组。
# ── 配置 / alias ─────────────────────────────────────────────────────
method config-path(--> IO::Path) {
    my $env = %*ENV<RAKUISH_CONFIG>;
    return IO::Path.new($env) if $env.defined && $env.chars;
    my $home = try { $*HOME } // $*CWD;
    $home.add('.rakuish-config.json');
}


method !load-config(--> Nil) {
    my $p = self.config-path;
    return unless $p.e;
    my $data = try { from-json($p.slurp) };
    %.config = $data.Hash if $data ~~ Hash;
    Nil
}


method !save-config(--> Nil) {
    my $p = self.config-path;
    try { $p.parent.mkdir unless $p.parent.d; $p.spurt(to-json(%.config, :pretty)); }
    Nil
}

# ── set -o 选项（0.90.0 / ADR-0025）──────────────────────────────────
# 每个选项都必须有执行点；这张表同时是 `set -o` 的列表输出与测试的真值源。

# ── set -o 选项（0.90.0 / ADR-0025）──────────────────────────────────
# 每个选项都必须有执行点；这张表同时是 `set -o` 的列表输出与测试的真值源。
method !option-names(--> List) {
    <errexit histexpand noglob noexpand xtrace>.List;
}


method !option-table(--> Hash) {
    %(
        errexit    => $.strict,
        histexpand => $.histexpand,
        noglob     => $.noglob,
        noexpand   => $.noexpand,
        xtrace     => $.xtrace,
    );
}


method !set-option(Str $name, Bool $on --> Bool) {
    given $name.lc {
        when 'errexit'    { $.strict     = $on }
        when 'histexpand' { $.histexpand = $on }
        when 'noglob' {
            $.noglob = $on;
            $.shell.noglob = $on if $.shell.defined;
        }
        when 'noexpand' {
            $.noexpand = $on;
            $.shell.noexpand = $on if $.shell.defined;
        }
        when 'xtrace'     { $.xtrace = $on }
        default           { return False }
    }
    True
}

# 公开只读视图：`repl.options` 可在 Rc / 插件里查，不必再猜。

# 公开只读视图：`repl.options` 可在 Rc / 插件里查，不必再猜。
method options(--> Hash) { self!option-table }


method !aliases(--> Hash) {
    my $a = %.config<aliases>;
    $a ~~ Hash ?? $a !! %();
}


method !expand-alias(Str $line --> Str) {
    my Str $out = $line;
    my %a = self!aliases;
    for ^10 {
        my @parts = $out.split(/\s+/, 2);
        last unless @parts.elems;
        my Str $name = @parts[0];
        last unless %a{$name}:exists;
        my Str $rest = @parts.elems > 1 ?? @parts[1] !! '';
        $out = %a{$name}.Str ~ ($rest.chars ?? ' ' ~ $rest !! '');
    }
    $out
}


method !cmd-alias(Str $raw --> Result) {
    my Str $t = $raw.trim;
    if $t eq 'alias' {
        my @lines = self!aliases.keys.sort.map({ "{$_}={self!aliases{$_}}" });
        return Result.new(:ok, :op<alias>, :value(self!aliases),
                          :out(@lines.join("\n")));
    }
    my Str $rest = $t.substr(5).trim;
    if $rest.starts-with('--') {
        return Result.new(:!ok, :code(2), :op<alias>,
                          :err('用法: alias [name=command]'));
    }
    my Int $eq = $rest.index('=');
    my Str $name;
    my Str $value;
    if $eq.defined {
        $name  = $rest.substr(0, $eq).trim;
        $value = $rest.substr($eq + 1).trim;
    }
    else {
        my @p = $rest.split(/\s+/, 2);
        $name = @p[0] // '';
        $value = @p.elems > 1 ?? @p[1] !! '';
    }
    return Result.new(:!ok, :code(2), :op<alias>,
                      :err('用法: alias name=command')) unless $name.chars;
    if !$value.chars {
        %.config<aliases>{$name}:delete;
    }
    else {
        %.config<aliases>{$name} = $value;
    }
    self!save-config;
    Result.new(:ok, :op<alias>, :value($name), :out("alias {$name}={$value}"));
}


method !cmd-unalias(Str $raw --> Result) {
    my Str $name = $raw.trim.substr(8).trim;
    return Result.new(:!ok, :code(2), :op<unalias>,
                      :err('用法: unalias name')) unless $name.chars;
    %.config<aliases>{$name}:delete;
    self!save-config;
    Result.new(:ok, :op<unalias>, :value($name), :out("unalias {$name}"));
}


method !cmd-config(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines = %.config.keys.sort.map({
            my $v = %.config{$_};
            "{$_}={$v ~~ Str ?? $v !! to-json($v, :!pretty)}"
        });
        return Result.new(:ok, :op<config>, :value(%.config),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'get' && @args.elems >= 3 {
        my Str $k = @args[2];
        return Result.new(:!ok, :code(1), :op<config>, :err("没有配置: {$k}"))
            unless %.config{$k}:exists;
        return Result.new(:ok, :op<config>, :value(%.config{$k}),
                          :out(%.config{$k}.Str));
    }
    if $sub eq 'set' && @args.elems >= 4 {
        my Str $k = @args[2];
        my Str $v = @args[3..*].join(' ');
        %.config{$k} = $v;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($v), :out("{$k}={$v}"));
    }
    if $sub eq 'unset' && @args.elems >= 3 {
        my Str $k = @args[2];
        %.config{$k}:delete;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($k), :out("unset {$k}"));
    }
    Result.new(:!ok, :code(2), :op<config>,
               :err('用法: config [get KEY|set KEY VALUE|unset KEY]'))
}


method !hooks(--> Hash) {
    my $h = %.config<hooks>;
    $h ~~ Hash ?? $h !! %();
}


method run-hooks(Str $event --> List) {
    my %h = self!hooks;
    return () unless %h{$event} ~~ Positional;
    my @res;
    for %h{$event}.List -> $code {
        @res.push(self.eval-line($code.Str));
        last if $.exit-requested;
    }
    @res.List;
}


method !cmd-hook(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines;
        for self!hooks.keys.sort -> $e {
            @lines.push("{$e}:");
            @lines.push("  {$_}") for self!hooks{$e}.List;
        }
        return Result.new(:ok, :op<hook>, :value(self!hooks),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'add' && @args.elems >= 4 {
        my Str $event = @args[2];
        my Str $code = @args[3..*].join(' ');
        my %h = self!hooks;
        %h{$event} //= [];
        %h{$event}.push($code);
        %.config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($code),
                          :out("hook {$event} += {$code}"));
    }
    if $sub eq 'clear' && @args.elems >= 3 {
        my Str $event = @args[2];
        my %h = self!hooks;
        %h{$event}:delete;
        %.config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($event),
                          :out("hook {$event} cleared"));
    }
    if $sub eq 'run' && @args.elems >= 3 {
        my Str $event = @args[2];
        my @rs = self.run-hooks($event);
        my Str $out = @rs.map({ $_.out.chomp }).grep(*.chars).join("\n");
        my Str $err = @rs.map({ $_.err.chomp }).grep(*.chars).join("\n");
        my Bool $all-ok = so @rs.map(*.ok).all;
        return Result.new(:ok($all-ok), :op<hook>,
                          :value(@rs.List), :out($out), :err($err));
    }
    Result.new(:!ok, :code(2), :op<hook>,
               :err('用法: hook [add EVENT CODE|clear EVENT|run EVENT]'))
}


method !cmd-plugin(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 3);
    my Str $sub = @p[1] // 'list';
    my Str $arg = (@p[2] // '').trim;
    my Str $usage = '用法: plugin [list|load PATH|unload NAME|info NAME]';
    given $sub {
        when 'list' {
            my $table = $.plugins.list;
            Result.new(:ok, :op<plugin>, :value($table),
                       :out($table.elems ?? $table.to-text !! '（未加载插件）'))
        }
        when 'info' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            Result.new(:ok, :op<plugin>, :value($arg),
                       :out($.plugins.info($arg)))
        }
        when 'load' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $.plugins.load($.sys, $.commands, $arg,
                           :enabled($.plugins.enabled(%.config)))
        }
        when 'unload' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $.plugins.unload($.commands, $arg)
        }
        when 'help' | '--help' | '-?' {
            Result.new(:ok, :op<help>, :value<plugin>, :out($usage))
        }
        default {
            Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
        }
    }
}
