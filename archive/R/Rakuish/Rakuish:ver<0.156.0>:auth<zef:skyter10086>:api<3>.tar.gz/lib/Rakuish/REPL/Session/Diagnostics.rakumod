# Rakuish::REPL::Session::Diagnostics —— 诊断 / 渲染层（0.147.0 / V-351 / ADR-0061）
#
# 本 role 承载 7 条 `!` 命令及其辅助：
#   explore（含分页）/ perf / tb（含 debug）/ audit / log / hint / who（含 whos）
# 以及入口与 Server 需要的公开入口：
#   perf-report / collect-traceback / log-line / hint-text / next-hint
#
# 属性归属规则（ADR-0060 §3.2）：属性全部留在 Session，这里只经公开访问器
# 读写（$.sys / $.shell / $.bt / @.decls / @.perf-hist / %.state / %.hinted …）。
# log-active 仍在 Session（读 $!log-on，名字与属性 log-on 不同）；
# log-path / log-lines 由 Session 的 `is rw` 属性访问器直接提供 —— 手写同名
# 只读方法会自递归或遮蔽写访问器（ADR-0061 §3）。

unit role Rakuish::REPL::Session::Diagnostics;

use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Data::Pager;
need Rakuish::Data;            # open-data / tableify：只加载不导入（同 Session）
use Rakuish::REPL::Hints;      # hint-for / result-hint

# ── !explore：把上一格结果或文件放进分页器 ─────────────────────────────
method !cmd-explore(Str $raw --> Result) {
    my Str $arg = $raw.trim.substr(7).trim;
    my $value;
    if $arg.chars {
        my $path = try { $.sys.resolve($arg) };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err("路径不存在: {$arg}")) unless $path.defined;
        my $loaded = try {
            $path.d
                ?? $.sys.ls-table($arg)
                !! Rakuish::Data::open-data($.sys, $arg)
        };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err($!.message)) unless $loaded.defined;
        $value = $loaded;
    }
    else {
        $value = @.out.elems ?? @.out[*-1] !! Nil;
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err('没有可探索的上一格结果')) unless $value.defined;
    }

    $value = Rakuish::Data::tableify($value)
        if $value ~~ Hash | Positional && $value !~~ Rakuish::Data::Table;
    return Result.new(:!ok, :code(1), :op<explore>,
                      :err('explore 需要 Table / 可表格化的数据'))
        unless $value ~~ Rakuish::Data::Table | Str;

    # 每页行数按终端高度算（留 2 行给提示符与 "-- more --"）。
    # 高度未知时退回 Pager 的默认 20 —— 这就是 height 的执行点，
    # 没有它 `height` 只是一个被存起来的数字（V-211 的同一把尺子）。
    my $pager = Rakuish::Data::Pager.new(:page-size(self.pager-page-size));
    # 这里要的是 live-out 而不是 tty：分页要往**真 stdout** 写、再读**真 stdin**。
    my Bool $tty = $.live-out;
    $tty = False if (%*ENV<RAKUISH_PAGER> // '') eq 'never';
    my Str $text = $pager.page($value, :interactive($tty));
    Result.new(:ok, :op<explore>, :value($value),
               :out($tty ?? '' !! $text));
}

method perf-report(Int :$limit = 10 --> Str) {
    return '还没有计时记录。' unless @.perf-hist.elems;
    my @rows = @.perf-hist.tail($limit max 1);
    my @lines;
    for @rows -> $row {
        my ($idx, $ms, $src, $ok) = @$row;
        my Str $text = $src.subst(:g, "\n", ' ');
        $text = $text.substr(0, 42) ~ '...' if $text.chars > 43;
        my Str $flag = $ok ?? 'ok' !! 'ERR';
        @lines.push(sprintf('#%-4d %8d ms  %-3s %s', $idx, $ms, $flag, $text));
    }
    my @all = @.perf-hist.map({ .[1] });
    my Str $avg = @all.elems ?? sprintf('%.1f', @all.sum / @all.elems) !! '0';
    my Int  $max = @all.elems ?? @all.max !! 0;
    @lines.push("共 {@.perf-hist.elems} 格 · 平均 {$avg} ms · 最慢 {$max} ms");
    @lines.join("\n")
}

method !cmd-perf(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('perf'),
                          :out($.shell.usage('perf')));
    }
    my Int $n = @args.elems ?? ((try { @args[0].Int }) // 10) !! 10;
    $n = 1   if $n < 1;
    $n = 200 if $n > 200;
    Result.new(:ok, :op<perf>, :value(@.perf-hist.List),
               :out(self.perf-report(:limit($n))))
}

# ── 0.132.0 / §4.9i：post-mortem lite（tb / debug / backtrace）──────────
# 只回放**上一格失败**的异常：异常族、消息、backtrace 帧与源码行。
# 刻意不做帧内求值：Raku 的 EVAL 没有可持久化的调试帧，假装能 pdb-next
# 才是撒谎。IPython 的 `%tb` 就是这个层次。
method !cmd-tb(Str $raw --> Result) {
    my Str $cmd = $raw.trim;
    my Str $usage = $.shell.usage($cmd);
    my Str $text;
    if !$.bt {
        $text = '异常回放已关闭（repl.bt = False）；打开后下一格失败才会记录。';
    }
    elsif !self.last-error().defined {
        $text = '还没有异常可回放：先让一格求值失败。';
    }
    else {
        $text = self!render-trace;
    }
    $text ~= "\n\n" ~ $usage if $cmd eq 'debug';
    Result.new(:ok, :op<tb>, :value($text), :out($text));
}

method !render-trace(--> Str) {
    my @lines = self.collect-traceback;
    @lines.join("\n");
}

# 0.132.0 / P2.5：返回帧列表（Jupyter error.traceback 要的形状）。
# 与 !render-trace 共享同一套帧过滤/源码行逻辑，只是返回数组不 join。
# Server 侧需要调它，所以是 public 方法。
method collect-traceback(--> List) {
    my $ex = self.last-error();
    return () unless $ex.defined;
    my @lines;
    @lines.push("异常: {$ex.^name}");
    if self.last-error-text().chars && self.last-error-text() ne $ex.^name {
        @lines.push("消息: {self.last-error-text()}");
    }
    my $bt = try { $ex.backtrace };
    my @frames = $bt.defined ?? $bt.list.List !! ();
    my Int $shown = 0;
    my %src-cache;
    for @frames -> $f {
        next if (try { $f.is-hidden }) // False;
        my Str $file = (try { $f.file } // '').Str;
        next if $file.starts-with('SETTING::');
        last if $shown >= 12;
        $shown++;
        my Str $sub  = (try { $f.subname } // '').Str;
        my Int $line = (try { $f.line } // 0).Int;
        my Str $loc = $file.chars
            ?? ($line > 0 ?? "{$file}:{$line}" !! $file)
            !! ($line > 0 ?? "行 {$line}" !! '?');
        @lines.push($sub.chars ?? "  at {$sub} ({$loc})" !! "  at {$loc}");
        my Str $src = self!source-line($file, $line, %src-cache);
        @lines.push("     {$src}") if $src.chars;
    }
    @lines.push('  （没有可显示的帧）') unless $shown;
    @lines.List;
}

# 帧的源码行：只读本地真实文件，读不到就静默跳过（EVAL 帧的 file 是伪路径）。
method !source-line(Str $file, Int $line, %cache --> Str) {
    return '' unless $file.chars && $line > 0;
    my $cached = %cache{$file};
    unless $cached.defined {
        my $io = $file.IO;
        $cached = $io.e && $io.f && $io.s < 2_000_000
            ?? ((try { $io.lines.List }) // False)
            !! False;
        %cache{$file} = $cached;
    }
    return '' unless $cached && $cached.elems >= $line;
    my Str $s = $cached[$line - 1].trim;
    $s.chars > 160 ?? $s.substr(0, 157) ~ '...' !! $s;
}

# ── 0.75.0 / ADR-0012 §5：会话日志 ─────────────────────────────────

# 入口主循环每格调一次：那是唯一同时拿得到「输入行 + Result + 渲染文本」的地方。
# Session.render 在 TTY 下会加 ANSI，日志必须纯文本，所以先剥掉 SGR 序列。
method log-line(Str $line, Result $r, Str $rendered --> Nil) {
    # 0.115.0：格记录要的是「终端看到的东西」，与日志开关无关。
    if @.cells.elems {
        @.cells[*-1]<rendered> = $rendered.subst(/ \e \[ <[0..9;]>* m /, :g, '');
    }
    return unless $.log-on;
    my Str $plain = $rendered.subst(/ \e \[ <[0..9;]>* m /, :g, '');
    ++$.log-seq;
    my Str $mark = $r.ok ?? '=' !! '!';
    my Str $entry = "[{$.log-seq}] > $line\n[{$.log-seq}] $mark $plain";
    @.log-lines.push($entry);
    if $.log-path.chars {
        try { $.sys.append($.log-path, $entry ~ "\n") };
    }
}

# 0.112.0 / V-303：按来源分账。和 `log` 的区别是这里查结构化审计记录，
# 不是给人看的会话抄本；账本可能跨进程，所以走 Audit.by-origin / origin-summary。
method !cmd-audit(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('audit'),
                          :out($.shell.usage('audit')));
    }
    my $audit = $.audit;
    unless $audit.defined {
        return Result.new(:!ok, :code(1), :op<audit>,
                          :err('本会话没有审计账本（Kernel 未注入）'));
    }

    my Str $arg = @args.elems ?? @args[0].Str !! '';
    my Bool $flag = $arg.starts-with('--origin');
    if $flag && @args.elems < 2 {
        return Result.new(:!ok, :code(2), :op<audit>,
                          :err('用法: audit --origin ORIGIN'));
    }
    my Str $origin = $flag ?? @args[1].Str
                   !! ($arg eq 'summary' ?? '' !! $arg);

    unless $origin.chars {
        my %s = $audit.origin-summary;
        my Str $out = '（审计账本为空）';
        if %s.elems {
            my @rows = %s.keys.sort.map(-> Str $o {
                my %v = %s{$o};
                sprintf '%-8s %5d %4d %6d', $o, %v<total>, %v<ok>, %v<failed>;
            });
            $out = ("origin     total   ok  failed",
                    '-------  ------  --  ------', |@rows).join("\n");
        }
        return Result.new(:ok, :op<audit>, :value(%s), :out($out));
    }

    my @rows = $audit.by-origin($origin);
    unless @rows.elems {
        return Result.new(:ok, :op<audit>, :value([].List),
                          :out("origin={$origin} 没有记录"));
    }
    my @lines = "origin={$origin}（{@rows.elems} 条）";
    for @rows -> %e {
        my Str $detail = (%e<detail> // '').Str;
        $detail = $detail.substr(0, 37) ~ '…' if $detail.chars > 38;
        @lines.push(sprintf '%4s  %-19s %-10s %-2s %3s  %s',
            %e<seq> // '?', (%e<ts> // '').Str.substr(0, 19),
            (%e<op> // '').Str, ?%e<ok> ?? 'ok' !! 'NO',
            (%e<code> // '?').Str, $detail);
    }
    Result.new(:ok, :op<audit>, :value(@rows.List), :out(@lines.join("\n")));
}

method !cmd-log(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('log'),
                          :out($.shell.usage('log')));
    }
    my Str $sub = @args.elems ?? @args[0].Str !! 'status';
    given $sub {
        when 'start' {
            if @args.elems > 2 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log start [路径]'));
            }
            my Str $path = @args.elems == 2
                ?? @args[1].Str
                !! ((try { $*HOME.add('.rakuish-session.log').Str })
                    // '.rakuish-session.log');
            my $resolved = try { $.sys.resolve($path) };
            unless $resolved.defined {
                return Result.new(:!ok, :code(1), :op<log>,
                                  :err("路径不可用: $path"));
            }
            my Str $header = '# Rakuish 会话日志 · ' ~ DateTime.now.Str ~ "\n";
            my $w = try { $.sys.write($path, $header, :mkdir) };
            unless $w.defined {
                return Result.new(:!ok, :code(1), :op<log>,
                                  :err("无法写日志: $path"));
            }
            $.log-on = True;
            $.log-path = $path;
            $.log-seq = 0;
            @.log-lines = ();
            return Result.new(:ok, :op<log>, :value($path),
                              :out("日志已开启: $path"));
        }
        when 'stop' {
            if @args.elems > 1 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log stop'));
            }
            $.log-on = False;
            my Int $n = @.log-lines.elems;
            my Str $where = $.log-path.chars ?? "（$.log-path）" !! '';
            return Result.new(:ok, :op<log>, :value($n),
                              :out("日志已关闭；共 $n 格$where"));
        }
        when 'show' {
            if @args.elems > 1 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log show'));
            }
            my Str $text = @.log-lines.elems
                ?? @.log-lines.join("\n") !! '（没有记录）';
            return Result.new(:ok, :op<log>, :value(@.log-lines.List),
                              :out($text));
        }
        when 'status' {
            my Str $state = $.log-on
                ?? "日志开启：$.log-path（" ~ @.log-lines.elems ~ ' 格）'
                !! '日志未开启（log start [路径]）';
            return Result.new(:ok, :op<log>, :value($.log-on), :out($state));
        }
        default {
            return Result.new(:!ok, :code(2), :op<log>,
                              :err('用法: log [start [路径]|stop|show]'));
        }
    }
}
method hint-text(Str $line = '' --> Str) {
    my Str $t = $line.chars ?? $line
              !! (@.history.elems ?? @.history[*-1] !! '');
    hint-for($t, :shell($.shell), :registry($.commands))
}

# 入口每格调用：失败优先给下一步建议；成功时给一次性的命令用法提示。
method next-hint(Str $line, Result $r --> Str) {
    unless $r.ok {
        my Str $advice = result-hint($r, $line);
        return $advice if $advice.chars;
    }
    my Str $ctx = hint-for($line, :shell($.shell), :registry($.commands));
    return '' unless $ctx.chars;
    my Str $key = $line.trim.words[0] // '';
    return '' if %.hinted{$key}:exists;
    %.hinted{$key} = True;
    $ctx
}

method !cmd-hint(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $h = self.hint-text(@p[1] // '');
    Result.new(:ok, :op<hint>, :value($h),
               :out($h.chars ?? $h !! '（该输入没有上下文提示）'))
}

# ── who / whos / rerun / `名字?`（0.108.0 / V-299）──────────────────────
# 数据源只有三处：%.state（变量）、@.decls（sub/class/use）、@.history（输入序）。
# 这一层不 EVAL、不碰 Sys —— 与 history / perf 同级，属于会话自省。
# 显示只用「名字（ASCII）+ 类型（ASCII）+ 大小（可能在行尾）」三列，
# 不对齐 CJK 表头：宽字符按 chars 算宽度必然错位，宁可不做那半列。
method !sigil-rank(Str $name --> Int) {
    given $name.substr(0, 1) {
        when '$' { 0 }
        when '@' { 1 }
        when '%' { 2 }
        default  { 3 }
    }
}

method !value-type($v --> Str) {
    # 类型对象本身 `.defined` 为假，但类型名仍是有效信息，不能丢。
    my $t = try { $v.WHAT.^name };
    my Str $name = ($t.defined ?? $t.Str !! 'Any');
    $v.defined ?? $name !! $name ~ '（未赋值）';
}

method !value-size($v --> Str) {
    return '—' unless $v.defined;
    # `elems` 不是所有类型都有；一个怪对象不该让 whos 整条崩掉。
    my $s = try {
        if    $v ~~ Str         { "{$v.chars} 字符" }
        elsif $v ~~ Associative { "{$v.elems} 键" }
        elsif $v ~~ Positional  { "{$v.elems} 项" }
        else                    { '—' }
    };
    ($s.defined ?? $s.Str !! '—');
}

method !cmd-who(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $flag = (@p[1] // '').trim;
    my Str $usage = '用法: who [-l]'
        ~ "\n  不带参数：列出变量名（带 sigil）"
        ~ "\n  -l（= whos）：变量类型/大小 + 可见的 sub/class/use";
    if $flag.chars && $flag ne '-l' && $flag ne '--long' {
        return Result.new(:!ok, :code(2), :op<who>, :err($usage));
    }

    my @names = %.state.keys.sort(
        { (self!sigil-rank($^a), $^a) cmp (self!sigil-rank($^b), $^b) });

    if !$flag.chars {
        my Str $text = @names.elems
            ?? @names.join('  ')
            !! '（本会话还没有变量；`my $x = 1` 之后再看）';
        return Result.new(:ok, :op<who>, :value(@names.List), :out($text));
    }

    my @var-rows;
    my Int $w-name = 0;
    my Int $w-type = 0;
    for @names -> $name {
        my Str $type = self!value-type(%.state{$name});
        my Str $size = self!value-size(%.state{$name});
        $w-name = $name.chars if $name.chars > $w-name;
        $w-type = $type.chars if $type.chars > $w-type;
        @var-rows.push([$name, $type, $size]);
    }

    my @decl-rows;
    for @.decls -> $d {
        my Str $key = ($d<key> // '').Str;
        next unless $key.chars;
        if $key ~~ /^ 'use:' $<src>=(.+) $/ {
            my Str $mod = $<src>.Str
                .subst(/^ 'use' \s+ /, '')
                .subst(/\s* ';' \s* $/, '').trim;
            @decl-rows.push(['use', $mod]);
        }
        elsif $key ~~ /^ $<kind>=(\w+) ':' $<name>=(.+) $/ {
            @decl-rows.push([$<kind>.Str, $<name>.Str]);
        }
    }

    my @lines;
    @lines.push("变量（{@var-rows.elems}）:");
    if @var-rows.elems {
        for @var-rows -> $r {
            @lines.push('  ' ~ $r[0] ~ (' ' x ($w-name - $r[0].chars + 2))
                             ~ $r[1] ~ (' ' x ($w-type - $r[1].chars + 2))
                             ~ $r[2]);
        }
    }
    else {
        @lines.push('  （无）');
    }
    if @decl-rows.elems {
        @lines.push('', "声明（{@decl-rows.elems}）:");
        for @decl-rows -> $r {
            @lines.push('  ' ~ $r[0] ~ (' ' x (8 - $r[0].chars)) ~ $r[1]);
        }
    }
    Result.new(:ok, :op<who>, :value(@names.List), :out(@lines.join("\n")));
}
