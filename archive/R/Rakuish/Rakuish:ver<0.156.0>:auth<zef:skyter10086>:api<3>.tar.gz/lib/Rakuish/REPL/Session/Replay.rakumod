# Rakuish::REPL::Session::Replay —— recall / source / paste 三条输入重放命令
# （0.150.0 / ADR-0064 / V-354）
#
# 三者的共同点是「把别处的源码送回求值器」，而不是自己求值：
#   · recall：从 @.history 里取一条放进预填缓冲，不执行（执行是 rerun 的活）；
#   · source：把脚本文件逐行喂 eval-line（声明因此留在会话里）；
#   · paste ：把 stdin 的块当一个格交给 eval-line。
#
# 状态归属（ADR-0060 §3.2 的规矩）：属性都留在 Session，本 role 只经公开
# 访问器读写 —— @.history / @.out / @.perf-hist / $.index / $.tty /
# $.sys / $.exit-requested / self.input-handler / self.read-line。
#
# 三个私有动作没有走「公开属性」而是走 Session 的私有方法，因为它们是
# **写入**且没有对外语义：!set-prefill（预填缓冲的写侧，读侧是公开的
# take-prefill）、!mark-recorded（`!!` / paste 的外层不重复记账）、
# !clear-pending（脚本结束时清掉续行残骸，别让它毒死会话）。
#
# 依赖必须自己 use：role 的编译单元看不到宿主类的导入表（ADR-0063 §3）。

unit role Rakuish::REPL::Session::Replay;

use Rakuish::Result;
use Rakuish::REPL::Highlight;   # set-continuation：脚本结束清续行高亮状态
use Rakuish::Incomplete;        # is-incomplete：paste 拒绝半个块
# ── 0.140.0 / P2.7 / V-344：recall [n] ───────────────────────────────
# 契约 = 把第 n 条历史放进**下一次输入**的预填缓冲（`take-prefill`），
# 同时把原文回显。不在这里重跑：recall 的用处是「改一个字再执行」，
# 直接执行那是 `rerun` 的活（两者共用同一套编号，负数从末尾算）。
#
# 为什么不做「真的塞进输入行」：内置行编辑器（Terminal::LineEditor）
# 0.0.23 没有预填 API，而本机连它的 CLIInput 都取不到（Keymap 里那个
# `try` 就是为此）。假装能塞进去只能靠按键注入，那是 ADR-0036 明令
# 不走的路。所以这里给出**可被前端消费的契约**（Notebook / 未来的行
# 编辑器实现 take-prefill 即可真预填），其余情况如实说明退路。
method !cmd-recall(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $arg = (@p[1] // '').trim;
    my Str $usage = '用法: recall [n]'
        ~ "\n  把历史里的第 n 条放回输入行（负数从末尾算；不带参数 = 上一条）"
        ~ "\n  编号用 history 查；只回显与预填，不执行（要重跑用 rerun n）";
    # --help 必须在「有没有历史」之前处理：空会话里也要能查用法。
    if $arg eq '--help' || $arg eq '-h' {
        return Result.new(:ok, :op<recall>, :value($usage), :out($usage));
    }
    return Result.new(:!ok, :code(127), :op<recall>,
                      :err('还没有可召回的历史')) unless @.history.elems;

    my Int $idx;
    if !$arg.chars {
        $idx = @.history.elems - 1;
    }
    elsif $arg ~~ /^ '-'? \d+ $/ {
        my Int $n = $arg.Int;
        $idx = $n < 0 ?? @.history.elems + $n !! $n - 1;
    }
    else {
        return Result.new(:!ok, :code(2), :op<recall>, :err($usage));
    }
    unless $idx >= 0 && $idx < @.history.elems {
        return Result.new(:!ok, :code(127), :op<recall>,
            :err("没有历史项: {$arg}（当前 {@.history.elems} 条，用 history 查编号）"));
    }

    my Str $src = @.history[$idx];
    self!set-prefill($src);
    my Int $shown-no = $idx + 1;
    my Str $note = $.tty
        ?? "（已放进预填缓冲：支持预填的前端会带出这一行；不支持的按 ↑ 调回，或 rerun {$shown-no} 直接重跑）"
        !! "（非交互模式没法预填输入行：用 rerun {$shown-no} 直接重跑，或复制上面那行）";
    my Str $out = "recalled 第 {$shown-no} 条:\n  {$src}\n{$note}";
    Result.new(:ok, :op<recall>, :value($src), :out($out));
}
# ── source：在会话里跑一个脚本文件（0.114.0 / V-306）──────────────────
# 与 `rakuish 文件` 的分工：那是一次性进程，跑完什么都没留下；`source` 在
# **当前会话**里跑 —— 脚本看得到会话的变量，脚本里的 sub / class / use /
# 顶层 `my` 也留在会话里（`source lib.raku` 就是把库装进当前会话）。
#
# 为什么逐行喂给 eval-line（和启动文件同一套路），而不是把整份文件当一个
# cell：`!pure-decl` 只在「一格恰好是一条声明」时把声明持久化。整份文件
# 当一个 cell 跑，里面的 `sub` 只活在那次 EVAL 里，跑完就没了 —— 那正好
# 废掉 source 最主要的用途。代价是脚本语义比「一个编译单元」弱一点
# （BEGIN 按行触发、声明必须先于使用），这与 REPL 的既有语义一致。
method !cmd-source(Str $raw --> Result) {
    my Str $usage = '用法: source <文件> [参数...]'
        ~ "\n  在当前会话里执行脚本文件：脚本能看到会话的变量，"
        ~ "\n  文件里的 sub / class / use / 顶层 my 也留在会话里"
        ~ "\n  参数进 @*ARGS；给了参数且文件里有 sub MAIN 时会调用它"
        ~ "\n  脚本内部的行不占 Out[n] / history；错误按 文件:行 报出";

    # 'source'.chars == 6；`source` 后面什么都没有时 body 必须是空串
    # （写成「按 6 往后切」会切成字符串 'source' 本身，然后去找名为 source 的文件）。
    my Str $trimmed = $raw.trim;
    my Str $body = $trimmed.chars > 6 ?? $trimmed.substr(6).trim !! '';
    if !$body.chars || $body eq '--help' || $body eq '-h' {
        return Result.new(:ok, :op<source>, :out($usage));
    }

    my @argv = self!split-argv($body);
    my Str $given = @argv[0];
    my @args = @argv.skip(1).List;

    # `~` / `~/x`：与 cd、cp 一致（Sys.resolve 只做相对 cwd 的解析）。
    my Str $target = $given;
    if $target eq '~' || $target.starts-with('~/') || $target.starts-with('~\\') {
        my Str $home = (try { $*HOME.Str }) // '';
        $target = $home ~ $target.substr(1) if $home.chars;
    }

    my IO::Path $path;
    my Str $perr = '';
    {
        CATCH { default { $perr = .message } }
        $path = $.sys.resolve($target);
    }
    return Result.new(:!ok, :code(127), :op<source>,
                      :err("source: {$perr}")) if $perr.chars;
    return Result.new(:!ok, :code(127), :op<source>,
                      :err("source: 找不到文件 {$path.Str}")) unless $path.e;
    return Result.new(:!ok, :code(126), :op<source>,
                      :err("source: 不是普通文件 {$path.Str}")) unless $path.f;

    my Str $src = '';
    my Str $rerr = '';
    {
        CATCH { default { $rerr = .message } }
        $src = $path.slurp(:enc<utf-8>);
    }
    return Result.new(:!ok, :code(126), :op<source>,
                      :err("source: 读取失败（{$rerr}）")) if $rerr.chars;
    # BOM / CRLF 都要吃掉：`.lines` 只按 \n 切，留着 \r 会让最后一行
    # 的 `}` 变成 `}\r`，续行判定直接失效。
    $src = $src.subst(/^ "\x[FEFF]" /, '');
    $src = $src.subst(:g, /\r$/, '');

    my Str $label = $path.basename.Str;
    my @out;
    my @err;
    my Int $failed = 0;
    my Int $n = 0;
    my Bool $pending = False;

    {
        # 脚本内部的行不是用户敲的格：Out[n] / history / perf 必须回到运行前，
        # 否则一个 300 行的脚本会把格号顶到 300 开外。声明缓存与会话状态
        # **不**回滚 —— 那正是 source 要留下的东西。
        my Int  $saved-index = $.index;
        my @saved-out  = @.out.List;
        my @saved-hist = @.history.List;
        my @saved-perf = @.perf-hist.List;
        LEAVE {
            $.index = $saved-index;
            @.out = @saved-out;
            @.history = @saved-hist;
            @.perf-hist = @saved-perf;
        }

        # 脚本的「命令行参数」：动态变量对 EVAL 可见（与 $*PROGRAM 一样），
        # temp 保证跑完后会话自己的 @*ARGS 不受影响。
        temp @*ARGS = @args;
        my $*PROGRAM = $path;
        my $*PROGRAM-NAME = $label;

        for $src.lines -> $l {
            $n++;
            my $r = self.eval-line($l);
            if $r.op eq 'more' {
                $pending = True;
                next;
            }
            $pending = False;
            @out.push($r.out.chomp) if $r.out.chars;
            if !$r.ok && $r.op ne 'skip' {
                $failed++;
                my Str $why = $r.err.trim;
                @err.push("{$label}:{$n}: " ~ ($why.chars ?? $why !! '执行失败'));
            }
            # 脚本里的 `exit` 就是退出（shell 的 source 同样如此）：不再往下跑，
            # 由 !exit-requested 交给入口收尾。
            last if $.exit-requested;
        }
        if $pending {
            $failed++;
            @err.push("{$label}:{$n}: 文件结束时仍有未闭合结构")
                unless $.exit-requested;
            # 必须把续行缓冲清掉：不清的话下一格会接着这个残骸拼，
            # 之后**每一行**都变成「未闭合」—— 一次手滑的脚本能把会话毒死。
            self!clear-pending();
            set-continuation('');
        }

        # MAIN：Rakudo 的用法解析（`--name`、类型转换、@argsfile）只对
        # **脚本入口**生效，EVAL 里跑不到。这里只在「给了参数」时按位置
        # 参数直接调用一次 —— 调用不上就如实说清楚边界，不假装支持。
        my Bool $declares-main =
            so $src ~~ /^^ \s* ['multi' \s+]? 'sub' \s+ 'MAIN' <?wb>/;
        if $declares-main && @args.elems && $failed == 0 && !$.exit-requested {
            $n++;
            my $mr = self.eval-line('MAIN(|@*ARGS)');
            @out.push($mr.out.chomp) if $mr.out.chars;
            if !$mr.ok {
                $failed++;
                @err.push("{$label}: 调用 MAIN 失败：" ~ $mr.err.trim
                    ~ "\n  只按位置参数调用；命名参数 / 类型转换 / 用法分派"
                    ~ "只在脚本入口生效，需要时用 `raku 文件 参数`");
            }
        }
    }

    Result.new(
        :ok($failed == 0),
        :code($failed == 0 ?? 0 !! 1),
        :op<source>,
        :out(@out.join("\n")),
        :err(@err.join("\n")),
    );
}
# ── paste：块输入（0.138.0 / V-342，评审 P1.4）────────────────────────
# `paste` 读行直到一行恰为 `--`（去空白后比较）或 EOF，把累积的整段源码
# 当作**一个格**交给 eval-line。为什么不是「逐行喂给 eval-line」（source
# 走的就是那条路）：块输入的全部价值就是把带空行/缩进的 class、multi sub
# 一次执行 —— 逐行喂会把缩进块切碎，还会触发 Session 自己的续行状态机。
#
# 为什么不改行编辑循环（ADR-0036 的输入循环所有权）：这一格里行编辑器
# 已经交还输入权，直接读 stdin 即可；TTY 与管道因此同语义。
# 引擎 / notebook 模式下 stdin 是协议流，读它等于把协议帧当源码 —— 明确
# 拒绝，而不是给出一个会吃掉协议帧的实现。
method !cmd-paste(Str $raw --> Result) {
    my Str $usage = '用法: paste'
        ~ "\n  读 stdin 直到一行恰为 -- （或 Ctrl-D / EOF），把整段源码当一个格执行"
        ~ "\n  适合粘贴带空行 / 缩进块的 class、multi sub、for 循环";
    my Str $body = $raw.chars > 5 ?? $raw.substr(5).trim !! '';
    if $body eq '--help' || $body eq '-h' {
        return Result.new(:ok, :op<paste>, :out($usage));
    }
    unless $body.chars == 0 {
        return Result.new(:!ok, :code(2), :op<paste>,
            :err("paste: 不接受参数（{$body}）。用法见 paste --help"));
    }
    if self.input-handler.defined {
        return Result.new(:!ok, :code(1), :op<paste>,
            :err('paste: 引擎 / notebook 模式下不可用（stdin 是协议流，不是键盘）'));
    }
    my @lines;
    # 注意：`self.read-line` 是**访问器方法调用**，`self.read-line()` 还是
    # 调访问器（返回那个 Block），不是调用 Block 本身。私有可调用属性
    # （`&` + sigil 那个写法）是「调用变量里的闭包」，改成公开访问器后
    # 必须先把闭包取出来再调，否则每轮拿到的都是 Block，`.Str` 会警告、
    # `--` 永远不匹配 → 死循环。
    my $reader = self.read-line;
    loop {
        my $l = $reader.defined ?? $reader() !! $*IN.get;
        last unless $l.defined;
        my Str $s = $l.Str;
        last if $s.trim eq '--';      # 终止行本身不进格
        @lines.push($s);
    }
    my Str $src = @lines.join("\n");
    unless $src.trim.chars {
        return Result.new(:!ok, :code(1), :op<paste>,
            :err('paste: 没有读到内容（用 -- 结束，或 Ctrl-D）'));
    }
    # 不完整的块宁可拒绝，也不让 EVAL 在半个 class 上报奇怪的语法错误；
    # 拒绝后会话仍可用（不碰续行缓冲，不占 Out[n]）。
    if is-incomplete($src) {
        return Result.new(:!ok, :code(1), :op<paste>,
            :err('paste: 源码不完整（括号 / quote / heredoc 没闭合）'));
    }
    my $r = self.eval-line($src);
    # 内层 eval-line 已经把整段源码记进 history / cells（一次，不是 N 次）；
    # 外层这一行 `paste` 本身不该再记一遍 —— 与 `!!` 同一手法。
    self!mark-recorded();
    $r;
}
