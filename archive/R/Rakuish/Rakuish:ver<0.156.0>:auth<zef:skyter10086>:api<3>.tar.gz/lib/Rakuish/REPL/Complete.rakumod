unit module Rakuish::REPL::Complete;

# Rakuish::REPL::Complete —— 补全 / 建议的纯函数辅助（0.100.0 / ADR-0034 §2.5）。
#
# 纯函数：无 IO、无状态、不碰 $*OUT。Shell 与 SqlComplete 共用：
#   · common-prefix   —— Tab 序列首位的公共前缀候选（V-278）
#   · subsequence-rank / fuzzy-words —— 前缀零命中时的子序列回退（V-282）
#   · suggest-suffix  —— autosuggestion 灰字的后缀计算（V-277）
#
# 边界（ADR-0034 §2.5）：模糊回退只给「单词」用（命令名、SQL 表/列/关键字），
# 选项与路径保持前缀匹配——子序列在带 `-` / `/` 的串上噪声大于收益。

# 多候选的最长公共前缀。
our sub common-prefix(@cands --> Str) is export {
    return '' unless @cands.elems;
    my Str $p = @cands[0].Str;
    for @cands.skip(1) -> $c {
        my Str $s = $c.Str;
        my Int $i = 0;
        $i++ while $i < $p.chars && $i < $s.chars
              && $p.substr($i, 1) eq $s.substr($i, 1);
        $p = $p.substr(0, $i);
        last unless $p.chars;
    }
    $p
}

# 子序列匹配打分：$needle 的字符按序（大小写不敏感）都能在 $hay 里找到
# 才算命中，返回「匹配跨度 + 缺口数」（越小越好）；不命中返回 Nil。
# 不做编辑距离 / 拼音——本期只回答「能不能补」，不回答「补得准不准」。
our sub subsequence-rank(Str $needle, Str $hay --> Any) is export {
    return Nil unless $needle.chars;
    my @h = $hay.comb;
    my Int $hi = 0;
    my Int $first = -1;
    my Int $prev = -1;
    my Int $gaps = 0;
    for $needle.comb -> $ch {
        my Bool $found = False;
        while $hi < @h.elems {
            if @h[$hi].lc eq $ch.lc {
                $first = $hi if $first < 0;
                $gaps += $hi - $prev - 1 if $prev >= 0;
                $prev = $hi;
                $hi++;
                $found = True;
                last;
            }
            $hi++;
        }
        return Nil unless $found;
    }
    ($prev - $first + 1) + $gaps
}

# 前缀优先的模糊过滤：前缀命中（原行为，排序不变）优先；零前缀命中时
# 退化为子序列匹配，按 rank 升序、同 rank 字典序，截 $limit 条。
our sub fuzzy-words(Str $frag, @cands, Int :$limit = 50 --> List) is export {
    my @prefix = @cands.grep({ .Str.lc.starts-with($frag.lc) })
                       .map(*.Str).unique.sort;
    return @prefix.List if @prefix.elems;
    return () unless $frag.chars;
    # rank => 词 两段稳定排序：先字典序、再按 rank——等价 (rank, name) 多键排序。
    my %seen;
    @cands.map({ my $r = subsequence-rank($frag, .Str);
                 $r.defined ?? ($r => .Str) !! Empty })
          .grep({ !%seen{.value}++ })
          .sort(*.value).sort(*.key)
          .map(*.value)
          .head($limit)
          .List
}

# In[n] / Out[n] 引用补全（V-285 / 0.123.0 V-322）：光标前的 prefix 形如
# `(In|Out)[数字*` 时，从各自的历史长度里生成完整替换行候选。
# 纯函数、无 IO；count 是 `Out` 的结果数，`in-count` 是 `In` 的输入数。
#
# 两者**必须分开**：失败格进 history 但不进 @!out，会话命令进 history 也不
# 进 @!out —— 拿 Out 的长度补 In 会补出不需要的编号，反过来会漏。
# 未给 `:in-count` 时退回 count（保持 0.101.0 的调用口径，t/60 依赖它）。
# 边界：`In`/`Out` 前不能紧跟标识符字符（避免 fooOut[ 误命中）。
our sub in-out-completions(Str $line, Int $pos, Int $count,
                           Int :$in-count = -1 --> List) is export {
    my Int $at = $pos min $line.chars;
    my Str $prefix = $line.substr(0, $at);
    return () unless $prefix ~~ /(In|Out) '[' (\d*) $/;
    my Str $kind    = ~$0;
    my Str $digits  = ~$1;
    my Int $start   = $/.from;
    return () if $start > 0 && $prefix.substr($start - 1, 1) ~~ /\w/;

    my Int $max = $kind eq 'In'
        ?? ($in-count >= 0 ?? $in-count !! $count)
        !! $count;
    return () unless $max > 0;

    my Str $head = $prefix.substr(0, $start);
    my Str $typed = $kind ~ '[' ~ $digits;
    my @c;
    for 1 .. $max -> $n {
        my Str $ref = $kind ~ '[' ~ $n;
        next unless $ref.starts-with($typed);
        @c.push($head ~ $ref ~ ']');
    }
    @c.head(50).List
}

# autosuggestion 后缀：历史（近者优先）→ 补全候选。只取单行、且候选
# 必须是当前行的真前缀（比当前行长）。空行不给建议。
our sub suggest-suffix(Str $line, @history, @completions --> Str) is export {
    return '' unless $line.chars;
    for @history.reverse -> $h {
        my Str $e = $h.Str.lines[0] // '';
        next unless $e.chars > $line.chars;
        return $e.substr($line.chars) if $e.starts-with($line);
    }
    for @completions -> $c {
        my Str $e = $c.Str.lines[0] // '';
        next unless $e.chars > $line.chars;
        return $e.substr($line.chars) if $e.starts-with($line);
    }
    ''
}
