unit module Rakuish::Kernel::Notebook;

# Rakuish::Kernel::Notebook —— notebook 前端的协议适配层（0.109.0 / V-300）。
#
# 位置：Jupyter（或任何外部前端）与 `Kernel` 之间。它**不认识 ZMQ、不碰终端**，
# 只做一件事：把一条「请求 Hash」变成一条「响应 Hash」。这样：
#   · 传输层（Python 桥 / 未来的 web UI / 测试里的假客户端）可以换；
#   · 语义仍然只在 Kernel / Session 里，不出现第二套求值逻辑。
#
# 线上形状（一行一个 JSON 对象；由 `serve()` 负责读写）：
#   → {"op":"execute","code":"1+1","silent":false,"id":"c1"}
#   ← {"event":"busy","op":"execute","id":"c1"}          ← 0.113.0 主动推送
#   ← {"op":"execute","ok":true,"code":0,"out":"","err":"",
#      "display":{"content":"2","format":"text","formats":["text"],"meta":{...}},
#      "execution_count":1,"cwd":"...","id":"c1"}
#   ← {"event":"idle","op":"execute","id":"c1","ms":12}  ← 0.113.0 主动推送
#
# 帧分两类，靠字段区分：**带 `op` 的是响应**，**带 `event` 的是推送**。
# 推送是 0.113.0 加的（V-305）：`busy` / `idle` 包住每一格 execute，
# `engine` 报引擎生死（dead / restart / interrupted / restart-failed）。
# 一旦可能有推送插在中间，前端就不能再假设「下一行就是我的响应」——
# 认领靠请求带的 `id`（原样回显）。
#
# 为什么 `display` 单独一份：`text` 是「终端直接打印什么」（含 Out[n] 标签、
# 颜色），`display` 是「另一个前端拿什么去渲染」（零 ANSI、MIME 分档）。
# 前者给 TTY，后者给 notebook —— 混用会把 `Out[1] =` 印进浏览器。
#
# 0.132.0 / §4.9j：补齐 Jupyter 的四个消息形态 —— history_request（tail /
# range 有真实数据）、interrupt_request（单线程内核只回「没有在跑的格」）、
# input_request / input_reply（stdin 仍不支持，结构化报错），以及 `display()`
# 的独立 display_data 帧（在 serve() 里发出，execute 回复保持原形状）。
#
# 边界（v1 明确不做）：
#   · 流式输出：`say` 的内容仍是一次性随 `out` 回来（引擎侧 chunk 是给 TTY 的）；
#   · stdin / `input()`：notebook 里的 stdin 请求回 `ok=false`，不假装支持；
#   · `! --tty` / 后台作业：需要真终端与作业表，notebook 里一律报错。

use Rakuish::Kernel;
use Rakuish::Kernel::Factory;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;
use Rakuish::Result;
use Rakuish::Audit;
use Rakuish::Incomplete;
use JSON::Fast;

# 与 META6.json 同步（t/51 守护）；只用于 kernel_info 的自我介绍。
my constant KERNEL-VERSION = '0.156.0';

# ── 一条请求 → 一条响应（纯映射，可单测）──────────────────────────
class Frontend is export {
    has $.kernel is required;
    has Str $.language = 'raku';

    method session() { $!kernel.session }

    method handle(%msg --> Hash) {
        my Str $op = (%msg<op> // '').Str;
        my %r = do given $op {
            when 'kernel_info'       { self!kernel-info }
            when 'execute'           { self!execute(%msg) }
            when 'complete'          { self!complete(%msg) }
            when 'is_complete'       { self!is-complete(%msg) }
            when 'inspect'           { self!inspect(%msg) }
            when 'history_request'   { self!history(%msg) }
            when 'interrupt_request' { self!interrupt }
            when 'input_request'     { self!input-request }
            when 'input_reply'       { self!input-reply }
            when 'shutdown'          { self!shutdown }
            default {
                %( ok => False, error => "未知 op: {$op}（支持 kernel_info / execute / "
                       ~ "complete / is_complete / inspect / history_request / "
                       ~ "interrupt_request / input_request / input_reply / shutdown）" )
            }
        };
        %r<op> = $op unless %r<op>:exists;
        # 0.113.0 / V-305：请求带 id 就原样回显 —— 一旦协议里出现
        # **主动推送**帧（busy / idle / engine），一问一答的顺序就不再是
        # 唯一线索，前端得靠 id 把响应认领回去。
        %r<id> = %msg<id> if %msg<id>:exists;
        %r;
    }

    method !kernel-info(--> Hash) {
        %(
            op                 => 'kernel_info',
            ok                 => True,
            protocol_version   => '5.3',
            implementation     => 'rakuish',
            implementation_version => KERNEL-VERSION,
            language_info      => %(
                name        => $!language,
                version     => $*RAKU.version.Str,
                mimetype    => 'text/plain',
                file_extension => '.raku',
            ),
            banner             => "Rakuish {KERNEL-VERSION}（Raku {$*RAKU.version}）—— 交互式会话"
                                  ~ "（Out[n] / _ / notebook 共用同一套）",
            help_links         => [],
        );
    }

    method !execute(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        # 空码：Jupyter 允许（用户点了运行但没写东西），不该占格号。
        if !$code.trim.chars {
            return %( op => 'execute', ok => True, code => 0, out => '', err => '',
                      display => %(), execution_count => self.session.index,
                      cwd => self!cwd );
        }
        # 走 Kernel：Policy / 审计 / trail 一个都不绕过（V-182 不变）。
        my $r = $!kernel.execute(
            Request.new(:kind<source>, :payload($code), :origin<notebook>));
        my %out = (
            op              => 'execute',
            ok              => ?$r.ok,
            code            => $r.code,
            out             => $r.out,
            err             => $r.err,
            display         => ($r.bundle // %{}).Hash,
            streamed        => ?$r.streamed,
            execution_count => self.session.index,
            cwd             => self!cwd,
        );
        # 0.135.0 / ADR-0051 v2：错误详情走独立 `error_info` 通道
        # （Proxy.last-error-info），不再是 Result 的字段。仍然拼成
        # Jupyter error reply 的形状，前端不用改。
        unless $r.ok {
            my %e = (try { self.session.last-error-info }) // %{};
            if (%e<ename> // '').chars {
                %out<ename>     = %e<ename>.Str;
                %out<evalue>    = (%e<evalue> // '').Str;
                %out<traceback> = (%e<traceback> // []).List;
            }
        }
        %out<silent> = True if ?(%msg<silent> // False);
        %out;
    }

    method !complete(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        my Int $pos  = (%msg<cursor_pos> // $code.chars).Int;
        $pos = 0 if $pos < 0;
        $pos = $code.chars if $pos > $code.chars;
        # 0.132.0 / P1.3：cursor_start/end 真实返回 —— 只替换 prefix 那段，
        # 不是整行替换。cursor_start 在 notebook 侧 inline 算（纯函数），
        # 不改 Engine/Proxy 返回类型（TTY LineEditor 和测试都假设 List）。
        my @matches = try { self.session.completions($code, $pos).List } // ();
        my Int $s = $pos - 1;
        while $s >= 0 && $code.substr($s, 1) ~~ /<:alpha> | <:digit> | '_' | '$' | '@' | '%'/ { $s-- }
        my Int $start = ($s + 1) min $pos;
        %( op => 'complete', ok => True, matches => @matches,
           cursor_start => $start, cursor_end => $pos );
    }

    method !is-complete(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        # `is-incomplete` 是纯函数（不碰会话状态），所以不需要往返引擎。
        my Bool $more = False;
        try { $more = is-incomplete($code) };
        %( op => 'is_complete', ok => True,
           status => ($more ?? 'incomplete' !! 'complete'),
           indent => '' );
    }

    method !inspect(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        my Int $pos  = (%msg<cursor_pos> // $code.chars).Int;
        my Str $name = self!word-at($code, $pos);
        return %( op => 'inspect', ok => True, found => False, text => '' )
            unless $name.chars;
        my %h = $!kernel.inspect($name);
        %( op => 'inspect', ok => True, found => ?%h<ok>,
           text => (%h<text> // '').Str );
    }

    # ── 0.132.0 / §4.9j：history_request / interrupt_request / stdin ────
    # history_request：Jupyter 的 tail / range / search。tail 与 range 有
    # 真实数据（引擎历史按行序传来）；search 需要 pattern 参数，当前回空。
    method !history(%msg --> Hash) {
        my @items;
        try { @items = self.session.history.List };
        my Str $mode = (%msg<hist_access_type> // 'tail').Str;
        my @sel;
        given $mode {
            when 'tail' {
                my Int $n = (%msg<n> // @items.elems).Int;
                @sel = $n > 0 ?? @items.tail($n).List !! ().List;
            }
            when 'range' {
                my Int $from = (%msg<start> // 0).Int max 0;
                my Int $to   = min((%msg<stop> // @items.elems).Int, @items.elems);
                @sel = $from < $to ?? @items[$from ..^ $to].List !! ().List;
            }
            default { @sel = ().List }
        }
        # Jupyter 的形状是 [[input, output], ...]；Rakuish 不记录每格的输出，
        # 第二个位置如实给 null。
        my @history = @sel.map({ [ $_.Str, Any ] }).List;
        %( op => 'history_request', ok => True, history => @history );
    }

    # 单线程协议循环：interrupt_request 只可能落在两格之间，正在跑的 EVAL
    # 与读 stdin 的是同一个线程 —— 这里读不到它。如实回报「没有在跑的格」，
    # 不假装把求值打断了（V-182 的同一条原则）。
    method !interrupt(--> Hash) {
        %( op => 'interrupt_request', ok => True, interrupted => False,
           note => '格与格之间没有正在执行的求值' );
    }

    method !input-request(--> Hash) {
        %( op => 'input_request', ok => False,
           error => 'input_request 是内核→前端的请求；客户端请发 input_reply' );
    }

    method !input-reply(--> Hash) {
        %( op => 'input_reply', ok => False,
           error => '没有待处理的输入请求（notebook 内核暂不支持 stdin）' );
    }

    method !shutdown(--> Hash) {
        try { self.session.shutdown if self.session.^can('shutdown') };
        %( op => 'shutdown', ok => True );
    }

    method !cwd(--> Str) {
        my $s = try { self.session.sys.cwd.Str };
        ($s.defined ?? $s !! $*CWD.Str);
    }

    # 光标前的最后一个名字：`$x` / `Box` / `JSON::Fast` / `ls`。
    method !word-at(Str $code, Int $pos --> Str) {
        my Str $pre = $code.substr(0, ($pos max 0) min $code.chars);
        my $m = $pre ~~ / [ '$' | '@' | '%' ]? <[A..Za..z_]> <[A..Za..z0..9_:-]>* $/;
        $m.defined ?? ~$m !! '';
    }
}

# ── 协议循环 ────────────────────────────────────────────────────────
# I/O 全部走回调（0.136.0 / ADR-0037 §10）：`serve()` 不再直接碰
# `$*IN` / `$*OUT`，「读一行请求 / 写一帧响应」由调用方给。默认值就是
# 进程标准流，`bin/rakuish-notebook` 与 Jupyter 桥一个字都不用改；
# 测试与未来的 web UI / socket 传输传自己的闭包即可。

# 启动文件：与 TTY 同一套优先级（RAKUISH_RC → ~/.rakuishrc），
# RAKUISH_NO_RC 关掉。rc 的输出放进 ready 帧，由桥决定显不显示。
my sub rc-path(--> IO::Path) {
    my Str $env = (%*ENV<RAKUISH_RC> // '').Str;
    return $env.IO if $env.chars;
    return IO::Path if (%*ENV<RAKUISH_NO_RC> // '').Str.chars;
    my $home = try { $*HOME };
    return IO::Path unless $home.defined;
    my $p = $home.add('.rakuishrc');
    $p.e ?? $p !! IO::Path;
}

our sub serve(
    IO::Path :$lib,
    # 读一行请求；Nil 表示 EOF（前端关掉了输入）。
    :&read-line = -> { $*IN.get },
    # 写一帧响应 JSON。参数**不带**换行 —— 换行与 flush 由传输自己决定
    # （行协议加 "\n" 并 flush；消息式传输（如 ZMQ）只要 JSON 本体）。
    :&write-frame = -> Str $json { $*OUT.print($json ~ "\n"); $*OUT.flush },
    --> Nil
) is export {
    # 0.113.0 / V-305：写端从「主线程独享」变成「主线程 + 看门狗线程」，
    # 一帧必须整体落盘 —— 两条线程各写半行会让前端解析出一坨 JSON 碎片。
    # 锁在 serve 内部（一次 serve 一个输出通道），序列化也只做一次。
    my Lock $out-lock .= new;
    my &emit = -> %h {
        my Str $json = to-json(%h, :!pretty);
        $out-lock.protect: { try { write-frame($json) } };
        Nil
    };

    my $engine = $lib.defined
        ?? Rakuish::Eval::Client.new(:lib($lib))
        !! Rakuish::Eval::Client.new();

    # 0.132.0 / §4.9j：stdin 通道。引擎的 stdin 是协议管道，prompt 读不到
    # 用户键盘 —— 发 input_request 给 Jupyter，然后阻塞在 Channel 上等
    # 主循环把 input_reply 填进来。用 Channel 不用 Promise：一格内可能
    # 连续多次 prompt()，每次都要独立的 reply。
    my Channel $input-reply .= new;
    $engine.input-handler = -> Str $prompt-text = '' {
        emit %( event => 'input_request', prompt => $prompt-text, password => False );
        $input-reply.receive();
    };
    $engine.start;

    my IO::Path $rc = rc-path();
    my $sess = Rakuish::Eval::Proxy.new(
        :client($engine), :rc-path($rc.defined ?? $rc.Str !! ''));
    # notebook 没有终端：颜色关掉（`display` 里本来也零 ANSI），
    # 也不开 stream（引擎的 chunk 帧会写本进程的 stdout，即协议流）。
    $sess.set-color(False);
    $sess.set-display(True);
    # 0.113.0 / V-305：引擎生死 → 一条 `event: engine` 帧。前端据此挂横幅、
    # 提示「状态已丢失」；Jupyter 桥只转播**空闲期**死亡（执行中的那次
    # 已经写在 execute 回复的 traceback 里了，重复播报是噪音）。
    $sess.on-engine-event = -> %ev { emit %( event => 'engine', |%ev ) };

    my Str $rc-out = '';
    my Str $rc-err = '';
    if $rc.defined && $rc.e {
        my $h = try { $sess.run-rc($rc.Str) };
        if $h.defined {
            $rc-out = ($h<out> // '').Str;
            $rc-err = ($h<err> // '').Str;
        }
        else {
            $rc-err = "启动文件执行失败: {$rc.Str}";
        }
    }

    my $kernel = Kernel.new(
        :session($sess),
        :policy(Policy.new(:profile<notebook>)),
        :audit(Rakuish::Audit.new(:default-origin<notebook>,
                                  :enabled(!(%*ENV<RAKUISH_NO_AUDIT> // '').Str.chars))),
    );
    my $front = Frontend.new(:kernel($kernel));

    # 0.113.0 / V-305：空闲期死亡的推送。
    #
    # 主循环阻塞在等读请求上（默认 `$*IN.get`）—— 引擎死在没有请求的那一刻，前端要等到
    # 下一条输入才知道（而那时它已经自动重启，前端看到的是「刚跑就失败」）。
    # 用一条独立的 OS 线程每 250ms 读一次 `alive`：读一个 Bool 的代价可以
    # 忽略，且它不占用调度器线程池（`Thread.start` 而不是 `start`）。
    #
    # `$busy` 的意义：执行中死亡由 `!revive` 负责报告（kind=restart），
    # 看门狗这时再喊一声「死了」只会让前端闪两条横幅。
    my Bool $stopping = False;
    my Bool $busy     = False;
    my Bool $noted    = False;
    Thread.start(name => 'rakuish-engine-watch', {
        loop {
            sleep 0.25;
            last if $stopping;
            my Bool $alive = True;
            try { $alive = ?$engine.alive };
            if $alive {
                $noted = False;
                next;
            }
            next if $busy || $noted;
            $noted = True;
            emit %( event => 'engine', kind => 'dead', alive => False,
                    reason => '引擎进程在空闲时退出（下一条输入会自动重启）' );
        }
    });

    # 0.136.1 / V-340：读端必须在**独立线程**上。
    #
    # 0.132.0 的 stdin 通道只修了引擎那一侧：引擎的 input-handler 会 emit
    # input_request，然后阻塞等 input_reply。但 serve 的主循环会在
    # `$front.handle(%req)` 里被 execute **整格阻塞** —— 同一线程再去 read-line
    # 就永远读不到那条 input_reply，`prompt` 在 notebook 里照样死锁
    # （实测：只出 ready/kernel_info/busy/execute_input 四帧，没有 input_request
    # 之后的任何响应）。
    #
    # 所以拆成「读线程 → Channel → 主循环」：读线程专门把 input_reply 直接投进
    # $input-reply（这一对只在引擎内部流转，不归 Frontend.handle 管），其余请求
    # 原样排队给主循环。
    my Channel $ops .= new;
    Thread.start(name => 'rakuish-ops-reader', {
        loop {
            my $l = read-line();
            unless $l.defined { $ops.close; last }
            my $m = try { from-json($l) };
            if $m.defined && $m ~~ Hash && (($m<op> // '') eq 'input_reply') {
                $input-reply.send(($m<value> // '').Str);
                emit %( op => 'input_reply', ok => True );
                next;
            }
            $ops.send($l);
        }
    });

    # 引擎 pid 也写进 ready：调试与「前端想自己重启它」都得有句柄。
    # 注意 `Proc::Async.pid` 给的是 **Promise**（不是 Int），必须 `.result`。
    my Int $ep = 0;
    try { $ep = $engine.proc.pid.result.Int if $engine.proc.defined };

    emit %( event => 'ready', language => 'raku', pid => $*PID,
            engine_pid => $ep,
            cwd => $sess.sys.cwd.Str,
            version => KERNEL-VERSION,
            startup_out => $rc-out, startup_err => $rc-err );

    loop {
        # 读线程投递；通道关闭（EOF）后 receive 抛，`try` 收成 Nil 即退出。
        my $line = try { $ops.receive };
        last unless $line.defined;
        next unless $line.trim.chars;
        my $msg = try { from-json($line) };
        my Bool $good = so ($msg.defined && $msg ~~ Hash);
        my %req = $good ?? $msg.Hash !! %( op => '' );

        my Str $op = (%req<op> // '').Str;

        # input_reply 由读线程直接投进 $input-reply（见上），主循环不再处理。
        # busy / idle 只包 execute：补全与 inspect 是**按键**触发的，
        # 每敲一个字符都播一次忙会让状态栏闪成噪音（Jupyter 也这么划）。
        my Bool $exec = $op eq 'execute';
        my %extra = %req<id>:exists ?? %( id => %req<id> ) !! %();
        my $t0 = now;

        if $exec {
            $busy = True;
            emit %( event => 'busy', op => $op, |%extra );
            # 0.132.0 / P2.4：execute_input 广播 —— Jupyter 前端据此更新
            # In[n] 标签。execution_count 是执行前的 index（会话从 0 递增，
            # 但 execute 请求返回时已 +1，所以广播里用 +1 后的）。
            my Int $n = 0;
            try { $n = $sess.index.Int + 1 };
            emit %( event => 'execute_input',
                    code => (%req<code> // '').Str,
                    execution_count => $n, |%extra );
        }

        my %rep = $good
            ?? $front.handle(%req)
            !! %( ok => False, error => '请求不是 JSON 对象', op => '' );

        $busy = False if $exec;
        emit(%rep);
        # 0.124.0 / ADR-0048 P1：一格里的 display() 逐条发 display_data。
        # execute 回复里仍保留 display（旧前端只认一行响应），这里只是让
        # Jupyter 形状的前端也能拿到标准的独立帧。
        if $exec && %rep<display> ~~ Hash {
            my $ds = %rep<display><displays>;
            if $ds ~~ Positional {
                for $ds.List -> $d {
                    next unless $d ~~ Hash;
                    my %d  = $d.Hash;
                    my %mime = %d<mime> ~~ Hash ?? %d<mime>.Hash !! %();
                    %mime{'text/plain'} = (%d<content> // '').Str unless %mime.elems;
                    emit %( event => 'display_data', op => 'execute', |%extra,
                            data => %mime,
                            metadata => (%d<meta> ~~ Hash ?? %d<meta>.Hash !! %()) );
                }
            }
        }
        # idle 在回复**之后**：Jupyter 的次序也是 busy → 输出 → reply → idle，
        # 前端看到 idle 就知道这一格彻底结束了，可以解锁输入。
        if $exec {
            emit %( event => 'idle', op => $op,
                    ms => ((now - $t0) * 1000).Int, |%extra );
        }
        last if (%rep<op> // '') eq 'shutdown';
    }
    $stopping = True;
    try { $engine.shutdown };
    Nil;
}
