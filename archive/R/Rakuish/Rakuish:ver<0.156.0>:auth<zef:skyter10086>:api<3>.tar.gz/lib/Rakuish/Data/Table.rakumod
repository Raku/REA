unit class Rakuish::Data::Table;

# Rakuish::Data::Table —— 结构化表格值（Nushell/Elvish 风格的“数据优先”）。
#
#   my $t = Table.from-rows([{name => 'a', size => 1}, ...]);
#   $t.where({ .<size> > 0 }).select('name').sort-by('name').to-text
#
# 这不是 shell 文本表格：rows 是真 Hash，get/where/select 可继续组合。

use JSON::Fast;

# 0.134.0 / 契约收口：三个属性**内部私有**，对外只给只读视图。
# 以前是 `has @.columns is rw` / `has @.rows is rw` / `has %.types is rw`：
# 任何代码都能 `$t.rows = ...` 而 columns / types 不跟着变，三个属性之间
# 没有任何不变式（表就可能自相矛盾）。全库 37 处**只读**消费、0 处写入，
# 所以收成私有 + 只读访问器是零破坏的（`t/11` 断言写入会被拒绝）。
has @!columns;
has @!rows;
has %!types;                    # column => int/num/str/bool/datetime/list/map/any

# 只读视图。想造新表就走 Table.new / 方法链。
# `types` 必须 `.clone`：`Hash.Hash` 返回的是**它自己**，不克隆的话
# `$t.types = %()` 会把内部 `%!types` 直接清空（实测 0.134.0 踩到，
# 「看起来只改了个副本，其实改的是本体」）。Array 的 `.List` 不会这样，
# 也不克隆（`rows` 在热点路径上，5 万行的浅拷贝没必要）。
method columns(--> List) { @!columns.List }
method rows(--> List) { @!rows.List }
method types(--> Hash) { %!types.clone }

# 私有写入点（只有 new 用）。Raku 不允许对**别的实例**写私有属性
# （`$obj!columns` 会报 "No such private method"），所以包一层 setter。
method !set-data(@cols, @rows, %types) {
    @!columns = @cols;
    @!rows = @rows;
    %!types = %types;
}

method new(:$columns = [], :$rows = [], :$types) {
    my @r = self!normalize-rows($rows);
    my @cols = $columns ~~ Positional ?? $columns.List !! ($columns,);
    @cols = @r[0].keys.sort unless @cols.elems || !@r.elems;
    my %t;
    if $types ~~ Hash {
        %t = $types.Hash;
    }
    if %t.elems == 0 {
        for @cols -> $c {
            %t{$c.Str} = self!infer-type(@r.map({ $_{$c} }).List);
        }
    }
    my $obj = self.bless;
    $obj!set-data(@cols, @r, %t);
    $obj;
}

method !infer-type(@values --> Str) {
    my @v = @values.grep({ .defined });
    return 'any' unless @v.elems;
    return 'bool'  if @v.all ~~ Bool;
    return 'int'   if @v.all ~~ Int;
    return 'num'   if @v.all ~~ (Int | Num | Rat);
    return 'datetime' if @v.all ~~ (DateTime | Instant);
    return 'list'  if @v.all ~~ Positional;
    return 'map'   if @v.all ~~ Associative;
    return 'str'   if @v.all ~~ Str;
    'any';
}

method !normalize-rows($rows --> List) {
    my @raw = $rows ~~ Associative
        ?? ($rows,)
        !! $rows.List;
    my @out;
    my @pairs;
    for @raw -> $r {
        if $r ~~ Pair {
            @pairs.push($r);
            next;
        }
        if @pairs {
            my %h;
            for @pairs -> $p { %h{$p.key} = $p.value }
            @out.push(%h);
            @pairs = ();
        }
        @out.push($r.Hash) if $r ~~ Associative;
    }
    if @pairs {
        my %h;
        for @pairs -> $p { %h{$p.key} = $p.value }
        @out.push(%h);
    }
    @out.List;
}

submethod TWEAK() {
    if @!columns.elems == 0 && @!rows.elems {
        @!columns = @!rows[0].keys.sort;
    }
}

method from-rows(@rows, :@columns, :$types --> Rakuish::Data::Table) {
    my @normalized = self!normalize-rows(@rows);
    my @cols = @columns.elems
        ?? @columns
        !! (@normalized.elems ?? @normalized[0].keys.sort !! ());
    Rakuish::Data::Table.new(:columns(@cols), :rows(@normalized), :$types);
}

method elems(--> Int) { @!rows.elems }

# ── 0.64 大结果保护 ─────────────────────────────────────────────────
# batches 是惰性 Seq of Table：调用方可以逐批处理 / 提前退出，不必先把
# 全部批次物化。渲染的 :max-rows 则是展示上限，避免一次拼出巨大字符串。
method batches(Int :$size = 1000 --> Seq) {
    my Int $n = $size max 1;
    @!rows.rotor($n, :partial).map(-> @chunk {
        Rakuish::Data::Table.new(:columns(@!columns), :rows(@chunk),
                                 :types(%!types));
    });
}

method !row-limit($max-rows) {
    $max-rows.defined && $max-rows.Int >= 0 ?? $max-rows.Int !! Nil
}

method !display-rows(:$max-rows --> List) {
    my $n = self!row-limit($max-rows);
    return @!rows.List unless $n.defined;
    return @!rows.List if @!rows.elems <= $n;
    @!rows.head($n).List
}

method !truncation-note(:$max-rows --> Str) {
    my $n = self!row-limit($max-rows);
    ($n.defined && @!rows.elems > $n)
        ?? "\n... 共 {@!rows.elems} 行，只显示前 $n 行"
        !! ''
}

method schema(--> Rakuish::Data::Table) {
    my @rows;
    for @!columns -> $c {
        my Str $name = $c.Str;
        my Bool $nullable = @!rows.elems
            && @!rows.grep({ !$_{$name}.defined }).elems > 0;
        @rows.push({
            name     => $name,
            type     => %!types{$name} // 'any',
            nullable => $nullable,
        });
    }
    Rakuish::Data::Table.new(
        :columns<name type nullable>,
        :rows(@rows),
        :types({ name => 'str', type => 'str', nullable => 'bool' }),
    );
}

# 0.69 / ADR-0006 §3：列级摘要仍是**值**（Table），不是文本报告。
# 与 Engine.describe 返回同样的 name/type/nullable/non_null/distinct/total/sample
# 列集合，方便把「文件读进来的 Table」与「数据库里的表」用同一套代码处理。
method describe(Int :$sample = 3 --> Rakuish::Data::Table) {
    my Int $n = ($sample max 0) min 20;
    my @rows;
    for @!columns -> $c {
        my Str $name = $c.Str;
        my @defined = @!rows.map({ $_{$name} }).grep({ .defined }).List;
        my @distinct = @defined.map(*.Str).unique.List;
        @rows.push({
            name     => $name,
            type     => %!types{$name} // 'any',
            nullable => @defined.elems < @!rows.elems,
            non_null => @defined.elems,
            distinct => @distinct.elems,
            total    => @!rows.elems,
            sample   => @distinct.head($n).join(' | '),
        });
    }
    Rakuish::Data::Table.from-rows(@rows,
        :columns<name type nullable non_null distinct total sample>)
}

method column-type(Str $col --> Str) { %!types{$col} // 'any' }

method limit(Int $n --> Rakuish::Data::Table) {
    my @rows = @!rows.head($n);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

# 0.128.0 / §4.9g：Table.head/tail — 评审说 `$t.head(2)` 走到 Any.head
# 返回包着整表的 Seq（因为自定义类没有 head 方法）。limit 已经能取前 N，
# 现在用 head/tail 名字补齐，语义对齐 pandas/DataFrame。
multi method head(Int $n = 10 --> Rakuish::Data::Table) {
    self.limit($n);
}
multi method head(Range $r --> Rakuish::Data::Table) {
    self.limit($r.max + 1).offset($r.min);
}

method tail(Int $n = 10 --> Rakuish::Data::Table) {
    my @rows = @!rows.tail($n);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method offset(Int $n --> Rakuish::Data::Table) {
    my @rows = @!rows.skip($n).List;
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method each(&f --> List) {
    @!rows.map(&f).List;
}

method count(--> Int) { @!rows.elems }

# 数值口径与 Stream.!numeric 保持一致：CSV / `!` 输出里的数字是**字符串**，
# 只按 `~~ Numeric` 过滤会把它们全丢掉（实测 sum('size') 返回 0）。
# 这里按字面数值再认一次，不做进制 / 千分位。
my constant NUMERIC-LITERAL = /^ '-'? \d+ [ '.' \d+ ]? $/;

method !numeric(Str $col --> List) {
    my @out;
    for @!rows -> $r {
        my $v = $r{$col};
        next unless $v.defined;
        if $v ~~ Numeric { @out.push($v.Num); next }
        my Str $s = $v.Str.trim;
        @out.push($s.Num) if $s ~~ NUMERIC-LITERAL;
    }
    @out.List;
}

# 0.155.0 / ADR-0069：**空列的聚合是 NULL，不是 0。**
#   `sum` / `mean` 原来在空列上返回 `0e0`，`min` / `max` 返回 `Nil` —— 同一个
#   「没有值」在 Table 里有两个答案，而 SQL（以及 Duckula）回的是 NULL。现在
#   统一成 `Any`（Rakuish 里 NULL 的值表示），和 `$t.sql(...)` 拿回的空值同
#   口径；调用方用 `.defined` 判断，别指望 `+ 0`。
method sum(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? @v.sum.Num !! Any;
}

method mean(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? (@v.sum / @v.elems).Num !! Any;
}

method min(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? @v.min !! Any;
}

method max(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? @v.max !! Any;
}

method distinct(*@cols --> Rakuish::Data::Table) {
    my @keep = @cols.elems ?? @cols.map(*.Str) !! @!columns;
    my @rows;
    my %seen;
    for @!rows -> $row {
        my Str $key = @keep.map({ ($row{$_} // '') ~ "\x[1F]" }).join('');
        next if %seen{$key};
        %seen{$key} = True;
        @rows.push($row);
    }
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

# 列合并规则：左列在前、右列其次；右列与已有列重名时加 :suffix（默认 _right），
# **不丢列**。只做纯计算，不碰行 —— Table.join / Stream.join / Stream.zip 共用，
# 免得三处各有一套后缀规则（0.94 / ADR-0029）。
# 返回：columns（输出列名）与 right-map（右列名 → 输出列名）。
method join-columns(@left-cols, @right-cols, Str :$suffix = '_right' --> Hash) {
    my @cols = @left-cols.map(*.Str);
    my %seen = @cols.map({ $_ => True });
    my @map;
    for @right-cols.map(*.Str) -> $c {
        my Str $name = %seen{$c} ?? $c ~ $suffix !! $c;
        %seen{$name} = True;
        @cols.push($name);
        @map.push($c => $name);
    }
    %( columns => @cols.List, right-map => @map.List );
}

# 把一条右行按 right-map 并进左行；$r 未定义时只输出左行
# （left / outer 的未匹配分支）。两侧都不改原 Hash。
method join-merge($l, $r, @right-map --> Hash) {
    my %row = $l.Hash;
    return %row unless $r.defined;
    for @right-map -> $p { %row{$p.value} = $r{$p.key} }
    %row;
}

# 关系连接。**默认 left**，与本项目 0.6x 起的 Table.join 行为一致；
# 想要 SQL / POSIX join 的语义写 :how<inner> —— 两个默认值不同的 API 比
# 一个会静默改变既有脚本行为的 API 更糟，所以这里选择「保持历史默认」。
method join(Rakuish::Data::Table $other, Str :$on,
            Str :$left-on = $on, Str :$right-on = $on,
            Str :$how = 'left', Str :$suffix = '_right'
            --> Rakuish::Data::Table) {

    X::Rakuish::Unsupported.new(
        :detail('join 需要 :on（或同时给 :left-on 与 :right-on）')
    ).throw unless $left-on.defined && $right-on.defined;

    my Str $mode = $how.lc;
    X::Rakuish::Unsupported.new(
        :detail("join 的 :how 只支持 inner / left / right / outer，收到 '{$how}'")
    ).throw unless $mode (elem) ('inner', 'left', 'right', 'outer');

    my %plan = self.join-columns(@!columns, $other.columns, :$suffix);
    my @cols = %plan<columns>.List;
    my @rmap = %plan<right-map>.List;

    my %idx;
    my @order;
    for $other.rows -> $r {
        my Str $k = ($r{$right-on} // '').Str;
        my %slot = %( row => $r, hit => False );
        %idx{$k}.push(%slot);
        @order.push(%slot);
    }

    my @rows;
    for @!rows -> $l {
        my Str $k = ($l{$left-on} // '').Str;
        my $slots = %idx{$k};
        if $slots.defined && $slots.elems {
            for $slots.list -> %slot {
                %slot<hit> = True;
                @rows.push(self.join-merge($l, %slot<row>, @rmap));
            }
        }
        elsif $mode eq 'left' || $mode eq 'outer' {
            @rows.push(self.join-merge($l, Nil, @rmap));
        }
    }
    if $mode eq 'right' || $mode eq 'outer' {
        for @order -> %slot {
            next if %slot<hit>;
            @rows.push(self.join-merge(%(), %slot<row>, @rmap));
        }
    }

    my %types = %!types;
    for @rmap -> $p {
        %types{$p.value} = $other.column-type($p.key);
    }
    Rakuish::Data::Table.new(:columns(@cols), :rows(@rows), :types(%types));
}

method where(&pred --> Rakuish::Data::Table) {
    my @rows = @!rows.grep(&pred);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method get(Str $col --> List) {
    @!rows.map({ $_{$col} }).List;
}

method select(*@cols --> Rakuish::Data::Table) {
    my @keep = @cols.map(*.Str);
    my @rows = @!rows.map(-> $row {
        my %r;
        for @keep -> $c { %r{$c} = $row{$c} if $row{$c}:exists }
        %r;
    });
    my %t;
    for @keep -> $c { %t{$c.Str} = %!types{$c.Str} // 'any' }
    Rakuish::Data::Table.new(:columns(@keep), :rows(@rows), :types(%t));
}

# 0.120.0 / V-315：把这张表交给 DuckDB（Duckula）跑一段 SQL，结果仍是 Table。
#   $t.sql('select kind, count(*) c from rakuish_t group by 1 order by c desc')
# 表在 SQL 里的名字默认 `t`（:name 可改）。Duckula 是可选依赖：
# 没装时抛 X::Rakuish::Unsupported，并给安装提示，不会在 `use` 阶段就把
# 原生 libduckdb 拖进来。
method sql(Str $query, Str :$name = 't' --> Rakuish::Data::Table) {
    require Rakuish::Data::Duck;
    Rakuish::Data::Duck::table-sql(self, $query, :$name);
}

method sort-by(Str $col, Bool :$reverse = False --> Rakuish::Data::Table) {
    my @rows = @!rows.sort(-> $a, $b {
        my $av = $a{$col};
        my $bv = $b{$col};
        my $c = ($av.defined ?? $av !! '') cmp ($bv.defined ?? $bv !! '');
        $reverse ?? (($bv.defined ?? $bv !! '') cmp ($av.defined ?? $av !! '')) !! $c;
    });
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method first(Int $n = 1 --> Rakuish::Data::Table) {
    my @rows = @!rows.head($n);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method last(Int $n = 1 --> Rakuish::Data::Table) {
    my @rows = @!rows.tail($n);
    Rakuish::Data::Table.new(:columns(@!columns), :rows(@rows), :types(%!types));
}

method !cell($v --> Str) {
    return '' unless $v.defined;
    given $v {
        when IO::Path { $v.Str }
        when Hash | Positional { JSON::Fast::to-json($v, :!pretty) }
        default { $v.Str }
    }
}

# pandas 式可选行（评审 P1.6 / V-341）：`:index` 前置行号列、`:dtype` 追加
# 一行 `dtypes: c1 int, c2 str`、`:shape` 追加一行 `(N rows × M cols)`。
# 三个开关默认全关 —— 不带选项的输出形态是既有契约（`gist` / `Str` 都走
# 这里，t/08 / t/11 / t/17 按它断言），新增能力不能改变老输出。
method to-text(:$max-rows, Bool :$index = False, Bool :$dtype = False,
               Bool :$shape = False --> Str) {
    my @headers = @!columns.map(*.Str);
    return '' unless @headers.elems;
    my @shown = self!display-rows(:$max-rows).List;
    my @heads = $index ?? ('#', |@headers) !! @headers;
    # 行号是**当前表内**的 0 基序号（Table 没有 pandas 那种可命名的 index）：
    # limit/offset 之后从 0 重新数，别指望它等于原始行号。
    my @all = @shown.kv.map(-> $i, $row {
        my @cells = @headers.map({ self!cell($row{$_}) });
        $index ?? ("{$i}", |@cells) !! @cells.List;
    }).List;
    my @widths = @heads.kv.map(-> $i, $h {
        my Int $w = $h.chars;
        for @all -> $r { $w = $r[$i].chars if $r[$i].chars > $w }
        $w;
    });
    my Str $line = @widths.map(-> $w { '-' x $w }).join('  ');
    my Str $head = @heads.kv.map(-> $i, $h { $h ~ (' ' x (@widths[$i] - $h.chars)) }).join('  ');
    my @lines = $head, $line;
    for @all -> $r {
        @lines.push($r.kv.map(-> $i, $v { $v ~ (' ' x (@widths[$i] - $v.chars)) }).join('  '));
    }
    # 省略提示落在数据行之后、dtypes/shape 之前：贴在最后一行后面会被
    # 读成「shape 是被截断的」，而 shape 讲的是整表。
    my Str $note = self!truncation-note(:$max-rows);
    @lines.push($note.trim) if $note.chars;
    @lines.push(self!dtype-line) if $dtype;
    @lines.push(self!shape-line) if $shape;
    @lines.join("\n");
}

method !dtype-line(--> Str) {
    'dtypes: ' ~ @!columns.map(-> $c { "{$c.Str} {%!types{$c.Str} // 'any'}" }).join(', ');
}

# shape 用**整表**行数（不是被 :max-rows 截断后显示的行数）：pandas 的
# `(1000 rows × 3 cols)` 讲的是表有多大，不是这次打印了多少行。
method !shape-line(--> Str) {
    '(' ~ self.count ~ ' rows × ' ~ @!columns.elems ~ ' cols)';
}

# JSON 里不能插入「省略」文本，否则不再是合法 JSON：这里只截断行数。
method to-json(Bool :$pretty = False, :$max-rows --> Str) {
    JSON::Fast::to-json(self!display-rows(:$max-rows).Array, :$pretty);
}

method to-markdown(:$max-rows --> Str) {
    my @headers = @!columns.map(*.Str);
    return '' unless @headers.elems;
    my @lines;
    @lines.push('| ' ~ @headers.join(' | ') ~ ' |');
    @lines.push('| ' ~ @headers.map({ '---' }).join(' | ') ~ ' |');
    for self!display-rows(:$max-rows) -> $row {
        @lines.push('| ' ~ @headers.map({ self!cell($row{$_}) }).join(' | ') ~ ' |');
    }
    @lines.join("\n") ~ self!truncation-note(:$max-rows);
}

# ── HTML 出口（0.110.0 / V-301）──────────────────────────────────────
# 给 notebook / Jupyter 的 `text/html` 用：同一份 rows，换成标签而不是对齐空格。
# 转义只有 `html-escape` 一份实现，和 to-text / to-markdown 共用 !display-rows
# 与 !cell —— 不重写取值规则。样式是内联的：Jupyter 不会给我们加 CSS，
# 裸 <table> 在页面上没有边框，读起来比等宽文本还差。
#
# 它是纯函数（不碰属性之外的 IO），所以可以 `Rakuish::Data::Table.html-escape(...)`
# 在类型对象上调用 —— 与 csv-cell 同一个模式。
method html-escape($v --> Str) {
    my Str $s = $v.defined ?? $v.Str !! '';
    # `&` 必须先换，否则会把后面生成的实体再转一次。
    $s.subst('&', '&amp;', :g)
      .subst('<', '&lt;', :g)
      .subst('>', '&gt;', :g)
      .subst('"', '&quot;', :g);
}

method to-html(:$max-rows --> Str) {
    my @headers = @!columns.map(*.Str);
    return '' unless @headers.elems;
    my Str $th = 'border-bottom:1px solid #ccc;padding:4px 10px;'
               ~ 'text-align:left;background:#f4f4f4;font-weight:600';
    my Str $td = 'border-bottom:1px solid #ddd;padding:4px 10px;text-align:left';
    my Str $head = @headers.map({
        '<th style="' ~ $th ~ '">' ~ self.html-escape($_) ~ '</th>'
    }).join;
    my @body;
    for self!display-rows(:$max-rows) -> $row {
        @body.push('<tr>' ~ @headers.map({
            '<td style="' ~ $td ~ '">' ~ self.html-escape(self!cell($row{$_})) ~ '</td>'
        }).join ~ '</tr>');
    }
    my Str $tbl = '<table style="border-collapse:collapse;font:13px/1.45 '
                ~ 'ui-monospace,SFMono-Regular,Consolas,monospace">'
                ~ '<thead><tr>' ~ $head ~ '</tr></thead>'
                ~ '<tbody>' ~ @body.join ~ '</tbody></table>';
    # 截断说明留在表下面（HTML 里不能像文本那样塞进表尾）。
    my Str $note = self!truncation-note(:$max-rows).trim;
    $note.chars
        ?? $tbl ~ "\n<p style=\"color:#666;font-size:12px;margin:6px 0 0\">"
                 ~ self.html-escape($note) ~ '</p>'
        !! $tbl;
}

# 0.91.0：CSV 序列化下沉到 Table —— Stream 的 `.csv` 出口与
# `Rakuish::Data::to-csv-data` 共用同一份引号规则，不抄第二遍。
# CSV 序列化只有这一份实现：`to-csv` 用它拼整份文本，`Stream` 的
# `.exec(:format<csv>)` 用它**逐行**往子进程 stdin 里写（0.93 / ADR-0028）。
# 引号 / 逗号 / 换行的规则写两处迟早会漂，所以拆成三个可按行调用的方法。
# 都是纯函数，不碰属性 —— 因此可以 `Rakuish::Data::Table.csv-line(...)` 这样
# 在类型对象上调用，不需要 Stream 先造一个 Table。
method csv-cell($v --> Str) {
    my Str $s = $v.defined ?? $v.Str !! '';
    my Bool $need-quote = $s.contains(',') || $s.contains('"')
        || $s.contains("\n") || $s.contains("\r");
    $need-quote ?? '"' ~ $s.subst('"', '""', :g) ~ '"' !! $s;
}

method csv-header(@cols --> Str) {
    @cols.map({ self.csv-cell($_) }).join(',');
}

method csv-line(@cols, $row --> Str) {
    @cols.map({ self.csv-cell($row{$_}) }).join(',');
}

method to-csv(--> Str) {
    my @headers = @!columns.map(*.Str);
    return '' unless @headers.elems;
    my @lines;
    @lines.push(self.csv-header(@headers));
    for @!rows -> $row {
        @lines.push(self.csv-line(@headers, $row));
    }
    @lines.join("\n") ~ "\n";
}

method gist(--> Str) { self.to-text }
