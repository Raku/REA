unit module Rakuish::Eval;

# Rakuish::Eval —— 引擎子进程的父侧客户端（0.83.0 / ADR-0021）。
#
# 只做一件事：把「一行输入」变成「一个响应」，并保证**引擎死了前端不死**。
# 语义全在子进程的 `Rakuish::Eval::Server` 里（它就是原来的 Session），
# 这一侧刻意不认识 Raku 语义 —— 不解析 `!`、不判断续行、不碰 `Out[n]`。
#
# 协议是**同一条管道上的请求/响应**，不是并发 RPC：同一时刻只有一条在飞。
# 父进程写一行 → 读若干行（`tty` 中间帧可选）→ 拿到同 seq 的终帧。
#
# 崩溃模型（ADR-0021 §3）：
#   · 子进程 `exit` / 段错误 / 被 kill ⇒ stdout EOF ⇒ Channel 关闭；
#   · 正在等的 `receive` 抛异常 ⇒ 收敛成 `X::Rakuish::Eval::Dead`；
#   · 上层（Proxy）捕获后重启一次，并把「状态已丢失」写进结果文本。
# 不承诺**求值中**中断（`while 1 {}` 仍需外部 kill），见 ADR-0021 §6。

use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Eval::Protocol;   # 0.133.0 / ADR-0051：协议契约（版本 + 帧）
use JSON::Fast;
# 0.117.0 / V-309：Windows Job Object。非 Windows 上这个模块只是几条
# 声明（native 符号调用时才解析），所有调用点都被 `supported()` 挡着。
use Rakuish::Sys::WinJob;

class X::Rakuish::Eval::Dead is Exception is export {
    has Str $.detail = '引擎进程已退出';
    method message(--> Str) { $!detail }
}

# 0.85.0 / ADR-0023：用户按了 Ctrl-C，不是引擎自己崩的。
# 两者都要重启引擎，但**归因不同** —— 把「我按了中断」说成「引擎崩了」
# 会让用户以为出了问题，下次就不敢用了。
class X::Rakuish::Eval::Interrupted is Exception is export {
    has Str $.detail = '求值被用户中断';
    method message(--> Str) { $!detail }
}

class Client is export {
    has Str $.raku = $*EXECUTABLE.Str;
    has IO::Path $.lib;              # 开发环境的 -I 路径；已安装时不必给
    has &.tty-exec;                  # (Str $exe, @argv --> Result)，父进程执行
    # 0.144.0 / V-348 / ADR-0057：`! --tty a | b` 的整条管道也在父进程执行
    # （只有它的 stdin 是真终端）。签名 (@stages --> Result)。
    has &.pipe-exec;
    # 0.96.0 / ADR-0031：作业控制也在父进程执行（持有真终端 + 作业表）。
    # 签名 (Str $op, @args --> Any)，$op ∈ bg-exec / fg / bg / bg-jobs。
    has &.job-dispatch;
    # 0.132.0 / §4.9j：stdin 钩子，(Str $prompt --> Str)。
    # TTY 模式 → 父进程直接 `prompt($prompt)`；
    # notebook 模式 → Notebook Frontend 转 Jupyter input_request。
    # 未注入时回退到原生 prompt（但引擎的 $*IN 是协议管道，所以**必须**注入，
    # 否则 prompt 直接读协议流里的下一条 JSON 帧 —— 0.131 及以前就是这样挂的）。
    has &.input-handler is rw;
    # 0.135.0 / ADR-0051 v2：失败格的错误详情（`error_info` 中间帧）。
    # 只有 notebook 前端读它；TTY 不看，所以结果类型 Result 不必背
    # `ename/evalue/traceback` 三个 Jupyter 专用字段。
    has %.last-error-info is rw;
    has $.proc is rw;
    has Channel $!ch;
    has Bool $.alive is rw = False;
    has Str  $.cwd is rw = '';
    has %.config is rw;
    has Int  $.plugins is rw = 0;
    # 0.133.0 / ADR-0051：握手协商到的协议版本（0 = 还没握手）。
    # 只做诊断/测试用；版本不符在 start() 里就已经抛 X::Rakuish::Protocol。
    has Int  $.protocol is rw = 0;
    has @.plugin-names is rw;
    has Int  $.index is rw = 0;
    has Int  $.restarts is rw = 0;
    has Str  $.startup-out is rw = '';
    has Str  $.startup-err is rw = '';
    has %.restored is rw;          # 0.84：重启时的恢复摘要（空 = 没恢复）
    has Int  $!seq = 0;
    has Int  $!generation = 0;     # 0.113.0：进程代际（判「这是不是当前那个」）
    has Bool $!in-request  = False;   # 正在等响应（只有这时才接管 SIGINT）
    has Bool $!interrupted = False;
    has Bool $.signal-armed is rw = False;
    # 0.99.0 / tail -f：父侧长操作（job 帧的 tail-follow）期间 Ctrl-C 的
    # 归属是「停止跟随」，不是「杀引擎」。$!job-interactive 期间信号置
    # $!job-stop，跟随循环轮询它退出；引擎完好无损（重启会丢会话现场）。
    has Bool $!job-interactive = False;
    has Bool $!job-stop        = False;
    # 0.101.4 / tty 直通：`! --tty` 期间 Ctrl-C 属于前台子进程，既不是
    # 「中断求值」也不是「停止跟随」。不单列这个状态的话，arm-signal 会
    # 落进 `in-request` 分支把引擎 SIGKILL —— 用户看到「引擎进程已退出 →
    # 重启」，而终端刚被直通交接改过状态，容易光标错位 / 输入无响应。
    has Bool $!tty-interactive = False;
    # 0.144.0 / V-348：`! --tty a | b` 的父侧执行期间。POSIX 下整组子进程与父
    # 同 pgid，Ctrl-C 由终端直接送给它们；Windows 下整组收在命令级 job 里，
    # arm-signal 只 terminate 这个 job。两种情形都**不动引擎**（重启会丢现场）。
    has Bool $!pipe-interactive = False;
    # 0.119.0 / V-314：当前这一格是不是 `!` 外部命令。
    # Windows 上 Ctrl-C 是 CTRL_C_EVENT，控制台把它广播给**同一控制台的所有
    # 进程** —— 子进程自己就会收到并退出。旧行为不分青红皂白先 SIGKILL 引擎，
    # 结果是「按一次 Ctrl-C，丢掉整场变量 + 等 4~5 秒重启」；重启窗口里敲的字
    # 被缓存，回来时光标/回显全错位（用户报的「卡死 + 字符错位」）。
    # 现在对外部命令先给 2 秒让子进程自己退，退了就当普通 `[exit=130]` 收尾，
    # 引擎不重启；只有子进程赖着不退才回到杀引擎的兜底。
    has Bool $!ext-command = False;
    # V-314：当前 `!` 命令的独立 job（父进程侧持有）。有它时 Ctrl-C 只收
    # 命令子树；没有才退回「杀引擎重启」。
    has $!child-job;
    # 这条命令是我们按 Ctrl-C 收掉的（终帧要报 130，不是 1）。
    has Bool $!child-killed = False;
    # 0.117.0 / V-309：引擎所在的 Windows Job。宿主持有句柄，
    # KILL_ON_JOB_CLOSE 保证「宿主没了，引擎子树跟着没」；
    # 重启 / Ctrl-C 时主动 TerminateJobObject，把前台命令和孙进程一起收掉
    # （Windows 上除此之外没有任何回收机制 —— ADR-0031 的 V-905）。
    has $!job;
    has Bool $!job-active = False;

    # 跟随循环的停止判据（bin 注入给 Sys.job-op 的 should-stop 闭包读它）。
    method job-stop(--> Bool) { $!job-stop }

    # 0.117.0 / V-309：Windows Job 句柄与开关（诊断 / 测试用）。
    # nil = 没启用（非 Windows，或建 job / 归类失败而降级）。
    method job(--> Any) { $!job-active ?? $!job !! Nil }
    method job-active(--> Bool) { $!job-active }

    method start(Bool :$restore = False --> Nil) {
        self!arm-signal;
        ++$!generation;
        my Int $gen = $!generation;
        my @cmd = ($!raku,);
        @cmd.push("-I{$!lib.absolute}") if $!lib.defined && $!lib.d;
        @cmd.push('-e', 'use Rakuish::Eval::Server; serve-engine()');

        # **不要**传 `:ENV`：本版 Rakudo 上它不生效（实测子进程仍拿父环境），
        # 而默认继承恰好是我们想要的 —— `RAKUISH_SNAPSHOT` / `RAKUISH_NO_SNAPSHOT`
        # 由父进程设好，子进程自动看到。恢复意图走协议（见下）。
        my $proc = Proc::Async.new(|@cmd, :w, :r, :e);
        # **必须**用局部 $ch / $proc 而不是 $!ch / $!proc：重启后旧进程的
        # done 回调还会触发一次，如果它闭包捕获的是属性，就会把**新**的
        # Channel 关掉 —— 表现是「重启后第一条请求就报 closed channel」。
        my $ch = Channel.new;
        $!proc = $proc;
        $!ch   = $ch;
        # 只 tap 一次：`stdout.lines` 每次调用都是新 Supply，重复 tap 会
        # 把同一行送进 Channel 两次，请求/响应就错位了。
        $proc.stdout.lines.tap(
            -> $l { try { $ch.send($l) } },
            done => { try { $ch.close } },
        );
        # 用户代码写 `$*ERR` 的内容落在这里；原样转发，不参与协议。
        $proc.stderr.lines.tap(-> $l { $*ERR.say($l) });

        my $done = $proc.start;
        $!alive = True;
        self!enter-job($proc);
        # 用 tap 而不是 `start { await }`：进程非零退出时 Promise 是 broken，
        # `start` 块里没被捕获的异常会变成 "Unhandled exception in code
        # scheduled on thread N"（0.83 开发中实测），tap 的 on-error 把它接住。
        # 旧进程退出不能把新进程标成 dead，所以要比对象身份。
        my &on-end = -> $p {
            # 旧进程退出不能把新进程标成 dead —— 判据是**代际**，不是对象。
            # 0.113.0 实测发现原来那行 `$!proc =:= $proc` 从 0.83 起就没生效：
            # `=:=` 是「容器同一性」，两个变量各装一份引用永远为 False，
            # 于是 `alive` 从来不会因为进程退出而翻假（崩溃全靠异常兜住）。
            # 看门狗要读 `alive` 判空闲期死亡，这行必须真的对。
            $!alive = False if $gen == $!generation;
            try { $ch.close };
            Nil
        };
        # `then` 的回调无论 Promise 成败都会跑；回调自己不抛，
        # 新 Promise 就是 kept —— 于是「进程非零退出」不会被报成未处理异常。
        $done.then(&on-end);

        my %ready = self!receive;   # 启动就崩的话这里抛 Dead
        if (%ready<event> // '') ne 'ready' {
            self!shutdown;
            X::Rakuish::Eval::Dead.new(
                detail => '引擎未返回 ready：' ~ to-json(%ready, :!pretty)).throw;
        }
        # 0.133.0 / ADR-0051：握手校验协议版本。旧引擎不带 protocol、
        # 版本不一致都给可操作的报错，而不是让后面的字段静默读成空值。
        Rakuish::Eval::Protocol::check-ready(%ready);
        $!protocol = Rakuish::Eval::Protocol::PROTOCOL-VERSION;
        $!cwd     = (%ready<cwd> // '').Str;
        %!config  = (%ready<config> // %{}).Hash;
        $!plugins = (%ready<plugins> // 0).Int;
        @!plugin-names = (%ready<plugin-names> // []).List;
        $!index   = (%ready<index> // 0).Int;
        $!startup-out = (%ready<out> // '').Str;
        $!startup-err = (%ready<err> // '').Str;

        # 恢复显式发起：只有崩溃重启的路径才要它。
        if $restore {
            my %r = self.request(%( cmd => 'restore' ));
            # 空快照时 Server 只回 path/index —— 不能把它当成「恢复了 0 项」，
            # 否则 Proxy 会显示一条没有意义的「已从快照恢复：0 条声明」。
            %!restored = ((%r<decls>:exists) || (%r<vars>:exists)) ?? %r !! %();
            $!index = (%r<index> // 0).Int;
        }
        Nil
    }

    # 重启：先杀旧进程，再起一个新的。会话状态**不恢复**（状态在旧进程里，
    # 那正是它死掉时丢失的东西）；调用方负责把这件事告诉用户。
    method restart(Bool :$restore = False --> Nil) {
        self!shutdown;
        ++$!restarts;
        self.start(:$restore);
    }

    # 0.85.0 / ADR-0023：求值期间的 Ctrl-C 由**这一层**接管。
    #
    # 为什么不是 worker 自己处理：实测 SIGINT 打不断 `loop { }`（MoarVM 不在
    # 纯 VM 循环里检查信号），所以只能由外部 kill 进程 —— 而「外部」就是这里。
    #
    # 为什么不是行编辑器处理：它只在 prompt 阶段有意义。求值期间它已经返回，
    # 却仍会记一个 take-interrupt 标志，导致**下一格**被误当成输入中断吞掉。
    #
    # 终端在求值期间是 cooked 模式（行编辑器 prompt 返回时恢复），
    # `` 由行规程转成 SIGINT 投给前台进程组 —— 父进程和 worker 都会收到。
    # worker 收到就直接死，但这里**不依赖**它：自己 kill 一次才确定。
    method !arm-signal(--> Nil) {
        return if $!signal-armed;
        my $sup = try { signal(SIGINT) };
        return unless $sup.defined;
        # 注意：回调跑在 scheduler 线程上，**不能写 `return`** ——
        # 它的词法 Routine 那时已经返回，会抛「Attempt to return outside of
        # immediately-enclosing Routine」。只用一个 if 分支。
        $sup.act: -> $sig {
            if $!job-interactive {
                # tail -f 之类的父侧长操作：Ctrl-C 只置停止标志（0.99.0）。
                $!job-stop = True;
            }
            elsif $!pipe-interactive {
                # 交互式管道（V-348）：Windows 上整组子进程收在命令级 job 里，
                # 按一次 Ctrl-C 只收这组（引擎不重启）；POSIX 上子进程与父同
                # pgid，终端自己会把 SIGINT 送给它们，这里什么也不做。
                if $!child-job.defined {
                    try { Rakuish::Sys::WinJob::terminate($!child-job) };
                    $!child-killed = True;
                    self!drop-child-job;
                }
            }
            elsif $!tty-interactive {
                # tty 直通：Ctrl-C 属于前台子进程（0.101.4）。宿主与引擎
                # 都不动 —— 引擎一死，重启 + 终端半坏就是用户看到的卡死。
            }
            elsif $!in-request && $!alive {
                if $!child-job.defined {
                    # V-314：这条命令有自己的 job。只 TerminateJobObject 收掉
                    # 命令 + 孙进程，引擎照常拿到 exec 结果（不重启、不丢状态）。
                    try { Rakuish::Sys::WinJob::terminate($!child-job) };
                    $!child-killed = True;
                    self!drop-child-job;
                    my Int $gen = $!seq;
                    start {
                        sleep 3;
                        if $!in-request && $!seq == $gen && $!alive {
                            $!interrupted = True;
                            self!kill-tree(:force);
                        }
                    };
                }
                elsif $!ext-command {
                    # 还没收到 child 帧（命令刚起 / 非 Windows）：先给子进程
                    # 2 秒自己收尾，超时才回到杀引擎的兜底。
                    my Int $gen = $!seq;
                    start {
                        sleep 2;
                        if $!in-request && $!seq == $gen && $!alive {
                            $!interrupted = True;
                            self!kill-tree(:force);
                        }
                    };
                }
                else {
                    $!interrupted = True;
                    self!kill-tree(:force);
                }
            }
            # 不在求值：什么也不做，把 Ctrl-C 让给行编辑器（输入中断）。
        };
        $!signal-armed = True;
        Nil
    }

    # 把刚起来的引擎放进 job。**越早越好**：它之后 spawn 的前台命令、
    # 命令再 spawn 的孙进程都会继承 job 归属，不需要逐个登记。
    # 失败一律降级（旧行为），不能因为 job 建不起来就起不了引擎。
    method !enter-job($proc --> Nil) {
        self!leave-job;
        return unless Rakuish::Sys::WinJob::supported();
        my $job = Rakuish::Sys::WinJob::create();
        return unless Rakuish::Sys::WinJob::valid($job);
        my Int $pid = 0;
        try { $pid = $proc.pid.result.Int }
        unless $pid > 0 {
            Rakuish::Sys::WinJob::close($job);
            return;
        }
        if Rakuish::Sys::WinJob::assign($job, $pid) {
            $!job = $job;
            $!job-active = True;
        } else {
            Rakuish::Sys::WinJob::close($job);
        }
        Nil;
    }

    method !leave-job(--> Nil) {
        if $!job-active {
            Rakuish::Sys::WinJob::close($!job);
            $!job-active = False;
            $!job = Nil;
        }
        Nil;
    }

    # 连子树一起杀：Windows 上没有别的办法回收引擎留下的孙进程。
    # 先 TerminateJobObject（一次带走整棵子树），再关句柄；POSIX / 降级
    # 路径仍然只 `$!proc.kill`。
    # `:force` 只影响**没有** job 时的进程 kill 力度：中断求值要 SIGKILL
    # （MoarVM 不在纯 VM 循环里查信号），正常 shutdown 保持原来的 SIGTERM，
    # 让引擎有机会跑完 LEAVE（关快照文件之类）。
    method !kill-tree(Bool :$force = False --> Nil) {
        if $!job-active {
            try { Rakuish::Sys::WinJob::terminate($!job) };
            self!leave-job;
        }
        try { $force ?? $!proc.kill(SIGKILL) !! $!proc.kill } if $!proc.defined;
        Nil;
    }

    # 0.119.0 / V-314：命令级 job。引擎在 spawn 后发 child 帧（pid），
    # 父进程 OpenProcess + AssignProcessToJobObject 把这条命令收进来；
    # Ctrl-C 时 TerminateJobObject 一次带走命令与孙进程，引擎自己不动。
    # 0.143.0 / V-347：一次收养**整组** pid —— 管道有 N 段，逐段收养会在
    # 收下一段时关掉上一段的 job，而 KILL_ON_JOB_CLOSE 下关句柄就是杀进程。
    method !adopt-children(@pids --> Bool) {
        return False unless @pids.elems && $*DISTRO.is-win;
        self!drop-child-job;
        return False unless Rakuish::Sys::WinJob::supported();
        my $job = Rakuish::Sys::WinJob::create();
        unless Rakuish::Sys::WinJob::valid($job) {
            Rakuish::Sys::WinJob::close($job);
            return False;
        }
        my Bool $ok = Rakuish::Sys::WinJob::assign-many($job, @pids);
        if $ok {
            $!child-job = $job;
        }
        else {
            Rakuish::Sys::WinJob::close($job);
        }
        $ok;
    }

    # 0.144.0 / V-348：父进程侧 pipe-exec hook 需要把子进程组交给**本对象**
    # 收养（CLI 的闭包拿不到私有方法）。非 Windows 上直接返回 False。
    method adopt-command(@pids --> Bool) { self!adopt-children(@pids) }

    method !drop-child-job(--> Nil) {
        if $!child-job.defined {
            try { Rakuish::Sys::WinJob::close($!child-job) };
            $!child-job = Nil;
        }
        Nil;
    }

    method !shutdown(--> Nil) {
        $!alive = False;
        if $!proc.defined {
            try { $!proc.close-stdin };
        }
        self!kill-tree;
        try { $!ch.close } if $!ch.defined;
        Nil
    }

    method !receive(--> Hash) {
        my $line;
        {
            CATCH {
                default {
                    $!alive = False;
                    # 中断先判：信号 kill 掉的 Channel 关闭与「引擎自己崩了」
                    # 在这里长得一模一样，只能靠 handler 留下的标志区分。
                    if $!interrupted {
                        $!interrupted = False;
                        X::Rakuish::Eval::Interrupted.new(
                            detail => '已中断当前求值').throw;
                    }
                    X::Rakuish::Eval::Dead.new(
                        detail => '连接已断开').throw;
                }
            }
            $line = $!ch.receive;
        }
        my $h = try { from-json($line) };
        ($h.defined && $h ~~ Hash) ?? $h !! %();
    }

    method !send(%frame --> Nil) {
        {
            CATCH {
                default {
                    $!alive = False;
                    X::Rakuish::Eval::Dead.new(
                        detail => '无法写入引擎（' ~ .message ~ '）').throw;
                }
            }
            await $!proc.write((to-json(%frame, :!pretty) ~ "\n").encode('utf-8'));
        }
        Nil
    }

    # 一个请求 → 一个终帧。中间的 `tty` 帧由父进程执行后回 resume。
    method request(%req --> Hash) {
        # 0.113.0：`alive` 现在会因为进程退出而真的翻假（空闲期崩溃由看门狗
        # 先发现），所以文案要覆盖两种情形：还没起过 / 起过但已经死了。
        X::Rakuish::Eval::Dead.new(detail => '引擎未启动或已退出').throw unless $!alive;
        ++$!seq;
        %req<seq> = $!seq;
        # 只对源码请求判 `!` 前缀；`! --tty` 走直通，信号归前台子进程，
        # 由 tty 帧自己置 $!tty-interactive，不在这里抢。
        # 帧字段是 `line`（eval）；`payload` 是 kernel 请求的名字，一并认。
        my Str $src = (%req<line> // %req<payload> // '').Str;
        $!ext-command = $src.trim.starts-with('!')
                        && $src.trim !~~ /^ '!' \s* '--tty' <?wb>/;
        $!interrupted = False;
        # 0.135.0：上一格的错误详情绝不能粘到下一格（成功格必须看到空）。
        %!last-error-info = %{};
        $!in-request  = True;
        LEAVE {
            $!in-request = False;
            $!ext-command = False;
            self!drop-child-job;
        }
        # 0.133.0 / ADR-0051：每个请求都带协议版本 —— 引擎据此判断
        # 「这个客户端是不是同一代」。握手已经在 start() 做过，这里是
        # 双向确认（引擎不会接受一个没带版本的请求）。
        %req<protocol> = Rakuish::Eval::Protocol::PROTOCOL-VERSION;
        self!send(%req);
        loop {
            my %h = self!receive;
            given (%h<event> // '') {
                when 'tty' {
                    self!answer-tty(%h);
                    next;
                }
                when 'pipe-exec' {
                    # 0.144.0 / V-348：`! --tty a | b` —— 引擎没有真终端 stdin。
                    self!answer-pipe(%h);
                    next;
                }
                when 'job' {
                    self!answer-job(%h);
                    next;
                }
                when 'input_request' {
                    # 0.132.0 / §4.9j：引擎要 stdin。父进程（TTY / notebook）拿值回它。
                    self!answer-input(%h);
                    next;
                }
                when 'child' {
                    # V-314：`!` 子进程 pid → 收进命令级 job（Windows 专用）。
                    # 0.143.0 / V-347：管道一次上报整组 `pids`；`pid` 是首段，
                    # 老引擎发来的帧只有它，也照收。
                    my @pids = %h<pids>.defined
                               ?? @(%h<pids>).map(*.Int)
                               !! ((%h<pid> // 0).Int,);
                    self!adopt-children(@pids.grep(* > 0).List);
                    next;
                }
                when 'chunk' {
                    # 0.90.0 / ADR-0024：引擎的 stdout 是协议管道，用户看到
                    # 的终端在这里。块到就写，别攒着 —— 攒就是 0.89 的卡死感。
                    if (%h<seq> // 0) == $!seq {
                        my Str $text = (%h<text> // '').Str;
                        my $handle = (%h<ch> // 'out').Str eq 'err'
                                     ?? $*ERR !! $*OUT;
                        try { $handle.print($text); $handle.flush };
                    }
                    next;
                }
                when 'error_info' {
                    # 0.135.0 / ADR-0051 v2：失败格的错误详情（独立中间帧）。
                    # 校验形状后存起来，Proxy 在请求结束后转给 notebook 前端。
                    %!last-error-info = Rakuish::Eval::Protocol::check-error-info(%h);
                    next;
                }
                when 'fatal' {
                    self!shutdown;
                    X::Rakuish::Eval::Dead.new(
                        detail => (%h<message> // '引擎致命错误').Str).throw;
                }
            }
            if (%h<seq> // 0) == $!seq {
                # V-314：命令是被我们按 Ctrl-C 收掉的 —— 报 130（128+SIGINT），
                # 别让用户看到一个来路不明的 exit=1。
                if $!child-killed {
                    $!child-killed = False;
                    %h<code> = 130;
                    %h<ok>   = False;
                }
                return Rakuish::Eval::Protocol::check-frame(%h);
            }
            # 理论上不会出现：协议是串行的。真出现了就丢掉旧帧，
            # 因为等一个永远不会来的 seq 只会把前端挂住。
        }
    }

    # `! --tty` 的父侧执行。父进程持有真终端，子进程的 stdio 是管道。
    method !answer-tty(Hash $h --> Nil) {
        # 0.101.4：直通期间 Ctrl-C 归前台子进程。不设这个状态，arm-signal
        # 会走 `in-request` 分支 SIGKILL 掉引擎（见属性注释）。
        $!tty-interactive = True;
        LEAVE { $!tty-interactive = False }
        my $hook = self.tty-exec;
        my $r;
        if $hook.defined {
            my $got = try { $hook(($h<exe> // '').Str, ($h<argv> // []).List) };
            $r = $got.defined && $got ~~ Rakuish::Result::Result
                ?? $got
                !! Rakuish::Result::Result.new(:!ok, :code(127), :op<tty-exec>,
                        :err('TTY 执行器返回了非 Result: ' ~ ($got // 'Any').raku));
        }
        else {
            $r = Rakuish::Result::Result.new(:!ok, :code(127), :op<tty-exec>,
                    :err('引擎请求 TTY 直通，但父进程没有注册执行器'));
        }
        self!send(%(
            seq => $!seq, cmd => 'resume',
            tty => %(
                ok   => ?$r.ok,
                code => $r.code,
                op   => $r.op,
                out  => $r.out,
                err  => $r.err,
            ),
        ));
        Nil
    }

    # 0.144.0 / V-348 / ADR-0057：`! --tty a | b` 的父侧执行。
    # 引擎只传 argv 段（不拼 shell 串）；父进程的真终端 stdin 交给第 0 段。
    method !answer-pipe(Hash $h --> Nil) {
        $!pipe-interactive = True;
        LEAVE { $!pipe-interactive = False }

        # 形状先校验：stages 必须是「非空段的列表」，每段首项是可执行文件。
        my @stages;
        my Bool $shape-ok = True;
        my $raw = ($h<stages> // []);
        unless $raw ~~ Positional && $raw.elems {
            $shape-ok = False;
        }
        if $shape-ok {
            for @($raw) -> $s {
                unless $s ~~ Positional && $s.elems && $s.List[0].defined {
                    $shape-ok = False;
                    last;
                }
                my @parts = $s.List;
                my Str $exe = @parts.shift.Str;
                @stages.push([$exe, |@parts.map(*.Str)]);
            }
        }

        my $hook = self.pipe-exec;
        my $r;
        if !$shape-ok {
            $r = Rakuish::Result::Result.new(:!ok, :code(127), :op<exec>,
                    :err('管道帧的 stages 形状不正确'));
        }
        elsif !$hook.defined {
            $r = Rakuish::Result::Result.new(:!ok, :code(127), :op<exec>,
                    :err('引擎请求交互式管道，但父进程没有注册执行器'));
        }
        else {
            # 0.145.0 / V-349：把 P1/P2 的开关交给父侧执行器。没有附加
            # 选项时仍按老签名调用（旧 hook 闭包没有 slurpy）。
            my %opts;
            %opts<no-capture> = True if ?($h<no-capture> // False);
            %opts<pipefail>   = True if ?($h<pipefail> // False);
            my Str $sf = ($h<stdin-file> // '').Str;
            %opts<stdin-file> = $sf if $sf.chars;
            %opts<timeout-ms> = ($h<timeout-ms>).Int if $h<timeout-ms>.defined;
            my $got = %opts.elems
                ?? (try { $hook(@stages.List, |%opts) })
                !! (try { $hook(@stages.List) });
            $r = $got.defined && $got ~~ Rakuish::Result::Result
                ?? $got
                !! Rakuish::Result::Result.new(:!ok, :code(127), :op<exec>,
                        :err('管道执行器返回了非 Result: ' ~ ($got // 'Any').raku));
        }

        # Ctrl-C 收掉的整组：报 130（128+SIGINT），并清掉标志，免得外层
        # 终帧处理再改一次（结果从这里开始就是最终结果）。
        if $!child-killed {
            $!child-killed = False;
            $r = Rakuish::Result::Result.new(
                :ok(False), :code(130), :op($r.op),
                :out($r.out), :err($r.err), :value($r.value),
                :elapsed($r.elapsed));
        }

        my %pl = %(
            ok   => ?$r.ok,
            code => $r.code,
            op   => $r.op,
            out  => $r.out,
            err  => $r.err,
        );
        # Mu 过不了 JSON：没有 value 的 Result 不写这个键。
        %pl<value> = $r.value if $r.value.defined;
        self!send(%( seq => $!seq, cmd => 'resume', pipe => %pl ));
        Nil
    }

    # 0.96.0 / ADR-0031：作业控制帧的父侧执行。与 !answer-tty 同形状，
    # 但多一种返回：bg-jobs 给的是 Table，不是 Result —— 用 rows+columns
    # 传回，引擎侧重建（Table 本身跨不过协议）。
    method !answer-job(Hash $h --> Nil) {
        my Str $op = ($h<op> // '').Str;
        my @args = ($h<args> // []).List;
        my $hook = self.job-dispatch;
        my %payload;

        # 0.99.0：tail-follow 是父侧长操作（跟随循环在这里跑）——期间
        # Ctrl-C 只应停止跟随（信号处理器置 $!job-stop），不能杀引擎。
        $!job-stop = False;
        $!job-interactive = $op eq 'tail-follow';
        LEAVE { $!job-interactive = False }

        if $hook.defined {
            my $got = try { $hook($op, @args) };
            if $got ~~ Rakuish::Result::Result {
                %payload = %( kind => 'result',
                    ok   => ?$got.ok, code => $got.code, op => $got.op,
                    out  => $got.out, err  => $got.err );
            }
            elsif $got ~~ Rakuish::Data::Table {
                %payload = %( kind => 'table',
                    columns => $got.columns.map(*.Str).List,
                    rows    => $got.rows.map({ .Hash }).List );
            }
            else {
                %payload = %( kind => 'result', :!ok, :code(127),
                    :op($op),
                    :err("作业执行器返回了无法序列化的值: " ~
                         (($got // Any).^name)) );
            }
        }
        else {
            %payload = %( kind => 'result', :!ok, :code(127), :op($op),
                :err('引擎请求作业控制，但父进程没有注册执行器') );
        }

        self!send(%( seq => $!seq, cmd => 'resume', job => %payload ));
        Nil
    }

    # 0.132.0 / §4.9j：引擎要 stdin，父侧拿值回。与 !answer-tty / !answer-job 同形。
    method !answer-input(Hash $h --> Nil) {
        my Str $prompt = ($h<prompt> // '').Str;
        my Str $value;
        my $hook = self.input-handler;
        if $hook.defined {
            $value = try { $hook($prompt) } // '';
        }
        else {
            # 兜底：没有 hook 就给空串 —— 比假装能读协议管道安全。
            $value = '';
        }
        self!send(%( seq => $!seq, event => 'input_reply',
                      input_reply => %( value => $value ) ));
        Nil
    }

    # ── 便捷方法（一一对应 Server 的 cmd）───────────────────────────
    method eval(Str $line, Bool :$color = False, Bool :$tty = False,
                Int :$width = 0, Int :$height = 0, Bool :$stream = False,
                Bool :$display = False,
                Hash :$config = %() --> Hash) {
        # `tty` / `width` / `height` 必须显式传：引擎的 `$*IN` `$*OUT` 是
        # 协议管道，自己探测只会得到 False / 0 —— 那会让 `clear` 静默、
        # shell 彩色全灭、多列 `ls` 按 80 列排（0.87 / 0.88 修复）。
        # `stream` 同理：引擎没有终端，但父进程有，「要不要边跑边出」
        # 也必须由前端下发（0.90 / ADR-0024）。
        # 0.109.0：`display` 让引擎顺带回一份 MIME 分档（text/markdown/json），
        # 只有 notebook 这类前端要；TTY 不传，字节数与 0.108 完全一致。
        self.request(%( cmd => 'eval', line => $line, color => ?$color,
                        tty => ?$tty, width => $width, height => $height,
                        stream => ?$stream, display => ?$display,
                        config => $config ));
    }

    # 0.90.0 / ADR-0025：可编程 prompt。每次取都问一次引擎，时间 / git 这类
    # 动态信息才是「当下」；计算成本由 rc 里的函数自己控制。
    method prompt-text(--> Str) {
        my %h = self.request(%( cmd => 'prompt' ));
        (%h<text> // '').Str;
    }

    # 启动文件：读与路径解析在父进程，执行在引擎（它才持有 %STATE / alias）。
    method run-rc(Str $path --> Hash) {
        self.request(%( cmd => 'rc', path => $path ));
    }

    method complete(Str $line, Int $pos --> List) {
        my %h = self.request(%( cmd => 'complete', line => $line, pos => $pos ));
        (%h<items> // []).List;
    }

    # 0.100.0 / ADR-0034：输入行错误态标记（V-280）。计算在引擎侧的
    # Session（它持有 Shell 命令表 / 注册表 / PATH 视角），前端只拿区间。
    # 0.109.0：文档内省（notebook 的 Shift+Tab）。返回 %(ok, text)。
    method inspect(Str $name --> Hash) {
        self.request(%( cmd => 'inspect', name => $name ));
    }

    method error-marks(Str $line --> List) {
        my %h = self.request(%( cmd => 'error-marks', line => $line ));
        (%h<items> // []).List;
    }

    method key(Str $key --> Hash) {
        self.request(%( cmd => 'key', key => $key ));
    }

    method info(--> Hash) {
        self.request(%( cmd => 'info' ));
    }

    # 0.132.0 / §4.9j：notebook 的 history_request 需要真实历史 ——
    # 历史只存在引擎的 Session 里，父进程的 Proxy 不能凭空知道。
    method history(--> List) {
        my %h = self.request(%( cmd => 'history' ));
        (%h<items> // []).List;
    }

    method shutdown(--> Nil) { self!shutdown }

    submethod DESTROY() { self!shutdown }
}
