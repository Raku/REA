unit module Rakuish::Store;

# Rakuish::Store —— 跨会话变量库（0.139.0 / V-343 / ADR-0053）。
#
# IPython 的 `%store` 把变量 pickle 进 `~/.ipython/profile_default/db/autorestore/`，
# 换一个会话 `%store -r x` 就能拿回来。Rakuish 的对应物是**值本身的可重建表示**
# （`.raku`）：会话快照（ADR-0022）已经证明这条路对 14/14 常见类型成立，
# 包括用户类实例（带着类定义）。
#
# 与快照的分工：
#   · 快照 = 整个 %!state，每格自动写，按 cwd 分文件，**不是**导出机制；
#   · 本模块 = 用户点名的那几个变量，手工 `store` / `store -r`，跨 cwd 共用一份。
#
# 判定复用 Rakuish::Snapshot::classify（闭包 / 资源 / 超限一律拒绝并给理由），
# 落盘复用 Rakuish::Snapshot::save（原子写 + POSIX 600）。本模块只多两件事：
# 路径约定与「文件里装的是哪些变量」这层信封。

use Rakuish::Snapshot;
use JSON::Fast;

# 信封版本：字段增删或语义变化才 +1。与快照版本无关 ——
# 两件事的兼容性不该绑在一起（快照改结构不该让 store 文件失效）。
our constant STORE-VERSION = 1;

# 默认路径 `$*HOME/.rakuish/store.json`，`RAKUISH_STORE` 可覆盖（测试也用它）。
# 故意**不按 cwd 分文件**：`%store` 的价值就是「换个目录还能拿回来」。
our sub store-path(--> IO::Path) {
    my Str $p = (%*ENV<RAKUISH_STORE> // '').Str;
    return $p.IO if $p.chars;
    my $home = try { $*HOME };
    return $home.add('.rakuish').add('store.json') if $home.defined;
    'rakuish-store.json'.IO;
}

our sub empty-store(--> Hash) {
    %( 'store-version' => STORE-VERSION, vars => %() );
}

# 读出信封。任何异常都返回空信封 —— store 是附加能力，
# 一个坏文件不该让 `store` 命令抛异常（用户要看到的是「库是空的」）。
our sub load(IO::Path $path --> Hash) {
    return empty-store() unless $path.e;
    my $text = try { $path.slurp(:enc<utf-8>) };
    return empty-store() unless $text.defined && $text ~~ Str && $text.chars;
    my $h = try { from-json($text) };
    return empty-store() unless $h.defined && $h ~~ Hash;
    # 只认本格式版本：以后改结构时旧文件当没有，而不是猜字段。
    return empty-store() unless ($h{'store-version'} // 0).Int == STORE-VERSION;
    my %vars = ($h<vars> // %{}).Hash;
    %( 'store-version' => STORE-VERSION,
       'saved-at' => ($h{'saved-at'} // '').Str,
       vars => %vars );
}

# 写回信封。失败返回 False（调用方决定怎么报）。
# `saved-at` 由这里统一刷新，免得每个调用点各写一遍。
our sub save(%data, IO::Path $path --> Bool) {
    my %out =
        'store-version' => STORE-VERSION,
        'saved-at'      => DateTime.now.Str,
        vars            => (%data<vars> // %{}).Hash,
        ;
    Rakuish::Snapshot::save(%out, $path);
}

# 单个变量的条目。`%c` 是 classify 的结果（kind/raku/type/reason）；
# `@decls` 是「重放这个值需要哪些声明」（key/src/name/is-type 的形状与快照一致）。
# 只有 kind = value 能进库 —— nil 存成 `Any` 也走 value。
our sub entry(%c, Str $cwd, @decls --> Hash) {
    %(
        raku      => (%c<raku> // 'Any').Str,
        type      => (%c<type> // 'Any').Str,
        'saved-at' => DateTime.now.Str,
        cwd       => $cwd,
        decls     => @decls.map({
            %( key      => (.<key> // '').Str,
               src      => (.<src> // '').Str,
               name     => (.<name> // '').Str,
               'is-type' => ?(.<is-type> // False) )
        }).List,
    );
}
