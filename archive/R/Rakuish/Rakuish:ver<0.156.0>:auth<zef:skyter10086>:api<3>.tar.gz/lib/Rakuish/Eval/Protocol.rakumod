unit module Rakuish::Eval::Protocol;

# 引擎协议（父进程 <-> 求值子进程）的**唯一契约**。见 ADR-0051 / SPEC V-335。
#
# 为什么需要它：两端通常来自同一份安装，但「升级过程中」完全可能出现
# 「新前端 + 旧引擎进程」（REPL 不重启引擎就一直用旧的），以及第三方前端。
# 以前协议没有版本、没有 schema：
#   · 改一个字段名（text → rendered），Client 用 `// 默认值` 兜底，前端拿到
#     空字符串/0，不抛异常、不报错 —— 静默坏掉；
#   · ready 帧没有版本，谁也没法判断对面是什么；
#   · 帧形状散在 Server 的 Hash 字面量和 Client 的 `given (%h<event>)` 里，
#     加字段时两边各改各的。
# 现在：ready 帧带版本、每个请求带版本、每个终帧按表校验必填字段，
# 不合契约抛 X::Rakuish::Protocol（带原始帧，便于定位）。
#
# 版本独立于 META6 的 `api<3>`：api 是模块 API，协议是进程间线格式，各自
# 演进。协议从 1 开始（0.83 起的既有线格式，0.133.0 首次把它写成契约）。
# v2（0.135.0）：错误详情从 result 终帧移到独立中间帧 `error_info`。结构化
# 错误是 notebook 前端的形状，不该下沉到结果类型 `Rakuish::Result`；TTY
# 也不必为这三个字段付构造与传输代价。

use Rakuish::Result;
use JSON::Fast;

our constant PROTOCOL-VERSION = 2;

sub fail-frame(Str $what, %h) {
    my Str $raw = try { to-json(%h, :!pretty) } // '(无法序列化)';
    X::Rakuish::Protocol.new(
        :detail("{$what}；协议 v{PROTOCOL-VERSION}（原始帧: {$raw}）")
    ).throw;
}

# `$names` 收 List/Array 都行：Raku 里 `@x = $list` 只得到「一个元素（那个
# List）」，所以这里统一 `.List` 摊平，调用方不必记 `|` 的规则。
sub require-fields(%h, $names, Str $what) {
    my @names = $names.List;
    my @missing = @names.grep({ !(%h{$_}:exists) });
    fail-frame("{$what} 缺少字段: {@missing.join(', ')}", %h) if @missing.elems;
}

# 一次 eval 的终帧。**字段即契约**：Server 用它构造，Client 用它解构；
# 字段名改动只能改这里 + 版本号。
our class EvalReply {
    has Int  $.seq = 0;
    has Str  $.op = 'eval';
    has Bool $.ok = False;
    has Int  $.code = 0;
    # `text` = 给终端直接打印的渲染文本（含 Out[n]/颜色）；`out`/`err` = 捕获的
    # stdout/stderr。两者不是一回事，0.109.0 起分开传。
    has Str  $.text = '';
    has Str  $.out = '';
    has Str  $.err = '';
    has Int  $.index = 0;
    has Str  $.cwd = '';
    has %.config;
    has Str  $.elapsed = '';
    has Bool $.exit = False;
    has Int  $.exit-code = 0;
    has Str  $.hint = '';
    has Bool $.no-newline = False;
    # 0.90.0 / ADR-0024：输出已经由 chunk 帧实时送走，前端不要再打印 `text`。
    has Bool $.streamed = False;
    # 0.109.0 / ADR-0048：内容级展示（MIME 分档）与一格里的 display() 调用。
    has %.display;
    # 这两个是 List 而**不是** `@.` 数组属性：`has @.x` 收到一个 List 命名参数时
    # 会当成「一个元素」（`X.new(x => (1,2))` ⇒ `@!x == ((1,2),)`），而 Server /
    # from-hash 都用 `|%fields` 摊平传 —— 结果是 displays 变成 `[(...)]`，
    # notebook 一条 display 都拿不到（0.133.0 首跑就是这么红的）。标量属性没有
    # 这个问题，赋值就是赋值。TWEAK 也不行：命名参数是在 TWEAK 之后才赋的。
    has $.displays  = ();
    # 为了方便调用方，`displays` 也提供 `@` 形态的读取方法。
    method display-list(--> List) { $!displays.List }

    method to-hash(--> Hash) {
        my %h =
            seq          => $!seq,
            event        => 'result',
            ok           => ?$!ok,
            op           => $!op,
            code         => $!code,
            text         => $!text,
            out          => $!out,
            err          => $!err,
            index        => $!index,
            cwd          => $!cwd,
            config       => %!config,
            elapsed      => $!elapsed,
            exit         => ?$!exit,
            'exit-code'  => $!exit-code,
            hint         => $!hint,
            'no-newline' => ?$!no-newline,
            streamed     => ?$!streamed,
        ;
        if %!display.elems || $!displays.List.elems {
            %h<display> = %!display;
            # 0.124.0：一格里的 `display()` 按序发 display_data；空列表不占键。
            %h<display><displays> = $!displays.List if $!displays.List.elems;
        }
        %h;
    }

    method from-hash(EvalReply:U: %h --> EvalReply) {
        require-fields(%h, <seq ok code text out err index cwd exit exit-code>,
                       'result 帧');
        my %display  = (%h<display> // %{}).Hash;
        my @displays = (%display<displays> // []).List;
        # 带连字符的字段名用 Hash 摊平传（`exit-code` 不能写成 `:exit-code`）。
        my %args =
            seq          => (%h<seq> // 0).Int,
            op           => (%h<op> // 'eval').Str,
            ok           => ?(%h<ok> // False),
            code         => (%h<code> // 0).Int,
            text         => (%h<text> // '').Str,
            out          => (%h<out> // '').Str,
            err          => (%h<err> // '').Str,
            index        => (%h<index> // 0).Int,
            cwd          => (%h<cwd> // '').Str,
            config       => (%h<config> // %{}).Hash,
            elapsed      => (%h<elapsed> // '').Str,
            exit         => ?(%h<exit> // False),
            'exit-code'  => (%h<exit-code> // 0).Int,
            hint         => (%h<hint> // '').Str,
            'no-newline' => ?(%h<no-newline> // False),
            streamed     => ?(%h<streamed> // False),
            display      => %display,
            displays     => @displays.List,
        ;
        EvalReply.new(|%args);
    }
}

# 终帧的必填字段表。`result` 也列在这里（先粗校验，再走 EvalReply 细校验）。
# `error` 不在这里：它是引擎自己报的协议/序列化错误，Client 会转成失败结果。
my constant FRAME-FIELDS = %(
    result      => <seq ok code text out err index cwd exit exit-code>,
    completions => <items>,
    marks       => <items>,
    key         => <ok op index>,
    inspect     => <ok text>,
    info        => <cwd index config>,
    history     => <items>,
    prompt      => <text>,
    rc          => <ok out err failed lines prompt config cwd index>,
    restored    => <path index>,
);

# ready 握手：引擎必须自报协议版本，且与前端一致。
# 旧引擎（0.132.x 及以前）的 ready 没有 protocol —— 升级时留下的进程会命中
# 这条，给的是可操作的提示，而不是「字段读到 Any」。
# 调用方（Client）已经确认过 `event eq 'ready'`，这里只管版本。
our sub check-ready(%h --> Hash) {
    unless %h<protocol>:exists {
        X::Rakuish::Protocol.new(
            :detail("引擎 ready 帧没有 protocol 字段：多半是升级过程中残留的旧引擎"
                    ~ "进程。退出 REPL 重开（或重启引擎）即可；当前协议 v"
                    ~ "{PROTOCOL-VERSION}")
        ).throw;
    }
    my Int $got = (%h<protocol> // 0).Int;
    unless $got == PROTOCOL-VERSION {
        X::Rakuish::Protocol.new(
            :detail("引擎协议版本不符：引擎 v{$got} / 前端 v{PROTOCOL-VERSION}。"
                    ~ "前后端来自同一份安装时，重启引擎即可；否则请升级另一端。")
        ).throw;
    }
    %h;
}

# 终帧校验。成功返回**规范化后**的 Hash（Proxy 只读字段，不关心顺序）：
#   · `error` 帧 → 折成一条失败 result（以前会被当普通终帧，Proxy 读不到
#     ok/err，前端显示一个空结果 —— 静默坏掉）；
#   · 未登记的 event → 抛（多半是前后端版本不一致）；
#   · 缺必填字段 → 抛。
our sub check-frame(%h --> Hash) {
    my Str $event = (%h<event> // '').Str;
    fail-frame('终帧缺少 event 字段', %h) unless $event.chars;

    if $event eq 'error' {
        # 只折出「必要字段」：会话态字段（index/cwd/config/exit…）**故意不给**，
        # 让 Proxy 的 `//` 默认值保留原会话值 —— 否则一条协议错误会把格号
        # 打回 0，`Out[n]` 跟着乱。
        return %(
            seq   => (%h<seq> // 0).Int,
            event => 'result',
            ok    => False,
            op    => 'eval',
            code  => 1,
            text  => '',
            out   => '',
            err   => (%h<message> // '引擎协议错误').Str,
        );
    }

    # 注意摊平：`@x = $list` 只得到「一个元素（那个 List）」。
    my @need = |(FRAME-FIELDS{$event} // ());
    fail-frame("未知终帧类型 '{$event}'（前后端协议版本可能不一致）", %h)
        unless @need.elems;
    require-fields(%h, @need, "{$event} 帧");
    return EvalReply.from-hash(%h).to-hash if $event eq 'result';
    %h;
}

# ── 中间帧 `error_info`（v2）────────────────────────────────────────────
# 失败格的错误详情。它**不是终帧**：Client 在 request 循环里直接消费
# （存进 `last-error-info`），不会走到 check-frame。但形状仍是契约 ——
# Server 按这里构造，Client 按这里校验。
#
# 为什么独立成帧而不是留在 result：`ename/evalue/traceback` 是 Jupyter
# error reply 的形状，TTY 不用。放在 Result 上会让「一个结果类型」长出
# 两个前端各自的语义（0.132 的 P2.5 就是这么做的），净化后 Result 只管
# ok/code/out/err/value。
our constant ERROR-INFO-FIELDS = <seq ename evalue traceback>;

our sub check-error-info(%h --> Hash) {
    require-fields(%h, ERROR-INFO-FIELDS, 'error_info 帧');
    %h;
}
