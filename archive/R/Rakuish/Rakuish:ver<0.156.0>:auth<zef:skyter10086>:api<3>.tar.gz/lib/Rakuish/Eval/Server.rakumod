unit module Rakuish::Eval::Server;

# Rakuish::Eval::Server —— 引擎子进程的协议服务端（0.83.0 / ADR-0021）。
#
# 为什么要有这个进程：Rakudo 上 `EVAL` 跑在宿主进程里，用户代码可以
#   · `exit` —— 直接结束整个 REPL；
#   · 段错误（NativeCall 乱指针、深度递归）—— 进程带走；
#   · `while 1 { }` —— SIGINT 打不断（实测：MoarVM 不在纯表达式循环里
#     检查中断），宿主只能被外部杀掉。
# 三条都要求**引擎与前端不在同一个进程**：同进程多实例的 C ABI 方案试过
# （0.80 探针），缺 `:pty`、并发求值不稳定，所以走进程级隔离。
#
# 这不是 V-906 否掉的「持久求值器」：V-906 的适用域是**多客户端服务**，
# 常驻编译单元会让跨请求状态泄漏；这里是单用户会话，跨格状态正是产品特性。
#
# 协议：stdin / stdout 各一行一个 JSON 对象（父进程见 Rakuish::Eval::Client）。
#   → {"seq":1,"cmd":"eval","line":"1+1","color":false,"config":{...}}
#   ← {"seq":1,"event":"result","ok":true,...,"text":"Out[1] = 1",...}
# 用户代码的 stdout 由 Session 的 CapturingOut 捕获后放进 `out` 字段，
# **不会**混进协议流；用户代码写 `$*ERR` 的内容落在本进程 stderr，
# 由父进程原样转发（不参与协议）。

use Rakuish::REPL::Session;
use Rakuish::Snapshot;
use Rakuish::Result;
use Rakuish::Display;       # 0.109.0：notebook 要的 MIME 分档
use Rakuish::Data::Table;
use Rakuish::Eval::Protocol;   # 0.133.0 / ADR-0051：协议契约（版本 + 帧）
use JSON::Fast;

# 0.136.1 / V-340：协议流的**绝对句柄**。
#
# emit / read-msg 以前用动态的 `$*OUT` / `$*IN`，而 Session 在 `!eval-raku` 里
# 对每一格 `temp $*OUT = $cap`（捕获缓冲）、在 prompt 所在的 do{} 块里
# `temp $*IN = _RakuishIn`。于是从**格内部**发出的帧会写进该格的捕获缓冲
# （前端永远收不到 input_request），而 read-msg 再从 `_RakuishIn` 读一行 →
# `_RakuishIn.get` → input-handler → read-msg → … 无限递归，会话直接卡死
# （实测：`my $n = prompt "name? "` 让引擎 45 秒内刷满 handler 调用后栈爆）。
# 协议流必须与用户代码的 `$*IN` / `$*OUT` 无关，所以在这里抓住真实句柄，
# serve-engine() 启动时再重新抓一次（那一刻还没被任何人 temp）。
my $PROTO-IN  = $*IN;
my $PROTO-OUT = $*OUT;

# 只有这一处写协议流。任何 `say` 都会污染 stdout，所以统一走 emit。
#
# 0.123.0 / V-324：这里是**引擎进程的最后一道护栏**。任何一格的可序列化
# 失败都不能穿出去 —— 穿出去就等于 serve-engine 抛异常、进程退出、用户丢会话。
# 正常路径不该走到 fallback；走到也宁可回一个错误帧，不能静默死掉。
sub emit(%h --> Nil) is export {
    my $line = try { to-json(%h, :!pretty) };
    unless $line.defined {
        $line = to-json(%(
            seq     => (%h<seq> // 0),
            event   => 'error',
            message => '响应无法序列化：值里有非 JSON 类型',
        ), :!pretty);
    }
    $PROTO-OUT.print($line ~ "\n");
    $PROTO-OUT.flush;
    Nil
}

# 读一行请求；EOF 或坏 JSON 返回空 Hash（调用方按「父进程没了」处理）。
my sub read-msg(--> Hash) {
    my $line = $PROTO-IN.get;
    return %() unless $line.defined;
    return %() unless $line.trim.chars;
    my $h = try { from-json($line) };
    ($h.defined && $h ~~ Hash) ?? $h !! %()
}

# 把 Session 的接口摊平成一个响应。
# `:$with-display` 是 0.109.0 加的：Jupyter 之类的前端要 MIME 分档（text /
# markdown / json），而 TTY 只要 `text`。默认不算是为了不让普通格多付一次
# markdown/json 的计算与传输 —— 同一格在 TTY 下的字节数与 0.108 完全一致。
my sub result-frame($session, $r, Str $line, Str $text, Duration $dt,
                    Bool :$with-display = False, :@displays --> Hash) {
    # 0.133.0 / ADR-0051：形状由 Rakuish::Eval::Protocol::EvalReply 定义，
    # 这里只负责填值 —— 字段名/默认值只有一份，Client 用同一个类解构。
    my %display;
    if $with-display {
        # 内容级展示（零 ANSI、无 `Out[n]` 标签）：与 `text` 是两种东西，
        # 前者给「另一个前端怎么渲染」，后者给「终端直接打印什么」。
        # 0.110.0：`:mime` 让响应带齐 text/plain · text/markdown · text/html ·
        # application/json 四档 —— Jupyter 的 execute_result 正是这个形状。
        #
        # 0.123.0 / V-324：display 是展示层，算不出来也不能让引擎死。
        my $display = try { Rakuish::Display::bundle-from($r).to-hash(:mime) };
        %display = $display.defined
            ?? $display
            !! %(
                ok      => ?$r.ok,
                code    => $r.code,
                format  => 'text',
                formats => ['text'],
                content => ($r.err.chars ?? $r.err !! ''),
                meta    => %( kind => 'error', source => 'error' ),
            );
    }
    # 带连字符的字段名用 Hash 摊平传（`exit-code` 这类不能写成 `:exit-code`）。
    my %fields =
        seq          => $*SEQ,
        ok           => ?$r.ok,
        op           => $r.op,
        code         => $r.code,
        text         => $text,
        out          => $r.out,
        err          => $r.err,
        index        => $session.index,
        cwd          => $session.sys.cwd.Str,
        config       => $session.config,
        elapsed      => $dt.Str,
        exit         => ?$session.exit-requested,
        'exit-code'  => $session.exit-code,
        hint         => $session.next-hint($line, $r),
        'no-newline' => ?$r.no-newline,
        # 0.90.0 / ADR-0024：输出已经通过 chunk 帧实时送走，父进程不要再打印 text。
        streamed     => ?$r.streamed,
        display      => %display,
        displays     => @displays.List,
    ;
    Rakuish::Eval::Protocol::EvalReply.new(|%fields).to-hash;
}

sub serve-engine(--> Nil) is export {
    # 当前请求的 seq：TTY 往返的闭包要比主循环更晚取值，所以用动态变量。
    # **必须**声明在本 sub 内 —— 模块顶层的 `my $*SEQ` 不在调用链上，
    # 子进程里访问会抛「Dynamic variable $*SEQ not found」。
    my $*SEQ = 0;

    # 0.136.1 / V-340：在任何人 temp 动态变量之前抓住协议流。
    # 这一句必须在下面所有 emit 之前 —— 首个 `ready` 帧就走它。
    $PROTO-IN  = $*IN;
    $PROTO-OUT = $*OUT;

    my $session = Rakuish::REPL::Session.new(:color(False));

    # 0.84.0 / ADR-0022：恢复由父进程显式发起（`restore` 命令），
    # 不在启动时自动做 —— 「什么时候恢复」是会话策略，不是引擎的事。
    # 也不能靠启动参数：`Proc::Async` 的 `:ENV` 在本版 Rakudo 上不生效
    # （实测子进程仍是父环境），所以走协议而不是进程环境。
    my %restored;

    # TTY 直通必须由父进程执行：本进程的 stdin/stdout 是协议管道，不是终端。
    # 闭包发一个 tty 事件，然后**同步**等父进程回 resume（同一时刻只可能
    # 有一个请求在飞，所以这里读到的一定是对应的 resume）。
    $session.tty-handler = -> Str $exe, @argv {
        emit %( seq => $*SEQ, event => 'tty', exe => $exe, argv => @argv.List );
        # 0.101.4：等父侧结果期间吞掉 Ctrl-C（纵深防御）。tty-exec 的前台
        # 子进程与引擎共享同一个控制台（Windows 的 CTRL_C_EVENT 发给整个
        # 控制台，没有 POSIX 的前台进程组隔离），引擎收到 SIGINT 且没有
        # handler 时默认处置就是**直接退出**。0.101.4 已在父进程侧把
        # tty 直通期间的 Ctrl-C 从「SIGKILL 引擎」改成「归前台子进程」，
        # 这里再兜一层，免得引擎自己被信号带走。与下面 job-dispatch 的
        # 同款 tap 一个道理（0.99.0 在 tail-follow 上修过一次）。
        my $tap = try { signal(SIGINT).tap(-> $ {}) };
        my %res = read-msg();
        try { $tap.close if $tap.defined };
        my %t = (%res<tty> // %());
        Rakuish::Result::Result.new(
            :ok(?(%t<ok> // False)),
            :code((%t<code> // 127).Int),
            :op((%t<op> // 'tty-exec').Str),
            :out((%t<out> // '').Str),
            :err((%t<err> // '无 TTY 结果：父进程未回传').Str),
        );
    };

    # 0.144.0 / V-348 / ADR-0057：交互式管道（`! --tty a | b`）。与 tty-handler
    # 同形 —— 引擎的 stdin 是协议管道，只有父进程能把真终端交给第 0 段。
    # 发 pipe-exec 中间帧（stages = [[exe, argv...], …]），同步等父进程回
    # resume 的嵌套 `pipe` Hash，再重建 Result。等待期间同样吞掉 Ctrl-C：
    # 前台子进程与引擎共享控制台，引擎被信号带走会让整个会话丢状态。
    $session.pipe-handler = -> @stages, *%opts {
        my %frame = %( seq => $*SEQ, event => 'pipe-exec',
                stages => @stages.map(
                    -> $s { [$s.List[0].Str, |$s.List[1 .. *].map(*.Str)] }).List );
        # 0.145.0 / V-349：P1/P2 的开关原样带给父进程 —— 真正执行管道的是它。
        %frame<no-capture> = True if %opts<no-capture>;
        %frame<pipefail>   = True if %opts<pipefail>;
        %frame<stdin-file> = %opts<stdin-file>.Str if %opts<stdin-file>.defined;
        %frame<timeout-ms> = %opts<timeout-ms>.Int if %opts<timeout-ms>.defined;
        emit %frame;
        my $tap = try { signal(SIGINT).tap(-> $ {}) };
        my %res = read-msg();
        try { $tap.close if $tap.defined };
        my %p = (%res<pipe> // %());
        Rakuish::Result::Result.new(
            :ok(?(%p<ok> // False)),
            :code((%p<code> // 127).Int),
            :op((%p<op> // 'exec').Str),
            :out((%p<out> // '').Str),
            :err((%p<err> // '父进程未回传管道结果').Str),
            :value(%p<value>),
        );
    };

    # 0.96.0 / ADR-0031：作业控制帧。与 tty-handler 同理 —— 引擎的 stdout
    # 是协议管道、也没有真终端，bg-exec/fg/bg 必须由父进程执行。DSL 的四个
    # 函数走 Sys.job-op → job-dispatch → 这里 → 父进程 → resume 帧。
    # 0.99.0：等待父侧结果期间吞掉终端 Ctrl-C —— tail-follow 之类的父侧
    # 长操作里，SIGINT 属于跟随循环（父进程置停止标志），worker 必须活着
    # 接结果；否则 SIGINT 的默认处置会把 worker 直接打死（t/54 时代实测）。
    $session.sys.job-dispatch = -> Str $op, *@args {
        emit %( seq => $*SEQ, event => 'job', op => $op, args => @args.List );
        my $tap = try { signal(SIGINT).tap(-> $ {}) };
        my %res = read-msg();
        try { $tap.close if $tap.defined };
        my %p = (%res<job> // %());
        if (%p<kind> // '') eq 'table' {
            Rakuish::Data::Table.new(
                :columns((%p<columns> // []).List),
                :rows((%p<rows> // []).List));
        }
        else {
            Rakuish::Result::Result.new(
                :ok(?(%p<ok> // False)),
                :code((%p<code> // 127).Int),
                :op((%p<op> // $op).Str),
                :out((%p<out> // '').Str),
                :err((%p<err> // '').Str));
        }
    };

    # 0.132.0 / §4.9j：stdin 处理（notebook prompt 不挂死内核）。
    # 与 tty-handler / job-dispatch 同形：引擎的 stdin 是协议管道、读不到用户键盘。
    # 把请求发出去，然后 read-msg 等父进程回 input_reply。
    # 0.136.1 / V-340：这里的 emit 与 read-msg **必须**走 $PROTO-OUT/$PROTO-IN。
    # 调用链是 `prompt` → `_RakuishIn.get` → 本 handler，而此刻格内 `$*IN` 就是
    # `_RakuishIn`、`$*OUT` 就是该格的捕获缓冲：走动态变量会 ① 把 input_request
    # 写进缓冲（前端收不到）② read-msg 又读回 `_RakuishIn` → 递归到栈溢出。
    $session.input-handler = -> Str $prompt-text = '' {
        emit %( seq => $*SEQ, event => 'input_request', prompt => $prompt-text );
        my $tap = try { signal(SIGINT).tap(-> $ {}) };
        my %res = read-msg();
        try { $tap.close if $tap.defined };
        (%res<input_reply><value> // '').Str;
    };
    # 0.90.0 / ADR-0024：`!` 的流式输出。本进程的 stdout 是协议管道，
    # 所以块不能直接打印 —— 写成 chunk 帧，由持有终端的父进程实时写出。
    $session.chunk-handler = -> Str $ch, Str $text {
        emit %( seq => $*SEQ, event => 'chunk', ch => $ch, text => $text );
    };

    # 0.119.0 / V-314：把 `!` 子进程的 pid 交给前端。Windows 上没有前台
    # 进程组，控制台的 CTRL_C_EVENT 到不了命令；前端拿到 pid 后把这条命令
    # 单独放进 job，按 Ctrl-C 只收命令子树 —— 引擎不重启，会话状态不丢。
    # 0.143.0 / V-347：改成整组上报。管道是 N 个进程，逐段发帧会让前端
    # 在收养下一段时关掉上一段的 job（= 杀死）。`pid` 保留首段，老读者不炸。
    if $*DISTRO.is-win && $session.sys.proc.defined {
        $session.sys.proc.set-child-cb(-> @pids {
            emit %( seq => $*SEQ, event => 'child',
                    pid => (@pids[0] // 0), pids => @pids.List );
        });
    }

    # 启动 hook 属于会话初始化，跑在引擎里（它可能要 `use` / 定义变量）。
    # 输出攒起来随 ready 帧回传，父进程负责打印。
    my @hook-out;
    my @hook-err;
    for $session.run-hooks('start') -> $r {
        @hook-out.push($r.out) if $r.out.chars;
        @hook-err.push($r.err) if $r.err.chars;
        unless $r.ok {
            emit %( event => 'fatal',
                    message => '启动 hook 失败: ' ~ ($r.err // '').Str );
            return;
        }
    }

    emit %(
        event   => 'ready',
        # 0.133.0 / ADR-0051：协议版本必须是 ready 的第一手信息 —— 前端据此
        # 判断「对面是不是同一代」。升级后残留的旧引擎进程会在这里被拦下。
        protocol => Rakuish::Eval::Protocol::PROTOCOL-VERSION,
        pid     => $*PID,
        cwd     => $session.sys.cwd.Str,
        config  => $session.config,
        plugins => $session.plugins.names.elems,
        plugin-names => $session.plugins.names.List,
        index   => $session.index,
        out     => @hook-out.join,
        err     => @hook-err.join,
        %( restored => %restored ),
    );

    loop {
        my %msg = read-msg();
        last unless %msg.elems;          # EOF：父进程退出
        $*SEQ = (%msg<seq> // 0).Int;
        my Str $cmd = (%msg<cmd> // '').Str;

        # 0.133.0 / ADR-0051：请求必须自报协议版本（Client 每条都带）。
        # 没带 = 旧客户端；不一致 = 升级中途。两种都明确报错，不猜。
        unless (%msg<protocol> // 0).Int == Rakuish::Eval::Protocol::PROTOCOL-VERSION {
            emit %(
                seq   => $*SEQ,
                event => 'fatal',
                message => "引擎协议版本不符：本引擎 v"
                    ~ Rakuish::Eval::Protocol::PROTOCOL-VERSION
                    ~ " / 请求 v{(%msg<protocol> // '缺失')}。"
                    ~ "前后端来自同一份安装时，退出 REPL 重开即可。",
            );
            last;
        }

        given $cmd {
            when 'eval' {
                # config 由父进程当格推下来（父进程是 config 的唯一权威：
                # banner / prompt / 高亮开关都在它那边读）。
                $session.config = %msg<config>.Hash if %msg<config>.defined;
                $session.set-color(?(%msg<color> // False));
                # 0.87.0：真实终端是不是 TTY 由父进程告知。**不能**让引擎
                # 自己看 `$*OUT.t` —— 它的 stdout 是协议管道，恒 False。
                $session.set-tty(?(%msg<tty> // $session.tty))
                    if %msg<tty>:exists;
                $session.set-size(:width((%msg<width>  // 0).Int),
                                  :height((%msg<height> // 0).Int));
                # 0.90.0：要不要边跑边出由父进程决定（只有它知道 stdout 是不是终端）。
                $session.set-stream-out(?(%msg<stream> // False))
                    if %msg<stream>:exists;
                # 0.124.0 / ADR-0048 P1：notebook 要 display() 的富输出；
                # TTY / 管道保持 False（display() 直接写 stdout）。
                $session.set-display(?(%msg<display> // False));
                my Str $line = (%msg<line> // '').Str;
                my Instant $t0 = now;
                my $r = $session.eval-line($line);
                my Duration $dt = now - $t0;
                # 0.135.0 / ADR-0051 v2：失败格的错误详情走独立中间帧，
                # 放在 result 终帧**之前** —— 父进程先存下，再返回终帧。
                # 形状由 Protocol::ERROR-INFO-FIELDS 定义；TTY 前端不读它。
                unless $r.ok {
                    my $ex = try { $session.last-error };
                    if $ex.defined {
                        my Str $ev = (try { $session.last-error-text } // '').Str;
                        emit %(
                            seq       => $*SEQ,
                            event     => 'error_info',
                            ename     => $ex.^name,
                            evalue    => ($ev.chars ?? $ev !! $ex.^name),
                            traceback => ((try { $session.collect-traceback }) // ()).List,
                        );
                    }
                }
                $session.note-timing($dt, $line, $r.ok);
                my Str $text = $session.render($r);
                # 会话日志要在能同时看到「输入 + Result + 渲染文本」的地方写。
                $session.log-line($line, $r, $text);
                # 收集的 display() 必须取走（成功 / 失败 / 超时都一样）。
                my @displays = $session.take-displays;
                emit result-frame($session, $r, $line, $text, $dt,
                                  :@displays,
                                  :with-display(?(%msg<display> // False)));
            }
            when 'complete' {
                my Str $line = (%msg<line> // '').Str;
                my Int $pos  = (%msg<pos> // $line.chars).Int;
                emit %( seq => $*SEQ, event => 'completions',
                        items => $session.completions($line, $pos).List );
            }
            when 'error-marks' {
                my Str $line = (%msg<line> // '').Str;
                emit %( seq => $*SEQ, event => 'marks',
                        items => $session.error-marks($line).List );
            }
            when 'key' {
                my $r = $session.handle-key((%msg<key> // '').Str);
                emit %( seq => $*SEQ, event => 'key',
                        ok => ?$r.ok, op => $r.op, value => $r.value.Str,
                        index => $session.index );
            }
            when 'inspect' {
                # 0.109.0：Jupyter 的 Shift+Tab。与 `名字?` 同一份实现
                # （Session.inspect-name），只是把结果摊平成 ok/text 两个字段。
                my Str $name = (%msg<name> // '').Str;
                my %h = $session.inspect-name($name);
                emit %( seq => $*SEQ, event => 'inspect',
                        ok => ?%h<ok>, text => (%h<text> // '').Str );
            }
            when 'info' {
                emit %( seq => $*SEQ, event => 'info',
                        cwd => $session.sys.cwd.Str,
                        index => $session.index,
                        config => $session.config,
                        plugins => $session.plugins.names.elems,
                        plugin-names => $session.plugins.names.List,
                        history => $session.history.elems );
            }
            when 'history' {
                # 0.132.0 / §4.9j：notebook 的 history_request 要真实历史。
                emit %( seq => $*SEQ, event => 'history',
                        items => $session.history.List );
            }
            when 'prompt' {
                emit %( seq => $*SEQ, event => 'prompt',
                        text => $session.render-prompt );
            }
            when 'rc' {
                # 0.90.0 / ADR-0025：启动文件。路径由父进程解析（RAKUISH_RC /
                # $*HOME/.rakuishrc / RAKUISH_NO_RC），引擎只负责执行 ——
                # 「读哪个文件」是会话策略，不是解释器的事。
                my Str $path = (%msg<path> // '').Str;
                my Str $src  = '';
                my Str $err  = '';
                if !$path.chars {
                    $err = '没有指定 rc 路径';
                }
                elsif !$path.IO.e {
                    $err = "启动文件不存在: {$path}";
                }
                else {
                    {
                        CATCH { default { $err = .message } }
                        $src = $path.IO.slurp(:enc<utf-8>);
                    }
                }
                if $err.chars {
                    emit %( seq => $*SEQ, event => 'rc', ok => False,
                            out => '', err => $err, failed => 1, lines => 0,
                            prompt => '',
                            config => $session.config,
                            cwd => $session.sys.cwd.Str,
                            index => $session.index );
                }
                else {
                    my %h = $session.run-rc($src, :label($path));
                    emit %( seq => $*SEQ, event => 'rc',
                            ok => ?(%h<failed> == 0),
                            out => %h<out>, err => %h<err>,
                            failed => %h<failed>, lines => %h<lines>,
                            prompt => $session.render-prompt,
                            config => $session.config,
                            cwd => $session.sys.cwd.Str,
                            index => $session.index );
                }
            }
            when 'restore' {
                # `snapshot-on` 同时管读写：关掉快照的会话不该去翻磁盘上
                # 上一轮留下的文件（那会把「关闭」变成「只关一半」）。
                my %r = %();
                if $session.snapshot-on {
                    my %snap = Rakuish::Snapshot::load($session.snapshot-path.IO);
                    %r = %snap.elems ?? $session.restore-snapshot(%snap) !! %();
                }
                emit %( seq => $*SEQ, event => 'restored',
                        path => $session.snapshot-path,
                        index => $session.index, |%r );
            }
            when 'quit' {
                last;
            }
            default {
                emit %( seq => $*SEQ, event => 'error',
                        message => "未知 cmd: $cmd" );
            }
        }
        last if $cmd eq 'quit';
    }
}
