# Rakuish JSON Server 模式文档

> 版本：0.17.7  
> 入口：`bin/rakuish --json`

---

## 1. 概述

JSON Server 模式是 Rakuish 面向 Agent / 程序调用的批处理接口。它以**流式 JSON 行**协议工作：stdin 每行一条命令，stdout 每行一条 JSON 结果。适合被 LLM Agent、编辑器插件、CI 脚本等程序化调用。

与交互式 REPL 的核心区别：

| 维度 | REPL 模式 | JSON Server 模式 |
|---|---|---|
| 输入 | 终端逐行（支持多行续接） | stdin 每行一条完整命令 |
| 输出 | 彩色 `Out[n]` 提示符 | 纯 JSON 行，含 `ok/code/stdout/stderr/value` |
| 状态 | 进程内 accum | 进程内 PersistState（跨请求） |
| 退出 | Ctrl+D / `exit` | `%quit` 或 stdin EOF |
| 并发 | 单线程 | EVAL 串行 + shell 并发 |

---

## 2. 快速开始

### 2.1 启动

```bash
raku -Ilib bin/rakuish --json
```

启动后第一行输出就绪信号：

```json
{"rakuish":"ready","daemon":true}
```

### 2.2 最简单的调用

```bash
echo 'say "hello"' | raku -Ilib bin/rakuish --json
```

输出：

```json
{"rakuish":"ready","daemon":true}
{"id":"cmd-1","ok":true,"code":0,"stdout":"hello\n","stderr":"","value":"True","shell":false,"elapsed_ms":82}
{"rakuish":"done","exit":0}
```

### 2.3 批量执行

将多条命令写入文件，每行一条：

```
my $x = 10
say $x
!echo "from shell"
%quit
```

```bash
cat commands.txt | raku -Ilib bin/rakuish --json
```

---

## 3. 通信协议

### 3.1 请求格式

每行可以是**纯文本命令**或**JSON 对象**。

#### 纯文本命令

```
my $x = 10
```

自动分配 `id` 为 `cmd-N`（N 从 1 递增）。

#### JSON 对象命令

```json
{"id":"req-42","cmd":"say $x","shell":false}
```

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `id` | string | 否 | 请求标识，响应中原样返回。缺省为 `cmd-N` |
| `cmd` | string | 是 | Raku 代码或 shell 命令 |
| `raku` | string | 是* | `cmd` 的别名 |
| `shell_cmd` | string | 是* | `cmd` 的别名 |
| `shell` | bool | 否 | `true` 强制走 shell 后端，`false` 强制走 Raku EVAL。缺省时由 `is-shell` 自动判断 |

> `cmd` / `raku` / `shell_cmd` 三者取其一即可，优先级 `cmd > shell_cmd > raku`。

#### JSON 行识别规则

仅当输入行**以 `{` 开头且以 `}` 结尾**，且包含 `cmd`/`raku`/`shell_cmd` 字段时，才按 JSON 解析。否则整行作为纯文本命令。

### 3.2 响应格式

每条命令对应一行 JSON：

```json
{
  "id": "cmd-1",
  "ok": true,
  "code": 0,
  "stdout": "20\n",
  "stderr": "",
  "value": "True",
  "shell": false,
  "elapsed_ms": 79
}
```

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | string | 请求的 id（原样回传） |
| `ok` | bool | 是否成功 |
| `code` | int | 退出码：0 成功，1 失败（shell 命令为进程退出码） |
| `stdout` | string | 标准输出（`say`/`print` 等捕获于此，不会泄漏到真实 stdout） |
| `stderr` | string | 错误信息或标准错误 |
| `value` | string | 表达式的返回值（`.Str` 化） |
| `shell` | bool | `true` 表示该响应来自 shell 后端 |
| `elapsed_ms` | int | 耗时（毫秒） |
| `hint` | string | *可选* 失败时的修复建议 |
| `watch` | object | *可选* `%watch on` 时返回的变量快照 |
| `magic` | string | *可选* 魔法命令的名称 |
| `message` | string | *可选* 魔法命令的提示信息 |

### 3.3 生命周期消息

```json
{"rakuish":"ready","daemon":true}    // 启动就绪
{"rakuish":"done","exit":0}           // 正常退出，exit 为最终退出码
```

- `exit: 0`：所有命令成功
- `exit: 1`：存在失败的命令（`failed-count > 0`）

---

## 4. 核心功能

### 4.1 Raku 代码执行

每一行非 shell、非魔法的输入都作为 Raku 代码执行。EVAL 在 `Rakuish::Eval` 包内进行，返回值通过 `value` 字段返回，`say`/`print` 的输出捕获到 `stdout`。

```
输入:  1 + 2
输出:  {"value":"3","ok":true,...}

输入:  say "hello"
输出:  {"value":"True","stdout":"hello\n",...}
```

### 4.2 变量持久化

变量声明跨请求保持，支持 `my` / `our` / `state`，以及 `$` `@` `%` `&` 四种 sigil。

#### 首次声明

`my` / `state` 自动转换为 `our`（包级作用域，跨 EVAL 持久）：

```
输入:  my $x = 10
实际EVAL: our $x = 10
```

#### 再次声明

去掉 `my`/`our`/`state` 关键字，变为裸赋值：

```
输入:  my $x = 20        # $x 已存在
实际EVAL: $x = 20
```

#### 混合声明

`my ($x, $y)` 中若 `$x` 已存在、`$y` 是新的，则去掉关键字，`$y` 通过 `our $y;` 前置声明：

```
输入:  my ($x, $y) = (10, 20)
实际EVAL: our $y; ($x, $y) = (10, 20)
```

#### 未在本格声明的变量

每格 EVAL 前自动前置 `our $var;`：

```
# 第1格: my $x = 10   →  our $x = 10
# 第2格: say $x       →  our $x; say $x
```

### 4.3 sub 持久化

`sub` 是词法作用域，不跨 EVAL 持久。因此所有已声明的 sub 源码会被累积，每格 EVAL 前重新前置声明。

```
# 第1格: sub greet($n) { "Hello, $n!" }
# 第2格: greet("World")
#        实际EVAL: sub greet($n) { "Hello, $n!" }\ngreet("World")
```

#### multi / proto / only sub

- `multi sub`：所有 variant 都被累积保留，支持多分派
- `proto sub` / `only sub`：同样累积
- 本格新声明的 sub 不会在前置中重复（避免 Redeclaration）

```
multi sub add(Int $a, Int $b) { $a + $b }
multi sub add(Str $a, Str $b) { $a ~ $b }
add(1, 2)        # → 3
add("a", "b")    # → "ab"
```

### 4.4 类型持久化

`class` / `role` / `grammar` / `enum` 声明写入包级 stash，跨 EVAL 自动持久。但 EVAL 是在子例程内调用的，**裸名查找看不到包级符号**，因此用 `constant Name = OUR::Name;` 建立词法别名。

```
# 第1格: class Foo { has $.z = 42 }
# 第2格: Foo.new.z
#        实际EVAL: class Foo { ... }\nconstant Foo = OUR::Foo;\nFoo.new.z
```

#### 不重声明

类型只声明一次，后续格只加 `constant` 别名，避免 `Redeclaration of symbol` 错误。

#### enum 支持

```
enum Color <Red Green Blue>
Color::Green     # → Green
Color::Red.raku  # → Color::Red (enum value)
```

### 4.5 Shell 命令

#### 显式 shell 前缀

以 `!` 开头的命令走 shell 后端：

```
!ls -la
!echo $HOME
```

#### 自动识别的 shell 内建

以下命令无需 `!` 前缀，自动走 shell：

```
export / unset / cd / alias / type / pwd / history
```

#### JSON 指定 shell

```json
{"id":"s1","cmd":"ls -la","shell":true}
```

#### shell 响应

```json
{"id":"s1","ok":true,"code":0,"stdout":"...","stderr":"","shell":true,"elapsed_ms":12}
```

### 4.6 魔法命令

以 `%` 开头且后跟已知关键字的命令为魔法命令。**注意**：`%h<c>` 等 Raku 哈希访问不会被误判为魔法命令。

| 命令 | 说明 | 示例 |
|---|---|---|
| `%eval-engine` | 查看/切换 EVAL 引擎 | `%eval-engine rakupp` / `%eval-engine rakudo` |
| `%watch` | 开启/关闭变量快照 | `%watch on` / `%watch off` |
| `%shell` | 查看/切换 shell 后端 | `%shell bash` / `%shell zsh` |
| `%quit` / `%exit` | 退出服务器 | `%quit` |

#### %eval-engine

```
%eval-engine              # 查看当前引擎
%eval-engine rakudo       # 切换到 rakudo（默认）
%eval-engine rakupp       # 切换到 rakupp（需设置 RAKUPP 环境变量或安装到 ~/.rakupp/bin/rakupp）
```

#### %watch

开启后，每次 EVAL 成功的响应会附带 `watch` 字段，包含当前所有 `our` 变量的快照：

```json
{
  "id":"cmd-3","ok":true,"value":"True",
  "watch":{"$x":"20","@arr":"[1 2 3 4]","%h":"{a => 1, b => 2}"}
}
```

### 4.7 错误提示 (hint)

EVAL 失败时，会尝试给出修复建议：

```json
{
  "ok":false,
  "stderr":"Undeclared routine: greet",
  "hint":"Name not declared. If shell cmd, prefix with !"
}
```

常见 hint：

| 场景 | hint |
|---|---|
| 使用了 shell 内建命令（export/cd/pwd 等）未加 `!` | `"export" is a shell builtin -- prefix with !` |
| 命令包含 `\|` 或 `>` 等 shell 语法 | `Looks like shell syntax -- prefix with !` |
| 调用了未声明的 routine | `Name not declared. If shell cmd, prefix with !` |

---

## 5. 架构设计

### 5.1 accum 副作用问题

**旧方案**：每格 EVAL 整份 accum（所有历史源码拼接）。

**问题**：`say` / `start` / `sleep` / `spurt :append` 等副作用会在每格重复执行。

**示例**：
```
# 格1: spurt("f", "A\n")        → f = "A\n"
# 格2: spurt("f", "B\n", :append)  → 重跑格1+格2 → f = "A\nA\nB\n"  ❌
```

**新方案**：每格只 EVAL 当前格，变量/sub/类型通过前置声明实现持久化。副作用只执行一次，性能从 O(n²) 降到 O(n)。

### 5.2 持久化策略总览

```
每格 EVAL 源码 = our 变量前置 + sub 声明累积 + 类型别名 + 当前格转换后源码
```

| 元素 | 持久机制 | 原因 |
|---|---|---|
| 变量 | `our` 包级作用域 | `our` 跨 EVAL 持久 |
| sub | 累积声明文本重新前置 | sub 是词法作用域，不跨 EVAL |
| 类型 | stash 持久 + `constant` 别名 | EVAL 在子内调用，裸名看不到包级符号 |

### 5.3 核心组件

#### PersistState

跨请求的持久状态容器：

```raku
class PersistState {
    has Set $!vars;        # 已声明变量名
    has %!subs;            # sub name → [声明源码, ...]（multi 支持）
    has @!sub-order;       # sub 声明顺序
    has Set $!types;       # 已声明类型名
}
```

关键方法：

- `vars` / `sub-source` / `sub-source-excluding(@fresh)` / `types`
- `add-var` / `add-sub` / `add-type`

#### transform-cell

源码转换 + 声明提取。逐字符扫描（含字符串/注释/正则状态机），在深度 0 处识别声明关键字：

1. **变量声明** `my` / `our` / `state`：
   - 首次：`my`/`state` → `our`，登记变量
   - 重声明：去掉关键字，新变量只登记到 ps（走 `our` 前置）
2. **sub 声明** `sub` / `multi sub` / `proto sub` / `only sub`：
   - 调用 `find-decl-end` 找到完整声明，提取名字，累积到 ps
3. **类型声明** `class` / `role` / `grammar` / `enum`：
   - 调用 `find-decl-end`，提取名字，登记到 ps

返回：`($transformed-src, @fresh-vars, @fresh-subs, @fresh-types)`

#### find-decl-end

向前扫描找到声明结束位置。跳过字符串（单/双/q-quoting）、注释、正则，遇到 `{` 开始计数，回到 0 时结束；若无 `{` 则遇到 `;` 结束。

#### build-eval-source

拼接完整 EVAL 源码：

```raku
our $x; our @y; ...                    # 1. our 变量前置（不含本格新声明）
sub foo() { ... }\nmulti sub foo(...)  # 2. sub 声明累积（不含本格新声明）
constant Foo = OUR::Foo;               # 3. 类型别名（不含本格新声明）
<当前格转换后源码>                      # 4. 当前格
```

#### json-server-loop

主循环：

1. 启动 shell daemon
2. 发送 `ready` 信号
3. 启动 reader 线程逐行读取 stdin
4. 每行命令分流：
   - 魔法命令 → 直接处理
   - shell 命令 → `start` 并发执行
   - Raku 代码 → 加入 `$eval-chain` Promise 链串行执行
5. 结果写入 `$result-channel`
6. 主线程从 channel 读取并输出 JSON
7. EOF 后 await 所有任务，输出 `done`

### 5.4 并发模型

```
stdin reader ──┬── shell cmd ──→ start (并发，各自独立)
               │
               └── raku cmd ───→ eval-chain (串行 Promise 链)
                                    │
                                    ▼
                              result-channel
                                    │
                                    ▼
                              stdout (JSON 行)
```

- **EVAL 必须串行**：`our` 变量和 sub 声明依赖执行顺序
- **shell 并发**：shell 命令无共享状态，可并发
- **输出顺序**：shell 和 EVAL 共享 result-channel，输出顺序可能与输入顺序不一致，靠 `id` 字段关联

### 5.5 eval-cell 接口

```raku
our sub eval-cell(Str $src, Int :$index = 0, LexState :$state,
                  Int :$line-base = 0, Bool :$watch = False --> CellResult)
```

JSON Server 模式传入**空的 `LexState.new`**，即不使用 accum，只 EVAL 给定的 `$full-src`。

`CellResult` 字段：`.ok` / `.value` / `.error` / `.extra-output` / `.exit-code` / `.watch` / `.elapsed-ms`

---

## 6. 边界与限制

### 6.1 单行协议

JSON 模式每行一条命令，**不支持多行声明**。多行 sub/class 需写成单行或用 `;` 分隔：

```
# 推荐（单行）
sub fib($n) { return 1 if $n < 2; fib($n-1) + fib($n-2) }

# 不支持（多行）
sub fib($n) {
    return 1 if $n < 2;
    fib($n-1) + fib($n-2)
}
```

### 6.2 sub 重声明

非 multi 的 sub 重新声明会报 `Redeclaration of routine`（所有历史声明都会被前置）。如需修改 sub 行为，使用 `multi sub` 或重启进程。

### 6.3 类型约束丢失

`my Int $x` 在后续格的前置声明只有 `our $x;`，类型约束不保留。

### 6.4 state 语义

`state $x = 0` 转换为 `our $x = 0`。由于每格只执行一次，`state` 的「只初始化一次」语义在单格内不体现。若同一格源码被重复发送，会重置为初值。

### 6.5 魔法命令列表

当前支持的魔法命令硬编码为：`eval-engine` / `watch` / `shell` / `quit` / `exit`。新增魔法命令需同步更新 `json-server-loop` 中的放行列表。

---

## 7. 完整示例

### 7.1 变量 + sub + class 综合

```
my $x = 10
$x = 20
say $x
sub greet($name) { "Hello, $name!" }
greet("World")
class Point { has $.x; has $.y; method area { $!x * $!y } }
Point.new(x => 3, y => 4).area
```

输出（省略无关字段）：

```json
{"value":"10","ok":true}
{"value":"20","ok":true}
{"value":"True","stdout":"20\n","ok":true}
{"value":"greet","ok":true}
{"value":"Hello, World!","ok":true}
{"ok":true}
{"value":"12","ok":true}
```

### 7.2 multi sub 分派

```
multi sub add(Int $a, Int $b) { $a + $b }
multi sub add(Str $a, Str $b) { $a ~ $b }
add(1, 2)
add("foo", "bar")
```

```json
{"value":"3","ok":true}
{"value":"foobar","ok":true}
```

### 7.3 副作用不重复

```
spurt("/tmp/f.txt", "A\n")
spurt("/tmp/f.txt", "B\n", :append)
```

文件内容：

```
A
B
```

而非旧方案的 `A\nA\nB\n`。

### 7.4 Shell 并发

```
!sleep 3 && echo first
!sleep 1 && echo second
say "raku runs in parallel with shell"
```

shell 的两个 `sleep` 并发执行，Raku 代码在 eval-chain 中串行。总耗时约 3 秒（而非 4 秒）。

### 7.5 watch 变量快照

```
%watch on
my $x = 10
$x = 20
```

```json
{"ok":true,"value":"10","watch":{"$x":"10"}}
{"ok":true,"value":"20","watch":{"$x":"20"}}
```

### 7.6 错误恢复

```
my $x = 1
$undeclared
say $x
```

```json
{"value":"1","ok":true}
{"ok":false,"stderr":"Variable '$undeclared' is not declared...","hint":"Name not declared. If shell cmd, prefix with !"}
{"value":"True","stdout":"1\n","ok":true}
```

单格失败不影响后续格，`$x` 仍然持久。

---

## 8. 环境变量

| 变量 | 说明 |
|---|---|
| `RAKUPP` | rakupp 可执行文件路径（`%eval-engine rakupp` 时使用） |
| `HOME` | shell daemon 和历史文件所在目录 |

---

## 9. 相关文件

| 文件 | 职责 |
|---|---|
| `bin/rakuish` | 入口，`--json` 参数分发到 `json-server-loop` |
| `lib/Rakuish/JSONServer.rakumod` | JSON Server 主逻辑（PersistState / transform-cell / build-eval-source / json-server-loop） |
| `lib/Rakuish/Eval.rakumod` | `eval-cell` / `wrap-eval-source` / DSL-PRELUDE |
| `lib/Rakuish/Shell/Engine.rakumod` | shell daemon / `run-engine` |
