#!/usr/bin/env raku
# rakuish-serve.raku — TCP 常驻服务端入口

use Rakuish::JSONServer;

# Manual ARGS parsing (no MAIN signature tricks — avoids Raku usage traps)
my Int  $port        = 8765;
my Int  $max-clients = 16;
my Bool $no-daemon   = False;
my Str  $host        = 'localhost';

my @argv = @*ARGS;
my Int $i = 0;
while $i < @argv {
    my $a = @argv[$i].Str;

    if $a ~~ /^ '--port=' (\d+) $/ { $port = +$0; $i++; next }
    if $a ~~ /^ '--max-clients=' (\d+) $/ { $max-clients = +$0; $i++; next }
    if $a ~~ /^ '--host=' (.+) $/ { $host = ~$0; $i++; next }
    if $a eq '--no-daemon' { $no-daemon = True; $i++; next }

    if $a eq '--port' && $i + 1 < @argv { $port = +@argv[$i+1]; $i += 2; next }
    if $a eq '--max-clients' && $i + 1 < @argv { $max-clients = +@argv[$i+1]; $i += 2; next }
    if $a eq '--host' && $i + 1 < @argv { $host = @argv[$i+1].Str; $i += 2; next }

    $i++;
}

my Int $code = serve-loop(
    :$port, :$max-clients, :$host,
    :enable-daemon(!$no-daemon),
);
exit $code;
