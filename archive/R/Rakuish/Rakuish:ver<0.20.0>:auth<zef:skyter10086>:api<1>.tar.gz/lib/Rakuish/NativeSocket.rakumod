unit module Rakuish::NativeSocket;

# ── NativeCall socket 辅助（纯 libc 封装）─────────────────────────────
#
# Raku IO::Socket::INET.accept 在当前 MoarVM 版本中会在创建新
# socket 对象时读取 getsockname 结果，拿到 0/-1 端口就抛
# "Invalid port (Int). Must be 0..65535"。
# 本模块用 NativeCall 直接调 libc 的 socket/accept/read/write
# 绕过 Raku 层。协议与 Raku IO 完全对齐（行分隔 \n）。

use NativeCall;

constant AF_INET      = 2;
constant SOCK_STREAM  = 1;
constant SOL_SOCKET   = 1;
constant SO_SNDBUF    = 7;
constant SO_RCVBUF    = 8;

constant BUF-SIZE     = 4096;   # buffered recv 缓冲区大小
constant WRITE-BUF-SZ = 65536;  # SO_SNDBUF / SO_RCVBUF 调整值

sub c_socket(int32, int32, int32) returns int32
    is native is symbol<socket> { * }
sub c_bind(int32, CArray[int8], int32) returns int32
    is native is symbol<bind> { * }
sub c_listen(int32, int32) returns int32
    is native is symbol<listen> { * }
sub c_accept(int32, Pointer, Pointer) returns int32
    is native is symbol<accept> { * }
sub c_close(int32) returns int32
    is native is symbol<close> { * }
sub c_read(int32, CArray[int8], size_t) returns ssize_t
    is native is symbol<read> { * }
sub c_write(int32, CArray[int8], size_t) returns ssize_t
    is native is symbol<write> { * }
sub c_setsockopt(int32, int32, int32, Pointer, int32) returns int32
    is native is symbol<setsockopt> { * }

# pollfd 结构体: { int32 fd; int16 events; int16 revents; }
# 我们用 CArray[int8] 手动布局 (8 bytes on Linux)
sub c_poll(CArray[int8], int32, int32) returns int32
    is native is symbol<poll> { * }

our constant POLLIN = 0x001;

# ── 公开子例程 ──────────────────────────────────────────────────

our sub native-listen(int16 $port, Str :$host = 'localhost' --> int32) is export {
    my $addr = CArray[int8].new(16);
    $addr[0] = 2;  $addr[1] = 0;         # sin_family = AF_INET
    $addr[2] = ($port +> 8) +& 0xFF;     # port hi byte (big-endian)
    $addr[3] = $port +& 0xFF;            # port lo byte
    # sin_addr = 0 (INADDR_ANY) + sin_zero = 0 → 剩下 12 字节全 0

    my $fd = c_socket(AF_INET, SOCK_STREAM, 0);
    die "native-listen: socket() failed: $!" if $fd < 0;

    my $r = c_bind($fd, $addr, 16);
    die "native-listen: bind(:$host:$port) failed: $!" if $r != 0;

    # backlog: SOMAXCONN 在 Linux 上通常 128-4096；
    # 8 太小（30+ 并发瞬间就 RST 拒绝）。取 256 够用且安全。
    $r = c_listen($fd, 256);
    die "native-listen: listen() failed" if $r != 0;

    return $fd;
}

our sub native-accept(int32 $srv-fd --> int32) is export {
    c_accept($srv-fd, Pointer, Pointer);
}

our sub native-close(int32 $fd) is export {
    c_close($fd);
}

# ── poll 辅助：检查 fd 是否可读（支持超时）────────────────────────
# 超时毫秒数。返回 True=可读/有数据, False=超时或错误
our sub native-can-read(int32 $fd, int32 $timeout-ms = 30000 --> Bool) is export {
    # 手动构造 pollfd { fd: int32, events: int16, revents: int16 } = 8 bytes
    my CArray[int8] $pfd = CArray[int8].new(8);
    # fd (4 bytes, little-endian)
    $pfd[0] = $fd +& 0xFF;
    $pfd[1] = ($fd +> 8) +& 0xFF;
    $pfd[2] = ($fd +> 16) +& 0xFF;
    $pfd[3] = ($fd +> 24) +& 0xFF;
    # events (2 bytes): POLLIN = 0x001
    $pfd[4] = 0x01;
    $pfd[5] = 0x00;
    # revents (2 bytes): 清零
    $pfd[6] = 0x00;
    $pfd[7] = 0x00;

    my $r = c_poll($pfd, 1, $timeout-ms);
    return True if $r > 0;     # 有事件
    return False;              # 超时 (-1 或 0)
}

# ── Buffered 读（新，用于 serve-loop）─────────────────────────────
#
# 每 client 一个 BufferedReader 对象，内部维护 4KB 缓冲。
# 读一行只需 1 次 recv(4096)（平均每行 < 100B），
# 相比逐字节 recv(1) 快 ~50x。

our class BufferedReader is export {
    has int32              $.fd;
    has CArray[int8]       $!cbuf;     # 给 c_read 当 buffer（底层内存连续）
    has Pointer[int8]      $!buf;      # nativecast 后逐字节读/写都走这个
    has int32              $!buf-pos;
    has int32              $!buf-len;
    has Bool               $!eof;

    method BUILD(:$fd! --> Nil) {
        $!fd      = $fd;
        $!cbuf    = CArray[int8].new(BUF-SIZE);
        $!buf     = nativecast(Pointer[int8], $!cbuf);  # 关键：用指针索引才对
        $!buf-pos = 0;
        $!buf-len = 0;
        $!eof     = False;
    }

    method !fill(--> Bool) {
        return False if $!eof;
        # 已全部消耗 → 归零
        if $!buf-pos >= $!buf-len {
            $!buf-pos = 0;
            $!buf-len = 0;
        }
        # 把剩余数据移到头部（用指针写）
        if $!buf-pos > 0 {
            my int32 $remain = $!buf-len - $!buf-pos;
            for ^$remain {
                $!buf[$_] = $!buf[$!buf-pos + $_];
            }
            $!buf-len = $remain;
            $!buf-pos = 0;
        }
        # 从 socket 读更多
        my int32 $space = BUF-SIZE - $!buf-len;
        if $space > 0 {
            my $n = c_read($.fd, $!cbuf, $space);
            if $n <= 0 {
                $!eof = True;
                return False;
            }
            $!buf-len += $n;
        }
        return True;
    }

    method read-line(--> Str) {
        my $out = "";
        loop {
            # 在缓冲里找 \n（用 Pointer[int8] 索引）
            my int32 $end-pos = -1;
            for $!buf-pos ..^ $!buf-len {
                if $!buf[$_] == 10 {
                    $end-pos = $_;
                    last;
                }
            }
            if $end-pos >= 0 {
                # 有完整一行 → 拼接
                for $!buf-pos ..^ $end-pos {
                    $out ~= $!buf[$_].chr;
                }
                $!buf-pos = $end-pos + 1;
                return $out;
            }
            # 没找到 \n → 把剩余全拼进 $out
            for $!buf-pos ..^ $!buf-len {
                $out ~= $!buf[$_].chr;
            }
            $!buf-pos = $!buf-len;
            # 再 fill 一次
            if !self!fill {
                last;
            }
        }
        return $out;
    }
}

# ── 逐字节读（旧，给 pipe-mode process-client 用）─────────────────
# 保留 API 兼容，但 pipe-mode 性能不重要（单 client 单次调用）。
our sub native-read-line(int32 $fd, int32 :$max = 65536 --> Str) is export {
    my CArray[int8] $one = CArray[int8].new(1);
    my $out = "";
    my int32 $total = 0;
    loop {
        my $n = c_read($fd, $one, 1);
        return "" if $n <= 0;               # EOF / error
        last if $one[0] == 10;              # \n terminates
        $out ~= $one[0].chr;
        $total++;
        last if $total >= $max;             # guard against runaway input
    }
    return $out;
}

# ── 写（优化版：UTF-8 encode + bulk CArray 拷贝）──────────────────

# 带换行符写一行
our sub native-write-line(int32 $fd, Str $line) is export {
    native-write($fd, $line ~ "\n");
}

# 写裸字节（逐字符 ord()，和原生版本行为一致）
# 注意：c_write 接受 CArray[int8] 时传的是底层内存指针，能正确按字节写，
# 但 Raku 端用 $buf[$i] 读写 int8 有 int32 索引错位 bug（见 BufferedReader）。
# 写侧因为只 c_write 一次整个指针，不涉及 Raku 端索引，所以能正常工作。
our sub native-write(int32 $fd, Str $data) is export {
    my CArray[int8] $buf = CArray[int8].new($data.chars);
    my int32 $i = 0;
    for $data.comb -> $ch {
        $buf[$i++] = $ch.ord;
    }
    c_write($fd, $buf, $data.chars);
}

# ── socket buffer 调优（可选，暂不默认调用）────────────────────
# 注意：CArray[int32] 传给 Pointer 参数有 unbox 问题（MoarVM NativeCall）。
# 这里用 malloc + Pointer + nativecast 绕过。
our sub native-set-bufs(int32 $fd, Int :$snd = WRITE-BUF-SZ, Int :$rcv = WRITE-BUF-SZ) is export {
    sub c_malloc(size_t) returns Pointer is native is symbol<malloc> { * }
    sub c_free(Pointer) is native is symbol<free> { * }

    if $snd > 0 {
        my Pointer $p = c_malloc(4);
        # 直接按字节写 int32 (little-endian)
        nativecast(CArray[int8], $p)[0] = $snd +& 0xFF;
        nativecast(CArray[int8], $p)[1] = ($snd +> 8) +& 0xFF;
        nativecast(CArray[int8], $p)[2] = ($snd +> 16) +& 0xFF;
        nativecast(CArray[int8], $p)[3] = ($snd +> 24) +& 0xFF;
        c_setsockopt($fd, SOL_SOCKET, SO_SNDBUF, $p, 4);
        c_free($p);
    }
    if $rcv > 0 {
        my Pointer $p = c_malloc(4);
        nativecast(CArray[int8], $p)[0] = $rcv +& 0xFF;
        nativecast(CArray[int8], $p)[1] = ($rcv +> 8) +& 0xFF;
        nativecast(CArray[int8], $p)[2] = ($rcv +> 16) +& 0xFF;
        nativecast(CArray[int8], $p)[3] = ($rcv +> 24) +& 0xFF;
        c_setsockopt($fd, SOL_SOCKET, SO_RCVBUF, $p, 4);
        c_free($p);
    }
}
