unit module Rakuish::JSONServer;

# ── JSON Server 模式（bin/rakuish --json 入口）──────────────────────
#
# 流式请求-响应：stdin 每行一条命令，stdout 每行一条 JSON 结果。
#
# ── accum 副作用问题的解决方案 ──────────────────────────────────────
#
# 旧方案每格 EVAL 整份 accum，导致 say/start/sleep/spurt 等副作用每格重复执行。
# 新方案采用「our 前置声明 + 声明累积 + 类型别名」混合策略，每格只 EVAL 当前格：
#
#   1. 变量（my/our/state $@%&）：
#      - 首次声明：my/state → our（our 变量包级作用域，跨 EVAL 持久）
#      - 再次声明：去掉 my/our/state 关键字，变成裸赋值
#      - 每格 EVAL 前前置 our $x; our @y; ...（已声明但未在本格重新声明的变量）
#
#   2. sub（含 multi/proto/only）：
#      - sub 不跨 EVAL 持久（词法作用域），需每格重新声明
#      - 声明本身无副作用（body 只在调用时执行），可安全重编译
#      - 累积所有 sub 声明文本，每格 EVAL 前前置（不含本格新声明的 sub）
#
#   3. class/role/grammar/enum：
#      - 声明本身写入包级 stash，跨 EVAL 持久
#      - 但 EVAL 内的裸名查找看不到包级符号（EVAL 在子内调用的限制）
#      - 解决方案：每格前置 constant Name = OUR::Name; 建立词法别名
#      - 不重声明（会报 "Redeclaration of symbol"）
#
# 每格 EVAL 源码 = our 变量前置 + sub 声明累积 + 类型别名 + 当前格转换后源码
# 副作用只执行一次，性能从 O(n²) 降到 O(n)。
#
# ── 分流规则 ────────────────────────────────────────────────────────
#   !cmd / export / unset / cd / pwd / alias / type  → shell 后端
#   %eval-engine / %watch / %shell / %quit           → 魔法命令
#   其余                                             → Raku EVAL
#
# 输入：每行一条命令，或 JSON {"id":"...","cmd":"...","shell":true/false}
# 输出：每行一个 JSON {id, ok, code, stdout, stderr, value, shell, elapsed_ms, hint?, watch?}
#
# 并发：shell 并发（各自独立引擎进程），Raku EVAL 串行（保持 our/sub 语义）
# 退出：收到 %quit 或 stdin EOF

use Rakuish::Shell::Engine;
use Rakuish::Eval;
use Rakuish::Loop;  # %RC, known-config-key, coerce-bool
use JSON::Fast;

# ── 持久状态：跨 cell 的变量 / sub / 类型声明 ───────────────────────
class PersistState is export {
    has Set $!vars .= new;              # 已声明变量名：$x, @y, %z
    has %!subs;                          # sub name → [声明源码, ...]（multi 支持）
    has @!sub-order;                     # sub 声明顺序（保持插入序）
    has Set $!types .= new;             # 已声明类型名：class/role/grammar/enum

    method has-var(Str $name --> Bool) { $name (elem) $!vars }
    method add-var(Str $name) { $!vars ∪= $name }
    method vars(--> List) { $!vars.keys.List }

    method has-sub(Str $name --> Bool) { %!subs{$name}:exists }
    method add-sub(Str $name, Str $src) {
        unless %!subs{$name}:exists { @!sub-order.push: $name; %!subs{$name} = [] }
        %!subs{$name}.push: $src;
    }
    method sub-source(--> Str) {
        @!sub-order.map({ %!subs{$_}.join("\n") }).join("\n")
    }

    method sub-source-excluding(@exclude --> Str) {
        my Set $ex .= new(@exclude);
        @!sub-order.grep({ !($_ (elem) $ex) }).map({ %!subs{$_}.join("\n") }).join("\n")
    }

    method has-type(Str $name --> Bool) { $name (elem) $!types }
    method add-type(Str $name) { $!types ∪= $name }
    method types(--> List) { $!types.keys.List }
}

# ── 提取变量声明中的所有变量名 ───────────────────────────────────────
sub extract-var-names(Str $decl-part --> List) {
    my @names = $decl-part ~~ m:g/ <[$@%&]> \w+ /;
    @names.map(*.Str).List
}

# ── 提取 sub 声明名 ────────────────────────────────────────────────
our sub extract-sub-name(Str $decl --> Str) is export {
    if $decl ~~ / ^ [multi|proto|only] \s+ sub \s+ (\w+) / { return ~$/[0] }
    if $decl ~~ / ^ sub \s+ (\w+) / { return ~$/[0] }
    if $decl ~~ / ^ [multi|proto|only] \s+ (\w+) / { return ~$/[0] }
    return ''
}

# ── 提取类型声明名（class/role/grammar/enum）────────────────────────
sub extract-type-name(Str $decl --> Str) {
    if $decl ~~ / ^ [our\s+]? [class|role|grammar|enum] \s+ (\w+) / { return ~$/[0] }
    return ''
}

# ── 向前扫描找到声明结束位置（sub / class / role / grammar / enum）──
# 从 $start 开始，跳过字符串/注释/正则，遇到 { 开始计数，回到 0 时结束；
# 若始终无 {，遇到 ; 结束。
our sub find-decl-end(Str $src, Int $start --> Int) is export {
    my $i = $start;
    my $n = $src.chars;
    my $st = 'normal';
    my $open; my $close;
    my $bq-depth = 0;
    my $depth = 0;
    my Bool $seen-brace = False;

    while $i < $n {
        my $c = $src.substr($i, 1);

        if $st eq 'comment' { $st = 'normal' if $c eq "\n"; $i++; next }
        if $st eq 'sq' {
            if $c eq q{'} {
                if $i + 1 < $n && $src.substr($i+1,1) eq q{'} { $i += 2; next }
                $st = 'normal';
            }
            $i++; next;
        }
        if $st eq 'dq' {
            if $c eq '\\' { $i += 2; next }
            $st = 'normal' if $c eq q{"};
            $i++; next;
        }
        if $st eq 'bq' {
            if $c eq $open { $bq-depth++ }
            elsif $c eq $close { $st = 'normal' if $bq-depth == 0; $bq-depth-- if $bq-depth > 0 }
            $i++; next;
        }
        if $st eq 'rx' {
            if $c eq '\\' { $i += 2; next }
            $st = 'normal' if $c eq '/';
            $i++; next;
        }
        if $c eq '#' { $st = 'comment'; $i++; next }
        if $c eq q{'} { $st = 'sq'; $i++; next }
        if $c eq q{"} { $st = 'dq'; $i++; next }
        if $c eq 'q' | 'Q' {
            my $prev = $i > 0 ?? $src.substr($i-1,1) !! ' ';
            my $wordy = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$@%&.'.contains($prev) || $prev eq ']';
            if !$wordy {
                if $src.substr($i) ~~ /^ [ 'q' | 'Q' ] [ 'q' | 'x' | 'w' | 'wv' | 'ww' | 'v' ]? ':'? <[a..z]>* $<brk>=('[' | '(' | '{' | '<') / -> $m {
                    my $b = $m<brk>.Str;
                    $open  = $b;
                    $close = $b eq '[' ?? ']' !! $b eq '(' ?? ')' !! $b eq '{' ?? '}' !! '>';
                    $bq-depth = 0; $st = 'bq'; $i++; next;
                }
            }
        }
        if $src.substr($i) ~~ /^ [ 'm' | 'rx' | 's' | 'ms' | 'ss' | 'tr' ] \s* '/' / { $st = 'rx'; $i++; next }

        if $c eq '{' { $depth++; $seen-brace = True }
        elsif $c eq '}' { $depth--; return $i + 1 if $seen-brace && $depth == 0 }
        elsif $c eq ';' && !$seen-brace { return $i + 1 }

        $i++;
    }
    return $n;
}

# ── 转换单格源码 ────────────────────────────────────────────────────
# my/state → our（首次）或去关键字（重声明）；提取 sub 和类型声明。
# 返回 ($transformed-src, @fresh-vars, @fresh-subs, @fresh-types)
our sub transform-cell(Str $src, PersistState $ps --> List) is export {
    my @fresh-vars;
    my @fresh-subs;
    my @fresh-types;
    my @out;
    my $i = 0;
    my $n = $src.chars;
    my $st = 'normal';
    my $open; my $close;
    my $bq-depth = 0;
    my $depth = 0;

    while $i < $n {
        my $c = $src.substr($i, 1);

        # ── 字符串/注释/正则状态处理 ──
        if $st eq 'comment' {
            @out.push($c); $st = 'normal' if $c eq "\n"; $i++; next;
        }
        if $st eq 'sq' {
            @out.push($c);
            if $c eq q{'} {
                if $i + 1 < $n && $src.substr($i+1,1) eq q{'} { @out.push($src.substr($i+1,1)); $i += 2; next }
                $st = 'normal';
            }
            $i++; next;
        }
        if $st eq 'dq' {
            @out.push($c);
            if $c eq '\\' { @out.push($src.substr($i+1,1)); $i += 2; next }
            $st = 'normal' if $c eq q{"};
            $i++; next;
        }
        if $st eq 'bq' {
            @out.push($c);
            if $c eq $open { $bq-depth++ }
            elsif $c eq $close { $st = 'normal' if $bq-depth == 0; $bq-depth-- if $bq-depth > 0 }
            $i++; next;
        }
        if $st eq 'rx' {
            @out.push($c);
            if $c eq '\\' { @out.push($src.substr($i+1,1)); $i += 2; next }
            $st = 'normal' if $c eq '/';
            $i++; next;
        }

        # ── normal 状态 ──
        if $c eq '#' { $st = 'comment'; @out.push($c); $i++; next }
        if $c eq q{'} { $st = 'sq'; @out.push($c); $i++; next }
        if $c eq q{"} { $st = 'dq'; @out.push($c); $i++; next }
        if $c eq 'q' | 'Q' {
            my $prev = $i > 0 ?? $src.substr($i-1,1) !! ' ';
            my $wordy = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$@%&.'.contains($prev) || $prev eq ']';
            if !$wordy {
                if $src.substr($i) ~~ /^ [ 'q' | 'Q' ] [ 'q' | 'x' | 'w' | 'wv' | 'ww' | 'v' ]? ':'? <[a..z]>* $<brk>=('[' | '(' | '{' | '<') / -> $m {
                    my $b = $m<brk>.Str;
                    $open  = $b;
                    $close = $b eq '[' ?? ']' !! $b eq '(' ?? ')' !! $b eq '{' ?? '}' !! '>';
                    $bq-depth = 0; $st = 'bq'; @out.push($c); $i++; next;
                }
            }
        }
        if $src.substr($i) ~~ /^ [ 'm' | 'rx' | 's' | 'ms' | 'ss' | 'tr' ] \s* '/' / {
            $st = 'rx'; @out.push($c); $i++; next;
        }

        if $c eq '{' || $c eq '(' || $c eq '[' { $depth++ }
        elsif $c eq '}' || $c eq ')' || $c eq ']' { $depth-- }

        # ── 深度 0 时检测声明关键字 ──
        if $depth == 0 {
            # 变量声明：my / our / state 后跟空白
            if $src.substr($i) ~~ /^ (my|our|state) \s+ / {
                my $match-len = $/.chars;
                my $rest-start = $i + $match-len;
                my $semi = $src.index(';', $rest-start);
                my $nl   = $src.index("\n", $rest-start);
                my $line-end = $semi.defined && ($nl.defined.not || $semi < $nl) ?? $semi !! ($nl // $n);
                my $decl-line = $src.substr($rest-start, $line-end - $rest-start);
                my $decl-part = $decl-line.split('=', 2)[0] // $decl-line;
                my @names = extract-var-names($decl-part);

                if @names {
                    my $redecl = @names.first({ $ps.has-var($_) }).defined;
                    if $redecl {
                        $i += $match-len; next;   # 去掉关键字
                    } else {
                        @out.push('our ');         # my/state → our
                        for @names -> $name {
                            unless $ps.has-var($name) {
                                $ps.add-var($name);
                                @fresh-vars.push: $name;
                            }
                        }
                        $i += $match-len; next;
                    }
                }
            }

            # sub 声明
            my $sub-match = $src.substr($i) ~~ /^ [ [multi|proto|only] \s+ ]? sub \s+ /;
            my $short-match = !$sub-match && ($src.substr($i) ~~ /^ [multi|proto|only] \s+ \w+ /);
            if $sub-match || $short-match {
                my $decl-start = $i;
                my $decl-end = find-decl-end($src, $decl-start);
                my $decl-text = $src.substr($decl-start, $decl-end - $decl-start);
                my $name = extract-sub-name($decl-text);
                if $name.chars {
                    $ps.add-sub($name, $decl-text);
                    @fresh-subs.push: $name;
                }
                @out.push($decl-text);
                $i = $decl-end; next;
            }

            # 类型声明：class / role / grammar / enum（可选 our 前缀）
            if $src.substr($i) ~~ / ^ [our\s+]? [class|role|grammar|enum] \s+ / {
                my $decl-start = $i;
                my $decl-end = find-decl-end($src, $decl-start);
                my $decl-text = $src.substr($decl-start, $decl-end - $decl-start);
                my $name = extract-type-name($decl-text);
                if $name.chars && !$ps.has-type($name) {
                    $ps.add-type($name);
                    @fresh-types.push: $name;
                }
                @out.push($decl-text);
                $i = $decl-end; next;
            }
        }

        @out.push($c);
        $i++;
    }

    return (@out.join, @fresh-vars, @fresh-subs, @fresh-types);
}

# ── 构建完整 EVAL 源码 ──────────────────────────────────────────────
our sub build-eval-source(Str $transformed, PersistState $ps,
                      @fresh-vars, @fresh-subs, @fresh-types --> Str) is export {
    my Set $fresh-var-set .= new(@fresh-vars);
    my Set $fresh-sub-set .= new(@fresh-subs);
    my Set $fresh-type-set .= new(@fresh-types);

    # 1. our 变量前置声明（不含本格新声明的变量）
    my @our-decls = $ps.vars.grep({ !($_ (elem) $fresh-var-set) }).map({ "our $_;" });
    my $our-prefix = @our-decls.join("\n");

    # 2. sub 声明累积（不含本格新声明的 sub，避免同格重复声明）
    my $sub-prefix = $ps.sub-source-excluding(@fresh-subs);

    # 3. 类型别名 constant Name = OUR::Name（不含本格新声明的类型）
    my @type-aliases = $ps.types.grep({ !($_ (elem) $fresh-type-set) }).map({ "constant $_ = OUR::$_;" });
    my $type-prefix = @type-aliases.join("\n");

    my @parts;
    @parts.push: $our-prefix if $our-prefix.chars;
    @parts.push: $sub-prefix if $sub-prefix.chars;
    @parts.push: $type-prefix if $type-prefix.chars;
    @parts.push: $transformed;

    @parts.join("\n");
}

# ── 处理单个会话（stdin/stdout / socket 通用）────────────────────────
# 注意：不用 IO 类型约束，因为 $*IN/$*OUT 是 IO::Handle 而非 IO（MoarVM 类层次）
our sub process-client($in, $out, Str $session-id,
                       Bool :$enable-daemon = True --> Int) is export {
    $enable-daemon and start-daemon-if-needed(:silent);

    $out.say(to-json({ rakuish => "ready", daemon => daemon-running(),
                       session => $session-id }, :!pretty));
    $out.flush;

    my $ps        = PersistState.new;
    my Bool $watch-on = False;
    my atomicint $failed-count = 0;
    my $eval-chain = Promise.kept;
    my $result-channel = Channel.new;
    my @pending;

    sub error-hint(Str $cmd, Str $err --> Str) {
        my $first = $cmd.words[0] // q{};
        my @shell-bt = <export unset cd alias type pwd history source clear>;
        if $first eq any(@shell-bt) {
            return qq/"$first" is a shell builtin -- prefix with !/;
        }
        if $cmd ~~ / \| | \> / {
            return q[Looks like shell syntax -- prefix with !];
        }
        if $err ~~ /Undeclared\s+routine|Undefined\s+routine/ {
            return q[Name not declared. If shell cmd, prefix with !];
        }
        return q{};
    }

    sub parse-req(Str $raw --> Map) {
        if $raw.starts-with('{') && $raw.ends-with('}') {
            my %j = try { from-json($raw) };
            if %j<cmd>.defined || %j<raku>.defined || %j<shell_cmd>.defined {
                my $cmd = (%j<cmd> // %j<shell_cmd> // %j<raku>).Str;
                my $id  = %j<id>.defined ?? %j<id>.Str !! Nil;
                my $shell = %j<shell>.defined ?? Bool(%j<shell>.Int) !! Nil;
                return %(:cmd($cmd), :$id, :$shell);
            }
        }
        return %(:cmd($raw));
    }

    sub is-shell(Str $cmd --> Bool) {
        return True if $cmd.starts-with('!');
        return True if $cmd.starts-with( any('export ', 'unset ', 'cd ', 'alias ', 'type ', 'pwd', 'history') );
        return False;
    }

    sub handle-magic(Str $cmd --> Map) {
        my $body = $cmd.substr(1).trim;
        my ($name, $arg) = $body.split(/\s+/, 2);
        $name = $name.lc;
        $arg  = $arg.trim if $arg.defined;

        given $name {
            when 'eval-engine' {
                if $arg.defined && ($arg eq 'rakudo' || $arg eq 'rakupp') {
                    if $arg eq 'rakupp' {
                        my $p = rakupp-path();
                        unless $p.chars {
                            return %(:ok(False), :magic('eval-engine'),
                                      :message('rakupp not found (set RAKUPP or install to ~/.rakupp/bin/rakupp)'));
                        }
                    }
                    $EVAL-ENGINE = $arg;
                    return %(:ok(True), :magic('eval-engine'), :message("EVAL engine switched: $arg"));
                }
                return %(:ok(True), :magic('eval-engine'),
                          :message("current EVAL engine: $EVAL-ENGINE"));
            }
            when 'watch' {
                if $arg.defined {
                    $watch-on = $arg eq 'on' ?? True !! ($arg eq 'off' ?? False !! $watch-on);
                }
                return %(:ok(True), :magic('watch'), :message("watch: {$watch-on ?? 'on' !! 'off'}"));
            }
            when 'shell' {
                if $arg.defined && $arg (elem) @SHELL-BACKENDS {
                    $SHELL-BACKEND = $arg;
                    return %(:ok(True), :magic('shell'), :message("shell backend switched: $arg"));
                }
                return %(:ok(True), :magic('shell'), :message("current shell backend: $SHELL-BACKEND"));
            }
            when 'quit' | 'exit' {
                return %(:ok(True), :magic('quit'), :message('bye'), :quit(True));
            }
            default {

            # ── %config ──
            when 'config' {
                my $body = $arg.defined ?? $arg.trim !! q{};
                if $body eq q{} {
                    my %list;
                    for <shell-backend eval-engine server-port idle-timeout watch-default color auto-shell> {
                        %list{$_} = (%RC{$_} // q{(默认)}).Str;
                    }
                    return %(:ok(True), :magic('config'), :message('ok'), :values(%list));
                }
                if $body.index(q{=}).defined {
                    my ($k, $v) = $body.split(/\s* '=' \s*/, 2);
                    if known-config-key($k) {
                        if $k eq q{color} | $k eq q{auto-shell} | $k eq q{watch-default} {
                            %RC{$k} = coerce-bool($v);
                        }
                        elsif $k eq q{server-port} | $k eq q{idle-timeout} {
                            %RC{$k} = $v.Int;
                        }
                        else { %RC{$k} = $v.trim.lc }
                        if $k eq q{shell-backend} { $SHELL-BACKEND = $v.trim.lc }
                        if $k eq q{eval-engine}  { $EVAL-ENGINE   = $v.trim.lc }
                        return %(:ok(True), :magic('config'),
                                :message("{$k} = {%RC{$k}.raku}"));
                    }
                    return %(:ok(False), :magic('config'),
                            :message("未知配置项: {$k}"));
                }
                if known-config-key($body) {
                    return %(:ok(True), :magic('config'),
                            :message(%RC{$body}.Str));
                }
                return %(:ok(False), :magic('config'),
                        :message("未知配置项: {$body}"));
            }

                return %(:ok(False), :magic($name), :message("unknown magic command: %$name"));
            }
        }
    }

    my $reader = start {
        for $in.lines -> $line {
            last unless defined $line;
            my $raw = $line.Str.trim;
            next if $raw eq q{};

            my %req = parse-req($raw);
            my $cmd = %req<cmd>;
            my $id  = %req<id> // "cmd-{+@pending + 1}";

            # 只有已知的 % 魔法命令才走 magic 分支；
            # %h<c> / %hash<key> 等 Raku 哈希访问交给 EVAL。
            if $cmd.starts-with('%') {
                my $body = $cmd.substr(1).trim;
                my $mname = ($body.split(/\s+/, 2)[0] // '').lc;
                if $mname (elem) <eval-engine watch shell quit exit config edit commit cancel> {
                    my %m = handle-magic($cmd);
                    my $quit = %m<quit>:exists && %m<quit>;
                    $result-channel.send({ id => $id, ok => %m<ok>, magic => %m<magic>,
                                           message => %m<message>, shell => False, code => 0 });
                    last if $quit;
                    next;
                }
            }

            my $is-shell = %req<shell>.defined ?? %req<shell> !! is-shell($cmd);
            my $shell-cmd = $is-shell && $cmd.starts-with('!') ?? $cmd.substr(1).trim !! $cmd;

            if $is-shell {
                my $task = start {
                    my $t0 = now;
                    my $r = run-engine($shell-cmd, Hash.new, :capture(True));
                    my $elapsed = ((now - $t0) * 1000).Int;
                    $failed-count⚛++ if $r.code != 0;
                    $result-channel.send({
                        id     => $id, ok => $r.ok, code => $r.code,
                        stdout => $r.stdout, stderr => $r.stderr,
                        shell  => True, elapsed_ms => $elapsed,
                    });
                };
                @pending.push: $task;
            }
            else {
                my $prev = $eval-chain;
                $eval-chain = start {
                    await $prev;
                    my $t0 = now;

                    my ($transformed, $fresh-v, $fresh-s, $fresh-t) = transform-cell($cmd, $ps);
                    my $full-src = build-eval-source($transformed, $ps, @$fresh-v, @$fresh-s, @$fresh-t);

                    my $lex = LexState.new;   # 空 accum：只 EVAL 当前格
                    my $r = eval-cell($full-src, :state($lex), :watch($watch-on));

                    my $elapsed = ((now - $t0) * 1000).Int;
                    my %resp = (
                        id => $id, ok => $r.ok,
                        code => $r.ok ?? 0 !! 1,
                        stdout => $r.extra-output,
                        stderr => $r.error.defined ?? $r.error.Str !! q{},
                        value => $r.value.defined ?? $r.value.Str !! q{},
                        shell => False, elapsed_ms => $elapsed,
                    );
                    if $watch-on && $r.watch.elems { %resp<watch> = $r.watch }
                    unless $r.ok {
                        my $hint = error-hint($cmd, $r.error.Str);
                        %resp<hint> = $hint if $hint.chars;
                    }
                    $failed-count⚛++ unless $r.ok;
                    $result-channel.send(%resp);
                };
                @pending.push: $eval-chain;
            }
        }

        await Promise.allof(@pending) if @pending;
        $result-channel.close;
    }

    for $result-channel.list -> %result {
        $out.say(to-json(%result, :!pretty));
        $out.flush;
    }

    await $reader;

    my $last-code = $failed-count > 0 ?? 1 !! 0;
    $enable-daemon and stop-daemon;
    $out.say(to-json({ rakuish => "done", exit => $last-code }, :!pretty));
    return $last-code;
}

# ── stdin/stdout 入口（bin/rakuish --json 仍走这里）─────────────────
our sub json-server-loop(--> Int) is export {
    process-client($*IN, $*OUT, 'default');
}

# ── TCP 服务端入口（多客户端常驻）────────────────────────────────────
#
# 启动一个常驻 TCP 服务器，接受多个客户端连接，每个连接获得独立的
# Raku PersistState + 独立 daemon（通过 RAKUISH_SESSION 环境变量隔离）。
#
# 协议与 --json 完全相同：客户端发一行命令 / JSON，服务端回一行 JSON。
# 不同 client 之间会话状态完全隔离，互不干扰。
#
#   raku -Ilib -e 'use Rakuish::JSONServer; serve-loop(:port<8765>)'
# 或  raku -Ilib rakuish-serve.raku --port 8765
#
# 客户端示例（Python）：
#   s = socket.socket(); s.connect(("localhost", 8765))
#   s.sendall(b'say 1+1\n'); s.shutdown(socket.SHUT_WR)
#   print(s.recv(4096))
#
# ⚠ 当前 MoarVM 版本 IO::Socket::INET.accept 存在 bug：在创建新 socket
#   对象时从 fd 读取 getsockname，拿到 0/-1 端口就抛 "Invalid port (Int)"。
#   本实现通过 NativeCall 调 libc socket/accept/read/write 绕过。

# ── 实现 serve-loop ─────────────────────────────────────────────
our sub serve-loop(Int :$port,
                   Int :$max-clients = 16,
                   Bool :$enable-daemon = True,
                   Str :$host = 'localhost' --> Int) is export {
    use Rakuish::NativeSocket;

    # 非交互模式：只有显式 RAKUISH_RC 才读 rc
    my @rc-warn;
    @rc-warn = load-rc() if (%*ENV<RAKUISH_RC> // q{}) ne q{};

    # 端口优先级: 显式参数 > rc 默认值 8765
    my $use-port = $port.defined ?? $port.Int !! (%RC<server-port> // 8765).Int;

    my int32 $srv-fd = native-listen($use-port, :$host);

    say to-json({
        rakuish     => "serve",
        url         => "tcp://{$host}:{$port}",
        max-clients => $max-clients,
        daemon      => $enable-daemon,
        protocol    => "json-lines",
    }, :!pretty);
    $*OUT.flush;

    my atomicint $client-count = 0;
    my atomicint $client-seq   = 0;
    my @pending;

    # 接受循环
    while (my int32 $fd = native-accept($srv-fd)) {
        last if $fd < 0;

        # ⚠ Raku while(my $x=...) 的 my 作用域是整个循环体（不是每轮一个新变量），
        # 所以 start {} 会 capture 同一个 $fd 变量——循环结束后所有 start 块看到的是
        # 最终值。必须在循环体内再套一个 my 来创建每轮独立的变量绑定。
        my int32 $capture-fd = $fd;

        my $n = $client-count⚛++;
        if $n >= $max-clients {
            native-write-line($capture-fd,
                to-json({ rakuish => "rejected",
                          reason  => "max-clients reached ($max-clients)" },
                        :!pretty));
            native-close($capture-fd);
            $client-count⚛--;
            next;
        }

        my $seq = ++$client-seq;
        my $session = "c{$seq}-p{$*PID}";
        my $task = start {
            my int32 $task-fd = $capture-fd;
            my $task-session  = $session;
            my %*ENV = %*ENV.clone;
            %*ENV<RAKUISH_SESSION> = $task-session;
            try { client-loop($task-fd, $task-session,
                              :enable-daemon($enable-daemon)) }
            # P2: 兜底：无论正常退出还是 crash，都清理 daemon PID 文件
            $enable-daemon and stop-daemon;
            native-close($task-fd);
            $client-count⚛--;
        };
        @pending.push: $task;
    }

    await Promise.allof(@pending) if @pending;
    native-close($srv-fd);
    return 0;
}

# ── 单个 client 处理循环（NativeCall fd 版）────────────────────────
sub client-loop(int32 $fd, Str $session, Bool :$enable-daemon = True) {
    use Rakuish::NativeSocket;

    $enable-daemon and start-daemon-if-needed(:silent);

    # 优化：BufferedReader（4KB 缓冲，比逐字节 recv 快 ~50x）
    my $reader = BufferedReader.new(:$fd);

    # ready 行 —— 与 process-client 保持一致
    native-write-line($fd, to-json(
        { rakuish => "ready", daemon => daemon-running(), session => $session },
        :!pretty));

    my $ps = PersistState.new;
    my Bool $watch-on = False;
    my atomicint $failed-count = 0;
    my $eval-chain = Promise.kept;
    my $result-channel = Channel.new;   # 留给 shell 命令用（并发）
    my @pending;

    # ── 局部子例程（与 process-client 共用同一逻辑）─────────────
    sub error-hint(Str $cmd, Str $err --> Str) {
        my $first = $cmd.words[0] // q{};
        my @shell-bt = <export unset cd alias type pwd history source clear>;
        if $first eq any(@shell-bt) {
            return qq/"$first" is a shell builtin -- prefix with !/;
        }
        if $cmd ~~ / \| | \> / {
            return q[Looks like shell syntax -- prefix with !];
        }
        if $err ~~ /Undeclared\s+routine|Undefined\s+routine/ {
            return q[Name not declared. If shell cmd, prefix with !];
        }
        return q{};
    }

    sub parse-req(Str $raw --> Map) {
        if $raw.starts-with('{') && $raw.ends-with('}') {
            my %j = try { from-json($raw) };
            if %j<cmd>.defined || %j<raku>.defined || %j<shell_cmd>.defined {
                my $cmd = (%j<cmd> // %j<shell_cmd> // %j<raku>).Str;
                my $id  = %j<id>.defined ?? %j<id>.Str !! Nil;
                my $shell = %j<shell>.defined ?? Bool(%j<shell>.Int) !! Nil;
                return %(:cmd($cmd), :$id, :$shell);
            }
        }
        return %(:cmd($raw));
    }

    sub is-shell(Str $cmd --> Bool) {
        return True if $cmd.starts-with('!');
        return True if $cmd.starts-with(
            any('export ', 'unset ', 'cd ', 'alias ', 'type ', 'pwd', 'history'));
        return False;
    }

    sub handle-magic(Str $cmd --> Map) {
        my $body = $cmd.substr(1).trim;
        my ($name, $arg) = $body.split(/\s+/, 2);
        $name = $name.lc;
        $arg  = $arg.trim if $arg.defined;

        given $name {
            when 'eval-engine' {
                if $arg.defined && ($arg eq 'rakudo' || $arg eq 'rakupp') {
                    if $arg eq 'rakupp' {
                        my $p = rakupp-path();
                        unless $p.chars {
                            return %(:ok(False), :magic('eval-engine'),
                                      :message('rakupp not found'));
                        }
                    }
                    $EVAL-ENGINE = $arg;
                    return %(:ok(True), :magic('eval-engine'),
                            :message("EVAL engine switched: $arg"));
                }
                return %(:ok(True), :magic('eval-engine'),
                          :message("current: $EVAL-ENGINE"));
            }
            when 'watch' {
                if $arg.defined {
                    $watch-on = $arg eq 'on' ?? True
                              !! ($arg eq 'off' ?? False !! $watch-on);
                }
                return %(:ok(True), :magic('watch'),
                        :message("watch: {$watch-on ?? 'on' !! 'off'}"));
            }
            when 'shell' {
                if $arg.defined && $arg (elem) @SHELL-BACKENDS {
                    $SHELL-BACKEND = $arg;
                    return %(:ok(True), :magic('shell'),
                            :message("backend: $arg"));
                }
                return %(:ok(True), :magic('shell'),
                        :message("current: $SHELL-BACKEND"));
            }
            when 'quit' | 'exit' {
                return %(:ok(True), :magic('quit'),
                        :message('bye'), :quit(True));
            }
            default {

            # ── %config ──
            when 'config' {
                my $body = $arg.defined ?? $arg.trim !! q{};
                if $body eq q{} {
                    my %list;
                    for <shell-backend eval-engine server-port idle-timeout watch-default color auto-shell> {
                        %list{$_} = (%RC{$_} // q{(默认)}).Str;
                    }
                    return %(:ok(True), :magic('config'), :message('ok'), :values(%list));
                }
                if $body.index(q{=}).defined {
                    my ($k, $v) = $body.split(/\s* '=' \s*/, 2);
                    if known-config-key($k) {
                        if $k eq q{color} | $k eq q{auto-shell} | $k eq q{watch-default} {
                            %RC{$k} = coerce-bool($v);
                        }
                        elsif $k eq q{server-port} | $k eq q{idle-timeout} {
                            %RC{$k} = $v.Int;
                        }
                        else { %RC{$k} = $v.trim.lc }
                        if $k eq q{shell-backend} { $SHELL-BACKEND = $v.trim.lc }
                        if $k eq q{eval-engine}  { $EVAL-ENGINE   = $v.trim.lc }
                        return %(:ok(True), :magic('config'),
                                :message("{$k} = {%RC{$k}.raku}"));
                    }
                    return %(:ok(False), :magic('config'),
                            :message("未知配置项: {$k}"));
                }
                if known-config-key($body) {
                    return %(:ok(True), :magic('config'),
                            :message(%RC{$body}.Str));
                }
                return %(:ok(False), :magic('config'),
                        :message("未知配置项: {$body}"));
            }

                return %(:ok(False), :magic($name),
                        :message("unknown magic: %$name"));
            }
        }
    }

    # ── 结果输出线程 ──────────────────────────────────────────
    my $writer = start {
        for $result-channel.list -> %result {
            native-write-line($fd, to-json(%result, :!pretty));
        }
    }

    # ── 主读循环 ──────────────────────────────────────────────
    my Bool $quit = False;
    while !$quit {
        # P3: Idle timeout — 30s 没新命令 → 自动断开（TCP 活着但 client 沉默）
        unless native-can-read($fd, 30000) {
            $*ERR.say("client idle timeout 30s, disconnecting session=$session");
            last;
        }
        my $line = $reader.read-line();   # BufferedReader (4KB)
        # my $line = native-read-line($fd);   # per-byte (replaced by BufferedReader)
        last if $line eq "";   # EOF / client disconnect

        my $raw = $line.trim;
        next if $raw eq q{};

        my %req = parse-req($raw);
        my $cmd = %req<cmd>;
        my $id  = %req<id> // "cmd-{+@pending + 1}";

        # ① magic 命令 → 直接内联写 socket（不走 Channel）
        if $cmd.starts-with('%') {
            my $body = $cmd.substr(1).trim;
            my $mname = ($body.split(/\s+/, 2)[0] // '').lc;
            if $mname (elem) <eval-engine watch shell quit exit config edit commit cancel> {
                my %m = handle-magic($cmd);
                $result-channel.send({
                    id => $id, ok => %m<ok>,
                    magic => %m<magic>, message => %m<message>,
                    shell => False, code => 0
                });
                $quit = %m<quit>:exists && %m<quit>;
                last if $quit;
                next;
            }
        }

        # ② shell 或 raku
        my $is-shell = %req<shell>.defined ?? %req<shell> !! is-shell($cmd);
        my $shell-cmd = $is-shell && $cmd.starts-with('!')
            ?? $cmd.substr(1).trim !! $cmd;

        if $is-shell {
            my $task = start {
                my $t0 = now;
                my $r = run-engine($shell-cmd, Hash.new, :capture(True));
                my $elapsed = ((now - $t0) * 1000).Int;
                $failed-count⚛++ if $r.code != 0;
                $result-channel.send({
                    id => $id, ok => $r.ok, code => $r.code,
                    stdout => $r.stdout, stderr => $r.stderr,
                    shell => True, elapsed_ms => $elapsed,
                });
            };
            @pending.push: $task;
        }
        else {
            # raku EVAL（串行 Promise 链）
            my $prev = $eval-chain;
            $eval-chain = start {
                await $prev;
                my $t0 = now;

                my %resp;
                try {
                    my ($tr, $fv, $fs, $ft) = transform-cell($cmd, $ps);
                    my $src = build-eval-source($tr, $ps, @$fv, @$fs, @$ft);

                    my $lex = LexState.new;
                    my $r = eval-cell($src, :state($lex), :watch($watch-on));

                    my $elapsed = ((now - $t0) * 1000).Int;
                    %resp = (
                        id => $id, ok => $r.ok,
                        code => $r.ok ?? 0 !! 1,
                        stdout => $r.extra-output,
                        stderr => $r.error.defined ?? $r.error.Str !! q{},
                        value => $r.value.defined ?? $r.value.Str !! q{},
                        shell => False, elapsed_ms => $elapsed,
                    );
                    if $watch-on && $r.watch.elems { %resp<watch> = $r.watch }
                    unless $r.ok {
                        my $hint = error-hint($cmd, $r.error.Str);
                        %resp<hint> = $hint if $hint.chars;
                    }
                    $failed-count⚛++ unless $r.ok;
                }
                if $!.defined {
                    my $elapsed = ((now - $t0) * 1000).Int;
                    my $err-msg = $!.Str;
                    %resp = (
                        id => $id, ok => False,
                        code => 1, shell => False,
                        stdout => q{},
                        stderr => $err-msg,
                        value => q{},
                        elapsed_ms => $elapsed,
                    );
                    my $hint = error-hint($cmd, $err-msg);
                    %resp<hint> = $hint if $hint.chars;
                    $failed-count⚛++;
                }
                $result-channel.send(%resp);
            };
            @pending.push: $eval-chain;
        }
    }

    # 等待所有 in-flight 任务完成，再关 channel
    await Promise.allof(@pending) if @pending;
    $result-channel.close;
    await $writer;

    my $last-code = $failed-count > 0 ?? 1 !! 0;
    $enable-daemon and stop-daemon;
    native-write-line($fd, to-json(
        { rakuish => "done", exit => $last-code }, :!pretty));
}


