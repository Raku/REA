# Rakuish::Loop —— 交互主循环
#
# 把三个组件串成一个能用的 REPL：读输入 → 判定是否续行 → 分流（magic /
# shell / Raku）→ 执行 → 渲染。
#
# ── 实测确定的三件事（MoarVM 上逐条验证过）────────────────────────────
#
# 1. **续行提示符不用求助于库。** `Prompt.read(变量prompt)` 接受任意字符串，
#    LineEditor 后端还会对它 `.chop`（去掉尾部换行）。所以想显示什么
#    提示符就传什么，**别自己加 `\n`** —— 加了会被 chop 掉。
#    `Prompt` 提供 `add-history` / `load-history` / `save-history`，
#    但 **`load-history` 在文件不存在时只 spurt 一个空文件**（不报错）。
#
# 2. **`Commands` 的 handler 约定**（读源码 + 实跑确认，五条都要记住）：
#      · handler 收到的是 **`$!tokenizer(变量line)` 的结果**（默认 `*.words`），
#        即**词列表被展开成位置参数**。用 slurpy 接：`sub (*@w) { ... }`。
#        **`sub` 后面必须有空格** —— `sub(@w) { ... }` 被解析成裸 block，
#        报 `Variable '@w' is not declared`。
#      · **整行原文在 `$*INPUT`**。要按原文判断（`!` 前缀、前导空白）就取它，
#        别指望位置参数。
#      · **`:default` 与 `:commands` 都是必填**（哪怕 `:commands` 传空表）。
#        未匹配的命令走 `$!default` —— 正好是"默认当 Raku 代码"的落点。
#      · **`:out` / `:err` 要传 IO 句柄，不是 Callable**。源码里是
#        `temp $*OUT = self.out`，传 Callable 会炸
#        （`Cannot resolve caller print(Sub:D: BOOTStr)`）。
#      · `add-command` **自动为长名建唯一前缀缩写**（`while ++变量i < 变量main.chars`），
#        所以 `%t` 能命中 `%time`；前缀不唯一时报 "Ambiguous command" 并列候选。
#        这是 IPython 的行为，不必自己实现。
#
# 3. **`Prompt.history` 返回你传给 `:history` 的那个 IO::Path**，不是历史
#    条目数组。所以历史要自己维护数组，只在保存时交给 `变量p.save-history`。
#
# 4. **rakupp 上「属性访问器与属性同名」会无限递归**。`has @.cells;` 配上
#    `method cells(--> Seq) { @.cells }` → `Too many levels of recursion`，
#    而 MoarVM 上完全正常。方法体只有一个属性读取，**代码看不出问题**。
#    所以本项目的约定：**访问器不与属性同名**（`@.cells` → `all-cells()`）。
#
# 5. **返回类型标注 (`-->`) 是跨实现最容易被抓到的地方**，两个方向都有：
#      · rakupp 不接受 `--> Seq`（实际给 `Array`）
#        → `Type check failed for return value; expected Seq but got Array`
#      · MoarVM 不接受 `--> List`（实际给 `Seq`），而 rakupp 上恰好过
#        → `expected List but got Seq (().Seq)`
#    所以本项目里**不写 Seq/List 这类容器返回标注**，只标真正稳定的
#    （Str / Bool / Int）。
#
# 6. **数组形参写 `*@x` 才是 slurpy**。`sub f(@x)` 里的 `@x` 是
#    **「一个数组参数」**（只收1 个位置参数），不是"收集剩下的" ——
#    于是 `f('a','b','c')` 报 `Too many positionals passed; expected 1 argument`，
#    而 `f(<a b c>)` 能过。内部要拼片段、要收集 words 时一律写 `*@x`。
#
# 7. **属性默认只读**。`has Bool $.should-exit` 之后 `$.should-exit = True`
#    报 `Cannot modify an immutable Bool`。要改就写 `is rw`。
#    → 这条曾被 `not ok` 计数掩盖：测试崩在中途、后面的 subtest 根本没跑，
#      而汇总脚本只数 `not ok`，于是"0 失败"却是退出码 1。
#      **退出码必须一起看**（run-all.sh 现在两个都报）。

unit module Rakuish::Loop;

use Rakuish::Incomplete;
use Rakuish::Eval;
use Rakuish::Script;   # P5-1：把规划出的格拼成整份编译单元
use Rakuish::Platform;

# Commands 只在 magic 分发时用，但**必须在模块头部 use**：
# 写在函数体里的 `require Commands` 在本版Rakudo 上不起作用 ——
# 表现为 `Commands.new(...)` 返回 `Any`（而不是 Commands），
# 于是 `变量c.process(...)` 报 "No such method 'process' for invocant of type 'Any'"。
# 同一个类在脚本顶层 `use Commands` 后new 出来是正常的。
use Commands;
use Rakuish::Slow;   # 慢档：让真 sh 跑 shell（原生层不支持的语法回退到它）
use Rakuish::Shell::Engine;   # shell 引擎客户端（默认 bash；%shell 可切）
use Rakuish::Shell::Heredoc;
use Rakuish::Shell::Session;   # 内建改会话变量（export/unset 落在这里）
use Rakuish::Result;         # P3：裸 `run 'ls'` 直接展示 .out（按结果类型分派）
use Rakuish::Builtins;         # P2：内建归宿主（cd/pwd/export/alias/type/…）   # heredoc 识别（纯逻辑）——⚠ 刻意**不** use Shell::Exec：
                               # 那个模块做裸 libc 调用，会把 REPL 进程拖进崩溃风险里
use NativeCall;
use Terminal::ANSIColor;  # ls 内建给目录列表上色（用户要求）      # cd 内建需要真正的 chdir 系统调用（两后端一致）
sub chdir-native(Str $p --> int32) is native is symbol<chdir> { * }

# ⚠ `use Rakuish::Result` 把内建的 `run` 遮蔽成了 DSL 的 `run`
#   （返回 Result 对象，不是进程）⇒ 这里**留一份内建的**，
#   跑外部进程时用它。手法与 Result.rakumod 里那一份一致。
my &CORE-RUN = &CORE::run;

# ── ANSI 颜色（终端原样透传，两实现已验证；非 tty 不影响逻辑）──
our Str $C-RESET = "\e[0m";
our Str $C-CYAN  = "\e[36m";
our Str $C-BCYAN = "\e[1m\e[36m";   # 加粗青：提示符与 Out[n] 标签
our Str $C-DIM   = "\e[90m";
our Str $C-YELLOW= "\e[33m";
our Str $C-RED   = "\e[31m";
our Str $C-GREEN = "\e[32m";
our Str $C-BOLD  = "\e[1m";
our Str $C-MAGENTA = "\e[35m";


# ── %watch 状态变量 ──
our $WATCH-ON = False;
our %WATCH-PREV = Hash.new;

# ── %perf: 累计计时 ──
our $PERF-ON = True;                        # 默认开！每格自动计时
our @PERF-HIST;                             # 每格 [index, elapsed-ms, src-preview]
our $PERF-TOTAL-MS = 0;

# ── %bt: 失败 backtrace ──
our $BT-ON = False;                         # 默认关（精简错误更好读）
# P5-1：脚本模式「一次 EVAL」期间驱动层要用到的会话句柄。
# session / lex-state 让 __script-cell__ 里的 cd、%exit、alias 落到同一个会话；
# run-script 是给 source 用的递归入口（脚本 source 脚本也走整份编译）。
# 声明必须早于 drive —— Raku 的 our 变量也要求先声明后使用。
our %SCRIPT-CTX;

# ── 命令记录高亮（回车后把输入行按词法上色，不引外部依赖）────────────
# 设计：只做"回车后命令回显"这一档（不做实时输入高亮——Prompt 行编辑器
# 没有 highlighter 钩子，实时高亮得重写行编辑器）。复用 kind-of 那套前缀
# 判别，把一行按 raku / shell / shellq / magic 分别上色：
#   · raku：注释/字符串/数字/变量/关键字
#   · shell：命令名、flag(-x/--long)、字符串
#   · magic：% 后的命令名
# 颜色全部取自本模块已有的 ANSI 常量；非 tty 时由调用方（drive）决定是否打印。

# 局部扫描辅助：跳过一个引号串（处理 \ 转义），返回 (含首尾引号的串, 新下标)
my sub scan-string(@c, Int $i, Str $q) {
    my Int $n = @c.elems;
    my Str $out = $q;
    my Int $j = $i + 1;
    while $j < $n {
        my Str $ch = @c[$j];
        if $ch eq "\\" && $j + 1 < $n {
            $out ~= "\\" ~ @c[$j + 1];
            $j += 2;
            next;
        }
        if $ch eq $q {
            $out ~= $q;
            return ($out, $j + 1);
        }
        $out ~= $ch;
        $j++;
    }
    ($out, $n)
}

# 局部扫描辅助：按配平括号吃掉一个 q[...] / q(...) / q{...}
my sub scan-bracket(@c, Int $i, Str $close) {
    my Int $n = @c.elems;
    my Str $open = @c[$i];
    my Int $j = $i + 1;
    my Int $depth = 1;
    while $j < $n && $depth > 0 {
        if @c[$j] eq $open { $depth++ }
        elsif @c[$j] eq $close { $depth-- }
        $j++;
    }
    (@c[$i..$j - 1].join(''), $j)
}

# Raku 源码按词法上色（逐字符状态机：注释/字符串优先整块吃掉，避免内部被误染）
our sub highlight-raku(Str $src, Bool :$color = False --> Str) is export {
    return $src unless $color;
    my $kw = set <my our let constant state temp has sub method multi proto
        macro rule token regex grammar if unless for while until loop repeat
        given when default with return next last redo exit die warn try catch
        CONTROL BEGIN END unit enum role class module package use require
        gather take react supply sink but does as also augment supersede
        trust hides unsafe submethod>;
    my @c = $src.comb;
    my Int $n = @c.elems;
    my Str $out = '';
    my Int $i = 0;
    while $i < $n {
        my Str $ch = @c[$i];
        if $ch eq '#' {                                   # 注释
            my Int $j = $i;
            while $j < $n && @c[$j] ne "\n" { $j++ }
            $out ~= $C-DIM ~ @c[$i..$j - 1].join('') ~ $C-RESET;
            $i = $j; next;
        }
        if $ch eq q['] {                                   # 单引号串
            my ($str, $ni) = scan-string(@c, $i, q[']);
            $out ~= $C-GREEN ~ $str ~ $C-RESET; $i = $ni; next;
        }
        if $ch eq q["] {                                   # 双引号串
            my ($str, $ni) = scan-string(@c, $i, q["]);
            $out ~= $C-GREEN ~ $str ~ $C-RESET; $i = $ni; next;
        }
        if $ch eq 'q' || $ch eq 'Q' {                      # q[...] / qq[...] / qx[...]
            my %pair = '[' => ']', '(' => ')', '{' => '}';
            my Int $j = $i + 1;
            my Str $open = $j < $n ?? @c[$j] !! '';
            if %pair{$open}:exists {
                my ($str, $ni) = scan-bracket(@c, $j, %pair{$open});
                $out ~= $C-GREEN ~ 'q' ~ $str ~ $C-RESET; $i = $ni; next;
            }
            if $open ~~ /<[a..z]>/ {                       # 带 adverb：qx[ ... ]
                my Int $k = $j;
                while $k < $n && @c[$k] ~~ /<[a..z]>/ { $k++ }
                my Str $op2 = $k < $n ?? @c[$k] !! '';
                if %pair{$op2}:exists {
                    my ($str, $ni) = scan-bracket(@c, $k, %pair{$op2});
                    $out ~= $C-GREEN ~ @c[$i..$k - 1].join('') ~ $str ~ $C-RESET;
                    $i = $ni; next;
                }
            }
            # 不是引号构造：落到下面的标识符分支
        }
        if $ch eq '$' || $ch eq '@' || $ch eq '%' || $ch eq '&' {   # 变量 / 具名形参
            my Int $j = $i + 1;
            if $j < $n && (@c[$j] eq '!' || @c[$j] eq '^' || @c[$j] eq ':'
                       || @c[$j] eq '*' || @c[$j] eq '?' || @c[$j] eq '.'
                       || @c[$j] eq '=' || @c[$j] eq '~') { $j++; }
            while $j < $n && @c[$j] ~~ /<[A..Za..z0..9_]>/ { $j++ }
            if $j < $n && (@c[$j] eq '[' || @c[$j] eq '{' || @c[$j] eq '<') {
                my Str $close = @c[$j] eq '[' ?? ']' !! @c[$j] eq '{' ?? '}' !! '>';
                my Int $depth = 1; my Int $k = $j + 1;
                while $k < $n && $depth > 0 {
                    if @c[$k] eq @c[$j] { $depth++ }
                    elsif @c[$k] eq $close { $depth-- }
                    $k++;
                }
                $j = $k;
            }
            $out ~= $C-YELLOW ~ @c[$i..$j - 1].join('') ~ $C-RESET; $i = $j; next;
        }
        if $ch ~~ /<[0..9]>/ {                              # 数字
            my Int $j = $i;
            while $j < $n && @c[$j] ~~ /<[0..9._a..zA..Z]>/ { $j++ }
            $out ~= $C-CYAN ~ @c[$i..$j - 1].join('') ~ $C-RESET; $i = $j; next;
        }
        if $ch ~~ /<[A..Za..z_]>/ {                         # 标识符 / 关键字
            my Int $j = $i;
            while $j < $n && @c[$j] ~~ /<[A..Za..z0..9_]>/ { $j++ }
            my Str $word = @c[$i..$j - 1].join('');
            if $word (elem) $kw {
                $out ~= $C-BOLD ~ $C-MAGENTA ~ $word ~ $C-RESET;
            }
            else {
                $out ~= $word;
            }
            $i = $j; next;
        }
        $out ~= $ch; $i++;                                  # 标点 / 空白 / 换行
    }
    $out
}

# shell 行（!cmd 或 `cmd`）按"命令名 / flag / 字符串"上色
our sub highlight-shell(Str $body, Bool :$color = False --> Str) is export {
    return $body unless $color;
    my @c = $body.comb;
    my Int $n = @c.elems;
    my Str $out = '';
    my Int $i = 0;
    while $i < $n && @c[$i] eq ' ' { $i++ }
    my Int $start = $i;
    while $i < $n && @c[$i] ne ' ' { $i++ }
    my Str $cmd = @c[$start..$i - 1].join('');
    $out ~= ' ' x $start if $start > 0;
    $out ~= $C-BOLD ~ $C-GREEN ~ $cmd ~ $C-RESET;
    while $i < $n {
        my Str $ch = @c[$i];
        if $ch eq q['] || $ch eq q["] {
            my ($str, $ni) = scan-string(@c, $i, $ch);
            $out ~= $C-GREEN ~ $str ~ $C-RESET; $i = $ni; next;
        }
        if $ch eq ' ' { $out ~= ' '; $i++; next; }
        if $ch eq '-' {                                     # flag：-x / --long
            my Int $j = $i;
            while $j < $n && @c[$j] ne ' ' { $j++ }
            $out ~= $C-CYAN ~ @c[$i..$j - 1].join('') ~ $C-RESET; $i = $j; next;
        }
        $out ~= $ch; $i++;
    }
    $out
}

# magic 行：% 后的命令名加粗青
our sub highlight-magic(Str $body, Bool :$color = False --> Str) is export {
    return $body unless $color;
    my @c = $body.comb;
    my Int $n = @c.elems;
    my Int $i = 0;
    while $i < $n && @c[$i] eq ' ' { $i++ }
    my Int $start = $i;
    while $i < $n && @c[$i] ne ' ' { $i++ }
    my Str $name = @c[$start..$i - 1].join('');
    my Str $rest = $i < $n ?? @c[$i..$n - 1].join('') !! '';
    $C-BCYAN ~ $name ~ $C-RESET ~ $rest
}

# 按前缀把一行派发给对应上色器（与 kind-of 同源但独立，显示更准）
our sub highlight-command(Str $src, Bool :$color = False --> Str) is export {
    return $src unless $color;
    my Str $t = $src.trim;
    if $t.starts-with(chr(96))     { return highlight-shell(strip-backticks($src), :$color); }
    if $t.starts-with('!')         { return highlight-shell(strip-prefix($src),   :$color); }
    if $t.starts-with('%')         { return highlight-magic(strip-prefix($src),    :$color); }
    highlight-raku($src, :$color)
}

# 命令记录：In[n] 前缀 + 上色后的命令体（仅在开启颜色时由 drive 打印）
our sub command-record(Int $index, Str $src, Bool :$color = False --> Str) is export {
    my Str $prefix = $color ?? ($C-DIM ~ 'In[' ~ $index ~ '] ' ~ $C-RESET)
                        !! ('In[' ~ $index ~ '] ');
    $prefix ~ highlight-command($src, :$color)
}


# ── Ctrl-C 处理 ─────────────────────────────────────────────────────
# 两套实现上都实测过（见 tmp 里的 SIGINT 探针）：MoarVM 默认 SIGINT 会
# **硬杀进程**（rc=-2，try/CATCH/CONTROL 都拦不住）；而
# `signal(SIGINT).tap` 能**压制默认终止**并让我们拿到控制权 —— 回调里
# 置标志、打印 `^C`。所以：
#   · 主循环启动时 tap SIGINT，REPL 不再被 Ctrl-C 杀掉（会话保住）；
#   · `drive` 每行开头看标志：被置过就报"已中断"并清掉；
#   · `%run` 跑着的 shell 子进程与本进程同属一个前台进程组，真实终端里
#     按 Ctrl-C 时 SIGINT 会直达子进程把它真正杀掉，而本进程因已 tap 存活。
# 局限（MoarVM 限制，IPython 之外多数 REPL 的通病）：Raku 快档 cell 在
# 进程内求值，信号回调无法跨线程展开它，**死循环无法被强制中断**；
# 但 Ctrl-C 已不会丢掉会话，循环返回后会看到"已中断"提示。
our $INTERRUPTED      = False;
our $SIGNAL-INSTALLED = False;

our sub note-interrupt(--> Nil) is export {
    $INTERRUPTED = True;
    try {
        if $*ERR.defined && $*ERR.t {
            $*ERR.print("^C\n");
        }
    }
    Nil
}

our sub take-interrupt(--> Bool) is export {
    my $v = $INTERRUPTED;
    $INTERRUPTED = False;
    $v
}

our sub install-signal-handler(--> Nil) is export {
    return if $SIGNAL-INSTALLED;        # 重复装会重复 tap，必须只装一次
    $SIGNAL-INSTALLED = True;
    try {
        signal(SIGINT).tap: { note-interrupt() };
    }
    Nil
}


# ── 会话持久化（.repl 重放）──────────────────────────────────────────
# 把"会改变 workspace 状态的输入"追加进一个 transcript 文件；下次启动
# 重放它来恢复 %STORE 等跨 cell 状态。`%run`/`%quit`/`%exit`/`%help`/
# `%repl` 不记录（脚本重跑有副作用、退出/帮助无意义、%repl 是自指的元命令）。
# 文件路径可用环境变量 RAKUISH_REPL 覆盖（测试与多 workspace 用）。
our $REPLAY-FILE;        # IO::Path（open-replay 后有效）
our $REPLAY-HANDLE;      # 追加写的打开句柄
our $REPLAYING   = False;# 重放阶段置位：暂停记录，避免回环
our $REPL-ON     = True; # 记录总开关（%repl off/on 改它）

our sub replay-file-path(--> IO::Path) is export {
    if %*ENV<RAKUISH_REPL> {
        return %*ENV<RAKUISH_REPL>.IO;
    }
    my $dir = $*HOME.Str.IO.add('.rakuish');
    try { $dir.mkdir unless $dir.e; }
    $dir.add('repl.raku')
}

our sub open-replay(--> Nil) is export {
    my $p = replay-file-path();
    $REPLAY-FILE = $p;
    try { $REPLAY-HANDLE = open($p, :a, :create); }
    Nil
}

our sub close-replay(--> Nil) is export {
    try { $REPLAY-HANDLE.close } if $REPLAY-HANDLE;
    $REPLAY-HANDLE = Nil;
    Nil
}

our sub replay-lines(--> List) is export {
    my $p = $REPLAY-FILE // replay-file-path();
    return () unless $p.e;
    my $t = try { slurp($p) };
    return () if $! or !defined $t;
    my @ls = $t.lines.grep(*.trim ne q{});
    @ls.List
}

our sub should-log(Str $line --> Bool) is export {
    return False unless $REPL-ON;
    my $t = $line.trim;
    return False if $t.starts-with('%quit') || $t.starts-with('%exit')
                 || $t.starts-with('%help') || $t.starts-with('%run')
                 || $t.starts-with('%repl')
                 || $t.starts-with('%hist');
    True
}

our sub log-parts(*@parts --> Nil) is export {
    return if $REPLAYING;                  # 重放阶段不回写
    return unless $REPLAY-HANDLE;
    for @parts -> $p {
        next unless should-log($p);
        try { $REPLAY-HANDLE.print($p ~ "\n"); }
    }
    Nil
}

our sub replay-status(--> Hash) is export {
    my $n = 0;
    my $p = $REPLAY-FILE // replay-file-path();
    if $p.e {
        my $t = try { slurp($p) };
        $n = $t ?? $t.lines.grep(*.trim ne q{}).elems !! 0 if !$!;
    }
    %( path => ($REPLAY-FILE ?? $REPLAY-FILE.Str !! q{}), lines => $n, enabled => $REPL-ON )
}

our sub repl-magic(Str $line) is export {
    my @w = $line.words;
    @w.shift if @w && @w[0] eq 'repl';
    my $cmd = @w.elems ?? @w[0] !! q{};
    if $cmd eq 'off' {
        $REPL-ON = False;
        out-line("记录已关闭（本会话不再写入 .repl；%repl on 恢复）");
        return Nil;
    }
    if $cmd eq 'on' {
        $REPL-ON = True;
        out-line("记录已开启");
        return Nil;
    }
    if $cmd eq 'clear' {
        try {
            if $REPLAY-FILE && $REPLAY-FILE.e {
                $REPLAY-FILE.spurt(q{});
                try { $REPLAY-HANDLE.close } if $REPLAY-HANDLE;
                $REPLAY-HANDLE = open($REPLAY-FILE, :a, :create);
            }
        }
        out-line("已清空 .repl 记录");
        return Nil;
    }
    my $st = replay-status();
    out-line("会话记录: " ~ ($st<enabled> ?? "开启" !! "关闭"));
    out-line("  路径: " ~ $st<path>);
    out-line("  已记录: " ~ $st<lines> ~ " 条输入");
    out-line("  %repl off 关闭 · %repl on 开启 · %repl clear 清空");
    Nil
}

our $MAGIC-PREFIX  = q{%};
our $SHELL-PREFIX = q{!};
our $BACKTICK      = q{`};   # 反引号包裹：把 shell 命令的输出捕获为值（bash 式 `cmd`）

# ── 输入分类 ─────────────────────────────────────────────────────────
# 返回 'magic' / 'shell' / 'raku'。**只看第一个非空白字符**——
# 判别必须廉价且无歧义，自动判别本身就是歧义源（`print` 是 Raku 内建
# 还是 `lpr`？）。所以照抄 IPython：显式前缀，不猜。
our sub kind-of(Str $line --> Str) is export {
    my $t = $line.trim;
    if $t.starts-with($MAGIC-PREFIX) {
        # 只把"已知的 6 个 magic"当 magic；其余以 % 开头的（如 %STORE{...} = ...，
        # 跨 cell 状态的主 API）一律当 Raku 求值。否则 %STORE 会被误判成
        # "未知 magic" 而求不了值——这是早期版本的真实 bug。
        my $name = ($t.substr(1).words[0] // q{});
        return 'magic' if $name eq 'help' || $name eq 'time' || $name eq 'load'
                      || $name eq 'run' || $name eq 'quit' || $name eq 'repl'
                      || $name eq 'exit' || $name eq 'hist' || $name eq 'shell'
                      || $name eq 'engine' || $name eq 'inspect' || $name eq 'trace' || $name eq 'watch' || $name eq 'perf' || $name eq 'bt';
        return 'raku';
    }
    return 'shell' if $t.starts-with($SHELL-PREFIX);
    return 'shellq' if $t.starts-with($BACKTICK) && $t.chars > 1
                   && $t.ends-with($BACKTICK);
    'raku'
}

# 去掉前缀得到命令体。magic 后面可能还带参数（`%load f.txt`），
# 所以只去前缀、不动其余部分。
# `ls` / `ll` 内建（不带 flag 时列目录、上色）。带 flag 的交给真 ls。
# `ls` / `ll` 内建：这一格是不是 ls？**参数是什么？**
#
# ⚠⚠ 参数必须**返回出来**，不能指望 `$0` 往外传：
#   match 对象变量（`$0`）是**词法作用域**的 —— 在本 sub 里做匹配，
#   调用方的 `$0` **纹丝不动**（实测：调用前后都是 Nil）。
#   0.16.0（P5-1 重构）把正则从 `drive` 里抽进本 sub 之后，
#   `drive` 里的 `my $rest = ($0 // q{}).Str.trim;` 就永远拿到空串
#   ⇒ **`ls <某个文件>` 的参数被静默吃掉**，一律退化成「列当前目录」
#   （连 `ls -la` 的 flag 检查也跟着形同虚设）。0.16.5 修。
#
# 返回：不是 ls 这一格 ⇒ Nil；是 ls ⇒ 参数文本（`ls` 无参数时是空串）。
our sub ls-arg(Str $src --> Str) is export {     # Nil = 不是 ls 这一格
    # ⚠⚠ **不要用 `$0`**（match 对象变量）拿捕获组，两个坑：
    #   ① 它是**块作用域**的 —— 匹配在别的 sub 里做，调用方**拿不到**
    #      （0.16.0 起 `ls` 的参数被静默吃掉，就是这个原因）；
    #   ② 它还会被**语句修饰符**（`unless`）的块**还原** ⇒ 偶尔是 Nil
    #      （实测抛 "Use of Nil in string context"）。
    #   ⇒ 用 `match` 的**返回值**拿：`.list`（= 全部捕获组的值）。
    #   ⚠ 索引口径（实测）：`.list` / `.caps` 是**捕获组**（**不含整段匹配**），
    #     `$m[0]` = 第一个捕获组；`$m[1]` 在只有一个捕获组时是 **Nil**。
    my $m = $src.match(/^ \s* [ 'ls' | 'll' ] [ \s+ (.*?) ]? \s* $/);
    return Nil unless $m;
    my @caps = $m.list;
    return q{} if @caps.elems == 0;          # `ls`（无参数）⇒ 空串
    @caps[0].Str;
}

our sub ls-cell(Str $src --> Bool) is export {
    so ls-arg($src).defined;
}

# P5-1：这一格是不是**真的**交给 Raku 求值？
#
# 脚本模式要一次性编译整份文件，所以规划阶段必须先回答这个问题：
# 判成 Raku 的行会被原样放进编译单元；判成"宿主"的行只能换成一次
# Rakuish::Loop::__script-cell__ 调用（它们要改 cwd / %ENV / 会话状态）。
#
# ⚠ 判据必须与 drive 的分流顺序**一致**（别名 → 内建 → ls → magic/shell）：
#   判宽了，`cd /tmp` 会被当成 Raku 代码编译（语法错误）；
#   判窄了，一段合法 Raku 会被塞给 shell 引擎。
our sub is-raku-cell(Str $src --> Bool) is export {
    return False unless kind-of($src) eq 'raku';
    my Str $bare = strip-prefix($src);
    return False if expand-alias($bare) ne $bare;   # 别名展开（\`hi\` → \`echo hi\`）
    return False if builtin-name($bare) ne '';      # cd/pwd/export/alias/type/exit/source…
    return False if ls-cell($src);                  # ls/ll 内建
    True
}

our sub strip-prefix(Str $line --> Str) is export {
    my $t = $line.trim;
    for $MAGIC-PREFIX, $SHELL-PREFIX {
        return $t.substr(1) if $t.starts-with($_);
    }
    $t
}

# 反引号包裹的整行：`cmd` -> cmd。只去首尾反引号（命令体内部的反引号保留，
# 交给 sh 处理 —— 与 bash 一致）。
our sub strip-backticks(Str $line --> Str) is export {
    my $t = $line.trim;
    return $t.substr(1, $t.chars - 2)
        if $t.starts-with($BACKTICK) && $t.ends-with($BACKTICK) && $t.chars > 1;
    $t
}

# ── 块尾 else 续行（P4-1）─────────────────────────────────────────────
# 本格是否"可能在等 else"：全配平、以 `}` 收尾、且首个词是可能有 else
# 分支的构造。已经合并过 else（有以 else/elsif 开头的行）就不再探了。
our sub else-capable-block(Str $src --> Bool) is export {
    my $t = $src.trim;
    return False if $t.chars < 2;
    return False unless $t.substr($t.chars - 1, 1) eq '}';
    return False if is-incomplete($src);        # 没配平 —— 交给 needs-more
    # 已经有**裸 `else`** 分支了：else 之后不可能再接 else，不用再探。
    # `elsif` 不算终点 —— `if/elsif/else` 三段式里 elsif 后面还可能有 else。
    return False if $t ~~ / ^^ \s* 'else' /;
    my $first = $t.words[0] // q{};
    $first eq 'if' || $first eq 'unless' || $first eq 'with' || $first eq 'without';
}

# 下一行是不是"接着上一块"的续行关键字（缩进随意，后面可跟 `{`）。
our sub is-else-continuation(Str $line --> Bool) is export {
    my $t = $line.trim;
    return False if $t eq q{};
    my $w = $t.words[0] // q{};
    $w eq 'else' || $w eq 'elsif' || $w eq 'catch'
        || $w eq 'andthen' || $w eq 'orwith' || $w eq 'notandthen' || $w eq 'notwith';
}

# ── 是否需要续行 ─────────────────────────────────────────────────────
# magic 与 shell 都是单行动作，不参与续行判定。
our sub needs-more(Str $line --> Bool) is export {
    return False if kind-of($line) ne 'raku';
    # ⚠ 0.16.7（§10.1 #10）：**内建命令不参与续行判定**。
    #   `cd -` 的行尾 `-` 会被 `is-incomplete` 当成**悬空操作符**
    #   ⇒ REPL 等续行 ⇒ Ctrl-D 后打印「已取消这一块（Ctrl-D）」，
    #   `cd` 根本没执行（实测 0.16.6 及以前）。
    #   内建（cd/pwd/export/read/…）都是**单行动作**，不存在需要续行的情况。
    #   ⚠ 去掉 `%` 前缀再判（`strip-prefix`）才能拿到 `%cd -`：
    #   `kind-of` 的 magic 白名单**没有** `cd`（只有 help/time/load/run/quit/repl/exit/hist/shell/engine），
    #   所以 `%cd -` 的 kind 是 'raku'，它靠**内建通道**执行（`cd-into`，本来就认 `cd -`）。
    my Str $bare = strip-prefix($line);
    return False if builtin-name($bare) ne '';
    is-incomplete($line)
}

# ── 提示符 ───────────────────────────────────────────────────────────
# LineEditor 后端会 `.chop` 掉尾部换行，所以这里**不加 `\n`**。
our sub prompt-for(Bool $continuing, Str $cwd, Bool :$color = False --> Str) is export {
    # 续行提示符 ``....1> `` 后必须只有一个空格（LineEditor 会 chop 尾部换行，
    # 但空格要留着；测试按此精确判等）。有颜色时把空格裹进 dim 区间。
    return ($color ?? $C-DIM ~ '      ....1> ' ~ $C-RESET !! '      ....1> ') if $continuing;
    return 'rakuish:' ~ ($cwd eq q{} ?? q{} !! $cwd) ~ '> ' unless $color;
    $C-BCYAN ~ 'rakuish' ~ $C-RESET ~ ':' ~ ($cwd eq q{} ?? q{} !! $C-DIM ~ $cwd ~ $C-RESET) ~ '> '
}

# ── 把续行片段拼成完整源码 ───────────────────────────────────────────
# **每段之间必须补换行**：`sub f {` 与 `say 1;` 若粘成`sub f {say 1;}`
# 语义不同（`my 变量x = 1` 与 `1` 粘一起会变成 `my 变量x = 11`）。
our sub join-lines(*@parts --> Str) is export {
    return q{} unless @parts;
    @parts.join("\n") ~ "\n"
}

# ── 会话状态 ─────────────────────────────────────────────────────────
class Loop is export {
    has Int$!index = 0;                # 已完成的 cell 数，下一个序号 =它 +1
    # `is rw`：Raku 的属性默认**只读**，而退出状态就是要从外部改的
    has Bool  $.should-exit is rw = False;
    has Int   $.exit-code  is rw = 0;
    has @.cells;                # 每次输入的记录

    method next-index(--> Int) { $!index + 1 }
    method advance(--> Nil)    { $!index = $!index + 1 }
    # 注意：**不能**叫 `cells` —— 属性 `@.cells` 与同名无参访问器在
    # rakupp 上会无限递归（`Too many levels of recursion`，MoarVM 上正常）。
    # 方法体就一个属性读取，看不出任何问题，只能实测发现。
    method all-cells()          { @.cells }

    method record(Str $src, Bool $ok, $value, Str $err --> Nil) {
        @.cells.push: %( source => $src, ok => $ok, value => $value, error => $err );
    }

    method request-exit(Int $code --> Nil) {
        $.should-exit = True;
        $.exit-code   = $code;
    }
}

our sub loop-new(--> Loop) is export { Loop.new }

# ── 欢迎信息 ─────────────────────────────────────────────────────────
# 报出实际拿到的编辑器名—— 用户第一眼就该知道行编辑有没有生效
# （拿不到 LineEditor 会静默回落到 Readline/Fallback，体验差别很大）。
our sub welcome-text(Str $editor, Bool :$color = False --> Str) is export {
    # ASCII art 标题
    my @banner = (
        '  Rakuish',
        '  ─────────────────────────────────────',
    );
    my @banner-colored = @banner.map: -> $ln {
        $color
            ?? ($ln.starts-with('  Rakuish')
                    ?? $C-BCYAN ~ $ln ~ $C-RESET
                    !! $C-DIM ~ $ln ~ $C-RESET)
            !! $ln;
    };
    my $banner = @banner-colored.join("\n");
    my $sub   = $color ?? $C-DIM ~ 'Rakuish · 双语言交互式 REPL —— shell 脚本 + Raku 语句' ~ $C-RESET
                      !! 'Rakuish · 双语言交互式 REPL —— shell 脚本 + Raku 语句';
    $banner ~ "\n" ~ $sub ~ "\n"
    ~ '编辑器: ' ~ $editor ~ '。' ~ ($color ?? $C-GREEN ~ 'TAB 补全' ~ $C-RESET !! 'TAB 补全')
      ~ '，Ctrl-C 中断当前 cell，Ctrl-D 或 %quit 退出。' ~ "\n"
    ~ '%-magic 看命令；裸输入默认按 Raku 求值，! 或 `cmd` 跑 shell（shell 后端默认 bash）；cd / !cd / %cd 切换目录。'
}

# 设置终端窗口/标签页标题（OSC 0 转义）。非 tty 时不输出，避免污染管道与测试捕获。
our sub set-terminal-title(Str $title --> Nil) is export {
    my Bool $tty = False;
    try { $tty = $*OUT.t; }
    return unless $tty;
    $*OUT.print(chr(27) ~ ']0;' ~ $title ~ chr(7));
    Nil
}

# ── magic 命令表 ─────────────────────────────────────────────────────
# 用 Commands 承载分发：自带唯一前缀缩写（`%t` → `%time`）与歧义提示。
# 实测：`%time` 的 handler 收到词列表展开的位置参数，**`sub` 后要有空格**。
sub magic-handler($name --> Nil) {
    # `&sub` 作为 Callable 被 `变量target(@words)` 调用时，**收到的是一个 List**
    # （不是平铺的位置参数）—— 实测：签名写 `Str 变量name` 会报
    # `expected Str but got List (("help",))`。
    # 要判断命令名就取第一个元素；要整行用 `$*INPUT`。
    my $n = @($name) ?? @($name)[0] !! q{};
    # 这里是 Commands 的 handler（命名 sub：规避匿名 sub + slurpy 的 caller 解析问题）
    given $n {
        when 'help'  { magic-help() }
        when 'time'  { time-magic($*INPUT) }
        when 'load' { load-magic($*INPUT) }
        when 'quit'  { $*OUT.say(q{bye}) }
        when 'exit'  { $*OUT.say(q{bye}) }
        when 'run'   { run-magic($*INPUT) }
        when 'repl'  { repl-magic($*INPUT) }
        when 'cd'    { my $a = ($*INPUT ~~ /^ \s* 'cd' \s+ (.*?) \s* $/ ?? ~$0 !! q{}); out-line(change-dir($a)); }
        when 'hist'  { hist-magic($*INPUT) }
        when 'shell'  { shell-magic($*INPUT) }
        when 'engine'  { out-line('`%engine` 已改名为 `%shell`（后端 bash / native）；`raku` 后端已改名 `native`。') }
        when 'inspect' { inspect-magic($*INPUT) }
        when 'trace'   { trace-magic($*INPUT) }
        when 'watch'   { watch-magic($*INPUT) }
        when 'perf'      { perf-magic($*INPUT) }
        when 'bt'        { bt-magic($*INPUT) }
        default        { $*OUT.say(q{未知 magic: } ~ $*INPUT) }
    }
    Nil
}

# 当前会话（Loop 实例），供需要会话状态的 magic（%time）使用。
# 由 magic-dispatch 在每行分发前注入；REPL 单线程顺序执行，模块级变量安全。
our $CURRENT-SESSION;

our sub magic-dispatch(Str $line, :$session) is export {
    $CURRENT-SESSION = $session;

    # Commands 需要 `%*COMMANDS` 动态变量（源码里 `temp $*COMMANDS := self`），
    # 所以每次现建一个对象 —— REPL 的一行输入本来就不是热路径。
    #
    # 注意**不能写成 `Commands.new(...).process(变量line)` 的链式**：
    # 那样 `.process` 拿到的是 Any（`new` 在同类链里返回值传播有坑）。
    # 拆成两步。
    my $c = Commands.new(
        :commands( help => &magic-handler, time => &magic-handler,
                   load => &magic-handler, quit => &magic-handler, run => &magic-handler, repl => &magic-handler,
                   cd => &magic-handler, exit => &magic-handler, hist => &magic-handler,
                   inspect => &magic-handler, trace => &magic-handler,
                   watch => &magic-handler,
                   perf => &magic-handler, bt => &magic-handler ),
        :default(&magic-handler),
        :out($*OUT), :err($*ERR),
    );
    $c.process($line);
    Nil
}

# ── %shell：切换 shell 后端 ────────────────────────────────────────
#
#   %shell          → 显示当前 shell 后端
#   %shell bash     → 切到真 bash（默认；语义 100% 准）
#   %shell native   → 切到本项目自己实现的 Raku shell 层
#
# ⚠ 两个 shell 后端的**语义不完全一样**：bash 是完整的 bash；
#   native 后端只覆盖了一部分（数组 / case / [[ ]] / 函数还没有）。
#   切后端只是换「谁来解析这一行」，会话变量两边都互通。
our sub shell-magic(Str $line --> Nil) is export {
    my $arg = q{};
    if $line ~~ /^ \s* 'shell' \s+ (.*?) \s* $/ {
        $arg = ~$0;
    }
    $arg = $arg.trim;
    if $arg eq q{} {
        out-line('当前 shell 后端: ' ~ $SHELL-BACKEND
                 ~ '（可选: ' ~ @SHELL-BACKENDS.join(' / ') ~ '；不影响裸输入的 Raku 求值）');
        return Nil;
    }
    unless $arg (elem) @SHELL-BACKENDS {
        out-line('未知 shell 后端: ' ~ $arg
                 ~ '（可选: ' ~ @SHELL-BACKENDS.join(' / ') ~ '）');
        return Nil;
    }
    $SHELL-BACKEND = $arg;
    out-line('shell 后端已切换: ' ~ $arg ~ '（Raku 求值不受影响）');
    Nil
}

our sub magic-help(--> Nil) is export {
    my @lines = (
        'Rakuish · 命令总览',
        '═════════════════════════════════════════════════════════════',
        '',
        '输入模式（按行首第一个非空白字符判定）',
        '  %命令    魔法命令（见下）',
        '  !命令    shell：直通报文，流式输出、保留 ANSI 颜色',
        '  `命令`   反引号 shell：捕获 stdout 作为本格的值',
        '            （显示在 Out[n]，并存入 %STORE<_>）',
        '  其它     当 Raku 求值（my 变量跨行、跨格持久）',
        '            求值失败且首个词是 PATH 里的命令时，自动转交 shell',
        '            （所以 `git status` 直接打就行；关掉见 ~/.rakuishrc 的 auto-shell）',
        '',
        '魔法命令（% 后跟完整命令名；不支持缩写，以免 %h<k> 这类哈希被误判）',
        '  %help    显示本总览',
        '  %time    计时求值：%time 表达式 → Out[n] + 耗时',
        '  %load    载入文件进当前工作区：%load 文件 [-r A-B] [-s 名称]',
        '  %run     运行脚本：%run [--numbers|-n] 脚本.sh',
        '  %repl    会话记录开关：%repl [off|on|clear]',
        '  %hist    历史反查：%hist [子串] [--put] [--pick N] [--all]',
        '  %cd      切换目录：%cd [目录]（默认回家）',
        '  %shell  切换 shell 后端：%shell [bash|native]（默认 bash；不影响 Raku 求值）',
        '  %quit    退出（别名 %exit）',
        '',
        '内建命令（直接写，不经 %）',
        '  cd       切换目录（裸 cd / !cd / %cd 三种写法等价）',
        '  ls       彩色列出当前目录（!ls 则走真实 shell 并补 --color）',
        '  ll       彩色长列表（含类型字符与大小）',
        '  export   设会话变量（跨格存活）：!export NAME=值',
        '  unset    删会话变量：!unset NAME',
        '',
        '会话状态',
        '  shell 变量跨格存活：!export FOO=bar 之后 !echo $FOO → bar',
        '  同一格内也有效：!export FOO=1 && !echo $FOO',
        '  Raku 侧同名可见：%*ENV<FOO>（shell 变量会镜像过去）',
        '  export 不带参数 → 列出全部会话变量',
        '',
        '管道 / 重定向 / 顺序执行 / 命令替换（原生实现，不经 sh）',
        '  !ls | wc -l          管道',
        '  !cmd > f 2>&1       重定向（< > >> 2> 2>&1 &> 都支持）',
        '  !a && !b            a 成功才跑 b；!a || !b 是 a 失败才跑 b',
        '  !echo $(pwd)        命令替换（反引号也行）；裸位置的结果会分词',
        '  !echo *.txt         通配（含 [abc] / [a-z]）；引号内不展开',
        '  !cat <<EOF          heredoc：接着输入正文，以 EOF 行结束',
        '                      （<<\'EOF\' 不展开正文；<<-EOF 去掉行首制表符）',
        '  !echo ~user         家目录展开（查 /etc/passwd）',
        '  !echo {a,b}         brace 展开（{1..5} 区间也行；引号内不展开）',
        '  !echo $?            上一条命令的退出码（每条 pipeline 都更新）',
        '  !echo $$            本 shell 的 PID（会话内恒定）',
        '',
        '跨格状态 / 特殊变量',
        '  %STORE       跨格共享哈希（our %STORE）；%STORE<_> 是最近一次反引号捕获',
        '  store-set/get/keys   访问 %STORE 的例程',
        '  Out[n] / In[n]   第 n 格的求值结果 / 输入（仅成功才编号）',
        '  my $x        在会话内持久，后续格可直接引用',
        '',
        '配置文件',
        '  ~/.rakuishrc   key = value（# 注释）。可用：color / replay / history',
        '                / auto-shell（关掉「Raku 失败自动转交 shell」）',
        '                优先级：默认值 < 配置文件 < 环境变量（NO_COLOR 强制关颜色）',
        '',
        '快捷键',
        '  Tab       补全：路径 / 已声明的 $@%变量 / Raku 关键字 / 自定义 sub',
        '  块续行    括号 ()/[]/{} 未闭合，或行尾停在运算符上时自动续行（提示符 ....1> ）',
        '  ↑ / ↓     历史翻查（跨会话持久，~/.rakuish-history）',
        '  Ctrl-C    中断当前 cell',
        '  Ctrl-D    续行途中按 = 取消这一块回到主提示符；空闲时按 = 退出（也可 %quit）',
    );
    $*OUT.say(@lines.join("\n"));
}

# ── 慢档 ─────────────────────────────────────────────────────────────
# `!cmd` / `!cmd --numbers` 两种：
#   · 默认**直通** —— 不捕获，于是流式与原生 ANSI 都保住（这是免费��）
#   · `--numbers` 才捕获并给行号标注（加工必然失去流式，不可兼得）
# ls 走真实 shell 时补 --color=always，让 GNU ls 自己上色（仅当未显式指定 --color）。
our sub ls-colorize(Str $cmd --> Str) is export {
    my $real = $cmd.trim;
    return $real if $real eq q{} || $real.contains('--color');
    return $real unless $real eq 'ls' || $real.starts-with('ls ');
    my $sp = $real.index(' ');
    $sp.defined ?? $real.substr(0, $sp) ~ ' --color=always ' ~ $real.substr($sp + 1)
                !! $real ~ ' --color=always';
}

# ── 自动回退 shell ───────────────────────────────────────────────────
# 裸敲 `git status` / `echo hi` / `pwd` 时，用户（合理地）期望像在 fish/zsh/
# nushell 里那样直接执行。Rakuish 原本一律当 Raku 求值，于是报「未定义名称」，
# 逼人加 `!`。这里的做法是：**先照常求值，只在失败之后**才考虑转交 shell。
#
# 为什么是「先求值再回退」而不是「先看词形再决定」：
#   · 所有**能跑通**的 Raku 行行为完全不变 —— 改动只落在「原本就是错误」的输入上，
#     不会因为用户机器上碰巧装了某个同名程序就把 Raku 代码改道。
#   · shell-candidate 要求首个词是**裸命令名**（出现 `;` `,` `(` 等一律拒绝），
#     所以多语句行根本进不来，回退不会造成「Raku 侧先执行一遍、再执行一次」。
# 代价：行为依赖 PATH。同一个输入在不同机器上语义可能不同，这是显式取舍。

# 在 PATH 里找一个可执行文件；找到返回其路径，否则空串。
# 带 `/` 的名字（如 ./x.sh）直接当路径处理，不查 PATH。
our sub executable-in-path(Str $name --> Str) is export {
    return q{} unless $name.chars;
    if $name.contains(q{/}) {
        my $p = $name.IO;
        return ($p.e and $p.f and $p.x) ?? $p.Str !! q{};
    }
    for (%*ENV<PATH> // q{}).split(q{:}).grep(*.chars) -> $dir {
        my $p = $dir.IO.add($name);
        return $p.Str if $p.e and $p.f and $p.x;
    }
    q{}
}

# Raku 关键字 / 常见内建子：这些词即使碰巧在 PATH 里同名，也一律按 Raku 处理。
our @RAKU-WORDS = <my our state has does class role enum grammar token rule regex
                    sub method multi submethod constant
                    if else elsif unless with without orelse given when default
                    for loop while until repeat do
                    return last next redo try CATCH
                    use need
                    say put print get prompt
                    die warn note fail>;

# 这一行「看起来是想跑外部命令」吗？是则返回可执行文件路径，否则空串。
our sub shell-candidate(Str $src --> Str) is export {
    my $line = $src.trim;
    return q{} unless $line.chars;
    my $w = $line.words[0] // q{};
    return q{} unless $w.chars;

    # sigil 开头 —— 肯定是 Raku（变量 / 容器 / &code）
    my $c0 = $w.substr(0, 1);
    return q{} if $c0 eq q{$} or $c0 eq q{@} or $c0 eq q{%} or $c0 eq q{&};

    # 关键字 / 内建子
    return q{} if $w (elem) @RAKU-WORDS;

    # 词形：只允许命令名里会出现的字符。出现 ( ) { } [ ] ; , = ' " 等一律拒绝。
    for $w.comb -> Str $c {
        next if $c ~~ /\w/;
        return q{} unless $c eq q{-} or $c eq q{-} or $c eq q{_}
                         or $c eq q{.} or $c eq q{/} or $c eq q{+};
    }

    executable-in-path($w)
}

# 首词是 shell 前置赋值 / 裸赋值模式吗？
#   my_var=hello → 是（bash 里裸设环境变量）
#   FOO=1 cmd    → 是（bash 里临时给 cmd 注入环境变量）
#   X=y ls       → 是
#
# 安全护栏（避免把 Raku 代码误判）：
#   · 首词不含空格（shell-candidate 已经保证首词存在且是第一个 word）
#   · 必须含 '='，且 '=' 之前是合法 shell 变量名 [A-Za-z_][A-Za-z0-9_]*
#   · 不含 shell 元字符（| ; ( ) > <）—— 那些由 has-shell-ops / shell-candidate 另外处理
#   · 不是 Raku 声明（my/our/state + $var 才是，这里 VAR=value 没有 sigil）
our sub has-shell-assignment(Str $src --> Bool) is export {
    my $line = $src.trim;
    return False unless $line.chars;
    my $w = $line.words[0] // q{};
    return False unless $w.chars;

    # 首词必须含 '='
    return False unless $w.contains(q{=});

    # '=' 之后的部分不能有 shell 元字符（有则是组合语法，让 has-shell-ops 拦）
    my $eq-pos = $w.index(q{=});
    return False if $eq-pos == 0;       # =var 不可能是 shell 赋值
    my $before = $w.substr(0, $eq-pos);

    # '=' 之前必须是合法 shell 变量名
    return False unless $before ~~ /^ <[A..Z a..z _]> \w* $/;

    # sigil 开头的首词 shell-candidate 已经拒了，这里再挡一层双保险
    my $c0 = $before.substr(0, 1);
    return False if $c0 eq q{$} or $c0 eq q{@} or $c0 eq q{%} or $c0 eq q{&};

    True
}

# 整行看起来应该走 shell 吗？（组合判据：比 shell-candidate 更宽，但仍保守）
#
#   返回空串 → 不该 auto-shell
#   返回非空串 → 应该，返回值用于 [shell] 提示行的显示
#
# 判据顺序（越靠前越精确、误伤概率越低）：
#   1. shell-candidate：首词在 PATH → 返回其路径（最准，维持旧行为）
#   2. has-shell-assignment：首词是 VAR=value → 返回 "shell assignment"
#   3. 后续可加更多整行特征（未转义的 $VAR、管道等）
our sub should-auto-shell(Str $src --> Str) is export {
    my $cand = shell-candidate($src);
    return $cand if $cand.chars;

    if has-shell-assignment($src) {
        my $line = $src.trim;
        my $w = $line.words[0];
        return "shell assignment: $w";
    }

    q{}
}

# ── shell 安全转义 ─────────────────────────────────────────────
# 把字符串安全嵌进 shell 单引号：值整体用 '' 包，内部 ' 用 '\'' 转义。
# 空串返回 ''（shell 里也是空串）。
our sub shell-escape(Str $s --> Str) is export {
    return q{''} if $s eq q{};
    my $escaped = $s.subst(q{'}, q{'\''}, :g);
    q{'} ~ $escaped ~ q{'}
}

# ── shell 命令里的 {{...}} Raku 插值 ────────────────────────────────
#
#   my $repo = "my project";
#   !git clone https://github.com/user/{{$repo}}.git
#                 → !git clone https://github.com/user/'my project'.git
#
# 为什么 {{...}} 而不是 Raku 原生 {...}：`!cmd` 整行交给 bash，
# Raku 的单层 {...} 根本不会被 Raku 解释器看到。双花括号在 bash 里
# 不是语法 token（只有 expansion 会用），零冲突。
#
# 求值策略：
#   · 传了 LexState → 克隆一份（能访问已声明的 my/our/sub，
#     但求值结果不写回外层 accum —— 避免污染跨 cell 状态）
#   · 没传 → 新空 LexState（只能访问全局/动态变量）
#   · 求值失败 → 替换为空串（给 bash 继续跑）
#
# 替换前必须 shell-escape！空格、引号、重定向字符都会被 bash 解释。
our sub interpolate-raku-in-shell(Str $cmd, LexState :$state --> Str) is export {
    return $cmd unless $cmd.contains('{{');

    my $lex = $state.defined
        ?? Rakuish::Eval::LexState.new(accum => $state.accum, prev-out => $state.prev-out)
        !! Rakuish::Eval::LexState.new;

    my $result = $cmd;
    # 非贪婪匹配 {{...}}：内部分隔符必须是最靠里的 }}
    while $result ~~ / \{\{ (.*?) \}\} / {
        my $expr = $0.Str;
        my $val = q{};
        my $r = Rakuish::Eval::eval-cell($expr, :state($lex));
        if $r.ok and $r.value.defined {
            $val = shell-escape($r.value.Str);
        }
        $result = $result.subst(q{'{{' ~ $expr ~ '}}'}, $val);
    }
    $result
}

# ── shell 行的**后端前缀** ────────────────────────────────────────────
#
#   !@bash  echo hi     → 这一行用 **bash 后端**跑
#   !@native  echo hi     → 这一行用 **native 后端**跑（自研实现）
#   !      echo hi      → 用**当前后端**（`%shell` 设的那个，默认 bash）
#
# ⚠ 为什么用 `@` 起头：shell 的命令名**不可能**以 `@` 开头
#   （bash 里 `@` 是数组下标操作符，不是命令名的一部分）
#   ⇒ 这个前缀**不可能**与真实命令冲突 ✓
#
# 用途：**逐行委托** —— 某个后端不支持的写法，用另一个后端跑那一行，
#   而不用把默认后端切来切去。
#
# 返回：(后端名 q{} = 用当前后端, 命令正文)
our sub split-backend-prefix(Str $cmd --> List) is export {
    my $t = $cmd.trim;
    if $t.starts-with('@') {
        my $sp = $t.index(' ') // -1;
        if $sp > 1 {
            my $name = $t.substr(1, $sp - 1);
            if $name (elem) @SHELL-BACKENDS {
                return ($name, $t.substr($sp + 1).trim);
            }
        }
    }
    (q{}, $t)
}

# 转交 shell 时打一行标记：让用户看见「这一行被 Rakuish 判给了 shell」，
# 而不是以为自己在跑 Raku。顺带把解析到的绝对路径显示出来，方便核对。
#
# ⚠ 用**黄色**而不是暗色：这一行是「语义换了」的提示，必须一眼看见
#   （用户反馈：暗色的 `[shell]` 几乎看不见 ⇒ 以为还在跑 Raku）。
#   文本本身保持 `[shell]`（t/29 断言的就是它）。
our sub shell-note(Str $exe, Bool :$color = False --> Str) is export {
    my $tag = q{[shell] };
    $tag = $C-YELLOW ~ $tag ~ $C-RESET if $color;
    $tag ~ $exe
}

our sub shell-dispatch(Str $cmd, Hash $bodies = Hash.new,
                                             LexState :$state --> Nil) is export {
# ── C1: {{...}} Raku 插值 ── 在 bash 解释之前先过一遍插值。传克隆的 LexState
#       （能访问 my/our，但求值结果不写回外层 accum —— 避免污染跨 cell 状态）。
$cmd = interpolate-raku-in-shell($cmd, :$state) if $cmd.contains('{{');
    # 选项写**前置**：先写选项、再写命令。理由与 IPython 的 magic 一致——
    # 前缀在一行开头一眼看得见；写成末尾时分不清是选项还是
    # 要传给被调用的程序的同名参数。
    #
    # **必须用 if/else 而不是「if 里 return」** —— 两条实测差异：
    #   · MoarVM：在 if 块里 return 之后，同一 sub 里后续块的变量
    #     声明会报未声明（编译器 bug，错误却指向后续那行）
    #   · rakupp：返回类型标 Nil 时不接受 return Nil
    #     （No return arguments allowed ...）
    # → 结构化写法两边都过。
    my $want-numbers = False;
    my $real = $cmd.trim;
    # 长度按常量算，不手数 —— 我手数成 13（实际 11），把命令切成了
    # ntf ...，症状是 sh 报 "ntf: not found"，完全看不出是切多了。
    my $opt = '--numbers ';
    if $real.starts-with($opt) {
        $want-numbers = True;
        $real = $real.substr($opt.chars);
    }

    # ⚠ **逐行指定后端**：`!@bash …` / `!@native …`
    #   （`@` 起头不可能是真实命令名 ⇒ 不会与命令冲突 ✓）
    my ($backend, $body) = split-backend-prefix($real);

    # ⚠ `ls-colorize` 必须在**去掉 `--numbers` / `@bash` / `@native` 之后**做 ——
    #   否则 `! --numbers ls`、`!@bash ls` 的命令首词不是 `ls`，不会补
    #   `--color=always`（实测这两条都曾静默不上色）。
    my $shown = $body;                 # 摘要行显示原命令（不含 --color）
    $body = ls-colorize($body);

    if $want-numbers {
        # 加工路径：捕获回来，加行号。
        # 直通路径**不要读 .out** —— 那会把已经流到终端的输出变成空串。
        my $cap = run-engine($body, $bodies, :capture(True), :backend($backend));
        my $text = $cap.out;
        out-line(number-lines($text, :numbers(True))) if $text.trim ne q{};
        out-line(summary-line(q{!} ~ $shown, $cap.code)) if $cap.code != 0;
    }
    else {
        my $direct = run-engine($body, $bodies, :capture(False), :backend($backend));
        out-line(summary-line(q{!} ~ $shown, $direct.code)) if $direct.code != 0;
    }
    Nil
}

# TAB 补全。
#
# 签名里的参数直接可用，函数体里不需要额外解构。
#
# 这条我连踩四次：每次都在注释里写带变量的示例，于是注释处的变量
# 真的被插值、报未声明，而错误指向注释行、方向完全错。
# 教训：注释里不要出现带美元符号的标识符，哪怕它只是举例。
# ── cd 内建 ──────────────────────────────────────────────────────────
# 改 REPL 自己的工作目录。$*CWD 是进程级 cwd：改它后，提示符（prompt-for
# 用 $*CWD.Str）与后续 `!` shell 命令（run-shell 起的 sh -c 继承进程 cwd）
# 都会跟着变。shell 子进程里的 `cd` 改不了父进程，所以必须在这里拦截。
sub strip-quotes(Str $s --> Str) {
    my $t = $s;
    if $t.chars >= 2 {
        if ($t.starts-with(q["]) && $t.ends-with(q["]))
        || ($t.starts-with(q[']) && $t.ends-with(q['])) {
            $t = $t.substr(1, $t.chars - 2);
        }
    }
    $t
}

sub expand-path(Str $s --> Str) {
    my $o = $s;
    return %*ENV<HOME> // $*HOME.Str if $o eq '~';
    if $o.starts-with('~/') {
        return (%*ENV<HOME> // $*HOME.Str) ~ $o.substr(1);
    }
    # $VAR 展开（%*ENV），只做一次、不递归
    $o = $o.subst(:g, /\$ (<[_A..Za..z]><[_A..Za..z0..9]>*) /,
                   -> $/ { %*ENV{$0} // q{} });
    $o
}

our sub change-dir(Str $target, Bool :$color = False --> Str) is export {
    my $raw = strip-quotes($target.trim);
    # ⚠ 0.16.7（§10.1 #10）：`cd -` —— 回上一个目录（bash 行为）。
    #   以前只有 `Builtins.cd-into`（裸 `cd` / `!cd` / 脚本那条路）认 `-`，
    #   `%cd` 不认 ⇒ **同一个 shell 语义两套结果**。
    #   报错措辞与 `cd-into` 逐字一致（0.16.4 的 C1 定的口径）。
    my $here = $*CWD.absolute.Str;
    if $raw eq '-' {
        my $old = (%*ENV<OLDPWD> // q{});
        if $old eq q{} {
            return ($color ?? $C-RED !! q{})
                ~ "cd: OLDPWD 没设置"
                ~ ($color ?? $C-RESET !! q{});
        }
        $raw = $old;
    }
    $raw = '~' if $raw eq q{};                 # 无参数 → 回家目录
    my $expanded = expand-path($raw);
    # ⚠ **归一化**（0.16.3 修）：上面拼出来的是**字面路径**，会带 `..` 与重复斜杠
    #   （`cd ..` ⇒ `/home/zby/..`；`cd ../..` ⇒ `/home/zby/../..//..`）——
    #   拿它当 cwd，提示符、`pwd`、`PWD` 就一直挂着脏路径（用户实测截图）。
    #   `.resolve` 消掉 `.` / `..` / 重复斜杠，并把符号链接解析成实际位置
    #   （与内核 chdir 的落点一致）。解析不了就原样返回（目标不存在由 `.d` 兜底）。
    my $raw-abs = $expanded.IO.is-absolute ?? $expanded.IO !! $*CWD.add($expanded);
    my $abs = (try $raw-abs.resolve) // $raw-abs;
    # ⚠ 0.16.4：**三段式**报错，与 `Builtins.cd-into`（REPL 裸 `cd` / 脚本那条路）
    #   **逐字一致** —— 以前这里是「不是目录或不存在」一句带过，于是同一个错误
    #   有两套说法（`cd /nope` 报「没有这个目录」，`%cd /nope` 报「不是目录或不存在」），
    #   用户会以为碰到的不是同一个错。措辞以 `cd-into` 那份为准（它分得最细）。
    unless $abs.e {
        return ($color ?? $C-RED !! q{})
            ~ "cd: 没有这个目录：{$expanded}"
            ~ ($color ?? $C-RESET !! q{});
    }
    unless $abs.d {
        return ($color ?? $C-RED !! q{})
            ~ "cd: 不是目录：{$expanded}"
            ~ ($color ?? $C-RESET !! q{});
    }
    # 真正的 chdir 系统调用：MoarVM 上 $*CWD= 会顺带 chdir，rakupp 上不会，
    # 故两后端统一用 native chdir 切换进程目录，再同步 $*CWD 变量供提示符显示
    # ⚠ 同步的是**归一化后**的 `$abs`（0.16.3 起）—— 以前同步的是拼出来的字面路径，
    #   于是提示符会一直显示 `/home/zby/..` 这种脏路径。
    my $rc = chdir-native($abs.Str);
    if $rc != 0 {
        return ($color ?? $C-RED !! q{})
            ~ "cd: 进不去：{$expanded}"
            ~ ($color ?? $C-RESET !! q{});
    }
    $*CWD = $abs;   # 同步变量（rakupp 上 $*CWD= 不改进程目录，仅更新变量）

    # ⚠ 0.16.7（§10.1 #10）：**同步 PWD / OLDPWD**（与 `cd-into` 一致）。
    #   以前 `change-dir` 从不碰这两个 ⇒ 引擎（**每条命令重新 spawn**，
    #   靠 `--env-in` / `--env-out` 传状态）看到的 `$PWD` 一直是**旧的**，
    #   `cd -` 更是压根不认。
    #   ⚠ 用**动态 key** 赋值（字面 key 在 rakupp 上会静默失效 —— 与 cd-into 同理）。
    my $k-old = 'OLDPWD';
    my $k-pwd = 'PWD';
    %*ENV{$k-old} = $here;
    %*ENV{$k-pwd} = $abs;

    return ($color ?? $C-GREEN !! q{})
        ~ "cd → " ~ $*CWD.Str
        ~ ($color ?? $C-RESET !! q{});
}

# ── ls / ll 彩色内建 ───────────────────────────────────────────────
# 用户觉得 ls 纯白太丑：用 Terminal::ANSIColor 给目录项按类型上色。
# 仅拦截裸写 ls/ll（无 !/% 前缀）；带选项的 !ls 仍走真实 shell（会补 --color=always）。
sub human-size(Int $bytes --> Str) {
    my @u = <B K M G T P>;
    my $i = 0;
    my $n = $bytes.Num;
    while $n >= 1024 && $i < @u.elems - 1 { $n /= 1024; $i++ }
    $i == 0 ?? "{$bytes}{@u[0]}" !! sprintf('%.1f%s', $n, @u[$i])
}

our sub list-dir-colored(Str $arg, Bool :$long = False, Bool :$color = False --> Str) is export {
    my $raw = strip-quotes($arg.trim);
    # ⚠ 0.16.5：目标**可以是文件** —— `ls <文件>` 打印它自己（bash 行为）。
    #   以前一律当目录处理，文件 ⇒ 报「不是目录或不存在」；
    #   而在 `drive` 那一层参数还没传进来之前，更是直接列当前目录。
    my $exp = $raw eq q{} ?? q{} !! expand-path($raw);
    my $target = $exp eq q{}
        ?? $*CWD
        !! do {
            my $e = $exp.IO;
            $e.is-absolute ?? $e !! $*CWD.add($e)
        };
    unless $target.e {
        return ($color ?? $C-RED !! q{}) ~ "ls: 没有这个文件或目录：{$exp}"
             ~ ($color ?? $C-RESET !! q{});
    }
    # 每行 = [IO::Path, 显示名]
    my @rows;
    if $target.d {
        for $target.dir
            .grep(-> $e { !$e.basename.starts-with(q{.}) })
            .sort(*.basename) -> $e {
            @rows.push([$e, $e.basename]);
        }
        if @rows.elems == 0 {
            return ($color ?? $C-DIM !! q{}) ~ "(空目录)" ~ ($color ?? $C-RESET !! q{});
        }
    }
    else {
        # 文件 / 符号链接：打印**它自己**。显示用户写的那个路径（与 bash 一致：
        # `ls /tmp/x.txt` 打印 `/tmp/x.txt`，不是 `x.txt`）。
        @rows.push([$target, $exp]);
    }
    my @lines;
    for @rows -> $row {
        my ($e, $name) = $row;
        my ($c, $glyph);
        if $e.l { $c = 'cyan';           $glyph = '@' }
        elsif $e.d { $c = 'bold blue'; $glyph = '/' }
        elsif $e.x { $c = 'bold green'; $glyph = '*' }
        else        { $c = 'reset';         $glyph = q{} }
        my $disp = $name ~ $glyph;
        if $long {
            my $t = $e.l ?? 'l' !! $e.d ?? 'd' !! '-';
            my $size = $e.f ?? human-size($e.s) !! q{};
            $disp = "$t " ~ $disp ~ ($size ?? "  $size" !! q{});
        }
        @lines.push($color ?? colored($disp, $c) !! $disp);
    }
    @lines.join("\n")
}

# ── Raku 侧补全：关键字 + 作用域变量 ────────────────────────────────
# complete-at 是被 Prompt 以**固定签名** (line, pos) 回调的，拿不到 drive 里
# 那个 LexState 实例。所以用模块级 $SCOPE-SOURCE 做通道：drive 每次求值后把
# LexState.accum 同步过来；补全时按需解析并缓存（源码没变就不重扫）。
#
# 为什么**不做前缀缩写**给 magic 的教训同样适用于这里：kind-of 靠全名门控
# 来保护 `%STORE` / `%h<k>` 这类用户哈希不被误判，所以补全只在明确语境
# （行首无前缀 = Raku）里加关键字，不会去猜 `%` 后面是什么。

our Str $SCOPE-SOURCE is export = q{};
our Str $SCOPE-PARSED = "\x00";     # 哨兵：与 $SCOPE-SOURCE 不等 → 首次必解析
our $SCOPE-VARS is export = ();      # List，带 sigil 的变量名
our $SCOPE-SUBS  is export = ();     # List，用户定义的例程名

# 常用关键字 / 类型 / 内建子（裸名补全用）。刻意保持精选：全量关键字表
# 会让补全列表变成噪声，而 REPL 里高频的就是这些。
our @RAKU-KEYWORDS = <
    if else elsif unless with without orelse
    given when default
    for loop while until repeat do
    my our state has does class role enum grammar token rule regex proto
    sub method multi submethod constant
    return last next redo try CATCH
    use need
    say put print get prompt
    die warn note fail
    is also but temp leave
    Int Num Str Bool Complex Rat List Array Hash Seq Map Pair Range Junction
    Callable Any Nil True False Whatever Star
>;

sub is-sigil(Str $c --> Bool) { $c eq q{$} || $c eq q{@} || $c eq q{%} }

# 从 $src 的 $k 处读一个标识符 → (名字, 结束下标)；不是标识符返回 ()。
# 用一次正则定位而不是逐字符 while：累积缓冲可能很长，逐字符测试在两个
# 实现上都明显慢。
#
# 刻意只用 \w，**不**把 '-' / '\'' 放进字符类，两个原因（都实测踩过）：
#   1. 字符类里的**裸撇号会被 Raku 当成引号构造的起点**，于是正则扫到后面
#      某个 ' 才闭合 → 报 "couldn't find final \""，而错误位置指向几百行
#      之后一个无辜的注释，极难定位（踩过一次，报在 `# ... ('$name')` 上）。
#   2. 写成 `\w\x27\-` 或 `\w\-` 能过编译，但两后端都**匹配全失败**
#      （MoarVM 报 "Unrecognized regex metacharacter -"，rakupp 静默不匹配）。
# 只用 \w 也更贴合 Raku 语义：`$foo-bar` 本来就是 `$foo - bar`（减法），
# 不是一个叫 foo-bar 的变量。
sub ident-at(Str $src, Int $k --> List) {
    return () if $k < 0 or $k >= $src.chars;
    my $m = $src.substr($k).match(/^ [\w]+ /);
    return () unless $m;
    my $name = $m.Str;
    ($name, $k + $name.chars)
}

# 声明名提取：从声明关键字**之后**的位置找出它声明的名字。
# 覆盖 my $x / my Int $x / my $!p / my $.attr / my ($a, @b)。
sub decl-at(Str $src, Int $from --> List) {
    my $n = $src.chars;
    my $k = $from;
    $k++ while $k < $n and $src.substr($k, 1) ~~ /\s/;
    return () if $k >= $n;

    # 解构：括号内逐个抓 sigil+名字
    if $src.substr($k, 1) eq q{(} {
        my @names;
        my $depth = 0;
        while $k < $n {
            my $d = $src.substr($k, 1);
            $depth++ if $d eq q{(};
            if $d eq q{)} {
                $depth--;
                last if $depth == 0;
            }
            if $depth >= 1 and is-sigil($d) {
                my $m = $k + 1;
                $m++ while $m < $n
                       and ($src.substr($m, 1) eq q{!} or $src.substr($m, 1) eq q{:});
                my @id = ident-at($src, $m);
                if @id.elems >= 2 {
                    @names.push: $d ~ @id[0];
                    $k = @id[1];
                    next;
                }
            }
            $k++;
        }
        return @names.List;
    }

    # 带类型：my Int $x —— 跳过类型标识符后若跟 sigil 才算声明
    my @t = ident-at($src, $k);
    if @t.elems >= 2 {
        my $after = @t[1];
        $after++ while $after < $n and $src.substr($after, 1) ~~ /\s/;
        $k = $after if $after < $n and is-sigil($src.substr($after, 1));
    }

    return () if $k >= $n or not is-sigil($src.substr($k, 1));
    my $m = $k + 1;
    $m++ while $m < $n
           and ($src.substr($m, 1) eq q{!} or $src.substr($m, 1) eq q{:});
    my @id = ident-at($src, $m);
    return () unless @id.elems >= 2;
    ($src.substr($k, 1) ~ @id[0]).List
}

# 词法感知扫描已求值源码，抽出「声明过的名字」。
# 跳过 '...' / "..." / # 注释：累积缓冲里注释很常见，不跳过会把注释里
# 的 my/$ 当成声明，产生幽灵补全。
our sub scan-scope(Str $src --> Hash) is export {
    my %vars; my %subs;
    my $n = $src.chars;
    my $i = 0;
    my $st = 0;                     # 0 normal | 1 '...' | 2 "..." | 3 # 注释
    my $SQ = chr(39); my $DQ = chr(34);
    my $DECL = <my our state has>;
    my $METH = <sub method>;

    while $i < $n {
        my $c = $src.substr($i, 1);
        if $st == 3 { $st = 0 if $c eq "\n"; $i++; next }
        if $st != 0 {
            $i++;
            if $st == 1 and $c eq $SQ {
                # 单引号串里 '' 是转义
                if $i < $n and $src.substr($i, 1) eq $SQ { $i++ }
                else { $st = 0 }
            }
            elsif $st == 2 and $c eq $DQ { $st = 0 }
            next;
        }
        if $c eq $SQ { $st = 1; $i++; next }
        if $c eq $DQ { $st = 2; $i++; next }
        if $c eq q{#}  { $st = 3; $i++; next }

        if $c ~~ /\w/ {
            my @id = ident-at($src, $i);
            if @id.elems >= 2 {
                my $w = @id[0];
                if $w (elem) $DECL {
                    %vars{$_} = 1 for decl-at($src, @id[1]);
                }
                elsif $w (elem) $METH {
                    my $j = @id[1];
                    $j++ while $j < $n and $src.substr($j, 1) ~~ /\s/;
                    my @nm = ident-at($src, $j);
                    %subs{@nm[0]} = 1 if @nm.elems >= 2;
                }
                $i = @id[1];
                next;
            }
        }
        $i++;
    }
    { vars => %vars.keys.sort.List, subs => %subs.keys.sort.List }
}

our sub scope-refresh() is export {
    return if $SCOPE-SOURCE eq $SCOPE-PARSED;
    my $h = scan-scope($SCOPE-SOURCE);
    $SCOPE-VARS = $h<vars>;
    $SCOPE-SUBS  = $h<subs>;
    $SCOPE-PARSED = $SCOPE-SOURCE;
}

# 作用域变量补全：sigil='$' prefix='na' → ('$name')
our sub raku-var-names(Str $sigil, Str $prefix --> List) is export {
    scope-refresh();
    my @hit = $SCOPE-VARS.grep(*.starts-with($sigil));
    @hit = @hit.grep(*.substr(1).starts-with($prefix)) if $prefix.chars;
    # %STORE 是跨格状态的主入口，值得能补出来
    if $sigil eq q{%} and q{STORE}.starts-with($prefix)
       and not @hit.grep(* eq q{%STORE}).elems {
        @hit.push: q{%STORE};
    }
    @hit.sort.List
}

# 用户定义的例程名（裸名）
our sub user-names(Str $prefix --> List) is export {
    scope-refresh();
    my @hit = $SCOPE-SUBS.grep(*.starts-with($prefix)) if $prefix.chars;
    @hit = $SCOPE-SUBS unless $prefix.chars;
    @hit.sort.List
}

our sub raku-keywords(Str $prefix --> List) is export {
    my @hit = @RAKU-KEYWORDS;
    @hit = @hit.grep(*.starts-with($prefix)) if $prefix.chars;
    @hit.sort.List
}

# 路径补全的引号处理。含空格或元字符的路径直接插进命令行会破：实测目录
# 里有 `a file with space.txt` 时，补全 `/tmp/rk comp dir/a fi` **返回空候选**
# （用户已经敲了带空格的前缀，匹配不上任何文件名），而 bash/zsh/fish 都会补成
# 引号包起来的形式。
#
# 用单引号：Raku 里只有 '' 需要转义，sh 里也是最安全的通用选择（双引号会让
# $ ` \ 继续被解释）。不需要引号的路径原样返回 —— 把普通路径也裹上引号会让
# 输出变丑，且 `change-dir` 之外的调用方未必剥引号。
our sub path-needs-quote(Str $p --> Bool) is export {
    # **不包含 `~`**：它几乎只出现在开头的屋目展开前缀，而包上引号会**阻止展开**
    # （即 `sh -c "'~/x'"` 不会展开），等于把好路径弄坏。它出现在其位时构成的异常
    # 可以用 `\` 转义，不应该由补全来代替。
    for $p.comb -> Str $c {
        return True if index(q{ '"\`$&|;<>(){}[]*?!$#}, $c).defined;
    }
    False
}

our sub quote-path(Str $p --> Str) is export {
    return $p unless path-needs-quote($p);
    q{'} ~ $p.subst(q{'}, q{''}, :g) ~ q{'}
}

# ── 补全的「词」边界 ───────────────────────────────────────
# 原来只用「最后一个空格」切词。这对**含空格的路径**是错的：实测
# `cat /tmp/rk dbg dir/pl` 被切成 `dir/pl` —— 变成相对路径、找错目录，
# 补全**一个候选都没有**（而 `/tmp/rk` 那一级是能补出来的）。
#
# 修法不是「换成另一种切法」（那会让 `say hello world` 把整行当成一个词），
# 而是**两个都试**：先按原来的空格切；只有在它**一个候选都没有**、且这一段
# 里含 `/`（说明确实在补路径）时，才再试把空格也算进词里的扩展版本。
# 用「有没有候选」来选，所以原本能补全的输入一个都不会退化。
our sub word-tries(Str $rest --> List) is export {
    # 返回每个元素为 Hash（prefix / word），**不是二元组**：实测这两个后端上
    # `my @a = ($x, $y).List` 会把完整 List **摊平**成两个字符串，取第一个就拿错了。
    # 另外**不能把 `{ ... }` 放在 `??` 后面**（Raku 会当成 Block/thunk 而不是 Hash）。
    my $sp = $rest.rindex(q{ });
    my @tries;
    my $word-start = $sp.defined ?? $sp + 1 !! 0;
    @tries.push: { prefix => $rest.substr(0, $word-start), word => $rest.substr($word-start) };

    # 后面再给出若干个「把空格也吃进词里」的扩展版本，交给调用方按「有没有候选」挑。
    # 只在整行出现路径分隔线时才尝试，否则纯多做无用事。
    return @tries unless $rest.contains(q{/});
    my $hard = q{;|&(){}[]`'=",$<>'};
    my $i = $word-start;
    my $n = 0;
    while $i > 0 and $n < 6 {
        # 跳过与当前词之间的空格
        my $seg-end = $i - 1;
        $seg-end-- while $seg-end > 0 and $rest.substr($seg-end, 1) eq q{ };
        last if $seg-end <= 0;
        # 从上一段的末尾左移到**它的起点**：每次恰好吞掉整个词。
        # （一开始逐字符左扫会停位错一格，吃掉了词尾那个字符。）
        my $k = $seg-end;
        $k-- while $k > 0
                 and $rest.substr($k, 1) ne q{ }
                 and not index($hard, $rest.substr($k, 1)).defined;
        last if $k <= 0;
        my $w = $rest.substr($k + 1);
        last if $w eq @tries[0]<word>;
        @tries.push: { prefix => $rest.substr(0, $k + 1), word => $w };
        $i = $k + 1;
        $n++;
    }
    @tries
}

# 按词收候选。返回 Hash: words=候选列表, is-path=哪些是文件路径。
# 「哪些是路径」必须精确标记：只有它们插入前才加引号，变量候选（$name/@rows）
# 加了引号就变成 '$name' 而归属错误。
our sub gather-candidates(Str $pc, Str $rest, Str $word, Bool $sp-def --> Hash) is export {
    my @words;
    my %is-path;

    if $pc eq $MAGIC-PREFIX {
        if $sp-def {
            my $cmd = $rest.words[0] // q{};
            my @f = ($cmd eq 'run' || $cmd eq 'load') ?? file-entries($word) !! ();
            @words = @f;
            %is-path{$_} = 1 for @f;
        }
        else {
            @words = <help time load quit run repl cd exit>;
        }
    }
    elsif $pc eq $SHELL-PREFIX {
        if $sp-def {
            @words = file-entries($word);
            %is-path{$_} = 1 for @words;
        }
        else {
            @words = command-candidates();
        }
    }
    else {
        # Raku 侧：作用域变量（$a/@rows/%h）+ 用户例程名 + 关键字。
        # 变量只在**带 sigil** 时补，裸词只补例程名/关键字 —— 这样
        # `%STORE{...}` 这类以 % 开头的 Raku 代码不会被关键字污染。
        my $c0 = $word.chars ?? $word.substr(0, 1) !! q{};
        my $rk = run-arg-kind($rest);
        if $rk eq 'cmd' {
            # `run 'xxx'` / `run-pipe 'xxx'` 的**首个参数**是命令名：
            # 候选 = PATH 命令 + 内建 + 别名，外加文件（脚本本身也能当命令跑）。
            # Raku 里裸词不是命令名（`run ls` 会被当成例程调用），所以这批
            # 候选**一律要加引号** —— 借 is-path 这个「插入前要引号」的通道。
            my @cmds = command-candidates();
            %is-path{$_} = 1 for @cmds;
            @words = @cmds;
            my @rf = file-entries($word);
            @words.append: @rf;
            %is-path{$_} = 1 for @rf;
            return { words => @words, is-path => %is-path };
        }
        if is-sigil($c0) {
            @words = raku-var-names($c0, $word.substr(1));
        }
        else {
            @words = user-names($word);
            @words.append: raku-keywords($word) if $word.chars;
        }
        @words.append: store-keys();
        my @f = file-entries($word);
        @words.append: @f;
        %is-path{$_} = 1 for @f;
    }

    { words => @words, is-path => %is-path }
}

our sub complete-at(Str $line, Int $where --> List) is export {
    # 锁制越界的光标位置：越界时 `substr` 会直接抛异常，整个补全崱崩了。
    my $pos = $where.defined ?? $where !! $line.chars;
    $pos = $line.chars if $pos > $line.chars;
    $pos = 0 if $pos < 0;
    my $head = $line.substr(0, $pos);
    my $post = $line.substr($pos);

    my $pc = q{};
    if $head.starts-with($MAGIC-PREFIX) { $pc = $MAGIC-PREFIX }
    elsif $head.starts-with($SHELL-PREFIX) { $pc = $SHELL-PREFIX }
    elsif $head.starts-with($BACKTICK) { $pc = $SHELL-PREFIX }   # 反引号走 shell 补全

    my $rest = $pc ?? $head.substr(1) !! $head;

    my $sp = $rest.rindex(q{ });

    my @out;
    for word-tries($rest) -> $t {
        my $pfx = $t<prefix>;
        my $w   = $t<word>;

        # 上文里可能已经敲了半个引号（`cat 'my fi`）。剥掉再匹配、输出时补回去
        # —— 以引号开头的词永远匹配不上任何文件名。
        my $pre-quote = q{};
        my $mw = $w;
        if $mw.starts-with(q{'}) or $mw.starts-with(q{"}) {
            $pre-quote = $mw.substr(0, 1);
            $mw = $mw.substr(1);
        }

        my $g = gather-candidates($pc, $rest, $mw, $sp.defined);

        # 候选遍历改成**按下标**：实测 `for $g<words> -> $c` 只迭代一次且拿到的是
        # 整个 Array（而 `.elems` 又是对的）。下标访问在两个后端上语义确定，不受这类容器奇异影响。
        # 参考不能搬迁到数组变量：`my @cand = <Array>` 在这两个后端上会把整个
        # Array 当成**一个元素**塞进去（已排锞三次）。用标量持有视图、下标访问。
        # 上文里是否已经有个未闭合的引号（`cat 'my fi`）。有的话当前面那个引号
        # 就是它自己，我们只补上**闭合**的那一个，不能再包一层引号出来
        # （否则会得到 `cat ''/path/with space.txt'` 的双引号。
        my $before = $pc ~ $pfx ~ $pre-quote;
        my $q = q{};
        if $before.chars {
            my $last = $before.substr($before.chars - 1, 1);
            $q = $last if $last eq q{'} or $last eq q{"};
        }

        my $cands = $g<words>;
        for ^$cands.elems -> $ci {
            my $c = $cands[$ci];
            next unless $c.starts-with($mw);
            # 只给**路径**加引号，且 `%magic` 分支不加：那里后面跟的是
            # `%load` / `%run` 自己要读的文件名，引号会被当成文件名的一部分。
            my $shown = $c;
            if $g<is-path>{$c} and $pc ne $MAGIC-PREFIX {
                $shown = $q.chars ?? ($c ~ $q) !! quote-path($c);
            }
            @out.push($before ~ $shown ~ $post);
        }

        # 第一种切法有候选就用它 —— 扩展切法只是**兜底**，所以原本能补全的
        # 输入不会因为这次改动退化。
        last if @out.elems;
    }
    @out.List
}

sub file-entries(Str $word --> List) {
    my ($dir-str, $base);
    my IO() $dir;
    if $word.starts-with('~') {
        # 家目录展开：~ 或 ~/... 都按绝对路径解析
        my $home = (%*ENV<HOME> // $*HOME).Str;
        my $rest = $word.substr(1);
        my $slash = $rest.rindex(q{/});
        if $slash.defined {
            $dir-str = '~' ~ $rest.substr(0, $slash + 1);
            $base = $rest.substr($slash + 1);
            $dir = ($home ~ $rest.substr(0, $slash + 1)).IO;
        }
        else {
            $dir-str = '~';
            $base = $rest;
            $dir = $home.IO;
        }
    }
    else {
        my $slash = $word.rindex(q{/});
        if $slash.defined {
            $dir-str = $word.substr(0, $slash + 1);
            $base = $word.substr($slash + 1);
        }
        else {
            $dir-str = q{};
            $base = $word;
        }
        # 绝对路径（/ 开头）直接当目录，不要被 $*CWD.add 吞掉
        $dir = $dir-str.starts-with('/') ?? $dir-str.IO
             !! ($dir-str eq q{} ?? $*CWD !! $*CWD.add($dir-str));
    }
    return () unless $dir.e && $dir.d;
    my @names = $dir.dir.map(*.basename).grep(*.starts-with($base));
    @names.map({ $dir-str ~ $_ }).List
}

# PATH 扫描结果缓存。补全每敲一个字符就会调一次，PATH 里常有几千个
# 可执行文件，每个都 stat 一遍会让补全明显发卡。
# 键用 **PATH 串**：`export PATH=…` 之后键变了，缓存自动失效，不用额外失效逻辑。
my %CMD-CACHE;

# 测试用：清掉缓存（`temp $*ENV<PATH>` 换目录后仍要重扫的场景）。
our sub reset-command-cache(--> Nil) is export {
    %CMD-CACHE = ();
    Nil
}

sub shell-command-names(--> List) {
    my $path = (%*ENV<PATH> // q{}).Str;
    return %CMD-CACHE{$path}.List if %CMD-CACHE.EXISTS-KEY($path);
    my @dirs = $path.split(q{:}).grep(*.chars);
    my %seen;
    for @dirs -> $d {
        my $p = $d.IO;
        next unless $p.e && $p.d;
        # WSL 默认会把 Windows 的 PATH 追加进来（/mnt/c/...），而 drvfs 上
        # **每个**文件都报 +x，光看可执行位会把几千个 .dll/.json 全算成命令。
        # 所以 /mnt/ 下的目录改用扩展名判定；原生 Linux 目录照旧看 +x。
        my $drvfs = $d.starts-with('/mnt/');
        for $p.dir -> $f {
            if $drvfs {
                next unless $f.f;
                my $ext = $f.extension // q{};
                next unless $ext eq q{} || $ext.lc (elem) <exe bat cmd com>;
                %seen{$f.basename} = 1;
                next;
            }
            my $ok = try { $f.f && $f.x };
            next unless $ok ~~ Bool && $ok;
            %seen{$f.basename} = 1;
        }
    }
    my @names = %seen.keys.sort.List;
    %CMD-CACHE{$path} = @names;
    @names
}

# 命令名候选：PATH + 内建 + 别名（去重保序）。`!` 行首与 `run '…'` 首参共用。
our sub command-candidates(--> List) is export {
    my @c = shell-command-names();
    @c.append: builtin-names();
    @c.append: %ALIASES.keys.sort.List;
    @c.unique.List
}

# 当前词落在 `run` 的什么位置？
#   'cmd' = run / run-pipe 的**首个参数**（补命令名）
#   'arg' = 首参之后（只补路径）
#   ''    = 不在 run 参数里，走常规 Raku 补全
# 只看光标**之前**那段文本（$rest），不看光标之后。
our sub run-arg-kind(Str $rest --> Str) is export {
    return q{} if $rest.trim eq q{};
    my @t = $rest.words;
    return q{} unless @t.elems;

    # `run(` / `run-pipe(`：括号还没收尾，整个括号里都是参数。
    # 判「填到第几个」只看有没有逗号 —— 有逗号就已经填过至少一个了。
    # （引号里的逗号会误判成 'arg'，代价是那一格少补命令名，可接受。）
    if $rest ~~ /^ \s* ['run'|'run-pipe'] '(' $<a> = (.*) $/ {
        return $<a>.Str.contains(q{,}) ?? 'arg' !! 'cmd';
    }

    my $prev = @t.elems >= 2 ?? @t[*-2] !! q{};
    return q{} unless $prev eq 'run' or $prev eq 'run-pipe';

    # 当前词带引号且引号内已有空格 ⇒ `run 'ls -l'` 已经进到第二个 shell 词，
    # 那里补命令名没意义，交给路径补全。
    my $cur = @t[*-1];
    my $q0 = $cur.substr(0, 1);
    return 'arg' if ($q0 eq q{'} or $q0 eq q{"}) and $cur.substr(1).contains(q{ });

    'cmd'
}

# ── 从一个字符串数组造出「读一行」函数（测试与脚本模式用）─────────────
# 返回的 Callable 接受提示符、忽略它，按顺序给出元素；取完返回 Nil
# （等价于 Ctrl-D）。**提示符被忽略** —— 脚本模式下没有终端，
# 提示符只是被构造出来走个形。
# 历史去重：**连续重复**的命令只留一条，对齐 bash 的 HISTCONTROL=ignoredups
# 以及 zsh / fish 的默认行为。不去重的话，连按 ↑ 会翻出一串一模一样的行。
# 非连续的重复（上一句那句相同的）仍然保留 —— 那是用户有意重复执行的。
#
# 做成纯函数而不是内联：@history 是 drive 的局部变量，内联逻辑没法单测。
our sub push-history(@hist is copy, Str $line --> List) is export {
    return @hist.List if @hist.elems and @hist[*-1] eq $line;
    # 注意用 `push` 而不是 `(@hist, $line)`：逗号表达式在这两个后端上**不摊平**
    # 数组，实测会把整个数组当成一个元素塞进去（返回 [[..], "line"] 这种嵌套）。
    @hist.push: $line;
    @hist.List
}

our sub reader-from(*@script --> Callable) is export {
    my $cursor = 0;
    # Deliberately NO `--> Str`: returning Nil once the script is exhausted is
    # part of the contract (callers test `.defined`). Declaring Str makes every
    # such call emit "Type check failed for return value; expected Str but
    # got Any" noise.
    sub (Str $prompt) {
        return Nil if $cursor >= @script.elems;
        @script[$cursor++]
    }
}

# ── 主循环的一个输入 ─────────────────────────────────────────────────
# 读一次就返回 Str；返回 Nil 表示"没东西了"（Ctrl-D 或脚本读完）。
# **做成可注入的 Callable 而不是直接在循环里调 `变量p.read`**：
# 否则主循环的判定/分流/渲染全只能在真 pty 里测 —— 而那些逻辑才是
# 值得测的部分（读一行是库的活）。`@script` 就是测试时喂进来的输入序列。
our sub drive(&read-line, Bool :$color = True,
            Bool :$auto-shell = True, Bool :$script = False,
            Loop :$session = Loop.new,
            LexState :$lex-state = LexState.new,
            Bool :$plan = False, Array :$cells --> Int) is export {
    # `:plan` 只走「读行 → 分类 → 记账」，**不执行任何东西**（P5-1 第一步）。
    # `$cells` 是调用方传进来的数组（必须是 Array：`:@cells` 会拿到副本，
    # push 进去的格子调用方看不见）。
    # `source` 会**复用**外层的会话与词法状态（bash 的 source 就是"同一会话里
    # 接着跑"：变量、my 绑定、In[n] 都应共享）。默认值只为独立调用（测试）。
    #
    # ⚠ 默认值必须写在**签名**里（`Loop :$session = Loop.new`）。
    #   不能写成函数体里的 `$session //= Loop.new` —— 带类型标注的可选参数
    #   在"没传"时值是**类型对象**（defined 为真），`//=` 于是直接跳过，
    #   后面一碰 `$session.advance` 就炸 "assign requires a concrete object"。
    my @history;
    my $line-no = 0;                # 脚本模式的物理行号（报错定位用）
    # 探测 `else` 续行时可能**多读一行**：读到不是续行的那一行要能退回去。
    # 只退一行就够（探测每次至多读一行），所以这里就是一个单槽。
    my $pending-line;               # 退回的那一行（物理行号在探测时已加过）

    # ── REPL 装饰 vs 程序输出 ──────────────────────────────────────
    # `say-ui` 只走「人看的装饰」：命令回显、Out[n] 值渲染、`↪ shell`
    # 提示、cd 提示、反引号捕获框。脚本模式（:script）把这些全静音，
    # 否则 `rakuish foo.rakuish | wc -l` 会被 Out[1] 之类灌满。
    # **程序自己的输出不走这里**：`say`/`print` 直接进 stdout，
    # 外部命令的输出由引擎进程继承终端，`$r.extra-output` 也照原样打。
    my &say-ui = $script ?? sub (Str $s --> Nil) { } !! &out-line;

    # `source` 的执行入口（注入给 Builtins，避免 Loop ←→ Builtins 循环 use）。
    # **共享** $session 与 $lex-state：source 进来的 `my $x` 在本会话里可见，
    # In[n] 也接着编号（bash 的 source 就是"同一 shell 里接着跑"）。
    # 被 source 的文件里出错 ⇒ 嵌套 drive 以非 0 返回 ⇒ 外层跟着结束
    #（脚本语义：出错即停）。
    my &source-runner = sub (Str $path --> Int) {
        # P5-1：脚本模式下 source 也走「整份一次编译」——否则被 source 的文件
        # 又回到逐格重放，G3 会在它身上原样复现。由 run-script 注入（递归调用）。
        if $script and %SCRIPT-CTX<run-script>.defined {
            return %SCRIPT-CTX<run-script>($path);
        }
        my $abs = $path.IO.is-absolute ?? $path.IO !! $*CWD.add($path);
        return 1 unless $abs.e and $abs.f;
        my @lines = $abs.lines;
        my $prev-file = $Rakuish::Eval::SOURCE-FILE;
        $Rakuish::Eval::SOURCE-FILE = $abs.absolute.Str;
        my $rc = drive(sub (Str $p) { @lines.elems ?? @lines.shift !! Nil },
                       :$color, :script(True),
                       :$lex-state($lex-state), :$session($session));
        $Rakuish::Eval::SOURCE-FILE = $prev-file;
        $rc
    };

    loop {
        # Ctrl-C 可能在上一轮 cell 求值途中被按下：标志在信号线程置位，
        # 这里在下一轮开头消费并提示，会话不丢。
        if take-interrupt() {
            say-ui(q{已中断（Ctrl-C）});
        }

        my $line;
        my $from-pending = False;
        if $pending-line.defined {
            $line = $pending-line;
            $pending-line = Nil;
            $from-pending = True;
        }
        else {
            $line = &read-line(prompt-for(False, $*CWD.Str, :color($color)));
        }
        last without $line;                        # Ctrl-D

        $line-no++ unless $from-pending;
        my $first = $line.Str;
        my $cell-line = $line-no;      # 这一格的第一行在文件里的行号
        next if $first.trim eq q{};

        # ── heredoc：shell 行带 `<<EOF` → **接着读正文行** ──
        #
        # bash 的 heredoc 正文不在命令行里 —— 它是**后续的输入行**，
        # 直到出现分隔符为止。所以 REPL 必须替用户把那些行读出来。
        #
        # ⚠ 只对 `!` 开头的 shell 行做（`kind-of` 判据）——
        #   反引号整行捕获（`` `cmd` ``）里的 heredoc 是**内层**的，
        #   正文在同一个输入流里（我们收集不到），交给 sh 处理。
        my %heredocs;
        my $hd-aborted = False;
        if kind-of($first) eq 'shell' {
            my @specs = heredoc-specs(strip-prefix($first));
            for @specs -> $spec {
                my @body;
                loop {
                    my $more = &read-line(prompt-for(True, $*CWD.Str, :color($color)));
                    if !defined $more {
                        # Ctrl-D：这一块作废（和 Raku 多行块一样）
                        $hd-aborted = True;
                        last;
                    }
                    $line-no++;
                    # ⚠ **先判断再收**：结束行**不属于**正文（bash 语义）
                    last if heredoc-end($more.Str, $spec);
                    @body.push: $more.Str;
                }
                last if $hd-aborted;
                # 正文每行都带换行（bash 语义）
                %heredocs{$spec.delim} = @body.join("\n") ~ "\n";
            }
        }
        if $hd-aborted {
            say-ui(q{已取消这一块（Ctrl-D）});
            next;
        }

        # ── 组装输入（可能是多行）──
        my @parts = $first;
        my $aborted = False;
        my Bool $probed = False;
        loop {
          while needs-more(join-lines(@parts)) {
            my $more = &read-line(prompt-for(True, $*CWD.Str, :color($color)));
            if !defined $more {
                # Ctrl-D during a continuation cancels ONLY this block and
                # returns to the main prompt. The old `last without $more`
                # dropped the whole session, so one stray `{` plus Ctrl-D meant
                # losing all accumulated state and restarting the process.
                # An abandoned block does NOT count as an input: no In[n], no
                # replay line, no cell index (we `next` before $session.advance).
                $aborted = True;
                last;
            }
            @parts.push: $more.Str;
            $line-no++;
          }
          # ── 块尾 `else` 续行（P4-1 的尾巴）──
          #
          # `if $x { ... }` 收在 `}` 上是**配平**的，光看本格源码无法判断
          # 后面还有没有 `else` / `elsif`。对拍官方 raku REPL：这类输入要
          # 等到下一行才知道结没结束（所以它的快照是"打完 `}` 还没动作"）。
          # 这里同样**只往前探一行**：
          #   是续行关键字  -> 合并进本格，回到上面的 needs-more 继续读
          #   不是          -> 退回去（$pending-line），本格照常执行
          # 只对 if/unless/with/without 这四种**可能有 else 分支**的块生效，
          # for/while 之类没有 else，仍按老行为立即执行（不拖一拍）。
          last if $aborted or $probed;
          $probed = True;
          last unless else-capable-block(join-lines(@parts));
          my $peek = &read-line(prompt-for(False, $*CWD.Str, :color($color)));
          last without $peek;                  # 读到文件尾：本格照常执行
          $line-no++;                          # 这一行确实被消费掉了
          if is-else-continuation($peek.Str) {
              @parts.push: $peek.Str;
              $probed = False;                 # 合并后可能又没收尾，再走一遍
              next;
          }
          $pending-line = $peek.Str;           # 不是续行：退回，留给下一轮
          last;
        }
        if $aborted {
            # 脚本模式：**文件读完了，这一格却还没写完** —— 绝不能静默跳过。
            # 老行为只打一句「已取消」然后 next，脚本里就成了 rc=0 + 零输出，
            # 用户完全看不出脚本被吞了（GAPS-P4 的 G2：5 个真实脚本踩中）。
            # 报「文件:行号 + 还差什么没闭合」，退出码 2（对齐 bash 的语法错误）。
            if $script {
                report-script-incomplete(join-lines(@parts), $cell-line);
                $session.request-exit(2);
                last;
            }
            say-ui(q{已取消这一块（Ctrl-D）});   # 与其他提示一样用中文
            next;
        }
        my $src   = join-lines(@parts);
        my $kind  = kind-of($src);
        my $index = $session.next-index;

        # ── P5-1 规划阶段：只记账，不执行 ──────────────────────────
        # 登记「首行行号 / 占几行 / 原文 / 是不是 Raku / heredoc 正文」，
        # 交给 Rakuish::Script::assemble 拼成一个编译单元。
        # span 的算法：探测 `else` 续行时可能**多读一行又退回**（$pending-line），
        # 那一行的行号已经加过、下一次还要复用，所以要扣掉。
        if $plan {
            my Int $span = $pending-line.defined ?? ($line-no - $cell-line)
                                                 !! ($line-no - $cell-line + 1);
            $cells.push: %( line => $cell-line, span => ($span max 1),
                            src => $src, raku => is-raku-cell($src),
                            heredocs => %heredocs );
            next;
        }

        # 命令记录高亮：回车后把这一格输入按词法着色回显（仅在开颜色时）
        say-ui(command-record($index, $src, :$color)) if $color;

        # 历史只记**首行**（记全部片段会把 `say 1;` 也存进去，
        # 上下键翻出来是碎的）。只去掉**连续重复**（对齐 bash 的
        # HISTCONTROL=ignoredups / zsh / fish 的默认行为）：上连按 ↑ 会翻出一串一模一样的行，
        # 很难用。非连续的重复（上辆提一句相同的）仍然保留。
        @history = push-history(@history, $first);

        # ── 别名展开（宿主态，P2）──────────────────────────────────
        # 放在分流之前：`hi` → `echo hello` 之后整行就该按 shell 走。
        # 只展开"简单命令"的第一词（Builtins::expand-alias 内部判据：
        # 带 `|` `;` `&&` 的行原样放过，由引擎里的 bash 自己处理别名）。
        my $bare     = strip-prefix($src);
        my $expanded = expand-alias($bare);
        if $expanded ne $bare {
            shell-dispatch($expanded, %heredocs, :state($lex-state));
            log-parts(@parts);
            $session.advance;
            next;
        }

        # ── 内建归宿主（P2）────────────────────────────────────────
        # cd / pwd / export / unset / alias / unalias / type / exit / read /
        # source / test —— 这些改的都是**会话状态**，必须由持有会话的
        # REPL 进程执行（以前交给引擎子进程，结果全丢）。
        # 裸写与 `!` 前缀都拦（`!export FOO=1` 与 `export FOO=1` 等价）；
        # 带组合语法的行（`export A=1 && echo $A`）不拦，交回引擎。
        if $kind eq 'raku' || $kind eq 'shell' {
            if builtin-name($bare) ne '' {
                my %b = dispatch($bare, :source-runner(&source-runner),
                                 :last-status(Rakuish::Shell::Session::last-status()));
                if %b<handled> {
                    my $bout = %b<out>.Str;
                    my $berr = %b<err>.Str;
                    if $berr.chars {
                        if $script { $*ERR.say($berr) }
                        else       { say-ui(($color ?? $C-RED !! q{}) ~ $berr ~ ($color ?? $C-RESET !! q{})) }
                    }
                    if $bout.chars {
                        # `ui => True` 的是「给人看的装饰」（如 `cd → /tmp`）：
                        # 脚本模式必须静音，否则 `rakuish foo.rakuish > out.txt`
                        # 里会混进 cd 的提示。
                        if %b<ui> { say-ui($bout) }
                        elsif $script { $*OUT.say($bout) }
                        else { out-line($bout) }
                    }
                    $session.record($src, %b<code> == 0, $bout, $berr);
                    Rakuish::Shell::Session::set-last-status(%b<code>);
                    log-parts(@parts);
                    if %b<quit> {
                        $session.request-exit(%b<code>);
                        last;
                    }
                    $session.advance;
                    next;
                }
            }
        }

        # ── ls/ll 内建：彩色目录列表（纯白太丑）──
        if ls-cell($src) {
            my $cmd  = $src.words[0];
            # ⚠ 参数要从 `ls-arg` **拿回来**（0.16.5 修）：
            #   以前这里写的是 `($0 // q{}).Str.trim`，而 `$0` 是词法作用域的
            #   ⇒ 抽进 `ls-cell` 之后永远是空串 ⇒ 参数被静默吃掉。
            my $rest = (ls-arg($src) // q{}).Str.trim;
            # **带 flag 就不拦**：交给真实 ls（ls-colorize 会自动补 --color=always）。
            # 内建只负责「列一个目录」这件它做得好的事；之前把 `-la`
            # 当成目录名去 list，报错的原文是 `ls: 不是目录或不存在: /tmp/-la`
            # （实测发现，且我曾在 %help 里误写过「带选项也走内建」）。
            if $rest ne q{} and $rest.starts-with(q{-}) {
                shell-dispatch($src, :state($lex-state));
                log-parts(@parts);
                $session.advance;
                next;
            }
            # ⚠ **多个目标也交给真 ls**（0.16.5）：内建只处理「一个目标」。
            #   `ls a b`、带空格的路径（`ls "my file.txt"`）都交给 bash
            #   —— 它对带引号的路径处理得更对（我们这里只是文本切分）。
            if $rest.words.elems > 1 {
                shell-dispatch($src, :state($lex-state));
                log-parts(@parts);
                $session.advance;
                next;
            }
            # ⚠ **带 glob 字符也交给真 ls**（0.16.5）：`ls *.txt` 要的是
            #   **shell 的通配**（真 ls 前面由 bash 展开），内建不会展开。
            if $rest.contains(q{*}) or $rest.contains(q{?}) or $rest.contains(q{[}) {
                shell-dispatch($src, :state($lex-state));
                log-parts(@parts);
                $session.advance;
                next;
            }
            my $out = list-dir-colored($rest, :long($cmd eq 'll'), :color($color));
            out-line($out);
            $session.record($src, True, $out, q{});
            log-parts(@parts);
            $session.advance;
            next;
        }

        if $kind eq 'magic' {
            my $cmd = strip-prefix($src);
            magic-dispatch($cmd, :session($session));
            log-parts(@parts);
            if $cmd eq q{quit} || $cmd eq q{exit} {
                $session.request-exit(0);
                last;
            }
        }
        elsif $kind eq 'shell' {
            shell-dispatch(strip-prefix($src), %heredocs, :state($lex-state));
            log-parts(@parts);
        }
        elsif $kind eq 'shellq' {
            # bash 式反引号：执行 shell，把 stdout 捕获为**本 cell 的值**，
            # 显示在 Out[n]，并存入 %STORE<_> 供后续 cell 复用。
            my $cmd = strip-backticks($src);
            # 反引号里也认后端前缀（`` `@native cmd` ``）
            my ($backend, $body) = split-backend-prefix($cmd);
            my $res = run-engine($body, :capture(True), :backend($backend));
            my $val = ($res.stdout // q{}).Str;
            $val = $val.subst(/\n+ $/, q{}, :g) if $val.chars;   # 去尾部换行
            say-ui(render-shell-capture($index, $val, :$color));
            $session.record($src, True, $val, q{});
            say-ui(summary-line("`$cmd", $res.code)) if $res.code != 0;
            store-set('_', $val) if $val.defined;
            log-parts(@parts);
        }
        else {
            # C阶段 Debug: %trace 模式下打印即将 EVAL 的完整源码
            maybe-trace-eval($src, $lex-state, $index);
            my $r = eval-cell($src, :index($index), :state($lex-state),
                              :line-base($cell-line), :watch($WATCH-ON));
            # 同步作用域源码，Raku 侧补全（关键字/变量）靠它取已声明的名字
            $SCOPE-SOURCE = $lex-state.accum;

            # ── 自动回退 shell（只在 Raku 求值失败且这一行像外部命令时）──
            my $shelled = False;
            if !$r.ok and $auto-shell {
                my $reason = should-auto-shell($src);
                if $reason ne q{} {
                    $shelled = True;
                    say-ui(shell-note($reason, :$color));
                    shell-dispatch($src, :state($lex-state));
                    log-parts(@parts);
                }
            }

            if !$shelled {
                if $r.ok {
                    # 程序输出必须原样落地：extra-output 自带行尾换行，
                    # 走 out-line 会再补一个，脚本模式就成了「每句一个空行」。
                    if $r.extra-output.chars {
                        if $script { $*OUT.print($r.extra-output) }
                        else       { out-line($r.extra-output) }
                    }
                    $session.record($src, True, $r.value, q{});
                    # %watch 模式：变量变化跟踪
                    maybe-watch-diff($r.watch // Hash.new, $index);
                    # %perf 累计：每格自动计时（默认开）
                    if $PERF-ON && $r.elapsed-ms > 0 {
                        @PERF-HIST.push: [$index, $r.elapsed-ms, $src.substr(0, 60)];
                        $PERF-TOTAL-MS += $r.elapsed-ms;
                    }
                    # 用户写了 `exit N`（P4-2）：本格该打的输出上面已经落地，
                    # 这里只负责收尾。REPL 与脚本一视同仁 —— 都结束会话，
                    # 退出码取 N（脚本靠它给 CI 传信号）。
                    if $r.exit-code.defined {
                        $session.request-exit($r.exit-code);
                        last;
                    }
                    # P3 糖：**裸** `run 'ls'` 的 Out[n] 直接给命令输出，
                    # 不套 `Result(code=… · N 行 · …)` 摘要（脚本模式不会走到
                    # 这里 —— say-ui 在脚本模式下被静音，不会自动打印值）。
                    if bare-run-src($src) and $r.value ~~ Rakuish::Result::Result {
                        say-ui(render-result-out($index, $r.value, :color($color)));
                    }
                    else {
                        say-ui(render-out($index, $r.value, :color($color)));
                    }
                }
                else {
                    # ⚠ 脚本模式（`drive(..., :script(True))`）也走这里
                    #   ⇒ 错误渲染要按脚本口径（无装饰），见 `render-error` 的 `:script`。
                    # %perf 累计（失败也要计）
                    if $PERF-ON && $r.elapsed-ms > 0 {
                        @PERF-HIST.push: [$index, $r.elapsed-ms, '✗ ' ~ $src.substr(0, 55)];
                        $PERF-TOTAL-MS += $r.elapsed-ms;
                    }
                    # %bt 开关：失败时打印完整 backtrace
                    if $BT-ON && $r.error.defined {
                        my $bt = try { $r.error.backtrace } // Nil;
                        if $bt.defined {
                            out-line("── backtrace ({$r.error.^name}) ──");
                            for $bt.list[^20] -> $fr {
                                out-line("  { $fr.Str }");
                            }
                            out-line("  … (truncated, total {$bt.elems} frames)") if $bt.elems > 20;
                        }
                    }
                    my $msg = render-error($r, :color($color), :script($script));
                    $session.record($src, False, Nil, $msg);
                    # 脚本模式的错误必须走 stderr：既符合 unix 习惯，
                    # 也让 `cmd >out.txt` 不会把报错一起收进结果文件。
                    if $script {
                        $*ERR.say($msg);
                        # 脚本不是 REPL：一行失败后继续跑下去只会把错误
                        # 拖到更远的地方爆发。出错即停、退出码 1。
                        $session.request-exit(1);
                        last;
                    }
                    else { say-ui($msg) }
                }
                log-parts(@parts) if $r.ok;
            }
        }
        $session.advance;
    }
    $session.exit-code
}

# ── P5-1：单次 EVAL 里执行一格「非 Raku」输入 ──────────────────────────
#
# Rakuish::Script 把 !cmd / %magic / cd / ls / 别名这些行改写成了对这里的
# 调用。它们必须**原地、按顺序、只执行一次** —— 否则要么 cwd 变了后面全歪，
# 要么副作用重放（G3 的原始症状：spurt 把 rename 掉的文件又造回来）。
#
# 实现上刻意**复用手 drive**：只喂它这一格（含 heredoc 正文），
# 分流 / 内建 / shell 引擎 / 错误渲染全走同一份代码。两处各判一次迟早会漂
#（`ls -la` 交给谁、别名先展开还是内建先拦，都是细活）。

our sub __script-cell__(Str $src, %heredocs = %() --> Nil) {
    my $ctx = %SCRIPT-CTX;
    # 不在脚本上下文（例如有人手写这份调用）：静默放过，不要炸掉整份脚本。
    return unless $ctx.defined and $ctx<session>.defined;

    my @lines = $src.lines;
    # heredoc 正文不在格子里（bash 语义：它在后续输入行里）。单次 EVAL 没有
    # "后续输入"可读，所以按分隔符顺序把正文与结束行**接回**行队列，
    # 让 drive 自己再走一遍收集逻辑（语义与 REPL 完全一致）。
    for heredoc-specs(strip-prefix($src)) -> $spec {
        my $body = %heredocs{$spec.delim};
        @lines.append($body.Str.lines) if $body.defined;
        @lines.push($spec.delim);
    }

    # Raku 侧的输出先落地：$*OUT 在非 tty 下常是块缓冲，不 flush 就会出现
    # "脚本里 say 的内容跑到子进程输出之后"（顺序错乱比丢输出更难查）。
    try { $*OUT.flush };
    try { $*ERR.flush };

    drive(sub (Str $p) { @lines.elems ?? @lines.shift !! Nil },
          :color(False), :auto-shell(False), :script(True),
          :session($ctx<session>), :lex-state($ctx<lex-state>));

    # `exit N` / `%quit` 是**脚本退出**，不是"这一格结束"：
    # 必须中断剩下的代码，否则 exit 之后的语句还会继续跑。
    if $ctx<session>.should-exit {
        Rakuish::Eval::ExitRequest.new(:code($ctx<session>.exit-code)).throw;
    }
    Nil
}

# ══════════════════════════════════════════════════════════════════════
# 真正的交互入口 —— 需要 tty。读终端的部分全交给 Prompt。
# 逻辑部分在 `drive` 里（可注入、可单测）。
# ══════════════════════════════════════════════════════════════════════
# ── ~/.rakuishrc 启动配置 ───────────────────────────────────────────
# 刻意做成**简单的 key = value 解析**，而不是 eval 一段 Raku：rc 在启动时执行，
# 一旦出错代价太大（REPL 起不来）；纯解析能给「��� N 行看不懂」这种人话提示，
# 而且永远不会误伤用户环境。
#
# 优先级：内置默认值 < ~/.rakuishrc < 环境变量 < 显式参数
# 环境变量：RAKUISH_RC（rc 路径）/ NO_COLOR / RAKUISH_COLOR /
#           RAKUISH_REPLAY / RAKUISH_HISTORY

our sub rc-defaults(--> Hash) is export {
    { 'color' => True, 'replay' => False, 'history' => q{}, 'auto-shell' => True }
}

our %RC is export = rc-defaults();

our sub rc-path(--> IO) is export {
    my $env = %*ENV<RAKUISH_RC>;
    return $env.Str.IO if $env.defined and $env.Str.chars;
    $*HOME.Str.IO.add(chr(46) ~ q{rakuishrc})
}

our sub known-config-key(Str $k --> Bool) is export {
    $k (elem) <color replay history auto-shell>
}

# 认不出来就当「开」——rc 是用户自己写的，宁可宽松也别静默关掉功能。
our sub coerce-bool(Str $v --> Bool) is export {
    my $t = $v.trim.lc;
    return True  if $t eq q{true}  or $t eq q{yes} or $t eq q{on}  or $t eq q{1};
    return False if $t eq q{false} or $t eq q{no}  or $t eq q{off} or $t eq q{0};
    True
}

# 去掉行尾注释，但认引号：'a#b' / "a#b" 里的 # 不是注释。
sub rc-strip-comment(Str $s --> Str) {
    my $q = q{};
    my @out;
    for $s.comb -> Str $c {
        if $q ne q{} {
            @out.push: $c;
            $q = q{} if $c eq $q;
            next;
        }
        if $c eq q{'} or $c eq q{"} { $q = $c; @out.push: $c; next }
        last if $c eq q{#};
        @out.push: $c;
    }
    @out.join
}

sub rc-unquote(Str $s --> Str) {
    my $t = $s.trim;
    return $t if $t.chars < 2;
    my $f = $t.substr(0, 1);
    return $t unless $f eq q{'} or $f eq q{"};
    return $t.substr(1, $t.chars - 2) if $t.substr($t.chars - 1, 1) eq $f;
    $t
}

# 配置名：首字符必须是字母或下划线，后面可以再带短横。
# 刻意逐字符判断而不用 /[\w-]/ 或 [A-Za-z]：字符类里的 '-' 与区间在两个
# 后端都不可靠（MoarVM 报未引用元字符，rakupp 静默失配）。
# 首字符单独拒绝数字，这样 `1bad = x` 才会被报成「配置名不合法」
# 而不是蛋的「未知配置项」。
sub is-config-key(Str $k --> Bool) {
    return False unless $k.chars;
    my $first = $k.substr(0, 1);
    return False unless $first ~~ /\w/ and $first !~~ /\d/;
    for $k.substr(1).comb -> Str $c {
        return False unless $c ~~ /\w/ or $c eq q{-};
    }
    True
}

# 一行拆成 key / value。**用 index 算，不用正则** —— rakupp 的正则引擎对
# 需要回溯的写法（如 /(\S+)\s*[=:]/）不保险，纯字符串运算两边行为一致。
sub rc-split(Str $line --> List) {
    my $eq = $line.index(q{=});
    my $co = $line.index(q{:});
    my $pos = -1;
    if $eq.defined and $co.defined { $pos = ($eq < $co ?? $eq !! $co) }
    elsif $eq.defined               { $pos = $eq }
    elsif $co.defined               { $pos = $co }
    return () if $pos < 1;
    my $key = $line.substr(0, $pos).trim;
    return () if $key eq q{};
    ($key, $line.substr($pos + 1).trim).List
}

# 解析 rc 文本 → Hash: settings / warns。纯函数：不读文件、不碰全局。
# 返回 Hash 而不是二元组：逗号表达式花帧时会把 `.List` 包裹的元素留成**嵌套
# List**（实测），解构出来的是 Pair 而不是字符串，很难查。Hash + 具名键无歧义。
our sub parse-rc(Str $text --> Hash) is export {
    # settings 用 **Hash**（key -> value 字符串）而不是「List of 二元组」
    #     —— 实测这两个后端 `for LIST-of-List -> $x` **只迭代一次**
    #     （$x 拿到整个 List；`.elems` 一样，`.list` 才对），于是下游拿到
    #     嵌套 List 并被字符串化成 "history ~/hist" 这种垃圾。
    #     扁平 Hash 完全绕开这个坑。同名 key 后写覆盖先写（符合直觉）。
    my %settings;
    my @warn;
    my $n = 0;
    for $text.lines -> $raw {
        $n++;
        my $line = rc-strip-comment($raw).trim;
        next if $line eq q{};
        my @kv = rc-split($line);
        unless @kv.elems >= 2 {
            @warn.push: "rc 第 {$n} 行看不懂：{$raw.trim}";
            next;
        }
        my ($key, $val) = @kv;
        unless is-config-key($key) {
            @warn.push: "rc 第 {$n} 行配置名不合法：{$key}";
            next;
        }
        unless known-config-key($key) {
            @warn.push: "rc 第 {$n} 行未知配置项：{$key}";
            next;
        }
        %settings{$key} = rc-unquote($val);
    }
    my %out;
    %out<settings> = %settings;
    %out<warns>   = @warn.List;
    %out
}

# 读 rc 并应用。返回警告列表而**不直接打印**：由调用方决定输出到哪个流，
# 这样单测不必去抓 stderr。
our sub load-rc(--> List) is export {
    %RC = rc-defaults();
    my $path = rc-path();
    return () unless $path.e;
    my $text = try { $path.slurp };
    if $! or not defined $text {
        return ("读不了配置文件：{$path}",);
    }
    my $h = parse-rc($text);
    my %set = $h<settings>;
    for %set.keys -> $k {
        my $v = %set{$k};
        if    $k eq q{color}   { %RC<color>   = coerce-bool($v) }
        elsif $k eq q{replay}  { %RC<replay>  = coerce-bool($v) }
        else                   { %RC<history> = $v }
    }
    $h<warns>.List
}

# 历史文件路径：rc 的 history 为空时回落 ~/.rakuish-history；支持 ~ 展开。
our sub rc-history-path(--> IO) is export {
    my $env = %*ENV<RAKUISH_HISTORY>;
    return $env.Str.IO if $env.defined and $env.Str.chars;
    my $h = (%RC<history> // q{}).Str;
    if $h.chars {
        return $*HOME.Str.IO                   if $h eq q{~};
        return ($*HOME.Str ~ $h.substr(1)).IO if $h.starts-with(q{~/});
        return $h.IO;
    }
    $*HOME.Str.IO.add(chr(46) ~ q{rakuish-history})
}

# `:color` / `:replay` 不给默认值，靠 `.defined` 区分「没传」——否则原来那句
# `Bool :$color = True` 等于把颜色永久锁死，rc 与环境变量都没有发挥余地。
our sub run-loop(:$color, :$replay, :$read-line --> Int) is export {
    # 注入了 read-line = 测试 / 脚本模式。此时默认**不读用户家目录的
    # ~/.rakuishrc**，否则开发机上一个偶然存在的 rc 就会让测试结果不可复现
    # （而且这些测试无 tty，颜色开关无意义）。而 RAKUISH_RC 一旦显式指定就一律读——
    # 所以测试里验证 rc 效果的正当用法就是设 RAKUISH_RC 指向临时文件。
    my $rc-explicit = (%*ENV<RAKUISH_RC> // q{}) ne q{};
    my @rc-warn;
    @rc-warn = load-rc() if $rc-explicit or not $read-line;
    $*ERR.say($_) for @rc-warn;

    # 优先级：默认值 < rc < 环境变量 < 显式参数
    my $use-color = %RC<color>;
    $use-color = coerce-bool(%*ENV<RAKUISH_COLOR>) if %*ENV<RAKUISH_COLOR>.defined;
    $use-color = False if (%*ENV<NO_COLOR> // q{}) ne q{};
    $use-color = $color.Bool if $color.defined;
    my $use-replay = %RC<replay>;
    $use-replay = coerce-bool(%*ENV<RAKUISH_REPLAY>) if %*ENV<RAKUISH_REPLAY>.defined;
    $use-replay = $replay.Bool if $replay.defined;

    my $history-file = rc-history-path();
    my $editor-name = 'none';
    my &interactive;
    if $read-line {
        &interactive = $read-line;     # 测试注入：无需 tty / Prompt
    }
    else {
        require Prompt;
        my $p = Prompt.new('LineEditor',
            :history($history-file), :additional-completions([&complete-at]));
        # 注意：Prompt.new 已通过 :history 把文件载入编辑器 @.history，
        # 这里**不再**调用 load-history（否则重复加载、落盘时产生重复行）。
        # 用 readline 而非 read：readline 在每次回车后 add-history，↑/↓ 当次
        # 会话即可翻查；再显式 save-history 把历史落盘，跨会话重放后也能翻到。
        $editor-name = $p.editor-name;
        &interactive = sub ($prompt) {
            # 把编辑器里的历史同步给 %hist 用（$p.history 由 handles 转发，
            # 读到的就是编辑器内部那份 @history，回车后自动更新）。
            history-sync($p.history.List);
            my $line = $p.readline($prompt);
            try { $p.save-history } if $line.defined;
            $line
        };
    }

    install-signal-handler();   # 让 REPL 不被 Ctrl-C 杀掉
    open-replay();              # 打开 .repl 追加句柄（也定下文件路径）

    # 默认**不**在启动时自动重放上次输入：否则一进 shell 就冒出一堆历史
    # 命令，既打扰又可能重跑有副作用的语句。要恢复旧行为用 :replay 参数
    # （或环境变量 RAKUISH_REPLAY=1，bin/rakuish 会读它）。注意 ↑/↓ 历史
    # 翻查走的是另一套 rakuish-history，与这里的 .repl 重放无关，不受影响。
    my &reader = &interactive;
    my $replay-count = 0;
    if $use-replay {
        my @saved = replay-lines();
        $replay-count = @saved.elems;
        my $phase = 0;
        &reader = sub ($prompt) {
            if $phase == 0 && @saved.elems > 0 {
                return @saved.shift;
            }
            if $phase == 0 {
                $phase = 1;
                $REPLAYING = False;     # 切到交互阶段：恢复记录
                return &interactive($prompt);
            }
            return &interactive($prompt);
        };
    }
    out-line(welcome-text($editor-name, :color($use-color)));
    set-terminal-title('rakuish');
    if $use-replay and $replay-count > 0 {
        $REPLAYING = True;
        out-line(chr(0x21BB) ~ " 重放 {$replay-count} 条输入（%repl clear 清空 " ~ chr(0x00B7) ~ " %repl off 关闭记录）");
    }
    my $rc = drive(&reader, :color($use-color), :auto-shell(%RC<auto-shell>));
    close-replay();
    $rc
}

# ── %hist：反查历史（Ctrl-R 的替代方案）───────────────────────────────
# 为什么不做 Ctrl-R：`Prompt` 的 `handles` 白名单里没有搜索 API，
# `$!LineEditor` 是私有属性（role 外取不到，`^get` 返回 Nil），而
# `CLIInput` 与 `ScrollingSingleLineInput::ANSI` 都是**不可组合的 class**——
# 既不能继承出 `edit-history-reverse-search`，也无法覆写按键分派；
# 且 `CLIInput.prompt` 没有 `:content` 参数，想"预填输入行"也做不到。
# 完整探查记录见 tools/NOTES-editor-limits.md。
#
# 所以给出不依赖按键流的两条替代路径：
#   %hist <子串>          反查（大小写不敏感），最新在前
#   %hist --put <子串>    反查并把最近一条存进 %STORE<last-hist>，打印出来，
#                         提示按 ↑ 即可调回输入行（↑ 调历史是编辑器原生能力）
#   %hist --pick N        同上，但取第 N 条
#   %hist --all           列全部

our $HISTORY-LINES;      # run-loop 每次读行前同步进来

our sub history-sync(*@lines) is export {
    $HISTORY-LINES = @lines;
    Nil
}

# 纯函数：过滤历史。最新在前（倒序），子串大小写不敏感。
# 返回 List 而非容器拷贝 —— 这两个后端里 `my @a = $some-list` 不摊平。
our sub hist-search(*@lines, Str :$needle!, Int :$limit = 20 --> List) is export {
    # 无论有没有 needle，一律「最新在前」—— 无参数时也要倒序。
    if $needle eq q{} {
        return @lines.reverse.List;
    }
    my $lc-needle = $needle.lc;
    my @hits = @lines.reverse.grep({ $_.lc.contains($lc-needle) });
    # 注意：不要写成 `@hits.elems > $limit ?? @hits[0..$limit-1] !! @hits` ——
    # 三元表达式里放数组会把它当**单个元素**，返回的List 里就套了一层
    # Array（下游 `@h[$i]` 于是拿到整个数组，报 expected Str but got Array）。
    # 显式分支最稳。
    if @hits.elems > $limit {
        return @hits[0 .. $limit - 1].List;
    }
    @hits.List
}

# 编辑距离（Levenshtein），用于"你是不是想找…"的近似提示。
our sub edit-distance(Str $a, Str $b --> Int) is export {
    my @prev = (0 .. $a.chars).List;
    my @cur;
    for 1 .. $b.chars -> $j {
        @cur = ($j);
        for 1 .. $a.chars -> $i {
            my $cost = $a.substr($i - 1, 1) eq $b.substr($j - 1, 1) ?? 0 !! 1;
            @cur.push: min(@prev[$i] + 1, @cur[$i - 1] + 1, @prev[$i - 1] + $cost);
        }
        @prev = @cur;
    }
    @prev[$a.chars]
}

# 近似匹配：子串没命中时找编辑距离最小的一条。
# 刻意用标量循环而不是 map/sort 出嵌套结构 —— 这两个后端遍历嵌套容器
# 的语义不一致（`for $list-of-list` 只迭代一次），本项目已踩过多次。
our sub hist-nearest(*@lines, Str :$needle! --> Str) is export {
    return q{} if $needle eq q{} || !@lines;
    my $target = $needle.lc;
    # 距离上限：与搜索词长度同阶即可。
    # 实测过几个方案：
    #   ceil(len/2)     → `stauts` → `git status`（距离 6）找不到提示，太紧
    #   夹在 [2,4]      → 同上，还是太紧
    #   固定 3          → 长词完全不给提示
    #   len             → 搜 10 字符词时距离 8 的无关行也被提示
    # 取「与词长同阶、但不超词长」这个折中：短词自然严、长词自然松，
    # 且不会给完全无关的行（距离上限=词长本身）。
    # 上限 6：再长的搜索词，编辑距离超过 6 基本就是无关内容，
    # 提示出来反而是噪声（实测搜10 字符词时距离 8 的行也会被捞出来）。
    my $thresh = $target.chars < 2 ?? 1 !! ($target.chars > 6 ?? 6 !! $target.chars);
    my Int $best = 9999;
    my Str $winner = q{};
    # 注意：写成 `$l.lc.edit-distance(...)` 会把 `.lc` 解析到 slurpy 的
    # **整个 @lines** 上（实测报 "No such method 'edit-distance' for string
    # '<全部历史拼起来>'"）。必须先用中间变量把 Str 落到标量。
    for @lines -> $l {
        my Str $lc-line = $l.lc;
        my $d = edit-distance($lc-line, $target);
        next if $d > $thresh;
        if $d < $best {
            $best = $d;
            $winner = $l;
        }
    }
    $winner
}

# 渲染一条历史（过长截断）
our sub hist-truncate(Str $line, Int $width = 96 --> Str) is export {
    return $line if $line.chars <= $width;
    $line.substr(0, $width) ~ q{ ...}
}

our sub hist-magic(Str $line) is export {
    # 剥掉命令词：`%hist` / `hist` 都可能（magic 分发传的是原始整行，
    # 而直接调hist-magic 时可能不带 %），顺带容忍中间的空白。
    # `my @w = $line.words` 之后 `@w[0]` 会拿到整个 List（不摊平），
    # 所以一律用 List 型变量 + 下标。
    # 这两个后端里，对「由 List 构造出来的容器」做 `$w[$i]` 下标访问不可靠
    # （实测 `$a` 拿到的是整个数组，于是 `$a eq '--put'` 永远 False）。
    # 唯一在所有情形都验证正确的顺序消费方式是**逐个 shift**，
    # 所以整个 flag 解析写成 shift 循环。
    my $w = Array.new;
    for $line.words -> $one { $w.push: $one }

    my Bool $put  = False;   # 取出到 %STORE
    my Bool $all  = False;   # 列全部
    my Int  $pick = 0;       # 指定第几条（1 起）
    my $rest = Array.new;
    my Bool $first = True;
    while $w.elems {
        my $a = $w.shift;
        if $first {
            $first = False;
            next if $a eq 'hist' || $a eq '%hist';
        }
        if $a eq '--put' {
            $put = True;
        }
        elsif $a eq '--all' {
            $all = True;
        }
        elsif $a eq '--pick' {
            # 下一个词是序号：直接取出来消费掉
            if $w.elems {
                my $nx = $w.shift;
                $pick = $nx.Int;
            }
        }
        elsif $pick < 1 && $a.chars && $a ~~ /^ <[0..9]> + $ / {
            # 也允许裸序号（`%hist 3`）
            $pick = $a.Int;
        }
        else {
            $rest.push: $a;
        }
    }

    # 不要写 `my @h = $HISTORY-LINES // ();` —— 这两个后端里
    # 「List 赋给数组变量」不摊平，整个 List 会变成**单个元素**，
    # 于是后面每个 $l 都是整段历史字符串（静默出错，不报类型错）。
    # 直接把 List 展开成位置参数传给 slurpy 形参。
    my $hl = $HISTORY-LINES // ();
    unless $hl.elems {
        out-line(q{（历史为空）});
        out-line(q{提示: 历史在每次回车后落盘到 ~/.rakuish-history});
        return Nil;
    }

    my $needle = $rest.join(q{ });
    my Int $limit = $all ?? 1000 !! 20;
    # 直接用 List 型变量 + 下标，**不要**写 `my @hits = hist-search(...)` ——
    # List 赋给数组变量在这两个后端不摊平，整个 List 会变成单个元素。
    # **必须**用 `$hl.List`：把一个 List 对象直接传给 `*@lines` slurpy
    # 在这两个后端上**不摊平**（@lines.elems == 1，拿到的是整个 List），
    # 于是下游每个"元素"都是嵌套 List。这是本项目最隐蔽的一个变体，
    # 测法：sub f(*@x){ @x.elems };  f(List(1,2,3)) # => 1（不是 3）
    my $hits = hist-search($hl.List, :$needle, :$limit);

    unless $hits.elems {
        out-line(q{没有匹配的历史: } ~ $needle);
        my $near = hist-nearest($hl.List, :$needle);
        if $near ne q{} {
            out-line(q{  最接近的: } ~ hist-truncate($near, 80));
            out-line(q{  试试 %hist --put } ~ hist-truncate($near, 40));
        }
        return Nil;
    }

    # --pick N / --put：取出到 %STORE，并提示用 ↑ 调回输入行
    my Int $which = 0;
    if $pick > 0 {
        unless $pick <= $hits.elems {
            out-line(q{%hist --pick } ~ $pick ~ q{: 越界（只有 } ~ $hits.elems ~ q{ 条匹配）});
            return Nil;
        }
        $which = $pick;
    }
    elsif $put {
        $which = 1;
    }

    if $which {
        my $got = $hits[$which - 1];
        store-set(q{<last-hist>}, $got);
        out-line(q{→ } ~ hist-truncate($got, 88));
        out-line(q{  已存入 %STORE<last-hist> · 按 ↑ 调回输入行});
        return Nil;
    }

    # 列表模式。
    # 注意：不能写 `for @hits -> $h, $i` —— 这两个后端会只迭代一次并把
    # 整个数组塞给第一个占位符（报 "Too few positionals"，实测踩过）。
    # 用 C: 前缀显式 enumerate。
    my $n = $hits.elems;
    # enumerate 的几种写法在这两个后端都踩过：
    #   `for @h -> $x, $i`  -> 只迭代一次，$x 拿到整个数组（Too few positionals）
    #   `for @h -> C: $i, $x` -> Invalid typename 'C'
    #   `@h.C -> $i, $x { }` -> Unexpected block in infix position
    # 所以用最保守的：显式下标 for 循环（语法是老Raku 就有的，必然可用）。
    # `rjust` 在 MoarVM/rakupp 上都没有，用 sprintf 的宽度格式。
    my Int $li = 0;
    while $li < $hits.elems {
        my $entry = $hits[$li];
        out-line(sprintf(q{  %3d%s%s}, $li + 1, q{  }, hist-truncate($entry)));
        $li = $li + 1;
    }
    out-line(q{共 } ~ $n ~ q{ 条} ~ ($needle ~~ q{} ?? q{} !! q{（匹配 } ~ $needle ~ q{）}));
    out-line(q{%hist --put <子串> 取出最近一条 · --pick <序号> 取指定条});
    Nil
}

# ── %run：整脚本执行 + 汇总块 ───────────────────────────────────────
our sub run-magic(Str $line) is export {
    my @parts = $line.words;
    @parts.shift if @parts && @parts[0] eq 'run';

    my $want-numbers = False;
    my @paths;
    for @parts -> $p {
        if $p eq '--numbers' || $p eq '-n' {
            $want-numbers = True;
        }
        else {
            @paths.push: $p;
        }
    }

    if !@paths {
        out-line(q{用法: %run [--numbers|-n] 脚本.sh});
        out-line(summary-box(q{run}, 2, :stdout-lines(0), :stderr-lines(0)));
        return Nil;
    }

    my $arg = @paths[0];
    my @script-args = @paths[1..*].grep(*.defined);
    my $f = $arg.IO;
    unless $f.e {
        out-line(qq{rakuish: 找不到脚本：{$arg}});
        out-line(summary-box($arg, 127, :stdout-lines(0), :stderr-lines(0)));
        return Nil;
    }

    my $t0 = now;
    # ⚠ 解释器由 **shebang / 后缀**决定（见 Slow::script-interpreter）：
    #   `.sh` 走 **bash**（不是 dash！dash 没有 brace 展开、没有 [[ ]]）。
    my $arg-str = @script-args.map({ sh-quote($_) }).join(' ');
    my $cmd = script-interpreter($f.Str) ~ ' ' ~ sh-quote($f.Str)
              ~ ($arg-str ?? ' ' ~ $arg-str !! '');
    my $res = run-shell($cmd, :capture(True));
    my $dt = (now - $t0).Real;

    if $res.stdout.trim ne q{} {
        if $want-numbers {
            out-line(number-lines($res.stdout, :numbers(True)));
        }
        else {
            out-line($res.stdout);
        }
    }
    if $res.stderr.trim ne q{} {
        out-line($res.stderr);
    }

    my $so = count-lines($res.stdout);
    my $se = count-lines($res.stderr);
    out-line(summary-box($arg, $res.code, :duration($dt),
                         :stdout-lines($so), :stderr-lines($se)));
    Nil
}

# ── %time：计时求值 ──────────────────────────────────────────────────
# 把 `%time` 后面的表达式按快档求值（同一 Eval 路径，%STORE / 副作用都生效），
# 显示成 Out[n]（复用 drive 给这一行预留的序号，不另占编号），末尾附一个耗时框。
# 语义对齐 IPython 的 %time：表达式的值仍进 Out[n]。
our sub time-magic(Str $line) is export {
    my @parts = $line.words;
    @parts.shift if @parts && @parts[0] eq 'time';

    my $expr = @parts.join(' ');
    if $expr.trim eq q{} {
        out-line(q{用法: %time 表达式});
        out-line(time-box(:duration(0), :status(2)));
        return Nil;
    }

    my $index = $CURRENT-SESSION.defined ?? $CURRENT-SESSION.next-index !! 1;
    my $t0 = now;
    my $r = eval-cell($expr, :index($index));
    my $dt = (now - $t0).Real;

    if $r.ok {
        $CURRENT-SESSION.record($expr, True, $r.value, q{}) if $CURRENT-SESSION.defined;
        out-line(render-out($index, $r.value));
    }
    else {
        my $msg = render-error($r);
        $CURRENT-SESSION.record($expr, False, Nil, $msg) if $CURRENT-SESSION.defined;
        out-line($msg);
    }

    out-line(time-box(:duration($dt), :status($r.ok ?? 0 !! 1)));
    Nil
}

# ── %load：载入文件进 workspace 并保留状态 ────────────────────────────
# 与 `%run`（真 sh 子进程、跑完即销毁）相反，`%load` 把**文件内容当作 Raku
# 代码送进当前 EVAL 通道**求值，所以跨 cell 的状态（`%STORE`）会留下。
# 注意：cell 里定义的 `sub` 仍不跨 cell（Eval 模块语义 3）—— 这正是
# 为什么状态要挂 %STORE 而非靠临时变量。详见 DESIGN.md。
our sub load-magic(Str $line) is export {
    my @parts = $line.words;
    @parts.shift if @parts && @parts[0] eq 'load';

    my $range; my $symbol; my @paths;
    my $i = 0;
    while $i < @parts.elems {
        my $t = @parts[$i];
        if $t eq '-r' || $t eq '--range' {
            $i++; $range = @parts[$i] if $i < @parts.elems;
        }
        elsif $t.starts-with('--range=') || $t.starts-with('-r=') {
            $range = $t.substr($t.index('=') + 1);
        }
        elsif $t eq '-s' || $t eq '--symbol' {
            $i++; $symbol = @parts[$i] if $i < @parts.elems;
        }
        elsif $t.starts-with('--symbol=') || $t.starts-with('-s=') {
            $symbol = $t.substr($t.index('=') + 1);
        }
        else {
            @paths.push: $t;
        }
        $i++;
    }

    if !@paths {
        out-line(q{用法: %load 文件 [-r A-B | --range A-B] [-s 名称 | --symbol 名称]});
        out-line(load-box(:status(2)));
        return Nil;
    }

    my $arg = @paths[0];
    my $f = $arg.IO;
    unless $f.e {
        out-line(qq{rakuish: 找不到文件：{$arg}});
        out-line(load-box($arg, :lines(0), :total(0), :status(1)));
        return Nil;
    }

    my $ext = $f.extension // q{};
    my $first = try { $f.slurp.lines[0] // q{} };
    my $is-shell = $ext eq 'sh'
        || ($first.defined && $first.starts-with('#!')
            && ($first.contains('/sh') || $first.contains('bash')));
    if $is-shell {
        out-line(qq{rakuish: {$arg} 看起来是 shell 脚本，请用 %run 运行});
        out-line(load-box($arg, :lines(0), :total(0), :status(1)));
        return Nil;
    }

    my $content = try { slurp($f) };
    if $! {
        out-line(qq{rakuish: 读取失败：{$arg}});
        out-line(load-box($arg, :lines(0), :total(0), :status(1)));
        return Nil;
    }

    my ($src, $sel, $total) = select-source($content, $range, $symbol);
    if $sel == 0 {
        my $reason = ($range.defined || $symbol.defined) ?? '范围/符号无效' !! '文件为空';
        out-line(qq{rakuish: 选取为空（{$reason}）：{$arg}});
        out-line(load-box($arg, :lines(0), :total($total), :status(1)));
        return Nil;
    }

    my $index = $CURRENT-SESSION.defined ?? $CURRENT-SESSION.next-index !! 1;
    my $r = eval-cell($src, :index($index));

    if $r.ok {
        $CURRENT-SESSION.record($src, True, $r.value, q{}) if $CURRENT-SESSION.defined;
        out-line(render-out($index, $r.value));
    }
    else {
        my $msg = render-error($r);
        $CURRENT-SESSION.record($src, False, Nil, $msg) if $CURRENT-SESSION.defined;
        out-line($msg);
    }

    out-line(load-box($arg, :lines($sel), :total($total), :status($r.ok ?? 0 !! 1)));
    Nil
}

# 从文件内容里挑出要载的源码：优先 -s（符号），其次 -r（行范围），否则整文件。
# 返回 (源码, 选中行数, 总行数)。选中 0 行表示选取无效。
our sub select-source(Str $content, $range, $symbol) is export {
    my @all = $content.lines;
    my $total = @all.elems;
    my @sel;
    if $symbol.defined && $symbol.chars {
        @sel = extract-symbol(@all, $symbol);
    }
    elsif $range.defined && $range.chars {
        @sel = slice-range(@all, $range);
    }
    else {
        @sel = @all;
    }
    (@sel.join(chr(10)) ~ chr(10), @sel.elems, $total)
}

# 行范围：`3-7` 取第 3..7 行（1 起，含端点）；`5` 取第 5 行。
# 越界/格式错 → 空列表（由调用方报"选取为空"）。
our sub slice-range(@lines, Str $spec --> List) is export {
    return () unless $spec.defined && $spec.chars;
    if $spec ~~ /^(\d+)$/ {
        my $a = $0.Int;
        return $a >= 1 && $a <= @lines.elems ?? (@lines[$a - 1],) !! ();
    }
    if $spec ~~ /^(\d+)'-'(\d+)$/ {
        my ($a, $b) = ($0.Int, $1.Int);
        return () unless $a >= 1 && $b >= $a && $b <= @lines.elems;
        return @lines[$a - 1 .. $b - 1].list;
    }
    ()
}

# 提取一个顶层声明（按名字）：从声明起始行开始，按花括号配平往下收，
# 直到净括号数归零（含起始行的 `{`）。忽略 `#` 注释与字符串里的 `{}`。
# 单行声明（如 `my $x = 1;`，无花括号）只收起始行。
our sub extract-symbol(@lines, Str $name --> List) is export {
    # 这条正则有三条**跨后端**硬约束（2026-10-30 实测踩出来的）：
    #
    # 1. **必须写成一行**。多行正则字面量里 rakupp 把换行当**显著**字符，
    #    MoarVM 则当无意义空白忽略 —— 同一个模式在 MoarVM 上能匹配、
    #    在 rakupp 上永远匹配不上（%load -s 静默失效）。
    # 2. **结尾的分隔符不要用 `<[ ... ]>` 字符类**。rakupp 在「正则存进变量」
    #    这一路径上会把带**空格分隔** item 的 `<[...]>` 拆坏（MoarVM 不会）。
    #    改用**带引号的括号式交替** `(\s | ' ' | '(' | ... )`：两个后端上
    #    匹配集合**逐字符一致**，且 item 集合与原意一致（空白 ∪ `(: { [ . , ;`）。
    # 3. **`$name` 与后面的分隔符组之间要留空格**。`$name<[...]>` 会被 rakupp
    #    解析成「下标」而不是「正则」（MoarVM 只警告一句
    #    "Apparent subscript will be treated as regex" 后仍按正则处理）。
    #
    # 判据：两个后端上 t/11-load.t 必须全绿 —— 只测一个等于没测。
    my $re = /^\s*[sub|my|our|class|grammar|role|module|constant|enum|subset|proto|multi|only]\s+$name (\s | ' ' | '(' | ':' | '{' | '[' | '.' | ',' | ';' )/;
    my $start = -1;
    for @lines.kv -> $k, $line {
        if $line ~~ $re {
            $start = $k; last;
        }
    }
    return () if $start < 0;

    my $net = 0; my $seen-open = False;
    my @picked;
    for @lines[$start .. *] -> $line {
        my ($n, $opened) = scan-braces($line);
        $net = $net + $n;
        $seen-open = $seen-open || $opened;
        @picked.push: $line;
        last if (!$seen-open && @picked.elems >= 1) || ($seen-open && $net == 0);
    }
    @picked.list
}

# 扫一行：返回 (净括号变化, 是否出现过 `{`)。忽略字符串与 `#` 注释里的括号。
our sub scan-braces(Str $line --> List) is export {
    my $net = 0; my $opened = False;
    my $in-s = False; my $in-d = False; my $in-t = False; my $esc = False;
    my $SQ = chr(39); my $DQ = chr(34); my $BT = chr(96); my $BS = chr(92);
    for $line.comb -> Str $c {
        if $esc { $esc = False; next; }
        if $c eq $BS && !$in-s { $esc = True; next; }
        if $c eq $SQ && !$in-d && !$in-t { $in-s = !$in-s; next; }
        if $c eq $DQ && !$in-s && !$in-t { $in-d = !$in-d; next; }
        if $c eq $BT && !$in-s && !$in-d { $in-t = !$in-t; next; }
        next if $in-s || $in-d || $in-t;
        if $c eq '#' { last; }
        if $c eq '{' { $net++; $opened = True; }
        elsif $c eq '}' { $net--; }
    }
    ($net, $opened).List
}

# P4-2：脚本模式下「文件读完而这一格还没写完」的报错。
# 三个要件：**带文件:行号**、**说清还差什么没闭合**、**非零退出码**
#（调用方置 2）。缺任何一条，用户就只能拿到一个 rc=0 的空跑。
sub report-script-incomplete(Str $partial, Int $from-line) {
    my $file  = $Rakuish::Eval::SOURCE-FILE;
    my $where = $file.chars ?? "{$file}:{$from-line}" !! "第 {$from-line} 行";
    my $hint  = unclosed-hint($partial);
    my $tail  = $hint.chars ?? "；未闭合：{$hint}" !! q{};
    $*ERR.say("rakuish: {$where}: 文件结束时输入还没写完（块或引号没有闭合）{$tail}");
}

# ══════════════════════════════════════════════════════════════════════
# 脚本模式（C 方案 P0）
#
# 刻意**不另写一套执行器**：把文件行序列塞进 `drive` 那个「可注入
# read-line」的入口，heredoc / 多行续接（needs-more）/ %STORE / 跨行
# 词法状态就全部免费继承，REPL 与脚本永远共用同一条语义通道。
#
# 与 REPL 的差别只有三处：
#   1. read-line 来自文件而非行编辑器（无提示符、无 tty 依赖）
#   2. :script → 静音 REPL 装饰，只留程序输出
#   3. :auto-shell(False) → 脚本里的 Raku 语法错误必须是错误。
#      REPL 那种「求值失败就猜成外部命令」的兜底在脚本里是有害的：
#      打错一个变量名会被当成命令去执行，错误被静默吞掉。
# ══════════════════════════════════════════════════════════════════════
#
# 用**外部解释器**跑一个脚本（脚本模式专用，G5）。
#
# ⚠ **不经 shell**：把路径原样交给解释器（`run($interp, $path)`）——
#   走 `sh -c` 会让 dash 介入（本机 /bin/sh 是 dash，bash 语法会静默跑歪），
#   也会把路径里的空格/引号吃掉。脚本要什么解释器，就用什么解释器。
# ⚠ stdout/stderr **不接管** ⇒ 子进程直接继承 ⇒ 输出直通、顺序不变、
#   保持流式（长脚本不会等到结束才出结果）。
# ⚠ 脚本参数原样传过去（`@*ARGS` 在脚本模式下就是「脚本名之后的参数」）。
our sub run-external-script(Str $path, Str $interp --> Int) is export {
    # ⚠ 必须用 `CORE-RUN`（内建的 run）：本模块里的 `run` 是 Result 的 DSL 版
    #   （返回 Result 对象，没有 .exitcode）。
    my $p = try { CORE-RUN($interp, $path, @*ARGS) };
    # ⚠⚠ **只能看 `$!`，不能看 `!$p`** —— 这是个很贵的 Raku 语义坑：
    #   **代码对象（Proc / Block）在布尔上下文里是「假」** ⇒ `!$p` 恒为真
    #   ⇒ 不管 try 成功没成功都会走进这个分支（实测：退出码 3 的脚本被
    #   误判成「解释器找不到」，退出码变成 127）。
    #   `try` 成功时 `$!` 是 Nil、失败时是异常 ⇒ 只认 `$!`。
    if $! {
        $*ERR.say: "rakuish: 跑不起来：{$interp}（找不到这个解释器？）";
        return 127;                 # bash 的「命令找不到」约定
    }
    my Int $rc = $p.exitcode // 0;
    return $rc < 0 ?? 127 !! $rc;
}

# ══════════════════════════════════════════════════════════════════════
our sub run-script(Str $path --> Int) is export {
    my $io = $path.IO;
    unless $io.e {
        $*ERR.say: "rakuish: 找不到脚本文件：{$path}";
        return 2;                    # 2 = 用法/输入错误（对齐 bash 的 127 语义归属）
    }

    # ⚠ G5（0.16.4 修）：脚本模式要**认 shebang**。
    #   以前不管文件写的是什么，一律当 Raku 脚本求值 ⇒
    #   `rakuish run x.sh`（`#!/bin/bash`）报
    #   "Two terms in a row across lines" —— 看着像语法错，
    #   其实是**用错了语言**。
    #   现在：shebang 指向 Raku 系（或没有 shebang 且不是 .sh）⇒ 走 Rakuish
    #   脚本模式；否则 ⇒ 交给那个解释器跑，退出码原样带回来。
    my $interp = script-mode-interpreter($path);
    if $interp ne 'raku' {
        return run-external-script($path, $interp);
    }

    my $text = try { $io.slurp };
    if $! or !defined $text {
        $*ERR.say: "rakuish: 读不了脚本文件：{$path}";
        return 2;
    }
    # `lines` 会丢掉末尾空行，但保留「最后一行没有换行符」的内容。
    my @lines = $text.lines;
    # $*PROGRAM 的来源：Eval 拼壳子时会 `my $*PROGRAM := IO::Path.new(路径)`
    # 遮蔽掉不可变的那个（P0 遗留：脚本里拿不到自己的路径）。
    my $prev-file = $Rakuish::Eval::SOURCE-FILE;
    $Rakuish::Eval::SOURCE-FILE = $io.absolute.Str;

    my Int $cursor = 0;
    my $session = Loop.new;
    my $lex     = LexState.new;
    my Array $cells = [];

    # ── 第一步：规划（只分类、不执行）──────────────────────────────
    # 只回答问题：「每格从第几行起、占几行、是不是 Raku、heredoc 正文是什么」。
    # 这一步碰不到文件系统，所以**不会**产生副作用。
    my $rc = drive(sub (Str $p) {
        $cursor < @lines.elems ?? @lines[$cursor++] !! Nil
    }, :color(False), :auto-shell(False), :script(True), :$session,
       :lex-state($lex), :plan(True), :cells($cells));

    if $rc != 0 {
        # 规划阶段就报错了（例如末块未闭合，P4-2 的 exit 2）：不再执行。
        $Rakuish::Eval::SOURCE-FILE = $prev-file;
        return $rc;
    }
    # 文件里还剩**非空行**没进规划 ⇒ 引擎丢了行。正常不会发生（规划阶段
    # 从不中止），留着当第二道防线：宁可报错，也不要静默少跑半份脚本。
    if !$session.should-exit and $cursor < @lines.elems {
        my @rest = @lines[$cursor .. *].grep({ .trim ne q{} });
        if @rest.elems {
            $*ERR.say("rakuish: {$io.absolute}:{$cursor + 1}: 还有 {@rest.elems} 行没有执行（脚本被提前终止）");
            $Rakuish::Eval::SOURCE-FILE = $prev-file;
            return 2;
        }
    }

    # ── 第二步：拼成一个编译单元，**一次编译、一次执行** ───────────
    # 这一步修掉 G3：以前每格把整份缓冲重 EVAL，spurt/rename/mkdir 会跟着
    # 重跑一次，靠文件系统状态的脚本因此在终态上"假失败"。
    my %asm = assemble($cells);
    # 诊断开关：RAKUISH_DEBUG_ASM=1 时把拼好的编译单元原样打到 stderr。
    # 脚本模式的 bug 十有八九是"拼错了"（行号错位、格没落位），
    # 没有这面镜子就只能靠猜。
    if %*ENV<RAKUISH_DEBUG_ASM> {
        $*ERR.say: "==== ASSEMBLED (prepend) ====\n{%asm<hoist>}==== BODY :{@lines.elems} 行 ====";
        for %asm<body>.lines.kv -> $i, $l { $*ERR.say: "{($i + 1).fmt('%3d')}| {$l}" }
        $*ERR.say: "==== END ====";
    }
    # ── 2.5 自动调用 MAIN ──────────────────────────────────────────
    # 原生 raku 编译器在主程序结束后会自动调用 &MAIN 并按其签名解析 @*ARGS；
    # 但 EVAL 不会（&MAIN 是 EVAL 词法作用域内的，外部看不到）。
    # 所以在 body 末尾补一段：检测到 &MAIN 就按 Raku MAIN 语义解析
    # @*ARGS 并调用。Bool 命名参数靠签名内省识别，避免吞掉下一个位置参数。
    my $main-dispatch = q:to/MD/;
    # ══ Rakuish: 自动调用 MAIN（EVAL 不会自动做） ══
    # 原生 raku 编译器会按 MAIN 签名解析 @*ARGS 并强制转换类型；
    # 这里手动实现同等语义（:key<value> 副词才有编译器自动强转，
    # hash slip 没有，所以必须自己按参数类型转）。
    {
        # 用 ::('&MAIN') 运行时查找：MAIN 未声明时返回 Nil，
        # 不会像直接写 &MAIN 那样触发编译期 "Undeclared routine" 错误。
        my $main = ::('&MAIN');
        if $main.defined {
            sub coerce-main-val(Str $v, Mu $t) {
                return $v if $v ~~ $t;
                if $t ~~ Bool {
                    return ?($v eq '1' | 'true' | 'True' | 'yes' | 'on');
                }
                return $v.Int if $t ~~ Int;
                return +$v     if $t ~~ Real;
                return $v;
            }
            my %type-for;
            my %is-bool;
            for $main.signature.params -> $p {
                next unless $p.named;
                my $n = $p.name.substr(1);
                %type-for{$n} = $p.type;
                %is-bool{$n} = True if $p.type ~~ Bool;
            }
            my @pos;
            my %named;
            my Bool $no-more = False;
            my @a = @*ARGS;
            while @a {
                my $arg = @a.shift;
                if $no-more {
                    @pos.push: $arg;
                }
                elsif $arg eq '--' {
                    $no-more = True;
                }
                elsif $arg.starts-with('--') {
                    my $rest = $arg.substr(2);
                    if $rest.contains('=') {
                        my ($k, $v) = $rest.split('=', 2);
                        %named{$k} = coerce-main-val($v, %type-for{$k});
                    }
                    elsif %is-bool{$rest} {
                        %named{$rest} = True;
                    }
                    elsif @a and @a[0] !~~ /^ '-' / {
                        my $k = $rest;
                        %named{$k} = coerce-main-val(@a.shift, %type-for{$k});
                    }
                    else {
                        %named{$rest} = True;
                    }
                }
                elsif $arg.starts-with('-') and $arg !~~ /^ '-' \d / {
                    %named{$arg.substr(1)} = True;
                }
                else {
                    @pos.push: $arg;
                }
            }
            $main(|@pos, |%named);
        }
    }
    MD
    %asm<body> ~= "\n" ~ $main-dispatch;

    my $prev-ctx = %SCRIPT-CTX;
    %SCRIPT-CTX = %( :$session, :lex-state($lex),
                     run-script => sub (Str $p --> Int) { run-script($p) } );
    my $r = eval-program(%asm<body>, :prepend(%asm<hoist>), :line-base(1),
                         :cell-hook(&__script-cell__));
    %SCRIPT-CTX = $prev-ctx;
    $Rakuish::Eval::SOURCE-FILE = $prev-file;
    try { $*OUT.flush };
    try { $*ERR.flush };

    if !$r.ok {
        # 报错走 stderr：既符合 unix 习惯，也让 `cmd >out.txt` 不会把报错
        # 一起收进结果文件。脚本不是 REPL：出错即停，退出码 1。
        # ⚠ 脚本模式：**无装饰**（PLAN-C 第 45 行「无装饰，只有程序输出」）
        #   —— 只留「文件:行号」+ 消息，不带 REPL 的分级头 / 出错行 / 提示。
        $*ERR.say(render-error($r, :color(False), :script(True)));
        return 1;
    }
    # 退出码优先级：程序里的 `exit N` > 非 Raku 格里的 exit/%quit > 0
    return $r.exit-code if $r.exit-code.defined;
    return $session.exit-code if $session.should-exit;
    0
}


# ── %inspect：查看会话内部状态 ────────────────────────────────────
#
#   %inspect              → 总览（session 数、STORE key 数、shell 后端、daemon）
#   %inspect store        → 列出所有 %STORE key
#   %inspect env          → 列出非噪声 %*ENV（daemon 同步后的）
#   %inspect session      → In[n] / Out[n] / _ 值
#   %inspect lex          → 累积源码（LexState.accum，即跨 cell 重跑的完整源码）
#   %inspect all          → 以上全部
#   %inspect daemon       → daemon PID / 文件 / 状态
#
our sub inspect-magic(Str $line --> Nil) is export {


    my $arg = q{};
    if $line ~~ /^ \s* 'inspect' \s+ (.*?) \s* $/ { $arg = ~$0 }
    $arg = $arg.trim;
    my $what = $arg eq q{} ?? 'all' !! $arg;

    my $session = $CURRENT-SESSION;
    my $lex-state = $session.lex-state if $session.defined;

    if $what eq 'all' or $what eq 'store' {
        out-line("── %STORE (" ~ store-keys().elems ~ " keys) ──");
        my @keys = store-keys();
        if @keys {
            for @keys -> $k {
                my $v = store{$k};
                my $vs = $v.defined ?? $v.Str !! 'Nil';
                out-line("  store{$k} = $vs");
            }
        }
        else {
            out-line("  (empty)");
        }
    }

    if $what eq 'all' or $what eq 'env' {
        out-line("── %*ENV (non-noise) ──");
        my @noise = <PATH HOME PWD SHELL USER LOGNAME TERM RAKUSH RAKU RAKUPATH PERL6LIB RAKULIB>;
        my @env-keys = %*ENV.keys.sort.grep({ $_ ne any(@noise) });
        if @env-keys {
            for @env-keys -> $k {
                out-line("  $k = {%*ENV{$k} // ''}");
            }
        }
        else {
            out-line("  (only noise vars)");
        }
    }

    if $what eq 'all' or $what eq 'session' {
        out-line("── Session ──");
        if $session.defined {
            out-line("  In count : " ~ $session.in-count);
            out-line("  Out count: " ~ $session.out-count);
            out-line("  _ (last) : " ~ ($session.last-value // 'Nil'));
            if $session.out-count > 0 {
                my $n = $session.out-count;
                out-line("  Out[$n]  : " ~ ($session.out-at($n) // 'Nil'));
            }
        }
        else {
            out-line("  (no session)");
        }
    }

    if $what eq 'all' or $what eq 'lex' or $what eq 'src' {
        out-line("── LexState 累积源码 ──");
        if $lex-state.defined and $lex-state.accum.chars > 0 {
            my @ls = $lex-state.accum.split("\n");
            my $n = @ls.elems;
            out-line("  ($n lines total)");
            # 显示最后 20 行
            my @show = @ls[*-20 .. *];
            if @show.elems > 20 { @show = @ls }
            for @show.kv -> $idx, $ln {
                my $real-line = $n - @show.elems + $idx + 1;
                out-line("  [$real-line] $ln");
            }
        }
        else {
            out-line("  (empty -- first cell yet)");
        }
    }

    if $what eq 'all' or $what eq 'daemon' {
        out-line("── Daemon / Shell ──");
        out-line("  backend  : $SHELL-BACKEND");
        out-line("  daemon?  : " ~ (try { daemon-running } // 'unknown'));
        my $pid-file = '/tmp/rakuish.pid';
        if $pid-file.IO.e {
            out-line("  PID file : $pid-file");
            out-line("  PID      : {$pid-file.IO.slurp.chomp}");
        }
        else {
            out-line("  PID file : (none)");
        }
    }

    if $what eq 'all' or $what eq 'help' {
        out-line("── %inspect 用法 ──");
        out-line("  %inspect [store|env|session|lex|daemon|all]");
    }

    Nil
}


# ── %trace：显示每次 EVAL 前的完整源码（调试用）───────────────────
#
#   %trace on           → 开启：每格 EVAL 前打印拼接好的完整源码
#   %trace off          → 关闭（默认）
#   %trace              → 查看当前状态
#
# 实现：Loop.drive 的 eval-cell 调用前，如果 $TRACE-ON 为 True，
#       把 lex-state.accum ~ ";\n" ~ src 打印出来（就是 eval-cell
#       内部实际会执行的那一份）。
#
our $TRACE-ON = False;

our sub trace-magic(Str $line --> Nil) is export {
    my $arg = q{};
    if $line ~~ /^ \s* 'trace' \s+ (.*?) \s* $/ { $arg = ~$0 }
    $arg = $arg.trim;

    if $arg eq 'on' or $arg eq '1' or $arg eq 'true' {
        $TRACE-ON = True;
        out-line('TRACE ON -- 每格 EVAL 前会打印完整源码');
    }
    elsif $arg eq 'off' or $arg eq '0' or $arg eq 'false' {
        $TRACE-ON = False;
        out-line('TRACE OFF');
    }
    else {
        out-line('TRACE is ' ~ ($TRACE-ON ?? 'ON' !! 'OFF') ~ '（用法: %trace on/off）');
    }
    Nil
}

# 被 drive 调用：如果 $TRACE-ON，打印这一格实际会 EVAL 的完整源码
our sub maybe-trace-eval(Str $cell-src, LexState $lex-state, Int $index --> Nil) is export {
    return unless $TRACE-ON;
    my $accum = $lex-state.defined ?? $lex-state.accum !! q{};
    my $full = $accum.chars ?? $accum ~ ";\n" ~ $cell-src !! $cell-src;
    out-line("── TRACE In[$index] ──");
    for $full.split("\n").kv -> $i, $ln {
        out-line("  " ~ ($i + 1).fmt('%3d') ~ ": $ln");
    }
    Nil
}

# ── %watch：跨 cell 变量变化跟踪 ─────────────────────────────
#
#   %watch            → 查看当前状态（开/关）
#   %watch on         → 开启：每格 eval 后对比变量变化（新增/修改/删除）
#   %watch off        → 关闭（默认），清空历史
#
# 实现：Eval.rakumod 侧：eval-cell(:watch(True)) 时自动从累积源码提取
#       my/our/state 变量名，wrap-eval-source 在 EVAL 的 do { } 块开头
#       注入 LEAVE phaser —— 块退出前通过 EVAL('$var') 运行时访问变量值，
#       存进 $*RAKUISH-WATCH 动态变量 → __eval-wrap 带出来 → CellResult.watch。
#       Loop 侧：drive() 里 eval-cell 成功后，对比 $r.watch 与 %WATCH-PREV，
#       打印差异，更新快照。

our sub watch-magic(Str $line --> Nil) is export {
    my $arg = q{};
    if $line ~~ /^ \s* 'watch' \s+ (.*?) \s* $/ { $arg = ~$0 }
    $arg = $arg.trim;

    if $arg eq 'on' or $arg eq '1' or $arg eq 'true' {
        $WATCH-ON = True;
        %WATCH-PREV = Hash.new;  # 重置历史，下一格开始跟踪
        out-line('WATCH ON -- 每格 eval 后对比变量变化');
    }
    elsif $arg eq 'off' or $arg eq '0' or $arg eq 'false' {
        $WATCH-ON = False;
        %WATCH-PREV = Hash.new;
        out-line('WATCH OFF (历史已清空)');
    }
    elsif $arg eq 'reset' {
        %WATCH-PREV = Hash.new;
        out-line('WATCH 历史已重置');
    }
    else {
        my $status = $WATCH-ON ?? 'ON' !! 'OFF';
        out-line("WATCH is $status");
        out-line('  用法: %watch [on|off|reset]');
    }
    Nil
}

# ── %perf magic ──────────────────────────────────────────────
our sub perf-magic(Str $line --> Nil) is export {
    my $arg = q{};
    if $line ~~ /^ \s* 'perf' \s+ (.*?) \s* $/ { $arg = ~$0 }
    $arg = $arg.trim;

    if $arg eq 'on' or $arg eq '1' or $arg eq 'true' {
        $PERF-ON = True;
        out-line('PERF ON -- 每格自动计时，%perf 查看');
    }
    elsif $arg eq 'off' or $arg eq '0' or $arg eq 'false' {
        $PERF-ON = False;
        out-line('PERF OFF');
    }
    elsif $arg eq 'reset' {
        @PERF-HIST = ();
        $PERF-TOTAL-MS = 0;
        out-line('PERF 历史已重置');
    }
    elsif $arg eq 'top' {
        my @sorted = @PERF-HIST.sort({ -$_[1] });
        my $n = min(@sorted.elems, 10);
        out-line("── PERF Top $n (共 {@PERF-HIST.elems} 格，总计 {$PERF-TOTAL-MS}ms) ──");
        for @sorted[0 .. $n-1] -> $r {
            my ($idx, $ms, $preview) = @$r;
            out-line("  [$idx] {$ms}ms — $preview");
        }
    }
    elsif $arg eq 'all' {
        out-line("── PERF 全部 {@PERF-HIST.elems} 格 (总计 {$PERF-TOTAL-MS}ms) ──");
        for @PERF-HIST -> $r {
            my ($idx, $ms, $preview) = @$r;
            out-line("  [$idx] {$ms}ms — $preview");
        }
    }
    else {
        my $total = $PERF-TOTAL-MS;
        my $count = @PERF-HIST.elems;
        my $avg = $count > 0 ?? ($total / $count).Int !! 0;
        out-line("PERF: {$PERF-ON ?? 'ON' !! 'OFF'}");
        out-line("  已记录 $count 格，总计 {$total}ms，平均 {$avg}ms/格");
        out-line('  用法: %perf [on|off|reset|top|all]');
    }
    Nil
}

# ── %bt magic ──────────────────────────────────────────────────
our sub bt-magic(Str $line --> Nil) is export {
    my $arg = q{};
    if $line ~~ /^ \s* 'bt' \s+ (.*?) \s* $/ { $arg = ~$0 }
    $arg = $arg.trim;

    if $arg eq 'on' or $arg eq '1' or $arg eq 'true' {
        $BT-ON = True;
        out-line('BT ON -- 失败时打印完整 backtrace');
    }
    elsif $arg eq 'off' or $arg eq '0' or $arg eq 'false' {
        $BT-ON = False;
        out-line('BT OFF (默认)');
    }
    else {
        my $status = $BT-ON ?? 'ON' !! 'OFF';
        out-line("BT is $status");
        out-line('  用法: %bt [on|off]');
    }
    Nil
}

# 被 drive 调用：如果 %watch 开着，对比本格 watch 快照和上一格，打印差异
our sub maybe-watch-diff(Hash $snap, Int $index --> Nil) is export {
    return unless $WATCH-ON;
    return unless $snap.elems;

    out-line("── WATCH[$index] ──");

    my %cur = $snap;
    my %prev = %WATCH-PREV;

    # 新增：在 current 里有但 prev 里没有
    my @added = %cur.keys.grep({ !%prev.exists($_) }).sort;
    for @added -> $k {
        out-line("  + $k = %cur{$k}");
    }

    # 删除：在 prev 里有但 current 里没有
    my @removed = %prev.keys.grep({ !%cur.exists($_) }).sort;
    for @removed -> $k {
        out-line("  - $k (不再声明)");
    }

    # 修改：两边都有但值不同
    my @changed = %cur.keys.grep({ %prev.exists($_) && %prev{$_} ne %cur{$_} }).sort;
    for @changed -> $k {
        out-line("  ~ $k: %prev{$k} → %cur{$k}");
    }

    unless @added || @removed || @changed {
        out-line('  (无变化)');
    }

    # 更新快照
    %WATCH-PREV = %cur;
    Nil
}
