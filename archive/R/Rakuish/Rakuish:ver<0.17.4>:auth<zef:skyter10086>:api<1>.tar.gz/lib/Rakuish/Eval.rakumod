# Rakuish::Eval —— 快档：求值 Raku 表达式并渲染结果
#
# 这个模块只管"给一段 Raku 代码、求出值、把结果显示得好看"。
# **不负责判断输入是 Raku 还是 shell 命令**（那是上一层的事），
# **也不负责读输入**（交互循环自己管，因为要处理多行与提示符）。
#
# ── 实测确定的三条语义（MoarVM 与 rakupp 逐条对拍过）────────────────────
#
# 1. **EVAL 里的 `say` 直接打到真实 stdout，不会被吞。**
#    所以「输出」这件事不需要捕获：`Out[n]` 要显示的**就是 EVAL 的返回值**。
#    这就是本项目相对 shell 的核心便宜之处 —— shell 只能"往 fd1 喷文本"，
#    拿到"最后一个表达式的值"得靠猜（`$?` 那一套），而 EVAL 直接把值给你。
#    副作用输出（say）与返回值（Out[n]）会按顺序都出现，和 IPython 一致。
#
# 2. **EVAL 之间变量互相隔离** —— `my` 变量跨不过去；`our` 变量在 MoarVM 上
#    也跨不过去。**但 EVAL 能看到并修改外层作用域里的词法**（读 `our`、读 `my`
#    数组、`push`、`@a[0]=…`、`$our = …` 全部对外层生效）。
#    → 所以跨 cell 的状态必须挂在一个**外层的容器**上，不能靠 cell 里新建变量。
#    本模块提供 `STORE`（外层 `our %STORE`）与访问例程 `store()`，
#    用法：`STORE{'x'} = 1` 或 `store{'x'} = 1`。两个实现都验证过可用。
#
# 3. **cell 里定义的 sub 不跨 cell**（两个实现都不行）。所以 REPL 需要一个
#    `%`-magic 命令来"定义并记住"函数，而不是指望用户敲一个 `sub` 就留下。
#
# ── 已知的一处实现差异（不影响本模块，但要记着）───────────────────────
#
# `our $x = …` 在 **rakupp 的 EVAL 里会泄漏到外层**，MoarVM 上不会。
# 所以**绝不能**把"cell 里声明 our"当作共享机制 —— 那在 MoarVM 上会失效。
# 本模块只用外层 `our %STORE`（两边行为一致，实测）。

unit module Rakuish::Eval;

use Rakuish::Platform;
use Rakuish::Slow;
use Rakuish::Shell::Engine;   # shell 引擎（`cmd` 内嵌在 Raku 表达式里也走它）
use Rakuish::Result;   # P1：run() → Result（供 EVAL 的 DSL prelude 用）

# 跨 cell 的共享存储。cell 里的代码写 `%STORE{'k'}` 或 `store-set('k', ...)` 会命中这里，
# 因为 EVAL 能看到外层词法（语义 2）。
our %STORE;

# ── 共享存储的访问方式 ────────────────────────────────────────────────
#
# 共享存储的**主API 是过程式的**（store-set / store-get / …），
# 而不是"返回一个可写的 Hash"。原因实测出来的：rakupp 上
# `store(){k} = v` 报 **"Target is not assignable"**（返回的绑定不可赋值），
# 而**直接写 `%STORE{k} = v` 两个实现都正常**（实测过）。
# 一个在两个实现上行为不一致的写法不能当主API。
#
# `store()` 作为只读访问器保留 —— 读是可用的，只是不能拿它写入。

our sub store(--> Hash) is export { %STORE }

our sub store-set(Str $key, Any $value --> Nil) is export {
    %STORE{$key} = $value;
    Nil
}

our sub store-get(Str $key --> Any) is export {
    %STORE{$key}
}

our sub store-has(Str $key --> Bool) is export {
    %STORE{$key}:exists
}

our sub store-del(Str $key --> Nil) is export {
    %STORE{$key}:delete;
    Nil
}

our sub store-keys() is export { %STORE.keys.sort }

# ── 求值结果 ──────────────────────────────────────────────────────────

class CellResult is export {
    has Bool $.ok;
    has Any  $.value  = Nil;   # 成功时的值（可能真的就是 Nil）
    has Any  $.error  = Nil;   # 失败时的异常对象
    has Str  $.source = '';    # 原始输入（错误渲染要用）
    has Int  $.index  = 0;     # 第几个 cell，1 起（字段默认只读，序号在构造时传入）
    has Str  $.extra-output = '';  # 本 cell 自身产生的 stdout（不含历史 cell 的回声）

    # ── 报错定位（P2 修的 $*PROGRAM / 行号偏移两个遗留问题）──────────
    # EVAL 的源码是我们**拼出来**的：`no worries;` + `$*PROGRAM` 声明 +
    # `do { ` + prelude + 历史累积 + 本格源码。所以异常里报的 `line N`
    # 是**拼接后**的行号，离用户看到的差了一大截（P1 之前一律显示 line 1~3，
    # 看起来像"报错行号瞎报"）。
    #   line-shift  = 本格第一行**之前**有多少行是壳子（要减掉）
    #   line-base   = 本格第一行在**源文件**里的行号（脚本 / source 才有）
    #   source-file = 源文件路径（REPL 里为空 ⇒ 只显示格内相对行号）
    has Int  $.line-shift = 0;
    has Int  $.line-base  = 0;
    has Str  $.source-file = '';

    # 用户在本格写了 `exit N`（P4-2）。undefined ⇒ 没有退出请求。
    # 用 undefined 而不是 0 做哨兵：`exit 0` 也是**明确要求退出**，
    # 写成 `= 0` 就没法把"没写 exit"和"exit 0"分开。
    has Int  $.exit-code;
    has Hash $.watch = Hash.new;
    has Int  $.elapsed-ms = 0;   # 本格 eval 耗时（毫秒）
}

# `exit` 在 cell 里不能真的退进程 —— $*OUT 被换成了内存缓冲，真 exit 会把
# 本格已经 say 出来的东西一起带走（脚本表现成"rc=1 但零输出"）。
# 所以 prelude 里的 `exit` 只抛这个异常，由 eval-cell 转成带退出码的
# CellResult，Loop 拿到后再决定什么时候真正结束会话。
class ExitRequest is Exception is export {
    has Int $.code = 0;
    method message(--> Str) { "exit {$!code}" }
}

# 跨 cell 的持久词法状态。会话开头 new 一个，每次成功求值后由 eval-cell 更新。
# 把它传给 eval-cell 的 :state，就能让 my / our / sub / 容器变更跨行可见
#（对齐官方 raku REPL：my $a = 1 之后 say $a 能看到 $a）。不传则退化为
# 单次孤立 EVAL（旧行为，供单测 / magic 命令使用）。
class LexState is export {
    has Str $.accum     is rw = q{};   # 已成功求值的源码累积缓冲
    has Str $.prev-out  is rw = q{};   # 上一 cell 为止已展示的 stdout（用于算 delta）
}

# 临时充当 $*OUT 的内存接收器：把 cell 里的 say / print 收进数组，
# 求值结束后 join 成字符串，方便只回显"本次新增"的输出。
my class CapturingOut {
    has @.cap = ();
    # 方法返回 True（对齐真实 IO::Handle 的 say/print/put），否则会把 say 的
    # 返回值（True）污染成 Nil/Any，进而让整段 EVAL 的返回值丢失。
    method print(*@a) { @!cap.push(@a.map(*.Str).join(q{})); True }
    method say(*@a)   { @!cap.push(@a.map(*.Str).join(q{}) ~ "\n"); True }
    method put(*@a)   { @!cap.push(@a.map(*.Str).join("\n") ~ "\n"); True }
    method flush()     { Nil }
    method nl-out()    { "\n" }
}

# 求值一段代码。
#
# 持久词法上下文：传了 :state 时，把每条成功求值的源码（原始、不含 no worries）
# 累加成完整缓冲，每次对整份缓冲重新 EVAL —— 于是跨行的 my/our/sub/容器变更都"留下"。
# stdout 临时重定向到内存，重跑历史时不会把旧 cell 的 say 回声再打一遍，
# 只回显"本次新增的输出"（delta = 当前总输出 减去 上一 cell 已展示部分）。
# no worries 只在"真正 EVAL 的那一份"开头加一次，避免重复累加到缓冲里。

# ── 嵌入反引号：`` `cmd` `` 当 bash 式 shell 捕获，内嵌进 Raku 表达式 ────────
# Raku 语言本身没有反引号运算符，所以成对的 `` `cmd` `` 在 Raku 源码里是语法错误。
# 这里在 EVAL 之前做一层源码变换：把源码里成对的反引号（仅当不在字符串/正则/
# 注释内）替换成 Rakuish::Eval::__shellq__('cmd') 调用，让 shell 的输出作为字符串
# 值参与表达式。例如 `my $x = `pwd`` → `my $x = Rakuish::Eval::__shellq__('pwd')`。

# 把命令文本安全地嵌成 Raku 单引号字面量（Raku 单引号里只有 '' 是转义）。
our sub quote-str-for-raku(Str $s --> Str) is export {
    "'" ~ $s.subst(q{'}, q{''}, :g) ~ "'"
}

# 反引号扫描：跳过字符串/正则/注释，收集"裸"反引号对。
our sub expand-backticks(Str $src --> Str) is export {
    return $src unless $src.contains('`');
    my @out;
    my $i = 0;
    my $n = $src.chars;
    my $st = 'normal';        # normal | sq | dq | bq | rx | comment
    my $open; my $close;      # 括号引号的成对错配
    my $bq-depth = 0;
    while $i < $n {
        my $c = $src.substr($i, 1);
        if $st eq 'comment' {
            @out.push($c);
            $st = 'normal' if $c eq "\n";
            $i++; next;
        }
        if $st eq 'sq' {                    # 单引号：'' 转义
            @out.push($c);
            if $c eq q{'} {
                if $i + 1 < $n && $src.substr($i+1,1) eq q{'} { $i += 2; next; }
                $st = 'normal';
            }
            $i++; next;
        }
        if $st eq 'dq' {                    # 双引号：\ 转义
            @out.push($c);
            if $c eq '\\' { @out.push($src.substr($i+1,1)); $i += 2; next; }
            $st = 'normal' if $c eq q{"};
            $i++; next;
        }
        if $st eq 'bq' {                    # 括号引号 q[...]/qq{...}/...：按括号嵌套
            @out.push($c);
            if $c eq $open { $bq-depth++; }
            elsif $c eq $close {
                $st = 'normal' if $bq-depth == 0;
                $bq-depth-- if $bq-depth > 0;
            }
            $i++; next;
        }
        if $st eq 'rx' {                    # 正则字面量 /.../：\ 转义，遇 / 关闭
            @out.push($c);
            if $c eq '\\' { @out.push($src.substr($i+1,1)); $i += 2; next; }
            $st = 'normal' if $c eq '/';
            $i++; next;
        }
        # ---- normal ----
        if $c eq '#' { $st = 'comment'; @out.push($c); $i++; next; }
        if $c eq q{'} { $st = 'sq'; @out.push($c); $i++; next; }
        if $c eq q{"} { $st = 'dq'; @out.push($c); $i++; next; }
        # 括号引号：q/Q（可带 qx/qw/v 与 adverb）后接 [ ( { <
        if $c eq 'q' | 'Q' {
            my $prev = $i > 0 ?? $src.substr($i-1,1) !! ' ';
            my $wordy = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$@%&.'.contains($prev) || $prev eq ']';
            if !$wordy {
                if $src.substr($i) ~~ /^ [ 'q' | 'Q' ] [ 'q' | 'x' | 'w' | 'wv' | 'ww' | 'v' ]? ':'? <[a..z]>* $<brk>=('[' | '(' | '{' | '<') / -> $m {
                    my $b = $m<brk>.Str;
                    $open  = $b;
                    $close = $b eq '[' ?? ']' !! $b eq '(' ?? ')' !! $b eq '{' ?? '}' !! '>';
                    $bq-depth = 0;
                    $st = 'bq'; @out.push($c); $i++; next;
                }
            }
        }
        # 正则字面量：m/ rx/ s/ ms/ ss/ tr/ 后紧跟 /（s/// 等只关第一个 /，足够覆盖常见写法）
        if $src.substr($i) ~~ /^ [ 'm' | 'rx' | 's' | 'ms' | 'ss' | 'tr' ] \s* '/' / -> $m {
            $st = 'rx'; @out.push($c); $i++; next;
        }
        # 裸 `/`：仅当左侧（跳过空白）是 ~ 或 = 时按正则处理（如 ~~ /x/、=~ /x/），避免误伤除法 a / b
        if $c eq '/' {
            my $j = $i - 1;
            while $j >= 0 && ($src.substr($j,1) eq ' ' || $src.substr($j,1) eq "\t") { $j--; }
            if $j >= 0 && ($src.substr($j,1) eq '~' || $src.substr($j,1) eq '=') {
                $st = 'rx'; @out.push($c); $i++; next;
            }
        }
        if $c eq '`' {
            my $k = $i + 1;
            my $cmd = '';
            while $k < $n && $src.substr($k,1) ne '`' { $cmd ~= $src.substr($k,1); $k++ }
            if $k < $n {
                @out.push('Rakuish::Eval::__shellq__(' ~ quote-str-for-raku($cmd) ~ ')');
                $i = $k + 1; next;
            }
            @out.push($c); $i++; next;
        }
        @out.push($c); $i++;
    }
    @out.join
}

# 真正执行 shell 并把 stdout 作为字符串返回（剥掉尾部换行，对齐 bash 行为）。
# 放在 Eval 包里，EVAL 出的用户代码通过全限定名直接引用。
#
# ⚠ 走**引擎**（不是 `Slow::run-shell`）：后者是 `sh -c` ⇒ 本机是 **dash**
#   （没有 brace 展开、没有 `[[ ]]`），而且**看不到会话变量**。
our sub __shellq__(Str $cmd --> Str) is export {
    my $r = Rakuish::Shell::Engine::run-engine($cmd, :capture(True));
    my $out = ($r.stdout // '').Str;
    $out.subst(/\n+$/, '', :g)
}

# EVAL 的返回值包装。见 wrap-eval-source 的注释。
my class EvalWrap { has $.value; has Hash $.watch = Hash.new }

our sub __eval-wrap($v, Hash :$watch = Hash.new) { EvalWrap.new(:value($v), :$watch) }

# 把要 EVAL 的源码包成：
#
#     my $__rakuish-eval = do { <源码>
#     }; Rakuish::Eval::__eval-wrap($__rakuish-eval)
#
# 为什么不能直接 `EVAL($src)`：
#   EVAL 块的**最后一个表达式**就是 EVAL 的返回值。若它是 Failure
#   （例：`my @a=(1,2,3); @a<0>`），MoarVM 会 FATALIZE（抛异常）并把那个
#   Failure 留在已废弃的帧里 —— 即使 `try` 已经接住异常，后续 GC 仍会打
#   `WARNING: unhandled Failure detected in DESTROY`（污染 REPL 与测试输出）。
#   赋值上下文 `my $x = do { … }` **不会** sink Failure；再用一个非 Failure
#   的包装对象返回，就不会留下未处理的 Failure。拆包在 eval-cell 里做。
# EVAL 的 DSL prelude：把 `run` / `run-pipe` 绑到 Rakuish::Result。
#
# 放在 do 块的**最前面**声明：Raku 的 sub 在本块内是全序可见的（实测——
# 块内后续代码能直接调到），所以用户代码无论写在第几行都命中它。
#
# ⚠ 这层**遮蔽是有意的**：Rakuish 里 `run('ls')` 就该拿到 Result 而不是
#   Proc。要原生 Process 请在自己的脚本里显式写 `my &cr = &CORE::run;`
#   再用 cr(...)。
#
# P2 起再补三个**同名内建转发**：`pwd` / `test` / `type`。
# 为什么不干脆都写成 Raku 方法：用户在 Raku 表达式里想用 shell 的判断
# （`if test('-f', $f) {…}`）时，有个同名的 Raku 版最顺手；
# 而裸写 `pwd` / `test -f x` 这类**命令行形态**由宿主内建拦（Builtins），
# 走不到这里。两套入口共用一份实现（Builtins 里的 sub），语义不会漂。
# ── ENV ↔ 动态变量桥接（方案 A 统一命名空间）────────────────
#
# 每次 eval-cell 重建 do 块 → 这些绑定每次都重新求值 → 自动读到
#   最新的 %*ENV（export 之后下次 eval 立即可见；unset 之后变 Nil）。
#
# 为什么不在外层用 state/our 存一份快照：Raku 里写 export 改的是
#   %*ENV，快照会 stale；而且每次只绑 10 来个变量，开销可以忽略。
#
# 为什么挑这几个：bash 程序员**真会敲**的那批。`export` / `my_var`
#   之外最常见的就是读环境：PATH/PWD 改路径、TERM/LANG 调环境、
#   EDITOR/VISUAL 改编辑器、HOSTNAME 取主机名。
#
# 注意：$*HOME / $*USER Raku 内置已有值，这里就不重复绑了。
#       $*UID / $*GID / $*VERSION / $*OS Raku 声称有但实测 Nil，
#       不在这里浪费绑定槽位。
my constant DSL-PRELUDE = q:to/PRE/;
    sub run(*@a, *%n) { Rakuish::Result::run(|@a, |%n) }
    sub run-pipe(*@a, *%n) { Rakuish::Result::run-pipe(|@a, |%n) }
    sub pwd(--> Str) { Rakuish::Builtins::pwd() }
    sub test(*@a --> Bool) { Rakuish::Builtins::test-args(|@a) }
    sub type(Str $w --> Str) { Rakuish::Builtins::type-of($w) }
    sub exit(Int $code = 0 --> Nil) { Rakuish::Eval::ExitRequest.new(:$code).throw }
    # C3: run 便捷变体 — 省掉 .out / .ok / .out.lines 样板
    sub run-lines(*@a, *%n) { Rakuish::Result::run(|@a, |%n).out.lines }
    sub run-out(*@a, *%n)   { Rakuish::Result::run(|@a, |%n).out }
    sub run-ok(*@a, *%n)    { Rakuish::Result::run(|@a, |%n).ok }
    # ENV → 动态变量桥接（每次 eval 重建，自动读最新值）
    my $*PATH    := (%*ENV<PATH>    // Nil);
    my $*PWD     := (%*ENV<PWD>     // Nil);
    my $*OLDPWD  := (%*ENV<OLDPWD>  // Nil);
    my $*SHELL   := (%*ENV<SHELL>   // Nil);
    my $*TERM    := (%*ENV<TERM>    // Nil);
    my $*LANG    := (%*ENV<LANG>    // Nil);
    my $*LC_ALL  := (%*ENV<LC_ALL>  // Nil);
    my $*EDITOR  := (%*ENV<EDITOR>  // Nil);
    my $*VISUAL  := (%*ENV<VISUAL>  // Nil);
    my $*HOSTNAME:= (%*ENV<HOSTNAME>// Nil);
    my $*LOGNAME := (%*ENV<LOGNAME> // Nil);
    my $*DISPLAY := (%*ENV<DISPLAY> // Nil);
    PRE

# ── EVAL 壳子的拼装（唯一定义点）────────────────────────────────────
#
# ⚠ 壳子有几行**必须**由一处算出来：`eval-cell` 用它算 `line-shift`
#   （报错行号要减掉壳子），`wrap-eval-source` 用它拼源码。
#   分成两份写就一定会漂（改一处忘了另一处 ⇒ 行号整体偏移）。
#
# $*PROGRAM 为什么要在这里遮蔽：Raku 的 `$*PROGRAM` 是**不可变**的
# IO::Path，`$*PROGRAM = …` 直接抛 "Cannot modify an immutable"。但
# `my $*PROGRAM := …`（**绑定**动态变量）在 do 块内可行（实测），
# 于是用户代码里的 `$*PROGRAM` / `$*PROGRAM.basename` 在脚本模式下
# 能拿到真脚本路径 —— P0 遗留问题，P2 一并修掉。
our Str $SOURCE-FILE is export = q{};   # 非空 ⇒ 处于脚本 / source 模式

sub program-pre(--> Str) {
    return q{} unless $SOURCE-FILE.chars;
    'my $*PROGRAM := IO::Path.new(' ~ quote-str-for-raku($SOURCE-FILE) ~ ");\n"
}

sub eval-prefix(Bool :$noworries = False --> Str) {
    ($noworries ?? "no worries;\n" !! q{})
        ~ program-pre()
        ~ 'my $__rakuish-eval = do { ' ~ DSL-PRELUDE
}

# 壳子占了几行（= 用户第一行之前的换行数）
sub prefix-lines(Bool :$noworries = False --> Int) {
    my $p = eval-prefix(:$noworries);
    # ⚠ Str 上**没有** `.count` 方法（那是 IO::Handle / List 的）—— 用 comb 数换行。
    $p.chars ?? $p.comb("\n").elems !! 0
}

# ── C2: $[VAR] → %*ENV<VAR> 预处理 ─────────────────────────────
# 在源码进 EVAL 之前扫一遍，把 $[HOME] / $[PATH] 这种语法替换成 %*ENV<VAR>。
#
# 为什么是预处理：比自定义 term grammars 简单得多，且零副作用。
#
# 匹配规则：
#   · $[ 后必须是字母或下划线开头的单词字符组 → 替换成 %*ENV<...>
#   · $[数字开头]（如 $[1]、$[0..3]）是合法 Raku 数组索引 → 不匹配
#
# 在字符串/正则/注释内的 $[VAR] 也会被替换——但这些上下文里的
# $[VAR] 本来就是语法错误（Raku 不认识），替换成 %*ENV<VAR> 反而能跑。
our sub expand-shell-env-brackets(Str $src --> Str) is export {
    return $src unless $src.contains('$[');
    $src.subst(:g, / '$[' $<name>=(<[A..Z a..z _]> \w*) ']' /,
               -> $/ { '%*ENV<' ~ $<name>.Str ~ '>' })
}

sub wrap-eval-source(Str $src, Bool :$noworries = False, :@watch-vars --> Str) {
    my $body = expand-shell-env-brackets($src);

    unless @watch-vars {
        # 普通模式（没有 watch），保持原有行为
        return eval-prefix(:$noworries) ~ $body ~ "\n"
            ~ '}; Rakuish::Eval::__eval-wrap($__rakuish-eval)';
    }

    # ── watch 模式：在 do { } 块开头注入 LEAVE phaser ──
    # LEAVE 在块退出前运行，通过 EVAL('$var-name') 在运行时访问变量
    # （绕开编译时作用域检查，同时不影响 do 块的返回值）
    # 只用单引号字符串 + 拼接，彻底避开双引号插值 & qq{} 花括号平衡陷阱
    my $nl = "\n";
    my $indent = '            ';
    my $leave = '
        LEAVE {
            my %__rw = Hash.new;' ~ $nl;
    for @watch-vars -> $vn {
        # 生成形如: try { %__rw{'$x'} = EVAL('$x').raku }
        # $vn.raku 会把 '$x' 变成 Raku 字面量形式 '$x'（带单引号）
        $leave ~= $indent ~ 'try { %__rw{' ~ $vn.raku ~ '} = EVAL(' ~ $vn.raku ~ ').raku }' ~ $nl;
    }
    $leave ~= $indent ~ '$*RAKUISH-WATCH = %__rw;' ~ $nl ~ '        }' ~ $nl;

    my $prefix = eval-prefix(:$noworries);
    return $prefix ~ $leave ~ $body ~ "\n"
        ~ '}; Rakuish::Eval::__eval-wrap($__rakuish-eval, :watch($*RAKUISH-WATCH // Hash.new))';
}
our sub eval-cell(Str $src, Int :$index = 0, LexState :$state,
                  Int :$line-base = 0 , Bool :$watch = False --> CellResult) is export {
    my $accumulate = $state.defined;
    my $raw = $src;
    $raw = ($state.accum ?? $state.accum ~ ";\n" !! q{}) ~ $src if $accumulate;

    # 嵌入形式 `` `cmd` ``：把成对的 `` `cmd` `` 展开成 Rakuish::Eval::__shellq__('cmd')，
    # 让 shell 输出能内嵌进 Raku 表达式（bash 式捕获，剥掉尾部换行、保留内部换行）。
    my $eval-src = $accumulate ?? expand-backticks($raw) !! expand-backticks($src);

    # ── 定位信息（报错行号用）──────────────────────────────────────
    # 壳子行数 + 历史累积行数 = 本格源码在 EVAL 源码里的偏移。
    my $nw = $accumulate;
    my $shift = prefix-lines(:noworries($nw));
    $shift += ($state.accum ~ ";\n").comb("\n").elems if $accumulate and $state.accum.chars;
    my %loc = (line-shift => $shift, line-base => $line-base,
               source-file => $SOURCE-FILE);

    my $v;
    my $t0 = now;                # 计时起点
    my $watch-snap = Hash.new;   # watch 模式快照：默认空 hash，EvalWrap 解包后覆盖
    my $cap = q{};
    my $sink;                       # 声明在外：exit 路径要从中取已产出的输出
    my @watch-names;                         # watch 模式：待提取的变量名列表
    if $accumulate {
        # no worries 仅在此处加一次，抑制重跑历史表达式时产生的
        # "Useless use of X in sink context" 软警告（对齐官方 REPL 不重跑故不告警）。
        # P2：改由 wrap-eval-source 的 :noworries 注入（壳子行数才算得准）。
        # ── watch 模式：从累积源码提取变量名 ──
        if $watch {
            my $src-for-watch = $accumulate ?? ($state.accum ~ ";" ~ $src) !! $src;
            for $src-for-watch.lines -> $lnw {
                my $t = $lnw.trim;
                next if $t.chars == 0;
                if $t.starts-with('my ') || $t.starts-with('our ') || $t.starts-with('state ') {
                    my $rest = $t;
                    $rest = $rest.subst(/^ my \s+/, '');
                    $rest = $rest.subst(/^ our \s+/, '');
                    $rest = $rest.subst(/^ state \s+/, '');
                    if $rest ~~ /^ (<[$@%&]> \w+) / {
                        push @watch-names, ~$/[0];
                    }
                }
            }
        }
        my $trial = $eval-src;
        $sink = CapturingOut.new;
        my $*OUT = $sink;
        $v = try { EVAL(wrap-eval-source($trial, :noworries($nw), :watch-vars(@watch-names))) };
        $cap = $sink.cap.join;
    }
    else {
        # 旧行为：直接打到真实 stdout，不捕获（magic 走这，其跨 cell 状态靠 %STORE）
        $v = try { EVAL(wrap-eval-source($eval-src, :noworries($nw), :watch-vars(@watch-names))) };
    }

    # 注意：`try` 失败时返回**未定义值**，所以只能看 `$!`判断成败（Platform 规则 1）。
    if $! {
        my $ex = $!;
        if $ex ~~ ExitRequest {
            # `exit N` 不是错误：把这一格已经打印的输出照 delta 规则交回去，
            # 再由 Loop 决定何时结束（脚本模式 = 打印后立刻退出，退出码 N）。
            $cap = $sink ?? $sink.cap.join !! q{};
            my $d = $cap;
            if $accumulate {
                my $start = min($state.prev-out.chars, $cap.chars);
                $d = $cap.substr($start);
                $state.accum    = $raw;
                $state.prev-out = $cap;
            }
            return CellResult.new(:elapsed-ms(Int((now - $t0).Num * 1000)),:ok(True), :value(Nil), :error(Nil),
                                  :exit-code($ex.code), :source($src),
                                  :index($index), :extra-output($d), |%loc);
        }
        return CellResult.new(:elapsed-ms(Int((now - $t0).Num * 1000)),:ok(False), :value(Nil), :error($ex), :source($src),
                              :index($index), :extra-output(q{}), :watch($watch-snap), |%loc);
    }

    # 拆包（见 wrap-eval-source）。最后一个表达式是 Failure 时，赋值上下文
    # 不会 sink 它 ⇒ 这里把它当**错误**处理，并先标记 handled，避免 GC 时
    # 打 "unhandled Failure detected in DESTROY"。
    if $v ~~ EvalWrap {
        $watch-snap = try { $v.watch } // Hash.new;
        my $val = $v.value;
        if $val ~~ Failure {
            my $ex = $val.exception;
            $val.Bool;      # 标记已处理（.Bool 只做处置，不抛）
            return CellResult.new(:elapsed-ms(Int((now - $t0).Num * 1000)),:ok(False), :value(Nil), :error($ex), :source($src),
                                  :index($index), :extra-output(q{}), :watch($watch-snap), |%loc);
        }
        $v = $val;
    }

    my $delta = q{};
    if $accumulate {
        my $start = min($state.prev-out.chars, $cap.chars);
        $delta = $cap.substr($start);
        $state.accum    = $raw;     # 存原始源码（不含 no worries），下次再拼
        $state.prev-out = $cap;
    }
    else {
        $delta = $cap;   # 未累积时捕获量本就只有本次（此分支 magic 不捕获，恒为空）
    }
    CellResult.new(:elapsed-ms(Int((now - $t0).Num * 1000)),:ok(True), :value($v), :error(Nil), :source($src), :index($index),
                   :extra-output($delta), :watch($watch-snap), |%loc)
}

# ── P5-1：脚本模式整份文件当一个编译单元 ──────────────────────────────
#
# G3 的根因是「脚本也走 REPL 的句级驱动」：eval-cell 每格把整份缓冲重
# EVAL，于是 spurt / mkdir / rename 这些副作用跟着重跑（stress/05 的幂等
# 检查因此假失败），耗时还是 O(n²)。脚本不是 REPL —— 它本来就该整份
# 编译一次、执行一次。
#
# 与 eval-cell 的三点不同（都是脚本语义要求的）：
#
# 1. **不累积、不重放**：整份 body 只 EVAL 一次，副作用只发生一次。
# 2. **不包 `do { }`**：`use v6.d;` 必须是编译单元的第一条**语句**；
#    包进 do 块后它就落在块首，实测照样报 "Too late to switch language
#    version"（EVAL 的语言版本切换在编译单元层面生效）。所以 body 直接
#    放在单元顶层。代价是失去"外层词法"这层容器 —— 脚本不需要它。
# 3. **DSL prelude 挂在尾部**：同一编译单元里 sub 是全序可见的（与 REPL
#    壳子同一机制，实测），挂尾部就不会把用户第一行的 `use v6.d;` 顶到
#    非首位置。
#
# `$prepend` 由上层（Rakuish::Script）算：把用户写在文件里、但**必须置首**
# 的 `use v6.x` 提到最前面，原位置留空行 —— 这样文件行号一个不差
#（prepend 的行数已经算进 line-shift）。
our sub eval-program(Str $body, Str :$prepend = q{}, Bool :$noworries = True,
                     Int :$line-base = 1, :&cell-hook = Nil --> CellResult) is export {
    my $pre = $prepend ~ ($noworries ?? "no worries;\n" !! q{}) ~ program-pre();
    # ⚠ body 末尾必须有分号：DSL-PRELUDE 紧跟其后（sub run / my $*PATH …），
    #   若 body 最后一行无分号（`say 42`），Raku 会把它和下一行的 `sub run`
    #   当成连续 term → "Two terms in a row across lines"。
    #   多一个分号无害（空语句），所以无条件补。
    my $src = $pre ~ $body ~ ";\n" ~ DSL-PRELUDE;
    # 脚本模式的格回调走**动态变量**，不走 `Rakuish::Loop::__script-cell__`
    # 这种包限定名：EVAL 单元里解析包限定名会退化成运行时 stash 查找，
    # 在模块内部发起的 EVAL 里会莫名 "Could not find symbol"（实测）。
    # 动态变量在编译期只是个 `$*` 名字，稳定且省一次 stash 查找。
    my $*RAKUISH-CELL-HOOK := &cell-hook;
    my %loc = (line-shift => $pre.comb("\n").elems, :$line-base,
               source-file => $SOURCE-FILE);
    if %*ENV<RAKUISH_DEBUG_ASM> {
        $*ERR.say: "==== EVAL SOURCE ====";
        for $src.lines.kv -> $i, $l { $*ERR.say: "{($i + 1).fmt('%3d')}| {$l}" }
        $*ERR.say: "==== END EVAL SOURCE ====";
    }
    my $v = try { EVAL($src) };
    if %*ENV<RAKUISH_DEBUG_ASM> and $! {
        $*ERR.say: "==== EVAL FAIL BACKTRACE ====";
        $*ERR.say: $!.backtrace.full;
        $*ERR.say: "==== END BACKTRACE ====";
    }
    if $! {
        my $ex = $!;
        # `exit N` 不是错误：脚本模式由调用方决定退出码。
        if $ex ~~ ExitRequest {
            return CellResult.new(:ok(True), :value(Nil), :error(Nil),
                                  :exit-code($ex.code), :source($body),
                                  :extra-output(q{}), |%loc);
        }
        return CellResult.new(:ok(False), :value(Nil), :error($ex),
                              :source($body), :extra-output(q{}), |%loc);
    }
    CellResult.new(:ok(True), :value(Nil), :error(Nil), :source($body),
                   :extra-output(q{}), |%loc)
}

# ── 会话：In[n] / Out[n] / `_` ─────────────────────────────────────────

class Session is export {
    has @in;
    has @out;

    method run(Str $src --> CellResult) {
        my $r = eval-cell($src, :index(@in.elems + 1));
        @in.push: $src;
        # 成功才记 Out —— 与 IPython 一致：报错的 cell 不占 Out 编号。
        @out.push: $r.value if $r.ok;
        $r
    }

    # Out[n]（1 起，与 In 平行）
    method out-at(Int $n --> Any) {
        return Nil if $n < 1 or $n > @out.elems;
        @out[$n - 1]
    }

    method in-at(Int $n --> Str) {
        return '' if $n < 1 or $n > @in.elems;
        @in[$n - 1]
    }

    # `_` = 最近一次成功求值的值；一次都没有时是 Nil（不是报错）
    method last-value(--> Any) {
        @out.elems ?? @out[*-1] !! Nil
    }

    method out-count(--> Int) { @out.elems }
}

# ── 值的渲染 ──────────────────────────────────────────────────────────

# ANSI 颜色。两个实现都原样透传转义序列（Platform 已验证），所以这里
# 只需要决定"什么时候用颜色"：给了 :color 就用。
our %COLOR = (
    'nil'=> "\e[90m", 'bool'  => "\e[35m", 'int'  => "\e[36m",
    'num'=> "\e[33m", 'str'   => "\e[32m", 'list' => "\e[37m",
    'hash'=> "\e[37m", 'obj'   => "\e[34m", 'reset'=> "\e[0m",
    'out'=> "\e[1m\e[36m", 'err' => "\e[31m",
);

# 值 → 该用哪档颜色。注意 **Bool 是 Int 的子类**，所以要先判 Bool。
our sub color-of($v --> Str) {
    return 'nil' unless defined $v;
    return 'bool' if $v ~~ Bool;
    return 'int' if $v ~~ Int;
    return 'num' if $v ~~ Numeric;
    return 'str' if $v ~~ Str;
    return 'list' if $v ~~ Iterable && $v !~~ Hash;
    return 'hash' if $v ~~ Hash;
    'obj'
}

# dump 风格渲染的参数：
# - $DUMP-WIDTH：单行 dump 超过这个字符数就改成"头尾采样/截断"，避免刷屏。
# - $SAMPLE：大容器采样时头尾各显示几个元素。
our $DUMP-WIDTH = 1200;
our $SAMPLE = 4;

# 多行缩进用的竖线。用 chr(0x2502) 而不是转义写法：
# 本版 Rakudo 不支持 `\x{...}` 花括号形式（报 "Unsupported use of curlies"）。
our $BAR = chr(0x2502);

our sub format-value($v, Bool :$color = False --> Str) is export {
    # REPL 传入的 cell 值被包在 Scalar 容器里；不先 decont 的话：
    #   - .raku 会多打一个 $ 前缀（$[1,2,3] 而非 [1,2,3]）
    #   - color-of 会把 Array/List 误判为 obj
    #   - sample-value 的 $v ~~ Array 失败、括号选错
    # 用无符号别名取出真实值（不能赋给 my $x，否则又包回 Scalar、前缀重现）。
    my \val = $v<> ;
    return paint('nil', 'Nil', $color) unless defined val;
    my $kind = color-of(val);

    # Bool 用紧凑形式；其余走 dump（.raku：dd 底层同款，忠实且可重建）
    my $text = val ~~ Bool ?? (val ?? 'True' !! 'False')
                         !! (try { val.raku } // '(无法显示)');
    $text = '(无法显示)' if $!;

    # 多行值（含换行的 Str 等）加竖线缩进，避免糊成一片
    my @lines = $text.lines;
    if @lines.elems > 1 {
        return paint($kind, @lines.map({ $BAR ~ ' ' ~ $_ }).join("\n"), $color);
    }

    # 单行但过长：容器做"头尾采样"，其余截断，避免超长一行刷屏
    if $text.chars > $DUMP-WIDTH {
        $text = ($kind eq 'list' || $kind eq 'hash')
            ?? sample-value(val, $kind)
            !! $text.substr(0, $DUMP-WIDTH) ~ '…';
    }
    paint($kind, $text, $color)
}

# 大容器采样：头尾各 $SAMPLE 个元素 + 真实总数，绝不静默隐藏内容。
our sub sample-value($v, Str $kind --> Str) {
    my @items = $kind eq 'hash' ?? $v.pairs.map(*.raku) !! $v.list.map(*.raku);
    my $n = @items.elems;
    return '()' if $n == 0;
    my $s = $SAMPLE;
    my @head = @items[0 .. min($s, $n) - 1];
    my @tail = $n > 2 * $s ?? @items[$n - $s .. $n - 1] !! ();
    my $body = @head.join(', ');
    $body ~= ', …' if @tail.elems || $n > $s;
    $body ~= ', ' ~ @tail.join(', ') if @tail.elems;
    my $open  = $kind eq 'hash' ?? '{' !! ($v ~~ Array ?? '[' !! '(');
    my $close = $kind eq 'hash' ?? '}' !! ($v ~~ Array ?? ']' !! ')');
    $open ~ $body ~ $close ~ " ({$n} items)";
}


our sub paint(Str $kind, Str $text, Bool $color --> Str) {
    return $text unless $color;
    my $c = %COLOR{$kind} // '';
    $c ?? $c ~ $text ~ %COLOR<reset> !! $text
}

# `Out[3]: 42`
our sub render-out(Int $n, $v, Bool :$color = False --> Str) is export {
    my $label = paint('out', "Out[{$n}]:", $color);
    $label ~ ' ' ~ format-value($v, :$color);
}

# 反引号捕获的渲染：把 shell 的 stdout 当作本 cell 的值。
# 多行原样保留（不做 dump 转义），读起来和终端一致；单行则与 Out[n] 同行。
our sub render-shell-capture(Int $n, Str $val, Bool :$color = False --> Str) is export {
    my $label = paint('out', "Out[{$n}]:", $color);
    return $label if $val eq q{};
    my @lines = $val.split("\n");
    return $label ~ ' ' ~ @lines[0] if @lines.elems == 1;
    $label ~ "\n" ~ @lines.map({ '  ' ~ $_ }).join("\n");
}

# ── P3：裸 `run` 的展示 ───────────────────────────────────────────────
#
# REPL 里敲 `run 'ls'`，要看的就是命令输出，而不是
# `Result(code=0 · 12 行 · …)` 这种摘要。所以**裸 run 调用**把 stdout
# 直接当本 cell 的输出渲染（多行缩进两格，与反引号捕获一致）。
#
# 判定落在**源码**上而不是结果上：`my $r = run 'ls'` 这种赋值不该刷屏，
# 它仍走 Result 摘要；脚本模式也不会自动打印（say-ui 被静音）。
our sub bare-run-src(Str $src --> Bool) is export {
    my $t = $src.trim;
    so $t ~~ /^ ['run'|'run-pipe'] [ '(' | \s ]/
}

our sub render-result-out(Int $n, $r, Bool :$color = False --> Str) is export {
    my $label = paint('out', "Out[{$n}]:", $color);
    my $out = $r.out.subst(/\n+$/, q{}, :g);
    my $err = $r.err.subst(/\n+$/, q{}, :g);
    my @parts;
    if $out ne q{} {
        my @lines = $out.split("\n");
        @parts.push(@lines.elems == 1 ?? $label ~ ' ' ~ @lines[0]
                                      !! $label ~ "\n" ~ @lines.map({ '  ' ~ $_ }).join("\n"));
    }
    else {
        @parts.push($label ~ ' ' ~ paint('nil', '(无输出)', $color));
    }
    @parts.push('stderr: ' ~ $err) if $err ne q{};
    @parts.push("[退出码 {$r.code}]") if $r.code != 0;
    @parts.join("\n")
}

# ── 错误渲染 ──────────────────────────────────────────────────────────

# 错误块自己的配色（与值渲染的 %COLOR 解耦：错误需要更多层级——
# 头 / 类别 / 消息 / 源码 / 提示各一档）。
our %ERR-COLOR = (
    'head'   => "\e[1m\e[31m",   # "错误" 标签：粗红
    'kind'   => "\e[90m",        # 错误类别：暗灰
    'msg'    => "\e[0m",         # 消息正文：保持默认可读
    'src'    => "\e[36m",        # 出错源码：青
    'gutter' => "\e[90m",        # 源码行首标记
    'hint'   => "\e[90m",        # 提示：暗灰
    'tok'    => "\e[1m\e[33m",   # 出错标识符：粗黄，在青色源码里跳出来
    'reset'  => "\e[0m",
);

sub e-paint(Str $k, Str $t, Bool $color --> Str) {
    return $t unless $color;
    my $c = %ERR-COLOR{$k} // '';
    $c ?? $c ~ $t ~ %ERR-COLOR<reset> !! $t
}

# 异常 → 多行、分级的错误块：
#     错误 · 类别
#       消息正文（可能多行，不再截断到一行）
#
#       » 出错的那一行源码
#
#       提示: 下一步建议
# 刻意不做"带 caret 的源码摘录"：两个实现都没有可靠的列号
#（MoarVM 的 EVAL 编译错误只在消息里，rakupp 连 <HERE> 都没有、`.column` 是 Any），
# 与其渲染一个假的 caret，不如把"完整（过滤后）消息 + 出错行 + 分类 + 提示"做扎实。
our sub render-error(CellResult $r, Bool :$color = False, Bool :$script = False --> Str) is export {
    my $e    = $r.error;
    my $kind = classify-error($e);
    my $msg  = remap-message-lines($r, clean-message($e));

    # ── 脚本模式：**无装饰** ────────────────────────────────────────
    #
    # 契约（PLAN-C 第 45 行）：「脚本 | … | **无装饰，只有程序输出**；出错即停」。
    # 脚本里**没有 cell、没有 `_`**，所以 REPL 那套装饰全都不该出现：
    #   · 「错误 · 类别」头 —— REPL 的分级装饰
    #   · 「» 出错的那一行源码」—— 在脚本里那是**拼出来的编译单元**
    #     （甚至会显示 `$*RAKUISH-CELL-HOOK(…)` 这种内部包装），
    #     是实现细节，还会把人引到错的行上
    #   · 「提示: 下一步建议」—— 全是 REPL 的话（「输入 _ 可以看上一个结果」
    #     在脚本里没有意义）
    # 只留「文件:行号」+ 消息正文 —— 像编译器那样。
    if $script {
        my @s;
        my $loc = error-location($e, $r);
        @s.push: e-paint('gutter', "{$loc}", $color) if $loc ne q{};
        for $msg.lines -> $ml {
            @s.push: e-paint('msg', $ml, $color);
        }
        return @s.join("\n");
    }

    my @out;
    # 头部：粗红「错误」+ 暗灰「· 类别」
    @out.push: e-paint('head', '错误', $color) ~ e-paint('kind', " · {$kind}", $color);
    # 出错位置：`/path/x.rakuish:4`。**只对编译期异常有**（`.line` 是编译器
    # 给的，运行时异常靠 `.backtrace`，那串栈对用户没意义）。
    my $loc = error-location($e, $r);
    @out.push: e-paint('gutter', "  {$loc}", $color) if $loc ne q{};
    # 消息正文（可能多行），逐行缩进
    for $msg.lines -> $ml {
        @out.push: '  ' ~ e-paint('msg', $ml, $color);
    }
    # 出错的那一行源码（并在其中高亮"出错的那个标识符"）
    my $bad = offending-line($r.source);
    my $tok = offending-token($msg);
    if $bad.defined {
        @out.push: '';
        @out.push: e-paint('gutter', '  » ', $color) ~ highlight-token($bad, $tok, $color);
    }
    # 下一步提示
    @out.push: '';
    @out.push: e-paint('hint', '  提示: ' ~ hint-for($r), $color);
    @out.join("\n")
}

# ── 行号重映射 ───────────────────────────────────────────────────────
#
# 异常消息里的 `… used at line 7` 指的是**拼接后的 EVAL 源码**第 7 行。
# 用户看到的是"我在第 2 行写的"，或者脚本的"文件第 12 行"。
# 归一到用户视角：
#   相对行 = 报出的行 - 壳子行数（line-shift），至少 1
#   文件行 = line-base + 相对行 - 1（line-base 是本格第一行的文件行号）
#
# 只重写 `line N` 这一种写法：两个后端（MoarVM / rakupp）在编译错误里
# 都是这个措辞；运行时异常的 `in block <unit> at … line N` 已被
# clean-message 当栈回溯丢掉，不会出现。
our sub remap-line(CellResult $r, Int $n --> Int) {
    my $rel = $n - $r.line-shift;
    $rel = 1 if $rel < 1;
    $r.source-file.chars ?? ($r.line-base + $rel - 1) !! $rel
}

our sub remap-message-lines(CellResult $r, Str $msg --> Str) {
    return $msg if $msg eq q{};
    return $msg if $r.line-shift == 0 and $r.source-file eq q{};
    $msg.subst(:g, / «line» \s+ (\d+) /, -> $/ {
        my $n = remap-line($r, $0.Int);
        $r.source-file.chars ?? "{$r.source-file}:{$n}" !! "line {$n}"
    })
}

# 给异常分一个简短的中文类别，便于一眼定位问题性质。
# 两个实现的异常类型名（X::Undeclared::Symbols 等）和消息措辞都不同，
# 所以**以消息关键词为主**、异常类型名为辅来判定，保证双后端一致。
# 编译期异常身上的 `.line` 是**拼接后 EVAL 源码**的行号（含壳子前缀），
# 所以必须过一遍 `remap-line` 才是用户视角的行号。
# `.file` **一律不用**：MoarVM 给的是 `EVAL_0` / `EVAL_xx` 这种内部临时名，
# 真实文件由 `$SOURCE-FILE` 说了算。
our sub error-location($e, CellResult $r --> Str) {
    return q{} unless defined $e;
    my $ln = try { $e.line };
    return q{} if $! or not $ln.defined or $ln === Any;
    my $n = try { $ln.Int };
    return q{} if $! or not $n.defined or $n < 1;
    my $f = remap-line($r, $n);
    $r.source-file.chars ?? "{$r.source-file}:{$f}" !! "line {$f}"
}

our sub classify-error($e --> Str) {
    return '运行时错误' unless defined $e;
    # 容错分类的访问器在**两个后端**上都可能拿到 `Any` 类型对象
    # （当异常涉及**多个**未声明符号时如 `cattt META6.json`，MoarVM 上
    # 实测会返回 `Any`）。把它当字符串用就会打
    # "Use of uninitialized value of type Any" 的噪声，污染整个错误块。
    my $t = q{};
    my $nm = try { $e.^name };
    $t = $nm.Str if $nm.defined and $nm !=== Any;
    my $m = q{};
    my $ms = try { $e.message };
    $m = $ms.Str if $ms.defined and $ms !=== Any;
    return '语法错误'   if $m ~~ /compiling|SORRY|parse|Missing\s+required|Unexpected|Adjacent|Precedence|Confused/;
    return '未定义名称' if $m ~~ /Undeclared|Undefined\s+routine|not\s+declared|Unknown\s+macro|never\s+declared/;
    return '下标错误'   if $m ~~ /does\s+not\s+support\s+associative|Positional|out\s+of\s+range|index\s+out/;
    return '类型错误'   if $m ~~ /Cannot\s+convert|does\s+not\s+support|Type\s+check|expected\s+.+but\s+got|did\s+not\s+pass|cannot\s+be\s+used/;
    return '类型错误'   if $t ~~ /TypeCheck|Numeric/;
    '运行时错误'
}

# 从异常的 gist 里挑出"人话"那几行（保留**全部**有用行，不再只取首行）。
# 两个实现的完整 gist 都长这样（以 MoarVM 为例）：
#     ===SORRY!=== Error while compiling EVAL_0      ← 内部临时文件，扔掉
#     Undeclared routine:                            ← 有用
#         twice used at line 1                       ← 有用（变量名 + 位置）
#     in block <unit> at ... line N                  ← 栈回溯，扔掉
# 过滤规则：丢掉含 `===SORRY`、行首 `in `（栈回溯）、行首 `at `、行首 `------>`、
# 以及纯空白行；其余逐行 trim 后保留（缩进信息本就无关紧要）。
our sub clean-message($e --> Str) {
    return '（无异常对象）' unless defined $e;
    my $g = try { $e.gist };
    # 同上：`gist` 也可能拿到 `Any` 类型对象，后面对它做 `.lines`
    # 会又触发一次同样的未初始化警告。
    return '（取消息失败）' if $! or not defined $g or $g === Any;
    # 注意：过滤必须用正则；正则里不能有空格（Raku 默认 sigspace），
    # 所以所有 alternation 都写成无空格的 `a|b|c`。
    my @keep = $g.lines.grep({
        $_ !~~ /SORRY/
        && $_ !~~ /^\s*in\s/          # 栈回溯：in block <unit> at … / in method …
        && $_ !~~ /^at\s/             # 栈回溯：at …
        && $_ !~~ /^\x2D\x2D/         # 分隔线 ------>
        && $_ !~~ /^\s*$/             # 纯空白行
    }).map(*.trim).grep(* ne '');
    return '（异常消息为空）' unless @keep.elems;
    @keep.join("\n")
}

# 出错的那一行源码（多行 cell 里挑第一行非空的；没有可靠行号，不瞎猜行数）。
our sub offending-line(Str $src --> Str) {
    my @lines = $src.lines.grep(*.trim ne '');
    return Nil unless @lines.elems;
    @lines[0].trim;
}

# 从（已清洗的）错误消息里尽量抠出"出错的那个标识符"，用于在源码行里高亮。
# 两个实现措辞不同，但都含标识符：
#   MoarVM/rakupp 变量：Variable '$x' is not declared   → 抠 '$x'
#   rakupp 例程       ：Undefined routine 'twice'        → 抠 'twice'
#   MoarVM 例程       ：<name> used at line N           → 抠 '<name>'
# 抠不到就返回空串（退化成"不高亮源码"，不影响其余渲染）。
our sub offending-token(Str $msg --> Str) is export {
    return '' unless defined $msg && $msg.chars;
    # 变量未声明：Variable '$x' is not declared（两边一致）
    if $msg ~~ / Variable \s+ \x27 (\S+?) \x27 \s+ is \s+ not \s+ declared / {
        return ~$0;
    }
    # 例程未定义（rakupp）：Undefined routine 'twice'
    if $msg ~~ / Undefined \s+ routine \s+ \x27 (\w+) \x27 / {
        return ~$0;
    }
    # 例程未定义（MoarVM）：<name> used at line N
    if $msg ~~ / (\w+) \s+ used \s+ at \s+ line / {
        return ~$0;
    }
    '';
}

# 在源码行里把 $tok 的每次出现用「粗黄」高亮，其余保持青色源码色。
# 不开 $color 时退化为普通青色整行（与旧行为一致）。
sub highlight-token(Str $line, Str $tok, Bool $color --> Str) {
    return e-paint('src', $line, $color) unless $color && $tok.chars && $line.contains($tok);
    my $sc = %ERR-COLOR<src>;
    my $tc = %ERR-COLOR<tok>;
    my $rs = %ERR-COLOR<reset>;
    # 不用 split(:all)（该 adverb 在两后端行为不一致、会丢掉分隔符），
    # 改用索引扫描，把 $tok 的每次出现用粗黄包住、其余保持青色源码色。
    my $out = '';
    my $i   = 0;
    my $n   = $line.chars;
    my $tl  = $tok.chars;
    while $i < $n {
        my $idx = $line.index($tok, $i);
        last unless defined $idx;
        $out ~= $sc ~ $line.substr($i, $idx - $i) ~ $rs if $idx > $i;
        $out ~= $tc ~ $tok ~ $rs;
        $i = $idx + $tl;
    }
    $out ~= $sc ~ $line.substr($i) ~ $rs if $i < $n;
    $out
}

# 追加一句"下一步建议"。不是猜错误原因，而是给可操作的下一步。
our sub hint-for(CellResult $r --> Str) {
    my $m = clean-message($r.error);
    my $src = $r.source // q{};

    # Undeclared routine: 先查 shell 特征，给针对性建议
    if $m ~~ /Undeclared\s+routine|Undefined\s+routine|not\s+declared|never\s+declared/ {
        my $first = ($src.words[0] // q{});
        if $first eq any(<export unset cd alias type pwd history source clear>) {
            return q["%s" 是 shell 内建，加 ! 前缀：!%s].sprintf($first, $src);
        }
        if $src ~~ / \| | \> | \< / {
            return q[这行像 shell 管道/重定向，加 ! 前缀：!%s].sprintf($src);
        }
        return q[这个名字不存在。如果是 shell 命令，在前面加 ! 试试：!%s].sprintf($src);
    }

    if $m ~~ /does\s+not\s+support\s+associative|Positional|out\s+of\s+range|index\s+out/ {
        return q[下标用错了容器：数组用 @a[0]，哈希才用 %h<key>。];
    }
    if $m ~~ /Cannot\s+convert|does\s+not\s+support|expected\s+.+but\s+got|Type\s+check/ {
        return q[类型不匹配：检查运算符/调用两边的类型，必要时显式 coerce（如 +$x、~$x）。];
    }
    if $m ~~ /parse|Missing\s+required\s+term|Unexpected|Confused|Two\s+terms/ {
        if $src ~~ / \| | \> / {
            return q[这行有 shell 语法特征，加 ! 前缀试试：!%s].sprintf($src);
        }
        return q[语法不完整或有错 —— 可以补全这一行，或在行首加 ! 改用 shell。];
    }
    if $m ~~ /unterminated|find\s+final|couldn.t\s+find/ {
        return q[引号（或括号）没闭合。];
    }
    q[错误只影响这一个 cell；会话还在，输入 _ 可以看上一个结果。];
}
