"""POSIX 真 PTY 下「求值期间 Ctrl-C」的实测探针（与 tools/ctrl-c-win.py 同构）。

和 Windows 版跑同样的四步，断言名也一致，方便两个平台的结果直接对照：

  0. 基线      `my $keep = 99` / `say $keep`
  1. 对照      **不在求值**时按 Ctrl-C → 必须是行编辑器的「已中断当前输入」
               没有这一步，「出现『已中断当前求值』」可能只是文案恒真
  2. 中断      `note 'SPIN'; loop { }`；看到 SPIN 才发 Ctrl-C
  3. 恢复      中断后 `say $keep` 仍是 99（引擎重启 + 快照恢复）

为什么要 `note 'SPIN'` 当门闩：`loop { }` 从外部不可观测，固定 sleep 会在
格子还没开始时就把 `\\x03` 发出去 —— 那测到的是输入中断，是假阴性。
0.85 的快速验证就栽在类似的时序上（Windows 版因此误判过一次）。

退出码：0 通过 / 1 断言失败 / 2 环境不具备（非 POSIX、没有 raku）。
用法：python3 tools/ctrl-c-posix.py [--json]
"""

import fcntl
import json
import os
import shutil
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROMPT = "\u276f"


# 真终端驱动在 tools/ttyprobe.py（与 pager-posix.py 共用；
# 抄第二份迟早会漂，尤其是 DSR 应答那几行）。
from ttyprobe import Pty


def run_scenario():
    raku = os.environ.get("RAKU") or shutil.which("raku")
    home = "/tmp/rakuish-ctrl-c-%d" % os.getpid()
    os.makedirs(home, exist_ok=True)
    env = dict(os.environ)
    env.update({
        "RAKUISH_CONFIG": home + "/config.json",
        "RAKUISH_SNAPSHOT": home + "/snap.json",
        "RAKUISH_NO_AUDIT": "1",
        "RAKUISH_NO_SNAPSHOT": "",
        "TERM": "xterm-256color",
        "LANG": "C.UTF-8",
        "PATH": os.path.dirname(raku) + ":" + env.get("PATH", ""),
    })

    t = Pty([raku, "-Ilib", "bin/rakuish"], env, ROOT)
    res = {"platform": "posix", "steps": {}}
    try:
        res["steps"]["ready"] = t.wait_for(PROMPT, 60)
        if not res["steps"]["ready"]:
            res["tail"] = t.text()[-800:]
            return res

        # prompt 打印 ≠ 行编辑器可接收输入：read-input 进入 raw mode 后还要
        # await detect-cursor-pos / detect-terminal-size，`react whenever` 建立
        # 之前到达的按键会丢。整行丢失时首格变成空行，后续 `say $keep` 报
        # 未声明，快照从未写出 —— 表现出来就是「50% 概率 state_survived=False」。
        # 这一步给事件循环留出建立时间（真机实测：不等则 6 次里 3 次失败）。
        t.settle(1.0, 10)

        t.send("my $keep = 99")
        res["steps"]["baseline"] = "99" in t.send("say $keep")

        ctl_mark = len(t.text())
        t.write(b"\x03")
        t.settle(1.0, 20)
        ctl = t.text()[ctl_mark:]
        res["steps"]["control_input_intr"] = "已中断当前输入" in ctl
        res["steps"]["control_no_eval_intr"] = "已中断当前求值" not in ctl

        mark = len(t.text())
        t.type_line("note 'SPIN'; loop { }", 0.8)
        res["steps"]["cell_started"] = t.wait_for("SPIN", 25)
        time.sleep(0.5)
        res["steps"]["spinning"] = t.poll() is None

        t.write(b"\x03")
        t.settle(2.0, 40)

        seg = t.text()[mark:]
        res["steps"]["alive_after_ctrlc"] = t.poll() is None
        res["steps"]["says_interrupted"] = "已中断当前求值" in seg
        res["steps"]["says_crashed"] = "引擎进程已退出" in seg
        res["steps"]["says_input_intr"] = "已中断当前输入" in seg
        res["steps"]["prompt_back"] = PROMPT in seg

        after_mark = len(t.text())
        if t.poll() is None:
            t.send("say $keep", 2.0)
            after = t.text()[after_mark:]
            res["steps"]["state_survived"] = "99" in after
            res["after_interrupt"] = after[-800:]
        else:
            res["steps"]["state_survived"] = False

        res["segment"] = seg[-1200:]
        if t.poll() is None:
            t.write("exit\r")
            for _ in range(50):          # 最多等 10 秒，别把「还在收尾」记成 None
                t.pump(0.2)
                if t.poll() is not None:
                    break
        res["exit"] = t.poll()
    finally:
        t.close()
    return res


def decide(res):
    fails = []
    s = res.get("steps", {})
    if not s.get("ready"):
        return ["REPL 没起来（PTY 没挂上或启动失败）"]
    if not s.get("baseline"):
        fails.append("基线求值失败：`say $keep` 没输出 99")
    if not s.get("control_input_intr"):
        fails.append("对照失效：prompt 上按 Ctrl-C 没有出现「已中断当前输入」")
    if not s.get("control_no_eval_intr"):
        fails.append("对照失效：没在求值却说「已中断当前求值」")
    if not s.get("cell_started"):
        fails.append("`note 'SPIN'` 没出现：这一格根本没开始")
    if not s.get("spinning"):
        fails.append("死循环期间 REPL 进程已退出")
    if not s.get("alive_after_ctrlc"):
        fails.append("Ctrl-C 后 REPL 进程死了")
    if not s.get("prompt_back"):
        fails.append("Ctrl-C 后 prompt 没回来")
    if s.get("says_input_intr") and not s.get("says_interrupted"):
        fails.append("Ctrl-C 被当成输入中断吃掉了：信号没进到求值层")
    if s.get("says_crashed") and not s.get("says_interrupted"):
        fails.append("归因退化成「引擎进程已退出」")
    if not s.get("says_interrupted"):
        fails.append("输出里没有「已中断当前求值」")
    if not s.get("state_survived"):
        fails.append("中断后 $keep 没恢复（快照恢复没走通）")
    return fails


def main():
    if os.name == "nt":
        print("SKIP: 仅 POSIX（Windows 用 tools/ctrl-c-win.py）")
        return 2
    if not (os.environ.get("RAKU") or shutil.which("raku")):
        print("SKIP: 找不到 raku")
        return 2

    res = run_scenario()
    fails = decide(res)
    if "--json" in sys.argv:
        print(json.dumps({"result": res, "fails": fails}, ensure_ascii=False, indent=2))
    else:
        s = res.get("steps", {})
        print("== POSIX 真 PTY：求值期间 Ctrl-C ==")
        for k in ("ready", "baseline", "control_input_intr", "control_no_eval_intr",
                  "cell_started", "spinning", "alive_after_ctrlc", "says_interrupted",
                  "says_crashed", "says_input_intr", "prompt_back", "state_survived"):
            print("  %-20s %s" % (k, s.get(k)))
        print("  exit=%s" % res.get("exit"))
        for f in fails:
            print("FAIL: " + f)
        if not fails:
            print("PASS: 中断归因正确、REPL 存活、状态经快照恢复")
        print("--- 中断前后 ---")
        print(res.get("segment", ""))
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main())
