"""真终端（PTY）探针的共用驱动。

`tools/ctrl-c-posix.py` 与 `tools/pager-posix.py` 都需要同一件事：
拿一个**真正的 pty** 起 rakuish，回答行编辑器的光标/尺寸查询，按「敲一行」的
节奏送输入，再把 ANSI 剥掉做文本断言。这段机器抄第二遍就会漂，所以放在这里。

Windows 不走这里：那边是 `winpty`（tools/ctrl-c-win.py），API 完全不同。

只依赖标准库；不 import 任何 rakuish 模块（探针要能测「起不来」这件事）。
"""

import fcntl
import os
import pty
import re
import select
import shutil
import struct
import termios
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROMPT = "\u276f"


def raku_bin():
    """探针用的 raku：优先 $RAKU（CI 里指向 rakubrew），其次 PATH。"""
    return os.environ.get("RAKU") or shutil.which("raku")


def base_env(home):
    """一套不污染用户真实配置的环境：配置/快照/审计都关掉或指到临时目录。"""
    env = dict(os.environ)
    env.update({
        "RAKUISH_CONFIG": os.path.join(home, "config.json"),
        "RAKUISH_SNAPSHOT": os.path.join(home, "snap.json"),
        "RAKUISH_NO_AUDIT": "1",
        "RAKUISH_NO_SNAPSHOT": "",
        "TERM": "xterm-256color",
        "LANG": "C.UTF-8",
    })
    raku = raku_bin()
    if raku:
        env["PATH"] = os.path.dirname(raku) + ":" + env.get("PATH", "")
    return env


class Pty:
    def __init__(self, argv, env, cwd, cols=110, rows=30):
        self.raw = bytearray()
        self._esc = b""
        self._size_pending = False
        self.cols = cols
        self.rows = rows
        self.pid, self.fd = pty.fork()
        if self.pid == 0:                       # 子进程
            os.chdir(cwd)
            os.execvpe(argv[0], argv, env)
        fcntl.ioctl(self.fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        self._status = None

    # ── 输出 ────────────────────────────────────────────────────
    def _feed(self, data):
        for b in data:
            self._esc += bytes((b,))
            if len(self._esc) > 24:
                self._esc = self._esc[-24:]
            # 行编辑器会问光标位置与窗口尺寸；不回答就会卡在启动阶段。
            if self._esc.endswith(b"\x1b[9999;9999H"):
                self._size_pending = True
            elif self._esc.endswith(b"\x1b[6n"):
                os.write(self.fd,
                         ("\x1b[%d;%dR" % (self.rows, self.cols)).encode()
                         if self._size_pending else b"\x1b[1;1R")
                self._size_pending = False
                self._esc = b""

    def pump(self, sec):
        end = time.time() + sec
        while time.time() < end:
            r, _, _ = select.select([self.fd], [], [], 0.08)
            if not r:
                continue
            try:
                data = os.read(self.fd, 65536)
            except OSError:
                return
            if not data:
                return
            self.raw.extend(data)
            self._feed(data)

    def text(self):
        txt = bytes(self.raw).decode("utf-8", "replace")
        txt = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", txt)
        txt = re.sub(r"\x1b\][^\x07]*\x07", "", txt)
        return txt

    def settle(self, quiet=1.2, timeout=40):
        """等输出静止：敲完一行 ≠ 这一格跑完（回显 / 重绘 / 引擎重启都会吐字节）。"""
        end = time.time() + timeout
        last, stable = -1, 0.0
        while time.time() < end:
            n = len(self.raw)
            if n != last:
                last, stable = n, time.time()
            elif time.time() - stable >= quiet:
                return True
            self.pump(0.1)
        return False

    def wait_for(self, needle, timeout=60):
        end = time.time() + timeout
        while time.time() < end:
            if needle in self.text():
                return True
            self.pump(0.2)
        return False

    def write(self, data):
        if isinstance(data, str):
            data = data.encode()
        os.write(self.fd, data)

    def type_line(self, text, quiet=0.5):
        """打字与回车分两次写：一次写完整行时，回车可能在重绘中被吞掉。"""
        self.write(text)
        self.settle(quiet, 10)
        self.write("\r")
        self.settle(1.0, 40)

    def send(self, line, quiet=1.2):
        self.type_line(line, 0.5)
        if quiet > 1.0:
            self.settle(quiet - 1.0, 10)
        return self.text()

    # ── 状态 ────────────────────────────────────────────────────
    def poll(self):
        if self._status is not None:
            return self._status
        w, st = os.waitpid(self.pid, os.WNOHANG)
        if w == 0:
            return None
        try:
            self._status = os.waitstatus_to_exitcode(st)
        except ValueError:
            self._status = -1
        return self._status

    def close(self):
        try:
            os.kill(self.pid, 9)
        except OSError:
            pass
