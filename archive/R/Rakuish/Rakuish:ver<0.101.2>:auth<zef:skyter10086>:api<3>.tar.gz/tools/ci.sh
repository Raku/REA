#!/usr/bin/env bash
# tools/ci.sh —— 平台无关的最小 CI 入口（0.80.1 / 发布工程化 A 路线）
#
# 目标：把「41 文件 / 1891 断言 + 真终端契约全绿」从**仓库自述**变成
#       「任何人一条命令可复核」。
#   Linux / WSL : bash tools/ci.sh   → bash tools/run-all.sh
#   Windows     : bash tools/ci.sh   → prove6 -Ilib t
# 产出 tmp/ci-report.txt（key=value，机器可读）与 tmp/ci-runner.log；
# 退出码 0 才代表 PASS，CI 直接看退出码。
#
# 两层验收，前一层失败不影响后一层跑完（都要看到结果）：
#   ① 单元/契约套件（prove6 或 run-all.sh）
#   ② 真终端层：tools/ctrl-c-{posix,win}.py —— 在真 PTY / 真 ConPTY 里
#      敲 `loop { }` 再按 Ctrl-C，验归因、REPL 存活、快照恢复。
#      这一层**测不了**套件里能测的东西（信号投递依赖真终端），所以单列。
#      退出码 2 = 环境不具备（无控制台且无 winpty），记 skip 不算失败。
#
# 四条**独立**失败判据（任一即 FAIL）：
#   ① runner 退出码非 0（含 127 = prove6 不存在、2 = 找不到 raku）
#   ② 输出里出现 not ok / Failed test / Result: FAIL
#   ③ 防空跑：文件数或断言数为 0 —— 不能让「什么都没跑」冒充通过
#   ④ 真终端层失败（探针退出码既非 0 也非 2）
# 只数 not ok 是不够的：测试崩在中途时 not ok 计数可能是 0 而退出码非 0
# （tools/run-all.sh 头部注释记过这个坑）。
#
# ⚠ 本脚本**不安装 Rakudo**：构建机需预装 Rakudo（建议 ≥ 2025.12）+
#   zef 依赖（JSON::Fast / Terminal::LineEditor / Terminal::API）。
#   缺 raku 时 env.sh 会 exit 2，这里如实记 FAIL，绝不静默跳过或降级。
# ⚠ 云端自动触发（Gitee Go / GitHub Actions）本版**未启用**，见 docs/CI.md。
#   本脚本是「可复核的入口」，不是「已接好托管 CI」的声明。

set -u
_here="$(cd "$(dirname "$0")" && pwd)"
cd "$_here/.." || exit 3

mkdir -p tmp
report=tmp/ci-report.txt
runner_log=tmp/ci-runner.log
: > "$report"

case "$(uname -s | tr '[:upper:]' '[:lower:]')" in
    mingw*|msys*|cygwin*) platform=windows ; runner_cmd="prove6 -Ilib t" ;;
    *)                    platform=linux   ; runner_cmd="bash tools/run-all.sh" ;;
esac

version="$(grep -m1 '"version"' META6.json | sed 's/.*: *"\([0-9][^"]*\)".*/\1/')"
# 在子 shell 里 source env.sh 拿 $RAKU：它找不到 raku 时会 exit 2，
# 但那只影响命令替换的结果，不会终止本脚本；失败就如实记 unknown。
raku_ver="$( bash -c 'source "$1/env.sh" >/dev/null 2>&1 && "$RAKU" -v' _ "$_here" 2>/dev/null | head -1 )"
[ -n "$raku_ver" ] || raku_ver=unknown
suites="$(ls t/*.t 2>/dev/null | wc -l | tr -d ' ')"

# ── 跑 runner ─────────────────────────────────────────────────────
if [ "$platform" = windows ]; then
    prove6 -Ilib t > "$runner_log" 2>&1
    rc=$?
else
    bash tools/run-all.sh > "$runner_log" 2>&1
    rc=$?
fi

# ── 真终端层：Ctrl-C 中断 + 前端分页（0.92）──────────────────────
# 两个探针各测一条真终端契约，合起来算一个 console 状态：任一失败即 fail，
# 至少一个通过即 pass，全都 skip 才是 skip。日志按探针分段写，失败时能看出
# 是哪一条挂的。
console_log=tmp/console.log
: > "$console_log"
console_pass=0
console_fail=0
console_skip=0
console=skip

run_probe() {                       # $1 = 命令行（含参数），$2 = 脚本路径
    [ -f "$2" ] || return 0
    echo "=== $2 ===" >> "$console_log"
    # shellcheck disable=SC2086
    $1 >> "$console_log" 2>&1
    case $? in
        0) console_pass=$((console_pass + 1)) ;;
        2) console_skip=$((console_skip + 1)) ;;
        *) console_fail=$((console_fail + 1)) ;;
    esac
}

if [ "$platform" = windows ]; then
    probe_py="$(command -v python || command -v py || true)"
else
    probe_py="$(command -v python3 || command -v python || true)"
fi

if [ -n "$probe_py" ]; then
    if [ "$platform" = windows ]; then
        run_probe "python tools/ctrl-c-win.py" tools/ctrl-c-win.py
    else
        run_probe "python3 tools/ctrl-c-posix.py" tools/ctrl-c-posix.py
        # 分页只有 POSIX 探针：Windows 侧走 winpty，输入路径不同（见 docs/CI.md）
        run_probe "python3 tools/pager-posix.py" tools/pager-posix.py
    fi
else
    echo "SKIP: 找不到 python，真终端层未跑" >> "$console_log"
fi

if [ "$console_fail" -gt 0 ]; then
    console=fail
elif [ "$console_pass" -gt 0 ]; then
    console=pass
elif [ "$console_skip" -gt 0 ]; then
    console=skip
fi

not_ok="$(grep -cE '^not ok|^# Failed test|Result: FAIL|\[FAIL\]' "$runner_log" 2>/dev/null || true)"
[ -n "$not_ok" ] || not_ok=0

# 断言数：优先读 prove6 的 Tests=；Linux 侧 run-all.sh 会为每个套件
# 写 tmp/<name>.out，按**当前 t/*.t 清单**逐个数 ^ok，避免把历史 .out 算进来。
assertions="$(grep -oE 'Tests=[0-9]+' "$runner_log" 2>/dev/null | tail -1 | cut -d= -f2)"
if [ -z "$assertions" ] || [ "$assertions" = 0 ]; then
    assertions=0
    for t in t/*.t; do
        [ -e "$t" ] || continue
        name="$(printf '%s' "$t" | sed 's#^t/##; s#/#__#g')"
        f="tmp/$name.out"
        [ -f "$f" ] || continue
        n="$(grep -cE '^ok ' "$f" 2>/dev/null || true)"
        [ -n "$n" ] || n=0
        assertions=$(( assertions + n ))
    done
fi
files="$(grep -oE 'Files=[0-9]+' "$runner_log" 2>/dev/null | tail -1 | cut -d= -f2)"
[ -n "$files" ] || files="$suites"

# ── 判定 ──────────────────────────────────────────────────────────
result=PASS
[ "$rc" -ne 0 ]          && result=FAIL
[ "$not_ok" -gt 0 ]      && result=FAIL
[ "$files" -eq 0 ]       && result=FAIL
[ "$assertions" -eq 0 ]  && result=FAIL
[ "$console" = fail ]    && result=FAIL

{
    echo "ci_entry=tools/ci.sh"
    echo "version=$version"
    echo "platform=$platform"
    echo "raku=$raku_ver"
    echo "runner=$runner_cmd"
    echo "runner_exit=$rc"
    echo "files=$files"
    echo "assertions=$assertions"
    echo "not_ok=$not_ok"
    echo "console=$console"
    echo "result=$result"
} >> "$report"

cat "$report"
echo "-----------------------------------------"
if [ "$result" != PASS ]; then
    echo "CI FAIL：套件见 $runner_log 末尾，真终端层见 $console_log" >&2
    [ "$console" = fail ] && tail -25 "$console_log" >&2
    tail -20 "$runner_log" >&2
    exit 1
fi
echo "CI PASS：报告 $report / 套件 $runner_log / 真终端 $console_log（console=$console）"
exit 0
