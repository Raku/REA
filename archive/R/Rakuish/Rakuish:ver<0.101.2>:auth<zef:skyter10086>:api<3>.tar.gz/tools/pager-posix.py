"""POSIX 真 PTY 下的前端分页验收（0.92 / ADR-0027）。

为什么要真终端：`t/47-pager.t` 用注入的 read/emit 覆盖了切页逻辑，但覆盖不了
「按键真的能到这一层」——分页发生在父进程，当时行编辑器刚交回终端；终端模式
没恢复的话，回车会被吞掉，表现为「翻不动页」。

三步：
  0. 基线      `explore big.csv` 必须出现 `-- more (`
  1. 翻页      发回车 → 出现第二次 `-- more`，且此时最后一行数据还没显示
  2. 退出      发 `q` → prompt 回来，最后一行仍不显示（说明确实没被一次性打完）
  3. 对照      `RAKUISH_PAGER=never` 的进程：**没有** `-- more`，且首末行都在
               没有这一步，「看到分页」可能只是输出恰好很长

退出码：0 通过 / 1 断言失败 / 2 环境不具备（非 POSIX、没有 raku）。
用法：python3 tools/pager-posix.py [--json]
"""

import json
import os
import shutil
import sys
import tempfile

from ttyprobe import PROMPT, Pty, base_env, raku_bin

ROWS = 30
COLS = 110
DATA_ROWS = 60


def write_csv(path):
    with open(path, "w", encoding="utf-8") as f:
        f.write("idx,name\n")
        for i in range(1, DATA_ROWS + 1):
            f.write("%d,row%02d\n" % (i, i))


def run_paged(bin_path, workdir):
    """RAKUISH_PAGER 未设（= auto）：explore 应当分页。"""
    steps = {}
    t = Pty([raku_bin(), bin_path], base_env(workdir), workdir, cols=COLS, rows=ROWS)
    try:
        steps["ready"] = t.wait_for(PROMPT, 60)
        if not steps["ready"]:
            return steps, t.text()[-800:]

        # 冷启动（新克隆、无 precomp）时 prompt 先画出来、引擎还没就绪，
        # 这时敲进去的字符会被吞掉，只剩一个回车 —— 表现为 `op: skip`。
        # 先等静止，再用一句无害的求值当门闩，确认「这一行真的被执行了」。
        t.settle(1.5, 40)
        t.send("say 4242", 2.0)
        steps["warm"] = "4242" in t.text()
        t.settle(1.0, 30)

        t.send("explore big.csv", 2.5)
        steps["first_page"] = "-- more (" in t.text()
        steps["first_has_row01"] = "row01" in t.text()
        steps["first_hides_row60"] = "row60" not in t.text()

        before = t.text().count("-- more (")
        t.write("\r")
        t.settle(1.5, 30)
        steps["advanced"] = t.text().count("-- more (") > before
        steps["still_hides_row60"] = "row60" not in t.text()

        mark = len(t.text())
        t.write("q")
        t.write("\r")                    # q 之后还要一个回车，read-line 才会返回
        t.settle(1.5, 30)
        after = t.text()[mark:]
        steps["prompt_back"] = PROMPT in after
        steps["no_row60_after_quit"] = "row60" not in after

        steps["alive"] = t.poll() is None
        t.write("exit\r")
        t.pump(2.0)
        steps["exit"] = t.poll()
        steps["tail"] = t.text()[-1500:]
    finally:
        t.close()
    return steps, ""


def run_never(bin_path, workdir):
    """RAKUISH_PAGER=never：同一份数据必须一次打完。"""
    steps = {}
    env = base_env(workdir)
    env["RAKUISH_PAGER"] = "never"
    t = Pty([raku_bin(), bin_path], env, workdir, cols=COLS, rows=ROWS)
    try:
        steps["ready"] = t.wait_for(PROMPT, 60)
        if not steps["ready"]:
            return steps, t.text()[-800:]
        t.settle(1.5, 40)
        t.send("say 4242", 2.0)
        t.settle(1.0, 30)
        t.send("explore big.csv", 3.0)
        txt = t.text()
        steps["no_more_prompt"] = "-- more (" not in txt
        steps["has_row01"] = "row01" in txt
        steps["has_row60"] = "row60" in txt
        t.write("exit\r")
        t.pump(2.0)
        steps["tail"] = t.text()[-1500:]
    finally:
        t.close()
    return steps, ""


def decide(paged, never):
    fails = []
    if not paged.get("ready"):
        return ["REPL 没起来（PTY 没挂上或启动失败）"]
    if not paged.get("warm"):
        fails.append("冷启动门闩失败：`say 4242` 没有回显（REPL 还没就绪就输入了）")
    if not paged.get("first_page"):
        fails.append("`explore big.csv` 没有出现 `-- more (`：分页没生效")
    if not paged.get("first_has_row01"):
        fails.append("第一页连 row01 都没显示：切页起点不对")
    if not paged.get("first_hides_row60"):
        fails.append("第一页就把 60 行全打了：没有真正切页")
    if not paged.get("advanced"):
        fails.append("发回车后没有翻页：读键没到分页器（终端模式或 stdin 有问题）")
    if not paged.get("still_hides_row60"):
        fails.append("翻一页就看到了 row60：每页行数算多了")
    if not paged.get("prompt_back"):
        fails.append("q 之后 prompt 没回来")
    if not paged.get("no_row60_after_quit"):
        fails.append("q 之后仍打印了后面的行：退出没生效")
    if not paged.get("alive"):
        fails.append("分页之后 REPL 进程死了")

    if not never.get("ready"):
        fails.append("RAKUISH_PAGER=never 的对照进程没起来")
    else:
        if not never.get("no_more_prompt"):
            fails.append("RAKUISH_PAGER=never 仍然出现 `-- more`：开关没生效")
        if not never.get("has_row60"):
            fails.append("RAKUISH_PAGER=never 没有打完全部行")
    return fails


def main():
    if os.name == "nt":
        print("SKIP: 仅 POSIX（Windows 用 winpty，见 docs/CI.md）")
        return 2
    if not raku_bin():
        print("SKIP: 找不到 raku")
        return 2

    workdir = tempfile.mkdtemp(prefix="rakuish-pager-")
    write_csv(os.path.join(workdir, "big.csv"))
    bin_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "bin", "rakuish")
    paged, tail = run_paged(bin_path, workdir)
    never, _ = run_never(bin_path, workdir)
    fails = decide(paged, never)

    if "--json" in sys.argv:
        print(json.dumps({"result": {"auto": paged, "never": never},
                          "fails": fails}, ensure_ascii=False, indent=2))
    else:
        print("== POSIX 真 PTY：explore 分页 ==")
        for group, name in ((paged, "auto"), (never, "never")):
            for k in sorted(group):
                print("  %-5s %-18s %s" % (name, k, group[k]))
        if tail:
            print("  ---- tail ----")
            print(tail)
        if fails:
            print("FAIL:")
            for f in fails:
                print("  - " + f)
        else:
            print("OK: 分页、翻页、退出与 never 对照都符合预期")

    shutil.rmtree(workdir, ignore_errors=True)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
