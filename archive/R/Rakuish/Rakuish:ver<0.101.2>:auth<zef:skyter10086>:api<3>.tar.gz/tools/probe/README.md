# 探针集：《Rakuish 愿景溯源》§6.6

这三个脚本是**只读探针**，回答两个「不做实验就只能靠草案假定」的问题：

| 探针 | 问题 | 脚本 |
|---|---|---|
| ① | 本机 REPL 到底依不依赖 `Rakuish::Sandbox`？撤掉应用层安全壳的真实改动面有多大？ | `sandbox-short-circuit.sh` |
| ② | rakupp 的 C ABI 里，两次 `rk_eval` 之间 `my` 是否真存活？Raku 侧能否直接调？ | `rakupp-session.c` / `rakupp-session.raku` |
| 第二层 | Rakuish 能不能真的跑在 rakupp 上？ | `rakupp-modules.sh`、`rakupp-cell.raku`、`rakupp-integration.raku`、`rakupp-callback.raku`、`rakupp-io.c`、`rakupp-suite.sh` |
| 第三层 | 15 个失败文件里，哪些是「改几行就能绕过」，哪些是「引擎真没有」？ | `rakupp-diff.raku`、`rakupp-adapt.sh` |

结论与全部实测数据见 [`docs/PROBE-2026-11-15-persistent-engine.md`](../../docs/PROBE-2026-11-15-persistent-engine.md)、
[`docs/PROBE-2026-11-16-rakupp-integration.md`](../../docs/PROBE-2026-11-16-rakupp-integration.md)
与 [`docs/PROBE-2026-11-16-rakupp-adaptation.md`](../../docs/PROBE-2026-11-16-rakupp-adaptation.md)。
**本目录不参与构建、不被 `t/*.t` 收集、不进 `META6.provides`、不改产品代码。**

## 环境

实测环境：WSL2 Ubuntu · 内核 6.6.114.1-microsoft · g++ · Rakudo `v2026.09` ·
rakupp **5.6.3**（`~/.rakupp/bin/rakupp`）、头文件 `~/.rakupp/include/rakupp/rakupp.h`、
动态库 `~/.rakupp/lib/librakupp.so.5.6.3`。

探针② 需要 rakupp 的 C ABI；**Windows 侧是否有对应构建未测**，所以这组数据只在
Linux/WSL 有效。探针① 是纯 Raku/bash，两个平台都可跑。

**版本漂移**：2026-11-16 00:30 左右 rakupp 自动升级 5.6.3 → 5.8.0。
C ABI 探针用 `RAKUPP_LIB` 显式指定库版本；CLI 探针（模块快筛 / 双引擎一格 /
全套件）跟随 `rakupp` 默认版本。两版 C ABI 核心结论逐项一致，引用数据时请标版本。

## 跑法

```bash
export PATH="$HOME/.rakubrew/versions/moar-2026.09/install/bin:$PATH"
export H="$HOME/.rakupp"

# 探针①：变异体 + 对照组（会创建 tmp/probe-sandbox 副本，不改主干）
export RAKU="$(command -v raku)"
bash tools/probe/sandbox-short-circuit.sh              # 替换 Sandbox 为会炸的 stub
bash tools/probe/sandbox-short-circuit.sh --control   # 保留原 Sandbox，其余完全相同

# 探针② C 侧：编译并跑默认配置 / sandbox 配置
g++ -O0 -I"$H/include" -o /tmp/rk-probe tools/probe/rakupp-session.c \
    "$H/lib/librakupp.so.5.6.3" -Wl,-rpath,"$H/lib" -pthread -ldl
/tmp/rk-probe
/tmp/rk-probe --sandbox

# 探针② Raku / NativeCall 侧
export RAKUPP_LIB="$H/lib/librakupp.so.5.6.3"
raku -Ilib tools/probe/rakupp-session.raku

# 第二层（需要 rakupp CLI 在 PATH 里）
export PATH="$HOME/.rakupp/bin:$PATH"
bash tools/probe/rakupp-modules.sh                 # 34 模块逐个加载
raku   -Ilib tools/probe/rakupp-cell.raku          # MoarVM 基线
rakupp -Ilib tools/probe/rakupp-cell.raku          # rakupp，逐行对比
raku -Ilib tools/probe/rakupp-integration.raku     # 值 ABI / rk_run / state / 内存
g++ -O0 -I"$H/include" -o /tmp/rk-io tools/probe/rakupp-io.c \
    "$H/lib/librakupp.so.5.8.0" -Wl,-rpath,"$H/lib" -pthread -ldl && /tmp/rk-io
raku -Ilib tools/probe/rakupp-callback.raku callback
raku -Ilib tools/probe/rakupp-callback.raku threads    # 预期 SIGSEGV(139)
bash tools/probe/rakupp-suite.sh                   # 全 42 文件兼容率

# 第三层：差异复现（同一份脚本在两个引擎上各跑一次，逐行 diff）
raku   -Ilib tools/probe/rakupp-diff.raku          # MoarVM 基线
rakupp -Ilib tools/probe/rakupp-diff.raku          # rakupp

# 第三层：适配实验（副本里只改两处，再跑全套件）
bash tools/probe/rakupp-adapt.sh                   # → ADAPT-SUMMARY
bash tools/probe/rakupp-adapt.sh --keep            # 保留 tmp/probe-adapt
```

`sandbox-short-circuit.sh` 输出 `PROBE|用例|rc=|首行`，两种模式逐行对照即可。
两个 C/Raku 探针输出 `key=value`。

## 边界（别把探针当实现）

- 探针① 只在 `tmp/probe-sandbox` 副本里替换模块；`tmp/` 已被 `.gitignore` 忽略。
  它验证的是「导入/构造依赖」，**不验证**删掉 Sandbox 后 Agent 协议还能不能用
  （那本来就该挂，是对照组存在的意义）。
- 探针② 只测**值 ABI 的最小路径**（Int、赋值、语法错恢复、root、重复 new）。
  没有测：34 个 `Rakuish::*` 模块能否在 rakupp 上 `use`、`NativeCall` /
  `Terminal::LineEditor` 等依赖、`rk_run` 整程序模式、完整类型覆盖、内存占用、
  多线程回调、JIT 行为、Windows 构建。这些是「能不能接进 Rakuish」的下一层问题。
- **`RkConfig.sandbox` 不是 OS 隔离**：头文件原话 "Only the Raku code is confined,
  not your process"，且是进程级单向开关。它不能替代 V-607，也不能用来跑不可信源码。
- 第二层全套件用 rakupp CLI 5.8.0 跑出 **27/42 通过**；第三层在副本里只改
  `Sys::Proc.spawn`（tap→Channel）与 `Sys.%.env`（TWEAK 复制）两处，
  升到 **30/42**、ok 行 1856→1980。剩余 12 个失败分七类，详见第三篇报告 §3。
  **这不等于「Rakuish 可以换引擎」**：其中 `:pty` 与 async accept 收尾是
  引擎硬缺口，而这两项恰是 shell / REPL 工作台的核心能力。
- 第三层的两处改动**只在副本里验证**，没有合入主干；MoarVM 侧未做回归。
- 探针不承诺实施。《愿景溯源》§6 的两个判断仍待用户决定；要不要重开 V-906、
  写新 ADR，是议题而不是本目录的结论。
