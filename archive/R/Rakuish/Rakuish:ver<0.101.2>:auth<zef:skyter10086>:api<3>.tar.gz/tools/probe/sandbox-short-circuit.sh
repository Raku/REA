#!/usr/bin/env bash
# 《Rakuish 愿景溯源》§6.6 探针①
#
# 在**临时副本**里把 `lib/Rakuish/Sandbox.rakumod` 换成立刻炸的 stub，
# 然后跑本机 REPL 的三个入口（-e / 脚本 / 交互管道）与 REPL 侧测试，
# 看「短路 Sandbox」之后还剩下谁依赖它。
#
# 目的：确证「Sandbox 是 Agent 产物」，以及撤掉应用层安全壳的真实依赖面。
# 只在 tmp/probe-sandbox 副本里动手，**不改主干任何文件**。
# 输出 PROBE|case|rc|first-line，便于复核。

set -u
mode="${1:---mutant}"          # --control = 不替换 stub，用作对照组
root="$(cd "$(dirname "$0")/../.." && pwd)"
work="$root/tmp/probe-sandbox"

# 防呆：只允许删项目内这个明确的专用目录
case "$work" in
    */tmp/probe-sandbox) : ;;
    *) echo "拒绝执行：work 路径异常 ($work)" >&2; exit 3 ;;
esac
rm -rf "$work"
mkdir -p "$work"
for d in lib bin t tools docs; do
    [ -e "$root/$d" ] && cp -r "$root/$d" "$work/"
done
cp "$root/META6.json" "$work/" 2>/dev/null || true
rm -rf "$work/lib/.precomp"

if [ "$mode" = "--control" ]; then
    echo "== 对照组：保留原始 Sandbox，其余步骤完全相同 =="
else
    cat > "$work/lib/Rakuish/Sandbox.rakumod" <<'RAKU'
unit class Rakuish::Sandbox;
submethod TWEAK(|) { die 'SANDBOX-STUB: 本机 REPL 路径不该构造 Sandbox' }
RAKU
fi

printf 'say "SCRIPT-OK"\n' > "$work/cell.raku"

cd "$work" || exit 3
RAKU="${RAKU:-raku}"
export RAKUISH_NO_AUDIT=1      # 探针不往用户目录写审计日志

probe() {
    local label="$1"; shift
    local out rc first
    out="$("$@" 2>&1)"
    rc=$?
    first="$(printf '%s' "$out" | head -1 | tr -d '\r' | cut -c1-100)"
    printf 'PROBE|%s|rc=%s|%s\n' "$label" "$rc" "$first"
}

echo "== mode=$mode：开始短路实验 =="
probe "-e"            "$RAKU" -Ilib bin/rakuish -e 'say 1+1'
probe "script"        "$RAKU" -Ilib bin/rakuish cell.raku
probe "repl-pipe"     bash -c "printf 'say 40+2\\nquit\\n' | '$RAKU' -Ilib bin/rakuish"
probe "t/05-session"  "$RAKU" -Ilib t/05-repl-session.t
probe "t/35-kernel"   "$RAKU" -Ilib t/35-kernel.t
probe "t/07-entry"    "$RAKU" -Ilib t/07-entrypoints.t
echo "-- Agent 侧（mutant 预期全挂，control 预期全绿）--"
probe "t/39-agent"    "$RAKU" -Ilib t/39-stream-cancel.t
probe "t/06-agent"    "$RAKU" -Ilib t/06-sandbox-agent.t
echo "== 结束；副本仍在 $work，可自行删除 =="
