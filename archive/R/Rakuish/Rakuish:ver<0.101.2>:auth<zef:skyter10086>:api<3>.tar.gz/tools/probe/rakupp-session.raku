#!/usr/bin/env raku
# 《Rakuish 愿景溯源》§6.6 探针②（Raku / NativeCall 侧）
#
# 目的：C 探针确证 ABI 契约之后，再确证「Raku 侧能直接调这套 C ABI」——
# RkInterp / RkCtx / RkValue 都是 opaque 指针，NativeCall 不需要猜结构体布局。
# 这是「接进 Rakuish」可行性的一半，不是实现。
#
# 只读探针：不写用户文件、不改产品代码。运行见 tools/probe/README.md。
use NativeCall;

my constant LIB = do {
    my Str $e = (%*ENV<RAKUPP_LIB> // '').Str;
    if $e.chars && $e.IO.e {
        $e;
    }
    else {
        my $d = $*HOME.add('.rakupp').add('lib');
        my @so = $d.e
            ?? $d.dir.grep({ .basename.starts-with('librakupp.so.') }).sort
            !! ();
        @so
            ?? @so[*-1].Str
            !! die "找不到 librakupp.so，请设 RAKUPP_LIB=/abs/path/to/librakupp.so.X.Y.Z";
    }
};

sub rk_version(--> Str)                              is native(LIB) { * }
sub rk_new(Pointer --> Pointer)                      is native(LIB) { * }
sub rk_free(Pointer)                                 is native(LIB) { * }
sub rk_ctx(Pointer --> Pointer)                      is native(LIB) { * }
sub rk_eval(Pointer, Str, CArray[Pointer] --> int32) is native(LIB) { * }
sub rk_int_get(Pointer, Pointer --> int64)           is native(LIB) { * }
sub rk_last_error(Pointer --> Str)                   is native(LIB) { * }

say "lib=", LIB;
say "version=", rk_version();

my $rk = rk_new(Pointer);
say "rk_new=", $rk.defined ?? "OK" !! "NULL";
die "rk_new 返回 NULL，无法继续" unless $rk.defined;

sub ev(Str $label, Str $src) {
    my $out = CArray[Pointer].new(Pointer);
    my $rc  = rk_eval($rk, $src, $out);
    if $rc == 0 {
        say "{$label}_rc=0 value=", rk_int_get(rk_ctx($rk), $out[0]);
    }
    else {
        say "{$label}_rc=$rc err=", (rk_last_error($rk) // '(none)').Str.lines[0];
    }
}

ev('eval1_my41',    'my $x = 41');
ev('eval2_x_plus',  '$x + 1');
ev('eval3_assign',  '$x = 100; $x');
ev('eval4_reread',  '$x');
ev('eval5_bad',     'this is !!! not valid raku');
ev('eval6_recover', '$x + 1');

my $second = rk_new(Pointer);
say 'second_live_rk_new=', $second.defined ?? 'non-NULL' !! 'NULL';
rk_free($second) if $second.defined;
rk_free($rk);
say 'freed=OK';
