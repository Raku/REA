#!/usr/bin/env raku
# §6 判断 B · 第二层探针：**同一份「Rakuish 一格」在两种引擎上跑**
#
#   raku   -Ilib tools/probe/rakupp-cell.raku     # 宿主 Rakudo 基线
#   rakupp -Ilib tools/probe/rakupp-cell.raku     # rakupp 5.6.3
#
# 目的不是比快慢，而是看 Rakuish 的核心链路（Session → Kernel.execute →
# 每格 EVAL → stdout 捕获 → Result 渲染）在 rakupp 上是否还成立。
# 只读探针；Audit 显式关掉，避免往用户目录写日志。
use Rakuish::REPL::Session;
use Rakuish::Kernel;
use Rakuish::Audit;

my $session = Rakuish::REPL::Session.new(:!color);
my $kernel  = Rakuish::Kernel.new(
    :$session,
    :policy(Policy.new(:profile<local>, :allow-source, :allow-exec)),
    :audit(Rakuish::Audit.new(:default-origin<human>, :enabled(False))),
);

my @src =
    'my $x = 40',
    '$x + 2',
    'say "CELL-SAY"',
    '[1,2,3].sum',
    '"中文".chars',
    'use Rakuish::Display; 42';

for @src.kv -> $i, $src {
    my $r = $kernel.execute(
        Request.new(:kind<source>, :payload($src), :origin<human>));
    my $value = (try { $r.value.defined ?? $r.value.raku !! '-' }) // 'ERR';
    my $out   = ($r.out // '').subst(/\n/, '\n', :g);
    say "CELL|$i|ok={$r.ok}|code={$r.code}"
      ~ "|value={$value.substr(0, 50)}|out={$out.substr(0, 50)}"
      ~ "|err={(($r.err // '').substr(0, 50))}";
}
say 'ENGINE_DONE';
