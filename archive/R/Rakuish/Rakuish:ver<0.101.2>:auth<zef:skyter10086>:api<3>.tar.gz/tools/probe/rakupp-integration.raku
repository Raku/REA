#!/usr/bin/env raku
# §6 判断 B · 第二层探针：C ABI 集成面
#
#   RAKUPP_LIB=... raku -Ilib tools/probe/rakupp-integration.raku
#
# 覆盖四组问题（只读，不改主干）：
#   ① 值 ABI 的 RkType 各类型能否取回（Out[n] 渲染层要改多少）
#   ② rk_eval 里能否 use 仓库模块 / 跨 eval 的 state / our / use 是否持久
#   ③ rk_run 整程序模式与 MAIN / exit / 语法错的语义
#   ④ 内存：new / 多次 eval / free 的 RSS 变化
#
# 输出全部是 key=value 或 | 分隔，便于与 docs/PROBE-* 对账。
use NativeCall;

my constant LIB = do {
    my Str $e = (%*ENV<RAKUPP_LIB> // '').Str;
    if $e.chars && $e.IO.e { $e }
    else {
        my $d = $*HOME.add('.rakupp').add('lib');
        my @so = $d.e
            ?? $d.dir.grep({ .basename.starts-with('librakupp.so.') }).sort !! ();
        @so ?? @so[*-1].Str !! die "找不到 librakupp.so，请设 RAKUPP_LIB=...";
    }
};

sub rk_new(Pointer --> Pointer)                        is native(LIB) { * }
sub rk_free(Pointer)                                   is native(LIB) { * }
sub rk_ctx(Pointer --> Pointer)                        is native(LIB) { * }
sub rk_eval(Pointer, Str, CArray[Pointer] --> int32)   is native(LIB) { * }
sub rk_run(Pointer, Str, Str, CArray[int32] --> int32) is native(LIB) { * }
sub rk_type(Pointer, Pointer --> int32)                is native(LIB) { * }
sub rk_int_get(Pointer, Pointer --> int64)             is native(LIB) { * }
sub rk_num_get(Pointer, Pointer --> num64)             is native(LIB) { * }
sub rk_str_get(Pointer, Pointer, CArray[uint64] --> Str) is native(LIB) { * }
sub rk_elems(Pointer, Pointer --> uint64)              is native(LIB) { * }
sub rk_at_pos(Pointer, Pointer, uint64 --> Pointer)    is native(LIB) { * }
sub rk_last_error(Pointer --> Str)                     is native(LIB) { * }
sub rk_version(--> Str)                                is native(LIB) { * }

sub rss-kb(--> Int) {
    for '/proc/self/status'.IO.lines -> $l {
        return $l.words[1].Int if $l.starts-with('VmRSS:');
    }
    0
}

say "lib=", LIB;
say "version=", rk_version();
my $rss0 = rss-kb();
my $rk = rk_new(Pointer);
die 'rk_new 返回 NULL' unless $rk.defined;
my $ctx = rk_ctx($rk);
say "rss_before_kb=$rss0 rss_after_new_kb={rss-kb()}";

# ── ① 值 ABI 类型覆盖 ────────────────────────────────────────────
my @cases =
    ('int',    '42'),
    ('num',    '3.14'),
    ('rat',    '1/3'),
    ('str',    '"中文"'),
    ('bool',   'True'),
    ('array',  '[1,2,3]'),
    ('hash',   '{a => 1, b => 2}'),
    ('nil',    'Nil'),
    ('any',    'Any'),
    ('date',   'Date.new("2026-11-16")'),
    ('buf',    'Buf.new(1,2,3)'),
    ('bigint', '123456789012345678901234567890');

for @cases -> ($label, $src) {
    my $out = CArray[Pointer].new(Pointer);
    my $rc  = rk_eval($rk, $src, $out);
    if $rc != 0 {
        say "TYPE|$label|rc=$rc|err=", (rk_last_error($rk) // '').lines[0];
        next;
    }
    my $v    = $out[0];
    my $t    = rk_type($ctx, $v);
    my $len  = CArray[uint64].new(0);
    my $s    = (try { rk_str_get($ctx, $v, $len) }) // 'ERR';
    my $n    = ($t == 6 || $t == 7) ?? rk_elems($ctx, $v) !! 0;
    my $i    = ($t == 2 ?? (try { rk_int_get($ctx, $v) }) // 'ERR' !! '-');
    say "TYPE|$label|rc=0|type=$t|str={$s.substr(0, 40)}"
      ~ "|bytes={$len[0]}|int=$i|elems=$n";
}

# ── ② 嵌入路径里的模块加载 + 跨 eval 的声明持久性 ────────────────
my $root = $*PROGRAM.parent.parent.parent.absolute;   # tools/probe/X → 仓库根
my $libsrc = 'use lib q[' ~ $root ~ '/lib]; ';
my @mods = <Rakuish::Kernel Rakuish::REPL::Session Rakuish::Audit Rakuish::Display>;
my $useall = $libsrc ~ @mods.map({ "use $_;" }).join(' ') ~ ' q[USE-ALL-OK]';
{
    my $out = CArray[Pointer].new(Pointer);
    my $rc  = rk_eval($rk, $useall, $out);
    my $len = CArray[uint64].new(0);
    my $s   = $rc == 0 ?? (try { rk_str_get($ctx, $out[0], $len) }) // 'ERR' !! '-';
    say "EMBED|use_all|rc=$rc|str=$s|err=", ($rc ?? (rk_last_error($rk) // '').lines[0] !! '');
}
{
    my $out = CArray[Pointer].new(Pointer);
    rk_eval($rk, 'state $n = 0; ++$n', $out);
    my $rc = rk_eval($rk, '++$n', $out);
    say "EMBED|state|rc=$rc|value=", ($rc == 0 ?? rk_int_get($ctx, $out[0]) !! '-');
}
{
    my $out = CArray[Pointer].new(Pointer);
    my $rc = rk_eval($rk, 'our $shared = 7; $shared', $out);
    say "EMBED|our_first|rc=$rc|value=", ($rc == 0 ?? rk_int_get($ctx, $out[0]) !! '-');
    $rc = rk_eval($rk, '$shared + 1', $out);
    say "EMBED|our_second|rc=$rc|value=", ($rc == 0 ?? rk_int_get($ctx, $out[0]) !! '-');
}
{
    my $out = CArray[Pointer].new(Pointer);
    my $rc = rk_eval($rk, $libsrc ~ 'use Rakuish::Audit; Rakuish::Audit::fingerprint("abc")', $out);
    my $len = CArray[uint64].new(0);
    my $s = $rc == 0 ?? (try { rk_str_get($ctx, $out[0], $len) }) // 'ERR' !! '-';
    say "EMBED|call_module_fn|rc=$rc|str=$s";
}

# ── ③ rk_run 整程序 ─────────────────────────────────────────────
for ('say q[RUN-OK];', 'sub MAIN() { say q[MAIN-OK] }',
     'this is !!! bad', 'exit 3;') -> $src {
    my $code = CArray[int32].new(0);
    my $rc = rk_run($rk, $src, '<probe>', $code);
    say "RUN|rc=$rc|exit_code={$code[0]}|src={$src.substr(0, 28)}";
}

# ── ④ 内存 ──────────────────────────────────────────────────────
say "rss_before_1000_kb={rss-kb()}";
for ^1000 {
    my $out = CArray[Pointer].new(Pointer);
    rk_eval($rk, 'my $tmp = ' ~ $_ ~ '; $tmp * 2', $out);
}
say "rss_after_1000_kb={rss-kb()}";
rk_free($rk);
say "rss_after_free_kb={rss-kb()} freed=OK";
