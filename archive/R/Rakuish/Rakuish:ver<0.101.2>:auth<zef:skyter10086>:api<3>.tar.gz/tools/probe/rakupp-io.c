/* tools/probe/rakupp-io.c
 *
 * §6 判断 B · 第二层探针：C 侧验证 rk_set_output / rk_set_input。
 * 目的是把「C ABI 有没有这个能力」与「Raku 宿主回调好不好接」分开测：
 * Raku 侧见 rakupp-callback.raku，本文件只证明 ABI 本身可用。
 *
 * 编译见 tools/probe/README.md。只读探针，不改主干。
 */
#include <stdio.h>
#include <string.h>
#include <rakupp/rakupp.h>

static int hits = 0;

static void on_output(void *ud, const char *text, size_t len, int is_err) {
    (void)ud;
    hits++;
    size_t show = len > 60 ? 60 : len;
    printf("CB|n=%d|is_err=%d|len=%zu|text=%.*s\n",
           hits, is_err, len, (int)show, text);
}

int main(void) {
    RkInterp rk = rk_new(NULL);
    if (!rk) { printf("rk_new=NULL\n"); return 2; }

    /* ① 宿主输出回调：替掉 Rakuish 现在的 CapturingOut sink */
    rk_set_output(rk, on_output, NULL);
    RkValue v = NULL;
    int rc = rk_eval(rk, "say q[CAPTURED-STDOUT]; note q[CAPTURED-STDERR]; 42", &v);
    printf("EVAL|rc=%d|hits=%d|value=%lld\n", rc, hits,
           rc == RK_OK ? rk_int_get(rk_ctx(rk), v) : -1);

    /* ② 宿主输入注入：REPL 把一行喂给解释器，而不是等终端 */
    rk_set_input(rk, "hello-from-host\n", 17);
    rc = rk_eval(rk, "my $line = $*IN.get; $line", &v);
    if (rc == RK_OK) {
        size_t len = 0;
        const char *s = rk_str_get(rk_ctx(rk), v, &len);
        printf("INPUT|rc=%d|len=%zu|text=%.*s\n",
               rc, len, (int)(len > 40 ? 40 : len), s ? s : "(null)");
    }
    else {
        printf("INPUT|rc=%d|err=%s\n", rc,
               rk_last_error(rk) ? rk_last_error(rk) : "(none)");
    }

    /* ③ NULL 回调恢复进程自身 stdout */
    rk_set_output(rk, NULL, NULL);
    rc = rk_eval(rk, "1 + 1", &v);
    printf("RESTORE|rc=%d|hits=%d\n", rc, hits);

    rk_free(rk);
    return 0;
}
