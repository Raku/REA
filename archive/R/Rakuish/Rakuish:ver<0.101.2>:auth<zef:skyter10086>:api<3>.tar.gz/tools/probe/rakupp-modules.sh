#!/usr/bin/env bash
# §6 判断 B · 第二层探针：34 个 Rakuish::* 模块能否在 rakupp 上编译加载
#
# 逐个用 rakupp CLI 起一个独立编译单元（避免一次全 use 时互相掩盖），
# 输出 MODULE|rc|首行；末尾汇总。只读，不写用户文件、不改主干。
#
# 用法：bash tools/probe/rakupp-modules.sh   [RAKUPP=/path/to/rakupp]
set -u
root="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$root" || exit 3
RAKUPP="${RAKUPP:-rakupp}"

command -v "$RAKUPP" >/dev/null 2>&1 || { echo "找不到 rakupp"; exit 3; }

mods="$(python3 -c 'import json;print("\n".join(sorted(json.load(open("META6.json"))["provides"])))')"
total=0; ok=0; failed=""

echo "== rakupp 模块加载快筛（$RAKUPP -Ilib）=="
while IFS= read -r m; do
    [ -n "$m" ] || continue
    total=$((total + 1))
    out="$(timeout 90 "$RAKUPP" -Ilib -e "use $m; say q[LOADED]" 2>&1)"
    rc=$?
    first="$(printf '%s' "$out" | head -1 | tr -d '\r' | cut -c1-110)"
    printf 'MODULE|%s|rc=%s|%s\n' "$m" "$rc" "$first"
    if [ "$rc" -eq 0 ] && printf '%s' "$out" | grep -q 'LOADED'; then
        ok=$((ok + 1))
    else
        failed="$failed $m"
    fi
done <<< "$mods"

echo "SUMMARY|total=$total|ok=$ok|failed=$((total-ok))"
[ -n "$failed" ] && echo "FAILED_MODULES|$failed"
exit 0
