#!/usr/bin/env bash
# §6 判断 B · 第二层探针：让 **rakupp** 跑整个 t/ 套件，量兼容率
#
# 判据与 tools/run-all.sh 完全一致（rc + `not ok` + TAP plan），
# 唯一变量是引擎：Raku → rakupp。只读，不改主干；结果写 tmp/。
#
# 用法：bash tools/probe/rakupp-suite.sh   [RAKUPP=/path/to/rakupp]
set -u
root="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$root" || exit 3
RAKUPP="${RAKUPP:-rakupp}"
command -v "$RAKUPP" >/dev/null 2>&1 || { echo "找不到 rakupp"; exit 3; }

mkdir -p tmp
: > tmp/rakupp-suite.log
files=0; pass=0; failed=""
assertions=0

echo "== rakupp 全套件（引擎：$("$RAKUPP" --version 2>&1 | head -1)）=="
for t in t/*.t; do
    [ -e "$t" ] || continue
    name="$(basename "$t")"
    files=$((files + 1))
    timeout 300 "$RAKUPP" -Ilib "$t" > "tmp/rakupp-$name.out" 2>&1
    rc=$?
    notok="$(grep -c 'not ok' "tmp/rakupp-$name.out" 2>/dev/null || true)"
    plan="$(grep -cE '^1\.\.[0-9]+( *# *SKIP.*)?$' "tmp/rakupp-$name.out" 2>/dev/null || true)"
    oks="$(grep -cE '^ok ' "tmp/rakupp-$name.out" 2>/dev/null || true)"
    [ -n "$notok" ] || notok=0
    [ -n "$plan" ]  || plan=0
    [ -n "$oks" ]   || oks=0
    assertions=$((assertions + oks))
    if [ "$rc" -eq 0 ] && [ "$notok" -eq 0 ] && [ "$plan" -ge 1 ]; then
        pass=$((pass + 1))
        verdict=PASS
    else
        failed="$failed $name(rc=$rc,notok=$notok,plan=$plan)"
        verdict=FAIL
    fi
    printf 'SUITE|%-34s|%s|rc=%s|notok=%s|plan=%s|ok=%s\n' \
        "$name" "$verdict" "$rc" "$notok" "$plan" "$oks" | tee -a tmp/rakupp-suite.log
done

echo "SUMMARY|files=$files|pass=$pass|fail=$((files-pass))|ok_lines=$assertions"
[ -n "$failed" ] && echo "FAILED|$failed"
exit 0
