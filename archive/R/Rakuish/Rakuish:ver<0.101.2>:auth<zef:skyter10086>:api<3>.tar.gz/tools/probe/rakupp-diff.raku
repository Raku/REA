#!/usr/bin/env raku
# §6 判断 B · 第三层探针：把「15 个失败」拆成可复现的最小差异
#
# 用法（同一份脚本在两个引擎上各跑一次，输出直接对比）：
#   raku   -Ilib tools/probe/rakupp-diff.raku
#   rakupp -Ilib tools/probe/rakupp-diff.raku
#
# 每一项都对应 docs/PROBE-2026-11-16-rakupp-adaptation.md §3 的一类。
# 判定按「diff 两段输出」读，不写死"应该是什么"——引擎版本会漂移。
#
# 注意：D 类（:pty）与 G 类（async accept）会真的起进程 / 起 socket，
# 在无 TTY 的 CI 里也安全（D 只探测、G 用 127.0.0.1 随机端口）。

use NativeCall;

my Str $impl = $*VM.name;
say "IMPL=$impl";
say "COMPILER=" ~ ($*RAKU.compiler.name // '?') ~ " " ~ ($*RAKU.compiler.version // '?');

# ── A. Proc::Async 的 .Channel vs .tap ────────────────────────────────
sub drain-channel($ch --> List) {
    my Str $s = ''; my Int $n = 0;
    loop {
        my $c;
        my Bool $got = so try { $c = $ch.receive; True };
        last unless $got && $c.defined;
        $s ~= $c.Str; $n++;
    }
    ($s, $n)
}

{
    my Str $R = $*EXECUTABLE.Str;
    my $p1 = Proc::Async.new($R, '-e', 'print "hello 中文"');
    my $ch1 = $p1.stdout.Channel;
    my $pr1 = $p1.start;
    my ($o1, $n1) = drain-channel($ch1);
    await $pr1;
    say "A1.channel len={$o1.chars} chunks={$n1}";

    my $p2 = Proc::Async.new($R, '-e', 'print "hello 中文"');
    my Str $o2 = ''; my Int $n2 = 0;
    $p2.stdout.tap(-> $c { $o2 ~= $c.Str; $n2++ });
    await $p2.start;
    say "A2.tap     len={$o2.chars} chunks={$n2}";

    # A3：普通 Supply 的 .Channel 作对照（排除「Channel 整体不可用」）
    my $s3 = Supply.from-list(1, 2, 3);
    my ($o3, $n3) = drain-channel($s3.Channel);
    say "A3.plain-supply-channel chunks={$n3}";

    # A4：stderr
    my $p4 = Proc::Async.new($R, '-e', '$*ERR.print("ERRTEXT")');
    my $ch4 = $p4.stderr.Channel;
    my $pr4 = $p4.start;
    my ($o4, $n4) = drain-channel($ch4);
    await $pr4;
    say "A4.stderr-channel len={$o4.chars} chunks={$n4}";
}

# ── B. 属性默认值 %*ENV.Hash 是否共享进程环境 ────────────────────────
class EnvHolder {
    has %.env = %*ENV.Hash;
    method poke(Str $k, Str $v) { %!env{$k} = $v }
    method peek(Str $k) { %!env{$k} }
}
{
    class EnvHolder2 {
        has %.env;
        submethod TWEAK() { %!env = %*ENV.Hash }
        method poke(Str $k, Str $v) { %!env{$k} = $v }
        method peek(Str $k) { %!env{$k} }
    }
    my Str $k = 'RAKUISH_DIFF_B';
    %*ENV{$k}:delete;
    EnvHolder.new.poke($k, 'attr-init');
    say "B1.attr-init  leaks-to-ENV=" ~ (%*ENV{$k}:exists ?? 'YES' !! 'no');
    %*ENV{$k}:delete;

    EnvHolder2.new.poke($k, 'tweak');
    say "B2.tweak-copy leaks-to-ENV=" ~ (%*ENV{$k}:exists ?? 'YES' !! 'no');
    %*ENV{$k}:delete;
}

# ── C. spawn 失败：Broken 还是 Kept ───────────────────────────────────
{
    my $p = Proc::Async.new('/no/such/cmd-rakuish-diff');
    my $pr = $p.start;
    my $drained = try { await $pr; True };
    my Str $status = $pr.status.^name;
    my Str $cause = $pr.status ~~ Broken ?? 'yes' !! 'no';
    my Str $exit = '';
    if $pr.status ~~ Kept {
        my $r = try { $pr.result };
        $exit = $r.defined ?? ($r.exitcode // 'undef').Str !! 'undef';
    }
    say "C1.spawn-fail status=$status broken=$cause exitcode=$exit";
}

# ── D. :pty 是否真的生效 ──────────────────────────────────────────────
{
    my Str $R = $*EXECUTABLE.Str;
    my Str $seen = 'PROBE-FAILED';
    my $tap;
    {
        CATCH { default { $seen = 'EXC:' ~ .message.lines[0] } }
        my $p = Proc::Async.new($R, '-e',
            'print $*OUT.t ?? "PTY-OK" !! "PTY-NO"', :pty(:cols(80), :rows(24)));
        my Str $out = '';
        my $done = Promise.new;
        $tap = $p.stdout.tap(
            -> $c { $out ~= $c.Str },
            done => { try { $done.keep(True) } },
            quit => -> $e { try { $done.keep(True) } },
        );
        my $st = $p.start;
        await Promise.anyof($st, Promise.in(5));
        await Promise.anyof($done, Promise.in(1));
        $seen = $out.contains('PTY-OK') ?? 'PTY-OK' !! ($out.contains('PTY-NO') ?? 'PTY-NO' !! "empty");
    }
    try { $tap.close } if $tap.defined;
    say "D1.pty-child-sees-tty=$seen";
}

# ── E. NativeCall：Pointer 与 CPointer repr 类 ───────────────────────
{
    my constant LIB = 'sqlite3';
    my Bool $lib-ok = False;
    my Str $ver = '';
    {
        CATCH { default { } }
        sub sqlite3_libversion(--> Str) is native(LIB) { * }
        $ver = sqlite3_libversion();
        $lib-ok = $ver.chars > 0;
    }
    say "E1.libsqlite-reachable={$lib-ok} version={$ver}";

    if $lib-ok {
        # E2：Pointer is rw（Rakuish 能自己控制的写法）
        sub sqlite3_open_v2_p(Str, Pointer is rw, int32, Str --> int32)
            is native(LIB) is symbol('sqlite3_open_v2') { * }
        my $h = Pointer.new;
        my Int $rc = 0;
        {
            CATCH { default { $rc = -999 } }
            $rc = sqlite3_open_v2_p('/tmp/rakuish-diff-e.db', $h, 0x46, Str);
        }
        say "E2.pointer-rw open-rc=$rc";

        # E3：CPointer repr 类（DB::SQLite 的写法）
        my Str $cls = 'skipped';
        {
            CATCH { default { $cls = 'EXC:' ~ .message.lines[0] } }
            my $mod = try { require ::('DB::SQLite') };
            # ⚠ require 成功返回的是**类型对象**，`.defined` 为 False；
            #   必须用 `.^name` 判断（Rakuish::Data::Engine::SQLite 也是这么写的）。
            if (try { $mod.^name eq 'DB::SQLite' } // False) {
                my $db = $mod.new(:filename('/tmp/rakuish-diff-e2.db'), :busy-timeout(10_000));
                my $conn = $db.connect;
                $cls = $conn.defined ?? 'ok' !! 'undef-conn';
            }
            else { $cls = 'DB::SQLite 未安装' }
        }
        say "E3.db-sqlite-connect=$cls";
    }
}

# ── F. 错误消息：多错误聚合与用词 ────────────────────────────────────
sub err-of(Str $code --> Str) {
    my $err;
    {
        CATCH { default { $err = $_ } }
        EVAL $code;
    }
    return '(no error)' unless $err.defined;
    my Str $m = try { $err.message } // '';
    $err.^name ~ ' | ' ~ $m.subst("\n", ' ⏎ ', :g);
}
{
    say "F1.two-undeclared = " ~ err-of('git(); status()');
    say "F2.one-undeclared = " ~ err-of('status()');
    say "F3.undefined-var  = " ~ err-of('say $nope');
    # F4：**裸词参数**（`git status` 无括号）——t/05、t/07 的真实用例。
    # 带括号时两边一致（F1）；无括号时 rakupp 只报最后一个、且用词变成 Undefined。
    say "F4.bareword-args  = " ~ err-of('git status');
}

# ── G. async accept handler 收尾 ─────────────────────────────────────
{
    # 说明：只做「听一个端口再关掉」，看是否吐
    # "async accept handler died: done without supply or react"。
    my Str $res = 'ok';
    {
        CATCH { default { $res = 'EXC:' ~ .message.lines[0] } }
        my $server = Supplier.new;
        my $supply = $server.Supply;
        my $tap = $supply.tap(-> $c { });
        $server.emit(1);
        $server.done;
        try { $tap.close }
        $res = 'closed';
    }
    say "G1.supply-done-then-close=$res";
    say "G2.note=server 收尾的真实用例见 t/06 / t/39（本项目未在此复现端口监听）";
}
