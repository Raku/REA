#!/usr/bin/env bash
# §6 判断 B · 第三层探针：**适配实验**
#
# 目的：把第二层「27/42」这个数字拆开看——其中有多少是「rakupp 的缺陷，
# 但 Rakuish 侧改几行就能绕过」，有多少是「引擎真的没有这项能力」。
#
# 做法：在 tmp/probe-adapt 里复制一份仓库，只改**两处**已知的引擎差异点，
# 其余一个字节不动，然后用 rakupp 跑全套件，对比第二层的 27/42。
# **不改主干**（副本用完即弃，产物在 tmp/ 下，不入库）。
#
# 两处改动（都由第二层的实测定位）：
#   ① Sys::Proc.spawn：`$proc.stdout.Channel` 在 rakupp 上收不到任何块
#      （`.tap` 正常）。改为 tap → 自建 Channel，`Handle.wait` 一行不改。
#   ② Sys：`has %.env = %*ENV.Hash` 在 rakupp 上**共享**进程环境存储
#      （`my %a = %*ENV.Hash` 却是正常复制），导致 set-env 污染 %*ENV。
#      改为 TWEAK 里显式复制。
#
# 用法：bash tools/probe/rakupp-adapt.sh [--keep]
#   --keep  保留副本目录以便手工检查
set -u
root="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$root" || exit 3
RAKUPP="${RAKUPP:-rakupp}"
command -v "$RAKUPP" >/dev/null 2>&1 || { echo "找不到 rakupp"; exit 3; }

work="$root/tmp/probe-adapt"
keep="${1:-}"
rm -rf "$work"
mkdir -p "$work"
# 只复制源码与测试；不要 .git / 已有产物，避免副本污染
# README/docs 也要带上：t/34 会读 README 做静态断言（漏了会误判成"新挂"）。
tar -cf - lib bin t docs META6.json README.md SPEC.md HANDOFF.md 2>/dev/null | tar -xf - -C "$work"
[ -d "$work/lib" ] || { echo "副本创建失败"; exit 3; }

echo "== 适配实验（引擎：$("$RAKUPP" --version 2>&1 | head -1)）=="

# ── ① Proc::Async 的 Supply→Channel 适配 ─────────────────────────────
python3 - "$work/lib/Rakuish/Sys/Proc.rakumod" <<'PY'
import io, sys
p = sys.argv[1]
s = io.open(p, encoding='utf-8').read()
old = """    my $out-ch = $proc.stdout.Channel;
    my $err-ch = $proc.stderr.Channel;"""
new = """    # ADAPT-PROBE：rakupp 上 `Supply.Channel` 对 Proc::Async 的 stdout/stderr
    # 返回的 Channel 收不到任何块（`.tap` 正常）。这里改成 tap → 自建 Channel，
    # 让 `Handle.wait` 的消费逻辑完全不变。
    my $out-ch = Channel.new;
    my $err-ch = Channel.new;
    $proc.stdout.tap(
        -> $c { $out-ch.send($c.Str) },
        done => { try { $out-ch.close } },
        quit => -> $e { try { $out-ch.close } },
    );
    $proc.stderr.tap(
        -> $c { $err-ch.send($c.Str) },
        done => { try { $err-ch.close } },
        quit => -> $e { try { $err-ch.close } },
    );"""
if old not in s:
    print("ADAPT-MISS: Proc.rakumod 锚点未命中", file=sys.stderr); sys.exit(4)
s = s.replace(old, new, 1)
io.open(p, 'w', encoding='utf-8', newline='\n').write(s)
print("ADAPT-OK: Proc::Async 改用 tap → Channel")
PY

# ── ② 属性默认值 %*ENV.Hash 的共享存储 ───────────────────────────────
python3 - "$work/lib/Rakuish/Sys.rakumod" <<'PY'
import io, sys
p = sys.argv[1]
s = io.open(p, encoding='utf-8').read()
old = "has %.env    = %*ENV.Hash;"
new = """has %.env;   # ADAPT-PROBE：rakupp 上 `has %.env = %*ENV.Hash` 会共享进程
             # 环境存储（`my %a = %*ENV.Hash` 却正常复制），故改在 TWEAK 里复制。"""
if old not in s:
    print("ADAPT-MISS: Sys.rakumod 属性锚点未命中", file=sys.stderr); sys.exit(4)
s = s.replace(old, new, 1)

anchor = "    $!proc = Rakuish::Sys::Proc.new(:max-bytes($!max-bytes));\n}"
if anchor not in s:
    print("ADAPT-MISS: Sys.rakumod TWEAK 锚点未命中", file=sys.stderr); sys.exit(4)
s = s.replace(anchor,
    "    $!proc = Rakuish::Sys::Proc.new(:max-bytes($!max-bytes));\n"
    "    # ADAPT-PROBE：显式复制，不依赖属性初始化的哈希绑定。\n"
    "    %!env = %*ENV.Hash;\n}", 1)
io.open(p, 'w', encoding='utf-8', newline='\n').write(s)
print("ADAPT-OK: Sys.%.env 改为 TWEAK 里复制")
PY

# ── 跑全套件（判据同 run-all.sh / rakupp-suite.sh）────────────────────
cd "$work" || exit 3
: > "$root/tmp/rakupp-adapt.log"
files=0; pass=0; oks=0; failed=""
for t in t/*.t; do
    [ -e "$t" ] || continue
    name="$(basename "$t")"
    files=$((files + 1))
    timeout 300 "$RAKUPP" -Ilib "$t" > "$root/tmp/adapt-$name.out" 2>&1
    rc=$?
    notok="$(grep -c 'not ok' "$root/tmp/adapt-$name.out" 2>/dev/null || true)"
    plan="$(grep -cE '^1\.\.[0-9]+( *# *SKIP.*)?$' "$root/tmp/adapt-$name.out" 2>/dev/null || true)"
    o="$(grep -cE '^ok ' "$root/tmp/adapt-$name.out" 2>/dev/null || true)"
    [ -n "$notok" ] || notok=0
    [ -n "$plan" ]  || plan=0
    [ -n "$o" ]     || o=0
    oks=$((oks + o))
    if [ "$rc" -eq 0 ] && [ "$notok" -eq 0 ] && [ "$plan" -ge 1 ]; then
        pass=$((pass + 1)); verdict=PASS
    else
        failed="$failed $name(rc=$rc,notok=$notok,plan=$plan)"; verdict=FAIL
    fi
    printf 'ADAPT|%-34s|%s|rc=%s|notok=%s|ok=%s\n' "$name" "$verdict" "$rc" "$notok" "$o" \
        | tee -a "$root/tmp/rakupp-adapt.log"
done

echo "ADAPT-SUMMARY|files=$files|pass=$pass|fail=$((files - pass))|ok_lines=$oks"
[ -n "$failed" ] && echo "ADAPT-FAILED|$failed"

cd "$root" || exit 3
[ "$keep" = "--keep" ] || rm -rf "$work"
echo "（副本：$( [ "$keep" = "--keep" ] && echo "保留在 $work" || echo "已清理" )）"
exit 0
