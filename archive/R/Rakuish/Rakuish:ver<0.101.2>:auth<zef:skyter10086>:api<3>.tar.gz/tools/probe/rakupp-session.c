/* tools/probe/rakupp-session.c
 *
 * 《Rakuish 愿景溯源》§6.6 探针②（C 侧）：用 rakupp 的公开 C ABI 实测
 * 「两次 rk_eval 之间 my 是否真存活」，顺带量启动开销、异常恢复、
 * rk_root 生命周期、一进程一解释器、以及 RkConfig.sandbox 的进程级单向性。
 *
 * 这是**只读探针**：不链接进 Rakuish、不改产品代码、不写用户文件。
 * 编译与运行见 tools/probe/README.md。输出为 key=value，便于复核。
 *
 * 头文件契约（~/.rakupp/include/rakupp/rakupp.h）：
 *   "An interpreter is a SESSION, not a one-shot: rk_eval(rk,"my $x = 41")
 *    then rk_eval(rk,"$x + 1") gives 42 ... both run in the same mainline scope."
 * 本文件的目的就是把这句注释变成实测数字。
 */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <rakupp/rakupp.h>

static double elapsed_ms(struct timespec a, struct timespec b) {
    return (double)(b.tv_sec - a.tv_sec) * 1000.0
         + (double)(b.tv_nsec - a.tv_nsec) / 1e6;
}

static void show_eval(const char *label, RkInterp rk, const char *src, RkValue *v) {
    int rc = rk_eval(rk, src, v);
    const char *err = rk_last_error(rk);
    if (rc == RK_OK)
        printf("%s_rc=%d value=%lld\n", label, rc, rk_int_get(rk_ctx(rk), *v));
    else
        printf("%s_rc=%d err=%s\n", label, rc, err ? err : "(none)");
}

int main(int argc, char **argv) {
    int want_sandbox = (argc > 1 && strcmp(argv[1], "--sandbox") == 0);

    RkConfig cfg;
    memset(&cfg, 0, sizeof cfg);       /* 全 0 = 官方推荐的默认配置 */
    cfg.sandbox = want_sandbox;

    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    RkInterp rk = rk_new(&cfg);
    clock_gettime(CLOCK_MONOTONIC, &t1);
    if (!rk) { printf("rk_new=NULL\n"); return 2; }

    printf("version=%s\n", rk_version());
    printf("sandbox=%d\n", want_sandbox);
    printf("new_ms=%.2f\n", elapsed_ms(t0, t1));

    RkValue v = NULL;

    /* ① 核心命题：跨两次 eval 的 my 是否存活 */
    show_eval("eval1_my41",  rk, "my $x = 41", &v);
    show_eval("eval2_x_plus", rk, "$x + 1", &v);

    /* ② 不是快照：改一次、再读一次 */
    show_eval("eval3_assign", rk, "$x = 100; $x", &v);
    show_eval("eval4_reread", rk, "$x", &v);

    /* ③ 语法/运行时错误之后解释器是否还能用 */
    show_eval("eval5_bad",    rk, "this is !!! not valid raku", &v);
    show_eval("eval6_recover", rk, "$x + 1", &v);

    /* ④ rk_root：把值移出 arena，跨后续 eval 仍可读 */
    {
        int rc = rk_eval(rk, "my $kept = 7; $kept", &v);
        if (rc == RK_OK) {
            RkValue rooted = rk_root(rk_ctx(rk), v);
            rk_eval(rk, "1 + 1", &v);   /* 若未 root，v 此刻已失效 */
            printf("rooted_after_next_eval=%lld\n",
                   rk_int_get(rk_ctx(rk), rooted));
            rk_unroot(rk_ctx(rk), rooted);
        } else {
            printf("rooted_after_next_eval=SKIP(root_setup_failed)\n");
        }
    }

    /* ⑤ sandbox 开关：进程级、单向（蓝图当年欠的 g_sandboxChecks 复核） */
    if (want_sandbox) {
        show_eval("sandbox_read", rk, "q[/etc/passwd].IO.slurp.chars", &v);
    }
    else {
        /* 蓝图「待核实表」欠的那条：g_sandboxChecks 的默认态到底是开还是关。
           默认 cfg 全 0，若能读 /etc/passwd 就说明默认是**不限制**。 */
        show_eval("plain_read", rk, "q[/etc/passwd].IO.slurp.chars", &v);
    }

    /* ⑥ 同一进程能否有两个 live 解释器（Agent 每连接模型的关键） */
    RkInterp second = rk_new(NULL);
    printf("second_live_rk_new=%s\n", second ? "non-NULL" : "NULL");

    clock_gettime(CLOCK_MONOTONIC, &t0);
    rk_free(rk);
    clock_gettime(CLOCK_MONOTONIC, &t1);
    printf("free_ms=%.2f\n", elapsed_ms(t0, t1));

    if (second) rk_free(second);

    /* ⑦ free 之后能否再建；sandbox 是否仍单向生效 */
    RkInterp third = rk_new(NULL);
    printf("after_free_rk_new=%s\n", third ? "non-NULL" : "NULL");
    if (third) {
        if (want_sandbox)
            show_eval("sandbox_read_after_free", third,
                      "q[/etc/passwd].IO.slurp.chars", &v);
        else
            show_eval("plain_read_after_free", third, "1 + 1", &v);
        rk_free(third);
    }
    return 0;
}
