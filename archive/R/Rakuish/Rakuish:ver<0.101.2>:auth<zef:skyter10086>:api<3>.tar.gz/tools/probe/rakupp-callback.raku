#!/usr/bin/env raku
# §6 判断 B · 第二层探针：宿主回调与并发边界（**故意隔离进程**）
#
#   RAKUPP_LIB=... raku -Ilib tools/probe/rakupp-callback.raku callback
#   RAKUPP_LIB=... raku -Ilib tools/probe/rakupp-callback.raku threads
#
# 两种模式分开跑，因为并发 rk_eval 违反「一解释器一线程」契约，
# 可能直接崩进程——不能让它污染主探针。用 `timeout` 包住、如实记退出码。
#
# callback：验证 rk_set_output 能否替掉 Rakuish 现在的 CapturingOut sink。
# threads ：验证头文件「one interpreter, one thread」在实测中是什么表现。
use NativeCall;

my constant LIB = do {
    my Str $e = (%*ENV<RAKUPP_LIB> // '').Str;
    if $e.chars && $e.IO.e { $e }
    else { die "请设 RAKUPP_LIB=/abs/path/to/librakupp.so.X.Y.Z" }
};

sub rk_new(Pointer --> Pointer)                      is native(LIB) { * }
sub rk_free(Pointer)                                 is native(LIB) { * }
sub rk_eval(Pointer, Str, CArray[Pointer] --> int32) is native(LIB) { * }
sub rk_last_error(Pointer --> Str)                   is native(LIB) { * }
# NativeCall 不接受 `Nil` 作原生返回类型（"Unknown type Nil used in native
# call"）。C 侧回调是 void，这里用 int32 + 恒返回 0 兼容调用约定。
sub rk_set_output(Pointer, &fn (Pointer, Str, uint64, int32 --> int32), Pointer)
                                                     is native(LIB) { * }

my $mode = @*ARGS[0] // 'callback';
my $rk = rk_new(Pointer);
die 'rk_new 返回 NULL' unless $rk.defined;

my $hits = 0;
sub on-output(Pointer $ud, Str $text, uint64 $len, int32 $is-err --> int32) {
    $hits++;
    say "CB|n=$hits|is_err=$is-err|len=$len|text={$text.substr(0, 60)}";
    0
}

if $mode eq 'callback' {
    rk_set_output($rk, &on-output, Pointer);
    my $out = CArray[Pointer].new(Pointer);
    my $rc = rk_eval($rk, 'say q[CAPTURED-STDOUT]; note q[CAPTURED-STDERR]; 42', $out);
    say "CALLBACK|eval_rc=$rc|hits=$hits|err=",
        ($rc ?? (rk_last_error($rk) // '').lines[0] !! '');
}
elsif $mode eq 'threads' {
    # 宿主两个线程同时进同一个解释器：这是头文件明确要求宿主串行化的场景。
    say 'THREADS|start';
    my @jobs = (^2).map: -> $i {
        start {
            my $out = CArray[Pointer].new(Pointer);
            my $rc = rk_eval($rk, "my \$v$i = $i; \$v$i + 10", $out);
            "job$i rc=$rc";
        }
    };
    my @r = await @jobs;
    say "THREADS|done|{@r.join('|')}";
}
else {
    die "未知模式：$mode（只支持 callback / threads）";
}

rk_free($rk);
say 'DONE';
