"""真 ConPTY 下的中文输入自检（Windows 专用，0.76.1 / ADR-0014）。

为什么单独有这么一个工具：
    控制台码页是**进程外**的状态，`prove6` 里没有控制台，测试永远看不到
    「输入中文卡死」这个故障。0.76.1 修的正是它，所以这里用真伪控制台跑一遍。

覆盖：
    ① 行首/参数位置的中文能正常回显；
    ② `ls 中文目录` 真的列出中文名；
    ③ `say "中文"` 求值成功（输出不乱码）；
    ④ 退出码与「无 crash」兜底。

用法：
    python tools/tty-cjk-win.py

退出码：0 通过 / 1 失败 / 2 环境不具备（非 Windows、找不到 raku、
没有控制台且没有 winpty）。

约束（与 tty-termios-win.py 相同）：
    ConPTY 的进程属性只有**驱动进程自己挂着控制台**时才生效。没有控制台时
    自动用 winpty 重启一次自己（winpty 不透传退出码，所以走裁决文件）。
"""

import ctypes
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RELAUNCH_ENV = "RAKUISH_CJK_RELAUNCHED"
VERDICT_ENV = "RAKUISH_CJK_VERDICT"

_tw_spec = importlib.util.spec_from_file_location(
    "tw", os.path.join(HERE, "tty-termios-win.py"))
tw = importlib.util.module_from_spec(_tw_spec)
_tw_spec.loader.exec_module(tw)

RAKU = tw.RAKU


class Session(tw.ConPTY):
    """在 ConPTY 里跑 rakuish，并可写入按键、按原始字节等待。"""

    def write(self, data):
        if isinstance(data, str):
            data = data.encode("utf-8")
        n = tw.wt.DWORD(0)
        tw.kernel32.WriteFile(self.h_in_write, data, len(data),
                              ctypes.byref(n), None)

    @property
    def raw(self):
        with self._lock:
            return bytes(self.buf)

    def wait_raw(self, needle, timeout=30.0):
        if isinstance(needle, str):
            needle = needle.encode("utf-8")
        end = time.time() + timeout
        while time.time() < end:
            if needle in self.raw:
                return True
            time.sleep(0.15)
        return False

    def type_text(self, text, per_char=0.08):
        """逐字符写入：一次性灌入会和行编辑器的逐字节读竞争，测出来的失败是假象。"""
        for ch in text:
            self.write(ch)
            time.sleep(per_char)


def has_console():
    mode = tw.wt.DWORD(0)
    return bool(tw.kernel32.GetConsoleMode(
        tw.kernel32.GetStdHandle(-10), ctypes.byref(mode)))


def relaunch_under_winpty():
    winpty = shutil.which("winpty")
    if not winpty:
        print("SKIP: 当前进程没有控制台，且找不到 winpty（ConPTY 属性不会生效）")
        return 2
    fd, path = tempfile.mkstemp(prefix="rakuish-cjk-", suffix=".rc")
    os.close(fd)
    env = dict(os.environ, **{RELAUNCH_ENV: "1", VERDICT_ENV: path})
    try:
        subprocess.run([winpty, "-Xallow-non-tty", sys.executable,
                        os.path.abspath(__file__)], cwd=ROOT, env=env)
        with open(path, encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return 2
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def check():
    if not sys.platform.startswith("win"):
        print("SKIP: 仅 Windows（POSIX 终端本来就是 UTF-8）")
        return 2
    if not os.path.exists(RAKU):
        print("SKIP: 找不到 raku: %s" % RAKU)
        return 2
    if not has_console():
        if os.environ.get(RELAUNCH_ENV):
            print("SKIP: 已经在 winpty 下仍然拿不到控制台")
            return 2
        return relaunch_under_winpty()

    work = tempfile.mkdtemp(prefix="rakuish-cjk-")
    os.makedirs(os.path.join(work, "中文目录"), exist_ok=True)
    with open(os.path.join(work, "中文目录", "文件.txt"), "w",
              encoding="utf-8") as f:
        f.write("x\n")

    fails = []
    passes = 0
    # 在临时目录里跑：中文目录建在 work 下，REPL 的 cwd 也必须是 work。
    # 0.77.0 修正 —— 原来 `cwd=ROOT` 而目录建在 work，`ls 中文目录` 只有在
    # 仓库根**恰好**也有同名目录时才会通过（0.76.1 就是靠一个手工遗留的
    # 目录骗过了自检）。这类「被测对象和夹具不在同一个目录」的假绿最难发现：
    # 失败信息看起来像功能坏了，实际是夹具没生效。
    cmd = '"%s" -I"%s" "%s"' % (
        RAKU, os.path.join(ROOT, "lib"), os.path.join(ROOT, "bin", "rakuish"))
    p = Session(cmd, cwd=work, cols=100, rows=30)
    try:
        if not p.wait_raw("Rakuish", 60):
            print("FAIL  banner 没出来（ConPTY 没挂上？）")
            return 1
        time.sleep(1.0)

        # ① 参数位置的中文 + ② 中文路径能被 ls 列出
        p.type_text("ls 中文目录")
        time.sleep(0.5)
        if "中文目录".encode("utf-8") in p.raw:
            passes += 1
            print("PASS  中文在输入行正常回显")
        elif os.environ.get(RELAUNCH_ENV):
            # winpty 降级路径：它自己做 UTF-8 ↔ 控制台码页转换，回显字节
            # 不保证仍是 UTF-8（但命令能正确送达 —— 下面 ls 会证明）。
            # 这一条只有真控制台才能判定，降级下记 skip，不冒充失败。
            print("SKIP  winpty 降级：回显经 winpty 转码，不判定（真控制台下才有效）")
        else:
            fails.append("输入行没有回显中文（码页没切到 UTF-8？）")

        mark = len(p.raw)
        p.write("\r")
        ok_ls = p.wait_raw("文件.txt", 30)
        tail = p.raw[mark:].decode("utf-8", "replace")
        if ok_ls and "Malformed" not in tail:
            passes += 1
            print("PASS  ls 中文目录 列出内容")
        else:
            fails.append("ls 中文目录 没有列出内容（tail=%r）" % tail[-160:])

        # ③ 中文字符串求值 + 输出不糊
        p.type_text('say "中文"')
        time.sleep(0.4)
        mark = len(p.raw)
        p.write("\r")
        ok_say = p.wait_raw("Bool::True", 30)
        out = p.raw[mark:].decode("utf-8", "replace")
        if ok_say and "Malformed" not in out:
            passes += 1
            print("PASS  say \"中文\" 求值成功")
        else:
            fails.append("say 中文 没有正常求值（out=%r）" % out[-160:])

        # ④ 兜底：没有 crash 痕迹
        all_text = p.raw.decode("utf-8", "replace")
        for bad in ("Cannot invoke", "Unhandled exception", "===SORRY!==="):
            if bad in all_text:
                fails.append("输出里出现 %s" % bad)
        if not [f for f in fails if f.startswith("输出里出现")]:
            passes += 1
            print("PASS  无 crash 痕迹")

        p.write("exit\r")
        p.wait(10)
    finally:
        p.close()
        shutil.rmtree(work, ignore_errors=True)

    print("\n%d 项通过，%d 项失败" % (passes, len(fails)))
    for f in fails:
        print("FAIL  " + f)
    return 0 if not fails else 1


def main():
    rc = check()
    verdict = os.environ.get(VERDICT_ENV)
    if verdict:
        try:
            with open(verdict, "w", encoding="utf-8") as f:
                f.write(str(rc))
        except OSError:
            pass
    return rc


if __name__ == "__main__":
    sys.exit(main())
