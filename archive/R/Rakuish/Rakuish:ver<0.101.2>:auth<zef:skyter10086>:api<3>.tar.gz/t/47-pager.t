#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Data::Pager;

# 47-pager.t —— 前端分页（0.92.0 / ADR-0027）
#
# 主张：**分页器只切页，不判断策略；策略可测，切页也可测。**
# 这里不起终端：读一行、写一行都注入，所以「Enter/q/EOF/刚好整页」这些
# 分支全都能断言 —— 真终端只剩「按键真的能到这一层」这一件事，
# 那一条交给 tools/pager-posix.py（与 ctrl-c 探针同一套 PTY 驱动）。

my $pager = Rakuish::Data::Pager.new;

# ── ① 环境取值归一 ──────────────────────────────────────────────────
is $pager.mode(''),        'auto',   '空值 → auto';
is $pager.mode('auto'),    'auto',   'auto';
is $pager.mode('never'),   'never',  'never';
is $pager.mode('OFF'),     'never',  'OFF 大小写不敏感';
is $pager.mode('0'),       'never',  '0 → never';
is $pager.mode('always'),  'always', 'always';
is $pager.mode('on'),      'always', 'on → always';
is $pager.mode('yes'),     'always', 'yes → always';
is $pager.mode('what'),    'auto',   '未知值回落 auto（不静默变 always）';

# ── ② 每页行数 ──────────────────────────────────────────────────────
is $pager.size-for-height(24), 22, '高度 24 → 每页 22 行（留两行）';
is $pager.size-for-height(0),  20, '高度未知 → 默认 20';
is $pager.size-for-height(1),  20, '高度太小 → 默认 20';

# ── ③ 该不该分页 ────────────────────────────────────────────────────
nok $pager.wants-page(:op<explore>, :lines(100), :height(24), :mode<auto>,
                      :tty(False)), '非终端：不分页';
nok $pager.wants-page(:op<explore>, :lines(100), :height(24), :mode<never>),
    'never：不分页';
nok $pager.wants-page(:op<explore>, :lines(5), :height(24), :mode<auto>),
    '装得下：不分页';
ok  $pager.wants-page(:op<explore>, :lines(100), :height(24), :mode<auto>),
    'explore + auto + 超一页：分页';
nok $pager.wants-page(:op<eval>, :lines(100), :height(24), :mode<auto>),
    'auto 只认 explore（cat 大文件应该全给）';
ok  $pager.wants-page(:op<eval>, :lines(100), :height(24), :mode<always>),
    'always：任何超过一页的结果都分页';

# ── ④ 切页本身 ──────────────────────────────────────────────────────
# 返回 Hash 而不是 (Bool, List)：Raku 里 `my ($a, @b) = (True, @list)` 会把
# 整个 List 当成 @b 的**单个元素**（本项目已踩过同类摊平坑）。
sub run-paginate(Str $text, Int $size, @answers) {
    my @out;
    my @pending = @answers;
    my Bool $paged = $pager.paginate(
        $text,
        -> { @pending.elems ?? @pending.shift !! Nil },
        -> Str $l { @out.push($l) },
        :$size,
    );
    %( paged => $paged, out => @out.List );
}

sub out-of(%r) { %r<out>.List }

{
    my %r = run-paginate("a\nb\nc", 5, []);
    nok %r<paged>, '一页装得下：返回 False';
    is out-of(%r).elems, 0, '一页装得下：一个字节都不写（交给调用方打印）';
}

{
    my %r = run-paginate("1\n2\n3\n4\n5\n6\n7\n8\n9\n10", 3, ['', 'q']);
    my @out = out-of(%r);
    ok %r<paged>, '多页：返回 True';
    is @out[0..2].join(','), '1,2,3', '第一页三行';
    like @out[3], /'-- more (3/10'/, '第一页后有 more 提示与进度';
    is @out[4..6].join(','), '4,5,6', '回车之后是第二页';
    like @out[7], /'-- more (6/10'/, '第二页后仍有提示';
    is @out.elems, 8, 'q 之后不再输出（没有第三页）';
}

{
    my @out = out-of(run-paginate("1\n2\n3\n4\n5\n6", 3, ['', '']));
    is @out.elems, 7, '刚好整页：最后一页后面不加提示';
    is @out[6], '6', '最后一行是内容而不是提示';
}

{
    my %r = run-paginate("1\n2\n3\n4", 2, [Nil]);
    my @out = out-of(%r);
    ok %r<paged>, 'EOF 时的分页';
    is @out.elems, 3, 'EOF：只出一页 + 提示，不再继续';
    like @out[2], /'more'/, 'EOF 前提示已经给出';
}

{
    is out-of(run-paginate("1\n2\n3\n4", 2, ['Q'])).elems, 3, '大写 Q 也算退出';
}

{
    my @out = out-of(run-paginate("1\n2\n3\n4", 2, ['x', 'x', 'x']));
    is @out.elems, 5, '非 q 的任意输入都算「下一页」（两页 + 一个提示）';
    is @out.tail, '4', '一直翻到底';
}

# ── ⑤ 进程内路径 page()（explore 在引擎自己 TTY 上走它）─────────────
# 用假的 in/out：交互分支不能只靠真终端验，否则「一页装得下就什么都不打印」
# 这种回归会一路漏到界面上（0.92 开发中真的漏过一次）。
my class FakeIn {
    has @.answers is rw;
    method t(--> Bool) { True }
    method get() { @!answers.elems ?? @!answers.shift !! Nil }
}
my class FakeOut {
    has @.lines is rw;
    method say(*@a) { @!lines.push(@a.map(*.Str).join(' ')); True }
    method print(*@a) { @!lines.push(@a.map(*.Str).join); True }
    method flush() { Nil }
}

{
    my $in  = FakeIn.new(:answers([]));
    my $out = FakeOut.new(:lines([]));
    my Str $text = $pager.page("a\nb", :$in, :$out, :interactive(False));
    is $text, "a\nb", '非交互：原样返回文本';
    is $out.lines.elems, 0, '非交互：不自己打印（由调用方决定）';
}

{
    my $in  = FakeIn.new(:answers([]));
    my $out = FakeOut.new(:lines([]));
    $pager.page("a\nb", :$in, :$out, :interactive(True));
    is $out.lines.elems, 2, '交互 + 一页装得下：**也要打印**（不能静默什么都不出）';
}

{
    my $small = Rakuish::Data::Pager.new(:page-size(2));
    my $in  = FakeIn.new(:answers(['', 'q']));
    my $out = FakeOut.new(:lines([]));
    $small.page("1\n2\n3\n4", :$in, :$out, :interactive(True));
    is $out.lines[0..1].join(','), '1,2', '交互：第一页按 page-size 切';
    like $out.lines[2], /'-- more (2/4'/, '交互：more 提示带进度';
    is $out.lines[3..4].join(','), '3,4', '交互：回车后第二页';
    is $out.lines.elems, 5, '交互：最后一页之后不再加提示';
}

done-testing;
