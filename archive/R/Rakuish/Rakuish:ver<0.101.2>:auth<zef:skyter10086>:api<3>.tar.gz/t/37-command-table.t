use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::REPL::Session;
use Rakuish::REPL::Shell;

# 0.77.0 / ADR-0015：
#   §2 命令名单一数据源（顺带修 hint / plugin 补不出来）
#   §3 输入序（history）与格号（Out[n]）分离
#
# 这一版没有新能力，所以断言的重点是**退化**：两边不能各说各话。

my $dir = $*TMPDIR.IO.add("rakuish-table-{$*PID}");
$dir.mkdir;
$dir.add('a.txt').spurt("hello\n");
LEAVE {
    try { $dir.add('a.txt').unlink };
    try { $dir.rmdir };
}

my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
my $sh  = Rakuish::REPL::Shell.new(:sys($sys));
my $s   = Rakuish::REPL::Session.new(:sys($sys));

my Str $src = 'lib/Rakuish/REPL/Shell.rakumod'.IO.slurp;

# ── §2.1 名单来源：三个视图必须是同一张表 ───────────────────────────
my @all     = $sh.command-names.List;
my @shell   = $sh.shell-command-names.List;

ok @all.elems > 30, "COMMANDS 非空（{@all.elems} 个）";
is @shell.elems, $sh.shell-command-names.elems, 'shell 名单稳定';
ok (@shell (&) @all).elems == @shell.elems, '每个 shell 命令都在总名单里';
ok @all.elems > @shell.elems, '总名单比 shell 多（会话级 + Raku API）';

# 这一条是 0.77 的起因：hint / plugin 有完整 usage，却不在任何一张表里，
# 于是 `help hint` 能查、Tab 却补不出来。
for <hint plugin> -> $n {
    ok @all.first({ $_ eq $n }).defined, "$n 在总名单里（0.77 前漏登记）";
    ok $sh.usage($n).chars > 0, "$n 有用法文本";
    ok $sh.completions($n.substr(0, 2), 2).grep({ $_ eq "$n " }).elems == 1,
       "Tab 能补出 $n";
    ok $sh.completions("help $n", 5 + $n.chars).grep({ $_ eq "help $n " }).elems == 1,
       "help 的二级补全能补出 $n";
}

# 0.97.3：后来新增的 DSL 函数此前只在 DSL 里导出，没登记进命令表，
# 于是 help 查不到、Tab 补不出、help 列表里也没有。这里逐名守护。
my Str $help-index = $sh.handle('help').out;
for <bg-exec bg-jobs fg bg open-db tty-exec pty-exec peach recent> -> $n {
    ok @all.first({ $_ eq $n }).defined, "$n 在总名单里（0.97.3 前漏登记）";
    ok $sh.usage($n).chars > 0, "$n 有用法文本";
    ok $sh.completions($n.substr(0, 2), 2).grep({ $_ eq "$n " }).elems == 1,
       "Tab 能补出 $n";
    ok $help-index.contains($n), "help 列表含 $n";
}

# ── §2.2 名单 ↔ usage：不能有「在表里但查不到用法」 ─────────────────
my @no-usage = @all.grep({ $sh.usage($_).chars == 0 });
is @no-usage.elems, 0, "每个登记的命令都有用法（缺: {@no-usage.join(', ')}）" or diag @no-usage;

# ── §2.3 名单 ↔ 分发：Shell 表里的每个名字都必须真有分支 ────────────
# `given $cmd` 的 default 返回 Nil，所以「没分支」的表现就是 handle 返回未定义。
my @not-dispatched = @shell.grep({ !$sh.handle($_).defined });
is @not-dispatched.elems, 0,
   "每个 shell 命令都有分发分支（缺: {@not-dispatched.join(', ')}）" or diag @not-dispatched;

# 反向：分发表里不许有表外分支（否则补全找不到、help 也查不到）。
# 用 q[] 拼锚点：双引号串里的 `{` 会被当成代码块。
my Str $anchor = q[    given $cmd {] ~ "\n" ~ q[        when 'cd'];
# usage() 里也有同样的 `given $cmd {`，且同样以 when 'cd' 开头 —— 必须从
# handle() 的位置往后找，否则抓到的是 usage 那张表（会把会话级命令误判成多余）。
my Int $hpos   = $src.index('method handle(');
my Int $dstart = $hpos > 0 ?? $src.index($anchor, $hpos) !! -1;
ok $dstart > 0, '定位到分发表';
my Str $dbody = '';
if $dstart > 0 {
    my Int $dend = $src.index("\n    }\n}", $dstart);
    $dbody = $src.substr($dstart, $dend - $dstart) if $dend > $dstart;
}
# 用 \x27 表示单引号：正则里直接写引号会和 Raku 的字符串/正则定界符打架。
my @branches = $dbody ~~ m:g/ 'when' \s+ \x27 (<[a..z]>+) \x27 /;
my @branch-names = @branches.map({ ~$_[0] }).sort;
ok @branch-names.elems > 20, "解析到分发表（{@branch-names.elems} 个分支）";
my @missing = @branch-names.grep({ !(@shell.first({ $_ eq $^n })) });
is @missing.elems, 0, "分发表没有表外分支（多出: {@missing.join(', ')}）" or diag @missing;

# ── §2.4 OPTIONS 的键必须是已知命令 ─────────────────────────────────
my @bad-opt = <ls head tail echo mkdir cp rm grep wc pwd open>.grep({
    !(@all.first({ $_ eq $^n }))
});
is @bad-opt.elems, 0, 'OPTIONS 的键都是已知命令';

# ── §2.5 渲染层的 op 名单也来自同一处 ───────────────────────────────
# 0.75 新增 doc / pushd / popd / dirs / bookmark 时，Session 里手抄的那份
# SHELL-OPS 没跟上；现在它读 Shell 的表，所以必然覆盖。
for <doc pushd popd dirs bookmark> -> $n {
    ok @shell.first({ $_ eq $n }).defined, "$n 在 shell 名单里（渲染层据此判值）";
}

# ── §2.6 帮助索引由表生成，不再手写 ─────────────────────────────────
my Str $helpidx = $sh.handle('help').out;
for <hint plugin perf log dirs bookmark> -> $n {
    ok $helpidx.contains($n), "help 索引里有 $n";
}
# 手写版把 hint / plugin 混在 shell 那一段里；生成版按组分类，会话级单列。
ok $helpidx.contains('会话级命令'), '索引按组分类（会话级单列）';

# 0.89.0：帮助索引按真实终端宽度折行（原来硬编码 62，40 列会溢出）。
{
    $sh.width = 40;
    my Str $narrow = $sh.handle('help').out;
    my Int $max = $narrow.lines.grep({ .chars }).map(*.chars).max // 0;
    ok $max <= 40, "40 列下帮助索引不超宽（最宽 {$max}）";
    $sh.width = 0;
    my Str $auto = $sh.handle('help').out;
    is $auto.lines.elems, $helpidx.lines.elems, '宽度未知时退回 62 列的原有观感';
}

ok $helpidx.contains('Raku / 文件 API'), '索引保留 API 段';
# ── §3.1 会话级命令进 history，但不占 Out 编号 ─────────────────────
my $s1 = Rakuish::REPL::Session.new(:sys($sys));
$s1.eval-line('1 + 1');
is $s1.index, 1, '一格求值后格号 = 1';
$s1.eval-line('config set clock on');
is $s1.history.List.elems, 2, '会话级命令也进 history';
is $s1.index, 1, '会话级命令不占格号（Out[n] 编号不跳）';
is $s1.history.List.tail, 'config set clock on', 'history 末条是刚敲的会话命令';

# ── §3.2 失败的 Raku 格进 history，仍不占格号 ───────────────────────
$s1.eval-line('die "boom"');
is $s1.history.List.elems, 3, '失败格也进 history';
is $s1.index, 1, '失败格不占格号（既有契约不变）';

# ── §3.3 !! 重放的是「用户敲的上一行」，不是「上一格求值」 ──────────
# 0.77 之前：config 不进 history，于是 !! 重放了 1 + 1。
my $s2 = Rakuish::REPL::Session.new(:sys($sys));
$s2.eval-line('40 + 2');
$s2.eval-line('config set clock on');
my $rep = $s2.eval-line('!!');
ok $rep.out.contains('clock=on'), '!! 重放上一行（会话命令），不是上一格求值';
nok $rep.out.contains('42'), '!! 没有退回更早的 40 + 2';
is $s2.history.List.tail, 'config set clock on', '!! 记的是展开后的真实命令';
nok $s2.history.List.grep({ $_ eq '!!' }).elems, '!! 本身不额外记一条';

# ── §3.4 多行格记完整源码，续行中间态不记 ───────────────────────────
my $s3 = Rakuish::REPL::Session.new(:sys($sys));
$s3.eval-line(q[for 1..2 {]);
$s3.eval-line(q[  say $_ + 0;]);
is $s3.history.List.elems, 0, '续行中间态不进 history';
$s3.eval-line(q[}]);
is $s3.history.List.elems, 1, '多行格只记一条';
ok $s3.history.List[0].contains('for 1..2'), '记的是完整源码（不是最后一行 }）';
ok $s3.history.List[0].contains('say $_ + 0;'), '完整源码含中间行';

# ── §3.5 history 的编号与 !n 指向同一行 ─────────────────────────────
my $s4 = Rakuish::REPL::Session.new(:sys($sys));
$s4.eval-line('"first".chars');
$s4.eval-line('config set timing off');
$s4.eval-line('"second".chars');
my Str $h = $s4.eval-line('history').out;
ok $h.contains('2  config set timing off'), 'history 把会话命令列进编号';
# !2 指向第 2 行 —— 与 history 显示的一致
ok $s4.eval-line('!2').out.contains('timing=off'), '!n 与 history 编号同源';

# ── §3.6 空行与纯空白不记录 ─────────────────────────────────────────
my $s5 = Rakuish::REPL::Session.new(:sys($sys));
$s5.eval-line('');
$s5.eval-line('   ');
is $s5.history.List.elems, 0, '空行不进 history';
is $s5.index, 0, '空行不占格号';

done-testing;
