use lib 'lib';
use Test;

# 60-followups.t —— ADR-0035 后续清单的引擎侧集成（0.101.0）
#
# V-285：In[n]/Out[n] 引用补全经 Session.completions（真实 @!out 历史）
# V-286：命令不存在的引擎侧精确判定——跨格 sub / my 变量不被误标红
# 两者都在引擎侧 Session 里读私有状态；这里用真实 eval-line 造状态，
# 比 PTY 更稳；PTY 链路本身由 t/59 覆盖。
#
# ⚠ 造声明/变量用 q[...] 字面量，避免 $ 被 shell/heredoc 插值（项目教训）。

use Rakuish::REPL::Session;

my $s = Rakuish::REPL::Session.new;

# ── 1. In/Out 引用补全（V-285）───────────────────────────────────────
{
    # 造三个成功格：@!out 变成 3 条
    ok $s.eval-line('10').ok, '成功格 1';
    ok $s.eval-line('20').ok, '成功格 2';
    ok $s.eval-line('30').ok, '成功格 3';

    my @out = $s.completions('Out[', 5);
    is @out.grep({ $_ eq 'Out[1]' }).elems, 1, 'Out[ 补出 Out[1]';
    is @out.grep({ $_ eq 'Out[3]' }).elems, 1, 'Out[ 补出 Out[3]';
    is @out.grep({ $_ eq 'Out[4]' }).elems, 0, '不补出不存在的 Out[4]';

    my @in = $s.completions('In[2', 4);
    is @in.grep({ $_ eq 'In[2]' }).elems, 1, 'In[2 补出 In[2]';

    my @inside = $s.completions('say Out[1', 9);
    is @inside.grep({ $_ eq 'say Out[1]' }).elems, 1, '表达式内 Out[ 补出整行替换';

    my @prefixed = $s.completions('fooOut[', 7);
    is @prefixed.grep({ $_.contains('Out[') }).elems, 0,
       '标识符紧跟的 fooOut[ 不走引用补全';
}

# ── 2. 引擎侧名字精确判定（V-286）──────────────────────────────────
sub kinds(Rakuish::REPL::Session $sess, Str $line --> Str) {
    $sess.error-marks($line).map({ .<kind> // '' }).join(',')
}

{
    my $fresh = Rakuish::REPL::Session.new;
    is kinds($fresh, 'myfoo arg'), 'command',
       '未声明的 foo bar 形态被标 command（基线）';

    ok $fresh.eval-line(q[sub myfoo($x) { $x + 1 }]).ok, '跨格 sub 声明成功';
    is kinds($fresh, 'myfoo arg'), '',
       '声明 sub 后首词不再误标（V-286 核心）';

    ok $fresh.eval-line(q[my $zz = 7]).ok, '跨格 my 变量成功';
    is kinds($fresh, 'zz arg'), '',
       '跨格 my 变量首词不再误标';

    is kinds($fresh, 'nosuchcmd arg'), 'command',
       '真正的未知命令仍标红（不放松判定）';
}

done-testing;
