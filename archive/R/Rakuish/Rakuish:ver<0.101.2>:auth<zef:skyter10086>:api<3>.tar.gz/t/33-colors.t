#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::REPL::Highlight;
use Rakuish::REPL::Chrome;
use Rakuish::REPL::Session;

# 33-colors.t —— 结果着色与输入行语法高亮（0.74.0 / SPEC V-176 / V-177 / ADR-0011）。
#
# 这里只测**不依赖终端**的部分：着色器的纯文本等价、色表、以及「无色时
# 逐字节不变」。真 PTY 下的实际观感（列对齐、输入区不错位）由
# `tools/tty-check.py` 覆盖 —— prove6 跑在管道里，$*OUT.t 恒为假。

sub strip-ansi(Str $s --> Str) {
    $s.subst(/ \e \[ <[0..9;]>* m /, :g, '');
}

# ── 一、高亮器的核心不变式：纯文本逐字符等价 ────────────────────────
# 行编辑器用 display-width 定位光标与清屏，着色串的纯文本部分多一个或少一个
# 字符都会让输入区错位（ADR-0011 §4.2）。这条断言就是那条不变式。
my @samples =
    '',
    '1 + 1',
    q{say "hello"},
    q{'single quoted'},
    q{my $x = 42; # trailing comment},
    q{for @list -> $v { say $v }},
    q{my %h = (a => 1, b => 2);},
    q|say "escaped \" quote"|,
    q{"unclosed string},
    q{1.abs},
    q{$},
    q{a-b},
    q{中文 "字符串" 混排},
    q{  leading and trailing  },
    q{if $x > 0 && $y < 10 { say True }},
    q{class Foo is Bar { has $.x }},
    q{# only a comment},
    q{},
    q{say "日本語テキスト" # コメント},
    q{$*CWD.Str},
    q{$!private-attr},
    q{%*ENV<HOME>},
    q{@*ARGS[0]},
    q{&some-sub(1, 2)},
    q{0x1F + 1_000 + 3.14e-2},
    q{a # b " c},
    q{"a" # "b"},
    ;

for @samples.kv -> $i, $s {
    is strip-ansi(highlight-line($s)), $s,
       "样本 {$i} 的纯文本等价（{ $s.chars } 字符）";
}

# ── 二、关闭着色时逐字节相同（不经过任何扫描） ──────────────────────
for @samples.kv -> $i, $s {
    is highlight-line($s, :!color), $s, "样本 {$i} 在 :!color 下原样返回";
}

# ── 三、各类 token 确实命中了对应颜色 ──────────────────────────────
sub painted(Str $s, Str $probe --> Bool) { highlight-line($s).contains($probe) }

ok painted('say 1', %CLR{'b-blue'}), '关键字 → 粗蓝';
ok painted('"x"', %CLR<green>), '字符串 → 绿';
ok painted('# note', %CLR<gray>), '注释 → 灰';
ok painted('42', %CLR<yellow>), '数字 → 黄';
ok painted('$x', %CLR<cyan>), '变量 → 青';
ok painted('my $x', %CLR{'b-blue'}), 'my 也被识别为关键字';

nok painted('a-b', %CLR{'b-blue'}), '普通标识符不当作关键字';
nok painted('$', %CLR<cyan>), '孤立的 $ 不吞成变量';
ok painted("'a#b'", %CLR<green>), '字符串里的 # 不当注释';
nok painted("'a#b'", %CLR<gray>), '字符串里的 # 没有注释色';

# ── 四、色表与路径分类 ────────────────────────────────────────────
is %CLR<reset>, "\e[0m", '色表有 reset';
is paint('x', %CLR<red>, True), %CLR<red> ~ 'x' ~ %CLR<reset>, 'paint 包住两端';
is paint('x', %CLR<red>, False), 'x', 'paint 关闭时原样';
is paint('x', Nil, True), 'x', 'paint 遇到空色码不抛异常';

my $dir = $*CWD.add('lib');
is path-color($dir), %CLR{'b-blue'}, '目录 → 粗蓝';

# 普通文件用**自建夹具**，不拿仓库里的文件：文件模式取决于检出方式。
# 从 drvfs（/mnt/c）或 windows 侧拷进来的树，每个文件都是 777，`.x` 为真，
# 于是 META6.json 被判成「可执行」、着色成粗绿 —— 那会被读成产品回归，
# 实际是夹具问题（WSL 验收时真的撞上过）。
my $tmp = $*TMPDIR.add("rakuish-color-{$*PID}");
$tmp.mkdir;
my $file = $tmp.add('plain.txt');
$file.spurt("x\n");
chmod 0o644, $file;               # 显式去掉执行位（Windows 上是 no-op）
LEAVE { try { $file.unlink }; try { $tmp.rmdir } }
is path-color($file), '', '普通文件 → 无色';

# 可执行的判定分平台：POSIX 看执行位，Windows 看扩展名。
# `.x` 在本版 Rakudo 的 Win32 上会抛（rindex ... got null），并且原来被
# `try` 吞掉 —— Windows 上从来没有把 exe 标绿过（0.77.0 修）。
my $exec-color = %CLR<b-green>;
if $*DISTRO.is-win {
    my $exe = $tmp.add('tool.exe');
    $exe.spurt('');
    LEAVE { try { $exe.unlink } }
    is path-color($exe), $exec-color, 'Windows：.exe → 粗绿（按扩展名）';
    is path-color($tmp.add('notes.md')), '', 'Windows：.md 不是可执行';
}
else {
    chmod 0o755, $file;
    is path-color($file), $exec-color, 'POSIX：置上执行位 → 粗绿';
}

# 不存在的路径：无色，且**不留 unhandled Failure**（0.79.1 真修）。
# `.l` / `.d` 对不存在的路径返回 Failure 而不是抛异常，`try` 和链式 `.so`
# 都挡不住（详见 Chrome.rakumod 的注释）。单次调用看不到警告、纯粹看 GC
# 时机 —— 所以这里用循环把 GC 逼出来，并把 `$*ERR` 重定向到文件核对。
# 0.79.0 只靠「本地跑没看到」验收，结果是假绿，zef install 里照样炸。
my $ghost = $tmp.add('does-not-exist-' ~ $*PID);
is path-color($ghost), '', '不存在的路径 → 无色';
nok $ghost.e, '夹具确实不存在';
my $err-cap = $tmp.add("stderr-{$*PID}.txt");
my $efh = $err-cap.open(:w);
{
    my $*ERR = $efh;
    for ^300 {
        path-color($ghost);
        path-color($tmp.add('notes.md'));
    }
}
$efh.close;
nok $err-cap.slurp.contains('unhandled'),
    '压力循环下不产生 unhandled Failure';
$err-cap.unlink;

# ── 五、Session：非 TTY 下即使 color=True 也不输出 ANSI ───────────
# 这一条守的是 SPEC V-116：管道里的 stdout 只能是求值结果。
# 显式 set-tty(False)：断言的是「非 TTY 代码路径」，不依赖宿主 stdout 形态
# （Windows NUL 会把 $*OUT.t 误判成 True，见 Rakuish::Sys::Term）。
my $cs = Rakuish::REPL::Session.new(:color(True));
$cs.set-tty(False);
my $rr = $cs.eval-line('ls');
my Str $rendered = $cs.render($rr);
nok $rendered.contains("\e["), '非 TTY：ls 结果不含 ANSI（即使 color=True）';
ok $rendered.chars > 0, '非 TTY：ls 仍正常输出文件名';

my $rl = $cs.eval-line('ls -l');
nok $cs.render($rl).contains("\e["), '非 TTY：ls -l 结果不含 ANSI';

my $rh = $cs.eval-line('help()');
nok $cs.render($rh).contains("\e["), '非 TTY：help() 结果不含 ANSI';

my $re = $cs.eval-line('1 + 1');
nok $cs.render($re).contains("\e["), '非 TTY：Out[n] 标签不含 ANSI';

# ── 六、默认构造（未传 color）也必须是纯文本 ─────────────────────
my $plain = Rakuish::REPL::Session.new;
$plain.set-tty(False);
my $pr = $plain.eval-line('ls');
nok $plain.render($pr).contains("\e["), '默认 Session 不带颜色（安全的默认值）';
nok $plain.color, '默认 color 为假（安全的默认值，别改成 True）';

# ── 七、跨行高亮（0.97.0 / ADR-0031 延伸）───────────────────────────
# set-continuation 把已提交的续行源码交给高亮器：下一行开头若还在上一行的
# 未闭合引号里，整段染成字符串色。核心不变式（纯文本等价）在跨行下同样成立。
{
    set-continuation('');
    is strip-ansi(highlight-line('abc"')), 'abc"',
        '跨行：无 continuation 时纯文本等价';

    # 未闭合双引号延续到下一行
    set-continuation('my $s = "hello');
    my Str $l1 = highlight-line('world"');
    ok $l1.contains(%CLR<green>), '跨行："..." 未闭合，下一行开头是字符串色';
    is strip-ansi($l1), 'world"', '跨行：字符串染色保持纯文本等价';

    # 闭合后余下按正常 token 染（关键字应出现蓝色）
    set-continuation('say "abc');
    my Str $l2 = highlight-line('def" say 1');
    is strip-ansi($l2), 'def" say 1', '跨行：闭合后余下纯文本等价';
    ok $l2.contains(%CLR<green>), '跨行：闭合记号前是字符串色';
    ok $l2.contains(%CLR{'b-blue'}), '跨行：闭合后的关键字恢复染色';

    # q[...] 定界符跨行
    set-continuation('my $s = q[line one');
    my Str $l3 = highlight-line('line two]');
    ok $l3.contains(%CLR<green>), '跨行：q[...] 未闭合，下一行是字符串色';
    is strip-ansi($l3), 'line two]', '跨行：q[] 染色保持纯文本等价';

    # 续行已闭合 → 下一行回到正常代码态
    set-continuation('say "done"');
    my Str $l4 = highlight-line('say 1');
    nok $l4.contains(%CLR<green>), '跨行：引号已闭合则下一行不是字符串色';
    ok $l4.contains(%CLR{'b-blue'}), '跨行：已闭合后关键字正常染';

    set-continuation('');
}

# Session 续行分支真的把状态传给了高亮器：eval 一行未闭合的引号 → incomplete，
# 此时 continuation 应已设置；下一行开头会被染成字符串色。
{
    my $ss = Rakuish::REPL::Session.new(:color(True));
    set-continuation('');
    my $r1 = $ss.eval-line('my $s = "abc');
    is $r1.op, 'more', 'Session：未闭合引号判为续行';
    my Str $hl = highlight-line('def"');
    ok $hl.contains(%CLR<green>), 'Session 续行后：下一行开头染成字符串色';
    set-continuation('');
}

done-testing;
