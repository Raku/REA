#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::REPL::Session;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;

# 45-startup.t —— 启动文件 / 可编程 prompt / set -o（0.90.0 / ADR-0025）
#
# 主张：**启动层不是装饰** —— rc 里的每条命令都要能改变会话行为，
# set -o 的每个选项都要有执行点，prompt 出错不能把 REPL 弄停。
#
# 分组：
#   ① run-rc：逐格执行、声明/别名/选项生效、不占 Out[n]；
#   ② rc 的错误不中断后续行，但会如实上报；
#   ③ set -o：列表、开关、执行点（noglob / noexpand / xtrace / histexpand）；
#   ④ prompt：返回值、吞掉噪声、异常回退；
#   ⑤ 引擎：rc 经协议执行，崩溃重启后重新执行。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';
%*ENV<RAKUISH_NO_RC> = '1';
my IO::Path $tmp = $*CWD.add('tmp');
$tmp.mkdir unless $tmp.d;
my IO::Path $cfg = $tmp.add("rc-config-{$*PID}.json");
$cfg.unlink if $cfg.e;
%*ENV<RAKUISH_CONFIG> = $cfg.Str;

my IO::Path $dir = $tmp.add("rc-dir-{$*PID}");
$dir.mkdir unless $dir.d;
$dir.add('a.txt').spurt("hello\n");

sub cleanup() {
    $cfg.unlink if $cfg.e;
    $dir.add('a.txt').unlink if $dir.add('a.txt').e;
    $dir.rmdir if $dir.d;
}
END { cleanup }

# ── ① run-rc ──────────────────────────────────────────────────────
my IO::Path $rc = $tmp.add("startup-{$*PID}.rakuishrc");
$rc.spurt(q:to/RC/);
my $fromrc = 7;
alias ll=ls -alh
set -o noglob
class RcBox {
    method n { 3 }
}
RC
END { $rc.unlink if $rc.e }

{
    my $s = Rakuish::REPL::Session.new(:color(False));
    my %h = $s.run-rc($rc.slurp);
    is %h<failed>, 0, 'rc 全部成功';
    is %h<lines>, 6, 'rc 按行执行（多行 class 算 3 行）';
    is $s.index, 0, 'rc 不占格号：index 仍为 0';
    is $s.history.elems, 0, 'rc 不进输入历史';
    is $s.perf-hist.elems, 0, 'rc 不进 perf 历史';
    is $s.eval-line('$fromrc').value, 7, 'rc 里的变量可用';
    is $s.eval-line('RcBox.new.n').value, 3, 'rc 里的多行类型声明可用';
    is $s.config<aliases><ll>, 'ls -alh', 'rc 里的 alias 生效';
    ok $s.noglob, 'rc 里的 set -o 生效';
}

# ── ② rc 错误如实上报、不吞后续行 ─────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new(:color(False));
    my %h = $s.run-rc("die 'boom';\nmy \$after = 9;\n");
    is %h<failed>, 1, '失败行计数为 1';
    like %h<err>, /boom/, '错误信息带原文';
    like %h<err>, /':1:'/, '错误带行号';
    is $s.eval-line('$after').value, 9, '后面的行仍然执行';
}

# ── ③ set -o ──────────────────────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new(:color(False));
    my $list = $s.eval-line('set -o');
    ok $list.ok, 'set -o 正常返回';
    for <errexit histexpand noglob noexpand xtrace> -> $name {
        like $list.out, /$name/, "列表含 {$name}";
    }

    ok $s.eval-line('set -o xtrace').ok, 'set -o xtrace 可执行';
    ok $s.xtrace, 'xtrace 打开';

    my IO::Path $trace = $tmp.add("trace-{$*PID}.log");
    $trace.spurt('');
    {
        my $fh = $trace.open(:w);
        temp $*ERR = $fh;
        $s.eval-line('1 + 1');
        $fh.close;
    }
    like $trace.slurp, /'+ 1 + 1'/, 'xtrace 在求值前把源码写到 stderr';
    $trace.unlink if $trace.e;

    # 关掉 xtrace 这一格自己也会被 trace；把 stderr 收进文件，避免污染 TAP。
    {
        my $fh = $tmp.add("off-trace-{$*PID}.log").open(:w);
        temp $*ERR = $fh;
        $s.eval-line('set +o xtrace');
        $fh.close;
    }
    nok $s.xtrace, 'xtrace 关闭';
    ok $s.eval-line('set -e').ok, 'set -e 仍可用';
    ok $s.strict, 'set -e 映射到 errexit';
    like $s.eval-line('set -o').out, /'errexit on'/, '列表反映 errexit';
    $s.eval-line('set +e');

    $s.eval-line('set +o histexpand');
    nok $s.histexpand, 'histexpand 关闭';
    $s.eval-line('echo hi');
    is $s.eval-line('!!').code, 127, '关闭后 !! 不再做历史替换';

    my $bad = $s.eval-line('set -o nonsense');
    ok !$bad.ok, '未知选项报错';
    like $bad.err, /未知选项/, '错误里说明未知选项';

    # noglob：cat * 从「读 a.txt」变成「找不到名为 * 的文件」
    my Str $dpath = $dir.Str.subst(:g, '\\', '/');
    $s.eval-line("cd {$dpath}");
    my $before = $s.eval-line('cat *');
    ok $before.ok, '默认会展开 *';
    like $before.out, /hello/, '展开后读到 a.txt';
    $s.eval-line('set -o noglob');
    my $after = $s.eval-line('cat *');
    ok !$after.ok, 'noglob 后 * 保持字面';
    like $after.err, /'*'/, '错误里就是字面 *';

    # noexpand：echo $HOME
    $s.eval-line('set +o noglob');
    is $s.eval-line('echo $HOME').out, $*HOME.Str, '默认展开 $HOME';
    $s.eval-line('set -o noexpand');
    is $s.eval-line('echo $HOME').out, '$HOME', 'noexpand 后保留字面 $HOME';
    $s.eval-line('set +o noexpand');
}

# ── ④ prompt ─────────────────────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new(:color(False));
    is $s.render-prompt, '', '未定义时返回空串（前端用默认样式）';
    $s.prompt = -> { 'P> ' };
    is $s.render-prompt, 'P> ', '返回用户给的字符串';
    $s.prompt = -> { "line1\nline2" };
    is $s.render-prompt, 'line1 line2', 'prompt 被压成单行';
    $s.prompt = -> { say 'noise'; 'clean> ' };
    is $s.render-prompt, 'clean> ', '函数里的 say 被吞掉';
    $s.prompt = -> { die 'prompt boom' };
    is $s.render-prompt, '', '异常时回退为空串，不抛给前端';
}

# ── ⑤ 引擎：rc / prompt / 重启后重新执行 ──────────────────────────
{
    my IO::Path $erc = $tmp.add("engine-{$*PID}.rakuishrc");
    $erc.spurt(q:to/RC/);
my $enginevar = 11;
repl.prompt = -> { "ENG> " }
alias ee=echo hi
RC

    my $c = Rakuish::Eval::Client.new(:lib('lib'.IO));
    $c.start;
    my $p = Rakuish::Eval::Proxy.new(:client($c), :rc-path($erc.Str));
    my %h = $p.run-rc($erc.Str);
    is %h<failed>, 0, '引擎执行 rc 成功';
    is $p.prompt-text, 'ENG> ', 'prompt 经协议取回';
    is $p.eval-line('$enginevar').rendered, 'Out[1] = 11', 'rc 变量在引擎里可用';
    is $p.eval-line('ee').out.chomp, 'hi', 'rc 里的 alias 没有被父侧 config 冲掉';

    # 崩溃 → 重启：Proxy 应重新执行 rc（prompt / 选项都在 rc 里）。
    $c.proc.kill(SIGKILL);
    sleep 1;
    my $r = $p.eval-line('1');
    is $r.op, 'engine-restart', '崩溃仍归因 engine-restart';
    is $p.prompt-text, 'ENG> ', '重启后 rc 重新执行，prompt 还在';
    is $p.eval-line('$enginevar').rendered, 'Out[1] = 11', '重启后 rc 变量还在';

    $c.shutdown;
    $erc.unlink if $erc.e;
}

done-testing;
