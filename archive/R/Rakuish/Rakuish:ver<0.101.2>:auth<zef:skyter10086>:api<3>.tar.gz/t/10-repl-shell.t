use Test;
use Rakuish::Sys;
use Rakuish::REPL::Session;

# t/10 —— REPL 的日常 shell 观感层
# 目标：cd/ls/cat/rm/cp/... 的常用写法符合用户习惯，但底层仍是 Sys。

my $base = $*TMPDIR.IO.add("rakuish-shell-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }

my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
my $s = Rakuish::REPL::Session.new(:sys($sys));

sub out(Str $line --> Str) { $s.render($s.eval-line($line)) }

$base.add('a.txt').spurt("one\ntwo\nthree\n");
$base.add('b.md').spurt('md');
$base.add('big.txt').spurt('x' x 2048);
$base.add('.hidden').spurt('h');
$base.add('sub').mkdir;
$base.add('sub/c.txt').spurt('c');
$base.add('data.json').spurt('[{"name":"x","size":1}]');
$base.add('ADR-0001.md').spurt('adr text');

# ── cd / pwd / ls ────────────────────────────────────────────────────
is out('pwd').subst('\\', '/', :g),
    $base.Str.subst('\\', '/', :g), 'pwd 输出当前目录';
is out('cd sub'), '', 'cd 成功且安静（shell 习惯）';
is $s.sys.cwd.Str.subst('\\', '/', :g),
    $base.add('sub').Str.subst('\\', '/', :g), 'cd 真的切到 sub';
is out('pwd').subst('\\', '/', :g),
    $base.add('sub').Str.subst('\\', '/', :g), 'cd 后 pwd 正确';
is out('cd -'), '', 'cd - 成功且安静';
is $s.sys.cwd.Str.subst('\\', '/', :g),
    $base.Str.subst('\\', '/', :g), 'cd - 回到上一个目录';

my Str $ls = out('ls');
like $ls, /'a.txt'/, 'ls 列出文件';
nok $ls.contains('IO::Path'), 'ls 不显示 IO::Path';
nok $ls.contains('Out['), 'ls 不套 Out[n]';
like out('ls -a'), /'.hidden'/, 'ls -a 列出隐藏项';
ok out('ls -F').contains('sub/'), 'ls -F 给目录加 /';
like out('ls -l'), /'a.txt'/, 'ls -l 显示长格式';
like out('ls -alh'), /'2.0K'/, 'ls -alh 支持人类可读大小';
ok out('ls -d sub').contains('sub'), 'ls -d 只列目录本身';
like out('ls *.md'), /'b.md'/, 'ls 展开 glob';
like out('ls **/*.txt'), /'c.txt'/, 'ls 支持 globstar **/';
like out('ls a.txt b.md'), /'a.txt'/, 'ls 支持多个路径（1）';
like out('ls a.txt b.md'), /'b.md'/, 'ls 支持多个路径（2）';
is out('clear'), '', 'clear 在非 TTY 下不输出控制码';

# 0.87.0：TTY 由入口注入，不再让 Shell 看 `$*OUT.t`。引擎子进程的 stdout
# 是协议管道，那份探测恒 False —— `clear` 曾在 REPL 里静默失效（用户报的 bug）。
{
    my $t = Rakuish::REPL::Session.new;
    nok $t.tty, '新会话在管道下 tty=False';
    is $t.eval-line('clear').out, '', 'tty=False 时 clear 无输出';
    $t.set-tty(True);
    ok $t.tty, 'set-tty 生效';
    is $t.shell.tty, True, 'set-tty 同步给 Shell（否则 clear 与 ls 判定不一致）';
    is $t.eval-line('clear').out, "\e[2J\e[H", 'tty=True 时 clear 发 ANSI 清屏';
    $t.set-tty(False);
    is $t.eval-line('clear').out, '', '再关掉又回到无输出（不是单向开关）';
}

# ── 结构化 open / ls --json ───────────────────────────────────────────
like out('open data.json'), /'name'/ && /'x'/, 'open json 渲染为表格';
like out('open --raw data.json'), /'"name"'/, 'open --raw 保留原始文本';
like out('ls --json data.json'), /'"type": "file"'/, 'ls --json 输出结构化字段';
like out('help open'), /^ '用法: open'/, 'open --help/help 有用法';

# ── 内置命令帮助 ────────────────────────────────────────────────────
like out('ls --help'), /^ '用法: ls'/, 'ls --help 显示用法';
like out('ls --help'), /'-h'/, 'ls --help 列出 -h';
like out('rm --help'), /^ '用法: rm'/, 'rm --help 显示用法';
like out('help cp'), /^ '用法: cp'/, 'help cp 显示用法';
like out('help'), /'Shell 日常命令'/, 'help 列出全部命令组';
like out('help read'), /^ '用法: read'/, 'help read 覆盖 Raku API';
like out('help --find 读取'), /'read'/, 'help --find 搜索用法';
like out('which ls'), /'shell: ls'/, 'which 查 Shell 内置';
like out('which definitely-missing'), /'未找到'/, 'which 未找到报错';
like out('read --help'), /^ '用法: read'/, 'read --help 也可用';
like out('env --help'), /^ '用法: env'/, 'env --help 也可用';
nok out('ls --help').contains('IO::Path'), '帮助不显示对象结构';

# ── cat / head / tail / echo ─────────────────────────────────────────
is out('cat a.txt'), "one\ntwo\nthree", 'cat 原样输出（显示层去掉末尾换行）';
is out('read ADR-0001.md'), 'adr text', 'read 按 shell 路径读取（带连字符）';
is out('head -n 2 a.txt'), "one\ntwo", 'head -n 输出前两行';
is out('tail -n 1 a.txt'), 'three', 'tail -n 输出最后一行';

# 0.97.0：大文件（>1MB 上限）head/tail 仍可读，read 报错但给出路。
my Str $huge = (1 .. 120_000).map({ "line{$_}" }).join("\n");   # > 1MB
$base.add('huge.txt').spurt($huge);
is out('head -n 2 huge.txt'), 'line1' ~ "\n" ~ 'line2',
    'head -n 2：超过 1MB 的大文件仍能读前两行';
is out('tail -n 2 huge.txt'), 'line119999' ~ "\n" ~ 'line120000',
    'tail -n 2：超过 1MB 的大文件仍能读末两行';
my $big-read = $s.eval-line('read huge.txt');
nok $big-read.ok, 'read：整份读超大文件仍失败（保护不删）';
like $big-read.err, /'read-lines'/, 'read：超限错误给出 read-lines 出路';

# 0.99.0：tail -f 的解析与路由（跟随循环本身在 t/55，这里只验命令层）。
# mock job-dispatch：记录路由参数，返回一个假的跟随结果。
{
    my @route;
    my $sys2 = Rakuish::Sys.new(:root($base), :cwd($base));
    my $s2 = Rakuish::REPL::Session.new(:sys($sys2));
    $sys2.job-dispatch = -> Str $op, *@a {
        @route.push([$op, |@a.map(*.Str)]);
        Rakuish::Result::Result.new(:ok, :code(130), :op('tail'),
            :out('已停止跟随（Ctrl-C）· 输出 0 行'));
    };
    my Str $r1 = $s2.render($s2.eval-line('tail -f a.txt'));
    is-deeply @route[0].List, ('tail-follow', 'a.txt', '10').List,
        'tail -f 路由为 tail-follow（默认 10 行）';
    like $r1, /'已停止跟随'/, '跟随结果的摘要正常渲染';

    @route = ();
    $s2.render($s2.eval-line('tail -5f a.txt'));
    is-deeply @route[0].List, ('tail-follow', 'a.txt', '5').List,
        'tail -5f 解析紧凑计数 + 跟随';

    @route = ();
    $s2.render($s2.eval-line('tail --follow -n 3 a.txt'));
    is-deeply @route[0].List, ('tail-follow', 'a.txt', '3').List,
        'tail --follow -n 3 解析长短两种选项';

    @route = ();
    my $rh = $s2.eval-line('head -f a.txt');
    nok $rh.ok, 'head -f 明确失败';
    like $rh.err, /'head 不支持'/, 'head -f 指路 tail -f';
    is @route.elems, 0, 'head -f 不发起跟随';

    like out('help tail'), /'-f'/, 'help tail 列出 -f';
}
is out('echo hello world'), 'hello world', 'echo 输出参数';
is out('echo -n hi'), 'hi', 'echo -n 不追加换行';
is out('echo "a;b"'), 'a;b', '引号内标点作为字面参数';
is out('echo "file(1).txt"'), 'file(1).txt', '引号内括号作为字面参数';

# ── mkdir / touch / cp / mv / rm ────────────────────────────────────
is out('mkdir -p d/e'), '', 'mkdir 成功且安静';
ok $base.add('d/e').d, 'mkdir 真的建好了';
is out('touch t.txt'), '', 'touch 成功且安静';
ok $base.add('t.txt').e, 'touch 创建空文件';
is out('cp a.txt c.txt'), '', 'cp 成功且安静';
is $base.add('c.txt').slurp, "one\ntwo\nthree\n", 'cp 内容正确';
is out('cp -r d d2'), '', 'cp -r 成功且安静';
ok $base.add('d2/e').d, 'cp -r 复制了子目录';
is out('mv c.txt m.txt'), '', 'mv 成功且安静';
ok $base.add('m.txt').e, 'mv 目标存在';
nok $base.add('c.txt').e, 'mv 源消失';
is out('rm -rf d2'), '', 'rm -rf 成功且安静';
nok $base.add('d2').e, 'rm -rf 真的删了';
is out('rm -f missing.txt'), '', 'rm -f 不存在也成功且安静';

# ── export / unset / glob ───────────────────────────────────────────
is out('export RAKUISH_SHELL_X=yes'), '', 'export 成功且安静';
is $sys.get-env('RAKUISH_SHELL_X'), 'yes', 'export 真的写进会话环境';
is out('echo $RAKUISH_SHELL_X'), 'yes', '参数里的 $NAME 按会话 env 展开';
is out('unset RAKUISH_SHELL_X'), '', 'unset 成功且安静';
nok $sys.get-env('RAKUISH_SHELL_X').defined, 'unset 真的删了';
like out('glob *.md'), /'b.md'/, 'glob 输出 basename';
is out('grep two a.txt'), 'two', 'grep 逐行匹配';
is out('grep -n three a.txt'), '3:three', 'grep -n 带行号';
is out('grep "^one" a.txt'), 'one', 'grep 支持正则锚点';
is out('grep -F "^one" a.txt'), '', 'grep -F 按字面匹配';
is out('grep -i ONE a.txt'), 'one', 'grep -i 忽略大小写';
is out('wc -l a.txt'), '3 a.txt', 'wc -l 统计行数并带文件名';
like out('history'), /'pwd'/, 'history 显示本会话命令';

# ── Tab 补全 provider ────────────────────────────────────────────────
ok $s.completions('c', 1).List.grep(* eq 'cat ').elems == 1, '命令名补全 cat';
ok $s.completions('ls ', 3).List.grep(* eq 'ls a.txt').elems == 1,
    '路径补全 a.txt';
nok $s.completions('ls ', 3).List.grep(* eq 'ls .hidden').elems,
    '默认不补全隐藏项';
ok $s.completions('help ', 5).List.grep(* eq 'help ls ').elems == 1,
    'help 补全命令名';

# ── jobs shell 视图 ─────────────────────────────────────────────────
my $jh = $s.sys.spawn($*EXECUTABLE.Str, '-e', 'sleep 1');
like out('jobs'), /'running'/, 'jobs 列出后台进程';
ok $s.sys.cancel($jh), '取消后台进程';
like out('jobs'), /'没有后台任务'/, '取消后 jobs 为空';

# ── Raku 变量参数不被 shell 层误吞 ──────────────────────────────────
$base.add('var-file.txt').spurt('v');
$s.eval-line('my $vp = "var-file.txt";');
is out('cat $vp'), 'v', '带 $var 的 cat 交回 Raku 变量';
$s.eval-line('my $ev = "hello-var";');
is out('echo $ev'), 'hello-var', '带 $var 的 echo 交回 Raku 变量';

# ── live-out：分页要看「stdout 是不是那个终端」（0.89.0 / V-228）──
# tty 说「用户面前有终端」，live-out 说「我写 stdout 就写到它」。
# 混用会让引擎里的分页器把表格写进协议流并吞掉下一个请求。
{
    my $x = Rakuish::REPL::Session.new;
    nok $x.live-out, '管道下 live-out=False';
    $x.set-tty(True);
    ok $x.tty, 'tty 被注入为 True（用户面前确实有终端）';
    nok $x.live-out, 'live-out 仍是 False（本进程 stdout 是管道）';

    $x.eval-line('my $tt = Rakuish::Data::Table.from-rows((1..40).map({ %(n => $_) }))');
    $x.eval-line('$tt');
    my $r = $x.eval-line('explore');
    ok $r.ok, 'explore 成功（不尝试分页）';
    ok $r.out.contains('40'), '整份文本返回，末行也在（40）';
    nok $r.out.contains('-- more'), '没有分页提示';
}

# ── 终端尺寸注入（0.88.0 / V-227）────────────────────────────────
# `COLUMNS` 不是终端属性：bash 只在交互 shell 里赋值、默认不导出，
# `resize` 之后还会变陈旧。40 列终端里按 80 列排，输出会乱序换行。
{
    my $d = $*TMPDIR.add("width-{$*PID}");
    $d.mkdir unless $d.e;
    $d.add("file-{$_}.txt").spurt('x') for 1..24;

    my $t = Rakuish::REPL::Session.new;
    is $t.width, 0, '默认宽度未知（0）';
    is $t.pager-page-size, 20, '高度未知时每页 20 行（Pager 默认）';
    $t.set-size(:height(30));
    is $t.pager-page-size, 28, '每页行数由高度推出（留 2 行）';
    $t.set-size(:height(2));
    is $t.pager-page-size, 20, '高度过小不产生 0 行页';
    $t.set-size(:width(40), :height(20));
    is $t.width, 40, 'set-size 生效';
    is $t.height, 20, '高度同样生效';
    is $t.shell.width, 40, '尺寸同步给 Shell（与 tty 同理）';
    $t.set-size(:width(0), :height(0));
    is $t.width, 40, '0 表示「未知」，不覆盖已知尺寸';

    $t.set-tty(True);                       # 多列只在 TTY 下成立
    is $t.eval-line("cd " ~ $d.Str.subst('\\', '/', :g)).ok, True, '切到夹具目录';

    my &rendered = -> Int $w {
        $t.set-size(:width($w));
        my $r = $t.eval-line("dir('.').list");
        $t.render($r).lines.grep({ .chars && !.contains('Out[') });
    };

    my @narrow = rendered(40);
    my @wide   = rendered(120);
    ok @narrow.elems > @wide.elems,
       "窄终端行数更多（40 列 {@narrow.elems} 行 vs 120 列 {@wide.elems} 行）";
    ok @narrow.map(*.chars).max <= 40,
       "40 列下没有超宽行（最宽 {@narrow.map(*.chars).max}）";

}

done-testing;
