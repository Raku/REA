#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Data::Stream;
use Rakuish::REPL::Session;

# 48-exec-stdin.t —— `Stream.exec` 的 stdin 是**流式**的（0.93.0 / ADR-0028）
#
# 主张四条：
#   ① 边算边写：子进程只要一行，生成器就不许把整条流跑完；
#   ② 字节不变：csv / tsv / json / lines 喂过去的内容与 `.csv` / `.json` / `.lines`
#      一致（含引号转义），包括最后一小块没有攒满 16KB 的尾巴；
#   ③ 收尾诚实：子进程提前关 stdin 是正常收尾（in-early），生成器自己抛是
#      另一回事（feed-error），一次性来源的二次消费**当场**报错而不是静默给空；
#   ④ 仍然走会话 Sys：cwd / env / 退出码与 `!` 同一条路。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';
%*ENV<RAKUISH_NO_RC> = '1';

my Str $raku = $*EXECUTABLE.Str;
my $sess = Rakuish::REPL::Session.new(:color(False));
my $*RAKUISH-SYS = $sess.sys;

# ── ① 惰性：20 万行的生成器，子进程只要第一行 ────────────────────────
{
    my Int $pulled = 0;
    my $huge = Rakuish::Data::Stream.new(
        :make(-> { (1 .. 200_000).map(-> $i { $pulled++; %( n => $i, line => "row$i" ) }) }),
        :source('counter'),
    );
    my $r = $huge.exec($raku, '-e', 'say $*IN.lines.head');
    ok $r.ok, '惰性：子进程正常退出';
    is $r.out.trim, 'row1', '惰性：子进程只拿到第一行';
    ok $pulled < 50_000, "惰性：只拉了 {$pulled}/200000 行（不是整条流）";
    ok ?($r.value<in-early>), '收尾：子进程提前关 stdin 时如实标记 in-early';
    nok ($r.value<feed-error> // '').chars, '收尾：提前关闭不是错误';
}

# ── ② 字节一致（含引号转义与「尾巴不足 16KB」）──────────────────────
{
    my $rows = Rakuish::Data::Stream.new(
        :make(-> {
            %( k => 'a,b' ), %( k => 'q"z' ), %( k => 'plain' ),
        }),
        :columns(('k',)),
    );
    my $expect = Rakuish::Data::Stream.new(
        :make(-> { %( k => 'a,b' ), %( k => 'q"z' ), %( k => 'plain' ) }),
        :columns(('k',)),
    ).csv;
    my $got = Rakuish::Data::Stream.new(
        :make(-> { %( k => 'a,b' ), %( k => 'q"z' ), %( k => 'plain' ) }),
        :columns(('k',)),
    ).exec($raku, '-e', 'print $*IN.slurp', :format<csv>);
    is $got.out, $expect, 'csv：与 .csv 逐字节相同（逗号 / 引号都走同一份转义）';
    like $got.out, /'"a,b"'/, 'csv：含逗号的字段被引号包住';
    like $got.out, /'"q""z"'/, 'csv：字段内的引号被双写';

    my $tsv = Rakuish::Data::Stream.from("a\tb\n1\t2", :format<tsv>).exec(
        $raku, '-e', 'print $*IN.slurp', :format<tsv>);
    is $tsv.out, "a\tb\n1\t2\n", 'tsv：表头 + 数据，制表符分隔';
}

# 尾巴：1024 行 × 16 字节 = 正好 16384（一整批），再来一行看边界外的那块。
{
    my $mk = -> $n {
        Rakuish::Data::Stream.new(
            :make(-> { (1 .. $n).map(-> $i { %( line => ('x' x 15) ) }) }),
            :columns(('line',)),
        )
    };
    my $exact = $mk(1024).exec($raku, '-e', 'say $*IN.slurp.chars');
    is $exact.out.trim, '16384', '尾块：正好一整批也不丢字节';

    my $over = $mk(1025).exec($raku, '-e', 'say $*IN.slurp.chars');
    is $over.out.trim, '16400', '尾块：越过批次边界的那一小块必须写出去';

    my $count = $mk(5000).exec($raku, '-e', 'say $*IN.lines.elems');
    is $count.out.trim, '5000', '尾块：5000 行一条不少（旧实现会丢最后一块）';
}

# ── ③ 收尾诚实 ───────────────────────────────────────────────────────
{
    # 生成器自己抛：不能变成「子进程收到空输入、看起来成功」。
    my $boom = Rakuish::Data::Stream.new(
        :make(-> { (1 .. 3).map(-> $i { $i == 2 ?? die('生成器炸了') !! %( n => $i ) }) }),
        :source('boom'),
    );
    my $r = $boom.exec($raku, '-e', 'say $*IN.lines.elems');
    like ($r.value<feed-error> // ''), /'生成器炸了'/, '生成器异常写进 feed-error（不被吞掉）';

    # 一次性来源：第二次必须当场抛，不许给空流。
    my $once = Rakuish::Data::Stream.new(
        :make(-> { %( n => 1 ) }), :repeatable(False), :source('cursor'),
    );
    ok $once.exec($raku, '-e', 'say $*IN.lines.elems').ok, '一次性来源：第一次可用';
    throws-like { $once.exec($raku, '-e', '1') }, X::Rakuish::Data,
        message => /'已经读过一次'/,
        '一次性来源：第二次当场报错（不是静默空输入）';

    # 未知格式：当场报错，不回落 lines。
    throws-like {
        Rakuish::Data::Stream.from("a\nb").exec($raku, '-e', '1', :format<yaml>)
    }, X::Rakuish::Unsupported, message => /'只支持'/, '未知 :format 明确拒绝';
}

# ── ④ 仍然走会话 Sys ────────────────────────────────────────────────
{
    my $code = Rakuish::Data::Stream.from("a").exec($raku, '-e', 'exit 3');
    nok $code.ok, '退出码：非零是失败 Result';
    is $code.code, 3, '退出码：原样透出';

    my $err = Rakuish::Data::Stream.from("a").exec(
        $raku, '-e', '$*ERR.say("boom"); exit 1');
    is $err.out.trim, '', 'stderr：不进 out';
    like $err.err, /'boom'/, 'stderr：进 err';

    my $env-r = Rakuish::Data::Stream.from("a").exec(
        $raku, '-e', 'say %*ENV<RAKUISH_T48> // "unset"');
    is $env-r.out.trim, 'unset', 'env：默认不凭空多出变量';

    # 注意 `sys.env` 返回的是**副本**（`%!env.Hash`），改它不生效；
    # 会话变量只能走 set-env —— 这条本身也值得钉住。
    $sess.sys.set-env('RAKUISH_T48', 'v48');
    my $env-r2 = Rakuish::Data::Stream.from("a").exec(
        $raku, '-e', 'say %*ENV<RAKUISH_T48> // "unset"');
    is $env-r2.out.trim, 'v48', 'env：走会话 Sys（会话变量会传给子进程）';

    my $conflict = $*RAKUISH-SYS.exec($raku, '-e', '1',
        :in('x'), :in-chunks(-> { 'y' }));
    is $conflict.code, 127, ':in 与 :in-chunks 同时给 → 启动失败 127';
    like $conflict.err, /'只能给一个'/, ':in 与 :in-chunks 互斥有明确说明';
}

done-testing;
