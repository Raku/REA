#!/usr/bin/env raku
use lib 'lib';
use Test;

# 59-feel-pty.t —— 交互手感的真 PTY 冒烟（0.100.0 / ADR-0034）
#
# 主张四条（真 PTY，引擎子进程模式）：
#   ① 灰字建议：输入历史前缀时渲染出现灰色建议后缀（连续 ANSI 串判定，
#      不用 clean() 偏移切 raw——clean 比 raw 短，切片会错位）；→ 整句
#      接受后 Enter 求值得到 Out[n] = 99；
#   ② ShiftTab 候选菜单在输入行下方列出候选；
#   ③ 错误态高亮：未知命令的词出现在 \e[31m… 连续段里；
#   ④ Ctrl-R 循环历史检索能把历史条目拉回输入行。
#
# Windows 无 pty 模块，整段 skip（渲染 / 动作契约由 t/58 覆盖）。

my Bool $pty-ok = !$*DISTRO.is-win;
my Str $py = '';
if $pty-ok {
    my $probe = try {
        my $p = run('python3', '-c', 'import pty, os; print("ok")', :out, :err);
        $p.out.slurp(:close).trim
    };
    $py = ($probe // '');
}

if $pty-ok && $py eq 'ok' {
    my IO::Path $tmp = $*CWD.add('tmp');
    $tmp.mkdir unless $tmp.e;
    my Str $tag = $*PID.Str;
    my $driver = $tmp.add("feel-driver-{$tag}.py");

    $driver.spurt(Q:to/PYTHON/);
        import fcntl, os, pty, re, select, struct, sys, termios, time

        root, raku = sys.argv[1], sys.argv[2]
        home = '/tmp/rakuish-feel-%d' % os.getpid()
        os.makedirs(home, exist_ok=True)
        env = os.environ.copy()
        env.update(
            RAKUISH_CONFIG=home + '/config.json',
            TERM='xterm-256color',
            LANG='C.UTF-8',
            PATH=os.path.dirname(raku) + ':' + env.get('PATH', ''),
        )

        os.chdir(root)
        pid, master = pty.fork()
        if pid == 0:
            os.execve(raku, [raku, '-Ilib', 'bin/rakuish'], env)
        fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack('HHHH', 24, 110, 0, 0))

        exit_state = {'code': None}

        def poll():
            if exit_state['code'] is not None:
                return exit_state['code']
            try:
                wpid, status = os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                exit_state['code'] = 'reaped'
                return exit_state['code']
            if wpid == 0:
                return None
            try:
                exit_state['code'] = os.waitstatus_to_exitcode(status)
            except ValueError:
                exit_state['code'] = -1
            return exit_state['code']

        raw = bytearray()
        esc = b''
        size_pending = False
        deadline = time.time() + 120

        def feed(data):
            global esc, size_pending
            for byte in data:
                esc += bytes((byte,))
                if len(esc) > 24:
                    esc = esc[-24:]
                if esc.endswith(b'\x1b[9999;9999H'):
                    size_pending = True
                elif esc.endswith(b'\x1b[6n'):
                    os.write(master, b'\x1b[24;110R' if size_pending else b'\x1b[1;1R')
                    size_pending = False
                    esc = b''

        def pump(seconds):
            end = time.time() + seconds
            while time.time() < end and time.time() < deadline:
                readable, _, _ = select.select([master], [], [], 0.08)
                if not readable:
                    continue
                try:
                    data = os.read(master, 65536)
                except OSError:
                    break
                if not data:
                    break
                raw.extend(data)
                feed(data)
                end = max(end, time.time() + 0.2)

        def send(text, wait=0.8):
            os.write(master, text.encode() if isinstance(text, str) else text)
            pump(wait)

        def has(marker):
            return (marker.encode() if isinstance(marker, str) else marker) in raw

        def seg_from(mark):
            return bytes(raw)[mark:]

        def clean_of(mark):
            return re.sub(rb'\x1b\[[0-9;?]*[A-Za-z]', b'', bytes(raw)[mark:])

        def wait_for(marker, timeout=25):
            end = time.time() + timeout
            while time.time() < end:
                if has(marker):
                    return True
                pump(0.2)
            return False

        probe = {}
        ready = wait_for('❯', 40)
        probe['ready'] = 1 if ready else 0
        if ready:
            # 前置：进历史（say 可重复求值，无 my 重声明问题）。
            # 等回显出现后再静置 2.5s，让首格的输出行全部落进 raw，
            # 免得它的 feel-ok-77\r\n 漏进后面的 accept 探针窗口。
            send('say "feel-ok-77"\r', 1.0)
            wait_for('feel-ok-77', 20)
            pump(2.5)

            # ① 灰字建议：连续 ANSI 串判定（echo/渲染不会把后缀包进灰色段）。
            #    → 接受后 Enter 求值：输出行 feel-ok-77\r\n（输入行渲染里
            #    77 后面紧跟的是引号，不会误配）。
            cmark = len(raw)
            send('say "feel', 1.2)
            seg = seg_from(cmark)
            probe['suggest'] = 1 if b'\x1b[90m-ok-77"\x1b[0m' in seg else 0
            send('\x1b[C', 1.0)          # → 整句接受
            send('\r', 1.5)              # 求值
            probe['accept'] = 1 if b'feel-ok-77\r\n' in seg_from(cmark) else 0

            # ② ShiftTab 候选菜单（op → open / open-data / open-db）
            cmark = len(raw)
            send('op', 0.8)
            send('\x1b[Z', 1.5)          # ShiftTab
            probe['menu'] = 1 if b'open-data' in clean_of(cmark) else 0
            send('\x15', 0.5)            # Ctrl-U 清行

            # ③ 错误态高亮：未知命令标红（连续段 \x1b[31mlss）
            cmark = len(raw)
            send('lss', 1.0)
            probe['error-red'] = 1 if b'\x1b[31mlss' in seg_from(cmark) else 0
            send('\x15', 0.5)

            # ④ Ctrl-R 循环历史检索（空行首按 → 最近历史 say "feel-ok-77"）
            cmark = len(raw)
            send('\x12', 1.2)            # Ctrl-R
            probe['search'] = 1 if b'say "feel-ok-77"' in clean_of(cmark) else 0
            send('\x15', 0.5)

            send('exit\n', 1.5)
        pump(1.0)
        for _ in range(60):
            if poll() is not None:
                break
            pump(0.1)
        probe['clean_exit'] = 1 if poll() == 0 else 0
        os.close(master)
        for k, v in probe.items():
            print('PROBE %s=%s' % (k, v))
        PYTHON

    my $ran = try {
        my $p = run('python3', $driver.Str, $*CWD.Str, $*EXECUTABLE.Str,
                    :out, :err);
        ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
    };
    my Str $text = $ran // '';
    my %p;
    for $text.lines -> $line {
        next unless $line.starts-with('PROBE ');
        my @kv = $line.substr(6).split('=', 2);
        %p{@kv[0]} = (@kv[1] // '');
    }

    is %p<ready>, '1', '真 PTY：REPL 出现第一个 prompt';
    is %p<suggest>, '1', '灰字建议后缀（连续灰色 ANSI 段）出现';
    is %p<accept>, '1', '→ 整句接受后求值（输出行 feel-ok-77）';
    is %p<menu>, '1', 'ShiftTab 列出候选菜单';
    is %p<error-red>, '1', '未知命令标红（连续 \x1b[31m 段）';
    is %p<search>, '1', 'Ctrl-R 把历史条目拉回输入行';
    is %p<clean_exit>, '1', '干净退出 rc=0';
}
else {
    skip 'Windows 无 pty 模块（渲染 / 动作契约由 t/58 覆盖）', 7;
}

done-testing;
