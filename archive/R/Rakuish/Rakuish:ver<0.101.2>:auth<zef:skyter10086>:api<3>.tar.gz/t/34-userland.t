use Test;
use Rakuish::Sys;
use Rakuish::Result;
use Rakuish::REPL::Session;
use Rakuish::REPL::Shell;
use Rakuish::REPL::Introspect;

# 0.75.0 / ADR-0012：P0 一致性订正 + 四项低风险能力
# （命令选项补全 / doc 内省 / 会话日志 / 目录栈与书签）。
# 反向断言同样是重点：内省零 EVAL、日志纯文本、按键表只列真正绑定的键。

my $dir = $*TMPDIR.IO.add("rakuish-userland-{$*PID}");
$dir.mkdir;
my $log = $dir.add('session.log');
for <sub-a sub-b> -> $n { $dir.add($n).mkdir }
$dir.add('a.txt').spurt("hello\n");
LEAVE {
    try { $log.unlink };
    try { $dir.add('a.txt').unlink };
    try { $dir.add('sub-a').rmdir };
    try { $dir.add('sub-b').rmdir };
    try { $dir.rmdir };
}

my $sys = Rakuish::Sys.new(:root($dir), :cwd($dir));
my $sh  = Rakuish::REPL::Shell.new(:sys($sys));
my $s   = Rakuish::REPL::Session.new(:sys($sys));

# ── P0 A1：Ctrl-X Ctrl-E 不再被宣称，也不再返回值 API ──────────────
is $s.key-bindings.elems, 9, '按键表 9 项（0.100 加建议/菜单/检索键）';
nok $s.key-bindings{'Ctrl-X Ctrl-E'}:exists, '按键表无 Ctrl-X Ctrl-E';
nok $s.handle-key('Ctrl-X Ctrl-E').ok, '未绑定按键返回失败 Result';
nok 'bin/rakuish'.IO.slurp.contains('Ctrl-X Ctrl-E'), '入口 help 不再宣称外部编辑器';

# ── P0 A2：theme 这个 inert 键不再出现在文档示例里 ──────────────────
nok 'README.md'.IO.slurp.contains('config set theme'), 'README 无 theme 示例';
nok 'docs/MANUAL.md'.IO.slurp.contains('config set theme'), 'MANUAL 无 theme 示例';
ok 'docs/MANUAL.md'.IO.slurp.contains('只有入口真正读取的键才生效'),
    'MANUAL 明确写出 config 的生效边界';

# ── P1-1：命令选项 Tab 补全 ─────────────────────────────────────────
my @j = $sh.completions('ls --j', 6).List;
ok @j.grep(* eq 'ls --json ').elems == 1, 'ls --j 补出 --json';
nok @j.grep(* eq 'ls --help ').elems, '--j 不该补出 --help';
ok $sh.completions('ls --', 5).grep(* eq 'ls --help ').elems == 1,
    'ls -- 补出通用 --help';
ok $sh.completions('rm -', 4).grep(* eq 'rm -r ').elems == 1, 'rm - 补出 -r';
ok $sh.completions('grep -i', 7).grep(* eq 'grep -i ').elems == 1,
    'grep -i 精确命中自身';
ok $sh.completions('cat ', 4).grep(* eq 'cat a.txt').elems == 1,
    '普通词仍走路径补全（无回归）';
is $sh.completions('nosuch -', 8).elems, 0, '未知命令不补选项';
is $sh.completions('ls -', 4).grep({ .starts-with('ls -') }).elems > 3,
    True, '短横线给出多个候选';

# ── P1-2：doc 内省（纯函数 + 命令层）──────────────────────────────
ok introspect-name-ok('Rakuish::Sys'), '合法限定名';
ok introspect-name-ok('&say'), '合法例程名';
nok introspect-name-ok('a;rm -rf'), '拒绝分号与空白';
nok introspect-name-ok('1+1'), '拒绝表达式';
my %i = introspect('Str');
ok %i<ok>, 'Str 可内省';
ok %i<text>.contains('类型: Str'), '内省文本含类型';
ok introspect('&say')<text>.contains('签名:'), '例程内省含签名';
nok introspect('NoSuchNameXyz_abc')<ok>, '不存在的名字失败';
ok introspect('a;rm -rf')<reason>.contains('非法名字'), '非法名字给出原因';
ok $s.eval-line('doc ls').out.contains('用法: ls'), 'doc <命令> 走 usage()';
ok $s.eval-line('doc Str').out.contains('名称: Str'), 'doc <类型> 走元对象内省';
ok $s.eval-line('doc &say').out.contains('签名:'), 'doc &例程 不被元字符闸门拦下';
nok $s.eval-line('doc NoSuchNameXyz_abc').ok, 'doc 未知名字返回失败';
nok $s.eval-line('doc 1+1').ok, 'doc 表达式返回失败';
ok $s.eval-line('doc --help').out.contains('用法: doc'), 'doc --help 给用法';

# ── P1-5：目录栈与书签 ─────────────────────────────────────────────
ok $s.eval-line('pushd sub-a').ok, 'pushd 成功';
ok $s.sys.cwd.Str.contains('sub-a'), 'pushd 切到目标目录';
ok $s.eval-line('dirs').out.contains('(当前)'), 'dirs 标出当前目录';
ok $s.eval-line('dirs').out.contains('sub-a'), 'dirs 列出当前目录';
ok $s.eval-line('popd').ok, 'popd 成功';
ok $s.sys.cwd.Str.ends-with($dir.basename), 'popd 回到原目录';
nok $s.eval-line('popd').ok, '空栈 popd 报错';
ok $s.eval-line('cd sub-b').ok, 'cd 仍可用';
ok $s.eval-line('cd -').ok, 'cd - 回归正常';
ok $s.sys.cwd.Str.ends-with($dir.basename), 'cd - 回到原目录';
ok $s.eval-line('bookmark add mark sub-a').ok, '添加书签';
ok $s.eval-line('bookmark list').out.contains('mark'), '书签可列出';
ok $s.eval-line('bookmark go mark').ok, '书签可跳转';
ok $s.eval-line('cd -').ok, '跳书签后可回到原目录';
ok $s.eval-line('bookmark del mark').ok, '删除书签';
nok $s.eval-line('bookmark go mark').ok, '删除后不可再跳转';
nok $s.eval-line('bookmark bogus').ok, '未知子命令报错';

# ── P1-4：会话日志（纯文本、经 Sys 落盘、可停止）───────────────────
ok $s.eval-line('log').out.contains('日志未开启'), 'log 无参数给状态';
ok $s.eval-line('log --help').out.contains('用法: log'), 'log --help 给用法';
ok $s.eval-line('log start ' ~ $log.Str).ok, 'log start 成功';
ok $s.log-active, '日志开关已打开';
my $r = $s.eval-line('1 + 1');
$s.log-line('1 + 1', $r, $s.render($r));
# 渲染文本在 TTY 下会带 SGR；日志必须剥掉。
$s.log-line('带色', $r, "\e[1m\e[34m彩色\e[0m 文本");
ok $s.eval-line('log show').out.contains('[1] > 1 + 1'), 'log show 含输入行';
ok $log.e, '日志文件已落盘';
ok $log.slurp.contains('[2] > 带色'), '日志内容写入文件';
nok $log.slurp.contains("\e["), '日志不含 ANSI';
ok $log.slurp.contains('彩色 文本'), '剥色后正文保留';
my $before = $log.s;
ok $s.eval-line('log stop').ok, 'log stop 成功';
nok $s.log-active, '日志开关已关闭';
$s.log-line('停止后', $r, '不该记录');
is $log.s, $before, '停止后不再追加';

done-testing;
