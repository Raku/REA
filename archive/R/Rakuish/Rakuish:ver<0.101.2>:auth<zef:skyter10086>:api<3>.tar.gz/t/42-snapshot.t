#!/usr/bin/env raku
use lib 'lib';
use Test;
use JSON::Fast;
use Rakuish::Result;
use Rakuish::Kernel;
use Rakuish::Audit;
use Rakuish::REPL::Session;
use Rakuish::Snapshot;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;

# 42-snapshot.t —— 会话快照（0.84.0 / ADR-0022）
#
# 这一版的主张：**声明与纯值可以跨进程边界活下来，语句不行**。
# 断言分五组：
#   ① classify 的可序列化边界（纯值 / 资源 / 闭包 / 超大）；
#   ② capture 的结构；
#   ③ save / load 的容错（坏文件、版本不符）；
#   ④ restore 的语义（声明重放、值恢复、失效列表）；
#   ⑤ 端到端：真崩溃 → 重启 → 从快照恢复 → 副作用**不**重复。

my IO::Path $dir = $*CWD.add('tmp');
$dir.mkdir unless $dir.e;
my IO::Path $snap = $dir.add("snap-test-{$*PID}.json");
$snap.unlink if $snap.e;
%*ENV<RAKUISH_SNAPSHOT> = $snap.Str;
%*ENV<RAKUISH_NO_SNAPSHOT> = '';

sub cleanup() { $snap.unlink if $snap.e; $snap.parent.add($snap.basename ~ '.tmp').unlink if $snap.parent.add($snap.basename ~ '.tmp').e }

# ── ① classify：可序列化边界 ────────────────────────────────────
{
    is Rakuish::Snapshot::classify(42)<kind>, 'value', 'Int 是可序列化值';
    is Rakuish::Snapshot::classify(42)<raku>, '42', 'Int 的 .raku';
    is Rakuish::Snapshot::classify('a "b"')<kind>, 'value', 'Str 是可序列化值';
    is Rakuish::Snapshot::classify([1, 2])<kind>, 'value', 'List 是可序列化值';
    is Rakuish::Snapshot::classify(%( a => 1 ))<kind>, 'value', 'Hash 是可序列化值';
    is Rakuish::Snapshot::classify(Nil)<kind>, 'nil', 'Nil 是 nil';
    is Rakuish::Snapshot::classify(Any)<kind>, 'nil', '未定义值是 nil';

    # 闭包：不能反序列化
    my %fn = Rakuish::Snapshot::classify(sub { 1 });
    is %fn<kind>, 'invalid', '闭包判为 invalid';
    like %fn<reason>, /closure/, '失效原因说明是闭包';

    # 资源：能「构造出来」但语义全新，必须判死
    my $p = Proc::Async.new($*EXECUTABLE.Str, '-e', '1', :r);
    my %proc = Rakuish::Snapshot::classify($p);
    is %proc<kind>, 'invalid', 'Proc::Async 判为 invalid';
    like %proc<reason>, /resource/, '失效原因说明是资源';

    my %sup = Rakuish::Snapshot::classify(Supply.interval(0.01));
    is %sup<kind>, 'invalid', 'Supply 判为 invalid';

    # 超大值：避免每格写一个几十 MB 的 JSON
    my %big = Rakuish::Snapshot::classify(
        'x' x (Rakuish::Snapshot::DEFAULT-MAX-VALUE-CHARS + 10));
    is %big<kind>, 'invalid', '超大值判为 invalid';
    like %big<reason>, /过大/, '失效原因说明是过大';
}

# ── ①b 单值上限可配置（0.87.0）────────────────────────────────
# 上限是「手感 vs 能救回多少」的取舍，硬编码一个数字等于把我的取舍
# 当成所有人的。这里是这条设计的环境变量契约。
{
    my %*ENV = %*ENV.Hash;          # 本块内改环境，出块自动还原
    %*ENV<RAKUISH_SNAPSHOT_MAX> = '';

    is Rakuish::Snapshot::max-value-chars(),
       Rakuish::Snapshot::DEFAULT-MAX-VALUE-CHARS, '未设置时用默认上限';

    %*ENV<RAKUISH_SNAPSHOT_MAX> = '10';
    is Rakuish::Snapshot::max-value-chars(), 10, '数字直接生效';
    # 走真实路径 env → capture → classify：classify 本身是纯函数，
    # 不读环境（谁读环境谁就不该被单测依赖）。
    my %m = Rakuish::Snapshot::capture(
        %( '$ok' => 'x' x 5, '$big' => 'x' x 20 ), []);
    is %m<state>{'$ok'}<kind>,  'value',   '小于上限的值仍可存';
    is %m<state>{'$big'}<kind>, 'invalid', '大于上限的值判失效';
    like %m<state>{'$big'}<reason>, /'10'/, '失效原因带上实际上限（不是写死的 1e6）';
    is %m<invalid>.List, ('$big',), 'invalid 只列出超限的那个';

    # 0 / off 都表示不限制
    %*ENV<RAKUISH_SNAPSHOT_MAX> = '0';
    is Rakuish::Snapshot::max-value-chars(), 0, '0 = 不限制';
    %*ENV<RAKUISH_SNAPSHOT_MAX> = 'off';
    is Rakuish::Snapshot::max-value-chars(), 0, 'off = 不限制';
    my %free = Rakuish::Snapshot::capture(%( '$a' => 'x' x 5000 ), []);
    is %free<state>{'$a'}<kind>, 'value', '不限制时长值可存';

    # 写错不能变成「关掉保护」
    %*ENV<RAKUISH_SNAPSHOT_MAX> = 'abc';
    is Rakuish::Snapshot::max-value-chars(),
       Rakuish::Snapshot::DEFAULT-MAX-VALUE-CHARS, '非法值回落到默认，不是当成 0';
    %*ENV<RAKUISH_SNAPSHOT_MAX> = '-5';
    is Rakuish::Snapshot::max-value-chars(),
       Rakuish::Snapshot::DEFAULT-MAX-VALUE-CHARS, '负数同样回落';

    # capture 用 :max 覆盖（不依赖环境，方便程序内控制）
    %*ENV<RAKUISH_SNAPSHOT_MAX> = '';
    my %snap = Rakuish::Snapshot::capture(
        %( '$a' => 'x' x 50 ), [], :max(10));
    is %snap<state>{'$a'}<kind>, 'invalid', 'capture 的 :max 生效';
    is %snap<invalid>.List, ('$a',), 'invalid 列表列出该变量';
}

# ── ② capture 的结构 ───────────────────────────────────────────
{
    my %state =
        '$x'  => 7,
        '@a'  => [1, 2],
        '$fn' => sub { 1 },
    ;
    my @decls = ( %( key => 'sub:double', src => 'my sub double($n) { $n * 2 }',
                     name => 'double', 'is-type' => False ), );
    my %snap = Rakuish::Snapshot::capture(%state, @decls, :cwd('/tmp/x'), :session('local'));
    is %snap{'snapshot-version'}, 1, '快照带格式版本';
    is %snap<cwd>, '/tmp/x', '快照记录 cwd';
    is %snap<decls>.elems, 1, '快照记录声明';
    is %snap<state>{'$x'}<raku>, '7', '标量存 .raku';
    is %snap<state>{'$fn'}<kind>, 'invalid', '闭包在快照里标记失效';
    is %snap<invalid>.List, ('$fn',), 'invalid 列表汇总失效变量';
}

# ── ③ save / load 容错 ─────────────────────────────────────────
{
    my %snap = Rakuish::Snapshot::capture(%( '$x' => 1 ), (), :cwd('/tmp'));
    ok Rakuish::Snapshot::save(%snap, $snap), 'save 成功';
    ok $snap.e, '文件存在';
    my %back = Rakuish::Snapshot::load($snap);
    is %back<state>{'$x'}<raku>, '1', 'load 读回值';

    # 坏文件不能挡住启动
    my $bad = $dir.add("snap-bad-{$*PID}.json");
    $bad.spurt('{ not json');
    is Rakuish::Snapshot::load($bad).elems, 0, '坏 JSON 返回空 Hash（不抛）';
    $bad.unlink;

    # 版本不符：直接当没有，而不是猜字段
    my $old = $dir.add("snap-old-{$*PID}.json");
    $old.spurt(to-json(%( 'snapshot-version' => 99, state => %() ), :!pretty));
    is Rakuish::Snapshot::load($old).elems, 0, '版本不符返回空 Hash';
    $old.unlink;
}

# ── ④ restore 语义 ─────────────────────────────────────────────
{
    my $a = Rakuish::REPL::Session.new;
    $a.eval-line('class Foo { has $.a; method hi { "hi" } }');
    $a.eval-line('my $f = Foo.new(a => 42)');
    $a.eval-line('my $x = 7');
    $a.eval-line('my $fn = -> $n { $n * 2 }');
    ok $snap.e, '会话求值后写出了快照';

    my %loaded = Rakuish::Snapshot::load($snap);
    ok %loaded.elems > 0, '快照可读';

    my $b = Rakuish::REPL::Session.new;
    my %r = $b.restore-snapshot(%loaded);
    is %r<decls>, 1, '恢复了 1 条声明';
    is %r<vars>, 2, '恢复了 2 个纯值变量（$f / $x）';
    is %r<failed>.List.sort, ('$fn',), '闭包进 failed 列表';

    is $b.eval-line('say $x').out.trim, '7', '标量值恢复正确';
    is $b.eval-line('say $f.a').out.trim, '42', '用户类实例恢复正确';
    is $b.eval-line('say $f.hi').out.trim, 'hi', '类的方法也一起恢复（声明重放）';

    # 失效变量恢复成 Any，不是「保留一个旧值」
    my $fn-line = $b.eval-line('$fn.defined');
    ok $fn-line.ok, '$fn 这一格能求值（没有未声明错误）';
    is $fn-line.value, False, '失效变量是未定义值';
}

# ── ⑤ 端到端：崩溃 → 重启 → 恢复，且副作用不重复 ────────────────
{
    my $mark = $dir.add("snap-mark-{$*PID}.txt");
    $mark.unlink if $mark.e;

    my $c = Rakuish::Eval::Client.new(:lib($*CWD.add('lib')));
    $c.start;
    my $p = Rakuish::Eval::Proxy.new(:client($c));
    my $k = Rakuish::Kernel.new(:session($p), :audit(Rakuish::Audit.new));

    $k.execute(Request.new(:kind<source>, :payload('my $kept = "alive"')));
    $k.execute(Request.new(:kind<source>, :payload('class Box { has $.n }')));
    $k.execute(Request.new(:kind<source>, :payload('my $box = Box.new(n => 9)')));
    # 副作用格：写一次文件。恢复时**不能**重放，否则会出现两份。
    $k.execute(Request.new(:kind<source>,
        :payload("write('{$mark.Str}', 'once')")));
    is $mark.slurp, 'once', '副作用格写了一次';

    my $boom = $k.execute(Request.new(:kind<source>, :payload('exit; 1')));
    nok $boom.ok, '崩溃格失败';
    is $boom.op, 'engine-restart', 'op=engine-restart';

    my Str $text = $p.render($boom);
    like $text, /'已从快照恢复'/, '结果文本说明已从快照恢复';
    unlike $text, /'会话状态已丢失'/, '恢复成功时不再谎报「全部丢失」';

    is $k.execute(Request.new(:kind<source>, :payload('say $kept'))).out.trim,
       'alive', '字符串变量跨崩溃存活';
    is $k.execute(Request.new(:kind<source>, :payload('say $box.n'))).out.trim,
       '9', '用户类实例跨崩溃存活';
    is $mark.slurp, 'once', '副作用没有被重放（文件仍是一份）';

    $c.shutdown;
}

# ── ⑥ 关闭开关 ─────────────────────────────────────────────────
{
    my $off = $dir.add("snap-off-{$*PID}.json");
    $off.unlink if $off.e;
    %*ENV<RAKUISH_SNAPSHOT> = $off.Str;
    %*ENV<RAKUISH_NO_SNAPSHOT> = '1';
    my $s = Rakuish::REPL::Session.new;
    nok $s.snapshot-on, 'RAKUISH_NO_SNAPSHOT=1 关闭快照';
    $s.eval-line('my $y = 1');
    nok $off.e, '关闭后不写文件';
    %*ENV<RAKUISH_NO_SNAPSHOT> = '';
    %*ENV<RAKUISH_SNAPSHOT> = $snap.Str;
}

cleanup();
done-testing;
