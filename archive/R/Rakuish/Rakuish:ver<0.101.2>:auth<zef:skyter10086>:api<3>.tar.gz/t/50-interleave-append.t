#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Sys;
use Rakuish::Data::Table;
use Rakuish::Data::Stream;

# 50-interleave-append.t —— 按顺序收拢两条流（0.95.0 / ADR-0030）
#
# 主张四条：
#   ① interleave 按位置交替，默认吐完长侧、:shortest 取短；
#   ② append 先左后右，左流耗尽之前不碰右流；
#   ③ 两者都**不改行、不改名**（与 zip 的「合成一行 + 加后缀」分界）；
#   ④ 惰性、一次性来源传播、入参错误当场抛。
#
# 特别守住两个「看起来对、其实错」的退化：
#   - 把 :shortest 的默认搞反 → 数据凭空少一半，还不报错；
#   - append 提前取右流 → 一次性右来源在左流还没读完时就被标记已消费。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';
%*ENV<RAKUISH_NO_RC> = '1';

my $dir = $*TMPDIR.IO.add("rakuish-concat-{$*PID}");
$dir.mkdir unless $dir.d;
LEAVE { try { $dir.dir>>.unlink; $dir.rmdir } }

my $*RAKUISH-SYS = Rakuish::Sys.new(:root($dir), :cwd($dir));

sub s(Str $csv) { Rakuish::Data::Stream.from($csv, :format<csv>) }
sub cells($x, Str $col) {
    my $t = $x ~~ Rakuish::Data::Stream ?? $x.table !! $x;
    $t.get($col).List;
}
# 缺列的地方归一成可见字符串：直接把 Nil / Any 放进 is 的操作数会让
# Test 在生成诊断时字符串化它们，刷一屏 uninitialized warning（zef 里尤其脏）。
sub shown($x, Str $col) {
    cells($x, $col).map({ $_.defined ?? $_.Str !! '<nil>' }).List;
}

my $L = s("k,v\na,1\nb,2\nc,3");
my $R = s("k,w\nA,X\nB,Y");

# ── ① interleave ───────────────────────────────────────────────────
{
    my $z = $L.interleave($R);
    is $z.count, 5, 'interleave：默认吐完长侧（3+2=5，不丢记录）';
    is cells($z, 'k').List, ('a', 'A', 'b', 'B', 'c'),
        'interleave：严格按位置交替';
    is shown($z, 'v'), ('1', '<nil>', '2', '<nil>', '3'),
        'interleave：每行保持自己的列（右行没有 v）';
    is shown($z, 'w'), ('<nil>', 'X', '<nil>', 'Y', '<nil>'),
        'interleave：右行列也不被搬走';
    is $z.table.columns.List, <k v w>,
        'interleave：列取两侧并集、同名 k 不改名（与 zip 不同）';

    my $short = $L.interleave($R, :shortest);
    is $short.count, 4, 'interleave :shortest：任一侧耗尽即停（2 轮 × 2 行）';
    is cells($short, 'k').List, ('a', 'A', 'b', 'B'),
        'interleave :shortest：不吐长侧剩下的那行';

    # 等长时两种口径一致
    my $eq = s("n\n1\n2").interleave(s("m\n3\n4"));
    is shown($eq, 'n'), ('1', '<nil>', '2', '<nil>'), 'interleave：等长时先左后右';
    is shown($eq, 'm'), ('<nil>', '3', '<nil>', '4'), 'interleave：等长时右侧跟着交替';

    # 右表可以是 Table / 记录列表
    my $tb = Rakuish::Data::Table.from-rows([{ k => 'Z', w => 9 }]);
    is cells(s("k\nq").interleave($tb), 'k').List, ('q', 'Z'),
        'interleave：右侧可以是 Table';
    my $one-row = %( k => 'W' );
    is cells(s("k\nq").interleave(($one-row,)), 'k').List, ('q', 'W'),
        'interleave：右侧可以是记录列表';

    # 完全惰性：first-row 只拉两条各一行
    my Int $pulled = 0;
    my $big = Rakuish::Data::Stream.new(
        :make(-> { (1 .. 5000).map(-> $i { $pulled++; %( k => $i ) }) }),
    );
    is $big.interleave(s("k\nX")).first-row<k>, 1,
        'interleave：首行立即可得';
    ok $pulled < 10, "interleave：只拉了 {$pulled} 条左行（不是 5000）";
}

# ── ② append ───────────────────────────────────────────────────────
{
    my $a = $L.append($R);
    is $a.count, 5, 'append：行数相加';
    is cells($a, 'k').List, ('a', 'b', 'c', 'A', 'B'),
        'append：先左流全部、再右流全部（不是交替）';
    is $a.table.columns.List, <k v>,
        'append：列取左侧（同构契约；右侧多出的 w 不悄悄并入）';

    my $tb = Rakuish::Data::Table.from-rows([{ k => 'Z', v => 9 }]);
    is cells($L.append($tb), 'k').List, ('a', 'b', 'c', 'Z'),
        'append：右侧可以是 Table';
    # 注意 `[%( k => ... )]` 会把 Hash slip 成 Pair 列表（项目踩过的坑），
    # 单条记录要用 ($hash,) 或 push 到数组里。
    my $one-row = %( k => 'W', v => 7 );
    is cells($L.append(($one-row,)), 'k').List, ('a', 'b', 'c', 'W'),
        'append：右侧可以是记录列表';

    # 左侧列未知（map 之后）→ 取右侧列，让 `.table` 有列头可用
    my $mapped = s("k,v\na,1").map(-> $r { %( k => $r<k>, v => $r<v> ) });
    is $mapped.append(s("k,v\nb,2")).table.columns.List, <k v>,
        'append：左侧列未知时取右侧列';

    # 左流耗尽之前不碰右流：一次性右来源的计数器必须还是 0
    my Int $right-pulled = 0;
    my $right-once = Rakuish::Data::Stream.new(
        :make(-> { (1 .. 3).map(-> $i { $right-pulled++; %( k => $i ) }) }),
        :repeatable(False),
    );
    is $L.append($right-once).limit(2).count, 2,
        'append：下游截断只拿左流前两行';
    is $right-pulled, 0, 'append：左流没读完时不碰右流';

    # 空流边界
    is s("").append(s("k\nx")).count, 1, 'append：左侧空流';
    is s("k\nx").append(s("")).count, 1, 'append：右侧空流';
}

# ── ③ 来源 / 一次性 / 错误 ─────────────────────────────────────────
{
    ok $L.interleave($R).repeatable, 'interleave：两侧可重读 → 可重读';
    ok $L.append($R).repeatable,     'append：两侧可重读 → 可重读';

    my $once = Rakuish::Data::Stream.new(
        :make(-> { (%( k => 'Z', w => 9 ),).Seq }), :repeatable(False));
    nok $L.interleave($once).repeatable, 'interleave：右一次性 → 结果一次性';
    nok $L.append($once).repeatable,     'append：右一次性 → 结果一次性';

    my $half = $L.append($once);
    is $half.count, 4, 'append：一次性右流首次消费正常';
    throws-like { $half.count }, X::Rakuish::Data,
        message => /'已经读过一次'/, 'append：二次消费报错，不静默给空';

    # 必须用新的流：上面 $half 已经把 $once 消费过一次了
    my $once2 = Rakuish::Data::Stream.new(
        :make(-> { (%( k => 'Z', w => 9 ),).Seq }), :repeatable(False));
    my $half2 = $L.interleave($once2);
    $half2.count;
    throws-like { $half2.count }, X::Rakuish::Data,
        message => /'已经读过一次'/, 'interleave：二次消费报错';

    # 与 zip/join 一致：!rows-of 在 :make 里，非法入参在**消费时**抛，
    # 不猜、不静默给空（SPEC V-259 的「当场」指不回落，不是构造期）。
    throws-like { $L.interleave(42).count }, X::Rakuish::Unsupported,
        message => /'需要 Stream'/, 'interleave：非法入参报错';
    throws-like { $L.append(42).count }, X::Rakuish::Unsupported,
        message => /'需要 Stream'/, 'append：非法入参报错';
}

done-testing;
