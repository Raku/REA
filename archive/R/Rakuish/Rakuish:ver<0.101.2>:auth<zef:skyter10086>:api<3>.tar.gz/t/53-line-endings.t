use v6.d;
use Test;

# 行尾护栏（0.86.0）。
#
# `.gitattributes` 已经写了 `* text=auto eol=lf`，但那只在 **git 动作**时
# 生效：一个用 Python / PowerShell 写出来的 CRLF 文件，在工作区里就是 CRLF，
# `bash tools/ci.sh` 在 WSL 里读挂载目录会直接报 `$'\r': command not found`
# —— 0.86 开发中真的踩到了（改 `tools/ci.sh` 时被 Python 的文本模式翻译）。
#
# 这条测试守的是**工作区**而不是仓库：只要有一个文本文件带 CRLF 就红。
# 它会逼着「写完先转 LF」，而不是等 WSL 那边炸出来才发现。
#
# 读文件必须用**:bin + latin1 解码**，不能用 `slurp(:enc)` —— 后者默认带
# `nl-in` 翻译，会把 `\r\n` 折成 `\n`，于是这条断言永远绿（实测过：
# 故意污染 `tools/ci.sh` 它照样报 ok）。这是个典型的「护栏自身假绿」。

plan 4;

my IO::Path $root = $*CWD;

my constant TEXT-EXT = <
    .sh .py .rakumod .t .md .json .raku .c .h .txt .yml .yaml
>;
my constant SKIP-DIR = <
    .git .workbuddy tmp .precomp node_modules
>;

sub walk(IO::Path $d, @acc) {
    return @acc unless $d.d;
    for $d.dir -> $e {
        my Str $name = $e.basename;
        if $e.d {
            next if $name (elem) SKIP-DIR;
            walk($e, @acc);
        }
        elsif $e.f {
            my Str $ext = $e.extension ?? '.' ~ $e.extension !! '';
            @acc.push($e) if $ext (elem) TEXT-EXT;
        }
    }
    @acc
}

# 只扫**仓库内容**（固定目录 + 根文件），不扫全工作区：
# 开发时旁边常有用完没删的临时文件（0.86 实测：WSL 副本里有个
# `_probe_drive.raku` 带 CRLF，把这条断言顶红了），那不是交付物，
# 不该让一条行尾护栏跟着环境变化。
my constant TARGET-DIRS = <lib bin t tools docs>;
my constant ROOT-FILES  = <META6.json README.md SPEC.md HANDOFF.md .gitattributes>;

my @files;
for TARGET-DIRS -> $d {
    my IO::Path $p = $root.add($d);
    walk($p, @files) if $p.d;
}
for ROOT-FILES -> $f {
    my IO::Path $p = $root.add($f);
    @files.push($p) if $p.f;
}

# Windows 上 `relative` 会给出反斜杠，比之前统一成正斜杠，
# 否则这条断言在 Windows 上恒假 —— 而那正是它要防的「空扫」假绿。
my &rel = -> $p { $p.relative($root).Str.subst('\\', '/', :g) };

ok @files.elems > 20, "扫到 {@files.elems} 个文本文件（防空跑：至少 20 个）";

is @files.grep({ rel($_) eq 'tools/ci.sh' }).elems, 1,
   'tools/ci.sh 在扫描范围内（防止 walk 写错导致空扫）';

my @bad;
for @files -> $f {
    my $buf = try { $f.slurp(:bin) } // Buf.new;
    next unless $buf.elems;
    my Str $text = $buf.decode('latin1');   # decode 不做换行翻译
    next unless $text.contains("\r\n");
    @bad.push(rel($f));
}

is @bad.elems, 0,
   '没有文本文件使用 CRLF 行尾（.gitattributes 要求 eol=lf）'
   or diag "带 CRLF 的文件（前 10 个）：\n  "
        ~ @bad[0 ..^ (@bad.elems min 10)].join("\n  ");

# 附带的正面断言：`bin/rakuish` 与 `tools/ci.sh` 都以 `#!` 开头，
# 保证它们作为可执行入口没被写成别的编码/换行风格。
my @shebang = <bin/rakuish tools/ci.sh>;
is @shebang.map({ $root.add($_).slurp(:bin).decode('latin1').starts-with('#!') }).all.so, True,
   '可执行入口以 shebang 开头';
