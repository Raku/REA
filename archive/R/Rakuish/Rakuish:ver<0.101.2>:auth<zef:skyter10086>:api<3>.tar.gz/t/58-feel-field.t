use Test;

# 58-feel-field.t —— HlField 渲染管线与交互动作（0.100.0 / ADR-0034；0.101.0 / ADR-0035）
# 追加：逐词接受（V-283）、补全候选建议来源（V-284）。
#
# 不经 TTY：直接构造 input-class 字段 + 桩 provider，覆盖——
#   · 灰字建议渲染（V-277）与宽度不变式（strip 后宽度 == display-width）
#   · accept-suggestion（整句接受 / 无建议退化为右移）
#   · Ctrl-R 循环历史检索（V-281：查询态保持、到头回绕、其它编辑复位）
#   · ShiftTab 候选菜单（V-279：分栏、去重、\r\n 分隔、重画输入区）
#   · 语义标记进渲染（V-280：错误色段）
#   · 掩码输入不给建议 / 不给菜单
#
# ⚠ marks 列表元素必须是标量包 Hash（[$h]）——`[ %(...) ]` 会被 Array
# 字面量展平成 Pair（t/57 头注有记）。

use Rakuish::REPL::Keymap;
use Rakuish::REPL::Chrome;

sub strip-ansi(Str $s --> Str) {
    $s.subst(:g, / \e '[' <[0..9;]>* 'm' /, '')
}

my $W = 40;

# 桩 provider：不依赖 Shell / Session
my &get-completions = -> $line, $pos {
    $line.substr(0, $pos) eq 'op' ?? ('open ', 'open-data ', 'open-db ') !! ()
};
my &get-marks = -> $line {
    $line eq 'lss' ?? [ %(start => 0, end => 3, kind => 'command') ] !! ()
};
my $cli = make-cli(:&get-completions, :&get-marks);
ok $cli.defined, 'make-cli 构造成功';

sub fresh-field(:$mask --> Any) {
    my %o = :display-width($W), :field-start(0);
    %o<mask> = $mask if $mask.defined;
    $cli.input-class.new(|%o)
}

# ── 1. 灰字建议渲染（V-277）────────────────────────────────────────
{
    my $f = fresh-field;
    $f.do-edit('insert-string', 'say "hel');
    my $r = $f.visible-input-field-string;
    nok $r.contains('world'), '无历史时无建议';

    $cli.add-history('say "hello world"');
    $r = $f.visible-input-field-string;
    ok $r.contains('lo world"'), '建议后缀出现在渲染里';
    ok $r.contains(%CLR<gray>), '建议用灰色';
    is strip-ansi($r).chars, $W,
        '宽度不变式：strip 后可见宽度 == display-width';
    like strip-ansi($r), / 'say "hel' .* 'lo world"' /,
        '建议紧跟内容段之后';

    # 整句接受
    $f.do-edit('accept-suggestion');
    is $f.buffer.contents, 'say "hello world"', 'accept-suggestion 插入整句';
}

# ── 2. accept 退化（V-277）─────────────────────────────────────────
{
    my $f = fresh-field;
    $f.do-edit('insert-string', 'abc');
    $f.do-edit('accept-suggestion');           # 无建议
    is $f.buffer.contents, 'abc', '无建议时插入 nothing';
    is $f.insert-cursor.pos, 3, '无建议时退化为右移一格（已在行尾则不动）';
}

# ── 3. Ctrl-R 循环历史检索（V-281）─────────────────────────────────
{
    $cli.add-history('say "one"');
    $cli.add-history('say "two"');
    $cli.add-history('say "three"');
    my $f = fresh-field;
    $f.do-edit('insert-string', 'say');
    $f.do-edit('history-search');
    is $f.buffer.contents, 'say "three"', '首按 → 最近的匹配';
    $f.do-edit('history-search');
    is $f.buffer.contents, 'say "two"',   '连按 → 更旧的匹配';
    $f.do-edit('history-search');
    is $f.buffer.contents, 'say "one"',   '再按 → 更旧';
    $f.do-edit('history-search');
    is $f.buffer.contents, 'say "hello world"', '继续走向更旧';
    $f.do-edit('history-search');
    is $f.buffer.contents, 'say "three"', '到头回绕到最近';

    # 其它编辑复位查询态：从新缓冲区重新开始
    $f.do-edit('delete-to-start');
    $f.do-edit('delete-to-end');
    $f.do-edit('insert-string', 'say "t');
    $f.do-edit('history-search');
    is $f.buffer.contents, 'say "three"', '查询态复位后以新缓冲区为查询串';

    # 空缓冲区 = 匹配一切（最近优先）
    $f.do-edit('delete-to-start');
    $f.do-edit('delete-to-end');
    $f.do-edit('history-search');
    is $f.buffer.contents, 'say "three"', '空查询按最近历史走';
}

# ── 4. 候选菜单（V-279）────────────────────────────────────────────
{
    my $f = fresh-field;
    $f.do-edit('insert-string', 'op');
    my $menu = $f.do-edit('complete-list');
    ok $menu.contains("\r\n"), '菜单与输入区之间换行';
    ok $menu.contains('open-data'), '菜单含候选 open-data';
    ok $menu.contains('open-db'),   '菜单含候选 open-db';
    my $plain = strip-ansi($menu);
    ok $plain ~~ / 'open' ' ' .* 'open-data' /, '候选按列排布';
    nok $plain ~~ / 'open' \s+ 'open' \s+ 'open-data' /,
        '公共前缀候选不与同词候选重复显示';

    # 空候选：无输出
    $f.do-edit('delete-to-start');
    $f.do-edit('delete-to-end');
    $f.do-edit('insert-string', 'zz');
    is $f.do-edit('complete-list'), '', '无候选时菜单为空串';
}

# ── 5. 语义标记进渲染（V-280）──────────────────────────────────────
{
    my $f = fresh-field;
    $f.do-edit('insert-string', 'lss');
    my $r = $f.visible-input-field-string;
    ok $r.contains(%CLR<red>), '错误态段上红色';
    is strip-ansi($r).chars, $W, '标记不破坏宽度不变式';
}

# ── 6. 掩码输入（密码）────────────────────────────────────────────
{
    my $f = fresh-field(:mask('*'));
    $f.do-edit('insert-string', 'say "hel');
    my $r = $f.visible-input-field-string;
    nok $r.contains('world'), '掩码输入无建议';
    is $f.do-edit('complete-list'), '', '掩码输入无菜单';
}

# ── 7. 键绑定（V-277/V-279/V-281/V-283 接线）────────────────────────
{
    my Int $n = bind-interaction-keys($cli);
    ok $n >= 5, "交互键绑定成功（$n 个，含 Alt-CursorRight 逐词接受）";
}

# ── 8. 逐词接受建议（V-283 / ADR-0035）──────────────────────────────
{
    my $f = fresh-field;
    $f.do-edit('insert-string', 'say hello wor');
    $cli.add-history('say hello world again');
    $f.visible-input-field-string;               # 刷新建议
    $f.do-edit('accept-suggestion-word');
    is $f.buffer.contents, 'say hello world',
       '第一次 Alt-→ 吞前导空白+第一个词（ld → world）';
    $f.visible-input-field-string;               # 重算剩余建议
    $f.do-edit('accept-suggestion-word');
    is $f.buffer.contents, 'say hello world again',
       '第二次 Alt-→ 吞下一个词（ again）';
    $f.visible-input-field-string;
    $f.do-edit('accept-suggestion-word');
    is $f.buffer.contents, 'say hello world again',
       '无建议时 Alt-→ 不吞键';
}

# ── 9. 补全候选作为建议来源（V-284）──────────────────────────────────
{
    # 用独立 cli（桩 provider 对 op 给候选，且该行不在历史里）
    my &gc = -> $l, $p { $l eq 'op' ?? ('open-data ', 'open-db ') !! () };
    my &gm = -> $l { () };
    my $c2 = make-cli(:get-completions(&gc), :get-marks(&gm));
    my $f = $c2.input-class.new(:display-width($W), :field-start(0));
    $f.do-edit('insert-string', 'op');
    my $r = $f.visible-input-field-string;
    ok $r.contains('en-data'), '历史无命中时退到补全候选做灰字建议';
    is strip-ansi($r).chars, $W, '补全来源建议不破坏宽度不变式';
    $f.do-edit('accept-suggestion');
    is $f.buffer.contents, 'open-data ', '补全来源建议可整句接受';
}

done-testing;
