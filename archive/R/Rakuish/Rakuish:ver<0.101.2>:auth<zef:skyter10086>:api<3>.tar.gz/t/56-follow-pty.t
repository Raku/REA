#!/usr/bin/env raku
use lib 'lib';
use Test;

# 56-follow-pty.t —— `tail -f` 的交互契约（0.99.0 / ADR-0033）
#
# 主张四条（真 PTY，引擎子进程模式）：
#   ① tail -f 先打末行、新增内容实时出现（引擎经 job 帧转给父进程跑循环）；
#   ② Ctrl-C 只停止跟随，**引擎不重启**（$*PID 不变、无重启文案）；
#   ③ 停止后会话完好：之前的 my 变量还在，下一格正常求值；
#   ④ head -f 明确拒绝。
#
# Windows 无 pty 模块，整段 skip（命令层解析由 t/10 覆盖，循环由 t/55 覆盖）。

my Bool $pty-ok = !$*DISTRO.is-win;
my Str $py = '';
if $pty-ok {
    my $probe = try {
        my $p = run('python3', '-c', 'import pty, os; print("ok")', :out, :err);
        $p.out.slurp(:close).trim
    };
    $py = ($probe // '');
}

if $pty-ok && $py eq 'ok' {
    my IO::Path $tmp = $*CWD.add('tmp');
    $tmp.mkdir unless $tmp.e;
    my Str $tag = $*PID.Str;
    my $driver = $tmp.add("follow-driver-{$tag}.py");
    my $log    = $tmp.add("follow-log-{$tag}.txt");
    $log.spurt("first line\n");

    # 驱动只往 stdout 打 PROBE 行；PTY 原始字节留在内存里判定。
    $driver.spurt(Q:to/PYTHON/);
        import fcntl, os, pty, re, select, struct, sys, termios, time

        root, raku, logp = sys.argv[1], sys.argv[2], sys.argv[3]
        home = '/tmp/rakuish-follow-%d' % os.getpid()
        os.makedirs(home, exist_ok=True)
        env = os.environ.copy()
        env.update(
            RAKUISH_CONFIG=home + '/config.json',
            TERM='xterm-256color',
            LANG='C.UTF-8',
            PATH=os.path.dirname(raku) + ':' + env.get('PATH', ''),
        )

        os.chdir(root)
        pid, master = pty.fork()
        if pid == 0:
            os.execve(raku, [raku, '-Ilib', 'bin/rakuish'], env)
        fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack('HHHH', 24, 110, 0, 0))

        exit_state = {'code': None}

        def poll():
            if exit_state['code'] is not None:
                return exit_state['code']
            try:
                wpid, status = os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                exit_state['code'] = 'reaped'
                return exit_state['code']
            if wpid == 0:
                return None
            try:
                exit_state['code'] = os.waitstatus_to_exitcode(status)
            except ValueError:
                exit_state['code'] = -1
            return exit_state['code']

        raw = bytearray()
        esc = b''
        size_pending = False
        deadline = time.time() + 120

        def feed(data):
            global esc, size_pending
            for byte in data:
                esc += bytes((byte,))
                if len(esc) > 24:
                    esc = esc[-24:]
                if esc.endswith(b'\x1b[9999;9999H'):
                    size_pending = True
                elif esc.endswith(b'\x1b[6n'):
                    os.write(master, b'\x1b[24;110R' if size_pending else b'\x1b[1;1R')
                    size_pending = False
                    esc = b''

        def pump(seconds):
            end = time.time() + seconds
            while time.time() < end and time.time() < deadline:
                readable, _, _ = select.select([master], [], [], 0.08)
                if not readable:
                    continue
                try:
                    data = os.read(master, 65536)
                except OSError:
                    break
                if not data:
                    break
                raw.extend(data)
                feed(data)
                end = max(end, time.time() + 0.2)

        def send(text, wait=0.8):
            os.write(master, text.encode() if isinstance(text, str) else text)
            pump(wait)

        def has(marker):
            return (marker.encode() if isinstance(marker, str) else marker) in raw

        def clean():
            return re.sub(rb'\x1b\[[0-9;?]*[A-Za-z]', b'', bytes(raw))

        def wait_for(marker, timeout=25):
            end = time.time() + timeout
            while time.time() < end:
                if has(marker):
                    return True
                pump(0.2)
            return False

        probe = {}
        ready = wait_for('\u276f', 40)
        probe['ready'] = 1 if ready else 0
        if ready:
            # 前置：my 变量 + 记录引擎 pid
            send('my $x = 42\r', 0.8)
            wait_for('Out[1] = 42')
            send('my $p = $*PID\r', 0.8)
            pump(1.0)
            m = re.search(rb'Out\[2\] = (\d+)', clean())
            engine_pid = int(m.group(1)) if m else 0
            probe['pid-captured'] = 1 if engine_pid else 0

            # ① tail -f：先打末行（相对路径，过 root 校验）
            rel = os.path.relpath(logp, root).replace('\\', '/')
            send('tail -f %s\r' % rel, 1.2)
            probe['initial'] = 1 if b'first line' in clean() else 0

            # 新增内容实时出现
            with open(logp, 'a') as f:
                f.write('appended line\n')
                f.flush()
            probe['appended'] = 1 if wait_for('appended line', 15) else 0

            # ② Ctrl-C 停跟随，引擎不重启
            os.write(master, b'\x03')
            probe['stopped'] = 1 if wait_for('\u5df2\u505c\u6b62\u8ddf\u968f', 15) else 0
            probe['no-restart'] = 0 if has('\u5df2\u81ea\u52a8\u91cd\u542f') or has('engine-restart') else 1

            # ③ 会话完好（clean() 是 raw 的确定性去 ANSI 结果，标记取它的偏移）
            cmark = len(clean())
            send('$x\r', 1.2)
            probe['x-alive'] = 1 if re.search(rb'Out\[\d+\] = 42', clean()[cmark:]) else 0
            cmark = len(clean())
            send('$p == $*PID\r', 1.2)
            probe['same-engine'] = 1 if re.search(rb'Out\[\d+\] = (Bool::)?True', clean()[cmark:]) else 0

            # ④ head -f 拒绝
            send('head -f %s\r' % rel, 1.0)
            probe['head-reject'] = 1 if wait_for('head \u4e0d\u652f\u6301', 10) else 0

            send('exit\n', 1.0)
        pump(1.0)
        for _ in range(60):
            if poll() is not None:
                break
            pump(0.1)
        probe['clean_exit'] = 1 if poll() == 0 else 0
        os.close(master)
        for k, v in probe.items():
            print('PROBE %s=%s' % (k, v))
        PYTHON

    my $ran = try {
        my $p = run('python3', $driver.Str, $*CWD.Str, $*EXECUTABLE.Str,
                    $log.Str, :out, :err);
        ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
    };
    my Str $text = $ran // '';
    my %p;
    for $text.lines -> $line {
        next unless $line.starts-with('PROBE ');
        my @kv = $line.substr(6).split('=', 2);
        %p{@kv[0]} = (@kv[1] // '');
    }

    is %p<ready>, '1', '真 PTY：REPL 出现第一个 prompt';
    is %p<pid-captured>, '1', '前置：记录引擎 pid';
    is %p<initial>, '1', '① tail -f 先打末行';
    is %p<appended>, '1', '① 新增内容实时出现';
    is %p<stopped>, '1', '② Ctrl-C 停止跟随（出现停止摘要）';
    is %p<no-restart>, '1', '② 引擎没有重启（无重启文案）';
    is %p<x-alive>, '1', '③ my 变量还在';
    is %p<same-engine>, '1', '③ 引擎 pid 未变（真没重启）';
    is %p<head-reject>, '1', '④ head -f 明确拒绝';
    is %p<clean_exit>, '1', '之后仍可正常退出（rc=0）';

    try { .unlink for ($driver, $log) };
}
else {
    skip 'Windows / 无 pty 模块：跟随交互由 t/10/t/55 覆盖', 10;
}

done-testing;
