#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys;
use Rakuish::Data::Table;
use Rakuish::Data::Cursor;
use Rakuish::Data::Stream;
use Rakuish::REPL::Session;

# 46-stream.t —— 结构化管道（0.91.0 / ADR-0026）
#
# 主张：**文本能变成记录、记录能变成表格、记录能喂回子进程的 stdin，而且
# 中间该惰性的时候真的惰性。**
# 断言分五组：
#   ① 文本入口（lines / csv / tsv / json / jsonl / pattern）与列顺序；
#   ② 阶段（where / select / sort-by / unique / count-by / group-by / add-column）
#      与惰性边界（limit 只拉需要的那几行）；
#   ③ 出口（table / text / json / csv / lines / count / sum / exec stdin）；
#   ④ 边界（失败的 Result 明确抛、游标流只能读一次、未知格式报错）；
#   ⑤ REPL 接线（Session 渲染流 / DSL stream() 接受 Table 与文本）。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';
%*ENV<RAKUISH_NO_RC> = '1';

my Str $raku = $*EXECUTABLE.Str;

# ── ① 文本入口 ──────────────────────────────────────────────────────
{
    my $s = Rakuish::Data::Stream.from("a\nb\nc");
    is $s.table.columns.List, <n line>, 'lines：列顺序是 n, line（不是哈希顺序）';
    is $s.count, 3, 'lines：三行';

    my $csv = Rakuish::Data::Stream.from("name,size\nx,10\ny,20", :format<csv>);
    is $csv.table.columns.List, <name size>, 'csv：表头顺序保留';
    is $csv.count, 2, 'csv：两行数据';
    is $csv.sum('size'), 30, 'csv：字符串数字也能求和（"10" 不是 Numeric）';

    my $tsv = Rakuish::Data::Stream.from("a\tb\n1\t2", :format<tsv>);
    is $tsv.table.columns.List, <a b>, 'tsv：表头即列名';
    is $tsv.first-row<a>, '1', 'tsv：取值';

    is Rakuish::Data::Stream.from('[{"a":1},{"a":2}]', :format<json>).count,
       2, 'json：对象数组';
    is Rakuish::Data::Stream.from(q[{"a":1}] ~ "\n" ~ q[{"a":2}], :format<jsonl>).count,
       2, 'jsonl：一行一个对象';

    my $p = Rakuish::Data::Stream.from("x 10\ny 20", :format<pattern>,
        :pattern(/(\w+)\s+(\d+)/), :names<k v>);
    is $p.table.columns.List, <n k v>, 'pattern：n + 指定列名';
    is $p.sum('v'), 30, 'pattern：捕获值可计算';

    my $anon = Rakuish::Data::Stream.from("x 10", :format<pattern>,
        :pattern(/(\w+)\s+(\d+)/));
    ok $anon.table.columns.grep({ .Str.starts-with('c') }).elems >= 2,
       'pattern：不给名字时用 c0/c1';

    throws-like { Rakuish::Data::Stream.from('x', :format<nope>) },
        X::Rakuish::Unsupported, '未知格式明确报错';
    throws-like { Rakuish::Data::Stream.from('x', :format<pattern>) },
        X::Rakuish::Unsupported, 'pattern 缺 :pattern 明确报错';
}

# ── ② 阶段与惰性 ────────────────────────────────────────────────────
{
    my $csv = "name,size\nx,10\ny,30\nz,20";

    is Rakuish::Data::Stream.from($csv, :format<csv>)
        .where({ .<size>.Int > 10 }).count, 2, 'where：按数值过滤';

    is Rakuish::Data::Stream.from($csv, :format<csv>)
        .sort-by('size', :reverse).select('name').lines.join(','),
       'y,z,x', 'sort-by reverse + select + lines';

    is Rakuish::Data::Stream.from($csv, :format<csv>).sort-by('name').lines('name').join(','),
       'x,y,z', 'sort-by 升序';

    is Rakuish::Data::Stream.from("a\na\nb").select('line').unique.count,
       2, 'unique：去重';

    is Rakuish::Data::Stream.from($csv, :format<csv>).count-by('name').count,
       3, 'count-by：每个名字一组';

    my $g = Rakuish::Data::Stream.from($csv, :format<csv>).group-by('name');
    is $g.count, 3, 'group-by：三组';
    is $g.first-row<rows>.elems, 1, 'group-by：组内行保留';

    is Rakuish::Data::Stream.from("1\n2\n3").limit(2).count, 2, 'limit';
    is Rakuish::Data::Stream.from("1\n2\n3").skip(1).count, 2, 'skip';

    my $add = Rakuish::Data::Stream.from("1\n2").add-column('double', -> $r { $r<n> * 2 });
    is $add.sum('double'), 6, 'add-column';
    is $add.table.columns.List, <n line double>, 'add-column：新列进入表头';

    is Rakuish::Data::Stream.from("a,b\n1,2", :format<csv>).drop('b').table.columns.List,
       <a>, 'drop 去掉列';

    is Rakuish::Data::Stream.from("1\n2").map({ '<' ~ $_.<line> ~ '>' }).count,
       2, 'map 返回非 Hash 时包成 value 列';
    is Rakuish::Data::Stream.from("1\n2").map({ %( v => $_.<n> ) }).table.columns.List,
       <v>, 'map 之后列元数据重新推断';

    # 惰性：只有被下游要走的行才会从上游拉。
    my Int $pulled = 0;
    my $lazy = Rakuish::Data::Stream.new(
        :make(-> { (1..1000).map({ $pulled++; %( i => $_ ) }).Seq }));
    is $lazy.limit(3).count, 3, 'limit 后只取三个';
    is $pulled, 3, '上游只被拉了三次（不是先物化 1000 行）';
}

# ── ③ 出口 ──────────────────────────────────────────────────────────
{
    my $s = Rakuish::Data::Stream.from("k,v\nx,1\ny,2", :format<csv>);
    like $s.text, /'k'/, 'text：含表头';
    is $s.count, 2, 'count';
    is $s.sum('v'), 3, 'sum';
    is $s.mean('v'), 1.5, 'mean';
    is $s.min('v'), 1, 'min';
    is $s.max('v'), 2, 'max';

    my $json = Rakuish::Data::Stream.from("a\nb").json;
    like $json, /'"line"'/, 'json：列名就是键';

    my $csv = Rakuish::Data::Stream.from("a,b\n1,2", :format<csv>).csv;
    is $csv, "a,b\n1,2\n", 'csv：与 from-csv 对称';

    is Rakuish::Data::Stream.from("x\ny").lines.join('|'), 'x|y', 'lines：取 line 列';

    my Int $seen = 0;
    is Rakuish::Data::Stream.from("1\n2\n3").each({ $seen++ }), 3, 'each：返回处理行数';
    is $seen, 3, 'each：确实逐行回调';

    # 管道的另一半：记录 → 子进程 stdin。
    my $sys = Rakuish::Sys.new;
    my $*RAKUISH-SYS = $sys;
    my $r = Rakuish::Data::Stream.from("a\nb\nc")
        .exec($raku, '-e', 'say $*IN.lines.elems');
    ok $r.ok, 'exec：子进程正常退出';
    is $r.out.trim, '3', 'exec：三行经 stdin 传给子进程';

    my $csv-in = Rakuish::Data::Stream.from("a,b\n1,2", :format<csv>)
        .exec($raku, '-e', 'say $*IN.lines.head', :format<csv>);
    is $csv-in.out.trim, 'a,b', 'exec :format<csv> 写表头';
}

# ── ④ 边界 ──────────────────────────────────────────────────────────
{
    my $bad = Result.new(:!ok, :code(127), :op<exec>, :err('没有这个命令'));
    throws-like { Rakuish::Data::Stream.from($bad) },
        X::Rakuish::CommandFailed, '失败的 Result 不能变成空流';

    my Int $n = 0;
    my $cursor = Rakuish::Data::Cursor.new(
        :columns(('v',)), :batch-size(2),
        :fetch(-> { $n < 3 ?? (%( v => $n + 1 ), $n++)[0] !! Nil }));
    my $st = Rakuish::Data::Stream.from($cursor);
    is $st.count, 3, '游标流：首次可读';
    throws-like { $st.count }, X::Rakuish::Data,
        '游标流：第二次读明确报错（不是静默空流）';

    throws-like { Rakuish::Data::Stream.from('[*]', :format<json>) },
        X::Rakuish::Data, 'json 数组里有非对象元素：报错';
}

# ── ⑤ REPL 接线 ─────────────────────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new(:color(False));

    my $r = $s.eval-line(q[stream("a\nb")]);
    ok $r.ok, 'REPL：stream(文本) 可求值';
    like $s.render($r), /'line'/, 'REPL：流直接渲染成表格';
    is $s.render($r).lines.elems, 4, 'REPL：表头 + 分隔线 + 两行';

    my $t = $s.eval-line(q[stream(ls-table()).count]);
    like $s.render($t), /'Out[' \d+ '] = ' \d+/, 'REPL：Table 也能进管道';

    my $q = $s.eval-line(q[stream("name,size\nx,10", :format<csv>).where({ .<size>.Int > 5 }).count]);
    like $s.render($q), /'= 1'/, 'REPL：CSV → where → count';
}

done-testing;
