#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Sys::Proc;
use Rakuish::REPL::Session;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;

# 44-exec-stream.t —— `!` 的流式输出与超时选项（0.90.0 / ADR-0024）
#
# 主张：**能边跑边出，也能显式关掉；默认的捕获契约在非终端下不变。**
# 断言分四组：
#   ① Proc 层的 on-out / on-err 真的在进程结束前被调用；
#   ② Session（进程内）的 stream-out：块到达、Result 不重复输出；
#   ③ `--capture` / `--timeout-ms` / `--no-timeout` 的解析与执行；
#   ④ 引擎子进程：chunk 帧到父进程，父进程打印，终帧不重放。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';
%*ENV<RAKUISH_NO_RC> = '1';

my Str $raku = $*EXECUTABLE.Str;
my Str $three = 'for 1..3 { say "L$_"; sleep 0.12 }';

# 测试里的「打印」：不写 TAP，只记块。
my class Sink {
    has @.chunks is rw;
    method print(*@a) { @!chunks.push(@a.map(*.Str).join); True }
    method say(*@a)   { @!chunks.push(@a.map(*.Str).join ~ "\n"); True }
    method put(*@a)   { @!chunks.push(@a.map(*.Str).join("\n") ~ "\n"); True }
    method flush()    { Nil }
    method nl-out()   { "\n" }
    method text()     { @!chunks.join }
}

# ── ① Proc 层：回调在结束前触发 ────────────────────────────────────
{
    my @out;
    my @err;
    my $p = Rakuish::Sys::Proc.new;
    my $r = $p.exec($raku, '-e',
        'say "O1"; note "E1"; sleep 0.15; say "O2"',
        :on-out(-> Str $t { @out.push($t) }),
        :on-err(-> Str $t { @err.push($t) }));
    ok $r.ok, 'Proc.exec 正常结束';
    ok @out.elems >= 2, 'stdout 回调收到多块（不是结束后一次性给）';
    ok @err.elems >= 1, 'stderr 回调也逐块到达';
    like $r.out, /O1/ & /O2/, '捕获的 out 仍然完整（回调不替代结果）';
}

# ── ② Session：stream-out + chunk-handler ─────────────────────────
{
    my $s = Rakuish::REPL::Session.new(:color(False));
    my @chunks;
    $s.set-stream-out(True);
    $s.chunk-handler = -> Str $ch, Str $t { @chunks.push("{$ch}:{$t}") };
    my $r = $s.eval-line("! {$raku} -e '{$three}'");
    ok $r.ok, '流式格成功';
    ok $r.streamed, 'Result 标记 streamed';
    is $r.out, '', 'streamed 时 out 清空（避免 render 重放）';
    is $r.err, '', 'streamed 时 err 清空';
    ok @chunks.elems >= 2, 'Session 收到多块';
    like @chunks.join, /L1/, '块里是第一行输出';
    is $s.render($r), '', 'render 不再输出已流过的内容';

    # 反向对照：不开启 stream-out 时仍是「收完再出」。
    my $s2 = Rakuish::REPL::Session.new(:color(False));
    my $r2 = $s2.eval-line("! {$raku} -e '{$three}'");
    ok !$r2.streamed, '默认（管道/测试）不是流式';
    like $r2.out, /L1/ & /L3/, '默认仍把输出收进 Result.out';
}

# ── ③ 选项解析与超时 ──────────────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new(:color(False));
    $s.set-stream-out(True);
    my @chunks;
    $s.chunk-handler = -> Str $ch, Str $t { @chunks.push($t) };

    my $c = $s.eval-line("! --capture {$raku} -e 'say \"C1\"'");
    ok !$c.streamed, '--capture 关闭流式';
    like $c.out, /C1/, '--capture 保留 out';
    is @chunks.elems, 0, '--capture 不产生 chunk';

    my $t = $s.eval-line("! --timeout-ms 100 {$raku} -e 'sleep 2'");
    is $t.code, 124, '--timeout-ms 到点返回 124';

    my $n = $s.eval-line("! --no-timeout {$raku} -e 'sleep 0.4'");
    is $n.code, 0, '--no-timeout 关掉默认超时';

    my $bad = $s.eval-line('! --timeout-ms nope echo hi');
    is $bad.code, 127, '非数字的超时被拒绝';
    like $bad.err, /'需要'/ , '拒绝时给明确说明';

    my $missing = $s.eval-line('! --timeout-ms');
    is $missing.code, 127, '缺少超时参数也被拒绝';

    my $fail = $s.eval-line("! {$raku} -e 'say \"before\"; exit 3'");
    ok !$fail.ok, '非零退出是失败格';
    is $fail.code, 3, '退出码原样保留（流式不影响）';
}

# ── ④ 引擎子进程：chunk 帧与终帧 ──────────────────────────────────
{
    my $c = Rakuish::Eval::Client.new(:lib('lib'.IO));
    $c.start;
    my $p = Rakuish::Eval::Proxy.new(:client($c));
    $p.set-stream-out(True);

    my $sink = Sink.new;
    my $r;
    {
        temp $*OUT = $sink;
        temp $*ERR = $sink;
        $r = $p.eval-line("! {$raku} -e '{$three}'");
    }
    ok $r.ok, '引擎流式格成功';
    ok $r.streamed, '终帧带回 streamed';
    is $r.rendered, '', '终帧 text 为空（不重放）';
    is $p.render($r), '', '流式格 render 也不 dump Result 字段（0.98.2）';
    nok $p.render($r).contains('ok:'), '流式格不出现 ok: 字段';
    like $sink.text, /L1/ & /L3/, '父进程在等待期间就打印了块';

    $p.set-stream-out(False);
    my $q = $p.eval-line("! {$raku} -e 'say \"CAP\"'");
    ok !$q.streamed, '关闭后回到捕获模式';
    like $q.out, /CAP/, '关闭后 out 正常回传';
    $c.shutdown;
}

done-testing;
