#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Kernel;
use Rakuish::Audit;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;

# 43-interrupt.t —— 求值期间的 Ctrl-C（0.85.0 / ADR-0023）
#
# 这一版要解决的不是「能不能中断」——0.83 起 SIGINT 本来就会杀死引擎、
# Proxy 本来就会重启，所以 `loop { }` 按 Ctrl-C 之后 REPL 是活的。
# 问题是**归因**：
#   · 用户看到「引擎进程已退出」，以为出故障了；
#   · 行编辑器同时记了一个 take-interrupt，把**下一格输入**吞掉。
# 所以断言分三组：归因（op/code/文案）、后续可用、不吞下一格。
#
# 这一份用 `kill -INT <测试进程>` 触发父进程自己的 handler ——
# 与真实 Ctrl-C 走的是同一条 handler 路径，但它依赖 POSIX 的 kill，
# Windows 上跑不了。真终端下的 Ctrl-C（含 Windows ConPTY）由
# tools/ctrl-c-{posix,win}.py 覆盖，两者是不同层的验收：
#   · 这一份：handler 逻辑（能不能抢到信号、归因、清标志）
#   · 那两个：真终端里的字节流（`\x03` 会不会变成 SIGINT / CTRL_C_EVENT）

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';   # 这一份不测快照恢复（t/42 负责）

my IO::Path $libdir = $*CWD.add('lib');
my Bool $posix = !$*DISTRO.is-win;

# ── ① 归因：中断不是崩溃 ─────────────────────────────────────────
if $posix {
    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $p = Rakuish::Eval::Proxy.new(:client($c));

    # 1 秒后给**测试进程自己**发 SIGINT：Client 的 handler 会接管
    # （只有在等响应时它才动手），并 kill 引擎。
    start {
        sleep 1;
        shell("kill -INT {$*PID}");
    }

    my Instant $t0 = now;
    my $r = $p.eval-line('loop { }');
    my Duration $dt = now - $t0;

    is $r.op, 'interrupted', 'op=interrupted（不是 engine-restart）';
    is $r.code, 130, 'code=130（128 + SIGINT，用户意图不是故障）';
    nok $r.ok, '中断是失败结果（这一格确实没完成）';
    ok $dt < 20, "中断及时生效（{$dt.Int}s，不是等它自己跑完）";

    my Str $text = $p.render($r);
    like $text, /'已中断当前求值'/, '文案说「已中断」';
    unlike $text, /'引擎进程已退出'/, '文案**不**说引擎退出（归因不能错）';
    like $text, /'引擎已重启'/, '文案说明引擎已重启';

    # ② 中断之后必须还能用
    my $after = $p.eval-line('say 6 * 7');
    ok $after.ok, '中断后下一格成功';
    is $after.out.trim, '42', '中断后求值结果正确';

    # ③ 不能吞掉下一格：中断的那一格不许影响后续输入
    my $third = $p.eval-line('my $z = 5');
    ok $third.ok, '再下一格仍然成功（take-interrupt 没有残留）';

    $c.shutdown;

# ── ③ 中断 + 快照：恢复得比崩溃更好 ─────────────────────────────
{
    my $snap = $*TMPDIR.add("int-snap-{$*PID}.json");
    $snap.unlink if $snap.e;
    %*ENV<RAKUISH_NO_SNAPSHOT> = '';
    %*ENV<RAKUISH_SNAPSHOT> = $snap.Str;

    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $p = Rakuish::Eval::Proxy.new(:client($c));
    $p.eval-line('my $keep = "still-here"');

    start {
        sleep 1;
        shell("kill -INT {$*PID}");
    }
    my $r = $p.eval-line('loop { }');

    like $p.render($r), /'已从快照恢复'/, '中断后从快照恢复（不是白丢状态）';
    is $p.eval-line('say $keep').out.trim, 'still-here', '中断前的变量跨重启存活';

    $c.shutdown;
    $snap.unlink if $snap.e;
    %*ENV<RAKUISH_NO_SNAPSHOT> = '1';
    %*ENV<RAKUISH_SNAPSHOT> = '';
}
}
else {
    skip 'Windows：本测试用 POSIX kill 投递信号；真控制台行为见 tools/ctrl-c-win.py', 12;
}

# ── ④ 与崩溃的区分：同一套重启，不同归因 ─────────────────────────
{
    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $p = Rakuish::Eval::Proxy.new(:client($c));

    my $dead = $p.eval-line('exit; 1');
    is $dead.op, 'engine-restart', '引擎自己崩了仍是 engine-restart';
    is $dead.code, 500, '崩溃是 500';
    like $p.render($dead), /'引擎进程已退出'/, '崩溃文案仍说引擎退出';

    $c.shutdown;
}

# ── ⑤ 异常类型本身 ──────────────────────────────────────────────
{
    my $ex = X::Rakuish::Eval::Interrupted.new(detail => 'test');
    ok $ex ~~ X::Rakuish::Eval::Interrupted, 'Interrupted 是独立异常类';
    nok $ex ~~ X::Rakuish::Eval::Dead, '不与 Dead 混用一个类';
    is $ex.message, 'test', 'message 来自 detail';
}

done-testing;
