#!/usr/bin/env raku
use lib 'lib';
use Test;

# 54-job-api.t —— TTY 后台作业 API：bg-exec / bg-jobs / fg / bg
# （0.96.0 / SPEC V-265…V-269 / ADR-0031）
#
# 主张五条：
#   ① bg-exec 立即返回、子进程自成进程组、**前台不交给它**；
#   ② bg-jobs 列出作业、状态随进程变化（running / stopped / done）；
#   ③ fg 切前台、带回退出码、结束后前台收回且作业从表移除；
#   ④ bg 只发 SIGCONT 不切前台；Ctrl-Z 停住时 fg 不卡死，返回 stopped；
#   ⑤ 失败要吵：非法 id 报错、Windows 明确降级（不假装能用）。
#
# 必须在真 controlling terminal 里测：tcsetpgrp 只对会话的控制终端有效
# （pty.openpty 的 slave 不是 ctty，TIOCGPGRP 直接 ENOTTY）。沿用 t/32
# 的驱动：Raku 写 probe、Python pty.fork 跑它、解析 PROBE 行断言。

my Bool $posix-ok = !$*DISTRO.is-win;
my Str $py = '';
if $posix-ok {
    my $probe = try {
        my $p = run('python3', '-c', 'import pty, os; print("ok")', :out, :err);
        $p.out.slurp(:close).trim
    };
    $py = ($probe // '');
}

if $posix-ok && $py eq 'ok' {
    my IO::Path $tmp = $*CWD.add('tmp');
    $tmp.mkdir unless $tmp.e;
    my Str $tag = $*PID.Str;
    my $probe  = $tmp.add("job-api-probe-{$tag}.raku");
    my $driver = $tmp.add("job-api-driver-{$tag}.py");
    my $mark   = $tmp.add("job-api-mark-{$tag}.txt");

    $probe.spurt(q:to/PROBE/);
        use Rakuish::Sys;

        my $sys = Rakuish::Sys.new(:root($*CWD), :cwd($*CWD));
        my $my-pgid = Rakuish::Sys::PosixSpawn::group-of(0);

        # ① 后台起一个进程：写标记 → 睡一小会儿 → exit 7。
        # 前台必须仍是宿主组（bg-exec 不调 tcsetpgrp）。
        my $r = $sys.bg-exec('/bin/sh', '-c',
            "printf x >> @MARK@; sleep 1; exit 7");
        my Int $id = $r.value<job>.Int;
        say "PROBE bg-ok {$r.ok.Int}";
        say "PROBE bg-id $id";
        say "PROBE bg-code {$r.code}";
        say "PROBE pgid-own {(Rakuish::Sys::PosixSpawn::group-of($r.value<pgid>.Int) == $r.value<pgid>.Int).Int}";
        say "PROBE fg-still-mine {(Rakuish::Sys::PosixSpawn::foreground-of(0) == $my-pgid).Int}";

        # ② 作业表：1 条、state=running。
        my $t = $sys.bg-jobs;
        say "PROBE jobs-elems {$t.rows.elems}";
        say "PROBE jobs-state {$t.get('state')[0]}";

        # 子进程马上写标记 → 证明它在跑（后台也能输出到文件系统）。
        sleep 0.3;
        say "PROBE mark-wrote {@MARK@.IO.e && @MARK@.IO.s > 0 ?? 1 !! 0}";

        # ③ fg 带回：切前台、等退出码 7、前台收回、表清空。
        my $fg = $sys.fg($id);
        say "PROBE fg-ok {$fg.ok.Int}";
        say "PROBE fg-code {$fg.code}";
        say "PROBE fg-state {$fg.value<state>}";
        say "PROBE fg-restored {$fg.value<fg-restored>.Int}";
        say "PROBE fg-back {(Rakuish::Sys::PosixSpawn::foreground-of(0) == $my-pgid).Int}";
        say "PROBE jobs-after {$sys.bg-jobs.rows.elems}";

        # ④ 挂起 → bg 恢复：子进程自己 SIGTSTP 停住。
        my $r2 = $sys.bg-exec('/bin/sh', '-c',
            'kill -TSTP $$; sleep 1; exit 0');
        my Int $id2 = $r2.value<job>.Int;
        sleep 0.4;
        say "PROBE stop-state {$sys.bg-jobs.get('state')[0]}";
        my $b = $sys.bg($id2);
        say "PROBE bg-ok2 {$b.ok.Int}";
        say "PROBE bg-state2 {$b.value<state>}";

        # ⑤ Ctrl-Z 时 fg 不卡死：停住的作业 fg 后应返回 stopped，
        # 且前台立刻还给宿主（不能像 0.73 那样等在那儿）。
        my $r3 = $sys.bg-exec('/bin/sh', '-c',
            'kill -TSTP $$; sleep 3; exit 0');
        my Int $id3 = $r3.value<job>.Int;
        sleep 0.4;
        my $fg2 = $sys.fg($id3);
        say "PROBE stop-fg-state {$fg2.value<state>}";
        say "PROBE stop-fg-ok {$fg2.ok.Int}";
        say "PROBE stop-fg-back {(Rakuish::Sys::PosixSpawn::foreground-of(0) == $my-pgid).Int}";

        # ⑥ 非法 id：报错，不静默成功。
        my $bad = $sys.fg(9999);
        say "PROBE bad-ok {$bad.ok.Int}";
        say "PROBE bad-code {$bad.code}";
        PROBE

    my $probe-text = $probe.slurp;
    $probe-text = $probe-text.subst('@MARK@', "'" ~ $mark.Str ~ "'", :g);
    $probe.spurt($probe-text);

    $driver.spurt(q:to/DRIVER/);
        import os, pty, sys, time, select
        args = sys.argv[1:]
        pid, fd = pty.fork()
        if pid == 0:
            os.environ['RAKUISH_NO_SNAPSHOT'] = '1'
            os.environ['RAKUISH_NO_RC'] = '1'
            os.execv(args[0], args)
        buf = b''
        deadline = time.time() + 30
        while time.time() < deadline:
            r, _, _ = select.select([fd], [], [], 0.2)
            if r:
                try: chunk = os.read(fd, 4096)
                except OSError: break
                if not chunk: break
                buf += chunk
            w = os.waitpid(pid, os.WNOHANG)
            if w[0]:
                try:
                    while True:
                        r2,_,_ = select.select([fd],[],[],0.1)
                        if not r2: break
                        c = os.read(fd, 4096)
                        if not c: break
                        buf += c
                except OSError: pass
                break
        text = buf.decode(errors='replace')
        for line in text.splitlines():
            if line.startswith('PROBE '):
                print(line)
        DRIVER

    my $raku = $*EXECUTABLE.Str;
    my $out = run('python3', $driver.Str, $raku, '-Ilib', $probe.Str,
                  :out, :err).out.slurp(:close);

    my %got;
    for $out.lines.grep(*.starts-with('PROBE ')) -> $line {
        my ($k, $v) = $line.substr(6).split(/\s+/, 2);
        %got{$k} = $v;
    }

    is %got<bg-ok>, 1, 'bg-exec：后台作业启动成功';
    is %got<bg-code>, 0, 'bg-exec：成功时 code=0';
    is %got<pgid-own>, 1, 'bg-exec：子进程自成进程组';
    is %got<fg-still-mine>, 1, 'bg-exec：前台没有交给后台作业';
    is %got<jobs-elems>, 1, 'bg-jobs：列出后台作业';
    is %got<jobs-state>, 'running', 'bg-jobs：运行中状态正确';
    is %got<mark-wrote>, 1, 'bg-exec：子进程在后台真的跑了（写了标记）';
    is %got<fg-ok>, 1, 'fg：带回作业成功（退出码非 0 也算成功带回）';
    is %got<fg-code>, 7, 'fg：带回子进程的退出码 7';
    is %got<fg-state>, 'exited', 'fg：状态为 exited';
    is %got<fg-restored>, 1, 'fg：前台已归还宿主';
    is %got<fg-back>, 1, 'fg：宿主重新拿回终端前台';
    is %got<jobs-after>, 0, 'fg：结束后作业从表中移除';
    is %got<stop-state>, 'stopped', 'bg-jobs：Ctrl-Z 停住的作业显示 stopped';
    is %got<bg-ok2>, 1, 'bg：让挂起的作业在后台继续';
    is %got<bg-state2>, 'running', 'bg：状态改回 running';
    is %got<stop-fg-state>, 'stopped', 'fg：挂起作业带回时返回 stopped（不卡死）';
    is %got<stop-fg-ok>, 1, 'fg：挂起带回本身是成功操作';
    is %got<stop-fg-back>, 1, 'fg：挂起带回后前台立即归还宿主';
    is %got<bad-ok>, 0, 'fg：非法 id 报失败';
    is %got<bad-code>, 127, 'fg：非法 id code=127';

    LEAVE { try { $probe.unlink; $driver.unlink; $mark.unlink } }
}
else {
    skip '作业控制 API 需要 POSIX + 真 PTY（Windows 无前台进程组，ADR-0010 §3）', 21;
}

done-testing;
