use lib 'lib';
use Test;

# 61-junction.t —— junction 值的结果契约（0.101.1 / V-287）
#
# 真机审计发现：`1|2` 这类合法 Raku 表达式会让 Session 崩在 Result 构造处
# （`has Any $.value` 装不下 Junction），或崩在渲染层（Raku 对 junction
# 参数逐分支调用函数体，函数内检测不到 Junction）。
#
# 本文件钉住三层：
#   ① Result 能装 junction，`.raku` / `value-defined` 正确；
#   ② 三格式渲染 + `display` 都不崩，且展示为 `any(...)`；
#   ③ Session 求值 + `_` / `Out[n]` 保留 junction 语义。

use Rakuish::Result;

# ── 1. Result 层 ─────────────────────────────────────────────────────
{
    my $r = Result.new(:ok(True), :value(1|2), :op<eval>);
    ok $r.ok, 'Result 能构造（不再抛 Type check）';
    is $r.value.raku, 'any(1, 2)', 'value 保留 junction';
    ok $r.value-defined, 'value-defined 对 junction 为 True';
}
{
    my $r = Result.new(:ok(True), :value(1|2|3));
    ok $r.value-defined, '多分支 junction 也有值';
}

# ── 2. 渲染层（三种格式都不崩）──────────────────────────────────────
{
    my $r = Result.new(:ok(True), :value(1|2), :op<eval>);
    my $text = $r.render('text');
    like $text, / 'value:' \s+ 'any(1, 2)' /, 'text 渲染 junction 为 any(1, 2)';
    like $r.text, / 'any(1, 2)' /, 'text 缓存一致';

    my $json = $r.render('json');
    like $json, / '"value":"any(1, 2)"' /, 'json 把 junction 转成字符串';

    my $md = $r.render('markdown');
    like $md, / 'any(1, 2)' /, 'markdown 渲染 junction';

    my %h = $r.to-hash;
    is %h<value>, 'any(1, 2)', 'to-hash 的 value 是字符串';
}
{
    my $r = Result.new(:ok(True), :value(all(1, 2)));
    like $r.render('text'), / 'all(1, 2)' /, 'all() 也能渲染';
}
{
    # display 是内置命令的展示口径（.out 优先 → .err → 简单 value → text），
    # 它的标量分支用 `.defined` + `~~ Str|Int|...`，对 junction 会 autothread 后
    # 在 `my Str $v` 处抛 Type check——必须在那之前单列一条 junction 出口。
    my $r = Result.new(:ok(True), :value(1|2), :op<eval>);
    is $r.display, 'any(1, 2)', 'display 对 junction 不崩、给 .raku';
    is Result.new(:ok(True), :value('x')).display, 'x',
       'display 的标量路径不变';
    is Result.new(:ok(True), :out("hi\n")).display, 'hi',
       'display 仍优先用 stdout';
}

# ── 3. Session 层（求值与结果引用）──────────────────────────────────
use Rakuish::REPL::Session;
{
    my $s = Rakuish::REPL::Session.new;
    my $r = $s.eval-line('1|2');
    ok $r.ok, 'Session 求值 1|2 成功';
    is $r.value.raku, 'any(1, 2)', '求值结果保留 junction';
    like $s.render($r), / 'any(1, 2)' /, 'Session.render 不崩';

    my $u = $s.eval-line('_');
    is $u.value.raku, 'any(1, 2)', '`_` 保留 junction（语义不降级）';

    my $o = $s.eval-line('Out[1]');
    is $o.value.raku, 'any(1, 2)', 'Out[1] 保留 junction';
}

# ── 4. 非 junction 的常规渲染不受影响（回归）────────────────────────
{
    my $r = Result.new(:ok(True), :value(42));
    is $r.render('text'), "ok: true\ncode: 0\nvalue:\n42",
       '普通标量渲染一字未变';
    nok $r.value-defined ?? False !! True, '42 有值';
}

done-testing;
