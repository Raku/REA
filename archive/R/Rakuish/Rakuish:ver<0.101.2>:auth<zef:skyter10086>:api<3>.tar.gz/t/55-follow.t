#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Sys;

# 55-follow.t —— tail -f 的跟随循环（0.99.0 / ADR-0033）
#
# 主张五条：
#   ① 先打末 N 行；-n 0 只看新增；
#   ② 只吐完整行，半行进缓冲补齐再吐（含跨 poll 的多字节 UTF-8）；
#   ③ 文件变小（截断 / 轮转替换）→ 从 0 重读新内容；
#   ④ 文件消失 → 等待，重现后按新文件处理；
#   ⑤ should-stop 停止 → code=130、value 形态正确；错误路径如实抛。
#
# 用 should-stop 回调当**情景驱动器**：它每轮询一次就被调用一次，
# 在里面改文件、翻阶段、最后返回 True —— 全部确定性，不靠 sleep 赛跑。

my IO::Path $base = $*TMPDIR.IO.add("rakuish-follow-{$*PID}");
$base.mkdir;
LEAVE { try { $base.dir>>.unlink; $base.rmdir } }

sub fresh(Str $name --> IO::Path) {
    my $f = $base.add($name);
    $f.unlink if $f.e;
    $f
}

# 吞掉默认 emit 的 $*OUT 直写（job-op 不接 :emit 的用例需要）
class Sink {
    method print(*@a) { True }
    method flush()    { Nil }
    method nl-out()   { "\n" }
}

# ── ① 初始末 N 行 / lines=0 ────────────────────────────────────────
{
    my $f = fresh('init.txt');
    $f.spurt("a\nb\nc\nd\n");
    my @got;
    my Int $tick = 0;
    my $r = Rakuish::Sys.new(:root($base), :cwd($base)).tail-follow(
        $f.Str, 2,
        :should-stop({ $tick++ >= 0 }),
        :emit(-> Str $t { @got.push($t) }));
    is-deeply @got.List, ("c\n", "d\n").List,
        '① 先打末 2 行（c/d），顺序保持';
    is $r.code, 130, '① 停止时 code=130';
    ok $r.value<stopped>, '① value<stopped> 为真';
    is $r.value<lines>, 2, '① value<lines> 计数准确';
    like $r.out, /'已停止跟随'/, '① out 给一行停止摘要（不重复行内容）';
}

{
    my $f = fresh('zero.txt');
    $f.spurt("a\nb\n");
    my @got;
    my Int $tick = 0;
    my $r = Rakuish::Sys.new(:root($base), :cwd($base)).tail-follow(
        $f.Str, 0,
        :should-stop({ $tick++ >= 0 }),
        :emit(-> Str $t { @got.push($t) }));
    is-deeply @got.List, ().List, '① lines=0 不打初始行（只看新增）';
    is $r.value<lines>, 0, '① lines=0 计数为 0';
}

# ── ② 半行缓冲 + 跨 poll 多字节 UTF-8 ─────────────────────────────
{
    my $f = fresh('partial.txt');
    $f.spurt("x\n");
    my @got;
    my Int $tick = 0;
    my $r = Rakuish::Sys.new(:root($base), :cwd($base)).tail-follow(
        $f.Str, 1,
        :should-stop(-> {
            $tick++;
            given $tick {
                when 1 { $f.spurt("c\npar", :append) }    # 整行 + 半行
                when 2 { }                                 # 半行应仍在缓冲
                when 3 { $f.spurt("tial\n", :append) }    # 补齐 → 吐 partial
                when 4 { $f.spurt(Buf.new(228, 184), :append) }  # 「中」前两字节
                when 5 { $f.spurt(Buf.new(173, 10), :append) }   # 第三字节 + \n
            }
            $tick >= 6;
        }),
        :emit(-> Str $t { @got.push($t) }));
    is-deeply @got.List, ("x\n", "c\n", "partial\n", "中\n").List,
        '② 半行补齐后才吐；跨 poll 的多字节 UTF-8 安全解码';
    is $r.value<lines>, 4, '② 计数含初始行';
}

# ── ③ 截断 / 轮转替换 → 从 0 重读 ─────────────────────────────────
{
    my $f = fresh('trunc.txt');
    $f.spurt("old1\nold2\nold3\n");
    my @got;
    my Int $tick = 0;
    my $r = Rakuish::Sys.new(:root($base), :cwd($base)).tail-follow(
        $f.Str, 2,
        :should-stop(-> {
            $tick++;
            $f.spurt("new1\nnew2\n") if $tick == 1;   # 替换（更小 → 新文件）
            $tick >= 2;
        }),
        :emit(-> Str $t { @got.push($t) }));
    is-deeply @got.List, ("old2\n", "old3\n", "new1\n", "new2\n").List,
        '③ 轮转替换后从 0 重读新内容（不卡在旧偏移）';
    is $r.value<lines>, 4, '③ 计数覆盖两段';
}

# ── ④ 消失 → 重现按新文件 ─────────────────────────────────────────
{
    my $f = fresh('gone.txt');
    $f.spurt("old\n");
    my @got;
    my Int $tick = 0;
    my $r = Rakuish::Sys.new(:root($base), :cwd($base)).tail-follow(
        $f.Str, 1,
        :should-stop(-> {
            $tick++;
            $f.unlink if $tick == 1;
            $f.spurt("reborn\n") if $tick == 3;
            $tick >= 4;
        }),
        :emit(-> Str $t { @got.push($t) }));
    is-deeply @got.List, ("old\n", "reborn\n").List,
        '④ 消失后重现按新文件处理（轮转场景）';
}

# ── ⑤ CRLF / job-op 回落 / 错误路径 ───────────────────────────────
{
    my $f = fresh('crlf.txt');
    $f.spurt("a\r\nb\r\n");
    my @got;
    my Int $tick = 0;
    my $r = Rakuish::Sys.new(:root($base), :cwd($base)).tail-follow(
        $f.Str, 0,
        :should-stop(-> {
            $tick++;
            $f.spurt("c\r\n", :append) if $tick == 1;
            $tick >= 2;
        }),
        :emit(-> Str $t { @got.push($t) }));
    is-deeply @got.List, ("c\n",).List, '⑤ CRLF 的行尾 \r 被剥掉';
}

{
    # job-op('tail-follow') 单进程回落：给 :should-stop 走确定性路径；
    # 不给时本地装 SIGINT tap（交互场景，这里只验结果形态）。
    temp $*OUT = Sink.new;
    my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
    my $f = fresh('op.txt');
    $f.spurt("m\n");
    my Int $tick = 0;
    my $r = $sys.job-op('tail-follow', $f.Str, 1,
        :should-stop(-> {
            $tick++;
            $f.spurt("n\n", :append) if $tick == 1;
            $tick >= 2;
        }));
    ok $r ~~ Rakuish::Result::Result, '⑤ job-op 回落返回 Result';
    is $r.op, 'tail', '⑤ op 恒为 tail';
    is $r.code, 130, '⑤ 停止码 130';
    is $r.value<lines>, 2, '⑤ job-op 路径计数正确（初始 + 新增）';
}

{
    my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
    my $missing = $base.add('no-such-file-xyz');
    my $ex;
    my $r;
    {
        CATCH { default { $ex = $_ } }
        $r = $sys.tail-follow($missing.Str, 1, :should-stop({ True }));
    }
    nok $r.defined, '⑤ 文件不存在抛异常（调用方收敛成失败 Result）';
    ok $ex.defined && $ex ~~ X::Rakuish::NotFound, '⑤ 异常类型是 NotFound';
}

{
    my $sys = Rakuish::Sys.new(:root($base), :cwd($base));
    my $f = fresh('neg.txt');
    $f.spurt("z\n");
    my $ex;
    my $r;
    {
        CATCH { default { $ex = $_ } }
        $r = $sys.tail-follow($f.Str, -1, :should-stop({ True }));
    }
    nok $r.defined, '⑤ 负行数拒绝';
    ok $ex.defined, '⑤ 负行数抛异常';
}

done-testing;
