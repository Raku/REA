#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Sys;
use Rakuish::Data::Table;
use Rakuish::Data::Stream;

# 49-merge.t —— 两条流对着看：zip / join / tee（0.94.0 / ADR-0029）
#
# 主张四条：
#   ① zip 按位置配对，默认取短的，:longest 补齐，列名冲突加后缀；
#   ② join 默认 left（与 Table.join 一致），:how 四档都真的不一样，
#      一对多出笛卡尔积，右表只物化一次；
#   ③ tee 边流边写，字节与 `.csv` / `.json` 一致；:append 不重复写表头；
#      写多少取决于下游读多少（上游 limit 就能精确写出前 N 行）；
#   ④ 失败要吵：未知 :how、缺 :on、坏格式、右表跑到 root 外都当场报错。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';
%*ENV<RAKUISH_NO_RC> = '1';

my $dir = $*TMPDIR.IO.add("rakuish-merge-{$*PID}");
$dir.mkdir unless $dir.d;
LEAVE { try { $dir.dir>>.unlink; $dir.rmdir } }

my $*RAKUISH-SYS = Rakuish::Sys.new(:root($dir), :cwd($dir));

sub s(Str $csv) { Rakuish::Data::Stream.from($csv, :format<csv>) }
sub cells($x, Str $col) {
    my $t = $x ~~ Rakuish::Data::Stream ?? $x.table !! $x;
    $t.get($col).List;
}

my $L = s("k,v\na,1\nb,2\nc,3");
my $R = s("k,w\na,X\nc,Y\nc,Z");

# ── ① zip ───────────────────────────────────────────────────────────
{
    my $z = s("k,a\n1,x\n2,y\n3,z").zip(s("k,b\n1,p\n2,q"));
    is $z.count, 2, 'zip：默认取较短的一条';
    is $z.table.columns.List, <k a k_right b>, 'zip：列名冲突时右列加 _right';
    is cells($z, 'k_right').List, ('1', '2'), 'zip：按位置配对（不是按值）';

    my $long = s("k,a\n1,x\n2,y").zip(s("k,b\n1,p"), :longest);
    is $long.count, 2, 'zip :longest：按较长的一条';
    my $short = s("k,a\n1,x\n2,y").zip(s("k,b\n1,p"));
    is $short.count, 1, 'zip：默认不补齐';

    my $t = Rakuish::Data::Table.from-rows([{ x => 10 }, { x => 20 }]);
    is cells(s("n\n1\n2").zip($t), 'x').List, (10, 20), 'zip：右表可以是 Table';

    is s("n\n1").zip(s("m\n9")).table.columns.List, <n m>,
        'zip：不冲突的列名不加后缀';
}

# ── ② join ──────────────────────────────────────────────────────────
{
    is $L.join($R, :on<k>).count, 4, 'join：默认 left（未匹配的左行保留）';
    is $L.join($R, :on<k>, :how<inner>).count, 3, 'join inner：只留匹配';
    is $L.join($R, :on<k>, :how<right>).count, 3,
        'join right：右行全保留（这里右表 3 行都匹配）';
    # a 匹配 1 条、c 匹配 2 条、b 未匹配、右表没有独有行 → 4
    is $L.join($R, :on<k>, :how<outer>).count, 4, 'join outer：两边并集';

    my $inner = $L.join($R, :on<k>, :how<inner>);
    is cells($inner, 'w').List, ('X', 'Y', 'Z'), 'join：一对多出笛卡尔积';
    is $inner.table.columns.List, <k v k_right w>, 'join：列顺序是左列 + 右列';

    # 右表独有、左表独有的行分别在 right / left 里出现
    my $Rt = s("k,w\na,X\nd,Z");
    is cells($L.join($Rt, :on<k>, :how<right>), 'k_right').List, ('a', 'd'),
        'join right：右表独有行也在结果里';
    is cells($L.join($Rt, :on<k>, :how<inner>), 'k_right').List, ('a',),
        'join inner：右表独有行不出现';

    # 左右键不同名
    my $L2 = s("id,v\na,1");
    is $L2.join(s("key,w\na,X"), :left-on<id>, :right-on<key>).count, 1,
        'join：支持 :left-on / :right-on 不同名';

    # 右表只物化一次（不是每来一条左行就重建索引）
    my Int $pulled = 0;
    my $right-once = Rakuish::Data::Stream.new(
        :make(-> { (1 .. 5).map(-> $i { $pulled++; %( k => 'a', w => $i ) }) }),
        :repeatable(False),
    );
    my $m = s("k\n" ~ ("a\n" x 20).chomp).join($right-once, :on<k>);
    is $m.count, 100, 'join：20 条左行 × 5 条右行 = 100';
    is $pulled, 5, 'join：右表只物化一次';

    # 左表保持惰性：只取一行时不应把左表跑完
    my Int $left-pulled = 0;
    my $big-left = Rakuish::Data::Stream.new(
        :make(-> { (1 .. 5000).map(-> $i { $left-pulled++; %( k => 'a' ) }) }),
    );
    # 左表没有列元数据 → 右列统一加后缀（判断不了冲突时不覆盖左值）；
    # 这里的左行只有 k，所以右列的 w 落成 w_right。
    is $big-left.join($R, :on<k>).first-row<w_right>.Str, 'X',
        'join：左表惰性，首行即可返回';
    ok $left-pulled < 50, "join：只拉了 {$left-pulled} 条左行（不是 5000）";

    throws-like { $L.join($R, :on<k>, :how<nonsense>) }, X::Rakuish::Unsupported,
        message => /'只支持 inner / left / right / outer'/, 'join：未知 :how 报错';
    throws-like { $L.join($R) }, X::Rakuish::Unsupported,
        message => /':on'/ , 'join：缺 :on 报错';

    # Table.join 与 Stream.join 用同一套规则
    my $ta = Rakuish::Data::Table.from-rows([{ k => 'a', v => 1 }, { k => 'b', v => 2 }]);
    my $tb = Rakuish::Data::Table.from-rows([{ k => 'a', w => 9 }]);
    is $ta.join($tb, :on<k>, :how<inner>).elems, 1, 'Table.join：:how<inner> 生效';
    is $ta.join($tb, :on<k>).elems, 2, 'Table.join：默认仍是 left（历史行为）';
    is $ta.join($tb, :on<k>).columns.List, <k v k_right w>,
        'Table.join 与 Stream.join：后缀与列序一致';
}

# ── ③ tee ───────────────────────────────────────────────────────────
{
    my $f = $dir.add('out.csv');
    my $n = s("k,v\na,1\nb,2").tee($f).count;
    is $n, 2, 'tee：往下游照常给行';
    is $f.slurp, s("k,v\na,1\nb,2").csv, 'tee：文件字节与 .csv 一致（含表头）';

    s("k,v\nc,3").tee($f, :append).count;
    is $f.slurp.lines.elems, 4, 'tee :append：追加（不重复写表头）';

    my $j = $dir.add('out.json');
    s("k,v\na,1").tee($j, :format<json>).count;
    is Rakuish::Data::Stream.from($j.slurp, :format<json>).count, 1,
        'tee :format<json>：写出的数组能再读回来';

    my $ln = $dir.add('out.txt');
    s("k,v\na,1\nb,2").tee($ln, :format<lines>, :column<k>).count;
    is $ln.slurp, "a\nb\n", 'tee :format<lines>：按 :column 取列值';

    # 上游 limit → tee 正常收尾，文件里只有前两行
    my $cut = $dir.add('cut.csv');
    s("n\n1\n2\n3\n4").limit(2).tee($cut).count;
    is $cut.slurp, "n\n1\n2\n", 'tee：把 limit 放上游，文件正好写到第 2 行';

    # tee 的结果是一次性的：再消费一次会报错，而不是把文件写第二遍
    my $once = s("n\n1").tee($dir.add('once.csv'));
    $once.count;
    throws-like { $once.count }, X::Rakuish::Data,
        message => /'已经读过一次'/, 'tee：结果不可重复消费';

    throws-like { s("n\n1").tee($dir.add('x.csv'), :format<yaml>) },
        X::Rakuish::Unsupported, message => /'只支持 lines'/,
        'tee：未知 :format 报错';

    throws-like { s("n\n1").tee('../escape.csv') }, X::Rakuish::Bound,
        'tee：跑到 root 外被拒绝（与会话 Sys 同一条路）';
}

# ── ④ 三条都保留会话边界 ────────────────────────────────────────────
{
    my $s = s("k\n1");
    ok $s.join(s("k\n1"), :on<k>).repeatable, 'join：两边都可重读 → 可重读';
    my $once-right = Rakuish::Data::Stream.new(
        :make(-> { %( k => 1 ) }), :repeatable(False));
    nok $s.join($once-right, :on<k>).repeatable, 'join：右表一次性 → 结果一次性';

    nok s("a\n1").tee($dir.add('r.csv')).repeatable, 'tee：写文件有副作用 → 一次性';
}

done-testing;
