use Test;

# 57-feel-complete.t —— 交互手感纯函数层（0.100.0 / ADR-0034；0.101.0 / ADR-0035）
#
# Complete：公共前缀（V-278）、子序列模糊回退（V-282）、建议后缀（V-277）、
# In/Out 引用补全纯函数（V-285）。
# Highlight.error-marks：括号失配 / 命令不存在 / 路径不存在（V-280），
# 以及 highlight-line :@marks 的段级换色 + 纯文本等价不变式。
#
# 全部纯函数（回调注入），不依赖 TTY / 引擎 / 行编辑器。
#
# ⚠ Raku 陷阱：`[ %(...) ]` 会把 Hash **展平成 Pair**（Array 字面量迭代
# Hash），marks 列表必须用标量包 Hash（[$h]）或 push 构建——曾经因此把
# 整行误染红。

use Rakuish::REPL::Complete;
use Rakuish::REPL::Highlight;

# ── 1. common-prefix（V-278）────────────────────────────────────────
is common-prefix(<open-data open-db>), 'open-d', '两词公共前缀';
is common-prefix(('ls --json ', 'ls --long ')), 'ls --', '完整替换行的公共前缀';
is common-prefix(('abc',)), 'abc', '单词公共前缀 = 自身';
is common-prefix(()), '', '空集公共前缀为空';
is common-prefix(('ab', 'cd')), '', '无公共前缀';

# ── 2. subsequence-rank（V-282）─────────────────────────────────────
ok subsequence-rank('opdt', 'open-data').defined, '子序列命中';
nok subsequence-rank('xyz', 'open-data').defined, '子序列不命中';
ok subsequence-rank('od', 'odd') < subsequence-rank('od', 'open-data'),
    '同 needle 下紧凑匹配的 rank 更小';
ok subsequence-rank('OD', 'open-data').defined, '大小写不敏感';
nok subsequence-rank('', 'x').defined, '空 needle 返回 Nil（fuzzy-words 已在前置拦截）';

# ── 3. fuzzy-words（V-282）──────────────────────────────────────────
my @c = <open-data open-db export echo>;
is-deeply fuzzy-words('op', @c).List, <open-data open-db>.List,
    '前缀命中时只给前缀候选（排序不变）';
is-deeply fuzzy-words('opdt', @c).List, ('open-data',),
    '零前缀命中 → 子序列回退';
is-deeply fuzzy-words('xyz', @c).List, (), '无命中返回空';
is-deeply fuzzy-words('', <b a>).List, <a b>.List, '空 frag 给全部（排序）';
is fuzzy-words('e', <ee ee>).elems, 1, '候选去重';

# ── 4. suggest-suffix（V-277）───────────────────────────────────────
my @hist = ('say 1', 'say "hello world"', 'ls --json');
is suggest-suffix('say', @hist, ()), ' "hello world"',
    '历史近者优先取后缀';
is suggest-suffix('ls --', @hist, ()), 'json', '历史后缀不含换行即可';
is suggest-suffix('say', @hist, ('say "x"', 'say "y"')), ' "hello world"',
    '历史优先于补全候选';
is suggest-suffix('say', (), ('say "x"',)), ' "x"', '无历史时用补全候选';
is suggest-suffix('say', (), ()), '', '无来源返回空';
is suggest-suffix('', @hist, ()), '', '空行不给建议';
is suggest-suffix('say', ("say 1\nsay 2",), ()), ' 1', '多行历史只取首行';

# ── 5. error-marks：括号（V-280）────────────────────────────────────
my @m = error-marks('say 1)', known-command => sub (Str $w --> Bool) { True });
is @m.elems, 1, '落单闭合标记 1 处';
is @m[0]<kind>, 'bracket', 'kind=bracket';
is-deeply (@m[0]<start>, @m[0]<end>).List, (5, 6).List, '落单闭合坐标';

@m = error-marks('say (1', known-command => sub (Str $w --> Bool) { True });
is @m.elems, 0, '行尾未闭合开括号是续行常态，不标';

@m = error-marks('say (]', known-command => sub (Str $w --> Bool) { True });
is @m.elems, 1, '类型失配的闭合标记';
is @m[0]<kind>, 'bracket', '失配 kind=bracket';

@m = error-marks('(say 1)', known-command => sub (Str $w --> Bool) { True });
is @m.elems, 0, '成对括号不标';

# 跨行：上一行留下的开括号被本行闭合吸收
set-continuation('if (1) {');
@m = error-marks('}', known-command => sub (Str $w --> Bool) { True });
is @m.elems, 0, '跨行闭合不误标（cont-open 吸收）';
set-continuation('');
@m = error-marks('}', known-command => sub (Str $w --> Bool) { True });
is @m.elems, 1, '无跨行上下文时落单闭合照标';

# ── 6. error-marks：命令（V-280）────────────────────────────────────
@m = error-marks('lss -l', known-command => sub (Str $w --> Bool) { False });
is @m.elems, 1, '未知命令标记';
is @m[0]<kind>, 'command', 'kind=command';
is-deeply (@m[0]<start>, @m[0]<end>).List, (0, 3).List, '命令词坐标';

@m = error-marks('ls -l', known-command => sub (Str $w --> Bool) { True });
is @m.elems, 0, '已知命令不标';

@m = error-marks('say hi', known-command => sub (Str $w --> Bool) { False });
is @m.elems, 0, 'Raku 关键字跳过命令探测';

@m = error-marks('foo(1) + 2', known-command => sub (Str $w --> Bool) { False });
is @m.elems, 0, '含元字符的 Raku 行不做命令探测';

@m = error-marks('lss "a b"', known-command => sub (Str $w --> Bool) { False });
is @m.elems, 1, '字符串里的空格不破坏 shell 形判定';

# ── 7. error-marks：路径（V-280）────────────────────────────────────
@m = error-marks('cat no/such', known-command => sub (Str $w --> Bool) { True },
                 path-exists => sub (Str $w --> Bool) { False });
is @m.elems, 1, '路径不存在标记';
is @m[0]<kind>, 'path', 'kind=path';
is-deeply (@m[0]<start>, @m[0]<end>).List, (4, 11).List, '路径 token 坐标';

@m = error-marks('cat ./a.txt', known-command => sub (Str $w --> Bool) { True },
                 path-exists => sub (Str $w --> Bool) { True });
is @m.elems, 0, '路径存在不标';

@m = error-marks('rm -rf ./x', known-command => sub (Str $w --> Bool) { True },
                 path-exists => sub (Str $w --> Bool) { False });
is @m.elems, 1, '选项后的路径形参数照标';

@m = error-marks('rm -x ./y', known-command => sub (Str $w --> Bool) { True },
                 path-exists => sub (Str $w --> Bool) { False });
is-deeply (@m[0]<start>, @m[0]<end>).List, (6, 9).List,
    '选项本身不标（-x 不是路径），只标 ./y';

@m = error-marks('./tool', known-command => sub (Str $w --> Bool) { True },
                 path-exists => sub (Str $w --> Bool) { False });
is @m[0]<kind>, 'path', '首词路径形按存在性标记';

# 默认回调 = 恒已知 / 恒存在 → 零标记
is error-marks('whatever ./x').elems, 0, '缺省回调零标记';

# ── 8. highlight-line :@marks 段级换色 + 不变式 ─────────────────────
my $mk = %(start => 0, end => 2, kind => 'command');
my $h = highlight-line('ls nope', :marks([$mk]));
ok $h.contains("\x[1B][31m"), '标记段上错误色';
ok $h.contains('nope'), '未标记段保留';

sub strip-ansi(Str $s --> Str) {
    $s.subst(:g, / <[ \e ]> '[' <[ 0..9 ; ]>* 'm' /, '')
}
is strip-ansi($h), 'ls nope', '不变式：strip-ansi(highlight-line(:marks)) eq 原文';

my $mk2 = %(start => 3, end => 5, kind => 'command');
is strip-ansi(highlight-line('ab cd ef', :marks([$mk2]))), 'ab cd ef',
    '中间段标记也不破坏不变式';
is strip-ansi(highlight-line('ab cd ef')), 'ab cd ef',
    '无标记不变式成立（回归）';

# 多标记
my $m1 = %(start => 0, end => 2, kind => 'command');
my $m2 = %(start => 6, end => 7, kind => 'bracket');
is strip-ansi(highlight-line('lss x )', :marks([$m1, $m2]))), 'lss x )',
    '多标记不变式成立';

# ── In[n] / Out[n] 引用补全（V-285 / ADR-0035）───────────────────────
{
    is in-out-completions('Out[', 5, 3).List.raku,
       ('Out[1]', 'Out[2]', 'Out[3]').List.raku,
       'Out[ 后列出全部编号（完整替换行）';
    is in-out-completions('In[2', 4, 5).List.raku, ('In[2]',).List.raku,
       'In[2 只补以 2 开头的编号';
    is in-out-completions('say Out[1', 9, 3).List.raku, ('say Out[1]',).List.raku,
       '带前缀时补出整行替换';
    is in-out-completions('fooOut[', 7, 3).elems, 0,
       '标识符紧跟时不误命中（fooOut[）';
    is in-out-completions('Out[', 4, 0).elems, 0,
       '无结果历史时无候选';
    is in-out-completions('Out[', 4, 200).elems, 50,
       '候选数封顶 50';
}

done-testing;
