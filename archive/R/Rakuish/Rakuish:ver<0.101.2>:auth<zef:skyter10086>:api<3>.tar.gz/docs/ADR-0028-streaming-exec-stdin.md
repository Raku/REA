# ADR-0028：`Stream.exec` 的 stdin 要流式，不要先物化

- 状态：**Accepted**
- 版本：0.93.0
- 关联：V-250…V-254；ADR-0026（结构化管道）、ADR-0024（`!` 流式输出）、V-901（不加 shell 语法）

## 1. 问题

0.91 的 `.exec` 是这么写的：

```raku
my Str $text = do given $format { ... };   # 物化整份文本
$sys.exec($exe, |@args, :in($text));
```

它把「结构化管道」的承诺打折成了半个：

- **大流先吃内存**：`stream(big).exec('wc','-l')` 会把整份 CSV 拼成字符串再写；
  上游标着「惰性」，到了出口又全部物化。
- **无限流永远不开始**：生成器不终止 → `$text` 永远算不出来 → 子进程连第一行
  都收不到。这直接违背 V-239「惰性要么真、要么说清楚」。
- **子进程提前退出时白算**：`head -1` / `grep -q` 只读一行就走，旧实现却要
  先把整条流算完（然后写进一个已经没人读的管道）。

`!` 那侧 0.90 已经做到「边跑边出」，出口这侧却还是一次性 —— 不对称，
而且正好卡在「管道」这个卖点上。

## 2. 决策

### 2.1 `spawn` 接受生成器，而不是一段文本

`Rakuish::Sys::Proc.spawn` 新增 `:&in-chunks`（一个返回 `Iterable` 的 Callable），
与原有的 `:in`（整份写）互斥，同时给两个直接抛 `X::Rakuish::Unsupported`。

后台写入任务：

```raku
my $it = in-chunks().iterator;
loop {
    my $chunk = $it.pull-one;
    last if $chunk ~~ IterationEnd;
    ... 攒缓冲 ...
    await $proc.write($buf);          # ← 背压就在这里
}
```

- **`await` 即背压**：子进程不读，写完成的 Promise 就不 settle，生成器停在下
  一个 `pull-one` 上。不需要自己造队列 / 信号量。
- **攒到 16KB 再写**：逐行写是每行一次 await（5 万行实测 2.9s），攒块之后同样
  的量 0.45s，往返少两个数量级。
- **写完必须 flush 尾巴**：最后不足 16KB 的那一块如果漏写，子进程会静默少收
  数据 —— 0.93 开发中真的漏过（50000 行只到 49152），`t/48` 用「1024 行 × 16
  字节正好一整批 + 1015 行跨批」钉住。

### 2.2 提前关闭是正常收尾，生成器异常不是

两种「停下来」必须分开：

| 现象 | 判定 | 落点 |
|---|---|---|
| 子进程先关 stdin（`head -1` / `grep -q` / 自己崩了） | 正常 | `Result.value<in-early>` |
| 生成器自己抛（只读来源二次消费、解析半途失败） | 有问题 | `Result.value<feed-error>` |

写失败时**必须立刻停止 pull**；否则一条无限流会被白跑到底，而子进程早就走了。

`Handle.wait` 在出结果前等喂入任务收尾（`Promise.anyof(feed-task, Promise.in(2))`），
否则 `in-early` / `feed-error` 是「看运气」的 —— 进程退出那一刻写入方可能还在跑。

### 2.3 `Stream.exec` 交生成器，不交文本

四种格式各有一个 `!chunk-seq`：

- `lines`：每行一个值 + `\n`（默认列仍然是第一列，与 0.91 一致）。
- `csv` / `tsv`：表头 + 逐行；**CSV 转义复用 `Table.csv-cell` / `csv-line`**，
  不给出口写第二份引号规则（0.91 起它们就是一份实现，这里只是按行调用）。
- `json`：自己拼 `[` … `]`，每个元素单独序列化且 `:!pretty`。

`json` 的两条让步要写明：

- 紧凑而不是缩进：逐个元素 pretty 拼出来的数组是一堆错位换行；
- **键序不作承诺**：Raku 的 Hash 没有插入序（`%o<k>` 后写 `%o<v>`，`keys` 可能
  是 v,k），所以 `.json` 与 `.exec(:format<json>)` 的字节不保证相同，只有 JSON
  语义相同。

### 2.4 一次性来源要在调用点报错

V-240 说「一次性来源第二次取要抛，不能给空」。改成生成器之后有个陷阱：
`self!seq` 跑在后台线程里，抛出来只会变成 `feed-error`，子进程安静地收到空
输入 —— 正是「静默给空」。

所以 `exec` 在 spawn **之前**先 `my $rows = self!seq;`（只建 Seq，不拉数据），
把二次消费的异常留在调用点；这个 Seq 再交给 `!chunk-seq`，避免取两次。

## 3. 踩到的 Raku 坑

- **`=:= IterationEnd` 不可靠**：`IterationEnd` 是 `Mu` 实例，被标量容器包一层
  之后身份比较失效（`~~` 才是真判定）。`Engine::DuckDB` 0.7x 就记过这条，
  这次在 `Proc` 和 `Stream` 两处又各踩了一遍 —— 两个新判定都用 `~~`。
- **`for $seq -> $r` 不可用**（0.91 已记）：手写循环一律用 `.iterator` +
  `pull-one`，不依赖 `for` 对 Seq 的处理。

## 4. 边界

- 只流式**喂** stdin；stdout 仍然是「收完再给」（要实时看输出用 `!`）。
- 不支持双向同时进行（子进程要边读边写、要终端语义 → `! --tty`）。
- 喂入期间不做 `max-bytes` 截断：限制的是子进程输出，不是我们写进去的量。
- `:timeout-ms` 仍然作用于整个子进程；超时会 cancel，写管道随之 broken，
  写入方停止 —— 这条路径不额外报错。

## 5. 验收

- `t/48-exec-stdin.t`（24 断言）：20 万行只拉一万出头、四种格式字节一致、
  批次边界不丢尾巴、`in-early` / `feed-error` 分得开、一次性来源当场报错、
  未知 format 拒绝、退出码 / stderr / cwd / env 仍走会话 Sys、`:in` 与
  `:in-chunks` 互斥。
- 双平台 CI：47 文件 / 2145 断言 / `console=pass`。
