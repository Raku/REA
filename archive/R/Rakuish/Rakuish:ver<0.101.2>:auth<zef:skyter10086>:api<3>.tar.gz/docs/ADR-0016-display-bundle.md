# ADR-0016 · 展示包与格式协商（DisplayBundle）

- **日期**：2026-11-13
- **对象**：`main` @ 0.77.0 → 0.78.0
- **状态**：已实施
- **输入**：0.76 / 0.77 之后按 ADR-0013 §7 推进「人机共用内核」的显示层
- **相关**：[ADR-0013](ADR-0013-kernel-frontends.md)（Kernel / 前端契约）、
  [ADR-0011](ADR-0011-highlight-colors.md)（TTY 着色）、
  [PROPOSAL-HUMAN-AGENT-KERNEL](PROPOSAL-HUMAN-AGENT-KERNEL.md) §3
- **对应条款**：SPEC **V-184**（展示包）、**V-185**（能力矩阵）、
  **V-186**（op 通道与协议向后兼容）

## 1. 问题：缺少「内容级」这一层

现在有两层，中间是空的：

| 层 | 知道什么 | 谁用 |
|---|---|---|
| `Result` | `ok` / `code` / `value` / `out` / `err` | 所有调用方 |
| `Session.render` | **TTY 上长什么样**：颜色、`Out[n]` 标签、多列 `ls` | REPL 前端 |

中间缺的是「同一份内容，不同前端要不同格式」：终端要等宽纯文本，Markdown
前端（文档、LLM）要表格，结构化前端要行数组。0.77 之前这件事根本不存在 ——
Agent 只能拿 JSON，REPL 只能拿 ANSI 文本，两边各自想办法。

`Result.render('text'|'json'|'markdown')` 看起来像答案，但它渲染的是**整个
Result 外壳**（`ok: true / op: eval / code: 0 / value:` 加一段 JSON 块），
是诊断视图，不是展示视图。把这张表贴进文档，读者看到的是
`# Result · eval` 而不是表格本身。

## 2. 决定：内容级展示包 = 三格式 + 协商 + 如实标注

```raku
class Bundle {
    has Str $.text;         # 必有，零 ANSI
    has Str $.markdown;     # '' = 不提供
    has     @.json;         # 空 = 不提供；内容是「值本身」，不是 Result 外壳
    has     %.meta;         # kind / ok / code / op / rows / truncated
}
```

三种能力：

| 方法 | 语义 |
|---|---|
| `available` | 当前这份内容支持哪几种（`text` 永远在） |
| `pick(@accepts)` | 按客户端给的**偏好顺序**挑第一个可用的，兜底 `text` |
| `render($fmt)` | 取该格式的字符串；不可用则回退 `text`，**不抛** |

`to-hash(:$format)` 是线上表示，只有一个内容字段：

```json
{ "content": "| a | b |\n|---|---|\n| 1 | 2 |",
  "format": "markdown",
  "formats": ["text", "markdown", "json"],
  "meta": { "kind": "table", "rows": 2, "ok": true, "op": "sql_query" } }
```

**字段名是 `content` 而不是 `text`**：当 `format` 是 `markdown` 时，内容不是
纯文本；叫 `text` 会诱导客户端把它直接塞进终端。

## 3. 构建：不写第二套渲染

`bundle-from(Result)` 按内容形态分支，**能借的就借**：

| kind | 触发条件 | text | markdown | json |
|---|---|---|---|---|
| `error` | `!ok` | `err` | — | — |
| `text` | `out` 非空 | `out` | — | — |
| `table` | `value ~~ Table` | `to-text` | `to-markdown` | `rows` |
| `records` | `Positional of Hash` | 转 `Table` 再取 | 同左 | 原数组 |
| `paths` | `Positional of IO::Path` | 一行一个 | 无序列表 | 路径数组 |
| `rows` | `Positional of Str` | 一行一个 | 无序列表 | 数组 |
| `record` | `Hash` | `k=v` | 两列表格 | `[hash]` |
| `scalar` | 其它有值 | `.Str` | — | `[value]` |
| `empty` | 无值无输出 | `''` | — | — |

`records` 直接 `Table.from-rows` 再调 `to-text` / `to-markdown` ——
**表格对齐、单元格转义、截断提示只有一份实现**。这是 0.74 色板、
0.77 命令表之后同一条原则：不复制会漂移的逻辑。

`json` 里放的是内容本身（`Table.rows` / 数组），**没有** `ok`/`code`/`op`
外壳 —— 那部分是 `Result.to-hash` 的职责，重复放会把「数据」和「元数据」
搅在一起，客户端还得剥一层。

## 4. 降级必须如实

最容易被写错的一行是「拿不到 markdown 就给 text」。给 text 没问题，但
**不能顺带谎报 `format`**：

```
请求 markdown，内容只有 text 能力
→ { content: "42", format: "text", formats: ["text","json"] }
```

客户端据此知道「我收到的是纯文本」，可以决定要不要改用别的渲染。如果
`format` 回填成请求值，客户端会把纯文本当 markdown 渲染（表格错位、
`*` 被当强调），而且**没有任何错误可查**。`t/38` 专门守这条，
变异测试确认：把 `format => $picked` 改成 `format => $format` 会挂 2 条。

## 5. Agent 侧：每个回复都带 `display`

`Agent.!reply` 统一附加：

```json
{ "ok": true, "code": 0, "value": ...,
  "display": { "content": "...", "format": "text",
               "formats": ["text","markdown","json"], "meta": {...} } }
```

三条约束：

1. **附加字段，不改既有键** —— 老客户端忽略 `display` 即可，`ok`/`code`/
   `value`/`out`/`err` 语义一字未改（V-186）。
2. **复用同一个构造器**：把 `%r` 重新包成 `Result` 再走 `bundle-from`。
   Agent 与 REPL 因此不会各自漂移出一套「什么算表格」的判断。
3. **失败也要带**：`Sandbox` 的 401/403、超时 504、解析 400 都有 `display`，
   其 `kind` 为 `error`。前端不需要为「显示错误」特判协议。

请求侧加一个可选字段 `"format"`（`text` / `markdown` / `json`）；不给就是
`text`，行为与 0.77 完全一致。

## 6. op 通道（V-186）

`Kernel` 的 `kind => 'op'` 从 501 变成「**部分可用**」：

- 载荷形态固定：`payload => %(op => 'name', ...参数)`；非 Hash → `2`，
  缺 `op` → `2`，不做隐式转换。
- 本版只开 `capabilities`：它不碰文件、不起进程、不执行源码，因此不需要
  `Sys` 与 `Sandbox` 参与。
- 其余 op 仍 `501`，但错误信息写明「为什么现在不给」与「随哪个版本接」。
- `Policy.allow-ops` 生效：不在名单里 → `403`（**先于** 501 判断，
  因为「不允许」比「没实现」更准确）。

`capabilities` 同时挂在 Agent 上（`Sandbox.OPS` 新增一项），返回
格式 / kind / op / 限额 / 开关。它是 0.79 的前置：客户端先问能力，
再决定发什么请求。

## 7. 明确不做

- **`html`**：没有任何一条渲染路径能产出 HTML，不写进 `formats`。
  声明一个做不到的格式比不声明更糟。
- **`stream` / `cancel`**：要改 JSONL 分帧与请求生命周期，属协议层大改，
  随 0.79。
- **`execute` op**：V-503 不变，Agent 仍不执行任意源码。
- **把 `Session.render` 改成走 Bundle**：终端那一层要颜色、`Out[n]` 标签、
  按 `COLUMNS` 分列，这些是**装饰**不是内容；塞进 bundle 会让 bundle
  重新变成「TTY 专用」。两者的分工写在 V-184 里。

## 8. 验收

- `t/38-display.t`（91 断言）：9 种 kind 的 text/markdown/json 可用性、
  text 零 ANSI、协商顺序、未知格式回退、`format` 如实标注、
  `max-rows` 截断标记、`Kernel.bundle`/`present`、op 通道
  （capabilities / 501 / 2 / 403）、Agent 回复带 display（成功 / 失败 / 401）、
  `format=markdown` 生效、既有键不被改动。
- 既有 39 个测试文件全绿（尤其 `t/06` / `t/16` / `t/21` 的 Agent 协议断言、
  `t/08` 的 Result 渲染、`t/35` 的 Kernel 对账）。
- 双平台：Windows `prove6`、WSL `run-all.sh`、真 TTY 自检。
