# ADR-0012 · 用户层四项能力与三处一致性订正

- **日期**：2026-11-13
- **对象**：`main` @ 0.74.0 → 0.75.0
- **状态**：已实施
- **输入**：横向能力盘点（[`FEATURE-GAP-2026-11-13.md`](FEATURE-GAP-2026-11-13.md)）
  查实 3 处「文档宣称 ≠ 实际接线」+ 5 处半截能力；用户选定「P0 三处 + P1 低风险四项」
- **相关**：[ADR-0001](ADR-0001-raku-native.md)（Raku 原生与快捷键边界）、
  [ADR-0003](ADR-0003-repl-experience.md)（命令观感）、SPEC V-125 / V-127

## 1. 订正：`Ctrl-X Ctrl-E` 不提供（删宣称，不补实现）

盘点发现 `bin/rakuish --help`、`ADR-0001 §4` 都把「Ctrl-X Ctrl-E 外部编辑器」列为
既有能力，`Session.handle-key` 也真的返回 `edit-request`，但：

- `REPL::Keymap` 的 `make-cli` **从未绑定**这个键；
- 入口主循环**从未消费** `edit-request`；
- `t/05` 只断言了那个返回值 API，等于把「值存在」当成了「功能存在」。

按用户第一直觉，正确修法似乎是「把键接上」。**但撞上 V-125 硬边界**：
`repl` 对象与快捷键禁止直接读写文件、启动进程（否则会绕过 Agent 的 Sandbox）。
外部编辑器要起进程 + 读写临时文件，与该条正面冲突。

因此本版**删除宣称，不补实现**：

| 位置 | 改动 |
|---|---|
| `bin/rakuish --help` | 删掉「Ctrl-X Ctrl-E 外部编辑器」一行 |
| `REPL::Session.key-bindings` | 删掉该键（7 项 → 6 项） |
| `REPL::Session.handle-key` | 删掉 `edit-request` 分支（死代码） |
| `ADR-0001 §4` | 交互动作 4 → 3，注明「`edit` 不提供」 |
| `SPEC V-125` | 快捷键清单去掉该项，并写明订正理由 |
| `t/05` | 断言从「返回 `edit-request`」改为「该键未绑定」 |

**这条不是砍功能，是把承诺收回到能力范围内**。若将来真要做外部编辑器，
它必须走 `Sys` 里新增的受控能力 + 显式 policy，那是一个独立 ADR。

## 2. 命令选项的结构化清单（Tab 补全）

### 问题

`Shell.completions` 只做路径补全：输入 `ls --j` + Tab 会去当前目录找名为
`--j` 的文件。选项信息只存在于 `usage()` 的**自由文本**里。

### 决策

新增模块级常量 `OPTIONS`（`Shell.rakumod`），与 `COMMANDS` 同级：

```raku
my constant OPTIONS = %(
    'ls'   => [< -a -A -l -h -F -p -R -t -S -r -d -1 --json >],
    'grep' => [< -i -n -v -F -E >],
    ...
);
```

- **不解析 `usage()`**：文本格式随时会变，反推 flag 太脆；
- 只登记 Shell 薄层**真正会解析**的选项，别把「文档里提过」当「支持」；
- `--help` / `-?` 对所有命令通用，补全时统一追加；
- 触发条件：当前片段以 `-` 开头 → 不进入路径补全分支，直接返回选项候选
  「完整替换行」（与路径补全的约定一致）。

**不做**：值补全（`--color=…` 之后的枚举）、子命令补全、按菜单选择。

## 3. `doc`：对象内省（零 EVAL）

### 问题

`help <命令>` 已有，但用户手里常有 Raku 名字（`Str`、`&say`、`Rakuish::Sys`），
想看一眼签名/方法/文档。IPython 的 `?`、`obj.method?` 是这层的参照物。

### 决策

新增 `Rakuish::REPL::Introspect`（纯函数）+ `doc` 命令：

| 输入 | 行为 |
|---|---|
| 内置命令名（`doc ls`） | 走 `Shell.usage()`，权威帮助优先于元对象 |
| Raku 名字（`doc Str` / `doc &say` / `doc Rakuish::Sys`） | `::($name)` 查符号 → 类型名、`WHY`、签名（例程）、局部方法列表（截断） |
| 其它（`doc 1+1`、`doc a;rm -rf`） | 拒绝：`valid-name` 只放行标识符与 `&name` |

**零 EVAL**：只用 `::($name)` 查符号表，绝不把参数当代码求值。
因此 **看不到跨格 `my` / `our`**（它们在 `Session` 的 `LexState` 里，不在全局符号表）。
这是刻意的能力边界，写进 usage 与 SPEC。

### 踩坑记录（都写进了代码注释）

1. `::($name)` 找不到符号时有**两条路**：抛 `X::NoSuchSymbol`，或返回**延迟
   Failure**。两条都要收口，否则 Failure 会在之后的 GC 里 DESTROY，往 stderr 吐
   `unhandled Failure detected in DESTROY`（`t/34` 直接受害）。
2. **不能用 `try`**。`try { $obj = ::($name) }` 会把块值（Failure）留在返回位置，
   `$! = Nil` 和 `$_` 上的 `.Bool` 都管不到它。改用裸块 + `CATCH`，块无返回值语义，
   Failure 当场被消费。
3. **不能用 `.defined` 判断**。异常对象的 `.defined` 返回 `False`（看起来「一切正常」），
   而 `Str` 这类类型对象的 `.defined` 同样是 `False`（会被误判成「查不到」）。只信标志位。
4. `doc &say` 会被 Shell 的「未加引号元字符」闸门拦下（`&` 是 sigil），
   与 `export` / `grep` / `glob` 一样加入白名单。

## 4. 目录栈与书签

### 问题

`cd -` 只有一个 `prev-cwd`。多目录来回切换时用户只能在脑子里记。

### 决策

`@!dir-stack` + `%!bookmarks` 都挂在 `Shell`（与 `prev-cwd` 同处），因为
`Shell` 已经是「当前目录」的唯一持有者。所有改目录的入口收口到一个方法：

```raku
method !change-dir(Str $target, Str $op = 'cd' --> Result)
```

`cd` / `pushd` / `popd` / `bookmark go` 全部经过它，`prev-cwd` 只在这一处更新
——否则 `cd -` 与目录栈会各说各话。

| 命令 | 语义 |
|---|---|
| `pushd DIR` | 压栈后切换（压的是**切换前**的目录） |
| `popd` | 弹栈并切回；栈空报错 |
| `dirs` | 列出栈（`0:` 起）与当前目录（标 `(当前)`） |
| `bookmark add NAME [DIR]` / `list` / `go NAME` / `del NAME` | 会话内书签，**不落盘** |

**不做**：跨会话持久化（要落盘就得走 `Sys` + 一套配置文件版本兼容，属于独立议题）、
`cd -N` 序号跳转（栈已经能表达）。

## 5. 会话日志（`log`）

### 问题

`history` 只记输入，不记结果；`perf` 只记耗时。想把一次探索过程整段留档，
现在只能靠终端的滚动缓冲。

### 决策

`log start [路径] | stop | show | status`，状态在 `Session`：

```raku
has Bool $!log-on;  has Str $!log-path;  has Int $!log-seq;  has @!log-lines;
```

- **写入点只有一个**：入口主循环里拿到 `(输入行, Result, 渲染文本)` 的那一处
  （`bin/rakuish`），因为只有那里三者同时在手；`log-line` 内部剥掉 SGR，
  **日志恒为纯文本**（TTY 下渲染文本带颜色，直接写文件会污染）；
- 默认路径 `~/.rakuish-session.log`，`log start <路径>` 可覆盖；
- **落盘一律经 `Sys.write` / `Sys.append`**：V-125 要求所有文件操作过 `Sys`，
  Agent 的 Sandbox root 才不会被绕过。没有照抄 `!save-config` 的裸 `.spurt`
  —— 那是配置文件的历史例外，不该扩散；
- 内存里同时保留 `@!log-lines`，`log show` 不依赖文件也能看。

**明确不做**：日志重放、多会话合并、结构化格式（JSONL）。要重放得给每格
存完整 `Result`，那是 0.77 之后 `DisplayBundle` 的事。

## 6. 订正：`config` 的键不等于特性（`theme` 假示例）

README / MANUAL / `t/05` 一直拿 `config set theme dark` 当示例。但 `lib/` 全库
**没有任何地方读取 `theme`**——它是 `config` 这个通用 KV 容器里的一个死键。
后果比「没用」更糟：`t/05` 断言「存进去再读出来相等」通过，制造了「能存 = 生效」
的假绿。

处理：

- 文档示例换成**真实生效**的 `color`；
- 两处文档都补一句生效边界：只有入口真正读取的键才产生行为
  （`color` / `clock` / `timing` / `git` / `prompt-style` / `banner` / `hints` /
  `plugins` / `edit-mode` / `vi-start`）；
- `t/05` 改用中性键 `probe-key` 测「持久化」这个**机制**，不再拿具体特性名暗示因果。

## 7. 影响与验收

| 项 | 结果 |
|---|---|
| `provides` | 29 → 30（新增 `Rakuish::REPL::Introspect`） |
| 新命令 | `doc` / `pushd` / `popd` / `dirs` / `bookmark` / `log`（Shell 5 + Session 1） |
| 新回归 | `t/34-userland.t`（59 断言：P0 三处 + 四项能力 + 反向断言） |
| 反向断言 | 内省零 EVAL（`doc 1+1` / `doc a;rm -rf` 必须失败）、日志不含 ANSI、按键表只列真正绑定的键 |
| 边界不变 | `Sys` 仍是唯一系统入口；不新增 `%magic`；管道输出仍无 ANSI |

## 8. 备选方案与否决理由

| 备选 | 否决理由 |
|---|---|
| 把 `Ctrl-X Ctrl-E` 真接上（起 `$EDITOR`） | 违反 V-125「快捷键禁止启动进程」；要做得先给 `Sys` 加受控能力 + policy，属独立 ADR |
| 解析 `usage()` 文本反推 flag | 帮助文本是给人读的，格式随时会调；结构化表与帮助文本各自演进更稳 |
| `doc` 用 `EVAL` 求值参数 | 等于把任意代码执行塞进「看一眼文档」这个无副作用动作里 |
| 目录栈放进 `Session` | `cd` 的状态已经在 `Shell`；两处持有必然漂移，`cd -` 与栈会打架 |
| 日志直接用 `.spurt` 写文件 | 绕开 `Sys` 就绕开了 Sandbox root；配置文件的历史例外不该扩散到新能力 |
| 删掉 `theme` 这个键（迁移用户配置） | 没必要：`config` 是通用 KV，未识别的键留着无害；要治的是**文档误导**，不是键本身 |
