# PROBE-2026-11-17-exit-teardown-9p —— 退出后残留线程与 WSL 9p

> 状态：探针记录（环境交互现象的取证与处置），产品契约以 SPEC 为准。
> 关联：t/30 契约 5（干净退出 rc=0）、bin/rakuish 的 `arm-linger-guard`（0.98.2）。

## 现象

`rakuish` 交互退出（`exit` / Ctrl-D）后进程偶发**不退场**：

- t/30-tty-exec-sigint.t 契约 5 在 WSL 连续稳定失败（`exit\n` 后 waitpid 不返回）；
- 复现对**外部输入时序极其敏感**：同一驱动只改一个轮询循环的写法
  （`while time.time()-t0 < 20` ↔ `for _ in range(100)`）就能在
  「0.04s 干净退出」与「永久挂住」之间翻转，各 3/3 稳定；
- 仅当**模块库（-Ilib）在 WSL 9p 挂载**（/mnt/c 检出）时出现；同一代码
  在 ext4 检出 0.03s 退出；cwd 在哪无关，lib 在哪决定。

## 取证结论

逐帧插桩（临时 spurt 标记）证明 rakuish 自身的收尾**全部完成**：
history 落盘 → END 块（引擎停机、终端还原）→ VM teardown → 退出码已按
`exit(N)` 记账。挂住点在进程「变 zombie」的最后一步：

- 挂住时 `/proc/PID/status`：`Threads: 1`，唯一线程 `State: D`、
  `wchan=p9_client_rpc`（WSL 9p 的 RPC，不可中断睡眠）；
- 外部 `kill -9` 后 waitpid **0.1s 内收割，且报告的退出码仍是 exit(N)
  记的 0/3/…，不是信号码** —— 说明 do_exit 记账在前，卡住的只是残留
  线程咽不下最后一口气；
- `kill -9` 前先量过：残留线程并非死锁在9p 上永不返回，只是退出窗口里
  恰好在一次 9p RPC 中；对微秒级输入时序敏感（谁在哪个窗口里发起 RPC）。

推断的机制：退出时（exit_group）若有残留线程（行编辑器的输入解析线程 /
事件线程）正处在 9p 文件 RPC 里，该线程进入不可中断睡眠，进程要等它
返回才能整体回收 —— WSL 9p 的 RPC 延迟把竞态窗口放大到稳定复现。
ext4 的文件操作不进这种长 D 状态，所以同一代码不挂。

## 尝试过且无效的处置

| 处置 | 结果 |
| ---- | ---- |
| 退出前 `set-done` + 向 /dev/tty 写唤醒字节（唤醒 read(1) 中的解析线程） | 仍挂 |
| 退出前 `sleep 0.3` 静置 | 仍挂 |
| 退出前 `nqp::force_gc()` 排空终结器 | 仍挂（GC 本身正常完成） |
| `_exit(3)`（NativeCall）绕开 VM teardown | 仍挂（残留线程问题与 teardown 无关） |

## 采用的处置（0.98.2）：linger guard

退出前起一个**看门狗子进程**（POSIX-only）：

1. `trap '' HUP`——rakuish 在 pty 测试里是会话首进程，leader 退出时内核
   给前台组发 SIGHUP，会把看门狗一起带走（实测过）；
2. `sleep 0.5` 后核验「我是否还是它的父进程」（`ps -o ppid=`）：
   - 不是 → 进程已正常回收（或被 init 收养），什么都不做；
   - 是 → `kill -9` 消解残留线程；
3. kill 后 waitpid 报告的仍是 `exit(N)` 的退出码（do_exit 记账在前，实测）。

正常路径只多一次 sh spawn（毫秒级）；挂死路径 0.5s 内收场且退出码不变。
Windows 无此现象，不挂看门狗。

## 复现（WSL，9p 检出）

t/30-tty-exec-sigint.t 契约 5 即回归用例；在修复前的二进制上稳定失败，
修复后 10/10。单变量翻转法（改驱动的退出检测循环写法）见上文，不必复现。
