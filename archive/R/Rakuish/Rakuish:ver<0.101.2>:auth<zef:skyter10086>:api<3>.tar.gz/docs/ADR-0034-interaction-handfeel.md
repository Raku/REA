# ADR-0034：交互手感层 —— 灰字建议、候选菜单、错误态高亮、模糊补全、Ctrl-R 检索

- 状态：**Accepted**
- 版本：0.100.0
- 关联：V-277…V-282；ADR-0003（行编辑器子类）、ADR-0011（高亮与
  `visible-input-field-string` 覆盖点）、ADR-0012（选项补全）、
  FEATURE-GAP-2026-11-13 A5 / P1-3 / P1-6 / P1-7、ARCH-REVIEW L5

## 1. 问题

补全 / 交互提示弱于 fish（FEATURE-GAP 已立项）：补全只有前缀匹配、
没有 autosuggestion 灰字、没有候选菜单、没有错误态高亮；另外 Ctrl-R
在**真实行编辑器里根本没绑定**（`Session.handle-key` 的 `:query` 值 API
与帮助文案宣称有，键表里却没有——又一处「宣称与现实不一致」）。
这些不是发布阻断项，但直接决定日常手感。

技术约束（ARCH-REVIEW L5 早已点名）：`HlField.visible-input-field-string`
是**单一覆盖点**，建议串与候选菜单都会挤进来；上游
`Terminal::LineEditor::CLIInput.read-input` 的 `do-complete` 是词法闭包，
**不可覆盖**；字段渲染必须维持 ADR-0011 §4.2 的宽度账本不变式。

## 2. 决策

### 2.1 渲染管线：三段式塞进同一个覆盖点

`visible-input-field-string` 内容段的产出顺序固定为：
**词法着色（Highlight）→ 语义标记（错误态，段级换色）→ 右侧灰字建议**。
建议只允许出现在内容段之后的 **padding 区**（宽度借自 padding，总宽
仍恒等于 `display-width`），光标定位仍由父类按 buffer 几何独立计算——
与「内容之后追加零宽转义」是同一账本。前置任何可见字符（如鱼式
`(rsearch)` 前缀）会破坏 `left-mark-width + scroll-to-insert-width`
的光标数学，**明确不做**。

### 2.2 autosuggestion（P1-7 / V-277）

- 来源：**历史**（最近一条以当前行为前缀的记录，多行记录只取首行）。
  补全候选 / 路径建议**本期不做**——建议是每键重算的热路径，补全候选
  可能触发目录扫描 / 引擎元数据查询（SqlComplete），留待后续（§4）。
  空行不给建议。
- 显示：内容段右侧灰字（`%CLR<gray>`），宽度截断进 padding 区；
  仅在光标在行尾、非掩码输入、高亮开启时出现。
- 接受：`CursorRight` / `Ctrl-F` = 整句接受（`edit-accept-suggestion`，
  无建议或不在行尾时退化为 `move-char-forward`，不改既有键义）。
  逐词接受（Alt-→）留待后续（见 §4）。

### 2.3 候选菜单（P1-6 / V-279）与公共前缀（V-278）

- **公共前缀优先**：多候选共享更长前缀时，Tab 序列的第一项是公共前缀
  补全（上游 `do-complete` 按序循环，把公共前缀排在返回列表首位即可，
  不碰上游循环）。
- **菜单键 `ShiftTab`**（`complete-list`）：把候选按列排布打印在输入行
  **下方**（`\r\n` + 分栏 + `\r\n`），然后**重打 prompt** 并
  `force-pos-to-start() + refresh-string(True)` 在新行重绘输入区——
  绕开「底部滚屏后存盘光标错位」问题，等价 bash/readline 的列表行为。
  菜单超过 6 行截断为 `…(+N)`。prompt 在 `InterruptCLIInput.prompt`
  覆盖点顺手捕获；候选由 `make-cli` 捕获的 `&get-completions` 提供。
- 没有做「Tab Tab 弹菜单」：第二次 Tab 的语义在上游 `do-complete` 闭包
  里，接管它必须整体 fork `read-input`（约 200 行），否掉（§3）。

### 2.4 错误态高亮（P1-3 / V-280）

`Highlight.error-marks($text, :&known-command, :&path-exists)` 纯函数
（回调注入，默认无标记），返回 `(start, end, kind)` 区间；`highlight-line`
新增 `:@marks` 参数，与标记区间相交的**段**改用红色。三个探测器：

1. **括号不匹配**：`()` / `[]` / `{}` 栈失配（跳过字符串 / 注释），
   标记落单的括号字符。零误报，无条件启用。
2. **路径不存在**：shell 形（无未引号元字符）命令行里形如路径的参数
   （`./` `../` `~/` `/` 或含 `/`）经 `Sys.resolve`/`.e` 不存在 → 标记。
3. **命令不存在**：shell 形命令行的首词，既不在 COMMANDS / 用户层注册表 /
   Raku 关键字，也不在 PATH（会话内一次性缓存扫描）→ 标记。

(2)(3) 只在「shell 形」输入上启用（复用 Shell 的未引号元字符判定：
含 `$ @ % & ( ) [ ] { } ; | < >` 的行按 Raku 表达式对待，不标）。
**残余误报**（ADR 记账）：用户上一格定义的无括号 listop 形式调用
（`foo bar`）会被 (3) 误标；彻底消除需要引擎侧名字可见性查询（跨格
`my` 只有 LexState 知道），列入后续（§4），本期接受启发式边界。
不变式：`strip-ansi(highlight-line($s, :@marks)) eq $s` 恒成立——
标记只是换色，不增删任何可见字符。

### 2.5 模糊补全回退（V-282）

前缀优先（行为与排序不变），**零前缀命中时**才做子序列回退（`opdt` →
`open-data`）。范围：Shell 命令名、SQL 表名 / 列名 / 关键字；**不做**
选项与路径的子序列（`-` / 路径的子序列噪声大于收益）。公共辅助
（`common-prefix` / `subsequence-rank` / `fuzzy-words` / `suggest-suffix`）
收进新模块 `Rakuish::REPL::Complete`，Shell 与 SqlComplete 共用。

### 2.6 Ctrl-R 历史检索（V-281）

- **订正宣称**：真实键位表补上 Ctrl-R；`key-bindings()` 文案与实际一致。
- 本期形态（bash 式循环检索，非鱼式模态）：首次 Ctrl-R 把**当前缓冲区
  内容**存为查询串，替换为「最近一条包含查询串」的历史记录；连按
  Ctrl-R 逐次走向更旧的匹配（到头回绕）；任何其它编辑动作清空查询态
  （挂在 `HlField.do-edit` 的统一入口上）。
- 鱼式**模态增量搜索**（搜索行占 prompt、逐键过滤、Ctrl-G 取消）需要
  在 `decode-keyname` 里做模态拦截 + 搜索态渲染（§2.1 前缀问题），
  实质是 fork 输入循环的前奏。**明确推迟**，与 V-155 的「不做输入中
  实时弹窗」一起在拥有输入循环的那次改造里做（§4）。

### 2.7 接线形态

Provider 全部以闭包注入 `Keymap` 的模块级槽位（`make-cli` 捕获
`&get-completions` / `&get-marks`，`prompt` 覆盖点捕获 prompt 文本，
历史取 `$cli.history`）；`HlField` 只读槽位。槽位缺省为空实现——
不接线时建议 / 标记 / 菜单自然静默，单测可注入桩。

## 3. 备选（否掉的）

- **fork `read-input` 接管 Tab / 模态搜索**：约 200 行上游循环复制，
  依赖升级即漂移（HANDOFF §10 的已知缺口会加倍），与「不叠补丁」
  相悖。菜单与检索先用 `edit-*` 动作 + decode 级最小拦截实现。
- **菜单进 `visible-input-field-string` 多行渲染**：该方法的产出被父类
  当作**单行**参与清屏 / 光标账本（`display-width` 不变式），多行渲染
  要改父类契约。
- **建议串 / 搜索态做行首可见前缀**：破坏光标数学（§2.1）。
- **命令不存在用引擎侧名字查询（本期）**：每键一次请求往返 + 协议扩展，
  本期先用启发式，把精确方案记为后续。

## 4. 后果

- 手感层五项在 0.100.0 一次落地（建议 / 菜单 / 错误态 / 模糊 / Ctrl-R），
  全部维持 ADR-0011 宽度不变式；`t/57`（纯函数）+ `t/58`（字段渲染 /
  动作）+ `t/59`（PTY 冒烟）钉住。
- `HlField` 的覆盖点从「一处着色」变成「三段管线」，仍是单方法；
  上游内核依赖面没扩大（`refresh-string` / `force-pos-to-start` /
  `buffer.replace` / `edit-*` 动作表都是既有公开机制）。
- 后续清单（不在本期）：鱼式模态增量搜索与 Tab-Tab 菜单（需要拥有
  输入循环）、逐词接受建议（Alt-→ 的键名解码未验证）、建议来源扩展
  （补全候选 / 路径——需控每键成本）、命令不存在的引擎侧精确判定、
  `In[n]`/`Out[n]` 结果引用补全。
