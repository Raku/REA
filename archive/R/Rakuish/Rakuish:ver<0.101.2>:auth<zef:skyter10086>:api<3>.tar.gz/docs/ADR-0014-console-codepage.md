# ADR-0014 · Windows 控制台码页收口（中文输入/输出）

- **日期**：2026-11-13
- **对象**：`main` @ 0.76.0 → 0.76.1
- **状态**：已实施
- **输入**：用户反馈「在 Windows 下，`ls` 后无法跟汉字」
- **相关**：[ADR-0001](ADR-0001-raku-native.md)（入口与 `Sys` 边界）、
  [ADR-0011](ADR-0011-highlight-colors.md) §4（输入行渲染）

## 1. 现象与定位

用户报告：Windows 上敲 `ls ` 之后再输入中文，字打不出来，回车也没反应。

复现路径（ConPTY 真控制台，`tools/tty-termios-win.py` 的驱动改造成探针）：

| 步骤 | 结果 |
|---|---|
| `printf 'ls 中文目录\n' \| rakuish` | ✅ 正常列出 —— 说明**命令层没问题** |
| `ls 中文目录` 直接 `-e` | ✅ 正常 —— 说明 **Shell / Sys 没问题** |
| ConPTY 里手敲 `ls 中文目录` | ❌ 只回显 `ls`，中文不出现，之后整行卡死 |
| 同环境跑最小 `$*IN.get` 循环 | ❌ 抛 `Malformed UTF-8 near byte d0` |

最后一行是决定性证据：**输入字节到得了进程，是解码失败。**

根因：中文环境的 Windows 控制台码页是 **936（GBK）**，而 Rakudo 的控制台
I/O 按 **UTF-8** 解析。「中」的 GBK 是 `D6 D0`，UTF-8 解析器看到 `D0`
（能当 3 字节序列的引导字节）就一直等后续字节 —— 于是：

- 单字节读的 `$*IN.get` 抛 `Malformed UTF-8`（`d0` 正是报错里那个字节）；
- `Terminal::LineEditor` 的 `start-parser` 是「读到解码成功为止」的循环，
  于是**永远等下去**：字不显示、回车也不生效。这就是「无法跟汉字」。

同一个码页还导致**输出**乱码：Raku 写 UTF-8，终端按 GBK 解释，
`Raku 原生命令与数据环境` 显示成 `Raku 鍘熺敓...`。

## 2. 决策

进程内把控制台码页切到 UTF-8（65001），退出时还原。

新增 `lib/Rakuish/Sys/Console.rakumod`：

| 接口 | 语义 |
|---|---|
| `console-cp()` / `console-output-cp()` | 当前码页；`0` 表示没有控制台 |
| `ensure-utf8-console(:interactive)` | 切到 65001；返回 `True` 表示「这次确实改了」 |
| `restore-console()` | 还原到进入前的值；未改动过则 no-op（幂等） |
| `describe()` | 一行状态，排障用 |

入口（`bin/rakuish`）在**所有分发之前**调用，并用 `END` 兜底还原：

```raku
my Bool $console-fixed = False;
try { $console-fixed = ensure-utf8-console(:interactive(so $*IN.t)) };
END { restore-console() if $console-fixed }
```

### 2.1 为什么必须放在「所有分发之前」

第一版把调用放进 `if @a.elems { given @a[0] {…} }` 里 —— 结果**无参数启动
（也就是正常的 REPL）根本不进那个分支**，修复等于没生效，ConPTY 复现照旧卡死。
这类「入口分支写窄了」的错误在 0.75 也出现过一次（`Ctrl-X Ctrl-E` 的值 API），
所以 `t/36` 直接把「调用位置必须在 `given @a[0]` 之前」写成静态断言。

### 2.2 为什么用 `:interactive` 硬闸门

码页是**控制台的全局状态**，同控制台的父 shell 也看得见。管道 / 脚本跑一次就把
用户的终端改成 65001 是不礼貌的（更别说中途崩溃会留下手尾）。所以只在
「stdin 是终端」时动手；非交互场景本来就走 UTF-8 管道，不需要任何调整。

### 2.3 为什么不用 `chcp`

`chcp` 要起外部进程，与 V-604 / 沙箱边界冲突，而且它改的是**整个控制台**
（包括父 shell），失败还静默。直接调 `SetConsoleCP` / `SetConsoleOutputCP`
是本进程权限内的事，能保存原值、能还原、能返回成败。

## 3. 验证

| 项 | 结果 |
|---|---|
| 进程内切换 | `before=936 → during=65001 → after=936`（`restore-console` 有效） |
| `END` 兜底 | 子进程 `exit 0` 后父进程读到 `cp=936`，没有留下手尾 |
| 非交互闸门 | `ensure-utf8-console(:interactive(False))` 返回 `False`，码页一字未变 |
| 真 ConPTY 手敲 | `ls 中文目录` → 输出 `中文目录/文件.txt`；`say "中文"` → `Bool::True` |
| 输出编码 | 加码页后 banner 与中文输出不再乱码 |
| 回归 | `t/36-console-utf8.t`（22 断言：平台闸门 / 副作用 / 入口顺序 / 管道中文） |

## 4. 边界

- **只做 Windows**：POSIX 终端本来就是 UTF-8，相关接口一律 no-op。
- **不改 `bin/rakuish-agent`**：Agent 走 JSONL 管道，没有控制台输入问题；
  若将来有交互式 Agent 前端，复用同一个模块即可。
- **不处理「非 UTF-8 的输入源」**：`LineEditor` 遇到非法字节仍会一直等
  （那是依赖内部的循环，本项目不私有化行编辑器）。改码页消除了最常见的触发条件；
  真正要根治需要上游支持，已在 HANDOFF 记为已知边界。
- **异常退出不兜底**：进程被强杀时控制台会停在 65001。判断是「留 65001 比留 936
  更安全」——65001 正是 Rakudo 期望的编码。

## 5. 备选方案

| 备选 | 否决理由 |
|---|---|
| 包装 `SetConsoleCP` 到每次读写前 | 频繁系统调用，且掩盖问题；一次切换足够 |
| 用 `chcp 65001` 起子进程 | 起进程违反 V-604 边界，且改不回来 |
| 让用户在启动前手动 `chcp 65001` | 把环境问题推给用户；且从 Windows Terminal 直接启动时没人会记得 |
| 自己接管行编辑器的字节解码 | 私有化 `Terminal::LineEditor` 的内部循环，代价远大于收益 |
