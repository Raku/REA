# ADR-0036：输入循环自研评估 —— "拥有 read-input"的成本、触发条件与决策

- 状态：**Accepted（决策 = 暂不实施，条件触发时重开）**
- 版本：0.101.0（评估基线；本文不改产品代码、不升版本）
- 关联：V-154 / V-155（不碰输入循环内部、不做输入中实时弹窗）、
  ADR-0034 §2.1 / §3 / §4（鱼式模态搜索与 Tab-Tab 菜单推迟）、
  ADR-0035（手感后续四项，剩余第五项即本文主题）、ADR-0011（宽度账本不变式）

## 1. 问题

用户问："输入循环什么意思，怎么做"。ADR-0034/0035 反复写"鱼式模态搜索
与 Tab-Tab 菜单要拥有输入循环才做得到"，但仓库里没有一处把这句话展开：
输入循环到底是什么、为什么必须"拥有"、真要做要付什么代价、什么条件下
值得做。本文补上这份决策依据。

## 2. "输入循环"的准确所指

指 `Terminal::LineEditor` 0.0.23 `RawTerminalInput.rakumod:753-922` 的
`read-input` 方法里的 `react whenever $.decoded { ... }` 事件循环（约 170 行）：
终端每个按键 → `decode-keyname` → 查 `%!keymap` → 一条硬编码的 `when`
分发链（`complete` / `history-*` / `literal-next` / `paste-start` /
`suspend` / `finish` / `abort-*` / `default → do-edit`）。

关键结构：分发链里 `when 'complete' { do-complete }` 和
`when history-* { do-history-* }` 调用的 `do-complete` / `do-history-*` 是
`read-input` **方法内部的 `my sub` 词法闭包**，持有 `$completions` /
`$completion-index` / history cursor 等私有状态。外部拿不到这些句柄，
只能通过四个可覆盖点从侧面挂钩子：

1. `decode-keyname`（改键名映射）—— 0.100/0.101 用它接 Alt-CursorRight；
2. `do-edit`（default 分支的自定义动作）—— 我们 5 个手感键全在这里；
3. `input-class`（换字段渲染类）—— `HlField` 覆盖 `visible-input-field-string`；
4. `prompt`（捕获/改写提示串）—— 菜单重画用。

**"拥有输入循环"= 把这条 `react whenever` 分发链连同它的私有状态一起
搬进自己的类，从而能改分发逻辑本身**，而非从外面挂钩子。

## 3. 为什么鱼式搜索 / Tab-Tab 菜单卡在这

两个障碍都在循环体内部，钩子够不着：

1. **Tab-Tab 弹菜单**：第一次 Tab 进 `do-complete`，它用私有的
   `$completions` / `$completion-index` 决定"第 N 次 Tab 补第几个候选"。
   第二次 Tab 该循环下一个还是弹菜单，语义完全由闭包决定；外部的 ShiftTab
   是另一个键，不是 fish 那种连按两次 Tab。要改必须重写 `do-complete`。
2. **鱼式模态增量搜索**：fish 按 Ctrl-R 后进入搜索态——prompt 变
   `(rsearch)`，其后每个键都喂给搜索器实时过滤历史，不再插入 buffer。
   这需要在 `react whenever` 里插 `if 搜索态 then 喂搜索器 else 原分发`
   的分支；且搜索前缀若放内容段会破坏 ADR-0011 的 `display-width` 光标
   数学（ADR-0034 §2.1 已记账），必须放 padding 区或独占整行。

## 4. 三条路线（对比）

| 路线 | 做法 | 收益 | 代价 |
|---|---|---|---|
| ① fork `read-input` | 复制 170 行分发链到本仓库的自研输入类 | 完全掌控每个键，鱼式搜索 / Tab-Tab 都能做 | 依赖升级即漂移；raw-mode / cursor-detect / history 生命周期全自扛 |
| ② 推上游 / 换库 | 给 Terminal::LineEditor 提 PR 加模态钩子，或改用支持鱼式的库 | 不动自己的分叉 | 依赖上游意愿、周期不可控；换库 = 重写全部键位与高亮（L5 全部重做） |
| ③ 近似体验（现状） | ShiftTab 列菜单 + bash 式 Ctrl-R 循环 + Alt-→ 逐词接受 | 零架构风险，已随 0.100/0.101 发布 | 不是 fish 的连按 Tab / 模态逐键过滤 |

**决策：维持 ③。** 鱼式项不是"发布阻断"，而 ① 动的是整个依赖面最脆弱
的一层（ADR-0034 §3 否掉的正是它）。把 ① 当普通待办补丁排期，会重演
HANDOFF §10 已记录的"子类依赖 LineEditor 内部"缺口加倍。

## 5. 若重开路线①（实施清单与门槛）

将来若"日常手感"证据足够强、决定自研输入层，按此清单做，**不许边改边加功能**：

1. **搬循环体零变化**：`read-input` 170 行原样复制进自研 `HlInput`，先跑
   现有全套键位 / 真 PTY 断言证明行为等价（含 raw-mode 进出、detect-cursor-pos、
   `replace-input-field`、`LEAVE` 清理、`unfinished-entry`）。
2. **加模态状态机**：`decode-keyname` 之后插搜索态分支——Ctrl-R 进入、
   Esc/Ctrl-G 退出、逐键喂查询串实时过滤；搜索态渲染遵守 ADR-0011 宽度账本。
3. **接管 `do-complete`**：把闭包搬进类后，把 `$completion-index` 循环状态与
   菜单渲染合流，实现"第一次 Tab 补候选、第二次 Tab 弹菜单"。
4. **双后端 + 真 PTY 回归**：t/56、t/58、t/59 扩成覆盖模态全流程；
   每次 LineEditor 升级跑一次 fork diff（`tools/` 加脚本比对上游方法体）。
5. **回退路径**：自研类构造失败仍退回原生 `CLIInput`（保持 0.70 行为 &&
   HANDOFF §10 的降级记录）。

**重开触发条件**（满足任一才立项，否则维持 ③）：
- 有连续 ≥3 个真实用户反馈 fish 式搜索 / 连按 Tab 是日常痛点；或
- Terminal::LineEditor 发布 breaking 版、我们本就不得不接管输入层；或
- 另一项必须改分发链的能力出现（届时一次自研覆盖多项，摊薄成本）。

## 6. 后果

- 本 ADR 只归档决策与触发条件，**不改产品代码、不升版本**（当前 0.101.0）。
- 鱼式模态搜索 + Tab-Tab 菜单位置不变：ADR-0034 §4 / ADR-0035 的"推迟项"，
  重开入口指向本文 §5。
- 提前锁死"当作补丁顺手做"的路径——自研必须是独立立项、独立 ADR、独立验收。
