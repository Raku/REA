# ADR-0020 · Policy 只留有执行点的字段

- **日期**：2026-11-16
- **对象**：`main` @ 0.81.0 → 0.82.0
- **状态**：已实施
- **输入**：0.81.0 缺口表里登记的「`Policy` 的 `allow-ops` / `limits` 等字段
  是 Agent 设计残留」；用户指示「拆吧」
- **相关**：[ADR-0013](ADR-0013-kernel-frontends.md)（Policy 的来源）、
  [ADR-0019](ADR-0019-local-full-privilege-shell.md)（Agent 线撤销，本 ADR 的直接前提）
- **影响条款**：V-183（前端只能收窄）保留；`capabilities.policy-fields` 内容变更

## 1. 决策

`Rakuish::Kernel::Policy` 从 **7 个字段收敛到 3 个**：

| 字段 | 0.82.0 | 理由 |
|---|---|---|
| `profile` | **保留** | 只进审计与 `describe()`，是标签不是判定 |
| `allow-source` | **保留** | Kernel 里真的拦（`execute` 的 `when 'source'` 分支） |
| `root` | **保留** | `narrow()` 真的校验包含关系、越界抛 403 |
| `allow-exec` | **删除** | 全仓库没有任何执行点读取它；`!` / `Sys.exec` 从不查 |
| `read-only` | **删除** | 没有任何执行点；`Sys` 的写操作从不查 |
| `allow-ops` | **删除** | op 通道只剩 `capabilities`，名字级白名单没有可挡的对象 |
| `limits` | **删除** | 全仓库没有任何读取者 |

同时删除 `Policy.narrow()` 里对应的四次合并，`Kernel` 的 op 分支不再做
`allow-ops` 过滤。

## 2. 判据：一个字段要么有执行点，要么不许存在

这不是「精简一下」的审美问题，是 ADR-0019 的直接推论。

ADR-0019 拒绝的是「设个牌子说禁止，其实你还是可以通过」。用这个尺子量
0.76 的 Policy，四个字段全都不合格：

- `allow-exec` 写 `False`，用户照样敲 `! rm -rf x` —— `Session` 的 `!` 分支
  只看行首是不是 `!`，不看 Policy。
- `read-only` 写 `True`，`sys.spurt(...)` 照样写盘 —— `Sys` 只有自己的
  `root` 检查，没有 Policy 参数（V-125 保证「系统操作只过 Sys」，但 Sys
  并不知道 Policy 的存在）。
- `limits` 写 `%( 'timeout-ms' => 100 )`，没有任何代码读这个哈希。

它们不是「预留接口」，是**四条会被误读为保护的措施**。误读的代价比缺字段大：
调用方（尤其是将来的自己）会以为写了 `:!allow-exec` 就安全了。

**执行点判据**（写进 SPEC V-211）：

> `Policy` 的每个字段必须在 `lib/` 里至少有一处判定语句读取它，
> 且该判定能改变 `Result`。做不到就不要加字段；需要「记录意图」时用
> `profile` 这个标签，不要用布尔开关。

## 3. 为什么不是「补上执行点」

另一条路是给 `allow-exec` / `read-only` 补上真正的检查，把牌子变成闸门。
0.81.0 已经否掉了这条路，理由在 ADR-0019 §5：

- 本地 shell 的用户就是机器的用户，`! bash` 一行就绕过去了；
- 要真的拦，必须在 OS 层（VM / 容器 / seccomp），那是独立立项；
- 半吊子的进程内闸门**只能提供虚假的安全感**，而它要污染每一条 `Sys`
  调用签名。

所以正确做法是删掉声明，而不是把声明做实。

## 4. 影响面

| 位置 | 变更 |
|---|---|
| `lib/Rakuish/Kernel.rakumod` | `Policy` 三字段；`narrow()` 只合并 `allow-source` / `root` / `profile`；op 分支去掉 `allow-ops` 过滤；`!deny` 去掉未使用的 `$req` 形参 |
| `Kernel.capabilities` | `policy-fields` = `<profile allow-source root>` |
| `bin/rakuish` | `make-kernel` 不再传 `:allow-exec` |
| `t/35-kernel.t` | 删 2 条正向断言，换 4 条 `^can` 负向断言（方法不存在，而非值为 False） |
| `t/38-display.t` | 删 `allow-ops` 收紧段，换 `policy-fields` 与 Policy 的一致性断言 |

**为什么断言用 `^can` 而不是「值为 False」**：后者在字段被重新加回收敛前的
默认值时仍然通过，等于没有护栏。`^can('allow-exec')` 断言的是「这个方法
根本不存在」，加回来就会红。

## 5. 不做什么

- **不删 `profile`**：审计账本按 profile 分栏，删了旧日志的字段就失去意义。
- **不删 op 通道**：`capabilities` 是前端自省入口（`t/38` 在用），
  它不碰文件、不起进程、不执行源码，没有理由跟着 `allow-ops` 一起删。
- **不引入新的权限字段**：要安全隔离就按 ADR-0019 §5 走 OS 级方案，
  不要在这一层继续堆布尔开关。
