# §6 判断 B 第二层验证：Rakuish 能不能真的跑在 rakupp 上

> 日期：2026-11-16 · 基线：`main` @ `36a406d`（0.80.2）→ 0.80.3
> 性质：**只读实验报告**，产品代码零改动、不改架构、不替读者下结论。
> 上游：[第一篇探针报告](PROBE-2026-11-15-persistent-engine.md) §5–§7，
> 《愿景溯源》§6 / §6.6；复现脚本见 [`tools/probe/README.md`](../tools/probe/README.md)。

## 0. 一句话

**判断 B 的「能不能」基本答完了：能，而且比预期容易；但「该不该」被两个新数据钉得更死。**

34/34 模块可加载，同一份 Rakuish 一格在 MoarVM 与 rakupp 上**六行输出逐字节一致**，
值 ABI、整程序模式、`state`/`our` 持久、宿主 IO 回调全部通。
但全套件只有 **27/42 文件通过**——失败几乎全在 `Proc::Async` / `:pty` / TTY 信号与
DB::SQLite 原生扩展；而**并发 `rk_eval` 稳定 SIGSEGV**。换引擎的成本不在
「拿回常驻解释器」，在**重做整个宿主集成层**，以及回答 §6.4 的 Agent 分叉。

## 1. 版本漂移（先说清楚，否则数据会串）

探针跑的过程中 rakupp **自动升级了**：`~/.rakupp/bin/rakupp` 与
`librakupp.so.5.8.0` 的时间戳都是 `00:30`。

| 数据 | 引擎版本 |
|---|---|
| 第一篇报告 §3 的 C ABI / NativeCall 实测 | `librakupp.so.5.6.3`（显式链接） |
| 本报告的 CLI 模块快筛、双引擎一格、全套件 | `rakupp` CLI **5.8.0**（2026-11-12） |

为排除版本错配，用 **5.8.0 重跑**了 C 探针与 Raku NativeCall 最小探针：
`42` / `101` / `rooted=7` / `plain_read=1468` / `second_live_rk_new=NULL` /
`sandbox_read` 被拒且 free 后仍被拒——**与第一篇 5.6.3 的数据逐项一致**。
下文未特别标注时，C ABI 结论对两版都成立。

## 2. 六组实测

### 2.1 模块加载：34/34

`rakupp -Ilib -e 'use <模块>; say LOADED'` 逐个独立编译单元（`tools/probe/rakupp-modules.sh`）：

```
SUMMARY|total=34|ok=34|failed=0
```

包含 `REPL::Keymap`（`Terminal::LineEditor`）、`Sys::PosixSpawn` / `Sys::Console`
（`NativeCall`）、`Data::Engine::*`、`Kernel`、`Sandbox` 等全部模块。

### 2.2 双引擎跑同一格：**逐字节一致**

`tools/probe/rakupp-cell.raku` 构造 `Session → Kernel.execute → 每格 EVAL →
stdout 捕获 → Result 渲染`，六格输入同时跑在宿主 Rakudo 与 rakupp 上：

| 输入 | MoarVM | rakupp 5.8.0 |
|---|---|---|
| `my $x = 40` | `ok=True value=40` | 同 |
| `$x + 2` | `ok=True value=42` | 同 |
| `say "CELL-SAY"` | `value=Bool::True out=CELL-SAY\n` | 同 |
| `[1,2,3].sum` / `"中文".chars` | `6` / `2` | 同 |
| 格内 `use Rakuish::Display; 42` | `42` | 同 |

**六行输出完全一致**，包括 stdout 捕获与中文字符数。第一篇 §5 第 5 条
「34 个模块能否在 rakupp 上加载」由此从「未测」升级为「加载 + 核心链路已实证」。

### 2.3 值 ABI 类型覆盖（`rakupp-integration.raku`）

| 输入 | `rk_type` | `rk_str_get` | 备注 |
|---|---|---|---|
| `42` | 2 INT | `42` | `rk_int_get` = 42 |
| `3.14` | **4 RAT** | `3.14` | Raku 字面量是 Rat，不是 RK_NUM |
| `1/3` | 4 RAT | `0.333333` | |
| `"中文"` | 5 STR | `中文` | **bytes=6**，UTF-8 正确 |
| `True` | 1 BOOL | `True` | |
| `[1,2,3]` | 6 ARRAY | `1 2 3` | `rk_elems` = 3 |
| `{a=>1,b=>2}` | 7 HASH | `a\t1\nb\t2` | `rk_elems` = 2 |
| `Nil` / `Any` | 0 ANY | 空串 | |
| `Date.new(...)` | 8 OTHER | `2026-11-16` | |
| `Buf.new(1,2,3)` | 8 OTHER | 3 字节 | |
| 30 位大整数 | 2 INT | **完整 30 位字符串** | **`rk_int_get` 饱和到 `9223372036854775807`** |

⚠ **对 `Out[n]` 渲染的直接后果**：值序列化必须走 `rk_str_get`，不能走
`rk_int_get`；否则大整数被截断成 `LLONG_MAX`。当前 `format-value` 走 `.raku`，
换引擎后要换成值 ABI 的词汇表（`RkType` 只有 9 类，`RK_OTHER` 一律 stringify）。

### 2.4 嵌入路径、`rk_run` 与跨 eval 声明

| 观测 | 结果 |
|---|---|
| `rk_eval` 内 `use lib` + 一次 `use` 四个模块 | `rc=0 USE-ALL-OK` |
| 调 `Rakuish::Audit::fingerprint("abc")` | `E16801510DB89EFD` |
| `state` 跨两次 eval | `1 → 2` ✅ |
| `our $shared` 跨两次 eval | `7 → 8` ✅ |
| `rk_run` `say` / `MAIN()` | `exit_code=0`，输出 `RUN-OK` / `MAIN-OK` |
| `rk_run` 语法错 / `exit 3` | `exit_code=1` / `3`，**不杀宿主进程** |

`rk_run` 的输出与错误按契约直接打到进程 stdout/stderr（集成探针未注册输出回调时
可见 `===SORRY!===`），这是「整程序模式」的语义，不是缺陷。

### 2.5 宿主 IO 回调：C 与 Raku 两侧都通

`tools/probe/rakupp-io.c`（C）与 `rakupp-callback.raku`（Raku NativeCall）：

```
CB|n=1|is_err=0|len=16|text=CAPTURED-STDOUT
CB|n=2|is_err=1|len=16|text=CAPTURED-STDERR
EVAL|rc=0|hits=2|value=42
INPUT|rc=0|len=15|text=hello-from-host     # rk_set_input 注入一行
RESTORE|rc=0|hits=2                        # NULL 回调恢复进程 stdout
```

**这是比替换 `$*OUT` 更干净的入口**：Rakuish 现在的 `CapturingOut` sink
可以直接换成 host 回调，`rk_set_input` 还能把一行输入喂给常驻解释器。
Raku 侧唯一坑：NativeCall 回调返回类型不能写 `--> Nil`（`Unknown type Nil used
in native call`），用 `--> int32` 恒返回 0 即可。

### 2.6 内存与并发

| 观测 | 数值 |
|---|---|
| `rk_new` 前后 RSS | 274844 → 282288 KB（**+7.4 MB**） |
| 1000 次 `rk_eval` | 310176 → 311952 KB（**+1.8 MB**） |
| `rk_free` 后 | 312264 KB（**不回落**，引擎池化/分配器行为） |
| 两个宿主线程并发 `rk_eval` | **SIGSEGV，rc=139，稳定复现两次** |

头文件「One interpreter, one thread, unless you serialise access yourself」
在实测里不是建议而是**崩溃线**。这把《愿景溯源》§6.4 的张力从「把网络输入接进
全权限常驻解释器更危险」变成了：Agent 的每连接并发模型与常驻解释器**在 ABI 层
不能共存**，除非所有请求排进一条全局串行队列（会话状态随之互相污染）。

## 3. 全套件：27/42 通过，失败高度集中

`tools/probe/rakupp-suite.sh` 用与 `run-all.sh` 相同的判据（rc + `not ok` + plan），
唯一变量换成 rakupp 5.8.0：

```
SUMMARY|files=42|pass=27|fail=15|ok_lines=1856
```

**通过**（27 个文件，覆盖纯 Raku 语义与数据/展示/治理层）：
`01` 文件 API、`08` 渲染、`09–12` REPL 显示 / Shell / Table / Engine、
`14–19` explore / UI / Agent serve / Parquet / 类型 glob / 交互体验、
`21–24` worker / CSV / SQL 补全 / 方言、`31–38` termios / job control / 着色 /
用户层 / Kernel / 码页 / 命令表 / Display、`40` 审计、`51/52` 元数据与模块加载。

**失败 15 个，归因四类**：

| 类 | 文件 | 证据 |
|---|---|---|
| `Proc::Async` / `:pty` / TTY 信号 | `03, 26, 27, 28, 29, 30, 39`，以及 `06` 尾段 | `t/29`「本机 Rakudo 的 :pty 能力探测通过」失败；`t/03` stdout 中文 / stderr 分离 / env 下传失败；`t/06` 跑到 80 个 ok 后 `exec` 的 `out` 变 `Any`，`No such method 'trim'` |
| DB::SQLite **原生扩展** | `13, 20, 25` | `DB::SQLite::Error: bad parameter or other API misuse` @ `sqlite3_open_v2` —— NativeCall 到宿主 site 库在 rakupp 下不通 |
| 未声明例程的**报告形态** | `07`（及 `05` 1 条） | `not ok 34`。**0.80.4 更正**：五类错误的消息正文逐字相同，真正的差异只有「只报一个」与 `Undeclared`→`Undefined` 用词；Rakuish 用 `do { }` 包装求值时 rakupp 只报参数位置那个。详见 [`PROBE-2026-11-16-rakupp-adaptation.md`](PROBE-2026-11-16-rakupp-adaptation.md) §3 F |
| 会话 / DSL 分词与入口细节 | `02, 04, 05, 07` 部分 | 多为上面三类的连带，未逐条做等价实现比对 |

⚠ 注意 `t/12`（DuckDB 路径）、`t/20` 里 DuckDB 用例是 **SKIP**（依赖未装），
不能把它们的 PASS 读成「原生数据库引擎全通」。

**结论**：失败不在「Raku 语义」或「Rakuish 的业务代码」，而在**宿主集成层**——
外部进程、PTY、信号、NativeCall 原生扩展、编译器错误文本。而这些恰恰是
「shell / REPL 工作台」的核心能力。所以「34 模块能加载 + 一格一致」是乐观信号，
**不等于 Rakuish 可以换引擎**：真换要重做这一层。

## 4. 回写第一篇报告 §5 的五条硬约束

| # | 第一篇的判断 | 第二层验证后 |
|---|---|---|
| 1 | V-906 未改，要推 B 须重开 + 新 ADR | **不变**（这是决策，不是技术验证能解除的） |
| 2 | 一进程一 live 解释器 + 一线程，与 Agent 并发冲突 | **钉死**：并发实测 SIGSEGV；且全套件证明 Agent serve 本身能跑，冲突点精确落在「共享一个解释器」 |
| 3 | `RkValue` 生命周期要改 `Out[n]` 存储 | **不变并更具体**：`rk_root` 可用，但大整数必须 `rk_str_get`，`RkType` 只有 9 类，`.raku` 渲染要重写 |
| 4 | 每格 EVAL → 常驻 mainline 是换底座 | **部分缓解**：双引擎一格逐字节一致，说明兼容面比预期大；但副作用重放 / 失败回滚在常驻 scope 下**仍未测** |
| 5 | 34 模块能否在 rakupp 上加载未测 | **已解除**：34/34 加载、完整一格链路跑通、全套件 27/42 |

**新增的两条**：
- 宿主 IO 回调（`rk_set_output` / `rk_set_input`）可用，`CapturingOut` 有更干净的替代，**降低**了接线成本。
- `Proc::Async` / `:pty` / DB::SQLite 原生扩展 / 错误消息分类是**新的主要成本中心**，第一篇没预见到这一面。

## 5. 明确未测

> **2026-11-16 更新（0.80.4）**：第一条已由第三层完成，见
> [`PROBE-2026-11-16-rakupp-adaptation.md`](PROBE-2026-11-16-rakupp-adaptation.md)。
> 下文原文保留以记录当时的边界。

- ~~15 个失败文件里「引擎语义差异」与「宿主环境缺失」的逐条等价实现比对
  （本报告只做归因，没做修复或适配）。~~ → **0.80.4 已做**：七类归因、四类可绕过、
  副本验证 27→30/42，理论上限 36/42。
- 常驻 mainline scope 下的**副作用重放 / 失败回滚 / `EVAL` 嵌套**语义。
- `Terminal::LineEditor` 在**真 TTY** 下的交互（双引擎一格是无 TTY 的管道式调用）。
- 长时间运行的内存增长（只测了 1000 次 eval）、JIT、`rk_install` host sub、
  多线程 host 回调可重入。
- Windows 侧 rakupp 构建；本报告全部数据来自 WSL2/Linux。
- rakupp 5.8.0 与 5.6.3 之间除 C ABI 最小路径外的差异。

## 6. 议题状态与下一步

> **2026-11-16 更新（0.80.4）**：§6 表格里的选项 ① 已完成。



**判断 B 的技术可行性已从「待验证」变成「可行，但代价清楚」**；
判断 A 的结论（第一篇 §2.3）不变。`SPEC V-906` **仍未改**，
V-607 / V-194…196 / ADR-0018 收口结论不撤回，`execute` 仍不做。

下一步选项（不排序、不推荐）：

| | 做什么 | 性质 |
|---|---|---|
| ① | 针对 15 个失败文件做**适配性探针**：确认哪些是 rakupp 可修的（如 `:pty` 能力探测、错误消息分类），哪些是必须换实现的 | 只读验证 |
| ② | 写 ADR-0019 明确「放弃 Agent 并发」或「不接常驻引擎」的二选一，再决定要不要重开 V-906 | 决策 |
| ③ | 做常驻 mainline 的**副作用/失败回滚**语义探针（补第 4 条） | 只读验证 |
| ④ | 存档，维持 0.80.x 收口状态 | 不动 |

无论哪条，§6.4 的分叉仍是第一道门：**保留 Agent / TCP，还是把常驻上下文接进来**。
第二层验证没有打开这道门，只是把门两侧的代价量清楚了。
