# 设计提案：人机共用 Shell + IPython 式数据探索

> 日期：2026-11-13 · 状态（0.80.1 校准）：**部分已实施，其余前提已变**
> 基线：0.75.0 开发中（**历史快照，勿当现状**）
>
> **0.80.1 校准**：0.76.0 已落地 `Kernel` / `Request` / `Policy`（ADR-0013），
> 0.78.0 已落地 `Display::Bundle` 与 Agent `display`（ADR-0016）；但
> **Agent 入口仍走自己的 `!dispatch`，两者未合并**（ADR-0013 仍是部分实施）。
> 更关键的是 0.79.2 的 V-607 与 0.80.0 的 ADR-0018 把「Agent 能执行什么」
> 整体收窄、`execute` 从路线图删除 —— 本文 §9 中「受限子进程跑源码」的设想
> **已明确不做**。剩下的「人机共用内核」若要继续，须先重开 ADR 讨论定位，
> 不能按本文的旧前提直接实施。决策状态见 [`ADR-INDEX.md`](ADR-INDEX.md)。
> 上游：[`ARCH-REVIEW-2026-11-13.md`](ARCH-REVIEW-2026-11-13.md)、[`FEATURE-GAP-2026-11-13.md`](FEATURE-GAP-2026-11-13.md)
>
> 回答：要做「人和 Agent 共用的 shell」+「IPython 式探索 REPL」，架构怎么改、SPEC 怎么改、要不要推翻。

---

## 0. 结论

**不需要推翻 ADR-0001，但需要一次「协议化重构」**，把现在**并列的两套入口**收敛成
**一个内核 + 多个前端**：

| 现状 | 目标 |
|---|---|
| 人走 `Session.eval-line(文本)` → `Result` → `Session.render` | 所有前端都产出 `Request` → `Kernel.execute` → `Result + DisplayBundle` |
| Agent 走 `Agent.!dispatch(op)` → `Sandbox` 白名单 | 同一 Kernel，`Policy` 决定「这个 origin 能做什么」 |
| 显示只有 `text/json/markdown` 字符串 | `DisplayBundle`（text/html/json/image）+ 前端能力协商 |
| 权限散在 `Sandbox.OPS`、`V-125`、`V-503` | 统一的 `Policy` profile（local / agent / analyst） |

**最关键的一条判断**：人机共用 ≠ 给 Agent 开 `eval`。共用的应该是**能力（capability）**，
不是**语法（source）**。Agent 默认仍只走结构化 op；「能执行任意源码」是一个**独立的、
显式开启的、跑在受限子进程里的 profile**（见 §4.1）。这条守住，`V-503` 的安全模型就不用推倒。

---

## 1. 两个目标拆成四个设计压力

| 目标 | 压力点 | 现在卡在哪 |
|---|---|---|
| **人机共用 shell** | 执行入口统一 | `eval-line` 是一串内联 `if`；Agent 是另一套 `!dispatch`，两边命令集不共享 |
| | 权限模型统一 | Agent 有 `Sandbox.OPS` 白名单 + root；TTY 默认 `all-drives`、无白名单；同一动作两种语义 |
| | 会话模型明确 | Agent 每连接一个 `Session`（V-504）；「共享同一会话」与 V-905「不做跨连接状态共享」直接冲突 |
| **IPython 式探索** | 富显示 | `Result.render-result` 只认 `text/json/markdown`，没有 MIME / display protocol |
| | 探索元能力 | `Out[n]`/`_` 有，但会话级命令不进 `history`/`@!out`；无 `store`/`who`/`timeit`/`debug` |
| | 内省深度 | `doc` 是零 EVAL 的符号表查找，看不到跨格 `my`/`class`（刻意边界） |

---

## 2. 目标架构：Kernel / Frontend / Presentation

```
TerminalFrontend ─┐
AgentFrontend ────┼─→ Request { kind, payload, origin, policy }
NotebookFrontend ─┘            │
                               ▼
                    ┌─────────────────────┐
                    │ Kernel              │
                    │  normalize → policy │
                    │  → execute → Result │
                    └─────────┬───────────┘
                              ▼
                    DisplayBundle { text, html?, json?, image?, meta? }
                     │              │                 │
                  TTY: text    Agent: json       Notebook: html/image
```

### 2.1 三个契约

| 契约 | 内容 | 谁实现 |
|---|---|---|
| `Request` | `kind`（`source` / `op`）、`payload`、`origin`（`human` / `agent` / `notebook`）、`policy`、`cwd`/`env` 快照 | 前端构造，Kernel 消费 |
| `Policy` | `allow-source`、`allow-exec`、`root`、`allowlist`、`limits`（字节/超时）、`read-only`、`audit-level` | 入口按 profile 生成；**Kernel 强制执行，前端不可覆盖** |
| `DisplayBundle` | `text`（必有，稳定、无 ANSI）、`json`（结构化值）、`html` / `image` / `meta`（可选） | Kernel 产出；前端按能力取 |

**不变式（必须写进 SPEC）**：

1. 任何前端都只能通过 `Kernel.execute(Request)` 触达 `Session`/`Sys`；
   前端**不得**直接调用 `eval-line`、`Sys.*` 或 `Agent.!dispatch`。
2. `Policy` 在 Kernel 内强制执行；前端传来的 policy 只能**收窄**，不能放宽。
3. 所有系统操作仍过 `Sys`（V-125 原样保留）；Kernel 不新增旁路。
4. `text` 形态与今天完全一致（无 ANSI、可管道），Agent 的 `json` 也保持稳定键序 ——
   新增 `html`/`image` 是**增量字段**，不改变老消费者。

### 2.2 为什么是「内核」而不是「再写一套 Agent 专用命令」

现在 `agent` 的 op 与 REPL 命令是两套名字、两套参数、两套错误码。人机共用后，
如果继续各写一套，会出现「人能 `ls`、Agent 只能 `list_dir`，行为还不一样」的漂移。
Kernel 化的收益是把**语义**收敛到一处，前端只负责翻译语法。

---

## 3. 人机能力矩阵（规约要钉住的东西）

| 能力 | 人类 TTY | Agent（默认） | Agent（`analyst` profile） | 说明 |
|---|:--:|:--:|:--:|---|
| 读文件 / 列目录 / stat | ✓ | ✓ | ✓ | 受 root 约束 |
| 写文件 / rm / cp / mv | ✓ | ✓（root 内） | 只读 | profile 收窄 |
| 外部命令 `exec` | ✓ | 默认关（V-604） | 白名单 | |
| 数据 `query` / `describe` | ✓ | ✓ | ✓（只读 Engine） | 已有 |
| 任意 Raku 源码 | ✓（本地信任） | **✗** | **✗** | V-503 保留 |
| 受限源码执行 | — | ✗ | 可选（独立子进程） | §4.1，需新 ADR |
| 显示 `html`/`image` | 降级 text | 只取 `json` | 只取 `json` | 能力协商 |
| 会话历史 / 日志 | ✓ | 每连接独立 | 每连接独立 | 不做共享会话 |

> 「共享同一会话」明确**不做**：它需要会话租约、操作序列化、输出广播、冲突解决，
> 与 V-905「不做跨连接状态共享」冲突。共用的是内核与能力，不是运行时状态。
> 若将来要做「人机协作会话」，单独立项（租约 + 事件流），不要塞进这一版。

---

## 4. 三个必须决策的难题

### 4.1 Agent 能不能执行任意源码？

| 选项 | 做法 | 代价 | 建议 |
|---|---|---|---|
| **A. 保持无 eval** | Agent 只走结构化 op；把探索高频动作做成 op（`doc`/`query`/`head`/`plot`/`store`） | 能力覆盖约 80%，但复杂分析要人写 | **默认选它** |
| **B. 受限 `execute` op** | 新 op；policy 显式开启；**独立低权限子进程**（受限 root、无网络、无 exec、CPU/内存/时间限额、`CapturingOut`） | 高：进程隔离 + 资源限制 + 审计 + 红队测试 | 可选 profile，独立 ADR + 威胁模型 |
| **C. 直接开 eval** | 复用 `!eval-raku` | 绕过 root / 白名单 / 审计 | **永不** |

**关键**：B 不是「在 Agent 进程里 `EVAL`」，而是「Agent 把源码交给一个**已经降权的子进程**」。
`Rakuish::Sys::Proc` 已经支持 argv-only spawn + cwd/env 收敛，但**没有**资源限额和
网络/子进程限制 —— 那是 OS 层能力（Windows Job Object / POSIX rlimit+seccomp），
属于新地基，必须单独立项。0.73 的进程组交接只解决「信号归属」，不等于沙箱。

### 4.2 IPython 的 `%magic` 怎么做？

**不能在 Raku 里做。** `%` 是哈希 sigil（`%h<a>` 是合法表达式），`%%` 是整除，
`:` 是 Pair / 命名参数，`/` 是除法与正则 —— sigil 空间已被占满。这正是 V-902 的根因，
不是「当时没做」。

替代设计（也是 Rakuish 的差异化优势）：

| IPython | Rakuish 设计 | 落点 |
|---|---|---|
| `%timeit f()` | `timeit 100 { f() }`（文本命令）/ `repl.timeit { }` | Shell 薄层 + Session 命令 |
| `%store x` | `store x` / `restore x`（经 `Sys` 写会话目录） | 会话命令 |
| `%who` | `who`（列 `%STATE` + `@decls` 的名字与类型） | 会话命令 |
| `%debug` | `repl.last-error` + `bt [N]` 帧浏览 | 独立子系统 |
| `%run f.raku` | `run f.raku`（已有 `load`/脚本模式） | 已有 |
| `%hist` | `history [-n N]`（已有） | 已有 |

**规则**：元能力一律「会话命令 + 对象 API」，不新造 sigil 语法。
`V-125` 的「元能力不是文本命令」需要修订为「元能力**可以**有文本命令入口，但必须
等价于对象 API，且不得引入新 sigil」——这是对既有决策的**语义放宽**，要写清楚。

### 4.3 会话级命令的旁路要不要一起修？

要。IPython 式体验的核心之一是 `In[n]`/`Out[n]` 完整可回溯。现在
`eval-line:751-832` 的会话级早返回分支不做 `index++` / `history.push` / `!remember`，
导致 `config`/`log`/`doc` 这类命令在 `repl.history` 与 `@!out` 里是断的。
做 Kernel 化时顺手抽 `!finish($line, $r)` 统一收口，否则「人机共用」后两端的
历史会各缺一块，没法对账。

---

## 5. 显示协议：从「格式字符串」到 `DisplayBundle`

现在的 `Result` 是**双通道**：`:out`（已渲染文本）+ `:value`（结构化值），
`Session.render` 按 `op` 分支决定用哪个。这对 TTY 够用，对富前端不够。

提案：

```raku
class DisplayBundle {
    has Str  $.text  is required;   # 必有；稳定、无 ANSI、可管道
    has      $.json;                # 结构化值（Agent 用）
    has Str  $.html;                # 可选；Notebook / Web
    has Str  $.image;               # 可选；data URI 或路径
    has Hash $.meta;                # mime / width / height / title
}
```

- **TTY**：只取 `text`，维持 V-116/V-176 的零 ANSI 契约。
- **Agent**：取 `json`（无则 `text`），协议字段**不变**，避免破坏 v1 消费者。
- **Notebook**：优先 `html` / `image`，缺失降级 `text`。
- 用户自定义类型：约定 `method Rakuish-display(--> Hash)`（返回 `html`/`image`/`text`），
  或 role `Rakuish::Displayable`；Kernel 在 `try` 里调用，失败降级 `text`，**绝不让显示钩子弄崩求值**。

**边界**：`DisplayBundle` 只存在于 Kernel ↔ 前端之间；`Result.render-result('text')`
的既有契约不变（V-176/V-207）。否则 `t/08` 那条「text 不掺 ANSI」会被富显示污染。

---

## 6. 规约调整清单

### 6.1 新增 ADR-0013「人机共用内核与显示协议」

必须写进 ADR 的决策：
1. Kernel / Frontend / Presentation 三层；三个契约 `Request` / `Policy` / `DisplayBundle`。
2. `Policy` profile：`local`（TTY，本地信任）/ `agent`（默认无源码、root 内、exec 关）/
   `analyst`（只读数据 + 只读 SQL + 无写）。
3. 前端只能收窄 policy，不能放宽；Kernel 是唯一执行入口。
4. 显示协议与降级规则；`text` 契约不变。
5. Agent 协议 v2：新增 `display` / `stream` / `cancel` / `describe`，保留 v1 兼容；
   `execute` 仅作为**可选实验 op**，默认关闭。
6. 明确不做：共享同一会话、`%`/`:` magic、无 policy 的源码执行。

### 6.2 现有条款的修订

| 条款 | 现在 | 建议 | 性质 |
|---|---|---|---|
| **V-125** | 元能力不是文本命令；`repl` 对象与快捷键禁止直读写 | 改成：元能力**可**有文本命令入口（等价对象 API）；**所有前端**统一过 Policy；仍禁止绕过 `Sys` | **语义放宽 + 扩展** |
| **V-503** | 没有 `eval` op | 改成：默认没有；仅 `allow-source` profile + 受限子进程时可用（若采纳选项 B）；否则保留原文 | **需 ADR + 威胁模型**，未决策前**不改** |
| **V-504** | 每会话独立 `Sys`，多会话不污染 | 保留；补一句「同会话多前端不做」 | 补充 |
| **V-176 / V-207** | `render-result(text)` 不掺 ANSI | 保留；新增 `DisplayBundle` 不改变 text 契约 | 补充 |
| **V-116** | 非 TTY 零 ANSI | 保留，扩到「所有前端的能力协商」 | 补充 |
| **V-155** | 不做输入中实时弹窗 | 若要做 autosuggestion，改这条 + ADR | 独立决策 |
| **V-606** | 审计只记 op/path/argv/结果/时间戳 | 加 `origin` / `kind` / `policy` / `display-types`；源码是否记全文需单独决策（建议默认只记 hash + 首行） | 扩展 |
| **V-905** | 不做跨连接状态共享 | **保留**，用它挡住「共享会话」的诱惑 | 不变 |
| **V-901 / V-902** | 不做 shell 语法 / `%magic` | **保留** | 不变 |

### 6.3 新增条款（建议编号 V-182…）

- `V-182` Kernel 唯一入口：前端不得直接调 `eval-line` / `Sys` / `Agent.!dispatch`。
- `V-183` Policy 单向收窄：前端传入的 policy 只能比入口生成的更严。
- `V-184` DisplayBundle：`text` 必有且无 ANSI；`html`/`image` 为可选增量；
  显示钩子异常必须降级 text。
- `V-185` 人机能力矩阵：同一动作在 `local` / `agent` / `analyst` 下的允许性，
  用「同一场景双前端跑、结果对账」的测试守住。
- `V-186` Agent 协议 v2 的兼容规则：v1 字段不动，新字段可选；`execute` 默认关闭。

---

## 7. 分阶段迁移（每步都可独立验收）

| 阶段 | 内容 | 风险 | 验收 |
|---|---|---|---|
| **0.76** | 抽 `Kernel`：`Request`/`Policy`；TTY 前端改走 `kernel.execute`；**行为零变化** | 低 | 现有 36 文件全绿 + 新增「同场景双路径结果一致」 |
| **0.77** | `DisplayBundle` + TTY 降级；`doc`/`log`/`bench`/`who` 统一命令注册；`!finish` 收口 | 中 | 富显示单测；历史/Out 完整性断言 |
| **0.78** | Agent 协议 v2（`display`/`stream`/`cancel`/`describe` + profile），**仍无 `execute`** | 中 | 协议兼容测试；审计字段 |
| **0.79** | 可选 `execute` op + 受限子进程（独立 ADR + 威胁模型 + 红队） | 高 | 逃逸测试、资源限额、审计 |
| 之后 | Notebook / Web 前端（MIME 协商） | 中 | 前端契约测试 |

**0.76 是关键**：它是纯重构，不改语义；一旦这步的回归全绿，后面才有地基。
不要跳过它直接做富显示 —— 那会把 `DisplayBundle` 硬塞进 `Session.render`，制造第四处技术债。

---

## 8. 风险与护栏

| 风险 | 表现 | 护栏 |
|---|---|---|
| **能力面漂移** | 人能 `ls`、Agent 只能 `list_dir`，行为不同 | `V-185` 双前端对账测试：同一场景跑两遍，比对 ok/code/value 摘要 |
| **Policy 被绕过** | 新前端图省事直接调 `Session.eval-line` | Kernel 是唯一入口；`Session` 构造器要求显式 policy；`t/` 加「前端不得 import Sys 直接调」的静态检查 |
| **显示污染协议** | `html` 塞进 `Result.out`，管道里出现标签 | `DisplayBundle` 只在内核边界存在；`render-result('text')` 契约不动 |
| **`execute` 变成后门** | 为了「方便」默认开启 | 默认关闭 + 独立子进程 + 审计 + 红队；不做就不写进 SPEC |
| **历史不一致** | 两端 `Out[n]` 编号对不上 | `!finish` 统一收口；日志/历史用同一序号源 |

---

## 9. 对你的问题的直接回答

> **0.80.1 注**：以下是 0.75.0 时的回答。其中「Agent 跑源码：默认不开；
> 要做就做受限子进程」已被 0.79.2 的 V-607 与 0.80.0 的 ADR-0018
> **推翻为明确不做**（`execute` 从路线图删除）；「Kernel 是唯一入口」
> 只对 REPL 三入口成立，Agent 入口未合并。其余回答仍有参考价值。

- **架构**：支持，但要做一次「并列入口 → 统一内核」的重构（0.76），不是推翻。
  ADR-0001 的 7 条决策（Raku 唯一语言、Sys 唯一入口、argv-only、结构化 op、无 magic）全部保留。
- **规约**：需要新增 ADR-0013 + V-182…186；修订 V-125（放宽元能力的文本入口）、
  V-606（审计字段）、V-176/V-207（显示增量）。V-901/902/905 **不动**。
- **IPython 式体验**：可以做，但**不要照搬 `%magic` 语法** —— Raku 的 sigil 已占满。
  用「会话命令 + 对象 API + DisplayBundle」，这是等价物，也是更干净的边界。
- **人机共用**：共用内核、能力矩阵、显示协议；**不共用运行时会话**（那是分布式问题，
  与 V-905 冲突，单独立项）。
- **Agent 跑源码**：默认不开；要做就做「受限子进程 + 独立 profile」，不要把 `EVAL`
  搬进 Agent 进程。

---

## 附：与现有代码的落点对照

| 现有 | 迁移后 |
|---|---|
| `Session.eval-line`（`Session.rakumod:751`） | `Kernel.execute` 的 `source` 分支内部；对外不再直接暴露 |
| `Shell.handle`（`Shell.rakumod:1105`） | 仍是 `source` 分支里的「命令观感」层，不动 |
| `Agent.!dispatch`（`Agent.rakumod:166`） | `Kernel.execute` 的 `op` 分支；`Sandbox` 变成 `Policy` 的一个实现 |
| `Session.render`（`:1048`） | 产出 `DisplayBundle`；TTY 前端取 `text` |
| `Result.render-result` | **不变**（text/json/markdown 契约保留） |
| `Sandbox.OPS`（`Sandbox.rakumod:47`） | 变成 `agent` profile 的 `allow-ops` |
| `t/` 36 文件 | 0.76 后全绿是硬门槛；再加双前端对账 |
