# ADR-0024 · `!` 的流式输出与超时选项

- **日期**：2026-11-16
- **对象**：`main` @ 0.89.1 → 0.90.0
- **状态**：已实施
- **输入**：用户问「和成熟 shell 比缺什么」，结论是「长任务像卡死」排第一；
  决定先做流式 + 可关超时
- **相关**：[ADR-0007](ADR-0007-tty-passthrough.md)（`tty-exec` 是另一条路）、
  [ADR-0021](ADR-0021-eval-worker.md)（引擎子进程 / 协议）、
  [ADR-0023](ADR-0023-interrupt.md)（求值中 Ctrl-C）
- **影响条款**：V-229…V-231 新增；SPEC §3.16

## 1. 问题

0.89 的 `!` 只有两种模式：

| 模式 | 行为 | 问题 |
|---|---|---|
| `! cmd` | 全量捕获，结束后一次性显示；默认 30s 超时 | 构建 / 测试 / `tail -f` 期间屏幕没有任何输出，到点被杀成 124 |
| `! --tty cmd` | 终端直通，无捕获、无超时 | 拿不到 `Result.out`、不能参与后续处理 |

shell 用户的默认预期是**边跑边出、不随意超时**。这不是「手感」问题：
一条要跑 5 分钟的测试在 30 秒时被杀，等于这条路不可用。

## 2. 事实：能力其实一直在，只是没接线

`Sys::Proc` 在 0.79.0 为 Agent 的 stream 帧加过 `Handle.wait(:&on-out, :&on-err)`，
`Proc.exec` 却从来没把这两个参数转出去。也就是说：

- 逐块消费的实现、`max-bytes` 截断、超时后 kill —— 全都在；
- 缺的只是 `exec → wait` 这一行转接，以及「块到哪里去」。

这和 `Ctrl-X Ctrl-E`（宣称有、实际没绑定）是同一类错误：**值 API 存在
不等接线完成**。

另一个约束是进程边界：0.83 之后交互式 REPL 的求值在引擎里，引擎的
stdout 是**协议管道**，它打印什么用户都看不见。所以流式不能靠「往
`$*OUT` 写」，必须把块送过协议。

## 3. 决策

三层分工，每层只回答自己知道的事：

| 层 | 知道什么 | 做什么 |
|---|---|---|
| 入口 `bin/rakuish` | 父进程的 stdout 是不是终端 | 每格下发 `stream = $*OUT.t` |
| `Session` | 这一次 `!` 要不要流、块交给谁 | `stream-out` + `chunk-handler`；`!` 解析元选项 |
| `Eval::Client` | 终端在父进程手里 | 收到 `chunk` 帧就 `print` + `flush` |

请求帧多一个 `stream` 布尔，响应帧多一个 `streamed` 布尔；中间的
`chunk` 帧复用已有的 `seq` 关联：

```
→ {"seq":7,"cmd":"eval","line":"! make","stream":true,...}
← {"seq":7,"event":"chunk","ch":"out","text":"[ 12%] ...\n"}
← {"seq":7,"event":"chunk","ch":"err","text":"warning: ...\n"}
← {"seq":7,"event":"result","ok":true,"streamed":true,"text":"",...}
```

`!` 的元选项也一并补齐（都属于分发层，子进程仍只收到 argv）：

| 写法 | 语义 |
|---|---|
| `--capture` | 强制不流式 |
| `--timeout-ms N` | 本次超时，毫秒；`0` = 不超时 |
| `--no-timeout` | `--timeout-ms 0` |
| `--` | 后续按字面 argv |

## 4. 为什么不是「默认走 tty-exec」

`tty-exec` 把三条 fd 直接交给子进程，实时性最好，但它**不捕获**输出、
没有 `Result.out`、也不能参与 Raku 侧的后续处理。shell 的管道语义是
「既能看见、又能被下一步消费」，`tty-exec` 只满足前一半。

所以两条路继续并存：

- `! cmd`：捕获 + 流式（本 ADR）；
- `! --tty cmd`：真交互程序（vim / less / 嵌套 REPL），不捕获。

## 5. 结果契约：不重放

流式最容易犯的错是「块已经给用户看了，结束时又把 `out` 打印一遍」。
`Result` 增加 `streamed`：

- 流式完成：`out` / `err` 清空，`streamed=True`，`render` 跳过 `out`；
- **启动失败**：没有任何块，`err` 必须保留（这是唯一不清空的例外）；
- 超时 / 非零退出：`code` 原样保留（124 / 真实退出码），归因不乱。

父进程不能通过「`out` 是不是空」来猜，必须读 `streamed` —— 空输出本来
就是合法结果。

## 6. 边界与不做

- 子进程的 stdout **仍是管道**，不是终端：`git` 的彩色、进度条、
  `isatty` 分支都按管道走。要 TTY 语义用 `! --tty`。
- 流式只在父进程 stdout 是终端时开启；管道 / `-e` / 脚本保持旧契约
  （测试依赖 `Result.out`，不拿它冒险）。
- 块边界是读到的字节块，不保证整行；渲染层不做行缓冲。
- 捕获仍有 `max-bytes`（1 MiB）上限；流式不放大它，也不承诺无限内存。
- **不做** shell 的管道 / 重定向（V-901），本 ADR 只改善单条命令的观感。

## 7. 验证

`t/44-exec-stream.t`（32 断言）：

- `Proc.exec` 的 on-out / on-err 在进程结束前触发，且 `out` 仍完整；
- `Session` 的 stream-out：多块、`streamed`、`out` 为空、`render` 为空；
- 反向对照：不开 stream-out 时仍是「收完再出」；
- `--capture` / `--timeout-ms` / `--no-timeout` / 缺参数 / 非数字；
- 引擎子进程：chunk 帧到父进程、终帧 `text` 为空、关闭后回到捕获模式。

真终端下的「边跑边出」由 `! --tty` 的既有探针（`t/30`/`t/32`）与
`tools/ctrl-c-*.py` 覆盖；本 ADR 不断言终端手感，只断言块确实提前到达。
