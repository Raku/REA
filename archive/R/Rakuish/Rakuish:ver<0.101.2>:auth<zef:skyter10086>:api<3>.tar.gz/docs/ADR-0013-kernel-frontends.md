# ADR-0013 · 人机共用内核与显示协议

- **日期**：2026-11-13
- **对象**：`main` @ 0.75.0 → 0.76.0（本 ADR 覆盖 0.76–0.79 的完整设计，
  每版只实现其中一段，见 §7）
- **状态**：**0.76 部分已实施**（Kernel / Request / Policy / source 通道）；
  `op` 通道、`DisplayBundle`、Agent 协议 v2 未实施
- **输入**：用户提问「如果我想做人和 Agent 共用的 shell，且同时可以做
  IPython 那样的数据探索交互 repl 呢？」
- **上游**：[`PROPOSAL-HUMAN-AGENT-KERNEL.md`](PROPOSAL-HUMAN-AGENT-KERNEL.md)、
  [`ARCH-REVIEW-2026-11-13.md`](ARCH-REVIEW-2026-11-13.md)
- **相关**：[ADR-0001](ADR-0001-raku-native.md)（Raku 原生 / Sys 唯一入口）、
  [ADR-0002](ADR-0002-agent-serve.md)（Agent 协议）、SPEC V-125 / V-503 / V-606 / V-905

## 1. 问题：两套并列入口

0.75 为止，「人」和「Agent」是两条互不相干的路径：

| | 人（TTY） | Agent |
|---|---|---|
| 入口 | `Session.eval-line(文本)` | `Agent.!dispatch(op)` |
| 权限 | 本地信任，root = 文件系统根 | `Sandbox.OPS` 白名单 + 显式 root |
| 错误 | `Result`（文本） | JSON（ok/code/err） |
| 命令集 | `ls` / `read` / `cat` … | `list_dir` / `read_file` … |

后果不是「差一个功能」，而是**同一个动作两种语义**：`ls` 与 `list_dir`
行为不同、错误码不同、越界判定不同。继续往上加能力，漂移只会更大。

## 2. 目标：一个内核 + 多个前端

```
TerminalFrontend ─┐
AgentFrontend ────┼─→ Request { kind, payload, origin, policy }
NotebookFrontend ─┘            │
                               ▼
                    ┌─────────────────────┐
                    │ Kernel              │
                    │  narrow(policy)     │
                    │  → execute → Result │
                    └─────────┬───────────┘
                              ▼
                    DisplayBundle { text, json?, html?, image?, meta? }
```

### 2.1 三个契约

| 契约 | 内容 | 谁实现 |
|---|---|---|
| `Request` | `kind`（source / op）、`payload`、`origin`、`policy`、`id` | 前端构造 |
| `Policy` | `allow-source`、`allow-exec`、`read-only`、`root`、`allow-ops`、`limits`、`profile` | 入口按 profile 生成；**Kernel 强制执行，前端只能收窄** |
| `DisplayBundle` | `text`（必有、零 ANSI）、`json`、`html` / `image` / `meta` | Kernel 产出；前端按能力取（0.77） |

### 2.2 不变式（SPEC V-182 / V-183）

1. 前端只能通过 `Kernel.execute(Request)` 触达 `Session` / `Sys`；
   不得直接调 `eval-line`、`Sys.*`、`Agent.!dispatch`。
2. `Policy` 在 Kernel 内强制执行；前端传入的策略只能**收窄**。
3. 所有系统操作仍过 `Sys`（V-125 不变），本层不新增旁路。
4. `text` 形态与今天完全一致（无 ANSI、可管道）；`json` 键序稳定。

## 3. `Policy` 的判定语义

`profile` 只是**标签**（`local` / `agent` / `analyst`），真正的判定只看字段。
理由：加新 profile 不该在 Kernel 里加 `when` 分支 —— 那是下一个漂移点。

| 字段 | 默认（local） | 收窄规则 |
|---|---|---|
| `allow-source` | True | 内外 **与** |
| `allow-exec` | True | 内外 **与** |
| `read-only` | False | 内外 **或**（任一要求只读就只读） |
| `root` | 未定义（不限制） | 内层必须落在内层之外则**拒绝**（403），否则取更窄的那个 |
| `allow-ops` | 空（不按 op 名限制） | 两边都非空时取交集 |
| `limits` | `{}` | 内层同名键覆盖外层 |

`root` 的包含判断是**词法**的（绝对化 + 分隔符边界 + Windows 小写化），
刻意不用 `IO::Path.contains` —— 它按真实路径解析，路径不存在时返回 False，
策略判定不该依赖「目录恰好存在」。真正的符号链接逃逸由 `Sys.resolve` 挡（V-201）。

## 4. 0.76 的实施范围（本版已做）

| 项 | 内容 |
|---|---|
| 新模块 | `lib/Rakuish/Kernel.rakumod`：`Request` / `Policy` / `Rakuish::Kernel`；`provides` 30 → 31 |
| 通道 | **只有 `kind => 'source'`**；`op` 返回 501（明确未实现，不伪装成功） |
| TTY 前端 | `bin/rakuish` 的三处调用（`-e` / 脚本 / REPL 循环）全部改走 `kernel.execute`，同一构造点 `make-kernel($session)` |
| 行为 | **零变化**：`t/35` 用 10 个样本对两个 Session 做逐字段对账（ok/code/op/out/err/value） |
| 审计雏形 | Kernel 内 `trail` 记录 seq / kind / origin / profile / ok / code（0.78 接进审计流） |

### 4.1 为什么先搬 `source`

`op` 通道要动 `Agent`、`Sandbox` 与协议字段，风险高；而 `source` 是
**所有 TTY 交互的唯一入口**，把它搬进 Kernel，等于先把「前端 → 内核」这条
主路打通。路通了之后再接 `op`，只是往 Kernel 里加一个分支，不是再改一次架构。

### 4.2 拒绝路径也必须结构化

策略拒绝返回 `Result(:!ok, :code(403), :op<kernel>)`，而不是抛异常：

- 前端只认 `ok/code/err`，异常穿透会逼每个前端写自己的 `try`；
- `op` 标成 `kernel` 而不是 `eval`，渲染层就不会把它当「求值失败」美化。

## 5. 延迟到后续版本的决策

| 决策 | 版本 | 原因 |
|---|---|---|
| `DisplayBundle` + TTY 降级 | 0.77 | 需要先有统一内核；否则会硬塞进 `Session.render`，变成第四处技术债 |
| 命令表单一数据源 + `!finish` 收口 | 0.77 | 与显示层一起改，避免两次动 `Session` |
| `op` 通道 + Agent 协议 v2 | 0.78 | 要动 `Agent` / `Sandbox` / 协议，需独立验收 |
| Agent `execute`（受限子进程） | 0.79 | 要 OS 级资源限额 + 网络/子进程限制，属新地基 |

## 6. 明确不做

| 不做 | 理由 |
|---|---|
| 人机**共享同一会话** | 要租约、操作序列化、输出广播、冲突解决；与 V-905「不做跨连接状态共享」冲突。共用内核即可，运行时状态不必共用 |
| `%` / `:` magic 语法 | `%` 是哈希 sigil、`%%` 是整除 —— sigil 空间已占满（V-902 的根因）。替代物是「会话命令 + 对象 API」 |
| Agent 直接 `EVAL` 源码 | 绕过 root / 白名单 / 审计（V-503）。要做得给受限子进程 + 独立 ADR + 威胁模型 |
| 把 `html` 塞进 `Result.out` | 会让管道输出混入标签，破坏 V-116 |

## 7. 阶段与验收

| 阶段 | 内容 | 验收 |
|---|---|---|
| **0.76（本版）** | Kernel + Request + Policy，TTY 走内核 | 现有 37 文件全绿 + `t/35` 双路径对账 + 策略拒绝断言 |
| 0.77 | `DisplayBundle`、命令表收口、`!finish` | 富显示单测；`Out[n]` / history 完整性 |
| 0.78 | `op` 通道 + Agent 协议 v2（`display`/`stream`/`cancel`/`describe`） | 协议兼容测试；审计字段含 origin/policy |
| 0.79 | 可选 `execute` op（受限子进程） | 逃逸测试、资源限额、红队 |

## 8. 备选方案与否决理由

| 备选 | 否决理由 |
|---|---|
| 给 Agent 再写一套「人可用的命令」 | 两套名字两套语义，正是要消灭的漂移 |
| 让 Kernel 直接持有 `Sys` 而不持 `Session` | 0.76 是搬运不是重写；先包住既有入口，能力边界不变，风险最低 |
| 用 profile 字符串在 Kernel 里 `when` 分支判定 | 加 profile 就要改 Kernel；改成字段判定后，profile 退化为日志标签 |
| 策略拒绝用异常表达 | 每个前端都要写 `try`，且容易把 403 渲染成「求值失败」 |
| 前端自行判断「这行是命令还是表达式」 | 那是 `Session` 的职责；前端只该决定 `kind` 与 `policy` |
