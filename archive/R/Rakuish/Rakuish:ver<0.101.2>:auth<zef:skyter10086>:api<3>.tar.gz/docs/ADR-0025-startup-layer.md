# ADR-0025 · 启动文件、可编程 prompt 与 `set -o`

- **日期**：2026-11-16
- **对象**：`main` @ 0.89.1 → 0.90.0
- **状态**：已实施
- **输入**：同 ADR-0024 —— 差距清单里「每次开机重敲配置」「prompt 不能改」
  「set 只有 -e」是日常使用的前三项
- **相关**：[ADR-0012](ADR-0012-userland-commands.md)（alias / 配置）、
  [ADR-0021](ADR-0021-eval-worker.md)（rc 必须跑在引擎里）、
  [ADR-0020](ADR-0020-policy-slim.md)（无执行点的字段不留）
- **影响条款**：V-232…V-236 新增；SPEC §3.17

## 1. 问题

0.89 的会话策略只有两条路：

- `~/.rakuish-config.json` 的扁平 KV + `hook add start` 一串命令；
- 每次开新会话手动重敲 `alias` / `config`。

缺的是 shell 的 **rc 层**：一个可读、可版本控制、可写变量与函数的启动文件。
prompt 也只有 `prompt-style` 三档 + 固定字段，装不下「显示 git 状态 / 时间 /
最近一条命令退出码」这种需求。`set` 只认 `-e`，其它选项没有。

## 2. 决策：rc 由引擎逐格执行

```
父进程                              引擎
  rc-path(): RAKUISH_RC / ~/.rakuish/rc.raku
  start → ready
  cmd=rc(path)  ────────────────→   slurp + run-rc(src)
                                      ├─ 逐行 eval-line（续行由 Session 持有）
                                      ├─ 收集 out / err / failed / lines
                                      └─ reset-counters: index=0, 清 out/history/perf
  ←──── {out,err,failed,lines,prompt}
  打印 out / err
```

为什么在引擎里：rc 要定义 `my $x`、`use`、`alias`、`set -o`、`repl.prompt` ——
这些状态全在 Session。父进程只负责「读哪个路径」和「把输出显示出来」，
不解释内容。这也让 `RAKUISH_NO_RC` / `RAKUISH_RC` 属于会话策略，而不是
解释器行为。

为什么逐行：rc 里既有 Raku（`my $x = 1`），也有薄层命令（`alias ll=ls -alh`），
后者只有 `eval-line` 认识。**不能**把整份文件当一个 cell `EVAL`。
续行缓冲必须交给 Session —— 自己在 run-rc 里拼一次会导致同一行被喂两次
（0.90 开发中实测：`class ... {` 永远等不到闭合）。

### 2.0 为什么不叫 `~/.rakuishrc`

v2 曾把**配置**写在 `~/.rakuishrc`（`color=true` / `replay=false` /
`auto-shell=true` / `editor="nano"` / `shell-backend=bash`）。v3 把同一路径
当 Raku 源码执行，每个会话开头都会刷一屏「Undeclared routine」。

两种选择：

| 方案 | 问题 |
|---|---|
| 沿用 `~/.rakuishrc` + 猜测是不是 v2 格式 | 启发式永远有漏网；用户的合法 Raku 也可能长成 `color=true` |
| 换到 `~/.rakuish/rc.raku` | 少一点 shell 习惯，但不与任何旧文件冲突 |

选后者。旧文件原样保留（不会被删除、也不会被读）；想用就显式
`RAKUISH_RC=~/.rakuishrc`，并把它改成 Raku。这个目录已经存在
（`audit.jsonl` / `session-*.json` 都在里面），不新增概念。

### 2.1 不占格号

rc 里成功执行一行，`eval-line` 会推进 `index`。用户不希望打开 REPL 就看到
`Out[7]`。所以 rc 结束后清零：

- `index = 0`
- `@!out` / `@!history` / `@!perf-hist` 清空
- `exit-requested` / `exit-code` 复位（rc 里的 `exit` 不该关掉会话）
- 保留：`%!state`、`@!decls`、alias、cwd、env、选项

### 2.2 崩溃后重跑，不从快照恢复

rc 定义的是**策略**（prompt 函数、选项、别名），不是数据。快照只恢复
声明与纯值（ADR-0022），恢复不了 `-> { ... }` 闭包。所以 `Proxy` 在重启
路径上**重新执行 rc**，并在结果文本里写明；rc 的错误也一并带出来。

### 2.3 只对交互式 REPL 生效

`-e` / 脚本 / 管道**不执行** rc。理由和「这些形态不走引擎」一致：它们要
可重复，不能被用户 HOME 里的文件改变。要脚本化配置，显式 `use` 或传
`RAKUISH_RC` 给交互会话。

## 3. 可编程 prompt

API 就是一条属性：

```raku
repl.prompt = -> { "{$*CWD.basename}> " }
```

- 每次取 prompt 都重新调用（父进程每格发 `cmd=prompt`）；时间 / git 这类
  信息才是当下的。
- 函数里 `say` 的内容被 `CapturingOut` 吞掉 —— prompt 计算不能污染结果流，
  更不能不慎写进 JSON 协议流。
- 异常 → 返回空串，前端回退默认样式。**坏 prompt 不能让 REPL 无法输入**。
- 换行压成空格：行编辑器按行算光标。
- 续行期间**不调用**（`$continuing` 为真时用默认 `···`），否则用户分不清
  自己是不是还在输入半个 `for`。

边界：prompt 是同步调用，里面跑 `git status` 这类外部命令会拖慢每一次
提示符；这是用户的选择，但文档要说明。没有 PS2 / 右侧 prompt / 异步 prompt。

注意 `cd` 只改 `sys.cwd`，不改引擎进程的 `$*CWD`（V-116 的会话语义），
所以 prompt 里要用 `sys.cwd` 而不是 `$*CWD` —— 否则提示符永远停在启动目录。

## 4. `set -o`：五个有执行点的选项

| 选项 | 默认 | 执行点 | 备注 |
|---|---|---|---|
| `errexit` | off | 失败格请求退出 | `set -e` 的正式名字 |
| `histexpand` | on | 整行 `!!` / `!$` / `!n` | 关掉后 `!!` 落回外部命令 |
| `noglob` | off | Shell 薄层 `* ?` 展开 | `glob` 命令显式调用不受影响 |
| `noexpand` | off | Shell 薄层 `$NAME` / `~` | 字面 `$` 原样传给命令 |
| `xtrace` | off | 求值前 `+ <源码>` 到 stderr | 不进 Result / Out |

规则：

- `set` / `set -o` 列表；`set -o NAME` 开；`set +o NAME` 关。
- 未知名字**明确报错**并列出可用项，不做「存下来但没人读」的 inert 键
  （0.75 的 `theme` 就是反例）。
- 选项只在会话内有效；要跨会话写进 rc（rc 会在重启后重跑）。
- `noglob` / `noexpand` 由 Session 同步给 Shell，Shell 不另存一份配置。

## 5. 不做什么

- 不解析 bash rc 语法、不执行 `.bashrc`（V-901）。
- 不做 per-directory rc / 登录 shell 分层 / `--norc` 参数；环境变量
  `RAKUISH_NO_RC` 足够，少一个启动参数就少一处口径。
- 不把 rc 里的 `export` 同步回父进程环境：会话 env 仍在引擎里，
  子进程继承的是会话 env（与 0.89 一致）。
- 不给 prompt 做异步 / 缓存：先要正确，再谈手感。

## 6. 验证

`t/45-startup.t`（48 断言）：

- rc：多行 `class`、变量、alias、`set -o`、不占格号 / 历史 / perf；
- rc 错误带行号、后续行继续执行；
- `set -o` 列表、开 / 关、未知选项、xtrace 真写到 stderr、
  `noglob` 让 `cat *` 从「读到文件」变成「找不到 `*`」、
  `noexpand` 保留字面 `$HOME`、`histexpand` 关闭后 `!!` 不再替换；
- prompt：返回值、单行化、吞掉 `say`、异常回退；
- 引擎：rc 经协议执行、`prompt` 命令、崩溃重启后 rc 重新执行，
  `ENG> ` 与变量都还在。

## 7. 教训

**配置层最容易被做成「看起来有」。** 一个选项只要没有执行点，就会变成
牌子：用户设了没效果，文档还写着支持。本 ADR 的规则是「先找执行点，
再进表」——所以 5 个选项，而不是 20 个。
