# ADR-0027 · 前端分页：把 `explore` 的 `-- more --` 搬到父进程

- **日期**：2026-11-17
- **对象**：`main` @ 0.91.0 → 0.92.0
- **状态**：已实施
- **输入**：`HANDOFF` 缺口表里的「引擎侧不做分页」——已知缺口，不是 bug
- **相关**：[ADR-0021](ADR-0021-eval-worker.md)（引擎子进程 / 协议流）、
  [ADR-0016](ADR-0016-display-bundle.md)（展示层只有一套排版）、SPEC V-245…V-249

## 1. 问题

`Rakuish::Data::Pager` 从 0.64 就在，`explore` 也一直在调它。但 0.83 把求值搬进
子进程之后，引擎的 stdout 是**协议管道**，`Pager` 判的 `live-out` 恒为 False：

```raku
my Bool $tty = $!live-out;          # 引擎进程自身的 stdout
$tty = False if (%*ENV<RAKUISH_PAGER> // '') eq 'never';
```

于是交互式 REPL 里 `explore` 从不分页，整份文本一次性刷屏。0.89 修的是更严重
的那件事（分页器把表格写进 JSON 协议流、吞掉下一个请求），修法是把分页**关掉**；
这次是把分页**接上**，但接在正确的一侧。

## 2. 决策：分页发生在父进程

父进程拥有真终端，也拥有「用户按了什么」这件事。所以：

| 层 | 职责 |
|---|---|
| 引擎 | 照旧把整份文本放进 `Result.out`（0.89 起就是这样），**不判断是否分页** |
| `Pager.paginate` | 只切页：文本 + 每页行数 + `&read` / `&emit` 两个回调 |
| `Pager.wants-page` | 只做策略：op / 行数 / 高度 / 模式 / 是否 TTY |
| `bin/rakuish` | 每格把 `term-size()` 的 rows 记下来，渲染后问一次 `wants-page` |

`&read` / `&emit` 注入是这个设计的核心：分页器不碰 `$*IN`，测试就能把
「回车 / q / EOF / 刚好整页」全部分支跑完（`t/47` 41 断言），真终端只剩
「按键真的到得了这一层」一条要验（`tools/pager-posix.py`）。

### 2.1 策略：auto / always / never

`RAKUISH_PAGER` 从「只认 never」升级成三档：

| 值 | 行为 |
|---|---|
| `auto`（默认，空值同此） | 只对 `explore` 且超过一页 |
| `always`（`on` / `1` / `yes` 同义） | 任何超过一页的结果都分页 |
| `never`（`off` / `0` / `no` 同义） | 不分页 |

未知值回落 `auto`。**不能**回落 `always`：环境变量写错不该让 `cat` 大文件突然停住。

默认只给 `explore`，是因为 `cat` / `ls -R` 的契约就是「给全」；想要 less 行为的人
显式写 `RAKUISH_PAGER=always`。

### 2.2 读键的位置

父进程在 `$cli.prompt()` 返回之后才渲染结果，此时行编辑器已经把终端交还，
`$*IN.get` 能拿到一行。读之前先 `$*OUT.flush`：否则先卡住再显示，看起来像死机。

`try { $*IN.get }` 把 Ctrl-C（`CX::Interrupted`）收成 Nil，分页器按 EOF 处理 ——
停在当前页，剩余输出丢弃。这与 `less` 里 Ctrl-C 的观感一致，也避免把中断
抛进主循环。

## 3. 被否掉的方案

| 方案 | 为什么不 |
|---|---|
| 引擎侧分页（把页面直接写到终端） | 引擎的 stdout 是协议流；写进去就是 0.87 那次事故 |
| 引擎把 `--tty` 交给父进程后自己分页 | `--tty` 是「整段时间交给子进程」，分页需要**交替**读写，语义不兼容 |
| 全屏 pager（备用屏、滚动、搜索） | 需要接管整个屏幕状态机，与行编辑器的 redraw 冲突；收益不值 |
| 默认给所有超一页的输出分页 | 改变 `cat` / `ls -R` 的既有契约，属于行为回归 |
| 用 `$*IN.getc` 做到「任意键翻页」 | 单字符读需要在原始模式下；跨平台（ConPTY / winpty）行为不一致，先用整行 |

## 4. 边界（如实记录）

- 分页只覆盖**已经渲染好的文本**；`Table` 的 `to-text(:max-rows)` 截断逻辑不变。
- `-e` / 脚本 / 管道**不受影响**（父进程主循环不参与）；`explore` 在进程内
  且 stdout 是终端时仍走 `Pager.page`（0.64 的行为）。
- Windows 侧没有分页探针（`tools/pager-posix.py` 仅 POSIX）；分页代码本身
  平台无关，但真终端验收目前只在 WSL / Linux 做过，Windows 只做了 `console=pass`
  的 Ctrl-C 那一层。
- 分页期间 `Ctrl-C` = 停止后续页（不是回到 prompt 再重画），没有「上一页」。
- `RAKUISH_PAGER` 每格读一次，改环境变量对已启动的会话无效（与 `RAKUISH_RC` 一致）。

## 5. 验证

- `t/47-pager.t`（41 断言）：模式归一、每页行数、策略矩阵（非 TTY / never /
  装得下 / auto 只认 explore / always）、切页（多页 / 刚好整页 / EOF / Q /
  任意键）、以及 `Pager.page` 的进程内路径（含「一页装得下也必须打印」）。
- `tools/pager-posix.py`（真 PTY）：`explore big.csv` 出现 `-- more`、回车翻页、
  `q` 退出且不补打剩余行、`RAKUISH_PAGER=never` 的对照进程一次打完。
- 接进 `tools/ci.sh` 的 console 层（POSIX 两个探针，Windows 一个），
  任一失败即 `console=fail`。
