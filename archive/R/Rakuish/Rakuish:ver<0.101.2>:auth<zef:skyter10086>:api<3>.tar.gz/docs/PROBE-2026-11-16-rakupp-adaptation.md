# 判断 B · 第三层验证：15 个失败文件的适配性归因

> 日期：2026-11-16 · 版本：0.80.4 · 性质：**只读探针**（副本里改，主干零改动）
> 引擎：Raku++ 5.8.0 (2026-11-12) x86_64-linux（WSL2）
> 前置：[`PROBE-2026-11-15-persistent-engine.md`](PROBE-2026-11-15-persistent-engine.md)、
> [`PROBE-2026-11-16-rakupp-integration.md`](PROBE-2026-11-16-rakupp-integration.md)

## 1. 这一层要回答什么

第二层给出的事实是「34/34 模块能加载、一格逐字节一致，但全套件只有 27/42」。
但它把**「引擎语义差异」与「宿主环境缺失」混在一起**，无法判断该不该继续。

本层把 15 个失败文件拆成两类：

- **Rakuish 侧改几行就能绕过**的（引擎有缺陷，但不是没有那项能力）；
- **引擎真的没有**、只能等上游或换实现的。

方法：`tools/probe/rakupp-adapt.sh` 在 `tmp/probe-adapt` 复制一份仓库，
**只改两处**已定位的差异点，其余一个字节不动，用 rakupp 重跑全套件。

## 2. 结果：27 → 30，失败 15 → 12

```
第二层（原样）      SUMMARY|files=42|pass=27|fail=15|ok_lines=1856
第三层（改两处后）  ADAPT-SUMMARY|files=42|pass=30|fail=12|ok_lines=1980
```

**修好的 3 个文件**：`02-sys-session`、`04-dsl-command`、`26-nested-repl`。
`+124` 个 ok 行，失败文件少 3 个——说明这两处不是边角，而是**主路径**。

两处改动（各一行级别）：

| # | 位置 | 原写法 | 绕过写法 |
|---|---|---|---|
| ① | `Sys::Proc.spawn` | `$proc.stdout.Channel` | `.tap` → 自建 `Channel`，`Handle.wait` 一行不改 |
| ② | `Sys` | `has %.env = %*ENV.Hash` | 改在 `TWEAK` 里 `%!env = %*ENV.Hash` |

## 3. 归因：七类，四类可绕过、三类不行

### A. `Proc::Async` 的 Supply→Channel 适配收不到数据（rakupp 缺陷）

| 观测 | MoarVM | rakupp 5.8.0 |
|---|---|---|
| `$p.stdout.Channel` 收块数 / 长度 | 2 / 8 | **0 / 0** |
| 同一 Supply 改用 `.tap` | 2 / 8 | 1 / 8 ✅ |
| stderr 单独取 Channel | 有 | **空** |
| `$p.stdout.lines.Channel` | 有 | **空** |
| 约 200 KB 输出 | 201000 字符 / 28 块 | **0 字符 / 0 块** |

**范围很窄**：普通的 `Supply.from-list(...).Channel`、`supply { emit ... }.Channel`
在两个引擎上都正常——只有 `Proc::Async` 的 stdout/stderr Supply 有此问题。

⇒ **可绕过**（实测）：改为 `.tap` 推送进自建 `Channel`，`wait` 的消费逻辑不变。
影响 03、04、05、06、07、26、39 的多数失败。

### B. 属性默认值 `%*ENV.Hash` 共享进程环境存储（rakupp 缺陷）

| 写法 | MoarVM | rakupp |
|---|---|---|
| `my %a = %*ENV.Hash; %a<X> = 'v'` → `%*ENV<X>:exists` | no（正常复制） | no（正常复制） |
| `has %.env = %*ENV.Hash;` 后写 `%!env<X>` | **no** | **yes（污染进程环境）** |

同一语义在「局部变量」与「属性初始化」上表现不同——这是 rakupp 的初始化路径缺陷。
后果：`set-env` 改到 `%*ENV`，且所有 `Sys` 实例共享同一份环境。

⇒ **可绕过**（实测）：在 `TWEAK` 里显式复制。修好 `t/02` 的两条（含「关键」那条）。

### C. spawn 失败返回 Kept 而不是 Broken（rakupp 差异）

```
MoarVM : await $p.start  → Broken;cause = "Failed to spawn process ...: no such file or directory (error code -2)"
rakupp : await $p.start  → Kept;result 可用;exitcode = -1
```

Rakuish 的 `start-failed` 判定依赖 `$!promise.status ~~ Broken`（`t/03` 的
`code=127` / `retain err` / `start-failed` 三条）。rakupp 上走不到那个分支，
于是 `code` 变成 `-1`。

⇒ **可绕过**：把 `exitcode < 0` 也计入 start-failed。成本约 3 行。

### D. `:pty` 被静默忽略（rakupp 未实现）

```
rakupp: $*RAKU.compiler.version = 2026.09（过 ≥2025.12 门槛）
        子进程仍报 PTY-NO —— :pty 参数被吞掉
```

**Rakuish 的行为是对的**：`pty-capability` 探测到 `PTY-NO` 后明确返回
`capable=False`，`pty-exec` 收敛成 `code=127` 并带上原因，不假装成功
（这正是 0.72.2 立的规矩）。所以 `t/28/29/30` 失败是**测试前提不成立**，
不是产品缺陷。

⇒ **不可绕过**：只能等 rakupp 实现。影响 27、28、29、30。

### E. NativeCall 的 `CPointer` repr out 参数语义（rakupp 差异）

| 观测 | MoarVM | rakupp |
|---|---|---|
| 最小 `Pointer is rw` 绑定 `sqlite3_open_v2` | rc=0、句柄有效 | **rc=0、句柄有效** |
| `DB::SQLite`（`class ... is repr('CPointer')` 作 out 参数） | 正常 | **`SQLITE_MISUSE` @ `sqlite3_open_v2`** |
| `is rw` 后对象是否被回写 | 否 | 是（语义相反） |
| 未定义 `CPointer` 实例传给 native out 参数 | 编译期拒绝 / 崩 | 崩（缺少类型检查，直接 SIGSEGV） |

`libsqlite3` 本身可达（`sqlite3_libversion` = 3.46.1，两个引擎一致），
所以不是环境缺库、也不是 ABI 不可用——是**「CPointer repr 类作为 out 参数」这一种
传参形式**在 rakupp 上语义不同。

⇒ **绕过有成本**：Rakuish 若要在 rakupp 上用 SQLite，得自建 `Pointer` 绑定
（`Pointer is rw` 实测可行），不能直接用 `DB::SQLite`。影响 13、20、25。

### F. 未声明例程的报告方式不同（rakupp 差异）

三种写法实测（同一段源码，只改包装形态）：

| 源码形态 | MoarVM | rakupp 5.8.0 |
|---|---|---|
| `git status`（裸） | `Undeclared routines:` + `git…` + `status…` | `Undeclared routine:` + `git…`（**只报第一个**） |
| `do { git status }`（**Rakuish 的包装**） | 两个都报 | `Undefined routine 'status'. Did you mean 'stat'?`（**只报参数位置那个**） |
| `do { git(); status() }` | 两个都报 | `Undefined routine 'git'…`（第一个） |

**重要更正**：第二层把 `t/07` 记为「错误消息措辞差异」并不准确。
逐条对比五类错误（未声明例程 / 未声明变量 / 语法 / 方法不存在 / 类型检查），
**消息正文几乎逐字相同**（只有 do-you-mean 候选顺序不同）。真正的差别只有两条：

1. **只报一个**未声明例程（MoarVM 收集全部）；
2. 用词从 `Undeclared routine: x used at line N` 变成 `Undefined routine 'x'`。

而 Rakuish 恰好用 `EVAL "no worries; do \{ $code\n }"` 求值（`Session` 第 725 行），
所以 `t/05`「err 含 git」、`t/07`「输出含 Undeclared」这两条断言在 rakupp 上必然失败
—— **不是产品回归，是断言绑死了 MoarVM 的报错形态**。

⇒ **可绕过**：`classify-error` 关键词表补 `Undefined routine`；这两条断言改为
「失败信息非空且提到出错标识符」而不绑具体用词。影响 05、07 各 1 条。

### G. async accept handler 收尾失败（rakupp 缺陷）

```
===WARNING=== async accept handler died: done without supply or react
```

`t/06` 的 idle-timeout 收尾、`t/39` 的 serve-once 收尾都撞在这条上。
不是 Rakuish 的连接管理逻辑，而是 rakupp 对 `IO::Socket::Async.listen`
的 Supply 生命周期处理（`done` 时没有活跃 react）。

⇒ **不可绕过**（除非放弃异步 socket）。影响 06、39 各 1 条。

## 4. 上界推算：能到 33，最好 36，剩下 6 个卡在引擎

| 修什么 | 预计通过 | 依据 |
|---|---|---|
| 现状（改两处） | **30 / 42** | 实测 |
| \+ C（spawn 失败判据） | 31 | `t/03` 三条同一根因 |
| \+ F（错误消息关键词与断言） | **33** | `t/05`、`t/07` 各 1 条 |
| \+ E（自建 SQLite 绑定，替换 `DB::SQLite`） | **36** | `t/13`、`t/20`、`t/25` |
| D（`:pty`）+ G（async accept） | 仍缺 6 个文件 | **只能等 rakupp** |

也就是说：**Rakuish 侧能自己解决的部分到 36/42（86%）为止**，
剩下的 `t/27`–`t/30`（PTY / 中断）与 `t/06`·`t/39` 的收尾
是引擎能力缺口，不是代码问题。

## 5. 对判断 B 的影响

第二层说「成本中心在宿主集成层」；这一层把成本**拆成了可估算的条目**：

- 三个绕过（A/B/C）是**主路径上的三行改动**，且都已在副本里验证有效；
- E 是**一次性适配成本**（自建 SQLite 绑定），不是架构问题；
- D/G 是**硬缺口**，项目若换引擎就会永久失去 PTY 与异步 socket 收尾。

因此结论没变，但**性质变了**：

> 换引擎不再是「不知道要付多少」，而是「先付 3 处主路径适配 + 1 个绑定重写，
> 然后接受永远没有 PTY 和可靠 socket 收尾」——对一个 **shell / REPL 工作台**，
> 后一条几乎是致命的（`:pty` 是交互式子进程的全部基础）。

**这也是本层最有价值的结论**：判断 B 的失败不在「Raku 语义兼容」，而在
「rakupp 缺的恰好是这个产品最核心的两项宿主能力」。等价实现比对不需要再做了
——`t/27`–`t/30` 的等价实现就是「自己实现一套 PTY」，那是另一个项目。

## 6. 明确未测

- 三个绕过（A/B/C）**没有合入主干**，只在副本里验证；MoarVM 上未做回归
  （理论上无影响：`.tap` 与 `TWEAK` 复制都是更保守的写法，但未实测）。
- E 的自建 SQLite 绑定只验到 `sqlite3_open_v2` 一条路径，未做完整
  prepare/step/bind 覆盖。
- D/G 的「等上游」是否现实——本层不评估 rakupp 的路线图。
- Windows 侧 rakupp 构建仍全部未测。

## 7. 复现

```bash
export PATH="$HOME/.rakupp/bin:$HOME/.rakubrew/versions/moar-2026.09/install/bin:$PATH"
bash tools/probe/rakupp-adapt.sh           # 副本里改两处 + 跑全套件
bash tools/probe/rakupp-adapt.sh --keep    # 保留 tmp/probe-adapt 供手工检查
```

单点验证（每类的最小复现），见 `tools/probe/README.md` 的「第三层」小节。
