# ADR-0032：退出残留线程消解与展示契约收口（0.98.2 修复集）

- 状态：**Accepted**
- 版本：0.98.2
- 关联：t/30 契约 5、t/41 §⑦、t/44、SPEC V-116；ADR-0021（引擎子进程）、ADR-0023（Ctrl-C 归因）、ADR-0024（流式输出）
- 取证记录：[`PROBE-2026-11-17-exit-teardown-9p.md`](PROBE-2026-11-17-exit-teardown-9p.md)

## 1. 问题

0.98.1 复核报告的 P0：t/30 契约 5（`tty-exec` + Ctrl-C 之后仍能干净退出，
rc=0）在 WSL 连续稳定失败。排查排除了「产品收尾没做完」：逐帧插桩证明
history 落盘、END 块、VM teardown 全部完成、退出码已按 `exit(N)` 记账，
进程只是卡在「变 zombie」的最后一步——残留线程正处在 WSL 9p 的
`p9_client_rpc`（不可中断睡眠）里。外部 `kill -9` 0.1s 收割，且 waitpid
报告的仍是 `exit(N)` 的退出码。对输入时序极敏感：同一驱动只改一个轮询
写法就能在「0.04s 干净退出」与「永久挂住」之间稳定翻转。

同版另两处展示/判定问题：

- `Proxy.render` 对 `rendered=''` 一律 fallback 到 `render('text')`，把
  `ok/op/code` 字段 dump 上屏：续行（0.97.1 挡了 more/exit/skip）、`!`
  流式、`cd` / `mkdir` 安静成功都踩过；
- Windows 的 `$*OUT.t` 走 CRT `_isatty`，对 NUL（`>/dev/null`）误报 True，
  颜色 / live-out 全开，t/10 / t/33 的「非 TTY」断言在该重定向下假失败
  （退出码 5/4 但 TAP 全 ok）。

## 2. 决策

### 2.1 退出残留线程：linger guard（不绕开 `exit()`）

退出前起一个看门狗子进程（POSIX-only）：`trap '' HUP` 后 `sleep 0.5`，
核验「我是否还是它的父进程」；是则 `kill -9` 消解残留线程，否则什么都不做。

- **不**改走 `_exit(3)` 绕开 VM teardown：实测 `_exit` 同样挂（问题不在
  teardown，而在残留线程），且会误伤模块 END / File::Temp 清理网；
- **不**在退出路径里 sleep / force_gc / 唤醒解析线程：都实测无效；
- `trap '' HUP` 必须有：pty 测试里 rakuish 是会话首进程，leader 退出时
  内核给前台组发 SIGHUP，会把看门狗一起带走（实测）；
- 退出码语义不变：do_exit 记账在前，kill -9 后 waitpid 报的仍是 `exit(N)`。

正常路径只多一次 sh spawn（毫秒级）。Windows 无此现象，不挂看门狗。

### 2.2 Proxy.render：只信引擎的 `rendered`

`rendered` 是引擎算好的最终展示文本，空串就是「刻意不展示」。「没渲染」
的情形已不存在（通信失败 / 引擎重启兜底 Result 自带非空 rendered）。
0.97.1 的 more/exit/skip 白名单并入本条——口子收完，不再 fallback
`render('text')`。

### 2.3 Windows TTY 判定：CSBI 探真控制台

`Rakuish::Sys::Term::stdout-is-console()`：Windows 用
`GetConsoleScreenBufferInfo`（只有真 console 才成功），POSIX 仍信 `.t`。
Session TWEAK / bin 的 tty、live-out 判定统一走它。测试侧对「非 TTY
代码路径」的断言显式 `set-tty(False)`，不再依赖宿主 stdout 形态。

## 3. 后果

- t/30 契约 5 在 WSL 9p 检出上恢复 10/10；`tools/run-all.sh` 问题总数 0。
- 安静格 / 流式格的屏幕上不再出现 `ok: true / op: ... / code: ...` 残渣
  （t/41 §⑦、t/44 回归）。
- 依赖一个 POSIX `sh` 看门狗（几乎所有环境都有；spawn 失败只退化为
  旧行为，try 吞掉）。极端情况（残留线程 0.5s 内都没咽气）由 kill 收场，
  退出码仍正确。
- Windows NUL 重定向下颜色/提示符行为修正；`tty-exec` 的非 TTY 守卫
  （`Sys::Proc`）仍用 `$*IN.t && $*OUT.t`，未并入本条（那是「有没有
  控制终端可交接」的另一件事）。
