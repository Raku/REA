# §6 方向输入探针报告：权限交给系统 + 拿回常驻引擎

> 日期：2026-11-15/16 · 基线：`main` @ `f9620e0`（0.80.1）
> 性质：**只读实验报告**。不改主干、不改架构、不升 SPEC 条款、不替读者下结论。
> 上游：[《Rakuish 愿景溯源：从 shell 解释器到 REPL 工作台》](https://www.workbuddy.cn/space/d/B5lMceuYGSOOInC9pN7YKo) §6（方向输入）与 §6.6（两条最小探针）。
> 复现：全部脚本在 [`tools/probe/`](../tools/probe/README.md)，数据在 §2 / §3。

## 0. 一句话

两条探针都跑通了，而且都**改变了 §6 的估计**：判断 A（权限交给系统）在本机 REPL 上
**基本已是事实，不需要「撤」**；判断 B（常驻引擎）的**技术前提成立且已实证**，
但挡在前面的不是「把引擎拿回来」，而是 V-906、一进程一解释器与 `RkValue` 生命周期
这三件事。两者合起来仍是一个品类选择，本文只把事实摆齐。

## 1. 重开的议题

《愿景溯源》§6 记下读者给的两个判断：

| | 判断 | 一句话 |
|---|---|---|
| A | 权限控制不如交给系统权限，为什么要 shell 来解决？所以沙箱没有必要 | 撤掉应用层安全壳 |
| B | rakupp 本来就是持久求值器，可以把蓝图里常驻引擎那部分拿回来 | 恢复跨格连续状态 |

§6.5 把两条合起来描述为「把 rakuish 拉回**本地、单用户、全权限、状态连续**的 Unix
工具模型，但不回到白皮书的 bash 语法」。§6.4 同时指出张力：常驻全权限解释器不能接
Agent / TCP。§6.6 给了两条**可复核探针**，明确「两条都不要求先动架构」。

本报告执行这两条探针，并把结果回写到议题状态。**探针不是实施，也不构成推荐。**

## 2. 探针①：`Sandbox` 整层短路后的依赖面

### 2.1 方法（变异测试 + 对照组）

在 `tmp/probe-sandbox` 副本里把 `lib/Rakuish/Sandbox.rakumod` 换成「构造即 die」的
stub，其余文件原样；`--control` 模式保留原 Sandbox、其余步骤完全相同。
脚本：`tools/probe/sandbox-short-circuit.sh`，输出 `PROBE|用例|rc=|首行`。

### 2.2 实测（WSL / Rakudo v2026.09）

| 用例 | 变异体 rc | 对照组 rc | 判定 |
|---|---|---|---|
| `-e 'say 1+1'` | 0 → `2` | 0 → `2` | **不受影响** |
| 脚本模式 `cell.raku` | 0 → `SCRIPT-OK` | 0 → `SCRIPT-OK` | **不受影响** |
| 交互管道 `say 40+2` / `quit` | 0 → `42` | 0 → `42` | **不受影响** |
| `t/05-repl-session.t` | 0 | 0 | **不受影响** |
| `t/35-kernel.t` | 0 | 0 | **不受影响** |
| `t/07-entrypoints.t` | **5**（失败 59–63） | 0 | 挂的 5 条全是 `--agent 转发` 用例 |
| `t/39-stream-cancel.t` | **1**（stub 抛错） | 0 | Agent 协议测试，预期挂 |
| `t/06-sandbox-agent.t` | **1**（stub 抛错） | 0 | Agent 策略测试，预期挂 |

静态盘点一致：`use Rakuish::Sandbox` 只出现在 `Agent.rakumod`、
`Agent/Server.rakumod`、`Agent/Worker.rakumod`；`bin/rakuish` 三个入口都不构造它。

### 2.3 比「沙箱是 Agent 产物」更关键的一条

`REPL/Session.rakumod` 的 TWEAK 里，本机会话默认：

```raku
my IO::Path $root = $*DISTRO.is-win
    ?? IO::Path.new($*CWD.volume ~ '\\')      # + all-drives 放行其它盘
    !! IO::Path.new('/');
```

且 `bin/rakuish` 的 `make-kernel` 给的是
`Policy.new(:profile<local>, :allow-source, :allow-exec)`。也就是说
**本机 REPL 的文件边界已经是文件系统根**，`Sys.resolve` 的 root 校验对 `root=/`
恒真，源码执行与外部进程都放行。

所以对判断 A，精确结论不是「要撤掉一层安全壳」，而是：

- **安全边界层**（root / 白名单 / token / V-607 闸门）在本机路径上**已经不存在**，
  它只活在 Agent 入口与 `bin/rakuish --agent` 这条转发支路里；
- 本机路径上剩下的 `max-bytes` / `timeout-ms` / `max-output` 等是
  **资源治理**，不是访问控制（§6.2 的判断在这里成立：OS 给「能/不能」，
  不给「最多 1 MiB / 30 秒」，要保留就得自己留）；
- `Rakuish::Audit` 已在 0.80.0 拆成独立模块，是读者自己定的第二条硬约束，
  **与安全壳无关，不该一起撤**。

**要决策的因此不是「本机怎么撤」，而是 Agent 那条线留不留**，以及要不要清理
`Sys` 里对本地恒真的那段 root 校验（清理是优化，不是能力变更）。

## 3. 探针②：rakupp C ABI 的常驻求值

### 3.1 环境与前提

WSL2 Ubuntu · g++ · Rakudo `v2026.09` · **rakupp 5.6.3**
（`~/.rakupp/include/rakupp/rakupp.h`、`~/.rakupp/lib/librakupp.so.5.6.3`）。
`RkInterp` / `RkCtx` / `RkValue` 全是 opaque 指针 —— NativeCall 侧不需要猜结构体布局。

蓝图当年欠的两条待核实项：「`rakuppRun` 真实签名」「`g_sandboxChecks` 默认状态」，
在这台机器上都可以直接读头文件 + 实测，不必再靠草案假定。

### 3.2 C 探针实测（`tools/probe/rakupp-session.c`）

| 观测 | 默认配置（`RkConfig` 全 0） | `--sandbox`（`cfg.sandbox=1`） |
|---|---|---|
| `rk_version` | `5.6.3` | `5.6.3` |
| `rk_new` 耗时 | 13.11 ms 冷 / 0.77 ms 热 | 0.67 / 0.56 ms |
| `my $x = 41` → `$x + 1` | **`42`** ✅ | **`42`** ✅ |
| 赋值 `$x = 100` 后再读 | `100` ✅ 不是快照 | `100` ✅ |
| 语法错后 `$x + 1` | `101` ✅ 解释器存活、状态没丢 | `101` ✅ |
| `rk_root` 的值跨后续 eval | `7` ✅ | `7` ✅ |
| 读 `/etc/passwd` | **`rc=0`, 1468 字符**（默认不限制） | **`rc=1`**：`IO::Path.slurp is not allowed in the sandbox` |
| 同一进程第二个 live `rk_new` | **`NULL`** | **`NULL`** |
| `rk_free` 后重新 `rk_new` | `non-NULL` ✅ 顺序复用可行 | `non-NULL` |
| free 之后再读文件 | — | **仍 `rc=1`** ✅ 进程级、单向 |

### 3.3 Raku / NativeCall 探针实测

`tools/probe/rakupp-session.raku` 用 `is native($lib)` 直调同一套 ABI：

```
lib=/home/zby/.rakupp/lib/librakupp.so.5.6.3   version=5.6.3   rk_new=OK
eval1_my41=41  eval2_x_plus=42  eval3_assign=100  eval4_reread=100
eval5_bad_rc=1 (Two terms in a row)  eval6_recover=101
second_live_rk_new=NULL   freed=OK
```

即 **Raku 侧可以直接驱动常驻解释器**，值 ABI 的最小路径通了。

### 3.4 结论：判断 B 的技术前提**成立**

头文件注释「An interpreter is a SESSION, not a one-shot」不是设计假定，是
ABI 契约，实测逐条对上。同时补上了蓝图欠的 `g_sandboxChecks` 默认态：
**默认关闭**；一旦用 `sandbox=1` 建过解释器，本进程后续所有解释器都被限，
连 `rk_free` 之后用无沙箱配置新建也一样。

但要立刻标清边界：头文件原话是
*"Only the Raku code is confined, not your process"* ——
这是**语言内能力约束，不是 OS 隔离**。它不能替代 V-607，也不能拿来跑不可信源码。

## 4. 两条探针合起来，对 §6 判断的影响

| §6 判断 | 探针前（文档 1 §6.2/§6.3 的估计） | 探针后 |
|---|---|---|
| A · 撤应用层安全壳 | 「`Sandbox.rakumod:25-50` 装了三类东西，不能一刀切」 | 更彻底：本机 REPL **本来就不构造 Sandbox**，root 已是 `/`，Policy 已是 local。安全壳只在 Agent 线；Audit 已独立成模块，属用户硬约束，不随壳一起撤 |
| A · 撤掉就等于交给 OS | 担心「删掉 Sandbox 就完事」 | 不成立的是这个担心本身：OS 权限按进程/用户授予，本机单用户下进程天然就是用户的权限；**剩下的真问题是 Agent 线留不留** |
| B · 常驻跨 eval 作用域 | 「白皮书草案的设计假定，未经实证，不应当成已验证能力」 | **已实证**：C ABI 与 Raku NativeCall 双路径都拿到 42 / 100 / 101；默认 sandbox 关、进程级单向也一并测出 |
| B · 「拿回来」比听上去重 | 指出 V-906、34 个模块、换底座 | 成立，而且更具体：见 §5 的五条硬约束 |
| §6.4 张力 | 「把网络输入接进全权限常驻解释器，比 0.80.0 更危险」 | 比「更危险」更硬：**ABI 层一进程只能有一个 live 解释器、一个线程**，Agent 的每连接并发模型放不进去，不是价值权衡 |

## 5. 判断 B 真正挡在前面的五件事

1. **V-906 明确不做持久求值器 / 常驻编译单元**（`ADR-0005 §4`）。
   要落地必须重开 V-906 + 新 ADR；而 ADR-0005 §4 反对的正是「要重做
   `EVAL` 作用域、副作用与失败回滚」——恰好是常驻引擎带来的最大语义变化。
2. **一进程一 live 解释器 + 一解释器一线程**（头文件契约 + 实测 `NULL`）。
   与 0.63「每连接独立 Sys/Engine」、0.67 worker、0.79 并发请求直接冲突：
   要么所有连接串行共享一个解释器（会话隔离消失、失败格互相污染），
   要么退回多进程 worker 模型。
3. **`RkValue` 只在下一次 `rk_eval` 之前有效**。现在 `@!out` / `%STORE<_>`
   假设 `Out[n]` 的值一直可用、`format-value` 随时能 `.raku`；
   常驻化后跨格保留值必须 `rk_root` / `rk_unroot`（实测可行，但要改存储与渲染语义）。
4. **求值语义换了底座**。当前是「每格新建编译单元 + 状态外置
  （`%!state` / `@!decls`）」；常驻 mainline scope 里 `my` / `state` / `our`、
   副作用重放、失败回滚、类型对象身份全部不同。这是 `ADR-0001` 量级，不是加开关。
5. **34 个 `Rakuish::*` 模块能否在 rakupp 上加载，未测**。
   `NativeCall`、`Terminal::LineEditor`、`JSON::Fast`、`CORE.setting` 差异、precomp
   都要单独验；Windows 侧是否存在对应的 rakupp C ABI 构建也未测。
   探针② 只证明「值 ABI 的最小路径通」，**不证明 Rakuish 能在它上面跑**。

## 6. 明确未测 / 未验证

> **2026-11-16 更新**：本节多项已由第二层验证覆盖（34/34 模块加载、
> `rk_run` 整程序、值 ABI 类型覆盖、内存、全套件兼容率），并发现新的成本中心。
> 见 [`PROBE-2026-11-16-rakupp-integration.md`](PROBE-2026-11-16-rakupp-integration.md) §4。
> 下文原文保留以记录当时的边界，**不代表现在仍未测**。

- 34 个模块的加载、`rk_run` 整程序模式、完整 `RkValue` 类型覆盖、内存占用、
  多线程 host 回调、JIT / sandbox 组合行为。
- Windows 侧 rakupp 构建；本报告的引擎数据**只在 Linux/WSL 有效**。
- `rakupp 5.6.3` 与白皮书基线 `5.3.0` 的 ABI 差异；只测了 5.6.3。
- 「把 `Sandbox` 删掉」之后的 Agent 协议行为 —— 探针① 只做依赖面盘点，
  不做删除方案；对照组已经证明那些用例本来就该挂。
- 探针② 的启动耗时是单次 `rk_new` 的粗测，不是 REPL 每格延迟的基准测试。

## 7. 议题状态与待判断的选项

**议题已重开，结论待定**：`docs/ROADMAP-2026-11-11.md` 的阶段表与
`docs/ADR-INDEX.md` 已把 §6 方向标为开放议题；`execute` / VM 隔离的收口结论
（V-607、ADR-0018）**不因探针而撤回**，`SPEC V-906` 未被改动。

可供选择的下一步（本文不排序、不推荐）：

| | 做什么 | 需要动主干吗 |
|---|---|---|
| ① | 只收判断 A 的尾：把「本机 REPL 已是全权限」写进文档，清理 `Sys` 里对本地恒真的 root 校验 | 小改动，需新版本 |
| ② | 只继续验证判断 B：34 模块加载探针 + `rk_run` + 值 ABI 类型覆盖 + 内存/线程 | 不动 |
| ③ | 两条一起推：先决定 Agent 线留不留，再重开 V-906、写 ADR-0019 | 换底座，大改动 |
| ④ | 都不做，把本报告存档，维持 0.80.1 的收口状态 | 不动 |

无论选哪条，§6.4 的分叉都必须先回答：**保留 Agent / TCP，还是把常驻上下文接进来**。
探针② 的 `second_live_rk_new=NULL` 说明这两者在当前 ABI 下不能共存。
