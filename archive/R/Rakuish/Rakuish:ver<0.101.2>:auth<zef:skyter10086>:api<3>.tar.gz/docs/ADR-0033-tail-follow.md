# ADR-0033：`tail -f` 跟随 —— 轮询循环放父进程，Ctrl-C 只停跟随

- 状态：**Accepted**
- 版本：0.99.0
- 关联：V-272…V-276；ADR-0007（tty-exec 父侧执行同构）、ADR-0031（job 帧）、
  ADR-0021（引擎子进程）、ADR-0032（中断与展示契约）

## 1. 问题

内置 `tail` 没有 `-f`。真值参照是 GNU tail -f：先打末 N 行，然后跟新增、
Ctrl-C 退出。难点不在轮询，在**Ctrl-C 的归属**：

- 求值期间的 Ctrl-C 在双进程架构里是「杀引擎 + 重启」（ADR-0023）——
  而 `tail -f` 的正常退出方式**就是** Ctrl-C。每次停跟随都搭一次引擎重启
  （重放 LexState、丢运行时注册）是荒谬的成本；
- 跟随要写实时输出，而引擎的 stdout 是协议管道（ADR-0024 的 chunk 帧是
  `!` 的通道，shell 命令的 out 是「执行完一次性渲染」）；
- Windows 没有 inotify，也没有前台进程组，方案必须跨平台。

## 2. 决策

### 2.1 跟随循环跑在父进程（job 帧 `tail-follow`）

引擎的 Shell 解析 `-f` 后走 `Sys.job-op('tail-follow', $file, $n)` →
job 帧 → 父进程 `!answer-job` → `Sys.tail-follow`（与 tty-exec / bg-exec
完全同构的通道）。行直接写真终端（专用 emit 通道，`Result.out` 只留一行
停止摘要，不重放）。单进程模式（`-e` / 脚本 / 直调）回落本地循环。

### 2.2 Ctrl-C 归属：job-interactive 期间只置停止标志

`Eval::Client` 的 SIGINT 处理器加一个 `job-interactive` 分支：tail-follow
期间 Ctrl-C 置 `job-stop`，跟随循环轮询它退出（code=130，128+SIGINT），
**不杀引擎**。`job-stop` 以闭包形式注入 `Sys.job-op(:should-stop)`。
worker 侧在等 job 帧响应期间装 SIGINT no-op tap（终端 Ctrl-C 会同时投给
前台组里的 worker，不装它会被默认处置打死）。

### 2.3 轮询而不是 inotify / kqueue

0.2s 间隔的大小比较 + 偏移读，一个实现三平台通用。半行缓冲按字节拼、
整行才解码（跨 poll 的 UTF-8 安全）。截断 / 轮转：size 变小 → 当作新文件
从 0 重读；消失 → 等待，重现按新文件。不做 inode 级跟踪（`tail -F`）——
大小比较已覆盖日志轮转的常见形态。

## 3. 备选（否掉的）

- **引擎内循环 + chunk 流式 + 软中断帧**：要把 Shell 输出接进 chunk 通道、
  还得给 worker 发「软中断」通告，两头都加机制；且「每次 Ctrl-C 一次引擎
  重启」的成本问题依旧（除非把软中断做进信号链，更深）。
- **`tail -f` 直接转给系统 tail（tty-exec）**：POSIX 才有，Windows 落空，
  违背内置命令的跨平台契约。
- **阻塞循环 + `_exit` 包装 / 引擎重启硬扛**：前者治不了归因，后者把
  「停跟随」错误地升格成「中断求值」。

## 4. 后果

- `tail -f` 在双平台可用；Ctrl-C 停跟随后会话现场原样保留（t/56 用
  `$*PID` 守「引擎没重启」）。
- 引入一个父侧长操作的通用形态：以后 `less -f` 之类的跟随类命令可以
  走同一个 `job-op` 分支（should-stop 闭包）。
- 轮询有 0.2s 延迟上界；对日志场景足够，对极高频写入不追求 tail -f 的
  inotify 级实时。
