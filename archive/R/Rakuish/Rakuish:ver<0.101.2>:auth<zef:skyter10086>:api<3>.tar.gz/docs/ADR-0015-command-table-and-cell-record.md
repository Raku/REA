# ADR-0015 · 命令名单一数据源与输入序/格号分离

- **日期**：2026-11-13
- **对象**：`main` @ 0.76.1 → 0.77.0
- **状态**：已实施
- **输入**：0.76 之后按 ADR-0013 §7 排期；实施前重新审视了 §7 的三件事，
  决定本版只做两件内部债，`DisplayBundle` 推迟
- **相关**：[ADR-0013](ADR-0013-kernel-frontends.md)（Kernel / 前端契约）、
  [ADR-0012](ADR-0012-userland-commands.md) §2（`OPTIONS` 表）
- **对应条款**：SPEC **V-188**（命令名单一数据源）、**V-189**（输入序与格号分离）

## 1. 为什么调整 ADR-0013 §7 的排期

§7 把三件事放在 0.77 同一版：`DisplayBundle`、命令表收口、`!finish`。实施前
量了一下风险，三者不是一个量级：

| 项 | 性质 | 风险 | 是否需要第二个消费者 |
|---|---|---|---|
| 命令表收口 | 纯内部重构 | 低 | 否 |
| `!finish` / 记账 | 改用户可见的 `history` 内容 | 中 | 否 |
| `DisplayBundle` | 新协议，改渲染层与所有前端 | 中高 | **是** |

`DisplayBundle` 的契约是「`text` 必有，`json` / `html` / `image` 按前端能力取」。
而 0.76 之后经 `Kernel` 的前端**只有 TTY 一个**（Agent 仍走自己的 `!dispatch`，
要到 `op` 通道落地才接进来）。**只对一个消费者定协议，第二个消费者上线时
几乎必然返工**——这正是 0.76 先搬执行入口、后谈显示的原因。

**决定**：0.77 只做前两件；`DisplayBundle` 推到 0.78，与 `op` 通道同批，
届时可以拿「TTY + Agent」两个消费者压这份契约。

## 2. 命令名单一数据源（V-188）

### 2.1 问题：一个命令名要登记 ~9 处

实施前 `Shell` / `Session` 里同时存在这些命令名清单：

| # | 位置 | 作用 |
|---|---|---|
| 1 | `COMMANDS` | 补全与「是不是内置命令」的闸门 |
| 2 | `SHELL-COMMANDS` | 说明哪些由 Shell 分发 |
| 3 | `usage()` 的 `given` | 每个命令的帮助文案 |
| 4 | `help-index()` | 手写的分类名单 |
| 5 | `handle()` 的 `given` | 真正的分发分支 |
| 6 | `OPTIONS` | 选项补全用的 flag 表 |
| 7 | `Session.render` 的 `SHELL-OPS` | 哪些 op 按值渲染 |
| 8 | `Session.eval-line` 的早返回分支 | 会话级命令 |
| 9 | README / MANUAL / help 文本 | 给人看的清单 |

漏一处的后果不是报错，是**半截功能**。实测到的两例：

```
hi      -> ("history ",)      ← hint 有完整 usage，却补不出来
plu     -> ()                 ← plugin 完全补不出
help hi -> ("help history ",) ← 连 help 的二级补全也漏
```

`hint` / `plugin` 自 0.66 起就存在，有 76 / 141 字符的用法文本，`help hint`
能查到——但从来不在 `COMMANDS` 里，所以 Tab 永远补不出来。同理
`Session.render` 手抄的那份 `SHELL-OPS` 也没跟上 0.75 新增的
`doc` / `pushd` / `popd` / `dirs` / `bookmark`（它们的 `out` 自带文本，
所以没暴露，但下一次新增命令就会踩）。

### 2.2 决定：名字归组，其余派生

```raku
my constant COMMAND-GROUPS = %(
    shell   => < cd pwd clear ls … bookmark >,   # Shell 真正分发
    session => < history set alias … describe >, # Session.eval-line 早返回
    api     => < write append exec … save-data >,# 只有 Raku 侧 API
);
my constant COMMANDS       = (|COMMAND-GROUPS<shell>, |COMMAND-GROUPS<session>, |COMMAND-GROUPS<api>);
my constant SHELL-COMMANDS = COMMAND-GROUPS<shell>;
```

派生出来的：`COMMANDS`、`SHELL-COMMANDS`、`help-index` 的三段分类、Tab 补全
候选、以及 `Session.render` 的 op 名单（新增
`Shell.command-names` / `Shell.shell-command-names` 两个访问器，渲染层不再抄写）。

**没有合并的两处，以及为什么**：

- `usage()` 的文案：一段 40 条、每条几行的帮助文本塞进数据表会淹没结构，
  而且 `usage()` 还被当作「这个命令是否存在」的判据。保留，但由 `t/37`
  断言「每个登记的名单都有非空用法」。
- `handle()` 的 `given` 分发体：分支要调私有方法（`self!cmd-ls(@args)`），
  无法从纯数据生成。保留，但 `t/37` 做**双向**断言：表里每个名字都必须有
  分支；分发表里不许有表外分支。

结果是「新增一个命令」从 ~9 处降到 4 处（组声明 / 用法文案 / `OPTIONS`（仅当
真有 flag）/ 分发体），其中 2 处有测试守着。

### 2.3 验证：断言有牙

`t/37` 的这两条断言做过变异测试：

| 变异 | 预期 | 实测 |
|---|---|---|
| 从组表删掉 `hint` | 补全 / 用法相关断言挂 | 挂 5 条 |
| 把 `when 'doc'` 改成 `when 'zzz'` | 双向断言都挂 | `缺: doc, dirs` + `多出: zzz` |

另外 `ok @branch-names.elems > 20` 是防空跑断言：正则若退化成匹配不到，
这条会先挂，而不是让「没有表外分支」 vacuously 通过。

## 3. 输入序与格号分离（V-189）

### 3.1 问题：一个 `if` 管两件事

改造前，三个地方都是同一句：

```raku
$!index = $!index + 1;
@!history.push($src);
```

`$!index` 是**格号**（`Out[n]` 与 `perf` 用），`@!history` 是**输入序**
（`history` 显示与 `!n` / `!!` 的编号用）。两者绑在同一句里，于是任何不经过
这三处的输入两个都不进——**会话级命令**（`config` / `alias` / `log` /
`hint` / `plugin` / `describe` / `set` / `perf`）走的是 `eval-line` 的早返回
分支，一处都不占。

实测（改造前）：

```
> 40 + 2
> config set clock on
> !!
history 内容: ["40 + 2", "40 + 2"]
!! 重放了什么 -> 42
```

用户敲过的 `config` 那行**凭空消失**，`!!` 退回更早的求值。同类的还有
**失败的 Raku 格**：`!eval-raku` 只在 `$ok` 分支里记账，所以 `die "x"` 也不进
history。

### 3.2 决定：记账收口到一处，两个计数分开

`eval-line` 拆成两段：

```raku
method eval-line(Str $line --> Result) {
    my Result $r = self!eval-line-body($line);
    self!finish($line, $r);       # 唯一记账点
    $r;
}
```

`!eval-line-body` 里有十几处 `return`（会话命令、`!` 前缀、Shell 薄层、Raku
求值…），逐个补 `@!history.push` 正是以前漏掉一半的成因；包一层之后，
**记账只有一处**，新增会话命令不可能再漏。

`!finish` 的三条规则：

1. **空行与续行中间态不记**（`op<more>` 是 `for ... {` 只敲了一半）。
2. **多行格记完整源码**，不记最后一行——否则 `history` 里只剩半个 `for`。
   源码由 `!eval-line-body` 在调用 `!eval-raku` 前存进 `$!cell-source`。
3. **`!!` 的外层不记**（内层已经把展开后的真实命令记过），否则用户敲一次
   `!!`，history 里会多出一条从未存在过的命令。

`$!index`（格号）**刻意不动**：

- 「失败的 Raku 格不占 `Out[n]` 编号」是既定契约（`t/07` 有断言
  「失败格不占 Out 编号」），不能因为记账改造而改变；
- 会话级命令不是求值格，占号会让 `Out[n]` 在用户眼里跳号，比现在更糟。

所以两个计数的关系是：**每一行输入都占输入序；只有成功的求值/执行格占格号**。
`Out[n]` 的 `n` 是格号而不是「第 n 个输出」，这与 IPython 的 `In[n]` / `Out[n]`
同构（`x = 1` 只占 `In`，不产生 `Out`）。

### 3.3 结果

```
> 40 + 2
> config set clock on
> !!
history = ["40 + 2", "config set clock on", "config set clock on"]
!! 重放 -> clock=on
```

`history` 的编号与 `!n` 指向同一行（`t/37` 断言 `!2` 打到的正是
`history` 里显示的第 2 行）。

## 4. 边界

- **不做**：`Out[n]` 改成「只对产生输出的格递增」。那会让编号与 `perf`、
  与既有断言全面漂移，收益只是好看一点。
- **不做**：给 `history` 加上限。`@!out` 有 1000 上限，但 `history` 截断会让
  `!n` 的编号含义漂移，属另一件事。
- **不做**：把 `Command` / `CommandRegistry`（DSL 的 `commands()`）并进
  这张表。那是**带 `ParamSpec` 的强类型 API 面**，与「文本命令名」不是同一种
  东西；它们的重名是刻意的（同一个 `Sys` 语义）。HANDOFF §5.2 的「影子 API」
  仍记为已知债。
- **不做**：`DisplayBundle`。见 §1。

## 5. 验收

- `t/37-command-table.t`（49 断言）：名单三视图一致、`hint`/`plugin` 可补全、
  每个名单都有用法、分发表**双向**一致、`OPTIONS` 键合法、渲染 op 名单覆盖
  新命令、帮助索引按组生成；会话命令/失败格进 history 但不占格号、多行格记
  完整源码、`!!` 不重复记、`!n` 与 `history` 同源、空行不记。
- 既有 37 个测试文件全绿（尤其 `t/05` 的格号、`t/07` 的 `Out[n]` 与
  「失败格不占编号」、`t/19` 的 history 行为）。
- 双平台：Windows `prove6`、WSL `run-all.sh`、真 TTY 自检工具。

### 5.1 附带修掉一个「假绿」自检工具

`tools/tty-cjk-win.py` 的 `ls 中文目录` 一项，把夹具建在 `tempfile.mkdtemp()`
的临时目录里，却让 REPL 在 `cwd=ROOT` 下运行。0.76.1 那次自检之所以通过，
是因为仓库根**恰好**还留着一个手工复现用的 `中文目录`——验收前清理掉之后，
0.77 的验收立刻把它照出来了（`ls` 报 exit=1，工具报「没有列出内容」）。

这是最阴的一类假绿：失败信息看起来像功能坏了，实际是被测对象和夹具不在同一
个目录。已改成「临时目录建夹具 + REPL 也在该目录运行，`-I` 与脚本走绝对路径」，
并重跑确认 4/4。**教训**：任何「建临时目录」的自检，都要确认被测进程的 cwd
真的落在那儿，否则那个目录只是摆设。

### 5.2 顺带查实 V-176 的一个静默降级

把 `t/33` 的「普通文件 → 无色」改成自建夹具后，WSL 侧仍挂了一条，继续挖出两件事：

1. **从 drvfs（`/mnt/c`）同步过来的树，每个文件都是 `777`**，于是
   `META6.json` 被判成可执行、着成粗绿。这是夹具问题，不是产品回归 ——
   但它说明「拿仓库文件当夹具」本身就是错的，`t/33` 已改成自建临时文件。
2. **产品真有 bug**：`path-color` 里写的是 `try { $p.x }`，而 `.x` 在本版
   Rakudo 的 Win32 上直接抛 `rindex search target requires a concrete
   string, but got null`。异常被 `try` 吞成 `False`，结果是
   **Windows 上从来没有把 exe 标绿过**，而且不报错、没有任何迹象。

已修：新增 `Chrome::is-executable`，POSIX 看执行位、Windows 看扩展名
（`exe/bat/cmd/com/ps1/msi`）；`path-color` 的两个 `try` 也补了 `// False`
兜底。`t/33` 增两条分平台断言（Windows：`.exe` 粗绿、`.md` 无色；
POSIX：置执行位后粗绿）。

教训和第二件同源：**`try` 吞掉的异常不会消失，只是变成了「功能静默不生效」**。
着色这类「缺失也不报错」的能力尤其危险，必须有断言盯住正例。
