# ADR-0026 · 结构化管道：Stream 与「记录喂给子进程」

- **日期**：2026-11-16
- **对象**：`main` @ 0.90.0 → 0.91.0
- **状态**：已实施
- **输入**：能力盘点里「结构化管道」被列为优先级 2（`|` 不做，向 nushell 靠拢）
- **相关**：[ADR-0001](ADR-0001-raku-native.md)（Raku 原生、不加第二套语法）、
  [ADR-0005](ADR-0005-data-workbench.md)（Table / Cursor / Engine）、
  [ADR-0024](ADR-0024-exec-stream.md)（`!` 的流式与元选项）、SPEC V-901 / V-237…V-244

## 1. 问题

Rakuish 有 `Table`（急值）和 `Cursor`（惰性、只服务数据库），但没有一个东西同时满足：

1. **文本进得来**：`! find . -name '*.raku'` 的输出是 `Result.out`，只能当字符串看；
2. **中间不物化**：`ls-table()` 是急值的；`explore` 里对 10 万行做一次 `where`
   就要先有一张 10 万行的表；
3. **出得去**：`Table` 不能喂给外部命令的 stdin —— 这是 shell 管道的另一半，
   `!` 只能往外吐，接不回来。

第二条容易被忽略：`Cursor` 已经有惰性，但它只从 SQL 来。文本来源（`!`、
文件、CSV）没有对应的惰性通道，于是「管道」在最常见的入口上直接断掉。

## 2. 决策：`Rakuish::Data::Stream`

一个 Stream 是**惰性的记录序列**（`Seq` of `Hash`），四个动作：

| 方向 | 入口 | 说明 |
|---|---|---|
| 文本 → 记录 | `stream(Str, :format<lines|csv|tsv|json|jsonl|pattern>)` | 六种格式，未知格式报错 |
| Result → 记录 | `stream($result)` | `!` 的直接产物；失败 Result 明确抛 |
| Table → 记录 | `stream($table)` | 复用现有 Table，不重写 |
| Cursor → 记录 | `stream($cursor)` | 真惰性；标记为一次性 |
| 记录 → 表格 | `.table` / `.text` / `.json` / `.csv` | 借 Table 的排版与序列化 |
| 记录 → 子进程 | `.exec($exe, @args, :format<lines|csv|tsv|json>)` | 写 stdin，走会话 Sys |

阶段：`where` / `select` / `drop` / `map` / `add-column` / `limit` / `skip`
是**惰性**的；`sort-by` / `unique` / `count-by` / `group-by` 是**物化边界**，
方法注释与手册都写明，不假装惰性。

### 2.1 不加管道语法

`|`、`>`、`&&`、`$?` 是 V-901 的「永不支持」，理由不变：Raku 里这些字符
各有含义，硬解析会得到一套半像 shell 半像 Raku 的方言。

`|>` 曾经是候选，**但它在 Raku 语法里不可定义**：

```text
$ raku -e 'sub infix:<|>($a, &b) { b($a) }; say 5 |> { $_ * 2 }'
===SORRY!=== Error while compiling -e
Preceding context expects a term, but found infix > instead.
```

`|` 之后接 `>` 会被切分成两个 token。所以「管道」只剩两条合法形态：

```raku
# ① 方法链（主推）
stream($r).where({ .<line> ~~ /\.raku$/ }).select('line').limit(10).lines;

# ② 原生 feed：==> 把左值放在**最后一个参数位**
sub only-raku($s) { $s.where({ .<line> ~~ /\.raku$/ }) }
only-raku(stream($r)).table;
stream($r) ==> only-raku();
```

`==>` 派生的 `a ==> f(b)` 实测等价 `f(b, a)`，所以阶段 sub 的签名要把数据放最后。
这是 Raku 的既有语义，不是我们的发明。

### 2.2 一次性来源必须报错

Cursor / 子进程通道只能读一次。第二次取**抛 `X::Rakuish::Data`**，不返回空流：
空流会让用户以为「没有数据」，而实际是「已经读完了」。重复来源（文本 / Table /
List）可以反复消费，`$!taken` 只在 `repeatable` 为假时生效。

### 2.3 列顺序由解析器给出，不靠 Hash 顺序

实测踩过：CSV 解析出 `name,size`，经过 `Table.rows` 再推断列就变成 `size,name` ——
Raku 的 Hash 不保证插入顺序。所以每种文本格式在解析时就返回 `columns`，
`stream()` 把它带进 Stream，`select` / `drop` 也据此维护列。

### 2.4 数字字符串参与计算

CSV / `!` 输出里的数字是 `Str`，`~~ Numeric` 会全过滤掉（实测 `sum('size')`
对 CSV 返回 0）。`!numeric` 在 `Numeric` 之外再认一次字面量
`/^ '-'? \d+ [ '.' \d+ ]? $/`，不做进制 / 千分位 / 科学计数法——
那些应该由数据引擎（DuckDB / SQLite）处理，不该在字符串层猜。

### 2.5 出口走会话 Sys

`.exec` 不自己起进程：`$*RAKUISH-SYS` 存在时调用 `sys.exec(..., :in($text))`，
cwd / 环境 / 超时 / 审计与 `!` 完全同一条路。没有会话上下文时明确报错，
不静默换一条绕过审计的路径。

`Sys::Proc.spawn` 的 `:$in` 是 0.79 就有的参数，但**此前没有任何调用方**
（和 `:&on-out` 一样属于「值存在、接线缺失」）。这次两个都接上了。

## 3. 被否掉的方案

| 方案 | 为什么不 |
|---|---|
| `pipe(cmd1, cmd2, ...)` 接字符串命令 | 那就是在 Raku 里重建 shell 语法，正中 V-901 |
| `a |> b` 自定义运算符 | Raku 语法不允许（见 §2.1） |
| 把 `Table` 改成惰性 | Table 已经是「可 `.to-text` 的急值」契约，到处依赖；改它等于重写数据层 |
| 让 Stream 自己实现一套表格渲染 | 展示层必须只有一套排版（ADR-0016 同一条原则），Stream 一律 `.table` 后借 Table |
| 自动把 `!` 的输出变成流 | 隐式转换会让 `!` 的 `Result.out` 语义分叉；显式 `stream(cmd-result('! ...'))` 更清楚 |

## 4. 边界（如实记录）

- `sort-by` / `unique` / `count-by` / `group-by` **必须物化**；对超大 Cursor
  使用会拉到内存里。真正的「边排边出」需要外部归并，不做。
- 没有 `join` / `tee` / `zip`：两个流同时消费的生命周期语义没想清楚，先不做。
- `.exec` 把**整份**结果写进 stdin（`Proc::Async.write` 一次），不是边算边写；
  超大结果会先拼成字符串。要真流式得改 `Sys::Proc` 的写入契约，单独一个 ADR。
- `stream()` 的 `:format` 只对文本有意义；对 Table / Cursor 传了会被忽略。
- 展示（`Session.render` / `Display`）会消费一次流；一次性来源展示后不能再取，
  错误信息会指回来源。
- Windows 上没有额外分支：文本按 `\n` 切，CRLF 由 `Str.lines` 处理。

## 5. 验证

`t/46-stream.t`（53 断言）：六种文本格式与列顺序、字符串数字求和、
where/select/sort/unique/count-by/group-by/add-column/drop/map、
「limit 只拉三行」的惰性断言、Table/Cursor 入口、失败 Result、游标二次消费报错、
`.exec` 的 stdin 三行往返与 `:format<csv>` 表头、Session 渲染与 DSL `stream()`。
