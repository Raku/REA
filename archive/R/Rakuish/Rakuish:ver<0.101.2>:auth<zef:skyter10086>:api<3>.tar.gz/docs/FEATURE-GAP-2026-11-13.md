# Rakuish 横向能力盘点：fish / xonsh / IPython

> 基线：Rakuish **0.74.0**（`HEAD` = 已推送版本，2026-11-13）。
> 本文是**只读分析**，未改产品代码、未升版本、未提交。
> **0.80.1 校准（历史快照，勿把「待办」当现状）**：基线是 0.74.0 ——
> A1/A2/A3 三处硬伤已于 0.75.0 订正（`Ctrl-X Ctrl-E` 移除宣称、
> `theme`→`color`、provides 27→29→34）、A6 两套命令表于 0.77.0 单源化、
> B 类多项（`doc` / 目录栈 / 书签 / 会话日志 / 选项补全）于 0.75.0 落地、
> 0.78.0 补了 `display` 但仍**无 HTML 富输出**。
> **0.100.0 校准**：A5 / P1-1 / P1-3 / P1-6 / P1-7 已落地（ADR-0034：
> 模糊补全回退、错误态高亮、候选菜单 ShiftTab、灰字建议、Ctrl-R 循环
> 检索；鱼式模态增量搜索仍列为边界）。补全来源扩展（建议取自补全 /
> 路径）与 Tab-Tab 菜单见 ADR-0034 §4 后续清单。
> **§6 的 C 类护栏与四者定位对比依然有效**，这是本文现在的主要价值。
> 逐项状态见 [`ADR-INDEX.md`](ADR-INDEX.md) §5；CI 一项见 [`CI.md`](CI.md)。
> 参照版本：fish 4.9.3（官方文档标题）、xonsh 0.25.0（教程页标题）、IPython 9.18.1（2026-11-02 发布）。
> 口径说明：用户所写「xoshell」无同名 shell 项目（搜到的 Xshell 是 SSH 终端模拟器，非同类），
> 本文按 **xonsh** 理解 —— 它和 fish、IPython 恰好构成「交互 shell / 语言融合 shell / 计算型 REPL」三个参照系。

---

## 0. 一句话结论

Rakuish **不是 shell**，是「Raku 原生 REPL + 数据工作台 + 受控 Agent 服务」。所以对比出来的「缺」必须分三类，混在一起会得出错误结论：

| 类别 | 含义 | 数量 | 建议 |
|---|---|---|---|
| **A. 实现不完整 / 文档不一致** | 宣称有、实际没接线；或键值 inert；或能力只做了一半 | 3 处硬伤 + 5 处半截 | **该修**，成本极小 |
| **B. 同类普遍有、Rakuish 没有，且不违反规格** | 自动建议、语义补全、对象内省、会话日志、目录栈等 | 约 8 项 | 可选，按性价比排 |
| **C. 规格明确不做** | 管道/重定向、`%magic`、auto-shell、持久求值器、SQL AST 补全、`fg`/`bg` | V-90x 系列 | **不要补**，别被对比带偏 |

Rakuish 有两块是三个参照**都没有**的：内置数据栈（Table / Cursor / DuckDB+SQLite / Parquet / CSV / 分页 / SQL 上下文补全）和受控服务化（Sandbox / JSONL+TCP Agent / worker 硬取消 / 审计 / 限额）。差距主要在**交互手感**（fish 那一层）和**探索性计算体验**（IPython 那一层），不在底层能力。

---

## 1. 四者定位差异（先对齐口径）

| 维度 | fish 4.9.3 | xonsh 0.25.0 | IPython 9.18.1 | Rakuish 0.74.0 |
|---|---|---|---|---|
| 本质 | 交互式 Unix shell（自带脚本语言） | Python 3 超集 shell | Python 增强 REPL / Jupyter kernel | Raku 原生 REPL + 数据工作台 + Agent |
| 输入默认语义 | 命令 | Python 表达式 / 子进程的**歧义消解** | Python 表达式 | Raku 表达式（`!` 前缀才走外部 argv） |
| shell 语法 | 完整（管道、重定向、`$()`、glob） | 完整 + Python 混写（`$(...)`、`@()`） | 部分（`!`/`!!` 转义到 shell） | **明确不做**（V-901），`!` 是 argv-only |
| 扩展机制 | `~/.config/fish/{functions,completions}` 自动发现 + 主题 | xontrib（entrypoint / RC / 运行时 load / unload） | extension + magic 注册 + PyPI 生态 | 显式本地 Raku 文件 `plugin load`，默认 off，不持久化 |
| 平台 | Unix-like（v4 起 Rust） | Linux / macOS / Windows / WSL / Android / Jupyter | 全平台（终端 + 浏览器） | Windows 11 + Linux/WSL 双平台，Windows 有明确降级项 |
| 主要受众 | 日常命令行用户 | 想用 Python 写 shell 的人 | 数据科学 / 探索性编程 | Raku 学习者 + 本地数据操作 + 受控远程执行 |

**关键判断**：fish 与 xonsh 的「管道 / 重定向 / 作业控制」是它们的**本体**，Rakuish 的 V-901 / V-902 恰恰把这些列为「永不支持」（`SPEC.md:24-26, 63-64, 881-886`）。拿这一栏说 Rakuish「不完整」是口径错误。

---

## 2. 能力矩阵

标记：`✓` 完整且有交互闭环 · `△` 部分/受限/需插件 · `—` 无或明确不做。

| 能力轴 | fish | xonsh | IPython | Rakuish | Rakuish 现状与证据 |
|---|:--:|:--:|:--:|:--:|---|
| 输入行语法高亮 | ✓ | ✓ | ✓ | △ | 0.74 单行词法（注释/字符串/数字/变量/关键字），`Highlight.rakumod`；**不检测错误**、不做 `q[]`/正则/多行（V-177） |
| 输入时自动建议（灰字 ghost） | ✓ | △ | △ | — | 只有主动的 ↑ / Ctrl-R 历史检索，`bin/rakuish:342-360` |
| 语义 / 上下文补全 | ✓ | ✓ | ✓ | △ | 前缀匹配 + SQL 上下文启发式；**无 Jedi 式语义补全、无命令选项补全**（`Shell.rakumod:864-910`） |
| 补全菜单 / pager / 搜索 | ✓ | ✓ | ✓ | — | Tab 直接插候选，无候选列表UI、无过滤搜索 |
| 历史与检索 | ✓ | ✓ | ✓ | △ | ↑/Ctrl-R、`!!`/`!n`/`!-n`、`~/.rakuish-history`；无 `%history -f` 式导出/回放 |
| 别名 / 缩写 / 函数 | ✓ | ✓ | △ | △ | `alias` 只展开首词、最多 10 层；函数用 Raku `sub`；**无 `abbr` 式「输入时展开可见」** |
| 对象内省 `?` / `??` / 源码 | △ | ✓ | ✓ | △ | `help()` / `<cmd> --help` / `which` / `hint`；**无 `?`/`??`、无 docstring/源码查看** |
| 富输出（HTML / 图片 / MIME） | — | △ | ✓ | — | Renderer 只有 `text / json / markdown`（`Renderer.rakumod:32`）；无 display protocol |
| 管道 / 重定向 | ✓ | ✓ | △ | — | **V-901 永不支持**；由 Raku 的 `.lines` / `run` 组合表达 |
| 语言 × 命令混写 | △ | ✓ | △ | △ | `!` argv-only；`$(...)` 捕获、`@()` 插值、反引号 shellq 均不做（V-901/902） |
| 作业控制 `fg`/`bg`/Ctrl-Z | ✓ | ✓ | — | △ | 0.73 只做 **POSIX 前台进程组交接**（`PosixSpawn.rakumod`）；无作业管理（V-175） |
| 插件 / 扩展生态 | ✓ | ✓ | ✓ | △ | 显式本地文件 load、默认 off、不自动发现、不持久化、非沙箱（V-156） |
| 数据 / SQL 工作流 | — | △ | ✓（生态） | ✓ | **Rakuish 独有强项**：Table/Cursor/DuckDB+SQLite/Parquet/CSV/分页/describe |
| 会话日志与回放 | △ | △ | ✓ | — | 只有历史落盘；无 `%logstart` / `%store` / 会话导出 |
| 调试 / 性能剖析 | — | △ | ✓ | △ | 有 `timed`/`bench`/`perf [N]`；**无 post-mortem 调试器**（`%debug` 对应物） |
| 目录栈 / 书签 | ✓ | △ | ✓ | △ | 只有 `cd -`（`prev-cwd`）；无 `pushd`/`popd`/`dirs`/`%bookmark` |
| 主题 / web 配置 | ✓ | ✓ | △ | △ | `prompt-style` 三档 + 颜色开关；**`theme` 配置键 inert**（见 §4） |
| 受控沙箱 / 远程 Agent | — | — | △ | ✓ | **Rakuish 独有**：Sandbox + JSONL/TCP + worker 硬取消 + 审计 + 限额 |

---

## 3. 逐轴要点：三个参照各自强在哪

### fish —— 交互手感的标杆
- **autosuggestions**：随输入实时给灰色建议，来源 = 历史 + 补全 + 合法路径；`→`/Ctrl-F 接受整句，Alt-`→` 接受一词（官方文档 Interactive use）。
- **completion pager**：多候选时插最长公共前缀并弹出可导航菜单，Ctrl-S 进搜索；命令专属补全可从 man page 生成，也可放 `~/.config/fish/completions/` 自动加载。
- **高亮的核心是「报错」而不是「染色」**：能标出不存在的命令、读写不存在的文件、错误的重定向、括号不匹配。这一层 Rakuish 完全没有 —— 0.74 的高亮是纯词法 token 染色（`ADR-0011 §4.3`）。
- **abbr**：`gco` 输入后按空格展开成 `git checkout`，展开结果可见、可改、进历史；比 alias 强。
- **universal variables / event handler / fish_config web UI / 主题**：`set -U` 跨会话即时传播，`--on-variable` 事件让所有会话同步换主题。

### xonsh —— 语言融合的标杆
- **同一行混写**：`len($(curl ...))`、`echo @(name) > /tmp/@(name)`、`$PATH.append('/tmp')`。`$(...)` 捕获 stdout、`@()` 把 Python 表达式插值进 subprocess 参数、`${expr}` 动态取环境变量、`$[ls -l]` 显式强制子进程模式。
- **Python 模式 / subprocess 模式歧义消解**：整行找不到名字就尝试按命令解析，任何不确定都偏向 Python 模式。
- **xontrib 生态**：补全器、prompt 字段、`on_chdir`/`on_postcommand` 事件、history backend、整块子系统都能替换；支持 entrypoint 自动加载、运行时 `load`/`unload`、`xontrib list --json`。
- **一等 Windows 支持**、Jupyter kernel、调用其它 shell（`xontrib load sh`）。

### IPython —— 探索性计算的标杆
- **`?` / `??`**：docstring、签名、源码即时查看。
- **magic 双层**：line magic（`%run` / `%timeit` / `%debug` / `%history` / `%store` / `%logstart` / `%edit` / `%load` / `%who` / `%bookmark`）与 cell magic（`%%writefile`、`%%bash`、`%%timeit`），`%alias_magic` 还能给 magic 造别名。
- **Jedi 语义补全**（属性 / 方法 / 文件名）、`In[n]`/`Out[n]`/`_` 结果缓存、`_dh`/`_ih` 会话变量。
- **rich display**：`_repr_html_` / PNG / LaTeX 等 MIME bundle，matplotlib 内联；Jupyter kernel。
- **会话日志 / 回放 / 跨会话变量**（`%logstart`、`%store`），`%pdb` 自动进入 post-mortem。

> 注意 IPython 的 `%` magic 之所以可行，是因为 `%` 在 Python 里不是合法一元运算符。**Raku 里 `%` 是哈希 sigil**，这正是 V-902「不保留 `%magic`」的技术根因 —— 不是不想做，是语法上会撞车。

---

## 4. 真正「实现不完整」的地方（A 类，带证据）

### 4.1 宣称有、实际没接线 / 键 inert

| # | 问题 | 宣称处 | 实际 | 影响 |
|---|---|---|---|---|
| A1 | **`Ctrl-X Ctrl-E` 外部编辑器** | `bin/rakuish:83`（`--help` 明写「Ctrl-X Ctrl-E 外部编辑器」）、`docs/ADR-0001:122` 把它列为四个交互动作之一 | 只有 `Session.rakumod:1266`（`key-bindings` 描述）、`:1296-1297`（`handle-key` 返回 `edit-request`）与 `t/05:268` 的值 API 断言；`Keymap.rakumod` 的 `make-cli` / `vi-actions` / `apply-keymap` **没有绑定该键**，入口也没消费 `edit-request` | 用户按这个键什么也不会发生；把「值 API」当成了「接线完成」 |
| A2 | **`config set theme ...` 是 inert 键** | `README.md:134-135`、`docs/MANUAL.md:850-852` 拿它当 config 用法示例，`t/05:129-136` 断言 set/get/持久化 | `lib/` 全库 **无任何代码读取 `theme`**（Grep 零命中）；`Session.rakumod:191-225` 的 config 是纯扁平 KV | 用户设主题毫无效果，且测试只验证了「KV 能存」，制造假绿 |
| A3 | **`HANDOFF.md:40` 写 `模块 provides | 27`** | 文档基线表 | `META6.json` 实际 **29**（0.73 加 `Sys::PosixSpawn`、0.74 加 `REPL::Highlight`），`t/51` 守的是 29 | 文档陈旧；`ROADMAP` / `README` 已是 0.74 口径，HANDOFF 没跟上 |

> 顺带核对：README 本身**没有**宣称 `Ctrl-X Ctrl-E`（只列 Up/Down/Ctrl-R/Ctrl-A/E/Ctrl-C/Ctrl-D/Tab），所以不一致集中在 `bin/rakuish --help` 与 ADR-0001。

### 4.2 能力做了一半、且被当成「已完成」

| # | 半截处 | 具体表现 | 为什么算半截 |
|---|---|---|---|
| A4 | 语法高亮只做词法 | 不识别 `q[...]` / `qq[...]` / heredoc / 正则字面量 / 多行 / pod（V-177）；无错误态着色 | Raku 是重度使用 `q[]`、正则、quote-like 构造的语言，最常见的一行代码反而染不对；fish 高亮的核心价值（命令/路径存在性、括号匹配）完全没有 |
| A5 | 补全只有前缀 | `Shell.rakumod:872/881/906` 全是 `.starts-with`；无命令选项/参数补全，无候选菜单，无模糊/纠错 | 有 `usage()` 表（`Shell.rakumod:437-509`）却没复用到 Tab 上；SQL 侧有元数据驱动，命令侧反而更弱 |
| A6 | 两套命令表并存 | Shell 薄层 24 个分发命令（`SHELL-COMMANDS`）+ `COMMANDS` 40 项（含只用于 help/补全的 Raku API 名）+ Session 拦截的一批会话级命令 | `HANDOFF §5.2` 自己记为「影子 API，要持续防止两套语义漂移」；用户无法从一处查到「我到底能敲什么」 |
| A7 | 插件机制 | 显式本地文件、默认 off、不自动扫描、不持久化、不开机加载、加载即执行（非沙箱）、不进 Shell 命令表、Agent 不开放 | 相对 xontrib / fish functions / IPython extension，缺的是「发现 + 自动加载 + 生命周期」，不只是「能不能加载」 |
| A8 | 作业控制只到「前台交接」 | 0.73 有 `posix_spawnp`+`SETPGROUP`+`tcsetpgrp`+`waitpid`，但无 `&`/`jobs`/`fg`/`bg`/Ctrl-Z；Ctrl-Z 会停住子进程而 REPL 等在那儿 | 这是 V-175 明确划出的边界，**如实标注了**，不算 bug；但从用户视角 `jobs` 命令存在（`!cmd-jobs`），容易误以为是完整作业控制 |
| A9 | PTY 无 stdin 写入 | `pty-exec` 可捕获输出但无可靠 stdin 通道（V-170/V-172），跑交互式 REPL 会挂到超时 | 对「在 Rakuish 里跑另一个 REPL」这个场景是硬缺口（`t/26` 嵌套 REPL 走的是 TTY 直通而非捕获） |

---

## 5. 值得补、且**不违反规格**的能力（B 类，按性价比）

| 优先级 | 能力 | 参照 | 最小落点 | 风险 / 是否需要 ADR |
|---|---|---|---|---|
| P0 | 修 A1/A2/A3 三处不一致 | — | 接线或删宣称；`theme` 要么实现要么从示例移除；`27→29` | 零风险，纯文档/接线，不需要 ADR |
| P1-1 | **命令选项补全**：把 `usage()` 里的 flag 表接到 Tab | fish | `Shell.completions()` 解析首词后的 `-`/`--` 前缀 | 低；纯函数，可单测，不碰语法 |
| P1-2 | **对象内省**：`doc <name>` / `?` 后缀 | IPython / xonsh | 包装 `.WHY`、`.signature`、`.^methods`、`.^name` 成纯函数 + 新 Result 渲染 | 低；不碰 EVAL，不改输入分类。`?` 后缀要确认 Raku 语法不撞车（`?` 是布尔化运算符），建议只做 `doc` |
| P1-3 | **错误态高亮**：命令不存在 / 路径不存在 / 括号不匹配 | fish | 在 `HlField` 之外加一层「语义标记」纯函数，复用 `which` / `Sys.resolve` / `Incomplete.is-incomplete` | 中；要小心不变式（纯文本等价），建议与 ADR-0011 §4 一起评审 |
| P1-4 | **会话日志 / 导出**：`log start|stop|show` | IPython `%logstart` | 复用 `Result.render('text')` 写文件，记录 cell + 结果 | 低；纯 Session 状态，不碰 EVAL |
| P1-5 | **目录栈 / 书签**：`pushd`/`popd`/`dirs`/`bookmark` | fish / IPython | Session 状态数组，扩展现有 `cd -`（`prev-cwd`） | 低；纯 Session 状态 |
| P1-6 | **补全候选菜单 + 过滤** | fish pager | 依赖 LineEditor 内部（同 `HlField`），或退化为「打印候选列表」 | 中高；会加深已有「子类依赖 LineEditor 内部」的缺口 |
| P1-7 | **历史 autosuggestion**（灰字 + `→` 接受） | fish | 同样要覆盖 `visible-input-field-string`，在内容段后追加零宽着色的建议串 | 中高；与 P1-6 同一处依赖，建议合并一次做，只开一个 ADR |
| P2-1 | 富输出（HTML / PNG / MIME bundle） | IPython | 新增 `Result.render('html')` + 一条 `display` 协议 | 高；当前 `Result` 双形态与 Agent 白名单都要动，须独立 ADR |
| P2-2 | post-mortem 调试 / 栈查看 | IPython `%debug` | 捕获异常对象 + 交互式帧浏览 | 高；Raku 异常模型与后端差异，须独立 ADR |

**明确建议**：P1-6 / P1-7 是提升「日常手感」最大的两项，但都压在同一个 `visible-input-field-string` 覆盖点上；0.74 刚加了 `HlField`，把三件事（着色、建议串、候选菜单）**一次性设计**比叠三次补丁好，先写 ADR 再动。

---

## 6. 明确不做（C 类，不要因对比而动摇）

出处：`SPEC.md §8`（V-901…909）、`ROADMAP §2/§5`、`ADR-0001/0005/0006/0007/0010`。

- **V-901**：bash / POSIX 语法（管道、重定向、变量展开、heredoc、`&&`、`$?`）永不支持，用 Raku 表达。
- **V-902**：`%magic` 分流、auto-shell 回退、反引号 shellq 已删除（`%` 是 Raku 哈希 sigil）。
- **V-905**：worker 派生孙进程强杀、跨连接状态共享、可恢复/事务一致性游标不做。
- **V-906 / V-908**：持久求值器 / 常驻编译单元不做；SQL AST 级补全不做。
- **V-909**：交互式子进程自动探测、Agent `tty_exec`、无开关的交互式捕获不做。
- **V-175**：`&` / `jobs` / `fg` / `bg` / Ctrl-Z、SIGWINCH 转发、孙进程树回收不做。
- **V-154 / V-155**：多行 buffer / 可视块 / `.` 重复 / 输入中实时弹窗不做。
- **V-176 / V-177**：`Result.render-result(text)`、`Table.to-text`、Agent 输出不掺 ANSI；高亮不碰 quote-like / heredoc / 正则 / 多行。
- **V-503**：Agent 没有 `eval` op（任意 Raku 代码会绕过 root / 白名单 / 审计）。

`ROADMAP §5` 特意写了「**不把「不做」伪装成「未排期」**」。所以本报告把 C 类单独列出，不混进 B 类的待办。

---

## 7. 工程层差异

| 项 | fish | xonsh | IPython | Rakuish | 备注 |
|---|---|---|---|---|---|
| 自动化测试 | 有 | 有 | 有 | **35 个 `.t` / 1672 断言**（Win）+ WSL `run-all.sh` | Rakuish 双平台 + 真 PTY 工具链（`tty-check.py` 25 项、`tty-termios-win.py`）反而比多数同类更严 |
| 规格 / 决策记录 | 文档 | 文档 | 文档 | **SPEC.md 唯一真值 + V-编号 + 11 篇 ADR + HANDOFF 缺口表** | 罕见的严谨度，是该保持的优势 |
| CI（GitHub Actions） | ✓ | ✓ | ✓ | **无 `.github/workflows`** | 当前靠本地手工双平台验收；脚本 `tools/run-all.sh` 已具备，接 CI 成本低 |
| CHANGELOG | ✓ | ✓ | ✓ | **无**（有 `ROADMAP` + `AUDIT-FIXES-*.md` 逐版记录） | 逐版审计记录实际充当了 changelog，但外部用户不好找 |
| 生态分发 | completions/functions 目录、主题 | xontrib 包 / entrypoint | PyPI extension | 插件只能显式 load 本地文件 | 见 A7 |
| 性能回归门槛 | — | — | — | 有 `bench`/`perf`，但无回归阈值 | 可加「启动耗时 / 大表渲染」基线 |
| 许可 | GPL-2.0 | — | BSD-3 | `LICENSE` 存在 | — |

---

## 8. 建议的下一步（不改产品代码的最小路径）

> **0.80.1 注**：以下 4 条是 0.74.0 时的排期，第 1 条（A1/A2/A3）与
> 第 2 条的 P1-2/P1-4/P1-5 已于 0.75.0 做完，第 4 条的 CI 于 0.80.1
> 以 `tools/ci.sh` 形式落地（云端触发仍未启用）。**第 3 条 C 类护栏仍然有效。**

1. **P0 先清账**（无需 ADR）：A1 接线或删 help 宣称、A2 `theme` 落地或移出示例、A3 `27→29`。这三处都是「文档/测试宣称」与「实际」不一致，属于可信度问题，优先级低于功能但高于新特性。
2. **P1 选一个开 ADR**：推荐先做「补全增强」（P1-1 + P1-6 + P1-7 合并设计），因为 0.74 刚碰过行编辑器，改动面集中；或先做「对象内省 + 会话日志」（P1-2 + P1-4），纯 Session 层、零行编辑器依赖、风险最低。
3. **保持 C 类不动**：任何试图加管道 / `%magic` / auto-shell 的提案，都应先回到 `SPEC V-901/902` 与 `ADR-0001` 讨论定位，而不是当「补缺口」。
4. **工程层**：把已有的 `tools/run-all.sh` + `prove6 -Ilib t` 接一份 CI，是投入产出比最高的一项。

按项目既有惯例，任何新能力都走「先写失败断言 → 再动实现 → 双平台验收 → 版本/文档同步 → 提交并核对 `HEAD == origin/main`」。

---

## 附：核对来源

本地（Rakuish 0.74.0）：`SPEC.md`、`HANDOFF.md`、`docs/ROADMAP-2026-11-11.md`、`docs/ADR-0001…0011`、
`lib/Rakuish/REPL/{Session,Shell,Keymap,Highlight,Hints,Chrome,Plugins,SqlComplete}.rakumod`、
`lib/Rakuish/Data/{Table,Cursor,Engine}.rakumod`、`lib/Rakuish/Data/Engine/{DuckDB,SQLite}.rakumod`、
`lib/Rakuish/Sys/{Proc,PosixSpawn,FS}.rakumod`、`lib/Rakuish/Result/Renderer.rakumod`、`bin/rakuish`、`META6.json`、`t/`。

外部（2026-11-13 查阅）：
- fish 官方文档 <https://fishshell.com/docs/current/interactive.html>（autosuggestions / completion pager / 错误检测高亮 / abbr / 主题）、<https://fishshell.com/>
- xonsh 官网 <https://xon.sh/>、教程 <https://xon.sh/tutorial.html>、扩展 <https://xon.sh/xontrib.html>、对比表 <https://xon.sh/contents.html>
- IPython 官网 <https://ipython.org/>、Built-in magic commands <https://ipython.readthedocs.io/en/stable/interactive/magics.html>、PyPI 功能说明 <https://pypi.org/project/ipython/>
