# ADR-0017 · 流式分帧与请求取消（Agent 协议 v2 收尾）

- **日期**：2026-11-13
- **对象**：`main` @ 0.78.0 → 0.79.0
- **状态**：已实施
- **输入**：ADR-0016 §7 把 `stream` / `cancel` 明确留给 0.79
- **相关**：[ADR-0002](ADR-0002-agent-serve.md)（Agent 协议与 deadline）、
  [ADR-0004](ADR-0004-cursor-worker.md)（硬取消）、
  [ADR-0013](ADR-0013-kernel-frontends.md)、[ADR-0016](ADR-0016-display-bundle.md)
- **对应条款**：SPEC **V-190**（帧）、**V-191**（流式不改结果）、
  **V-192**（能力声明单源）、**V-193**（cancel 边界）

## 1. 问题：协议只能「一问一答」

0.78 的连接是这样一条流水线：读一行 → `handle-line` → 写一行。由此产生两个死结：

1. **没有中间过程**。`exec` 跑 30 秒的构建，客户端 30 秒里一个字节也收不到，
   无法区分「在跑」和「挂了」；`max_output` 到了也只能等进程结束才知道。
2. **没法取消**。`cancel` 如果作为普通 op 走同一条流水线，它只能排在那个
   30 秒请求**后面**执行 —— 语义上等于没有取消。

要同时解决，必须动两处：分帧（一行响应 → 多行）与读循环（串行 → 队列 + 就地
处理 cancel）。

## 2. 决定一：帧只分两种，靠 `event` 键区分

```text
{"id":7,"event":"start","op":"exec"}
{"id":7,"event":"chunk","seq":0,"fd":"stdout","data":"Building...\n"}
{"id":7,"event":"chunk","seq":1,"fd":"stderr","data":"warning\n"}
{"id":7,"ok":true,"code":0,"op":"exec","out":"Building...\n","streamed":true,"chunks":2,...}
```

规则只有一条：**有 `event` 是中间帧，没有 `event` 是响应行**。

为什么不用 `event:"end"`：那样客户端得先判断「这是不是最后一帧」，而
「响应行长什么样」在 0.78 已经定义完了。让响应行**保持原样**意味着
「只读一行的老客户端」仍然拿到完整结果（`out` 是全量，不是最后一块），
`streamed`/`chunks` 是纯增量字段。兼容性靠**形状不变**保证，不靠版本协商。

`seq` 跨 `fd` 共用一个序号：两路输出要能还原**到达顺序**，分开编号就丢了
stdout/stderr 的交替关系。代价是客户端不能按 `fd` 分组推进序号 —— 但那本来
也不是它需要的。

## 3. 决定二：cancel 不进队列

读循环改成：

```text
读一行
  ├─ 超长 → 直接回 400
  ├─ op == cancel → 就地 handle-line（只查 inflight 表，不碰 Sys）
  └─ 其余 → 入 Channel
              ↓
        单个执行器任务串行跑 → 写回（sink 有锁）
```

三条推论，都是必须守住的：

1. **非 cancel 请求仍然串行**。0.78 的「输出 N 行、顺序等于请求顺序」是既有
   契约（`t/06` 的断言），并发执行会把它废掉。串行 + 就地 cancel 同时满足
   「顺序不变」与「取消及时」。
2. **写回必须走同一个 sink 并加锁**。否则 `cancel` 的应答会插进别人
   `start → chunk → end` 中间，客户端解析到「end 之后又来了一个 id 相同的
   响应」。帧的原子性在传输层保证，不在业务层。
3. **收尾要等执行器**。读循环结束（EOF / idle）时先 `close` 队列并 `await`
   执行器，再关 socket，否则最后一帧被丢掉。

## 4. 决定三：可取消面只有 `exec`，且如实报边界

| 情况 | 响应 | 说明 |
|---|---|---|
| 目标不存在 / 已结束 | `409 cancelled=false` | 没有可取消的东西 |
| 非 `exec` 在跑 | `409 cancelled=false` + 原因 | 纯文件 I/O 无法中断，不假装 |
| `exec` 已 spawn | `200 cancelled=true` | 被取消请求回 `code=137` |
| `exec` 还没 spawn 完 | `200 cancelled=true deferred=true` | 记 `cancel-requested`，spawn 后补杀 |

`code=137` 不是新发明的码：`Sys::Proc` 的 `Handle.wait` 早就用
`cancelled ? 137 : …`，`exec` 超时用 `124`。取消沿用同一套，客户端不需要
记第二套映射。

「太早取消」这一格必须有，否则存在一个静默失效窗口：`handle` 先登记 inflight
（cancel 才找得到目标），`exec` 才 spawn 并拿到 handle。中间这段里 cancel
若直接返回「不可取消」，用户看到的就是「我明明取消了，它还在跑」。

## 5. 决定四：流式不改结果语义

`stream` 只影响**中间帧发不发**，不影响 `out` / `value` / `code`。实现上
`!exec-run` 是唯一入口：

```raku
spawn → 登记取消 → wait(:&on-out, :&on-err)   # 有回调就是流式，没有就是 0.78
```

`Handle.wait` 里两个 drain 循环各加一个回调调用点，`max-bytes` 的限流逻辑
原封不动。这是刻意的最小改动：如果为流式另写一条「边收边发」的消费路径，
`max-bytes` / 截断 / `signal` / `out-bytes` 这些既有语义都要复制一遍，迟早漂移。

**超限处理**：`max-output` 是帧预算。发到上限就不再发块（`truncated=true`），
但**继续 drain** —— 不 drain 会把子进程堵在管道上，`exec` 反而挂死。

## 6. 实现陷阱（都实测踩过）

1. **`-> Bool { ... }` 不是「返回 Bool 的块」**。这是「带一个必填位置参数、
   参数名叫 `Bool` 的块」。把它存进 hash 再调用就报
   `Too few positionals passed; expected 1 argument but got 0`，
   而且报错点在**赋值那一行**，极难定位。要返回类型就写 `--> Bool`，
   或者干脆省掉。
2. **回调里不能用 `return` 早退**。回调是跨线程被 `try` 调用的，`return`
   产生控制异常，被 `try` 吃掉后 MoarVM 直接 panic：
   `Did not find expected unwind target frame`。改 `if/else` + 局部标志。
3. **`Channel.Supply` 每次调用都是新的消费者**，不是广播。想「既转发又收集」
   不能 tap 两次（两块数据各拿一半），只能在 `wait` 的 drain 里回调。
4. **`has &.sink` 的属性要用 `self.sink` 取**，`$!sink` 取不到。

## 7. 明确不做

- **`sql_query` 流式**：Cursor 已经是惰性 API（ADR-0004），要流式得先把
  `Table` 的物化语义拆开，属另一件事；`capabilities.stream_ops` 里就没有它。
- **pty_exec 流式/取消**：`pty-exec` 是一次性捕获（V-170），改成流式要重做
  PTY 读写循环与截断规则，本版不做。
- **`execute` op**（Agent 跑任意源码）：V-503 不变。要做得先有
  OS 级受限子进程（rlimit / Job Object / 网络与子进程限制）+ 威胁模型，
  单独立项。
- **请求并发执行**：见 §3 推论 1，顺序契约优先。真要并发，得先给
  「同连接多请求」定义顺序与背压，不能顺手打开。

## 8. 验收

- `t/39-stream-cancel.t`（64 断言）：非流式响应无 `event`/`streamed`/`chunks`
  三键；start → chunk* → end 顺序与 `seq` 连续性；stdout/stderr 分路可辨且
  拼接还原；`end` 无 `event` 且带完整 `out`；不支持流式的 op 零帧；
  无 emit 通道不谎报；超限停发且 `truncated`；cancel 三条边界（无目标 /
  不可中断 / exec 真停 137）；取消后 Agent 仍可用；`capabilities` 报
  `protocol=2` / `stream_ops` / `cancel`；`run-jsonl` 顺序不变；TCP 上帧不撕开、
  普通请求仍只一行。
- 既有 40 个文件全绿（尤其 `t/06` 的 JSONL 顺序、`t/16` 的多连接与超时、
  `t/28` 的 PTY）。
- 双平台：Windows `prove6`、WSL `run-all.sh`、真 TTY 自检。
