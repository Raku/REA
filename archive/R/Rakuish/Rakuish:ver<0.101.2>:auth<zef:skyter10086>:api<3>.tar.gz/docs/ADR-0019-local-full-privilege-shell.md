# ADR-0019 · 放弃 Agent 线，做全权限的本地 shell

- **日期**：2026-11-16
- **对象**：`main` @ 0.80.4 → 0.81.0
- **状态**：已实施
- **输入**：§6 方向议题的三层探针（`PROBE-2026-11-15`、`-11-16-integration`、
  `-11-16-adaptation`），以及用户决定「放弃 agent 做全权限的本地 shell」
- **相关**：[ADR-0001](ADR-0001-raku-native.md)（Raku 原生）、
  [ADR-0002](ADR-0002-agent-serve.md)（Agent 服务，**本 ADR 撤销**）、
  [ADR-0013](ADR-0013-kernel-frontends.md)（Kernel 前端）、
  [ADR-0018](ADR-0018-audit-and-no-agent-scripts.md)（不给 Agent 脚本权限）
- **撤销条款**：V-503（无 eval op）、V-604（exec 白名单）、
  V-607（`allow-code-exec` 闸门）、V-190…V-193（`stream` / `cancel`）、
  V-130 / V-152（Agent op 白名单）
- **保留条款**：V-194…V-196（统一审计）、V-184…V-186（DisplayBundle）

## 1. 决策

Rakuish 不再提供 Agent 线。`bin/rakuish-agent`、`Rakuish::Agent`、
`Rakuish::Agent::Server`、`Rakuish::Agent::Worker`、`Rakuish::Sandbox`
全部删除；`Agent` 协议（JSONL / TCP / 结构化 op / `stream` / `cancel`）
一并撤销。

Rakuish 从此是**一个本地、全权限、Raku 原生的交互式 shell / 数据工作台**：
`rakuish` 就是唯一入口，`!` 起进程、其余按 Raku 求值，没有任何权限闸门。

## 2. 为什么现在能下这个结论

前面三轮一直在「怎么让 Agent 安全地跑源码」上打转，根因是把**并发 +
不可信输入**当成必须支持的前提。三层探针把代价量清楚之后，这个前提本身
被证明不值得：

| 事实 | 来源 |
|---|---|
| 本机 REPL **根本不构造** `Sandbox`，`root` 已是 `/`，Policy 就是 `local` 全开 | 探针①（0.80.2） |
| rakupp 的常驻跨 eval 在 C ABI 层成立，但**一进程一解释器**，与「每连接一个」冲突 | 探针②（0.80.3，并发 `rk_eval` 稳定 SIGSEGV） |
| 换成 rakupp 后全套件只有 27/42；Rakuish 侧能自修到 **36/42 封顶**，剩下 6 个卡在 `:pty` 与 async socket | 探针③（0.80.4） |

最后一条是关键：**rakupp 缺的恰好是 shell / REPL 最核心的两项宿主能力**
（PTY、可靠 socket 收尾）。而这两项之所以成为问题，是因为要给 Agent 一个
「安全执行环境」；只做本地 shell 时，`tty-exec` 直接跑在 MoarVM 上，PTY
一直就是好的。

换句话说：**Agent 线带来的不是能力，是一整套为了弥补它而生的成本**
（Sandbox / 白名单 / op 通道 / 执行闸门 / 流式取消 / 统一审计的 Agent 侧），
而它换来的东西（远程结构化调用）已经被「本地全权限」的体验优势盖过。

## 3. 撤销与保留

### 撤销

| 撤销 | 原因 |
|---|---|
| `bin/rakuish-agent`、`Rakuish::Agent` / `Server` / `Worker` | Agent 线整体下线（1695 行） |
| `Rakuish::Sandbox` | 本机 REPL 从未构造它；全权限后没有「沙箱」这个概念 |
| 结构化 op 协议（JSONL / TCP / `--agent` 转发） | 唯一使用者是 Agent |
| `stream` / `cancel`（V-190…V-193） | 分帧是协议能力，协议没了它就没了对象 |
| `allow-code-exec` 闸门（V-607） | 本机本来就能跑 Raku；闸门只是 Agent 的补丁 |
| `exec` 白名单与 `allowlist`（V-604） | 全权限 |
| `X::Rakuish::Sandbox` 异常名 | 改名 `X::Rakuish::Bound`：它表示「越出工作目录 / 层级过深 / 拒绝删根」，是**防误操作**，不是安全隔离 |

### 保留

| 保留 | 理由 |
|---|---|
| **统一审计**（V-194…V-196） | 用户的硬约束：「每次操作都要有日志记录」。审计与安全壳是两件事，壳撤了账不能撤 |
| `Display::Bundle`（V-184…V-186） | 内容级展示（text / markdown / json）是本地渲染与 `-e` 输出都在用的能力，只有 Agent 的 `display` 字段撤销 |
| `Kernel`（V-182） | 三个本机入口（REPL / `-e` / 脚本）本来就共用它，与 Agent 无关 |
| `pty-exec` / `tty-exec`（V-116、V-155…） | 本地跑 vim / less / 嵌套 REPL 的全部基础 |
| `Sys` 的 root 边界 | 保留但**明确不是安全边界**：默认 `/`（Windows 为当前盘根 + all-drives），只用于「别删根 / 别越出工作目录」的防误操作，测试夹具也靠它做隔离 |

## 4. 本机全权限意味着什么

- **Raku 源码直接 `EVAL`**，不需要 pragma、不看白名单。
- **`!` 直接起进程**，没有 `allow-exec`、没有 `allowlist`、没有 `allow-code-exec`。
- **不再有「Agent 不许做什么」的条款**：那些约束的适用对象已经不存在。
  留着只会让读者以为还有一层边界——正是用户反复否掉的「牌子」。
- 唯一保留的越界检查是 `Sys.resolve` 的**工作目录边界**与「拒绝删除文件系统根」，
  它们防的是手滑，不是攻击。

## 5. 恢复路径

一切都在 `v0.80.4` tag 里（`git checkout v0.80.4 -- lib/Rakuish/Agent.rakumod` 等）。
如果将来真要重开 Agent 线，前提必须先写清楚：

1. 谁是输入方（不可信？并发？），决定了要不要真隔离；
2. 若答案是「不可信」，就照 0.80.0 之前的结论走**外部执行器 / VM**，
   不要在应用层再长一套 Sandbox；
3. 不要再把「Agent 需要 PTY / 异步 socket」的成本转嫁给本地 shell。

## 6. 后果

**好的**：

- 代码少 1695 行、测试少 4 个文件（2075 → 1774 断言）；
- 概念从「两套前端 + 沙箱 + 白名单 + 闸门」收敛成「一个入口、一条审计」；
- 不用再为 rakupp 的 `:pty` / async accept 缺口付费，MoarVM 上的 `tty-exec` 继续工作；
- 文档不再需要对读者解释「为什么明明叫 shell 却不能起进程」。

**代价**：

- 失去远程结构化调用能力（若将来需要，按 §5 重开）；
- `v0.80.4` 之前写的 Agent 客户端全部失效；
- `Kernel` 的 `Policy` 里仍有 `allow-ops` / `limits` / `profile` 这些为 Agent
  设计的字段，本版**没有**拆（`t/35` 有 50 条断言依赖它们的收窄语义），
  它们的定位降级为「本机偏好标签」，不构成任何约束。拆解留到后续版本。
