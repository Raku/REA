# ADR-0035：交互手感后续清单 —— 逐词接受、建议来源、In/Out 引用、名字精确判定

- 状态：**Accepted**
- 版本：0.101.0
- 关联：V-283…V-286；ADR-0034（交互手感层主体，§4 后续清单）、
  ADR-0033（job 帧）、ADR-0021（引擎子进程）、ADR-0011（宽度账本不变式）

## 1. 问题

ADR-0034 §4 记了 5 项后续清单。本轮落地其中 4 项；第 5 项（鱼式模态
增量搜索 + Tab-Tab 菜单）**仍推迟**——它需要 fork 上游 `read-input`
（0.0.23 里 170 行词法闭包），依赖升级即漂移，与「不叠补丁」相悖。

四项各自要解决的问题：

1. **逐词接受**：灰字建议只能 `→`/Ctrl-F 整句吞；fish 的 `Alt-→` 逐词
   接受没有。上游 `decode-keyname` 对 CSI 修饰方向键（`\e[1;3C` →
   `Alt-CursorRight`）有解，键名零障碍。
2. **建议来源**：灰字只取历史，补全候选 / 路径候选（ADR-0034 §2.2
   刻意推迟）没进建议。缺的是「历史无命中时的兜底来源」。
3. **In/Out 引用**：SPEC V-140 定义 `Out[1]` 起是成功格结果历史，但输入
   `Out[` / `In[` 时 Tab 补不出编号，用户得手打。
4. **名字精确判定**：命令不存在的红色标记用启发式（COMMANDS/注册表/PATH），
   用户上一格定义的无括号 listop（`foo bar`）会被误标；跨格 `my` / `sub`
   的名字只有引擎侧知道。

## 2. 决策

### 2.1 逐词接受（V-283）

`HlField.edit-accept-suggestion-word`：取 `$SUGGEST` 的**第一个词**
（连续非空白字符）插入，`$SUGGEST` 消费掉已插入部分，剩余留待下一次
`Alt-→`。绑定 `Alt-CursorRight`（上游 `decode-keyname` 支持）。无建议时
退化为 `move-word-forward`（不改 `Alt-→` 的默认上游义——上游未绑定，
 Accept 无建议时不吞键）。`→`/Ctrl-F 整句接受语义一字不改。

### 2.2 建议来源扩展（V-284）

`suggest-suffix($line, @history, @completions)` 的 `@completions`（ADR-0034
就留好的参数）接上 `GET-COMPLETIONS` 的结果。成本纪律：

- **顺序**：历史优先，历史有命中就不调补全 provider（补全可能触发目录
  扫描 / SqlComplete 引擎元数据查询）；
- **缓存**：`suggest-suffix` 是纯函数，但 provider 有 IO；在 HlField 缓存
  「(buf, pos, history-命中?) → 补全候选」，同一行重绘不重复扫盘；
- **宽度**：仍只进 padding 区，ADR-0011 宽度账本不变式不动；
- 路径建议天然来自补全表（Shell.completions 的路径分支），不另起通道。

### 2.3 In/Out 引用补全（V-285）

`Session.completions` 在 `Shell.completions` 之前先识别 `In[` / `Out[`
上下文（正则 `/\b (In|Out) \[ (\d*) $/`，光标紧跟在 `[` 后或数字后）：
从 `@!out.elems` 生成 `In[1]`…`In[N]` / `Out[1]`…`Out[N]` 候选（完整替换
行，带 `]`），补在数字前缀上。此逻辑在**引擎侧** Session 里（它持有
`@!out`），走既有 `complete` RPC，不需扩协议。前端 Proxy 自动受益。
SQL 上下文 / Shell 命令补全优先级不变——只在 `In[`/`Out[` 形态命中时接管。

### 2.4 名字精确判定（V-286）

`Session.error-marks` 的 `known-command` 回调加一层引擎侧名字查询：

- `foo` 若已在 `@!decls`（跨格 sub/class/use 声明，`<name>` 字段）或
  `%!state`（跨格 `my` 变量，去 sigil 后同名）里，视为已知，不标红；
- 判定在引擎侧 Session 内完成（它持有这两个结构），走既有 `error-marks`
  RPC，**不扩协议**；
- 命令名仍以 usage / 注册表 / PATH 为准，名字判定只是**消除误报**，
  不把任意名字当命令补进表；
- 每键成本：`error-marks` 本就已经每键在引擎侧跑（0.100.0 起），这次只是
  在同一个回调里多查两个内存哈希，无新增往返。

### 2.5 接线形态

四项全部走 0.100.0 已有的 provider 槽位 / RPC：`edit-*` 动作表 + bind-key、
`GET-COMPLETIONS` 闭包、`complete` / `error-marks` RPC。缺依赖时优雅降级
（动作不存在则键不绑、provider 异常则建议/标记静默），与 ADR-0034 §2.7 一致。

## 3. 备选（否掉的）

- **fork `read-input` 做鱼式模态搜索 / Tab-Tab**：见 §1，仍推迟。
- **扩 Eval 协议加 `name-visible` / `out-history` 命令**：`error-marks` 与
  `complete` 两个 RPC 本就在引擎侧执行、能直接读 `@!decls` / `@!out`，
  新增协议是纯冗余（多一次设计、多一份双进程对账）。
- **建议来源无条件调补全 provider**：每键扫盘 / 引擎往返，热路径不可接受；
  用「历史优先 + 缓存」把成本压到与 0.100.0 同级。

## 4. 后果

- ADR-0034 的 4 项后续在 0.101.0 落地，`t/57`（纯函数）+ `t/58`（动作层）
  + `t/59`（PTY）+ 新回归（`t/60`）钉住。
- ADR-0011 宽度账本不变式继续成立；`strip-ansi(highlight-line($s, :@marks)) eq $s`
  恒成立。
- 剩余唯一后续项（鱼式模态搜索 + Tab-Tab 菜单）明确留待「拥有输入循环」
  的那次独立改造，与 V-155「不做输入中实时弹窗」一起处理。**该改造的
  成本、三路线对比与重开触发条件见 [ADR-0036](ADR-0036-input-loop-ownership.md)。**
