# Rakuish 规格（Raku 原生命令与脚本环境，API v3）

> **本文件是唯一真值**（0.34.0 / Phase 5b 起，当前 0.101.2）。
> v2 的双语言 REPL（`!` bash 子集 + `%magic` + 独立 shell 引擎）已于 0.34.0 整体删除，
> 仓库里**只有这一套语义**：没有兼容入口、没有 `--v2` 开关、没有 daemon。
> 测试用例的标注必须能在这里找到对应条款（编号 `V-xxx`）。
> 使用说明见 [`docs/MANUAL.md`](docs/MANUAL.md)。
>
> 正文含 0.81 之前 Agent / Sandbox 时代的条款：Agent 线已随 0.81.0 整体删除
> （ADR-0019），那些条款标了历史语境，**不作为现行契约**；现行契约看
> 各节里带「当前」标注的条目与 `docs/ADR-INDEX.md` 的状态列。
>
> 方向依据：[ADR-0001](docs/ADR-0001-raku-native.md) · 原始设计：[DESIGN-RAKU-NATIVE.md](docs/DESIGN-RAKU-NATIVE.md)。
> `META6.api` 为 `3`，与实际宣称一致。

---

## 1. 适用范围与术语

> **读法（0.81.0 起）**：本文正文里凡提到「Agent 的 X」「Agent op 白名单」
> 「Sandbox」的地方，除 §3.12 与 §6 以外，都是**历史记录**（描述 0.80.x 及更早）。
> Agent 线已于 0.81.0 整体撤销，见 §6.1 与
> [ADR-0019](docs/ADR-0019-local-full-privilege-shell.md)。
> 当前实现只有一个入口、没有协议、没有沙箱、没有权限闸门（V-197…V-199）。

| 术语 | 含义 |
|---|---|
| **会话（Session）** | 一个 `Rakuish::REPL::Session` 或 `Rakuish::Sys` 实例；`cwd` / `env` / `root` 是它的对象属性，**不是进程全局** |
| **Sys** | 唯一系统出口：文件、进程、路径解析、环境 |
| **Result** | `ok / code / value / out / err / elapsed / op`，`.Bool` 供 `&&` 短路 |
| **argv** | 外部命令的参数数组；**永不经过 shell** |
| **op** | 结构化操作名（`Kernel` 的 `kind=op` 请求）。0.81.0 起只剩 `capabilities`，其余 501 |

**V-101**：V3 不实现、不扩展 bash / POSIX 语法。`$VAR` / `|` / `>` / `2>` /
`&&` / `||` / glob / heredoc / 命令替换 / `$?` / `$$` 都不是 V3 语法。
需要这些能力时用 Raku 本身（方法链、`Supply`、`&&`、`.subst`、正则）。

**V-102**：脚本就是 Raku 脚本。`.raku` / `.rakuish` 交给默认入口时，
整份源码作为**一个 cell** 求值，预加载 DSL 与 `sys` / `repl` / `registry` 词法绑定；
不解析 shebang、不模拟 `%magic`、不打印 `Out[n]`。
相对路径跟随**调用者 cwd**（与 shell 惯例一致），不是脚本所在目录。

---

## 2. 入口契约（V-11x）

| 条款 | 规则 |
|---|---|
| V-111 | `bin/rakuish`（唯一入口）：无参数 → REPL；`-e <code>` → 求值后退出；`<file> [args...]` → 跑 Raku 脚本；`--help` / `--version` |
| V-112 | ~~`bin/rakuish --agent [args...]` 转发到 Agent 入口~~ —— **0.81.0 撤销**（ADR-0019）：`--agent` 不再是启动参数，输入里写它会被当成 Raku 运算符 |
| V-113 | ~~`bin/rakuish-agent`：Agent 入口（JSONL / TCP）~~ —— **0.81.0 撤销**，入口文件已删除（`t/07` 断言其不存在） |
| V-114 | 入口**只有一个**（`bin/rakuish`）；v2 的 `rakuish-v2` / `rakuish-v3` / `rakuish-sh` 随 0.34.0 删除、Agent 入口随 0.81.0 删除（`t/07` 断言都不存在） |
| V-115 | 入口**不猜参数形态**：参数该落在哪一层由用户显式写出；猜测等于把 `auto-shell` 换成「猜入口」 |
| V-116 | 管道（非 TTY）下不打印提示符，stdout 只有求值结果；TTY 下才显示 banner 与 `rakuish> ` |
| V-117 | 入口的版本常量必须与 `META6.version` 一致（`t/51` 与 `t/07` 守护） |
| V-118 | ~~转发用 argv 数组调用~~ —— 0.81.0 起没有转发（唯一入口）；`!` 的 argv 分词仍不解释空格 / 引号 / `|` / `$` / `&&` |

---

## 3. 输入分类（V-12x）

**V-121**：REPL 每行只有两类输入，没有第三套语言：

| 首字符 | 处理 |
|---|---|
| `!` | argv 分词（空格 + 引号），交给 `sys.exec`；`!=` / `!~~` 仍按 Raku 运算符求值 |
| 其它（**含 `%`**） | Raku 表达式，直接 EVAL；编译 / 运行失败就是失败，**不回退 shell** |

日常命令 `cd` / `ls` / `cat` / `read` / `rm` 等由 Shell 薄层翻译成 `Sys`
调用（V-127），这是**命令别名层**，不是第三套语法；带 Raku 表达式或复杂引号的
输入仍交回 Raku。

**V-122**：`%foo<a>` / `%STATE{...}` 是 Raku 哈希访问，不是魔法命令。
（`%STATE` 是跨格变量的底层哈希，可直接读写；v2 时代的 `%STORE` / `%RC`
已随 0.34.0 删除，`%STORE` 现在会报「未声明变量」。）
V3 没有 `kind-of` 的 `%` 分支、没有 magic handler、没有 magic help 表。

**V-123**：`!` 的分词只处理空格与引号；`$()`、反引号、`;`、`|`、`>`、`*`、`&&`、
heredoc 全部原样作为 argv 元素传入。要管道 / 过滤 / 重定向就写 Raku：

```raku
my $r = sys.exec('git', 'status', '--short');
say $r.out.lines.grep(*.contains('.md'));
```

**V-124**：多行续行用纯 Raku 的括号平衡判定；跨格顶层 `my` / `our` / `state`
由只读扫描器转成 `%STATE` 别名，**每格只 EVAL 当前源码，不重放历史副作用**。
嵌套块里的 `my` 仍是块内局部；纯 `sub` / `use` / `class` / `role` / `grammar`
声明格会缓存并在后续格前置（机制与边界见 V-153）。stdout 直接回显当前格输出，
不打印历史重复内容。

> 历史实现（0.35.2 及以前）靠累积整份源码重 EVAL 保留 `my`，会把上一格的
> `append` / `write` / `exec` 重跑一遍；V-124 已禁止这种做法。

**V-125**：REPL 元能力不是文本命令：`repl.history` / `repl.config<k>` / `repl.trace`
是对象 API，纯交互动作走快捷键（Up / Down / Ctrl-R / Ctrl-C / Ctrl-D / Tab）。
**repl 对象与快捷键禁止直接读写文件、启动进程**——所有系统操作必须过 `Sys`，
否则 Agent 的 Sandbox 会被绕过。**0.75.0 订正**：`Ctrl-X Ctrl-E / edit-request`
曾只在 `handle-key` 返回值、`Keymap` 从未绑定、入口也不消费；补实现又会撞上
本条硬边界（外部编辑器要起进程 + 读写临时文件），故从快捷键表、入口 help 与
ADR-0001 设计表中一并删除（ADR-0012 §1）。

**V-128**：TTY 交互入口使用 `Terminal::LineEditor` 提供行编辑与历史：
Up/Down 翻历史、Ctrl-R 搜索、Ctrl-D 退出；历史默认保存在
`~/.rakuish-history`。Tab 补全命令名、路径和 `help <命令>`。
管道 / 脚本输入仍走普通逐行读取，不输出提示符或终端控制序列。

**V-129**：结构化数据层：
- `Rakuish::Data::Table`：行是 Hash，列为字符串；支持 `where/get/select/sort-by/
  first/last/limit/offset/each/count/sum/mean/min/max/distinct/join`、
  `schema/column-type`、`to-text/to-json/to-markdown`。
- `Table` 类型集合 `int / num / str / bool / datetime / list / map / any`；
  构造时推断，链式操作保留，`join` 合并右表类型。
- `Rakuish::Data`：`open-data` / `save-data` / `from-json-data` / `to-json-data` /
  `from-csv-data` / `to-csv-data`。
- `Sys.ls-table` / `DSL.ls-table` 返回 `Table`，字段至少
  `name/type/size/modified/path`。
- REPL 支持 `open [--raw] 文件`、`ls --json`、`explore [路径]`；
  `glob` 支持 `**/` 递归前缀。
- 数据层只经 `Sys` 读写文件，不绕过 Sandbox
  （Parquet 的显式授权例外见 V-152）。

**V-130**：数据引擎是可选能力：
- `Rakuish::Data::Engine` 定义 `query/execute/tables/schema/close` 契约。
- `Rakuish::Data::Engine::DuckDB` 通过**运行时 require** 使用 `DB::DuckDB`，
  不成为核心依赖；缺失时明确报安装提示。
- 默认只读；只读下 `execute` 和 DDL query 抛 `X::Rakuish::Unsupported`。
- 默认 `enable_external_access=false`；SQL 不能借 DuckDB 的文件函数绕过
  `Sys` 的 root/Sandbox。
- Agent 的 `sql_query` 默认关闭；显式 `--allow-sql --db` 后只允许参数化只读查询，
  不开放 `sql_exec` / DDL / 任意 SQL。

**V-131**：SQLite 是可选的小型事务引擎：
- `Rakuish::Data::Engine::SQLite` 运行时 require `DB::SQLite`，不成为核心依赖。
- 适配器固定一个连接（`:memory:` 不能走连接池，否则每个连接一个库）。
- 参数化 `query/execute` 使用 prepared statement。
- 默认只读；只读下拒绝 `execute` 和 DDL query。
- SQLite 用于小表/应用状态，不作为大分析引擎。

**V-132**：`Table` 值管道至少包含：
`where/get/select/sort-by/first/last/limit/offset/each/count/sum/mean/min/max/
distinct/join`。`join` 默认是左连接，列名冲突时右表列加 `_right` 后缀；
`from-rows` 必须把单行 Hash / Pair 列表归一化成一行 Hash。

**V-133**：REPL 支持 `set -e` / `set +e`：
- `set -e` 打开 strict；任一 shell、`!` 或 Raku 求值失败后设置
  `exit-requested`，退出码取该结果的 `code`（无则 1）。
- `set +e` 关闭 strict；失败只返回错误 `Result`，不退出。
- strict 是会话级状态，不改变单个 `Result` 的 `ok/code/err`。

**V-134**：Agent 可选 `sql_query`：
- 默认关闭；需 `Sandbox.allow-sql` 和已配置只读 Engine。
- `sql` 必须参数化 `params[]`；结果转 `Table`，再按 `max-rows` 截断。
- 不开放 `sql_exec` / DDL；未知 op 仍 404，策略拒绝是 403。

**V-135**：资源与递归边界：
- `ls -R` 在 TTY 下按目录流式输出，每个目录先打 `目录:` 头再输出条目；
  非 TTY 返回完整分组文本。`--json` 仍返回扁平 Table。
- 普通 `glob`（如 `*.jpg`）只扫当前目录；按模式段数限制 `max-depth`，
  只有包含 `**` 时才无界递归。
- `ls` 递归结果超过 `Sys.max-entries`（默认 100000）抛 `X::Rakuish::Limit`；
  `cp -r` 在复制前预检源树条目数，超限直接拒绝。
- `write` 的原子临时文件使用 `spurt(:exclusive)`，不再可预测地覆盖已有临时文件。
- `!` 命令的未闭合引号直接返回 127，不把残片当 argv 执行。
- `peach` 是 DSL 的并行 map，`:degree` 控制并发度，结果保序。
- `glob` 支持 `*` / `?`（不跨 `/`）、`**/`、`foo/**/bar`、`foo/**`、
  `[abc]` / `[a-z]` / `[!x]`、`{a,b}` 与嵌套 `{a,{b,c}}`；`\` + 元字符
  （`* ? [ ] { } , \`）按字面匹配，裸 `\` 归一化为 `/`（V-153）。

**V-136**：`Sys` 记录本会话 `spawn` 的后台任务：
- `jobs` 返回 `Table`（id/status/exe/argv/started），REPL 有同名 shell 命令。
- `wait` / `cancel` 成功后清理；`job(id)` 可取回 Handle。
- 任务记录不跨 `Sys` 会话，不写全局进程表。

**V-137**：Agent 审计 `sql_query` 只记录 FNV-1a SQL 指纹和参数个数，
不记录 SQL 原文、参数值或结果行内容。

**V-138**：文件替换临时名：
- `write` / `mv` 的临时名使用时间 + 随机 + PID，降低可预测性。
- 原子写仍用 `spurt(:exclusive)`；写入前拒绝覆盖 `.bak` 符号链接。
- 失败路径保持原有回滚语义，不先删除目标。

**V-139**：超时：
- `serve-once` 使用 `IO::Socket::Async`，支持 `idle-timeout-ms`；超时后关闭连接并返回
  `timed_out => True`。
- DuckDB Engine 支持 `max-execution-time-ms`，映射到 DuckDB `max_execution_time`；
  超时查询抛数据库中断错误。
- SQLite 超时见 V-147；Agent `--sql-timeout-ms` 对两种引擎一致生效。

**V-140**：REPL 值历史：
- `_` 是上一成功格的值；`Out[1]` 起是成功格结果历史（首个元素为占位）。
- `cmd('shell 文本')` 执行 shell 薄层并返回结构化值；失败抛
  `X::Rakuish::CommandFailed`，`cmd-result` 则返回完整 Result。
- `cmd` 只在 REPL/绑定 Session 的上下文可用；不把 shell 文本变成第二套 Raku 语法。

**V-141**：`read` 作为 REPL shell 命令支持 `read 文件...`，按字面路径读取
（含 `-` 的文件名不再交给 Raku 当表达式解析）；与 `cat` 同源，输出文本。

**V-142**：0.53 命令查找：
- `which 命令` 优先报告 Shell 内置，其次按会话 `PATH` 查外部可执行文件。
- `help --find 文本` 在全部 usage 中做子串搜索，返回命令名 + 用法。
- 历史替换只识别整行 `!!` / `!$` / `!n` / `!-n`；`!cmd` 仍是外部命令。
  替换后立即求值，替换结果再入历史；用 `expanding` 标志防递归。

**V-143**：会话配置与 alias：
- 配置默认 `~/.rakuish-config.json`，`RAKUISH_CONFIG` 可覆盖；启动时加载。
- `config [get KEY|set KEY VALUE|unset KEY]` 读写顶层键。
- `alias name=command` / `alias name command` 写入配置；`unalias` 删除。
- alias 只展开 Shell 命令行的首个词，最多 10 层，防循环。

**V-144**：启动 hook：
- `hook add EVENT CODE`、`hook clear EVENT`、`hook run EVENT`；
  hook 存在配置 `hooks.EVENT` 数组。
- `bin/rakuish` 在 `-e` / 脚本 / 交互模式求值前运行 `start` hook。
- hook 失败时打印错误并停止启动；hook 内容是本地可信配置。

**V-145**：`Table` schema/types：
- 类型集合：`int / num / str / bool / datetime / list / map / any`。
- 构造时推断；`select/where/limit/...` 保留，`join` 合并右表类型。
- `column-type(NAME)` 与 `schema`（name/type/nullable）是稳定 API。

**V-146**：`Data::Engine` 写事务：
- `begin` / `commit` / `rollback` 是 Engine 角色方法；DuckDB、SQLite 都实现。
- 只读引擎调用事务抛 `X::Rakuish::Unsupported`。
- 事务属于引擎连接，不跨 Session/Agent 共享。

**V-147**：SQLite 查询超时：
- Engine `max-execution-time-ms` 通过看门狗调用 `sqlite3_interrupt` 中断。
- 超时抛 `X::Rakuish::Limit`；Agent `--sql-timeout-ms` 对两种引擎一致生效。
- 中断是连接级操作，不跨连接共享。

**V-148**：Agent 请求 deadline：
- `--request-timeout-ms` 默认 30000；超时响应 504，审计 stage=timeout。
- `exec` 和 SQL 会把实际执行超时压到不超过请求 deadline。
- 0.63 起 dispatch 在独立任务中执行，deadline 到点**立即**返回 504，
  超时任务的结果丢弃，连接继续可用（ADR-0002）；不再是「等操作返回后再检查」。
- Raku 线程无法强杀：不可取消的纯文件 I/O 仍会在后台跑完；exec / SQL 因底层
  超时被压进参数会真的终止。默认模式不宣称 OS 级进程硬取消，边界见 ADR-0002 §2；
  0.67 起 `--worker` 提供可选的进程级硬取消（V-159，默认关闭）。

**V-149**：`explore` 结构化分页：
- 无参数时探索上一格 Table；带路径时加载 JSON/CSV/目录为 Table。
- TTY 下按页输出（Enter 下一页、q 退出）；非 TTY 直接返回完整文本。
- `RAKUISH_PAGER=never` 强制非交互；不引入分页器第二套数据解释。

**V-150**：REPL 展示层与计时（0.62）：

- `Rakuish::REPL::Chrome` 是**纯展示模块**：banner / prompt / 颜色能力 /
  路径缩写 / 耗时格式化 / git 分支（只读 `.git/HEAD`，经 `Sys`）。
  它不求值、不注册命令、不解析输入，可在非 TTY 下被直接断言。
- TTY 下 banner 为极简字标 + 细分割线（**禁止字符拼字**）；prompt 显示时间、
  cwd、git 分支、格号、上格状态与耗时；续行提示符为 `···`。
  非 TTY 不打印 banner / prompt 与任何 ANSI（V-116）。
- 颜色：`NO_COLOR` 强制关、`FORCE_COLOR=1` 强制开，否则按 TTY + `config color`；
  `clock` / `timing` / `git` / `prompt-style` / `banner` 每格重读，`config set` 即时生效。
- 计时数据是会话级 `repl.perf-hist`，由入口对**每一格**（shell / `!` / Raku）
  统一调用 `note-timing` 写入，不重放历史、不引入第二套计时口径。
  `perf [N]` 展示；`timed` / `bench` 是普通 Raku sub，返回 `Result`。
- **不恢复 `%magic`**：不存在 `%time` 分流，`%` 始终是 Raku 哈希（V-122）。
  计时需求由「每格自动计时 + 状态行 + 值 API」满足。
- 测试：`t/15-repl-ui.t`（颜色、banner、prompt、格式、git 分支、timed/bench/perf）。

**V-152**：Parquet / 大结果 / SQL 错误统一（0.64）：

- `open-data` / `save-data` 支持 `.parquet` / `.pq`，返回 / 接受 `Table`；
  DSL 的 `:allow-external` 与 Shell 的 `open --external` 暴露该能力。
- **外部访问是显式例外**：读写 Parquet 必须给 `:allow-external`（人类 REPL），
  路径一律先经 `Sys.resolve` 做 root 校验；DuckDB 的 `read_parquet` / `COPY`
  由受控的 `:!safe` 引擎执行。**Agent 的 op 白名单不暴露该开关**，
  引擎默认 `enable_external_access=false` 不变。这是 V-129「只经 Sys」在
  显式授权下的例外；0.68 起 CSV 纳入同一模型（V-160），Parquet / CSV 是
  **全部**例外，不扩大到 Agent、不开放任意 SQL 文件函数。0.69 的 CSV 方言
  参数（V-162）只是给这两个例外加选项，不新增第三个例外。
- `Engine.query(:$max-rows)` 把 `LIMIT` 下推进 SQL，在物化前截断；
  DuckDB / SQLite 一致。`Table.batches(:size)` 返回惰性分批 `Seq`；
  `to-text` / `to-markdown` / `to-json(:$max-rows)` 是展示上限
  （`to-json` 只截行、不加文本，保持合法 JSON）。
- **Table 本身仍是物化值**：0.67 起真正的惰性查询由 `Engine.cursor()` 提供
  （V-158）；`query()` 的物化语义不变。
- SQL 驱动异常统一包装为 `X::Rakuish::Data`；只读 / 沙箱 / 超时等
  `X::Rakuish::V3` 子类原样抛，不泄漏驱动堆栈。
- 测试：`t/17-data-parquet.t`（Parquet 往返、默认拒绝、root 校验、
  LIMIT 下推、分批、渲染上限、错误统一、Agent 白名单）。

**V-153**：类型声明跨格与 glob 完整语法（0.65）：

- 纯声明格（`sub` / `use` / `class` / `role` / `grammar`）缓存进 `@decls`，
  每格前置重放**只重放声明**，不重放任何执行语句（V-124 红线不变）。
- 顶层类型声明统一改写为 `my class` / `my role` / `my grammar`：裸声明在
  `EVAL` 里会装进 `GLOBAL`，跨格前置重放时触发 `Redeclaration of symbol`。
  代价是 `.^name` 带外层包名（`Rakuish::REPL::Session::Foo`），短名仍可解析；
  持久的是**名字可见性，不是类型对象身份**（每格重放生成新 type object）。
- 类型声明在缓存中**原位替换**（不是移除后追加），保证 `role R` →
  `class C does R` 的依赖顺序在重定义后仍成立；声明求值失败时回滚缓存。
- 含 `BEGIN` / `INIT` / `CHECK` / `END` / `START` / `FIRST` 的声明格**不缓存**，
  避免 phaser 副作用每格重放；该格仍照常求值。混有其它语句的格不缓存。
- glob：`\` + 元字符按字面匹配；嵌套 brace 按最外层逗号切分；字符集支持
  转义的 `]` / `-`；未闭合 brace 按字面处理；裸 `\` 仍归一化为 `/`。
- Shell 薄层只展开 `* ?`：含 `{ } [ ]` 的参数交回 Raku（`glob` 命令除外），
  且 `!split` 会把 `\` 当转义前缀吃掉；完整语法请用 Raku `glob('...')`。
- 测试：`t/18-repl-types-glob.t`（50 断言：三类声明、重定义顺序、副作用不
  重放、失败回滚、转义 / 嵌套 brace / 字符集 / Shell 入口）。

**V-154**：Vi/Helix 编辑模式与键位预设（0.66，ADR-0003 §3.1）：

- `config set edit-mode emacs|vi|helix`（默认 `emacs`，完全不碰原生键位）；
  `config set vi-start insert|normal` 决定每行起始模式。配置当格生效：
  重建行编辑器并迁移历史。
- `REPL::Keymap::ViState` 是纯逻辑的单行模态模型（insert / normal / select、
  缓冲 / 光标 / 撤销 / yank），`repl.vi` 可访问；单行 REPL 里 `j` / `k` 映射
  历史上下格。
- TTY 下 `ViCLIInput` 子类覆盖 `decode-keyname` / `special-actions` /
  `input-class`：normal 模式把可打印字符映射成 `vi-<char>` 键名，只绑定依赖
  已有的 edit action 或少数自定义 `edit-vi-*`，**不复制 `read-input`**。构造 /
  绑定失败自动回退原生 `CLIInput` + `Alt-*` 预设。
- **边界**：0.70 `tools/tty-check.py` 已在 WSL 真 PTY 下自动验证 Vi 徽标、
  Tab 补全、SQL 补全、describe 与嵌套 REPL 直通；真实终端模拟器的光标手感
  仍需人工确认。normal 模式下 bracketed paste 会被当 vi 键吞掉（粘贴前按
  `i`）；不做多行 buffer / 可视块 / `.` 重复。子类化依赖
  `Terminal::LineEditor` 0.0.23 内部结构。

**V-155**：上下文提示（0.66，ADR-0003 §3.2）：

- `hint [输入行]` 查询；TTY 下 `config set hints on|off`（默认 `on`）在 prompt
  前打印一行暗灰提示；**管道 / 非 TTY 完全不输出**（V-116 不变）。
- 提示来自 `hint-for`（命令 usage 首行 / registry spec 参数 / `!` argv 说明 /
  启动参数误用）与 `result-hint`（失败格下一步建议）；同一首词只提示一次。
- 不做「输入中实时弹窗」：行编辑器没有输入变化 hook，硬塞补全列表会污染补全。

**V-156**：显式本地 Raku 插件（0.66，ADR-0003 §3.3）：

- `config set plugins on`（默认 **off**）后可用 `plugin load PATH`；
  `plugin list | info NAME | unload NAME | help`。
- 路径经 `Sys.resolve` root 校验、源码经 `Sys.read`；插件是 Raku 文件，最后一个
  表达式求值为 `Command` 对象或 `List[Command]`，注册进会话 `CommandRegistry`
  （`registry.names` / `help()` / `cmd('name', ...)` 可见），**不进 Shell 文本
  命令表**。重名冲突（内建 / 其它插件）返回 409；`unload` 只移除自己的命令。
- **加载即执行本地 Raku 代码**，等同 `use` 一个本地模块，不是沙箱：只加载可信
  文件。不自动扫描目录、不联网、不持久化、不开机加载。
- Agent 的 op 白名单不暴露 `plugin`，Sandbox 不加载插件；插件的
  `run($sys, ...)` 拿到会话 `Sys`，必须经它做文件 / 进程操作（V-129）。
- 测试：`t/19-repl-experience.t`（89 断言：模态语义、预设合法性、行编辑器
  子类与回退、hints、插件默认拒绝 / 冲突 / 越界 / 卸载、Agent 白名单、管道）。

**V-157**：符号链接逐段 root 校验（0.67，安全修复）：

- `Sys.resolve` 在 `!canonical` 之外，对路径链上每一级 `.l` 做 `readlink`
  并校验真实目标在 root 内；root 自身允许是链接。
- 原因：Windows 上 `IO::Path.resolve` **不跟随文件类型的符号链接**（指向目录时
  `.e=False` / `.l=True`，但 OS 的 open/slurp 会跟随），只靠 canonical 会让
  `escape-dir/secret.txt` 读到 root 外内容。
- dangling symlink / 无法 readlink 一律按 `X::Rakuish::Sandbox` 拒绝，不放行。
- 测试：`t/01-sys-fs.t`（中间 symlink 读 / 写越界均被拒）。

**V-158**：流式查询 Cursor（0.67，[ADR-0004](docs/ADR-0004-cursor-worker.md) §3）：

- `Engine.cursor($sql, *@params, :$batch-size, :$max-rows)` 返回一次性
  `Rakuish::Data::Cursor`；`next-batch` / `batches` / `rows` / `take` / `close`。
  只有被拉取时才向驱动要下一批行，`close` 幂等、拉完或达上限自动释放。
- DuckDB 用 `DB.query(:$stream)` + 惰性 `chunks`（驱动一次只持有一个 chunk）；
  SQLite 用 `Result.hash` 逐行 `sqlite3_step`。**不复用 `.hashes` 物化**。
- 不支持的引擎抛 `X::Rakuish::Unsupported`，**不静默退化成 `query()`**；
  只读判据、LIMIT 下推、`X::Rakuish::Data` 错误包装与 `query()` 一致；
  V3 异常族原样抛。`query()` 与 `Table.batches` 行为不变。
- 刻意不用 `gather/take` 嵌套：两层惰性 continuation 跨调用帧会触发
  `continuationreset` 错误，改用显式 `Iterator` + fetch 闭包。
- **边界**：一次性单连接，不提供可恢复游标 / 事务一致性快照 / 并发修改下的
  稳定视图；提前退出惰性 Seq 需显式 `close`（`DESTROY` 只作兜底）。
- Agent 的 `sql_query` **不暴露** Cursor（流式对象无法安全序列化进 JSONL），
  `query(:max-rows)` 的 LIMIT 下推保证物化前截断。
- 测试：`t/20-data-cursor.t`（56 断言：惰性计数、分批、上限、close、错误包装、
  DuckDB streaming / SQLite 逐行两后端、角色默认拒绝、Agent 白名单）。

**V-159**：连接级 worker 与 OS 硬取消（0.67，ADR-0004 §4）：

- `--worker` **默认关闭**，必须与 `--mode tcp --serve` 同用；不开时 `serve()`
  与 V-151 完全一致。每连接启动一个常驻 worker 子进程（不是按请求 fork）。
- 配置（含 token）走子进程 **stdin 第一行**，不进命令行参数；就绪握手行由
  父进程消费，启动成本隔离在连接建立阶段。stdout 只有响应 JSONL，诊断走 stderr。
- 子进程返回 504 或父进程 watchdog 到点 → `kill` 整个 worker 进程；卡在
  不可取消文件 I/O 里的线程随进程消失。审计集中在父进程并脱敏，子进程
  不写审计文件；每连接独立 session。
- **边界**：硬取消后该连接随即关闭（客户端需重连），与 V-151「连接继续可用」
  不同；不保证杀掉 worker 派生的孙进程（无 job object / 进程组）；
  不提供跨连接会话状态或 Engine 缓存共享。
- `--worker-hard-timeout-ms` 可显式设置监督者硬超时，默认
  `request-timeout-ms + 1000`（无 deadline 时 30s）。
- 测试：`t/21-agent-worker.t`（29 断言：真实子进程 + TCP、握手、非法配置、
  kill 后进程退出、504 后连接关闭、新连接不受影响、审计脱敏、默认拒绝）。

**V-160**：CSV 受控外部读写（0.68，[ADR-0005](docs/ADR-0005-data-workbench.md) §2）：

- `open-data` / `save-data` 的 `.csv` 在显式 `:allow-external` 时走 DuckDB
  `read_csv_auto(?)` / `COPY (...) TO ... (FORMAT CSV, HEADER)`；与 Parquet
  共用 V-152 的授权模型：路径经 `Sys.resolve`、受控 `:!safe` 引擎、
  Agent 的 op 白名单不暴露该开关。
- **默认行为不变**：不带开关的 `.csv` 仍走 `Sys.read` + `from-csv-data` /
  `Sys.write` + `to-csv-data`（V-129 路径）。
- `Engine.read-csv(:$max-rows)` 支持 LIMIT 下推；`write-csv` 拒绝含分号的
  导出 SQL；驱动异常统一 `X::Rakuish::Data`，V3 异常族原样抛。
- 导出流程与 Parquet 共用 `export-table`（建临时表 → 参数化 insert → COPY），
  空值规则一致，不写 SQL NULL。
- **不承诺**：CSV 方言全兼容（分隔符 / 编码 / 多行字段精细控制）、按 schema
  强制类型、分区写出。
- 测试：`t/22-data-csv.t`（33 断言：默认路径类型仍 str、外部路径推断
  int/num、写入往返、root 越界、Agent 白名单、角色默认拒绝、错误统一、
  Parquet 导出流程回归）。

**V-161**：Engine 元数据驱动的 SQL 上下文补全（0.68，ADR-0005 §3）：

- `Rakuish::REPL::SqlComplete` 是纯函数：仅当光标位于 `'...'` / `"..."`
  字符串内、且该字符串是 `query/cursor/execute/sql(...)` 参数时激活；
  否则返回空，`Shell.completions` 原路径一字不改。
- `DSL.open-db` 通过 `$*RAKUISH-SESSION` 把新建 Engine 注册为当前会话
  Engine（`repl.engine` 可读，最后一次 `open-db` 生效）。
- 候选来自只读 `tables()` / `schema()` 元数据加固定 SQL 关键字；按「最近
  关键字」启发式决定补表名还是列名；返回**完整替换行**（与 Shell 约定一致）。
- 所有 Engine 调用包在 `try` 里：驱动缺失 / 库被锁 / 元数据查询失败都优雅
  退化成空补全，不让 Tab 崩 REPL。非 TTY / 管道下不创建行编辑器，不触发。
- **边界（0.71 修订）**：`q[...]` 等不插值引号算子与 `sql =>` / `:sql(`
  具名形态已由 V-169 支持；仍不识别 `qq` / `Q` / heredoc / 嵌套 `q[...]`，
  不解析 SQL AST，不引 `\d` / 裸 SQL 命令等第二套语法；SQL 仍是字符串参数。
- 测试：`t/23-sql-complete.t`（30 断言：上下文识别、关键字/表名/列名、
  完整替换行与 tail、异常退化、Session 联动、Shell 回退、open-db 注册链路）。

**V-162**：CSV 方言参数（0.69，[ADR-0006](docs/ADR-0006-data-profile.md) §2）：

- `open-data` / `save-data` 增加 `:%csv-options`，`Data::CsvOptions` 是纯函数
  白名单：`delimiter` / `quote` / `escape` / `nullstr` / `header` / `skip` /
  `all-varchar`。未知键明确抛 `X::Rakuish::Unsupported`，不静默忽略。
- **读路径**：选项一律写成 `name => ?` 并用参数绑定，值不进 SQL 字符串；
  选项名只来自常量表。**写路径**：`COPY` 选项不支持绑定，字面量须先过
  「单字符可打印 ASCII / 长度 ≤64、不含单引号、反斜杠、换行、NUL」校验；
  `skip` / `all-varchar` 在写路径明确拒绝，不假装生效。
- 方言选项**只在 Raku 层**且必须 `.csv` + `:allow-external`；默认路径仍走
  `Sys.read` / `Sys.write` + Raku 解析器（V-129）。空选项生成的 SQL 与 0.68
  逐字一致。Shell 薄层 `open --external` 不做第二套参数语法。
- 路径仍经 `Sys.resolve` root 校验；Agent 的 `OPS` 白名单不变、不新增 op。
- **不承诺**：编码 / 多行字段精细控制、按 schema 强制类型、分区写出。
- 测试：`t/24-csv-dialect.t`（57 断言：白名单纯函数、注入拒绝、方言往返、
  默认行为不变、Agent 白名单、REPL 链路）。

**V-163**：`describe` 值 API（0.69，ADR-0006 §3）：

- `Table.describe(:$sample)` 与 `Engine.describe(Str $table, :$sample)` 都返回
  **Table**，列集合固定为 `name/type/nullable/non_null/distinct/total/sample`；
  不返回文本报告，可继续组合。
- `Engine.describe` 是**角色默认实现**，只依赖契约里的 `schema()` / `query()`
  聚合（`count(*)` / `count(col)` / `count(distinct col)`），因此 DuckDB /
  SQLite 与第三方引擎自动获得。表名限定 `[A-Za-z_][A-Za-z0-9_]*` 并加双引号；
  单列聚合失败时该列统计留空、整表不失败、不编造数字。
- DSL `describe($value)`：Table → 值摘要；Str → 当前会话 Engine 的表摘要；
  其它类型明确抛 `X::Rakuish::Unsupported`。REPL `describe [表名]` 是会话
  命令（与 `hint` / `plugin` / `perf` 同级，**不是 `%magic`**）：无参数取上一格
  成功值（Table 直接摘要，否则列出 `tables()`），有参数需已注册 Engine。
- **不承诺**：大表 `count(distinct ...)` 性能（可用既有查询超时限制）、
  文本直方图、关联分析。
- 测试：`t/25-describe-complete.t`（69 断言）。

**V-164**：SQL 上下文补全增强（0.69，ADR-0006 §4）：

- 在 V-161 启发式上增加：`from sales s` / `join users as u` 的**别名映射**；
  `s.am` 前缀只补 `sales` 的列且不塞关键字，返回完整替换行 `s.amount`；
  关键字大小写跟随输入片段（`SEL` → `SELECT`、`Sel` → `Select`）；扩展调用名。
- 仍**不解析 SQL AST**：不引解析器依赖、不处理 `qq` / `Q` / heredoc
  （`q[...]` 由 V-169 以纯词法方式支持）、不承诺方言完整性；所有 Engine
  元数据调用继续包在 `try` 里优雅退化。
- 理由见 ADR-0006 §4：DuckDB / SQLite 方言不同、Tab 热路径成本不划算、
  启发式已覆盖主要场景。SQL AST 级补全列为 V-908「不做」。

**V-165**：REPL 的 `open-data` / `save-data` 名字解析（0.69，缺陷修复）：

- `REPL::Session` 同时 `use Rakuish::DSL` 与 `use Rakuish::Data` 时，后者导出的
  同名 sub（带 `$sys` 首参）会覆盖 DSL 版本，导致文档示例的单参数形态在
  EVAL 里报参数错误。Session 内部只用全限定名，故改为 `need Rakuish::Data`。
- 此后 REPL 中 `open-data('x.csv')` / `save-data('x.csv', $t)` 解析到 DSL 的
  会话级版本；`Rakuish::Data::open-data($sys, ...)` 仍可供脚本显式调用。
- 测试：`t/24-csv-dialect.t` 的 V-165 回归段。

**V-166**：失败格不污染 stderr（0.69.1，缺陷修复）：

- 症状：`zef test` / REPL 中，混合格或含 phaser 的声明格之后引用未声明类型时，
  stderr 出现两次 `Use of uninitialized value of type Any in string context`
  （`REPL::Session` 的 `CATCH` 取异常消息处）。
- 根因：部分编译期异常的 `.message` / `.gist` 在**方法内部**字符串化未定义值并
  抛 `CX::Warn`；仅在调用侧判断 `.defined` 拦不住。
- 修法：用 `quietly` 只包住「构造异常文本」这一小块，结果仍显式收敛成 `Str`，
  最后以 `$ex.^name` 兜底；错误消息内容不变、不吞掉其它警告。
- 测试：`t/18-repl-types-glob.t` 新增子进程断言——失败格 stderr 不含
  `uninitialized value` 且子进程正常退出。

**V-167**：交互式子进程的 TTY 直通（0.70，[ADR-0007](docs/ADR-0007-tty-passthrough.md)）：

- 症状：`! rakupp` 这类嵌套 REPL 的输出被 `Sys::Proc` 的 Channel 捕获，
  30s 后被默认超时杀成 `code=124`，失败格不进 `_` / `Out[n]`。
- 显式入口：`! --tty <exe> [args]` / `! -t <exe> [args]`，Raku 里是
  `tty-exec(...)`；`! -- <exe> ...` 之后全部按字面 argv，不解析元选项。
  元选项属于 `!` 分发层，子进程收到的仍只有 argv 数组。
- `Sys::Proc.tty-exec`：`bind-stdin($*IN)` / `bind-stdout($*OUT)` /
  `bind-stderr($*ERR)`，输出实时可见、**无超时**、不捕获、不进 `_`；
  只返回退出码 / 耗时 / exe / argv 的结构化 `Result`（`op=tty-exec`）。
- 守卫：`$*IN.t && $*OUT.t` 必须为真；非 TTY 抛
  `X::Rakuish::Unsupported`，`Session` 收敛成 `code=127` 的失败 Result，
  不污染 V-116 的管道纯净输出。`cwd` 仍经 `Sys.resolve` root 校验、
  `env` 仍是会话 Hash。
- Ctrl-C 归属：0.73.0 起 POSIX 上用**进程组交接**（`posix_spawnp`
  `SETPGROUP` + `tcsetpgrp`）让子进程成为终端前台，Ctrl-C 由终端驱动直接
  投给它，父进程收不到；`SIGINT tap` 只保留在 spawn 与切前台之间的
  微秒级窗口。Windows 与降级路径仍是「父进程临时吞 SIGINT」（见
  **V-175 / ADR-0010**）。行编辑器 `prompt()` 返回时已 `leave-raw-mode`，
  无需手工改终端模式。中断期间的完整契约与真 PTY 回归见
  **V-173 / ADR-0009**（0.72.3）。
- 默认 `!` 的捕获 / 截断 / 30s 超时 / `Result.value` 语义**一字未改**；
  `code=124` 的失败格提示改用 `tty-exec(...)`。
- Agent op 白名单不暴露 `tty_exec`；不自动探测交互式程序、不捕获交互式输出、
  不注册后台 job、不提供嵌套子进程的多路复用（ADR-0007 §4）。
- 测试：`t/26-nested-repl.t`（32 断言；Windows 跳过 4 条真 PTY 集成，
  WSL/Linux 用 Python `pty` 起真实子进程验证首字符不丢、退出码回传）、
  `t/30-tty-exec-sigint.t`（中断归属契约，V-173）；
  `tools/tty-check.py` 是完整交互自检工具。

**V-168**：Ctrl-C 中断输入而非退出 REPL（0.71，[ADR-0008](docs/ADR-0008-input-interrupt-sql-forms.md) §3.1）：

- 问题：`Terminal::LineEditor` 默认把 `Ctrl-C` 绑成 `abort-input`，
  `prompt()` 返回未定义 `Str`；`bin/rakuish` 把未定义当 EOF，于是整个会话
  退出，与 `Session.key-bindings` 的「中断当前 cell / 清空续行缓冲」及
  `handle-key('Ctrl-C')` 的值 API 不一致。
- `REPL::Keymap::InterruptCLIInput`（继承 `CLIInput`）在 `decode-keyname`
  记本次 prompt 的 Ctrl-C 标志，`prompt` 把「abort 且标志为真」收敛成
  **定义的空串**；`take-interrupt` 一次性供宿主查询。真 EOF 与 Ctrl-D
  仍返回未定义 `Str`，退出语义不变。`ViCLIInput` 继承该子类，`make-cli`
  在 emacs 模式也构造它；构造失败回退原生 `CLIInput` 时如实记录为 0.70 行为。
- 宿主命中中断标志后调用 `$session.handle-key('Ctrl-C')` 复用值 API 清
  `@!pending`，不 `eval-line`、不进历史、不产生空 `Out[n]` 格，打印暗灰
  提示并 `next` 重画 prompt。`Ctrl-D` / `exit N` 仍是退出入口。
- **边界**：只处理输入阶段的 Ctrl-C；cell 求值中行编辑器不读键，SIGINT
  仍按 Rakudo 默认行为，不承诺中断运行中的 cell。不复制 `read-input`、
  不用哨兵字符串、不装全局 SIGINT handler（ADR-0008 §4）。
- 测试：`t/19-repl-experience.t`（解码 / 一次性标志 / 三模式类接线）、
  `t/27-interrupt.t`（值 API + 真 PTY：半行 → Ctrl-C → 仍活 →
  `Out[1] = 42` → Ctrl-D 退出；Windows 跳过 8 条）、`tools/tty-check.py` 增 2 项。

**V-169**：SQL 补全的调用形态扩展（0.71，ADR-0008 §3.2）：

- `sql-context` 的扫描器除 `'...'` / `"..."` 外，还支持**不插值**
  `q[...]` / `q{...}` / `q(...)` / `q<...>`；`q` 前须词边界，反斜杠跳过
  下一字符，不处理嵌套分隔符。SQL 内含单引号时不再打断上下文。
- 调用检测放宽为「CALLS 白名单名字 + `(`，其后可跟 `:sql(` 或 `sql =>`」
  的紧邻前缀；不扫描整行、不做括号配对回溯。返回结构新增 `quote-style`
  （`single` / `double` / `q`）。
- 候选生成、完整替换行与 `tail` 保留、别名映射、大小写风格、Engine 异常
  优雅退化、Shell 回退**全部不变**；仍不做 SQL AST（V-908 不变），
  不识别 `qq` / `Q` / `qx` / heredoc。
- 测试：`t/23-sql-complete.t` 新增 q 四种分隔符 / 两种具名形态 / 内嵌单引号 /
  tail 保留 / 双引号回归 / `qq` 与非白名单负向。

**V-170**：PTY 捕获层（0.72）：

- `Sys.pty-exec` / `DSL.pty-exec` 用 `Proc::Async.new(:pty(:cols,:rows))`
  给子进程分配伪终端；stdout 由父进程捕获，stderr 合流（PTY 语义）。
- 默认 `strip-ansi=True`，去掉 CSI / OSC / 非换行控制字符；`Result.out`
  是干净文本，`value` 标记 `pty/tty/timed-out/truncated/cols/rows`，
  0.72.2 增 `pty-capable/stderr-merged/stdin-unavailable/strip-ansi`。
- `timeout-ms` 到点 kill 子进程，返回 `code=124`、`err='PTY 请求超时'`；
  `max-bytes` 限制的是**剥离后文本**的字节数：0.72.2 起先对完整输出剥离
  控制序列、再做 UTF-8 安全截断（控制序列不占配额，也不会被截成半截残留）；
  tap 内只按 chunk 计数，累积上限 `4 × max-bytes`。
- **能力探测（V-172）**：`pty-exec` 先过版本 + isatty 双检，失败返回
  `code=127` 且 `value<pty>/<tty>` 为 `False`，绝不静默当 PTY 用。
- **不提供 stdin 写入**：当前 Rakudo 的 `Proc::Async :pty` 没有可靠的
  stdin 通道；不要把它伪装成完整交互会话。
- Agent `pty_exec` 默认关闭；必须同时显式 `--allow-exec --allow-pty`，
  argv[0] 过 canonical 白名单，cwd 过 root，env 只允许安全键；
  请求参数只能调小 timeout / output / 尺寸。
- 测试：`t/28-pty-exec.t`（PTY 捕获、TTY 可见、控制序列剥离、超时 124、
  max-bytes、Agent 默认 403、显式开关成功）。

**V-171**：Windows 的“文件系统根”（0.72.1）：

- POSIX 的 `root=/` 表示整个文件系统；Windows 的 `C:\` 只是当前盘根。
- REPL / 脚本默认构造 `Sys.new(:all-drives)`，允许 `D:/`、`F:/` 等其他盘；
  root 仍记录启动盘，用于默认 cwd / 显示。
- Agent / 显式 `Sys.new` 默认 `all-drives=False`，跨盘目标仍按 root 拒绝。
- `all-drives` 时跳过逐段 symlink root 校验（语义等同 POSIX root=/）；
  不是 OS 隔离，Agent 不应打开。
- 测试：`t/02-sys-session.t` 在 Windows 有 F: 时验证跨盘允许/默认拒绝。

**V-172**：PTY 能力探测与捕获层收尾（0.72.2，[AUDIT-FIXES-0.72.2](docs/AUDIT-FIXES-0.72.2.md)）：

- 起因：`Proc::Async.new` 用 `*%_` 吞掉未知命名参数，旧 Rakudo 传 `:pty`
  不报错、不生效；0.72.0/0.72.1 的 `Result.value<pty>/<tty>` 却硬编码
  `True`，等于结果撒谎（任务书 R-1，`[确证]`）。
- `Rakuish::Sys::Proc.pty-capability()` 做「`$*RAKU.compiler.version >=
  v2025.12` + 用 `:pty` 起 `raku -e 'print $*OUT.t …'` 真探针」双检，
  结果 `Lock` + 进程级缓存（一次/进程），失败带 `reason`。
  `META6.json` 的 `raku` 字段是语言版本，不能当 Rakudo 下限用；
  最低 Rakudo 版本写进 MANUAL / AUDIT-FIXES，不塞未识别元数据键。
- 探测失败时 `pty-exec` 返回 `Result.new(:!ok, :code(127))`，`err` 写明
  原因、`value<pty>/<tty>` 为 `False`；**不降级成普通 exec、不抛穿 Agent**。
  方法为 public，可被子类覆盖以注入失败路径（`t/29`，无需装旧 Rakudo）。
- 捕获层（任务书 R-3，`[需复核]` → 已实证）：tap 内改「数组追加 + 仅对
  新 chunk 计 UTF-8 字节」，结束一次 `join`；先 `strip-terminal-controls`
  再 `clip-bytes`；超过 `4 × max-bytes` 停止累积但继续消费并标 `truncated`；
  drain 改为等 stdout Supply 的 `done/quit`（0.5s 兜底、超时标 `truncated`）
  而非固定 `sleep 0.02`；Windows ConPTY 大输出仍可能在驱动层丢尾部 chunk
  （裸 `Proc::Async` 同样复现，非本版回归，见 AUDIT-FIXES-0.72.2 §3）。
- **边界不变**：`:!strip-ansi` 仍按原始字节截断（半截序列是该模式已知边界）；
  stderr 合流、`err` 恒空（超时除外），用 `value<stderr-merged>` 标记；
  不提供 stdin 写入（交互式 REPL 请用 `tty-exec`），用
  `value<stdin-unavailable>` 标记；超时只 kill 直接子进程，不承诺杀孙进程。
- 测试：`t/28-pty-exec.t`（18 断言）+ `t/29-pty-capability.t`（36 断言：
  能力探测、注入失败、结果标记、截断无 CSI 残片、`:!strip-ansi`、大输出）。

**V-173**：`tty-exec` 期间 Ctrl-C 的归属契约（0.72.3，[ADR-0009](docs/ADR-0009-tty-exec-sigint-contract.md)）：

- `! --tty` / `tty-exec(...)` 期间，前台进程组收到 SIGINT（真终端的 Ctrl-C）
  时，子进程按自身 SIGINT 语义退出，`tty-exec` 返回交接摘要与
  `Result.value<exit>`；**父进程存活**，之后重画 prompt，下一格可正常
  输入并求值；`LEAVE` 关闭临时 tap 后，普通 Ctrl-C 仍是 V-168 的输入中断。
- 实现不变：`Sys::Proc.tty-exec` 的 `signal(SIGINT).tap(-> $ { })` +
  `LEAVE` 这一对行为已满足契约（0.72.2 实测）。本版只把契约钉成断言，
  **不改产品代码**。
- 回归用「`start_new_session` + `killpg(pgrp, SIGINT)`」模拟前台进程组。
  **0.73.0 起改为真终端路径**（`pty.fork` + 写 `\x03`）：进程组交接落地后，
  那个模拟写法不再成立 —— 切组后信号打不到子进程（见 V-175）。
- **边界**：0.72.3 当时不做 `setpgid` / `tcsetpgrp`；**该边界已由 V-175
  在 0.73.0 解除**（POSIX-only）。仍不做 `&` / `jobs` / `fg` / `bg` /
  Ctrl-Z 作业管理。子进程忽略 SIGINT 时 `tty-exec` 仍按无超时边界一直等；
  不承诺求值中 SIGINT 的 Rakudo 默认行为；Windows 无 pty 时整段跳过。
  终端状态恢复 0.72.4 起单独由 V-174 覆盖（0.72.3 曾误判为「本驱动不可观测」）。
- 测试：`t/30-tty-exec-sigint.t`（Linux/WSL 真 PTY，5 条契约断言；
  Windows skip）、`tools/tty-check.py` 增 2 项。

**V-174**：`tty-exec` 交接期的宿主 termios 快照恢复（0.72.4，
[ADR-0009 §0](docs/ADR-0009-tty-exec-sigint-contract.md)）：

- 背景：`tty-exec` 将宿主 TTY 三条 fd 直接 bind 给子进程；子进程
  （vim / less / `stty raw -echo`）改动 termios 后不还原时，行编辑器
  下一轮 prompt 会把污染态当成新基准「保存并恢复」，污染固化（实测
  `c_lflag` 35387 → 35376，关掉 `ICANON + ECHO + ISIG`）。
- `Sys::Proc.tty-exec` 在 `bind-stdin` **之前**调用
  `termios-snapshot($fd)` 保存宿主配置，正常路径与 `LEAVE` 幂等恢复
  （`Terminal::API::restore-config(..., :when(DRAIN))`）。`LEAVE` 是块级
  phaser，非 TTY 守卫抛异常时也会触发，故恢复前必须判 `$saved.defined`
  并整体包 `try`，不得覆盖原异常。
- 复用 `Terminal::API`（`Terminal::LineEditor` 的传递依赖，0.72.4 起在
  `META6.depends` 显式声明）：Linux / macOS / BSD 三套 CStruct 与
  Windows `GetConsoleMode` / `SetConsoleMode` 均已封装，不重写 NativeCall。
- `Result.value<termios-restored>` 如实标记恢复成败；快照不可用
  （非 TTY / API 失败 / 子类注入）时**不阻断直通**，只标 `False`。
- **边界**：不猜测子进程改了哪些位，整份配置恢复。
- Windows 无 POSIX termios，走 `GetConsoleMode` / `SetConsoleMode`。
  0.72.5 用真 ConPTY 实测通过：输入模式 `503` → 子进程 `make-raw` 后
  `1008` → 返回后 `503`（`termios-restored=True`），关掉快照的对照保持
  `1008`；conhost（winpty）下数值一致。`prove6` 环境无控制台，该分支不进
  `t/`，由 `tools/tty-termios-win.py` 自查（ADR-0009 §7）。
- 测试：`t/31-tty-termios.t`（canonical 基线 PTY，13 断言：正常恢复 /
  注入禁用快照的对照证明污染真实发生 / 非零退出路径 LEAVE 兜底；
  Windows 只跑 2 条非 TTY 退化断言）。

**V-175**：`tty-exec` 的 POSIX 进程组交接（0.73.0，
[ADR-0010](docs/ADR-0010-job-control-feasibility.md) §6）：

- 背景：0.72.x 用 `Proc::Async` 起子进程，父子**同属一个进程组**，
  靠父进程临时吞 SIGINT 保命。后果是子进程一句 `kill(0, SIGTERM)`
  （现实中清理进程组的工具会这么做）会把宿主 REPL 一起打死 —— 真 PTY
  实测 `alive=False`。而 POSIX 只允许父进程对**尚未 exec** 的子进程
  `setpgid`，`Proc::Async` 交出 pid 时子进程早已 exec（实测 60/60 失败、
  `EACCES`），所以只能在 spawn 时定组。
- 实现：POSIX 上改用 `posix_spawnp` + `POSIX_SPAWN_SETPGROUP(0)`
  （新模块 `Rakuish::Sys::PosixSpawn`），spawn 后 `tcsetpgrp(0, child-pgid)`
  把终端前台交给子进程；`waitpid` 自己回收并解出 `exit` / `sig`。
  返回时把前台还给宿主，再恢复 termios。
- **SIGTTOU 必须真 `SIG_IGN`**（`signal(2)` + handler `(void*)1`），并在
  `LEAVE` 还原旧 handler。用 Raku 的 `signal(SIGTTOU).tap` 是捕获语义，
  会让恢复那次 `tcsetpgrp` 返回 `ENOTTY`（ADR-0010 §2.3 实测）。
- SIGINT tap 缩到**交接窗口**（spawn 后、切前台前）：那段时间前台仍是父组，
  不兜住会被 Ctrl-C 带走；切前台成功立即关闭。正常运行**不依赖**该 tap。
- `cwd`：`posix_spawn` 无 cwd 参数，用
  `posix_spawn_file_actions_addchdir_np`；与当前目录相同的请求直接跳过该动作。
  符号不可用（glibc < 2.29 / macOS < 10.15）时**降级**回 `Proc::Async`，
  `value<job-control>=False` 且写 `value<job-control-reason>`，
  **绝不改父进程 `chdir`**。
- 状态映射：`WIFSIGNALED` → `code = 128 + sig`；`posix_spawnp` 返回
  `ENOENT(2)` → `code=127`；`waitpid` 拿不到状态 → `code=1`（不谎报成功）。
- `Result.value` 新增 `job-control` / `job-control-reason` / `fg-restored` /
  `pgid`；原有 `exit` / `signal` / `elapsed` / `termios-restored` 语义不变。
- **边界**：只做进程组交接。不做 `&` 后台、`jobs` / `fg` / `bg`、Ctrl-Z
  作业管理（那是 shell 语法，需另立议题，且与 V-90x「不引 bash 语法」冲突）；
  不做信号转发（SIGWINCH 由子进程组自己处理）；不做孙进程树回收（V-905）。
  Ctrl-Z 会把子进程停住而 REPL 等在那儿 —— 这是明确划出去的已知行为。
- Windows 无 POSIX 前台进程组（`CTRL_C_EVENT` 不能投递给进程组，属 MSDN
  明确语义），走老路径，`value<job-control>=False` 并带原因。
- 测试：`t/32-job-control.t`（真 `pty.fork` controlling terminal，11 断言：
  自成一组 / 拿到前台 / 退出码与信号码映射 / cwd 动作 / `kill(0)` 不波及
  宿主 / Ctrl-C 只投给前台组 / 前台收回；Windows skip）。
  `t/30` 的驱动同步改用真终端路径（`pty.fork` + 写 `\x03`）。

**V-176**：内置命令结果的着色（0.74.0，
[ADR-0011](docs/ADR-0011-highlight-colors.md) §2–§3）：

- 开关链唯一：`config color` / `NO_COLOR` / `FORCE_COLOR` / `$*OUT.t`
  → `Chrome::color-mode()` → `Session.new(:color)` 与 `make-cli` 的高亮开关。
  `Session` 的默认值是 `False`（忘记传参的调用点一律纯文本）。
- 着色点与样式：路径列表与 `ls -l` 的名字列（目录粗蓝 / 可执行粗绿 /
  符号链接青）、`Out[n] =` 标签（dim）、`错误:` 整行（红）、`help()`
  的命令名（粗青）与摘要（dim）、`env()` 的 KEY（青）、`stat` 的字段名
  （dim）、写入结果的 `wrote`（绿）与 `[non-atomic]`（黄）。
- **「可执行」分平台判定**（0.77.0 订正）：POSIX 看执行位；Windows 看扩展名
  （`exe/bat/cmd/com/ps1/msi`）。依据是 `IO::Path.x` 在本版 Rakudo 的 Win32 上
  会抛（`rindex ... got null`），旧实现把它包在 `try` 里 —— 异常被吞成「不是
  可执行」，于是 **Windows 上从未把 exe 标绿过**，且不报错、看不出来。
- **不变式**：颜色只插入零宽转义。列宽、列数、padding 一律按**纯文本**算，
  否则多列 `ls` 会错位；`strip-ansi(着色结果)` 必须与不着色时逐字符相同。
- **渲染层必须同时判 TTY**：只问 `color` 开关会让 `rakuish -e 'ls' | cat`
  混进 ANSI，违反 V-116。统一走 `Session!color-on`（开关 ∧ `$*OUT.t`）。
- **不做**：`Result` 的 `render-result(format => 'text')` 仍不掺 ANSI
  （SPEC 747 不变）；`Table.to-text`（describe / `ls --json`）不着色；
  Agent 输出不着色（JSONL 没有终端语义）。
- 测试：`t/33-colors.t`（非 TTY 零 ANSI、色表、路径分类；普通文件用**自建
  夹具**而非仓库文件 —— 文件模式取决于检出方式，从 drvfs 拷来的树满是 `+x`）；
  `tools/tty-check.py` 在 raw 字节上断言真 PTY 下 `ls` 目录确实着色。

**V-177**：REPL 输入行的语法高亮（0.74.0，
[ADR-0011](docs/ADR-0011-highlight-colors.md) §4）：

- 实现方式：行编辑器不提供高亮钩子，覆盖
  `ScrollingSingleLineInput::ANSI.visible-input-field-string` —— 它是
  「左滚动标记 + 内容 + padding + 右标记」那一层，只给中间的内容段上色。
  新增 `Rakuish::REPL::Keymap::HlField` 作为基类，`ViField` 继承它，
  `InterruptCLIInput` 覆盖 `input-class` 让 emacs 模式也走同一个字段类。
- **硬不变式**：着色串的**纯文本部分**必须与不染色时逐字符相同。父类用
  `display-width`（对 buffer 内容算出的显示宽度）定位光标与清屏，多一个
  可见字符就会让输入区错位。`$.mask.defined`（掩码输入）时直接短路。
- 词法范围（`Rakuish::REPL::Highlight`，纯函数）：注释 `#…`、单双引号
  字符串（含 `\` 转义、未闭合染到行尾）、数字、`$ @ % &` 变量（含 twigil）、
  关键字表。**不做** `q[...]` / `qq[...]` / heredoc / 正则字面量 /
  多行字符串 / pod —— 它们需要跨行状态或真正的 Raku 词法器。
- 回退：`make-cli` 在子类构造失败时回退到原生 `CLIInput`，那条路径
  **没有高亮**（与 Ctrl-C 的回退同理，如实标注，不假装）。
- 开关与 V-176 同源，`config set color off` 当格生效；非 TTY 与
  `NO_COLOR` 下不进入着色分支。
- 测试：`t/33-colors.t`（27 个样本的纯文本等价、`:!color` 逐字节相同、
  各 token 命中）；`tools/tty-check.py` 在 raw 上断言真 PTY 输入
  `say "hi"` 时字符串与关键字确实着色。

**V-270**：跨行引号高亮（0.97.0）。

- 词法范围扩到**跨行引号**：Session 判定续行（`is-incomplete`）时，把已提交
  的续行源码经 `Highlight.set-continuation($src)` 传给高亮器；下一行开头若
  仍在未闭合的 `"..."` / `q[...]` / `qq(...)` 内，整段染成字符串色，遇闭合
  记号后恢复正常 token 着色。提交完成 / 清空续行 / Ctrl-C 时置空状态。
- 这是**轻量**跨行：只回答「在哪个引号里、等什么闭合」，复用单行那套闭合
  与 `q[...]` 同类嵌套规则；**仍不做**正则字面量 / heredoc / pod / 插值块
  `{$x}` 里的代码着色（需真正的 Raku 词法器）。
- **硬不变式在跨行下同样成立**：着色只走 `seg`（零宽 ANSI），
  `strip-ansi(highlight-line($s)) eq $s` 恒成立（`t/33` 10 断言守）。

**V-271**：大文件的 `head` / `tail`（0.97.0）。

- `head -n N` / `tail -n N` 走 `Sys.read-lines(:head/:tail)` 流式按行读，
  只留 N 行、不 slurp 全文，**不受 `read` 的 `max-bytes` 全文上限**——
  读的量与文件总大小无关，大日志也能看首尾。
- 路径仍过 `Sys.resolve`（root 校验与 `read` 同一条路），不另开口子。
- `read` 整份读的 1 MiB 上限**保留**（防 slurp 吃爆内存）；超限错误给出
  三条出路：`read-lines` / `head`·`tail` / `stream('路径')`，或显式
  `:max-bytes(N)` 自行承担内存。
- `tail` 仍扫到文件尾（内存只留 N 行）；O(n) 尾部 seek 不做。

**V-178**：命令选项的 Tab 补全（0.75.0，
[ADR-0012](docs/ADR-0012-userland-commands.md) §2）：

- 选项信息来自 `Shell` 的模块级常量 `OPTIONS`（`命令名 => 选项列表`），
  **不解析 `usage()` 的自由文本** —— 帮助文案随时会调，反推 flag 太脆。
- 触发条件：光标前的片段以 `-` 开头。此时**不进入路径补全分支**
  （否则 `ls --j` + Tab 会去当前目录找名为 `--j` 的文件），直接返回
  「完整替换行」候选，前缀匹配、排序、去重。
- `--help` / `-?` 对所有命令通用，补全时统一追加。
- **不做**：选项值补全（`--color=` 之后的枚举）、子命令补全、候选菜单。

**V-179**：`doc` 命令的对象内省（0.75.0，ADR-0012 §3）：

- `doc <内置命令>` 走 `Shell.usage()`，权威帮助优先于元对象；
  `doc <Raku 名字>` 走 `Rakuish::REPL::Introspect`（纯函数），输出类型名 /
  `WHY` / 例程签名 / 局部方法列表。
- **零 EVAL**：只用 `::($name)` 查符号表，绝不把参数当代码求值。
  因此**看不到跨格 `my` / `our`**（它们在 `Session` 的 `LexState` 里，
  不在全局符号表）—— 这是能力边界，不是缺陷。
- 名字校验：只放行标识符与 `&例程名`（`valid-name`）；`doc 1+1`、
  `doc a;rm -rf` 必须失败。
- 符号查找必须同时收口两条路：抛出 `X::NoSuchSymbol`，或返回**延迟
  Failure**。**不能用 `try`** —— `try` 会把块值（Failure）留在返回位置，
  之后在 GC 里 DESTROY 时吐 `unhandled Failure detected in DESTROY`；
  用裸块 + `CATCH`，并对返回值再做一次 `~~ Failure` 兜底。
  **也不能用 `.defined` 判断**（异常对象的 `.defined` 是 False，
  `Str` 这类类型对象的 `.defined` 同样是 False，两头都会误判）。
- `doc &say` 这类带 sigil 的参数要加入 Shell「未加引号元字符」闸门的白名单
  （与 `export` / `grep` / `glob` 同处），否则会被交回 Raku 求值。
- 测试：`t/34-userland.t`（合法/非法名字、类型与例程内省、`doc 1+1` 失败、
  `doc --help`）。

**V-180**：目录栈与书签（0.75.0，ADR-0012 §4）：

- `pushd DIR` / `popd` / `dirs` 维护 `Shell` 上的 `@!dir-stack`；
  `bookmark add NAME [DIR] | list | go NAME | del NAME` 维护 `%!bookmarks`。
- **所有改当前目录的入口收口到 `Shell!change-dir`**（`cd` / `pushd` / `popd` /
  `bookmark go`），`prev-cwd` 只在这一处更新 —— 否则 `cd -` 与目录栈会各说各话。
- 书签是**会话内**状态，不落盘；名字限 `[A-Za-z0-9_]`。
- 失败语义：栈空 `popd`、未知书签名、非法书签名都给错误 `Result`，不静默。

**V-181**：会话日志（0.75.0，ADR-0012 §5）：

- `log [start [路径]|stop|show|status]`，状态在 `Session`
  （`log-on` / `log-path` / `log-seq` / `log-lines`）。
- **写入点只有一个**：入口主循环里同时拿到「输入行 + Result + 渲染文本」的那一处。
  `log-line` 内部剥掉 SGR，**日志恒为纯文本**（TTY 渲染带颜色，直写文件会污染）。
- **落盘一律经 `Sys.write` / `Sys.append`**（V-125）；不复制 `!save-config`
  的裸 `.spurt` —— 那是配置文件的历史例外，不扩散到新能力。
- 默认路径 `~/.rakuish-session.log`。内存里同时保留记录，`log show` 不依赖文件。
- **不做**：日志重放、多会话合并、JSONL 结构化格式（等 `DisplayBundle`）。


**V-126**：REPL 对常见返回值做 shell 习惯的展示，而不是一律 `.raku`:

| 返回值 | 展示 |
|---|---|
| `List[IO::Path]`（`ls` / `glob` / `recent`） | basename 列表；TTY 多列，管道一行一个 |
| `CommandSpec` 列表（`help()`） | 命令名 + 摘要对齐 |
| `List[Str]`（如 `registry.names`） | 一行一个 |
| `Hash`（如 `env()`） | `KEY=VALUE`，按 key 排序 |
| `Str`（如 `read()` / `pwd()`） | 原样内容/路径，不显示 Raku 引号 |
| `Stat` | `path/type/size/mode/modified/...` 字段 |
| `WriteResult` | `wrote N bytes to PATH` |
| `IO::Path` | 路径字符串 |
| `Result` | 优先命令 stdout / stderr，回退 `text` |
| 其它 | `Out[n] = .raku` |

这些只是展示层，值本身仍是原来的类型，`.grep` / `.map` / `.value` 不受影响。

**V-127**：REPL 提供“日常 shell 观感”薄层，但**不是第二套 shell**：
支持 `cd [dir|-]` / `pwd [-L|-P]` / `clear` / `history` / `set -e|+e` /
`jobs` / `which` / `alias` / `unalias` / `config` / `hook` / `explore` /
`ls [-a -l -h -F -R -t -S -r -d]` / `cat` / `read` / `head|tail [-n N]` /
`echo [-n]` / `mkdir [-p]` / `touch` / `cp [-r]` / `mv` / `rm [-r] [-f]` /
`stat` / `export` / `unset` / `glob` / `grep [-inv]` / `wc [-lwc]`；
0.75.0 补 `doc` / `pushd` / `popd` / `dirs` / `bookmark` / `log`
（ADR-0012；`log` 是会话级命令，其余在 `Shell` 薄层）。
命令只翻译成直接 `Sys` 调用；每个命令支持 `--help` / `-?`
查看自己的用法，也支持 `help <命令>`。不支持管道、重定向、子 shell。
参数中的 `$NAME` 按会话 env 展开，`~` 展开到 `$*HOME`；带 Raku 表达式或
非字面参数的输入仍交给 Raku。实现位于 `Rakuish::REPL::Shell`，不改变底层
`Sys` / DSL API。

---

## 3.5 内核与前端（V-18x，0.76 / ADR-0013）

**V-182**：`Rakuish::Kernel` 是前端与执行之间的**唯一入口**（0.76.0）：

- 前端（TTY / 将来的 Agent、Notebook）只构造 `Request`：
  `kind`（`source` / `op`）、`payload`、`origin`（human / agent / notebook /
  script）、可选的 `policy`；执行一律走 `Kernel.execute`。
- **前端不得直接调 `Session.eval-line` / `Sys.*` / `Agent.!dispatch`**；
  `t/35-kernel.t` 对 `bin/rakuish` 做静态断言（不得出现 `.eval-line(`、
  必须出现 `kernel.execute`）。
- 0.76 只接 `source` 通道；`op` 返回 `501`（明确未实现，不伪装成空成功）。
- 拒绝也是结构化结果：`Result(:!ok, :code(403), :op<kernel>)`，
  不把策略异常穿透给前端（前端只认 `ok/code/err`）。
- **行为不变**是这一版的硬门槛：同一批样本在「直连 Session」与
  「经 Kernel」两条路径上 `ok/code/op/out/err/value` 必须逐字段相同，
  `Out[n]` 编号也必须同步（`t/35` 十个样本对账）。

**V-183**：`Policy` 由内核强制执行，**前端只能收窄**（0.76.0；0.82.0 收敛，ADR-0020）：

- 字段**只有三个**（0.82.0 起）：
  `allow-source`（内外**与**）、`root`（更窄者胜；越界直接 403）、
  `profile`（标签）。
- 0.76 的 `allow-exec` / `read-only` / `allow-ops` / `limits` **已删除**：
  全仓库没有任何执行点读取它们，留着就是「声明禁止、实际放行」的牌子
  （ADR-0019 的同一把尺子，见 V-211）。
- `profile` 只是**日志标签**（`local` / `analyst`），不参与判定 ——
  加新 profile 不该在 Kernel 里加 `when` 分支。
- `root` 的包含判断是**词法**的（绝对化 + 分隔符边界 + Windows 小写化），
  不用 `IO::Path.contains`（它按真实路径解析，路径不存在即返回 False，
  策略判定不该依赖目录存在）；符号链接逃逸仍由 `Sys.resolve` 负责（V-201）。
- 拒绝路径**不推进** `Out[n]`、不写 `@!out`（`t/35` 断言 `index` 不变）。

> `DisplayBundle`（V-184）、人机能力矩阵（V-185）、Agent 协议 v2（V-186）
> 分别随 0.77 / 0.78 落地，本版不写进验收。

---

## 3.6 Windows 控制台编码（V-187，0.76.1 / ADR-0014）

**V-187**：Windows 上进入交互前把**控制台码页**切到 UTF-8（65001），退出还原。

- **问题**：中文环境的控制台默认 936（GBK），而 Rakudo 的控制台 I/O 按 UTF-8
  解析。输入中文抛 `Malformed UTF-8`；`Terminal::LineEditor` 的字节循环
  「读到解码成功为止」，于是**一直等**（字不显示、回车不生效）。输出同样乱码。
- 实现：`Rakuish::Sys::Console`（`ensure-utf8-console` / `restore-console` /
  `console-cp` / `describe`），走 `SetConsoleCP` / `SetConsoleOutputCP`。
- **必须放在所有入口分发之前**（`-e` / 脚本 / REPL 全部覆盖），并用 `END`
  兜底还原 —— 曾经的错法是放进 `if @*ARGS { given ... }`，无参数启动（正常
  REPL）根本不进那个分支，修复等于没生效。
- **硬闸门**：只有「stdin 是终端」才切换。码页是控制台全局状态，父 shell 也
  看得见；管道 / 脚本不该改用户的终端。
- **不用 `chcp`**：那要起外部进程（与 V-604 / 沙箱边界冲突），且无法可靠还原。
- 非 Windows 一律 no-op。回归：`t/36-console-utf8.t`（平台闸门 / 无副作用 /
  入口顺序 / 管道中文）；真控制台由 `tools/tty-cjk-win.py` 自检（4 项）。

---

## 3.7 命令表与格记账（V-188 / V-189，0.77.0 / ADR-0015）

**V-188**：命令名只有一个声明处（`Shell` 的 `COMMAND-GROUPS`），其余派生。

- 分组：`shell`（`handle()` 真正分发）/ `session`（`eval-line` 早返回处理）/
  `api`（只有 Raku 侧 API、无同名文本命令）。`COMMANDS`、`SHELL-COMMANDS`、
  帮助索引的分类、Tab 补全候选、渲染层的 shell-op 名单**全部由它生成**。
- **必须保留手写、且有测试守着的两处**：`usage()` 的文案（太长，塞进数据表会
  淹没结构）；`handle()` 的 `given` 分发体（要调私有方法，无法从数据生成）。
  `t/37` 双向断言：表里每个名字都要有分支，分发表里不许有表外分支。
- **历史教训**：`hint` / `plugin` 自 0.66 起有完整 `usage`、`help hint` 可查，
  却从不在 `COMMANDS` 里 —— Tab 永远补不出来。任何「新命令要手工登记 N 处」
  的设计都会重演这个错误，所以宁可用测试守两处，也不再加第三张名单。
- 新增命令的登记点从 ~9 处降到 4 处（组声明 / 用法文案 / `OPTIONS`（仅当真有
  flag）/ 分发体）。

**V-189**：输入序与格号是两个计数，**不得共用一个写点**。

- `@!history` = 输入序：`history` 显示与 `!n` / `!!` 的编号来源。**每一行提交
  都给**：会话级命令、失败的 Raku 格、`!` 外部命令一律入册。
- `$!index` = 格号：`Out[n]` 与 `perf` 用它，只在**成功的求值/执行格**递增。
  会话级命令不占格号（否则 `Out[n]` 跳号）；失败的 Raku 格不占格号
  （既有契约，`t/07` 有断言）。
- **记账必须收口**：`eval-line` 是 `!eval-line-body`（执行）+ `!finish`（记账）
  两段。`!eval-line-body` 内有十几处 `return`，逐个补 `@!history.push` 正是
  0.77 之前漏掉一半的成因。
- 规则：空行与续行中间态（`op<more>`）不记；多行格记**完整源码**不记最后一行；
  `!!` 的外层不记（内层已记展开后的真实命令）。
- 回归：`t/37-command-table.t`（`!!` 重放上一行而非上一格、`!n` 与 `history`
  编号同源、多行格只记一条且含中间行、失败格入册但不占格号）。

---

## 3.8 展示包与 op 通道（V-184…V-186，0.78.0 / ADR-0016）

**V-184**：`Rakuish::Display::Bundle` 是结果的**内容级**展示包。

- 字段：`text`（必有，**零 ANSI**）、`markdown`（`''` = 不提供）、
  `json`（空 = 不提供；内容是**值本身**，不含 `ok`/`code`/`op` 外壳）、
  `meta`（`kind`/`ok`/`code`/`op`/`rows`/`truncated`）。
- 能力：`available` / `pick(@accepts)` / `render($fmt)`。`render` 遇到不可用
  格式**回退 `text` 而不抛** —— 展示层不该让调用方崩。
- **分工不可混**：Bundle 只管内容；颜色、`Out[n]` 标签、`COLUMNS` 分列属于
  `Session.render`（前端装饰）。把装饰塞进 Bundle 会让它退化成 TTY 专用。
- **不复制渲染逻辑**：`records`（`Positional of Hash`）先 `Table.from-rows`
  再取 `to-text` / `to-markdown`；表格对齐、单元格转义、截断提示只有一份实现。
- `kind` 取值固定为
  `error` / `text` / `table` / `records` / `paths` / `rows` / `record` /
  `scalar` / `empty`（V-185 的 `kinds` 必须与之一致）。

**V-185**：`capabilities()` 只列**真的能用**的能力。

- `Kernel.capabilities` 报 `formats` / `kinds` / `request-kinds` / `ops` /
  `profiles` / `policy-fields`；Agent 的 `capabilities` op 另报限额与开关，
  0.79.0 起再报 `protocol`（=2）/ `stream_ops` / `cancel`。
- **不写进清单的东西**：`html`（没有任何渲染路径能产出）、`execute` op
  （V-503 不变）。声明做不到的格式比不声明更糟。
- `stream_ops` 必须**只列真的会发帧的 op**（0.79.0 只有 `exec`）；
  请求里带 `stream` 但 op 不在清单内时不得发任何帧（V-192）。

**V-186**：op 通道与协议向后兼容。

- `kind => 'op'` 的载荷固定为 `payload => %(op => 'name', ...)`；
  非 Hash → `2`，缺 `op` → `2`，不做隐式转换。
- 0.78 只开 `capabilities`（不碰文件、不起进程、不执行源码）；其余 `501`
  且错误信息写明原因与计划版本。**不允许出现第二个含糊的空成功**。
- `Policy.allow-ops` **先于** 501 判定：不在名单里 → `403`。
  **0.82.0 撤销**：该字段已删（V-205 / ADR-0020）—— op 通道只剩
  `capabilities`，名字级白名单没有可挡的对象，直接按下面的 501 规则处理。
- Agent 的每条回复附加 `display`（同 V-184 形状）；请求可选 `format`。
  **附加字段不得改变既有键语义**：`ok`/`code`/`value`/`out`/`err` 一字未改，
  老客户端忽略 `display` 即可。失败回复（401/403/504/400）同样带 `display`，
  `kind` 为 `error`。
- **降级必须如实**：请求 `markdown` 而内容不支持时，`format` 必须回填
  `text` 而不是请求值，否则客户端会把纯文本当 markdown 渲染且无从查错。
- **0.81.0**：`Display::Bundle` 本身保留（本地渲染 / `-e` 输出都在用），
  但 **V-186 的「Agent 响应带 `display` 字段」随 Agent 线撤销**。

---

## 3.9 流式分帧与请求取消（V-190…V-193，0.79.0 / ADR-0017 —— **0.81.0 撤销**）

> ⚠ 本节四条（V-190…V-193）已随 Agent 协议删除，见 §6.1 与
> [ADR-0019](docs/ADR-0019-local-full-privilege-shell.md)。下文保留原文
> 作为历史记录，**当前实现不存在流式帧**。

**V-190**：**帧有且只有两种**，客户端靠 `event` 键区分。

| 行 | 形状 | 含义 |
|---|---|---|
| 中间帧 | `{"id":N,"event":"start"\|"chunk",...}` | 只在流式请求期间出现 |
| 响应行 | 与 0.78 完全相同的响应（**没有 `event` 键**） | 每个请求恰好一行 |

- `start` 帧：`id` / `op`。每个流式请求**恰好一帧**，且在第一个 `chunk` 之前。
- `chunk` 帧：`id` / `seq`（本次请求内从 0 递增、跨 fd 共用、不重号）/
  `fd`（`stdout` \| `stderr`）/ `data`（字符串）。
- 响应行附加 `streamed: true`、`chunks: N`；被取消时 `cancelled: true`；
  因超限停止发块时 `truncated: true`。**这些键只在真的发过帧时出现**。
- **不发半套帧**：`stream` 为假、op 不支持、或传输层给不出 emit 通道时，
  一律退回单帧，且不得声称 `streamed`。

**V-191**：**流式不改结果语义**。响应行里的 `out` / `value` / `code` 仍是
完整结果（与不带 `stream` 时同一个 `Handle.wait`）；流只是**多给了中间过程**。
超限时以 `max-output` 为界停止发块（不无限灌连接），已发内容不再收回。

**V-192**：`capabilities.stream_ops` 是**唯一**的流式能力声明。
0.79.0 只含 `exec`。新增可流式 op 必须先改这张表，再改实现 ——
顺序反过来就会出现「客户端发 stream 却收不到帧」。

**V-193**：`cancel` 是 op，语义边界必须如实：

- 载荷 `target`（被取消请求的 `id`）。目标不存在/已结束 → `409 cancelled=false`。
- **只有 `exec` 可取消**；其余 op 在跑时取消 → `409 cancelled=false` + 原因
  （不假装成功，也不谎称已停）。
- `exec` 已 spawn → 立即 `kill`，被取消请求以 `code=137`（128+SIGKILL）、
  `ok=false`、`cancelled=true` 收场，与 `Sys.cancel` 同一套码。
- `exec` 尚未 spawn 完（取消来得太早）→ 记 `cancel-requested`，spawn 后补杀，
  回 `cancelled=true` + `deferred=true`。
- `cancel` **不进串行执行队列**：读循环就地处理，否则它只能排在长请求后面，
  等于没取消。取消本身进审计（`stage=cancel`）。

---

## 3.10 统一审计（V-194…V-196，0.80.0 / ADR-0018）

**V-194**：`Rakuish::Audit.record` 是**唯一写入函数**。

- 字段白名单：`token` / 文件内容 / SQL 全文 / 源码全文**结构上进不来**，
  不靠调用点自觉（V-606）。源码只记 FNV-1a 指纹 + 字节数；编译错误消息
  也不记（Rakudo 常把源码片段带进消息）。
- 自动补 `seq` / `ts` / `origin`；内存 10k 条上限、JSONL 单行追加、
  10MB 轮转、跨实例锁。落盘失败只退化为内存，不影响业务。
- 新实例以现有 JSONL 行数为 `seq` 起点，多进程追加时保持连续。

**V-195**：**每次操作恰好一条**。

| 前端 | 调用点 | 覆盖 |
|---|---|---|
| 人（REPL / `-e` / 脚本） | `Kernel.execute` 的 `LEAVE` | 成功、失败、会话级命令、坏请求、策略拒绝、root 越界早返回、异常 |
| Agent（结构化 op） | `Sandbox.audit` | 成功、401 / 403 / 409、504、cancel、op 执行 |

- `Kernel` 必须用 `LEAVE`（不是末尾调用）：0.76 的
  `return $r if $denied` 会绕过末尾记账，安全事件反而漏了。
  `t/40` 用这条路径做变异护栏。
- 两个调用点可注入**同一个 Audit 实例**做双前端对账；`Sandbox.entries`
  代理到它，不再维护第二套。
- 默认开启，默认落盘 `$*HOME/.rakuish/audit.jsonl`；
  `RAKUISH_AUDIT` 覆盖路径，`RAKUISH_NO_AUDIT=1` 关闭。

**V-196**：分工与诚实边界。

- `Audit`（机器 / 安全）、`Session.log-line`（人类可读会话抄本，含渲染文本）、
  `Kernel.trail`（200 条内存调试视图）、`display`（结果内容）**四者不合并**。
- 审计是**事后可查**，不是事前阻止；本地 REPL 是同用户可信环境，
  日志文件同用户可写，**本版不防篡改**（需外部追加-only 时另立项目）。
- `execute` op 不做；Agent 默认无脚本路径见 V-607。

---

## 3.11 能力定位变更登记（0.80.1，不新增条款、不改行为）

> **0.81.0 终结**：本节登记的 `stream` / `cancel` 已随 Agent 线整体撤销
> （ADR-0019）。保留此节只为记录「这两项能力曾在 0.79.0 存在、0.79.2 被收窄、
> 0.81.0 删除」的完整链条，**不要再按本节实现或放宽 V-607** —— V-607 已撤销。

0.79.0 的 `stream` / `cancel` 作用对象是 `exec`（`STREAM-OPS = <exec>`）；
0.79.2 的 **V-607** 让 `exec` / `pty_exec` 默认 403。因此
**默认配置下 `stream` 不发任何帧、`cancel` 恒为 409**，只有显式
`--allow-code-exec --allow-exec` 启动的不安全 profile 才用得上。

这改变了两项能力的定位（默认能力 → 可选 profile 能力），不是缺陷，
也不回退 0.79.0 的实现；但此前没有任何文档标记这次变更，0.80.1 在此
补登记（`docs/ADR-INDEX.md` §3、`HANDOFF` 缺口表、`docs/MANUAL.md`）。
**若要恢复默认流式，须先决定 V-607 是否放宽并另开 ADR。**

---

## 3.12 本机全权限（V-197…V-199，0.81.0 / ADR-0019）

**V-197**：Rakuish 是**单入口、全权限**的本地 shell。

- 唯一入口 `bin/rakuish`；REPL / `-e` / 脚本三种模式共用同一个 `Kernel`（V-182）。
- **没有 Agent 协议**：无 JSONL / TCP / token / op 白名单 / `--agent` 转发
  （0.81.0 删除，见 §6.1）。
- **没有沙箱**：`Rakuish::Sandbox` 已删除；不存在 `--root`（除非测试或用户显式
  给 `Sys.new(:root(...))` 做工作目录限定）。

**V-198**：**不设权限闸门**，且不保留「默认关闭 + 开关打开」的形态。

- Raku 源码直接 `EVAL`，不需要 pragma；`!` 直接 `Sys.exec` 起进程。
- **不存在** `allow-exec` / `allowlist` / `allow-code-exec` / `allow-sql` 这类开关。
  删掉而不是默认关：留一个默认关闭的开关，等于承认「打开就安全」，那正是
  ADR-0018 / ADR-0019 反复否掉的「牌子」。
- 注：0.81.0 时 `Policy` 上还留着 `allow-exec` / `read-only` 两个**无执行点**
  的字段（声明禁止、实际放行），0.82.0 已按 V-211 删除。
- 因而 V-503（无 eval op）与 V-604 / V-607（exec 白名单、代码执行闸门）
  失去适用对象，已撤销（见 §6.1）。

**V-199**：**唯一保留的越界检查是防误操作，不是安全边界。**

| 检查 | 行为 | 定位 |
|---|---|---|
| `Sys.resolve` 工作目录边界 | 越出会话 root 抛 `X::Rakuish::Bound` | 防手滑；root 默认 `/`（Windows 当前盘根 + all-drives），此时恒真 |
| 路径层级过深 | 抛 `X::Rakuish::Bound` | 防病态路径 |
| 拒绝删除文件系统根 / 会话 root | 抛 `X::Rakuish::Bound` | 防灾难性误操作 |

`X::Rakuish::Bound` 原名 `X::Rakuish::Sandbox`，0.81.0 改名 —— 全权限之后
再叫 Sandbox 就是误导。**这三条都不构成安全隔离**：同一用户能做的事，
Rakuish 里都能做，这是设计目标而不是缺口。

**V-211**：**一个策略字段要么有执行点，要么不许存在**（0.82.0 / ADR-0020）。

- 判据：`Policy` 的每个字段必须在 `lib/` 里至少有一处**判定语句**读取它，
  且该判定能改变 `Result`（拒绝 / 收窄 / 越界 403）。
- 做不到就不要加字段。需要「记录意图」时用 `profile` 标签，
  不要用布尔开关 —— 布尔开关会被读成保护承诺。
- 推论：`allow-exec` / `read-only` / `allow-ops` / `limits` 已于 0.82.0 删除；
  `capabilities.policy-fields` 只报 `<profile allow-source root>`。
- 护栏：`t/35` 用 `^can` 断言这四个方法**不存在**。不用「值为 False」——
  字段被加回来且默认为假值时那种断言仍然通过，等于没有护栏。

---

## 3.13 求值引擎子进程（V-212…V-216、V-226…V-228，0.83.0 / 0.87.0 / 0.88.0 / 0.89.0 / ADR-0021）

**V-212**：**交互式 REPL 的 `EVAL` 跑在 `raku` 子进程里**（0.83.0）。

- 父进程（`bin/rakuish`）保留行编辑、prompt、banner、渲染输出与审计；
  引擎子进程持有 `REPL::Session` 的全部求值状态（`%STATE` / `@decls` /
  `Out[n]` / `Sys` / Shell / 内建命令）。
- 理由：同进程 `EVAL` 下，用户代码 `exit`、段错误、`while 1 {}` 三条都会
  带走整个 REPL，且第三条**无法**用 SIGINT 打断（本版实测）。
- `Kernel` 与审计**不感知**这层：`Rakuish::Eval::Proxy` 冒充
  `REPL::Session`，`Kernel.execute` 的实现一行未改（V-182 不变）。
- 模块：`Rakuish::Eval::Server`（子进程入口）/ `Rakuish::Eval`（Client）/
  `Rakuish::Eval::Proxy`（门面）。

**V-213**：协议是**一行一个 JSON、串行请求/响应**。

- 所有帧强制 `:!pretty`。`JSON::Fast` 的 `to-json` 默认会输出多行，
  按行切帧会把一帧切成多条残缺 JSON —— `t/41` 有专门断言。
- 同一时刻只有一条请求在飞；`seq` 必须对齐，不做并发、不做多路复用。
- 响应里的 `text` 是引擎**渲染好的最终文本**（含 `Out[n]` 与颜色）；
  父进程不二次渲染，也不接收 Raku 值对象。
- 用户代码的 stdout 进 `out` 字段（`CapturingOut`），**不混进协议流**；
  `$*ERR` 走子进程 stderr，父进程原样转发。

**V-214**：**崩溃是失败结果，不假装成功**。

- 引擎退出 ⇒ 请求抛 `X::Rakuish::Eval::Dead` ⇒ `Proxy` 重启一次 ⇒ 返回
  `Result(:!ok, :code(500), :op<engine-restart>)`。
- 结果文本**必须**同时说明「已自动重启」与「会话状态已丢失」两件事，
  缺一件就是误导（`t/41` 两条独立断言）。
- 重启成功后 `Out[n]` 从 1 重新开始；`%STATE` / `@decls` / 数据引擎连接
  全部丢失。**不做状态恢复** —— 让它看起来没丢等于骗用户。
- 崩溃的那一格仍被审计记一条（`LEAVE` 在 `Kernel.execute` 里，与引擎死活无关）。

**V-215**：`! --tty` **交回父进程执行**。

- 引擎的 stdio 是协议管道，`Sys.tty-exec` 在里面只能报「无 TTY」。
  `Session` 通过 `&tty-handler` 注入点把 `(exe, argv)` 交给父进程。
- 父进程用自己的 `Sys`（真终端、cwd 与引擎同步）执行，结果经 `resume`
  帧回传；引擎继续走原来的 `!remember` / `strict-result` 流程。
- argv 仍是数组，不拼 shell 字符串（V-153 / ADR-0001 不变）。
- 未注册执行器时必须**明确失败**（`127` + 说明），不能静默当成功。
- 回归：`t/30`（POSIX 真 PTY）+ `tools/ctrl-c-win.py` 的场景二（Windows
  真 ConPTY，0.87.0 补齐）。两者都验：子进程收到 SIGINT 并退出、
  宿主 REPL 未被带走、交接后 prompt 回来且能继续求值。

**V-216**：**只有 TTY 交互 REPL 走 worker**。

- `-e` / 脚本 / 管道保持进程内 `Session`：它们没有「会话要继续」这回事，
  崩了就崩了，多一层进程只是多一处出错点。
- 分流依据是 `$*IN.t`；管道模式的输出契约（V-116：stdout 只有求值结果）
  不受影响。
- 求值中的硬中断由 0.85.0 补上（V-221…V-224），本节该条已作废。

**V-226**：**真实终端是不是 TTY，由入口注入，引擎不许自己探测**（0.87.0）。

- 引擎子进程的 `$*IN` / `$*OUT` 是**协议管道**，`.t` 恒为 False。任何
  「在引擎里问 `$*OUT.t`」的判定都会得到错误结论，且错得很安静。
- `Session.tty` / `Shell.tty` 是会话属性，入口经协议每格推送
  （`Client.eval(:tty)` → Server → `set-tty`）。`set-tty` 必须**同时**
  同步 Shell：只改 Session 会出现「路径列表彩色、`ls -l` 无色」的半截状态。
- 已知曾因此退化的行为：`clear` 静默不输出（0.83 起，0.87.0 修复）；
  shell 彩色全灭；多列 `ls` 退化成单列。回归见 `t/10`、`t/41`。
- 管道 / `-e` / 脚本仍是进程内 `Session`，其 `tty` 由自己的 `$*OUT.t` 判定，
  输出契约（V-116）不变。

**V-227**：**终端尺寸与 TTY 同源，也必须由入口下发**（0.88.0）。

- `Session.width` / `Session.height` / `Shell.width` / `Shell.height`，
  经 `Client.eval(:width, :height)` 每格推送；`0` 表示未知，**不覆盖**已知值。
- 取数来源是**问终端**，不是读环境：POSIX `ioctl(TIOCGWINSZ)`（stdout，
  失败再用 stderr），Windows `GetConsoleScreenBufferInfo`。
- `%*ENV<COLUMNS>` 只作最后兜底：它是 shell 变量，bash 只在交互式 shell
  里赋值且默认不导出，`resize` 之后还会陈旧。实测过的错误：40 列终端里
  `ls` 按 80 列排出 76 字符宽的行。
- 未知宽度时排版回落 80 列 —— 这是**渲染策略**，所以放在 Session，
  不放在 `Rakuish::Sys::Term`（后者只回答事实，不知道默认值该是多少）。
- 已知未覆盖：不做 SIGWINCH 订阅（每格查一次已足够，ioctl 是微秒级）；
  `COLUMNS` 若被用户显式覆盖，仍以真实终端为准。
- `height` 的执行点是分页器每页行数（`pager-page-size` = 高度 − 2，
  未知时 20）。**没有执行点的字段不许留**（V-211 的同一把尺子）。

**V-228**：`tty` 与 `live-out` 是**两件事**，混用会写进协议流（0.89.0）。

| 谓词 | 含义 | 用于 |
|---|---|---|
| `tty` | 用户面前有终端（前端下发） | 排版：颜色、列数、`clear` 的 ANSI |
| `live-out` | **本进程的 stdout 就是那个终端**（`$*OUT.t`） | 分页、逐行流式输出 |

- 引擎子进程里 `live-out` 恒 False（stdout 是协议管道），`tty` 可以 True。
- 分页器（`explore`）与 `ls -R` 的流式分支必须判 `live-out`：
  它们要往真 stdout 写、再读真 stdin。
- **0.87 的实测事故**：`tty` 注入后这两处改判 `tty`，于是引擎里的分页器把
  表格文本插进 JSON 协议流、又把父进程的下一个请求当「按键」吃掉 ——
  REPL 直接卡死（`explore` 一个大表即可复现，见 `t/41` ⑧⑨）。
- 推论：**「能写到终端」不等于「用户能看见终端」**。凡是涉及 fd 的副作用，
  都要问 fd 本身，而不是问前端下发的意图。

---

## 3.14 会话快照（V-217…V-220，0.84.0 / ADR-0022）

**V-217**：引擎在**每次成功格之后**写一份会话快照（0.84.0）。

- 内容只有两样：`%!state`（跨格变量的纯值）与 `@!decls`（纯声明源码）。
- **只在成功格后写**：失败格没有改变可持久状态，写了会冲掉上一份好快照。
- **语句格不重放**：副作用不幂等（`write(...)` / `! rm` 会执行第二次）。
- 覆盖路径：`RAKUISH_SNAPSHOT=<path>` → `$*HOME/.rakuish/session-<cwd指纹>.json`
  → 空（纯内存）。`RAKUISH_NO_SNAPSHOT=1` 同时关闭**读与写**。

**V-218**：可序列化边界是**三类判定**，不是「能/不能」。

- 纯值（标量 / 集合 / DateTime / IO::Path / 枚举 / 属性可序列化的类实例）：
  存 `.raku`，恢复时 `EVAL`。实测 14/14 常见类型往返成功。
- **资源**（`Proc` / `IO::Handle` / `IO::Socket` / `Supply` / `Channel` /
  `Promise` / `Lock` / `DB::*` / `Rakuish::Data::Engine::*`）：**标记失效**。
  它们能「恢复成功」但语义是全新对象（`DB::SQLite.new(...)` 重连空库），
  静默的错误状态比崩溃更难查。
- **闭包 / Code**：标记失效（无反序列化）。
- 单值 `.raku` 超过上限标记失效，避免每格写几十 MB。上限**可配置**
  （0.87.0）：`RAKUISH_SNAPSHOT_MAX` 为字符数，`0` / `off` / `none` /
  `unlimited` 表示不限制；未设置时默认 `1_000_000`。
  **非法值（负数、非数字）回落到默认**，不许把「写错了」解释成「关掉保护」。
- `classify()` 本身是纯函数（`:max` 由 `capture` 传入），不读环境 ——
  谁读环境，谁就没法被单测稳定覆盖。

**V-219**：恢复是**显式发起**的，且必须如实报告。

- 只有 `Eval::Proxy` 的崩溃重启路径发 `restore` 命令；正常启动不自动恢复。
- 摘要必须同时给出：恢复的声明数、变量数、**失效变量名列表**。
- 恢复失败时（无快照 / 版本不符）仍走「会话状态已丢失」，**不假装恢复过**。
- 失效变量置为 `Any`（未定义），不是「保留一个旧值」。
- 引用别名（`my $a := $b`）恢复为两个独立拷贝；不承诺引用语义。

**V-220**：快照格式**不迁移**。

- `snapshot-version` 不符时整体忽略（当作没有快照），不猜字段、不做转换。
- 坏 JSON / 不可读文件一律返回空 Hash，启动流程不被它挡住。
- POSIX 上文件权限收紧到 `0600`；**不承诺**防住同用户进程 ——
  要更严格用 `RAKUISH_NO_SNAPSHOT=1`。

---

## 3.15 求值期间的中断（V-221…V-224，0.85.0 / ADR-0023）

**V-221**：`Eval::Client` 在**等待响应期间**接管 SIGINT（0.85.0）。

- 不在求值时，handler 什么都不做，Ctrl-C 仍归行编辑器（输入中断 / 清续行）。
- 在求值时，handler 标记 `interrupted` 并**主动 kill 引擎**（SIGKILL）。
  不依赖「终端信号恰好也打到 worker」这个巧合 —— 同组只是当前现状。
- 引擎死 ⇒ `receive` 抛 ⇒ 标记为真则抛 `X::Rakuish::Eval::Interrupted`
  （与 `Dead` 分开的异常类）。
- 引擎**不能**自己处理：SIGINT 打不断 `while 1 { }`（MoarVM 不在纯 VM
  循环里检查信号，实测）。

**V-222**：中断与崩溃**必须分开归因**。

| 情形 | `op` | `code` | 文案 |
|---|---|---|---|
| 用户 Ctrl-C | `interrupted` | `130`（128+SIGINT） | 「已中断当前求值（Ctrl-C）」 |
| 引擎自己退出 | `engine-restart` | `500` | 「引擎进程已退出（…）」 |

- 中断**不许**说「引擎进程已退出」——会让用户以为出故障；
  崩溃**不许**说「已中断」——那是掩盖故障。
- 中断的那一格不产生 `Out[n]`，但 `perf` 记录其耗时。

**V-223**：中断后的恢复与崩溃**共用同一条路径**。

- 引擎重启 → 从快照恢复声明与纯值（V-217…V-220）→ 报告恢复摘要。
- 快照是上一格成功时写的，正好是「中断前那一刻」的状态。
- 重启失败时仍报 `op=interrupted` / `code=130`，但文案说明重启失败。

**V-224**：前端必须**消费**行编辑器的 `take-interrupt` 标志。

- 求值期间的 SIGINT 会让行编辑器也记一个标志；不清理的话，它会在**下一轮**
  被当成「输入中断」执行 `next`，吞掉用户输入的下一格。
- 条件：仅当结果 `op=interrupted` 时消费，其余情况保持既有语义（V-168）。

**V-225**：中断契约必须有一层**真终端**验收，不能只有单测（0.86.0）。

- 位置：`tools/ctrl-c-posix.py`（真 PTY）/ `tools/ctrl-c-win.py`（真 ConPTY）。
- 两者的步骤与断言名**保持一致**，便于跨平台比对：
  `ready` / `baseline` / `control_input_intr` / `control_no_eval_intr` /
  `cell_started` / `spinning` / `alive_after_ctrlc` / `says_interrupted` /
  `says_crashed` / `says_input_intr` / `prompt_back` / `state_survived`。
- **两条必备的反假绿措施**：
  1. 用 `note 'SPIN'` 作门闩，看到它才发 Ctrl-C —— 否则测到的是输入中断；
  2. 不在求值时先按一次 Ctrl-C 作对照，必须得到「已中断当前输入」。
- 由 `tools/ci.sh` 的 `console` 层执行：退出码 0 = pass，2 = skip（环境不具备），
  其余 = FAIL。`skip` **不算通过**，报告里单独一行可见。
- 单测（`t/43`）与真终端层**不是替代关系**：前者验 handler 逻辑与归因字段，
  后者验「`\x03` 到底会不会变成信号」。

**平台**：Linux / WSL 与 **Windows 真控制台（ConPTY）** 均已验证（0.86.0）。

- 单测层：`t/43` 18 断言（POSIX 用 `kill -INT` 触发父进程 handler；
  Windows 用不了 `kill`，skip 12 条）。
- 真终端层：`tools/ctrl-c-posix.py` / `tools/ctrl-c-win.py`，在真 PTY / 真
  ConPTY 里敲 `note 'SPIN'; loop { }` 再按 Ctrl-C，断言四件事：
  归因是「已中断当前求值」、`code=130`、REPL 存活、`$keep` 经快照恢复。
- 两侧都带**对照**：不在求值时按 Ctrl-C 必须是「已中断当前输入」——
  没有这一步，「出现『已中断当前求值』」可能只是文案恒真。
- 两个探针由 `tools/ci.sh` 的 `console` 层调用，退出码 2（无控制台且无
  winpty）记 `skip`，其余非 0 记 FAIL。

Windows 上的注意点（实测，写在这里省一次排查）：`\x03` 只有在控制台输入
模式为 cooked 时才会变成 `CTRL_C_EVENT`。行编辑器在 `prompt` 返回时恢复
模式，所以「求值中」这个窗口里是对的；但探针若在格子还没开始时就发
`\x03`，会落到行编辑器手里、表现为「输入中断」——这是**假阴性**，
不是平台不支持。

---

## 3.16 `!` 的流式输出与超时（V-229…V-231，0.90.0 / ADR-0024）

**V-229**：**外命令的输出默认在终端里边跑边出**，但「是不是终端」由入口判。

| 形态 | 行为 |
|---|---|
| 交互式 REPL（父进程 stdout 是终端） | 引擎发 `chunk` 帧，父进程立刻写 stdout / stderr |
| `-e` / 脚本 / 管道 | 流式关闭，保持 0.89 的「收完再显示」 |

- 判据是**父进程**的 stdout 是否终端（`$*OUT.t`），不是引擎的 `live-out`
  （引擎恒 False）也不是 `tty`（那是排版意图）。
- 引擎不得直接打印：它的 stdout 是协议流。块只能走 `chunk` 帧。
- `chunk` 帧带 `seq`；父进程只接受当前请求的块，stale 块丢弃。
- 块边界是**读到的字节块**，不是行、不是字符边界；实现不得假设对齐。

**V-230**：`!` 的分发层新增三个元选项，语义固定。

| 写法 | 含义 |
|---|---|
| `! --capture cmd ...` | 强制不流式，输出回到 `Result.out`（0.89 行为） |
| `! --timeout-ms N cmd ...` | 本次超时 N 毫秒；`0` = 不超时 |
| `! --no-timeout cmd ...` | 等价于 `--timeout-ms 0` |
| `! --` | 之后的 token 全部按字面 argv，不再解析元选项 |

- 非数字 / 负数 / 缺参数的 `--timeout-ms` 返回 `code=127` 并给明确错误，
  **不许**静默回落到默认。
- 元选项属于 rakuish 分发层；子进程收到的仍然只有 argv 数组（V-901 不松动）。

**V-231**：流式结果必须**不重放**。

- `Result.streamed` 为真时，`out` / `err` 清空（启动失败除外：此时没有块，
  错误必须保留），`Session.render` 跳过 `out`。
- 超时（`code=124`）与非零退出不影响归因；`code` 原样保留。
- 引擎终帧必须带 `streamed` 布尔；父进程不得根据「out 为空」猜。

---

## 3.17 启动层：rc / prompt / 选项（V-232…V-236，0.90.0 / ADR-0025）

**V-232**：交互式 REPL 启动时执行**一个**启动文件。

- 路径优先级：`RAKUISH_RC=<path>` → `$*HOME/.rakuish/rc.raku`；不存在就跳过。
  **不读 `~/.rakuishrc`**（v2 的 KEY=VALUE 配置，格式不兼容）。
- `RAKUISH_NO_RC=1` 关闭（任意非空值）。`-e` / 脚本 / 管道**不执行** rc：
  它们必须可重复，不受用户 HOME 影响。
- rc 由**引擎**执行（声明 / alias / 选项 / prompt 都在引擎里），父进程只
  解析路径并显示输出。
- **逐行喂给 `eval-line`**，续行缓冲由 Session 持有；rc 写完后执行续行
  缓冲必须为空，否则报「文件结束时仍有未闭合结构」。
- rc 的格**不占** `Out[n]` / `history` / `perf`：执行完把 `index` 归零、
  三个历史容器清空；`exit` 请求也一并复位。状态（变量 / 声明 / alias /
  cwd / env / 选项）保留。

**V-233**：rc 的错误**如实上报、不阻断后续行**。

- 失败行计入 `failed`，错误文本带 `<path>:<行号>:` 前缀。
- 一行失败不终止整份 rc（shell 的 source 语义）；只有未闭合结构在文件末尾
  单独报一次。
- 崩溃重启后 **rc 重新执行**（不是从快照恢复）：它定义的是会话策略，
  重放一次才符合 shell 语义。重启摘要必须说明这件事。

**V-234**：`repl.prompt` 是可编程 prompt，返回值就是完整 prompt。

- 类型是 Callable，签名无参、返回 Str（`Nil` / 未定义视为空）。
- **每次取 prompt 都重新调用**：时间 / git 这类信息必须是当下的。
- 函数里写到 `$*OUT` / `$*ERR` 的内容被吞掉，不污染结果流 / 协议流。
- 异常返回空串，前端回退默认样式 —— 坏 prompt 不能让 REPL 无法输入。
- 返回值中的换行压成空格（行编辑器按行算光标）。
- **续行期间不调用**：续行固定用默认的 `···`，否则用户分不清是否在续行。
- 引擎经 `prompt` 命令返回；父进程每格问一次。

**V-235**：`set` 是选项系统，不是字符串开关。

| 选项 | 默认 | 执行点 |
|---|---|---|
| `errexit` | off | 失败格请求退出（`set -e` 的别名） |
| `histexpand` | on | 是否认整行 `!!` / `!$` / `!n` |
| `noglob` | off | Shell 薄层不展开 `* ?`（`glob` 命令不受影响） |
| `noexpand` | off | Shell 薄层不展开 `$NAME` / `~` |
| `xtrace` | off | 求值前把 `+ <源码>` 写到 stderr |

- `set` / `set -o` 列出全部；`set -o NAME` 开、`set +o NAME` 关。
- 未知选项返回失败并列出可用名字，**不静默接受**。
- 选项只在会话内有效；要跨会话就写进 rc（rc 会在重启后重跑）。

**V-236**：每个选项必须有执行点；没有执行点的键不许进表（V-211 同一把尺子）。

- `noglob` / `noexpand` 由 Session 同步到 Shell 薄层；Shell 不另存一份配置。
- `xtrace` 走 stderr，不进 `Result.out` / `Out[n]`；rc 里开启后，后续 rc 行
  也会被 trace。
- `histexpand` 关闭后 `!!` 落回外部命令（通常 `code=127`），这是显式结果，
  不是「静默退化」。

---

## 3.18 结构化管道（V-237…V-244，0.91.0 / ADR-0026）

**V-237**：`stream(...)` 是结构化管道的**唯一入口**，返回
`Rakuish::Data::Stream`（惰性 `Seq` of `Hash`）。

| 入参 | 行为 |
|---|---|
| `Str` | 按 `:format` 解析，默认 `lines` |
| `IO::Path` | 读文件后同 `Str`（文件不存在抛 `X::Rakuish::NotFound`） |
| `Result` | 取 `out` 按行；**失败 Result 抛 `X::Rakuish::CommandFailed`** |
| `Table` | 逐行展开 |
| `Cursor` | 真惰性；标记为一次性（V-240） |
| `Positional` | 元素是 Hash 就展开，否则包成 `value` 列 |
| `Hash` | 单行 |

- `:format` 取值固定六种：`lines` / `csv` / `tsv` / `json` / `jsonl` / `pattern`；
  其它值抛 `X::Rakuish::Unsupported`，**不静默回落 lines**。
- `pattern` 必须给 `:pattern`（Regex），否则抛 `X::Rakuish::Unsupported`。
- `json` 只接受对象数组；`jsonl` 逐行解析，坏行报出**行号**。
- 抛出的 `CommandFailed` 必须同时带 `:detail`：`X::Rakuish::V3` 族的 `detail`
  是 required 属性，只给 `:result` 会变成 `X::Attribute::Required`（实测）。

**V-238**：文本解析的**列顺序由解析器给出**，不依赖 Hash 键顺序。

- `lines` 的列是 `n, line`（行号从 1 起）；`csv` 用表头顺序（复用
  `Rakuish::Data::from-csv-data`，不写第二份引号状态机）；`tsv` 同理；
  `pattern` 是 `n` + 给定 `:names`，不给名字时用 `c0 / c1…` 与正则具名捕获。
- 列顺序错了会直接体现在 `select` / `to-text` 上，所以这条是契约不是实现细节。

**V-239**：惰性边界必须写明，不许假装。

- 惰性：`where` / `select` / `drop` / `map` / `add-column` / `limit` / `skip`。
- 物化：`sort-by` / `unique` / `count-by` / `group-by`（排序 / 去重 / 分组本来
  就要看完全部记录）。
- 断言方式：上游是生成器时，`limit(3).count` 只允许拉 3 行（`t/46` 用计数器守）。

**V-240**：一次性来源只能消费一次。

- `repeatable=False` 的流（Cursor / 进程通道）第二次取会抛 `X::Rakuish::Data`，
  错误信息要指回来源；**不许**返回空流（空流会被误读成「没有数据」）。
- 文本 / Table / List 来源可重复消费；`$!taken` 只在 `repeatable` 为假时生效。

**V-241**：数字口径。`sum` / `mean` / `min` / `max` 先收 `Numeric`，再收
字面量数字字符串 `/^ '-'? \d+ [ '.' \d+ ]? $/`；不做进制 / 千分位 /
科学计数法（那些归数据引擎）。

**V-242**：`.exec($exe, *@args, :format<lines|csv|tsv|json>, :column)` 把记录写成
子进程 **stdin**，返回 `Result`。

- 必须走 `$*RAKUISH-SYS` 的 `Sys.exec`（cwd / env / 超时 / 审计与 `!` 同一条路）；
  没有会话上下文时抛 `X::Rakuish::Unsupported`，**不许**自己起进程绕过审计。
- `:format<lines>` 取 `:column` 或第一列，每行一个值；`csv` / `tsv` / `json`
  使用对应序列化（CSV 复用 `Table.csv-line`）。
- 子进程的 stdout/stderr 仍是 `Result.out` / `Result.err`，可以再喂给 `stream`。
- 0.93 起 stdin 是**流式**写的（见 §3.20），不再先把整份文本物化。

**V-243**：**不新增管道语法**。

- `|` / `>` / `&&` / `$?` 仍属 V-901「永不支持」。
- `|>` 在 Raku 语法里不可定义（实测 `sub infix:<|>` 报
  "Preceding context expects a term, but found infix >"），因此不作为候选。
- 管道 = 方法链；`==>` 是原生 feed（左值作为**最后一个**参数），可用于把流喂给
  自定义阶段 sub。

**V-244**：展示只有一套排版。

- `Session.render` 与 `Display.bundle-from` 遇到 Stream 一律先 `.table`，再走
  现有 Table 渲染 / 序列化；不许为流写第二套表格。
- 展示会消费一次流；一次性来源展示后再取按 V-240 报错。

---

## 3.19 前端分页（V-245…V-249，0.92.0 / ADR-0027）

**V-245**：交互式 REPL 的分页在**父进程**执行。

- 引擎只把整份文本放进 `Result.out`（0.89 起的既有契约），**不判断是否分页**，
  也不得把页面写到终端 —— 它的 stdout 是协议流（0.87 事故的根因）。
- 父进程每格取一次 `term-size()` 的 rows，每页行数 = rows − 2（至少 1）。
- 读「下一页」用真 stdin 的一行；读之前必须 flush 输出，否则观感是「卡住」。

**V-246**：`RAKUISH_PAGER` 有三档，每格读一次。

| 值 | 行为 |
|---|---|
| `auto`（默认 / 空值 / 未知值） | 只对 `explore`，且超过一页 |
| `always`（`on` / `1` / `yes`） | 任何超过一页的结果 |
| `never`（`off` / `0` / `no`） | 不分页 |

- 未知值**回落 auto**，不许回落 always：写错环境变量不该改变 `cat` 的行为。
- 非 TTY（管道 / `-e` / 脚本 / 重定向）一律不分页。

**V-247**：分页器只切页，策略与执行分离。

- `Pager.paginate($text, &read, &emit, :size)` 不碰 `$*IN` / `$*OUT`：读一行、
  写一行都由调用方注入，因此分支可单测。
- `Pager.wants-page(:op, :lines, :height, :mode, :tty)` 是纯函数，同一条策略
  不许在入口与测试里各写一份。

**V-248**：一页装得下时的行为，两条路径相反且都必须成立。

- `paginate`：返回 False 且**一个字节都不写**，调用方走原来的打印路径
  （没有分页的格在观感与测试里完全不变）。
- `page`（进程内、已接管输出）：交互路径下**必须打印**，哪怕只有一行 ——
  否则 `explore` 小文件会静默无输出（0.92 开发中漏过一次）。

**V-249**：分页期间的输入语义。

- `q` / `Q` / `quit` → 停止，剩余页不打印；其它任意输入（含空行）→ 下一页。
- 读键被中断（Ctrl-C）或遇到 EOF → 按 EOF 处理：停在当前页，异常不得抛进主循环。
- 不提供「上一页」/ 搜索 / 全屏备用屏。

---

## 3.20 流式 stdin（V-250…V-254，0.93.0 / ADR-0028）

**V-250**：`Sys::Proc.spawn` 接受 `:&in-chunks`（Callable → Iterable），与
`:in` **互斥**；同时给两个抛 `X::Rakuish::Unsupported`，不静默挑一个。

- 写入方每块 `await $proc.write(...)`：**这就是背压**，子进程不读则生成器不前进。
- 缓冲到 16 KiB 再写；循环结束后**必须**写出最后不足一块的尾巴。
- 子进程提前关闭 stdin 时立刻停止 pull；不得把剩下的流跑完。

**V-251**：两种「停下来」必须分开报告，且都不许抛。

| 现象 | 字段 |
|---|---|
| 子进程先关 stdin（`head -1` / `grep -q` / 自身崩溃） | `Result.value<in-early>` |
| 生成器自己抛（解析失败 / 一次性来源二次消费） | `Result.value<feed-error>`（带原始消息） |

`Handle.wait` 在生成 `Result` 前等喂入任务收尾（上限 2 s），否则这两个字段是
竞态产物。

**V-252**：`Stream.exec` 必须把**生成器**交给 `Sys.exec`，不得先物化。

- `lines` 取 `:column` 或第一列，每行一个值 + `\n`；`csv` / `tsv` 出表头再逐行，
  转义复用 `Table.csv-cell` / `csv-line`（**不写第二份引号规则**）。
- `json` 自己拼 `[` … `]`，元素单独序列化且紧凑（`:!pretty`）；**键序不作承诺**
  （Raku 的 Hash 没有插入序），只保证 JSON 语义等价。
- `:format` 只接受 `lines` / `csv` / `tsv` / `json`，其它值抛
  `X::Rakuish::Unsupported`，不回落 `lines`。

**V-253**：一次性来源的二次消费必须在 **`exec` 调用点**同步抛出
`X::Rakuish::Data`，不得退化成 `feed-error` + 子进程收到空输入（V-240）。

- 实现方式：`exec` 先 `self!seq` 取一次 Seq（只建不拉），再把这个 Seq 交给
  生成器，避免后台线程里才第一次取。

**V-254**：喂 stdin 不吃 `max-bytes`（那是限制子进程输出的）；`:timeout-ms`
仍作用于整个子进程，超时 cancel 之后写入方因 broken pipe 自然停止，不额外报错。

---

## 3.21 两条流：zip / join / tee（V-255…V-260，0.94.0 / ADR-0029）

**V-255**：`Stream.zip($other, :$suffix, :$longest)` 按**位置**配对。

- 默认取较短的一条（与 Raku 的 `Z` 一致）；`:longest` 补齐，缺的一侧留空。
- 右列与左列重名时加 `:suffix`（默认 `_right`）；不冲突不改名。
- 两侧都有列元数据时，结果列顺序 = 左列 + 右列；否则留给 `.table` 推断。
- `$other` 可以是 `Stream` / `Table` / 记录列表（`Positional` of `Hash`）。

**V-256**：`Stream.join($other, :$on | :$left-on/:$right-on, :$how, :$suffix)`
是 hash join：**右表物化**、左表流式。

- `:how` 取值 `inner` / `left` / `right` / `outer`，**默认 `left`** ——
  与 `Table.join` 的历史行为一致；两个同名 API 不允许有两个默认值。
- 一对多出笛卡尔积；`right` / `outer` 在左表耗尽后补出右表的未匹配行。
- 键比较 `(值 // '').Str`：CSV 的 `"1"` 与 `1` 必须能对上；缺失当空串。
- 右表只物化**一次**（不是每来一条左行重建索引），`t/49` 用计数器守。

**V-257**：列合并规则只有一份实现 —— `Table.join-columns`（纯函数）。

- 左列在前、右列其次、重名右列加 `:suffix`，**不丢列**。
- `Table.join` / `Stream.join` / `Stream.zip` 三处都调它，不许各写一套后缀规则。
- 右表没有列元数据（json 来源 / `map` 之后 / 行列表）时**右列统一加后缀**：
  判断不了冲突时宁可多改，也不让右值覆盖左值。

**V-258**：`Stream.tee($path, :$format, :$column, :$append)` 是 Unix `tee`：
写一份副本并照常把行送下去。

- **不是** fan-out（不把一条流同时喂给两个消费者）。
- 路径经 `$*RAKUISH-SYS.resolve` 解析（root 约束同 `!` / `save`）；无会话时抛
  `X::Rakuish::Unsupported`。
- 格式与 `Stream.exec` **共用** `!fmt-head` / `!fmt-row`：`:format<csv>` 的字节
  与 `.csv` 一致（含引号转义）。
- `:append` 用 `open(:a)`（`:w` 会截断），且**不重写表头**。
- 写多少取决于下游读多少：`limit` 放在 tee **上游**才会得到「正好 N 行且已 close」
  的文件；放在下游会留下半截未关闭的文件（手册写明）。
- 结果恒为一次性（有副作用）。

**V-259**：入参错误必须当场抛，不许猜。

- `join` 缺 `:on`（且未同时给 `:left-on` / `:right-on`）→ `X::Rakuish::Unsupported`。
- `:how` / `:format` 取值非法 → `X::Rakuish::Unsupported`。
- `$other` 不是 `Stream` / `Table` / 记录列表 → `X::Rakuish::Unsupported`。
- 路径越出 root → `X::Rakuish::Bound`（与 `Sys.resolve` 同一道门）。

**V-260**：`repeatable` 取两侧的与。

- 任一侧是一次性来源（游标 / 进程通道）→ 结果一次性；`tee` 恒一次性。
- 第二次消费给出「已经读过一次」，不得静默重写文件或返回空流（V-240 的延伸）。

---

## 3.22 按顺序收拢两条流：interleave / append（V-261…V-264，0.95.0 / ADR-0030）

**V-261**：`Stream.interleave($other, :$shortest = False)` 按**位置**交替取
左1、右1、左2、右2……（round-robin，不是 zip 的配对）。

- 默认**吐完长侧**：一方耗尽后继续把另一方剩余吐完（收拢不是配对，不丢记录）；
  `:shortest` 才在任一侧耗尽时停。这是与 V-255 `zip` 默认取短的分界。
- 完全惰性：每轮两侧各 `pull-one` 一行；短侧耗尽后继续 pull 靠 `IterationEnd`
  的幂等性跳过。
- `$other` 可以是 `Stream` / `Table` / 记录列表（`Positional` of `Hash`）。

**V-262**：`Stream.append($other)` 先吐完左流再吐右流（Unix `cat` 对同构流）。

- 完全惰性，且左流耗尽之前**不碰**右流：`!rows-of($other)` 在左侧循环之后才
  调用。一次性右来源若被提前标记已消费，`limit` 左流就会无故毁掉右流。
- 列元数据取左侧，左侧未知（json / `map` 之后）才取右侧；**不取并集** ——
  异构流并集会让「接错流」隐形，沿用左列则让右侧多出的列显成缺值。

**V-263**：两个动作都**不改行、不改名**，与 `zip` 的合成一行分道扬镳。

- `zip` 合成一行 → 同名列加 `_right`（`Table.join-columns`）。
- `interleave` / `append` 每行保持原样 → 不存在同一行里的撞名，**不调用**
  `Table.join-columns`。`interleave` 列取两侧并集（保序、不改名），`append`
  取左侧。任意一侧列未知时留空，交给 `.table` 从实际行推断。

**V-264**：一次性来源传播与错误口径与 V-260 / V-259 一致。

- `repeatable` 取两侧的与；二次消费给「已经读过一次」，不静默给空。
- `$other` 类型非法与 `zip` / `join` 一样在**消费时**由 `!rows-of` 抛
  `X::Rakuish::Unsupported`，不猜、不回落（SPEC V-259 的「当场」指不回落，
  不是构造期）。
- 不引入 shell 管道语法（V-901）。

---

## 3.23 TTY 后台作业 API（V-265…V-269，0.96.0 / ADR-0031）

**V-265**：四个普通 Raku 函数 `bg-exec($exe, *@args)` / `bg-jobs()` / `fg($id)` /
`bg($id)` 提供作业控制，**不引入 shell 语法**（V-901 不松动）。

- 返回真值：`bg-exec` / `fg` / `bg` 给 `Result`，`bg-jobs` 给 `Table`。
- 不解析 shell 字符串，argv-only，与 `exec()` 同一类东西。
- 不做 `&` 后缀、不做 `jobs` 保留字。

**V-266**：`bg-exec` 起一个自成进程组的后台作业并**立即返回** job id。

- 复用 `spawn-in-group`（SETPGROUP，无竞态），但**不**调 `tcsetpgrp`——
  前台仍是宿主，子进程继承 fd 0/1/2 直接写终端。
- 登记进父进程的 `JobTable`（id → pid/pgid/cmd/state/时间）。
- cwd / env 走会话 `Sys`，与 `!` 同一条路。

**V-267**：作业表建在**父进程**，不建在引擎。

- 引擎会因 Ctrl-C / 崩溃重启（ADR-0021 / 0023）；表若在引擎，后台进程重启后
  成孤儿。父进程持有真终端 + 作业表，是唯一落点。
- 引擎侧 DSL 函数经 `Sys.job-op` → `job-dispatch` hook → `event => 'job'` 帧
  转到父进程（与 `tty-exec` hook 同构，同一条请求/响应管道）。
- hook 未注入时（`-e` / 脚本 / 单进程）回落到本地方法。
- 与 `Sys.spawn()/jobs()`（捕获式后台、Promise/Handle）**分工不合并**：
  新 API 叫 `bg-jobs()`，不覆盖 `jobs()`，`!cmd-jobs` 不动。

**V-268**：`fg(id)` / `bg(id)` 的语义与 Ctrl-Z 边界。

- `fg`：切前台 → `SIGCONT` → 轮询等待 → 退出或再次被停 → **收回前台**。
  用 `wait-state`（`WNOHANG|WUNTRACED|WCONTINUED`）非阻塞轮询，**不装 SIGCHLD
  handler**（避免和 Rakudo 的回收抢信号，V-175）。
- Ctrl-Z（SIGTSTP）停住时返回 `state=stopped` 并立即归还前台，**不让 REPL
  卡死**（补 ADR-0010 §6.4 的已知边界）；不放行 `\x1a`、不改行编辑器。
- `bg`：只发 `SIGCONT`，前台不动。
- `fg` 的 `ok` 表示「带回动作成功」，不是「子进程 exit 0」；后者在
  `code` / `value<exit>`。

**V-269**：POSIX-only 与错误口径。

- Windows 上四个方法返回 `code=127` + 明确错误（无前台进程组，ADR-0010 §3），
  不退化成捕获式后台——那是 `spawn()` 的职责。
- 非法 id / 已结束作业 / 启动失败都返回失败 `Result`，不抛异常穿透。
- `repeatable` / 一次性来源语义不适用（作业表是父进程长生命周期对象）。
- 不做 SIGWINCH 转发、不做孙进程树回收（V-905 不变）。

## 3.24 tail -f 跟随（V-272…V-276，0.99.0 / ADR-0033）

**V-272**：`tail [-n N] [-f|--follow] 文件` 的跟随模式：先打末 N 行
（默认 10；`-n 0` 只看新增），然后**轮询**文件增长（0.2s 间隔，不用
inotify/kqueue——一个实现跨平台）。只吐完整行（`\n` 结尾），半行进
缓冲补齐再吐；缓冲按字节拼，整行才解码（跨 poll 的多字节 UTF-8 安全）。
紧凑形式 `-5f` / `-f5` 与 `-n N` 同时可写。CRLF 的行尾 `\r` 剥掉。

**V-273**：截断 / 轮转语义：文件变小（截断、被替换）→ 当作新文件从 0
重读；文件消失 → 等它回来，重现后按新文件处理。不做 inode 级
`tail -F` 跟踪——轮询 + 大小比较已覆盖日志轮转的常见形态。

**V-274**：执行位置与 Ctrl-C 归属：跟随循环在**持有真终端的父进程**里跑
（引擎经 `job-op('tail-follow')` 转过去，与 tty-exec / bg-exec 同构；
单进程模式回落本地，自装 SIGINT tap 当停止信号）。跟随期间 Ctrl-C 的
语义是**停止跟随**（code=130，128+SIGINT，用户意图不是故障），**不**重启
引擎——会话现场（my / our）原样保留。`head -f` 明确拒绝并指路 `tail -f`。

**V-275**：输出契约：跟随的行经专用通道**实时显示**，不进 `Result.out`
（render 不重放）；`Result.out` 只有一行停止摘要（`已停止跟随（Ctrl-C）·
输出 N 行`），`value => %(lines, stopped)`。`op` 恒为 `tail`。

**V-276**：文件不存在 / 不是普通文件 / 负行数：与 `read-lines` 同口径抛
`X::Rakuish::NotFound` / `X::Rakuish::Path`，Shell 层收敛成失败 `Result`。

---

## 3.25 交互手感层（V-277…V-282，0.100.0 / ADR-0034）

**V-277**：autosuggestion 灰字：输入行渲染在**内容段之后、padding 区内**
追加灰色建议后缀（宽度截断到 padding，总显示宽恒等于 display-width；
光标定位仍按 buffer 几何独立计算，建议串本身不参与）。来源是**历史**
（最近一条以当前行为前缀的记录，多行只取首行）；空行不给建议；仅
光标在行尾、尾段整段可见、非掩码输入、高亮开启时出现。`CursorRight` /
`Ctrl-F` 整句接受；无建议或不在行尾时退化为 `move-char-forward`
（不改既有键义）。建议来源扩展（补全候选 / 路径）明确留待后续——
建议是每键重算的热路径。

**V-278**：Tab 补全公共前缀优先：多候选共享**长于已输入文本**的公共
前缀时，候选序列首位放公共前缀补全（无尾随空格），其后才是逐个候选
（完整替换行契约不变）；单候选或前缀等长时不插入前缀项。上游 Tab
循环（`do-complete`）不动，靠候选排序实现。

**V-279**：候选菜单：`ShiftTab`（动作 `complete-list`）把候选去重
（按去尾空格归一——公共前缀候选与同词候选不重复显示）、按列排布打印
在输入行**下方**，最多 6 行、超出记 `…(+N)`；随后重打 prompt 并在新行
重绘输入区（避开底部滚屏后的存盘光标错位，等价 readline 列表行为）。
掩码输入（密码）与空候选不出菜单。

**V-280**：错误态标记：`Highlight.error-marks`（回调注入的纯函数）返回
`(start, end, kind)` 区间，`highlight-line :@marks` 把相交**段**改错误色
——**只换色不增删可见字符**（strip-ansi 等价不变式恒成立）。三个探测器：
① 括号失配 / 落单闭合（跳过字符串与注释；行尾未闭合开括号是续行常态
**不标**；跨行闭合由续行括号净数吸收）；② 命令不存在（shell 形行的首
词，跳过 Raku 关键字，查 COMMANDS / 用户层注册表 / PATH 一次性缓存）；
③ 路径不存在（shell 形行里 `./` `../` `~/` `/` 或含 `/` 的参数，引号内
不标、`-` 开头的选项跳过）。shell 形 = 无未引号
`$ @ % & ( ) [ ] { } ; | < >`。残余误报（用户自定义无括号 listop 形
调用）与精确化路径（引擎侧名字查询）记录在 ADR-0034 §2.4 / §4。

**V-281**：Ctrl-R 循环历史检索：首按把当前缓冲区内容存为查询串（可为
空 = 匹配一切），替换为「最近一条包含查询串」的历史记录；连按逐次走向
更旧的匹配（到头回绕）；任何其它编辑动作复位查询态。0.100.0 前
`key-bindings()` 宣称 Ctrl-R 搜索但真实键表未绑定——本版订正宣称与
实际一致。鱼式模态增量搜索（搜索行占 prompt、逐键过滤）明确**不做**：
需要拥有输入循环，与 V-155 边界一并在后续改造里做（ADR-0034 §3）。

**V-282**：补全模糊回退：前缀匹配（大小写不敏感）优先、命中时排序与
0.68 一致；**零前缀命中时**才做子序列回退（rank = 匹配跨度 + 缺口数，
升序、同分字典序，上限 50）。范围：Shell 命令名、SQL 表名 / 列名 /
关键字；**选项与路径保持前缀匹配**（带 `-` / `/` 的串做子序列噪声大于
收益）。公共辅助（`common-prefix` / `subsequence-rank` / `fuzzy-words` /
`suggest-suffix`）收在 `Rakuish::REPL::Complete`。

## 3.26 手感后续清单（V-283…V-286，0.101.0 / ADR-0035）

ADR-0034 §4 五项后续落地四项；第五项（鱼式模态增量搜索 + Tab-Tab 菜单）
仍推迟——需 fork 上游 `read-input`（0.0.23 里 170 行词法闭包），依赖升级
即漂移，与「不叠补丁」相悖，与 V-155 一起留待「拥有输入循环」的改造。

**V-283**：逐词接受建议——`Alt-CursorRight` 绑定
`edit-accept-suggestion-word`，吞掉灰字建议的前导空白 + 第一个词，剩余
留待再按；无建议时退化为 `move-word-forward`（不吞键）。`→`/Ctrl-F 整句
接受语义不变。上游 `decode-keyname` 对 CSI 修饰方向键（`\e[1;3C` →
`Alt-CursorRight`）有解，键名零障碍。

**V-284**：建议来源扩展——灰字建议除历史外，历史无命中时退到补全候选
（含路径，来自 Shell.completions）。用 `(buf,pos) → 候选` 缓存避免每键
扫盘 / 引擎往返；仍只进 padding 区，ADR-0011 宽度账本不变式不动。

**V-285**：`In[n]` / `Out[n]` 结果引用补全——光标前 prefix 形如
`(In|Out)[数字*` 时补出完整替换行候选（编号 1…结果历史长度，上限 50），
边界 `In`/`Out` 前不紧跟标识符字符。在引擎侧 Session 读 `@!out`，走既有
`complete` RPC，不扩协议。

**V-286**：命令不存在的引擎侧精确判定——`Session.error-marks` 的
`known-command` 回调加一层名字可见性：跨格 `sub`/`class`/`use` 声明
（`@!decls` 的 `<name>`）与跨格 `my` 变量（`%!state` 带 sigil 键）视为
已知，不标红。只消除误报，不把任意名字当命令补进表；判定在引擎内完成，
走既有 `error-marks` RPC，无新增往返。

## 3.27 结果渲染的 junction 边界（V-287，0.101.1 引入 / 0.101.2 补齐 display）

**V-287**：junction（`1|2` / `any(...)` / `all(...)`）是合法 Raku 值，
REPL 必须能承载，**不得崩在结果构造或渲染层**（0.101.0 及之前会崩）：

- `Result.value` 类型是 **`Mu`**（不是 `Any`）——`Junction` 是 `Mu` 的
  子类型、不是 `Any` 的子类型，用 `Any` 会在 `Result.new` 处抛 Type check。
- 「有没有值」用 `Result.value-defined`（junction 恒 True）；**不用**
  `.defined`（对 junction 会 autothread，在布尔上下文 splat）。
- 三种渲染格式（text / json / markdown）、`Session.render` 与内置命令展示口径
  `Result.display` 都把 junction 显示为它的 `.raku`（`any(1, 2)`）；`_` /
  `Out[n]` 里**保留 junction 原对象**，不降级成字符串。
- 检测必须在**调用点**做：Raku 对 junction 参数会逐分支调用函数体，
  函数内部看到的已是分支值（`$v.WHAT` 是 `Int` 而非 `Junction`），
  `$v ~~ Junction` / `.isa` 在函数内一律失效；只有 `$v.WHAT === Junction`
  在调用点才可靠。

---

## 4. Sys API（V-20x）

**V-201**：路径一律 `IO::Path`，不自建 `Platform::Path`。
`resolve` 做词法归一化 + **中间 symlink canonical 校验**，`../` 或真实目标越界
抛 `X::Rakuish::Sandbox`。

**V-202**：文件 API（经 `Sys` 委托到 `Sys::FS`）：
`read` / `write` / `append` / `ls` / `stat` / `rm` / `cp` / `mv` / `mkdir` / `glob`。
`write` 默认原子写（Windows 降级失败必须回滚，不先丢目标）；`rm` 不跟随符号链接、
拒绝删会话 root、支持 `:dry-run`；`cp -r` 遇到 symlink 直接拒绝；`ls file` 返回
单元素列表；`glob` 支持 `*` / `?`，`*` 不跨目录分隔符。

**V-203**：进程 API（`Sys::Proc`）：`exec` / `spawn` / `wait` / `cancel`；
`Handle.stdout` / `.stderr` 是 `Channel.Supply` 真流式输出。
`wait(:&on-out, :&on-err)` 可在进程还在跑时逐块回调（0.79.0，Agent 的
`chunk` 帧就建立在它上面）；回调抛异常只让该路停止转发，不影响最终结果。
`cwd` / `env` 经 `Proc::Async.start(:cwd, :ENV)` 显式下传，宿主 `$*CWD` / `%*ENV` 不变。

**V-204**：`exec` 永不抛：正常 `0`、启动失败 `127`、超时 `124`、取消 `137`；
`Result.value` 带 `exe / argv / timed-out / cancelled / truncated / start-failed` 供审计。
输出由 `Handle.wait` 边读边按 UTF-8 **字节**限流，超过 `max-bytes` 保留安全前缀并
丢弃后续（内存不随输出增长），且不切坏中文。

**V-205**：错误模型——读 / 写 / 列目录 / stat **抛异常**（Raku 风格）；
`rm` / `cp` / `mv` / `mkdir` 返回 `Result`；Agent 边界用 `Sys.try-op` 统一收敛。

**V-206**：Windows 只承诺 argv 外部命令 + 文件 API，不承诺 bash / POSIX 语法。
`IO::Path.mode` / `.modified` 在 Windows 上可能返回 0 或 1969 年假值，
`Stat` 如实返回、不编造时间；`DSL.recent` 检测到不可信时间就降级为全量。

**V-207**：`Result` 提供多格式渲染层 `render(Str $format = 'text', *%opts --> Str)`：

| 格式 | 别名 | 说明 |
|---|---|---|
| `text` | `txt` / `plain` | 默认人读格式；`ok/op/code/elapsed/out/err/value`，不掺 ANSI |
| `json` | — | JSON；默认紧凑，`:pretty` 展开；键序稳定（按 key 排序），路径统一 `/` |
| `markdown` | `md` | 标题 + 元信息 + `stdout` / `stderr` / `value` 代码围栏；围栏会自动加长 |

`to-text` / `to-json` / `to-markdown` 是等价便捷方法。未知格式抛
`X::Rakuish::Render`（定义在 `Rakuish::Result::Renderer`），不静默回落 `text`。
渲染层不读文件、不起进程、不改 `Result`。

---

## 5. DSL 与 Command（V-30x）

**V-301**：`Rakuish::DSL` 导出短 sub：
`ls / read / write / append / stat / rm / cp / mv / mkdir / glob / exec /
cd / pwd / cwd / resolve / env / get-env / set-env / unset-env /
try-op / timed / help / recent`。
它们委托给会话绑定的 `Sys`；用户想加「常用命令」就再写一个普通 Raku sub，
返回可组合的值，无需注册表、无需改分支表。

**V-302**：`Rakuish::Command` 提供 `role Command { name / spec / run(Sys, @args --> Result) }`、
`CommandSpec`（参数 schema → JSON Schema）、`ExternalCommand` / `BuiltinCommand`、
可扩展 `CommandRegistry`（默认 13 个命令）。加命令只需 `register(...)`。

**V-303**：`BuiltinCommand.run` 必须**透传** handler 已返回的 `Result`，
否则外层 `try-op` 会把子进程退出码伪装成 0、`out` 吞成空串。

**V-304**：内置命令统一附带 text 渲染：`BuiltinCommand.run` 返回的 `Result`
保留结构化 `value/out/err/op`，同时把 `render('text')` 写入 `Result.rendered`。
`Result.text` / `.to-text` / `.gist` 优先返回该缓存；`say $result` 与 REPL
展示内置命令结果时走 text，而不是对象的 raku 结构。`render('json')` /
`render('markdown')` 不受 text 缓存影响。

---

## 6. Agent 与 Sandbox（**0.81.0 整体撤销**，V-50x / V-60x）

> 本节全部条款已于 **0.81.0 / [ADR-0019](docs/ADR-0019-local-full-privilege-shell.md)**
> 随 Agent 线一并撤销。保留编号与摘要只为**可追溯**：老客户端 / 旧文档提到这些
> 条款时，能查到「它曾经是什么、为什么没了」。
> **不要按本节实现任何东西** —— 代码里已经没有对应模块。

### 6.1 撤销清单

| 条款 | 原内容（摘要） | 撤销原因 |
|---|---|---|
| V-501 | 请求为 JSONL（一行一个 JSON） | 结构化 op 协议随 Agent 删除 |
| V-502 | 解析 → 认证 → 策略 → 分派 → 审计 → 结构化响应 | 无请求方 |
| V-503 | op 白名单；**没有 `eval` op** | 本机全权限，Raku 源码直接 EVAL |
| V-504 | 每会话独立 `Sys`；`exec.cwd` 过 root；请求级 env 白名单 | 全权限：`!` 直接起进程，不做 argv/env 审查 |
| V-505 | 传输层 JSONL over stdio / TCP 只绑 127.0.0.1 | 没有传输层 |
| V-151 | 常驻多客户端 / `serve-once` / 每连接独立 Agent / worker | 没有常驻服务 |
| V-601 | 显式 `--root`（无默认值，不传就起不来） | 本机会话 root 默认 `/`（Windows 为当前盘根 + all-drives） |
| V-602 | 只监听 127.0.0.1 | 不监听 |
| V-603 | 启动时生成 token（CSPRNG） | 没有认证面 |
| V-604 | `exec` 默认关闭 + argv 白名单精确匹配 | 全权限，无白名单 |
| V-605 | 读写 1 MiB / 超时 30 s / 输出 1 MiB，请求级只能调小 | 限额是 Agent 的防护，本机保留超时（V-155）但不做请求级降级 |
| V-606 | 审计不含 token 与文件内容 | **保留其精神**，见 V-194…V-196（审计仍在） |
| V-607 | `allow-code-exec` 闸门（默认 False，启动期双开关） | 全权限：本机本来就能跑 Raku，闸门失去对象 |
| V-190…V-193 | `stream` / `cancel` 分帧与取消 | 分帧是协议能力，协议没了它就没有作用对象 |

### 6.2 唯一被继承下来的东西

**审计**。V-606 的「不记 token / 不记文件内容 / 源码只记指纹」被 V-194…V-196
继承，并升级为**全进程唯一写入点**（`Kernel.execute` 的 `LEAVE`）。
审计与安全壳是两件独立的事：壳撤了，账不能撤。

---

## 7. 明确不支持 / 待办（V-90x）

| 编号 | 内容 | 归属 |
|---|---|---|
| V-901 | bash / POSIX 语法（管道、重定向、变量展开、glob、heredoc、`&&` 短路语义、`$?`） | 永不支持；用 Raku 表达 |
| V-902 | `%magic` 分流、auto-shell 回退、反引号 shellq | 已删除（Phase 3） |
| V-903 | glob 转义、brace 嵌套等剩余完整语法 | 已实现（0.65，V-153）；Shell 薄层文件名参数仍只展开 `* ?` |
| V-904 | `class` / `role` / `grammar` 的跨格持久 | 已实现（0.65，V-153）；类型对象身份不跨格 |
| V-905 | worker 派生孙进程的强杀、跨连接状态共享、可恢复/事务一致性游标 | 不做（worker 仍不引入 job object / 进程树跟踪；`tty-exec` 的进程组交接只覆盖前台交接，见 V-175） |
| V-906 | **服务侧**持久求值器 / 常驻编译单元（rakupp 常驻引擎、每连接一个） | **不做**：0.81.0 放弃 Agent 线后驱动力（Agent 并发）消失；三层探针亦证明 rakupp 缺 `:pty` 与 async socket 收尾（[PROBE-2026-11-16-adaptation](docs/PROBE-2026-11-16-rakupp-adaptation.md)）。**0.83.0 收窄适用域**：单用户会话的**引擎子进程**（V-212 / [ADR-0021](docs/ADR-0021-eval-worker.md)）不是本条对象 —— 它换的是崩溃隔离而不是启动时间，且跨格状态正是产品要的特性 |
| V-907 | CSV 方言参数 | 已实现（0.69，V-162 / ADR-0006 §2）；不做编码 / 多行字段精细控制 |
| V-908 | SQL AST 级补全 | 不做（ADR-0006 §4）：不引解析器依赖，启发式已覆盖主要场景 |
| V-909 | 交互式子进程自动探测、无开关的交互式捕获 | 不做（ADR-0007 §4）；本地 `tty-exec`（V-116）负责真交互，`pty-exec` 负责带超时的捕获 |

---

## 8. 验收

- `raku -Ilib t/*.t`：Windows / Linux 双平台 `not ok = 0`；
  `t/07` 专门守护入口契约（**只有一个入口**、无 v2 / Agent 痕迹、版本一致、`api = 3`）。
- `bash tools/run-all.sh`：任意一条 `not ok` / 非零退出码 / 缺 TAP plan 都算问题，
  脚本退出码即 `问题总数 == 0`。
- `python3 tools/tty-check.py`（Linux / WSL）：真 PTY 交互自检，覆盖 banner、
  彩色 prompt、Vi 徽标、Tab / SQL 补全、describe、Ctrl-C 中断后继续求值、
  嵌套 REPL 的 TTY 直通，以及 `tty-exec` 期间前台进程组 SIGINT 的归属
  （ADR-0009 / ADR-0011，25 项）；`t/27-interrupt.t` / `t/30-tty-exec-sigint.t` /
  `t/32-job-control.t` 在 Linux/WSL 也跑真 PTY 断言。
- `t/28` / `t/29`：PTY 捕获与能力探测双平台回归；`t/29` 用子类注入
  「不支持 PTY」的失败路径，不需要真的安装旧 Rakudo。
- `t/32`：进程组交接（V-175）的真 controlling terminal 回归，Windows
  整段 skip（POSIX-only）。
- `t/33`：结果着色与输入行高亮（V-176 / V-177 / V-270）：着色纯文本等价、
  `:!color` 逐字节相同、非 TTY 零 ANSI、跨行引号染色与不变式。
- `t/10`：日常 shell 观感（含 V-271 / V-274）：大文件 head/tail 流式读、
  `read` 超限的三条出路提示、tail -f 解析与路由（mock job-dispatch）。
- `t/34`：用户层命令（V-178…V-181）与 P0 三处订正：选项补全、`doc` 零 EVAL、
  目录栈、会话日志；反向断言覆盖「日志不含 ANSI」「未绑定键必须失败」
  「`doc 1+1` / `doc a;rm -rf` 必须失败」。
- `t/35`：内核与前端（V-182 / V-183）：双路径逐字段对账、策略拒绝不推进
  `Out[n]`、前端不能放宽策略、root 越界 403、`op` 通道 501、
  以及 `bin/rakuish` 的静态断言（不得直连 `eval-line`）。
- `t/36`：Windows 控制台编码（V-187）：非交互不许改码页、`restore` 幂等、
  切换调用必须在参数分发之前、管道下中文输入输出完好。
- `python3 tools/tty-cjk-win.py`（Windows 真控制台）：中文回显、`ls 中文目录`、
  `say "中文"`、无 crash 四项；无控制台时自动经 winpty 重启。
- `t/37`：命令名单一数据源（V-188）与输入序/格号分离（V-189）：名单三视图
  一致、`hint`/`plugin` 可补全、分发表双向一致、`OPTIONS` 键合法；会话命令与
  失败格进 `history` 但不占格号、多行格记完整源码、`!!` 不重复记。
- `t/38`：展示包与 op 通道（V-184…V-186）：9 种 kind 的格式可用性、text 零
  ANSI、协商顺序、未知格式回退、**降级时 `format` 如实回填 `text`**、
  `max-rows` 截断标记、`Kernel.bundle`/`present`、op 通道
  （capabilities / 501 / 2 / 403）、Agent 回复带 `display`（成功/失败/401）、
  `format=markdown` 生效且不改动既有键。
- `t/44`：`!` 流式与超时（V-229…V-231）：`Proc` 回调先于结束、Session
  stream-out 多块且不重放、`--capture` 回到捕获、`--timeout-ms` / `--no-timeout`、
  非法参数、引擎 chunk 帧到父进程、终帧 `streamed`。
- `t/45`：启动层（V-232…V-236）：rc 多行 / 变量 / alias / 选项且不占格号、
  错误带行号不中断、`set -o` 五选项各自执行点、prompt 吞噪声与异常回退、
  引擎 rc / prompt 协议、崩溃重启后 rc 重跑。
- `t/55`：tail -f 跟随循环（V-272…V-276）：初始末行 / lines=0、半行缓冲与
  跨 poll 多字节 UTF-8、截断轮转重读、消失重现、CRLF 剥 `\r`、
  should-stop 停止码 130、错误路径（should-stop 回调当情景驱动器，确定性）。
- `t/56`：tail -f 交互契约（V-272…V-275，真 PTY）：实时出现新增行、
  Ctrl-C 停跟随且引擎不重启（$*PID 不变）、my 变量保留、head -f 拒绝、
  之后干净退出；Windows 整段 skip（解析与循环由 t/10 / t/55 覆盖）。
- `t/57`：交互手感纯函数（V-277…V-282）：公共前缀、子序列 rank、
  fuzzy-words 前缀优先与回退、suggest-suffix 来源优先级、error-marks
  三探测器与跨行括号吸收、highlight-line :@marks 不变式。
- `t/58`：HlField 渲染与动作（V-277…V-281，不经 TTY）：灰字建议与宽度
  不变式、accept 退化、Ctrl-R 循环 / 回绕 / 复位、菜单去重与空候选、
  标记进渲染、掩码静默、键绑定接线。
- `t/59`：交互手感真 PTY 冒烟（V-277 / V-279…V-281）：灰字建议出现且
  → 接受、ShiftTab 菜单打印在输入行下方、未知命令标红、Ctrl-R 拉回
  历史、干净退出；Windows 整段 skip（t/58 覆盖渲染与动作契约）。
- `t/60`：手感后续清单引擎侧集成（V-285 / V-286）：真实 `@!out` 历史喂
  `Session.completions` 的 `In[`/`Out[` 引用补全（含边界与上限）、跨格
  `sub`/`my` 声明消除命令误标（真未知命令仍标红）。
- `t/61`：junction 结果契约（V-287）：Result 能装 `1|2`、`value-defined`、
  text/json/markdown/to-hash/**display** 均渲染为 `any(...)`（display 的
  标量/stdout 路径不变）、Session 求值与 `_`/`Out[n]` 保留原对象、普通标量
  渲染不变。
- 每个条款有对应断言；正向（必须含 Y）与反向（不得含 X）成对出现。
