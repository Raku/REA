unit class Rakuish::Data::Pager;

# 结构化分页器：只负责把**已经渲染好的文本**分页，不重新解释数据。
#
# 两条路径，故意分开：
#   · `page()`      —— 进程内（`-e` / 脚本 / 引擎自己的 TTY），自己拿 $*IN/$*OUT；
#   · `paginate()`  —— 前端驱动（0.92 / ADR-0027）：读一行、写一行都由调用方注入。
#     交互式 REPL 的求值在引擎子进程里，引擎的 stdout 是协议管道，它自己没有
#     终端可写；所以分页必须搬到父进程，而父进程的「读一个键」要与行编辑器共存，
#     不能在这里写死 $*IN。
#
# 分页器不判断「该不该分页」——那是调用方的策略（wants-page）。这里只回答
# 「这段文本能不能一页放下」。

use Rakuish::Data::Table;

has Int $.page-size = 20;

method summary(Rakuish::Data::Table $t --> Str) {
    "{ $t.elems } 行 × { $t.columns.elems } 列\n" ~ $t.schema.to-text;
}

# 每页行数：终端高度 − 2（给提示符与 `-- more --` 留两行）。
method size-for-height(Int $height --> Int) {
    $height > 2 ?? $height - 2 !! ($!page-size max 1);
}

# RAKUISH_PAGER 的取值归一。未知值回落 auto —— 但这是**有意的宽容**：
# 环境变量写错不该让分页静默变成 always（那会让 cat 大文件时突然停住）。
method mode(Str $raw --> Str) {
    my Str $m = $raw.trim.lc;
    # 用显式字符串列表：`<never off 0 no>` 里的 `0` 会被解析成 IntStr，
    # `(elem)` 按 === 比较，Str "0" 匹配不上（实测）。
    return 'never'  if $m (elem) ('never', 'off', '0', 'no', 'n');
    return 'always' if $m (elem) ('always', 'all', 'on', '1', 'yes', 'y');
    'auto';
}

# 该不该分页由调用方问这里，免得同一条策略在 bin 与测试里各写一份。
#   auto   ：只对 `explore`，且超过一页（默认）
#   always ：任何超过一页的结果（显式要求 less 行为）
#   never  ：不分页
method wants-page(Str :$op!, Int :$lines!, Int :$height = 0, Str :$mode = 'auto',
                  Bool :$tty = True --> Bool) {
    return False unless $tty;
    return False if $mode eq 'never';
    my Int $size = self.size-for-height($height);
    return False unless $lines > $size;
    return True if $mode eq 'always';
    $op eq 'explore';
}

# 进程内路径（0.89 起只有 `explore` 在引擎自己的 TTY 上用它）：
# 直接读写 $*IN / $*OUT，不做回调注入。非交互时原样返回文本，
# 由调用方决定怎么显示（这就是 `-e` / 管道的语义）。
method page($value, :$in = $*IN, :$out = $*OUT,
           Bool :$interactive = (so try { $in.t }) --> Str) {
    my Str $text = $value ~~ Rakuish::Data::Table
        ?? $value.to-text
        !! $value.Str;
    return $text unless $interactive;

    my @lines = $text.lines;
    my Int $n = @lines.elems;
    return $text unless $n;

    my Int $size = $!page-size max 1;
    if $n <= $size {
        # 一页装得下也要打印：这是**交互**路径，调用方已经决定由这里输出。
        $out.say(@lines[$_]) for 0 .. $n - 1;
        return $text;
    }

    my Int $start = 0;
    while $start < $n {
        my Int $end = ($start + $size - 1) min ($n - 1);
        $out.say(@lines[$_]) for $start .. $end;
        $start = $end + 1;
        last if $start >= $n;
        $out.print("-- more ({$start}/{$n}; Enter=下一页, q=退出) -- ");
        $out.flush;
        my $answer = $in.get;
        last unless $answer.defined;
        last if $answer.trim.lc eq 'q';
    }
    $text;
}

# 分页输出。`&read` 返回一行（未定义 = EOF，停止），`&emit` 收一行文本。
# 返回 True 表示「已经自己打印过了」，调用方不要再 say 一遍。
# 一页就装得下时返回 False 且一个字节都不写 —— 让调用方走原来的打印路径，
# 这样没有分页的格在观感与测试里完全不变。
method paginate(Str $text, &read!, &emit!, Int :$size = -1,
                Str :$hint = 'Enter=下一页, q=退出' --> Bool) {
    my @lines = $text.lines;
    my Int $n = @lines.elems;
    my Int $page = ($size > 0 ?? $size !! $!page-size) max 1;
    return False unless $n > $page;

    my Int $start = 0;
    while $start < $n {
        my Int $end = ($start + $page - 1) min ($n - 1);
        emit(@lines[$_]) for $start .. $end;
        $start = $end + 1;
        last if $start >= $n;
        emit("-- more ({$start}/{$n}; {$hint}) --");
        my $answer = read();
        last unless $answer.defined;
        my Str $a = $answer.trim.lc;
        last if $a eq 'q' || $a eq 'quit';
    }
    True;
}
