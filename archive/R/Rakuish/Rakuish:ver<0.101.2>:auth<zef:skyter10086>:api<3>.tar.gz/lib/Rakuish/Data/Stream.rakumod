unit class Rakuish::Data::Stream;

# Rakuish::Data::Stream —— 结构化管道里的「管」（0.91.0 / ADR-0026）。
#
# 一个 Stream 是**惰性的记录序列**（Seq of Hash），不是文本行。它存在的理由
# 只有一条：shell 里 `a | b | c` 的位置，在 Rakuish 里换成
# 「把结构化记录喂给下一个阶段」，且不必把整份数据先物化成 Table。
#
#   stream(cmd-result('! find . -name "*.rakumod"'))   # 文本 → 记录
#         .where({ .<line> ~~ /Result/ })
#         .count;
#
#   stream(ls-table()).where({ .<size> > 4096 }).sort-by('size').table;
#
# 三条硬约定：
#   1. **不造第二套语法**。管道就是方法链；`==>` 也能用（feed 把值放在最后一个
#      参数位），但不提供 `|` / `|>` —— 前者在 Raku 里是 slip / 参数分隔符，
#      后者在 Raku 语法里根本不可定义（实测 `infix:<|>` 报
#      "expects a term, but found infix >"）。V-901 不松动。
#   2. **惰性要么真、要么说清楚**。where/select/map/limit/skip/add-column 都是
#      惰性的；sort-by / unique / group-by / count-by 必须物化（排序本来就要
#      看完全部），这一条写进方法注释与手册，不假装。
#   3. **一次性来源要报错，不能静默给空**。来自 Cursor / 子进程通道的流只能读
#      一次；第二次取会抛 X::Rakuish::Data，而不是返回一个空 Seq 让人以为没数据。
#
# 出口：table / text / json / csv / lines / count / exec（把记录喂给外部命令的
# stdin —— 这是 shell 管道的另一半，`!` 单独做不到）。

use JSON::Fast;
use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Data::Cursor;
need Rakuish::Data;      # 只为复用 from-csv-data 的引号状态机，不导出它的 open-data

has Callable $!make;                 # --> Seq of Hash
has Str  $.source     = '';          # 诊断用：来源与阶段链
has Bool $.repeatable = True;        # False = 只能消费一次（游标 / 进程通道）
has      $!taken      = False;
has      @!columns;

submethod BUILD(:&make!, Str :$source = '', Bool :$repeatable = True,
                :@columns) {
    $!make       = &make;
    $!source     = $source;
    $!repeatable = $repeatable;
    @!columns    = @columns.List if @columns;
}

# ── 构造 ─────────────────────────────────────────────────────────────

# 文本解析格式只有这几个；未知格式明确报错，不做「猜」。
my constant TEXT-FORMATS = <lines csv tsv json jsonl pattern>;

multi method from(Rakuish::Data::Table $t --> Rakuish::Data::Stream) {
    my @rows = $t.rows.List;
    self.new(:make(-> { @rows.Seq }),
             :source("table({$t.elems}×{$t.columns.elems})"),
             :columns($t.columns.List));
}

multi method from(Rakuish::Data::Cursor $c --> Rakuish::Data::Stream) {
    self.new(:make(-> { $c.rows }),
             :source("cursor({$c.columns.join(',')})"),
             :repeatable(False),
             :columns($c.columns.List));
}

# 文本行是**最常见的来源**：`!` 的输出就是 Result.out。
multi method from(Result $r --> Rakuish::Data::Stream) {
    # V3 的异常族都要求 :detail（父类 required 属性），只给 result 会抛
    # X::Attribute::Required 而不是我们要的错误 —— 实测踩过。
    X::Rakuish::CommandFailed.new(
        :result($r),
        :detail("{$r.op} 失败，不能当成数据流：{$r.err.chomp}")
    ).throw unless $r.ok;
    self.from($r.out, :format<lines>, :source("{$r.op} 输出"));
}

multi method from(Associative $h --> Rakuish::Data::Stream) {
    my %row = $h.Hash;
    self.new(:make(-> { (%row,).Seq }), :source('record(1)'),
             :columns(%row.keys.List));
}

multi method from(Positional $list --> Rakuish::Data::Stream) {
    my @rows = $list.List.map(-> $x {
        $x ~~ Associative ?? $x.Hash !! %( value => $x );
    }).List;
    self.new(:make(-> { @rows.Seq }), :source("list({@rows.elems})"));
}

multi method from(IO::Path $p, Str :$format = 'lines',
                  Regex :$pattern, :@names, :%csv-options
                  --> Rakuish::Data::Stream) {
    X::Rakuish::NotFound.new(:detail("文件不存在: {$p.Str}")).throw
        unless $p.e;
    self.from($p.slurp(:enc('utf-8')), :$format, :$pattern, :@names,
              :%csv-options, :source("{$p.basename}"));
}

multi method from(Str $text, Str :$format = 'lines',
                  Regex :$pattern, :@names, :%csv-options,
                  Str :$source = 'text' --> Rakuish::Data::Stream) {
    my Str $fmt = $format.chars ?? $format.lc !! 'lines';
    X::Rakuish::Unsupported.new(
        :detail("未知的文本格式: {$format}（可选 {TEXT-FORMATS.join(' / ')}）")
    ).throw unless $fmt (elem) TEXT-FORMATS;
    X::Rakuish::Unsupported.new(
        :detail('pattern 格式必须给 :pattern（正则）')
    ).throw if $fmt eq 'pattern' && !$pattern.defined;

    # 物化成 List：文本已经在内存里了，再假装惰性没有意义；但下游阶段仍惰性。
    # 列顺序必须由解析器给出 —— Hash 的键顺序不可依赖（实测 CSV 会排成 size,name）。
    my %parsed = self!parse-text($text, $fmt, $pattern, @names, %csv-options);
    my @rows = (%parsed<rows> // ()).List;
    my @cols = (%parsed<columns> // ()).List;
    my Str $src = $fmt eq 'lines' ?? "{$source}:lines({@rows.elems})"
                                  !! "{$source}:{$fmt}({@rows.elems})";
    self.new(:make(-> { @rows.Seq }), :source($src), :columns(@cols));
}

method !parse-text(Str $text, Str $fmt, $pattern, @names, %csv-options --> Hash) {
    given $fmt {
        when 'lines' {
            return %(
                :columns< n line >,
                :rows($text.lines.kv.map(-> $i, $l {
                    { n => $i + 1, line => $l }
                }).List),
            );
        }
        when 'csv' {
            # 复用 Data 的解析器（不复制第二份引号状态机）；这里只做表 → 行。
            my $t = Rakuish::Data::from-csv-data($text);
            return %( :columns($t.columns.List), :rows($t.rows.List) );
        }
        when 'tsv' {
            my @lines = $text.lines;
            return %( :columns(), :rows() ) unless @lines.elems;
            my @cols = @lines.shift.split("\t").map(*.Str).List;
            return %(
                :columns(@cols),
                :rows(@lines.map(-> $l {
                    my @v = $l.split("\t");
                    my %r;
                    for @cols.kv -> $i, $c { %r{$c} = @v[$i] // '' }
                    %r;
                }).List),
            );
        }
        when 'json' {
            my $v = try { from-json($text) };
            X::Rakuish::Data.new(:detail('不是合法 JSON: ' ~ ($!.message // ''))).throw
                unless $v.defined;
            X::Rakuish::Data.new(
                :detail('json 格式需要对象数组（[{a:1},…]）；单个对象请直接 stream(record)')
            ).throw unless $v ~~ Positional;
            my @rows;
            for $v.List -> $x {
                X::Rakuish::Data.new(
                    :detail('JSON 数组里有非对象元素，无法当成记录')
                ).throw unless $x ~~ Associative;
                @rows.push($x.Hash);
            }
            return %( :columns(@rows.elems ?? @rows[0].keys.sort.List !! ()),
                      :rows(@rows) );
        }
        when 'jsonl' {
            my @rows;
            for $text.lines.kv -> $i, $l {
                next unless $l.trim.chars;
                my $v = try { from-json($l) };
                X::Rakuish::Data.new(
                    :detail("第 {$i + 1} 行不是合法 JSON: " ~ ($!.message // ''))
                ).throw unless $v ~~ Associative;
                @rows.push($v.Hash);
            }
            return %( :columns(@rows.elems ?? @rows[0].keys.sort.List !! ()),
                      :rows(@rows) );
        }
        when 'pattern' {
            my @rows;
            my @cols = 'n', |@names.map(*.Str);
            for $text.lines.kv -> $i, $l {
                my $m = $l.match($pattern) // next;
                my %r = n => $i + 1;
                if @names.elems {
                    my @caps = $m.list;
                    for @names.kv -> $j, $name {
                        my $v = @caps[$j] // $m.hash{$name.Str};
                        %r{$name.Str} = $v.defined ?? $v.Str !! Nil;
                    }
                }
                else {
                    %r{$_.key.Str} = $_.value.Str for $m.hash.pairs;
                    my @caps = $m.list;
                    %r{"c{$_}"} = @caps[$_].Str for ^@caps.elems;
                }
                @rows.push(%r);
            }
            @cols = @rows.elems ?? @rows[0].keys.sort.List !! () unless @cols.elems > 1;
            return %( :columns(@cols), :rows(@rows) );
        }
    }
    %( :columns(), :rows() );
}

# ── 惰性阶段 ─────────────────────────────────────────────────────────

method !derive(&f, Str $label, :@columns --> Rakuish::Data::Stream) {
    my Str $src = $!source.chars ?? "{$!source} → {$label}" !! $label;
    my @cols = @columns.defined ?? @columns.List !! @!columns.List;
    Rakuish::Data::Stream.new(
        :make(-> { f(self!seq) }),
        :source($src),
        :repeatable($!repeatable),
        :columns(@cols),
    );
}

method !seq(--> Seq) {
    if $!taken && !$!repeatable {
        X::Rakuish::Data.new(
            :detail("这个流已经读过一次（{$!source}）；游标 / 进程来源的流不能重读，请重新取源")
        ).throw;
    }
    $!taken = True;
    # 行必须是 Hash：Raku 里 `{ a => 1 }` 在块位置可能给出 Pair 列表，
    # 后续 where / select 再按 $r{...} 取值就会静默拿不到（0.91 开发中踩过）。
    # 这里统一收口，用户 .map 返回 Pairs 列表也能继续用。
    $!make.().map(-> $r { self!coerce-row($r) });
}

method !coerce-row($r --> Hash) {
    return $r.Hash if $r ~~ Associative;
    if $r ~~ Positional && $r.elems && $r.all ~~ Pair {
        my %h;
        for $r -> $p { %h{$p.key} = $p.value }
        return %h;
    }
    %( value => $r );
}

method where(&pred --> Rakuish::Data::Stream) {
    self!derive(-> $s { $s.grep(-> $r { so pred($r) }) }, 'where');
}

method select(*@cols --> Rakuish::Data::Stream) {
    my @keep = @cols.map(*.Str).List;
    self!derive(
        -> $s {
            $s.map(-> $r {
                my %h;
                for @keep -> $c { %h{$c} = $r{$c} if $r{$c}:exists }
                %h;
            })
        },
        "select({@keep.join(',')})", :columns(@keep));
}

method drop(*@cols --> Rakuish::Data::Stream) {
    my @gone = @cols.map(*.Str);
    my @keep = @!columns.grep({ !($_.Str (elem) @gone) }).map(*.Str).List;
    # 列未知（文本行之类）时按每行实际键过滤，不假装知道 schema。
    self!derive(
        -> $s {
            $s.map(-> $r {
                my %h;
                for $r.keys -> $k { %h{$k.Str} = $r{$k} unless $k.Str (elem) @gone }
                %h;
            })
        },
        "drop({@gone.join(',')})", :columns(@keep));
}

# map 之后列可能全变，所以**清空**列元数据、让出口重新推断；
# 传空列而不是不传，是为了区分「继承」与「不知道」。
method map(&f --> Rakuish::Data::Stream) {
    self!derive(
        -> $s {
            $s.map(-> $r {
                my $v = f($r);
                $v ~~ Associative ?? $v.Hash !! %( value => $v );
            })
        }, 'map', :columns(()));
}

method add-column(Str $name, &f --> Rakuish::Data::Stream) {
    self!derive(
        -> $s {
            $s.map(-> $r {
                my %h = $r.Hash;
                %h{$name} = f($r);
                %h;
            })
        }, "add-column({$name})", :columns((@!columns.List, $name).flat.List));
}

method limit(Int $n --> Rakuish::Data::Stream) {
    my Int $k = $n max 0;
    self!derive(-> $s { $s.head($k) }, "limit({$k})");
}

method skip(Int $n --> Rakuish::Data::Stream) {
    my Int $k = $n max 0;
    self!derive(-> $s { $s.skip($k) }, "skip({$k})");
}

# 排序 / 去重 / 分组必须看完全部记录：这三处是**物化边界**，注释与手册都说清楚。
method sort-by(Str $col, Bool :$reverse = False --> Rakuish::Data::Stream) {
    self!derive(
        -> $s {
            my @rows = $s.List.sort(-> $a, $b {
                my $av = $a{$col};
                my $bv = $b{$col};
                my $av-d = $av.defined ?? $av !! '';
                my $bv-d = $bv.defined ?? $bv !! '';
                $reverse ?? ($bv-d cmp $av-d) !! ($av-d cmp $bv-d);
            });
            @rows.Seq;
        }, "sort-by({$col}" ~ ($reverse ?? ', reverse)' !! ')'));
}

method unique(*@cols --> Rakuish::Data::Stream) {
    my @keep = @cols.map(*.Str);
    self!derive(
        -> $s {
            my %seen;
            my @out;
            for $s.List -> $r {
                my @keys = @keep.elems ?? @keep !! $r.keys.sort.List;
                my Str $k = @keys.map({ ($r{$_} // '') ~ "\x[1F]" }).join('');
                next if %seen{$k};
                %seen{$k} = True;
                @out.push($r);
            }
            @out.Seq;
        }, 'unique');
}

# 分组只给**计数**：想要完整的行组用 .group-by。
method count-by(Str $col --> Rakuish::Data::Stream) {
    self!derive(
        -> $s {
            my @order;
            my %n;
            for $s.List -> $r {
                my Str $k = ($r{$col} // '').Str;
                @order.push($k) unless %n{$k}:exists;
                %n{$k}++;
            }
            @order.map(-> $k { %( $col => $k, count => %n{$k} ) }).Seq;
        }, "count-by({$col})", :columns(($col, 'count')));
}

method group-by(Str $col --> Rakuish::Data::Stream) {
    self!derive(
        -> $s {
            my @order;
            my %g;
            for $s.List -> $r {
                my Str $k = ($r{$col} // '').Str;
                @order.push($k) unless %g{$k}:exists;
                %g{$k}.push($r);
            }
            @order.map(-> $k { %( $col => $k, rows => %g{$k}.List ) }).Seq;
        }, "group-by({$col})", :columns(($col, 'rows')));
}

# ── 出口 ─────────────────────────────────────────────────────────────

method !materialize(--> List) {
    my @rows = self!seq.List;
    if @!columns.elems == 0 && @rows.elems {
        my @cols;
        my %seen;
        for @rows -> $r {
            for $r.keys -> $k {
                next if %seen{$k.Str};
                %seen{$k.Str} = True;
                @cols.push($k.Str);
            }
        }
        @!columns = @cols;
    }
    @rows.List;
}

method table(--> Rakuish::Data::Table) {
    my @rows = self!materialize;
    my @cols = @!columns.List;
    # 列元数据缺失（json 来源 / map 之后）：用第一行的键推断，按名排序保证
    # 多次调用顺序一致。不做这一步的话 `.csv` / `.text` 会因为这些流没有
    # columns 而给出空字符串（0.93 把它和 `.exec` 一起修了）。
    @cols = (@rows.elems ?? @rows[0].keys.sort.List !! ()) unless @cols.elems;
    Rakuish::Data::Table.new(:columns(@cols), :rows(@rows));
}

method text(Int :$max-rows --> Str) { self.table.to-text(:$max-rows) }
method json(Bool :$pretty = False, Int :$max-rows --> Str) {
    self.table.to-json(:$pretty, :$max-rows);
}
method csv(--> Str) { self.table.to-csv }

method rows(--> Seq) { self!seq }

# 单列取值：`lines` 默认拿 line 列，`column` 拿任意列。
method column(Str $col --> List) {
    self!materialize.map({ $_{$col} }).List;
}

# 默认取 line 列；没有 line 列（例如 select 过之后）就取第一列 ——
# 不让「管道里改过列名」变成一堆 undef。
method lines($col? --> List) {
    my @rows = self!materialize;
    my Str $c = $col.defined ?? $col.Str
        !! (@!columns.grep({ $_.Str eq 'line' }).elems ?? 'line'
            !! (@!columns.elems ?? @!columns[0].Str !! 'line'));
    @rows.map({ $_{$c} }).List;
}

method count(--> Int)      { self!seq.elems }
method first-row(--> Any)  { self!seq.head(1).List.head }

# 数值口径：CSV / `!` 输出里的数字是**字符串**，`~~ Numeric` 会全过滤掉
# （实测 sum('size') 对 CSV 返回 0）。这里按字面数值再认一次，不做进制/千分位。
my constant NUMERIC-LITERAL = /^ '-'? \d+ [ '.' \d+ ]? $/;

method !numeric(Str $col --> List) {
    my @out;
    for self!seq.List -> $r {
        my $v = $r{$col};
        next unless $v.defined;
        if $v ~~ Numeric { @out.push($v.Num); next }
        my Str $s = $v.Str.trim;
        @out.push($s.Num) if $s ~~ NUMERIC-LITERAL;
    }
    @out.List;
}

method sum(Str $col --> Num)  { self!numeric($col).sum.Num }
method mean(Str $col --> Num) {
    my @v = self!numeric($col);
    @v.elems ?? @v.sum / @v.elems !! 0e0;
}
method min(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? @v.min !! Nil;
}
method max(Str $col --> Any) {
    my @v = self!numeric($col);
    @v.elems ?? @v.max !! Nil;
}

# 逐行副作用；返回值是处理过的行数（和 `wc -l` 同一种「结束才给」）。
method each(&f --> Int) {
    my Int $n = 0;
    for self!seq.List -> $r { f($r); $n++ }
    $n;
}

# ── 行格式化：exec 与 tee 共用一份（0.94 / ADR-0029）──────────────────
# csv 的引号 / 表头 / 换行规则原本只在 Table 里；0.93 的 exec 调它，
# 0.94 的 tee 也要用 —— 这里再抽一层「一行怎么变成文本」，两处只调一个方法。
method !fmt-head(Str $fmt, @cols --> Str) {
    return '' unless $fmt eq 'csv' || $fmt eq 'tsv';
    return '' unless @cols.elems;
    $fmt eq 'csv' ?? Rakuish::Data::Table.csv-header(@cols) ~ "\n"
                  !! @cols.join("\t") ~ "\n";
}

method !fmt-row(Str $fmt, @cols, Str $col, $r, Bool $first --> Str) {
    given $fmt {
        when 'csv'  { Rakuish::Data::Table.csv-line(@cols, $r) ~ "\n" }
        when 'tsv'  { @cols.map({ ($r{$_} // '').Str }).join("\t") ~ "\n" }
        when 'json' {
            # 数组的 `[` `]` 由调用方负责；`:!pretty` 是刻意的（逐元素缩进版
            # 会变成一堆错位的换行）。键序不作承诺，见 ADR-0028 §2.3。
            (($first ?? '' !! ',') ~ JSON::Fast::to-json($r.Hash, :!pretty))
        }
        default { ($r{$col} // '').Str ~ "\n" }
    }
}

# 列元数据。**可能为空**：json 来源、map 之后、join 的右侧未知时都是空表。
# 展示不靠它 —— `.table` 会从第一行推断；这里只给「已经知道的那部分」。
method columns(--> List) { @!columns.List }

# ── 把记录喂给外部命令的 stdin（shell 管道的另一半）─────────────────
# 走会话级 Sys：cwd / 环境 / 超时 / 审计与 `!` 完全同一条路。
# 出口的**流式版**：一个真正的生成器，`.exec` 靠它边算边写子进程 stdin（0.93）。
# csv / tsv 与 `.csv` 逐字节相同（转义复用 Table.csv-line，不写第二份）；
# json 只保证语义等价：逐元素紧凑序列化，键序不作承诺。
# 表头靠列元数据；元数据缺失时偷看第一行的键 —— 只拉一行，不是物化。
method !chunk-seq(Str $format, $column, $rows --> Seq) {
    my Str $fmt = $format.lc;
    my @cols = @!columns.map(*.Str).List;
    my Str $col = $column.defined ?? $column.Str
                                 !! (@cols.elems ?? @cols[0] !! 'line');

    gather {
        take '[' if $fmt eq 'json';
        my Bool $first = True;
        my Bool $header-done = $fmt ne 'csv' && $fmt ne 'tsv';

        # 用 iterator 而不是 `for $seq -> $r`：手写 for 对 Seq 的行为在本项目
        # 已经踩过（标量里的 Seq 被当成单个元素），pull-one 没有二义。
        my $it = $rows.iterator;
        loop {
            my $r = $it.pull-one;
            # 同 Proc：`=:=` 会被标量容器破坏，`~~` 才是可靠判定。
            last if $r ~~ IterationEnd;
            unless $header-done {
                @cols = $r.keys.sort.map(*.Str).List;
                my Str $head = self!fmt-head($fmt, @cols);
                take $head if $head.chars;
                $header-done = True;
            }
            take self!fmt-row($fmt, @cols, $col, $r, $first);
            $first = False;
        }

        # 零行 + 有列元数据：`.to-csv` 会给表头，这里保持一致。
        unless $header-done {
            my Str $head = self!fmt-head($fmt, @cols);
            take $head if $head.chars;
        }
        take ']' if $fmt eq 'json';
    }
}

method exec($exe, *@args, Str :$column,
            Str :$format = 'lines', *%opts --> Result) {
    my $sys = $*RAKUISH-SYS;
    X::Rakuish::Unsupported.new(
        :detail('Stream.exec 需要 Rakuish 会话（找不到 $*RAKUISH-SYS）；请在 REPL 或 Session 里用')
    ).throw unless $sys.defined;

    my Str $fmt = $format.lc;
    # 不静默回落 lines：写错格式该当场知道，而不是拿到一份「看起来像」的输出。
    X::Rakuish::Unsupported.new(
        :detail("Stream.exec 的 :format 只支持 lines / csv / tsv / json，收到 '{$format}'")
    ).throw unless $fmt (elem) ('lines', 'csv', 'tsv', 'json');

    # 先同步取一次 Seq：一次性来源（游标 / 进程通道）的二次消费必须**当场**
    # 报错。写成惰性之后这一步在后台线程里跑，异常只会变成 feed-error、
    # 子进程安静地收到空输入 —— 那是「静默给空」，V-240 明令不许。
    # `!seq` 本身是惰性的，这里只建 Seq，不拉数据。
    my $rows = self!seq;

    # 0.93.0 / ADR-0028：交给子进程的是**生成器**，不是一整份文本。
    # 背压在 Proc 侧（写一块 await 一块）：子进程读多快就生成多快；它提前
    # 退出（head -1 / grep -q）时，生成器停在被拉到的位置，不会白跑整条流。
    $sys.exec($exe.Str, |@args,
              :in-chunks(-> { self!chunk-seq($fmt, $column, $rows) }), |%opts);
}

# ── 两条流对着看：zip / join / tee（0.94 / ADR-0029）─────────────────
# 三者的共同事实：**都必须动到「另一方」**，所以都绕不开一个代价 ——
# zip 逐条对齐（可以全惰性），join 要把右表建成索引（右表必须物化），
# tee 要往磁盘写（写多少取决于下游读多少）。这些代价写在每个方法上。

# 把「另一条流」的入参统一成 Seq of Hash。支持 Stream / Table / 记录列表；
# 其它类型明确报错，不猜（猜错会得到一份「看起来像」的空结果）。
method !rows-of($other --> Seq) {
    given $other {
        when Rakuish::Data::Stream { $other.rows }
        when Rakuish::Data::Table  { $other.rows.Seq }
        when Positional            { $other.list.map(-> $r { self!coerce-row($r) }).Seq }
        default {
            X::Rakuish::Unsupported.new(
                :detail("需要 Stream / Table / 记录列表，收到 {$other.^name}")
            ).throw;
        }
    }
}

method !other-columns($other --> List) {
    given $other {
        when Rakuish::Data::Stream { $other.columns }
        when Rakuish::Data::Table  { $other.columns.map(*.Str).List }
        default { () }
    }
}

method !other-repeatable($other --> Bool) {
    $other ~~ Rakuish::Data::Stream ?? $other.repeatable !! True;
}

# 按位置配对：左 1 配右 1、左 2 配右 2……
# 默认取**较短**的那条（和 Raku 的 `Z` 一致）；`:longest` 用空行补齐。
# 两边列名冲突时右列加 :suffix；右表没有列元数据时，右列**统一**加后缀 ——
# 判断不了冲突时宁可多改，也不让右值悄悄覆盖左值。
method zip($other, Str :$suffix = '_right', Bool :$longest = False
           --> Rakuish::Data::Stream) {
    my @other-cols = self!other-columns($other);
    my @rmap;
    my @out-cols;
    if @!columns.elems && @other-cols.elems {
        my %plan = Rakuish::Data::Table.join-columns(@!columns, @other-cols, :$suffix);
        @rmap = %plan<right-map>.List;
        @out-cols = %plan<columns>.List;
    }

    Rakuish::Data::Stream.new(
        :make(-> {
            my $left  = self!seq;
            my $right = self!rows-of($other);
            gather {
                my $il = $left.iterator;
                my $ir = $right.iterator;
                my @map = @rmap;
                loop {
                    my $l = $il.pull-one;
                    my $r = $ir.pull-one;
                    my Bool $el = $l ~~ IterationEnd;
                    my Bool $er = $r ~~ IterationEnd;
                    last if $el && $er;
                    last if ($el || $er) && !$longest;
                    my $lv = $el ?? Nil !! $l;
                    my $rv = $er ?? Nil !! $r;
                    if !@map.elems && $rv.defined {
                        @map = $rv.keys.sort.map({ (my Str $k = $_.Str) => $k ~ $suffix }).List;
                    }
                    take Rakuish::Data::Table.join-merge($lv, $rv, @map);
                }
            }
        }),
        :source("{$!source} zip " ~ ($other ~~ Rakuish::Data::Stream ?? $other.source !! 'other')),
        :repeatable($!repeatable && self!other-repeatable($other)),
        :columns(@out-cols),
    );
}

# 关系连接。**默认 left**，与 Table.join 的历史行为一致；要 SQL / POSIX join
# 的语义写 `:how<inner>`。同一个动词在本项目里只能有一个默认值 ——
# 「两个 API 各有一个默认」比「默认不是 SQL 那个」更坑。
method join($other,
            Str :$on, Str :$left-on = $on, Str :$right-on = $on,
            Str :$how = 'left', Str :$suffix = '_right'
            --> Rakuish::Data::Stream) {

    X::Rakuish::Unsupported.new(
        :detail('join 需要 :on（或同时给 :left-on 与 :right-on）')
    ).throw unless $left-on.defined && $right-on.defined;

    my Str $mode = $how.lc;
    X::Rakuish::Unsupported.new(
        :detail("join 的 :how 只支持 inner / left / right / outer，收到 '{$how}'")
    ).throw unless $mode (elem) ('inner', 'left', 'right', 'outer');

    my @other-cols = self!other-columns($other);
    my @rmap;
    my @out-cols;
    if @!columns.elems && @other-cols.elems {
        my %plan = Rakuish::Data::Table.join-columns(@!columns, @other-cols, :$suffix);
        @rmap = %plan<right-map>.List;
        @out-cols = %plan<columns>.List;
    }

    Rakuish::Data::Stream.new(
        :make(-> {
            # 右表在第一次消费时才物化（hash join 的代价）。左表保持惰性，
            # 所以「大左表 × 小右表」是唯一划算的用法 —— 反过来写请先 swap。
            my %idx;
            my @order;
            my @map = @rmap;
            my $rit = self!rows-of($other).iterator;
            loop {
                my $r = $rit.pull-one;
                last if $r ~~ IterationEnd;
                if !@map.elems {
                    @map = $r.keys.sort.map({ (my Str $k = $_.Str) => $k ~ $suffix }).List;
                }
                my Str $k = ($r{$right-on} // '').Str;
                my %slot = %( row => $r, hit => False );
                %idx{$k}.push(%slot);
                @order.push(%slot);
            }

            my $left = self!seq;
            gather {
                my $it = $left.iterator;
                loop {
                    my $l = $it.pull-one;
                    last if $l ~~ IterationEnd;
                    my Str $k = ($l{$left-on} // '').Str;
                    my $slots = %idx{$k};
                    if $slots.defined && $slots.elems {
                        # 一对多就是笛卡尔积：同键的右行有几条就出几行（SQL 如此）。
                        for $slots.list -> %slot {
                            %slot<hit> = True;
                            take Rakuish::Data::Table.join-merge($l, %slot<row>, @map);
                        }
                    }
                    elsif $mode eq 'left' || $mode eq 'outer' {
                        take Rakuish::Data::Table.join-merge($l, Nil, @map);
                    }
                }
                if $mode eq 'right' || $mode eq 'outer' {
                    for @order -> %slot {
                        next if %slot<hit>;
                        take Rakuish::Data::Table.join-merge(Nil, %slot<row>, @map);
                    }
                }
            }
        }),
        :source("{$!source} ⋈" ~ $mode ~ " " ~
                ($other ~~ Rakuish::Data::Stream ?? $other.source !! 'other')),
        :repeatable($!repeatable && self!other-repeatable($other)),
        :columns(@out-cols),
    );
}

# 边往下流边写一份副本（Unix `tee`）。写文件走会话 Sys 的 resolve ——
# root 约束与 `!` / `save` 同一条路，不另开一个绕过检查的口子。
# 格式与 `.exec` 完全共用（`!fmt-head` / `!fmt-row`），所以 `:format<csv>`
# 得到的字节与 `.csv` 一致。
# **边界**：写多少取决于下游读多少。要「只写前 N 行」就把截断放在上游
# （`stream(...).limit(N).tee('x.csv')`），那样 tee 会正常收尾并关文件；
# 反过来 `tee(...).limit(N)` 会留下一个写到一半、且尚未 close 的文件。
method tee($path, Str :$format = 'csv', :$column, Bool :$append = False
           --> Rakuish::Data::Stream) {
    my $sys = $*RAKUISH-SYS;
    X::Rakuish::Unsupported.new(
        :detail('Stream.tee 需要 Rakuish 会话（找不到 $*RAKUISH-SYS）；请在 REPL 或 Session 里用')
    ).throw unless $sys.defined;

    my Str $fmt = $format.lc;
    X::Rakuish::Unsupported.new(
        :detail("Stream.tee 的 :format 只支持 lines / csv / tsv / json，收到 '{$format}'")
    ).throw unless $fmt (elem) ('lines', 'csv', 'tsv', 'json');

    my Str $abs = $sys.resolve($path).Str;
    my Str $col = $column.defined ?? $column.Str
                                 !! (@!columns.elems ?? @!columns[0].Str !! 'line');

    Rakuish::Data::Stream.new(
        :make(-> {
            my $rows = self!seq;
            gather {
                # 建流不碰磁盘：文件在第一次真正 pull 时才打开。
                my Bool $has-body = so ($abs.IO.e && ($abs.IO.s // 0) > 0);
                # 追加用 :a —— `open(:w, :append)` 里 :w 会先把文件截断（实测）。
                my $h = $append ?? $abs.IO.open(:a) !! $abs.IO.open(:w);
                my @cols = @!columns.map(*.Str).List;
                my Bool $header-done = $fmt ne 'csv' && $fmt ne 'tsv';
                my Bool $first = True;
                $h.print('[') if $fmt eq 'json';

                my $it = $rows.iterator;
                loop {
                    my $r = $it.pull-one;
                    last if $r ~~ IterationEnd;
                    unless $header-done {
                        @cols = $r.keys.sort.map(*.Str).List;
                        my Str $head = self!fmt-head($fmt, @cols);
                        # 追加模式不重写表头：否则 CSV 中间会插一行表头。
                        $h.print($head) if $head.chars && !($append && $has-body);
                        $header-done = True;
                    }
                    $h.print(self!fmt-row($fmt, @cols, $col, $r, $first));
                    $first = False;
                    take $r;
                }
                unless $header-done {
                    my Str $head = self!fmt-head($fmt, @cols);
                    $h.print($head) if $head.chars && !($append && $has-body);
                }
                $h.print(']') if $fmt eq 'json';
                # 正常收尾（含上游 limit）一定会走到这里：落盘 + 释放句柄。
                $h.close;
            }
        }),
        :source("{$!source} ▷ tee({$abs})"),
        :repeatable(False),
        :columns(@!columns.List),
    );
}

# ── 按顺序收拢两条流：interleave / append（0.95 / ADR-0030）─────────
# 与 zip 的分水岭：zip 把两侧**合成一行**（所以同名列必须改后缀）；
# 这里让每一行**保持原样**，只改它们出现的顺序。既然不存在「同一行里两列
# 撞名」，就**不调用** Table.join-columns —— 给行改列名只会把本来对的数据
# 改坏。这是两个动作不共用列规则的原因，写在这里免得后人以为是漏了。

# 两侧列元数据的并集：左列在前，右列里没出现过的追加在后，保序、不改名。
# 任一侧列未知（json 来源 / map 之后 / 行列表）→ 返回空，交给 `.table`
# 从实际行推断。与 zip 对「未知 schema」的保守态度一致。
method !concat-union-columns($other --> List) {
    my @left  = @!columns.map(*.Str);
    my @right = self!other-columns($other).map(*.Str);
    return () unless @left.elems && @right.elems;
    my @cols = @left;
    my %seen = @left.map({ $_ => True });
    for @right -> $c {
        next if %seen{$c}:exists;
        %seen{$c} = True;
        @cols.push($c);
    }
    @cols.List;
}

# 按位置交替：左1、右1、左2、右2……（`roundrobin` 语义，不是 zip 的配对）。
#
# 默认**不截断**：一方先尽就继续把另一方的剩余吐完。理由是「收拢」不是
# 「配对」，长出来的一半依然是有用的记录，丢掉没有任何好处 —— 这也正是
# 它和 zip 默认取短的分界。要取短就写 `:shortest`。
#
# 完全惰性：每轮只从两侧各拉一行。短侧耗尽后仍会 pull 它（已耗尽的
# iterator 返回 IterationEnd 是幂等的，zip :longest 已验证过这一点）。
method interleave($other, Bool :$shortest = False
                  --> Rakuish::Data::Stream) {
    my @cols = self!concat-union-columns($other);
    Rakuish::Data::Stream.new(
        :make(-> {
            my $il = self!seq.iterator;
            my $ir = self!rows-of($other).iterator;
            gather {
                loop {
                    my $l = $il.pull-one;
                    my $r = $ir.pull-one;
                    my Bool $el = $l ~~ IterationEnd;
                    my Bool $er = $r ~~ IterationEnd;
                    last if $shortest ?? ($el || $er) !! ($el && $er);
                    take $l unless $el;
                    take $r unless $er;
                }
            }
        }),
        :source("{$!source} ⇄ " ~
                ($other ~~ Rakuish::Data::Stream ?? $other.source !! 'other')),
        :repeatable($!repeatable && self!other-repeatable($other)),
        :columns(@cols),
    );
}

# 首尾相接：先吐完左流，再吐右流（Unix `cat` 对同构流的语义）。
#
# 「同构」是**契约**：列元数据取左侧，左侧未知才取右侧。故意不取并集 ——
# 若接错了两条异构流，并集会让结果看起来有多个列、好像没事；沿用左列的
# 话，右侧多出来的列在 `.table` 里自然显示为缺值，问题一眼可见。
# 这与 interleave 不改名是同一个原则：不制造「看着对、其实错」的数据。
#
# 完全惰性：左流耗尽之前**不碰**右流（init 顺序也保证如此）。
method append($other --> Rakuish::Data::Stream) {
    my @left = @!columns.map(*.Str);
    my @cols = @left.elems
        ?? @left
        !! self!other-columns($other).map(*.Str).List;
    Rakuish::Data::Stream.new(
        :make(-> {
            gather {
                my $it = self!seq.iterator;
                loop {
                    my $r = $it.pull-one;
                    last if $r ~~ IterationEnd;
                    take $r;
                }
                # 到这里才取右流：一次性来源若已被消费过，此刻才报错；
                # 这也让「只取左流第一行」永远不会动到右流。
                my $it2 = self!rows-of($other).iterator;
                loop {
                    my $r = $it2.pull-one;
                    last if $r ~~ IterationEnd;
                    take $r;
                }
            }
        }),
        :source("{$!source} ++ " ~
                ($other ~~ Rakuish::Data::Stream ?? $other.source !! 'other')),
        :repeatable($!repeatable && self!other-repeatable($other)),
        :columns(@cols),
    );
}

method gist(--> Str) {
    "Stream<{$!source}>（用 .table / .text / .count 取值）";
}
