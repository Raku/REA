unit module Rakuish::Eval;

# Rakuish::Eval —— 引擎子进程的父侧客户端（0.83.0 / ADR-0021）。
#
# 只做一件事：把「一行输入」变成「一个响应」，并保证**引擎死了前端不死**。
# 语义全在子进程的 `Rakuish::Eval::Server` 里（它就是原来的 Session），
# 这一侧刻意不认识 Raku 语义 —— 不解析 `!`、不判断续行、不碰 `Out[n]`。
#
# 协议是**同一条管道上的请求/响应**，不是并发 RPC：同一时刻只有一条在飞。
# 父进程写一行 → 读若干行（`tty` 中间帧可选）→ 拿到同 seq 的终帧。
#
# 崩溃模型（ADR-0021 §3）：
#   · 子进程 `exit` / 段错误 / 被 kill ⇒ stdout EOF ⇒ Channel 关闭；
#   · 正在等的 `receive` 抛异常 ⇒ 收敛成 `X::Rakuish::Eval::Dead`；
#   · 上层（Proxy）捕获后重启一次，并把「状态已丢失」写进结果文本。
# 不承诺**求值中**中断（`while 1 {}` 仍需外部 kill），见 ADR-0021 §6。

use Rakuish::Result;
use Rakuish::Data::Table;
use JSON::Fast;

class X::Rakuish::Eval::Dead is Exception is export {
    has Str $.detail = '引擎进程已退出';
    method message(--> Str) { $!detail }
}

# 0.85.0 / ADR-0023：用户按了 Ctrl-C，不是引擎自己崩的。
# 两者都要重启引擎，但**归因不同** —— 把「我按了中断」说成「引擎崩了」
# 会让用户以为出了问题，下次就不敢用了。
class X::Rakuish::Eval::Interrupted is Exception is export {
    has Str $.detail = '求值被用户中断';
    method message(--> Str) { $!detail }
}

class Client is export {
    has Str $.raku = $*EXECUTABLE.Str;
    has IO::Path $.lib;              # 开发环境的 -I 路径；已安装时不必给
    has &.tty-exec;                  # (Str $exe, @argv --> Result)，父进程执行
    # 0.96.0 / ADR-0031：作业控制也在父进程执行（持有真终端 + 作业表）。
    # 签名 (Str $op, @args --> Any)，$op ∈ bg-exec / fg / bg / bg-jobs。
    has &.job-dispatch;
    has $.proc is rw;
    has Channel $!ch;
    has Bool $.alive is rw = False;
    has Str  $.cwd is rw = '';
    has %.config is rw;
    has Int  $.plugins is rw = 0;
    has @.plugin-names is rw;
    has Int  $.index is rw = 0;
    has Int  $.restarts is rw = 0;
    has Str  $.startup-out is rw = '';
    has Str  $.startup-err is rw = '';
    has %.restored is rw;          # 0.84：重启时的恢复摘要（空 = 没恢复）
    has Int  $!seq = 0;
    has Bool $!in-request  = False;   # 正在等响应（只有这时才接管 SIGINT）
    has Bool $!interrupted = False;
    has Bool $.signal-armed is rw = False;
    # 0.99.0 / tail -f：父侧长操作（job 帧的 tail-follow）期间 Ctrl-C 的
    # 归属是「停止跟随」，不是「杀引擎」。$!job-interactive 期间信号置
    # $!job-stop，跟随循环轮询它退出；引擎完好无损（重启会丢会话现场）。
    has Bool $!job-interactive = False;
    has Bool $!job-stop        = False;

    # 跟随循环的停止判据（bin 注入给 Sys.job-op 的 should-stop 闭包读它）。
    method job-stop(--> Bool) { $!job-stop }

    method start(Bool :$restore = False --> Nil) {
        self!arm-signal;
        my @cmd = ($!raku,);
        @cmd.push("-I{$!lib.absolute}") if $!lib.defined && $!lib.d;
        @cmd.push('-e', 'use Rakuish::Eval::Server; serve-engine()');

        # **不要**传 `:ENV`：本版 Rakudo 上它不生效（实测子进程仍拿父环境），
        # 而默认继承恰好是我们想要的 —— `RAKUISH_SNAPSHOT` / `RAKUISH_NO_SNAPSHOT`
        # 由父进程设好，子进程自动看到。恢复意图走协议（见下）。
        my $proc = Proc::Async.new(|@cmd, :w, :r, :e);
        # **必须**用局部 $ch / $proc 而不是 $!ch / $!proc：重启后旧进程的
        # done 回调还会触发一次，如果它闭包捕获的是属性，就会把**新**的
        # Channel 关掉 —— 表现是「重启后第一条请求就报 closed channel」。
        my $ch = Channel.new;
        $!proc = $proc;
        $!ch   = $ch;
        # 只 tap 一次：`stdout.lines` 每次调用都是新 Supply，重复 tap 会
        # 把同一行送进 Channel 两次，请求/响应就错位了。
        $proc.stdout.lines.tap(
            -> $l { try { $ch.send($l) } },
            done => { try { $ch.close } },
        );
        # 用户代码写 `$*ERR` 的内容落在这里；原样转发，不参与协议。
        $proc.stderr.lines.tap(-> $l { $*ERR.say($l) });

        my $done = $proc.start;
        $!alive = True;
        # 用 tap 而不是 `start { await }`：进程非零退出时 Promise 是 broken，
        # `start` 块里没被捕获的异常会变成 "Unhandled exception in code
        # scheduled on thread N"（0.83 开发中实测），tap 的 on-error 把它接住。
        # 旧进程退出不能把新进程标成 dead，所以要比对象身份。
        my &on-end = -> $p {
            $!alive = False if $!proc =:= $proc;
            try { $ch.close };
            Nil
        };
        # `then` 的回调无论 Promise 成败都会跑；回调自己不抛，
        # 新 Promise 就是 kept —— 于是「进程非零退出」不会被报成未处理异常。
        $done.then(&on-end);

        my %ready = self!receive;   # 启动就崩的话这里抛 Dead
        if (%ready<event> // '') ne 'ready' {
            self!shutdown;
            X::Rakuish::Eval::Dead.new(
                detail => '引擎未返回 ready：' ~ to-json(%ready, :!pretty)).throw;
        }
        $!cwd     = (%ready<cwd> // '').Str;
        %!config  = (%ready<config> // %{}).Hash;
        $!plugins = (%ready<plugins> // 0).Int;
        @!plugin-names = (%ready<plugin-names> // []).List;
        $!index   = (%ready<index> // 0).Int;
        $!startup-out = (%ready<out> // '').Str;
        $!startup-err = (%ready<err> // '').Str;

        # 恢复显式发起：只有崩溃重启的路径才要它。
        if $restore {
            my %r = self.request(%( cmd => 'restore' ));
            # 空快照时 Server 只回 path/index —— 不能把它当成「恢复了 0 项」，
            # 否则 Proxy 会显示一条没有意义的「已从快照恢复：0 条声明」。
            %!restored = ((%r<decls>:exists) || (%r<vars>:exists)) ?? %r !! %();
            $!index = (%r<index> // 0).Int;
        }
        Nil
    }

    # 重启：先杀旧进程，再起一个新的。会话状态**不恢复**（状态在旧进程里，
    # 那正是它死掉时丢失的东西）；调用方负责把这件事告诉用户。
    method restart(Bool :$restore = False --> Nil) {
        self!shutdown;
        ++$!restarts;
        self.start(:$restore);
    }

    # 0.85.0 / ADR-0023：求值期间的 Ctrl-C 由**这一层**接管。
    #
    # 为什么不是 worker 自己处理：实测 SIGINT 打不断 `loop { }`（MoarVM 不在
    # 纯 VM 循环里检查信号），所以只能由外部 kill 进程 —— 而「外部」就是这里。
    #
    # 为什么不是行编辑器处理：它只在 prompt 阶段有意义。求值期间它已经返回，
    # 却仍会记一个 take-interrupt 标志，导致**下一格**被误当成输入中断吞掉。
    #
    # 终端在求值期间是 cooked 模式（行编辑器 prompt 返回时恢复），
    # `` 由行规程转成 SIGINT 投给前台进程组 —— 父进程和 worker 都会收到。
    # worker 收到就直接死，但这里**不依赖**它：自己 kill 一次才确定。
    method !arm-signal(--> Nil) {
        return if $!signal-armed;
        my $sup = try { signal(SIGINT) };
        return unless $sup.defined;
        # 注意：回调跑在 scheduler 线程上，**不能写 `return`** ——
        # 它的词法 Routine 那时已经返回，会抛「Attempt to return outside of
        # immediately-enclosing Routine」。只用一个 if 分支。
        $sup.act: -> $sig {
            if $!job-interactive {
                # tail -f 之类的父侧长操作：Ctrl-C 只置停止标志（0.99.0）。
                $!job-stop = True;
            }
            elsif $!in-request && $!alive {
                $!interrupted = True;
                if $!proc.defined {
                    try { $!proc.kill(SIGKILL) };
                }
            }
            # 不在求值：什么也不做，把 Ctrl-C 让给行编辑器（输入中断）。
        };
        $!signal-armed = True;
        Nil
    }

    method !shutdown(--> Nil) {
        $!alive = False;
        if $!proc.defined {
            try { $!proc.close-stdin };
            try { $!proc.kill };
        }
        try { $!ch.close } if $!ch.defined;
        Nil
    }

    method !receive(--> Hash) {
        my $line;
        {
            CATCH {
                default {
                    $!alive = False;
                    # 中断先判：信号 kill 掉的 Channel 关闭与「引擎自己崩了」
                    # 在这里长得一模一样，只能靠 handler 留下的标志区分。
                    if $!interrupted {
                        $!interrupted = False;
                        X::Rakuish::Eval::Interrupted.new(
                            detail => '已中断当前求值').throw;
                    }
                    X::Rakuish::Eval::Dead.new(
                        detail => '连接已断开').throw;
                }
            }
            $line = $!ch.receive;
        }
        my $h = try { from-json($line) };
        ($h.defined && $h ~~ Hash) ?? $h !! %();
    }

    method !send(%frame --> Nil) {
        {
            CATCH {
                default {
                    $!alive = False;
                    X::Rakuish::Eval::Dead.new(
                        detail => '无法写入引擎（' ~ .message ~ '）').throw;
                }
            }
            await $!proc.write((to-json(%frame, :!pretty) ~ "\n").encode('utf-8'));
        }
        Nil
    }

    # 一个请求 → 一个终帧。中间的 `tty` 帧由父进程执行后回 resume。
    method request(%req --> Hash) {
        X::Rakuish::Eval::Dead.new(detail => '引擎未启动').throw unless $!alive;
        ++$!seq;
        %req<seq> = $!seq;
        $!interrupted = False;
        $!in-request  = True;
        LEAVE { $!in-request = False }
        self!send(%req);
        loop {
            my %h = self!receive;
            given (%h<event> // '') {
                when 'tty' {
                    self!answer-tty(%h);
                    next;
                }
                when 'job' {
                    self!answer-job(%h);
                    next;
                }
                when 'chunk' {
                    # 0.90.0 / ADR-0024：引擎的 stdout 是协议管道，用户看到
                    # 的终端在这里。块到就写，别攒着 —— 攒就是 0.89 的卡死感。
                    if (%h<seq> // 0) == $!seq {
                        my Str $text = (%h<text> // '').Str;
                        my $handle = (%h<ch> // 'out').Str eq 'err'
                                     ?? $*ERR !! $*OUT;
                        try { $handle.print($text); $handle.flush };
                    }
                    next;
                }
                when 'fatal' {
                    self!shutdown;
                    X::Rakuish::Eval::Dead.new(
                        detail => (%h<message> // '引擎致命错误').Str).throw;
                }
            }
            return %h if (%h<seq> // 0) == $!seq;
            # 理论上不会出现：协议是串行的。真出现了就丢掉旧帧，
            # 因为等一个永远不会来的 seq 只会把前端挂住。
        }
    }

    # `! --tty` 的父侧执行。父进程持有真终端，子进程的 stdio 是管道。
    method !answer-tty(Hash $h --> Nil) {
        my $hook = self.tty-exec;
        my $r;
        if $hook.defined {
            my $got = try { $hook(($h<exe> // '').Str, ($h<argv> // []).List) };
            $r = $got.defined && $got ~~ Rakuish::Result::Result
                ?? $got
                !! Rakuish::Result::Result.new(:!ok, :code(127), :op<tty-exec>,
                        :err('TTY 执行器返回了非 Result: ' ~ ($got // 'Any').raku));
        }
        else {
            $r = Rakuish::Result::Result.new(:!ok, :code(127), :op<tty-exec>,
                    :err('引擎请求 TTY 直通，但父进程没有注册执行器'));
        }
        self!send(%(
            seq => $!seq, cmd => 'resume',
            tty => %(
                ok   => ?$r.ok,
                code => $r.code,
                op   => $r.op,
                out  => $r.out,
                err  => $r.err,
            ),
        ));
        Nil
    }

    # 0.96.0 / ADR-0031：作业控制帧的父侧执行。与 !answer-tty 同形状，
    # 但多一种返回：bg-jobs 给的是 Table，不是 Result —— 用 rows+columns
    # 传回，引擎侧重建（Table 本身跨不过协议）。
    method !answer-job(Hash $h --> Nil) {
        my Str $op = ($h<op> // '').Str;
        my @args = ($h<args> // []).List;
        my $hook = self.job-dispatch;
        my %payload;

        # 0.99.0：tail-follow 是父侧长操作（跟随循环在这里跑）——期间
        # Ctrl-C 只应停止跟随（信号处理器置 $!job-stop），不能杀引擎。
        $!job-stop = False;
        $!job-interactive = $op eq 'tail-follow';
        LEAVE { $!job-interactive = False }

        if $hook.defined {
            my $got = try { $hook($op, @args) };
            if $got ~~ Rakuish::Result::Result {
                %payload = %( kind => 'result',
                    ok   => ?$got.ok, code => $got.code, op => $got.op,
                    out  => $got.out, err  => $got.err );
            }
            elsif $got ~~ Rakuish::Data::Table {
                %payload = %( kind => 'table',
                    columns => $got.columns.map(*.Str).List,
                    rows    => $got.rows.map({ .Hash }).List );
            }
            else {
                %payload = %( kind => 'result', :!ok, :code(127),
                    :op($op),
                    :err("作业执行器返回了无法序列化的值: " ~
                         (($got // Any).^name)) );
            }
        }
        else {
            %payload = %( kind => 'result', :!ok, :code(127), :op($op),
                :err('引擎请求作业控制，但父进程没有注册执行器') );
        }

        self!send(%( seq => $!seq, cmd => 'resume', job => %payload ));
        Nil
    }

    # ── 便捷方法（一一对应 Server 的 cmd）───────────────────────────
    method eval(Str $line, Bool :$color = False, Bool :$tty = False,
                Int :$width = 0, Int :$height = 0, Bool :$stream = False,
                Hash :$config = %() --> Hash) {
        # `tty` / `width` / `height` 必须显式传：引擎的 `$*IN` `$*OUT` 是
        # 协议管道，自己探测只会得到 False / 0 —— 那会让 `clear` 静默、
        # shell 彩色全灭、多列 `ls` 按 80 列排（0.87 / 0.88 修复）。
        # `stream` 同理：引擎没有终端，但父进程有，「要不要边跑边出」
        # 也必须由前端下发（0.90 / ADR-0024）。
        self.request(%( cmd => 'eval', line => $line, color => ?$color,
                        tty => ?$tty, width => $width, height => $height,
                        stream => ?$stream, config => $config ));
    }

    # 0.90.0 / ADR-0025：可编程 prompt。每次取都问一次引擎，时间 / git 这类
    # 动态信息才是「当下」；计算成本由 rc 里的函数自己控制。
    method prompt-text(--> Str) {
        my %h = self.request(%( cmd => 'prompt' ));
        (%h<text> // '').Str;
    }

    # 启动文件：读与路径解析在父进程，执行在引擎（它才持有 %STATE / alias）。
    method run-rc(Str $path --> Hash) {
        self.request(%( cmd => 'rc', path => $path ));
    }

    method complete(Str $line, Int $pos --> List) {
        my %h = self.request(%( cmd => 'complete', line => $line, pos => $pos ));
        (%h<items> // []).List;
    }

    # 0.100.0 / ADR-0034：输入行错误态标记（V-280）。计算在引擎侧的
    # Session（它持有 Shell 命令表 / 注册表 / PATH 视角），前端只拿区间。
    method error-marks(Str $line --> List) {
        my %h = self.request(%( cmd => 'error-marks', line => $line ));
        (%h<items> // []).List;
    }

    method key(Str $key --> Hash) {
        self.request(%( cmd => 'key', key => $key ));
    }

    method info(--> Hash) {
        self.request(%( cmd => 'info' ));
    }

    method shutdown(--> Nil) { self!shutdown }

    submethod DESTROY() { self!shutdown }
}
