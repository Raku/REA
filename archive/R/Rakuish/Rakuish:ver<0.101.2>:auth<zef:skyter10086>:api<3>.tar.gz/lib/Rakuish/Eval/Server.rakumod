unit module Rakuish::Eval::Server;

# Rakuish::Eval::Server —— 引擎子进程的协议服务端（0.83.0 / ADR-0021）。
#
# 为什么要有这个进程：Rakudo 上 `EVAL` 跑在宿主进程里，用户代码可以
#   · `exit` —— 直接结束整个 REPL；
#   · 段错误（NativeCall 乱指针、深度递归）—— 进程带走；
#   · `while 1 { }` —— SIGINT 打不断（实测：MoarVM 不在纯表达式循环里
#     检查中断），宿主只能被外部杀掉。
# 三条都要求**引擎与前端不在同一个进程**。rakupp 的 C ABI 同进程多实例
# 已在 0.80 探针里否掉（缺 `:pty`、并发 `rk_eval` SIGSEGV），所以走进程级。
#
# 这不是 V-906 否掉的「持久求值器」：V-906 的适用域是**多客户端服务**，
# 常驻编译单元会让跨请求状态泄漏；这里是单用户会话，跨格状态正是产品特性。
#
# 协议：stdin / stdout 各一行一个 JSON 对象（父进程见 Rakuish::Eval::Client）。
#   → {"seq":1,"cmd":"eval","line":"1+1","color":false,"config":{...}}
#   ← {"seq":1,"event":"result","ok":true,...,"text":"Out[1] = 1",...}
# 用户代码的 stdout 由 Session 的 CapturingOut 捕获后放进 `out` 字段，
# **不会**混进协议流；用户代码写 `$*ERR` 的内容落在本进程 stderr，
# 由父进程原样转发（不参与协议）。

use Rakuish::REPL::Session;
use Rakuish::Snapshot;
use Rakuish::Result;
use Rakuish::Data::Table;
use JSON::Fast;

# 只有这一处写协议流。任何 `say` 都会污染 stdout，所以统一走 emit。
sub emit(%h --> Nil) is export {
    $*OUT.print(to-json(%h, :!pretty) ~ "\n");
    $*OUT.flush;
    Nil
}

# 读一行请求；EOF 或坏 JSON 返回空 Hash（调用方按「父进程没了」处理）。
my sub read-msg(--> Hash) {
    my $line = $*IN.get;
    return %() unless $line.defined;
    return %() unless $line.trim.chars;
    my $h = try { from-json($line) };
    ($h.defined && $h ~~ Hash) ?? $h !! %()
}

# 把 Session 的接口摊平成一个响应。
my sub result-frame($session, $r, Str $line, Str $text, Duration $dt --> Hash) {
    %(
        seq        => $*SEQ,
        event      => 'result',
        ok         => ?$r.ok,
        op         => $r.op,
        code       => $r.code,
        # 渲染好的完整展示文本（含 Out[n] 标签与颜色）。父进程直接打印，
        # 不在父进程重算 —— 那样会要求把任意 Raku 值跨进程传过去。
        text       => $text,
        out        => $r.out,
        err        => $r.err,
        index      => $session.index,
        cwd        => $session.sys.cwd.Str,
        config     => $session.config,
        elapsed    => $dt.Str,
        exit       => ?$session.exit-requested,
        exit-code  => $session.exit-code,
        hint       => $session.next-hint($line, $r),
        no-newline => ?$r.no-newline,
        # 0.90.0 / ADR-0024：输出已经通过 chunk 帧实时送走，父进程不要再打印 text。
        streamed   => ?$r.streamed,
    )
}

sub serve-engine(--> Nil) is export {
    # 当前请求的 seq：TTY 往返的闭包要比主循环更晚取值，所以用动态变量。
    # **必须**声明在本 sub 内 —— 模块顶层的 `my $*SEQ` 不在调用链上，
    # 子进程里访问会抛「Dynamic variable $*SEQ not found」。
    my $*SEQ = 0;
    my $session = Rakuish::REPL::Session.new(:color(False));

    # 0.84.0 / ADR-0022：恢复由父进程显式发起（`restore` 命令），
    # 不在启动时自动做 —— 「什么时候恢复」是会话策略，不是引擎的事。
    # 也不能靠启动参数：`Proc::Async` 的 `:ENV` 在本版 Rakudo 上不生效
    # （实测子进程仍是父环境），所以走协议而不是进程环境。
    my %restored;

    # TTY 直通必须由父进程执行：本进程的 stdin/stdout 是协议管道，不是终端。
    # 闭包发一个 tty 事件，然后**同步**等父进程回 resume（同一时刻只可能
    # 有一个请求在飞，所以这里读到的一定是对应的 resume）。
    $session.tty-handler = -> Str $exe, @argv {
        emit %( seq => $*SEQ, event => 'tty', exe => $exe, argv => @argv.List );
        my %res = read-msg();
        my %t = (%res<tty> // %());
        Rakuish::Result::Result.new(
            :ok(?(%t<ok> // False)),
            :code((%t<code> // 127).Int),
            :op((%t<op> // 'tty-exec').Str),
            :out((%t<out> // '').Str),
            :err((%t<err> // '无 TTY 结果：父进程未回传').Str),
        );
    };

    # 0.96.0 / ADR-0031：作业控制帧。与 tty-handler 同理 —— 引擎的 stdout
    # 是协议管道、也没有真终端，bg-exec/fg/bg 必须由父进程执行。DSL 的四个
    # 函数走 Sys.job-op → job-dispatch → 这里 → 父进程 → resume 帧。
    # 0.99.0：等待父侧结果期间吞掉终端 Ctrl-C —— tail-follow 之类的父侧
    # 长操作里，SIGINT 属于跟随循环（父进程置停止标志），worker 必须活着
    # 接结果；否则 SIGINT 的默认处置会把 worker 直接打死（t/54 时代实测）。
    $session.sys.job-dispatch = -> Str $op, *@args {
        emit %( seq => $*SEQ, event => 'job', op => $op, args => @args.List );
        my $tap = try { signal(SIGINT).tap(-> $ {}) };
        my %res = read-msg();
        try { $tap.close if $tap.defined };
        my %p = (%res<job> // %());
        if (%p<kind> // '') eq 'table' {
            Rakuish::Data::Table.new(
                :columns((%p<columns> // []).List),
                :rows((%p<rows> // []).List));
        }
        else {
            Rakuish::Result::Result.new(
                :ok(?(%p<ok> // False)),
                :code((%p<code> // 127).Int),
                :op((%p<op> // $op).Str),
                :out((%p<out> // '').Str),
                :err((%p<err> // '').Str));
        }
    };

    # 0.90.0 / ADR-0024：`!` 的流式输出。本进程的 stdout 是协议管道，
    # 所以块不能直接打印 —— 写成 chunk 帧，由持有终端的父进程实时写出。
    $session.chunk-handler = -> Str $ch, Str $text {
        emit %( seq => $*SEQ, event => 'chunk', ch => $ch, text => $text );
    };

    # 启动 hook 属于会话初始化，跑在引擎里（它可能要 `use` / 定义变量）。
    # 输出攒起来随 ready 帧回传，父进程负责打印。
    my @hook-out;
    my @hook-err;
    for $session.run-hooks('start') -> $r {
        @hook-out.push($r.out) if $r.out.chars;
        @hook-err.push($r.err) if $r.err.chars;
        unless $r.ok {
            emit %( event => 'fatal',
                    message => '启动 hook 失败: ' ~ ($r.err // '').Str );
            return;
        }
    }

    emit %(
        event   => 'ready',
        pid     => $*PID,
        cwd     => $session.sys.cwd.Str,
        config  => $session.config,
        plugins => $session.plugins.names.elems,
        plugin-names => $session.plugins.names.List,
        index   => $session.index,
        out     => @hook-out.join,
        err     => @hook-err.join,
        %( restored => %restored ),
    );

    loop {
        my %msg = read-msg();
        last unless %msg.elems;          # EOF：父进程退出
        $*SEQ = (%msg<seq> // 0).Int;
        my Str $cmd = (%msg<cmd> // '').Str;

        given $cmd {
            when 'eval' {
                # config 由父进程当格推下来（父进程是 config 的唯一权威：
                # banner / prompt / 高亮开关都在它那边读）。
                $session.config = %msg<config>.Hash if %msg<config>.defined;
                $session.set-color(?(%msg<color> // False));
                # 0.87.0：真实终端是不是 TTY 由父进程告知。**不能**让引擎
                # 自己看 `$*OUT.t` —— 它的 stdout 是协议管道，恒 False。
                $session.set-tty(?(%msg<tty> // $session.tty))
                    if %msg<tty>:exists;
                $session.set-size(:width((%msg<width>  // 0).Int),
                                  :height((%msg<height> // 0).Int));
                # 0.90.0：要不要边跑边出由父进程决定（只有它知道 stdout 是不是终端）。
                $session.set-stream-out(?(%msg<stream> // False))
                    if %msg<stream>:exists;
                my Str $line = (%msg<line> // '').Str;
                my Instant $t0 = now;
                my $r = $session.eval-line($line);
                my Duration $dt = now - $t0;
                $session.note-timing($dt, $line, $r.ok);
                my Str $text = $session.render($r);
                # 会话日志要在能同时看到「输入 + Result + 渲染文本」的地方写。
                $session.log-line($line, $r, $text);
                emit result-frame($session, $r, $line, $text, $dt);
            }
            when 'complete' {
                my Str $line = (%msg<line> // '').Str;
                my Int $pos  = (%msg<pos> // $line.chars).Int;
                emit %( seq => $*SEQ, event => 'completions',
                        items => $session.completions($line, $pos).List );
            }
            when 'error-marks' {
                my Str $line = (%msg<line> // '').Str;
                emit %( seq => $*SEQ, event => 'marks',
                        items => $session.error-marks($line).List );
            }
            when 'key' {
                my $r = $session.handle-key((%msg<key> // '').Str);
                emit %( seq => $*SEQ, event => 'key',
                        ok => ?$r.ok, op => $r.op, value => $r.value.Str,
                        index => $session.index );
            }
            when 'info' {
                emit %( seq => $*SEQ, event => 'info',
                        cwd => $session.sys.cwd.Str,
                        index => $session.index,
                        config => $session.config,
                        plugins => $session.plugins.names.elems,
                        plugin-names => $session.plugins.names.List,
                        history => $session.history.elems );
            }
            when 'prompt' {
                emit %( seq => $*SEQ, event => 'prompt',
                        text => $session.render-prompt );
            }
            when 'rc' {
                # 0.90.0 / ADR-0025：启动文件。路径由父进程解析（RAKUISH_RC /
                # $*HOME/.rakuishrc / RAKUISH_NO_RC），引擎只负责执行 ——
                # 「读哪个文件」是会话策略，不是解释器的事。
                my Str $path = (%msg<path> // '').Str;
                my Str $src  = '';
                my Str $err  = '';
                if !$path.chars {
                    $err = '没有指定 rc 路径';
                }
                elsif !$path.IO.e {
                    $err = "启动文件不存在: {$path}";
                }
                else {
                    {
                        CATCH { default { $err = .message } }
                        $src = $path.IO.slurp(:enc<utf-8>);
                    }
                }
                if $err.chars {
                    emit %( seq => $*SEQ, event => 'rc', ok => False,
                            out => '', err => $err, failed => 1, lines => 0,
                            prompt => '',
                            config => $session.config,
                            cwd => $session.sys.cwd.Str,
                            index => $session.index );
                }
                else {
                    my %h = $session.run-rc($src, :label($path));
                    emit %( seq => $*SEQ, event => 'rc',
                            ok => ?(%h<failed> == 0),
                            out => %h<out>, err => %h<err>,
                            failed => %h<failed>, lines => %h<lines>,
                            prompt => $session.render-prompt,
                            config => $session.config,
                            cwd => $session.sys.cwd.Str,
                            index => $session.index );
                }
            }
            when 'restore' {
                # `snapshot-on` 同时管读写：关掉快照的会话不该去翻磁盘上
                # 上一轮留下的文件（那会把「关闭」变成「只关一半」）。
                my %r = %();
                if $session.snapshot-on {
                    my %snap = Rakuish::Snapshot::load($session.snapshot-path.IO);
                    %r = %snap.elems ?? $session.restore-snapshot(%snap) !! %();
                }
                emit %( seq => $*SEQ, event => 'restored',
                        path => $session.snapshot-path,
                        index => $session.index, |%r );
            }
            when 'quit' {
                last;
            }
            default {
                emit %( seq => $*SEQ, event => 'error',
                        message => "未知 cmd: $cmd" );
            }
        }
        last if $cmd eq 'quit';
    }
}
