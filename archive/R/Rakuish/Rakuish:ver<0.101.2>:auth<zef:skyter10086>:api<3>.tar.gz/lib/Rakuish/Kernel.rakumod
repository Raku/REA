# Rakuish::Kernel —— 前端与执行之间的唯一入口（0.76.0 / ADR-0013）。
#
# 为什么要有这一层：0.75 之前「人」和「Agent」是两条并列路径 ——
#   · 人：`Session.eval-line(文本)`，本地信任，root 是文件系统根；
#   · Agent 线已于 0.81.0 删除（ADR-0019）；op 通道只剩 `capabilities`，其余 501。
# 两条路径各有自己的入口、错误码与权限判断，继续加功能只会让漂移变大。
#
# 0.76 只做**搬运**，不改语义：把「构造请求 → 检查策略 → 执行」收成
# `Kernel.execute(Request)`，TTY 前端改走它；行为与 0.75 逐字节相同。
# `op` 通道留到 0.78 与 Agent 协议一起接（见 ADR-0013 §7）。
#
# 三条不变式（SPEC V-182 / V-183）：
#   1. 前端不得直接调 `Session.eval-line` / `Sys.*`，只能构造 Request；
#   2. `Policy` 由 Kernel 强制执行，前端传来的只能**收窄**，不能放宽；
#   3. 所有系统操作仍过 `Sys`（V-125 不变），本层不新增旁路。

use Rakuish::Result;
use Rakuish::Display;   # 0.78.0：内容级展示包（ADR-0016）
use Rakuish::Audit;     # 0.80.0：统一审计账本

# ── 异常族：策略拒绝不抛给前端，统一收敛成 Result ───────────────────
# 名字不带 Policy：`is export` 默认导出短名，X::...::Policy 会撞上 Policy。
class X::Rakuish::Kernel::Denied is Exception is export {
    has Str $.detail is required;
    method message(--> Str) { $!detail }
}

# ── Policy：这一条请求以什么身份执行 ────────────────────────────────
# 0.82.0 / ADR-0020：**只保留有执行点的字段**。
#
# 0.76 的 Policy 有七个字段，但 Agent 线删除（0.81.0）后逐个核对执行点：
#   · allow-source —— Kernel 里真的拦（唯一闸门）
#   · root         —— narrow 时真的校验包含关系
#   · profile      —— 只进审计与 describe，是标签
#   · allow-exec   —— **没有执行点**：`!` / Sys.exec 从不查它
#   · read-only    —— **没有执行点**：Sys 的写操作从不查它
#   · allow-ops    —— 只影响 op 通道，而 op 通道只剩 capabilities
#   · limits       —— **没有执行点**：没有任何读取者
# 后四个留着就是「牌子」—— 声明禁止、实际放行，正是 ADR-0019 拒绝的东西。
# 拆掉它们比留着更诚实：能力清单只写真的能执行的判定。
class Policy is export {
    has Str  $.profile    = 'local';   # 标签：local / analyst，只影响日志
    has Bool $.allow-source = True;    # 唯一被执行判定的字段
    has      $.root;                   # 可收窄的执行根（Any = 不限制）

    method describe(--> Str) {
        my Str $r = $!root.defined ?? $!root.Str !! '(不限制)';
        "profile={$!profile} source={$!allow-source.Int} root=$r";
    }

    # 收紧：`$inner` 是前端传来的策略，只能比 self 更严。
    # 放宽的情况不报错、直接按 self 算（前端多给权限不生效），
    # 只有「根目录跑到外面」这种越界必须显式拒绝 —— 静默接受会让
    # 调用方以为自己的 root 生效了。
    method narrow(Policy $inner --> Policy) {
        my $root = $!root;
        if $inner.root.defined {
            if $root.defined && !within($inner.root, $root) {
                X::Rakuish::Kernel::Denied.new(
                    detail => "请求策略的 root（{$inner.root.Str}）不在内核 root"
                            ~ "（{$root.Str}）之内，拒绝执行").throw;
            }
            $root = $inner.root;   # 更窄（或内核本来不限制）
        }
        Policy.new(
            # profile 取内层：它是「这次请求以谁的身份」的标签，只影响日志。
            :profile($inner.profile),
            :allow-source($!allow-source && $inner.allow-source),
            :$root,
        );
    }
}

# 词法包含判断：`$inner` 是否落在 `$outer` 之内。
# 刻意不用 `IO::Path.contains` —— 它按真实路径解析，路径不存在时返回 False，
# 策略判定不该依赖「目录恰好存在」。这里只做词法归一化 + 分隔符边界比较，
# 与 `Sys.resolve` 的第一步一致；符号链接由真正的 `Sys` 调用去挡（V-201）。
sub within(IO::Path $inner, IO::Path $outer --> Bool) {
    my sub norm(IO::Path $p --> Str) {
        my Str $s = $p.absolute.subst(:g, '\\', '/');
        # 不用 `.trim-trailing('/')`：本版 Rakudo 上它不接受参数
        # （报「expected 1 argument but got 2」），用正则剥尾部分隔符。
        $s = $s.subst(/ \/+ $/, '') || '/';
        $*DISTRO.is-win ?? $s.lc !! $s;
    }
    my Str $i = norm($inner);
    my Str $o = norm($outer);
    return True if $i eq $o;
    return True if $o eq '/';
    $i.starts-with($o ~ '/');
}

# ── Request：一次执行请求 ────────────────────────────────────────────
# `kind` 是唯一的语法维度：source（文本）/ op（结构化操作，0.78）。
# 前端不该自己判断「这是命令还是表达式」——那是 Session 的活。
class Request is export {
    has Str  $.kind is required;
    has      $.payload;            # source → Str；op → Hash
    has Str  $.origin = 'human';   # human / agent / notebook / script
    has      $.policy;             # Policy | Any（不传 = 不收窄）
    has Str  $.id = '';            # 可选，审计用

    method describe(--> Str) {
        my Str $p = $!payload.defined ?? $!payload.WHAT.^name !! 'Any';
        "kind={$!kind} origin={$!origin} payload=$p";
    }
}

# ── Kernel ───────────────────────────────────────────────────────────
class Rakuish::Kernel is export {
    has $.session is required;
    has Policy $.policy = Policy.new;
    has $.audit;   # 0.80.0：可注入的共享 Rakuish::Audit 实例

    submethod TWEAK() {
        # 不注入时只建纯内存账本：Kernel 常被测试直接 new，不该往用户目录写。
        $!audit = Rakuish::Audit.new(:default-origin<human>)
            unless $!audit.defined;
    }

    # 调试视图（t/35 的契约）；真正的账本在 $!audit。
    has @!trail;
    has Int $!seq = 0;

    method trail(--> List) { @!trail.List }

    # 唯一的执行入口。
    method execute(Request $req --> Result) {
        my Policy $eff = $!policy;
        my Result $r;
        my Instant $t0 = now;
        my Bool $denied = False;
        # 0.80.0：**唯一记账点**。0.76 的写法在末尾显式 !record，而策略越界
        # 分支 `return $r if $denied` 偏偏绕过它（注释说不 return，代码却
        # return 了）—— 安全事件最该留痕的一条反而漏了。改成 LEAVE：正常 /
        # 拒绝 / 早返回 / 异常都恰好一条；审计自身出错也不能弄崩求值。
        LEAVE {
            try {
                my $final = $r.defined
                    ?? $r
                    !! Result.new(:!ok, :code(500), :op<kernel>,
                                  :err('内核异常，未完成求值'));
                self!record($req, $eff, $final, $t0);
            }
        }
        {
            CATCH {
                default {
                    .Bool;
                    $denied = True;
                    $r = self!deny('策略越界: ' ~ .message);
                }
            }
            $eff = $req.policy.defined
                ?? $!policy.narrow($req.policy)
                !! $!policy;
        }
        return $r if $denied;

        $r = do given $req.kind {
            when 'source' {
                if !$eff.allow-source {
                    self!deny("该策略不允许执行源码（{$eff.describe}）");
                }
                else {
                    # payload 必须是文本。非 Str 不猜、不 stringify 任意对象：
                    # 那会把「传错了」变成「执行了别的东西」。
                    if !($req.payload ~~ Str) {
                        Result.new(:!ok, :code(2), :op<kernel>,
                                   :err('source 请求的 payload 必须是 Str'));
                    }
                    else {
                        $!session.eval-line($req.payload);
                    }
                }
            }
            when 'op' {
                # 0.78.0 / V-186：op 通道开工，但**只开不需要系统能力的 op**。
                # 形态固定为 `payload => %(op => 'name', ...参数)`，与 source 的
                # 「payload 是文本」并列；非 Hash 一律 400/2，不做隐式转换。
                if !($req.payload ~~ Hash) {
                    Result.new(:!ok, :code(2), :op<kernel>,
                               :err('op 请求的 payload 必须是 Hash，如 { op => "capabilities" }'));
                }
                elsif !($req.payload<op> // '').Str.chars {
                    Result.new(:!ok, :code(2), :op<kernel>,
                               :err('op 请求缺少 payload<op>'));
                }
                else {
                    my Str $name = $req.payload<op>.Str;
                    # 0.82.0：不再有 allow-ops 过滤 —— op 通道只剩 capabilities
                    # 一个 op，名字级的白名单没有可挡的对象（ADR-0020）。
                    self!run-op($name, $req.payload);
                }
            }
            default {
                Result.new(:!ok, :code(2), :op<kernel>,
                           :err("未知的请求类型: {$req.kind}"));
            }
        };

        $r;
    }

    # ── op 分发（0.78.0）─────────────────────────────────────────────
    # 目前只开 `capabilities`：它不碰文件、不起进程、不执行源码，
    # 因此不需要 Sys 参与。其余 op 明确 501，并把「为什么不给」
    # 写进错误里 —— 0.80 起 `execute` 明确不做（ADR-0018），不要有第二个含糊的「空成功」。
    method !run-op(Str $name, Hash $payload --> Result) {
        given $name {
            when 'capabilities' {
                Result.new(:ok, :op<capabilities>, :value(self.capabilities));
            }
            default {
                Result.new(:!ok, :code(501), :op<kernel>,
                           :err("op 未接入: $name（op 通道只开 capabilities；"
                                ~ "文件/进程请用本机 REPL 的 ! 前缀或 Sys API，"
                                ~ "Agent 协议已于 0.81.0 删除）"));
            }
        }
    }

    # 能力矩阵：**只列真的能用**的。前端据此决定怎么请求，别把计划写进来。
    method capabilities(--> Hash) {
        my %c = Rakuish::Display::capabilities();
        %c<request-kinds> = <source op>.List;
        %c<ops>           = <capabilities>.List;
        %c<profiles>      = <local analyst>.List;  # agent 档随 Agent 线删除
        # 只列 Policy 上真的存在的字段（0.82.0 拆掉四个无执行点的字段）。
        %c<policy-fields> = <profile allow-source root>.List;
        %c
    }

    # ── 展示包（0.78.0 / V-184）──────────────────────────────────────
    # 内容级：text 必有、markdown/json 可选。终端装饰（颜色 / Out[n] / 分页）
    # 不在这里 —— 那是前端 `Session.render` 的事。
    method bundle(Result $r, Int :$max-rows = 200 --> Rakuish::Display::Bundle) {
        bundle-from($r, :$max-rows);
    }

    # 线上表示：只带实际选中的那一种格式（`format` 字段说明降级与否）。
    method present(Result $r, Str :$format = 'text', Int :$max-rows = 200 --> Hash) {
        self.bundle($r, :$max-rows).to-hash(:$format);
    }

    # 只造 Result，不记录：记录统一在 execute 的 LEAVE 里做一次，
    # 否则「拒绝」会记两条（0.76 开发中踩过，靠 t/35 的 trail 计数发现）。
    # 0.82.0：去掉没人用的 `$req` 形参 —— 拒绝原因已经带在消息里，
    # 记录点在 LEAVE，不需要在这里回看请求。
    method !deny(Str $why --> Result) {
        Result.new(:!ok, :code(403), :op<kernel>, :err($why));
    }

    method !record(Request $req, Policy $eff, Result $r, Instant $t0 --> Nil) {
        my %src = $req.kind eq 'source' && $req.payload ~~ Str
            ?? %( 'source-hash'  => Rakuish::Audit::fingerprint($req.payload),
                  'source-bytes' => $req.payload.encode('utf-8').elems )
            !! %();
        # 源码**只记指纹与字节数，不记任何源码文本**（V-606）：
        # 首行也可能含凭据，不给自己留这个口子。
        my %c = $!audit.record(%(
            origin     => $req.origin,
            kind       => $req.kind,
            action     => $req.kind eq 'source'
                          ?? 'source'
                          !! (($req.payload ~~ Hash ?? ($req.payload<op> // '') !! '').Str),
            session    => 'local',
            policy     => $eff.profile,
            root       => ($eff.root.defined ?? $eff.root.Str !! ''),
            ok         => $r.ok,
            code       => $r.code,
            elapsed-ms => ((now - $t0) * 1000).Int,
            # source 失败不记 err：Rakudo 的编译错误常把源码片段带进消息，
            # 那样「只记指纹」就成了空话。
            detail     => ($r.ok || $req.kind eq 'source'
                            ?? '' !! ($r.err // '').Str.substr(0, 200)),
            |%src,
        ));
        ++$!seq;
        @!trail.push({
            seq    => (%c<seq> // $!seq),
            kind   => $req.kind,
            origin => $req.origin,
            profile => $eff.profile,
            ok     => $r.ok,
            code   => $r.code,
        });
        @!trail.shift while @!trail.elems > 200;
        Nil
    }
}
