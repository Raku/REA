unit module Rakuish::Snapshot;

# Rakuish::Snapshot —— 会话快照的判定 / 捕获 / 落盘（0.84.0 / ADR-0022）。
#
# 为什么能做这件事：Rakuish 刻意把 REPL 的 `my` 变量收进一个哈希
# （`%!state<$x>`），每格再用 `my $x := %STATE<$x>` 别名注入。于是
# **可快照的边界本来就已经存在** —— 不是「给 Raku 做镜像」，而是
# 「把已有的两个容器（%STATE 与 @decls）写出去」。
#
# 边界（ADR-0022 §2，实测得出）：
#   · 纯值 → 存 `.raku`，恢复时 `EVAL` 回来；14/14 常见类型往返成功，
#     含用户类实例（前提是同一次快照里带着类定义）；
#   · 资源（连接 / 句柄 / 进程 / 锁）→ **标记失效**，不存 `.raku`。
#     它们能「恢复成功」但语义是全新的（`DB::SQLite.new(...)` 重连空库），
#     比起崩溃，静默的错误状态更难查；
#   · 闭包 / Code → 标记失效（`.raku` 只能给出 `<anon>` 之类，无反序列化）；
#   · 超大值 → 标记失效（避免每格写一个几十 MB 的 JSON）。
#
# 本模块**不碰 REPL 状态**：只吃 Hash / List，产出 Hash。副作用只有落盘。

use JSON::Fast;

# 资源类类型名的前缀。用类型名而不是 `~~ 类型` 逐个列举，是因为
# 可选依赖（DB::SQLite / DuckDB）在没装时不能出现在 `~~` 里，
# 而字符串匹配对「装了但没 require」的情况同样成立。
# 不用 regex：`Proc::Async` 里的 `::` 在 regex 里是语法（`:: not yet implemented`），
# 转义又容易漏。前缀 + 精确匹配更好读，也更好加条目。
my constant RESOURCE-PREFIX = <
    Proc IO::Handle IO::Socket IO::Pipe IO::CatHandle
    Supply Channel Promise Lock Semaphore Thread Tap
    DB:: DBIish:: DuckDB Rakuish::Data::Engine
>;

# `.raku` 里出现这些就说明它不是一个可重建的构造表达式。
my constant OPAQUE-MARKERS = <
    '<object>' '<anon>' '(closed)' '<closed>'
>;

sub resource-type(Str $t --> Bool) {
    RESOURCE-PREFIX.first({ $t eq $_ || $t.starts-with($_) }).defined;
}

sub opaque-repr(Str $r --> Bool) {
    OPAQUE-MARKERS.first({ $r.contains($_) }).defined;
}

# 单值上限：超过就当失效。REPL 里真的会有 50MB 的数组，
# 每格把它 `.raku` 一遍再写盘，手感会直接烂掉。
#
# 0.87.0：默认值仍是 1e6，但**可配置**（`RAKUISH_SNAPSHOT_MAX`）。
# 理由：上限是「手感 vs 能救回多少」的取舍，不同人差很多 ——
# 有人整天摆弄几十万元素的数组，1e6 字符全判失效等于快照没意义；
# 也有人希望快照永远别超过几 KB。硬编码一个数字就是把我的取舍
# 当成所有人的。
our constant DEFAULT-MAX-VALUE-CHARS = 1_000_000;

# 运行时上限。`0` / `off` / `none` / `unlimited` = 不限制。
# 非法值（负数、非数字）**回落到默认**而不是当成 0 —— 「写错了」不该
# 变成「关掉保护」，那是最糟的失败方向。
our sub max-value-chars(--> Int) {
    my Str $raw = (%*ENV<RAKUISH_SNAPSHOT_MAX> // '').Str.trim.lc;
    return DEFAULT-MAX-VALUE-CHARS unless $raw.chars;
    return 0 if $raw (elem) <0 off none unlimited no-limit>;
    my $n = try { $raw.Int };
    return DEFAULT-MAX-VALUE-CHARS unless $n.defined && $n >= 0;
    $n;
}

# 快照格式版本：结构性变更（字段增删/语义变化）才 +1。
our sub snapshot-version(--> Int) { 1 }

# 判定一个值能不能进快照。
# 返回 %( kind => 'nil' | 'value' | 'invalid', raku => Str, type => Str, reason => Str )
# `:max` 是单值字符上限，0 = 不限制（由 capture 统一传，classify 本身不读环境）。
our sub classify($v, Int :$max = DEFAULT-MAX-VALUE-CHARS --> Hash) {
    return %( kind => 'nil', raku => 'Any', type => 'Any', reason => '' )
        unless $v.defined;

    my Str $type = $v.WHAT.^name;

    # 闭包先判：Sub / Method / Block 都是 Code。
    if $v ~~ Code {
        return %( kind => 'invalid', raku => '', type => $type,
                 reason => 'closure（代码对象无法反序列化）' );
    }
    if resource-type($type) {
        return %( kind => 'invalid', raku => '', type => $type,
                 reason => 'resource（连接/句柄/进程/锁，重建出来的是新对象）' );
    }

    my $repr = try { $v.raku };
    unless $repr.defined && $repr ~~ Str {
        return %( kind => 'invalid', raku => '', type => $type,
                 reason => '.raku 不可用' );
    }
    if opaque-repr($repr) {
        return %( kind => 'invalid', raku => '', type => $type,
                 reason => '`.raku` 没有可重建的表示' );
    }
    if $max > 0 && $repr.chars > $max {
        return %( kind => 'invalid', raku => '', type => $type,
                 reason => "值过大（{ $repr.chars } 字符 > {$max}）" );
    }
    %( kind => 'value', raku => $repr.Str, type => $type, reason => '' );
}

# 捕获一份快照。`@decls` 是 Session 的纯声明缓存（key / src / name / is-type）。
our sub capture(%state, @decls,
                Str :$cwd = '', Str :$session = '', Str :$rakuish = '',
                Int :$max = max-value-chars() --> Hash) {
    my %values;
    my @invalid;
    for %state.keys.sort -> $k {
        my %c = classify(%state{$k}, :$max);
        %values{$k} = %c;
        @invalid.push($k) if %c<kind> eq 'invalid';
    }
    %(
        'snapshot-version' => snapshot-version(),
        'rakuish'          => $rakuish,
        session            => $session,
        cwd                => $cwd,
        'saved-at'         => DateTime.now.Str,
        decls              => @decls.map({
            %( key     => (.<key>  // '').Str,
               src     => (.<src>  // '').Str,
               name    => (.<name> // '').Str,
               'is-type' => ?(.<is-type>) )
        }).List,
        state   => %values,
        invalid => @invalid.List,
    );
}

# 原子落盘：先写 `.tmp` 再 rename。Windows 上 rename 覆盖已存在文件会失败，
# 那时退化成「删了再 rename」—— 短窗口内没有快照，但这比写坏一个 JSON 强。
our sub save(%snap, IO::Path $path --> Bool) {
    my $parent = $path.parent;
    try { $parent.mkdir unless $parent.e };

    my Str $text = to-json(%snap, :!pretty);
    my $tmp = $parent.add($path.basename ~ '.tmp');
    my $ok = True;
    {
        CATCH { default { $ok = False } }
        $tmp.spurt($text, :enc<utf-8>);
    }
    return False unless $ok;

    my Bool $moved = False;
    {
        CATCH { default { } }
        $tmp.rename($path);
        $moved = True;
    }
    unless $moved {
        # Windows：目标存在时 rename 失败
        try { $path.unlink if $path.e };
        {
            CATCH { default { $moved = False } }
            $tmp.rename($path);
            $moved = True;
        }
    }
    # POSIX 上把权限收紧到 600：快照里有变量的**值**（可能有凭据），
    # 不该让同机其他用户读到。Windows 无对应语义，忽略失败。
    unless $*DISTRO.is-win {
        try { $path.chmod(0o600) };
    }
    $moved;
}

# 读快照。任何异常都返回空 Hash —— 启动流程不该被一个坏文件挡住。
our sub load(IO::Path $path --> Hash) {
    return %() unless $path.e;
    my $text = try { $path.slurp(:enc<utf-8>) };
    return %() unless $text.defined && $text ~~ Str && $text.chars;
    my $h = try { from-json($text) };
    return %() unless $h.defined && $h ~~ Hash;
    # 只接受本格式版本：以后改结构时旧文件直接当没有，而不是猜字段。
    return %() unless ($h{'snapshot-version'} // 0).Int == snapshot-version();
    $h;
}
