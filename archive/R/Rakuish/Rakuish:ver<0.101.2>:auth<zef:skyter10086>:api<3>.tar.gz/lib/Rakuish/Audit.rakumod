unit class Rakuish::Audit;

# Rakuish::Audit —— 全进程唯一的「每次操作一条」结构化账本（0.80.0 / ADR-0018）。
#
# 0.80 之前有三套互不通气的账本：
#   · Sandbox.audit     Agent 请求，结构化，落盘 + 轮转  ← 0.81.0 已随 Agent 线删除
#   · Session.log-line  人类可读的会话抄本（含渲染文本），默认关闭
#   · Kernel.@!trail    内存摘要，200 条上限，只是调试视图
# 没有任何一处能保证「每次操作都有记录」。本模块把**写入**收成一个函数。
#
# 0.81.0 / ADR-0019：Agent 线删除后只剩**一个**写入点（Kernel.execute 的 LEAVE），
# 但审计本身保留 —— 那是用户明确要求的硬约束，不随安全壳一起撤。
# Session.log-line 保持原样 —— 那是给人看的抄本，不是审计。
#
# 两条不变式：
#   1. 字段白名单：调用方多传的键一律丢弃。token / 文件内容 / SQL 全文 /
#      源码全文**结构上进不来**，不靠每个调用点自觉（V-606）。
#   2. 审计不能弄崩业务：落盘失败、路径不存在、轮转失败全部 try 吞掉。

use JSON::Fast;

my constant FIELDS = <
    seq ts origin kind action op stage session policy root
    path argv sql-fingerprint sql-params source-hash source-bytes
    ok code elapsed-ms detail err
>;

# 多实例共享一把锁：同一进程可能有多个 Audit（测试、多会话），entries / 追加写必须串行。
my Lock $LOCK .= new;

has Bool $.enabled = True;
has Str  $.path    = '';
has Int  $.max-entries = 10_000;
has Int  $.max-bytes   = 10 * 1024 * 1024;
has Str  $.default-origin = 'unknown';
has @!entries;
has Int $!seq = 0;

submethod TWEAK() {
    # 同一个日志文件可能被多个进程追加（REPL / -e / 脚本各起一个进程）。
    # 以现有行数为起点，seq 在文件里保持连续；进程内仍有锁保证不重号。
    if $!path.chars {
        my $p = $!path.IO;
        $!seq = (try { $p.lines.elems } // 0).Int if $p.e;
    }
}

# FNV-1a：源码与 SQL 只留稳定指纹。0.80 起这是**唯一**实现 ——
# Agent 原来的 !sql-fingerprint 与它是一份逻辑，不再各写一遍。
our sub fingerprint(Str $s --> Str) is export {
    my uint64 $h = 1469598103934665603;
    for $s.encode('utf-8').list -> uint8 $b {
        $h = (($h +^ $b) * 1099511628211) +& 0xFFFFFFFFFFFFFFFF;
    }
    $h.base(16);
}

method record(%e --> Hash) {
    return {} unless $!enabled;
    my %c;
    $LOCK.protect({
        ++$!seq;
        for FIELDS -> $k {
            %c{$k} = %e{$k} if %e{$k}:exists;
        }
        %c<seq>    = $!seq;
        %c<ts>     = DateTime.now.Str;
        %c<origin> = $!default-origin unless %c<origin>:exists;
        %c<ok>     = True unless %c<ok>:exists;
        %c<code>   = 0    unless %c<code>:exists;

        @!entries.push(%c);
        if $!max-entries > 0 && @!entries.elems > $!max-entries {
            @!entries.splice(0, @!entries.elems - $!max-entries);
        }

        if $!path.chars {
            my $p = $!path.IO;
            if $!max-bytes > 0 && $p.e && $p.s > $!max-bytes {
                my Str $bak = $p.Str ~ '.1';
                try { $bak.IO.unlink };
                try { $p.rename($bak) };
            }
            # 单行 JSONL：必须 :!pretty，否则一条记录会被拆成多行（0.79.1 踩过）。
            try { $p.spurt(to-json(%c, :!pretty) ~ "\n", :append) };
        }
    });
    %c
}

method entries(--> List) { $LOCK.protect({ @!entries.List }) }

method summary(--> Hash) {
    { enabled => $!enabled, path => $!path, entries => @!entries.elems,
      'max-entries' => $!max-entries, 'max-bytes' => $!max-bytes }
}
