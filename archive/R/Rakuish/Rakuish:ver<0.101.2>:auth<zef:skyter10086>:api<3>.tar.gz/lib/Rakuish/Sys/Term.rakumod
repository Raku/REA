# Rakuish::Sys::Term —— 终端尺寸（0.88.0 / V-227）。
#
# 为什么需要它：`COLUMNS` / `LINES` 是 **shell 变量**，不是终端属性。
# bash 只在交互式 shell 里赋值，而且默认**不导出**；导出了也会在用户
# `resize` 之后变成陈旧值。0.87 修完 TTY 之后，多列 `ls` 仍然按 80 列排
# （实测：40 列终端里排出 76 字符宽的行，直接乱序换行）。
#
# 所以尺寸和 TTY 一样，属于「终端事实」，必须由前端**问终端**再下发：
#   POSIX   ioctl(fd, TIOCGWINSZ, &winsize)
#   Windows GetConsoleScreenBufferInfo(stdout)
# 两者都失败（管道 / 重定向 / 无控制台）时返回 0，由调用方决定默认值 ——
# 本模块不猜 80x24，那是渲染策略，不是终端事实。
#
# 已知边界：
#   · 只问 stdout。`-e 'ls' > file` 时 stdout 是文件，返回 0（正确：
#     那时也不该按终端宽度排版）。
#   · 不订阅 SIGWINCH：调用方每格查一次即可（ioctl 是微秒级），
#     不需要自己维护「尺寸变了」的状态机。

use NativeCall;

unit module Rakuish::Sys::Term;

class WinSize is repr('CStruct') {
    has uint16 $.rows;
    has uint16 $.cols;
    has uint16 $.xpixel;
    has uint16 $.ypixel;
}

# TIOCGWINSZ 的数值随内核/平台不同，不能只取 Linux 那个。
my constant TIOCGWINSZ = %(
    linux   => 0x5413,
    darwin  => 0x40087468,
    freebsd => 0x40087468,
    openbsd => 0x40087468,
);

our sub ioctl-winsize(int32 $fd, uint32 $req, WinSize $ws is rw --> int32)
    is native is symbol<ioctl> { * }

# ── Windows ────────────────────────────────────────────────────────
# CONSOLE_SCREEN_BUFFER_INFO 在头文件里是嵌套结构（COORD / SMALL_RECT），
# 但 Raku NativeCall 对**嵌套 CStruct 字段**只给出类型对象而不是实例
# （实测：`$info.window` 得到 `SMALL-RECT` 类型对象，取 `.right` 直接抛
# 「Cannot look up attributes in a type object」）。嵌套布局与展平布局
# 在内存里完全一致（都是 2 字节对齐的连续整数），所以这里按 C 布局
# 展平声明，绕开那个坑：
#   COORD size(4) COORD cursor(4) WORD attrs(2) SMALL_RECT(8) COORD max(4)
class CONSOLE-SCREEN-BUFFER-INFO is repr('CStruct') {
    has int16  $.size-x;
    has int16  $.size-y;
    has int16  $.cursor-x;
    has int16  $.cursor-y;
    has uint16 $.attributes;
    has int16  $.window-left;
    has int16  $.window-top;
    has int16  $.window-right;
    has int16  $.window-bottom;
    has int16  $.max-x;
    has int16  $.max-y;
}

sub GetStdHandle(int32 --> Pointer) is native('kernel32') { * }
sub GetConsoleScreenBufferInfo(Pointer $h, CONSOLE-SCREEN-BUFFER-INFO $info --> int32)
    is native('kernel32') { * }

my constant STD-OUTPUT-HANDLE = -11;

# 0.98.2：stdout 是不是「真终端」。
# Windows 的 `$*OUT.t` 走 CRT `_isatty`，它对**所有字符设备**都返回 True ——
# 重定向到 NUL（Git Bash 的 `>/dev/null`、PowerShell 的 `> $null` 映射到 NUL）
# 会被误判成 TTY，颜色 / 提示符 / live-out 全开（t/10、t/33 的「非 TTY」
# 断言因此在 >/dev/null 下假失败，退出码 5/4 但 TAP 全 ok）。这里用
# GetConsoleScreenBufferInfo 探真控制台：只有真 console 才成功。
# POSIX 的 `.t` 是真 isatty，直接可信。
our sub stdout-is-console(--> Bool) is export {
    if $*DISTRO.is-win {
        my $h = try { GetStdHandle(STD-OUTPUT-HANDLE) };
        return False unless $h.defined;
        my $info = CONSOLE-SCREEN-BUFFER-INFO.new;
        my $ok = try { GetConsoleScreenBufferInfo($h, $info) };
        return ?$ok;
    }
    so try { $*OUT.t }
}

# 返回 %( cols => Int, rows => Int, source => Str )。
# `source` 说明数字是哪来的（诊断用；也让「80 是默认还是真值」可分辨）。
our sub term-size(--> Hash) is export {
    my Int $cols = 0;
    my Int $rows = 0;
    my Str $source = 'none';

    if $*DISTRO.is-win {
        my $h = try { GetStdHandle(STD-OUTPUT-HANDLE) };
        if $h.defined {
            my $info = CONSOLE-SCREEN-BUFFER-INFO.new;
            my $ok = try { GetConsoleScreenBufferInfo($h, $info) };
            if $ok {
                $cols = ($info.window-right - $info.window-left + 1).Int;
                $rows = ($info.window-bottom - $info.window-top + 1).Int;
                $source = 'csbi' if $cols > 0 && $rows > 0;
            }
        }
    }
    else {
        my Str $kern = try { $*KERNEL.name.lc } // 'linux';
        my $req = TIOCGWINSZ{$kern} // TIOCGWINSZ<linux>;
        # 优先 stdout（1），它没有再用 stderr（2）：`cmd 2>log` 时
        # stdout 仍是终端。两个都不是终端就老实返回 0。
        for 1, 2 -> $fd {
            my $ws = WinSize.new;
            my $rc = try { ioctl-winsize($fd, $req, $ws) };
            if $rc.defined && $rc == 0 && $ws.cols > 0 && $ws.rows > 0 {
                $cols = $ws.cols.Int;
                $rows = $ws.rows.Int;
                $source = "ioctl:$fd";
                last;
            }
        }
    }

    # 兜底：环境变量。它可能是陈旧的，但比 0 有用；`source` 会说明来源。
    if $cols <= 0 {
        my $c = try { (%*ENV<COLUMNS> // '').Int };
        my $r = try { (%*ENV<LINES> // '').Int };
        if $c.defined && $c > 0 {
            $cols = $c;
            $source = 'env';
        }
        if $r.defined && $r > 0 { $rows = $r }
    }

    %( cols => $cols, rows => $rows, source => $source );
}
