# Rakuish::Sys::Console —— Windows 控制台码页收口（0.77.0 / ADR-0014）。
#
# 为什么需要它：
#   Windows 控制台的输入/输出码页默认跟随系统区域设置，中文环境是 936（GBK），
#   而 Rakudo 的控制台 I/O 按 UTF-8 解析。两者不一致时：
#     · 输入中文 → 「Malformed UTF-8 near byte d0」；
#     · 行编辑器（Terminal::LineEditor）在读字节时按「凑够一个合法 UTF-8
#       序列」循环，凑不出来就一直等 —— 表现是**敲了没反应、回车也不生效**；
#     · 输出中文 → 终端按 GBK 解释 UTF-8 字节，显示成乱码。
#
#   实测（ConPTY，CP=936）：`$*IN.get` 读「中文」直接抛 Malformed UTF-8；
#   进程内 SetConsoleCP(65001) 之后同一段代码 `got="中文" chars=2`。
#
# 做法：进交互前把码页切到 65001，退出时还原，并把原来的值记下来。
# 只碰「控制台」：没有控制台（管道 / prove6 / 服务）时 GetConsoleCP 返回 0，
# 这里一律不动 —— 管道下本来就按 UTF-8 走，不需要也不应该改任何全局状态。
#
# 边界：
#   · 非 Windows 一律 no-op（POSIX 终端本来就是 UTF-8）；
#   · 只改码页，不改代码页转换函数（CP 65001 下 Rakudo 的 UTF-8 路径才自洽）；
#   · 若进程异常退出没走到 restore，控制台会停在 65001 —— 这比停在 936 更安全
#     （65001 是 Rakudo 期望的编码），故不做额外兜底。

unit module Rakuish::Sys::Console;

use NativeCall;   # is native 需要它；NativeCall 在非 Windows 上加载也安全

# 记下切换前的值，供 restore 用。`0` 表示没切换过 / 没有控制台。
my Int $saved-in  = 0;
my Int $saved-out = 0;
my Bool $changed  = False;

sub SetConsoleCP(uint32 $cp --> int32) is native('kernel32') { * }
sub SetConsoleOutputCP(uint32 $cp --> int32) is native('kernel32') { * }
sub GetConsoleCP(--> uint32) is native('kernel32') { * }
sub GetConsoleOutputCP(--> uint32) is native('kernel32') { * }

# 当前控制台输入码页；0 表示这个进程没有挂控制台（管道 / 重定向 / 服务）。
our sub console-cp(--> Int) is export {
    return 0 unless $*DISTRO.is-win;
    my $cp = try { GetConsoleCP().Int };
    ($cp.defined ?? $cp !! 0);
}

our sub console-output-cp(--> Int) is export {
    return 0 unless $*DISTRO.is-win;
    my $cp = try { GetConsoleOutputCP().Int };
    ($cp.defined ?? $cp !! 0);
}

# 切到 UTF-8。返回 True 表示「这次确实改动了」（调用方据此决定要不要还原）。
# 没控制台 / 已经是 65001 / 非 Windows → 返回 False，调用方什么都不用做。
# `:interactive` 是**硬闸门**：码页是控制台的全局状态，同控制台的父 shell 也看得见。
# 管道 / 脚本跑一次就把用户终端改成 65001 是不礼貌的，所以只有「stdin 是终端」
# 才动手（非交互的 UTF-8 由管道本身保证：Raku 写管道恒为 UTF-8）。
our sub ensure-utf8-console(Bool :$interactive = True --> Bool) is export {
    return False unless $interactive;
    return False unless $*DISTRO.is-win;
    my Int $in = console-cp();
    return False if $in == 0;            # 没控制台，别动全局状态
    return False if $in == 65001 && console-output-cp() == 65001;

    $saved-in  = $in;
    $saved-out = console-output-cp();
    my $ok-in  = try { SetConsoleCP(65001) != 0 };
    my $ok-out = try { SetConsoleOutputCP(65001) != 0 };
    $changed = ($ok-in // False) || ($ok-out // False);
    $changed;
}

# 还原到进入前的码页。没切换过就什么都不做（幂等）。
# 返回类型留空：`--> Nil` 里不能再 `return Nil`（Raku 会报
# "No return arguments allowed when return value Nil is already specified"）。
our sub restore-console() is export {
    return unless $changed;
    return unless $*DISTRO.is-win;
    try { SetConsoleCP($saved-in) if $saved-in > 0 };
    try { SetConsoleOutputCP($saved-out) if $saved-out > 0 };
    $changed = False;
    Nil;
}

# 诊断用：一行说明当前状态（banner / --version 之外的排障入口）。
our sub describe(--> Str) is export {
    return 'console: non-Windows' unless $*DISTRO.is-win;
    my Int $in = console-cp();
    return 'console: (no console)' if $in == 0;
    "console: in=$in out={console-output-cp()}";
}
