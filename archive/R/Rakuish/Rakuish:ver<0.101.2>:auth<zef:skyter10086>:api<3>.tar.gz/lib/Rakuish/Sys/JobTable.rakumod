unit class Rakuish::Sys::JobTable;

# Rakuish::Sys::JobTable —— 父进程侧的后台作业表（0.96.0 / ADR-0031）。
#
# 为什么在父进程：引擎的 stdout 是 JSON 协议流，且会因 Ctrl-C / 崩溃重启；
# 作业表若放引擎里，后台进程会在重启后变成没人能 fg / kill 的孤儿。父进程
# 持有真终端、PosixSpawn 原语和整段会话生命周期，是唯一合适的落点。
#
# 这张表**只管账**，不碰进程本身：
#   · spawn / tcsetpgrp / SIGCONT 在 Sys::Proc 与 Sys::PosixSpawn；
#   · 本类只记 id → (pid, pgid, cmd, state, 时间戳, 退出码)，并调 wait-state
#     把已退出的收掉（不 wait 成 zombie，也不重复 wait 同一个 pid）。
#
# 状态机：running → stopped（Ctrl-Z）→ running（fg/bg）→ done（收割）。
# 收割是**幂等**的：同一个 pid 只 wait 一次，之后状态冻结为 done。

need Rakuish::Sys::PosixSpawn;

has %!jobs;          # Int id => Hash（可变作业记录）
has Int $!next-id = 1;

# 登记一个新作业。返回分配到的 id。
method add(Int :$pid!, Int :$pgid!, Str :$cmd!, Str :$exe! --> Int) {
    my Int $id = $!next-id++;
    %!jobs{$id} = %(
        id      => $id,
        pid     => $pid,
        pgid    => $pgid,
        cmd     => $cmd,
        exe     => $exe,
        state   => 'running',
        exit    => -1,
        sig     => 0,
        since   => now.Str,
    );
    $id;
}

# 非阻塞收割所有仍活着的作业。返回本次**新收割**的 id 列表（供完成通知用）。
# 已 done 的不再 wait —— waitpid 对同一个 pid 第二次调用只会拿到 ECHILD。
method reap(--> List) {
    my @done;
    for %!jobs.kv -> $id, %j {
        next if %j<state> eq 'done';
        my %w = Rakuish::Sys::PosixSpawn::wait-state(%j<pid>.Int);
        given %w<state> {
            when 'stopped' {
                %j<state> = 'stopped';
                %j<stopped-by> = %w<stopped-by>;
            }
            when 'running' {
                %j<state> = 'running';
            }
            when 'exited' | 'signaled' {
                %j<state> = 'done';
                %j<exit>  = %w<exit>;
                %j<sig>   = %w<sig>;
                @done.push($id.Int);
            }
            when 'gone' {
                # 已被别人（ Rakudo 内部 / 外部）回收：标记 done 但不谎报退出码。
                %j<state> = 'done';
                @done.push($id.Int);
            }
        }
    }
    @done.List;
}

# 取一条作业的**副本**（调用方改它不会影响表）。
method get(Int $id --> Hash) {
    my %j = %!jobs{$id}:exists ?? %!jobs{$id}.Hash !! ();
    %j;
}

method state(Int $id --> Str) {
    return 'missing' unless %!jobs{$id}:exists;
    %!jobs{$id}<state>.Str;
}

method exists(Int $id --> Bool) { so %!jobs{$id}:exists }

# 全部作业快照，按 id 升序。先 reap 一次，保证列表状态是当下。
method list(--> List) {
    self.reap;
    %!jobs.keys.map({ %!jobs{$_}.Hash }).sort({ $^a<id> <=> $^b<id> }).List;
}

# 找出某 pid 对应的作业 id（fg/bg 拿到 Result 后反查时用）；找不到返回 0。
method id-of(Int $pid --> Int) {
    for %!jobs.kv -> $id, %j {
        return $id.Int if %j<pid> == $pid;
    }
    0;
}

# 改状态（fg 切前台前拨回 running、bg 恢复后拨回 running）。
method set-state(Int $id, Str $state --> Bool) {
    return False unless %!jobs{$id}:exists;
    %!jobs{$id}<state> = $state;
    True;
}

# 移除一条已完成 / 已被带走的作业。返回被移除的记录（不存在则空 Hash）。
method remove(Int $id --> Hash) {
    return %() unless %!jobs{$id}:exists;
    my %j = %!jobs{$id}.Hash;
    %!jobs{$id}:delete;
    %j;
}

method elems(--> Int) { %!jobs.elems }
