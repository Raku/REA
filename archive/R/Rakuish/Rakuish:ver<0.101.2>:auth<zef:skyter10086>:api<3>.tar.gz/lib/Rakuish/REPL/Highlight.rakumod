unit module Rakuish::REPL::Highlight;

# Rakuish::REPL::Highlight —— 输入行的轻量语法着色（0.74.0 / ADR-0011 §4）。
#
# 纯函数：单行、无状态、不 IO、不解析 AST、不碰 $*OUT。
#
# **唯一硬约束**（ADR-0011 §4.2）：
#   `strip-ansi(highlight-line($s)) eq $s` 必须恒成立。
# 因为行编辑器用 `display-width`（对 buffer 内容算出的显示宽度）定位光标和
# 清屏，而不是用绘制结果。着色只能插入**零宽**转义序列；一旦多出或少掉一个
# 可见字符，输入区就会错位。
#
# 跨行状态（0.97.0）：多行续行时，第一行未闭合的引号（`"..."` / `q[...]`）
# 会让第二行整行处在「字符串内」——但行编辑器每次只把**当前那一行**交给
# highlight-line。set-continuation() 让 Session 把已提交的续行源码传进来，
# highlight-line 据此算出「进入本行时期待的闭合记号」，把本行开头染对色。
# 这是**轻量**跨行：只回答「在哪个引号里、等什么闭合」，不做完整 Raku 词法器
# （q[] 嵌套 / 插值 / heredoc / pod 仍不染，见 MANUAL 边界）。
#
# 依旧刻意不做（不是遗漏）：正则字面量 / heredoc / pod / 插值块里的代码着色。
# 它们要么需要真正的 Raku 词法器，要么在「每次按键重算一行」的热路径上不值。
# 把半截输入染错色比不染更烦人。边界写进 MANUAL。
use Rakuish::REPL::Chrome;

my constant S-RESET   = %CLR<reset>;
my constant S-STRING  = %CLR<green>;
my constant S-COMMENT = %CLR<gray>;
my constant S-NUMBER  = %CLR<yellow>;
my constant S-VAR     = %CLR<cyan>;
my constant S-KEYWORD = %CLR{'b-blue'};
my constant S-ERROR   = %CLR<red>;

# 关键字表：只收「单独出现时几乎一定是关键字」的词。变量有 $/@/%/& 前缀，
# 走变量分支，不会被这里误伤；`say` / `put` 这类看起来像函数名的也收进来，
# 因为 Raku 里它们确实是关键字（不需要括号）。
my constant KEYWORDS = set <
    my our has sub method class role module grammar package
    use need require import export also is does but
    if else elsif unless with without given when default
    for loop while until repeat return last next redo
    die fail try CATCH CONTROL LEAVE ENTER KEEP UNDO
    say put print note warn dd
    True False Nil Any Mu Str Int Num Rat Bool Array Hash Set Bag Mix
    anon state constant subset enum multi proto only
    and or not so xor eq ne lt gt le ge cmp before after
    take gather lazy eager start await react supply whenever emit
    where of returns handles
>;

# 变量名里可能出现的字符（Raku 的 twigil 与二级 sigil 都在这里）。
# 不含 `(` / `[` / `{`：那三种是「$ 后跟表达式」的写法，不该被吞进变量名。
my constant VAR-CHARS = set <
    a b c d e f g h i j k l m n o p q r s t u v w x y z
    A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
    0 1 2 3 4 5 6 7 8 9 _ - * ! ? ^ . : < > +
>;

my sub seg(Str $s, Str $code --> Str) {
    return $s unless $s.chars && $code.chars;
    $code ~ $s ~ S-RESET;
}

# ── 跨行引号 / 括号状态（0.97.0 / 0.100.0）────────────────────────────
# $cont-close = 进入当前行时期待的闭合引号记号（' / " / ] / } / ) 等），
# 空串表示代码态（正常逐 token 染色）。%cont-open = 上一行留下的**未闭合
# 开括号净数**（括号类型 → 张数）——错误态标记用它吸收跨行闭合（V-280），
# 不把「关上一行的括号」误标成落单括号。
my Str $cont-close = '';
my Int %cont-open;

# 扫一段（可能多行的）源码，返回 (结尾未闭合引号, 开括号净数)。
# 只认引号/quote-like 的跨行，不认括号（括号跨行不该把下一行整行染成字符串）。
# 规则与单行染色一致：`\` 跳下一字符；`q[...]` / `qq(...)` 取成对括号；
# 未闭合的引号留存。行尾 `#` 注释后本行忽略。
my sub closing-at-end(Str $src --> List) {
    my @c = $src.comb;
    my Int $n = @c.elems;
    my Int $i = 0;
    my Str $close = '';
    my Int %net;
    my @stack;
    my %pair = ')' => '(', ']' => '[', '}' => '{';
    while $i < $n {
        my $ch = @c[$i];
        if $close ne '' {
            # 引号内：认转义与闭合。q[...] 的同类括号可嵌套（复用 Incomplete
            # 的规则），但这里只需最外层的闭合记号，嵌套深度用计数。
            if $ch eq '\\' { $i += 2; next }
            if $close eq ']' || $close eq ')' || $close eq '}' {
                my %pair2 = ']' => '[', ')' => '(', '}' => '{';
                if $ch eq %pair2{$close} { $i++; next }   # 同类嵌套，加深
            }
            if $ch eq $close { $close = ''; $i++; next }
            $i++;
            next;
        }
        # 代码态
        if $ch eq '#' {
            # 跳到行尾
            $i++ while $i < $n && @c[$i] ne "\n";
            next;
        }
        if $ch eq "'" || $ch eq '"' { $close = $ch; $i++; next }
        # 括号净数（只在代码态；q[...] 的括号同样按代码态计——单行染色
        # 本来也把 q[ 当标识符+括号，保持同一口径）
        if $ch eq any('(', '[', '{') { @stack.push($ch); $i++; next }
        if $ch eq any(')', ']', '}') {
            my Str $want = %pair{$ch};
            if @stack && @stack[*-1] eq $want { @stack.pop }
            elsif @stack { }   # 类型失配：留给当前行的 error-marks 标记
            else { %net{$want}-- if %net{$want}:exists && %net{$want} > 0 }
            $i++;
            next;
        }
        # q[...] / qq(...) / Q{...}：取 q/Q 后紧跟的分隔符
        if $ch eq 'q' || $ch eq 'Q' {
            my Int $j = $i + 1;
            # 跳过 :adverb（如 q:to / qq:x）
            if $j < $n && @c[$j] eq ':' {
                $j++ while $j < $n && @c[$j] ~~ /^<[a..z A..Z]>$/;
            }
            if $j < $n && @c[$j] eq any('[', '(', '{') {
                my %close-of = '[' => ']', '(' => ')', '{' => '}';
                $close = %close-of{@c[$j]};
                $i = $j + 1;
                next;
            }
        }
        $i++;
    }
    # 余下的开括号是跨行净数
    for @stack -> $ch { %net{$ch}++ }
    ($close, %net);
}

# Session 在续行时把已提交源码传进来；提交完成/清空时传空串。
our sub set-continuation(Str $src --> Nil) is export {
    my ($close, $net) = closing-at-end($src);
    $cont-close = $close;
    %cont-open  = $net;
}

# 单行着色。$color 为假时**逐字节原样返回**（不经过任何扫描）。
# :@marks 是 error-marks 给出的 (start, end, kind) 区间列表——与区间相交的
# **段**改用错误色（V-280）。标记只换色、不增删可见字符，宽度不变式不变。
our sub highlight-line(Str $text, Bool :$color = True, :@marks = () --> Str) is export {
    return $text unless $color;
    return $text unless $text.chars;

    my @c = $text.comb;
    my Int $n = @c.elems;
    my Str @out;
    my Int $i = 0;

    # 标记覆盖位图（按字符下标）
    my Bool @cover;
    @cover = False xx $n;
    for @marks -> $m {
        my Int $s = ($m<start> // 0) max 0;
        my Int $e = ($m<end> // $n) min $n;
        @cover[$_] = True for $s ..^ $e;
    }

    # 段级换色：与任一标记区间相交 → 错误色
    my sub seg-at(Str $s, Str $code, Int $start --> Str) {
        return $s unless $s.chars;
        my Bool $hit = False;
        for $start ..^ $start + $s.chars -> $k {
            if @cover[$k] { $hit = True; last }
        }
        $hit ?? seg($s, S-ERROR) !! ($code.chars ?? seg($s, $code) !! $s)
    }

    # 跨行续行：本行开头还在上一行未闭合的引号里。染到闭合记号（含），
    # 之后回到正常扫描。闭合记号和转义规则与 closing-at-end 一致。
    if $cont-close ne '' {
        my Str $close = $cont-close;
        my Int $depth = 1;
        my Int $j = 0;
        while $j < $n {
            my $ch = @c[$j];
            if $ch eq '\\' { $j += 2; next }
            if ($close eq ']' || $close eq ')' || $close eq '}')
               && $ch eq ({ ']' => '[', ')' => '(', '}' => '{' }{$close}) {
                $depth++;
                $j++;
                next;
            }
            if $ch eq $close {
                $depth--;
                $j++;
                last if $depth == 0;
                next;
            }
            $j++;
        }
        # 未闭合（$j >= n）就染到行尾；闭合了就只染到记号为止。
        @out.push(seg-at(@c[0 ..^ $j].join, S-STRING, 0));
        $i = $j;
    }

    while $i < $n {
        my Str $ch = @c[$i];

        # ── 注释：吞到行尾 ──
        if $ch eq '#' {
            @out.push(seg-at(@c[$i ..^ $n].join, S-COMMENT, $i));
            last;
        }

        # ── 字符串：单/双引号；`\` 跳过下一个字符；未闭合就染到行尾 ──
        # 未闭合（用户刚敲了引号）也照样上色，视觉上更像"字符串还开着"。
        if $ch eq "'" || $ch eq '"' {
            my Str $q = $ch;
            my Int $j = $i + 1;
            while $j < $n {
                if @c[$j] eq '\\' { $j += 2; next }
                if @c[$j] eq $q    { $j++; last }
                $j++;
            }
            $j = $n if $j > $n;
            @out.push(seg-at(@c[$i ..^ $j].join, S-STRING, $i));
            $i = $j;
            next;
        }

        # ── 数字：整数 / 小数 / 下划线分组 / 指数 ──
        if $ch ~~ /^<digit>$/ {
            my Int $j = $i + 1;
            $j++ while $j < $n && @c[$j] ~~ /^<[0..9._eE]>$/;
            # 末尾的点不算数字的一部分（`1.` 是方法调用起点，Raku 里 1.abs）
            $j-- while $j > $i + 1 && @c[$j - 1] eq '.';
            @out.push(seg-at(@c[$i ..^ $j].join, S-NUMBER, $i));
            $i = $j;
            next;
        }

        # ── 变量：$foo / @arr / %h / &code / $*CWD / $!attr ──
        if $ch eq any('$', '@', '%', '&') {
            my Int $j = $i + 1;
            $j++ while $j < $n && VAR-CHARS{@c[$j]};
            if $j > $i + 1 {
                @out.push(seg-at(@c[$i ..^ $j].join, S-VAR, $i));
                $i = $j;
                next;
            }
            # 单独的 `$`（如 `$(...)` 的 sigil）原样输出
            @out.push(@cover[$i] ?? seg($ch, S-ERROR) !! $ch);
            $i++;
            next;
        }

        # ── 标识符 / 关键字 ──
        if $ch ~~ /^<[a..z A..Z _]>$/ {
            my Int $j = $i + 1;
            $j++ while $j < $n && (@c[$j] ~~ /^<[\w]>$/ || @c[$j] eq '-');
            my Str $w = @c[$i ..^ $j].join;
            @out.push(seg-at($w, KEYWORDS{$w} ?? S-KEYWORD !! '', $i));
            $i = $j;
            next;
        }

        # ── 其余：逐字符原样输出（含空白、操作符、括号） ──
        @out.push(@cover[$i] ?? seg($ch, S-ERROR) !! $ch);
        $i++;
    }

    @out.join;
}

# ── 语义标记（0.100.0 / ADR-0034 §2.4 / V-280）────────────────────────
# 纯函数（回调注入）：返回 (start, end, kind) 区间列表，kind ∈
# bracket / command / path。默认回调恒「已知 / 存在」→ 零标记。
#
# 三个探测器：
#   bracket —— 括号失配 / 落单闭合（跳过字符串与注释）。行尾未闭合的
#              开括号是**续行常态**，不标；跨行闭合由 %cont-open 吸收。
#   command —— shell 形（无未引号元字符）行的首词，不在已知命令集合
#              （COMMANDS / 注册表 / 关键字 / PATH）→ 标记。
#   path    —— shell 形行里形如路径的参数（./ ../ ~/ / 或含 /）不存在
#              → 标记。引号内的路径不标（词法器看不到）。
#
# 残余误报（ADR-0034 §2.4 记账）：用户自定义的无括号 listop 形调用
# 会被 command 误标；精确判定需要引擎侧名字可见性，列入后续。
our sub error-marks(Str $text, :&known-command, :&path-exists --> List) is export {
    my &known = &known-command // sub (Str $w --> Bool) { True };
    my &exists = &path-exists  // sub (Str $w --> Bool) { True };

    my @marks;
    my @c = $text.comb;
    my Int $n = @c.elems;
    return () unless $n;

    my @stack;              # (char => pos) 开括号栈
    my %pair = ')' => '(', ']' => '[', '}' => '{';
    my %cont = %cont-open;  # 跨行未闭合净数（可变副本）

    my Bool $meta = False;          # 未引号元字符 → Raku 表达式形态
    my Bool $in-comment = False;
    my Str  $quote = '';
    my Int  $quote-start = 0;

    # 词收集：代码态的裸词（标识符字符 + '-'）与路径形 token。
    # 元素用 Hash（itemized，不会被 slurpy push 扁平化——List 元组会）。
    my @words;
    my Int $ws = -1;
    my Str $buf = '';

    my sub flush-word() {
        return unless $ws >= 0;
        my Bool $pl = $buf.contains('/') || $buf.starts-with('~')
                      || $buf.starts-with('.');
        @words.push(%(start => $ws, word => $buf, path => $pl));
        $ws = -1; $buf = '';
    }

    my Int $i = 0;
    while $i < $n {
        my Str $ch = @c[$i];
        if $in-comment { $i++; next }
        if $quote ne '' {
            if $ch eq '\\' { $i += 2; next }
            if $ch eq $quote { $quote = ''; }
            $i++;
            next;
        }
        if $ch eq '#' { flush-word(); $in-comment = True; $i++; next }
        if $ch eq "'" || $ch eq '"' {
            flush-word();
            $quote = $ch; $quote-start = $i; $i++;
            next;
        }
        if $ch eq any('$', '@', '%', '&', '(', ')', '[', ']', '{', '}', ';', '|', '<', '>') {
            $meta = True;
        }
        if $ch eq any('(', '[', '{') {
            flush-word();
            @stack.push(($ch, $i));
            $i++;
            next;
        }
        if $ch eq any(')', ']', '}') {
            flush-word();
            my Str $want = %pair{$ch};
            if @stack && @stack[*-1][0] eq $want {
                @stack.pop;
            }
            elsif @stack {
                # 类型失配：标这个闭合（开括号留栈上等真正的闭合）
                @marks.push(%(start => $i, end => $i + 1, kind => 'bracket'));
            }
            elsif (%cont{$want} // 0) > 0 {
                %cont{$want}--;    # 关上一行的开括号，不标
            }
            else {
                @marks.push(%(start => $i, end => $i + 1, kind => 'bracket'));
            }
            $i++;
            next;
        }
        # 词字符：标识符 / 路径 token
        if $ch ~~ /^<[a..z A..Z 0..9 _ . ~ \/ -]>$/ {
            $ws = $i if $ws < 0;
            $buf ~= $ch;
            $i++;
            next;
        }
        flush-word();
        $i++;
    }
    flush-word();

    # 行尾未闭合的开括号是续行常态，不标（ADR-0034 §2.4）

    # 命令 / 路径探测：只在 shell 形输入上（无未引号元字符）
    unless $meta {
        if @words.elems {
            my %w0 = @words[0];
            my Int $ws0 = %w0<start>;
            my Str $w0  = %w0<word>;
            if %w0<path> {
                # 首词即路径形（./foo ~/x dir/y）：按存在性标记
                my Bool $e = (try { so &exists($w0) }) // False;
                @marks.push(%(start => $ws0, end => $ws0 + $w0.chars,
                              kind => 'path')) unless $e;
            }
            elsif $w0.chars && !KEYWORDS{$w0} && !&known($w0) {
                @marks.push(%(start => $ws0, end => $ws0 + $w0.chars,
                              kind => 'command'));
            }
            # 其余位置的路径形参数
            for @words.skip(1) -> %w {
                next unless %w<path>;
                my Str $w1 = %w<word>;
                next if $w1.starts-with('-');
                my Bool $e = (try { so &exists($w1) }) // False;
                @marks.push(%(start => %w<start>, end => %w<start> + $w1.chars,
                              kind => 'path')) unless $e;
            }
        }
    }

    @marks.List;
}
