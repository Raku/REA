# Rakuish 交接文档

- **版本**：`0.121.0`（API v3）
- **日期**：2026-11-23
- **面向**：接手开发者 / 下一个 AI
- **先读**：[`docs/MANUAL.md`](docs/MANUAL.md) → 本文 → [`SPEC.md`](SPEC.md) → [`docs/ADR-0001-raku-native.md`](docs/ADR-0001-raku-native.md) → ~~ADR-0002（Agent 服务，**已撤销**）~~ → [`docs/ADR-0019-local-full-privilege-shell.md`](docs/ADR-0019-local-full-privilege-shell.md) → [`docs/ADR-0003-repl-experience.md`](docs/ADR-0003-repl-experience.md) → [`docs/ADR-0004-cursor-worker.md`](docs/ADR-0004-cursor-worker.md) → [`docs/ADR-0005-data-workbench.md`](docs/ADR-0005-data-workbench.md) → [`docs/ADR-0006-data-profile.md`](docs/ADR-0006-data-profile.md) → [`docs/ADR-0007-tty-passthrough.md`](docs/ADR-0007-tty-passthrough.md)

---

## 1. 一句话

Rakuish 是一个 **Raku 原生的命令、脚本与数据环境**：

- REPL 里可以写 Raku，也可以用 shell 习惯的 `cd/ls/read/rm/...`；
- 系统操作收敛到会话级 `Sys`，外部命令只接 argv；
- 数据能力用 `Table` + DuckDB/SQLite，不把一切变成文本；
- **本地、全权限**：没有沙箱、没有 token、没有权限闸门（ADR-0019）；
- 每次操作一条结构化审计（用户硬约束，与安全壳无关）。

**它不是 bash，不是 POSIX，不是“Raku 写的 shell 模拟器”，也不再是 Agent 服务。**
凡是看起来像“再补一个 bash 语义”的需求，先回到 ADR-0001。

---

## 2. 当前基线

```bash
git clone <repo>
cd rakuish
raku -Ilib t/01-sys-fs.t     # 单文件
bash tools/run-all.sh        # Linux / WSL 全套（首选入口）
bash tools/ci.sh             # 平台无关 CI 入口 → tmp/ci-report.txt
zef install . --force-install
rakuish --version            # 0.121.0
git tag --list 'v0.*'        # v0.80.0 / v0.80.1 … v0.121.0
```

无 TTY 的构建机：`Terminal::API` 上游测试会中断 `zef install .`，按
`docs/CI.md` §2.1 先 `--force-test --force-install` 装依赖再装本包。

| 项 | 当前值 |
|---|---|
| Windows 测试 | 73 个文件 / 3270 条断言（t/43 在该平台 skip 12 条，t/56 / t/59 整段 skip；`prove6` 在**去掉 Git `usr/bin` 的 PATH** 上也复跑过，防夹具依赖 Git 自带 exe） |
| Linux 测试 | WSL `bash tools/run-all.sh` 73 文件 / 3270 条断言，`not ok` = 0、问题总数 0（t/56 / t/59 真 PTY 全绿） |
| `META6.api` | 3 |
| 模块 provides | 44 |
| 入口 | `bin/rakuish`（唯一） |
| 可选依赖 | `DB::DuckDB:ver<1.2.2+>`（依赖 `Alien::Libduckdb:ver<1.2.1+>`）、`DB::SQLite` |
| 核心依赖 | `JSON::Fast`、`Terminal::LineEditor`、`Terminal::API` |
| 最新 tag | `v0.121.0`（V-317 / ADR-0045：Arrow 写侧**多批与流式** —— 写入器拆成 `IpWriter.start / add-batch / finish`，sink 可为 `Buf` 或文件句柄：`write-ipc(:batch-size)` 多批、`write-ipc-stream(行迭代器或 Table 迭代器, $path)` 边拉边写；schema 首批推断后固定，逐列核类型防 `"abc".Int == 0` 的静默脏数据；落盘先写 `.part` 再 rename，失败不留半截；新增 `ipc-batch-count`、`save-data :batch-size`。5 万行单批 2.65 s vs 10 批 2.70 s；50 万行流式 100 批 23.9 s / 14.9 MB，pyarrow 26 全对。t/77 46 条。上一版 0.120.1 是 Arrow 读侧按类型分流 V-316） |
| CI | `tools/ci.sh` 双平台实测；**云端自动触发未启用**（`docs/CI.md`） |

**安装时如果 precomp 或 `rakuish.exe` 被锁**：先结束残留 `rakuish` / `rakudo`
进程；Windows 上测试/交互进程可能持有 precomp 内存映射。不是代码 bug。

---

## 3. 架构地图

```text
bin/rakuish
  ├─ REPL（TTY）──> Rakuish::Eval::Proxy ──协议──> 子进程 Rakuish::Eval::Server
  │                  │                             └─ Rakuish::REPL::Session（真的那个）
  │                  │                                ├─ 输入分类（! / Shell 薄层 / Raku）
  │                  │                                ├─ 当前格 EVAL + 顶层状态扫描
  │                  │                                ├─ rc / prompt / set -o（0.90）
  │                  │                                └─ 渲染 / 历史 / 配置 / hooks
  │                  ├─ 行编辑 / prompt / banner / 补全 UI
  │                  ├─ Kernel.execute（Policy + 审计）
  │                  ├─ `!` 的 chunk 帧 → 终端（0.90，ADR-0024）
  │                  └─ `! --tty` 的真实执行（父进程持终端）
  ├─ -e / 脚本 / 管道 ──> 进程内 Rakuish::REPL::Session（整份源码一个 cell）
  └─ 引擎崩溃 ──> Eval::Proxy 重启子进程 + 从快照恢复 + 重跑 rc + 如实报告

lib/Rakuish/
  Sys                  会话 cwd/env/root + resolve + try-op + jobs
  Sys::FS              文件 API（IO::Path）
  Sys::Proc            argv-only 进程 API（Proc::Async 真流式）
  Result               Result/Stat/WriteResult/异常族 + render 门面
  Result::Renderer     text/json/markdown
  Data                  open/save + JSON/CSV
  Data::Table           结构化值 + where/select/join/schema/types
  Data::Engine          引擎角色（query/execute/tx/tables/schema）
  Data::Engine::DuckDB  可选 DuckDB 适配器
  Data::Engine::SQLite  可选 SQLite 适配器
  Data::Pager           explore 分页
  DSL                   普通 sub + bind-session + cmd 桥
  Command               Command/CommandSpec/Registry
   Kernel                前端唯一入口：Request / Policy / execute（0.76，ADR-0013）
   Display               内容级展示包：text/markdown/json + 协商（0.78，ADR-0016）
   Audit                 统一审计：字段白名单 / seq / 落盘 / 轮转（0.80，ADR-0018）
   Eval                  引擎子进程父侧客户端：协议 / 崩溃检测 / 重启（0.83，ADR-0021）
   Eval::Server          引擎子进程入口（它才是完整 Session 的宿主）
   Eval::Proxy           冒充 REPL::Session，让 Kernel 与审计不感知进程边界
   Snapshot              会话快照：可序列化判定 / 捕获 / 原子落盘（0.84，ADR-0022）
  REPL::Chrome          banner/prompt/颜色/耗时格式（纯展示，0.62）
  REPL::Session         会话、扫描器、渲染、配置、_ / Out
  REPL::Shell           日常命令薄层
  Incomplete            多行续行

（0.81.0 / ADR-0019 删除：Sandbox、Agent、Agent::Server、Agent::Worker、
  bin/rakuish-agent。Agent 代码在 v0.80.4 tag 里，需要时按 ADR-0019 §5 取回。）
```

### 3.1 四条边界

1. **所有文件/进程操作必须过 `Sys`**。REPL 对象、快捷键、Shell 薄层都不能
   绕过 `Sys` 直接 `spurt` / `Proc::Async`。
   **理由不是安全**（0.81.0 起没有沙箱），而是三件事：统一审计能落在同一处、
   `Result` 语义一致、`root` 边界与超时/输出上限只有一套实现。
   0.76 起再加一层：**前端只能调 `Kernel.execute(Request)`**，不直接调
   `Session.eval-line`（V-182）；`Policy` 由内核强制执行、前端只能收窄（V-183）。
   0.78 起 `op` 通道只开 `capabilities`（不碰文件/进程/源码），其余 501 ——
   Agent 删除后这个通道只是 `Kernel` 的自描述接口，**没有第二个前端在用**。
2. **外部命令只接 argv**，永不拼 shell 字符串。
3. ~~Agent 只接结构化 op~~ —— **0.81.0 撤销**（ADR-0019）。现在**只有本机**
   REPL / `-e` / 脚本，Raku 源码直接 `EVAL`，`!` 直接起进程，没有
   `allow-exec` / `allowlist` / `allow-code-exec` / `allow-sql` 任何开关（V-198）。
   **不要再加回「默认关闭 + 开关打开」的形态**：那等于承认「打开就安全」，
   是 0.79–0.80 反复否掉的牌子。
4. **显示分两层，不要混**（0.78）：`Display::Bundle` 管**内容**
   （text 必有 + 可选 markdown/json），`Session.render` 管**装饰**
   （颜色、`Out[n]`、`COLUMNS` 分列）。颜色塞进 bundle 会让它退化成 TTY 专用；
   `Out[n]` 塞进去会让 Agent 收到终端标签。
5. **审计只有一个写入函数**（0.80）：`Rakuish::Audit.record`。Kernel 走
   `LEAVE`（正常/拒绝/异常都记）。0.81.0 起 Agent 删除，写入点只剩这一个 ——
   所以「每次操作一条」比之前**更容易**保证，不是更难。
   `Audit`（安全）/ `log-line`（人读抄本）/ `trail`（调试）/`display`（内容）
   四者**不合并**（V-196）。

### 3.2 求值模型（重要）

REPL 不重放历史。每格：

1. 扫描当前源码的顶层 `my/our/state`，转成 `%STATE` 别名；
2. 顶层 `class` / `role` / `grammar` 统一改写成 `my class` / `my role` /
   `my grammar`，避免 `EVAL` 把包装进 `GLOBAL` 导致重放时 Redeclaration；
3. 缓存纯 `sub` / `use` / `class` / `role` / `grammar` 声明格；类型声明
   **原位替换**缓存以保持继承/组合的依赖顺序，失败时回滚；含 phaser 或
   混有其它语句的格不缓存；
4. 只 EVAL **当前格 + 纯声明 prelude**，绝不重放执行语句；
5. 成功值进入 `@!out`，供 `_` / `Out[n]`。

不要通过“重放整份历史”来修任何状态问题，会重新引入 P0-1 的副作用问题。
持久的是**名字可见性，不是类型对象身份**（SPEC V-153）。

---

## 4. 从 v1 到 v3：为什么换架构

### 4.1 v1：Raku eval 环境

最早仓库是 `raku-eval`，后来改名 Rakuish。v1 的结构大致是：

- `RakuEval::Incomplete`：多行输入判定；
- `Rakuish::Platform`：平台差异隔离；
- `Rakuish::Eval`：求值 + `Out[n]` 渲染；
- `Rakuish::Loop`：交互循环、历史、补全、`%magic`；
- `Rakuish::Slow`：慢档/真 `sh` 后端；
- 后续加入 shell 引擎、后台 daemon、JSON server、`.repl` 重放、配置/alias。

v1 的产品形态是 **IPython 式 Raku 环境 + shell 逃生口**：
`!` 走 shell，反引号捕获，`%run/%load/%time/%config` 等 magic，
auto-shell 会把“看起来像命令”的输入交给 shell。

**贡献**：`Out[n]`、行编辑/补全、历史、配置、`%time`、脚本运行这些交互体验
方向是正确的；问题在于它逐渐长成“两套语言 + 两套执行栈”。

### 4.2 v2：API v2 的 bash 子集

v2 是 v1 的“新栈”：

```text
Parser → AST → Executor → Builtin
```

- 用 Raku 实现 bash 子集：`$VAR`、`|`、`>`、`&&`、`test`、`export`、
  heredoc、glob、`[[ ]]` 等；
- 独立 shell 引擎进程 `bin/rakuish-sh`，真 `bash` / `native` 双后端；
- `%magic` 第二套命令语言；
- 后台 daemon、JSON batch / TCP server；
- 自建 `Platform::Path` / `Stat`；
- v2 与 v1 legacy 栈可切换，长期并存。

**为什么失败**：不是差几个 bug，而是底座选择错误。v2 审计列出的 7 个 P0
（`rm -r`、`test -L`、`ls -la`、管道挂死、TCP 无认证、双栈漂移等）是
“自建 bash 语义”的必然产物：

- 自建 Path 丢 `IO::Path` 能力；
- 自建 Lexer 要自己解析 flag；
- 用临时文件模拟管道，挂死/撑盘；
- shell 字符串协议 + 手写 socket，认证/编码都难；
- 两套语言、两套执行栈长期漂移。

**贡献**：v2 的 `Result` 化、错误展示、配置/alias、补全、JSON 传输思路被保留；
但它不应被“修好”，而应被删除。

### 4.3 v3：Raku 原生（当前）

0.29–0.34 逐步落地，0.34.0 删除 v2：

- `Rakuish::Sys` 会话级系统出口；
- `IO::Path` 替代自建 Path；
- argv-only 进程 API；
- `Result` 类型 + 多格式渲染；
- DSL / Command 注册表；
- 无 magic 的 REPL；
- ~~Agent 结构化 op + Sandbox~~（0.81.0 删除，见 ADR-0019）；
- 0.39 以后加数据层、DuckDB/SQLite、`explore`、配置/hooks。

**关键提交**（Git 历史可查）：

- `6c04f15` 建仓，`c547827` Incomplete；
- `71860a9` v1 真 sh Slow 后端；
- `29de8c4` API v2 新栈接管；
- `278b4ee` 删除 v2，0.34.0；
- `3ee1980` / `360eb38` / `3275149` / `dfd1cb6` v3 Phase 1–4；
- 0.39–0.61 见 `git log --oneline`。

---

## 5. 现在这套架构是最优的吗？

### 5.1 对“本地全权限 shell + 数据环境”这个目标：是正确底座

**优点**：

- 单一语义：输入落到哪一层明确，没有 auto-shell / magic 歧义；
- `Sys` 是唯一出口，审计与 `Result` 语义都能集中在一处；
- `IO::Path` / `Proc::Async` 直接使用 Raku/OS 能力，不自建半套；
- 结构化 Result / Table 对交互与脚本都友好；
- 数据层与系统层分离，DuckDB/SQLite 可选，不拖核心安装。

### 5.2 但它不是“绝对最优”

以下是下一任接手者应该知道的真实弱点：

1. **REPL 状态扫描器是权宜方案**
   - 顶层 `my/our/state` 与纯声明格（含 `class/role/grammar`）可跨格；混合格、
     嵌套块内声明、含 phaser 的声明仍不持久。
   - 类型声明每格前置重放，生成**新** type object：对象身份不跨格，`.^name`
     带外层包名。持久编译器/常驻 cell 服务是更彻底的方案，但工程量大。
2. **Shell 薄层是影子 API**
   - `ls/read/...` 在 `Sys` 之上又有一套参数解析；要持续防止两套语义漂移。
   - 新命令应先问：这是 `Sys` API，还是 Shell 观感？不要两边都加。
   - **命令名登记已收口**（0.77.0 / V-188 / ADR-0015 §2）：`COMMAND-GROUPS`
     是唯一声明处，`COMMANDS` / `SHELL-COMMANDS` / 帮助索引 / 补全 / 渲染层的
     op 名单都由它生成。新增命令从 ~9 处降到 4 处（组声明 / `usage()` 文案 /
     `OPTIONS`（仅当真有 flag）/ `given` 分发体）。
   - 仍手写的两处由 `t/37` 双向守着：`usage()` 每个名字都要有文案，
     `given` 分发表里不许有表外分支、表里每个名字都要有分支。
   - 历史教训（别再犯）：`hint` / `plugin` 有完整用法、`help hint` 可查，
     却从不在 `COMMANDS` 里 —— Tab 一直补不出来。任何「新命令要手工登记 N 处」
     的设计都会重演这个错误。
3. **记账已收口，但只到 history 这一层**（0.77.0 / V-189 / ADR-0015 §3）
   - `eval-line` 已拆成 `!eval-line-body`（执行）+ `!finish`（记账），会话级命令
     与失败的 Raku 格都进 `history`，`!!` / `!n` 与 `history` 编号同源。
   - **`@!out` / `$!index` 仍留在原来的三处**（`!eval-raku` / `!` 执行 /
     Shell 薄层）：格号语义与「失败格不占 `Out[n]`」的既有契约绑在一起，
     动它会让编号全面漂移。想让「记账」也覆盖 `@!out` 时，必须同时改
     `t/07` 的契约断言，而不是悄悄挪写点。
   - 0.75 的会话日志仍挂在入口主循环（唯一同时拿到输入/结果/渲染文本的位置），
     等 `DisplayBundle` 落地再决定是否并入 `!finish`。
4. **超时不是 kill**：`exec` 的底层超时会真的终止子进程（V-148），但 Raku
   线程无法强杀 —— 纯文件 I/O 被判超时后仍在后台跑完（结果丢弃）。
   别把「响应及时」当成「已 kill」。0.81.0 删掉 Agent 后，
   「deadline 回 504 / worker 硬取消」那两套都随之删除（ADR-0002 / ADR-0004）。
5. **`root` 是防误操作，不是安全隔离**（0.81.0 改名定性）
   - canonical symlink 校验能挡「手滑越出工作目录」，挡不住任何有意的访问；
     同一用户能做的事，Rakuish 里都能做 —— 这是设计目标（V-199）。
   - 异常类 `X::Rakuish::Sandbox` 已改名 `X::Rakuish::Bound`；见到旧名说明
     读的是 0.80.x 及更早的文档。
6. **Table / query() 仍以物化为主**（0.67 提供 Cursor 旁路）
   - `query(:max-rows)` 把 LIMIT 下推进 SQL、`batches` 惰性分批、
     渲染有 `:max-rows` 上限，大结果不再一次拼成巨型字符串 / JSON。
   - `query()` 与 `Table` 仍是全量行 Hash；0.67 起需要惰性执行时改用
     `Engine.cursor()`（DuckDB `:stream` / SQLite 逐行，V-158 / ADR-0004）。
     两者并存，不要把 `Table.batches` 当成惰性查询。
   - Parquet 是显式授权的外部访问例外（V-152），别把它当默认能力。
7. ~~常驻服务~~ —— **0.81.0 删除**（ADR-0019）。Rakuish 没有守护进程、
   没有监听端口、没有客户端连接；唯一形态是一个前台进程。
   需要远程/并发调用时按 ADR-0019 §5 重开，不要在应用层再长一套。
   - 仍是本地可信服务：无开机自启、无跨进程 Engine 共享、无速率限制。

### 5.3 建议的方向

- **保留 v3 底座**，不要回退到 bash/parser；
- 0.67 已交付 **流式 Cursor / 连接级 worker 硬取消**（ADR-0004），
  0.68 已交付 **CSV 受控外部读写 / Engine 元数据补全**（ADR-0005），
  0.69 已交付 **CSV 方言 / describe 值 API / 补全增强**（ADR-0006），
  0.66 已交付 Vi/hints / 插件；**SQL AST 级补全与可恢复游标已明确不做**，
  剩余未排期方向只有 CSV 方言精细控制、SQL 元数据 `describe` 的扩展统计，
  不是再加 shell flag；
- REPL 若要彻底解决状态，做 **持久求值器**，而不是历史重放；
- 不要为了“像 shell”恢复 `%magic` 或 auto-shell。

---

## 6. v1/v2 中值得保留的东西

| 来自 | 东西 | 现状 |
|---|---|---|
| v1 | `Out[n]` / 历史 | 已完成，且补了 `_` |
| v1 | 行编辑 / Tab 补全 / 历史文件 | 已接 `Terminal::LineEditor` |
| v1 | 配置 / alias / 启动配置 | 已做 `config`/`alias`/`hook` |
| v1 | `%time` 计时 | 变成 `timed` / `bench` / `perf` + prompt 每格耗时（0.62），不恢复 magic |
| v1 | `%load` 载入文件 | 用 Raku `EVALFILE` / 脚本；未做专用命令 |
| v1/v2 | 错误展示 / 结果渲染 | 收敛到 `Result.render` |
| v2 | `Result` 化、JSON 传输 | 保留并重做 |
| v2 | Shell 日常观感 | 保留为薄层，但不接 bash 语义 |

**不要复活**：

- `Parser` / `Pipeline` / 临时文件管道；
- 自建 `Platform::Path` / `Stat`；
- 独立 shell 引擎 / daemon / shell 字符串协议；
- `%magic` / auto-shell / 反引号 shellq；
- v1/v2 双栈并存；
- 无界历史重放。

---

## 7. 必须守住的契约

1. **入口不猜**：`!` 与 Raku 表达式由用户显式选择；没有隐藏的第三层。
2. **argv-only**：外部命令不经过 shell。
3. **会话级 cwd/env**：不 `chdir`、不改 `%*ENV`。
4. **一条出口**：所有文件/进程操作过 `Sys`。
5. ~~Agent 无 eval~~ —— **0.81.0 撤销**（ADR-0019）：只有本机，源码直接 EVAL、
   `!` 直接起进程。**不要加回任何「默认关闭 + 开关」的权限闸门**（V-198）。
6. **Result 双形态**：结构化 `value/out` + text 渲染缓存。
7. **不重放历史副作用**。
8. **Shell 薄层不绕过 `Sys`**（审计与 `Result` 语义靠这条成立，不是为了安全）。

违反其中任何一条，先停下来改设计，不要用测试“修绿”。

---

## 8. 文件与职责

| 文件 | 职责 | 改动注意 |
|---|---|---|
| `bin/rakuish` | 入口、REPL、`-e`、脚本、hooks | 版本常量与 META 同步 |
| `Sys.rakumod` | cwd/env/root/resolve/try-op/jobs | 任何路径操作过 resolve；中间 symlink 逐段 readlink 校验（V-157）；Windows 用 `all-drives`；`root` 只做防误操作（V-199） |
| `Sys/FS.rakumod` | 文件 API | 读/写/stat 抛异常；rm/cp 返回 Result |
| `Sys/Proc.rakumod` | argv 进程 / `tty-exec` 直通 / `pty-exec` 捕获 | `Proc::Async.start(:cwd,:ENV)`；直通用 `bind-stdio`、无超时；PTY 用 `:pty`、可超时/截断 |
| `Result.rakumod` | 类型 + 异常 | 不破坏 render 契约 |
| `Result/Renderer` | text/json/markdown | 稳定键序、路径 `/` |
| `Data.rakumod` | JSON/CSV/Parquet open/save | 只经 Sys；Parquet/CSV 外部读写需显式 `:allow-external` |
| `Data/Table.rakumod` | Table 值/schema/types/describe/batches | 单行 Hash 归一化、类型保留 |
| `Data/Cursor.rakumod` | 惰性游标（batches/rows/take/close） | 显式 Iterator + fetch；不嵌套 gather |
| `Data/CsvOptions.rakumod` | CSV 方言白名单 | 纯函数；读用 ? 绑定、写只拼校验过的字面量 |
| `Data/Engine*` | 数据库适配 | 可选依赖、只读默认、超时、`cursor()`、`describe()`、CSV/Parquet 外部读写 |
| `Data/Pager.rakumod` | 分页 | 非 TTY 返回文本 |
| `DSL.rakumod` | 短 sub / cmd | 不引第二套语法 |
| `REPL/Chrome.rakumod` | banner/prompt/颜色/耗时格式 | 纯展示，不求值、不解析输入 |
| `REPL/Keymap.rakumod` | Vi/Helix 模态语义 + 行编辑器子类 | 只绑已有 edit action；构造失败自动回退 |
| `REPL/Hints.rakumod` | 上下文提示 | 纯函数；管道下不输出 |
| `REPL/Plugins.rakumod` | 显式本地 Raku 插件 | 默认关闭；加载即执行本地代码，不是沙箱 |
| `REPL/SqlComplete.rakumod` | SQL 上下文补全 | 纯函数；别名/前缀列/大小写；异常退化成空补全 |
| `REPL/Complete.rakumod` | 补全/建议纯函数（0.100） | 公共前缀、子序列模糊回退、建议后缀；无状态 |
| `REPL/Session.rakumod` | 输入分类/EVAL/渲染 | 不重放历史；顶层类型词法化；`need Rakuish::Data` 避免同名导出覆盖（V-165） |
| `REPL/Shell.rakumod` | shell 观感 | 只翻译成 Sys；文件名参数只展开 `* ?` |
| `Audit.rakumod` | 统一审计账本 | 字段白名单；源码只记指纹 + 字节数；落盘失败不能弄崩业务 |
| `Incomplete.rakumod` | 续行 | 纯逻辑 |

测试：

- `t/01` FS、`t/02` Sys、`t/03` Proc、`t/04` DSL/Command；
- `t/05` REPL、`t/07` 入口；
- `t/08` 渲染、`t/09` 展示、`t/10` Shell、`t/11` Table；
- `t/12` DuckDB、`t/13` SQLite、`t/14` explore、`t/15` 界面与计时、
  `t/17` Parquet / 大结果、
  `t/18` 类型声明跨格 / glob 转义与嵌套 brace、
  `t/19` Vi/Helix 模式 / hints / 插件、
  `t/20` 流式 Cursor、
  `t/22` CSV 受控外部读写、`t/23` SQL 上下文补全、
  `t/24` CSV 方言 / V-165 名字解析、`t/25` describe 值 API / 补全增强、
  `t/26` 交互式子进程 TTY 直通（非 TTY 守卫 / 元选项 / 真 PTY 集成）、
  `t/27` Ctrl-C 中断输入（值 API + 真 PTY）、
  `t/28` PTY 捕获 / 超时 / 截断、
  `t/29` PTY 能力探测失败路径 / 先剥离后截断 / 结果标记、
  `t/30` `tty-exec` 期间 SIGINT 归属契约（真 controlling terminal + `\x03`，
  Windows skip）、
  `t/32` 进程组交接（`posix_spawnp` SETPGROUP，Windows skip）、
  `t/33` 结果着色与输入行高亮的纯文本等价 / 非 TTY 零 ANSI、
  `t/34` 用户层命令（选项补全 / doc 内省 / 目录栈 / 会话日志）与 P0 订正、
  `t/35` 内核入口与策略（双路径逐字段对账 / 拒绝不推进 `Out[n]`）、
  `t/36` Windows 控制台码页（非交互不改 / 还原幂等 / 管道中文）、
  `t/37` 命令名单一数据源与输入序/格号分离（双向一致 / `!!` 语义）、
  `t/38` 展示包（格式协商 / 降级如实 / 内容与装饰分界）、
  `t/39` 流式分帧与取消（帧顺序 / 超限 / cancel 三条边界 / 传输层）、
  `t/40` 统一审计（字段白名单 / 每次操作一条 / 早返回回归 / 双前端对账 / 落盘）、
  `t/31` `tty-exec` 交接期 termios 快照恢复（canonical 基线 PTY，
  Windows 只跑 2 条退化断言）；
  `t/18` 另含 0.69.1 失败格 stderr 回归；
- `t/51` provides/版本、`t/52` 全模块加载。
- `tools/ci.sh`（可复核的 CI 入口）、`docs/CI.md`（CI 状态与启用配方）、
  `docs/ADR-INDEX.md`（36 份 ADR 的仓库内决策索引与品类变更登记）
  均为 0.80.1 新增；**云端自动触发未启用**，见 `docs/CI.md`。

---

## 9. 开发流程

```bash
# 1. 改代码
# 2. 单测
raku -Ilib t/xx.t
# 3. 全量
bash tools/run-all.sh
bash tools/ci.sh             # 平台无关；报告写进提交说明
# 4. 安装验证
zef install . --force-install
# 5. 版本
# META6.json + bin/rakuish + bin/rakuish-agent
# 6. 文档三联
# README / MANUAL / SPEC / ROADMAP / HANDOFF
# 7. 提交
```

规则：

- 新模块必须加入 `META6.provides`（`t/51`）。
- 新能力必须有正向 + 反向断言。
- `lib/` 改动后跑全模块 `require`（`t/52`）。
- 版本常量与 `META6` 同步；`t/51` 守护。
- **推送前跑 `bash tools/ci.sh`**（0.80.1），把 `files/assertions/result`
  写进提交说明；只看退出码或只数 `not ok` 都会漏判，见 `docs/CI.md` §3。
- **每个发布版本打 annotated tag**（0.80.1 起）：`git tag -a v0.x.y -m ...`，
  推送后用 `git ls-remote --tags origin` 核对。0.7x 整段漏打是 0.80.1 补的账，
  最新 tag 曾长期停在 `v0.26.0`。
- **临时夹具必须在测试开头清理**（0.79.1）：`$*PID` 会复用、上次测试中断时
  结尾清理根本不执行；`Sandbox.audit` 是 `:append`，残留两行就能让「2 行」
  变成 4 行（只在 `zef install` 里暴露，`prove6` 反而全绿）。
- **涉及 Failure 的修复要用压力循环 + `$*ERR` 重定向验收**（0.79.1）：
  unhandled Failure 在 DESTROY（GC 时）才吐，单次调用看不到是运气，
  不是修好了。`t/33` 的做法可直接抄。
- Windows/Linux 都跑 `tools/run-all.sh`；Linux/WSL 另跑
  `python3 tools/tty-check.py` 做真 TTY 交互自检；Windows 的**控制台模式**
  （termios 对应物）不在 `prove6` 覆盖范围内，跑
  `python3 tools/tty-termios-win.py`（真 ConPTY，退出码 0/1/2）。

---

## 10. 已知缺口与风险

| 项 | 现状 | 风险 |
|---|---|---|
| ~~Agent OS 级硬取消~~ | 已随 Agent 线删除（0.81.0） | 需要硬取消时按 ADR-0019 §5 重开；`exec` 自身的超时仍会终止直接子进程（V-148） |
| 多客户端 daemon | 已随 Agent 线删除（0.81.0） | 现在没有任何监听端口；需要远程执行时按 ADR-0019 §5 重开 |
| ~~worker 模式~~ | 0.67 的 `--worker` 已删除（0.81.0）；0.83 起是**求值引擎子进程** | 引擎子进程不是 daemon：一会话一进程，协议串行 |
| CSV 外部读写 | 与 Parquet 共用 `:allow-external`（0.68）+ 7 项方言白名单（0.69，V-162） | 不做编码 / 多行字段精细控制 / 分区写出；方言只在 Raku 层 |
| describe 值 API | Table.describe + Engine.describe 默认实现（0.69，V-163） | 大表 count(distinct) 不承诺性能；不做直方图 |
| SQL 上下文补全 | 纯函数 + 别名/前缀列/大小写（0.68 / 0.69） | 只识别 '...'/"..."；**不做 SQL AST 解析**（V-908） |
| REPL 同名导出 | Session 改 `need Rakuish::Data`（0.69，V-165） | 新增导出同名 sub 时仍需留意 EVAL 词法作用域 |
| Table 大结果 | 0.67 `Engine.cursor()` 真惰性；`query()` 仍物化 | 游标一次性、无事务一致性快照 |
| `class/role/grammar` 跨格 | 纯声明格可持久（0.65） | 混合格 / 类型对象身份仍受限 |
| glob 转义/嵌套 brace | 已实现（0.65，`Sys.glob` / Raku `glob()`） | Shell 薄层文件名参数只展开 `* ?` |
| Vi/Helix 模态 | 已实现（0.66，ADR-0003）；0.70 `tools/tty-check.py` 自动验收 | 真实终端光标手感仍需人工确认；子类依赖 LineEditor 0.0.23 内部 |
| 交互式子进程 | 0.70 `tty-exec` / `! --tty` 显式 TTY 直通（V-167 / ADR-0007） | 输出不进 `_`；无超时需自行结束；行编辑器挂起读理论上可能吞首字符（PTY 测试已验证未发生） |
| PTY 捕获 | 0.72 `pty-exec`；0.72.2 版本+isatty 双检、先剥离后截断（V-170 / V-172） | 只捕获 stdout，stderr 合流（`value<stderr-merged>`）；**没有 stdin 写入**，跑交互式 REPL 会挂到超时（要真交互用 `tty-exec`）；超时 kill 直接子进程、不承诺杀孙进程；需 Rakudo ≥ 2025.12，旧版返回 `code=127` 而非静默降级 |
| Ctrl-C 中断 | 0.71 输入中断（V-168）；0.85 起求值中由 `Eval::Client` 接管 SIGINT，归因 `op=interrupted` / `code=130`（V-221…V-225 / ADR-0023） | 输入阶段仍是行编辑器；求值中是 kill 引擎 + 重启 + 快照恢复（状态可能不完整）；子类构造失败回退原生 `CLIInput` 时是 0.70 行为 |
| `tty-exec` 期间 Ctrl-C | 0.72.3 真 PTY 契约（V-173 / ADR-0009）；0.73.0 起由进程组交接实现，Ctrl-C 由终端驱动直接投给前台子进程组 | SIGINT tap 只剩交接窗口；Windows 与降级路径仍是同组 + tap；子进程忽略 SIGINT 时按无超时边界一直等 |
| job control / 进程组切换 | **0.73.0 已实施**（V-175 / ADR-0010 §6）：`posix_spawnp` + `SETPGROUP` + `tcsetpgrp` + 自建 `waitpid`，真 PTY 11 断言（`t/32`） | 只做前台交接：**不做 `&` / `jobs` / `fg` / `bg` / Ctrl-Z 作业管理**，Ctrl-Z 会把子进程停住而 REPL 等在那儿；不做 SIGWINCH 转发与孙进程树回收（V-905）；Windows 无对应语义（`CTRL_C_EVENT` 不能投递给进程组）；`cwd` 依赖 `posix_spawn_file_actions_addchdir_np`，缺失时降级并标 `job-control=False` |
| 结果着色 | 0.74.0：`Session` 按入口的颜色能力着色路径列表 / `ls -l` / `Out[n]` / 错误行 / `help()` / `env()` / `stat` / 写入结果（V-176 / ADR-0011） | 列宽按纯文本算，颜色只插零宽转义；`Result.render-result(text)` 与 Table 仍不掺 ANSI。**0.77.0 修**：`IO::Path.x` 在本版 Rakudo 的 Win32 上会抛、被 `try` 吞成 False，Windows 因此从未把 exe 标绿；现改为 POSIX 看执行位、Windows 看扩展名。**0.79.0 修**：`.l`/`.d` 对不存在的路径返回的是 Failure（不抛），`try` 挡不住，最后在 DESTROY 往 stderr 吐 unhandled Failure；**0.79.1 真修**：链式 `.so` 里的 Failure 仍是临时值、GC 时照样吐；改为先落到标量再 `.defined` 消费 |
| 输入行高亮 | 0.74.0：覆盖 `visible-input-field-string`（`HlField`），emacs / vi / helix 共用（V-177 / ADR-0011 §4）；**0.97.0 补跨行引号**：Session 续行时经 `set-continuation` 传已提交源码，下一行开头若在未闭合 `"..."` / `q[...]` 内则整段染字符串色（`t/33` 10 断言，纯文本等价仍成立） | 仍不染正则字面量 / heredoc / pod / 插值块 `{$x}` 里的代码（要真词法器）；**依赖 LineEditor 内部**（scroll-cursor / available-width）；回退到原生 `CLIInput` 时无高亮 |
| 大文件读 | 0.97.0：`head -n` / `tail -n` 走 `sys.read-lines(:head/:tail)` 流式按行读，不受 `read` 的 1 MiB 全文上限；`read` 超限报错给出 `read-lines` / `stream` / `:max-bytes` 三条出路（`t/10`） | `tail` 仍需扫到文件尾（只在内存留 n 行，不物化全文）；真正 O(n) 的尾部 seek 未做 |
| 展示包 | 0.78.0：`Display::Bundle`（text 必有 + markdown/json 可选 + 协商），`Kernel.bundle` / `present`（V-184 / ADR-0016）；**0.81.0**：Agent 的 `display` 字段随 Agent 线撤销，bundle 本身保留 | **不提供 `html`**（没有任何渲染路径能产出）；markdown 只对表格类内容（table / records）原生，其余降级为 text 并在 `format` 里如实标注；`Result.render('markdown')` 渲染的仍是 Result 外壳，与 bundle 不是一回事 |
| op 通道 | 0.78.0：`kind=op` 只开 `capabilities`（V-186 / ADR-0016 §6）；0.81.0 起它是 `Kernel` 的自描述接口，**没有第二个前端在用** | 文件/进程类 op 仍 501；`sandbox` 相关的 403 / root 越界语义随 Agent 删除 |
| 统一审计 | 0.80.0：`Rakuish::Audit` 唯一写入函数（V-194…V-196 / ADR-0018），默认落盘、`RAKUISH_AUDIT` 覆盖、`RAKUISH_NO_AUDIT` 关闭；`t/40` | **不防篡改**（同用户可写日志文件）、**不是事前阻止**；`Audit` / `log-line` / `trail` / `display` 四者刻意不合并 |
| 发布工程 | 0.80.1：`v0.80.0` tag、`tools/ci.sh` 双平台实测、清 `v/` 与 2 个测试残留、修 `HANDOFF` 日期 / `PROPOSAL` 状态 / 三份自审定位、补 `ADR-INDEX.md` 与 `CI.md` | **云端 CI 自动触发未启用**（Gitee Go 需网页端开通 + 构建机预装 Rakudo）；真 PTY / ConPTY / `zef install` 仍按 §9 验收清单手工跑；**拿真实任务用一两周**尚未开始 |
| §6 方向议题（权限交给系统 + 常驻引擎） | **已终结**（0.81.0）：三层探针证明 rakupp 缺 `:pty` 与 async socket 收尾，而那两项之所以成为问题，是因为要给 Agent 一个安全执行环境；用户据此决定放弃 Agent 线、做全权限本地 shell（ADR-0019） | V-906 标为**不做且已终结**；探针数据保留在 `docs/PROBE-2026-11-1*.md`；Agent 代码可从 `v0.80.4` 取回，重开前提见 ADR-0019 §5；**0.121.1 起 rakupp 线彻底终结**，只支持标准 Rakudo（ADR-0046） |
| 全权限本地 shell | 0.81.0：删除 Agent / Sandbox / 协议（1695 行），`X::Rakuish::Sandbox` 改名 `Bound`，SPEC 新增 V-197…V-199；**0.82.0：`Policy` 收敛到 3 字段**（V-211 / ADR-0020） | **没有权限闸门**；`root` 降级为防误操作；`allow-exec` / `read-only` / `allow-ops` / `limits` 已删 —— 它们没有执行点，留着只会被读成保护承诺 |
| 引擎子进程 | 0.83.0：交互式 REPL 的 `EVAL` 跑在 `raku` 子进程（V-212…V-216 / ADR-0021）；`exit` / 段错误 / `while 1 {}` 只带走引擎，`Eval::Proxy` 重启一次；`! --tty` 交回父进程执行（WSL 真 PTY `t/30` 10 断言全绿） | 协议串行、不并发；管道 / `-e` / 脚本仍是进程内 Session（没有「会话要继续」这回事） |
| 求值中断 | 0.85.0：`Eval::Client` 在等响应时接管 SIGINT、主动 kill 引擎（V-221…V-224 / ADR-0023）；归因 `op=interrupted` / `code=130`，文案「已中断当前求值」；清掉行编辑器的 `take-interrupt` 以免吞下一格；中断后照常从快照恢复（`t/43` 18 断言） | 不承诺中断立即生效（kill 是异步的）；语句格的中间状态不留（中断即丢该格）；协议仍串行，中断期间不能并发提交新格 |
| 真终端验收 | 0.86.0：`tools/ctrl-c-posix.py`（真 PTY）+ `tools/ctrl-c-win.py`（真 ConPTY）；两侧都带「不在求值时按 Ctrl-C 必须走输入中断」的对照；接进 `tools/ci.sh` 的 `console` 层，报告里 `console=pass`（V-225 / ADR-0023 §8）。**0.87.0：Windows 侧加场景二**——`! --tty` 期间 Ctrl-C 必须落到子进程、不带走宿主（t/30 的 Windows 对应物） | 只覆盖 Ctrl-C / tty-exec 这两条真终端契约；`tty-check.py` / `tty-termios-win.py` / `tty-cjk-win.py` / `zef install` 仍是手工项；无控制台且无 winpty 时记 `console=skip`（不算绿） |
| TTY 判定 | 0.87.0：**真实终端是不是 TTY 由入口注入**（V-226 / ADR-0021 §10）：`Session.tty` / `Shell.tty` + `Client.eval(:tty)` 每格推送。修掉了 0.83 引入的静默回归——`clear` 不输出、shell 彩色全灭、多列 `ls` 退化成单列（引擎的 `$*OUT` 是协议管道，`.t` 恒 False） | 凡是终端事实（TTY / 宽高 / 颜色）都必须由前端下发，引擎不许自己看 fd 属性；`RAKUISH_PAGER` 等环境在会话中改动仍以每格推送为准 |
| 分页 / 流式与协议 | 0.89.0：拆出 `live-out`（本进程 stdout 是不是终端），分页器与 `ls -R` 流式分支改判它（V-228 / ADR-0021 §12）。修掉 0.87 的事故：`explore` 大表会把表格写进 JSON 协议流并吞掉下一个请求，整个 REPL 卡死；`t/41` ⑧⑨ 用真子进程守住「操作后协议仍健康」 | **0.92.0 已补上**：分页搬到父进程（`Pager.paginate` 注入读/写回调，入口按 `term-size()` 切页，`RAKUISH_PAGER=auto/always/never`，V-245…V-249 / ADR-0027）；`t/47` 41 断言 + `tools/pager-posix.py` 真 PTY 验收（翻页 / q / never 对照），已接进 `tools/ci.sh` 的 console 层。剩下的边界：没有「上一页」/ 搜索 / 全屏备用屏；Windows 侧没有分页探针（只有 POSIX）；`always` 会让 `cat` 大文件也停下来（显式要求才这样） |
| `!` 流式输出 | 0.90.0：把 0.79 就存在的 `Handle.wait(:&on-out,:&on-err)` 真正接到 `exec`；Session 按 `stream-out` 分流，引擎发 `chunk` 帧、父进程实时打印；新增 `--capture` / `--timeout-ms` / `--no-timeout`（V-229…V-231 / ADR-0024）；`t/44` 32 断言 | 子进程 stdout 仍是**管道**不是 TTY（颜色 / 进度条不按终端走）；只在父进程 stdout 是终端时流式；捕获上限仍 1 MiB；块边界不保证整行 |
| 启动层 | 0.90.0：`~/.rakuish/rc.raku` 在引擎里逐格执行、不占 `Out[n]`，崩溃重启后重跑；`repl.prompt` 每格求值且吞掉噪声；`set -o` 五个有执行点的选项（V-232…V-236 / ADR-0025）；`t/45` 48 断言 | rc 只对交互式 REPL 生效（`-e` / 脚本不读）；不支持 bash 语法 / per-dir rc / 登录分层；prompt 是同步调用，里面跑外部命令会拖慢提示符；选项只在会话内有效，跨会话要写 rc |
| 结构化管道 | 0.91.0：`Rakuish::Data::Stream` —— 惰性记录流；`stream()` 接文本（lines/csv/tsv/json/jsonl/pattern）、`!` 的 `Result`、`Table`、`Cursor`；阶段 `where/select/drop/map/add-column/limit/skip` 惰性，`sort-by/unique/count-by/group-by` 物化；出口 `.table/.text/.json/.csv/.lines` 与 `.exec`（写子进程 stdin，走会话 Sys）；V-237…V-244 / ADR-0026；`t/46` 53 断言 | 不加管道语法（`|` 属 V-901；`|>` 在 Raku 语法里不可定义），管道就是方法链；**0.93.0 已补上**：`.exec` 的 stdin 改成流式（`Sys::Proc.spawn` 的 `:&in-chunks`，写一块 await 一块 = 背压，V-250…V-254 / ADR-0028；`t/48` 24 断言）；**0.94.0 已补上 `zip` / `join` / `tee`**（ADR-0029 / V-255…V-260，`t/49` 37 断言；`join` 仍只支持单键、`tee` 不是 fan-out）；**0.95.0 已补上 `interleave` / `append`**（ADR-0030 / V-261…V-264，`t/50` 32 断言；交替默认吐完长侧、`:shortest` 取短，append 首尾接且左读完不碰右；两者不改行不改名）；Cursor 来源的流只能读一次（第二次明确报错）；`stream()` 的 `:format` 对非文本入参无效 |
| 作业控制 | 0.73.0 只做前台进程组交接（ADR-0010 选项 A，POSIX-only）；**0.96.0 补上 B 档 API**：`bg-exec` / `bg-jobs` / `fg` / `bg`（ADR-0031 / V-265…V-269，`t/54` 21 断言） | 纠正前提：ADR-0010 本就是 MoarVM 真 PTY 实测，换后端不解锁新东西；障碍是 V-901（不做 shell 语法）+ 双进程架构。作业表在父进程（引擎重启不丢），DSL 经 job 帧转过去；Ctrl-Z 停住时 fg 归还前台不卡死。仍不做 `&` 语法 / Ctrl-Z 键绑定 / SIGWINCH / 孙进程树（V-905）；Windows 返回 code=127 明确降级 |
| 终端尺寸 | 0.88.0：`Rakuish::Sys::Term::term-size()` —— POSIX `ioctl(TIOCGWINSZ)`、Windows `GetConsoleScreenBufferInfo`，经 `Client.eval(:width,:height)` 每格下发（V-227 / ADR-0021 §11）；`t/10` 9 条 + `t/41` 2 条覆盖「注入 + 排版随宽度变化」；真终端实测 40 列 → 每行 ≤40 | 不做 SIGWINCH 订阅（每格查一次，ioctl 是微秒级）；只问 stdout（重定向时返回 0，回落 80 列）；`COLUMNS` 仅在两种探测都失败时兜底，且可能是陈旧值 |
| 快照上限 | 0.87.0：单值上限可配 `RAKUISH_SNAPSHOT_MAX`（默认 1e6 字符，`0`/`off`/`none`/`unlimited` = 不限制，非法值回落默认）（V-218 修订） | 只限单值，**没有**整份快照总大小上限；不限制时大数组会让每格写盘变慢（用户自担）；不做增量快照 |
| 会话快照 | 0.84.0：每成功格写 `%!state` + `@!decls`（V-217…V-220 / ADR-0022）；崩溃重启重放声明与纯值，`t/42` 45 断言（含「副作用不重放」）；资源 / 闭包 / 超大值明确标失效并列出名字 | **语句格不重放**（副作用不幂等）；不承诺引用语义（`my $a := $b` 变两份拷贝）；格式不迁移（版本不符即忽略）；快照含变量值，仅 chmod 600，不加密 |
| 流式 / 取消 | 0.79.0：`stream` 只对 `exec` 生效（V-190…V-193 / ADR-0017），帧 `start`→`chunk`*→`end`；`cancel` 只停 `exec`（137），其余 op 明确 409 | **0.79.2 / V-607 后默认配置下没有作用对象**：`STREAM-OPS = <exec>` 而 `exec` 默认 403 ⇒ 默认 `stream` 不发帧、`cancel` 恒 409，只有显式 `--allow-code-exec --allow-exec` 的 profile 可用（0.80.1 补登记，SPEC §3.11 / ADR-INDEX §3）；**非 cancel 请求仍串行执行**（顺序契约优先，没做请求并发）；`sql_query` / `pty_exec` 不流式；`max-output` 是帧预算，超限只停发不收回；取消只杀直接子进程（与 V-159 同边界，不承诺孙进程） |
| `tty-exec` 的 termios | 0.72.4 交接前快照、正常路径与 `LEAVE` 幂等恢复（V-174 / ADR-0009 §0） | 整份配置恢复、不猜测子进程改了哪些位；Windows 的 `GetConsoleMode` 分支 0.72.5 已在真 ConPTY 与 conhost 下实测（`tools/tty-termios-win.py`），vim / less 自身的恢复时序仍需人工 |
| SQL 补全形态 | 0.71 `q[...]` 与 `sql =>` / `:sql(`（V-169 / ADR-0008） | 不识别 `qq` / `Q` / heredoc / 嵌套 `q[]`；仍无 SQL AST；别名是词法启发式 |
| 本地 Raku 插件 | 已实现（0.66，默认 off） | 加载即执行本地代码，不是沙箱；只加载可信文件 |
| OS 隔离 | 同用户文件策略 | 不是容器级安全 |
| Windows 控制台码页 | 0.76.1 起交互前自动切 UTF-8 并还原 | 只处理「stdin 是终端」；非法字节仍会让 `LineEditor` 一直等（依赖内部循环，未私有化） |
| Windows 时间戳 | 可能 1969 | 已如实降级 |
| SQLite 连接并发 | 单连接 | 单写者 |
| `cmd` 递归 | 仅 REPL | 不用于脚本 |

---

## 11. 下一任 AI 的工作方式

1. **先读** `docs/MANUAL.md`、`SPEC.md`、本文件；不要凭文件名猜行为。
2. **先跑** `bash tools/run-all.sh`，确认基线；不要把已有失败当自己引入。
3. **不要重写架构**：v3 是刻意选的；要改先写 ADR/设计。
4. **不要加 bash**：新需求先问能否用 Raku/结构化值表达。
5. **不要重放历史**：修 REPL 状态用声明持久/持久求值器。
6. **不要绕过 Sys**：文件/进程一律经 `Sys`。
7. **默认不设闸门**（0.81.0 起）：本地全权限，新能力不给「默认关闭 + 开关」形态（V-198）。
   要限制什么，先问「这限制是给谁的」——没有不可信输入方时，闸门只是牌子。
8. **小步提交**：每个能力带测试、文档、版本；不要一次性大重构。
9. **保持诚实**：Windows/超时/安全边界的不确定性写进文档，不假装解决。

### 接手检查清单

- [ ] `prove6 -Ilib t` 全绿
- [ ] `tools/run-all.sh` 退出 0
- [ ] `python3 tools/tty-check.py` 全 PASS（Linux/WSL）
- [ ] `zef install . --force-install` 通过
- [ ] 版本/`provides` 同步
- [ ] README/MANUAL/SPEC/ROADMAP 同步
- [ ] 没有新增 shell 字符串解析
- [ ] 新 op 默认关闭、审计、限额
- [ ] 没有重放历史副作用

---

## 12. 术语

- **Session**：`Rakuish::REPL::Session`，一格 REPL。
- **Sys**：会话级系统出口。
- **Result**：结构化结果；`ok/code/value/out/err/op/elapsed`。
- **Table**：行 Hash + 列 + 类型。
- **Engine**：数据库适配器。
- **Shell 薄层**：日常命令翻译层，不是第二套 shell。
- **v1/v2/v3**：历史架构代际；只有 v3 在仓库中。
