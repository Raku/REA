unit module Rakuish::Data::Duck;

# Rakuish::Data::Duck —— Table ⟷ DuckDB（Duckula）的桥（0.120.0 / V-315）。
#
# 三方分工，各管一段：
#   · 解码：`.arrow` 文件 → Table 走 Arrow::IPC（0.118.3 起，支持 list/struct/map）
#   · 编码：Table → `.arrow` 文件走 Rakuish::Data::Arrow（纯 Raku，零原生依赖）
#   · 计算：Table → SQL 走 Duckula（DuckDB 的 DataFrame 层）
#
# 桥本身只做两件事：把 Table 写成临时 Arrow IPC 文件交给 Duckula 的
# `read-arrow`，再把查询结果的 Frame 读回 Table。**不让 Duckula 写 IPC**：
# 0.33.1 的 `ipc-buf` 在 timestamp / date 列上会产出 pyarrow 与 Arrow::IPC
# 都读不了（前者报 Not an Arrow file，后者直接段错误）的字节流 —— 已在
# ADR-0043 记录，等上游修；回读走 Frame 的 Raku 值，不碰那条路径。

use JSON::Fast;
use Rakuish::Result;
use Rakuish::Data::Table;

# 运行时加载 Duckula 并取 Session 类。
# 不能写 `require ::('Duckula')`：那是「按变量名软查找」，在我们这种模块
# 作用域里会静默返回 Nil（实测）。字面 `require Duckula` 才会真正加载
# provides 表里的整个发行版；类从 WHO 里取，避免编译期符号解析（本模块
# 编译时 Duckula 可能还没装）。
my sub duck-session-class() {
    require Duckula;
    Duckula.WHO<Session>;
}

# 结果列名要能当 SQL 标识符用，也避免拼进 SQL 时被当成语法。
my sub check-name(Str $name) {
    X::Rakuish::Data.new(
        :detail("表名 '{$name}' 不合法：只允许字母、数字、下划线，且不能以数字开头")
    ).throw unless $name ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/;
    $name;
}

# ── DuckDB 类型 → Table 类型 ─────────────────────────────────────────
# Duckula 的 dtypes 给的是 DuckDB 的 SQL 类型名（BIGINT / DECIMAL(10,2) /
# TIMESTAMP WITH TIME ZONE / VARCHAR[] …），不是 Arrow format 串。
our sub duck-type(Str $t --> Str) is export {
    my Str $u = $t.uc;
    return 'list' if $u.ends-with('[]');
    return 'map'  if $u ~~ /^ 'STRUCT' | ^ 'MAP' | ^ 'UNION' /;
    return 'datetime' if $u ~~ /^ 'TIMESTAMP' | ^ 'DATE' /;
    return 'bool' if $u ~~ /^ 'BOOL'/;
    return 'int'  if $u ~~ /^ 'TINYINT' | ^ 'SMALLINT' | ^ 'INTEGER' | ^ 'BIGINT'
                       | ^ 'HUGEINT' | ^ 'UTINYINT' | ^ 'USMALLINT' | ^ 'UINTEGER'
                       | ^ 'UBIGINT' | ^ 'UHUGEINT' /;
    return 'num'  if $u ~~ /^ 'DECIMAL' | ^ 'NUMERIC' | ^ 'DOUBLE'
                       | ^ 'FLOAT' | ^ 'REAL' /;
    'str';
}

# "2020-01-01 12:00:00" / "2020-01-01 12:00:00.5+08" → DateTime。
# 解析不了就返回 Nil，调用方把整列退回 str（和 open-data 的口径一致：
# 不把没解析成功的字符串伪装成时间）。
my sub parse-datetime($v) {
    return $v if $v ~~ DateTime;
    return Nil unless $v.defined;
    my Str $s = $v.Str.trim;
    return Nil unless $s.chars;
    my $d = try DateTime.new($s.subst(' ', 'T'));
    $d.defined && $d ~~ DateTime ?? $d !! Nil;
}

# ── Frame → Table ─────────────────────────────────────────────────────
# Frame.rows 给的是 Array of Array（Raku 原生值），dtypes 给 SQL 类型名；
# 两者一起还原成 Table 的列类型。日期时间列整列尝试转换，有一格失败就
# 整列退回 str —— 混合列比错误类型更难用。
our sub table-from-frame($frame --> Rakuish::Data::Table) is export {
    my @names = $frame.names.List.map(*.Str);
    X::Rakuish::Data.new(:detail('查询结果没有列')).throw unless @names.elems;
    my %dup;
    for @names -> $n { %dup{$n}++ }
    if %dup.values.grep(* > 1) {
        X::Rakuish::Data.new(
            :detail('查询结果有重名列：' ~ %dup.grep(*.value > 1).map(*.key).sort.join(', ')
                ~ '；给列起别名再查')
        ).throw;
    }

    my %types;
    for @names -> $n {
        %types{$n} = duck-type(($frame.dtypes{$n} // '').Str);
    }

    my @raw = $frame.rows.List;
    my @rows;
    for @raw -> $r {
        my %h;
        for @names.kv -> $i, $n {
            my $v = $r[$i];
            %h{$n} = $v.defined ?? $v !! Any;
        }
        @rows.push(%h);
    }

    # datetime / 数值列的语义还原（只做「不改变可比性」的那种）
    for @names -> $n {
        my Str $kind = %types{$n};
        if $kind eq 'datetime' {
            my @vals = @rows.map({ $_{$n} });
            my Bool $all-ok = True;
            my @conv;
            for @vals -> $v {
                if $v.defined {
                    my $d = parse-datetime($v);
                    if $d.defined { @conv.push($d) }
                    else { $all-ok = False; last }
                }
                else { @conv.push(Any) }
            }
            if $all-ok && @conv.elems == @vals.elems {
                for @rows.kv -> $i, %row { %row{$n} = @conv[$i] }
            }
            else { %types{$n} = 'str' }
        }
    }

    Rakuish::Data::Table.new(:columns(@names), :rows(@rows), :types(%types));
}

# ── Table → 可写的 Table ──────────────────────────────────────────────
# 写侧（Rakuish::Data::Arrow）只支持标量列：嵌套列在 0.120.0 起会明确报错，
# 不再静默拼成 ".Str"（那是 `age\t30\nname\tann` 这种垃圾）。要过 SQL 的
# 嵌套列，这里显式转成 JSON 文本，类型记 str —— 可读、可 like、可再 to-json
# 解回来，且不假装 DuckDB 能直接取结构体字段。
our sub duck-ready(Rakuish::Data::Table $t --> Rakuish::Data::Table) is export {
    my @cols = $t.columns.map(*.Str);
    my %nested;
    for @cols -> $c {
        my Str $kind = ($t.types{$c} // 'str').Str;
        if $kind eq 'list' | 'map' {
            %nested{$c} = True;
            next;
        }
        # 类型标错但值是嵌套结构时的兜底：按值判断，别让写侧炸在用户看不懂的地方。
        my $probe = $t.rows.first({ $_{$c}.defined });
        %nested{$c} = True
            if $probe.defined && $probe{$c} ~~ Positional | Associative;
    }
    return $t unless %nested;

    my %types = $t.types.Hash;
    my @rows;
    for $t.rows -> %row {
        my %h;
        for @cols -> $c {
            my $v = %row{$c};
            if %nested{$c} {
                if $v.defined {
                    my $json = try { to-json($v, :!pretty) };
                    %h{$c} = $json.defined ?? $json !! $v.Str;
                }
                else { %h{$c} = Any }
                %types{$c} = 'str';
            }
            else { %h{$c} = $v }
        }
        @rows.push(%h);
    }
    Rakuish::Data::Table.new(:columns(@cols), :rows(@rows), :types(%types));
}

# ── 主入口：多张表一起跑一段 SQL ────────────────────────────────────
# %tables 是 名字 => Table；SQL 里就当它们是这个会话里的普通表，可以 join。
#   query({ a => $t1, b => $t2 }, 'select ... from a join b using (k)')
our sub query(%tables, Str $query --> Rakuish::Data::Table) is export {
    # 运行时加载（Duckula 是可选依赖）；类从 WHO 里取，编译期不当符号解析。
    # 注意类对象本身是「undefined value」，不能用 `.defined` 判断。
    my $sess-class;
    try { $sess-class = duck-session-class() };
    X::Rakuish::Unsupported.new(
        :detail('Table.sql 需要 Duckula（DuckDB 的 DataFrame 层）；请先 zef install Duckula')
    ).throw unless $sess-class.^can('new').elems;
    X::Rakuish::Data.new(:detail('至少要有一张表')).throw unless %tables.elems;
    X::Rakuish::Data.new(:detail('SQL 不能为空')).throw unless $query.trim.chars;

    require Rakuish::Data::Arrow;

    # 先把每张表写成临时 Arrow 文件：编码走自研写侧（DuckDB 能直接读，
    # t/76 有交叉验证），计算留给 DuckDB —— 各用各的强项。
    my %paths;
    my $sess;
    LEAVE {
        try { $sess.close } if $sess.defined;
        # 临时文件是这一格的私人物品，DuckDB 读完就不该留下。
        for %paths.values -> $p { try { $p.IO.unlink if $p.IO.e } }
    }

    my Int $i = 0;
    for %tables.keys.sort -> $name {
        my Str $view = check-name($name.Str);
        my $path = $*TMPDIR.add(
            "rakuish-duck-{$*PID}-{(now * 1000).Int}-{$i}-{(rand * 1_000_000).Int}.arrow"
        ).Str;
        $i++;
        Rakuish::Data::Arrow::write-ipc-file(duck-ready(%tables{$name}), $path);
        %paths{$view} = $path;
    }

    my $err;
    my $frame;
    {
        CATCH { default { $err = .message } }
        $sess = $sess-class.new;
        for %paths.keys.sort -> $view {
            $sess.read-arrow(%paths{$view}, :name($view));
        }
        # 用任何一个 Frame 上的 SQL 入口执行；查询里写的就是上面注册的表名。
        $frame = $sess.sql($query);
    }
    X::Rakuish::Data.new(
        :detail('SQL 执行失败: ' ~ (($err // '未知错误').Str.lines[0] // ''))
    ).throw if $err.defined;

    table-from-frame($frame);
}

# 单表糖：`$t.sql('select ... from t')`。
our sub table-sql(Rakuish::Data::Table $t, Str $query,
                  Str :$name = 't' --> Rakuish::Data::Table) is export {
    query({ check-name($name) => $t }, $query);
}
