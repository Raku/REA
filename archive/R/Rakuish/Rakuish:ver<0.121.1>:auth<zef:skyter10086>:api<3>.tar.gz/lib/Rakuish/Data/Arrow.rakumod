unit module Rakuish::Data::Arrow;

# Rakuish::Data::Arrow —— Arrow IPC 文件格式的纯 Raku 读写（0.116.0 / V-308）。
#
# 为什么不拉依赖：
#   · DuckDB 只能扫内存里的 Arrow，**读不了 IPC 文件**（`read_parquet` 是另一回事）；
#   · Duckula 能读，但会拖进 DB::DuckDB / 原生 libduckdb，只为了解一个文件格式太重。
#   所以这里自己解析 FlatBuffers。成本是这个文件长，好处是零依赖、可审计、可教学。
#
# 支持范围（其余一律**明确报错**，不静默降级）：
#   读：int / float / bool / utf8 / large-utf8 / binary / large-binary /
#       date / time / timestamp / decimal / duration / null
#   写：int64 / float64 / bool / utf8（含从 datetime 转毫秒时间戳）
#   不支持：字典编码、BodyCompression、List / Struct / Map / Union /
#           FixedSizeBinary / FixedSizeList / RunEndEncoded / Interval
#
# 格式速记：文件 = "ARROW1" + 消息流 + Footer + int32 footer 长度 + "ARROW1"；
# 流 = 消息流（无头尾）。消息以 0xFFFFFFFF 续行标记开头（V5 起），随后是
# 元数据长度、FlatBuffers 元数据、body。

use Rakuish::Data::Table;
use Rakuish::Result;
use JSON::Fast;

my sub arrow-fail(Str $msg --> Nil) { X::Rakuish::Arrow.new(:detail($msg)).throw }
# 「文件合法但类型没实现」——与「文件坏了」分开，读侧据此决定要不要回退到
# Arrow::IPC（0.120.1 / V-316）。坏文件走它只会段错误，不能回退。
my sub arrow-unsupported(Str $msg --> Nil) {
    X::Rakuish::Arrow::UnsupportedType.new(:detail($msg)).throw;
}

# ── 小端读取 ─────────────────────────────────────────────────────────
my Bool $LE = (Buf.new(1, 0, 0, 0).read-uint32(0) == 1);

class Reader {
    has Buf $.buf is required;
    has Int $.pos is rw = 0;

    method take(Int $n --> Buf) {
        arrow-fail("数据在 {$!pos} 处提前结束：需要 {$n} 字节，只剩 {$!buf.elems - $!pos}")
            if $n < 0 || $!pos + $n > $!buf.elems;
        my Buf $b = $!buf.subbuf($!pos, $n);
        $!pos += $n;
        $LE ?? $b !! $b.reverse;
    }
    method u8(--> Int)  { my $b = self.take(1); $b[0] }
    method u16(--> Int) { self.take(2).read-uint16(0) }
    method u32(--> Int) { self.take(4).read-uint32(0) }
    method u64(--> Int) { self.take(8).read-uint64(0) }
    method i32(--> Int) { my $v = self.u32; $v >= 0x8000_0000 ?? $v - 0x1_0000_0000 !! $v }
    method i64(--> Int) { my $v = self.u64; $v >= 0x8000_0000_0000_0000 ?? $v - 0x1_0000_0000_0000_0000 !! $v }
    method num32(--> Num) { self.take(4).read-num32(0) }
    method num64(--> Num) { self.take(8).read-num64(0) }
}

# ── FlatBuffers 表读取 ───────────────────────────────────────────────
# 表 = soffset(i32) 指向 vtable；vtable = 长度(u16) + 每个字段的 u16 偏移。
# 字段偏移为 0 表示「没写这个字段」（读默认值）。
class Fb {
    has Buf $.buf is required;
    has Int $.pos is required;
    has Int $!vtable = 0;
    has Int $!vlen = 0;

    submethod TWEAK() {
        my Int $soff = Reader.new(:buf($!buf), :pos($!pos)).i32;
        $!vtable = $!pos - $soff;
        arrow-fail("FlatBuffers 表头越界（pos={$!pos} soffset={$soff}）")
            if $!vtable < 0 || $!vtable + 4 > $!buf.elems;
        $!vlen = Reader.new(:buf($!buf), :pos($!vtable)).u16;
        $!vlen = 4 if $!vlen < 4;
    }

    method pos-of(Int $id --> Int) {
        my Int $at = 4 + 2 * $id;
        return -1 if $at + 2 > $!vlen;
        my Int $off = Reader.new(:buf($!buf), :pos($!vtable + $at)).u16;
        $off == 0 ?? -1 !! $!pos + $off;
    }
    method has(Int $id --> Bool) { self.pos-of($id) >= 0 }

    method u8-at(Int $id, Int $default = 0 --> Int) {
        my Int $p = self.pos-of($id);
        $p < 0 ?? $default !! Reader.new(:buf($!buf), :pos($p)).u8;
    }
    method bool-at(Int $id, Bool $default = False --> Bool) {
        my Int $p = self.pos-of($id);
        $p < 0 ?? $default !! Reader.new(:buf($!buf), :pos($p)).u8 != 0;
    }
    method i16-at(Int $id, Int $default = 0 --> Int) {
        my Int $p = self.pos-of($id);
        $p < 0 ?? $default !! Reader.new(:buf($!buf), :pos($p)).u16;
    }
    method i32-at(Int $id, Int $default = 0 --> Int) {
        my Int $p = self.pos-of($id);
        $p < 0 ?? $default !! Reader.new(:buf($!buf), :pos($p)).i32;
    }
    method i64-at(Int $id, Int $default = 0 --> Int) {
        my Int $p = self.pos-of($id);
        $p < 0 ?? $default !! Reader.new(:buf($!buf), :pos($p)).i64;
    }

    # 引用字段：位置处是「相对该位置的 u32 偏移」，目标在它**后面**。
    method ref-at(Int $id --> Int) {
        my Int $p = self.pos-of($id);
        return -1 if $p < 0;
        $p + Reader.new(:buf($!buf), :pos($p)).u32;
    }
    method table(Int $id --> Fb) {
        my Int $p = self.ref-at($id);
        arrow-fail("字段 {$id} 应当是表，但没写") if $p < 0;
        Fb.new(:buf($!buf), :pos($p));
    }
    method str(Int $id --> Str) {
        my Int $p = self.ref-at($id);
        return '' if $p < 0;
        my $r = Reader.new(:buf($!buf), :pos($p));
        my Int $n = $r.u32;
        $r.take($n).decode('utf-8');
    }
    # 向量：位置处是长度，元素紧随其后（可能因对齐而留 1~7 字节缝）。
    method vec(Int $id, Int $elem-size, Int $elem-align = 4 --> List) {
        my Int $p = self.ref-at($id);
        return (0, -1) if $p < 0;
        my Int $len = Reader.new(:buf($!buf), :pos($p)).u32;
        my Int $start = $p + 4;
        my Int $a = $elem-align max 1;
        $start++ while $start % $a;
        ($len, $start);
    }
    method vec-i64(Int $id --> List) {
        my (Int $len, Int $start) = self.vec($id, 8, 8);
        return () if $len <= 0;
        my @v;
        for ^$len -> $i {
            @v.push(Reader.new(:buf($!buf), :pos($start + 8 * $i)).i64);
        }
        @v.List;
    }
    method vec-tables(Int $id --> List) {
        my (Int $len, Int $start) = self.vec($id, 4, 4);
        return () if $len <= 0;
        my @v;
        for ^$len -> $i {
            my Int $p = $start + 4 * $i;
            @v.push($p + Reader.new(:buf($!buf), :pos($p)).u32);
        }
        @v.List;
    }
}

# ── 类型描述 ─────────────────────────────────────────────────────────
my constant %TYPE-NAME =
    1  => 'null',        2  => 'int',          3  => 'float',
    4  => 'binary',      5  => 'utf8',         6  => 'bool',
    7  => 'decimal',     8  => 'date',         9  => 'time',
    10 => 'timestamp',   11 => 'interval',     12 => 'list',
    13 => 'struct',      14 => 'union',        15 => 'fixed-size-binary',
    16 => 'fixed-size-list', 17 => 'map',      18 => 'duration',
    19 => 'large-binary', 20 => 'large-utf8',  21 => 'large-list',
    22 => 'run-end-encoded';

my constant %UNIT = 0 => 's', 1 => 'ms', 2 => 'us', 3 => 'ns';

sub parse-type(Fb $field --> Hash) {
    my Int $code = $field.u8-at(2);
    my Str $kind = %TYPE-NAME{$code} // "未知类型 #{$code}";
    my %t = kind => $kind;
    my $tab = $field.has(3) ?? $field.table(3) !! Nil;
    given $kind {
        when 'int' {
            %t<bits> = $tab.defined ?? $tab.i32-at(0, 32) !! 32;
            %t<signed> = $tab.defined ?? $tab.bool-at(1, False) !! False;
        }
        when 'float' {
            my Int $p = $tab.defined ?? $tab.i16-at(0) !! 2;
            %t<precision> = $p == 0 ?? 'half' !! $p == 1 ?? 'single' !! 'double';
        }
        when 'timestamp' {
            %t<unit> = %UNIT{($tab.defined ?? $tab.i16-at(0) !! 0)} // 's';
            %t<tz> = $tab.defined ?? $tab.str(1) !! '';
        }
        when 'date' {
            %t<unit> = ($tab.defined ?? $tab.i16-at(0) !! 0) == 0 ?? 'day' !! 'ms';
        }
        when 'time' {
            %t<unit> = %UNIT{($tab.defined ?? $tab.i16-at(0) !! 0)} // 's';
            %t<bits> = $tab.defined ?? $tab.i32-at(1, 32) !! 32;
        }
        when 'decimal' {
            %t<precision> = $tab.defined ?? $tab.i32-at(0, 38) !! 38;
            %t<scale> = $tab.defined ?? $tab.i32-at(1, 0) !! 0;
            %t<bits> = $tab.defined ?? $tab.i32-at(2, 128) !! 128;
        }
        when 'duration' {
            %t<unit> = %UNIT{($tab.defined ?? $tab.i16-at(0) !! 0)} // 's';
        }
        when 'fixed-size-binary' {
            %t<size> = $tab.defined ?? $tab.i32-at(0, 0) !! 0;
        }
    }
    %t;
}

sub parse-fields(Fb $schema --> List) {
    my (Int $len, Int $start) = $schema.vec(1, 4, 4);
    return () if $len <= 0;
    my @out;
    for ^$len -> $i {
        my Int $p = $start + 4 * $i;
        my Int $target = $p + Reader.new(:buf($schema.buf), :pos($p)).u32;
        my $f = Fb.new(:buf($schema.buf), :pos($target));
        my %type = parse-type($f);
        %type<dictionary> = True if $f.has(4);
        @out.push(%( name => $f.str(0), type => %type ));
    }
    @out.List;
}

# FlatBuffer 的缓冲区开头是一个指向**根表**的 uoffset，根表本身在后面。
# 直接把缓冲区起点当表会读到垃圾（vtable 长度 5 这种怪值）。
sub root-table(Buf $buf, Int $pos --> Fb) {
    my Int $off = Reader.new(:buf($buf), :pos($pos)).u32;
    arrow-fail("根表偏移越界（缓冲区 @ {$pos}，偏移 {$off}）")
        if $pos + $off >= $buf.elems;
    Fb.new(:buf($buf), :pos($pos + $off));
}

# ── 消息 ─────────────────────────────────────────────────────────────
my constant MSG-SCHEMA = 1;
my constant MSG-DICTIONARY = 2;
my constant MSG-BATCH = 3;

sub read-message(Buf $data, Int $pos --> Hash) {
    my $r = Reader.new(:buf($data), :pos($pos));
    my Int $first = $r.u32;
    my Int $meta-len = $first == 0xFFFF_FFFF ?? $r.u32 !! $first;
    arrow-fail("消息（pos={$pos}）的元数据长度不合理：{$meta-len}")
        if $meta-len <= 0 || $r.pos + $meta-len > $data.elems;
    my $msg = root-table($data, $r.pos);
    my %h =
        header   => $msg.u8-at(1),
        body-len => $msg.i64-at(3),
        meta-len => $meta-len,
        next-pos => $r.pos + $meta-len,
    ;
    %h<table> = $msg.table(2) if %h<header>;
    %h;
}

# ── 解码一列 ─────────────────────────────────────────────────────────
class Decoder {
    has Buf $.body is required;
    has @.nodes is required;
    has @.buffers is required;
    has Int $!ni = 0;
    has Int $!bi = 0;

    method !node(--> Hash) {
        arrow-fail('记录批里的 FieldNode 数量不够') if $!ni >= @!nodes.elems;
        @!nodes[$!ni++];
    }
    method !buffer(--> Buf) {
        arrow-fail('记录批里的 Buffer 数量不够') if $!bi >= @!buffers.elems;
        my %b = @!buffers[$!bi++];
        return Buf.new if %b<length> <= 0;
        arrow-fail("缓冲区越界（offset={%b<offset>} length={%b<length>} body={$!body.elems}）")
            if %b<offset> + %b<length> > $!body.elems;
        $!body.subbuf(%b<offset>, %b<length>);
    }
    # nullptr 有效性位图：位为 1 = 有效；长度为 0 = 全有效。
    # 位图长度是 ceil(n/8) 字节；超出位图范围按「有效」处理。
    # 别拿 null_count 当边界 —— 那是本批里有几个 null，不是下标上限
    # （0.116.0 一开始就这么写错了，结果一列有 null 时后面全变 null）。
    method !valid(Buf $bits, Int $i --> Bool) {
        return True if $bits.elems == 0;
        return True if $i >= $bits.elems * 8;
        (($bits[$i div 8] +> ($i % 8)) +& 1) == 1;
    }

    method column(%field --> List) {
        my %t = %field<type>.Hash;
        my Str $kind = %t<kind>;
        arrow-unsupported("字段 '{%field<name>}' 是字典编码的，暂不支持（请先用 duckdb / pyarrow 解码成普通列）")
            if %t<dictionary>;
        arrow-unsupported("字段 '{%field<name>}' 的类型是 {$kind}，暂不支持（支持 int/float/bool/utf8/binary/date/time/timestamp/decimal/duration/null）")
            if $kind eq any(<list struct union map fixed-size-binary fixed-size-list large-list run-end-encoded interval>);

        my %node = self!node;
        my Int $n = %node<length>;
        return (Any xx $n).List if $kind eq 'null';

        my Buf $valid = self!buffer;
        my Int $vc = %node<null-count>;

        given $kind {
            when 'int' | 'date' | 'time' | 'timestamp' | 'duration' {
                my Buf $raw = self!buffer;
                my Int $bits = %t<bits> // self!bits-for($kind, %t);
                my Int $width = ($bits / 8).Int;
                my Bool $signed = %t<signed> // True;
                my @v;
                for ^$n -> $i {
                    unless self!valid($valid, $i) { @v.push(Any); next }
                    my Int $v = self!int-at($raw, $i * $width, $width, $signed);
                    @v.push(self!convert($kind, %t, $v));
                }
                return @v.List;
            }
            when 'float' {
                my Buf $raw = self!buffer;
                my Str $prec = %t<precision> // 'double';
                my Int $w = $prec eq 'half' ?? 2 !! $prec eq 'single' ?? 4 !! 8;
                my @v;
                for ^$n -> $i {
                    unless self!valid($valid, $i) { @v.push(Any); next }
                    @v.push(self!float-at($raw, $i * $w, $prec));
                }
                return @v.List;
            }
            when 'bool' {
                my Buf $raw = self!buffer;
                my @v;
                for ^$n -> $i {
                    unless self!valid($valid, $i) { @v.push(Any); next }
                    @v.push((($raw[$i div 8] +> ($i % 8)) +& 1) == 1);
                }
                return @v.List;
            }
            when 'utf8' | 'large-utf8' | 'binary' | 'large-binary' {
                my Buf $off = self!buffer;
                my Buf $raw = self!buffer;
                my Bool $wide = $kind.starts-with('large');
                my Bool $is-text = $kind.ends-with('utf8');
                my @v;
                for ^$n -> $i {
                    unless self!valid($valid, $i) { @v.push(Any); next }
                    my Int $a = $wide
                        ?? Reader.new(:buf($off), :pos($i * 8)).i64
                        !! Reader.new(:buf($off), :pos($i * 4)).i32;
                    my Int $b = $wide
                        ?? Reader.new(:buf($off), :pos(($i + 1) * 8)).i64
                        !! Reader.new(:buf($off), :pos(($i + 1) * 4)).i32;
                    my Int $len = ($b - $a) max 0;
                    my Buf $slice = $len ?? $raw.subbuf($a, $len) !! Buf.new;
                    @v.push($is-text ?? $slice.decode('utf-8') !! $slice);
                }
                return @v.List;
            }
            when 'decimal' {
                my Buf $raw = self!buffer;
                my Int $bits = %t<bits> // 128;
                my Int $w = ($bits / 8).Int;
                my Int $scale = %t<scale> // 0;
                my @v;
                for ^$n -> $i {
                    unless self!valid($valid, $i) { @v.push(Any); next }
                    my Int $v = self!int-at($raw, $i * $w, $w, True);
                    @v.push($scale == 0 ?? $v !! ($v / (10 ** $scale)));
                }
                return @v.List;
            }
            default {
                arrow-fail("字段 '{%field<name>}' 的类型 {$kind} 没有对应的解码分支");
            }
        }
    }

    method !bits-for(Str $kind, %t --> Int) {
        $kind eq 'timestamp' | 'duration' ?? 64 !! 32;
    }

    method !int-at(Buf $raw, Int $off, Int $width, Bool $signed --> Int) {
        arrow-fail("整数缓冲区不够：要读 {$width} 字节 @ {$off}，实际 {$raw.elems}")
            if $off + $width > $raw.elems;
        my UInt $v = 0;
        for ^$width -> $i { $v += $raw[$off + $i] * (256 ** $i) }
        return $v unless $signed;
        my Int $sign = 2 ** ($width * 8 - 1);
        $v >= $sign ?? $v - 2 * $sign !! $v;
    }

    method !float-at(Buf $raw, Int $off, Str $prec --> Num) {
        arrow-fail("浮点缓冲区不够：要读 @ {$off}") if $off + ($prec eq 'half' ?? 2 !! $prec eq 'single' ?? 4 !! 8) > $raw.elems;
        given $prec {
            when 'half' { self!half-to-num($raw.read-uint16($off)) }
            when 'single' { $raw.read-num32($off) }
            default { $raw.read-num64($off) }
        }
    }

    # IEEE 754 半精度 → 双精度（Arrow 允许 float16，pandas 不常写，但要能读）。
    method !half-to-num(Int $h --> Num) {
        my Int $sign = ($h +> 15) +& 1;
        my Int $exp = ($h +> 10) +& 0x1F;
        my Int $frac = $h +& 0x3FF;
        my Num $val;
        if $exp == 0 { $val = $frac / 1024 * (2 ** -14) }
        elsif $exp == 0x1F { $val = $frac == 0 ?? Inf !! NaN }
        else { $val = (1 + $frac / 1024) * (2 ** ($exp - 15)) }
        $sign ?? -$val !! $val;
    }

    method !convert(Str $kind, %t, Int $v) {
        given $kind {
            when 'date' {
                my $base = Date.new('1970-01-01');
                return (%t<unit> // 'day') eq 'day'
                    ?? ($base + $v).DateTime
                    !! DateTime.new(Instant.from-posix(($v / 1000).Num));
            }
            when 'timestamp' {
                my Str $u = %t<unit> // 's';
                # 除法在 Raku 里给 Rat，而 Instant.from-posix 要 Num。
                my Num $secs = ($u eq 's'  ?? $v
                              !! $u eq 'ms' ?? $v / 1000
                              !! $u eq 'us' ?? $v / 1_000_000
                              !! $v / 1_000_000_000).Num;
                return DateTime.new(Instant.from-posix($secs));
            }
            when 'time' | 'duration' {
                # 时间/时长没有跨日语义：换算成秒，保留成数字最不容易误导。
                my Str $u = %t<unit> // 's';
                return $u eq 's' ?? $v !! $u eq 'ms' ?? ($v / 1000).Num
                    !! $u eq 'us' ?? ($v / 1_000_000).Num !! ($v / 1_000_000_000).Num;
            }
            default { $v }
        }
    }
}

sub arrow-type-of(%type --> Str) {
    given %type<kind> {
        when 'int' | 'bool' { $_ }
        when 'float' | 'decimal' | 'time' | 'duration' { 'num' }
        when 'date' | 'timestamp' { 'datetime' }
        when 'utf8' | 'large-utf8' | 'binary' | 'large-binary' { 'str' }
        default { 'any' }
    }
}

sub table-from-batches(@fields, @batches --> Rakuish::Data::Table) {
    my @columns = @fields.map({ .<name> });
    my @rows;
    for @batches -> @cols {
        my Int $n = @cols.elems ?? @cols[0].elems !! 0;
        for ^$n -> $i {
            my %r;
            for @columns.kv -> $ci, $name {
                %r{$name} = @cols[$ci][$i];
            }
            @rows.push(%r);
        }
    }
    my %types;
    for @fields -> %f { %types{%f<name>} = arrow-type-of(%f<type>) }
    Rakuish::Data::Table.new(:columns(@columns), :rows(@rows), :%types);
}

# ── 对外：读 ─────────────────────────────────────────────────────────
our sub ipc-format(Buf $data --> Str) is export {
    return '' if $data.elems < 8;
    # 流格式没有 magic：前 6 字节可能是任意二进制，decode 会抛，所以要 try。
    my $magic = try { $data.subbuf(0, 6).decode('ascii') };
    return 'file' if $magic.defined && $magic eq 'ARROW1';
    # 流格式没有 magic，靠首条消息是不是 Schema 判断。
    # 别写 `my %m = try {...}`：try 失败返回 Nil，而把 Nil / 奇数长度 List
    # 塞进 Hash 会在 **try 之外**抛 X::Hash::Store::OddNumber（实测把文本文件
    # 改名 .arrow 就是这个怪错）。先绑标量，判完再用。
    my $m = try { read-message($data, 0) };
    return '' unless $m.defined && $m ~~ Hash;
    $m<header> == MSG-SCHEMA ?? 'stream' !! '';
}

# ── 压缩检测（0.118.3 / V-313）──────────────────────────────────────
# Arrow::IPC 0.1.0 **不处理 BodyCompression，也不报错**：压缩的 body 会被
# 当成裸 buffer 解成垃圾（实测 compressed.arrow 的真值 [1,2,3] →
# 24 / 46469901123040552 / 844433520156672）。读侧交给它之前先用这条扫描
# 拦一次：只看消息元数据（Footer 的 block 偏移 + RecordBatch 的第 4 个字段），
# 不碰 body，成本 O(批数)。
our sub ipc-compressed(Buf $data --> Bool) is export {
    my Str $fmt = ipc-format($data);
    return False unless $fmt.chars;

    if $fmt eq 'file' {
        return False if $data.elems < 18;
        my Int $flen = Reader.new(:buf($data), :pos($data.elems - 10)).u32;
        return False if $flen <= 0 || $flen + 10 > $data.elems;
        my $footer = root-table($data, $data.elems - 10 - $flen);
        my (Int $blen, Int $bstart) = $footer.vec(3, 24, 8);
        for ^$blen -> $i {
            my $r = Reader.new(:buf($data), :pos($bstart + 24 * $i));
            my %m = read-message($data, $r.i64);
            return True
                if (%m<header> // 0) == MSG-BATCH && %m<table>.has(3);
        }
        return False;
    }

    my Int $pos = 0;
    while $pos + 8 <= $data.elems {
        my $m = try { read-message($data, $pos) };
        last unless $m.defined && $m ~~ Hash;
        my %msg = $m.Hash;
        return True if %msg<header> == MSG-BATCH && %msg<table>.has(3);
        $pos = %msg<next-pos> + %msg<body-len>;
        $pos++ while $pos % 8 && $pos < $data.elems;
    }
    False;
}

our sub ipc-compressed-file(Str $path --> Bool) is export {
    ipc-compressed(slurp($path, :bin));
}

# 有几个 RecordBatch（文件看 Footer 的 Block 向量，流就数一遍消息头）。
# 诊断用：多批写完之后可以直接确认「确实是 3 批而不是 1 批」。
our sub ipc-batch-count(Buf $data --> Int) is export {
    my Str $fmt = ipc-format($data);
    return 0 unless $fmt.chars;
    if $fmt eq 'file' {
        return 0 if $data.elems < 18;
        my Int $flen = Reader.new(:buf($data), :pos($data.elems - 10)).u32;
        return 0 if $flen <= 0 || $flen + 10 > $data.elems;
        my $footer = root-table($data, $data.elems - 10 - $flen);
        return $footer.vec(3, 24, 8)[0];
    }
    my Int $pos = 0;
    my Int $n = 0;
    while $pos + 8 <= $data.elems {
        my $m = try { read-message($data, $pos) };
        last unless $m.defined && $m ~~ Hash;
        $n++ if ($m<header> // 0) == MSG-BATCH;
        $pos = $m<next-pos> + $m<body-len>;
        $pos++ while $pos % 8 && $pos < $data.elems;
    }
    $n;
}

our sub read-ipc(Buf $data --> Rakuish::Data::Table) is export {
    my Str $fmt = ipc-format($data);
    arrow-fail('不是 Arrow IPC 数据（文件模式缺 ARROW1 头，流模式首条消息也不是 Schema）')
        unless $fmt.chars;

    if $fmt eq 'file' {
        arrow-fail('文件太短，放不下尾部标记') if $data.elems < 18;
        arrow-fail('文件尾部缺少 ARROW1 标记')
            unless $data.subbuf($data.elems - 6, 6).decode('ascii') eq 'ARROW1';
        my Int $flen = Reader.new(:buf($data), :pos($data.elems - 10)).u32;
        arrow-fail("Footer 长度不合理：{$flen}") if $flen <= 0 || $flen + 10 > $data.elems;
        my Int $fpos = $data.elems - 10 - $flen;
        my $footer = root-table($data, $fpos);
        my @fields = parse-fields($footer.table(1));
        my (Int $blen, Int $bstart) = $footer.vec(3, 24, 8);
        my @batches;
        for ^$blen -> $i {
            my $r = Reader.new(:buf($data), :pos($bstart + 24 * $i));
            my Int $off = $r.i64;
            my %msg = read-message($data, $off);
            arrow-fail("Footer 指向的记录批（offset={$off}）不是 RecordBatch")
                unless (%msg<header> // 0) == MSG-BATCH;
            @batches.push(decode-batch($data, %msg, @fields));
        }
        return table-from-batches(@fields, @batches);
    }

    # 流格式：Schema 打头，随后若干 RecordBatch，没有 Footer。
    my Int $pos = 0;
    my @fields;
    my @batches;
    my Bool $seen-schema = False;
    while $pos + 8 <= $data.elems {
        # 别写成 `my %msg = try {...}`：流末尾读不出来时 try 返回 Nil，
        # 把 Nil 赋给 Hash 会报「Odd number of elements」。
        my $m = try { read-message($data, $pos) };
        last unless $m.defined && $m ~~ Hash;
        my %msg = $m.Hash;
        given %msg<header> {
            when MSG-SCHEMA { @fields = parse-fields(%msg<table>); $seen-schema = True }
            when MSG-BATCH  { @batches.push(decode-batch($data, %msg, @fields)) }
            when MSG-DICTIONARY {
                arrow-unsupported('流里有字典批（DictionaryBatch），暂不支持字典编码的列');
            }
        }
        $pos = %msg<next-pos> + %msg<body-len>;
        # body 之后按 8 字节对齐
        $pos++ while $pos % 8 && $pos < $data.elems;
    }
    arrow-fail('流里没有 Schema 消息') unless $seen-schema;
    table-from-batches(@fields, @batches);
}

sub decode-batch(Buf $data, %msg, @fields --> List) {
    my $rb = %msg<table>;
    arrow-unsupported('记录批带 BodyCompression，暂不支持压缩的 Arrow（请用未压缩导出）')
        if $rb.has(3);
    my (Int $nlen, Int $nstart) = $rb.vec(1, 16, 8);
    my (Int $blen, Int $bstart) = $rb.vec(2, 16, 8);
    my @nodes;
    for ^$nlen -> $i {
        my $r = Reader.new(:buf($data), :pos($nstart + 16 * $i));
        @nodes.push(%( length => $r.i64, null-count => $r.i64 ));
    }
    my @buffers;
    for ^$blen -> $i {
        my $r = Reader.new(:buf($data), :pos($bstart + 16 * $i));
        @buffers.push(%( offset => $r.i64, length => $r.i64 ));
    }
    my Int $body-len = (%msg<body-len> // 0).Int;
    arrow-fail("记录批声明的 body 长度 {$body-len} 超出数据范围")
        if %msg<next-pos> + $body-len > $data.elems;
    my Buf $body = $body-len > 0 ?? $data.subbuf(%msg<next-pos>, $body-len) !! Buf.new;
    my $dec = Decoder.new(:$body, :@nodes, :@buffers);
    my @cols = @fields.map({ $dec.column($_) });
    @cols.List;
}

our sub read-ipc-file(Str $path --> Rakuish::Data::Table) is export {
    my $io = $path.IO;
    arrow-fail("文件不存在：{$path}") unless $io.e;
    arrow-fail("不是普通文件：{$path}") unless $io.f;
    read-ipc($io.slurp(:bin));
}

# ══════════════════════════════════════════════════════════════════════
# 写：FlatBuffers 构造器
# ══════════════════════════════════════════════════════════════════════
# FlatBuffers 是**从后往前**写的：新字节总落在更低地址，所以内部用反向表存，
# 最后翻一次。字段偏移写的是「表起点往前多少」，因此表必须先于引用者写完。
my sub le32(Int $v --> List) {
    my UInt $u = $v +& 0xFFFF_FFFF;
    (($u +& 0xFF), (($u +> 8) +& 0xFF), (($u +> 16) +& 0xFF), (($u +> 24) +& 0xFF));
}
my sub le64(Int $v --> List) {
    my UInt $u = $v +& 0xFFFF_FFFF_FFFF_FFFF;
    (^8).map({ ($u +> (8 * $_)) +& 0xFF }).List;
}

class Builder {
    has @!rev;                  # 反向字节：@!rev[0] 是缓冲区最后一个字节
    has @!vtable;
    has Int $!object-start = 0;
    has Int $!minalign = 1;
    has @!patches;              # (距末尾位置, i32 值)：表头的 soffset 最后回填

    method size(--> Int) { @!rev.elems }

    method !pad(Int $n --> Nil) { @!rev.unshift(0) for ^$n; Nil }

    method !align(Int $size, Int $additional = 0 --> Nil) {
        $!minalign = $size if $size > $!minalign;
        my Int $rem = (self.size + $additional) % $size;
        self!pad($size - $rem) if $rem;
        Nil
    }
    # 顺序 unshift：最后 unshift 的那个落在下标 0（= 最高地址），
    # 于是 @bytes 的**最后一个**字节贴着前一次写入的位置 —— 正是我们要的。
    # 写成 `.reverse` 会把整块字节序翻过来（0.116.0 第一版就是这么错的：
    # 写出来的 footer 根偏移是 0x6e000000 而不是 0x0000006e）。
    method !place(@bytes --> Nil) { @!rev.unshift($_) for @bytes.reverse; Nil }

    method u8(Int $v --> Nil)  { self!align(1); self!place(($v +& 0xFF,)) }
    method u16(Int $v --> Nil) {
        self!align(2);
        self!place((($v +& 0xFF), (($v +> 8) +& 0xFF)));
    }
    method u32(Int $v --> Nil) { self!align(4); self!place(le32($v)) }
    method i16(Int $v --> Nil) { self.u16($v) }
    method i32(Int $v --> Nil) { self.u32($v) }
    method i64(Int $v --> Nil) { self!align(8); self!place(le64($v)) }
    method f64(Num $v --> Nil) {
        my Buf $b = Buf.new(0 xx 8);
        $b.write-num64(0, $v);
        self!align(8);
        self!place($b.list);
    }
    # 结构体：按内存镜像整块写，避免逐字段对齐算错
    method struct-bytes(@bytes, Int $align = 8 --> Nil) {
        self!align($align);
        self!place(@bytes);
    }

    method uoffset(Int $off --> Nil) {
        self!align(4);
        my Int $v = $off == 0 ?? 0 !! (self.size - $off + 4);
        self!place(le32($v));
        Nil
    }
    method create-string(Str $s --> Int) {
        my @bytes = $s.encode('utf-8').list;
        self!align(4, @bytes.elems + 1);
        self!place((0,));               # 结尾 NUL（最高地址）
        self!place(@bytes);
        self!place(le32(@bytes.elems)); # 长度（最低地址，已对齐过）
        self.size;
    }
    method start-vector(Int $elem-size, Int $n, Int $align --> Nil) {
        self!align(4, $elem-size * $n);
        self!align($align, $elem-size * $n);
        Nil
    }
    method end-vector(Int $n --> Int) {
        self!place(le32($n));
        self.size;
    }
    method start-table(Int $n --> Nil) {
        @!vtable = (0 xx $n).Array;
        $!object-start = self.size;
        Nil
    }
    method !slot(Int $i --> Nil) { @!vtable[$i] = self.size }
    method add-uoffset(Int $i, Int $off --> Nil) {
        return unless $off;
        self.uoffset($off);
        self!slot($i);
        Nil
    }
    method add-u8(Int $i, Int $v, Int $default = 0 --> Nil) {
        return if $v == $default;
        self.u8($v);
        self!slot($i);
        Nil
    }
    method add-bool(Int $i, Bool $v, Bool $default = False --> Nil) {
        self.add-u8($i, $v ?? 1 !! 0, $default ?? 1 !! 0);
        Nil
    }
    method add-i16(Int $i, Int $v, Int $default = 0 --> Nil) {
        return if $v == $default;
        self.i16($v);
        self!slot($i);
        Nil
    }
    method add-i32(Int $i, Int $v, Int $default = 0 --> Nil) {
        return if $v == $default;
        self.i32($v);
        self!slot($i);
        Nil
    }
    method add-i64(Int $i, Int $v, Int $default = 0 --> Nil) {
        return if $v == $default;
        self.i64($v);
        self!slot($i);
        Nil
    }
    method end-table(--> Int) {
        self!align(4);
        self!place((0, 0, 0, 0));           # 表起点：稍后回填 soffset
        my Int $obj = self.size;
        my Int $n = @!vtable.elems;
        $n-- while $n > 0 && @!vtable[$n - 1] == 0;
        if $n > 0 {
            for ($n - 1) ... 0 -> $i {
                my Int $off = @!vtable[$i];
                my Int $v = $off == 0 ?? 0 !! ($obj - $off);
                self!align(2);
                self!place((($v +& 0xFF), (($v +> 8) +& 0xFF)));
            }
        }
        my Int $osize = $obj - $!object-start;
        self!align(2);
        self!place((($osize +& 0xFF), (($osize +> 8) +& 0xFF)));
        my Int $vsize = ($n + 2) * 2;
        self!align(2);
        self!place((($vsize +& 0xFF), (($vsize +> 8) +& 0xFF)));
        my Int $vt = self.size;
        @!patches.push(($obj, $vt - $obj));
        $obj;
    }
    method finish(Int $root --> Buf) {
        self!align($!minalign, 4);
        self.uoffset($root);
        my Int $total = self.size;
        # @!rev 现在是**正序**：每个新块插在最前，所以下标 0 就是缓冲区首字节。
        # （这里曾经写过 `.reverse`，结果整份缓冲区被翻过来 —— 根偏移跑到末尾。）
        my @abs = @!rev;
        for @!patches -> @p {
            my Int $at = $total - @p[0];
            my Int $v = @p[1];
            for ^4 -> $k { @abs[$at + $k] = ($v +> (8 * $k)) +& 0xFF }
        }
        Buf.new(@abs);
    }
}

# ── Arrow 的 FlatBuffers 形状 ────────────────────────────────────────
my constant V5 = 4;   # MetadataVersion：V1..V5 = 0..4

my constant %TYPE-CODE =
    null => 1, int => 2, float => 3, binary => 4, utf8 => 5, bool => 6,
    decimal => 7, date => 8, time => 9, timestamp => 10, duration => 18;

sub build-type-table(Builder $b, %t --> Int) {
    given %t<kind> {
        when 'int' {
            $b.start-table(2);
            $b.add-i32(0, %t<bits> // 64, 32);
            $b.add-bool(1, %t<signed> // True, False);
            $b.end-table;
        }
        when 'float' {
            my Int $p = (%t<precision> // 'double') eq 'half' ?? 0
                      !! (%t<precision> // 'double') eq 'single' ?? 1 !! 2;
            $b.start-table(1);
            $b.add-i16(0, $p, 0);
            $b.end-table;
        }
        when 'timestamp' {
            my Int $u = (%t<unit> // 'ms') eq 's' ?? 0 !! (%t<unit> // 'ms') eq 'ms' ?? 1
                      !! (%t<unit> // 'ms') eq 'us' ?? 2 !! 3;
            $b.start-table(2);
            $b.add-i16(0, $u, 0);
            $b.end-table;
        }
        when 'bool' | 'utf8' | 'binary' | 'null' {
            $b.start-table(0);
            $b.end-table;
        }
        default {
            arrow-fail("写 Arrow 时不支持类型 {%t<kind>}（可写 int / num / bool / str / datetime）");
        }
    }
}

sub build-field(Builder $b, %f --> Int) {
    my Int $name = $b.create-string(%f<name>);
    my Int $type = build-type-table($b, %f<type>);
    $b.start-table(7);
    $b.add-bool(1, %f<nullable> // False, False);
    $b.add-u8(2, %TYPE-CODE{%f<type><kind>} // 0, 0);
    $b.add-uoffset(3, $type);
    $b.add-uoffset(0, $name);
    $b.end-table;
}

sub build-schema-table(Builder $b, @fields --> Int) {
    my @offs = @fields.map({ build-field($b, $_) }).List;
    my Int $vec = 0;
    if @offs.elems {
        $b.start-vector(4, @offs.elems, 4);
        for @offs.reverse -> $o { $b.uoffset($o) }
        $vec = $b.end-vector(@offs.elems);
    }
    $b.start-table(4);
    $b.add-i16(0, 0, 0);              # LittleEndian
    $b.add-uoffset(1, $vec);
    $b.end-table;
}

# Message.bodyLength 必须和 Block.bodyLength 一致，否则 pyarrow 会拒收
# （报 "Mismatching body length for IPC message"）。
sub build-message-meta(Builder $b, Int $header-type, Int $header, Int $body-len = 0 --> Buf) {
    $b.start-table(5);
    $b.add-i16(0, V5, 0);
    $b.add-u8(1, $header-type, 0);
    $b.add-uoffset(2, $header);
    $b.add-i64(3, $body-len, 0);
    $b.end-table.&{ $b.finish($_) };
}

sub build-nodes(Builder $b, @nodes --> Int) {
    return 0 unless @nodes.elems;
    $b.start-vector(16, @nodes.elems, 8);
    for @nodes.reverse -> %n {
        $b.struct-bytes((|le64(%n<length>), |le64(%n<null-count>)), 8);
    }
    $b.end-vector(@nodes.elems);
}

sub build-buffers(Builder $b, @buffers --> Int) {
    return 0 unless @buffers.elems;
    $b.start-vector(16, @buffers.elems, 8);
    for @buffers.reverse -> %bf {
        $b.struct-bytes((|le64(%bf<offset>), |le64(%bf<length>)), 8);
    }
    $b.end-vector(@buffers.elems);
}

sub build-blocks(Builder $b, @blocks --> Int) {
    return 0 unless @blocks.elems;
    $b.start-vector(24, @blocks.elems, 8);
    for @blocks.reverse -> %bl {
        # Block = offset(i64) + metaDataLength(i32) + 4 字节填充 + bodyLength(i64)
        $b.struct-bytes((|le64(%bl<offset>), |le32(%bl<meta-length>), |(0, 0, 0, 0),
                         |le64(%bl<body-length>)), 8);
    }
    $b.end-vector(@blocks.elems);
}

sub build-record-batch(Builder $b, Int $rows, @nodes, @buffers --> Int) {
    my Int $nvec = build-nodes($b, @nodes);
    my Int $bvec = build-buffers($b, @buffers);
    $b.start-table(5);
    $b.add-i64(0, $rows, 0);
    $b.add-uoffset(1, $nvec);
    $b.add-uoffset(2, $bvec);
    $b.end-table;
}

# ── 编码一列 ─────────────────────────────────────────────────────────
sub arrow-type-for(Str $kind --> Hash) {
    given $kind {
        when 'int'      { %( kind => 'int', bits => 64, signed => True ) }
        when 'num'      { %( kind => 'float', precision => 'double' ) }
        when 'bool'     { %( kind => 'bool' ) }
        when 'datetime' { %( kind => 'timestamp', unit => 'ms', tz => '' ) }
        default         { %( kind => 'utf8' ) }
    }
}

sub as-bits(@flags --> Buf) {
    my Int $n = @flags.elems;
    (return Buf.new) unless $n;
    my Buf $b = Buf.new(0 xx (($n + 7) div 8));
    for ^$n -> $i { $b[$i div 8] += 1 +< ($i % 8) if @flags[$i] }
    $b;
}

sub encode-column(@values, %type --> Hash) {
    my Int $n = @values.elems;
    my @valid = @values.map({ .defined });
    my Int $nulls = @valid.grep(*.not).elems;
    my @pairs;                       # (offset-from-start, byte)
    my Buf $data = Buf.new;

    given %type<kind> {
        when 'int' {
            for @values -> $v { $data.append: Buf.new(le64($v.defined ?? $v.Int !! 0)) }
        }
        when 'float' {
            my Buf $tmp = Buf.new(0 xx 8);
            for @values -> $v {
                $tmp.write-num64(0, $v.defined ?? $v.Num !! 0e0);
                $data.append: $tmp;
            }
        }
        when 'bool' {
            $data = as-bits(@values.map({ .defined && $_.Bool }));
        }
        when 'timestamp' {
            my $epoch = DateTime.new('1970-01-01T00:00:00Z');
            for @values -> $v {
                my Int $ms;
                $ms = 0 unless $v.defined;
                if $v.defined {
                    if $v ~~ DateTime | Instant {
                        my $dt = $v ~~ Instant ?? $v.DateTime !! $v;
                        # 用 posix（UTC 秒）+ 小数部分。**别用 Instant.Num**：
                        # 它按 TAI 计，含闰秒（2020 年的值会多出 37 秒），
                        # 写进 Arrow 就变成一个偏移的时间戳。
                        $ms = (($dt.posix + ($dt.second - $dt.whole-second)) * 1000).round.Int;
                    } else {
                        $ms = $v.Int;
                    }
                }
                $data.append: Buf.new(le64($ms // 0));
            }
        }
        default {
            my Buf $offs = Buf.new;
            my Buf $raw = Buf.new;
            my Int $at = 0;
            $offs.append: Buf.new(le32(0));
            for @values -> $v {
                if $v.defined {
                    my Buf $enc = $v.Str.encode('utf-8').Buf;
                    $raw.append: $enc;
                    $at += $enc.elems;
                }
                $offs.append: Buf.new(le32($at));
            }
            return %(
                node    => %( length => $n, null-count => $nulls ),
                buffers => (($nulls ?? as-bits(@valid) !! Buf.new), $offs, $raw),
            );
        }
    }
    %(
        node    => %( length => $n, null-count => $nulls ),
        buffers => (($nulls ?? as-bits(@valid) !! Buf.new), $data),
    );
}

sub pad-buf(Buf $b, Int $to = 8 --> Buf) {
    my Int $rem = $b.elems % $to;
    $rem ?? Buf.new((|$b.list, |(0 xx ($to - $rem)))) !! $b;
}

sub meta-block(Buf $meta, Buf $body --> Buf) {
    my Buf $m = pad-buf($meta);
    my Buf $out = Buf.new(0xFF, 0xFF, 0xFF, 0xFF);
    $out.append: Buf.new(le32($m.elems));
    $out.append: $m;
    $out.append: $body;
    $out;
}

sub fields-of(Rakuish::Data::Table $t, @rows = $t.rows --> List) {
    my @fields;
    for $t.columns -> $c {
        my Str $name = $c.Str;
        my Str $kind = ($t.types{$name} // 'str').Str;
        my @vals = @rows.map({ $_{$name} // Any });
        # 0.120.0：嵌套列以前落到 default → utf8，值走 `.Str`，结果写成
        # `age\t30\nname\tann` 这种噪声（Hash 的 Str 形态）——看起来成功、
        # 实际数据已经毁了。写侧目前只做标量列，宁可明确拒绝。
        # 类型标成 list/map 固然要拒；类型标错（str 里塞 Hash）也一样。
        my $nested = $kind eq 'list' | 'map'
            || @vals.first({ .defined && ($_ ~~ Positional | Associative) }).defined;
        if $nested {
            arrow-fail("写侧不支持嵌套列（{$name}"
                ~ ($kind eq 'list' | 'map' ?? ": {$kind}" !! '') ~ "）："
                ~ "先用 select 掉这列，或 to-json 转成字符串列再写。"
                ~ "（读侧支持嵌套：open-data / Table.sql 都能处理）");
        }
        my %type = arrow-type-for($kind);
        my Bool $nullable = @vals.grep({ !.defined }).elems > 0;
        @fields.push(%( name => $name, type => %type, nullable => $nullable, values => @vals.List ));
    }
    @fields.List;
}

# Schema 部分（不带行值）：多批/流式时 schema 只推断一次，之后每批复用。
my sub schema-fields(@fields --> List) {
    @fields.map({ %( name => .<name>, type => .<type>, nullable => .<nullable> ) }).List;
}

my sub fields-with-values(@schema, @rows --> List) {
    @schema.map(-> %f {
        my Str $name = %f<name>;
        %( |%f, values => @rows.map({ $_{$name} }).List );
    }).List;
}

# 编码一批：返回 (body, nodes, buffers)。多批时每批独立调一次，
# 于是编码峰值从「整表」降到「一批」。
my sub encode-fields(@fields --> Hash) {
    my @nodes;
    my @buffers;
    my Buf $body = Buf.new;
    for @fields -> %f {
        my %enc = encode-column(%f<values>, %f<type>);
        @nodes.push(%enc<node>);
        for %enc<buffers>.list -> Buf $b {
            @buffers.push(%( offset => $body.elems, length => $b.elems ));
            $body.append: pad-buf($b);
        }
    }
    %( body => $body, nodes => @nodes.List, buffers => @buffers.List );
}

# ══════════════════════════════════════════════════════════════════════
# 写：增量写入器（0.121.0 / V-317）
# ══════════════════════════════════════════════════════════════════════
# 旧实现把「schema + 一个 RecordBatch + footer」一次性拼进一个 Buf，于是
# 写 50 万行时峰值内存 = 表 + 整份文件。这里拆成「start / add-batch / finish」，
# sink 既可以是内存 Buf（write-ipc），也可以是文件句柄（write-ipc-stream），
# 后者写完一批就吐出去，内存里只剩一批。
class IpWriter {
    has Str $!format = 'file';
    has $!fh;
    has Buf $!buf = Buf.new;
    has Int $!offset = 0;
    has @!fields;
    has @!blocks;
    has Bool $!started = False;

    submethod BUILD(Str :$format = 'file', :$fh = Nil) {
        $!format = $format;
        $!fh = $fh;
    }

    method started(--> Bool) { $!started }
    method bytes(--> Int) { $!offset }
    method batch-count(--> Int) { @!blocks.elems }

    method !emit(Buf $b --> Nil) {
        $!offset += $b.elems;
        if $!fh.defined { $!fh.write($b) } else { $!buf.append($b) }
        Nil;
    }

    method start(@schema --> Nil) {
        return if $!started;
        @!fields = @schema.List;
        my $sb = Builder.new;
        my Int $schema = build-schema-table($sb, @!fields);
        my Buf $meta = build-message-meta($sb, MSG-SCHEMA, $schema, 0);
        self!emit(Buf.new((|'ARROW1'.encode('ascii').list, 0, 0))) if $!format eq 'file';
        self!emit(meta-block($meta, Buf.new));
        $!started = True;
        Nil;
    }

    method add-batch(@fields-with-values --> Nil) {
        arrow-fail('先写 Schema 再加记录批（内部错误）') unless $!started;
        return unless @fields-with-values.elems;
        my %enc = encode-fields(@fields-with-values);
        my Buf $body = %enc<body>;
        my @nodes = %enc<nodes>.List;
        my @buffers = %enc<buffers>.List;
        my Int $rows = @fields-with-values[0]<values>.elems;
        my $rb = Builder.new;
        my Int $batch = build-record-batch($rb, $rows, @nodes, @buffers);
        my Buf $meta = build-message-meta($rb, MSG-BATCH, $batch, $body.elems);
        my Buf $mb = meta-block($meta, $body);
        if $!format eq 'file' {
            # Block 的 offset 是**文件内绝对偏移**，所以记的是本批 metadata 起点。
            @!blocks.push(%(
                offset      => $!offset,
                meta-length => $mb.elems - $body.elems,
                body-length => $body.elems,
            ));
        }
        self!emit($mb);
        Nil;
    }

    method finish(--> Buf) {
        arrow-fail('还没写 Schema 就收尾（内部错误）') unless $!started;
        return $!buf if $!format eq 'stream';
        my $fb = Builder.new;
        my Int $fschema = build-schema-table($fb, @!fields);
        my Int $blocks = build-blocks($fb, @!blocks);
        $fb.start-table(5);
        $fb.add-i16(0, V5, 0);
        $fb.add-uoffset(1, $fschema);
        $fb.add-uoffset(3, $blocks);
        my Int $footer = $fb.end-table;
        my Buf $footer-buf = $fb.finish($footer);
        self!emit($footer-buf);
        self!emit(Buf.new(le32($footer-buf.elems)));
        self!emit(Buf.new('ARROW1'.encode('ascii').list));
        $!buf;
    }
}

my sub feed-batches(IpWriter $w, Rakuish::Data::Table $t, @schema, @fields, Int $batch-size) {
    if $batch-size.defined && $batch-size < $t.rows.elems {
        for $t.batches(:size($batch-size)) -> $chunk {
            $w.add-batch(fields-with-values(@schema, $chunk.rows));
        }
    } else {
        $w.add-batch(@fields);
    }
    Nil;
}

# 先写 <文件名>.part，成功后才改名 —— 中途失败（类型冲突、磁盘满）不会
# 把目标路径留成半截 Arrow 文件。
my sub atomic-bin-write(Str $path, &writer --> Nil) {
    my IO::Path $target = $path.IO;
    $target.parent.mkdir unless $target.parent.e;
    my IO::Path $part = $target.parent.add($target.basename ~ '.part');
    my $fh = $part.open(:w, :bin);
    my Bool $done = False;
    LEAVE {
        $fh.close if $fh.opened;
        $part.unlink if !$done && $part.e;
    }
    writer($fh);
    $fh.close;
    $target.unlink if $target.e;
    $part.rename($target);
    $done = True;
    Nil;
}

# 流式写时的类型守卫：schema 由首批推断，之后不能回改，所以遇到冲突必须
# 当场报错。`"abc".Int` 在 Raku 里是 0（不抛），静默写下去就是脏数据。
my sub check-batch(@schema, @rows, Int $base --> Nil) {
    for @schema -> %f {
        my Str $name = %f<name>;
        my Str $kind = (%f<type><kind> // 'utf8');
        my Str $expect = $kind eq 'int' ?? 'int'
            !! $kind eq 'float' ?? 'num'
            !! $kind eq 'bool' ?? 'bool'
            !! $kind eq 'timestamp' ?? 'datetime' !! 'str';
        for @rows.kv -> $i, $row {
            my $v = $row{$name};
            next unless $v.defined;
            arrow-fail("流式写第 {$base + $i + 1} 行的列「{$name}」是嵌套值（{$v.WHAT.^name}）："
                ~ "写侧只做标量列，请先 to-json 转成字符串列")
                if $v ~~ Positional | Associative;
            my Bool $ok = $expect eq 'int'      ?? $v ~~ Int
                       !! $expect eq 'num'      ?? $v ~~ Numeric
                       !! $expect eq 'bool'     ?? $v ~~ Bool
                       !! $expect eq 'datetime' ?? $v ~~ (DateTime | Instant | Int)
                       !! $v ~~ (Str | Numeric | Bool);
            arrow-fail("流式写第 {$base + $i + 1} 行的列「{$name}」类型对不上："
                ~ "schema 按首批定为 {$expect}，这行是 {$v.WHAT.^name}（{$v.raku}）。"
                ~ "流式写不能回头改 schema —— 先统一类型，或改用 write-ipc 全表写") unless $ok;
        }
    }
    Nil;
}

my sub check-columns(@schema, Rakuish::Data::Table $t --> Nil) {
    my @want = @schema.map(*.<name>).List;
    my @got = $t.columns.map(*.Str).List;
    arrow-fail("流里的表列对不上：schema 是 [@want.join(', ')]，这张表是 [@got.join(', ')]")
        unless @want.sort.List eqv @got.sort.List;
    Nil;
}

# ── 对外：写 ─────────────────────────────────────────────────────────
#   write-ipc($t)                       一个 RecordBatch（0.120 及以前的行为）
#   write-ipc($t, :batch-size(1000))    按批切开，编码峰值 = 一批
#   write-ipc-stream(行迭代器, $path)   真流式：边读边写，不物化全表
our sub write-ipc(Rakuish::Data::Table $t, Str :$format = 'file',
                  Int :$batch-size --> Buf) is export {
    arrow-fail("未知的 Arrow 输出格式：{$format}（file / stream）")
        unless $format eq 'file' | 'stream';
    arrow-fail("batch-size 必须是正整数（收到 {$batch-size}）")
        if $batch-size.defined && $batch-size < 1;

    my @fields = fields-of($t);
    my @schema = schema-fields(@fields);
    my $w = IpWriter.new(:$format);
    $w.start(@schema);
    feed-batches($w, $t, @schema, @fields, $batch-size);
    $w.finish;
}

our sub write-ipc-file(Rakuish::Data::Table $t, Str $path, Str :$format = 'file',
                       Int :$batch-size --> Nil) is export {
    arrow-fail("未知的 Arrow 输出格式：{$format}（file / stream）")
        unless $format eq 'file' | 'stream';
    arrow-fail("batch-size 必须是正整数（收到 {$batch-size}）")
        if $batch-size.defined && $batch-size < 1;

    my @fields = fields-of($t);
    my @schema = schema-fields(@fields);
    atomic-bin-write($path, -> $fh {
        my $w = IpWriter.new(:$format, :$fh);
        $w.start(@schema);
        feed-batches($w, $t, @schema, @fields, $batch-size);
        $w.finish;
    });
    Nil;
}

# ── 对外：流式写 ─────────────────────────────────────────────────────
# 接受「行的迭代器」或「Table 的迭代器」，每攒够 batch-size 行就编一批写盘，
# 内存里只留一批（= batch-size 行）。返回写入的总行数。
#
#   write-ipc-stream((1..Inf).map({ %(n => $_) }).head(1_000_000), 'big.arrow');
#   write-ipc-stream($t.batches(:size(5000)), 'big.arrow');      # 表批流
#
# 边界：schema 由首批推断后固定，之后类型不符会报错（不会静默截断/转换）；
# 空流要么报错，要么用 :columns 明确列名。
our sub write-ipc-stream($source, Str $path,
                         Int :$batch-size = 1000,
                         Str :$format = 'file',
                         :@columns, :%types --> Int) is export {
    arrow-fail("未知的 Arrow 输出格式：{$format}（file / stream）")
        unless $format eq 'file' | 'stream';
    arrow-fail("batch-size 必须是正整数（收到 {$batch-size}）") unless $batch-size >= 1;

    my $iter = $source.iterator;
    my $first = $iter.pull-one;

    # 空流：没有行就没法推断 schema。给了 :columns 就写一个 0 行的文件。
    if $first ~~ IterationEnd {
        arrow-fail('流里没有任何行，无法推断 schema：'
            ~ '要写空表请用 save-data（先建好 Table），或给出 :columns 明确列名')
            unless @columns.elems;
        my %ty = %types;
        my @schema = @columns.map(-> $c {
            my Str $n = $c.Str;
            %( name => $n, type => arrow-type-for((%ty{$n} // 'str').Str), nullable => True )
        }).List;
        atomic-bin-write($path, -> $fh {
            my $w = IpWriter.new(:$format, :$fh);
            $w.start(@schema);
            $w.add-batch(@schema.map({ %( |$_, values => () ) }).List);
            $w.finish;
        });
        return 0;
    }

    my Int $total = 0;
    my Bool $schema-ready = False;
    my @schema;
    my Bool $table-mode = $first ~~ Rakuish::Data::Table;

    atomic-bin-write($path, -> $fh {
        my $w = IpWriter.new(:$format, :$fh);
        # 注意：block 里的 `return` 在 Raku 中是 non-local 的，会直接返回外层
        # sub（实测第一批写完就整个函数返回、文件没落地）。这里一律用 if 包裹。
        my &prepare = -> $t {
            unless $schema-ready {
                @schema = schema-fields(fields-of($t));
                $w.start(@schema);
                $schema-ready = True;
            }
            Nil;
        };

        if $table-mode {
            # 别写成 `my $seq = ($first, |$iter)`：Iterator 被 slip 时元素会
            # 变成 List（实测 `$t` 拿到 List，`.rows` 直接炸）。手写 pull 循环。
            my $t = $first;
            loop {
                arrow-fail("表流里的元素不是 Table（拿到 {$t.WHAT.^name}）")
                    unless $t ~~ Rakuish::Data::Table;
                if $t.rows.elems {
                    prepare($t);
                    check-columns(@schema, $t);
                    for $t.batches(:size($batch-size)) -> $chunk {
                        check-batch(@schema, $chunk.rows, $total);
                        $w.add-batch(fields-with-values(@schema, $chunk.rows));
                        $total += $chunk.rows.elems;
                    }
                }
                $t = $iter.pull-one;
                last if $t ~~ IterationEnd;
            }
        } else {
            my @pending;
            my &flush = -> {
                if @pending.elems {
                    # 只有首批需要建 Table（推断列与类型）；后续批直接用固定
                    # schema 取名，别每批都 Table.new —— 那会白跑一次类型推断
                    # （实测 50 万行 3 列因此多花约 8 秒）。
                    unless $schema-ready {
                        # 列顺序按 Table 的规则（首行键排序），与 save-data
                        # 从 rows 建表的行为一致。
                        my $t = Rakuish::Data::Table.new(:rows(@pending.List),
                                                         :@columns, :types(%types));
                        prepare($t);
                    }
                    check-batch(@schema, @pending.List, $total);
                    $w.add-batch(fields-with-values(@schema, @pending.List));
                    $total += @pending.elems;
                    @pending = ();
                }
                Nil;
            };

            my $row = $first;
            loop {
                arrow-fail("流里的元素不是行（需要 Hash/Pair，拿到 {$row.WHAT.^name}）")
                    unless $row ~~ Associative;
                @pending.push($row.Hash);
                flush() if @pending.elems >= $batch-size;
                $row = $iter.pull-one;
                last if $row ~~ IterationEnd;
            }
            flush();
        }
        $w.finish;
    });
    $total;
}
