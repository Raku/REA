unit module Rakuish::Result;

use Rakuish::Result::Renderer;

# Rakuish::Result —— API v3 的类型化结果（ADR-0001）。
#
# 约定：
#   · 读 / 写 / 列目录 / stat 这类文件 API **抛异常**（Raku 风格）；
#   · rm / cp / mv 等破坏性或带 dry-run 的操作直接返回 Result；
#   · Agent 边界一律用 Sys.try-op 把异常收敛成 Result，再序列化。
#   · 这里没有 $? / $$ / $0：退出码只作为 Result.code。
#
# 与 v2 的 Rakuish::Result 完全无关：那个类吃 shell 字符串，本模块只吃 Raku 值。

# ── 异常族 ────────────────────────────────────────────────────────────
class X::Rakuish::V3 is Exception is export {
    has Str $.detail is required;
    method message(--> Str) { $!detail }
}

class X::Rakuish::NotFound is X::Rakuish::V3 is export { }
class X::Rakuish::Path    is X::Rakuish::V3 is export { }
class X::Rakuish::Limit   is X::Rakuish::V3 is export { }
# 0.81.0 / ADR-0019：原 `X::Rakuish::Sandbox`。全权限本地 shell 之后不再有
# 沙箱，这个名字保留会误导；它实际表示「越出会话工作目录 / 路径层级过深 /
# 拒绝删除根」——是**防误操作的边界**，不是安全隔离。
class X::Rakuish::Bound is X::Rakuish::V3 is export { }
class X::Rakuish::Exists  is X::Rakuish::V3 is export { }
class X::Rakuish::Unsupported is X::Rakuish::V3 is export { }
# 0.116.0：Arrow IPC 的格式 / 范围问题（不是「不支持这个操作」，而是
# 「这个文件里用了我们没实现的编码」——单独一类，报错时能带上字节位置）。
class X::Rakuish::Arrow is X::Rakuish::Unsupported is export { }
# 0.120.1 / V-316：**文件本身是合法的**，只是用了自研读入器没实现的编码
# （嵌套类型 / 字典 / 压缩）。它和「文件坏了」必须分开：坏文件绝不能交给
# Arrow::IPC —— 那个包对越界元数据没有边界检查，会段错误（实测 rc=139），
# 段错误连 `try` 都接不住。分流时只认这一类才回退。
class X::Rakuish::Arrow::UnsupportedType is X::Rakuish::Arrow is export { }
# 0.102.0：内容与编码不符（典型是拿文本接口读二进制）。
# 以前这里冒的是 X::AdHoc「Malformed UTF-8 near bytes ...」——既不在
# Rakuish 异常族里，也不告诉用户出路。
class X::Rakuish::Encoding  is X::Rakuish::V3 is export { }
# 0.105.0：文件锁冲突（with-lock :non-blocking 拿不到锁时抛）
# 名字不能叫 X::Rakuish::Lock——会遮蔽 Raku 内建 Lock 类，让 Proc 里的
# `my Lock $PTY-LOCK .= new` 编译失败（缺 required detail）。
class X::Rakuish::LockConflict is X::Rakuish::V3 is export { }
# 数据引擎错误统一门面：不把驱动堆栈原样抛给 REPL / Agent（0.64）。
class X::Rakuish::Data is X::Rakuish::V3 is export { }

# ── 文件元数据 ────────────────────────────────────────────────────────
class Stat is export {
    has IO::Path $.path is required;
    has Int  $.size       = 0;
    has Bool $.is-file    = False;
    has Bool $.is-dir     = False;
    has Bool $.is-symlink = False;
    has Bool $.readable   = False;
    has Bool $.writable   = False;
    has Bool $.executable = False;
    has Int  $.mode       = 0;
    has Instant $.modified;          # 取不到时保持未定义，绝不编 1970 年假值

    method type(--> Str) {
        return 'symlink' if $!is-symlink;
        return 'dir'     if $!is-dir;
        return 'file'    if $!is-file;
        'other'
    }

    method to-hash(--> Hash) {
        my %h = path       => $!path.Str,
                size       => $!size,
                type       => self.type,
                is-file    => $!is-file,
                is-dir     => $!is-dir,
                is-symlink => $!is-symlink,
                readable   => $!readable,
                writable   => $!writable,
                executable => $!executable,
                mode       => $!mode;
        %h<modified> = ~$!modified if $!modified.defined;
        %h
    }
}

# ── 写入结果 ──────────────────────────────────────────────────────────
class WriteResult is export {
    has IO::Path $.path is required;
    has Int  $.bytes  = 0;
    has Bool $.atomic = False;   # 是否真的走了 rename；Windows 覆盖降级时为 False
    has Str  $.backup = '';

    method to-hash(--> Hash) {
        my %h = path => $!path.Str, bytes => $!bytes, atomic => $!atomic;
        %h<backup> = $!backup if $!backup.chars;
        %h
    }
}

# ── 统一结果 ──────────────────────────────────────────────────────────
class Result is export {
    has Bool $.ok is required;
    has Int  $.code = 0;
    # 0.101.1：`Mu` 而不是 `Any` —— Raku 的 junction（`1|2` / `any(...)`）
    # 是 Mu 的子类型、不是 Any 的子类型，用 Any 会让合法表达式的求值**崩在
    # Result 构造处**（真机审计发现）。取值语义见 `value-defined`。
    has Mu   $.value;
    has Str  $.out  = '';
    has Str  $.err  = '';
    has Str  $.op   = '';
    has Duration $.elapsed;
    # shell 层的 echo -n：调用方打印时不要追加换行（不影响 value/out）。
    has Bool $.no-newline = False;
    # 0.90.0 / ADR-0024：输出已经在执行过程中实时写给了用户。
    # 此时 out / err 里即使还有副本，render 也不能再打印一遍 —— 否则
    # `! make` 会在结束时把整段输出重放一次。
    has Bool $.streamed = False;
    # 内置命令统一预渲染的 text 结果。空串表示“还没有缓存”，由 text 方法
    # 按需用 render('text') 计算；结构化 value/out/err 仍然保留。
    has Str  $.rendered = '';
    # 0.109.0：内容级展示包（Display::Bundle.to-hash 的形状）。只有前端显式
    # 要求时才由引擎填（notebook 要 MIME 分档，TTY 不需要），默认空 —— 这样
    # 普通格不多付一次 markdown/json 的计算与传输。
    # 名字不能叫 `display`：Result 已有 `method display`（文本摘要），会被遮蔽。
    has %.bundle;

    method Bool(--> Bool) { $!ok }                 # Raku 的 && / || 直接可用
    method lines(--> List) { $!out.lines.List }

    # 「有没有值」不能用 `$!value.defined`：junction（`1|2`）的 `.defined`
    # 会逐分支求值、在布尔上下文里 splat 并抛异常。junction 本身就是值。
    method value-defined(--> Bool) {
        # `~~ Junction` / `.isa` 都会对 junction 逐分支求值（autothread），
        # 只有比对类型对象本身才不会。
        return True if $!value.WHAT === Junction;
        $!value.defined;
    }

    method to-hash(--> Hash) {
        my %h = ok => $!ok, code => $!code, out => $!out, err => $!err;
        # 结构化出口里 junction 转成 `.raku` 字符串：它不是可 JSON 化的
        # 标量，而任何渲染函数收到 junction 参数都会被 Raku 逐分支调用。
        %h<value> = $!value.WHAT === Junction ?? $!value.raku !! $!value
            if self.value-defined;
        %h<op>      = $!op      if $!op.chars;
        %h<elapsed> = ~$!elapsed if $!elapsed.defined;
        %h<streamed> = True if $!streamed;
        %h
    }

    # ── 多格式渲染 ────────────────────────────────────────────────────
    # text / json / markdown；别名 txt / plain、md。未知格式抛
    # X::Rakuish::Render（在 Rakuish::Result::Renderer 里定义）。
    # json 默认紧凑，:pretty 可展开；其余格式忽略额外选项。
    method render(Str $format = 'text', *%opts --> Str) {
        # 同时接受 `render('json')` 与 `render(:format<json>)`：Raku 的
        # 位置参数不会自动接住同名命名参数，这里显式合并一次。
        my Str $fmt = (%opts<format> // $format).Str;
        # 内置命令已经预渲染过 text：直接返回缓存，避免重复扫描 value。
        return $!rendered if $!rendered.chars
            && ($fmt.lc eq 'text' || $fmt.lc eq 'txt' || $fmt.lc eq 'plain');
        Rakuish::Result::Renderer::render-result(self, $fmt, |%opts);
    }

    # 内置命令的 text 结果入口：优先返回预渲染缓存，否则按需计算。
    method text(--> Str) {
        $!rendered.chars ?? $!rendered !! self.render('text');
    }

    method to-text(--> Str)     { self.text }
    method to-json(Bool :$pretty = False --> Str) { self.render('json', :$pretty) }
    method to-markdown(--> Str) { self.render('markdown') }

    # `say $result` / REPL 默认展示统一走 text，而不是对象的默认 gist。
    method gist(--> Str) { self.text }

    # REPL 的“内置命令结果”展示口径：优先显示命令自己的 stdout；失败时显示
    # stderr；路径/计数这类简单 value 直接给出；复杂结构回退到 text 全量。
    # 完整诊断仍可用 .text / .render('text')，这里只影响交互展示。
    method display(--> Str) {
        if $!out.chars {
            my Str $s = $!out.chomp;
            $s ~= "\n" ~ $!err.chomp if $!err.chars;
            return $s;
        }
        return $!err.chomp if !$!ok && $!err.chars;
        # junction 不能落到下面的 `.defined` / `~~ Str|Int|...`：两者都会
        # autothread，随后在 `my Str $v = ...` 处抛 Type check。
        return $!value.raku if $!value.WHAT === Junction;
        if $!value.defined && ($!value ~~ Str | Int | Num | Bool | IO::Path) {
            my Str $v = $!value.Str;
            return $v if $v.chars;
        }
        self.text;
    }
}

class X::Rakuish::CommandFailed is X::Rakuish::V3 is export {
    has Result $.result is required;
    method message(--> Str) {
        my Str $op = $!result.op.chars ?? $!result.op !! 'command';
        "{$op} 失败" ~ ($!result.err.chars ?? ": {$!result.err.chomp}" !! '');
    }
}
