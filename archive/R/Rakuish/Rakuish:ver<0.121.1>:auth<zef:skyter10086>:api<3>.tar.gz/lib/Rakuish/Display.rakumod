unit module Rakuish::Display;

use JSON::Fast;
use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Data::Stream;

# Rakuish::Display —— 结果的**内容级**展示包（0.78.0 / SPEC V-184 / ADR-0016）。
#
# 为什么要有它：`Result` 知道「是什么」（ok/code/value/out/err），
# `Session.render` 知道「TTY 上长什么样」（颜色 + `Out[n]` 标签）。
# 两者之间缺一层——**同一份内容，不同前端能取不同格式**：
#   · 终端要 `text`（等宽、不含 ANSI 也行）；
#   · Markdown 前端（文档、LLM）要 `markdown`；
#   · 结构化前端要 `json`。
#
# 三条硬约束：
#   1. `text` 必有且**零 ANSI** —— 任何前端至少能显示；
#   2. 格式缺失时**降级到 text 并显式标注**（`to-hash<format>` 说明实际给的是
#      哪个），绝不悄悄给错格式；
#   3. 不做第二套渲染逻辑：能在 `Table` / `Result` 上算出来的，一律算出来，
#      不在这里重写一遍表格对齐或数值格式化。
#
# 刻意**不**包含终端装饰（`Out[n]`、颜色、分页）——那是前端的事。

# 可用的格式，按「信息量递增」排列。text 永远在。
# 0.110.0：加 `html` —— notebook / Jupyter 的 `text/html`，也是「导出成网页」
# 时的正文。它和 markdown 是并列的两条渲染路径，不是谁的降级。
my constant FORMATS = < text markdown html json >;

# 转义只有 Table 那一份实现（csv-cell 同一个模式：纯函数，可在类型对象上调用）。
my sub esc($v --> Str) { Rakuish::Data::Table.html-escape($v) }

# 纯文本块：保留换行与空白，前端不必再判断「这段该不该 pre」。
my sub pre-block(Str $text, Str :$class = '' --> Str) {
    my Str $cls = $class.chars ?? ' class="' ~ $class ~ '"' !! '';
    '<pre' ~ $cls ~ ' style="margin:0;font:13px/1.45 '
        ~ 'ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap">'
        ~ esc($text) ~ '</pre>';
}

class Bundle is export {
    has Str $.text is required;     # 必有，零 ANSI
    has Str $.markdown = '';        # '' 表示不提供
    has Str $.html = '';            # 0.110.0：text/html（同样 '' = 不提供）
    has     @.json;                 # 空表示不提供（结构化内容，不是 Result 外壳）
    has     %.meta;                 # kind / ok / code / op / rows / truncated

    method available(--> List) {
        my @a = 'text';
        @a.push('markdown') if $!markdown.chars;
        @a.push('html')     if $!html.chars;
        @a.push('json')     if @!json.elems;
        @a.List;
    }

    method has(Str $fmt --> Bool) {
        my Str $f = $fmt.lc;
        return $!markdown.chars > 0 if $f eq 'markdown' || $f eq 'md';
        return $!html.chars     > 0 if $f eq 'html';
        return @!json.elems     > 0 if $f eq 'json';
        return True                 if $f eq 'text' || $f eq 'txt' || $f eq 'plain';
        False;
    }

    # 内容协商：按调用方的偏好顺序挑第一个**可用**的格式；都不行就 text。
    # 偏好顺序由前端给（例如 LLM 客户端写 ['markdown','text']）。
    method pick(@accepts --> Str) {
        for @accepts -> $want {
            my Str $f = $want.Str.lc;
            return 'markdown' if ($f eq 'markdown' || $f eq 'md') && $!markdown.chars;
            return 'html'     if $f eq 'html' && $!html.chars;
            return 'json'     if $f eq 'json' && @!json.elems;
            return 'text'     if $f eq 'text' || $f eq 'txt' || $f eq 'plain';
        }
        'text';
    }

    method render(Str $fmt = 'text' --> Str) {
        my Str $f = $fmt.lc;
        return $!markdown if ($f eq 'markdown' || $f eq 'md') && $!markdown.chars;
        return $!html     if $f eq 'html' && $!html.chars;
        return to-json(@!json.Array, :!pretty) if $f eq 'json' && @!json.elems;
        # 未知或不可用：降级到 text（不是抛异常 —— 展示层不该让调用方崩）。
        $!text;
    }

    # 一次给齐所有可用 MIME（0.110.0）。Jupyter 的 `execute_result` 就是这样：
    # 前端按自己会渲染的类型挑，而不是让内核猜一个。`text/plain` 永远在。
    method to-mime(--> Hash) {
        my %m;
        # 键必须用花括号：`%m<"text/plain">` 会把引号当成键名的一部分（实测），
        # 序列化出来是 `"\"text/plain\""`，前端一个 MIME 都对不上。
        %m{'text/plain'} = $!text;
        %m{'text/markdown'} = $!markdown if $!markdown.chars;
        %m{'text/html'}     = $!html     if $!html.chars;
        %m{'application/json'} = to-json(@!json.Array, :!pretty) if @!json.elems;
        %m;
    }

    # 线上/跨进程表示。只带**实际选中**的那一份，避免把三种格式都塞进响应。
    #
    # 字段叫 `content` 而不是 `text`：当 format 是 markdown 时，内容不是纯文本。
    # 让字段名跟着格式走会逼客户端先判断再取值，容易把 markdown 当纯文本渲染。
    #
    # `:mime=True` 时再附一份 `mime` 哈希（全部分档）—— 只有 notebook 需要；
    # TTY / Kernel.present 不传，响应体积与 0.109 一致。
    method to-hash(Str :$format = 'text', Bool :$mime = False --> Hash) {
        my Str $picked = self.pick([$format]);
        my %h = content => self.render($picked),
                format  => $picked,
                formats => self.available,
                meta    => %!meta.Hash;
        %h<mime> = self.to-mime if $mime;
        %h;
    }
}

# ── 从 Result 构建 ───────────────────────────────────────────────────
# `:$max-rows` 只影响表格类内容（与 Table 的约定一致）。
our sub bundle-from(Result $r, Int :$max-rows = 200 --> Bundle) is export {
    my %meta = ok => $r.ok, code => $r.code;
    %meta<op> = $r.op if $r.op.chars;

    # ① 失败：错误信息就是全部内容。不给 markdown / json —— 没有内容可结构化。
    unless $r.ok {
        my Str $t = $r.err.chars ?? $r.err.trim
                  !! ($r.out.chars ?? $r.out.trim !! '（失败，无错误信息）');
        return Bundle.new(:text($t), :html(pre-block($t, :class<err>)),
                           :meta(%(%meta, kind => 'error')));
    }

    # ② 命令自带的 stdout 就是它的展示形式（ls / cat / help / doc …）。
    if $r.out.chars {
        return Bundle.new(:text($r.out.chomp), :html(pre-block($r.out.chomp)),
                           :meta(%(%meta, kind => 'text')));
    }

    my $v = $r.value;

    # ③-0 流（0.91.0）：先物化成 Table，再走同一条表格渲染 —— 展示层只有
    # 一套排版，不因为「管道」多出第二种表格。
    $v = $v.table if $v ~~ Rakuish::Data::Stream;

    # ③ 表格：三种格式都是原生支持的，直接借 Table 的实现。
    if $v ~~ Rakuish::Data::Table {
        my Int $rows = $v.elems;
        my %m = %meta, kind => 'table', :$rows,
                columns => $v.columns.List;
        %m<truncated> = True if $max-rows > 0 && $rows > $max-rows;
        return Bundle.new(
            :text($v.to-text(:$max-rows)),
            :markdown($v.to-markdown(:$max-rows)),
            :html($v.to-html(:$max-rows)),
            :json($v.rows.Array),
            :meta(%m),
        );
    }

    # ④ 记录集（Array of Hash）：先转成 Table 再借用它的排版，避免第二套对齐代码。
    if $v ~~ Positional && $v.elems && $v.all ~~ Hash {
        my $t = Rakuish::Data::Table.from-rows($v.List);
        my Int $rows = $v.elems;
        my %m = %meta, kind => 'records', :$rows, columns => $t.columns.List;
        %m<truncated> = True if $max-rows > 0 && $rows > $max-rows;
        return Bundle.new(
            :text($t.to-text(:$max-rows)),
            :markdown($t.to-markdown(:$max-rows)),
            :html($t.to-html(:$max-rows)),
            :json($v.Array),
            :meta(%m),
        );
    }

    # ⑤ 路径列表：与 ls 的观感一致（一行一个），markdown 给成列表。
    if $v ~~ Positional && $v.elems && $v.all ~~ IO::Path {
        my @names = $v.map({ $_.Str }).List;
        return Bundle.new(
            :text(@names.join("\n")),
            :markdown(@names.map({ "- $_" }).join("\n")),
            :html('<ul style="margin:0;padding-left:1.4em">'
                  ~ @names.map({ '<li>' ~ esc($_) ~ '</li>' }).join ~ '</ul>'),
            :json(@names),
            :meta(%(%meta, kind => 'paths', rows => @names.elems)),
        );
    }

    # ⑥ 字符串列表（registry 名字、history 之类）：一行一个。
    if $v ~~ Positional && $v.elems && $v.all ~~ Str {
        my @items = $v.map({ $_.Str }).List;
        return Bundle.new(
            :text(@items.join("\n")),
            :markdown(@items.map({ "- $_" }).join("\n")),
            :html('<ul style="margin:0;padding-left:1.4em">'
                  ~ @items.map({ '<li>' ~ esc($_) ~ '</li>' }).join ~ '</ul>'),
            :json(@items),
            :meta(%(%meta, kind => 'rows', rows => @items.elems)),
        );
    }

    # ⑦ 单个记录：text 用 k=v（shell env 的习惯），markdown 用两列表格。
    if $v ~~ Hash {
        my @keys = $v.keys.sort({ .Str });
        my Str $text = @keys.map({ "{$_.Str}={$v{$_}}" }).join("\n");
        my Str $md = "| key | value |\n| --- | --- |\n"
                   ~ @keys.map({ "| {$_.Str} | {$v{$_}} |" }).join("\n");
        # 单条记录：转成两列的表再走 Table 的 HTML，别在这里手拼第三遍。
        my $rt = Rakuish::Data::Table.new(
            :columns<key value>,
            :rows(@keys.map({ %(key => $_.Str,
                               value => $v{$_}.defined ?? $v{$_}.Str !! '') })));
        return Bundle.new(
            :text($text), :markdown($md),
            :html($rt.to-html),
            :json([$v.Hash]),
            :meta(%(%meta, kind => 'record', rows => 1)),
        );
    }

    # ⑧ 标量：Str / Int / Num / Bool / IO::Path / Ratio … 都能 .Str。
    if $v.defined {
        return Bundle.new(
            :text($v.Str),
            :html(pre-block($v.Str)),
            :json([$v]),
            :meta(%(%meta, kind => 'scalar')),
        );
    }

    # ⑨ 没有值也没有输出（`cd` 之类）：空内容，但仍是成功的展示包。
    Bundle.new(:text(''), :meta(%(%meta, kind => 'empty')));
}

# 能力矩阵：给 `capabilities` / 文档生成用。不要把「想做的」写进来，
# 只列**真的能用**的。
our sub capabilities(--> Hash) is export {
    %(
        formats => FORMATS.List,
        kinds   => < error text table records paths rows record scalar empty >.List,
        notes   => %(
            markdown => '表格类内容（table / records）原生提供；其余降级为 text',
            html     => '表格 / 列表 / 文本块都是真标签（0.110.0）；错误与标量给 <pre>',
            json     => '结构化内容本身（不是 Result 外壳）；标量为单元素数组',
            text     => '必有，零 ANSI，任何前端都能显示',
        ),
    );
}
