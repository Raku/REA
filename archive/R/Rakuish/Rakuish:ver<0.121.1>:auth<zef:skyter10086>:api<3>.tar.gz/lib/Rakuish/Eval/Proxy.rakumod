unit class Rakuish::Eval::Proxy is export;

# Rakuish::Eval::Proxy —— 引擎子进程的「Session 形状」门面（0.83.0 / ADR-0021）。
#
# 为什么是 Proxy 而不是把 `bin/rakuish` 改写成 RPC 客户端：`Kernel.execute`
# 的 `source` 通道只认一个 `eval-line`，审计 / Policy / trail 全部挂在 Kernel 上。
# 让 Proxy 冒充 Session，Kernel 与审计**一行都不用改**，前端也只改构造点。
#
# 它自己不执行任何 Raku：能转发的一律转发，转发不了的（`note-timing`、
# `log-line`）就是空实现 —— 那些活已经在子进程里做完了，重复做会双计数。

use Rakuish::Eval;
use Rakuish::Sys;
use Rakuish::Result;

has $.client is required;
has Bool $.color is rw = False;
has Bool $.tty   is rw = False;   # 0.87.0：真实终端是不是 TTY（引擎据此决定 clear/彩色）
has Int  $.width  is rw = 0;      # 0.88.0：真实终端列数（0 = 未知，排版回落 80）
has Int  $.height is rw = 0;
# 0.90.0 / ADR-0024：`!` 要不要边跑边出。判据是父进程的 stdout 是不是终端；
# 引擎自己的 `live-out` 恒 False（stdout 是协议管道），不能拿来判。
has Bool $.stream-out is rw = False;
# 0.109.0：要不要让引擎顺带算 MIME 分档（notebook 要，TTY 不要）。
has Bool $.want-display is rw = False;
# 0.90.0 / ADR-0025：启动文件路径。崩溃重启后要**重新执行**它 ——
# 新引擎只恢复了声明与纯值，而 rc 里的 prompt / set -o / alias 是会话策略。
has Str $.rc-path is rw = '';
# 0.113.0 / V-305：引擎生死是**事件**，不是某条请求的副产物。
# 回调收一个 Hash：kind（restart / interrupted / restart-failed）、ok、reason、
# restarts、index、restored、rc。notebook 桥把它翻成 `event: engine` 帧；
# TTY 侧暂不订阅（它本来就把这段文字打在结果里，重复播报反而是噪音）。
has &.on-engine-event is rw;
has %.config  is rw;
has Int  $.index is rw = 0;
has Bool $.exit-requested is rw = False;
has Int  $.exit-code is rw = 0;

has Str $!last-hint = '';
has @!plugin-names;
has $!sys;
has Int $!revived = 0;

submethod TWEAK() {
    %!config = $!client.config;
    $!index  = $!client.index;
    @!plugin-names = $!client.plugin-names.List;
    $!sys = self!make-sys;
}

# `Sys` 的 cwd 是只读属性，所以 cwd 一变就重建一个 —— 而不是给 Sys 开
# 一个 setter（那会让「一个 Sys 实例对应一个会话目录」的假设失效）。
method !make-sys(--> Rakuish::Sys) {
    my IO::Path $root = $*DISTRO.is-win
        ?? IO::Path.new($*CWD.volume ~ '\\')
        !! IO::Path.new('/');
    my Str $c = $!client.cwd;
    my $cwd = $c.chars ?? IO::Path.new($c) !! $*CWD.IO;
    Rakuish::Sys.new(:$root, :$cwd, :all-drives($*DISTRO.is-win));
}

method sys(--> Rakuish::Sys) { $!sys }
# 0.113.0：给旁观者（notebook 的看门狗）一个只读的存活判据。
method alive(--> Bool) { ?$!client.alive }
method plugin-names(--> List) { @!plugin-names.List }
method history(--> List) { ().List }
method set-color(Bool $on --> Nil) { $!color = $on; Nil }
method set-tty(Bool $on --> Nil)   { $!tty   = $on; Nil }
method set-stream-out(Bool $on --> Nil) { $!stream-out = $on; Nil }
method set-display(Bool $on --> Nil) { $!want-display = $on; Nil }
method set-size(Int :$width = 0, Int :$height = 0 --> Nil) {
    $!width  = $width  if $width  > 0;
    $!height = $height if $height > 0;
    Nil
}

# 启动 hook 已经在引擎启动时跑过了；这里必须返回空，
# 否则前端会把它们跑第二遍（`use` / 声明就会被执行两次）。
method run-hooks(Str $event --> List) { ().List }

# 引擎已经把耗时记进自己的 perf 历史，父进程不再记一遍。
method note-timing(Duration $d, Str $src, Bool $ok = True --> Nil) { Nil }

# 会话日志同理：`log-line` 需要「输入 + Result + 渲染文本」三者同时在场，
# 那只有引擎里才有。父进程调用它是为了让 bin/rakuish 的控制流不变。
method log-line(Str $line, Result $r, Str $rendered --> Nil) { Nil }

method next-hint(Str $line, Result $r --> Str) { $!last-hint }

# Kernel 的 source 通道唯一入口。
method eval-line(Str $line --> Result) {
    my %h;
    {
        CATCH {
            default {
                my $ex = $_;
                # 中断先于崩溃判定：两者都要重启引擎，但归因不同。
                return self!revive($ex, :interrupted) if $ex ~~ X::Rakuish::Eval::Interrupted;
                return self!revive($ex) if $ex ~~ X::Rakuish::Eval::Dead;
                return Result.new(:!ok, :code(500), :op<engine>,
                    :err('引擎通信失败: ' ~ $ex.message),
                    :rendered('引擎通信失败: ' ~ $ex.message));
            }
        }
        %h = $!client.eval($line, :color($!color), :tty($!tty),
                           :width($!width), :height($!height),
                           :stream($!stream-out),
                           :display($!want-display), config => %!config);
    }

    $!index = (%h<index> // $!index).Int;
    $!last-hint = (%h<hint> // '').Str;
    %!config = (%h<config> // %!config).Hash if %h<config>.defined;
    $!client.cwd = (%h<cwd> // $!client.cwd).Str;
    $!sys = self!make-sys;
    $!exit-requested = ?(%h<exit> // False);
    $!exit-code = (%h<exit-code> // 0).Int;

    # `rendered` 是关键：引擎已经把带 Out[n] / 颜色的最终文本算好了。
    # 把任意 Raku 值（DuckDB 连接、自定义对象）跨进程传过来既不可能也不必要。
    Result.new(
        :ok(?%h<ok>),
        :code((%h<code> // 0).Int),
        :op((%h<op> // 'eval').Str),
        :out((%h<out> // '').Str),
        :err((%h<err> // '').Str),
        :rendered((%h<text> // '').Str),
        :no-newline(?%h<no-newline>),
        :streamed(?%h<streamed>),
        # 0.109.0：内容级展示包（引擎按 :display 才回传，空 Hash = 没要）。
        :bundle((%h<display> // %{}).Hash),
    );
}

# 引擎死了：重启一次，并**如实**告诉用户丢了什么。
# 不假装这条请求成功 —— 它确实没有完成，而且状态确实没了。
method !revive($ex, Bool :$interrupted = False --> Result) {
    my Str $why = $ex.message;
    my Bool $ok = True;
    my Str $more = '';
    my Str $rc-err = '';
    my Bool $rc-exists = so ($!rc-path.chars && $!rc-path.IO.e);
    my %rec = %();          # 0.113.0：提到块外，事件帧也要看它
    {
        CATCH { default { $ok = False; $more = .message } }
        # 0.84.0 / ADR-0022：重启时让新引擎从快照恢复声明与纯值。
        $!client.restart(:restore(True));
        # 0.90.0 / ADR-0025：rc 不恢复，**重新执行**。它定义的是会话策略
        # （prompt / set -o / alias），重放一次才是 shell 的语义。
        if $rc-exists {
            my $rch = try { self.run-rc($!rc-path) };
            if $rch.defined && $rch ~~ Hash {
                $rc-err = ($rch<err> // '').Str;
            }
        }
    }
    my Str $text;
    if $ok {
        ++$!revived;
        $!index = $!client.index;
        %!config = $!client.config;
        $!sys = self!make-sys;
        # 中断不是故障：文案不能说「引擎进程已退出」，那会让用户以为出事了。
        $text = $interrupted
            ?? "已中断当前求值（Ctrl-C）\n"
             ~ "  · 引擎已重启，可以继续输入\n"
            !! "引擎进程已退出（{$why}）\n"
             ~ "  · 已自动重启：REPL 本身没有退出，可以继续输入\n";

        %rec = $!client.restored;
        if %rec.elems {
            my Str $when = (%rec{'saved-at'} // '').Str;
            $text ~= "  · 已从快照恢复：{%rec<decls>} 条声明、{%rec<vars>} 个变量"
                   ~ ($when.chars > 19 ?? "（{ $when.substr(0, 19) }）" !! '') ~ "\n";
            my @failed = (%rec<failed> // []).List;
            if @failed.elems {
                $text ~= "  · 无法恢复：" ~ @failed.join('、')
                       ~ "（连接 / 闭包 / 超大值，已置为 Any；重新赋值即可）\n";
            }
        }
        else {
            $text ~= "  · **会话状态已丢失**：跨格变量 / Out[n] / 打开的数据引擎连接\n";
        }
        if $rc-exists {
            $text ~= "  · 已重新执行启动文件：{$!rc-path}\n";
            $text ~= "  · 启动文件有错误：\n{$rc-err}\n" if $rc-err.chars;
        }
        $text ~= "  · 输入历史与配置仍在（它们在父进程侧）";
    }
    else {
        $text = $interrupted
            ?? "已中断当前求值（Ctrl-C），但引擎重启失败（{$more}）\n"
             ~ "  · 请退出后重新启动 rakuish"
            !! "引擎进程已退出（{$why}），重启也失败（{$more}）\n"
             ~ "  · 这次崩溃无法自愈；请退出后重新启动 rakuish";
    }
    # 0.113.0 / V-305：把引擎生死广播出去。
    # 位置在 `$text` 之后：事件要带上重启后的 `index` 与 `restored`，
    # 而这两个值只有 `if $ok` 分支才更新过。回调是**旁观者** —— 它抛异常
    # 不能把「已重启」这个事实改写成失败，所以整段包在 try 里。
    if &!on-engine-event.defined {
        # `restored` 只挑四个业务字段：`%!restored` 存的是引擎的整条
        # restore 回复，里面还带着 `event` / `seq` / `path` —— 把它塞进
        # 事件帧会出现嵌套的 `"event":"restored"`，前端按 event 字段分类
        # 时会被这条假帧带偏（实测在 0.113 的手工验证里看到过）。
        my %rest = %rec.elems
            ?? %( decls    => (%rec<decls> // 0).Int,
                  vars     => (%rec<vars>  // 0).Int,
                  failed   => (%rec<failed> // []).List,
                  saved-at => (%rec{'saved-at'} // '').Str )
            !! %();
        try {
            &!on-engine-event(%(
                kind     => $interrupted ?? 'interrupted'
                            !! ($ok ?? 'restart' !! 'restart-failed'),
                ok       => ?$ok,
                reason   => $why,
                index    => $!index,
                restarts => $!client.restarts,
                restored => %rest,
                rc       => ($rc-exists ?? $!rc-path !! ''),
            ));
        }
    }
    # 中断用 130（128 + SIGINT）而不是 500：它是用户意图，不是故障。
    Result.new(
        :!ok,
        :code($interrupted ?? 130 !! 500),
        :op($interrupted ?? 'interrupted' !! 'engine-restart'),
        :err($interrupted ?? '已中断当前求值'
             !! ($ok ?? "引擎已重启: {$why}" !! "引擎重启失败: {$more}")),
        :rendered($text));
}

method render(Result $r --> Str) {
    # 0.98.2：只信引擎算好的 rendered —— 空串就是「刻意不展示」，不再
    # fallback 到 render('text')。0.74～0.97.1 那个回退把 ok/op/code 字段
    # dump 到屏幕：续行（op=more）踩过、`!` 流式（streamed=True、out 已
    # 实时输出）踩过、cd / mkdir 这类安静成功（out=''）也踩过。「没渲染」
    # 的情形已不存在：通信失败与引擎重启的兜底 Result 自带非空 rendered
    # （见 eval-line 的 CATCH 与 !revive），只有引擎回传的文本才是展示
    # 事实来源。0.97.1 用 more/exit/skip 白名单挡了一类，这里把口子收完。
    $r.rendered
}

method completions(Str $line, Int $pos --> List) {
    my $items = try { $!client.complete($line, $pos) };
    $items.defined ?? $items.List !! ().List;
}

# 0.100.0 / ADR-0034 §2.7：错误态标记走引擎 RPC（Session.error-marks）。
# 引擎忙 / 重启窗口返回空——标记是增强不是正确性，宁可暂时不标也不能
# 让渲染抛异常（0.100.0-RC 曾因这里缺方法把整个行编辑器打回 .get）。
# 0.109.0：文档内省（notebook 的 Shift+Tab），返回 %(ok, text)。
method inspect-name(Str $name --> Hash) {
    $!client.inspect($name);
}

method error-marks(Str $line --> List) {
    my $items = try { $!client.error-marks($line) };
    $items.defined ?? $items.List !! ().List;
}

# 0.90.0 / ADR-0025：rc 里 `repl.prompt = -> {...}` 定义的 prompt。
# 引擎死了 / 计算抛异常时退回空串，让入口用默认样式 —— 不能让 prompt
# 把整个 REPL 卡住。
method prompt-text(--> Str) {
    my $t = try { $!client.prompt-text };
    $t.defined && $t ~~ Str ?? $t !! '';
}

# 0.90.0 / ADR-0025：rc 会改 alias / config / cwd，三个都必须回收到父侧，
# 否则下一格把旧 config 推下去就会**把 rc 里的 alias 冲掉**（0.90 实测）。
method run-rc(Str $path --> Hash) {
    my %h = $!client.run-rc($path);
    %!config = %h<config>.Hash if %h<config>.defined;
    $!client.cwd = (%h<cwd> // $!client.cwd).Str if %h<cwd>.defined;
    $!sys = self!make-sys;
    $!index = (%h<index> // 0).Int;
    %h;
}

method handle-key(Str $key, Str :$query = '', Int :$at --> Result) {
    my %h = $!client.key($key);
    Result.new(:ok(?%h<ok>), :op((%h<op> // 'key').Str),
               :value((%h<value> // '').Str), :code(0));
}

method shutdown(--> Nil) { $!client.shutdown }
