unit class Rakuish::REPL::Session;

# Rakuish::REPL::Session —— API v3 的会话与求值器（ADR-0001 §2.3 / 设计 §5）。
#
# 输入只有两类，没有第三套语言：
#   · `!` 开头（第二个字符不是 = / ~）→ argv 便利入口，等价于 sys.exec(...)
#   · 其余全部（含 `%` 开头）        → Raku 表达式，直接 EVAL
#
# 明确**不做**的事（这是 Phase 3 的产品决策，别再加回来）：
#   · 没有 %magic 分流：`%STATE{...}` 就是 Raku 哈希访问（v2 的 %STORE / %RC 已删）；
#   · 没有 auto-shell：Raku 求值失败就是失败，不偷偷转交外部程序；
#   · 没有反引号 shellq / 管道 / 重定向 / 变量展开 / glob 展开；
#   · 求值器自带，不复用 v2 的 eval-cell（它内置 expand-backticks）。
#
# 原 %magic 的 REPL 状态由本对象承载，用户写 `repl.history` / `repl.config`
# / `repl.trace = True`；纯交互动作（历史回调、外部编辑、中断）走快捷键，
# 见 key-bindings() / handle-key()。本对象**不提供文件 / 进程的旁路**。

use Rakuish::Sys;
use Rakuish::Sys::Term;   # 0.98.2：stdout-is-console（Windows NUL 误判修正）
use Rakuish::Result;
use Rakuish::Command;
use Rakuish::DSL;
use Rakuish::Data::Table;
use Rakuish::Data::Stream;
use Rakuish::Data::Pager;
# 必须只加载、不导入：Rakuish::Data 也导出 open-data/save-data，但那是带
# $sys 的底层签名。若用 use 会覆盖 DSL 的同名导出，使 EVAL 里文档示例的
# open-data('x.csv') / save-data(...) 变成参数错误（0.69 修，V-165）。
need Rakuish::Data;
use Rakuish::REPL::Shell;
use Rakuish::REPL::Chrome;        # banner/prompt/耗时格式化（纯展示层）
use Rakuish::REPL::Keymap;        # Vi/Helix 模态与键位预设（ADR-0003）
use Rakuish::REPL::Highlight;     # 0.97：续行时把多行引号状态传给输入高亮器
use Rakuish::REPL::Hints;         # 上下文提示（纯函数）
use Rakuish::REPL::Plugins;       # 显式本地 Raku 插件
use Rakuish::REPL::SqlComplete;   # SQL 字符串上下文补全（ADR-0005，纯函数）
use Rakuish::REPL::Complete;      # 公共前缀 / suggest-suffix（0.100.0 / ADR-0034）
use Rakuish::REPL::Methods;       # 0.107.0：`$obj.` / `Type::Name.` 的方法名补全
use Rakuish::Incomplete;          # 纯 Raku 多行续行，设计 §5.1 允许复用
use Rakuish::Audit;               # 0.84：快照路径用同一个 FNV 指纹
use Rakuish::Snapshot;            # 0.84：会话快照（ADR-0022）
use JSON::Fast;

my class CapturingOut {
    has @.buf is rw;
    method print(*@a) { @!buf.push(@a.map(*.Str).join); True }
    method say(*@a)   { @!buf.push(@a.map(*.Str).join ~ "\n"); True }
    method put(*@a)   { @!buf.push(@a.map(*.Str).join("\n") ~ "\n"); True }
    method flush()    { Nil }
    method nl-out()   { "\n" }
    method text()     { @!buf.join }
}

has Rakuish::Sys $.sys;
has CommandRegistry $.commands;
has Rakuish::REPL::Shell $.shell;
has PluginManager $.plugins;
has $.engine is rw;               # 当前会话数据引擎（open-db 注册，SQL 补全用）

# 0.83.0 / ADR-0021：引擎子进程模式下，`! --tty` 必须由**持有终端的父进程**
# 执行 —— worker 的 stdin/stdout 是管道，`Sys.tty-exec` 在里面只会报「无 TTY」。
# 注入这个 hook 后，`! --tty` 改走它；hook 负责一次完整往返并返回与
# `Sys.tty-exec` 同形状的 Result。未注入（默认）时行为与 0.82 完全一致。
has &.tty-handler is rw;

# 0.90.0 / ADR-0024：`!` 的流式输出。
#   · stream-out    = 本次会话要不要边跑边给用户看（由入口按 stdout 是否终端决定）
#   · chunk-handler = 引擎子进程用：把块写成协议帧（父进程负责真正打印）
# 两者都不在时完全退回 0.89 的「收完再显示」。
has Bool $.stream-out is rw = False;
has &.chunk-handler is rw;

# 0.90.0 / ADR-0025：`set -o` 的选项。每一个都必须有执行点，否则就是
# 一个「被存起来的布尔值」（V-211 同一条尺子）。
#   errexit     → 失败格请求退出（复用 strict）
#   xtrace      → 求值前把源码打到 stderr
#   noglob      → Shell 薄层不展开 * ?
#   noexpand    → Shell 薄层不展开 $NAME / ~
#   histexpand  → 是否认整行 !! / !$ / !n
has Bool $.xtrace     is rw = False;
has Bool $.noglob     is rw = False;
has Bool $.noexpand   is rw = False;
has Bool $.histexpand is rw = True;

# 0.90.0 / ADR-0025：可编程 prompt。rc 里写
#   repl.prompt = -> { "..." }
# 后每次取 prompt 都会调用它；返回空串 / Nil 则退回默认样式。
has &.prompt is rw;

method set-engine($e --> Nil) { $!engine = $e; Nil }

# 插件名单：前端只需要数量与名字，不必拿到 PluginManager 本身。
# Proxy（引擎子进程）也实现同名方法，两者形状一致。
method plugin-names(--> List) { $!plugins.names.List }

# ── 原 %magic 的 REPL 运行时状态（会话级，可读写）────────────────────
has @.history is rw;
has %.config  is rw;
has Bool $.trace is rw = False;
has Bool $.watch is rw = False;
has Bool $.perf  is rw = True;
# 0.74.0 / ADR-0011：结果渲染层的颜色开关，由入口按 Chrome::color-mode 传入。
# 默认 False 是刻意的 —— 忘记传参的调用点（测试、库内构造）一律退回纯文本，
# 绝不因为「代码路径没覆盖到」就给数据管道塞 ANSI。
has Bool $.color is rw = False;
# 0.87.0：**真实终端**是不是 TTY。0.83 起 REPL 跑在引擎子进程里，那里的
# `$*OUT` 是协议管道 —— `$*OUT.t` 恒为 False，于是 `clear` 静默、shell 彩色
# 全灭。探测权收归入口，引擎只接受结论。
has Bool $.tty   is rw = False;
# 0.88.0 / V-227：终端尺寸同样是「终端事实」，由入口查好再下发。
# 0 表示未知（管道 / 无控制台），排版时回落到 80 列。
has Int  $.width  is rw = 0;
# 0.89.0 / V-228：**本进程的 stdout 是不是那个终端**。
# 与 `tty` 是两件事：`tty` 说「用户面前有终端」（排版用），
# `live-out` 说「我写 stdout 就能写到它」（分页、逐行流式用）。
# 引擎子进程里恒 False（stdout 是协议管道）—— 用 `tty` 代替它会让
# 分页器把表格文本写进 JSON 流、并去读 stdin 当按键（0.87 引入的回归，
# 实测 `explore` 之后 REPL 直接卡死）。
has Bool $.live-out = False;
has Int  $.height is rw = 0;
has Bool $.bt    is rw = False;
has @.perf-hist is rw;
has Int  $.index is rw = 0;
has Bool $.exit-requested is rw = False;
has Int  $.exit-code      is rw = 0;
has Bool $.interrupt-requested is rw = False;
has Bool $.strict is rw = False;   # set -e 等价：失败格请求退出
# 0.118.0 / V-311：脚本模式不捕获 `$*OUT`。脚本里 `exit 3` 会当场结束进程，
# 捕获模式下已经 say 的内容会**随缓冲区一起丢**（实测：MAIN 里先打印再
# exit，用户什么都看不到）。REPL 仍捕获（Out[n] / `_` 靠它）。
has Bool $!code-stream = False;
has Bool $!expanding = False;      # 防历史替换递归
# 0.77.0 / ADR-0015 §3：输入序与格号分离。
#   · $!index  = 格号（成功求值/执行的格），`Out[n]` 与 perf 用它；
#   · @!history = 输入序，`history` 显示与 `!n` / `!!` 的编号用它。
# 以前两者绑在同一句 `$!index++; @!history.push(...)` 里，于是会话级命令
# （config / alias / log …）两个都不进 —— 用户敲过的那行凭空消失，
# `!!` 重放的是上一格。
has Str  $!cell-source = '';       # 本格的完整源码（多行拼接后），供 !finish 记账
has Bool $!skip-record = False;    # `!!` 的外层不重复记（内层已记展开结果）

# 0.75.0 / ADR-0012 §5：会话日志。状态只在内存，落盘一律经 Sys（V-125），
# 不能照抄 !save-config 的裸 .spurt —— 那是配置文件的既有例外。
has Bool $!log-on = False;
has Str  $!log-path = '';
has Int  $!log-seq = 0;
has @!log-lines;

# ── 求值器内部状态 ───────────────────────────────────────────────────
has Str $.accum is rw = '';      # 兼容旧字段；不再用于整份重 EVAL
has Int $.shown is rw = 0;       # 已展示过的 stdout 长度（当前格）
has %.state;                    # 跨格持久化的顶层 my/our/state 变量
has @!decls;                    # 跨格持久化的纯 sub/class/use 声明
has %!type-cache;               # 0.107.0：补全时按名字解析出的类型对象

# ── 会话快照（0.84.0 / ADR-0022）──────────────────────────────────────
# 每格成功后把 `%!state` + `@!decls` 写到磁盘，崩溃重启时可以重放。
# 快照只存**声明 + 纯值**：语句格不重放（`write` / `! rm` 幂等性不成立）。
has Str  $.snapshot-path is rw = '';
has Bool $.snapshot-on   is rw = True;
has      %!restored;            # 最近一次恢复的摘要（给前端展示）
has      @!restore-failed;      # 恢复失败的变量名
has @!pending;                  # 多行续行缓冲
has @!out;                      # 成功结果历史；Out[1] 是第一个成功格
# 0.115.0 / V-307：格记录（cell record）。与 @!out / @!history 的区别是
# **一格一条**，带输入、渲染文本、成败与耗时 —— 导出时才有东西可写。
has @!cells;
has Int $!cell-seq = 0;
# `export` 自己不进格记录：否则每导出一次就多一格，继续导出时把上一次的
# `export ...` 也写进文件（自指），而且 count 与用户看到的格数永远差 1。
has Bool $!skip-cell = False;
has %!hinted;                   # hints 去重：同一首词只提示一次
# 0.112.0：审计账本由 Kernel 注入（同一实例）。独立 Session（测试 / 工具）
# 默认有一本纯内存账，命令可用但查不到别的进程的记录。
has $.audit is rw = Rakuish::Audit.new;

submethod TWEAK() {
    # 进程内构造（管道 / -e / 测试）就按自己的 stdout 判定；引擎里由
    # `set-tty` 覆盖成父进程的结论（见 Server 的 eval 分支）。
    # 0.98.2：不用 `$*OUT.t` —— Windows 上它对 NUL 误报 True（见 Term）。
    $!tty = Rakuish::Sys::Term::stdout-is-console();
    $!live-out = Rakuish::Sys::Term::stdout-is-console();
    unless $!sys.defined {
        # REPL/脚本是可信的本地环境：默认 root 是文件系统根，而不是启动 cwd。
        # 否则用户连 `cd ..` / 读绝对路径都做不到；Agent 入口仍要求显式 root。
        my IO::Path $root = $*DISTRO.is-win
            ?? IO::Path.new($*CWD.volume ~ '\\')
            !! IO::Path.new('/');
        # Windows 的 C:\ 只是当前盘根，不是“文件系统根”；REPL 应像 POSIX
        # root=/ 一样允许用户访问 D:/F: 等其他盘。Agent 走自己的 root，不受影响。
        $!sys = Rakuish::Sys.new(
            :root($root), :cwd($*CWD.IO),
            :all-drives($*DISTRO.is-win),
        );
    }
    $!commands = default-registry()  unless $!commands.defined;
    $!shell = Rakuish::REPL::Shell.new(:sys($!sys), :color($!color), :tty($!tty))
        unless $!shell.defined;
    $!plugins = PluginManager.new unless $!plugins.defined;
    self!load-config;
    bind-session($!sys);
    self!init-snapshot;
}

# ── 配置 / alias ─────────────────────────────────────────────────────
method config-path(--> IO::Path) {
    my $env = %*ENV<RAKUISH_CONFIG>;
    return IO::Path.new($env) if $env.defined && $env.chars;
    my $home = try { $*HOME } // $*CWD;
    $home.add('.rakuish-config.json');
}

method !load-config(--> Nil) {
    my $p = self.config-path;
    return unless $p.e;
    my $data = try { from-json($p.slurp) };
    %!config = $data.Hash if $data ~~ Hash;
    Nil
}

method !save-config(--> Nil) {
    my $p = self.config-path;
    try { $p.parent.mkdir unless $p.parent.d; $p.spurt(to-json(%!config, :pretty)); }
    Nil
}

# ── set -o 选项（0.90.0 / ADR-0025）──────────────────────────────────
# 每个选项都必须有执行点；这张表同时是 `set -o` 的列表输出与测试的真值源。
method !option-names(--> List) {
    <errexit histexpand noglob noexpand xtrace>.List;
}

method !option-table(--> Hash) {
    %(
        errexit    => $!strict,
        histexpand => $!histexpand,
        noglob     => $!noglob,
        noexpand   => $!noexpand,
        xtrace     => $!xtrace,
    );
}

method !set-option(Str $name, Bool $on --> Bool) {
    given $name.lc {
        when 'errexit'    { $!strict     = $on }
        when 'histexpand' { $!histexpand = $on }
        when 'noglob' {
            $!noglob = $on;
            $!shell.noglob = $on if $!shell.defined;
        }
        when 'noexpand' {
            $!noexpand = $on;
            $!shell.noexpand = $on if $!shell.defined;
        }
        when 'xtrace'     { $!xtrace = $on }
        default           { return False }
    }
    True
}

# 公开只读视图：`repl.options` 可在 Rc / 插件里查，不必再猜。
method options(--> Hash) { self!option-table }

method !aliases(--> Hash) {
    my $a = %!config<aliases>;
    $a ~~ Hash ?? $a !! %();
}

method !expand-alias(Str $line --> Str) {
    my Str $out = $line;
    my %a = self!aliases;
    for ^10 {
        my @parts = $out.split(/\s+/, 2);
        last unless @parts.elems;
        my Str $name = @parts[0];
        last unless %a{$name}:exists;
        my Str $rest = @parts.elems > 1 ?? @parts[1] !! '';
        $out = %a{$name}.Str ~ ($rest.chars ?? ' ' ~ $rest !! '');
    }
    $out
}

method !cmd-alias(Str $raw --> Result) {
    my Str $t = $raw.trim;
    if $t eq 'alias' {
        my @lines = self!aliases.keys.sort.map({ "{$_}={self!aliases{$_}}" });
        return Result.new(:ok, :op<alias>, :value(self!aliases),
                          :out(@lines.join("\n")));
    }
    my Str $rest = $t.substr(5).trim;
    if $rest.starts-with('--') {
        return Result.new(:!ok, :code(2), :op<alias>,
                          :err('用法: alias [name=command]'));
    }
    my Int $eq = $rest.index('=');
    my Str $name;
    my Str $value;
    if $eq.defined {
        $name  = $rest.substr(0, $eq).trim;
        $value = $rest.substr($eq + 1).trim;
    }
    else {
        my @p = $rest.split(/\s+/, 2);
        $name = @p[0] // '';
        $value = @p.elems > 1 ?? @p[1] !! '';
    }
    return Result.new(:!ok, :code(2), :op<alias>,
                      :err('用法: alias name=command')) unless $name.chars;
    if !$value.chars {
        %!config<aliases>{$name}:delete;
    }
    else {
        %!config<aliases>{$name} = $value;
    }
    self!save-config;
    Result.new(:ok, :op<alias>, :value($name), :out("alias {$name}={$value}"));
}

method !cmd-unalias(Str $raw --> Result) {
    my Str $name = $raw.trim.substr(8).trim;
    return Result.new(:!ok, :code(2), :op<unalias>,
                      :err('用法: unalias name')) unless $name.chars;
    %!config<aliases>{$name}:delete;
    self!save-config;
    Result.new(:ok, :op<unalias>, :value($name), :out("unalias {$name}"));
}

method !cmd-config(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines = %!config.keys.sort.map({
            my $v = %!config{$_};
            "{$_}={$v ~~ Str ?? $v !! to-json($v, :!pretty)}"
        });
        return Result.new(:ok, :op<config>, :value(%!config),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'get' && @args.elems >= 3 {
        my Str $k = @args[2];
        return Result.new(:!ok, :code(1), :op<config>, :err("没有配置: {$k}"))
            unless %!config{$k}:exists;
        return Result.new(:ok, :op<config>, :value(%!config{$k}),
                          :out(%!config{$k}.Str));
    }
    if $sub eq 'set' && @args.elems >= 4 {
        my Str $k = @args[2];
        my Str $v = @args[3..*].join(' ');
        %!config{$k} = $v;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($v), :out("{$k}={$v}"));
    }
    if $sub eq 'unset' && @args.elems >= 3 {
        my Str $k = @args[2];
        %!config{$k}:delete;
        self!save-config;
        return Result.new(:ok, :op<config>, :value($k), :out("unset {$k}"));
    }
    Result.new(:!ok, :code(2), :op<config>,
               :err('用法: config [get KEY|set KEY VALUE|unset KEY]'))
}

method !hooks(--> Hash) {
    my $h = %!config<hooks>;
    $h ~~ Hash ?? $h !! %();
}

method run-hooks(Str $event --> List) {
    my %h = self!hooks;
    return () unless %h{$event} ~~ Positional;
    my @res;
    for %h{$event}.List -> $code {
        @res.push(self.eval-line($code.Str));
        last if $!exit-requested;
    }
    @res.List;
}

method !cmd-hook(Str $raw --> Result) {
    my Str $t = $raw.trim;
    my @args = $t.split(/\s+/);
    if @args.elems <= 1 {
        my @lines;
        for self!hooks.keys.sort -> $e {
            @lines.push("{$e}:");
            @lines.push("  {$_}") for self!hooks{$e}.List;
        }
        return Result.new(:ok, :op<hook>, :value(self!hooks),
                          :out(@lines.join("\n")));
    }
    my Str $sub = @args[1];
    if $sub eq 'add' && @args.elems >= 4 {
        my Str $event = @args[2];
        my Str $code = @args[3..*].join(' ');
        my %h = self!hooks;
        %h{$event} //= [];
        %h{$event}.push($code);
        %!config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($code),
                          :out("hook {$event} += {$code}"));
    }
    if $sub eq 'clear' && @args.elems >= 3 {
        my Str $event = @args[2];
        my %h = self!hooks;
        %h{$event}:delete;
        %!config<hooks> = %h;
        self!save-config;
        return Result.new(:ok, :op<hook>, :value($event),
                          :out("hook {$event} cleared"));
    }
    if $sub eq 'run' && @args.elems >= 3 {
        my Str $event = @args[2];
        my @rs = self.run-hooks($event);
        my Str $out = @rs.map({ $_.out.chomp }).grep(*.chars).join("\n");
        my Str $err = @rs.map({ $_.err.chomp }).grep(*.chars).join("\n");
        my Bool $all-ok = so @rs.map(*.ok).all;
        return Result.new(:ok($all-ok), :op<hook>,
                          :value(@rs.List), :out($out), :err($err));
    }
    Result.new(:!ok, :code(2), :op<hook>,
               :err('用法: hook [add EVENT CODE|clear EVENT|run EVENT]'))
}

method !cmd-explore(Str $raw --> Result) {
    my Str $arg = $raw.trim.substr(7).trim;
    my $value;
    if $arg.chars {
        my $path = try { $!sys.resolve($arg) };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err("路径不存在: {$arg}")) unless $path.defined;
        my $loaded = try {
            $path.d
                ?? $!sys.ls-table($arg)
                !! Rakuish::Data::open-data($!sys, $arg)
        };
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err($!.message)) unless $loaded.defined;
        $value = $loaded;
    }
    else {
        $value = @!out.elems ?? @!out[*-1] !! Nil;
        return Result.new(:!ok, :code(1), :op<explore>,
                          :err('没有可探索的上一格结果')) unless $value.defined;
    }

    $value = Rakuish::Data::tableify($value)
        if $value ~~ Hash | Positional && $value !~~ Rakuish::Data::Table;
    return Result.new(:!ok, :code(1), :op<explore>,
                      :err('explore 需要 Table / 可表格化的数据'))
        unless $value ~~ Rakuish::Data::Table | Str;

    # 每页行数按终端高度算（留 2 行给提示符与 "-- more --"）。
    # 高度未知时退回 Pager 的默认 20 —— 这就是 height 的执行点，
    # 没有它 `height` 只是一个被存起来的数字（V-211 的同一把尺子）。
    my $pager = Rakuish::Data::Pager.new(:page-size(self.pager-page-size));
    # 这里要的是 live-out 而不是 tty：分页要往**真 stdout** 写、再读**真 stdin**。
    my Bool $tty = $!live-out;
    $tty = False if (%*ENV<RAKUISH_PAGER> // '') eq 'never';
    my Str $text = $pager.page($value, :interactive($tty));
    Result.new(:ok, :op<explore>, :value($value),
               :out($tty ?? '' !! $text));
}

# ── `!` 的 argv 分词：只处理空格与引号，元字符一律原样当参数 ──────────
# 不做 $VAR / * / ? / | / > / && / ; / heredoc / 命令替换。
method !unclosed-quote(Str $s --> Bool) {
    my Str $q = '';
    my Bool $escape = False;
    for $s.comb -> $ch {
        if $escape { $escape = False; next }
        if $q eq '' {
            if $ch eq '\\' { $escape = True; next }
            $q = $ch if $ch eq "'" || $ch eq '"';
        }
        else {
            if $ch eq '\\' { $escape = True; next }
            $q = '' if $ch eq $q;
        }
    }
    $q ne '';
}

method !split-argv(Str $s --> List) {
    my @out;
    my Str $cur   = '';
    my Str $quote = '';
    my Bool $has  = False;
    for $s.comb -> $ch {
        if $quote eq '' {
            if $ch eq "'" || $ch eq '"' {
                $quote = $ch;
                $has = True;
            }
            elsif so($ch ~~ /\s/) {
                if $has { @out.push($cur); $cur = ''; $has = False }
            }
            else { $cur ~= $ch; $has = True }
        }
        else {
            if $ch eq $quote { $quote = '' }
            else             { $cur ~= $ch }
        }
    }
    @out.push($cur) if $has;
    @out.List
}

# ── 顶层声明状态化（替代整份历史重 EVAL）────────────────────────────
# Raku 的 EVAL 不能跨调用保留词法 my；为了同时做到「my 跨格」和
# 「副作用只执行一次」，这里只把**顶层声明**转成状态 Hash 的别名：
#
#   my $x = 41;      →  $x = 41;        （$x 已别名到 %STATE<$x>）
#   my @a = (1,2);   →  @a = (1,2);
#   my %h = a=>1;    →  %h = a=>1;
#
# 当前格里的普通语句只执行一次；不再把上一格的 sys.write / append / exec
# 重新跑一遍。已知边界：嵌套块里的 my 保持局部（正确）；复杂类型约束/
# 自定义 trait 会被简化掉；sub/class 的跨格持久仍不在本状态层内。

method !take-name(Int $at, @ch, Int $n --> Str) {
    return '' if $at >= $n;
    my Str $sig = @ch[$at];
    return '' unless $sig ~~ /^<[$@%&]>$/;
    return '' if $at + 1 >= $n;
    return '' unless @ch[$at + 1] ~~ /^<[A..Za..z_]>$/;
    my Str $name = $sig;
    my Int $j = $at + 1;
    while $j < $n && @ch[$j] ~~ /^<[A..Za..z0..9_-]>$/ {
        $name ~= @ch[$j];
        $j++;
    }
    $name;
}

method !scan-cell(Str $src --> Hash) {
    my @ch = $src.comb;
    my Int $n = @ch.elems;
    my Str $out = '';
    my @names;
    my Str $quote = '';
    my Bool $esc = False;
    my Int $brace = 0;
    my Int $paren = 0;
    my Int $bracket = 0;
    my Bool $stmt-start = True;
    my Int $i = 0;

    while $i < $n {
        my Str $c = @ch[$i];

        if $quote ne '' {
            $out ~= $c;
            if $quote eq '"' && $esc {
                $esc = False;
            }
            elsif $quote eq '"' && $c eq '\\' {
                $esc = True;
            }
            elsif $c eq $quote {
                $quote = '';
            }
            $i++;
            next;
        }

        if $c eq q{'} || $c eq q{"} {
            $quote = $c;
            $out ~= $c;
            $stmt-start = False;
            $i++;
            next;
        }

        if $c eq '#' {
            while $i < $n {
                $out ~= @ch[$i];
                last if @ch[$i] eq "\n";
                $i++;
            }
            $i++;
            next;
        }

        if $stmt-start && $brace == 0 && $paren == 0 && $bracket == 0 {
            my Str $rest = $src.substr($i);

            # 0.106.2：`use Foo` 不带分号、后面直接换行时，同一编译单元里
            # 看不到它导入的名字（Rakudo 2026.09 实测：`do { use X⏎X::Y }` 报
            # "Could not find symbol '&Y' in '<pkg>::X'"）。这里补一个 `;`，
            # 让「用户敲 use X」和「prelude 重放 use X」都等价于 `use X;`。
            if $rest ~~ /^ use \s / {
                my Int $mark = $out.chars;
                my Str $q = '';
                my Int $hash = -1;
                my Int $depth = 0;
                while $i < $n {
                    my Str $ch = @ch[$i];
                    if $q ne '' {
                        $out ~= $ch;
                        if $q eq '"' && $ch eq '\\' && $i + 1 < $n {
                            $i++;
                            $out ~= @ch[$i];
                        }
                        elsif $ch eq $q {
                            $q = '';
                        }
                        $i++;
                        next;
                    }
                    if $ch eq q{'} || $ch eq q{"} {
                        $q = $ch;
                        $out ~= $ch;
                        $i++;
                        next;
                    }
                    if $ch eq '#' {
                        $hash = $out.chars;
                        last;
                    }
                    last if $ch eq "\n";
                    $depth++ if $ch eq '(' || $ch eq '[' || $ch eq '{';
                    $depth-- if $ch eq ')' || $ch eq ']' || $ch eq '}';
                    $out ~= $ch;
                    $i++;
                }
                # 括号没闭合（多行 use）时不动它，维持原行为。
                if $depth == 0 {
                    $out ~= ';' unless $out.substr($mark).trim-trailing.ends-with(';');
                    # `use Foo # 注释`：分号要补在注释之前，注释原样接回。
                    while $hash >= 0 && $i < $n && @ch[$i] ne "\n" {
                        $out ~= @ch[$i];
                        $i++;
                    }
                }
                $stmt-start = True;
                next;
            }

            my Str $kw = '';
            for <my our state> -> $cand {
                next unless $rest.starts-with($cand);
                my Str $after = $rest.substr($cand.chars, 1);
                next if $after ~~ /^<[A..Za..z0..9_-]>$/;
                $kw = $cand;
                last;
            }
            # 顶层类型声明必须留在词法作用域：裸 class/role/grammar 会被 EVAL
            # 安装到 GLOBAL，跨格前置重放时触发 "Redeclaration of symbol"。
            # 统一改写为 my；同时不能让下面的 %STATE 扫描把 my/our/state 剥掉
            # （剥离只适用于带 sigil 的变量声明）。
            if $kw.chars {
                my Str $ahead = $rest.substr($kw.chars).trim-leading;
                # 0.114.0：`sub` / `method` / `multi` 也得走这条。旧清单里没有
                # 它们，于是 `our sub f {}` 会掉进下面的「变量声明」扫描：把
                # `sub` 当成类型约束吃掉，cell 变成 `f($n) { $n }`，然后报
                # 「Unexpected block in infix position」—— 声明根本没被保留。
                if $ahead ~~ /^ (class|role|grammar|subset|enum|constant|sub|submethod|method|multi) \s / {
                    $out ~= 'my';
                    $i += $kw.chars;
                    $stmt-start = False;
                    next;
                }
            }
            my $tm = $kw.chars ?? Nil !! ($rest ~~ /^ (class|role|grammar) \s /);
            if $tm {
                my Str $tk = ~$tm[0];
                $out ~= 'my ' ~ $tk;
                $i += $tk.chars;
                $stmt-start = False;
                next;
            }
            if $kw.chars {
                my Int $j = $i + $kw.chars;
                $j++ while $j < $n && @ch[$j] ~~ /\s/;

                # 可选类型约束：`my Int $x` / `my IO::Path $p`
                if $j < $n && @ch[$j] ne '(' && @ch[$j] !~~ /^<[$@%&]>/ {
                    while $j < $n && @ch[$j] ~~ /^<[A..Za..z0..9_:]>$/ { $j++ }
                    $j++ while $j < $n && @ch[$j] ~~ /\s/;
                }

                my @new;
                if $j < $n && @ch[$j] eq '(' {
                    my Int $k = $j + 1;
                    while $k < $n && @ch[$k] ne ')' {
                        my Str $name = self!take-name($k, @ch, $n);
                        if $name.chars {
                            @new.push($name);
                            $k += $name.chars;
                        }
                        else {
                            $k++;
                        }
                    }
                }
                else {
                    my Int $k = $j;
                    while $k < $n && @ch[$k] ne '=' && @ch[$k] ne ';' && @ch[$k] ne "\n" {
                        if @ch[$k] eq ',' { $k++; next }
                        my Str $name = self!take-name($k, @ch, $n);
                        if $name.chars {
                            @new.push($name);
                            $k += $name.chars;
                        }
                        else {
                            $k++;
                        }
                    }
                }

                @names.append(@new);
                $i = $j;
                $stmt-start = False;
                next;
            }
        }

        $out ~= $c;
        given $c {
            when '{' { $brace++ }
            when '}' { $brace-- if $brace > 0 }
            when '(' { $paren++ }
            when ')' { $paren-- if $paren > 0 }
            when '[' { $bracket++ }
            when ']' { $bracket-- if $bracket > 0 }
        }

        if $c eq ';' && $brace == 0 && $paren == 0 && $bracket == 0 {
            $stmt-start = True;
        }
        elsif $c eq "\n" {
            $stmt-start = True;
        }
        elsif $c !~~ /\s/ {
            $stmt-start = False;
        }
        $i++;
    }

    %( code => $out, names => @names.unique.List );
}

# ── 会话快照（0.84.0 / ADR-0022）─────────────────────────────────────
# 路径：RAKUISH_SNAPSHOT 显式指定 → $*HOME/.rakuish/session-<cwd指纹>.json
# → 空（纯内存）。按 cwd 分文件是为了让不同项目的会话互不覆盖。
method !init-snapshot(--> Nil) {
    $!snapshot-on = !(%*ENV<RAKUISH_NO_SNAPSHOT> // '').Str.chars;
    my Str $p = (%*ENV<RAKUISH_SNAPSHOT> // '').Str;
    unless $p.chars {
        my $home = try { $*HOME };
        if $home.defined {
            my $d = $home.add('.rakuish');
            my Str $key = Rakuish::Audit::fingerprint($!sys.cwd.Str).substr(0, 12);
            $p = $d.add("session-{$key}.json").Str;
        }
    }
    $!snapshot-path = $p;
    Nil
}

# 每格成功后调用。任何失败都吞掉：快照是**附加价值**，
# 不能因为它写不出去就让求值失败。
method save-snapshot(--> Nil) {
    return unless $!snapshot-on && $!snapshot-path.chars;
    my %snap = Rakuish::Snapshot::capture(
        %!state, @!decls,
        :cwd($!sys.cwd.Str),
        :session('local'),
        :rakuish(($?DISTRIBUTION.meta<version> // '').Str),
    );
    try { Rakuish::Snapshot::save(%snap, $!snapshot-path.IO) };
    Nil
}

# 从快照恢复。只做两件事：把声明填回缓存、把纯值灌回 %!state。
# 返回摘要 %( decls, vars, failed, saved-at )。
#
# 值必须**带着 prelude 一起 EVAL**：Raku 的 `EVAL` 定义的类型不会跨 EVAL
# 存活（实测），所以 `Foo.new(...)` 单独求值只会得到「Undeclared routine」。
method restore-snapshot(%snap --> Hash) {
    my @decls = (%snap<decls> // []).List;
    my %values = (%snap<state> // %{}).Hash;
    return %( decls => 0, vars => 0, failed => ().List, 'saved-at' => '' )
        unless @decls.elems || %values.elems;

    my @srcs;
    for @decls -> %d {
        my Str $src = (%d<src> // '').Str;
        next unless $src.chars;
        @srcs.push($src);
        @!decls.push(%(
            key       => (%d<key>  // '').Str,
            src       => $src,
            name      => (%d<name> // '').Str,
            'is-type' => ?(%d{'is-type'} // False),
        ));
    }

    my Int $ok-vars = 0;
    my @failed;
    my @pairs;          # (name, raku)
    for %values.kv -> $k, %c {
        given (%c<kind> // '').Str {
            when 'value' { @pairs.push(($k, (%c<raku> // '').Str)) }
            when 'nil'   { %!state{$k} = Any; ++$ok-vars }
            default      { %!state{$k} = Any; @failed.push($k) }
        }
    }

    if @pairs.elems {
        my Str $pre = @srcs.join("\n");
        # 用户在会话里定义的类由本类的 EVAL 定义，`.raku` 会写成
        # `Rakuish::REPL::Session::Foo.new(...)`。但声明源码是 `my class Foo`
        # —— `my` 类型不以全名注册，直接用全名构造会「找不到类型」。
        # 所以恢复前把本类前缀剥掉，让它按短名解析（同一 EVAL 块内可见）。
        my Str $pkg = self.WHAT.^name ~ '::';
        my Str $body = @pairs.map({ "'{.[0]}' => { .[1].subst($pkg, '', :g) }" }).join(",\n");
        my $bag;
        my Str $batch-err = '';
        {
            CATCH { default { $batch-err = .message } }
            $bag = EVAL "no worries; do \{ $pre \n %( $body ) }";
        }
        if $bag.defined && $bag ~~ Hash {
            for $bag.kv -> $k, $v { %!state{$k} = $v; ++$ok-vars }
        }
        else {
            # 批量失败（某个值依赖恢复不回来的东西）就逐个来：
            # 能救几个是几个，救不回的进 failed 列表。
            for @pairs -> $p {
                my $v;
                {
                    CATCH { default { } }
                    $v = EVAL "no worries; do \{ $pre \n { $p[1].subst($pkg, '', :g) } }";
                }
                if $v.defined || $p[1] eq 'Any' {
                    %!state{$p[0]} = $v;
                    ++$ok-vars;
                }
                else {
                    %!state{$p[0]} = Any;
                    @failed.push($p[0]);
                }
            }
        }
    }

    $!index = 0;
    %!restored = %(
        decls    => @srcs.elems,
        vars     => $ok-vars,
        failed   => @failed.List,
        'saved-at' => (%snap{'saved-at'} // '').Str,
    );
    @!restore-failed = @failed.List;
    %!restored;
}

method restored(--> Hash) { %!restored }

method !state-alias(Str $name --> Str) {
    given $name.substr(0, 1) {
        when '$' { 'my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;' }
        when '@' {
            '%STATE<' ~ $name ~ '> //= []; my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;'
        }
        when '%' {
            '%STATE<' ~ $name ~ '> //= {}; my ' ~ $name ~ ' := %STATE<' ~ $name ~ '>;'
        }
        default { '' }
    }
}

# 只接受“纯声明格”：整个 cell 就是一个 sub/class/role/grammar 或 use。
# 混有其它语句的 cell 不缓存，避免把副作用也带进后续格。
# 编译期/运行期 phaser 也不缓存：prelude 每格前置重放一次，BEGIN/INIT/END
# 之类的副作用会被反复执行；拒绝缓存后该格仍照常求值，只是不跨格持久。
my constant DECL-STMT-START = rx/^ \s*
    ['our'|'my'] \s+ ['sub'|'submethod'|'method'|'class'|'role'|'grammar'|'module'|'package'] <?wb>/;

# 带声明符的块声明需要语句结束符（见 !eval-raku 里的调用点）。
# 行尾有注释时不补：分号会落进注释里，等于没补，还可能误导。
method !terminate-decl-stmt(Str $src --> Str) {
    my Str $t = $src.trim;
    return $src unless $t ~~ DECL-STMT-START;
    return $src if $t.ends-with(';');
    my Str $last = $src.lines.grep({ .trim.chars }).tail // '';
    return $src if $last.contains('#');
    $src ~ ';';
}

method !pure-decl(Str $src --> Hash) {
    my Str $t = $src.trim;
    return Nil unless $t.chars;

    # 0.106.2：扫描阶段会给 `use` 补分号，这里按「第一条语句」切，
    # 允许后面只跟注释；旧快照里没分号的写法也一并收编。
    if $t ~~ /^ use \s+ \S+ / {
        my Int $semi = $t.index(';') // -1;
        my Str $one  = $semi >= 0 ?? $t.substr(0, $semi + 1) !! $t;
        my Str $tail = $semi >= 0 ?? $t.substr($semi + 1) !! '';
        return Nil unless $tail.trim ~~ /^ ['#' .*]? $/;
        $one = $one.subst(/\s* '#' .* $/, '') unless $semi >= 0;
        $one = $one.trim;
        $one ~= ';' unless $one.ends-with(';');
        return %( key => "use:$one", src => $one );
    }

    for <BEGIN INIT CHECK END START FIRST> -> $phaser {
        return Nil if $t ~~ / << $phaser >> /;
    }

    # 0.114.0：`our sub f {}` 也是顶层声明，但旧正则只认 `my`，于是它既
    # 进不了 @!decls（下一格看不见），又因为缺 `;` 连编译都过不去。
    my $m = $t ~~ /^ [ ['my'|'our'] \s+ ]? [multi \s+]* (sub|class|role|grammar) \s+ (\S+) /;
    return Nil unless $m;
    my Str $kind = ~$m[0];
    my Str $name = (~$m[1]).subst(/<[{;(]>.*$/, '');
    return Nil unless $name.chars;
    my Int $open = $t.index('{');
    return Nil unless $open.defined;

    my @ch = $t.comb;
    my Int $n = @ch.elems;
    my Str $quote = '';
    my Bool $esc = False;
    my Int $depth = 0;
    my Int $i = $open;
    my Int $close = -1;
    while $i < $n {
        my Str $c = @ch[$i];
        if $quote ne '' {
            if $quote eq '"' && $esc { $esc = False }
            elsif $quote eq '"' && $c eq '\\' { $esc = True }
            elsif $c eq $quote { $quote = '' }
            $i++;
            next;
        }
        if $c eq q{'} || $c eq q{"} { $quote = $c; $i++; next }
        if $c eq '#' {
            while $i < $n && @ch[$i] ne "\n" { $i++ }
            next;
        }
        if $c eq '{' { $depth++ }
        elsif $c eq '}' {
            $depth--;
            if $depth == 0 { $close = $i; last }
        }
        $i++;
    }
    return Nil if $close < 0;
    my Str $tail = $t.substr($close + 1).trim;
    return Nil if $tail.chars && $tail ne ';';

    %( key => "{$kind}:{$name}", src => $t, :name($name),
       is-type => ($kind eq 'class' || $kind eq 'role' || $kind eq 'grammar') );
}

# 0.106.2：从任意 cell 里挑出顶层 `use` 语句（每行一条、必须已有 `;`，
# 扫描阶段保证）。用于「use 和其它语句混在一格」时也不丢导入。
method !collect-uses(Str $code --> List) {
    my @found;
    for $code.lines -> $ln {
        next unless $ln ~~ /^ use \s+ \S+ /;
        my Str $t = $ln.trim;
        my Int $semi = $t.index(';') // -1;
        next if $semi < 0;
        my Str $one = $t.substr(0, $semi + 1);
        @found.push(%( key => "use:$one", src => $one ));
    }
    @found.List;
}

# ── Raku 求值：只执行当前格；顶层声明用 %STATE / @decls 持久化 ──────
method !remember(Result $r --> Nil) {
    return unless $r.ok;
    return if $r.op eq 'more' || $r.op eq 'exit' || $r.op eq 'skip';
    @!out.push($r.value);
    @!out.shift while @!out.elems > 1000;
    Nil
}

method !eval-raku(Str $src --> Result) {
    my %scanned = self!scan-cell($src);
    my @new-names = %scanned<names>.List;
    my Str $cell-code = %scanned<code>;
    my %decl = self!pure-decl($cell-code) // %();
    my Bool $is-type = so %decl<is-type>;

    # 声明进入 prelude 的方式：
    #   · sub / use：当前 cell 自己声明，成功后按原位插回缓存；
    #   · class / role / grammar：直接原位替换缓存，当前 cell 只引用类型名。
    #     否则重定义被继承的类型时，依赖它的声明会排在它前面（编译失败）。
    my Int $slot = -1;
    my @saved-decls = @!decls.List;
    # 0.106.2：混着其它语句的 cell（`use X; say 1`）不算纯声明格，
    # 但里面的顶层 `use` 必须留下 —— 它只是加载 + 导入，重放无副作用。
    my @uses = self!collect-uses($cell-code);
    for @uses -> $u {
        next if @!decls.first({ .<key> eq $u<key> });
        @!decls.push($u);
    }
    if %decl<key> {
        $slot = @!decls.first({ .<key> eq %decl<key> }, :k) // -1;
        if $is-type {
            if $slot >= 0 { @!decls[$slot] = %decl }
            else          { @!decls.push(%decl) }
            $cell-code = %decl<name>;
        }
        elsif $slot >= 0 {
            @!decls = @!decls.grep({ .<key> ne %decl<key> }).List;
        }
    }

    for @new-names -> $name {
        next if %!state{$name}:exists;
        given $name.substr(0, 1) {
            when '$' { %!state{$name} = Any }
            when '@' { %!state{$name} = [] }
            when '%' { %!state{$name} = {} }
        }
    }

    my @prelude;
    for @!decls -> $d {
        my Str $s = $d<src>;
        # 旧快照里可能存着没分号的 `use Foo`，重放时同样补上（见 !scan-cell）。
        $s ~= ';' if $s ~~ /^ use \s / && !$s.trim-trailing.ends-with(';');
        @prelude.push($s);
    }
    for %!state.keys.sort -> $name {
        my Str $alias = self!state-alias($name);
        @prelude.push($alias) if $alias.chars;
    }
    # 0.114.0 / V-306：`our sub f {}` / `my sub f {}` 单独成格时，Raku 要求
    # 语句结束符 —— 否则报「Unexpected block in infix position」。裸 `sub f {}`
    # 是 statement 不需要分号，带上声明符就变成了 term。这里补一个 `;`；
    # 只补在**整格**末尾，所以多行声明（`our sub f {\n ... \n}`）同样适用。
    $cell-code = self!terminate-decl-stmt($cell-code);

    my Str $code = @prelude.join("\n")
        ~ (@prelude.elems ?? "\n" !! '')
        ~ $cell-code;

    my $cap  = CapturingOut.new;
    my $t0   = now;
    my $value;
    my Str $err = '';
    my Bool $ok = True;
    my $last = @!out.elems ?? @!out[*-1] !! Any;
    my @out  = (Any, |@!out);

    {
        # 部分编译期异常（典型：跨格引用未声明类型）的 .message / .gist
        # 在**方法内部**字符串化未定义值并抛 CX::Warn，仅在外面判断
        # .defined 拦不住（0.69.1 实测：警告行号就落在取消息这一行）。
        # quietly 只包住「构造异常文本」这一小块，抑制驱动自身的警告；
        # 结果仍显式收敛成 Str，最后用异常类名兜底，$err 绝不接收 Any。
        CATCH { default {
            $ok = False;
            my $ex = $_;
            my Str $text = (quietly {
                my $m = try { $ex.message };
                my Str $s = $m.defined ?? (try { ~$m } // '') !! '';
                $s.chars ?? $s !! (try { ~$ex.gist } // '')
            }) // '';
            $err = $text.chars ?? $text !! $ex.^name;
        } }
        # 无 sigil 词法绑定：EVAL 里可直接写 sys.read(...) / repl.history /
        # registry.names（实测 MoarVM 上 EVAL 能看到调用处的词法绑定）。
        my \sys      = $!sys;
        my \repl     = self;
        my \registry = $!commands;
        my \_        = $last;
        my \Out      = @out;
        my $*RAKUISH-SESSION = self;
        my $*RAKUISH-SYS = $!sys;
        my %STATE := %!state;
        # 脚本模式（V-311）直通：`exit` 不该把已经打印的内容留在捕获缓冲里。
        temp $*OUT = $cap unless $!code-stream;
        $value = EVAL "no worries; do \{ $code \n }";
    }

    my Str $all = $cap.text;
    $!shown = $all.chars;

    if $ok {
        # 新的 use 可能带来新类型；类型补全缓存整块作废（重建一次约 4ms）。
        %!type-cache = %() if @uses.elems;
        if %decl<key> && !$is-type {
            if $slot >= 0 && $slot <= @!decls.elems {
                @!decls.splice($slot, 0, %decl);
            }
            else {
                @!decls.push(%decl);
            }
        }
        $!accum = $src;
        $!index = $!index + 1;
        # 0.84.0 / ADR-0022：成功格之后落一次快照。只在**成功**时写 ——
        # 失败格没有改变可持久状态，写了反而会把上一份好快照冲掉。
        self.save-snapshot;
        # 耗时由入口 note-timing() 统一记录（覆盖 shell / ! / Raku 三类格），
        # 这里不再重复推入，否则 perf 报表会出现双倍条目。
    }
    else {
        # 声明格求值失败时回滚，不能把上一格可用的旧声明弄丢。
        @!decls = @saved-decls.List if %decl<key>;
    }
    my $res = Result.new(:ok($ok), :code($ok ?? 0 !! 1), :value($value),
                         :out($all), :err($err), :op<eval>,
                         :elapsed(now - $t0));
    self!remember($res);
    $res;
}

# ── 主入口 ────────────────────────────────────────────────────────────
method !strict-result(Result $r --> Result) {
    if $!strict && !$r.ok {
        $!exit-requested = True;
        $!exit-code = $r.code || 1;
    }
    $r;
}

# 0.76.0 / ADR-0013：这是 `Kernel` 的 `source` 通道实现，**不是前端入口**。
# 前端（bin/rakuish、将来的 Agent/Notebook）必须调 `Kernel.execute(Request)`，
# 让 Policy 在进入这里之前就被执行；`t/35` 有静态断言守着这条。
# 保留 public 是因为：进程内的 `repl` 对象 API（DSL）已经处在 Kernel 的执行
# 上下文里，再套一层只会绕回来。
#
# 0.77.0：拆成「执行 + 记账」两段。记账必须每行都走到，可 `!eval-line-body`
# 里有十几处 return（会话命令、`!` 前缀、shell 薄层、Raku 求值…）；
# 逐个补 `@!history.push` 正是以前漏掉一半的原因。包一层，让记账只有一处。
method eval-line(Str $line --> Result) {
    # 0.90.0 / ADR-0025：`set -o xtrace` 的执行点。打在求值之前、走 stderr，
    # 不参与 Out/值 —— 与 shell 的 `+ cmd` 同义。
    if $!xtrace && $line.trim.chars {
        $*ERR.say('+ ' ~ $line);
        try { $*ERR.flush };
    }
    my Result $r = self!eval-line-body($line);
    self!finish($line, $r);
    $r;
}

# ── 脚本模式：整份源码 + MAIN 分派（0.118.0 / V-311）─────────────────
# `rakuish 文件 参数` 与 `raku 文件 参数` 的理想差别只剩「预加载了 DSL 与
# 会话 Sys」。Rakudo 的 MAIN 分派绑在 **mainline** 上：EVAL 里定义了 MAIN
# 也不会被调用。但 `RUN-MAIN` 本身只是个普通 sub —— 把 EVAL 里的 `&MAIN`
# 取出来显式交给它，参数解析 / 类型强转 / multi 分派 / USAGE / 退出码就都是
# Rakudo 自己那一套，不用抄第二份（抄出来迟早与真 mainline 走偏）。
#
# 尾巴放进 EVAL **内部**而不是调用方：这样 RUN-MAIN 的 `callframe(1).my`
# 正好是脚本的顶层词法域 —— 脚本自定义的 `sub USAGE` / `sub GENERATE-USAGE`
# / `&MAIN` 都在里面，与真 mainline 一致；顶层 `my %*SUB-MAIN-OPTS` 的动态
# 作用域也还在（0.118.0 实测：`%*SUB-MAIN-OPTS` 在 EVAL 里可直接读，但赋值
# 需 `my` 声明，与独立脚本一致）。
#
# 用 `::('&MAIN')` 做**软查找**：没有 MAIN 时它返回 `Failure`。不能绑到
# `my &m`（Type check failed: expected Callable），也不能让它闲置 sink
# （程序结束时会冒 "Earlier failure"）—— 所以先 `~~ Failure` 认领再判断。
my constant SCRIPT-MAIN-TRAILER = q<
; (::('&MAIN') !~~ Failure) && RUN-MAIN(::('&MAIN'), Nil);
>;

method eval-script(Str $src --> Result) {
    # 未闭合结构用与 eval-line 相同的判据先拦：脚本模式宁可拒绝执行，
    # 也不能把「少了个 }」的源码当完整程序跑（更不能用尾巴把它凑完整）。
    if is-incomplete($src) {
        return Result.new(:ok, :op<more>, :value(1));
    }
    # 不经过 eval-line：脚本不是「一格」，不该进 history / perf，也不该被
    # `!` 分流或会话命令截胡 —— 它就是一段完整的 Raku 程序。
    #
    # 已知边界：`=finish` / `$=finish` 用不了。Raku 的 finish 数据段是
    # **编译单元**的属性，而这里把源码放进 `do { }` 里 EVAL（0.118.0 之前
    # 就是这样），`=finish` 在块里会报 "Missing block"。这不是 MAIN 引入的
    # 回归；需要数据段就写普通 Raku 脚本或用文件 IO。
    self!eval-raku($src ~ SCRIPT-MAIN-TRAILER);
}

# ── 启动文件（0.90.0 / ADR-0025）────────────────────────────────────
# 逐**格**执行 rc：既能写 Raku（`my $x = 1` / `use Foo`），也能写薄层命令
# （`alias ll=ls -alh` / `set -o xtrace`）—— 后者只有 eval-line 认识。
# 空行与续行中间态不记账；整份跑完后把格号 / 历史 / perf 清零，让用户的
# 第一个格仍然是 Out[1]。
method run-rc(Str $src, Str :$label = 'rc' --> Hash) {
    my @out;
    my @err;
    my Int $failed = 0;
    my Int $n = 0;
    my Bool $pending = False;

    # 一行一行喂给 eval-line：续行缓冲由 Session 自己持有（@!pending），
    # 这里再拼一遍会把同一行喂两次 —— 0.90 开发中实测 class 因此永远不完整。
    for $src.lines -> $l {
        $n++;
        my $r = self.eval-line($l);
        if $r.op eq 'more' {
            $pending = True;
            next;
        }
        $pending = False;
        @out.push($r.out.chomp) if $r.out.chars;
        if !$r.ok && $r.op ne 'skip' && $r.err.chars {
            $failed++;
            @err.push("{$label}:{$n}: {$r.err.trim}");
        }
    }
    if $pending {
        $failed++;
        @err.push("{$label}:{$n}: 文件结束时仍有未闭合结构");
    }

    self!reset-counters;
    %(
        out    => @out.join("\n"),
        err    => @err.join("\n"),
        failed => $failed,
        lines  => $n,
    );
}

# rc 里的命令不该占用 Out[n] / history / perf：它们不是用户敲的格。
method !reset-counters(--> Nil) {
    $!index = 0;
    @!out = ();
    @!history = ();
    @!perf-hist = ();
    $!exit-requested = False;
    $!exit-code = 0;
    @!pending = ();
    set-continuation('');
    $!cell-source = '';
    Nil
}

# ── 可编程 prompt（0.90.0 / ADR-0025）────────────────────────────────
# 返回值就是用户看到的整个 prompt（含箭头）。函数里 `say` 的内容会被
# 吞掉：prompt 计算不能污染结果流 / 协议流。任何异常都退回空串，由前端
# 使用默认样式 —— 一个坏 prompt 不该让 REPL 无法输入。
method render-prompt(--> Str) {
    return '' unless &!prompt.defined;
    my Str $text = '';
    my Bool $ok = True;
    {
        CATCH { default { $ok = False } }
        my $cap = CapturingOut.new;
        temp $*OUT = $cap;
        temp $*ERR = $cap;
        my $v = &!prompt();
        $text = $v.defined ?? $v.Str !! '';
    }
    return '' unless $ok;
    # prompt 必须是单行：行编辑器按行计算光标位置。
    $text.subst(:g, /<[\r\n]>/, ' ');
}

# 唯一记账点：输入序（history）在这里增长，与格号（index）彻底解耦。
# 刻意**不**在这里碰 $!index —— 「失败的 Raku 格不占 Out 编号」是既定契约
# （t/07 有断言），shell 失败格占不占号是 0.77 之前的行为，不动它。
method !finish(Str $line, Result $r --> Nil) {
    if $!skip-record {          # `!!`：内层已经记过展开后的真实命令
        $!skip-record = False;
        return;
    }
    my Str $src = $!cell-source;
    $!cell-source = '';
    # 空行、续行中间态（`for ... {` 只敲了一半）都不是「用户提交的一行」。
    return unless $line.trim.chars;
    return if $r.op eq 'more';
    # 多行格记完整源码，不记最后一行 —— 否则 history 里只剩半个 for。
    my Str $input = $r.op eq 'eval' && $src.chars ?? $src !! $line;
    @!history.push($input);
    # 0.115.0 / V-307：格记录在同一处落账。渲染文本要等前端算完才有，
    # 所以这里只记「引擎知道的部分」，`log-line` 再补 rendered。
    ++$!cell-seq;
    @!cells.push(%(
        seq   => $!cell-seq,
        index => $!index,
        input => $input,
        ok    => ?$r.ok,
        op    => $r.op,
        code  => $r.code,
        ms    => $r.elapsed.defined ?? ($r.elapsed.Num * 1000).Int !! 0,
    ));
    @!cells.shift while @!cells.elems > 500;
    if $!skip-cell {
        @!cells.pop;
        $!cell-seq--;
        $!skip-cell = False;
    }
}

method !eval-line-body(Str $line --> Result) {
    return Result.new(:ok, :op<skip>) if $line.trim.chars == 0;

    my Str $t = $line.trim-leading;

    # `set`：0.90.0 起是一个真的选项系统（ADR-0025）。只实现有执行点的
    # 五个选项；不认识的明确报错，不做「存下来但没人读」的 inert 键。
    if $t.trim eq 'set' || $t.trim ~~ /^ 'set' \s+ <[-+]> 'o' $/ {
        my %opts = self!option-table;
        my Str $text = %opts.keys.sort
            .map({ "{$_} " ~ (%opts{$_} ?? 'on' !! 'off') }).join("\n");
        return Result.new(:ok, :op<set>, :value(%opts), :out($text));
    }
    if $t.trim ~~ /^ 'set' \s+ (<[-+]>) 'o' \s+ (\w+) ';'? $/ {
        my Bool $on   = ~$0 eq '-';
        my Str  $name = ~$1;
        unless self!set-option($name, $on) {
            return Result.new(:!ok, :code(1), :op<set>,
                :err("未知选项: {$name}（可用: {self!option-names.join(', ')}）"));
        }
        return Result.new(:ok, :op<set>, :value(self!option-table),
                          :out("{$name} " ~ ($on ?? 'on' !! 'off')));
    }
    # 兼容 shell 习惯：set -e / set +e 就是 errexit 的别名。
    if $t.trim ~~ /^ 'set' \s+ (<[-+]>) 'e' ';'? $/ {
        my Bool $on = ~$0 eq '-';
        self!set-option('errexit', $on);
        my Str $msg = $on ?? 'errexit on' !! 'errexit off';
        return Result.new(:ok, :op<set>, :value($on), :out($msg));
    }

    # shell 习惯的 history：显示本会话已执行行。
    if $t.trim eq 'history' {
        my Str $text = @!history.kv.map(-> $i, $v { "{$i + 1}  {$v}" }).join("\n");
        return Result.new(:ok, :op<history>, :value(@!history.List), :out($text));
    }

    # perf：查看每格耗时。不引入 %magic —— 耗时是会话数据，prompt 也读它。
    if $t.trim eq 'perf' || $t.trim.starts-with('perf ') {
        return self!cmd-perf($t);
    }

    # 0.75.0 / ADR-0012 §5：会话日志（与 config/alias 同级的普通会话命令）。
    if $t.trim eq 'log' || $t.trim.starts-with('log ') {
        return self!cmd-log($t);
    }

    # 0.112.0：结构化审计账本（与上面的文本会话日志 log 不是一回事）。
    if $t.trim eq 'audit' || $t.trim.starts-with('audit ') {
        return self!cmd-audit($t);
    }

    # 0.66：hints（会话数据查询）与 plugin（显式本地 Raku 插件）。
    # 仍然不是 %magic：它们是普通会话命令，与 config/alias/hook 同级。
    if $t.trim eq 'hint' || $t.trim.starts-with('hint ') {
        return self!cmd-hint($t);
    }
    if $t.trim eq 'plugin' || $t.trim.starts-with('plugin ') {
        return self!cmd-plugin($t);
    }

    # 0.69：describe 是值 API 的会话入口（不是 %magic、不是文本报告）。
    # 只拦「首词是 describe 且后面是普通参数」；describe(...) 这类 Raku 调用
    # 仍交给 EVAL，由 DSL.describe 处理。
    if $t.trim eq 'describe' || $t.trim.starts-with('describe ') {
        return self!cmd-describe($t);
    }

    # 0.108.0 / V-299：会话状态总览与重跑（IPython 的 who / whos / %rerun）。
    # 三个都是**纯会话数据**：读 %!state / @!decls / @!history，不 EVAL。
    if $t.trim eq 'who' || $t.trim.starts-with('who ') {
        return self!cmd-who($t);
    }
    if $t.trim eq 'whos' {
        return self!cmd-who('who -l');
    }
    if $t.trim eq 'rerun' || $t.trim.starts-with('rerun ') {
        return self!cmd-rerun($t);
    }

    # 0.114.0 / V-306：在会话里跑脚本文件（shell 的 source / IPython 的 %run）。
    # 名字不用 `run`：`run` 是 Raku 自带的 sub（`run 'git', 'status'`），
    # 抢过来就等于把语言拆了半边。
    if $t.trim eq 'source' || $t.trim ~~ /^ 'source' \s / {
        return self!cmd-source($t);
    }

    # 0.115.0 / V-307：格记录（看 / 导出）。名字不能用 `export`：
    # 那是 Shell 的环境变量导出（`export FOO=1`，t/10 守着）。
    if $t.trim eq 'cells' || $t.trim ~~ /^ 'cells' \s / {
        return self!cmd-cells($t);
    }

    # 0.108.0 / V-299：`名字?` = doc（IPython 的 `x?`）。Raku 没有后缀 `?`
    # 运算符，所以「整行只有 名字?」今天本来就是语法错误 —— 接过来不抢语义。
    # 非 sigil 名交给 doc（命令走 usage，类型/sub 走 Introspect）。
    if $t.trim ~~ /^ $<n>=( [ '$' | '@' | '%' ]? <[A..Za..z_]> <[A..Za..z0..9_-]>*
                      ['::' <[A..Za..z_]> <[A..Za..z0..9_-]>*]*) \s* '?' $/ {
        return self!cmd-question(~$<n>);
    }

    # 配置 / alias：会话级命令，不交给 Shell 参数解析。
    if $t.trim eq 'alias' || $t.trim.starts-with('alias ') {
        return self!cmd-alias($t);
    }
    if $t.trim.starts-with('unalias ') {
        return self!cmd-unalias($t);
    }
    if $t.trim eq 'config' || $t.trim.starts-with('config ') {
        return self!cmd-config($t);
    }
    if $t.trim eq 'hook' || $t.trim.starts-with('hook ') {
        return self!cmd-hook($t);
    }
    if $t.trim eq 'explore' || $t.trim.starts-with('explore ') {
        return self!cmd-explore($t);
    }
    # 历史替换只认整行 !! / !$ / !n；`!cmd` 仍是外部命令。
    # `set +o histexpand` 关闭后，`!!` 会落回外部命令（不存在 → 127），
    # 这是显式选项，不是静默退化。
    if !$!expanding && $!histexpand
       && $t.trim ~~ /^ '!' ('!' | '$' | '-'? \d+) $/ {
        return Result.new(:!ok, :code(127), :op<history>,
                          :err('历史为空')) unless @!history.elems;
        my Str $spec = $t.trim;
        my Str $expanded;
        if $spec eq '!!' {
            $expanded = @!history[*-1];
        }
        elsif $spec eq '!$' {
            $expanded = @!history[*-1].words.tail // '';
        }
        else {
            my Int $n = $spec.substr(1).Int;
            my Int $idx = $n < 0 ?? @!history.elems + $n !! $n - 1;
            return Result.new(:!ok, :code(127), :op<history>,
                              :err("没有历史项: {$spec}"))
                unless $idx >= 0 && $idx < @!history.elems;
            $expanded = @!history[$idx];
        }
        return Result.new(:!ok, :code(127), :op<history>,
                          :err("历史项为空: {$spec}")) unless $expanded.chars;
        $!expanding = True;
        my $r = self.eval-line($expanded);
        $!expanding = False;
        # 内层已经把**展开后的真实命令**记进 history；`!!` 这一行本身不再记，
        # 否则用户敲一次 `!!`，history 里会多出一条不存在的命令。
        $!skip-record = True;
        return $r;
    }

    # 1) `!` argv 便利入口。`!=` / `!~~` 是 Raku 运算符，仍按 Raku 求值。
    if $t.starts-with('!') {
        my Str $next = $t.chars > 1 ?? $t.substr(1, 1) !! '';
        if $next ne '=' && $next ne '~' {
            my Str $cmdline = $t.substr(1).trim;
            if self!unclosed-quote($cmdline) {
                return self!strict-result(
                    Result.new(:!ok, :code(127), :op<exec>,
                               :err('! 命令的引号未闭合')));
            }
            my @argv = self!split-argv($cmdline);
            # 0.70 / ADR-0007：`! --tty` / `! -t` 是显式 TTY 直通的元选项，
            # 只认首个 token；`! -- ...` 之后全部按字面 argv，不再解析元选项。
            # 0.90.0 / ADR-0024：同一层新增 `--capture` / `--timeout-ms` /
            # `--no-timeout`。它们仍属于 rakuish 的分发层，子进程只收到 argv。
            my Bool $tty-mode = False;
            my Bool $capture  = False;
            my Int  $timeout-ms = -1;          # -1 = 用 Sys 的默认（30s）
            while @argv.elems {
                my Str $head = @argv[0].Str;
                if $head eq '--' { @argv.shift; last }
                if $head eq '--tty' || $head eq '-t' {
                    $tty-mode = True; @argv.shift; next;
                }
                if $head eq '--capture' {
                    $capture = True; @argv.shift; next;
                }
                if $head eq '--no-timeout' {
                    $timeout-ms = 0; @argv.shift; next;
                }
                if $head eq '--timeout-ms' {
                    @argv.shift;
                    my $raw = @argv.shift;
                    my $n = $raw.defined ?? (try { $raw.Str.Int }) !! Nil;
                    unless $n.defined && $n >= 0 {
                        return self!strict-result(Result.new(
                            :!ok, :code(127), :op<exec>,
                            :err('! --timeout-ms 需要一个非负整数（毫秒；0 = 不超时）')));
                    }
                    $timeout-ms = $n.Int;
                    next;
                }
                last;
            }
            return self!strict-result(Result.new(:!ok, :code(127), :op<exec>,
                              :err('! 后面没有命令'))) unless @argv.elems;
            my $exe = @argv.shift;
            $!index = $!index + 1;
            my $r;
            if $tty-mode {
                my $hook = self.tty-handler;
                if $hook.defined {
                    # worker 模式：交回父进程执行（ADR-0021 §4）。
                    # hook 自己不抛：它把父进程的结果包装成 Result。
                    $r = $hook($exe, @argv);
                }
                else {
                    # 非 TTY 时 Sys 会抛 X::Rakuish::Unsupported；收敛成失败 Result，
                    # 不让异常穿透 eval-line（管道/脚本必须保持干净）。
                    my Str $start-err = '';
                    {
                        CATCH { default { $start-err = .message } }
                        $r = $!sys.tty-exec($exe, |@argv);
                    }
                    $r = Result.new(:!ok, :code(127), :op<tty-exec>,
                                    :err($start-err)) unless $r.defined;
                }
            }
            else {
                my %to = $timeout-ms >= 0 ?? ('timeout-ms' => $timeout-ms) !! %();
                my Bool $want-stream = $!stream-out && !$capture;
                if $want-stream {
                    my &emit-out = -> Str $t { self!emit-chunk('out', $t) };
                    my &emit-err = -> Str $t { self!emit-chunk('err', $t) };
                    $r = $!sys.exec($exe, |@argv, |%to,
                                    :on-out(&emit-out), :on-err(&emit-err));
                    # 启动失败时没有任何 chunk，err 必须留给 render；
                    # 正常结束则输出已经实时写过，不能再由 render 重放一遍。
                    my %v = ($r.value ~~ Hash) ?? %($r.value) !! %();
                    unless ?(%v<start-failed> // False) {
                        $r = Result.new(:ok($r.ok), :code($r.code), :op($r.op),
                                        :out(''), :err(''),
                                        :value($r.value), :elapsed($r.elapsed),
                                        :streamed(True));
                    }
                }
                else {
                    $r = $!sys.exec($exe, |@argv, |%to);
                }
            }
            self!remember($r);
            return self!strict-result($r);
        }
    }

    # 2) shell 习惯的常用命令：必须在续行判定前处理 `cd -`（Raku 会把它当
    #    不完整表达式）。只处理单行、无待续行的输入。
    if !@!pending && !$line.contains("\n") {
        my $shell-result = $!shell.handle(self!expand-alias($line));
        if $shell-result.defined {
            $!index = $!index + 1;
            self!remember($shell-result);
            return self!strict-result($shell-result);
        }
    }

    # 3) 其余一律 Raku（% 开头不再分流）。先处理多行续行。
    my @parts = @!pending.List;
    @parts.push($line);
    my Str $src = @parts.join("\n");

    # Raku 的 `exit` 会真的终止 REPL 进程（v2 用 prelude 覆盖）。这里显式
    # 映射成会话退出请求；这不是新命令表，不改变「只有两类输入」的分流。
    my Str $trim = $src.trim;
    # 0.114.0：也认行尾的 `;`。脚本里几乎都写 `exit 3;`，而 source 是逐行
    # 执行的 —— 漏掉分号那一路就等于把引擎真的杀掉（会话重启、状态全丢）。
    my Bool $is-exit = $trim eq 'exit'
        || so($trim ~~ /^ 'exit' [ \s+ <[0..9]>+ ]? ';'? $/);
    if $is-exit {
        $!exit-requested = True;
        my Int $code = 0;
        $code = ~$0 .Int if $trim ~~ /^ 'exit' \s+ (<[0..9]>+) ';'? $/;
        $!exit-code = $code;
        @!pending = ();
        set-continuation('');
        return Result.new(:ok, :op<exit>, :value<exit>);
    }

    if is-incomplete($src) {
        @!pending = @parts;
        # 0.97.0：把已提交的续行源码交给高亮器——它据此算出「本行开头是否
        # 还在上一行的引号里」，用户敲下一行时才能整行染对色（跨行字符串）。
        set-continuation($src);
        return Result.new(:ok, :op<more>, :value(@parts.elems));
    }
    @!pending = ();
    set-continuation('');
    $!cell-source = $src;      # 供 !finish 记完整多行源码
    self!strict-result(self!eval-raku($src))
}

# ── 渲染：值用 .raku，先 decont 避免 Scalar 多打 $ 前缀 ────────────────
method !fmt($v --> Str) {
    my $x = $v<>;
    # 二进制必须单独处理：Buf 的 `.raku` 是**完整元素列表**（4000 字节 ≈ 14k
    # 字符），一格 `slurp(:bin)` 就能把屏幕刷掉，还会被写进 cells 记录。
    return self!render-bytes($x) if $x ~~ Blob;
    (try { $x.raku } // $x.Str) // ''
}

# 预览多少个字节。16 足够看出格式，又不至于把提示符挤走。
my constant BUF-PREVIEW = 16;

# `Buf[uint8] 4000 字节 · Arrow IPC 文件  0x<41 52 52 4F 57 31 …>`
# 只认 magic、**不做完整解析**：渲染是每格都要走的路，必须 O(1)；
# 真要读内容让用户 `open-data` / `decode-ipc`，那是显式动作。
method !render-bytes(Blob $b --> Str) {
    my Str $type = $b.WHAT.^name;
    # `'x'.encode` 的 WHAT 是 `utf8` / `utf16` 这种裸别名，直接印出来像在报
    # 编码名而不是容器；补成 `Buf[utf8]` 才和 `Buf[uint8]` 一个读法。
    $type = "Buf[$type]" unless $type ~~ /^ ['Buf' | 'Blob'] /;
    my Int $n = $b.elems;
    return "$type 空" if $n == 0;
    my @head = $b.list.head(BUF-PREVIEW).map(* +& 0xFF);
    my Str $hex = @head.map({ sprintf('%02X', $_) }).join(' ');
    my Str $more = $n > BUF-PREVIEW ?? ' …' !! '';
    my Str $tag = '';
    my Str $magic = (try { $b.subbuf(0, 6).decode('ascii') }) // '';
    $tag = ' · Arrow IPC 文件（open-data 读，save-data 写）'
        if $n >= 6 && $magic eq 'ARROW1';
    "$type $n 字节$tag  0x<$hex$more>";
}

# `ls` / `glob` / `recent` 返回的是 List[IO::Path]，不能按默认 .raku 展示成
# `$(IO::Path.new(...), ...)`。这里给一个 shell `ls` 风格的展示：
#   · 只显示 basename，按名字排序；
#   · 非 TTY / 管道下每行一个（与 ls 管道行为一致）；
#   · TTY 下按 COLUMNS 排成多列（与 ls 默认视觉一致）。
method !render-path-list(@paths --> Str) {
    # 递归 ls 的条目来自不同目录时，只显示 basename 会丢上下文；
    # 这种情况改用相对 cwd 的路径。单目录列表仍保持 shell ls 的 basename。
    my @parents = @paths.map({ .parent.Str }).unique;
    my Str $cwd = $!sys.cwd.Str;
    my Bool $multi = @parents.elems > 1 || @parents.first({ $_ ne $cwd }).defined;

    # 0.74.0 / ADR-0011：每个条目同时保留「纯文本」与「路径」。
    # 列宽、列数、padding 一律按纯文本算 —— 着色只插入零宽转义，
    # 一旦把它算进宽度，多列就会错位。
    my @items = @paths.map(-> $p {
        my Str $plain = $multi
            ?? do {
                my Str $rel = $p.relative($!sys.cwd).Str.subst(:g, '\\', '/');
                $rel.starts-with('..') ?? $p.Str.subst(:g, '\\', '/') !! $rel;
            }
            !! $p.basename;
        %( plain => $plain, path => $p );
    }).sort({ .<plain>.lc });

    return '' unless @items.elems;

    my Bool $tty = $!tty;
    my Bool $color = $tty && self!color-on;

    my &shown = -> $it { paint($it<plain>, path-color($it<path>), $color) };

    return @items.map(&shown).join("\n") unless $tty && @items.elems > 1;

    # 0.88.0：尺寸来自入口查到的真实终端（V-227）。以前读 `%*ENV<COLUMNS>`，
    # 而它不是终端属性：bash 只在交互 shell 里赋值、默认不导出，`resize`
    # 之后还会变陈旧 —— 40 列终端里按 80 列排，输出直接乱序换行。
    my Int $width = $!width > 0 ?? $!width !! 80;
    my Int $max = @items.map({ .<plain>.chars }).max;
    my Int $cols = (($width + 2) div ($max + 2)) max 1;
    return @items.map(&shown).join("\n") if $cols <= 1;

    my Int $rows = (@items.elems + $cols - 1) div $cols;
    my @lines;
    for ^$rows -> $r {
        my @cells;
        for ^$cols -> $c {
            my $i = $r * $cols + $c;
            last if $i >= @items.elems;
            my Str $plain = @items[$i]<plain>;
            @cells.push(shown(@items[$i]) ~ (' ' x ($max - $plain.chars)));
        }
        # 尾部填充是纯空格，替换不会碰到中间的转义序列。
        @lines.push(@cells.join('  ').subst(/\s+$/, ''));
    }
    @lines.join("\n");
}

# help() / registry.names：命令列表给人看，不要显示成 $("...")。
method !render-command-help(@specs --> Str) {
    my Int $w = @specs.map(*.name.chars).max // 0;
    my Bool $c = self!color-on;
    # padding 按纯文本名字长度算；着色不参与对齐。
    @specs.sort({ .name }).map({
        paint(.name, %CLR{'b-cyan'}, $c)
        ~ (' ' x ($w - .name.chars + 2))
        ~ paint(.summary, %CLR<dim>, $c)
    }).join("\n");
}

# env()：按 shell `env` 的习惯输出 KEY=VALUE，而不是 Raku Hash 的 raku 结构。
method !render-env-hash(%h --> Str) {
    my Bool $c = self!color-on;
    %h.keys.sort({ .Str }).map({
        paint($_.Str, %CLR<cyan>, $c) ~ '=' ~ %h{$_}.Str
    }).join("\n");
}

method !render-stat(Stat $s --> Str) {
    my Bool $c = self!color-on;
    # $value 可能是 IO::Path / Int / Bool，统一在这里 stringify —— 原来用
    # 字符串插值自动转了，包成函数后必须显式做。
    my sub k(Str $name, $value --> Str) {
        paint($name, %CLR<dim>, $c) ~ ': ' ~ $value.Str
    }
    my @lines;
    @lines.push(k('path', $s.path));
    @lines.push(k('type', $s.type));
    @lines.push(k('size', $s.size.Str));
    @lines.push(k('mode', '0' ~ $s.mode.fmt('%o'))) if $s.mode > 0;
    # Windows 的 modified 可能是 1969 年假值；不可信就不显示，别给用户看 -0.15。
    my $y2k = Instant.from-posix(946684800);
    @lines.push(k('modified', $s.modified.DateTime.Str))
        if $s.modified.defined && $s.modified >= $y2k;
    @lines.push(k('readable', $s.readable.Str)
                ~ '  ' ~ k('writable', $s.writable.Str)
                ~ '  ' ~ k('executable', $s.executable.Str));
    @lines.join("\n");
}

method !render-write(WriteResult $w --> Str) {
    my Bool $c = self!color-on;
    my Str $text = paint('wrote', %CLR<green>, $c) ~ " {$w.bytes} bytes to {$w.path}";
    $text ~= ' (backup: ' ~ $w.backup ~ ')' if $w.backup.chars;
    $text ~= ' ' ~ paint('[non-atomic]', %CLR<yellow>, $c) unless $w.atomic;
    $text;
}

# 0.74.0 / ADR-0011：入口每格按 config 重算颜色能力后调它。
# 必须同时同步 Shell —— ls 的长格式 / 普通列表在 Shell 里渲染，
# 只改 Session 会出现「路径列表彩色、ls -l 无色」的半截状态。
# 渲染层唯一该问的一句话：开关开着**且**当前 stdout 是终端。
# 只问 $!color 会漏掉管道：`rakuish -e 'ls' | cat` 的 stdout 不是 TTY，
# 混进 ANSI 就违反了 SPEC V-116（管道输出只能是求值结果）。
method !color-on(--> Bool) {
    return False unless $!color;
    $!tty;
}

method set-color(Bool $on --> Nil) {
    $!color = $on;
    $!shell.color = $on if $!shell.defined;
}

# 与 set-color 同理：Shell 也要同步，否则 `clear` 认 TTY、`ls` 认管道。
method set-tty(Bool $on --> Nil) {
    $!tty = $on;
    $!shell.tty = $on if $!shell.defined;
}

# 0.90.0 / ADR-0024：流式开关由入口决定（stdout 是不是真终端）。
# 引擎里恒为 False 的 `live-out` 解决不了这个问题：引擎没有终端，但
# **父进程有** —— 所以「要不要流式」由父进程下发，块通过 chunk-handler 走协议。
method set-stream-out(Bool $on --> Nil) {
    $!stream-out = $on;
    Nil
}

# 0.118.0 / V-311：脚本模式的输出直通开关（不捕获 `$*OUT`）。
# 只有 `eval-script` 用；REPL 与 `-e` 必须保留捕获，否则 Out[n] / `_` 就没了。
method set-code-stream(Bool $on --> Nil) {
    $!code-stream = $on;
    Nil
}

# 把一块输出交给「能看到用户的那一层」：引擎用协议帧，进程内直接打印。
# 两边都不在（测试 / 管道）时静默丢弃 —— 调用方只有在 stream-out 时才走这里。
method !emit-chunk(Str $ch, Str $text --> Nil) {
    return unless $text.chars;
    if &!chunk-handler.defined {
        try { &!chunk-handler($ch, $text) };
    }
    elsif $!stream-out {
        my $handle = $ch eq 'err' ?? $*ERR !! $*OUT;
        try { $handle.print($text); $handle.flush };
    }
    Nil
}

# 尺寸每格同步一次（和 tty / color 同一趟）：用户 `resize` 之后下一格就生效，
# 不需要 SIGWINCH 状态机。0 = 未知，保留上一份有效值。
# 每页行数由终端高度推出（留 2 行给提示符与 "-- more --"）。
# 独立成方法是为了可测：`height` 若没人读，就只是「被存起来的数字」。
method pager-page-size(--> Int) {
    $!height > 2 ?? $!height - 2 !! 20;
}

method set-size(Int :$width = 0, Int :$height = 0 --> Nil) {
    $!width  = $width  if $width  > 0;
    $!height = $height if $height > 0;
    if $!shell.defined {
        $!shell.width  = $!width  if $width  > 0;
        $!shell.height = $!height if $height > 0;
    }
}

method render(Result $r --> Str) {
    my @lines;
    # 0.90.0 / ADR-0024：流式输出的字节已经实时写过，不能再重放。
    @lines.push($r.out.chomp) if !$r.streamed && $r.out.chars;
    # Shell 薄层的 Result 也按普通值展示；exec 的 value 是审计 Hash，不能套。
    # 0.77.0：op 名单从 Shell 的命令表取，不再在这里另抄一份 —— 抄写版漏过
    # doc / pushd / popd / dirs / bookmark（它们的 out 已经自带文本，所以之前
    # 没暴露；但下一次新增命令就会踩）。
    my List $shell-ops = $!shell.shell-command-names;
    my Bool $value-op = $r.op eq 'eval' || ($r.op (elem) $shell-ops);
    my Bool $shell-op = ($r.op (elem) $shell-ops);
    my Bool $shell-value = $r.op eq 'ls' && $r.out.chars == 0;
    if $r.ok && $r.value-defined && $value-op && (!$shell-op || $shell-value) {
        my $v = $r.value;
        # junction 不能进 fmt / smartmatch：Raku 会把参数逐分支喂给函数体。
        # 展示用它自己的 `.raku`（`any(1, 2)`），`_` / `Out[n]` 里仍是原对象。
        $v = $v.raku if $v.WHAT === Junction;
        if $v ~~ Result {
            @lines.push($v.display);
        }
        elsif $v ~~ Rakuish::Data::Table {
            @lines.push($v.to-text);
        }
        elsif $v ~~ Rakuish::Data::Stream {
            # 0.91.0：流的默认展示就是它自己的表格形态（与 Table 一致）。
            # 这里会真的消费一次；一次性来源（游标）被展示后再取会明确报错，
            # 所以 Out[n] 里存的是「已经渲染过的流」，不是可以反复读的东西。
            @lines.push($v.text);
        }
        elsif $r.op eq 'ls' && $v ~~ Positional && $v.elems == 0 {
            # 空目录：shell ls 不打印任何东西
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ IO::Path {
            # ls / glob / recent 的 shell 风格列表
            @lines.push(self!render-path-list($v));
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ CommandSpec {
            # help() 的命令列表
            @lines.push(self!render-command-help($v));
        }
        elsif $v ~~ Positional && $v.elems && $v.all ~~ Str {
            # registry.names 这类字符串列表，一行一个
            @lines.push($v.join("\n"));
        }
        elsif $v ~~ Str {
            # read / pwd：shell 习惯是直接显示内容/路径，不显示 Raku 引号
            @lines.push($v);
        }
        elsif $v ~~ Hash {
            # env()：shell `env` 风格
            @lines.push(self!render-env-hash($v));
        }
        elsif $v ~~ Stat {
            @lines.push(self!render-stat($v));
        }
        elsif $v ~~ WriteResult {
            @lines.push(self!render-write($v));
        }
        elsif $v ~~ IO::Path {
            # cd / pwd 等单路径结果
            @lines.push($v.Str);
        }
        else {
            @lines.push(paint("Out[{$!index}] =", %CLR<dim>, self!color-on)
                        ~ ' ' ~ self!fmt($v));
        }
    }
    @lines.push(paint('错误: ' ~ $r.err.trim, %CLR<red>, self!color-on)) if $r.err.chars;
    @lines.join("\n")
}

# ── 计时：入口对每一格统一写入，perf 命令读 ─────────────────────────
# 这是「%time 的 Raku 原生替代」的一半：不用文本魔法，耗时是会话数据，
# 既能显示在 prompt 上，也能作为值查（repl.perf-hist）。
method note-timing(Duration $d, Str $src, Bool $ok = True --> Nil) {
    if $!perf {
        @!perf-hist.push([$!index, ($d.Num * 1000).Int, $src.substr(0, 60), $ok]);
    }
}

method perf-report(Int :$limit = 10 --> Str) {
    return '还没有计时记录。' unless @!perf-hist.elems;
    my @rows = @!perf-hist.tail($limit max 1);
    my @lines;
    for @rows -> $row {
        my ($idx, $ms, $src, $ok) = @$row;
        my Str $text = $src.subst(:g, "\n", ' ');
        $text = $text.substr(0, 42) ~ '...' if $text.chars > 43;
        my Str $flag = $ok ?? 'ok' !! 'ERR';
        @lines.push(sprintf('#%-4d %8d ms  %-3s %s', $idx, $ms, $flag, $text));
    }
    my @all = @!perf-hist.map({ .[1] });
    my Str $avg = @all.elems ?? sprintf('%.1f', @all.sum / @all.elems) !! '0';
    my Int  $max = @all.elems ?? @all.max !! 0;
    @lines.push("共 {@!perf-hist.elems} 格 · 平均 {$avg} ms · 最慢 {$max} ms");
    @lines.join("\n")
}

method !cmd-perf(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('perf'),
                          :out($!shell.usage('perf')));
    }
    my Int $n = @args.elems ?? ((try { @args[0].Int }) // 10) !! 10;
    $n = 1   if $n < 1;
    $n = 200 if $n > 200;
    Result.new(:ok, :op<perf>, :value(@!perf-hist.List),
               :out(self.perf-report(:limit($n))))
}

# ── 0.75.0 / ADR-0012 §5：会话日志 ─────────────────────────────────
method log-active(--> Bool) { $!log-on }
method log-path(--> Str)    { $!log-path }
method log-lines(--> List)  { @!log-lines.List }

# 入口主循环每格调一次：那是唯一同时拿得到「输入行 + Result + 渲染文本」的地方。
# Session.render 在 TTY 下会加 ANSI，日志必须纯文本，所以先剥掉 SGR 序列。
method log-line(Str $line, Result $r, Str $rendered --> Nil) {
    # 0.115.0：格记录要的是「终端看到的东西」，与日志开关无关。
    if @!cells.elems {
        @!cells[*-1]<rendered> = $rendered.subst(/ \e \[ <[0..9;]>* m /, :g, '');
    }
    return unless $!log-on;
    my Str $plain = $rendered.subst(/ \e \[ <[0..9;]>* m /, :g, '');
    ++$!log-seq;
    my Str $mark = $r.ok ?? '=' !! '!';
    my Str $entry = "[{$!log-seq}] > $line\n[{$!log-seq}] $mark $plain";
    @!log-lines.push($entry);
    if $!log-path.chars {
        try { $!sys.append($!log-path, $entry ~ "\n") };
    }
}

# 0.112.0 / V-303：按来源分账。和 `log` 的区别是这里查结构化审计记录，
# 不是给人看的会话抄本；账本可能跨进程，所以走 Audit.by-origin / origin-summary。
method !cmd-audit(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('audit'),
                          :out($!shell.usage('audit')));
    }
    my $audit = $!audit;
    unless $audit.defined {
        return Result.new(:!ok, :code(1), :op<audit>,
                          :err('本会话没有审计账本（Kernel 未注入）'));
    }

    my Str $arg = @args.elems ?? @args[0].Str !! '';
    my Bool $flag = $arg.starts-with('--origin');
    if $flag && @args.elems < 2 {
        return Result.new(:!ok, :code(2), :op<audit>,
                          :err('用法: audit --origin ORIGIN'));
    }
    my Str $origin = $flag ?? @args[1].Str
                   !! ($arg eq 'summary' ?? '' !! $arg);

    unless $origin.chars {
        my %s = $audit.origin-summary;
        my Str $out = '（审计账本为空）';
        if %s.elems {
            my @rows = %s.keys.sort.map(-> Str $o {
                my %v = %s{$o};
                sprintf '%-8s %5d %4d %6d', $o, %v<total>, %v<ok>, %v<failed>;
            });
            $out = ("origin     total   ok  failed",
                    '-------  ------  --  ------', |@rows).join("\n");
        }
        return Result.new(:ok, :op<audit>, :value(%s), :out($out));
    }

    my @rows = $audit.by-origin($origin);
    unless @rows.elems {
        return Result.new(:ok, :op<audit>, :value([].List),
                          :out("origin={$origin} 没有记录"));
    }
    my @lines = "origin={$origin}（{@rows.elems} 条）";
    for @rows -> %e {
        my Str $detail = (%e<detail> // '').Str;
        $detail = $detail.substr(0, 37) ~ '…' if $detail.chars > 38;
        @lines.push(sprintf '%4s  %-19s %-10s %-2s %3s  %s',
            %e<seq> // '?', (%e<ts> // '').Str.substr(0, 19),
            (%e<op> // '').Str, ?%e<ok> ?? 'ok' !! 'NO',
            (%e<code> // '?').Str, $detail);
    }
    Result.new(:ok, :op<audit>, :value(@rows.List), :out(@lines.join("\n")));
}

method !cmd-log(Str $raw --> Result) {
    my @args = $raw.trim.split(/\s+/).skip(1);
    if @args.grep({ .Str eq '--help' || .Str eq '-?' }).elems {
        return Result.new(:ok, :op<help>, :value('log'),
                          :out($!shell.usage('log')));
    }
    my Str $sub = @args.elems ?? @args[0].Str !! 'status';
    given $sub {
        when 'start' {
            if @args.elems > 2 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log start [路径]'));
            }
            my Str $path = @args.elems == 2
                ?? @args[1].Str
                !! ((try { $*HOME.add('.rakuish-session.log').Str })
                    // '.rakuish-session.log');
            my $resolved = try { $!sys.resolve($path) };
            unless $resolved.defined {
                return Result.new(:!ok, :code(1), :op<log>,
                                  :err("路径不可用: $path"));
            }
            my Str $header = '# Rakuish 会话日志 · ' ~ DateTime.now.Str ~ "\n";
            my $w = try { $!sys.write($path, $header, :mkdir) };
            unless $w.defined {
                return Result.new(:!ok, :code(1), :op<log>,
                                  :err("无法写日志: $path"));
            }
            $!log-on = True;
            $!log-path = $path;
            $!log-seq = 0;
            @!log-lines = ();
            return Result.new(:ok, :op<log>, :value($path),
                              :out("日志已开启: $path"));
        }
        when 'stop' {
            if @args.elems > 1 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log stop'));
            }
            $!log-on = False;
            my Int $n = @!log-lines.elems;
            my Str $where = $!log-path.chars ?? "（$!log-path）" !! '';
            return Result.new(:ok, :op<log>, :value($n),
                              :out("日志已关闭；共 $n 格$where"));
        }
        when 'show' {
            if @args.elems > 1 {
                return Result.new(:!ok, :code(2), :op<log>,
                                  :err('用法: log show'));
            }
            my Str $text = @!log-lines.elems
                ?? @!log-lines.join("\n") !! '（没有记录）';
            return Result.new(:ok, :op<log>, :value(@!log-lines.List),
                              :out($text));
        }
        when 'status' {
            my Str $state = $!log-on
                ?? "日志开启：$!log-path（" ~ @!log-lines.elems ~ ' 格）'
                !! '日志未开启（log start [路径]）';
            return Result.new(:ok, :op<log>, :value($!log-on), :out($state));
        }
        default {
            return Result.new(:!ok, :code(2), :op<log>,
                              :err('用法: log [start [路径]|stop|show]'));
        }
    }
}

# ── 0.66：Vi/Helix 状态、hints、插件（ADR-0003）─────────────────────
method vi(--> ViState)   { vi-state() }
method vi-keys(--> Hash) { vi-actions() }

method hint-text(Str $line = '' --> Str) {
    my Str $t = $line.chars ?? $line
              !! (@!history.elems ?? @!history[*-1] !! '');
    hint-for($t, :shell($!shell), :registry($!commands))
}

# 入口每格调用：失败优先给下一步建议；成功时给一次性的命令用法提示。
method next-hint(Str $line, Result $r --> Str) {
    unless $r.ok {
        my Str $advice = result-hint($r, $line);
        return $advice if $advice.chars;
    }
    my Str $ctx = hint-for($line, :shell($!shell), :registry($!commands));
    return '' unless $ctx.chars;
    my Str $key = $line.trim.words[0] // '';
    return '' if %!hinted{$key}:exists;
    %!hinted{$key} = True;
    $ctx
}

method !cmd-hint(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $h = self.hint-text(@p[1] // '');
    Result.new(:ok, :op<hint>, :value($h),
               :out($h.chars ?? $h !! '（该输入没有上下文提示）'))
}

# ── who / whos / rerun / `名字?`（0.108.0 / V-299）──────────────────────
# 数据源只有三处：%!state（变量）、@!decls（sub/class/use）、@!history（输入序）。
# 这一层不 EVAL、不碰 Sys —— 与 history / perf 同级，属于会话自省。
# 显示只用「名字（ASCII）+ 类型（ASCII）+ 大小（可能在行尾）」三列，
# 不对齐 CJK 表头：宽字符按 chars 算宽度必然错位，宁可不做那半列。
method !sigil-rank(Str $name --> Int) {
    given $name.substr(0, 1) {
        when '$' { 0 }
        when '@' { 1 }
        when '%' { 2 }
        default  { 3 }
    }
}

method !value-type($v --> Str) {
    # 类型对象本身 `.defined` 为假，但类型名仍是有效信息，不能丢。
    my $t = try { $v.WHAT.^name };
    my Str $name = ($t.defined ?? $t.Str !! 'Any');
    $v.defined ?? $name !! $name ~ '（未赋值）';
}

method !value-size($v --> Str) {
    return '—' unless $v.defined;
    # `elems` 不是所有类型都有；一个怪对象不该让 whos 整条崩掉。
    my $s = try {
        if    $v ~~ Str         { "{$v.chars} 字符" }
        elsif $v ~~ Associative { "{$v.elems} 键" }
        elsif $v ~~ Positional  { "{$v.elems} 项" }
        else                    { '—' }
    };
    ($s.defined ?? $s.Str !! '—');
}

method !cmd-who(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $flag = (@p[1] // '').trim;
    my Str $usage = '用法: who [-l]'
        ~ "\n  不带参数：列出变量名（带 sigil）"
        ~ "\n  -l（= whos）：变量类型/大小 + 可见的 sub/class/use";
    if $flag.chars && $flag ne '-l' && $flag ne '--long' {
        return Result.new(:!ok, :code(2), :op<who>, :err($usage));
    }

    my @names = %!state.keys.sort(
        { (self!sigil-rank($^a), $^a) cmp (self!sigil-rank($^b), $^b) });

    if !$flag.chars {
        my Str $text = @names.elems
            ?? @names.join('  ')
            !! '（本会话还没有变量；`my $x = 1` 之后再看）';
        return Result.new(:ok, :op<who>, :value(@names.List), :out($text));
    }

    my @var-rows;
    my Int $w-name = 0;
    my Int $w-type = 0;
    for @names -> $name {
        my Str $type = self!value-type(%!state{$name});
        my Str $size = self!value-size(%!state{$name});
        $w-name = $name.chars if $name.chars > $w-name;
        $w-type = $type.chars if $type.chars > $w-type;
        @var-rows.push([$name, $type, $size]);
    }

    my @decl-rows;
    for @!decls -> $d {
        my Str $key = ($d<key> // '').Str;
        next unless $key.chars;
        if $key ~~ /^ 'use:' $<src>=(.+) $/ {
            my Str $mod = $<src>.Str
                .subst(/^ 'use' \s+ /, '')
                .subst(/\s* ';' \s* $/, '').trim;
            @decl-rows.push(['use', $mod]);
        }
        elsif $key ~~ /^ $<kind>=(\w+) ':' $<name>=(.+) $/ {
            @decl-rows.push([$<kind>.Str, $<name>.Str]);
        }
    }

    my @lines;
    @lines.push("变量（{@var-rows.elems}）:");
    if @var-rows.elems {
        for @var-rows -> $r {
            @lines.push('  ' ~ $r[0] ~ (' ' x ($w-name - $r[0].chars + 2))
                             ~ $r[1] ~ (' ' x ($w-type - $r[1].chars + 2))
                             ~ $r[2]);
        }
    }
    else {
        @lines.push('  （无）');
    }
    if @decl-rows.elems {
        @lines.push('', "声明（{@decl-rows.elems}）:");
        for @decl-rows -> $r {
            @lines.push('  ' ~ $r[0] ~ (' ' x (8 - $r[0].chars)) ~ $r[1]);
        }
    }
    Result.new(:ok, :op<who>, :value(@names.List), :out(@lines.join("\n")));
}

method !cmd-rerun(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $arg = (@p[1] // '').trim;
    my Str $usage = '用法: rerun [n]'
        ~ "\n  重跑历史里的第 n 条（负数从末尾算；不带参数 = 上一条）"
        ~ "\n  编号用 history 查；重跑本身计入 Out[n]，不额外记一条历史";
    return Result.new(:!ok, :code(127), :op<rerun>,
                      :err('还没有可重跑的历史')) unless @!history.elems;

    my Int $idx;
    if !$arg.chars {
        $idx = @!history.elems - 1;
    }
    elsif $arg ~~ /^ '-'? \d+ $/ {
        my Int $n = $arg.Int;
        $idx = $n < 0 ?? @!history.elems + $n !! $n - 1;
    }
    else {
        return Result.new(:!ok, :code(2), :op<rerun>, :err($usage));
    }
    unless $idx >= 0 && $idx < @!history.elems {
        return Result.new(:!ok, :code(127), :op<rerun>,
            :err("没有历史项: {$arg}（当前 {@!history.elems} 条，用 history 查编号）"));
    }

    my Str $src = @!history[$idx];
    # 与 `!!` 同一套路：内层照常记账（Out[n] / history 都算这次真的执行了），
    # 外层 `rerun 3` 这一行不再记 —— 否则历史里会多出「rerun 3」这种假命令。
    $!expanding = True;
    my $r = self.eval-line($src);
    $!expanding = False;
    $!skip-record = True;
    $r;
}

# ── source：在会话里跑一个脚本文件（0.114.0 / V-306）──────────────────
# 与 `rakuish 文件` 的分工：那是一次性进程，跑完什么都没留下；`source` 在
# **当前会话**里跑 —— 脚本看得到会话的变量，脚本里的 sub / class / use /
# 顶层 `my` 也留在会话里（`source lib.raku` 就是把库装进当前会话）。
#
# 为什么逐行喂给 eval-line（和启动文件同一套路），而不是把整份文件当一个
# cell：`!pure-decl` 只在「一格恰好是一条声明」时把声明持久化。整份文件
# 当一个 cell 跑，里面的 `sub` 只活在那次 EVAL 里，跑完就没了 —— 那正好
# 废掉 source 最主要的用途。代价是脚本语义比「一个编译单元」弱一点
# （BEGIN 按行触发、声明必须先于使用），这与 REPL 的既有语义一致。
method !cmd-source(Str $raw --> Result) {
    my Str $usage = '用法: source <文件> [参数...]'
        ~ "\n  在当前会话里执行脚本文件：脚本能看到会话的变量，"
        ~ "\n  文件里的 sub / class / use / 顶层 my 也留在会话里"
        ~ "\n  参数进 @*ARGS；给了参数且文件里有 sub MAIN 时会调用它"
        ~ "\n  脚本内部的行不占 Out[n] / history；错误按 文件:行 报出";

    # 'source'.chars == 6；`source` 后面什么都没有时 body 必须是空串
    # （写成「按 6 往后切」会切成字符串 'source' 本身，然后去找名为 source 的文件）。
    my Str $trimmed = $raw.trim;
    my Str $body = $trimmed.chars > 6 ?? $trimmed.substr(6).trim !! '';
    if !$body.chars || $body eq '--help' || $body eq '-h' {
        return Result.new(:ok, :op<source>, :out($usage));
    }

    my @argv = self!split-argv($body);
    my Str $given = @argv[0];
    my @args = @argv.skip(1).List;

    # `~` / `~/x`：与 cd、cp 一致（Sys.resolve 只做相对 cwd 的解析）。
    my Str $target = $given;
    if $target eq '~' || $target.starts-with('~/') || $target.starts-with('~\\') {
        my Str $home = (try { $*HOME.Str }) // '';
        $target = $home ~ $target.substr(1) if $home.chars;
    }

    my IO::Path $path;
    my Str $perr = '';
    {
        CATCH { default { $perr = .message } }
        $path = $!sys.resolve($target);
    }
    return Result.new(:!ok, :code(127), :op<source>,
                      :err("source: {$perr}")) if $perr.chars;
    return Result.new(:!ok, :code(127), :op<source>,
                      :err("source: 找不到文件 {$path.Str}")) unless $path.e;
    return Result.new(:!ok, :code(126), :op<source>,
                      :err("source: 不是普通文件 {$path.Str}")) unless $path.f;

    my Str $src = '';
    my Str $rerr = '';
    {
        CATCH { default { $rerr = .message } }
        $src = $path.slurp(:enc<utf-8>);
    }
    return Result.new(:!ok, :code(126), :op<source>,
                      :err("source: 读取失败（{$rerr}）")) if $rerr.chars;
    # BOM / CRLF 都要吃掉：`.lines` 只按 \n 切，留着 \r 会让最后一行
    # 的 `}` 变成 `}\r`，续行判定直接失效。
    $src = $src.subst(/^ "\x[FEFF]" /, '');
    $src = $src.subst(:g, /\r$/, '');

    my Str $label = $path.basename.Str;
    my @out;
    my @err;
    my Int $failed = 0;
    my Int $n = 0;
    my Bool $pending = False;

    {
        # 脚本内部的行不是用户敲的格：Out[n] / history / perf 必须回到运行前，
        # 否则一个 300 行的脚本会把格号顶到 300 开外。`@!decls` / `%!state`
        # **不**回滚 —— 那正是 source 要留下的东西。
        my Int  $saved-index = $!index;
        my @saved-out  = @!out.List;
        my @saved-hist = @!history.List;
        my @saved-perf = @!perf-hist.List;
        LEAVE {
            $!index = $saved-index;
            @!out = @saved-out;
            @!history = @saved-hist;
            @!perf-hist = @saved-perf;
        }

        # 脚本的「命令行参数」：动态变量对 EVAL 可见（与 $*PROGRAM 一样），
        # temp 保证跑完后会话自己的 @*ARGS 不受影响。
        temp @*ARGS = @args;
        my $*PROGRAM = $path;
        my $*PROGRAM-NAME = $label;

        for $src.lines -> $l {
            $n++;
            my $r = self.eval-line($l);
            if $r.op eq 'more' {
                $pending = True;
                next;
            }
            $pending = False;
            @out.push($r.out.chomp) if $r.out.chars;
            if !$r.ok && $r.op ne 'skip' {
                $failed++;
                my Str $why = $r.err.trim;
                @err.push("{$label}:{$n}: " ~ ($why.chars ?? $why !! '执行失败'));
            }
            # 脚本里的 `exit` 就是退出（shell 的 source 同样如此）：不再往下跑，
            # 由 !exit-requested 交给入口收尾。
            last if $!exit-requested;
        }
        if $pending {
            $failed++;
            @err.push("{$label}:{$n}: 文件结束时仍有未闭合结构")
                unless $!exit-requested;
            # 必须把续行缓冲清掉：不清的话下一格会接着这个残骸拼，
            # 之后**每一行**都变成「未闭合」—— 一次手滑的脚本能把会话毒死。
            @!pending = ();
            set-continuation('');
        }

        # MAIN：Rakudo 的用法解析（`--name`、类型转换、@argsfile）只对
        # **脚本入口**生效，EVAL 里跑不到。这里只在「给了参数」时按位置
        # 参数直接调用一次 —— 调用不上就如实说清楚边界，不假装支持。
        my Bool $declares-main =
            so $src ~~ /^^ \s* ['multi' \s+]? 'sub' \s+ 'MAIN' <?wb>/;
        if $declares-main && @args.elems && $failed == 0 && !$!exit-requested {
            $n++;
            my $mr = self.eval-line('MAIN(|@*ARGS)');
            @out.push($mr.out.chomp) if $mr.out.chars;
            if !$mr.ok {
                $failed++;
                @err.push("{$label}: 调用 MAIN 失败：" ~ $mr.err.trim
                    ~ "\n  只按位置参数调用；命名参数 / 类型转换 / 用法分派"
                    ~ "只在脚本入口生效，需要时用 `raku 文件 参数`");
            }
        }
    }

    Result.new(
        :ok($failed == 0),
        :code($failed == 0 ?? 0 !! 1),
        :op<source>,
        :out(@out.join("\n")),
        :err(@err.join("\n")),
    );
}

# ── cells：查看 / 导出本会话的格记录（0.115.0 / V-307）──────────────────
# 与 `log` / `history` 的分工：
#   · `history` 只有输入；
#   · `log` 是人读的文本抄本（还受 log on/off 影响）；
#   · `cells` 是**结构化**的格记录：输入 + 渲染文本 + 成败 + 耗时。
#     不带参数就列出来，带 `--text` / `--json` 就导出。
#
# 名字不叫 `export`：那是 Shell 薄层的环境变量导出（`export FOO=1`），
# 抢过来等于把 shell 习惯拆掉半边（t/10 立刻会红）。
method !cmd-cells(Str $raw --> Result) {
    # 无论成功失败都不把自己记进格表（见 $!skip-cell 的注释）。
    LEAVE { $!skip-cell = True }
    my Str $usage = '用法: cells [--json|--text] [<文件|->]'
        ~ "\n  不带参数：列出本会话的格记录（编号 / 状态 / 耗时 / 输入）"
        ~ "\n  --text  导出可重放脚本：只写输入，可直接 `rakuish 文件` 或 `source 文件`"
        ~ "\n  --json  导出结构化记录：input / rendered / ok / op / code / ms / index"
        ~ "\n  `-` 代替文件名 = 打到 stdout；格数上限 500（最近的）；与 log 开关无关";

    my Str $trimmed = $raw.trim;
    my Str $body = $trimmed.chars > 5 ?? $trimmed.substr(5).trim !! '';
    my @argv = $body.chars ?? self!split-argv($body) !! ();
    my Str $fmt = 'text';
    my Str $path = '';
    for @argv -> $a {
        my Str $s = $a.Str;
        given $s {
            when '--json' { $fmt = 'json' }
            when '--text' { $fmt = 'text' }
            when '--help' | '-h' {
                return Result.new(:ok, :op<cells>, :out($usage));
            }
            when '-' { $path = $s }
            default {
                return Result.new(:!ok, :code(2), :op<cells>,
                    :err("cells: 未知选项 {$s}\n{$usage}")) if $s.starts-with('-');
                return Result.new(:!ok, :code(2), :op<cells>,
                    :err("cells: 只接受一个输出文件\n{$usage}")) if $path.chars;
                $path = $s;
            }
        }
    }

    # 不带输出文件 = 看记录（这是最常用的；导出要求显式给路径或 `-`）。
    if !$path.chars {
        return Result.new(:ok, :op<cells>,
                          :out(self!render-cells-list(@!cells.List)));
    }
    unless @!cells.elems {
        return Result.new(:!ok, :code(1), :op<cells>,
                          :err('cells: 还没有可导出的格'));
    }

    my @cells = @!cells.List;
    my Str $text = $fmt eq 'json' ?? self!render-cells-json(@cells)
                                  !! self!render-cells-text(@cells);

    if $path eq '-' {
        return Result.new(:ok, :op<cells>, :out($text),
                          :value(%( cells => @cells.elems, format => $fmt )));
    }

    my IO::Path $target;
    my Str $perr = '';
    {
        CATCH { default { $perr = .message } }
        $target = $!sys.resolve($path);
    }
    return Result.new(:!ok, :code(127), :op<cells>,
                      :err("cells: {$perr}")) if $perr.chars;

    my Str $werr = '';
    {
        CATCH { default { $werr = .message } }
        $!sys.write($target, $text);
    }
    return Result.new(:!ok, :code(1), :op<cells>,
                      :err("cells: 写入失败（{$werr}）")) if $werr.chars;

    Result.new(:ok, :op<cells>,
        :out("已导出 {@cells.elems} 格（{$fmt}）→ {$target.Str}"),
        :value(%( cells => @cells.elems, format => $fmt, path => $target.Str )));
}

# 不带参数时的列表：编号 / 状态 / 耗时 / 输入（多行只留首行）。
# 列宽按实际内容算，中文输入不会把表撑歪（宽度按字符数，不按显示宽度：
# 这一列是代码，中文只出现在注释里，凑合够用 —— 不做 wcwidth 那一套）。
method !render-cells-list(@cells --> Str) {
    return '（还没有格记录）' unless @cells.elems;
    my @out;
    for @cells -> %c {
        my Str $in = (%c<input> // '').Str;
        # 多行格只留首行：列表是索引，不是抄本。
        my Str $first = $in.contains("\n") ?? $in.lines[0] ~ ' …' !! $in;
        # 编号用 seq 而不是 Out 号：失败的格不占 Out[n]（既定契约），
        # 拿 index 当编号会出现两个「2」。
        @out.push(sprintf('%-3d %-4s %4dms  %s',
                          (%c<seq> // 0).Int,
                          ?(%c<ok> // False) ?? 'ok' !! 'ERR',
                          (%c<ms> // 0).Int,
                          $first));
    }
    @out.push('');
    @out.push("共 {@cells.elems} 格 · 列依次是 编号 / 状态 / 耗时 / 输入"
              ~ "（失败格不占 Out[n]，所以编号与 Out 号会错开）");
    @out.push('导出：cells --text 文件（可重放）· cells --json 文件（结构化）');
    @out.join("\n");
}

# `--text`：只写输入。多行格原样保留（`!finish` 存的就是完整源码）。
# 开头给一段注释，说明怎么重放 —— 导出的文件本身就该能跑。
#
# 两条必要的修补：
#   · **每格补语句结束符**：REPL 里一格是一次独立 EVAL，`1+1` 后面不带 `;`
#     也没事；拼成整份脚本后 `1+1` 紧跟 `my $x = 1;` 会被读成「两个项连写」
#     （实测：Two terms in a row）。补 `;` 后两种重放方式都成立。
#   · **`no worries;`**：脚本模式下裸表达式会报 "Useless use ... in sink
#     context"，几十格导出来就是几十条噪音。REPL 里这些值本来就展示了。
method !render-cells-text(@cells --> Str) {
    my Str $when = DateTime.now.Str;
    my @lines;
    @lines.push("# rakuish 会话导出 · {$when} · {@cells.elems} 格");
    @lines.push('# 重放：rakuish 本文件（或会话里 source 本文件）');
    @lines.push('# 只含输入、不含输出；失败的格也照原样保留；每格补了语句结束符');
    @lines.push('');
    @lines.push('no worries;   # 脚本模式下表达式的 sink 警告是噪音');
    @lines.push('');
    for @cells -> %c {
        my Str $src = (%c<input> // '').Str;
        @lines.push($src);
        next if !$src.chars || $src.trim.ends-with(';');
        my Str $last = $src.lines.grep({ .trim.chars }).tail // '';
        # 行尾有注释：分号只能另起一行，否则会落进注释里。
        if $last.contains('#') { @lines.push(';') }
        else { @lines[*-1] = $src ~ ';' }
    }
    @lines.join("\n") ~ "\n";
}

# `--json`：结构化记录。字段名用短横线（与审计账本、快照保持同一风格），
# `rendered` 缺失时给空串 —— 前端没调 log-line 的路径（`-e` / 管道）不会崩。
method !render-cells-json(@cells --> Str) {
    my @rows = @cells.map(-> %c {
        %(
            seq      => (%c<seq>   // 0).Int,
            index    => (%c<index> // 0).Int,
            input    => (%c<input> // '').Str,
            rendered => (%c<rendered> // '').Str,
            ok       => ?(%c<ok> // False),
            op       => (%c<op>    // '').Str,
            code     => (%c<code>  // 0).Int,
            ms       => (%c<ms>    // 0).Int,
        );
    });
    to-json(%(
        format         => 'rakuish-cells',
        'format-version' => 1,
        'exported-at'  => DateTime.now.Str,
        cwd            => $!sys.cwd.Str,
        count          => @rows.elems,
        cells          => @rows,
    ), :pretty);
}

# 0.109.0：`名字?` 与 notebook 的 inspect 共用这一份实现。
# 返回 `%(ok, text)` —— 前端只关心「显示什么」，不关心 Result 的错误码。
method inspect-name(Str $name --> Hash) {
    # sigil 名只看值：值就在 %!state 里，不需要 EVAL（也不会触发副作用）。
    if $name ~~ /^ ['$' | '@' | '%'] / {
        return %(ok => False,
                 text => "没有这个变量: {$name}（用 whos 看现有变量）")
            unless %!state{$name}:exists;
        my $v = %!state{$name};
        my Str $type = self!value-type($v);
        my Str $size = self!value-size($v);
        my Str $text = "{$name} : {$type}";
        $text ~= "（{$size}）" if $size ne '—';
        if $v.defined {
            # 只给一行摘要：`$x?` 是「看一眼」，不是 dump。
            my $g = try { $v.gist };
            my Str $one = $g.defined ?? $g.Str !! '';
            $one = $one.subst(:g, /<[\r\n]>/ , ' ');
            $one = $one.substr(0, 160) ~ '…' if $one.chars > 160;
            $text ~= "\n  = {$one}" if $one.chars;
        }
        return %(ok => True, text => $text);
    }
    # 非 sigil：完全交给 doc —— 命令走 usage()，类型 / sub 走 Introspect。
    my $r = self!eval-line-body('doc ' ~ $name);
    if !$r.ok {
        # 本会话声明的 class/role/grammar：Introspect 在自己的编译单元里看不见，
        # 但类型对象本身能通过「重放声明」取到（!resolve-type），够给一份摘要。
        my Str $kind = '';
        for @!decls -> $d {
            my Str $k = ($d<key> // '').Str;
            for <class role grammar> -> $c {
                $kind = $c if $k eq "{$c}:{$name}";
            }
            last if $kind.chars;
        }
        if $kind.chars {
            my $t = self!resolve-type($name);
            # 类型对象本身 `.defined` 为假，不能拿它当「解析失败」的判据。
            if $t.WHAT.^name ne 'Any' {
                # POPULATE 是 Rakudo 给新类自动挂上的元方法，不是用户的 API。
                my $ms = try { $t.^methods.map(*.name.Str)
                                    .grep({ $_.chars && !$_.starts-with('!')
                                            && $_ ne 'POPULATE' }) };
                my @ms = $ms.defined ?? $ms.List.unique.sort !! ();
                my Str $text = "{$name} : {$kind}（本会话声明）\n  "
                    ~ "方法（{@ms.elems}）: "
                    ~ (@ms.elems ?? @ms.head(12).join(', ')
                                  ~ (@ms.elems > 12 ?? ' …' !! '') !! '（无）');
                my $why = try { $t.WHY };
                if $why.defined {
                    my Str $w = $why.Str.trim;
                    $text ~= "\n  文档: {$w}" if $w.chars;
                }
                return %(ok => True, text => $text);
            }
        }
        # 本会话声明的 sub：同样在 Introspect 之外，但至少别报「找不到」。
        if @!decls.first({ (.<key> // '').Str eq "sub:{$name}" }) {
            return %(ok => False,
                text => "{$name} 是本会话声明的 sub；doc 看不到跨格声明"
                        ~ "（`&{$name}.signature` 仍可在下一格打印签名）");
        }
        # doc 的 Introspect 是「零 EVAL」，看不到本会话 use 进来的模块（既有边界）。
        # 但 `JSON::Fast?` 这种问法是自然的 —— 至少说清楚它确实已经导入。
        my Bool $imported = False;
        for @!decls -> $d {
            my Str $k = ($d<key> // '').Str;
            next unless $k.starts-with('use:use ');
            # `use Foo :tag;` 也认：只比第一个词（先剥掉结尾分号）。
            my Str $mod = $k.substr(8).trim.subst(/\s* ';' \s* $/, '');
            my Str $first = ($mod.words.first // '').Str;
            if $first eq $name { $imported = True; last }
        }
        if $imported {
            return %(ok => False,
                text => "{$name} 是本会话 `use` 进来的模块；doc 只认编译期可见的名字，"
                        ~ "看不到跨格 use（用 `who -l` 确认已导入）");
        }
    }
    %(ok => ?$r.ok, text => ($r.ok ?? $r.out !! $r.err));
}

# `名字?` 的入口：只是把 inspect-name 的哈希包成 Result（走原有渲染路径）。
method !cmd-question(Str $name --> Result) {
    my %h = self.inspect-name($name);
    %h<ok> ?? Result.new(:ok, :op<doc>, :out(%h<text>))
           !! Result.new(:!ok, :code(1), :op<doc>, :err(%h<text>));
}

method !cmd-describe(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 2);
    my Str $arg = (@p[1] // '').trim;
    my Str $usage = '用法: describe [表名]'
        ~ "\n  无参数：摘要上一格 Table；否则列出已注册 Engine 的表"
        ~ "\n  有参数：describe('表名') 的结构摘要（需先 open-db(...)）";

    my $table;
    if $arg.chars {
        return Result.new(:!ok, :code(2), :op<describe>,
                          :err('还没有会话 Engine，先用 open-db(...) 打开数据库'))
            unless $!engine.defined;
        $table = try { $!engine.describe($arg) };
    }
    else {
        my $last = @!out.elems ?? @!out[*-1] !! Nil;
        if $last ~~ Rakuish::Data::Table {
            $table = try { $last.describe };
        }
        elsif $!engine.defined {
            $table = try { $!engine.tables };
        }
        else {
            return Result.new(:!ok, :code(2), :op<describe>, :err($usage));
        }
    }
    return Result.new(:!ok, :code(2), :op<describe>,
                      :err(($! ?? $!.message !! 'describe 失败').Str))
        unless $table.defined;

    Result.new(:ok, :op<describe>, :value($table),
               :out($table.to-text(:max-rows(50))))
}

method !cmd-plugin(Str $raw --> Result) {
    my @p = $raw.trim.split(/\s+/, 3);
    my Str $sub = @p[1] // 'list';
    my Str $arg = (@p[2] // '').trim;
    my Str $usage = '用法: plugin [list|load PATH|unload NAME|info NAME]';
    given $sub {
        when 'list' {
            my $table = $!plugins.list;
            Result.new(:ok, :op<plugin>, :value($table),
                       :out($table.elems ?? $table.to-text !! '（未加载插件）'))
        }
        when 'info' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            Result.new(:ok, :op<plugin>, :value($arg),
                       :out($!plugins.info($arg)))
        }
        when 'load' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $!plugins.load($!sys, $!commands, $arg,
                           :enabled($!plugins.enabled(%!config)))
        }
        when 'unload' {
            return Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
                unless $arg.chars;
            $!plugins.unload($!commands, $arg)
        }
        when 'help' | '--help' | '-?' {
            Result.new(:ok, :op<help>, :value<plugin>, :out($usage))
        }
        default {
            Result.new(:!ok, :code(2), :op<plugin>, :err($usage))
        }
    }
}

method completions(Str $line, Int $pos --> List) {
    # In[n] / Out[n] 结果引用补全（V-285）：引擎侧持有 @!out，命中此形态
    # 就接管；纯函数 + 结果历史长度，无额外 IO。
    my @refs = in-out-completions($line, $pos, @!out.elems);
    return @refs.List if @refs.elems;

    # 0.107.0 / V-298：`$obj.` / `Type::Name.` 的方法名补全。命中就接管，
    # 不再往 Shell 走（Shell 对含 `$` 的前缀本来就返回空）。
    my @meth = self!method-completions($line, $pos);
    return @meth.List if @meth.elems;

    # SQL 字符串上下文优先（纯函数、engine 缺失/异常时返回空），
    # 否则原样交给 Shell；这样 0.68 之前的所有补全行为不变。
    my @sql = sql-completions($line, $pos, :engine($!engine));
    my @c = @sql.elems ?? @sql.List !! $!shell.completions($line, $pos).List;

    # 公共前缀优先（V-278）：多候选共享更长前缀时，Tab 序列首位放前缀
    # 补全（首位无尾随空格），其后才是逐个候选——等价 fish 的「先补最长
    # 公共前缀」。上游 do-complete 按序循环，不动它的循环逻辑。
    if @c.elems > 1 {
        my Str $cp = common-prefix(@c);
        my Str $typed = $line.substr(0, $pos min $line.chars);
        @c = ($cp, |@c) if $cp.chars > $typed.chars;
    }
    @c.List;
}

# ── 方法名补全（0.107.0 / V-298）─────────────────────────────────────
# `$db.` / `DB::DuckDB.` 之后 Tab 出方法名。解析规则在 Methods（纯函数），
# 取值和类型解析在这里：只有会话知道 %!state、@!out 和已 use 的模块。
method !method-completions(Str $line, Int $pos --> List) {
    my %ctx = method-context($line, $pos);
    return () unless %ctx<target>:exists;

    my Str $target = %ctx<target>.Str;
    my $obj = self!completion-value($target);
    my @names = method-names($obj);
    return () unless @names.elems;

    # 类型对象本身 `.defined` 为假，但方法表是有效的；只有 Any / Mu 这种
    # 「没有值」的占位才不该给补全（否则 `$未赋值.` 会刷一屏 Mu 的方法）。
    unless $obj.defined {
        my Str $tn = (try { $obj.^name.Str }) // '';
        return () if $tn eq 'Any' || $tn eq 'Mu';
    }

    @names = filter-names(@names, %ctx<frag>.Str);
    return () unless @names.elems;

    my Str $base = (%ctx<head>.Str) ~ $target ~ '.';
    my @out = @names.head(120).map({ $base ~ $_ });

    # 与 Shell 的口径一致：多候选时把公共前缀放首位（V-278）；
    # 前缀恰好等于某个候选时不重复塞一份。
    if @out.elems > 1 {
        my Str $cp = common-prefix(@out);
        my Str $typed = $line.substr(0, $pos min $line.chars);
        @out = ($cp, |@out) if $cp.chars > $typed.chars
                            && !@out.first({ .Str eq $cp });
    }
    @out.List;
}

# 目标值：跨格变量 / 结果引用走会话状态，类型名走 !resolve-type。
method !completion-value(Str $target --> Any) {
    return %!state{$target} if %!state{$target}:exists;
    return (@!out.elems ?? @!out[*-1] !! Any) if $target eq '_';
    # 与显示口径一致：显示 `Out[n]` 对应 @!out[n-1]（EVAL 里给用户看到的
    # `Out` 是 `(Any, |@!out)`，前面的 Any 只是占位）。
    # `In[n]` 是输入历史、没有值，不参与方法补全。
    if $target ~~ /^ 'Out' '[' (\d+) ']' $/ {
        my Int $n = +$0;
        return ($n >= 1 && $n <= @!out.elems) ?? @!out[$n - 1] !! Any;
    }
    self!resolve-type($target);
}

# 名字 → 类型对象。必须在 EVAL 里解析：`::("DB::DuckDB")` 是**相对包名**
# 查找，方法自身的编译单元看不到 EVAL 里 use 进来的符号（实测返回 Nil）。
# 所以把已有的 use 行连同名字一起 EVAL 一次；结果按名字缓存（约 4ms/次），
# 新增 use 时整块清缓存。
method !resolve-type(Str $name --> Any) {
    return %!type-cache{$name} if %!type-cache{$name}:exists;
    my $v = Any;
    if $name ~~ /^ <[A..Z]> <[\w-]>* [ '::' <[\w-]>+ ]* $/ {
        # 0.108.0：prelude 从「只重放 use」扩到「重放全部声明」——
        # 本会话里 `class Box {}` 之后，`Box.<Tab>` 和 `Box?` 都要能用。
        # 失败的声明在 try 里静默，和以前一样退化成 Any（不给候选）。
        my @pre = @!decls.map({ (.<src> // '').Str }).grep({ .chars });
        my Str $prelude = @pre.map(-> $s {
            $s ~~ /^ use \s / && !$s.trim-trailing.ends-with(';') ?? $s ~ ';' !! $s
        }).join("\n");
        # 不能用 `//` 兜底：类型对象本身 `.defined` 为假，会被直接吞成 Any。
        my $r = Any;
        try { $r = EVAL "no worries; do \{ $prelude \n do \{ $name } \n }" }
        $v = $r unless $r.WHAT.^name eq 'Nil';
    }
    %!type-cache{$name} = $v;
    $v;
}

# ── 错误态标记（0.100.0 / ADR-0034 §2.4 / V-280）────────────────────────
# 纯扫描在 Highlight.error-marks（回调注入）；这里提供真实判定：
# 命令是否已知（usage / 用户层注册表 / PATH 缓存）与路径是否存在。
my %path-names-cache;

method !path-names(--> Set) {
    my Str $path = (%*ENV<PATH> // '').Str;
    return %path-names-cache{$path} if %path-names-cache{$path}:exists;
    my Str $sep = $*DISTRO.is-win ?? ';' !! ':';
    my @exts = $*DISTRO.is-win
        ?? (%*ENV<PATHEXT> // '.COM;.EXE;.BAT;.CMD').split(';')
                .map(*.lc).grep(*.chars).List
        !! ();
    my %names;
    for $path.split($sep) -> $dir {
        next unless $dir.chars;
        my @entries = try { $dir.IO.dir } // ();
        for @entries -> $e {
            my Str $n = $e.basename.lc;
            %names{$n} = True;
            for @exts -> $x {
                if $n.chars > $x.chars && $n.ends-with($x) {
                    %names{$n.substr(0, $n.chars - $x.chars)} = True;
                    last;
                }
            }
        }
    }
    %path-names-cache{$path} = set %names.keys;
}

# 引擎侧名字可见性（V-286）：跨格 sub/class/use 声明（@!decls 的 <name>）
# 与跨格 my 变量（%!state 的带 sigil 键）。消除「上一格定义的无括号
# listop（foo bar）被当成未知命令标红」的误报——这些名字只有引擎知道。
method !known-name(Str $w --> Bool) {
    return True if @!decls.first({ (.<name> // '') eq $w });
    for '$', '@', '%', '&' -> $sigil {
        return True if %!state{"$sigil$w"}:exists;
    }
    False
}

method error-marks(Str $line --> List) {
    error-marks($line,
        known-command => sub (Str $w --> Bool) {
            return True if $!shell.defined && $!shell.usage($w).chars;
            return True if $!commands.defined && $!commands.has($w);
            return True if self!known-name($w);
            so self!path-names(){$w.lc}:exists;
        },
        path-exists => sub (Str $w --> Bool) {
            my Str $p = $w;
            if $p.starts-with('~') && $*HOME.defined {
                $p = $*HOME.Str ~ $p.substr(1);
            }
            my $v = try { $p.IO.e };
            return False unless $v.defined;
            so $v;
        });
}

# ── 快捷键：纯交互动作不占文本命令 ────────────────────────────────────
# 0.75.0 订正：这里只列**真正绑定**的键。曾有 `Ctrl-X Ctrl-E / edit-request`
# 值 API，但 Keymap 从未绑定、入口也不消费；补实现又会撞上 V-125 的
# 「快捷键禁止读写文件、启动进程」的限制已随 Agent 线一并删除（ADR-0019）。
method key-bindings(--> Hash) {
    {
        'Up'          => '历史上一格',
        'Down'        => '历史下一格',
        'Ctrl-R'      => '循环历史检索（首按以当前行为查询串，连按走向更旧的匹配）',
        'CursorRight' => '接受灰字建议（无建议时右移一格）',
        'Ctrl-F'      => '同 CursorRight',
        'ShiftTab'    => '列出补全候选（分栏菜单）',
        'Ctrl-C'      => '中断当前输入 / 清空续行缓冲（不退出）',
        'Ctrl-D'      => '退出会话（EOF）',
        'Tab'         => '补全（命令名 / 选项 / 路径 / SQL 上下文）',
    }
}

method handle-key(Str $key, Str :$query = '', Int :$at --> Result) {
    given $key {
        when 'Ctrl-C' {
            $!interrupt-requested = True;
            @!pending = ();
            set-continuation('');
            Result.new(:ok, :op<key>, :value<interrupted>)
        }
        when 'Ctrl-D' {
            $!exit-requested = True;
            $!exit-code = 0;
            Result.new(:ok, :op<key>, :value<exit>)
        }
        when 'Ctrl-R' {
            my @hits = @!history.grep({ .contains($query) });
            Result.new(:ok, :op<key>, :value(@hits.List))
        }
        when 'Up' | 'Down' {
            my $i = $at.defined ?? $at !! @!history.elems - 1;
            $i = $i - 1 if $key eq 'Up';
            $i = $i + 1 if $key eq 'Down';
            $i = 0 if $i < 0;
            $i = @!history.elems - 1 if $i >= @!history.elems;
            Result.new(:ok, :op<key>,
                       :value(@!history.elems ?? @!history[$i] !! ''))
        }
        default {
            Result.new(:!ok, :code(1), :op<key>,
                       :err("未绑定按键: $key"))
        }
    }
}
