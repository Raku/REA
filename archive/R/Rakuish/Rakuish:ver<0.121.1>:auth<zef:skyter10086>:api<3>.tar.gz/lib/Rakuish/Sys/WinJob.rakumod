unit module Rakuish::Sys::WinJob;

# Rakuish::Sys::WinJob —— Windows Job Object 薄封装（0.117.0 / V-309）。
#
# 为什么需要它：引擎（Eval::Client 起的子进程）被 Ctrl-C 杀掉时会重启并从
# 快照恢复，但它**启动过的前台命令和孙进程没有任何人回收** —— Windows 没有
# POSIX 进程组，也没有「父进程死了孩子跟着死」这回事。ADR-0031 的 V-905
# 当年就是这么写进「不做」的。
#
# Job Object 一次解决：把引擎塞进一个 job，设 JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE，
# 句柄一关（宿主退出 / 引擎重启前主动 TerminateJobObject），子树整体回收。
#
# 这不涉及 fg/bg 语义，与「显式拒绝 job control」的立场不冲突（ADR-0031）。
# 唯一的取舍是：job 里的进程不能再被**移出**（Windows 7 起支持嵌套 job，
# 但移出需要 Job 支持 breakaway，这里不开）。
#
# 所有 native 符号都是**调用时**解析；非 Windows 上 `supported` 为 False，
# 调用方据此跳过，加载模块本身不碰 kernel32。

use NativeCall;

constant JOB-OBJECT-LIMIT-KILL-ON-JOB-CLOSE            = 0x0000_2000;
constant JOB-OBJECT-EXTENDED-LIMIT-INFORMATION-CLASS   = 9;
# AssignProcessToJobObject 要求 PROCESS_SET_QUOTA | PROCESS_TERMINATE。
constant PROCESS-SET-QUOTA                             = 0x0100;
constant PROCESS-TERMINATE                             = 0x0001;
# IsProcessInJob 要 PROCESS_QUERY_LIMITED_INFORMATION，否则返回 0 而不是
# 「不在 job 里」—— 0.117.0 一开始就漏了它，诊断一直报 False。
constant PROCESS-QUERY-LIMITED                         = 0x1000;

# 布局照 winnt.h，**平铺**成一张表（不嵌套 CStruct：Rakudo 的 nativesizeof
# 对嵌套 CStruct 算不对，实测外层报 48 而不是 144，SetInformationJobObject
# 于是静默失败 —— job 建出来但没有任何限制，最坏的一种错法）。
#
#   JOBOBJECT_BASIC_LIMIT_INFORMATION  x64 = 64 字节（LimitFlags 后 4 字节填充、
#   ActiveProcessLimit 后同样），IO_COUNTERS = 48，再跟 4 个 SIZE_T。
class ExtendedLimitInformation is repr('CStruct') {
    has int64  $.per-process-user-time-limit is rw;
    has int64  $.per-job-user-time-limit is rw;
    has uint32 $.limit-flags is rw;
    has uint32 $.pad-after-flags is rw;
    has uint64 $.minimum-working-set-size is rw;
    has uint64 $.maximum-working-set-size is rw;
    has uint32 $.active-process-limit is rw;
    has uint32 $.pad-after-active is rw;
    has uint64 $.affinity is rw;
    has uint32 $.priority-class is rw;
    has uint32 $.scheduling-class is rw;
    has uint64 $.read-operation-count is rw;
    has uint64 $.write-operation-count is rw;
    has uint64 $.other-operation-count is rw;
    has uint64 $.read-transfer-count is rw;
    has uint64 $.write-transfer-count is rw;
    has uint64 $.other-transfer-count is rw;
    has uint64 $.process-memory-limit is rw;
    has uint64 $.job-memory-limit is rw;
    has uint64 $.peak-process-memory-used is rw;
    has uint64 $.peak-job-memory-used is rw;
}

our sub CreateJobObjectW(Pointer $attributes, Pointer $name --> Pointer)
    is native('kernel32') is symbol('CreateJobObjectW') { * }
our sub SetInformationJobObject(Pointer $job, int32 $class, Pointer $info, uint32 $len --> int32)
    is native('kernel32') is symbol('SetInformationJobObject') { * }
our sub AssignProcessToJobObject(Pointer $job, Pointer $proc --> int32)
    is native('kernel32') is symbol('AssignProcessToJobObject') { * }
our sub TerminateJobObject(Pointer $job, uint32 $code --> int32)
    is native('kernel32') is symbol('TerminateJobObject') { * }
our sub IsProcessInJob(Pointer $proc, Pointer $job, CArray[int32] $result --> int32)
    is native('kernel32') is symbol('IsProcessInJob') { * }
our sub OpenProcess(uint32 $access, int32 $inherit, uint32 $pid --> Pointer)
    is native('kernel32') is symbol('OpenProcess') { * }
our sub CloseHandle(Pointer $handle --> int32)
    is native('kernel32') is symbol('CloseHandle') { * }
our sub GetLastError(--> uint32) is native('kernel32') is symbol('GetLastError') { * }

# 结构体尺寸是这套调用的命门：SetInformationJobObject 的 cb 传错会返回
# FALSE，而且错得很安静（拿到的 job 没有任何限制，等于没设）。
our sub layout-ok(--> Bool) is export {
    # 只对 x64 成立；32 位 Rakudo 上这套偏移全错，直接降级不启用。
    $*DISTRO.is-win && $*KERNEL.bits == 64
        && nativesizeof(ExtendedLimitInformation) == 144;
}

our sub supported(--> Bool) is export { $*DISTRO.is-win }

# 建 job 并设 KILL_ON_JOB_CLOSE。失败返回 Nil（调用方降级，不影响主流程）。
our sub create(--> Pointer) is export {
    return Pointer unless supported();
    return Pointer unless layout-ok();
    my $job = CreateJobObjectW(Pointer, Pointer);
    return Pointer unless $job.defined;   # NULL 回来的是类型对象
    my $info = ExtendedLimitInformation.new;
    $info.limit-flags = JOB-OBJECT-LIMIT-KILL-ON-JOB-CLOSE;
    my Int $rc = SetInformationJobObject(
        $job, JOB-OBJECT-EXTENDED-LIMIT-INFORMATION-CLASS,
        nativecast(Pointer, $info), nativesizeof(ExtendedLimitInformation));
    unless $rc {
        CloseHandle($job);
        return Pointer;
    }
    $job;
}

# 注意：Pointer 的**实例**也 `~~ Pointer`（类型检查），所以判空只能看 defined。
our sub valid(Pointer $job --> Bool) is export {
    $job.defined;
}

# 把 pid 塞进 job。**必须在引擎还没开始干活时调** —— 之后它 spawn 的子进程
# 会自动继承 job 归属，孙进程也一样。
our sub assign(Pointer $job, Int $pid --> Bool) is export {
    return False unless valid($job) && $pid > 0;
    my $proc = OpenProcess(PROCESS-SET-QUOTA +| PROCESS-TERMINATE, 0, $pid.UInt);
    return False unless $proc.defined;
    LEAVE { CloseHandle($proc) }
    AssignProcessToJobObject($job, $proc) != 0;
}

# 连子树一起杀（Engine 重启 / 用户 Ctrl-C 走这条）。
our sub terminate(Pointer $job, Int $code = 1 --> Bool) is export {
    return False unless valid($job);
    TerminateJobObject($job, $code.UInt) != 0;
}

our sub close(Pointer $job --> Nil) is export {
    CloseHandle($job) if valid($job);
    Nil;
}

# 诊断 / 测试用：这个 pid 现在在不在 job 里。
our sub in-job(Pointer $job, Int $pid --> Bool) is export {
    return False unless valid($job) && $pid > 0;
    my $proc = OpenProcess(PROCESS-QUERY-LIMITED +| PROCESS-SET-QUOTA +| PROCESS-TERMINATE,
                           0, $pid.UInt);
    return False unless $proc.defined;
    LEAVE { CloseHandle($proc) }
    # 出参必须是 CArray：传裸 int32 会报「expected CPointer representation,
    # but got a NativeRef」。
    my $flag = CArray[int32].new;
    $flag[0] = 0;
    my $ok = IsProcessInJob($proc, $job, $flag);
    $ok != 0 && $flag[0] != 0;
}
