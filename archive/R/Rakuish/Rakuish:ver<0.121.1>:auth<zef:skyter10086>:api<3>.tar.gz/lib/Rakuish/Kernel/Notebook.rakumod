unit module Rakuish::Kernel::Notebook;

# Rakuish::Kernel::Notebook —— notebook 前端的协议适配层（0.109.0 / V-300）。
#
# 位置：Jupyter（或任何外部前端）与 `Kernel` 之间。它**不认识 ZMQ、不碰终端**，
# 只做一件事：把一条「请求 Hash」变成一条「响应 Hash」。这样：
#   · 传输层（Python 桥 / 未来的 web UI / 测试里的假客户端）可以换；
#   · 语义仍然只在 Kernel / Session 里，不出现第二套求值逻辑。
#
# 线上形状（一行一个 JSON 对象；由 `serve()` 负责读写）：
#   → {"op":"execute","code":"1+1","silent":false,"id":"c1"}
#   ← {"event":"busy","op":"execute","id":"c1"}          ← 0.113.0 主动推送
#   ← {"op":"execute","ok":true,"code":0,"out":"","err":"",
#      "display":{"content":"2","format":"text","formats":["text"],"meta":{...}},
#      "execution_count":1,"cwd":"...","id":"c1"}
#   ← {"event":"idle","op":"execute","id":"c1","ms":12}  ← 0.113.0 主动推送
#
# 帧分两类，靠字段区分：**带 `op` 的是响应**，**带 `event` 的是推送**。
# 推送是 0.113.0 加的（V-305）：`busy` / `idle` 包住每一格 execute，
# `engine` 报引擎生死（dead / restart / interrupted / restart-failed）。
# 一旦可能有推送插在中间，前端就不能再假设「下一行就是我的响应」——
# 认领靠请求带的 `id`（原样回显）。
#
# 为什么 `display` 单独一份：`text` 是「终端直接打印什么」（含 Out[n] 标签、
# 颜色），`display` 是「另一个前端拿什么去渲染」（零 ANSI、MIME 分档）。
# 前者给 TTY，后者给 notebook —— 混用会把 `Out[1] =` 印进浏览器。
#
# 边界（v1 明确不做）：
#   · 流式输出：`say` 的内容仍是一次性随 `out` 回来（引擎侧 chunk 是给 TTY 的）；
#   · stdin / `input()`：notebook 里的 stdin 请求回 `ok=false`，不假装支持；
#   · `! --tty` / 后台作业：需要真终端与作业表，notebook 里一律报错。

use Rakuish::Kernel;
use Rakuish::Kernel::Factory;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;
use Rakuish::Result;
use Rakuish::Audit;
use Rakuish::Incomplete;
use JSON::Fast;

# 与 META6.json 同步（t/51 守护）；只用于 kernel_info 的自我介绍。
my constant KERNEL-VERSION = '0.121.1';

# ── 一条请求 → 一条响应（纯映射，可单测）──────────────────────────
class Frontend is export {
    has $.kernel is required;
    has Str $.language = 'raku';

    method session() { $!kernel.session }

    method handle(%msg --> Hash) {
        my Str $op = (%msg<op> // '').Str;
        my %r = do given $op {
            when 'kernel_info' { self!kernel-info }
            when 'execute'     { self!execute(%msg) }
            when 'complete'    { self!complete(%msg) }
            when 'is_complete' { self!is-complete(%msg) }
            when 'inspect'     { self!inspect(%msg) }
            when 'shutdown'    { self!shutdown }
            default {
                %( ok => False, error => "未知 op: {$op}（支持 kernel_info / execute / "
                       ~ "complete / is_complete / inspect / shutdown）" )
            }
        };
        %r<op> = $op unless %r<op>:exists;
        # 0.113.0 / V-305：请求带 id 就原样回显 —— 一旦协议里出现
        # **主动推送**帧（busy / idle / engine），一问一答的顺序就不再是
        # 唯一线索，前端得靠 id 把响应认领回去。
        %r<id> = %msg<id> if %msg<id>:exists;
        %r;
    }

    method !kernel-info(--> Hash) {
        %(
            op                 => 'kernel_info',
            ok                 => True,
            protocol_version   => '5.3',
            implementation     => 'rakuish',
            implementation_version => KERNEL-VERSION,
            language_info      => %(
                name        => $!language,
                version     => $*RAKU.version.Str,
                mimetype    => 'text/plain',
                file_extension => '.raku',
            ),
            banner             => "Rakuish {KERNEL-VERSION}（Raku {$*RAKU.version}）—— 交互式会话"
                                  ~ "（Out[n] / _ / notebook 共用同一套）",
            help_links         => [],
        );
    }

    method !execute(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        # 空码：Jupyter 允许（用户点了运行但没写东西），不该占格号。
        if !$code.trim.chars {
            return %( op => 'execute', ok => True, code => 0, out => '', err => '',
                      display => %(), execution_count => self.session.index,
                      cwd => self!cwd );
        }
        # 走 Kernel：Policy / 审计 / trail 一个都不绕过（V-182 不变）。
        my $r = $!kernel.execute(
            Request.new(:kind<source>, :payload($code), :origin<notebook>));
        my %out = (
            op              => 'execute',
            ok              => ?$r.ok,
            code            => $r.code,
            out             => $r.out,
            err             => $r.err,
            display         => ($r.bundle // %{}).Hash,
            streamed        => ?$r.streamed,
            execution_count => self.session.index,
            cwd             => self!cwd,
        );
        %out<silent> = True if ?(%msg<silent> // False);
        %out;
    }

    method !complete(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        my Int $pos  = (%msg<cursor_pos> // $code.chars).Int;
        $pos = 0 if $pos < 0;
        $pos = $code.chars if $pos > $code.chars;
        # 候选是**整行替换**（和 TTY 的 Tab 一致），所以 cursor_start 固定为 0：
        # 若按单词边界给 start，前端会把 `$db.` 再拼一次。
        my $items = try { self.session.completions($code, $pos) };
        my @matches = $items.defined ?? $items.List !! ();
        %( op => 'complete', ok => True, matches => @matches,
           cursor_start => 0, cursor_end => $pos );
    }

    method !is-complete(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        # `is-incomplete` 是纯函数（不碰会话状态），所以不需要往返引擎。
        my Bool $more = False;
        try { $more = is-incomplete($code) };
        %( op => 'is_complete', ok => True,
           status => ($more ?? 'incomplete' !! 'complete'),
           indent => '' );
    }

    method !inspect(%msg --> Hash) {
        my Str $code = (%msg<code> // '').Str;
        my Int $pos  = (%msg<cursor_pos> // $code.chars).Int;
        my Str $name = self!word-at($code, $pos);
        return %( op => 'inspect', ok => True, found => False, text => '' )
            unless $name.chars;
        my %h = $!kernel.inspect($name);
        %( op => 'inspect', ok => True, found => ?%h<ok>,
           text => (%h<text> // '').Str );
    }

    method !shutdown(--> Hash) {
        try { self.session.shutdown if self.session.^can('shutdown') };
        %( op => 'shutdown', ok => True );
    }

    method !cwd(--> Str) {
        my $s = try { self.session.sys.cwd.Str };
        ($s.defined ?? $s !! $*CWD.Str);
    }

    # 光标前的最后一个名字：`$x` / `Box` / `JSON::Fast` / `ls`。
    method !word-at(Str $code, Int $pos --> Str) {
        my Str $pre = $code.substr(0, ($pos max 0) min $code.chars);
        my $m = $pre ~~ / [ '$' | '@' | '%' ]? <[A..Za..z_]> <[A..Za..z0..9_:-]>* $/;
        $m.defined ?? ~$m !! '';
    }
}

# ── 协议循环（唯一的 I/O 点）────────────────────────────────────────
# 0.113.0 / V-305：写端从「主线程独享」变成「主线程 + 看门狗线程」，
# 一帧必须整体落盘 —— 两条线程各写半行会让前端解析出一坨 JSON 碎片。
my Lock $out-lock .= new;

my sub emit(%h --> Nil) {
    $out-lock.protect: {
        try {
            $*OUT.print(to-json(%h, :!pretty) ~ "\n");
            $*OUT.flush;
        }
    };
    Nil
}

# 启动文件：与 TTY 同一套优先级（RAKUISH_RC → ~/.rakuishrc），
# RAKUISH_NO_RC 关掉。rc 的输出放进 ready 帧，由桥决定显不显示。
my sub rc-path(--> IO::Path) {
    my Str $env = (%*ENV<RAKUISH_RC> // '').Str;
    return $env.IO if $env.chars;
    return IO::Path if (%*ENV<RAKUISH_NO_RC> // '').Str.chars;
    my $home = try { $*HOME };
    return IO::Path unless $home.defined;
    my $p = $home.add('.rakuishrc');
    $p.e ?? $p !! IO::Path;
}

our sub serve(IO::Path :$lib --> Nil) is export {
    my $engine = $lib.defined
        ?? Rakuish::Eval::Client.new(:lib($lib))
        !! Rakuish::Eval::Client.new();
    $engine.start;

    my IO::Path $rc = rc-path();
    my $sess = Rakuish::Eval::Proxy.new(
        :client($engine), :rc-path($rc.defined ?? $rc.Str !! ''));
    # notebook 没有终端：颜色关掉（`display` 里本来也零 ANSI），
    # 也不开 stream（引擎的 chunk 帧会写本进程的 stdout，即协议流）。
    $sess.set-color(False);
    $sess.set-display(True);
    # 0.113.0 / V-305：引擎生死 → 一条 `event: engine` 帧。前端据此挂横幅、
    # 提示「状态已丢失」；Jupyter 桥只转播**空闲期**死亡（执行中的那次
    # 已经写在 execute 回复的 traceback 里了，重复播报是噪音）。
    $sess.on-engine-event = -> %ev { emit %( event => 'engine', |%ev ) };

    my Str $rc-out = '';
    my Str $rc-err = '';
    if $rc.defined && $rc.e {
        my $h = try { $sess.run-rc($rc.Str) };
        if $h.defined {
            $rc-out = ($h<out> // '').Str;
            $rc-err = ($h<err> // '').Str;
        }
        else {
            $rc-err = "启动文件执行失败: {$rc.Str}";
        }
    }

    my $kernel = Kernel.new(
        :session($sess),
        :policy(Policy.new(:profile<notebook>)),
        :audit(Rakuish::Audit.new(:default-origin<notebook>,
                                  :enabled(!(%*ENV<RAKUISH_NO_AUDIT> // '').Str.chars))),
    );
    my $front = Frontend.new(:kernel($kernel));

    # 0.113.0 / V-305：空闲期死亡的推送。
    #
    # 主循环阻塞在 `$*IN.get` 上 —— 引擎死在没有请求的那一刻，前端要等到
    # 下一条输入才知道（而那时它已经自动重启，前端看到的是「刚跑就失败」）。
    # 用一条独立的 OS 线程每 250ms 读一次 `alive`：读一个 Bool 的代价可以
    # 忽略，且它不占用调度器线程池（`Thread.start` 而不是 `start`）。
    #
    # `$busy` 的意义：执行中死亡由 `!revive` 负责报告（kind=restart），
    # 看门狗这时再喊一声「死了」只会让前端闪两条横幅。
    my Bool $stopping = False;
    my Bool $busy     = False;
    my Bool $noted    = False;
    Thread.start(name => 'rakuish-engine-watch', {
        loop {
            sleep 0.25;
            last if $stopping;
            my Bool $alive = True;
            try { $alive = ?$engine.alive };
            if $alive {
                $noted = False;
                next;
            }
            next if $busy || $noted;
            $noted = True;
            emit %( event => 'engine', kind => 'dead', alive => False,
                    reason => '引擎进程在空闲时退出（下一条输入会自动重启）' );
        }
    });

    # 引擎 pid 也写进 ready：调试与「前端想自己重启它」都得有句柄。
    # 注意 `Proc::Async.pid` 给的是 **Promise**（不是 Int），必须 `.result`。
    my Int $ep = 0;
    try { $ep = $engine.proc.pid.result.Int if $engine.proc.defined };

    emit %( event => 'ready', language => 'raku', pid => $*PID,
            engine_pid => $ep,
            cwd => $sess.sys.cwd.Str,
            version => KERNEL-VERSION,
            startup_out => $rc-out, startup_err => $rc-err );

    loop {
        my $line = $*IN.get;
        last unless $line.defined;
        next unless $line.trim.chars;
        my $msg = try { from-json($line) };
        my Bool $good = so ($msg.defined && $msg ~~ Hash);
        my %req = $good ?? $msg.Hash !! %( op => '' );

        my Str $op = (%req<op> // '').Str;
        # busy / idle 只包 execute：补全与 inspect 是**按键**触发的，
        # 每敲一个字符都播一次忙会让状态栏闪成噪音（Jupyter 也这么划）。
        my Bool $exec = $op eq 'execute';
        my %extra = %req<id>:exists ?? %( id => %req<id> ) !! %();
        my $t0 = now;

        if $exec {
            $busy = True;
            emit %( event => 'busy', op => $op, |%extra );
        }

        my %rep = $good
            ?? $front.handle(%req)
            !! %( ok => False, error => '请求不是 JSON 对象', op => '' );

        $busy = False if $exec;
        emit(%rep);
        # idle 在回复**之后**：Jupyter 的次序也是 busy → 输出 → reply → idle，
        # 前端看到 idle 就知道这一格彻底结束了，可以解锁输入。
        if $exec {
            emit %( event => 'idle', op => $op,
                    ms => ((now - $t0) * 1000).Int, |%extra );
        }
        last if (%rep<op> // '') eq 'shutdown';
    }
    $stopping = True;
    try { $engine.shutdown };
    Nil;
}
