# 持续集成（0.120.1）

> 状态：**本地 CI 入口已接并双平台实测；云端自动触发未启用。**
> 远端是 `https://gitee.com/skyter10086/rakuish.git`（Gitee），不是 GitHub。

## 1. 为什么是这样

`A` 路线要的是「把 63 文件 / 2815 断言从仓库自述变成**可复核**」（数字随每次发布更新）。
这一条由 `tools/ci.sh` 达成：任何人 clone 后跑一条命令，得到机器可读报告
与严格退出码。

**本版故意不放一个「看起来像 CI、但永远不会跑」的 YAML**：

- 远端是 Gitee，GitHub Actions 的 `.github/workflows/*.yml` 不会触发；
- Gitee Go 需要在仓库网页端开通流水线，且构建机里默认**没有 Rakudo**
  （本项目要求 Rakudo ≥ 2025.12 的 `:pty`，发行版自带包通常太旧）；
- Gitee Go 的 `shell@agent` 是「到主机组执行」、要 `hostGroupID`，
  不是在构建机内跑脚本；通用构建插件的 `commands:` 可用，但整条链路
  在本会话里**无法端到端验证**。

写了不验证就等于挂牌子。所以这里把两件事分开交付：
**可复核的入口（已验证）** 与 **云端触发的启用配方（未启用，见 §5）**。

## 2. 用法

```bash
bash tools/ci.sh          # Linux / WSL / Windows(Git Bash) 通用
```

### 2.1 无 TTY 环境的依赖安装（容器 / 构建机）

`Terminal::API` 的上游测试在非 TTY 环境会失败（`get-config failed`），
直接 `zef install .` 会中途断掉。干净环境按下面顺序装：

```bash
zef install Terminal::API        --force-test --force-install
zef install Terminal::LineEditor --force-install
zef install .                    --force-install
```

`--force-test` 只针对上游测试失败；Rakuish 自己的测试照常跑（`tools/ci.sh`）。
CI 脚本里请把「依赖安装」与「应用测试」分成两个步骤记录，不要混在一起
（依赖测试失败是上游问题，应用测试失败才是本仓库的问题）。

平台自动判定（`uname -s`）：

| 平台 | 实际 runner | 断言数来源 |
|---|---|---|
| Linux / WSL | `bash tools/run-all.sh` | 按当前 `t/*.t` 清单逐个统计 `tmp/<name>.out` 的 `^ok ` 行 |
| Windows（MINGW / MSYS / CYGWIN） | `prove6 -Ilib t` | prove6 汇总行的 `Tests=N`；缺失时回退到上一行的方式 |

产物：

- `tmp/ci-report.txt` —— `key=value` 机器可读报告
- `tmp/ci-runner.log` —— 套件原始输出（失败时末尾 20 行打到 stderr）
- `tmp/console.log` —— 真终端层原始输出（失败时末尾 25 行打到 stderr）

两层验收（0.86.0 起）：

| 层 | 内容 | 为什么单列 |
|---|---|---|
| 套件 | `prove6 -Ilib t` / `run-all.sh` | 常规回归 |
| **真终端** | `tools/ctrl-c-posix.py`（真 PTY）/ `tools/ctrl-c-win.py`（真 ConPTY）/ `tools/pager-posix.py`（真 PTY，0.92 分页） | 信号投递依赖真终端：套件里用 `kill -INT` 只能验 handler 逻辑，验不了「`\x03` 会不会变成 SIGINT / `CTRL_C_EVENT`」。Windows 版还多一个 `! --tty` 场景（t/30 的对应物）。分页探针验的是「行编辑器交还终端之后，回车真的到得了分页器」——这条在套件里测不出来 |

实测（0.120.1，2026-11-24）：

```
version=0.121.0  platform=windows  runner_exit=0  files=73  assertions=3270
not_ok=0         console=未跑      result=PASS
version=0.121.0  platform=linux    runner_exit=0  files=73  assertions=3270
not_ok=0         console=未跑      result=PASS
```

（0.121.0 备注：**Arrow 写侧支持多批与流式（V-317 / ADR-0045）**——写入器拆成
`IpWriter.start / add-batch / finish`，sink 可以是内存 `Buf` 或文件句柄：
`write-ipc(:batch-size)` 多批、`write-ipc-stream(行迭代器或 Table 迭代器, $path)`
边拉边写（内存里只留一批）。schema 由首批推断后固定，每批编码前逐列核类型
（`"abc".Int` 在 Raku 里是 0，不核就静默写脏数据）；嵌套值、表流列不一致、
空流都明确报错；落盘先写 `.part` 再 rename，失败不留半截文件。实测 5 万行 × 3 列
单批 2.65 s / 10 批 2.70 s；50 万行流式 100 批 23.9 s / 14.9 MB，pyarrow 26
读回批数与类型全对。新增 `ipc-batch-count` 与 `save-data :batch-size`；
t/77 46 条（73 / 3270）。本版未改中断路径，真终端层未跑。
（0.120.1 备注：**Arrow 读侧按类型分流（V-316 / ADR-0044）**——评估时实测
`Arrow::IPC.decode-ipc` 两个问题：5 万行 × 5 列慢 4.6 倍（20 s vs 自研 4.2 s），
以及对越界元数据**段错误**（截断文件、Duckula 坏 IPC 都是 rc=139，`try` 接不住，
一次坏文件带走整个 REPL）。现在先走自研读入器，只有
`X::Rakuish::Arrow::UnsupportedType`（嵌套/字典/压缩）才回退包；结构错误不回退。
顺带修 `ipc-format` 里 `my %m = try {...}` 把 Nil 塞进 Hash、在 try 外抛
`X::Hash::Store::OddNumber` 的怪错。t/74 +8 条（42 / 全库 3224）。
本版未改中断路径，真终端层未跑。
（0.120.0 备注：**Table 上跑 SQL（V-315 / ADR-0043）**——`$t.sql(...)` 与
`sql({a => $t1, ...}, ...)` 把 Table 交给 DuckDB（Duckula）计算，交换格式是 `$*TMPDIR`
下的临时 Arrow IPC 文件：写走自研（DuckDB 能直接读，等于第三方兼容性验证）、
读走 `Session.read-arrow`，结果从 `Frame.rows` + `dtypes` 还原（**不用**
Duckula 0.33.1 的 `ipc-buf`：它给 timestamp/date 列产出的字节流 pyarrow 报
Not an Arrow file、`Arrow::IPC` 解码直接段错误）。只读守卫、NULL 与时间类型
还原、嵌套列转 JSON 文本；顺带修掉写侧对嵌套列静默写成 `.Str` 噪声的损坏
（现在抛 `X::Rakuish::Arrow`）。新增 t/76 43 条（72 / 3216）。Duckula 是可选依赖
（本机双平台都已装，测试未走 skip 分支）。
本版真终端层未跑（没有新的中断路径改动）：`tools/ctrl-c-win.py` 只在 0.119.0
验证过三场景，本条记录不冒充本轮结果。
（0.119.0 备注：**Windows 上 Ctrl-C 只收外部命令（V-314 / ADR-0042）**——引擎
spawn 后发 `child` 帧（pid），前端把这条命令收进独立 Job Object；Ctrl-C 走
`TerminateJobObject` 只收命令子树，`exec` 正常返回、终帧 `code=130`，引擎不重启、
会话变量与 `Out[n]` 保留。子进程收不到 `CTRL_C_EVENT`（Raku 建了独立进程组），
所以「等它自己死」不可行；3 秒兜底才回到杀引擎。`! --tty` 与 Raku 求值路径不变。
真终端层本轮**跑了**：`python tools/ctrl-c-win.py` 三场景全过
（死循环中断/快照恢复、`! --tty` 信号归属、`!` 命令中断不重启），故 Windows
记 `console=pass`。新增 t/75 3 条（71 / 3172）。
0.118.3 备注：**Arrow 读侧改走 Arrow::IPC（V-313 / ADR-0041）**——`open-data`
的 `.arrow` 由独立包解码（支持 list/struct/map/字典），约 90 行适配还原
DateTime / 秒数 / Rat，失败退回字符串并标 `str`；写侧仍自研。**压缩批读前拦截**：
包 0.1.0 不处理 BodyCompression 也不报错（`[1,2,3]` → 24 / 4.6e16）。
META6 增依赖 `Arrow::IPC:ver<0.1.0+>`。
0.118.2 备注：**二进制值的显示摘要（V-312 / SPEC §3.51）**——`Buf` / `Blob`
不再走 `.raku`（`Buf.new(1..4000)` 是 14 250 字符），改为「类型 + 字节数 +
前 16 字节」，认 `ARROW1` magic 但**不解析**内容、渲染路径不加载任何 Arrow
模块；`_` / `Out[n]` 里的值不截断。新增 t/73 16 条。
0.118.1 备注：t/72 的 `invoke` 把 cwd 固定到仓库根（否则从 `/tmp` 这类
目录手动跑会因 Rakudo 2026.11 的上游 USAGE bug 假红），并在 SPEC §3.50 记录该
怪癖；断言数不变（68 / 3119）。
0.118.0 备注：**脚本模式 MAIN 分派（V-311 / ADR-0040）**——`rakuish 文件 参数`
把 EVAL 里的 `&MAIN` 交给 Rakudo 的 `RUN-MAIN`，参数解析 / 强转 / `multi` /
`--help` / `sub USAGE` / 退出码与 `raku 文件` 一致；新增 t/72 42 条。
（0.117.1 当时真终端层没跑成：那个会话没有真控制台，`tools/ctrl-c-win.py`
停在 winpty 的 `cols > 0 && rows > 0` 断言 —— 属环境限制，与套件无关。）
0.117.1 备注：**测试夹具修复（V-310 / SPEC §3.49）**——t/65 原来用
`! echo hi` 验 notebook 的 `!` 路径，但 `echo` 在 cmd / PowerShell 里是内置
命令、没有 `echo.exe`（只有 Git Bash 的 `usr/bin` 才带），于是在没有 Git
`usr/bin` 的 PATH 上 `zef install .` 会红两条。夹具改成
`! '$*EXECUTABLE' -e 'say 42'`（路径用单引号，双引号里的 `\` 会被分词吃掉），
并补 3 条反面断言锁「起不来的程序 → 127 + 带命令名的 err」；t/65 105 → 108。
Windows 套件另外在**去掉 Git `usr/bin` 的 PATH** 上复跑一遍（67 / 3077，
not_ok=0），确认不再依赖 Git 自带的 exe。
0.117.0 备注：Windows 子树回收（V-309 / ADR-0039）——`Rakuish::Sys::WinJob`
把引擎归类进 Job Object，`KILL_ON_JOB_CLOSE` 兜住宿主退出，Ctrl-C / restart /
shutdown 统一走 `TerminateJobObject`，引擎起的命令与孙进程一并回收（V-905 的
Windows 侧）。新增 t/71 17 条，POSIX 整段 skip。同版更正 ADR-0010 §3：
真机实测证明只有 `CTRL_C_EVENT` 不能定向投递，`CTRL_BREAK_EVENT` 可以（语义近
SIGQUIT）；resize 仍按格轮询，不做 WINDOW_BUFFER_SIZE_EVENT。
0.116.0 备注：

```
version=0.116.0  platform=windows  runner_exit=0  files=66  assertions=3056
not_ok=0         console=pass      result=PASS
version=0.116.0  platform=linux    runner_exit=0  files=66  assertions=3056
not_ok=0         console=pass      result=PASS
```

（0.116.0 备注：Arrow IPC 读写（V-308 / ADR-0038）——纯 Raku 解 FlatBuffers，
文件与流两种模式都认；读 int/float/bool/utf8/binary/date/time/timestamp/decimal，
写 int64/double/bool/utf8/timestamp[ms]；字典编码 / 压缩 / 嵌套类型一律明确报错；
`.arrow`/`.feather`/`.ipc` 接进 open-data / save-data，不走 `:allow-external`。
新增 t/70 68 条断言，夹具由 pyarrow 26 生成后提交（CI 不需要 pyarrow）。
WSL 首轮 t/56 / t/59 因 PTY 争用偶发失败，重跑即 0 —— 与本次改动无关。
0.115.0 备注：

```
version=0.115.0  platform=windows  runner_exit=0  files=65  assertions=2987
not_ok=0         console=pass      result=PASS
version=0.115.0  platform=linux    runner_exit=0  files=65  assertions=2987
not_ok=0         console=pass      result=PASS
```

（0.115.0 备注：`cells` 格记录与导出（V-307）——`!finish` 落 seq/index/input/ok/
op/code/ms，`log-line` 补 rendered；`--text` 是可重放脚本（每格补 `;`、开头
`no worries;`），`--json` 是 `rakuish-cells@1`；`cells` 自己不进记录（否则自指）。
新增 t/69 59 条断言。0.114.0 备注：`source` 在会话里跑脚本（V-306）——逐行喂 `eval-line`，脚本与
会话双向共享变量与声明；脚本内部的行不占 `Out[n]` / history / perf（进入前
快照、退出还原）；错误按 `文件:行` 报出且不中止后续行；`sub MAIN` 在给了参数时
按位置参数调用，调不上如实说明边界；`exit` / `exit N` / `exit;` 映射成会话退出
而不是杀引擎。顺带修掉 `our sub f {}` 被 `!scan-cell` 当成变量声明吃掉、以及
`our` 不在 `!pure-decl` 的声明清单里两个老问题。新增 t/68 59 条断言。
0.113.0 备注：notebook 协议主动推送（V-305 / ADR-0037 §9）——`busy`/`idle`
包住每格 execute（idle 在响应之后），`engine` 帧报崩溃 / 重启 / 快照恢复；
请求 `id` 原样回显；空闲期死亡由独立看门狗线程（250ms 读 `Client.alive`）发现。
顺带修掉 `Client.alive` 从 0.83 起就没生效的 `=:=` 判据（容器同一性 ≠ 对象同一性）。
t/65 60→105、t/66 24→33，共 +54 条断言；`tools/jupyter/smoke.py` 真内核端到端复跑通过。
0.112.0 备注：按 origin 分账（V-303）——`valid-origin` 约束 + `x-` escape hatch，
`Audit.by-origin` / `origin-summary` 合并内存与 JSONL，`audit` 命令与 Kernel 注入；
t/35 + t/40 + t/67 + t/37 共 +43 条断言。0.111.0 备注：Jupyter wrapper kernel（V-302 / ADR-0037 §8）——
`tools/jupyter/` 用 ipykernel 基类接管 ZMQ，Raku 侧仍是一行一 JSON；
MIME 直接转发 `display.mime`，格号用会话口径，shutdown 走 control 通道；
新增 t/66 24 条断言，`tools/jupyter/smoke.py` 用真内核做端到端冒烟。
0.110.0 备注：展示层 HTML 与 MIME 分档（V-301）——`Display::Bundle` 增加
`html`，`Table.to-html` + 统一转义；`to-mime` 一次给齐四档，notebook 的
`display.mime` 用它；`to-hash(:mime)` 默认关。t/38 +17、t/65 +10 断言。
0.109.0 备注：Notebook 协议层（V-300 / ADR-0037）——`Rakuish::Kernel::Notebook`
+ `bin/rakuish-notebook` 一行一 JSON；`Result.bundle` 承载 MIME 分档（仅请求
`display:true` 时计算）；Server/Client/Proxy 增加 `inspect`（复用 `名字?`）；
新增 t/65 50 条断言（含真实子进程 ready / 行协议冒烟）。0.108.0 备注：会话自省与重跑（V-299）——`who` / `whos` / `名字?` / `rerun`；
新增 t/64 63 条断言；`!resolve-type` 的 prelude 扩到全部声明，本会话 class 的
方法补全一并修好。0.107.0 备注：方法名补全（V-298）——`$obj.` / `Out[n].` / `Type::Name.`
Tab 出方法名；新增 `Rakuish::REPL::Methods`（纯函数）+ t/63 41 条断言。
0.106.2 备注：`use` 的跨格可见性（V-297）——扫描阶段给顶层 `use` 补 `;`，
prelude 重放同样补，混合格的顶层 `use` 也收进 prelude；新增 t/62 25 条断言
+ t/51 1 条版本一致断言。0.106.1 是入口启动成本（V-296）——`bin/rakuish` 变薄启动器，
`Rakuish::CLI` 走预编译缓存，`--version` 直读 META6，Kernel 构造走
`Rakuish::Kernel::Factory`。`-e '1+1'` 1.35s → 0.69s。0.106.0 是管道
与 CSV 收口（V-295）——CSV 行级切分、`where` 告警抑制、已知行数不重扫；
0.105.0 是文件锁 `with-lock`（V-294）。）

## 3. 失败判据（四条独立，任一即 FAIL）

1. **runner 退出码非 0** —— 含 `127`（`prove6` 不存在）、`2`（`env.sh` 找不到 raku）。
2. **输出里有** `not ok` / `# Failed test` / `Result: FAIL` / `[FAIL]`。
3. **防空跑**：`files` 或 `assertions` 为 0 直接 FAIL。
4. **真终端层失败**：探针退出码非 0 且非 2。

真终端层的 `2` 是「环境不具备」（没有控制台且找不到 winpty，或没有
python），记 `console=skip`、**不算失败也不算出绿**——报告里能看见，
不会被当成通过。

只看 `not ok` 会漏判：测试崩在中途时计数可能是 0 而退出码非 0
（`tools/run-all.sh` 头部注释记过这个坑）。只看退出码也不够，所以三条并列。

`ci.sh` **不安装 Rakudo**，缺 raku 时如实 FAIL，不静默跳过、不降级为「跳过」。

## 4. 前提（构建机）

- Rakudo ≥ 2025.12（`:pty` 相关用例），`raku` 可被 `tools/env.sh` 找到；
  优先级 `$RAKU` > `~/.rakubrew/versions/moar-2026.09` > 其它 rakubrew 版本 > PATH。
- zef 依赖：`JSON::Fast`、`Terminal::LineEditor`、`Terminal::API`；
  数据栈的可选依赖（`DB::DuckDB` / `DB::SQLite`）缺失时相关用例按既有语义跳过。
- 不需要 root、不需要网络、（Windows 侧）不需要管理员权限。

## 5. 云端触发：启用配方（本版未启用）

### Gitee Go（当前远端）

1. 仓库网页端 → 流水线 / Gitee Go → 新建流水线，选「自定义」；
2. 配置文件路径用 `.workflow/*.yml`（Gitee Go 的仓库内格式，
   `version: '1.0'` + `stages/steps` + `triggers`），或用网页可视化编排；
3. 构建步骤只填一条：`bash tools/ci.sh`；
4. 触发：`push` 到 `main` 与 PR。

**关键前提**：构建机镜像里要有 §4 的 Rakudo 与依赖。
Gitee 公共构建机没有预装 Rakudo，需要先准备安装步骤或自定义镜像——
这一步没做，所以流水线即使建了也会在 `env.sh` 处 exit 2。

### GitHub Actions（若将来镜像 / 迁移到 GitHub）

`.github/workflows/ci.yml` 的两个 job 只需分别执行 `bash tools/ci.sh`
（Linux 用 `ubuntu-latest`、Windows 用 `windows-latest` + Git Bash），
**同样要先装 Rakudo**。不要在干净 runner 上直接套用，否则必然 FAIL
——那不是 CI 通过了，是 CI 如实报「环境没准备好」。

## 6. 明确未验证 / 未承诺

- 云端自动触发**未启用**（Gitee Go 需网页端开通，本会话无法验证）。
- Windows 云端 runner 未验证；本地 Windows 是 Git Bash + 本机 Rakudo Star 2026.09。
- `assertions` 是 TAP `^ok ` 行数（或 prove6 的 `Tests=`），
  不是独立重算的断言真值；与 `t/51` 守的 provides、`t/52` 的模块冒烟是互补关系。
- CI 的 `console` 层只覆盖 **Ctrl-C 中断**这一条真终端契约；
  `tools/tty-check.py`、`tools/tty-termios-win.py`、`tools/tty-cjk-win.py`
  与 `zef install` 仍按 HANDOFF 的验收清单**手工**跑。
- Windows 的 `console` 层需要 winpty（Git for Windows 自带）：`ci.sh` 在
  Git Bash 里跑时自身没有控制台，探针会自己用 winpty 重启一次；找不到
  winpty 时记 `console=skip`，不会伪装成通过。
- 报告落在 `tmp/`（`.gitignore` 已忽略），不是长期存档；要留档得另接制品库。

## 7. 建议的停止条件

`bash tools/ci.sh` 在推送前跑一次，结果写进提交说明。
等真的把云端触发接通（并且第一次绿跑有日志链接可查）之后，
再把本文首行状态从「云端未启用」改掉 —— 不要提前改。
