# ADR-0043 · Table 的 SQL 计算交给 DuckDB（Duckula），交换格式用 Arrow IPC

- **日期**：2026-11-24
- **对象**：0.120.0（`Table.sql` / `Rakuish::Data::Duck::query`）
- **状态**：**已实施**
- **输入**：用户问「Arrow IPC 做好了吗，和 Arrow::IPC 以及 Duckula 联合处理」
- **相关**：SPEC V-315、[ADR-0038](ADR-0038-arrow-ipc.md)（自研 Arrow IPC）、
  [ADR-0041](ADR-0041-arrow-read-via-package.md)（读侧走 Arrow::IPC）

## 1. 三层现状（回答前半句）

| 环节 | 谁做 | 状态 |
|---|---|---|
| `.arrow` → `Table`（读、含 list/struct/map/字典） | `Arrow::IPC` 0.1.0 | 0.118.3 起（ADR-0041） |
| `Table` → `.arrow`（写） | `Rakuish::Data::Arrow`（纯 Raku，零原生依赖） | 0.116.0 起（ADR-0038） |
| `Table` → SQL → `Table` | Duckula / DuckDB | **本 ADR** |

前两层已经互通，但缺「一起用」的入口：拿 Arrow 文件读到 `Table` 之后，只能
用 `where` / `select` / `join` 这套 Raku 方法，做不了聚合窗口、`group by`、
多源 join。补的就是这一段。

## 2. 决定：Arrow IPC 当交换格式，计算交给 DuckDB

```
Table ──自研写──▶ .arrow(临时) ──Duckula read-arrow──▶ DuckDB 表
                                                          │ SQL
Table ◀──Frame.rows / dtypes── Duckula Frame ◀────────────┘
```

- **不自己实现 SQL**：`where` / `select` 是数据形状操作，`group by` 窗口函数
  是查询引擎的活；重写一遍只会和 DuckDB 越走越偏。
- **不让 Duckula 写 IPC**：0.33.1 的 `ipc-buf` 在 timestamp/date 列上产出的是
  坏字节流 —— pyarrow `open_file` 报 `Not an Arrow file`，pyarrow `open_stream`
  与 `Arrow::IPC.decode-ipc` 在同一个文件上都会**段错误**（实测
  `t/fixtures/arrow/temporal.arrow` 经 `Frame.ipc-buf` 再解码，rc=139）。
  （0.121.0 逐列复核修正了这里的表述：坏的是 **TIMESTAMP WITH TIME ZONE**；
  `DATE` / `TIME` / 无时区 `TIMESTAMP` / `DECIMAL` 都正常。详见
  `tmp/upstream-issues/duckula-ipcbuf-timestamptz.md`。）
  回读改走 `Frame.rows` + `Frame.dtypes` 的 Raku 值，绕开这条路径；
  上游修好后这条绕行可以撤。
- **写侧复用自研**：它写出的文件 DuckDB 能直接读（时间戳、日期、NULL 都对），
  这也顺便成了自研写入器的第三方兼容性验证。
- **多表**：`sql({ a => $t1, b => $t2 }, 'select ... from a join b using (k)')`
  一次注册多张表；`$t.sql(...)` / `sql($t, ...)` 是单表糖（表名默认 `t`）。
  短命令不叫 `query`：引擎侧已有 `query(sql => '...')` 的具名参数约定，
  抢这个名字会把「少传参数」变成看不懂的错误；模块层仍叫 `Duck::query`。

## 3. 边界（都在 SPEC §3.54 写死）

- **只读**：`Session.sql` 的守卫会拒绝 `DROP` / `INSERT` 等；错误原样转成
  `X::Rakuish::Data`，点名「statement is not read-only」。
- **嵌套列**：`Table` 没有嵌套类型的表达式，进 DuckDB 前显式 `to-json` 成
  文本列（类型记 `str`）。可以 `like`、可以再 `from-json` 解回来，但**不能**
  在 SQL 里 `tags[1]` 或取 struct 字段 —— 这是如实的能力边界，不是 bug。
- **时间列**：SQL 结果里的 TIMESTAMP/DATE 还原成 `DateTime`；整列有一格解析
  失败就整列退回 `str`（和 `open-data` 口径一致）。
- **临时文件**：`$*TMPDIR` 下每张表一个 `rakuish-duck-*.arrow`，`LEAVE` 里
  删掉；t/76 断言前后数量一致。
- **可选依赖**：Duckula 不在 `depends` 里，没装时抛 `X::Rakuish::Unsupported`
  并给 `zef install Duckula` 提示；`Table.sql` 走 `require`，不会把原生
  libduckdb 拖进核心安装。
- **性能**：整表写一次 IPC 再读一次，是 O(行数) 的拷贝；换来的是不用自己
  维护查询引擎。大表场景后续可以换 `create-table` + Appender 直插（Duckula
  已有 `insert`），接口不用变。

## 4. 顺带修掉的静默损坏

`fields-of` 对未知类型落到 `default → utf8`，嵌套列的值走 `.Str`：Hash 的
`Str` 是 `age\t30\nname\tann`，于是 `save-data` 对嵌套表**看起来成功**、
写出来的却是噪声（0.119.0 之前一直如此）。0.120.0 起写侧对 `list` / `map`
（以及类型标错、值却是嵌套结构的列）明确抛 `X::Rakuish::Arrow`，报错里点名
列名并给出路（`select` 掉 / `to-json`）。

## 5. 验证

- `t/76-duck-sql.t` 43 条：聚合 / 计算列 / NULL / 浮点序 / 空表 / 时间往返 /
  多表 left join / 嵌套转 JSON / 只读守卫 / 非法表名 / 空 SQL / 原表不可变 /
  临时文件清理 / 写侧拒嵌套。
- 双平台套件与 `zef install`；WSL 侧 Duckula 已装（MoarVM）。
