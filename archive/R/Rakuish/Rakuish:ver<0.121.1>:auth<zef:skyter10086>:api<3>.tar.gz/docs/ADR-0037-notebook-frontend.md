# ADR-0037 · Notebook 前端：协议层先于传输层

- **日期**：2026-11-23（§9 追加于 0.113.0）
- **对象**：0.109.0 协议层；§8 = 0.111.0 传输层；§9 = 0.113.0 双向推送
- **状态**：**已实施**（`Rakuish::Kernel::Notebook` + `bin/rakuish-notebook` +
  `tools/jupyter/` wrapper + kernelspec；0.113.0 起支持服务端主动推送）
- **输入**：用户提问「如果要接 Jupyter 怎么改」「不接 Jupyter 能不能做到 IPython 那样」
- **相关**：[ADR-0013](ADR-0013-kernel-frontends.md)（Kernel / Request / DisplayBundle 的源头，
  `NotebookFrontend` 那一列就是这里落地的）、[ADR-0021](ADR-0021-engine-subprocess.md)（引擎子进程）、
  SPEC V-182 / V-183 / V-184 / V-300 / V-301 / V-302 / V-305

## 1. 问题：Jupyter 缺的不是能力，是「另一类前端」

拆开看，Jupyter 由三块组成：**ZMQ 传输**（shell / iopub / stdin / control /
heartbeat 五个 socket + HMAC 签名）、**消息协议**（execute / complete /
is_complete / inspect / kernel_info …）、**单元文档**（.ipynb + nbconvert 生态）。

rakuish 这边，前两块真正缺的只有「传输」：语义层早就有 Kernel 单入口、
`Result` 三态、跨格状态、补全（0.107 的 `.` 方法补全正好接上 Jupyter 的
complete_request 形态）、续行判定（`is-incomplete` 纯函数）、内容级展示
（`Display::Bundle`：text / markdown / json）。

所以本 ADR 把工作切成两段，**先做不依赖 ZMQ 的那段**：

```
Jupyter ⇄ 【传输桥：ZMQ ⇄ JSON 行】 ⇄ bin/rakuish-notebook ⇄ Kernel ⇄ 引擎
                    ↑ 未实施              ↑ 本 ADR            ↑ 已有
```

## 2. 决策

1. **适配层与传输解耦**：`Rakuish::Kernel::Notebook::Frontend.handle(%msg --> %reply)`
   只吃/吐普通 Hash，一行一个 JSON；`bin/rakuish-notebook` 是唯一的 I/O 壳。
   于是测试不需要 socket，未来的 web UI 也能复用同一层。
2. **Raku 侧不绑 ZMQ**：Windows 上没有 libzmq，`Net::ZMQ` 的安装文档只覆盖
   brew / apt；而 Jupyter 自己就带 pyzmq。传输交给外部桥，Raku 只负责语义。
3. **`text` 与 `display` 分开**：`text` 是「终端直接打印什么」（含 `Out[n]` 标签、
   颜色），`display` 是「另一个前端拿什么渲染」（零 ANSI、MIME 分档）。
   引擎只在请求带 `display:true` 时才算 `Display::Bundle` —— TTY 路径的字节数
   与 0.108 完全一致。
4. **`display` 落在 `Result.bundle`**：不能叫 `display` —— `Result` 已经有
   `method display`（文本摘要），属性会被方法遮蔽（开发中实测踩过一次）。
5. **complete 的候选是整行替换**：`cursor_start` 固定 0、`cursor_end` 是光标位。
   按单词边界给 start 会让前端把 `$db.` 再拼一次。
6. **inspect 复用 `名字?`**：`Session.inspect-name` 是唯一实现，`?` 命令与
   notebook 的 Shift+Tab 都走它；经 Server（`cmd:'inspect'`）/ Client / Proxy
   暴露，Kernel 只做转发与保底。
7. **is_complete 不往返引擎**：`is-incomplete` 是纯函数（不碰会话状态），
   在适配层本地算，省一次 IPC。

## 3. 线上协议（v1）

| op | 请求字段 | 响应字段 |
|---|---|---|
| `kernel_info` | — | `protocol_version`(5.3) / `implementation`(rakuish) / `implementation_version` / `language_info` / `banner` |
| `execute` | `code` `silent?` | `ok` `code` `out` `err` `display` `execution_count` `cwd` `streamed` |
| `complete` | `code` `cursor_pos` | `matches` `cursor_start` `cursor_end` |
| `is_complete` | `code` | `status`(complete/incomplete) `indent` |
| `inspect` | `code` `cursor_pos` | `found` `text` |
| `shutdown` | — | `ok` |

启动先发一帧 `{"event":"ready", ...}`（带 `version` / `cwd` / `startup_out` /
`startup_err`，后者来自 `~/.rakuishrc`）。协议按行切帧，**任何 `say` 都不许
进这条流**：用户代码的 stdout 由引擎捕获进 `out`，不经本进程。

## 4. 边界（v1 明确不做）

- **流式输出**：`say` 仍是一次性随 `out` 回来。引擎的 chunk 帧是给 TTY 的，
  notebook 不开 stream（开了会写到协议流里）。
- **stdin / `input()`**：不支持；将来要做得先定义 `stdin_request` 的交互语义。
- **`! --tty` / 后台作业**：需要真终端与作业表，notebook 里一律报错。
- **富 HTML / 图片**：`Display` 目前只有 text / markdown / json；HTML/PNG 是
  独立议题（富输出一直按 V-901/902 的口径卡着，不在这里顺手放开）。
- **中断**：引擎侧只有「杀掉重启」，所以 notebook 的 ⏹ 会丢会话状态。这条
  与 TTY 的 Ctrl-C 一致，但要在桥里如实报告，不假装支持。

## 5. 后果

- 现在就能验证：`echo '{"op":"execute","code":"1+1"}' | raku bin/rakuish-notebook`。
- 下一步只剩传输：Python 桥（`ipykernel.kernelbase.Kernel` 子类，或裸 pyzmq）
  + `kernel.json`，端到端用 `jupyter_client.BlockingKernelClient` 冒烟。
- 代价：多一层 JSON 编解码（每格一次），以及 `Result` 多一个 `bundle` 字段；
  两者都不影响 TTY 路径。

## 6. 否决的方案

| 方案 | 否决理由 |
|---|---|
| 纯 Raku 直接用 `Net::ZMQ` | Windows 缺 libzmq；ZMQ socket 非线程安全，5 个 socket + 心跳在 Raku 单线程模型里要自己写事件循环；生态安装成本最高 |
| 复用 `Jupyter::Kernel` 再塞 rakuish 的 Session | 它有自己的 `$Out`、magic、续行与补全语义，嵌进来等于换掉它的 evaluator；维护面比自己写协议层更大 |
| 每格起一个 `rakuish -e` 子进程 | 丢跨格状态（`my` / `use` / `Out`），而状态正是这个产品的核心 |
| 在 `Result` 里直接塞 `Display::Bundle` 对象 | `Display` 已经依赖 `Result`，反向依赖会成环；存 Hash（`to-hash` 的形状）即可 |

## 7. 0.110.0 扩展：`text/html` 与 MIME 分档

v1 的 `display` 只有 `text / markdown / json`。加 `text/html` 时守住了两条线：

- **HTML 属于展示层，不是富媒体**：表格 / 列表 / `<pre>` 都由已有的 `Table` /
  `Bundle` 数据生成，不引入新的求值或渲染依赖。内联图片、HTML 小组件这类
  需要外部资源的东西仍是独立议题（V-901/902）。
- **`Result` 不承载格式选择**：`to-mime` 一次给齐四档，挑哪一档是前端的事。
  内核不猜「你会渲染什么」，也不因为某个前端支持 HTML 就把 TTY 路径也改成 HTML。

代价与边界：

- 每个带 `display:true` 的格多算一次 HTML（字符串拼接，表格量级可忽略）；
  TTY 路径不经过它，字节数不变。
- **PNG 没有一起做**：它需要浏览器 headless 或 rsvg 起一个进程，属于「导出动作」。
  实测本机可行（Chrome 约 1 s/张，中文字体正常），但 WSL 侧没有渲染器，
  且 `Display` 的契约是纯函数 —— 放进这里会破坏契约。将来做导出命令时，
  路径应是「HTML → 渲染器 → PNG」，HTML 这一半已经现成。

## 8. 0.111.0：传输层按 wrapper kernel 落地

0.109 的边界写的是「传输层不在本版」。0.111 补上了，但走的是**官方 wrapper
kernel**而不是自己实现 ZMQ：Python 侧继承 `ipykernel.kernelbase.Kernel`，
ZMQ / HMAC / heartbeat 全由基类接，Raku 侧的一行一 JSON 协议保持不变。
这样 ADR 一开始画的「传输与语义分离」才真正闭环：换传输不碰 Kernel。

实施时相对原设计的三处修正：

| 原设计 | 实际实现 | 原因 |
|---|---|---|
| Python 侧 `_mime()` 手写映射 | 直接转发 `display.mime` | 0.110 已给齐四档；再写一套会漂移 |
| `execution_count` 二选一 | 用桥返回的会话格号 | 基类递增会把失败格算进去 |
| `kernel.json` 里 `interrupt_mode: signal` | 改成 `message` | 我们的中断是杀引擎重启，不能假装无损 |

验收方式是 `tools/jupyter/smoke.py`：用 `BlockingKernelClient` 起真实内核，
不依赖浏览器就能验证 shell / iopub / control 三条通道。t/66 只锁静态口径，
端到端不进双平台测试套件——WSL 侧没有 ipykernel，塞进去会让 CI 假失败。

## 9. 0.113.0：协议从「一问一答」到双向

0.109 的协议是严格串行的：写一行、读一行，读到的就是这条的响应。0.113 往
中间插了**服务端主动推送**，那条假设就不再成立。

- **分帧靠字段**：带 `op` 的是响应，带 `event` 的是推送。请求带 `id` 就原样
  回显，前端按 id 归位；不带 id 的旧客户端仍然可用（它只是要多跳过几行）。
- **`busy` / `idle` 只包 execute**，且 `idle` 在响应**之后** —— 与 Jupyter 的
  busy → 输出 → reply → idle 同序。补全 / inspect 不播：那是按键触发的，
  每敲一个字符播一次忙只会让状态栏闪。
- **`engine` 帧是真正的增量**：引擎崩溃、自动重启、快照恢复过去只写在
  那一条失败结果的文字里；现在它是一条独立事件，前端可以在没跑格子的时候
  就知道「内核刚死过、状态丢了」。

实施时发现两个必须一起解决的问题：

| 问题 | 处理 |
|---|---|
| 主循环阻塞在 `$*IN.get`，空闲期死亡没人发现 | 独立 OS 线程每 250ms 读 `Client.alive`（`Thread.start`，不占调度器线程池）；`$busy` 期间不报，那一段由 `!revive` 负责 |
| `Client.alive` 根本不会因进程退出翻假 | `$!proc =:= $proc` 判的是**容器同一性**，永远 False。改代际计数；0.83 起这行就没生效过，t/41 能过是因为求值中的崩溃走 `!receive` 的 CATCH |

Jupyter 侧的取舍：`busy`/`idle` 不转播（ipykernel 自己已发 status，转发就成双份），
`engine` 只转播 `kind=dead`（空闲期死亡没有 reply 可携带；执行中的已写在
execute 回复的 traceback 里，重复播报是噪音）。

**没有做**：中止长格子的推送（`interrupt` 仍是杀引擎重启）、流式输出
（`say` 仍一次性随 `out` 回来）、stdin 请求。三者都要动引擎侧的求值模型，
不是协议层能补的。
