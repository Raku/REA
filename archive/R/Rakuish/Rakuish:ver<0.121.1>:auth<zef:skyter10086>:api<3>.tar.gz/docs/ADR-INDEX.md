# ADR 决策索引（0.120.1）

> **本文件是仓库内 44 份 ADR 的目录与状态真值**；条款真值仍是 [`SPEC.md`](../SPEC.md)，
> 逐条理由看各 ADR 原文。资料库另有一篇《Rakuish 0.80.0 状态与决策索引》，
> 它是外部分析文档，**不作为仓库真值源**。
>
> 更新：2026-11-23 · 版本：0.120.1 · 条目数：44

## 1. 决策总表

| ADR | 主题 | 版本 | 状态 | 一句话结论 |
|---|---|---|---|---|
| [0001](ADR-0001-raku-native.md) | 不再实现 bash / POSIX 子集 | 0.29–0.34 | Accepted | 删双栈，Raku 是唯一命令语言；v2 的 `v/` 遗骸 0.80.1 已清除 |
| [0002](ADR-0002-agent-serve.md) | Agent 多客户端服务与请求级取消 | 0.63.0 | **已撤销**（0.81.0） | 每连接独立 Sys / Engine / 审计；**Agent 线整体删除，本文仅存档**（ADR-0019） |
| [0003](ADR-0003-repl-experience.md) | Vi/Helix 模态、hints、插件 | 0.66.0 | 已实施 | 插件加载即执行本地代码，不是沙箱 |
| [0004](ADR-0004-cursor-worker.md) | 流式 Cursor 与连接级 worker 硬取消 | 0.67.0 | Accepted | `--worker` 默认关闭；超时真 kill 进程，不保证杀孙进程（V-159 / V-905） |
| [0005](ADR-0005-data-workbench.md) | CSV 受控外部读写 + Engine 元数据 | 0.68.0 | Accepted | 与 Parquet 共用 `:allow-external`，Agent 不开放（V-152）；§4 反对持久求值器 |
| [0006](ADR-0006-data-profile.md) | CSV 方言 / describe / 补全启发式 | 0.69.0 | 已接受 | 7 项方言白名单；不做 SQL AST 级补全 |
| [0007](ADR-0007-tty-passthrough.md) | 交互式子进程 TTY 直通 | 0.70 / §3.5 补于 0.72.0 | 已接受 | `! --tty` 零捕获直通；`pty_exec` 是显式双开关的捕获入口，不等同实时 `tty_exec` |
| [0008](ADR-0008-input-interrupt-sql-forms.md) | 输入中断语义与 SQL 补全形态 | 0.71 | 已接受 | Ctrl-C 中断输入而非退出 REPL；`q[...]` / `sql =>` / `:sql(` |
| [0009](ADR-0009-tty-exec-sigint-contract.md) | `tty-exec` 期间 Ctrl-C 归属契约 | 0.72.3 / 0.72.4 订正 | 已接受 | 真 PTY 回归 + 交接期宿主 `termios` 快照恢复 |
| [0010](ADR-0010-job-control-feasibility.md) | job control 可行性评估 | 0.73.0 | 已实施（有边界） | `posix_spawnp` + `SETPGROUP` + `tcsetpgrp` + 自建 `waitpid`；**只到前台交接**，无 `&`/`jobs`/`fg`/`bg`/Ctrl-Z |
| [0011](ADR-0011-highlight-colors.md) | 结果着色与输入行高亮 | 0.74.0 | 已实施 | V-176 / V-177 / `t/33`；高亮只做单行词法，依赖 LineEditor 内部 |
| [0012](ADR-0012-userland-commands.md) | 用户层四项能力 + 三处订正 | 0.75.0 | 已实施 | 选项补全、`doc` 零 EVAL 内省、目录栈/书签、会话日志；顺手清掉 FEATURE-GAP 的 A1/A2/A3 |
| [0013](ADR-0013-kernel-frontends.md) | 人机共用内核与显示协议 | 0.76.0 | **部分实施，Agent 半边已作废** | `Kernel` / `Request` / `Policy` 统一 REPL 三入口；Agent 入口已删除（ADR-0019），「两者合并」不再有对象 |
| [0014](ADR-0014-console-codepage.md) | Windows 控制台码页收口 | 0.76.1 | 已实施 | 交互前切 UTF-8、退出还原；`tools/tty-cjk-win.py` |
| [0015](ADR-0015-command-table-and-cell-record.md) | 命令名单一数据源 + 输入序/格号分离 | 0.77.0 | 已实施 | `COMMAND-GROUPS` 派生全部视图；`!finish` 收口记账 |
| [0016](ADR-0016-display-bundle.md) | 展示包与格式协商 | 0.78.0 | 已实施（Agent 半边撤销） | text / markdown / json；Agent `display` 字段已删，bundle 本身保留；`html` 明确没有 |
| [0017](ADR-0017-stream-cancel.md) | 流式分帧与请求取消 | 0.79.0 | **已撤销**（0.81.0） | `stream` / `cancel` 只对 `exec` 生效；协议删除后无作用对象 |
| [0018](ADR-0018-audit-and-no-agent-scripts.md) | 统一审计 + 不给 Agent 脚本路径 | 0.79.2 / 0.80.0 | **部分撤销**（0.81.0） | V-607 与「不给 Agent 脚本路径」随 Agent 线撤销；**V-194…196 统一审计保留并成为唯一写入点** |
| [0019](ADR-0019-local-full-privilege-shell.md) | 放弃 Agent 线，做全权限本地 shell | 0.81.0 | **Accepted** | 删 Agent / Sandbox / 协议；Raku 源码直接 EVAL、`!` 直接起进程；**不设权限闸门**；审计保留 |
| [0020](ADR-0020-policy-slim.md) | Policy 只留有执行点的字段 | 0.82.0 | **Accepted** | 7 → 3（profile / allow-source / root）；删 allow-exec / read-only / allow-ops / limits —— 无执行点的声明就是牌子 |
| [0021](ADR-0021-eval-worker.md) | 求值引擎住子进程 | 0.83.0 | **Accepted** | 交互式 REPL 的 `EVAL` 在 `raku` 子进程里；`exit` / 段错误 / 死循环只带走引擎，父进程重启并如实告知状态丢失；`! --tty` 交回父进程 |
| [0022](ADR-0022-session-snapshot.md) | 会话快照：声明与纯值跨崩溃存活 | 0.84.0 | **Accepted** | 每成功格写 `%!state` + `@!decls`；崩溃重启重放声明与纯值；**语句格不重放**（副作用不幂等）；资源/闭包/超大值明确标失效 |
| [0023](ADR-0023-interrupt.md) | 求值期间的 Ctrl-C | 0.85.0 | **Accepted** | `Eval::Client` 在等响应时接管 SIGINT、主动 kill 引擎；归因为 `op=interrupted` / `code=130`（不是「引擎崩溃」）；清掉行编辑器的 `take-interrupt` 以免吞掉下一格 |
| [0024](ADR-0024-exec-stream.md) | `!` 的流式输出与超时选项 | 0.90.0 | **Accepted** | 终端里 `! cmd` 边跑边出（引擎发 chunk 帧、父进程打印）；`--capture` / `--timeout-ms` / `--no-timeout`；`Result.streamed` 保证不重放 |
| [0025](ADR-0025-startup-layer.md) | 启动文件 / 可编程 prompt / `set -o` | 0.90.0 | **Accepted** | `~/.rakuish/rc.raku` 在引擎里逐格执行且不占 `Out[n]`；`repl.prompt = -> {...}` 每格求值；5 个有执行点的选项（errexit / histexpand / noglob / noexpand / xtrace） |
| [0026](ADR-0026-structured-pipe.md) | 结构化管道：`Stream` 与记录喂给子进程 | 0.91.0 | **Accepted** | 惰性记录流 `stream()`（文本 / `!` 的 Result / Table / Cursor → `Seq of Hash`）；阶段方法链，惰性边界写明；`.exec` 写子进程 stdin。**不加管道语法**：`|` 属 V-901，`|>` 在 Raku 语法里不可定义 |
| [0027](ADR-0027-frontend-pager.md) | 前端分页：`explore` 的 `-- more --` 搬到父进程 | 0.92.0 | **Accepted** | 引擎只回文本、不判断分页（它的 stdout 是协议流）；`Pager.paginate` 注入读/写回调，入口按终端高度切页；`RAKUISH_PAGER=auto/always/never`（默认只给 `explore`）。真 PTY 验收接进 `tools/ci.sh` |
| [0028](ADR-0028-streaming-exec-stdin.md) | `Stream.exec` 的 stdin 流式化 | 0.93.0 | **Accepted** | `spawn` 新增 `:&in-chunks`（与 `:in` 互斥）；写一块 await 一块 = 背压，攒 16 KiB；子进程提前关 stdin 记 `in-early`、生成器抛记 `feed-error`；一次性来源的二次消费在 `exec` 调用点同步抛 |
| [0029](ADR-0029-zip-join-tee.md) | 两条流：`zip` / `join` / `tee` | 0.94.0 | **Accepted** | `zip` 按位置（默认短、`:longest` 补齐）；`join` 是 hash join（右表物化、左表惰性），`:how` 四档但**默认 left**（与 `Table.join` 一致）；`tee` 是 Unix 语义（写文件 + 透传），路径过会话 root，格式与 `exec` 共用。列命名只有 `Table.join-columns` 一份 |
| [0030](ADR-0030-interleave-append.md) | 按顺序收拢两条流：`interleave` / `append` | 0.95.0 | **Accepted** | `interleave` 交替（默认吐完长侧、`:shortest` 取短）；`append` 首尾接（同构契约，左读完才碰右）。两者每行原样、**不改列名**，不调用 `Table.join-columns`（那是合成一行时用的） |
| [0031](ADR-0031-job-control-api.md) | MoarVM 下的作业控制 API | 0.96.0 | **Accepted** | `bg-exec` / `bg-jobs` / `fg` / `bg` 是**普通 Raku 函数**，不碰 V-901；作业表建在父进程（引擎重启不丢孤儿），DSL 经 job 帧转过去；复用 ADR-0010 原语 + `wait-state`(WUNTRACED)/`signal-group`；Ctrl-Z 时 fg 归还前台不卡死；POSIX-only |
| [0032](ADR-0032-exit-linger-and-render-contract.md) | 退出残留线程消解与展示契约收口 | 0.98.2 | **Accepted** | linger guard（看门狗 `trap '' HUP` + 父子核验 + `kill -9`，退出码仍 `exit(N)`）；`Proxy.render` 只信 `rendered`（空串=刻意不展示，不再 dump 字段）；Windows NUL 的 `$*OUT.t` 误判改 CSBI 探真控制台 |
| [0033](ADR-0033-tail-follow.md) | `tail -f` 跟随：循环放父进程 | 0.99.0 | **Accepted** | 轮询跟随（0.2s，半行缓冲，截断/轮转重读）走 job 帧 `tail-follow` 在父进程跑；Ctrl-C 只停跟随（job-interactive 置停止标志，code=130），引擎不重启；`head -f` 拒绝 |
| [0034](ADR-0034-interaction-handfeel.md) | 交互手感层：建议/菜单/错误态/模糊/Ctrl-R | 0.100.0 | **Accepted** | 渲染管线「词法→语义标记→灰字建议」压在 `visible-input-field-string` 单点（宽度不变式不动）；ShiftTab 菜单打印后重画 prompt；Ctrl-R 循环历史检索（鱼式模态搜索推迟，需拥有输入循环）；补全前缀优先、零命中子序列回退 |
| [0035](ADR-0035-handfeel-followups.md) | 手感后续：逐词接受/建议来源/In·Out 引用/名字精确判定 | 0.101.0 | **Accepted** | ADR-0034 §4 五项后续落地四项：`Alt-→` 逐词接受、补全候选做灰字建议（历史优先+缓存）、`In[`/`Out[` 引用补全、引擎侧名字判定消除 listop 误标；第五项（鱼式模态+Tab-Tab）仍推迟 |
| [0036](ADR-0036-input-loop-ownership.md) | 输入循环自研评估：成本 / 触发条件 / 决策 | 0.101.0 | **Accepted（暂不实施）** | "输入循环"= 上游 `read-input` 的 `react whenever` 分发链（词法闭包不可从外部改）；三路线对比（fork / 推上游 / 近似体验），决策维持 ③；重开 ① 的五步清单与三个触发条件钉死，不许当补丁做 |
| [0037](ADR-0037-notebook-frontend.md) | Notebook 前端：协议层先于传输层 | 0.111.0 | **Accepted（协议层 0.109 / 传输层 0.111）** | `Frontend.handle(%msg) → %reply` 与 ZMQ 解耦；`text`（含 Out[n]）与 `display`（MIME 分档）分开，引擎仅按 `display:true` 计算；complete 走整行替换（cursor_start=0）；inspect 复用 `名字?`；v1 不做流式/stdin/tty/富媒体 |
| [0038](ADR-0038-arrow-ipc.md) | Arrow IPC 自己解析，不引 DuckDB 依赖 | 0.116.0 | **Accepted** | DuckDB 读不了 IPC 文件、Duckula 要拖原生库，所以自己解 FlatBuffers（读 500 行量级）；支持 int/float/bool/utf8/binary/date/time/timestamp/decimal；字典编码、压缩、嵌套类型一律明确拒绝；`open-data` / `save-data` 按扩展名分发，不需要 `:allow-external` |
| [0039](ADR-0039-win-job-subtree.md) | Windows 子树回收用 Job Object，不动 fg/bg | 0.117.0 | **Accepted** | 引擎归类进 job + `KILL_ON_JOB_CLOSE`：Ctrl-C / restart 走 `TerminateJobObject` 连子树一起收，宿主退出靠关句柄兜底；与 fg/bg 无关，ADR-0031 的 POSIX-only 立场不变；顺带更正 ADR-0010 §3（`CTRL_BREAK` 可定向、语义近 SIGQUIT） |
| [0040](ADR-0040-script-main-dispatch.md) | 脚本模式的 MAIN 分派交给 RUN-MAIN | 0.118.0 | **Accepted** | 不自己解析 argv，也不起子进程：在 EVAL 末尾追加 `(::('&MAIN') !~~ Failure) && RUN-MAIN(::('&MAIN'), Nil)` —— 尾巴在 EVAL 内部，`RUN-MAIN` 的 `callframe(1).my` 正好是脚本顶层（`sub USAGE` / `%*SUB-MAIN-OPTS` 都还在）；软查找避开 `Failure` 绑定与 sink 爆炸；`$*PROGRAM-NAME` 用绝对路径绕开 Rakudo 2026.11 的 USAGE 崩溃；脚本输出不捕获（否则 `exit` 前的 say 全丢）；Kernel 新增 `kind<script>`，与 `source` 共用 403 门与审计口径 |
| [0041](ADR-0041-arrow-read-via-package.md) | Arrow 读侧依赖 Arrow::IPC，写侧保留自研 | 0.118.3 | **Accepted** | 读侧 API 是「路径 → names/formats/cols」，约 90 行适配就能拿到 list/struct/map/字典；写侧的鸭子接口要 Arrow C Data 视图，Table 喂不进去，迁过去要先写 CData 导出器（更贵）。适配层把时刻还原成 DateTime/秒/Rat，失败退回字符串并标 `str`；**压缩批读前拦截**（Arrow::IPC 0.1.0 不解压也不报错，会把 `[1,2,3]` 解成 24 / 4.6e16） |
| [0042](ADR-0042-win-ctrl-c-child.md) | Windows 上 Ctrl-C 只收外部命令，不重启引擎 | 0.119.0 | **Accepted** | 引擎 spawn 后发 `child` 帧（pid），前端把它收进命令级 Job Object；Ctrl-C 只 `TerminateJobObject` 命令子树，`exec` 正常返回、终帧报 130，会话变量与 `Out[n]` 全保留。子进程收不到 `CTRL_C_EVENT`（Raku 建了独立进程组），所以「等它自己死」与「引擎侧杀」都不可行。Raku 求值（`sleep`/`loop{}`）没有子进程，仍按 ADR-0023 杀引擎；3 秒兜底防极端卡死 |
| [0043](ADR-0043-table-sql-via-duckula.md) | Table 的 SQL 计算交给 DuckDB/Duckula，交换格式用 Arrow IPC | 0.120.0 | **Accepted** | 读 `Arrow::IPC`、写自研、算 DuckDB，桥只做「Table → 临时 .arrow → read-arrow → SQL → Frame.rows」；不让 Duckula 写 IPC（0.33.1 的 `ipc-buf` 对 timestamp/date 产出坏流，pyarrow 报 Not an Arrow file、`Arrow::IPC` 段错误）；单表 `t` / 多表 `query`，只读守卫，NULL 与时间类型还原，嵌套列转 JSON 文本；顺带让写侧对嵌套列明确报错而不是静默写成 `.Str` |
| [0044](ADR-0044-arrow-read-routing.md) | Arrow 读侧按类型分流：标量走自研，嵌套走包 | 0.120.1 | **Accepted** | 实测 `decode-ipc` 5 万行慢 4.6 倍（20 s vs 4.2 s）且对越界元数据**段错误**（截断文件 rc=139，`try` 接不住）。改为先走自研（边界检查齐全），只在 `X::Rakuish::Arrow::UnsupportedType`（嵌套/字典/压缩）时回退 `Arrow::IPC`；结构错误绝不回退。顺带修 `ipc-format` 里 `my %m = try {...}` 在 try 外抛 `X::Hash::Store::OddNumber` 的怪错 |
| [0045](ADR-0045-arrow-batch-write.md) | Arrow 写侧支持多批与流式 | 0.121.0 | **Accepted** | 写入器拆成 `start/add-batch/finish`（`IpWriter`），sink 可为 `Buf` 或文件句柄：`write-ipc(:batch-size)` 多批、`write-ipc-stream(流, 路径)` 真流式（内存只留一批）。schema 首批推断后固定，`check-batch` 逐列核类型（`"abc".Int` 是 0，不核就静默写脏数据）；嵌套值、表流列不一致、空流都明确报错；落盘先写 `.part` 再 rename，失败不留半截文件；新增 `ipc-batch-count`、`save-data :batch-size`
| [0046](ADR-0046-rakudo-only.md) | 只支持标准 Rakudo，终止 rakupp 兼容线 | 0.121.1 | **Accepted** | Rakuish 是纯 Raku 模块，没有原生 ABI、也没有按实现分支的代码路径；「双后端验证」是 0.80 常驻引擎探针留下的习惯，Agent 线删除后已无驱动力。统一示例为 `! --tty raku` / `tty-exec('raku')`，注释只写结论不写实现对比；探针与旧 ADR 保留为历史证据但标注终结，不承诺在 rakupp 上可用

## 2. 决策演变链

| 阶段 | 输入 | 决策 | 结果 |
|---|---|---|---|
| 0.121.1 | 文档/注释/示例里到处拿 rakupp 当第二参照物，看起来像还要维护双后端 | 只支持标准 Rakudo（V-317 后续 / ADR-0046） | 单一运行时：示例统一 `raku`、注释去掉实现对比、README 明写只支持 Rakudo；探针与旧 ADR 标注历史归档；无行为变化 |
| 0.121.0 | 写 Arrow 只会整表 → 一个批 → 一份 Buf：大表峰值内存翻倍，且没有失败保护 | 多批 / 流式写（V-317 / ADR-0045） | 写入器拆成 `IpWriter.start/add-batch/finish`，sink 可为 `Buf` 或文件句柄：`write-ipc(:batch-size)` 多批、`write-ipc-stream(流, $path)` 边拉边写（内存只留一批，行流/表流都收）；schema 首批推断后固定，逐列核类型防 `"abc".Int == 0` 的静默脏数据；嵌套值、表流列不一致、空流明确报错；落盘先写 `.part` 再 rename，失败不留半截；5 万行单批 2.65 s vs 10 批 2.70 s（多批几乎零开销），50 万行流式 100 批 23.9 s / 14.9 MB；t/77 46 条 |
| 0.120.1 | 读侧全交给 `Arrow::IPC`：标量文件慢 4.6 倍，坏文件直接段错误 | Arrow 读侧分流（V-316 / ADR-0044） | 自研读入器先跑（4.2 s/50k），只在 UnsupportedType 时回退包；坏字节挡在会崩的解析器之外；新增 `X::Rakuish::Arrow::UnsupportedType`；t/74 +8 条 |
| 0.120.0 | Arrow 能读能写，但 `Table` 只能 `where`/`select`，做不了聚合、窗口、多源 join | Table 上跑 SQL（V-315 / ADR-0043） | Table → 临时 Arrow IPC → Duckula `read-arrow` → DuckDB SQL → `Frame.rows` + `dtypes` → Table；单表 `$t.sql()` / `sql($t, …)`、多表 `sql({a => $t1, …}, …)`（模块层 `Duck::query`）；只读守卫、时间/NULL 还原、嵌套转 JSON；不碰 Duckula 有问题的 `ipc-buf`；写侧对嵌套列改为明确报错 |
| 0.119.0 | Windows 上按 Ctrl-C 中断 `!` 命令会杀掉并重启引擎（4~5 秒、丢会话，重启窗口里输入错位） | Ctrl-C 只收外部命令（V-314 / ADR-0042） | 引擎 spawn 后发 `child` 帧（pid），前端把命令收进独立 Job Object；Ctrl-C 只 `TerminateJobObject` 命令子树，`exec` 正常返回、终帧 code=130，变量与 `Out[n]` 保留；子进程收不到 `CTRL_C_EVENT`（独立进程组），所以「等它自己死」不可行；3 秒兜底才杀引擎；`! --tty` 与 Raku 求值路径不变；真控制台三场景探针 |
| 0.118.3 | Arrow IPC 已被抽成独立包 `Arrow::IPC` 0.1.0（支持嵌套/字典），Rakuish 里那份成了重复实现 | 读侧依赖包、写侧保留自研（V-313 / ADR-0041） | `open-data` 的 `.arrow` 走 `decode-ipc` + 约 90 行 Table 适配：list/struct/map/字典立刻可用；时刻还原成 DateTime、时长按原单位、decimal 给 Rat，还原失败退回字符串并标 `str`；**压缩批读前拦截**（包会静默解成垃圾）；写侧仍 `write-ipc-file`（包的写侧要 Arrow C Data 视图，迁过去更贵）；META6 增依赖 `Arrow::IPC:ver<0.1.0+>`；t/74 34 条 |
| v2 → v3 | 两套语言、两套执行栈，7 个 P0 | ADR-0001 整体删双栈 | Raku 唯一命令语言 |
| 0.118.0 | `rakuish 文件 参数` 只跑顶层语句，`sub MAIN` 永远不被调用 | 脚本模式 MAIN 分派（V-311 / ADR-0040） | 把 EVAL 里的 `&MAIN` 显式交给 Rakudo 的 `RUN-MAIN`（尾巴追加在 EVAL 内部，`callframe(1).my` = 脚本顶层）；参数解析 / 强转 / multi / `--help` / `sub USAGE` / 退出码与 `raku 文件` 一致；`$*PROGRAM-NAME` 用绝对路径绕开 2026.11 的 USAGE 崩溃；脚本输出直通（`exit` 前的 say 不丢）；`source` 不上分派（用法错误会 exit 2 杀掉引擎）；t/72 42 条 |
| 0.117.0 | 引擎被杀后它起的命令与孙进程成孤儿（V-905） | Windows 子树回收（V-309 / ADR-0039） | `Rakuish::Sys::WinJob`：建 job + `KILL_ON_JOB_CLOSE` + `AssignProcessToJobObject`，三条杀引擎的路径统一走 `TerminateJobObject`；平铺 144 字节结构体（嵌套 CStruct 的 nativesizeof 算错会静默失效）；同时更正 ADR-0010 §3 的 Ctrl 事件结论并实测（CTRL_C 不可定向 / CTRL_BREAK 可定向，近 SIGQUIT）；resize 仍轮询；t/71 17 条（POSIX skip） |
| 0.116.0 | 二进制表格数据没法跟 pandas / polars 交换 | Arrow IPC 读写（V-308 / ADR-0038） | 纯 Raku 解 FlatBuffers（文件 + 流两种模式）；读 int/float/bool/utf8/binary/date/time/timestamp/decimal，写 int64/double/bool/utf8/timestamp[ms]；字典编码与压缩明确报错；`.arrow`/`.feather`/`.ipc` 接进 open-data/save-data，不走 `:allow-external`；t/70 68 条断言（夹具由 pyarrow 生成后提交） |
| 0.115.0 | 会话跑过什么只有人读的日志，没法重放也没法喂给别的工具 | 格记录与导出（V-307） | `!finish` 是唯一记账点（seq/index/input/ok/op/code/ms），`log-line` 补 rendered；`cells` 不带参数列记录、`--text` 导出可重放脚本（每格补 `;` + `no worries;`，`rakuish 文件` 与 `source 文件` 两种重放都验过）、`--json` 给 `rakuish-cells@1`；名字不叫 `export`（Shell 的 `export FOO=1` 已占，t/10 会红） |
| 0.114.0 | 想在会话里跑脚本并共享状态，`rakuish 文件` 却是一次性进程 | `source` 命令（V-306） | 逐行喂 `eval-line`（整份当一个 cell 会丢掉脚本里的 `sub` —— 纯声明持久化只在「一格恰好一条声明」时生效）；`@*ARGS` / `$*PROGRAM` 注入后还原；脚本内部的行不占 `Out[n]` / history；错误按 `文件:行` 且不中止；`sub MAIN` 在给参数时按位置参数调用；名字不用 `run`（Raku 自带 sub） |
| 0.113.0 | notebook 只能一问一答，前端不知道内核死活 | 服务端主动推送（V-305 / ADR-0037 §9） | 帧按字段分：带 `op` 是响应、带 `event` 是推送；`busy`/`idle` 包住 execute（idle 在响应后），`engine` 帧报崩溃/重启/快照恢复；请求 `id` 原样回显；空闲期死亡靠 250ms 看门狗线程；顺带修好 `Client.alive` 的 `=:=`（容器同一性）判据 |
| 0.112.0 | 说不清某类前端跑过什么 | 按 origin 分账（V-303 / ADR-0018） | `valid-origin` 约束 human/agent/notebook/script + `x-` 前缀，Request 构造即校验；`Audit.by-origin` / `origin-summary` 合并内存与 JSONL；Session `audit` 命令，Kernel 把共享账本注入；t/35 + t/40 + t/67 + t/37 |
| 0.111.0 | Jupyter 前端接不上 | Jupyter wrapper kernel（V-302 / ADR-0037 §8） | `tools/jupyter/` 用 ipykernel 基类接管 ZMQ/HMAC/心跳，Raku 侧仍是一行一 JSON；MIME 直接转发 `display.mime`（json 档需 json.loads），格号用会话口径；shutdown 走 control 通道，能力不虚报；t/66 24 条 + smoke.py 真内核冒烟 |
| 0.110.0 | 结果只能给文本 / markdown | 展示层 HTML 与 MIME 分档（V-301） | `Display::Bundle` 增加 `html`，`Table.to-html` + 统一转义；`to-mime` 一次给齐 `text/plain`·`text/markdown`·`text/html`·`application/json`，notebook 的 `display.mime` 用它；`to-hash(:mime)` 默认关，TTY 不付成本；PNG 不做文件（ADR-0037 §7） |
| 0.109.0 | 接 Jupyter 要改哪里 | Notebook 协议层（V-300 / ADR-0037） | `Rakuish::Kernel::Notebook` + `bin/rakuish-notebook`（一行一 JSON）；`Result.bundle` 承载 MIME 分档，只有请求 `display:true` 才算；Server/Client/Proxy 增加 `inspect`（复用 `名字?`）；新增 t/65 50 条断言，含真实子进程的 ready / 行协议冒烟 |
| 0.108.0 | 「现在有什么 / 刚才跑了什么」查不到 | 会话自省与重跑（V-299） | `who` / `whos` 直读 `%!state` / `@!decls`；`名字?` 接 `doc`（`$x?` 给类型+值摘要，`Box?` 靠重放声明取类型对象）；`rerun [n]` 走真实 `eval-line`，生成新 `Out[n]` 而自身不记历史；prelude 从「只重放 use」扩到「重放全部声明」，顺带修好本会话 class 的 `.<Tab>` |
| 0.107.0 | `.` 之后没有方法补全 | 方法名补全（V-298） | `method-context` 纯函数解析 `$obj.` / `@arr.` / `%h.` / `_.` / `Out[n].` / `Type::Name.`；Session 侧查 `%!state` / `@!out`，类型名用「已有 use 行 + 名字」EVAL 解析并按名缓存；候选来自 `^methods` + `^can` 补 `new` 等，链式调用不补 |
| 0.106.2 | `use` 之后带 `::` 的名字跨格失效 | `use` 补分号 + 跨格重放（V-297） | EVAL 在 Session 包里编译，`DB::DuckDB` 被当相对包名；Rakudo 里 `use X` 不带分号换行时同单元也认不到导入名。扫描阶段给顶层 `use` 补 `;`，旧快照重放时同样补；混合格的顶层 `use` 由 `!collect-uses` 收进 prelude |
| 0.106.1 | `-e` / 单行模式启动慢 | 入口预编译 + 按模式懒加载（V-296） | `bin/rakuish` 薄启动器 + `Rakuish::CLI` 预编译模块；`--version` 直读 META6；Kernel 构造走 `Rakuish::Kernel::Factory`；`-e '1+1'` 1.35s → 0.69s |
| 0.106.0 | 性能审计的一、二项 | 管道与 CSV 收口（V-295） | `where` 未定义列值告警只提示一次（用户 `warn` 透传）；已知行数不重扫、Hash 行免重复 coerce；CSV 无引号行走行级切分，20 万行错列名从 77s → 5s |
| 0.105.0 | 文件锁 with-lock | 劝告锁（V-294） | 锁独立 `.lock` 伴生文件（不锁数据文件，避免 rename 换 inode 失效）；Raku 内建 IO::Handle.lock 跨平台；异常自动解锁；`:shared`/`:non-blocking`（冲突抛 X::Rakuish::LockConflict，名字避开内建 Lock） |
| 0.104.0 | 中文编码别名 | `gbk`/`cp936` → `gb18030`（V-293） | Rakudo 内建 gb18030 被外部评测漏查；read/write/read-lines 加别名映射，shell `cat`/`read` 加 `--enc`；GBK 不再是「无解」，big5/shift-jis 仍须 `:bin` |
| 0.103.0 | `!` 的 PATH 命令补全 | 外部程序名入补全（V-292） | 首词补 PATH 可执行文件（Windows 去 .exe 后缀、按 V-288 口径判可执行），`! --tty` 第二词同样；PATH 扫描并行 + 按 PATH 缓存 + 入口后台预热 |
| 0.102.0 | 外部评测跟进 + `!` 补全 | 上限就地抬高 / 异常族归位 / shell 补全（V-290、V-291） | 1 MiB 默认值不变；`cat`/`read` 加 `--max-bytes=N`（K/M/G）、`write`/`append` 加单次 `:max-bytes`；二进制当文本读改抛 `X::Rakuish::Encoding` 并给 `:bin`/`:enc`/`read-lines` 三条出路；`!` 前缀走同一套 argv 补全（路径/选项，首词可为外部程序） |
| 0.101.4 | 真机反馈（`! --tty` + Ctrl-C） | tty 直通的信号归属（V-289） | 宿主 SIGINT handler 在 `in-request` 分支 SIGKILL 引擎，导致「引擎进程已退出 → 重启」+ 光标错位/回车无响应；新增 `tty-interactive` 状态（Ctrl-C 归前台子进程），引擎侧 tty-handler 加纵深 tap；探针加 `engine_survived` 并反证 |
| 0.101.3 | 外部评测（Windows 文件读写） | 跨平台可执行判定（V-288） | Windows 上 `IO::Path.x` 对存在文件也抛 `rindex ... got null`：`which` 崩且中止输入、`stat.executable` 恒假；改走扩展名白名单（Win）/ x 位（POSIX），`write/append/read` 帮助文案改成 Raku 调用形式 |
| 0.101.2 | 0.101.1 文档核对复检 | junction 结果契约补齐 `Result.display` | 同一 bug 的第三处出口（`display` 的标量分支用 `.defined`/`~~`，对 junction autothread 后在 `my Str` 处抛 Type check）；t/61 17→20 断言，SPEC V-287 同步 |
| 0.101.1 | 真机 + SPEC 审计 | junction 结果契约（V-287）+ 文档订正 | `Result.value` 改 `Mu`、渲染在调用点转字符串、`value-defined`；SPEC 头部版本与 V-122 的 `%STORE` 订正；ctrl-c 探针输入竞态、cjk winpty 误报（详见 AUDIT-2026-11-18） |
| 0.101.0 | ADR-0034 §4 后续清单 | 手感后续四项（ADR-0035） | 逐词接受 / 补全候选建议 / In·Out 引用补全 / 引擎侧名字精确判定；均走既有 RPC，不扩协议；鱼式模态仍推迟 |
| 0.100.0 | 补全 / 交互弱于 fish | 交互手感层（ADR-0034） | 灰字建议 / 候选菜单 / 错误态高亮 / 模糊回退 / Ctrl-R 循环检索一次落地；鱼式模态搜索仍为边界（需拥有输入循环） |
| 0.99.0 | 内置 tail 缺 -f | `tail -f` 跟随（ADR-0033） | 轮询循环放父进程（job 帧同构 tty-exec）；Ctrl-C 归属是「停跟随」不是「中断求值」 |
| 0.98.2 | 复核报告 P0/P1 修复集 | linger guard + 展示契约收口 + Windows NUL TTY 判定（ADR-0032） | 退出残留线程用看门狗消解（不绕开 `exit()`）；`Proxy.render` 只信 `rendered`；`$*OUT.t` 的 NUL 误判改 CSBI 探测 |
| 0.96.0 | 「只用 MoarVM 能否做作业控制」重开 ADR-0010 | B 档：`bg-exec`/`bg-jobs`/`fg`/`bg`（ADR-0031） | 纠正前提：ADR-0010 本就是 MoarVM 实测；障碍是 V-901 + 双进程架构，不是运行时。作业表落父进程，Ctrl-Z 不再卡死 REPL |
| 0.95.0 | 两条流的收尾 | `interleave` / `append`（ADR-0030） | 交替与首尾接：不合成行、不改列名，收拢而非配对 |
| 0.94.0 | 同一清单的优先级 3 之后 | `zip` / `join` / `tee`（ADR-0029） | 两条流的合并与落地：字典连接、按位对齐、边流边存 |
| 0.93.0 | 结构化管道的收尾 | `.exec` 的 stdin 流式化（ADR-0028） | 管道两端都真惰性：大流不吃内存，子进程提前走就不白算 |
| 0.92.0 | 同一清单的优先级 3 的前置 | 前端分页（ADR-0027） | `explore` 在交互式 REPL 里真的能分页；`-- more --` 不再只在进程内出现 |
| 0.91.0 | 同一清单的优先级 2 | 结构化管道 `Stream`（ADR-0026） | 文本↔记录↔子进程 stdin 打通；不加 shell 语法 |
| 0.90.0 | shell 差距清单 | `!` 流式 + 超时选项 + rc / prompt / `set -o`（ADR-0024 / 0025） | 长任务可见、会话可配置 |
| 0.80.4 | 判断 B 第三层适配归因 | `rakupp-diff.raku` + `rakupp-adapt.sh` + 报告 `PROBE-2026-11-16-rakupp-adaptation.md`；副本改两处即 27→30/42，七类归因，上限 36/42 | **结论待定**，仍未动主干 |
| 0.80.3 | 判断 B 第二层验证 | 6 个新探针 + 报告 `PROBE-2026-11-16-rakupp-integration.md`；34/34 模块、双引擎一格一致、全套件 27/42、并发 SIGSEGV | **结论待定**，仍未动主干 |
| 0.80.2 | 按《愿景溯源》§6 重开方向议题 | 两条最小探针实测（Sandbox 短路 / rakupp 常驻求值），报告 `PROBE-2026-11-15-persistent-engine.md` | **结论待定**，未动主干，未改 V-906 |
| 0.80.1 | 发布工程化 | 打 `v0.80.0` tag、`tools/ci.sh`、清残留、收敛文档真值 | 无新能力，不改任何对外语义 |
| 0.71–0.72 | 代码审计 4 高 / 11 中 / 11 工程项 | 逐条修，写 8 份 `AUDIT-FIXES` | 基本清零，TTY/PTY 层补齐 |
| 0.73–0.75 | TTY / 进程组 / 交互手感 | 前台交接、着色高亮、用户层命令 | 不碰 `EVAL` 作用域 |
| 0.76–0.79 | 三份自审（FEATURE-GAP / ARCH-REVIEW / PROPOSAL） | Kernel / Display / stream / cancel 陆续落地 | +8k 行，ADR 8 → 17 |
| 0.79.2–0.80 | 跨平台 OS 隔离四轮讨论 | V-607 结构性闸门 + V-194…196 统一审计 | `execute` 删除、VM 隔离整体搁置 |
| 0.83–0.85 | 崩溃隔离 | 引擎子进程 + 会话快照 + 求值中 Ctrl-C（ADR-0021 / 0022 / 0023） | 交互式 REPL 开始有「重启后继续」语义 |

## 3. 一次「品类变更」的补登记（0.80.1）

ADR-0017 的 `stream` / `cancel` 在 0.79.0 落地时，作用对象是 `exec`
（`STREAM-OPS = <exec>`）。0.79.2 的 V-607 把 `exec` / `pty_exec`
**默认**关成 403，于是：

> **默认配置下 `stream` 不发任何帧、`cancel` 恒为 409**，
> 只有显式给 `--allow-code-exec --allow-exec` 的不安全 profile 才用得上。

这不是缺陷，也没有回退 0.79.0 的实现；但它改变了这两项能力的定位
（从「默认能力」变成「可选 profile 能力」），而此前没有任何文档标记这件事。
这里补登记，`HANDOFF` 缺口表与 `MANUAL` 同步标注。
**若将来要恢复默认流式，须先回答 V-607 是否放宽，并另开 ADR。**

## 4. 改之前要新 ADR 的清单

- 不实现 bash / POSIX、`%magic`、auto-shell、第二套脚本语言（ADR-0001 / V-901/902）。
- 不让 Agent 接 shell 字符串或 `eval` op（V-503 / V-607 / ADR-0018）。
- 不做持久求值器 / 常驻编译单元（V-906 / ADR-0005 §4）。
- 不承诺杀孙进程、不做完整 job control（V-905 / ADR-0010 §6）。
- OS 级隔离若将来要跑不可信源码，须独立立项 + 威胁模型，不从审计这条路上长出来。
- `html` 富输出、SQL AST 补全、post-mortem 调试等 P2/P3 项：先改规格再开 ADR，
  **不把「不做」伪装成「未排期」**。

## 5. 三份自审文档的定位（0.80.1 校准）

| 文档 | 基线 | 现在的定位 |
|---|---|---|
| [`FEATURE-GAP-2026-11-13.md`](FEATURE-GAP-2026-11-13.md) | 0.74.0 | 历史快照。四者横向对比与 C 类护栏仍有效；A1/A2/A3 已在 0.75 订正，B 类多项已在 0.75/0.77/0.78 落地 |
| [`ARCH-REVIEW-2026-11-13.md`](ARCH-REVIEW-2026-11-13.md) | 0.75.0 开发中 | 历史快照。三处技术债里「命令名 9 处登记」与「会话级命令旁路」已由 0.77 收敛；L5 单一覆盖点仍在 |
| [`PROPOSAL-HUMAN-AGENT-KERNEL.md`](PROPOSAL-HUMAN-AGENT-KERNEL.md) | 0.75.0 开发中 | **部分已实施**：0.76 Kernel、0.78 Display 已落地；「Agent 也走 Kernel」仍未做，且 V-607 后前提已变，不应照原提案继续推 |

## 6. §6 方向议题（0.80.2 重开 → **0.81.0 终结**；rakupp 线 0.121.1 终结）

> **0.121.1 补记**：本节所有 rakupp 相关的探针、脚本与报告只作**历史证据**保留。
> 项目已明确只支持标准 Rakudo（MoarVM），不再做双后端验证，也不在 rakupp 上
> 承诺可用性 —— 见 [ADR-0046](ADR-0046-rakudo-only.md)。

《Rakuish 愿景溯源》§6 的两个判断——**A 权限交给系统 / 撤应用层安全壳**、
**B 拿回 rakupp 常驻引擎 / 恢复跨格连续状态**——已通过 §6.6 的两条最小探针
拿到实测数据，见 [`PROBE-2026-11-15-persistent-engine.md`](PROBE-2026-11-15-persistent-engine.md)。

第二层验证（0.80.3）补充：**34/34 模块可加载、同一格在 MoarVM 与 rakupp 上逐字节一致**，
但全套件只有 **27/42** 通过；**并发 `rk_eval` 稳定 SIGSEGV**。

第三层归因（0.80.4）修正了第二层的两个粗略判断，并把成本拆成可估算的七类：
副本里只改 `Sys::Proc.spawn`（tap→Channel）与 `Sys.%.env`（TWEAK 复制）两处，
即 **27 → 30/42**、ok 行 1856 → 1980。其中 **A 通道空 / B 环境共享 / C spawn 失败 /
F 报错形态四类可绕过**；**D `:pty` 未实现 / E `CPointer` repr out 参数 /
G async accept 收尾三类受引擎限制**。理论上限 **36/42**，剩下 6 个文件恰好是
PTY、中断与 socket 收尾 —— 一个 shell / REPL 工作台最核心的宿主能力。

要点：**A 在本机 REPL 上基本已是事实**（root 已是 `/`、Policy 是 local、
本机三入口不构造 Sandbox）；**B 的技术前提成立**（跨 eval 的 `my` 存活已由
C ABI 与 Raku NativeCall 双路径确证），但 V-906 未改、34 个模块能否在 rakupp
上加载未测，且「一进程一 live 解释器」与 Agent 每连接并发模型不能共存。

### 6.1 结论（0.81.0）

三层探针做完之后，用户的判断是：**放弃 Agent 线，做全权限的本地 shell**
（[ADR-0019](ADR-0019-local-full-privilege-shell.md)）。理由是探针自己给出来的：

> 判断 B 的失败不在「Raku 语义兼容」，而在 **rakupp 缺的恰好是这个产品最核心的
> 两项宿主能力**（`:pty`、可靠 socket 收尾）。而这两项之所以成为问题，
> 只是因为在给 Agent 找一个「安全执行环境」。

于是两个判断一起落地：

| 判断 | 结论 |
|---|---|
| A（权限交给系统 / 撤应用层安全壳） | **做到极致**：不只是撤 Sandbox，连 Agent 线一起删；本机全权限（V-197…V-199） |
| B（拿回 rakupp 常驻引擎） | **不做了**：驱动力（Agent 并发）消失；V-906 标为「不做且已终结」 |

**因此本索引中凡与 Agent 相关的状态都已更新**：ADR-0002 撤销、ADR-0017 撤销、
ADR-0018 部分撤销（审计保留）、ADR-0013 的 Agent 半边作废。
探针脚本与报告保留在 `tools/probe/` 与 `docs/PROBE-2026-11-1*.md`，作为
「为什么不做」的证据，不再作为「待办提案」。
