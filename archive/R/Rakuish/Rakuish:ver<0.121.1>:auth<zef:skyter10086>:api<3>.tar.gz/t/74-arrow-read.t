use Test;
use lib 't/lib';
use Rakuish::Sys;
use Rakuish::Data;
use Rakuish::Data::Arrow;
use Rakuish::Data::Table;
use Rakuish::Result;

# ══════════════════════════════════════════════════════════════════
# 74-arrow-read.t —— 读侧走 Arrow::IPC（0.118.3 / V-313）
# ══════════════════════════════════════════════════════════════════
# 0.118.2 之前 open-data 的 .arrow 走自研 Rakuish::Data::Arrow，
# 只认 int/float/bool/utf8/date/time/timestamp/decimal/duration，
# 明确拒绝 list / struct / map / 字典。
# 0.118.3 把读侧整个交给 Arrow::IPC；0.120.1 改成**分流**（V-316）：
#   · 标量文件先走自研读入器（快约 4 倍，且有边界检查）；
#   · 只有「文件合法、但类型没实现」（嵌套 / 字典）才回退 Arrow::IPC；
#   · **坏文件绝不回退**——`decode-ipc` 对越界元数据会段错误（rc=139），
#     `try` 接不住，所以分流只认 X::Rakuish::Arrow::UnsupportedType；
#   · 语义两条路径一致：时刻 DateTime、时长秒数、decimal Rat；
#   · **压缩批先拦**：Arrow::IPC 0.1.0 不解压也不报错，会解出垃圾。
# 写侧不动，仍是 Rakuish::Data::Arrow::write-ipc-file。

plan 42;

my $sys = Rakuish::Sys.new(:root($*CWD));

sub op(Str $name --> Rakuish::Data::Table) {
    open-data($sys, "t/fixtures/arrow/$name");
}

# ── 1. 基本文件（文件格式）────────────────────────────────────────
my $b = op('basic.arrow');
is $b.columns, ('n', 'x', 's', 'b'), '列名与顺序保留';
is $b.rows.elems, 3, '行数正确';
is $b.types<n>, 'int', 'int64 → int';
is $b.rows[0]<n>, 1, '第一行 int 值';
nok $b.rows[2]<s>.defined, 'null 仍是未定义，不是 ""';

# ── 2. 流格式与文件格式同一条路 ───────────────────────────────────
my $st = op('stream.arrow');
is $st.rows.elems, 3, '流格式读出行数';
is $st.rows[1]<s>, 'b', '流格式读出的值一致';

# ── 3. 各类标量：宽度 / 日期 / 大字符串 / 小数 ────────────────────
my $k = op('kinds.arrow');
is $k.types<ts>, 'datetime', 'timestamp 列标成 datetime';
isa-ok $k.rows[0]<ts>, DateTime, 'timestamp 还原成 DateTime';
is $k.types<dec>, 'num', 'decimal 列标成 num';
is $k.rows[0]<dec>, 1.25, 'decimal 还原成数值';
is $k.rows[2]<u8>, 255, 'uint8 上界';

# ── 4. 时间 / 时长 / 带时区时间 / 日期 ───────────────────────────
my $tp = op('temporal.arrow');
is $tp.rows[0]<t32>, 3723, 'time32 换成当天秒数（旧语义）';
is $tp.rows[0]<dur>, 1500, 'duration 保留原单位数值（与旧读法一致）';
is $tp.rows[0]<tsz>.hour, 12, '带时区 timestamp 的小时正确';
is $tp.rows[0]<date>.Date.Str, '2020-01-01', 'date32 还原成 DateTime';

# ── 5. 嵌套与字典：这是换读侧换来的能力 ──────────────────────────
my $n = op('nested.arrow');
is $n.types<tags>, 'list', 'list 列标成 list';
is $n.rows[0]<tags>.elems, 2, 'list 值是真数组';
is $n.rows[0]<person><name>, 'ann', 'struct 值转成 Hash（可继续取字段）';
is $n.rows[0]<counts><y>, 2, 'map 值转成 Hash';
is $n.rows[1]<kind>, 'green', '字典编码列解成原值';
nok $n.rows[2]<person>.defined, '嵌套列的 null 仍是未定义';

# ── 6. 空表：有 schema、零行 ─────────────────────────────────────
my $e = op('empty.arrow');
is $e.columns, ('a', 'b'), '空表保留 schema 的列名';
is $e.rows.elems, 0, '空表 0 行';
is $e.types<b>, 'str', '空表仍按 format 标类型';

# ── 7. 压缩批必须被拦住（不静默解成垃圾）────────────────────────
# 注意 `try` 在失败时返回 Nil、异常落在 `$!`，别写成 `my $e = try {...}`
# 然后断言 `$e.defined` —— 那条永远假。
my $cerr = (try { op('compressed.arrow') } // $!);
ok $cerr ~~ Exception, '压缩的 Arrow 被拒绝';
like $cerr.message, /'BodyCompression'/, '错误里点名 BodyCompression';

# ── 8. 检测函数本身 ──────────────────────────────────────────────
nok ipc-compressed-file($*CWD.add('t/fixtures/arrow/basic.arrow').Str),
    '未压缩文件判定为 False';
ok ipc-compressed-file($*CWD.add('t/fixtures/arrow/compressed.arrow').Str),
    '压缩文件判定为 True';

# ── 9. 写侧不变：写出去再读回来 ─────────────────────────────────
my $dir = $*CWD.IO.add("tmp/arrow-read-{$*PID}");
$dir.mkdir;
LEAVE { try { $dir.dir>>.unlink; $dir.rmdir } }
my Str $rt-path = $dir.Str ~ '/rt.arrow';
save-data($sys, $rt-path, $b);
ok $rt-path.IO.e, 'save-data 仍写出 .arrow';
my $rt = open-data($sys, $rt-path);
is $rt.rows.elems, 3, '写读往返行数一致';
is $rt.types<n>, 'int', '往返后 int 仍是 int';
is $rt.rows[0]<n>, 1, '往返后值一致';

# ── 10. --raw 仍然是明确拒绝 ─────────────────────────────────────
throws-like { open-data($sys, $rt-path, :raw) },
    X::Rakuish::Unsupported,
    message => /'二进制'/,
    '--raw 对二进制文件明确拒绝';

# ── 11. 读侧分流与坏文件护栏（0.120.1 / V-316）────────────────────
throws-like { Rakuish::Data::Arrow::read-ipc-file('t/fixtures/arrow/nested.arrow') },
    X::Rakuish::Arrow::UnsupportedType,
    '自研读入器把嵌套列归为「类型未实现」（可安全回退）';

my $nested-again = op('nested.arrow');
is $nested-again.types<tags>, 'list', 'open-data 仍读得出嵌套（回退 Arrow::IPC）';

# 必须放在会话 root 内（$sys 是 :root($*CWD)），否则先被 Sys.resolve 拦下，
# 测不到 Arrow 解析器本身。
my $bad-dir = $*CWD.add("tmp/rakuish-t74-bad-{$*PID}");
$bad-dir.mkdir unless $bad-dir.e;
LEAVE { try { $bad-dir.dir>>.unlink; $bad-dir.rmdir } }
my Str $bad-path = $bad-dir.Str ~ '/trunc.arrow';
my Buf $full = 't/fixtures/arrow/basic.arrow'.IO.slurp(:bin);
# Buf 的 [range] 会给 List，spurt 会把它写成字符串；用 subbuf 切字节。
spurt($bad-path, $full.subbuf(0, $full.elems div 2));

my $bad-err;
{
    CATCH { default { $bad-err = $_ } }
    open-data($sys, $bad-path);
}
ok $bad-err.defined, '截断文件报错（而不是把进程带崩）';
isa-ok $bad-err, X::Rakuish::Arrow, '错误在 Arrow 异常族里';
nok $bad-err ~~ X::Rakuish::Arrow::UnsupportedType,
    '坏文件不会被标成「类型未实现」（否则会回退给会段错误的解析器）';
like $bad-err.message, /'越界' | '提前结束' | '缺少'/, '错误点明是结构问题';

# 文本文件改名 .arrow：以前会冒 X::Hash::Store::OddNumber（try 之外抛的），
# 现在 ipc-format 里先判类型，给的是「不是 Arrow IPC 数据」。
my Str $text-path = $bad-dir.Str ~ '/text.arrow';
spurt($text-path, "hello\nthis is not arrow\n");
my $text-err;
{
    CATCH { default { $text-err = $_ } }
    open-data($sys, $text-path);
}
isa-ok $text-err, X::Rakuish::Arrow, '文本文件改名 .arrow：错误在 Arrow 族里';
like $text-err.message, /'不是 Arrow IPC'/, '明确说不是 Arrow 数据';
