#!/usr/bin/env raku
use lib 'lib';
use Test;
use JSON::Fast;
use Rakuish::Kernel;
use Rakuish::Kernel::Notebook;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;
use Rakuish::Audit;

# ══════════════════════════════════════════════════════════════════
# 65-notebook-frontend.t —— notebook 协议适配层（0.109.0 / V-300）
# ══════════════════════════════════════════════════════════════════
# 这一层是「Jupyter（或任何前端）↔ Kernel」之间的纯映射：请求 Hash 进，
# 响应 Hash 出。传输（ZMQ）不在这里，所以不带任何 socket 依赖就能测。
#
# 断言分三组：
#   ① kernel_info / execute：语义走 Kernel，`display` 与 `out` 分工明确；
#   ② complete / is_complete / inspect：Jupyter 的三个查询消息；
#   ③ 真实的 `bin/rakuish-notebook` 子进程：ready 帧 + 行协议 + shutdown。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';

my $engine = Rakuish::Eval::Client.new(:lib($*CWD.add('lib')));
$engine.start;
my $sess = Rakuish::Eval::Proxy.new(:client($engine));
$sess.set-display(True);
my $kernel = Kernel.new(
    :session($sess),
    :audit(Rakuish::Audit.new(:default-origin<notebook>, :enabled(False))),
);
my $front = Rakuish::Kernel::Notebook::Frontend.new(:kernel($kernel));
LEAVE { try { $engine.shutdown } }

# ── 1. kernel_info ─────────────────────────────────────────────────
my %ki = $front.handle(%(op => 'kernel_info'));
is %ki<op>, 'kernel_info', 'op 原样回显';
ok %ki<ok>, 'kernel_info 成功';
is %ki<protocol_version>, '5.3', 'Jupyter 协议版本 5.3';
is %ki<implementation>, 'rakuish', '实现名 rakuish';
is %ki<language_info><name>, 'raku', '语言名 raku';
ok (%ki<implementation_version> // '').chars, '有实现版本';
ok (%ki<banner> // '').contains('Rakuish'), 'banner 带名字';

# ── 2. execute：值 / stdout / 错误 ──────────────────────────────────
my %e1 = $front.handle(%(op => 'execute', code => '1+1'));
ok %e1<ok>, '1+1 成功';
is %e1<code>, 0, '成功格 code=0';
is %e1<execution_count>, 1, 'execution_count 用会话格号';
is %e1<out>, '', '纯表达式没有 stdout';
is %e1<display><content>, '2', 'display 给出值文本';
nok %e1<display><content>.contains('Out['), 'display 不带 Out[n] 标签';
ok %e1<display><formats>.list.grep(* eq 'text').elems, 'display 至少有 text';

my %e2 = $front.handle(%(op => 'execute', code => 'say 7'));
ok %e2<ok>, 'say 成功';
is %e2<out>, "7\n", 'say 的内容进 out（不是 display）';

my %e3 = $front.handle(%(op => 'execute', code => 'my $x = 42'));
ok %e3<ok>, '声明格成功';
my %e4 = $front.handle(%(op => 'execute', code => '$x * 2'));
is %e4<display><content>, '84', '跨格变量在 notebook 路径上也可见';
is %e4<execution_count>, 4, '格号连续（1+1 / say / my / 表达式 = 4）';

my %ee = $front.handle(%(op => 'execute', code => 'die "boom"'));
nok %ee<ok>, '错误格 ok=false';
is %ee<code>, 1, '错误格 code=1';
like %ee<err>, /boom/, 'err 带异常消息';
is %ee<display><meta><kind>, 'error', 'display 标明这是错误';

# 夹具必须是**真正的可执行文件**。`!` 是 argv-only 的外部执行，不做 shell
# 解释；`echo` 在 cmd / PowerShell 里是内置命令，没有同名 .exe（只有 Git
# Bash 的 usr/bin 才带 echo.exe），拿它当夹具会在没有 Git 的 PATH 上假红。
# 路径用单引号包住：split 里双引号把 `\` 当转义，Windows 路径会被吃掉。
my Str $bang-code = q{! '} ~ $*EXECUTABLE.Str ~ q{' -e 'say 42'};
my %es = $front.handle(%(op => 'execute', code => $bang-code));
ok %es<ok>, '`!` 外部命令在 notebook 里也能跑';
like %es<out>, /42/, '命令输出进 out';

# 反面：名字不是可执行文件时必须明确失败（127 + 带命令名的 err），
# 不能出现 ok=true / out 空串 这种「看起来跑过了」的结果。0.117.1 的旧夹具
# `! echo hi` 在缺 Git `usr/bin` 的 PATH 上走的就是这条；把口径锁住。
my %ex = $front.handle(%(op => 'execute', code => '! rakuish-no-such-cmd-9f3a'));
nok %ex<ok>, '起不来的可执行文件让格子失败';
is %ex<code>, 127, '外部命令起不来返回 127';
ok %ex<err>.contains('rakuish-no-such-cmd-9f3a'), 'err 带上命令名';

# 空码：合法且不占格号
my Int $before = $sess.index;
my %blank = $front.handle(%(op => 'execute', code => "  \n"));
ok %blank<ok>, '空码不报错';
is %blank<execution_count>, $before, '空码不推进格号';

# silent 原样回显（给前端决定要不要展示）
my %esil = $front.handle(%(op => 'execute', code => '1', silent => True));
ok %esil<silent>, 'silent 标记回显';

# 0.110.0 / V-301：MIME 分档 —— Jupyter 的 execute_result 一次拿全，
# 前端按自己会渲染的类型挑，而不是让内核猜一个。
my %m1 = %e1<display><mime>.Hash;
ok %m1.elems > 0, 'display 带 mime 分档';
is %m1{'text/plain'}, '2', 'text/plain 是值文本';
ok %m1{'text/html'}.contains('<pre'), '标量的 text/html 是 pre 块';
nok %m1{'text/plain'}.contains('Out['), 'text/plain 不带 Out[n]';

my %et = $front.handle(%(op => 'execute',
    code => 'use Rakuish::Data::Table; Rakuish::Data::Table.from-rows([%(name=><a>,n=>1),%(name=><b>,n=>2)])'));
ok %et<ok>, '表格格执行成功';
ok %et<display><formats>.list.grep(* eq 'html').elems, 'formats 含 html';
my %mt = %et<display><mime>.Hash;
ok %mt{'text/html'}.contains('<table'), '表格给真 table 标签';
ok %mt{'text/html'}.contains('</td>'), '单元格也渲染出来';
ok %mt{'application/json'}.starts-with('['), '同时给 application/json';
ok %mt{'text/markdown'}.contains('|'), '同时给 text/markdown';

# ── 3. complete：整行替换口径 ──────────────────────────────────────
my %cp = $front.handle(%(op => 'complete', code => '$x.ab', cursor_pos => 5));
ok %cp<ok>, 'complete 成功';
is %cp<cursor_start>, 0, 'cursor_start 固定 0（候选是整行）';
is %cp<cursor_end>, 5, 'cursor_end 是光标位置';
ok %cp<matches>.list.grep(* eq '$x.abs').elems, '方法补全候选';

# ── 4. is_complete ─────────────────────────────────────────────────
is $front.handle(%(op => 'is_complete', code => 'for 1..3 {') )<status>,
   'incomplete', '未闭合的块判 incomplete';
is $front.handle(%(op => 'is_complete', code => '1+1') )<status>,
   'complete', '完整表达式判 complete';

# ── 5. inspect（Shift+Tab）─────────────────────────────────────────
my %i1 = $front.handle(%(op => 'inspect', code => 'Int', cursor_pos => 3));
ok %i1<found>, '内置类型能找到';
like %i1<text>, /Int/, '文本里带类型名';

my %i2 = $front.handle(%(op => 'inspect', code => '$x', cursor_pos => 2));
ok %i2<found>, '本会话变量能找到';
like %i2<text>, /42/, '文本里带值摘要';

my %i3 = $front.handle(%(op => 'inspect', code => '$nope', cursor_pos => 5));
nok %i3<found>, '不存在的变量 found=false';

# ── 6. 未知 op 不炸 ────────────────────────────────────────────────
my %bad = $front.handle(%(op => 'wat'));
nok %bad<ok>, '未知 op 返回失败';
ok %bad<error>.contains('未知 op'), '错误里说清楚是未知 op';

# ── 6b. id 原样回显（0.113.0 / V-305）───────────────────────────────
# 一旦协议里会插进推送帧，前端就得靠 id 认领响应，不能只靠「下一行」。
my %wid = $front.handle(%(op => 'execute', code => '1', id => 'cell-9'));
is %wid<id>, 'cell-9', '请求带 id → 响应回显 id';
is %wid<op>, 'execute', 'id 不影响 op 回显';
my %noid = $front.handle(%(op => 'execute', code => '1'));
nok %noid<id>:exists, '不带 id 的请求不凭空造一个';
is $front.handle(%(op => 'kernel_info', id => 3))<id>, 3, 'id 对非 execute 的 op 也回显';

# ── 7. 真实子进程：ready 帧 + 行协议 + 推送帧 ───────────────────────
# 帧是**流式**的（0.113 起还会中间插推送），所以不能「写完两行就关 stdin」
# 再一次性读：`Proc::Async.say/print` 是异步写，紧跟着 close-stdin 有可能
# 把还没落盘的请求丢掉（WSL 上实测偶发只剩 ready 一帧）。改成「写 → 等帧」。
sub wait-for(@frames, &pred, Numeric $timeout = 30 --> Bool) {
    my $t0 = now;
    while (now - $t0) < $timeout {
        return True if @frames.first(&pred);
        sleep 0.1;
    }
    False;
}

my $proc = Proc::Async.new($*EXECUTABLE.Str, '-Ilib', 'bin/rakuish-notebook', :w, :r);
my @frames;
my $lines-done = Promise.new;
# tap 必须在 start 之前：Proc::Async 会拒绝「先跑再挂」。
$proc.stdout.lines.tap(-> $l { @frames.push($l) }, done => { $lines-done.keep });
my $p = $proc.start;
ok wait-for(@frames, *.contains('"event":"ready"')), 'boot：ready 帧到达';
await $proc.print(to-json(%(op => 'execute', code => '40 + 2', id => 'c7'), :!pretty) ~ "\n");
ok wait-for(@frames, *.contains('"event":"idle"')), 'execute：busy → 响应 → idle 全部到达';
await $proc.print(to-json(%(op => 'shutdown'), :!pretty) ~ "\n");
ok wait-for(@frames, *.contains('"op":"shutdown"')), 'shutdown：收到响应';
$proc.close-stdin;
try { await $lines-done }
try { await $p }

my @f = @frames.map({ (try { from-json($_) }) }).grep(*.defined).map(*.Hash);
ok @f.elems >= 5, "子进程输出 ready + busy + 响应 + idle + shutdown（{@f.elems} 帧）";

my %ready = @f[0];
is %ready<event>, 'ready', '第一帧是 ready';
is %ready<language>, 'raku', 'ready 带 language';
ok %ready<version>:exists, 'ready 带版本';
ok (%ready<engine_pid> // 0) > 0, 'ready 带引擎 pid';

# 0.113.0：execute 前后各一帧推送，顺序是 busy → 响应 → idle。
is @f[1]<event>, 'busy', '执行前先推 busy';
is @f[1]<op>, 'execute', 'busy 帧带 op';
is @f[1]<id>, 'c7', 'busy 帧带 id（能认领回请求）';

# 响应带 `op` 且**没有** `event`；busy/idle 两个推送帧也带 `op`，别捞错。
my &is-reply = -> $h { (($h<op> // '') eq 'execute') && !($h<event>:exists) };
my %rep = @f.grep(&is-reply)[0];
ok %rep<ok>, '子进程执行 40 + 2 成功';
is %rep<display><content>, '42', 'display 值正确';
is %rep<execution_count>, 1, '子进程会话格号从 1 开始';
is %rep<id>, 'c7', '响应回显 id';

my $idle-idx = @f.first({ (.<event> // '') eq 'idle' }, :k);
ok $idle-idx.defined, '执行后推 idle';
if $idle-idx.defined {
    my %idle = @f[$idle-idx];
    is %idle<op>, 'execute', 'idle 帧带 op';
    is %idle<id>, 'c7', 'idle 帧带 id';
    ok %idle<ms> ~~ Int, 'idle 帧带毫秒耗时';
    is @f.first(&is-reply, :k) < $idle-idx, True,
       'idle 在响应之后（前端据此解锁输入）';
}

my %bye = @f.first({ (.<op> // '') eq 'shutdown' }) // %();
is %bye<op>, 'shutdown', '最后一帧是 shutdown';

# ── 8. 空闲期死亡：服务端主动推送（0.113.0 / V-305）─────────────────
# 主循环阻塞在读 stdin 上，引擎死在没有请求的时刻，前端**不该**等到
# 下一条输入才发现。看门狗每 250ms 读一次 alive，杀掉引擎 pid 就能验证。
sub kill-pid(Int $pid --> Bool) {
    my @cmd = $*DISTRO.is-win
        ?? ('taskkill', '/F', '/PID', ~$pid)
        !! ('kill', '-9', ~$pid);
    my $ok = try { run(|@cmd, :out, :err).exitcode == 0 } // False;
    so $ok;
}

my @f2;
my $proc2 = Proc::Async.new($*EXECUTABLE.Str, '-Ilib', 'bin/rakuish-notebook', :w, :r);
$proc2.stdout.lines.tap(-> $l { @f2.push($l) });
my $p2 = $proc2.start;
ok wait-for(@f2, *.contains('"event":"ready"')), '第二个桥发出 ready';
my Int $epid = ((try { from-json(@f2[0])<engine_pid> }) // 0).Int;
ok $epid > 0, 'ready 帧里的引擎 pid 可用';

if kill-pid($epid) {
    ok wait-for(@f2, *.contains('"kind":"dead"')), '空闲期死亡推送 engine/dead';
    my %dead = (try { from-json(@f2.first(*.contains('"kind":"dead"'))) }) // %();
    is %dead<event>, 'engine', '死亡帧的 event 是 engine';
    nok %dead<alive>, '死亡帧 alive=false';
    ok (%dead<reason> // '').chars > 0, '死亡帧带原因';

    # 下一条输入自动重启，并推一帧 engine/restart。
    $proc2.say(to-json(%(op => 'execute', code => '6 * 7', id => 'r1'), :!pretty));
    ok wait-for(@f2, *.contains('"kind":"restart"')), '重启后推送 engine/restart';
    my %rs = (try { from-json(@f2.first(*.contains('"kind":"restart"'))) }) // %();
    is %rs<event>, 'engine', '重启帧的 event 是 engine';
    ok %rs<ok>, '重启帧 ok=true';
    is %rs<restarts>, 1, '重启帧带累计重启次数';
    is %rs<reason>, '引擎未启动或已退出', '死亡原因来自客户端的存活判据';
    is %rs<restored>.Hash.elems, 0, 'RAKUISH_NO_SNAPSHOT=1 时 restored 为空（不假装恢复）';

    # busy 帧也带同一个 id，所以要挑**响应**（有 op、没有 event）。
    # 重启事件先到、响应后到（不保证同一批），得再等一次。
    # 注意别在 `->` 块里写 `return`：那是 Block 不是 Routine（顶层会报
    # 「Attempt to return outside of any Routine」），所以写成单表达式。
    my &reply-of = -> $raw, Str $id {
        my $h = try { from-json($raw) };
        so $h.defined
            && $h ~~ Hash
            && !($h<event>:exists)          # busy 也带 op=execute，跳过推送帧
            && (($h<id> // '') eq $id)
            && (($h<op> // '') eq 'execute');
    }
    ok wait-for(@f2, -> $raw { reply-of($raw, 'r1') }), '重启后那一格的响应回来了';
    my %failed = (try {
        from-json(@f2.first(-> $raw { reply-of($raw, 'r1') }))
    }) // %();
    is %failed<id>, 'r1', '重启后那一格的响应仍然对得上 id';
    nok %failed<ok>, '那一格本身失败（引擎当时是死的）';
    like %failed<err>, /引擎/, '失败原因说清楚是引擎问题';
}
else {
    skip '无法杀掉引擎 pid（平台限制），跳过空闲期死亡与重启推送', 11;
}

$proc2.say(to-json(%(op => 'shutdown'), :!pretty));
$proc2.close-stdin;
try { await $p2 };

# ── 9. Proxy 把引擎生死交给订阅者（0.113.0 / V-305）────────────────
# 这一组用进程内的 Client：Proc::Async 是我们自己起的，kill 一定生效，
# 于是「事件载荷长什么样」可以确定性断言（上一组验的是异步送达）。
my @evs;
$sess.on-engine-event = -> %ev { @evs.push(%ev) };
$engine.proc.kill(SIGKILL);
sleep 0.3;
my $dead-r = $sess.eval-line('1+1');
nok $dead-r.ok, '引擎被杀后那一格失败';
is $dead-r.op, 'engine-restart', '失败归因为引擎重启，不是普通错误';
is @evs.elems, 1, '订阅者收到且只收到一次事件';
if @evs.elems {
    my %ev = @evs[0];
    is %ev<kind>, 'restart', '事件 kind=restart';
    ok %ev<ok>, '事件 ok=true（重启成功）';
    is %ev<restarts>, 1, '事件带累计重启次数';
    ok %ev<index> ~~ Int, '事件带重启后的格号';
    is %ev<restored>.Hash.elems, 0, '无快照时 restored 为空';
    nok %ev<rc>.chars, '没有启动文件时 rc 为空串';
    nok %ev<restored>.Hash<event>:exists,
       'restored 里不再夹带协议的 event 字段（否则前端会误分类）';
}

# 回调抛异常不能把「已重启」改写成失败。
$sess.on-engine-event = -> %ev { die "订阅者自己的 bug" };
$engine.proc.kill(SIGKILL);
sleep 0.3;
my $again = $sess.eval-line('2+2');
is $again.op, 'engine-restart', '订阅者炸了也不影响重启结果';
ok $sess.alive, '重启后会话仍然活着';

# ── 10. 适配层收尾 ─────────────────────────────────────────────────
ok $front.handle(%(op => 'shutdown'))<ok>, 'Frontend 的 shutdown 幂等';

done-testing;
