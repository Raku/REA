use Test;

my $cwd   = $*CWD;
my @lines = 'META6.json'.IO.lines;

# lib 下所有模块文件（递归，相对路径）
#
# ⚠ 路径分隔符必须归一成 `/`：META6 provides 里登记的是**正斜杠**（规范写法，
#   zef 就是按它找文件），而 Windows 的 `.relative.Str` 给的是反斜杠
#   ⇒ 不归一会把 21 个模块全部误报成「未登记」。归一后两平台断言同一件事。
sub meta-path($p --> Str) {
    $p.Str.subst('\\', '/', :g)
}
my @files;
sub walk(IO::Path:D $d) {
    for $d.dir {
        when .d     { walk($_) }
        when .f     { @files.push(meta-path(.relative($cwd))) if .extension eq 'rakumod' }
    }
}
walk($cwd.add('lib'));
@files = @files.sort;

# META6 provides 里登记的路径
my @parts  = @lines.map({ .split('"')[3] });
my @listed = @parts.grep({ .defined && .ends-with('.rakumod') });
@listed = @listed.sort;

is @files.elems, @listed.elems,
    "META6 provides 条目数({@listed.elems}) 应等于 lib 下模块文件数({@files.elems})";

my %have = @listed.Set;
my @missing = @files.grep({ !%have{$_} });
is @missing.join(','), '',
    "以下模块未登记进 META6 provides（zef 安装后会缺文件）: {@missing.join(', ')}";

# 0.106.1：入口逻辑移到 lib/Rakuish/CLI.rakumod（bin 只做 require）。
# 版本回退常量跟着走；两处版本必须与 META6.json 一致，防止安装后 --version 漂移。
my $metav = ~@lines.grep({ .contains('"version"') })[0].match(/ '"version"' \s* ':' \s* '"' (<-["]>+) '"' /)[0];
my $cliv  = ~'lib/Rakuish/CLI.rakumod'.IO.slurp.match(/ 'FALLBACK_VERSION' \s* '=' \s* "'" (<-["']>+) "'" /)[0];
is $cliv, $metav, "Rakuish::CLI 的 FALLBACK_VERSION({$cliv}) 与 META6 版本({$metav}) 一致";

# `--version` 快路径不加载 CLI，它自带一份回退常量，同样不能漂。
my $binv = ~'bin/rakuish'.IO.slurp.match(/ 'my Str $v' \s* '=' \s* "'" (<-["']>+) "'" /)[0];
is $binv, $metav, "bin/rakuish 的 --version 回退常量({$binv}) 与 META6 版本({$metav}) 一致";

# 0.109.0：notebook 适配层要对外自报版本（kernel_info），同一份约束。
my $ksrc  = 'lib/Rakuish/Kernel/Notebook.rakumod'.IO.slurp;
my $kernv = ~$ksrc.match(/ 'KERNEL-VERSION' \s* '=' \s* "'" (<-["']>+) "'" /)[0];
is $kernv, $metav, "Notebook 的 KERNEL-VERSION({$kernv}) 与 META6 版本({$metav}) 一致";

done-testing;
