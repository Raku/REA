use Test;
use lib 't/lib';
use TestNS::Box;
use Rakuish::REPL::Methods;
use Rakuish::REPL::Session;

# ══════════════════════════════════════════════════════════════════
# 63-method-complete.t —— `.` 之后的方法名补全（0.107.0 / V-298）
# ══════════════════════════════════════════════════════════════════
# 目标：`use TestNS::Box` 之后 `TestNS::Box.<Tab>`、`my $b = ...` 之后
# `$b.<Tab>` 都能列出方法名；解析是纯函数，取值在 Session 侧。

# ── 1. method-context：认出「在补方法」的几种形态 ──────────────────
my %v = method-context('$db.', 4);
is %v<kind>, 'var', '$db. 是变量形态';
is %v<target>, '$db', '变量名';
is %v<frag>, '', '还没输入方法名';
is %v<head>, '', '目标前没有别的内容';

my %arr = method-context('@rows.ele', 9);
is %arr<target>, '@rows', '@ 数组也认';
is %arr<frag>, 'ele', '方法名片段';

my %hash = method-context('%cfg.', 5);
is %hash<target>, '%cfg', '% 哈希也认';

my %mid = method-context('say $x.fo', 10);
is %mid<head>, 'say ', '目标前的原文保留';
is %mid<frag>, 'fo', '半截方法名';

my %type = method-context('TestNS::Box.', 12);
is %type<kind>, 'type', '包名形态';
is %type<target>, 'TestNS::Box', '带 :: 的类型名';

my %out = method-context('Out[2].', 7);
is %out<kind>, 'ref', 'Out[n] 形态';
is %out<target>, 'Out[2]', '引用目标';

my %last = method-context('_.', 2);
is %last<target>, '_', '上值引用';

# 不该命中的形态
is method-context('1.5', 3).elems, 0, '小数不当类型';
is method-context('foo.bar', 7).elems, 0, '小写链式调用不猜';
is method-context('! ls x.', 7).elems, 0, '! 行是 shell，不补方法';
is method-context('Foo::Bar', 8).elems, 0, '没有点就不补';

# ── 2. method-names：实例与类型对象都给同一份方法表 ───────────────
my $box = TestNS::Box.new;
my @inst = method-names($box);
ok @inst.grep(* eq 'hi').elems, '实例方法里有 hi';
ok @inst.grep(* eq 'hello').elems, '实例方法里有 hello';
nok @inst.grep(* eq '!secret').elems, '私有方法不进候选';
ok @inst.grep(* eq 'new').elems, 'submethod new 由 ^can 补上';
is @inst.elems, @inst.unique.elems, '候选去重';

my @typed = method-names(TestNS::Box);
ok @typed.grep(* eq 'hi').elems, '类型对象也能列方法';

# 前缀过滤
is filter-names(@inst, 'he').List.sort, ('hello',), 'filter-names 按前缀';
is filter-names(@inst, '').elems, @inst.elems, '空片段原样返回';

# ── 3. Session：跨格 use 之后按类型补全 ───────────────────────────
my $s = Rakuish::REPL::Session.new;
ok $s.eval-line('use TestNS::Box').ok, 'use TestNS::Box';

my @t = $s.completions('TestNS::Box.', 12);
ok @t.elems > 0, '类型后面 Tab 有候选';
ok @t.grep(* eq 'TestNS::Box.hi').elems, '候选是完整替换行（类型.方法）';
ok @t.grep(* eq 'TestNS::Box.new').elems, '构造器也在候选里';

my @tp = $s.completions('TestNS::Box.he', 14);
ok @tp.grep(* eq 'TestNS::Box.hello').elems, '按已输入片段过滤';

# ── 4. Session：对象补全（跨格 my 变量）───────────────────────────
ok $s.eval-line('my $b = TestNS::Box.new').ok, 'my $b = TestNS::Box.new';
my @o = $s.completions('$b.', 3);
ok @o.grep(* eq '$b.hi').elems, '对象后面能补方法';
my @op = $s.completions('say $b.he', 10);
ok @op.grep(* eq 'say $b.hello').elems, '前缀里的原文保留下来';

# ── 5. 结果引用 _ / Out[n] ────────────────────────────────────────
my @u = $s.completions('_.', 2);
ok @u.grep(* eq '_.hi').elems, '_. 用上一格的值';

my @oo = $s.completions('Out[2].', 7);
ok @oo.grep(* eq 'Out[2].hi').elems, 'Out[2] 指向对应结果';

# ── 6. 未知目标不炸、也不给候选 ───────────────────────────────────
is $s.completions('$nope.', 6).elems, 0, '未定义变量不给候选';
is $s.completions('No::Such::Type.', 15).elems, 0, '未知类型不给候选';
is $s.completions('1.5', 3).elems, 0, '小数不当作类型补全';

# ── 7. 原有补全不受影响 ──────────────────────────────────────────
ok $s.completions('help ', 5).grep(* eq 'help ls ').elems, 'help 补全照旧';
ok $s.completions('c', 1).grep(* eq 'cat ').elems, '命令名补全照旧';

done-testing;
