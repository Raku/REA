# Rakuish

**Raku 原生的命令与脚本环境**：一个 REPL，以及一套可编程的系统操作 API。
没有 bash 子集、没有 `%magic`、没有第二套语法——**命令就是 Raku**。

它是**本地、全权限**的：没有沙箱、没有 token、没有权限闸门（ADR-0019）。
Raku 源码直接求值，`!` 直接起进程——同一用户能做的事，Rakuish 里都能做。

**只支持标准 Rakudo（MoarVM）**。这是个纯 Raku 模块：不针对其他 Raku 实现
（如 rakupp）做兼容，也没有「双后端」验证这回事（ADR-0046）。

> 0.34.0（Phase 5b）起仓库只有这一套实现：v2 的双语言 REPL
> （`!` bash 子集 + `%magic` + 独立 shell 引擎 + 后台守护进程）已整体删除，
> 没有 `--v2` 兼容开关。规格真值见 [`SPEC.md`](SPEC.md)，
> 方向决策见 [`docs/ADR-0001-raku-native.md`](docs/ADR-0001-raku-native.md)，
> Agent 线已于 0.81.0 整体删除，决策与撤销清单见
> [`docs/ADR-0019-local-full-privilege-shell.md`](docs/ADR-0019-local-full-privilege-shell.md)，
> REPL 交互体验设计见 [`docs/ADR-0003-repl-experience.md`](docs/ADR-0003-repl-experience.md)，
> Cursor / worker 设计见 [`docs/ADR-0004-cursor-worker.md`](docs/ADR-0004-cursor-worker.md)，
> CSV / 补全设计见 [`docs/ADR-0005-data-workbench.md`](docs/ADR-0005-data-workbench.md)，
> CSV 方言 / describe / 补全增强见 [`docs/ADR-0006-data-profile.md`](docs/ADR-0006-data-profile.md)，
> 交互式子进程 TTY 直通见 [`docs/ADR-0007-tty-passthrough.md`](docs/ADR-0007-tty-passthrough.md)，
> 输入中断与 SQL 补全形态见 [`docs/ADR-0008-input-interrupt-sql-forms.md`](docs/ADR-0008-input-interrupt-sql-forms.md)，
> 46 份 ADR 的决策索引见 [`docs/ADR-INDEX.md`](docs/ADR-INDEX.md)，
全权限 shell 后的策略收敛见 [`docs/ADR-0020-policy-slim.md`](docs/ADR-0020-policy-slim.md)，
求值引擎子进程见 [`docs/ADR-0021-eval-worker.md`](docs/ADR-0021-eval-worker.md)，
会话快照见 [`docs/ADR-0022-session-snapshot.md`](docs/ADR-0022-session-snapshot.md)，
求值中断见 [`docs/ADR-0023-interrupt.md`](docs/ADR-0023-interrupt.md)，
`!` 流式输出与超时见 [`docs/ADR-0024-exec-stream.md`](docs/ADR-0024-exec-stream.md)，
启动文件 / prompt / `set -o` 见 [`docs/ADR-0025-startup-layer.md`](docs/ADR-0025-startup-layer.md)，
结构化管道与 `stream` 见 [`docs/ADR-0026-structured-pipe.md`](docs/ADR-0026-structured-pipe.md)、
`zip` / `join` / `tee` 见 [`docs/ADR-0029-zip-join-tee.md`](docs/ADR-0029-zip-join-tee.md)，
`interleave` / `append` 见 [`docs/ADR-0030-interleave-append.md`](docs/ADR-0030-interleave-append.md)，
TTY 后台作业 API 见 [`docs/ADR-0031-job-control-api.md`](docs/ADR-0031-job-control-api.md)，
`stream.exec` 的流式 stdin 见 [`docs/ADR-0028-streaming-exec-stdin.md`](docs/ADR-0028-streaming-exec-stdin.md)，
前端分页见 [`docs/ADR-0027-frontend-pager.md`](docs/ADR-0027-frontend-pager.md)，
> §6 方向（权限交给系统 + 常驻引擎）的探针报告见（历史归档；rakupp 线已终结，见 ADR-0046）
> [`docs/PROBE-2026-11-15-persistent-engine.md`](docs/PROBE-2026-11-15-persistent-engine.md)、
> [`docs/PROBE-2026-11-16-rakupp-integration.md`](docs/PROBE-2026-11-16-rakupp-integration.md)、
> [`docs/PROBE-2026-11-16-rakupp-adaptation.md`](docs/PROBE-2026-11-16-rakupp-adaptation.md)，
> 下一阶段路线见 [`docs/ROADMAP-2026-11-11.md`](docs/ROADMAP-2026-11-11.md)，
> 数据引擎设计见 [`docs/DESIGN-DATA-ENGINE.md`](docs/DESIGN-DATA-ENGINE.md)，
> 审计关闭状态见 [`docs/AUDIT-STATUS-2026-11-11.md`](docs/AUDIT-STATUS-2026-11-11.md)（0.61 历史记录），
> **最新复核见 [`docs/AUDIT-2026-11-18.md`](docs/AUDIT-2026-11-18.md)**（真机 + SPEC 审计，0.101.1 / 0.101.2；前次为 [`docs/AUDIT-2026-11-17.md`](docs/AUDIT-2026-11-17.md)），
> **完整使用手册见 [`docs/MANUAL.md`](docs/MANUAL.md)**。

当前版本：**`0.121.1`**（以 `META6.json` 为准，`api = 3`）。
本地复核：`bash tools/ci.sh`（套件 + 真终端两层，报告 `tmp/ci-report.txt`）；
云端 CI 自动触发未启用，见 [`docs/CI.md`](docs/CI.md)。

---

## 安装

需要 Raku（Rakudo / MoarVM）与自带的 `zef`。

```bash
zef install .          # 或：bash tools/install.sh
rakuish --version
```

运行期依赖：`JSON::Fast`、`Terminal::LineEditor`（REPL 行编辑/历史）、
`Terminal::API`（0.72.4 起的宿主 termios 快照；原本是 LineEditor 的传递依赖，
现在显式声明）。测试用 `Test`（Rakudo 自带）。

> 无 TTY 的构建机 / 容器：`Terminal::API` 的上游测试会失败并中断安装，
> 按 `docs/CI.md` §2.1 的顺序用 `--force-test --force-install` 先装依赖。

## 快速开始

```bash
raku bin/rakuish                      # REPL（TTY 带提示符；管道下逐行求值）
raku bin/rakuish -e '1 + 1'           # 求值一段 Raku 后退出
raku bin/rakuish foo.raku a b         # 跑 Raku 脚本（已预加载 DSL；一次性进程）
raku bin/rakuish-notebook              # notebook 协议入口（一行一 JSON，0.109）
```

脚本里有 `sub MAIN` 时按 `raku foo.raku a b` 的语义做**完整分派**（0.118）：
位置 / 命名参数、类型强转、`multi MAIN`、`--help`、自定义 `sub USAGE`、退出码
都交给 Rakudo 自己的 `RUN-MAIN`，只是词法环境里多了 `sys` / `repl` / DSL。

`rakuish-notebook` 不接 ZMQ：它只说「一行请求 / 一行响应」，传输留给外部进程。
这样语义只有一套，前端可以换。协议见
[`docs/ADR-0037-notebook-frontend.md`](docs/ADR-0037-notebook-frontend.md)。
0.113 起它还会**主动推送**：`busy` / `idle` 包住每格执行，`engine` 帧报告
引擎崩溃与自动重启（含快照恢复结果）——引擎死在没有请求的时刻，前端也能立刻知道。

### 在 Jupyter 里用（0.111）

Python 侧只需要 `ipykernel`（Jupyter 自带），ZMQ / HMAC / 心跳由它的基类处理：

```bash
python -m pip install ipykernel jupyter_client
python tools/jupyter/install_kernel.py     # 装 kernelspec 到用户目录
python tools/jupyter/smoke.py              # 端到端自检（不需要浏览器）
jupyter lab                                # 或 jupyter console --kernel rakuish
```

源码树开发时可指定桥命令：
`python tools/jupyter/install_kernel.py --bridge "raku -Ilib bin/rakuish-notebook"`。
中断会杀掉求值引擎并丢会话状态，内核不声称 debugger；详见 MANUAL。
notebook 里跑过的操作可用 `audit notebook` 查账本（0.112 起）。

### REPL 输入只有两类

| 你敲的 | 处理 |
|---|---|
| `! git status` | argv 分词（空格 + 引号）后交给 `sys.exec`；`\|` `>` `$` `*` `&&` **原样当参数** |
| `cd ..` / `ls docs` / `stat .` / `read file` | 内置命令 + **裸字面路径**改写成函数调用；`$var` / 表达式 / 引号参数仍按 Raku |
| 其它（**含 `%` 开头**） | Raku 表达式，直接求值；失败就是失败，不回退 shell |

```text
rakuish> 1 + 1
Out[1] = 2
rakuish> %h = a => 7; %h<a>       # % 是哈希，不是魔法命令
Out[2] = 7
rakuish> ! git status --short     # 外部命令：argv，不经过 shell
rakuish> help()                   # 命令 + 摘要
rakuish> env()                    # KEY=VALUE
rakuish> stat('README.md')        # path / type / size ...
rakuish> write('a.txt', 'hi')     # wrote 2 bytes to ...
rakuish> read('a.txt')            # 直接显示内容
rakuish> source lib.raku          # 在会话里跑脚本：它声明的 sub / my 留在会话里
rakuish> source tool.raku 参数     # 带参数跑；文件有 sub MAIN 时会调用它
rakuish> cells                    # 本会话的格记录（编号 / 状态 / 耗时 / 输入）
rakuish> cells --text sess.raku   # 导出成可重放脚本
```

内置结果按用户习惯展示：`help()` 是命令表，`env()` 是 `KEY=VALUE`，
`stat()` 是字段列表，`write()` 是“写了多少字节到哪”，`read()` / `pwd()` 直接给内容/路径，
`ls` / `glob` 给 basename 列表；不再显示 `IO::Path.new(...)` / `Stat.new(...)` 之类的对象结构。

日常命令有 shell 习惯的薄层：`cd` / `cd -` / `pwd [-L|-P]` / `clear` / `history` /
`ls [-a -l -h -F -R -t -S -r -d]` / `cat` / `read` / `head [-n N]` / `tail [-n N] [-f]` /
`echo [-n]` / `mkdir [-p]` / `touch` / `cp [-r]` / `mv` / `rm [-r] [-f]` /
`stat` / `export` / `unset` / `glob` / `grep [-inv]` / `wc [-lwc]` / `which`。
每个命令支持 `--help`（或 `-?`）查看自己的用法；也可以 `help ls`。
会话自省另有一组不占 `Out[n]` 的只读命令：`who` / `whos`（变量、类型、大小、
声明的 sub/class/use）、`$x?` / `Box?` / `ls?`（看一眼文档或类型）、
`rerun [n]`（重跑历史第 n 条，0.108）。
它只翻译这些命令，不是第二套 shell：管道、重定向、子 shell 不支持；
参数里的 `$NAME` 按会话 env 展开，`~` 展开到家目录。

**没有** auto-shell：裸打 `git status` 会得到 Raku 的「未声明例程」编译错误——
这正是设计目标，输入落到哪一层永远明确。

**嵌套 REPL / 交互式子进程（0.70）**：`! --tty raku`（或 `-t`）把当前终端
直接交给子进程——输出实时可见、无 30s 超时、退出后回到 Rakuish；Raku 里等价写
`tty-exec('raku')`。`! -- --tty foo` 让 `--tty` 成为字面 argv。
输出不进 `_` / `Out[n]`，非 TTY 明确拒绝。设计见 ADR-0007 / SPEC V-167。

**流式输出与超时（0.90）**：交互式 REPL 里 `! make` 边跑边出（引擎发 `chunk`
帧，父进程实时打印）；管道 / `-e` / 脚本仍「收完再显示」。长任务用
`! --timeout-ms 600000 make` 或 `! --no-timeout make`，要旧的捕获行为用
`! --capture ...`。子进程 stdout 仍是管道（不是 TTY），需要终端语义用 `--tty`。
设计见 ADR-0024 / SPEC V-229…V-231。

**纯声明格跨格持久**（0.65）：`class` / `role` / `grammar` / `sub` / `use`
单独成格时，后续格可直接使用；混合语句格不缓存。glob 支持反斜杠转义与
嵌套 brace：`glob('{a,{b,c}}.txt')`、`glob('\{a,b\}.txt')`。边界见 SPEC V-153。

**交互体验（0.66）**：`config set edit-mode vi|helix|emacs` 切换 Vi/Helix 模态
（默认 emacs），`hints on|off` 控制上下文提示（默认 on），
`plugins on|off` 允许加载本地 Raku 插件（默认 off）。`hint [输入行]` 查提示，
`plugin list|load PATH|unload NAME|info NAME` 管插件；插件是返回 `Command`
对象的 Raku 文件，**加载即执行本地代码**——只加载你自己的文件。
边界见 ADR-0003 / SPEC V-154…156。

TTY 下使用 `Terminal::LineEditor`：Up/Down 翻历史、Ctrl-R 循环历史检索、
Ctrl-A/E 行首行尾、`→`/Ctrl-F 接受灰字建议（0.100 起，历史前缀自动建议）、
ShiftTab 列出补全候选、**Ctrl-C 中断当前输入（0.71 起不再退出会话）**、
Ctrl-D 退出，Tab 补全命令名、路径和 `help <命令>`（0.100 起前缀零命中时
子序列回退、未知命令 / 缺失路径 / 括号失配标红）；历史保存在
`~/.rakuish-history`。管道下仍走普通逐行输入。

严格模式：

```text
set -e     # 失败格请求退出，退出码 1
set +e     # 关闭
```

`set -e` 对 shell 命令、`!` 外部命令和 Raku 求值失败同样生效；它在 REPL 里也是
“下一个失败就退出”，不要和普通的交互式试错混用。

**启动文件 / prompt / `set -o`（0.90）**：交互式 REPL 启动时执行
`~/.rakuish/rc.raku`（`RAKUISH_RC` 改路径、`RAKUISH_NO_RC=1` 关闭；`-e` / 脚本不读；v2 的 `~/.rakuishrc` 不读）。
rc 逐行执行，变量 / `use` / `alias` / `set` 都能写，且**不占 `Out[n]`**。
`repl.prompt = -> { "{sys.cwd.basename} ❯ " }` 可编程提示符（每格重新求值，
异常回退默认样式）。`set -o` 支持 `errexit` / `histexpand` / `noglob` /
`noexpand` / `xtrace`，`set -o NAME` 开、`set +o NAME` 关；未知选项明确报错。
设计见 ADR-0025 / SPEC V-232…V-236。

历史替换与查找：

```text
!!        重跑上一条
!3        重跑第 3 条
!-1       重跑倒数第一条
!$        重跑上一条的最后一个词
help --find 读取
which ls
```

`!cmd` 仍是外部命令；只有整行的 `!!` / `!$` / `!n` 才做历史替换。

配置与别名：

```text
alias ll=ls -alh
alias
unalias ll

config set color off
config get color
config
```

配置默认写入 `~/.rakuish-config.json`；可用 `RAKUISH_CONFIG` 覆盖路径。
alias 只展开 Shell 命令行的第一个词，不会改变 Raku 表达式。
`config` 是通用 KV 存取：**只有入口真正读取的键才生效**（`color` / `clock` /
`timing` / `git` / `prompt-style` / `banner` / `hints` / `plugins` / `edit-mode` /
`vi-start`）；0.75.0 前文档拿 `theme` 当示例，但它从未被读取，已订正。

启动 hook：

```text
hook add start echo "hello"
hook
hook run start
hook clear start
```

`start` hook 在 REPL/脚本求值前执行；写入配置，下次启动自动运行。
hook 是本地可信配置，等同于启动时执行一条命令，不要放不可信内容。

后台任务：

```raku
my $h = sys.spawn('raku', '-e', 'sleep 20');
jobs                 # id / status / exe / argv / started
sys.cancel($h);      # 或 sys.wait($h)
```

`jobs` 只列出当前 `Sys` 会话启动的进程，`wait` / `cancel` 后自动清理。

常用命令已覆盖：文件/目录、进程、数据、配置、插件。
完整参数、示例和边界见 **[docs/MANUAL.md](docs/MANUAL.md)**；本文只保留速览和架构入口。

### 界面与计时（0.62）

TTY 启动显示极简 banner（版本 / Raku / VM / 时间 / cwd / 行编辑状态），
prompt 每行显示 `时间 · cwd · git 分支 · 格号 · 上格耗时 · ❯`；失败格显示退出码，
续行用 `···`。管道 / 脚本一律纯文本，不输出提示符与任何控制序列。

计时是**会话数据**，不是 `%magic`：`timed { ... }` / `bench({ ... }, :repeat(5))`
返回可组合的 `Result`，`perf [N]` 查看每格耗时与平均/最慢，`repl.perf-hist` 是原始记录。

`config set` 即时生效：`color auto|on|off`、`clock on|off`、`timing on|off`、
`git on|off`、`prompt-style full|compact|plain`、`banner on|off`；
环境变量 `NO_COLOR` 强制关色、`FORCE_COLOR=1` 强制开。

`--help` / `--version` 是**启动参数**，要在 shell 里跟在 `rakuish` 后面；
在提示符里敲 `--help` 会被当成 Raku 的 `--` 运算符（入口会给一句提示）。

### 脚本就是 Raku 脚本

```raku
#!/usr/bin/env rakuish
use Rakuish::DSL;

for ls('.', :recursive).grep(*.extension eq 'rakumod') -> $f {
    my $text = read($f);
    write($f, $text.subst(/TODO/, 'DONE'), :atomic);
}
```

`.rakuish` / `.raku` 交给入口时，整份源码作为**一个 cell** 求值：DSL 与
`sys` / `repl` / `registry` 已预绑定，不打印 `Out[n]`，相对路径跟随**调用者 cwd**。
REPL / `-e` / 脚本的 `root` 默认是文件系统根（Windows 为当前盘根 + all-drives）。
`root` 现在是**防误操作的边界**，不是安全沙箱：测试夹具用它隔离临时目录，
日常使用下它恒真（SPEC V-199）。

### 引擎进程：崩溃不带走 REPL（0.83）

交互式 REPL 的 `EVAL` 不在宿进程里跑，而是一个独立的 `raku` 子进程
（SPEC V-212…V-216 / [ADR-0021](docs/ADR-0021-eval-worker.md)）：

```text
你 → 行编辑（父进程） → 协议 → 引擎子进程（Session / EVAL / %STATE / Out[n]）
                                    ↓ 崩溃
                       父进程重启引擎，继续接受输入
```

为什么需要它——同进程下这三条都无解：

| 你做的事 | 同进程的后果 |
|---|---|
| `exit; 1`（不是整行 `exit`，那个会被会话拦下） | 整个 REPL 立即结束 |
| NativeCall 乱指针 / 深度递归 | 段错误带走进程 |
| `while 1 { }` | **SIGINT 打不断**，只能从外面 kill |

引擎死掉后，父进程会重启它并**如实**告诉你丢了什么：

```text
引擎进程已退出（…）
  · 已自动重启：REPL 本身没有退出，可以继续输入
  · **会话状态已丢失**：跨格变量 / Out[n] / 打开的数据引擎连接
  · 输入历史与配置仍在（它们在父进程侧）
```

`! --tty` 由父进程执行（它持有终端），管道 / `-e` / 脚本仍是进程内求值
（没有「会话要继续」这回事）。

**终端事实由前端下发**（0.87 / 0.88）：引擎的 `$*IN` / `$*OUT` 是协议
管道，`.t` 恒 False、`COLUMNS` 也不可靠。所以「是不是 TTY」「多少列」
都由父进程每格告诉它（V-226 / V-227）。尺寸是用 `ioctl(TIOCGWINSZ)`
（POSIX）或 `GetConsoleScreenBufferInfo`（Windows）**问终端**得来的，
不是读环境变量。

这里还有个容易混的区分：`tty`（用户面前有终端）**不等于** `live-out`
（本进程的 stdout 就是它）。分页、逐行流式要判后者 —— 拿前者代替会让
引擎里的分页器把表格写进 JSON 协议流、再吞掉下一个请求（0.89 修的事故）。

这条修掉了 0.83 / 0.87 引入的几个静默回归：

| 症状 | 原因 |
|---|---|
| `clear` 不输出 | 引擎把管道当成非终端，跳过 ANSI |
| shell 彩色全灭 | 同上 |
| 40 列终端里 `ls` 排出 76 字符宽的行 | 读不到 `COLUMNS`，按默认 80 列排 |

#### 求值中的 Ctrl-C（0.85）

引擎卡在 `while 1 { }` 时按 Ctrl-C：引擎被 kill、重启、从快照恢复，
提示符回来，上一格的变量还在。

```text
❯ loop { }
^C已中断当前求值（Ctrl-C）
  · 引擎已重启，可以继续输入
  · 已从快照恢复：0 条声明、1 个变量（2026-11-16T13:31:15）
[exit=130]  2.29s  ❯ say $keep
99
```

**归因是分开的**：中断是 `op=interrupted` / `code=130`（128+SIGINT），
说「已中断」；引擎自己崩了才说「引擎进程已退出」/ `500`。
混在一起会让用户以为按 Ctrl-C 会搞坏东西。

引擎自己处理不了中断 —— SIGINT 打不断纯 VM 循环（实测），只能由外部 kill。

平台现状（0.86 起两个平台都在真终端里验过）：

| 平台 | 验证方式 | 结果 |
|---|---|---|
| Linux / WSL | `tools/ctrl-c-posix.py`（真 PTY） | 归因、存活、快照恢复全过 |
| Windows | `tools/ctrl-c-win.py`（真 ConPTY，经 winpty 起） | 同上，`exit=130` |

两个探针都带对照：**不在求值时**按 Ctrl-C 必须是「已中断当前输入」。
缺了这条，「出现『已中断当前求值』」可能只是文案恒真。它们由
`bash tools/ci.sh` 的 `console` 层跑，报告里有一行 `console=pass`。

#### 崩溃后能恢复什么（0.84）

引擎每成功一格就把**声明 + 纯值**写进快照，崩溃重启时重放：

```text
引擎进程已退出（…）
  · 已自动重启：REPL 本身没有退出，可以继续输入
  · 已从快照恢复：1 条声明、3 个变量（2026-11-16T12:18:51）
  · 无法恢复：$fn（连接 / 闭包 / 超大值，已置为 Any；重新赋值即可）
  · 输入历史与配置仍在（它们在父进程侧）
```

| 能恢复 | 不能恢复 |
|---|---|
| 标量 / 集合 / DateTime / IO::Path / 枚举 | 数据库连接、文件句柄、进程 |
| `sub` / `class` / `role` / `grammar` / `use` | 闭包（`sub { }`、`-> $x { }`） |
| 属性可序列化的类实例 | 超过上限的值（默认 1MB 字符，可配） |

**语句格不重放**：`write(...)` / `! rm` 这类副作用不会因为恢复再执行一次
（恢复一次就多删一次文件，比丢状态更糟）。

单值上限：`RAKUISH_SNAPSHOT_MAX` 指定字符数（默认 `1000000`）；
`0` / `off` / `none` / `unlimited` 表示不限制。写错值（负数、非数字）
**回落到默认**——不会因为一个笔误就把保护关掉。

开关：`RAKUISH_NO_SNAPSHOT=1` 关闭（同时停掉读写），
`RAKUISH_SNAPSHOT=<path>` 指定文件，默认 `$HOME/.rakuish/session-<cwd指纹>.json`。

---

## 核心 API

### `Rakuish::Sys` —— 唯一系统出口

```raku
use Rakuish::Sys;

my $sys = Rakuish::Sys.new(:root('/work'), :cwd('/work'));

my $text = $sys.read('README.md');
$sys.write('README.md', $text.subst(/TODO/, 'DONE'), :atomic);

my @md = $sys.ls('docs', :recursive).grep(*.extension eq 'md').sort(*.modified);
my $r  = $sys.exec('git', 'status', '--short');   # argv-only
say $r.out if $r.ok;
```

| 方法 | 说明 |
|---|---|
| `read` / `write` / `append` | 文本（`utf-8`）或 `:bin`；`write` 默认原子写 |
| `ls` / `glob` / `stat` | 路径一律 `IO::Path`；`glob` 支持 `*` / `?` / `**` / `foo/**/bar` / `[a-z]` / `{a,b}` |
| `rm` / `cp` / `mv` / `mkdir` | 返回 `Result`；`rm` 支持 `:recursive` / `:dry-run`，不跟随符号链接；`cp -r` 有总条目上限 |
| `exec` / `spawn` / `wait` / `cancel` | 只收 argv 数组；`Handle.stdout` / `.stderr` 是 `Channel.Supply` 真流式 |
| `cd` / `get-env` / `set-env` / `env` | **会话级**：不 `chdir`、不改 `%*ENV` |
| `resolve` | 词法归一化 + 中间 symlink canonical 校验，越界抛 `X::Rakuish::Bound` |
| `try-op` | 把异常收敛成 `Result`（DSL / 命令层用） |

**错误模型**：读 / 写 / 列目录 / stat **抛异常**（Raku 风格）；
`rm` / `cp` / `mv` / `mkdir` 返回 `Result`。
`exec` **永不抛**：正常 `0`、启动失败 `127`、超时 `124`、取消 `137`，
`Result.value` 带 `exe / argv / timed-out / cancelled / truncated / start-failed` 供审计。

**Result 渲染层**：`Result` 自带 `render`，可直接产出 text / json / markdown：

```raku
my $r = $sys.exec('git', 'status', '--short');
say $r.render('text');       # 默认；人读
say $r.render('json');       # 稳定键序；:pretty 展开
say $r.render('markdown');   # 带 stdout/stderr/value 代码围栏
say $r.to-json;              # 等价便捷方法
```

JSON 中 `IO::Path` 统一 `/` 分隔，`Blob` 为字节数组；markdown 围栏会按内容自动加长，
不会被内容里的三个反引号截断。未知格式抛 `X::Rakuish::Render`，不静默回落。

`ls` / `glob` / `recent` 返回的是 `List[IO::Path]`；REPL 展示时会按 shell `ls`
风格输出 **basename**（TTY 下多列、管道下每行一个），而不是 `IO::Path.new(...)` 结构。
值本身仍是 `List[IO::Path]`，可继续 `.grep` / `.map`。

### `Rakuish::Data` —— 结构化数据层（0.39）

```raku
use Rakuish::Data;
use Rakuish::Data::Table;

my $t = ls-table('.');                       # name/type/size/modified/path
$t.where({ .<type> eq 'file' })
  .select('name', 'size')
  .sort-by('size')
  .to-text;

my $json = open-data('data.json');           # .json → Record/Table
my $csv  = open-data('data.csv');            # .csv → Table
my $arr  = open-data('events.arrow');        # .arrow/.feather → Table（标量自研读、嵌套走 Arrow::IPC）
save-data('out.json', $json);                # 按扩展名写 JSON/CSV/Arrow/文本
save-data('out.arrow', $arr);                # 二进制列式，pandas/polars/duckdb 能直接读
save-data('big.arrow', $arr, :batch-size(50_000));   # 大表：拆成多个 RecordBatch（0.121）

# 装了 Duckula 就能把 Table 交给 DuckDB 算（聚合 / 窗口 / 多源 join）
$arr.sql('select kind, count(*) c from t group by 1 order by c desc');
sql({ a => $arr, b => $csv }, 'select * from a join b using (id)');
```

REPL 里也有 `open` 与 `ls --json`：

```text
open data.json
open --raw README.md
ls --json .
ls **/*.rakumod
```

`Table` 支持 `where` / `get` / `select` / `sort-by` / `first` / `last` /
`limit` / `offset` / `each` / `count` / `sum` / `mean` / `min` / `max` /
`distinct` / `join` / `sql` / `schema` / `column-type` / `to-text` / `to-json` / `to-markdown` / `to-html`；
它是真 Hash 行，不是文本表格。

类型由首行推断（`int` / `num` / `str` / `bool` / `datetime` / `list` / `map` / `any`），
`select` / `where` / `join` 等操作会保留/合并类型；`$t.schema` 返回
`name/type/nullable` 表。

**结构化管道（0.91 / ADR-0026）**：`stream(...)` 把文本 / `!` 的输出 / Table /
Cursor 变成**惰性记录流**，阶段是方法链，出口是表格、JSON、CSV，或者回灌给
子进程的 stdin——`!` 单独做不到的那一半。

```raku
stream(cmd-result('! find . -name "*.raku"'))   # 文本 → 记录（n/line）
    .where({ .<line> ~~ /Result/ })             # 惰性
    .limit(5)
    .table;                                     # 出口

stream('a,b' ~ "\n" ~ '1,2', :format<csv>)
    .exec('wc', '-l', :format<csv>);            # 记录 → 子进程 stdin（边算边写）
```

惰性：`where` / `select` / `map` / `limit` / `skip` / `add-column` / `drop`；
物化：`sort-by` / `unique` / `count-by` / `group-by`。来源是 Cursor 时只能读一次，
第二次明确报错而不是给空流。没有 `|`，也没有 `|>`（后者在 Raku 语法里不可定义）。

**两条流（0.94 / ADR-0029）**：`zip` 按位置配对，`join` 做 hash join（右表物化、
左表惰性，`:how<inner|left|right|outer>`，默认 left 与 `Table.join` 一致），
`tee` 边流边写一份副本。

```raku
$logs.join($names, :on<user_id>, :how<inner>);   # 右表是字典
$logs.zip($marks, :longest);                     # 按位置对齐
$logs.tee('out.csv');                            # 写多少看下游读多少
```

列名冲突时右列加 `_right`（`:suffix` 可改）。`tee` 要「只写前 N 行」就把 `limit`
放上游；它不是 fan-out。

**按顺序收拢两条流（0.95 / ADR-0030）**：`interleave` 交替取、`append` 首尾接；
两者都保持每行原样、不改列名（与 `zip` 合成一行不同）。

```raku
$a.interleave($b);            # a1,b1,a2,b2…（默认吐完长侧）
$a.interleave($b, :shortest); # 任一侧耗尽即停
$a.append($b);                # a 全部 + b 全部（同构流）
```

`append` 的列取左侧（同构是契约）；`interleave` 取两侧并集但不改名。

**后台作业（0.96 / ADR-0031，POSIX-only）**：普通 Raku 函数，不是 shell 语法。

```raku
my $r   = bg-exec('/usr/bin/slow-job');  # 起后台作业，立即返回带 job id 的 Result
bg-jobs();                                # 列出作业（Table）
fg($r.value<job>);                        # 带回前台并等待；Ctrl-Z 停住则归还前台
bg($r.value<job>);                        # 挂起的作业在后台继续
```

作业表在父进程，引擎崩溃重启也不丢；`fg` 的 `ok` 是「带回成功」，退出码看
`code`。Windows 上返回 `code=127` 明确降级。与 `spawn()/jobs()`（捕获式后台）
是两套语义，不合并。

结构化分页：

```text
explore data.csv        # JSON/CSV → Table，按页查看
explore docs/           # 目录 → ls-table
ls --json .             # 产生 Table
explore                 # 查看上一格
```

分页在**父进程**做（0.92 / ADR-0027）：TTY 下 `Enter` 翻页、`q` 退出；
`RAKUISH_PAGER=auto`（默认，只给 `explore`）/ `always`（任何超一页输出）/ `never`。

**Parquet 与大结果（0.64）**：

```raku
my $t = open-data('sales.parquet', :allow-external);   # → Table
save-data('out.parquet', $t, :allow-external);
my $small = $db.query('select * from big', :max-rows(100));
$t.batches(:size(1000)).map({ .to-text });             # 惰性分批
$t.to-text(:max-rows(20));                             # 展示上限
```

`.parquet` / `.pq` 需要显式 `:allow-external`（Shell 里是 `open --external`），
路径仍经 `Sys.resolve` 做工作目录校验。
`:max-rows` 在引擎里把 `LIMIT` 下推进 SQL，物化前就截断；`Table` 本身仍是物化值。
SQL 驱动错误统一为 `X::Rakuish::Data`，不泄漏驱动堆栈（SPEC V-152）。

### `Rakuish::Data::Engine` —— DuckDB / SQLite 数据引擎

`DB::DuckDB` 是可选依赖：没装时核心 rakuish 不受影响，`open-db` 会给出安装提示。

```raku
my $db = open-db(':memory:', :!read-only);   # 只读是默认
$db.execute('create table sales (region varchar, amount double)');
$db.execute('insert into sales values (?, ?)', 'east', 42.5);
my $t = $db.query('select region, sum(amount) s from sales group by region');
$t.sort-by('s', :reverse).to-text;
$db.tables;          # Table
$db.schema('sales'); # Table
$db.close;
```

**0.67 流式 Cursor**（设计见 [`docs/ADR-0004-cursor-worker.md`](docs/ADR-0004-cursor-worker.md) §3）：
`cursor()` 只在被拉取时向驱动要下一批行——DuckDB 走 `:stream` + 惰性 `chunks`，
SQLite 走逐行 `hash`，都不预先物化整表。

```raku
my $c = $db.cursor('select * from big_table', :batch-size(500), :max-rows(5000));
for $c.batches -> $batch { ... }   # 惰性 Seq of Table；提前退出不会读完
$c.take(10).to-text;               # 只取前 10 行并立即释放
$c.close;                          # 幂等；拉完 / 达到上限自动 close
```

`query()` 行为不变；`Table.batches` 仍是**已物化 Table** 的分批视图，两者不是一回事。
不支持的引擎抛 `X::Rakuish::Unsupported`，不静默退化。一次性单连接，不提供
可恢复游标或事务一致性快照。

**0.68 数据工作台**（设计见 [`docs/ADR-0005-data-workbench.md`](docs/ADR-0005-data-workbench.md)）：

- **CSV 受控外部读写**：`.csv` 加上 `:allow-external` 时走 DuckDB
  `read_csv_auto` / `COPY ... FORMAT CSV`，由引擎做类型推断；不加开关时
  仍走 `Sys.read` / `Sys.write`，行为与 0.64 完全一致。路径仍经 `Sys.resolve`。
- **SQL 上下文补全**：`open-db` 会注册当前会话 Engine（可用 `repl.engine` 读），
  在 `$db.query('select ...')` 这类引号字符串里按 Tab 会补关键字 / 表名 / 列名。
  纯函数、只读 `tables()` / `schema()` 元数据，驱动异常时安静退化成不补全（V-161）。

```raku
my $t = open-data('sales.csv', :allow-external);   # int / num 由 DuckDB 推断
save-data('out.csv', $t, :allow-external);          # COPY ... FORMAT CSV, HEADER
$db.query('select * from sa|')                      # Tab → sales
```

**0.71 输入中断与补全形态**（设计见 [`docs/ADR-0008-input-interrupt-sql-forms.md`](docs/ADR-0008-input-interrupt-sql-forms.md)）：

```text
Ctrl-C                  # 丢弃半行输入 / 清空续行缓冲，重画 prompt（不退出）
Ctrl-D                  # 才退出会话
$db.query(q[select * from sales where region = 'east' and am|])   # Tab → amount
$db.query(sql => 'select * from sa|')                              # Tab → sales
$db.query(:sql('select * from sa|'))                               # Tab → sales
```

Ctrl-C 只作用于输入阶段，不承诺中断正在求值的 cell；SQL 仍只做词法启发式，
不解析 AST（V-168 / V-169）。

**0.70 交互式子进程**（设计见 [`docs/ADR-0007-tty-passthrough.md`](docs/ADR-0007-tty-passthrough.md)）：

```text
! --tty raku          # TTY 直通：实时输出、无超时、退出后回到 Rakuish
tty-exec('python')      # Raku 原生入口
! -- --tty foo          # -- 之后是字面 argv
```

`tty-exec` 是“把当前终端借给子进程”，不捕获输出。

**0.72 PTY 捕获**：子进程看到 TTY，但父进程拿回输出、超时、取消：

```raku
my $r = pty-exec('python', '-c', 'print("hi")',
                 :timeout-ms(5_000), :cols(100), :rows(30));
$r.out;     # 干净文本（默认剥离 ANSI / OSC）
$r.code;    # 124 = 超时
```

当前不提供 PTY stdin 写入，见 SPEC V-170 / MANUAL §5。

**0.72.2 加固**（见 [`docs/AUDIT-FIXES-0.72.2.md`](docs/AUDIT-FIXES-0.72.2.md)）：
`pty-exec` 先做 Rakudo 版本 + `isatty` 双检，旧编译器上明确返回 `code=127` 而
不再把 `value<pty>` 硬编码成 `True`；`max-bytes` 改为「先剥离控制序列、再截断
干净文本」，消除半截 `ESC[` 残片并让大输出捕获从超线性降到近线性。
需要 Rakudo ≥ 2025.12；交互式 REPL 仍请用 `tty-exec`。

**0.72.3 契约回归**（见 [`docs/ADR-0009-tty-exec-sigint-contract.md`](docs/ADR-0009-tty-exec-sigint-contract.md)）：
`tty-exec` 期间按 Ctrl-C 的行为已用真 PTY 钉住——子进程退出、宿主存活、
下一格仍可求值、之后 Ctrl-C 回到输入中断语义。

**0.72.4 termios 快照恢复**（见 [ADR-0009 §0](docs/ADR-0009-tty-exec-sigint-contract.md)）：
0.72.3 把「不做 termios 快照」当成边界，前提是错的——`Terminal::API`
（`Terminal::LineEditor` 的传递依赖）早已封装好 Linux/macOS/BSD 与 Windows
的实现，而 canonical 基线能直接测出污染：子进程 `stty raw -echo` 会把宿主
`c_lflag` 从 35387 改成 35376（关掉 `ICANON+ECHO+ISIG`），行编辑器下一轮
prompt 会把污染态当基准固化。现在 `tty-exec` 在交接前存快照、正常路径与
`LEAVE` 幂等恢复，`Result.value<termios-restored>` 标记成败；回归见 `t/31`。

**0.72.5 Windows 控制台模式实测**（见 [ADR-0009 §7](docs/ADR-0009-tty-exec-sigint-contract.md)）：
Windows 没有 POSIX termios，走的是 `GetConsoleMode` / `SetConsoleMode`。
用 ctypes 直接调 `CreatePseudoConsole` 造真 ConPTY 后测得：输入模式 `503`
（`PROCESSED/LINE/ECHO`）→ 子进程 `make-raw` 后 `1008`（清掉 `0x007`、置
`VIRTUAL_TERMINAL_INPUT`）→ `tty-exec` 返回后回到 `503`；把快照注入关掉时
停在 `1008`，说明断言确实敏感。同一探针在 conhost（`winpty`）下数值一致。
`prove6` 环境没有控制台，所以这块不进 `t/`，入口是
`python3 tools/tty-termios-win.py`（0 通过 / 1 失败 / 2 环境不具备）。

**0.73.0 进程组交接**（见 [`docs/ADR-0010-job-control-feasibility.md`](docs/ADR-0010-job-control-feasibility.md)）：
以前 `tty-exec` 的父子进程同属一个组，靠父进程临时吞 SIGINT 保命——所以
子进程一句 `kill(0, SIGTERM)` 就能把宿主 REPL 一起打死。现在 POSIX 上改用
`posix_spawnp` + `POSIX_SPAWN_SETPGROUP(0)`（`Proc::Async` 交 pid 时子进程已
exec，父侧 `setpgid` 100% 失败），spawn 后 `tcsetpgrp` 把终端前台交给它，
`waitpid` 自己回收。Ctrl-C 由终端驱动直接投给前台组，父进程收不到；SIGINT
tap 只保留在 spawn 与切前台之间的微秒级窗口。`Result.value` 新增
`job-control` / `job-control-reason` / `fg-restored` / `pgid`。
Windows 无 POSIX 前台进程组，走老路径并标 `job-control=False`。
**不做** `&` / `jobs` / `fg` / `bg` / Ctrl-Z 作业管理（那是 shell 语法）。
回归见 `t/32`（真 controlling terminal，11 断言）。

**0.74.0 结果着色与输入行高亮**（见 [`docs/ADR-0011-highlight-colors.md`](docs/ADR-0011-highlight-colors.md)）：
颜色以前只在 banner / prompt / hint 上，结果本身是纯文本。现在渲染层也接上了
同一条开关链（`config color` / `NO_COLOR` / `FORCE_COLOR` / TTY）：

- `ls` / `glob` 的路径列表与 `ls -l`：目录**粗蓝**、可执行**粗绿**、符号链接**青**；
- `Out[n] =` 标签 dim、`错误:` 红、`help()` 命令名粗青 + 摘要 dim、
  `env()` 的 KEY 青、`stat` 字段名 dim、写入结果 `wrote` 绿 + `[non-atomic]` 黄；
- 输入行：字符串绿、注释灰、数字黄、变量青、关键字粗蓝。

两条硬约束：颜色只插入**零宽**转义——列宽仍按纯文本算，`strip-ansi` 后
必须逐字符相同；渲染层同时判 TTY，`rakuish -e 'ls' | cat` 绝不混进 ANSI（V-116）。
输入行高亮通过覆盖行编辑器的 `visible-input-field-string` 实现（它不提供钩子），
`emacs` / `vi` / `helix` 三种模式共用同一个字段类；词法只做单行的字符串 /
注释 / 数字 / 变量 / 关键字，不碰 `q[...]` / heredoc / 多行。
`Result.render-result(format => 'text')` 与 Table 表格**仍然不掺 ANSI**。
回归见 `t/33`（77 断言）与 `tools/tty-check.py` 的三项真 PTY 检查。

普通 `!` 的输出捕获 / 30s 超时 / 结构化 `Result` 语义保持不变；超时会提示改用
`tty-exec`。`bind-stdio` 前先过 `Sys` 的 cwd root 校验与会话 env（V-167）。

**0.69 数据剖析与方言**（设计见 [`docs/ADR-0006-data-profile.md`](docs/ADR-0006-data-profile.md)）：

- **CSV 方言**：`:csv-options({ delimiter => ';' })` 等 7 个白名单选项；
  读路径全部 `?` 绑定，写路径只拼校验过的字面量。只在 `.csv` +
  `:allow-external` 时生效，默认文本路径不变（V-162）。
- **describe 值 API**：`describe [表名]` / `describe($table)` 返回结构化 Table
  （`name/type/nullable/non_null/distinct/total/sample`），可继续 `.where` /
  `.to-json`；`Table.describe` 与 `Engine.describe` 列集合一致（V-163）。
- **补全增强**：表别名前缀 `s.am` → `s.amount`、关键字跟随大小写
  `SEL` → `SELECT`。**不做 SQL AST 解析**（V-164 / ADR-0006 §4）。
- 顺手修了一个 0.68 之前的名字解析缺陷：REPL 里裸写 `open-data('x.csv')`
  曾解析到需要 `$sys` 的底层函数，现在正确落到 DSL 版本（V-165）。

```raku
my $t = open-data('semi.csv', :allow-external,
                  :csv-options({ delimiter => ';', header => False }));
describe($t)                      # 列摘要 Table，不是文本报告
describe('sales')                 # 需先 open-db(...)
```

默认只读、默认 `enable_external_access=false`；SQL 文件访问不能绕过 `Sys` 的
工作目录校验。本机 REPL 里 `open-db` 之后即可查询。

```bash
zef install DB::DuckDB:ver<1.2.2+>   # 依赖 Alien::Libduckdb:ver<1.2.1+>，官方预编译 DLL 自带 Excel 扩展
```

SQLite 作为可选的小型事务引擎：

```raku
my $sdb = open-db(':memory:', :engine<sqlite>, :!read-only);
$sdb.execute('create table t (x int)');
$sdb.execute('insert into t values (?)', 1);
$sdb.query('select * from t').to-text;
$sdb.close;
```

`DB::SQLite` 同样是运行时可选依赖；SQLite 适合小表/应用状态，不用于大分析。
SQLite 的 `:memory:` 连接固定为单连接，避免连接池各开一个独立内存库。

写事务（DuckDB / SQLite 同一 API）：

```raku
$db.begin;
$db.execute('insert into t values (?)', 1);
$db.rollback;    # 或 $db.commit
```

### `Rakuish::DSL` —— 短命令（可扩展）

```raku
use Rakuish::DSL;
bind-session(Rakuish::Sys.new(:root('/work'), :cwd('/work')));

say read('a.txt');
write('b.txt', 'hi', :atomic);
for recent(7, 'md') -> $f { say $f.basename }

# 并行 map（保序）；:degree 控制并发度
my @sizes = peach(ls('docs'), { .s });

# 想要「常用命令」就写个普通 sub，返回可组合的值——不用注册、不用改分支表
sub todo-files { ls('.', :recursive).grep({ read($_) ~~ /'TODO'/ }) }
```

REPL 里的 shell 文本 → Raku 值桥：

```raku
my $t = cmd('ls --json .');        # Table
$t.where({ .<type> eq 'file' }).elems;

# _ 指向上一格，Out[1] 起是成功结果历史
_
Out[1]
```

`cmd` 只在这种“有 REPL Session”的上下文可用；裸脚本请直接用 `sys` / DSL。
`==>` 可以接单参数/目标在最后的例程；Table 的多参数操作继续用方法链。

导出：`ls / read / cat / write / append / stat / rm / cp / mv / mkdir / glob / exec /
tty-exec / pty-exec / cmd / cmd-result / cd / pwd / cwd / resolve / env / get-env /
set-env / unset-env / echo / try-op / timed / peach / help / recent`。

### `Rakuish::Command` —— 命令注册表

```raku
use Rakuish::Command;

my $reg = default-registry();               # 13 个内置命令
say $reg.get('read').spec.to-json-schema;   # 参数 schema → JSON Schema

$reg.register(BuiltinCommand.new(
    :cmd-name<double>, :summary('两倍'),
    :handler(-> $sys, $x { $x * 2 }),
));
```

加命令只需 `register(...)`：`CommandSpec` 同时给补全器与 `help` 生成参数 schema。

内置命令返回的 `Result` 会**附带一份 text 渲染**（`rendered` / `text` / `gist`），
`say $result` 和 REPL 展示时直接看人读文本；`value` / `out` 仍是结构化值，
所以 `read` 仍返回 `Str`、`ls` 仍返回 `IO::Path` 列表，不影响链式组合。

---

## 项目结构

```text
bin/rakuish            唯一入口：REPL / -e / 脚本
lib/Rakuish/
  Sys.rakumod          会话对象：cwd / env / root / resolve / try-op
  Sys/FS.rakumod       文件 API（read/write/ls/stat/rm/cp/mv/mkdir/glob：转义/嵌套 brace）
  Sys/Proc.rakumod     进程 API（exec/spawn/wait/cancel/tty-exec/pty-exec，argv-only）
  Sys/PosixSpawn.rakumod  进程组交接：posix_spawnp(SETPGROUP)+tcsetpgrp+waitpid（0.73，ADR-0010）
  Result.rakumod       Result / Stat / WriteResult / 异常族
  Result/Renderer.rakumod  多格式渲染（text/json/markdown）
  Data.rakumod         open/save + JSON/CSV/Parquet（显式 :allow-external）
  Data/Table.rakumod   Table（值方法/schema/types/describe/渲染/batches）
  Data/Cursor.rakumod  惰性查询游标（batches/rows/take/close）
  Data/Stream.rakumod  结构化管道（惰性记录流 / 文本桥 / exec stdin）
  Data/CsvOptions.rakumod CSV 方言白名单 / 绑定与字面量生成（纯函数）
  Data/Engine.rakumod  引擎角色（query/cursor/describe/read-write parquet·csv）
  Data/Engine/DuckDB.rakumod / SQLite.rakumod  可选引擎
  Data/Pager.rakumod   explore 结构化分页
  DSL.rakumod          短 sub + 会话绑定 + cmd 桥
  Command.rakumod      Command 协议 / CommandSpec / 注册表
  REPL/Chrome.rakumod  banner/prompt/颜色/耗时格式化（纯展示层）
  REPL/Keymap.rakumod  Vi/Helix 模态语义 + 行编辑器子类 + 键位预设
  REPL/Hints.rakumod   上下文提示（纯函数）
  REPL/Plugins.rakumod 显式本地 Raku 插件（默认 off）
  REPL/SqlComplete.rakumod SQL 上下文补全（纯函数，别名/前缀列/大小写风格）
  REPL/Highlight.rakumod    输入行语法着色（纯函数，0.74 / ADR-0011)
  REPL/Introspect.rakumod   doc 的对象内省（纯函数、零 EVAL，0.75 / ADR-0012)
  Kernel.rakumod       前端唯一入口：Request / Policy / execute（0.76，ADR-0013）；
                       op 通道 + present/bundle（0.78）
  Display.rakumod      内容级展示包：text / markdown / html / json + 协商（0.78/0.110）
  Sys/Console.rakumod  Windows 控制台码页收口（0.76.1，ADR-0014）
  REPL/Session.rakumod REPL 会话：求值、续行、渲染、`_`/`Out`、声明持久、配置/hooks
  REPL/Shell.rakumod   日常命令薄层（cd/ls/cat/rm/...，只翻译成 Sys 调用）；
                       命令名只在 COMMAND-GROUPS 声明一处（0.77 / ADR-0015）
  Audit.rakumod        统一审计：字段白名单 / seq / 落盘 / 轮转（0.80，ADR-0018）；
                       0.81.0 起 Agent 线删除，只剩 Kernel 一个写入点
  Eval.rakumod         引擎子进程父侧客户端：协议 / 崩溃检测 / 重启（0.83，ADR-0021）
  Eval/Server.rakumod  引擎子进程入口（完整 Session 住在这里）
  Eval/Proxy.rakumod   冒充 REPL::Session，让 Kernel 与审计不感知进程边界
  Snapshot.rakumod     会话快照：可序列化判定 / 捕获 / 原子落盘（0.84，ADR-0022）
  Incomplete.rakumod   纯 Raku 的多行续行判定
t/01…t/50（有间隔）  语义、入口、shell 观感、数据层、分页、界面与计时、Parquet、类型持久/glob、模态/hints/插件、Cursor、CSV、SQL 补全、CSV 方言、describe/补全增强、嵌套 REPL、Ctrl-C、PTY 捕获与能力探测、`tty-exec` 期间 SIGINT 归属与 termios 快照、进程组交接、结果着色与输入行高亮、选项补全与 doc/目录栈/日志、内核与策略、Windows 控制台编码、命令表与格记账、展示包、统一审计、引擎子进程、会话快照、求值中断与真终端验收、`!` 流式/超时、rc/prompt/`set -o`、结构化管道
t/51 / t/52 / t/53    元数据护栏、全模块 require 冒烟、行尾护栏（双平台）
t/54                  TTY 后台作业 API（bg-exec/fg/bg/bg-jobs，POSIX）
t/55 / t/56           tail -f 跟随循环与交互契约（should-stop 驱动 + 真 PTY）
t/57 / t/58 / t/59    交互手感：纯函数（模糊/建议/错误态标记、In/Out 引用）、
                      字段渲染与动作（灰字/逐词接受/菜单/Ctrl-R）、真 PTY 冒烟（POSIX）
t/60                  手感后续引擎侧集成：In/Out 引用补全、跨格声明消除命令误标
t/61                  junction 结果契约：`1|2` 的构造 / 三格式 + display 渲染 / `_` 与 `Out[n]`
tools/tty-check.py      真 TTY 交互自检（Linux/WSL；驱动 REPL + 嵌套子进程）
tools/tty-termios-win.py Windows 控制台模式快照/恢复自查（真 ConPTY；无控制台时自动经 winpty 重启）
tools/tty-cjk-win.py   Windows 中文输入自检（真 ConPTY：中文回显 / ls 中文目录 / say 中文，0.76.1）
tools/ctrl-c-posix.py  真 PTY 下 Ctrl-C 求值中断自查（含「不在求值」对照，0.86）
tools/ctrl-c-win.py    同上，Windows 真 ConPTY 版（无控制台时自动经 winpty 重启，0.86）
```

## 测试

```bash
raku -Ilib t/01-sys-fs.t            # 单文件
bash tools/run-all.sh               # 首选全套入口（退出码 = 是否有问题）
python3 tools/tty-check.py          # 真 TTY 交互自检（需 Linux/WSL + python3）
python3 tools/tty-termios-win.py    # Windows 控制台模式自查（真 ConPTY，需 winpty 兜底）
```

`tools/run-all.sh` 是全量测试的首选入口（Linux / WSL 原生；Windows 在
Git Bash / WSL 下跑）。`prove6 -Ilib t` 仅在显式安装了 prove6 时作为备选；
逐文件 `raku -Ilib t/xx.t` 是可移植的最小方式。

Windows 与 Linux 都跑同一套断言。Windows 侧的部分差异是**如实反映**而非缺陷：
符号链接创建需要权限（对应用例 SKIP），`IO::Path.modified` 可能返回 1969 年假值，
`DSL.recent` 检测到不可信时间就降级为全量，不编造时间。

## 明确不支持

bash / POSIX 语法本身：管道、重定向、变量展开、glob、heredoc、`&&` 短路语义、
`$?`。需要这些能力就写 Raku（方法链、`Supply`、`.subst`、正则）。
完整清单见 [`SPEC.md`](SPEC.md) §7。

引擎子进程侧还有三条明确不做（[ADR-0021](docs/ADR-0021-eval-worker.md) §9）：
求值中的 Ctrl-C 硬中断、崩溃后的会话状态恢复、跨进程传递 Raku 值对象。
第一条是 0.84 候选，后两条是刻意不做——「看起来没丢」比丢失更糟。

## 平台

**Linux 是正式目标平台；Windows 11 可用**：文件 API 与 argv 外部命令两平台都验证过，
不承诺任何 POSIX shell 语义。Windows 下 REPL / 脚本默认允许访问所有盘符（`D:/`、`F:/`）；
给 `Sys.new(:root(...))` 时才有目录边界（防误操作，非安全隔离）。

## 许可

MIT，见 [`LICENSE`](LICENSE)。
