# 持续集成（0.105.0）

> 状态：**本地 CI 入口已接并双平台实测；云端自动触发未启用。**
> 远端是 `https://gitee.com/skyter10086/rakuish.git`（Gitee），不是 GitHub。

## 1. 为什么是这样

`A` 路线要的是「把 57 文件 / 2521 断言从仓库自述变成**可复核**」（数字随每次发布更新）。
这一条由 `tools/ci.sh` 达成：任何人 clone 后跑一条命令，得到机器可读报告
与严格退出码。

**本版故意不放一个「看起来像 CI、但永远不会跑」的 YAML**：

- 远端是 Gitee，GitHub Actions 的 `.github/workflows/*.yml` 不会触发；
- Gitee Go 需要在仓库网页端开通流水线，且构建机里默认**没有 Rakudo**
  （本项目要求 Rakudo ≥ 2025.12 的 `:pty`，发行版自带包通常太旧）；
- Gitee Go 的 `shell@agent` 是「到主机组执行」、要 `hostGroupID`，
  不是在构建机内跑脚本；通用构建插件的 `commands:` 可用，但整条链路
  在本会话里**无法端到端验证**。

写了不验证就等于挂牌子。所以这里把两件事分开交付：
**可复核的入口（已验证）** 与 **云端触发的启用配方（未启用，见 §5）**。

## 2. 用法

```bash
bash tools/ci.sh          # Linux / WSL / Windows(Git Bash) 通用
```

### 2.1 无 TTY 环境的依赖安装（容器 / 构建机）

`Terminal::API` 的上游测试在非 TTY 环境会失败（`get-config failed`），
直接 `zef install .` 会中途断掉。干净环境按下面顺序装：

```bash
zef install Terminal::API        --force-test --force-install
zef install Terminal::LineEditor --force-install
zef install .                    --force-install
```

`--force-test` 只针对上游测试失败；Rakuish 自己的测试照常跑（`tools/ci.sh`）。
CI 脚本里请把「依赖安装」与「应用测试」分成两个步骤记录，不要混在一起
（依赖测试失败是上游问题，应用测试失败才是本仓库的问题）。

平台自动判定（`uname -s`）：

| 平台 | 实际 runner | 断言数来源 |
|---|---|---|
| Linux / WSL | `bash tools/run-all.sh` | 按当前 `t/*.t` 清单逐个统计 `tmp/<name>.out` 的 `^ok ` 行 |
| Windows（MINGW / MSYS / CYGWIN） | `prove6 -Ilib t` | prove6 汇总行的 `Tests=N`；缺失时回退到上一行的方式 |

产物：

- `tmp/ci-report.txt` —— `key=value` 机器可读报告
- `tmp/ci-runner.log` —— 套件原始输出（失败时末尾 20 行打到 stderr）
- `tmp/console.log` —— 真终端层原始输出（失败时末尾 25 行打到 stderr）

两层验收（0.86.0 起）：

| 层 | 内容 | 为什么单列 |
|---|---|---|
| 套件 | `prove6 -Ilib t` / `run-all.sh` | 常规回归 |
| **真终端** | `tools/ctrl-c-posix.py`（真 PTY）/ `tools/ctrl-c-win.py`（真 ConPTY）/ `tools/pager-posix.py`（真 PTY，0.92 分页） | 信号投递依赖真终端：套件里用 `kill -INT` 只能验 handler 逻辑，验不了「`\x03` 会不会变成 SIGINT / `CTRL_C_EVENT`」。Windows 版还多一个 `! --tty` 场景（t/30 的对应物）。分页探针验的是「行编辑器交还终端之后，回车真的到得了分页器」——这条在套件里测不出来 |

实测（0.105.0，2026-11-19）：

```
version=0.105.0  platform=windows  runner_exit=0  files=57  assertions=2521
not_ok=0         console=pass      result=PASS
version=0.105.0  platform=linux    runner_exit=0  files=57  assertions=2521
not_ok=0         console=pass      result=PASS
```

（0.105.0 备注：文件锁 `with-lock`（V-294）——锁独立 `路径.lock` 伴生文件
而非数据文件（后者被原子 rename 换 inode 会让锁失效），Raku 内建
`IO::Handle.lock` 跨平台、无需模块；异常自动解锁，`:shared` / `:non-blocking`
（冲突抛 `X::Rakuish::LockConflict`）。t/01 +8 断言；两进程抢锁无丢失更新
已手工验证。0.104.0 是中文编码别名 `gbk`→`gb18030`。）

## 3. 失败判据（四条独立，任一即 FAIL）

1. **runner 退出码非 0** —— 含 `127`（`prove6` 不存在）、`2`（`env.sh` 找不到 raku）。
2. **输出里有** `not ok` / `# Failed test` / `Result: FAIL` / `[FAIL]`。
3. **防空跑**：`files` 或 `assertions` 为 0 直接 FAIL。
4. **真终端层失败**：探针退出码非 0 且非 2。

真终端层的 `2` 是「环境不具备」（没有控制台且找不到 winpty，或没有
python），记 `console=skip`、**不算失败也不算出绿**——报告里能看见，
不会被当成通过。

只看 `not ok` 会漏判：测试崩在中途时计数可能是 0 而退出码非 0
（`tools/run-all.sh` 头部注释记过这个坑）。只看退出码也不够，所以三条并列。

`ci.sh` **不安装 Rakudo**，缺 raku 时如实 FAIL，不静默跳过、不降级为「跳过」。

## 4. 前提（构建机）

- Rakudo ≥ 2025.12（`:pty` 相关用例），`raku` 可被 `tools/env.sh` 找到；
  优先级 `$RAKU` > `~/.rakubrew/versions/moar-2026.09` > 其它 rakubrew 版本 > PATH。
- zef 依赖：`JSON::Fast`、`Terminal::LineEditor`、`Terminal::API`；
  数据栈的可选依赖（`DB::DuckDB` / `DB::SQLite`）缺失时相关用例按既有语义跳过。
- 不需要 root、不需要网络、（Windows 侧）不需要管理员权限。

## 5. 云端触发：启用配方（本版未启用）

### Gitee Go（当前远端）

1. 仓库网页端 → 流水线 / Gitee Go → 新建流水线，选「自定义」；
2. 配置文件路径用 `.workflow/*.yml`（Gitee Go 的仓库内格式，
   `version: '1.0'` + `stages/steps` + `triggers`），或用网页可视化编排；
3. 构建步骤只填一条：`bash tools/ci.sh`；
4. 触发：`push` 到 `main` 与 PR。

**关键前提**：构建机镜像里要有 §4 的 Rakudo 与依赖。
Gitee 公共构建机没有预装 Rakudo，需要先准备安装步骤或自定义镜像——
这一步没做，所以流水线即使建了也会在 `env.sh` 处 exit 2。

### GitHub Actions（若将来镜像 / 迁移到 GitHub）

`.github/workflows/ci.yml` 的两个 job 只需分别执行 `bash tools/ci.sh`
（Linux 用 `ubuntu-latest`、Windows 用 `windows-latest` + Git Bash），
**同样要先装 Rakudo**。不要在干净 runner 上直接套用，否则必然 FAIL
——那不是 CI 通过了，是 CI 如实报「环境没准备好」。

## 6. 明确未验证 / 未承诺

- 云端自动触发**未启用**（Gitee Go 需网页端开通，本会话无法验证）。
- Windows 云端 runner 未验证；本地 Windows 是 Git Bash + 本机 Rakudo Star 2026.09。
- `assertions` 是 TAP `^ok ` 行数（或 prove6 的 `Tests=`），
  不是独立重算的断言真值；与 `t/51` 守的 provides、`t/52` 的模块冒烟是互补关系。
- CI 的 `console` 层只覆盖 **Ctrl-C 中断**这一条真终端契约；
  `tools/tty-check.py`、`tools/tty-termios-win.py`、`tools/tty-cjk-win.py`
  与 `zef install` 仍按 HANDOFF 的验收清单**手工**跑。
- Windows 的 `console` 层需要 winpty（Git for Windows 自带）：`ci.sh` 在
  Git Bash 里跑时自身没有控制台，探针会自己用 winpty 重启一次；找不到
  winpty 时记 `console=skip`，不会伪装成通过。
- 报告落在 `tmp/`（`.gitignore` 已忽略），不是长期存档；要留档得另接制品库。

## 7. 建议的停止条件

`bash tools/ci.sh` 在推送前跑一次，结果写进提交说明。
等真的把云端触发接通（并且第一次绿跑有日志链接可查）之后，
再把本文首行状态从「云端未启用」改掉 —— 不要提前改。
