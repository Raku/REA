# Rakuish 架构决策记录（v0.2 · 转向后）

> ⛔ **历史文档（2026-10-13 的 v0.2 设计草案）—— 已被取代，不要按它实现。**
>
> 本文描述的是「默认按 shell 解析 / Raku 走 `eval` 逃逸层 / rakupp 常驻 pty」
> 的旧方案。当前实现是：
>
> - **默认按 Raku 求值**；`!` / 自动回退 / 反引号走 shell（不是默认 shell）；
> - shell 语义在**独立引擎进程** `bin/rakuish-sh` 里，**默认真 bash**，
>   `%shell native` 才切到自研 Raku shell 层（2026-11-05 架构转向）；
> - 只跑 **Rakudo（MoarVM）**，rakupp 不再作为验收基线。
>
> 当前架构以 [`../HANDOFF.md`](../HANDOFF.md) §2 / §5.8 与
> [`../README.md`](../README.md) 为准；本文仅留作决策历史。
>
> 基线文档：`rakuish-core-subset`（功能范围）/ `rakuish-agent-mode`（AI 接口）
> / `rakuish-shell-design`（V 实现蓝图），三者均为 v0.1 草案。

## 1. 这次转向做了什么

**转向前**（v0.1，Raku 优先）：

```
输入 → 默认按 Raku 求值 → 失败且首个词在 PATH 里 → 回退 shell
```

**转向后**（v0.2，shell 优先）：

```
输入 → 默认按 shell 解析执行（管道/重定向/glob/$VAR/内建）
     → 只有 eval "..." / raku { } 才穿过逃逸层进 Raku 引擎
```

这直接回应了「为什么不能像 bash/zsh/fish 那样直接敲命令」——
不再靠"求值失败再猜"，而是**默认就是 shell**，Raku 是显式逃逸。

## 2. 关键设计契约（来自 shell-design §1）

> **外壳层永不解析 Raku。** 两个独立 parser 靠 `eval "..."` / `raku { }`
> 的字符串边界隔开。

这条契约消灭了 v0.1 里一整类歧义 bug（`print` 是内建还是 `lpr`？
`_` 是不是变量？`%h` 会不会被误判成 magic？）。新架构下它们都不存在，
因为外壳层根本不碰 Raku 语法。

## 3. 作用域隔离（白皮书 §4 + shell-design §6）

| | 存储 | 类型 | 可见性 |
|---|---|---|---|
| shell 变量 | 外壳层内存表 | 全字符串（bash 模型） | 经 `export` 进 `%*ENV` 后 Raku 可见 |
| Raku 变量 | 引擎内部 | 全类型 | 外壳层**读不到**，除非经 `eval` 结果 `.Str` 回填 |

唯一交叉点：`eval "..."` 的字符串边界。

## 4. ⚠️ 实测结论：rakupp 二进制**没有** C API

shell-design §5.1 假设存在 `rakupp_new` / `rakupp_run` / `rakupp_free`，
并建议"拉 rakupp 头文件确认签名"。**实测结论是这套 API 不存在**：

```console
$ nm -D ~/.rakupp/bin/rakupp | grep -cE ' T (rakupp|Raku)'
0
```

二进制只导出 C++ mangled 符号（`_ZN6rakupp10ParseErrorC2E...` 之类），
没有任何 C ABI 入口，也没有头文件。

## 5. ⚠️ 实测结论：必须用 **pty** 驱动，不能用管道

逐项测过三种调用方式：

| 方式 | 逐行求值 | `my` 跨行存活 | 错误后可用 |
|---|---|---|---|
| `rakupp -e '...'`（每次新进程） | 是 | **否** | 是 |
| `rakupp < file` / `rakupp -`（管道） | **否**（当整程序） | 是（同一次输入内） | **否**（首个错误即终止） |
| `rakupp` / `raku` 裸跑 + 管道 | **否**（无回显） | — | — |
| `raku` + **pty** | **是** | **是** | **是** |

关键机制：两个引擎都按 `isatty` 分流——非 tty 时走**脚本模式**
（整份输入编译成一个程序，无逐行回显，出错即终止）；只有 tty 才进
真正的 REPL（有 banner、有 `[0] >` 提示符、逐行求值）。

用 pty 验证（`pty.openpty()` + `raku`）拿到了完整 REPL banner 与提示符，
证明这条路径成立。

**所以引擎层的设计是**：`os.openpty()` 起一个常驻 `raku`/`rakupp`，
按**提示符边界**切分每次求值的输出，而不是按行。

## 6. 选型：MoarVM 还是 rakupp

两者都可用（MoarVM 2026.09 与 rakupp 5.3.0 都在本机）。v0.1 项目做了
双后端兼容，代价是踩了一大批"两后端语义不一致"的坑（容器不摊平、
字符类不可靠、`=~` 不可用、`$0` 作用域、`split(:all)` 行为不同……）。

**v0.2 改为单后端**：默认 rakupp（shell-design 与白皮书都基于它，
且它是单二进制、跨平台、更小）。MoarVM 保留为可切换选项，但不再要求
每次改动双后端跑回归。

## 7. Agent Mode 的落地方式

agent-mode.md 定义的是 JSONL over stdio。由于引擎是 pty 子进程，
Agent Mode 的 `mode:"eval"` 实现为：写一行 JSONL → 转成一行 Raku 送进
pty 引擎 → 按提示符边界收结果 → 序列化成 JSONL 响应。

`mode:"shell"` 走同一套 shell parser/executor，只把输出收成
`stdout`/`status` 而非直接打到终端。

## 8. 待核实（文档遗留，我方实测进度）

| 项 | 文档状态 | 我们的结论 |
|---|---|---|
| rakupp C API 签名 | 待核实 | **不存在**，改用 pty |
| rakupp 沙箱 `g_sandboxChecks` 默认态 | 待核实 | 未测；Agent Mode 先在外壳层做能力限制 |
| NativeCall 全量支持度 | ⚠️ | 未测；Tier 2 暂不承诺 |
| 生态包可用比例 | ⚠️ 约 40% | 未测；不影响 Tier 0/1 |
| 自定义中缀运算符 | 未核实 | 未测 |

## 9. v0.1 的哪些资产保留

保留并继续用：
- 报错美化的**分类思路**（按消息关键词而非异常类型名分类）
- 命令高亮、Tab 补全（含含空格路径的处理）
- 历史持久化与去重
- `~/.rakuishrc` 的 `key = value` 解析器设计
- 30 套回归测试的**用例设计**（语义变了的会标注）

废弃：
- `kind-of` 的"默认 raku，失败回退 shell"路由 → 改为默认 shell
- `%` magic 命令族（help/time/load/run/repl/hist…）→ shell 内建取代
- 双后端一致性约束 → 单后端
- Raku 侧补全（关键字/作用域变量）→ 逃逸层后 Raku 代码不再在输入行，
  该功能自然消失