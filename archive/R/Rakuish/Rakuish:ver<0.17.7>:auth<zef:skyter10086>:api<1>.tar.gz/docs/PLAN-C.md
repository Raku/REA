# Rakuish 重设计（C 方案）：真 bash 做兼容层，火力转向 Raku 脚本 DSL

> 决策记录：用户已确认「不再追 bash 100% 兼容」。
> 版本基线：0.12.0（P0 脚本模式、P1 Result 对象化均已落地）。

---

## 1. 为什么停

两条路同时走，结果是两条都不到位：

| 现状 | 问题 |
| --- | --- |
| native 引擎是 bash 的不完整克隆 | 21 个内建（`cd` `export` `read` `exit` `type` `alias` `source` `test` …）在 `$SH-BUILTINS` 里直接 fail-unsupported，越补越发现边角无穷 |
| 目标是「用 Raku 写 shell 脚本」 | `bin/rakuish` 原本 36 行、无 `@*ARGS`，**根本没有脚本入口**，Raku 侧只能当 REPL 用 |
| 会话状态活引擎进程里 | REPL 侧看不到 cwd / 环境变化，两边各有半个 shell |

结论：bash 兼容性做成「能用真 bash 就用真 bash」，自研层不再扩张；
把工程预算全部投到**只有 Rakuish 能提供的东西**——Raku 当脚本语言的 shell。

---

## 2. 分层

| 层 | 内容 | 状态 |
| --- | --- | --- |
| **L0 进程原语** | `posix_spawnp` 直接拉起二进制（`Shell::Exec`，只在引擎进程用） | 已有，冻结 |
| **L1 bash 兼容层** | 现有 native bash 子集（词法/解析/展开/管道/&&/重定向/heredoc/参数） | **冻结：只修 bug，不加语法** |
| **L2 Raku shell DSL** | `run()` 返回 Result、管道对象化、内建归宿主、DSL 糖 | **主战场（P1–P3）** |
| **L3 驱动层** | REPL + 脚本模式（同一个 `drive`）、shebang | P0 已通 |

判定规则（写进 CONTRIBUTING 级别的硬规矩）：

1. 遇到 bash 语法缺口 → **不实现**，报错并给出 Raku 等价写法。
2. 遇到真 bash 能做的事 → 走 `%shell bash`（默认），不要自研。
3. 新能力只允许加在 L2，且必须有 `.t` 用例。

---

## 3. 三种运行形态

| 形态 | 入口 | 行为 |
| --- | --- | --- |
| 交互 REPL | `rakuish` | 有提示符 / 回显 / `Out[n]` / `%hist` 等全套装饰 |
| 脚本 | `rakuish run foo.rakuish`、`rakuish foo.rakuish`、shebang | 无装饰，只有程序输出；出错即停 |
| 兼容 shell | REPL 里的 `!cmd`、脚本里的 `!cmd` | 交给引擎进程（默认真 bash） |

三种形态共用 `drive`，语义不会分叉。

---

## 4. P0：脚本模式（已落地 0.11.0）

### 4.1 实现

不另写执行器，只把「输入从哪来」换掉：

```raku
our sub run-script(Str $path --> Int) is export {
    ...
    drive(reader-from(@lines), :color(False), :auto-shell(False), :script(True))
}
```

`drive(&read-line, …)` 本来就是可注入的（测试早就这么用），于是
heredoc、多行续接（`needs-more`）、`%STORE`、跨行词法状态全部免费继承。

新增 `:script` 一个开关，只做三件事：

1. **装饰分流**：`say-ui` 是「人看的」出口（`In[n]` 回显、`Out[n]` 值渲染、
   `↪ shell` 提示、`cd` 提示、反引号捕获框），脚本模式静音；
   `say` / 外部命令 / `$r.extra-output` 走程序输出，原样落地。
2. **不猜外部命令**：`:auto-shell(False)`。REPL 里求值失败会猜「这行像不像命令」，
   脚本里这是有害的——打错一个变量名会被当命令执行，错误被静默吞掉。
3. **出错即停**：错误写 stderr（不污染 `> out.txt`），退出码 1。
   继续跑只会把错误拖到更远的地方爆发。

### 4.2 交付

| 文件 | 变更 |
| --- | --- |
| `lib/Rakuish/Loop.rakumod` | `drive` 加 `:$script`；新增 `run-script`；`out-line(` 在 drive 体内共 12 处按「装饰 / 程序输出 / 错误流」三分流 |
| `bin/rakuish` | 参数解析（`run <file>` / 裸文件 / `--help` / `--version`）；**脚本模式不加载 Prompt**（CI 不必为批处理装行编辑器） |
| `t/43-script.t` | 13 条断言，全部通过真实子进程验证 stdout / stderr / 退出码 |
| `META6.json` | 0.10.0 → 0.11.0 |

回归：`tools/run-all.sh` 43 个 .t 文件，问题总数 0。

### 4.3 已知限制（P0 明确不做）

- ~~`$*PROGRAM` 仍是 `bin/rakuish` 的路径，不是脚本路径~~ → **P2 已修**（0.13.0，
  `$SOURCE-FILE` 注入 `$*PROGRAM`）。
- ~~行号/文件名在报错里指向 `EVAL`，不是脚本第 N 行~~ → **P2 已修**（0.13.0，
  `error-location` + `remap-line`，现在报 `/tmp/x.rakuish:3`）。
- 脚本里 `%magic` 命令可用但输出未做脚本化裁剪（`%help` 之类）。
- bash 风格 `set -e` / 函数 / `trap` 不做——脚本语言是 Raku，不是 bash。

---

## 5. P1：Result 对象化与管道对象化（已落地 0.12.0）

### 5.1 目标

```raku
my $r = run 'ls -la';          # 立即执行，得到结果对象
$r.code; $r.out; $r.err;       # 三个基本字段
$r.lines;                      # 惰性切行
$r.json;                       # 自动 from-json，失败给 Nil + 提示

run('ls').grep(rx/\.raku$/).head(5).out.say;   # 进程内管道（小数据）
run-pipe <ls grep sort head-5>;                 # 真管道（大数据，不进 REPL 内存）
```

现状缺口：`!cmd` 只能把输出甩到终端，Raku 侧拿不到结构化结果；
反引号 `` `cmd` `` 只给一个字符串，`code` / `stderr` 全丢。

### 5.2 设计

新模块 `lib/Rakuish/Result.rakumod`：

```
class Rk::Result {
    has Str  $.out;    # 已 chomp 尾换行
    has Str  $.err;
    has Int  $.code;
    has Str  $.cmd;
    method lines(--> Seq)      # $!out.lines，惰性
    method ok(--> Bool)        # $!code == 0
    method json(--> Mu)        # try from-json($!out)，失败 Nil
    method grep($m --> Rk::Result)
    method head(Int $n)
    method tail(Int $n)
    method sort(*%opts)
    method uniq
    method wc(--> Int)
    method !derive(Str $out)   # 派生新结果，保留 code/cmd
}

sub run(Str $cmd, :$in, :%env --> Rk::Result) is export
```

暴露方式：在 `Eval.wrap-eval-source` 的源码前缀里加 `use Rakuish::Result;`
（与现在注入 `__shellq__` 同一个位置），用户自己 `my sub run` 自然遮蔽。

**为什么 `run-pipe` 要单独存在**：`.grep().head()` 是进程内流，中间结果要全进内存；
`ls | grep | head` 在真 shell 里是流水线，`head` 一退前面全停。给 `run-pipe`
直接走引擎的多进程管道，`run` 走单进程捕获。

### 5.3 验收

- `run('false').code == 1`
- `run('echo a b').lines.elems == 1`
- `run('printf "{\"a\":1}"').json<a> == 1`
- stderr 不进 `.out`
- `run-pipe` 在 100MB 输出 + `head -1` 下不 OOM
- `Rakupp` 后端同样通过（正则/字符串运算都要避开回溯写法，见既有踩坑记录）

---

### 5.4 落地记录（0.12.0）

实现与 §5.2 草稿的三处偏差，都是踩出来的：

| 草稿 | 实际 | 原因 |
| --- | --- | --- |
| 类名 `Rk::Result` | `Rakuish::Result::Result`（`Result` 由模块 export） | 项目里其它模块都是 `Rakuish::` 前缀，`Rk::` 是新的短命名空间，没必要为 4 个字符多一层 |
| `grep`/`head` 返回派生 Result | 返回**行的 List** | 派生 Result 得伪造退出码与 cmd，语义会飘（`.code` 该等于多少？）—— 只保留「行序列」这一种可组合值，要重新变成 Result 用 `run-pipe` |
| `.json` 依赖 JSON::Fast | 内置递归下降解析器，装了 JSON::Fast 时优先用它 | 环境里没装 JSON::Fast（META6 也没这依赖），而 `.json` 是招牌能力，不能"看环境给不给" |

另外两处是**行为**层面的决定：

1. **`run` 落在 EVAL prelude 里做遮蔽**：`Eval::wrap-eval-source` 的 `do { … }`
   最前面注入两行 `sub run` / `sub run-pipe`。Raku 的 sub 在块内**全序可见**（实测），
   所以用户代码写在哪儿都命中；想拿原生 `Proc` 显式写 `my &cr = &CORE::run;`。
   先例是 `__shellq__` 已经在同一个位置注入，没有新机制。
2. **`.raku` 只给一行摘要**（`Result(code=0 · 3 行 · a)`）。`Out[n]` 渲染走 `.raku`，
   把几万行灌进终端会毁掉 REPL；要看全文用 `.out` / `.gist`。

交付与回归：

| 文件 | 变更 |
| --- | --- |
| `lib/Rakuish/Result.rakumod` | 新模块（264 行）：`Result` 类 + `run` / `run-pipe` + 零依赖 JSON |
| `lib/Rakuish/Eval.rakumod` | 顶部 `use Rakuish::Result;`；`wrap-eval-source` 注入 `DSL-PRELUDE` |
| `t/44-result.t` | 26 条断言：单元层 24 条 + EVAL 集成层 2 条 |
| `META6.json` | 0.11.0 → 0.12.0，`provides` 加 `Rakuish::Result` |

回归：`tools/run-all.sh` 44 个 .t 文件，问题总数 0。

§5.3 验收项全部通过，其中「`run-pipe` 在 100MB 输出下不 OOM」按设计成立但
**未做压测**（流水线是引擎进程里的真 pipe，`head` 退出后 SIGPIPE 由引擎侧处理，
这一条留到 P2 做引擎侧改造时一起验）。

---

## 6. P2：内建与会话状态归位（已落地 0.13.0）

### 6.1 问题

21 个内建在 native 引擎里是硬黑名单。而 REPL 已经自己实现了 `cd` / `ls`，
两边各有一份状态：引擎里的 `export` 改不到 REPL 的 `%ENV`，REPL 的 `cd`
也要额外 `change-dir` 才能同步进程 cwd。

### 6.2 设计

原则：**谁拥有会话，谁实现内建**。宿主是 REPL 进程，所以内建归 REPL：

| 内建 | 归属 | 落地方式 |
| --- | --- | --- |
| `cd` `pwd` `export` `unset` `alias` `type` `exit` `read` `source` `test` | REPL 宿主 | 在 drive 里按行拦截（`cd` / `ls` 已是这个模式），直接改宿主 `%ENV` / cwd |
| 引擎侧状态同步 | —— | 复用已有 `--env-out` / `apply-env-delta` 协议：引擎每次执行后回传 env 增量，宿主 merge；宿主改 env 则通过 `--env-in` 下传 |

这样 `%shell native` 也有一致的会话语义；而 `%shell bash`（默认）下 bash 自己管内建，互不干扰。

顺带解决 P0 遗留：`$*PROGRAM` / 报错行号传参（`EVAL` 支持 `:file` / 行号偏移）。

### 6.3 验收

- `export FOO=1` 后 `!printenv FOO` 与 `%ENV<FOO>` 都看得到
- `cd /tmp` 后 `pwd`、`!pwd`、`run('pwd')` 三者一致
- `alias ll='ls -l'` 在 REPL 内生效，且不影响 `!` 行（`!` 行是 bash 的领域）

### 6.4 落地记录（0.13.0）

新增 `lib/Rakuish/Builtins.rakumod`（宿主侧内建）+ `t/45-builtins.t`（76 断言）。

**落地的是 13 个名字、10 类行为**：

| 类别 | 名字 | 备注 |
| --- | --- | --- |
| 目录 | `cd` `pwd` | `cd` 写 `$*CWD` + 同步 `PWD`/`OLDPWD` 进 `%*ENV`；输出 `cd → /path` 标记 `ui`（脚本静音） |
| 变量 | `export` `unset` | 会话表为准，同时镜像进 `%*ENV`（引擎子进程靠继承拿到） |
| 别名 | `alias` `unalias` | 只对**简单命令**展开、**只展一层**（同 bash） |
| 查询 | `type` | 别名 / 内建 / PATH 扫描三档 |
| 退出 | `exit` | 超 255 取模；非数字 ⇒ 2 |
| 输入 | `read` | `-p` 提示、`-r`；最后一个变量吃掉剩余全部词（bash 语义） |
| 执行 | `source` `.` | 真执行由 Loop 以 `:&source-runner` 注入（避免 Builtins 反依赖 Loop） |
| 判定 | `test` `[` | 一元 `-e -f -d -r -w -x -s -z -n -L`；二元 `= != -eq…-ge`；`!` 取反 |

**与草稿的三处偏差**（记录原因，避免下次再纠结）：

1. `true` / `false` **不搬**。它们不改会话状态，引擎一次 fork 就够；搬过来反而让
   `!false` 失去「退出码摘要行」（t/04 会红）。
2. `[` / `]` 从「元字符黑名单」里**拿掉**。否则 `[ -d /tmp ]` 的 `[` 被当成 glob，
   这个内建永远进不了宿主。`*` / `?` / `|` / `;` / 重定向 / `$(` 仍然挡着，
   宁可少拦（漏给引擎走默认路径）不可拦错。
3. **env 下传没走 `--env-in`**：`set-var` 已把变量镜像进宿主的 `%*ENV`，引擎
   作为子进程**天然继承**，再造一份 `--env-in` 只是多一条容易不同步的路径。
   引擎 → 宿主方向仍走 `--env-out` + `apply-env-delta`（`!export` 之后宿主看得到）。

**P0 遗留一并修掉**：

- `$*PROGRAM` 在脚本模式指向脚本本身（`$SOURCE-FILE` P0 已接线，本次补回归断言）。
- 报错带真实位置 `文件:行号`：编译期异常身上的 `.line` 是**拼接后 EVAL 源码**的行号，
  新增 `error-location()` 过一遍 `remap-line` 再渲染。`.file` 一律不用 ——
  MoarVM 给的是 `EVAL_0` 这种内部临时名。

**顺手修的两个真 bug**（都是"只在测试里才炸"的类型）：

- `expand-arg` 里 `<[A..Z a..z 0..9 _]>` 在 MoarVM 上只吃到首字母
  （`$RK_DEBUG` 只捕获 `R`）→ 换 `(\w+)`。
- `type-of` 写成 `$*ENV<PATH>` → 那是**标量**动态变量，根本不存在，
  抛 "Dynamic variable $*ENV not found"；正确写法 `%*ENV<PATH>`。

**已知限制（留给 P3）**：

- `%*ENV` 是 Rakudo 的特殊容器，`:delete` 之后槽位残留 `Any`（`:exists` 已是 False）。
  用户对未设置变量直接字符串化（`"$x" ~ %*ENV<GONE>`）会触发 Rakudo 的
  "Use of uninitialized value ... Any" 警告，并带一条 `in block at EVAL_n` 回溯尾巴 ——
  这是 Rakudo 的警告格式，尚未美化。写 `(%*ENV<GONE> // '')` 即无警告。
- `alias` 不参与制表符补全（补全仍按 PATH / 内建表扫）。→ **P3 已修**：别名进 `!` 首词与 `run` 首参候选。

---

---

## 7. P3：补全与 DSL 糖（已落地 0.14.0）

### 7.1 目标

到 P2 为止「能不能用」已经不是问题，剩下的全是**手感**问题：

1. 补全只认 PATH 里的可执行文件 —— `!cd` / `!export` / `!myalias` 敲一半按 TAB 没反应。
   而这些恰恰是 P2 刚归到宿主的、用户最常敲的词。
2. `run` 的首个参数是命令名，补全却给 Raku 变量 / 关键字；就算补对了，补出来的裸词
   （`run ls`）在 Raku 里根本不是命令名，还得手动加引号。
3. 给命令喂 stdin 只能 `echo x | cmd`（多一层管道、多一次 fork），表达式里没处下手。
4. `ls` 类输出拿到手是一坨文本，想当路径用还得 `.lines».IO`；REPL 里 `run 'ls'`
   只回一句 `Result(code=0 · 12 行 · …)`，用户想看的是那份文件列表。

### 7.2 设计

**补全（Loop）**

- `shell-command-names()` 的结果按 **PATH 串**缓存（`%CMD-CACHE`）：补全每敲一个字符
  就调一次，PATH 里常有几千个可执行文件，逐个 `stat` 是主要卡顿源。键用 PATH 串 ⇒
  `export PATH=…` 之后键变了，缓存自动失效，不需要额外的失效钩子。
- 新增 `command-candidates()` = PATH 命令 + `builtin-names()` + `%ALIASES.keys`（去重保序）。
  `!` 行首与 `run` 首参共用这一份 —— 内建与别名不在 PATH 里，但它们确实能当命令敲。
- drvfs 例外：WSL 默认把 Windows 的 PATH 追加进来，而 drvfs 上**每个**文件都报 `+x`，
  只看可执行位会把几千个 `.dll` / `.json` 当成命令。所以 `/mnt/` 下的目录改按扩展名
  判定（空 / `exe` / `bat` / `cmd` / `com`），原生 Linux 目录照旧看 `+x`。
- `run-arg-kind($rest)`：只看光标**之前**的文本，判当前词在 `run` 的什么位置 ——
  `cmd`（首个参数，补命令名）/ `arg`（首参之后，只补路径）/ `''`（不在 run 参数里）。
  括号形式按「括号里有没有逗号」判位置。
- `run` 首参的候选**一律补成带引号形式**（借 `is-path` 这条「插入前要引号」的通道）：
  Raku 里 `run ls` 会被当成例程调用，裸词是错的。

**糖（Result / Eval / Loop）**

- `run(*@args, :$in)`：`$in` 是喂给 stdin 的**字符串正文**。
  shell 行形式 → 引擎新增的 `:stdin`（临时文件 + `< file` 重定向）；
  argv 形式 → 临时文件 + `CORE::run(:in($fh))`（原生 `:in` 只收句柄或 Bool）。
  两条链路都在 `await` 之后删临时文件。
- `Result.paths`：输出按行 `.IO`，空行丢弃，相对路径**保持相对**（按当前 CWD 解析，
  与 shell 里敲的一致）。
- 裸 `run` 展示：`bare-run-src($src)` 在**源码**上判定（`my $r = run …` / `say run …`
  这类「要的是对象」的场合不受影响），命中则用 `render-result-out` 渲染 `.out`
  （多行缩进两格）/ `(无输出)` / 单独一行 `stderr:` / `[退出码 N]`。
  脚本模式不受影响：`say-ui` 在脚本模式下被静音，不会自动打印值。

### 7.3 验收

- `t/46-rdsl-sugar.t`（13 条）：`:in` 的 argv / shell 行 / `run-pipe` 三路、`:in("")`
  与「不传」区分、临时文件不残留、`.paths` 的空行与相对形态。
- `t/47-run-display.t`（15 条）：`bare-run-src` 七种边界、`render-result-out` 五种形态，
  外加 drive 级集成 —— 裸 `run` 出现命令输出且**不**出现 `Result(`，赋值则反过来。
- `t/48-complete-p3.t`（17 条）：候选合并与去重、别名进候选、`run-arg-kind` 六种位置、
  `run` 首参补全带引号、缓存按 PATH 串失效。
- 全套 48 个 `.t`、**2552 条断言**，`bash tools/run-all.sh` 问题总数 0。

### 7.4 落地记录（0.14.0）

| 文件 | 改动 |
| --- | --- |
| `lib/Rakuish/Shell/Engine.rakumod` | `run-engine` 增加 `Str :$stdin`：写临时文件并以 `:in($fh)` 交给 `sh`（capture 与直通两路都处理） |
| `lib/Rakuish/Result.rakumod` | `run` 加 `:$in`（两种链路）、新增 `method paths`、`run-pipe` 透传 `:in` |
| `lib/Rakuish/Builtins.rakumod` | 导出 `builtin-names()`（补全要用） |
| `lib/Rakuish/Loop.rakumod` | PATH 缓存 + `command-candidates` + `run-arg-kind` + `run` 首参补全分支 + 裸 run 展示分派 |
| `lib/Rakuish/Eval.rakumod` | `bare-run-src()` 与 `render-result-out()` |

三处偏差（原计划没写到的）：

1. **括号形式怎么判「填到第几个」**：原本想按内部空格数，实测 `run('ls', '/t`
   里没有空格却已经是第二个参数 ⇒ 改成看逗号。代价：引号里的逗号会误判成 `arg`
   （那一格少补命令名，多补路径），可接受。
2. **drvfs 扩展名白名单**：本机是 WSL，实测补全列表里冒出 `lsaadt.dll` / `*.json` ——
   不做这层过滤，P3 的「PATH 补全」在 WSL 上等于给用户塞几千条垃圾。
3. **`:in("")` 必须与「不传」分开**：一开始打算 `$in.defined` 一把梭，测试里用
   `run 'cat', :in('')` 当探针才发现语义差别（空 stdin vs 继承终端会挂住）。

同时消掉 P2 的一条已知限制：`alias` 现在进 `!` 首词与 `run` 首参候选。

### 7.5 已知限制（P3 明确不做）

- `:in` 只收字符串；要传句柄 / 走原生 `Proc`，显式 `my &cr = &CORE::run`。
- 不做子命令级补全（`git ch<TAB>`）：那需要每个命令自己的 schema，属于「不追 bash」范畴。
- 补全列表的宽字符对齐仍按字符数算（既有问题，与本阶段无关）。

---

### 7.6 落地记录（0.15.0 / P4 脚本正确性）

真实脚本压测（`tools/stress.sh`）暴露的 G1/G2 两条，本阶段修完；G3 记入 P5。

| 文件 | 改动 |
| --- | --- |
| `lib/Rakuish/Incomplete.rakumod` | quote 帧支持**同种括号嵌套**：`q{...}` 里再遇到 `{` 就压一层，`}` 逐层收（原来遇第一个 `}` 就闭，awk 脚本必挂） |
| `lib/Rakuish/Loop.rakumod` | 新增导出 `else-capable-block` / `is-else-continuation`；`:script` 下块尾 `}` 属 `if/unless/with/without` 时探一行，续行合并、非续行**推回缓冲区**（`$pending-line`，行号不重算）；EOF 时块未闭合 → `report-script-incomplete` 打 `文件:行号: …` 并 exit 2 |
| `t/49-p4-cells.t` | 23 条断言：7 条判定函数单测 + 16 条真实子进程（G1 三个最小样例、跨行 if/else、elsif 链不吞行、`q{}` 嵌套、两种未闭合形态 rc=2 带行号、EOF 前 if 块不被吞） |

stress 复测 9/10；剩下 05 是 G3（整份缓冲重复 EVAL → 副作用重复执行），与 cell 切分无关。

两处偏差：

1. **`else` 探测只能用在 `:script`**：REPL 的 `read-line` 是阻塞的，交互式仍维持"`}` 收尾立即执行"。
2. **`elsif` 不能当"已合过 else"**：一开始把 `elsif` 和 `else` 都当终点，`if/elsif/else`
   三段式里 `else` 又单飞；只有**裸 `else`**才算终点。

### 7.7 落地记录（0.16.0 / P5-1 整文件一次编译）

| 文件 | 改动 |
| --- | --- |
| `lib/Rakuish/Script.rakumod` | 新增：读满整份文件 → `assemble` 拼单一编译单元 → `eval-program` 一次 `EVAL`；恢复 `use v6.d` / `class` / `sub MAIN` / heredoc / `END` 语义；出错按 `文件:行号` 写 stderr |
| `lib/Rakuish/Eval.rakumod` | `eval-program` 增 `:&cell-hook`，注入 `$*RAKUISH-CELL-HOOK`，替代包限定名直调 |
| `lib/Rakuish/Loop.rakumod` | `run-script` 传 `:cell-hook(&__script-cell__)`；脚本模式不再逐格 `drive` |
| `t/50-p5-script.t` | 新增 12 条进程级断言：副作用不重放、rename 幂等、O(n) 耗时、文件级语义、编译期错误零输出 |
| `t/43-script.t`、`t/49-p4-cells.t` | 断言按"整文件一次编译"改写（编译期错误整份不执行；运行期错误保留前输出） |

全量 `prove -e raku -Ilib t/`：53 文件 / **789 条断言 / 0 失败**；stress 10/10 符合预期。
> ⚠ 这行在 0.16.0 写下时是**不准**的：当时 `prove` 因 4 个 `.t` 缺顶层 plan 判 FAIL，
> stress 也不是 10/10（05 的判定标记写错）。两者到 **0.16.2** 才真正成立，见 HANDOFF §7.10。

> **0.16.4 补充**：脚本模式现在**按 shebang 选解释器**（**G5 落地**）——
> `rakuish run x.sh` 走 bash / python3，不再当 Raku 求值（报 `Two terms in a row`）；
> Raku 系 shebang 仍走 Raku，既有行为不变。回归 `t/52-script-shebang.t`，
> 详见 HANDOFF §7.12。

两处踩坑（写这类测试必撞）：

1. **双引号字符串里的 `{ ... }` 是闭包插值**，会当场执行并把返回值插进去——拼源码时
   `END { say 'x' }` 必须用 `q{}` 包，否则源码变成 `END True`，而副作用已经打到真 stdout。
2. **单引号里 `
` 不是换行**（就是反斜杠 + n），多行脚本会被压成一行 → 语法错误。
   本轮 t/50、t/43 各因此假失败一次。

---

## 8. 不做清单（写死，避免再次跑偏）

1. 不再实现任何新的 bash 内建 / bash 语法（`$SH-BUILTINS` 黑名单只缩不增）。
2. `%shell native` 的语法层冻结；新增 bash 语义需求 → 让用户用 `%shell bash`。
3. 不追 `set -e` / `trap` / bash 函数 / 数组语法。
4. 不再为「bash 边角」写对拍用例；新用例只覆盖 L2 的 DSL 行为。
   既有 `diff-cases/` 用例保留做回归（防止 L1 退化）。
   ⚠ **例外（0.17.0 起）**：native 后端的**对齐矩阵**（`tools/diff-cases/native-matrix.txt`）
   是「**防 native 退化**」的回归，不是给 bash 边角加新用例——
   它把「不支持」也变成了可回归的断言（退出码 2 + 「不支持」）。

---

## 9. 里程碑

| 阶段 | 内容 | 状态 |
| --- | --- | --- |
| P0 | 脚本模式 + shebang + 出错即停 | **完成** |
| P1 | `Rakuish::Result` + `run` / `run-pipe` | **完成**（0.12.0）|
| P2 | 内建归宿主 + env 双向同步 + `$*PROGRAM`（0.13.0） | **完成** |
| P3 | 补全 + DSL 糖（0.14.0） | **完成** |
| P4 | 脚本正确性：cell 切分 + 不静默终止（0.15.0） | **完成** |
| P5-1 | 脚本模式整文件一次编译（0.16.0） | **完成** |
| P6 | native 后端语义对齐矩阵（+ unsupported 机制固化）（0.17.0） | **完成** |
