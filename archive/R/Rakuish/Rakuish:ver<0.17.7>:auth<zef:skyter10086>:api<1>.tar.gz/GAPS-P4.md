# GAPS-P4.md — 0.14.0 真实脚本压测与 bash 语法缺口清单

- 压测对象：Rakuish 0.14.0（commit c5d8196，t/ 48 个 .t / 2552 断言全绿）
- 压测日期：2026-11-03
- 复现工具：`tools/stress.sh`（v2）、`tools/bash-parity.sh`
- 复现命令：
  ```bash
  export PATH=/home/zby/.rakubrew/versions/moar-2026.09/install/bin:$PATH
  bash tools/stress.sh          # 10 个真实脚本
  bash tools/bash-parity.sh     # 20 条 bash 构造对拍
  ```

---

## 0. 结论摘要

1. **10 个真实脚本 0 个全绿**，且根因高度收敛：**10 个脚本全栽在同一个 bug 上——多行块内出现花括号**
   （字符串插值 `{...}`、哈希下标 `%h{...}`）。
2. 该 bug 有三种表现，最危险的是**静默终止**：`rc=0`、stdout 空、stderr 空，看起来像"成功"。
3. bash 兼容层（`!` 前缀）的**单行能力 20/20 与真 bash 对拍一致**，缺口不在"支持哪些语法"，而在**跨行结构**（if/then/fi、for/do/done、函数体、heredoc）。
4. 因此 P4 第一优先级**不是扩 bash 语法**，而是：**修 cell 切分器 + 禁止静默失败**（P4-1 / P4-2）。

---

## 1. 压测结果（tools/stress.sh v2）

v2 相对原 runner 增加两道"假通过"防线：`MINLINES`（行数下限）+ `REQUIRED`（终态标记）。

| 脚本 | rc | 行数 | 字节 | 判定 | 根因 |
|---|---|---|---|---|---|
| 01-disk-report | 0 | 23 | 1427 | 部分成功 | 尾部 `if @hot.elems { say "告警…{+@hot}…" }` 块被吞（无『告警/全部』行） |
| 02-log-cleanup | 0 | 0 | 0 | **静默终止** | 块内 `"line {$_}\n"` |
| 03-csv-summary | 1 | 1 | 28 | Missing block | 块内 `%by{@c[0]}` |
| 04-json-report | 1 | 3 | 85 | Missing block | 块内 `%per-svc{%b<svc>}` |
| 05-batch-rename | 0 | 2 | 62 | **静默终止** | 块内 `"{$i}.txt"` |
| 06-backup-rotate | 0 | 0 | 0 | **静默终止** | 块内插值 |
| 07-grep-replace | 0 | 0 | 0 | **静默终止** | 块内插值 |
| 08-port-audit | 1 | 0 | 0 | Missing block | `for $r.lines -> $l {` 体内花括号 |
| 09-env-guard | 0 | 7 | 241 | 退出码不符（期望 3） | `if @errors { ... }` 块后半段崩 |
| 10-pipeline-glue | 0 | 0 | 0 | **静默终止** | 块内插值 |

统计：真跑通 0 / 部分成功 1（01 尾部块被吞）/ 输出不全 1（09）/ 静默终止 5 / Missing block 3。

> 说明：这 10 个脚本刻意保持"真人会写的写法"（块内插值、哈希下标），**不为 bug 让路**。修完 P4-1 后用同一批脚本复测，才是有意义的回归基线。

---

## 2. 引擎缺口清单（按严重度）

### G1【P0】块内花括号破坏 cell —— 真实脚本 10/10 命中

最小复现：

```raku
# z1：块内字符串插值 → 静默终止（rc=0，无任何输出，连块后的 say 也不执行）
for 1..2 -> $i {
    say "v={$i}";
}
say 'Z1';

# z2：块内哈希下标 → 运行时错误
my %h;
for 1..2 -> $i {
    %h{$i} = $i * 10;
}
say 'Z2';

# z6：块内插值 + for 变量 → 静默终止
my @a = <x y>;
for @a -> $e {
    say "e={$e}";
}
```

对照组（全部正常）：

| 写法 | 结果 |
|---|---|
| 块内 `say "v=" ~ $i`（拼接，无花括号） | 正常 |
| 顶层 `my $s = "a-{1+1}"`（块外插值） | 正常 |
| `if %h.elems > 0 { ... }`（块内无花括号） | 正常 |
| `do for @a -> $e { "x-" ~ $e }`（单行块） | 正常 |
| `@rows.map({ $_.sum })`（顶层闭包） | 正常 |

成因推断：cell 完整性/切分按**花括号计数**判断，未区分「代码块 `{`」「字符串内插值 `{}`」「哈希下标 `%h{}`」，块内一出现花括号，cell 边界就判错——结局取决于切在哪儿：切坏了 → `Missing block`；切成空 cell → 静默跳过。

规避写法（当前可写脚本用）：

| 场景 | 不要写 | 改写成 |
|---|---|---|
| 块内拼字符串 | `"a-{$i}.log"` | `"a-" ~ $i ~ ".log"` |
| 块内写哈希 | `%h{$i} = $v` | `%h.push: $i => $v` |
| 块内读哈希 | `%h{$k}` | 块外先 `my $v = %h{$k}` 再进块 |
| 遍历哈希键 | `for %h.keys -> $k { ... }` | `my @k = %h.keys.sort; for @k -> $k { ... }` |

修复建议：
1. 判定 cell 完整性改用 `raku -c` 试编译（或至少做「字符串/注释/正则」状态机，跳过引号内、`#` 后的花括号）；
2. 补 3 条 .t 回归，直接落 z1 / z2 / z6 三个最小样例；
3. 修好后用 stress 10 个脚本原样复测。

### G2【P0】静默终止零诊断

`rc=0` + stdout 空 + stderr 空 = 用户完全无法感知脚本被吞掉。5 个脚本踩中，且 runner 若不查行数会全部误判为通过。
要求：解析不出可执行语句、或 cell 被判定不完整时，**必须报错并给行号**，禁止静默跳过。

### G3【P1】句级求值语义

`END` / `LEAVE` 在每个 cell 结束就触发（scripts 里已改成显式收尾）。建议脚本模式支持"整文件一次求值"，或提供 Rakuish 自己的 `on-exit` 钩子替代 `END`。

### G4【P1】跨 cell 声明

- 多行 `class` 定义跨 cell 失败（需单行写完）
- `use v6.d` 出现在非首句失败
- `MAIN` 未触发（脚本参数无法自动分发）
- `die` 输出带 REPL 装饰（`错误 · 运行时错误` 前缀、`提示: 错误只影响这一个 cell…`），脚本模式下应退回纯 stderr + 退出码

### G5【P1】shebang 未参与后端选择

`bin/rakuish x.sh`（`#!/bin/bash`）仍走 Raku 求值 → `Undeclared routines: echo`。
`Slow.rakumod` 里已有 shebang→后端 的规则，但 `bin/rakuish <file>` 路径没接上。
期望：`#!/bin/bash` 的 .sh 直接交给 bash 执行，`#!/usr/bin/env -S rakuish` 走脚本模式。

---

## 3. bash 兼容层对拍（tools/bash-parity.sh）

### 3.1 单行构造：20/20 与真 bash 一致

变量赋值与 `${x:-默认}`、`$( )` 命令替换、管道（sort/uniq/head）、重定向 `>` `>>` `<`、`for ... do ... done`（单行）、`while read ... done < f`（单行）、`[ ]` / `[[ ]]`、`case esac`（单行）、函数定义（单行）、`$(( ))` 算术、数组 `${arr[@]}`、花括号展开 `{a,b}.txt`、子 shell `( cd x && pwd )`、`xargs`、`export`（跨进程可见）、`set -e`、`local`、`$?`、`&&` / `||`。

### 3.2 跨行结构：4/4 失败（这是真正的 bash 缺口）

| 构造 | 跨行写法结果 | 现象 |
|---|---|---|
| `if ... then ... fi` | 失败 | 三行各自独立丢给 bash，`then` 行 exit 2，`fi` 行 exit 2，条件体被当独立命令执行 |
| `for ... do ... done` | 失败 | 循环变量在后续行丢失（`f=` 空） |
| 函数体 `f() { ... }` | 失败 | `{` 行 exit 2，调用行 exit 127 |
| heredoc `<<EOT ... EOT` | 失败 | 整段静默吞掉，无输出无报错 |

每条 `!` 行当前都是**独立一次 bash 调用**，所以跨行结构天然拼不起来。
建议 P4-3：`!` 行以 `then` / `do` / `{` / `<<X` 结尾时进入"收集模式"，直到匹配的 `fi` / `done` / `}` / `X`——交互式那边已有 heredoc 收集逻辑（`Loop.rakumod`），脚本模式复用即可。

### 3.3 顺带确认

- `!` 行内多条语句（`;` 串联）正常，所以**单行 bash 足以覆盖大部分日常脚本**，跨行属于体验缺口而非能力缺口。
- `!` 命令失败会 `exit N` 并打印〔…〕摘要，脚本整体 rc 跟随，语义正确。

---

## 4. P4 任务建议（按序，附验收）

| 序号 | 任务 | 验收标准 |
|---|---|---|
| P4-1 | 修 G1：cell 切分/完整性不受块内花括号影响 | z1/z2/z6 三个最小样例各 1 条 .t；stress 10 脚本原样复测 ≥ 8 全绿 |
| P4-2 | 修 G2：静默终止一律报错带行号 | 构造空 cell / 残块用例，断言 rc≠0 且含行号 |
| P4-3 | `!` 跨行块收集（if/for/while/函数/heredoc） | bash-parity 补 4 条跨行用例，一致数从 20 升到 24 |
| P4-4 | shebang 后端调度（`#!/bin/bash` → bash） | `bin/rakuish x.sh` 与直接 `bash x.sh` 输出一致 |
| P4-5 | 文档：脚本模式三条硬约束 + 本文档链接 | README「脚本模式」节补约束表；PLAN-C §9 记 P4 |

**判断依据**：P4-1/P4-2 是"能不不能用"的问题（影响 9/10 真实脚本），P4-3/P4-4 是"顺不顺手"的问题。先修正确性，再谈兼容面。

---

## 5. 本次新增/变更的工程件

- `tools/stress.sh` → v2：新增 `MINLINES` / `REQUIRED`，堵住"静默终止冒充通过"；每个脚本独立沙箱 `TMPDIR=$OUTDIR/sand/<脚本名>`（v2 初版里一句 `rm -rf /tmp/rk-stress-*` 会连自己的 OUTDIR 一起删掉，导致 10 个脚本全部"rc=1 + 0 行"的假失败，已修，别在循环里清通配目录）
- `tools/bash-parity.sh` → 新增：20 条 bash 构造（单行 + 片段）逐条与真 bash 对拍 rc + stdout
- `stress/*.rakuish` → 10 个真实脚本保持原写法，作为 P4-1 的复测基线（不改造成"能跑"的样子）

---

## 6. P4-1 / P4-2 落地记录（0.15.0）

> 复测：`bash tools/stress.sh` → **通过 9 / 失败 1**（P4 前是 5/5）。
> 全量回归：`prove -e raku -Ilib t/` → 49 个 .t，714 条断言，0 失败。

### 6.1 P4-1 到底错在哪（三处，逐条对应现象）

| # | 病灶 | 现象 | 修法 |
|---|---|---|---|
| 1 | 括号当引号分隔符的 `q{...}` / `qq(...)` **没有数嵌套层** | `q{awk '{ a += 1 } END { b }'}` 被内层第一个 `}` 提前闭合，之后整段错位 → 文件读完还"没写完" | `Incomplete.rakumod` 的 quote 帧：遇到与 `want` 配对的**开括号**就压一层同样的 quote 帧 |
| 2 | cell 收在 `}` 上时**无法判断后面还有没有 `else`** | 跨行 `if {...}` + `else {...}` 的第二格单飞，报 `Undeclared routine: else` | `Loop.rakumod` 对 `if/unless/with/without` 收尾的格**向前探一行**：是 `else/elsif/catch/...` 就合并，不是就**推回缓冲区**（`$pending-line`）留给下一轮 |
| 3 | 探测/续行读进来的行会**丢行号**或**被吞** | 行号错位、`tail` 那一行消失 | 探测器统一 `$line-no++`，推回时置 `$from-pending` 跳过再次自增 |

`else-capable-block` / `is-else-continuation` 两个判定都 `is export`，单测直接打（`t/49-p4-cells.t` 前 7 条）。

### 6.2 三个 G1 最小样例（各 1 条 .t）

- `for 1..3 -> $i { say "v={$i}" }` 多行式 → `v=1/v=2/v=3`
- `for 1..2 -> $i { %h{$i} = $i * 10 }` → `%h{1} + %h{2}` == 30
- `for @a -> $e { say "e={$e}" }` 单行式 → `e=x/e=y`

### 6.3 P4-2（静默终止）已收口

`drive` 在 `:script` 模式下，块没收完就 EOF 时**不再**打一句"已取消"然后 `next`，而是
`report-script-incomplete` 打 `文件:行号: 文件结束时输入还没写完（块或引号没有闭合）；未闭合：X`，
退出码 **2**（对齐 bash 的语法错误）。`t/49-p4-cells.t` 8/9 两条断言 `rc=2` + 行号 + 无假输出。

### 6.4 stress 复测：9/10 全绿，剩下 1 个是新缺口（不是 P4-1/P4-2）

| 脚本 | 结果 | 说明 |
|---|---|---|
| 01/02/03/04/06/07/08/09/10 | ok | 02 的跨行 `if/else`、10 的 `q{}` + awk 都是本轮修好的 |
| 05-batch-rename | 缺终态标记 | **G3：整文件重放**（见下）——不是 cell 切分问题 |

压测脚本自身也修了 3 处**真语法错误**（官方 raku 一样编不过，不是引擎让它过的）：

- `06:57` `{$keep.elems}` → `{@keep.elems}`（`$keep` 未声明）
- `10:27` awk 脚本写在双引号里（`{...}` 被当 Raku 代码块插值）→ 拆成 `q{...}` 拼接
- `10:47` `\"` 在 `"..."` 的 `{...}` 里不是 Raku 转义 → 整段 awk 放 `q{}`

### 6.5 新缺口 G3（P5 第一位）：整份缓冲重复 EVAL

`05` 失败与 G1 无关。`Eval.rakumod:136` 的设计是：每个 cell 都**把整份缓冲重新 EVAL 一遍**，
靠"重跑一遍就看得到前面的 `my`"来支持跨格变量（输出被抑制，所以肉眼看不出重复）。

问题在于**输出抑制了，副作用没抑制**。用一份带日志的探针脚本实测（每格往同一文件 append 一行）：

```
A                     ← 第 1 格
A B                   ← 第 2 格（A 又跑了一次）
A B C                 ← 第 3 格
A B C D-in-if         ← 第 4 格
A B C D-in-if E ...
```

每格都从头重跑，日志长度按 `1+2+…+n` 增长。后果两条：

1. **带副作用的脚本必然错**：`spurt` / `mkdir` / `rename` / `unlink` 在每一格再执行一次。
   05 就是"造了 alpha.txt → 循环里改名成 alpha.md → 下一格的重新 EVAL 又把 alpha.txt 造回来"，
   于是"剩余 .txt: 3"、幂等检查 `unexpected`；循环本身也被重跑，第二遍才会打出"目标已存在，跳过"。
2. **耗时约 O(n²)**：10-pipeline-glue 从 9s 涨到 90s 量级。

顺带一个小 bug：抑制输出时偶发漏出一截尾巴（`exp.rakuish` 里多打一行 `.txt`），说明抑制边界
没做干净，建议一并修。

修法只有一条，不该靠改脚本绕：**脚本模式整文件一次 EVAL，不再逐格重放**（REPL 保留重放）。
改动集中在 `Loop.rakumod` 的 `drive`：`:script` 时先把 `read-line` 读满整个文件、一次性走
`eval-cell`，旁路掉逐格渲染 / `In[n]` / 重放三条 REPL 专属逻辑。**建议列为 P5-1**。

#### 6.5.1 已修（0.16.0 / P5-1）

实装：新增 `Rakuish::Script`（读满整份文件 → `assemble` 拼编译单元 → 一次 `eval-program`），
`bin/rakuish run` 走这条路径，不再进 REPL 的逐格 `drive`。

顺带解决一个符号可见性问题：shell 格回调宿主时，原先写死
`Rakuish::Loop::__script-cell__(...)` 这种包限定名，在 `EVAL` 单元里 `Stash.AT-KEY` 查不到
（`Could not find symbol '&__script-cell__' in 'Rakuish::Loop'`）；改为
`eval-program(:&cell-hook)` 把 hook 注入成动态变量 `$*RAKUISH-CELL-HOOK`，脚本里生成
`$*RAKUISH-CELL-HOOK(...)` 调用。

语义变化（刻意的，对齐 `raku` / bash）：

| 情形 | 修前（逐格重放） | 修后（整文件一次编译） |
| --- | --- | --- |
| 编译期错误（`foo bar baz`） | 前面的格已执行，留下半截输出 | **一行都不执行**，rc 非 0 |
| 运行期错误（`die`） | 保留前面输出 | 保留前面输出（不变） |
| `spurt` / `rename` / `unlink` 副作用 | 每格重跑一次 | 只跑一次 |
| `use v6.d` / `class` / `sub MAIN` / heredoc / `END` | 全部失效 | 正常 |

证据：`t/50-p5-script.t` 12 条进程级断言（5 格 append 正好 5 行、`mkdir`+`touch` 幂等、
rename 后源文件不被重建、40 格 append 正好 40 行、`use v6.d`+heredoc+`END`、编译期错误零输出）；
`t/43-script.t` 按新语义改写（plan 13→16）；stress **10/10 符合预期**，05 从「故意失败」变真通过。
> ⚠ **补注（0.16.2）**：05 的*功能*当时确实通过了，但 `tools/stress.sh` 的判定标记
> 写的是 `改名校验` —— 而脚本从来只打印 `改名成功` ⇒ harness 恒判失败、压测恒为 9/10。
> 标记直到 0.16.2 才修对，见 HANDOFF §7.10。

### 6.6 顺带发现（REPL 语义对齐）

官方 `raku` REPL 对"整块收尾"的输入是**等下一行**再执行的（`if 1 { say "A" }` 单独一行
在 EOF 时照样输出 A）。本轮 `else` 探测就是按这个语义做的，只对 `if/unless/with/without`
生效——`for`/`while` 没有 `else` 分支，仍然立即执行，不拖一拍。
