use lib 'lib';
use Test;
use Rakuish::Loop;
use Rakuish::Shell::Engine;
use Rakuish::Shell::Session;

# t/42-shell-engine.t —— **shell 引擎**（独立进程）与 REPL 的对接
#
# 这一层是 2026-11-05 架构转向的产物：
#
#   REPL（Raku 进程）  ──① 命令 / env / $?──▶  引擎（独立进程）
#                     ◀──② stdout / stderr / 退出码 / 环境──
#
# 覆盖：
#
#   ① **协议**（编解码往返）
#   ② 引擎客户端：`run-engine` 的输出 / 退出码
#   ③ **会话变量跨格存活**（引擎回传环境 ⇒ REPL 求差 ⇒ 更新会话表）
#   ④ **`$?` 跨格存活**
#   ⑤ **bash 语义**（brace 展开 / 算术 / 参数展开 / 管道 / 重定向）
#   ⑥ REPL 的三个 shell 入口（`!` / 反引号 / 自动回退）都走引擎
#   ⑦ `%shell` 切换引擎
#   ⑧ heredoc 穿过引擎
#
# ⚠ 期望值来自**真 bash 5.3.9**（不是我们的实现）——
#   默认后端就是 bash，所以这些断言同时也是「引擎接对了」的验收。
#
# ⚠ 为什么大部分断言用 `run-engine(..., :capture(True))` 而不是走 REPL：
#   REPL 的 `!cmd` 是**直通**模式（输出直接写终端，保留流式与 ANSI），
#   抓不到 ⇒ 要断言输出内容就走捕获模式。

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method print(*@a)      { @.lines.push: @a.join; Nil }
    method flush()         { }
}

# 跑一行（走 REPL 的完整分发），返回捕获到的输出
sub run1(Str $line --> Str) {
    my $s = Sink.new;
    { temp $*OUT = $s; drive(reader-from($line), :color(False)); }
    $s.lines.join("\n")
}

# 跑多行（同一场会话里 —— 会话变量要跨格存活）
sub runN(*@lines --> Str) {
    my $s = Sink.new;
    { temp $*OUT = $s; drive(reader-from(@lines), :color(False)); }
    $s.lines.join("\n")
}

# 走引擎跑一行，取 stdout（去尾部换行）
sub eng-out(Str $line --> Str) {
    my $r = run-engine($line, :capture(True));
    $r.stdout.Str.trim
}

# ══════════════════════════════════════════════════════════════════════
# ① 协议
# ══════════════════════════════════════════════════════════════════════

subtest "协议：编解码往返", {
    my $enc = encode-input('echo hi', {});
    is decode-input($enc)<cmd>, 'echo hi', '命令文本还原';

    my $enc2 = encode-input('cat <<EOF', {'EOF' => "hello\n"});
    my $in2 = decode-input($enc2);
    is $in2<cmd>, 'cat <<EOF', '命令文本还原（带 heredoc）';
    is $in2<bodies><EOF>, "hello\n", 'heredoc 正文还原';

    # 空正文也要能编码/解码（`cat <<EOF` 后面直接 EOF）
    my $enc3 = encode-input('cat <<EOF', {'EOF' => q{}});
    my $in3 = decode-input($enc3);
    is $in3<bodies><EOF>, q{}, '空正文还原';
}

subtest "引擎可执行文件在", {
    ok engine-path().IO.e, '引擎 CLI 存在（bin/rakuish-sh）';
    ok engine-path().ends-with('rakuish-sh'), '路径指向 rakuish-sh';
}

# ⚠ 回归：zef / raku-pm 把**模块源码**放在 `<安装前缀>/sources/<HASH>`，
#   不是 `<前缀>/lib/Rakuish/...`。旧实现按 `$?FILE` 的父目录推算 ⇒ 安装后
#   得到 `~/bin/rakuish-sh`（不存在）⇒ 所有 `!cmd` exit 127。
subtest 'engine-path：安装布局（sources/<hash>）', {
    my $root = $*TMPDIR.add('rakuish-inst-' ~ $*PID);
    my $src  = $root.add('sources');
    my $bin  = $root.add('bin');
    $src.mkdir;
    $bin.mkdir;
    my $mf  = $src.add('HASH');
    my $exe = $bin.add('rakuish-sh');
    $mf.spurt(q{});
    $exe.spurt(q{});

    is engine-path(:module-file($mf.Str),
                   :program($root.add('cli').add('rakuish.raku').Str),
                   :path(q{}), :override(q{}), :repos([$root.Str])).Str,
       $exe.Str,
       '模块在 <prefix>/sources/<hash> ⇒ <prefix>/bin/rakuish-sh';

    is engine-path(:module-file($mf.Str),
                   :program($root.add('cli').add('rakuish.raku').Str),
                   :path($bin.Str), :override(q{}), :repos([])).Str,
       $exe.Str,
       '仓库里找不到时回退 PATH';

    is engine-path(:module-file($mf.Str),
                   :program('/no/such/rakuish.raku'),
                   :path($bin.Str), :override('/custom/rakuish-sh'),
                   :repos([$root.Str])).Str,
       '/custom/rakuish-sh',
       'RAKUISH_SH 显式覆盖优先';

    $mf.unlink;
    $exe.unlink;
    $src.rmdir;
    $bin.rmdir;
    $root.rmdir;
}

# ══════════════════════════════════════════════════════════════════════
# ② 引擎客户端
# ══════════════════════════════════════════════════════════════════════

subtest 'run-engine：输出与退出码', {
    is eng-out('echo hello-engine'), 'hello-engine', 'stdout 拿到了';
    my $r = run-engine('exit 7', :capture(True));
    is $r.code, 7, '退出码拿到了';
    my $r2 = run-engine('echo oops >&2', :capture(True));
    ok $r2.stderr.contains('oops'), 'stderr 拿到了';
}

# ══════════════════════════════════════════════════════════════════════
# ③ 会话变量跨格存活（靠引擎回传环境）
# ══════════════════════════════════════════════════════════════════════

subtest 'export 的值跨格存活', {
    run-engine('export RK_ENG=engine-value', :capture(True));
    # ⚠ **必须加引号**：`[$RK_ENG]` 展开成 `[engine-value]` 之后，
    #   bash 把它当**字符类**（e–v 区间）⇒ 会 glob 成目录里的同名文件
    #   （本仓库根目录就有 `t` 和 `v` 两个目录 ⇒ 输出变成 "t v"）。
    #   这不是 bug，是 bash 的真语义（我们自己的原生引擎也一样）。
    is eng-out('echo "[$RK_ENG]"'), '[engine-value]', '下一格读得到';
    is get-var('RK_ENG'), 'engine-value', '会话表里有';
    unset-var('RK_ENG');
}

subtest 'unset 跨格生效', {
    run-engine('export RK_ENG2=x', :capture(True));
    run-engine('unset RK_ENG2', :capture(True));
    is eng-out('echo "[$RK_ENG2]"'), '[]', 'unset 之后读不到';
    is get-var('RK_ENG2'), q{}, '会话表里也没了';
}

subtest '会话变量能传到子进程', {
    run-engine('export RK_ENG3=child-value', :capture(True));
    is eng-out('printenv RK_ENG3'), 'child-value', '子进程看到了';
    unset-var('RK_ENG3');
}

subtest 'export 与 && 同一条：后面的命令看得到', {
    # bash 语义：export 在**同一个 shell** 里跑，不是子 shell
    is eng-out('export RK_ENG4=1 && echo [$RK_ENG4]'), '[1]', '同一行里看得到';
}

# ══════════════════════════════════════════════════════════════════════
# ④ `$?` 跨格存活
# ══════════════════════════════════════════════════════════════════════

subtest '$? 是上一条命令的退出码', {
    run-engine('false', :capture(True));
    is eng-out('echo status=$?'), 'status=1', '失败 ⇒ 1';
    run-engine('true', :capture(True));
    is eng-out('echo status=$?'), 'status=0', '成功 ⇒ 0';
}

# ══════════════════════════════════════════════════════════════════════
# ⑤ 默认后端是 bash ⇒ bash 的语义一个都不少
# ══════════════════════════════════════════════════════════════════════

subtest 'bash 语义（默认后端）', {
    is $SHELL-BACKEND, 'bash', '默认后端是 bash';

    is eng-out('echo {a,b}'), 'a b', 'brace 展开';
    is eng-out('echo $((1+2))'), '3', '算术展开';
    is eng-out('echo ${RK_UNSET_ENG:-fallback}'), 'fallback', '参数展开（默认值）';
    is eng-out('echo hi | tr a-z A-Z'), 'HI', '管道';
    is eng-out('echo one > /tmp/rakuish-t42-out; cat /tmp/rakuish-t42-out'),
        'one', '重定向';
    is eng-out('echo $((2**10))'), '1024', 'bash 的幂优先级';
}

# ══════════════════════════════════════════════════════════════════════
# ⑥ REPL 的三个 shell 入口都走引擎
# ══════════════════════════════════════════════════════════════════════

subtest 'REPL 的 shell 入口都走引擎', {
    # 反引号：捕获 stdout 当值（这条能抓到输出 ✓）
    ok run1('`echo captured-value`').contains('captured-value'), '反引号捕获';

    # 自动回退：有 [shell] 标记 ⇒ 说明转交了（转交的那条路就是引擎）
    # `pwd` 在 P2 之后是宿主内建（不再走引擎），这里用真正的外部命令。
    my $o = run1('whoami');
    ok $o.contains('[shell]'), '自动回退有 [shell] 标记';
    ok !$o.contains('错误'), '没有 Raku 报错（说明确实转交了）';
}

# ══════════════════════════════════════════════════════════════════════
# ⑦ `%shell` 切换 shell 后端
# ══════════════════════════════════════════════════════════════════════

subtest '%shell 切换 shell 后端', {
    my $show = run1('%shell');
    ok $show.contains('bash'), '显示当前后端';
    ok $show.contains('不影响裸输入的 Raku 求值'), '说明 shell 后端不影响 Raku 求值';

    ok run1('%shell native').contains('native'), '切到 native 后端';
    is $SHELL-BACKEND, 'native', '变量真的改了';

    # native 后端也能跑普通命令
    is eng-out('echo via-raku-engine'), 'via-raku-engine', 'native 后端能跑命令';

    ok run1('%shell nope').contains('未知 shell 后端'), '未知后端给提示';

    ok run1('%engine').contains('已改名为'), '旧 %engine 提示改名（不执行切换）';

    run1('%shell bash');
    is $SHELL-BACKEND, 'bash', '切回 bash';
}

subtest 'native 后端：原生层的能力还在（不是被砍掉）', {
    run1('%shell native');
    is eng-out('echo {a,b}'), 'a b', 'brace 展开';
    is eng-out('echo $((1+2))'), '3', '算术展开';
    is eng-out('echo ${RK_UNSET_ENG:-fallback}'), 'fallback', '参数展开';
    is eng-out('echo hi | tr a-z A-Z'), 'HI', '管道';
    run1('%shell bash');
}

# ══════════════════════════════════════════════════════════════════════
# ⑧ heredoc 穿过引擎
# ══════════════════════════════════════════════════════════════════════

subtest 'heredoc 穿过引擎', {
    # 引擎层：正文由调用方给（REPL 侧是「接着读正文行」收集来的）
    my $r = run-engine('cat <<EOF', {'EOF' => "body-line\n"}, :capture(True));
    ok $r.stdout.contains('body-line'), 'heredoc 正文送到了命令';

    # REPL 层：REPL 会**接着读正文行**（直到结束行）⇒ 引擎拿到完整脚本文本。
    # ⚠ `!cmd` 是**直通**模式（输出直接写终端，抓不到）⇒ 用 `--numbers`
    #   走捕获模式。
    my $o = runN('! --numbers cat <<EOF', 'body-line2', 'EOF');
    ok $o.contains('body-line2'), 'REPL 收集的正文送到了命令';
}

# ══════════════════════════════════════════════════════════════════════
# ⑨ 逐行委托：`!@bash …` / `!@native …`
# ══════════════════════════════════════════════════════════════════════
#
# ⚠ 为什么需要「逐行委托」：
#   两个后端的语义**不完全一样**（native 后端还没实现 `cd` / 数组 / `[[ ]]`）。
#   但用户**不该**为了跑一条命令就去切默认后端 ⇒ 有了逐行前缀。
#
# ⚠ 为什么用 `@` 起头：shell 的命令名**不可能**以 `@` 开头
#   （bash 里 `@` 是数组下标操作符）⇒ 这个前缀不可能与真实命令冲突 ✓

subtest 'split-backend-prefix：前缀怎么切', {
    is split-backend-prefix('@bash echo hi').join('|'), 'bash|echo hi',
        '`@bash` ⇒ bash 后端';
    is split-backend-prefix('@native echo hi').join('|'), 'native|echo hi',
        '`@native` ⇒ native 后端';
    is split-backend-prefix('echo hi').join('|'), '|echo hi',
        '没有前缀 ⇒ 用当前后端（空串）';
    is split-backend-prefix('@bogus echo hi').join('|'), '|@bogus echo hi',
        '未知后端名 ⇒ **原样**（不能把 `@bogus` 当成命令名吃掉）';
}

subtest 'REPL 端到端：逐行委托', {
    # ⚠ `!cmd` 是**直通**模式（输出直接写终端）⇒ 要断言输出内容
    #   就用 `--numbers`（走捕获模式）。
    ok run1('! --numbers @bash echo from-bash').contains('from-bash'),
        '`!@bash` 走 bash 后端';
    ok run1('! --numbers @native echo from-raku').contains('from-raku'),
        '`!@native` 走 native 后端';

    # 反引号里也认前缀
    ok run1('`@native echo via-backtick`').contains('via-backtick'),
        '反引号里也认后端前缀';

    # ⚠ **逐行委托不改全局后端** —— 这是「逐行」的意义
    is $SHELL-BACKEND, 'bash', '逐行委托之后默认后端没变';
}

subtest 'native 后端不支持 ⇒ 退出码 2 + 委托提示', {
    # `cd` 是 shell 内建（native 后端还没实现）⇒ 明确报错，**不**偷偷交给 bash
    my $r = run-engine('cd /tmp && echo x', :capture(True), :backend('native'));
    is $r.code, 2, '退出码 2（bash 的语法错误码）';
    ok $r.stderr.contains('不支持'), '说清楚「不支持」';
    ok $r.stderr.contains('@bash'), '并给出委托办法';

    # ⚠ 同一个命令给 bash 后端 ⇒ **正常跑**（语义 100% 准）
    my $b = run-engine('cd /tmp && echo x', :capture(True), :backend('bash'));
    is $b.code, 0, 'bash 后端跑同一个命令 ⇒ 退出码 0';
    is $b.stdout.trim, 'x', '输出也对';

    # REPL 层：退出码非 0 ⇒ 摘要行里能看到 `exit 2`
    ok run1('! @native cd /tmp && echo x').contains('exit 2'),
        'REPL 层的摘要行报出退出码 2';
}

done-testing;
