use v6;
use lib 'lib';
use Test;
use Rakuish::Loop;
use Rakuish::Builtins;
use Rakuish::Shell::Session;

# P2：10 个高频 shell 内建归 REPL 宿主（C 方案 §6）
#
# 为什么必须归宿主：`cd` / `export` 改的是**会话状态**，而引擎是子进程 ——
# 子进程里 `cd` 只影响它自己，回不到 REPL。所以这些内建只能由宿主实现，
# 并且要和引擎共享同一份状态（env 靠 %*ENV 继承 + `--env-out` 回传，
# cwd 靠宿主自己的 $*CWD）。
#
# 这个文件测「宿主侧语义」：返回值、退出码、会话状态副作用。
# 「REPL 里敲一行会怎样」在 t/19（cd 那条链路）与本文件末尾的 drive 集成里测。
#
# ⚠ 全部是**平铺断言**，不用 subtest 分组：`Test` 的 subtest 在**新线程**里
#   跑块，而 `$*ENV` / `%*ENV` 这类动态变量在主线程之外拿不到（实测报
#   "Dynamic variable $*ENV not found"）—— 一进 subtest 就把被测代码炸了。

my $start = $*CWD.Str;

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}
sub run-capture(*@script, Bool :$color = False --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    drive(reader-from(@script), :$color);
    $sink
}

# ── 1. 白名单与边界 ────────────────────────────────────────────────
# ── 0.16.7（§10.1 #11）：read -p 提示语的去向与打印条件 ──────────
#
# 以前提示语写 **stdout** ⇒ `rakuish x.rakuish > out.txt` 时提示语进了
# 结果文件（bash 写的是 stderr）；且**不看 stdin 是不是终端**——
# bash 只在交互时打印（`printf 'x\n' | bash -c 'read -p "P: " v'` 不打印）。
# ⚠ 这里不能用 subtest：`$*IN` / `%*ENV` 这类动态变量在子线程里拿不到。
is read-prompt-text('P: ', False), q{},   '非 tty：不打印提示语（bash 语义）';
is read-prompt-text('P: ', True),  'P: ', 'tty：打印提示语';
is read-prompt-text(q{}, True),     q{},   '没提示语就不打印';

class ErrSink {
    has $.buf = q{};
    method print($s --> Nil) { $!buf ~= $s.Str; Nil }
    method say($s --> Nil)   { $!buf ~= $s.Str ~ "\n"; Nil }
    method text(--> Str)     { $!buf }
}

{
    my $fh = open('/dev/null');
    temp $*IN  = $fh;
    temp $*ERR = ErrSink.new;
    my %h = read-into('-p', 'P: ', 'v');
    is $*ERR.text, q{}, '非 tty 时提示语**不打印**（不进 stderr）';
    ok !(%h<out>.contains('P: ')), '提示语不进 stdout（输出里没有提示语）';
}

is builtin-name('cd /tmp'),        'cd',    'cd 归宿主';
is builtin-name('  pwd  '),        'pwd',   '前导空白不影响';
is builtin-name('export A=1'),     'export','export 归宿主';
is builtin-name('test -d /tmp'),   'test',  'test 归宿主';
is builtin-name('[ -d /tmp ]'),    '[',     '`[` 归宿主（`[` 不算元字符）';
is builtin-name('ls -l'),          q{},     '外部命令不归宿主';
is builtin-name('cd /tmp && ls'),  q{},     '有 && ⇒ 整行交引擎';
is builtin-name('cd $(pwd)'),      q{},     '命令替换 ⇒ 交引擎';
is builtin-name('echo hi > f'),    q{},     '重定向 ⇒ 交引擎';
is builtin-name('export A="x y"'), 'export','双引号里的空格不算元字符';

# ── 2. pwd / cd ────────────────────────────────────────────────────
is pwd(), $*CWD.absolute.Str, 'pwd 就是宿主的 cwd';

my %cd = cd-into('/tmp');
is %cd<code>, 0, 'cd /tmp 成功';
is $*CWD.Str, '/tmp', 'cwd 真的切了（宿主进程级）';
ok %cd<out>.contains('cd → /tmp'), '给人看的提示';
ok %cd<ui>, '这条输出标记为 ui（脚本模式静音）';
is %*ENV<PWD>, '/tmp', 'PWD 同步进 %*ENV（引擎继承得到）';

my %bad = cd-into('/no/such/dir/xyz');
is %bad<code>, 1, '不存在的目录 ⇒ 退出码 1';
ok %bad<err>.contains('没有这个目录'), '不存在的目录：给一句人话';

my %file = cd-into('/etc/hostname');
is %file<code>, 1, '文件不是目录 ⇒ 退出码 1';
ok %file<err>.contains('不是目录'), '说清楚是"不是目录"';

cd-into($start);
is $*CWD.Str, $start, 'cd 回到原目录';

# ── 3. export / unset（会话变量 + %*ENV 双向一致）────────────────
is export-vars('RK_T45=hello')<code>, 0, 'export 成功';
is lookup('RK_T45'), 'hello', '会话变量表里有';
is %*ENV<RK_T45>, 'hello', '%*ENV 里也有（引擎靠继承拿到）';

is unset-vars('RK_T45')<code>, 0, 'unset 成功';
is lookup('RK_T45'), q{}, '查表为空';
nok %*ENV<RK_T45>.defined, '%*ENV 里的也删了';

my %e = export-vars('1BAD=x');
is %e<code>, 1, '非法变量名 ⇒ 退出码 1';
ok %e<err>.contains('不是合法的变量名'), '说清楚哪里不对';

# `export NAME`（不带值）：把已有值导出，不能清空
%*ENV<RK_T45B> = 'inherited';
export-vars('RK_T45B');
is lookup('RK_T45B'), 'inherited', 'export 不带值不会清空已有值';
try { %*ENV<RK_T45B>:delete };

# ── 4. 字面量展开：~ 与 $VAR ───────────────────────────────────────
is expand-arg('~'), (%*ENV<HOME> // q{}), '~ ⇒ HOME';
is expand-arg('~/x'), (%*ENV<HOME> // q{}) ~ '/x', '~/x ⇒ HOME/x';
export-vars('RK_T45C=vv');
is expand-arg('$RK_T45C'), 'vv', '$NAME 展开';
is expand-arg('${RK_T45C}!'), 'vv!', '${NAME} 展开';
is expand-arg('a$RK_T45Cb'), 'a', '未定义的变量展开成空串（bash 语义）';
unset-vars('RK_T45C');

# ── 5. alias / unalias ─────────────────────────────────────────────
is alias-def(q{hi=echo HI})<code>, 0, '定义别名';
is expand-alias('hi'), 'echo HI', '裸别名展开';
is expand-alias('hi there'), 'echo HI there', '带参数时拼在后面';
ok alias-def('hi')<out>.contains(q{alias hi='echo HI'}), '查询单个别名';
is expand-alias('cd /tmp'), 'cd /tmp', '内建不被别名影响';

# 带引号的整体：引号本身要被 dequote 剥掉，内部空格保住
alias-def(q{h2='echo two words'});
is expand-alias('h2'), 'echo two words', '引号里的空格保住';
unalias-def('h2');

unalias-def('hi');
is expand-alias('hi'), 'hi', '别名没了就不再展开';
is unalias-def('nope')<code>, 1, '删不存在的别名 ⇒ 退出码 1';

# ── 6. type ────────────────────────────────────────────────────────
ok type-of('ls').chars > 0, 'ls 找得到';
ok type-of('ls').ends-with('ls'), '返回的是路径';
ok type-of('cd').contains('内建'), 'cd 认成内建';
is type-of('绝对不存在的命令-xyzzy'), q{}, '找不到 ⇒ 空串';

# ── 7. exit ────────────────────────────────────────────────────────
my %x7 = finish-exit('7');
is %x7<code>, 7, 'exit 7 ⇒ 7';
ok %x7<quit>, '标记收摊';
is finish-exit('300')<code>, 44, '超 255 取模（bash 语义）';
is finish-exit()<code>, 0, '无参 ⇒ 0';
is finish-exit('abc')<code>, 2, '非数字 ⇒ 2（bash 用法错误的约定）';

# ── 8. test / [ ────────────────────────────────────────────────────
ok test-args('-d', '/tmp'),           '-d 目录';
nok test-args('-d', '/etc/hostname'), '-d 对文件为假';
ok test-args('-f', '/etc/hostname'),  '-f 普通文件';
ok test-args('-e', '/tmp'),           '-e 存在';
nok test-args('-e', '/no/such'),      '-e 不存在';
ok test-args('-z', q{}),              '-z 空串';
ok test-args('-n', 'x'),              '-n 非空';
ok test-args('a', '=', 'a'),          '字符串相等';
nok test-args('a', '!=', 'a'),        '字符串不等（假）';
ok test-args('2', '-lt', '10'),       '整数比较（不是字符串比较）';
ok test-args('!', '-d', '/etc/hostname'), '! 取反';
ok test-args('-d', '/tmp', ']'),      '`[` 的收尾 ] 被吃掉';

# ── 9. source ──────────────────────────────────────────────────────
my $src = $*TMPDIR.add("rk-src-{$*PID}.rakuish");
$src.spurt("export RK_T45D=from-file;\nsay 'src-ok';\n");
my @seen;
my %sr = do-source($src.Str, :runner(-> Str $p { @seen.push: $p; 0 }));
is %sr<code>, 0, 'source 返回 runner 的退出码';
is @seen.elems, 1, 'runner 被调用一次';
is @seen[0], $src.Str, 'runner 收到了路径';
$src.unlink;

is do-source()<code>, 1, '缺文件名 ⇒ 1';
is do-source('/tmp/x')<code>, 1, '没有 runner ⇒ 1（不炸）';

# ── 10. drive 集成：宿主内建不再落到引擎 ───────────────────────────
my $s1 = run-capture('pwd');
ok $s1.text.contains($*CWD.absolute.Str), '裸 pwd 由宿主回答';
nok $s1.text.contains('[shell]'), '而且没有交给引擎（没有 [shell] 标记）';

my $s2 = run-capture('test -d /tmp');
nok $s2.text.contains('错误'), 'test 不报错';

# ── 11. 脚本模式：$*PROGRAM 与报错定位 ─────────────────────────────
my $root = $?FILE.IO.dirname.IO.parent;
my @base = ($*EXECUTABLE.Str, '-I', $root.add('lib').Str,
            $root.add('bin/rakuish').Str);
my $prog = $*TMPDIR.add("rk-p2prog-{$*PID}.rakuish");

# ① $*PROGRAM 指向脚本本身
$prog.spurt("say \$*PROGRAM.Str;\n");
my $p = run(|@base, 'run', $prog.Str, :out, :err);
is $p.out.slurp(:close).trim, $prog.Str, q{$*PROGRAM 就是脚本路径};
is $p.exitcode, 0, '正常退出';
$p.err.slurp(:close);

# ② 编译期错误报的是**文件行号**（不是 EVAL 拼接后的行号）
$prog.spurt("say 'a';\nmy \$x = 1;\nsay \$undefined_name_xyz;\nsay 'never';\n");
my $q = run(|@base, 'run', $prog.Str, :out, :err);
my $err = $q.err.slurp(:close);
$q.out.slurp(:close);
ok $err.contains("{$prog.Str}:3"), '报错带 文件:行号（第 3 行）';
is $q.exitcode, 1, '出错 ⇒ 退出码 1';

$prog.unlink;
change-dir($start);
done-testing;
