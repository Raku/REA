use lib 'lib';
use Test;
use Rakuish::Shell::Session;
use Rakuish::Shell::Exec;
use Rakuish::Shell::Expand;

# t/35-shell-session.t —— 外壳层的**会话状态**（跨行存活的变量）
#
# 这一层解决的是改造前的真缺陷：
#   !export FOO=bar     →  改的是 `sh -c` 那个**子进程**的环境
#   !echo $FOO          →  又是一个新进程，看不到上一个进程的环境
#   ⇒ 变量永远传不下去（实测输出是空的）。
#
# 现在会话变量存在**宿主进程**里（`Rakuish::Shell::Session`），
# 跨行存活，并且：
#   · shell 展开能看到它（`$VAR`）
#   · 子进程能看到它（`printenv`）—— 靠**显式构造 envp**
#   · Raku 侧能看到它（`%*ENV<VAR>`）—— 靠**镜像**
#
# ⚠ 断言刻意不写死外部命令的报错原文，只断言「退出码 / 输出内容」。

my $SQ = chr(39);
my $DQ = chr(34);

# 每个 subtest 前把会话清干净 —— 变量表是**模块级**的，
# 跨 subtest 存活（这正是我们要测的性质，但用例会互相干扰时要清）。
sub reset-session() {
    clear-vars();
}

subtest "变量名合法性", {
    ok valid-name('FOO'), 'FOO 合法';
    ok valid-name('_foo'), '_foo 合法';
    ok valid-name('a1'), 'a1 合法';
    ok !valid-name('1FOO'), '1FOO 不合法（不能以数字开头）';
    ok !valid-name(''), '空串不合法';
    ok !valid-name('A-B'), 'A-B 不合法（���允许横线）';
    ok !valid-name('A B'), 'A B 不合法（不允许空格）';
}

subtest "赋值词的识别", {
    ok is-assignment('FOO=bar'), 'FOO=bar 是赋值';
    ok is-assignment('FOO='), 'FOO= 是赋值（空值）';
    ok !is-assignment('FOO'), 'FOO 不是赋值';
    ok !is-assignment('=bar'), '=bar 不是赋值（没有名字）';
    ok !is-assignment($SQ ~ 'FOO=bar' ~ $SQ), '整体带引号不是赋值（bash 语义）';
    ok !is-assignment('1FOO=bar'), '名字不合法就不是赋值';
}

subtest "set-var / get-var / unset-var", {
    reset-session();
    ok set-var('RK_A', 'v1'), 'set-var 成功';
    is get-var('RK_A'), 'v1', '读回来一致';
    ok set-var('RK_A', 'v2'), '覆盖成功';
    is get-var('RK_A'), 'v2', '覆盖后是新值';
    ok unset-var('RK_A'), 'unset-var 成功';
    is get-var('RK_A'), q{}, '删掉后读回空';
}

subtest "不合法的变量名被丢弃（不抛错）", {
    reset-session();
    ok !set-var('1BAD', 'x'), '名字不合法 → 返回 False';
    is get-var('1BAD'), q{}, '没有写进去';
}

subtest "镜像到 %*ENV（Raku 侧能看到）", {
    reset-session();
    set-var('RK_MIRROR', 'mirrored');
    is %*ENV<RK_MIRROR>, 'mirrored', '%*ENV 里有镜像';
    unset-var('RK_MIRROR');
    ok !%*ENV.EXISTS-KEY('RK_MIRROR'), 'unset 后镜像也删掉了';
}

subtest "会话变量优先于 %*ENV", {
    reset-session();
    %*ENV<RK_BOTH> = 'from-env';
    set-var('RK_BOTH', 'from-session');
    is get-var('RK_BOTH'), 'from-session', '会话变量优先';
    is expand-arg('$RK_BOTH'), 'from-session', '展开层也优先';
    unset-var('RK_BOTH');
}

subtest "显式设成空串时**不**回退到 %*ENV", {
    reset-session();
    %*ENV<RK_EMPTY> = 'old';
    set-var('RK_EMPTY', q{});
    is get-var('RK_EMPTY'), q{}, '空串就是空串（bash 语义）';
    is expand-arg('$RK_EMPTY'), q{}, '展开层同样是空串';
    unset-var('RK_EMPTY');
}

subtest "export：设置后跨行存活", {
    reset-session();
    my $r = run-shell-line('export RK_SESSION=bar', :capture(True));
    is $r.code, 0, 'export 退出码 0';
    my $r2 = run-shell-line('echo [$RK_SESSION]', :capture(True));
    is $r2.stdout.trim, '[bar]', '下一行读得到';
    reset-session();
}

subtest "export 的值能传到子进程", {
    reset-session();
    run-shell-line('export RK_CHILD=cv', :capture(True));
    my $r = run-shell-line('printenv RK_CHILD', :capture(True));
    is $r.code, 0, 'printenv 成功';
    is $r.stdout.trim, 'cv', '子进程看到了会话变量';
    reset-session();
}

subtest "export 的值能穿过管道传到子进程", {
    reset-session();
    run-shell-line('export RK_PIPE=pv', :capture(True));
    my $r = run-shell-line('printenv RK_PIPE | cat', :capture(True));
    is $r.stdout.trim, 'pv', '管道下游也看到了';
    reset-session();
}

subtest "unset：删掉变量", {
    reset-session();
    run-shell-line('export RK_GONE=x', :capture(True));
    is get-var('RK_GONE'), 'x', '先设上';
    run-shell-line('unset RK_GONE', :capture(True));
    is get-var('RK_GONE'), q{}, 'unset 之后没了';
    my $r = run-shell-line('echo [$RK_GONE]', :capture(True));
    is $r.stdout.trim, '[]', '展开成空串';
    reset-session();
}

subtest "纯赋值（NAME=VALUE）也进会话", {
    reset-session();
    my $r = run-shell-line('RK_PLAIN=pv', :capture(True));
    is $r.code, 0, '退出码 0';
    is get-var('RK_PLAIN'), 'pv', '会话表里有';
    my $r2 = run-shell-line('printenv RK_PLAIN', :capture(True));
    is $r2.stdout.trim, 'pv', '子进程也看得到';
    reset-session();
}

subtest "export 不带参数 → 列出全部", {
    reset-session();
    run-shell-line('export RK_L1=one', :capture(True));
    run-shell-line('export RK_L2=two', :capture(True));
    my $r = run-shell-line('export', :capture(True));
    ok $r.stdout.contains('RK_L1=one'), '列出了第一个';
    ok $r.stdout.contains('RK_L2=two'), '列出了第二个';
    reset-session();
}

subtest "export NAME（不带值）导出已有变量", {
    reset-session();
    %*ENV<RK_PRE> = 'preset';
    my $r = run-shell-line('export RK_PRE', :capture(True));
    is $r.code, 0, '退出码 0';
    is get-var('RK_PRE'), 'preset', '值被带进会话';
    reset-session();
    %*ENV<RK_PRE>:delete;
}

subtest "export 的值带引号时只剥引号", {
    reset-session();
    run-shell-line('export RK_QUOTED=' ~ $DQ ~ 'a b' ~ $DQ, :capture(True));
    is get-var('RK_QUOTED'), 'a b', '引号剥了、空格保留';
    reset-session();
}

subtest "单引号里的赋值不是赋值", {
    reset-session();
    my $r = run-shell-line($SQ ~ 'RK_LIT=1' ~ $SQ, :capture(True));
    ok get-var('RK_LIT') eq q{}, '没进会话表';
    reset-session();
}

subtest "会话变量不会被 sh 回退路径丢掉", {
    reset-session();
    run-shell-line('export RK_BOTH=1', :capture(True));
    # 这一行含 `&&`，走 sh 回退路径 —— 但变量仍要传得下去
    my $r = run-shell-line('echo [$RK_BOTH] && echo done', :capture(True));
    ok $r.stdout.contains('[1]'), 'sh 路径也看到了变量';
    ok $r.stdout.contains('done'), '&& 后半段跑了';
    reset-session();
}

subtest "会话状态在两次 run-shell-line 之间存活", {
    reset-session();
    run-shell-line('export RK_ACROSS=kept', :capture(True));
    is get-var('RK_ACROSS'), 'kept', '第二次调用还在';
    reset-session();
}

subtest "export 与 && 同一条：后面的命令看得到", {
    # bash 语义：`export` 在**当前 shell** 里执行，不是子 shell ⇒
    # 同一行里后面的命令就能看到刚设的变量。
    reset-session();
    my $r = run-shell-line('export RK_SAME=1 && echo [$RK_SAME]', :capture(True));
    is $r.stdout.trim, '[1]', '同一行里后面的命令看到了';
    reset-session();
}

subtest "export 与 ; 同一条：后面的命令看得到", {
    reset-session();
    my $r = run-shell-line('export RK_SEMI=2 ; echo [$RK_SEMI]', :capture(True));
    is $r.stdout.trim, '[2]', '分号后面的命令看到了';
    reset-session();
}

subtest "export 在管道里 → 不进会话表（bash 的子 shell 语义）", {
    # bash：`export X=3 | cat` 里 export 跑在**管道子进程**里，
    # 不影响当前 shell ⇒ 后面 `echo $X` 是空的。
    #
    # ⚠⚠ **2026-11-05 行为变更**：native 后端**不再**把整行交给 sh ——
    #   「会话内建出现在管道里」这个语义我们**还没实现**
    #   （bash 里它跑在管道子进程里，不影响会话）⇒
    #   **明确报错 + 退出码 2 + 委托提示**（§5.8.7「不跨引擎委托」）。
    #   以前这条是靠「整行交 sh」蒙混过关的（行为对，但违反引擎纯化原则）。
    reset-session();
    my $r = run-shell-line('export RK_SUB=3 | cat', :capture(True));
    is $r.code, 2, '退出码 2（bash 的语法错误码 = 「这一行跑不了」）';
    ok $r.stderr.contains('不支持'), '并且说清楚「不支持」';
    ok $r.stderr.contains('@bash'), '并告诉用户怎么委托给 bash 引擎';
    is get-var('RK_SUB'), q{}, '没有进会话表';
    my $r2 = run-shell-line('echo [$RK_SUB]', :capture(True));
    is $r2.stdout.trim, '[]', '后续也看不到';
    reset-session();
}

subtest "unset 在管道里 → 不进会话表（同上）", {
    reset-session();
    run-shell-line('export RK_UNP=1', :capture(True));
    is get-var('RK_UNP'), '1', '先设上';
    run-shell-line('unset RK_UNP | cat', :capture(True));
    is get-var('RK_UNP'), '1', '管道里的 unset 没影响会话表';
    reset-session();
}

subtest "会话变量覆盖同名环境变量（envp 里不能出现重复 key）", {
    # ⚠ 同一个 key 在 envp 里出现两次时，各家 libc 行为**不一致**：
    #   实测 `sh -c printenv` 看到后者，但 glibc 的 `getenv()` 返回前者
    #   （POSIX 没规定）→ 会话变量必须是**唯一**的那个。
    reset-session();
    %*ENV<RK_SHADOW> = 'from-env';
    set-var('RK_SHADOW', 'from-session');
    my $r = run-shell-line('printenv RK_SHADOW', :capture(True));
    is $r.stdout.trim, 'from-session', '子进程看到的是会话变量的值';
    unset-var('RK_SHADOW');
    %*ENV<RK_SHADOW>:delete;
}

done-testing;
