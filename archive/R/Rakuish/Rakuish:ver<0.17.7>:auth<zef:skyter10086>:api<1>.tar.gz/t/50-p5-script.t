use v6;
use Test;

# 脚本模式（C 方案 P5-1）：**整文件一次编译、一次执行**
#
# 这一组保护的是 G3 的修法本身：以前每个 cell 都把「前面所有源码」重新
# EVAL 一遍，副作用（spurt / rename / mkdir / 追加写文件）因此每格重跑
# 一次，靠文件系统状态判定的脚本会在终态上"假失败"，耗时还是 O(n²)。
# 现在脚本模式把整份文件拼成一个编译单元，格子只负责"渲染成一次调用"。
#
# 这些断言全部走真实子进程 + 真实文件系统：副作用重复执行这种 bug 只在
# 进程真跑过之后才看得见，进程内断言一律看不出。

plan 12;

my $root = $?FILE.IO.dirname.IO.parent;
my @base = ($*EXECUTABLE.Str, '-I', $root.add('lib').Str,
            $root.add('bin/rakuish').Str);

sub run-file(Str $src, *@args) {
    my $f = $*TMPDIR.add("rk-p51-{$*PID}-{(1000..9999).pick}.rakuish");
    $f.spurt($src);
    my $p = run(|@base, $f.Str, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    $f.unlink;
    %( code => $p.exitcode, out => $out, err => $err );
}

sub fresh-dir(--> IO::Path) {
    my $d = $*TMPDIR.add("rk-p51-d-{$*PID}-{(1000..9999).pick}");
    $d.mkdir;
    $d;
}

# ── 1. 副作用只执行一次：5 格各追加一行，日志就必须正好 5 行 ──
{
    my $d = fresh-dir();
    my $log = $d.add('sfx.log');
    my @lines = (1..5).map: -> $i {
        "!echo l$i >> {$log.Str}\n"
    };
    my %r = run-file(@lines.join ~ 'say "done";' ~ "\n");
    is %r<code>, 0, '追加写脚本正常结束';
    is $log.IO.lines.elems, 5, '5 格副作用只落 5 行（不再 1+2+…+n 重放）';
    shell("rm -rf {$d.Str}");
}

# ── 2. 幂等：mkdir 出来的目录不会被后续格重放覆盖/重建 ──
{
    my $d = fresh-dir();
    my $t = $d.add('target');
    my %r = run-file(
        "mkdir '{$t.Str}';\n" ~
        "!touch {$t.Str}/x\n" ~
        "my \$ok = ('{$t.Str}/x'.IO.e) ?? 'yes' !! 'no';\n" ~
        "say \$ok;\n"
    );
    is %r<out>, "yes\n", 'mkdir 之后 touch 的文件仍在（无重放）';
    is %r<code>, 0, 'rc 0';
    shell("rm -rf {$d.Str}");
}

# ── 3. 显式 rename 场景（G3 当初卡住的那类）：先建后改名，终态只要一个文件 ──
{
    my $d = fresh-dir();
    my $a = $d.add('a.txt');
    my $b = $d.add('b.txt');
    my %r = run-file(
        "spurt '{$a.Str}', 'hi';\n" ~
        "!mv {$a.Str} {$b.Str}\n" ~
        "say '{$a.Str}'.IO.e ?? 'a-still' !! 'a-gone';\n" ~
        "say '{$b.Str}'.IO.e ?? 'b-here' !! 'b-missing';\n"
    );
    is %r<out>, "a-gone\nb-here\n", 'rename 之后 a 不再被重建';
    is $d.add('a.txt').e, False, '磁盘上确实没有 a.txt';
    shell("rm -rf {$d.Str}");
}

# ── 4. O(n) 而不是 O(n²)：40 格追加，正好 40 行 ──
{
    my $d = fresh-dir();
    my $log = $d.add('many.log');
    my @cells = (1..40).map: -> $i { "!echo {$i} >> {$log.Str}\n" };
    my %r = run-file(@cells.join);
    is $log.IO.lines.elems, 40, '40 格追加正好 40 行';
    is %r<code>, 0, 'rc 0';
    shell("rm -rf {$d.Str}");
}

# ── 5. 文件级语义：use v6.d / heredoc / END ──
{
    # ⚠ 双引号里的 { ... } 是 Raku 的闭包插值（会当场执行并按值插进去），
    # 所以带花括号的源码行一律用 q{} 拼，别再踩这个坑。
    my %r = run-file(
        "use v6.d;\n" ~
        'my $t = q:to/EOT/;' ~ "\n" ~
        "line-one\nline-two\nEOT\n" ~
        q{END { say 'end-once' }} ~ "\n" ~
        'say $t.lines.elems;' ~ "\n"
    );
    is %r<code>, 0, 'use v6.d + heredoc 可跑';
    is %r<out>, "2\nend-once\n", 'heredoc 两行、END 只跑一次';
}

# ── 6. 编译期错误：整份文件不执行（与 raku 一致）──
{
    my %r = run-file("say 1;\nfoo bar baz;\n");
    is %r<out>, '', '编译期错误不留下部分输出';
    isnt %r<code>, 0, '编译期错误非 0 退出';
}
