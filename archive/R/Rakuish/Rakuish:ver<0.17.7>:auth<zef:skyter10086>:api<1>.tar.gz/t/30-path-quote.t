use lib "lib";
use Test;
use Rakuish::Loop;

# ══ 1. quote-path / path-needs-quote ══════════════════════════════════
ok !path-needs-quote(q{plain.txt}),      q{普通路径不需要引号};
ok  path-needs-quote(q{with space.txt}), q{含空格需要引号};
ok  path-needs-quote(q{a#b}),           q{# 需要引号};
ok  path-needs-quote(q{a$b}),           q{$ 需要引号};
is quote-path(q{plain.txt}),      q{plain.txt},      q{不加引号时原样返回};
is quote-path(q{with space.txt}), q{'with space.txt'}, q{含空格 -> 单引号};
is quote-path(q{a'b}),            q{'a''b'},         q{单引号转义成两个};
# `~` 必须**不**触发引号：单引号会阻止 shell/Raku 的 ~ 展开，等于把好路径弄坏。
ok !path-needs-quote(q{~/.config}),   q{~ 不触发引号};
is quote-path(q{~/.config}), q{~/.config}, q{~ 路径保持可展开};

# ══ 2. 含空格路径的补全（端到端）════════════════════════════════════
my $dir = $*TMPDIR.add(q{rk t30 dir});       # 目录名本身含空格
$dir.IO.mkdir;
$dir.IO.add(q{a file with space.txt}).spurt(q{x});
$dir.IO.add(q{plain.txt}).spurt(q{y});

sub cands(Str $p --> Str) {
    my @c = complete-at($p, $p.chars);
    @c.elems ?? @c.join(q{ | }) !! q{(无)};
}

is cands(q{cat } ~ $dir.Str ~ q{/a fi}),
   q{cat '} ~ $dir.Str ~ q{/a file with space.txt'},
   q{含空格的路径能补出来且自动加引号};

is cands(q{cat } ~ $dir.Str ~ q{/pl}),
   q{cat '} ~ $dir.Str ~ q{/plain.txt'},
   q{目录名含空格时也会加引号（整条路径都需要）};

is cands(q{cat '} ~ $dir.Str ~ q{/a fi}),
   q{cat '} ~ $dir.Str ~ q{/a file with space.txt'},
   q{上文已有引号时只补闭合引号，不产生双引号};

is cands(q{!cat } ~ $dir.Str ~ q{/a fi}),
   q{!cat '} ~ $dir.Str ~ q{/a file with space.txt'},
   q{shell 分支同样加引号};

is cands(q{%load } ~ $dir.Str ~ q{/pl}),
   q{%load } ~ $dir.Str ~ q{/plain.txt},
   q{%load 后面是文件名参数，不加引号};

# 变量候选绝不能被加引号（否则变成 '$name'，归属就错了）
$SCOPE-SOURCE = q{my $name = 1;};
scope-refresh();
is cands(q{say $na}), q{say $name}, q{变量候选不加引号};

$dir.IO.add(q{a file with space.txt}).unlink;
$dir.IO.add(q{plain.txt}).unlink;
$dir.IO.rmdir;

# ══ 3. word-tries：原切法优先 + 扩展版本兜底 ════════════════════════
my @t1 = word-tries(q{cat /tmp/plain});
is @t1.elems, 1, q{不含空格且无路径分隔时只给一种切法};

my @t2 = word-tries(q{cat /tmp/rk batch dir/a fi});
ok @t2.elems > 1, q{含空格的路径会额外给出扩展切法};
is @t2[0]<word>, q{fi}, q{第一个（原始）切法是空格后的那一段};
is @t2[*-1]<word>, q{/tmp/rk batch dir/a fi}, q{最后一个扩展切法把整条路径都包进来了};

# ══ 4. 历史去重 ═════════════════════════════════════════════════════
my @h;
@h = push-history(@h, q{git status});
@h = push-history(@h, q{say 1});
@h = push-history(@h, q{say 1});
@h = push-history(@h, q{say 1});
@h = push-history(@h, q{git status});
is @h.elems, 3, q{连续重复被丢弃，非连续重复保留};
ok @h[0] ~~ Str, q{返回的是扁平字符串列表（不是嵌套 List）};
is @h.join(q{|}), q{git status|say 1|git status}, q{内容与顺序正确};

my @h2 = push-history((), q{only once});
is @h2.elems, 1, q{空历史时正常写入};

done-testing;
