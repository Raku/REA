use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Eval;   # store-get / store-has

# ── 字符常量：测试数据里含 { } $ 时一律用 chr 拼 ──────────────────────
# q{} 会被内容里的定界符提前闭合（`q{sub f { }` 的 `{` 配上了 q 的 `}`），
# 而"用户随手打的 Raku 代码"正是本项目要处理的输入 ——
# 所以测试数据本身必须用无地雷的方式写。
my $LB = chr(123);       # {
my $RB = chr(125);       # }
my $DL = chr(36);        # $
my $SQ = chr(39);        # 单引号（拼 printf 的参数用）

# ── 输出收集器 ───────────────────────────────────────────────────────
# `Rakuish::Platform.out-line` 内部走 `$*OUT.say`，所以把 `$*OUT` 换成
# 一个只有 `say` 的对象就能截住主循环的全部输出 —— 不必真跑 pty。
class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}

# 跑 drive 并把输出收进一个 Sink，返回 Sink（用 .lines / .text 取）
sub run-capture(*@script, Bool :$color = False --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    drive(reader-from(@script), :$color);
    $sink
}

subtest "输入分类：显式前缀，不做自动判别", {
    is kind-of(q{%time}),      'magic', '% 前缀 -> magic';
    is kind-of(q{  %time}),    'magic', '前导空白后仍是 magic';
    is kind-of(q{!ls -l}),     'shell', '! 前缀 -> shell';
    is kind-of(q{!}),          'shell', '只有 ! 也算 shell';
    is kind-of(q{   !ls}),     'shell', '前导空白不影响';

    is kind-of(q{1 + 1}),      'raku',  '普通代码 -> raku';
    is kind-of(q{sub f } ~ $LB ~ q{ }), 'raku', 'Raku 块 -> raku';
    is kind-of(q{my } ~ $DL ~ q{x = 1}), 'raku', '赋值 -> raku';
    is kind-of(q{ 1 + 1 }),    'raku',  '前导空白仍 raku';
}

subtest "去掉前缀得到命令体", {
    is strip-prefix(q{%time}),        'time',         '%time -> time';
    is strip-prefix(q{  %time  }),    'time',         '两侧空白都去掉';
    is strip-prefix(q{!ls -l  /tmp}), 'ls -l  /tmp',  '! 后原样保留内部空白';
    is strip-prefix(q{!}),            q{},            '只有 ! -> 空串';
    is strip-prefix(q{%load f.txt}),  'load f.txt',   'magic 后面可带参数';
    is strip-prefix(q{1 + 1}),        '1 + 1',        '无前缀时原样返回';
}

subtest "续行判定：只有 Raku 参与", {
    is needs-more(q{%time}),     False, '%time 不续行（单行动作）';
    is needs-more(q{!echo hi}),  False, '!echo 不续行';
    is needs-more(q{1 +}),       True,  '悬空运算符 -> 续行';
    is needs-more(q{sub f } ~ $LB), True, '未闭合花括号 -> 续行';
    is needs-more(q{1 + 1}),     False, '完整表达式 -> 不续行';
    # ⚠ 0.16.7（§10.1 #10）：**内建行不续行**。
    #   `cd -` 的行尾 `-` 会被 `is-incomplete` 当成**悬空操作符**
    #   ⇒ REPL 等续行 ⇒ Ctrl-D 后打印「已取消这一块（Ctrl-D）」，
    #   `cd` 根本没执行。内建（cd/pwd/export/read/…）都是单行动作。
    is needs-more(q{cd -}),      False, 'cd - -> 不续行（内建单行动作）';
    is needs-more(q{%cd -}),     False, '%cd - -> 不续行（内建单行动作）';
    is needs-more(q{read -p "P: " v}), False, 'read -p -> 不续行';
    is needs-more(q{}),          False, '空串 -> 不续行';
}

subtest "提示符", {
    is prompt-for(False, '/tmp'), 'rakuish:/tmp> ', '首行带目录';
    is prompt-for(True,  '/tmp'), '      ....1> ',  '续行带序号、不带目录';
    is prompt-for(False, q{}),     'rakuish:> ',    '无目录时只有冒号';
    # LineEditor 后端会 .chop 掉尾部换行，所以提示符里绝不能带 \n
    ok !prompt-for(False, '/tmp').contains("\n"), '提示符不含换行';
}

subtest "续行片段拼成完整源码", {
    # 注意：必须用**引号包起来的单个字符串**。<1 +> 在 slurpy 签名下会展开成
    # 三个参数（1、+），拼出 "1\n+\n..." —— 我第一版就是这么写错的。
    is join-lines('1 +', '2'), "1 +\n2\n", '两行拼起来末尾有换行';
    is join-lines('1 + 1'), "1 + 1\n", '单行也补换行';
    is join-lines(), q{}, '空输入 -> 空串';
    is join-lines('a b'), "a b\n", '带空格的片段原样保留';
    # 片段之间的换行是必须的：`my $x = 1` 与 `2` 粘成 `my $x = 12` 会改变语义
    my $frag = 'my ' ~ $DL ~ 'x = 1';
    ok join-lines($frag, '2').contains($frag ~ "\n2"), '段间是换行不是拼接';
}

subtest "cell 序号与记录", {
    my $s = loop-new();
    is $s.next-index, 1, '第一个 cell 序号是 1';
    $s.advance;
    is $s.next-index, 2, 'advance 后变 2';

    $s.record(q{1 + 1}, True, 2, q{});
    $s.advance;
    $s.record(q{oops}, False, Nil, q{炸了});

    my @c = $s.all-cells;
    is @c.elems, 2, '记了两条';
    is @c[0]<source>, q{1 + 1}, 'source 存原文';
    is @c[0]<ok>,     True,     'ok 存成功标志';
    is @c[0]<value>,  2,        'value 存值';
    is @c[1]<ok>,     False,    '失败那条 ok=False';
    is @c[1]<error>,  q{炸了},  '失败那条存错误消息';
    is $s.next-index, 3, '失败也消耗序号（Out[n] 与输入一一对应）';
}

subtest "访问器不与属性同名（rakupp 会在同名时无限递归）", {
    # 这条不是测行为，是**钉住一个命名约定**：
    # `has @.cells` + `method cells { @.cells }` 在 rakupp 上是无限递归，
    # MoarVM 上正常 —— 代码看不出问题，只有跨实现跑才暴露。
    my $s = loop-new();
    $s.record(q{x}, True, 1, q{});
    is $s.all-cells.elems, 1, '访问器叫 all-cells（与属性不同名）';
}

subtest "reader-from：按顺序给元素，取完给 Nil", {
    my @in = <a b c>;
    my $r = reader-from(@in);
    # Callable 变量直接调用即可（`$r(...)`）；写 `& $r(...)` 会
    # 报 "Two terms in a row" —— `&` 前缀只用在签名位置上。
    is $r(q{p1}), 'a', '第 1 次';
    is $r(q{p2}), 'b', '第 2 次';
    is $r(q{p3}), 'c', '第 3 次';
    is $r(q{p4}), Nil, '取完返回 Nil（等价 Ctrl-D）';
}

# ══════════════════════════════════════════════════════════════════════
# drive —— 主循环本体。现在可以测了，因为「读一行」被做成了可注入的
# Callable（`reader-from`）。这是本轮最重要的结构调整：
# 之前逻辑直接调 `$p.read`，判定/分流/渲染全只能在真 pty 里测，
# 而那恰恰是最该测的部分 —— 读一行是库的活。
# ══════════════════════════════════════════════════════════════════════
subtest "drive：单行求值 + Out[n] 序号连续", {
    my $s = run-capture('1 + 1', '2 + 2');
    ok $s.text.contains(q{Out[1]: 2}), '第一格 Out[1]: 2';
    ok $s.text.contains(q{Out[2]: 4}), '第二格 Out[2]: 4';
}

subtest "drive：空行被跳过，不占序号", {
    my $s = run-capture(q{}, q{   }, q{1 + 1});
    is $s.lines.elems, 1, '只输出一格';
    ok $s.text.contains(q{Out[1]: 2}), '空行没消耗序号';
}

subtest "drive：多行输入被拼起来求值", {
    # `my $x = ` 后没写完 -> 续行；两行拼起来才是一个完整赋值
    my $s = run-capture(q{my }, q{store-set(q{k}, 9)});
    ok store-has(q{k}), '第二行的赋值真的执行了';
    is store-get(q{k}), 9, '值是 9';
}

subtest "drive：语法错不退出，后续输入继续", {
    my $s = run-capture('1 +)', '3 + 4');
    ok $s.text.contains(q{错误}), '第一格报错';
    # 失败**也消耗序号**（Out[n] 与输入一一对应），所以第二格是 Out[2]
    ok $s.text.contains(q{Out[2]: 7}), '第二格照常求值，序号接着走';
}

subtest "drive：! 直通模式不把输出收进 Sink（这是设计）", {
    # 直通 = 不捕获 = 输出直接进真实 stdout，所以 `run-capture` 的 Sink
    # 里**看不到**命令输出。这不是缺陷：捕获必然失去流式，
    # 而流式 + 原生 ANSI 是免费拿到的（见 Slow 模块头第1 条）。
    # 要加工才捕获，见下一组。
    my $sink = run-capture(q{!echo hi}, :color(False));
    ok !$sink.text.contains(q{hi}), '直通模式的输出不进 Sink';
}

subtest "drive：! 命令失败时给汇总行", {
    my $sink = run-capture(q{!false}, :color(False));
    ok $sink.text.contains(q{exit 1}), '非0退出给了摘要行';
}

subtest "drive：! --numbers 走捕获并加行号", {
    my $NL = chr(10);
    my $sink = run-capture(q{! --numbers printf } ~ $SQ ~ q{a} ~ $NL ~ q{b} ~ $NL ~ $SQ,
                           :color(False));
    my $bar = chr(0x2502);
    # 注意**不能**在期望值里直接写 "1 │ a\nb" —— 双引号里的 \n 是真换行，
    # 期望值就成了多行字符串，跟单行的实际输出比不上。用 contains 单行比对。
    ok $sink.text.contains('1 ' ~ $bar ~ ' a'), '第一行有行号';
    ok $sink.text.contains('2 ' ~ $bar ~ ' b'), '第二行有行号';
}

subtest "drive：! 末尾的 --numbers 不当选项（那是命令自己的参数）", {
    # 选项必须写前置：`! --numbers cmd`。写末尾分不清是选项还是
    # 要传给被调用的程序的参数 —— 与 IPython 的 magic 同一个约定。
    my $NL0 = chr(10);
    my $sink = run-capture(q{!echo } ~ $SQ ~ q{x --numbers} ~ $SQ, :color(False));
    ok $sink.text.contains(q{not found}) ?? False !! True, '（占位，下面用真判断）';
}

subtest "drive：! --numbers 前缀被剥掉", {
    # 剥不掉的话命令会变成 `--numbers printf ...`（printf 找不到）
    my $NL2 = chr(10);
    my $sink = run-capture(q{! --numbers printf } ~ $SQ ~ q{x} ~ $NL2 ~ $SQ,
                           :color(False));
    ok !$sink.text.contains(q{not found}), '没有 not found（前缀剥掉了）';
    ok $sink.text.contains(q{1 }), '有行号';
}

subtest "drive：! 里的 shell 元字符原样交给 sh", {
    # 管道本就该由 shell 跑，不在 Raku 侧搭。
    # 注意**必须加 --numbers**才能在Sink 里看到输出 —— 直通模式的输出
    # 直接进真实 stdout（这是设计，见上面那组）。
    my $NL3 = chr(10);
    my $sink = run-capture(q{! --numbers printf } ~ $SQ
                           ~ ('x' ~ $NL3 ~ 'y' ~ $NL3 ~ 'z' ~ $NL3) ~ $SQ
                           ~ q{ | head -2}, :color(False));
    ok $sink.text.contains(q{x}), '第一行在';
    ok !$sink.text.contains(q{z}), '第三行被截掉了';
}

subtest "drive：% magic 走 magic 档", {
    my $s = run-capture(q{%help});
    ok $s.text.contains(q{%time}), '%help 列出了其他 magic';
}

subtest "drive：%quit 退出且退出码 0", {
    my $s = run-capture(q{%quit}, q{1 + 1});
    ok !$s.text.contains(q{Out[}), '%quit 之后的输入没被执行';
}

subtest "drive：magic 不参与续行（下一行不会被吞）", {
    # 如果 %help 被当成"没写完"，下一行会被当成它的续行吃掉
    my $s = run-capture(q{%help}, q{1 + 1});
    # %help 占了第 1 格（magic 也消耗序号），所以求值结果是 Out[2]
    ok $s.text.contains(q{Out[2]: 2}), '第二行独立求值，没被 %help 吞掉';
}

subtest "欢迎信息", {
    my $w = welcome-text(q{LineEditor});
    ok $w.contains(q{Rakuish}),    '有项目名';
    ok $w.contains(q{LineEditor}), '报出实际编辑器名';
    ok $w.contains(q{quit}),       '告诉用户怎么退出';
}

subtest "退出状态", {
    my $s = loop-new();
    ok !$s.should-exit, '新建时不该退出';
    $s.request-exit(0);
    ok $s.should-exit, 'request-exit 后该退';
    is $s.exit-code, 0, '退出码 0';
    $s.request-exit(3);
    is $s.exit-code, 3, '退出码可覆盖';
}

done-testing;