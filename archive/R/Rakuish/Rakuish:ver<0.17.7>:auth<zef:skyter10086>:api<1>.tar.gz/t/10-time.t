use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Eval;

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}

sub time-magic-capture(Str $cmd --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    time-magic($cmd);
    $sink
}

subtest "time-magic：求值并给 Out[n] + 耗时框", {
    my $s = time-magic-capture('time 1 + 1');
    ok $s.text.contains('Out[1]: 2'), '值 2 以 Out[1] 显示';
    ok $s.text.contains('s ·'),        '有耗时';
    ok $s.text.contains('OK'),         '成功态 OK';
};

subtest "time-magic：无参数给用法", {
    my $s = time-magic-capture('time');
    ok $s.text.contains('用法'), '提示用法';
    ok $s.text.contains('用法'), '框里标 用法';
};

subtest "time-magic：走真实 Eval 路径（%STORE 生效）", {
    my $s = time-magic-capture(q{time store-set('tval', 99)});
    is store-get('tval'), 99, 'store 被写入';
    ok $s.text.contains('OK'), '仍成功';
    store-del('tval');
};

subtest "time-magic：错误表达式走错误路径", {
    my $s = time-magic-capture('time this-routine-does-not-exist-xyz');
    ok $s.text.contains('ERR'),  '失败态 ERR';
    ok $s.text.contains('错误'), '有错误渲染';
};

done-testing;
