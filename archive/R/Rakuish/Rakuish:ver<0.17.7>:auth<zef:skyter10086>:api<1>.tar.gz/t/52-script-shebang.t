use v6;
use Test;

# 脚本模式认 shebang（G5，0.16.4）。
#
# 以前脚本模式**不管文件写的是什么**，一律当 Raku 脚本求值 ⇒
# `rakuish run x.sh`（`#!/bin/bash`）报
#   "Two terms in a row across lines (missing semicolon or comma?)"
# —— 看着像语法错，其实是**用错了语言**。
#
# 全部用真实子进程验证：脚本模式的合同就是进程的 stdout / stderr / 退出码。

plan 14;

my $root = $?FILE.IO.dirname.IO.parent;
my @base = ($*EXECUTABLE.Str, '-I', $root.add('lib').Str,
            $root.add('bin/rakuish').Str);

sub run-file(Str $fname, Str $src, *@args) {
    my $f = $*TMPDIR.add("rk-shebang-{$*PID}-{(1000..9999).pick}-{$fname}");
    $f.spurt($src);
    my $p = run(|@base, $f.Str, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    $f.unlink;
    %( code => $p.exitcode, out => $out, err => $err );
}

# ── 1. shebang 指向 bash ⇒ 用 bash 跑，不是 Raku ─────────────────────
{
    my %r = run-file('a.sh', "#!/bin/bash\necho hello-from-bash\n");
    is %r<code>, 0, 'bash 脚本退出码 0';
    is %r<out>, "hello-from-bash\n", 'bash 脚本的 stdout 原样落地';
}

# ── 2. 退出码原样带回来 ─────────────────────────────────────────────
{
    my %r = run-file('b.sh', "#!/bin/bash\nexit 3\n");
    is %r<code>, 3, 'bash 脚本的退出码原样传回';
}

# ── 3. `#!/bin/sh` 与 `#!/usr/bin/env bash` 也认 ────────────────────
{
    my %r = run-file('c.sh', "#!/bin/sh\necho sh-ok\n");
    is %r<out>, "sh-ok\n", '#!/bin/sh 用 sh 跑';
    my %r2 = run-file('d.sh', "#!/usr/bin/env bash\necho env-bash\n");
    is %r2<out>, "env-bash\n", '#!/usr/bin/env bash 用 bash 跑';
}

# ── 4. 没有 shebang 的 .sh ⇒ 按后缀兜底用 bash ──────────────────────
{
    my %r = run-file('e.sh', "echo no-shebang-bash\n");
    is %r<out>, "no-shebang-bash\n", '无 shebang 的 .sh 走 bash';
}

# ── 5. Raku 脚本仍然是 Raku（护栏：别把这条路径改坏）───────────────
{
    my %r = run-file('f.rakuish', "say 'raku-ok';\n");
    is %r<out>, "raku-ok\n", '无 shebang 的 .rakuish 仍走 Raku';

    my %r2 = run-file('g.rakuish', "#!/usr/bin/env raku\nsay 'raku-shebang';\n");
    is %r2<out>, "raku-shebang\n", '#!/usr/bin/env raku 仍走 Raku';

    # stress/ 里的十个脚本就是这个形式 —— 绝不能被当成外部脚本
    my %r3 = run-file('h.rakuish', "#!/usr/bin/env -S rakuish run\nsay 'rakuish-shebang';\n");
    is %r3<out>, "rakuish-shebang\n", '#!/usr/bin/env -S rakuish run 仍走 Raku';
}

# ── 6. 别的解释器也认（python3）─────────────────────────────────────
{
    my %r = run-file('i.py', "#!/usr/bin/env python3\nprint('py-ok')\n");
    is %r<code>, 0, 'python3 脚本退出码 0';
    is %r<out>, "py-ok\n", 'python3 脚本的 stdout 原样落地';
}

# ── 7. 脚本参数原样传过去 ───────────────────────────────────────────
{
    # ⚠ `$1` 必须转义 —— 否则 Raku 会把它当插值变量（Nil）⇒
    #   "Use of Nil in string context"
    my %r = run-file('j.sh', "#!/bin/bash\necho \"arg=\$1\"\n", 'hello');
    is %r<out>, "arg=hello\n", '脚本参数传给外部解释器';
}

# ── 8. stderr 直通、stdout 不带 REPL 装饰 ───────────────────────────
{
    my %r = run-file('k.sh', "#!/bin/bash\necho oops >&2\necho out\n");
    is %r<out>, "out\n", 'stdout 只有程序输出（无 In[n]/Out[n] 装饰）';
    is %r<err>, "oops\n", 'stderr 原样透传';
}
