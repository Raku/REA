use lib "lib";
use Test;
use Rakuish::Loop;

plan 9;

# 绝对路径补全：根目录下的 /home、/tmp 等
ok complete-at('cd /ho', 6).grep(*.ends-with('/home')), '绝对路径 /ho -> /home';
ok complete-at('ls /tm', 6).grep(*.ends-with('/tmp')),  '绝对路径 /tm -> /tmp';
ok complete-at('!cd /ho', 7).grep(*.ends-with('/home')), 'shell 行绝对路径 /ho -> /home';

# 家目录 ~ 展开
ok complete-at('cd ~/', 5).elems > 0, '~/ 能列出家目录';
my $ra = 'cd ~/Rakui';
ok (complete-at($ra, $ra.chars).grep(*.ends-with('~/Rakuish')) \
    || complete-at($ra, $ra.chars).grep(*.ends-with('/Rakuish'))), '~/Rakui -> ~/Rakuish（或绝对形式）';

# 相对路径（当前目录内）补全，回归保护
ok complete-at('ls lib/Rakui', 12).grep(*.ends-with('lib/Rakuish')), '相对路径 lib/Rakui -> lib/Rakuish';
ok complete-at('%load lib/Rakui', 15).grep(*.ends-with('lib/Rakuish')), 'magic %load 相对路径补全';

# 不存在的前缀不应产生错误条目
nok complete-at('cd /zzz-no-such', 13).grep(*.contains('zzz-no-such')), '不存在前缀不产生幽灵补全';

# 验证 file-entries 对绝对路径不再被 $*CWD 吞掉：/home 必在根目录列出
ok('/'.IO.dir.map(*.basename).grep('home').elems == 1, '根目录确实含 /home（环境前提）');
