use lib 'lib';
use Test;
use Rakuish::Shell::Exec;
use Rakuish::Shell::Expand;
use Rakuish::Shell::Parser;

# t/53-native-parity.t —— native 后端与 bash 的**语义对齐**回归
# （§10.2-2：语义对齐扫描的落地）
#
# 这个文件锁住两件事：
#
# ① **空参数不能被丢掉**（展开层）
#    bash 里 `""` 是**一个空参数**：`[ -n "" ]` 判假、`echo ""` 输出空行。
#    以前 native 的展开层**不产生片段** ⇒ 空参数被静默丢掉
#    ⇒ `[ -n "" ]` 变成 `[ -n ]`（单参数测试）⇒ **恒为真**
#    —— 两边都「成功」，结果却不同 ⇒ 最危险的一类（静默分歧）。
#
# ② **控制流关键字必须明确报不支持**（语法层）
#    native 不实现 if / for / while / case / 函数 … 以前这些行被当成
#    「一条名叫 `if` 的命令」⇒ stderr 冒三行 `command not found`，
#    stdout 空、退出码 127 ⇒ **看起来跑了，其实什么都没跑**。
#    ⇒ 按「半懂半猜比不支持更糟」，识别出来就明确报不支持（退出码 2）。

subtest "展开层：显式引号里的空参数**必须保留**", {
    my @w = expand-words(['[', '-n', '""']);
    is @w.elems, 3, '三个词（含那个空参数）';
    is @w[2], q{}, '第三个词是空串（不是「消失」）';

    my @w2 = expand-words(['echo', '""']);
    is @w2.elems, 2, '`echo ""` 也是一个空参数';
    is @w2[1], q{}, '它是空串';

    my @w3 = expand-words(['echo', "''"]);
    is @w3.elems, 2, '单引号空串同样保留';

    my @w4 = expand-words(['echo', 'a""b']);
    is @w4.elems, 2, '`a""b` 仍是一个词';
    is @w4[1], 'ab', '内容是 ab';
};

subtest "展开层：裸位置的空展开仍然**不产生**参数（bash 语义）", {
    my @w = expand-words(['echo', '$RK_EMPTY_VAR']);
    is @w.elems, 1, '空变量展开不产生词';
};

subtest "native：`[ -n 空参数 ]` 判假（与 bash 一致）", {
    my $r = run-shell-line('[ -n "" ]; echo "rc=$?"', :capture(True));
    is $r.stdout.trim, 'rc=1', 'bash 是 rc=1（空串非非空）';
    is $r.code, 0, '整行成功';
};

subtest "native：`[ -z 空参数 ]` 判真（与 bash 一致）", {
    my $r = run-shell-line('[ -z "" ]; echo "rc=$?"', :capture(True));
    is $r.stdout.trim, 'rc=0', 'bash 是 rc=0';
};

subtest "语法层：shell 保留字（控制流）被识别", {
    my @words = <if then else elif fi case esac for while until do done select function coproc>;
    for @words -> $w {
        is reserved-word($w), $w, "「$w」是保留字";
    }
    is reserved-word('echo'), q{}, '普通命令名不是保留字';
    is reserved-word('in'), q{}, '`in` 不拦（可能真是命令名）';
    is reserved-word('time'), q{}, '`time` 不拦（/usr/bin/time 存在）';
};

subtest "native：控制流构造**明确报不支持**（不是 command not found）", {
    my @cf-lines = (
        'if [ -d /tmp ]; then echo d; fi',
        'for i in 1 2; do echo $i; done',
        'while true; do break; done',
        'case x in x) echo X;; esac',
        'f() { echo hi; }; f',
    );
    for @cf-lines -> $line {
        my $r = run-shell-line($line, :capture(True));
        is $r.code, 2, "「$line」退出码 2（bash 的语法错误码）";
        ok $r.stderr.contains('不支持'), "「$line」明确说「不支持」";
        ok !$r.stderr.contains('command not found'),
            "「$line」不是「当成普通命令跑」（没有 command not found）";
    }
};

subtest "native：算术命令 `(( … ))` 明确报不支持", {
    my $r = run-shell-line('((1+1))', :capture(True));
    is $r.code, 2, '退出码 2';
    ok $r.stderr.contains('不支持'), '明确说「不支持」';
};

subtest "native：普通命令**不受**保留字判定影响", {
    my $r = run-shell-line('echo if', :capture(True));
    is $r.code, 0, '`echo if` 正常跑';
    is $r.stdout.trim, 'if', '输出 if（if 在这里是参数，不是保留字）';
};

done-testing;
