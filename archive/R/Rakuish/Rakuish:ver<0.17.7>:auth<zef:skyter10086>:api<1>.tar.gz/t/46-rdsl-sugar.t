use v6;
use Test;
use lib 'lib';

use Rakuish::Result;

# C 方案 P3：DSL 糖之一 —— `:in`（喂 stdin）与 `.paths`（输出当路径列表）
#
# `:in` 的两种调用形式必须都对：
#   run 'grep -c x' :in("...")     ← shell 行（过引擎 /bin/sh）
#   run 'grep', '-c', 'x', :in(…)  ← argv（直接 exec，不过 shell）
# 两条链路实现完全不同（引擎走临时文件传 --stdin，argv 走 CORE::run 的
# `:in(handle)`），所以要分别断言，别只测一条就当都好了。

plan 13;

# ── ① argv 形式 ──────────────────────────────────────────────────────
my $a = run 'cat', :in("hello\nworld\n");
is $a.code, 0, 'argv + :in 正常退出';
is $a.out, "hello\nworld\n", 'argv 形式 :in 真的喂到 stdin';

# ── ② shell 行形式 ──────────────────────────────────────────────────
my $b = run 'wc -l', :in("a\nb\nc\n");
is $b.out.trim, '3', 'shell 行形式 :in 生效（引擎链路）';

my $c = run-pipe 'cat', 'wc -l', :in("1\n2\n");
is $c.out.trim, '2', 'run-pipe 也透传 :in';

# ── ③ 边界：不传 / 空串 ─────────────────────────────────────────────
my $d = run 'printf x';
is $d.out, 'x', '不传 :in 时行为不变（回归）';

# "" 与「没传」必须区分：空串是「有 stdin 但内容为空」，不是「继承终端」。
# 若两者混了，`run 'cat' :in("")` 会挂住等终端，这条就是探针。
my $e = run 'cat', :in('');
is $e.out, '', q{:in("") 是空 stdin，不是继承终端};

# ── ④ 临时文件不残留 ────────────────────────────────────────────────
sub leftovers(--> Int) {
    $*TMPDIR.dir.grep({ .basename.contains('rakuish-run-in') }).elems
}
my $before = leftovers();
run 'cat', :in("x\n");
is leftovers(), $before, ':in 用的临时文件已清理';

# ── ⑤ .paths ────────────────────────────────────────────────────────
my $ls = run q{printf 'a.txt\nb/c.txt\n\n'};
is $ls.paths.elems, 2, '.paths 丢空行';
isa-ok $ls.paths[0], IO::Path, '.paths 元素是 IO::Path';
is $ls.paths[0].Str, 'a.txt', '.paths 保持相对形式（不是全绝对化）';
is $ls.paths[0].absolute.Str, $*CWD.add('a.txt').absolute.Str,
    '.paths 的相对路径按当前 CWD 解析';
is $ls.paths[1].Str, 'b/c.txt', '.paths 保留子目录形态';
is run(q{printf ''}).paths.elems, 0, '空输出 ⇒ 空列表（不是含一个空串）';
