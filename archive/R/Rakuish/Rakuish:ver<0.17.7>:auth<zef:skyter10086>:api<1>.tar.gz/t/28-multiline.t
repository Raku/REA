use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Incomplete;

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method print(*@a)      { @.lines.push: @a.join; Nil }
    method flush()         { }
}

# 用注入的 reader 跑真实的 drive（不需要 tty），返回合并后的输出。
# 脚本里放一个 Nil 就模拟「续行途中按 Ctrl-D」——reader-from 读完就返回 Nil。
sub run-block(*@script --> Str) {
    my $s = Sink.new;
    { temp $*OUT = $s; drive(reader-from(@script), :color(False)); }
    $s.lines.join("\n")
}

# ── 1. 三种括号都能跨行 ───────────────────────────────────────────────
my $o = run-block(q[for 1..3 {], q[    say 5], q[}]);
ok  $o.contains('5'),      q{花括号块：块内语句执行了};
ok !$o.contains(q{错误}), q{花括号块：无报错};

$o = run-block(q[my @a = (], q[1,], q[2], q[);], q[say @a.elems]);
ok $o.contains('Out[1]: [1, 2]'), q{圆括号跨行：拼成数组};

$o = run-block(q{my $s = [1,}, q{2];}, q[say $s.elems]);
ok $o.contains('Out[1]: [1, 2]'), q{方括号跨行};

# ── 2. 行尾运算符续行（本轮修的真 bug）───────────────────────────────
# 根因：join-lines 会在源码末尾补 "\n"，而 is-incomplete 当时只看 @lines[*-1]
# （于是拿到空串）→ 行尾运算符判定被跳过，`my $x = 1 +` 永远不续行。
$o = run-block(q[my $x = 1 +], q[2;], q[say $x]);
ok  $o.contains('Out[1]: 3'), q{行尾运算符续行生效（尾换行曾让它失效）};
ok !$o.contains(q{错误}),     q{行尾运算符：无报错};

ok is-incomplete(q[my $x = 1 +] ~ "\n"), q{带尾换行仍判为未写完};

# ── 3. 回归护栏：cd .. 不能被误判成「没写完」────────────────────────
# @TRAILING 里曾有 `..`，而 `cd ..` 是 5 个字的完整命令 —— 判定生效后会吃掉
# 下一行输入、命令不生效（t/19 因此挂过）。触发式判定按 REPL 频率取舍。
ok !is-incomplete(q[cd ..]),        q{cd .. 判为写完};
ok !is-incomplete(q[cd ..] ~ "\n"), q{cd .. 带尾换行也判为写完};

# ── 4. 块中间的空行不终止续行 ────────────────────────────────────────
$o = run-block(q[for 1..2 {], q[    say 6], q[ ], q[}]);
ok  $o.contains('6'),      q{块中间空行不终止续行};
ok !$o.contains(q{错误}), q{块中间空行：无报错};

# ── 5. Ctrl-D 只取消当前块，不杀会话 ────────────────────────────────
# 旧行为是 `last without $more`，在续行里按 Ctrl-D 会把整个会话丢掉。
$o = run-block(q[for 1..2 {], Nil, q[say 42]);
ok $o.contains(q{已取消这一块}), q{Ctrl-D 给出取消提示};
ok $o.contains('Out[1]: True'),   q{取消后 cell 序号未被消耗（后一条拿到 Out[1]）};
ok !$o.contains(q{错误}),         q{被取消的块不产生报错};

# ── 6. 多余闭括号：立刻报错，而不是傻等下一行 ────────────────────────
$o = run-block(q[say 1], q[)], q[say 2]);
ok $o.contains('Out[1]: True'), q{多余闭括号：前一条已正常执行};
ok $o.contains(q{错误}),         q{多余闭括号：立刻报错};
ok $o.contains('Out[3]: True'), q{多余闭括号：会话继续（报错那格不产生 Out 但仍占序号）};

# ── 7. heredoc 不触发续行 ────────────────────────────────────────────
# 实测两后端的 EVAL 通道都不支持 heredoc（<<TAG 被当 quote-words 下标，
# qq:to 报 Two terms in a row）。继续等待只会让用户多敲几行再看同一个错。
ok !is-incomplete(q[say <<END]), q{heredoc 不触发续行};

# ── 8. 回归护栏：以 / < > 结尾的行不是「悬空运算符」──────────────────
# @TRAILING 是触发式判定，这几个字符在 REPL 里的典型用法都不是运算符：
#   `ls lib/` 是以 / 结尾的路径、`<a b>` 是以 > 结尾的 quote-words 词表。
# 放进 @TRAILING 会让这些行被当成「没写完」，吃掉下一行输入。
ok !is-incomplete(q[ls lib/]), q{ls lib/ 不触发续行};
ok !is-incomplete(q[cat ..]),  q{cat .. 不触发续行};
my $words = q{<} ~ q[a b>];    # 一层 q{} 写不出 <a b>（内嵌 { 会撑破外层引号）
ok !is-incomplete($words), q{quote-words 词表不被当成悬空运算符};

# ── 9. 回归护栏：ls 带 flag 时交给真实 ls ────────────────────────────
# 之前内建把 `-la` 当成目录名，报 "ls: 不是目录或不存在: /tmp/-la"。
$o = run-block(q[ls -la]);
ok !$o.contains(q{不是目录或不存在}), q{ls -la 不会把 -la 当成目录名};

done-testing;
