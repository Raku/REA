use lib 'lib';
use Test;
use Rakuish::Shell::Exec;
use Rakuish::Shell::Expand;

# t/34-shell-exec.t —— 原生 shell 层的执行（端到端）
#
# 这一层真的 fork / pipe / dup2，所以它验的是**行为**而不是结构。
# 验收基线来自 v/selftest.v 的 24 项（V 版那套 shell 层的自测），
# 逐条搬过来，另外补上本实现特有的用例。
#
# ⚠ 断言刻意**不写死外部命令的报错原文**（"No such file or directory" 这类
# 文本随 locale / coreutils 版本变），只断言「stderr 非空」与「含路径」——
# 否则这条测试会在别的机器上假红。

my $SQ = chr(39);
my $DQ = chr(34);

my $TMP = '/tmp/rakuish-t34';

sub fresh-path(Str $name --> Str) {
    my $p = $TMP ~ '-' ~ $name;
    try { unlink $p };
    $p
}

subtest "管道：两段真的串起来", {
    my $r = run-shell-line('echo hi | tr a-z A-Z', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'HI', 'stdout 是 HI';
    ok $r.passed, '走了捕获路径';
}

subtest "三段管道", {
    my $r = run-shell-line('echo abc | tr a-z A-Z | rev', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'CBA', 'stdout 是 CBA';
}

subtest "重定向落盘 + 追加", {
    my $p = fresh-path('redir.txt');
    my $r1 = run-shell-line('printf REDIRECTED > ' ~ $p, :capture(True));
    is $r1.code, 0, '写入退出码 0';
    ok (try { slurp($p) }).defined, '文件生成了';
    is (try { slurp($p) }).trim, 'REDIRECTED', '内容是 REDIRECTED';

    my $r2 = run-shell-line('printf -NAPPED >> ' ~ $p, :capture(True));
    is $r2.code, 0, '追加退出码 0';
    my $text = try { slurp($p) };
    ok $text.contains('REDIRECTED'), '原内容还在';
    ok $text.contains('-NAPPED'), '追加的内容在';
    try { unlink $p };
}

subtest "stderr 重定向：2> file 单独落盘", {
    my $p = fresh-path('err.txt');
    my $r = run-shell-line('ls /rakuish-no-such-path 2> ' ~ $p, :capture(True));
    ok $r.code != 0, 'ls 失败 → 退出码非 0';
    my $text = try { slurp($p) };
    ok $text.chars > 0, '错误信息落到了文件里';
    ok $text.contains('rakuish-no-such-path'), '错误信息里有路径';
    is $r.stderr, q{}, '捕获到的 stderr 是空的（已被重定向走）';
    try { unlink $p };
}

subtest "2>&1：stderr 并进 stdout", {
    my $r = run-shell-line('ls /rakuish-no-such-path 2>&1', :capture(True));
    ok $r.stdout.chars > 0, 'stdout 有内容';
    ok $r.stdout.contains('rakuish-no-such-path'), '内容里有路径';
}

subtest "2>&1 在管道里也生效", {
    my $r = run-shell-line('ls /rakuish-no-such-path 2>&1 | cat', :capture(True));
    ok $r.stdout.chars > 0, '管道下游收到了 stderr';
    ok $r.stdout.contains('rakuish-no-such-path'), '内容里有路径';
}

subtest "> f 2>&1：两条重定向都生效", {
    # 【V 版最深的一个坑】V 的 fd_dup2 以 fd 1 为目标会静默失效，
    # 于是这个组合落盘的是空文件。我们直接调 libc dup2，没有那个问题。
    my $p = fresh-path('both.txt');
    my $r = run-shell-line('ls /rakuish-no-such-path > ' ~ $p ~ ' 2>&1', :capture(True));
    my $text = try { slurp($p) };
    ok $text.chars > 0, '文件非空';
    ok $text.contains('rakuish-no-such-path'), 'stderr 也进了文件';
    try { unlink $p };
}

subtest "&> 一并重定向", {
    my $p = fresh-path('amp.txt');
    my $r = run-shell-line('ls /rakuish-no-such-path &> ' ~ $p, :capture(True));
    my $text = try { slurp($p) };
    ok $text.chars > 0, '文件非空';
    ok $text.contains('rakuish-no-such-path'), 'stderr 进了文件';
    try { unlink $p };
}

subtest "stdin 重定向", {
    my $p = fresh-path('in.txt');
    spurt($p, "from-file\n");
    my $r = run-shell-line('cat < ' ~ $p, :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'from-file', '读到了文件内容';
    try { unlink $p };
}

subtest "分号：按顺序执行两条", {
    my $r = run-shell-line('echo one ; echo two', :capture(True));
    is $r.stdout.lines.elems, 2, '两行输出';
    is $r.stdout.lines[0].trim, 'one', '第 1 行';
    is $r.stdout.lines[1].trim, 'two', '第 2 行';
}

subtest "! 取反：退出码翻转", {
    my $r1 = run-shell-line('! true', :capture(True));
    is $r1.code, 1, '! true → 退出码 1';
    my $r2 = run-shell-line('! false', :capture(True));
    is $r2.code, 0, '! false → 退出码 0';
}

subtest "命令不存在 → 127", {
    my $r = run-shell-line('rakuish-no-such-command-xyz', :capture(True));
    is $r.code, 127, '退出码 127';
    ok !$r.found, 'found=False';
}

subtest "变量展开", {
    %*ENV<RK_EXEC_TEST> = 'v42';
    my $r = run-shell-line('echo $RK_EXEC_TEST', :capture(True));
    is $r.stdout.trim, 'v42', '变量被展开';
    my $r2 = run-shell-line('echo "$RK_EXEC_TEST"', :capture(True));
    is $r2.stdout.trim, 'v42', '双引号里也展开';
    my $r3 = run-shell-line('echo ' ~ $SQ ~ '$RK_EXEC_TEST' ~ $SQ, :capture(True));
    is $r3.stdout.trim, '$RK_EXEC_TEST', '单引号里不展开';
}

subtest "带空格的引号参数不被拆开", {
    my $r = run-shell-line('echo ' ~ $DQ ~ 'a b' ~ $DQ, :capture(True));
    is $r.stdout.trim, 'a b', '是一个参数';
}

subtest "家目录展开 ~user（端到端）", {
    my $root-home = home-of('root');
    ok $root-home.chars > 0, 'root 的家目录查得到';
    my $r = run-shell-line('echo ~root', :capture(True));
    is $r.stdout.trim, $root-home, 'echo ~root → 家目录';
    my $r2 = run-shell-line('ls -d ~root', :capture(True));
    is $r2.stdout.trim, $root-home, 'ls -d ~root → 家目录';
    is $r2.code, 0, '退出码 0';
}

subtest "glob 展开进参数", {
    my $dir = '/tmp/rakuish-t34-glob';
    my $dp = $dir.IO;
    $dp.mkdir unless $dp.e;
    for <a b> -> $n { spurt($dir ~ '/' ~ $n ~ '.txt', 'x'); }
    my $r = run-shell-line('echo ' ~ $dir ~ '/*.txt', :capture(True));
    is $r.stdout.split(' ').elems, 2, '展开成 2 个参数';
    try { unlink $dir ~ '/a.txt' };
    try { unlink $dir ~ '/b.txt' };
}

subtest "不原生支持的语法 → 整段回退给 sh", {
    # `$(...)` 从 2026-11 起**原生支持**了（命令替换），语义断言在
    # t/37-shell-cmdsub.t。
    ok native-supported('echo $(date)'), '$(...) 现在原生支持';
    ok native-supported('echo a | grep a'), '管道原生支持';
    ok native-supported('echo a > /tmp/x'), '重定向原生支持';
    ok native-supported('echo $?'), '$? 现在原生支持';
    ok !native-supported('echo $!'), '$! 仍不原生支持';

    # `$?` 是**会话状态**（上一条命令的退出码），语义断言在
    # t/39-shell-special-params.t。这里只验「能跑通」。
    run-shell-line('true', :capture(True));    # 先把退出码归零
    my $r = run-shell-line('echo $?', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, '0', '$? 展开成上一条命令的退出码';
}

subtest "空行与纯空白", {
    my $r = run-shell-line('   ', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout, q{}, '没有输出';
}

done-testing;
