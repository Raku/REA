use lib "lib";
use Test;
use Rakuish::Slow;

# 测试数据里凡含 { } " $ 一律用 chr 拼：`q{...}` 的内容里出现 { 或 }
# 会改变定界符配对，导致整个字符串被截断（实测 q{grep -n "hello world" x}
# 的 .chars 只有 1 个元素）。这是 Rakuish 要处理的输入形态本身。
my $DQ = chr(34);        # "
my $DQ2 = chr(34) ~ chr(34);   # ""
my $BS = chr(92);        # 反斜杠
my $NL = chr(10);        # 换行

# ── 慢档：让真 sh 跑shell ─────────────────────────────────────────────
# 设计前提（两个实现上实测对拍过，见模块头）：
#   · `run()` 不接返回值就**继承 fd1** → 输出流式直通、原生 ANSI 全保留
#   · `sh -c '…'` 包一层后，命令不存在给**127 + stderr 消息**（两边一致）
#   · `.slurp(:close)` 是读管道的唯一可用读法（`readline` 两个实现都没有）
#
# 所以慢档的形状是：**默认直通（不捕获），需要加工时才捕获**。
# 加工必然失去流式 —— 这是不可兼得的，必须做成两档而不是偷偷降级。

subtest "shell-escape：引号正确性", {
    # 单引号包裹 + 内部单引号用 '\'' 收尾再续一个 —— POSIX 标准做法
    is sh-quote('simple'), q{'simple'}, '无特殊字符也加引号（统一处理）';
    is sh-quote(q{a b}), q{'a b'}, '含空格';
    is sh-quote(q{it's}), q{'it'\''s'}, '含单引号';
    is sh-quote(q{a"b}), q{'a"b'}, '含双引号（单引号里不用转义）';
    is sh-quote(q{a$b}), q{'a$b'}, '含 $（单引号里不展开）';
    is sh-quote(q{}), q{''}, '空串';
}

# 注意：**不要用 `list(split-argv(...))`**。sub 末尾的裸 `@argv` 会让
# `list()` 收到两个值（列表 + 末尾表达式的 True），于是多出一个元素。
# 直接 `my @x = split-argv(...)` 才是对的。
subtest "命令拆成 argv：引号/空格不切错", {
    # grep / -n / "hello world" / a.txt = **4 个词**
    # （我一开始写成 3，然后一路把"正确的 4"当成"多了一个"去改实现 ——
    #  该数清楚再动手。）
    my $line = 'grep -n ' ~ $DQ ~ 'hello world' ~ $DQ ~ ' a.txt';
    my @argv = split-argv($line);
    is @argv.elems, 4, '4 个词';
    is @argv[0], 'grep', 'argv[0]';
    is @argv[1], '-n', 'argv[1]';
    is @argv[2], 'hello world', '带空格的引号段是一个词';
    is @argv[3], 'a.txt', '引号段后面的词没被粘进来';
}

subtest "命令拆成 argv：转义与引号", {
    my @argv = split-argv(q{echo 'a b'});
    is @argv.elems, 2, '单引号段是一个词';
    is @argv[1], 'a b', '内容正确';

    my @b = split-argv('echo a' ~ $BS ~ ' b');
    is @b.elems, 2, '反斜杠转义空格';
    is @b[1], 'a b', '转义生效';

    my @c = split-argv(q{});
    is @c.elems, 0, '空命令 -> 空 argv';
}

subtest "含管道的命令：交给 sh 跑整段", {
    # `yes | head -3` 这类必须整段交 sh，不能自己在 Raku 里搭
    my $shape = needs-sh(q{yes | head -3});
    ok $shape, '含管道 -> 走 sh';
    ok needs-sh(q{a && b}), '含&& -> 走 sh';
    ok needs-sh(q{a; b}), '含分号 -> 走 sh';
    ok needs-sh(q{a > f}), '含重定向 -> 走 sh';
    ok !needs-sh(q{cd /tmp}), '纯命令不需要 sh';
    ok !needs-sh(q{ls -l}), 'ls 不需要 sh';
    ok !needs-sh(q{grep -n foo f.txt}), '带参数但无元字符 -> 不需要 sh';
    ok !needs-sh(q{echo a\|b}), '反斜杠转义的元字符不算';
}

subtest "run-result：状态与输出的分离", {
    # 直通模式下没有输出可拿，只有状态
    my $r = SlowResult.new(:code(0), :found(True), :passed(False));
    ok $r.ok, 'code 0 -> ok';
    is $r.code, 0, 'code 0';

    my $f = SlowResult.new(:code(127), :found(False), :passed(False));
    ok !$f.ok, '非 0 -> 不 ok';
    ok !$f.found, 'found=False（命令不存在）';
    is $f.code, 127, 'code 127';
}

subtest "need-capture：默认不加工就不捕获", {
    ok !needs-capture(q{ls -l}), '默认直通不捕获';
    ok needs-capture(q{ls -l}, :numbers(True)), '要求行号就捕获';
}

subtest "数字标注：给捕获到的输出加行号", {
    # 注意期望值里的换行必须用 $NL —— 写在双引号里的 \n 是**真换行**，
    # 于是 "1 │ a\n2 │ b" 变成多行字符串，跟单行的实际输出比不上。
    my $BAR = chr(0x2502);
    my $NL  = chr(10);
    is number-lines('a' ~ $NL ~ 'b' ~ $NL ~ 'c', :numbers(True)),
        '1 ' ~ $BAR ~ ' a' ~ $NL ~ '2 ' ~ $BAR ~ ' b' ~ $NL ~ '3 ' ~ $BAR ~ ' c',
        '三行都编号';
    is number-lines('a' ~ $NL ~ 'b', :numbers(False)), 'a' ~ $NL ~ 'b', '不编号时原样';
    is number-lines(q{}, :numbers(True)), q{}, '空输出不产生只有编号的行';
    is number-lines('a' ~ $NL, :numbers(True)), '1 ' ~ $BAR ~ ' a', '末尾换行不多算一行';
}

subtest "汇总块：跑完脚本给一行摘要", {
    my $s = summary-line('demo.sh', 1, :duration(0.42));
    ok $s.contains('demo.sh'), '含脚本名';
    ok $s.contains('exit 1'),  '含退出码';
    ok $s.contains('0.42'),    '含耗时';
}

subtest "summary：退出码 0 与非 0 要能区分", {
    ok summary-line('a.sh', 0, :duration(0.1)).contains('exit 0'), 'exit 0';
    ok summary-line('a.sh', 2, :duration(0.1)).contains('exit 2'), 'exit 2';
}

done-testing;