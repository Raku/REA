use v6;
use Test;
use lib 'lib';

use Rakuish::Result;
use Rakuish::Eval;

# C 方案 P1：脚本 DSL —— run() 返回 Result，管道在 Raku 侧可组合
#
# 这里测两层：
#   ① 单元层：Result 的取值/谓词/派生方法（直接调模块，不经 REPL）
#   ② 集成层：EVAL 里的 `run` 是否真被 prelude 接到 Rakuish::Result
#      （这一层才是用户实际接触到的东西 —— 少了它，模块再对也没用）

plan 26;

# ── ① 单元层 ────────────────────────────────────────────────────────

my $r = run(q{printf 'a\nb\nc\n'});
isa-ok $r, Result, 'run() 返回 Result 而不是 Proc';
is $r.code, 0, '.code 是命令退出码';
is $r.ok, True, '.ok 在退出码 0 时为真';
is $r.lines.elems, 3, '.lines 按行切分';
is $r.lines.head, 'a', '.lines 首行';
is $r.head, 'a', '.head 取首行';
is $r.tail, 'c', '.tail 取末行';
is $r.head(2).join(','), 'a,b', '.head(2) 取前两行';
is $r.Str, "a\nb\nc", '.Str 剥掉尾部换行（bash $(cmd) 语义）';
is $r.words.elems, 3, '.words 分词';
is $r.grep({ .contains('b') }).elems, 1, '.grep 在行上过滤';
is $r.map(*.uc).join(','), 'A,B,C', '.map 在行上映射';
is $r.join('-'), 'a-b-c', '.join 拼接行';

# stderr 与退出码**分开**，互不污染
my $bad = run(q{echo oops >&2; exit 3});
is $bad.code, 3, '非零退出码原样回传';
is $bad.ok, False, '.ok 在非零时为假';
is $bad.err.trim, 'oops', '.err 独立捕获 stderr';
is $bad.out, '', '.out 不含 stderr';
is $bad.Int, 3, 'Int 强转给退出码';
ok $bad.gist.contains('退出码 3'), '.gist 在失败时提示退出码';

# 多参数形式：直接 exec，参数里的空格不需要自己转义
is run('echo', '-n', 'a b').out, 'a b', '多参数走 exec，不经 shell';

# .json：零依赖解析（环境没装 JSON::Fast 时走内置解析器）
my $j = run(q{printf '%s' '{"a":{"b":[1,2,3]},"s":"x\ny","t":true,"n":null}'});
is $j.json<a><b>[1], 2, '.json 解析嵌套数组';
is $j.json<s>, "x\ny", '.json 处理转义';
is $j.json<t>, True, '.json 处理 true';

# run-pipe：真管道（左侧的 stdout 接右侧的 stdin）
is run-pipe(q{printf 'x\ny\nz\n'}, 'grep y').head, 'y', 'run-pipe 串联真管道';

# ── ② 集成层：EVAL prelude ──────────────────────────────────────────

my $st = LexState.new;
my $c1 = eval-cell(q{run('echo hi').head}, :state($st));
is $c1.ok, True, 'EVAL 里 run 可用（prelude 生效）';
is $c1.value, 'hi', 'EVAL 里拿到的就是 Result 的方法返回值';
