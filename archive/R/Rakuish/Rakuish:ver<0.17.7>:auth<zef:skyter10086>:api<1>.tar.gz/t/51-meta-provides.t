use Test;

my $cwd   = $*CWD;
my @lines = 'META6.json'.IO.lines;

# lib 下所有模块文件（递归，相对路径）
my @files;
sub walk(IO::Path:D $d) {
    for $d.dir {
        when .d     { walk($_) }
        when .f     { @files.push(.relative($cwd).Str) if .extension eq 'rakumod' }
    }
}
walk($cwd.add('lib'));
@files = @files.sort;

# META6 provides 里登记的路径
my @parts  = @lines.map({ .split('"')[3] });
my @listed = @parts.grep({ .defined && .ends-with('.rakumod') });
@listed = @listed.sort;

is @files.elems, @listed.elems,
    "META6 provides 条目数({@listed.elems}) 应等于 lib 下模块文件数({@files.elems})";

my %have = @listed.Set;
my @missing = @files.grep({ !%have{$_} });
is @missing.join(','), '',
    "以下模块未登记进 META6 provides（zef 安装后会缺文件）: {@missing.join(', ')}";

# bin 里的版本回退常量必须与 META6.json 一致（防止安装后 --version 漂移）
my $metav = ~@lines.grep({ .contains('"version"') })[0].match(/ '"version"' \s* ':' \s* '"' (<-["]>+) '"' /)[0];
my $binv  = ~'bin/rakuish'.IO.slurp.match(/ 'FALLBACK_VERSION' \s* '=' \s* "'" (<-["']>+) "'" /)[0];
is $binv, $metav, "bin/rakuish 的 FALLBACK_VERSION({$binv}) 与 META6 版本({$metav}) 一致";

done-testing;
