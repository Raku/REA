use v6;
use lib "lib";
use Test;
use Rakuish::Loop;

# 守住「颜色可关」契约：04-loop.t 对 prompt-for 做精确字符串判等，
# 一旦默认带颜色就会误伤；同时确认开颜色时确实注入 ANSI、且提示符本体仍在。
plan 10;

my $ESC = chr(27);

# ── 默认（无颜色）：精确等于历史期望 ──────────────────────────────
is prompt-for(False, '/tmp'), 'rakuish:/tmp> ', '首行带目录（无颜色精确匹配）';
is prompt-for(True,  '/tmp'), '      ....1> ',  '续行（无颜色，尾部仅一个空格）';
is prompt-for(False, q{}),     'rakuish:> ',    '无目录时只有冒号';
ok !prompt-for(False, '/tmp').contains($ESC), '无颜色时不含 ANSI 转义';

# ── 开颜色：应注入 ANSI，且保留提示符本体 ───────────────────────
my $p-colored = prompt-for(False, '/tmp', :color(True));
ok $p-colored.contains($ESC ~ '[36m'), '首行颜色含青色 (ESC[36m)';
ok $p-colored.contains('rakuish') && $p-colored.contains('/tmp') && $p-colored.ends-with('> '),
   '首行颜色含 rakuish、cwd，且以 "> " 结尾';

my $c-colored = prompt-for(True, '/tmp', :color(True));
ok $c-colored.contains($ESC ~ '[90m'), '续行颜色含暗色 (ESC[90m)';
ok $c-colored.contains('      ....1> '), '续行颜色保留本体 ....1> ';

# ── welcome-text ────────────────────────────────────────────────
my $w  = welcome-text('LineEditor');
ok $w.contains('Rakuish') && !$w.contains($ESC), '欢迎语无颜色时不含转义但含项目名';
my $wc = welcome-text('LineEditor', :color(True));
ok $wc.contains('Rakuish') && $wc.contains($ESC), '欢迎语有颜色时含转义与项目名';
