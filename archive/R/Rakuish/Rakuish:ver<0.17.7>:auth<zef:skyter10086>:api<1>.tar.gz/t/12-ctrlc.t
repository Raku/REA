use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Eval;

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    # 真 IO::Handle 既有 say 也有 print；用户 cell 里的 `say` 最终走 print，
    # 所以这里也得有，否则 drive 跑 `say ...` 会报 "Cannot resolve caller print"。
    method print($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}

# 清掉可能遗留的标志（跨 subtest 隔离）。take-interrupt 幂等：取出并清零，
# 没置位时返回 False 也无副作用。注意**不要**直接引用模块变量 $INTERRUPTED
# —— rakupp 会把它当成自动声明的词法变量，导致清标志与置标志不是同一个槽。
sub clear-interrupt() { take-interrupt() }

subtest "note-interrupt / take-interrupt 标志机", {
    clear-interrupt();
    nok take-interrupt(), '初始无中断';
    note-interrupt();
    ok take-interrupt(),  'note 后置位、take 取出';
    nok take-interrupt(), '取出后自动清除';
};

subtest "drive 在循环开头报告已中断并继续", {
    clear-interrupt();
    my $sink = Sink.new;
    temp $*OUT = $sink;
    note-interrupt();                 # 模拟上一轮 cell 途中被 Ctrl-C
    my $rc = drive(reader-from('1', '%quit'), :color(False));
    ok $sink.text.contains('已中断'),        '报告 已中断';
    ok $sink.text.contains('Out[1]: 1'),    '被中断的那一轮仍正常求值';
    is $rc, 0, '正常退出';
};

subtest "drive 标志未被置则无提示", {
    clear-interrupt();
    my $sink = Sink.new;
    temp $*OUT = $sink;
    my $rc = drive(reader-from('42', '%quit'), :color(False));
    ok $sink.text.contains('Out[1]: 42'), '正常求值';
    ok !$sink.text.contains('已中断'),     '没有误报';
    is $rc, 0, '退出码 0';
};

subtest "install-signal-handler 可安全调用（不抛）", {
    my $ok = True;
    try { install-signal-handler() }
    $ok = False if $!;
    ok $ok, '调用不抛异常';
};

done-testing;
