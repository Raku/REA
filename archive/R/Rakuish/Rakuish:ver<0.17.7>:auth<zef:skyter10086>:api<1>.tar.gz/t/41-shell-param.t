use lib 'lib';
use Test;
use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;
use Rakuish::Shell::Expand;
use Rakuish::Shell::Exec;
use Rakuish::Shell::Session;

# t/41-shell-param.t —— 原生 shell 层的**参数展开** `${...}`
#
# 本文件覆盖 bash 的参数展开算子（全部期望值来自 **bash 5.3.9 实测**，
# 对拍脚本见本文件末尾）：
#
#   · 取值 `${V}` 与长度 `${#V}`
#   · 默认值 `${V:-w}` / `${V-w}`（**冒号**看「空」，不带冒号只看「没设置」）
#   · 赋值 `${V:=w}` / `${V=w}`（有副作用）
#   · 报错 `${V:?msg}` / `${V?msg}`（**中止这条命令**）
#   · 备用值 `${V:+w}` / `${V+w}`
#   · 删前缀 / 后缀 `${V#p}` `${V##p}` `${V%p}` `${V%%p}`
#   · 替换 `${V/p/r}` `${V//p/r}` `${V/#p/r}` `${V/%p/r}`
#   · 大小写 `${V^}` `${V^^}` `${V,}` `${V,,}`
#   · 截取子串 `${V:off}` `${V:off:len}`
#   · **引号规则**：裸位置 vs 双引号内，操作数里的引号生效与否
#
# ⚠ 本文件里的 shell 命令**一律用单引号**写：Raku 的双引号串里
#   `${...}` 是哈希下标、`$(` 是代码插值 —— 写成双引号会得到
#   莫名其妙的编译错误。

my $SQ = chr(39);
my $DQ = chr(34);

# 跑一行，取 stdout（去掉尾部换行）。
sub run-out(Str $line --> Str) {
    my $r = run-shell-line($line, :capture(True));
    $r.stdout.Str.trim
}

# ══════════════════════════════════════════════════════════════════════
# ① 取值与长度
# ══════════════════════════════════════════════════════════════════════

subtest "取值与长度", {
    set-var('P41', 'hello');
    is run-out('echo ${P41}'), 'hello', '${VAR} 取值';
    is run-out('echo ${#P41}'), '5', '${#VAR} 是长度';
    is run-out('echo $P41'), 'hello', '普通形式（对照）';
    unset-var('P41');
    is run-out('echo ${#P41}'), '0', '未设置的变量长度是 0';
}

# ══════════════════════════════════════════════════════════════════════
# ② 默认值：`:-` 看「空」，`-` 只看「没设置」
# ══════════════════════════════════════════════════════════════════════

subtest "默认值 :- 与 -", {
    unset-var('P41B');
    is run-out('echo "[${P41B:-d}]"'), '[d]', '没设置 ⇒ :- 用默认值';
    is run-out('echo "[${P41B-d}]"'), '[d]', '没设置 ⇒ - 也用默认值';

    set-var('P41B', q{});
    is run-out('echo "[${P41B:-d}]"'), '[d]',
        '⚠ 设成**空** ⇒ :- 仍然用默认值（冒号看「空」）';
    is run-out('echo "[${P41B-d}]"'), '[]',
        '⚠ 设成**空** ⇒ - **不用**默认值（不带冒号只看「没设置」）';
    unset-var('P41B');
}

subtest "备用值 :+ 与 +", {
    unset-var('P41C');
    is run-out('echo "[${P41C:+x}]"'), '[]', '没设置 ⇒ :+ 不用备用值';
    is run-out('echo "[${P41C+x}]"'), '[]', '没设置 ⇒ + 不用备用值';

    set-var('P41C', 'v');
    is run-out('echo "[${P41C:+x}]"'), '[x]', '设置且非空 ⇒ :+ 用备用值';
    is run-out('echo "[${P41C+x}]"'), '[x]', '设置 ⇒ + 用备用值';

    set-var('P41C', q{});
    is run-out('echo "[${P41C:+x}]"'), '[]', '设成空 ⇒ :+ 不用（它看「非空」）';
    is run-out('echo "[${P41C+x}]"'), '[x]', '设成空 ⇒ + 仍然用（它只看「设置」）';
    unset-var('P41C');
}

subtest "赋值 := 与 =（有副作用）", {
    unset-var('P41D');
    is run-out('echo "${P41D:=d}"'), 'd', '没设置 ⇒ := 赋值并返回';
    is lookup('P41D'), 'd', '⚠ 变量真的被赋值了（副作用）';

    set-var('P41E', q{});
    is run-out('echo "${P41E:=d}"'), 'd', '设成空 ⇒ := 赋值';
    is lookup('P41E'), 'd', '副作用生效';

    set-var('P41F', 'v');
    is run-out('echo "${P41F:=d}"'), 'v', '已设置 ⇒ := 不用默认值';
    is lookup('P41F'), 'v', '变量没被改';

    unset-var('P41D'); unset-var('P41E'); unset-var('P41F');
}

# ══════════════════════════════════════════════════════════════════════
# ③ 报错 :? / ?（bash 会**中止**这条命令）
# ══════════════════════════════════════════════════════════════════════

subtest ':? 与 ?：报错 + 中止这条命令', {
    unset-var('P41G');
    my $r = run-shell-line('echo "[${P41G:?msg}]"', :capture(True));
    is $r.stdout.Str.trim, q{}, 'stdout 是空的（bash 里 echo 根本不跑）';
    is $r.code, 1, '退出码 1';
    ok $r.stderr.Str.contains('msg'), 'stderr 里有自定义的消息';

    # 设成空 ⇒ `:?` 也报错（它看「空」）
    set-var('P41G', q{});
    my $r2 = run-shell-line('echo "[${P41G:?msg}]"', :capture(True));
    is $r2.code, 1, '设成空 ⇒ :? 同样中止';
    unset-var('P41G');

    # 不带冒号的 `?` 只看「没设置」
    set-var('P41H', q{});
    my $r3 = run-shell-line('echo "[${P41H?msg}]"', :capture(True));
    is $r3.code, 0, '设成空 ⇒ ? 不报错（它只看「没设置」）';
    is $r3.stdout.Str.trim, '[]', '正常展开成空串';
    unset-var('P41H');

    # 中止的是这一条命令：前面的照跑，后面的不跑
    my $r4 = run-shell-line('echo one; echo "${P41I:?msg}"; echo two',
                            :capture(True));
    is $r4.stdout.Str.trim, 'one', '前面的命令照跑';
    is $r4.code, 1, '整行退出码 1';
}

# ══════════════════════════════════════════════════════════════════════
# ④ 删前缀 / 后缀
# ══════════════════════════════════════════════════════════════════════

subtest "删前缀 # 与 ##", {
    set-var('P41J', 'a/b/c.txt');
    is run-out('echo ${P41J#*/}'), 'b/c.txt', '# 删**最短**匹配的前缀';
    is run-out('echo ${P41J##*/}'), 'c.txt', '## 删**最长**匹配的前缀';
    unset-var('P41J');

    set-var('P41K', 'hello.txt');
    is run-out('echo ${P41K#*.}'), 'txt', '按 glob 模式删前缀';
    is run-out('echo ${P41K##*.}'), 'txt', '只有一个 * 时两者相同';
    unset-var('P41K');
}

subtest "删后缀 % 与 %%", {
    set-var('P41L', 'a/b/c.txt');
    is run-out('echo ${P41L%/*}'), 'a/b', '% 删**最短**匹配的后缀';
    is run-out('echo ${P41L%%/*}'), 'a', '%% 删**最长**匹配的后缀';
    unset-var('P41L');

    set-var('P41M', 'abc.txt');
    is run-out('echo ${P41M%.*}'), 'abc', '按 glob 模式删后缀';
    unset-var('P41M');
}

# ══════════════════════════════════════════════════════════════════════
# ⑤ 替换
# ══════════════════════════════════════════════════════════════════════

subtest "替换 / // /# /%", {
    set-var('P41N', 'aaa');
    is run-out('echo ${P41N/a/X}'), 'Xaa', '/ 只替换**第一处**';
    is run-out('echo ${P41N//a/X}'), 'XXX', '// 替换**所有**处';
    unset-var('P41N');

    set-var('P41O', 'abc');
    is run-out('echo ${P41O/#a/X}'), 'Xbc', '/# 替换**前缀**（锚定）';
    is run-out('echo ${P41O/%c/X}'), 'abX', '/% 替换**后缀**（锚定）';
    unset-var('P41O');

    set-var('P41P', 'aXbXc');
    is run-out('echo ${P41P//X/-}'), 'a-b-c', '替换所有分隔符';
    unset-var('P41P');

    set-var('P41Q', 'abc');
    is run-out('echo ${P41Q/b/}'), 'ac', '替换成空串';
    unset-var('P41Q');
}

# ══════════════════════════════════════════════════════════════════════
# ⑥ 大小写
# ══════════════════════════════════════════════════════════════════════

subtest "大小写转换", {
    set-var('P41R', 'hello');
    is run-out('echo ${P41R^}'), 'Hello', '^ 只转**首字符**';
    is run-out('echo ${P41R^^}'), 'HELLO', '^^ 转**全部**';
    unset-var('P41R');

    set-var('P41S', 'HELLO');
    is run-out('echo ${P41S,}'), 'hELLO', ', 只转**首字符**';
    is run-out('echo ${P41S,,}'), 'hello', ',, 转**全部**';
    unset-var('P41S');
}

# ══════════════════════════════════════════════════════════════════════
# ⑦ 截取子串
# ══════════════════════════════════════════════════════════════════════

subtest "截取子串 :off 与 :off:len", {
    set-var('P41T', 'abcdef');
    is run-out('echo ${P41T:2}'), 'cdef', '从第 3 个字符开始';
    is run-out('echo ${P41T:2:3}'), 'cde', '偏移 + 长度';
    is run-out('echo ${P41T: -2}'), 'ef', '负偏移 = 从末尾数';
    is run-out('echo ${P41T:1:-1}'), 'bcde', '负长度 = 到倒数第几个之前';
    unset-var('P41T');
}

# ══════════════════════════════════════════════════════════════════════
# ⑧ 引号规则
# ══════════════════════════════════════════════════════════════════════

subtest "操作数里的引号：按当前上下文处理（bash 语义）", {
    # ⚠ 变量必须**没设置**才会用到默认值（设置了就用变量自己的值）
    unset-var('P41U');

    my $printf = 'printf ' ~ $SQ ~ '[%s]' ~ $SQ ~ ' ';

    # ── 裸位置：操作数里的引号**生效**（保护空格 ⇒ 一个词）──
    is run-out($printf ~ '${P41U:-"a b"}'), '[a b]',
        '裸位置 + 双引号 ⇒ **一个**词（引号保护空格）';
    is run-out($printf ~ '${P41U:-' ~ $SQ ~ 'a b' ~ $SQ ~ '}'), '[a b]',
        '裸位置 + 单引号 ⇒ **一个**词';
    is run-out($printf ~ '${P41U:-a b}'), '[a][b]',
        '裸位置 + 无引号 ⇒ **两个**词（空格是分词点）';

    # ── 双引号内：结果**不分词**；单引号是**字面量** ──
    is run-out($printf ~ '"${P41U:-"a b"}"'), '[a b]',
        '双引号内 + 双引号 ⇒ 一个词';
    is run-out($printf ~ '"${P41U:-' ~ $SQ ~ 'a b' ~ $SQ ~ '}"'), "['a b']",
        '⚠ 双引号内 + 单引号 ⇒ 单引号是**字面量**（bash 语义）';
}

subtest "操作数里的变量会展开", {
    unset-var('P41V');
    set-var('P41W', 'DEF');
    is run-out('echo ${P41V:-$P41W}'), 'DEF', '操作数里的 $VAR 照样展开';
    unset-var('P41W');
}

# ══════════════════════════════════════════════════════════════════════
# ⑨ 词法层：不认识的写法 ⇒ 整行交 sh
# ══════════════════════════════════════════════════════════════════════

subtest "词法层：认得出来的写法原生支持", {
    is lex('echo ${V:-d}', :cmdsub(True)).unsupported, q{}, '${V:-d} 认得';
    is lex('echo ${V#p}', :cmdsub(True)).unsupported, q{}, '${V#p} 认得';
    is lex('echo ${V//p/r}', :cmdsub(True)).unsupported, q{}, '${V//p/r} 认得';
    is lex('echo ${#V}', :cmdsub(True)).unsupported, q{}, '${#V} 认得';
    is lex('echo ${V^^}', :cmdsub(True)).unsupported, q{}, '${V^^} 认得';
    is lex('echo ${V:1:2}', :cmdsub(True)).unsupported, q{}, '${V:1:2} 认得';
}

subtest "词法层：认不出来的写法整行交 sh", {
    ok lex('echo ${V@Q}', :cmdsub(True)).unsupported ne q{},
        '${V@Q} 不认 ⇒ 交 sh（bash 自己会报 bad substitution）';
    ok lex('echo ${V:-a', :cmdsub(True)).unsupported ne q{},
        '没闭合的 ${…} ⇒ 交 sh';
}

# ── 对拍说明 ─────────────────────────────────────────────────────────
# 上面每个期望值都来自 bash 5.3.9 的实测：
#   bash -c 'V=; echo "[${V:-d}]"'      → [d]
#   bash -c 'V=; echo "[${V-d}]"'       → []
#   bash -c 'V=; echo "[${V+x}]"'       → [x]
#   bash -c 'V=a/b/c.txt; echo ${V##*/}' → c.txt
#   bash -c 'V=a/b/c.txt; echo ${V%%/*}' → a
#   bash -c 'V=aaa; echo ${V//a/X}'     → XXX
#   bash -c 'V=abc; echo ${V/#a/X}'     → Xbc
#   bash -c 'V=hello; echo ${V^^}'      → HELLO
#   bash -c 'V=abcdef; echo ${V:2:3}'   → cde
#   bash -c 'V=abc; echo "${V:-"a b"}"' → "a b"（引号是字面量）
#   bash -c 'echo "${V:?msg}"'          → 空 + "V: msg" 错误 + 退出码 1

done-testing;
