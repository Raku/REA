use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Eval;

subtest "magic 名补全（% 前缀）", {
    my @c = complete-at('%ru', 3);
    ok @c.elems == 1 && @c[0] eq '%run', '输入 %ru 补全为 %run';

    my @all = complete-at('%', 1);
    ok @all.grep(* eq '%help').elems > 0, '只有 % 列出全部 magic';
    ok @all.grep(* eq '%run').elems  > 0, '包含 %run';
};

subtest "shell 命令名补全（! 前缀）", {
    my @c = complete-at('!sh', 3);
    ok @c.grep(* eq '!sh').elems > 0, '能补全出 !sh';
};

subtest "store 键补全（Raku 上下文）", {
    store-set('myvar', 42);
    my @c = complete-at('say myv', 7);
    ok @c.grep(*.ends-with('myvar')).elems > 0, '补全出 myvar';
};

subtest "文件名补全（当前目录）", {
    my @c = complete-at('cat li', 6);
    ok @c.grep(*.ends-with('lib')).elems > 0, '补全出 lib';
};

subtest "返回类型是 List", {
    my @c = complete-at('xyz', 3);
    ok @c ~~ List, '返回 List';
};

done-testing;
