use lib 'lib';
use Test;
use Rakuish::Shell::Lexer;

# t/31-shell-lexer.t —— 原生 shell 层的词法
#
# 这一层是**纯逻辑**：没有进程、没有 IO、没有正则。
# 正因如此它必须在**两个 Raku 实现上逐条一致**（MoarVM 与 rakupp）——
# 这也是 Platform 层隔离思路的延续。
#
# 写法约定：**含引号/反斜杠的样例一律用 chr() 拼**，
# 不用转义序列（引号会被定界符咬到，见 t/01 的文件头注释）。

my $SQ = chr(39);        # 单引号
my $DQ = chr(34);        # 双引号
my $BS = chr(92);        # 反斜杠
my $BT = chr(96);        # 反引号

# 取第 n 个 token 的文本
sub tok-text($lexed, Int $i --> Str) { $lexed.tokens[$i].text }
sub tok-kind($lexed, Int $i --> Str) { $lexed.tokens[$i].kind }

subtest "引号词切分：引号保留在文本里", {
    my $l = lex('echo ' ~ $SQ ~ 'a $B' ~ $SQ ~ ' ' ~ $DQ ~ 'c d' ~ $DQ);
    is $l.tokens.elems, 3, '3 个 token';
    is tok-text($l, 0), 'echo', '第 1 个是命令名';
    is tok-text($l, 1), $SQ ~ 'a $B' ~ $SQ, '单引号文本原样保留';
    is tok-text($l, 2), $DQ ~ 'c d' ~ $DQ, '双引号文本原样保留';
    ok $l.tokens[1].quoted, '单引号词 quoted=True';
    ok $l.tokens[2].quoted, '双引号词 quoted=True';
    ok !$l.tokens[0].quoted, '裸词 quoted=False';
    is $l.unsupported, q{}, '没有不支持的语法';
}

subtest "重定向记号：>> 与 &> 都是单个 op", {
    my $l = lex('echo hi >> log.txt');
    is $l.tokens.elems, 4, '4 个 token';
    is tok-kind($l, 2), 'op', '第 3 个是 op';
    is tok-text($l, 2), '>>', '>> 没有被拆成两个 >';

    # `&>` 必须被切成**单个** op —— 否则 parser 看到裸 `&`
    # 会把当前命令提前切掉，重定向落到错误的 command 上
    my $l2 = lex('ls /nope &> out.txt');
    my $ands = 0;
    for @($l2.tokens) -> $t { $ands++ if $t.kind eq 'op' and $t.text eq '&>'; }
    is $ands, 1, '恰好 1 个 &> op';
    is $l2.unsupported, q{}, '&> 本身是支持的';
}

subtest "管道与分号切出 op", {
    my $l = lex('a | b ; c');
    is $l.tokens.elems, 5, '5 个 token';
    is tok-text($l, 1), '|', '第 2 个是 |';
    is tok-text($l, 3), ';', '第 4 个是 ;';
    is tok-kind($l, 1), 'op', '管道是 op';
}

subtest "&& 与 || 合并成单个 op（不合并会被看成两条流水线）", {
    my $l = lex('a && b');
    is tok-text($l, 1), '&&', '&& 是一个 op';
    my $l2 = lex('a || b');
    is tok-text($l2, 1), '||', '|| 是一个 op';
    # 注意：**词法层不判**「不支持」—— 它只负责把 && 合并成一个 op，
    # 判定放在语法层（那里才知道它不是自己认识的算子）。见 t/32。
}

subtest "裸 & 标记为不支持（后台作业不做）", {
    my $l = lex('a & b');
    ok $l.unsupported ne q{}, '裸 & 不支持';
}

subtest "! 只在词首切 op", {
    my $l = lex('! false');
    is tok-kind($l, 0), 'op', '词首的 ! 是 op';
    is tok-text($l, 0), '!', '文本是 !';
    my $l2 = lex('echo hi!');
    is $l2.tokens.elems, 2, 'echo hi! 是两个词';
    is tok-text($l2, 1), 'hi!', '词内的 ! 属于词内容（没被切成 op）';
}

subtest "反斜杠转义：转义空格不切词", {
    my $l = lex('echo a' ~ $BS ~ ' b');
    is $l.tokens.elems, 2, '2 个词';
    is tok-text($l, 1), 'a' ~ $BS ~ ' b', '转义空格留在同一个词里';
}

subtest "双引号内的转义引号不结束引号段", {
    # 这是移植时修掉的一个**真 bug**（V 版在这里把反斜杠丢了，
    # 于是 \" 变成裸 " → 提前结束引号段 → 后面整段被切错）
    my $l = lex('echo ' ~ $DQ ~ 'a' ~ $BS ~ $DQ ~ 'b' ~ $DQ);
    is $l.tokens.elems, 2, '2 个词（没被切成 3 个）';
    is tok-text($l, 1), $DQ ~ 'a' ~ $BS ~ $DQ ~ 'b' ~ $DQ, '整段是一个词';
}

subtest "不原生支持的语法会被标记出来（交给 sh）", {
    ok lex('echo $(date)').unsupported ne q{}, '$(...) 命令替换';
    ok lex('echo ' ~ $BT ~ 'date' ~ $BT).unsupported ne q{}, '反引号命令替换';
    ok lex('{ echo x; }').unsupported ne q{}, '{ } 复合命令';
    ok lex('(cd /tmp)').unsupported ne q{}, '( ) 子 shell';
    # 2026-11-04 起 `$?` / `$$` **原生支持**了（见 t/39-shell-special-params.t）
    is lex('echo $?').unsupported, q{}, '$? 现在原生支持';
    is lex('echo $$').unsupported, q{}, '$$ 现在原生支持';
    # 2026-11-03 起这两条**原生支持**了（heredoc / ~user 家目录展开）
    ok lex('cat <<EOF').unsupported eq q{}, '<< heredoc 现在原生支持';
    ok lex('echo ~user').unsupported eq q{}, '~user 现在原生支持';
    ok lex('cat <<<EOF').unsupported ne q{}, '<<< herestring 仍交 sh';
    ok lex('echo a').unsupported eq q{}, '普通命令不受影响';
    is lex('echo "a $?"').unsupported, q{}, '双引号内的 $? 现在原生支持';
    # 仍然交 sh 的特殊参数（后台 PID / 参数个数 / 位置参数 / 选项标志）
    ok lex('echo $!').unsupported ne q{}, '$! 仍交 sh';
    ok lex('echo $#').unsupported ne q{}, '$# 仍交 sh';
    ok lex('echo $@').unsupported ne q{}, '$@ 仍交 sh';
    # `${VAR}` 是**变量**（不是 brace 组），也原生支持
    is lex('echo ${HOME}').unsupported, q{}, '${VAR} 原生支持';
}

subtest "has-unquoted-glob：只有裸位置的 * / ? 才算 glob", {
    ok has-unquoted-glob('*.txt'), '裸 * 触发';
    ok has-unquoted-glob('a?b'), '裸 ? 触发';
    ok !has-unquoted-glob('"*.txt"'), '双引号内不触发';
    ok !has-unquoted-glob($SQ ~ '*.txt' ~ $SQ), '单引号内不触发';
    ok !has-unquoted-glob($BS ~ '*.txt'), '反斜杠转义的不触发';
    ok !has-unquoted-glob('plain.txt'), '没有元字符不触发';
}

done-testing;
