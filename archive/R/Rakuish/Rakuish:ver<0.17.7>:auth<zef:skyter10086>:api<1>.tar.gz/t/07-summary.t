use lib "lib";
use Test;
use Rakuish::Slow;

subtest "count-lines：末尾换行不额外算一行", {
    is count-lines("a\nb\n"), 2, '两行 + 末尾换行 = 2';
    is count-lines("a\nb"),   2, '两行无末尾换行 = 2';
    is count-lines(""),       0, '空串 = 0';
    is count-lines("\n\n"),   0, '只有换行 = 0';
};

subtest "disp-width：CJK 算 2，ASCII 算 1", {
    is disp-width("ab"), 2, '两个 ASCII = 2';
    is disp-width("行"), 2, '一个汉字 = 2';
    is disp-width("a行"), 3, 'a + 汉字 = 3';
};

subtest "summary-box：三行且上下边框对齐", {
    my $b = summary-box("x.sh", 0, :duration(1.23),
                        :stdout-lines(3), :stderr-lines(0));
    my @ls = $b.split("\n");
    is @ls.elems, 3, '三行：上边框 / 内容 / 下边框';
    ok @ls[1].contains("exit 0"),    '有退出码';
    ok @ls[1].contains("1.23s"),     '有耗时';
    ok @ls[1].contains("stdout 3"),  '有 stdout 行数';
    my $w = disp-width(@ls[1]);
    is disp-width(@ls[0]), $w, '上边框宽度 = 内容宽度';
    is disp-width(@ls[2]), $w, '下边框宽度 = 内容宽度';
};

subtest "SlowResult 现在带 stdout / stderr", {
    my $r = run-shell(q{echo out; echo err >&2}, :capture(True));
    ok $r.stdout.contains('out'),  'stdout 字段有内容';
    ok $r.stderr.contains('err'),  'stderr 字段有内容';
    ok $r.out.contains('out') && $r.out.contains('err'), 'out 仍是合并';
};

done-testing;
