use Test;
use lib 'lib';
use Rakuish::Eval;

# 直接验证 render-out 的 dump 风格渲染（不进入 REPL 循环）。
# 回归点：之前 list/hash 超过 12 元素会被折叠成 "[…[ (N items)" 隐藏全部内容。

sub r($n, $v) { render-out($n, $v, :color(False)) }

# 100 元素数组：应完整显示内容，不被折叠
my @a = 1..100;
my $s = r(3, @a);
like $s, /'1, 2, 3'/,   '数组 dump 显示开头元素';
like $s, /'99, 100'/,   '数组 dump 显示结尾元素';
nok $s.contains('(100 items)'), '中等数组不折叠（仍能看到全部内容）';

# 1000 元素：超过 $DUMP-WIDTH，应头尾采样并标注真实总数
my @b = 1..1000;
my $t = r(4, @b);
like $t, /'1, 2, 3, 4'/,          '大数组采样显示头部';
like $t, /'997, 998, 999, 1000'/, '大数组采样显示尾部';
like $t, /'1000 items'/,           '大数组标注真实总数';

# 标量 dump 风格
is r(5, True),   'Out[5]: True',   'Bool 紧凑显示';
is r(6, False),  'Out[6]: False',  'Bool 紧凑显示（假）';
is r(7, 42),     'Out[7]: 42',     'Int';
is r(8, Nil),    'Out[8]: Nil',    'Nil';
is r(9, 1..100), 'Out[9]: 1..100', 'Range';
is r(10, "hi\nml"), 'Out[10]: "hi\\nml"', '多行 Str 用 \\n 转义';

done-testing;
