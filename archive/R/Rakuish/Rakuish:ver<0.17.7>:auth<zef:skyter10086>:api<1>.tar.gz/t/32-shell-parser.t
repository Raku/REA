use lib 'lib';
use Test;
use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;

# t/32-shell-parser.t —— 原生 shell 层的语法
#
# 结构（bash 的三层）：
#   一行 → 多个 Pipeline（`;` 分隔）→ 多个 Command（`|` 分隔）
#   Command → 参数 + 重定向
#
# 纯逻辑，两个实现必须逐条一致。

my $SQ = chr(39);
my $DQ = chr(34);

# 解析一行（词法 + 语法）
sub parse-line(Str $line --> Parsed) { parse(lex($line).tokens) }

subtest "流水线结构", {
    my $p = parse-line('echo hi | tr a-z A-Z ; ls -l');
    is $p.pipelines.elems, 2, '2 条流水线';
    is $p.pipelines[0].commands.elems, 2, '第 1 条有 2 段';
    is $p.pipelines[0].commands[0].args.elems, 2, '第 1 段有 2 个参数';
    is $p.pipelines[0].commands[1].args[0], 'tr', '第 2 段是 tr';
    is $p.pipelines[1].commands.elems, 1, '分号后 1 条命令';
    is $p.pipelines[1].commands[0].args[0], 'ls', '是 ls';
}

subtest "参数内容保留引号（剥引号是展开阶段的事）", {
    my $p = parse-line('echo ' ~ $DQ ~ 'a b' ~ $DQ);
    is $p.pipelines[0].commands[0].args[1], $DQ ~ 'a b' ~ $DQ, '带引号的文本原样保留';
}

subtest "stderr 重定向：2> file", {
    my $p = parse-line('ls /nope 2> err.txt');
    is $p.pipelines.elems, 1, '1 条流水线';
    my $c = $p.pipelines[0].commands[0];
    is $c.redirs.elems, 1, '1 条重定向';
    is $c.redirs[0].kind, 'out', 'kind=out';
    is $c.redirs[0].fd, 2, '源 fd=2';
    is $c.redirs[0].target, 'err.txt', '目标是 err.txt';
    # 数字前缀 2 不能泄漏进 args
    my $leaked = False;
    for @($c.args) -> $a { $leaked = True if $a eq '2'; }
    ok !$leaked, 'fd 前缀 2 没有泄漏进 args';
    is $c.args[0], 'ls', '命令名还在';
}

subtest "stdin 重定向：< file 的默认 fd 必须是 0", {
    # 写成 1 会让 cat 去读终端，**抢走 REPL 的下一行输入**（V 版实测踩过）
    my $p = parse-line('cat < in.txt');
    my $c = $p.pipelines[0].commands[0];
    is $c.redirs.elems, 1, '1 条重定向';
    is $c.redirs[0].kind, 'in', 'kind=in';
    is $c.redirs[0].fd, 0, '源 fd=0（不是 1）';
    is $c.redirs[0].target, 'in.txt', '目标文件';
}

subtest "追加重定向：>> 是 append", {
    my $p = parse-line('echo hi >> log.txt');
    my $c = $p.pipelines[0].commands[0];
    is $c.redirs.elems, 1, '1 条重定向';
    is $c.redirs[0].kind, 'append', 'kind=append';
    is $c.redirs[0].fd, 1, '默认源 fd=1';
    is $c.redirs[0].target, 'log.txt', '目标文件';
}

subtest "fd 复制：2>&1 与 >&2", {
    my $p = parse-line('ls /nope > f 2>&1');
    my $c = $p.pipelines[0].commands[0];
    is $c.args.elems, 2, 'args 没被污染';
    is $c.args[0], 'ls', '命令名';
    is $c.args[1], '/nope', '参数';
    is $c.redirs.elems, 2, '2 条重定向';
    is $c.redirs[0].kind, 'out', '第 1 条是 out';
    is $c.redirs[0].fd, 1, '第 1 条 fd=1';
    is $c.redirs[0].target, 'f', '第 1 条目标';
    is $c.redirs[1].kind, 'dup', '第 2 条是 dup';
    is $c.redirs[1].fd, 2, '第 2 条 fd=2';
    is $c.redirs[1].dup-fd, 1, '第 2 条 dup-fd=1';

    my $p2 = parse-line('ls >&2');
    my $c2 = $p2.pipelines[0].commands[0];
    is $c2.redirs.elems, 1, '1 条重定向';
    is $c2.redirs[0].kind, 'dup', 'kind=dup';
    is $c2.redirs[0].fd, 1, '无前缀时源 fd=1';
    is $c2.redirs[0].dup-fd, 2, '目标是 2';
}

subtest "&> 展开成 out + dup(2->1)", {
    my $p = parse-line('ls /nope &> out.txt');
    my $c = $p.pipelines[0].commands[0];
    is $c.redirs.elems, 2, '2 条重定向';
    is $c.redirs[0].kind, 'out', '第 1 条 out';
    is $c.redirs[0].fd, 1, '第 1 条 fd=1';
    is $c.redirs[0].target, 'out.txt', '第 1 条目标';
    is $c.redirs[1].kind, 'dup', '第 2 条 dup';
    is $c.redirs[1].fd, 2, '第 2 条 fd=2';
    is $c.redirs[1].dup-fd, 1, '第 2 条 dup-fd=1';
}

subtest "! 取反：只标记，不污染命令", {
    my $p = parse-line('! false');
    is $p.pipelines.elems, 1, '1 条流水线';
    ok $p.pipelines[0].negated, 'negated 已置位';
    my $c = $p.pipelines[0].commands[0];
    is $c.args.elems, 1, '命令只有 1 段';
    is $c.args[0], 'false', '参数没被 ! 污染';
}

subtest "重定向属于当前 command（不会被甩给下一条）", {
    my $p = parse-line('echo x >> log ; echo y');
    is $p.pipelines.elems, 2, '2 条流水线';
    is $p.pipelines[0].commands[0].redirs.elems, 1, '重定向挂在第 1 条上';
    is $p.pipelines[1].commands[0].redirs.elems, 0, '第 2 条没有重定向';
}

subtest "不认识的算子 → 标记不支持（整段交 sh）", {
    # `<<` heredoc 从 2026-11-03 起原生支持（语义断言在 t/38）
    ok parse-line('cat <<EOF').unsupported eq q{}, '<< 现在原生支持';
    ok parse-line('cat <<<EOF').unsupported ne q{}, '<<<';
    ok parse-line('a >>> b').unsupported ne q{}, '>>>';
    ok parse-line('echo hi').unsupported eq q{}, '普通命令不受影响';
    # `&&` / `||` 现在**原生支持**了（2026-10-31 起）——
    # 语义断言在 t/36-shell-andor.t。
    ok parse-line('a && b').unsupported eq q{}, '&& 现在原生支持';
    ok parse-line('a || b').unsupported eq q{}, '|| 现在原生支持';
}

done-testing;
