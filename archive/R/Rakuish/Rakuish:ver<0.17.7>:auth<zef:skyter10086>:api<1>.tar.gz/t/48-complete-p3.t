use v6;
use Test;
use lib 'lib';
use Rakuish::Loop;
use Rakuish::Builtins;

# C 方案 P3：PATH 自动补全
#
# 三件事：
#   ① `!` 行首与 `run '…'` 首参的候选 = PATH 命令 + 内建 + 别名
#      （内建和别名不在 PATH 里，但它们确实能当命令敲）
#   ② `run` 首参补出来的命令名**必须带引号**（Raku 里裸词不是命令名）
#   ③ PATH 扫描结果按 PATH 串缓存（`export PATH=…` 后自动失效）
#
# ⚠ 全部平铺断言，不用 subtest：`temp %*ENV` 要留在主线程才稳。

plan 17;

# ── ① 候选合并 ──────────────────────────────────────────────────────
temp %*ENV<PATH> = '/usr/local/bin:/usr/bin:/bin';
reset-command-cache();

ok command-candidates().elems > 20, 'PATH 里扫出了命令';
is command-candidates().grep({ $_ eq 'ls' }).elems, 1, 'ls 在候选里且只出现一次';
is command-candidates().grep({ $_ eq 'cd' }).elems, 1, '内建 cd 进候选（不在 PATH 里）';
is command-candidates().grep({ $_ eq 'export' }).elems, 1, '内建 export 进候选';
is command-candidates().grep({ $_ eq 'echo' }).elems, 1,
    'echo 既是内建又在 /bin ⇒ 去重后仍只有一条';

{
    temp %ALIASES<zzalias> = 'echo';
    ok command-candidates().grep({ $_ eq 'zzalias' }).elems, '别名进候选';
}

# ── ② run 首参定位 ──────────────────────────────────────────────────
is run-arg-kind(q{run 'ls}),        'cmd', 'run 首个参数 → 补命令名';
is run-arg-kind(q{my $x = run 'l}), 'cmd', '赋值右侧的 run 首参也算';
is run-arg-kind(q{run('l}),         'cmd', '括号形式首参';
is run-arg-kind(q{run('ls', '/t}),  'arg', '第二个参数 → 只补路径';
is run-arg-kind(q{ls -l}),          q{},   '不是 run 的参数 → 走常规补全';
is run-arg-kind(q{run 'ls -l}),     q{},
    'run 里已进到第二个 shell 词 ⇒ 交给常规补全（路径）';

# ── ③ 补全结果要带引号 ──────────────────────────────────────────────
my @c = complete-at(q{run 'gr}, 8);
ok @c.grep({ $_ eq q{run 'grep'} }), 'run 首参补出 grep，并补上右引号';
ok @c.grep({ $_ eq 'run grep' }).elems == 0, '不会给出没引号的裸词形式';

{
    temp %ALIASES<zzalias> = 'echo';
    ok complete-at(q{!zzal}, 6).grep({ $_ eq '!zzalias' }), '`!` 首词补别名';
}

# ── ④ 缓存按 PATH 串失效 ────────────────────────────────────────────
my $dir = $*TMPDIR.add("rakuish-cache-{$*PID}-{(1000..9999).pick}");
$dir.mkdir;
my $exe = $dir.add('rakuish-zzz-testcmd');
$exe.spurt: "#!/bin/sh\nexit 0\n";
$exe.chmod(0o755);
{
    temp %*ENV<PATH> = $dir.Str;
    reset-command-cache();
    ok command-candidates().grep({ $_ eq 'rakuish-zzz-testcmd' }),
        '换 PATH 后新命令立刻可见（缓存按 PATH 串分键，用不着手动清）';
}
{
    temp %*ENV<PATH> = '/usr/bin:/bin';
    nok command-candidates().grep({ $_ eq 'rakuish-zzz-testcmd' }),
        'PATH 换回去后它也消失（证明缓存真的按 PATH 分键）';
}
$exe.unlink;
$dir.rmdir;
