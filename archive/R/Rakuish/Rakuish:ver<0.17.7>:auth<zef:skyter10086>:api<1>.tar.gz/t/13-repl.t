use Test;
use lib 'lib';
use Rakuish::Loop;
use Rakuish::Eval;

# 用一个临时文件当 .repl，避免污染真实 HOME / 重复运行互相干扰
my $tmp = $*TMPDIR.add('rakuish-repl-test-' ~ $*PID ~ '.raku');
%*ENV<RAKUISH_REPL> = $tmp.Str;
$tmp.spurt(q{}) if $tmp.e;

sub clean-store {
    for store-keys() -> $k { store-del($k) }
}

plan 10;

# ── 1) kind-of 只认已知 magic（%STORE 必须当 Raku） ─────────────────
subtest 'kind-of 只认已知 magic', {
    plan 5;
    is kind-of('%help'),        'magic', '%help 是 magic';
    is kind-of('%time 2 ** 10'),'magic', '%time 是 magic';
    is kind-of('%run a.sh'),    'magic', '%run 是 magic';
    is kind-of('%STORE{x} = 1'),'raku',  '%STORE 当 Raku（早期 bug 修复）';
    is kind-of('!ls'),          'shell', '! 前缀是 shell';
};

# ── 2) should-log 过滤规则 ──────────────────────────────────────────
subtest 'should-log 过滤规则', {
    plan 7;
    $Rakuish::Loop::REPL-ON = True;
    ok  should-log('1 + 1'),             '普通 Raku 行记录';
    ok  should-log("store-set('x', 5)"), 'store-set 记录';
    ok  should-log('%time 2 ** 10'),     '%time 记录';
    ok  should-log('%load f.raku'),      '%load 记录';
    nok should-log('%run f.sh'),         '%run 不记录';
    nok should-log('%quit'),             '%quit 不记录';
    nok should-log('%repl clear'),       '%repl 不记录';
};

# ── 3) replay-status 反映文件 ───────────────────────────────────────
subtest 'replay-status 读文件', {
    plan 3;
    $tmp.spurt("store-set('a', 1)\n%time 2\n");
    open-replay();
    my $st = replay-status();
    is  $st<lines>,   2, '统计到 2 条非空输入';
    ok  $st<enabled>,    '默认开启';
    ok  $st<path> eq $tmp.Str, '路径正确';
    close-replay();
};

# ── 4) replay-lines 过滤空行 ────────────────────────────────────────
subtest 'replay-lines 过滤空行', {
    plan 1;
    $tmp.spurt("\nstore-set('b', 2)\n\n");
    is replay-lines().elems, 1, '跳过空行，只剩 1 条';
};

# ── 5) 端到端（真实 run-loop）：重放恢复 %STORE + 交互继续记录 ──────
subtest '重放恢复状态 + 交互追加（run-loop）', {
    plan 3;
    clean-store();
    $Rakuish::Loop::REPL-ON = True;
    $tmp.spurt("store-set('persisted', 42)\nstore-set('other', 7)\n");
    my &rd = reader-from("store-set('new', 99)", '%quit');
    my $rc = run-loop(:color(False), :replay, :read-line(&rd));
    is store-get('persisted'), 42, '重放后 store-get(persisted) 恢复';
    is store-get('new'),      99, '交互新行被记录并求值';
    my $after = $tmp.e ?? $tmp.slurp.lines.grep(*.trim ne q{}).elems !! 0;
    is $after, 3, '文件追加了新交互行（quit 未记）';
};

# ── 6) 失败 Raku cell 不写入（只有成功的才记） ──────────────────────
subtest '失败 cell 不持久化', {
    plan 2;
    clean-store();
    $Rakuish::Loop::REPL-ON = True;
    $tmp.spurt(q{});
    open-replay();
    my &rd = reader-from('this is not valid raku @@@', "store-set('okk', 1)", '%quit');
    my $rc = drive(&rd, :color(False));
    close-replay();
    my $content = $tmp.e ?? $tmp.slurp !! q{};
    ok $content !~~ /'not valid'/, '错误行未写入';
    ok $content ~~ /'okk'/,        '成功行已写入';
};

# ── 7) %repl off 关闭记录 ───────────────────────────────────────────
subtest '%repl off 关闭记录', {
    plan 2;
    $Rakuish::Loop::REPL-ON = True;
    $tmp.spurt(q{});
    open-replay();
    my &rd = reader-from('%repl off', "store-set('afteroff', 1)", '%quit');
    my $rc = drive(&rd, :color(False));
    close-replay();
    my $content = $tmp.e ?? $tmp.slurp !! q{};
    ok $content !~~ /'afteroff'/, '%repl off 后新行不写入';
    ok $content !~~ /'repl off'/,  '%repl off 自身也不写入（元命令排除）';
    $Rakuish::Loop::REPL-ON = True;   # 复位，避免影响后续 subtest
};

# ── 8) %repl clear 清空 ─────────────────────────────────────────────
subtest '%repl clear 清空文件', {
    plan 1;
    $Rakuish::Loop::REPL-ON = True;
    $tmp.spurt(q{});
    open-replay();
    my &rd = reader-from('%repl clear', '%quit');
    my $rc = drive(&rd, :color(False));
    close-replay();
    my $n = $tmp.e ?? $tmp.slurp.lines.grep(*.trim ne q{}).elems !! 0;
    is $n, 0, 'clear 后文件为空';
};

# ── 9) 真实 run-loop：跨会话恢复（注入 reader，无需 tty） ───────────
subtest 'run-loop 跨会话恢复', {
    plan 3;
    clean-store();
    $Rakuish::Loop::REPL-ON = True;
    $tmp.spurt(q{});
    # 会话 1：写入一个状态并退出
    my &s1 = reader-from("store-set('keep', 123)", '%quit');
    run-loop(:color(False), :replay, :read-line(&s1));
    ok $tmp.e && $tmp.slurp.lines.grep(*.trim ne q{}).elems == 1, '会话1已落盘 1 条';

    # 会话 2：重放后读取该状态；用 Sink 抓输出
    class Sink {
        has @.lines;
        method say($s --> Nil)  { @.lines.push: $s.Str; Nil }
        method print($s --> Nil){ @.lines.push: $s.Str; Nil }
        method text(--> Str) { @.lines.join("\n") }
    }
    my $sink = Sink.new;
    my &s2 = reader-from('%time store-get("keep")', '%quit');
    {
        temp $*OUT = $sink;
        run-loop(:color(False), :replay, :read-line(&s2));
    }
    ok $sink.text.contains('123'), '会话2重放后 store-get 取到 123';
    ok $sink.text.contains('重放'), '会话2打印了重放横幅';
};

# ── 10) 默认不重放（启动即干净，对应「不要一进入shell就出现历史命令」）──
subtest '默认关闭自动重放', {
    plan 2;
    clean-store();
    $Rakuish::Loop::REPL-ON = True;
    $tmp.spurt("store-set('ghost', 555)\n");
    my &rd = reader-from("store-set('fresh', 1)", '%quit');
    run-loop(:color(False), :read-line(&rd));   # 不传 :replay
    nok store-has('ghost'), '默认不重放：上次的 ghost 未恢复';
    ok  store-has('fresh'), '交互输入仍正常求值';
    $tmp.spurt(q{});
};

# 清理
$tmp.unlink if $tmp.e;
