use lib 'lib';
use Test;
use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;
use Rakuish::Shell::Exec;
use Rakuish::Loop;

# t/38-shell-heredoc.t —— 原生 shell 层的 **heredoc**
#
#   cat <<EOF
#   ...正文...
#   EOF
#
# bash 语义：
#   · 正文**不在命令行里** —— 它是**后续的输入行**，直到出现分隔符为止
#   · 分隔符被**引号包住** ⇒ 正文**不做展开**（原样）
#   · 分隔符没被引号包住 ⇒ 正文**做展开**（变量 / 命令替换）
#   · `<<-` ⇒ 去掉正文行首的**制表符**
#   · heredoc 就是命令的 **stdin**
#
# ⚠ 期望值**全部来自真 bash 实测**。
#
# ⚠ 本层要跨两层：
#   · 执行层（run-shell-line 收正文）
#   · 交互层（REPL 替用户把正文行读出来）

my $SQ = chr(39);
my $DQ = chr(34);

# drive() 会写会话记录文件 —— 指到临时文件，别污染真实 HOME
my $tmp = $*TMPDIR.add('rakuish-t38-' ~ $*PID ~ '.repl');
%*ENV<RAKUISH_REPL> = $tmp.Str;
$tmp.spurt(q{}) if $tmp.e;

# ── 词法：<< 与 <<- 是 op，分隔符是下一个词 ───────────────────────
subtest "词法：heredoc 运算符", {
    my $l = lex('cat <<EOF', :cmdsub(True));
    is $l.unsupported, q{}, '不再标记成不支持';
    is $l.tokens.elems, 3, '3 个 token（cat / << / EOF）';
    is $l.tokens[1].kind, 'op', '<< 是 op';
    is $l.tokens[1].text, '<<', '<<';
    is $l.tokens[2].text, 'EOF', '分隔符是下一个词';

    my $l2 = lex('cat <<-EOF', :cmdsub(True));
    is $l2.tokens[1].text, '<<-', '<<- 带去制表符的标记';

    # `<<<` herestring 不实现 → 交 sh
    ok lex('cat <<<EOF').unsupported ne q{}, '<<< 仍不原生支持';
}

# ── 语法：heredoc 变成一条重定向 ───────────────────────────────────
subtest "语法：heredoc 重定向", {
    my $l = lex('cat <<EOF', :cmdsub(True));
    my $p = parse($l.tokens);
    is $p.unsupported, q{}, '能解析';
    my @redirs = @(@($p.pipelines)[0].commands[0].redirs);
    is @redirs.elems, 1, '1 条重定向';
    is @redirs[0].kind, 'heredoc', 'kind 是 heredoc';
    is @redirs[0].target, 'EOF', 'target 是分隔符';
    ok !@redirs[0].literal, '分隔符没加引号 → 正文要展开';
    ok !@redirs[0].strip, '不是 <<-';

    # 带引号的分隔符 → 正文**不**展开
    my $l2 = lex('cat <<' ~ $SQ ~ 'EOF' ~ $SQ, :cmdsub(True));
    my $p2 = parse($l2.tokens);
    my @r2 = @(@($p2.pipelines)[0].commands[0].redirs);
    is @r2[0].target, 'EOF', '分隔符去掉引号';
    ok @r2[0].literal, '分隔符带引号 → 正文不展开';

    # <<-
    my $l3 = lex('cat <<-EOF', :cmdsub(True));
    my $p3 = parse($l3.tokens);
    my @r3 = @(@($p3.pipelines)[0].commands[0].redirs);
    ok @r3[0].strip, '<<- → strip 标记';
}

# ── 执行层：正文当 stdin ───────────────────────────────────────────
subtest "执行：正文就是命令的 stdin", {
    my %b = 'EOF' => "hello\nworld\n";
    my $r = run-shell-line('cat <<EOF', %b, :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout, "hello\nworld\n", '正文原样喂给 cat';

    my %b2 = 'EOF' => "a\nb\nc\n";
    my $r2 = run-shell-line('wc -l <<EOF', %b2, :capture(True));
    is $r2.stdout.trim, '3', 'wc -l 数到 3 行';
}

subtest "分隔符加引号 → 正文不做展开", {
    my %b = 'EOF' => 'raw ' ~ chr(36) ~ "HOME\n";
    my $r = run-shell-line('cat <<' ~ $SQ ~ 'EOF' ~ $SQ, %b, :capture(True));
    is $r.stdout, 'raw ' ~ chr(36) ~ "HOME\n", '正文里的 $HOME 没被展开';
}

subtest "分隔符不加引号 → 正文做展开", {
    my %b = 'EOF' => 'raw ' ~ chr(36) ~ "HOME\n";
    my $r = run-shell-line('cat <<EOF', %b, :capture(True));
    isnt $r.stdout, 'raw ' ~ chr(36) ~ "HOME\n", '正文里的 $HOME 被展开了';
    ok $r.stdout.contains('/'), '展开成了路径';
}

subtest "<<- 去掉正文行首的制表符", {
    my %b = 'EOF' => "\tindented\n\talso\n";
    my $r = run-shell-line('cat <<-EOF', %b, :capture(True));
    is $r.stdout, "indented\nalso\n", '制表符被去掉';
}

subtest "一行里多个 heredoc", {
    my %b = 'EA' => "first\n", 'EB' => "second\n";
    my $r = run-shell-line('cat <<EA; cat <<EB', %b, :capture(True));
    is $r.stdout, "first\nsecond\n", '两个正文按顺序喂给两条命令';
}

subtest "heredoc 与管道 / 其它重定向共存", {
    my %b = 'EOF' => "alpha\nbeta\n";
    my $r = run-shell-line('cat <<EOF | tr a-z A-Z', %b, :capture(True));
    is $r.stdout, "ALPHA\nBETA\n", '管道下游拿到的是正文';
}

# ── 交互层：REPL 替用户读正文行 ───────────────────────────────────
#
# ⚠ 子进程的 stdout 是**直接写 fd 1** 的（不经过 `$*OUT`），
#   所以这里不截输出，而是让命令把正文写进**文件**再断言文件内容。
subtest "交互层：REPL 接着读正文行", {
    my $outfile = '/tmp/rakuish-t38-heredoc-out';
    try { unlink $outfile };
    my @script = (
        '!cat <<EOF > ' ~ $outfile,
        'line one',
        'line two',
        'EOF',
    );
    my $sink = class {
        has @.lines;
        method say($s --> Nil) { @.lines.push: $s.Str; Nil }
        method text(--> Str) { @.lines.join("\n") }
    }.new;
    {
        temp $*OUT = $sink;
        temp $*ERR = $sink;
        my $cursor = 0;
        my $read-line = sub ($prompt) {
            my $line = @script[$cursor++];
            $line;
        };
        drive($read-line, :color(False));
    }
    my $text = try { slurp($outfile) };
    ok $text.defined, '输出文件生成了';
    is $text, "line one\nline two\n", '正文行被读进来并喂给命令';
    try { unlink $outfile };
}

subtest "交互层：结束行不属于正文", {
    my $outfile = '/tmp/rakuish-t38-heredoc-end';
    try { unlink $outfile };
    my @script = (
        '!cat <<EOF > ' ~ $outfile,
        'only body',
        'EOF',
    );
    my $sink = class {
        has @.lines;
        method say($s --> Nil) { @.lines.push: $s.Str; Nil }
        method text(--> Str) { @.lines.join("\n") }
    }.new;
    {
        temp $*OUT = $sink;
        temp $*ERR = $sink;
        my $cursor = 0;
        my $read-line = sub ($prompt) {
            my $line = @script[$cursor++];
            $line;
        };
        drive($read-line, :color(False));
    }
    my $text = try { slurp($outfile) };
    is $text, "only body\n", '结束行没进正文';
    try { unlink $outfile };
}

done-testing;
