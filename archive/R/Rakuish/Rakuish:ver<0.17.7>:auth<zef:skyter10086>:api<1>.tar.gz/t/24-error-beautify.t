use lib "lib";
use Test;
use Rakuish::Eval;

# 报错美化回归：分类标签（后端无关）+ 结构（» 标记 / 提示 / 源码）+ 多行消息保留。
# 断言只锁"分类标签"和"结构"，不锁各后端原始英文消息（措辞不同但都会归到同一中文类别）。

my $state = LexState.new;

sub rendered(Str $src --> Str) {
    my $r = eval-cell($src, :index(1), :state($state));
    $r.ok ?? '' !! render-error($r, :color(False));
}

subtest "未定义名称（例程 / 变量）", {
    my $m1 = rendered('twice');
    ok $m1.contains('未定义名称'), '例程: 归类为未定义名称';
    ok $m1.contains('»'),         '例程: 有源码行首标记 »';
    ok $m1.contains('twice'),     '例程: 出错源码出现在块里';
    ok $m1.contains('提示:'),     '例程: 有下一步提示';

    my $m2 = rendered('say $undefined_var');
    ok $m2.contains('未定义名称'),     '变量: 归类为未定义名称';
    ok $m2.contains('$undefined_var'),'变量: 出错源码出现';
    # 多行消息保留（MoarVM 给两行；rakupp 若也给则一并验证）
    if $m2.contains("Perhaps you forgot") {
        ok $m2.contains("Perhaps you forgot a 'sub'"),
           '变量: 消息第二行被保留（不再是只取首行）';
    } else {
        skip "本后端未给出多行消息", 1;
    }
};

subtest "类型错误", {
    my $m = rendered('my $a = 1; say $a + "x"');
    ok $m.contains('类型错误'),         '归类为类型错误';
    ok $m.contains('»'),               '有源码标记';
    ok $m.contains('提示: 类型不匹配'), '类型不匹配提示';
};

subtest "下标错误", {
    my $m = rendered('my @a = (1,2,3); @a<0>');
    ok $m.contains('下标错误'),             '归类为下标错误';
    ok $m.contains('提示: 下标用错了容器'), '下标容器提示';
};

subtest "语法错误", {
    my $m = rendered('1 /');
    ok $m.contains('语法错误'), '归类为语法错误';
    ok $m.contains('提示:'),   '有提示';
};

subtest "运行时错误（die）", {
    my $m = rendered('die "boom"');
    ok $m.contains('运行时错误'),    '归类为运行时错误';
    ok $m.contains('» die "boom"'), '源码出现';
};

subtest "异常对象缺失兜底", {
    ok render-error(CellResult.new(:ok(False), :source('x')), :color(False))
       .contains('无异常对象'),
       'Nil 异常给出（无异常对象）';
};

subtest "出错标识符高亮（offending-token + highlight-token）", {
    # 提取器本身（后端无关）：用样本消息直接验证正则
    is offending-token(q{Variable '$x' is not declared}),       '$x',    'regex: 变量未声明 抠出 $x';
    is offending-token(q{Undefined routine 'foo'}),             'foo',   'regex: rakupp 例程 抠出 foo';
    is offending-token(q{    twice used at line 1}),            'twice', 'regex: MoarVM 例程 抠出 twice';
    is offending-token(q{Type Int does not support associative indexing.}), '', 'regex: 下标错误 无标识符 → 空串';

    # 真实触发：变量未声明，彩色渲染的源码行应出现粗黄高亮转义
    my $rv = eval-cell('say $undefined_var', :index(1), :state($state));
    ok !$rv.ok, '变量用例确实报错';
    ok render-error($rv, :color).contains("\e[1m\e[33m"),
       '彩色: 源码行出现粗黄高亮转义';
    ok render-error($rv, :color).contains('$undefined_var'),
       '彩色: 被高亮的标识符仍在输出里';

    # 真实触发：例程未定义，同样应高亮
    my $rt = eval-cell('twice()', :index(1), :state($state));
    ok !$rt.ok, '例程用例确实报错';
    ok render-error($rt, :color).contains("\e[1m\e[33m"),
       '彩色: 例程错误源码行也高亮';
};

done-testing;
