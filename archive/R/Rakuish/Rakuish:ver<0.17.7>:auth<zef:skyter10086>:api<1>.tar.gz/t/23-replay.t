use lib "lib";
use Test;
use Rakuish::Loop;

# ── 会话持久化（.repl 重放）子系统测试 ──
# 全部写操作重定向到临时文件（RAKUISH_REPL），绝不触碰用户真实的
# ~/.rakuish/repl.raku；不依赖 tty，可在管道里双后端跑。

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}

my $tmp = $*TMPDIR.add('rakuish-repl-' ~ $*PID ~ '.txt');
%*ENV<RAKUISH_REPL> = $tmp.Str;

END {
    try { $tmp.unlink if $tmp.e }
    try { %*ENV<RAKUISH_REPL>:delete }
    try { close-replay() }
}

subtest "replay-file-path：env 覆盖优先于默认", {
    is replay-file-path().Str, $tmp.Str, 'env 覆盖生效';
    %*ENV<RAKUISH_REPL>:delete;
    my $def = replay-file-path();
    ok $def.Str.contains('.rakuish') && $def.Str.ends-with('repl.raku'),
       '默认落在 ~/.rakuish/repl.raku';
    %*ENV<RAKUISH_REPL> = $tmp.Str;
};

subtest "should-log：过滤元命令 + 总开关", {
    ok should-log('my $a = 1'), '普通 Raku 行记录';
    ok should-log('!ls'),       'shell 行记录';
    ok !should-log('%quit'),    '%quit 不记录';
    ok !should-log('%exit'),    '%exit 不记录';
    ok !should-log('%help'),    '%help 不记录';
    ok !should-log('%run foo'), '%run 不记录';
    ok !should-log('%repl'),    '%repl 不记录';
    repl-magic('repl off');
    ok !should-log('my $a = 1'), '总开关 off 时不记录';
    repl-magic('repl on');
    ok should-log('my $a = 1'),  '总开关 on 恢复记录';
};

subtest "log-parts + replay-lines：往返 + 丢弃空行", {
    # log-parts 把每个 should-log 为真的部分都写盘（含空白行）；
    # replay-lines 在读取时丢弃纯空白行。所以 3 入 → 2 出。
    open-replay();
    log-parts('a', '   ', 'b');
    my @lines = replay-lines();
    is @lines.elems, 2,        '空行被丢弃（3 入 2 出）';
    is @lines[0], 'a',         '首行保留';
    is @lines[1], 'b',         '末行保留（中间空行跳过）';
    my %st = replay-status();
    is %st<lines>, 2,          'replay-status 计数=2';
    ok %st<enabled>,           'replay-status enabled=True';
    is %st<path>, $tmp.Str,    'replay-status 路径=隔离文件';
    close-replay();
};

subtest "repl-magic：off/on/clear + 状态", {
    open-replay();
    log-parts('a', 'b');
    my $sink = Sink.new;
    temp $*OUT = $sink;
    repl-magic('repl off');
    ok !should-log('x'), 'off 后不记录';
    repl-magic('repl on');
    ok should-log('x'),  'on 后恢复记录';
    repl-magic('repl clear');
    is replay-lines().elems, 0, 'repl clear 清空记录';
    repl-magic('repl');
    ok $sink.text.contains('会话记录'), 'repl 状态含"会话记录"';
    close-replay();
};

subtest "run-loop :replay：重放行→切交互，状态跨阶段保留", {
    $tmp.spurt("my \$x = 100\n");
    my $sink = Sink.new;
    temp $*OUT = $sink;
    my $rc = run-loop(:replay, :read-line(reader-from(['say $x', '%quit'])));
    is $rc, 0,                      '正常退出 rc=0';
    ok $sink.text.contains('Out['), '驱动正常产出结果';
    ok $sink.text.contains('100'),  '重放的 my $x=100 在交互阶段可见（say $x → 100）';
};

done-testing;
