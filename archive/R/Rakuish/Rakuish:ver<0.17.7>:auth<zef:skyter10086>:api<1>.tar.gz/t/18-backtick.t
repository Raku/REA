use Test;
use lib 'lib';
use Rakuish::Loop;
use Rakuish::Eval;
use Rakuish::Slow;

plan 7;

sub clean-store {
    for store-keys() -> $k { store-del($k) }
}

# 1) 分类与去引号
subtest 'kind-of / strip-backticks', {
    plan 4;
    is kind-of('`echo hi`'), 'shellq', '反引号整行 = shellq';
    is kind-of('`x`'),        'shellq', '单字符命令也算';
    is kind-of('`'),           'raku',  '只有反引号（无闭合）当 Raku';
    is strip-backticks('  `echo hi`  '), 'echo hi', '去首尾反引号并 trim';
};

# 2) 渲染：单行同行、多行原样
subtest 'render-shell-capture', {
    plan 3;
    my $one = render-shell-capture(3, 'hi', :color(False));
    ok $one.contains('Out[3]:') && $one.contains('hi'), '单行显示 Out[n] 与值';
    my $multi = render-shell-capture(4, "a\nb\n", :color(False));
    ok $multi.contains('  a') && $multi.contains('  b'), '多行每行原样、加 2 空格缩进';
    my $empty = render-shell-capture(5, '', :color(False));
    ok $empty.contains('Out[5]:'), '空输出仍打印标签';
};

# 3) 真实 shell 捕获基础设施
subtest 'run-shell 捕获 stdout', {
    plan 1;
    my $r = run-shell('echo captured-xyz', :capture(True));
    ok $r.stdout.contains('captured-xyz'), '捕获到 shell 输出';
};

# 4) 端到端：反引号走 shellq，Out[n] 显示捕获值，并写入 %STORE<_>
subtest '端到端 run-loop 反引号捕获', {
    plan 3;
    clean-store();
    class ESink {
        has @.lines;
        method say($s --> Nil)   { @.lines.push: $s.Str; Nil }
        method print($s --> Nil) { @.lines.push: $s.Str; Nil }
        method text(--> Str) { @.lines.join("\n") }
    }
    my $sink = ESink.new;
    my &rd = reader-from('`echo captured-xyz`', '%quit');
    {
        temp $*OUT = $sink;
        run-loop(:color(False), :read-line(&rd));
    }
    ok $sink.text.contains('Out[1]:'), '反引号 cell 显示 Out[1]';
    ok $sink.text.contains('captured-xyz'), '捕获的 shell 输出出现在 Out';
    is store-get('_'), 'captured-xyz', '捕获值存入 %STORE<_> 可复用';
};


# 5) 嵌入反引号扫描：仅替换"裸"反引号，跳过字符串/括号引号/正则
subtest 'expand-backticks 扫描', {
    plan 6;
    my $e = expand-backticks('my $x = `pwd`');
    ok $e.contains('__shellq__'), '裸反引号被展开';
    ok $e.contains("('pwd')"), '命令体为单引号字面量';
    nok $e.contains('`pwd`'), '展开后不再含反引号';

    is expand-backticks('say "a `b` c"'), 'say "a `b` c"', '双引号字符串内反引号保留';
    is expand-backticks('my $s = q[`inside`];'), 'my $s = q[`inside`];', '括号引号内反引号保留';
    is expand-backticks('my $y = 1 + 2'), 'my $y = 1 + 2', '无反引号原样';
};

# 6) eval-cell：嵌入反引号把 shell 输出当本 cell 的值
subtest 'eval-cell 嵌入反引号当值用', {
    plan 3;
    my $r1 = eval-cell('my $x = `pwd`', :index(1));
    ok $r1.ok, 'eval 成功';
    ok $r1.value.contains('Rakuish'), 'pwd 输出作为字符串值: ' ~ $r1.value;

    my $r2 = eval-cell('`ls -1 /tmp`.lines.elems', :index(2));
    ok $r2.ok && $r2.value ~~ Int && $r2.value > 0, '可接着调用 .lines.elems: ' ~ $r2.value;
};

# 7) 端到端：嵌入反引号在真实 run-loop 里工作，且与整行反引号、跨行 my 共存
subtest '端到端 嵌入反引号', {
    plan 4;
    clean-store();
    class GSink {
        has @.lines;
        method say($s --> Nil)   { @.lines.push: $s.Str; Nil }
        method print($s --> Nil) { @.lines.push: $s.Str; Nil }
        method text(--> Str) { @.lines.join("\n") }
    }
    my $sink = GSink.new;
    my &rd = reader-from(
        'my $base = `pwd`',
        'my $n = `ls -1 /tmp`.lines.elems',
        'say "base=[$base] n=[$n]"',
        '`echo standalone`',
        '%quit'
    );
    {
        temp $*OUT = $sink;
        run-loop(:color(False), :read-line(&rd));
    }
    my $txt = $sink.text;
    ok $txt.contains('Out[1]:'), '嵌入反引号 cell 显示 Out[1]';
    ok $txt.contains('/home'), '捕获的 pwd 输出出现';
    ok $txt.contains('base=[/home') && $txt.contains('n=['), '跨行 my 能引用嵌入反引号的值';
    ok $txt.contains('standalone'), '整行反引号仍作为 shellq 工作';
};

done-testing;
