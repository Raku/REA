use lib 'lib';
use Test;
use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;
use Rakuish::Shell::Exec;

# t/36-shell-andor.t —— 原生 shell 层的 `&&` / `||` 顺序语义
#
# bash 规则：
#   `a && b`  b 只在 a **成功**（退出码 0）时跑
#   `a || b`  b 只在 a **失败**（退出码 ≠ 0）时跑
#   `;`        下一条无条件跑
#   `&&` 与 `||` **同优先级、左结合**
#     ⇒ `a && b || c` = `(a && b) || c`
#     ⇒ `a || b && c` = `(a || b) && c`
#
# ⚠ 这套语义**必须与真 sh 逐条一致** —— 所以每条用例都写了
#   「期望的退出码 + 期望的输出」，那些值是按真 `sh -c` 实测出来的。
#
# 连接符属于它**后面**那条 pipeline（`a && b` 里 `&&` 是 b 的前缀）。
# 写反的话症状是「`false && echo NOPE` 照样打印 NOPE」。

sub parse-line(Str $line --> Parsed) { parse(lex($line).tokens) }

subtest "词法层：&& 与 || 是独立的 op", {
    my $l = lex('a && b || c');
    is $l.unsupported, q{}, '不再标记为不支持';
    my @t = $l.tokens.map({ $_.kind ~ ':' ~ $_.text });
    is @t[1], 'op:&&', '&& 是一个 op';
    is @t[3], 'op:||', '|| 是一个 op';
}

subtest "语法层：连接符记在**后面**那条 pipeline 上", {
    my $p = parse-line('a && b');
    is $p.pipelines.elems, 2, '两条 pipeline';
    is $p.pipelines[0].op, q{}, '第 1 条没有连接符';
    is $p.pipelines[1].op, '&&', '第 2 条的连接符是 &&';

    my $p2 = parse-line('a || b');
    is $p2.pipelines[1].op, '||', '|| 同样记在后面那条';

    my $p3 = parse-line('a ; b');
    is $p3.pipelines[0].op, q{}, '分号后第 1 条无连接符';
    is $p3.pipelines[1].op, q{}, '分号后第 2 条也无连接符（无条件执行）';

    my $p4 = parse-line('a && b || c');
    is $p4.pipelines[1].op, '&&', '第 2 条是 &&';
    is $p4.pipelines[2].op, '||', '第 3 条是 ||';
}

subtest "语法层：&& / || 不再标记为不支持", {
    ok parse-line('a && b').unsupported eq q{}, '&& 现在原生支持';
    ok parse-line('a || b').unsupported eq q{}, '|| 现在原生支持';
    ok native-supported('a && b'), 'native-supported 也放行';
    ok native-supported('a || b'), 'native-supported 也放行';
    # 仍然不支持的还在（heredoc 从 2026-11-03 起原生支持了，语义断言在 t/38）
    ok parse-line('a >>> b').unsupported ne q{}, '>>> 仍交 sh';
}

subtest "&&：成功才跑后面那条", {
    my $r = run-shell-line('true && echo YES', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'YES', '打印了 YES';
}

subtest "&&：失败就不跑后面那条", {
    my $r = run-shell-line('false && echo NOPE', :capture(True));
    is $r.code, 1, '退出码是 1（前面那条的）';
    is $r.stdout.trim, q{}, '没有输出';
}

subtest "||：失败才跑后面那条", {
    my $r = run-shell-line('false || echo FALLBACK', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'FALLBACK', '打印了 FALLBACK';
}

subtest "||：成功就不跑后面那条", {
    my $r = run-shell-line('true || echo NORUN', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, q{}, '没有输出';
}

subtest "左结合：a && b || c", {
    # (a && b) || c：a 失败 → 跳过 b → 因为失败，|| 触发 → 跑 c
    my $r = run-shell-line('false && echo NO || echo YES', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'YES', '只打印了 YES';
}

subtest "左结合：a || b && c", {
    # (a || b) && c：a 成功 → 跳过 b → 因为成功，&& 触发 → 跑 c
    my $r = run-shell-line('true || echo NO && echo YES', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'YES', '只打印了 YES';
}

subtest "&& 与管道混用", {
    my $r = run-shell-line('echo hi | grep hi && echo PIPE-OK', :capture(True));
    is $r.code, 0, '退出码 0';
    ok $r.stdout.contains('hi'), '管道输出在';
    ok $r.stdout.contains('PIPE-OK'), '&& 后半段跑了';
}

subtest "&& 失败后管道不跑", {
    my $r = run-shell-line('false && echo hi | grep hi', :capture(True));
    ok $r.stdout.trim eq q{}, '没有输出';
}

subtest "分号仍然无条件执行（不受连接符影响）", {
    my $r = run-shell-line('false ; echo AFTER', :capture(True));
    is $r.stdout.trim, 'AFTER', '分号后照跑';
    is $r.code, 0, '退出码是最后一条的';
}

subtest "跳过的流水线不改退出码", {
    # `false && echo NO` 的退出码是 1（false 的），不是 0
    my $r = run-shell-line('false && echo NO', :capture(True));
    is $r.code, 1, '退出码保持前面那条的';
}

subtest "与真 sh 逐条对拍", {
    # 这些期望值是**真 sh 实测**出来的（不是推想的）。
    my @cases = (
        ['true && echo YES',            0, 'YES'],
        ['false && echo NOPE',          1, q{}],
        ['false || echo FALLBACK',      0, 'FALLBACK'],
        ['true || echo NORUN',          0, q{}],
        ['false && echo NO || echo YES',0, 'YES'],
        ['true || echo NO && echo YES', 0, 'YES'],
    );
    for @cases -> $c {
        my ($cmd, $want-code, $want-out) = @$c;
        my $r = run-shell-line($cmd, :capture(True));
        is $r.code, $want-code, "退出码一致：$cmd";
        is $r.stdout.trim, $want-out, "输出一致：$cmd";
    }
}

done-testing;
