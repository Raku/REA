use lib "lib";
use Test;
use Rakuish::Loop;

# drive 的 log-parts 会写 replay 文件，重定向到临时路径，别碰用户真实文件
my $tmp = $*TMPDIR.add('rakuish-scope-' ~ $*PID ~ '.txt');
%*ENV<RAKUISH_REPL> = $tmp.Str;
END { try { $tmp.unlink if $tmp.e } }

# ── 1. scan-scope：基本声明形式 ───────────────────────────────────────
my $r = scan-scope(q{ my $a = 1; my @rows = (); my %h; my Int $n = 0; my $!p; });
ok $r<vars>.grep(* eq q{$a}).elems,    'my $a';
ok $r<vars>.grep(* eq q{@rows}).elems, 'my @rows';
ok $r<vars>.grep(* eq q{%h}).elems,    'my %h';
ok $r<vars>.grep(* eq q{$n}).elems,    'my Int $n（带类型）';
ok $r<vars>.grep(* eq q{$p}).elems,    'my $!p（私有，twigil 归一为 $p）';

# ── 2. scan-scope：例程名 ─────────────────────────────────────────────
my $r2 = scan-scope(q{ sub foo { 1 }  method bar() {}  sub baz(Str $x) { } });
is $r2<subs>.sort.List.join(q{ }), q{bar baz foo}, 'sub / method 名都被收集';

# ── 3. 解构声明 ───────────────────────────────────────────────────────
my $r3 = scan-scope(q{ my ($x, @y) = 1, 2; });
is $r3<vars>.sort.List.join(q{ }), q{$x @y}, '解构 my ($x, @y)';

# ── 4. 注释 / 字符串里的 my 不算声明（幽灵补全护栏）──────────────────
my $src4 = [
    q{# my $fake = 1},
    q{my $real = 2;   # trailing my $nope},
    q{my $s = 'my $str = 3';},
].join("\n");
my $r4 = scan-scope($src4);
ok   $r4<vars>.grep(* eq q{$real}).elems, '真声明仍能找到';
ok !$r4<vars>.grep(* eq q{$fake}).elems, '整行注释里的 my 不算声明';
ok !$r4<vars>.grep(* eq q{$nope}).elems, '行尾注释里的 my 不算声明';
ok !$r4<vars>.grep(* eq q{$str}).elems,  '单引号字符串里的 my 不算声明';

# ── 5. 查询子：sigil 与 prefix 过滤 ───────────────────────────────────
$SCOPE-SOURCE = q{my $name = 1; my @rows; my %opt; my $count = 0; sub greet { } };
is raku-var-names(q{$}, q{na}).List.join(q{ }),        q{$name},       '$na  -> $name';
is raku-var-names(q{$}, q{}).List.sort.List.join(q{ }), q{$count $name}, '$ 全部只含 $ 变量';
is raku-var-names(q{@}, q{}).List.join(q{ }),          q{@rows},       '@ 全部只含 @ 变量';
ok raku-var-names(q{%}, q{}).List.grep(* eq q{%STORE}).elems, '%STORE 能被补出';
ok raku-var-names(q{%}, q{}).List.grep(* eq q{%opt}).elems,   '%opt 能被补出';
is user-names(q{gr}).List.join(q{ }), q{greet}, 'user-names 补出用户 sub';
ok raku-keywords(q{wh}).List.grep(* eq q{when}).elems,  '关键字 when';
ok raku-keywords(q{wh}).List.grep(* eq q{while}).elems, '关键字 while';

# ── 6. complete-at 端到端 ─────────────────────────────────────────────
ok   complete-at(q{$na}, 3).grep(* eq q{$name}), 'complete-at($na) -> $name';
ok   complete-at(q{fo}, 2).grep(* eq q{for}),     'complete-at(fo)  -> for';
ok   complete-at(q{wh}, 2).grep(* eq q{while}),   'complete-at(wh)  -> while';
ok ! complete-at(q{say $zzz}, 8).grep(*.contains('zzz')), '未声明变量不产生幽灵补全';

# sigil 过滤必须真的生效：曾因「List 赋给数组变量不摊平」导致全体通过
my @dollar = complete-at(q{$}, 1);
ok  @dollar.grep(* eq q{$name}).elems,  '$ 给出 $name';
ok !@dollar.grep(* eq q{@rows}).elems,  '$ 不混入 @ 变量';
ok !@dollar.grep(* eq q{%opt}).elems,   '$ 不混入 % 变量';

# ── 7. drive 集成：求值后作用域自动同步，新变量立刻可补 ───────────────
class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
}
$SCOPE-SOURCE = q{};
{
    temp $*OUT = Sink.new;
    drive(reader-from(q{my $zebra = 42}));
}
ok $SCOPE-SOURCE.contains('zebra'), 'drive 求值后同步了作用域源码';
ok complete-at(q{$zeb}, 4).grep(* eq q{$zebra}), 'drive 之后能补出新声明的 $zebra';

done-testing;
