# t/16-lexical.t —— 跨行词法持久（my / our / sub / 重赋值 / say 输出）
#
# 对应修复：用户进入 REPL 后 `my $a = 1` 下一行 `say $a` 报"变量不存在"。
# 根因：每次 eval-cell 用孤立 EVAL，my 跨不过去。
# 修法：eval-cell 传 :state（LexState）时，把成功源码累加成完整缓冲，
# 每次对整份缓冲重新 EVAL，于是跨行 my/our/sub/容器变更都"留下"。
#
# 必须在两个 Raku 实现上都跑、行为一致。

use Test;
use lib "lib";
use Rakuish::Eval;

plan 10;

# 带 :state 时，my 跨行可见
my $st = LexState.new;
my $r1 = eval-cell(q[my $a = 1], :state($st));
ok $r1.ok, '第一行 my $a = 1 成功';
is $r1.value, 1, '返回值 1';

my $r2 = eval-cell(q[$a], :state($st));
ok $r2.ok, '第二行能看见 $a（不报未声明）';
is $r2.value, 1, '跨行 my 可见';

my $r3 = eval-cell(q[$a = 99], :state($st));
is $r3.value, 99, '重赋值生效并返回新值';

my $r4 = eval-cell(q[$a], :state($st));
is $r4.value, 99, '重赋值跨行保留';

my $r5 = eval-cell(q[sub sq($x){ $x * $x }; sq(5)], :state($st));
is $r5.value, 25, 'sub 跨行可见';

my $r6 = eval-cell(q[say $a], :state($st));
ok $r6.ok, 'say 不报错';
ok $r6.extra-output.contains('99'), 'say 的输出被捕获进 extra-output（而非丢到真实 stdout）';

# 不传 :state 时退化为孤立 EVAL（旧行为，my 不跨调用）—— 确保 :state 是 opt-in
my $iso1 = eval-cell(q[my $z = 7]);
my $iso2 = eval-cell(q[$z]);
nok $iso2.ok, '无 :state 时 my 不跨调用（保持旧语义，不污染单测）';
