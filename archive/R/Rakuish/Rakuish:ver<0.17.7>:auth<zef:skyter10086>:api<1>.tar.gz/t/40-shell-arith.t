use lib 'lib';
use Test;
use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;
use Rakuish::Shell::Expand;
use Rakuish::Shell::Exec;
use Rakuish::Shell::Session;
use Rakuish::Shell::Arith;

# t/40-shell-arith.t —— 原生 shell 层的**算术展开** `$((...))`
#
# 本文件覆盖 bash 的算术求值语义（全部期望值来自 **bash 5.3.9 实测**，
# 对拍脚本见本文件末尾）：
#
#   · 四则运算、位运算、比较、逻辑、三元、逗号
#   · **优先级**（与 C 不同！`**` 比一元运算符更松）
#   · 进制（`0x` / 八进制 / `base#num`）
#   · 变量参与（`$X` 与**裸名字** `X` 都算变量）
#   · **赋值有副作用**（`$((X=9))` 把 X 变成 9）
#   · 除零 ⇒ 报错 + **中止这条命令**（bash 语义）
#
# ⚠ 本文件里的 shell 命令**一律用单引号**写：Raku 的双引号串里
#   `$(` 是代码插值、`${...}` 是哈希下标 —— 写成双引号会得到
#   莫名其妙的编译错误。

my $SQ = chr(39);
my $DQ = chr(34);

# 跑一行，取 stdout（去掉尾部换行）。
sub run-out(Str $line --> Str) {
    my $r = run-shell-line($line, :capture(True));
    $r.stdout.Str.trim
}

# ══════════════════════════════════════════════════════════════════════
# ① 纯算术（不走 shell，直接测求值器）
# ══════════════════════════════════════════════════════════════════════

subtest "四则运算与取整", {
    is eval-arith('1+2'), 3, '加法';
    is eval-arith('10-3'), 7, '减法';
    is eval-arith('3*4'), 12, '乘法';
    is eval-arith('10/3'), 3, '整数除法向零取整';
    is eval-arith('-7/2'), -3, '负数除法也向零取整（不是 -4）';
    is eval-arith('7%3'), 1, '取余';
    is eval-arith('-7%3'), -1,
        '⚠ bash 的 `%` 是**余**（符号跟被除数）—— 不是 Raku 的模（符号跟除数）';
    is eval-arith('7%-3'), 1, '除数为负同样跟被除数';
}

subtest "位运算", {
    is eval-arith('6&3'), 2, '按位与';
    is eval-arith('6|3'), 7, '按位或';
    is eval-arith('6^3'), 5, '按位异或';
    is eval-arith('~5'), -6, '按位取反';
    is eval-arith('1<<4'), 16, '左移';
    is eval-arith('16>>2'), 4, '右移';
}

subtest "比较与逻辑", {
    is eval-arith('1<2'), 1, '小于为真';
    is eval-arith('2<=2'), 1, '小于等于';
    is eval-arith('3>4'), 0, '大于为假';
    is eval-arith('1==1'), 1, '相等';
    is eval-arith('1!=1'), 0, '不等';
    is eval-arith('1&&0'), 0, '逻辑与';
    is eval-arith('0||7'), 1, '逻辑或（只看真假，不看值）';
    is eval-arith('!0'), 1, '逻辑非';
    is eval-arith('!5'), 0, '非零为真';
}

subtest "三元与逗号", {
    is eval-arith('1?2:3'), 2, '条件为真取前者';
    is eval-arith('0?2:3'), 3, '条件为假取后者';
    is eval-arith('1,2'), 2, '逗号运算符取最后一个';
}

subtest "优先级", {
    is eval-arith('1+2*3'), 7, '乘法优先';
    is eval-arith('(1+2)*3'), 9, '括号改变优先级';
    is eval-arith('5-3-1'), 1, '减法左结合';
    is eval-arith('100/5/2'), 10, '除法左结合';
    is eval-arith('3%2*4'), 4, '同优先级从左到右';
}

subtest "幂运算：** 比一元运算符更松（不是 C 的语义！）", {
    is eval-arith('2**10'), 1024, '幂';
    is eval-arith('-2**2'), 4,
        '⚠ bash 里 `-2**2` = **4**（= (-2)**2），不是 -4';
    is eval-arith('~(5**2)'), -26, '显式括号时按 C 的直觉';
    is eval-arith('2**3**2'), 512, '右结合（2**(3**2)）';
}

subtest "进制", {
    is eval-arith('0x10'), 16, '十六进制';
    is eval-arith('010'), 8, '前导 0 是八进制';
    is eval-arith('2#101'), 5, 'base#num';
    is eval-arith('16#ff'), 255, 'base#num（十六进制）';
}

# ══════════════════════════════════════════════════════════════════════
# ② 变量参与 + 赋值的副作用
# ══════════════════════════════════════════════════════════════════════

subtest "变量参与求值", {
    set-var('AR40', '5');
    is eval-arith('AR40+1'), 6, '裸名字也是变量';
    is eval-arith('$AR40+1'), 6, '带 $ 也是变量';
    is eval-arith('AR40'), 5, '变量本身';
    unset-var('AR40');
    is eval-arith('AR40'), 0, '未设置的变量按 0 算（bash 语义）';
}

subtest "赋值有副作用", {
    set-var('AR41', '5');
    is eval-arith('AR41=9'), 9, '表达式的值是 9';
    is lookup('AR41'), '9', '⚠ 变量真的被改成了 9（bash 语义：赋值有副作用）';

    set-var('AR42', '5');
    is eval-arith('AR42+=2'), 7, '复合赋值 +=';
    is lookup('AR42'), '7', '副作用生效';

    set-var('AR43', '5');
    is eval-arith('AR43-=2'), 3, '复合赋值 -=';

    set-var('AR44', '5');
    is eval-arith('AR44*=2'), 10, '复合赋值 *=';

    set-var('AR45', '5');
    is eval-arith('AR45/=2'), 2, '复合赋值 /=';

    set-var('AR46', '5');
    is eval-arith('AR46%=3'), 2, '复合赋值 %=';

    unset-var('AR41'); unset-var('AR42'); unset-var('AR43');
    unset-var('AR44'); unset-var('AR45'); unset-var('AR46');
}

# ══════════════════════════════════════════════════════════════════════
# ③ 执行层：$((...)) 在命令里怎么用
# ══════════════════════════════════════════════════════════════════════

subtest "执行层：算术展开", {
    is run-out('echo $((1+2))'), '3', '最基本的';
    is run-out('echo $((10/3))'), '3', '整数除法';
    is run-out('echo "$((1+2))"'), '3', '双引号内也展开';
    is run-out('echo "x$((1+2))y"'), 'x3y', '夹在文字中间';
    is run-out('echo $(((1+2)*3))'), '9', '嵌套括号';
    is run-out('echo $(( (1+2)*3 ))'), '9', '括号前面有空格也行';
    is run-out('echo $((1?2:3))'), '2', '三元';
    is run-out('echo $((2**10))'), '1024', '幂';
    is run-out('echo $((0x10))'), '16', '十六进制';
}

subtest "执行层：变量参与", {
    set-var('AR40B', '5');
    is run-out('echo $((AR40B+1))'), '6', '裸名字';
    is run-out('echo $(($AR40B+1))'), '6', '带 $';
    is run-out('echo $((AR40B=9))'), '9', '赋值表达式';
    is run-out('echo $AR40B'), '9', '⚠ 赋值真的改了变量（副作用）';
    unset-var('AR40B');
}

subtest '`$(` 与 `$((` 必须分清', {
    # `$((1+2))` —— 紧挨着的第二个 `(` ⇒ 是**算术展开**
    is run-out('echo $((1+2))'), '3', '紧挨着的 `$((` 是算术展开';

    # ⚠ `$( (echo a) )` —— 第二个 `(` 前面有空格 ⇒ 是**命令替换**，
    #   而命令替换的内层是**子 shell** `( … )` ⇒ **native 后端不支持**
    #   （以前会「整行交 sh」—— 那是在一个引擎里干另一个引擎的活 ✗）。
    # → 现在明确报错 ✓（要跑它就用 bash 引擎：`!@bash echo $( (echo a) )`）
    my $r = run-shell-line('echo $( (echo a) )', :capture(True));
    is $r.code, 2, '不支持的语法：退出码 2（bash 的语法错误码）';
    ok $r.stderr.contains('不支持'), '并且说清楚「不支持」';
    ok $r.stderr.contains('@bash'), '并告诉用户怎么委托给 bash 引擎';

    # 区分本身在**词法层**：紧挨着的第二个 `(` ⇒ 算术展开
    is lex('echo $((1+2))', :cmdsub(True)).unsupported, q{},
        '词法层把 `$((` 当算术展开（不是命令替换）';
}

subtest '除零：报错 + 中止这条命令（bash 语义）', {
    my $r = run-shell-line('echo $((1/0))', :capture(True));
    is $r.stdout.Str.trim, q{}, 'stdout 是空的（bash 里 echo 根本不跑）';
    is $r.code, 1, '退出码 1';
    ok $r.stderr.Str.contains('division by zero'), 'stderr 里有除零的报错';

    # 中止的是**这一条命令**，前面的命令照跑
    my $r2 = run-shell-line('echo one; echo $((1/0)); echo two', :capture(True));
    is $r2.stdout.Str.trim, 'one', '前面的命令照跑，后面的不跑';
    is $r2.code, 1, '整行的退出码是 1';
}

# ── 对拍说明 ─────────────────────────────────────────────────────────
# 上面每个期望值都来自 bash 5.3.9 的实测：
#   bash -c 'echo $((1+2))'              → 3
#   bash -c 'echo $((-7/2))'             → -3
#   bash -c 'echo $((-7%3))'             → -1
#   bash -c 'echo $((-2**2))'            → 4      （不是 -4！）
#   bash -c 'echo $((2**3**2))'          → 512
#   bash -c 'echo $((010))'              → 8
#   bash -c 'echo $((2#101))'            → 5
#   bash -c 'V=5; echo $((V=9)); echo $V' → 9 / 9
#   bash -c 'echo $((1/0))'              → 空 + "division by 0" 错误
#   bash -c 'echo $( (echo a) )'         → a

done-testing;
