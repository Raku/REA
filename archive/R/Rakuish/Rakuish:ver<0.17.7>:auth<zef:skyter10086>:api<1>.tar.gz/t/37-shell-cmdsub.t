use lib 'lib';
use Test;
use Rakuish::Shell::Session;
use Rakuish::Shell::Exec;
use Rakuish::Shell::Expand;
use Rakuish::Shell::Lexer;

# t/37-shell-cmdsub.t —— 原生 shell 层的**命令替换**
#
#   `$(cmd)`  与  `` `cmd` ``
#
# 这一层做的事（bash 语义）：
#   · 执行命令，把 **stdout** 换成它的输出（stderr 不算）
#   · 结果的**尾部换行**被去掉
#   · **裸位置**的结果参与**分词**（`$(echo a b)` → 两个参数）
#   · **双引号内**的结果不分词、也不 glob
#   · 内层命令在**子 shell** 里跑（内层的 export 不影响当前会话）
#
# ⚠⚠ 期望值**全部来自真 bash 实测**（不是推想的）。
#   对拍方法：对每条用例跑 `sh -c <cmd>`，与本实现的结果逐条比对。
#   会话语义相关的用例另在 t/35 里对拍（同一个会话里跑）。
#
# ⚠ 断言刻意不写死外部命令的报错原文（随 locale / coreutils 版本变）。

my $SQ = chr(39);
my $DQ = chr(34);
my $BT = chr(96);
my $BS = chr(92);

# glob 用例的工作目录：放几个已知文件
my $GDIR = '/tmp/rakuish-t37-glob';
sub setup-glob-dir() {
    my $dp = $GDIR.IO;
    $dp.mkdir unless $dp.e;
    for <a b> -> $n { spurt($GDIR ~ '/' ~ $n ~ '.txt', 'x') }
    for <c1 d2> -> $n { spurt($GDIR ~ '/' ~ $n ~ '.dat', 'x') }
}

subtest "词法：命令替换是**一个词**（里面的空格不切词）", {
    my $l = lex('echo $(echo a b)', :cmdsub(True));
    is $l.tokens.elems, 2, '2 个 token';
    is $l.tokens[1].text, '$(echo a b)', '命令替换整体是一个词';
    is $l.unsupported, q{}, '开启 :cmdsub 后不算不支持';

    # 不开启 :cmdsub 时**保持旧行为**（标记成不支持 → 整行交 sh）
    ok lex('echo $(date)').unsupported ne q{}, '默认仍标记为不支持';
    ok lex('echo ' ~ $BT ~ 'date' ~ $BT).unsupported ne q{}, '反引号同理';
}

subtest "词法：括号配对认引号、认嵌套", {
    my $l = lex('echo $(echo ")")', :cmdsub(True));
    is $l.tokens[1].text, '$(echo ")")', '双引号里的 ) 不算配对';
    my $l2 = lex('echo $(echo $(echo x))', :cmdsub(True));
    is $l2.tokens[1].text, '$(echo $(echo x))', '嵌套的 $( 整块取出';
    my $l3 = lex('echo $(echo x', :cmdsub(True));
    ok $l3.unsupported ne q{}, '没闭合 → 交 sh';
}

subtest "基本替换", {
    my $r = run-shell-line('echo $(echo a)', :capture(True));
    is $r.code, 0, '退出码 0';
    is $r.stdout.trim, 'a', 'stdout 是 a';

    my $r2 = run-shell-line('echo ' ~ $DQ ~ '$(echo a)' ~ $DQ, :capture(True));
    is $r2.stdout.trim, 'a', '双引号里一样';
}

subtest "分词：裸位置的结果按 IFS 切词", {
    # bash：echo $(echo a b) → 两个参数 → 输出 "a b"
    my $r = run-shell-line('echo $(echo a b)', :capture(True));
    is $r.stdout.trim, 'a b', '两个词';

    # 用 printf 才能看出**参数个数**
    my $r2 = run-shell-line('printf ' ~ $SQ ~ '[%s]' ~ $SQ ~ ' $(echo a b)', :capture(True));
    is $r2.stdout, '[a][b]', '两个参数';

    # 双引号内 → 一个参数
    my $r3 = run-shell-line('printf ' ~ $SQ ~ '[%s]' ~ $SQ ~ ' ' ~ $DQ ~ '$(echo a b)' ~ $DQ, :capture(True));
    is $r3.stdout, '[a b]', '一个参数';
}

subtest "空结果：整词删除 vs 保留空参数", {
    # bash：set -- $(echo) → 0 个参数；set -- "$(echo)" → 1 个空参数
    # ⚠ 不用 `printf '[%s]'` 数参数 —— printf **没有**参数时会把格式串
    #   **原样打印**（bash 语义），数不出个数。用 `sh -c 'echo $#'` 数。
    my $r = run-shell-line('sh -c ' ~ $SQ ~ 'echo $#' ~ $SQ ~ ' sh $(echo)', :capture(True));
    is $r.stdout.trim, '0', '裸位置空结果 → 整个词被删除';

    my $r2 = run-shell-line('sh -c ' ~ $SQ ~ 'echo $#' ~ $SQ ~ ' sh ' ~ $DQ ~ '$(echo)' ~ $DQ, :capture(True));
    is $r2.stdout.trim, '1', '双引号内空结果 → 保留一个空参数';

    # 展开层的直接断言（不经过 shell）
    my @a = expand-words(['$(echo a b)'], Hash.new, sub (Str $inner, Str $whole) { 'a b' });
    is @a.elems, 2, '裸位置结果按空白切成 2 个词';
    my @b = expand-words(['"$(echo a b)"'], Hash.new, sub (Str $inner, Str $whole) { 'a b' });
    is @b.elems, 1, '双引号内不切词';
    my @c = expand-words(['$(echo)'], Hash.new, sub (Str $inner, Str $whole) { '' });
    is @c.elems, 0, '空结果 → 整个词删除';
    my @d = expand-words(['"$(echo)"'], Hash.new, sub (Str $inner, Str $whole) { '' });
    is @d.elems, 1, '双引号内的空结果 → 保留一个空词';
}

subtest "拼接：字面量与结果粘在一起", {
    # bash：x$(echo a b)y → 两个词 "xa" 与 "by"
    my $r = run-shell-line('echo x$(echo a b)y', :capture(True));
    is $r.stdout.trim, 'xa by', 'xa 与 by';
}

subtest "尾部换行被去掉", {
    my $r = run-shell-line('echo $(printf ' ~ $SQ ~ 'a' ~ $BS ~ 'n' ~ $BS ~ 'n' ~ $SQ ~ ')', :capture(True));
    is $r.stdout.trim, 'a', '两个尾随换行都去掉';
}

subtest "嵌套替换", {
    my $r = run-shell-line('echo $(echo $(echo deep))', :capture(True));
    is $r.stdout.trim, 'deep', '两层嵌套';
    my $r2 = run-shell-line('echo ' ~ $DQ ~ '$(echo $(echo deep))' ~ $DQ, :capture(True));
    is $r2.stdout.trim, 'deep', '双引号内嵌套';
}

subtest "单引号内不替换（bash 语义）", {
    my $r = run-shell-line('echo ' ~ $SQ ~ '$(echo nope)' ~ $SQ, :capture(True));
    is $r.stdout.trim, '$(echo nope)', '原样输出';
}

subtest "反引号命令替换", {
    my $r = run-shell-line('echo ' ~ $BT ~ 'echo bt' ~ $BT, :capture(True));
    is $r.stdout.trim, 'bt', '反引号也能替换';
    my $r2 = run-shell-line('echo ' ~ $DQ ~ $BT ~ 'echo bt' ~ $BT ~ $DQ, :capture(True));
    is $r2.stdout.trim, 'bt', '双引号内的反引号';
}

subtest "内层命令的引号不被提前剥掉", {
    # ⚠ 这是个真 bug 的回归：早期实现把内层文本**先展开**再执行，
    #   于是 `printf 'a\n\n'` 的引号被剥掉 → `\n` 变成字面 n → 输出 "ann"。
    my $r = run-shell-line('echo $(printf ' ~ $SQ ~ 'a' ~ $BS ~ 'n' ~ $BS ~ 'n' ~ $SQ ~ ')', :capture(True));
    is $r.stdout.trim, 'a', 'printf 的格式串没被破坏';
}

subtest "会话变量在命令替换里可见", {
    clear-vars();
    my $r = run-shell-line('export RK_CMDSUB=bar && echo $(echo $RK_CMDSUB)', :capture(True));
    is $r.stdout.trim, 'bar', 'export 之后命令替换里能看到';
    my $r2 = run-shell-line('echo $(echo $RK_CMDSUB)', :capture(True));
    is $r2.stdout.trim, 'bar', '下一行也还在（会话变量跨行存活）';
    clear-vars();
}

subtest "export 的值可以来自命令替换", {
    clear-vars();
    my $r = run-shell-line('export RK_FROM_SUB=$(echo baz) && echo $RK_FROM_SUB', :capture(True));
    is $r.stdout.trim, 'baz', '值取自命令替换';
    clear-vars();
}

subtest "命令只跑一次（预扫描 + 执行遍共用缓存）", {
    # 这一行会被扫两遍（预扫描 + 执行遍）。如果命令替换在两遍里
    # 各跑一次，计数器文件里就会有**两行**。
    my $cf = '/tmp/rakuish-t37-count';
    try { unlink $cf };
    my $r = run-shell-line('echo $(echo x >> ' ~ $cf ~ ')', :capture(True));
    is $r.stdout.trim, q{}, '内层输出被重定向进文件，外层拿到空串';
    my $text = try { slurp($cf) };
    ok $text.defined, '计数器文件生成了';
    is $text.lines.elems, 1, '命令只执行了 1 次';
    try { unlink $cf };
}

subtest "命令替换的输出会参与 glob（bash 语义）", {
    setup-glob-dir();
    # bash：echo $(echo '/dir/*.txt') → 展开成文件名（裸位置的结果会 glob）
    my $r = run-shell-line('echo $(echo ' ~ $SQ ~ $GDIR ~ '/*.txt' ~ $SQ ~ ')', :capture(True));
    is $r.stdout.trim, $GDIR ~ '/a.txt ' ~ $GDIR ~ '/b.txt', '裸位置的结果被 glob 展开';

    # 引号保护住模式 → 不 glob
    my $r2 = run-shell-line('echo ' ~ $DQ ~ $GDIR ~ '/*.txt' ~ $DQ, :capture(True));
    is $r2.stdout.trim, $GDIR ~ '/*.txt', '双引号内不 glob';
}

subtest "变量展开出来的通配也会 glob（bash 语义）", {
    setup-glob-dir();
    clear-vars();
    my $r = run-shell-line('export RK_GLOB=' ~ $DQ ~ $GDIR ~ '/*.txt' ~ $DQ
                           ~ ' && echo $RK_GLOB', :capture(True));
    is $r.stdout.trim, $GDIR ~ '/a.txt ' ~ $GDIR ~ '/b.txt', '裸位置的变量展开会 glob';
    my $r2 = run-shell-line('echo ' ~ $DQ ~ '$RK_GLOB' ~ $DQ, :capture(True));
    is $r2.stdout.trim, $GDIR ~ '/*.txt', '双引号内不 glob';
    clear-vars();
}

subtest "字符类 glob", {
    setup-glob-dir();
    my $r = run-shell-line('echo ' ~ $GDIR ~ '/c[0-9].dat', :capture(True));
    is $r.stdout.trim, $GDIR ~ '/c1.dat', '区间 [0-9]';
    my $r2 = run-shell-line('echo ' ~ $GDIR ~ '/[cd][0-9].dat', :capture(True));
    is $r2.stdout.trim, $GDIR ~ '/c1.dat ' ~ $GDIR ~ '/d2.dat', '两个字符类';
    # 取反：`[!ab][0-9].dat` 匹配 c1.dat / d2.dat（首字母都不是 a/b）
    my $r3 = run-shell-line('echo ' ~ $GDIR ~ '/[!ab][0-9].dat', :capture(True));
    is $r3.stdout.trim, $GDIR ~ '/c1.dat ' ~ $GDIR ~ '/d2.dat', '取反 [!ab]';
    # ⚠ 模式不匹配时**原样保留**（bash 语义）：
    #   `[!ab].dat` 要的是「1 个字符 + .dat」，c1.dat 有 2 个字符 → 不匹配
    my $r4 = run-shell-line('echo ' ~ $GDIR ~ '/[!ab].dat', :capture(True));
    is $r4.stdout.trim, $GDIR ~ '/[!ab].dat', '不匹配 → 原样保留';
}

subtest "原生支持判定：命令替换现在原生支持", {
    ok native-supported('echo $(date)'), '$(...) 原生支持';
    ok native-supported('echo ' ~ $BT ~ 'date' ~ $BT), '反引号原生支持';
}

subtest "内层命令失败不影响外层（bash 语义）", {
    # bash：$(false) → 空串，退出码取**外层**的
    my $r = run-shell-line('echo $(false)', :capture(True));
    is $r.code, 0, '退出码是 echo 的（0）';
    is $r.stdout.trim, q{}, '输出为空';
}

done-testing;
