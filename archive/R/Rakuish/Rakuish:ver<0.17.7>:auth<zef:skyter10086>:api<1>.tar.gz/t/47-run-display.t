use v6;
use lib 'lib';
use Test;
use Rakuish::Loop;
use Rakuish::Eval;
use Rakuish::Result;

# C 方案 P3：DSL 糖之二 —— **裸 run 直接展示命令输出**
#
# 用户敲 `run 'ls'` 想看的就是 ls 的输出，不是 `Result(code=0 · 12 行 · …)`。
# 所以裸调用 → 渲染 .out；`my $r = run 'ls'` → 仍走 Result 摘要（不刷屏）。
#
# 判定放在**源码**上（bare-run-src）而不是结果上，这样赋值/传参/当实参
# 这些「要的是对象」的场合一律不受影响。三种边界都在下面钉住。

plan 15;

# ── ① 源码判定 ──────────────────────────────────────────────────────
ok bare-run-src(q{run 'ls'}),            '裸 run 命中';
ok bare-run-src(q{run 'ls -l'}),         '带参数的裸 run 也命中';
ok bare-run-src(q{  run('ls')  }),       '括号形式命中（前面空白不影响）';
ok bare-run-src(q{run-pipe 'ls' 'wc -l'}), 'run-pipe 同样享受糖';
nok bare-run-src(q{my $r = run 'ls'}),   '赋值 ⇒ 不要糖（保留 Result 摘要）';
nok bare-run-src(q{say run 'ls'}),       '当实参传出去 ⇒ 不要糖';
nok bare-run-src(q{run-this 'ls'}),      '只是前缀像 run 的标识符不算';

# ── ② 渲染 ──────────────────────────────────────────────────────────
is render-result-out(3, run(q{printf 'a\nb\n'})), "Out[3]:\n  a\n  b",
    '多行输出：逐行缩进两格';
is render-result-out(4, run(q{printf 'x'})), 'Out[4]: x', '单行输出：跟在 Out[n] 后面';
is render-result-out(5, run(q{printf ''})), 'Out[5]: (无输出)', '无输出给一句人话';
ok render-result-out(6, run(q{echo bad >&2; exit 2})).contains('[退出码 2]'),
    '非零退出码要标出来（不然静默失败）';
ok render-result-out(7, run(q{echo bad >&2})).contains('stderr: bad'),
    'stderr 单独一行，不混进 stdout';

# ── ③ REPL 集成：真的要这么显示 ─────────────────────────────────────
class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}
sub run-capture(*@script --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    drive(reader-from(@script), :color(False));
    $sink
}

my $bare = run-capture(q{run 'ls t/09-complete.t t/10-eval.t'});
ok $bare.text.contains('09-complete.t'), 'REPL 里裸 run：输出内容直接出现';
nok $bare.text.contains('Result('), 'REPL 里裸 run：不出现 Result 摘要';

my $assigned = run-capture(q{my $x = run 'ls t/09-complete.t'});
ok $assigned.text.contains('Result('), '赋值的 run：仍显示 Result 摘要（不刷屏）';
