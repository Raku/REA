use lib "lib";
use Test;
use Rakuish::Loop;

# ── 输出收集器（与 t/04-loop.t 同套路：out-line 走 $*OUT.say）──
class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}
sub run-capture(*@script, Bool :$color = False --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    drive(reader-from(@script), :$color);
    $sink
}

subtest "highlight-raku：词法上色", {
    my $s = highlight-raku('my $x = 42;', :color(True));
    ok $s.contains("\e[35m"),            '关键字有洋红';
    ok $s.contains("\e[33m\$x"),         '变量黄色';
    ok $s.contains("\e[36m42"),          '数字青色';
    is highlight-raku('my $x', :color(False)), 'my $x', '关颜色原样返回';
};

subtest "highlight-raku：注释与字符串", {
    my $s = highlight-raku('# note', :color(True));
    ok $s.contains("\e[90m# note"),      '注释灰';
    ok highlight-raku(q{say "hi"}, :color(True)).contains("\e[32m\"hi\""), '双引号串绿';
    ok highlight-raku("my \$a = 'x'", :color(True)).contains("\e[32m'x'"), '单引号串绿';
    ok highlight-raku('my $b = q[z];', :color(True)).contains("\e[32mq[z]"), 'q[ ] 绿';
};

subtest "highlight-raku：twigil 与下标", {
    my $s = highlight-raku('my %h; %h<k> = 1', :color(True));
    ok $s.contains("\e[33m\%h"),          '哈希变量黄色';
    my $t = highlight-raku('my @a; @a[0]', :color(True));
    ok $t.contains("\e[33m\@a"),          '数组变量黄色';
};

subtest "highlight-shell：命令名 / flag / 串", {
    my $s = highlight-shell('ls -l /tmp', :color(True));
    ok $s.contains("\e[32mls"),           '命令名绿';
    ok $s.contains("\e[36m-l"),           'flag 青';
    is highlight-shell('ls', :color(False)), 'ls', '关颜色原样';
};

subtest "highlight-magic：% 命令名", {
    ok highlight-magic('help', :color(True)).contains("\e[36mhelp"), 'magic 名青';
};

subtest "highlight-command：按前缀派发", {
    ok highlight-command('my $x', :color(True)).contains('my'),  'raku 行';
    ok highlight-command('!ls', :color(True)).contains('ls'),   'shell 行';
    ok highlight-command('`pwd`', :color(True)).contains('pwd'), '反引号行';
    ok highlight-command('%time', :color(True)).contains('time'), 'magic 行';
};

subtest "command-record：In[n] 前缀", {
    my $s = command-record(2, 'my $x = 1', :color(True));
    ok $s.contains('In[2]'),               '含 In[2]';
    ok $s.contains("\e[90mIn[2]"),         '前缀灰';
    is command-record(2, 'my $x = 1', :color(False)), 'In[2] my $x = 1', '关颜色纯文本';
};

subtest "drive：开颜色时回显带色", {
    my $s = run-capture('my $x = 7', '!echo hi', :color(True));
    ok $s.text.contains('In[1]'),          '第一格有 In[1] 回显';
    ok $s.text.contains('In[2]'),          '第二格有 In[2] 回显';
    ok $s.text.contains("\e["),            '回显带 ANSI 颜色';
    ok $s.text.contains(q{Out[1]}),        '结果仍正常';
};

subtest "drive：关颜色时不打印回显", {
    my $s = run-capture('1 + 1', :color(False));
    ok !$s.text.contains('In['),           '关颜色无 In[ 回显';
    ok $s.text.contains(q{Out[1]: 2}),     '结果正常';
};

done-testing;
