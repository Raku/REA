use lib 'lib';
use Test;
use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;
use Rakuish::Shell::Expand;
use Rakuish::Shell::Exec;
use Rakuish::Shell::Session;

# t/39-shell-special-params.t —— 原生 shell 层的**特殊参数**与 **brace 展开**
#
# 本文件覆盖两件事：
#
#   ① **brace 展开** `{a,b}` / `{1..5}`（bash 语义）
#      · 词级、**变量展开之前**发生
#      · 引号里的 `{` `}` 不参与
#      · 没有逗号也没有 `..` ⇒ 不展开（`{a}` 是字面量）
#      · 多个组形成**笛卡尔积**（同一词内）
#      · 不同词之间是**拼接**（不是笛卡尔积）
#
#   ② **特殊参数** `$?` / `$$`
#      · `$?` = 上一条命令的退出码（**每条 pipeline** 都更新）
#      · `$$` = Rakuish 进程的 PID（会话内恒定）
#
# ⚠⚠ 期望值**全部来自真 bash 实测**（bash 5.3.9），不是推想的。
#   对拍脚本见本文件末尾的说明。
#
# ⚠ 本文件里的 shell 命令**一律用单引号**写：Raku 的双引号串里
#   `{` 是哈希下标、`$(` 是代码插值 —— 写成双引号会得到莫名其妙的编译错误。

my $SQ = chr(39);
my $DQ = chr(34);
my $BS = chr(92);

# 跑一行，取 stdout（去掉尾部换行）。
sub run-out(Str $line --> Str) {
    my $r = run-shell-line($line, :capture(True));
    $r.stdout.Str.trim
}

# ══════════════════════════════════════════════════════════════════════
# ① brace 展开 —— 词法层
# ══════════════════════════════════════════════════════════════════════

subtest "brace 展开：逗号组", {
    is brace-expand-text('{a,b}').join(' '), 'a b', '最基本的一组';
    is brace-expand-text('pre{a,b}post').join(' '), 'preapost prebpost',
        '前后缀保留（每个候选项都带上前后缀）';
    is brace-expand-text('{a,b,c}').join(' '), 'a b c', '三个候选项';
    is brace-expand-text('{,a}').join(' '), 'a', '空的候选项被丢掉';
    is brace-expand-text('{a,}').join(' '), 'a', '尾部空的候选项被丢掉';
    is brace-expand-text('{a,,b}').join(' '), 'a b', '中间空的候选项被丢掉';
    is brace-expand-text('{a,{b,c}}').join(' '), 'a b c', '嵌套的组也展开';
    is brace-expand-text('{a{b,c}}').join(' '), '{ab} {ac}',
        '外层组不可展开时，内层的组照样展开';
    is brace-expand-text('{a}{b,c}').join(' '), '{a}b {a}c',
        '左边不可展开的组原样保留，右边的展开';
}

subtest "brace 展开：区间", {
    is brace-expand-text('{1..5}').join(' '), '1 2 3 4 5', '数值区间';
    is brace-expand-text('{5..1}').join(' '), '5 4 3 2 1', '降序';
    is brace-expand-text('{a..e}').join(' '), 'a b c d e', '字符区间';
    is brace-expand-text('{01..03}').join(' '), '01 02 03', '前导零 ⇒ 补零';
    is brace-expand-text('{001..010}').join(' '), '001 002 003 004 005 006 007 008 009 010',
        '补零到端点的宽度';
    is brace-expand-text('{3..01}').join(' '), '03 02 01', '降序也补零';
    is brace-expand-text('{1..10..2}').join(' '), '1 3 5 7 9', '步长';
    is brace-expand-text('{a..z..3}').join(' '), 'a d g j m p s v y', '字符区间带步长';
    is brace-expand-text('{5..1..-1}').join(' '), '5 4 3 2 1', '负步长 + 降序';
    is brace-expand-text('{-1..1}').join(' '), '-1 0 1', '负数起点';
}

subtest "brace 展开：字面量与引号", {
    is brace-expand-text('{a}').join(' '), '{a}', '没有逗号也没有 .. ⇒ 不展开';
    is brace-expand-text('{}').join(' '), '{}', '空组不展开';
    is brace-expand-text('{a..5}').join(' '), '{a..5}', '混合端点不展开';
    is brace-expand-text('{ab..ad}').join(' '), '{ab..ad}', '两端不止一个字符不展开';
    is brace-expand-text('{1..3..}').join(' '), '{1..3..}', '步长非法不展开';
    is brace-expand-text('{1..3,x}').join(' '), '1..3 x',
        '有逗号时区间不再展开（bash 实测）';
    is brace-expand-text('{x,1..3}').join(' '), 'x 1..3', '同上';
    is brace-expand-text($DQ ~ '{a,b}' ~ $DQ).join(' '), $DQ ~ '{a,b}' ~ $DQ,
        '双引号里的组不展开';
    is brace-expand-text($SQ ~ '{a,b}' ~ $SQ).join(' '), $SQ ~ '{a,b}' ~ $SQ,
        '单引号里的组不展开';
    is brace-expand-text('${VAR}').join(' '), '${VAR}',
        '${VAR} 是**变量**，不是 brace 组';
    is brace-expand-text('$${a,b}').join(' '), '$$a $$b',
        '$$ 之后的组是独立的组';
}

subtest "brace 展开：笛卡尔积", {
    is brace-expand-text('{a,b}{c,d}').join(' '), 'ac ad bc bd',
        '同一个词里的两个组 ⇒ 笛卡尔积（左边的变化最慢）';
    is brace-expand-text('{a,b}{c,d}{e,f}').join(' '), 'ace acf ade adf bce bcf bde bdf',
        '三个组';
    is brace-expand-text('x{a,b}y{c,d}').join(' '), 'xayc xayd xbyc xbyd',
        '前后缀 + 两个组';
}

# ══════════════════════════════════════════════════════════════════════
# ② brace 展开 —— 执行层
# ══════════════════════════════════════════════════════════════════════

subtest "brace 展开：执行层", {
    is run-out('echo {a,b}'), 'a b', '一个词展开成两个参数';
    is run-out('echo {1..3}'), '1 2 3', '区间';
    is run-out('echo pre{a,b}post'), 'preapost prebpost', '前后缀';
    is run-out('echo {a,b} {c,d}'), 'a b c d',
        '两个**不同的词** ⇒ 拼接（不是笛卡尔积）';
    is run-out('echo {a,b}{c,d}'), 'ac ad bc bd', '同一个词里的两个组 ⇒ 笛卡尔积';
    is run-out('echo "{a,b}"'), '{a,b}', '双引号保护';
    is run-out('echo {a}'), '{a}', '不展开的组是字面量';
    is run-out('echo {01..03}'), '01 02 03', '补零';
}

subtest "brace 展开：原生路径（多命令行）也展开", {
    # ⚠⚠ **2026-11-05 行为变更**（§5.8.7「不跨引擎委托」）：
    #   native 后端**不再**把整行交给 sh ⇒ 「回退路径」这个概念没了。
    #   以前这条用例专门验「我们自己展开」（因为 dash 不支持 brace 展开）——
    #   现在 brace 展开住在**词法层**（切词之后、变量展开之前），
    #   所以**多命令行**（`&&` / `;`）里一样生效 ✓
    is run-out('echo {a,b} && echo {1..3}'), join("\n", 'a b', '1 2 3'),
        '多个 pipeline 里 brace 都展开';
    is run-out('echo {a,b} ; echo {c,d}'), join("\n", 'a b', 'c d'),
        '分号后面也展开';
    is run-out('echo {a,b} {c,d}'), 'a b c d',
        '两个**不同的词** ⇒ 拼接（不是笛卡尔积）';

    # ⚠ `cd` 是 shell 内建（我们还没实现）⇒ 现在**明确报错**，
    #   而不是偷偷交给 sh（那会让 dash 的语义泄漏进来）。
    my $r = run-shell-line('cd /tmp && echo {a,b}', :capture(True));
    is $r.code, 2, 'cd（shell 内建）⇒ 退出码 2';
    ok $r.stderr.contains('不支持'), '并且说清楚「不支持」';
    ok $r.stderr.contains('@bash'), '并告诉用户怎么委托给 bash 引擎';
}

# ══════════════════════════════════════════════════════════════════════
# ③ `$?` —— 上一条命令的退出码
# ══════════════════════════════════════════════════════════════════════

subtest '$? 展开成上一条命令的退出码', {
    run-shell-line('true', :capture(True));
    is run-out('echo $?'), '0', '成功 ⇒ 0';

    run-shell-line('false', :capture(True));
    is run-out('echo $?'), '1', '失败 ⇒ 1';

    # 同一行里也是**逐条 pipeline** 更新（bash 语义）
    run-shell-line('true', :capture(True));
    is run-out('false; echo $?'), '1', '`false; echo $?` ⇒ 1';
    is run-out('false && echo $?'), q{},
        '`false && echo $?` ⇒ echo 根本不执行（短路）';
    is run-out('false || echo $?'), '1', '`false || echo $?` ⇒ 1';
    is run-out('false | true; echo $?'), '0',
        '管道的退出码取**最后一条**命令的 ⇒ 0';
    is run-out('false && true; echo $?'), '1',
        '`false && true` 里 true 没执行 ⇒ 退出码仍是 1';
}

subtest '$? 的引号规则', {
    run-shell-line('false', :capture(True));
    is run-out('echo "$?"'), '1', '双引号内也展开';
    is run-out('echo ' ~ $SQ ~ '$?' ~ $SQ), '$?', '单引号内是字面量';
    is run-out('echo ' ~ $BS ~ '$?'), '$?', '反斜杠转义 ⇒ 字面量';
}

subtest '$? 跨格（会话里）也正确', {
    # ⚠ 2026-11-05：不再有「整行交 sh」的回退路径（§5.8.7）——
    #   `$?` 的语义改由**原生路径**保证：
    #   ① 上一格留下的退出码，下一格能看到（会话状态）
    #   ② 行内语义**优先于**初值（bash：`cd` 成功 ⇒ `$?` 是 0）
    run-shell-line('false', :capture(True));
    is run-out('echo $?'), '1', '上一格的 `false` ⇒ 下一格看到 1';

    run-shell-line('false', :capture(True));
    is run-out('true && echo $?'), '0', '行内语义优先于初值';

    run-shell-line('false', :capture(True));
    is run-out('false ; echo $?'), '1', '分号后面的命令看到前面的退出码';
}

# ══════════════════════════════════════════════════════════════════════
# ④ `$$` —— shell 的 PID
# ══════════════════════════════════════════════════════════════════════

subtest '$$ 展开成 Rakuish 进程的 PID', {
    my $pid = run-out('echo $$');
    ok $pid.chars > 0, '不是空串';
    ok $pid.Int > 0, '是一个正整数';
    is $pid.Int, shell-pid(), '与 shell-pid() 一致';

    # 会话内**恒定**（不是每条命令一个 PID）
    is run-out('echo $$'), $pid, '两条命令的 `$$` 相同';

    is run-out('echo "$$"'), $pid, '双引号内也展开';
    is run-out('echo ' ~ $SQ ~ '$$' ~ $SQ), '$$', '单引号内是字面量';
}

subtest '$$ 在多命令行里也是同一个 PID', {
    # ⚠ 2026-11-05：不再有「整行交 sh」的回退路径（§5.8.7）。
    #   `$$` 的语义（会话内恒定）现在完全由**原生路径**保证。
    my $pid = run-out('echo $$');
    is run-out('echo a && echo $$'), join("\n", 'a', $pid),
        '多命令行里 `$$` 也不变';
}

subtest '$$ 必须成对吃掉（回归：2026-11-05 修的真 bug）', {
    # ⚠⚠ **真 bug**（2026-11-05 修）：词法层是**逐字符**扫描的 ——
    #   第一个 `$` 被当普通字符收下，第二个 `$` 就**单独**落进
    #   「特殊参数」检查（它看的是**下一个字符** = `"` / 空格）
    #   ⇒ 整行被判 unsupported ⇒ `echo "$$"` 直接报错。
    #   修法：`$$` **成对**吃掉（双引号分支与裸位置分支都要改）。
    my $pid = run-out('echo $$');
    is run-out('echo $$ x'), join(' ', $pid, 'x'),
        '裸位置的 `$$` 后面跟别的词也展开';
    is run-out('echo "a $$ b"'), join(' ', 'a', $pid, 'b'),
        '双引号内、词中间也展开';
    is run-out('echo "$$" x'), join(' ', $pid, 'x'),
        '双引号内的 `$$` 后面跟别的词也展开';
}

# ══════════════════════════════════════════════════════════════════════
# ⑤ `${VAR}` 现在原生支持（以前被误判成「花括号」而整行交 sh）
# ══════════════════════════════════════════════════════════════════════

subtest '${VAR} 原生支持', {
    is lex('echo ${HOME}', :cmdsub(True)).unsupported, q{}, '词法层不再标不支持';
    set-var('RK_T39', 'v39');
    is run-out('echo ${RK_T39}'), 'v39', '花括号形式的变量展开';
    is run-out('echo $RK_T39'), 'v39', '普通形式（对照）';
    unset-var('RK_T39');
}

# ══════════════════════════════════════════════════════════════════════
# ⑥ fd 前缀必须**紧邻**操作符（bash 规则）
# ══════════════════════════════════════════════════════════════════════

subtest "fd 前缀必须紧邻操作符", {
    my $d = '/tmp/rakuish-t39-fd';
    $d.IO.mkdir unless $d.IO.e;
    my $f1 = $d ~ '/a.txt';
    my $f2 = $d ~ '/b.txt';

    run-shell-line('echo 2 > ' ~ $f1, :capture(True));
    is slurp($f1).trim, '2', '`echo 2 > f` 里的 2 是**参数**（不是 fd）';

    run-shell-line('echo 2> ' ~ $f2, :capture(True));
    is slurp($f2).trim, q{}, '`echo 2> f` 里的 2 是**fd**（文件是空的）';

    try { unlink $f1 };
    try { unlink $f2 };
}

# ══════════════════════════════════════════════════════════════════════
# ⑦ 词法层：`{` / `}` 的两种身份
# ══════════════════════════════════════════════════════════════════════

subtest "词法层区分 brace 展开与复合命令", {
    is lex('echo {a,b}', :cmdsub(True)).unsupported, q{},
        '{a,b} 是 brace 展开 ⇒ 原生支持';
    ok lex('{ echo x; }', :cmdsub(True)).unsupported ne q{},
        '`{ cmd; }` 是复合命令 ⇒ 交 sh';
    ok lex('{a,b}', :cmdsub(True)).unsupported eq q{},
        '独立的 `{a,b}` 也是 brace 展开';
    is lex('echo ' ~ $SQ ~ '{a,b}' ~ $SQ, :cmdsub(True)).unsupported, q{},
        '单引号里的花括号是字面量';
}

# ── 对拍说明 ─────────────────────────────────────────────────────────
# 上面每个期望值都来自 bash 5.3.9 的实测：
#   bash -c 'printf "[%s]" {a,b}'            → a b
#   bash -c 'printf "[%s]" {01..03}'         → 01 02 03
#   bash -c 'printf "[%s]" {a,{b,c}}'       → a b c
#   bash -c 'printf "[%s]" {a,b}{c,d}'       → ac ad bc bd
#   bash -c 'false; echo $?'                 → 1
#   bash -c 'false | true; echo $?'          → 0
#   bash -c 'echo 2 > f'                     → 文件里是 "2"
#   bash -c 'echo 2> f'                      → 文件是空的

done-testing;
