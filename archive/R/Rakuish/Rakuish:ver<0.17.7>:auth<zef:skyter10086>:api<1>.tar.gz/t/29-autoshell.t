use lib "lib";
use Test;
use Rakuish::Loop;

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method print(*@a)      { @.lines.push: @a.join; Nil }
    method flush()         { }
}

sub run1(Str $line, Bool :$auto = True --> Str) {
    my $s = Sink.new;
    { temp $*OUT = $s; drive(reader-from($line), :color(False), :auto-shell($auto)); }
    $s.lines.join("\n")
}

# ── 1. shell-candidate：与 PATH 无关的「一定不是命令」────────────────
# 这些是最要紧的护栏 —— 判错就意味着 Raku 代码被改道或重复执行。
is shell-candidate(q{say 1}),   q{}, q{say 是 Raku 内建，不是命令};
is shell-candidate(q{print 1}), q{}, q{print 同上};
is shell-candidate(q{my $x = 1}), q{}, q{my 开头是 Raku};
is shell-candidate(q{if 1 { 1 }}), q{}, q{if 是关键字};
is shell-candidate(q{say 1; rm -rf x}), q{}, q{多语句行一律拒绝（防 Raku 侧先执行一遍）};
is shell-candidate(q{$x}),    q{}, q{$ 开头是 sigil};
is shell-candidate(q{@rows}), q{}, q{@ 开头是 sigil};
is shell-candidate(q{%h}),    q{}, q{% 开头是 sigil};
is shell-candidate(q{&code}), q{}, q{& 开头是 sigil};
is shell-candidate(q{(1,2,3).grep(* > 1)}), q{}, q{方法调用不是命令};
is shell-candidate(q{foo(1)}), q{}, q{带括号的不是命令};
is shell-candidate(q{sayy 1}), q{}, q{拼错且不在 PATH：仍按 Raku 报错};

# ── 2. shell-candidate：确实在 PATH 里时认出来 ───────────────────────
my $ls-exe = executable-in-path(q{ls});
ok $ls-exe.chars > 0, q{环境前提：ls 在 PATH 里（找到 } ~ $ls-exe ~ q{）};
is shell-candidate(q{ls}),     $ls-exe, q{ls 被认成外部命令};
is shell-candidate(q{ls -la}), $ls-exe, q{带参数的 ls 同样按首个词判定};
is executable-in-path(q{绝对不存在的命令-xyzzy}), q{}, q{不在 PATH 的命令返回空};

# ── 3. drive 集成：裸敲命令会转交 shell ──────────────────────────────
# ⚠ 用 `whoami` 而不是 `pwd`：P2 之后 `pwd` 是**宿主内建**，不走自动回退
#   （见 t/45-builtins.t）。自动回退测的是"PATH 里的外部命令"这条路径。
my $o = run1(q{whoami});
ok  $o.contains(q{[shell]}), q{裸敲外部命令自动转交 shell（有 [shell] 标记）};
ok !$o.contains(q{错误}),    q{转交后不再报 Raku 错};

$o = run1(q{whoami}, :auto(False));
ok  $o.contains(q{错误}),     q{auto-shell = false 时回到旧行为（报 Raku 错）};
ok !$o.contains(q{[shell]}), q{关闭时不打 [shell] 标记};

# ── 4. 回归护栏：能跑通的 Raku 行绝不能被改道 ────────────────────────
$o = run1(q{say 1 + 1});
ok  $o.contains('Out[1]: True'), q{say 1 + 1 照旧求值};
ok !$o.contains(q{[shell]}),      q{say 1 + 1 不会被转交};

$o = run1(q{my $z = 5});
ok  $o.contains('Out[1]: 5'), q{my 声明照旧};
ok !$o.contains(q{[shell]}),  q{my 声明不会被转交};

$o = run1(q{(1,2,3).grep(* > 1).elems});
ok $o.contains('Out[1]: 2'), q{方法调用照旧求值};

# ── 5. auto-shell 是可配置项 ──────────────────────────────────────────
ok known-config-key(q{auto-shell}), q{auto-shell 是已知配置项};
ok rc-defaults()<auto-shell>,       q{auto-shell 默认为开};

done-testing;
