# t/03-eval.t —— 快档求值与结果渲染
#
# 必须在 **两个 Raku 实现上都跑**，且断言**行为一致**。
# "什么该进 Out[]、什么不该"这类语义两个实现的 EVAL 行为本来就不同，
# 这一层就是把它们统一起来的地方。
#
# 写断言的规矩（都是这一轮踩出来的）：
#   · 正则里**不能有空格**（Raku 默认 sigspace，/a b/ 会被警告成匹配 "ab"）→ 用 \s+ 或 \x20
#   · 正则里**不能有裸元字符**（`!` `-` `<` `>` 都会被当元字符报错）→ 用 \x20 \x2D \x3C \x3E
#   · **没有 `ok!`**（Test 模组的 ok 没有否定式）→ 写 `ok !x`
#   · 别写 `is $x, Nil`（`:value(Nil)` 等于不指定，拿到的是 Any）→ 写 `ok !$x.defined`

use Test;
use lib "lib";
use Rakuish::Eval;

plan 5;

# ── 1. 求值：拿值、认错、把Nil 与失败分开 ────────────────────────────
subtest 'eval-cell 拿值与认错', {
    my $r1 = eval-cell('1 + 1');
    ok $r1.ok, '表达式求值成功';
    is $r1.value, 2, '拿到值';
    ok !$r1.error.defined, '成功时没有异常对象';

    my $r2 = eval-cell('nosuchroutine-zz');
    ok !$r2.ok, '不存在的例程名则失败';
    ok $r2.error ~~ Exception, '失败时有异常对象';
    is $r2.source, 'nosuchroutine-zz', '保留原始输入（错误渲染要用）';

    # 真正的 Nil 值不能与"失败"混淆
    my $r3 = eval-cell('Nil');
    ok $r3.ok, 'Nil 是成功的求值';
    ok !($r3.value ~~ Exception), 'Nil 不是异常';
};

# ── 2. 会话：In[n] / Out[n] / `_` ────────────────────────────────────
subtest 'Session 记录 In 与 Out 以及下划线', {
    my $s = Session.new;
    $s.run('1 + 1');
    $s.run('"hi"');
    is $s.out-count, 2, '两次成功求值则 Out 有两项';
    is $s.out-at(1), 2, 'Out[1] 是 2';
    is $s.out-at(2), 'hi', 'Out[2] 是 hi';
    is $s.in-at(1), '1 + 1', 'In[1] 是源码';
    is $s.last-value, 'hi', '下划线是最近一次结果';
    is $s.out-at(99), Nil, '越界的 Out 取到 Nil（不报错）';
    is $s.in-at(0), '', '越界的 In 取到空串';

    # 失败的 cell **不占 Out 编号**（与 IPython 一致），但占 In 编号
    my $s2 = Session.new;
    $s2.run('1 + 1');
    my $bad = $s2.run('nosuch-zz');
    is $bad.index, 2, '失败 cell 的序号仍然递增';
    is $s2.out-count, 1, '失败不占 Out';
    is $s2.last-value, 2, '下划线仍是上一个成功结果';
    is $s2.in-at(2), 'nosuch-zz', '失败 cell 也记进 In';

    ok !Session.new.last-value.defined, '空会话的下划线是 Nil';
};

# ── 3. 跨 cell 共享状态（两个实现一致的关键机制）─────────────────────
subtest '共享存储跨 cell 可用', {
    # 用过程式 API（store-set / store-get）而不是 `store(){...}=...`：
    # 后者在 rakupp 上不可赋值（"Target is not assignable"）。
    store-set('answer', 42);
    is store-get('answer'), 42, '同一 cell 内读写';
    ok store-has('answer'), 'store-has 能看到';

    my $r = eval-cell(q{store-set('answer', 43); store-get('answer')});
    is $r.value, 43, 'cell 里能写共享存储';
    is store-get('answer'), 43, '外层看得到 cell 的写';

    is eval-cell(q{store-get('answer')}).value, 43, '下一个 cell 能读到';
    ok eval-cell(q{store-has('answer')}).value, 'cell 里能问存在性';

    # 直接写 %STORE 两个实现都支持（cell 靠词法嵌套看到外层的 our）
    is eval-cell(q{%STORE{'answer'} = 44; %STORE{'answer'}}).value, 44,
        'cell 里直接写 %STORE 也可以';

    store-del('answer');
    ok !store-has('answer'), '删掉后确实没有了';
    is store-keys().elems, 0, 'keys 随之清空';
};

# ── 4. 值的渲染 ──────────────────────────────────────────────────────
subtest 'format-value 按类型着色与容器 dump 渲染', {
    is format-value(Nil), 'Nil', 'Nil';
    is format-value(42), '42', '整数';
    is format-value(3.14), '3.14', '浮点';
    is format-value('hi'), '"hi"', '字符串（dump 带引号）';
    is format-value(True), 'True', '布尔';
    is format-value((1, 2, 3)), '(1, 2, 3)', 'List 的 raku 带圆括号（decont 后无 $ 前缀）';
    ok !format-value((1, 2, 3)).starts-with('\$'), 'List 无 Scalar \$ 前缀（decont 生效）';
    ok !format-value(%(a => 1, b => 2)).starts-with('\$'), 'Hash 无 Scalar \$ 前缀';

    # 中等大小容器完整显示（dump 风格不再静默折叠）
    my $mid = format-value((1..200).List);
    ok !$mid.contains('items'), '中等列表完整显示不折叠';

    # 超大容器做头尾采样并标注真实元素数（绝不静默隐藏）
    my $big = format-value((1..1500).List);
    ok $big.contains('1500 items'), '超大列表采样并标注真实元素数: ' ~ $big;
    ok !$big.contains('1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14'),
        '超大列表不再逐项展开';

    # 含换行的 Str 用 \n 转义，保持单行（dump 风格）
    is format-value("a\nb"), '"a\nb"', '多行 Str 用 \n 转义';

    # 颜色开关
    ok !format-value(42, :color(False)).contains("\e["), '不染色时没有转义序列';
    ok format-value(42, :color(True)).contains("\e["), '染色时有转义序列';
    ok format-value(42, :color(True)).contains('42'), '染色后文本本身不变';

    # Out 标签
    ok render-out(3, 42).contains('Out[3]'), 'render-out 带 Out 编号';
    ok render-out(3, 42).contains('42'), 'render-out 带值';
};

# ── 5. 错误渲染 ──────────────────────────────────────────────────────
subtest 'render-error 给出可读信息', {
    my $r = eval-cell('nosuchroutine-zz');
    my $msg = render-error($r);
    ok $msg.contains('nosuchroutine-zz'), '带上了异常消息（含出错的那个名字）';
    ok !$msg.contains('SORRY'), '内部的 SORRY 头被过滤掉';
    ok !$msg.contains('EVAL_'), '内部临时文件名 EVAL_N 被过滤掉';
    ok $msg.contains('nosuchroutine-zz'), '出错那行源码出现在错误块里';

    # 建议要可操作：未定义的名字提示加叹号走 shell
    ok $msg.contains('!'), '未定义的名字给出加叹号的建议';

    # 无异常对象时也不能炸
    ok render-error(CellResult.new(:ok(False), :source('x'))).contains('无异常对象'),
        '没有异常对象时如实说明';
};