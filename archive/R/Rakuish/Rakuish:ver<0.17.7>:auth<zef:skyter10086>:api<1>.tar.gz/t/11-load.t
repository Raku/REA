use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Eval;

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}

sub load-magic-capture(Str $cmd --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    load-magic($cmd);
    $sink
}

my $dir = $*CWD.add('11-tmp');
$dir.mkdir;

subtest "load-magic：整文件载入，%STORE 状态保留", {
    my $f = $dir.add('whole.raku');
    my $src = q:to/END/;
    %STORE{'wf1'} = 11;
    %STORE{'wf2'} = 22;
    END
    $f.spurt($src);
    my $s = load-magic-capture('load ' ~ $f.absolute);
    ok $s.text.contains('OK'), '成功态 OK';
    ok $s.text.contains('whole.raku'), '框里带文件名';
    ok $s.text.contains('2/2'), '框里标 2/2 行';
    is store-get('wf1'), 11, '%STORE 写入并跨 cell 保留';
    is store-get('wf2'), 22, '%STORE 第二项也保留';
    store-del('wf1'); store-del('wf2');
};

subtest "load-magic：-r 行范围只载选中行", {
    my $f = $dir.add('range.raku');
    my $src = q:to/END/;
    %STORE{'rg1'} = 1;
    %STORE{'rg2'} = 2;
    %STORE{'rg3'} = 3;
    %STORE{'rg4'} = 4;
    %STORE{'rg5'} = 5;
    END
    $f.spurt($src);
    my $s = load-magic-capture('load -r 2-4 ' ~ $f.absolute);
    ok store-has('rg2') && store-has('rg3') && store-has('rg4'), '选中行 2-4 都载入了';
    ok !store-has('rg1') && !store-has('rg5'), '范围外未载入';
    ok $s.text.contains('3/5'), '框里标 3/5 行';
    for <rg1 rg2 rg3 rg4 rg5> { store-del($_) }
};

subtest "load-magic：-s 提取符号（含嵌套块），排除范围外", {
    my $f = $dir.add('sym.raku');
    my $src = q:to/END/;
    # 头部注释
    my $outside = 7;
    sub hi {
        my $x = 1;
        $x + 1;
    }
    my $tail = 8;
    sub nest {
        if True {
            say 42;
        }
    }
    END
    $f.spurt($src);
    my $s1 = load-magic-capture('load -s hi ' ~ $f.absolute);
    ok $s1.text.contains('hi'), '提取到 hi';
    ok !$s1.text.contains('$tail'), '范围外 $tail 未载入';
    ok !$s1.text.contains('$outside'), '声明前的 $outside 也未载入';
    my $s2 = load-magic-capture('load -s nest ' ~ $f.absolute);
    ok $s2.text.contains('nest'), '提取到 nest（含嵌套 if 块）';
    ok !$s2.text.contains('$tail'), 'nest 之后仍排除 $tail';
};

# 回归线（2026-10-30）：%load -s 的匹配正则踩过三个**跨后端**坑 ——
#   ① 多行正则字面量：rakupp 把换行当显著字符，MoarVM 当无意义空白；
#   ② `<[ ... ]>` 字符类在 rakupp「正则存进变量」路径上被拆坏；
#   ③ `$name<[...]>` 被 rakupp 解析成下标而非正则。
# 三个坑的表现都一样：**在 rakupp 上静默匹配不到任何东西**（MoarVM 上却全绿）。
# 下面这组断言锁住「符号名后面必须跟分隔符」这条语义，两后端都必须一致。
subtest "load-magic：-s 符号名边界（不能匹配更长的标识符）", {
    my $f = $dir.add('edge.raku');
    $f.spurt(q:to/END/);
    sub hiya {
        say 'hiya';
    }
    sub hip(Str $x) {
        $x;
    }
    sub hip2 {
        say 'hip2';
    }
    END
    # hi 是 hiya 的前缀：不能把 hiya 当成 hi 提出来
    my $s1 = load-magic-capture('load -s hi ' ~ $f.absolute);
    ok $s1.text.contains('选取为空'), '前缀 hi 匹配不到 hiya（明确报"选取为空"，而非静默）';
    ok !$s1.text.contains('hiya'), '前缀不误匹配更长的标识符 hiya';
    # hip 后面紧跟 '(' —— 括号也是合法分隔符，必须能提取
    my $s2 = load-magic-capture('load -s hip ' ~ $f.absolute);
    ok $s2.text.contains('hip'), '提取到 hip（后面紧跟 "(" 分隔符）';
    ok !$s2.text.contains('hiya'), '提取 hip 时不带上 hiya';
};

subtest "load-magic：文件不存在给报错 + ERR", {
    my $s = load-magic-capture('load nope-xyz.raku');
    ok $s.text.contains('找不到文件'), '有报错';
    ok $s.text.contains('ERR'), '失败态 ERR';
};

subtest "load-magic：无参数给用法", {
    my $s = load-magic-capture('load');
    ok $s.text.contains('用法'), '提示用法';
};

subtest "load-magic：shell 脚本提示改用 %run", {
    my $f = $dir.add('x.sh');
    my $src = q:to/END/;
    #!/bin/sh
    echo hi
    END
    $f.spurt($src);
    my $s = load-magic-capture('load ' ~ $f.absolute);
    ok $s.text.contains('%run'), '提示用 %run';
    ok $s.text.contains('ERR'), '失败态 ERR';
};

subtest "load-magic：载入语法错误文件走错误路径", {
    my $f = $dir.add('bad.raku');
    my $src = q:to/END/;
    this is not valid raku ???
    END
    $f.spurt($src);
    my $s = load-magic-capture('load ' ~ $f.absolute);
    ok $s.text.contains('ERR'), '失败态 ERR';
    ok $s.text.contains('错误'), '有错误渲染';
};

for $dir.dir -> $f { try $f.unlink }
try $dir.rmdir;

done-testing;
