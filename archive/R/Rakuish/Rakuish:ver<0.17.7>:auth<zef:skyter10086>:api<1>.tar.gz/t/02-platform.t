# t/02-platform.t —— 实现差异隔离层
#
# 这份测试必须在 **两个 Raku 实现上都跑**（MoarVM 与 rakupp/C++），
# 而且**断言的是行为一致，不是"各自能不能跑"**。
# 这是 Platform 层存在的意义：把差异关在这一层里，两边跑出一样的结果。

use Test;
use lib 'lib';
use Rakuish::Platform;

plan 5;

# ── 1. catch：成败必须分得清 ─────────────────────────────────────────
subtest 'catch 区分成功与失败', {
    my $o1 = catch(sub { 42 });
    ok $o1.ok, '成功时 ok 为真';
    is $o1.value, 42, '成功时拿得到值';
    ok !$o1.error.defined, q{成功时 error 未定义};

    my $o2 = catch(sub { die "boom" });
    ok !$o2.ok, '失败时 ok 为假';
    ok !$o2.value.defined, q{失败时 value 未定义};
    ok $o2.error ~~ Exception, '失败时 error 是异常对象';
    like $o2.message, /boom/, '异常消息能取到';

    # 关键：失败时**返回值**是未定义值（不是 Failure，也不是异常对象）。
    # 这就是为什么 Platform 提供 catch 而不让人直接用 try ——
    # 光看返回值分不出「返回了 Nil」和「失败了」。
    my $raw = try { die "x" };
    ok $raw.defined.not, '直接用 try 时失败返回未定义值（所以不能靠返回值判断）';
}

# ── 2. run-capture：三个字段都要对 ───────────────────────────────────
subtest 'run-capture 收 stdout / stderr / 退出码', {
    my $r = run-capture('sh', '-c', 'echo OUT; echo ERR >&2; exit 3');
    is $r.out, "OUT\n", 'stdout';
    is $r.err, "ERR\n", 'stderr';
    is $r.exitcode, 3, '退出码';
    ok $r.found, '命令存在时 found 为真';

    my $miss = run-capture('nosuch-cmd-zz-9');
    ok !$miss.found, '命令不存在时 found 为假';
    ok $miss.exitcode < 0, '命令不存在时退出码是负的';

    my $ok = run-capture('echo', '');
    is $ok.out, "\n", '空输出也返回串而不是 Nil';
};

# ── 3. 文本文件 ──────────────────────────────────────────────────────
subtest '文本文件读写', {
    my $path = 'rakuish-t02.tmp';
    write-text-file($path, "a\nb\n");
    is read-text-file($path), "a\nb\n", '写进去读出来一致';
    is read-text-file($path).lines.elems, 2, '行数正确';
    unlink $path;
};

# ── 4. 输出动作：两边行为必须一致 ────────────────────────────────────
subtest 'out-raw 不加换行、out-line 加换行', {
    # 这两条是 REPL 提示符与行内渲染的地基，必须在两个实现上同样行为。
    my $p1 = run-capture($*EXECUTABLE.Str, '-e',
        'use lib "lib"; use Rakuish::Platform;
         Rakuish::Platform::out-raw("AB");
         Rakuish::Platform::out-line("CD");');
    is $p1.out, "ABCD\n", 'out-raw 不加换行，out-line 加';

    my $p2 = run-capture($*EXECUTABLE.Str, '-e',
        'use lib "lib"; use Rakuish::Platform;
         Rakuish::Platform::err-line("E1");');
    is $p2.err, "E1\n", 'err-line 走 stderr';

    # ANSI 透传：着色输出的地基。转义序列必须原样出去。
    my $esc = "\e[31m";
    my $p3 = run-capture($*EXECUTABLE.Str, '-e',
        'use lib "lib"; use Rakuish::Platform;
         Rakuish::Platform::out-raw("\e[31mRED\e[0m");');
    ok $p3.out.contains($esc), 'ANSI 转义原样透传（out-raw 不吞）';
};

# ── 5. 能力自述：靠"做"不靠"问" ──────────────────────────────────────
subtest 'capabilities 靠做来探测', {
    my %c = capabilities();
    ok %c<out-raw>,  'out-raw 可用';
    ok %c<out-line>, 'out-line 可用';
    ok %c<run-out>,  'run 可用';
    ok %c<spurt>,    'spurt 可用';
    like %c<impl>, rx/ MoarVM | rakupp /, '实现名字认得出来';
    try unlink spurt-probe-path();
}