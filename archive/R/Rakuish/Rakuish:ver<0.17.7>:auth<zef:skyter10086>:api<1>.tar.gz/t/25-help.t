use lib "lib";
use Test;
use Rakuish::Loop;

plan 29;

# ── 输出收集器（与 t/21..24 同款）──
class Sink {
    has @.lines;
    method print(*@a) { @!lines.push: @a.join; }
    method say(*@a)   { @!lines.push: @a.join ~ "\n"; }
    method put(*@a)   { @!lines.push: @a.join ~ "\n"; }
    method print-nl() { @!lines.push: "\n"; }
    method write($b)  { @!lines.push: $b.Str; }
    method flush()    { }
}

sub capture(&code) {
    my $s = Sink.new;
    { temp $*OUT = $s; code(); }
    $s.lines.join;
}

# ── 1. %exit 别名接线 ────────────────────────────────────────────────
# 设计注释一直把 %exit 与 %quit 并列，但 kind-of / dispatch / handler /
# drive 四处都没接，%exit 实际会被当 Raku 变量报错。这里锁死修复。
is kind-of(q{%exit}),        'magic', '%exit 被识别为 magic（别名已接线）';
is kind-of(q{%quit}),        'magic', '%quit 仍是 magic';
is kind-of(q{%help}),        'magic', '%help 仍是 magic';
is kind-of(q{%STORE<a> = 1}), 'raku', '%STORE 仍是 raku（防误判回归：早期真实 bug）';

# ── 2. 总览结构 ──────────────────────────────────────────────────────
my $help = capture({ magic-help() });

ok $help.contains('Rakuish · 命令总览'), '总览有标题';

for <输入模式 魔法命令 内建命令 跨格状态 快捷键> -> $sec {
    ok $help.contains($sec), '总览含小节：' ~ $sec;
}

# ── 3. 总览列出全部魔法命令 ──────────────────────────────────────────
for <help time load run repl cd quit exit hist> -> $c {
    ok $help.contains('%' ~ $c), '总览列出 %' ~ $c;
}

# ── 4. 总览列出内建命令（各自用有区分度的描述串）──
ok $help.contains('裸 cd / !cd / %cd'), '内建 cd：三种写法等价';
ok $help.contains('彩色列出当前目录'),   '内建 ls：彩色列出';
ok $help.contains('彩色长列表'),         '内建 ll：彩色长列表';

# ── 5. 总览覆盖 shellq 与跨格状态 ────────────────────────────────────
ok $help.contains('%STORE'), '总览提到 %STORE 跨格状态';
ok $help.contains('反引号'),  '总览提到反引号 shellq';
ok $help.contains('Tab'),     '总览提到 Tab 补全';
ok $help.contains('取消这一块'), '总览说明 Ctrl-D 取消当前块';

# ── 6. 退出分发 ──────────────────────────────────────────────────────
is capture({ magic-dispatch(q{exit}) }).trim, 'bye', '%exit 分发 → bye';
is capture({ magic-dispatch(q{quit}) }).trim, 'bye', '%quit 分发 → bye';

# ── 7. 缩写确实不支持（与总览文档保持一致）──────────────────────────
# kind-of 用**全名**门控 magic 分支，正是为了保护 %h<k> 这类用户哈希不被
# 误判。所以缩写不可用；若将来给 kind-of 加了前缀解析，必须同步改总览文本。
# `h` 现在同时是 help 与 hist 的前缀，Commands 会报歧义 —— 这仍然是
# 「缩写不可用」，只是表现形式从「未知 magic」变成「歧义列表」。
my $h-out = capture-both({ magic-dispatch(q{h}) });
ok $h-out.contains('Ambigous'),
   '缩写不支持（h 同时是 help/hist 前缀 → Commands 报歧义，与总览文档一致）';

# 同时捕获 stdout 与 stderr（Commands 的歧义提示走 stderr：构造时 :err($*ERR)）
sub capture-both(&code --> Str) {
    my $so = Sink.new;
    my $se = Sink.new;
    { temp $*OUT = $so; temp $*ERR = $se; code(); }
    $so.lines.join("\n") ~ "\n" ~ $se.lines.join("\n")
}
