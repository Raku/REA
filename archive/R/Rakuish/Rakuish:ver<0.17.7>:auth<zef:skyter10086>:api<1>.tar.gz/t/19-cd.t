use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Builtins;

# 与 t/04-loop.t 同款输出收集器：把 $*OUT.say 截进 Sink
class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}
sub run-capture(*@script, Bool :$color = False --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    drive(reader-from(@script), :$color);
    $sink
}

my $start = $*CWD.Str;

subtest "change-dir 直接调用", {
    my $m = change-dir('/tmp');
    ok $m.contains('cd →'), '返回成功信息';
    is $*CWD.Str, '/tmp', 'cd /tmp 后 $*CWD 更新';
    my $bad = change-dir('/no/such/dir/xyz');
    ok $bad.contains('没有这个目录'), '不存在目录报错';
    my $h = change-dir('');
    ok $h.contains('cd →'), '无参 cd 回家目录';
    is $*CWD.Str, (%*ENV<HOME> // $*HOME.Str), '回到家目录';
};

subtest "drive 拦截：裸 cd", {
    my $s = run-capture('cd /tmp');
    ok $s.text.contains('cd → /tmp'), '裸 cd /tmp 输出切换信息';
    is $*CWD.Str, '/tmp', '裸 cd 改了 REPL 目录';
};

subtest "drive 拦截：!cd 与 %cd", {
    my $s1 = run-capture('!cd /tmp');
    ok $s1.text.contains('cd → /tmp'), '!cd /tmp 生效';
    is $*CWD.Str, '/tmp', '!cd 改了 REPL 目录';
    my $s2 = run-capture('%cd /tmp');
    ok $s2.text.contains('cd → /tmp'), '%cd /tmp 生效';
};

subtest "drive 拦截：cd 含 \$HOME 展开", {
    my $s = run-capture('cd $HOME');
    ok $s.text.contains('cd →'), 'cd \$HOME 展开并切换';
    is $*CWD.Str, (%*ENV<HOME> // $*HOME.Str), '切到 HOME';
};

subtest "drive 拦截：相对路径 cd", {
    change-dir('/tmp');
    my $s = run-capture('cd ..');
    ok $s.text.contains('cd →'), 'cd .. 生效';
};

# ── 0.16.3：相对路径必须**归一化** ──────────────────────────────────────
# 以前 `cd ..` 停在 `/tmp/..`、`cd ../..` 拼出 `/home/zby/../..//..` ——
# 提示符、`pwd`、`PWD` 一直挂着脏路径（用户实测截图）。bash 的行为是
# `cd ..` 之后 `pwd` 打印父目录本身，所以这里锁「归一化」而不是「能进」。
subtest "相对路径 cd 归一化：裸 cd", {
    change-dir('/tmp');
    my $s = run-capture('cd ..');
    is $*CWD.Str, '/', 'cd .. 落在父目录本身，不是 /tmp/..';
    ok !$s.text.contains('/tmp/..'), "输出里不残留未归一化的路径：{$s.text}";
};

subtest "相对路径 cd 归一化：多段相对路径", {
    change-dir('/tmp');
    my $s = run-capture('cd ../..');
    is $*CWD.Str, '/', 'cd ../.. 落在 /';
    ok !$s.text.contains('//'), "输出里没有双斜杠：{$s.text}";
};

subtest "相对路径 cd 归一化：%cd（走 change-dir 那条路）", {
    change-dir('/tmp');
    my $s = run-capture('%cd ..');
    is $*CWD.Str, '/', '%cd .. 落在父目录本身';
    ok !$s.text.contains('/tmp/..'), "输出里不残留未归一化的路径：{$s.text}";
};

subtest "相对路径 cd 归一化：change-dir 直接调用", {
    change-dir('/tmp');
    my $m = change-dir('..');
    ok $m.contains('cd →'), '返回成功信息';
    is $*CWD.Str, '/', 'change-dir("..") 落在父目录本身';
    ok !$m.contains('/tmp/..'), "输出里不残留未归一化的路径：{$m}";
};

# ── 0.16.4（C1）：两处 cd 实现的报错文案必须**逐字一致** ──────────────
#
# Rakuish 有两个 cd 实现：
#   · `Builtins.cd-into`   —— REPL 裸 `cd` / `!cd` / 脚本模式的 `cd`
#   · `Loop.change-dir`    —— `%cd` 魔法命令
# 以前两者说法不同（`cd /nope` 说「没有这个目录」，`%cd /nope` 说「不是目录或不存在」），
# 同一个错误两套话 ⇒ 用户以为碰到的不是同一个错。本轮统一成三段式：
#   不存在 ⇒ 没有这个目录 / 存在但不是目录 ⇒ 不是目录 / 进不去 ⇒ 进不去
subtest "C1：两处 cd 实现的报错文案一致", {
    # ⚠ 两个实现的**返回形状不同**：`change-dir` 回 Str，`cd-into` 回 Hash
    #   （错误文本在 `err` 键里）。这里比的是**错误文案本身**。
    my $a1 = change-dir('/no/such/dir/xyz');
    my %a2 = cd-into('/no/such/dir/xyz');
    ok $a1.contains('cd: 没有这个目录：'), 'change-dir：不存在';
    ok %a2<err>.contains('cd: 没有这个目录：'), 'cd-into：不存在';
    is $a1, %a2<err>, '两处文案逐字相同（不存在）';

    my $b1 = change-dir('/etc/hostname');
    my %b2 = cd-into('/etc/hostname');
    ok $b1.contains('cd: 不是目录：'), 'change-dir：是文件不是目录';
    ok %b2<err>.contains('cd: 不是目录：'), 'cd-into：是文件不是目录';
    is $b1, %b2<err>, '两处文案逐字相同（不是目录）';
};

# ── 0.16.7（§10.1 #10）：`cd -` ──────────────────────────────────
#
# 以前 `cd -` 在 REPL 里**根本没执行**：行尾的 `-` 被 `is-incomplete`
# 当成**悬空操作符** ⇒ REPL 判定「本格没写完」 ⇒ 等续行
# ⇒ Ctrl-D 后打印「已取消这一块（Ctrl-D）」，`cd` 哪根没跑。
# 根因在 `needs-more`：它只排除了 magic 与 shell 行，**没排除内建行**。
#
# 另外：`cd -` 需要 `OLDPWD`，而 `OLDPWD` 是我们自己维护的
#（`cd-into` / `change-dir` 都要同步它）——不能依赖 bash 的继承。
subtest "0.16.7：cd - 回上一个目录", {
    change-dir('/tmp');
    my $back = $*CWD.Str;
    change-dir('/usr');
    ok $*CWD.Str ne $back, '先切走';
    my $r = change-dir('-');
    ok $r.contains('cd →'), 'cd - 成功';
    is $*CWD.Str, $back, 'cd - 回到上一个目录';
};

subtest "0.16.7：cd - 的 PWD / OLDPWD 同步", {
    change-dir('/tmp');
    is %*ENV<PWD>, '/tmp', 'PWD 跟着走';
    ok (%*ENV<OLDPWD> // q{}).chars, 'OLDPWD 被写入';
    my $old = %*ENV<OLDPWD>;
    change-dir('-');
    is %*ENV<PWD>, $old, 'cd - 之后 PWD 回到 OLDPWD';
};

subtest "0.16.7：OLDPWD 没设置时报错（与 cd-into 逐字一致）", {
    my $keep = %*ENV<OLDPWD>;
    %*ENV<OLDPWD> = q{};
    my $r = change-dir('-');
    ok $r.contains('cd: OLDPWD 没设置'), 'change-dir 报错';
    my %h = cd-into('-');
    is %h<err>, 'cd: OLDPWD 没设置', 'cd-into 报错（文案逐字相同）';
    %*ENV<OLDPWD> = $keep;
};

subtest "0.16.7：drive 层：cd - 与 %cd - 都能执行", {
    change-dir('/tmp');
    my $back = $*CWD.Str;
    change-dir('/usr');
    my $s1 = run-capture('cd -');
    ok $s1.text.contains('cd →'), 'cd - 执行了（不是等续行）';
    is $*CWD.Str, $back, '回到上一个目录';

    change-dir('/tmp');
    my $back2 = $*CWD.Str;
    change-dir('/usr');
    my $s2 = run-capture('%cd -');
    ok $s2.text.contains('cd →'), '%cd - 执行了';
    is $*CWD.Str, $back2, '%cd - 回到上一个目录';
};

# 复位，避免本进程遗留非预期 cwd
change-dir($start);
done-testing;
