use v6;
use Test;

# 脚本模式（C 方案 P0）：rakuish run <file> / rakuish <file>
#
# 全部用真实子进程验证 —— 脚本模式的合同就是「进程的 stdout / stderr /
# 退出码」。如果在进程内把 out-line 换成假函数，就永远看不出 REPL 装饰
# （In[n] / Out[n] / ↪ shell）有没有漏进管道，而那正是这个特性唯一
# 值得测的地方。

plan 24;

my $root = $?FILE.IO.dirname.IO.parent;
my @base = ($*EXECUTABLE.Str, '-I', $root.add('lib').Str,
            $root.add('bin/rakuish').Str);

sub run-file(Str $src, *@args) {
    my $f = $*TMPDIR.add("rk-{$*PID}-{(1000..9999).pick}.rakuish");
    $f.spurt($src);
    my $p = run(|@base, $f.Str, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    $f.unlink;
    %( code => $p.exitcode, out => $out, err => $err );
}

# ── 1. 最基本：程序输出原样落地，且**不带** Out[n] ──
{
    my %r = run-file("say 'hello';\n");
    is %r<out>, "hello\n", 'stdout 只有程序输出';
    is %r<code>, 0, '正常结束退出码 0';
}

# ── 2. 表达式值不自动打印（REPL 的 Out[n] 语义不属于脚本）──
{
    my %r = run-file("1 + 1;\n");
    is %r<out>, '', '裸表达式不打印';
}

# ── 3. 多行块：文件模式下也要靠 needs-more 续行 ──
{
    # 用单引号字符串：双引号里 \($n) 会被 Raku 当成插值，报「未声明」。
    my %r = run-file('sub f($n) {
    return $n * 2;
}
say f(21);
');
    is %r<out>, "42\n", '多行 sub 跨行续接';
}

# ── 4. 退出码透传 ──
{
    my %r = run-file("say 'x';\nexit 3;\n");
    is %r<code>, 3, 'exit 3 透传到进程退出码';
}

# ── 5. 出错即停 + 走 stderr（不污染 stdout）──
{
    # P5-1 后脚本模式是**整文件一次编译**：`foo bar baz` 是编译期错误，
    # 整个编译单元编译失败 ⇒ 一行都不执行（连前面的 say 1 也不会跑）。
    # 这和 `raku foo.raku` / bash 的表现一致，是刻意的语义。
    my %r = run-file("say 1;\nfoo bar baz;\nsay 2;\n");
    is %r<out>, "", '编译期错误：整份文件不执行（没有 1 也没有 2）';
    ok %r<code> != 0, '语法 / 名称错误以非 0 退出';
    ok %r<err>.chars > 0, '错误写 stderr';
}

# ── 5b. 运行期错误：前面已执行完的部分输出要留住 ──
{
    # 双引号拼，别用单引号：Raku 单引号里 \n 是字面反斜杠+n，会把三行压成一行
    my %r = run-file("say 1;\ndie \"boom\";\nsay 2;\n");
    is %r<out>, "1\n", '运行期错误保留前面的输出（没有 2）';
    ok %r<code> != 0, '运行期错误以非 0 退出';
    ok %r<err>.contains('boom'), '运行期错误信息进 stderr';
}

# ── 6. 脚本参数进 @*ARGS ──
{
    my %r = run-file('say @*ARGS.join(",");
', 'a', 'b');
    is %r<out>, "a,b\n", '脚本参数进 @*ARGS';
}

# ── 7. shell 行照旧可混排 ──
{
    my %r = run-file("!echo hi-shell\n");
    is %r<out>, "hi-shell\n", '!shell 行输出直通';
}

# ── 8. 文件不存在 ──
{
    my $p = run(|@base, ($*TMPDIR.add('definitely-not-here.rakuish')).Str, :out, :err);
    my $err = $p.err.slurp(:close);
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 2, '脚本不存在退出码 2';
    ok $err.contains('找不到脚本文件'), '给一句人话而不是栈';
}

# ── 10. 脚本模式的错误输出：**无装饰**（#8） ────────────────────────
#
# 契约（PLAN-C 第 45 行）：「脚本 | … | **无装饰，只有程序输出**；出错即停」。
# 以前脚本里的错误**整个复用 REPL 的渲染** ⇒ stderr 里带
#   · 「错误 · 运行时错误」头（REPL 的分级装饰）
#   · 「» 出错的那一行源码」—— 在脚本里那其实是**拼出来的编译单元**，
#     甚至会显示 `$*RAKUISH-CELL-HOOK(…)` 这种**内部包装**
#   · 「提示: 错误只影响这一个 cell；会话还在，输入 _ 可以看上一个结果。」
# —— 脚本里没有 cell，也没有 `_`。
{
    # ① 运行期错误（整文件一次编译 ⇒ 走 render-error 那条路）
    my %r = run-file("say 1;\ndie \"boom\";\nsay 2;\n");
    ok  %r<err>.contains('boom'),        '运行期错误：消息进 stderr';
    ok !%r<err>.contains('提示:'),       '运行期错误：没有 REPL 的「提示:」';
    ok !%r<err>.contains('错误 ·'),      '运行期错误：没有 REPL 的分级头';
    ok !%r<err>.contains('»'),           '运行期错误：没有 REPL 的「» 出错行」';
}
{
    # ② 格内错误（host cell 那条路）
    my %r = run-file("cd /tmp\nfoo bar\n");
    ok  %r<err>.contains('Undeclared routines'), '格内错误：消息进 stderr';
    ok !%r<err>.contains('提示:'),                  '格内错误：没有 REPL 的「提示:」';
    ok !%r<err>.contains('错误 ·'),                 '格内错误：没有 REPL 的分级头';
    ok !%r<err>.contains('RAKUISH-CELL-HOOK'),      '格内错误：不泄漏内部包装';
}

# ── 9. `run` 子命令与裸路径等价 ──
{
    my $f = $*TMPDIR.add("rk-run-{$*PID}.rakuish");
    $f.spurt("say 'ok';\n");
    my $p = run(|@base, 'run', $f.Str, :out, :err);
    my $out = $p.out.slurp(:close);
    $p.err.slurp(:close);
    $f.unlink;
    is $out, "ok\n", 'run 子命令可用';
}
