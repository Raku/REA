use Test;

# 启动器冒烟：bin/rakuish 这个给用户跑的入口得一直存在、可执行、
# 首行是 shebang、且语法检查通过（两实现分别跑各自的那份 raku）。
# 注意：真正的"读终端"那段靠 Prompt，只能在 pty 里人工/集成冒烟，
# 这里只锁住"启动器本身没坏"这条 cheapest 的回归线。

my $proj = $*PROGRAM.parent.parent;          # t/14-bin.t -> t -> 项目根
my $bin  = $proj.add('bin/rakuish');

plan 4;

ok  $bin.e,                    'bin/rakuish 存在';
ok  $bin.x,                    'bin/rakuish 有可执行位';

my $first = ($bin.lines.first // '');
ok  $first.starts-with('#!'),  '首行是 shebang';

# 用正在跑这份测试的 raku 自己去做 -c，保证 MoarVM / rakupp 各自校验自己那份
my $proc = run($*EXECUTABLE.Str, '-c', $bin.Str, :out, :err);
my $rc   = $proc.exitcode;
ok  $rc == 0,                  "raku -c 语法检查通过 (rc={$rc})";
