use lib "lib";
use Test;
use Rakuish::Loop;
use Rakuish::Eval;

class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}

sub run-magic-capture(Str $cmd --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    run-magic($cmd);
    $sink
}

my $dir = $*CWD.add('08-tmp');
$dir.mkdir;
my $script = $dir.add('demo.sh');
$script.spurt("#!/bin/sh\necho hello-from-script\n");

subtest "run-magic：跑通脚本并给汇总块", {
    my $s = run-magic-capture('run ' ~ $script.Str);
    ok $s.text.contains('exit 0'),     '汇总块有 exit 0';
    ok $s.text.contains('stdout 1'),   'stdout 1 行（脚本输出一行）';
};

subtest "run-magic：--numbers 给行号", {
    my $s = run-magic-capture('run --numbers ' ~ $script.Str);
    ok $s.text.contains('1 ' ~ chr(0x2502) ~ ' hello-from-script'),
       '第一行带行号';
    ok $s.text.contains('exit 0'), '仍有汇总块';
};

subtest "run-magic：脚本不存在给报错 + 127 汇总", {
    my $s = run-magic-capture('run nope-not-here.sh');
    ok $s.text.contains('找不到脚本'), '有报错';
    ok $s.text.contains('exit 127'),   '汇总 exit 127';
};

subtest "run-magic：无参数给用法", {
    my $s = run-magic-capture('run');
    ok $s.text.contains('用法'), '提示用法';
};

$script.unlink;
$dir.rmdir;

done-testing;
