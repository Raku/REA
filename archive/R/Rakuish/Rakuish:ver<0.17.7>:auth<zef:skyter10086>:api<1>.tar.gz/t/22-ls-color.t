use lib "lib";
use Test;
use Rakuish::Loop;

# 输出收集器：把 $*OUT 换成只实现 say 的对象，截住 drive 的全部输出
class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}

sub run-capture(*@script, Bool :$color = False --> Sink) {
    my $sink = Sink.new;
    temp $*OUT = $sink;
    drive(reader-from(@script), :$color);
    $sink
}

plan 29;

# ── 单元：list-dir-colored ──
ok list-dir-colored('', :color(True)).contains("\e["),      '彩色含 ANSI 转义';
ok list-dir-colored('', :color(True)).contains('lib/'),    '彩色列出 lib/（目录带 /）';
ok !(list-dir-colored('', :color(False)).contains("\e[")), '无颜色时不含 ANSI';
ok list-dir-colored('', :color(False)).contains('lib/'),   '无颜色也正常列出 lib/';
ok list-dir-colored('', :long(True), :color(False)).contains('d lib/'), 'll 长格式含 d 前缀';
ok list-dir-colored('/no/such/dir', :color(False)).contains('没有这个文件或目录'), '不存在的路径给中文报错';

# ── 集成：裸 ls / ll 走内建 ──
my $s = run-capture('ls', :color(True));
ok $s.text.contains('lib/'), 'drive: 裸 ls 列出目录';
ok $s.text.contains("\e["),  'drive: ls 带 ANSI 颜色';
my $s2 = run-capture('ll', :color(False));
ok $s2.text.contains('d lib/'), 'drive: 裸 ll 长格式';

# ── 单元：ls-colorize（给真实 shell 的 ls 补 --color=always）──
is ls-colorize('ls'),          'ls --color=always',       '裸 ls 补 --color=always';
is ls-colorize('ls -l'),       'ls --color=always -l',    '带参数时插在 ls 之后';
is ls-colorize('ls --color=auto'), 'ls --color=auto',     '已带 --color 不重复加';
is ls-colorize('echo hello'),  'echo hello',              '非 ls 原样返回';

# ── 0.16.5 回归：`ls <某个文件>` 不能列当前目录 ────────────────────
#
# 以前 `drive` 里取参数写的是 `my $rest = ($0 // q{}).Str.trim;`，
# 而 **`$0`（match 对象）是词法作用域的**：0.16.0（P5-1 重构）把 `ls` 的正则
# 从 `drive` 里抽进 `ls-cell` 之后，**调用方的 `$0` 纹丝不动**（实测都是 Nil）
# ⇒ 参数被静默吃掉 ⇒ `ls <文件>` / `ls <目录>` / `ls -la` 一律退化成
# 「列当前目录」（用户实测报告）。本组用例锁住修复。
my $tmp = $*TMPDIR;
my $tf  = $tmp.add('rk-ls-target.txt');
my $td  = $tmp.add('rk-ls-dir');
$tf.spurt("hello\n");
$td.mkdir;
$td.add('inner.txt').spurt("inner\n");

# 单元：ls-arg 把参数**返回出来**（不是靠 `$0` 往外传）
is ls-arg('ls'),         q{},         'ls-arg：裸 ls ⇒ 空参数';
is ls-arg('ls foo.txt'), 'foo.txt',   'ls-arg：返回参数';
is ls-arg('ll /tmp'),    '/tmp',      'ls-arg：ll 也返回参数';
is ls-arg('echo hi'),    Nil,         'ls-arg：不是 ls ⇒ Nil';
ok  ls-cell('ls foo'),                'ls-cell 仍是谓词（True）';
ok !ls-cell('echo hi'),               'ls-cell：不是 ls ⇒ False';

# 集成：`ls <文件>` 只打印那个文件，**不列当前目录**
my $sf = run-capture("ls {$tf.Str}", :color(False));
ok  $sf.text.contains('rk-ls-target.txt'), 'ls <文件>：打印该文件名';
ok !$sf.text.contains('lib/'),             'ls <文件>：不再列当前目录';

# 集成：`ls <目录>` 列**那个目录**的内容
my $sd = run-capture("ls {$td.Str}", :color(False));
ok  $sd.text.contains('inner.txt'), 'ls <目录>：列该目录的内容';
ok !$sd.text.contains('lib/'),       'ls <目录>：不是当前目录的内容';

# 不存在 ⇒ 给一句人话（不是「列当前目录」）
my $sn = run-capture('ls /no/such/path/xyz', :color(False));
ok $sn.text.contains('没有这个文件或目录'), 'ls <不存在>：给一句人话';

# `ll <文件>` ⇒ 长格式
my $sl = run-capture("ll {$tf.Str}", :color(False));
# ⚠ 长格式显示的是**用户写的那个路径**（与 bash 一致：`ls /tmp/x.txt` 显示
#   `/tmp/x.txt`，不是 `x.txt`）⇒ 断言按「类型前缀 + 完整路径」写。
ok $sl.text.contains("- {$tf.Str}"), 'll <文件>：长格式（类型前缀 + 路径）';

$td.add('inner.txt').unlink;
$td.rmdir;
$tf.unlink;

# ── 集成：!ls 走真实 shell（直通路径，输出到终端而非收集器，只验证不崩）──
lives-ok { run-capture('!ls', :color(False)) }, 'drive: !ls 走真实 shell 不崩';

# ⚠ 0.16.5：以前 `$rest` 恒为空 ⇒ **flag 检查形同虚设** ⇒ `ls -la` 被内建吃掉、
#   列的是当前目录。现在带 flag 一律交给真 ls（这条路径以前从没真正生效过）。
#   用一个**不存在的路径**让它几乎不输出，避免污染 TAP 流。
lives-ok { run-capture('ls -1 /nonexistent-xyz-12345', :color(False)) },
    'drive: ls 带 flag 交给真 ls（不再被内建吃掉）';

# ── 回归：`--numbers` 必须在 ls-colorize **之前**剥掉 ──
# 否则首词是 `--numbers`，`ls --color=always` 不会加上；
# 同时锁住「引擎把 dumb TERM 提升为可上色 TERM」这条路径。
my $old-term = %*ENV<TERM>;
%*ENV<TERM> = 'dumb';
my $s3 = run-capture('! --numbers ls', :color(False));
ok $s3.text.contains("\e["), 'drive: ! --numbers ls 仍然带 ANSI 颜色';
is %*ENV<TERM>, 'dumb', 'REPL 的 TERM 不被引擎回写';
%*ENV<TERM> = $old-term if $old-term.defined;
%*ENV<TERM>:delete unless $old-term.defined;

done-testing;
