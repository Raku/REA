# t/01-incomplete.t —— 「这段输入还没写完吗」的判定
#
# 为什么这个组件存在：Raku 的两个实现在这里都靠不住。
# rakupp 的编译错误既没有 <HERE> 位置标记，也不区分"未写完"与"写错了"
# （`1 +` 与 `1 +)` 的消息完全一样），所以只能自己扫。
#
# 这份测试必须在 **两个 Raku 实现上都跑**（MoarVM 与 rakupp）——
# 它是纯逻辑，两边结果必须一致；这也是 Platform 层隔离是否有效的第一块试金石。
#
# 写法约定：**含引号/反斜杠的样例一律用 chr() 拼，不用转义序列**。
# 这一轮踩了四个坑，全部是字面量层面的：
#   ① 双引号里的 `{` 会触发闭包插值 → `"sub f {\n...}"` 直接崩
#   ② `q{'it\'s'}` 里 `\'` 被当转义单引号 → 字符串不闭合（runaway quote）
#   ③ 单引号写 `'\'` 同理 → 改用 chr(92)
#   ④ `"a\\\"b"` 这类嵌套转义 Raku 自己都解析不稳
# 用 chr() 拼接之后这一类问题全部消失。

use Test;
use lib 'lib';
use Rakuish::Incomplete;

my $BS = chr(92);   # 反斜杠
my $DQ = chr(34);   # 双引号
my $SQ = chr(39);   # 单引号

# 样例里含转义引号的两个串
my $ESC-DQ = $DQ ~ 'a' ~ $BS ~ $DQ ~ 'b' ~ $DQ;   # "a\"b"
my $ESC-SQ = $SQ ~ 'it' ~ $BS ~ $SQ ~ 's' ~ $SQ;   # 'it\'s'

# 多行样例统一用单引号 + 拼接换行（双引号里的 `{` 会闭包插值，`$` 会插值）
my sub mk(*@parts --> Str) { @parts.join("\n") }

plan 3;

# %want: 输入 → 是否"还没写完"
my %want = (
    # ── 未写完：应继续读下一行 ──
    '1 +'                     => True,   # 停在运算符上（括号是平的）
    'my $x = ('               => True,
    'sub f {'                 => True,
    'if 1 {'                  => True,
    'for 1,2 -> $a {'         => True,
    $DQ ~ 'abc'               => True,   # 双引号未闭合
    $SQ ~ 'abc'               => True,   # 单引号未闭合（只有开引号）
    $SQ ~ 'abc' ~ $SQ         => False,  # 单引号闭合了
    '@a['                     => True,
    'my $s = qq:q(hello'      => True,   # smart quote 未闭合
    'say qq[a b'              => True,   # smart quote 用方括号
    'my $x = 1; my $y = 2; +' => True,   # 只有最后一行是运算符
    # 下面两条是**带尾换行**的同一件事：调用方 join-lines 总会在末尾补 "\n"，
    # 如果只看「最后一行」就会拿到空串，行尾运算符判定被跳过（实测踩过：
    # `my $x = 1 +` 永远不续行，而花括号块能续行纯属侥幸）。
    mk('my $x = 1 +', '')      => True,   # 末尾补空行仍判定为未写完
    'my $x = 1 +' ~ chr(10)    => True,   # 末尾补换行仍判定为未写完
    # heredoc **刻意不等**：实测两后端的 EVAL 通道都不支持 heredoc
    # （<<TAG 被当 quote-words 下标；qq:to 报 Two terms in a row），
    # 等用户敲完终止行也只会换一个错误。不等 = 立刻报错，更省事。
    mk('cat <<TAG', 'line1')  => False,  # heredoc 不触发续行

    # ── 写完了 ──
    '1+1'                     => False,
    'my $x = (1)'             => False,
    'sub f { }'               => False,
    'say ' ~ $DQ ~ 'hi' ~ $DQ => False,
    'my @a = ^5'              => False,
    '1 + 2'                   => False,   # 运算符后面有东西了

    # ── 确定写错了：不能傻等下一行 ──
    '1 +)'                    => False,   # 闭括号多出来
    ')'                       => False,
    '@a[1..2]'                => False,
);

subtest '逐条判定', {
    my @wrong;
    # 注意 `.map(*.key)`：Hash 直接迭代得到的是 **Pair**（不是键），
    # 忘了这一步就会把 `Pair(Str => Bool)` 传进 Str 形参。
    for %want.sort(*.key).map(*.key) -> $src {
        my $expect = %want{$src};
        my $got    = is-incomplete($src);
        @wrong.push: "'{$src}' → 期望 {$expect}，实得 {$got}" if $got != $expect;
    }
    is @wrong.elems, 0, '共 25 条判定全部正确'
        or diag(@wrong.map({ '  ' ~ $_ }).join("\n"));
}

subtest '多行整体', {
    is is-incomplete(mk('my $x = [1,', '2,', '')), True,  '跨行未闭合的方括号';
    is is-incomplete(mk('sub f {', '  say 1;', '}')), False, '三行的完整函数';
    is is-incomplete(mk('sub f {', '  say 1;')),     True,  '缺收尾花括号';
    is is-incomplete(mk('1 +', '2 +')),               True,  '最后一行又停在运算符上';
    is is-incomplete(mk('1 +', '2')),                 False, '最后一行是操作数';
}

subtest '注释与转义', {
    is is-incomplete('# 未闭合的括号在注释里 ('), False, '注释里的括号不算';
    is is-incomplete($DQ ~ 'a # b'),            True,  '引号里的 # 不算注释';
    is is-incomplete($ESC-DQ),                   False, '双引号里反斜杠转义引号';
    is is-incomplete($ESC-SQ),                   False, '单引号里转义单引号';
}