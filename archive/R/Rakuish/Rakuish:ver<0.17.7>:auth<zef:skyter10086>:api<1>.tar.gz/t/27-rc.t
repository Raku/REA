use lib "lib";
use Test;
use Rakuish::Loop;

my $tmp     = $*TMPDIR.add('rakuish-rc-' ~ $*PID ~ '.txt');
my $missing = $*TMPDIR.add('rakuish-rc-nope-' ~ $*PID ~ '.txt');
my $repl    = $*TMPDIR.add('rakuish-rc-repl-' ~ $*PID ~ '.txt');
%*ENV<RAKUISH_REPL> = $repl.Str;

# ⚠ 测试必须与环境无关：调用方（CI、`zef install` 的 wrapper、编辑器…）
#   可能已经设了 NO_COLOR / RAKUISH_COLOR。它们优先级**高于 rc**
#   （见 run-loop 的「默认值 < rc < 环境变量」），会让第 7 节
#   「rc color=true -> 有 ANSI」变成假失败。这里先清掉，END 里原样恢复。
my $saved-no-color      = %*ENV<NO_COLOR>;
my $saved-rakuish-color = %*ENV<RAKUISH_COLOR>;
%*ENV<NO_COLOR>:delete;
%*ENV<RAKUISH_COLOR>:delete;

END {
    try { $tmp.unlink  if $tmp.e }
    try { $repl.unlink if $repl.e }
    %*ENV<NO_COLOR>:delete;
    %*ENV<RAKUISH_COLOR>:delete;
    %*ENV<NO_COLOR>      = $saved-no-color      if $saved-no-color.defined;
    %*ENV<RAKUISH_COLOR> = $saved-rakuish-color if $saved-rakuish-color.defined;
}

# ── 1. coerce-bool：各种写法 ─────────────────────────────────────────
ok  coerce-bool(q{true}),  'true -> 开';
ok  coerce-bool(q{YES}),   'YES（大小写不敏感）-> 开';
ok  coerce-bool(q{on}),    'on  -> 开';
ok  coerce-bool(q{1}),     '1   -> 开';
ok !coerce-bool(q{false}), 'false -> 关';
ok !coerce-bool(q{off}),   'off   -> 关';
ok !coerce-bool(q{0}),     '0     -> 关';
ok  coerce-bool(q{随便写的}), '认不出来 -> 当开（宽松，不静默关功能）';

# ── 2. parse-rc：正常解析（settings 是扁平 Hash）────────────────────
my $h = parse-rc("# 这是注释\ncolor = false\nreplay: true\nhistory = '~/.my_hist'\n");
is $h<warns>.elems,    0, '正常 rc 无警告';
is $h<settings>.elems, 3, '三条设置都被识别';
is $h<settings><color>,   q{false},       'color = false';
is $h<settings><replay>,  q{true},        'replay: true（冒号分隔也认）';
is $h<settings><history>, q{~/.my_hist},  '引号被剥掉';

# 同名 key 后写覆盖先写
my $hdup = parse-rc("color = false\ncolor = true\n");
is $hdup<settings><color>, q{true}, '同名 key 后写覆盖先写';

# ── 3. parse-rc：注释与引号 ──────────────────────────────────────────
my $h2 = parse-rc("color = false  # 关掉颜色\nhistory = 'a#b'\n");
is $h2<settings><color>,   q{false}, '行尾注释被去掉';
is $h2<settings><history>, q{a#b},   '引号里的 # 不算注释';
my $h3 = parse-rc(q{color=false});
is $h3<settings><color>, q{false}, '无空格写法 color=false 也能解析';

# ── 4. parse-rc：坏输入只警告、不致命 ────────────────────────────────
my $h4 = parse-rc("color = false\nnonsense line\nbogus = 1\n1bad = x\n");
is $h4<warns>.elems, 3, '三处坏输入 -> 三条警告';
ok $h4<warns>[0].contains('第 2 行'), '警告 1 带行号（这行看不懂）';
ok $h4<warns>[1].contains('第 3 行'), '警告 2 带行号（未知配置项）';
ok $h4<warns>[2].contains('第 4 行'), '警告 3 带行号（配置名不合法）';
ok $h4<warns>[2].contains('配置名不合法'), '1bad 报的是「配置名不合法」而非「未知配置项」';
is $h4<settings>.elems, 1, '坏行被跳过，好行照常生效';
is $h4<settings><color>, q{false}, '好行的值仍然正确';

# ── 5. load-rc：文件生效 / 缺失无害 ──────────────────────────────────
$tmp.spurt("color = false\nhistory = '~/hist-from-rc'\n");
%*ENV<RAKUISH_RC> = $tmp.Str;
my @w = load-rc();
is @w.elems, 0, '好文件无警告';
ok !%RC<color>, 'rc 里 color = false 生效';
is %RC<history>, q{~/hist-from-rc}, 'rc 里 history 生效';

%*ENV<RAKUISH_RC> = $missing.Str;
@w = load-rc();
is @w.elems, 0, 'rc 文件不存在不算错误';
ok %RC<color>, '文件不存在时回落到默认值';

# ── 6. rc-history-path ───────────────────────────────────────────────
%*ENV<RAKUISH_RC>:delete;
%RC = rc-defaults();
is rc-history-path().Str, ($*HOME.Str ~ q{/.rakuish-history}), '默认 ~/.rakuish-history';
%RC<history> = q{/tmp/some-hist};
is rc-history-path().Str, q{/tmp/some-hist},          'rc 指定的绝对路径';
%RC<history> = q{~/.my_hist};
is rc-history-path().Str, ($*HOME.Str ~ q{/.my_hist}), '~ 展开到家目录';
%RC<history> = q{~};
is rc-history-path().Str, $*HOME.Str,                 '单独的 ~ 就是家目录';
%*ENV<RAKUISH_HISTORY> = q{/tmp/env-hist};
is rc-history-path().Str, q{/tmp/env-hist},           'RAKUISH_HISTORY 环境变量优先于 rc';
%*ENV<RAKUISH_HISTORY>:delete;

# ── 7. 优先级：rc < 环境变量 < 显式参数（端到端看欢迎语有没有 ANSI）──
class Sink {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method print(*@a)      { @.lines.push: @a.join; Nil }
    method flush()         { }
}
sub welcome-plain(--> Str) {
    my $s = Sink.new;
    { temp $*OUT = $s; run-loop(:read-line(reader-from(q{%quit}))); }
    $s.lines.join("\n")
}
sub welcome-force-color(--> Str) {
    my $s = Sink.new;
    { temp $*OUT = $s; run-loop(:color(True), :read-line(reader-from(q{%quit}))); }
    $s.lines.join("\n")
}

$tmp.spurt("color = false\n");
%*ENV<RAKUISH_RC> = $tmp.Str;
ok !welcome-plain().contains(chr(27)), 'rc color=false -> 欢迎语无 ANSI';

$tmp.spurt("color = true\n");
ok welcome-plain().contains(chr(27)), 'rc color=true -> 欢迎语有 ANSI';

%*ENV<NO_COLOR> = q{1};
ok !welcome-plain().contains(chr(27)),     'NO_COLOR 覆盖 rc（强制关色）';
ok   welcome-force-color().contains(chr(27)), '显式 :color(True) 又覆盖 NO_COLOR';
%*ENV<NO_COLOR>:delete;

%*ENV<RAKUISH_RC>:delete;
try { $tmp.unlink if $tmp.e }

done-testing;
