use lib 'lib';
use Test;
use Rakuish::Shell::Expand;
use Rakuish::Shell::Lexer;

# t/33-shell-expand.t —— 原生 shell 层的展开
#
# 这一层做三件事（bash 语义）：
#   · 变量展开（$VAR / ${VAR}）
#   · 引号感知（单引号内一切原样；双引号内可展开）
#   · glob（只有**裸位置**的 * / ? 才触发）
#
# 关键原则：**展开与剥引号必须一步完成**。
# 拆成「先剥壳、再展开」的话，单引号上下文就丢了 ——
# `echo 'a $B'` 会被错误展开（bash 里单引号内一切原样）。

my $SQ = chr(39);
my $DQ = chr(34);
my $BS = chr(92);

# 测试用环境变量（两个实现上 %*ENV 都可读可写）
%*ENV<RK_TEST> = 'xyz';

subtest "单引号内不展开（bash 语义）", {
    is expand-arg($SQ ~ 'a $RK_TEST' ~ $SQ), 'a $RK_TEST', '变量原样保留';
    is expand-arg($SQ ~ 'a $RK_TEST' ~ $SQ ~ $SQ), 'a $RK_TEST', '空串拼接也一样';
}

subtest "双引号内展开", {
    is expand-arg($DQ ~ 'a $RK_TEST' ~ $DQ), 'a xyz', '变量被展开';
    is expand-arg($DQ ~ 'a ${RK_TEST}' ~ $DQ), 'a xyz', '花括号形式';
}

subtest "裸位置的变量展开", {
    is expand-arg('a$RK_TEST'), 'axyz', '拼接';
    is expand-arg('${RK_TEST}b'), 'xyzb', '花括号形式';
    is expand-arg('$RK_TEST'), 'xyz', '单独一个';
}

subtest "未定义的变量展开成空串（与 bash 一致）", {
    is expand-arg('a$RK_NO_SUCH_VAR'), 'a', '未定义 → 空串';
    is expand-arg('${RK_NO_SUCH_VAR}!'), '!', '花括号形式同样';
}

subtest "转义的美元符不触发展开", {
    is expand-arg('a' ~ $BS ~ '$RK_TEST'), 'a$RK_TEST', '裸位置转义';
    is expand-arg($DQ ~ 'a' ~ $BS ~ '$RK_TEST' ~ $DQ), 'a$RK_TEST', '双引号内转义';
}

subtest "混合引号", {
    is expand-arg('x' ~ $SQ ~ 'y' ~ $SQ ~ '$RK_TEST' ~ $DQ ~ 'z' ~ $DQ), 'xyxyzz',
        'x + y + 变量 + z';
}

subtest "双引号内的反斜杠只对 4 个字符有转义意义", {
    # bash：双引号内 \" \\ \$ \` 有转义意义，其余保留反斜杠
    is expand-arg($DQ ~ $BS ~ 'n' ~ $DQ), $BS ~ 'n', '双引号内 \\n 保留反斜杠';
    is expand-arg($DQ ~ 'a' ~ $BS ~ $DQ ~ 'b' ~ $DQ), 'a' ~ $DQ ~ 'b', '双引号内 \\" 变成 "';
}

subtest "裸位置的引号被剥掉", {
    is expand-arg($SQ ~ 'abc' ~ $SQ), 'abc', '单引号剥掉';
    is expand-arg($DQ ~ 'abc' ~ $DQ), 'abc', '双引号剥掉';
    is expand-arg('abc'), 'abc', '裸词原样';
}

subtest "家目录展开：~ 与 ~/（只在裸位置）", {
    my $home = %*ENV<HOME>;
    ok $home.defined, 'HOME 有值';
    is expand-arg('~'), $home, '~ → HOME';
    is expand-arg('~/x'), $home ~ '/x', '~/x → HOME/x';
    is expand-arg($SQ ~ '~' ~ $SQ), '~', '引号里的 ~ 不展开';
}

subtest "家目录展开：~ / ~/ / ~user", {
    my $home = %*ENV<HOME>;
    is expand-arg('~'), $home, '~ → HOME';
    is expand-arg('~/'), $home ~ '/', '~/ → HOME/';

    # `~user` → 查 /etc/passwd（root 一定存在）
    my $root-home = home-of('root');
    ok $root-home.chars > 0, 'root 的家目录查得到';
    is expand-arg('~root'), $root-home, '~root → root 的家目录';
    is expand-arg('~root/'), $root-home ~ '/', '~root/ → 家目录 + /';
    is expand-arg('~root/x'), $root-home ~ '/x', '~root/x → 家目录下的路径';

    # 引号里的 ~ 不展开（bash 语义）
    is expand-arg($SQ ~ '~root' ~ $SQ), '~root', '单引号内不展开';
    is expand-arg($DQ ~ '~root' ~ $DQ), '~root', '双引号内不展开';

    # 用户不存在 → 原样保留（bash 会报错并原样保留；我们不报错）
    is home-of('rakuish-no-such-user-xyz'), q{}, '查不到的用户返回空';
    is expand-arg('~rakuish-no-such-user-xyz'), '~rakuish-no-such-user-xyz',
        '查不到的用户 → 原样保留';
}

subtest "glob 展开：无匹配时原样保留", {
    is @(glob-expand('/rakuish-no-such-dir-xyz/*')).elems, 1, '无匹配 → 1 个（原样）';
    is @(glob-expand('/rakuish-no-such-dir-xyz/*'))[0], '/rakuish-no-such-dir-xyz/*', '原样返回';
}

subtest "glob 展开：匹配到的按字典序", {
    my $dir = '/tmp/rakuish-glob-test';
    my $dp = $dir.IO;
    $dp.mkdir unless $dp.e;              # 目录不存在时 spurt 会失败
    for <a b c> -> $n {
        my $p = $dir ~ '/' ~ $n ~ '.txt';
        try { unlink $p };
        spurt($p, 'x');
    }
    my @hits = @(glob-expand($dir ~ '/*.txt'));
    is @hits.elems, 3, '匹配到 3 个';
    is @hits[0], $dir ~ '/a.txt', '第 1 个是 a.txt（排序）';
    is @hits[2], $dir ~ '/c.txt', '第 3 个是 c.txt（排序）';
    for <a b c> -> $n { try { unlink $dir ~ '/' ~ $n ~ '.txt' }; }
}

subtest "glob 不匹配隐藏文件（除非模式以 . 开头）", {
    my $dir = '/tmp/rakuish-glob-hidden';
    my $dp = $dir.IO;
    $dp.mkdir unless $dp.e;              # 目录不存在时 spurt 会失败
    try { unlink $dir ~ '/.hid' };
    spurt($dir ~ '/.hid', 'x');
    spurt($dir ~ '/vis', 'x');
    my @hits = @(glob-expand($dir ~ '/*'));
    is @hits.elems, 1, '只匹配到可见文件';
    is @hits[0], $dir ~ '/vis', '是 vis';
    my @dots = @(glob-expand($dir ~ '/.*'));
    ok @dots.elems >= 1, '模式以 . 开头时能匹配到隐藏文件';
    try { unlink $dir ~ '/.hid' };
    try { unlink $dir ~ '/vis' };
}

subtest "glob-supportable：目录部分含通配 → 不支持（字符类现已支持）", {
    ok glob-supportable('/tmp/*.txt'), '普通模式支持';
    ok !glob-supportable('/tmp/*/x.txt'), '目录部分含 * 不支持';
    # 字符类 `[abc]` 从 2026-11 起**原生支持**了（见 glob-match-at）
    ok glob-supportable('/tmp/[ab].txt'), '字符类在末段 → 支持';
    ok !glob-supportable('/tmp/[ab]/*.txt'), '目录部分含字符类仍不支持（目录部分不 glob）';
}

subtest "expand-args：引号保护的不做 glob", {
    # 注意：`<...>` 引号构造产出的是**单个 Str**，不是 List ——
    # 直接传给 `List` 形参会报 "expected List but got Str"。
    my @a = expand-args(['/tmp/rakuish-glob-test/*.txt']);
    is @a.elems, 1, '引号内 → 1 个参数';
    is @a[0], '/tmp/rakuish-glob-test/*.txt', '原样保留';
}

done-testing;
