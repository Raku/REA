use v6;
use Test;
use lib $?FILE.IO.dirname.IO.parent.add('lib').Str;
use Rakuish::Loop;

# P4-1 / P4-2 回归：cell 切分不再被块内花括号破坏，且绝不允许静默终止。
#
# 全部走**真实子进程**（看 stdout / stderr / 退出码）：这两条都是"进程
# 层面看不出来就等于没修"的 bug —— G1 是 rc=0 + 零输出，G2 也是 rc=0 +
# 零输出，进程内怎么断言都发现不了。

plan 23;

my $root = $?FILE.IO.dirname.IO.parent;
my @base = ($*EXECUTABLE.Str, '-I', $root.add('lib').Str,
            $root.add('bin/rakuish').Str);

sub run-file(Str $src, *@args) {
    my $f = $*TMPDIR.add("rk-p4-{$*PID}-{(10000..99999).pick}.rakuish");
    $f.spurt($src);
    my $p = run(|@base, $f.Str, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    $f.unlink;
    %( code => $p.exitcode, out => $out, err => $err );
}

# ── 1. 单元：块尾 `else` 续行判据 ──
# 注意：断言里的源码片段一律用**单引号**（双引号里 `{...}` 会被当插值）。
ok else-capable-block('if 1 { say 1; }'), 'if 块收尾 `}` 需要探下一行';
ok else-capable-block('unless 0 { say 1 }'), 'unless 同理';
nok else-capable-block('for 1..2 { say 1; }'), 'for 块没有 else，不拖一拍';
my $merged = q:to/EOS/;
if 1 { say 1 }
else { say 2 }
EOS
nok else-capable-block($merged), '已经合并过 else 就不再探';
ok is-else-continuation('  else {'), 'else 续行（带缩进 + 左花括号）';
ok is-else-continuation('elsif $x {'), 'elsif 续行';
nok is-else-continuation('say 1;'), '普通语句不是续行';

# ── 2. 跨行 if / else：两个 cell 必须合并成一个 ──
# 下面所有脚本源码一律用**单引号**包（Raku 单引号不插值，`$i` / `{$i}`
# 才能原样落到临时文件里；双引号里 `\$i` 不是合法转义）。
{
    my %r = run-file('my $dry = True;
if $dry {
  say "dry";
}
else {
  say "wet";
}
say "end";
');
    is %r<out>, "dry\nend\n", '跨行 if/else 合并成功（不再是 Undeclared routine: else）';
    is %r<code>, 0, 'rc 0';
}

# ── 3. elsif 链 + 不吞掉后面的第一条语句（探测读进来的行要能退回去）──
{
    my %r = run-file('my $x = 2;
if $x == 1 {
  say "one";
}
elsif $x == 2 {
  say "two";
}
else {
  say "other";
}
say "tail";
');
    is %r<out>, "two\ntail\n", 'elsif 链合并，且 tail 那一行没被探测吞掉';
}

# ── 4. G1 最小样例①：块内字符串插值 `{...}` ──
{
    my %r = run-file('for 1..3 -> $i {
  say "v={$i}";
}
');
    is %r<out>, "v=1\nv=2\nv=3\n", '块内插值不再破坏 cell 切分';
}

# ── 5. G1 最小样例②：块内 SIGIL 下标 `%h{...}` ──
{
    my %r = run-file('my %h;
for 1..2 -> $i {
  %h{$i} = $i * 10;
}
say %h{1} + %h{2};
');
    is %r<out>, "30\n", '块内哈希下标不破坏 cell 切分';
}

# ── 6. G1 最小样例③：for 块内插值 `{...}` 单行式 ──
{
    my %r = run-file('my @a = <x y>;
for @a -> $e { say "e={$e}" }
');
    is %r<out>, "e=x\ne=y\n", '单行 for + 插值正常';
}

# ── 7. 括号当引号分隔符时可嵌套（q{...} 里带 awk 的 {}）──
{
    my %r = run-file('my $s = q{awk \'{ n += 1 } END { print n }\'};
say $s;
');
    # 断言串里的 `{...}` 不能写进双引号（那是 Raku 插值），用 q{} 拼：
    my $want = q:to/EOW/;
awk '{ n += 1 } END { print n }'
EOW
    is %r<out>, $want, 'q{} 内层花括号不提前闭合引号';
}

# ── 8. P4-2：文件读完还没写完 → 报错 + 行号 + rc 2，绝不静默 ──
{
    my %r = run-file('say 1;
for 1..3 -> $i {
  say $i;
');
    is %r<code>, 2, '未闭合块以 2 退出（对齐 bash 的语法错误）';
    like %r<err>, /':2:'/, '报错带物理行号（块开始那一行）';
    like %r<err>, /'未闭合'/, '报错说清是没闭合';
    # P5-1 之后脚本模式每个文件只是一个编译单元：规划阶段发现未闭合就
    # 直接放弃，**不执行任何格**，所以 `say 1` 也不会落地。
    is %r<out>, "", '未闭合块时任何格都不执行';
}

# ── 9. P4-2：整个文件只有半截块（第一行就缺）──
{
    my %r = run-file('if 1 {
  say "never";
');
    is %r<code>, 2, '只有半截也是 rc 2';
    like %r<err>, /':1:'/, '行号指向第 1 行';
    is %r<out>, '', '没有假成功输出';
}

# ── 10. 文件最后一条就是 if 块（EOF 时探测读不到下一行，也要照常执行）──
{
    my %r = run-file('say "a";
if 1 {
  say "b";
}
');
    is %r<out>, "a\nb\n", 'EOF 前的 if 块不被吞掉';
    is %r<code>, 0, 'rc 0';
}
