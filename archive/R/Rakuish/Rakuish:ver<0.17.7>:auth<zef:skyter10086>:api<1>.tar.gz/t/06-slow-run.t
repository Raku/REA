use lib "lib";
use Test;
use Rakuish::Slow;

# ── 真跑 shell 的那部分 ──────────────────────────────────────────────
# 上面 t/05-slow.t 测的是判定与格式化；这里测"真的把命令交给 sh 跑"。
# 用真命令而不是 mock：mock 掉 run() 就等于把"shell 能不能跑通"这个
# 最该验证的东西给测没了。

my $NL = chr(10);

subtest "直通：命令真的执行，退出码正确", {
    my $r = run-shell(q{echo hello});
    is $r.code, 0, 'echo 成功 -> 0';
    ok $r.found, 'found=True';

    my $f = run-shell(q{false});
    is $f.code, 1, 'false -> 1';
    ok !$f.ok, 'ok=False';

    my $c = run-shell(q{exit 7});
    is $c.code, 7, 'exit 7 -> 7';
}

subtest "命令不存在：127 而不是 -1", {
    # `run()` 直接跑不存在的命令给 exitcode=-1 且 stderr 空（两个实现 signal
    # 值还不同）→ 不可用。包sh -c 才有 127 + 消息。
    my $r = run-shell(q{definitely-no-such-cmd-xyz-123});
    is $r.code, 127, 'exit 127';
    ok !$r.found, 'found=False';
}

subtest "捕获模式：能拿到 stdout", {
    my $r = run-shell(q{echo captured}, :capture(True));
    ok $r.passed, '走了捕获路径';
    ok $r.out.contains('captured'), '输出里有内容';
}

subtest "捕获模式：stderr 也收进来", {
    my $r = run-shell(q{echo o; echo e >&2}, :capture(True));
    ok $r.out.contains('o'), '有 stdout';
    ok $r.out.contains('e'), '有 stderr';
}

subtest "管道：整段交 sh，不在 Raku 侧搭", {
    # 这是 needs-sh 判定的主要理由：管道本就该由 shell 跑
    my $r = run-shell(q{printf 'x\ny\nz\n' | head -2}, :capture(True));
    is $r.code, 0, '管道退出码 0';
    ok $r.out.contains('x'), '第一行在';
    ok !$r.out.contains('z'), '第三行被 head 截掉了';
}

subtest "行号标注接在捕获后面", {
    my $r = run-shell(q{printf 'a\nb\nc\n'}, :capture(True));
    my $numbered = number-lines($r.out, :numbers(True));
    my @ls = $numbered.split($NL);
    is @ls.elems, 3, '三行';
    ok @ls[0].contains('1'), '第一行编号 1';
    ok @ls[2].contains('3'), '第三行编号 3';
}

subtest "引号正确性：路径含空格也能跑", {
    # 注意：`$*HOME.Str.IO` 里的 `.Str` 把 Path 变成了**字符串**，
    # 再 `~ 'rakish test dir'` 拼出来是 `/home/zbyrakish test dir`（少了 /）。
    # 要拼接就用 `.path`（那里还是 Path，拼接保留分隔符）。
    # Path 拼接用 `.add`（或 `.append`），**不要用 `~`**：
    # `~` 两侧只要有一边是 Str 就变成字符串拼接，于是
    # `/home/zby` ~ `rakish test dir` -> `/home/zbyrakish test dir`（少分隔符），
    # 而且字符串上也没有 `.mkdir` / `.spurt` 这些方法。
    # （`.Str` / `.path` 同样不行—— 它们把 Path 降级成 Str。）
    my $dir = $*HOME.IO.add('rakish test dir');
    $dir.mkdir;
    my $f = $dir.add('a b.txt');   # $dir 已是 Path，这个 ~ 没问题
    $f.spurt(q{hello});
    my $r = run-shell(q{cat } ~ sh-quote($f.Str), :capture(True));
    is $r.code, 0, '退出码 0';
    ok $r.out.contains('hello'), '内容读到了';
    $f.unlink;
    $dir.rmdir;
}

subtest "空命令不 spawn 进程", {
    my $r = run-shell(q{ });
    is $r.code, 0, '空命令 -> 0';
}

done-testing;