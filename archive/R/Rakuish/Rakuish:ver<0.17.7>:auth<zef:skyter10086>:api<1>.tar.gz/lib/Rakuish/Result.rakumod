unit module Rakuish::Result;

# Rakuish::Result —— C 方案 P1：「跑命令」返回**对象**，让 shell 输出能在
# Raku 表达式里链式加工。
#
#     run('ls').grep(*.ends-with('.rakumod')).head
#     run('git status --short').lines.elems
#     run(q{printf '%s' '{"a":{"b":[1,2,3]}}'}).json<a><b>[1]   # → 2
#
# 设计取舍：
#   · 执行走**引擎**（Rakuish::Shell::Engine::run-engine, :capture(True)）
#     —— 与 `` `cmd` `` 与裸 shell 行**同一套语义**（%shell 切后端时一起变）。
#   · 不吞 stderr：.out / .err 分开存，互不污染。
#   · .code 是命令退出码，.ok 是 code == 0 的简写，.Int 也是退出码。
#   · 单参数形式 = **shell 行**（管道 / 重定向 / 展开全可用）；
#     多参数形式 = **直接 exec**（不过 shell，免掉引号地狱）。
#   · 不做异步 / 流式：P1 的目标是「可组合的值」，流式属于 P3。

use Rakuish::Shell::Engine;   # 单参数（shell 行）走引擎，语义与裸 shell 行一致

# ── JSON（零依赖回落）────────────────────────────────────────────────
#
# 环境里不一定装了 JSON::Fast，而 `.json` 是 P1 的招牌能力之一。
# 所以这里带一个**够用**的递归下降解析器：对象 / 数组 / 字符串（含
# \uXXXX 与常用转义）/ 数字 / true / false / null。
# 装了 JSON::Fast 时优先用它（更快、边界更全）。
my class JParser {
    has Str $.s;
    has Int $!i = 0;
    has Int $!n;

    submethod BUILD(:$!s) { $!n = $!s.chars }

    method fail(Str $what) {
        die "Result.json: 非法 JSON（第 {$!i} 个字符处：$what）";
    }

    method peek() { $!i < $!n ?? $!s.substr($!i, 1) !! '' }

    method ws() {
        while $!i < $!n && $!s.substr($!i, 1) ~~ /\s/ { $!i++ }
    }

    method parse() {
        self.ws();
        self.fail('空文本') if $!i >= $!n;
        my $v = self.value();
        self.ws();
        self.fail('尾随内容') if $!i < $!n;
        $v
    }

    method value() {
        self.ws();
        my $c = self.peek();
        return Nil if $c eq '';
        given $c {
            when '{' { self.object() }
            when '[' { self.array() }
            when '"' { self.str() }
            when 't' { self.lit('true', True) }
            when 'f' { self.lit('false', False) }
            when 'n' { self.lit('null', Nil) }
            default  { self.number() }
        }
    }

    method lit(Str $word, $v) {
        self.fail("期望 $word") unless $!s.substr($!i, $word.chars) eq $word;
        $!i += $word.chars;
        $v
    }

    method object() {
        $!i++;                       # 吃掉 '{'
        my %h;
        self.ws();
        if self.peek() eq '}' { $!i++; return %h }
        loop {
            self.ws();
            self.fail('期望键名') unless self.peek() eq '"';
            my $k = self.str();
            self.ws();
            self.fail('期望 :') unless self.peek() eq ':';
            $!i++;
            %h{$k} = self.value();
            self.ws();
            my $c = self.peek();
            if $c eq ',' { $!i++; next }
            if $c eq '}' { $!i++; last }
            self.fail('期望 , 或 }');
        }
        %h
    }

    method array() {
        $!i++;                       # 吃掉 '['
        my @a;
        self.ws();
        if self.peek() eq ']' { $!i++; return @a }
        loop {
            @a.push: self.value();
            self.ws();
            my $c = self.peek();
            if $c eq ',' { $!i++; next }
            if $c eq ']' { $!i++; last }
            self.fail('期望 , 或 ]');
        }
        @a
    }

    method str() {
        $!i++;                       # 吃掉开引号
        my $out = '';
        loop {
            self.fail('字符串未结束') if $!i >= $!n;
            my $c = $!s.substr($!i, 1);
            $!i++;
            if $c eq '"' { return $out }
            if $c ne '\\' { $out ~= $c; next }
            self.fail('转义未结束') if $!i >= $!n;
            my $e = $!s.substr($!i, 1);
            $!i++;
            given $e {
                when '"'  { $out ~= '"'  }
                when '\\' { $out ~= '\\' }
                when '/'  { $out ~= '/'  }
                when 'b'  { $out ~= "\b" }
                when 'f'  { $out ~= "\f" }
                when 'n'  { $out ~= "\n" }
                when 'r'  { $out ~= "\r" }
                when 't'  { $out ~= "\t" }
                when 'u'  {
                    my $hex = $!s.substr($!i, 4);
                    self.fail('\\u 需要 4 位十六进制') unless $hex ~~ /^ <[0..9a..fA..F]> ** 4 $/;
                    $!i += 4;
                    $out ~= chr(:16($hex));
                }
                default { self.fail("未知转义 \\$e") }
            }
        }
    }

    method number() {
        my $rest = $!s.substr($!i);
        unless $rest ~~ /^ ('-'? \d+ ['.' \d+ ]? [<[eE]> <[+\-]>? \d+ ]?)/ {
            self.fail("无法识别的内容 '{$rest.substr(0, 1)}'");
        }
        my $tok = ~$0;
        $!i += $tok.chars;
        $tok ~~ /<[.eE]>/ ?? $tok.Numeric !! $tok.Int
    }
}

# ── Result ──────────────────────────────────────────────────────────

class Result is export {
    has Str $.cmd  = '';      # 原始命令（shell 行或 argv 拼接）
    has Str $.out  = '';      # stdout
    has Str $.err  = '';      # stderr
    has Int $.code = 0;       # 退出码

    method ok(--> Bool)  { $!code == 0 }
    method to-json(--> Str) is export {
        use JSON::Fast;
        to-json({
            cmd  => $!cmd,
            out  => $!out,
            err  => $!err,
            code => $!code,
            ok   => self.ok,
        })
    }
    method Bool(--> Bool) { $!code == 0 }
    method Int(--> Int)  { $!code }

    # bash `$(cmd)` 同款：剥掉尾部换行，内部换行保留
    method Str(--> Str)  { $!out.subst(/\n+$/, '', :g) }

    method stdout(--> Str) { $!out }
    method stderr(--> Str) { $!err }

    method lines(--> List) { $!out.lines.List }
    method words(--> List) { $!out.words.List }

    method elems(--> Int)  { self.lines.elems }
    method head(Int $n? --> Any) {
        my @l = self.lines;
        return @l.elems ?? @l[0] !! Nil unless $n.defined;
        @l.head($n)
    }
    method tail(Int $n? --> Any) {
        my @l = self.lines;
        return @l.elems ?? @l[*-1] !! Nil unless $n.defined;
        @l.tail($n)
    }
    method first($m --> Any) { self.lines.first($m) }
    method grep($m --> List) { self.lines.grep($m).List }
    method map(&f --> List)  { self.lines.map(&f).List }
    method sort(&by? --> List) {
        by.defined ?? self.lines.sort(&by).List !! self.lines.sort.List
    }
    method join(Str $sep = '' --> Str) { self.lines.join($sep) }

    # ls / find / fd 这类**一行一个路径**的输出 → IO::Path 列表（P3）。
    # 空行丢掉（不少工具会留尾空行）。相对路径保持相对 —— 后续
    # `.slurp` / `.e` 按当前 CWD 解析，与在 shell 里敲的一致。
    method paths(--> List) {
        my @p;
        for self.lines -> $l {
            my $t = $l.trim;
            next if $t eq q{};
            @p.push: $t.IO;
        }
        @p.List
    }

    # 文本太长时的预览（REPL Out[n] 用）：首行 + 行数
    method summary(--> Str) {
        my @l = self.lines;
        return "code={$!code} · 无输出" if @l.elems == 0;
        "code={$!code} · {@l.elems} 行 · " ~ @l[0];
    }

    method gist(--> Str) {
        my $body = $!out.subst(/\n+$/, '', :g);
        my @parts;
        @parts.push($body) if $body ne '';
        @parts.push("stderr: " ~ $!err.subst(/\n+$/, '', :g)) if $!err.trim ne '';
        @parts.push("[退出码 {$!code}]") if $!code != 0;
        @parts.elems == 0 ?? "(无输出 · 退出码 0)" !! @parts.join("\n");
    }

    # REPL 用 .raku 渲染值（见 Eval::format-value）—— 给个紧凑的一行摘要，
    # 避免把整个 out 灌进 Out[n]。想看全文用 .out / .gist。
    method raku(--> Str) {
        'Result(' ~ self.summary ~ ')'
    }

    method json(--> Any) {
        my $impl = try {
            require JSON::Fast;
            &JSON::Fast::from-json;
        };
        return $impl($!out) if $impl.defined;
        JParser.new(:s($!out)).parse;
    }
}

# ── DSL 入口 ────────────────────────────────────────────────────────

# 模块内部保留一份**内建 run**（下面 our sub run 会遮蔽它）
my &CORE-RUN = &CORE::run;

# `:in` = 喂给命令标准输入的正文（P3 的 DSL 糖）：
#     run 'grep -c x' :in("x\ny\n")        # shell 行形式
#     run 'grep', '-c', 'x', :in("x\ny")    # argv 形式
# 只接字符串：给 IO 句柄没有意义 —— 想那样用就 `my &cr = &CORE::run` 拿回内建。
our sub run(*@args, Bool :$check = False, :$in, *%opts --> Result) is export {
    die 'run: 至少需要一个命令（例：run("ls -l") / run("ls", "-l")）' unless @args.elems;

    my $stdin = $in.defined ?? $in.Str !! Str;

    my ($cmd, $out, $err, $code);

    if @args.elems == 1 {
        # shell 行：管道 / 重定向 / 变量展开全部交给引擎
        $cmd = ~@args[0];
        my $r = $stdin.defined
            ?? Rakuish::Shell::Engine::run-engine($cmd, :capture(True), :stdin($stdin))
            !! Rakuish::Shell::Engine::run-engine($cmd, :capture(True));
        $code = $r.code;
        $out  = ($r.stdout // '').Str;
        $err  = ($r.stderr // '').Str;
        $err = "找不到 shell 引擎（{Rakuish::Shell::Engine::engine-path}）" if $err eq '' && $code == 127;
    }
    else {
        # argv：直接 exec，不过 shell —— 参数里有空格 / 引号也不用转义
        my $tmp;
        my $fh;
        if $stdin.defined {
            # 原生 run 的 `:in` 要句柄（Bool 表示「继承终端」，给不了正文），
            # 落到临时文件再 open 是最省事、也不会和句柄生命周期打架的做法。
            $tmp = $*TMPDIR.add("rakuish-run-in-{$*PID}-{(100000..999999).pick}.txt");
            $tmp.spurt: $stdin;
            $fh = $tmp.open(:r);
        }
        my $p = $fh.defined ?? CORE-RUN(|@args, :out, :err, :in($fh), |%opts)
                            !! CORE-RUN(|@args, :out, :err, |%opts);
        $err  = $p.err.slurp(:close);
        $out  = $p.out.slurp(:close);
        $code = $p.exitcode;
        $cmd  = @args.map(*.Str).join(' ');
        try { $fh.close } if $fh.defined;
        try { $tmp.unlink } if $tmp.defined;
    }

    my $res = Result.new(:$cmd, :$out, :$err, :$code);
    die "命令失败（退出码 {$res.code}）：{$res.cmd}\n{$res.err}" if $check && !$res.ok;
    $res
}

our sub run-pipe(*@cmds, Bool :$check = False, :$in --> Result) is export {
    die 'run-pipe: 至少需要一个命令' unless @cmds.elems;
    run(@cmds.map(*.Str).join(' | '), :$check, |($in.defined ?? (:$in) !! ()))
}
