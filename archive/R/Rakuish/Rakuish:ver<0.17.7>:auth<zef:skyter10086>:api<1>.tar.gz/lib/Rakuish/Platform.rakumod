# Rakuish::Platform —— 实现差异隔离层
#
# 存在的理由：Raku 有两个实现（MoarVM 与 rakupp/C++），它们在**语义**上有 11 处差异
# （见 docs/DESIGN.md 第 0.1 节）。本模块把其中真正会咬人的几处收在一处，
# 业务代码只依赖这里，换实现时只改这一个文件。
#
# ── 实测得到的四条规则（本轮逐条对拍过，不是推测）────────────────────
#
# 1. **错误处理一律用 `try` + `$!`，不要用 `CATCH`。**
#    rakupp 上 `CATCH { default { … } }` 不触发，且块内 `$_` 不是异常对象；
#    而 `try` + `$!` 两个实现**行为一致**（异常对象在 `$!`，`$!.gist` 有消息）。
#    `try` 失败时的返回值是**未定义值**（不是 Failure、也不是异常对象），
#    所以绝不能用返回值判断成败，必须查 `$!`。
#
# 2. **不要用内省（`?can` / `.^methods`）判断能力。**
#    rakupp 的内省**不可靠**：实测 `$*OUT.?can('print')` 返回真，
#    而 `$*OUT.^methods` 报"0 个方法"——两个都不可信，于是照着内省写分支会得到
#    完全错误的结论（我第一版探测就是这么得出"rakupp 没有输出方法"的误判的，
#    实际 `$*OUT.say/print/put/write`、`$*IN.get` **全部可用**）。
#    **正确做法：探测靠"做"，不靠"问"。**
#
# 3. **`$*OUT.write` 两边签名不兼容** —— 这是唯一一个"方法名相同但参数类型不同"的坑：
#        MoarVM：只收 **Blob**（传 Str 报 "Type check failed … expected Blob"）
#        rakupp：收 Str（它没有 Blob，`.encode` 给的是 `utf8`）
#    所以对外一律用 **`$*OUT.print`**（两边都是"原样输出、不加换行"），
#    把 `write` 挡在本模块里。
#
# 4. **不要把句柄泄漏出去。** 对外只给"动作"（`out-raw` / `out-line` / `in-line`），
#    不给 `$*OUT` / `$*IN`。理由是 rakupp 上碰 `$*IN` 的某些方法会让脚本
#    **静默中断**（退出码 0、输出截断、无任何报错）——这种形状的差异没法用类型系统挡住。

unit module Rakuish::Platform;

# ── 结果类型 ──────────────────────────────────────────────────────────

# `catch` 的返回值。刻意**不**用 Any/Nil 去表达成败 —— 那样调用方还得区分
# "返回了 Nil" 和 "失败了"，而这两件事在 REPL 里必须分开处理（一个要显示 Nil，
# 一个要显示错误）。
class Outcome {
    has Bool $.ok;
    has Any  $.value = Nil;   # 成功时的值
    has Any  $.error = Nil;   # 失败时的异常对象

    # 异常消息的第一行。用 `$.error` 而不是 `$!`——方法体里的 `$!`
    # 指的是"当前作用域"的错误，不是构造时存进来的那个。
    method message {
        my $e = $.error;
        return '（无异常对象）' unless defined $e;
        my $g = try { $e.gist };
        return '（取 gist 失败）' if $!;
        my @lines = $g.lines;
        return @lines.elems ?? @lines[0] !! '（空消息）';
    }
}

# 外部命令的结果。`found` 单列出来：两个实现都用**负 exitcode** 表示"命令没找到"
# （实测 -1），混在 exitcode 里容易被当成普通失败。
class ProcResult {
    has Str  $.out      = '';
    has Str  $.err      = '';
    has Int  $.exitcode = 0;
    has Bool $.found    = True;
}

# ── 错误处理 ──────────────────────────────────────────────────────────

# 跑 code，把成败收进 Outcome。
# 注意 `try` **失败时返回未定义值**，所以判断必须看 `$!`（规则 1）。
our sub catch(&code --> Outcome) is export {
    my $v = try { &code() };
    if $! {
        return Outcome.new(:ok(False), :value(Nil), :error($!));
    }
    Outcome.new(:ok(True), :value($v), :error(Nil))
}

# ── 外部命令 ──────────────────────────────────────────────────────────

# 跑一个外部命令并收 stdout / stderr / 退出码。
# `run(@argv, :out, :err)` 两个实现都支持（实测 rakupp 的 `:err` 也正常 ——
# 早先以为不支持，其实是我把 `:err> <fh>` 的语法写错了）。
our sub run-capture(*@argv --> ProcResult) is export {
    if !@argv {
        return ProcResult.new(:found(False), :exitcode(-1));
    }

    my $p = try { run(@argv, :out, :err) };
    if $! {
        # spawn 本身失败（例如可执行文件不存在）——MoarVM 返回负 exitcode 的 Proc，
        # rakupp 在一部分场景下会直接抛。两种都归一成"没找到"。
        return ProcResult.new(:found(False), :exitcode(-1));
    }
    my Int $rc = $p.exitcode // 0;
    ProcResult.new(
        :out(slurp-of($p.out)),
        :err(slurp-of($p.err)),
        :exitcode($rc),
        :found($rc >= 0),
    )
}

# Pipe 的内容取出来；没有这一路就空串。
# `.slurp` 在两个实现上都可用，但 pipe 可能没开（纯继承的情形）。
sub slurp-of($pipe --> Str) {
    return '' unless $pipe;
    my $s = try { $pipe.slurp(:bin) };
    return '' if $!;
    return '' unless defined $s;
    $s.decode('utf-8')
}

# ── 输出动作（不给句柄，只给动作；规则 4）───────────────────────────

# 原样输出，**不加换行**（提示符、ANSI 颜色、行内更新都靠它）。
our sub out-raw(Str $s --> Nil) is export {
    # 统一用 print：两个实现都支持，且语义一致。
    # 不用 write —— 签名不兼容（规则 3）。
    $*OUT.print($s);
    Nil
}

# 输出一行。
our sub out-line(Str $s --> Nil) is export {
    $*OUT.say($s);
    Nil
}

# 往 stderr 输出一行（诊断信息）。
our sub err-line(Str $s --> Nil) is export {
    $*ERR.say($s);
    Nil
}

# 读一行；到 EOF 返回 Nil。
# **这条目前没有测试覆盖** —— 要测它就得控制子进程 stdin，
# 等 REPL 主循环落地后它会被真实走到（而不是造一个只为测试的假路径）。
our sub in-line(--> Str) is export {
    my $l = try { $*IN.get };
    return Nil if $!;
    $l
}

# stdin / stdout 是否是 tty。两个实现在管道下都返回 False；真实 tty 未验证。
our sub stdin-is-tty(--> Bool) is export {
    my $t = try { $*IN.t };
    return False if $!;
    $t ?? True !! False
}

our sub stdout-is-tty(--> Bool) is export {
    my $t = try { $*OUT.t };
    return False if $!;
    $t ?? True !! False
}

# ── 文本文件 ──────────────────────────────────────────────────────────

our sub write-text-file(Str $path, Str $content --> Nil) is export {
    spurt($path, $content);
    Nil
}

our sub read-text-file(Str $path --> Str) is export {
    slurp($path)
}

# ── 能力自述（供诊断类magic 命令用）─────────────────────────────────
# 全部**靠做**来探测，不靠内省（规则 2）。只列"探测不会产生副作用"的项；
# 输入能力探不了（探测会吃掉一行），所以不在表里。

our $SPURT-PROBE-PATH = 'rakuish-platform-probe.tmp';

our sub spurt-probe-path(--> Str) is export { $SPURT-PROBE-PATH }

our sub capabilities(--> Hash) is export {
    my %c;
    %c<out-raw>    = probe-works(sub { $*OUT.print(''); True });
    %c<out-line>   = probe-works(sub { $*OUT.say(''); True });
    %c<err-line>   = probe-works(sub { $*ERR.say(''); True });
    %c<run-out>    = probe-works(sub { run('echo', '', :out, :err); True });
    %c<spurt>      = probe-works(sub { spurt($SPURT-PROBE-PATH, ''); True });
    %c<stdin-tty>  = stdin-is-tty();
    %c<stdout-tty> = stdout-is-tty();
    %c<impl>       = implementation-name();
    %c
}

our sub probe-works(&code --> Bool) is export {
    my $v = try { &code() };
    return False if $!;
    $v ?? True !! False
}

# 实现名字（用于诊断输出）。没有可靠的版本查询接口，所以做**行为指纹**：
# rakupp 的 `.encode` 返回 `utf8`（它没有 Blob），MoarVM 返回 `Blob`。
our $UNKNOWN-IMPL = 'unknown-implementation';

our sub implementation-name(--> Str) is export {
    my $enc = try { "x".encode.^name };
    return $UNKNOWN-IMPL if $!;
    return 'rakupp (C++)' if $enc eq 'utf8';
    return 'MoarVM'       if $enc eq 'Blob';
    return 'unknown-implementation (encode => ' ~ $enc ~ ')';
}