unit module Rakuish::Shell::Lexer;

# Rakuish::Shell::Lexer —— 外壳层词法（shell-design §4.1）
#
# 移植自 v/shell_lexer.v（V 版的 167 行）。**不是逐行翻译**，有两处刻意改动，
# 理由写在下面各自的注释里。
#
# ── 为什么自己写词法而不用正则 ──────────────────────────────────────
# shell 词法的难点在**引号边界**与**转义**：同一行里要同时表达
#   · 单引号内一切原样（连反斜杠都不转义）
#   · 双引号内 `\"` 不结束引号、`\$` 不展开
#   · 裸模式下反斜杠转义空格（`a\ b` 是一个词）
# 三套规则。正则能写，但写出来是一坨难以验证的分支；更要命的是本项目
# **必须同时跑两个 Raku 实现**（MoarVM / rakupp），而两者的正则语义**并不一致**
# （见 HANDOFF §4.1：多行正则字面量、`<[...]>` 字符类、插值变量紧跟 `<`
# 三处差异都会**静默给出不同结果**）。
# → 所以用**逐字符状态机**：状态只有 3 个（bare / single / double），
#   没有正则 ⇒ 两个实现上行为**逐字节一致**。
#
# ── 两条实现上的硬规矩（踩过才知道）────────────────────────────────
# ① 逐字符必须用 `.comb`，**不能用 `.chars`** —— 本版 `.chars` 返回的是
#    「字符数」这个 Str，不是字符列表（实测 `.chars.elems = 1`）。
#    用错的后果极隐蔽：循环只跑一次，于是「分词只返回 1 个元素、值等于行长」。
#    凡是逐字符处都直接写 `.comb`。
# ② 源码里**不写引号字面量**，一律 `chr(39)` / `chr(34)` —— 否则引号会被
#    自己所在的定界符咬到（`q{...}` 里再出现 `{` 还会改变定界符配对）。

our $BSL    = chr(92);        # 反斜杠
our $SQUOTE = chr(39);        # 单引号
our $DQUOTE = chr(34);        # 双引号
our $TICK   = chr(96);        # 反引号
our $DOLLAR = chr(36);        # $
our $TAB    = chr(9);         # 制表符

# ── 命令替换的边界扫描 ────────────────────────────────────────────
#
# `$(cmd)` 与 `` `cmd` `` 必须**整块**处理：里面的空格不能切词
# （bash 语义：命令替换是**一个词**，空格只在替换**之后**才参与分词）。
# 所以词法阶段就要把整块吞掉，不能逐字符走。
#
# 括号配对要**认引号**：`$(echo ")")` 里的 `)` 在双引号内，
# 不该被当成配对的右括号。嵌套的 `$(` 递归处理。
#
# 返回值：匹配的右括号下标；**找不到返回 -1**（不是 Nil ——
# `index` 找不到时返回 Nil，直接比 >= 0 会报 "Use of Nil in numeric context"，
# 见 Expand 的同类注释）。
our sub find-cmdsub-end(Str $s, Int $open --> Int) is export {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $depth = 1;
    my $i = $open + 1;
    my $mode = 'bare';

    while $i < $n {
        my $c = @ch[$i];

        # ── 单引号段：一切原样 ──
        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }

        # ── 双引号段 ──
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            if $c eq $DQUOTE { $mode = 'bare'; $i++; next }
            if $c eq $DOLLAR and $i + 1 < $n and @ch[$i + 1] eq '(' {
                # ⚠ `$((...))` 是**算术**展开，不是命令替换 → 整块跳过
                if $i + 2 < $n and @ch[$i + 2] eq '(' {
                    my $ae = find-arith-end($s, $i);
                    if $ae >= 0 { $i = $ae + 1; next }
                }
                my $e = find-cmdsub-end($s, $i + 1);
                return -1 if $e < 0;
                $i = $e + 1;
                next;
            }
            if $c eq $TICK {
                my $e = find-backtick-end($s, $i);
                return -1 if $e < 0;
                $i = $e + 1;
                next;
            }
            $i++;
            next;
        }

        # ── 裸段 ──
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }
        if $c eq $DOLLAR and $i + 1 < $n and @ch[$i + 1] eq '(' {
            # ⚠ `$((...))` 是**算术**展开，不是命令替换 → 整块跳过
            if $i + 2 < $n and @ch[$i + 2] eq '(' {
                my $ae = find-arith-end($s, $i);
                if $ae >= 0 { $i = $ae + 1; next }
            }
            # 嵌套的 `$(`：递归找它的配对右括号，整块跳过
            my $e = find-cmdsub-end($s, $i + 1);
            return -1 if $e < 0;
            $i = $e + 1;
            next;
        }
        if $c eq $TICK {
            my $e = find-backtick-end($s, $i);
            return -1 if $e < 0;
            $i = $e + 1;
            next;
        }
        if $c eq '(' { $depth++; $i++; next }
        if $c eq ')' {
            $depth--;
            return $i if $depth == 0;
            $i++;
            next;
        }
        $i++;
    }
    -1
}

# 反引号命令替换的边界（`` `cmd` ``）。
# bash 的老式反引号里 `\` 可以转义 `$` / `` ` `` / `\` ——
# 词法阶段只管找**配对的反引号**（被反斜杠转义的不算）。
our sub find-backtick-end(Str $s, Int $open --> Int) is export {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = $open + 1;
    while $i < $n {
        my $c = @ch[$i];
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $TICK { return $i }
        $i++;
    }
    -1
}

# ── 算术展开 `$((...))` 的边界 ──────────────────────────────────
#
# bash 的 `$((expr))` 里 expr **可以有括号**（`$(((1+2)*3))` → 9），
# 所以要**数括号**；引号内的括号不算。
#
# ⚠ `$((` 与 `$(` 的区分：**紧挨着的第二个 `(`** 才算算术展开。
#   `$( (echo a) )`（`(` 前面有空格）是**命令替换**（bash 语义）。
#
# 返回：配对的**第二个**右括号的下标；找不到返回 -1。
our sub find-arith-end(Str $s, Int $dollar --> Int) is export {
    my @ch = $s.comb;
    my $n = @ch.elems;
    # $dollar+1 是第一个 '('，$dollar+2 是第二个 '('
    my $i = $dollar + 3;
    my $depth = 1;
    my $mode = 'bare';
    while $i < $n {
        my $c = @ch[$i];

        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            if $c eq $DQUOTE { $mode = 'bare'; $i++; next }
            $i++;
            next;
        }

        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }
        if $c eq '(' { $depth++; $i++; next }
        if $c eq ')' {
            $depth--;
            if $depth == 0 {
                # 必须**紧跟**第二个 ')'
                return -1 if $i + 1 >= $n or @ch[$i + 1] ne ')';
                return $i + 1;
            }
            $i++;
            next;
        }
        $i++;
    }
    -1
}

# 算术表达式里有命令替换（`$(...)` 或 `` `...` ``）吗？
#
# 我们**不实现**算术里的命令替换 —— 但 bash 支持
# （`$(( $(echo 3) + 1 ))` → 4，实测）。
# → 判出来之后整行**明确报错**（语义不将就）✓
our sub arith-has-cmdsub(Str $s --> Bool) is export {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = 0;
    my $mode = 'bare';
    while $i < $n {
        my $c = @ch[$i];
        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            if $c eq $DQUOTE { $mode = 'bare'; $i++; next }
            $i++;
            next;
        }
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }
        if $c eq $DOLLAR and $i + 1 < $n and @ch[$i + 1] eq '(' { return True }
        if $c eq $TICK { return True }
        $i++;
    }
    False
}

# ── 参数展开 `${...}` 的算子表 ──────────────────────────────────
#
# bash 的参数展开有一整套算子。`${` 与 `}` 之间的内容分成
# 「名字」+「算子」+「操作数」三段：
#
#   ${VAR}            取值
#   ${#VAR}           长度
#   ${VAR:-w}         未设置**或**为空 → 用 w
#   ${VAR-w}          未设置 → 用 w
#   ${VAR:=w}         未设置或为空 → **赋值** w
#   ${VAR=w}          未设置 → **赋值** w
#   ${VAR:?w}         未设置或为空 → 报错（bash 会中止 shell）
#   ${VAR?w}          未设置 → 报错
#   ${VAR:+w}         设置了**且**非空 → 用 w
#   ${VAR+w}          设置了 → 用 w
#   ${VAR#p}          删掉最短的匹配前缀
#   ${VAR##p}         删掉最长的匹配前缀
#   ${VAR%p}          删掉最短的匹配后缀
#   ${VAR%%p}         删掉最长的匹配后缀
#   ${VAR/p/r}        替换第一处
#   ${VAR//p/r}       替换所有处
#   ${VAR/#p/r}       替换前缀
#   ${VAR/%p/r}       替换后缀
#   ${VAR^} ${VAR^^}  转大写（首字符 / 全部）
#   ${VAR,} ${VAR,,}  转小写（首字符 / 全部）
#   ${VAR:o} ${VAR:o:l}  截取子串
#
# ⚠ **两字符的算子必须先匹配**（`##` 先于 `#`，`:-` 先于 `-`，
#   `//` 先于 `/`）—— 顺序反了 `${V##p}` 会被当成 `${V#}` + `#p`。
class ParamSpec is export {
    has Str  $.name    = q{};   # 变量名
    has Str  $.op      = q{};   # 算子（q{} = 纯 ${VAR}）
    has Str  $.operand = q{};   # 操作数原文
    has Bool $.ok      = True;  # 认得出来吗？
}

# 解析 `${...}` 的内容（不含 `${` 与 `}`）。
#
# `ok = False` 表示「不认识的写法」（例如 `${V@Q}`）——
# 调用方据此把整行**明确报错**（退出码 2 + 委托提示）。
our sub parse-param-spec(Str $content --> ParamSpec) is export {
    my $c = $content;

    # `${#VAR}` —— 长度
    if $c.starts-with('#') {
        my $rest = $c.substr(1);
        my $name = leading-name($rest);
        # `${#}` 是「位置参数个数」，我们没有位置参数 → 不认
        return ParamSpec.new(:ok(False)) if $name.chars == 0;
        return ParamSpec.new(:name($name), :op('len'));
    }

    my $name = leading-name($c);
    return ParamSpec.new(:ok(False)) if $name.chars == 0;
    my $rest = $c.substr($name.chars);

    my $op = q{};
    my $operand = q{};
    if    $rest.starts-with(':-') { $op = ':-'; $operand = $rest.substr(2) }
    elsif $rest.starts-with(':=') { $op = ':='; $operand = $rest.substr(2) }
    elsif $rest.starts-with(':?') { $op = ':?'; $operand = $rest.substr(2) }
    elsif $rest.starts-with(':+') { $op = ':+'; $operand = $rest.substr(2) }
    elsif $rest.starts-with('-')  { $op = '-';  $operand = $rest.substr(1) }
    elsif $rest.starts-with('=')  { $op = '=';  $operand = $rest.substr(1) }
    elsif $rest.starts-with('?')  { $op = '?';  $operand = $rest.substr(1) }
    elsif $rest.starts-with('+')  { $op = '+';  $operand = $rest.substr(1) }
    elsif $rest.starts-with('##') { $op = '##'; $operand = $rest.substr(2) }
    elsif $rest.starts-with('#')  { $op = '#';  $operand = $rest.substr(1) }
    elsif $rest.starts-with('%%') { $op = '%%'; $operand = $rest.substr(2) }
    elsif $rest.starts-with('%')  { $op = '%';  $operand = $rest.substr(1) }
    elsif $rest.starts-with('//') { $op = '//'; $operand = $rest.substr(2) }
    elsif $rest.starts-with('/#') { $op = '/#'; $operand = $rest.substr(2) }
    elsif $rest.starts-with('/%') { $op = '/%'; $operand = $rest.substr(2) }
    elsif $rest.starts-with('/')  { $op = '/';  $operand = $rest.substr(1) }
    elsif $rest.starts-with('^^') { $op = '^^' }
    elsif $rest.starts-with('^')  { $op = '^' }
    elsif $rest.starts-with(',,') { $op = ',,' }
    elsif $rest.starts-with(',')  { $op = ',' }
    elsif $rest.starts-with(':')  { $op = ':';  $operand = $rest.substr(1) }
    elsif $rest.chars > 0         { return ParamSpec.new(:ok(False)) }

    ParamSpec.new(:name($name), :op($op), :operand($operand))
}

# 开头连续的「名字字符」
sub leading-name(Str $s --> Str) is export {
    my $name = q{};
    for $s.comb -> $c {
        last unless is-name-char($c);
        $name ~= $c;
    }
    $name
}

# 词法记号。kind 只有两种：'word'（一个词）与 'op'（操作符）。
#
# **word 的 text 里保留引号字符**（`"'a b'"` 存成 `'a b'`）——
# 展开阶段要靠引号区分单/双/裸三种上下文，剥早了就会把 `'a $B'` 错误展开
# （bash 语义：单引号内一切原样）。
#
# `start` / `end` = 这个记号在**源串**里的下标区间（`text` 恰好等于
# `src.substr(start, end - start)`）。为什么需要：**改写整行**之前要
# **就地改写某些词**（brace 展开、`$$` 换成 PID），
# 而重拼整行会毁掉 `2>&1` 这种「数字紧贴操作符」的写法
# （重拼成 `2 >& 1` 就是语法错误）⇒ 只能按**原文位置**替换。
class Token is export {
    has Str  $.kind;           # 'word' | 'op'
    has Str  $.text;
    has Bool $.quoted = False; # 这个词里出现过引号
    has Int  $.start = 0;      # 源串里的起始下标
    has Int  $.end   = 0;      # 源串里的结束下标（不含）
}

# 词法结果。`unsupported` 非空 = 这行里有**本层不原生支持**的语法，
# 调用方应当把**原样文本**交给真 sh（而不是自己解析）——
# 半懂半猜地执行会让语义与 bash 不一致，比不支持更糟。
class Lexed is export {
    has List $.tokens;
    has Str  $.unsupported = q{};
}

# 反斜杠后面跟什么算「一个整体」。bash 语义：反斜杠转义**任意**字符
# （换行除外）。所以这里不设白名单 —— 白名单会让 `a\bc` 变成 `a` + `\bc`。
#
# 词法阶段**不剥反斜杠**：成对保留，交给 Expand 按上下文规则处理。
# 理由见下面双引号分支的注释。

# 是不是变量名可以用的字符
our sub is-name-char(Str $c --> Bool) is export {
    return True if $c ge 'a' and $c le 'z';
    return True if $c ge 'A' and $c le 'Z';
    return True if $c ge '0' and $c le '9';
    $c eq '_'
}

# `$` 后面跟的不是变量名、也不是 `{` ⇒ 是 bash 的特殊参数
# （`$?` `$#` `$$` `$!` `$0`…`$9`）。
#
# ⚠ 改动记录（第五批）：`$?` 与 `$$` 现在**原生支持**了
#   （见 Expand 的特殊参数展开、Session 的会话退出码），
#   所以这里不再把它们标成 unsupported。
#   仍然**不支持**的：`$!`（后台作业 PID）、`$#`（参数个数）、
#   `$@` / `$*`（位置参数）、`$-`（选项标志）。
#   `$0`…`$9` 里数字是「名字字符」，走**普通变量**那条路
#   （`$1` 展开成空串 —— bash 里它也是空的：我们没有位置参数）。
#
# ⚠ 改动记录（第六批）：`$(` **不再**算特殊参数 ——
#   `$(...)`（命令替换）与 `$((...))`（算术展开）都是原生支持的，
#   由词法主循环单独整块吞掉（见 `lex`）。
#   这里必须放行，否则会误判成 unsupported ⇒ 整行被判不支持。
our sub special-dollar(Str $src, Int $i --> Bool) is export {
    return False if $i + 1 >= $src.chars;
    my $nx = $src.substr($i + 1, 1);
    return False if $nx eq '{';         # ${VAR} 是**变量**（原生支持）
    return False if $nx eq '(';         # $(...) / $((...))（原生支持）
    return False if is-name-char($nx);  # $VAR / $1
    return False if $nx eq '?';         # $?  → 上一条命令的退出码
    return False if $nx eq '$';         # $$  → shell 的 PID
    True
}

# ══════════════════════════════════════════════════════════════════════
# brace 展开（bash 语义）
# ══════════════════════════════════════════════════════════════════════
#
# bash 的展开顺序是「**切词** → brace 展开 → 变量展开 → 分词 → glob」。
# 于是 brace 展开是**词级**的：
#   · 一个词里的 `{a,b}` 展开成**多个词**
#   · `{1..5}` / `{a..e}` 是区间（可带步长 `{1..10..2}`）
#   · 既没有逗号也没有 `..` ⇒ **不展开**（`{a}` 是字面量）
#   · 引号里的 `{` `}` **不参与**（`"{a,b}"` 是字面量）
#   · 空的候选项被**丢掉**（`{,a}` → `a`）
#   · `${VAR}` 是**变量**，不是 brace 组
#
# 期望值全部来自真 bash 实测（bash 5.3），逐条对拍过：
#   {a,b} → a b          {a,{b,c}} → a b c      {a{b,c}} → {ab} {ac}
#   {1..5} → 1..5        {01..03} → 01 02 03     {5..1} → 5 4 3 2 1
#   {a..e} → a b c d e   {a} → {a}（字面）        {} → {}（字面）
#   {a,b}{c,d} → ac ad bc bd（**笛卡尔积**）
#   {a,b} {c,d} → a b c d（**两个词各展开后拼接**，不是笛卡尔积）
#   {a, b} → {a, b}（**不展开**：bash 先切词，组里有空白就断了）
#   {1..3,x} → 1..3 x（有逗号时区间不再展开）
#
# 为什么住在**词法**模块（而不是 Expand）：
#   brace 展开必须夹在「切词」与「变量展开」之间 ——
#   `x=1; echo {a,$x}` 在 bash 里是 `a 1`（变量在 brace 展开**之后**
#   才展开，所以 `$x` 是被 brace 展开分出来那个词里的变量）。
#   而「切词」正是词法做的事 ⇒ brace 展开住在词法层最自然。
#   （Expand 模块 use Lexer、不反向依赖，所以也不能放那边。）

# 组里出现这些字符（且**没被引号保护**）⇒ 这个 `{` 不是 brace 组。
#
# 判据来自 bash 的**词法顺序**：bash 先切词，词里出现裸的
# `;` `|` `&` `<` `>` `(` `)` 就是操作符，词在那儿就断了
# —— 于是 `{a,b;c}` 不是一个词，brace 展开**不会发生**。
# 同样的道理，组里若有**裸空白**，词法阶段就已经把它切成两个词了
# （`{a, b}` 在 bash 里原样输出 —— 实测 bash 5.3）。
our $BRACE-BLOCKED = ';|&<>()`' ~ "\t\n ";

# 一个 brace 组的内容分析结果。
class BraceGroup is export {
    has List $.commas = [];     # 顶层逗号在内容里的下标
    has Bool $.blocked = False; # 里面有裸空白 / 裸操作符
}

# 找 `{` 的配对 `}`（认引号、认嵌套）。找不到返回 -1。
our sub brace-match-end(Str $s, Int $open --> Int) is export {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $depth = 1;
    my $i = $open + 1;
    my $mode = 'bare';
    while $i < $n {
        my $c = @ch[$i];
        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            if $c eq $DQUOTE { $mode = 'bare'; $i++; next }
            $i++;
            next;
        }
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }
        if $c eq '{' { $depth++; $i++; next }
        if $c eq '}' {
            $depth--;
            return $i if $depth == 0;
            $i++;
            next;
        }
        $i++;
    }
    -1
}

# 分析一个 brace 组的内容：顶层逗号在哪儿、有没有裸空白/裸操作符。
our sub scan-brace-group(Str $content --> BraceGroup) is export {
    my @commas;
    my $blocked = False;
    my @ch = $content.comb;
    my $n = @ch.elems;
    my $i = 0;
    my $depth = 0;
    my $mode = 'bare';
    while $i < $n {
        my $c = @ch[$i];
        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            if $c eq $DQUOTE { $mode = 'bare'; $i++; next }
            $i++;
            next;
        }
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }
        if $c eq '{' { $depth++; $i++; next }
        if $c eq '}' { $depth--; $i++; next }
        if $depth == 0 {
            if $c eq ',' { @commas.push: $i }
            elsif $BRACE-BLOCKED.contains($c) { $blocked = True }
        }
        $i++;
    }
    my @c-snap = @commas;
    BraceGroup.new(:commas(@c-snap), :blocked($blocked))
}

# 按顶层逗号切开内容。
#
# ⚠ **不要写 `--> List`**：容器返回标注跨实现不兼容（见 Slow.rakumod 文件头）。
our sub split-top-commas(Str $content, List $commas) is export {
    my @out;
    my $prev = 0;
    for @($commas) -> $p {
        @out.push: $content.substr($prev, $p - $prev);
        $prev = $p + 1;
    }
    @out.push: $content.substr($prev);
    @out
}

# 这个字符串是不是一个整数？（可带 +/- 号）
our sub is-int-str(Str $s --> Bool) is export {
    return False if $s.chars == 0;
    my $t = $s;
    if $t.starts-with('-') or $t.starts-with('+') { $t = $t.substr(1) }
    return False if $t.chars == 0;
    for $t.comb -> $c { return False unless $c ge '0' and $c le '9' }
    True
}

# 字符串 → 整数（手写，不靠 `Int()` —— 两后端对 `Int("+5")` 的处理
# 不完全一样，手写就没有这个分歧）。
our sub str-to-int(Str $s --> Int) is export {
    my $neg = False;
    my $t = $s;
    if $t.starts-with('-') { $neg = True; $t = $t.substr(1) }
    elsif $t.starts-with('+') { $t = $t.substr(1) }
    my $v = 0;
    for $t.comb -> $c { $v = $v * 10 + (ord($c) - 48) }
    $neg ?? -$v !! $v
}

# 区间的**补零宽度**（bash：`{01..10}` → 01 02 … 10）。
#
# 规则：**以 0 开头**的端点决定宽度，宽度 = 那个字符串的**长度**。
#   "01" → 2    "001" → 3    "010" → 3
#   "10" → 0（不以 0 开头）   "0" → 0（只有一位）
#   "3"  → 0
# 取两端宽度的**较大者**（`{01..3}` → 2；`{3..01}` → 2）。
our sub zero-width(Str $s --> Int) is export {
    return 0 if $s.chars < 2;
    return 0 unless $s.substr(0, 1) eq '0';
    $s.chars
}

# 补零到指定宽度（bash：`{01..10}` → 01 02 … 10）。
our sub pad-int(Int $v, Int $w --> Str) is export {
    my $s = $v.Str;
    return $s if $w <= 0 or $s.chars >= $w;
    ('0' x ($w - $s.chars)) ~ $s
}

# 区间：`X..Y` 或 `X..Y..Z`。不是合法区间时返回**空数组**。
#
# 规则（实测 bash 5.3）：
#   · 两端都是整数 ⇒ 数值区间；**前导零**决定补零宽度
#     （`{01..03}` → 01 02 03；`{1..10}` → 1 … 10；`{10..01}` → 10 09 … 01）
#   · 两端都是**单个字符** ⇒ 字符区间（`{a..e}` → a b c d e）
#   · 混合（`{a..5}`）或两端不止一个字符（`{ab..ad}`）⇒ **不展开**
#   · 步长：`{1..10..2}` → 1 3 5 7 9；步长 0 当 1；
#     方向由起止决定（`{5..1..-1}` → 5 4 3 2 1；`{a..c..-1}` → a b c）
#
# ⚠ **不要写 `--> List`**：容器返回标注跨实现不兼容（Slow.rakumod 文件头）。
our sub range-items(Str $content) is export {
    # 含引号 / 反斜杠 ⇒ 不是区间（bash 也不认）
    my @none;
    return @none if $content.contains($SQUOTE);
    return @none if $content.contains($DQUOTE);
    return @none if $content.contains($BSL);
    my $p = index($content, '..') // -1;
    return @none if $p < 0;
    my $a = $content.substr(0, $p);
    my $rest = $content.substr($p + 2);
    my $b = $rest;
    my $step = 1;
    my $q = index($rest, '..') // -1;
    if $q >= 0 {
        $b = $rest.substr(0, $q);
        my $st = $rest.substr($q + 2);
        return @none unless is-int-str($st);
        $step = str-to-int($st);
    }
    return @none if $a.chars == 0 or $b.chars == 0;

    my $st = abs($step);
    if $st == 0 { $st = 1 }

    # 数值区间
    if is-int-str($a) and is-int-str($b) {
        my $from = str-to-int($a);
        my $to = str-to-int($b);
        my $w = zero-width($a);
        my $w2 = zero-width($b);
        if $w2 > $w { $w = $w2 }
        my @out;
        if $from <= $to {
            my $v = $from;
            while $v <= $to { @out.push: pad-int($v, $w); $v += $st }
        }
        else {
            my $v = $from;
            while $v >= $to { @out.push: pad-int($v, $w); $v -= $st }
        }
        return @out;
    }

    # 字符区间（两端都是单个字符，且都不是数字）
    if $a.chars == 1 and $b.chars == 1 {
        my $ca = $a.substr(0, 1);
        my $cb = $b.substr(0, 1);
        return @none if $ca ge '0' and $ca le '9';
        return @none if $cb ge '0' and $cb le '9';
        my $from = ord($ca);
        my $to = ord($cb);
        my @out;
        if $from <= $to {
            my $v = $from;
            while $v <= $to { @out.push: chr($v); $v += $st }
        }
        else {
            my $v = $from;
            while $v >= $to { @out.push: chr($v); $v -= $st }
        }
        return @out;
    }

    @none
}

# ── brace 展开的主入口 ────────────────────────────────────────────
#
# 返回**展开后的词列表**（1 个或多个）。
#   `brace-expand-text('{a,b}')`  →  ('a', 'b')
#   `brace-expand-text('x{1..3}y')` →  ('x1y', 'x2y', 'x3y')
#   `brace-expand-text('{a}')`    →  ('{a}')     ← 没有逗号也没有 `..`
#
# 算法（与 bash 一致）：
#   1. 从左往右找**第一个可展开**的组（`{a}` 这种不可展开的跳过，继续找下一个）
#   2. 逗号组 → 按顶层逗号切候选项；区间组 → 生成序列
#   3. 每个候选项与前后缀拼起来，**递归**再展开一次
#      （于是多个组形成笛卡尔积，且**最左边的组变化最慢**）
#
# ⚠⚠ **Raku 陷阱（本轮实测踩到，两后端一致）**：
#   `@a = $someList` **不摊平** —— 数组里只有**一个**元素（那个 List 本身）；
#   而 `@a = f()`（**调用**结果）会摊平。
#   ⇒ 想把一个 List 摊进数组，必须**直接赋值调用结果**，
#     中间存进变量再赋值就会变成「一个元素」（症状：区间展开成
#     `x1 2 3y` 这种把整个列表拼进一个词的样子）。
#   ⇒ 本函数**不要**写 `--> List`（容器返回标注跨实现不兼容），
#     一律返回普通 Array，调用点直接赋值。
our sub brace-expand-text(Str $s) is export {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = 0;
    my $mode = 'bare';

    while $i < $n {
        my $c = @ch[$i];

        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            if $c eq $DQUOTE { $mode = 'bare'; $i++; next }
            $i++;
            next;
        }

        # 裸段
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }

        if $c eq $DOLLAR and $i + 1 < $n {
            my $nx = @ch[$i + 1];
            # `${...}` 是**变量**，不是 brace 组 → 整块跳过
            if $nx eq '{' {
                my $end = brace-match-end($s, $i + 1);
                if $end >= 0 { $i = $end + 1; next }
                $i += 2;
                next;
            }
            # `$$` 是 PID 参数 → 吃掉两个 `$`
            # （后面的 `{` 是**独立**的组：`$${a,b}` 在 bash 里是「PID + 展开」）
            if $nx eq '$' { $i += 2; next }
            $i++;
            next;
        }

        if $c eq '{' {
            my $end = brace-match-end($s, $i);
            if $end < 0 { $i++; next }          # 没配对 → 字面量
            my $content = $s.substr($i + 1, $end - $i - 1);
            my $g = scan-brace-group($content);
            my @alts;
            if $g.blocked {
                @alts = ();                    # 组里有裸空白/操作符 → 不是 brace 组
            }
            elsif $g.commas.elems > 0 {
                @alts = split-top-commas($content, $g.commas);
            }
            else {
                # ⚠ **直接赋值调用结果**（见本函数上头的 Raku 陷阱说明）
                @alts = range-items($content);
            }
            if @alts.elems == 0 {
                # 这个组不可展开（既没有逗号也不是区间）→ **继续往里找**
                # （只跳过 `{` 这一个字符，不跳过整组 ——
                #   否则嵌套在里面的组就永远找不到了：
                #   `{a{b,c}}` 在 bash 里是 `{ab}` `{ac}`，不是字面量）
                $i++;
                next;
            }
            # 空候选项丢掉（bash：`{,a}` → `a`，`{a,,b}` → a b）
            my @keep;
            for @alts -> $a { @keep.push: $a if $a.chars }
            my $prefix = $s.substr(0, $i);
            my $suffix = $s.substr($end + 1);
            my @out;
            for @keep -> $alt {
                for @(brace-expand-text($prefix ~ $alt ~ $suffix)) -> $r {
                    @out.push: $r;
                }
            }
            return @out;
        }

        $i++;
    }

    my @one = ($s);
    @one
}

# ── 主词法 ──────────────────────────────────────────────────────────
# 逐字符状态机。三个模式：
#   bare   —— 空格/制表符分词；`\` 转义下一个字符；引号开启对应模式
#   single —— 单引号内一切原样（连 `\` 都不转义，bash 语义）
#   double —— 双引号内保留 `\` + 下一字符成对；`"` 结束本段
#
# `:cmdsub` = 是否支持命令替换（`$(...)` 与 `` `...` ``）。
#   · False（默认）：命令替换标记成 unsupported → 整行判不支持。
#     **保持默认行为不变**，是为了不破坏既有调用方与测试。
#   · True：命令替换被当作**一个整体**吞进当前的词里
#     （里面的空格不切词 —— bash 语义：命令替换是一个词，
#      空格只在替换**之后**才参与分词）。
our sub lex(Str $src, Bool :$cmdsub = False --> Lexed) is export {
    my @toks;
    my $cur = q{};
    my $has-cur = False;
    my $quoted = False;
    my $mode = 'bare';
    my $bad = q{};
    # 当前词在**源串**里的起始下标（Token 的 start/end 字段用）。
    my $word-start = 0;

    # `.comb` 给字符列表（不是 `.chars` —— 见文件头规矩 ①）
    my @ch = $src.comb;
    my $n = @ch.elems;
    my $i = 0;

    while $i < $n {
        my $c = @ch[$i];

        # ── 单引号段 ──────────────────────────────────────────────
        if $mode eq 'single' {
            $cur ~= $c;
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }

        # ── 双引号段 ──────────────────────────────────────────────
        if $mode eq 'double' {
            # 反斜杠 + 任意字符**成对保留**，不剥反斜杠。
            #
            # 【与 V 版的差异 · 修掉一个真 bug】V 版在这里写的是
            # `cur += 被转义字符`（反斜杠被丢掉），于是源文本里的 `\"`
            # 在词法阶段就变成了裸 `"` —— **提前结束引号段**，
            # 后面整段内容会被当成新词切分。
            # 保留成对字符是安全的：Expand 阶段按 bash 规则再处理一次
            # （双引号内只有 `" \ $ \`` 四个字符的反斜杠有转义意义）。
            if $c eq $BSL and $i + 1 < $n {
                $cur ~= $c ~ @ch[$i + 1];
                $i += 2;
                next;
            }
            if $c eq $DQUOTE {
                $mode = 'bare';
                $cur ~= $c;
                $i++;
                next;
            }
            # ── 参数展开 `${...}` 与算术展开 `$((...))`（双引号内）──
            # 必须**整块吞掉**：`${V:-a b}` 里有一个空格，
            # 按普通字符处理会被切成两个词 —— 而 bash 里参数展开是**一个词**，
            # 空格只在替换**之后**才参与分词。
            if $c eq $DOLLAR and $i + 1 < $n {
                my $nx = @ch[$i + 1];
                if $nx eq '(' and $i + 2 < $n and @ch[$i + 2] eq '(' {
                    my $aend = find-arith-end($src, $i);
                    if $aend >= 0 {
                        my $inner = $src.substr($i + 3, $aend - $i - 4);
                        if arith-has-cmdsub($inner) {
                            $bad = 'command substitution inside arithmetic expansion';
                        }
                        $cur ~= $src.substr($i, $aend - $i + 1);
                        $i = $aend + 1;
                        next;
                    }
                    $bad = 'arithmetic expansion $((...))';
                }
                if $nx eq '{' {
                    my $pend = brace-match-end($src, $i + 1);
                    if $pend >= 0 {
                        my $inner = $src.substr($i + 2, $pend - $i - 2);
                        my $spec = parse-param-spec($inner);
                        $bad = 'parameter expansion' if not $spec.ok;
                        $cur ~= $src.substr($i, $pend - $i + 1);
                        $i = $pend + 1;
                        next;
                    }
                    $bad = 'unterminated ${...}';
                }
            }
            # 双引号内的命令替换：`$(...)` / `` `...` ``
            # 开启 `:cmdsub` 时整块吞掉（不切词）；否则标记成不支持。
            if $c eq $DOLLAR and $i + 1 < $n and @ch[$i + 1] eq '(' {
                my $end = $cmdsub ?? find-cmdsub-end($src, $i + 1) !! -1;
                if $end >= 0 {
                    $cur ~= $src.substr($i, $end - $i + 1);
                    $i = $end + 1;
                    next;
                }
                $bad = 'command substitution $(...) inside double quotes';
            }
            if $c eq $TICK {
                my $end = $cmdsub ?? find-backtick-end($src, $i) !! -1;
                if $end >= 0 {
                    $cur ~= $src.substr($i, $end - $i + 1);
                    $i = $end + 1;
                    next;
                }
                $bad = 'command substitution inside double quotes';
            }
            # ── `$$`（PID 参数）→ **成对**吃掉 ──────────────────
            #
            # ⚠⚠ **必须成对**（真 bug，2026-11-05 修）：
            #   这个分支是**逐字符**扫描的 —— 第一个 `$` 被当普通字符收下，
            #   第二个 `$` 就**单独**落进下面的 `special-dollar` 检查，
            #   而它看的是「下一个字符」= `"` ⇒ 判成「不支持的特殊参数」
            #   ⇒ `echo "$$"` 整行被判 unsupported。
            #
            # ⚠ **裸位置分支有同一个 bug**（`echo $$ x`）—— 一并修了，
            #   见下面裸模式里的同名注释。
            if $c eq $DOLLAR and $i + 1 < $n and @ch[$i + 1] eq '$' {
                $cur ~= $c ~ @ch[$i + 1];
                $i += 2;
                next;
            }
            if $c eq $DOLLAR and special-dollar($src, $i) {
                $bad = 'special parameter ($? / $$ / $1 ...) inside double quotes';
            }
            $cur ~= $c;
            $i++;
            next;
        }

        # ── 裸模式 ────────────────────────────────────────────────
        # 反斜杠转义：反斜杠 + 任意字符算**同一个词的一部分**
        # （`a\ b` 是一个词，不是两个词）。成对保留，Expand 再剥。
        if $c eq $BSL and $i + 1 < $n {
            $word-start = $i if not $has-cur;
            $cur ~= $c ~ @ch[$i + 1];
            $has-cur = True;
            $quoted = True;        # 转义过的字符不参与 glob
            $i += 2;
            next;
        }

        # 空白分词
        if $c eq ' ' or $c eq $TAB {
            if $has-cur {
                @toks.push: Token.new(:kind('word'), :text($cur), :quoted($quoted),
                                      :start($word-start), :end($i));
                $cur = q{};
                $has-cur = False;
                $quoted = False;
            }
            $i++;
            next;
        }

        # 单引号：开启单引号段
        if $c eq $SQUOTE {
            $word-start = $i if not $has-cur;
            $mode = 'single';
            $has-cur = True;
            $quoted = True;
            $cur ~= $c;
            $i++;
            next;
        }

        # 双引号：开启双引号段
        if $c eq $DQUOTE {
            $word-start = $i if not $has-cur;
            $mode = 'double';
            $has-cur = True;
            $quoted = True;
            $cur ~= $c;
            $i++;
            next;
        }

        # ── 操作符 ────────────────────────────────────────────────
        if $c eq '|' or $c eq ';' or $c eq '&' {
            if $has-cur {
                @toks.push: Token.new(:kind('word'), :text($cur), :quoted($quoted),
                                      :start($word-start), :end($i));
                $cur = q{};
                $has-cur = False;
                $quoted = False;
            }
            # `&&` / `||` 必须合并成**单个** op：拆成两个会让 parser 看成
            # 两条流水线（`a && b` 变成 `a` 与 `b` 两条），语义全错。
            # 合并后由 parser 标记 unsupported → 整段判不支持。
            if $c eq '|' and $i + 1 < $n and @ch[$i + 1] eq '|' {
                @toks.push: Token.new(:kind('op'), :text('||'), :start($i), :end($i + 2));
                $i += 2;
                next;
            }
            if $c eq '&' and $i + 1 < $n and @ch[$i + 1] eq '&' {
                @toks.push: Token.new(:kind('op'), :text('&&'), :start($i), :end($i + 2));
                $i += 2;
                next;
            }
            # `&>` / `&>>` = stdout+stderr 一并重定向（bash 语义）。
            # 不合并的话 parser 看到裸 `&` 会把当前命令提前切掉，
            # 重定向落到错误的 command 上。
            if $c eq '&' and $i + 1 < $n and @ch[$i + 1] eq '>' {
                if $i + 2 < $n and @ch[$i + 2] eq '>' {
                    @toks.push: Token.new(:kind('op'), :text('&>>'), :start($i), :end($i + 3));
                    $i += 3;
                }
                else {
                    @toks.push: Token.new(:kind('op'), :text('&>'), :start($i), :end($i + 2));
                    $i += 2;
                }
                next;
            }
            # 裸 `&` = 后台作业 —— 不实现（要作业控制）⇒ 判不支持
            if $c eq '&' {
                $bad = 'background job (&)';
            }
            @toks.push: Token.new(:kind('op'), :text($c), :start($i), :end($i + 1));
            $i++;
            next;
        }

        # `!` 只在**词首**切出 op（`echo hi!` 里的 ! 属于词内容）
        if $c eq '!' and !$has-cur {
            @toks.push: Token.new(:kind('op'), :text('!'), :start($i), :end($i + 1));
            $i++;
            next;
        }

        # `<` / `>` 家族
        if $c eq '<' or $c eq '>' {
            if $has-cur {
                @toks.push: Token.new(:kind('word'), :text($cur), :quoted($quoted),
                                      :start($word-start), :end($i));
                $cur = q{};
                $has-cur = False;
                $quoted = False;
            }
            if $c eq '>' and $i + 1 < $n and @ch[$i + 1] eq '>' {
                if $i + 2 < $n and @ch[$i + 2] eq '>' {
                    # `>>>` 不是我们要的语法 ⇒ 判不支持
                    @toks.push: Token.new(:kind('op'), :text('>>>'), :start($i), :end($i + 3));
                    $bad = '>>> redirect';
                    $i += 3;
                }
                else {
                    @toks.push: Token.new(:kind('op'), :text('>>'), :start($i), :end($i + 2));
                    $i += 2;
                }
                next;
            }
            if $c eq '<' and $i + 1 < $n and @ch[$i + 1] eq '<' {
                if $i + 2 < $n and @ch[$i + 2] eq '<' {
                    # `<<<` herestring（字符串当 stdin）—— 不实现 ⇒ 判不支持
                    @toks.push: Token.new(:kind('op'), :text('<<<'), :start($i), :end($i + 3));
                    $bad = 'herestring (<<<)';
                    $i += 3;
                    next;
                }
                # `<<` / `<<-`：heredoc。分隔符是**下一个词**（由 Parser 取）。
                # `<<-` 的 `-` 必须**紧跟** `<<`（bash 规则：`<< -EOF` 的分隔符
                # 是 `-EOF`，不是 `EOF`）。
                my $strip = False;
                my $adv = 2;
                if $i + 2 < $n and @ch[$i + 2] eq '-' {
                    $strip = True;
                    $adv = 3;
                }
                @toks.push: Token.new(:kind('op'), :text($strip ?? '<<-' !! '<<'),
                                              :start($i), :end($i + ($strip ?? 3 !! 2)));
                $i += $adv;
                next;
            }
            # `>&` / `<&` = fd 复制（2>&1 / >&2）
            if $i + 1 < $n and @ch[$i + 1] eq '&' {
                @toks.push: Token.new(:kind('op'), :text($c ~ '&'), :start($i), :end($i + 2));
                $i += 2;
                next;
            }
            @toks.push: Token.new(:kind('op'), :text($c), :start($i), :end($i + 1));
            $i++;
            next;
        }

        # ── 参数展开 `${...}` 与算术展开 `$((...))`（整块算一个词）──
        #
        # 必须整块吞掉：`${V:-a b}` 里有一个空格，
        # 按普通字符处理会被切成两个词 —— 而 bash 里参数展开是**一个词**，
        # 空格只在替换**之后**才参与分词（Expand 的 split-frags 负责）。
        if $c eq $DOLLAR and $i + 1 < $n {
            my $nx = @ch[$i + 1];
            # ── `$$`（PID 参数）→ **成对**吃掉 ──────────────────
            #
            # ⚠⚠ **必须成对**（真 bug，2026-11-05 修）：
            #   裸位置也是**逐字符**扫描 —— 第一个 `$` 收下后，
            #   第二个 `$` 会**单独**落进 `special-dollar`，
            #   而它看的是「下一个字符」= 空格 ⇒ 判成「不支持的特殊参数」
            #   ⇒ `echo $$ x` 整行被判 unsupported
            #   （只有 `$$` 恰好在**行尾**时才侥幸躲过）。
            if $nx eq '$' {
                $word-start = $i if not $has-cur;
                $cur ~= $c ~ $nx;
                $has-cur = True;
                $i += 2;
                next;
            }
            # ⚠ `$((` 必须**先于** `$(` 判断：`$(` 后面紧跟第二个 `(`
            #   才是算术展开（`$( (echo a) )` 是命令替换，括号前面有空格）。
            if $nx eq '(' and $i + 2 < $n and @ch[$i + 2] eq '(' {
                my $aend = find-arith-end($src, $i);
                if $aend >= 0 {
                    my $inner = $src.substr($i + 3, $aend - $i - 4);
                    if arith-has-cmdsub($inner) {
                        $bad = 'command substitution inside arithmetic expansion';
                    }
                    $word-start = $i if not $has-cur;
                    $cur ~= $src.substr($i, $aend - $i + 1);
                    $has-cur = True;
                    $i = $aend + 1;
                    next;
                }
                $bad = 'arithmetic expansion $((...))';
            }
            if $nx eq '{' {
                my $pend = brace-match-end($src, $i + 1);
                if $pend >= 0 {
                    my $inner = $src.substr($i + 2, $pend - $i - 2);
                    my $spec = parse-param-spec($inner);
                    # 不认识的写法（`${V@Q}` 之类）⇒ 整行判不支持
                    # （bash 自己会报 "bad substitution"，我们照它的意思报）
                    $bad = 'parameter expansion' if not $spec.ok;
                    $word-start = $i if not $has-cur;
                    $cur ~= $src.substr($i, $pend - $i + 1);
                    $has-cur = True;
                    $i = $pend + 1;
                    next;
                }
                $bad = 'unterminated ${...}';
            }
        }

        # ── 命令替换：$(...) 与 `...`（整块算**一个词**的一部分）──
        #
        # 必须整块吞掉：`$(echo a b)` 里有一个空格，
        # 按普通字符处理会被切成两个词 —— 而 bash 里命令替换是**一个词**，
        # 空格只在替换**之后**才参与分词（Expand 的 split-frags 负责）。
        if $c eq $DOLLAR and $i + 1 < $n and @ch[$i + 1] eq '(' {
            my $end = $cmdsub ?? find-cmdsub-end($src, $i + 1) !! -1;
            if $end >= 0 {
                $word-start = $i if not $has-cur;
                $cur ~= $src.substr($i, $end - $i + 1);
                $has-cur = True;
                $i = $end + 1;
                next;
            }
            $bad = 'command substitution $(...)';
        }
        if $c eq $TICK {
            my $end = $cmdsub ?? find-backtick-end($src, $i) !! -1;
            if $end >= 0 {
                $word-start = $i if not $has-cur;
                $cur ~= $src.substr($i, $end - $i + 1);
                $has-cur = True;
                $i = $end + 1;
                next;
            }
            $bad = 'command substitution (`)';
        }

        # ── 不原生支持的裸字符 ────────────────────────────────────
        # 子 shell / 复合命令 —— 一律判不支持（明确报错）。
        # 判据是**裸位置**（引号内不算）：`awk '{print $1}'` 里的 `{` 是字面量。
        #
        # ⚠ `{` / `}` **不再**一律判为不支持（第五批起 brace 展开原生支持）：
        #   bash 里 `{` 只有在「**独立成词**且后面跟空白」时才是**保留字**
        #   （复合命令 `{ cmd; }`）；否则它就是普通字符（brace 展开的候选）。
        #   判据：当前词为空（词的起点）且下一个字符是空白。
        if $c eq '(' or $c eq ')' {
            $bad = 'subshell ( )';
        }
        if $c eq '{' {
            if not $has-cur and $i + 1 < $n {
                my $nx = @ch[$i + 1];
                if $nx eq ' ' or $nx eq $TAB {
                    $bad = 'compound command ({ })';
                }
            }
        }
        if $c eq '}' {
            # 独立的 `}` 是 bash 的保留字（复合命令的结尾）⇒ 判不支持
            if not $has-cur {
                $bad = 'compound command ({ })';
            }
        }
        if $c eq $DOLLAR and special-dollar($src, $i) {
            $bad = 'special parameter ($! / $# / $@ / $* / $-)';
        }

        $word-start = $i if not $has-cur;
        $cur ~= $c;
        $has-cur = True;
        $i++;
    }

    # 收尾：没闭合的引号照样出词（展开阶段会看到没配对的引号）
    if $has-cur {
        @toks.push: Token.new(:kind('word'), :text($cur), :quoted($quoted),
                              :start($word-start), :end($n));
    }

    # ⚠ 先拷贝再传：命名实参里的数组是**后期绑定**的（保存变量而不是值）。
    my @t-snap = @toks;
    Lexed.new(:tokens(@t-snap), :unsupported($bad))
}

# ── 这个词里有没有**未被引号保护**的 glob 字符 ──────────────────────
# bash 规则：只有裸位置的 `*` / `?` 才触发 glob。
#   `*.txt`  → glob
#   `"*.txt"`→ 不 glob（引号保护）
#   `\*.txt` → 不 glob（转义保护）
#   `a\*b*`  → glob（只有第一个 * 被保护，第二个仍生效）
# 所以判据不能是「词里含不含引号」（V 版的 is_quoted 就是这么粗的），
# 必须**逐字符按上下文**看。
#
# `:cmdsub` = 命令替换区域要不要跳过。跳过是对的：`$(echo *.txt)` 里的
# `*` 属于**内层**命令，不是外层词的 glob 模式。
#
# ⚠ **展开流水线已经不用这个函数了** —— 片段模型（Expand::Frag）能直接
#   看出每个字符来自哪种上下文，glob 活性是**逐片段**判断的，比这里
#   「整词里有没有裸位置的 `*`」精确（能区分 `a"*"b`）。
#   本函数保留给外部调用者与测试。
our sub has-unquoted-glob(Str $s, Bool :$cmdsub = False --> Bool) is export {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = 0;
    my $mode = 'bare';
    while $i < $n {
        my $c = @ch[$i];
        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            $mode = 'bare' if $c eq $DQUOTE;
            $i++;
            next;
        }
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }
        if $cmdsub and $c eq $DOLLAR and $i + 1 < $n and @ch[$i + 1] eq '(' {
            my $e = find-cmdsub-end($s, $i + 1);
            if $e >= 0 { $i = $e + 1; next }
        }
        if $c eq '*' or $c eq '?' { return True }
        $i++;
    }
    False
}
