unit module Rakuish::Shell::Arith;

use Rakuish::Shell::Session;

# Rakuish::Shell::Arith —— **算术展开** `$((...))` 的求值器
#
# 为什么单独一个模块：它是个**自足的小语言**（递归下降解析），
# 与 Expand 的「片段模型」完全无关 —— 混在一起会让两个文件都难读。
#
# ── bash 语义（全部实测过，bash 5.3.9）──────────────────────────
#
#   $((1+2))      → 3        $((3*4-1))  → 11
#   $((10/3))     → 3        （整数除法，向零取整：-7/2 → -3）
#   $((10%3))     → 1        $((2**10))  → 1024
#   $((1<<4))     → 16       $((6&3))    → 2
#   $((6|3))      → 7        $((6^3))    → 5      $((~5))  → -6
#   $((1<2))      → 1        $((1&&0))   → 0      $((0||7))→ 1
#   $((!0))       → 1        $((1?2:3))  → 2（元）
#   $((X+1))      → 变量参与（**裸名字**也是变量：`$((X+1))` 里的 X）
#   $((X=9))      → **有赋值副作用**（X 变成 9，表达式值也是 9）
#   $((0x10))     → 16       $((010)) → 8（八进制）  $((2#101)) → 5（base#num）
#   $((1,2))      → 2（逗号运算符，取最后一个）
#
# ⚠ **优先级**（从松到紧，实测得出）：
#
#   `,` → 赋值 → 三元 → `||` → `&&` → `|` → `^` → `&`
#   → 相等 → 关系 → 移位 → `+ -` → `* / %` → **`**`** → 一元 → 基本项
#
# ⚠⚠ **`**` 比一元运算符**更松**（不是 C 的语义！）：
#   bash 里 `-2**2` = **4**（= `(-2)**2`），不是 -4。
#   同理 `~5**2` = 36（= `(~5)**2`）。
#   实测：`$((-2**2))` → 4；`$((-(2**2)))` → -4。
#   → 所以文法是 `power := unary ('**' power)?`，**右结合**
#     （`$((2**3**2))` = 512 = 2**(3**2)）。
#
# ── 一条实现上的硬规矩 ─────────────────────────────────────────
# ⚠ **Raku 的 `~` 是「字符串取反」，不是位取反**（Perl 血统的经典陷阱）：
#   `~5` 在 Raku 里是 **Str "5"**（先转成 Str 再取反），
#   会让 `--> Int` 的返回类型检查直接报
#   "expected Int but got Str ("5")" —— 症状极难定位。
#   而前缀 `^` 也不行：`^5` 是**序列**运算符（0 1 2 3 4）。
#   → Int 的位取反用 **`+^`**（Raku 的位运算家族：`+&` `+|` `+^` `+<` `+>`）✓

# ── 状态 ────────────────────────────────────────────────────────
#
# 用一个 class（而不是 Hash）装全部状态：可变的属性用 `is rw`。
class ArithState is export {
    has Array $.ch  = [];        # 字符数组（`.comb` 的结果）
    has Int   $.pos is rw = 0;  # 当前位置
    has Int   $.n   = 0;         # 字符总数
    has Hash  $.over = Hash.new;# 变量覆盖表（预扫描时是影子表）
    has Bool  $.bad  is rw = False;  # 语法错误？
    has Str   $.var  is rw = q{};    # 最近读到的变量名（赋值要用）
    has Str   $.err  is rw = q{};    # 运行时错误（除零 …）
}

# ── 词法小工具 ──────────────────────────────────────────────────

# 跳过空白
sub skip-ws(ArithState $s --> Nil) {
    while $s.pos < $s.n {
        my $c = $s.ch[$s.pos];
        last unless $c eq ' ' or $c eq "\t" or $c eq "\n";
        $s.pos = $s.pos + 1;
    }
    Nil
}

# 当前位置的字符（越界返回空串）
sub peek(ArithState $s --> Str) {
    return q{} if $s.pos >= $s.n;
    $s.ch[$s.pos]
}

# 当前位置是不是以 $t 开头？
sub starts-with(ArithState $s, Str $t --> Bool) {
    my $l = $t.chars;
    return False if $s.pos + $l > $s.n;
    for (0 ..^ $l) -> $k {
        return False unless $s.ch[$s.pos + $k] eq $t.substr($k, 1);
    }
    True
}

# 吃掉一个运算符（不吃空白 —— 空白由调用方先 skip）
sub eat(ArithState $s, Str $op --> Bool) {
    return False unless starts-with($s, $op);
    $s.pos = $s.pos + $op.chars;
    True
}

# 吃掉一个运算符（不吃空白 —— 空白由调用方先 skip）
#
# 单字符运算符有**一条额外限制**：不能吃掉双字符运算符的前半截
# （`|` 不能吃掉 `||` 的第一个 `|` —— `||` 的优先级更松）。
sub eat-bin(ArithState $s, Str $op --> Bool) {
    return False unless starts-with($s, $op);
    if $op.chars == 1 {
        return False if $s.pos + 1 < $s.n and $s.ch[$s.pos + 1] eq $op;
    }
    $s.pos = $s.pos + $op.chars;
    True
}

# 当前的赋值运算符？（返回运算符文本，**不**吃掉）
sub assign-op(ArithState $s --> Str) {
    # ⚠⚠ **必须用普通列表 `("+=", ...)`，不能用 `<...>`** ——
    #   Raku 的 `<...>`（quote-words）**不剥引号**：
    #     <"a" "b">   → ('"a"', '"b"')    ← 引号是**字面字符**
    #     <'a' 'b'>   → 整个当**一个** q:s 字符串
    #   ⇒ 用 quote-words 时每个元素都带着引号，长度对不上 ⇒
    #     `starts-with` 的长度检查直接把整串判成「不匹配」
    #     ⇒ 复合赋值（`+=` `*=` …）全部失效（实测：`$((X+=2))` 得 0）。
    #   （Raku 经典坑，已记进 HANDOFF §4.8）
    my @ops = ("+=", "-=", "*=", "/=", "%=", "<<=", ">>=", "&=", "|=", "^=");
    for @ops -> $o {
        return $o if starts-with($s, $o);
    }
    if starts-with($s, '=') and not starts-with($s, '==') {
        return '=';
    }
    q{}
}

# ── 二元运算符的语义 ────────────────────────────────────────────
#
# ⚠ 第一个形参是**状态**：除零要往 `$s.err` 里写错误信息
#   （bash 的 `%` 与 `/` 除零都会报错并中止命令）。
sub apply-bin(ArithState $s, Str $op, Int $a, Int $b --> Int) {
    if $op eq '||' { return (($a != 0) or ($b != 0)) ?? 1 !! 0 }
    if $op eq '&&' { return (($a != 0) and ($b != 0)) ?? 1 !! 0 }
    if $op eq '|'  { return $a +| $b }
    if $op eq '^'  { return $a +^ $b }
    if $op eq '&'  { return $a +& $b }
    if $op eq '==' { return $a == $b ?? 1 !! 0 }
    if $op eq '!=' { return $a != $b ?? 1 !! 0 }
    if $op eq '<=' { return $a <= $b ?? 1 !! 0 }
    if $op eq '>=' { return $a >= $b ?? 1 !! 0 }
    if $op eq '<'  { return $a <  $b ?? 1 !! 0 }
    if $op eq '>'  { return $a >  $b ?? 1 !! 0 }
    if $op eq '<<' { return $a +< $b }
    if $op eq '>>' { return $a +> $b }
    if $op eq '+'  { return $a + $b }
    if $op eq '-'  { return $a - $b }
    if $op eq '*'  { return $a * $b }
    if $op eq '/'  {
        # ⚠ 除零：bash 报错并**中止**这条命令（`$((1/0))` → 空 + 错误）
        if $b == 0 {
            $s.err = 'division by zero';
            return 0;
        }
        return a-div($a, $b);
    }
    if $op eq '%'  {
        if $b == 0 {
            $s.err = 'division by zero';
            return 0;
        }
        return a-mod($a, $b);
    }
    0
}

# 赋值的语义（`$((X=9))` → 给 X 赋值并返回 9）
sub apply-assign(ArithState $s, Str $op, Int $a, Int $b --> Int) {
    my $val = $b;
    if    $op eq '+='  { $val = $a + $b }
    elsif $op eq '-='  { $val = $a - $b }
    elsif $op eq '*='  { $val = $a * $b }
    elsif $op eq '/='  { $val = a-div($a, $b) }
    elsif $op eq '%='  { $val = a-mod($a, $b) }
    elsif $op eq '<<=' { $val = $a +< $b }
    elsif $op eq '>>=' { $val = $a +> $b }
    elsif $op eq '&='  { $val = $a +& $b }
    elsif $op eq '|='  { $val = $a +| $b }
    elsif $op eq '^='  { $val = $a +^ $b }
    # 赋值的目标是**变量名**（基本项解析时记下来的那个）
    my $name = $s.var;
    if $name ne q{} {
        set-var($name, $val.Str);
        # 影子表里也有这个变量时一并更新（预扫描的一致性）
        if $s.over.EXISTS-KEY($name) {
            $s.over{$name} = $val.Str;
        }
    }
    $val
}

# 除法：向零取整（Raku 的 `/` 对 Int 是**真除法**（Rat）→ `.Int` 截断 ✓）
#
# ⚠ 除零由 `apply-bin` 拦（它要报错误信息），这里不再兜底。
sub a-div(Int $a, Int $b --> Int) {
    ($a / $b).Int
}

sub a-mod(Int $a, Int $b --> Int) {
    # ⚠ Raku 的 `%` 是**模**（结果符号跟**除数**）：`-7 % 3` = 2；
    #   bash 的 `%` 是**余**（符号跟**被除数**）：`-7 % 3` = -1。
    #   → 自己算：`a - b * (a/b 向零取整)` ✓
    $a - $b * (($a / $b).Int)
}

# ── 基本项：数字 / 变量 ─────────────────────────────────────────

# 名字里能用的字符
our sub is-arith-name-char(Str $c --> Bool) is export {
    return True if $c ge 'a' and $c le 'z';
    return True if $c ge 'A' and $c le 'Z';
    return True if $c ge '0' and $c le '9';
    $c eq '_'
}

# 十六进制数字
our sub is-hex-digit(Str $c --> Bool) is export {
    return True if $c ge '0' and $c le '9';
    return True if $c ge 'a' and $c le 'f';
    return True if $c ge 'A' and $c le 'F';
    False
}

# 任意进制的数字串 → Int（手写，不靠 `Int("0x10")` —— 那个对
# 「0x 前缀」的处理在两个实现上不一致，手写就没有这个分歧）
our sub str-to-int-base(Str $s, Int $base --> Int) is export {
    my $v = 0;
    for $s.comb -> $c {
        my $d = digit-value($c);
        last if $d < 0;
        $v = $v * $base + $d;
    }
    $v
}

# 一个字符的数值（0-9 / a-f / A-F），非法返回 -1
our sub digit-value(Str $c --> Int) is export {
    return ord($c) - 48 if $c ge '0' and $c le '9';
    return ord($c) - 87 if $c ge 'a' and $c le 'f';   # 'a' = 97 → 10
    return ord($c) - 55 if $c ge 'A' and $c le 'F';   # 'A' = 65 → 10
    -1
}

# 数字：十进制 / `0x` 十六进制 / `0` 开头八进制 / `base#digits`
sub parse-number(ArithState $s --> Int) {
    # `base#digits`（base 是 2..64）
    my $i = $s.pos;
    my $base = 0;
    while $i < $s.n {
        my $x = $s.ch[$i];
        last unless $x ge '0' and $x le '9';
        $base = $base * 10 + (ord($x) - 48);
        $i++;
    }
    if $i > $s.pos and $i < $s.n and $s.ch[$i] eq '#' and
       $base >= 2 and $base <= 64 {
        $s.pos = $i + 1;
        my $digits = q{};
        while $s.pos < $s.n {
            my $x = $s.ch[$s.pos];
            last if $x eq ' ' or $x eq "\t" or $x eq ')' or $x eq '+' or
                $x eq '-' or $x eq '*' or $x eq '/' or $x eq '%';
            $digits ~= $x;
            $s.pos = $s.pos + 1;
        }
        return str-to-int-base($digits, $base);
    }

    # `0x` / `0X`
    if $s.ch[$s.pos] eq '0' and $s.pos + 1 < $s.n {
        my $n2 = $s.ch[$s.pos + 1];
        if $n2 eq 'x' or $n2 eq 'X' {
            $s.pos = $s.pos + 2;
            my $digits = q{};
            while $s.pos < $s.n {
                my $x = $s.ch[$s.pos];
                last unless is-hex-digit($x);
                $digits ~= $x;
                $s.pos = $s.pos + 1;
            }
            return str-to-int-base($digits, 16);
        }
    }

    # 普通十进制（`0` 开头按**八进制** —— bash 语义）
    my $digits = q{};
    while $s.pos < $s.n {
        my $x = $s.ch[$s.pos];
        last unless $x ge '0' and $x le '9';
        $digits ~= $x;
        $s.pos = $s.pos + 1;
    }
    if $digits.chars > 1 and $digits.substr(0, 1) eq '0' {
        return str-to-int-base($digits, 8);
    }
    str-to-int-base($digits, 10)
}

# 变量的值（没设置 → 0）
sub var-value(ArithState $s, Str $name --> Int) {
    my $raw = lookup($name, $s.over);
    my $v = 0;
    $v = $raw.Int if $raw.chars;
    $v
}

# ── 文法（递归下降，从松到紧）──────────────────────────────────
#
# 每一层一个 sub，层与层之间是**单向**调用（不互相递归），
# 只有 `power` 自己调自己（右结合）。

# 最松：逗号运算符（取最后一个值）
sub parse-comma(ArithState $s --> Int) {
    my $v = parse-assign($s);
    while True {
        skip-ws($s);
        last unless eat($s, ',');
        $v = parse-assign($s);
    }
    $v
}

# 赋值（**右结合**）
#
# ⚠⚠ 赋值必须**先**认出来，再去解析右操作数 ——
#   否则 `X+=2` 里的 `+` 会被**加法层**吃掉（加法层的优先级比赋值紧），
#   解析到 `=` 时已经是「语法错误」了（实测：`$((X+=2))` 得出 0，
#   而 bash 是 5）。
#
# → 所以先**前瞻**：当前位置是「变量名 + 赋值运算符」吗？
#   是 → 直接按赋值处理（右操作数递归用本层 ⇒ 右结合）；
#   否 → 退回普通的表达式解析。
sub parse-assign(ArithState $s --> Int) {
    skip-ws($s);
    my $start = $s.pos;

    my $name = peek-var-name($s);
    if $name ne q{} {
        # ⚠ peek-var-name **已经把位置移到变量名之后**了 ——
        #   赋值运算符就在那儿（`X+=2` 的 `+=`）。
        skip-ws($s);
        my $op = assign-op($s);
        if $op ne q{} {
            $s.pos = $s.pos + $op.chars;
            my $right = parse-assign($s);        # 右结合
            $s.var = $name;
            my $old = var-value($s, $name);
            return apply-assign($s, $op, $old, $right);
        }
    }
    # 不是赋值 → 位置复原，走普通表达式
    $s.pos = $start;
    my $left = parse-ternary($s);
    skip-ws($s);
    my $op = assign-op($s);
    return $left if $op eq q{};
    $s.pos = $s.pos + $op.chars;
    my $right = parse-assign($s);
    apply-assign($s, $op, $left, $right)
}

# 前瞻一个变量名：`$X` 或裸名字 `X`。
# 不是变量名 → 返回空串。
#
# ⚠ **位置会前移到变量名之后**（调用方负责在「不是赋值」时复原）。
sub peek-var-name(ArithState $s --> Str) {
    my $name = q{};
    if $s.pos < $s.n and $s.ch[$s.pos] eq '$' {
        $s.pos = $s.pos + 1;
        if $s.pos < $s.n and $s.ch[$s.pos] eq '{' {
            $s.pos = $s.pos + 1;
            while $s.pos < $s.n and $s.ch[$s.pos] ne '}' {
                $name ~= $s.ch[$s.pos];
                $s.pos = $s.pos + 1;
            }
            $s.pos = $s.pos + 1 if $s.pos < $s.n;
        }
        else {
            while $s.pos < $s.n {
                my $x = $s.ch[$s.pos];
                last unless is-arith-name-char($x);
                $name ~= $x;
                $s.pos = $s.pos + 1;
            }
        }
    }
    elsif $s.pos < $s.n and is-arith-name-char($s.ch[$s.pos]) {
        while $s.pos < $s.n {
            my $x = $s.ch[$s.pos];
            last unless is-arith-name-char($x);
            $name ~= $x;
            $s.pos = $s.pos + 1;
        }
    }
    else {
        return q{};
    }
    $name
}

# 三元（**右结合**）
sub parse-ternary(ArithState $s --> Int) {
    my $c = parse-logical-or($s);
    skip-ws($s);
    return $c unless eat($s, '?');
    my $a = parse-comma($s);
    skip-ws($s);
    eat($s, ':');
    my $b = parse-ternary($s);
    if $c != 0 { return $a }
    return $b
}

sub parse-logical-or(ArithState $s --> Int) {
    my $left = parse-logical-and($s);
    while True {
        skip-ws($s);
        last unless eat-bin($s, '||');
        my $right = parse-logical-and($s);
        $left = (($left != 0) or ($right != 0)) ?? 1 !! 0;
    }
    $left
}

sub parse-logical-and(ArithState $s --> Int) {
    my $left = parse-bit-or($s);
    while True {
        skip-ws($s);
        last unless eat-bin($s, '&&');
        my $right = parse-bit-or($s);
        $left = (($left != 0) and ($right != 0)) ?? 1 !! 0;
    }
    $left
}

sub parse-bit-or(ArithState $s --> Int) {
    my $left = parse-bit-xor($s);
    while True {
        skip-ws($s);
        last unless eat-bin($s, '|');
        my $right = parse-bit-xor($s);
        $left = apply-bin($s, '|', $left, $right);
    }
    $left
}

sub parse-bit-xor(ArithState $s --> Int) {
    my $left = parse-bit-and($s);
    while True {
        skip-ws($s);
        last unless eat-bin($s, '^');
        my $right = parse-bit-and($s);
        $left = apply-bin($s, '^', $left, $right);
    }
    $left
}

sub parse-bit-and(ArithState $s --> Int) {
    my $left = parse-equality($s);
    while True {
        skip-ws($s);
        last unless eat-bin($s, '&');
        my $right = parse-equality($s);
        $left = apply-bin($s, '&', $left, $right);
    }
    $left
}

sub parse-equality(ArithState $s --> Int) {
    my $left = parse-relational($s);
    while True {
        skip-ws($s);
        my $hit = q{};
        if eat-bin($s, '==') { $hit = '==' }
        elsif eat-bin($s, '!=') { $hit = '!=' }
        last if $hit eq q{};
        my $right = parse-relational($s);
        $left = apply-bin($s, $hit, $left, $right);
    }
    $left
}

sub parse-relational(ArithState $s --> Int) {
    my $left = parse-shift($s);
    while True {
        skip-ws($s);
        my $hit = q{};
        if eat-bin($s, '<=') { $hit = '<=' }
        elsif eat-bin($s, '>=') { $hit = '>=' }
        elsif eat-bin($s, '<') { $hit = '<' }
        elsif eat-bin($s, '>') { $hit = '>' }
        last if $hit eq q{};
        my $right = parse-shift($s);
        $left = apply-bin($s, $hit, $left, $right);
    }
    $left
}

sub parse-shift(ArithState $s --> Int) {
    my $left = parse-additive($s);
    while True {
        skip-ws($s);
        my $hit = q{};
        if eat-bin($s, '<<') { $hit = '<<' }
        elsif eat-bin($s, '>>') { $hit = '>>' }
        last if $hit eq q{};
        my $right = parse-additive($s);
        $left = apply-bin($s, $hit, $left, $right);
    }
    $left
}

sub parse-additive(ArithState $s --> Int) {
    my $left = parse-multiplicative($s);
    while True {
        skip-ws($s);
        my $hit = q{};
        if eat-bin($s, '+') { $hit = '+' }
        elsif eat-bin($s, '-') { $hit = '-' }
        last if $hit eq q{};
        my $right = parse-multiplicative($s);
        $left = apply-bin($s, $hit, $left, $right);
    }
    $left
}

sub parse-multiplicative(ArithState $s --> Int) {
    my $left = parse-power($s);
    while True {
        skip-ws($s);
        my $hit = q{};
        if eat-bin($s, '*') { $hit = '*' }
        elsif eat-bin($s, '/') { $hit = '/' }
        elsif eat-bin($s, '%') { $hit = '%' }
        last if $hit eq q{};
        my $right = parse-power($s);
        $left = apply-bin($s, $hit, $left, $right);
    }
    $left
}

# `**`（**右结合**，且比一元运算符**更松** —— 见文件头的实测记录）
sub parse-power(ArithState $s --> Int) {
    my $base = parse-unary($s);
    skip-ws($s);
    return $base unless eat($s, '**');
    my $e = parse-power($s);
    # bash 对负指数报错（"exponent less than 0"）；我们不崩，返回 0
    return 0 if $e < 0;
    $base ** $e
}

# 一元运算符：`!` `~` `-` `+`
sub parse-unary(ArithState $s --> Int) {
    skip-ws($s);
    if eat($s, '!') {
        my $v = parse-unary($s);
        return $v == 0 ?? 1 !! 0;
    }
    if eat($s, '~') {
        my $v = parse-unary($s);
        # ⚠ Raku 的 `~` 是**字符串取反**，位取反要用 `+^`（见文件头）
        return +^ $v;
    }
    if eat($s, '-') {
        my $v = parse-unary($s);
        return -$v;
    }
    if eat($s, '+') {
        return parse-unary($s);
    }
    parse-primary($s)
}

# 基本项：数字 / 变量 / 括号
sub parse-primary(ArithState $s --> Int) {
    skip-ws($s);
    if $s.pos >= $s.n {
        $s.bad = True;
        return 0;
    }
    my $c = peek($s);

    # 括号
    if $c eq '(' {
        $s.pos = $s.pos + 1;
        my $v = parse-comma($s);
        skip-ws($s);
        eat($s, ')');
        return $v;
    }

    # `$NAME` / `${NAME}`
    if $c eq '$' {
        $s.pos = $s.pos + 1;
        return parse-var-name($s);
    }

    # 数字
    if $c ge '0' and $c le '9' {
        return parse-number($s);
    }

    # 裸名字（bash 里 `X` 也是变量）
    if is-arith-name-char($c) {
        return parse-var-name($s);
    }

    # 认不出来 → 吃掉一个字符（避免死循环），标记为语法错误
    $s.bad = True;
    $s.pos = $s.pos + 1;
    0
}

# 读一个变量名（`$` 已经被吃掉了）
sub parse-var-name(ArithState $s --> Int) {
    my $name = q{};
    if $s.pos < $s.n and $s.ch[$s.pos] eq '{' {
        $s.pos = $s.pos + 1;
        while $s.pos < $s.n and $s.ch[$s.pos] ne '}' {
            $name ~= $s.ch[$s.pos];
            $s.pos = $s.pos + 1;
        }
        eat($s, '}');
    }
    else {
        while $s.pos < $s.n {
            my $x = $s.ch[$s.pos];
            last unless is-arith-name-char($x);
            $name ~= $x;
            $s.pos = $s.pos + 1;
        }
    }
    $s.var = $name;
    var-value($s, $name)
}

# ── 算术求值 ────────────────────────────────────────────────────
#
# `$over` = 会话变量表（预扫描时是**影子表**，见 Exec 的两遍扫描）：
# 变量取值走它 → `%*ENV` 的回退链，赋值落到**真表**。
#
# 解析失败（语法错误 / 未知的字符）时返回 0（bash 会报错，我们不崩）。
#
# `@err` = **输出参数**（错误信息；没有错就是空串）。
#
# ⚠ 为什么用「数组当输出参数」而不是返回值：
#   Raku 的 sub 形参默认**不可变**，标量形参改了调用方看不见
#   （`my $x = 0; f($x)` 里 f 改 $x 无效），而数组是**可变容器**、
#   按引用传递 —— 这是本项目传输出参数的标准做法
#   （见 Expand::expand-dollar-frags 的 `@adv`）。
our sub eval-arith(Str $expr, Hash $over = Hash.new, @err = @ --> Int) is export {
    my @ch = $expr.comb;
    my $st = ArithState.new(:ch(@ch), :n(@ch.elems), :over($over));
    my $v = parse-comma($st);
    # 运行时错误（除零）⇒ 错误信息交出去（bash 会中止命令）
    if $st.err ne q{} {
        @err[0] = $st.err;
        return 0;
    }
    # 语法错误 → 整体作废（bash 会报错「arithmetic syntax error」，
    # 我们不崩，但也不能返回「错误发生前算出的那一半」）
    return 0 if $st.bad;
    $v
}
