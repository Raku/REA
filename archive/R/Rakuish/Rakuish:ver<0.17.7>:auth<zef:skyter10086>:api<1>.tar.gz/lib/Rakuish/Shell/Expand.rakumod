unit module Rakuish::Shell::Expand;

use Rakuish::Shell::Lexer;
use Rakuish::Shell::Session;
use Rakuish::Shell::Arith;

# Rakuish::Shell::Expand —— 外壳层展开（shell-design §4.3）
#
# 移植自 v/shell_expand.v（V 版 194 行），并在 2026-11 这一轮**重写**了
# 内部模型（见下面的「为什么是片段模型」）。
#
# ── 为什么是片段模型 ──────────────────────────────────────────────
# 一次展开的结果**不是一个字符串**，而是**一串片段** —— 每个片段带着
# 「它来自哪种上下文」。bash 的两条规则都依赖这个信息：
#
#   · **分词**（word splitting）：只有**裸位置**的展开结果里的空白才切词。
#       X='a b'; echo $X   → 两个参数（bash）
#       echo "$X"          → 一个参数
#   · **glob**：只有**裸位置**的 `*` / `?` / `[` 才是模式。
#       X='*'; echo $X     → 展开成文件名（bash）
#       echo "$X"          → 字面量 `*`
#
# 旧模型只产出一个字符串，于是「引号内的元字符」与「变量展开出来的元字符」
# 这两种情况**分不开** —— 只能靠「原始词里有没有裸位置的 `*`」这种粗判据，
# 结果是 `echo $VAR`（VAR='*.txt'）不 glob，而 bash 会 glob。
#
# ── 与 V 版的两处实质差异 ──────────────────────────────────────────
# ① **引号感知必须一步到位**（V 版已修对，本版保持）。
#    正确顺序是「按上下文展开 + 同时剥引号」；若拆成「先剥壳、再展开」，
#    单引号上下文就丢了 —— `echo 'a $B'` 会被错误展开成 `a <B的值>`
#    （bash 语义：单引号内一切原样，包括反斜杠）。
#    本版用**一个状态机**同时做两件事，天然不可能出现顺序错。
#
# ② **裸模式的反斜杠转义任意字符**（V 版只认一个白名单）。
#    bash 语义：`\` 后面**任何**字符都被转义（`a\bc` = `abc`）。
#    V 版的 `is_escapable` 白名单会让 `a\bc` 变成 `a` + `\bc`（两个词）。
#
# 变量取值走 `%*ENV`（而不是 V 版的 `os.getenv`）—— 因为 REPL 的
# 环境变量镜像就在 `%*ENV` 里（shell 变量 → Raku 变量的字符串桥），
# 走 `%*ENV` 才能看到 REPL 里刚 export 的变量。

our $BSL    = chr(92);
our $SQUOTE = chr(39);
our $DQUOTE = chr(34);
our $TICK   = chr(96);
our $DOLLAR = chr(36);

# ── 展开片段 ──────────────────────────────────────────────────────
#
# 字段：
#   text     —— 当前文本。命令替换片段在被求值**之前**存的是原始的
#               `$(...)` / `` `...` `` 文本（求值后换成命令输出）。
#   inert    —— 「被保护」：来自引号内或被反斜杠转义
#               ⇒ 不参与分词、glob 元字符不生效。
#   split    —— 「裸位置的展开结果」（变量 / 命令替换）
#               ⇒ 其中的空白是**分词点**（bash 语义）。
#   is-cmdsub—— 这是一个命令替换片段。
#   inner    —— 命令替换的**内层文本**（`$(` 与 `)` 之间）。
class Frag is export {
    has Str  $.text      = q{};
    has Bool $.inert     = False;
    has Bool $.split     = False;
    has Bool $.is-cmdsub = False;
    has Str  $.inner     = q{};
}

# ── 环境变量取值（未定义 → 空串，与 bash 一致）────────────────────
#
# `$((` 是**算术展开**的开头（`$(` 后面紧跟第二个 `(`）——
# 命令替换与算术展开必须分清，否则 `$((1+2))` 会被当成
# 「跑一条叫 `(1+2)` 的命令」。
our sub is-arith-start(@ch, Int $i, Int $n --> Bool) is export {
    return False if $i + 2 >= $n;
    return False unless @ch[$i] eq $DOLLAR;
    return False unless @ch[$i + 1] eq '(';
    @ch[$i + 2] eq '('
}

#
# 查表顺序：**会话变量优先**，再退到 `%*ENV`。
#
# 为什么会话变量优先（而不是反过来）：会话变量是 REPL 里**显式设置**的
# （`!export FOO=bar`），它是「用户的意思」；而 `%*ENV` 里可能还留着
# 同名的旧值（例如从父进程继承来的）。bash 的语义也是「后设的覆盖先设的」。
#
# 委托给 `Session::get-var` —— 那边是**唯一**的实现
# （两边各写一份的话，改一处忘另一处就会出现「展开层看到了、
# 内建层看不到」这种极难查的不一致）。
our sub env-get(Str $name, Hash $over = Hash.new --> Str) is export {
    lookup($name, $over)
}

# ── `$` 的展开（返回**片段**序列）───────────────────────────────
#
# 为什么返回片段而不是一个字符串：参数展开的**操作数**里可能有引号
# （`${V:-"a b"}` → **一个**词；`${V:-a b}` → **两个**词），
# 这个「引号保护」的信息只能靠片段承载 —— 字符串层表达不了。
#
# `@adv[0]` 写回消耗掉的字符数。
#
# `$mode` = 当前的引号上下文（'bare' / 'double'）：
# 同一个 `${V:-x}` 在两种上下文里语义**不同** ——
#   裸位置  `${V:-"a b"}` → 引号生效 → 1 个词 `a b`
#   双引号内 `${V:-"a b"}` → 引号是**字面量** → 1 个词 `"a b"`（实测 bash）
our sub expand-dollar-frags(Str $s, Int $i, @adv, Hash $over = Hash.new,
                           Str $mode = 'bare') is export {
    my @out;
    my $n = $s.chars;
    @adv[0] = 1;
    return (Frag.new(:text('$')),) if $i + 1 >= $n;

    my $nx = $s.substr($i + 1, 1);

    # ── `$((...))` 算术展开 ────────────────────────────────────
    #
    # ⚠ 必须**先于** `$(` 判断：`$(` 后面紧跟第二个 `(` 才是算术
    #   （`$( (echo a) )` 是命令替换 —— 括号前面有空格）。
    if $nx eq '(' and $i + 2 < $n and $s.substr($i + 2, 1) eq '(' {
        my $end = find-arith-end($s, $i);
        if $end >= 0 {
            # ⚠ 长度是 `$end - $i - 4`：表达式夹在「第二个 `(`」与
            #   「**第一个** `)`」之间，而 `$end` 指的是**第二个** `)`
            #   （`find-arith-end` 的返回值）—— 差 1 个字符。
            #   （写错的话表达式里会多带一个 `)`：求值结果碰巧还对
            #     ——尾部多出的 `)` 被忽略——但**报错信息**会难看：
            #     `1/0): division by zero`。）
            my $expr = $s.substr($i + 3, $end - $i - 4);
            @adv[0] = $end - $i + 1;
            my @err;
            my $v = eval-arith($expr, $over, @err).Str;
            # ⚠ 除零：bash 报错并**中止**这条命令（`$((1/0))` → 空输出 + 错误）
            if @err.elems and @err[0] ne q{} {
                diag-push($expr ~ ': ' ~ @err[0], :fatal(True));
                return (mk-frag(q{}, $mode),);
            }
            return (mk-frag($v, $mode),);
        }
        return (Frag.new(:text('$((')),);
    }

    # ── `${...}` 参数展开 ──────────────────────────────────────
    if $nx eq '{' {
        my $end = brace-match-end($s, $i + 1);
        if $end >= 0 {
            my $content = $s.substr($i + 2, $end - $i - 2);
            @adv[0] = $end - $i + 1;
            return param-frags($content, $over, $mode);
        }
        return (Frag.new(:text('${')),);      # 没闭合 → 当字面量
    }

    # ── `$?` —— 上一条命令的退出码（会话状态，见 Session）─────
    #
    # bash 语义：`$?` 在**双引号内也展开**（`echo "$?"` → 0），
    # 且**不分词**（它是数字，本来也没有空白）。
    if $nx eq '?' {
        @adv[0] = 2;
        return (mk-frag(last-status().Str, $mode),);
    }

    # ── `$$` —— shell 的 PID（Rakuish 进程自己的 PID，会话内恒定）──
    if $nx eq '$' {
        @adv[0] = 2;
        return (mk-frag(shell-pid().Str, $mode),);
    }

    # ── `$VAR` ─────────────────────────────────────────────────
    if is-name-char($nx) {
        my $j = $i + 1;
        my $name = q{};
        while $j < $s.chars {
            my $c = $s.substr($j, 1);
            last unless is-name-char($c);
            $name ~= $c;
            $j++;
        }
        @adv[0] = $j - $i;
        return (mk-frag(env-get($name, $over), $mode),);
    }

    (Frag.new(:text('$')),)                # 落单的 $ → 字面量
}

# 按上下文造一个「展开结果」片段：
#   裸位置  → split（结果里的空白是**分词点**）
#   双引号内 → inert（不分词、glob 不生效）
sub mk-frag(Str $text, Str $mode --> Frag) {
    if $mode eq 'double' {
        return Frag.new(:text($text), :inert(True));
    }
    Frag.new(:text($text), :split(True))
}

# ── 兼容入口：只取展开结果的**文本** ────────────────────────────
#
# 旧的 `expand-var-at` 只返回字符串 —— 参数展开需要片段（引号保护），
# 所以真正的实现搬到了 `expand-dollar-frags`。
# 这个包装保留给只需要文本的调用方。
our sub expand-var-at(Str $s, Int $i, @adv, Hash $over = Hash.new --> Str) is export {
    my @frags = expand-dollar-frags($s, $i, @adv, $over, 'bare');
    frag-text(@frags)
}

# ══════════════════════════════════════════════════════════════════════
# 参数展开 `${...}`（bash 语义）
# ══════════════════════════════════════════════════════════════════════
#
# 算子表在 **Lexer::parse-param-spec** 里（词法层要靠它判断
# 「这个写法我们认不认识」→ 不认识就整行判不支持）。
# 这里只管**语义**。
#
# 两条贯穿全局的规则：
#
# ① **「没设置」与「设置成空」是两件事**（Session::is-set）。
#    `:-(冒号)` 那一族看的是「没设置**或**为空」，不带冒号的看「没设置」。
#      unset V; ${V:-d} → d      V=; ${V:-d} → d      V=; ${V-d} → 空
#
# ② **操作数在当前引号上下文里展开**（引号保护要能传下去）。
#      裸位置  ${V:-"a b"} → 1 个词 `a b`（引号生效）
#      双引号内 ${V:-"a b"} → 1 个词 `"a b"`（引号是字面量，实测 bash）

# 展开一个 `${...}`（`$content` = `${` 与 `}` 之间的内容）。
our sub param-frags(Str $content, Hash $over = Hash.new, Str $mode = 'bare') is export {
    my $spec = parse-param-spec($content);
    my $name = $spec.name;
    my $op = $spec.op;

    # `${#VAR}` —— 长度（字符数）
    if $op eq 'len' {
        my $v = lookup($name, $over);
        return (mk-frag($v.chars.Str, $mode),);
    }

    my $set = is-set($name, $over);
    my $val = lookup($name, $over);
    my $blank = ($val eq q{});

    # 纯 `${VAR}`
    if $op eq q{} {
        return (mk-frag($val, $mode),);
    }

    # ── `:?` / `?` —— 未设置（或为空）时报错 ────────────────────
    #
    # bash 会**中止 shell**；我们是 REPL，不该中止整个会话 ⇒
    # 报错 + **中止这一条命令**（执行层看 `diag-has-fatal()`），
    # 展开结果为空串（bash 里这一条命令根本不执行 ⇒ stdout 是空的）。
    # ⚠ 报错信息走**诊断队列**（不是直接打印）：一行会被扫两遍
    #   （预扫描 + 执行遍），直接打印会打两遍。
    if $op eq ':?' or $op eq '?' {
        my $bad = ($op eq ':?') ?? (not $set or $blank) !! (not $set);
        if $bad {
            my $msg = $spec.operand;
            $msg = 'parameter null or not set' if $msg.chars == 0;
            diag-push($name ~ ': ' ~ $msg, :fatal(True));
            return (mk-frag(q{}, $mode),);
        }
        return (mk-frag($val, $mode),);
    }

    # ── `:=` / `=` —— 未设置（或为空）时**赋值** ─────────────────
    if $op eq ':=' or $op eq '=' {
        my $use = ($op eq ':=') ?? (not $set or $blank) !! (not $set);
        return (mk-frag($val, $mode),) if not $use;
        my @frags = expand-operand($spec.operand, $over, $mode);
        my $text = frag-text(@frags);
        set-var($name, $text);
        # 影子表里也有这个变量时一并更新（预扫描的一致性）
        if $over.EXISTS-KEY($name) {
            $over{$name} = $text;
        }
        return @frags;
    }

    # ── `:+` / `+` —— 设置了（且非空）→ 用操作数 ────────────────
    if $op eq ':+' or $op eq '+' {
        my $use = ($op eq ':+') ?? ($set and not $blank) !! $set;
        return (mk-frag(q{}, $mode),) if not $use;
        return expand-operand($spec.operand, $over, $mode);
    }

    # ── `:-` / `-` —— 未设置（或为空）→ 用操作数 ────────────────
    if $op eq ':-' or $op eq '-' {
        my $use = ($op eq ':-') ?? (not $set or $blank) !! (not $set);
        return (mk-frag($val, $mode),) if not $use;
        return expand-operand($spec.operand, $over, $mode);
    }

    # ── `#` `##` `%` `%%` —— 删前缀 / 后缀 ─────────────────────
    if $op eq '#' or $op eq '##' or $op eq '%' or $op eq '%%' {
        my $pat = expand-pattern($spec.operand, $over, $mode);
        return (mk-frag(strip-affix($val, $pat, $op), $mode),);
    }

    # ── `/` `//` `/#` `/%` —— 替换 ──────────────────────────────
    if $op eq '/' or $op eq '//' or $op eq '/#' or $op eq '/%' {
        my ($pat, $repl) = split-slash($spec.operand);
        my $pat-str = expand-pattern($pat, $over, $mode);
        my $repl-text = frag-text(expand-operands-text($repl, $over, $mode));
        return (mk-frag(replace-affix($val, $pat-str, $repl-text, $op), $mode),);
    }

    # ── `^` `^^` `,` `,,` —— 大小写转换 ─────────────────────────
    if $op eq '^' or $op eq '^^' or $op eq ',' or $op eq ',,' {
        my $all = ($op eq '^^' or $op eq ',,');
        my $up = ($op eq '^' or $op eq '^^');
        return (mk-frag(case-convert($val, $all, $up), $mode),);
    }

    # ── `:` —— 截取子串 `${V:off}` / `${V:off:len}` ─────────────
    if $op eq ':' {
        my @parts = split-colon($spec.operand);
        my $len = $val.chars;
        my $off = eval-arith(@parts[0], $over);
        if $off < 0 {
            $off = $len + $off;
            $off = 0 if $off < 0;
        }
        return (mk-frag(q{}, $mode),) if $off > $len;
        if @parts.elems == 1 {
            return (mk-frag($val.substr($off), $mode),);
        }
        my $take = eval-arith(@parts[1], $over);
        if $take < 0 {
            # 负长度 = 「到倒数第几个字符为止」（bash 语义）
            $take = $len - $off + $take;
            $take = 0 if $take < 0;
        }
        return (mk-frag(q{}, $mode),) if $take == 0;
        my $avail = $len - $off;
        $take = $avail if $take > $avail;
        return (mk-frag($val.substr($off, $take), $mode),);
    }

    # 认不出来的算子（词法层通常已经把它交给 sh 了）→ 当普通变量
    (mk-frag($val, $mode),)
}

# ── 操作数的展开 ────────────────────────────────────────────────
#
# 裸位置：操作数展开出来的**字面文本**也要参与分词
#   （`${V:-a b}` → 两个词），但被引号保护的部分不参与。
# 双引号内：全部是 inert（不分词）。
sub expand-operand(Str $operand, Hash $over, Str $mode) {
    my @frags = expand-operands-text($operand, $over, $mode);
    if $mode eq 'double' {
        return @frags;
    }
    my @out;
    for @frags -> $f {
        if $f.inert {
            @out.push: $f;
        }
        else {
            @out.push: Frag.new(:text($f.text), :split(True));
        }
    }
    @out
}

# 操作数按当前上下文展开（`:start-mode` 决定起始的引号上下文）
sub expand-operands-text(Str $operand, Hash $over, Str $mode) {
    if $mode eq 'double' {
        return expand-frags($operand, $over, :start-mode('double'));
    }
    expand-frags($operand, $over)
}

# ── 模式（`#` `##` `%` `%%` `/` `//` …）的展开 ───────────────────
#
# 模式要当成 **glob 模式**用 —— 所以被引号保护的部分里的元字符
# 必须**转义掉**（`${V#"*"}` 的模式是字面的 `*`，不是通配）。
# → 正好复用 `frag-pattern`（它就是干这个的）✓
#
# ⚠⚠ 模式**永远**在「裸位置」展开 ——
#   **外层**的双引号**不**保护模式里的元字符：
#     `"${V#*.}"` 里的 `*` 仍然是通配（实测 bash：→ `b.c`）
#     `"${V//[abc]/X}"` 里的 `[abc]` 仍然是字符类（实测 bash：→ `XXX`）
#   但**操作数自己**的引号**保护**元字符（`${V#"*"}` → 字面的 `*`）。
# → 一律按裸位置展开：引号保护由**操作数内部**的引号决定 ✓
sub expand-pattern(Str $operand, Hash $over, Str $mode --> Str) {
    my @frags = expand-frags($operand, $over);
    frag-pattern(@frags)
}

# ── 删前缀 / 后缀 ──────────────────────────────────────────────
#
# 语义：找**最短**（`#` / `%`）或**最长**（`##` / `%%`）的、
# 能被模式**整个匹配**的前缀 / 后缀，然后删掉它。
#
# 例（实测 bash）：
#   V=a/b/c.txt; ${V#*/}  → b/c.txt   （最短前缀 `*/`）
#              ${V##*/} → c.txt    （最长前缀 `*/`）
#              ${V%/*}  → a/b      （最短后缀 `/*`）
#              ${V%%/*} → a        （最长后缀 `/*`）
sub strip-affix(Str $val, Str $pat, Str $op --> Str) {
    my $len = $val.chars;
    my $is-prefix = ($op eq '#' or $op eq '##');
    my $longest = ($op eq '##' or $op eq '%%');
    if $is-prefix {
        if $longest {
            my $l = $len;
            while $l >= 0 {
                return $val.substr($l) if glob-match-exact($val.substr(0, $l), $pat);
                $l--;
            }
        }
        else {
            my $l = 0;
            while $l <= $len {
                return $val.substr($l) if glob-match-exact($val.substr(0, $l), $pat);
                $l++;
            }
        }
    }
    else {
        if $longest {
            my $l = $len;
            while $l >= 0 {
                return $val.substr(0, $len - $l) if glob-match-exact($val.substr($len - $l), $pat);
                $l--;
            }
        }
        else {
            my $l = 0;
            while $l <= $len {
                return $val.substr(0, $len - $l) if glob-match-exact($val.substr($len - $l), $pat);
                $l++;
            }
        }
    }
    $val
}

# ── 替换 ────────────────────────────────────────────────────────
#
#   `/`  替换第一处        `//` 替换所有处
#   `/#` 替换前缀（锚定）  `/%` 替换后缀（锚定）
#
# 替换文本里的 `&` 代表「匹配到的那一段」（bash 语义，实测：
# `V=aaa; ${V/a/&}` → `aaa`）。
sub replace-affix(Str $val, Str $pat, Str $repl, Str $op --> Str) {
    my $len = $val.chars;

    # 前缀锚定
    if $op eq '/#' {
        my $m = glob-match-len($val, 0, $pat, 0);
        return $val if $m <= 0;
        return replace-amp($repl, $val.substr(0, $m)) ~ $val.substr($m);
    }

    # 后缀锚定：找**最长**的、能被模式整个匹配的后缀
    # ⚠ 必须从**最长**往后找（i 从 0 开始）——
    #   `${V/%*/X}`（V=hello）要替换掉**整个**字符串（→ `X`），
    #   而不是最后一个字符（→ `helloX`）。
    if $op eq '/%' {
        my $i = 0;
        while $i <= $len {
            my $tail = $val.substr($i);
            if glob-match-exact($tail, $pat) {
                return $val.substr(0, $i) ~ replace-amp($repl, $tail);
            }
            $i++;
        }
        return $val;
    }

    # 普通替换：找**最左**的匹配（同一位置上取**最长**的匹配）
    #
    # ⚠ 只有**匹配到非空**才算命中：空匹配会让「替换第一处」变成
    #   在末尾插一段（`${V/.*/.md}` 在 "abc.txt" 上会变成 "abc.txt.md" ——
    #   正确答案是 "abc.md"，因为真正匹配的是中间的 ".txt"）。
    my $all = ($op eq '//');
    my $out = q{};
    my $i = 0;
    my $guard = 0;
    while $i <= $len {
        $guard++;
        last if $guard > 10000;      # 死循环保险
        my $m = glob-match-len($val, $i, $pat, 0);
        if $m > 0 {
            my $matched = $val.substr($i, $m);
            # 匹配到的那一段被**替换掉**（不是保留）
            $out ~= replace-amp($repl, $matched);
            $i = $i + $m;
            if not $all {
                # 只替换第一处 → 剩下的原样
                return $out ~ $val.substr($i);
            }
            next;
        }
        # 没匹配上（或只匹配了空串）→ 原样吐一个字符，继续找
        $out ~= $val.substr($i, 1);
        $i++;
    }
    $out
}

# 替换文本里的 `&` → 匹配到的那一段
sub replace-amp(Str $repl, Str $matched --> Str) {
    return $repl unless $repl.contains('&');
    my @out;
    for $repl.comb -> $c {
        if $c eq '&' { @out.push: $matched }
        else { @out.push: $c }
    }
    @out.join
}

# ── 大小写转换 ──────────────────────────────────────────────────
#
#   `^`  首字符转大写      `^^` 全部转大写
#   `,`  首字符转小写      `,,` 全部转小写
sub case-convert(Str $val, Bool $all, Bool $up --> Str) {
    return q{} if $val.chars == 0;
    if $all {
        return $up ?? $val.uc !! $val.lc;
    }
    my $head = $val.substr(0, 1);
    my $tail = $val.substr(1);
    my $h = $up ?? $head.uc !! $head.lc;
    $h ~ $tail
}

# ── `pat/repl` 按**第一个没被引号保护的** `/` 切开 ───────────────
#
# （bash 语义：`${V/a/b/c}` 的模式是 `a`，替换是 `b/c`）
sub split-slash(Str $s) {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = 0;
    my $mode = 'bare';
    while $i < $n {
        my $c = @ch[$i];
        if $mode eq 'single' {
            $mode = 'bare' if $c eq $SQUOTE;
            $i++;
            next;
        }
        if $mode eq 'double' {
            if $c eq $BSL and $i + 1 < $n { $i += 2; next }
            if $c eq $DQUOTE { $mode = 'bare'; $i++; next }
            $i++;
            next;
        }
        if $c eq $BSL and $i + 1 < $n { $i += 2; next }
        if $c eq $SQUOTE { $mode = 'single'; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $i++; next }
        if $c eq '/' {
            return ($s.substr(0, $i), $s.substr($i + 1));
        }
        $i++;
    }
    ($s, q{})
}

# ── `${V:off:len}` 的操作数按**第一个** `:` 切开 ────────────────
sub split-colon(Str $s) {
    my $p = $s.index(':') // -1;
    if $p < 0 {
        return ($s,);
    }
    ($s.substr(0, $p), $s.substr($p + 1))
}

# ── 诊断信息（`${V:?msg}` 的报错）──────────────────────────────
#
# 为什么不在展开时直接打印：
#   一行会被扫**两遍**（预扫描 + 执行遍，见 Exec 的两遍扫描），
#   直接打印会打**两遍**。
#   → 收集起来，执行完统一打印（Exec 负责 flush）。
#   交 sh 的那条路（**已删**）要把收集到的**丢掉**。
our @DIAG = [];

# 「致命」诊断：bash 语义里这两种错误会**中止整条命令**：
#
#   `${V:?msg}`   —— V 未设置或为空（bash 报 "V: msg" 并**中止**）
#   `$((1/0))`    —— 除零（bash 报 "division by 0" 并**中止**）
#
# ⚠ 中止的是**当前这条命令**，不是整个 shell
#   （bash 的交互式行为：报错后回到提示符，shell 还活着）。
our Bool $DIAG-FATAL = False;

our sub diag-push(Str $msg, Bool :$fatal = False) is export {
    # ⚠⚠ **「致命」标记必须在去重的提前返回**之前**设置**！
    #
    # 为什么：一行会被扫**两遍**（预扫描 + 执行遍），同一个错误会
    # `diag-push` 两次（消息文本一样 ⇒ 第二次被去重挡掉）。
    # 如果标志放在去重之后设置 ⇒ **第二次不会置标志** ⇒
    # 执行遍看不到「致命」⇒ 不中止 ⇒ bash 的语义丢了
    # （实测：`echo "[${V:?msg}]"` 照样打印了 `[]`）。
    $DIAG-FATAL = True if $fatal;
    for @DIAG -> $m { return if $m eq $msg }
    @DIAG.push: $msg;
}

# 取走并清空（**返回**消息文本，由调用方决定去哪儿）
#
# ⚠ 为什么不直接打印：捕获模式下诊断信息应该进 `SlowResult.stderr`
#   （这样 `!cmd --numbers` 的行号统计、以及 REPL 的输出顺序都对）；
#   非捕获模式才直接写到 `$*ERR`。
our sub diag-flush() is export {
    my $text = @DIAG.join("\n");
    @DIAG = ();
    $DIAG-FATAL = False;
    $text
}

# 清空但不打印（**已删**的「整行交 sh」那条路用）
our sub diag-clear() is export {
    @DIAG = ();
    $DIAG-FATAL = False;
}

# 有没有「致命」诊断？（执行层据此中止这一行）
our sub diag-has-fatal() is export {
    $DIAG-FATAL
}

# 只重置「致命」标记（消息留着 —— 两遍扫描会重复收集，靠消息去重）
our sub diag-fatal-reset() is export {
    $DIAG-FATAL = False;
}

# ── 老式反引号的转义还原 ──────────────────────────────────────────
#
# bash 的 `` `cmd` `` 里，反斜杠只对 `$` / `` ` `` / `\` 有转义意义
# （bash 会把老式反引号**改写**成 `$(...)` 形式再执行）。
# 我们照做：把这三种转义还原掉，内层文本就等价于 `$(...)` 的写法。
our sub legacy-backtick(Str $s --> Str) is export {
    my @out;
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = 0;
    while $i < $n {
        my $c = @ch[$i];
        if $c eq $BSL and $i + 1 < $n {
            my $nx = @ch[$i + 1];
            if $nx eq '$' or $nx eq $TICK or $nx eq $BSL {
                @out.push: $nx;
                $i += 2;
                next;
            }
            @out.push: $c;
            $i++;
            next;
        }
        @out.push: $c;
        $i++;
    }
    @out.join
}

# ── 合并相邻的同属性字面片段 ──────────────────────────────────────
#
# 逐字符建片段会产生大量碎片（一个 20 字的词 = 20 个对象）。
# 合并后只剩几段，性能差别很明显。
# ⚠ **不能**合并「命令替换」或「展开结果」片段：
#   展开结果片段的空白是分词点，合并进去就丢了。
our sub merge-frags(@frags) is export {
    my @out;
    for @frags -> $f {
        if @out.elems > 0 {
            my $prev = @out[*-1];
            if not $prev.is-cmdsub and not $f.is-cmdsub
            and not $prev.split and not $f.split
            and $prev.inert == $f.inert {
                @out[*-1] = Frag.new(:text($prev.text ~ $f.text), :inert($f.inert));
                next;
            }
        }
        @out.push: $f;
    }
    @out
}

# ── 家目录展开：`~user` ────────────────────────────────────────────
#
# bash 语义：`~name` 展开成**该用户**的家目录（查 `/etc/passwd` 的第 6 段）。
# 用户不存在时 bash 会报错并**原样保留**；我们不报错（只原样保留）——
# 报错是登录 shell 的行为，这里只是命令展开。
#
# 结果**缓存**起来：`/etc/passwd` 不会在进程生命周期里变，
# 而展开每个词都查一遍太浪费。
our %HOME-OF = Hash.new;

our sub home-of(Str $user --> Str) is export {
    return q{} if $user.chars == 0;
    return %HOME-OF{$user} if %HOME-OF.EXISTS-KEY($user);
    my $home = q{};
    my $text = try { slurp('/etc/passwd') };
    if not $! and $text.defined {
        for $text.lines -> $line {
            next unless $line.chars;
            # passwd 格式： name:passwd:uid:gid:gecos:home:shell
            my @f = $line.split(':');
            next if @f.elems < 6;
            next unless @f[0] eq $user;
            $home = @f[5];
            last;
        }
    }
    %HOME-OF{$user} = $home;
    $home
}

# ── 展开一个词 → 片段序列 ─────────────────────────────────────────
#
# bash 规则：
#   单引号内：一切原样（**连反斜杠都不转义**）
#   双引号内：$VAR 展开；`\` 只对 " \ $ ` 四个字符有转义意义
#   裸位置  ：$VAR 展开；`\` 转义任意字符（反斜杠本身被去掉）
#
# 命令替换（`$(...)` 与 `` `...` ``）在这里**只做标记**，不求值 ——
# 求值要**跑命令**，那是执行层的事（Expand 不该有进程副作用）。
# 求值由 `subst-frags` 完成。
our sub expand-frags(Str $s, Hash $over = Hash.new,
                    Bool :$heredoc = False, Str :$start-mode = 'bare') is export {
    my @frags;
    my @ch = $s.comb;          # 逐字符必须 `.comb`（`.chars` 是字符数！见 Lexer 文件头）
    my $n = @ch.elems;
    my $i = 0;
    # `:$heredoc` = 这段文本是 **heredoc 正文**。
    #   bash 语义：正文里的引号是**字面量**（不开启引号上下文），
    #   但变量 / 命令替换照常展开 —— 相当于「整体当双引号，但引号不生效」。
    # `:$start-mode` = 起始的引号上下文。
    #   参数展开的**操作数**要在**当前上下文**里展开
    #   （`"${V:-"a b"}"` 里的引号是字面量，`${V:-"a b"}` 里的引号生效），
    #   所以操作数用这个入口重新展开一遍。
    my $mode = $heredoc ?? 'double' !! $start-mode;

    # ⚠ 0.17.0（§10.2-2）：**引号段是空的时候，要补一个空片段**。
    #
    # 为什么：bash 里 `echo ""` 是**一个空参数**（不是「没有参数」）：
    #   `echo ""` 输出一个空行；`[ -n "" ]` 判定为**假**（非空）。
    # ⚠ 之前引号**本身不产生片段**⇒ `""` 这个词根本不存在
    #   ⇒ 空参数被**静默丢掉**。后果：`[ -n "" ]` 变成 `[ -n ]`
    #   → 单参数测试「非空字符串 -n」⇒ **恒为真**（bash 是假）。
    #   这是**静默分歧**（两边都「成功」，结果不一样）。
    #
    # 判据：进入引号段时记下片段数；退出时若**一片段都没产生**
    #   ⇒ 这是一个**显式的空引号参数**⇒ 补一个空片段。
    # ⚠ `"$EMPTY"` 只产生**一个空文本**片段（变量为空）——那也是空参数，应保留。
    my $q-start = -1;

    while $i < $n {
        my $c = @ch[$i];

        # ── 单引号段 ──────────────────────────────────────────────
        if $mode eq 'single' {
            if $c eq $SQUOTE {
                # ⚠ 0.17.0（§10.2-2）：引号段是空的时候补一个空片段（见文件头备注）
                @frags.push: Frag.new(:text(q{}), :inert(True)) if @frags.elems == $q-start;
                $mode = 'bare';
            }
            else { @frags.push: Frag.new(:text($c), :inert(True)) }
            $i++;
            next;
        }

        # ── 双引号段 ──────────────────────────────────────────────
        if $mode eq 'double' {
            if $c eq $DQUOTE {
                # heredoc 正文里，引号是**字面量**（bash：正文不是引号上下文）
                if $heredoc {
                    @frags.push: Frag.new(:text($c), :inert(True));
                    $i++;
                    next;
                }
                # ⚠ 0.17.0：空双引号也是**一个空参数**（见文件头备注）
                @frags.push: Frag.new(:text(q{}), :inert(True)) if @frags.elems == $q-start;
                $mode = 'bare';
                $i++;
                next;
            }
            if $c eq $BSL and $i + 1 < $n {
                my $nx = @ch[$i + 1];
                # heredoc 正文里 `\` + 换行 = **续行**（换行被吃掉）
                if $heredoc and $nx eq "\n" {
                    $i += 2;
                    next;
                }
                # bash：双引号内反斜杠只对 " \ $ ` 有转义意义，
                # 其余情况反斜杠**保留**（`\n` 在双引号里就是 `\n` 两个字符）
                if $nx eq $DQUOTE or $nx eq $BSL or $nx eq '$' or $nx eq $TICK {
                    @frags.push: Frag.new(:text($nx), :inert(True));
                }
                else {
                    @frags.push: Frag.new(:text($BSL ~ $nx), :inert(True));
                }
                $i += 2;
                next;
            }
            if $c eq $DOLLAR {
                # 命令替换（双引号内）：整块取出，不切词、不 glob
                # ⚠ `$((...))` 是**算术**展开，不是命令替换 —— 必须先排除掉，
                #   否则 `$(` 那条路会把 `$((1+2))` 当成「跑一条叫 `(1+2)` 的命令」。
                if not is-arith-start(@ch, $i, $n) {
                    if $i + 1 < $n and @ch[$i + 1] eq '(' {
                        my $end = find-cmdsub-end($s, $i + 1);
                        if $end >= 0 {
                            my $whole = $s.substr($i, $end - $i + 1);
                            my $inner = $s.substr($i + 2, $end - $i - 2);
                            @frags.push: Frag.new(:text($whole), :inert(True),
                                                  :is-cmdsub(True), :inner($inner));
                            $i = $end + 1;
                            next;
                        }
                    }
                }
                # 变量 / 参数展开 / 算术展开：双引号内**不分词、glob 不生效**
                my @adv = 0;
                my @vs = expand-dollar-frags($s, $i, @adv, $over, 'double');
                # ⚠ 用 `append` 而不是 `push:` ——
                #   `@a.push: @b` 在 Raku 里会把 @b 当成**一个**数组元素推进去
                #   （实测：`@a.push: @b` → @a.elems == 1），
                #   于是后面 `@frags[0].is-cmdsub` 会报
                #   "No such method 'is-cmdsub' for invocant of type 'Array'"。
                @frags.append(@vs);
                $i += @adv[0];
                next;
            }
            if $c eq $TICK {
                my $end = find-backtick-end($s, $i);
                if $end >= 0 {
                    my $whole = $s.substr($i, $end - $i + 1);
                    my $inner = legacy-backtick($s.substr($i + 1, $end - $i - 1));
                    @frags.push: Frag.new(:text($whole), :inert(True),
                                          :is-cmdsub(True), :inner($inner));
                    $i = $end + 1;
                    next;
                }
                @frags.push: Frag.new(:text($c), :inert(True));
                $i++;
                next;
            }
            @frags.push: Frag.new(:text($c), :inert(True));
            $i++;
            next;
        }

        # ── 裸位置 ────────────────────────────────────────────────
        # 词首的 ~ / ~/ / ~user → 家目录展开（bash 语义）。
        # 必须在**裸位置**才做：引号里的 `~` 是字面量。
        if $i == 0 and $c eq '~' {
            my $home = env-get('HOME', $over);
            if $i + 1 >= $n {
                @frags.push: Frag.new(:text($home));
                $i++;
                next;
            }
            if @ch[$i + 1] eq '/' {
                @frags.push: Frag.new(:text($home ~ '/'));
                $i += 2;
                next;
            }
            # `~user` → 查 /etc/passwd
            if is-name-char(@ch[$i + 1]) {
                my $j = $i + 1;
                my $user = q{};
                while $j < $n and is-name-char(@ch[$j]) {
                    $user ~= @ch[$j];
                    $j++;
                }
                my $uh = home-of($user);
                if $uh.chars {
                    my $text = $uh;
                    if $j < $n and @ch[$j] eq '/' {
                        $text ~= '/';
                        $j++;
                    }
                    @frags.push: Frag.new(:text($text));
                    $i = $j;
                    next;
                }
                # 用户不存在 → **原样保留**（bash 会报错；我们不报错）
            }
        }
        if $c eq $SQUOTE { $mode = 'single'; $q-start = @frags.elems; $i++; next }
        if $c eq $DQUOTE { $mode = 'double'; $q-start = @frags.elems; $i++; next }
        if $c eq $BSL and $i + 1 < $n {
            # bash：裸位置反斜杠转义**任意**字符，反斜杠本身去掉。
            # 被转义的字符是「被保护」的 ⇒ glob 不生效（`\*` 不是通配）。
            @frags.push: Frag.new(:text(@ch[$i + 1]), :inert(True));
            $i += 2;
            next;
        }
        if $c eq $BSL {
            # 落单的反斜杠（行尾）→ 字面量，且被保护
            @frags.push: Frag.new(:text($BSL), :inert(True));
            $i++;
            next;
        }
        if $c eq $DOLLAR {
            # 命令替换（裸位置）：整块取出；**分词**与 **glob** 都生效
            # ⚠ `$((...))` 是**算术**展开，不是命令替换 —— 必须先排除掉
            #   （否则 `$(` 那条路会把 `$((1+2))` 当成「跑一条叫 `(1+2)` 的命令」）。
            if not is-arith-start(@ch, $i, $n) {
                if $i + 1 < $n and @ch[$i + 1] eq '(' {
                    my $end = find-cmdsub-end($s, $i + 1);
                    if $end >= 0 {
                        my $whole = $s.substr($i, $end - $i + 1);
                        my $inner = $s.substr($i + 2, $end - $i - 2);
                        @frags.push: Frag.new(:text($whole), :split(True),
                                              :is-cmdsub(True), :inner($inner));
                        $i = $end + 1;
                        next;
                    }
                }
            }
            # 变量 / 参数展开 / 算术展开：裸位置的展开结果 ⇒ 其中的空白是分词点
            my @adv = 0;
            my @vs = expand-dollar-frags($s, $i, @adv, $over, 'bare');
            @frags.append(@vs);      # ⚠ 见上面：不能用 `push:`
            $i += @adv[0];
            next;
        }
        if $c eq $TICK {
            my $end = find-backtick-end($s, $i);
            if $end >= 0 {
                my $whole = $s.substr($i, $end - $i + 1);
                my $inner = legacy-backtick($s.substr($i + 1, $end - $i - 1));
                @frags.push: Frag.new(:text($whole), :split(True),
                                      :is-cmdsub(True), :inner($inner));
                $i = $end + 1;
                next;
            }
        }
        @frags.push: Frag.new(:text($c));
        $i++;
    }

    merge-frags(@frags)
}

# ── 命令替换求值 ──────────────────────────────────────────────────
#
# 把片段里的命令替换片段换成**命令的输出**。
#
# `&subst` 的签名是 `(Str $inner, Str $whole) --> Str`：
#   inner —— `$(` 与 `)` 之间的文本（反引号的话是**还原转义后**的）
#   whole —— 原始的 `$(...)` / `` `...` `` 文本
#
# 为什么要传 whole：默认实现（不求值、原样透传）靠它把原文还原回去，
# 于是「没装求值器」时 `$(echo a)` 仍然是字面量，而不是变成 `echo a`。
our sub default-subst(Str $inner, Str $whole --> Str) is export {
    $whole
}

our sub subst-frags(@frags, &subst = &default-subst) is export {
    my @out;
    for @frags -> $f {
        if $f.is-cmdsub {
            my $v = &subst($f.inner, $f.text);
            $v = q{} unless $v.defined;
            @out.push: Frag.new(:text($v.Str), :inert($f.inert), :split($f.split));
        }
        else {
            @out.push: $f;
        }
    }
    @out
}

# ── 按 IFS 空白切开 ───────────────────────────────────────────────
#
# bash 默认 IFS = 「空格 + 制表 + 换行」。
# ⚠ **不用正则**（HANDOFF §4.1：两后端的正则语义不一致且会静默分叉）。
our sub split-ws(Str $s) is export {
    my @parts;
    my $cur = q{};
    my $has = False;
    for $s.comb -> $c {
        if $c eq ' ' or $c eq chr(9) or $c eq "\n" {
            if $has { @parts.push: $cur; $cur = q{}; $has = False }
        }
        else {
            $cur ~= $c;
            $has = True;
        }
    }
    if $has { @parts.push: $cur }
    @parts
}

# ── 分词：片段序列 → 词序列 ───────────────────────────────────────
#
# bash 规则：
#   · 只有「裸位置的展开结果」里的空白才切词。
#   · 切出来的空白**消失**（不是替换成空格）。
#   · 一个词如果**整个**由「没有产生任何字符的展开」组成，
#     这个词就被**删除**（bash：`set -- $(echo); echo $#` → 0）。
#
# 例：`x$(echo a b)y` → bash 给两个词：`xa` 与 `by`
#   （展开结果切成 a / b 两段，`x` 贴住 a，`y` 贴住 b）。
our sub split-frags(@frags) is export {
    my @words;
    my @cur;
    my $i = 0;
    my $n = @frags.elems;
    while $i < $n {
        my $f = @frags[$i];
        if $f.split {
            # ── 连续的 split 片段合成**一段文本**再切 ──────────
            #
            # 为什么不能一个片段一个片段地切：
            #   参数展开的操作数会产出**多个相邻**的 split 片段
            #   （`${V:-a b}` → "a" " " "b" 三段），
            #   逐段切的话每段都只有一个非空白段 → 切不出词边界
            #   （结果会是 1 个词 `ab`，而 bash 是 2 个词）。
            # → 先合并成一段文本，再按空白切 ✓
            my $text = q{};
            while $i < $n and @frags[$i].split {
                $text ~= @frags[$i].text;
                $i++;
            }
            my @pieces = split-ws($text);
            # 前导空白 = 「这个词到此为止」（前面那个词结束了）
            # ⚠ 用 `&&` 不用 `and`：**赋值比 `and` 紧**，
            #   `my $lead = $a and $b` 会被解析成 `($lead = $a) and $b`
            #   —— 于是 `$lead` 永远是「前半段的值」，判断全错（实测踩过）。
            my $lead = $text.chars > 0 && is-ws-char($text.substr(0, 1));
            # 结尾空白 = 「这个词到此为止」（后面的是**新**词）
            my $trail = $text.chars > 0 && is-ws-char($text.substr($text.chars - 1, 1));
            if $lead and @cur.elems > 0 {
                my @snap = @cur;
                @words.push: @snap;
                @cur = ();
            }
            my $k = 0;
            for @pieces -> $p {
                if $k > 0 {
                    # ⚠⚠ **必须先拷贝再 push** ——
                    #   Raku 里 `@cur = ()` 是「**清空原数组**」而不是「换一个新数组」
                    #   （实测两个后端一致），而 `push` 存进去的是**数组本身**。
                    #   不拷贝的话后面 `@cur = ()` 会把**已经存好的那个词**也清空，
                    #   症状是所有词都变成最后一个词的内容。
                    my @snap = @cur;
                    @words.push: @snap;
                    @cur = ();
                }
                @cur.push: Frag.new(:text($p), :inert($f.inert));
                $k++;
            }
            if $trail and @cur.elems > 0 {
                my @snap = @cur;
                @words.push: @snap;
                @cur = ();
            }
            next;
        }
        @cur.push: $f;
        $i++;
    }
    # 收尾：一个片段都没有的词 = 「整个词都是空的展开」⇒ 删除
    if @cur.elems > 0 {
        my @snap = @cur;
        @words.push: @snap;
    }
    @words
}

# 是空白字符吗？（bash 的 IFS 默认：空格 / 制表 / 换行）
our sub is-ws-char(Str $c --> Bool) is export {
    $c eq ' ' or $c eq chr(9) or $c eq "\n"
}

# ── 片段 → 文本 / glob 模式 ───────────────────────────────────────

# 片段序列的字面文本（拼接）
our sub frag-text(@frags --> Str) is export {
    my $out = q{};
    for @frags -> $f { $out ~= $f.text }
    $out
}

# 片段序列的 glob 模式。
#
# 「被保护」的片段（引号内 / 转义过）里的元字符要在模式里**转义掉** ——
# 否则 `echo "*.txt"` 会去 glob，而 bash 不会（引号保护）。
# 转义后的模式由 `glob-match` 解释（`\*` = 字面量 `*`）。
our sub frag-pattern(@frags --> Str) is export {
    my $out = q{};
    for @frags -> $f {
        if $f.inert {
            for $f.text.comb -> $c {
                if $c eq '*' or $c eq '?' or $c eq '[' or $c eq $BSL {
                    $out ~= $BSL ~ $c;
                }
                else { $out ~= $c }
            }
        }
        else {
            $out ~= $f.text;
        }
    }
    $out
}

# 片段序列里有没有**未加引号保护**的 glob 元字符？
# 只有这种词才需要走 glob 展开。
our sub frag-has-meta(@frags --> Bool) is export {
    for @frags -> $f {
        next if $f.inert;
        my $t = $f.text;
        return True if $t.contains('*') or $t.contains('?') or $t.contains('[');
    }
    False
}

# ── glob 匹配（不用正则）───────────────────────────────────────────
#
# 支持三种元字符 + 一种转义：
#   `*`      任意长度的任意串
#   `?`      任意一个字符
#   `[...]`  字符类（`a-z` 区间；`!` / `^` 开头表示取反）
#   `\x`     字面量 x（表达「被引号保护 / 被转义」的元字符）
#
# **刻意不用正则**：HANDOFF §4.1 记着两个 Raku 实现在正则上语义不一致且
# **静默给出不同结果**。glob 只是几个元字符，手写匹配器两个实现上必然
# 逐字符一致。
our sub glob-match(Str $name, Str $pat --> Bool) is export {
    glob-match-at($name, 0, $pat, 0)
}

# 「模式能不能**整个**匹配这个字符串」？
# （参数展开的 `#`/`##`/`%`/`%%` 要的就是这个：
#   模式匹配的必须是**前缀 / 后缀的完整一段**，不是「前缀里含一段匹配」。）
#
# ⚠ **不能用**「最长匹配长度 == 字符串长度」来判断 ——
#   模式 `*.` 对字符串 `a.`：最长的匹配是 `a`（1 个字符，`*` 匹配空、
#   `.` 匹配 `.`），但 `*.` **确实**能整个匹配 `a.`（`*` 匹配 `a`）。
#   → 用整串匹配器 `glob-match`（它要求模式与字符串**同时**用完）✓
our sub glob-match-exact(Str $s, Str $pat --> Bool) is export {
    glob-match($s, $pat)
}

# 从 `$ni` 开始，模式 `$pat[$pi..]` 能匹配到的**最长**长度。
# 没有匹配返回 -1。
#
# 为什么需要「最长」而不是「匹配/不匹配」：
#   · 替换（`${V/pat/repl}`）要知道**匹配了多长**，才能切掉那一段；
#   · 同一个位置上 bash 取**最长**的匹配（leftmost-longest）。
#
# 实现：`*` 枚举它吃掉多少个字符（从 0 到字符串末尾），取**最大**的总长。
# （模式很短、字符串也不长，O(n²) 完全可以接受。）
our sub glob-match-len(Str $name, Int $ni, Str $pat, Int $pi --> Int) is export {
    my $nl = $name.chars;
    my $pl = $pat.chars;
    if $pi >= $pl { return 0 }
    my $c = $pat.substr($pi, 1);

    # 转义：下一个字符按字面量比
    if $c eq $BSL {
        return -1 if $ni + 1 >= $pl;
        return -1 if $ni >= $nl;
        return -1 if $name.substr($ni, 1) ne $pat.substr($pi + 1, 1);
        return 1 + glob-match-len($name, $ni + 1, $pat, $pi + 2);
    }

    # `*`：枚举它吃掉的长度，取总长最大的那个
    if $c eq '*' {
        my $best = -1;
        my $k = $ni;
        while $k <= $nl {
            my $r = glob-match-len($name, $k, $pat, $pi + 1);
            if $r >= 0 {
                my $len = ($k - $ni) + $r;
                $best = $len if $len > $best;
            }
            $k++;
        }
        return $best;
    }

    # `?`：正好一个字符
    if $c eq '?' {
        return -1 if $ni >= $nl;
        my $r = glob-match-len($name, $ni + 1, $pat, $pi + 1);
        return -1 if $r < 0;
        return 1 + $r;
    }

    # `[...]`：字符类
    if $c eq '[' {
        my $cls = parse-class($pat, $pi);
        if $cls.defined {
            return -1 if $ni >= $nl;
            my $hit = class-hit($cls.items, $name.substr($ni, 1));
            $hit = !$hit if $cls.negate;
            return -1 unless $hit;
            my $r = glob-match-len($name, $ni + 1, $pat, $cls.next);
            return -1 if $r < 0;
            return 1 + $r;
        }
        # 不是合法字符类 → `[` 按字面量处理（bash 语义）
    }

    # 普通字符
    return -1 if $ni >= $nl;
    return -1 if $name.substr($ni, 1) ne $c;
    my $r = glob-match-len($name, $ni + 1, $pat, $pi + 1);
    return -1 if $r < 0;
    1 + $r
}

sub glob-match-at(Str $name, Int $ni0, Str $pat, Int $pi0 --> Bool) {
    my $nl = $name.chars;
    my $pl = $pat.chars;
    # ⚠ 形参在 Raku 里是**不可变**的 —— `$pi++` 会报
    #   "Cannot resolve caller postfix:<++>(Int:D)"（实测两后端都报）。
    #   所以先拷到局部变量再改。
    my $ni = $ni0;
    my $pi = $pi0;

    while $pi < $pl {
        my $c = $pat.substr($pi, 1);

        # 转义：下一个字符按字面量比
        if $c eq $BSL {
            return False if $pi + 1 >= $pl;
            my $lit = $pat.substr($pi + 1, 1);
            return False if $ni >= $nl or $name.substr($ni, 1) ne $lit;
            $ni++;
            $pi += 2;
            next;
        }

        # `*`：依次尝试「吃 0 个 / 1 个 / …」字符
        if $c eq '*' {
            my $k = $ni;
            while True {
                return True if glob-match-at($name, $k, $pat, $pi + 1);
                last if $k >= $nl;
                $k++;
            }
            return False;
        }

        # `?`：正好一个字符
        if $c eq '?' {
            return False if $ni >= $nl;
            $ni++;
            $pi++;
            next;
        }

        # `[...]`：字符类
        if $c eq '[' {
            my $cls = parse-class($pat, $pi);
            if $cls.defined {
                return False if $ni >= $nl;
                my $hit = class-hit($cls.items, $name.substr($ni, 1));
                $hit = !$hit if $cls.negate;
                return False unless $hit;
                $ni++;
                $pi = $cls.next;
                next;
            }
            # 不是合法字符类 → `[` 按字面量处理（bash 语义）
        }

        # 普通字符
        return False if $ni >= $nl or $name.substr($ni, 1) ne $c;
        $ni++;
        $pi++;
    }

    $ni == $nl
}

# 一个字符类的解析结果。
class GlobClass is export {
    has Array $.items = [];    # 每项：单字符，或 "a-z"（区间）
    has Int   $.next  = 0;     # 字符类结束后的模式下标
    has Bool  $.negate = False;
}

# 解析 `[...]`。返回 Nil 表示**不是**合法字符类（`[` 按字面量）。
our sub parse-class(Str $pat, Int $pi) is export {
    my $pl = $pat.chars;
    my $i = $pi + 1;
    my $negate = False;
    if $i < $pl {
        my $c0 = $pat.substr($i, 1);
        if $c0 eq '!' or $c0 eq '^' { $negate = True; $i++ }
    }
    my @items;
    my $first = True;
    my $closed = False;
    while $i < $pl {
        my $c = $pat.substr($i, 1);
        # `]` 结束字符类 —— 但**第一个**字符不能是 `]`（bash 语义）
        if $c eq ']' and not $first { $i++; $closed = True; last }
        $first = False;
        if $c eq $BSL and $i + 1 < $pl {
            @items.push: $pat.substr($i + 1, 1);
            $i += 2;
            next;
        }
        # 区间 `a-z`
        if $i + 2 < $pl and $pat.substr($i + 1, 1) eq '-' and $pat.substr($i + 2, 1) ne ']' {
            @items.push: $c ~ '-' ~ $pat.substr($i + 2, 1);
            $i += 3;
            next;
        }
        @items.push: $c;
        $i++;
    }
    return Nil unless $closed;
    return Nil if @items.elems == 0;      # 空类不是合法字符类
    my @items-snap = @items;
    GlobClass.new(:items(@items-snap), :next($i), :negate($negate))
}

# 字符是否落在字符类里
sub class-hit(List $items, Str $c --> Bool) {
    my $hit = False;
    for @($items) -> $it {
        if $it.chars == 1 {
            $hit = True if $c eq $it;
        }
        else {
            my $a = $it.substr(0, 1);
            my $b = $it.substr(2, 1);
            $hit = True if $c ge $a and $c le $b;
        }
    }
    $hit
}

# 这个 glob 模式我们**能**处理吗？
#
# 不能的情况：**目录部分**也含未加引号保护的通配（`*/foo`）。
# 我们只 glob 路径的**最后一段**（bash 的 globstar / 递归语义不实现），
# 目录部分带通配的话就得整体判不支持 —— 半懂半猜比不支持更糟。
#
# 字符类 `[abc]` 现在**支持**了（见 glob-match-at），
# 但目录部分里的字符类仍然不支持（目录部分根本不 glob）。
our sub glob-supportable(Str $pattern --> Bool) is export {
    # ⚠ `rindex` 找不到时返回 **Nil**（不是 -1）—— 必须 `// -1` 兜住，
    #   否则 `Nil >= 0` 会报 "Use of uninitialized value"（实测两后端都报）。
    my $idx = $pattern.rindex('/') // -1;
    return True if $idx < 0;
    my $dir = $pattern.substr(0, $idx);
    return False if dir-has-meta($dir);
    True
}

# 目录部分有没有未加引号保护的通配元字符？
sub dir-has-meta(Str $s --> Bool) {
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = 0;
    while $i < $n {
        my $c = @ch[$i];
        if $c eq $BSL { $i += 2; next }
        if $c eq '*' or $c eq '?' or $c eq '[' { return True }
        $i++;
    }
    False
}

# 模式里的转义还原（只用于「隐藏文件规则」的首字符判断）
sub unescape-pattern(Str $s --> Str) {
    my @out;
    my @ch = $s.comb;
    my $n = @ch.elems;
    my $i = 0;
    while $i < $n {
        my $c = @ch[$i];
        if $c eq $BSL and $i + 1 < $n {
            @out.push: @ch[$i + 1];
            $i += 2;
            next;
        }
        @out.push: $c;
        $i++;
    }
    @out.join
}

# ── glob 展开 ──────────────────────────────────────────────────────
# bash 语义：
#   · 无匹配 → **原样保留**（不是报错、也不是空）
#   · 不匹配以 `.` 开头的隐藏文件（除非模式本身以 `.` 开头）
#   · 结果**按字典序**（bash 排序；`dir()` 给的是 readdir 顺序，不排序）
# 注意：**不要写 `--> List`**。容器返回标注跨实现不兼容
# （MoarVM 拒绝 `--> List`，因为实际给的是 Seq；rakupp 拒绝 `--> Seq`）——
# 这是 Slow.rakumod 文件头记过的坑。这里干脆不标返回类型。
#
# `$fallback` = 没匹配上时返回什么。默认是模式本身；
# 片段模型下调用方会传**字面文本**（模式里可能有转义，如 `\*.txt`）。
our sub glob-expand(Str $pattern, Str $fallback = $pattern) is export {
    my $dir;
    my $pat;
    my $prefix;

    # ⚠ 同上：`rindex` 找不到返回 Nil，必须 `// -1`（见 glob-supportable）
    my $idx = $pattern.rindex('/') // -1;
    if $idx >= 0 {
        $dir = $pattern.substr(0, $idx);
        $pat = $pattern.substr($idx + 1);
        $prefix = $dir ~ '/';
        $dir = '.' if $dir eq q{};
    }
    else {
        $dir = '.';
        $pat = $pattern;
        $prefix = q{};
    }

    my @hits;
    my $entries = try { dir($dir) };
    if $entries {
        for @($entries) -> $e {
            # basename **用字符串切**，不用 IO::Path 的方法 ——
            # 实测两个后端的 IO::Path 都**没有** `.name` 方法
            # （MoarVM 与 rakupp 都没有），用了直接报
            # "No such method 'name' for invocant of type 'IO::Path'"。
            my $full = $e.Str;
            my $slash = $full.rindex('/') // -1;   # 找不到返回 Nil → 兜 -1
            my $name = $slash >= 0 ?? $full.substr($slash + 1) !! $full;
            # 隐藏文件规则：模式不以 `.` 开头时，`*` 不匹配点开头的名字
            next if $name.starts-with('.') and not unescape-pattern($pat).starts-with('.');
            next unless glob-match($name, $pat);
            @hits.push: $prefix ~ $name;
        }
    }
    return ($fallback,) if @hits.elems == 0;
    @hits.sort
}

# ── 展开一个词（字符串视图）────────────────────────────────────────
#
# 兼容入口：只做「展开 + 剥引号」，**不**分词、不 glob。
# 命令替换在这里**不求值**（保持原样透传）—— 求值要跑命令，
# 由执行层用 `subst-frags` 显式触发。
our sub expand-arg(Str $s, Hash $over = Hash.new --> Str) is export {
    frag-text(expand-frags($s, $over))
}

# ── 展开一个词 + **求值**命令替换（不分词、不 glob）────────────────
#
# 用于「要一个字符串」的场合：赋值右侧、重定向目标、内建参数。
# 与 `expand-arg` 的区别只在于**命令替换被求值**了。
our sub expand-arg-sub(Str $s, Hash $over = Hash.new, &subst = &default-subst,
                       Bool :$heredoc = False) is export {
    my @frags = expand-frags($s, $over, :heredoc($heredoc));
    @frags = subst-frags(@frags, &subst);
    frag-text(@frags)
}

# ── 展开一整条命令的参数（完整流程）───────────────────────────────
#
# 顺序（bash）：**展开 → 分词 → glob**。
# 旧实现是「按原始词里有没有裸位置的 `*` 决定要不要 glob」——
# 那样 `echo $VAR`（VAR='*.txt'）不会 glob，而 bash 会。
#
# `&subst` 是命令替换的求值器（`(Str $inner, Str $whole) --> Str`）。
# 默认是 `default-subst`（原样透传，不跑命令）。
our sub expand-words(List $args, Hash $over = Hash.new, &subst = &default-subst) is export {
    my @out;
    for @($args) -> $raw {
        my @frags = expand-frags($raw, $over);
        @frags = subst-frags(@frags, &subst);
        for @(split-frags(@frags)) -> $w {
            my $text = frag-text($w);
            if frag-has-meta($w) {
                for @(glob-expand(frag-pattern($w), $text)) -> $g { @out.push: $g }
            }
            else {
                @out.push: $text;
            }
        }
    }
    @out
}

# ── 展开一整条命令的参数（兼容入口）────────────────────────────────
our sub expand-args(List $args, Hash $over = Hash.new) is export {
    expand-words($args, $over, &default-subst)
}

# ══════════════════════════════════════════════════════════════════════
# 特殊参数的位置扫描 —— **已删**（2026-11-05 引擎纯化）
# ══════════════════════════════════════════════════════════════════════
#
# ⚠⚠ 原来这里有 `find-special-in-word`（扫「**没被引号保护**」的 `$?` / `$$`），
#   它只服务于**「整行交 sh」那条路**（`prepare-for-sh` 用它判断
#   「这一行里有没有**真正的** `$?`」，并把 `$$` 换成 PID 字面量）。
#   纯化之后**没有交 sh 这条路了** ⇒ 它成了**死代码** ⇒ 连同
#   `has-dollar-question` / `rewrite-pid-in-word` 一起删掉。
#
#   （`$$` 的 PID 一致性现在由**原生路径**保证：
#     `Expand::expand-var-at` 直接把 `$$` 展开成 `Session::shell-pid()`；
#     `$?` 由 `last-status()` 展开。）

# ⚠⚠ **已删**（2026-11-05 引擎纯化）：
#
#   `has-dollar-question` / `rewrite-pid-in-word` 这两个公开 sub
#   是给**「整行交 sh」那条路**用的（`prepare-for-sh` 靠它们
#   判断「这一行有没有真正的 `$?`」并把 `$$` 换成 PID 字面量）。
#   纯化之后**没有交 sh 这条路了** ⇒ 两个函数成了**死代码** ⇒ 删掉。
#
#   （`$$` 的 PID 一致性现在由**原生路径**保证：
#     `Expand::expand-var-at` 直接把 `$$` 展开成 `Session::shell-pid()`。）
