unit module Rakuish::Shell::Exec;

use NativeCall;

use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;
use Rakuish::Shell::Expand;
use Rakuish::Shell::Session;
use Rakuish::Shell::Heredoc;   # heredoc 的识别（纯逻辑，见该模块的文件头）
use Rakuish::Slow;

# Rakuish::Shell::Exec —— 原生管道 / 重定向执行层
#
# 移植自 v/rakuish.v 的 `run_pipeline`（V 版 608 行里的执行部分）。
#
# ══════════════════════════════════════════════════════════════════════
# ⚠⚠⚠ 本文件最重要的一条设计约束：**不要用 fork + 在子进程里 exec** ⚠⚠⚠
# ══════════════════════════════════════════════════════════════════════
#
# 原因（实测踩出来的，不是推测）：
# **MoarVM 是多线程运行时**（GC 线程、异步调度器线程…）。`fork()` 只复制调用
# 线程 —— 其它线程在 fork 那一刻正持有的锁，在子进程里**永远解不开**。
# 于是子进程里只要触发一次 GC / 调度器，就会**永久卡在 futex 上**。
#
# 症状极具迷惑性：
#   · 父进程停在 `waitpid`，子进程停在 `futex_wait`（`/proc/<pid>/wchan` 可见）
#   · **同样的代码有时能跑通、有时卡死**（取决于 fork 那一刻有没有线程持锁）
#   · 单条命令（不走 fork）永远正常
#   · 连「子进程里只调 libc 原生函数」也**不能保证安全** ——
#     NativeCall 的调度器自己会分配内存，分配可能触发 GC → 一样卡死
#     （实测：480 次执行里卡死 1 次，约 0.2%）
#
# 所以最终方案是 **`posix_spawn(3)`**：
#   · 进程创建由 **libc** 负责（内部是 clone(CLONE_VM|CLONE_VFORK)），
#     **我们的运行时完全不参与** ⇒ 没有锁继承问题 ✅
#   · 管道/重定向靠 `posix_spawn_file_actions_adddup2` 描述 ——
#     **不需要子进程**去执行 dup2 ✅（也就没有「子进程里跑 Raku 代码」的风险）
#   · argv 数组用 `strdup` + `CArray[Pointer]` 造，NULL 终止符用
#     `getenv` 取一个必然不存在的变量名（返回 NULL 指针）
#
# V 版是「fork + 子进程里 dup2 + execvp」—— V 的运行时是单线程的，
# 所以它没这个问题；Raku 这边必须换成 posix_spawn。
#
# ── 结果类型沿用 Slow::SlowResult ─────────────────────────────────
# 字段形状与 Slow 的完全一致（code / found / passed / out / stdout / stderr），
# 这样 Loop 侧不必区分「原生路径」与「sh 回退路径」两条路。

# ── libc 原语 ──────────────────────────────────────────────────────
# 注意：**必须写两个独立 trait**（`is native is symbol<...>`）。
# 写成 `is native(:symbol<chdir>)` 会把 symbol 误当库名
# （HANDOFF §4.2 坑 19）。
#
# `CArray[int32]` 形参：NativeCall 把它当**裸指针**传给 C 侧
# （实测两个后端都正确）。但有个前提 —— **数组必须先有正确的长度**：
# `CArray[int32].new(2)` 实际只建了 **1 个槽位**（实测 `.elems = 1`），
# 于是 native 写不进第二个元素（fds 变成 [3,0]）。
# 正确写法：先 `CArray[int32].new`，再给下标 **赋值**（赋值会自动扩容）。
#
# `CArray[Pointer]` 形参：execvp / posix_spawnp 的 argv 就是它 ✅。

sub c-pipe(CArray[int32]) is native is symbol<pipe> returns int32 { * }
sub c-dup2(int32, int32) is native is symbol<dup2> returns int32 { * }
sub c-close(int32) is native is symbol<close> returns int32 { * }
sub c-open(Str, int32, int32) is native is symbol<open> returns int32 { * }
sub c-waitpid(int32, CArray[int32], int32) is native is symbol<waitpid> returns int32 { * }
sub c-getpid() is native is symbol<getpid> returns int32 { * }
sub c-strdup(Str) is native is symbol<strdup> returns Pointer { * }
sub c-getenv(Str) is native is symbol<getenv> returns Pointer { * }
sub c-malloc(int32) is native is symbol<malloc> returns Pointer { * }
sub c-free(Pointer) is native is symbol<free> returns int32 { * }
sub c-fcntl(int32, int32, int32) is native is symbol<fcntl> returns int32 { * }
sub c-posix-spawn-file-actions-init(Pointer) is native is symbol<posix_spawn_file_actions_init> returns int32 { * }
sub c-posix-spawn-file-actions-adddup2(Pointer, int32, int32) is native is symbol<posix_spawn_file_actions_adddup2> returns int32 { * }
# ⚠ 第 6 个参数（envp）是 `CArray[Pointer]`，**不是** `Pointer`。
#   之前这里写的是 `Pointer` + 传 NULL（= 继承父进程环境）——
#   实测两个后端对「`%*ENV` 的改动进不进子进程」的处理**不一致**
#   （MoarVM 进、rakupp 不进），所以改成显式传 envp。
sub c-posix-spawnp(CArray[int32], Str, Pointer, Pointer, CArray[Pointer], CArray[Pointer]) is native is symbol<posix_spawnp> returns int32 { * }

# Linux x86_64 的常量
our $O-RDONLY  = 0;
our $O-WRONLY  = 1;
our $O-CREAT   = 64;
our $O-TRUNC   = 512;
our $O-APPEND  = 1024;
our $FILE-MODE = 420;        # 0o644
our $F-SETFD   = 2;          # fcntl 的命令
our $FD-CLOEXEC = 1;         # 关闭即关
our $ACTIONS-SIZE = 512;     # posix_spawn_file_actions_t 的分配大小（不透明结构，取够）

# NULL 终止符的来源：getenv 一个**必然不存在**的变量名 → 返回 NULL 指针。
# （不能写死一个真实变量名 —— 万一被设置了，argv 就不 terminated 了。）
our $NULL-ENV-NAME = 'RKUISH_INTERNAL_NULL_TERMINATOR_7f3a91c8';

# ── 计划：一条命令的 argv + 重定向 ────────────────────────────────
class Plan is export {
    has List $.argv;      # List of Str（已展开）
    has List $.redirs;    # List of Redirect
}

# ── 我们**不实现**的 shell 内建 ───────────────────────────────────
# 这些命令的语义依赖**会话状态**（cd 改进程目录、export 改环境、
# read 读 stdin、exit 退出会话）。自己实现一半比交给 sh 更糟，
# 所以整段交 sh —— 行为与改造前完全一致（改造前也是 `sh -c`）。
#
# ⚠ `export` / `unset` **不在表里**了 —— 它们由本模块自己处理
#   （见 `run-session-builtin`），因为它们要改的是**跨行存活**的
#   会话状态，交给 `sh -c` 的话进程一退出就没了。
# 内层命令（命令替换）的 stderr 暂存处。
# ⚠ 模块级变量：Rakuish 是单线程顺序执行 REPL，一行一行来 ⇒ 安全。
our Str $INNER-ERR = q{};

# 「这一行 native 后端跑不了」的退出码。0 = 没中止；2 = bash 的语法错误码。
#
# 为什么需要它（2026-11-05）：**命令替换的内层**不支持时，
# 错误发生在**内层**，而外层（`echo $( (echo a) )`）只是把内层的
# stdout 当替换结果 —— 内层的退出码/错误被**丢掉**了 ⇒
# 外层 echo 照跑、退出码 0（错！bash 这里是语法错误，退出码 2）。
#
# ⇒ 内层中止时把这个标记**传回外层**，外层在展开之后、执行之前中止。
our Int $ABORT-CODE = 0;

our $SH-BUILTINS = <cd alias source . eval exec trap ulimit
                    local readonly declare jobs fg bg wait umask shopt type
                    command builtin hash let times return exit break continue
                    shift getopts read enable>;
# 注意 `echo` / `printf` / `test` / `[` / `true` / `false` **不在表里**：
# 它们都有真正的可执行文件（/bin/echo、/usr/bin/printf …），
# 直接 exec 即可，行为与 sh 内建一致（连 `-e` / `-n` 都支持）。

# ── 小工具 ────────────────────────────────────────────────────────

# 冲掉缓冲。**spawn 之前必须做**：子进程继承了父进程的输出缓冲，
# 退出时再刷一次就会**输出重复**（实测 rakupp 上会重复）。
sub flush-stdio() {
    try { $*OUT.flush };
    try { $*ERR.flush };
    Nil
}

# 捕获用的临时文件序号（同进程内递增，避免同名）
our $CAP-SEQ = 0;

# 读一个文件的内容（可能不是合法 UTF-8 → 失败时给空串而不是炸掉）
sub slurp-file(Str $path --> Str) {
    return q{} unless $path.chars;
    my $s = try { slurp($path) };
    return q{} if $!;
    return q{} unless defined $s;
    $s.Str
}

# 给 fd 打上「关闭即关」标记。
# 为什么必须打：posix_spawn 的子进程会继承父进程所有**没有** FD_CLOEXEC 的 fd。
# 管道两端如果不打标记，就会被**所有** stage 继承 —— 读端永远等不到 EOF
# （写端的副本一直开着），管道就死了。
# 另外 dup2 出来的目标 fd（fd 0/1/2）会自动清掉这个标记 ✅（POSIX 规定），
# 所以「该继承的继承、不该继承的关掉」正好成立。
sub set-cloexec(Int $fd) {
    c-fcntl($fd, $F-SETFD, $FD-CLOEXEC);
    Nil
}

# ── argv 数组（execvp / posix_spawnp 要的 char**）──────────────────
sub make-argv(List $args --> CArray[Pointer]) {
    my $argv = CArray[Pointer].new;
    # ⚠ CArray **没有** `.push`（实测两后端都报
    # "Cannot resolve caller push(CArray[Pointer])"）——
    # 只能用下标赋值（赋值会自动扩容）。
    my $i = 0;
    for @$args -> $a {
        $argv[$i] = c-strdup($a);         # strdup 给出 NUL 结尾的副本
        $i++;
    }
    $argv[$i] = c-getenv($NULL-ENV-NAME); # NULL 终止符
    $argv
}

# ── envp 数组（posix_spawnp 的 envp 参数）──────────────────────────
#
# ⚠⚠ 为什么必须**显式构造** envp，而不是传 NULL（= 继承父进程环境）⚠⚠
#
# 实测（两个后端都验过）：
#   · MoarVM：`%*ENV` **就是**进程真实环境 ⇒ 传 NULL 时子进程能看到
#     REPL 里新写的 `%*ENV`。
#   · rakupp：`%*ENV` 与进程真实环境**不是同一份** ⇒ 传 NULL 时子进程
#     **看不到** REPL 里新写的 `%*ENV`。
# → 同一段代码在两个后端上**行为不同**，而且**不报错**。
#
# 这正是 HANDOFF §4.1 那类「静默给出不同结果」的坑。
# 所以：**永远显式构造 envp** —— 基础环境取 `%*ENV`（两后端都是
# 「REPL 启动时继承的那份」），再用会话变量覆盖。
# 这样两个后端行为一致，且会话变量**确定**能进到子进程。
sub make-envp(Hash $over = Hash.new --> CArray[Pointer]) {
    my $envp = CArray[Pointer].new;
    my $i = 0;

    # 基础环境：`%*ENV` 全量。
    # ⚠ `%*ENV.keys` 而不是 `for %*ENV -> $k, $v`：后者在两个后端上
    #   **都不支持**解构（rakupp 直接报 "Too few positionals passed"）。
    #   `for %*ENV -> $pair` 可以，但 key/value 要用 `.key` / `.value` 取。
    for %*ENV.keys -> Str $k {
        next if $k eq q{};              # 空 key 不合法
        next if $k.contains(q{=});      # key 里带 '=' 不合法
        # ⚠ **跳过会话变量**：同一个 key 出现两次时，各家 libc 的
        #   行为**不一致** —— 实测 `sh -c printenv` 看到的是**后者**，
        #   但 glibc 的 `getenv()` 返回的是**前者**（POSIX 也没规定）。
        #   → 绝不让同一个 key 出现两次。
        #   会话变量的值由下面那个循环统一写入（优先级更高）。
        next if %VARS.EXISTS-KEY($k);
        # 覆盖层（命令替换的子 shell 用）优先级最高，也不能重复出现
        next if $over.EXISTS-KEY($k);
        my $v = %*ENV{$k};
        $envp[$i] = c-strdup($k ~ q{=} ~ (($v // q{}).Str));
        $i++;
    }

    # 会话变量（`export` 过的）。
    # 注意 `set-var` 也会把它镜像进 `%*ENV`，所以这里其实是**兜底**：
    # 万一镜像失败（`%*ENV` 写入被拒），子进程仍能看到这个变量。
    for %VARS.keys -> Str $k {
        next if $over.EXISTS-KEY($k);   # 覆盖层优先，不能重复
        my $v = %VARS{$k};
        $envp[$i] = c-strdup($k ~ q{=} ~ (($v // q{}).Str));
        $i++;
    }

    # 覆盖层（预扫描的影子表 / 命令替换子 shell 的临时变量）
    for $over.keys -> Str $k {
        my $v = $over{$k};
        $envp[$i] = c-strdup($k ~ q{=} ~ (($v // q{}).Str));
        $i++;
    }

    $envp[$i] = c-getenv($NULL-ENV-NAME); # NULL 终止符
    $envp
}

# ── 重定向 → posix_spawn file actions ─────────────────────────────
# dup2 的参数顺序是**极易写反**的地方：`dup2(oldfd, newfd)` 里
# **oldfd 是源、newfd 是目标**。
#   `2>&1` = dup2(1, 2) —— 让 fd2 指向 fd1 当前指向的东西
# 写反的症状极具误导性：dup2 返回成功、`2> file` 正常落盘、
# 只有 `2>&1` 静默失效。
#
# 【与 V 版的差异】V 版在 fork 出的子进程里「dup2 以 fd 1 为目标会静默失效」
# （实测），它的绕法是「目标为 fd1 时先 dup(1) 再 dup2(新fd → 源fd)」。
# 那是 **V 自己的 fd_dup2 封装**的问题，不是 POSIX 的问题 ——
# 我们直接调 libc 的 dup2 / posix_spawn file actions，**不需要**那个绕法，
# `> f 2>&1` 就是「先 dup2(file→1)，再 dup2(1→2)」。
#
# ⚠ 目标文件名**在父进程里就展开好** —— 这里没有子进程，
#   但也统一「展开发生在解析阶段」这条规矩。
sub add-redir-actions(Pointer $acts, List $redirs) {
    for @$redirs -> $r {
        if $r.kind eq 'dup' {
            # `N>&M` —— 让 fd N 指向 fd M 当前所指向的目标。
            # 实现就是 dup2(M, N)（**M 是源，N 是目标**）。
            c-posix-spawn-file-actions-adddup2($acts, $r.dup-fd, $r.fd);
            next;
        }
        my $flags = $O-RDONLY;
        if $r.kind eq 'out' {
            $flags = $O-WRONLY +| $O-CREAT +| $O-TRUNC;
        }
        elsif $r.kind eq 'append' {
            $flags = $O-WRONLY +| $O-CREAT +| $O-APPEND;
        }
        my $fd = c-open($r.target, $flags, $FILE-MODE);
        if $fd < 0 {
            next;         # 打不开：跳过
        }
        # 打开出来的 fd 打上 CLOEXEC：dup2 出去的那份（fd 0/1/2）会清掉标记，
        # 原始这份在 exec 时自动关闭 ✅（不用再单独 addclose）。
        set-cloexec($fd);
        c-posix-spawn-file-actions-adddup2($acts, $fd, $r.fd);
    }
    Nil
}

# ── 原生执行一条流水线 ───────────────────────────────────────────
# 语义（对齐 bash）：
#   · 每个 pipeline 段一个进程，段间用 pipe(2) 串起来
#   · 首段 stdin 继承父进程（交互式 REPL 下就是终端）
#   · 末段 stdout：直通时继承父进程；捕获时写临时文件后读回
#     （用文件而不是管道收集：父进程先 wait 再读，彻底避免管道缓冲区打满的死锁）
#   · 重定向用 posix_spawn file actions 描述（可覆盖管道布局）
sub exec-native(List $plans, Bool $negated, Bool $capture,
                 Hash $envover = Hash.new --> SlowResult) {
    my $n = $plans.elems;
    return SlowResult.new(:code(0), :found(True)) if $n == 0;

    # ── 段间管道 ──
    my @pr;      # 读端
    my @pw;      # 写端
    for (1 .. ($n - 1)) {
        my $fds = CArray[int32].new;
        $fds[0] = -1;
        $fds[1] = -1;          # 赋值自动扩容到 2 个槽位（见文件头注释）
        my $rc = c-pipe($fds);
        if $rc != 0 {
            return SlowResult.new(:code(1), :found(False),
                                  :passed($capture), :stderr("pipe failed\n"));
        }
        set-cloexec($fds[0]);
        set-cloexec($fds[1]);
        @pr.push: $fds[0];
        @pw.push: $fds[1];
    }

    # ── 捕获模式：末段 stdout / stderr → 临时文件 ──
    my $out-path = q{};
    my $err-path = q{};
    my $out-fd = -1;
    my $err-fd = -1;
    if $capture {
        my $base = '/tmp/rakuish-cap-' ~ c-getpid() ~ '-' ~ ($CAP-SEQ++);
        $out-path = $base ~ '.out';
        $err-path = $base ~ '.err';
        $out-fd = c-open($out-path, $O-WRONLY +| $O-CREAT +| $O-TRUNC, $FILE-MODE);
        $err-fd = c-open($err-path, $O-WRONLY +| $O-CREAT +| $O-TRUNC, $FILE-MODE);
        if $out-fd < 0 { $out-path = q{}; $out-fd = -1 }
        if $err-fd < 0 { $err-path = q{}; $err-fd = -1 }
        set-cloexec($out-fd) if $out-fd >= 0;
        set-cloexec($err-fd) if $err-fd >= 0;
    }

    # ── 逐段 spawn ──
    my @pids;
    my $spawn-failed = q{};
    for (0 ..^ $n) -> $i {
        my $plan = $plans[$i];

        # argv 数组在父进程里造好（libc 自己 fork+exec，不需要子进程）
        my $argv = make-argv($plan.argv);
        my $prog = $plan.argv[0];

        # flush 一下，免得子进程退出时把父进程的缓冲重复刷一遍
        flush-stdio();

        # file actions：管道布局 + 重定向（顺序即 bash 的顺序）
        my $acts = c-malloc($ACTIONS-SIZE);
        c-posix-spawn-file-actions-init($acts);
        if $i > 0 {
            c-posix-spawn-file-actions-adddup2($acts, @pr[$i - 1], 0);  # 上游读端 → stdin
        }
        if $i < $n - 1 {
            c-posix-spawn-file-actions-adddup2($acts, @pw[$i], 1);      # 本段写端 → stdout
        }
        elsif $out-fd >= 0 {
            c-posix-spawn-file-actions-adddup2($acts, $out-fd, 1);      # 末段 stdout → 捕获文件
        }
        if $err-fd >= 0 {
            c-posix-spawn-file-actions-adddup2($acts, $err-fd, 2);      # stderr → 捕获文件
        }
        add-redir-actions($acts, $plan.redirs);

        my $pid-arr = CArray[int32].new;
        $pid-arr[0] = 0;
        # envp **显式构造**（不传 NULL = 继承）：两个后端对
        # 「`%*ENV` 的改动是否进到子进程」的语义不同（见 make-envp
        # 的注释），显式传才能保证行为一致 + 会话变量一定传得进去。
        my $rc = c-posix-spawnp($pid-arr, $prog, $acts,
                                c-getenv($NULL-ENV-NAME), $argv,
                                make-envp($envover));
        c-free($acts);
        if $rc != 0 {
            # 启动失败（最常见：命令不存在）。bash 语义：127 + 一行提示。
            $spawn-failed = $prog ~ ": command not found\n";
            @pids.push: 0;
            next;
        }
        @pids.push: $pid-arr[0];
    }

    # ── 父进程：关掉自己的管道端 copy ──
    # 否则写端永远不 EOF，末段会一直等。
    for @pr -> $fd { c-close($fd) }
    for @pw -> $fd { c-close($fd) }
    if $out-fd >= 0 { c-close($out-fd) }
    if $err-fd >= 0 { c-close($err-fd) }

    # 逐个收尸，取**最后一条**的退出码（bash 语义）
    my $code = 0;
    for @pids -> $pid {
        if $pid == 0 {
            $code = 127;        # 启动失败的那一段
            next;
        }
        my $st = CArray[int32].new;
        $st[0] = 0;
        c-waitpid($pid, $st, 0);
        my $raw = $st[0];
        # ⚠ 位运算必须用 `+&` / `+|` / `+^` —— Raku 的 `&` `|` `^` 是
        # **Junction 运算符**（两个后端实测一致：`5 & 3` 的类型是 Junction，
        # 不是 Int）。写成 `&` 会让 exitcode 变成 Junction，
        # 赋给 Int 属性时直接报 "expected Int but got Junction"。
        if ($raw +& 0x7F) == 0 {
            $code = ($raw +> 8) +& 0xFF;     # 正常退出
        }
        else {
            $code = 128 + ($raw +& 0x7F);    # 被信号杀死 → 128 + 信号号
        }
    }
    if $spawn-failed ne q{} {
        try { $*ERR.print($spawn-failed) };
    }

    my $stdout = q{};
    my $stderr = q{};
    if $capture {
        $stdout = slurp-file($out-path);
        $stderr = slurp-file($err-path);
        try { unlink $out-path };
        try { unlink $err-path };
    }

    if $negated {
        $code = $code == 0 ?? 1 !! 0;        # `! cmd` → 退出码取反
    }

    SlowResult.new(
        :code($code),
        :found($code != 127),
        :passed($capture),
        :out($stdout ~ $stderr),
        :stdout($stdout),
        :stderr($stderr),
    )
}

# ── 快路径：单命令、无重定向、直通 ────────────────────────────────
# 直接用 Raku 的 `run(@argv)`：
#   · 不接返回值 = 继承 fd1 = **流式直通 + 原生 ANSI 全保留**
#   · argv 直接给程序，**不经过 shell** ⇒ 引号不会被二次解释
#     （`"a b"` 就是一个参数，不是两个）
#   · Raku 内部走 posix_spawn，**不 fork 我们的进程** ⇒ 没有 fork 锁死问题
my sub exec-fast(List $argv --> SlowResult) {
    if $argv.elems == 0 {
        return SlowResult.new(:code(0), :found(True));
    }
    my $code = try {
        my $p = run(@$argv);
        $p.exitcode // 0;
    };
    if $! {
        # 命令不存在（或起不来）：bash 语义给 127
        try { $*ERR.print($argv[0] ~ ": command not found\n") };
        return SlowResult.new(:code(127), :found(False));
    }
    SlowResult.new(:code($code), :found($code != 127))
}

# ── heredoc ────────────────────────────────────────────────────────
#
# ⚠ 识别部分挪到 `Shell::Heredoc`（纯逻辑、无 libc）——
#   REPL 侧只需要「有没有 heredoc / 正文到哪结束」，**不必**加载执行层
# heredoc 正文用的临时文件序号
our $HD-SEQ = 0;

# 写一个临时文件（正文 / 脚本文本都用它）
sub write-temp-text(Str $text --> Str) {
    my $path = '/tmp/rakuish-hd-' ~ c-getpid() ~ '-' ~ ($HD-SEQ++);
    try { spurt($path, $text) };
    $path
}

# 去掉每行开头的制表符（`<<-` 用）
#
# ⚠ 不用正则（两后端正则语义可能不一致，见 HANDOFF §4.1）——
#   逐字符扫，记住「当前是不是行首」。
sub strip-leading-tabs(Str $s --> Str) {
    my $out = q{};
    my $at-start = True;
    for $s.comb -> $c {
        next if $at-start and $c eq "\t";
        $out ~= $c;
        $at-start = ($c eq "\n");
    }
    $out
}

# ── 「这个后端不支持」⇒ **明确报错**，不偷偷交给 bash/sh ─────────────
#
# ⚠⚠ **这里曾经是 `fall-back-to-sh`**（整行交 `sh -c`）——
#   那是「**在一个后端里干另一个后端的活**」：
#   · native 后端于是永远只是「近似 bash」（bash 的特性要一个个自己补）；
#   · 更糟的是**静默**：本机 `/bin/sh` 是 **dash**，它与 bash 的差异
#     （没有 brace 展开、没有 `[[ ]]`、数组行为不同…）会**悄悄泄漏**进来
#     —— 用户写的是 bash 语法，跑出来的却是另一种结果。
#
# → 现在：**明确报错 + 告诉用户怎么委托**（`!@bash ...` 或 `%shell bash`）。
#
# 退出码取 **2**（bash 的语法错误码就是 2）。
our sub fail-unsupported(Str $why, Bool :$capture = False --> SlowResult) is export {
    # ⚠ **中止标记**要在这里置上（不只是返回退出码）：
    #   这一行可能是**命令替换的内层** ⇒ 外层要跟着中止
    #   （否则外层 echo 照跑、退出码 0 —— 错）。
    $ABORT-CODE = 2;
    my $msg = "native 后端不支持这一行：$why\n"
             ~ "  这一行要的是 bash 的语义 —— 用 `!@bash ...` **委托**给 bash 后端，\n"
             ~ "  或 `%shell bash` 把默认 shell 后端切过去。\n";
    if $capture {
        return SlowResult.new(:code(2), :found(True), :passed(True),
                              :out($msg), :stdout(q{}), :stderr($msg));
    }
    try { $*ERR.print($msg) };
    SlowResult.new(:code(2), :found(True))
}

# ── 命令替换的求值 ────────────────────────────────────────────────
#
# bash 语义：
#   · 只捕获 **stdout**（stderr 透传到终端）
#   · 结果的**尾部换行被去掉**（`$(printf 'a\n\n')` → `a`）
#   · 内层命令在**子 shell** 里跑（内层的 export 不影响当前会话）
our sub subst-cmd(Str $inner, Hash $envover = Hash.new --> Str) is export {
    # ⚠⚠ 内层命令走**原生路径**（`run-shell-line(..., :inner(True))`），
    #   **不再** `sh -c` —— 那也是「在一个引擎里干另一个引擎的活」：
    #   dash 与 bash 的差异会静默泄漏进来。
    #
    #   bash 的命令替换是在**子 shell** 里跑的，所以：
    #   · 内层的 `export` **不该**影响当前会话（子 shell 的改动随进程消失）
    #     → `:inner(True)` 让内层**不走会话内建**那条路 ✓
    #   · 内层的引号/转义由**我们自己的词法层**解析（不是提前展开 ——
    #     提前展开会把 `printf 'a\n\n'` 的引号剥掉，
    #     `\n` 就被当成转义而不是 printf 的格式串了）
    my $res = run-shell-line($inner, :inner(True), :capture(True));
    my $out = ($res.stdout // q{}).Str;
    # 尾部换行去掉（bash：命令替换的结果 strip 掉所有尾随换行）
    my $t = $out;
    $t = $t.substr(0, $t.chars - 1) while $t.ends-with("\n");
    # ⚠ stderr **不属于替换的结果**（bash 语义：只取 stdout），
    #   但它**要透传出去**（不能吞掉）——
    #   收集起来交给调用方（捕获模式下并进结果的 stderr，直通模式下写终端）✓
    $INNER-ERR ~= $res.stderr;
    $t
}


# ── 这一行能不能原生跑？──────────────────────────────────────────
# 返回 False 表示「有我们不实现的语法」。
#
# ⚠ 这只是**静态**判断（不执行任何东西）。真正的判断在
#   `run-shell-line` 的预扫描里做（那里还要模拟 export 的效果）。
#   这个函数给外部/测试用。
#
# ⚠⚠ **现在没有「交 sh」这条路了**（2026-11-05 引擎纯化）——
#   返回 False 的后果是**明确报错 + 退出码 2**（`fail-unsupported`）。
our sub native-supported(Str $line --> Bool) is export {
    my $trimmed = $line.trim;
    return True if $trimmed eq q{};
    my $lexed = lex($trimmed, :cmdsub(True));
    return False if $lexed.unsupported ne q{};
    my $parsed = parse($lexed.tokens);
    return False if $parsed.unsupported ne q{};
    my %shadow;
    for @($parsed.pipelines) -> $pl {
        my @cmds = @($pl.commands);
        for @cmds -> $cmd {
            my @raws = @($cmd.args);
            # 会话内建：单条 command 时原生支持；管道里则要交 sh
            # （bash 里它在子进程里跑，不影响当前 shell）。
            if is-session-command(@raws) {
                return True if @cmds.elems == 1;
                return False;
            }
            for @raws -> $raw {
                for @(word-frags($raw, %shadow)) -> $w {
                    next unless frag-has-meta($w);
                    return False unless glob-supportable(frag-pattern($w));
                }
            }
            # 内建：命令名要看**展开后**的（`$CMD` 也可能是内建）
            my $name = first-word(@raws, %shadow, &default-subst);
            return False if $name (elem) $SH-BUILTINS;
        }
    }
    True
}

# ── 展开辅助：词 → 片段列表 ───────────────────────────────────────
#
# 展开的**完整前半段**：展开变量 → 命令替换求值 → 分词。
# 返回的是「词」的列表，每个词是一个片段列表。
# （glob 展开放在最后一步，因为 glob 要按**模式**而不是按结果做。）
sub word-frags(Str $raw, Hash $ovr, &subst = &default-subst) {
    my @frags = expand-frags($raw, $ovr);
    @frags = subst-frags(@frags, &subst);
    split-frags(@frags)
}

# 第一条命令的**命令名**（展开 + 分词后的第一个词）。
#
# ⚠ `$raws` 用**标量**形参而不是 `@raws`：Raku 里 `@` 形参会**吞掉后面
#   所有位置实参**（ slurpy ），放在中间会把 `&subst` 也吞掉。
sub first-word($raws, Hash $ovr, &subst = &default-subst --> Str) {
    for @($raws) -> $raw {
        my @words = word-frags($raw, $ovr, &subst);
        return q{} if @words.elems == 0;
        return frag-text(@words[0]);
    }
    q{}
}

# ── 会话内建：export / unset / VAR=value ─────────────────────────
#
# 这些命令改的是**会话状态**（跨行存活的变量表），
# 交给 `sh -c` 的话进程一退出就没了 —— 改造前 `!export FOO=bar` 之后
# `!echo $FOO` 是空的，正是这个原因。
#
# 返回 Nil 表示「不是会话内建，交给正常执行路径」。
#
# ⚠ **不要写返回类型标注** `--> SlowResult`：这里要返回 Nil 表示
#   「不是内建」，标了类型就等于把 Nil 判成类型错误
#   （两个后端都会报 "expected SlowResult but got Nil"）。
our sub run-session-builtin(List $args, Hash $ovr = Hash.new,
                             &subst = &default-subst, Bool :$dry = False) is export {
    return Nil if $args.elems == 0;

    my $name = expand-arg-sub($args[0], $ovr, &subst);

    # ── export ──────────────────────────────────────────────────
    if $name eq 'export' {
        my @rest = @($args)[1..$args.elems - 1];
        if @rest.elems == 0 {
            # `export` 不带参数 → 列出（bash 是 `declare -x` 格式）
            my $text = q{};
            for var-names() -> $k {
                $text ~= q{export } ~ $k ~ q{=} ~ get-var($k) ~ "\n";
            }
            return SlowResult.new(:code(0), :found(True), :passed(True),
                                  :out($text), :stdout($text));
        }
        for @rest -> $a {
            my $w = expand-arg-sub($a, $ovr, &subst);
            my $parts = assignment-parts($w);
            if $parts.defined {
                my ($k, $v) = $parts;
                # value 部分**单独展开**：`FOO="a b"` 的值是 `a b`。
                set-var($k, expand-arg-sub($v, $ovr, &subst)) unless $dry;
            }
            else {
                # `export NAME` —— 导出已有变量（没有就当空）
                set-var($w, get-var($w)) unless $dry;
            }
        }
        return SlowResult.new(:code(0), :found(True));
    }

    # ── unset ───────────────────────────────────────────────────
    if $name eq 'unset' {
        for @($args)[1..$args.elems - 1] -> $a {
            unset-var(expand-arg-sub($a, $ovr, &subst)) unless $dry;
        }
        return SlowResult.new(:code(0), :found(True));
    }

    # ── 纯赋值：NAME=VALUE（整行只有一个词）──────────────────────
    if $args.elems == 1 {
        my $parts = assignment-parts($args[0]);
        if $parts.defined {
            my ($k, $v) = $parts;
            set-var($k, expand-arg-sub($v, $ovr, &subst)) unless $dry;
            return SlowResult.new(:code(0), :found(True));
        }
    }

    Nil
}

# ── 模拟一条会话内建对变量表的影响（**只改影子表**）───────────────
#
# 预扫描时用：判断「后面那条命令展开后会是什么」时，需要知道
# 前面的 export 设了什么，但**不能**真的改真表（那会让 export 跑两次）。
#
# `$shadow` 是普通的 Hash（名字 → 值）。
our sub simulate-session-command(List $args, Hash $shadow,
                                 &subst = &default-subst) is export {
    return if $args.elems == 0;
    my $name = expand-arg-sub($args[0], $shadow, &subst);

    if $name eq 'export' {
        for @($args)[1..$args.elems - 1] -> $a {
            my $w = expand-arg-sub($a, $shadow, &subst);
            my $parts = assignment-parts($w);
            if $parts.defined {
                my ($k, $v) = $parts;
                $shadow{$k} = expand-arg-sub($v, $shadow, &subst);
            }
            else {
                # `export NAME` —— 导出已有变量（没有就当空）
                $shadow{$w} = get-var($w);
            }
        }
        return;
    }

    if $name eq 'unset' {
        for @($args)[1..$args.elems - 1] -> $a {
            my $w = expand-arg-sub($a, $shadow, &subst);
            $shadow{$w} = q{} if $shadow.EXISTS-KEY($w);
            $shadow{$w} = q{};
        }
        return;
    }

    # 纯赋值 NAME=VALUE
    if $args.elems == 1 {
        my $parts = assignment-parts($args[0]);
        if $parts.defined {
            my ($k, $v) = $parts;
            $shadow{$k} = expand-arg-sub($v, $shadow, &subst);
        }
    }
}

# ── 这一条 pipeline 是不是「纯会话内建」？─────────────────────────
#
# 判据：**只有一条 command**，且它是 `export` / `unset` / `NAME=VALUE`。
#
# ⚠ 为什么要求「只有一条 command」：
#   `export X=1 && echo $X` —— 这里 export 是**一条 pipeline 里的一条
#   command**，整条 pipeline 还有别的 command ⇒ **不是**纯内建。
#   bash 的语义：`export` 在**当前 shell** 里执行（不是子 shell），
#   所以 `export X=1 && echo $X` 里 echo 能看到 X。
#   → 这条路径由「按 pipeline 逐条执行」处理（见 run-shell-line），
#     而不是在这里整行拦下来。
#
# 反过来，`export X=1 | cat` 里 export 在**管道子进程**里跑，
# 不会影响当前 shell ⇒ 那种情况**不该**进会话表。
our sub is-session-command(List $args, &subst = &default-subst --> Bool) is export {
    return False if $args.elems == 0;
    my $name = expand-arg-sub($args[0], Hash.new, &subst);
    return True if $name eq 'export' or $name eq 'unset';
    # `NAME=VALUE`（单词）
    if $args.elems == 1 {
        return True if is-assignment($args[0]);
    }
    False
}

# ── 顶层：跑一行 shell ───────────────────────────────────────────
#
# 路由：
#   · 能原生跑 → 原生执行（管道 / 重定向 / argv 全部自己实现）
#   · 不能原生跑（`{...}` 复合命令、`( … )` 子 shell、shell 内建 …）
#     → **明确报错 + 退出码 2 + 委托提示**（`fail-unsupported`）
#
# ⚠⚠ **不再有「交 sh」这条路**（2026-11-05 引擎纯化，见 §5.8.7）：
#   偷偷交给 `sh -c` 会让 **dash** 的语义泄漏进来
#   （本机 `/bin/sh` 是 dash：没有 brace 展开、没有 `[[ ]]`…）——
#   用户写的是 bash 语法，跑出来的却是另一种结果。
our sub run-shell-line(Str $line, Hash $bodies = Hash.new,
                       Bool :$capture = False,
                       Bool :$inner = False --> SlowResult) is export {
    my $trimmed = $line.trim;
    return SlowResult.new(:code(0), :found(True)) if $trimmed eq q{};
    # 内层命令的 stderr 暂存（这一行开始重新收集）
    $INNER-ERR = q{};
    # ⚠ **中止标记重置**（这一行开始重新算）。
    #   命令替换的**内层**也会调 `run-shell-line` ⇒ 内层会把标记清零 ——
    #   所以内层失败时要**重新置上**（`fail-unsupported` 负责），
    #   内层成功时清零才是对的（外层继续跑）✓
    $ABORT-CODE = 0;

    # 这一行的 heredoc（分隔符 + 开关）。
    my @hd-specs = heredoc-specs($trimmed);

    my $lexed = lex($trimmed, :cmdsub(True));
    if $lexed.unsupported ne q{} {
        return fail-unsupported($lexed.unsupported, :capture($capture));
    }
    my $parsed = parse($lexed.tokens);
    if $parsed.unsupported ne q{} {
        return fail-unsupported($parsed.unsupported, :capture($capture));
    }
    if $parsed.pipelines.elems == 0 {
        return SlowResult.new(:code(0), :found(True));
    }

    # ══════════════════════════════════════════════════════════════
    # 命令替换的求值器（每行一个）
    # ══════════════════════════════════════════════════════════════
    #
    # `$(cmd)` 要**真的跑一条命令**。放在哪里跑？放在这里 —— 执行层
    # （Expand 层不该有进程副作用）。
    #
    # ⚠ **缓存**为什么必须有：
    #   这一行会被扫**两遍**（预扫描 + 执行遍）。如果每遍都求值一次，
    #   `$(rm -f x)` 就会**跑两次** —— 而 bash 只跑一次。
    #
    #   缓存键 = **原始**内层文本（不能是展开后的：展开会剥掉引号，
    #   而展开后的文本不能拿去执行 —— 见 subst-cmd 的注释）。
    #   「预扫描用影子表、执行遍用真表」这件事由 **envp** 解决：
    #   内层命令拿到的环境 = base + 会话变量 + 当前覆盖表（见 make-envp）。
    #
    # ⚠ 内层命令的 **stderr 不属于结果**（bash 语义）→ 直接透传出去。
    my %subst-cache;
    # 覆盖表：预扫描阶段是**影子表**，执行阶段清空（用真表 %VARS）。
    # 一个 Hash 复用两段 —— 免得闭包捕获的「当前表」指针换不掉。
    my %ovr;
    my &subst = sub (Str $inner, Str $whole) {
        # 缓存键 = **原始**内层文本。
        #   为什么不展开后再当键：展开会剥掉引号（`printf 'a\n'` → `printf a\n`），
        #   而展开后的文本**不能**拿去执行（sh 需要原样解析引号）。
        #   原始文本当键 → 预扫描与执行遍命中同一个条目 ⇒ 命令只跑一次。
        if %subst-cache.EXISTS-KEY($inner) {
            my $e = %subst-cache{$inner};
            # ⚠ 缓存命中也要**恢复中止标记** ——
            #   「预扫描里就失败」的那次会被下面的重置清掉标记，
            #   命中缓存时必须把它**带回来**，否则外层不中止 ⇒ 退出码错。
            $ABORT-CODE = 2 if $e<abort>;
            return $e<v>;
        }
        my $v = subst-cmd($inner, %ovr);
        # 缓存条目存**值 + 是否中止**（中止也要缓存，否则会跑两次）
        %subst-cache{$inner} = { v => $v, abort => ($ABORT-CODE != 0) };
        $v
    };

    # ══════════════════════════════════════════════════════════════
    # 两遍扫描
    # ══════════════════════════════════════════════════════════════
    #
    # **第一遍（预扫描）**：判断这一行能不能**整行**原生跑。
    # 只要有**任何一条** pipeline 需要交 sh（内建、不可处理的 glob、
    # 管道里的会话内建），整行就原样交给 sh ——
    # 半原生半 sh 的混合执行会让语义变得不可预测。
    #
    # **第二遍（执行）**：按 pipeline 顺序逐条执行。
    #
    # ⚠ 为什么预扫描要带「影子表」`%ovr`：
    #   判断「这条命令能不能原生跑」需要**展开**参数（看命令名、看 glob），
    #   而展开结果取决于**同一条命令里更早的 export 设了什么**：
    #     `export CMD=ls && $CMD`  →  `$CMD` 要展开成 `ls`（不是空）
    #   → 预扫描时用影子表模拟 export 的效果，真跑的时候用真表。
    #   这也是为什么第一遍不能直接改真表（那会让 export 跑两次）。

    # 第一遍：预扫描（只判断，不执行、不改真表）
    #
    # ⚠ 这一遍的结论叫「need-sh」，但**现在没有 sh 了** ——
    #   它变成「这一行 native 后端跑不了」⇒ 明确报错（fail-unsupported）。
    #   `$need-sh-why` 记下**原因**（报错要说人话）。
    my $need-sh = False;
    my $need-sh-why = q{这一行需要 bash 的语义};
    for @($parsed.pipelines) -> $pl {
        my @cmds = @($pl.commands);
        for @cmds -> $cmd {
            my @raws = @($cmd.args);

            # 会话内建（export / unset / NAME=VALUE）
            if is-session-command(@raws, &subst) {
                # ⚠ 只有**单条 command** 的 pipeline 才算会话内建。
                # `export X=1 | cat` 里 export 跑在**管道子进程**里，
                # 不影响当前 shell ⇒ 那种情况交给 sh（语义才对）。
                if @cmds.elems == 1 {
                    # 模拟它对变量的影响（不碰真表）
                    # ⚠ `:inner`（命令替换的内层）**不模拟** ——
                    #   bash 的命令替换跑在**子 shell** 里，它的 export 带不回来 ✓
                    simulate-session-command(@raws, %ovr, &subst) unless $inner;
                    last;
                }
                $need-sh = True;
                $need-sh-why = '会话内建（export / unset / 赋值）出现在管道里 —— '
                             ~ 'bash 里它跑在**管道子进程**里，我们还没实现这个语义';
                last;
            }

            # 展开 + 预检（不可处理的 glob）
            #
            # ⚠ **含命令替换的参数不做 glob 预检**：
            #   预检要按**展开后**的模式判断，而展开命令替换 = **真的跑一条命令**。
            #   预扫描跑一遍、执行遍再跑一遍 ⇒ 命令被执行两次（bash 只跑一次）。
            #   → 含命令替换的参数**跳过预检**（宁可少判，也不多跑命令）。
            for @raws -> $raw {
                my @frags = expand-frags($raw, %ovr);   # 不求值
                my $has-cmdsub = False;
                for @frags -> $f { $has-cmdsub = True if $f.is-cmdsub }
                next if $has-cmdsub;
                for @(split-frags(@frags)) -> $w {
                    next unless frag-has-meta($w);
                    if not glob-supportable(frag-pattern($w)) {
                        $need-sh = True;
                        $need-sh-why = '这个 glob 模式我们处理不了（' ~ frag-pattern($w) ~ '）';
                        last;
                    }
                }
            }
            last if $need-sh;

            # 内建：命令名要看**展开后**的（`$CMD` 也可能是内建）
            my $name = first-word(@raws, %ovr, &subst);
            if $name (elem) $SH-BUILTINS {
                $need-sh = True;
                $need-sh-why = 'shell 内建命令 `' ~ $name ~ '`（我们还没实现内建）';
                last;
            }
        }
        last if $need-sh;
    }
    if $need-sh {
        return fail-unsupported($need-sh-why, :capture($capture));
    }

    # ⚠ **清掉预扫描阶段留下的「致命」标记**（消息留着 —— 靠文本去重）。
    #
    # 为什么必须清：预扫描也做展开（要判断这条命令能不能原生跑），
    # 于是 `${V:?msg}` / `$((1/0))` 在预扫描阶段就置了致命标记。
    # 如果不清，执行遍会在**第一条** pipeline 就中止 ——
    # 但错误其实在第三条（bash 的语义是：前两条照跑，第三条报错中止）。
    # → 清掉后，执行遍的展开会**重新**置上标记，位置就准了 ✓
    diag-fatal-reset();

    # ⚠ **清掉预扫描阶段的「中止」标记**（理由同上）。
    #
    # 预扫描也会做展开（要判断命令名、glob），于是命令替换的**内层**
    # 可能在那里就失败了。预扫描的位置**不准**（bash 是「前面的照跑、
    # 出错那条中止」）⇒ 清掉标记，让执行遍重新判定。
    #
    # ⚠ 清掉不会丢信息：命令替换的**缓存条目里记着「中止」**，
    #   执行遍命中缓存时会把标记**带回来** ✓（见上面 `&subst` 的注释）。
    $ABORT-CODE = 0;

    # ── 第二遍：逐条执行 ────────────────────────────────────────
    #
    # 三种连接符，语义各不相同（bash）：
    #   `;`   无条件执行下一条
    #   `&&`  上一条**成功**（退出码 0）才执行下一条
    #   `||`  上一条**失败**（退出码 ≠ 0）才执行下一条
    #
    # `&&` 与 `||` **同优先级、左结合** ⇒ 从左往右顺序扫描即可：
    # `a && b || c` = `(a && b) || c`
    #   a 失败 → 跳过 b → 因为 a 失败，`||` 触发 → 跑 c
    #   a 成功 → 跑 b → b 成功 → `||` 不触发 → 不跑 c
    #
    # ⚠ 跳过的流水线**不产生输出、也不改退出码**（退出码保留上一条的）。
    #   bash 里 `false && echo NO` 的退出码是 1（false 的），不是 0。
    #
    # 捕获模式下要**累加**各条流水线的输出：`echo one ; echo two` 的
    # 完整输出是 "one\ntwo\n"。只留最后一条的话前半段就丢了
    # （V 版有这个同样的 bug：run_line 里 `last = run_pipeline(...)` 覆盖）。
    my $code = 0;
    my $found = True;
    my $acc-out = q{};
    my $acc-err = q{};

    # ⚠ 覆盖表清空：执行阶段用**真表**（%VARS + %*ENV），
    #   影子表只在预扫描阶段有效（它模拟的是「假如这条命令跑完会怎样」）。
    for %ovr.keys -> Str $k { %ovr{$k}:delete }

    for @($parsed.pipelines) -> $pl {
        my $op = $pl.op;

        # ── 短路判断 ────────────────────────────────────────────
        # 连接符决定「这一条要不要跑」，依据是**上一条的退出码**。
        if $op eq '&&' and $code != 0 {
            next;         # 跳过：不改 $code、不产生输出
        }
        if $op eq '||' and $code == 0 {
            next;         # 跳过
        }

        my @cmds = @($pl.commands);

        # ── 会话内建：不 spawn，直接改会话状态 ──────────────────
        if @cmds.elems == 1 {
            my @raws = @(@cmds[0].args);
            if is-session-command(@raws, &subst) {
                # ⚠ `:inner`（命令替换的内层）**不走会话内建** ——
                #   bash 的命令替换跑在**子 shell** 里：内层的 export
                #   **不该**影响当前会话（改动随进程消失）✓
                my $sr = $inner ?? Nil !! run-session-builtin(@raws, %ovr, &subst);
                if $sr.defined {
                    $code = $sr.code;
                    $found = $sr.found;
                    # 会话退出码：每条 pipeline 执行完就更新（bash 语义）
                    set-last-status($code);
                    if $capture {
                        $acc-out ~= $sr.stdout;
                        $acc-err ~= $sr.stderr;
                    }
                    next;
                }
            }
        }

        # ── 普通命令：展开 + 执行 ──────────────────────────────
        my @plans;
        my @hd-files;      # 本条流水线的 heredoc 临时文件（执行完删）
        for @cmds -> $cmd {
            # 展开 → 分词 → glob（bash 的顺序）
            my @argv = expand-words(@($cmd.args), %ovr, &subst);
            # 重定向目标在**解析阶段**就展开好
            my @redirs;
            for @($cmd.redirs) -> $r {
                if $r.kind eq 'heredoc' {
                    # 正文 → 临时文件 → 当 **stdin** 重定向
                    # （bash：heredoc 就是命令的 stdin）
                    my $body = $bodies{$r.target};
                    $body = q{} unless $body.defined;
                    my $text = $body;
                    # 分隔符**没加引号** → 正文要展开（bash 语义）
                    if not $r.literal {
                        $text = expand-arg-sub($body, %ovr, &subst, :heredoc(True));
                    }
                    # `<<-` → 去掉行首制表符
                    $text = strip-leading-tabs($text) if $r.strip;
                    my $path = write-temp-text($text);
                    @hd-files.push: $path;
                    @redirs.push: Redirect.new(:kind('in'), :target($path), :fd(0));
                }
                elsif $r.kind eq 'dup' {
                    @redirs.push: Redirect.new(:kind('dup'), :target(q{}),
                                               :fd($r.fd), :dup-fd($r.dup-fd));
                }
                else {
                    @redirs.push: Redirect.new(:kind($r.kind),
                                               :target(expand-arg-sub($r.target, %ovr, &subst)),
                                               :fd($r.fd));
                }
            }
            # ⚠ 先拷贝再传：命名实参里的数组是**后期绑定**的
            # （`:argv(@argv)` 保存的是变量而不是值）——
            # 不拷贝的话所有 Plan 都会拿到最后一条命令的参数。
            my @argv-snap = @argv;
            my @redirs-snap = @redirs;
            @plans.push: Plan.new(:argv(@argv-snap), :redirs(@redirs-snap));
        }

        # ── 「native 后端跑不了这一行」⇒ **中止这一行** ─────────────
        #
        # ⚠ 什么时候会置上这个标记？
        #   · **命令替换的内层**不支持（`echo $( (echo a) )`）——
        #     内层的错误**不能被丢掉**：bash 里这是语法错误（退出码 2），
        #     外层的 echo **根本不执行**。以前内层报完错、外层照跑 ⇒ 退出码 0（错）。
        #   · 这一行本身不支持（但那种情况预扫描就 `return` 了）。
        #
        # ⚠ 放在**展开之后、执行之前**（与下面的致命诊断并列）。
        # ⚠ 退出码取 `$ABORT-CODE`（2 = bash 的语法错误码）。
        if $ABORT-CODE != 0 {
            $code = $ABORT-CODE;
            $found = True;
            set-last-status($code);
            last;          # 中止整行（后面的 pipeline 都不跑）
        }

        # ── 致命诊断 ⇒ **中止这一行**（bash 语义）──────────────
        #
        # 两种情况：`${V:?msg}`（V 未设置或为空）与 `$((1/0))`（除零）。
        # bash 的做法是：报错 + **这一条命令不执行** + 退出码非 0
        # （交互式 shell 报错后回到提示符，shell 本身还活着）。
        #
        # ⚠ 放在**展开之后、执行之前**：错误是展开阶段发现的
        #   （bash 也是这样：`echo ${V:?msg}` 里 echo 根本不跑）。
        # ⚠ 退出码取 1（bash 里参数展开失败是 1）。
        if diag-has-fatal() {
            $code = 1;
            $found = True;
            set-last-status($code);
            last;          # 中止整行（后面的 pipeline 都不跑）
        }

        # 快路径：单命令、无重定向、且不捕获
        if @plans.elems == 1 and @plans[0].redirs.elems == 0 and !$capture {
            my $r = exec-fast(@plans[0].argv);
            $code = $r.code;
            $found = $r.found;
            # 会话退出码：每条 pipeline 执行完就更新（bash 语义）
            set-last-status($code);
            next;
        }
        my $r = exec-native(@plans, $pl.negated, $capture);
        $code = $r.code;
        $found = $r.found;
        # 会话退出码：每条 pipeline 执行完就更新（bash 语义）
        set-last-status($code);
        if $capture {
            $acc-out ~= $r.stdout;
            $acc-err ~= $r.stderr;
        }
        # heredoc 的临时文件用完就删
        for @hd-files -> $f { try { unlink $f } }
    }


    # 诊断信息（`${V:?msg}` / 除零的报错）在这里统一取走 ——
    # 展开阶段只**收集**不打印（一行会扫两遍，直接打印会打两遍）。
    #
    # ⚠ 捕获模式 ⇒ 进 `stderr`（而不是直接写 `$*ERR`）：
    #   这样 `!cmd --numbers` 的行数统计、以及 REPL 里 stdout/stderr
    #   的相对顺序都对（bash 也是两条流分开）。
    # 内层命令的 stderr ⇒ 并进结果（捕获模式）或写终端（直通模式）
    if $INNER-ERR.chars {
        if $capture { $acc-err ~= $INNER-ERR }
        else { try { $*ERR.print($INNER-ERR) } }
        $INNER-ERR = q{};
    }

    my $diag-text = diag-flush();
    if $diag-text.chars {
        if $capture {
            $acc-err ~= $diag-text ~ "\n";
        }
        else {
            try { $*ERR.print($diag-text ~ "\n") };
        }
    }

    if $capture {
        return SlowResult.new(
            :code($code),
            :found($found),
            :passed(True),
            :out($acc-out ~ $acc-err),
            :stdout($acc-out),
            :stderr($acc-err),
        );
    }
    SlowResult.new(:code($code), :found($found))
}