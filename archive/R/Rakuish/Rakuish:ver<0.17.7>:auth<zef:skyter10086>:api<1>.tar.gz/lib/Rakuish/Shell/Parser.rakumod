unit module Rakuish::Shell::Parser;

use Rakuish::Shell::Lexer;

# Rakuish::Shell::Parser —— 外壳层语法（shell-design §4.2）
#
# 移植自 v/shell_parser.v（V 版 176 行）。
#
# 结构（bash 的三层）：
#   一行  →  多个 Pipeline（用 `;` 分隔）
#   Pipeline → 多个 Command（用 `|` 分隔）
#   Command → 若干参数 + 若干重定向
#
# ── 与 V 版的一处结构差异 ──────────────────────────────────────────
# V 版把重定向类型存成 `kind`（enum）与 `kind_i`（int）两份，原因是
# **V 0.5 的 enum 跨模块比较不可靠**（实测 `r.kind == .dup` 恒为假，
# `.dup` 分支从不执行）—— 于是它被迫在构造时多存一份整数。
# Raku 没有这个问题：直接用 Str（'in' / 'out' / 'append' / 'dup'），
# 比较是字符串比较，两个实现上行为一致。**不要**为此再加一份 int。

# 一条重定向。
#   kind    : 'in' | 'out' | 'append' | 'dup' | 'heredoc'
#   target  : 文件名（'dup' 时为空；'heredoc' 时是**分隔符**）
#   fd      : 被重定向的源 fd（`<` 默认 0 = stdin，`>`/`>>` 默认 1 = stdout）
#   dup-fd  : kind='dup' 时的目标 fd（`2>&1` ⇒ fd=2, dup-fd=1）
#   literal : kind='heredoc' 时 —— 分隔符**被引号包住** ⇒ 正文不做展开
#   strip   : kind='heredoc' 时 —— `<<-` ⇒ 去掉正文行首的制表符
class Redirect is export {
    has Str $.kind;
    has Str $.target = q{};
    has Int $.fd = 1;
    has Int $.dup-fd = 2;
    has Bool $.literal = False;
    has Bool $.strip = False;
}

# 一条命令：参数 + 重定向。
class Command is export {
    has List $.args;      # List of Str
    has List $.redirs;    # List of Redirect
}

# 一条流水线。
#
# `op` = **本条流水线前面的连接符**：`&&` / `||` / 空串。
#   · 空串 = 行首，或前面是 `;`（无条件执行）
#   · `&&` = 只在前一条**成功**时执行
#   · `||` = 只在前一条**失败**时执行
# bash 里 `&&` 与 `||` **同优先级、左结合** ⇒ 按顺序判断即可
# （见 HANDOFF §5.3 的说明与 t/36 的断言）。
class Pipeline is export {
    has List $.commands;  # List of Command
    has Bool $.negated = False;   # 前缀 `!` ⇒ 退出码取反
    has Str  $.op = q{};          # 前置连接符：'&&' | '||' | ''
}

# 解析结果。`unsupported` 非空 ⇒ 有我们不原生支持的语法，
# 调用方应把**原样文本**交给真 sh。
class Parsed is export {
    has List $.pipelines;             # List of Pipeline
    has Str  $.unsupported = q{};
}

# ── shell 保留字（控制流）────────────────────────────────
#
# bash 把这些词当作**保留字**：出现在**命令位置**时，后面的 `;`
# `then` `do` 不是普通的「命令分隔符」，而是**复合命令**的一部分。
#
# ⚠ native 后端**不实现控制流**。以前这些行会被当成
#   「一条名叫 `if` 的命令」⇒ spawn 失败 ⇒ stderr 冒
#   `if: command not found` / `then: command not found` / `fi: command not found`（三行噪声），
#   stdout 空、退出码 127 ⇒ **看起来跑了，其实什么都没跑**。
#
# ⇒ 按项目规矩「半懂半猜比不支持更坏」：识别出来就**明确报不支持**
#   （退出码 2 + 「不支持」 + 委托提示），而不是被当成普通命令。
#
# ⚠ 不收 `in`：`in` 只在 `for x in ...` 的**中部**才是保留字，
#   而它作为**第一个词**时可能是用户的命令名 ⇒ 不拦。
# ⚠ 不收 `time`：bash 的 `time` 是关键字，但 `/usr/bin/time` 存在且语义接近 ⇒ 不拦。
our sub reserved-word(Str $w --> Str) is export {
    return $w if $w eq 'if'  or $w eq 'then' or $w eq 'else' or $w eq 'elif'
              or $w eq 'fi'  or $w eq 'case' or $w eq 'esac' or $w eq 'for'
              or $w eq 'while' or $w eq 'until' or $w eq 'do'  or $w eq 'done'
              or $w eq 'select' or $w eq 'function' or $w eq 'coproc';
    q{}
}

# 词是不是纯数字（用于 `2>&1` 的 fd 前缀识别）。
# 注意不能用正则：`$s ~~ /^\d+$/` 在两个实现上都能用，但**纯数字判定**
# 用 `.comb` 更省事，也避免"正则语义两后端可能不同"这条通用坑。
our sub is-digits(Str $s --> Bool) is export {
    return False if $s.chars == 0;
    for $s.comb -> Str $c {
        return False if $c lt '0' or $c gt '9';
    }
    True
}

# ── 主解析 ──────────────────────────────────────────────────────────
our sub parse(List $tokens --> Parsed) is export {
    my @pipes;
    my @args;
    my @redirs;
    my @cmds;
    my $negated = False;
    my $bad = q{};

    my $n = $tokens.elems;
    my $i = 0;
    # 上一个**词**记号（用来判断 fd 前缀是否紧邻操作符，见下面 `2>` 的处理）
    my $prev-tok;

    # ⚠ 短路判断**不在这里做** —— 语法层不知道上一条命令的退出码。
    # 这里只把连接符**记在 Pipeline 上**（`op` 字段），
    # 由执行层（Exec）拿到实际退出码后决定下一条跑不跑。
    # bash 里 `&&` 与 `||` 同优先级、左结合 ⇒ 执行层从左往右扫即可。
    #
    # ⚠ `$pending-op` 是「**下一条** pipeline 的连接符」。
    #   连接符属于它**后面**的那条（`a && b` 里 `&&` 是 b 的前缀），
    #   不是它前面那条 —— 写反了会出现「`false && echo NOPE` 照样打印 NOPE」。
    my $pending-op = q{};

    while $i < $n {
        my $t = $tokens[$i];

        if $t.kind eq 'word' {
            # ── brace 展开（bash 语义）────────────────────────────
            # 一个词可能展开成**多个**词：`{a,b}` → `a` `b`。
            # 展开发生在**变量展开之前**（bash 的顺序），
            # 所以放在语法层（切词之后、展开之前）是对的位置。
            #
            # ⚠ `@args = f()`（**调用**结果）会摊平；写成
            #   `my @t = f(); @args = @t;` 就**不会**摊平（Raku 陷阱，
            #   见 Lexer::brace-expand-text 的说明）。
            for @(brace-expand-text($t.text)) -> $w {
                @args.push: $w;
            }
            $prev-tok = $t;
            $i++;
            next;
        }

        # ── op ────────────────────────────────────────────────────
        my $op = $t.text;

        if $op eq '<' or $op eq '>' or $op eq '>>' {
            # 重定向**属于当前 command** —— 不能在这里 flush，
            # 否则 `echo x >> log` 会把重定向甩给下一个 command。
            my $kind = 'out';
            $kind = 'in'    if $op eq '<';
            $kind = 'append' if $op eq '>>';

            # fd 前缀：紧邻重定向符号的数字 word 是源 fd。
            # 默认值随方向不同 —— `<` 是 stdin(0)，`>`/`>>` 是 stdout(1)。
            # 【V 版实测踩坑】`<` 的默认 fd 必须是 0：写成 1 会让 cat 去读
            # 终端，**抢走 REPL 的下一行输入**。
            #
            # ⚠ bash 规则：fd 前缀必须**紧邻**操作符 ——
            #   `2>file` 的 2 是 fd，而 `echo 2 > file` 里的 2 是**参数**。
            #   判据用 token 的区间：前一个词的 end == 本操作符的 start。
            my $fd = $kind eq 'in' ?? 0 !! 1;
            if @args.elems > 0 and $prev-tok.defined
            and $prev-tok.kind eq 'word' and $prev-tok.end == $t.start {
                my $lastw = @args[*-1];
                if is-digits($lastw) {
                    $fd = $lastw.Int;
                    @args.pop;
                }
            }

            my $target = q{};
            if $i + 1 < $n {
                $i++;
                $target = $tokens[$i].text;
            }
            # brace 展开：`> {a,b}` 在 bash 里是**两个**重定向（后者生效）
            for @(brace-expand-text($target)) -> $tg {
                @redirs.push: Redirect.new(:kind($kind), :target($tg), :fd($fd));
            }
        }

        elsif $op eq '<<' or $op eq '<<-' {
            # heredoc：分隔符是**下一个词**（`<<EOF` / `<<'EOF'` / `<<-EOF`）
            #
            # bash 规则：
            #   · 分隔符被**任何引号**包住 ⇒ 正文**不做展开**（原样）
            #   · `<<-` ⇒ 去掉正文行首的制表符
            #   · 分隔符本身要去掉引号与反斜杠（`<<E"OF"` → `EOF`）
            my $strip = $op eq '<<-';
            my $target = q{};
            my $literal = False;
            if $i + 1 < $n {
                $i++;
                my $raw = $tokens[$i].text;
                $literal = $raw.contains(chr(39)) or $raw.contains(chr(34));
                my @keep;
                for $raw.comb -> $c {
                    next if $c eq chr(39) or $c eq chr(34) or $c eq chr(92);
                    @keep.push: $c;
                }
                $target = @keep.join;
            }
            if $target eq q{} {
                # 没有分隔符 —— bash 是语法错误，我们判不支持
                $bad = 'heredoc without delimiter';
            }
            else {
                @redirs.push: Redirect.new(:kind('heredoc'), :target($target),
                                           :fd(0), :literal($literal),
                                           :strip($strip));
            }
        }

        elsif $op eq '>&' or $op eq '<&' {
            # `2>&1` / `>&2` —— 源 fd 取自紧邻的数字前缀。
            # 无前缀时：`>&` 默认 fd=1（stdout）→ dup-fd=2；
            #           `<&` 默认 fd=0（stdin）。
            #
            # ⚠ 前缀必须**紧邻**（bash 规则）：`2>&1` 的 2 是 fd，
            #   而 `ls 2 >&1` 里的 2 是**参数**。判据同 `>` 分支。
            my $fd = $op eq '<&' ?? 0 !! 1;
            if @args.elems > 0 and $prev-tok.defined
            and $prev-tok.kind eq 'word' and $prev-tok.end == $t.start {
                my $lastw = @args[*-1];
                if is-digits($lastw) {
                    $fd = $lastw.Int;
                    @args.pop;
                }
            }
            my $dst = 2;
            if $i + 1 < $n {
                $i++;
                my $nxt = $tokens[$i].text;
                $dst = is-digits($nxt) ?? $nxt.Int !! 2;
            }
            @redirs.push: Redirect.new(:kind('dup'), :target(q{}), :fd($fd), :dup-fd($dst));
        }

        elsif $op eq '&>' or $op eq '&>>' {
            # `cmd &> f` = `> f 2>&1`（展开成两条，简化执行器）
            my $kind = $op eq '&>>' ?? 'append' !! 'out';
            my $target = q{};
            if $i + 1 < $n {
                $i++;
                $target = $tokens[$i].text;
            }
            for @(brace-expand-text($target)) -> $tg {
                @redirs.push: Redirect.new(:kind($kind), :target($tg), :fd(1));
            }
            @redirs.push: Redirect.new(:kind('dup'), :target(q{}), :fd(2), :dup-fd(1));
        }

        elsif $op eq '!' {
            $negated = True;
        }

        elsif $op eq ';' or $op eq '|' or $op eq '&&' or $op eq '||' {
            # 这里才结束当前 command
            if @args.elems > 0 or @redirs.elems > 0 {
                # ⚠ 必须**先拷贝再传**。`:args(@args)` 里的 `@args` 是
                # **后期绑定**的：命名实参保存的是**变量**而不是当时的值，
                # 于是所有 Command 最后都看到同一份（最后一份）参数 ——
                # 症状是管道里两段命令跑成了同一条。
                # 实测两个后端行为一致。`my @x = @y;` 是真拷贝。
                my @a-snap = @args;
                my @r-snap = @redirs;
                # ⚠ 0.17.0（§10.2-2）：命令位置出现 **shell 保留字**（控制流）
                #   ⇒ 整行判「不支持」（不是当成普通命令跑出一堆
                #   `command not found`）。详见 `reserved-word` 的说明。
                if @a-snap.elems {
                    my $rw = reserved-word(@a-snap[0].Str);
                    $bad = 'shell 保留字（控制流）：' ~ $rw if $rw ne q{};
                    # bash 的算术命令 `(( … ))` 也是保留语法 ⇒ 明确报不支持
                    $bad = 'shell 算术命令：(( … ))' if @a-snap[0].Str.starts-with('((');
                }
                @cmds.push: Command.new(:args(@a-snap), :redirs(@r-snap));
            }
            @args = ();
            @redirs = ();

            # `|` 只是管道内部的连接（同一批 commands 继续攒），
            # `;` / `&&` / `||` 才结束一条 pipeline。
            if $op ne '|' {
                if @cmds.elems > 0 {
                    my @c-snap = @cmds;      # 同上：先拷贝（后期绑定的坑）
                    @pipes.push: Pipeline.new(:commands(@c-snap),
                                             :negated($negated),
                                             :op($pending-op));
                }
                @cmds = ();
                $negated = False;
                # 连接符属于**下一条** pipeline。
                # `;` 之后的下一条是无条件执行 ⇒ op 清空。
                $pending-op = ($op eq '&&' or $op eq '||') ?? $op !! q{};
            }
        }

        else {
            # 其余 op（`<<` `>>>` `&` …）我们不原生实现 → 整段判不支持
            $bad = 'unsupported operator: ' ~ $op;
        }

        # 「前一个记号」= 本操作符自己（下一个记号要拿它判断 fd 前缀是否紧邻）
        $prev-tok = $t;
        $i++;
    }

    # 收尾
    if @args.elems > 0 or @redirs.elems > 0 {
        my @a-snap = @args;
        my @r-snap = @redirs;
        if @a-snap.elems {
            my $rw = reserved-word(@a-snap[0].Str);
            $bad = 'shell 保留字（控制流）：' ~ $rw if $rw ne q{};
            $bad = 'shell 算术命令：(( … ))' if @a-snap[0].Str.starts-with('((');
        }
        @cmds.push: Command.new(:args(@a-snap), :redirs(@r-snap));
    }
    if @cmds.elems > 0 {
        my @c-snap = @cmds;              # 同上：先拷贝
        @pipes.push: Pipeline.new(:commands(@c-snap),
                                   :negated($negated), :op($pending-op));
    }

    my @p-snap = @pipes;                # 同上：先拷贝
    Parsed.new(:pipelines(@p-snap), :unsupported($bad))
}
