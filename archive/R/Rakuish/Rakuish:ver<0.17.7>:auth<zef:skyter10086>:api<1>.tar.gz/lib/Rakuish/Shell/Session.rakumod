unit module Rakuish::Shell::Session;

use NativeCall;

# `use NativeCall` 只为了 `c-getpid`（`$$` 的值）——
# `getpid()` 是**无害**的 libc 调用（不会野指针、不会崩），
# 真正危险的是 Exec 里的 pipe/dup2/posix_spawnp 那一批。

# Rakuish::Shell::Session —— 外壳层的**会话状态**（shell 变量表 + 退出码）
#
# 移植自 v/rakuish.v 的 `Session.vars`（V 版第 81-87 行）。
#
# ── 为什么需要它 ────────────────────────────────────────────────────
# 改造前（本项目第一版）所有 shell 命令都交给 `sh -c`，于是
# `export FOO=bar` 之后 `echo $FOO` 是**空的** —— 因为每行是一次
# 独立的 `sh -c` 进程，export 改的是那个进程的环境，随进程一起消失。
# V 版为此引入了 `Session.vars`：变量存在**宿主进程**里，跨行存活。
# 本模块是那个设计的 Raku 版。
#
# ── 两张表，为什么 ──────────────────────────────────────────────────
# · `%VARS`  —— 会话变量（REPL 自己的状态）。跨行存活。
# · `%*ENV`  —— **镜像**。Raku 侧的 `$*ENV` / `%*ENV` 直接读它，
#              所以 REPL 里写的 Raku 代码立刻能看到 shell 变量；
#              反过来，Raku 侧改 `%*ENV` 也立刻被 shell 层看到。
#              这一条是「字符串桥」（DESIGN §4）的实现方式。
#
# ⚠ 两后端差异（HANDOFF §4.1 的同类坑，**实测**）：
#   · MoarVM：`%*ENV` 与**进程真实环境**是同一份 ⇒ 写 `%*ENV` 会
#     让子进程（`run` / `posix_spawnp`）看到它。
#   · rakupp：`%*ENV` 与进程真实环境**不是同一份** ⇒ 写 `%*ENV`
#     **不会**让子进程看到。
#   → 所以「让子进程看到会话变量」这件事**不能靠 `%*ENV`**，
#     必须**显式构造 envp** 传给 `posix_spawnp`（见 Exec）。
#     本模块只负责「记录 + 镜像」，不负责 spawn。
#
# ── 为什么变量名要校验 ──────────────────────────────────────────────
# 环境变量的名字只允许 `[A-Za-z_][A-Za-z0-9_]*`。不合规的名字
# **静默丢弃**（不报错）—— 因为 shell 里 `1BAD=x` 本来就是语法错误，
# 而我们不实现 shell 的语法报错体系。静默丢弃比崩掉好。

# 会话变量表。`our` = 模块级，跨 cell 存活（REPL 每格都重新 EVAL，
# 但模块状态是全局的，不受 EVAL 作用域影响）。
our %VARS is export = Hash.new;

# ── 被显式 unset 掉的变量名（P2 的 env 下行同步用）──────────────────
#
# 为什么需要它：宿主把会话变量**下传**给引擎（`--env-in`）时，
# "设置"可以用 `K=V` 表达，"删除"没法表达 —— 引擎是个**新进程**，
# 它从父进程继承了整个环境；宿主 `unset FOO` 之后必须让引擎也把它删掉，
# 否则下一行 `!echo $FOO` 又从继承来的环境里读到旧值（实测会这样）。
# 所以 unset-var 在这里留一条记录，Engine 下传时写成 `-FOO`。
# set-var 会清掉这条记录（重新设置 ⇒ 不再是"已删除"）。
our %REMOVED is export = Hash.new;

# 变量名合法吗？（POSIX / bash 规则）
our sub valid-name(Str $name --> Bool) is export {
    return False if $name.chars == 0;
    my $first = $name.substr(0, 1);
    return False if not (($first ge 'a' and $first le 'z')
                      or ($first ge 'A' and $first le 'Z')
                      or $first eq '_');
    for $name.comb -> Str $c {
        next if ($c ge 'a' and $c le 'z');
        next if ($c ge 'A' and $c le 'Z');
        next if ($c ge '0' and $c le '9');
        next if $c eq '_';
        return False;
    }
    True
}

# 记一个会话变量，并镜像进 `%*ENV`。
#
# 返回 False 表示**名字不合法被丢弃**（不抛错）。
#
# ⚠ `%*ENV` 的 key **不能加引号**：`%*ENV<'KEY'>` 会**静默失效**
#   （HANDOFF §4.2 坑 16）。用**动态 key** 赋值
#   （`%*ENV{$name} = $value`）两个后端都正常（实测）。
our sub set-var(Str $name, Str $value --> Bool) is export {
    return False unless valid-name($name);
    %VARS{$name} = $value;
    %REMOVED{$name}:delete;      # 重新设置 ⇒ 撤销"已删除"记录
    my $w = try { %*ENV{$name} = $value; True };
    if $! {
        # 镜像失败**不影响会话变量本身**（会话表才是权威）。
        # 记录到 stderr 会污染 REPL 输出，所以只静默忽略。
    }
    True
}

# ── 查表：会话变量优先，再退到 %*ENV ──────────────────────────────
#
# `$over` 是**影子表**（预扫描时用来模拟「假如这条命令按顺序跑完，
# 变量会是什么」）—— 见 Exec 的两遍扫描说明。
#
# 为什么要影子表：预扫描要判断「这一行能不能原生跑」，但判断本身
# 需要展开参数（要看命令名、要看 glob 支不支持）—— 而展开的结果
# 取决于**同一条命令里更早的 export 设了什么**。
#   `export CMD=ls && $CMD`  →  `$CMD` 展开成 `ls`（不是空）
# → 预扫描时用一个影子表模拟 export 的效果，真跑的时候用真表。
#
# ⚠ 判断「在不在表里」要用 `EXISTS-KEY` 而不是「值非空」——
#   `export FOO=` 明确设成空串时，不该退回 `%*ENV` 拿旧值
#   （bash 语义：显式设空就是空）。
our sub lookup(Str $name, Hash $over = Hash.new --> Str) is export {
    if $over.EXISTS-KEY($name) {
        my $v = $over{$name};
        return q{} unless $v.defined;
        return $v.Str;
    }
    if %VARS.EXISTS-KEY($name) {
        my $v = %VARS{$name};
        return q{} unless $v.defined;
        return $v.Str;
    }
    my $e = %*ENV{$name};
    return q{} unless $e.defined;
    $e.Str
}

# 读一个会话变量（未定义 → 空串）。
#
# 为什么要退到 `%*ENV`：`export NAME`（不带值）的语义是「把**已有**的
# 变量导出」—— 而「已有」可能指从父进程继承来的（只在 `%*ENV` 里，
# 不在会话表里）。只查会话表的话，`export INHERITED` 会把它的值
# **清成空串**（实测：设了 preset，export 之后变成空）。
our sub get-var(Str $name --> Str) is export {
    lookup($name)
}

# ── 这个变量「设置」了吗？───────────────────────────────────────
#
# bash 区分「**没设置**」与「**设置成空**」：
#   unset V; echo "[${V:-d}]"  →  [d]   （没设置 → 用默认值）
#   V=;     echo "[${V:-d}]"  →  [d]   （设置成空 → 也用默认值，`:-` 看「空」）
#   V=;     echo "[${V-d}]"   →  []    （但 `-` 只看「没设置」）
#   V=;     echo "[${V+r}]"   →  [r]   （设置了就是设置了，空也算）
#
# → 参数展开的 `:?` `?` `:+` `+` 全都靠它。
#
# 判据是「键在不在表里」，不是「值非空」——
# `export FOO=` 明确设成空串时，它就是「设置了的空值」。
our sub is-set(Str $name, Hash $over = Hash.new --> Bool) is export {
    return True if $over.EXISTS-KEY($name);
    return True if %VARS.EXISTS-KEY($name);
    %*ENV.EXISTS-KEY($name)
}

# 删一个会话变量（并从 `%*ENV` 镜像里删掉）。
our sub unset-var(Str $name --> Bool) is export {
    return False unless valid-name($name);
    %VARS{$name}:delete;
    %REMOVED{$name} = True;      # 记一笔，下传给引擎时变成 `-NAME`
    try { %*ENV{$name}:delete };
    True
}

# 会话里有哪些变量？（给 `%STORE` / 调试用）
#
# ⚠ **不要写 `--> List`**：`.keys` 返回的是 Seq，标成 List 会报
#   "Type check failed for return value; expected List but got Seq"
#   （实测 MoarVM 上如此；rakupp 对容器返回标注也不兼容 ——
#   HANDOFF §4.2 坑 15 记过同一类问题）。
our sub var-names() is export {
    %VARS.keys.sort
}

# 清空会话（测试用；REPL 里对应 `%repl off` 之类的新会话）。
#
# ⚠ **不要用 `%VARS.clear`** —— Hash 上没有 `clear` 方法
#   （实测两个后端都报 "No such method 'clear' for invocant of type 'Hash'"）。
#   逐个 `:delete` 才两个后端都支持。
our sub clear-vars(--> Nil) is export {
    for %VARS.keys -> Str $k {
        %VARS{$k}:delete;
    }
    for %*ENV.keys -> Str $k {
        next unless $k.starts-with('RK_');   # 只清我们自己造的镜像
        %*ENV{$k}:delete;
    }
    for %REMOVED.keys -> Str $k { %REMOVED{$k}:delete }
    Nil
}

# ── 赋值词识别：NAME=VALUE ────────────────────────────────────────
#
# 返回 Nil（不是赋值）或一个 Pair（name / 原始 value 部分）。
#
# ⚠ 必须**按原始词**判断，不能先展开：
#   `FOO="a b"` 展开后是 `FOO=a b`，再切 `=` 会把值切成 `a`（错）。
#   而 `'FOO=bar'`（整体带引号）在 bash 里**不是**赋值（是字面量）。
#   → 先切出 name（未展开），确认它合法，再把 value 部分交给展开层。
#
# name 的合法性由 valid-name 把关：它会拒掉引号、`$`、空格等，
# 于是「整体带引号」的情形自动被排除（`valid-name("'FOO")` = False）。
our sub assignment-parts(Str $raw --> Any) is export {
    my $eq = $raw.index('=');
    return Nil unless $eq.defined;
    return Nil if $eq == 0;
    my $name = $raw.substr(0, $eq);
    return Nil unless valid-name($name);
    ($name, $raw.substr($eq + 1))
}

# 这个词是赋值词吗？（`FOO=bar` → True；`FOO` → False；`'FOO=bar'` → False）
our sub is-assignment(Str $raw --> Bool) is export {
    assignment-parts($raw).defined
}

# ══════════════════════════════════════════════════════════════════════
# 会话退出码（`$?`）与 shell PID（`$$`）
# ══════════════════════════════════════════════════════════════════════
#
# ── `$?`：上一条命令的退出码 ──────────────────────────────────────
#
# bash 语义：`$?` 是**最近执行过的那条命令**的退出状态。
# 「最近执行过」指的是**每一条 pipeline**（不是每一行）：
#   false && echo $?     →  echo 根本不执行（短路）
#   false; echo $?       →  1
#   false || echo $?     →  1（echo 执行了，但 `$?` 此刻还是 false 的 1）
#   false && true; echo $?  →  1（true 没执行，退出码还是 false 的）
#
# → 所以退出码必须在**每条 pipeline 执行完**就更新（见 Exec 的执行遍），
#   而不是「一行结束时」更新。
#
# ⚠ 会话里存的是**状态**，不是「每行重置」—— bash 的 `$?` 跨命令存活，
#   REPL 里下一格仍然看得到上一条命令的退出码。
our $LAST-STATUS = 0;

our sub set-last-status(Int $code) is export {
    $LAST-STATUS = $code;
}

our sub last-status(--> Int) is export {
    $LAST-STATUS
}

# ── `$$`：shell 的 PID ─────────────────────────────────────────────
#
# bash 的 `$$` 是**那个 shell 进程**的 PID。对 Rakuish 来说，
# 「shell 进程」就是 Rakuish 自己 ⇒ `$$` = Rakuish 进程的 PID，
# 在整个会话里**恒定**（不像 sh 子进程那样每次都变）。
#
# ⚠（历史）曾与 sh 回退路径对齐：整行交 sh 时，sh 会把 `$$` 展开成
#   **它自己**（子进程）的 PID —— 那样同一个值在两条路径上就变了。
#   → Exec 在把行交给 sh 之前，会把 `$$` 换成 Rakuish 的 PID 字面量
#     （见 Exec 的 prepare-for-sh）。
#
# `c-getpid` 的写法：**必须两个独立 trait**（`is native is symbol<...>`）。
sub c-getpid() is native is symbol<getpid> returns int32 { * }

# PID 缓存（进程生命周期内不变，算一次就够）。
our $SHELL-PID = 0;

our sub shell-pid(--> Int) is export {
    if $SHELL-PID == 0 {
        $SHELL-PID = c-getpid();
    }
    $SHELL-PID
}
