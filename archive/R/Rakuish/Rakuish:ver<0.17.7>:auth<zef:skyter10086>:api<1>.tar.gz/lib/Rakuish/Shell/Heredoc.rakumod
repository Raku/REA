unit module Rakuish::Shell::Heredoc;

use Rakuish::Shell::Lexer;
use Rakuish::Shell::Parser;

# Rakuish::Shell::Heredoc —— heredoc 的**识别**（纯逻辑，无 libc 调用）
#
# ⚠⚠ **为什么单独一个模块**：
#   `Shell::Exec` 是整个项目里**唯一**做裸 libc 调用的地方
#   （pipe / dup2 / posix_spawnp / malloc / waitpid …）——
#   一个野指针就是**段错误**，会把整个 REPL 带走。
#
#   REPL 侧只需要「这一行有没有 heredoc、正文到哪结束」这两件事
#   （用来决定要不要**接着读正文行**）—— 纯词法，**不需要**执行层。
#
#   → 把这两个函数挪到这里，REPL 就**不必加载 Exec** ⇒
#     REPL 进程里一行 libc 调用都没有 ⇒ 引擎崩了也带不走它 ✓
#
#   （引擎侧照旧 `use` 这个模块 —— 那边本来就该有 libc 调用。）

# 一条 heredoc 的描述：分隔符 + 两个开关。
class HeredocSpec is export {
    has Str  $.delim = q{};
    has Bool $.literal = False;   # 分隔符带引号 → 正文**不**展开
    has Bool $.strip = False;     # `<<-` → 去掉正文行首的制表符
}

# 这一行里有哪几个 heredoc？（按出现顺序）
our sub heredoc-specs(Str $line) is export {
    my $t = $line.trim;
    return () unless $t.chars;
    my $lexed = lex($t, :cmdsub(True));
    return () if $lexed.unsupported ne q{};
    my $parsed = parse($lexed.tokens);
    return () if $parsed.unsupported ne q{};
    my @specs;
    for @($parsed.pipelines) -> $pl {
        for @($pl.commands) -> $cmd {
            for @($cmd.redirs) -> $r {
                next unless $r.kind eq 'heredoc';
                @specs.push: HeredocSpec.new(:delim($r.target),
                                             :literal($r.literal),
                                             :strip($r.strip));
            }
        }
    }
    @specs
}

# 这一行是不是某条 heredoc 的**结束行**？
our sub heredoc-end(Str $line, HeredocSpec $spec --> Bool) is export {
    my $t = $line;
    # `<<-` 允许结束行用制表符缩进（bash 规则）
    $t = $t.substr(1) while $spec.strip and $t.starts-with("\t");
    $t.trim eq $spec.delim
}
