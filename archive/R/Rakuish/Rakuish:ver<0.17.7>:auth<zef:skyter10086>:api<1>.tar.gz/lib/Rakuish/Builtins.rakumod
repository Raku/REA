unit module Rakuish::Builtins;

use Rakuish::Shell::Session;
use Rakuish::Shell::Engine;

# Rakuish::Builtins —— **宿主侧内建**（P2）
#
# ── 为什么内建必须归宿主 ────────────────────────────────────────────
# 以前 shell 内建一律交给引擎（真 bash / native 都一样），于是：
#     export FOO=1        ← 改的是引擎进程的环境，引擎一退就没了
#     cd /tmp             ← 改的是引擎进程的 cwd，REPL 还站在原地
# 这些内建的本质是「改会话状态」，而**持有会话的是 REPL 进程**。
# 谁拥有会话谁实现内建 —— 这是 PLAN-C §6 的第一原则。
#
# ── 拦截判据（保守：只拦能整行解释的）────────────────────────────
# 带组合语法的行（`export A=1 && echo $A`、`cd /tmp; ls`）**不拦**，
# 交回引擎 —— 那些行的语义由 bash 自己拼装，我们只照看"单个简单命令"。
# 宁可少拦，不可拦错。
#
# ── 与 DSL prelude 的关系 ──────────────────────────────────────────
# `pwd` / `test` / `type` 在 Raku 表达式里也有同名 sub（Eval 的 prelude
# 转发到本模块的 `pwd` / `test-args` / `type-of`）。两条入口共用一份
# 实现，语义不会漂。

# ── 别名表（会话态）────────────────────────────────────────────────
our %ALIASES is export = Hash.new;

# 组合语法 / 重定向 / 展开的元字符：命中任意一个就不归宿主管。
# ⚠ `$` 与 `~` **不在**黑名单里：`cd $HOME` / `cd ~/src` 是内建该管的事，
#   宿主自己做这两个字面的展开（`expand-arg`），不必因为一个 `$` 就把
#   整行交给引擎 —— 交给引擎就等于 `cd` 又白做了（子进程改不了父进程的 cwd）。
#   `$(…)` / 反引号 / `|` / `;` / 重定向仍然是硬边界。
#
# ⚠ `[` / `]` 也**不在**这里：`[ -d /tmp ]` 的 `[` 是命令名（test 的别名），
#   不是 glob。若把它们当元字符，`[` 内建永远进不了宿主。
#   glob 的 `*` / `?` 仍然挡着，`a[bc]` 这种少见形态漏给引擎也无害 ——
#   它只会让"不是内建的行"走引擎，本来就是默认路径。
my constant META-CHARS = ('|', '&', ';', '<', '>', '(', ')', '{', '}',
                          '`', '*', '?', '#');

# 简单命令？（整行只有一个命令、引号外没有组合语法）
our sub has-shell-ops(Str $line --> Bool) is export {
    my $in-s = False;
    my $in-d = False;
    for $line.comb -> Str $c {
        if $in-s {
            $in-s = False if $c eq q{'};
            next;
        }
        if $in-d {
            $in-d = False if $c eq q{"};
            next;
        }
        if $c eq q{'} { $in-s = True; next }
        if $c eq q{"} { $in-d = True; next }
        return True if $c (elem) META-CHARS;
    }
    # 引号没闭合：交给引擎（它的报错更准）
    $in-s or $in-d ?? True !! False
}

# ── 按 shell 规则切词（够用即可：空格分隔 + 去引号）─────────────────
#
# ⚠ 不做变量展开、不做 glob —— 那些由引擎负责；宿主内建的参数
#   只需要"人写的字面量"。
our sub split-words(Str $line --> List) is export {
    my @w;
    my $cur = q{};
    my $have = False;
    my $in-s = False;
    my $in-d = False;
    for $line.comb -> Str $c {
        if $in-s {
            if $c eq q{'} { $in-s = False } else { $cur ~= $c }
            $have = True;
            next;
        }
        if $in-d {
            if $c eq q{"} { $in-d = False } else { $cur ~= $c }
            $have = True;
            next;
        }
        if $c eq q{'} { $in-s = True; $have = True; next }
        if $c eq q{"} { $in-d = True; $have = True; next }
        if $c eq q{ } or $c eq "\t" {
            if $have { @w.push($cur); $cur = q{}; $have = False }
            next;
        }
        $cur ~= $c;
        $have = True;
    }
    @w.push($cur) if $have;
    @w.List
}

# ── 单字面量展开：`~` 与 `$VAR` / `${VAR}` ──────────────────────────
#
# 只做**能确定的**那两件事：开头的 `~` 换成 $HOME，`$NAME` / `${NAME}`
# 换成会话变量的值。`$(…)`、反引号、`${VAR:-default}` 这类需要 shell
# 语法的一律不认（那类行在 has-shell-ops 那关就被挡下了）。
our sub expand-arg(Str $w --> Str) is export {
    my $s = $w;

    if $s eq '~' {
        return (%*ENV<HOME> // q{});
    }
    if $s.starts-with('~/') {
        $s = (%*ENV<HOME> // q{}) ~ $s.substr(1);
    }

    # `${NAME}` 先做：否则 `$` 后跟 `{` 会被当成"普通的 $ 后又接了花括号"
    # ⚠ 用 `(\w+)` 而不是手写字符类：`<[A..Z a..z 0..9 _]>` 在 MoarVM 上
    #   只能吃到首字母（实测 `$RK_DEBUG` 只捕获到 `R`），`\w` 没这毛病。
    $s = $s.subst(/'$' '{' $<n>=(\w+) '}'/,
                  { lookup($<n>.Str) }, :g);

    # `$NAME`（只认单词字符，遇到 `{` / `/` / `:` 就停）
    $s = $s.subst(/'$' $<n>=(\w+)/,
                  { lookup($<n>.Str) }, :g);

    $s
}

# ── 内建白名单 ─────────────────────────────────────────────────────
#
# 只列**改会话状态**或**纯宿主可算**的那几个；`echo` / `printf` 之类
# 不在此列（引擎做得好，没必要搬）。
# `true` / `false` **不搬**：它们不改会话状态，引擎一次 fork 就够了，
# 搬过来反而会让 `!false` 失去「退出码摘要行」（实测 t/04 会红）。
my constant BUILTIN-NAMES = ('cd', 'pwd', 'export', 'unset', 'alias',
                             'unalias', 'type', 'exit', 'read', 'source',
                             '.', 'test', '[');

# 补全用：内建名列表。P3 把 `!` 行首的候选从「只有 PATH 命令」扩到
# 「PATH 命令 + 内建 + 别名」—— 内建和别名确实能当命令敲，缺了就是漏。
our sub builtin-names(--> List) is export {
    BUILTIN-NAMES.List
}

# 这一行的第一个词是哪个内建？（不是内建 ⇒ 空串）
our sub builtin-name(Str $line --> Str) is export {
    return q{} if $line.trim eq q{};
    return q{} if has-shell-ops($line);
    my @w = split-words($line);
    return q{} unless @w.elems;
    my $first = @w[0];
    return $first if $first (elem) BUILTIN-NAMES;
    q{}
}

# ── 别名展开 ───────────────────────────────────────────────────────
#
# `hi` → `echo hello`：只在**简单命令**上做；只展开一层（bash 同样）。
our sub expand-alias(Str $line --> Str) is export {
    return $line if $line.trim eq q{};
    return $line if has-shell-ops($line);
    my @w = split-words($line);
    return $line unless @w.elems;
    my $first = @w[0];
    return $line unless %ALIASES.EXISTS-KEY($first);
    my $body = %ALIASES{$first}.Str;
    my $rest = $line.trim.substr($first.chars).trim;
    $rest eq q{} ?? $body !! $body ~ ' ' ~ $rest
}

# ══════════════════════════════════════════════════════════════════════
# 各内建实现
# ══════════════════════════════════════════════════════════════════════

# ── pwd ────────────────────────────────────────────────────────────
our sub pwd(--> Str) is export {
    $*CWD.absolute.Str
}

# ── cd ─────────────────────────────────────────────────────────────
our sub cd-into(Str $arg --> Hash) is export {
    my $home = (%*ENV<HOME> // q{});
    my $t = $arg.trim;
    my $target;

    # `cd -`：回上一个目录，并把目标路径**打印出来**（bash 行为）
    if $t eq '-' {
        my $old = (%*ENV<OLDPWD> // q{});
        return { code => 1, out => q{}, err => 'cd: OLDPWD 没设置' } if $old eq q{};
        $target = $old;
    }
    else {
        $target = $t eq q{} ?? $home !! $t;
    }
    return { code => 1, out => q{}, err => 'cd: HOME 没设置' } if $target eq q{};

    my $here = $*CWD.absolute.Str;
    # ⚠ **归一化**（0.16.3 修）：拼出来的字面路径带 `..` 与重复斜杠
    #   （`cd ..` ⇒ `/home/zby/..`），而 CORE `chdir` 会**原样**把它写进 `$*CWD`
    #   ⇒ 提示符与 `PWD` 一直是脏路径。`.resolve` 消掉 `.` / `..` / 重复斜杠，
    #   符号链接按实际位置解析（与内核 chdir 的落点一致）。
    my $raw-want = $target.IO.is-absolute ?? $target.IO !! $*CWD.add($target);
    my $want = (try $raw-want.resolve) // $raw-want;

    unless $want.e {
        return { code => 1, out => q{}, err => "cd: 没有这个目录：{$target}" };
    }
    unless $want.d {
        return { code => 1, out => q{}, err => "cd: 不是目录：{$target}" };
    }

    my $abs = $want.Str;          # 已经是归一化后的绝对路径
    my $ok = try { chdir($abs); True };
    unless $ok {
        return { code => 1, out => q{}, err => "cd: 进不去：{$target}" };
    }

    # PWD / OLDPWD 要同步进 %*ENV：引擎是子进程，靠继承拿这两个值。
    # ⚠ 用**动态 key** 赋值（字面 key 在 rakupp 上会静默失效）。
    my $k-old = 'OLDPWD';
    my $k-pwd = 'PWD';
    %*ENV{$k-old} = $here;
    %*ENV{$k-pwd} = $abs;

    # 输出对齐改造前的 `change-dir`：「cd → /tmp」（人看的，脚本模式里静音）。
    { code => 0, out => 'cd → ' ~ $abs, err => q{}, ui => True }
}

# ── export ─────────────────────────────────────────────────────────
#
# 支持：`export`（列全部）/ `export -p` / `export NAME=V` /
# `export NAME`（把已有值导出）/ 多个参数。
our sub export-vars(*@args --> Hash) is export {
    my @a = @args>>.Str;
    if !@a.elems or (@a.elems == 1 and @a[0] eq '-p') {
        my @lines;
        for var-names() -> $k {
            @lines.push: 'export ' ~ $k ~ '="' ~ get-var($k) ~ '"';
        }
        return { code => 0, out => @lines.join("\n"), err => q{} };
    }
    my @err;
    my $code = 0;
    for @a -> $item {
        next if $item eq '-p' or $item eq '-n';
        my $eq = $item.index('=');
        if $eq.defined and $eq > 0 {
            my $name = $item.substr(0, $eq);
            my $val  = $item.substr($eq + 1);
            unless valid-name($name) {
                @err.push: "export: 不是合法的变量名：{$name}";
                $code = 1;
                next;
            }
            set-var($name, $val);
            next;
        }
        unless valid-name($item) {
            @err.push: "export: 不是合法的变量名：{$item}";
            $code = 1;
            next;
        }
        # `export NAME`：值从会话表 / %*ENV 里取（可能压根没有 ⇒ 空串）
        set-var($item, get-var($item));
    }
    { code => $code, out => q{}, err => @err.join("\n") }
}

# ── unset ──────────────────────────────────────────────────────────
our sub unset-vars(*@args --> Hash) is export {
    my @a = @args>>.Str;
    my @err;
    my $code = 0;
    for @a -> $item {
        next if $item eq '-v' or $item eq '-f';
        unless valid-name($item) {
            @err.push: "unset: 不是合法的变量名：{$item}";
            $code = 1;
            next;
        }
        unset-var($item);
    }
    { code => $code, out => q{}, err => @err.join("\n") }
}

# ── alias / unalias ────────────────────────────────────────────────
our sub dequote(Str $s --> Str) is export {
    my $t = $s.trim;
    return $t.substr(1, $t.chars - 2)
        if $t.chars > 1 and (($t.starts-with(q{'}) and $t.ends-with(q{'}))
                          or ($t.starts-with(q{"}) and $t.ends-with(q{"})));
    $t
}

our sub alias-def(*@args --> Hash) is export {
    my @a = @args>>.Str;
    if !@a.elems {
        my @lines;
        for %ALIASES.keys.sort -> $k {
            @lines.push: "alias {$k}='{%ALIASES{$k}}'";
        }
        return { code => 0, out => @lines.join("\n"), err => q{} };
    }
    my @err;
    my @out;
    my $code = 0;
    for @a -> $item {
        my $eq = $item.index('=');
        if $eq.defined and $eq > 0 {
            my $name = $item.substr(0, $eq);
            my $body = dequote($item.substr($eq + 1));
            %ALIASES{$name} = $body;
            next;
        }
        if %ALIASES.EXISTS-KEY($item) {
            @out.push: "alias {$item}='{%ALIASES{$item}}'";
        }
        else {
            @err.push: "alias: 没有这个别名：{$item}";
            $code = 1;
        }
    }
    { code => $code, out => @out.join("\n"), err => @err.join("\n") }
}

our sub unalias-def(*@args --> Hash) is export {
    my @a = @args>>.Str;
    return { code => 0, out => q{}, err => q{} } if @a.elems == 1 and @a[0] eq '-a';
    my @err;
    my $code = 0;
    for @a -> $item {
        if %ALIASES.EXISTS-KEY($item) {
            %ALIASES{$item}:delete;
        }
        else {
            @err.push: "unalias: 没有这个别名：{$item}";
            $code = 1;
        }
    }
    { code => $code, out => q{}, err => @err.join("\n") }
}

# ── type ───────────────────────────────────────────────────────────
our sub type-of(Str $word --> Str) is export {
    if %ALIASES.EXISTS-KEY($word) {
        return "{$word} 是别名 → `{%ALIASES{$word}}`";
    }
    return "{$word} 是 shell 内建" if $word (elem) BUILTIN-NAMES;
    # ⚠ 是 `%*ENV`（哈希）不是 `$*ENV`：后者是"标量动态变量"，根本不存在，
    #   取下标会抛 "Dynamic variable $*ENV not found"。
    my $path = %*ENV<PATH> // q{};
    for $path.split(':') -> $dir {
        next if $dir eq q{};
        my $cand = $dir.IO.add($word);
        if $cand.e and $cand.f and $cand.x {
            return $cand.absolute.Str;
        }
    }
    q{}
}

# ── exit ───────────────────────────────────────────────────────────
our sub finish-exit(*@args --> Hash) is export {
    my @a = @args>>.Str;
    return { code => 0, out => q{}, err => q{}, quit => True } unless @a.elems;
    my $n = @a[0];
    unless $n ~~ /^ '-'? \d+ $/ {
        return { code => 2, out => q{},
                 err => "exit: {$n}：需要数字参数", quit => True };
    }
    my $code = $n.Int % 256;
    { code => $code, out => q{}, err => q{}, quit => True }
}

# ── read ───────────────────────────────────────────────────────────
#
# ⚠ 0.16.7（§10.1 #11）：`read -p` 的提示语语义。
#
# bash 的口径：
#   · 提示语写 **stderr**（不是 stdout）；
#   · 只有 **stdin 是终端**时才打印（非交互不打印）。
#
# 抽成独立函数的原因：`$*IN.t` 在测试里**总是 False**
#（测试进程没有 tty）——如果写在 `read-into` 里面，
# “tty 要打印”那一分支就**永远跟不到**（覆盖率为 0）。
our sub read-prompt-text(Str $prompt, Bool $t --> Str) is export {
    return q{} unless $prompt.chars and $t;
    $prompt
}

# 从标准输入读一行，按 IFS 切词后写进会话变量。
# REPL 的输入来自行编辑器（不是 $*IN），所以这个内建主要给**脚本**用
#（`rakuish run.rakuish < data.txt`）——与 bash 一致。
our sub read-into(*@args --> Hash) is export {
    my @a = @args>>.Str;
    my $prompt = q{};
    my @names;
    my $i = 0;
    while $i < @a.elems {
        my $w = @a[$i];
        if $w eq '-p' and $i + 1 < @a.elems {
            $prompt = @a[$i + 1];
            $i += 2;
            next;
        }
        if $w eq '-r' {
            $i++;
            next;
        }
        @names.push: $w;
        $i++;
    }
    # ⚠ 0.16.7（§10.1 #11）：提示语写 **stderr**（bash 语义：
    #   `read -p` 的提示语写到 stderr，不是 stdout）
    #   —— 以前写 stdout ⇒ `rakuish x.rakuish > out.txt` 时
    #   **提示语进了结果文件**，而不是留在终端上。
    # ⚠ 而且**只在 stdin 是终端时**打印（bash 语义：非交互不打印提示语）
    #   —— 实测 bash：`printf 'x\n' | bash -c 'read -p "P: " v'` ⇒ **不打印**。
    my $shown = read-prompt-text($prompt, $*IN.t);
    $*ERR.print($shown) if $shown.chars;
    my $line = $*IN.get;
    my $code = $line.defined ?? 0 !! 1;
    my $text = $line.defined ?? $line.Str !! q{};
    @names = ('REPLY',) unless @names.elems;
    my @w = $text.trim.split(/\s+/, :skip-empty);
    for @names.kv -> $idx, $name {
        next unless valid-name($name);
        my $val;
        if $idx == @names.elems - 1 and $idx < @w.elems {
            # 最后一个变量吃掉剩下的全部（bash 语义）
            $val = @w[$idx .. *].join(' ');
        }
        else {
            $val = $idx < @w.elems ?? @w[$idx] !! q{};
        }
        set-var($name, $val);
    }
    { code => $code, out => q{}, err => q{} }
}

# ── source / . ─────────────────────────────────────────────────────
#
# 实际执行由 Loop 注入（`source-runner`）—— 跑一个文件需要 drive /
# 求值器，Builtins 不能反向 use Loop（循环依赖）。
our sub do-source(*@args, :&runner --> Hash) is export {
    my @a = @args>>.Str;
    my $path = @a.elems ?? @a[0] !! q{};
    return { code => 1, out => q{}, err => 'source: 缺少文件名' } if $path eq q{};
    return { code => 1, out => q{}, err => 'source: 当前环境不支持' } unless &runner.defined;
    my $code = &runner($path);
    { code => $code, out => q{}, err => q{} }
}

# ── test / [ ───────────────────────────────────────────────────────
#
# 支持 bash 的常用形态：
#   一元：-e -f -d -r -w -x -s -z -n -L -h
#   二元：= != -eq -ne -lt -le -gt -ge
#   `!` 取反
#
# ⚠ 0.17.1（§10.2-3）：**用法错误必须报错（退出码 2），不能静默给个假**。
#
# bash 的 `test` 在三类情况下会**报错并以退出码 2 结束**（实测）：
#   ⓪ 数字比较的操作数**不是整数**：`test x -eq 1` → "integer expression expected"
#   ① **运算符缺操作数 / 运算符不存在**：`test -zz /tmp` → "unary operator expected"；
#      `test a -zz b` → "binary operator expected"；`test 1 -eq 1 -eq 1` → 语法错
#   ② 用了**我们不支持的运算符**（如 `-a` / `-o` / `-nt`）
#
# 以前这些情况一律返回 False ⇒ **两边都「成功」，结果却不一样**（静默分歧）。
# 现在对齐 bash：**能判定的就判，判不了的就报错**。
#
# 返回：Hash { ok => Bool, err => Str }
#   · err 非空 ⇒ 调用方应退出码 2 并把 err 打到 stderr
#   · 不支持的运算符（如 `-p` / `-g` / `-u` / `-O` / `-G` / `-k` / `-nt`）
#     ⇒ 也是**报错**（而不是静默假）——「半懂半猜比不支持更坏」
our sub test-args-ex(*@args --> Hash) is export {
    my @a = @args>>.Str;
    @a.pop if @a.elems and @a[*-1] eq ']';   # `[ … ]` 的收尾
    # `test`（无参数）⇒ 假（bash 一致）
    return { ok => False, err => q{} } unless @a.elems;
    if @a[0] eq '!' {
        # bash：`test !`（没有操作数）⇒ **真**（实测）
        return { ok => True, err => q{} } if @a.elems == 1;
        my %r = test-args-ex(|@a[1 .. *]);
        return %r if %r<err> ne q{};
        return { ok => !%r<ok>, err => q{} };
    }
    # 单参数：bash 语义 = 「这个字符串非空吗」
    return { ok => @a[0].chars > 0, err => q{} } if @a.elems == 1;

    if @a.elems == 2 {
        my $op = @a[0];
        my $x  = @a[1];
        # 纯字符串测试先行：不碰文件系统
        return { ok => $x eq q{}, err => q{} } if $op eq '-z';
        return { ok => $x ne q{}, err => q{} } if $op eq '-n';
        # ⚠ 本项目**不支持**的一元运算符 ⇒ 报错（不静默假）
        #   `-k`（sticky bit）也在其中：Raku 的 IO::Path 不暴露 mode 位 ⇒ 判不准 ⇒ 不能猜。
        if $op eq '-p' or $op eq '-g' or $op eq '-u' or $op eq '-O' or $op eq '-G' or $op eq '-k' {
            return { ok => False, err => "test: {$op}：暂不支持这个运算符" };
        }
        # 不认识的一元运算符 ⇒ bash 也是错误（"unary operator expected"）
        unless $op eq '-e' or $op eq '-a' or $op eq '-f' or $op eq '-d' or $op eq '-r'
            or $op eq '-w' or $op eq '-x' or $op eq '-s' or $op eq '-L' or $op eq '-h' {
            return { ok => False, err => "test: {$op}：不认识的一元运算符" };
        }
        # 空路径一律为假。⚠ 不能直接 `q{}.IO`：那会抛
        #   "Must specify a non-empty string as a path"，而 bash 的
        #   `test -e ""` 只是**返回假**（不报错）。
        return { ok => False, err => q{} } if $x eq q{};
        my $io = $x.IO;
        return { ok => $io.e, err => q{} } if $op eq '-e' or $op eq '-a';
        return { ok => $io.f, err => q{} } if $op eq '-f';
        return { ok => $io.d, err => q{} } if $op eq '-d';
        return { ok => $io.r, err => q{} } if $op eq '-r';
        return { ok => $io.w, err => q{} } if $op eq '-w';
        return { ok => $io.x, err => q{} } if $op eq '-x';
        return { ok => ($io.e and $io.s > 0), err => q{} } if $op eq '-s';
        # `-h` 是 `-L` 的别名（bash）—— 0.17.1 补上
        #   （之前静默假 ⇒ 对符号链接推出错误结论）
        return { ok => $io.l, err => q{} } if $op eq '-L' or $op eq '-h';
        return { ok => False, err => q{} };
    }

    if @a.elems == 3 {
        my ($x, $op, $y) = @a[0], @a[1], @a[2];
        return { ok => $x eq $y, err => q{} } if $op eq '=';
        return { ok => $x ne $y, err => q{} } if $op eq '!=';
        # ⚠ 本项目**不支持**的二元运算符 ⇒ 报错
        #   `-a` / `-o` 是 bash 的**逻辑运算符**（与 2 参数的 `-a`（存在）不同）。
        if $op eq '-a' or $op eq '-o' {
            return { ok => False, err => "test: {$op}：暂不支持逻辑运算符" };
        }
        if $op eq '-nt' or $op eq '-ot' or $op eq '-ef' {
            return { ok => False, err => "test: {$op}：暂不支持这个运算符" };
        }
        unless $op eq '-eq' or $op eq '-ne' or $op eq '-lt' or $op eq '-le'
            or $op eq '-gt' or $op eq '-ge' {
            return { ok => False, err => "test: {$op}：不认识的二元运算符" };
        }
        # ⚠ **整数校验**：bash 的整数表达式是「可选符号 + 十进制数字」。
        #   `010` 在 bash 的 test 里是**十进制 10**（实测），而 `0x10` / `1.5` / `x` 都是错误。
        my $nx = parse-int($x);
        my $ny = parse-int($y);
        return { ok => False, err => "test: {$x}：不是整数" } unless $nx.defined;
        return { ok => False, err => "test: {$y}：不是整数" } unless $ny.defined;
        return { ok => $nx == $ny, err => q{} } if $op eq '-eq';
        return { ok => $nx != $ny, err => q{} } if $op eq '-ne';
        return { ok => $nx <  $ny, err => q{} } if $op eq '-lt';
        return { ok => $nx <= $ny, err => q{} } if $op eq '-le';
        return { ok => $nx >  $ny, err => q{} } if $op eq '-gt';
        return { ok => $nx >= $ny, err => q{} } if $op eq '-ge';
        return { ok => False, err => q{} };
    }

    # 4 个参数以上：bash 用 `-a` / `-o` 串联。我们不支持 ⇒ 报错
    return { ok => False, err => "test：暂不支持多运算符组合（`-a` / `-o`）" };
}

# bash 的「整数表达式」解析：不是整数 ⇒ Nil（调用方报错）
sub parse-int(Str $s) {
    return Nil unless $s ~~ /^ <[+-]>? \d+ $/;
    $s.Int
}

# 兼容入口：只要真假（不要错误详情）
our sub test-args(*@args --> Bool) is export {
    test-args-ex(|@args)<ok>
}

# `test` / `[` 的结果包装：用法错误 ⇒ 退出码 2 + stderr（bash 的行为）
sub test-result(*@args --> Hash) is export {
    my %r = test-args-ex(|@args);
    return { code => 2, out => q{}, err => %r<err> } if %r<err> ne q{};
    { code => %r<ok> ?? 0 !! 1, out => q{}, err => q{} }
}

# ── 总入口 ─────────────────────────────────────────────────────────
#
# 返回 Hash：
#   handled  真 ⇒ 宿主已经处理（Loop 不再交引擎）
#   code     退出码（要写进 $?）
#   out/err  文本（Loop 决定怎么渲染）
#   quit     真 ⇒ 收摊（exit）
our sub dispatch(Str $line, :&source-runner, Int :$last-status = 0 --> Hash) is export {
    my $name = builtin-name($line);
    my %skip = handled => False, code => $last-status, out => q{}, err => q{}, quit => False;
    return %skip if $name eq q{};

    my @w = split-words($line);
    shift @w;
    my @args = @w>>.&expand-arg;      # `$HOME` / `~` 在这里落成字面量

    my %r;
    given $name {
        when 'cd'      { %r = cd-into(@args.elems ?? @args[0].Str !! q{}) }
        when 'pwd'     { %r = { code => 0, out => pwd(), err => q{} } }
        when 'export'  { %r = export-vars(|@args) }
        when 'unset'   { %r = unset-vars(|@args) }
        when 'alias'   { %r = alias-def(|@args) }
        when 'unalias' { %r = unalias-def(|@args) }
        when 'exit'    { %r = finish-exit(|@args) }
        when 'read'    { %r = read-into(|@args) }
        when 'test'    { %r = test-result(@args) }
        when '['       { %r = test-result(@args) }
        when 'source' | '.' { %r = do-source(|@args, :runner(&source-runner)) }
        default        { %r = %skip }
    }

    # `type` 单独写：多参数逐个查，任一个找不到 ⇒ 退出码 1
    if $name eq 'type' {
        my @out;
        my @err;
        my $code = 0;
        for @args -> $w {
            my $hit = type-of($w.Str);
            if $hit eq q{} {
                @err.push: "type: 找不到：{$w}";
                $code = 1;
            }
            else {
                @out.push: $hit;
            }
        }
        %r = { code => $code, out => @out.join("\n"), err => @err.join("\n") };
    }

    %r<handled> = True;
    %r<ui>    = False unless %r<ui>.defined;
    %r<quit>  = False unless %r<quit>.defined;
    %r<code>  = 0     unless %r<code>.defined;
    %r<out>   = q{}   unless %r<out>.defined;
    %r<err>   = q{}   unless %r<err>.defined;
    %r
}
