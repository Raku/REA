# Rakuish::Slow —— 慢档：让真 sh 跑 shell
#
# 设计前提（**两个实现上实测对拍过**，不是推断）：
#
# 1. **`run()` 不接返回值就继承 fd1** —— 输出流式直通，`printf "a"; sleep; printf "b"`
#    的 a / b 按顺序出现，**原生 ANSI 原样保留**（实测 `^[[31mRED^[[0m`）。
#    所以"默认直通"在 Linux 上是**免费**的：流式与颜色都不需要额外处理。
#    这一点是 Linux-only 相对 Windows 版最大的红利 —— rsh 当年整套
#    `$needs-sh` 判定 + `posix-argv` 转义 + "并段交给 sh" 的复杂设计
#    （坑 3 / 75 / 82）在 Linux 上整个不需要。
#
# 2. **`run()` 直接跑不存在的命令给 `exitcode = -1` 且 stderr 为空**，
#    `signal` 两个实现还不一样（MoarVM 254 / rakupp 0）。
#    → **不可用**。包一层 `sh -c` 就得到 `127` + stderr 消息
#    （`sh: 1: xxx: not found`），**两个实现完全一致**。
#    所以对外一律走 `sh -c`，顺便还白拿 shell 的所有语法。
#
# 3. **`run(:in)` 真链式管道两个实现都能用**。读管道只能用
#    **`.slurp(:close)`**（`IO::Pipe` 没有 `readline`）。
#    但**三棒在 MoarVM 上会卡**（中间棒的 `:out` 没人消费）——
#    所以本模块的管道一律**整段交给 `sh -c`**（`needs-sh` 判定），
#    不在 Raku 侧搭。这不是能力不足，是 shell 的管道本就该由 shell 跑。
#
# 4. **加工必然失去流式**。要给行号/汇总就得捕获，捕获就得等结束。
#    → 做成两档：**默认直通**，显式要求才加工。不偷偷降级。
#
# 5. **`Str.chars` 在本版返回的是「字符数」而不是字符列表**（实测
#    `$s.chars.elems = 1`、`$s.chars().elems = 1`、`@($s.chars).elems = 1`、
#    而 `$s.comb.elems = 3`）。**逐字符迭代必须用 `.comb`。**
#    这个坑**不报错** —— `for $s.chars -> $c` 只跑一次、拿到的是那个数字字符串，
#    于是"分词函数只返回 1 个元素、值等于行长""判元字符永远只命中 1 个"
#    这类症状极难定位。**我在同一个文件里踩了两次**（分词与 needs-sh），
#    所以注释里凡是逐字符处都直接写 `.comb` 并说明原因。
#
# 6. **`for $s.comb -> $c` 里的 `$c` 退化成 `Any`**，于是
#    `index($table, $c)` 报`Cannot resolve caller index(Str:D, Any:U)`。
#    → 逐字符循环一律写 `for $s.comb -> Str $c`（显式标类型）。

unit module Rakuish::Slow;

use Rakuish::Platform;

# 字符常量用 chr()：源码里直接写反斜杠与双引号会被自己所在的定界符咬到。
our $BSL     = chr(92);        # 反斜杠
our $DQUOTE  = chr(34);        # 双引号
our $SQUOTE  = chr(39);        # 单引号

# ── shell 引号 ───────────────────────────────────────────────────────
# POSIX 标准做法：单引号包裹，内部单引号用 `'\''` 收尾再续一个。
# 注意用单引号是**关键**：`$`、`*`、反引号在单引号里都不展开，
# 比"该转义哪些字符"的分析题可靠得多。
our sub sh-quote(Str $s --> Str) is export {
    # 注意方法名：Raku 是 `subst(..., :g)`，**没有 `gsub`**。
    # 写成 `$s.gsub(...)` 报"No such method 'gsub' for string"。
    "'" ~ $s.subst(q{'}, "'\\''", :g) ~ "'"
}

# ── 命令拆成 argv ────────────────────────────────────────────────────
# 只处理**词法层**：单引号段、双引号段、反斜杠转义。**不处理**管道、
# 重定向、`&&` 之类 —— 那些走 `needs-sh` 整段交 sh。
# 拆不动的（带元字符的）返回 Nil，由调用方改走 sh。
# 注意：**不要写 `--> List`**。容器返回标注跨实现不兼容
# （MoarVM 拒绝 `--> List` 因为实际给 Seq；rakupp 拒绝 `--> Seq`）。
# 调用方用 `@(...)` / `list(...)` 显式要列表就行。
our sub split-argv(Str $line) is export {
    my @argv;
    my $cur = '';
    my $started = False;
    my $mode = q{bare};                # bare / single / double
    my $skip = False;                 # 反斜杠转义后跳过下一个字符

    # 两个字符常量都用 chr 定义，**不在源码里写引号字面量** ——
    # `q{'}` 看着是"双引号的 q 字面量"，其实 `'` 是定界符、内容为空；
    # 写成 `'quote'`（裸引号）又会被当成未声明标识符。
    # 这两种误写都不会报错，只会让状态机走错分支（实测双引号段被当单引号段，
    # 于是段内空格不再被保护、`hello world` 与后面的 a.txt 粘成一段）。
    my $Q1 = $SQUOTE;
    my $Q2 = $DQUOTE;

    # **必须用 `.comb` 而不是 `.chars`** —— 实测（MoarVM 2026.09）：
    #   $s.chars.elems = 1$ s.chars().elems = 1   @($s.chars).elems = 1
    #   $s.comb.elems  = 3   ← 只有这个给字符列表
    # `.chars` 返回的是**字符数**（一个 Str），不是字符列表；不报错，
    # 只是让 for 只跑一次，于是"分词只返回 1 个元素、值等于行长"。
    for $line.comb -> Str $c {
        if $skip { $skip = False; $cur ~= $c; $started = True; next }

        # 反斜杠转义：下一个字符是字面量
        if $c eq $BSL and $mode ne q{single} {
            $skip = True;
            $started = True;
            next;
        }

        # 单引号段：只在 bare 下开启、在 single 下关闭
        if $c eq $Q1 {
            $mode = $mode eq q{single} ?? q{bare} !! q{single};
            $started = True;
            next;
        }

        # 双引号段：只在 bare 下开启、在 double 下关闭
        if $c eq $Q2 and $mode ne q{single} {
            $mode = $mode eq q{double} ?? q{bare} !! q{double};
            $started = True;
            next;
        }

        # 空格只在 bare 下分隔词
        if $c eq q{ } and $mode eq q{bare} {
            @argv.push: $cur if $started;
            $cur = '';
            $started = False;
            next;
        }

        $cur ~= $c;
        $started = True;
    }
    @argv.push: $cur if $started;
    # 注意：**末尾的裸 `@argv` 不够**。`list(split-argv(...))` 会多出一个
    # True —— 因为 sub 最后一个求值表达式的值被当成第二个返回值传给 list()。
    # 显式 return 才干净。
    return @argv;
}

# ── 是否需要 sh ──────────────────────────────────────────────────────
# 含 shell 元字符就整段交给 sh：这条判据比"逐个实现 pipe 重定向"可靠得多，
# 而且 sh 本来就是这些东西的实现者。

# shell 元字符表。用查表而不是字符类/正则：Raku 里`[; & $ ...]`
# 这些元字符必须逐个转义、容易漏，而这处只是"有没有一个"。
# 注意**不用** `Str.new(...)`：本版 Rakudo 的 Str 默认构造器只接受命名参数
#（`Default constructor for 'Str' only takes named arguments`）。
# 直接用字符串拼接的编译期常量。
our $SH-META-CHARS = '|&;<>$' ~ "`" ~ '"' ~ "'" ~ '()' ~ '*?[]{}' ~ '~#!';

our sub needs-sh(Str $line --> Bool) is export {
    # 反斜杠转义的元字符不算（`echo a\|b` 是字面 a|b）——
    # 所以先把"反斜杠 + 任意字符"抹成空格，再看还剩什么元字符。
    my $probe = $line;
    $probe ~~ s:g/\\./ /;
    # `index` 找不到时返回 **Nil 而不是 -1**，直接比 >= 0 会报
    # "Use of Nil in numeric context"。必须用 .defined 判。
    # 注意用 `$c`（显式绑定）**而不是 `$_`** —— 写 `$_` 时它是 Any，
    # 于是 `index($table, $_)` 报 "Cannot resolve caller index(Str:D, Any:U)"，
    # 而且**给循环变量标 Str 类型也救不了**（因为类型标在$c 上，$_ 仍是 Any）。
    for $probe.comb -> Str $c {
        return True if index($SH-META-CHARS, $c).defined;
    }
    False
}

# ── 要不要捕获 ──────────────────────────────────────────────────────
our sub needs-capture(Str $line, Bool :$numbers --> Bool) is export {
    $numbers
}

# ── 结果 ────────────────────────────────────────────────────────────
# 直通模式下**没有输出可拿**（它已经流到终端了），只有状态；
# 捕获模式下才有 `out`。所以两种模式共用一个类型。
class SlowResult is export {
    has Int$.code   = 0;      # 退出码；命令不存在时 sh 给 127
    has Bool $.found = True;   # False = 命令没找到（127）
    has Bool $.passed = False;# True = 走了捕获路径（out 有值）
    has Str  $.out   = q{};    # 捕获的 stdout（passed=True 时有效）
    has Str  $.stdout = q{};   # 捕获的纯 stdout（汇总块行数统计用）
    has Str  $.stderr = q{};   # 捕获的纯 stderr

    method ok(--> Bool) { $.code == 0 }
}

our sub slow-result-new(*%args --> SlowResult) is export { SlowResult.new(|%args) }

# ── 行号标注 ─────────────────────────────────────────────────────────
our $BAR = chr(0x2502);       # 行号标注用的竖线

our sub number-lines(Str $text, Bool :$numbers --> Str) is export {
    return $text unless $numbers;
    my @lines = $text.split("\n");
    # 末尾换行不多算一行。注意 `@lines && @lines[*-1] eq q{}` 在
    # `a\n` 这种只剩空串的情况会把列表 pop 空 —— 所以先判长度。
    @lines.pop while @lines.elems > 0 and @lines[*-1] eq q{};
    return q{} unless @lines;

    # 序号**从 1 开始**（和编辑器/Errno 一致的直觉），列宽随行数走
    my $w = @lines.elems.chars;
    my @out;
    for @lines -> $line {
        my $n = (@out.elems + 1).Str;
        # 注意：**Str 没有 `.pad`**（左对齐得用 `.fmt('%<width>s')`，
        # 但 rakupp 不支持 `%-22` 那种左对齐宽度）→ 手工补空格。
        @out.push: $n ~ q{ } ~ q{ } x ($w - $n.chars) ~ $BAR ~ q{ } ~ $line;
    }
    @out.join("\n")
}

# ── 汇总块 ──────────────────────────────────────────────────────────
# 跑完给一行摘要：脚本名 / 退出码 / 耗时。**不做逐行加工** ——
# 那是 `%run --numbers` 显式要求的事。
our sub summary-line(Str $name, Int $code, Numeric :$duration = 0 --> Str) is export {
    # 耗时格式：试过 `.round(2)`（本版对 0.42 给回 0）、`.round` 后手工补位
    # （同样拿不到小数部分）—— 最后用 sprintf，最省事且两个实现行为一致。
    my $d = sprintf(q{%.2f}, $duration);
    "〔$name〕exit {$code}，{$d}s"
}

# ── 真正跑 ──────────────────────────────────────────────────────────
our sub run-shell(Str $line, Bool :$capture = False --> SlowResult) is export {
    return SlowResult.new(:code(0), :found(True)) if $line.trim eq q{};

    my $cmd = $line.trim;

    if $capture {
        # 加工路径：整段交给 sh（管道/重定向都在那一侧），然后 slurp 回来
        my $p = run('sh', '-c', $cmd, :out, :err);
        # slurp 顺序：**先 err 后 out**。反过来 out 管道写满时
        # 子进程会阻塞等着（两个实现都会）。
        my $err = $p.err.slurp(:close);
        my $out = $p.out.slurp(:close);
        return SlowResult.new(
            :code($p.exitcode),
            :found($p.exitcode != 127),
            :passed(True),
            :out($out ~ $err),
            :stdout($out),
            :stderr($err),
        );
    }

    # 直通路径：**不接返回值** —— 这就是继承 fd1、保留流式与 ANSI 的原因。
    # 注意这里不能读 $p.exitcode 之前就 close 什么，run 返回的 Proc
    # 在两个实现上都要靠 `.exitcode` 等它结束。
    my $p = run('sh', '-c', $cmd);
    SlowResult.new(:code($p.exitcode), :found($p.exitcode != 127))
}

our sub run-script-file(Str $path --> SlowResult) is export {
    my $f = $path.IO;
    return SlowResult.new(:code(127), :found(False)) unless $f.e;

    my $r = run-shell(script-interpreter($path) ~ ' ' ~ sh-quote($path), :capture(False));
    SlowResult.new(:code($r.code), :found($r.found), :passed(False))
}

# ── 跑脚本用哪个解释器 ────────────────────────────────────────────────
#
# 判据（按顺序）：
#
#   ① **shebang**（`#!`）—— 最权威，脚本自己说了算
#      `#!/bin/bash` → bash      `#!/usr/bin/env bash` → bash
#      `#!/usr/bin/env python3` → python3
#   ② 后缀 `.sh` → **bash**
#   ③ 其它 → `sh`
#
# ⚠⚠ **为什么 `.sh` 要用 bash 而不是 `sh`**：
#   本机 `/bin/sh` 是 **dash**（实测：`ls -l /bin/sh` → dash），
#   dash 不是 POSIX 之外的 bash：没有 brace 展开 `{a,b}`、
#   没有 `[[ ]]`、没有 `local`、数组行为也不同。
#   → 脚本写的是 bash 语法却用 dash 跑 ⇒ 静默跑出**另一种结果**
#   （这是「同��份脚本在别人机器上行为不同」的经典来源）。
#   → `.sh` 一律用 bash；写了 `#!/bin/sh` 的**尊重它**（脚本自己要求的）。
#
# ⚠ 环境变量是**单向继承**的：REPL 的 `%*ENV` + 会话变量 → 脚本进程；
#   脚本里的 `export` **不回传**（子进程改不了父进程的环境）。
#   这跟 docker exec / make 的惯例一致。
# ── shebang 读取（**唯一的读法**）────────────────────────────────────
#
# 只负责「读第一行、切词」；**怎么解释**由调用方决定 —— 两条路问的问题
# 本来就不一样（见下面两个 sub）。但「第一行怎么读」只有一份，
# 免得两边读法漂移。
our sub shebang-words(Str $path --> List) is export {
    my $f = $path.IO;
    return () unless $f.e;

    my $first = q{};
    try {
        # ⚠ 用 `.lines[0]` 而不是 `getline`：MoarVM 的 `IO::Handle`
        #   **没有** `getline` 方法（只有 `readline`）⇒ 直接调会抛
        #   "No such method 'getline'"（实测）。
        #   `.lines` 是惰性的，取 [0] 只会读第一行 ✓
        $first = $f.lines[0] // q{};
    }
    return () unless $first.starts-with('#!');

    # ⚠ `.words` 返回的是 **Seq** ⇒ 必须显式包成 List，
    #   否则 `--> List` 的类型检查会失败（实测报 "expected List but got Seq"）。
    List($first.substr(2).trim.words);
}

# `%run` 那条路：跑的是**shell 脚本** ⇒ 解释器由 shebang / 后缀决定。
our sub script-interpreter(Str $path --> Str) is export {
    my @w = shebang-words($path);
    if @w.elems {
        # `#!/usr/bin/env bash` → 取 env 后面的那个
        my $base = @w[0];
        if ($base eq '/usr/bin/env' or $base eq '/bin/env')
        and @w.elems > 1 {
            return @w[1];
        }
        return $base;
    }

    my $ext = $path.IO.extension;
    return 'bash' if $ext eq 'sh';
    'sh'
}

# ── 脚本模式用哪个解释器（G5，0.16.4）────────────────────────────────
#
# ⚠ 与 `script-interpreter` **判据不同**，因为问的问题不同：
#   · `%run` 跑的是 **shell 脚本** ⇒ 一律交给 shell 解释器；
#   · 脚本模式（`rakuish run x`）默认跑的是 **Raku 脚本** ⇒
#     只有文件自己说「我不是 Raku」（shebang 指向别的解释器，
#     或后缀是 .sh）才交给外部解释器。
#
# 返回值：
#   'raku'      ⇒ 用 Rakuish 自己的脚本模式跑（当前行为）
#   其它字符串  ⇒ 外部解释器（'bash' / '/bin/sh' / 'python3' …）
our sub script-mode-interpreter(Str $path --> Str) is export {
    my @w = shebang-words($path);
    if @w.elems {
        # `env` 的可选参数（`-S` / `-i` …）要跳过，只留真正的命令
        my @cmd = @w.grep({ !.starts-with('-') });
        # 去掉 `env` 本身 ⇒ 剩下的第一个才是解释器
        @cmd.shift if @cmd.elems and (@cmd[0].ends-with('/env') or @cmd[0] eq 'env');
        if @cmd.elems {
            my $name = @cmd[0].IO.basename;
            # Raku 系（raku / rakudo / rakuish）⇒ 还是走 Rakuish 脚本模式
            return 'raku' if $name.starts-with('raku');
            return @cmd[0];
        }
    }
    # 没有 shebang：按后缀兜底（`.sh` 一律 bash —— 本机 /bin/sh 是 dash，
    # 用 dash 跑 bash 脚本会**静默跑出另一种结果**）
    my $ext = $path.IO.extension;
    return 'bash' if $ext eq 'sh' or $ext eq 'bash';
    'raku'
}

# ── 行数统计 ──────────────────────────────────────────────────────────
our sub count-lines(Str $text --> Int) is export {
    return 0 if $text eq q{};
    my @ls = $text.split("\n");
    @ls.pop while @ls.elems > 0 and @ls[*-1] eq q{};
    @ls.elems
}

# ── 显示宽度（CJK / 全角算 2，其余算 1）─────────────────────────────
our sub disp-width(Str $s --> Int) is export {
    my $w = 0;
    for $s.comb -> Str $c {
        my $o = $c.ord;
        my $wide = $o >= 0x1100 && (
            $o <= 0x115F ||
            ($o >= 0x2E80 && $o <= 0x303E) ||
            ($o >= 0x3041 && $o <= 0x33FF) ||
            ($o >= 0x3400 && $o <= 0x4DBF) ||
            ($o >= 0x4E00 && $o <= 0x9FFF) ||
            ($o >= 0xA000 && $o <= 0xA4CF) ||
            ($o >= 0xAC00 && $o <= 0xD7A3) ||
            ($o >= 0xF900 && $o <= 0xFAFF) ||
            ($o >= 0xFE30 && $o <= 0xFE4F) ||
            ($o >= 0xFF00 && $o <= 0xFF60) ||
            ($o >= 0xFFE0 && $o <= 0xFFE6)
        );
        $w = $w + ($wide ?? 2 !! 1);
    }
    $w
}

# ── 汇总块（盒子）────────────────────────────────────────────────────
our sub summary-box(Str $name, Int $code, Numeric :$duration = 0,
                    Int :$stdout-lines = 0, Int :$stderr-lines = 0 --> Str) is export {
    my $d = sprintf(q{%.2f}, $duration);
    my $inner = " {$d}s · exit {$code} · stdout {$stdout-lines} 行 · stderr {$stderr-lines} 行 ";
    my $w = disp-width($inner);
    my $bar = "─" x ($w > 2 ?? $w - 2 !! 0);
    "┌" ~ $bar ~ "┐\n" ~ $inner ~ "\n└" ~ $bar ~ "┘"
}

# ── 耗时框（%time 用）─────────────────────────────────────────────────
# 与 summary-box 同一套视觉语言（Unicode 盒子 + CJK 宽度感知），
# 只显示耗时与成败，不做脚本那一套行数统计。
our sub time-box(Numeric :$duration = 0, Int :$status = 0 --> Str) is export {
    my $d = sprintf(q{%.4f}, $duration);
    my $st = $status == 0 ?? 'OK' !! ($status == 2 ?? '用法' !! 'ERR');
    my $inner = " {$d}s · {$st} ";
    my $w = disp-width($inner);
    my $bar = "─" x ($w > 2 ?? $w - 2 !! 0);
    "┌" ~ $bar ~ "┐\n" ~ $inner ~ "\n└" ~ $bar ~ "┘"
}

# ── 载入框（%load 用）─────────────────────────────────────────────────
# 与 summary-box / time-box 同一套视觉语言（Unicode 盒子 + CJK 宽度感知）。
our sub load-box(Str $name = '', Int :$lines = 0, Int :$total = 0,
                 Int :$status = 0 --> Str) is export {
    my $st = $status == 0 ?? 'OK' !! ($status == 2 ?? '用法' !! 'ERR');
    my $inner = $name eq q{}
        ?? " {$lines} 行 · $st " 
        !! " $name · $lines/$total 行 · $st ";
    my $w = disp-width($inner);
    my $bar = "─" x ($w > 2 ?? $w - 2 !! 0);
    "┌" ~ $bar ~ "┐\n" ~ $inner ~ "\n└" ~ $bar ~ "┘"
}
