# Rakuish::Script —— 脚本模式的「整份文件一个编译单元」拼装器（P5-1）
#
# 背景（GAPS-P4.md §6.5 / G3）：脚本以前复用 REPL 的句级驱动，eval-cell
# 每格把整份缓冲重 EVAL，副作用（spurt / mkdir / rename）跟着重跑，
# 05 的幂等检查因此假失败，耗时 O(n²)。
#
# 修法：先把整份文件**规划**一遍（只分类、不执行），再拼成一个 Raku
# 编译单元交给 Rakuish::Eval::eval-program 一次编译执行。
#
# 规划阶段会产出若干「格」：
#
#   %( line => 首行行号, span => 占几行, src => 原文, raku => Bool,
#      heredocs => %( 分隔符 => 正文 ) )
#
# Raku 格原样落到它的行号上；非 Raku 格（!cmd / %magic / cd / ls / 别名）
# 只有一行能放 —— 那里放一次调用到 Rakuish::Loop::__script-cell__，
# 由驱动层在**那一刻**执行一次（不重放、不预执行），占用的其余行留空。
#
# 为什么非 Raku 行必须回到驱动层：它们要改的是**会话状态**
#（cwd、%ENV、%STORE、shell 会话变量、exit 码、source），
# 全部由 Rakuish::Loop 持有；在 EVAL 里做不了。
#
# ── 两条硬约束（踩过才知道的）─────────────────────────────────────
#
# 1. **行号必须一像素不差**：每个格都落在它的物理行号上，报错行号才对得上
#    文件（P4-2 的 `文件:行号` 承诺不破）。
# 2. **`use v6.x;` 必须置首**：写在文件中间时原生 raku 报
#    "Too late to switch language version"（实测）。所以规划时把文件头
#    （第一个真正的代码行之前）的 `use v6.x;` **提到最前面**，原位置留空
#    —— 行数不变、行号不漂。
#
# ⚠ 非 Raku 行的分类判据只有一份：`Rakuish::Loop::is-raku-cell`。
#   这里只**信任**它给出的 Bool，不重复实现分类。

unit module Rakuish::Script;

use Rakuish::Eval;      # quote-str-for-raku：拼 Raku 单引号字面量

# 生成一个 Raku 哈希字面量：`%( 'k' => 'v', ... )`。
#
# 正文用**单引号**字面量而非双引号：Raku 的单引号串里只有 `'` 和 `\\` 有
# 意义（前者双写转义、后者原样保留字面量），heredoc 正文里的 `$x`、`@a`、
# 反斜杠、反引号全都不会被插值 —— 双引号串里这些全是坑（Shell 语法与
# Raku 语法在这一点上正好相反：shell 双引号会插值，Raku 单引号不会）。
# 换行可以直接出现在单引号串里，所以正文不必按行拼。
sub hash-lit(%h --> Str) {
    return 'Hash.new' unless %h.elems;
    my @pairs;
    for %h.keys.sort({ .Str }) -> $k {
        @pairs.push: quote-str-for-raku($k.Str) ~ ' => ' ~ quote-str-for-raku(%h{$k}.Str);
    }
    '%( ' ~ @pairs.join(', ') ~ ' )'
}

# 一格非 Raku 输入 → 一行 Raku 调用（**行数恒为 1**）。
#
# 只传原文与 heredoc 正文，不带"这一格是什么"：执行时由驱动层重新判定。
# 宁可多判一次，也不要把判据复制成两份 —— 两份判据漂移的那天，
# `ls -la` 会一半当 shell、一半当内建，最难查。
our sub shell-call(%cell --> Str) is export {
    # ⚠ `join-lines` 会给格尾补一个 "\n"（REPL 侧需要它做 needs-more 判定）。
    # 这个换行必须在这里剥掉：它一旦进到单引号字面量里，一格就会变成两行源码，
    # 整份文件的行号从此全体后移一格 —— 表现是"报错行指向上一行"。
    my Str $src = %cell<src>.Str;
    $src = $src.subst(/ \n+ $ /, '');
    # ⚠ 用**动态变量**而不是 `Rakuish::Loop::__script-cell__`：包限定名在
    # EVAL 单元里会退化成运行时 stash 查找，在模块内部发起的 EVAL 里会
    # 报 "Could not find symbol '&__script-cell__' in 'Rakuish::Loop'"（实测）。
    # hook 由 eval-program 的 `&cell-hook` 参数注入，脚本模式才有值。
    '$*RAKUISH-CELL-HOOK('
        ~ quote-str-for-raku($src) ~ ', '
        # 行尾分号不能省：一格一行，下一行紧接着就是另一条语句；
        # 少了它 Raku 会把下一行的裸名当成续接项，报 "Missing infix inside R"。
        ~ hash-lit(%cell<heredocs> // %()) ~ ');'
}

# 把「格」列表拼成编译单元正文（不含 no worries / $*PROGRAM / DSL prelude，
# 那三样由 eval-program 负责）。
#
# 返回 %( body => 正文, hoist => 需要置首的 `use v6.x` )。
our sub assemble(@cells --> Hash) is export {
    my Int $total = 0;
    for @cells -> %c {
        $total max= %c<line>.Int + %c<span>.Int - 1;
    }
    my @emit = ('') xx $total;
    my Str $hoist = q{};
    my Bool $head = True;       # 还在文件头（只有空行/注释）？

    for @cells -> %c {
        my Str $src = %c<src>.Str;
        my Int $at  = %c<line>.Int - 1;
        if %c<raku> {
            my @src = $src.lines;
            if $head {
                if @src.elems == 1 and $src ~~ /^ \s* '#'/ {
                    # 注释行不打断「文件头」——`#!/usr/bin/env rakuish`
                    # 与版权注释之后写 `use v6.d;` 是最常见的写法。
                }
                elsif @src.elems == 1 and $src ~~ /^ \s* 'use' \s+ v6 / {
                    $hoist ~= $src.trim ~ "\n";
                    next;               # 原位留空：行号不动
                }
                else {
                    $head = False;
                }
            }
            for @src.kv -> $i, $l {
                @emit[$at + $i] = $l if $at + $i < @emit.elems;
            }
        }
        else {
            $head = False;              # 头里有 shell 行 ⇒ 已经不是文件头
            @emit[$at] = shell-call(%c);
        }
    }
    %( body => @emit.join("\n"), hoist => $hoist )
}
