unit module Rakuish::JSONServer;

# ── JSON Server 模式（bin/rakuish --json 入口）──────────────────────
#
# 流式请求-响应：stdin 每行一条命令，stdout 每行一条 JSON 结果。
#
# ── accum 副作用问题的解决方案 ──────────────────────────────────────
#
# 旧方案每格 EVAL 整份 accum，导致 say/start/sleep/spurt 等副作用每格重复执行。
# 新方案采用「our 前置声明 + 声明累积 + 类型别名」混合策略，每格只 EVAL 当前格：
#
#   1. 变量（my/our/state $@%&）：
#      - 首次声明：my/state → our（our 变量包级作用域，跨 EVAL 持久）
#      - 再次声明：去掉 my/our/state 关键字，变成裸赋值
#      - 每格 EVAL 前前置 our $x; our @y; ...（已声明但未在本格重新声明的变量）
#
#   2. sub（含 multi/proto/only）：
#      - sub 不跨 EVAL 持久（词法作用域），需每格重新声明
#      - 声明本身无副作用（body 只在调用时执行），可安全重编译
#      - 累积所有 sub 声明文本，每格 EVAL 前前置（不含本格新声明的 sub）
#
#   3. class/role/grammar/enum：
#      - 声明本身写入包级 stash，跨 EVAL 持久
#      - 但 EVAL 内的裸名查找看不到包级符号（EVAL 在子内调用的限制）
#      - 解决方案：每格前置 constant Name = OUR::Name; 建立词法别名
#      - 不重声明（会报 "Redeclaration of symbol"）
#
# 每格 EVAL 源码 = our 变量前置 + sub 声明累积 + 类型别名 + 当前格转换后源码
# 副作用只执行一次，性能从 O(n²) 降到 O(n)。
#
# ── 分流规则 ────────────────────────────────────────────────────────
#   !cmd / export / unset / cd / pwd / alias / type  → shell 后端
#   %eval-engine / %watch / %shell / %quit           → 魔法命令
#   其余                                             → Raku EVAL
#
# 输入：每行一条命令，或 JSON {"id":"...","cmd":"...","shell":true/false}
# 输出：每行一个 JSON {id, ok, code, stdout, stderr, value, shell, elapsed_ms, hint?, watch?}
#
# 并发：shell 并发（各自独立引擎进程），Raku EVAL 串行（保持 our/sub 语义）
# 退出：收到 %quit 或 stdin EOF

use Rakuish::Shell::Engine;
use Rakuish::Eval;
use JSON::Fast;

# ── 持久状态：跨 cell 的变量 / sub / 类型声明 ───────────────────────
class PersistState is export {
    has Set $!vars .= new;              # 已声明变量名：$x, @y, %z
    has %!subs;                          # sub name → [声明源码, ...]（multi 支持）
    has @!sub-order;                     # sub 声明顺序（保持插入序）
    has Set $!types .= new;             # 已声明类型名：class/role/grammar/enum

    method has-var(Str $name --> Bool) { $name (elem) $!vars }
    method add-var(Str $name) { $!vars ∪= $name }
    method vars(--> List) { $!vars.keys.List }

    method has-sub(Str $name --> Bool) { %!subs{$name}:exists }
    method add-sub(Str $name, Str $src) {
        unless %!subs{$name}:exists { @!sub-order.push: $name; %!subs{$name} = [] }
        %!subs{$name}.push: $src;
    }
    method sub-source(--> Str) {
        @!sub-order.map({ %!subs{$_}.join("\n") }).join("\n")
    }

    method sub-source-excluding(@exclude --> Str) {
        my Set $ex .= new(@exclude);
        @!sub-order.grep({ !($_ (elem) $ex) }).map({ %!subs{$_}.join("\n") }).join("\n")
    }

    method has-type(Str $name --> Bool) { $name (elem) $!types }
    method add-type(Str $name) { $!types ∪= $name }
    method types(--> List) { $!types.keys.List }
}

# ── 提取变量声明中的所有变量名 ───────────────────────────────────────
sub extract-var-names(Str $decl-part --> List) {
    my @names = $decl-part ~~ m:g/ <[$@%&]> \w+ /;
    @names.map(*.Str).List
}

# ── 提取 sub 声明名 ────────────────────────────────────────────────
our sub extract-sub-name(Str $decl --> Str) is export {
    if $decl ~~ / ^ [multi|proto|only] \s+ sub \s+ (\w+) / { return ~$/[0] }
    if $decl ~~ / ^ sub \s+ (\w+) / { return ~$/[0] }
    if $decl ~~ / ^ [multi|proto|only] \s+ (\w+) / { return ~$/[0] }
    return ''
}

# ── 提取类型声明名（class/role/grammar/enum）────────────────────────
sub extract-type-name(Str $decl --> Str) {
    if $decl ~~ / ^ [our\s+]? [class|role|grammar|enum] \s+ (\w+) / { return ~$/[0] }
    return ''
}

# ── 向前扫描找到声明结束位置（sub / class / role / grammar / enum）──
# 从 $start 开始，跳过字符串/注释/正则，遇到 { 开始计数，回到 0 时结束；
# 若始终无 {，遇到 ; 结束。
our sub find-decl-end(Str $src, Int $start --> Int) is export {
    my $i = $start;
    my $n = $src.chars;
    my $st = 'normal';
    my $open; my $close;
    my $bq-depth = 0;
    my $depth = 0;
    my Bool $seen-brace = False;

    while $i < $n {
        my $c = $src.substr($i, 1);

        if $st eq 'comment' { $st = 'normal' if $c eq "\n"; $i++; next }
        if $st eq 'sq' {
            if $c eq q{'} {
                if $i + 1 < $n && $src.substr($i+1,1) eq q{'} { $i += 2; next }
                $st = 'normal';
            }
            $i++; next;
        }
        if $st eq 'dq' {
            if $c eq '\\' { $i += 2; next }
            $st = 'normal' if $c eq q{"};
            $i++; next;
        }
        if $st eq 'bq' {
            if $c eq $open { $bq-depth++ }
            elsif $c eq $close { $st = 'normal' if $bq-depth == 0; $bq-depth-- if $bq-depth > 0 }
            $i++; next;
        }
        if $st eq 'rx' {
            if $c eq '\\' { $i += 2; next }
            $st = 'normal' if $c eq '/';
            $i++; next;
        }
        if $c eq '#' { $st = 'comment'; $i++; next }
        if $c eq q{'} { $st = 'sq'; $i++; next }
        if $c eq q{"} { $st = 'dq'; $i++; next }
        if $c eq 'q' | 'Q' {
            my $prev = $i > 0 ?? $src.substr($i-1,1) !! ' ';
            my $wordy = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$@%&.'.contains($prev) || $prev eq ']';
            if !$wordy {
                if $src.substr($i) ~~ /^ [ 'q' | 'Q' ] [ 'q' | 'x' | 'w' | 'wv' | 'ww' | 'v' ]? ':'? <[a..z]>* $<brk>=('[' | '(' | '{' | '<') / -> $m {
                    my $b = $m<brk>.Str;
                    $open  = $b;
                    $close = $b eq '[' ?? ']' !! $b eq '(' ?? ')' !! $b eq '{' ?? '}' !! '>';
                    $bq-depth = 0; $st = 'bq'; $i++; next;
                }
            }
        }
        if $src.substr($i) ~~ /^ [ 'm' | 'rx' | 's' | 'ms' | 'ss' | 'tr' ] \s* '/' / { $st = 'rx'; $i++; next }

        if $c eq '{' { $depth++; $seen-brace = True }
        elsif $c eq '}' { $depth--; return $i + 1 if $seen-brace && $depth == 0 }
        elsif $c eq ';' && !$seen-brace { return $i + 1 }

        $i++;
    }
    return $n;
}

# ── 转换单格源码 ────────────────────────────────────────────────────
# my/state → our（首次）或去关键字（重声明）；提取 sub 和类型声明。
# 返回 ($transformed-src, @fresh-vars, @fresh-subs, @fresh-types)
our sub transform-cell(Str $src, PersistState $ps --> List) is export {
    my @fresh-vars;
    my @fresh-subs;
    my @fresh-types;
    my @out;
    my $i = 0;
    my $n = $src.chars;
    my $st = 'normal';
    my $open; my $close;
    my $bq-depth = 0;
    my $depth = 0;

    while $i < $n {
        my $c = $src.substr($i, 1);

        # ── 字符串/注释/正则状态处理 ──
        if $st eq 'comment' {
            @out.push($c); $st = 'normal' if $c eq "\n"; $i++; next;
        }
        if $st eq 'sq' {
            @out.push($c);
            if $c eq q{'} {
                if $i + 1 < $n && $src.substr($i+1,1) eq q{'} { @out.push($src.substr($i+1,1)); $i += 2; next }
                $st = 'normal';
            }
            $i++; next;
        }
        if $st eq 'dq' {
            @out.push($c);
            if $c eq '\\' { @out.push($src.substr($i+1,1)); $i += 2; next }
            $st = 'normal' if $c eq q{"};
            $i++; next;
        }
        if $st eq 'bq' {
            @out.push($c);
            if $c eq $open { $bq-depth++ }
            elsif $c eq $close { $st = 'normal' if $bq-depth == 0; $bq-depth-- if $bq-depth > 0 }
            $i++; next;
        }
        if $st eq 'rx' {
            @out.push($c);
            if $c eq '\\' { @out.push($src.substr($i+1,1)); $i += 2; next }
            $st = 'normal' if $c eq '/';
            $i++; next;
        }

        # ── normal 状态 ──
        if $c eq '#' { $st = 'comment'; @out.push($c); $i++; next }
        if $c eq q{'} { $st = 'sq'; @out.push($c); $i++; next }
        if $c eq q{"} { $st = 'dq'; @out.push($c); $i++; next }
        if $c eq 'q' | 'Q' {
            my $prev = $i > 0 ?? $src.substr($i-1,1) !! ' ';
            my $wordy = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$@%&.'.contains($prev) || $prev eq ']';
            if !$wordy {
                if $src.substr($i) ~~ /^ [ 'q' | 'Q' ] [ 'q' | 'x' | 'w' | 'wv' | 'ww' | 'v' ]? ':'? <[a..z]>* $<brk>=('[' | '(' | '{' | '<') / -> $m {
                    my $b = $m<brk>.Str;
                    $open  = $b;
                    $close = $b eq '[' ?? ']' !! $b eq '(' ?? ')' !! $b eq '{' ?? '}' !! '>';
                    $bq-depth = 0; $st = 'bq'; @out.push($c); $i++; next;
                }
            }
        }
        if $src.substr($i) ~~ /^ [ 'm' | 'rx' | 's' | 'ms' | 'ss' | 'tr' ] \s* '/' / {
            $st = 'rx'; @out.push($c); $i++; next;
        }

        if $c eq '{' || $c eq '(' || $c eq '[' { $depth++ }
        elsif $c eq '}' || $c eq ')' || $c eq ']' { $depth-- }

        # ── 深度 0 时检测声明关键字 ──
        if $depth == 0 {
            # 变量声明：my / our / state 后跟空白
            if $src.substr($i) ~~ /^ (my|our|state) \s+ / {
                my $match-len = $/.chars;
                my $rest-start = $i + $match-len;
                my $semi = $src.index(';', $rest-start);
                my $nl   = $src.index("\n", $rest-start);
                my $line-end = $semi.defined && ($nl.defined.not || $semi < $nl) ?? $semi !! ($nl // $n);
                my $decl-line = $src.substr($rest-start, $line-end - $rest-start);
                my $decl-part = $decl-line.split('=', 2)[0] // $decl-line;
                my @names = extract-var-names($decl-part);

                if @names {
                    my $redecl = @names.first({ $ps.has-var($_) }).defined;
                    if $redecl {
                        # 部分变量已声明：去掉 my/our/state 关键字；
                        # 新变量只登记到 ps（需 our 前置），不进 fresh-vars
                        for @names -> $name {
                            unless $ps.has-var($name) { $ps.add-var($name) }
                        }
                    } else {
                        @out.push('our ');         # 首次声明：my/state → our
                        for @names -> $name {
                            unless $ps.has-var($name) {
                                $ps.add-var($name);
                                @fresh-vars.push: $name;
                            }
                        }
                    }
                    $i += $match-len; next;
                }
            }

            # sub 声明
            my $sub-match = $src.substr($i) ~~ /^ [ [multi|proto|only] \s+ ]? sub \s+ /;
            my $short-match = !$sub-match && ($src.substr($i) ~~ /^ [multi|proto|only] \s+ \w+ /);
            if $sub-match || $short-match {
                my $decl-start = $i;
                my $decl-end = find-decl-end($src, $decl-start);
                my $decl-text = $src.substr($decl-start, $decl-end - $decl-start);
                my $name = extract-sub-name($decl-text);
                if $name.chars {
                    $ps.add-sub($name, $decl-text);
                    @fresh-subs.push: $name;
                }
                @out.push($decl-text);
                $i = $decl-end; next;
            }

            # 类型声明：class / role / grammar / enum（可选 our 前缀）
            if $src.substr($i) ~~ / ^ [our\s+]? [class|role|grammar|enum] \s+ / {
                my $decl-start = $i;
                my $decl-end = find-decl-end($src, $decl-start);
                my $decl-text = $src.substr($decl-start, $decl-end - $decl-start);
                my $name = extract-type-name($decl-text);
                if $name.chars && !$ps.has-type($name) {
                    $ps.add-type($name);
                    @fresh-types.push: $name;
                }
                @out.push($decl-text);
                $i = $decl-end; next;
            }
        }

        @out.push($c);
        $i++;
    }

    return (@out.join, @fresh-vars, @fresh-subs, @fresh-types);
}

# ── 构建完整 EVAL 源码 ──────────────────────────────────────────────
our sub build-eval-source(Str $transformed, PersistState $ps,
                      @fresh-vars, @fresh-subs, @fresh-types --> Str) is export {
    my Set $fresh-var-set .= new(@fresh-vars);
    my Set $fresh-sub-set .= new(@fresh-subs);
    my Set $fresh-type-set .= new(@fresh-types);

    # 1. our 变量前置声明（不含本格新声明的变量）
    my @our-decls = $ps.vars.grep({ !($_ (elem) $fresh-var-set) }).map({ "our $_;" });
    my $our-prefix = @our-decls.join("\n");

    # 2. sub 声明累积（不含本格新声明的 sub，避免同格重复声明）
    my $sub-prefix = $ps.sub-source-excluding(@fresh-subs);

    # 3. 类型别名 constant Name = OUR::Name（不含本格新声明的类型）
    my @type-aliases = $ps.types.grep({ !($_ (elem) $fresh-type-set) }).map({ "constant $_ = OUR::$_;" });
    my $type-prefix = @type-aliases.join("\n");

    my @parts;
    @parts.push: $our-prefix if $our-prefix.chars;
    @parts.push: $sub-prefix if $sub-prefix.chars;
    @parts.push: $type-prefix if $type-prefix.chars;
    @parts.push: $transformed;

    @parts.join("\n");
}

# ── 主循环 ──────────────────────────────────────────────────────────
our sub json-server-loop(--> Int) is export {
    start-daemon-if-needed(:silent);

    say to-json({ rakuish => "ready", daemon => daemon-running() }, :!pretty);
    $*OUT.flush;

    my $ps        = PersistState.new;
    my Bool $watch-on = False;
    my atomicint $failed-count = 0;
    my $eval-chain = Promise.kept;
    my $result-channel = Channel.new;
    my @pending;

    sub error-hint(Str $cmd, Str $err --> Str) {
        my $first = $cmd.words[0] // q{};
        my @shell-bt = <export unset cd alias type pwd history source clear>;
        if $first eq any(@shell-bt) {
            return qq/"$first" is a shell builtin -- prefix with !/;
        }
        if $cmd ~~ / \| | \> / {
            return q[Looks like shell syntax -- prefix with !];
        }
        if $err ~~ /Undeclared\s+routine|Undefined\s+routine/ {
            return q[Name not declared. If shell cmd, prefix with !];
        }
        return q{};
    }

    sub parse-req(Str $raw --> Map) {
        if $raw.starts-with('{') && $raw.ends-with('}') {
            my %j = try { from-json($raw) };
            if %j<cmd>.defined || %j<raku>.defined || %j<shell_cmd>.defined {
                my $cmd = (%j<cmd> // %j<shell_cmd> // %j<raku>).Str;
                my $id  = %j<id>.defined ?? %j<id>.Str !! Nil;
                my $shell = %j<shell>.defined ?? Bool(%j<shell>.Int) !! Nil;
                return %(:cmd($cmd), :$id, :$shell);
            }
        }
        return %(:cmd($raw));
    }

    sub is-shell(Str $cmd --> Bool) {
        return True if $cmd.starts-with('!');
        return True if $cmd.starts-with( any('export ', 'unset ', 'cd ', 'alias ', 'type ', 'pwd', 'history') );
        return False;
    }

    sub handle-magic(Str $cmd --> Map) {
        my $body = $cmd.substr(1).trim;
        my ($name, $arg) = $body.split(/\s+/, 2);
        $name = $name.lc;
        $arg  = $arg.trim if $arg.defined;

        given $name {
            when 'eval-engine' {
                if $arg.defined && ($arg eq 'rakudo' || $arg eq 'rakupp') {
                    if $arg eq 'rakupp' {
                        my $p = rakupp-path();
                        unless $p.chars {
                            return %(:ok(False), :magic('eval-engine'),
                                      :message('rakupp not found (set RAKUPP or install to ~/.rakupp/bin/rakupp)'));
                        }
                    }
                    $EVAL-ENGINE = $arg;
                    return %(:ok(True), :magic('eval-engine'), :message("EVAL engine switched: $arg"));
                }
                return %(:ok(True), :magic('eval-engine'),
                          :message("current EVAL engine: $EVAL-ENGINE"));
            }
            when 'watch' {
                if $arg.defined {
                    $watch-on = $arg eq 'on' ?? True !! ($arg eq 'off' ?? False !! $watch-on);
                }
                return %(:ok(True), :magic('watch'), :message("watch: {$watch-on ?? 'on' !! 'off'}"));
            }
            when 'shell' {
                if $arg.defined && $arg (elem) @SHELL-BACKENDS {
                    $SHELL-BACKEND = $arg;
                    return %(:ok(True), :magic('shell'), :message("shell backend switched: $arg"));
                }
                return %(:ok(True), :magic('shell'), :message("current shell backend: $SHELL-BACKEND"));
            }
            when 'quit' | 'exit' {
                return %(:ok(True), :magic('quit'), :message('bye'), :quit(True));
            }
            default {
                return %(:ok(False), :magic($name), :message("unknown magic command: %$name"));
            }
        }
    }

    my $reader = start {
        for $*IN.lines -> $line {
            last unless defined $line;
            my $raw = $line.Str.trim;
            next if $raw eq q{};

            my %req = parse-req($raw);
            my $cmd = %req<cmd>;
            my $id  = %req<id> // "cmd-{+@pending + 1}";

            # 只有已知的 % 魔法命令才走 magic 分支；
            # %h<c> / %hash<key> 等 Raku 哈希访问交给 EVAL。
            if $cmd.starts-with('%') {
                my $body = $cmd.substr(1).trim;
                my $mname = ($body.split(/\s+/, 2)[0] // '').lc;
                if $mname (elem) <eval-engine watch shell quit exit> {
                    my %m = handle-magic($cmd);
                    my $quit = %m<quit>:exists && %m<quit>;
                    $result-channel.send({ id => $id, ok => %m<ok>, magic => %m<magic>,
                                           message => %m<message>, shell => False, code => 0 });
                    last if $quit;
                    next;
                }
            }

            my $is-shell = %req<shell>.defined ?? %req<shell> !! is-shell($cmd);
            my $shell-cmd = $is-shell && $cmd.starts-with('!') ?? $cmd.substr(1).trim !! $cmd;

            if $is-shell {
                my $task = start {
                    my $t0 = now;
                    my $r = run-engine($shell-cmd, Hash.new, :capture(True));
                    my $elapsed = ((now - $t0) * 1000).Int;
                    $failed-count⚛++ if $r.code != 0;
                    $result-channel.send({
                        id     => $id, ok => $r.ok, code => $r.code,
                        stdout => $r.stdout, stderr => $r.stderr,
                        shell  => True, elapsed_ms => $elapsed,
                    });
                };
                @pending.push: $task;
            }
            else {
                my $prev = $eval-chain;
                $eval-chain = start {
                    await $prev;
                    my $t0 = now;

                    my ($transformed, $fresh-v, $fresh-s, $fresh-t) = transform-cell($cmd, $ps);
                    my $full-src = build-eval-source($transformed, $ps, @$fresh-v, @$fresh-s, @$fresh-t);

                    my $lex = LexState.new;   # 空 accum：只 EVAL 当前格
                    my $r = eval-cell($full-src, :state($lex), :watch($watch-on));

                    my $elapsed = ((now - $t0) * 1000).Int;
                    my %resp = (
                        id => $id, ok => $r.ok,
                        code => $r.ok ?? 0 !! 1,
                        stdout => $r.extra-output,
                        stderr => $r.error.defined ?? $r.error.Str !! q{},
                        value => $r.value.defined ?? $r.value.Str !! q{},
                        shell => False, elapsed_ms => $elapsed,
                    );
                    if $watch-on && $r.watch.elems { %resp<watch> = $r.watch }
                    unless $r.ok {
                        my $hint = error-hint($cmd, $r.error.Str);
                        %resp<hint> = $hint if $hint.chars;
                    }
                    $failed-count⚛++ unless $r.ok;
                    $result-channel.send(%resp);
                };
                @pending.push: $eval-chain;
            }
        }

        await Promise.allof(@pending) if @pending;
        $result-channel.close;
    }

    for $result-channel.list -> %result {
        say to-json(%result, :!pretty);
        $*OUT.flush;
    }

    await $reader;

    my $last-code = $failed-count > 0 ?? 1 !! 0;
    stop-daemon;
    say to-json({ rakuish => "done", exit => $last-code }, :!pretty);
    return $last-code;
}
