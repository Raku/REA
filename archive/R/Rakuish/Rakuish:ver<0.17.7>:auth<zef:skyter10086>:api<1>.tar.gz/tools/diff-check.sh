#!/usr/bin/env bash
# 对拍总入口：同一批用例分别喂给 **真 bash** 与 **Rakuish 原生 shell 层**，
# 比对 **stdout**（严格）与 **stderr**（仅提示）。
#
# 用法：bash tools/diff-check.sh [用例文件...]
#        不带参数 ⇒ 跑 tools/diff-cases/ 下的全部用例。
#
# 为什么必须做对拍：
#   自己实现的 bash 语义，偏差**绝大多数是静默的** —— 不报错、结果错。
#   本轮就靠它抓到了两个「看起来能跑」的 bug：
#     · 复合赋值 `+=` 全部失效（Raku 的 `<...>` 不剥引号）
#     · 除零 / `${V:?}` 不中止这条命令
#
# ── 两类用例 ────────────────────────────────────────────────────────
#
# ① **普通用例** ⇒ stdout 必须与真 bash **逐条一致**。
#
# ② **标记用例**（行尾带 `  #!unsupported`）⇒ 这条语法 native 后端
#    **还没实现** ⇒ 不比对 stdout，改为断言「raku 侧**明确报错**了」
#    （退出码 2 + 文本里有「不支持」）。
#
#    ⚠ 为什么要这一类（2026-11-05 引擎纯化）：
#      引擎纯化之后 native 后端**不再**把不支持的语法偷偷交给 `sh -c`
#      （本机 `/bin/sh` 是 dash，差异会静默泄漏）⇒
#      不支持的用例**必然**与 bash 不同。
#      与其让工具一直报 DIFF（噪声），不如把「不支持」也**变成断言** ——
#      这样「不许跨引擎委托」这条规则本身也被锁住了。
#
# ⚠ **已知差异**（stderr 措辞，行为一致）：
#   · 除零：bash `1/0: division by 0 (error token is "0")`
#            我们 `1/0: division by zero`
#   · 未闭合的 `$((`：bash 报自己的语法错；我们明确报「不支持」
_here="$(cd "$(dirname "$0")" && pwd)"
source "$_here/env.sh"          # 统一探测 raku（并把它塞进 PATH，供引擎的
cd "$_here/.." || exit 1        # `#!/usr/bin/env raku` shebang 找到）

R=$RAKU
mkdir -p tmp

files=("$@")
if [ ${#files[@]} -eq 0 ]; then
    files=(tools/diff-cases/*.txt)
fi

status=0
for f in "${files[@]}"; do
    bash tools/diff-bash.sh "$f" > "tmp/.diff-bash.out"
    "$R" tools/diff-rakuish.raku "$f" > "tmp/.diff-rakuish.out"

    # 标记用例的行号（native 后端不支持的那些）
    # ⚠ 排除**注释行**（`grep -v '^[0-9]*:[[:space:]]*#'`）——
    #   用例文件的说明文字里也可能出现 `#!unsupported` 这个词。
    grep -n '#!unsupported' "$f" | grep -v '^[0-9]*:[[:space:]]*#' \
        | cut -d: -f1 | sort -n > "tmp/.diff-marked"

    # stdout 严格比对（第 2 段）—— **只比对普通用例**
    #   （标记用例的 stdout 必然不同：bash 支持、我们明确不支持）
    # ⚠ 用 `FILENAME==markfile` 而不是 `NR==FNR` —— 后者在**第一个文件为空**时
    #   会把第二个文件的**第一行**也当成标记文件吃掉（awk 的经典坑）。
    # ⚠ stdout 比对**只取前两段**（行号 | stdout）——
    #   stderr 的措辞差异（除零等）不该算进 stdout 比对。
    awk -F'|' -v mk="tmp/.diff-marked" 'FILENAME==mk { m[$1] = 1; next } !($1 in m) { print $1 "|" $2 }' \
        "tmp/.diff-marked" "tmp/.diff-bash.out" > "tmp/.diff-bash.out-only"
    awk -F'|' -v mk="tmp/.diff-marked" 'FILENAME==mk { m[$1] = 1; next } !($1 in m) { print $1 "|" $2 }' \
        "tmp/.diff-marked" "tmp/.diff-rakuish.out" > "tmp/.diff-rakuish.out-only"

    if diff -u "tmp/.diff-bash.out-only" "tmp/.diff-rakuish.out-only" > "tmp/.diff.out"; then
        echo "OK   $f（stdout 逐条一致）"
    else
        echo "DIFF $f（stdout 不一致！）"
        cat "tmp/.diff.out"
        status=1
    fi

    # 标记用例：断言 raku 侧**确实明确报错**了
    awk -F'|' -v mk="tmp/.diff-marked" 'FILENAME==mk { m[$1] = 1; next } ($1 in m) && $2 != "!UNSUPPORTED" { print "  行 " $1 ": 本该「明确报不支持」，实际 stdout=[" $2 "] stderr=[" $3 "]" }' \
        "tmp/.diff-marked" "tmp/.diff-rakuish.out" > "tmp/.diff-unsup.out"
    if [ -s "tmp/.diff-unsup.out" ]; then
        echo "DIFF $f（标记为不支持的用例没有明确报错！）"
        cat "tmp/.diff-unsup.out"
        status=1
    fi

    # stderr 只提示（第 3 段）—— 标记用例不比（它们**本来就**该有差异）
    awk -F'|' -v mk="tmp/.diff-marked" 'FILENAME==mk { m[$1] = 1; next } !($1 in m) { print $1 "|" $3 }' \
        "tmp/.diff-marked" "tmp/.diff-bash.out" | sed 's/|bash: line 1: /|/' > "tmp/.diff-bash.err"
    awk -F'|' -v mk="tmp/.diff-marked" 'FILENAME==mk { m[$1] = 1; next } !($1 in m) { print $1 "|" $3 }' \
        "tmp/.diff-marked" "tmp/.diff-rakuish.out" > "tmp/.diff-rakuish.err"
    if ! diff -u "tmp/.diff-bash.err" "tmp/.diff-rakuish.err" > "tmp/.diff-err.out"; then
        echo "     （stderr 措辞差异，仅提示 —— 已知：除零 / 未闭合的算术展开）"
        head -8 "tmp/.diff-err.out"
    fi
done

exit $status
