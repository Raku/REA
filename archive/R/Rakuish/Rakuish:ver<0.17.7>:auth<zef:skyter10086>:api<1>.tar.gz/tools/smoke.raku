# 端到端冒烟：三个组件串起来跑一遍
#
# 与 t/*.t 的区别：那些是单元测试（逐条断言、两个实现上都跑）；
# 这里是**集成冒烟** —— 多行判定 → 快档求值 → Prompt/LineEditor 起编辑器，
# 用来确认三层能接在一起。它需要**真实尺寸的 pty**（见 README），
# 所以不在 t/ 里，避免被当成普通测试跑出误导性的失败。
#
# 用法（注意要 stty 给尺寸，script 默认给的 pty 是 0x0）：
#   script -q -c "stty rows 40 cols 120; ~/bin/rakuish-dev raku tools/smoke.raku" /dev/null

use lib q{lib};
use Rakuish::Incomplete;
use Rakuish::Eval;
use Prompt;
use Commands;

sub tab-complete(Str $line, Int $pos --> Str) { q{} }

# --- 1. 多行判定（决定要不要续行）---
my $dq = chr(34);
my @cases = (q{1 +}, q{1 +)}, q{sub } ~ chr(123),
                    q{my $x = (1,2)},
                    $dq ~ q{abc});
my @want = (True, False, True, False, True);
my $bad = 0;
for ^@cases.elems -> $i {
    my $c = @cases[$i];
    my $w = @want[$i];
    my $got = is-incomplete($c);
    if $got != $w {
        $bad++;
        say qq{判定错: [$c] 期望=$w 实得=$got};
    }
}
say qq{多行判定: } ~ (5 - $bad) ~ qq{/5 正确};

# --- 2. 快档求值 ---
my $r1 = eval-cell(q{1 + 1}, :index(1));
say qq{In[1]: 1 + 1 => } ~ render-out(1, $r1.value, :color(False));

my $r2 = eval-cell(q{store-set(q{answer}, 42); store-get(q{answer})}, :index(2));
say qq{In[2]: 跨 cell 共享 => } ~ render-out(2, $r2.value, :color(False));

my $r3 = eval-cell(q{1 +) }, :index(3));
say qq{In[3]: 语法错 => } ~ (($r3.ok) ?? q{居然成功了} !! q{正确报错});
print render-error($r3, :color(False));

# --- 3. Prompt 起 LineEditor 后端 ---
my $h = $*HOME.Str.IO.add(chr(46) ~ q{rakuish-smoke-history});
my $p = Prompt.new(q{LineEditor}, :history($h),
                   :additional-completions([&tab-complete]));
say qq{编辑器: } ~ $p.editor-name;
$p.add-history(q{1 + 1});
$p.save-history;
# 注意：$p.history 返回的是上面那个 IO::Path，不是历史条目数组
say qq{历史文件: } ~ ($h.e ?? q{已写} !! q{没写});
try unlink $h;