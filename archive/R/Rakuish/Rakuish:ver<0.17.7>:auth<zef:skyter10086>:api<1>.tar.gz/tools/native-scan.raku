#!/usr/bin/env raku
# native 扫描（Rakuish 侧）：把用例文件里的每一行喂给**原生 shell 层**，
# 输出「行号|退出码|stdout|stderr」。
#
# 用法：raku tools/native-scan.raku tools/native-cases.txt
use lib 'lib';
use Rakuish::Shell::Exec;

my $file = @*ARGS[0] // 'tools/native-cases.txt';
my @lines = $file.IO.slurp.split("\n");
my $i = 0;
for @lines -> $line {
    $i++;
    next if $line.trim eq q{};
    next if $line.trim.starts-with('#');
    # 去掉行尾标记（`  #!unsupported` / `  #!note: xxx`）
    my $p = $line.rindex('#!') // -1;
    my $cmd = $p >= 0 ?? $line.substr(0, $p).trim !! $line;
    my $r = run-shell-line($cmd, :capture(True));
    my $out = $r.stdout.Str;
    my $err = $r.stderr.Str;
    $out = $out.subst(/\n$/, q{}, :g);
    $err = $err.subst(/\n$/, q{}, :g);
    $out = $out.subst(/\n/, q{\n}, :g);
    $err = $err.subst(/\n/, q{\n}, :g);
    printf("%d|%d|%s|%s\n", $i, $r.code, $out, $err);
}
