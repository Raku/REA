# tools/env.sh —— 工具链共用的环境探测（被 tools/*.sh source）
#
# 它解决两件事：
#
# 1) **找到 raku 的绝对路径**（$RAKU）
#    优先级：$RAKU 环境变量 > rakubrew 装的版本 > PATH 里的 raku。
#    ⚠ 2026-11-04 之前四个工具各写各的：两个硬编码 `moar-2026.09`、
#    两个用 `command -v raku` 兜底 ⇒ 升级 rakubrew 版本时**会悄悄失效**。
#
# 2) **把 raku 所在目录前置到 PATH**
#    这一步不是锦上添花：`bin/rakuish` 与 `bin/rakuish-sh` 的 shebang 是
#    `#!/usr/bin/env raku`，shell 引擎（shell 语义的实际执行者）靠它启动
#    ⇒ **raku 必须在 PATH 里**，否则引擎全灭（成片 exit 127，
#    看着像上百个功能缺陷）。本机的 raku 装在 rakubrew 下、默认不在 PATH。
#
# 用法：source "$(dirname "$0")/env.sh"  ⇒ 之后 $RAKU 就是可用的 raku 绝对路径。
#       找不到 raku 时本文件直接 exit 2（与各工具原有的约定一致）。

# ── 1. 定位 raku ──────────────────────────────────────────────────
# ⚠ **先把 RAKU 兜成空串**：本文件被 `set -u` 的工具 source
#   （`stress.sh` / `bash-parity.sh`）⇒ 后面任何裸 `$RAKU` 引用都会致命。
#   （0.16.4 自检时真踩过：`[ -z "$RAKU" ]` 在 RAKU 未设置时直接
#   "line 31: RAKU: unbound variable" ⇒ 「找不到 raku」时不是干净 exit 2。）
RAKU="${RAKU:-}"

# 用户显式给的 RAKU 优先（可以是绝对路径，也可以是 PATH 里的命令名）
if [ -n "${RAKU:-}" ] && [ ! -x "$RAKU" ]; then
  RAKU="$(command -v "$RAKU" 2>/dev/null || true)"
fi

if [ -z "${RAKU:-}" ]; then
  # a) 文档基线版本优先 —— 验收口径要稳定，不能因为机器上多装一个版本就漂
  if [ -x "$HOME/.rakubrew/versions/moar-2026.09/install/bin/raku" ]; then
    RAKU="$HOME/.rakubrew/versions/moar-2026.09/install/bin/raku"
  fi
  # b) rakubrew 的其它版本（取版本号最高的那个）
  if [ -z "${RAKU:-}" ]; then
    for cand in "$HOME"/.rakubrew/versions/*/install/bin/raku; do
      [ -x "$cand" ] && RAKU="$cand"
    done
  fi
  # c) PATH 里
  if [ -z "${RAKU:-}" ]; then
    RAKU="$(command -v raku 2>/dev/null || true)"
  fi
fi

if [ -z "${RAKU:-}" ] || [ ! -x "$RAKU" ]; then
  echo "找不到 raku：装一个（rakubrew / rakudo），或设 RAKU=/path/to/raku" >&2
  exit 2
fi

# 绝对化（相对路径在 cd 之后会指错地方）
RAKU="$(cd "$(dirname "$RAKU")" && pwd)/$(basename "$RAKU")"
RAKU_DIR="$(dirname "$RAKU")"

# ── 2. 让 `#!/usr/bin/env raku` 找得到它 ───────────────────────────
case ":$PATH:" in
  *":$RAKU_DIR:"*) : ;;
  *) PATH="$RAKU_DIR:$PATH" ;;
esac

export RAKU RAKU_DIR PATH
