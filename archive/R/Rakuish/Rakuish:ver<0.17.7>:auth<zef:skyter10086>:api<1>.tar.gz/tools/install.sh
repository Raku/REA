#!/usr/bin/env bash
# 安装 Rakuish 到当前 Raku 环境（zef）
set -euo pipefail

here="$(cd "$(dirname "$0")/.." && pwd)"
cd "$here"

# 确保启动器与 shell 引擎都有可执行位（引擎由 run-engine 直接 exec）
chmod +x bin/rakuish bin/rakuish-sh

if ! command -v zef >/dev/null 2>&1; then
    echo "未找到 zef。请先安装 Raku 工具链（rakubrew / rakudo 自带 zef）。" >&2
    exit 1
fi

echo "==> 用 zef 安装 Rakuish（读取 META6.json，自动拉取 Prompt / Commands 依赖）"
zef install .

echo
echo "完成。之后可直接运行："
echo "    rakuish"
echo "    # 或：raku $here/bin/rakuish"
