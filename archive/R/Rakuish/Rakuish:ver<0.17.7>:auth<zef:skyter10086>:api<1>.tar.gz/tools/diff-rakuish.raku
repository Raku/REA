#!/usr/bin/env raku
# 对拍脚本（Rakuish 侧）：把用例文件里的每一行喂给**原生 shell 层**，
# 输出「行号|stdout|stderr]」（格式与 tools/diff-bash.sh 一致）。
#
# 用法：raku tools/diff-rakuish.raku tools/diff-cases/arith.txt
#
# ⚠ 本版 Rakudo **没有** `@ARGV` 这个预声明变量（实测：编译报错
#   "Variable '@ARGV' is not declared"）—— 命令行参数在 `@*ARGS` 里。
#
# ── 「native 后端不支持」的用例怎么对拍 ──────────────────────────────
#
# 用例行尾可以带标记 `  #!unsupported`（**两个空格**分隔）：
#
#     echo $( (echo a) )  #!unsupported
#
# 它的含义是：**这条语法 native 后端还没实现** ⇒ 我们**不**比对 stdout，
# 改为断言「raku 侧确实**明确报错**了」（退出码 2 + 报错文本里有「不支持」）。
#
# 为什么要有这个机制（2026-11-05）：
#   引擎纯化之后，native 后端**不再**把不支持的语法偷偷交给 `sh -c`
#   （那是 dash，语义差异会静默泄漏）⇒ 不支持的用例**必然**与 bash 不同。
#   与其让对拍工具一直报 DIFF（噪声），不如把「不支持」也**变成断言** ——
#   这样「不许跨引擎委托」这条规则本身也被锁住了。
use lib 'lib';
use Rakuish::Shell::Exec;

my $file = @*ARGS[0] // 'tools/diff-cases/arith.txt';
my @lines = $file.IO.slurp.split("\n");
my $i = 0;
for @lines -> $line {
    $i++;
    next if $line.trim eq q{};
    # ⚠ **注释行也要跳过**（行号仍然计数，两边才对得上）：
    #   注释里可能有反引号 / 引号 —— 交给 bash 会变成命令替换。
    next if $line.trim.starts-with('#');

    # 标记：`  #!unsupported` ⇒ 这条是「native 后端不支持」的用例
    #
    # ⚠ **不用正则**（Raku 的正则字面量里 `#` 是注释起始符 ⇒ 会把后半段
    #   当注释吃掉，编译报 "Unrecognized regex metacharacter !"）。
    #   `rindex` 找不到时返回 **Nil**（不是 -1）⇒ 必须 `// -1` 兜住。
    my $p = $line.rindex('#!unsupported') // -1;
    my $marked = $p >= 0 ?? True !! False;
    my $cmd = $marked ?? $line.substr(0, $p).trim !! $line;

    my $r = run-shell-line($cmd, :capture(True));
    my $out = $r.stdout.Str;
    my $err = $r.stderr.Str;
    # bash 侧用 $(...) 捕获 → **去掉尾部换行**；这边对齐
    $out = $out.subst(/\n$/, q{}, :g);
    $err = $err.subst(/\n$/, q{}, :g);
    $out = $out.subst(/\n/, q{\n}, :g);
    $err = $err.subst(/\n/, q{\n}, :g);

    if $marked {
        # 断言「明确报错」：退出码 2（bash 的语法错误码）+ 文本里有「不支持」
        if $r.code == 2 and $err.contains('不支持') {
            $out = '!UNSUPPORTED';
        }
        # else ⇒ 保留真实输出 ⇒ 对拍工具会报 DIFF（说明「本该不支持却支持了」
        #   或者「该报错却没报」—— 两种都是问题）
    }
    printf("%d|%s|%s\n", $i, $out, $err);
}
