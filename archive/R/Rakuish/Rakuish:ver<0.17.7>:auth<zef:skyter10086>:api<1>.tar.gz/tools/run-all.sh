#!/usr/bin/env bash
# 全套件回归：每个套件在 **Rakudo（MoarVM）** 上跑，结果写 tmp/all.log。
#
# ⚠⚠ 变更记录（第六批）：**不再跑 rakupp**。
#   原因：rakupp 的实现差异逼出了一堆「为了兼容 rakupp 而写」的变通
#   （Hash 当状态、前向引用禁令、`~` 的位取反手写…），
#   而这些变通让代码偏离 idiomatic Raku、也偏离 bash 语义。
#   项目**只在 Rakudo（MoarVM）平台上实现** ⇒ rakupp 不再是验收基线。
#   （差异清单见 HANDOFF §4.1 / §4.8）
#
# **退出码和 not ok 计数必须一起看**。本项目踩过：测试崩在中途
# （后面 subtest 根本没跑）时 `not ok` 计数是 0，但退出码非 0 ——
# 只看计数会把"测试崩了"当成"全绿"。
#
# 用法：bash tools/run-all.sh

_here="$(cd "$(dirname "$0")" && pwd)"
source "$_here/env.sh"          # 统一探测 raku（并把它塞进 PATH，供引擎的
cd "$_here/.." || exit 1        # `#!/usr/bin/env raku` shebang 找到）

R=$RAKU
mkdir -p tmp

total=0
: > tmp/all.log

for t in t/[0-9]*.t; do
    name=$(basename "$t")

    timeout 300 "$R" "$t" > "tmp/$name.out" 2>&1
    rc_m=$?
    n_m=$(grep -c 'not ok' "tmp/$name.out")
    # 顶层 TAP plan 行（1..N）：缺了 `prove` 会判 "No plan found" ⇒ FAIL。
    # 这类问题 `not ok` 为 0 且 rc 为 0 ⇒ 不单独查就会「绿灯漏过」。
    p_m=$(grep -cE '^1\.\.[0-9]+$' "tmp/$name.out")
    printf '%-24s MoarVM rc=%s notok=%s plan=%s\n' "$name" "$rc_m" "$n_m" "$p_m" >> tmp/all.log

    total=$(( total + n_m ))
    # 退出码非 0 也要计入（测试崩在中途的情形）
    [ "$rc_m" -ne 0 ] && total=$(( total + 1 ))
    # 缺顶层 plan 也要计入（与 prove 口径对齐）
    [ "$p_m" -eq 0 ] && total=$(( total + 1 ))
done

echo "-----------------------------------------" >> tmp/all.log
echo "问题总数（not ok + 非零退出码 + 缺 TAP plan）: $total" >> tmp/all.log
cat tmp/all.log