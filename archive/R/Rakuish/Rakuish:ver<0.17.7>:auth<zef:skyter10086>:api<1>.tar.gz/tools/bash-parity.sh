#!/bin/bash
# bash 兼容层对拍 v2：每个用例是一句可在单行表达的 bash 片段，
# 交给 `! <fragment>`（rakuish 的 bash 直通前缀）与真 bash 各跑一次，比 rc + stdout。
#
# 用法: bash tools/bash-parity.sh
set -u
_here="$(cd "$(dirname "$0")" && pwd)"
source "$_here/env.sh"          # 统一探测 raku（找不到时这里就 exit 2）
cd "$_here/.." || exit 2
ROOT=$PWD
R=$RAKU
W=$(mktemp -d /tmp/rk-parity-XXXXXX)

cases=(
'01-var|NAME=world; GREETING="hello $NAME"; echo "$GREETING"; echo "${MISSING:-dflt}"'
'02-cmdsub|now=$(echo hi); n=$(printf "a\nb\n" | wc -l); echo "$now $n"'
'03-pipe|printf "a\nb\na\n" | sort | uniq -c | sort -rn | head -1'
'04-redirect|echo one > '"$W"'/f; echo two >> '"$W"'/f; wc -l < '"$W"'/f'
'05-forglob|for f in '"$W"'/*.txt; do echo "f=$f"; done'
'06-whileread|printf "x\ny\n" > '"$W"'/l; while read -r line; do echo "L=$line"; done < '"$W"'/l'
'07-if-test|if [ -f '"$W"'/f ]; then echo file; else echo nofile; fi'
'08-dbracket|s=app.log; if [[ $s == *.log ]]; then echo match; fi'
'09-case|x=b; case $x in a) echo A;; b) echo B;; *) echo other;; esac'
'10-func|f() { echo "hi $1"; }; f bob'
'11-arith|i=1; i=$((i+2)); echo "i=$i"'
'12-array|arr=(a b c); echo "${arr[@]} ${#arr[@]} ${arr[1]}"'
'13-braceexp|echo '"$W"'/{a,b}.txt'
'14-subshell|( cd /tmp && pwd )'
'15-xargs|printf "a\nb\n" | xargs -n1 echo pre'
'16-export|export FOO=bar; bash -c "echo $FOO"'
'17-sete|set -e; false || echo handled; echo alive'
'18-local|f() { local v=in; echo $v; }; v=out; f; echo $v'
'19-teststr|[ -n "" ] && echo empty || echo nonempty'
'20-exitcode|false; echo "rc=$?"'
# 0.16.7（§10.1 #11）：read -p 的提示语去向。
# `</dev/null` 是为了**不阻塞**（stdin 不是终端时 bash 不打印提示语）。
'21-readp|read -p "P: " v < /dev/null; echo "v=[$v]"'
)
: > "$W"/f; : > "$W"/a.txt; : > "$W"/b.txt

printf '%-14s %4s %4s %-6s %s\n' 用例 bash raku 一致? 说明
printf '%.0s-' {1..74}; echo
same=0; diff=0
i=0
for c in "${cases[@]}"; do
  n=${c%%|*}; frag=${c#*|}
  i=$((i+1))
  echo "! $frag" > "$W/c.rakuish"
  bout=$(bash -c "$frag" 2>&1); brc=$?
  rout=$("$R" -I "$ROOT/lib" "$ROOT/bin/rakuish" "$W/c.rakuish" 2>&1); rrc=$?
  if [ "$brc" = "$rrc" ] && [ "$bout" = "$rout" ]; then
    st='一致'; same=$((same+1)); note=''
  else
    st='差异'; diff=$((diff+1))
    note=$(echo "$rout" | grep -m1 -E 'Missing|未定义|语法错误|运行时错误' | cut -c1-40)
    [ -z "$note" ] && note=$(echo "$rout" | head -1 | cut -c1-40)
  fi
  printf '%-14s %4s %4s %-6s %s\n' "$n" "$brc" "$rrc" "$st" "$note"
done
printf '%.0s-' {1..74}; echo
echo "一致 $same，差异 $diff （差异即 bash 兼容层缺口）"
