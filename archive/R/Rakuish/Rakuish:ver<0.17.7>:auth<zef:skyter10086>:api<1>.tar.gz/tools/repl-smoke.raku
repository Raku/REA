use lib q{lib};
use Rakuish::Loop;
use Prompt;

# 交互层端到端：真的起Prompt/LineEditor、真的读 pty。
# 单元测试走 `drive`（注入读入），那条路径覆盖不到"Prompt 能否起来、
# 历史能否落盘、提示符能不能显示"。这个脚本补上那一段。
#
# 必须给pty 一个真实尺寸 —— 无 pty 时 Terminal::API::get-config 抛错，
# script 默认给的 0x0 会让 "Terminal size is sane" 失败：
#   script -q -c "stty rows 40 cols 120; ~/bin/rakuish-dev raku tools/repl-smoke.raku" /dev/null

my $hist = $*HOME.Str.IO.add(chr(46) ~ q{rakuish-repl-smoke});
my $p = Prompt.new('LineEditor', :history($hist),
                   :additional-completions([&complete-at]));

say q{编辑器: } ~ $p.editor-name;
say q{历史文件已建: } ~ ($hist.e ?? q{是} !! q{否});

# 提示符要能显示（不真的读，只构造）
say q{首行提示符: } ~ prompt-for(False, $*CWD.basename.Str);
say q{续行提示符: } ~ prompt-for(True, $*CWD.Str);

# 走一遍 drive（注入读入），确认核心逻辑在真实句柄下也正常
my @out;
my $sink = class {
    has @.lines;
    method say($s --> Nil) { @.lines.push: $s.Str; Nil }
    method text(--> Str) { @.lines.join("\n") }
}.new;

{
    temp $*OUT = $sink;
    # 真实走一遍「读入 -> 记历史 -> 分流」：把 $p 包成 read-line喂给 drive
    my @script = '1 + 1', q{%help}, q{!echo hi};
    my $cursor = 0;
    my $read-line = sub ($prompt) {
        # 每次读到东西都真的 add-history，验证历史文件能被写出来
        my $line = @script[$cursor++];
        $p.add-history($line) if $line.defined;
        $line;
    };
    drive($read-line, :color(False));
}
say q{};
say q{--- drive 输出 ---};
say $sink.text;

$p.save-history;
say q{--- 历史保存后 ---};
say q{历史文件字节: } ~ $hist.s;
say q{大于 0: } ~ (($hist.s > 0) ?? q{是} !! q{否});

try unlink $hist;
say q{清理: } ~ ($hist.e ?? q{还在} !! q{已删});