#!/bin/bash
# 真实脚本压测 runner v2 —— 每个脚本独立沙箱（TMPDIR 隔离）
#
# v2 相比 v1 增加两道「假通过」防线：
#   1) MINLINES：stdout 行数下限（防止引擎静默终止 + rc=0 冒充成功）
#   2) REQUIRED：stdout 必须含的终态标记
#
# 用法:  bash tools/stress.sh [脚本 glob]
# 退出码: 0 全部符合预期; 1 有脚本不符预期; 2 环境问题
set -u
_here="$(cd "$(dirname "$0")" && pwd)"
source "$_here/env.sh"          # 统一探测 raku（找不到时这里就 exit 2）
cd "$_here/.." || exit 2
ROOT=$PWD
R=$RAKU

OUTDIR=$(mktemp -d /tmp/rk-stress-XXXXXX)
KEEP=${KEEP_LOG:-0}

declare -A EXPECT=(
  [01-disk-report.rakuish]=0
  [02-log-cleanup.rakuish]=0
  [03-csv-summary.rakuish]=0
  [04-json-report.rakuish]=1
  [05-batch-rename.rakuish]=0
  [06-backup-rotate.rakuish]=0
  [07-grep-replace.rakuish]=0
  [08-port-audit.rakuish]=MULTI
  [09-env-guard.rakuish]=3
  [10-pipeline-glue.rakuish]=0
)
declare -A MINLINES=(
  [01-disk-report.rakuish]=20
  [02-log-cleanup.rakuish]=6
  [03-csv-summary.rakuish]=8
  [04-json-report.rakuish]=5
  [05-batch-rename.rakuish]=6
  [06-backup-rotate.rakuish]=5
  [07-grep-replace.rakuish]=4
  [08-port-audit.rakuish]=2
  [09-env-guard.rakuish]=8
  [10-pipeline-glue.rakuish]=5
)
declare -A REQUIRED=(
  [01-disk-report.rakuish]='告警|全部'
  [02-log-cleanup.rakuish]='已删除'
  [03-csv-summary.rakuish]='总额'
  [04-json-report.rakuish]='失败清单'
  [05-batch-rename.rakuish]='改名成功'
  [06-backup-rotate.rakuish]='轮转校验通过'
  [07-grep-replace.rakuish]='零残留'
  [08-port-audit.rakuish]='监听'
  [09-env-guard.rakuish]='前置检查失败'
  [10-pipeline-glue.rakuish]='Raku 验算'
)

pass=0; fail=0
printf '%-26s %4s %4s %7s %6s %8s %s\n' 脚本 RC 期望 耗时ms 行数 输出字节 判定
printf '%.0s-' {1..78}; echo

for f in ${1:-stress/[0-9]*.rakuish}; do
  n=$(basename "$f")
  exp=${EXPECT[$n]:-0}
  minl=${MINLINES[$n]:-1}
  req=${REQUIRED[$n]-}

  # 每个脚本独立沙箱（唯一目录，跑完不删，供事后排查）
  SAND=$OUTDIR/sand/$n
  mkdir -p "$SAND"

  t0=$(date +%s%N)
  TMPDIR=$SAND "$R" -I "$ROOT/lib" "$ROOT/bin/rakuish" "$ROOT/$f" \
      >"$OUTDIR/$n.out" 2>"$OUTDIR/$n.err"
  rc=$?
  t1=$(date +%s%N)
  ms=$(( (t1 - t0) / 1000000 ))
  lines=$(wc -l <"$OUTDIR/$n.out")
  bytes=$(wc -c <"$OUTDIR/$n.out")

  ok=1; why='ok'
  if [ "$exp" = MULTI ]; then
    case $rc in 0|1|2) : ;; *) ok=0; why="退出码 $rc 不在 0/1/2";; esac
  else
    if [ "$rc" != "$exp" ]; then ok=0; why="退出码 $rc != 期望 $exp"; fi
  fi
  if [ $ok = 1 ] && [ "$lines" -lt "$minl" ]; then
    ok=0; why="行数 $lines < 下限 $minl（疑似静默终止）"
  fi
  if [ $ok = 1 ] && [ -n "$req" ] && ! grep -qE -- "$req" "$OUTDIR/$n.out"; then
    ok=0; why="缺少终态标记『$req』（疑似半途中断）"
  fi

  printf '%-26s %4d %4s %7d %6d %8d %s\n' "$n" "$rc" "$exp" "$ms" "$lines" "$bytes" "$why"
  if [ $ok = 1 ]; then
    pass=$((pass+1))
  else
    fail=$((fail+1))
    tail -n 6 "$OUTDIR/$n.err" | sed 's/^/     err| /'
    tail -n 3 "$OUTDIR/$n.out" | sed 's/^/     out| /'
  fi
done

printf '%.0s-' {1..78}; echo
echo "通过 $pass，失败 $fail；产物留在 $OUTDIR"
[ "$KEEP" = 1 ] && echo "(KEEP_LOG=1)" || true
[ $fail -eq 0 ] && exit 0 || exit 1
