#!/usr/bin/env bash
# 对拍脚本（bash 侧）：把用例文件里的每一行喂给真 bash，
# 输出「行号|stdout|stderr」（换行转义成 \n）。
#
# 用法：bash tools/diff-bash.sh tools/diff-cases/arith.txt
#
# ⚠ 不用 `mktemp` + `rm`：本机的 `rm` 走「可恢复删除」包装，会往
#   **stdout** 打印一行「moved to trash」⇒ 污染对拍输出。
cd "$(dirname "$0")/.." || exit 1
mkdir -p tmp              # 临时 stderr 文件落在 tmp/ 里（目录可能被人清掉）

# ⚠ 临时 stderr 文件用**固定名**（不再是 `$$`）：
#   以前是 `tmp/.diff-err.$$`（每次运行一个 PID 名）而且**从不删**，
#   于是每跑一次对拍就往 tmp/ 里多一个文件（实测已堆 67 个 `.diff-err.<pid>`）。
#   固定名 ⇒ 永远只有这一个文件（每行 `2>` 都会截断重写）。
#   退出时清掉；`rm` 的输出全部丢掉 —— 本机 `rm` 走「可恢复删除」包装，
#   会往 stdout 打印一行「moved to trash」⇒ 会污染对拍输出。
err="tmp/.diff-err"
trap 'rm -f "$err" >/dev/null 2>&1' EXIT

# ⚠ 变量名**不能带连字符**（bash 的变量名只有字母数字下划线）——
#   `case-file=xxx` 会被 bash 当成「跑一条叫 case-file 的命令」。
casefile=${1:?用法: bash tools/diff-bash.sh 用例文件}

i=0
while IFS= read -r line; do
    i=$(( i + 1 ))
    # ⚠ **空行与注释行都跳过**（行号仍然计数 —— 两边的行号要对齐）：
    #   · 注释里可能有反引号 / 引号 ⇒ `bash -c` 会把它当命令替换；
    #   · 空行：Raku 侧不产出记录 ⇒ 这边也不产出，否则**记录会错位**
    #     （按行号配对时就对不上了）。
    trimmed="${line#"${line%%[![:space:]]*}"}"
    trimmed="${trimmed%"${trimmed##*[![:space:]]}"}"
    case "$trimmed" in
        ""|\#*) continue ;;
    esac
    # 去掉「native 后端不支持」的标记（对 bash 来说它只是句尾注释）
    line=${line%%  #!unsupported*}
    out=$(bash -c "$line" 2>"$err")
    e=$(cat "$err")
    printf '%d|%s|%s\n' "$i" "${out//$'\n'/\\n}" "${e//$'\n'/\\n}"
done < "$casefile"
