#!/usr/bin/env bash
# native 对齐扫描（§10.2-2）：同一批 bash 构造分别喂给
#   · 真 bash（tools/diff-bash.sh）
#   · native 后端（tools/native-scan.raku）
# 按三档归类并输出 Markdown 表格：
#
#   | 构造 | bash stdout | native stdout | 判定 |
#   | 一致 / 明确不支持 / ⚠ 静默不同 |
#
# ⚠ 「静默不同」= 两边都**成功返回**但结果不同 ⇒ 最危险的一类
#   （用户以为跑通了，其实结果是错的）。清单里不允许出现这一档。
#
# 用法：bash tools/native-scan.sh [用例文件]
set -u
_here="$(cd "$(dirname "$0")" && pwd)"
source "$_here/env.sh"
cd "$_here/.." || exit 2

casefile=${1:-tools/native-cases.txt}
[ -f "$casefile" ] || { echo "用例文件不存在：$casefile" >&2; exit 2; }

mkdir -p tmp
err="tmp/.scan-err"
trap 'rm -f "$err" >/dev/null 2>&1' EXIT

bash tools/diff-bash.sh "$casefile" > tmp/.scan-bash.out
"$RAKU" tools/native-scan.raku "$casefile" > tmp/.scan-native.out

awk -F'|' '
  NR==FNR { b[$1]=$2; be[$1]=$3; next }
  {
    n=$1; code=$2; out=$3; errout=$4;
    b_out = (n in b) ? b[n] : "";
    if (code == 2 && errout ~ /不支持/) {
      verdict = "明确不支持";
    } else if (out == b_out) {
      verdict = "一致";
    } else {
      verdict = "⚠ 静默不同";
    }
    cnt[verdict]++;
    printf "| %s | `%s` | `%s` | %s |\n", n, b_out, out, verdict;
  }
  END {
    printf "\n合计：一致 %d，明确不支持 %d，⚠ 静默不同 %d\n",
      cnt["一致"], cnt["明确不支持"], cnt["⚠ 静默不同"];
  }
' tmp/.scan-bash.out tmp/.scan-native.out
