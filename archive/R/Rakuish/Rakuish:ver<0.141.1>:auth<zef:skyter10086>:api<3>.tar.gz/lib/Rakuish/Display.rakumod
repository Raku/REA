unit module Rakuish::Display;

use JSON::Fast;
use Rakuish::Result;
use Rakuish::Data::Table;
use Rakuish::Data::Stream;

# Rakuish::Display —— 结果的**内容级**展示包（0.78.0 / SPEC V-184 / ADR-0016）。
#
# 为什么要有它：`Result` 知道「是什么」（ok/code/value/out/err），
# `Session.render` 知道「TTY 上长什么样」（颜色 + `Out[n]` 标签）。
# 两者之间缺一层——**同一份内容，不同前端能取不同格式**：
#   · 终端要 `text`（等宽、不含 ANSI 也行）；
#   · Markdown 前端（文档、LLM）要 `markdown`；
#   · 结构化前端要 `json`。
#
# 三条硬约束：
#   1. `text` 必有且**零 ANSI** —— 任何前端至少能显示；
#   2. 格式缺失时**降级到 text 并显式标注**（`to-hash<format>` 说明实际给的是
#      哪个），绝不悄悄给错格式；
#   3. 不做第二套渲染逻辑：能在 `Table` / `Result` 上算出来的，一律算出来，
#      不在这里重写一遍表格对齐或数值格式化。
#
# 刻意**不**包含终端装饰（`Out[n]`、颜色、分页）——那是前端的事。

# 可用的格式，按「信息量递增」排列。text 永远在。
# 0.110.0：加 `html` —— notebook / Jupyter 的 `text/html`，也是「导出成网页」
# 时的正文。它和 markdown 是并列的两条渲染路径，不是谁的降级。
my constant FORMATS = < text markdown html json >;

# 转义只有 Table 那一份实现（csv-cell 同一个模式：纯函数，可在类型对象上调用）。
my sub esc($v --> Str) { Rakuish::Data::Table.html-escape($v) }

# 纯文本块：保留换行与空白，前端不必再判断「这段该不该 pre」。
my sub pre-block(Str $text, Str :$class = '' --> Str) {
    my Str $cls = $class.chars ?? ' class="' ~ $class ~ '"' !! '';
    '<pre' ~ $cls ~ ' style="margin:0;font:13px/1.45 '
        ~ 'ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap">'
        ~ esc($text) ~ '</pre>';
}

class Bundle is export {
    has Str $.text is required;     # 必有，零 ANSI
    has Str $.markdown = '';        # '' 表示不提供
    has Str $.html = '';            # 0.110.0：text/html（同样 '' = 不提供）
    has     @.json;                 # 空表示不提供（结构化内容，不是 Result 外壳）
    has     %.meta;                 # kind / ok / code / op / rows / truncated
    # 0.124.0 / ADR-0048 P1：对象 `to-mime` 带来的**额外** MIME 档（svg /
    # latex / png …）。P1 只定义透传与终端降级，渲染交给前端。
    has     %.extra-mime;
    # 0.123.0 / V-324：JSON 档是否**真的**可序列化，算一次记住。
    # 不能只看 `@!json.elems` —— Complex / Sub / 自定义对象会在 to-json 时抛。
    has Str  $!json-cached;
    has Bool $!json-done = False;

    method !json-text(--> Str) {
        # 0.124.0：每个出口都必须落缓存。之前空 json 只置 done、不置值，
        # 第二次调用会读到未初始化的 Str（`available` 一次 + `to-mime` 一次
        # 就必现，notebook 侧表现为一条 warning）。
        unless $!json-done {
            $!json-done = True;
            my Str $s = '';
            if @!json.elems {
                my $j = try { to-json(@!json.Array, :!pretty) };
                $s = $j.defined ?? $j.Str !! '';
            }
            $!json-cached = $s;
        }
        $!json-cached.defined ?? $!json-cached !! '';
    }

    method available(--> List) {
        my @a = 'text';
        @a.push('markdown') if $!markdown.chars;
        @a.push('html')     if $!html.chars;
        @a.push('json')     if self!json-text.chars;
        # 额外 MIME 按名字排序，去重（text/plain 等已知档不重复列）。
        my %seen = @a.map({ $_ => True });
        for %!extra-mime.keys.sort -> $k {
            my Str $key = $k.Str;
            next if %seen{$key}:exists;
            %seen{$key} = True;
            @a.push($key);
        }
        @a.List;
    }

    method has(Str $fmt --> Bool) {
        my Str $f = $fmt.lc;
        return True                     if %!extra-mime{$f}:exists;
        return $!markdown.chars     > 0 if $f eq 'markdown' || $f eq 'md';
        return $!html.chars         > 0 if $f eq 'html';
        return self!json-text.chars > 0 if $f eq 'json';
        return True                     if $f eq 'text' || $f eq 'txt' || $f eq 'plain';
        False;
    }

    # 内容协商：按调用方的偏好顺序挑第一个**可用**的格式；都不行就 text。
    # 偏好顺序由前端给（例如 LLM 客户端写 ['markdown','text']）。
    method pick(@accepts --> Str) {
        for @accepts -> $want {
            my Str $f = $want.Str.lc;
            return $f if %!extra-mime{$f}:exists;
            return 'markdown' if ($f eq 'markdown' || $f eq 'md') && $!markdown.chars;
            return 'html'     if $f eq 'html' && $!html.chars;
            return 'json'     if $f eq 'json' && self!json-text.chars;
            return 'text'     if $f eq 'text' || $f eq 'txt' || $f eq 'plain';
        }
        'text';
    }

    method render(Str $fmt = 'text' --> Str) {
        my Str $f = $fmt.lc;
        return %!extra-mime{$f} if %!extra-mime{$f}:exists;
        return $!markdown if ($f eq 'markdown' || $f eq 'md') && $!markdown.chars;
        return $!html     if $f eq 'html' && $!html.chars;
        if $f eq 'json' {
            # 0.123.0 / V-324：展示层不负责序列化失败。JSON::Fast 对 Complex /
            # Sub / 自定义对象会直接抛；让它抛到调用方就会把引擎带走，所以这里
            # 降级成 text（与「格式缺失降级」同一条原则：不伪装成功）。
            my Str $j = self!json-text;
            return $j if $j.chars;
        }
        # 未知或不可用：降级到 text（不是抛异常 —— 展示层不该让调用方崩）。
        $!text;
    }

    # 一次给齐所有可用 MIME（0.110.0）。Jupyter 的 `execute_result` 就是这样：
    # 前端按自己会渲染的类型挑，而不是让内核猜一个。`text/plain` 永远在。
    method to-mime(--> Hash) {
        my %m;
        # 键必须用花括号：`%m<"text/plain">` 会把引号当成键名的一部分（实测），
        # 序列化出来是 `"\"text/plain\""`，前端一个 MIME 都对不上。
        %m{'text/plain'} = $!text;
        %m{'text/markdown'} = $!markdown if $!markdown.chars;
        %m{'text/html'}     = $!html     if $!html.chars;
        # 0.123.0 / V-324：不可 JSON 化就**不提供** application/json。
        # 之前这里直接 `to-json`，一个 `3+4i` 就能抛穿 `Eval::Server` 的
        # emit，把引擎进程打死（notebook 侧表现为「引擎已重启」）。
        my Str $j = self!json-text;
        %m{'application/json'} = $j if $j.chars;
        # 对象带来的额外档（ADR-0048）。同名以额外档为准：那是值的作者
        # 明确声明的表示，比内置识别更权威。
        for %!extra-mime.kv -> $k, $v {
            %m{$k.Str} = $v.Str;
        }
        %m;
    }

    # 线上/跨进程表示。只带**实际选中**的那一份，避免把三种格式都塞进响应。
    #
    # 字段叫 `content` 而不是 `text`：当 format 是 markdown 时，内容不是纯文本。
    # 让字段名跟着格式走会逼客户端先判断再取值，容易把 markdown 当纯文本渲染。
    #
    # `:mime=True` 时再附一份 `mime` 哈希（全部分档）—— 只有 notebook 需要；
    # TTY / Kernel.present 不传，响应体积与 0.109 一致。
    method to-hash(Str :$format = 'text', Bool :$mime = False --> Hash) {
        my Str $picked = self.pick([$format]);
        my %h = content => self.render($picked),
                format  => $picked,
                formats => self.available,
                meta    => %!meta.Hash;
        %h<mime> = self.to-mime if $mime;
        %h;
    }
}

# ── `display()` 的返回值哨兵 ─────────────────────────────────────────
# ADR-0048 §2.2：`display($v)` 是**语句**，不是值。Raku 没有 None，而
# 返回 `Nil` 会让 `!remember` 把 `_` 改成 Nil（V-321 同一条原则：只读动作
# 不该改结果历史）。所以返回一个可识别的哨兵，由 Session 的 remember /
# render / bundle 三处统一忽略。
class Shown is export {
    has Str $.kind = 'display';
}

# ── 对象自带 MIME（ADR-0048 P1）──────────────────────────────────────
# 协议：值实现 `method to-mime(--> Hash)`，返回 MIME => payload。
# 优先级高于内置类型分派；`text/plain` 缺失时用 `.Str` 兜底。
# 抛异常 = 没有富表示，静默降级 —— 展示层任何情况下都不该把调用方带走。
my sub bundle-from-mime($v, %m, :%meta --> Bundle) {
    my Str $text = (%m<text/plain> // '').Str;
    my Str $md   = (%m<text/markdown> // '').Str;
    my Str $html = (%m<text/html> // '').Str;

    my @json;
    if %m<application/json>:exists {
        my $raw = %m<application/json>;
        # 契约是「序列化后的字符串」；也容忍直接给结构化值。
        my $parsed = try { $raw ~~ Str ?? from-json($raw) !! $raw };
        if $parsed.defined {
            @json = $parsed ~~ Positional ?? $parsed.List !! ($parsed,);
        }
        # 解析失败 = 不提供 json 档（V-324 的原则：不伪装成功）。
    }

    my %extra;
    for %m.keys -> $k {
        my Str $key = $k.Str;
        next if $key eq 'text/plain' || $key eq 'text/markdown'
             || $key eq 'text/html' || $key eq 'application/json';
        %extra{$key} = %m{$k}.Str;
    }

    unless $text.chars {
        my $s = try { $v.Str };
        $text = $s.defined ?? $s.Str !! '';
    }
    # 只有富 MIME、没有文本表示的怪对象：给一句可读摘要，TTY 不至于空白。
    unless $text.chars {
        $text = %extra.keys.sort.map({ "[$_]" }).join(' ');
    }

    my %mm = %meta,
             kind   => 'mime',
             source => (%meta<source> // 'value'),
             mime   => %m.keys.map(*.Str).sort.List;
    Bundle.new(:$text, :markdown($md), :html($html), :@json,
               :extra-mime(%extra), :meta(%mm));
}

# ── 从 Result 构建 ───────────────────────────────────────────────────
# `:$max-rows` 只影响表格类内容（与 Table 的约定一致）。
our sub bundle-from(Result $r, Int :$max-rows = 200, :%seed --> Bundle) is export {
    my %meta = %seed, ok => $r.ok, code => $r.code;
    %meta<op> = $r.op if $r.op.chars;

    # ① 失败：错误信息就是全部内容。不给 markdown / json —— 没有内容可结构化。
    unless $r.ok {
        my Str $t = $r.err.chars ?? $r.err.trim
                  !! ($r.out.chars ?? $r.out.trim !! '（失败，无错误信息）');
        return Bundle.new(:text($t), :html(pre-block($t, :class<err>)),
                           :meta(%(%meta, kind => 'error', source => 'error')));
    }

    # ② 谁代表「这一格的展示」：`out` 是 stdout 流，值才是结果 —— 但只对
    # `eval` 成立。shell 命令（ls / doc / cat …）的 out 就是它的展示形态，
    # 值只是附带的结构化副本。
    #
    # 0.123.0 / V-323：之前 `out` 无条件抢先返回，于是 `say "hi"; 42` 的 42
    # **永远到不了前端**（notebook 只看到 hi，还会把它重复显示两遍）。
    # 现在 eval + 有值 => display 给值；stdout 仍走 Response 的 `out` 字段。
    my Bool $value-is-display = $r.value-defined
        && ($r.op eq 'eval' || !$r.out.chars);

    unless $value-is-display {
        if $r.out.chars {
            return Bundle.new(:text($r.out.chomp), :html(pre-block($r.out.chomp)),
                               :meta(%(%meta, kind => 'text', source => 'out')));
        }
        # 没有值也没有输出（`cd` 之类）：空内容，但仍是成功的展示包。
        return Bundle.new(:text(''), :meta(%(%meta, kind => 'empty',
                                                 source => 'empty')));
    }
    # seed 里可以带 source（`display()` 传 'display'）；值分支只在没指定时补默认。
    %meta<source> //= 'value';

    my $v = $r.value;

    # 0.124.0 / ADR-0048 P1：`display()` 的返回值不是结果，别渲染成
    # `Out[n] = Shown<...>`。它已经在自己调用时输出过内容了。
    return Bundle.new(:text(''), :meta(%(%meta, kind => 'empty', source => 'display')))
        if $v ~~ Shown;

    # ── 0.125.0 / §4.9f：timed/bench 带耗时 ──
    # Result.elapsed 是 Duration，bundle 时把它放进 meta；text 在末尾附加。
    my Str $elapsed-line = '';
    my Num $elapsed-ms = ($r.elapsed // 0).Num * 1000;
    $elapsed-line = sprintf("（%.1f ms）", $elapsed-ms)
        if $r.op eq 'timed' || $r.op eq 'bench' || $r.op eq 'perf';

    # 值自己声明了 MIME 就用它，优先于下面所有内置识别。
    # junction 必须先排除：`$v.defined` / `.can` / 方法调用都会 autothread。
    if !($v.WHAT === Junction) && $v.defined && $v.can('to-mime') {
        my $m = try { $v.to-mime };
        if $m.defined && $m ~~ Hash && $m.elems {
            my Bundle $b = bundle-from-mime($v, %($m), :%meta);
            $b.meta<elapsed-ms> = $elapsed-ms if $elapsed-ms;
            if $elapsed-line.chars && $b.text.chars {
                $b.text = $b.text ~ $elapsed-line;
            }
            return $b;
        }
    }

    # ③-0 流（0.91.0）：先物化成 Table，再走同一条表格渲染 —— 展示层只有
    # 一套排版，不因为「管道」多出第二种表格。
    $v = $v.table if $v ~~ Rakuish::Data::Stream;

    # ── 0.125.0 / §4.9c：Seq / Range / Iter 容器先限元素数再分发 ──
    # `ls('t').head(3)` 返回 Seq，之前掉不进 Positional 分支直接兜底。
    # 现在显式识别惰性容器，先取 up-to-N 个元素再做类型分派。
    # 注意：Hash / Scalar 也是 Iterable 但不该被物化成 Positional ——
    # 它们有自己的分支（⑦ 记录 / ⑧ 标量），别被这条懒容器拦截。
    my Bool $was-lazy = $v ~~ Iterable && !($v ~~ Positional)
                      && !($v ~~ Hash) && !($v.defined && $v.WHAT.^name eq 'Type');
    if $was-lazy {
        my Int $cap = $max-rows > 0 ?? $max-rows !! 200;
        my @sliced = gather {
            my $i = 0;
            for $v -> $elem {
                take $elem;
                last if ++$i >= $cap;
            }
        };
        $v = @sliced;
        # 超限标记（与 Table.truncated 约定一致）。
        %meta<truncated> = True if $v.elems >= $cap;
    }

    # ③ 表格：三种格式都是原生支持的，直接借 Table 的实现。
    if $v ~~ Rakuish::Data::Table {
        my Int $rows = $v.elems;
        my %m = %meta, kind => 'table', :$rows,
                columns => $v.columns.List;
        %m<truncated> = True if $max-rows > 0 && $rows > $max-rows;
        return Bundle.new(
            :text($v.to-text(:$max-rows)),
            :markdown($v.to-markdown(:$max-rows)),
            :html($v.to-html(:$max-rows)),
            :json($v.rows.Array),
            :meta(%m),
        );
    }

    # ④ 记录集（Array of Hash）：先转成 Table 再借用它的排版，避免第二套对齐代码。
    if $v ~~ Positional && $v.elems && $v.all ~~ Hash {
        my $t = Rakuish::Data::Table.from-rows($v.List);
        my Int $rows = $v.elems;
        my %m = %meta, kind => 'records', :$rows, columns => $t.columns.List;
        %m<truncated> = True if $max-rows > 0 && $rows > $max-rows;
        return Bundle.new(
            :text($t.to-text(:$max-rows)),
            :markdown($t.to-markdown(:$max-rows)),
            :html($t.to-html(:$max-rows)),
            :json($v.Array),
            :meta(%m),
        );
    }

    # ⑤ 路径列表：与 ls 的观感一致（一行一个），markdown 给成列表。
    if $v ~~ Positional && $v.elems && $v.all ~~ IO::Path {
        my @names = $v.map({ $_.Str }).List;
        return Bundle.new(
            :text(@names.join("\n")),
            :markdown(@names.map({ "- $_" }).join("\n")),
            :html('<ul style="margin:0;padding-left:1.4em">'
                  ~ @names.map({ '<li>' ~ esc($_) ~ '</li>' }).join ~ '</ul>'),
            :json(@names),
            :meta(%(%meta, kind => 'paths', rows => @names.elems)),
        );
    }

    # ⑥ 字符串列表（registry 名字、history 之类）：一行一个。
    if $v ~~ Positional && $v.elems && $v.all ~~ Str {
        my @items = $v.map({ $_.Str }).List;
        return Bundle.new(
            :text(@items.join("\n")),
            :markdown(@items.map({ "- $_" }).join("\n")),
            :html('<ul style="margin:0;padding-left:1.4em">'
                  ~ @items.map({ '<li>' ~ esc($_) ~ '</li>' }).join ~ '</ul>'),
            :json(@items),
            :meta(%(%meta, kind => 'rows', rows => @items.elems)),
        );
    }

    # ⑦ 单个记录：text 用 k=v（shell env 的习惯），markdown 用两列表格。
    if $v ~~ Hash {
        my @keys = $v.keys.sort({ .Str });
        my Str $text = @keys.map({ "{$_.Str}={$v{$_}}" }).join("\n");
        my Str $md = "| key | value |\n| --- | --- |\n"
                   ~ @keys.map({ "| {$_.Str} | {$v{$_}} |" }).join("\n");
        # 单条记录：转成两列的表再走 Table 的 HTML，别在这里手拼第三遍。
        my $rt = Rakuish::Data::Table.new(
            :columns<key value>,
            :rows(@keys.map({ %(key => $_.Str,
                               value => $v{$_}.defined ?? $v{$_}.Str !! '') })));
        return Bundle.new(
            :text($text), :markdown($md),
            :html($rt.to-html),
            :json([$v.Hash]),
            :meta(%(%meta, kind => 'record', rows => 1)),
        );
    }

    # ⑧ 标量：Str / Int / Num / Bool / IO::Path / Ratio … 都能 .Str。
    if $v.defined {
        my $txt = $v.Str;
        $txt = $txt ~ $elapsed-line if $elapsed-line.chars;
        $txt = budgeted-text($txt);
        return Bundle.new(
            :text($txt),
            :html(pre-block($txt)),
            :json([$v]),
            :meta(%(%meta, kind => 'scalar')),
        );
    }

    # ⑨-0 类型对象（§4.9b）：`Int.WHAT` 之类 `.Str` 返回空。
    # 给成可读的类型名字（括号里标注「类型对象」）。
    if $v.defined && $v.WHAT.^name eq 'Type' {
        my Str $txt = $v.^name ~ '（类型对象）';
        return Bundle.new(
            :text($txt), :html(pre-block($txt)),
            :json([$v.^name]),
            :meta(%(%meta, kind => 'type')),
        );
    }

    # ⑨ 防御性兜底：值声称「有」但没有命中任何已知形态（例如怪容器）。
    # Nil 但 `.gist` 有值（比如 `Int.WHAT` 返回 `(Int)`）也要渲染。
    my Str $fallback = ($v.gist.chars ?? $v.gist !! ($v.Str // ''));
    $fallback = budgeted-text($fallback);
    Bundle.new(:text($fallback), :meta(%(%meta, kind => 'empty', source => 'empty')));
}

# ── 输出预算（§4.9d）────────────────────────────────────────────
# 默认 ~4000 字符上限。超限截断并标 `…（共 N 项）` 或 `…（截断 N 字符）`。
# 表格/路径/行列表这些已经在分支里给了结构化呈现，只有兜底和标量的
# 长字符串/Seq dump 会命中这条。
my constant MAX-DISPLAY-CHARS = 4000;
my sub budgeted-text(Str $s --> Str) {
    return $s if $s.chars <= MAX-DISPLAY-CHARS;
    $s.substr(0, MAX-DISPLAY-CHARS) ~ "\n…（截断 {$s.chars - MAX-DISPLAY-CHARS} 字符）"
}

# 0.124.0 / ADR-0048 P1：`display($v)` 用这个入口。与 `bundle-from` 共用
# 同一条渲染链（鸭子类型 → 内置识别 → 标量降级），不另写第二套。
our sub bundle-of($v, Int :$max-rows = 200, :%meta --> Bundle) is export {
    bundle-from(Result.new(:ok, :op<eval>, :value($v)),
                :$max-rows, :seed(%meta));
}

# 能力矩阵：给 `capabilities` / 文档生成用。不要把「想做的」写进来，
# 只列**真的能用**的。
our sub capabilities(--> Hash) is export {
    %(
        formats => FORMATS.List,
        kinds   => < error text table records paths rows record scalar empty mime >.List,
        notes   => %(
            markdown => '表格类内容（table / records）原生提供；其余降级为 text',
            html     => '表格 / 列表 / 文本块都是真标签（0.110.0）；错误与标量给 <pre>',
            json     => '结构化内容本身（不是 Result 外壳）；标量为单元素数组',
            text     => '必有，零 ANSI，任何前端都能显示',
            mime     => '对象自带 to-mime 的额外档（svg / latex …）；0.124.0 起透传',
        ),
    );
}
