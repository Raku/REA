unit class Rakuish::Sys::FS;

# Rakuish::Sys::FS —— API v3 的文件系统 API（ADR-0001 / Phase 1）。
#
# 铁律：
#   · 全部基于 IO::Path，不再自建 Rakuish::Platform::Path；
#   · 路径一律先过 resolver（Sys 会做 root 沙箱校验），本类不自己拼 cwd；
#   · 读 / 写 / 列目录 / stat 抛异常；rm / cp / mv / mkdir 返回 Result；
#   · 不接受任何 shell 字符串，不解析 flag，不 spawn 进程。

use Rakuish::Result;
use Rakuish::Data::Table;

has Callable $.resolver = -> $p { $p ~~ IO::Path ?? $p !! $p.Str.IO };
has Int $.max-bytes = 1024 * 1024;
has Int $.max-entries = 100_000;

# Windows 上 `IO::Path.x` 在 Rakudo 2026.11 对**存在的文件**也会抛
# 「rindex search target requires a concrete string, but got null」；
# 不处理的话 `try { $f.x }` 静默成 False，`stat.executable` 在 Windows
# 恒为假。NTFS 本来没有执行位，用扩展名白名单代替。白名单与
# `Rakuish::REPL::Chrome` 的同名常量保持一致（两处各自私有，避免
# Sys 层反向依赖 REPL 层）。
my constant WIN-EXEC-EXT = <exe bat cmd com ps1 msi>;

my sub exec-p(IO::Path $f --> Bool) {
    if $*DISTRO.is-win {
        my Str $ext = $f.extension.lc;
        return $ext.chars > 0 && WIN-EXEC-EXT.first({ $_ eq $ext }).defined;
    }
    so try { $f.x };   # POSIX：x 位有意义；异常（竞态删除）按不可执行
}

method !resolve($p --> IO::Path) {
    my $r = $!resolver.($p);
    X::Rakuish::Path.new(:detail("resolver 必须返回 IO::Path，实际 {$r.^name}")).throw
        unless $r ~~ IO::Path;
    $r
}

# 0.104.0：编码别名归一化。Rakudo 内建支持 gb18030 / gb2312（GB18030
# 向下兼容 GBK/GB2312），但**不认** gbk / cp936 / windows-936 这些常见写法。
# 外部评测（RESEARCH-rakuish-fs.md §3.4）据此说「GBK 无解」，其实是查漏了。
# 这里把常见的中文编码别名映射到 Rakudo 真认识的编码名；其余原样交给
# Rakudo 自己判断（它会对真正不支持的 big5 / shift-jis 报错）。
my sub normalize-enc(Str $enc --> Str) {
    state %alias = (
        gbk          => 'gb18030',
        'gbk-18030'  => 'gb18030',
        gb2312       => 'gb2312',   # Rakudo 原生支持，显式列出便于对照
        cp936        => 'gb18030',
        'windows-936'=> 'gb18030',
        ms936        => 'gb18030',
    );
    my Str $key = $enc.lc.trim;
    %alias{$key} // $enc
}

method !bytes($data, Str $enc --> Blob) {
    return $data if $data ~~ Blob;
    my Str $e = normalize-enc($enc);
    return $data.encode($e) if $data ~~ Str;
    $data.Str.encode($e)
}

method !random-token(--> Str) {
    my Str $t = (now * 1e9).Int.base(16) ~ '-' ~ (rand * 1e12).Int.base(16);
    $t ~ '-' ~ $*PID;
}

# ── read ───────────────────────────────────────────────────────────────
# Phase 1 用「大小上限 + 明确异常」兜住大文件，不做静默截断；
# 流式 / :lines 留给 Phase 2（ADR-0001 §3）。
method read($p, Str :$enc = 'utf-8', Bool :$bin = False,
            Int :$max-bytes, Int :$offset, Int :$limit) {
    my IO::Path $f = self!resolve($p);
    X::Rakuish::NotFound.new(:detail("文件不存在: {$f.Str}")).throw
        unless $f.e || $f.l;
    X::Rakuish::Path.new(:detail("不是普通文件: {$f.Str}")).throw
        unless $f.f;

    my Int $cap = $max-bytes // $!max-bytes;
    my Int $sz  = (try { $f.s } // 0);
    if $cap > 0 && $sz > $cap {
        # 0.97.0：报错要给**出路**，别让用户对着 "超限" 干瞪眼。
        # 大文件整份 slurp 会吃爆内存，所以上限保留；但告诉用户三条可读的路：
        # 按行流式读 / 只看首尾 / 显式抬高上限（自己承担内存）。
        X::Rakuish::Limit.new(
            :detail("读取超限: {$sz} > {$cap} 字节 ({$f.Str})；"
                    ~ "大文件请用 read-lines(:head/:tail) 或 head -n / tail -n，"
                    ~ "或 stream('路径') 惰性记录流；"
                    ~ "确实要整份读就 read(..., :max-bytes(N)) 显式抬高上限")
        ).throw;
    }

    X::Rakuish::Path.new(:detail("offset 不能为负: {$offset}")).throw
        if $offset.defined && $offset < 0;
    X::Rakuish::Path.new(:detail("limit 不能为负: {$limit}")).throw
        if $limit.defined && $limit < 0;

    my Int $start = $offset // 0;

    if $bin {
        my $blob = $f.slurp(:bin);
        return $blob unless $offset.defined || $limit.defined;
        return Blob.new if $start >= $blob.elems;
        my Int $avail = $blob.elems - $start;
        my Int $len = $limit.defined ?? ($limit min $avail) !! $avail;
        return $blob.subbuf($start, $len);
    }

    # 0.102.0：`slurp(:enc)` 的失败以前是 X::AdHoc（「Malformed UTF-8 near
    # bytes 7e 7f 80 ...」）——不在 Rakuish 异常族里，也没给用户任何出路。
    # 包成 X::Rakuish::Encoding，并把三条可走的路直接写进消息。
    # 只拦「解码类」失败：文件在 resolve 之后被删之类的 IO 错误原样抛。
    # 0.104.0：先把别名（gbk / cp936）归一到 Rakudo 认识的编码名。
    my Str $enc-use = normalize-enc($enc);
    my Str $text;
    {
        CATCH {
            default {
                my Str $m = .message;
                .rethrow unless $m ~~ /:i 'malformed' | 'encoding' | 'decode' | 'utf-'
                                     | 'unknown' | 'not.*support' /;
                X::Rakuish::Encoding.new(
                    :detail("无法按 {$enc} 解码 {$f.Str}（可能是二进制文件或编码不支持）：{$m}\n"
                            ~ "  · 读原始字节：read(路径, :bin)\n"
                            ~ "  · 换编码读取：read(路径, :enc<gb18030>)（GBK/GB2312）"
                            ~ " / :enc<utf-16> / :enc<latin-1>\n"
                            ~ "  · 只看能否按行处理：read-lines(路径) / head -n\n"
                            ~ "  · Rakudo 内建不含 big5 / shift-jis；这类只能 :bin 后自行转码")
                ).throw;
            }
        }
        $text = $f.slurp(:enc($enc-use));
    }
    return $text unless $offset.defined || $limit.defined;
    return '' if $start >= $text.chars;
    my Int $avail = $text.chars - $start;
    my Int $len = $limit.defined ?? ($limit min $avail) !! $avail;
    $text.substr($start, $len)
}

# ── 流式按行读（head / tail，0.97.0）────────────────────────────────
# 为什么单独开一个入口，不让 head/tail 调 read()：
#   read() 用**整份文件大小**对比 max-bytes，超了就抛 Limit —— 那是为了
#   防止「一次性 slurp 把内存吃爆」。但 head -n 10 只要前 10 行、tail -n 10
#   只要末 10 行，跟文件多大无关；拿整文件大小卡它们是把保护用错了地方。
# 这里逐行流式读、只留 n 行，不 slurp 全文，因此**不受 max-bytes 约束**
# （这是刻意的豁免：读的量与文件总大小无关）。路径仍走 !resolve，root 校验
# 与 read() 完全同一条路，不另开口子。
method read-lines($p, Int :$head, Int :$tail, Str :$enc = 'utf-8' --> List) {
    my IO::Path $f = self!resolve($p);
    X::Rakuish::NotFound.new(:detail("文件不存在: {$f.Str}")).throw
        unless $f.e || $f.l;
    X::Rakuish::Path.new(:detail("不是普通文件: {$f.Str}")).throw
        unless $f.f;
    X::Rakuish::Path.new(:detail('head / tail 必须给正的 n')).throw
        unless ($head.defined || $tail.defined) && ($head // $tail) > 0;

    my Int $n = ($head // $tail).Int;
    # 0.104.0：:enc 别名归一（gbk→gb18030），$f.lines(:enc) 保持惰性。
    my Str $enc-use = normalize-enc($enc);
    # IO::Path.lines 是惰性 Seq：head($n) 读够就停（早停，大文件只读前面一点）。
    # tail($n) 仍需扫到文件尾，但只在内存里留 n 行 —— 不物化整份。
    my @lines = $head.defined
        ?? $f.lines(:enc($enc-use)).head($n).List
        !! $f.lines(:enc($enc-use)).tail($n).List;
    @lines.List;
}

# ── follow（tail -f，0.99.0）────────────────────────────────────────
# 轮询式跟随：定时看文件有没有长出新字节。为什么不用 inotify/kqueue：
# 一个实现跨平台（Windows / POSIX 同一条路径），0.2s 轮询对日志场景足够
# 跟手；且跟随发生在**持有真终端的父进程**里（引擎经 job 帧转过来，同
# tty-exec / bg-exec 的道理），Windows 也能用。
# 语义（与 GNU tail -f 对齐的部分）：
#   · 先打末 N 行（默认 10；:lines(0) 表示只看新增）；
#   · 只吐完整行（\n 结尾），半行进缓冲，补齐后再吐（跨 poll 的多字节
#     UTF-8 也安全：缓冲按字节拼，整行才解码）；
#   · 文件变小（截断 / 轮转替换）→ 当作新文件从 0 重读；
#   · 文件消失 → 等它回来，回来后按上条处理；
#   · should-stop() 为 True 时停下（交互层用它实现 Ctrl-C 停跟随）。
# 行经 &emit 逐行吐出（带尾换行），**不进 Result.out** —— 实时输出走
# 专用通道，render 不重放。返回 Result：ok=True；停止时 code=130
# （128+SIGINT，用户意图不是故障，同 Proxy 中断口径）；value=%(lines, stopped)。
method follow($p, Int :$lines = 10, :&should-stop, :&emit --> Result) {
    my IO::Path $f = self!resolve($p);
    X::Rakuish::NotFound.new(:detail("文件不存在: {$f.Str}")).throw
        unless $f.e || $f.l;
    X::Rakuish::Path.new(:detail("不是普通文件: {$f.Str}")).throw
        unless $f.f;
    X::Rakuish::Path.new(:detail('follow 的行数不能为负')).throw if $lines < 0;

    my &stop = &should-stop.defined ?? &should-stop !! -> { False };
    my &out  = &emit.defined ?? &emit
        !! -> Str $t { $*OUT.print($t); $*OUT.flush };

    my Int $printed = 0;
    if $lines > 0 {
        for self.read-lines($p, :tail($lines)) -> $ln {
            out($ln ~ "\n");
            $printed++;
        }
    }

    my Int $offset = (try { $f.s } // 0).Int;
    my Buf $rest = Buf.new;
    my Bool $was-missing = False;
    my Bool $stopped = False;

    loop {
        if stop() { $stopped = True; last }

        my $size = try { (($f.e || $f.l) && $f.f) ?? $f.s.Int !! Nil };
        without $size {
            # 文件暂时消失：等它回来；重现后按新文件处理（轮转）。
            $was-missing = True;
            sleep 0.2;
            next;
        }
        if $was-missing || $size < $offset {
            $offset = 0;
            $rest = Buf.new;
            $was-missing = False;
        }
        if $size > $offset {
            my $chunk;
            {
                CATCH { default { $offset = 0; $rest = Buf.new; } }
                my $fh = $f.open(:bin);
                LEAVE { try $fh.close }
                $fh.seek($offset, SeekFromBeginning);
                $chunk = $fh.read($size - $offset);
            }
            if $chunk.defined {
                $offset += $chunk.elems;
                my Buf $buf = $rest ~ $chunk;
                my Int $start = 0;
                for $buf.list.kv -> $i, $byte {
                    if $byte == 0x0A {
                        my $seg = $buf.subbuf($start, $i - $start);
                        $start = $i + 1;
                        my Str $line = (try { $seg.decode('utf-8') })
                            // $seg.decode('latin1');
                        $line ~~ s/ \r $ //;
                        out($line ~ "\n");
                        $printed++;
                    }
                }
                $rest = $start > 0 ?? $buf.subbuf($start) !! $buf;
            }
        }
        sleep 0.2;
    }

    my Str $summary = $stopped
        ?? "已停止跟随（Ctrl-C）· 输出 {$printed} 行"
        !! "跟随结束 · 输出 {$printed} 行";
    Result.new(:ok, :code($stopped ?? 130 !! 0), :op('tail'), :out($summary),
               :value(%(lines => $printed, stopped => $stopped)))
}

# ── write / append ────────────────────────────────────────────────────
# :atomic 走「同目录临时文件 + rename」；Windows 上目标已存在时 rename 无法覆盖，
# 会降级为先 unlink 再 rename，并把 WriteResult.atomic 如实标成 False —— 不撒谎。
method write($p, $data, Bool :$append = False, Bool :$atomic = True,
             Bool :$mkdir = False, Bool :$backup = False,
             Bool :$bin = False, Str :$enc = 'utf-8',
             Int :$max-bytes --> WriteResult) {

    my IO::Path $f = self!resolve($p);
    my $bytes = self!bytes($data, $enc);
    my Int $n = $bytes.elems;

    # 0.102.0：单次调用也能抬上限 —— 否则想写一个 2 MB 字符串只能重建
    # 整个 Sys（`Rakuish::Sys.new(:max-bytes(...))`），代价与意图不成比例。
    my Int $cap = $max-bytes // $!max-bytes;
    X::Rakuish::Limit.new(
        :detail("写入超限: {$n} > {$cap} 字节 ({$f.Str})；"
                ~ "可传 :max-bytes(N) 单次抬高，或 Rakuish::Sys.new(:max-bytes(N))")
    ).throw
        if $cap > 0 && $n > $cap;

    self!ensure-parent($f.parent) if $mkdir;
    X::Rakuish::NotFound.new(:detail("父目录不存在: {$f.parent.Str}（需要 :mkdir）")).throw
        unless $f.parent.d;

    # 追加是流式的，与「整体替换」的原子写语义互斥
    if $append {
        my Bool $ok = so try { $f.spurt($bytes, :bin, :append); True };
        unless $ok {
            my $fh = $f.open(:a, :bin);
            LEAVE { try $fh.close }
            $fh.write($bytes);
        }
        return WriteResult.new(:path($f), :bytes($n), :atomic(False));
    }

    my Str $backup-path = '';
    if $backup && $f.e {
        my Int $old-size = (try { $f.s } // 0);
        # 0.134.0 / AUDIT-FS-LIMITS S9：原来这里用 `$!max-bytes` 而不是本次
        # 调用的 `$cap`，于是 `write(..., :backup, :max-bytes(64M))` 仍会被
        # 1 MiB 的默认值卡住 —— 参数看起来生效了，其实没生效。
        X::Rakuish::Limit.new(
            :detail("备份超限: {$old-size} > {$cap} 字节 ({$f.Str})；"
                ~ "可传 :max-bytes(N) 单次抬高，或 Rakuish::Sys.new(:max-bytes(N))")
        ).throw if $cap > 0 && $old-size > $cap;
        my IO::Path $bak = IO::Path.new($f.Str ~ '.bak');
        X::Rakuish::Unsupported.new(
            :detail("拒绝覆盖符号链接备份: {$bak.Str}")
        ).throw if $bak.l;
        $bak.spurt($f.slurp(:bin), :bin);
        $backup-path = $bak.Str;
    }

    return WriteResult.new(:path($f), :bytes($n), :atomic(False),
                           :backup($backup-path))
        unless $atomic;

    my Str $tmp-name = $f.Str ~ ".rakuish-v3-" ~ self!random-token ~ ".tmp";
    my IO::Path $tmp = IO::Path.new($tmp-name);
    LEAVE { try $tmp.unlink if $tmp.e }

    $tmp.spurt($bytes, :bin, :exclusive);

    my Bool $did-atomic = False;
    if $f.e {
        # POSIX 的 rename(2) 可覆盖；Windows 的 MoveFileEx 不行，需要显式降级。
        $did-atomic = so try { $tmp.rename($f); True };
        unless $did-atomic {
            # 关键：不能先 unlink 目标。先把旧文件移到同目录备份，
            # 新文件 rename 成功后才删备份；失败则把备份移回，绝不丢数据。
            my Str $old-name = $f.Str ~ ".rakuish-v3-old-" ~ self!random-token ~ ".tmp";
            my IO::Path $old = IO::Path.new($old-name);
            my Bool $moved = so try { $f.rename($old); True };
            X::Rakuish::Path.new(
                :detail("无法替换目标文件（准备备份失败）: {$f.Str}")
            ).throw unless $moved;

            my Bool $replaced = so try { $tmp.rename($f); True };
            unless $replaced {
                my Bool $restored = so try { $old.rename($f); True };
                X::Rakuish::Path.new(
                    :detail("替换目标文件失败，且回滚" ~
                            ($restored ?? '成功' !! '失败') ~ ": {$f.Str}")
                ).throw;
            }
            try $old.unlink;
        }
    }
    else {
        $tmp.rename($f);
        $did-atomic = True;
    }

    WriteResult.new(:path($f), :bytes($n), :atomic($did-atomic),
                    :backup($backup-path))
}

method append($p, $data, Bool :$mkdir = False, Str :$enc = 'utf-8',
              Int :$max-bytes --> WriteResult) {
    self.write($p, $data, :append, :$mkdir, :$enc, :$max-bytes)
}

# ── with-lock（0.105.0 / V-294）─────────────────────────────────────
# 用**独立伴生锁文件**（路径.lock）做劝告锁，而不是锁数据文件本身。
# 原因：write 是 .tmp + rename 换 inode——若锁在数据文件上，rename 后锁就
# 留在旧 inode 上，对新的数据文件不再生效。锁文件 inode 稳定，不受影响。
# 锁文件故意不删除：删了会让两个进程各锁一个 inode，互斥失效（经典锁文件坑）。
method with-lock($p, &block, Bool :$shared = False,
                 Bool :$non-blocking = False) {
    my IO::Path $f = self!resolve($p);
    X::Rakuish::Path.new(:detail("路径不能为空: {$f.Str}")).throw
        unless $f.Str.chars;
    my IO::Path $lock = IO::Path.new($f.Str ~ '.lock');
    X::Rakuish::Path.new(:detail("锁文件是符号链接，拒绝: {$lock.Str}")).throw
        if $lock.l;

    my $fh = try { $lock.open(:rw) };
    unless $fh.defined {
        # 不存在则创建（空文件即锁载体），再加锁。
        try { $lock.spurt('', :bin) };
        $fh = try { $lock.open(:rw) };
    }
    X::Rakuish::Path.new(:detail("无法打开锁文件: {$lock.Str}")).throw
        unless $fh.defined;
    LEAVE { try $fh.close }   # 关句柄即解锁；&block 抛异常也照常释放

    my Bool $got = so try {
        $fh.lock(:$shared, :$non-blocking);
        True;
    };
    unless $got {
        my Str $msg = $!.defined ?? $!.message !! '未知原因';
        X::Rakuish::LockConflict.new(
            :detail("无法获取{$shared ?? '共享' !! '独占'}锁: {$lock.Str}（{$msg}）；"
                    ~ "另一个进程正持有它，稍后重试或去掉 :non-blocking 等待")
        ).throw;
    }
    $! = Nil;   # 清掉 try 遗留的 $!
    block()
}

# ── ls / stat ─────────────────────────────────────────────────────────
method ls($p = '.', Bool :$all = False, Bool :$recursive = False,
          Int :$max-depth, Bool :$follow-symlinks = False --> List) {
    my IO::Path $d = self!resolve($p);
    X::Rakuish::NotFound.new(:detail("路径不存在: {$d.Str}")).throw
        unless $d.e || $d.l;
    # shell `ls file` 会打印文件本身；这里保持同样习惯。
    return ($d,) unless $d.d;
    my $limit = $max-depth // ($recursive ?? Inf !! 1);
    my @counter = [0];
    my @entries = self!walk($d, 1, $limit, @counter,
                            :$all, :$follow-symlinks,
                            :max-entries($!max-entries));
    @entries.List
}

method !walk(IO::Path $d, Int $depth, $limit, $counter,
             Bool :$all, Bool :$follow-symlinks,
             Int :$max-entries --> List) {
    my @out;
    for (try { $d.dir } // ()) -> $child {
        next if !$all && $child.basename.starts-with('.');
        $counter[0]++;
        X::Rakuish::Limit.new(
            :detail("目录条目超限: {$counter[0]} > {$max-entries} ({$d.Str})")
        ).throw if $max-entries > 0 && $counter[0] > $max-entries;
        @out.push($child);
        if $depth < $limit && $child.d && (!$child.l || $follow-symlinks) {
            @out.append(self!walk($child, $depth + 1, $limit, $counter,
                                  :$all, :$follow-symlinks,
                                  :$max-entries));
        }
    }
    @out.List
}

# 结构化目录列表：给 Table 消费者 / ls --json / 数据管道用。
method ls-table($p = '.', Bool :$all = False, Bool :$recursive = False,
                Int :$max-depth, Bool :$follow-symlinks = False
                --> Rakuish::Data::Table) {
    my @entries = self.ls($p, :$all, :$recursive, :$max-depth,
                          :$follow-symlinks);
    my @rows;
    for @entries -> $e {
        my $st = try { self.stat($e) };
        my Str $type = $e.l ?? 'symlink' !! ($e.d ?? 'dir' !! 'file');
        my Str $modified = '';
        if $st.defined && $st.modified.defined
           && $st.modified >= Instant.from-posix(946684800) {
            $modified = $st.modified.DateTime.Str;
        }
        @rows.push({
            name     => $e.basename,
            type     => $type,
            size     => ($st.defined ?? $st.size !! 0),
            modified => $modified,
            path     => $e.Str,
        });
    }
    Rakuish::Data::Table.from-rows(@rows, :columns<name type size modified path>);
}

method stat($p --> Stat) {
    my IO::Path $f = self!resolve($p);
    X::Rakuish::NotFound.new(:detail("路径不存在: {$f.Str}")).throw
        unless $f.e || $f.l;
    Stat.new(
        path       => $f,
        size       => (($f.f ?? (try { $f.s } // 0) !! 0)),
        is-file    => so($f.f),
        is-dir     => so($f.d),
        is-symlink => so($f.l),
        readable   => so(try { $f.r }),
        writable   => so(try { $f.w }),
        executable => exec-p($f),
        mode       => ((try { $f.mode.Int } // 0)),
        modified   => (try { $f.modified } // Instant),
    )
}

# ── rm ────────────────────────────────────────────────────────────────
# 不跟随符号链接：链接只 unlink，绝不递归进目标；拒绝删文件系统根。
# dry-run 返回计划（路径列表），一个字节都不动。
method rm($p, Bool :$recursive = False, Bool :$force = False,
          Bool :$dry-run = False --> Result) {
    my IO::Path $f = self!resolve($p);
    X::Rakuish::Bound.new(:detail("拒绝删除文件系统根: {$f.Str}")).throw
        if $f.parent.Str eq $f.Str;

    unless $f.e || $f.l {
        return Result.new(:ok, :op<rm>, :out('no-op: 不存在')) if $force;
        X::Rakuish::NotFound.new(:detail("不存在: {$f.Str}")).throw;
    }

    my @plan = self!rm-plan($f, [0], :$recursive,
                            :max-entries($!max-entries));
    return Result.new(:ok, :op<rm>, :value(@plan.map(*.[1].Str).List),
                      :out("dry-run: {@plan.elems} 项")) if $dry-run;

    # plan 本身已是后序（子项在前、父目录在后），按原序执行即可。
    # ⚠ 不要 reverse：reverse 会先 rmdir 非空父目录，再删子项 —— 父目录
    #   永远删不掉，而 try 会把失败吞掉，返回一个 ok=True 的假绿结果。
    my Str @errs;
    for @plan -> $e {
        my IO::Path $target = $e[1];
        my Bool $done = so try {
            $e[0] eq 'dir' ?? $target.rmdir !! $target.unlink;
            True
        };
        @errs.push("{$e[0]}: {$target.Str}") unless $done;
    }
    my Bool $gone = !($f.e || $f.l);
    @errs.push("目标仍存在: {$f.Str}") unless $gone;

    my Bool $ok = !@errs.elems;
    Result.new(:ok($ok), :code($ok ?? 0 !! 1), :op<rm>,
               :value(@plan.elems), :out("removed {@plan.elems} 项"),
               :err(@errs.join('; ')))
}

method !rm-plan(IO::Path $f, $counter, Bool :$recursive,
                Int :$max-entries --> List) {
    my @out;
    $counter[0]++;
    X::Rakuish::Limit.new(
        :detail("删除条目超限: {$counter[0]} > {$max-entries} ({$f.Str})")
    ).throw if $max-entries > 0 && $counter[0] > $max-entries;
    if $f.l {
        @out.push(['link', $f]);                    # 关键：只看链接本身
    }
    elsif $f.d {
        X::Rakuish::Path.new(:detail("目录需要 :recursive: {$f.Str}")).throw
            unless $recursive;
        for (try { $f.dir } // ()) -> $c {
            @out.append(self!rm-plan($c, $counter, :recursive,
                                     :$max-entries));
        }
        @out.push(['dir', $f]);                     # 子项在前，父目录在后
    }
    else {
        @out.push(['file', $f]);
    }
    @out.List
}

# ── cp / mv / mkdir ───────────────────────────────────────────────────
method cp($from, $to, Bool :$recursive = False,
          Int :$max-bytes,
          Bool :$overwrite = False --> Result) {
    my IO::Path $a = self!resolve($from);
    my IO::Path $b = self!resolve($to);
    my Int $cap = $max-bytes // $!max-bytes;
    X::Rakuish::NotFound.new(:detail("源不存在: {$a.Str}")).throw unless $a.e || $a.l;
    X::Rakuish::Exists.new(:detail("目标已存在: {$b.Str}（需要 :overwrite）")).throw
        if $b.e && !$overwrite;
    X::Rakuish::Unsupported.new(:detail("Phase 1 不复制符号链接: {$a.Str}")).throw
        if $a.l;
    if $recursive && $a.d {
        # 0.134.0 / AUDIT-FS-LIMITS S8：`!count-entries` 以前不吃上限，
        # 对 `C:\Windows` 这类目录是 O(n) 无界递归 —— 预检本身成了新的炸弹。
        # 现在边数边判，超 `max-entries` 立即抛（与 `!walk` 同口径）。
        my Int $entries = self!count-entries($a, $!max-entries);
        X::Rakuish::Limit.new(
            :detail("复制条目超限: 已数到 {$entries} > {$!max-entries} ({$a.Str})；"
                ~ "大目录请分子目录复制，或 Rakuish::Sys.new(:max-entries(N))")
        ).throw if $!max-entries > 0 && $entries > $!max-entries;
    }
    my Int $n = self!copy-one($a, $b, :$recursive, :$cap);
    Result.new(:ok, :op<cp>, :value($n))
}

# `$cap` 为 0 表示「不设上限」（沿用 `> 0` 才生效的既有约定）。
method !count-entries(IO::Path $dir, Int $cap = 0 --> Int) {
    my Int $n = 0;
    for (try { $dir.dir } // ()) -> $c {
        $n++;
        # 早停：数到上限外一个就够判「超了」，不必把整棵树走完。
        X::Rakuish::Limit.new(
            :detail("复制条目超限: 已数到 {$n} > {$cap} ({$dir.Str})；"
                ~ "大目录请分子目录复制，或 Rakuish::Sys.new(:max-entries(N))")
        ).throw if $cap > 0 && $n > $cap;
        $n += self!count-entries($c, $cap) if $c.d && !$c.l;
    }
    $n;
}

method !copy-one(IO::Path $a, IO::Path $b, Bool :$recursive, Int :$cap --> Int) {
    X::Rakuish::Unsupported.new(
        :detail("不复制符号链接（避免跟随到 root 外）: {$a.Str}")
    ).throw if $a.l;
    if $a.d {
        X::Rakuish::Path.new(:detail("目录需要 :recursive: {$a.Str}")).throw
            unless $recursive;
        $b.mkdir unless $b.d;
        my Int $n = 0;
        for (try { $a.dir } // ()) -> $c {
            $n += self!copy-one($c, $b.add($c.basename), :recursive, :$cap);
        }
        $n
    }
    else {
        my Int $sz = (try { $a.s } // 0);
        X::Rakuish::Limit.new(:detail(
            "复制超限: {$sz} > {$cap} 字节 ({$a.Str})；"
                ~ "可传 :max-bytes(N) 单次抬高，或 Rakuish::Sys.new(:max-bytes(N))"))
            .throw if $cap > 0 && $sz > $cap;
        $b.spurt($a.slurp(:bin), :bin);
        1
    }
}

method mv($from, $to, Bool :$overwrite = False --> Result) {
    my IO::Path $a = self!resolve($from);
    my IO::Path $b = self!resolve($to);
    X::Rakuish::NotFound.new(:detail("源不存在: {$a.Str}")).throw unless $a.e || $a.l;
    my IO::Path $old;
    my Bool $had-old = False;
    if $b.e {
        X::Rakuish::Exists.new(:detail("目标已存在: {$b.Str}（需要 :overwrite）")).throw
            unless $overwrite;
        X::Rakuish::Unsupported.new(:detail("Phase 1 不支持覆盖目录: {$b.Str}")).throw
            if $b.d;
        # 先备份目标；rename 失败时能恢复，不能先 unlink 丢数据。
        my Str $old-name = $b.Str ~ ".rakuish-v3-mv-" ~ self!random-token ~ ".tmp";
        $old = IO::Path.new($old-name);
        X::Rakuish::Path.new(:detail("无法备份目标: {$b.Str}")).throw
            unless so try { $b.rename($old); True };
        $had-old = True;
    }
    my Bool $renamed = so try { $a.rename($b); True };
    if $renamed {
        try $old.unlink if $had-old;
    }
    else {
        # 恢复目标后再走跨设备 cp/rm 回退。
        try $old.rename($b) if $had-old;
        my $cp = self.cp($from, $to, :recursive($a.d), :overwrite);
        unless $cp.ok {
            return Result.new(:!ok, :op<mv>,
                              :err("跨设备复制失败: {$cp.err}"));
        }
        my $rm = self.rm($from, :recursive($a.d), :force);
        unless $rm.ok {
            return Result.new(:!ok, :op<mv>,
                              :err("复制成功但删除源失败: {$rm.err}"));
        }
    }
    Result.new(:ok, :op<mv>, :value($b.Str))
}

method mkdir($p, Bool :$parents = True --> Result) {
    my IO::Path $d = self!resolve($p);
    return Result.new(:ok, :op<mkdir>, :out('已存在')) if $d.d;
    self!ensure-parent($d.parent) if $parents;
    $d.mkdir;
    Result.new(:ok, :op<mkdir>, :value($d.Str))
}

method !ensure-parent(IO::Path $d) {
    return if $d.d;
    my @chain;
    my IO::Path $cur = $d;
    while !$cur.d {
        @chain.push($cur);
        my $p = $cur.parent;
        last if $p.Str eq $cur.Str;
        $cur = $p;
    }
    for @chain.reverse -> $x { try $x.mkdir }
}

# ── glob（* ? **/ [a-z] {a,{b,c}} 与反斜杠转义）──────────────────────
# 模式匹配的是**相对 root 的路径**，且 * 不跨目录分隔符（标准 glob 语义）。
#
# 刻意不用动态正则：Raku 的 rx/<$rx-str>/ 会把插值文本当正则代码解析，
# 模式里的 `/` 和 `.` 都会变成元字符（实测 `/` 直接编译失败）。
# 这里用经典双指针回溯，行为确定、无注入面。
#
# 转义：'\' + 元字符（* ? [ ] { } , \）按字面量匹配，先编码成 GLOB-ESC
# 加该字符，避免后续 brace 展开 / 通配符匹配把它们当语法。裸 '\' 仍按
# Windows 路径分隔符归一化为 '/'，保持既有兼容。
my constant GLOB-ESC  = "\x[E000]";        # 私用区哨兵：其后一字符是字面量
my constant GLOB-META = '*?[]{},\\';

method !normalize-pattern(Str $pattern --> Str) {
    my @c = $pattern.comb;
    my Str $out = '';
    my Int $i = 0;
    while $i < @c.elems {
        if @c[$i] eq '\\' {
            if $i + 1 < @c.elems && GLOB-META.contains(@c[$i + 1]) {
                # '\\' 归一化成 '/'（路径分隔符语义），其余保留被转义字符
                $out ~= GLOB-ESC ~ (@c[$i + 1] eq '\\' ?? '/' !! @c[$i + 1]);
                $i += 2;
            }
            else {
                $out ~= '/';
                $i++;
            }
        }
        else {
            $out ~= @c[$i];
            $i++;
        }
    }
    $out
}

method !class-match(Str $ch, Str $inside --> Bool) {
    my Bool $neg = $inside.starts-with('!') || $inside.starts-with('^');
    my Str $body = ($neg ?? $inside.substr(1) !! $inside);
    my Bool $hit = False;
    my @c = $body.comb;
    my Int $n = @c.elems;
    my Int $i = 0;
    while $i < $n {
        my Bool $esc = @c[$i] eq GLOB-ESC;
        my Str $lo = $esc ?? ($i + 1 < $n ?? @c[$i + 1] !! '') !! @c[$i];
        my Int $step = $esc ?? 2 !! 1;
        if $lo eq '' { $i += $step; next }
        my Int $dash = $i + $step;
        if $dash + 1 < $n && @c[$dash] eq '-' {
            my Int $k = $dash + 1;
            my Bool $hi-esc = @c[$k] eq GLOB-ESC;
            my Str $hi = $hi-esc ?? ($k + 1 < $n ?? @c[$k + 1] !! '') !! @c[$k];
            $hit = True if $hi.chars
                && $ch.ord >= $lo.ord && $ch.ord <= $hi.ord;
            $i = $k + ($hi-esc ?? 2 !! 1);
        }
        else {
            $hit = True if $ch eq $lo;
            $i += $step;
        }
    }
    $neg ?? !$hit !! $hit;
}

method !glob-match(Str $s, Str $pat --> Bool) {
    # globstar：**/ 匹配零个或多个目录段。
    if $pat eq '**' { return True }
    if $pat.starts-with('**/') {
        my Str $rest = $pat.substr(3);
        return True if self!glob-match($s, $rest);
        my Int $at = -1;
        loop {
            my $slash = $s.index('/', $at + 1);
            last unless $slash.defined;
            $at = $slash;
            return True if self!glob-match($s.substr($at + 1), $rest);
        }
        return False;
    }
    # foo/**/bar：左侧按字面前缀匹配，剩余部分继续按 **/ 规则。
    if $pat.contains('/**/') {
        my Int $at = $pat.index('/**/');
        my Str $left = $pat.substr(0, $at);
        my Str $right = $pat.substr($at + 4);
        return False unless $s.starts-with($left ~ '/');
        return self!glob-match($s.substr($left.chars + 1), '**/' ~ $right);
    }
    # foo/**：匹配 foo 下任意深度。
    if $pat.ends-with('/**') {
        my Str $left = $pat.substr(0, $pat.chars - 3);
        return $s.starts-with($left ~ '/');
    }

    my @s = $s.comb;
    my @p = $pat.comb;
    my Int $i = 0;
    my Int $j = 0;
    my Int $star = -1;
    my Int $mark = 0;

    while $i < @s.elems {
        if $j < @p.elems && @p[$j] eq GLOB-ESC {
            # 转义过的元字符：按字面量匹配，不参与通配
            return False if $j + 1 >= @p.elems || @s[$i] ne @p[$j + 1];
            $i++; $j += 2;
        }
        elsif $j < @p.elems && @p[$j] eq '?' {
            # 标准 glob：? 只匹配单个非分隔符字符
            return False if @s[$i] eq '/';
            $i++; $j++;
        }
        elsif $j < @p.elems && @p[$j] eq '[' {
            my Int $end = $j + 1;
            while $end < @p.elems && @p[$end] ne ']' {
                $end += (@p[$end] eq GLOB-ESC ?? 2 !! 1);
            }
            return False if $end >= @p.elems;
            return False if @s[$i] eq '/';
            my Str $inside = @p[($j + 1) ..^ $end].join('');
            return False unless self!class-match(@s[$i], $inside);
            $i++; $j = $end + 1;
        }
        elsif $j < @p.elems && @p[$j] eq @s[$i] {
            $i++; $j++;
        }
        elsif $j < @p.elems && @p[$j] eq '*' {
            $star = $j;
            $mark = $i;
            $j++;
        }
        elsif $star >= 0 {
            # * 每回溯一次多吞一个字符，但绝不能吞掉 '/'
            return False if $mark >= @s.elems || @s[$mark] eq '/';
            $mark++;
            $i = $mark;
            $j = $star + 1;
        }
        else {
            return False;
        }
    }
    $j++ while $j < @p.elems && @p[$j] eq '*';
    $j == @p.elems
}

# brace 展开：按字符扫描，支持嵌套 {a,{b,c}}、转义 \{ \} \, ，
# 且只在最外层深度为 1 的逗号上切分。哨兵后的字符一律跳过。
method !expand-braces(Str $pat --> List) {
    my @c = $pat.comb;
    my Int $n = @c.elems;
    my Int $open = -1;
    my Int $i = 0;
    while $i < $n {
        if @c[$i] eq GLOB-ESC { $i += 2; next }
        if @c[$i] eq '{' { $open = $i; last }
        $i++;
    }
    return ($pat,) if $open < 0;

    my Int $depth = 1;
    my Int $j = $open + 1;
    my Int $start = $j;
    my @alts;
    while $j < $n {
        if @c[$j] eq GLOB-ESC { $j += 2; next }
        if @c[$j] eq '{' { $depth++ }
        elsif @c[$j] eq '}' {
            $depth--;
            last if $depth == 0;
        }
        elsif @c[$j] eq ',' && $depth == 1 {
            @alts.push(@c[$start ..^ $j].join(''));
            $start = $j + 1;
        }
        $j++;
    }
    return ($pat,) if $depth != 0;      # 未闭合 brace：整串按字面处理

    @alts.push(@c[$start ..^ $j].join(''));
    my Str $pre  = @c[0 ..^ $open].join('');
    my Str $post = @c[$j + 1 ..^ $n].join('');
    my @out;
    for @alts -> $alt {
        @out.append(self!expand-braces($pre ~ $alt ~ $post));
    }
    @out.unique.List
}

method glob(Str $pattern, $root = '.', Bool :$all = False --> List) {
    my IO::Path $r = self!resolve($root);
    my Str $prefix = $r.Str.subst(:g, '\\', '/');
    $prefix ~= '/' unless $prefix.ends-with('/');
    my Str $pat = self!normalize-pattern($pattern);
    my @patterns = self!expand-braces($pat);

    # 只有 ** 才需要无界递归；普通 *.jpg 只扫当前目录。按模式段数设置
    # max-depth，sub/*.jpg 仍能匹配，但不会把整棵子树都走一遍。
    my Bool $deep = so @patterns.first({ .contains('**') });
    my Int $depth = 1;
    for @patterns -> $p {
        my Int $n = $p.split('/').grep({ .chars }).elems;
        $depth = $n if $n > $depth;
    }

    my @entries = $deep
        ?? self.ls($root, :$all, :recursive)
        !! self.ls($root, :$all, :max-depth($depth));

    @entries.grep({
        my Str $s = .Str.subst(:g, '\\', '/');
        my Str $rel = $s.starts-with($prefix) ?? $s.substr($prefix.chars) !! $s;
        so @patterns.first({ self!glob-match($rel, $_) });
    }).List
}
