unit module Rakuish::Data::Duck;

# Rakuish::Data::Duck —— Table ⟷ DuckDB（Duckula）的桥（0.120.0 / V-315）。
#
# 三方分工，各管一段：
#   · 解码：`.arrow` 文件 → Table 走 Arrow::IPC（0.118.3 起，支持 list/struct/map）
#   · 编码：Table → `.arrow` 文件走 Rakuish::Data::Arrow（纯 Raku，零原生依赖）
#   · 计算：Table → SQL 走 Duckula（DuckDB 的 DataFrame 层）
#
# 桥本身只做两件事：把 Table 写成临时 Arrow IPC 文件交给 Duckula 的
# `read-arrow`，再把查询结果的 Frame 读回 Table。**不让 Duckula 写 IPC**：
# 0.33.1 的 `ipc-buf` 在 timestamp / date 列上会产出 pyarrow 与 Arrow::IPC
# 都读不了（前者报 Not an Arrow file，后者直接段错误）的字节流 —— 已在
# ADR-0043 记录，等上游修；回读走 Frame 的 Raku 值，不碰那条路径。

use JSON::Fast;
use Rakuish::Result;
use Rakuish::Data::Table;

# 运行时加载 Duckula 并取 Session 类。
# 不能写 `require ::('Duckula')`：那是「按变量名软查找」，在我们这种模块
# 作用域里会静默返回 Nil（实测）。字面 `require Duckula` 才会真正加载
# provides 表里的整个发行版；类从 WHO 里取，避免编译期符号解析（本模块
# 编译时 Duckula 可能还没装）。
my sub duck-session-class() {
    require Duckula;
    Duckula.WHO<Session>;
}

# 结果列名要能当 SQL 标识符用，也避免拼进 SQL 时被当成语法。
my sub check-name(Str $name) {
    X::Rakuish::Data.new(
        :detail("表名 '{$name}' 不合法：只允许字母、数字、下划线，且不能以数字开头")
    ).throw unless $name ~~ /^ <[A..Z a..z _]> <[A..Z a..z 0..9 _]>* $/;
    $name;
}

# ── DuckDB 类型 → Table 类型 ─────────────────────────────────────────
# Duckula 的 dtypes 给的是 DuckDB 的 SQL 类型名（BIGINT / DECIMAL(10,2) /
# TIMESTAMP WITH TIME ZONE / VARCHAR[] …），不是 Arrow format 串。
our sub duck-type(Str $t --> Str) is export {
    my Str $u = $t.uc;
    return 'list' if $u.ends-with('[]');
    return 'map'  if $u ~~ /^ 'STRUCT' | ^ 'MAP' | ^ 'UNION' /;
    return 'datetime' if $u ~~ /^ 'TIMESTAMP' | ^ 'DATE' /;
    return 'bool' if $u ~~ /^ 'BOOL'/;
    return 'int'  if $u ~~ /^ 'TINYINT' | ^ 'SMALLINT' | ^ 'INTEGER' | ^ 'BIGINT'
                       | ^ 'HUGEINT' | ^ 'UTINYINT' | ^ 'USMALLINT' | ^ 'UINTEGER'
                       | ^ 'UBIGINT' | ^ 'UHUGEINT' /;
    return 'num'  if $u ~~ /^ 'DECIMAL' | ^ 'NUMERIC' | ^ 'DOUBLE'
                       | ^ 'FLOAT' | ^ 'REAL' /;
    'str';
}

# "2020-01-01 12:00:00" / "2020-01-01 12:00:00.5+08" → DateTime。
# 解析不了就返回 Nil，调用方把整列退回 str（和 open-data 的口径一致：
# 不把没解析成功的字符串伪装成时间）。
my sub parse-datetime($v) {
    return $v if $v ~~ DateTime;
    return Nil unless $v.defined;
    my Str $s = $v.Str.trim;
    return Nil unless $s.chars;
    my $d = try DateTime.new($s.subst(' ', 'T'));
    $d.defined && $d ~~ DateTime ?? $d !! Nil;
}

# ── Frame → Table ─────────────────────────────────────────────────────
# Frame.rows 给的是 Array of Array（Raku 原生值），dtypes 给 SQL 类型名；
# 两者一起还原成 Table 的列类型。日期时间列整列尝试转换，有一格失败就
# 整列退回 str —— 混合列比错误类型更难用。
our sub table-from-frame($frame --> Rakuish::Data::Table) is export {
    my %dtypes;
    for $frame.names.List -> $n { %dtypes{$n.Str} = ($frame.dtypes{$n} // '').Str }
    # 优先用列式数据（如果 Duckula 暴露了）：省掉逐行 Hash 的 4 s。
    if $frame.^can('columns-typed').elems {
        my @cols = $frame.columns-typed.List;
        return table-from-columns($frame.names.List, %dtypes, @cols, :columnar);
    }
    table-from-columns($frame.names.List, %dtypes, $frame.rows.List);
}

# 列名 + SQL 类型名 + 行/列 → Table（table-from-frame 与读文件共用一套口径）。
#
# :columnar(True) — @data-in 每列一个 Positional，按列式处理（Duckula columns-typed 直接传进来）
# :columnar(False) — @data-in 每行一个 Positional（老调用方：frame.rows 直接传进来）
#
# 行式会先转置成列式，然后所有路径共用「列式 datetime 转换 → 行式组 Hash」一次遍历。
our sub table-from-columns(@names-in, %dtypes, @data-in,
                           Bool :$columnar = False --> Rakuish::Data::Table) is export {
    my @names = @names-in.map(*.Str);
    X::Rakuish::Data.new(:detail('查询结果没有列')).throw unless @names.elems;
    my %dup;
    for @names -> $n { %dup{$n}++ }
    if %dup.values.grep(* > 1) {
        X::Rakuish::Data.new(
            :detail('查询结果有重名列：' ~ %dup.grep(*.value > 1).map(*.key).sort.join(', ')
                ~ '；给列起别名再查')
        ).throw;
    }

    my %types;
    for @names -> $n {
        %types{$n} = duck-type((%dtypes{$n} // '').Str);
    }

    # 统一成列式 @cols：@cols[$col][$row]
    my @cols;
    if $columnar {
        # 调用方已经按列式传进来
        @cols = @data-in.map(*.List);
    }
    else {
        # 行式 → 列式转置
        my @rows = @data-in.List;
        for @names.kv -> $i, $n {
            @cols.push([@rows.map({ $_[$i] }).List]);
        }
    }
    my Int $nrows = @cols.elems ?? @cols[0].elems !! 0;

    # datetime 列整列尝试转换，有一格失败整列退回 str。
    for @names.kv -> $i, $n {
        next unless %types{$n} eq 'datetime';
        # `.List` 是关键：@cols[$i] 返回的 Array 直接赋给 @vals 会变成
        # 单元素嵌套数组（Raku 默认不 flatten Positional 赋值）。
        my @vals = @cols[$i].List;
        my Bool $all-ok = True;
        my @conv;
        for @vals -> $v {
            if $v.defined {
                my $d = parse-datetime($v);
                if $d.defined { @conv.push($d) }
                else { $all-ok = False; last }
            }
            else { @conv.push(Any) }
        }
        if $all-ok && @conv.elems == @vals.elems {
            @cols[$i] = @conv;
        }
        else {
            %types{$n} = 'str';
        }
    }

    # 列式 → 行式 Hash（Table.rows 契约必须是 Array[Hash]）
    my @rows;
    for ^$nrows -> $r {
        my %h;
        for @names.kv -> $i, $n {
            my $v = @cols[$i][$r];
            %h{$n} = $v.defined ?? $v !! Any;
        }
        @rows.push(%h);
    }

    Rakuish::Data::Table.new(:columns(@names), :rows(@rows), :types(%types));
}

# ── .arrow 读取：交给 DuckDB（0.122.0 / V-318）────────────────────────
# 只给「逐值与自研读入器一致」的标量列用（白名单在 Data.rakumod 里判）。
# 返回 Nil 表示这条路走不了（Duckula / DB::DuckDB / nanoarrow 缺一个），
# 调用方回落到纯 Raku 读入器；真正的读取错误照常抛。
#
# 「快路可不可用」本身也要能问：测试与错误信息都依赖它，而三者缺一个的
# 机器（比如没装 nanoarrow 扩展的 WSL）行为确实不同。结果按进程缓存 ——
# require 失败一次就够了，不必每次 open 都重试。
my Bool $checked = False;
my Bool $usable = False;

our sub arrow-native-available(--> Bool) is export {
    return $usable if $checked;
    $checked = True;

    my $sess-class;
    try { $sess-class = duck-session-class() };
    return False unless $sess-class.^can('new').elems;

    my $sess = try { $sess-class.new };
    return False unless $sess.defined;
    my Bool $ok = (try { $sess.conn.arrow-available }) // False;
    try { $sess.close };
    $usable = $ok;
}

our sub read-arrow-native(Str $path) {
    return Nil unless arrow-native-available;

    my $sess-class;
    try { $sess-class = duck-session-class() };
    return Nil unless $sess-class.^can('new').elems;

    my $sess = try { $sess-class.new };
    return Nil unless $sess.defined;
    LEAVE { try { $sess.close } }

    table-from-frame($sess.read-arrow($path));
}

# 每列「首个非空值」一次遍历拿全 —— 按列各扫一遍是 O(列数 × 行数)，
# 5 万行 × 5 列实测吃掉 2.5 s（duck-ready 与直插的 DDL 判断都用它）。
my sub first-per-column(@cols, @rows --> Hash) {
    my %sample;
    my Int $need = @cols.elems;
    for @rows -> %row {
        for @cols -> $c {
            next if %sample{$c}:exists;
            my $v = %row{$c};
            next unless $v.defined;
            %sample{$c} = $v;
            $need--;
            last if $need == 0;
        }
        last if $need == 0;
    }
    %sample;
}

# ── Table → 可写的 Table ──────────────────────────────────────────────
# 写侧（Rakuish::Data::Arrow）只支持标量列：嵌套列在 0.120.0 起会明确报错，
# 不再静默拼成 ".Str"（那是 `age\t30\nname\tann` 这种垃圾）。要过 SQL 的
# 嵌套列，这里显式转成 JSON 文本，类型记 str —— 可读、可 like、可再 to-json
# 解回来，且不假装 DuckDB 能直接取结构体字段。
our sub duck-ready(Rakuish::Data::Table $t --> Rakuish::Data::Table) is export {
    my @cols = $t.columns.map(*.Str);
    my %nested;
    my %sample = first-per-column(@cols, $t.rows);
    for @cols -> $c {
        my Str $kind = ($t.types{$c} // 'str').Str;
        if $kind eq 'list' | 'map' {
            %nested{$c} = True;
            next;
        }
        # 类型标错但值是嵌套结构时的兜底：按值判断，别让写侧炸在用户看不懂的地方。
        my $probe = %sample{$c};
        %nested{$c} = True
            if $probe.defined && $probe ~~ Positional | Associative;
    }
    return $t unless %nested;

    my %types = $t.types.Hash;
    my @rows;
    for $t.rows -> %row {
        my %h;
        for @cols -> $c {
            my $v = %row{$c};
            if %nested{$c} {
                if $v.defined {
                    my $json = try { to-json($v, :!pretty) };
                    %h{$c} = $json.defined ?? $json !! $v.Str;
                }
                else { %h{$c} = Any }
                %types{$c} = 'str';
            }
            else { %h{$c} = $v }
        }
        @rows.push(%h);
    }
    Rakuish::Data::Table.new(:columns(@cols), :rows(@rows), :types(%types));
}

# ── Table → DuckDB 的类型映射（0.134.0 / AUDIT 路线 B）───────────────────
# 直插路径要自己拼 DDL，所以类型映射与标识符转义都落在这里。
# `list` / `map` 在 duck-ready 之后已经是 JSON 文本，按 VARCHAR 存。
my constant DUCK-DDL-TYPE = %(
    int      => 'BIGINT',
    num      => 'DOUBLE',
    str      => 'VARCHAR',
    bool     => 'BOOLEAN',
    datetime => 'TIMESTAMP',
    list     => 'VARCHAR',
    map      => 'VARCHAR',
    any      => 'VARCHAR',
);

# SQL 标识符转义：双写 `"` 再包起来。列名/表名都会被拼进 DDL，所以必须转义 ——
# 以前「列名完全不进 SQL」（表名只当 read-arrow 的名字），直插之后这条欠账
# 必须补上（AUDIT 的「#6 欠账转嫁」）。
my sub quote-ident(Str $name --> Str) {
    '"' ~ $name.subst('"', '""', :g) ~ '"';
}

# 每列一个转换闭包（按声明类型固定），避免逐值 `given` 派发 ——
# 5 万行 × 5 列 = 25 万次调用，闭包比每次重新分派便宜一个量级。
my sub converter-for(Str $kind --> Callable) {
    given $kind {
        when 'int'      { -> $v { $v.defined ?? ($v.isa(Int) ?? $v !! $v.Int) !! Any } }
        when 'num'      { -> $v { $v.defined ?? ($v ~~ Numeric ?? $v !! $v.Num) !! Any } }
        when 'bool'     { -> $v { $v.defined ?? $v.Bool !! Any } }
        when 'datetime' {
            # 用 if/elsif/else 表达式（块里写 `return` 会返回外层 routine；
            # 写裸语句会落进 sink context，两个都是坑）。
            -> $v {
                if !$v.defined { Any }
                elsif $v ~~ DateTime { $v }
                else {
                    my $d = parse-datetime($v);
                    $d.defined ?? $d !! $v.Str;
                }
            }
        }
        default         { -> $v { $v.defined ?? ($v ~~ Str ?? $v !! $v.Str) !! Any } }
    }
}

# Table → (DDL, 行列表)。行是 Positional，按列顺序对齐（Appender 要这个形状）。
#
# 性能上限全在「逐值处理」：5 万行 × 5 列 = 25 万次。所以：
#   · 抽样的成本必须**一次遍历**拿全所有列的首个非空值（按列各扫一遍是
#     O(列数 × 行数)，实测吃掉 2.5 s）；
#   · 值本身已经是声明类型时（绝大多数）整表走直通分支，用 hash 切片一次取齐；
#   · 只有确实需要转换的列才逐值调转换器。
my sub table-to-ddl(Rakuish::Data::Table $t, Str $view --> List) {
    my Str @cols = $t.columns.map(*.Str);
    my @decls;
    for @cols -> $c {
        my Str $kind = ($t.types{$c} // 'str').Str;
        $kind = 'str' unless DUCK-DDL-TYPE{$kind}:exists;
        @decls.push(quote-ident($c) ~ ' ' ~ DUCK-DDL-TYPE{$kind});
    }

    my %sample = first-per-column(@cols, $t.rows);

    my @kind = @cols.map(-> $c {
        my Str $k = ($t.types{$c} // 'str').Str;
        DUCK-DDL-TYPE{$k}:exists ?? $k !! 'str';
    });
    my Bool $all-native = True;
    my @conv;
    for @cols.kv -> $i, $c {
        my Str $kind = @kind[$i];
        my $sample = %sample{$c};
        my Bool $native = do {
            if $kind eq 'int'          { $sample ~~ Int }
            elsif $kind eq 'num'       { $sample ~~ Numeric }
            elsif $kind eq 'bool'      { $sample ~~ Bool }
            elsif $kind eq 'datetime'  { $sample ~~ DateTime }
            else                       { $sample ~~ Str }
        };
        $all-native = False unless $native;
        @conv.push($native ?? Callable !! converter-for($kind));
    }

    my Str $ddl = 'create table ' ~ quote-ident($view) ~ ' (' ~ @decls.join(', ') ~ ')';

    my @rows;
    if $all-native {
        # 直通：值已经是声明类型，NULL 用 Any。hash 切片一次取齐所有列。
        for $t.rows -> %row {
            my @raw = %row{@cols}.List;
            @rows.push(@raw.map(-> $v { $v.defined ?? $v !! Any }).List);
        }
    }
    else {
        for $t.rows -> %row {
            my @vals;
            for @cols.kv -> $i, $c {
                my $v = %row{$c};
                my $f = @conv[$i];
                @vals.push($f.defined ?? $f($v) !! ($v.defined ?? $v !! Any));
            }
            @rows.push(@vals.List);
        }
    }
    ($ddl, @rows);
}

# ── 主入口：多张表一起跑一段 SQL ────────────────────────────────────
# %tables 是 名字 => Table；SQL 里就当它们是这个会话里的普通表，可以 join。
#   query({ a => $t1, b => $t2 }, 'select ... from a join b using (k)')
our sub query(%tables, Str $query --> Rakuish::Data::Table) is export {
    # 运行时加载（Duckula 是可选依赖）；类从 WHO 里取，编译期不当符号解析。
    # 注意类对象本身是「undefined value」，不能用 `.defined` 判断。
    my $sess-class;
    try { $sess-class = duck-session-class() };
    X::Rakuish::Unsupported.new(
        :detail('Table.sql 需要 Duckula（DuckDB 的 DataFrame 层）；请先 zef install Duckula')
    ).throw unless $sess-class.^can('new').elems;
    X::Rakuish::Data.new(:detail('至少要有一张表')).throw unless %tables.elems;
    X::Rakuish::Data.new(:detail('SQL 不能为空')).throw unless $query.trim.chars;

    # 0.134.0 / AUDIT 路线 B：**不再写临时 Arrow 文件**。
    # 老路径（Table → 自研 Arrow 写临时文件 → read-arrow 建视图）每一张表都要
    # 一次 O(行数) 全量序列化：5 万行实测 4,784 ms，而 SQL 执行本身只要 4–5 ms
    # —— 桥的 99% 成本花在「把数据搬进 DuckDB」，不在查询。
    # 现在走 CREATE TABLE（显式 DDL）+ Appender 直插：5 万行 853 ms（5.6×），
    # 顺带去掉 nanoarrow 的隐式依赖（Appender 走原生 C 接口）。
    # 失败时**回落到老路径**：这条是纯优化，不能因为一个边界情况让 SQL 桥整体
    # 不可用（老路径是已验证的兜底）。
    my %paths;
    my $sess;
    LEAVE {
        try { $sess.close } if $sess.defined;
        for %paths.values -> $p { try { $p.IO.unlink if $p.IO.e } }
    }

    my Str $err;
    my $frame;
    {
        CATCH { default { $err = .message } }
        $sess = $sess-class.new;
        # 先把每张表建起来：DDL + 逐行 Appender。表名与列名都过标识符转义。
        my Bool $fast-ok = True;
        my %ddl-rows;
        for %tables.keys.sort -> $name {
            my Str $view = check-name($name.Str);
            my $t-ready = duck-ready(%tables{$name});
            %ddl-rows{$view} = table-to-ddl($t-ready, $view);
        }
        for %ddl-rows.keys.sort -> $view {
            my ($ddl, $rows) = @(%ddl-rows{$view});
            $sess.sql($ddl, :unsafe(True));        # DDL 必须走「写」入口
            $sess.insert($view, $rows.List) if $rows.elems;
        }
        # 用任何一个 Frame 上的 SQL 入口执行；查询里写的就是上面注册的表名。
        $frame = $sess.sql($query);
    }
    X::Rakuish::Data.new(
        :detail('SQL 执行失败: ' ~ (($err // '未知错误').Str.lines[0] // ''))
    ).throw if $err.defined;

    table-from-frame($frame);
}

# 单表糖：`$t.sql('select ... from t')`。
our sub table-sql(Rakuish::Data::Table $t, Str $query,
                  Str :$name = 't' --> Rakuish::Data::Table) is export {
    query({ check-name($name) => $t }, $query);
}
