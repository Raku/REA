use Test;
use JSON::Fast;
use Rakuish::Display;
use Rakuish::DSL;
use Rakuish::REPL::Session;
use Rakuish::Kernel;
use Rakuish::Kernel::Notebook;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;
use Rakuish::Audit;

# 0.124.0 / ADR-0048 P1：显示协议。
#   ① 鸭子类型 `to-mime` 优先于内置识别；失败降级、不抛。
#   ② 额外 MIME（svg 等）透传：available / has / pick / render / to-mime 一致。
#   ③ HTML / Markdown / JSON 包装类型与终端降级。
#   ④ `display()` 在 TTY：立即输出、不产生 Out[n]、不改 `_`。
#   ⑤ `display()` 在 notebook：收集成 display_data，cell 末尾的值仍是 execute_result。

%*ENV<RAKUISH_NO_SNAPSHOT> = '1';

class Fancy {
    method to-mime(--> Hash) {
        %( 'text/html'    => '<i>F</i>',
           'text/plain'   => 'F',
           'image/svg+xml' => '<svg><!--f--></svg>' )
    }
    method Str { 'fancy-fallback' }
}

class Boom {
    method to-mime(--> Hash) { die 'to-mime 故意失败' }
    method Str { 'boom-fallback' }
}

class SvgOnly {
    method to-mime(--> Hash) { %('image/svg+xml' => '<svg>!</svg>') }
}

# ── ① 鸭子类型 ─────────────────────────────────────────────────────
{
    my $b = Rakuish::Display::bundle-of(Fancy.new);
    is $b.text, 'F', 'to-mime 的 text/plain 成为正文';
    is $b.html, '<i>F</i>', 'text/html 进入 Bundle';
    ok $b.has('image/svg+xml'), '未知 MIME 不丢：Bundle 认得额外档';
    is $b.render('image/svg+xml'), '<svg><!--f--></svg>',
       '额外 MIME 能原样取出';
    is $b.meta<kind>, 'mime', 'meta.kind 标明来自对象 MIME';
    is $b.meta<source>, 'value', 'meta.source 默认是值';

    my %m = $b.to-mime;
    is %m{'text/plain'}, 'F', 'to-mime 合并 text/plain';
    is %m{'image/svg+xml'}, '<svg><!--f--></svg>', 'to-mime 合并额外档';
}

# ── ② 失败降级：to-mime 抛异常不能穿出去 ──────────────────────────
{
    my $b;
    lives-ok { $b = Rakuish::Display::bundle-of(Boom.new) },
        'to-mime 抛异常不影响 bundle-of';
    is $b.text, 'boom-fallback', '降级到 .Str';
    is $b.meta<kind>, 'scalar', '降级后按标量归类';
    nok $b.has('image/svg+xml'), '失败的值没有多出来的 MIME';
}

# ── ③ 额外 MIME 透传的一致性 ───────────────────────────────────────
{
    my $b = Rakuish::Display::bundle-of(SvgOnly.new);
    ok $b.text.chars, '只有富 MIME 时也有可读的 text 兜底';
    is $b.render('image/svg+xml'), '<svg>!</svg>', 'render 取到原始载荷';
    is $b.pick(['image/svg+xml', 'text']), 'image/svg+xml', 'pick 认得额外档';
    ok $b.available.grep(* eq 'image/svg+xml').elems, 'available 列出额外档';
}

# ── ④ 包装类型 ─────────────────────────────────────────────────────
{
    my $h = HTML.new('<b>hi</b> <span>there</span>');
    is $h.Str, 'hi there', 'HTML 的终端降级去标签';
    my %hm = $h.to-mime;
    is %hm{'text/html'}, '<b>hi</b> <span>there</span>', 'HTML 保留原文';
    is %hm{'text/plain'}, 'hi there', 'HTML 同时给 text/plain';

    my $md = Markdown.new("# title\n\nbody");
    is $md.to-mime{'text/markdown'}, "# title\n\nbody", 'Markdown 原样给 markdown';
    is $md.to-mime{'text/plain'}, "# title\n\nbody", 'Markdown 的 text 就是原文';

    my $j = JSON.new({ a => 1, b => [2, 3] });
    ok $j.to-mime{'application/json'}.contains('"a"'), 'JSON 给紧凑 JSON';
    ok $j.to-mime{'text/plain'}.contains("\n"), 'JSON 的 text 是展开后的';

    # 经 Bundle 转一手，仍然能拿到 JSON 档（解析回结构化值）。
    my $jb = Rakuish::Display::bundle-of($j);
    ok $jb.to-mime{'application/json'}.contains('"a"'), 'Bundle 透传 JSON 档';
    ok $jb.text.contains('"a"'), 'JSON 的正文可读';
}

# ── ⑤ TTY 的 display() ─────────────────────────────────────────────
{
    my $s = Rakuish::REPL::Session.new;
    is $s.eval-line('40 + 2').value, 42, '基准：先有一个 `_`';
    my $r = $s.eval-line('display(HTML.new("<b>hi</b>"))');
    ok $r.ok, 'display() 求值成功';
    ok $r.out.contains('hi'), '终端立即看到降级文本';
    nok $r.out.contains('<b>'), '终端不打印 HTML 标签';
    nok $s.render($r).contains('Out['), 'display() 不产生 Out[n] 条目';
    is $s.eval-line('_').value, 42, 'display() 不改 `_`';

    # display 之后仍能正常返回值：最后一句是值时照常占 Out。
    my $r2 = $s.eval-line('display(HTML.new("<b>x</b>")); 7');
    is $r2.value, 7, 'display 之后的值仍是这一格的结果';
    ok $s.render($r2).contains('Out['), '有值的格照常渲染 Out[n]';
}

# ── ⑥ notebook：一格多条 display ───────────────────────────────────
{
    my $engine = Rakuish::Eval::Client.new(:lib($*CWD.add('lib')));
    $engine.start;
    my $sess = Rakuish::Eval::Proxy.new(:client($engine));
    $sess.set-display(True);
    my $kernel = Kernel.new(
        :session($sess),
        :audit(Rakuish::Audit.new(:default-origin<notebook>, :enabled(False))),
    );
    my $front = Rakuish::Kernel::Notebook::Frontend.new(:kernel($kernel));
    LEAVE { try { $engine.shutdown } }

    my %e = $front.handle(%(op => 'execute',
                           code => 'display(HTML.new("<b>x</b>"))',
                           display => True));
    ok %e<ok>, 'notebook display 成功';
    my @d = (%e<display><displays> // []).List;
    is @d.elems, 1, '收集到一条 display';
    is @d[0]<meta><source>, 'display', 'meta.source 标明是 display()';
    ok @d[0]<mime>{'text/html'}.contains('<b>x</b>'), 'display 带 text/html';
    is (%e<display><content> // ''), '', 'display() 本身不冒充 cell 结果';

    # cell 末尾的值仍然是 execute_result，且与 display 分开。
    my %e2 = $front.handle(%(op => 'execute',
                            code => 'display(Markdown.new("# m")); 42',
                            display => True));
    is (%e2<display><content> // ''), '42', '最后的值仍走 execute_result';
    is (%e2<display><formats> // []).List.grep(* eq 'markdown').elems, 0,
       '值是标量，不因为前面 display 过就带 markdown';
    is (%e2<display><displays> // []).List.elems, 1,
       '同一格里的 display 与结果分开收集';
}

done-testing;
