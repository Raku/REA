#!/usr/bin/env raku
use lib 'lib';
use Test;
use Rakuish::Result;
use Rakuish::Kernel;
use Rakuish::Audit;
use Rakuish::Eval;
use Rakuish::Eval::Proxy;
use Rakuish::Eval::Protocol;
use JSON::Fast;

# 41-eval-worker.t —— 求值引擎子进程（0.83.0 / ADR-0021）
#
# 这一版的核心主张只有一句：**用户代码把引擎搞死，前端不死**。
# 所以断言分四组：
#   ① 协议本身（单行 JSON、ready 帧、seq 对齐）；
#   ② 语义没退化（词法跨格、Out[n]、stdout 捕获、补全）；
#   ③ 崩溃与重启（Dead 异常、状态丢失如实告知、重启后可用）；
#   ④ `! --tty` 由父进程执行（引擎的 stdio 是管道，没有终端）。
#
# 全部用**真实子进程**，不 mock 协议 —— 这一层的风险恰恰在进程边界上。

my IO::Path $libdir = $*CWD.add('lib');

# 这一份只测**引擎边界**（协议 / 崩溃 / 重启），不测快照恢复。
# 关掉快照，崩溃后的结果文本才会走「会话状态已丢失」那一支 ——
# 快照恢复的语义由 t/42 单独覆盖，两者互不干扰。
%*ENV<RAKUISH_NO_SNAPSHOT> = '1';

# ── ① 启动与 ready ────────────────────────────────────────────────
my $client = Rakuish::Eval::Client.new(:lib($libdir));
$client.start;
ok $client.alive, '引擎启动后 alive';
ok $client.cwd.chars > 0, 'ready 帧带回 cwd';
is $client.index, 0, 'ready 帧 index=0';
nok $client.cwd.contains("\n"), 'ready 的 cwd 是单行（协议按行切帧）';

# 协议必须单行：JSON::Fast 的 to-json 默认会 pretty 成多行，
# 那样每一帧都会被父进程当成多条残缺 JSON —— 0.83 开发中踩过。
{
    my Str $frame = to-json(%( a => 1, b => [1, 2] ), :!pretty);
    nok $frame.contains("\n"), 'to-json(:!pretty) 产出单行帧';
}

# ── ② 语义没退化 ──────────────────────────────────────────────────
{
    my %r = $client.eval('1 + 1', :config(%()));
    ok ?%r<ok>, '基本求值成功';
    is %r<op>, 'eval', 'op=eval';
    is %r<index>, 1, 'Out[n] 编号从 1 开始';
    is %r<text>, 'Out[1] = 2', '渲染文本由引擎算好（含 Out[n] 标签）';
}

{
    my %a = $client.eval('my $kept = 41', :config(%()));
    my %b = $client.eval('$kept + 1', :config(%()));
    ok ?%a<ok>, '声明格成功';
    ok ?%b<ok>, '跨格引用成功（词法状态在引擎里）';
    is %b<text>, 'Out[3] = 42', '跨格变量的值正确';
}

{
    my %r = $client.eval('say "captured"', :config(%()));
    is %r<out>.trim, 'captured', '用户 say 的 stdout 进 out 字段（不混进协议流）';
    ok ?%r<ok>, 'say 格成功';
}

{
    # 失败格不推进 Out 编号（既有契约），且 err 有内容。
    my Int $before = $client.index;
    my %r = $client.eval('NoSuchNameAbc()', :config(%()));
    nok ?%r<ok>, '未定义名字是失败格';
    ok %r<err>.chars > 0, '失败格带回错误文本';
    is $client.index, $before, '失败格不推进 Out[n]（引擎侧）';
}

{
    my $items = $client.complete('say 4', 5);
    ok $items ~~ List, 'complete 返回 List';
    my $slash = $client.complete('ls doc', 6);
    ok $slash ~~ List, '路径补全不崩（返回 List 即可）';
}

# ── ④ `! --tty` 交给父进程 ───────────────────────────────────────
# 引擎的 stdin/stdout 是协议管道，`Sys.tty-exec` 在里面只会报「无 TTY」。
# 所以引擎发 tty 事件，父进程执行后回 resume —— 用一个假执行器验证往返。
{
    my Int $calls = 0;
    my $tty-client = Rakuish::Eval::Client.new(
        :lib($libdir),
        :tty-exec(-> Str $exe, @argv {
            ++$calls;
            Rakuish::Result::Result.new(
                :ok, :code(0), :op<tty-exec>,
                :out("FAKE-TTY {$exe} {@argv.join('|')}"));
        }),
    );
    $tty-client.start;
    my %r = $tty-client.eval('! --tty myprog a b', :config(%()));
    is $calls, 1, '父进程的 TTY 执行器被调用一次';
    ok ?%r<ok>, 'tty 往返后结果成功';
    is %r<out>.trim, 'FAKE-TTY myprog a|b', 'argv 原样传到父进程（不拼 shell 字符串）';

    # 没注册执行器时必须**明确失败**，不能静默当成成功。
    my $bare = Rakuish::Eval::Client.new(:lib($libdir));
    $bare.start;
    my %r2 = $bare.eval('! --tty myprog', :config(%()));
    nok ?%r2<ok>, '未注册 TTY 执行器时该格失败';
    ok %r2<err>.contains('TTY'), '错误说明是 TTY 不可用';
    $bare.shutdown;
    $tty-client.shutdown;
}

# ── ③ 崩溃与重启 ─────────────────────────────────────────────────
# `exit` 整行会被 Session 拦成 op=exit（不真退出），所以用 `exit; 1`
# 让引擎在 EVAL 里真的调 exit —— 这正是用户手滑能造成的效果。
{
    my $boom = Rakuish::Eval::Client.new(:lib($libdir));
    $boom.start;
    ok $boom.alive, '崩溃前 alive';

    my Bool $died = False;
    {
        CATCH {
            default {
                $died = $_ ~~ X::Rakuish::Eval::Dead;
            }
        }
        $boom.eval('exit; 1', :config(%()));
    }
    ok $died, '引擎内 exit 让请求抛 X::Rakuish::Eval::Dead（不是把父进程带走）';
    nok $boom.alive, '崩溃后 alive=False';

    lives-ok { $boom.restart }, 'restart 能重建引擎';
    ok $boom.alive, '重启后 alive';
    is $boom.restarts, 1, '重启计数 +1';

    my %r = $boom.eval('6 * 7', :config(%()));
    ok ?%r<ok>, '重启后可以继续求值';
    is %r<text>, 'Out[1] = 42', '重启后 Out[n] 重新从 1 开始（状态确实没了）';
    $boom.shutdown;
}

# Proxy：崩溃要变成一条**如实**的结果，而不是抛给前端。
{
    my $pc = Rakuish::Eval::Client.new(:lib($libdir));
    $pc.start;
    my $proxy = Rakuish::Eval::Proxy.new(:client($pc));
    my $kernel = Rakuish::Kernel.new(
        :session($proxy), :audit(Rakuish::Audit.new));

    my $ok1 = $kernel.execute(Request.new(:kind<source>, :payload('my $x = 7')));
    ok $ok1.ok, 'Proxy 正常格成功';
    is $proxy.render($ok1), 'Out[1] = 7', 'Proxy.render 直接返回引擎渲染的文本';

    my $boom = $kernel.execute(Request.new(:kind<source>, :payload('exit; 1')));
    nok $boom.ok, '崩溃格是失败结果';
    is $boom.op, 'engine-restart', 'op 标成 engine-restart（前端据此换样式）';
    is $boom.code, 500, '崩溃格 code=500';
    like $proxy.render($boom), /'已自动重启'/, '结果文本说明已自动重启';
    like $proxy.render($boom), /'会话状态已丢失'/, '没有快照时如实说明状态丢失（有快照的分支见 t/42）';
    is $kernel.trail.elems, 2, '崩溃也被审计记一条（审计不因崩溃漏记）';

    my $after = $kernel.execute(Request.new(:kind<source>, :payload('1 + 1')));
    ok $after.ok, '重启后同一 Kernel 继续可用';
    is $proxy.render($after), 'Out[1] = 2', '重启后编号重新开始';

    $pc.shutdown;
}

# ── ⑥ tty 必须由父进程告知（0.87.0）──────────────────────────────
# 引擎的 `$*OUT` 是协议管道，自己探测恒 False。不传就会让 `clear` 静默、
# shell 彩色全灭 —— 这正是 0.83 引入的回归，用户报了「clear 不清屏」。
{
    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $px = Rakuish::Eval::Proxy.new(:client($c));

    is $px.eval-line('clear').out, '', '默认（非 TTY）clear 无输出';
    $px.set-tty(True);
    is $px.eval-line('clear').out, "\e[2J\e[H", '父进程说 TTY，引擎的 clear 才发 ANSI';
    $px.set-tty(False);
    is $px.eval-line('clear').out, '', '关掉后又无输出（tty 每格同步，不是一次性）';

    $c.shutdown;
}

# ── ⑦ 终端尺寸也要过协议（0.88.0 / V-227）─────────────────────────
# 引擎自己查不到宽度（stdout 是管道，COLUMNS 也不可靠），所以尺寸和 tty
# 一样由父进程下发。这里验的是「下发生效」而不是具体数字。
{
    my $d = $*TMPDIR.add("worker-width-{$*PID}");
    $d.mkdir unless $d.e;
    $d.add("file-{$_}.txt").spurt('x') for 1..24;

    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $px = Rakuish::Eval::Proxy.new(:client($c));
    $px.set-tty(True);
    $px.eval-line("cd " ~ $d.Str.subst('\\', '/', :g));

    my &lines = -> Int $w {
        $px.set-size(:width($w), :height(30));
        my $r = $px.eval-line("dir('.').list");
        $px.render($r).lines.grep({ .chars && !.contains('Out[') });
    };

    my @narrow = lines(40);
    my @wide   = lines(120);
    ok @narrow.elems > @wide.elems,
       "尺寸过协议：40 列 {@narrow.elems} 行 > 120 列 {@wide.elems} 行";
    ok @narrow.map(*.chars).max <= 40, '窄宽度下没有超宽行';

    $c.shutdown;
    @narrow = ();
    @wide = ();
}

# ── ⑧ 引擎里**不许**做分页 / 流式输出（0.89.0 / V-228）──────────
# 引擎的 stdout 是协议管道：分页器往里写会把表格文本插进 JSON 流，
# 再读 stdin 会把下一个请求当「按键」吃掉 —— 实测 `explore` 之后整个
# REPL 卡死（0.87 引入 tty 注入后触发）。判据是 live-out 而不是 tty。
{
    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $px = Rakuish::Eval::Proxy.new(:client($c));
    $px.set-tty(True);                 # 用户面前确实有终端
    ok $px.tty, '前置：前端确实告诉过引擎「有终端」';

    $px.eval-line('my $big = Rakuish::Data::Table.from-rows((1..60).map({ %(n => $_) }))');
    $px.eval-line('$big');             # 让 Table 成为上一格结果
    my $r = $px.eval-line('explore');
    ok $r.ok, 'explore 成功返回（没有卡在分页）';
    my Str $rendered = $px.render($r);
    ok $rendered.contains('60'), '大表整份返回（60 行都在）';

    my $after = $px.eval-line('1 + 2');
    ok $after.ok, 'explore 之后协议仍然健康（这是回归的核心）';
    like $px.render($after), /'= 3'/, '下一格拿到正确结果';

    $c.shutdown;
}

# ── ⑨ `ls -R` 的流式分支同样不能写协议流（V-228）───────────────
{
    my $d = $*TMPDIR.add("rec-{$*PID}");
    my $sub = $d.add('sub');
    $sub.mkdir unless $sub.e;
    $d.add('top.txt').spurt('t');
    $sub.add('inner.txt').spurt('i');

    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $px = Rakuish::Eval::Proxy.new(:client($c));
    $px.set-tty(True);
    $px.eval-line("cd " ~ $d.Str.subst('\\', '/', :g));

    my $r = $px.eval-line('ls -R');
    my Str $text = $r.out.chars ?? $r.out !! $px.render($r);
    ok $text.contains('inner.txt'), 'ls -R 的内容通过结果返回（不是写进协议流）';
    ok $px.eval-line('1 + 1').ok, 'ls -R 之后协议仍然健康';

    $c.shutdown;
}

# ── ⑤ 引擎退出要能被显式关闭 ────────────────────────────────────
{
    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my Int $pid = await $c.proc.pid;   # Proc::Async.pid 是 Promise
    ok $pid > 0, '子进程有 pid';
    $c.shutdown;
    nok $c.alive, 'shutdown 后 alive=False';
}

# ── ⑥ 续行格不展示 Result 字段（跨行编辑观感回归）────────────────
# rendered='' 有两种含义：more/exit/skip 是「刻意不展示」，通信失败兜底
# 是「没渲染」。Proxy.render 不能对空串一律 fallback 到 text —— 那样
# 续行会把 ok/op/code dump 到屏幕（ok: true / op: more / code: 0）。
{
    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $px = Rakuish::Eval::Proxy.new(:client($c));

    my $r = $px.eval-line('my $a = [ 1,');
    is $r.op, 'more', '不完整输入返回 op=more';
    is $px.render($r), '', '续行格渲染为空串（不 dump Result 字段）';
    nok $px.render($r).contains('ok:'), '续行不出现 ok: 字段';
    nok $px.render($r).contains('op:'), '续行不出现 op: 字段';

    # 喂完让它闭合，确认后续格仍健康
    ok $px.eval-line('2,').op eq 'more', '第二行仍是续行';
    ok $px.eval-line('];').ok, '闭合行求值成功';
    ok $px.render($px.eval-line('$a')).contains('[1 2]'), '闭合后能取到数组（Raku .gist 空格分隔）';
    $c.shutdown;
}

# ── ⑦ 安静成功格不 dump Result 字段（0.98.2，Proxy.render 只信 rendered）─
# cd / mkdir 这类 shell 命令 out=''、value 不展示，引擎 rendered=''。
# 0.97.1 之前 Proxy.render 对空串 fallback 到 render('text')，
# 屏幕上会多出 "ok: true / op: mkdir / code: 0"。
{
    my $c = Rakuish::Eval::Client.new(:lib($libdir));
    $c.start;
    my $px = Rakuish::Eval::Proxy.new(:client($c));
    my $r = $px.eval-line('mkdir tmp/r41-' ~ $*PID ~ '-' ~ now.Int);
    is $px.render($r), '', '安静成功格渲染为空串（不 dump ok/op/code）';
    nok $px.render($r).contains('ok:'), '安静成功不出现 ok: 字段';
    nok $px.render($r).contains('op:'), '安静成功不出现 op: 字段';
    $c.shutdown;
}

# ── ⑤ 协议契约（0.133.0 / ADR-0051）────────────────────────────────
# 以前协议没有版本、没有 schema：字段改名后 Client 用 `// 默认值` 兜底，
# 前端拿到空字符串/0，不抛异常也不报错。这里把契约本身钉住（纯函数 +
# 真引擎的握手结果），协议版本升级时这些断言会一起要求改。
{
    my constant P = Rakuish::Eval::Protocol;

    is P::PROTOCOL-VERSION, 2, '协议版本常量为 2（v2：错误详情走 error_info）';
    is $client.protocol, P::PROTOCOL-VERSION, '真引擎握手协商到同一版本';

    # ready 必须自报版本。旧引擎（0.134 及以前）没有这个字段或版本不符 ——
    # 升级时残留的进程会命中这条，报错要可操作，而不是「字段读到 Any」。
    ok P::check-ready(%(event => 'ready', protocol => P::PROTOCOL-VERSION)).defined,
        'ready 合法则通过';
    throws-like { P::check-ready(%(event => 'ready')) },
        X::Rakuish::Protocol, 'ready 缺 protocol → Protocol 异常';
    throws-like { P::check-ready(%(event => 'ready', protocol => 99)) },
        X::Rakuish::Protocol, 'ready 版本不符 → Protocol 异常';

    # result 帧：构造/解构都走 EvalReply，往返不丢字段。
    my %args =
        seq      => 1, ok => True, code => 0, text => 'T', out => 'O', err => '',
        index    => 2, cwd => '/w', config => %(a => 1), elapsed => '0.1s',
        exit     => False, 'exit-code' => 0,
        display  => %(format => 'text'),
        displays => [%(format => 'text')],
    ;
    my %frame = P::EvalReply.new(|%args).to-hash;
    is %frame<event>, 'result', 'to-hash 带 event=result';
    my $back = P::EvalReply.from-hash(%frame);
    is $back.text, 'T', 'from-hash 往返 text';
    is $back.display<format>, 'text', 'display 往返';
    is $back.displays.List.elems, 1, 'displays 往返';
    is $back.exit-code, 0, '带连字符的字段（exit-code）往返';

    # 缺字段 → 抛（不再静默读成 Any）；未知终帧同理。
    throws-like { P::EvalReply.from-hash(%(seq => 1, ok => True)) },
        X::Rakuish::Protocol, 'result 缺字段 → Protocol 异常';
    throws-like { P::check-frame(%(seq => 1, event => 'no-such-frame')) },
        X::Rakuish::Protocol, '未知终帧 → Protocol 异常';

    # 引擎自报的 error 帧折成失败 result：以前它会被当普通终帧返回，
    # Proxy 读不到 ok/err，前端显示一个空结果（静默坏掉）。
    my %e = P::check-frame(%(seq => 1, event => 'error', message => 'boom'));
    is %e<event>, 'result', 'error 帧 → result 形状';
    nok %e<ok>, 'error 帧 ok=False';
    like %e<err>, /boom/, 'error 消息进 err';

    # 真引擎的失败格：错误详情走独立 error_info 帧（v2），result 帧不再带它。
    my %bad = P::check-frame($client.eval('die "contract"', :!tty));
    nok %bad<ok>, '真引擎失败格 ok=False';
    nok %bad<ename>:exists, 'result 终帧不再带 ename（v2 净化）';
    ok ($client.last-error-info<ename> // '').chars > 0,
        'error_info 帧带 ename';
    ok ($client.last-error-info<traceback> // ()).List.elems > 0,
        'error_info 帧带 traceback 帧列表';
}

$client.shutdown;
done-testing;
