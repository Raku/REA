use Test;

my $cwd   = $*CWD;
my @lines = 'META6.json'.IO.lines;

# lib 下所有模块文件（递归，相对路径）
#
# ⚠ 路径分隔符必须归一成 `/`：META6 provides 里登记的是**正斜杠**（规范写法，
#   zef 就是按它找文件），而 Windows 的 `.relative.Str` 给的是反斜杠
#   ⇒ 不归一会把 21 个模块全部误报成「未登记」。归一后两平台断言同一件事。
sub meta-path($p --> Str) {
    $p.Str.subst('\\', '/', :g)
}
my @files;
sub walk(IO::Path:D $d) {
    for $d.dir {
        when .d     { walk($_) }
        when .f     { @files.push(meta-path(.relative($cwd))) if .extension eq 'rakumod' }
    }
}
walk($cwd.add('lib'));
@files = @files.sort;

# META6 provides 里登记的路径
my @parts  = @lines.map({ .split('"')[3] });
my @listed = @parts.grep({ .defined && .ends-with('.rakumod') });
@listed = @listed.sort;

is @files.elems, @listed.elems,
    "META6 provides 条目数({@listed.elems}) 应等于 lib 下模块文件数({@files.elems})";

my %have = @listed.Set;
my @missing = @files.grep({ !%have{$_} });
is @missing.join(','), '',
    "以下模块未登记进 META6 provides（zef 安装后会缺文件）: {@missing.join(', ')}";

# 0.106.1：入口逻辑移到 lib/Rakuish/CLI.rakumod（bin 只做 require）。
# 版本回退常量跟着走；两处版本必须与 META6.json 一致，防止安装后 --version 漂移。
my $metav = ~@lines.grep({ .contains('"version"') })[0].match(/ '"version"' \s* ':' \s* '"' (<-["]>+) '"' /)[0];
my $cliv  = ~'lib/Rakuish/CLI.rakumod'.IO.slurp.match(/ 'FALLBACK_VERSION' \s* '=' \s* "'" (<-["']>+) "'" /)[0];
is $cliv, $metav, "Rakuish::CLI 的 FALLBACK_VERSION({$cliv}) 与 META6 版本({$metav}) 一致";

# `--version` 快路径不加载 CLI，它自带一份回退常量，同样不能漂。
my $binv = ~'bin/rakuish'.IO.slurp.match(/ 'my Str $v' \s* '=' \s* "'" (<-["']>+) "'" /)[0];
is $binv, $metav, "bin/rakuish 的 --version 回退常量({$binv}) 与 META6 版本({$metav}) 一致";

# 0.109.0：notebook 适配层要对外自报版本（kernel_info），同一份约束。
my $ksrc  = 'lib/Rakuish/Kernel/Notebook.rakumod'.IO.slurp;
my $kernv = ~$ksrc.match(/ 'KERNEL-VERSION' \s* '=' \s* "'" (<-["']>+) "'" /)[0];
is $kernv, $metav, "Notebook 的 KERNEL-VERSION({$kernv}) 与 META6 版本({$metav}) 一致";

# ── 文档守卫（0.130.0 / 评审 P3 3.2）───────────────────────────────────
# 此前 5 份文档的版本/ADR 数互相矛盾（README 0.122.1、HANDOFF 0.122.1、
# MANUAL 0.120.1、ADR-INDEX 0.120.1/44 条，而 META6 是 0.122.3 / 47 条）——
# 「版本一致」只靠人肉同步，必然再次漂移。这里把它变成断言。
my Str $readme   = 'README.md'.IO.slurp;
my Str $handoff  = 'HANDOFF.md'.IO.slurp;
my Str $manual   = 'docs/MANUAL.md'.IO.slurp;
my Str $adrIndex = 'docs/ADR-INDEX.md'.IO.slurp;

# ADR 文件数是唯一事实源：ADR-INDEX 的「条目数」「N 份 ADR」与 README 的说法
# 都必须等于它，不允许各写各的。
my Int $adr-count = 'docs'.IO.dir.grep({
    .f && .basename ~~ /^ 'ADR-' \d ** 4 '-' .* '.md' $/
}).elems;
ok $adr-count > 0, "扫到 {$adr-count} 份 ADR 文件（防空跑）";

# 取「第一个捕获」，取不到就返回空串：这样断言失败时给的是「漂了」，不是崩溃。
sub grab(Str $text, Regex $re --> Str) {
    my $m = $text.match($re);
    $m.defined ?? ~$m[0] !! '';
}

is grab($readme, / '当前版本' \s* '：' \s* '**`' (<[\d.]>+) '`**' /), $metav,
    'README 声明的当前版本与 META6 一致';
is grab($manual, / '适用版本' \s* '：' \s* '**' (<[\d.]>+) '**' /), $metav,
    'MANUAL 的适用版本与 META6 一致';
is grab($handoff, / '- **版本**：`' (<[\d.]>+) '`' /), $metav,
    'HANDOFF 的版本与 META6 一致';
is grab($adrIndex, / ^ '#' ' ADR 决策索引（' (<[\d.]>+) '）' /), $metav,
    'ADR-INDEX 标题里的版本与 META6 一致';

is grab($adrIndex, / '条目数：' (\d+) /), $adr-count.Str,
    "ADR-INDEX 的条目数应为实际 ADR 文件数({$adr-count})";
is grab($adrIndex, / '仓库内 ' (\d+) ' 份 ADR' /), $adr-count.Str,
    'ADR-INDEX 正文声明的 ADR 份数与实际一致';
is grab($readme, / (\d+) ' 份 ADR 的决策索引' /), $adr-count.Str,
    'README 提到的 ADR 份数与实际一致';

# 依赖（评审 P3 3.3）：README 的依赖段漏过 Arrow::IPC（META6 实际 4 个）。
# 只查「名字出现过」，版本约束不在这里管。
my Str $meta = 'META6.json'.IO.slurp;
my Int $dstart = $meta.index('"depends"') // 0;
my Str $tail = $meta.substr($dstart);
my Str $dep-block = $tail.substr(0, $tail.index(']') // $tail.chars);
my @deps = $dep-block.comb(/ '"' (<-["]>+) '"' /, :match)
    .map({ ~($_.[0]) })
    .map({ $_.subst(/ ':' ['ver' | 'auth' | 'api'] '<' (.*?) '>' /, '') });
@deps.shift;     # 第一个匹配是键名 "depends" 自己
ok @deps.elems > 0, "META6 的 depends 解析出 {@deps.elems} 条（防空跑）";
for @deps -> $dep {
    ok $readme.contains("`{$dep}`"), "README 的依赖段提到 {$dep}";
}

# ── 变更日志守卫（0.141.0 / 评审 P3 3.4 + 3.5）─────────────────────────────
# 评审说「46 天 93 个 tag，用户无法跟踪」，且仓库一直没有 CHANGELOG 与英文 README。
# 两者都补上之后，同样的漂移问题会重演：版本升了却忘了写日志、README 互链断掉。
# 这里把「每版必有一节日志」和「中英 README 互相指得到」都变成断言。
my Str $changelog = 'CHANGELOG.md'.IO.slurp;
my Str $readmeEn  = 'README.en.md'.IO.slurp;

# 版本节标题形如 `## 0.140.0 — 2026-11-26`
my @vheads = $changelog.lines.grep({ $_ ~~ /^ '##' \s+ <[\d.]>+ \s+ '—' \s+ \d+ '-' \d+ '-' \d+ $/ }).List;
ok @vheads.elems > 0, "CHANGELOG 里解析出 {@vheads.elems} 个版本节（防空跑）";

# 最新一版必须是当前版本，且必须有日期：发版与写日志不能只做一半
my Str $first = @vheads.elems ?? ~@vheads[0] !! '';
my Str $first-v = $first ~~ /^ '##' \s+ (<[\d.]>+) \s+ / ?? ~$0 !! '';
is $first-v, $metav, "CHANGELOG 的第一节是当前版本（读出「{$first}」）";
ok $first ~~ / '—' \s+ \d+ '-' \d+ '-' \d+ $/, 'CHANGELOG 的最新一节带日期';

# 更早的 tag 只保留 git log；本文件从 0.123.0 起逐版本记录
ok $changelog.contains('## 发布节奏'), 'CHANGELOG 有「发布节奏」一节';
ok $changelog.contains('Keep a Changelog'), 'CHANGELOG 说明了自己遵循的格式';

# 英文 README（P3.5）：至少要有入口与指向真值的链接，不能是孤立文件
ok 'README.en.md'.IO.f, 'README.en.md 存在';
ok $readmeEn.contains('[`CHANGELOG.md`](CHANGELOG.md)'), '英文 README 指向 CHANGELOG';
ok $readmeEn.contains('[`docs/MANUAL.md`](docs/MANUAL.md)'), '英文 README 指向 MANUAL';
ok $readmeEn.contains('[`README.md`](README.md)'), '英文 README 指向中文 README';
ok $readmeEn.contains('English table of contents'), '英文 README 有文档索引（English table of contents）';
ok $readme.contains('[`README.en.md`](README.en.md)'), '中文 README 指向英文 README';
ok $readme.contains('[`CHANGELOG.md`](CHANGELOG.md)'), '中文 README 指向 CHANGELOG';
ok $manual.contains('本文是使用手册'), 'MANUAL 仍自称使用手册（英文 README 的指向不是空话）';

done-testing;
