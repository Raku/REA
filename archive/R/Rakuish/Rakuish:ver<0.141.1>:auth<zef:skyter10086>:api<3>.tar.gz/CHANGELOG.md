# Rakuish 变更日志（CHANGELOG）

本文件按**版本**记录对外可见的变化：新增命令 / API、行为变更、缺陷修复，
以及对应的规格条款（SPEC `V-nnn`）与决策记录（`docs/ADR-####`）。
每个版本都有 annotated tag（`v0.x.y`），提交级细节用 `git log v0.122.3..v0.140.0`。

格式遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 的简化版：
`新增` / `变更` / `修复` / `文档`。**没有**「未发布」区段——
版本号只在 `META6.json` 一处为准，发版同时打 tag。

> 记录范围：本文件从 **0.123.0** 起逐版本记录。更早的版本（0.1 起的 90 余个 tag）
> 只保留 `git tag` 与 `git log`，不在此重复誊写——它们由 0.123.0 之前的
> `docs/AUDIT-FIXES-*.md` 与 `docs/ROADMAP-2026-11-11.md` 覆盖。

---

## 0.141.1 — 2026-11-26

跨平台测试修复：Linux 安装与「PATH 上有 dir.exe」的 Windows（V-331 / V-332）

**修复**
- `t/10` 的「`env-var` 对大小写不敏感」无条件跑了：大小写不敏感是 **Windows 专属**
  口径（V-331 明写「POSIX 行为不变」），Linux 上 `env-var('path')` 本来就该是空串。
  0.136.1 的 Linux `zef install .` 就红在这一条：期望整条 PATH，实得 `''`。
  现在按平台分支——Windows 断「大小写不敏感」，POSIX 断「不跨大小写偷值
  （`path` 与 `PATH` 各自独立）」。
- `t/10` 的「`! dir` 能列当前目录」假定 PATH 上没有真 `dir.exe`。有的机器
  （Git for Windows / MSYS 的 coreutils）有，按 ADR-0049 §2 的「真 exe 优先」
  回落不参与，于是断言的前提本身不成立（0.140.0 在一台这样的机器上红）。
  现在先问实现「这次会回落吗」：会回落 → 断「交给 `cmd.exe`」+ 列出 `a.txt`；
  不会 → 断「spawn 的就是 `dir`、argv 原样两项」。失败消息会带出 `code` / `err` / `out`。

**文档**
- SPEC §3.60 V-331 / §3.61 V-332 补记两条平台分支的理由与这次的实测红。

## 0.141.0 — 2026-11-26

文档入口：变更日志 + 英文 README，并把「不漂移」变成断言（V-345）

**新增**
- `CHANGELOG.md`（本文件）：从 0.123.0 起逐版本记录新增 / 变更 / 修复 / 文档，
  标出对应的 SPEC 条款与 ADR；更早的版本只指 `git tag` / `git log`（评审 P3.4：
  「46 天 93 个 tag，用户无法跟踪」）。
- `README.en.md`：英文入口，含安装、快速开始、两种输入、核心 API、
  **英文的 MANUAL 目录**（逐节指向 `docs/MANUAL.md` 的行号）、测试、明确不支持、
  平台、许可（评审 P3.5 的最低要求）。
- `SPEC.md` §3.74 V-345：文档契约——每版必须有一节日志、最新一节必须等于
  `META6.json` 的版本且带日期、中英 README 必须互链。

**变更**
- 中文 `README.md` 增加两行入口：英文 README 与 CHANGELOG。

**测试 / 文档**
- `t/51` 从 18 条扩到 **31 条**：CHANGELOG 有版本节 / 第一节等于当前版本 / 带日期 /
  有「发布节奏」节 / 说明了格式约定 / 英文 README 存在且三条链接在 / 有英文目录 /
  中文 README 反向链接 / MANUAL 仍自称使用手册。
- 英文 README 刻意**不写版本号**：版本号唯一来源是 META6，四处已由 `t/51` 守着，
  不给自己多加一个要同步的地方。

## 0.140.0 — 2026-11-26

错误分级 `errors short|full` + 历史预填 `recall [n]`（V-344 / [ADR-0054](docs/ADR-0054-error-modes-and-recall.md)）

**新增**
- 会话命令 `errors [short|full]`：失败格头一行给出**类型**——编译错误 / 运行错误 /
  被拒绝，并附位置「第 N 格第 M 行」。`full` 额外附完整回放帧；`short` 是默认。
- 会话命令 `recall [n]`：把历史第 n 条（负数从末尾算，默认上一条）放进预填缓冲
  并回显，**不执行**；`take-prefill()` 读一次即清、且只活到下一格。与 `rerun` 共用编号。

**变更**
- 失败格的 `err` 文本统一变成 `类型: 消息（位置）`。判据是异常类型，不看消息文本；
  `X::Rakuish` 族用包含判定（实际类名带 `Rakuish::Result::` 前缀）。
- 位置只从 `EVAL_k` 帧折算（`行 = 帧行 - (prelude 行数 + 1)`），折算不出有效行只报格号，
  不硬造行号，也不把驱动 / 调用方的文件行报给用户。

**修复**
- `errors full` 在 `repl.trace = False` 的会话里原本只有头没有回放帧（记录异常的判据
  只看 `$!bt`），已按 `error-mode` 放宽。

**测试 / 文档**
- 新增 `t/82-errors-recall.t`（88 断言）；全量 **78 文件 / 3705 断言**。
- SPEC §3.73 V-344；ADR-0054；README / MANUAL / ADR-INDEX（54 份）同步。

## 0.139.0 — 2026-11-26

跨会话变量库 `store`（V-343 / [ADR-0053](docs/ADR-0053-cross-session-store.md)）

**新增**
- `store $x @rows %cfg`：按名保存到 `$*HOME/.rakuish/store.json`（`RAKUISH_STORE`
  或 `store -f PATH` 可改）；`store -l` 列库、`store -r x` 读回、`store -d x` 删除、
  `store --clear` 清空。
- 新模块 `lib/Rakuish/Store.rakumod`（信封版本 / 原子写 / 坏文件回落到空库）。
- 条目带**声明源码**，所以用户类实例读回时能重建类型（`$p.show` 仍可用）。

**变更**
- 不可保存的值（闭包 / 句柄 / 超上限）**当场拒绝并给理由**，与快照的「标记失效」
  相反——变量库是显式动作，静默丢弃不可接受。

**测试 / 文档**
- 新增 `t/81-store.t`（54 断言）；全量 **77 文件 / 3617 断言**。
- SPEC §3.72 V-343；ADR-0053；MANUAL 新增「跨会话变量库」；provides 46→47。

## 0.138.0 — 2026-11-26

块输入 `paste`（V-342 / [ADR-0052](docs/ADR-0052-block-input-paste.md)）

**新增**
- 会话命令 `paste`：读 stdin 到一行恰为 `--` 或 EOF，整段源码当**一个格**执行；
  只产生一个 `Out[n]`、一条 history、一条 `cells` 记录。

**变更**
- `Session` 新增可注入的 `read-line`（不是 `input-handler`：后者是协议通道），
  测试与前端可替换 stdin。
- vi 模式下 bracketed paste 仍会被当键吞掉的说法，MANUAL 改为指向 `paste` 命令。

**修复**
- 四种拒绝面各有明确文案：空块 / 参数 / 源码不完整 / 引擎模式（stdin 是协议流）。

**测试 / 文档**
- `t/05` +15 断言；全量 **76 文件 / 3562 断言**。SPEC §3.71 V-342；MANUAL 新增章节。

## 0.137.0 — 2026-11-26

数据层：`to-text` 可选行 + CSV 补 `bool` / `datetime`（V-341）

**新增**
- `Table.to-text(:index, :dtype, :shape)`：行号（表内 0 基，`limit`/`offset` 后重数）、
  `dtypes: a int, b str`、`(N rows × M cols)` 三行可选；默认全关，老输出逐字节不变。
- `from-csv-data` 逐列推断补齐 `bool`（只认 `true`/`false`）与 `datetime`
  （`YYYY-MM-DD hh:mm:ss`，且 `DateTime.new` 能解析才认）。

**变更**
- 截断提示移出表头，改到数据行之后、`dtypes`/`shape` 之前；`shape` 报整表行数。
- 推断**只改类型标签**，单元格原值一律保留。

**测试 / 文档**
- `t/11` 48→71 断言；全量 **76 文件 / 3544 断言**。SPEC §3.70 V-341。

## 0.136.1 — 2026-11-26

修复 `prompt()` 把引擎卡死（V-340 / ADR-0051 v3 + ADR-0037 §11）

**修复**
- 引擎里 `prompt()` 无限递归：`read-msg` 读的是动态 `$*IN`，而格内 `$*IN` 已被换成
  转发到 `input-handler` 的替身，于是「handler 发帧 → 再读协议 → 又进 handler」。
  现在协议流在 `serve-engine()` 入口抓成模块级 `$PROTO-IN`/`$PROTO-OUT`，
  用户代码对 `$*IN`/`$*OUT` 的替换影响不到它（ttc / notebook 两种入口都覆盖）。
- 格内 `emit` 原本写进该格的捕获缓冲，帧到不了父进程——同上修复。
- notebook 主循环的读端线程化：`ops` Channel 由读线程投递，`input_reply` 在读线程
  直投 `$input-reply`，主循环不再被读阻塞。
- `prompt` 文案现在真的到 handler（Rakudo 的 `prompt` 会先 `print` 再读，之前文案被
  `print` 进捕获缓冲，handler 收到空串）。

**测试 / 文档**
- `t/05` +5、`t/65` 第 12 组 +7；全量 **76 文件 / 3521 断言**。
- SPEC §3.69 V-340；ADR-0051 v3、ADR-0037 §11。
- 另：补齐 0.130.0–0.136.0 共 8 个漏打的 annotated tag（此前最新只到 v0.129.0）。

## 0.136.0 — 2026-11-26

Notebook `serve()` 传输回调化（V-339 / ADR-0037 §10）

**变更**
- `Kernel::Notebook.serve(:$lib, :&read-line, :&write-frame)`：传输由调用方注入，
  `serve` 不再自己抓 `$*IN`/`$*OUT`；写帧回调收到一帧 JSON 本体（不带换行）。
- emit 收进 `serve` 闭包并包 try，坏帧不再掀掉主循环。

**测试**
- `t/65` 新增第 11 组：内存闭包驱动整个 serve 生命周期。

## 0.135.0 — 2026-11-26

错误详情走独立 `error_info` 帧（V-338 / ADR-0051 v2）

**变更**
- `PROTOCOL-VERSION` 1→2：失败格不再把 `ename`/`evalue`/`traceback` 塞进 result 终帧，
  改为先发一帧 `error_info` 中间帧；`EvalReply` 与 `Rakuish::Result` 都删掉这三个字段。
- Client 把 error_info 收进 `last-error-info`；Proxy 透传；Notebook 前端拼回 Jupyter
  `error` 消息（`ename`/`evalue`/`traceback` 语义不变）。

## 0.134.0 — 2026-11-26

审计四项（V-336 / V-337）

**修复 / 变更**
- `open-data(:max-rows)`：CSV / Parquet 读入口把上限下推给引擎，物化前截断；
  没有默认值，避免静默截断。
- `Sys::FS` 的复制 / 写入上限：`cp(:max-bytes)` 可单次抬高，条目上限扫描**边数边失败**，
  报错文案给出两条退路（`Sys.new(:max-bytes/:max-entries)`）。
- SQL 桥（`Rakuish::Data::Duck`）去掉临时文件交换：改为 `CREATE TABLE` DDL +
  Duckula Appender 直插（50k 行稳态 ~1.5 s；>int64 现在显式报错而不是溢出成负数）。
- `Table` 属性私有化 + 只读视图 `columns` / `rows` / `types`（`types` 返回克隆，
  防止外部改内部状态）。

**文档**
- SPEC §3.65 V-336、§3.66 V-337；ADR-0043 §6/§7；`docs/analysis/README.md` 给 8 份
  同行分析文档标注「已落地 / 已过期」。

## 0.133.0 — 2026-11-26

引擎协议契约（V-335 / [ADR-0051](docs/ADR-0051-engine-protocol-contract.md)）

**新增**
- `lib/Rakuish/Eval/Protocol.rakumod`：`PROTOCOL-VERSION`（独立于 META6 `api`）、
  `EvalReply`（`to-hash`/`from-hash`）、`FRAME-FIELDS`、`check-ready` / `check-frame`。
- 引擎 ready 帧带 `protocol`；握不上就明确报「残留旧引擎进程 / 协议版本不符」。
- 帧校验失败抛 `X::Rakuish::Protocol`（带原始帧 JSON）；`event=error` 折叠成只含
  `seq/event/ok/op/code/text/out/err` 的失败结果帧，避免 Proxy 的默认值把 `Out[n]` 归零。

## 0.132.1 — 2026-11-26

**修复**：裸 `enum` / `subset` 声明把整个会话锁死（V-334）
- `!scan-cell` 的「给裸类型声明补 `my`」名单只有 `class|role|grammar`，漏了
  `enum|subset|constant`，于是裸 enum/subset 进了 GLOBAL，之后每格都报
  `Redeclaration of symbol` / `Invalid typename`。
- 名单补齐；读旧快照时同样补 `my`，所以老会话文件不会把新版本锁死。

## 0.132.0 — 2026-11-26

§4.9 的四项 IPython 差距（CSV 类型推断、`help()` 列表、错误回放、notebook）
- `t/18` 增枚举 / 子集 / 常量跨格与新会话可用性断言（0.132.1 的回归就在这组里）。

## 0.131.0 — 2026-11-25

长会话前奏按需裁剪（V-333 / [ADR-0050](docs/ADR-0050-eval-prelude-slicing.md)）
- 每格不再无条件重放全部别名与缓存声明，只挑「本格点名」的，并沿源码做传递闭包。
- 40 声明会话每格 48–70 ms → 9–13 ms；`use` 与运算符类声明仍总是重放。

## 0.130.0 — 2026-11-25

Windows 的 cmd 内建命令（V-332 / [ADR-0049](docs/ADR-0049-windows-cmd-builtins.md)）
- `! echo hi` / `! dir /b` 这类磁盘上没有同名 exe 的命令，改走
  `cmd.exe /d /c`（固定白名单 + 逐个 `^` 转义）：`&`/`|`/`>` 仍是字面参数、
  `%VAR%` 不展开；`Sys.exec` 与 `--tty` 不走这层回落。
- `t/51` 扩到 18 断言：README / MANUAL / HANDOFF / ADR-INDEX 的版本必须与 META6 一致，
  ADR 条目数必须等于真实文件数，META6 的每个依赖都要在 README 里露面。

## 0.129.1 — 2026-11-25

**修复**：Windows 上 `PATH` / `HOME` 的大小写（V-331）
- Windows 进程环境里的键是 `Path` 而不是 `PATH`，Rakudo 的 `%*ENV` 大小写敏感：
  `%*ENV<PATH>` 为 Nil → `which`、PATH 补全全部空。新增 `env-var()` 做大小写无关查找，
  `get-env`/`set-env`/`unset-env` 也按同一口径解析键。
- Windows 没有 `HOME`（只有 `USERPROFILE`），会话 env 缺 `HOME` 时从 `$*HOME` 补。

## 0.129.0 — 2026-11-25

§4.9 e / g / i：`doc` 走内置例程、`Table` 的 `head`/`tail`、`html` 渲染。

## 0.128.0 — 2026-11-25

§4.7 会话名字补全：变量 / sub / class / 模块名。

## 0.127.0 — 2026-11-25

混合语句格里的 `sub` 与 `constant` 声明也能持久（§3.2c 的后续）。

## 0.126.0 — 2026-11-25

`constant` / `enum` / `subset` 声明持久（§3.2c）。

## 0.125.0 — 2026-11-25

对标 IPython 评审的 §4.9 b / c / d / f 散项。

## 0.124.0 — 2026-11-24

显示协议 P1（V-326…V-330 / [ADR-0048](docs/ADR-0048-display-protocol.md)）
- `display($v)` 在同一格多次输出：终端立即显示降级文本，不产生 `Out[n]`、不改 `_`；
  notebook 里走 `display_data`。
- `HTML` / `Markdown` / `JSON` 三种内置包装；任何类型实现 `method to-mime(--> Hash)`
  即可自带渲染（SVG / LaTeX 原样透传）。

## 0.123.0 — 2026-11-24

对标 IPython 评审的 P0「止血」（V-319…V-325、`t/79`）
- 起点：`docs/REVIEW-VS-IPYTHON-2026-11-24.md`（四路实测复核）把差距分成 P0–P3；
  本版只修会让用户直接踩坑的那一档。

---

## 发布节奏

- 版本号只在 `META6.json` 一处为准；`bin/rakuish`、`lib/Rakuish/CLI.rakumod`
  （`FALLBACK_VERSION`）、`lib/Rakuish/Kernel/Notebook.rakumod`（`KERNEL-VERSION`）
  以及 README / MANUAL / HANDOFF / ADR-INDEX 的标题必须同步，由 `t/51` 守着。
- 每个版本一个 annotated tag，tag 消息 = 该版本一句话标题；
  `git tag --list 'v0.*'` 应能对上 CHANGELOG 的每一节。
- 缺陷修复升补丁号（`0.132.1`），新增命令 / API / 行为变更升次版本号（`0.138.0`）。
