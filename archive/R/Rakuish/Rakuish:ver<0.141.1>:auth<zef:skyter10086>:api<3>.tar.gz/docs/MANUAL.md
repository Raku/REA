# Rakuish Manual

适用版本：**0.141.1**（API v3）

本文是使用手册；规格真值见 [`SPEC.md`](../SPEC.md)，架构与接手说明见
[`HANDOFF.md`](../HANDOFF.md)。Rakuish 不是 bash 兼容层：**命令是 Raku，
外部命令只接 argv，Shell 薄层只负责日常文件操作的观感**。

0.83 起交互式 REPL 是**两个进程**（前端 + 求值引擎），0.84 起带会话快照，
0.85 起求值中可按 Ctrl-C 中断，0.90 起 `!` 在终端里边跑边出、并支持
`~/.rakuish/rc.raku` / 可编程 prompt / `set -o`。手册里凡涉及「崩溃 / 重启 /
恢复 / 中断 / 启动」的条款都以当前实现为准。见 §3「进程架构」。

---

## 目录

1. [安装与依赖](#1-安装与依赖)
2. [入口模式](#2-入口模式)
3. [REPL 基本模型](#3-repl-基本模型)
4. [Shell 薄层命令](#4-shell-薄层命令)
5. [Raku 表达式与外部命令](#5-raku-表达式与外部命令)
6. [脚本与 DSL](#6-脚本与-dsl)
7. [结构化数据](#7-结构化数据)
8. [数据引擎：DuckDB / SQLite](#8-数据引擎duckdb--sqlite)
9. [文件与进程 API](#9-文件与进程-api)
10. [配置、alias、hook](#10-配置aliashook)
11. [审计、展示包与运行限制](#11-审计展示包与运行限制)
12. [错误、限制与安全边界](#12-错误限制与安全边界)
13. [故障排查](#13-故障排查)
14. [API 速查](#14-api-速查)

---

## 1. 安装与依赖

```bash
zef install .
rakuish --version
```

要求：

- Rakudo / MoarVM（实测 2026.09 系列）
- `zef`
- 核心依赖：`JSON::Fast`、`Terminal::LineEditor`、`Terminal::API`
- 可选：`DB::DuckDB:ver<1.2.2+>`（分析引擎，依赖 `Alien::Libduckdb:ver<1.2.1+>`）、`DB::SQLite`（事务型小库）

无 TTY 的构建机 / 容器：`Terminal::API` 的上游测试会失败并中断 `zef install .`，
先按 `CI.md` §2.1 用 `--force-test --force-install` 装依赖，再装本包。

源码运行：

```bash
raku -Ilib bin/rakuish
```

Windows 上若 `rakuish.exe` / precomp 文件被残留 `raku` 进程占用，先结束残留进程再安装。

---

## 2. 入口模式

| 命令 | 行为 |
|---|---|
| `rakuish` | 交互 REPL；TTY 有提示符，管道下逐行求值 |
| `rakuish -e '1 + 1'` | 求值一段 Raku，打印结果后退出 |
| `rakuish script.raku a b` | 把整份源码当一个 cell 跑；参数进 `@*ARGS` |
| `rakuish --help` | 启动参数帮助 |
| `rakuish --version` | 版本 |
| `rakuish-notebook` | notebook 前端的协议入口（一行一 JSON，0.109） |

notebook 协议（0.109 / ADR-0037）：`rakuish-notebook` 不接 ZMQ，只做「一行一条
JSON」的请求/响应，传输层由外部桥负责。手动试：

```
echo '{"op":"execute","code":"1+1"}' | rakuish-notebook
# {"display":{"content":"2",...},"ok":true,"execution_count":1,...}
```

支持的 op：`kernel_info` / `execute` / `complete` / `is_complete` / `inspect` /
`shutdown`；启动先输出一帧 `{"event":"ready",...}`。`execute` 回两份内容：
`out`/`err`（用户看到的标准流）与 `display`（MIME 分档，零 ANSI、不带 `Out[n]`
标签）。`display.formats` 列出可用的抽象格式，`display.mime` 是直接的
MIME 表（`text/plain` / `text/markdown` / `text/html` / `application/json`）——
前端按自己会渲染的类型挑一个即可。`! --tty`、后台作业、`input()` 在 notebook
里不可用（没有终端），错误会如实返回。

**主动推送**（0.113 / V-305）：协议不再严格一问一答。帧靠字段区分 —— 带 `op`
的是**响应**，带 `event` 的是**推送**：

| 帧 | 时机 | 字段 |
|---|---|---|
| `busy` | 每格 `execute` 开始 | `op` `id?` |
| `idle` | 该格响应**之后** | `op` `id?` `ms`（耗时毫秒） |
| `engine` | 引擎死亡 / 自动重启 / 快照恢复 | `kind`(dead/restart/interrupted/restart-failed) `ok` `reason` `restarts` `index` `restored` `rc` |

请求带 `id` 就原样回显到响应与推送帧，前端按 id 认领；不带 id 的旧客户端
也还能用，只是要多跳过几行。`engine: dead` 是**空闲期**死亡：引擎死在没人
跑格子的时候，主循环还阻塞在读输入上，靠一条 250ms 的看门狗线程发现并推送
——否则用户要到下一次执行才知道（那时它已经自动重启，看起来像「刚跑就失败」）。

### Jupyter kernel（0.111 / V-302）

`tools/jupyter/` 是一个 **ipykernel wrapper**：继承 `ipykernel.kernelbase.Kernel`，
ZMQ 五通道、HMAC 签名与 heartbeat 全由基类负责；wrapper 只把 Jupyter 的消息
翻译成 `rakuish-notebook` 的一行一 JSON，再把 `display.mime` 原样交给 Jupyter。

```bash
python -m pip install ipykernel jupyter_client
python tools/jupyter/install_kernel.py
python tools/jupyter/smoke.py     # BlockingKernelClient 端到端自检
jupyter lab
```

安装脚本把 wrapper 包和 `kernel.json` 放到 Jupyter 用户目录，因此不用改全局
PYTHONPATH。源码树开发时可用
`install_kernel.py --bridge "raku -Ilib bin/rakuish-notebook"` 指向未安装的桥。

| 事项 | 实现 |
|---|---|
| MIME | 直接转发 `display.mime` 四档；`application/json` 从字符串解成对象 |
| 格号 | 用桥返回的 `execution_count`，失败格不占号；不让 ipykernel 自己递增 |
| 通道 | execute/complete/inspect/is_complete 走 shell；shutdown 走 control |
| 输出 | stdout/stderr → iopub `stream`；值 → `execute_result` |
| 能力 | 清空 `supported_features`（不虚报 debugger / subshells） |
| 推送 | `busy`/`idle` 只记录不转播（ipykernel 自己发 status）；`engine: dead` 转成 iopub stderr 一行 |

边界：没有流式输出（cell 结束才一次性回 `out`），`input()` 与 `! --tty` 不可用；
中断等于杀引擎重启、**会丢会话状态**，所以 kernelspec 用
`interrupt_mode: "message"`。没有自带前端——JupyterLab / Notebook 由用户安装。

**启动参数必须在 shell 里传给 `rakuish`**；REPL 内敲 `--help` 是 Raku 的 `--`
运算符，不是启动参数。

启动成本（0.106.1）：`bin/rakuish` 是极薄启动器，入口逻辑在 `Rakuish::CLI`
模块里走预编译缓存；`--version` 直读 `META6.json`，`-e` / 脚本只加载求值
必需模块。实测 `-e '1+1'` 约 1.35s → 0.69s，`--version` 约 1.2s → 0.3s；
冷启动剩下的主要是 Rakudo 自身与 Session 加载。

`use` 的行为和脚本一致（0.106.2）：`use Foo::Bar` 之后，**后续格**可以直接写
`Foo::Bar.new`；`use` 不写分号、后面跟行内注释都行。混着别的语句的格
（`use X; say 1`）不算纯声明格，但其中的顶层 `use` 仍会被记住 —— 只有 `use`
享受这个待遇，其它语句依旧不重放。

进程模型（0.83 / ADR-0021）：只有**交互式** REPL 把求值放进引擎子进程；
`-e`、脚本、管道都在当前进程里求值 —— 它们没有「会话要继续」这回事，
崩了就崩了，多一层进程只是多一处出错点。详见 §3「进程架构」。

> 0.81.0 / ADR-0019：`--agent` 不再是启动参数，`rakuish-agent` 入口已删除。

脚本模式：

- 预加载 `Rakuish::DSL`、`sys`、`repl`、`registry`
- 不打印 `Out[n]`；输出直接写 stdout（脚本里 `exit` 也不会丢已经打印的内容）
- 有 `sub MAIN` 时做**完整命令行分派**（0.118）：位置 / 命名参数、类型强转、
  `multi MAIN` 候选、`--help`、`sub USAGE`、退出码都与 `raku 文件 参数` 一致；
  顶层语句仍先执行，MAIN 也能看到脚本顶层的 `my` 变量。没给参数时若 MAIN
  需要参数，会打用法并 `exit 2`
- 相对路径跟随调用者 cwd
- **不支持 `=finish` / `$=finish`**：源码在 `do { }` 里编译，数据段没有编译单元
  可挂；需要就用 `raku 文件` 或普通文件 IO
- root 默认是文件系统根（Windows 为当前盘根 + all-drives）；
  给 `Sys.new(:root(...))` 时才有目录边界，那是**防误操作**不是安全隔离

---

## 3. REPL 基本模型

### 进程架构（0.83–0.90）

交互式 REPL 有**两个进程**，边界只有一条：**求值在引擎里，其余都在前端**。

```text
父进程 bin/rakuish                      子进程 raku -e 'serve-engine()'
  Eval::Proxy（冒充 Session）  ← JSON →   Eval::Server + 真正的 Session
  ├─ 行编辑 / 历史 / Tab 补全              ├─ EVAL / %STATE / @decls / Out[n]
  ├─ prompt / banner / 颜色 / 计时         ├─ 输入分类（! / Shell 薄层 / Raku）
  ├─ Kernel.execute（Policy + 审计）       ├─ 内置命令 / DSL / 数据引擎
  ├─ `! --tty` 的真实执行（持终端）        ├─ config / perf / 会话日志
  └─ 崩溃后重启 + 从快照恢复               └─ 崩了只带走它自己
```

| 形态 | 求值位置 | 说明 |
|---|---|---|
| 交互 REPL（stdin 是 TTY） | 引擎子进程 | 崩了自动重启；`Out[n]` / `_` 在引擎里 |
| `-e` / 脚本 / 管道 | 当前进程 | 不重启、不快照、不接管 SIGINT |

四条协议事实：

- **一行一个 JSON 帧**，请求/响应**串行**（同一时刻只有一条在飞）。
- 父进程只拿**渲染好的文本**，不拿 Raku 值 —— 把 DuckDB 连接、自定义
  对象跨进程传过去既不可能也不必要。`_` / `Out[n]` 留在引擎里。
- 用户代码的 `say` 被收进结果的 `out` 字段，不会混进协议流；`$*ERR`
  走子进程 stderr，父进程原样转发。
- `!` 的流式输出走 **`chunk` 帧**（0.90）：父进程收到就写终端，终帧用
  `streamed` 标记，避免结束时重放（§5）。

**终端事实由前端下发**（0.87 / 0.88 / 0.89）：引擎的 `$*IN` / `$*OUT` 是
协议管道，自己探测只会得到 False / 0。所以「是不是 TTY」「多少列多少行」
「颜色开关」每格由父进程探测后随请求推下去。这条规则来自三次静默退化：
`clear` 不清屏、彩色全灭、40 列终端按 80 列排版 —— 进程边界会把
「探测」变成「猜」。

同族的还有 `live-out`：它问的是「本进程 stdout 就是那个终端吗」，答案是
`$*OUT.t`，不需要下发，也**不能**用 `tty` 代替。分页与逐行流式必须判
`live-out`，否则引擎会把表格文本写进 JSON 流（0.89 修掉的事故）。

`! --tty` 是唯一反向的通道：引擎没有终端，它在执行前发 `tty` 事件，
由**父进程**用自己的 `Sys` 执行，再把结果回传（ADR-0021 §6）。

### 输入分类

REPL 每行只有两类输入：

| 输入 | 处理 |
|---|---|
| `! git status` | 去 `!`，只做 argv 分词，调用 `sys.exec`；`|`、`>`、`$`、`*`、`&&` 原样作为参数 |
| `! --tty raku` | 显式 TTY 直通，跑嵌套 REPL / 编辑器（0.70 / V-167） |
| 其它（含 `%`） | Raku 表达式；失败就是失败，不回退 shell |

另外有**日常命令薄层**：`cd`、`ls`、`cat` 等，只把常见 shell 输入翻译成
`Sys` 调用；它不是第三套语言，也不支持管道/重定向/子 shell。

```text
rakuish> 1 + 1
Out[1] = 2
rakuish> %h = a => 7; %h<a>     # % 是哈希
Out[2] = 7
rakuish> ! git status --short    # 外部命令，argv-only
rakuish> help ls                 # 命令帮助
```

**路径参数要加引号**：非 `!` 行按 Raku 表达式解析，裸写的斜杠路径会被拆成
表达式（`save-data(tmp/a.csv, $t)` 报 `Undeclared routine: tmp`）；写成
`save-data("tmp/a.csv", $t)` 即可。脚本模式同理——DSL 函数的路径参数一律是
字符串。

### `_` / `In[n]` / `Out[n]`

- `_`：上一成功格的值
- `Out[1]`：第一个成功结果；`Out[2]` 第二个……
- `In[1]`：本会话第一条输入；`In[2]` 第二条……（0.123.0 / V-322）
  —— 与 `Out` 分开编号：失败格和会话命令都进 `In`，但不进 `Out`
- 纯声明格（整格一个 `sub` / `use` / `class` / …）**不占** `Out` 编号、
  不改变 `_`（0.123.0 / V-320）；IPython 的 `def` 同义
- 失败格不增加 `Out` 编号
- 值可以是 `Table`、`List[IO::Path]`、`Str`、`Stat`、`Junction` 等；
  junction（`1|2`）显示为 `any(1, 2)`，`_` 与 `Out[n]` 保留原 junction，
  不会被折叠成单个分支（0.101.1 起 / 0.101.2 补齐 display，V-287）
- `Buf` / `Blob` 只显示摘要：`Buf[uint8] 978 字节 · Arrow IPC 文件  0x<41 52 …>`
  —— 字节数 + 前 16 字节，不再打印完整元素列表；值本身不变（0.118.2 / V-312）

```raku
ls --json .
_.where({ .<type> eq 'file' }).select('name').to-text
Out[1]
In[1]                              # 上一条输入（字符串）
```

### `display()` 与富输出（0.124 / ADR-0048）

`display($v)` 是「额外输出」：同一格可以调用多次。终端立即显示降级文本，
notebook 里走 `display_data`；**不产生 `Out[n]`、不改 `_`**（它不是结果）。

```raku
display(HTML.new('<b>重要</b>'))
display(Markdown.new("# 标题\n正文"))
display(JSON.new({ a => 1 }))
```

任何类型都可以自己声明怎么显示（鸭子类型）：

```raku
class Chart {
    method to-mime(--> Hash) {
        %( 'image/svg+xml' => '<svg>…</svg>', 'text/plain' => '[chart]' )
    }
}
Chart.new
```

规则：

- `to-mime` 优先于内置识别；它抛异常 = 没有富表示，降级到 `.Str`，**不会崩**。
- 除 text/markdown/html/json 外的 MIME（svg / latex / png …）原样透传给前端；
  P1 只保证 `text/plain` 的终端降级，各档降级与大小上限见 P2。
- `HTML` 的终端降级是去标签文本；`JSON` 的终端降级是展开后的 JSON；
  `Markdown` 终端就是原文。
- 一次执行的多条 `display()` 在 notebook 里发多条 `display_data`；
  cell 末尾的值仍是 `execute_result`。

### 多行输入与声明持久

括号 / 引号未闭合时进入续行；空行提交。

**纯声明格跨格持久**（0.65）：整格只写一个 `sub` / `use` / `class` / `role` /
`grammar` 声明时，它会被缓存并在后续每格前置，下一格可直接使用：

```raku
class Box { has $.n; method twice { $!n * 2 } }
Box.new(n => 21).twice            # 42
role Tag { method tag { "T" } }
class Tagged is Box does Tag { }
Tagged.new(n => 5).twice          # 10
grammar Digits { token TOP { \d+ } }
Digits.parse('123').Bool          # True
```

机制是**只重放纯声明**，不重放任何执行语句；顶层类型声明统一改写成
`my class` / `my role` / `my grammar`，避免装进 `GLOBAL` 后重放冲突。
前奏里 `%STATE` 别名排在声明之前 —— 所以声明体可以引用会话变量
（`my $n = 10` 之后 `sub f { $n }`，0.123.0 / V-319 修掉了旧顺序导致的
「第二格起整段前奏编译失败」）。
边界：混有其它语句的格、含 `BEGIN` / `INIT` 等 phaser 的格不缓存；
持久的是**名字可见性，不是类型对象身份**（每格重放生成新 type object），
`.^name` 会带外层包名。详见 SPEC V-124 / V-153。

### 行编辑

TTY 下使用 `Terminal::LineEditor`：

- Up / Down 历史
- Ctrl-R 循环历史检索（0.100）：首按以**当前缓冲区内容**为查询串，替换为
  「最近一条包含查询串」的历史记录；连按走向更旧的匹配（到头回绕）；
  其它任何编辑动作复位查询态。鱼式模态增量搜索是明确边界（ADR-0034 §3）
- Ctrl-A / Ctrl-E 行首 / 行尾
- `→` / Ctrl-F 接受灰字建议（0.100）：见下「交互手感」
- ShiftTab 列出补全候选（0.100）：见下「交互手感」
- **Ctrl-C 中断当前输入 / 清空续行缓冲（0.71 起不退出会话）**：丢弃半行、
  重画 prompt，不产生一格输出；退出仍用 Ctrl-D 或 `exit`
- Ctrl-D 退出
- Tab 补全命令、路径、`help <cmd>`
- `!` 模式下同样补：`! ls tmp/<Tab>`、`! raku script/<Tab>` 都补路径；
  首词可以是外部程序（`raku` / `python`），不要求是内置命令（0.102.0）
- 0.105.0 起首词本身也补：`! git<Tab>` 会给 PATH 里的外部程序（Windows 下
  去掉 `.exe` 后缀）；`! --tty <Tab>` 的第二词同样补程序名。第一次会后台
  预热 PATH 扫描，之后按 Tab 即时
- 0.98.0 起新登记的 Raku API 名字（`bg-exec` / `bg-jobs` / `fg` / `bg` /
  `open-db` / `tty-exec` / `pty-exec` / `peach` / `recent`）也进 Tab 补全与
  `help` 索引——此前它们只在 DSL 里导出，`help` 查不到、Tab 补不出
- 0.68 起在 `$db.query('...')` / `$db.cursor('...')` 的 SQL 字符串里，
  Tab 还会补关键字 / 表名 / 列名（见下「SQL 上下文补全」）
- 0.69 起支持表别名前缀（`s.am` → `s.amount`）与关键字大小写跟随
  （`SEL` → `SELECT`）；仍不解析 SQL AST
- 0.71 起 SQL 补全还认 `q[...]` 与 `sql =>` / `:sql(` 具名形态
- 历史文件 `~/.rakuish-history`

### 交互手感（0.100 / ADR-0034）

- **灰字建议**：输入停在行尾时，行尾右侧出现灰色建议后缀。来源：先是
  历史（最近一条以当前行为前缀的记录），历史无命中时退到补全候选
  （含路径，0.101 / V-284）；补全结果按 `(行,光标)` 缓存，不会每键扫盘。
  接受方式：`→` 或 Ctrl-F 整句接受；**Alt-→ 逐词接受**（0.101 / V-283，
  每次吞掉下一个词，连按逐词推进）。不在行尾或无建议时，这两个键退化
  为普通的右移 / 右移一词。空行不给建议；密码输入（掩码）不给建议。
- **In/Out 引用补全**（0.101 / V-285）：输入 `Out[` / `In[` 后按 Tab，
  补出已有的结果编号（`Out[1]` … `Out[N]`；`In[2` 只补以 2 开头的），
  直接给出完整替换行。编号来自成功格历史，不存在的编号补不出。
- **方法名补全**（0.107 / V-298）：`$db.<Tab>`、`@rows.<Tab>`、`Out[2].<Tab>`、
  `_.<Tab>`、`DB::DuckDB.<Tab>` 都补方法名，候选是完整替换行；打了半截
  （`$db.co<Tab>`）就只留匹配的。来源是 `^methods` 加几个 `^can` 补的常用名
  （`new` 这类 submethod 不在 `^methods` 里），`!` 开头的私有方法不出现。
  还没赋值的变量、未知类型、`1.5` 这种小数都不补。边界：**链式调用不补**
  （`$x.foo.` 要在补全路径上真求值一次，代价和风险都不值）。
- **候选菜单**：ShiftTab 把当前光标处的补全候选按列打印在输入行下方
  （最多 6 行，超出记 `…(+N)`），然后重画 prompt——菜单不会和输入区
  串行。Tab 的逐候选循环照旧；多候选共享更长前缀时 Tab 第一下先补
  公共前缀（0.100，V-278）。
- **错误态高亮**：输入行里三类「确定错」的东西标红——shell 形命令行的
  未知命令（不在命令表 / 注册表 / PATH，Raku 关键字除外）、不存在的
  路径参数（`./` `~/` `dir/x` 这类；引号内的不标）、括号失配 / 落单
  闭合。行尾未闭合的开括号是**续行常态**，不标。含 `$ @ % & ( ) [ ] { }
  ; | < >` 等未引号元字符的行按 Raku 表达式对待，只做括号检查。
  跨格声明/变量（上一格 `sub foo` / `my $bar`）已作为已知名字排除，
  不再误标无括号 listop 形调用（0.101 / V-286，引擎侧判定）。
- **模糊补全**：命令名 / SQL 表列名的 Tab 补全在前缀零命中时做子序列
  回退（`opdt` → `open-data`）；选项与路径保持前缀匹配。

Ctrl-C 分两个阶段，归属不同（0.85 / ADR-0023）：

| 阶段 | 谁接管 | 结果 |
|---|---|---|
| 输入中（行编辑器在等键） | 行编辑器 | 丢弃半行、重画 prompt，不产生格，不退出 |
| 求值中 · `!` 外部命令（Windows） | 父进程的命令级 job | 只终止命令与它的孙进程，**引擎不重启、会话变量与 `Out[n]` 保留**；`code=130`（0.119 / V-314） |
| 求值中 · Raku 代码（`sleep` / `loop {}`） | 引擎客户端 | 杀掉并重启引擎，从快照恢复；`op=interrupted` / `code=130` |

求值中的 SIGINT **不能**交给引擎自己处理：实测 MoarVM 在 `while 1 { }`
这类纯表达式循环里不检查信号，`kill -INT` 打完仍在跑。唯一可靠的落点是
父进程 `kill(SIGKILL)` 子进程 —— 这正是有两个进程之后才有的物理落点。

`!` 命令能被单独收掉，是因为引擎 spawn 后会把 pid 发给前端，前端把这条命令
收进独立 Job Object（Windows 8+ 的嵌套 job）；否则子进程与引擎不在同一个
「前台」概念里，Ctrl-C 到不了它。没有 job（非 Windows / 建 job 失败）时退回
上一行的行为。

归因刻意分开：按 Ctrl-C 是「已中断当前求值」（用户意图），引擎自己死才是
「引擎进程已退出」（故障）。两者都要重启，但把用户的中断说成故障，会让人
以为出了事、下次不敢按。

设计见 [ADR-0008](ADR-0008-input-interrupt-sql-forms.md) §3.1、
[ADR-0023](ADR-0023-interrupt.md) / SPEC V-168、V-221…V-225。

### 引擎崩溃、快照与恢复（0.83 / 0.84）

**为什么换进程**：同进程 `EVAL` 有三条硬事实 —— 用户写 `exit` 会结束整个
REPL；NativeCall 乱指针 / 深递归的段错误会带走进程；`while 1 { }` 用 SIGINT
打不断。三条都不是「写得小心一点」能解决的。

引擎崩了会看到这样一段（不是栈回溯，也不是静默重置）：

```text
引擎进程已退出（连接已断开）
  · 已自动重启：REPL 本身没有退出，可以继续输入
  · 已从快照恢复：5 条声明、3 个变量（2026-11-16T17:00:00）
  · 无法恢复：$db（连接 / 闭包 / 超大值，已置为 Any；重新赋值即可）
  · 输入历史与配置仍在（它们在父进程侧）
```

注意「整行 `exit`」仍映射为**会话退出**（不算崩溃）；写在表达式里的
`exit`（如 `(exit; 1)`）才会真的结束引擎，然后走上表的恢复流程。

崩溃的那一格是**失败格**，`Out[n]` 不加号；重启后 `Out[n]` 从 `Out[1]`
重新开始，`_` 变回 `Any`（它们和值一起在引擎里）。

**快照存什么**（`Rakuish::Snapshot`，ADR-0022）：

| 类别 | 处理 |
|---|---|
| 纯值（标量 / 数组 / 哈希 / 时间 / 路径 / 枚举 / 简单对象） | 存 `.raku`，恢复时重新 `EVAL` |
| 顶层 `class` / `role` / `grammar` / `sub` / `use` | 随声明缓存一起存，恢复时先重放声明 |
| 资源（数据库连接 / 文件句柄 / 进程 / 锁 / Channel） | **标失效**，置 `Any` |
| 闭包 / Code | 标失效 |
| 超过单值上限的值 | 标失效，并在恢复摘要里列出名字 |

- **语句格不重放**：`write` / `rm` 这类副作用不会因为恢复再执行一次。
  只重放「纯声明」，与上一节「多行输入与声明持久」是同一套边界。
- 每格**成功**后写一次；失败格不写，免得冲掉上一份好快照。
- 落盘路径：`RAKUISH_SNAPSHOT` → `$*HOME/.rakuish/session-<cwd指纹>.json`。
  按 cwd 分文件，不同项目的会话互不覆盖；POSIX 上权限收紧到 `600`
  （快照里有变量的**值**，可能含凭据）。
- `RAKUISH_NO_SNAPSHOT=1` 关闭，**同时停读停写** —— 关掉快照的会话不该去
  翻磁盘上上一轮留下的文件，那会把「关闭」变成「只关一半」。
- `RAKUISH_SNAPSHOT_MAX=N` 设单值字符上限，默认 `1000000`；
  `0` / `off` / `none` / `unlimited` 不限制。非法值回落到默认，不会变成
  「关掉保护」——「写错了」不该让保护消失。

恢复不回来的东西**如实列出来**，不假装变量还在：数据库连接重建出来的是一个
空库连接，比崩溃更难查。恢复后要重新 `open-db(...)`。

已知边界：快照只有单值上限、**没有总量上限**；重启期间不能提交新格
（协议串行）；恢复摘要里的数字是「声明 + 变量」，不是历史格数。

### 启动文件、prompt 与选项（0.90 / ADR-0025）

交互式 REPL 启动时会执行一个启动文件，位置：

| 优先级 | 路径 |
|---|---|
| 1 | `RAKUISH_RC=<path>` |
| 2 | `$*HOME/.rakuish/rc.raku` |
| — | `RAKUISH_NO_RC=1` 关闭（任意非空值） |

> **不是 `~/.rakuishrc`**：那是 v2 的 `KEY=VALUE` 配置（`color=true` 之类），
> v3 不读它 —— 同一路径当 Raku 执行只会在每个会话开头刷「Undeclared routine」。
> 迁移时把 Raku 写进 `~/.rakuish/rc.raku`，或显式 `RAKUISH_RC` 指过去。

`-e` / 脚本 / 管道**不执行** rc —— 它们必须可重复，不受 HOME 影响。

rc 是**逐行**执行的普通会话输入：Raku 与薄层命令都能写。

```raku
# ~/.rakuish/rc.raku
my $project = 'demo';
alias ll=ls -alh
set -o noglob

repl.prompt = -> {
    my $r = try { sys.exec('git', 'rev-parse', '--abbrev-ref', 'HEAD') };
    my $branch = $r.defined && $r.ok ?? $r.out.trim !! '';
    "{sys.cwd.basename}{$branch.chars ?? " [$branch]" !! ''} ❯ "
};
```

- rc 的输出照常显示；但 rc 的格**不占** `Out[n]` / `history` / `perf` ——
  打开 REPL 第一个成功格仍是 `Out[1]`。
- 一行失败不会中断后面的行；错误按 `路径:行号:` 报出来。
- 崩溃重启后 rc **重新执行**（prompt / 选项 / alias 是策略，不是数据）。
- 续行结构（`class {` … `}`）受支持；文件结束时仍有未闭合结构会明确报错。

**可编程 prompt**：`repl.prompt` 接受一个无参 Callable，返回值就是完整
prompt（含箭头）。每次取提示符都会重新调用，所以时间 / git 分支是当下的。
函数里 `say` 的内容会被吞掉；异常时回退默认样式（坏 prompt 不会卡住 REPL）。
续行期间仍显示默认的 `···`，不会用你的 prompt（免得看不出还在输入半个块）。
提示符里的目录请用 `sys.cwd` —— `cd` 只改会话目录，不改引擎进程的 `$*CWD`。

**`set -o`**（0.90 起；`set` 或 `set -o` 列出现状）：

| 选项 | 默认 | 作用 |
|---|---|---|
| `errexit` | off | 失败格请求退出；`set -e` / `set +e` 是别名 |
| `histexpand` | on | 是否认整行 `!!` / `!$` / `!n` |
| `noglob` | off | Shell 薄层不展开 `* ?`（`glob` 命令不受影响） |
| `noexpand` | off | Shell 薄层不展开 `$NAME` / `~` |
| `xtrace` | off | 求值前把 `+ <源码>` 写到 stderr |

```text
set -o                 # 列出全部
set -o noglob          # 打开
set +o noglob          # 关闭
set -o nonsense        # 明确报错并列出可用项
```

选项只在会话内有效；要跨会话写进 rc。`xtrace` 走 stderr，不进
`Result.out` / `Out[n]`；rc 里打开后，后续 rc 行也会被 trace。

### 编辑模式与 hints（0.66 / ADR-0003）

默认 `emacs` 键位，完全不改 `Terminal::LineEditor` 的原生行为。想用 Vi/Helix：

```text
config set edit-mode vi|helix|emacs
config set vi-start insert|normal     # 每行起始模式
config set hints on|off               # 上下文提示（默认 on）
config set plugins on|off             # 本地 Raku 插件（默认 off）
```

`edit-mode` 当格生效（重建行编辑器并迁移历史）。非 emacs 时 prompt 显示
`VI·NORMAL` / `HELIX·INSERT` 之类的模式徽标，banner 也列出编辑模式。

| 键 | 动作 |
|---|---|
| `Esc` | 进 normal |
| `i` / `a` / `A` / `I` / `o` / `O` | 进 insert（各自带光标定位） |
| `h` / `l` / `0` / `$` | 左 / 右 / 行首 / 行尾 |
| `w` / `b` / `e` | 词移动 |
| `x` / `D` / `dd` | 删字符 / 删到行尾 / 清空整行 |
| `u` / `p` | 撤销 / 粘贴 |
| `j` / `k` | 历史下 / 上一格（单行 REPL 的映射） |

`repl.vi` 是同一套语义的纯逻辑对象（缓冲 / 光标 / 模式 / 撤销），可脚本化；
`repl.vi-keys` 是键位表。构造行编辑器失败会自动回退到原生 `CLIInput` 的
`Alt-*` 预设（`Alt-h/j/k/l` 移动、`Alt-w/b` 词移动、`Alt-x` 删除等）。

**hints** 是「上一格给下一格的提示」：命令用法首行、registry 参数摘要、
`!` 的 argv 说明、失败格的下一步建议。同一首词只提示一次，`hint <输入行>`
可手动查询。TTY 下在 prompt 前显示一行暗灰文字；管道 / 非 TTY 完全不输出。

边界：`tools/tty-check.py`（0.74.0 起 25 项）已在 WSL 真 PTY 下自动验证
banner / 彩色 prompt / Vi 徽标 / Tab 补全 / SQL 补全 / Ctrl-C 中断 /
describe / 嵌套 REPL / `tty-exec` 期间 SIGINT 归属；但**真实终端模拟器**
（Windows Terminal、Konsole、tmux 等）的光标手感仍需人工确认。normal 模式下
bracketed paste 的字符会被当 vi 键吞掉，粘贴前先按 `i`，或改用会话命令
`paste`（见后文「块输入：paste」）—— 它读 stdin 到 `--`，整段源码当一个格执行；
行编辑里仍不做多行 buffer / 可视块 / `.` 重复。

### 界面与计时（0.62）

TTY 下的 banner 是**极简字标**（`  Rakuish` + 细分割线，不用字符拼字），
第二行给出版本、Raku / VM、启动时间、cwd 与行编辑状态。prompt 单行显示：

```text
12:37:06  ~/rakuish  git:main  [3]  1.2ms  ❯
```

依次是时间、会话 cwd（长路径折叠）、git 分支、格号、上格耗时、箭头；
失败格额外显示 `[exit=N]`，多行续行的提示符是 `···`。
**管道 / 脚本下不打印 banner 与 prompt，也不输出任何 ANSI**（SPEC V-116）。

计时能力全部是 Raku 原生的值，不是文本魔法命令：

| 写法 | 结果 |
|---|---|
| `timed { ... }` | `Result`，`value` 是返回值，`elapsed` 是耗时；`:repeat(N)` 连跑 N 次 |
| `bench({ ... }, :repeat(5))` | `Result`，`value<min/mean/max/total/repeat>` 可组合，`out` 是人读摘要 |
| `perf [N]` | 最近 N 格耗时 + 平均 / 最慢（默认 10，上限 200） |
| `repl.perf-hist` | 会话级原始记录 `[格号, 毫秒, 源码, 是否成功]` |

`%time` 这类魔法命令**没有恢复**：`%` 始终是 Raku 哈希（SPEC V-122），
耗时改由每格自动记录 + prompt 显示，覆盖所有输入类型。

界面配置（`config set KEY VALUE`，当格即生效）：

| 键 | 值 | 默认 |
|---|---|---|
| `color` | `auto` / `on` / `off` | `auto`（TTY 即开） |
| `clock` / `timing` / `git` / `banner` | `on` / `off` | `on` |
| `prompt-style` | `full` / `compact` / `plain` | `full` |

`NO_COLOR`（任意值）强制关色，`FORCE_COLOR=1` 强制开；`compact` 只留路径，
`plain` 去掉 ANSI 与 `❯`。git 分支只读 `.git/HEAD`，经 `Sys`，不启动进程。

### 颜色与高亮（0.74 / ADR-0011）

`config set color off`（或 `NO_COLOR`、管道）会让**所有**着色同时失效；
开关是同一个，不区分「结果」和「输入」。

结果侧的着色点：

| 内容 | 样式 |
|---|---|
| `ls` / `glob` 的路径列表、`ls -l` 的名字列 | 目录粗蓝 · 可执行粗绿 · 符号链接青 |
| `Out[n] =` 标签 | dim |
| `错误:` 整行 | 红 |
| `help()` | 命令名粗青 · 摘要 dim |
| `env()` | `KEY` 青，`=` 与值保持默认 |
| `stat` | 字段名 dim |
| 写入结果 | `wrote` 绿 · `[non-atomic]` 黄 |

输入行（`emacs` / `vi` / `helix` 一致）：字符串绿、注释灰、数字黄、
变量青（含 `$*CWD` / `$!attr` 这类 twigil）、关键字粗蓝。

两条边界要知道：

- **列宽永远按纯文本算**。着色只插入零宽转义，`strip-ansi` 后与不染色时
  逐字符相同 —— 否则多列 `ls` 会错位、输入区光标会漂。
- 词法覆盖单行的字符串 / 注释 / 数字 / 变量 / 关键字；0.97 起**多行引号会
  延续**：第一行 `"..."` / `q[...]` 没闭合时，续行的下一行开头会整段染成
  字符串色，遇到闭合记号后恢复正常着色。Session 把已提交的续行源码传给
  高亮器实现这一点，纯文本等价不变式仍成立。
- 仍**不染**：正则字面量 / heredoc / pod / 插值块 `{$x}` 里的代码 —— 需要
  真正的 Raku 词法器，刻意为之（半截输入染错色比不染更烦人）。
- `Result` 的 `render-result(format => 'text')` 与 Table 表格**不掺 ANSI**：
  那是给脚本消费的数据格式。
- 行编辑器子类构造失败回退到原生 `CLIInput` 时**没有高亮**，与 Ctrl-C 的
  回退路径同理。

### strict

```text
set -e     # 下一个失败请求退出（等价 set -o errexit）
set +e     # 关闭
```

适用于 shell、`!` 外部命令、Raku 求值失败。完整选项见 §3「启动文件、
prompt 与选项」。

### 历史替换

```text
!!        重跑上一条
!3        重跑第 3 条
!-1       重跑倒数第一条
!$        重跑上一条最后一个词
```

只有整行 `!!` / `!$` / `!n` / `!-n` 做替换；`!cmd` 仍是外部命令。
替换后立即求值，结果再入历史；`expanding` 标志防递归。

编号的口径（0.77 起明确）：**`history` 里的序号就是 `!n` 的 n**，两者同源。
要重跑某一条，用 `rerun n`（0.108）：它走真实求值，会生成新的 `Out[n]`，
但 `rerun n` 这一行本身不进历史，和 `!!` 一样。

- 你提交的**每一行**都进历史：Raku 表达式、shell 命令、`!` 外部命令、
  以及 `config` / `alias` / `log` / `hint` 这类会话级命令；
- 求值**失败**的格也进（`history` 能看到自己敲过什么，哪怕是错的）；
- 多行格记的是**完整源码**（不是最后一行）；空行和还没敲完的续行不记；
- `!!` 记的是它展开后的那条真实命令，不会多出一条 `!!`。

`Out[n]` 用的是另一个计数——**格号**，只有成功的求值/执行格才占号。
所以 `Out[3]` 的意思是「第 3 个成功格」，不是「第 3 个有输出的格」。
会话级命令不占格号，失败格也不占（这条从 0.34 起就是契约）。

---

## 4. Shell 薄层命令

这些命令由 `Rakuish::REPL::Shell` 处理，参数是字面路径/简单 flag；带 Raku
表达式、变量或复杂引号时会交回 Raku。每个命令支持 `--help` 或 `help <cmd>`。

命令名只在 `Shell` 的 `COMMAND-GROUPS` 里声明一处（0.77 / ADR-0015），
补全候选、`help` 索引、`help <cmd>` 的用法都从它派生——所以不会出现
「能跑但 Tab 补不出来」的半截状态。

### 文件与目录

| 命令 | 说明 |
|---|---|
| `pwd [-L|-P]` | 当前会话目录 |
| `cd [dir|-]` | 切换会话 cwd；不 `chdir` 进程 |
| `ls [-a -A -l -h -F -p -R -t -S -r -d -1 --json] [paths]` | 目录列表；`-l` 长格式，`--json` 返回 `Table` |
| `cat [--max-bytes=N] [--enc=编码] 文件...` | 原样输出；`--enc=gbk` 读 GBK/GB2312 |
| `read [--max-bytes=N] [--enc=编码] 文件...` | 与 `cat` 同源；二进制用 `sys.read(..., :bin)` |
| `head [-n N]` / `tail [-n N] [-f\|--follow]` | 前/后 N 行（0.97 流式读，大文件也能用）；`tail -f` 轮询跟随新增（0.99） |
| `mkdir [-p]` | 建目录 |
| `touch` | 建空文件 |
| `cp [-r]` | 复制；目录需要 `-r` |
| `mv` | 移动/重命名 |
| `rm [-r] [-f] [-n]` | 删除；`-n` 是 dry-run |
| `stat 路径` | 元数据 |
| `glob 模式 [目录]` | 返回 `List[IO::Path]` |
| `grep [-inv] [-F|-E] 模式 文件...` | 行匹配 |
| `wc [-lwc] 文件...` | 行/词/字符数 |
| `which 命令` | Shell 内置或 PATH 外部命令 |
| `pushd 目录` / `popd` / `dirs` | 目录栈（`pushd` 压的是切换**前**的目录） |
| `bookmark add NAME [DIR]` / `list` / `go NAME` / `del NAME` | 会话内目录书签，不落盘 |

`ls` 的 `-h` 需要配合 `-l`；`-F` 给目录加 `/`；`-R` 在 TTY 下按目录流式输出
（找到一层显示一层，带 `目录:` 头），非 TTY 仍返回完整分组文本。

**大文件（0.97）**：`read` 整份读有 1 MiB 上限（`max-bytes`），防止 slurp 吃爆
内存；超限会明确报错并给出路。`head -n` / `tail -n` 只读 N 行，与文件总大小
无关，**不受这个上限**——它们走流式按行读（`sys.read-lines(:head/:tail)`），
几十 MB 的日志也能 `head -n 5` / `tail -n 20`。要按记录处理整份大文件用
`stream('路径')`（惰性记录流）；确实要整份读就 `read(...)` 显式传 `:max-bytes(N)`，
自己承担内存。

**tail -f（0.99）**：`tail -f 文件`（或 `--follow` / `-5f` / `-f5`）先打末
N 行（默认 10，`-n 0` 只看新增），然后 0.2s 轮询跟随新增内容，**Ctrl-C
停止跟随**——只是停跟随，不中断会话、不重启引擎（my / our 原样保留）。
只显示完整行（半行等补齐再显示）；文件被截断 / 轮转替换后从新内容继续，
文件消失会等它回来。跟随的行实时显示，格子结果只有一行停止摘要。
`head -f` 不支持（指路 `tail -f`）。跟随循环跑在持有真终端的父进程里，
Windows 同样可用。

### 其他日常命令

| 命令 | 说明 |
|---|---|
| `clear` | 清屏；非 TTY 无控制码 |
| `history` | 本会话命令行 |
| `export KEY=VALUE...` | 写会话 env |
| `unset KEY...` | 删会话 env |
| `help [cmd]` / `help --find TEXT` | 帮助 / 搜索 usage |
| `doc <命令名\|Raku 名字>` | 命令用法，或类型/例程内省（`WHY` / 签名 / 方法）；零 EVAL |
| `log [start [路径]\|stop\|show]` | 会话日志：逐格记录输入与结果，纯文本 |
| `jobs` | 后台任务表 |
| `open [--raw] [--external] 文件` | JSON/CSV/Arrow → Table；Parquet 需 `--external` |
| `explore [路径]` | 结构化浏览；无参数看上一格（引擎侧不分页，见 §7） |
| `describe [表名]` | 列摘要 Table；无参数摘要上一格 Table，表名需 `open-db(...)` |
| `hint [输入行]` | 上下文提示；不带参数查上一格 |
| `paste` | 块输入：读 stdin 到一行为 `--`，整段源码当一个格（0.138） |
| `store [-r|-d|-l]` | 跨会话变量库：点名保存 / 读回 / 删除 / 列出（0.139） |
| `errors [short|full]` | 错误显示分级：默认一行给类型与位置，full 附回放帧（0.140） |
| `recall [n]` | 把历史第 n 条放回预填缓冲（只回显不执行；要重跑用 `rerun n`，0.140） |
| `plugin list\|load PATH\|unload NAME\|info NAME` | 本地 Raku 插件（默认关闭，见下文） |
| `set [-e\|+e]` / `set [-o\|+o] NAME` | strict / 选项（见 §3） |
| `alias` / `unalias` / `config` / `hook` | 见 §10 |

### 路径与展开

- 参数里的 `$NAME` 按会话 env 展开
- `~` 展开到 `$*HOME`
- **Windows**：默认允许访问所有盘符（`D:/`、`F:/`）；
  显式给 `Sys.new(:root(...))` 时只允许该 root 内，跨盘报 `X::Rakuish::Bound`
- glob 由命令自己展开；不经过 shell

### Windows 下中文输入 / 乱码（0.76.1 / ADR-0014）

中文环境的 Windows 控制台默认用 **936（GBK）** 码页，而 Rakudo 的控制台 I/O
按 UTF-8 解析。两者不一致时的表现很具体：

- 敲中文**没有回显**，回车也不生效（行编辑器在等一个永远凑不齐的 UTF-8 序列）；
- 输出里的中文变成 `鍘熺敓` 这类乱码。

`rakuish` 进入交互前会自动把**本控制台**的输入/输出码页切到 65001，退出时还原。
判断依据是「stdin 是终端」——所以管道和脚本不会去改你的终端设置。

排障：若仍然异常，先看一眼当前码页（在 cmd 或终端里敲 `chcp`）；正常应是
`65001`。若被别的工具改回去了，可先手动 `chcp 65001` 再启动。
真控制台的自动化自检：`python tools/tty-cjk-win.py`（Windows，4 项）。

### 格记录与导出：`cells`（0.115 / V-307）

```
cells                        # 列出本会话的格记录（编号 / 状态 / 耗时 / 输入）
cells --text sess.raku       # 导出可重放脚本：直接 rakuish 或 source 它
cells --json -               # 导出结构化记录到 stdout（给别的工具吃）
```

- 与 `history`（只有输入）、`log`（人读抄本，受 log 开关影响）不同，
  `cells` 是**记录**：输入 + 渲染文本 + 成败 + 耗时，上限 500 条。
- `--text` 每格补语句结束符、开头加 `no worries;` —— 补分号是因为 REPL 里
  一格是一次独立 EVAL（`1+1` 不用分号），拼成整份脚本就会「两个项连写」；
  `no worries` 是压掉脚本模式下裸表达式的 sink 警告。
- 两种重放都成立：`rakuish 导出文件`（脚本模式）与 `source 导出文件`（会话模式）。
- 列表的编号是**记录序号**，不是 `Out[n]`：失败的格不占 Out 号，两者会错开。

### 内省、目录栈与日志（0.75 / ADR-0012）

`doc` 是「看一眼」的命令，不是求值：

```
doc ls                  # 内置命令 → 直接给 usage()
doc Str                 # Raku 类型 → 类型名 / WHY / 方法列表
doc &say                # 例程 → 签名 / WHY
doc 1+1                 # 拒绝：不是标识符
```

它用 `::($name)` 查全局符号表，**不做 EVAL**，所以看不到跨格的 `my` / `our`
（那些在会话的 `LexState` 里）。这是刻意的能力边界：内省不该有执行副作用。

会话状态与重跑（0.108 / V-299）：

```
who                     # 变量名：$x  @rows  %cfg
who -l / whos           # 再加类型 / 大小，以及 sub / class / use 一览
$x?                     # 变量：类型 + 一行值摘要
@rows?                  # 容器：类型 + 项数
Box?                    # 本会话声明的 class：方法列表
ls?                     # 命令：等价 doc ls
rerun                   # 重跑上一条
rerun 3 / rerun -2      # 重跑 history 第 3 条 / 倒数第 2 条
```

它们只读 `%STATE` / 声明缓存 / 历史，**不 EVAL、不占 `Out[n]`**（`Box?` 是
例外：为了拿到类型对象会把声明重放一次）。`rerun` 走真实求值，会产生新的
`Out[n]`，但 `rerun 3` 这一行本身不进历史 —— 和 `!!` 一致。

`名字?` 的边界与 `doc` 相同：跨格 `use` 的模块、跨格声明的 sub 看不到内部
符号，会明确说明；`class` / `role` / `grammar` 例外，能列方法。

### 在会话里跑脚本：`source`（0.114 / V-306）

`source 文件 [参数...]` 把脚本喂给**当前会话**，不是新进程（`rakuish 文件`
才是一次性进程，跑完什么都不留）：

```
source lib.raku            # 装库：文件里的 sub / class / use / 顶层 my 留在会话里
source tool.raku 世界       # 带参数跑；文件有 sub MAIN 时按位置参数调用它
```

- **双向共享**：脚本能看到会话里已有的变量与声明；脚本声明的东西跑完也在。
- **参数**：进 `@*ARGS`，`$*PROGRAM` / `$*PROGRAM-NAME` 指向该文件；跑完还原。
  不给参数就只加载，**不调用 MAIN** —— `source lib.raku` 是「装库」不是「跑程序」。
- **记账**：脚本内部的行不占 `Out[n]` / `history` / `perf`（`source` 这一行自身
  记一条历史）。
- **错误**：按 `文件:行` 报出，某一行失败**不中止**后续行（与 shell 的 `source`
  一致）；文件结束时仍处于续行态会报「未闭合结构」。
- **`exit`**：脚本里的 `exit` / `exit 3` / `exit;` 就是退出会话（之前的输出照常
  返回），不会把引擎杀掉重来。
- **边界**：`source` 里的 `sub MAIN` 只按**位置参数**调用；会话里不做完整的
  RUN-MAIN 分派，因为 Rakudo 的用法错误分支会直接 `exit 2` —— 那会把引擎
  带走。需要命名参数 / 类型转换 / 多候选分派时，用 `rakuish 文件 参数`
  （0.118 起脚本模式有完整 MAIN 分派），或在会话里手动 `MAIN(...)`。

### 块输入：`paste`（0.138 / V-342）

粘一段带空行和缩进块的源码（`class` / `multi sub` / heredoc）时，逐行喂会话
会被续行状态机切碎，而且每行各占一条历史。`paste` 换一条路径：读 **stdin**
（不是行编辑器）直到某一行的内容恰为 `--`，把累积的整段文本当成**一个格**
交给 `eval-line`：

```
paste
class P {
    has $.x;
    method hi { "hi {$!x}" }
}

--
P.new(:x(9)).hi        # hi 9
```

- **一个格**：整段只产生一个 `Out[n]`、一条历史（内容是整段源码），`cells`
  里也是一条；同一格里的 `class` 声明照常留下，跨格可用。
- **结束**：`--` 独占一行（前后空白忽略）；管道里直接 EOF 也行（Ctrl-D）。
- **`--` 之后**：后面的行不吃掉，照常按命令 / 表达式解释 —— 可以 `--` 之后
  紧接着写要跑的代码（上面例子里那行就是这样）。
- **四种拒绝**：带参数（「不接受参数」）、空块（没读到任何内容）、源码不完整
  （`is-incomplete` 命中：括号 / quote / heredoc 没闭合）、引擎 / notebook 模式
  （stdin 是协议流不是键盘，明确报不可用）。
- **不改行编辑**：行编辑器仍按 ADR-0036 独占输入循环；`paste` 只在它交还
  输入权之后读 stdin，所以 TTY 与管道同语义。

### 跨会话变量库：`store`（0.139 / V-343）

会话快照（每格自动、按 cwd 分文件）管的是「崩溃后还能接着干」；`store` 管的是
「我只要这一个值，下个项目里也要用」。它把点名的变量写进
`$*HOME/.rakuish/store.json` 一份**跨目录共享**的库里：

```
my $x = 41
my @rows = 1..3
store $x @rows           # 保存；名字不带 sigil 时按 $ @ % & 找唯一匹配

store -l                 # 库里有什么（名字 / 类型 / 长度 / 保存时间）
store -r x               # 换个会话读回，读回的是真·会话变量
store -d $x              # 从库里删掉
store --clear            # 清空库
store -f other.json $x   # 换一个库文件（测试 / 分项目各一份）
```

- **存不下的会说明理由**：闭包、连接句柄 / 进程 / 锁、超过
  `RAKUISH_SNAPSHOT_MAX`（默认 1e6 字符）的超大值一律**拒绝并原文报出**
  原因。这一点与快照相反 —— 快照每格自动跑，只能标记失效；`store` 是你
  点了名，静默跳过等于下次 `store -r` 拿到个空值还以为是自己存的。
- **用户类实例也能跨会话**：值的 `.raku` 形如
  `Rakuish::REPL::Session::Pt.new(...)`，条目里因此连「重放它需要的声明」
  一起存；读回时先拼 prelude（本会话声明 + 条目声明）再求值，所以
  `my class Pt { … }` 只在旧会话里写过也能还原。
- **不是安全边界**：库里有值（可能有凭据），POSIX 上文件权限 600；
  它不加密，也不在用户间隔离。
- 后写覆盖先写；`-f` 只是换文件，不做迁移；不存语句格、`Out[n]`、`_`。

### 错误显示分级：`errors`（0.140 / V-344）

失败格的错误头一行现在说清是哪一层，默认不刷 backtrace：

```
say foo                  # 编译错误: Undeclared routine:
                         #     foo used at line 2
                         # （第 5 格）
say 1 / 0                # 运行错误: Attempt to divide 1 by zero …（第 4 格第 1 行）
sys.read('nope.txt')     # 被拒绝: 文件不存在: …（第 1 格第 1 行）

errors                   # 看当前分级（默认 short）
errors short             # 一行「类型: 消息（位置）」
errors full              # 同一行头 + 完整回放帧（等价 repl.trace = True）
```

- 三种类型的判据是异常类型，不是消息文本：`X::Comp` 族（含
  `X::Comp::AdHoc` / `X::Undeclared::Symbols` 之类的类名前缀兜底）= 编译错误；
  名字含 `X::Rakuish`（实际是 `Rakuish::Result::X::Rakuish::…`）= 被拒绝；
  其余 = 运行错误。
- **位置是「第 N 格第 M 行」**，不是文件名：格内代码经 `EVAL` 编译，
  帧名是 `EVAL_k`，行号按整段拼接源码算（wrapper + prelude + 本格），
  这里已经折算回你那一格的行号。折算到不了有效行（比如编译错误）时只报格号，
  不硬造行号。
- `full` 只是多给帧，不改任何协议字段：Notebook / 引擎前端看到的错误文本照旧。

### 把历史放回输入行：`recall`（0.140 / V-344）

```
recall                   # 上一条
recall 3                 # 第 3 条（编号同 history）
recall -1                # 最后一条
```

`recall` 与 `rerun` 编号相同但语义相反：它**不执行**，只把原文放进预填缓冲
（前端用 `take-prefill` 取走，取一次就清、且只活到下一格）并回显。要直接重跑用
`rerun n`。本机自带行编辑器没有预填 API，所以非交互模式会如实告诉你退路，
不会假装把代码塞进了输入行。

目录栈：

```
pushd src               # 压当前目录，切到 src
dirs                    # 0: /之前/目录 1: /当前/目录  (当前)
popd                    # 弹栈并切回
bookmark add proj       # 把当前目录存成书签 proj
bookmark go proj        # 跳过去（同样更新 cd - 的上一目录）
bookmark list / del proj
```

书签只活在本次会话；`cd -` 与目录栈共用同一个 `prev-cwd`，不会互相覆盖。

会话日志：

```
log start               # 默认写 ~/.rakuish-session.log
log start ./debug.log   # 指定路径
log show                # 看本次会话已记录的内容（不依赖文件）
log stop
```

日志**恒为纯文本**：TTY 下渲染结果带颜色，写文件前会剥掉 SGR；落盘经 `Sys`，
所以会话的 root 边界同样约束它。
- **不支持**：管道 `|`、重定向 `>`、子 shell、heredoc、`&&` 的 shell 语义

#### glob 模式语法（0.65）

`Sys.glob` / Raku `glob('...')` / `glob` 命令支持：

| 写法 | 含义 |
|---|---|
| `*` / `?` | 不跨 `/` 的通配；`?` 只匹配一个非分隔符字符 |
| `**/`、`foo/**/bar`、`foo/**` | 任意深度 |
| `[abc]` / `[a-z]` / `[!x]` | 字符集（范围与取反） |
| `{a,b}` / `{a,{b,c}}` | brace 展开，支持嵌套 |
| `\` + `* ? [ ] { } , \` | 按字面匹配，不当元字符 |
| 裸 `\` | 归一化为 `/`（Windows 路径兼容） |

```raku
glob('*.{txt,md}')        # txt / md 两类文件
glob('{a,{b,c}}.txt')     # a.txt / b.txt / c.txt
glob('\{a,b\}.txt')       # 名字就叫 {a,b}.txt 的文件
```

Shell 薄层（`ls` / `cat` / `rm` 等）的文件名参数**只展开 `* ?`**：含
`{ } [ ]` 的参数会交回 Raku 求值（`glob` 命令除外），且 `!split` 会把 `\`
当转义前缀吃掉。要用转义或嵌套 brace，请写 Raku `glob('...')`。

#### 本地 Raku 插件（0.66 / ADR-0003）

插件就是一个本地 Raku 文件，最后一个表达式求值为 `Command` 对象（或
`List[Command]`）。**加载即执行本地 Raku 代码**，等同 `use` 一个本地模块，
所以默认关闭、只加载你信任的文件。

```text
config set plugins on
plugin load ./mytools.rakumod
plugin list
plugin info mytools.rakumod
plugin unload mytools.rakumod
```

```raku
# mytools.rakumod —— 注意 Result / BuiltinCommand 是模块导出的短名
use Rakuish::Command;
use Rakuish::Result;
BuiltinCommand.new(
    :cmd-name<hello>, :summary('示例插件'),
    :handler(-> $sys, |args { Result.new(:ok, :out('hello')) })
)
```

- 路径先经 `Sys.resolve` 做 root 校验，源码经 `Sys.read`，扩展名限
  `.rakumod` / `.raku`；不自动扫描目录、不联网、不持久化、不开机加载。
- 注册进会话 `CommandRegistry`：`registry.names` / `help()` /
  `cmd('hello', ...)` 可见；**不进** Shell 薄层的文本命令表。
- 与内建或其它插件重名返回 409；`unload` 只移除自己注册的命令。
- 插件的 `run($sys, ...)` 拿到会话 `Sys`，必须经它做文件 / 进程操作。
- 插件只在本机加载（0.81.0 起没有 Agent 线）。

---

## 5. Raku 表达式与外部命令

### 外部命令

```raku
sys.exec('git', 'status', '--short');
```

或 REPL 便捷写法：

```text
! git status --short
```

argv-only：

- 参数原样传入，不解释 `$()`、反引号、`|`、`>`、`*`、`&&`
- 启动失败 `127`、超时 `124`、取消 `137`
- `Result` 永不抛，失败看 `ok/code/err`
- **不做 shell 查找，也不认内置命令别名**：`! cat a.txt` 要求 PATH 里真有
  `cat.exe`（Windows 默认没有，只有 Git Bash 的 `usr/bin` 才带）——缺了就是
  `127`。日常文件操作不用 `!`：`echo hi`、`cat a.txt`、`ls` 这些**不带 `!`**
  的写法走 Shell 薄层，是 Rakuish 自己实现的内置命令，不依赖系统里有没有
  同名 exe。
- **Windows 的 cmd 内建例外（0.130 / ADR-0049 / V-332）**：`echo` / `dir` /
  `type` / `set` 等是 cmd.exe 内建，磁盘上没有同名 exe。`!` 会按**固定白名单**
  回落到 `cmd.exe /d /c`，参数逐个 `^` 转义——`&` / `|` / `>` 仍是字面参数、
  `%VAR%` 不展开。不在白名单里的名字仍按原生规则失败（`127`）；
  `Sys.exec` / 脚本里的 `exec` 不加这层；`! --tty` 也不经过它。

### 输出流式与超时（0.90 / ADR-0024）

交互式 REPL 里 `!` 是**边跑边出**：引擎把 stdout / stderr 分块经协议
送回，父进程立刻写终端。管道 / 脚本 / `-e` 仍保持「收完再显示」，
`Result.out` 契约不变。

```text
! --capture make             # 强制收完再显示
! --timeout-ms 300000 make   # 本次 5 分钟；0 = 不超时
! --no-timeout make          # 等价于 --timeout-ms 0
! -- make --version          # -- 之后全部是字面 argv
```

- 元选项与 `--tty` 同层，只解析开头的 token；子进程仍只收到 argv 数组。
- 非数字 / 负数 / 缺参数明确报 `code=127`，不静默回落到默认。
- 流式完成时 `Result.streamed=True`，输出不会在结束时重放；
  启动失败（没有任何块）仍保留 `err` 文本。
- 子进程 stdout 仍是**管道**，不是终端：`git` 不会自动上色、进度条可能
  退化成整块输出；需要 TTY 语义请用 `! --tty`。
- 捕获上限仍是 1 MiB（`max-bytes`）；流式不放大它，也不承诺无限内存。

### 交互式子进程（0.70 / ADR-0007）

默认 `!` 会捕获输出并在 30s 后超时（终端里同时流式显示）；跑 `raku` /
`python` / 编辑器这类「自己不结束」的程序仍会被杀成 `code=124`。
显式请求 TTY 直通：

```text
! --tty raku                  # 也可写 ! -t raku
! -- --tty foo                  # -- 之后 --tty 只是普通 argv
```

```raku
tty-exec('raku');             # Raku 原生入口，表达式里可用
```

- stdin / stdout / stderr 直接绑定当前 TTY，子进程输出**实时可见**；
- **没有超时**，由子进程的 `exit` / Ctrl-C 决定何时回来。0.73.0 起在 POSIX
  上做**进程组交接**：子进程自成一组并成为终端前台，Ctrl-C 由终端驱动直接
  投给它，父进程根本收不到（V-175 / [ADR-0010](ADR-0010-job-control-feasibility.md)）。
  之前的「父进程临时吞 SIGINT」只保留在 spawn 与切前台之间的微秒级窗口，
  Windows 与降级路径仍走那套。0.72.3 用真 PTY 回归钉住的契约不变：
  子进程退出、宿主存活、下一格仍可输入求值、之后 Ctrl-C 仍是输入中断
  （V-173 / [ADR-0009](ADR-0009-tty-exec-sigint-contract.md)）；
- **Windows / 降级路径（0.101.4 / V-289）**：没有进程组交接时，Ctrl-C 会
  同时到达前台子进程、宿主与引擎。归属现在是明确的：子进程退出、宿主重画
  prompt、**引擎保持存活**。早期版本会把引擎当「中断求值」直接 SIGKILL，
  随后打印「引擎进程已退出 → 重启」，并可能留下光标错位 / 回车无响应的
  终端（只能关窗口）。现在直通期间 Ctrl-C 一律归属前台子进程；
- 进程组交接带来的实际差别：子进程执行 `kill(0, SIGTERM)`（对自己所在
  进程组发信号，现实中清理进程组的工具会这么做）**不再打死宿主 REPL**；
  `Result.value<job-control>` / `<fg-restored>` / `<pgid>` 可查。
  `cwd` 与当前目录不同时依赖 `posix_spawn_file_actions_addchdir_np`
  （glibc ≥ 2.29 / macOS 10.15+），缺失则降级回同组语义并标
  `job-control=False` + `job-control-reason`；
- 0.72.4 起，交接前保存宿主 termios，子进程退出（含非零 / 被信号打断）后
  自动恢复，子进程留下的 raw mode 不会固化到下一轮 prompt；
  `Result.value<termios-restored>` 标记成败（V-174 / ADR-0009 §0）；
  Windows 用 `GetConsoleMode` / `SetConsoleMode`，0.72.5 已在真 ConPTY 与
  conhost 下实测（`503 → 1008 → 503`），见 `tools/tty-termios-win.py`；
- 结束后给一行交接摘要（`↩ exe 已退出 · code=N · 耗时`），然后回到 Rakuish；
- 子进程输出**不进** `_` / `Out[n]`，`Result.value` 只有退出码 / 耗时 / exe / argv；
- `cwd` 仍过 `Sys.resolve` root 校验，`env` 仍是会话属性；
- 非 TTY（管道 / 脚本）明确报错 `code=127`，提示改用 `exec(...)`；
- 普通 `!` 超时（`code=124`）时 hints 会提示改用 `tty-exec(...)`。

### Windows 的孤儿进程：Job Object（0.117 / V-309）

Windows 没有 POSIX 进程组，也没有「父进程死了孩子跟着死」。引擎被 Ctrl-C 杀掉
或崩溃重启时，它启动的命令行进程原本会变成孤儿，谁都不收。

现在引擎一起床就被放进一个 **Job Object**（`JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`）：

- 引擎 spawn 的前台命令、命令再 spawn 的孙进程**自动继承** job 归属；
- Ctrl-C 中断 / `restart` / `shutdown` 都走 `TerminateJobObject`，整棵子树一起收；
- Rakuish 自己退出时句柄自动关闭，job 里的进程跟着结束——不留孤儿。

这跟 fg/bg 无关（那是另一条 POSIX-only 的线），纯粹是回收。非 Windows、
32 位 Rakudo 或建 job 失败时自动降级成旧行为（只 kill 引擎进程），不影响启动。
`Eval::Client.job-active` 可以看当前是否启用了 job。

顺带更正一条旧结论：ADR-0010 原来写「Windows 上 Ctrl 事件不能投递给进程组」，
实测只有 `CTRL_C_EVENT` 成立——`CTRL_BREAK_EVENT` 定向投递是**可以**的，
语义接近 SIGQUIT（默认终止、装 handler 可拦截）。但它换不来前台组与挂起，
所以 job control 依然只在 POSIX 上成立。窗口大小变化仍按格轮询，不做
`WINDOW_BUFFER_SIZE_EVENT` 常驻监听（会和 Ctrl-C 抢 console 输入队列）。

不做自动探测：只有你显式写了 `--tty` / `tty-exec` 才走直通。
边界见 §12 与 [ADR-0007](ADR-0007-tty-passthrough.md)。

### PTY 捕获（0.72 / 0.72.2，SPEC V-170 / V-172）

`tty-exec` 是“把当前终端借给子进程”，不捕获输出。需要“子进程看到 TTY，
但父进程拿回输出、超时、取消”时用 PTY：

```raku
my $r = pty-exec('python', '-c', 'print("hello")',
                 :timeout-ms(5_000), :cols(100), :rows(30));
$r.out;       # 捕获的 stdout（stderr 已按 PTY 语义合流）
$r.code;      # 124 = 超时；0 = 正常
$r.value<pty>; # True
```

```text
pty-exec('cmd', '/c', 'echo hi')   # DSL / 表达式里可用
```

- 分配 `Proc::Async` 的 `:pty(:cols,:rows)`；**需要 Rakudo ≥ 2025.12**。
  0.72.2 起先用版本 + isatty 探针双检，不支持时直接返回 `code=127`
  （`value<pty>/<tty>` 为 `False`），不会静默把普通管道当 PTY 用；
- 默认剥离 ANSI / OSC / 非换行控制字符，保留文本与换行；
  `max-bytes` 限制的是**剥离后文本**的字节数（0.72.2 起先剥离再截断，
  控制序列不占配额、不会留半截 `ESC[` 残片）；
- `timeout-ms` 到点 kill，`code=124`；
- `Result.value` 带 `pty-capable` / `stderr-merged` / `stdin-unavailable` /
  `strip-ansi`：PTY 下 stderr 与 stdout 合流，`err` 恒为空不是遗漏；
- **当前不提供 stdin 写入**：Rakudo 的 `Proc::Async :pty` 没有可靠 stdin
  通道；拿它跑 `raku` 这类需要键盘的 REPL 会一直等到超时（`code=124`），
  那种场景请用 `tty-exec` / `! --tty`；
- **Windows ConPTY 大输出可能丢尾部 chunk**（驱动层行为，Linux 未复现）；
  需要逐字节完整输出时让子进程写文件再读，见
  [AUDIT-FIXES-0.72.2](AUDIT-FIXES-0.72.2.md) §3；
- 需要**交互**而非捕获时用 `tty-exec`（§5.2），别用 `pty-exec` 硬撑。

### 方法链

```raku
my $t = ls-table('.');
$t.where({ .<type> eq 'file' })
  .select('name', 'size')
  .sort-by('size', :reverse)
  .first(10)
  .to-text;
```

### `cmd` 桥

只在 REPL / 绑定 Session 的上下文可用：

```raku
my $t = cmd('ls --json .');
$t.where({ .<type> eq 'file' }).elems;
```

`cmd` 失败抛 `X::Rakuish::CommandFailed`；`cmd-result` 返回完整 `Result`。

### `==>` 的边界

`==>` 是 Raku feed 操作符，只接**例程调用**，左值作为最后一个参数；
它不能写 `.where(...)`。多参数 Table 操作继续用方法链。

```raku
sub files($t) { $t.where({ .<type> eq 'file' }) }
cmd('ls --json .') ==> files();
```

流也一样：`sub only-raku($s) { $s.where({ .<line> ~~ /\.raku$/ }) }`，
`stream($r) ==> only-raku()` 合法；`... ==> .table` **不合法**（右边必须是例程调用），
所以 feed 之后仍要回到方法链。

---

## 6. 脚本与 DSL

```raku
#!/usr/bin/env rakuish
use Rakuish::DSL;

for ls('.', :recursive).grep(*.extension eq 'rakumod') -> $f {
    my $text = read($f);
    write($f, $text.subst(/TODO/, 'DONE'), :atomic);
}
```

### DSL 导出

`ls / ls-table / read / cat / write / append / stat / rm / cp / mv / mkdir /
glob / exec / cmd / cmd-result / cd / pwd / cwd / resolve / env / get-env /
set-env / unset-env / echo / try-op / timed / peach / help / recent`

### 事务 / 并行

```raku
my $db = open-db(':memory:', :!read-only);
$db.begin;
$db.execute('insert into t values (?)', 1);
$db.commit;

my @sizes = peach(ls('docs'), { .s }, :degree(4));
```

---

## 7. 结构化数据

### Table

```raku
my $t = ls-table('.');          # name/type/size/modified/path
$t.where({ .<type> eq 'file' });
$t.get('name');
$t.select('name', 'size');
$t.sort-by('size', :reverse);
$t.first(10);
$t.limit(10).offset(5);
$t.distinct('type');
$t.join($other, :on<name>);
$t.count;
$t.sum('size');
$t.mean('size');
$t.to-text;
$t.to-json;
$t.to-markdown;
```

**从内存数据建表**：DSL 只导出 `ls-table`（列目录）和 `open-data`（读文件），
**没有 `table()` 函数**；手写数据要先 `use Rakuish::Data::Table`，用
`from-rows` 把 Hash / Pair 列表归一化成行：

```raku
use Rakuish::Data::Table;
my $t = Rakuish::Data::Table.from-rows(
    [{ name => 'a', size => 1 }, { name => 'b', size => 2 }]);
$t.elems;    # 2
```

注意 `Table.new(:rows(...))` 直接收的是**已归一化**的行，传位置列表
（`:rows((1, 'x'), (2, 'y'))`）会得到 0 行且无报错——手写数据一律走
`from-rows`。

类型：

`int / num / str / bool / datetime / list / map / any`

```raku
$t.column-type('size');   # int
$t.schema.to-text;        # name/type/nullable
```

### 结构化管道（0.91 / ADR-0026）

`Table` 是急值，`Cursor` 只从数据库来；两者都不接「`!` 的输出」。`stream` 是
缺的那一节：**惰性记录流**。它不引入新语法，就是方法链。

```raku
# 文本 → 记录 → 过滤 → 表格
stream(cmd-result('! find . -name "*.raku"'))
    .where({ .<line> ~~ /Result/ })
    .limit(5)
    .table;

# CSV → 分组计数
stream('region,amount' ~ "\n" ~ 'east,10' ~ "\n" ~ 'west,20', :format<csv>)
    .count-by('region');
```

入口：

| 传什么 | 得到什么 |
|---|---|
| `Str` / `IO::Path` | 按 `:format<lines\|csv\|tsv\|json\|jsonl\|pattern>` 解析；默认 `lines` |
| `Result`（`!` 的产物） | 按行；**失败的 Result 直接抛**，不会被当成空数据 |
| `Table` / `Cursor` | 逐行；Cursor 是真惰性，但只能读一次 |
| `List` / `Hash` | 直接展开 |

```text
! find . -name '*.raku'    → 文本
stream(cmd-result('! ...')) → 记录（n / line 两列）
```

**性能与排错（0.106.0）**：

- 列名写错时（例如 `.<2>` 而实际列叫 `val`），`where` 谓词原本会为每行
  打一条 `Use of uninitialized value` 到 stderr——20 万行就是 20 万条，
  实测把 5 秒的过滤拖成 77 秒。现在只给一次提示并抑制后续同类警告；
  提示会给出 `.columns` 核对列名的出路。**你自己写的 `warn` 不受影响**。
- 来源已知行数时（文本 / CSV / Table / List），`count` 直接返回，
  `limit` / `skip` 也能推算；派生阶段（如 `where` 之后）仍按真实消费计数。
- CSV 无引号行走行级切分，含引号（可跨行）的行仍走原状态机；BOM、
  CRLF、双写引号、字段内逗号/换行与行尾空字段语义不变。

阶段与惰性：

| 阶段 | 惰性 | 说明 |
|---|---|---|
| `.where({...})` | 是 | `$_` 是行 Hash |
| `.select('a','b')` / `.drop('c')` | 是 | 列裁剪 |
| `.map({...})` / `.add-column('x', {...})` | 是 | 返回非 Hash 时包成 `value` 列 |
| `.limit(n)` / `.skip(n)` | 是 | 上游只被拉需要的行数（`t/46` 用计数器守） |
| `.sort-by('col', :reverse)` | **否** | 排序要看完 |
| `.unique` / `.count-by('col')` / `.group-by('col')` | **否** | 去重 / 分组要看完 |

出口：

```raku
$s.table;  $s.text;  $s.json;  $s.csv;
$s.lines;            # 默认 line 列；没有就取第一列
$s.count;  $s.sum('amount');  $s.mean('amount');  $s.min('amount');  $s.max('amount');
$s.each({ .say });   # 返回处理行数
```

**把记录喂回子进程**（shell 管道的另一半，`!` 单独做不到）：

```raku
stream('a,b' ~ "\n" ~ '1,2', :format<csv>)
    .exec('wc', '-l', :format<csv>);     # 走会话 Sys，不是另起一套进程

stream(cmd-result('! find . -name "*.rakumod"'))   # 20 万行也不怕
    .exec('head', '-1');                           # 子进程只读一行就停
```

`.exec` 的 `:format` 是写给子进程的格式（`lines` / `csv` / `tsv` / `json`，
别的值明确报错）；返回 `Result`，可以再 `stream(...)` 接着用。

**stdin 是流式写的**（0.93 / ADR-0028）：上游惰性，下游也惰性 —— 子进程读多快，
生成器就出多快，不会先把整份数据拼成字符串。`head -1` / `grep -q` 提前退出时
上游**立刻停**（`Result.value<in-early>`），不是白算完整条流。

两条必须知道的差别：

- `:format<json>` 是**紧凑**数组（`[{...},{...}]`），键序由 Hash 决定、不作承诺；
  `.json` 那个是缩进版。要字节完全一致就别走 json。
- 只流式**喂** stdin；子进程的输出仍然收完再给（要实时看输出用 `!`）。

**两条流对着看**（0.94 / ADR-0029）：

```raku
$logs.zip($marks);                       # 按位置配对，取较短的一条
$logs.zip($marks, :longest);             # 补齐到长的那个
$logs.join($names, :on<user_id>);        # 默认 left；右表是「字典」
$logs.join($names, :on<user_id>, :how<inner>);   # inner / left / right / outer
$stream.tee('out.csv');                  # 边流边写一份 CSV，行照常往下走
```

三条代价必须知道：

- `join` 把**右表**建成哈希索引（右表必须物化），左表保持惰性。大表放左边、
  小表放右边；写反了会吃内存。
- 列名冲突时右列加 `_right` 后缀（`:suffix` 可改）；右表没有列元数据时，
  右列**统一**加后缀 —— 判断不了冲突，宁可多改也不让右值覆盖左值。
- `tee` 写多少取决于下游读多少。要「只写前 N 行」就把 `limit` 放在**上游**：
  `stream(...).limit(N).tee('x.csv')`，它会正常收尾并关文件；
  `tee(...).limit(N)` 会留下半截、尚未关闭的文件。

`tee` 不是 fan-out（不把一条流同时给两个消费者）：真要分流就先 `.table` 再各处理。

**按顺序收拢两条流**（0.95 / ADR-0030）：

```raku
$a.interleave($b);            # a1,b1,a2,b2…：默认吐完长侧，不丢记录
$a.interleave($b, :shortest); # 任一侧耗尽即停（对齐 zip 的默认取短）
$a.append($b);                # a 全部 + b 全部（Unix cat 对同构流）
```

两条都是**每行保持原样、不改列名**——它们不像 `zip` 那样把两行合成一行，
不存在「同一行里两列撞名」。所以：

- `interleave` 的列取两侧并集、保序、同名列**不改名**；任一侧列未知就留空
  让 `.table` 从实际行推断。
- `append` 的列**取左侧**（同构是契约），左侧未知才取右侧；故意不取并集——
  接错异构流时，并集会让结果看着有全部列、好像没事，沿用左列则让右侧多出的
  列显成缺值，一眼可见。
- `append` 完全惰性，左流读完之前**不碰**右流：`stream(...).append($b).limit(2)`
  不会消费 `$b` 的任何记录（一次性来源也不会因此被毁）。

四条边界：

- **一次性来源只能读一次**。Cursor / 子进程通道的流第二次取会报错（不是空流）；
  `Out[n]` 里存的流在展示时已被消费，要重读就重新取源。
- **数字字符串能算**：CSV 里的 `"10"` 参与 `sum` / `mean`，口径是纯字面量数字。
- **regex 里的空格在 Raku 中不生效**：`/(\w+) (\d+)/` 等价 `(\w+)(\d+)`，
  写 `:pattern` 要用 `\s+`（这不是 Rakuish 的规则，是 Raku 的）。

`help stream` / `doc stream` 能查到同一条摘要。

### 后台作业（0.96 / ADR-0031，POSIX-only）

普通 Raku 函数，**不是 shell 语法**（不碰 V-901）：

```raku
my $r = bg-exec('/usr/bin/slow-job');   # 起后台作业，立即返回 Result
bg-jobs();                               # Table：id / state / exe / pid …
fg($r.value<job>);                       # 带回前台并等待
bg($r.value<job>);                       # 挂起的作业后台继续
```

- `bg-exec` 不起前台交接：子进程自成进程组、继承终端 fd 直接写，前台仍是宿主。
- `fg` 切前台 + `SIGCONT` + 等待；**Ctrl-Z 停住时归还前台并返回 `state=stopped`**，
  不会像 0.73 那样把 REPL 卡在那儿。可以再 `fg(id)` 或 `bg(id)`。
- `fg` 的 `ok` 表示「带回成功」，子进程退出码看 `code` / `value<exit>`——
  作业 exit 7 时 fg 依然成功。
- 作业表在**父进程**：引擎崩溃重启后作业不丢。DSL 函数经协议帧转过去。
- 与 `spawn()` / `jobs()`（捕获输出、`wait()` 收 Result）是**两套语义**：
  那套给「要拿回输出」的后台任务，这套给「占用真终端」的作业。
- Windows 没有前台进程组：四个方法返回 `code=127` + 明确原因，不假装能用。

### JSON / CSV

```raku
my $json = open-data('data.json');
my $csv  = open-data('data.csv');
save-data('out.json', $json);
save-data('out.csv', $csv);
```

REPL：

```text
open data.json
open --raw README.md
ls --json .
```

### explore

```text
explore data.csv
explore docs/
ls --json .
explore
```

分页在**父进程**做（0.92 / ADR-0027）：引擎把整份文本作为 `Result.out` 交回来，
父进程按终端高度切页，用真 stdin 等一个回车。按 `Enter` 下一页，`q` 退出（剩余
行不打印）；读键期间 Ctrl-C 等于停下来。

```text
RAKUISH_PAGER=auto      # 默认：只给 explore 分页
RAKUISH_PAGER=always    # 任何超过一页的结果都分页（cat / ls -R 也算）
RAKUISH_PAGER=never     # 一律不分页
```

默认只给 `explore`：`cat` 大文件、`ls -R` 的契约是「给全」，分页该是显式请求。
非 TTY（管道 / `-e` / 脚本 / 重定向）永不分页。

### Parquet 与大结果（0.64）

```raku
my $t = open-data('sales.parquet', :allow-external);   # → Table
save-data('out.parquet', $t, :allow-external);
my $small = $db.query('select * from big', :max-rows(100));
$t.batches(:size(1000)).map({ .to-text });             # 惰性分批 Seq
$t.to-text(:max-rows(20));                             # 展示上限
```

| 项 | 规则 |
|---|---|
| 扩展名 | `.parquet` / `.pq` → `Table` |
| 开关 | 必须显式 `:allow-external`；Shell 命令是 `open --external` |
| 路径 | 先经 `Sys.resolve` 做工作目录校验；越界抛 `X::Rakuish::Bound` |
| 引擎 | 默认 `enable_external_access=false`，必须显式开关才放开 |
| 空值 | 导出时按列类型写成 0 / 0.0 / False / 空串（不写 NULL） |

`:max-rows` 在 DuckDB / SQLite 里都把 `LIMIT` 下推进 SQL，物化前截断；
`Table.batches` 是惰性分批 `Seq`，`to-text` / `to-markdown` / `to-html` / `to-json(:$max-rows)`
是展示上限（`to-json` 只截行，保持合法 JSON）。**`Table` 本身仍是物化值**；
0.67 起真正的惰性查询由 `Engine.cursor()` 提供（见 §8「流式 Cursor」）。

### Arrow IPC（0.116 / V-308；读侧 0.120.1 起按类型分流）

```raku
my $t = open-data('events.arrow');        # → Table，不需要任何开关
save-data('out.feather', $t);             # 反向往回写
open events.arrow                         # Shell 里一样
```

| 项 | 规则 |
|---|---|
| 扩展名 | `.arrow` / `.feather` / `.ipc` → `Table` |
| 开关 | **不需要** `:allow-external` |
| 读（快路） | 标量列（`int`/`float`/`bool`/`utf8`/`date`/无时区 `timestamp`/`decimal`）且文件 ≥ 1 MB 时，交给 DuckDB（Duckula `read_arrow`）；装了 DuckDB 才有，没有就静默回落（0.122 / V-318） |
| 读（原路） | 其余情况走**自研读入器**（边界检查齐全）；只有嵌套 / 字典这类「自研没实现」的类型才回退 `Arrow::IPC`（0.120.1 / V-316） |
| 坏文件 | 截断 / 越界元数据 → `X::Rakuish::Arrow` 干净报错，**不会**把它们交给会段错误的解析器 |
| 写 | 仍由 `Rakuish::Data::Arrow`：`int64` / `double` / `bool` / `utf8` / `timestamp[ms]` |
| 写多批 | `save-data('x.arrow', $t, :batch-size(N))` 或 `write-ipc($t, :batch-size(N))`：每个 RecordBatch N 行（0.121 / V-317） |
| 流式写 | `write-ipc-stream(行迭代器, $path, :batch-size(N))`：边拉边写，内存只留一批；返回总行数 |
| 读取类型 | `int`(8/16/32/64，有/无符号) / `float` / `bool` / `utf8` / `binary` / `date` / `time` / `timestamp` / `decimal` / `duration` / **`list` / `struct` / `map` / 字典** |
| 压缩 | 标量列能读（DuckDB 解压）；含嵌套 / 带时区列时报 `X::Rakuish::Unsupported` 并给出安装或先用 duckdb 解压的出路 |
| `--raw` | 二进制没有文本形态，明确报错 |

两条读路径的语义逐项对齐（t/74 断言列类型与首行值一致）。
类型落到 `Table` 的口径：`int→int`、`float/decimal/time/duration→num`、
`date/timestamp→datetime`、`utf8/binary→str`、`bool→bool`、`list→list`、
`struct/map→map`（值是 `Hash`，`to-text` 用 JSON 展示，`where` 能继续用）。
`Arrow::IPC` 把时刻解码成字符串，适配层会还原成 `DateTime`（空格换 `T` 再解析）、
`time` 换算成当天秒数、`decimal` 给 `Rat`；**还原不了就保留字符串**并把列标成
`str` —— 不让一次解析失败变成一列假日期。

```raku
# 直接拿字节（不进 Table 体系时）
use Rakuish::Data::Arrow;
my $t = read-ipc-file('a.arrow');
my Buf $b = write-ipc($t, :format<stream>);   # 流模式没有头尾 magic

# 大表：分多批写（每个 RecordBatch 5 万行）
save-data('big.arrow', $t, :batch-size(50_000));
# 或者根本不建 Table：边算边写，内存只留一批
write-ipc-stream((^1_000_000).map({ %(n => $_, s => "u{$_}") }),
                 'big.arrow', :batch-size(50_000));
ipc-batch-count(slurp('big.arrow', :bin));     # → 20，不用装 pyarrow 就能验批数
```

流式写的 schema 由**第一批**决定（列与类型），之后不能改：中途出现别的类型会
抛 `X::Rakuish::Arrow`（`"abc".Int` 在 Raku 里是 0，不核就静默写脏数据）。
落盘先写 `.part` 再改名，失败不会留半截文件。

夹具是 pyarrow 生成的真实文件（`t/fixtures/arrow/`，随仓库提交，测试不依赖
pyarrow）；写出的文件也用 pyarrow `open_file` / `open_stream` 读回核对过。
快路依赖 `DB::DuckDB:ver<1.3.1+>` + `Duckula:ver<0.36+>` + DuckDB 的 `nanoarrow`
扩展（`INSTALL nanoarrow FROM community`）；缺任何一个就自动走原路，不报错。

两条读路径**必须逐值一致**（t/78 用同一份文件跑两遍比对列名 / 类型 / 每一行）：
白名单是按这条契约验证出来的，`time` / `duration` / 带时区 `timestamp` /
`binary` / 嵌套都因此留在原路。快路实测：5 万行 2.6 s → 1.2 s，
50 万行 23.4 s → 13.1 s；剩下的开销几乎全在把列物化成 Raku 的 `Hash`，
DuckDB 真正读文件只花几十毫秒。

已知边界：读侧仍整份文件进内存（快路也是先落成表再转 `Table`）；写侧可以
多批 / 流式（0.121 / V-317），但嵌套列仍不能写（`list` / `map` 明确报错）。
排查读路径时可以用 `RAKUISH_ARROW_NATIVE=1`（强制快路）或
`RAKUISH_ARROW_RAKU=1`（强制原路）。

### Table 上跑 SQL（0.120 / V-315）

`Table` 自带 `where` / `select` / `join`，但聚合、窗口、多源 join 交给 DuckDB
更合适。装了 Duckula 就能直接跑：

```raku
my $t = open-data('events.arrow');        # Arrow::IPC 解码
$t.sql('select kind, count(*) c from t group by 1 order by c desc');

# 多张表（名字就是 SQL 里的表名）
sql({ a => $t1, b => $t2 }, 'select * from a join b using (k)');
# 模块层入口：use Rakuish::Data::Duck; query({...}, '...')
```

| 项 | 规则 |
|---|---|
| 表名 | 单表默认 `t`（`:name` 可改）；只允许字母/数字/下划线 |
| 只读 | `DROP` / `INSERT` 等被拒，错误原文 `statement is not read-only` |
| 类型 | TIMESTAMP/DATE → `DateTime`；整数 → `int`；DECIMAL/DOUBLE → `num`；`xxx[]` → `list`；STRUCT/MAP → `map` |
| NULL | 回到 `Table` 是 `undef`；不替换成 0 / 空串 |
| 嵌套列 | 进 SQL 前转 JSON 文本（可 `like`、可 `from-json` 解回）；SQL 里不能取 struct 字段 |
| 依赖 | Duckula 可选；没装时 `.sql` 抛 `X::Rakuish::Unsupported` 并给安装提示 |

写侧（`save-data`）**不支持**嵌套列：`list` / `map` 列会明确抛
`X::Rakuish::Arrow`（0.120 之前是静默写成 `.Str` 噪声）。要存就先
`select` 掉，或 `to-json` 成字符串列。

---

## 8. 数据引擎：DuckDB / SQLite

DuckDB 是可选分析引擎；SQLite 是可选事务/小数据引擎。核心不强制安装。

### DuckDB

```raku
my $db = open-db(':memory:', :!read-only);
$db.execute('create table t (x int)');
$db.execute('insert into t values (?)', 1);
$db.query('select * from t').to-text;
$db.close;
```

### SQLite

```raku
my $db = open-db(':memory:', :engine<sqlite>, :!read-only);
$db.execute('create table t (x int)');
$db.execute('insert into t values (?)', 1);
$db.query('select * from t').to-text;
$db.close;
```

### 流式 Cursor（0.67）

```raku
my $c = $db.cursor('select * from big_table', :batch-size(500), :max-rows(5000));
for $c.batches -> $batch { say $batch.elems }   # 惰性 Seq of Table
$c.rows.head(3);            # 惰性逐行 Hash
$c.take(10).to-text;        # 只取前 10 行并立即释放
$c.close;                   # 幂等；拉完 / 达到上限自动 close
```

- DuckDB 用 `:stream` + 惰性 `chunks`，SQLite 用逐行 `hash`；**不预先物化整表**。
- 消费到哪一批，查询就走到哪一批；提前退出时请显式 `close`（`DESTROY` 只兜底）。
- 一次性、单连接；不提供可恢复游标、事务一致性快照或并发修改下的稳定视图。
- 不支持的引擎抛 `X::Rakuish::Unsupported`，不静默退化成 `query()`；
  `query()` 与 `Table.batches` 行为不变。
- `query(:max-rows)` 会在物化前下推 `LIMIT`，与 Cursor 是两条路。
- 设计取舍见 [ADR-0004](ADR-0004-cursor-worker.md) §3 / SPEC V-158。

### CSV 受控外部读写（0.68）

```raku
my $t = open-data('sales.csv', :allow-external);   # DuckDB 推断 int / num
save-data('out.csv', $t, :allow-external);          # COPY ... FORMAT CSV, HEADER
```

- 不加 `:allow-external` 时 `.csv` 仍走 `Sys.read` / `Sys.write`，
  列值都是 `Str`；加了开关才由 DuckDB 做类型推断与写出。
- 路径经 `Sys.resolve` 校验；与 Parquet 共用同一套显式授权（V-152 / V-160）。
- `Engine.read-csv(:max-rows)` 会下推 `LIMIT`；驱动错误统一为
  `X::Rakuish::Data`。不做分区写出或按 schema 强制类型。
- 设计取舍见 [ADR-0005](ADR-0005-data-workbench.md) §2。

### CSV 方言参数（0.69 / ADR-0006 §2）

```raku
my $t = open-data('semi.csv', :allow-external,
                  :csv-options({ delimiter => ';', header => False,
                                 skip => 1, 'all-varchar' => True }));
save-data('out.csv', $t, :allow-external,
          :csv-options({ delimiter => ';', header => False }));
```

| 选项 | 读 | 写 | 说明 |
|---|---|---|---|
| `delimiter` | ✅ | ✅ | 单字符，如 `';'`；分号合法 |
| `quote` / `escape` | ✅ | ✅ | 单字符 |
| `nullstr` | ✅ | ✅ | ≤64 字符，写出时映射为 `NULL '...'` |
| `header` | ✅ | ✅ | Bool；`False` 写出时无表头 |
| `skip` | ✅ | ❌ | 0..100000，写出时明确拒绝 |
| `all-varchar` | ✅ | ❌ | Bool，写出时明确拒绝 |

- 未知键明确报错（拼错 `delimeter` 会被发现），不静默忽略。
- 读路径选项全部 `?` 参数绑定，值不进 SQL；写路径是 `COPY` 字面量，
  先过字符校验（不接受单引号 / 反斜杠 / 换行 / NUL）。
- **方言只在 Raku 层**：Shell `open --external` 不做第二套参数语法；
  必须 `.csv` + `:allow-external`，否则明确拒绝。默认文本路径不变。
- 空选项生成的 SQL 与 0.68 完全一致；路径仍经 `Sys.resolve`。

### describe 值 API（0.69 / ADR-0006 §3）

```raku
my $t = open-data('sales.csv', :allow-external);
describe($t).where({ .<nullable> })       # 摘要本身也是 Table
describe('sales')                         # 需先 open-db(...)
describe                                  # 会话命令：无参数摘要上一格 Table
```

- 返回结构化 Table，列固定为
  `name / type / nullable / non_null / distinct / total / sample`；不是文本报告，
  可继续 `.where` / `.sort-by` / `.to-json`。`:sample(N)` 控制样例值个数（0..20）。
- `Engine.describe` 是角色默认实现，只调用 `schema()` / `query()`，DuckDB 与
  SQLite 都可用；聚合失败时该列统计留空，不编造数字。
- 表名只允许字母 / 数字 / 下划线且不以数字开头（防注入）；未注册 Engine 时
  表名形态明确报错并提示 `open-db(...)`。
- 不承诺大表 `count(distinct ...)` 的性能，可用既有查询超时限制。


### SQL 上下文补全（0.68 / 0.71）

`open-db` 会把新建引擎注册为当前会话 Engine（`repl.engine` 可读）。在
`$db.query('select * from sa` 里按 Tab，`Session.completions` 会先识别 SQL
字符串上下文，从 `tables()` / `schema()` 取元数据补表名 / 列名 / 关键字。

- 识别 `'...'` / `"..."` 字符串，以及 0.71 起的不插值 `q[...]` / `q{...}` /
  `q(...)` / `q<...>`；调用名是 `query/cursor/execute/sql(...)` 等白名单，
  也接受 `query(sql => '...')` / `query(:sql('...'))` 具名形态
  （不解析 `qq` / `Q` / heredoc / 嵌套 `q[...]` 或 SQL AST）。
- 0.69：`from sales s` / `join users as u` 建立别名映射，`s.am` 只补该表的列；
  关键字按片段大小写输出（`SEL` → `SELECT`、`Sel` → `Select`）。
- `q[...]` 适合 SQL 里含字符串字面量的场景：`$db.query(q[select * from sales
  where region = 'east' and am` 里按 Tab 仍能补 `amount`。
- **SQL AST 级补全明确不做**（ADR-0006 §4）：不引解析器依赖、两引擎方言不同、
  Tab 热路径不划算。
- 纯函数、只读元数据；驱动缺失 / 库被锁时安静退化，不让 Tab 崩 REPL。
- 原 Shell 补全（命令名 / 路径 / help 参数）完全不变；非 TTY 不触发。
- 见 [ADR-0005](ADR-0005-data-workbench.md) §3 / [ADR-0008](ADR-0008-input-interrupt-sql-forms.md) §3.2 /
  SPEC V-161 / V-169。

### 只读与安全

- 默认只读；`execute` / DDL / 事务会拒绝
- DuckDB 默认 `enable_external_access=false`
- SQL 不能借引擎文件函数绕过 `Sys` root

### 事务

```raku
$db.begin;
$db.execute('insert into t values (?)', 1);
$db.rollback;    # 或 $db.commit
```

### 查询超时

```raku
my $db = Rakuish::Data::Engine::DuckDB.new(
    :max-execution-time-ms(1000),
);
```

SQLite 同样支持 `max-execution-time-ms`（通过 `sqlite3_interrupt`）。

**错误模型（0.64）**：SQL 驱动抛出的异常统一包装成 `X::Rakuish::Data`，
不把驱动堆栈直接暴露给用户；只读拒绝、越界、查询超时仍分别是
`X::Rakuish::Unsupported` / `X::Rakuish::Bound` / `X::Rakuish::Limit`。

---

## 9. 文件与进程 API

### Sys

```raku
my $sys = Rakuish::Sys.new(:root('/work'), :cwd('/work'));
my $text = $sys.read('README.md');
$sys.write('README.md', $text, :atomic);
my @md = $sys.ls('docs', :recursive);
my $r = $sys.exec('git', 'status', '--short');
```

| 方法 | 说明 |
|---|---|
| `read / write / append` | 文本或 `:bin`；`write` 默认原子 |
| `ls / glob / stat` | `IO::Path` |
| `rm / cp / mv / mkdir` | 返回 `Result` |
| `exec / spawn / wait / cancel` | argv-only |
| `tty-exec` | 交互式子进程：TTY 直通、无超时、不捕获输出（0.70 / V-167） |
| `cd / get-env / set-env / env` | 会话级 |
| `resolve` | canonical + root 校验 |
| `jobs / job` | 后台任务 |
| `try-op` | 异常收敛为 Result |

### 文件语义的几个反直觉点（0.101.3 补记）

默认值会咬人，先把四条写清楚：

| 行为 | 实际 | 怎么办 |
|---|---|---|
| 读写大小 | 默认上限 **1 MiB**（`max-bytes`） | `cat` / `read` 加 `--max-bytes=64M`（K/M/G）；API 用 `write(..., :max-bytes(N))` / `read(..., :max-bytes(N))` 单次抬，或 `Sys.new(:max-bytes(...))` |
| 换行 | **写保真、读归一化**：写 `"a\r\nb"` 落盘仍是 CRLF，`read` 文本返回 `"a\nb"` | 要字节精确用 `:bin` |
| `cp` / `mv` | 目标已存在时**默认拒绝**（`X::Rakuish::Exists`），与 POSIX 的默认覆盖相反 | API 传 `:overwrite`；shell 层 `cp` / `mv` **没有 `-f`**（只有 `rm` 有） |
| `glob` | 大小写**敏感**（Windows 上 `*.TXT` 与 `*.txt` 结果不同） | 没有大小写开关；按真实大小写写模式，或自己用 Raku `glob(...)` 过滤 |

**编码**：默认 UTF-8；Rakudo 内建还认识 `utf-16` / `latin-1` / `gb18030` /
`gb2312` 等。**GBK / GB2312 / CP936 直接可用**——0.105.0 起别名自动映射到
`gb18030`（GB18030 向下兼容），API 用 `read(路径, :enc<gbk>)`，shell 用
`cat --enc=gbk 文件` / `read --enc gbk 文件`；写同理 `write(路径, $s, :enc<gbk>)`。
`read-lines(路径, :enc<gbk>)` 也能按行解码（保持 head 惰性）。
**big5 / shift-jis** Rakudo 确实不支持，只能 `:bin` 读字节后自行转码——
拿文本接口读这类文件或二进制会抛 `X::Rakuish::Encoding`，消息给出
`:bin` / 换 `:enc` / `read-lines` 三条路。

### 文件锁（0.105.0）

多进程写同一文件时用 `with-lock` 协调（Raku 内建 `IO::Handle.lock`，
跨平台，无需装模块）：

```raku
with-lock('data.json', {
    my %d = open-data('data.json') // {};
    %d<count>++;
    save-data('data.json', %d);
});
```

- 锁的是独立 `data.json.lock` 伴生文件（**不锁数据文件本身**——`write`
  是原子 rename 换 inode，锁数据文件会让锁失效）；锁文件保留不删。
- 回调正常返回或抛异常，锁都会自动释放；返回值原样透传。
- `:shared` 共享读锁（默认独占写锁）；`:non-blocking` 拿不到锁抛
  `X::Rakuish::LockConflict`（默认会阻塞等待）。
- 这是**劝告锁**：只有同样调用 `with-lock` 的进程互相等待；绕过锁直接读写
  文件的进程不受拦。无强制锁 / 记录锁 / 死锁检测 / 超时参数。
- 典型用途：计数器、配置更新、多脚本协同的日志汇总——"读-改-写"序列
  放进回调里就避免丢失更新。

### 错误模型

- 读/写/列目录/stat：抛异常
- `rm/cp/mv/mkdir`：返回 `Result`
- `exec`：永不抛；看 `ok/code`
- DSL / 命令层：`try-op` 收敛

### Result 渲染

```raku
$r.render('text');
$r.render('json', :pretty);
$r.render('markdown');
$r.to-json;
```

---

## 10. 配置、alias、hook

配置文件默认 `~/.rakuish-config.json`，`RAKUISH_CONFIG` 可覆盖。
`config` 是扁平 KV 存取，**不是**「配置即特性」：只有入口真正读取的键才生效
（`color` / `clock` / `timing` / `git` / `prompt-style` / `banner` / `hints` /
`plugins` / `edit-mode` / `vi-start`），其它键只是存下来，不会凭空产生行为。
0.75.0 订正：旧版文档用 `theme` 做示例，该键全库无人读取，已换成 `color`。

```text
alias ll=ls -alh
alias
unalias ll

config set color off
config get color
config unset color
config

hook add start echo "hello"
hook
hook run start
hook clear start
```

- alias 只展开 Shell 命令行第一个词，最多 10 层
- `start` hook 在 `-e` / 脚本 / 交互求值前运行
- hook 是**本地可信配置**，不要放不可信内容

---

## 11. 审计、展示包与运行限制

> **0.81.0 / ADR-0019**：Agent 结构化服务（JSONL / TCP / 常驻多客户端 /
> 连接级 worker / `stream` / `cancel` / 默认安全开关）已**整体删除**。
> 本节只保留与本机相关的部分：展示包、统一审计、持续集成、超时。
> 历史用法见 `v0.80.4` tag 与 [`ADR-0002`](ADR-0002-agent-serve.md)（已撤销）。

### 展示包（0.78 / ADR-0016）

`Result` 除了 `ok` / `code` / `value` / `out`，还能通过 `Kernel.bundle`
拿到**同一份内容的多种格式**，按需取用（本机渲染与 `-e` 输出都在用）：

```raku
my $b = $kernel.bundle($result);
say $b.render('markdown');     # 实际给到什么格式，$b.render 会如实降级
say $b.available;              # 这个内容支持哪些格式
```

- `text` **永远存在**；`markdown` / `html` / `json` 视内容而定。
- **降级必须如实**：内容不支持 markdown 时给 `text`，并把 `format` 写成
  `text` —— 不会把纯文本标成 markdown。
- 表格类内容（`Table`、记录集、`sql_query` 的行）原生支持 markdown，
  可以直接贴进文档。
- `html`（0.110）：table / records 给 `<table>`（带最小内联样式），
  paths / rows 给 `<ul>`，标量与错误给 `<pre>`；用户内容先转义，
  贴进 notebook 或网页不会变成标签。空内容不提供 html。
- `to-mime` 一次给齐 `text/plain` / `text/markdown` / `text/html` /
  `application/json`（只含可用项）—— notebook 的 `display.mime` 就是它。
- 失败结果（坏语法 / 越界 / 超时）也有 bundle，`kind` 为 `error`。

> 0.81.0：Agent 的 `display` 字段与 `format` 请求参数随协议删除；
> `Display::Bundle` 本身保留。

### 统一审计（0.80 / ADR-0018）

**按来源分账**（0.112 / V-303）：`audit` 看各来源计数，`audit notebook` 或
`audit --origin human` 看明细。查的是结构化审计记录（含其它进程写下的
JSONL），不是 `log` 那份给人看的会话抄本。`Request.origin` 只接受
`human / agent / notebook / script`，自定义来源用 `x-` 前缀（如 `x-web-ui`）；
拼错的值在构造请求时就拒绝，不会悄悄进账本。

**每次操作一条结构化记录**。默认开启、默认落盘
`$*HOME/.rakuish/audit.jsonl`（10k 条 / 10MB 轮转）：

```json
{"seq":1,"ts":"2026-11-16T...","origin":"human","kind":"source",
 "action":"source","session":"local",
 "ok":true,"code":0,"source-hash":"9f2c…","source-bytes":5}
```

- 覆盖：REPL 每一格、`-e`、脚本模式、失败格、被策略拒绝的请求。
  0.81.0 起 Agent 删除，写入点只剩 `Kernel.execute` 的 `LEAVE` 一处，
  **不存在「没记上」的成功路径**。
- 源码只记 FNV-1a 指纹 + 字节数；token、文件内容、SQL 全文、源码文本
  （含编译错误消息里的源码片段）都进不来 —— 靠字段白名单，不靠自觉。
- `RAKUISH_AUDIT=PATH` 改路径，`RAKUISH_NO_AUDIT=1` 关闭。
- `log` 命令是人类可读的**会话抄本**（含渲染文本），与这份审计互不影响。

**不承诺**：日志是事后可查、不是事前阻止；本地 REPL 是同用户环境，
日志文件同用户可写，本版**不防篡改**。

### 持续集成（0.80.1）

`bash tools/ci.sh` 是平台无关的最小 CI 入口：Linux/WSL 跑 `tools/run-all.sh`、
Windows 跑 `prove6 -Ilib t`，产出 `tmp/ci-report.txt`（版本 / 平台 / 文件数 /
断言数 / 结果）并以退出码判定。三条独立失败判据：runner 非零退出、出现
`not ok`、防空跑（文件数或断言数为 0）——只看其中一条都会漏判。

**云端自动触发未启用**：远端是 Gitee，Gitee Go 需网页端开通且构建机要预装
Rakudo；本版不放一个永不触发的 YAML 冒充已接 CI。完整状态与启用配方见
[`CI.md`](CI.md)。真 PTY / ConPTY 与 `zef install` 仍按 HANDOFF 验收清单手工跑。

### 超时

| 对象 | 默认 | 怎么改 |
|---|---|---|
| `!` / `exec` | 30s（超时 `code=124`） | `exec(..., :timeout-ms(N))`；`Sys.new(:default-timeout-ms(...))` |
| SQL 查询 | 不设限 | 直接构造 `Engine::DuckDB.new(:max-execution-time-ms(N))` / `Engine::SQLite.new(...)`（`open-db` 不转这个参数） |
| `pty-exec` | 不设限 | `:timeout-ms(N)` |
| `tty-exec` | **没有超时** | 由子进程 `exit` / Ctrl-C 决定 |
| 求值 | 不设限 | Ctrl-C 中断（0.85，见 §3） |

0.81.0 删除 Agent 之后，`--idle-timeout-ms` / `--sql-timeout-ms` /
`--request-timeout-ms` 这些启动参数与 504 响应一并消失：本机 REPL 没有
请求 deadline，只有**具体操作**自己的超时。旧文档里「dispatch 独立任务 +
超时不等待底层操作」描述的是一条已不存在的服务路径。

`exec` 超时会真的终止直接子进程；纯文件 I/O 这类不可取消操作仍会跑完
（不宣称 OS 级隔离）。需要硬取消整个求值就是 Ctrl-C 杀引擎。

## 12. 错误、限制与安全边界

- root 是同用户文件策略，不是 OS 级隔离
- symlink 逐段 `readlink` + canonical 双重校验（0.67 / V-157）；Windows 创建 symlink 需权限
- `ls` 递归默认 `max-entries=100000`；`cp -r` 预检条目数
- 读写默认 1 MiB；`exec` 输出上限 1 MiB
- `serve-once` / `--serve` 随 Agent 线在 0.81.0 删除：现在没有任何监听端口
- 只有整行 `exit` / `exit N` 映射为会话退出；写在表达式里的 `exit`
  会真的结束引擎进程，父进程重启并从快照恢复（§3）
- 类型声明跨格只覆盖**纯声明格**：混合格、含 phaser 的格不缓存；
  类型对象身份不跨格，`.^name` 带外层包名（SPEC V-153）
- glob 完整语法在 `Sys.glob` / Raku `glob()` 层；Shell 薄层文件名参数只展开 `* ?`
- Vi/Helix 模态依赖 `Terminal::LineEditor` 0.0.23 内部结构；构造失败自动回退
  `emacs`；`tools/tty-check.py` 已自动验到第一个 prompt 之后的交互，真实终端
  光标手感仍需人工确认；normal 模式下粘贴前先按 `i`
- 本地 Raku 插件**加载即执行本地代码**，默认 `off`，只加载你自己的文件；
  0.81.0 起没有 Agent 线，不再有「op 白名单要不要暴露 plugin」这个问题
- Table 类型按值推断；混合列可能降为 `any`
- Parquet 读写是显式授权的外部访问例外（`:allow-external`）
- `query()` 仍返回物化 `Table`；惰性查询用 `Engine.cursor()`（0.67 / V-158），
  游标一次性、单连接，无事务一致性快照
- SQL 驱动错误统一为 `X::Rakuish::Data`；只读 / 越界 / 超时异常原样抛
- Parquet / CSV 的 `:allow-external` 是 V-129 的两个显式例外；
  0.69 的 CSV 方言只是给这两个例外加选项，不新增第三个例外
- CSV 方言选项只在 Raku 层；Shell 薄层不解析方言；写路径不支持 `skip` /
  `all-varchar`，不承诺编码 / 多行字段精细控制
- `describe` 返回结构化 Table，无 Engine 时表名形态报错；大表统计不承诺性能
- SQL 补全不解析 AST（V-908），不识别 `qq` / `Q` / heredoc / 嵌套 `q[...]`；
  别名是词法启发式（0.71 起支持单层 `q[...]`）
- REPL 的 `open-data` / `save-data` 解析到 DSL 版本（V-165 修复）；脚本里
  显式调 `Rakuish::Data::open-data($sys, ...)` 仍可用
- SQL 补全只识别引号字符串 + 元数据启发式；不做 SQL AST 级补全或方言参数
- Ctrl-C 的归属分两个阶段：输入中是输入中断；求值中是杀掉并重启引擎 +
  快照恢复（`op=interrupted` / `code=130`，V-221…V-225）。行编辑器子类
  构造失败回退到原生 `CLIInput` 时没有 `take-interrupt`，输入中断退回
  0.70 的「abort == EOF」行为
- 引擎崩溃后重启**不保证状态完整**：资源 / 闭包 / 超大值明确置 `Any`，
  `Out[n]` 从 `Out[1]` 重新开始、`_` 变回 `Any`，语句不重放（ADR-0022 / §3）
- 引擎里的 `Sys` / `Shell` 不持终端：需要 TTY 的 `! --tty` 绕回父进程执行；
  分页因此不在引擎侧生效（§7）
- 协议串行：引擎重启 / 中断期间不能提交新格
- 快照只限单值大小（`RAKUISH_SNAPSHOT_MAX`），**没有**总量上限；
  `RAKUISH_NO_SNAPSHOT=1` 同时停读停写
- `!` 的流式只在**父进程 stdout 是终端**时开启；子进程 stdout 仍是管道，
  不是 TTY（要终端语义用 `--tty`）。块边界是读到的字节块，不保证整行
- 流式不改变捕获上限（`max-bytes` 仍为 1 MiB），也不承诺输出无限内存
- rc **只对交互式 REPL** 生效，逐行执行；不支持 bash 语法、登录 shell
  分层、per-directory rc。rc 里的 `exit` 会被复位，不会关掉会话
- `repl.prompt` 是同步调用：里面跑外部命令会拖慢每一次提示符；续行期间
  不调用它（固定用 `···`）
- `set -o` 只有五个选项；未知名字明确报错，不做静默接受
- `tty-exec` / `! --tty` 的输出不可捕获、不进 `_` / `Out[n]`；没有超时保护，
  必须自己结束子进程；不自动探测交互式程序（V-167 / ADR-0007）
- `tty-exec` 期间 Ctrl-C 的归属契约见 V-173 / ADR-0009：0.73.0 起 POSIX 上
  已做进程组交接（V-175），不再依赖「父进程吞 SIGINT」；终止符仍是窗口内
  的 tap 与 Windows 老路径。**不做** `&` / `jobs` / `fg` / `bg` / Ctrl-Z
  作业管理 —— Ctrl-Z 会把子进程停住而 REPL 等在那儿，这是明确划出范围外的；
  termios 快照 0.72.4 起已实现（V-174），canonical 基线的位图回归见 `t/31`，
  Windows 控制台模式在 ConPTY / conhost 下由 `tools/tty-termios-win.py` 自查
  （0.72.5，`503 → 1008 → 503`）；
  真终端模拟器里的手感仍建议人工确认（`tmp/TTY-CHECK.md` §7.1）；
  子进程忽略 SIGINT 时仍会一直等
- TTY 直通期间行编辑器的 `start-parser` 理论上仍有一次挂起读；PTY 集成测试
  验证首字符不丢，若某平台确实吞键，退路是 `config set edit-mode emacs`
- `! --tty` 在管道 / 脚本里返回 `code=127`，不会退化成 30s 捕获式执行

---

## 13. 故障排查

### `!` 里的程序 30 秒后被杀（code=124）

这通常是想跑交互式程序（REPL / 编辑器 / 分页器）。默认 `!` 会捕获输出并设
30s 超时；改用 `! --tty <exe>` 或 `tty-exec('<exe>')`，输出会实时出现且不再
超时，退出后回到 Rakuish。非 TTY 环境两者都会明确拒绝（V-167）。

长任务别用 `--tty`：它会拿走终端、也拿不回输出。用
`! --timeout-ms 600000 make`（或 `--no-timeout`），输出仍然会流式显示。

### 命令没有实时输出

流式只在**交互式 REPL**（父进程 stdout 是终端）开启。以下情况是有意的
「收完再出」：

- `rakuish -e '! cmd'`、`rakuish script.raku`、`echo ... | rakuish`；
- 显式 `! --capture cmd`；
- 输出被重定向到文件 / 管道（此时本来就是流给下游，不需要终端实时性）。

### rc 没生效 / prompt 没变

- rc **只对交互式 REPL** 生效；`-e` / 脚本 / 管道不读它。
- 检查 `RAKUISH_NO_RC` 是否被设过；`RAKUISH_RC` 只接受一个路径。
- rc 的失败会带 `路径:行号:` 打印出来，但不会中断后续行 —— 先看有没有
  这一行。
- `repl.prompt` 抛异常会**静默回退**默认样式（不让坏 prompt 卡住输入）；
  先在 REPL 里手动调用一次 `repl.prompt()` 看错误。
- 崩溃重启会重新执行 rc；如果重启后 prompt 还在，说明 rc 路径没变。

### `zef install .` 报 precomp / exe locked

先结束残留 `rakuish` / `rakudo` 进程，再：

```bash
zef install . --force-install
```

### `read docs/ADR-0001.md` 被当 Raku 表达式

0.52.1 起 `read` 是 Shell 命令，按字面路径读取；确认版本 >= 0.52.1。

### `explore` 没有分页（`-- more --` 看不到）

0.92 起分页在父进程做，出现不了通常是这几种情况：

- **输出没超过一页**：rows − 2 行以内不分页，这是正常的；
- **不是 `explore`**：默认 `auto` 只给 `explore` 分页，`cat` / `ls -R` 永远给全；
  想要「什么都分页」用 `RAKUISH_PAGER=always`；
- **非 TTY**：管道、`-e`、脚本、重定向一律不分页；
- 显式关掉了：`RAKUISH_PAGER=never`（`off` / `0` / `no` 同义）。

翻页没反应（回车被吞）说明终端模式没交还 —— 那是要修的问题，先确认
`rakuish` 不是跑在 `winpty` / 非交互封装里。

### 引擎反复重启 / 启动失败

先确认同一个 `raku` 能被直接执行（引擎用 `$*EXECUTABLE` 启动）：

```bash
raku -e 'say $*RAKU-VERSION'
```

再看 `RAKUISH_SNAPSHOT` 指向的目录是否可写。启动失败时前端会照实说
「重启也失败」，不会假装还活着 —— 此时只能退出重开。引擎启动阶段的
stderr 会原样转发到终端，不会吞掉。

### 崩溃后变量 / 数据库连接没了

这是快照的边界，不是丢数据：连接 / 句柄 / 进程 / 锁 / 闭包 / 超大值
**明确不恢复**，置为 `Any` 并在结果里列出名字；恢复摘要会告诉你恢复了
多少。重新 `open-db(...)` / 重新赋值即可。若连纯值都没回来：

- 检查 `RAKUISH_NO_SNAPSHOT` 是否被设过（它同时停读停写）；
- 检查 `$*HOME/.rakuish/session-*.json` 的 `saved-at` 是不是本次会话；
- 快照按 **cwd 指纹**分文件，换了目录就是另一个会话文件；
- 值超过 `RAKUISH_SNAPSHOT_MAX`（默认 1e6 字符）会被判失效，可调大或设
  `0` 关闭上限。

### Windows 时间戳异常

`IO::Path.modified` 可能不可信；`Stat` 如实返回，`recent` 降级，不编造时间。

### 越界与只读（`X::Rakuish::Bound` / `X::Rakuish::Unsupported`）

- 路径越出会话 root（仅在显式 `:root(...)` 时可能发生）
- 删除文件系统根 / 会话 root
- 只读引擎上执行写操作
- Parquet / CSV 外部读写没给 `:allow-external`

---

## 14. API 速查

```raku
# Sys
$sys.read / write / append / ls / stat / rm / cp / mv / mkdir / glob
$sys.exec / tty-exec / spawn / wait / cancel / jobs / job
$sys.cd / get-env / set-env / env / resolve / try-op

# Data
ls-table / open-data / save-data
Table: where/get/select/sort-by/first/last/limit/offset/each/count/
       sum/mean/min/max/distinct/join/schema/describe/column-type/
       to-text/to-json/to-markdown/to-html

# Engine
open-db(:engine<duckdb|sqlite>)
query/execute/tables/schema/begin/commit/rollback/close

# REPL
_ / Out[n] / cmd / cmd-result / explore
alias / unalias / config / hook / which / help --find
perf [N] / timed { ... } / bench({ ... }) / repl.perf-hist
peach(@items, &code, :degree(4)) / recent(N, 'ext', :path('.'))
tty-exec('raku') / ! --tty raku

# 引擎 / 快照（0.83–0.85）
Ctrl-C 求值中 → op=interrupted / code=130（自动重启 + 快照恢复）
RAKUISH_SNAPSHOT / RAKUISH_NO_SNAPSHOT / RAKUISH_SNAPSHOT_MAX

# 分页（0.92）
RAKUISH_PAGER=auto|always|never      # explore 默认分页；always 覆盖所有超一页输出

# 流式与启动层（0.90）
! --capture cmd / ! --timeout-ms N cmd / ! --no-timeout cmd
~/.rakuish/rc.raku · RAKUISH_RC / RAKUISH_NO_RC
repl.prompt = -> { ... } / repl.options
set -o NAME / set +o NAME / set -o

# 结构化管道（0.91）
stream($text|$result|$table|$cursor, :format<lines|csv|tsv|json|jsonl|pattern>)
Stream: where/select/drop/map/add-column/limit/skip（惰性）
        sort-by/unique/count-by/group-by（物化）
        table/text/json/csv/lines/count/sum/mean/min/max/each
        exec(程序, 参数, :format<lines|csv|tsv|json>)   # 边算边写子进程 stdin
        zip(另一条流, :longest) / join(另一条流, :on<列>, :how<inner>)
        tee('out.csv')                                  # 边流边写（写多少看下游）
        interleave(另一条流, :shortest) / append(另一条流)  # 交替 / 首尾接（不改列名）

# 后台作业（0.96，POSIX-only）
bg-exec(程序, 参数) → Result.value<job> / bg-jobs() → Table
fg(job id) / bg(job id)   # 带回前台 / 后台继续（Ctrl-Z 停住时 fg 归还前台）
```

更完整的条款和测试对应关系见 [`SPEC.md`](../SPEC.md) 与 [`HANDOFF.md`](../HANDOFF.md)。
