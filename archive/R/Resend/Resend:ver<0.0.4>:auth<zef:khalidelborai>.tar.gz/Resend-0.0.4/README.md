[![Actions Status](https://github.com/khalidelborai/raku-Resend/actions/workflows/test.yml/badge.svg)](https://github.com/khalidelborai/raku-Resend/actions)

NAME
====

Resend - Raku SDK for Resend

SYNOPSIS
========

```raku
use Resend;
```

DESCRIPTION
===========

Raku SDK for Resend

AUTHOR
======

khalidelborai <elboraikhalid@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2023 khalidelborai

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

