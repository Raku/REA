# Changlog

----
----
## Table of Contents
[2021-01-24](#2021-01-24)  
[2021-01-27](#2021-01-27)  

----
# 2021-01-24
*  Add Changelog

*  Add test for no config.raku file

*  re-order tests, put author and extensive tests in xt/

*  add :cache = True option, so that if :!cache, then the previous value of config is not used

# 2021-01-27


*  added test for empty strings in config files, no need to change code

*  removed :cache and replaced with :no-cache which is False by default





----
Rendered from CHANGELOG at 2021-01-27T18:41:01Z