#!/usr/bin/env sh

set -o errexit

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)

PERL_VERSION=$1

cd /root

wget -O perl-${PERL_VERSION}.tar.gz https://www.cpan.org/src/5.0/perl-${PERL_VERSION}.tar.gz
tar xzf perl-${PERL_VERSION}.tar.gz
cd perl-${PERL_VERSION}
sh Configure -de -Dprefix=/usr/local -Duseshrplib -Dusemultiplicity
make --jobs=`nproc`
make install

cd $DIR
wget -O - https://cpanmin.us 2>/dev/null | perl - App::cpanminus

