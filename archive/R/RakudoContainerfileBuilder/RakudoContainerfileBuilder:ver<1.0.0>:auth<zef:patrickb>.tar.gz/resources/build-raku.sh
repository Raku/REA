#!/usr/bin/env sh

set -o errexit

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)

RAKUDO_VERSION=$1

cd /root

wget -O rakudo-${RAKUDO_VERSION}.tar.gz http://rakudo.org/dl/rakudo/rakudo-${RAKUDO_VERSION}.tar.gz
tar xzf rakudo-${RAKUDO_VERSION}.tar.gz
cd rakudo-${RAKUDO_VERSION}
perl Configure.pl --gen-moar --prefix=/usr/local
make --jobs=`nproc` install

cd $DIR
git clone https://github.com/ugexe/zef.git zef
cd zef
raku -I. bin/zef install .

