Rakudo Containerfile Builder
============================

A small script to build _Containerfile_ s that can create Rakudo container
images. Currently images are based on Alpine.

The resulting images have approximately the following sizes:

- `rakudo`: 71MB
- `rakudo-zef`: 280MB (also includes build tools required to install modules
  with native code)
- `rakudo-perl`: 130MB (includes a Perl suitable for use with `Inline::Perl5`)
- `rakudo-zef-perl`: 339MB (includes Zef and Perl)

Containers based on these are recommended to be _Multi Stage_ d and use
`rakudo-zef` in the build stage and a plain `alpine` (or `rakudo-perl` should a
perl be necessary) in the final stage.

The following example Containerfile showcases that.

    # BUILD STAGE #########################
    FROM rakudo-zef:2020.12 AS build

    RUN mkdir /app
    WORKDIR /app

    # Install deps separately first to not trash the podman cache on every
    # source change.
    COPY META6.json .
    RUN zef install --deps-only .

    # Now copy and compile the actual app.
    COPY . .
    RUN raku -c -I. service.raku

    # FINAL STAGE #########################
    FROM alpine:3.13.1

    # Copy over app and Raku installation
    COPY --from=build /app /app
    COPY --from=build /usr/local /usr/local

    WORKDIR /app

    # Update path to make raku executables available
    ENV PATH=$PATH:/usr/local/share/perl6/site/bin

    ENV MY_APP_HOST="0.0.0.0" \
        MY_APP_PORT="10000"

    EXPOSE 10000
    CMD raku -I. service.raku

