unit class Rakuest::Response;

use JSON::Fast;
use Rakuest::Error;

# 不可变响应对象。4xx/5xx 也是普通 Response —— 与 httpx 一致，
# 想要异常语义请显式调用 raise-for-status。
#
# %.headers 是「名称小写 → 值」的便捷视图（同名多值以 ", " 合并）；
# @.header-list 保留原始顺序与重名条目（Set-Cookie 必须靠它）。
has Int $.status is required;
has %.headers;
has @.header-list;
has Str $.url = '';
has Duration $.elapsed;
has Blob $.blob = Blob.new;
has Supply $.stream;

# 跟过的重定向（老的在前，最后一跳就是 self）。跳数为 0 时是空表 ——
# `$r.history.elems` 直接就是「跳了几次」，排查 302 满天飞时不用抓包。
has @.history;

submethod TWEAK() {
    # 防线：后端如果把 List 当成单个值塞进 header-list（List 在具名参数里
    # 会被 itemize），这里拆一层，保证 @!header-list 永远是扁平的 Pair 数组。
    if @!header-list.elems == 1 && @!header-list[0] ~~ Positional {
        @!header-list = @!header-list[0].list;
    }
}

# 头不存在时返回 Str 类型对象（未定义），不要返回 Any —— 声明了 --> Str
# 的返回类型会让 Any 直接触发类型检查异常，调用方连「有没有这个头」都问不了。
method header(Str $name --> Str) { %.headers{$name.lc} // Str }

method all-headers(Str $name --> List) {
    @!header-list.grep({ .key.lc eq $name.lc })».value.List;
}

method content(--> Blob) { $!blob }

# `blob` / `content` / `body` 是同一份字节的三个名字：blob 是属性本名，
# content 是 httpx 的叫法，body 是「响应当然也有 body」的直觉叫法。
# 请求侧也有 body，两侧同名反而好记，所以这里给个别名而不是让人去猜。
method body(--> Blob) { $!blob }

method text(--> Str) {
    my $ct = %.headers<content-type> // '';
    if $ct ~~ /'charset=' (\S+)/ {
        my $cs = ~$0;
        if $cs.lc ne 'utf-8' && $cs.lc ne 'utf8' {
            my $decoded = try { $!blob.decode($cs) };
            return $decoded if $decoded.defined;
        }
    }
    $!blob.decode;
}

# 解析失败时不要直接把 JSON::Fast 的 "expected a json object" 抛出去 ——
# 十有八九是响应根本不是 JSON（4xx 的 XML/HTML 错误页），而用户看到的那句话
# 里既没有状态码也没有 content-type，根本猜不出发生了什么。这里带上现场信息。
method json {
    my $text = self.text;
    {
        return from-json($text);
        CATCH {
            default {
                die X::Rakuest.new(
                    detail => "响应不是 JSON（HTTP {$!status}，content-type: "
                        ~ (%.headers<content-type> // '未声明') ~ '）'
                        ~ ($text.chars ?? "：{$text.substr(0, 120).trim}…" !! '：正文为空')
                        ~ '。4xx/5xx 不是异常，想直接抛就用 raise-for-status。',
                );
            }
        }
    }
}

method is-success(--> Bool) { 200 <= $!status < 300 }

method is-redirect(--> Bool) {
    $!status == 301 || $!status == 302 || $!status == 303
        || $!status == 307 || $!status == 308;
}

method has-body-stream(--> Bool) { $!stream.defined }

method body-stream(--> Supply) { $!stream // Supply.from-list(()) }

# 换掉 body（解压后用）。被换掉的头必须一起删，否则 Content-Length 是旧值、
# Content-Encoding 还在说「这是压缩过的」，下游再解一次就炸了。
method with-body(Blob $body, *@drop --> Rakuest::Response) {
    my %drop = @drop.map({ $_.lc => True });
    self!derive(
        headers     => %!headers.grep({ !%drop{.key.lc} }),
        header-list => @!header-list.grep({ !%drop{.key.lc} }),
        blob        => $body,
    );
}

# 补上重定向链（门面在最后一跳调）。响应是不可变的，只能重建一份。
method with-history(@hist --> Rakuest::Response) {
    self!derive(history => @hist.List);
}

# 重建响应的唯一入口：字段必须**全列一遍**，漏一个就是静默丢数据
# （比如忘了 stream，流式响应经过一次 with-body 就变成空 body）。
method !derive(*%over --> Rakuest::Response) {
    self.WHAT.new(
        status      => %over<status>      // $!status,
        headers     => %over<headers>     // %!headers,
        header-list => %over<header-list> // @!header-list,
        url         => %over<url>         // $!url,
        elapsed     => %over<elapsed>     // $!elapsed,
        blob        => %over<blob>        // $!blob,
        stream      => %over<stream>      // $!stream,
        history     => %over<history>     // @!history,
    );
}

method raise-for-status(--> Rakuest::Response) {
    die X::Rakuest::StatusError.new(:$!status, :$!url, :response(self))
        unless self.is-success;
    self;
}

# 把流式响应落盘（大文件下载用，不整块进内存）。
method stream-to($dest --> Nil) {
    die X::Rakuest.new(detail => '该响应不是流式读取的') without $!stream;
    my $fh = open $dest.IO, :w, :bin;
    LEAVE $fh.close;
    self!while-stream(-> $chunk { $fh.write($chunk) });
}

# 把流读掉但不留：重定向中途换道、或者非 2xx 时用，避免传输线程
# 往没人读的缓冲里灌数据。
method drain(--> Nil) {
    return without $!stream;
    self!while-stream(-> $chunk { });
}

# `react whenever` 会把 tapper 里抛的异常包成 X::React::Died，
# 用户的 X::Rakuest::TransportError / Timeout 会就此变成一个 AdHoc，
# 他们写的 `CATCH { when X::Rakuest::Timeout }` 全部失配。
# 这里把原异常从 payload 里捞出来重新抛，保持异常族对调用方可见。
method !while-stream(&handler) {
    react {
        whenever $!stream -> $chunk { handler($chunk) }
    }
    CATCH {
        when X::React::Died {
            my $orig = .payload;
            die $orig if $orig ~~ Exception;
            die $_;
        }
    }
}
