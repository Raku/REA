unit role Rakuest::Transport;

use Rakuest::Progress::Tracker;
use Rakuest::Request;

# 窄腰接口：一个后端只需要实现这两件事。
#
# 契约（很重要，加新后端时逐条对照）：
#   1. request 返回的 Promise 兑现为 Rakuest::Response —— 4xx/5xx 也是 Response，
#      不要当异常抛（那会把某个后端的方言泄漏给用户）。
#   2. 只做一跳：不跟随重定向、不处理 cookie、不重试、不注入认证头。
#      这些策略在 Rakuest::Client 里，后端之间必须保持一致。
#   3. 拿不到 HTTP 响应（DNS/连接/TLS/socket）时 die X::Rakuest::TransportError。
#   4. 流式请求（$req.stream 为真）时把响应体放进 Response.stream，
#      不要先整块读进内存。
#   5. capabilities 用字符串集合声明能力：http1 http2 http3 ftp socks mtls……
#   6. 收到 :$progress 时（可能为 Nil）：上传/下载的字节数要喂给它 ——
#      set-total / advance（按块）/ report（绝对位置），阶段结束时 finish。
#      收尾之前先 abort-if-failed：用户回调抛的异常必须原样交给调用方。

method capabilities(--> Set) { set() }

method request(Rakuest::Request $req, Rakuest::Progress::Tracker :$progress --> Promise) { ... }

method supports(Str $capability --> Bool) {
    $capability ∈ self.capabilities;
}

# 放掉连接资源（连接池 / 空闲句柄）。默认什么都不用做 ——
# 但一个后端只要持有 socket，就必须重写它，否则 Client.close 是假的。
method close(--> Nil) { Nil }
