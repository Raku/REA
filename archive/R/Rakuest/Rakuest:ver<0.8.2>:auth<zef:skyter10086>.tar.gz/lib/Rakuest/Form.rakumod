unit module Rakuest::Form;

use Rakuest::Body;

# 常量要写在最前面：`my constant` 是词法作用域，只对它**后面**的代码可见。
my constant CRLF = "\r\n";

# multipart 的部件模型 + 组装。刻意不依赖 Cro 的 Part 类：
# 门面只产出中立模型，后端自己翻译（或者干脆只收字节流）。
#
# 两条命名坑，都踩过：
#   1. 模块叫 Rakuest::Form，类**不能**再叫 Form。包和类同名时 `Rakuest::Form.new`
#      解析到的是包（PackageHOW），直接 "You cannot create an instance of this
#      type" —— 而且只有在真的发 multipart 时才炸。所以类叫 Multipart。
#   2. 部件里的流一律是 Rakuest::Body::Stream（拉模型）。用 Blob 存文件就等于
#      「整块读进内存」，那正是 multipart 大文件上传要避开的事。

class Part is export {
    has Str $.name is required;
    has Str $.filename;
    has Str $.content-type;
    has Blob $.body;                     # 字段值或文件内容（小的、已在内存里的）
    has Str $.value;                     # 文本字段
    has Rakuest::Body::Stream $.stream;  # 文件内容（大的、边读边传的）

    method is-file(--> Bool) { $!body.defined || $!stream.defined }
    method is-stream(--> Bool) { $!stream.defined }

    method bytes(--> Blob) {
        return $!body if $!body.defined;
        ($!value // '').encode('utf-8');
    }

    # 未定义 = 长度未知（流没报长度）→ 整个 multipart 退化成 chunked。
    method length(--> Int) {
        return $!stream.length if $!stream.defined;
        self.bytes.elems;
    }

    method replayable(--> Bool) {
        $!stream.defined ?? $!stream.replayable !! True;
    }
}

class Multipart is export {
    has Part @.parts;
    has Str $.boundary = gen-boundary();

    method add(Part $p --> Multipart) { @!parts.push($p); self }
    method elems(--> Int) { @!parts.elems }

    method content-type(--> Str) { "multipart/form-data; boundary={$!boundary}" }

    # 把整个表单变成一条字节流：部件头是常量字节，文件部件直接接上它的流。
    # 这样内存里永远只有一个块，和 body-stream 上传是同一套机制。
    method to-stream(--> Rakuest::Body::Stream) {
        my $b = $!boundary;
        my @segs;                       # 元素是 Blob 或 Rakuest::Body::Stream

        for @!parts -> $p {
            @segs.push: part-head($p, $b).encode('utf-8');
            @segs.push: $p.is-stream ?? $p.stream !! $p.bytes;
            @segs.push: CRLF.encode('utf-8');
        }
        @segs.push: "--{$b}--\r\n".encode('utf-8');

        my Int $length = 0;
        my Bool $known = True;
        my Bool $replayable = True;
        for @segs -> $s {
            if $s ~~ Blob {
                $length += $s.elems;
            }
            elsif $s.length.defined {
                $length += $s.length;
                $replayable &&= $s.replayable;
            }
            else {
                $known = False;
                $replayable &&= $s.replayable;
            }
        }

        my $state = %( idx => 0, inner => Any, current => Any );

        Rakuest::Body::Stream.new(
            length => $known ?? $length !! Int,
            :$replayable,
            opener => sub {
                # 重放时把游标复位，并且重新开每一段子流：原来的那些已经被
                # 上一轮读空了（Stream 的 chunk 之后不会再吐数据）。
                $state<idx> = 0;
                $state<inner> = Any;
                $state<current> = Any;

                sub () {
                    loop {
                        with $state<inner> -> &pull {
                            my $c = pull();
                            return $c if $c.defined && $c.elems;
                            $state<inner> = Any;
                            $state<current> = Any;
                        }

                        return Nil if $state<idx> >= @segs.elems;
                        my $seg = @segs[$state<idx>++];

                        if $seg ~~ Blob {
                            return $seg if $seg.elems;
                            next;                       # 空段直接跳过
                        }

                        # 可重开的段拿一份新的；不可重开的原样用（此时整体也
                        # 标了 replayable False，没人会来重开）。
                        my $st = $seg.replayable ?? $seg.replay !! $seg;
                        $state<current> = $st;
                        $state<inner> = sub () { $st.chunk };
                    }
                }
            },
            # 上传被中途放弃（超时、连接断）时把当前文件句柄关掉。
            closer => sub {
                .close with $state<current>;
                $state<current> = Any;
                $state<inner> = Any;
            },
        );
    }
}

sub gen-boundary(--> Str) {
    '----RakuestBoundary' ~ (^16).map({ sprintf('%02x', (256 * rand).floor) }).join('');
}

# 头部值里的引号和换行必须挡掉：换行会让攻击者塞进额外的头（header injection）。
sub quote-token(Str $s --> Str) {
    $s.subst('"', '%22', :g).subst("\r", '', :g).subst("\n", '', :g);
}

sub part-head(Part $p, Str $b --> Str) {
    my $cd = 'Content-Disposition: form-data; name="' ~ quote-token($p.name) ~ '"';
    $cd ~= '; filename="' ~ quote-token($p.filename) ~ '"' with $p.filename;

    my @lines = "--$b", $cd;
    @lines.push('Content-Type: ' ~ $p.content-type) with $p.content-type;

    @lines.join(CRLF) ~ CRLF ~ CRLF;
}
