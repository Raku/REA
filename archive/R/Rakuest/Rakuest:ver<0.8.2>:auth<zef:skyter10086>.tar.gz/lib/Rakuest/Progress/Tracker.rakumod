unit class Rakuest::Progress::Tracker;

use Rakuest::Progress;

# 进度记账 + 回调节流。后端只管把「传了多少字节」告诉它 —— 总长、限流、
# 回调异常、线程安全都在这里，两个后端才不会各有一套语义。
#
# 线程模型：Curl 的 xferinfo 在传输线程上调、Cro 的计数在序列化/消费线程上
# 调，都可能不是调用方的线程。状态读写一律进 Lock；**回调本身在锁外调**，
# 否则用户在回调里再摸这个对象（比如查一下 done）就会自己把自己锁死。
#
# 回调抛异常时：记下来、停止后续回调（muted），由后端的下一站把它抛给调用方
# —— 静默吞掉是最坏的选择，用户只会看到「进度条停住但请求成功」。

has Str $.url = '';
has Str $.method = '';
has Int $.attempt = 1;
has Int $.hop = 1;
has &.callback is required;

# 两次回调之间的最小间隔（秒）。0 = 每个 tick 都报。
# curl 每收到 64KB 就 tick 一次，1GB 下载是一万多次回调；进度条 UI 通常
# 只想要 10Hz，设 0.1 就够。**到达终点的那一次永远不受限**（否则余额不足的
# 进度条会停在 99%）。
has Numeric $.interval = 0;

has Lock $!lock .= new;
has %!done;        # phase => 已传字节
has %!total;       # phase => 总字节（可能没有）
has %!started;     # phase => 起始时刻
has %!emitted;     # phase => 上一次报出去的 done（去重用）
has %!last-at;     # phase => 上一次回调的时刻（限流用）
has $!failure;
has Bool $!muted = False;

method failure() { $!failure }
method failed(--> Bool) { $!failure.defined }

# 回调已经炸了：把**原始异常**抛给调用方，不要包装 —— 用户写的是
# `progress => -> $p { die "磁盘满了" }`，他应该看到「磁盘满了」。
method abort-if-failed(--> Nil) {
    die $!failure if $!failure.defined;
    Nil;
}

# 总长。知道了就报一次，进度条才能一开始就有比例（curl 在第一个 tick 之前
# 不会给 ultotal）。负数（curl 的 -1 = 未知）忽略。
method set-total(Str $phase, Int $n --> Nil) {
    return if $n < 0;
    $!lock.protect({
        %!total{$phase} = $n;
        %!started{$phase} //= now;
    });
    Nil;
}

# 相对推进：Cro 的按块计数走这条。
method advance(Str $phase, Int $delta --> Nil) {
    return if $delta <= 0;
    my ($done, $total, $fire);
    $!lock.protect({
        %!started{$phase} //= now;
        %!done{$phase} = (%!done{$phase} // 0) + $delta;
        $done = %!done{$phase};
        $total = %!total{$phase} // Int;
        $fire = self!want-emit($phase, $done, $total);
    });
    self!deliver($phase, $done, $total) if $fire;
    Nil;
}

# 绝对位置：curl 的 xferinfo 给的是 dlnow/ultotal 这种累计值。
method report(Str $phase, Int $done, Int $total --> Nil) {
    my ($seen, $total-now, $fire);
    $!lock.protect({
        %!started{$phase} //= now;
        %!done{$phase} = $done;
        %!total{$phase} = $total if $total > 0;
        $seen = $done;
        $total-now = %!total{$phase} // Int;
        $fire = self!want-emit($phase, $seen, $total-now);
    });
    self!deliver($phase, $seen, $total-now) if $fire;
    Nil;
}

# 收尾：把「最后到哪儿了」补报一次。已经报过同样位置就不重复。
# 失败/提前结束时 done < total，这一发是**有信息量的**（进度条不会假装成功）。
method finish(Str $phase --> Nil) {
    my ($done, $total, $fire) = (0, Int, False);
    $!lock.protect({
        if %!started{$phase}:exists {
            $done = %!done{$phase} // 0;
            $total = %!total{$phase} // Int;
            $fire = !(%!emitted{$phase}:exists && %!emitted{$phase} == $done);
        }
    });
    self!deliver($phase, $done, $total) if $fire;
    Nil;
}

# 调用前必须持锁。
method !want-emit(Str $phase, Int $done, Int $total --> Bool) {
    return False if %!emitted{$phase}:exists && %!emitted{$phase} == $done;
    return True if $total.defined && $done >= $total;   # 终点不受限流约束
    return True if $!interval <= 0;
    my $last = %!last-at{$phase};
    return True without $last;
    (now - $last) >= $!interval;
}

method !deliver(Str $phase, Int $done, Int $total --> Nil) {
    return if $!muted;

    my $started;
    $!lock.protect({
        %!emitted{$phase} = $done;
        %!last-at{$phase} = now;
        $started = %!started{$phase} // now;
    });

    my $p = Rakuest::Progress.new(
        phase   => $phase,
        done    => $done,
        total   => $total,
        url     => $!url,
        method  => $!method,
        attempt => $!attempt,
        hop     => $!hop,
        elapsed => now - $started,
    );

    {
        &!callback($p);
        CATCH {
            default {
                $!failure = $_;
                $!muted = True;
            }
        }
    }
    Nil;
}
