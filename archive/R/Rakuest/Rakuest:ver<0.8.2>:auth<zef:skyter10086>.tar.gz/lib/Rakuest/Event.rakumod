unit class Rakuest::Event;

# 生命周期钩子收到的事件。字段全部塞在 %!data 里，用 `$e<status>` 取 ——
# 每种事件的字段不一样，为它们各建一个类只会让「加一个字段」变成改三处。
#
# 已定义的事件（与 Client 的 hooks 键一一对应）：
#   request   在发出前一跳之前    method / url / hop / attempt
#   response  收到一跳的响应之后  response / hop / attempt
#   redirect  决定跟随重定向之后  from / to / status / response
#   retry     决定重试之后        url / attempt / delay / status 或 error
#
# 钩子在**调用方线程**上同步执行（重定向/重试都在门面里），抛出的异常会
# 直接冒到 request() 的调用点 —— 那是用户的 bug，不该被吞掉。

has Str $.name is required;
has %.data;

method AT-KEY(Str $k) { %!data{$k} }
method EXISTS-KEY(Str $k) { %!data{$k}:exists }
method keys(--> List) { %!data.keys.List }
method to-hash(--> Hash) { %!data.clone }

method gist(--> Str) {
    "Rakuest::Event({$!name}: {%!data.keys.sort.join(', ')})";
}
