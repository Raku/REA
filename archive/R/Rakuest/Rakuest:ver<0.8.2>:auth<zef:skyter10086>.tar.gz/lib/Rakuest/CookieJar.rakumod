unit class Rakuest::CookieJar;

use Rakuest::URI;
use Rakuest::Response;

# RFC 6265 的可用子集：
#   · 解析 Set-Cookie 的 name/value/Domain/Path/Secure/Max-Age/Expires；
#   · Expires 支持 IMF-fixdate、RFC 850、asctime 三种历史格式；
#   · Domain 必须是请求域名的后缀，否则整条属性忽略（防 cookie 注入）；
#   · 发送时按 host（host-only / 后缀匹配）、path 前缀、Secure、过期时间过滤。
#
# 放在门面层而不是传输层：换后端时 cookie 语义不变。
#
# 线程安全：absorb / header-for / clear / elems 全部在内部 Lock 下操作，
# 一个罐子可以被多个线程同时用（并发客户端共享的正是同一个罐子）。
class Cookie is export {
    has Str $.name is required;
    has Str $.value = '';
    has Str $.domain is required;
    has Str $.path = '/';
    has Bool $.secure = False;
    has Bool $.host-only = True;
    has Instant $.expires;

    method expired(--> Bool) { $!expires.defined && $!expires <= now }
    method key(--> Str) { "{$!domain}\t{$!path}\t{$!name}" }
}

# ---- RFC 6265 §5.1.1 cookie-date ----
#
# 单靠 DateTime 的 strptime 顶不住历史格式，于是按 RFC 的思路做：先切 token，
# 再按「时间/日/月/年」分别认领。允许的写法实际是这几种：
#
#   Sun, 06 Nov 1994 08:49:37 GMT    ; IMF-fixdate（RFC 1123/5322）
#   Sunday, 06-Nov-94 08:49:37 GMT   ; RFC 850
#   Sun Nov  6 08:49:37 1994         ; asctime
#   06 Nov 1994 08:49:37 GMT         ; 省略星期
#
# 时区一律按 UTC 处理（RFC 6265 本身不解析时区，直接忽略这些 token）。
# 坑：Raku 的 `<[...]>` 会**忽略类里的空白**（连 `\t` 都被当成字面 't'），
# 所以空格必须写成 \x20，制表符写 \x09 —— 否则分隔符匹配不上，整串只剩一次 split。
my regex date-sep { <[\x20\x09\x0D\x0A,;\-]>+ }

# class body 里只跑声明，不跑语句 —— 所以这里必须是 constant（编译期求值），
# 写成 `my %MONTH; for ... { }` 那个 for 根本不会执行，月份永远匹配不上。
my constant MONTHS = <jan feb mar apr may jun jul aug sep oct nov dec>;

# 解析失败返回 Instant 类型对象（未定义），调用方据此决定「忽略这条属性」。
# 不能返回 Nil：调用方要区分「没解析出来」和「解析成 1970」。
sub parse-cookie-date(Str $raw --> Instant) is export {
    my @tok = $raw.split(&date-sep).grep(*.chars);
    return Instant unless @tok.elems;

    my Int $hour = 0;
    my Int $minute = 0;
    my Int $second = 0;
    my $day;
    my $month;
    my $year;
    my Bool $got-time = False;
    my Bool $got-day = False;
    my Bool $got-month = False;
    my Bool $got-year = False;

    for @tok -> $t {
        # 顺序与 RFC 一致：时间 → 日 → 月 → 年，每个字段只认领第一个匹配的 token。
        # 这样 "Sun, 06 Nov 1994 ..." 里的 "Sun" 会被跳过（星期名不是月份）。
        if !$got-time && $t ~~ /^ (\d**1..2) ':' (\d**1..2) ':' (\d**1..2) $/ {
            ($hour, $minute, $second) = $0.Int, $1.Int, $2.Int;
            $got-time = True;
            next;
        }
        if !$got-day && $t ~~ /^ \d**1..2 $/ {
            $day = $t.Int;
            $got-day = True;
            next;
        }
        if !$got-month {
            with MONTHS.first($t.substr(0, 3).lc, :k) {
                $month = $_ + 1;
                $got-month = True;
                next;
            }
        }
        # 只接受 2–4 位纯数字。RFC 的 year 产生式还允许「以非数字开头」的 token，
        # 那条如果照字面实现，任何杂词都会被当成 year —— 各大浏览器也都不这么做。
        if !$got-year && $t ~~ /^ \d**2..4 $/ {
            $year = $t.Int;
            $got-year = True;
            next;
        }
    }

    return Instant unless $got-day && $got-month && $got-year;

    # 两位年份展开：70–99 → 19xx，00–69 → 20xx（RFC 6265 §5.1.1 第 5 步）
    $year += $year >= 70 ?? 1900 !! 2000 if $year < 100;
    return Instant if $year < 1601;
    return Instant unless 1 <= $month <= 12;
    return Instant unless ($hour <= 23) && ($minute <= 59) && ($second <= 59);

    # 交给 DateTime 校验「2 月 30 日」这类非法日期：它抛 X::OutOfRange，我们当成解析失败。
    my $dt = try DateTime.new(
        :$year, :$month, :$day, :$hour, :$minute, :$second, :timezone(0),
    );
    return Instant without $dt;
    $dt.Instant;
}

# RFC 6265 §5.1.3：host == domain，或 host 以 ".domain" 结尾。
# IP 地址不做后缀匹配（否则 "1.2.3.4" 会被 ".2.3.4" 匹配上）。
sub domain-match(Str $host, Str $domain --> Bool) {
    return True if $host eq $domain;
    return False if is-ip-address($host);
    $host.ends-with('.' ~ $domain);
}

sub is-ip-address(Str $host --> Bool) {
    return True if $host.contains(':')                      # IPv6 字面量
        || $host.starts-with('[');
    # 注意 `~~ /.../` 返回 Match，声明了 --> Bool 就得显式转成布尔
    so $host ~~ /^ \d**1..3 '.' \d**1..3 '.' \d**1..3 '.' \d**1..3 $/;
}

has Cookie %!store;

# 罐子会被多个线程同时用：门面在重定向的每一跳都 absorb，而用户完全可以
# `start { $c.get(...) }` 并发跑。Hash 的并发读写在 MoarVM 上不是原子的
# （扩容时重哈希最危险，会丢条目甚至崩），所以所有「读或改 %!store」的入口
# 一律进锁。锁只护内存操作，不包住网络 IO —— 不会让并发退化成串行。
has Lock $!lock .= new;

method absorb(Rakuest::Response $resp --> Nil) {
    return unless $resp.url;
    my $url = parse-url($resp.url);

    $!lock.protect({
        for $resp.all-headers('set-cookie') -> $raw {
            my $cookie = self!parse($raw, $url);
            next without $cookie;
            if $cookie.expired {
                %!store{$cookie.key}:delete;
            } else {
                %!store{$cookie.key} = $cookie;
            }
        }
    });
    Nil;
}

method !parse(Str $raw, $url --> Cookie) {
    my @bits = $raw.split(';').map(*.trim);
    my $pair = @bits.shift // '';
    my $sep = $pair.index('=');
    return without $sep;                 # 没有等号：不是 cookie

    my $name = $pair.substr(0, $sep).trim;
    my $value = $pair.substr($sep + 1).trim;
    # RFC 6265 §5.3 第 5 步：name 与 value 同时为空则整条丢弃
    return if !$name.chars && !$value.chars;

    my %attr;
    for @bits -> $b {
        next unless $b.chars;
        if $b.contains('=') {
            my ($k, $v) = $b.split('=', 2);
            %attr{$k.trim.lc} = $v.trim;
        } else {
            %attr{$b.lc} = '';
        }
    }

    # --- Domain：必须是请求域名的后缀，否则忽略这条属性（回落到 host-only）---
    # 不加这层校验的话，`Set-Cookie: a=1; Domain=com` 会让 cookie 发给所有 .com 站点。
    my $host = $url.host.lc;
    my $domain = $host;
    my Bool $host-only = True;
    with %attr<domain> {
        my $d = $_.lc;
        $d = $d.substr(1) if $d.starts-with('.');
        if $d.chars && domain-match($host, $d) {
            $domain = $d;
            $host-only = False;
        }
    }

    # --- Path：不是以 / 开头的一律忽略，回落到默认路径 ---
    my $path = %attr<path> // '';
    $path = $url.dir unless $path.starts-with('/');

    # --- 过期时间：Max-Age 优先于 Expires（RFC 6265 §5.3 第 11、12 步）---
    my $expires;
    my Bool $has-max-age = False;
    with %attr<max-age> {
        # 必须以数字或减号开头，否则整条属性无效（"abc" 不能被当成 0 秒）
        if $_ ~~ /^ '-'? \d+ $/ {
            $expires = now + $_.Int;
            $has-max-age = True;
        }
    }
    if !$has-max-age && (%attr<expires>:exists) {
        my $at = parse-cookie-date(%attr<expires>);
        $expires = $at if $at.defined;      # 解析不出来就当会话 cookie
    }

    my %args =
        :$name,
        :$value,
        :$domain,
        :$path,
        secure => %attr<secure>:exists,
        :$host-only;
    %args<expires> = $expires if $expires.defined;
    Cookie.new(|%args);
}

method header-for(Str $url --> Str) {
    my $u = parse-url($url);

    $!lock.protect({
        my @alive;
        my @stale;

        for %!store.values -> $c {
            if $c.expired {
                @stale.push($c.key);
                next;
            }
            next if $c.secure && $u.scheme ne 'https';

            my $host-ok = $c.host-only
                ?? $u.host eq $c.domain
                !! domain-match($u.host, $c.domain);
            next unless $host-ok;
            next unless $u.path.starts-with($c.path);

            @alive.push($c);
        }

        # 顺手清理过期项：不然长期不重启的进程里会一直堆着僵尸 cookie。
        %!store{$_}:delete for @stale;

        # RFC 6265 §5.4：路径更具体的先发（同名 cookie 才有意义），
        # 路径一样就按名字排，保证输出稳定（方便断言，也避免抖动）。
        @alive.sort({ (-$_.path.chars, $_.name) }).map({ "{$_.name}={$_.value}" }).join('; ');
    });
}

method elems(--> Int) { $!lock.protect({ %!store.elems }) }

method clear(--> Nil) { $!lock.protect({ %!store = () }); Nil }
