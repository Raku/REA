unit module Rakuest::Encoding;

use Rakuest::Error;
use Rakuest::Zlib;

# 响应体解码（Content-Encoding）。
#
# 为什么要自己写：Cro::HTTP::Client **不做** Content-Encoding 解压
# ——它只按 Content-Type 解析 body，gzip 字节会原样交出来。
# 而 curl 的 --compressed、httpx 的默认行为都是自动解。
#
# 范围有意收窄：只支持 gzip / deflate / identity。
# br（brotli）、zstd 在 Raku 生态里没有能用的绑定，遇到了就明确报错，
# 而不是把压缩字节当成正文交出去。

sub gzip(--> Str) is export { 'gzip' }

# 归一化：HTTP 里 x-gzip 是 gzip 的别名，大小写不敏感，可能带参数。
sub normalize-encoding(Str $encoding --> Str) is export {
    my $e = $encoding.trim.lc;
    $e = $e.subst(/';'.*$/, '');      # gzip;q=0.5 之类
    given $e {
        when 'x-gzip' { 'gzip' }
        when '' | 'identity' { '' }
        default { $e }
    }
}

# Content-Encoding 可能是逗号分隔的多层（很少见，但规范允许）。
sub encodings(Str $header --> List) is export {
    $header.split(',').map({ normalize-encoding($_) }).grep(*.chars).List;
}

sub supported-encoding(Str $encoding --> Bool) is export {
    normalize-encoding($encoding) ∈ ('', 'gzip', 'deflate');
}

# 一次性解压。$encoding 为 '' 时原样返回。
sub decode-body(Blob $data, Str $encoding --> Blob) is export {
    my $enc = normalize-encoding($encoding);
    return $data unless $enc.chars;
    return $data if $data.elems == 0;

    my $out = do given $enc {
        when 'gzip' { decode-gzip($data) }
        when 'deflate' { decode-deflate($data) }
        default {
            die X::Rakuest::ContentEncoding.new(:$encoding);
        }
    };

    # 多层编码从内到外解（header 顺序是「应用的顺序」）。
    $out;
}

# 解压走自己那份最小 zlib 绑定（Rakuest::Zlib）。
#
# 不用 Compress::Zlib 的原因写在那个模块的文件头：它的 z_stream 把 C 指针存进
# 受 GC 管理的字段里，和 Cro 的 HTTPS 栈一起加载时 inflate 必崩。这里把所有失败
# 都翻译成 X::Rakuest::ContentEncoding —— 调用方只需要认这一种异常。
sub inflate-or-die(Str $encoding, Blob $data, Str $format --> Blob) {
    my $out;
    {
        $out = Rakuest::Zlib::inflate-bytes($data, $format);
        CATCH {
            default {
                die X::Rakuest::ContentEncoding.new(
                    :$encoding,
                    detail => "$encoding 解压失败：{.message}",
                );
            }
        }
    }
    $out;
}

sub decode-gzip(Blob $data --> Blob) is export {
    inflate-or-die('gzip', $data, 'gzip');
}

# HTTP 的 `deflate` 规范上是 zlib 容器（RFC 1950），但历史上不少服务器
# 发的是裸 deflate（RFC 1951）。两种都试，先 zlib 后 raw。
sub decode-deflate(Blob $data --> Blob) is export {
    my $zlib = try { inflate-or-die('deflate', $data, 'zlib') };
    return $zlib if $zlib.defined;

    my $raw = try { inflate-or-die('deflate', $data, 'raw') };
    return $raw if $raw.defined;

    die X::Rakuest::ContentEncoding.new(
        encoding => 'deflate',
        detail => 'zlib 与 raw deflate 两种解释都失败',
    );
}

# 服务端可能用多值 header（`Content-Encoding: gzip` 只该有一个，
# 但多层编码会写成 `gzip, br`）。按顺序逐个解。
sub decode-chain(Blob $data, Str $header --> Blob) is export {
    my $out = $data;
    for encodings($header).reverse -> $enc {
        $out = decode-body($out, $enc);
    }
    $out;
}

# 我们愿意接受哪些编码。
sub accept-encoding(--> Str) is export { 'gzip, deflate' }
