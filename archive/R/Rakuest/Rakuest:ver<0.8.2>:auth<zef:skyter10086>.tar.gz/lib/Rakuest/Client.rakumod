unit class Rakuest::Client;

use JSON::Fast;
use Rakuest::Body;
use Rakuest::CookieJar;
use Rakuest::Encoding;
use Rakuest::Error;
use Rakuest::Event;
use Rakuest::Form;
use Rakuest::Progress::Tracker;
use Rakuest::Request;
use Rakuest::Response;
use Rakuest::Transport;
use Rakuest::Transport::Cro;
use Rakuest::URI;
use Rakuest::Util;

# 版本号只在这里写一次，user-agent 与 META6 靠它对齐。
my constant VERSION = '0.8.2';

# hooks 只认这四个名字。拼错（response 写成 responses）在构造期就炸，
# 而不是安静地什么都不发生 —— 观测代码最怕的就是「看起来装上了」。
my constant HOOK-EVENTS = <request response redirect retry>;

# 门面 / 策略层。所有后端共享的语义都在这里：
#   重定向、cookie、认证、重试、超时、能力协商、URL 拼接、请求体序列化。
#
# 传输后端只做一跳（见 Rakuest::Transport），因此换后端时行为不变。
has Str $.base-url = '';
has %.headers;
has %.params;
has Numeric $.timeout;
has Numeric $.connect-timeout = 10;
has Bool $.follow = True;
has Int $.max-redirects = 10;
has Int $.retry = 0;
has Numeric $.retry-delay = 1;

# 除了传输失败，这些状态码也重试（只在 retry > 0 时有意义）。
# 429/503 是服务端明说「等会儿再来」，重试它们是用户写 retry 的本意；
# 401/404 之类重试只是白白放大流量，所以默认不碰。
# 想完全不重试状态码：retry-status => set()。
has Set $.retry-status = set(429, 503);

# Retry-After 是服务端说了算的等待时间，恶意/配置错误的服务端能让你挂一小时。
# 超过这个秒数就截断，按自己的 retry-delay 走。
has Numeric $.max-retry-delay = 60;
has $.auth;
has Bool $.cookies = True;
has Str $.user-agent = 'Rakuest/' ~ VERSION;

# 自动发 Accept-Encoding 并解 gzip/deflate。
# 流式请求（download）不协商 —— 解压要在流上做增量解码，那属于另一层，
# 而且大文件下载通常用 Content-Type（.tar.gz），不走 Content-Encoding。
has Bool $.compress = True;
has Str $.proxy;
has Bool $.insecure = False;

# TLS 信任根。优先级：insecure > ca-file > ca-path > auto-ca 探测。
# Windows 上 OpenSSL 读不到系统证书库，靠 ca-file 指向一份 PEM bundle 才能正常校验 HTTPS。
has Str $.ca-file;
has Str $.ca-path;
has Bool $.auto-ca = True;

# scheme => Transport，留给将来的 ftp://、socks5:// 等；不填则 http/https 用默认后端。
has %.transports;

# 传输进度：progress => -> Rakuest::Progress $p { ... }。
# 每次回调是一份不可变快照（phase/done/total/fraction/percent/rate/eta）。
# 单次请求可用 progress => False 关掉；也可以用别的回调覆盖。
has $.progress;

# 生命周期钩子：hooks => { request => &cb, response => &cb, redirect => ..., retry => ... }。
# 值可以是单个可调用对象，也可以是它们的列表。事件见 Rakuest::Event。
has %.hooks;

# 两次进度回调之间的最小间隔（秒）。0 = 每个传输 tick 都报。
# curl 每 64KB tick 一次，1GB 就是一万多次；0.1（10Hz）对 UI 足够。
has Numeric $.progress-interval = 0;

has Rakuest::Transport $!transport;
has $!jar;
has Bool $!closed = False;

# 懒建默认后端要进锁：并发下两个线程可能同时判断「还没有后端」，
# 各自 new 一个 Cro 客户端 —— 多出来的那个连接池没人关，而且最后写赢的那个
# 会让先前的请求和后来的请求挂在不同的池上（cookie 一致、连接不复用）。
has Lock $!init-lock .= new;

submethod TWEAK(:$transport) {
    $!transport = $transport with $transport;
    $!jar = Rakuest::CookieJar.new if $!cookies;
    self!check-progress;
    self!check-hooks;
}

# progress 要的是可调用对象。False / Nil 是「不要」的两种写法，
# 别的类型（True、Hash、字符串……）都是笔误，当场说清楚，别等第一个字节才炸。
method !check-progress(--> Nil) {
    return unless $!progress.defined;
    return if $!progress === False;
    return if $!progress ~~ Callable;
    die X::Rakuest.new(
        detail => "progress 要一个可调用对象（收到 {$!progress.^name}）；"
            ~ '不想要进度写 progress => False',
    );
}

method !check-hooks(--> Nil) {
    for %!hooks.keys -> $name {
        die X::Rakuest.new(
            detail => "未知的 hook：$name（可用：{HOOK-EVENTS.join(' / ')}）",
        ) unless $name ∈ HOOK-EVENTS;
        for self!callbacks($name) -> $cb {
            die X::Rakuest.new(
                detail => "hook '$name' 的值必须是可调用对象，收到 {$cb.^name}",
            ) unless $cb ~~ Callable;
        }
    }
}

# 一个 hook 可以挂多个回调：单个可调用对象就是「只有一个的列表」。
method !callbacks(Str $name --> List) {
    my $v = %!hooks{$name};
    return () without $v;
    return ($v,) if $v ~~ Callable;
    $v ~~ Positional ?? $v.list !! ($v,);
}

# 同步触发钩子。异常直接冒到 request() 的调用点：那是用户的 bug，
# 吞掉只会让「钩子里少做了一步」变成更难查的问题。
method !emit(Str $name, *%data --> Nil) {
    my @cbs = self!callbacks($name);
    return unless @cbs.elems;
    my $event = Rakuest::Event.new(:$name, data => %data);
    .($event) for @cbs;
    Nil;
}

# 每次「一跳的一次尝试」一个 tracker：进度从 0 开始，重试/换跳都不会
# 把上一段的字节混进来（快照里的 attempt / hop 说明了这是哪一段）。
method !tracker(Rakuest::Request $req, Int $attempt, Int $hop) {
    my $cb = $req.progress;
    return Nil unless $cb ~~ Callable;
    Rakuest::Progress::Tracker.new(
        url     => $req.url,
        method  => $req.method,
        :$attempt,
        :$hop,
        callback => $cb,
        interval => $!progress-interval,
    );
}

method transport(--> Rakuest::Transport) { self!transport }

# 关掉 cookie（:!cookies）时返回类型对象而不是 Nil —— 声明了返回类型就
# 必须给个同类型的值，Nil 会让调用方拿到一句 Type check failed。
method cookies(--> Rakuest::CookieJar) { $!jar // Rakuest::CookieJar }

method !transport(--> Rakuest::Transport) {
    return $!transport with $!transport;

    # 双重检查：锁外先判一次（常见路径无竞争），进来再判一次。
    # 块里不用 `return`（会从方法返回，锁的释放依赖 protect 的 LEAVE，
    # 别在这里赌实现细节），靠赋值 + 末尾统一返回。
    $!init-lock.protect({
        unless $!transport.defined {
            my %ca = self.ca-settings;
            $!transport = Rakuest::Transport::Cro.new(
                :$!connect-timeout,
                |($!proxy.defined ?? (proxy => $!proxy) !! ()),
                |(%ca.elems ?? (ca => %ca) !! ()),
            );
        }
    });
    $!transport;
}

# 把「用户想怎么校验」翻译成后端能直接用的 ca 设置。
# 空 Hash 表示「什么都不指定，用 OpenSSL 默认行为」。
method ca-settings(--> Hash) {
    return %( :insecure ) if $!insecure;

    my %ca;
    my $file = $!ca-file.defined && $!ca-file.chars
        ?? $!ca-file
        !! ($!auto-ca ?? find-ca-bundle() !! Str);
    %ca<ca-file> = $file.Str if $file.defined && $file.Str.chars;
    %ca<ca-path> = $!ca-path if $!ca-path.defined && $!ca-path.chars;
    %ca;
}

method get(Str $url, *@rest, *%opt --> Rakuest::Response)    { self.request('GET', $url, |self!opts(@rest, %opt)) }
method head(Str $url, *@rest, *%opt --> Rakuest::Response)   { self.request('HEAD', $url, |self!opts(@rest, %opt)) }
method post(Str $url, *@rest, *%opt --> Rakuest::Response)   { self.request('POST', $url, |self!opts(@rest, %opt)) }
method put(Str $url, *@rest, *%opt --> Rakuest::Response)    { self.request('PUT', $url, |self!opts(@rest, %opt)) }
method patch(Str $url, *@rest, *%opt --> Rakuest::Response)  { self.request('PATCH', $url, |self!opts(@rest, %opt)) }
method delete(Str $url, *@rest, *%opt --> Rakuest::Response) { self.request('DELETE', $url, |self!opts(@rest, %opt)) }

method request(Str $method, Str $url, *@rest, *%opt --> Rakuest::Response) {
    self!check-open;
    my $req = self!build($method, $url, self!opts(@rest, %opt));
    self!check-capability($req);
    self!send($req);
}

method download(Str $url, $dest, *@rest, *%opt --> Rakuest::Response) {
    self!check-open;
    my $req = self!build('GET', $url, self!opts(@rest, %opt), :stream);
    self!check-capability($req);
    my $resp = self!send($req);
    # 4xx/5xx 也要先把流排空再抛，否则传输线程会继续往没人读的缓冲里灌数据。
    unless $resp.is-success {
        $resp.drain;
        $resp.raise-for-status;
    }
    $resp.stream-to($dest);
    $resp;
}

# Raku 里 `'key' => value` 是**位置**参数（只有裸字 `key => value` 才被解析成
# 具名参数）。几乎所有人都会写成前者——那是 Python/JS 的习惯——于是撞上
# 「Too many positionals passed」这种完全看不出原因的错误。
# 这里把位置上的 Pair 统一收编成选项，非 Pair 则给出能读懂的话。
method !opts(@rest, %opt --> Hash) {
    my %all = |%opt;
    for @rest -> $p {
        die X::Rakuest.new(detail => "无法识别的参数：{$p.raku}（选项要写成 name => value）")
            unless $p ~~ Pair;
        %all{$p.key} = $p.value;
    }
    %all;
}

method close(--> Nil) {
    $!closed = True;
    # 后端持有的连接（Curl 的空闲句柄池、Cro 的连接池）也要一起放掉，
    # 否则「关掉客户端」只是不再用它，socket 还开着。
    $!transport.close with $!transport;
    .close for %!transports.values;
    $!jar = Nil;
    Nil;
}

method !check-open(--> Nil) {
    die X::Rakuest.new(detail => '客户端已关闭') if $!closed;
}

method !absolute(Str $url --> Str) {
    return $url if $url.match(rx{ ^ <[A..Z a..z]>+ '://' });
    die X::Rakuest.new(detail => "相对 URL 需要先设置 base-url：$url") unless $!base-url;
    resolve-url($!base-url, $url);
}

method !transport-for(Str $url --> Rakuest::Transport) {
    my $scheme = parse-url($url).scheme;
    return %!transports{$scheme} if %!transports{$scheme}:exists;
    return self!transport if $scheme eq 'http' || $scheme eq 'https';
    die X::Rakuest::UnsupportedScheme.new(:$scheme);
}

method !check-capability(Rakuest::Request $req --> Nil) {
    my $transport = self!transport-for($req.url);
    with $req.http-version {
        my $cap = 'http' ~ ($_ eq '1.1' ?? '1' !! $_);
        die X::Rakuest::UnsupportedCapability.new(capability => $cap)
            unless $transport.supports($cap);
    }
}

# 门面的核心循环：一跳由后端完成，重定向由这里串起来。
method !send(Rakuest::Request $req --> Rakuest::Response) {
    my $current = $req;
    my $hops = 0;
    my @history;

    loop {
        my $resp = self!send-once($current, $hops + 1);
        $!jar.absorb($resp) with $!jar;

        # follow 是请求级的：调用方可以只对这一次说「别跟」。
        # 语义与 httpx 一致：**跟过**的跳才进 history，最后一跳就是响应本身。
        # 所以「没跟的 302」history 是空的 —— 它就在你手里，不用再去历史里翻。
        my $keep = sub ($r) { @history.elems ?? $r.with-history(@history) !! $r };
        return $keep($resp) unless $current.follow && $resp.is-redirect;

        my $location = $resp.header('location');
        return $keep($resp) without $location;

        die X::Rakuest::TooManyRedirects.new(max => $current.max-redirects)
            if ++$hops > $current.max-redirects;

        # 流式响应要中途换道：把这一跳的流排空，否则传输线程会一直往
        # 没人读的缓冲里塞数据（大响应下就是内存泄漏）。
        $resp.drain if $resp.has-body-stream;

        @history.push($resp);
        my $next = $current.redirected($location, $resp.status);
        # 在门面里发，不在后端：后端只管一跳，「跳了几次、跳到哪」是策略层的事。
        self!emit('redirect',
            from => $current.url, to => $next.url,
            status => $resp.status, response => $resp);
        $current = $next;
    }
}

# 单跳 + 重试。
#
# 两类失败分开处理，因为语义完全不同：
#   · 传输失败（连不上、TLS、断流）→ 没有响应可看，退避后重发；
#   · 429/503 这类「服务端明说等会儿再来」→ 有响应，但值得再问一次。
# 后者的等待时间优先听服务端的 Retry-After（秒数或 HTTP-date 都合法）。
method !send-once(Rakuest::Request $req, Int $hop = 1 --> Rakuest::Response) {
    my $tries = $!retry + 1;
    my $current = $req;

    loop (my $i = 1; ; $i++) {
        # 一次尝试一个 tracker：重试时进度从 0 重新开始，但 attempt 会变，
        # 调用方分得清「这是新一轮」而不是「怎么倒回去了」。
        my $progress = self!tracker($current, $i, $hop);
        self!emit('request',
            method => $current.method, url => $current.url,
            hop => $hop, attempt => $i);

        my ($resp, $error);
        {
            my $transport = self!transport-for($current.url);
            # 没开进度就别多传一个参数：现有/第三方的后端签名不用改。
            $resp = $progress.defined
                ?? await $transport.request($current, :progress($progress))
                !! await $transport.request($current);
            CATCH { default { $error = $_ } }
        }

        if $resp.defined {
            $resp = self!decode($resp, $current);
            self!emit('response',
                response => $resp, hop => $hop, attempt => $i);
            return $resp if $i >= $tries || !$!retry-status{$resp.status};

            # 流式体只能发一次：重开不了就别装作能重试，把 429 原样交回去。
            # 悄悄补发一个空 body 是最坏的（服务端只看到长度 0）。
            return $resp unless $current.replayable;

            # 这一跳的流必须排空，否则连接不可复用、传输线程还在往缓冲里灌数据。
            $resp.drain if $resp.has-body-stream;
            my $delay = self!status-wait($resp, $i);
            self!emit('retry',
                url => $current.url, attempt => $i, delay => $delay,
                status => $resp.status, response => $resp);
            sleep $delay;
            $current = $current.replayed;
            next;
        }

        die $error unless $error ~~ X::Rakuest::TransportError;
        die $error if $i >= $tries;
        my $delay = $!retry-delay * $i;
        self!emit('retry',
            url => $current.url, attempt => $i, delay => $delay,
            error => $error);
        sleep $delay if $delay > 0;
    }
}

# 429/503 之后等多久：有 Retry-After 就听它的（截断到 max-retry-delay），
# 没有就按自己的线性退避。Retry-After 允许两种写法：
#   429  → 秒数
#   503  → 秒数，或者 HTTP-date（形如 Sun, 06 Nov 1994 08:49:37 GMT）
# HTTP-date 与 cookie 的 IMF-fixdate 是同一个格式，直接复用解析器。
method !status-wait(Rakuest::Response $resp, Int $attempt --> Numeric) {
    my $fallback = $!retry-delay * $attempt;
    my $raw = $resp.header('retry-after');
    return $fallback without $raw;

    my $text = $raw.trim;
    my Int $secs;
    if $text ~~ /^ \d+ $/ {
        $secs = $text.Int;
    } else {
        my $at = try parse-cookie-date($text);
        return $fallback without $at;
        $secs = ($at - now).ceiling;
    }
    return $fallback if $secs <= 0;
    $secs min $!max-retry-delay;
}

# 解压属于策略层（换后端行为不变），所以放在门面而不是后端。
method !decode(Rakuest::Response $resp, Rakuest::Request $req --> Rakuest::Response) {
    return $resp unless $req.compress;
    return $resp if $resp.has-body-stream;
    my $enc = $resp.header('content-encoding') // '';
    return $resp unless $enc.trim.chars;
    $resp.with-body(decode-chain($resp.content, $enc), 'content-encoding', 'content-length');
}

method !build(Str $method, Str $url, %opt, Bool :$stream = False --> Rakuest::Request) {
    my $abs = self!absolute($url);

    # 流式：download() 会传 :stream，用户也可以直接 get(url, stream => True)。
    my Bool $streaming = (%opt<stream> // $stream).Bool;

    my %query;
    %query{.key} = .value for %.params.pairs;
    %query{.key} = .value for (%opt<params> // {}).pairs;
    if %query.elems {
        $abs ~= ($abs.contains('?') ?? '&' !! '?') ~ query-string(%query);
    }

    my %headers;
    %headers{.key} = .value for %.headers.pairs;
    %headers{.key} = .value for (%opt<headers> // {}).pairs;
    # HTTP 头名大小写不敏感。统一成小写，后面所有「有没有这个头」的判断才可靠
    # （否则 'Accept-Encoding' 和 'accept-encoding' 会被当成两个头）。
    %headers = %headers.map({ .key.lc => .value }).Hash;

    # data 有两种身份：单独出现 = 原始请求体；和 files 一起 = multipart 的文本字段
    # （这正是 README 里的上传写法，以前的互斥检查把这种组合直接判死了）。
    my @kinds = <json form files body-stream>.grep({ %opt{$_}:exists });
    die X::Rakuest.new(detail => 'json / form / files / body-stream 一次只能传一种')
        if @kinds.elems > 1;
    die X::Rakuest.new(
        detail => 'data 只能单独用（原始请求体）或与 files 一起用（multipart 文本字段），'
            ~ "不能和 {@kinds[0]} 同时出现",
    ) if %opt<data>:exists && @kinds.elems && @kinds[0] ne 'files';

    my $body;
    my $content-type;
    given (@kinds[0] // '') {
        when 'json' {
            $body = to-json(%opt<json>, :!pretty);
            $content-type = 'application/json';
        }
        when 'form' {
            $body = query-string(%opt<form>);
            $content-type = 'application/x-www-form-urlencoded';
        }
        when 'files' {
            my $mp = Rakuest::Form::Multipart.new;
            if %opt<data>:exists {
                my $fields = %opt<data>;
                die X::Rakuest.new(
                    detail => "files + data 里的 data 要是哈希（文本字段），收到 {$fields.^name}；"
                        ~ '原始请求体请单独用 data =>',
                ) unless $fields ~~ Associative;
                for $fields.pairs -> $p {
                    $mp.add(Rakuest::Form::Part.new(name => $p.key, value => $p.value.Str));
                }
            }
            for %opt<files>.pairs -> $p {
                $mp.add(file-part($p.key, $p.value));
            }
            # 整份表单当成一条字节流发：文件部件边读边传，不再整块进内存。
            $body = $mp.to-stream;
            $content-type = $mp.content-type;
        }
        when 'data' {
            my $d = %opt<data>;
            die X::Rakuest.new(
                detail => "data 只接受 Str / Blob（原始请求体），收到 {$d.^name}；"
                    ~ 'JSON 用 json =>，urlencoded 表单用 form =>，文件上传用 files =>',
            ) unless $d ~~ Str || $d ~~ Blob;
            $body = $d;
        }
        when 'body-stream' {
            $body = to-body-stream(%opt<body-stream>);
            $content-type = 'application/octet-stream';
        }
    }
    $content-type = %opt<content-type> with %opt<content-type>;

    my $auth = %opt<auth> // $!auth;
    %headers<authorization> //= auth-header($auth) with $auth;
    %headers<user-agent> //= $!user-agent;
    # 单次 compress => False 覆盖客户端设置；显式给了 Accept-Encoding 也照用。
    my $compress = %opt<compress> // $!compress;
    %headers<accept-encoding> //= accept-encoding() if $compress && !$streaming;

    if $!jar {
        my $cookie = $!jar.header-for($abs);
        %headers<cookie> //= $cookie if $cookie.chars;
    }

    my %args = :$method, url => $abs, headers => %headers, :$body, stream => $streaming, :$compress;

    # 进度回调也能按单次请求给：progress => &cb 覆盖客户端设置，
    # progress => False 让这一次静默（典型场景：轮询接口不想刷进度条）。
    my $progress-opt = %opt<progress>:exists ?? %opt<progress> !! $!progress;
    if $progress-opt.defined && $progress-opt !=== False && !($progress-opt ~~ Callable) {
        die X::Rakuest.new(
            detail => "progress 要一个可调用对象（收到 {$progress-opt.^name}）；"
                ~ '不想要进度写 progress => False',
        );
    }
    %args<progress> = $progress-opt if $progress-opt ~~ Callable;
    # 重定向策略：单次请求可覆盖（follow => False / max-redirects => 0）。
    # max-redirects <= 0 直接当「不跟随」用 —— 有人会这么写，
    # 不该变成「一跳就抛 TooManyRedirects」的惊喜。
    my $max-redirects = (%opt<max-redirects> // $!max-redirects).Int;
    %args<follow> = (%opt<follow> // $!follow) && $max-redirects > 0;
    %args<max-redirects> = $max-redirects;
    %args<content-type> = $content-type if $content-type.defined;
    my $timeout = %opt<timeout> // $!timeout;
    %args<timeout> = $timeout if $timeout.defined;
    %args<http-version> = %opt<http-version> if %opt<http-version>.defined;
    Rakuest::Request.new(|%args);
}

# auth 支持三种写法：
#   'user:pass'、'Bearer xxx'、{ username => ..., password => ... }、{ bearer => ... }
sub auth-header($auth --> Str) {
    given $auth {
        when Str {
            return $auth if $auth.starts-with('Bearer ');
            return 'Basic ' ~ base64-encode($auth.encode('utf-8'));
        }
        when Hash {
            return 'Bearer ' ~ $auth<bearer> if $auth<bearer>:exists;
            my $user = $auth<username> // '';
            my $pass = $auth<password> // '';
            return 'Basic ' ~ base64-encode("{ $user }:{ $pass }".encode('utf-8'));
        }
        default {
            die X::Rakuest.new(detail => 'auth 只支持 Str（user:pass / Bearer xxx）或 Hash');
        }
    }
}

# files 的一个部件。值是路径 / 句柄 / 流时都按「边读边传」处理：
# 以前这里一律 slurp 成 Blob，一个 2GB 的日志文件就是一次 OOM。
sub file-part(Str $name, $value --> Rakuest::Form::Part) {
    given $value {
        when IO::Path | Str {
            my $path = $value.IO;
            die X::Rakuest.new(detail => "要上传的文件不存在：{$path.Str}") unless $path.e;
            return Rakuest::Form::Part.new(
                :$name,
                filename => $path.basename,
                content-type => guess-content-type($path),
                stream => body-from-path($path),
            );
        }
        when IO::Handle {
            return Rakuest::Form::Part.new(
                :$name,
                filename => $name,
                content-type => 'application/octet-stream',
                stream => body-from-handle($value),
            );
        }
        when Rakuest::Body::Stream {
            return Rakuest::Form::Part.new(
                :$name,
                filename => $name,
                content-type => 'application/octet-stream',
                :stream($value),
            );
        }
        default {
            # Blob / Supply 之类交给统一入口；Blob 就知道长度，Supply 不知道。
            return Rakuest::Form::Part.new(
                :$name,
                filename => $name,
                content-type => 'application/octet-stream',
                stream => to-body-stream($value),
            );
        }
    }
}
