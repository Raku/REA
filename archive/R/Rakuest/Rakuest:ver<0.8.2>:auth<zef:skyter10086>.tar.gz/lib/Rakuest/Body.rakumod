unit module Rakuest::Body;

use Rakuest::Error;

# 请求体的一份「可拉取」抽象：边生成边上传。
#
# 为什么不是 Supply：Supply 是**推**模型，上游想发多快就发多快，中间必然要有
# 缓冲把背压吃掉；文件上传走 Supply 就等于「换个姿势整块读进内存」。
# 拉模型才是上传该有的形状 —— libcurl 的 read 回调本来就是「给我 64KB」，
# 我们直接从文件读这么多给它，内存里永远只有一块。
#
# 契约：
#   · chunk() 每次返回一个 Blob；返回空 Blob（未定义）表示结束。
#   · length 已知时后端可以发 Content-Length（普通请求）；未知时走 chunked。
#   · replayable 为真表示「还能再开一份」，重定向 307/308 需要它。
class Stream is export {
    has &.opener is required;      # 无参闭包 → 一个分块拉取器
    has &.closer;                  # 提前收工时的清理钩子（关句柄 / 取消订阅）
    has Int $.length;              # 总字节数；未定义 = 不知道 → chunked
    has Bool $.replayable = False;

    has &!pull;
    has $!rest;
    has Bool $!exhausted = False;

    # 后端发完就调一次。不能指望 read 一直到 EOF —— curl 按 Content-Length
    # 收满就停，根本不会问最后一次，文件句柄会一直开着。
    method close(--> Nil) {
        &!closer() with &!closer;
        $!exhausted = True;
        Nil;
    }

    # 原始的一块（不经缓冲）。一般用 read()，这个留给「块大小无所谓」的场景。
    method chunk(--> Blob) {
        return Blob if $!exhausted;
        without &!pull { &!pull = &!opener() }

        my $c = &!pull();
        if !$c.defined || ($c ~~ Blob && $c.elems == 0) {
            # 空块即结束。约定死这一条，调用方就不用区分「空块」和「没数据」，
            # 也不会因为上游一直吐空块而空转。
            $!exhausted = True;
            return Blob;
        }
        $c ~~ Blob ?? $c !! ($c ~~ Buf ?? $c.Blob !! $c.Str.encode('utf-8'));
    }

    # 最多要 $max 字节。libcurl 的 read 回调就靠它 —— 它规定一次要多少，
    # 我们给的必须 ≤ 它要的，多出来的留到下次（不然数据会丢）。
    method read(Int $max --> Blob) {
        return Blob if $max <= 0;
        $!rest //= Buf.new;

        while $!rest.elems < $max {
            my $c = self.chunk;
            last unless $c.defined;
            $!rest.append($c);
        }

        return Blob if $!rest.elems == 0;

        my $n = $max < $!rest.elems ?? $max !! $!rest.elems;
        my $out = $!rest.subbuf(0, $n);
        $!rest = $n == $!rest.elems ?? Buf.new !! $!rest.subbuf($n);
        $out;
    }

    # 消费完的流不能重发；能重开的（文件、字节串）给一份新的。
    method replay(--> Stream) {
        die X::Rakuest::BodyReplay.new(
            detail => '流式请求体只能发送一次，重定向需要重发；'
                ~ '请改用 body-stream => 路径（可重开）或先把内容读成 Blob',
        ) unless $!replayable;

        self.WHAT.new(
            opener => &!opener,
            closer => &!closer,
            length => $!length,
            replayable => True,
        );
    }

    method is-exhausted(--> Bool) { $!exhausted }
}

sub body-from-blob(Blob $data --> Stream) is export {
    Stream.new(
        length => $data.elems,
        replayable => True,
        opener => sub {
            my Bool $sent = False;
            sub () {
                return Nil if $sent;
                $sent = True;
                $data;
            }
        },
    );
}

# 大文件上传的主力：每次重开都新建句柄，所以可重放。
#
# 用 remaining 而不是「读到空为止」来收尾：curl 按 Content-Length 收满就停，
# 不会再来要一次，靠 EOF 关句柄等于不关。知道还剩多少，就能在最后一个字节
# 送出去的当下关掉。
sub body-from-path(IO::Path $path, Int :$chunk-size = 64 * 1024 --> Stream) is export {
    die X::Rakuest.new(detail => "要上传的文件不存在：{$path.Str}") unless $path.e;

    my $state = %( handle => IO::Handle );

    Stream.new(
        length => $path.s,
        replayable => True,
        opener => sub {
            .close with $state<handle>;      # 上一轮没读完就重开：先关旧的
            $state<handle> = IO::Handle;

            my $fh = $path.open(:bin);
            $state<handle> = $fh;
            my $remaining = $path.s;

            sub () {
                return Nil if $remaining <= 0;
                my $buf = $fh.read(min($chunk-size, $remaining));
                unless $buf.defined && $buf.elems {
                    $remaining = 0;
                    $fh.close;
                    $state<handle> = IO::Handle;
                    return Nil;
                }
                $remaining -= $buf.elems;
                if $remaining <= 0 {
                    $fh.close;
                    $state<handle> = IO::Handle;
                }
                $buf;
            }
        },
        closer => sub {
            .close with $state<handle>;
            $state<handle> = IO::Handle;
        },
    );
}

# 调用方自己的句柄：关不关由它决定（我们只是读），因此不可重放。
sub body-from-handle($fh, Int :$chunk-size = 64 * 1024, Int :$length --> Stream) is export {
    Stream.new(
        length => $length,
        replayable => False,
        opener => sub {
            sub () {
                my $buf = $fh.read($chunk-size);
                unless $buf.defined && $buf.elems { return Nil }
                $buf;
            }
        },
    );
}

# 推模型中转成拉模型：中间有个 Channel 缓冲，所以上游发得比网络快时内存会涨。
# 真在意内存就用路径/句柄那两种。
sub body-from-supply(Supply $source, Int :$length --> Stream) is export {
    my $state = %( tap => Any, channel => Channel );

    Stream.new(
        length => $length,
        replayable => False,
        opener => sub {
            my $channel = Channel.new;
            my $error;
            $state<channel> = $channel;

            my $tap = $source.tap(
                -> $chunk {
                    $channel.send($chunk ~~ Blob ?? $chunk !! $chunk.Str.encode('utf-8'));
                },
                done => { $channel.close },
                quit => -> $e { $error = $e; $channel.close },
            );
            $state<tap> = $tap;

            sub () {
                # 关闭的通道上 receive 会**抛异常**（"Cannot receive a message on
                # a closed channel"），不是安静地返回空值 —— 必须 try 住。
                my $v = try $channel.receive;

                if $v ~~ Exception {
                    if $error.defined {
                        my $e = $error;
                        $error = Nil;
                        die $e ~~ Exception
                            ?? $e
                            !! X::Rakuest::TransportError.new(detail => $e.Str);
                    }
                    return Nil;      # 正常结束
                }
                $v;
            }
        },
        # 后端提前收工时把订阅断掉，否则上游还在往一个没人读的通道里灌。
        closer => sub {
            with $state<tap> { .close }
            with $state<channel> { .close }
        },
    );
}

# 门面收到的各种写法统一收编成 Stream。
#   路径（IO::Path / Str）→ 打开文件按块读
#   IO::Handle            → 直接读
#   Supply                → Channel 中转
#   Blob                  → 单块
sub to-body-stream($source --> Stream) is export {
    my $src = $source // '';
    given $src {
        when Stream { return $src }
        when Supply { return body-from-supply($src) }
        when Blob { return body-from-blob($src) }
        when Str {
            return body-from-path($src.IO);
        }
        when IO::Path { return body-from-path($src) }
        when IO::Handle { return body-from-handle($src) }
        default {
            die X::Rakuest.new(
                detail => "body-stream 只接受 Supply / IO::Handle / IO::Path / Blob，"
                    ~ "收到的是 {$src.^name}",
            );
        }
    }
}
