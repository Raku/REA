unit class Rakuest::Progress;

# 一次传输进度的**快照**。不可变，每次回调都是新的一份。
#
# 为什么给快照而不是「可变的计数器 + 让用户自己读最新值」：回调是在传输
# 线程上被调的，用户还没处理完的对象转眼就会被下一次更新覆盖。快照可以
# 安全地塞进队列、打日志、或者和上一份相减算瞬时速度。
#
# total 未定义表示「不知道总长」（chunked 上传、没有 Content-Length 的响应）。
# 这种时候 fraction / percent / eta 一律返回 Nil —— 硬编成 0 或 100 只会让
# 进度条说谎，而那正是排查「到底卡在哪」时最不能接受的事。

has Str $.phase is required;     # 'upload' | 'download'
has Int $.done = 0;              # 本阶段已传输的字节
has Int $.total;                 # 总字节；未定义 = 不知道
has Str $.url = '';
has Str $.method = '';
has Int $.attempt = 1;           # 第几次尝试（重试会从头计数）
has Int $.hop = 1;               # 第几跳（重定向链）
# 默认值必须用 Duration.new(0)：`0.Duration` 在 Rakudo 2026.11 上编译得过、
# 运行到属性初始化时抛「No such method 'Duration' for invocant of type 'Int'」。
has Duration $.elapsed = Duration.new(0);   # 本阶段已用时

# 0..1。total 未知时是 Nil。
method fraction() {
    return Nil without $!total;
    return 1 if $!total <= 0;
    ($!done / $!total) min 1;
}

# 0..100，保留一位小数（进度条只想要一个数，调用方不必自己再格式化）。
method percent() {
    my $f = self.fraction;
    return Nil without $f;
    ($f * 1000).round / 10;
}

# 平均速度（字节/秒）。注意是**本阶段平均**，不是瞬时值：瞬时速度要靠调用方
# 自己拿两次快照相减，库不替它猜窗口大小。
method rate(--> Numeric) {
    return 0 if $!elapsed <= 0;
    $!done / $!elapsed;
}

method eta() {
    return Nil without $!total;
    my $left = $!total - $!done;
    return 0 if $left <= 0;
    my $rate = self.rate;
    return Nil if $rate <= 0;
    $left / $rate;
}

method complete(--> Bool) { $!total.defined && $!done >= $!total }

method to-hash(--> Hash) {
    %(
        phase   => $!phase,
        done    => $!done,
        total   => $!total,
        url     => $!url,
        method  => $!method,
        attempt => $!attempt,
        hop     => $!hop,
        elapsed => $!elapsed,
        fraction => self.fraction,
        percent  => self.percent,
        rate     => self.rate,
        eta      => self.eta,
    );
}

method gist(--> Str) {
    my $size = $!total.defined ?? "{$!done}/{$!total}" !! "{$!done}";
    my $pct = self.percent;
    my $tail = $pct.defined ?? " {$pct}%" !! ' ?%';
    "Rakuest::Progress({$!phase} {$size} bytes{$tail})";
}
