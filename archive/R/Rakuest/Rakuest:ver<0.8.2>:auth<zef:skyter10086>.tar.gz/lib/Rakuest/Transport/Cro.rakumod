use Cro::HTTP::Client;
use Cro::HTTP::BodySerializers;
use Rakuest::Body;
use Rakuest::Error;
use Rakuest::Progress::Tracker;
use Rakuest::Request;
use Rakuest::Response;
use Rakuest::Transport;
use Rakuest::URI;

# 默认后端：纯 Raku（Cro::HTTP::Client）。
# 只做一跳 —— 重定向、cookie、认证、重试都在 Rakuest::Client。
class Rakuest::Transport::Cro does Rakuest::Transport {
    has Numeric $.connect-timeout = 10;
    has Str $.proxy;
    has Bool $.insecure = False;

    # 直接透传给 IO::Socket::Async::SSL 的 TLS 参数：
    #   ca-file => '...pem'、ca-path => '/etc/ssl/certs'、insecure => True
    has %.ca;

    has $!client;

    method capabilities(--> Set) { set <http1 http2> }

    # Cro 的连接复用挂在 client 实例上，所以「关掉」= 丢掉实例。
    method close(--> Nil) {
        $!client = Nil;
        Nil;
    }

    # 惰性构建：一个后端实例 = 一个连接池（Cro 的连接复用挂在 client 实例上）。
    method !cro-client(--> Cro::HTTP::Client) {
        return $!client with $!client;
        my %opts = timeout => { connection => $!connect-timeout };
        my %ca = %!ca.elems ?? %!ca !! ($!insecure ?? %( :insecure ) !! %());
        %opts<ca> = %ca if %ca.elems;
        %opts<http-proxy> = $!proxy if $!proxy.defined;
        %opts<https-proxy> = $!proxy if $!proxy.defined;
        # Cro 的请求序列化器默认**不含** SupplyFallback（只有响应侧有），
        # 不补这一项的话「Supply 作请求体」会直接抛 NoneApplicable。
        # 用 add- 而不是 body-serializers：后者会整体替换，把 json/form 弄丢。
        %opts<add-body-serializers> = [Cro::HTTP::BodySerializer::SupplyFallback];
        $!client = Cro::HTTP::Client.new(|%opts);
    }

    method request(Rakuest::Request $req, Rakuest::Progress::Tracker :$progress --> Promise) {
        start {
            self!guard-https-proxy($req.url);
            my $started = now;
            # 请求体发完（或中途失败）都要收掉：关文件句柄、断上游订阅。
            LEAVE { $req.body.close if $req.body ~~ Rakuest::Body::Stream; }

            my %hdr = $req.headers;
            # 流式请求体自己决定长度（Cro 见不到 content-length 就写 chunked），
            # 调用方若手写了 content-length，那就是错的，删掉免得冲突。
            %hdr<content-length>:delete if $req.body ~~ Rakuest::Body::Stream;

            my %args = follow => False;
            %args<headers> = %hdr.pairs.List if %hdr.elems;
            %args<body> = self!cro-body($req.body, $progress) with $req.body;
            %args<content-type> = $req.content-type with $req.content-type;
            %args<timeout> = { total => $req.timeout } with $req.timeout;
            %args<http> = do {
                with $req.http-version {
                    $_ eq '1.1' ?? <1.1> !! ($_ eq '2' ?? <2> !! <1.1 2>);
                } else {
                    <1.1 2>;
                }
            };

            my $r;
            {
                $r = await self!cro-client.request($req.method, $req.url, |%args);
                CATCH {
                    when X::Cro::HTTP::Error {
                        # 4xx/5xx 在 Cro 里是异常，但它是 HTTP 语义的一部分：
                        # 转回 Response，别让它以 Cro 异常的形式泄漏出去。
                        $r = .response;
                        die X::Rakuest::TransportError.new(
                            cause => $_,
                            detail => 'HTTP 错误缺少响应对象',
                        ) without $r;
                    }
                    default {
                        # 进度回调里的异常要原样交出去（用户写的是 `die "磁盘满了"`
                        # 就该看到「磁盘满了」），不要被包成 TransportError。
                        die $progress.failure
                            if $progress.defined && $progress.failure.defined;
                        # 带上「有没有 CA bundle」：证书校验失败时这句话决定了
                        # 该提示「给它一份根证书」还是「证书链本身对不上」。
                        die X::Rakuest::TransportError.new(
                            cause => $_, ca-loaded => %!ca<ca-file>:exists,
                        );
                    }
                }
            }

            self!to-response($r, now - $started, $req.stream, $req.url, $progress);
        }
    }
    # HTTPS 走代理在 Cro 里是坏的：!get-proxy-url 只是把绝对 URI 明文发给代理，
    # 没有 CONNECT 隧道。结果是 400，严重的是 Authorization 会以明文过代理。
    # 这里宁可拒绝，也不静默降级成「假成功」。
    method !guard-https-proxy(Str $url --> Nil) {
        return unless parse-url($url).scheme eq 'https';
        my $proxy = $!proxy // '';
        $proxy = %*ENV<HTTPS_PROXY> // '' unless $proxy.chars;
        return unless $proxy.chars;
        return if self!no-proxy($url);
        die X::Rakuest::ProxyUnsupported.new(:$proxy);
    }

    # 与 Cro 内部一致的 NO_PROXY 语义（'*' 或后缀匹配）。
    method !no-proxy(Str $url --> Bool) {
        my $list = %*ENV<NO_PROXY> // '';
        return False unless $list.chars;
        my $host = parse-url($url).host;
        for $list.split(',') -> $m {
            my $matcher = $m.trim;
            next unless $matcher.chars;
            return True if $matcher eq '*' || $host.ends-with($matcher);
        }
        False;
    }

    method !cro-body($body, $progress) {
        if $body ~~ Rakuest::Body::Stream {
            if $progress.defined && $body.length.defined {
                $progress.set-total('upload', $body.length);
            }
            # 拉模型 → Cro 的 Supply。没有 content-length 时 Cro 会写
            # Transfer-Encoding: chunked，正是「边生成边上传」要的形状。
            # 进度就算在这里：Cro 从这条 Supply 拉走多少，就是发出去多少。
            return supply {
                loop {
                    my $chunk = $body.chunk;
                    last without $chunk;
                    $progress.advance('upload', $chunk.elems) with $progress;
                    $progress.abort-if-failed with $progress;
                    emit $chunk;
                }
                $progress.finish('upload') with $progress;
            };
        }
        # multipart 已经在 Rakuest::Request 里换成 Stream（见那里的 TWEAK），
        # 所以这里不再有自己的 Form 分支 —— 少一条永远走不到的路。
        #
        # 非流式体（JSON / 表单 / 小文件）是一整块：Cro 自己发，中间没有可数的
        # 时刻，所以只报一次「已完成」。总长未知的 Str 也照报，只是 total 为空。
        if $progress.defined && $body.defined {
            my $bytes = $body ~~ Blob
                ?? $body.elems
                !! ($body ~~ Str ?? $body.encode('utf-8').elems !! 0);
            $progress.set-total('upload', $bytes);
            $progress.advance('upload', $bytes);
            $progress.abort-if-failed;
            $progress.finish('upload');
        }
        return $body;
    }

    method !to-response($r, Duration $elapsed, Bool $stream, Str $url, $progress --> Rakuest::Response) {
        my %headers;
        my @header-list;
        for $r.headers -> $h {
            my $k = $h.name.lc;
            @header-list.push($k => $h.value);
            %headers{$k} = %headers{$k}:exists
                ?? "{%headers{$k}}, {$h.value}"
                !! $h.value;
        }

        # 注意：不要用 ~$r.request.uri —— 走 HTTP 代理时 Cro 会把它变成代理地址，
        # cookie 域名匹配和对外报告的 URL 都会错。

        # Content-Length 拿来当下载总长。别的地方可能是 "123, 123"（重复头），
        # Int 会失败 —— 那一律当「不知道」处理，而不是炸掉。
        # 先 `// ''` 再 Int：直接对缺席的 Any 调 .Int 会在 stderr 上刷
        # 「Use of uninitialized value」（try 拦不住警告，只拦异常）。
        my $total = (try (%headers<content-length> // '').Int) // -1;
        # 204/304 没有正文，报「下载 0/500」只会让人以为出错了。
        my $bodyless = $r.status == 204 || $r.status == 304;

        if $stream {
            my $source = $r.body-byte-stream;
            with $progress {
                .set-total('download', $total) if $total > 0 && !$bodyless;
                # map 里可以安全地 emit（supply 的 emit 属于 map，不属于 react）；
                # 收尾挂 on-close —— 它在 done 和 close 上都会触发一次，
                # finish 自己是幂等的，所以不用去重。
                my $counted = $source.map(-> $chunk {
                    $progress.advance('download', $chunk.elems);
                    $progress.abort-if-failed;
                    $chunk;
                }).on-close({
                    $progress.finish('download');
                });
                return Rakuest::Response.new(
                    status => $r.status,
                    headers => %headers,
                    header-list => @header-list,
                    :$url,
                    :$elapsed,
                    stream => $counted,
                );
            }
            return Rakuest::Response.new(
                status => $r.status,
                headers => %headers,
                header-list => @header-list,
                :$url,
                :$elapsed,
                stream => $source,
            );
        }

        # 非流式：body-blob 不给中间量，进度只能最后跳一下 —— 那等于没有。
        # 有人要进度时自己把字节流收完（反正整块进内存的成本一样），
        # 这样两个后端、流式/非流式四种组合的进度语义就一致了。
        my $blob = do {
            if $progress.defined && !$bodyless {
                $progress.set-total('download', $total) if $total > 0;
                my $acc = Buf.new;
                react {
                    whenever $r.body-byte-stream -> $chunk {
                        $acc.append($chunk);
                        $progress.advance('download', $chunk.elems);
                        $progress.abort-if-failed;
                    }
                }
                $progress.finish('download');
                $acc;
            }
            else {
                await $r.body-blob;
            }
        };

        Rakuest::Response.new(
            status => $r.status,
            headers => %headers,
            header-list => @header-list,
            :$url,
            :$elapsed,
            blob => $blob,
        );
    }
}
