use NativeCall;
use Rakuest::Body;
use Rakuest::Error;
use Rakuest::Progress::Tracker;
use Rakuest::Request;
use Rakuest::Response;
use Rakuest::Transport;
use Rakuest::URI;
use Rakuest::Util;

# libcurl 后端：把 Cro 做不到的能力一次补齐。
#
#   · HTTP/3（若构建时带 quiche/ngtcp2）
#   · FTP / FTPS / SFTP / SCP / SMTP / IMAP……（真正多协议，不是包一层 HTTP）
#   · SOCKS4/5 代理、代理链
#   · mTLS 客户端证书、CA 目录、证书钉扎
#   · Windows 上用 Schannel，天然读系统证书库（不用再 ca-file 兜底）
#
# 与 Cro 后端完全同构：只做一跳，不管重定向 / cookie / 认证 / 重试，
# 4xx/5xx 一律翻译成正常 Response。
#
# 已知取舍（写清楚比假装没有好）：
#   · 非流式请求仍然整块进内存（这就是普通响应的语义）；
#     流式请求（$req.stream）走 Channel 分块直推，不累积。
#   · Content-Encoding 解压统一由门面做，本后端不开 CURLOPT_ACCEPT_ENCODING。

# ---- 原生库定位 ----
#
# 为什么不能直接写 native('curl')：那个名字只会去找 libcurl.so，而它是
# libcurl*-dev 包才提供的开发软链。只装运行时包的机器上文件名是 libcurl.so.4，
# 于是 Curl 后端被判成「本机没有 libcurl」，所有依赖它的测试整片跳过
# （作者机器上装了 -dev，所以一直没发现）。候选 soname 与目录探测的细节见
# Rakuest::Util 里 locate-native-lib 的说明。
my constant LIB = %*ENV<RAKUEST_CURL_LIB>
    // ($*DISTRO.is-win
        ?? 'libcurl-4'
        !! locate-native-lib('curl', 'libcurl.so.4', 'libcurl.dylib', 'libcurl.4.dylib'));

# ---- curl.h 常量（只抄我们要用的；注意 Raku 里 - 和 _ 不等价） ----
my constant CURLOPT-URL                 = 10002;
my constant CURLOPT-WRITEFUNCTION       = 20011;
my constant CURLOPT-READFUNCTION        = 20012;
my constant CURLOPT-HEADERFUNCTION      = 20079;
my constant CURLOPT-HTTPHEADER          = 10023;
my constant CURLOPT-CUSTOMREQUEST       = 10036;
my constant CURLOPT-COPYPOSTFIELDS      = 10165;
my constant CURLOPT-POSTFIELDSIZE-LARGE = 30120;
my constant CURLOPT-INFILESIZE-LARGE    = 30115;
my constant CURLOPT-UPLOAD              = 46;
my constant CURLOPT-POST                = 47;
my constant CURLOPT-NOBODY              = 44;
my constant CURLOPT-FOLLOWLOCATION      = 52;
my constant CURLOPT-TIMEOUT-MS          = 155;
my constant CURLOPT-CONNECTTIMEOUT-MS   = 156;
my constant CURLOPT-NOSIGNAL            = 99;
my constant CURLOPT-PROXY               = 10004;
my constant CURLOPT-PROXYTYPE           = 101;
my constant CURLOPT-HTTP-VERSION        = 84;
my constant CURLOPT-SSL-VERIFYPEER      = 64;
my constant CURLOPT-SSL-VERIFYHOST      = 81;
my constant CURLOPT-CAINFO              = 10065;
my constant CURLOPT-CAPATH              = 10097;
my constant CURLOPT-SSLCERT             = 10025;
my constant CURLOPT-SSLKEY              = 10087;
my constant CURLOPT-SSLKEYPASSWD        = 10026;
my constant CURLOPT-ERRORBUFFER         = 10010;
my constant CURLOPT-VERBOSE             = 41;
# 低速检测：这两个合用就是「读空闲超时」——速率 < limit 字节/秒 持续 time 秒即中断。
my constant CURLOPT-LOW-SPEED-LIMIT     = 19;
my constant CURLOPT-LOW-SPEED-TIME      = 20;

# 进度回调：NOPROGRESS 默认是 1（关），必须先设 0 才会调 XFERINFO。
# XFERINFO 是 PROGRESSFUNCTION 的替代品，四个数字都是 curl_off_t（int64）。
my constant CURLOPT-NOPROGRESS        = 43;
my constant CURLOPT-XFERINFOFUNCTION  = 20219;

my constant CURLINFO-RESPONSE-CODE = 0x200002;

my constant CURL-HV-ELEVEN = 2;
my constant CURL-HV-TWO = 3;
my constant CURL-HV-THREE   = 30;

my constant CURL-PROXY-HTTP        = 0;
my constant CURL-PROXY-SOCKS4      = 4;
my constant CURL-PROXY-SOCKS5      = 5;
my constant CURL-PROXY-SOCKS4A     = 6;
my constant CURL-PROXY-SOCKS5-HOST = 7;

my constant CURL-VERSION-HTTP2 = 1 +< 16;
my constant CURL-VERSION-HTTP3 = 1 +< 25;

my constant CURL-GLOBAL-ALL = 3;
my constant CURL-ERROR-SIZE = 256;

# read 回调里返回这个值等于告诉 curl「别传了，我这边出错了」，
# perform 会以 CURLE_ABORTED_BY_CALLBACK(42) 返回。
my constant CURL-READFUNC-ABORT = 0x10000000;

# curl 的错误码里只有「超时」值得单独成型（上层可能要按超时做别的策略），
# 其余一律 TransportError。参考 curl.h 的 CURLcode 枚举。
my constant CURL-ERR-TIMEOUT = 28;

# ---- NativeCall 声明 ----
# curl_easy_setopt 是 C 可变参数函数，NativeCall 不支持 varargs，
# 于是按第三个参数的类型各声明一个，共用同一个 C 符号。
sub curl_global_init(long $flags) returns int32 is native(LIB) { * }
sub curl_easy_init() returns Pointer is native(LIB) { * }
sub curl_easy_cleanup(Pointer $handle) is native(LIB) { * }
sub curl_easy_perform(Pointer $handle) returns int32 is native(LIB) { * }
# reset 会清掉所有选项，但**保留**连接缓存 / DNS 缓存 / session ——
# 这正是「复用连接」要的那一半，所以池子里放的是 handle 而不是 socket。
sub curl_easy_reset(Pointer $handle) is native(LIB) { * }
sub curl_easy_strerror(int32 $code) returns Str is native(LIB) { * }
sub curl_slist_append(Pointer $list, Str $s) returns Pointer is native(LIB) { * }
sub curl_slist_free_all(Pointer $list) is native(LIB) { * }
sub curl_version() returns Str is native(LIB) { * }
sub curl_version_info(int32 $age) returns Pointer is native(LIB) { * }
# 回调里把裸指针拷进 Raku 的 Buf 需要 memcpy。Windows 上没有「进程自身」这个
# 解析目标（is native 不带库名会落空），得显式指到 CRT。Linux 上同理不能写 'c'：
# 那会撞上 ld 脚本，必须指名 glibc / musl 的真实 soname（见 locate-native-lib）。
my constant CRT = %*ENV<RAKUEST_CRT_LIB>
    // ($*DISTRO.is-win
        ?? 'msvcrt'
        !! locate-native-lib('c', 'libc.so.6', 'libc.musl-x86_64.so.1',
                             'libc.musl-aarch64.so.1', 'libc.dylib'));

sub memcpy(Pointer $dst, Pointer $src, size_t $n) returns Pointer
    is native(CRT) is symbol('memcpy') { * }

sub curl_setopt_long(Pointer $h, int32 $opt, long $val) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
sub curl_setopt_int(Pointer $h, int32 $opt, int32 $val) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
sub curl_setopt_off(Pointer $h, int32 $opt, int64 $val) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
sub curl_setopt_str(Pointer $h, int32 $opt, Str $val) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
sub curl_setopt_ptr(Pointer $h, int32 $opt, Pointer $val) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
sub curl_setopt_blob(Pointer $h, int32 $opt, Blob $val) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
sub curl_getinfo_long(Pointer $h, int32 $info, CArray[long] $out) returns int32
    is native(LIB) is symbol('curl_easy_getinfo') { * }

sub curl_setopt_writefn(Pointer $h, int32 $opt, &cb (Pointer, size_t, size_t, Pointer --> size_t)) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
sub curl_setopt_headerfn(Pointer $h, int32 $opt, &cb (Pointer, size_t, size_t, Pointer --> size_t)) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
# read 回调的签名和 write 一样，方向反过来：我们往它给的缓冲里填数据。
sub curl_setopt_readfn(Pointer $h, int32 $opt, &cb (Pointer, size_t, size_t, Pointer --> size_t)) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }
# 进度回调返回非 0 表示「中止传输」（CURLE_ABORTED_BY_CALLBACK）。
sub curl_setopt_xferfn(Pointer $h, int32 $opt, &cb (Pointer, int64, int64, int64, int64 --> int32)) returns int32
    is native(LIB) is symbol('curl_easy_setopt') { * }

# ---- 可用性探测 ----
#
# libcurl 的全局状态是进程级的，所以状态也放在模块级：0 未尝试 / 1 可用 / -1 不可用。
# 系统上没装 libcurl 时，这里能给出「后端不可用 + 库名 + 怎么换后端」这种
# 人能看懂的话，而不是让 NativeCall 抛一句 Cannot locate native library。
my Int $GLOBAL-STATE = 0;
my Str $GLOBAL-ERROR = '';

sub ensure-global(--> Bool) {
    return True if $GLOBAL-STATE == 1;
    return False if $GLOBAL-STATE == -1;

    try {
        curl_global_init(CURL-GLOBAL-ALL);
        $GLOBAL-STATE = 1;
    }
    if $GLOBAL-STATE != 1 {
        $GLOBAL-STATE = -1;
        $GLOBAL-ERROR = (try $!.message) // '原生库加载失败';
    }
    $GLOBAL-STATE == 1;
}

sub lib-error(--> Str) { $GLOBAL-ERROR }

sub require-lib(--> Nil) {
    return if ensure-global();
    die X::Rakuest::BackendUnavailable.new(
        backend => 'Rakuest::Transport::Curl',
        library => LIB,
        detail => $GLOBAL-ERROR,
    );
}

# ---- curl_slist：自己构链，不用 curl_slist_append ----
#
# 为什么不调 libcurl 的 curl_slist_append：文档说它返回表头，但 Windows 8.21
# Schannel 构建经 NativeCall 调用时，返回值是**新节点**且看不到链式效果——
# 结果是只有最后一个头被发出（Content-Type 丢失、服务器按表单处理），
# 更糟的是 curl_slist_free_all 释放中段节点会直接段错误。
#
# 这个结构很简单，自己分配内存更可靠，也省掉 free。
#
# 字段顺序**必须**和 libcurl 的 slist.h 完全一致：
#     struct curl_slist { char *data; struct curl_slist *next; };
# data 在前、next 在后。写反了 libcurl 会把字符串指针当节点地址去解引用，
# 进程当场段错误（现象就是「一设请求头就无声崩溃」）。
class CurlSlistNode is repr('CStruct') {
    # 字段用 uint64 存地址，而不是 Pointer：CStruct 里 Pointer 类型的属性是
    # 不可变类型对象，`$node.data = $ptr` 会报「assign requires a concrete
    # object」。uint64 可赋值，位模式与指针完全一致（64 位平台）。
    # CStruct 内存默认清零，所以 next 初始就是 NULL —— 正好是链表结尾。
    has uint64 $.data is rw;
    has uint64 $.next is rw;
}

class Rakuest::Transport::Curl::Slist {
    has Pointer $.head;
    has CurlSlistNode $!last-node;
    has @!nodes;                  # 节点对象：既是保活手段，也便于自检
    has @!bufs;                   # 每行对应的 C 字符串缓冲，同样不能回收

    method add(Str $line --> Nil) {
        my $bytes = $line.encode('utf-8');
        # 必须带初始尺寸构造：零长 CArray 没有原生缓冲，
        # nativecast(Pointer, ...) 会拿到类型对象而不是地址。
        my $buf = CArray[uint8].new(0 xx ($bytes.elems + 1));
        for ^$bytes.elems -> $i { $buf[$i] = $bytes[$i] }
        $buf[$bytes.elems] = 0;   # C 字符串结尾

        my $node = CurlSlistNode.new;
        $node.data = nativecast(Pointer, $buf).Int;

        with $!last-node {
            .next = nativecast(Pointer, $node).Int;
        }
        else {
            $!head = nativecast(Pointer, $node);
        }
        $!last-node = $node;

        @!bufs.push($buf);
        @!nodes.push($node);
    }

    method elems(--> Int) { @!nodes.elems }

    # 自检接口：顺着原生内存把内容读回来。
    # 字段顺序只要和 curl 的 slist.h 有一点偏差，这里读出来的就是垃圾——
    # 所以 t/09 用它守住那次「一设请求头就段错误」的回归。
    method line(Int $i --> Str) {
        my $node = @!nodes[$i];
        die X::Rakuest.new(detail => "slist 下标越界：$i") without $node;
        nativecast(Str, Pointer.new($node.data));
    }

    # 每个节点的 next 地址；最后一项必须是 0（链表结尾）。
    method links(--> List) { @!nodes.map({ $_.next }).List }
}

# curl_version_info_data 的前缀字段（我们只读到这里，后面还有 ares / libidn 等，用不上）
class CurlVersionInfo is repr('CStruct') {
    has int32 $.age;
    has Str $.version;
    has uint32 $.version-num;
    has Str $.host;
    has int32 $.features;
    has Str $.ssl-version;
    has long $.ssl-version-num;
    has Str $.libz-version;
    has Pointer $.protocols;
}

# 一次请求的累积缓冲 + 回调（回调必须保持引用，否则会被 GC 回收）
class CurlExchange {
    has Buf $.body = Buf.new;
    has @.header-blocks;
    has @.current;

    # 流式路径用：分块走 Channel 直推，不碰 $.body。
    has Bool $.streaming = False;
    has Channel $.channel;
    has Promise $.ready;
    # 响应对象是否已经交给调用方（第一块数据到达时就交，让它能边收边处理）。
    has Bool $.delivered is rw = False;
    # 状态码从状态行解析（走代理时前面还有 CONNECT 的 200 块，取最后一个）。
    has Int $.status is rw = 0;
    has Instant $.started is rw;

    # 回调里抛出的异常不能就地抛出（见 apply-options 里的说明），
    # 先存在这里，等 curl_easy_perform 返回后再抛给调用方。
    has $.failure is rw;

    # 进度回调也要在这儿留一份引用：curl 只保存裸函数指针，
    # 闭包被 GC 掉之后下一次 tick 就是野指针（直接段错误）。
    has &.progress-cb is rw;
}

sub build-slist(%hdr) {
    my $list = Rakuest::Transport::Curl::Slist.new;
    for %hdr.keys.sort -> $k {
        my $v = %hdr{$k};
        # 空值的头在 libcurl 里是「把这个头去掉」的写法，所以不能拼成 "name: "
        # （带一个空格会被当成空值以外的意思，行为随版本漂）。
        $list.add(($v.defined && $v.Str.chars) ?? "$k: $v" !! "$k:");
    }
    $list;
}

class Rakuest::Transport::Curl does Rakuest::Transport {
    has Str $.proxy;
    has Str $.proxy-type = 'http';      # http | socks4 | socks5 | socks4a | socks5h
    has Numeric $.connect-timeout = 10;

    # 读空闲超时（秒）。libcurl 没有「read timeout」这种原生选项，
    # 等价物是低速检测：速率低于 1 字节/秒持续这么多秒就中断（CURLE 28）。
    # 0 = 不设，靠总超时兜底。对「服务端接了连接就装死」最有用。
    has Numeric $.read-timeout = 0;

    has Bool $.insecure = False;
    has Str $.ca-file;
    has Str $.ca-path;
    has Str $.client-cert;              # mTLS
    has Str $.client-key;
    has Str $.key-password;

    # 相当于 curl -v：把协议交互打到 stderr。调试用，别在生产里开。
    has Bool $.verbose = False;

    # 连接复用。一个 handle 自带连接缓存，所以「复用连接」= 复用 handle：
    # 归还时 curl_easy_reset 清选项、留缓存，下一跳同主机就直接走已有 socket。
    has Bool $.reuse-connections = True;

    # **每个 host** 的空闲句柄上限（不是全局上限）。池子按 host 分桶，
    # 所以总量 = min(host 数, max-host-pools) × max-idle-connections。
    has Int $.max-idle-connections = 8;

    # 最多跟踪多少个 host 桶。超过就按 LRU 整桶回收，
    # 避免「爬几千个域名 → 池子跟着长到几千个句柄」。
    has Int $.max-host-pools = 64;

    has Set $!caps;
    has %!idle;                 # 桶：host-key => Array of Pointer（尾部最新）
    has @!order;                # 桶的 LRU 顺序，末尾最新
    has Lock $!lock .= new;

    submethod TWEAK() {
        # 全局初始化只做一次（curl_global_init 本身可重入，但没必要重复调）。
        # 失败在这里就记下来，而不是等第一次请求时才抛一句莫名其妙的
        # 「Cannot locate native library」。
        ensure-global();
    }

    method capabilities(--> Set) {
        return $!caps with $!caps;
        # 库都加载不了就什么都别声称：能力协商自然会退化到「不支持」，
        # 用户看到的是明确的 UnsupportedCapability，而不是深处的段错误。
        return set() unless ensure-global();
        $!caps = self!detect-capabilities;
    }

    method !detect-capabilities(--> Set) {
        my $set = set(<http1 http socks>);
        my $info := nativecast(CurlVersionInfo, curl_version_info(4));
        if $info.defined {
            with $info.features {
                $set = $set ∪ set(<http2>) if $_ +& CURL-VERSION-HTTP2;
                $set = $set ∪ set(<http3>) if $_ +& CURL-VERSION-HTTP3;
            }
            with $info.protocols {
                # 注意用 CArray[Pointer]：Pointer[Pointer] 的索引给的是地址本身，
                # 不是解引用后的值，读 char** 会读出一堆垃圾。
                my $arr := nativecast(CArray[Pointer], $_);
                my $i = 0;
                while $arr[$i].defined {
                    my $name = nativecast(Str, $arr[$i]).lc;
                    $set = $set ∪ set($name) if $name.chars;
                    $i++;
                }
            }
        }
        # 有 TLS 就有能力做双向证书
        $set = $set ∪ set(<mtls>) if 'https' ∈ $set;
        $set;
    }

    # 原生库在这台机器上能不能用：纯查询，不抛异常。
    # 装了 libcurl 但缺 HTTP/2 支持之类，看 capabilities 而不是这里。
    method available(--> Bool) { ensure-global() }

    # 不可用时的原因（可用时为空串）。
    method unavailable-reason(--> Str) { lib-error() }

    method version(--> Str) { ensure-global() ?? curl_version() !! '' }

    # ---- 句柄池（按 host 隔离）----
    #
    # 每次新建 handle 等于每次重新做 DNS + TCP + TLS，本机 HTTPS 一个来回就
    # 多几十毫秒。池子里放 handle（而不是 socket），因为连接缓存是 handle 私有的。
    #
    # 为什么按 host 分桶：handle 的连接缓存本来就**能**同时缓存多条不同目标的
    # 连接，所以混在一个池里也能跑通 —— 但 A、B 两个 host 会互相挤占配额。
    # 并发一高，B 归还时把 A 的暖句柄顶出池子，A 下一跳又得重新握手；
    # max-idle-connections 在这种混用下到底算「谁的额度」也说不清。
    # 分桶之后 A 只从 A 的桶里拿，命中稳定，邻居的流量影响不到它。
    #
    # 用 Lock 而不是按线程分桶：Rakudo 的调度线程数远小于并发请求数，
    # 分桶只会让同一个 handle 被多线程同时摸到。锁里只做 push/pop，不存在争用。
    method !pooling(--> Bool) {
        $!reuse-connections && $!max-idle-connections > 0 && $!max-host-pools > 0;
    }

    # 桶的 key：scheme://host:port。
    # host 不区分大小写（URL 语义），端口按 scheme 补默认值 —— 这样
    # `http://X/` 和 `http://x:80/` 落进同一个桶，不会平白多建一条连接。
    method !pool-key(Str $url --> Str) {
        my $p = try parse-url($url);
        return '?' without $p;          # 解析不了就走一个兜底桶
        "{$p.scheme}://{$p.host.lc}:{$p.port}";
    }

    # 某个 URL 会落到哪个桶里（测试/调试用）。
    method pool-key(Str $url --> Str) { self!pool-key($url) }

    method !checkout(Str $key --> Pointer) {
        my $h;
        if self!pooling {
            $h = $!lock.protect({
                my $got = Pointer;
                if %!idle{$key}:exists {
                    my $bucket := %!idle{$key};
                    if $bucket.elems {
                        $got = $bucket.pop;
                        # 空桶立刻删掉：留着只会让 LRU 记账变脏
                        $bucket.elems ?? self!touch($key) !! self!forget($key);
                    }
                }
                $got;
            });
        }
        return $h if $h.defined;
        curl_easy_init();
    }

    method !checkin(Pointer $h, Str $key --> Nil) {
        return unless $h.defined;

        unless self!pooling {
            curl_easy_cleanup($h);
            return;
        }

        # 必须先 reset 再入池：选项（URL、回调、代理、TLS…）全清，
        # 否则下一个请求会带着上一个请求的头和 body 跑。
        curl_easy_reset($h);

        my @drop;          # 被挤出去的句柄，锁外统一 cleanup
        my $kept = $!lock.protect({
            %!idle{$key} //= [];
            my $bucket := %!idle{$key};
            if $bucket.elems >= $!max-idle-connections {
                False
            }
            else {
                $bucket.push($h);
                self!touch($key);
                # 桶太多 → 按 LRU 整桶回收（刚放进去的这个在队尾，不会被选中）
                while @!order.elems > $!max-host-pools {
                    my $victim = @!order[0];
                    @drop.append(@$_) with %!idle{$victim};
                    self!forget($victim);
                }
                True
            }
        });
        curl_easy_cleanup($_) for @drop;
        curl_easy_cleanup($h) unless $kept;
    }

    # ---- LRU 记账（调用方必须持锁）----
    method !touch(Str $key --> Nil) {
        @!order = @!order.grep(* ne $key).Array;
        @!order.push($key);
        Nil;
    }

    method !forget(Str $key --> Nil) {
        %!idle{$key}:delete;
        @!order = @!order.grep(* ne $key).Array;
        Nil;
    }

    # 池里现在有几个空闲 handle（所有 host 合计）。测试用它确认「归还确实发生了」。
    method pool-size(--> Int) {
        $!lock.protect({ %!idle.values.map({ +@$_ }).sum });
    }

    # 某个 URL 对应的桶里有几个空闲 handle。
    method pool-size-for(Str $url --> Int) {
        my $key = self!pool-key($url);
        $!lock.protect({
            with %!idle{$key} { +@$_ } else { 0 }
        });
    }

    # 当前池子里有哪些 host 桶（排序后的 key）。
    method pool-hosts(--> List) {
        $!lock.protect({ %!idle.keys.sort.List });
    }

    method close(--> Nil) {
        my @old = $!lock.protect({
            my @x;
            @x.append(@$_) for %!idle.values;
            %!idle = ();
            @!order = ();
            @x;
        });
        curl_easy_cleanup($_) for @old;
        Nil;
    }

    method request(Rakuest::Request $req, Rakuest::Progress::Tracker :$progress --> Promise) {
        return self!streaming-request($req, $progress) if $req.stream;

        # 出池/回池的桶 key 只跟 URL 有关，先算好（纯函数，放到 start 外面）。
        my $key = self!pool-key($req.url);

        start {
            require-lib();
            my $started = now;
            my $ex = CurlExchange.new;

            my $handle = self!checkout($key);
            die X::Rakuest::TransportError.new(detail => 'curl_easy_init 失败')
                unless $handle;

            my $headers-list = self!build-slist($req);
            LEAVE {
                self!checkin($handle, $key);
                # 发完就把请求体收掉（关文件句柄 / 断上游订阅）。
                $req.body.close if $req.body ~~ Rakuest::Body::Stream;
            }

            my $error-buffer = CArray[uint8].new(0 xx CURL-ERROR-SIZE);
            self!apply-options($handle, $req, $ex, $error-buffer, $headers-list, $progress);

            my $code = curl_easy_perform($handle);
            my $status = self!getinfo-long($handle, CURLINFO-RESPONSE-CODE);

            # 收尾先于报错：失败时 done < total 这一发是有信息的，
            # 进度条不该停在半路还装作没事。
            if $progress.defined {
                $progress.finish('upload');
                $progress.finish('download');
            }

            # 回调里存下来的异常优先：它比 curl 那句「aborted by callback」
            # 有用得多（原话可能是「文件读失败」）。
            die $ex.failure if $ex.failure.defined;

            if $code != 0 {
                die self!translate-error($code, $error-buffer);
            }

            # 不开 CURLOPT_FOLLOWLOCATION：3xx 原样交回，跟随由门面决定 —— 契约一致。
            my ($headers-hash, $header-list) = self!parse-headers($ex);
            Rakuest::Response.new(
                status => self!normalize-status($req.url, $status.Int),
                headers => $headers-hash,
                header-list => $header-list,
                url => $req.url,
                elapsed => now - $started,
                blob => $ex.body,
            );
        }
    }

    # 流式：curl_easy_perform 会阻塞整个传输过程，而响应头在正文之前就到了。
    # 所以传输扔到工作线程，回调里「第一块数据到达」时就把 Response 交出去，
    # 之后每块直接 send 进 Channel —— 内存里只留正在处理的那一块。
    method !streaming-request(Rakuest::Request $req, $progress --> Promise) {
        my $ready = Promise.new;
        my $channel = Channel.new;                 # 无界：send 不阻塞，天然背压交给消费方
        my $key = self!pool-key($req.url);
        my $ex = CurlExchange.new(
            :streaming, :$channel, :$ready, started => now,
        );

        start {
            my $handle;
            my $failure;
            {
                LEAVE {
                    self!checkin($handle, $key);
                    $req.body.close if $req.body ~~ Rakuest::Body::Stream;
                }
                require-lib();
                $handle = self!checkout($key);
                die X::Rakuest::TransportError.new(detail => 'curl_easy_init 失败')
                    unless $handle;

                my $headers-list = self!build-slist($req);
                my $error-buffer = CArray[uint8].new(0 xx CURL-ERROR-SIZE);
                self!apply-options($handle, $req, $ex, $error-buffer, $headers-list, $progress);

                my $code = curl_easy_perform($handle);
                $failure = $ex.failure;
                $failure = self!translate-error($code, $error-buffer)
                    if !$failure.defined && $code != 0;
                CATCH { default { $failure = $_ } }
            }

            if $progress.defined {
                $progress.finish('upload');
                $progress.finish('download');
            }

            if $failure.defined {
                try {
                    if $ex.delivered {
                        # 头已经发出去了，只能从流上把错误传给消费方
                        $ex.channel.fail($failure);
                    }
                    else {
                        # 连响应都没拿到：让 await 直接抛
                        $ex.ready.break($failure);
                        $ex.channel.close;
                    }
                }
            }
            else {
                # 没有正文的响应（204/HEAD）不会触发写回调，这里补交
                self!deliver($ex, $req) unless $ex.delivered;
                $ex.channel.close;
            }
        }

        $ready;
    }

    # 把「目前已知的头 + 状态」封成 Response 交给调用方，只做一次。
    method !deliver(CurlExchange $ex, Rakuest::Request $req --> Nil) {
        return if $ex.delivered;
        $ex.delivered = True;
        my ($headers, $header-list) = self!parse-headers($ex);
        $ex.ready.keep(Rakuest::Response.new(
            status => self!normalize-status($req.url, $ex.status),
            headers => $headers,
            header-list => $header-list,
            url => $req.url,
            # 流式下 elapsed 是「首字节时间」而不是总耗时 —— 总耗时在交付时还不知道。
            elapsed => now - $ex.started,
            stream => $ex.channel.Supply,
        ));
    }

    # 请求头链表。content-type 在 Request 里是独立属性（Cro 后端也是单独传的），
    # 这里补回头里，否则 curl 会用默认的 x-www-form-urlencoded 把 JSON 当表单发。
    method !build-slist(Rakuest::Request $req --> Rakuest::Transport::Curl::Slist) {
        my %hdr = $req.headers;
        %hdr<content-type> //= $req.content-type with $req.content-type;
        # 流式上传时抑制 100-continue。curl 默认给大上传加 Expect: 100-continue，
        # 等于「先问一句再发」，白白多一个 RTT；服务端不回 100 时还要等超时。
        # 传一个空值头就是让 curl 把这个头删掉。
        %hdr<expect> = '' if $req.body ~~ Rakuest::Body::Stream;
        build-slist(%hdr);
    }

    method !apply-options(Pointer $h, Rakuest::Request $req, CurlExchange $ex,
                          CArray[uint8] $error-buffer, Rakuest::Transport::Curl::Slist $headers-list,
                          $progress --> Nil) {
        die X::Rakuest::TransportError.new(detail => 'curl setopt 失败：URL')
            if curl_setopt_str($h, CURLOPT-URL, $req.url) != 0;

        curl_setopt_int($h, CURLOPT-NOSIGNAL, 1);
        curl_setopt_ptr($h, CURLOPT-ERRORBUFFER, nativecast(Pointer, $error-buffer));
        curl_setopt_long($h, CURLOPT-VERBOSE, 1) if $!verbose;

        # 重定向归门面管
        curl_setopt_int($h, CURLOPT-FOLLOWLOCATION, 0);

        # 请求头
        curl_setopt_ptr($h, CURLOPT-HTTPHEADER, $headers-list.head)
            if $headers-list.head.defined;

        # 方法 + body
        my $method = $req.method.uc;
        if $method eq 'HEAD' {
            curl_setopt_int($h, CURLOPT-NOBODY, 1);
            curl_setopt_int($h, CURLOPT-HTTP-VERSION, self!http-version($req));
        }
        else {
            curl_setopt_str($h, CURLOPT-CUSTOMREQUEST, $method);
            curl_setopt_int($h, CURLOPT-HTTP-VERSION, self!http-version($req));
            if $req.body ~~ Rakuest::Body::Stream {
                # 先告诉 tracker 上传总长：curl 在第一个 tick 之前不会给
                # ultotal，进度条会有一小段时间没有比例。
                if $progress.defined && $req.body.length.defined {
                    $progress.set-total('upload', $req.body.length);
                }
                self!apply-stream-body($h, $req, $ex, $req.body);
            }
            else {
                with self!body-bytes($req.body) -> $bytes {
                    # 顺序不能反：POSTFIELDSIZE 默认 -1 表示「用 strlen() 量长度」，
                    # 先设 COPYPOSTFIELDS 会让 curl 去 strlen 一个没有 NUL 结尾的
                    # 二进制缓冲 —— 读出天量长度，然后卡死在复制上。
                    curl_setopt_off($h, CURLOPT-POSTFIELDSIZE-LARGE, $bytes.elems);
                    curl_setopt_blob($h, CURLOPT-COPYPOSTFIELDS, $bytes);
                }
            }
        }

        # 超时
        with $req.timeout {
            curl_setopt_long($h, CURLOPT-TIMEOUT-MS, ($_ * 1000).Int);
        }
        curl_setopt_long($h, CURLOPT-CONNECTTIMEOUT-MS, ($!connect-timeout * 1000).Int);

        # 读空闲超时（低速检测）。threshold 取 1 字节/秒：只要对端还在「滴」数据
        # 就不算死掉，完全不动才会触发 —— 这正是「空闲」的定义。
        if $!read-timeout > 0 {
            curl_setopt_long($h, CURLOPT-LOW-SPEED-LIMIT, 1);
            curl_setopt_long($h, CURLOPT-LOW-SPEED-TIME, $!read-timeout.ceiling.Int);
        }

        # TLS
        if $!insecure {
            curl_setopt_long($h, CURLOPT-SSL-VERIFYPEER, 0);
            curl_setopt_long($h, CURLOPT-SSL-VERIFYHOST, 0);
        }
        curl_setopt_str($h, CURLOPT-CAINFO, $!ca-file) with $!ca-file;
        curl_setopt_str($h, CURLOPT-CAPATH, $!ca-path) with $!ca-path;
        curl_setopt_str($h, CURLOPT-SSLCERT, $!client-cert) with $!client-cert;
        curl_setopt_str($h, CURLOPT-SSLKEY, $!client-key) with $!client-key;
        curl_setopt_str($h, CURLOPT-SSLKEYPASSWD, $!key-password) with $!key-password;

        # 代理
        with $!proxy {
            curl_setopt_str($h, CURLOPT-PROXY, $_);
            curl_setopt_long($h, CURLOPT-PROXYTYPE, self!proxy-type-code);
        }

        # 回调：body + header 都靠它们收集
        #
        # 重要：**异常绝不能从原生回调里抛出去**。这些函数是从 libcurl 的 C 栈
        # 里被调用的，Rakudo 无法在那里展开异常 —— 结果是
        # 「An unhandled exception occurred in a native callback」然后整个进程死掉，
        # 调用方连 try/CATCH 都来不及。所以一律就地 catch、记在 $ex.failure 上，
        # 让 perform 返回后再抛。
        my &write = sub (Pointer $ptr, size_t $size, size_t $nmemb, Pointer $ud --> size_t) {
            my $n = ($size * $nmemb).Int;
            return 0 if $n == 0;

            {
                my buf8 $chunk .= allocate($n);
                memcpy(nativecast(Pointer, $chunk), $ptr, $n);
                if $ex.streaming {
                    # 第一块数据意味着响应头已经完整 —— 此刻把 Response 交出去，
                    # 调用方就能一边收一边处理，不用等整块传输结束。
                    self!deliver($ex, $req) unless $ex.delivered;
                    $ex.channel.send($chunk);
                }
                else {
                    $ex.body.append($chunk);
                }
                CATCH { default { $ex.failure = $_; $n = 0 } }
            }
            $n;
        };
        my &header = sub (Pointer $ptr, size_t $size, size_t $nmemb, Pointer $ud --> size_t) {
            my $n = ($size * $nmemb).Int;
            return 0 if $n == 0;
            {
                # 回调给的不是 null 结尾字符串，必须按长度拷贝再解码。
                my buf8 $bytes .= allocate($n);
                memcpy(nativecast(Pointer, $bytes), $ptr, $n);
                # 响应头规范上是 ISO-8859-1，现实里 UTF-8 和 GBK 都见过。
                # 这里硬解 UTF-8 的话，一个中文文件名就能让整个请求失败。
                my $line = decode-lenient($bytes).trim;
                # 空行 = 一个响应头块结束。走代理时前面还有 CONNECT 的 200 块，
                # 所以按块累积，最后取最后一块。
                if $line.chars == 0 {
                    $ex.header-blocks.push($ex.current.List) if $ex.current.elems;
                    $ex.current = ();
                }
                else {
                    # 状态行：流式路径要在这里拿到状态码（那时 perform 还没返回，
                    # curl_getinfo 用不上）。走代理时会先见到 CONNECT 的 200，
                    # 后面真正的状态行会覆盖它 —— 正好是我们要的「最后一个」。
                    self!absorb-status($ex, $line) if $line.starts-with('HTTP/');
                    $ex.current.push($line);
                }
                CATCH { default { $ex.failure = $_; $n = 0 } }
            }
            $n;
        };
        curl_setopt_writefn($h, CURLOPT-WRITEFUNCTION, &write);
        curl_setopt_headerfn($h, CURLOPT-HEADERFUNCTION, &header);
        self!apply-progress($h, $ex, $progress) if $progress.defined;
    }

    # libcurl 的进度回调。一次调用同时给两个方向的累计值（字节）：
    #   dltotal/dlnow —— 下载总长/已下；ultotal/ulnow —— 上传总长/已传。
    # 两个方向都要判断一下再报：GET 请求的 ultotal/ulnow 恒为 0，
    # 无条件报就会冒出一堆「上传 0/0」。
    #
    # 和 write/header 一样：**异常不能越过 FFI 边界**。tracker 自己会吞掉
    # 用户回调的异常（记在 failure 上），这里只负责把「中止」翻译成返回值 1，
    # 让 perform 尽快返回（CURLE 42），异常随后在 request 里重新抛。
    method !apply-progress(Pointer $h, CurlExchange $ex,
                           Rakuest::Progress::Tracker $progress --> Nil) {
        my &xfer = sub (Pointer $ud, int64 $dltotal, int64 $dlnow,
                        int64 $ultotal, int64 $ulnow --> int32) {
            {
                $progress.report('download', $dlnow.Int, $dltotal.Int)
                    if $dlnow > 0 || $dltotal > 0;
                $progress.report('upload', $ulnow.Int, $ultotal.Int)
                    if $ulnow > 0 || $ultotal > 0;
                CATCH { default { $ex.failure = $_ } }
            }
            $ex.failure //= $progress.failure;
            $ex.failure.defined ?? 1 !! 0;
        };
        $ex.progress-cb = &xfer;      # 保活，见 CurlExchange 的注释

        curl_setopt_int($h, CURLOPT-NOPROGRESS, 0);   # 默认是 1（关）
        curl_setopt_xferfn($h, CURLOPT-XFERINFOFUNCTION, &xfer);
        Nil;
    }

    # 流式上传：libcurl 反复调 read 回调来「要」数据，我们按它要的量从
    # Body::Stream 里拉 —— 拉到多少给多少，内存里始终只有一块。
    # 注意回调必须严格听从 $want：给多了会丢，给少了不会（剩下的下次再给）。
    #
    # 和 write/header 一样，异常绝不能从回调里抛出去（会当场杀掉进程），
    # 一律 catch 住、记到 $ex.failure，返回 ABORT 让 perform 尽快结束。
    method !apply-stream-body(Pointer $h, Rakuest::Request $req, CurlExchange $ex,
                              Rakuest::Body::Stream $body --> Nil) {
        my &read = sub (Pointer $ptr, size_t $size, size_t $nmemb, Pointer $ud --> size_t) {
            my $want = ($size * $nmemb).Int;
            return 0 if $want <= 0;

            my $chunk;
            {
                $chunk = $body.read($want);
                CATCH { default { $ex.failure = $_ } }
            }
            return CURL-READFUNC-ABORT if $ex.failure.defined;
            return 0 unless $chunk.defined;          # 0 = EOF，curl 收到就结束

            {
                memcpy($ptr, nativecast(Pointer, $chunk), $chunk.elems);
                CATCH { default { $ex.failure = $_ } }
            }
            return CURL-READFUNC-ABORT if $ex.failure.defined;

            $chunk.elems;
        };

        curl_setopt_readfn($h, CURLOPT-READFUNCTION, &read);
        # UPLOAD 让 curl 走 read 回调；配 CUSTOMREQUEST 就能发 POST / PUT / PATCH。
        curl_setopt_int($h, CURLOPT-UPLOAD, 1);
        # -1 = 不知道总长 → HTTP/1.1 chunked；知道就发 Content-Length。
        curl_setopt_off($h, CURLOPT-INFILESIZE-LARGE,
                        $body.length.defined ?? $body.length !! -1);
    }

    # "HTTP/1.1 200 OK" / "HTTP/2 404" → 200 / 404
    method !absorb-status(CurlExchange $ex, Str $line --> Nil) {
        my @parts = $line.split(' ', 3);
        return unless @parts.elems >= 2;
        my $code = try +@parts[1];
        $ex.status = $code if $code.defined && $code.Int > 0;
    }

    # 非 HTTP 协议没有状态行：
    #   file://  → RESPONSE_CODE 是 0
    #   ftp://   → RESPONSE_CODE 是 FTP 应答码（226 / 250…），不是 HTTP 语义
    # 传输成功（code == 0，否则上面已经抛了）就统一报 200，让 is-success 有意义。
    # FTP 的 550 之类不会走到这里 —— libcurl 会把它变成非零错误码。
    method !normalize-status(Str $url, Int $status --> Int) {
        my $scheme = (try parse-url($url).scheme) // '';
        return $status if $scheme eq 'http' || $scheme eq 'https';
        200;
    }

    method !http-version(Rakuest::Request $req --> int32) {
        given ($req.http-version // '') {
            when '1.1' { CURL-HV-ELEVEN }
            when '2'   { CURL-HV-TWO }
            when '3'   { CURL-HV-THREE }
            default    { 0 }   # CURL_HTTP_VERSION_NONE：让 curl 自己协商
        }
    }

    method !proxy-type-code(--> int32) {
        given $!proxy-type.lc {
            when 'socks4'   { CURL-PROXY-SOCKS4 }
            when 'socks4a'  { CURL-PROXY-SOCKS4A }
            when 'socks5'   { CURL-PROXY-SOCKS5 }
            when 'socks5h'  { CURL-PROXY-SOCKS5-HOST }
            default         { CURL-PROXY-HTTP }
        }
    }

    # 请求体统一成字节。Stream 走 read 回调，不经过这里。
    #
    # 不认识的类型必须炸：以前这里默默返回 Nil，于是 multipart（Form）发出去
    # 是一个**空 body**，服务端只看到 Content-Length: 0 或者干脆挂住 —— 这种
    # 「静默丢正文」是最难查的一类 bug，宁可编译完就报错。
    method !body-bytes($body --> Blob) {
        return Blob unless $body.defined;
        given $body {
            when Blob { $_ }
            when Str  { $_.encode('utf-8') }
            default {
                die X::Rakuest::TransportError.new(
                    detail => "curl 后端不认识这种请求体：{$body.^name}"
                        ~ '（应当已在 Rakuest::Request 里换成 Str / Blob / Stream）',
                );
            }
        }
    }

    # curl 的错误码 → Rakuest 异常族。CURLOPT_ERRORBUFFER 里的信息比
    # curl_easy_strerror 更具体，优先用它。
    #
    # 证书类错误按**错误码**判定而不是错误文字：Windows 上这段文字来自
    # Schannel 的 FormatMessage，中文系统上是中文的（"证书链是由不受信任的
    # 颁发机构颁发的"），按字符串匹配必然漏。
    my constant CURL-CERT-CODES = <51 58 60 77 82 83 90 91>.Set;
    method !translate-error(int32 $code, CArray[uint8] $error-buffer --> Exception) {
        my $detail = $error-buffer[0] ?? self!cstring($error-buffer) !! '';
        my $why = $detail.chars ?? $detail !! ((try curl_easy_strerror($code)) // '');
        my $text = "curl 失败（code={$code}）" ~ ($why.chars ?? "：{$why}" !! '');
        return X::Rakuest::Timeout.new(detail => $text) if $code == CURL-ERR-TIMEOUT;
        # Windows 上走 Schannel，信任根来自系统证书库，所以算「有得用」。
        X::Rakuest::TransportError.new(
            detail    => $text,
            ca-loaded => $!ca-file.defined || $*DISTRO.is-win,
            tls-issue => (CURL-CERT-CODES{$code} ?? 'verify' !! Str),
        );
    }

    method !getinfo-long(Pointer $h, int32 $info --> long) {
        my $out = CArray[long].new;
        $out[0] = 0;
        my $rc = curl_getinfo_long($h, $info, $out);
        $rc == 0 ?? $out[0] !! 0;
    }

    method !cstring(CArray[uint8] $buf --> Str) {
        my @bytes;
        for ^CURL-ERROR-SIZE -> $i {
            last if $buf[$i] == 0;
            @bytes.push($buf[$i]);
        }
        # 错误文本是**本机编码**：libcurl 在 Windows 上把 Schannel 的
        # FormatMessage 结果按 ANSI 代码页塞进 buffer，中文系统上就是 GBK。
        # 报错的路径上再抛 `Malformed UTF-8` 是最坏的结果 —— 一句看不懂的
        # 消息也比崩掉强，所以这里宽松解码，绝不让它抛。
        decode-lenient(Buf.new(@bytes), :native);
    }

    method !parse-headers(CurlExchange $ex --> List) {
        my @block = $ex.header-blocks.elems ?? $ex.header-blocks.tail.List !! ();
        # 兜底：没有空行结尾时，用累积中的那一块
        @block = $ex.current.List if !@block.elems && $ex.current.elems;

        my %headers;
        my @list;
        for @block -> $line {
            next if $line.starts-with('HTTP/');      # 状态行不是头
            my $i = $line.index(':');
            next without $i;
            my $name = $line.substr(0, $i).trim.lc;
            my $value = $line.substr($i + 1).trim;
            next unless $name.chars;
            @list.push($name => $value);
            %headers{$name} = %headers{$name}:exists
                ?? "{%headers{$name}}, {$value}"
                !! $value;
        }
        # 注意返回 Array 而不是 List：把 List 传给 Response 的 `has @.header-list`
        # 会被当成单个元素包起来（List 在具名参数里被 itemize），
        # 而 Array / Seq 会正常展平。
        (%headers, @list.Array);
    }
}
