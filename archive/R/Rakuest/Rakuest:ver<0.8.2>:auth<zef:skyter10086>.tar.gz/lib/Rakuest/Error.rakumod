# Rakuest 的异常族。
#
# 约定：传输后端负责把自己的异常（Cro 的 X::Cro::*、libcurl 的错误码……）
# 翻译成这里的类型。上层与用户代码因此永远不需要认识具体后端。
#
# 注意：本文件**不给 class 挂 `is export`**，改用文件末尾的显式 `sub EXPORT`。
# 原因：这些类叫 X::Rakuest…，并不在模块命名空间 Rakuest::Error 之下，
# 而 `is export` 会按「名字的最后一段」把符号装进 use 方的作用域 ——
# 也就是往用户空间里装一个名叫 `Rakuest` 的符号（值为异常类），
# 把 `Rakuest` 包本身遮蔽掉：`use Rakuest; use Rakuest::Error;`
# 会直接报 `Redeclaration of symbol 'Rakuest'`，只 `use Rakuest::Error;`
# 也会让后续的 `Rakuest::Client` 解析不到。显式 EXPORT 把全名摆正即可。
unit module Rakuest::Error;

class X::Rakuest is Exception {
    has Str $.detail;
    method message(--> Str) { 'Rakuest: ' ~ ($!detail // '请求失败') }
}

# 证书校验失败是「看起来像网络不通」里最常见的一种：OpenSSL 只会甩一句
# unable to get local issuer certificate，不说该怎么办。按「本地有没有 CA bundle」
# 分两句人话；不是这类错误就返回 Str（调用方据此不加提示）。
#
# 为什么还得看中文：Windows 上 libcurl 的错误文字来自 Schannel 的
# FormatMessage，中文系统上整句都是中文（「证书链是由不受信任的颁发机构颁发的」）。
# 所以文字判定要中英都认；实在认不出来时，后端可以按错误码直接给 $issue。
my constant TLS-FAIL = rx:i/ 'certificate verification failed'
    | 'certificate verify failed' | 'unable to get local issuer'
    | 'unable to get issuer certificate' | 'self[-]signed certificate'
    | 'untrusted root' | '不受信任' | '证书链' /;

my constant TLS-EXPIRED = rx:i/ 'certificate has expired' | 'expired certificate'
    | '证书已过期' | '证书过期' /;

my constant TLS-SELF-SIGNED = rx:i/ 'self[-]signed certificate' | 'self signed certificate'
    | '自签名' /;

sub tls-hint(Str $text, Bool $ca-loaded, Str $issue --> Str) {
    # 先按文字判，判不出来再用后端给的类别（$issue: verify / expired / self-signed）。
    my $kind = (do {
        if $text ~~ TLS-EXPIRED { 'expired' }
        elsif $text ~~ TLS-SELF-SIGNED { 'self-signed' }
        elsif $text ~~ TLS-FAIL { 'verify' }
        else { Str }
    }) // $issue;
    return Str unless $kind.defined;

    given $kind {
        when 'expired' {
            '证书已过期（本机时钟不准也会这样）：先校一下系统时间；临时可用 insecure => True 跳过。'
        }
        when 'self-signed' {
            '服务端用的是自签名证书：把它（或签发它的根）加进 ca-file 指向的 PEM，'
                ~ '或临时 insecure => True。'
        }
        default {
            $ca-loaded
                ?? '证书链没验过，但本地 CA bundle 是加载了的：多半是服务端没发中间证书，'
                 ~ '或者中间有个 TLS 拦截代理。换一份企业根证书（ca-file），或临时 insecure => True。'
                !! '本地没有可用的 CA bundle（Windows 上 OpenSSL 读不到系统证书库）。'
                 ~ 'Windows 用 Git 自带的 ca-bundle.crt，Linux 通常是 /etc/ssl/certs/ca-certificates.crt：'
                 ~ 'ca-file => \'该文件的路径\'，或临时 insecure => True。'
        }
    }
}

# 任何「没有拿到 HTTP 响应」的失败（DNS、连接、TLS、socket 中断……）。
class X::Rakuest::TransportError is X::Rakuest {
    has Mu $.cause;

    # 后端到底有没有可用的信任根。TLS 校验失败时这两种情况该说的话完全不同：
    # 有 bundle 还失败 = 证书本身对不上；没有 bundle = 先给它一份根证书。
    has Bool $.ca-loaded = False;

    # 后端若能从错误码确定「这就是证书问题」（libcurl 的 60 之类），
    # 直接给类别，比猜本地化了的错误文字可靠：verify / expired / self-signed。
    has Str $.tls-issue;

    method message(--> Str) {
        my $base = do {
            # detail 是父类 X::Rakuest 的属性，子类里只能用 self.detail。
            if self.detail.defined {
                'Rakuest: ' ~ self.detail
            }
            else {
                my $why = '';
                with $!cause {
                    # X::Await::Died 之类组合出来的异常，.message 可能落在 stub 上，包一层 try。
                    my $name = .^name.subst(/\+\{.*\}$/, '');
                    my $msg = try { .message };
                    $why = ($msg.defined && $msg ne '')
                        ?? "（$name: $msg）"
                        !! "（$name）";
                }
                'Rakuest: 传输失败' ~ $why;
            }
        };
        my $hint = tls-hint($base, $!ca-loaded, $!tls-issue);
        $hint.defined ?? $base ~ "\n提示: " ~ $hint !! $base;
    }
}

class X::Rakuest::Timeout is X::Rakuest::TransportError {
    method message(--> Str) {
        self.detail.defined
            ?? 'Rakuest: ' ~ self.detail
            !! 'Rakuest: 请求超时' ~ (self.cause.defined ?? "（{self.cause.message}）" !! '');
    }
}

class X::Rakuest::TooManyRedirects is X::Rakuest {
    has Int $.max is required;
    method message(--> Str) { "Rakuest: 重定向次数超过上限（{$!max}）" }
}

class X::Rakuest::UnsupportedScheme is X::Rakuest {
    has Str $.scheme is required;
    method message(--> Str) { "Rakuest: 没有能处理 '{$!scheme}://' 的传输后端" }
}

class X::Rakuest::UnsupportedCapability is X::Rakuest {
    has Str $.capability is required;
    method message(--> Str) { "Rakuest: 当前传输后端不支持 '{$!capability}'" }
}

# 服务端用了我们不认识的 Content-Encoding（brotli/zstd 等），
# 或者压缩流本身是坏的。宁可报错，也不把压缩字节当正文交出去。
class X::Rakuest::ContentEncoding is X::Rakuest {
    has Str $.encoding = '';
    method message(--> Str) {
        return 'Rakuest: ' ~ self.detail if self.detail.defined;
        'Rakuest: 不支持的 Content-Encoding ' ~ ($!encoding.chars ?? "'{$!encoding}'" !! '')
            ~ '（当前只支持 gzip / deflate；可用 compress => False 关闭协商）';
    }
}

# Cro 后端没有实现代理的 CONNECT 隧道：它会把 `GET https://host/ HTTP/1.1`
# 以**明文**发给代理端口，代理要么 400，要么把 Authorization 头一起读走。
# 这既是功能缺陷也是安全问题，所以宁可报错也不静默降级。
class X::Rakuest::ProxyUnsupported is X::Rakuest {
    has Str $.proxy = '';
    method message(--> Str) {
        'Rakuest: Cro 后端不支持 HTTPS 经代理（没有 CONNECT 隧道），'
        ~ '继续走会把请求明文发给代理。'
        ~ '解决方式：① 去掉 proxy / unset HTTPS_PROXY 直连；'
        ~ '② 用 NO_PROXY 让目标直连；'
        ~ '③ 换 Rakuest::Transport::Curl 后端（原生支持 CONNECT）。'
        ~ ($!proxy.chars ?? "（当前代理：{$!proxy}）" !! '');
    }
}

# 只有显式调用 raise-for-status 时才会抛：4xx/5xx 默认是普通响应。
class X::Rakuest::StatusError is X::Rakuest {
    has Int $.status is required;
    has Str $.url is required;
    has $.response;
    method message(--> Str) { "Rakuest: HTTP {$!status}（{$!url}）" }
}

# 流式请求体已经被发出去过，重定向要重发时没法凭空再变一份。
# 单独成型是因为用户看得懂「改成传路径」这个解法，比一句「发送失败」有用得多。
class X::Rakuest::BodyReplay is X::Rakuest {
    method message(--> Str) {
        'Rakuest: ' ~ (self.detail // '流式请求体无法重发');
    }
}

# 后端依赖的原生库加载不了（典型：系统里根本没装 libcurl）。
# 单独成型是因为它属于「环境问题」，和「这次请求失败」应当区分开。
class X::Rakuest::BackendUnavailable is X::Rakuest {
    has Str $.backend = 'backend';
    has Str $.library = '';
    method message(--> Str) {
        'Rakuest: ' ~ $!backend ~ ' 后端不可用'
            ~ ($!library.chars ?? "（找不到原生库 '{$!library}'）" !! '')
            ~ (self.detail.defined ?? "：{self.detail}" !! '')
            ~ '。可改用默认的 Cro 后端，或先安装 libcurl。'
    }
}

# 显式导出全名（理由见文件头）。
# 只导出基类一个符号就够：X::Rakuest 这个类型对象本身就是其余异常的包，
# X::Rakuest::Timeout 之类会顺着它的 stash 解析出来。
# 只装一个键也顺便避开了「先装子类还是先装基类」的先后顺序问题。
sub EXPORT(--> Map) {
    Map.new('X::Rakuest' => X::Rakuest)
}
