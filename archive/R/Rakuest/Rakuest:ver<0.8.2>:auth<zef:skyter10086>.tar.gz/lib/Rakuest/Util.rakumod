unit module Rakuest::Util;

use NativeCall;

# ---- 原生库定位 ----
#
# 「库名」和「库文件名」不是一回事，Linux 上这两个坑都很要命：
#
#   · native('curl') 只会去找 libcurl.so —— 那是 libcurl*-dev 包才提供的开发软链。
#     普通用户机器上只装了运行时包，文件名是 libcurl.so.4，于是后端被判成
#     「本机没有 libcurl」。
#   · native('c') 在 Debian/Ubuntu 上会命中 /usr/lib/<triplet>/libc.so，而那个
#     文件的内容是一段 GNU ld 脚本（"GROUP ( /lib/.../libc.so.6 ... )"），不是
#     ELF，dlopen 报 invalid ELF header。
#
# 所以按「候选 soname × 标准库目录」探真实文件，挑第一个存在的；都不存在就退回
# 最笼统的那个名字交给 dlopen。调用方拿到的要么是 soname，要么是兜底名字，
# 都可以直接喂给 `is native(...)`。
#
# 只在模块加载（预编译）时跑一次，结果被固化；换库要清 .precomp 重建。
our @NATIVE-LIB-DIRS =
    '/usr/lib/x86_64-linux-gnu', '/usr/lib/aarch64-linux-gnu',
    '/usr/lib/arm-linux-gnueabihf', '/usr/lib64', '/usr/lib',
    '/lib/x86_64-linux-gnu', '/lib/aarch64-linux-gnu', '/lib64', '/lib',
    '/usr/local/lib', '/opt/homebrew/lib';

sub locate-native-lib(Str $fallback, *@names --> Str) is export {
    for @names -> $n {
        return $n if $n.IO.e;                          # 已经是完整路径
        return $n if @NATIVE-LIB-DIRS.first({ "{$_}/{$n}".IO.e });
    }
    $fallback;
}

# ---- 宽松解码 ----
#
# 会拿到「不是 UTF-8」的字节的地方有两个，而且都在**出错**或**处理别人的数据**的
# 路径上，崩在这儿是最难看的失败方式：
#
#   · libcurl 的错误文本：Windows 上它把 Schannel / FormatMessage 的结果按系统
#     ANSI 代码页塞进错误缓冲（中文系统就是 GBK），当 UTF-8 硬解会抛
#     `Malformed UTF-8`；
#   · 响应头：规范说 ISO-8859-1，现实里服务器常塞 UTF-8，也见过 GBK 的
#     `Content-Disposition: filename="报表.xlsx"`。
#
# 顺序：UTF-8（正常情况，零损失）→ 可选的本机 ANSI（仅 Windows，用于系统错误
# 文本）→ latin-1（对任意字节都不会失败，兜底）。:native 只在解释「操作系统的
# 话」时打开 —— 协议文本用系统代码页去猜只会猜错。
our sub decode-lenient(Blob $bytes, Bool :$native = False --> Str) is export {
    my $utf8 = try $bytes.decode('utf-8');
    return $utf8 if $utf8.defined;
    if $native && $*DISTRO.is-win {
        my $ansi = decode-win-ansi($bytes);
        return $ansi if $ansi.defined;
    }
    $bytes.decode('iso-8859-1');
}

# 按系统 ANSI 代码页解码（CP_ACP）。只在 Windows 且 UTF-8 已经失败时调用。
# 失败返回 Str（调用方退回 latin-1），绝不抛 —— 调用它的时候请求已经失败了。
sub decode-win-ansi(Blob $bytes --> Str) {
    my sub mb-to-wc(int32 $cp, uint32 $flags, CArray[uint8] $src, int32 $len,
                    CArray[uint16] $dst, int32 $dst-len --> int32)
        is native('kernel32') is symbol('MultiByteToWideChar') { * }

    my $n = $bytes.elems;
    return Str unless $n;
    my $src = CArray[uint8].new;
    $src[$n - 1] = 0;
    my $i = 0;
    for $bytes.list { $src[$i++] = $_ }

    my $need = mb-to-wc(0, 0, $src, $n, CArray[uint16].new, 0);
    return Str if $need <= 0;
    my $wide = CArray[uint16].new;
    $wide[$need - 1] = 0;
    my $got = mb-to-wc(0, 0, $src, $n, $wide, $need);
    return Str if $got <= 0;

    my $le = Buf.new;
    for ^$got -> $k {
        my $u = $wide[$k].Int;
        $le.append($u +& 0xFF, ($u +> 8) +& 0xFF);
    }
    $le.decode('utf-16le');
}

my %MIME =
    json => 'application/json',
    txt  => 'text/plain',
    html => 'text/html',
    htm  => 'text/html',
    xml  => 'application/xml',
    csv  => 'text/csv',
    yaml => 'application/yaml',
    yml  => 'application/yaml',
    png  => 'image/png',
    jpg  => 'image/jpeg',
    jpeg => 'image/jpeg',
    gif  => 'image/gif',
    webp => 'image/webp',
    svg  => 'image/svg+xml',
    pdf  => 'application/pdf',
    zip  => 'application/zip',
    gz   => 'application/gzip',
    tgz  => 'application/gzip',
    tar  => 'application/x-tar',
    bin  => 'application/octet-stream';

sub guess-content-type(IO::Path $path --> Str) is export {
    %MIME{$path.extension.lc} // 'application/octet-stream';
}

# 找一份可用的 CA bundle。
#
# 为什么要这个：Windows 上 OpenSSL 的 SSL_CTX_set_default_verify_paths 形同虚设
# ——它读不到 Windows 证书库（那是 Crypt32 的格式），于是 HTTPS 一律校验失败。
# 现实做法是给它一份 PEM bundle（Git for Windows / curl 都自带一份）。
#
# 优先级：显式参数 > RAKUEST_CA_FILE > SSL_CERT_FILE > CURL_CA_BUNDLE > 常见路径。
# 找不到返回 Nil（调用方据此退回 OpenSSL 默认行为）。
our @CA-CANDIDATES =
    '/mingw64/etc/ssl/certs/ca-bundle.crt',
    '/mingw64/ssl/certs/ca-bundle.crt',
    'C:\Program Files\Git\mingw64\etc\ssl\certs\ca-bundle.crt',
    'C:\Program Files\Git\mingw64\ssl\certs\ca-bundle.crt',
    '/etc/ssl/certs/ca-certificates.crt',
    '/etc/pki/tls/certs/ca-bundle.crt',
    '/etc/ssl/cert.pem',
    '/usr/local/etc/openssl@3/cert.pem',
    '/opt/homebrew/etc/openssl@3/cert.pem';

sub find-ca-bundle(--> IO::Path) is export {
    for %*ENV<RAKUEST_CA_FILE SSL_CERT_FILE CURL_CA_BUNDLE>.list -> $env {
        next unless $env.defined && $env.chars;
        my $p = $env.IO;
        return $p if $p.e && $p.f;
    }
    for @CA-CANDIDATES -> $path {
        my $p = $path.IO;
        return $p if $p.e && $p.f;
    }
    Nil;
}

# Raku 核心没有 base64 编码（OpenSSL/MIME 模块在 Windows 上装不齐），
# 几十行自己实现，少一个依赖。标准字母表 + '=' 填充。
sub base64-encode(Blob $data --> Str) is export {
    my @alphabet = flat ('A' .. 'Z'), ('a' .. 'z'), ('0' .. '9'), '+', '/';
    my @bytes = $data.list;
    my @out;
    while @bytes {
        my @chunk = @bytes.splice(0, 3);
        my $n = ((@chunk[0] // 0) +< 16) +| (((@chunk[1] // 0) +< 8)) +| (@chunk[2] // 0);
        @out.push: @alphabet[($n +> 18) +& 63];
        @out.push: @alphabet[($n +> 12) +& 63];
        @out.push: @chunk.elems > 1 ?? @alphabet[($n +> 6) +& 63] !! '=';
        @out.push: @chunk.elems > 2 ?? @alphabet[$n +& 63] !! '=';
    }
    @out.join;
}
