unit class Rakuest::Request;

use Rakuest::Body;
use Rakuest::Form;
use Rakuest::URI;

# 一个「已经解析好」的请求：URL 是绝对地址且查询串已并入，
# 传输后端不需要再理解 query / base-url / 参数。
has Str $.method = 'GET';
has Str $.url is required;
has %.headers;
has $.body;
has Str $.content-type;
has Numeric $.timeout;
has Str $.http-version;
has Bool $.stream = False;
# 是否协商 gzip/deflate。门面建请求时把客户端设置和单次覆盖合并到这里，
# 后端不用管，重定向时也能原样带到下一跳。
has Bool $.compress = True;

# 传输进度回调（Rakuest::Progress）。也是「单次请求覆盖」的一员：
# 它在 redirected / replayed 里必须跟着走，否则跟到第二跳就没有进度了。
# 存的是回调而不是 tracker —— tracker 是每次尝试新建的，见 Client!tracker。
has $.progress;

# 重定向策略快照。后端**不看**这两个字段（跟随重定向是门面的活），
# 放在这里只是为了让「单次请求覆盖 follow => False」跨跳保持一致。
has Bool $.follow = True;
has Int $.max-redirects = 10;

# multipart 在这里就换成字节流：backend 只认 Str / Blob / Stream 三种 body，
# 少一种「谁来负责序列化」的讨论。门面自己也会先转（它要设 content-type），
# 这里兜住「有人直接 new 一个 Request」的情况。
submethod TWEAK() {
    return unless $!body ~~ Rakuest::Form::Multipart;
    my $mp = $!body;
    $!body = $mp.to-stream;
    $!content-type //= $mp.content-type;
}

# 按 RFC 9110 的语义生成下一跳请求：
#   303           → GET，丢 body / content-type
#   301 / 302     → 仅当原方法是 POST 时改 GET（与浏览器、httpx、Go 一致）
#   307 / 308     → 方法与 body 原样保留
# 跨 origin 时剥掉 Authorization（避免把凭据转发给第三方主机）。
method redirected(Str $location, Int $status --> Rakuest::Request) {
    my $next = resolve-url($!url, $location);

    my $method = $!method;
    my $body = $!body;
    my $ct = $!content-type;
    my %headers = %!headers;

    if $status == 303 || (($status == 301 || $status == 302) && $method eq 'POST') {
        $method = 'GET';
        $body = Nil;
        $ct = Nil;
        for @(%headers.keys.grep({ .lc eq 'content-type' })) -> $k { %headers{$k}:delete }
    }

    my $old = parse-url($!url);
    my $new = parse-url($next);
    if $old.origin ne $new.origin {
        for @(%headers.keys.grep({ .lc eq 'authorization' })) -> $k { %headers{$k}:delete }
    }

    # 流式体只能发一次。能重开的（文件 / 字节串）换一份新的；重开不了的
    # 直接报错 —— 悄悄发一个空 body 过去最糟，服务端只看到长度 0，极难查。
    if $body ~~ Rakuest::Body::Stream {
        $body = $body.replay;
    }

    my %args = :method($method), url => $next, headers => %headers, :$body,
               stream => $!stream, compress => $!compress,
               follow => $!follow, max-redirects => $!max-redirects;
    %args<content-type> = $ct if $ct.defined;
    %args<timeout> = $!timeout if $!timeout.defined;
    %args<http-version> = $!http-version if $!http-version.defined;
    %args<progress> = $!progress if $!progress.defined;
    self.WHAT.new(|%args);
}

# 同一份请求能不能再发一次。字节串 / 字符串天然可以；流式体要看它有没有
# 声明 replayable（文件路径能重开，Supply 不能）。
method replayable(--> Bool) {
    return True unless $!body ~~ Rakuest::Body::Stream;
    $!body.replayable;
}

# 原样重发（重试用），与 redirected 的唯一区别是不换 URL。
# 重放不了的体交给 replay 抛 BodyReplay：悄悄发一个空 body 过去是最坏的选择。
method replayed(--> Rakuest::Request) {
    return self unless $!body ~~ Rakuest::Body::Stream;

    my %args =
        method => $!method,
        url    => $!url,
        headers => %!headers,
        body   => $!body.replay,
        stream => $!stream,
        compress => $!compress,
        follow => $!follow,
        max-redirects => $!max-redirects;
    %args<content-type> = $!content-type with $!content-type;
    %args<timeout> = $!timeout with $!timeout;
    %args<http-version> = $!http-version with $!http-version;
    %args<progress> = $!progress with $!progress;
    self.WHAT.new(|%args);
}
