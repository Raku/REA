use NativeCall;
use Rakuest::Error;
use Rakuest::Util;

# 最小可用的 zlib 绑定：只做「整块 inflate / deflate」。
#
# 为什么不用 Compress::Zlib（生态里就它一个）：它的 `z_stream` 把字段声明成
# `CArray $.next-in` 和 `Str $.msg` —— 这两个是**受 GC 管理的类型**，而 CStruct
# 槽里存的其实是裸 C 指针。inflate 循环里只要触发一次 GC，GC 就会把 zlib 写进去的
# 指针当对象指针去标记，进程当场段错误。实测（Rakudo 2026.11 + Compress::Zlib
# 2.0.0）：只 `use` 它自己没事，一旦同时加载 IO::Socket::Async::SSL（Cro 的
# HTTPS 栈）就必崩 —— 所以「HTTP 客户端 + gzip 响应」这个组合在那边根本走不通。
#
# 这里所有指针槽一律用 uint64 存地址（CStruct 里的 Pointer 属性是不可变类型对象，
# 赋不了值），缓冲区用 Raku 的 buf8 自己持有、只把地址填进结构体，全程不让 GC 见到
# 一个它认得的对象指针。uLong 用 `long` 对齐（LP64 上是 8 字节，Windows 上是 4 字节，
# 和 C 的 unsigned long 一致），否则 sizeof(z_stream) 对不上，zlib 会直接拒收。
unit module Rakuest::Zlib;

my constant LIB = %*ENV<RAKUEST_ZLIB_LIB>
    // ($*DISTRO.is-win
        ?? 'zlib1'
        !! locate-native-lib('z', 'libz.so.1', 'libz.dylib', 'libz.1.dylib'));

# 与 zlib.h 的 z_stream 逐字段对应（顺序不能动）
class ZStream is repr('CStruct') {
    has uint64 $.next-in is rw;      # Bytef*
    has uint32 $.avail-in is rw;     # uInt
    has long   $.total-in is rw;     # uLong
    has uint64 $.next-out is rw;     # Bytef*
    has uint32 $.avail-out is rw;    # uInt
    has long   $.total-out is rw;    # uLong
    has uint64 $.msg is rw;          # char*
    has uint64 $.state is rw;        # internal_state*
    has uint64 $.zalloc is rw;
    has uint64 $.zfree is rw;
    has uint64 $.opaque is rw;
    has int32  $.data-type is rw;
    has long   $.adler is rw;
    has long   $.reserved is rw;
}

sub inflateInit2_(ZStream, int32, Str, int32) returns int32 is native(LIB) { * }
sub inflate(ZStream, int32) returns int32 is native(LIB) { * }
sub inflateEnd(ZStream) returns int32 is native(LIB) { * }
# 注意 deflateInit2_ 是 8 个参数：level, method, windowBits, memLevel, **strategy**,
# version, stream_size。漏掉 strategy 会把 version 的指针当 int 传进去，当场段错误。
sub deflateInit2_(ZStream, int32, int32, int32, int32, int32, Str, int32) returns int32 is native(LIB) { * }
sub deflate(ZStream, int32) returns int32 is native(LIB) { * }
sub deflateEnd(ZStream) returns int32 is native(LIB) { * }
sub zlibVersion() returns Str is native(LIB) { * }
sub zError(int32) returns Str is native(LIB) { * }

my constant Z-OK         = 0;
my constant Z-STREAM-END = 1;
my constant Z-NO-FLUSH   = 0;
my constant Z-FINISH     = 4;
my constant Z-DEFLATED   = 8;

# 每次向 zlib 递一个 64KB 的窗口。用「每轮新开窗口」而不是「一个不断长大的缓冲 +
# 指针偏移」，是因为 Raku 的 Pointer 不支持加减（`$p + 8` 得到的是 Int），在结构体
# 里存偏移地址反而更容易写错；多一次 64KB 拷贝换代码简单，划算。
my constant WINDOW = 65536;

# windowBits 的三档含义是 zlib 自己定的：
#   +15 → zlib 容器（RFC 1950）；-15 → 裸 deflate（RFC 1951）；31（=15+16）→ gzip。
my %FORMAT = gzip => 31, zlib => 15, raw => -15;

# 库在不在（纯查询，不抛异常）。和 Curl 后端一个套路：不可用要能说清原因。
my Int $STATE = 0;
my Str $WHY = '';

our sub available(--> Bool) is export {
    return True if $STATE == 1;
    return False if $STATE == -1;
    try {
        zlibVersion();
        $STATE = 1;
    }
    if $STATE != 1 {
        $STATE = -1;
        $WHY = (try $!.message) // '原生库加载失败';
    }
    $STATE == 1;
}

our sub unavailable-reason(--> Str) is export { available(); $WHY }
our sub zlib-version(--> Str) is export { available() ?? zlibVersion() !! '' }

# 用之前先过这一关：库不存在时给出「装什么 / 怎么指定」的话，
# 而不是让 NativeCall 抛一句 Cannot locate native library。
our sub ensure-available(Str :$encoding = 'gzip') is export {
    return if available();
    die X::Rakuest::ContentEncoding.new(
        :$encoding,
        detail => "本机找不到 zlib 动态库（库名 {LIB}；{$WHY}），无法解压 {$encoding} 响应；"
            ~ '装一个 zlib（Debian/Ubuntu: apt install zlib1g，macOS 自带），'
            ~ '或用 RAKUEST_ZLIB_LIB 指定库文件',
    );
}

# Blob 的裸地址。nativecast 到 CArray 拿到的是**视图**（写它等于写原 Blob），
# 再把视图转成 Pointer 取地址 —— 千万别把 CArray 存进结构体，那正是 Compress::Zlib
# 踩的坑（CArray 是受 GC 管理的类型）。
sub blob-address(Blob $b --> uint64) {
    nativecast(Pointer, nativecast(CArray[uint8], $b)).Int;
}

sub why(int32 $rc --> Str) { "zlib rc={$rc}（{zError($rc)}）" }

sub window-bits(Str $format --> int32) {
    %FORMAT{$format} // die X::Rakuest.new(detail => "不认识的 zlib 格式：{$format}");
}

# 整块解压。$format：gzip | zlib | raw。
our sub inflate-bytes(Blob $data, Str $format = 'gzip' --> Blob) is export {
    ensure-available(:encoding($format));
    return Buf.new unless $data.elems;

    my int32 $bits = window-bits($format);
    my $zs = ZStream.new;
    $zs.next-in = blob-address($data);
    $zs.avail-in = $data.elems;

    my $rc = inflateInit2_($zs, $bits, zlibVersion(), nativesizeof(ZStream));
    die X::Rakuest::ContentEncoding.new(
        detail => "zlib 初始化失败：{why($rc)}（{$format}）",
    ) unless $rc == Z-OK;

    my buf8 $out .= new;
    my $failure;
    loop {
        # 每轮一个新窗口：填进结构体的永远是窗口起点，不用做指针算术。
        my buf8 $win .= new;
        $win.reallocate(WINDOW);
        $zs.next-out = blob-address($win);
        $zs.avail-out = WINDOW;

        $rc = inflate($zs, Z-NO-FLUSH);
        my $produced = WINDOW - $zs.avail-out;
        $out.append($win.subbuf(0, $produced));

        last if $rc == Z-STREAM-END;
        unless $rc == Z-OK {
            $failure = why($rc);
            last;
        }
        # 输入吃完了却还没到 STREAM_END = 流被截断。必须报错：交给调用方半截正文
        # 比报错难查得多（响应头里的 Content-Length 还指着完整长度）。
        if $produced == 0 && $zs.avail-in == 0 {
            $failure = "输入数据不完整（{$format} 流被截断）";
            last;
        }
    }
    inflateEnd($zs);
    die X::Rakuest::ContentEncoding.new(detail => "inflate 失败：{$failure}") with $failure;
    $out;
}

# 整块压缩。给测试造 fixture 用，也顺手让「压了再解」能被自证一遍。
our sub deflate-bytes(Blob $data, Str $format = 'gzip', Int $level = 6 --> Blob) is export {
    ensure-available(:encoding($format));
    my int32 $bits = window-bits($format);
    my $zs = ZStream.new;
    $zs.next-in = blob-address($data);
    $zs.avail-in = $data.elems;

    my $rc = deflateInit2_($zs, $level, Z-DEFLATED, $bits, 8, 0,
                           zlibVersion(), nativesizeof(ZStream));
    die X::Rakuest::ContentEncoding.new(
        detail => "zlib 初始化失败：{why($rc)}（{$format}）",
    ) unless $rc == Z-OK;

    my buf8 $out .= new;
    my $failure;
    loop {
        my buf8 $win .= new;
        $win.reallocate(WINDOW);
        $zs.next-out = blob-address($win);
        $zs.avail-out = WINDOW;

        $rc = deflate($zs, Z-FINISH);
        $out.append($win.subbuf(0, WINDOW - $zs.avail-out));

        last if $rc == Z-STREAM-END;
        unless $rc == Z-OK {
            $failure = why($rc);
            last;
        }
    }
    deflateEnd($zs);
    die X::Rakuest::ContentEncoding.new(detail => "deflate 失败：{$failure}") with $failure;
    $out;
}
