# 只做 HTTP(S) 需要的 URL 处理：解析、RFC 3986 参考解析（含 ../ 归一）、
# 百分号编码、查询串拼接。刻意不追求完整 URI 规范，够用且可测。
unit module Rakuest::URI;

use Rakuest::Error;

class Parsed is export {
    has Str $.scheme = '';
    has Str $.host = '';
    has Int $.port;
    has Str $.path = '/';
    has Str $.query = '';

    method origin(--> Str) {
        my $default = $!scheme eq 'https' ?? 443 !! 80;
        ($!port.defined && $!port != $default)
            ?? "{$!scheme}://{$!host}:{$!port}"
            !! "{$!scheme}://{$!host}";
    }

    method dir(--> Str) {
        my $i = $!path.rindex('/');
        $i.defined ?? $!path.substr(0, $i + 1) !! '/';
    }

    method target(--> Str) {
        $!query eq '' ?? $!path !! "{$!path}?{$!query}";
    }
}

my $url-re = rx{
    ^
    $<scheme>=(<[A..Z a..z]>+) '://'
    [ $<userinfo>=(<-[:@/]>*) '@' ]?
    # 主机名可以缺席：file:///C:/x 这种「空主机 + 绝对路径」是合法的。
    # http(s) 缺主机由下面的检查挡掉。
    [ $<host>=( '[' <-[\]]>+ ']' | <-[:/?#]>+ ) ]?
    [ ':' $<port>=(\d+) ]?
    $<path>=('/' <-[?#]>**0..*)?
    [ '?' $<query>=(<-[#]>*) ]?
    [ '#' <-[\n]>* ]?
};

sub parse-url(Str $url --> Parsed) is export {
    my $m = $url.match($url-re);
    die X::Rakuest.new(detail => "无法解析的 URL：$url") without $m;

    my $scheme = $m<scheme>.Str.lc;
    my $host = $m<host>.defined ?? $m<host>.Str !! '';
    die X::Rakuest.new(detail => "URL 缺少主机名：$url")
        if $host eq '' && $scheme ne 'file';

    my $port = $m<port>.defined
        ?? $m<port>.Int
        !! ($scheme eq 'https' ?? 443 !! 80);

    Parsed.new(
        :$scheme,
        :$host,
        :$port,
        path  => $m<path>.defined  ?? $m<path>.Str  !! '/',
        query => $m<query>.defined ?? $m<query>.Str !! '',
    );
}

# 归一化路径中的 . 与 ..（保留开头的 /）
sub normalize-path(Str $path --> Str) {
    my ($p, $q) = $path.split('?', 2);
    my $query = $q.defined ?? "?$q" !! '';
    my @out;
    for $p.split('/') -> $seg {
        next if $seg eq '.';
        if $seg eq '..' {
            @out.pop if @out.elems > 1;
            next;
        }
        @out.push($seg);
    }
    my $joined = @out.join('/');
    $joined = '/' if $joined eq '';
    $joined ~ $query;
}

sub resolve-url(Str $base, Str $ref --> Str) is export {
    my $r = $ref.split('#', 2)[0] // '';
    return $base if $r eq '';
    return $r if $r.match(rx{ ^ <[A..Z a..z]>+ '://' });

    my $b = parse-url($base);
    return "{$b.scheme}:$r" if $r.starts-with('//');
    return $b.origin ~ $b.path ~ $r if $r.starts-with('?');
    return $b.origin ~ normalize-path($r) if $r.starts-with('/');
    $b.origin ~ normalize-path($b.dir ~ $r);
}

sub percent-encode(Str $s --> Str) is export {
    $s.encode('utf-8').list.map(-> $c {
        (0x30 <= $c <= 0x39) || (0x41 <= $c <= 0x5A) || (0x61 <= $c <= 0x7A)
            || $c == 0x2D || $c == 0x2E || $c == 0x5F || $c == 0x7E
            ?? $c.chr
            !! '%' ~ $c.fmt('%02X');
    }).join;
}

sub query-string(%params --> Str) is export {
    my @parts;
    for %params.kv -> $k, $v {
        if $v ~~ Positional {
            @parts.push(percent-encode($k) ~ '=' ~ percent-encode($_.Str)) for $v;
        } else {
            @parts.push(percent-encode($k) ~ '=' ~ percent-encode($v.Str));
        }
    }
    @parts.join('&');
}
