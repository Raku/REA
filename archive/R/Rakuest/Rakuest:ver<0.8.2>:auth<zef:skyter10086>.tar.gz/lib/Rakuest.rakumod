unit module Rakuest;

# 只加载、不导入符号（need 而非 use）：
#   · 这些类都以全名使用（Rakuest::Client 等），不需要 import；
#   · 在带预编译的入口模块里，`use` 会把导出符号塞进本包，
#     之后再加载同类 compunit 会触发包符号冲突，导致后面这些类在运行时缺席。
# 唯一的例外是 Rakuest::Error：`use Rakuest;` 之后要能直接写
# `CATCH { when X::Rakuest { … } }`，所以它得真的导入进来（见文件末尾的 EXPORT）。
use Rakuest::Error;
need Rakuest::URI;
need Rakuest::Util;
need Rakuest::Body;
need Rakuest::Event;
need Rakuest::Form;
need Rakuest::Progress;
need Rakuest::Progress::Tracker;
need Rakuest::Request;
need Rakuest::Response;
need Rakuest::CookieJar;
need Rakuest::Transport;
need Rakuest::Client;

# 只导出异常基类这一个符号：X::Rakuest 这个类型对象本身就是其余异常的包，
# `X::Rakuest::Timeout` 之类顺着它的 stash 解析得到，不必逐个再导出。
sub EXPORT(--> Map) {
    Map.new('X::Rakuest' => X::Rakuest);
}

#   use Rakuest;
#   my $c = Rakuest::Client.new(base-url => 'https://360.zef.pm');
#   my $r = $c.get('/');
