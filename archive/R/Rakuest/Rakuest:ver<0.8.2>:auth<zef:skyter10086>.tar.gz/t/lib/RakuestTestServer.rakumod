# 测试用极简 HTTP/1.1 服务器原语。
#
# 为什么不用 Cro 起测试服务器：要验的正是「裸字节层面发生了什么」——
# chunked 分块有没有真的分块、keep-alive 有没有真的复用同一条 socket。
# 走 Cro 的话这些细节都被它隐藏了。
#
# 也不绑定固定端口：Windows 上有整段端口被 Hyper-V 预留（本机 45610+ 全绑不上），
# 所以随机撒点、能绑就用，并把实际端口回传给调用方。
#
# 读请求的方式很笨但很硬：**只用 read**。
#   · read(1) 切行 —— 一个字节一个字节地找 LF，没有任何内部预读缓冲；
#   · read(n) 读正文 —— 会一直阻塞到凑满 n 字节或对端关闭，正好是我们要的语义。
# 一开始用 `$conn.get` 切行 + `$conn.read` 读正文，结果是「字节数对、内容错一半」：
# get 会预读进句柄自己的缓冲，read 又直接从 socket 拿，两边对不齐。这类 bug 极难查，
# 所以这里宁可慢一点，也不要聪明的 IO 封装。
unit module RakuestTestServer;

class Received is export {
    has Str $.method = '';
    has Str $.target = '';
    has %.headers;
    has $.body;                    # Buf
    has Bool $.chunked = False;
    has Int $.chunks = 0;
}

sub listen-anywhere(--> List) is export {
    for (20000..40000).roll(300) -> $p {
        my $s;
        try { $s = IO::Socket::INET.new(:listen, :localhost<127.0.0.1>, :localport($p)); }
        return ($p, $s) if $s.defined;
    }
    (Nil, Nil);
}

class Reader {
    has $!conn;

    submethod BUILD(:$!conn) { }

    # 读到 LF 为止（含 CRLF 时去掉 CR）。EOF 返回 Str 类型对象。
    method read-line(--> Str) {
        my $buf = Buf.new;
        loop {
            my $b = $!conn.read(1);
            return Str if !$b.defined || $b.elems == 0;
            last if $b[0] == 10;
            $buf.append($b);
        }
        $buf.decode('utf-8').subst(/\r$/, '');
    }

    method read-bytes(Int $n --> Buf) {
        my $out = Buf.new;
        while $out.elems < $n {
            my $piece = $!conn.read($n - $out.elems);
            last unless $piece.defined && $piece.elems;
            $out.append($piece);
        }
        $out;
    }
}

# 读一个完整的请求。连接已关闭时返回 Nil（keep-alive 循环靠它退出）。
sub read-request($conn --> Received) is export {
    my $reader = Reader.new(:$conn);

    my $first = $reader.read-line;
    return Nil unless $first.defined && $first.chars;

    my @parts = $first.trim.split(' ');
    my %headers;
    loop {
        my $h = $reader.read-line;
        last without $h;
        my $t = $h.trim;
        last if $t eq '';
        my $i = $t.index(':');
        next without $i;
        %headers{$t.substr(0, $i).trim.lc} = $t.substr($i + 1).trim;
    }

    # 客户端在等 100-continue 时不发正文，先给它，否则两边互等。
    if (%headers<expect> // '').lc.contains('100-continue') {
        $conn.print("HTTP/1.1 100 Continue\r\n\r\n");
    }

    my $encoding = (%headers<transfer-encoding> // '').lc;
    my $chunked = $encoding.contains('chunked');

    my $body = Buf.new;
    my $chunks = 0;

    if $chunked {
        loop {
            my $size-line = $reader.read-line;
            last without $size-line;
            my $spec = $size-line.trim.split(';')[0].trim;
            last unless $spec.chars;
            my $n = (try { :16($spec) }) // 0;
            last if $n <= 0;
            my $piece = $reader.read-bytes($n);
            if $piece.elems {
                $body.append($piece);
                $chunks++;
            }
            $reader.read-bytes(2);                # 每个块后面的 CRLF
        }
        while (my $t = $reader.read-line) { last if $t.trim eq '' }    # trailer
    }
    elsif %headers<content-length>:exists {
        my $want = (%headers<content-length> // '0').Int;
        my $got = $reader.read-bytes($want);
        if $got.elems {
            $body.append($got);
            $chunks++;
        }
    }

    Received.new(
        method  => @parts[0] // '',
        target  => @parts[1] // '',
        :%headers,
        :$body,
        :$chunked,
        :$chunks,
    );
}

# 起一个「收一个连接、做一件事、关门」的服务器。
# handler 收到 socket，自己调 read-request 再写响应。
# 返回 ($port, Promise)，Promise 在服务器收工时兑现。
sub serve-once(&handler --> List) is export {
    my ($port, $server) = listen-anywhere().List;
    return (Nil, Nil) unless $port.defined;

    my $done = Promise.new;
    start {
        my $conn;
        try {
            $conn = $server.accept;
            handler($conn);
            CATCH { default { note "测试服务器出错：{$_.message}" } }
        }
        $conn.close if $conn.defined;
        $server.close;
        $done.keep(True);
    }
    ($port, $done);
}

# 依次处理 $count 个连接（重定向、多跳这类场景要多个连接）。
sub serve-many(Int $count, &handler --> List) is export {
    my ($port, $server) = listen-anywhere().List;
    return (Nil, Nil) unless $port.defined;

    my $done = Promise.new;
    start {
        for ^$count {
            my $conn;
            try { $conn = $server.accept }
            last unless $conn.defined;
            try { handler($conn) }
            $conn.close;
        }
        $server.close;
        $done.keep(True);
    }
    ($port, $done);
}

sub reply($conn, Str $status-line, Str $body, Bool :$keep-alive = False --> Nil) is export {
    my $conn-hdr = $keep-alive ?? 'keep-alive' !! 'close';
    $conn.print(
        "$status-line\r\nContent-Type: text/plain\r\nContent-Length: {$body.encode('utf-8').elems}\r\n"
        ~ "Connection: $conn-hdr\r\n\r\n$body"
    );
    Nil;
}
