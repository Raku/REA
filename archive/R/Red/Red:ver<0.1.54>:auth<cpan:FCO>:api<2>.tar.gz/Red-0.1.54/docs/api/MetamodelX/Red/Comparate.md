MetamodelX::Red::Comparate
--------------------------

### method add-comparate-methods

```raku
method add-comparate-methods(
    Mu:U \type,
    Red::Attr::Column $attr
) returns Empty
```

An internal method that generates Red getters and setters for an attribute $attr of a type.

