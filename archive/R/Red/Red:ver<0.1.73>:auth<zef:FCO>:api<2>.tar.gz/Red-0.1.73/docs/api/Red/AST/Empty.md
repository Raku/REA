class Red::AST::Empty
---------------------

Represents an empty return

