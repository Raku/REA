use Red <shortname>;
