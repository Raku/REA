class Red::AST::Delete
----------------------

Represents a delete

