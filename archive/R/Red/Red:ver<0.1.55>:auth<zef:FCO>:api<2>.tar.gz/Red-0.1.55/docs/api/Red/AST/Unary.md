

Base role for unary operators

class Red::AST::Cast
--------------------

Represents a cast operation

class Red::AST::Not
-------------------

Represents a not operation

class Red::AST::So
------------------

Represents a so operation

