

Base role to schema readers used to read DB Schema

