class Red::AST::Unique
----------------------

Represents an unique constraint

class Red::AST::Pk
------------------

Represents a primary key constraint

