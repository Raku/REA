class Red::AST::Intersect
-------------------------

Represents a intersect between 2 (or more) selects

