class Red::AST::Insert
----------------------

Represents an insert

