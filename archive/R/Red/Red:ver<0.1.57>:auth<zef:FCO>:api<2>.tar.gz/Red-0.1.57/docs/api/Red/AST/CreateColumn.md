class Red::AST::CreateColumn
----------------------------

Represents an alter table add column

