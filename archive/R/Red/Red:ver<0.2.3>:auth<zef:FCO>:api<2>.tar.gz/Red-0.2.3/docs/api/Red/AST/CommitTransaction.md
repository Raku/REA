class Red::AST::CommitTransaction
---------------------------------

AST to run a commit

