class Red::AST::Between
-----------------------

Represents a function call

