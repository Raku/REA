

Base role for string functions

class Red::AST::Substring
-------------------------

Represents a substring call

class Red::AST::Index
---------------------

Represents a index call

class Red::AST::Lowercase
-------------------------

Represents a lc/fc call

class Red::AST::Uppercase
-------------------------

Represents a uc call

