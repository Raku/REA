class Red::AST::JsonItem
------------------------

Represents a json item

