class Red::AST::Select
----------------------

Represents a Select

