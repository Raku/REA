

Base role for date time functions

class Red::AST::DateTimePart
----------------------------

Represents a function that extracts a part of a date time

class Red::AST::DateTimeCoerce
------------------------------

Coerce a DateTime, timestamp etc to just date for comparisons

