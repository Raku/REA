class Red::AST::ChangeColumn
----------------------------

Represents an alter table alter column

