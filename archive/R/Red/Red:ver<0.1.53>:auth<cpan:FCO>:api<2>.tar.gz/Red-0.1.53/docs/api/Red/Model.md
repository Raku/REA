Red::Model
----------



Base role for models

