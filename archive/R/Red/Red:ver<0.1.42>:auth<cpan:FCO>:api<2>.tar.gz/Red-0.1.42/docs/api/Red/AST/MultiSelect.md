

Base role to multi selects (union, intersect, minus)

