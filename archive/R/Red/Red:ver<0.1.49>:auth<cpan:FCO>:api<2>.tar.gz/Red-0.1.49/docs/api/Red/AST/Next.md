class Red::AST::Next
--------------------

Represents a next call

