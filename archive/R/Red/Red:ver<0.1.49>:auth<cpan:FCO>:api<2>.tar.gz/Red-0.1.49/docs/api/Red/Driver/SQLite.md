### multi method should-drop-cascade

```perl6
multi method should-drop-cascade() returns Mu
```

Does this driver accept drop table cascade?

