module Red::Phaser
------------------

Define Red phasers

