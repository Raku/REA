class Red::AST::BeginTransaction
--------------------------------

AST to run a begin

