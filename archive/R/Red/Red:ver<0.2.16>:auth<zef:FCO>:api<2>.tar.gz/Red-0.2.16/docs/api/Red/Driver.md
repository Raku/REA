Red::Driver
-----------



Base role for a Red::Driver::*

### has Supply $.events

Supply of events of that driver

### method driver-name

```raku
method driver-name() returns Mu
```

Public backend name, independent of internal transaction wrappers.

### method connection-id

```raku
method connection-id() returns Str:D
```

Stable identity shared by a driver and the connection clones created by C<begin>.

### method begin

```raku
method begin() returns Mu
```

Begin transaction

### method commit

```raku
method commit() returns Mu
```

Commit transaction

### method rollback

```raku
method rollback() returns Mu
```

Rollback transaction

### method savepoint

```raku
method savepoint(
    Str:D $name
) returns Mu
```

Creates a savepoint on the current connection

### method rollback-to-savepoint

```raku
method rollback-to-savepoint(
    Str:D $name
) returns Mu
```

Rolls back to a savepoint, leaving it active

### method release-savepoint

```raku
method release-savepoint(
    Str:D $name
) returns Mu
```

Releases a savepoint without committing the surrounding transaction

### method auto-register

```raku
method auto-register(
    |
) returns Mu
```

Self-register its events on Red.events

### method emit

```raku
method emit(
    $data?
) returns Mu
```

Emit events

### method should-drop-cascade

```raku
method should-drop-cascade() returns Mu
```

Does this driver accept drop table cascade?

### method emit

```raku
method emit(
    Red::Event $event
) returns Mu
```

Emit events

### method prepare

```raku
method prepare(
    Red::AST $query
) returns Mu
```

Prepares a DB statement

### method compile-query

```raku
method compile-query(
    Red::AST:D $query,
    :@parameters = Code.new
) returns Red::QueryPlan:D
```

Compile independently of the lifetime of a connection or statement.

### method is-valid-table-name

```raku
method is-valid-table-name(
    Str $
) returns Bool
```

Checks if a name is a valid table name

### method type-by-name

```raku
method type-by-name(
    "varchar"
) returns "varchar(255)"
```

Maps types

### method type-by-name

```raku
method type-by-name(
    "string"
) returns "text"
```

Maps types

### method type-by-name

```raku
method type-by-name(
    "int"
) returns "integer"
```

Maps types

### method map-exception

```raku
method map-exception(
    $orig-exception
) returns Mu
```

Maps exception

### method inflate

```raku
method inflate(
    $value,
    :$to
) returns Mu
```

Default inflator

### method execute

```raku
method execute(
    $query,
    *@bind
) returns Mu
```

Execute query

### method optimize

```raku
method optimize(
    Red::AST $in
) returns Red::AST
```

Optimize AST

### method database-client

```raku
method database-client() returns Hash
```

Build the native client invocation for this backend.

### method advance-sequences

```raku
method advance-sequences(
    @models
) returns Mu
```

Synchronize generated identifiers after inserting explicit values.

### method finish-statement

```raku
method finish-statement(
    $statement,
    Bool :$executed = Bool::False
) returns Mu
```

Release an executed cursor before ending its transaction.

### method type-by-name

```raku
method type-by-name(
    "serial"
) returns Str:D
```

Physical integer spelling for the portable serial column abstraction.

