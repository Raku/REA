DROP TABLE "comment";
