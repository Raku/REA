use v6;
use Red::Do;
use Red::Model;
use Red::Attr::Column;
use Red::Column;
use Red::ColumnMethods;
use Red::Utils;
use Red::ResultSeq;
use Red::DefaultResultSeq;
use Red::Attr::Query;
use Red::AST;
use MetamodelX::Red::Model;
use Red::Traits;
use Red::Operators;
use Red::Database;
use Red::AST::Optimizer::AND;
use Red::AST::Optimizer::OR;
use Red::AST::Optimizer::Case;
use Red::Class;
use Red::DB;
use Red::Schema;
use Red::Formatter;
use Red::AST::Infixes;
use Red::AST::Native;
use Red::Compiler::RakuAST;

class Red:ver<0.2.10>:api<2> {
    our %experimentals;
    our @experimental-roles;
    method events   { Red::Class.instance.events }
    method emit(|c) { get-RED-DB.emit: |c        }
    method experimentals { %experimentals }
    method ping {
        do for (%GLOBAL::RED-DEFAULT-DRIVERS || :default(get-RED-DB)).kv -> $key, $conn {
            $key => $conn.ping
        }.Map
    }
    method exports(@experimentals --> Map()) {
        %Red::experimentals{$_} = True for @experimentals;
        Red::Do::EXPORT::ALL::,
        Red::Traits::EXPORT::ALL::,
        Red::Operators::EXPORT::ALL::,
        Red::Schema::EXPORT::ALL::,
        Red::AST::Native::EXPORT::ALL::,
        ‘&database’ => &database,
        '&red-compile' => &red-compile,
        |@experimentals.map(-> $feature { |experimental( $feature ) })
    }
}

my %unsupported-raku-versions{Version} =
    v2022.06 => [
        "2022.06 has a bug that calls `iterator` method on instantiation of a class",
        "that does `Positional` and `Sequence` roles and have attributes with initialisation,",
        "making it impossible to use `Red::ResultSeq`. Please update your Raku to use Red.",
    ],
    v2024.03 => [
        "2024.03 has a bug that breaks ClassHOW does role. Please update your Raku to use Red.",
    ],
;

BEGIN {
    Red::Column.^add_role: Red::ColumnMethods;
    Red::Column.^compose;

    for <AND OR Case> -> $infix {
        ::("Red::AST::$infix").^add_role: ::("Red::AST::Optimizer::$infix");
        ::("Red::AST::$infix").^compose;
    }
}

my package EXPORTHOW {
    my $ver = $*RAKU.compiler.version;
    die "\o33[31;1m$ver\o33[m is \o33[1mnot\o33[m supported by \o33[31;1mRed\o33[m:\n" ~ .join("\n").indent: 8 with %unsupported-raku-versions{$ver};

    package DECLARE {
        constant model = MetamodelX::Red::Model;
    }
}

proto experimental(Str) {*}

multi experimental("shortname") {
    MetamodelX::Red::Model.^add_method: "experimental-name", method (\model) { model.^shortname }
    MetamodelX::Red::Model.^compose;
    Empty
}

multi experimental("formatters") {
    MetamodelX::Red::Model.^add_method: "experimental-formatter", method { True }
    Red::Column.^add_method: "experimental-formatter", method { True }
    MetamodelX::Red::Model.^compose;
    Red::Column.^compose;
    Empty
}

multi experimental($ where "experimental migrations" | "migrations") {
    require ::('MetamodelX::Red::Migration');
    @Red::experimental-roles.push: ::('MetamodelX::Red::Migration');

    Empty
}

multi experimental("supply") {
    require ::('MetamodelX::Red::Supply');
    @Red::experimental-roles.push: ::('MetamodelX::Red::Supply');

    Empty
}

multi experimental("is-handling") {
    Empty
}

multi experimental("has-one") {
    Empty
}

multi experimental("refreshable") {
    Empty
}

multi experimental($feature) { die "Experimental feature '{ $feature }' not recognized." }

multi EXPORT(+@experimentals) {
	#my $no = "no-optimization";
    	#if @experimentals.none eq $no {
	#        require ::("Red::AST::Infixes");
    	#        for <AND OR Case> -> $infix {
	#		::("Red::AST::$infix").^add_role: ::("Red::AST::Optimizer::$infix");
	#		::("Red::AST::$infix").^compose;
    	#        }
    	#} else {
    	#        @experimentals .= grep: { $_ ne $no }
    	#}
    Red.exports(@experimentals)
}

=begin pod

[![Build Status](https://github.com/FCO/Red/workflows/test/badge.svg)](https://github.com/FCO/Red/actions)
[![SparrowCI](https://ci.sparrowhub.io/project/gh-FCO-Red/badge)](https://ci.sparrowhub.io)

=begin head1
Red
=end head1

B<Experimental migrations:> manage versioned schema and data changes with C<red migration>.
The API and migration formats may change. See L<basic usage|#experimental-migrations>.
Read the L<migration workflow|docs/migrations.md>
or follow the L<Docker workshop|examples/migrations/README.md>.

Take a look at our Documentation: L<https://fco.github.io/Red/>

=head2 Red - A **WiP** ORM for Raku

=head2 RECENT HIGHLIGHTS

**PostgreSQL users: the Pg driver is no longer bundled with Red.** Install the separate `Red::Driver::Pg` distribution when installing or upgrading:

    zef install Red::Driver::Pg

Other recent highlights include:

=item B<Queries:> opt-in RakuAST compilation, compiled regex filters translated to SQL, and isolated SQL plan caching. See L<compiled regex filters|#compiled-regex-filters>.

=item B<Schema:> named, composite and partial indexes, C<CHECK> and PostgreSQL C<EXCLUDE> constraints, and native range/regex helpers. See L<indexes and constraints|#named-indexes-and-schema-constraints> and L<PostgreSQL ranges|#postgresql-ranges-regex-and-exclusion-constraints>.

=item B<Transactions:> nested savepoints and explicit guards with asynchronous work. See L<transactions and savepoints|#transactions-and-savepoints>.

=item B<Models and relationships:> creation through empty scalar relationships, stable C<has-one>, C<.^refresh> and C<is handling>, plus dirty tracking for in-place collection mutations. See L<relationship creation|#creating-through-a-scalar-relationship>, L<refresh|#refresh> and L<is handling|#is-handling>.

=item B<Results and JSON:> chainable scalar/container projections, SQL C<tail>/C<reverse>, C<ResultSeq> products and expanded JSON operations.

=item B<Performance and reliability:> faster hydration and projections, safer concurrent query/class initialization, and fixes for generated getters and formatter handling.

See [Changes](Changes) for the complete list.

=head2 EXPERIMENTAL MIGRATIONS

Configure your existing Red models and database in C<red.rakuconf> at the project root.
For example, with a model available as C<lib/MyApp/Task.rakumod>:

=begin code :lang<raku>
use lib 'lib';
use Red:api<2>;
use Red::Migration::Configuration;

config {
    .models = ['MyApp::Task'];
    .drivers = ['SQLite'];
    .directory = 'migrations';
    .connections = %(
        default => { database 'SQLite', :database<development.sqlite> },
    );
}
=end code

Application queries also use C<< .connections<default> >> automatically, and C<schema()>
returns the configured models:

=begin code :lang<raku>
use lib 'lib';
use Red:api<2>;
use MyApp::Task;

say schema().models.keys;
MyApp::Task.^create(:title<Example>);
=end code

Run from the directory containing C<red.rakuconf>. Loading a schema does not open
the database; lazy connections are reused per thread on first database use.
Explicit C<$*RED-DB> and C<red-defaults> take precedence. Tests can replace the
configuration with C<set-config> from C<Red::Migration::Configuration>.
Supplying models explicitly to C<schema(...)> keeps the existing behavior.

Run these commands from the project root:

=begin code :lang<sh>
red migration prepare initial  # Generate SQL and schema snapshots; do not change the database.
red migration apply --test     # Validate the history in a disposable database.
red migration apply            # Apply pending versions to the configured default connection.
red migration status           # Show database initialization and migration states.
red migration init-tests       # Create t/migrations.rakutest for your project's test suite.
=end code

Review the generated SQL before applying it and commit the C<migrations/> directory.
After changing your models, run C<red migration prepare change-name>, validate and apply again.
Preparation compares models with the last prepared snapshot, initially an empty schema;
it does not automatically adopt an existing database. PostgreSQL and MySQL are also supported
through their separate driver distributions.

For changes requiring data preparation, use C<red migration create change-name>, edit the
generated C<migration.raku>, then run C<red migration prepare change-name>. Data updates and
final constraints execute synchronously during apply. Rollback uses C<red migration rollback>
when the version has an available inverse; it cannot automatically recover overwritten data.
Supported changes vary by driver, and SQLite table reconstruction requires manual SQL.

See the L<migration workflow|docs/migrations.md> for data transformations, production
connections, rollback, driver backfill and parallel histories, or follow the
L<Docker workshop|examples/migrations/README.md> for a guided deployment exercise.

=head2 INSTALL

Install with (you need **rakudo 2018.12-94-g495ac7c00** or **newer**):

    zef install Red

PostgreSQL support is provided by a separate distribution. Install it only if you use PostgreSQL:

    zef install Red::Driver::Pg

=head2 SYNOPSIS

=begin code :lang<raku>

use Red:api<2>;

model Person {...}

model Post is rw {
    has Int         $.id        is serial;
    has Int         $!author-id is referencing( *.id, :model(Person) );
    has Str         $.title     is column{ :unique };
    has Str         $.body      is column;
    has Person      $.author    is relationship{ .author-id };
    has Bool        $.deleted   is column = False;
    has DateTime    $.created   is column .= now;
    has Set         $.tags      is column{
        :type<string>,
        :deflate{ .keys.join: "," },
        :inflate{ set(.split: ",") }
    } = set();
    method delete { $!deleted = True; self.^save }
}

model Person is rw {
    has Int  $.id            is serial;
    has Str  $.name          is column;
    has Post @.posts         is relationship{ .author-id };
    method active-posts { @!posts.grep: not *.deleted }
}

my $*RED-DB = database "SQLite";

Person.^create-table;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
CREATE TABLE person(
    id integer NOT NULL primary key
    AUTOINCREMENT,
    name varchar(255) NOT NULL
)
=end code

=begin code :lang<raku>
Post.^create-table;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
CREATE TABLE post(
    id integer NOT NULL primary key AUTOINCREMENT,
    author_id integer NULL references person(id),
    title varchar(255) NOT NULL,
    body varchar(255) NOT NULL,
    deleted integer NOT NULL,
    created varchar(32) NOT NULL,
    tags varchar(255) NOT NULL,
    UNIQUE (title)
)
=end code

=begin code :lang<raku>
my Post $post1 = Post.^load: :42id;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    post.id,
    post.author_id as "author-id",
    post.title,
    post.body,
    post.deleted,
    post.created,
    post.tags
FROM
    post
WHERE
    post.id = 42
=end code

=begin code :lang<raku>
my Post $post1 = Post.^load: 42;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    post.id,
    post.author_id as "author-id",
    post.title,
    post.body,
    post.deleted,
    post.created,
    post.tags
FROM
    post
WHERE
    post.id = 42
=end code

=begin code :lang<raku>
my Post $post1 = Post.^load: :title("my title");
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    post.id,
    post.author_id as "author-id",
    post.title,
    post.body,
    post.deleted,
    post.created,
    post.tags
FROM
    post
WHERE
    post.title = ‘my title’
=end code

=begin code :lang<raku>
my $person = Person.^create: :name<Fernando>;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
INSERT INTO person(
    name
)
VALUES(
    $1
) RETURNING *
-- BIND: ["Fernando"]
=end code

=begin code :lang<raku>
RETURNS:
Person.new(name => "Fernando")
=end code

=begin code :lang<raku>
say $person.posts;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    post.id,
    post.author_id as "author-id",
    post.title,
    post.body,
    post.deleted,
    post.created,
    post.tags
FROM
    post
WHERE
    post.author_id = ?
-- BIND: [1]
=end code

=begin code :lang<raku>
say Person.new(:2id)
    .active-posts
    .grep: { .created > now }
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    post.id,
    post.author_id as "author-id",
    post.title,
    post.body,
    post.deleted,
    post.created,
    post.tags
FROM
    post
WHERE
    (
       post.author_id = ?
       AND (
           post.deleted == 0
           OR post.deleted IS NULL
       )
    )
    AND post.created > 1554246698.448671
-- BIND: [2]
=end code

=begin code :lang<raku>
my $now = now;
say Person.new(:3id)
    .active-posts
    .grep: { .created > $now }
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    post.id,
    post.author_id as "author-id",
    post.title,
    post.body,
    post.deleted,
    post.created,
    post.tags
FROM
    post
WHERE
    (
       post.author_id = ?
       AND (
           post.deleted == 0
           OR post.deleted IS NULL
       )
    )
    AND post.created > ?
-- BIND: [
--   3,
--   Instant.from-posix(
--       <399441421363/257>,
--       Bool::False
--   )
-- ]
=end code

=begin code :lang<raku>
Person.^create:
    :name<Fernando>,
    :posts[
        {
            :title("My new post"),
            :body("A long post")
        },
    ]
;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
INSERT INTO person(
    name
)
VALUES(
    ?
) RETURNING *
-- BIND: ["Fernando"]

INSERT INTO post(
    created,
    title,
    author_id,
    tags,
    deleted,
    body
)
VALUES(
    ?,
    ?,
    ?,
    ?,
    ?,
    ?
) RETURNING *
-- BIND: [
--   "2019-04-02T22:55:13.658596+01:00",
--   "My new post",
--   1,
--   "",
--   Bool::False,
--   "A long post"
-- ]
=end code

=begin code :lang<raku>
my $post = Post.^load: :title("My new post");
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    post.id,
    post.author_id as "author-id",
    post.title,
    post.body,
    post.deleted,
    post.created,
    post.tags
FROM
    post
WHERE
    post.title = ‘My new post’
-- BIND: []
=end code

=begin code :lang<raku>
RETURNS:
Post.new(
   title   => "My new post",
   body    => "A long post",
   deleted => 0,
   created => DateTime.new(
       2019,
       4,
       2,
       23,
       7,
       46.677388,
       :timezone(3600)
   ),
   tags    => Set.new("")
)
=end code

=begin code :lang<raku>
say $post.body;
=end code

=begin code :lang<raku>
PRINTS:
A long post
=end code

=begin code :lang<raku>
my $author = $post.author;
=end code

=begin code :lang<raku>
RETURNS:
Person.new(name => "Fernando")
=end code

=begin code :lang<raku>
$author.name = "John Doe";

$author.^save;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
UPDATE person SET
    name = ‘John Doe’
WHERE id = 1
=end code

=begin code :lang<raku>
$author.posts.create:
    :title("Second post"),
    :body("Another long post");
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
INSERT INTO post(
    title,
    body,
    created,
    tags,
    deleted,
    author_id
)
VALUES(
    ?,
    ?,
    ?,
    ?,
    ?,
    ?
) RETURNING *
-- BIND: [
--   "Second post",
--   "Another long post",
--   "2019-04-02T23:28:09.346442+01:00",
--   "",
--   Bool::False,
--   1
-- ]
=end code

=begin code :lang<raku>
$author.posts.elems;
=end code

=begin code :lang<sql>
-- Equivalent to the following query:
SELECT
    count(*) as "data_1"
FROM
    post
WHERE
    post.author_id = ?
-- BIND: [1]
=end code

=begin code :lang<raku>
RETURNS:
2
=end code

=head2 DESCRIPTION

Red is a *WiP* ORM for Raku.

=head3 traits

=item C<is column>
=item C<is column{}>
=item C<is id>
=item C<is id{}>
=item C<is serial>
=item C<is referencing{}>
=item C<is relationship{}>
=item C<is table<>>
=item C<is nullable>
=item C<is handling>

=head3 features:

=head4 relationships

Red will infer relationship data if you use type constraints on your properties.

=begin code :lang<raku>
# Single file e.g. Schema.pm6

model Related { ... }


# belongs to
model MyModel {
    has Int     $!related-id is referencing( *.id, :model<Related> );
    has Related $.related    is relationship{ .id };
}

# has one/has many
model Related {
    has Int $.id is serial;
    has MyModel @.my-models is relationship{ .related-id };
}
=end code

If you want to put your schema into multiple files, you can create an "indirect"
relationship, and Red will look up the related models as necessary.

=begin code :lang<raku>
# MyModel.pm6
model MyModel {
    has Int     $!related-id is referencing{ :model<Related>, :column<id> };
    has         $.related    is relationship({ .id }, :model<Related>);
}

# Related.pm6
model Related {
    has Int $.id is serial;
    has     @.my-models is relationship({ .related-id }, :model<MyModel>);
}
=end code

If Red can’t find where your C<model> is defined you can override where it looks
with C<require>:

=begin code :lang<raku>
    has Int     $!related-id is referencing{ :model<Related>, :column<id>,
                                             :require<MyApp::Schema::Related> };
=end code

=head4 creating through a scalar relationship

An empty scalar relationship returns an undefined, false type object carrying
the relationship's creation context, rather than C<Nil>. Call C<.^create> on
that object to create the related row and fill the foreign key automatically:

=begin code :lang<raku>
my $parent = $child.parent.^create(:name<parent>);

# For a relationship declared with :has-one:
my $profile = $account.profile.^create(:description<profile>);
=end code

For a belongs-to relationship, Red saves the foreign key on the existing source
row. For C<:has-one>, Red supplies the source key to the new related row. The
source must already be saved. Both writes participate in one transaction; a
failed operation rolls back its writes and restores the source's attribute and
dirty state. Inside a transaction, the operation uses a savepoint.

Existing relationships continue to return their related instances. An empty
relationship still tests false and undefined, but code that checks specifically
for C<Nil> should use C<.defined> instead. Creation uses C<.^create>, while
plural relationships continue to use C<.create>.

=head4 named indexes and schema constraints

Independent schema declarations use ordinary attributes that do not become
columns or appear in row data. Existing C<is indexed>, C<is unique>,
C<is index{...}> and C<is unique-index{...}> forms remain supported.

=begin code :lang<raku>
model Measurement {
    has UInt $.id is serial;
    has Rat $.percent is column;
    has Str $.name is column;
    has Int $.active is column;

    has $!percent-valid is check{ sql-and(.percent >= 0, .percent <= 1) };
    has $!name-tree is index({ .name }, :using<btree>);
    has $!name-search is index({ .name },
        :using<gin>, :opclass<gin_trgm_ops>, :driver<Pg>);
    has $!active-name is unique-index({ .name },
        :where{ .active == 1 }, :driver<Pg>);
}
=end code

C<:using> selects an access method. PostgreSQL supports C<btree>, C<hash>,
C<gin>, C<gist>, C<spgist> and C<brin>; the common API supports C<btree>.
C<:opclass> selects a PostgreSQL operator class. For multiple keys, supply a list
with one string per key, using an empty string for the default class. A class can
be qualified with its schema. C<:where> defines a partial index on PostgreSQL or
SQLite; MySQL rejects an unguarded partial index.

C<:driver<Pg>> explicitly selects a declaration only for that backend. The names
are C<Pg>, C<SQLite> and C<MySQL>, or a custom driver's final class-name component.
Without this option an unsupported declaration raises C<X::Red::Index>; Red
does not substitute another index method or weaken a constraint. Conditional
constraints are intentionally absent on the other backends.

C<CHECK> is included by C<.^create-table> and C<schema.create> and is enforced
by the database for both inserts and updates, including writes outside Red.
Use C<sql-and>, C<sql-or> and C<sql-not> for compound predicates. Raku's
short-circuit C<&&> and C<||> are rejected in schema predicates rather than
changing SQL's three-valued logic. SQL's usual NULL semantics apply: a CHECK is
not a substitute for NOT NULL.

C<.^create-indexes> adds indexes to existing tables and checks existing names,
key order, uniqueness, access method, operator classes and partial predicates.
It rejects incompatible definitions instead of silently accepting them. It does
not add or alter CHECK or EXCLUDE constraints on an existing table; those require
an explicit schema migration.

=head4 Compiled regex filters

Red exports the optional compiler. On the RakuAST frontend, invoke it at CHECK:

=begin code :lang<raku>
use Red:api<2>;
CHECK red-compile;

my @users = User.^all.grep({ .name ~~ /^ 'Ana'/ });
my @codes = User.^all.grep({ .code ~~ /:i ^ <[a..z]>+ \d ** 2 $/ });
=end code

Recent Rakudo versions may use RakuAST by default. Set C<RAKUDO_RAKUAST=1> only
when selecting it is necessary; the frontend alone does not enable C<red-compile>.

Regex literals in C<grep> and C<first> are compiled to SQL, including single
C<.match(/.../)> predicates and regex callables on scalar projections. PostgreSQL uses its
ARE engine and MySQL 8 uses C<REGEXP_LIKE>. SQLite rejects regex by default;
opt in with C<database "SQLite", :use-experimental-regex>. Its experimental
implementation uses string operations for
literal-only patterns or a recursive SQL state machine for general patterns,
without an extension or Raku callback. Pattern data are bound as
parameters. Primitive numeric inputs use SQL text formatting; Boolean inputs
retain Raku's C<True>/C<False> spelling. Direct nullable columns and unsupported
composite/custom stringifiers are rejected.

The supported core includes literals, string/line/word anchors, groups,
alternatives, positive and negative character classes, static Unicode
properties, static C<E<lt>at(n)E<gt>> positions, Boolean Match markers,
greedy/frugal quantifiers, open/finite repetition bounds, separators,
C<:s> significant whitespace and lookarounds. Nonrecursive lexical regex rules
without parameters, traits or phasers can be expanded from their syntax tree.
C<token> and C<rule> declarations are also expanded when their operations are
supported by the chosen engine. MySQL supports ratcheted quantifiers through
atomic matching; PostgreSQL and SQLite reject operations requiring that lowering.
Regular conjunctions C<&> and C<&&> use a product automaton, preserving the common
matched span. Native conjunction lowering has a 128-state/64KiB pattern limit.
Case modifiers work at the root on all three engines; scoped case modifiers
also work on MySQL and SQLite. PostgreSQL bounds above 255 are lowered into
smaller native blocks, subject to pattern expansion and capture limits.
SQLite limits each compiled state machine to 4096 states.

Positional capture references are supported by PostgreSQL and MySQL within
engine limits. MySQL keeps capture references exact under C<:i>; PostgreSQL
rejects references in that case mode. MySQL supports references within a lookahead's own capture scope;
PostgreSQL and SQLite reject those references. Local scalar references survive
repeated group/rule scopes; repeated capture-list references are rejected;
Raku capture lists cannot be replaced by a single native backreference. SQLite
rejects regex backreferences. PostgreSQL supports guarded scalar capture text
comparisons with C<$0>, literal named captures and C<$/> after a direct regex
condition, including predicate C<if>/C<unless> modifiers. Quote spaces that must
match input. Missing captures produce SQL NULL; capture arrays and Match object
methods remain unsupported. MySQL 8.0.17+ also supports whole-match C<$/> text
using C<REGEXP_SUBSTR>, with exact case and trailing-space comparison. Whole-match C<$/.defined> and C<$/.Bool> work on all
matching backends. PostgreSQL also supports scalar capture presence via
C<.defined>, C<.Bool> and Boolean C<:exists>, preserving empty versus absent groups.
No Raku Match object is returned or populated.

Matching uses database character/collation semantics, so normalization,
grapheme boundaries and case folding can differ from Raku. Static Unicode
properties use the compiling Rakudo's Unicode data. Literal scalar/array
interpolation is bound once as escaped data; it does not evaluate regex source.
Interpolation inside inlined named rules is rejected until their closure frames
can be retained safely. SQLite's built-in case
folding and shorthand classes are ASCII-oriented. SQL NULL semantics apply to
expressions producing NULL; text containing NUL is outside the supported domain.

Unsupported regex syntax and unavailable driver features throw a fatal
C<X::Red::Compiler::Unsupported> diagnostic, even if C<$*RED-FALLBACK> is enabled.
Code blocks, executable regex interpolation, recursive grammars and unsupported
capture behavior are never silently replaced with in-memory filtering. Ordinary Raku
collections retain their normal regex behavior. See C<docs/regex-support.md>
for the driver matrix and remaining work.

=head4 PostgreSQL ranges, regex and exclusion constraints

C<sql-operator> builds an AST for PostgreSQL range and regex operators such as
C<< @> >>, C<< <@ >>, C<&&> and C<~*>. Values are bound in queries and quoted as
literals in schema DDL. C<sql-range> builds a native range constructor, defaulting
to C<numrange> with C<[)> bounds. Its C<:type> can also select C<int4range>,
C<int8range>, C<tsrange>, C<tstzrange> or C<daterange>.

=begin code :lang<raku>
model TrackSegment {
    has UInt $.id is serial;
    has Int $.track-id is column;
    has Str $.percent-range is column{ :type<numrange> };

    has $!range-valid is check(
        { sql-operator('@>', sql-range(0, 1, :bounds<[]>), .percent-range) },
        :driver<Pg>
    );
    has $!no-overlap is exclude(
        { .track-id => '=', .percent-range => '&&' },
        :using<gist>, :driver<Pg>
    );
}

my @segments = TrackSegment.^all.grep({
    sql-operator('&&', .percent-range, sql-range(0.2, 0.4))
});
=end code

The exclusion constraint rejects overlapping ranges on the same track. Native
range columns and operators require PostgreSQL. Bounds containment permits empty
ranges; reject them with a separate constraint if the domain requires it.
Applications must provision needed extensions explicitly: C<pg_trgm> supplies
C<gin_trgm_ops>, and C<btree_gist> supplies GiST classes for scalar keys such as
the integer track identifier. Red does not install extensions automatically.

=head4 custom table name

=begin code :lang<raku>

model MyModel is table<custom_table_name> {}

=end code

=head4 not nullable columns by default

Red, by default, has not nullable columns, to change it:

=begin code :lang<raku>
#| This makes this model’s columns nullable by default
model MyModel is nullable {
    has Int $.col1 is column;               #= this column is nullable
    has Int $.col2 is column{ :!nullable }; #= this one is not nullable
}
=end code

=head4 load object from database

=begin code :lang<raku>
MyModel.^load: 42;
MyModel.^load: id => 42;
=end code

=head4 save object on the database

=begin code :lang<raku>
$object.^save;
=end code

=head4 search for a list of object

=begin code :lang<raku>
Question.^all.grep: { .answer == 42 }; # returns a result seq
=end code

=head4 transactions and savepoints

C<red-do :transaction> commits when its block succeeds and rolls back when it fails.
Nested transactional blocks on the same connection use savepoints. They can see
uncommitted outer changes, and their successful changes remain subject to an outer
rollback. Catch an inner exception to roll back only that inner block and continue
the outer transaction; an exception that propagates out rolls back the outer block too.

=begin code :lang<raku>
red-do :transaction, {
    Person.^create: :name<Alice>;
    try {
        red-do :transaction, {
            Person.^create: :name<Bob>;
            # A failure here rolls back Bob, leaving Alice in the outer transaction.
        }
    }
};
=end code

Drivers provide C<savepoint($name)>, C<rollback-to-savepoint($name)> and
C<release-savepoint($name)> on the current connection. Rolling back to a savepoint
leaves that savepoint active; releasing it does not commit the surrounding transaction.
Savepoints do not coordinate concurrent tasks. Await asynchronous database work before
leaving an automatic transactional block, and avoid overlapping access to its connection.

=head5 Explicit transaction guards

Declare a named C<:$guard> parameter to take explicit control of a transaction.
The block receives a C<Red::Transaction::Guard>; a positional parameter, if declared,
still receives the transaction's driver. A slurpy named parameter alone does not
enable manual control. Blocks that declare neither C<:$guard> nor the named
placeholder C<$:guard> retain automatic commit and rollback.
Automatic scopes retain Raku's C<KEEP>/C<UNDO> behavior: a nonlocal C<return> or
C<fail> unwinds the scope and rolls it back.

=begin code :lang<raku>
my $work = red-do :transaction, -> :$guard! {
    $guard.start: -> :&commit {
        Person.^create: :name<Alice>;
        commit();
    }
};
await $work;
=end code

You can also use Raku's named placeholder C<$:guard> instead of writing
C<-> :$guard!>. Using it inside a block implicitly declares the required named
parameter, so C<red-do> recognizes it as a manual transaction. Both direct commit
and asynchronous work are supported:

=begin code :lang<raku>
red-do :transaction, {
    Person.^create: :name<Alice>;
    $:guard.commit;
};

my $work = red-do :transaction, {
    $:guard.start: -> :&commit {
        Person.^create: :name<Bob>;
        commit();
    }
};
await $work;
=end code

Each guard starts with one participant, which C<red-do> releases automatically
when its block exits, including with C<:async>. The last release rolls back an
unfinished scope. Do not release that initial participant yourself.

C<.do(&block)> reserves a participant, runs the block immediately and releases
when it finishes, returning its result. C<.start(&block)> reserves before scheduling
and returns a Promise; completion releases the participant. Failed scheduling returns
the reservation. Both restore the guard's transaction context and inject
C<:&commit> and C<:&rollback> only when explicitly declared in the block's
signature. An escaping exception immediately rolls back and propagates (breaking the
Promise for C<.start>). A Promise returned by C<.do> does not extend its
participation; use C<.start> for asynchronous work. Returning a pending Promise
from C<.do> emits C<X::Red::Transaction::AsyncResult>, a resumable warning
that suggests C<.start> without awaiting or replacing the result. Already completed
Promises do not warn. To silence an intentional pending result, handle this type in
C<CONTROL> and call C<.resume>.

For explicit lifetime control, C<retain()> adds a participant and C<release()>
removes one. Both return the guard. Each additional participant must be released exactly
once. To use a guard after its C<red-do> block returns, retain it or schedule work
with C<.start> before exiting. For manually scheduled work, reserve before
scheduling, release in its C<LEAVE>, and return the reservation if scheduling fails.

C<commit()> confirms immediately, without waiting for participants. Explicit
C<rollback()> and exceptions escaping the block also close an open scope immediately.
Pending participants must still release after closure; these releases execute no SQL.
Retaining a closed guard, releasing with no remaining participants, or committing a
closed guard raises C<X::Red::Transaction>. Explicit rollback remains idempotent.
An exception after commit cannot undo it. Garbage collection provides no cleanup guarantee.

A nested guard controls a savepoint with its own participant count. Its last release
rolls back only that savepoint. Its parent cannot run queries, open another child,
or commit until that child closes. Parent rollback also invalidates all descendants.
Drivers, statements, iterators and lazy queries belonging to a closed scope reject
further database access. Ordinary driver use outside the scope is unaffected; direct
access to a native database handle bypasses these guards.

Guards keep the reserved session usable by asynchronous work that inherits the block's
context. Participant bookkeeping is synchronized, but does not permit simultaneous
database operations: overlapping database access is rejected with
C<X::Red::Transaction>. No returned Promise is required to retain a manual transaction.
With C<:async>, an automatic transaction's Promise resolves after commit; a manual
transaction's Promise represents only execution of its block, not guard completion.

=head4 phasers

=item C<before-create>
=item C<after-create>
=item C<before-update>
=item C<after-update>
=item C<before-delete>
=item C<after-delete>

=head4 Temporary table

=begin code :lang<raku>
model Bla is temp { ... }
=end code

=head4 is handling

The C<is handling> trait "exports" C<ResultSeq> methods to the model itself, so
they can be called directly on the model's type object. Each positional value
is the name of a C<ResultSeq> method to expose; passing a pair renames it:

=begin code :lang<raku>
model Bla is handling<map grep> { has Int $.a is column }

Bla.map(*.a);              # same as Bla.^all.map(*.a)
Bla.grep(*.a < 5);         # same as Bla.^all.grep(*.a < 5)

model Ble is handling(map => "update", grep => "where") { has Int $.a is column }

Ble.update(*.a);           # same as Ble.^all.map(*.a), renamed
Ble.where(*.a < 5);        # same as Ble.^all.grep(*.a < 5), renamed
=end code

=head4 refresh

The C<.^refresh> meta-method reloads a model instance's columns with the actual
data from the database. It accepts a list of column (attribute) names, or
nothing at all to refresh every column:

=begin code :lang<raku>
my $post = Post.^load: 42;
# ... some external process updates the row ...
$post.^refresh;                # refreshes all columns
$post.^refresh: "title";       # refreshes only the "title" column
$post.^refresh: <title body>;  # refreshes "title" and "body"
=end code

Refreshed columns are also marked clean on the model's dirty tracking.

=head4 Create table

=begin code :lang<raku>
Question.^create-table;
Question.^create-table: :if-not-exists;
Question.^create-table: :unless-exists;
=end code

=head4 IN

=begin code :lang<raku>
Question.^all.grep: *.answer ⊂ (3.14, 13, 42)
=end code

=head4 create

=begin code :lang<raku>

Post.^create: :body("bla ble bli blo blu"), :title("qwer");


model Tree {
    has UInt   $!id        is id;
    has Str    $.value     is column;
    has UInt   $!parent-id is referencing{ Tree.id };

    has Tree   $.parent    is relationship{ .parent-id };
    has Tree   @.kids      is relationship{ .parent-id };
}

Tree.^create-table: :if-not-exists;

Tree.^create:
    :value<Bla>,
    :parent{:value<Ble>},
    :kids[
        {:value<Bli>},
        {:value<Blo>},
        {:value<Blu>}
    ]
;

=end code

=head2 AUTHOR

Fernando Correa de Oliveira <fernandocorrea@gmail.com>

=head2 COPYRIGHT AND LICENSE

Copyright 2018 Fernando Correa de Oliveira

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

=end pod
