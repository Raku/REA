use Red::Column;
use nqp;

class X::Red is Exception {}

#| Internal signal for a template that cannot bind to the current projection.
class X::Red::Compiler::Unsupported is Exception {
    has Bool $.fatal = False;
    has Str $.reason = "Unsupported compiled query";
    method message { $!reason }
}

class X::Red::Transaction is X::Red {
    has Str $.reason = 'Invalid transaction operation';
    method message { $!reason }
}

# A resumable warning, rather than a transaction failure caught by CATCH.
class X::Red::Transaction::AsyncResult is CX::Warn {
    method message {
        'Guard.do returned a pending Promise; its participation ends when the block returns. '
            ~ 'Use Guard.start to keep the transaction alive for asynchronous work.'
    }

    method warn {
        my $exception := nqp::newexception();
        nqp::setmessage($exception, self.message);
        nqp::setextype($exception, nqp::const::CONTROL_WARN);
        nqp::setpayload($exception, self);
        nqp::throw($exception);
    }
}

class X::Red::Transaction::Cleanup is X::Red::Transaction {
    has Exception $.cause is required;
    has Exception $.cleanup is required;
    method message { "{ $!cause.message }; rollback also failed: { $!cleanup.message }" }
}

class X::Red::Index is X::Red {
    has Str $.reason is required;
    method message { "Invalid index: $!reason" }
}

class X::Red::Projection is X::Red {
    has Str $.reason is required;
    method message { $!reason }
}

class X::Red::Json is X::Red {
    has Str $.operation is required;
    has Exception $.cause is required;

    method message { "Cannot $!operation JSON: { $!cause.message }" }
}

class X::Red::NoOperatorsDefined is X::Red {
    has Str $.meth is required where <first grep map>.any;
    method message {
        qq:to/END/
        Red operators not defined while calling $!meth. It's probably not doing what you mean.
        Please use Red (or Red::Operators) before using $!meth on a Red::ResultSet.
        If that's what you want, please set \$*RED-DONT-FAIL-WITHOUT-OPERATORS to True.
        END
    }
}

class X::Red::RedDbNotDefined is X::Red {
    method message { Q[$*RED-DB wasn't defined] }
}

#| A project configuration could not supply valid Red runtime settings or a default connection.
class X::Red::Configuration is X::Red {
    has Str $.reason is required;
    method message { $!reason }
}

class X::Red::Defaults::FromConfNotFound is X::Red {
    has Str $.file = "./.red.json";
    method message { "Red configuration file ($!file) not found" }
}

class X::Red::Do is X::Red {
    has Str $.driver = "default"
}

class X::Red::Do::DriverNotDefined is X::Red::Do {
    method message { "Driver $.driver not specified" }
}

class X::Red::Do::DriverDefinedMoreThanOnce is X::Red::Do {
    method message { "Driver $.driver defined mor than once" }
}

class X::Red::Driver is X::Red {
    has Str $.driver = $*RED-DB.^name;
}

class X::Red::Driver::Pg::NotInstalled is X::Red::Driver {
    has Exception $.cause is required;

    method message {
        qq:to/END/
        PostgreSQL support is provided by the separate Red::Driver::Pg distribution.
        Red could not load Red::Driver::Pg while evaluating database "Pg".
        Since the Pg driver was removed from the core Red distribution, upgrading
        Red does not install or update PostgreSQL support automatically.

        To fix this, install the driver with:

            zef install Red::Driver::Pg

        Then restart your Raku program and run database "Pg" again. Existing
        database "Pg" calls do not need to change after the driver is installed.
        If the driver is already installed, check its dependencies and the original
        loading error below.

        Original loading error:
        {$!cause.message}
        END
    }
}

class X::Red::RelationshipNotColumn is X::Red {
    has Attribute   $.relationship;
    has             $.points-to;

    method message {
        "The relationship '$!relationship.name()' points to a {$!points-to.^name} ($!points-to.Str()). Should point to a column that is refering to another column."
    }
}

class X::Red::RelationshipCreate is X::Red {
    has Str $.reason is required;
    method message { "Cannot create through relationship: $!reason" }
}

class X::Red::RelationshipNotRelated is X::Red {
    has Attribute   $.relationship;
    has Red::Column $.points-to;

    method message {
        "The relationship '$!relationship.name()' points to a column ('$!points-to.attr-name()') that does not refer to any where"
    }
}

class X::Red::InvalidTableName is X::Red::Driver {
    has Str $.table;

    method message { "'$!table' is an invalid table name for driver { $.driver }" }
}

class X::Red::UpdateNoId is X::Red::Driver {
    method message { "Update on a model without id isn't allowed" }
}

class X::Red::Driver::Mapped is X::Red::Driver {
    has Exception   $.orig-exception is required;
    has Str         $!orig-message   = $!orig-exception.message;
    has Backtrace   $!orig-backtrace = $!orig-exception.backtrace;

    method msg { !!! }

    method message {
        "{self.msg}\nOriginal error:\n{$!orig-message}"
    }

    method throw is hidden-from-backtrace {
        nextwith $!orig-backtrace
    }
}

class X::Red::Driver::Mapped::UnknownError is X::Red::Driver::Mapped {
    has Str @.fields;
    method msg {
        qq:to/END/
            Unknown Error!!!
            Please, copy this backtrace and open an issue on https://github.com/FCO/Red/issues/new
            Driver: { $.driver }
            Original error: { $.orig-exception.raku }
        END
    }
}

class X::Red::Driver::Mapped::Unique is X::Red::Driver::Mapped {
    has Str @.fields;
    method msg { "Unique constraint ({@!fields.join: ", "}) violated" }
}

class X::Red::Driver::Mapped::TableExists is X::Red::Driver::Mapped {
    has Str $.table is required;
    method msg { "Table $!table already exists" }
}
