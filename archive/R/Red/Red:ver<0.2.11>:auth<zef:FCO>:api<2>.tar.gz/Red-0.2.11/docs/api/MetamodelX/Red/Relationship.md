MetamodelX::Red::Relationship
-----------------------------

### method add-relationship

```raku
method add-relationship(
    Mu:U $self,
    Attribute $attr,
    &reference,
    Mu:U :$model-type!,
    Bool :$optional,
    Bool :$prefetch = Code.new,
    Bool :$no-prefetch = Code.new,
    Bool :$has-one
) returns Mu
```

Adds a new relationship by reference.

### method add-relationship

```raku
method add-relationship(
    Mu:U $self,
    Attribute $attr,
    Str :$column!,
    Str :$model!,
    Str :$require = Code.new,
    Bool :$optional,
    Bool :$prefetch = Code.new,
    Bool :$no-prefetch = Code.new,
    Bool :$has-one
) returns Mu
```

Adds a new relationship by column.

### method add-relationship

```raku
method add-relationship(
    Mu:U $self,
    Attribute $attr,
    &reference,
    Str :$model,
    Str :$require = Code.new,
    Bool :$optional,
    Bool :$prefetch = Code.new,
    Bool :$no-prefetch = Code.new,
    Bool :$has-one
) returns Mu
```

Adds a new relationship by reference.

### method add-relationship

```raku
method add-relationship(
    Mu:U $self,
    Attribute $attr,
    &ref1,
    &ref2,
    Str :$model,
    Str :$require = Code.new,
    Bool :$optional,
    Bool :$prefetch = Code.new,
    Bool :$no-prefetch = Code.new,
    Bool :$has-one
) returns Mu
```

Adds a new relationship by two references.

### method add-relationship

```raku
method add-relationship(
    ::Type Mu:U $self,
    Red::Attr::Relationship $attr
) returns Mu
```

Adds a new relationship using an attribute of type `Red::Attr::Relationship`.

