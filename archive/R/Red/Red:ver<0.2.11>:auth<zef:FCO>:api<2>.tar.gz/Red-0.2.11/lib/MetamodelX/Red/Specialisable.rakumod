use Red::AST::MultiSelect;
use Red::Column;
use Red::Attr::Column;
use Red::HiddenFromSQLCommenting;
use Red::AST::Reference;

unit role MetamodelX::Red::Specialisable;

multi method specialise($self, +@ret where .all ~~ Red::AST) is hidden-from-sql-commenting {
    # Generated models compose shared roles; keep their metamodel construction atomic.
    self.protect-model-composition({ self!specialise($self, |@ret) })
}

method !specialise($self, *@ret) is hidden-from-sql-commenting {
    my \Meta  = $self.^orig.HOW.WHAT;
    my \model = Meta.new(:table($self.^table)).new_type: :name($self.^name);
    model.HOW.^attributes.first(*.name eq '$!table').set_value: model.HOW, $self.^table;
    model.HOW.?defer-resultseq(model);
    my $attr-name = 'data_0';
    my @attrs = do for @ret {
        @*table-list.push: |.tables if @*table-list.defined;
        my $multi-select = !$self.HOW.?is-projection-storage
            && $self.^all.filter ~~ Red::AST::MultiSelect;
        my $name = $multi-select ?? .attr.name.substr(2) !! ++$attr-name;
        my $col-name = $_ ~~ Red::Column ?? .name !! $name;
        my $attr  = Attribute.new:
            :name("\$!$name"),
            :package(model),
            :type(.returns ~~ Any && .returns !~~ Nil ?? .returns !! Any),
            :has_accessor,
            :build(.returns),
        ;
        my %data = %(
            :name-alias($col-name),
            :name($col-name),
            :attr-name($name),
            :type(.returns.^name),
            :$attr,
            :model($_ ~~ Red::Column ?? .model !! .tables.head),
            :class(model),
            |(do if $_ ~~ Red::Column | Red::AST::Reference {
                :inflate(.inflate),
                :deflate(.deflate),
                |(:computation($_) if $_ ~~ Red::AST::Reference),
            } else {
                :computation($_)
            })
        );
        $attr does Red::Attr::Column(%data);
        model.^add_attribute: $attr;
        model.^add_multi_method: $name, my method (Mu:D:) { $attr.get_value(self) }
        $attr
    }
    model.^add_method: "no-table", my method no-table { True }
    model.^add_method: "orig-result-seq", my method orig-result-seq { $self.^all }
    model.^compose;
    model.^add-column: $_ for @attrs;
    model
}
