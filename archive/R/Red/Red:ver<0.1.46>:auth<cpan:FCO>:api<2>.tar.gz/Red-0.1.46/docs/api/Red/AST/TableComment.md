class Red::AST::TableComment
----------------------------

Represents a table comment

