class Red::Driver::SQLite::SchemaReader
---------------------------------------

An internal class to read SQLite schemes.

