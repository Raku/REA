class Red::AST::CreateView
--------------------------

Represents a create table

