

Base role to infix operators

