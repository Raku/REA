class Red::AST::CreateTable
---------------------------

Represents a create table

