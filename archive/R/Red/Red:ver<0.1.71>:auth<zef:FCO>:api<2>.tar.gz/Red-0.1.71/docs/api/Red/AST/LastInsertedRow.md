class Red::AST::LastInsertedRow
-------------------------------

Represents the last inserted row

