class Red::AST::Update
----------------------

Represents an update operation

