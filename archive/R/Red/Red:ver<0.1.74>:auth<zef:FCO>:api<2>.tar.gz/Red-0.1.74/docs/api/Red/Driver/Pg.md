class submethod BUILD (Red::Driver::Pg: :$!dbh, Str :$!user, Str :$!password, Str :$!host = "127.0.0.1", Int :$!port = 5432, Str :$!dbname, *%_) { #`(Submethod|140278952491296) ... }
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Data accepted by the Pg driver constructor: dbh : DB::Pg object user : User to be used to connect to the database password: Password to be used to connect to the database host : To be connected to port : What port to connect dbname : Database name

