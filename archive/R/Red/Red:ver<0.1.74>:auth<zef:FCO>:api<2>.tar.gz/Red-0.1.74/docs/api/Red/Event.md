class Red::Event
----------------

Represents a event

### has Mu $.db

Database driver

### has Str $.db-name

Database driver's name

### has Str $.driver-name

Database driver type name

