use Red <shortname formatter>;
