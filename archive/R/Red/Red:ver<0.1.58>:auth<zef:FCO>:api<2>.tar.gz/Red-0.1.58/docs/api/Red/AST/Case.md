class Red::AST::Case
--------------------

Represents a case statement

