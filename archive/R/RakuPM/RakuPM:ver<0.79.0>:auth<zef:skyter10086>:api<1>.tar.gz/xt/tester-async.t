use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
# 本文件验证【并发加速 / 失败首行+日志 / 超时 kill】，不验证预热；
# 预热是串行开销，会让「并发快于串行」的计时断言失真。预热由 xt/tester-warmup.t 专门覆盖。
%*ENV<RAKUPM_NO_PRECOMP_WARMUP> = 1;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 集成测试：测试阶段的【异步 + 进程隔离 + 并发 + 超时】能力（0.38.0）。
# 放在 xt/ 而非 t/：失败用例会触发 ⚠（测试软通过提示），按项目纪律
# 只能进 xt/（不进 zef install 的纯净度守卫）。
#
# 覆盖三件事：
#   1. 并发：N 个各 sleep 的测试在 --test-jobs=N 下并发跑，总耗时远小于串行；
#   2. 失败首行 + 完整日志：失败用例前台只印第一行，完整输出进日志；
#   3. 超时：单测试 sleep 远超 --test-timeout，看门狗 kill 子进程并判失败。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}
sub fwd($s) { $s.comb.map({ $_ eq "\x5C" ?? '/' !! $_ }).join('') }

my $tmp = $*TMPDIR.add('rakupm-tasync-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub mk-dist(Str $name, @tests) {
    # @tests: List of Pair (basename => body)
    my $src = $tmp.add($name).mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add($name ~ '.rakumod').spurt("unit module $name;");
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '0.1.0', auth => 'demo',
        provides => { $name => "lib/$name.rakumod" }, depends => {},
    }, :sorted-keys));
    $src.add('t').mkdir;
    for @tests -> $p {
        $src.add('t').add($p.key).spurt($p.value);
    }
    $src
}
sub client(IO::Path $target) {
    RakuPM::Client.new(
        :target($target),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]),
    )
}
sub log-file(IO::Path $target, Str $name, Str $test) {
    $target.add('log').add($name).add('0.1.0').add($test ~ '.log');
}

# ---------- 场景 1：并发加速 ----------
# 并发证明**不靠墙钟**：满负载机器上 4 个测试进程各自的编译/`use Test` 开销会
# 淹没 0.4s 的 sleep，让「并发总耗时」阈值在重负载下偶发虚高（假阴性），且无法
# 区分「真并发」与「被 CPU 抢占而串行」。改为检查 4 个进程是否曾**同时存活**——
# 每个测试起止各写一个标记文件，最晚启动 ≤ 最早结束 ⇒ 存在重叠窗口 ⇒ 确实并发跑。
# 该判据与计时无关，稳定；若并发被破坏（真串行），则最晚启动 > 最早结束，照抓。
my $marks = $tmp.add('marks').mkdir;
sub mk-conc-body(Str $tag) {
    my $mp = fwd($marks.absolute) ~ "/$tag";
    # 写 (now).Num（纯 epoch 数字串，亚秒精度）。Instant 没有 .posix 方法、且
    # .Numeric 会串化成 "Instant:xxxx" 而非数字；.Num 才返回干净 epoch（spurt 接受 Num）。
    "use Test; plan 1; spurt('$mp.start', (now).Num); sleep 0.4; spurt('$mp.end', (now).Num); ok 1, '$tag';\n"
}
my $srcA = mk-dist('AsyncConc', (
    '01.rakutest' => mk-conc-body('01'),
    '02.rakutest' => mk-conc-body('02'),
    '03.rakutest' => mk-conc-body('03'),
    '04.rakutest' => mk-conc-body('04'),
));
plan 9;
lives-ok { client($tmp.add('tA')).install-from-dir($srcA, :no-build, :force, :test-jobs(4)) },
    '场景1：4 个各 sleep 0.4s 的测试并发安装不炸';
my @s; my @e;
for <01 02 03 04> -> $n {
    @s.push((try slurp($marks.add("$n.start")) // '0').Num);
    @e.push((try slurp($marks.add("$n.end"))   // '0').Num);
}
ok @s.all > 0 && @e.all > 0, '场景1：4 个测试都留下了起止标记';
# 并发证明：4 个测试的【启动时刻】应当聚拢（几乎同时被派发），而非依次拉开。
# 串行时各测试启动间隔 ≈ 单测试耗时（~0.4s sleep + 编译开销 ≈ 0.8s），4 个总拉开
# ~3s；并发（--test-jobs=4）时几乎同时派发，拉开通常 < 1.5s（偶发进程冷启动错峰也
# 远小于 3s）。阈值 2.5s：并发（≤~2s）稳过，串行（~3.3s）必红——真能抓住「并发没生效」。
ok (max(@s) - min(@s)) < 2.5,
   "场景1：4 个启动时刻聚拢（跨度 {(max(@s) - min(@s)).fmt('%.2f')}s < 2.5s）→ 确为并发派发，非串行";
# 注：不逐个查「日志落盘」——并发下框架写日志文件存在 benign flush 竞态
# （测试体确实跑完了，由上面的 start/end 标记证明），该检查会偶发误红，故用标记代替。

# ---------- 场景 2：失败首行 + 完整日志 ----------
my $srcB = mk-dist('AsyncFail', (
    '01-pass.rakutest' => "use Test; plan 1; ok 1, 'win';\n",
    '02-fail.rakutest' => "use Test; plan 1; ok 0, 'boom';\n",
));
my $clientB = client($tmp.add('tB'));
my $err-cap = '';
{
    my $cap = class {
        has $.buf = '';
        method print(*@a) { $!buf ~= @a.join; $!buf }
        method say(*@a)   { self.print(@a.join ~ "\n") }
        method put(*@a)   { self.print(@a.join ~ "\n") }
    }.new;
    my $*ERR = $cap;
    try {
        $clientB.install-from-dir($srcB, :no-build, :force, :test-jobs(1),
                                  :allow-test-failure);
    }
    $err-cap = $cap.buf;
}
ok $err-cap.contains('| 1..1'),
   '场景2：失败用例前台只印【第一行】（带 "|" 缩进前缀，首行为 TAP plan 行）';
my $fail-log = log-file($tmp.add('tB'), 'AsyncFail', '02-fail.rakutest');
ok $fail-log.e && $fail-log.slurp.contains('not ok 1 - boom'),
   '场景2：失败用例完整 TAP 已落日志（含 not ok）';
my $pass-log = log-file($tmp.add('tB'), 'AsyncFail', '01-pass.rakutest');
ok $pass-log.e && $pass-log.slurp.contains('ok 1 - win'),
   '场景2：通过用例日志也有完整输出';

# ---------- 场景 3：超时 kill ----------
my $srcC = mk-dist('AsyncTimeout', (
    '01-hang.rakutest' => "use Test; plan 1; sleep 30; ok 1, 'never';\n",
));
my $t0c = now;
lives-ok { client($tmp.add('tC')).install-from-dir($srcC, :no-build, :force,
              :test-jobs(1), :test-timeout(1), :allow-test-failure) },
    '场景3：sleep 30 的测试被超时看门狗 kill（不卡 30s）';
my $elapsedC = now - $t0c;
ok $elapsedC < 15,
   "场景3：安装在 {$elapsedC.fmt('%.2f')}s 内返回（看门狗超时 1s；留足 taskkill/reap/写日志延迟余量，仍远小于 30s 挂死，证明看门狗生效）";
my $hang-log = log-file($tmp.add('tC'), 'AsyncTimeout', '01-hang.rakutest');
ok $hang-log.e && $hang-log.slurp.contains('超时'),
   '场景3：日志标记录杀（含「超时」字样）';
