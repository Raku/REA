use Test;
use RakuPM::HTTP;
use RakuPM::HTTP::Backend;
use RakuPM::Repository::Ecosystem;

# 验证 RakuPM::HTTP 插件门面：后端顺序 / 重试 / 代理透传 / download / 全失败抛错，
# 以及 Ecosystem 的索引 TTL（重校验）与「拉取失败回退旧缓存」韧性。
# 全程用假后端，不触网。

# ---------- 假后端：类级记录调用、可按需失败 N 次后成功、透传 proxy/max-time ----------
# 注册的是【类型】，门面会 new 一个带 proxy 的实例；调用记到类级 @!CALLS 便于断言。
class FakeBackend does RakuPM::HTTP::Backend {
    has Str      $.proxy    = '';
    has Numeric  $.max-time = 120;
    my @CALLS;
    my Int $FAIL = 0;
    method get-text(Str $url, *%o --> Str) {
        @CALLS.push: { url => $url, proxy => $!proxy, kind => 'text' };
        if $FAIL > 0 { $FAIL--; die "fake get-text fail" }
        return 'OK';
    }
    method download(Str $url, IO::Path $dest, *%o --> Nil) {
        @CALLS.push: { url => $url, proxy => $!proxy, kind => 'download' };
        if $FAIL > 0 { $FAIL--; die "fake download fail" }
        $dest.spurt('OK');
    }
    method reset(--> Nil)     { @CALLS = (); $FAIL = 0; }
    method calls(--> List)    { @CALLS.List }
    method fail-times(Int $n --> Nil) { $FAIL = $n; }
}

# 1) 默认注册表含 tinyish(走 curl) + httptiny，且 tinyish 排在前面（curl 优先，
#    httptiny 兜底）。curl 由成熟依赖 HTTP::Tinyish 自己子进程，不是旧的自管子进程。
ok (RakuPM::HTTP.backend-names ⊇ ('tinyish', 'httptiny')),
   '默认后端已注册 tinyish + httptiny';
is RakuPM::HTTP.new.order.join(','), 'tinyish,httptiny',
   '默认顺序 tinyish 优先、httptiny 兜底';

# 2) 注册自定义后端并选中，get-text 返回文本
RakuPM::HTTP.register-backend('fake1', FakeBackend);
FakeBackend.reset;
my $h = RakuPM::HTTP.new(:order('fake1'), :attempts(3), :base-delay(0.001));
is $h.get-text('http://x'), 'OK', 'get-text 返回后端文本';

# 3) 重试：首次失败，重试成功
RakuPM::HTTP.register-backend('fake2', FakeBackend);
FakeBackend.reset; FakeBackend.fail-times(1);
my $h2 = RakuPM::HTTP.new(:order('fake2'), :attempts(3), :base-delay(0.001));
is $h2.get-text('http://x'), 'OK', '首次失败后重试成功';
is FakeBackend.calls.elems, 2, '重试实际发生了两次调用';

# 4) 全部失败 → get-text 抛错，且尝试次数 = attempts
RakuPM::HTTP.register-backend('fake3', FakeBackend);
FakeBackend.reset; FakeBackend.fail-times(99);
my $h3 = RakuPM::HTTP.new(:order('fake3'), :attempts(2), :base-delay(0.001));
dies-ok { $h3.get-text('http://x') }, '全部失败抛错';
is FakeBackend.calls.elems, 2, '尝试次数 = attempts';

# 5) 代理透传
RakuPM::HTTP.register-backend('fake4', FakeBackend);
FakeBackend.reset;
my $h4 = RakuPM::HTTP.new(:order('fake4'), :proxy('http://proxy:8080'), :base-delay(0.001));
$h4.get-text('http://x');
is FakeBackend.calls[0]<proxy>, 'http://proxy:8080', 'proxy 透传给后端';

# 6) download 调用后端并写文件
RakuPM::HTTP.register-backend('fake5', FakeBackend);
FakeBackend.reset;
my $h5 = RakuPM::HTTP.new(:order('fake5'), :base-delay(0.001));
my $tmp = ($*TMPDIR // '/tmp').add('rakupm-http-test-' ~ $*PID ~ '.bin');
$h5.download('http://x', $tmp);
ok $tmp.e && $tmp.slurp eq 'OK', 'download 写文件';
$tmp.unlink if $tmp.e;

# 7) 自定义的假 HTTP 门面（鸭型）直接注入 Ecosystem，验证 TTL
sub fake-http(--> Mu) {
    my class FakeHTTP {
        has @.gets;
        has Bool $.boom is rw = False;
        has Str  $.text is rw = '[]';
        method get-text($url) {
            @!gets.push($url);
            die "boom" if $!boom;
            return $!text;
        }
        method download($url, $dest) { $dest.spurt('x') }
    }
    FakeHTTP.new;
}

# 7a) 新鲜缓存被直接复用，不重新拉取
{
    my $dir = ($*TMPDIR // '/tmp').add('rakupm-ttl-' ~ $*PID ~ '-a');
    $dir.mkdir;
    LEAVE { $dir.dir.map: { .unlink if .f; .rmdir if .d }; try $dir.rmdir }
    my $fh = fake-http;
    my $eco = RakuPM::Repository::Ecosystem.new(
        :name('zef'), :index-url('http://example.test/zef'),
        :cache-root($dir), :http($fh));
    $eco.refresh;                       # 首次：拉取，写入缓存
    is $fh.gets.elems, 1, '首次 refresh 拉取了索引';

    my $eco2 = RakuPM::Repository::Ecosystem.new(
        :name('zef'), :index-url('http://example.test/zef'),
        :cache-root($dir), :http($fh));
    $eco2.refresh;                      # 缓存新鲜 → 复用，不再拉取
    is $fh.gets.elems, 1, '缓存新鲜时 refresh 复用、不重新拉取';
}

# 7b) 缓存过期（TTL 内 fetched_at 过旧）→ 重新拉取
{
    temp %*ENV<RAKUPM_INDEX_TTL> = '86400';   # 1 天
    my $dir = ($*TMPDIR // '/tmp').add('rakupm-ttl-' ~ $*PID ~ '-b');
    $dir.mkdir;
    LEAVE { $dir.dir.map: { .unlink if .f; .rmdir if .d }; try $dir.rmdir }
    my $fh = fake-http;
    my $eco = RakuPM::Repository::Ecosystem.new(
        :name('zef'), :index-url('http://example.test/zef'),
        :cache-root($dir), :http($fh));
    $eco.refresh;                       # 写入缓存
    # 把 fetched_at 回退 2 天 → 已过期
    my $cache = $dir.dir.first(*.f);
    use JSON::Fast;
    $cache.spurt: to-json({ _rakupm_t => now.Int - 2*86400, rows => [{stale => 'yes'}] });
    my $eco2 = RakuPM::Repository::Ecosystem.new(
        :name('zef'), :index-url('http://example.test/zef'),
        :cache-root($dir), :http($fh));
    $eco2.refresh;                      # 过期 → 重新拉取
    is $fh.gets.elems, 2, '缓存过期时 refresh 重新拉取';
}

# 7c) 拉取失败但本地有旧缓存 → 韧性兜底，不抛错
{
    temp %*ENV<RAKUPM_INDEX_TTL> = '86400';
    my $dir = ($*TMPDIR // '/tmp').add('rakupm-ttl-' ~ $*PID ~ '-c');
    $dir.mkdir;
    LEAVE { $dir.dir.map: { .unlink if .f; .rmdir if .d }; try $dir.rmdir }
    my $fh = fake-http;                 # 不 boom
    my $eco = RakuPM::Repository::Ecosystem.new(
        :name('zef'), :index-url('http://example.test/zef'),
        :cache-root($dir), :http($fh));
    $eco.refresh;                       # 写入缓存
    use JSON::Fast;
    my $cache = $dir.dir.first(*.f);
    # 旧缓存里塞 1 行（哪怕 fetch 失败也至少有 1 行兜底）
    $cache.spurt: to-json({ _rakupm_t => now.Int - 2*86400, rows => [{stale => 'yes'}] });
    $fh = fake-http; $fh.boom = True;   # 这次拉取会失败
    my $eco2 = RakuPM::Repository::Ecosystem.new(
        :name('zef'), :index-url('http://example.test/zef'),
        :cache-root($dir), :http($fh));
    lives-ok { $eco2.refresh }, '拉取失败但有旧缓存时不抛错（韧性兜底）';
}

# 7d) 拉取失败且【无任何缓存】→ 不再抛错，按空索引处理并标记降级（0.49.5）
#
# 用户现场（国内网络）：raw.githubusercontent.com 上的 cpan/rea 索引不可达、且从未
# 缓存过 → 以前这里直接 die，于是**「答案本来就在本地仓库里」的命令也整条失败**
# （`xt/fetch.t` 就是这样红的：它解析的 Lib::A 就在本地仓库，却因为 REA 拉不到而崩）。
# 这与 Ecosystem 里写下的原则「单点网络抖动不应升级成安装失败」直接矛盾 —— 那条原则
# 原先只在「有旧缓存」时兑现（7c 那条），现在补全。
{
    temp %*ENV<RAKUPM_INDEX_TTL> = '86400';
    my $dir = ($*TMPDIR // '/tmp').add('rakupm-ttl-' ~ $*PID ~ '-d');
    $dir.mkdir;
    LEAVE { $dir.dir.map: { .unlink if .f; .rmdir if .d }; try $dir.rmdir }
    my $fh = fake-http; $fh.boom = True;     # 一上来就失败，且 cache-root 里没有任何缓存
    # 刻意用 rmtree 之外的手段确认目录是空的：这条测试的前提就是「无缓存」
    is $dir.dir.elems, 0, '前提：cache-root 里确实没有任何索引缓存';

    my $eco = RakuPM::Repository::Ecosystem.new(
        :name('rea'), :index-url('http://example.test/rea'),
        :cache-root($dir), :http($fh));
    lives-ok { $eco.refresh }, '拉取失败且无缓存时不再抛错（不升级成命令失败）';
    ok $eco.degraded, '标记为降级 —— 上层据此能如实告知「结果可能不完整」';
    is $eco.find-providers('Anything').elems, 0, '按空索引处理：查不到提供者，但也不炸';
}

done-testing;
