use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 测试阶段「实时进度」（避免长静默被误认为卡死）的集成回归。
#
# 行为契约：
#   · RAKUPM_TEST_PROGRESS=1 → 跑测试期间在 stderr 上刷「预热 i/N」「测试 i/N pct%」进度行；
#   · RAKUPM_TEST_PROGRESS=0 → 完全静默（进度一行都不出）；
#   · 二者都【不影响 stdout】：成功汇总仍是 `✓ <basename>`，安装照常成功。
#
# 为什么必须起【子进程】：进度直接写 $*ERR（进程内 $*ERR 是 IO::Handle，无法用假对象
# 替换），所以只能把子进程的 stderr 重定向到文件再读回来断言。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-progress-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $libf = $*PROGRAM.parent.parent.add('lib').absolute.Str.subst('\\', '/', :g);
my $tmpf = $tmp.absolute.Str.subst('\\', '/', :g);

# 造一个带 3 个测试文件的本地发行版
my $d = $tmp.add('repo').add('Demo').mkdir;
$d.add('lib').mkdir;
$d.add('lib').add('Demo.rakumod').spurt("unit module Demo;\n");
$d.add('t').mkdir;
for 1..3 -> $i {
    $d.add('t').add("{$i}-step.rakutest").spurt("use Test;\npass 'step $i';\ndone-testing;\n");
}
$d.add('META6.json').spurt(to-json({
    name => 'Demo', version => '1.0', auth => 'demo:test',
    provides => { 'Demo' => 'lib/Demo.rakumod' }, depends => {},
}, :sorted-keys));

# 子进程驱动脚本：装 Demo（每次用不同的 target，确保真的会跑测试，而不是命中「已装跳过」）
my $script = $tmp.add('runner.raku');
$script.spurt(q:to/RUNNER/);
use lib 'LIBPATH';
use RakuPM::Client;
use RakuPM::Repository::Local;
my $tmp = 'TMPPATH'.IO;
my $suffix = (@*ARGS[0] // 'x');
my $client = RakuPM::Client.new(
    :target($tmp.add('target-' ~ $suffix)),
    :repos([RakuPM::Repository::Local.new(:root($tmp.add('repo')))]),
);
$client.install('Demo');
RUNNER
my $src = $script.slurp;
$src = $src.subst("'LIBPATH'", "'{$libf}'").subst("'TMPPATH'", "'{$tmpf}'");
$script.spurt($src);

# 跑一次子进程，返回 (exitcode, stderr, stdout)
sub run-child(Str $progress-mode, Str $suffix --> List) {
    my %env = %*ENV;
    if $progress-mode eq 'unset' { %env<RAKUPM_TEST_PROGRESS>:delete }
    else                         { %env<RAKUPM_TEST_PROGRESS> = $progress-mode }
    my $out-f = $tmp.add("out-{$suffix}.txt");
    my $err-f = $tmp.add("err-{$suffix}.txt");
    my $of = $out-f.IO.open(:w);
    my $ef = $err-f.IO.open(:w);
    my $p = run($*EXECUTABLE.Str, $script.Str, $suffix, :out($of), :err($ef),
                :cwd($tmp.Str), :env(%env));
    $of.close; $ef.close;
    ($p.exitcode, $err-f.slurp, $out-f.slurp)
}

my ($code-on, $err-on, $out-on) = run-child('1', 'on');
is $code-on, 0, 'PROGRESS=1：安装成功（退出码 0）';
ok $err-on.contains('预热 1/3'), 'PROGRESS=1：预热阶段有进度行（计数）；stderr 实为：'
    ~ ($err-on.contains('预热') ?? '有' !! '无');
ok $err-on.contains('测试 1/3'), 'PROGRESS=1：跑测试阶段有进度行';
ok $err-on.contains('100%'),    'PROGRESS=1：进度行含百分比，且能走到 100%';
ok $out-on.contains('✓ 1-step.rakutest'), 'PROGRESS=1：stdout 汇总仍是 ✓（进度不影响 stdout）';

my ($code-off, $err-off, $out-off) = run-child('0', 'off');
is $code-off, 0, 'PROGRESS=0：安装成功（退出码 0）';
nok $err-off.contains('测试 1/3'), 'PROGRESS=0：进度完全静默（stderr 无进度行）';
nok $err-off.contains('预热 1/3'), 'PROGRESS=0：预热进度也静默';
ok $out-off.contains('✓ 1-step.rakutest'), 'PROGRESS=0：不影响 stdout 的 ✓ 汇总';

done-testing;
