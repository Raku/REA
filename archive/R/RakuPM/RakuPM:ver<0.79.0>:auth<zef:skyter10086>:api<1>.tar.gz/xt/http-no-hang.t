use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 回归 /  invariants：raku-pm 的网络层必须【永不挂死】。
# 历史根因：旧 curl 后端在「失败路径」泄漏 run() 的 out 管道句柄，导致后续 run()
# 永久挂起（第 1 次失败被 SIGTERM，第 2 次起毫无输出）。现已彻底删除 curl 后端、
# 改用纯 Raku 的 HTTP::Tiny（无外部进程、无管道句柄），从根上消除该类 bug。
# 本测试仍常驻，作为「整体网络层不挂死」的硬守卫。
#
# 用本地「拒绝连接」端口（127.0.0.1:1，任何环境都立即 RST）模拟请求失败：
# HTTP::Tiny 会快速返错（status=5xx），子进程自行退出。主进程用 Proc::Async 看门狗
# 带硬超时——即使将来网络层又出现挂死，看门狗也会杀掉子进程，不会拖垮整个套件。
# 断言点：两次连续请求都必须在硬超时内【自行退出】（返回 'done'），
# 而不是被看门狗杀死（'killed' = 挂死，回归）。

sub call-with-watchdog(Str $url, Numeric :$cap = 60 --> Str) {
    # 返回 'done'（子进程自行退出）或 'killed'（超时看门狗杀掉 = 挂死）
    my $killed = False;
    my $proc = Proc::Async.new('raku', '-I', 'lib', '-e',
        "use RakuPM::HTTP; "
      ~ "my \$h = RakuPM::HTTP.new(:max-time(5)); "
      ~ "try \$h.get-text('$url'); exit 0");
    my $promise = $proc.start;
    # 看门狗：到 cap 秒还没跑完就 kill【子进程】（Promise 没有 .cancel，也无需取消：
    # 子进程一旦自己退出，这里就不会触发，或触发时 try 接住「已不在」的报错）。
    # 注意：kill 必须作用在 $proc 上，绝不能误伤本测试进程，否则看门狗自己先把
    # 测试进程杀掉，就测不到「是否挂死」了。
    my $watch = Promise.in($cap).then({ $killed = True; try $proc.kill });
    try await $promise;   # 看门狗 kill 子进程时 await 会抛；接住即可，靠 $killed 判定
    $killed ?? 'killed' !! 'done'
}

my $url = 'http://127.0.0.1:1/rakupm-no-hang-probe';   # 本地拒绝连接端口，立即失败

my $r1 = call-with-watchdog($url, :cap(60));
is $r1, 'done', '不可达地址第 1 次请求快速失败返回（未挂死）';

my $r2 = call-with-watchdog($url, :cap(60));
is $r2, 'done', '不可达地址第 2 次请求也快速失败返回（修复前此处挂死）';

done-testing;
