use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 集成测试：防御性预热（0.41.2）。
# 预热在并发测试前串行编译每个测试文件（-c），写热共享模块 / 依赖的 precomp 缓存，
# 消除并发首跑时多个进程同时首次编译同一份 lib/*.rakumod 的竞态（表现为偶发的
# "===SORRY!=== Error while compiling" 却被串行复验误当用例本身 flaky）。
# 本测试验证：
#   1. 默认开启时，含共享模块的 2 个测试文件在 test-jobs=2 下并发安装并全过；
#   2. 设 RAKUPM_NO_PRECOMP_WARMUP=1 关闭预热时，同样能装过（opt-out 可用）。
# 两场景用不同模块名，确保场景 2 是真正「冷」的并发编译（不被场景 1 的预热缓存影响）。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}
my $tmp = $*TMPDIR.add('rakupm-warm-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub mk-dist(Str $name, @tests) {
    my $src = $tmp.add($name).mkdir;
    my $lib = $src.add('lib'); $lib.mkdir;
    $lib.add($name ~ '.rakumod').spurt("unit module $name; sub shared-value() is export \{ 42 \};");
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '0.1.0', auth => 'demo',
        provides => { $name => "lib/$name.rakumod" }, depends => {},
    }, :sorted-keys));
    $src.add('t').mkdir;
    for @tests -> $p { $src.add('t').add($p.key).spurt($p.value) }
    $src
}
sub client(IO::Path $target) {
    RakuPM::Client.new(:target($target),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]));
}
sub log-file(IO::Path $target, Str $name, Str $test) {
    $target.add('log').add($name).add('0.1.0').add($test ~ '.log');
}
sub t-body(Str $mod) {
    "use Test; use $mod; plan 1; is shared-value(), 42, 'shared module loaded';\n"
}

# ---------- 场景 1：默认预热开启，test-jobs=2 并发安装 ----------
my $srcA = mk-dist('WarmModA', (
    'a.rakutest' => t-body('WarmModA'),
    'b.rakutest' => t-body('WarmModA'),
));
plan 6;
lives-ok {
    client($tmp.add('t1')).install-from-dir($srcA, :no-build, :force, :test-jobs(2))
}, '场景1：预热开启时 2 共享模块测试并发安装不炸';
for <a b> -> $n {
    my $lf = log-file($tmp.add('t1'), 'WarmModA', "$n.rakutest");
    ok $lf.e && $lf.slurp.contains('ok 1'), "场景1：日志 $n.rakutest 通过";
}

# ---------- 场景 2：关闭预热（opt-out），真正冷编译并发安装 ----------
%*ENV<RAKUPM_NO_PRECOMP_WARMUP> = 1;
my $srcB = mk-dist('WarmModB', (
    'a.rakutest' => t-body('WarmModB'),
    'b.rakutest' => t-body('WarmModB'),
));
lives-ok {
    client($tmp.add('t2')).install-from-dir($srcB, :no-build, :force, :test-jobs(2))
}, '场景2：关闭预热后 2 共享模块测试冷并发安装仍 OK（opt-out 可用）';
for <a b> -> $n {
    my $lf = log-file($tmp.add('t2'), 'WarmModB', "$n.rakutest");
    ok $lf.e && $lf.slurp.contains('ok 1'), "场景2：日志 $n.rakutest 通过";
}
