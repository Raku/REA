#!/usr/bin/env raku
# ==============================================================================
# tools/run-suite.raku — raku-pm 本地全量回归 + 文档纪律校验
#
# 【为什么需要它】
#   · 项目此前没有「一条命令跑完」的入口，全靠临时手写 for 循环；而 CI（Gitee Go）
#     需要自有主机、实际长期没跑，等于没有门禁。
#   · prove6 不能用：它把「Subtest N doesn't have a plan」这类无害解析告警当失败
#     （exit=1）→ 常年假红。只有逐个 `raku <file>` 的真实退出码才是成败信号。
#   · 文档纪律（META6 版本 ↔ 两份 README 的版本示例 ↔ Changes 条目；provides 清单
#     与 lib/ 下实际文件是否互为全集）此前无人校验，已漂移过多次。
#
# 本脚本是**唯一**的判定口径：本地跑它、CI 跑它，是同一条代码路径。
#
# 【用法】
#   raku tools/run-suite.raku                  # t/ + xt/ + 静态检查 + 文档纪律 + 个人痕迹
#   raku tools/run-suite.raku --no-xt          # 跳过 xt/（网络/重测试）
#   raku tools/run-suite.raku --only=t         # 只跑 t/
#   raku tools/run-suite.raku --docs-only      # 只做静态检查 + 文档纪律 + 个人痕迹（秒级）
#   raku tools/run-suite.raku --precommit      # 预提交门禁：上者 + 编译暂存文件
#   raku tools/run-suite.raku --filter=native  # 只跑文件名含 native 的
#   raku tools/run-suite.raku --jobs=4         # 并行度（默认 1 = 串行，见下）
#
# 退出码：0 全过 / 1 有失败 / 2 参数错。
#
# 【为什么现在默认并行】此前为躲「并发首编译 lib 触发预编译竞态」而默认串行，但那
# 等于把多核机当单核用（24 核只跑 1 个）。如今默认按 CPU 核数并行（上限 8），并加两
# 道安全网：① 跑前先把 lib 预热编译（-c）把 precomp 写热；② 跑完对失败用例【串行复验】
# 一次，竞态/时序敏感假失败被剔除。要纯串行就 --jobs=1。RAKUPM_NO_PRECOMP_WARMUP 跳预热。
# ==============================================================================

use v6.d;
use JSON::Fast;

use lib $*PROGRAM.parent.Str;
use NamedArgCheck;                       # 具名实参静态检查（本目录下的开发工具）

my IO::Path $root = $*PROGRAM.parent.parent.absolute.IO;
my $raku = $*EXECUTABLE.Str;

# 测试一律以【工作树】的 lib/ 为准。用绝对路径而不是 `-Ilib`：后者依赖 cwd，一旦 cwd
# 不是仓库根，链上就没有 lib/，测试会静默改用系统里**已安装**的 RakuPM —— 那正是
# 0.49.2 在用户 Linux 机上暴露的事故（详见 tests-see-worktree 的注释）。
my $lib-abs = $root.add('lib').absolute.Str;

my Bool $do-t    = True;
my Bool $do-xt   = True;
my Bool $do-docs = True;
my Bool $do-static = True;               # 具名实参静态检查（秒级，预提交也跑）
my Str  $filter  = '';
my Int  $jobs    = do { my $n = try ($*KERNEL.cpu-cores // 4) // 4; min($n, 8) }; # 默认按 CPU 核数并行，上限 8

# ---------------------------------- 参数 --------------------------------------
my @argv = @*ARGS;
while @argv.elems {
    my $a = @argv.shift;
    if $a eq '--help' || $a eq '-h' || $a eq 'help' {
        print usage-text();
        exit 0;
    }
    elsif $a eq '--only=t'      { $do-xt = False; $do-docs = False; $do-static = False }
    elsif $a eq '--only=xt'     { $do-t  = False; $do-docs = False; $do-static = False }
    elsif $a eq '--no-t'        { $do-t  = False }
    elsif $a eq '--no-xt'       { $do-xt = False }
    elsif $a eq '--docs-only'   { $do-t  = False; $do-xt = False }
    elsif $a eq '--no-docs'     { $do-docs = False }
    elsif $a eq '--no-static'   { $do-static = False }
    elsif $a eq '--precommit'   { $do-t = False; $do-xt = False; $do-docs = True }
    elsif $a ~~ /^ '--filter=' (.+) $/ { $filter  = ~$0 }
    elsif $a ~~ /^ '--jobs='   (\d+) $/ { $jobs    = +$0 }
    else {
        note "未知选项：$a";
        note "  用 `raku tools/run-suite.raku --help` 看用法（不接受拼错的旗标）";
        exit 2;
    }
}
$jobs max= 1;

# --------------------------------- 小工具 -------------------------------------
sub usage-text(--> Str) {
    q:to/USAGE/;
    raku tools/run-suite.raku — raku-pm 本地全量回归 + 静态检查 + 文档纪律 + 个人痕迹检查

      （无参数）        t/ + xt/ + 具名实参检查 + 文档纪律 + 个人痕迹
      --no-xt           跳过 xt/（网络 / 重 / 故意失败的集成测试）
      --no-t            跳过 t/
      --only=t          只跑 t/
      --only=xt         只跑 xt/
      --docs-only       只做静态检查 + 文档纪律 + 个人痕迹（秒级，适合预提交）
      --precommit       静态检查 + 文档纪律 + 个人痕迹 + 编译暂存的 .rakumod/bin 文件（快，适合 git hook）
      --no-docs         不做文档纪律校验（个人痕迹检查也随之跳过）
      --no-static       不做具名实参检查（tools/check-named-args.raku）
      --filter=SUBSTR   只跑文件名含 SUBSTR 的用例
      --jobs=N          t/ 并发度（默认按 CPU 核数、上限 8；设 1 则完全串行）
      -h, --help        本帮助

    退出码：0 全过 / 1 有失败 / 2 参数错。
    USAGE
}

# 急切收集（Windows 上惰性迭代会持住目录句柄），按 basename 稳定排序。
# 刻意**不**依赖 lib/RakuPM/Fs —— 门禁脚本必须在源码坏掉时仍能跑起来。
sub walk-files(IO::Path $d --> List) {
    return () unless $d.d;
    my @out;
    my @entries = $d.dir;               # 急切收集
    for @entries.sort({ .basename }) -> $e {
        $e.d ?? @out.append(walk-files($e)) !! @out.push($e);
    }
    @out.List
}

sub norm(Str $p --> Str) { $p.subst('\\', '/', :g) }

sub rel-str(IO::Path $f --> Str) { norm($f.relative($root).Str) }

# 测试子进程的**统一**启动参数。
#
# 必须收敛成一个函数：自检（tests-see-worktree）与真正跑测试（run-one）要共用它，
# 否则自检只是「自说自话」—— 比如有人把 run-one 里的 -I 删了，自检仍然绿。
# 共用之后，任何一处动了 -I，自检立刻变红。
sub test-args(Str $target, *@extra --> List) {
    ($raku, '-I' ~ $lib-abs, $target, |@extra)
}

sub test-files(Str $dir, Str $filter --> List) {
    my $d = $root.add($dir);
    return () unless $d.d;
    my @files = $d.dir.grep({
        .f && (.extension.lc eq 't' || .extension.lc eq 'rakutest')
    }).sort({ .basename });
    @files = @files.grep({ .basename.contains($filter) }) if $filter.chars;
    @files.List
}

# ------------------- 自检：测试必须看到【工作树】的 lib/ -------------------
#
# 【为什么必须有这一条】0.49.2 的用户现场：本脚本以前是
#   run($raku, $rel, :out, :err, :cwd($root));      # ← 没有 -Ilib
# 于是**任何没有写 `use lib` 的测试文件都在测系统里已安装的 RakuPM，而不是工作树**。
# Linux 上一口气红了 5 个文件（author-check / store-lock / store-provides-ext /
# repos / http），而开发机 Windows 上全过 —— 只因那台机器已装的那份 RakuPM 恰好
# 自洽。这是一类「门禁看着绿、其实测的不是这份代码」的假绿，比没有门禁更危险。
#
# 现在测试一律带 `-I<绝对路径>/lib`，并且**跑之前先用同一个启动方式证明它生效**：
# 链首必须是本仓库的 lib/。判据用 `$*REPO.repo-chain.head`（实测 head 就是 `-I`
# 那个 FileSystem 仓库），不去解析具体模块 —— 便宜，且不依赖任何模块能否加载。
# 已实测对照：带 -Ilib 时链首是本仓库 lib/；不带时链首直接是用户的 RAKULIB 目录，
# 本仓库 lib/ 根本不在链上。
sub tests-see-worktree(--> Bool) {
    my $probe = q{my $h = $*REPO.repo-chain.head; say $h.defined ?? $h.Str !! ''};
    my $p = run(|test-args('-e', $probe), :out, :err, :cwd($root));
    my $out = $p.out.slurp(:close).trim;
    $p.err.slurp(:close);
    return False unless $p.exitcode == 0;
    # 折大小写：Windows 上同一条路径的大小写形式可能不同；Linux 上两侧同时折也不出错。
    norm($out).lc eq norm($lib-abs).lc
}

# ------------------------------- 跑一个测试文件 -------------------------------
sub run-one(IO::Path $f, Bool $strict --> Hash) {
    my $rel = rel-str($f);
    my $p = run(|test-args($rel), :out, :err, :cwd($root));
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    my $code = $p.exitcode;
    my $all = $out ~ $err;
    my @noise = $strict
        ?? $all.lines.grep({ $_.contains('⚠') || $_.contains('[RakuPM]') }).List
        !! ().List;
    %(
        rel   => $rel,
        code  => $code,
        noise => @noise,
        ok    => ($code == 0 && !@noise.elems),
        tail  => $all.lines.tail(25).join("\n"),
    )
}

sub report(%r, Bool $strict --> Nil) {
    if %r<ok> {
        say "  ok    {%r<rel>}";
        return;
    }
    say "  FAIL  {%r<rel>}";
    say "        （退出码 {%r<code>}）" if %r<code> != 0;
    if %r<noise>.elems {
        say "        （喷了生产级警告 ⚠ / [RakuPM]，会搞乱 zef install 日志）：";
        for %r<noise>.head(5) -> $n { say "          {$n.trim}" }
    }
    if %r<tail>.trim.chars {
        say "        --- 输出尾部 ---";
        for %r<tail>.lines -> $l { say "        {$l}" }
    }
}

# 预热：把 lib/ 下每个 .rakumod 各编译一遍（-c，不执行），把 precomp 缓存写热。
# 以 $jobs 并发编译，避免后续测试进程并发首跑同一份模块触发 rakudo 预编译竞态
# （表现为偶发的 ===SORRY!=== Error while compiling 假失败）。RAKUPM_NO_PRECOMP_WARMUP
# 可跳过（回归/调试用）。
sub warmup-precomp(Int $jobs --> Nil) {
    my @mods = walk-files($root.add('lib'))
        .grep({ .extension.lc eq 'rakumod' })
        .sort({ .basename });
    return unless @mods.elems;
    say "  （预热 lib 预编译缓存：{@mods.elems} 个模块，并发 {$jobs}）";
    my @queue = @mods.list;
    while @queue.elems {
        my @batch = @queue.splice(0, $jobs);
        await @batch.map(-> $m {
            start {
                my $p = run($raku, '-I' ~ $lib-abs, '-c', $m.Str, :out, :err, :cwd($root));
                $p.out.slurp(:close); $p.err.slurp(:close);
            }
        });
    }
}

sub run-suite(Str $dir, Str $label, Bool $strict --> List) {
    my @files = test-files($dir, $filter);
    say "";
    say "===== {$label} ({$dir}/, {@files.elems} 个用例) =====";
    if !@files.elems {
        say "  （没有匹配的用例{$filter.chars ?? "（filter=$filter）" !! ''}）";
        return ().List;
    }

    # 并发（jobs>1）前先预热共享 lib 的 precomp 缓存：避免多个 raku 子进程同时
    # 首次编译同一份 lib/*.rakumod 触发预编译竞态假失败。单进程串行（jobs==1）
    # 无此风险，跳过预热。RAKUPM_NO_PRECOMP_WARMUP 可强制跳过。
    if $jobs > 1 && !(%*ENV<RAKUPM_NO_PRECOMP_WARMUP> // '').chars {
        warmup-precomp($jobs);
    }

    # 统一用「分批 + 每批并发 $jobs 个」跑：jobs==1 时退化为纯串行，jobs>1 时
    # 每批同时起 $jobs 个 raku 子进程（注意：这里 $jobs 就是并发度，不再是批数）。
    my @failed;
    my @queue = @files.list;
    while @queue.elems {
        my @batch = @queue.splice(0, $jobs);
        my @rs = await @batch.map(-> $f { start { run-one($f, $strict) } });
        for @rs -> %r { report(%r, $strict); @failed.push(%r<rel>) unless %r<ok> }
    }

    # 并发模式下的假失败兜底：把失败的用例【串行复验】一次。并行竞态 / 时序敏感的
    # 偶发失败会在串行复验中通过，从而不污染最终结果（与 Tester 同款机制）。
    if $jobs > 1 && @failed.elems {
        my @still;
        for @failed -> $rel {
            my %r = run-one($root.add($rel), $strict);
            if %r<ok> {
                say "    ↻ 串行复验通过（疑似并发假失败，已从失败清单剔除）：{$rel}";
            }
            else {
                @still.push($rel);
            }
        }
        @failed = @still;
    }
    @failed.List
}

# ------------------------------ 文档纪律校验 ----------------------------------
sub check-docs(--> List) {
    my @fails;

    my $meta-path = $root.add('META6.json');
    if !$meta-path.f {
        return ("META6.json 不存在",).List;
    }

    my $meta;
    try { $meta = from-json($meta-path.slurp) }
    if !$meta.defined {
        return ("META6.json 无法解析 —— 发布前必须先修好它",).List;
    }
    unless $meta ~~ Associative {
        return ("META6.json 顶层必须是对象（Associative），实为 {$meta.WHAT.raku}",).List;
    }

    my $version = ($meta<version> // '').Str;
    @fails.push("META6.json 缺 version 字段") unless $version.chars;

    # 1) 版本号示例一致性（RakuPM:ver<x.y.z>）
    #    基准文件 README.md / README.en.md：**必须**含版本示例，且全部等于 META6 版本。
    #    文档目录 docs/*.md（递归）：若含版本示例则必须与 META6 一致（**不强制必须有**）——
    #    版本示例迁到 docs/ 后，该校验范围必须同步扩展，否则每次提交必红（见 Issue 1 修正）。
    my @doc-files = ('README.md', 'README.en.md');
    my %strict = 'README.md' => True, 'README.en.md' => True;
    if $root.add('docs').d {
        for walk-files($root.add('docs')).grep({ .extension.lc eq 'md' }) -> $p {
            @doc-files.push(norm($p.relative($root).Str));
        }
    }
    for @doc-files -> $rn {
        my $f = $root.add($rn);
        if !$f.f {
            @fails.push("{$rn} 不存在");
            next;
        }
        my @found;
        for $f.lines -> $line {
            # 注意 <[ ... ]> 里的范围必须写 `..`（`0-9` 会被 Rakudo 拒为
            # 「Unsupported use of - as character range」）—— 见 Author.rakumod 同款写法。
            my @ms = $line.match(/ 'RakuPM:ver<' (<[0..9.]>+) '>' /, :g) // ();
            for @ms -> $m { @found.push(~$m[0]) }
        }
        my $strict = %strict{$rn} // False;
        if !@found.elems {
            @fails.push("{$rn} 里找不到 `RakuPM:ver<x.y.z>` 版本示例（约定：必须与 META6 同步）")
                if $strict;
            next;
        }
        for @found.unique -> $v {
            @fails.push("{$rn} 的版本示例 RakuPM:ver<{$v}> 与 META6 的 {$version} 不一致")
                if $v ne $version;
        }
    }

    # 2) Changes 顶部条目 = META6 版本
    my $ch = $root.add('Changes');
    if !$ch.f {
        @fails.push("Changes 不存在（约定：每次改动必须补条目）");
    }
    else {
        my $first = $ch.lines.first({ $_ ~~ /^ '## ' / });
        if !$first.defined {
            @fails.push("Changes 里找不到 `## X.Y.Z` 形式的版本标题");
        }
        else {
            my $m = $first.match(/ '## ' (<[0..9.]>+) /);
            my $cv = $m.defined ?? ~$m[0] !! '';
            @fails.push("Changes 最新条目 {$cv} 与 META6 的 {$version} 不一致")
                if $cv.chars && $cv ne $version;
        }
    }

    # 3) provides ↔ lib/ 下实际 .rakumod 互为全集
    my %provides = %($meta<provides> // {});
    my @declared = %provides.values.map({ norm($_.Str) }).sort.unique;
    my @actual = walk-files($root.add('lib'))
        .grep({ .extension.lc eq 'rakumod' })
        .map({ rel-str($_) }).sort;
    for @actual -> $f {
        @fails.push("lib 下的 {$f} 未在 META6 provides 里声明（装了也 use 不到）")
            unless $f (elem) @declared;
    }
    for @declared -> $f {
        @fails.push("META6 provides 声明的 {$f} 不存在") unless $root.add($f).f;
    }

    # 4) bin 清单里的文件必须存在
    my @bins = ($meta<bin> // []).List;
    for @bins -> $b {
        my $p = norm($b.Str);
        @fails.push("META6 bin 声明的 {$p} 不存在") unless $root.add($p).f;
    }

    # 5) 依赖清单里不能有空项（空字符串会让解析器拿到无意义约束）
    my %depends = %($meta<depends> // {});
    my %runtime = %(%depends<runtime> // {});
    my @req = (%runtime<requires> // []).List;
    for @req -> $r {
        @fails.push("META6 depends.runtime.requires 里有空项")
            unless $r.defined && $r.Str.trim.chars;
    }

    @fails.List
}

# ---------------------------- 暂存文件的编译门禁 ------------------------------
sub staged-source-files(--> List) {
    my $p = run('git', 'diff', '--cached', '--name-only', '--diff-filter=ACM',
                :out, :err, :cwd($root));
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    return ().List unless $p.exitcode == 0;
    $out.lines.map(*.trim).grep({
        .chars && !.starts-with('#') &&
        (.ends-with('.rakumod') || .ends-with('.raku') || .ends-with('.pm6') ||
         .ends-with('.rakutest') || .ends-with('.t'))
    }).grep({ $root.add($_).f }).List
}

sub check-staged-compile(--> List) {
    my @fails;
    my @files = staged-source-files();
    return @fails.List unless @files.elems;
    say "";
    say "===== 编译暂存文件（{@files.elems} 个） =====";
    for @files -> $f {
        my $p = run($raku, '-Ilib', '-c', $f, :out, :err, :cwd($root));
        my $out = $p.out.slurp(:close);
        my $err = $p.err.slurp(:close);
        if $p.exitcode == 0 {
            say "  ok    {$f}";
        }
        else {
            say "  FAIL  {$f}";
            for (($out ~ $err).lines.tail(15)) -> $l { say "        {$l}" }
            @fails.push("{$f} 编译失败");
        }
    }
    @fails.List
}

# ------------------------------ 个人痕迹检查 ----------------------------------
#
# 【为什么需要它 · 血的教训】这类泄漏会以「换个写法再写一遍」的形式复发：
#   · 0.74.1 清掉了历史文档里的个人用户名；
#   · 0.75.0 的 Changes 在说明「我清理了那个用户名」时，又把该用户名原样写了进去
#     —— 语义上是在报告修复，效果上等于换个地方把它发到公开生态；
#   · 0.75.1 的条目描述「本机用户名 → 中性占位」时，又把本机用户名写了回来。
# 靠人「发版前记得 grep 一下」不可靠，故钉进门禁 —— 它在 --docs-only / --precommit /
# 全量门禁三种口径下都会跑。
#
# 【本函数里的黑名单不能写字面量】要禁的字符串若在此出现字面量，本文件自己就成了
# 泄漏源（tools/ 同样会进 sdist）。故一律用 `'a' ~ 'b'` 拼接构造。
#
# 扫描范围 = **会进发布包的内容**：跳过 dot 目录（打包层已确认 .git/.precomp/
# .workbuddy 等不进 sdist）与 blib，并跳过 `.distignore` 里列出的条目 —— 否则
# 内部文档（CODEBUDDY.md 之类）里的路径会把门禁误报成红。
sub walk-shipped(IO::Path $d --> List) {
    return () unless $d.d;
    my @out;
    for $d.dir.sort({ .basename }) -> $e {
        if $e.d {
            next if $e.basename.starts-with('.') || $e.basename eq 'blib';
            @out.append(walk-shipped($e));
        }
        else {
            @out.push($e);
        }
    }
    @out.List
}

sub dist-ignored-entries(--> List) {
    my $f = $root.add('.distignore');
    return () unless $f.f;
    my @out;
    for $f.lines -> $line {
        my Str $s = $line.trim;
        next unless $s.chars;
        next if $s.starts-with('#');
        # 行尾注释：`#` 前须有空白（与 .gitignore 同款语义；Author.!dist-ignores 同规则）
        $s = $s.subst(/ \s+ '#' .* $ /, '').trim;
        next unless $s.chars;
        @out.push($s.subst('\\', '/', :g).subst(/^ '.\/' /, '').subst(/\/+$/, ''));
    }
    @out.List
}

sub check-personal-traces(--> List) {
    my @fails;
    my $workspace = 'Work' ~ 'Buddy';   # ① 本机工作区根目录名
    my $legacy    = 'z' ~ 'by';         # ② 历史遗留的短用户名
    # ③ 中性占位白名单：这些「名字」是技术示例，允许出现在路径里
    my @neutral = <user User USER username foo bar baz x X tester test me
                   example sample alice bob someone name public nobody>;

    my @ignores = dist-ignored-entries();
    my @ext-ok = <md rakumod raku t json yml yaml txt pm ps1 bat sh
                  gitignore gitattributes distignore>;
    my @scan = walk-shipped($root).grep(-> IO::Path $f {
        my Str $rel = rel-str($f);
        my Bool $ignored = so @ignores.first({ $rel eq $_ || $rel.starts-with("{$_}/") });
        !$ignored && ($f.extension (elem) @ext-ok || $f.basename eq 'Changes')
    }).List;

    my @hit-path; my @hit-legacy; my @hit-user;
    for @scan -> $f {
        my Str $text = (try { $f.slurp } // '');
        next unless $text.chars;
        my Str $rel = rel-str($f);
        for $text.lines.kv -> $i, $line {
            my Int $n = $i + 1;
            @hit-path.push("{$rel}:{$n}") if $line.contains($workspace);
            @hit-legacy.push("{$rel}:{$n}") if $line.contains($legacy);
            for ($line.match(/ 'Users' <[\\\/]>+ (\w+) /, :g) // ()) -> $m {
                my Str $who = ~$m[0];
                @hit-user.push("{$rel}:{$n}（Users\\{$who}）") unless $who (elem) @neutral;
            }
        }
    }

    # 注意必须显式 `.List`：`Seq` 不是 Positional，`append` 不会展平它，会把它当
    # 【单个元素】塞进去（元素 stringify 成内容拼接，空 Seq 就是空串）—— 症状是
    # 「明明命中 3 处、打印出来却是 3 行空白」。踩过一次，别再省这个 `.List`。
    my @all;
    @all.append(@hit-path.map({ "① 本机工作区绝对路径痕迹：{$_}" }).List);
    @all.append(@hit-legacy.map({ "② 历史遗留用户名痕迹：{$_}" }).List);
    @all.append(@hit-user.map({ "③ 非中性占位的 Windows 用户名：{$_}" }).List);
    return @all.List if @all.elems <= 15;
    @all.head(15).List.push("…另有 {@all.elems - 15} 处（全部：grep -rn 手工确认）");
}

# ---------------------------------- 主流程 ------------------------------------
my @failed;

# 自证「测试看到的是工作树」——否则后面所有绿灯都不可信，直接中止（不假绿）。
if $do-t || $do-xt {
    unless tests-see-worktree() {
        say "";
        say "===== 门禁自检失败（中止） =====";
        say "  测试看不到工作树的 lib/：仓库链首不是 {$lib-abs}。";
        say "  再跑下去只会得到「测了系统里那份已安装的 RakuPM」的假绿，故不继续。";
        say "  排查：`raku -I{$lib-abs} -e 'say \$*REPO.repo-chain.head.Str'`";
        exit 1;
    }
}

if $do-t {
    @failed.append(run-suite('t', "单测（zef install 测试阶段跑的就是这一批，强制安静）", True));
}

if $do-xt {
    @failed.append(run-suite('xt', "集成测试（重 / 网络 / 故意失败；只判成败不判噪音）", False));
}
elsif $do-t {
    say "";
    say "===== 跳过 xt/ =====";
}

if $do-static {
    say "";
    say "===== 具名实参检查（method 会【静默忽略】未知具名实参，编译器不报） =====";
    my @nf = check-named-args($root);
    if !@nf.elems {
        say "  ok    没有「名字不在任何形参/属性里」的调用点";
    }
    else {
        say "  FAIL 发现 {@nf.elems} 处：";
        for @nf.head(15) -> $x {
            say "        {$x<file>}:{$x<line>}  :{$x<name>}   {$x<snippet>}";
        }
        say "        …另有 {@nf.elems - 15} 处（raku tools/check-named-args.raku --verbose 看全部）"
            if @nf.elems > 15;
        @failed.append("具名实参检查（{@nf.elems} 处。逐个核对被调方签名；"
                     ~ "确属项目外 API 的，加进 tools/NamedArgCheck.rakumod 的 %ALLOWED 并写明理由）");
    }
}

if $do-docs {
    say "";
    say "===== 文档纪律校验（版本号一致性 / provides 完整性 / bin / Changes） =====";
    my @df = check-docs();
    if !@df.elems {
        say "  ok    版本号三处一致、provides 与 lib/ 互为全集、bin 与依赖清单正常";
    }
    else {
        for @df -> $m { say "  FAIL  {$m}" }
        @failed.append(@df);
    }
    if @*ARGS.grep({ $_ eq '--precommit' }).elems {
        @failed.append(check-staged-compile());
    }

    say "";
    say "===== 个人痕迹检查（会进发布包的内容里，不该有本机用户名 / 绝对路径） =====";
    my @pf = check-personal-traces();
    if !@pf.elems {
        say "  ok    没有本机工作区路径 / 历史用户名 / 非中性 Windows 用户名";
    }
    else {
        for @pf -> $m { say "  FAIL  {$m}" }
        @failed.append("个人痕迹检查（{@pf.elems} 处。改成中性占位：user / foo / tester 之类；"
                     ~ "路径示例写 C:\\Users\\user\\）");
    }
}

# ---------------------------------- 汇总 --------------------------------------
say "";
say "=========================== 汇总 ===========================";
if @failed.elems {
    say "失败 {@failed.elems} 项：";
    for @failed -> $f { say "  · {$f}" }
    say "";
    say "**回归不通过** —— 修好再提交/推送。";
    exit 1;
}
say "全部通过 ✅（串行判定口径；jobs={$jobs}）";
exit 0;
