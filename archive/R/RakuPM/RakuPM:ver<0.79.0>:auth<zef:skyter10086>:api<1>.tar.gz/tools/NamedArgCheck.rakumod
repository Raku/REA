# NamedArgCheck —— 具名实参名的静态检查（开发工具，不随发行版安装）
#
# 要抓的问题：Raku 的 **method 会静默忽略未知具名实参**（而 sub 会报错）：
#     sub    s(:$x = 1) { }  ;  s(:zzz(9))     # 报 Unexpected named argument  ✅
#     method m(:$x = 1) { }  ;  $o.m(:zzz(9))  # 静默忽略，$x 取默认值，无任何提示 ❌
# 私有方法、role 方法同样静默。于是「方法调用点上的具名实参名字拼错 / 记错」
# 编译器与运行时都不告诉你，参数凭空失效。项目里已因此栽过两次：
#     uninstall($name, :$ver)   ← 形参其实叫 :version → 整包版本被删（数据丢失）
#     self-upgrade(:$src)       ← 形参其实叫 :source  → 那条分支永不走到
#
# 做法：全项目收集「已声明的具名名字」（routine 形参 + has 属性名），再扫所有
# colonpair；名字不在集合里就报嫌疑。
#
# 为什么不用正则：Raku 里 `[$%@]` 是【分组不是字符类】（`%` 被当量词直接编译错）；
# 命名捕获配字符类极易「匹配上了但捕获是 Nil」→ `~Nil` 得空串 → 集合里只剩一个
# 空串键 → **全体误判为已声明** → 检查器变假绿（0.44.0 那次失败就死在这里）。
# 所以这里**全程字符级扫描**，不碰命名捕获。
#
# 已知边界（宁可少报也不误报 —— 误报会让门禁被人用 --no-verify 绕过）：
#   · 名字集合是**全项目**的、不按被调方区分 → 抓的是「拼写 / 记忆错误」这一
#     高发且致命的类型；「名字合法但用错对象」这种语义错误抓不到。
#   · 项目外 API（核心 IO/Proc/正则副词、CPI、Distribution::Path…）靠 %ALLOWED
#     兜住，每条都写了理由；白名单本身就是一份审查记录。
unit module NamedArgCheck;

# ============ 源码预处理：把「不是代码」的部分抹成等长空格 ============
#
# 三个函数都必须【等长】：位置能直接映射回原行号（报嫌疑要给人看行号和原文）。

my %HEREDOC-CLOSE =
    '<' => '>', '[' => ']', '(' => ')', '{' => '}', '«' => '»',
    "'" => "'", '"' => '"', '/' => '/', '|' => '|', '!' => '!';

sub delim-after(Str $line, Int $i --> Str) {
    my $j = $i;
    while $j < $line.chars && $line.substr($j, 1) ~~ /\s/ { $j++ }
    return '' if $j >= $line.chars;
    my $open  = $line.substr($j, 1);
    my $close = %HEREDOC-CLOSE{$open};
    return '' unless $close.defined;
    my $rest = $line.substr($j + 1);
    my $e    = $rest.index($close);
    return '' unless $e.defined;
    $rest.substr(0, $e)
}

# 这一行是不是 heredoc 起始？是则返回结束定界符。
# 判据沿用 lib/RakuPM/NativeLib.rakumod 里那套（已在生产里跑）：`:to` 前面必须是
# q/Q 或一个「分隔位」。**外加一道它没有的守卫**：注释里的示例不算 —— NativeLib
# 自己的文档注释里就列了 q:to/END/ 、:to<END> 各种写法，不加这条会把注释之后的
# 大段真实代码当成 heredoc 内容整段遮蔽（作者第一版就是这么翻车的：
# 273 行的 `has Str $.os` 整行变空格，于是属性名一个都收不到）。
sub heredoc-marker(Str $line --> Str) {
    return '' if $line.trim-leading.starts-with('#');
    for ':heredoc', ':to' -> $kw {
        my $at = $line.index($kw);
        next unless $at.defined;
        next if $line.substr(0, $at).contains('#');        # 行内注释之后的
        my $prev = $at > 0 ?? $line.substr($at - 1, 1) !! '';
        next unless $prev eq '' || so $prev ~~ /^ <[qQ\s(=,]> $/;
        my $d = delim-after($line, $at + $kw.chars);
        return $d if $d.chars;
    }
    ''
}

# heredoc 内容整行遮蔽为等长空格。
#
# 【两遍扫描】先确认"结束标记真的存在"，再遮蔽 —— 这一步至关重要：
# 单遍实现里，只要判据误把某行当成 heredoc 起始（例如文档注释里恰好列了
# `q:to/END/` 这种示例），就会一路遮蔽到文件末尾或下一次偶然出现该标记的行，
# 静默吞掉大片真实代码，而检查器照样输出"通过"（作者第一版就是这么翻车的：
# NativeLib 的注释里列了各种 heredoc 写法 → 273 行的 `has Str $.os` 整行变空格，
# 属性名一个都收不到）。两遍扫描让"找不到结束标记"自然退化为"不是 heredoc"。
sub mask-heredocs(Str $src --> Str) {
    my @lines = $src.lines;
    my @mask;                                  # 待遮蔽的行号
    my $MAX-SPAN = 500;                        # 防御：真 heredoc 也不该有几千行
    my $i = 0;
    while $i < @lines.elems {
        my $m = heredoc-marker(@lines[$i]);
        if $m.chars {
            my $j = $i + 1;
            my $end = -1;
            while $j < @lines.elems && ($j - $i) <= $MAX-SPAN {
                if @lines[$j].trim eq $m { $end = $j; last }
                $j++;
            }
            if $end > $i {
                @mask.push($_) for ($i + 1) .. $end;
                $i = $end + 1;
                next;
            }
            # 找不到结束标记 → 判据失效，不当作 heredoc，继续往下扫
        }
        $i++;
    }
    @lines[$_] = ' ' x @lines[$_].chars for @mask;
    @lines.join("\n")
}

# 把行注释与字符串内容换成空格（保持长度与换行），只留代码骨架。
# 引号状态**不跨行累积**：Raku 的单行字符串本就不跨行（跨行的用 heredoc，
# 已单独遮蔽），而正则字面量里的引号（如 `<["']>`）会让配对算错 —— 不重置的话
# 错误状态会一路累积，把后面整段真实代码吞掉（同上，作者第一版翻车现场）。
sub strip-code(Str $src --> Str) {
    my @c = $src.comb;
    my $n = @c.elems;
    my @out;
    my $state = 'code';
    my $i = 0;
    while $i < $n {
        my $c = @c[$i];
        given $state {
            when 'code' {
                if    $c eq '#' { @out.push(' '); $state = 'lc' }
                elsif $c eq "'" { @out.push(' '); $state = 'sq' }
                elsif $c eq '"' { @out.push(' '); $state = 'dq' }
                else            { @out.push($c) }
            }
            when 'lc' {
                if $c eq "\n" { @out.push($c); $state = 'code' } else { @out.push(' ') }
            }
            when 'sq' {
                if    $c eq '\\' { @out.push(' '); $i++; @out.push($i < $n ?? ' ' !! '') }
                elsif $c eq "'"  { @out.push(' '); $state = 'code' }
                elsif $c eq "\n" { @out.push($c); $state = 'code' }
                else             { @out.push(' ') }
            }
            when 'dq' {
                if    $c eq '\\' { @out.push(' '); $i++; @out.push($i < $n ?? ' ' !! '') }
                elsif $c eq '"'  { @out.push(' '); $state = 'code' }
                elsif $c eq "\n" { @out.push($c); $state = 'code' }
                else             { @out.push(' ') }
            }
        }
        $i++;
    }
    @out.join
}

# ============ 代码骨架上的字符级扫描 ============

sub word-char($ch --> Bool) { so $ch ~~ /^<[A..Za..z0..9_]>$/ }
sub name-char($ch --> Bool) { word-char($ch) || $ch eq '-' }

# 配平括号：$open 处是 '('，返回配对 ')' 的下标；找不到返回 -1。
sub balanced-end(Str $code, Int $open --> Int) {
    my @c = $code.comb;
    my $n = @c.elems;
    my $depth = 0;
    my $i = $open;
    while $i < $n {
        my $ch = @c[$i];
        if    $ch eq '(' { $depth++ }
        elsif $ch eq ')' { $depth--; return $i if $depth == 0 }
        $i++;
    }
    -1
}

# 所有 `%( ... )` 的区间。区内的 colonpair 是 **Hash 字面量的键**、不是具名实参，
# 必须豁免（否则 `%( :name($x), type => 'y', :$url )` 里的 :url 会被当成嫌疑）。
sub hash-literal-ranges(Str $code --> List) {
    my @c = $code.comb;
    my $n = @c.elems;
    my @ranges;
    my $i = 0;
    while $i < $n - 1 {
        if @c[$i] eq '%' && @c[$i+1] eq '(' {
            my $end = balanced-end($code, $i + 1);
            if $end > $i + 1 {
                # 必须用 [ ] 包成 Array：push 是 slurpy 的，直接 push((a,b)) 会把
                # 两项【展平】成两个独立元素，区间判断随之全错（豁免彻底失效）。
                @ranges.push([$i, $end]);
                $i = $end + 1;
                next;
            }
        }
        $i++;
    }
    @ranges
}

# 全部 colonpair：:name / :name(...) / :$var / :@arr / :%hash / :$!attr / :!merge
sub colonpairs(Str $code --> List) {
    my @c = $code.comb;
    my $n = @c.elems;
    my @hits;
    my $i = 0;
    while $i < $n {
        if @c[$i] eq ':' {
            # `::` 整体跳过两个字符：否则第二个冒号会被当成 colonpair 起点，
            # 于是 RakuPM::Client::SelfManager 会冒出 :Client / :SelfManager
            # 两条假嫌疑（每条 `use` 一行，噪声量很大）。
            if $i + 1 < $n && @c[$i+1] eq ':' { $i += 2; next }
            if $i > 0 && @c[$i-1] eq ':'      { $i++;     next }
            my $prev = $i > 0 ?? @c[$i-1] !! '';
            # 排除两类「看着像 colonpair 其实不是」：
            #   Mu:D / Int:U（类型笑脸）、/foo:g/（正则副词）→ prev 是标识符字符
            #   %h<a>:exists / $x[0]:delete（方法调用）    → prev 是 > ) ] }
            my $prev-bad = $prev.chars && (word-char($prev)
                          || $prev eq ')' || $prev eq ']' || $prev eq '}' || $prev eq '>');
            unless $prev-bad {
                my $j = $i + 1;
                my $sigil = '';
                if $j < $n && (@c[$j] eq '$' || @c[$j] eq '@' || @c[$j] eq '%') { $sigil = @c[$j]; $j++ }
                $j++ if $j < $n && @c[$j] eq '!';
                my $st = $j;
                while $j < $n && name-char(@c[$j]) { $j++ }
                my $name = $code.substr($st, $j - $st);
                # 纯数字名是数字字面量（:16<ff>），不是具名实参
                if $name.chars && !($sigil eq '' && $name ~~ /^<[0..9]>/) {
                    # 用 %( ) 而不是 { }：大括号在 Raku 里是 Block/Hash 歧义，
                    # 工具自身也用 { } 造 Hash 的话就认不出「这是字面量的键」。
                    @hits.push(%( :$name, :$sigil, :pos($i), :end($j) ));
                }
                $i = $j > $i ?? $j !! $i + 1;
                next;
            }
        }
        $i++;
    }
    @hits
}

# routine 定义参数列表里的具名形参名
sub declared-params(Str $code --> List) {
    my @c = $code.comb;
    my $n = @c.elems;
    my @out;
    my @kws = <submethod method sub>;
    my $i = 0;
    while $i < $n {
        my $kw = '';
        for @kws -> $k {
            next unless $i + $k.chars <= $n && $code.substr($i, $k.chars) eq $k;
            next if $i > 0 && word-char(@c[$i-1]);                        # 前边界
            next if $i + $k.chars < $n && word-char(@c[$i + $k.chars]);   # 后边界：substr ≠ sub
            $kw = $k; last;
        }
        if $kw.chars {
            my $j = $i + $kw.chars;
            my $found = -1;
            my $guard = 0;
            while $j < $n && $guard < 400 {
                my $ch = @c[$j];
                last if $ch eq '{' || $ch eq ';';        # 没有括号的签名 → 放弃
                if $ch eq '(' { $found = $j; last }
                $j++; $guard++;
            }
            if $found >= 0 {
                my $end = balanced-end($code, $found);
                if $end > $found {
                    my $params = $code.substr($found + 1, $end - $found - 1);
                    @out.push($_) for colonpairs($params).map(*<name>);
                    $i = $end + 1;
                    next;
                }
            }
        }
        $i++;
    }
    @out
}

# has 属性名（`has IO::Path $.target` / `has @.repos` / `has $!cur`）。
# 注意 sigil 在【前】、twigil 在后 —— 作者第一版按「[.!] 在前」找，
# 结果一个属性都没收到（自检 target=NO 暴露），而项目里大量具名实参
# 是传给属主的（Client.new(:target(...)) / Store.new(:root(...))），
# 全被误报成嫌疑。
sub declared-attrs(Str $code --> List) {
    my @c = $code.comb;
    my $n = @c.elems;
    my @out;
    my $i = 0;
    while $i < $n {
        if $i + 3 <= $n && $code.substr($i, 3) eq 'has'
           && ($i == 0 || !word-char(@c[$i-1]))
           && ($i + 3 >= $n || !word-char(@c[$i+3])) {
            my $j = $i + 3;
            my $guard = 0;
            while $j < $n && $guard < 150 {
                my $ch = @c[$j];
                last if $ch eq ';' || $ch eq "\n" || $ch eq '{' || $ch eq '}';
                if $ch eq '$' || $ch eq '@' || $ch eq '%' {
                    my $k = $j + 1;
                    if $k < $n && (@c[$k] eq '.' || @c[$k] eq '!') {
                        $k++;
                        my $st = $k;
                        while $k < $n && name-char(@c[$k]) { $k++ }
                        my $nm = $code.substr($st, $k - $st);
                        @out.push($nm) if $nm.chars;
                        $j = $k;
                        last;
                    }
                }
                $j++; $guard++;
            }
            $i = $j > $i ?? $j !! $i + 1;
            next;
        }
        $i++;
    }
    @out
}

# ============ 白名单：项目外 API 的具名参数 ============
#
# 每一条都必须写理由 —— 这份表本身就是审查记录。新增前先问：
# 「这个名字能不能在项目源码里找到声明？」能就别加（说明是漏收，去修扫描器）。
my %ALLOWED = %(
    # —— 子进程（核心）——
    'out'          => '核心：run(:out) / Proc::Async(:out)',
    'err'          => '核心：run(:err) / Proc::Async(:err)',
    'in'           => '核心：run(:in)',
    'env'          => '核心：run(:env) / Proc::Async.start(:env)',
    'cwd'          => '核心：run(:cwd) / Proc::Async.start(:cwd)',
    'merge'        => '核心：Proc::Async(:merge)（:!merge 同）',
    # —— 文件 / IO（核心）——
    'close'        => '核心：IO::Handle.slurp(:close)',
    'chomp'        => '核心：IO::Handle.lines(:chomp)',
    'w'            => '核心：IO::Handle.open(:w)',
    'a'            => '核心：IO::Handle.open(:a)',
    'r'            => '核心：IO::Handle.open(:r)',
    'rw'           => '核心：IO::Handle.open(:rw)',
    'non-blocking' => '核心：IO::Handle.lock(:non-blocking)',
    # —— 字符串 / 正则 / 列表（核心，多为单字母副词）——
    'g'            => '核心/正则副词：subst/match/comb(:g)',
    'global'       => '核心：Str.subst(:global)',
    'i'            => '正则副词 :i（ignorecase）',
    'm'            => '正则副词 :m（ignoremark）',
    's'            => '正则副词 :s（sigspace）',
    'x'            => '正则副词 :x（扩展空白）',
    'k'            => '核心：grep/first/sort(:k)',
    'v'            => '核心：grep(:v) / sort(:v)',
    'nth'          => '核心：Str.match(:nth)',
    'ov'           => '核心：Str.match(:ov)',
    # —— 外部模块 ——
    'sorted-keys'  => 'JSON::Fast.to-json(:sorted-keys)',
    'pretty'       => 'JSON::Fast.to-json(:!pretty) —— 关掉默认 pretty 打印、发紧凑 JSON 体（post-json 登录请求体用）',
    'prefix'       => 'CompUnit::Repository::Installation.new(:prefix)',
    'precompile'   => 'CUR::Installation.install(:precompile)',
    'meta-file'    => 'Distribution::Path.new(:meta-file)',
    'short-name'   => '核心：CompUnit::DependencySpecification.new(:short-name<Foo>)（0.48.0 `raku-pm which` 用它按模块名向某个仓库解析）',
    # —— 网络（核心）——
    'localhost'    => 'IO::Socket::INET.new(:localhost)',
    'localport'    => 'IO::Socket::INET.new(:localport)',
    'listen'       => 'IO::Socket::INET.new(:listen)',
);

# ============ 主入口 ============

# 从「文件名 => 源码」的 Pair 列表检查。抽出来是为了测试能直接喂人造源码。
#
# 参数刻意用 Pair 而不是 Hash：Raku 里 **Hash 在列表上下文会被展平成 Pair 列表**
# （`[ %h ]` 得到的是 Pairs 而不是一个 Hash；`f(*@x)` 传 Hash 同样展平）。
# 用 Pair 则任何传递方式都保持原样，不会踩这个坑。
sub check-texts(*@sources --> List) is export {
    my %declared;
    my @prepared;
    for @sources -> $pair {
        my $name = $pair.key.Str;
        my $text = $pair.value.Str;
        my $code = strip-code(mask-heredocs($text));
        %declared{.lc} = True for (|declared-params($code), |declared-attrs($code));
        @prepared.push(%( :$name, :$text, :$code ));
    }

    my @findings;
    for @prepared -> $p {
        my $code = $p<code>;
        my @hash-ranges = hash-literal-ranges($code);
        for colonpairs($code) -> $h {
            my $nm = $h<name>;
            next if %declared{$nm.lc};
            next if %ALLOWED{$nm}:exists;
            # Hash 字面量里的键不是具名实参
            next if @hash-ranges.first({ $h<pos> > $_[0] && $h<pos> < $_[1] });
            my $line = $code.substr(0, $h<pos>).lines.elems;
            my @rl = $p<text>.lines;
            @findings.push(%(
                :name($nm),
                :line($line),
                :file($p<name>),
                :snippet(($line >= 1 && $line <= @rl.elems) ?? @rl[$line - 1].trim !! ''),
            ));
        }
    }
    @findings.sort({ .<file> leg .<file> || .<line> <=> .<line> }).List
}

sub source-files(IO::Path $d --> List) {
    return () unless $d.e;
    my @out;
    my @stack = ($d,);
    while @stack {
        my $cur = @stack.pop;
        my @entries = $cur.dir;                      # 急切收集（Windows 目录句柄）
        for @entries -> $e {
            my $bn = $e.basename;
            next if $bn eq '.precomp' || $bn eq '.git' || $bn eq 'blib';
            if $e.d { @stack.push($e) }
            elsif so $bn ~~ /\. [ rakumod | pm6 | raku | t | rakutest ] $/ { @out.push($e) }
        }
    }
    @out.sort({ .absolute.Str }).List
}

# 扫一棵仓库树。:@dirs 是要扫的子目录。
sub check-named-args(IO::Path $root, :@dirs = <lib bin t xt tools> --> List) is export {
    my @pairs;
    for @dirs -> $d {
        for source-files($root.add($d)) -> $f {
            @pairs.push($f.relative($root).Str => $f.slurp);
        }
    }
    check-texts(|@pairs)
}
