# raku-pm 重构路线图与实施清单

本文件用于把“项目现状分析”转成可执行的里程碑计划。

## 0. 路线图总则

- **先降维护成本，再扩能力**
- **先补文档与可观察性，再做深层重构**
- 每个 PR 保持“可独立合并、可独立验收”
- 不改变现有核心语义，只降低未来变更成本

建议执行顺序：

1. **M1**：快速上手 + CLI 结构治理 + 消息层收口  
2. **M2**：作者侧可教学 + 排障效率 + HTTP 可观察性  
3. **M3**：平台矩阵固化 + 关键链路 e2e + install 参数收敛

---

## 1. Milestone 1（M1）：上手体验与 CLI 可维护性

目标：
- 新用户 5 分钟内完成基本 install 流程
- CLI 的命令定义、旗标白名单、补全生成可维护
- 用户面提示风格统一

### PR1：文档拆分与快速上手

**改动范围**
- `README.md`
- `README.en.md`
- `docs/quickstart.md`（新增）
- `docs/architecture.md`（新增）

**具体动作**
- `README.md` 保留：
  - 项目介绍
  - 安装方式
  - 最小用法（`install / upgrade / verify`）
- 原 README 中“架构、锁文件、世代、多索引、平台差异”迁移到 `docs/architecture.md`
- 新增 `docs/quickstart.md`，覆盖：
  - 本地仓库安装
  - git URL 安装
  - 锁文件与 `--locked`
  - rollback 基本流程

**验收标准**
- 新用户只看 README 可快速跑通核心安装路径
- 原有文档内容不丢失，只是迁移位置
- `raku tools/run-suite.raku --precommit` 文档一致性检查仍通过

---

### PR2：CLI 元数据声明化

**改动范围**
- `bin/raku-pm.raku`
- `lib/RakuPM/CliSpec.rakumod`（新增）
- `lib/RakuPM/CliAlias.rakumod`（可选）

**具体动作**
- 将 `%CMD_FLAGS`、`%CMD_ALIASES`、命令分组、是否需要写锁、是否联网等信息抽到独立模块
- CLI 仅保留：
  - 参数解析
  - 声明表查询
  - 旗标校验
  - 命令派发

**验收标准**
- `raku-pm completions bash|zsh|fish|pwsh` 输出不变
- `raku-pm help` 输出不变
- 新增一个 flag 只改声明表，不改派发逻辑
- `tools/run-suite.raku` 通过

---

### PR3：用户面消息层收口

**改动范围**
- `lib/RakuPM/Message.rakumod`（新增）
- `bin/raku-pm.raku`
- `lib/RakuPM/Client/Reporter.rakumod`
- `lib/RakuPM/Installer.rakumod`

**具体动作**
- 统一 `warn / error / hint` 前缀
- 统一退出码语义（0/1/2）
- 先迁移高频提示：
  - CLI 校验报错
  - doctor
  - verify
  - native lib 检查结果

**验收标准**
- `raku-pm doctor` 提示风格统一
- 拼错旗标时错误提示风格统一
- 现有命令行为与退出码语义保持兼容

---

## 2. Milestone 2（M2）：作者侧与排障效率

目标：
- 作者侧流程可教、可复现
- 依赖解析不再是黑盒
- 网络与后端问题可快速定位

### PR4：作者侧 tutorial 文档

**改动范围**
- `docs/authoring.md`（新增）
- `examples/minimal-dist/`（新增示例目录）

**具体动作**
- 编写端到端教程：
  - `raku-pm new Foo::Bar`
  - `raku-pm refresh`
  - `raku-pm check`
  - `raku-pm dist`
  - `raku-pm publish --to=<本地仓库>`
- 提供最小示例仓库结构（META6 + lib + t）

**验收标准**
- 用户按文档可在本地完成完整发布流程
- 示例仓库可被 `raku-pm install` 识别并安装

---

### PR5：依赖解析诊断命令

**改动范围**
- `lib/RakuPM/Resolver.rakumod`
- `lib/RakuPM/Client/Reporter.rakumod`
- CLI 命令注册

**具体动作**
- 新增 `raku-pm resolve --explain Module` 或 `raku-pm why Module`
- 输出：
  - 候选版本来源（哪个 repo）
  - 被淘汰原因
  - 冲突约束
  - 最终选择顺序

**验收标准**
- 正常安装不受影响
- 对单模块可输出 explain 结果
- 对冲突依赖可输出冲突双方信息

---

### PR6：HTTP 可观察性增强

**改动范围**
- `lib/RakuPM/HTTP.rakumod`
- `lib/RakuPM/HTTP/Tinyish.rakumod`
- `lib/RakuPM/HTTP/HTTPTiny.rakumod`

**具体动作**
- 新增 debug 级日志：
  - 实际后端选择
  - 超时设置
  - 回退结果
- 统一离线/缓存命中提示样式
- 联网失败时明确提示“哪个后端失败 + 是否回退成功”

**验收标准**
- `--offline` 且有缓存时输出明确
- 后端回落成功/失败可从输出判断
- 默认不刷屏（debug 日志可控）

---

## 3. Milestone 3（M3）：稳定性与长期演进

目标：
- 把平台差异固化到文档和测试矩阵里
- 关键链路有端到端回归保护
- 安装参数收敛，降低组合复杂度

### PR7：平台行为矩阵与测试标签

**改动范围**
- `docs/platform-matrix.md`（新增）
- `t/native-lib.t`
- `t/native-search-path.t`
- `xt/` 相关集成测试

**具体动作**
- 梳理三平台行为差异：
  - native lib 搜索路径
  - shell wrapper
  - PATH / RAKULIB 语义
- 给关键测试补平台说明/标签

**验收标准**
- 文档与测试可一一对应
- Windows / Linux / macOS 核心规则都可在文档中查到

---

### PR8：关键链路 golden e2e

**改动范围**
- `xt/e2e-local-install.t`（新增）
- `xt/e2e-git-install.t`（新增）
- `xt/e2e-verify.t`（新增）
- `xt/e2e-uninstall-autoremove.t`（新增）

**具体动作**
- 固化四条关键链路：
  1. 本地仓库 install + upgrade + rollback
  2. git URL install + 依赖冲突
  3. verify --fix 边界
  4. uninstall + reverse deps + autoremove

**验收标准**
- 这四条链路稳定通过
- 单测全绿但 e2e 红时必须视为失败
- e2e 测试可在本地重复执行

---

### PR9：InstallContext 收敛安装参数

**改动范围**
- `lib/RakuPM/InstallOptions.rakumod`
- `lib/RakuPM/Client.rakumod`
- install / uninstall / reinstall / self-upgrade 入口

**具体动作**
- 将安装行为策略封装到统一 context：
  - dry
  - force
  - no-test
  - no-build
  - no-native-check
  - allow-test-failure
  - pin
- 让下游方法只读 context，不重复传零散布尔值

**验收标准**
- 现有安装命令行为不变
- 新增策略只改 context 定义
- 参数传递路径更清晰，测试可覆盖

---

## 4. 推荐 PR 验收模板（通用）

每个 PR 建议按以下结构验收：

### 目标
- 本 PR 解决什么问题

### 改动范围
- 涉及文件/模块清单

### 开发检查
- [ ] 代码改动完成
- [ ] CLI 输出兼容性确认
- [ ] 文档同步更新

### 测试检查
- [ ] `raku tools/run-suite.raku` 通过
- [ ] 相关 xt / t 新增或调整
- [ ] 手工验证核心链路（install / verify / doctor）

### 风险检查
- [ ] 是否影响默认行为
- [ ] 是否影响平台兼容性
- [ ] 是否需要迁移说明

---

## 5. 建议时间节奏

- **第 1 轮（1~2 周）**：完成 M1
- **第 2 轮（1~2 周）**：完成 M2
- **第 3 轮（1~2 周）**：完成 M3

如果时间紧张，优先保证：
- PR1（文档拆分）
- PR2（CLI 声明化）
- PR8（关键 e2e）

这三项收益最高。

---

## 6. 结论

这个项目的工程完成度已经很高，接下来最优策略不是继续快速加功能，而是：

- 把知识从 README 里抽出来，变成可持续维护的文档体系
- 把 CLI 从“能跑”升级成“好维护”
- 把关键链路用 e2e 测试锁死
- 把作者侧体验补齐，让它更适合教学和推广

这样后续每一次功能演进，都会更稳、更快、更容易被社区接受。