# 架构与深度设计

> 最小用法见 [../README.md](../README.md)；快速上手见 [./quickstart.md](./quickstart.md)。

> 本文档由 README 拆分而来，保留全部设计细节；仅位置迁移，未删减。

## 架构总览

```
bin/raku-pm.raku          薄壳入口（仅把参数转交给 RakuPM::CLI）
        │
        ▼
RakuPM::CLI               CLI 主体：命令派发 + 各命令实现（原先 bin 里的 900+ 行）
        │                 ※ 单独成模块【只为 precomp】：bin 脚本不享受预编译，
        │                   每次调用都被整体编译（实测 ~0.75s）；搬进模块后只剩
        │                   薄壳要编译，启动实测量省 0.6~0.8s（0.79.0）
        │
        ▼
RakuPM::Client            编排器（仿 Zef::Client，只负责协调）
        │
        ├── RakuPM::Repositories    仓库【列表】：配置持久化 + 别名 + 环境变量
        │       │                   （repositories.json，决定挂哪几个索引）
        │       ▼
        ├── RakuPM::Resolver       依赖解析器（递归解析 + 冲突检测 + 拓扑排序）
        │       │                  先按「该版本是否真的提供此模块」筛，再择优
        │       │
        │       ├── RakuPM::Repository (role)   仓库抽象（可插拔）
        │       │       │                    └ 混合 Repository::Matching：
        │       │       │                      「关键词↔发行版」匹配的唯一实现处
        │       │       │                      （search/store/installed/install 共用）
        │       │       ├── Repository::Local        本地目录仓库
        │       │       └── Repository::Ecosystem    远程 JSON 生态（zef/rea/cpan…）
        │       │
        │       ├── RakuPM::Version     语义化版本 + 约束匹配
        │       │
        │       └── RakuPM::Spec        安装规格串解析（Foo:ver<1.2.3> / Foo@1.2.3）
        │                               零依赖轻量模块：install 与查询命令共用
        │
        ├── RakuPM::Store           包存储（多版本共存 + 内容指纹）
        │
        ├── RakuPM::Installer       安装器（store → CUR::Installation 的 site/）
        │                           + 事务/世代 + bin wrapper
        │   ├── RakuPM::InstallOptions  安装链的选项载体（把 7+ 个布尔开关收成一个对象）
        │   ├── RakuPM::Ledger          账本（installed.json）的唯一读写入口
        │   ├── RakuPM::Fs              递归删除 / 复制 / 遍历 / 体积（单一实现处）
        │   ├── RakuPM::Installer::Generations      generations/ 目录的格式与生命周期
        │   │                           （id 分配 / before / meta / manifest / current / 裁剪）
        │   └── RakuPM::Installer::ShellTemplates   bin wrapper 的三段平台 shell 模板
        │                                （bash / cmd .bat / PowerShell .ps1，纯字符串函数）
        │
        ├── RakuPM::Prefix          安装前缀的【唯一】出处
        │                           默认前缀 / 前缀解析 / 「是不是默认前缀」/
        │                           promote 默认值。零依赖 —— CLI 要在
        │                           require Client 之前就知道前缀（冷启动）
        │
        ├── RakuPM::Platform        平台差异的【唯一】出处（H9）
        │                           系统判别 / 路径分隔符 / 可执行后缀 / MSYS 路径 /
        │                           强杀进程 / 库搜索路径 / md5 命令与输出格式
        │                           一律在调用时读 $*DISTRO，故测试能用
        │                           `my $*DISTRO = Distro.new(:name('linux'))`
        │                           遮蔽，在任意机器上把三个平台的分支真跑一遍
        │
        ├── RakuPM::NativeLib       系统本地库（:from<native>）探测
        │                           逻辑名 → 各系统文件名 + 搜索路径 + 安装命令
        │                           （平台知识全部委托给 RakuPM::Platform）
        │
        ├── RakuPM::FileLock        跨进程文件锁（flock）：写命令串行化
        │                           可重入、超时报错、进程被杀自动释放
        │
        ├── RakuPM::Cleaner         缓存回收（clean / gc）：判定哪些版本还在被用
        │                           默认只试算，--yes 才真删
        │
        └── RakuPM::Lock            锁文件（精确版本 + 指纹 + native-libs，
                                    保证可复现）

（下面这个不在 Client 树里 —— CLI 直接调用它，与安装目标无关）
RakuPM::Author            生产侧（作者侧）：面向【一个发行版目录】
        └── refresh               以磁盘为准重建 META6.json 的 provides
```

> `RakuPM::Client` 本身再按职责拆成 4 个 role（`SelfManager` / `Tester` / `Git` /
> `Reporter`），通过 `does` 混入同一个类，避免「编排器」膨胀成上千行的上帝类；
> 拆分后对外行为完全不变。

## HTTP 层：双后端（curl 优先 + 纯 Raku 兜底）

网络请求全部走 `RakuPM::HTTP` 门面，后端实现 `RakuPM::HTTP::Backend` 这个 role：

| 后端 | 底层 | 位置 | 说明 |
|---|---|---|---|
| `tinyish` | HTTP::Tinyish（系统 curl） | 默认第一 | TLS / 代理（含 HTTPS 走代理的 CONNECT）最稳，`timeout` 会变成 curl 的 `--max-time` |
| `httptiny` | HTTP::Tiny（纯 Raku） | 兜底 | 无外部进程；**客户端自身没有可用超时**（它的 `timeout` 选项从未被读取），由本后端在调用侧自己加闸 |

顺序可用 `RAKUPM_HTTP_BACKEND`（逗号串）覆盖，也可以
`RakuPM::HTTP.register-backend('myclient', MyClient)` 注册自己的实现。
**某个后端加载不了会自动回落到下一个** —— 源码直跑而机器上没装 HTTP::Tinyish 时靠这条兜住。

写新后端时两个已经踩过的坑，务必避开：

- **请求头要传给 `.get()`，不能塞进 `.new()`**。两个客户端的构造选项都叫
  `default-headers`，`.new(headers => …)` 会被静默丢弃 —— 曾经因此 `If-None-Match`
  从未真正发出，索引的 ETag / 304 增量更新（TTL 过期后的条件 GET）完全空转，
  每次都全量重下 10~18MB。
- **超时选项名**：Tinyish 是 `timeout`（不是 `max-time`）。写错等于没设超时，
  链路一停流就无限挂（Windows 与 WSL 表现一致，与平台无关）。
- **HTTP::Tiny 没有超时，得自己加闸**：`HTTPTiny` 把每个请求丢进线程、轮询等待，
  超过 `max-time` 就抛错让门面重试 / 回落。被放弃的那个线程杀不掉（卡在 socket
  读上，Raku 没有线程取消），会挂到进程退出 —— 实测不影响进程正常退出，但写测试
  时要注意：留一个永不响应的连接会让**测试进程**在退出时挂住，所以相关用例用的是
  「响应很慢」而不是「永不响应」的假服务器。

## 安装流程（五阶段）

```
解析 resolve → 抓取 fetch → 构建 build → 入存储 store → 测试 test → 激活 install → 写锁 lock
```

1. **resolve**：在各仓库里查找能提供目标模块的发行版，按约束挑最高版本，
   递归展开依赖成一棵树，再做拓扑排序得到「依赖优先」的自底向上顺序。
2. **fetch**：本地仓库直接指向目录；生态仓库按索引里的 `path` 拼 URL，
   用 HTTP 下载 tar 包并解压到 `cache/dist/<发行版>/<版本>/`。
3. **build**：包里有 `Build.pm`（约定 `class Build` 的 `build` 方法）或 META6
   写了 `"builder"` 字段（如 `Distribution::Builder::MakeFromJSON`）时，
   在发行版根目录起 raku 子进程执行构建，返回真才算成功；`build-depends`
   （builder 类通常是生态里的独立包）会在构建前自动解析安装；
   `--no-build` 可整段跳过。native 包常用这一步编译 C 源生成
   `resources/libraries/*.so`。
4. **store**：源码目录入库（内容指纹 MD5），一次下载可反复部署。
   Build 生成的资源此刻随包复制进 store，装完后 `%?RESOURCES` 才取得到。
5. **test**：在源码目录上跑 `t/*.t` 与 `t/*.rakutest`（`-I lib -I inst#<target>/site`，
   依赖此时已装进 CUR::Installation）。任一用例失败即中止安装，`--no-test` 可跳过。
6. **install**：交给 `CompUnit::Repository::Installation` 装进 `target/site/`。
   它默认 `:precompile`，预编译由 Rakudo 自己管 —— 早期那套「跑 `raku -M<mod>`
   把模块预编译进平铺 lib/」的做法已删除（既慢又缺版本元数据）。
7. **lock**：写入精确版本 + 指纹。
8. **世代（原子安装）**：上面第 3~7 步整体包在一个**事务**里 —— 任何一个包失败，
   target 会被恢复成本次操作前的样子；全部成功才落一个**世代**，可随时
   `raku-pm rollback` 退回。详见下面《原子安装与世代回滚》。

**git 安装走同一条流水线**，只是第 1、2 步的「目标包」换成 git clone 出来的目录：
`resolve` 时用 `META6.json` 里的 `depends` 当**一组根**递归解析（见下节），
`fetch` 时目标包跳过下载、直接用 clone 目录，其余步骤逐字相同。

## 原子安装与世代回滚

一次 `install` 要么**完全生效**、要么**完全不生效**，不留「装了一半」的坏状态：

```
raku-pm install A          # A 依赖 B → 顺序 [B, A]
  B 装进 CUR ✓
  A 测试失败 ✗
  → 回滚：把 B 也摘掉，target 回到执行前
```

```bash
raku-pm generations     # 列出所有世代
raku-pm rollback        # 退回上一世代
raku-pm rollback 000003 # 退回指定世代
```

**为什么世代这么便宜**：`CompUnit::Repository::Installation` 天然支持多版本并存，
装新版本不会抹掉旧版本。所以「回滚」= 把本次装进去的版本从 CUR 摘掉 + 把
账本 `installed.json` 恢复成事务前那份，旧版本本来就还在 CUR 里 —— 世代因此
只是一份几 KB 的 JSON，**不需要复制几百 MB 的 `site/`**。

布局：

```
target/
├── site/                    当前生效的 CUR::Installation
├── installed.json           当前账本（世代的 manifest 就是它的快照）
└── generations/
    ├── current              当前世代 id
    ├── 000001/
    │   ├── before.json      事务前的账本快照（回滚的真值来源）
    │   ├── manifest.json    提交后的账本（= 这个世代长什么样）
    │   └── meta.json        时间、本次装了什么
    └── 000002/…
```

保留最近 10 个世代，当前世代永不裁剪。

**边界（诚实声明）**：

- `build` / `test` 发生在源码目录，不碰 target，本来就是原子的；事务保护的是
  「激活进 target CUR + 写账本 + 放 bin」这一段。
- 回滚到某个世代时，若对应版本的源码已被 `raku-pm clean` 从 store 清掉，
  会警告并跳过（装不回来）。所以别在需要回滚前激进 gc。
- 同版本 `--force` 重装被回滚时，CUR 里那份会被摘掉，此时若 store 里还有该
  版本会自动装回，不会出现「账本说装了、实际加载不到」。

## 反向依赖与依赖回收

依赖声明写的是**模块名**（`"depends": { "Foo::Bar" => "1.0" }`），而账本记的是
**发行版名**，两者靠 `provides` 打通，于是得到一张依赖图；反向依赖就是它的反向边。

```bash
raku-pm rdepends Foo          # 反查谁依赖了 Foo（也可写它提供的模块名）
raku-pm uninstall Foo         # 还有包依赖它时【拒绝】卸载
raku-pm uninstall Foo --recursive   # 把依赖它的包也一并卸掉
raku-pm uninstall Foo --force       # 强卸（会留下坏掉的依赖，自己负责）
raku-pm autoremove            # 回收不再被依赖的包
raku-pm autoremove --dry      # 只看不动
```

`uninstall` 之后会顺带提示「以下包不再被任何已装包依赖」，例如卸掉 `Top` 之后：

```
以下 1 个包不再被任何已装包依赖（当初是作为依赖装进来的）：
  · Mid 1.0
  raku-pm autoremove        可以把它们一起清掉
```

**为什么不会乱删**：账本给每个包记了 `reason` ——

| reason | 含义 | 会被 autoremove 回收吗 |
|---|---|---|
| `explicit` | 用户点名装的（`@order` 里最后一个，即本次目标包） | **永远不回收** |
| `dependency` | 作为依赖被拉进来的 | 没人再依赖它时回收 |

老账本没有 `reason` 字段时按 `explicit` 处理——**宁可不回收，也不能把用户自己装的东西
悄悄删掉**。这是 apt 的 auto/manual 标记同款用意：没有这个区分，「自动回收」就变成「乱删」。

`autoremove` 会循环到收敛：卸掉 `Mid` 可能让只被 `Mid` 依赖的 `Leaf` 变成新孤儿，
一并處理。

## 校验：内容完整性 + 安装一致性

```bash
raku-pm verify              # 两段都跑
raku-pm verify --content    # 只看内容完整性（旧行为）
raku-pm verify --fix        # 顺便修能修的
```

**① 内容完整性** —— store 里的源码有没有被改动（覆盖 `versions[]` 全部版本，
不是只查激活版本）。

**② 安装一致性** —— 账本 / CUR / store / resources 四者对不对得上。这一段是后来
加的：只做 ① 会给人虚假安全感——GDBM 那次 CUR 已经半残（`site/dist/<id>` 丢了），
而 store 副本完好无损，① 照样报「全部正常」。

| 问题 | 含义 | 能自动修吗 |
|---|---|---|
| 账本有、CUR 没有 | dist 条目损坏那类半截状态 | 否，需重装 |
| 账本有、store 没有 | 回滚/重装装不回来 | 否，需重装 |
| CUR 有、账本没记 | 影响 `installed` / 依赖回收 / 世代回滚 | ✅ 补记账本 |
| 声明过的资源文件没了 | 构建产物被删 | 否，需重装 |
| **构建后资源仍没生成** | 构建没跑成功（0.44.0 起可查） | 否，需重装 |
| **声明了 builder 却没有构建痕迹** | 旧版 raku-pm 装的，无从确认 | 否，需重装 |
| **用 `--no-build` 装进去的** | 主动跳过了构建，但包声明了 builder | 否，需重装 |
| **构建失败却仍被入库** | 不应发生 | 否，需重装 |

### 构建痕迹：`build.json` 旁车（0.44.0 起）

store 每个条目多一个 `build.json`，记下构建阶段到底发生了什么：`mode`
（`built` / `skipped-no-build` / `not-needed` / `not-recorded`）、成功与否、
用的哪个 raku（编译器发行版号，便于排查预编译/ABI 不一致）、以及
**声明过却没生成的那些资源**。

它补的正是下面这条原本的诚实边界：只声明磁盘上真实存在的资源是 `Store` 的必然
取舍（声明了却找不到会让 `CUR::Installation` 装不上），于是「构建没跑成功 →
资源没生成」在 store 的 `META6.json` 里被**静默剔除**，事后看那份元数据干干净净，
查无可查。`build.json` 把「被剔掉的是哪些」原样记下来，`verify` 才第一次能报出来。

它刻意**不计入内容指纹**（`!fingerprint` 里与 `.digest` 同级跳过）：它是「条目
怎么产出的」的记录，不是发行版内容；带时间戳，计入指纹会让每次重算都漂移、
误报「内容已被修改」。

仍然查不出来的一类：**资源压根没在任何 META6 里声明过**（上游打包就没声明）——
那种情况连「该有什么」都不知道，不假装能查。

## 仓库：可配置的数组

Raku 世界不止一个生态索引，而且**收录范围差别很大**（2026-09 实测）：

| 别名 | 索引 URL | 记录数 | 唯一发行版 | 特点 |
|---|---|---:|---:|---|
| `zef` | <https://360.zef.pm> | 7971 | 1617 | 当前版本，官方生态 |
| `rea` | `…/Raku/REA/main/META.json` | 15054 | 2538 | 生态存档，**含历史版本与已下架包** |
| `cpan` | `…/Perl6-ecosystems/master/cpan1.json` | 1916 | — | CPAN 上的 Perl6 模块 |
| `p6c` | `…/Perl6-ecosystems/master/p6c1.json` | — | — | 旧生态存档 |

**有 922 个发行版只在 REA 里有、zef 索引里没有**，所以单个索引装不全所有包——
仓库必须是数组。

配置来源优先级（高 → 低）：

1. `$RAKUPM_TARGET/repositories.json`（`repos add/remove` 维护，持久化）
2. `RAKUPM_ECOSYSTEM` 环境变量，支持逗号/分号分隔多个，每项可以是 URL 或上表别名
3. 默认：`zef` 索引 + 本地 `$RAKUPM_REPO` 目录

**一个容易踩的坑**：`RAKUPM_REPO` 是**调用级**设置（相当于"这次在哪个目录找本地包"），
即使配置文件里已经存了 `local` 的路径，命令行显式指定时也会覆盖它。而
`RAKUPM_ECOSYSTEM` 是**持久配置**的兜底，只有配置文件不存在时才生效。
（否则 `RAKUPM_REPO=./vendor raku-pm install Foo` 会静默用回上次存下的路径，
表现为"明明把包放进去了却找不到"。）

```bash
raku -Ilib bin/raku-pm.raku repos                 # 列出已配置的仓库
raku -Ilib bin/raku-pm.raku repos add rea          # 加生态存档（别名）
raku -Ilib bin/raku-pm.raku repos add https://example.com/eco.json   # 或完整 URL
raku -Ilib bin/raku-pm.raku repos remove rea

# 也可以不落盘，临时指定多个索引
RAKUPM_ECOSYSTEM='https://360.zef.pm,rea' raku -Ilib bin/raku-pm.raku install ADT
```

### 本地目录仓库（不需要任何索引文件）

一个目录下挂多个「发行版子目录」，每个子目录里放 `META6.json` + `lib/` 即被收录：

```
~/my-dists/
├── HTTP-Client/{META6.json, lib/...}
└── Web-App/{META6.json, lib/...}
```

```bash
# 给的是目录 → 自动识别为本地仓库（名字默认取目录名，可用 --name= 指定，存绝对路径）
raku -Ilib bin/raku-pm.raku repos add ~/my-dists
# 往里填内容：取源码（只下载不安装），或自己把包目录放/软链进去
raku -Ilib bin/raku-pm.raku fetch HTTP::Client --to=~/my-dists
raku -Ilib bin/raku-pm.raku repos remove ~/my-dists      # 按目录/名字都能删
```

之后 `install` / `search` / 依赖解析都会认这个仓库里的包。

两点要分清：
- 本地仓库是**源码来源**，不是已安装的包 —— 已装的在 `$RAKUPM_TARGET/site/`；
- 单个正在开发的包**不必**建仓库，直接 `raku-pm install ./my-pkg` 即可（会自动装依赖）。
  建仓库的价值在于「多个本地包 + 按名安装 + 依赖能被自动解析」。

### 安装前缀

`--target=<路径>` 指定**安装前缀**（一个前缀 = 一份独立的包环境），优先于环境变量
`RAKUPM_TARGET`，默认 `~/.raku-pm`。写在命令**前或后**都行，两种位置等价：

```bash
raku -Ilib bin/raku-pm.raku install Foo --target=./vendor
raku -Ilib bin/raku-pm.raku --target=./vendor install Foo    # 等价
```

路径里的前导 `~` 会被展开：`--target=~/myenv` 是**家目录**下的 `myenv`，
不是当前目录下一个叫 `~` 的目录。（Rakudo 自己不展开 `IO::Path` 里的 `~`，
这一步是 raku-pm 补上的。）

**前缀自洽**：`<前缀>/bin/` 里的 wrapper 会把前缀显式传给 CLI —— 敲哪个前缀的
wrapper 就在哪个前缀里干活，跟 venv 的 `<venv>/bin/python` 是同一个语义。
所以「用哪个环境」= 「用哪个 wrapper」/「PATH 里哪个 bin 排在前面」。

**要不要写全局 `site/bin`**：装完默认会把 wrapper 也复制进
`<rakudo>/share/perl6/site/bin`（zef 用的那个目录、天然在 PATH 上），这样装完命令
立刻能用。但这个默认**只对默认前缀生效**；自定义前缀不写 —— 全局 `site/bin` 是整机
共享的，局部安装写进去会污染全局环境，多个前缀之间还会互相覆盖：

| 前缀 | 默认行为 | 想改用 |
|------|----------|--------|
| 默认 `~/.raku-pm` | 写全局 `site/bin`（zef 同款：装完即用） | `--no-promote-bin` |
| 自定义 `<路径>` | 不写（只动前缀内部） | `--promote-bin` |

自定义前缀下装完会明确提示该配什么。要让它生效就是两行：

```bash
export RAKULIB="inst#<前缀>/site"     # 模块搜索路径（inst# 前缀不能省）
export PATH="<前缀>/bin:$PATH"        # 命令搜索路径（放最前）
```

`raku-pm env` 会按当前前缀直接把这两行打印出来。

**为什么 bin 要放 PATH 最前**：跨目录是「PATH 顺序」说了算，只有**同一个目录内部**
才轮到 PATHEXT 比扩展名。所以把 `<前缀>/bin` 放最前就能赢过 zef 目录里的
`<命令名>.exe` —— 不必去改别人的文件。

#### 推荐做法：完全不写前缀外的文件（PATH 模式）

上面的默认行为是往全局 `site/bin` 写一份副本（zef 同款）。如果你更希望
「raku-pm 只在它自己那个目录里留下东西」，把**默认前缀**也切到 PATH 模式：

```bash
# ① 先把前缀自己的 bin 放到 PATH 最前（写进 shell 配置里长期生效）
export RAKULIB="inst#$HOME/.raku-pm/site"
export PATH="$HOME/.raku-pm/bin:$PATH"      # ← 顺序关键，必须在 rakudo site/bin 之前

# ② 以后升级/安装都不再往全局 site/bin 写（self-upgrade 也认这个旗标）
raku-pm self-upgrade --no-promote-bin

# ③ 可选：清掉此前写进全局 site/bin 的那三份副本
#    位置：<rakudo>/share/perl6/site/bin/ 下的 raku-pm、raku-pm.bat、raku-pm.ps1
#    先确认 ① 已生效（`raku-pm env` 列出的 [0] 指向 <前缀>/bin）再删，否则会没有入口。
```

三个好处：① 前缀外不留任何文件，升级或重装 rakudo 都带不走它；
② 不必改动别的包管理器留下的文件（0.48.0 的「入口体检」改名只是补救手段）；
③ 撤销只要改 PATH，不留残渣。代价是自己配一次上面那两行 —— `raku-pm env`
会按当前前缀直接把这两行打印出来。

**多版本 / 多项目共存**：一份前缀就是一份独立环境，互不干扰：

```bash
raku-pm --target=./projA/.raku-env install Foo    # A 项目自己的环境
raku-pm --target=./projB/.raku-env install Foo    # B 项目的，版本可以不同
```

自定义前缀默认就是 PATH 模式（不写全局 site/bin），且 `<前缀>/bin/` 里的 wrapper
会把前缀显式传给 CLI —— 敲哪个前缀的 wrapper 就在哪个前缀里干活。

#### ⚠ 全局 `RAKULIB` 对「开发 raku-pm 本身」是个陷阱

上面建议把 `RAKULIB` 写进 shell 配置 —— 对**用**包是对的（裸 `raku` 也能 `use Foo`）。
但请注意它的副作用：**裸 `raku` 从此也会加载 `<前缀>/site` 里那份 RakuPM 自己**。
如果那份是旧的，你在仓库里跑测试或脚本时就会「以为测的是工作树、其实测的是旧版」——
症状是**旧版的 bug 被当成当前代码的失败报出来**，方向完全跑偏
（0.49.3 就是因为这个查了半天；`t/` 与 `xt/` 里没写 `use lib` 的文件会这样）。

自保三条：

- 跑测试只用 `raku tools/run-suite.raku`：它给每个测试传 `-I<工作树>/lib`，
  并在跑之前**自检**链首确实是工作树，不是就**直接中止**（不产生假绿）；
  除跑测试外它还带三道静态闸门：**具名实参检查**、**文档纪律校验**（版本号三处一致 /
  provides 完整性 / bin / Changes）、**个人痕迹检查**（会进发布包的内容里不该出现本机
  用户名或绝对路径 —— 这类泄漏会「换个写法复发」，故钉成闸门；`--docs-only` 秒级可跑）；
- 单独跑某个文件用 `raku -Ilib t/<x>.t`（`-I` 永远排在 `RAKULIB` 之前）；
- 想知道「此刻裸 `raku` 会用哪一份」：`raku-pm which RakuPM::Version`
  （链上多份时会把被遮蔽的都列出来）；
- raku-pm **自己启动也会自检**：加载链上出现多个不同版本的 RakuPM 时，会在
  stderr 打印 `⚠ 加载链上检测到多个 RakuPM 版本`，提示实际加载的未必是以为的那份
  （0.54.1 起；纯警告、零代价，不影响加载行为）。

清掉前缀里那些过期的 RakuPM（**用命令、别手删**）：

```bash
raku-pm installed RakuPM              # 看前缀里有哪些版本，* 是不指定版本时 use 拿到的那个
raku-pm self-upgrade                  # 让前缀里有一份当前的（最高版本会被优先选中）
raku-pm uninstall RakuPM --version=0.36.14   # 确定不要的旧版再逐个摘掉
```

输出示例：

```
已配置的仓库（共 3 个，按优先级从上到下）：
  [0] zef  远程索引  https://360.zef.pm
  [1] rea  远程索引  https://raw.githubusercontent.com/Raku/REA/main/META.json
  [2] local  本地目录  .
```

**多索引如何协同**：解析时把各索引的候选版本**合并**，再挑满足约束的最高版本，
所以后加的 rea / cpan 不会覆盖 zef 的新版本。`repos add` 会把新仓库插到最后一个
远程索引之后（`local` 之前），保持主索引 zef 在最前。找不到包时报错会直接提示
该加哪个索引：

```
在所有已配置的仓库里都找不到模块 'ADT'。
  已配置的仓库：eco:zef:https://360.zef.pm, local:.
  提示：
    · 用 `raku-pm repos list` 看当前挂了哪些仓库；
    · 用 `raku-pm repos add rea` 加上 Raku 生态存档（收录更全，含历史版本）；
```

**某个索引拉不动时怎么办**（0.49.5 起统一为「降级 + 告警」，不再整条命令失败）：
解析器会把每个仓库都问一遍，所以只要有一个索引不可达，**以前就会让整条命令崩** ——
哪怕答案本来就在可达的仓库里（比如本地目录仓库）。现在分两种情形处理，都不阻断：

| 情形 | 行为 |
|------|------|
| 拉取失败，但本地有旧缓存 | 用旧缓存继续，提示「可能已过期，跑 `raku-pm repos update` 可强制刷新」 |
| 拉取失败，且从未缓存过 | 本次把它当**空索引**继续，提示「结果可能不完整」 |

两种情形都会打印一行 `⚠`，点明是哪个索引、哪个 URL。所以如果你看到
「找不到模块」**紧挨着**几行索引 ⚠，那就是「不是没有，是我这次看不到」——
配好网络/代理后重试，或 `raku-pm repos remove` 掉用不到的索引。
**它不会静默降级**：宁可多打一行警告，也不让你以为「真的没有这个包」。
（国内网络常见：`raw.githubusercontent.com` 上的 `cpan` / `rea` 连不上，
主索引 `360.zef.pm` 正常 —— 这时仍能正常安装 zef 索引里的包。）

### 各索引的字段差异

索引记录大体同构（name / version / provides / depends），但两处关键差异要处理：

- **tar 包地址**：`360.zef.pm` 给的是相对 `path`（要拼主机），REA 与 cpan 给的是
  绝对 `source-url`。代码里 `!tarball-url` 优先用 `source-url`。
- **auth 字段**：REA 有些记录顶层没有 `auth`，身份写在 `dist` 串里
  （`ADT:ver<0.5>:auth<github:timo>`）。代码里 `!auth-of` 会回退去解析 `dist`。

另外**索引缓存与解压目录都按仓库名隔离**：`rea` 和 `cpan` 两个索引都挂在
`raw.githubusercontent.com` 上（按 host 命名缓存会互相覆盖），
而同一个发行版+版本也可能同时存在于多个索引（按仓库隔离解压结果）。

## 本地目录布局

```
$RAKUPM_TARGET/                   默认 ~/.raku-pm
├── cache/                        生态索引 + 下载的 tar 包与解压目录
│   ├── index-360.zef.pm.json
│   └── dist/<发行版>/<版本>/
├── store/                        「下载下来」的包的家
│   └── <发行版名>/<版本>/          多版本共存
│       ├── META.json             raku-pm 自己的规范化元数据
│       ├── META6.json            Raku 标准元数据（CUR::Installation 只认这个）
│       ├── lib/                  源码
│       ├── resources/            资源（native 包的 .so/.dll 构建产物在这里）
│       ├── build.json            构建痕迹旁车（0.44.0 起；不计入内容指纹）
│       └── .digest               内容指纹（MD5，用于防篡改）
├── site/                         ★ 模块搜索路径：CompUnit::Repository::Installation
│   ├── precomp/                  Rakudo 管的预编译产物
│   └── dist/                     按发行版存的元数据（多版本并存）
├── installed.json                raku-pm 自己的已安装清单
└── raku-pm.lock                  锁文件
```

**为什么分 store 和 site 两层**（仿 cargo 的 `registry/cache` + `src`）：
- `store/` 是**缓存**，一次下载可反复部署，卸载后重装无需再访问仓库；
- `site/` 是**运行环境**，交给 Raku 官方的 `CompUnit::Repository::Installation`
  管理（zef 装包用的就是它），多版本由它按元数据解析。

> 早期版本这里是个平铺的 `lib/*.rakumod` 目录。**那样做是错的**——平铺目录
> 没有任何版本元数据，`use Foo:ver<1.1.0>` 会静默加载实际存在的 2.0.0。
> 详见下一节。

## 版本管理

- **多版本共存**：store 里可同时有 `JSON/1.0.0` 与 `JSON/2.0.0`；装进 `site/`
  后两个版本**都能被 `use` 到**，靠 `:ver<>` 精确选。
- **指定版本**：`install JSON --version=1.0.0`（降级也是这个命令）。
- **升级**：`upgrade JSON` 升到仓库中最高版本；`upgrade` 不带包名 = 升级**所有**
  已装包（同 `zef upgrade` / `apt upgrade` 的惯例）。
- **切到指定版本**：`upgrade JSON --version=1.0.0`。
- **降级的坑（重要）**：Raku 的 `use JSON`（不带版本约束）**永远加载最高版本**，
  这是 Rakudo CUR::Installation 的行为，raku-pm 改不了。所以装一个更旧的版本
  **默认不会让 `use` 切过去**，只会多一份并存 —— 此时命令会明确提示你。
  要让旧版真的生效：`upgrade JSON --version=1.0.0 --only`（先卸掉更高的版本），
  或在代码里写 `use JSON:ver<1.0.0>`。
- **按版本卸载**：`uninstall JSON --version=1.0.0` 只清掉那一个版本，其余保留；
  不给 `--version` 才是整包卸载（所有版本）。
- **无参数不猜**：`uninstall` / `upgrade` 的语义不含「默认对 raku-pm 自己动手」——
  卸载自己请显式写 `uninstall RakuPM`，避免少打一个参数就误删包管理器。
- **管理 raku-pm 自身**：
  - `self-upgrade [--from=<git-url>] [--dry]` —— 升级 raku-pm 自身。
    它**不依赖账本是否已记录**（raku-pm 很可能是 zef 装的、不在我们自己的账本里，
    而 `upgrade` 一上来就按账本查 `installed-version` 会直接 die "尚未安装"），
    也**不依赖是否把 RakuPM 发布到了生态索引**（目前没发布，去仓库找必死）。
    来源优先级：
      1. `--from <url>`：从指定 git 远端拉源码升级（覆盖一切）；
      2. 当前这份来自某个 git 仓库（开发者自装/自跑）→ `git pull` 该仓库 + 本地重装；
      3. 否则从默认上游 <https://gitee.com/skyter10086/raku-pm.git> 拉取升级。
    需要本机已装 Git。`--dry` 只解析、不真正替换。
    升级前会比对版本号：本地已是最新（版本一致**且** git 提交号也一致）就**跳过下载安装**；
    版本号相同但 git 提交号不同（上游被强推 / 改写历史，内容已变）则照常重装。
    `--force` 跳过所有比对、强制重装。
  - `self-remove [--dry]` —— 卸载 raku-pm 自身。比 `uninstall RakuPM` 多清几样东西：
    ① 从 CUR::Installation 摘掉发行版；② 删 `store/RakuPM/`（各版本源码快照，
    往往占大头）；③ 删 `target/bin/` 下的 `raku-pm` / `raku-pm.bat` wrapper；
    ④ 清掉账本与锁文件里的 RakuPM 条目。`--dry` 只报告会删什么、不真删。
  - **注意**：如果 zef 也曾装过 raku-pm，那份不在我们管理范围内 ——
    卸完 `raku-pm` 命令可能仍然存在（会跑 zef 装的那份），要一并清掉请用
    `zef uninstall RakuPM`。
- **版本共存 ≠ 版本冲突**：不指定版本时 `use` 拿到最高的那个；指定 `:ver<>`
  时由 Rakudo 精确匹配。

## 多版本与 `use Foo:ver<1.2.3>`

Raku 支持 `use Module:ver<1.2.3>` 这种写法，但**光有目录里有文件是不够的** ——
Raku 得知道每份文件的版本号才能做匹配。

### 平铺 lib/ 是错的（以及它错得多隐蔽）

如果装包只是把 `*.rakumod` 平铺复制到 `target/lib/`，那这个目录里
**没有任何版本元数据**。Raku 的 `CompUnit::Repository::FileSystem` 只能从文件
路径推出模块名（`lib/Foo/Bar.rakumod` → `Foo::Bar`），推不出版本，于是
`:ver<>` 约束会被无条件满足：

```
lib/ 里实际是 2.0.0
> use MultiVer:ver<1.1.0>
我是 2.0.0          ← 不报错，静默给了错的版本
```

这是最糟的一类失败：**不报错，只是给你错的**。

### 正确做法：CompUnit::Repository::Installation

zef 装包用的就是它（`site` / `home` / `vendor` 都是这种仓库）。它按「发行版」
存元数据，同一模块的多个版本可以并存，`use Foo:ver<1.1.0>` 由 Rakudo 自己解析，
挑不到就明确报错。raku-pm 现在把包装进 `$RAKUPM_TARGET/site/`：

```raku
my $cur  = CompUnit::Repository::Installation.new(prefix => $target.add('site'));
my $dist = Distribution::Path.new($store-dir, :meta-file($store-dir.add('META6.json')));
$cur.install($dist, :force);       # :precompile 默认开，预编译由 Rakudo 管
```

于是：

```
$ raku-pm install Concurrent::Stack --version=1.1
$ raku-pm install Concurrent::Stack            # 再装个 1.3

$ raku-pm installed
    Concurrent::Stack 1.1
  * Concurrent::Stack 1.3
（* = 不指定版本时 use 会拿到的那个）

$ raku -I"inst#$HOME/.raku-pm/site" -e 'use Concurrent::Stack:ver<1.1>; ...'
$ raku -I"inst#$HOME/.raku-pm/site" -e 'use Concurrent::Stack:ver<9.9>; ...'
===SORRY!=== Could not find Concurrent::Stack:ver<9.9> in: ...
```

### 两个关键细节

**1. `inst#` 前缀不能省。** 少写它，Rakudo 会把 `site/` 当成普通文件仓库，
多版本元数据就白存了。让 `raku-pm env` 帮你生成：

```bash
$ raku-pm env
# bash / zsh / Git Bash：
export RAKULIB="inst#C:\Users\...\.raku-pm\site"
# PowerShell：
$env:RAKULIB = "inst#C:\Users\...\.raku-pm\site"
```

**2. store 里要多写一份标准 META6.json。** CUR::Installation 只认它，且它的
`provides` 是「模块名 => 相对路径」，比我们自己的 META.json 多一样东西。
麻烦在于 `RakuPM::Distribution.provides` 只保存了模块名列表 —— 路径在解析生态
索引时就被丢掉了 —— 所以入库时要**扫一遍 `lib/` 把路径反推回来**
（`Foo::Bar` → `lib/Foo/Bar.rakumod`，`.pm6` 也认；注意 `.rakudoc` 是文档不是模块，不计），
并且统一用正斜杠（Windows 的反斜杠会让 `Distribution::Path` 拼错路径）。
provides 里写了但文件不存在的模块会被跳过 —— 写进去只会让安装失败。

> 这一对反向操作现在都归 `RakuPM::Distribution`：
> `provides-with-paths`（模块名 → 路径）与 `scan-provides`（扫 `lib/` → 模块名）。
> 它们原先是 `Store` 的私有实现（且只有单向前者），上移后消费侧（入库写
> META6.json）与将来的生产侧（`refresh` / `check` / `dist`）共用一份实现。


### 与 zef 共存：同名包两个版本怎么办

zef 和 raku-pm 各有各的安装地盘（zef 装进 `~/.raku` 和 rakudo 的 site/，
raku-pm 装进 `$RAKUPM_TARGET/site/`），Raku 的多版本机制让它们**天然并存、
互不覆盖** —— 同一模块的两个版本可以同时存在，用 `:ver<>` 精确挑。

仓库链的顺序（实测）：

```
RAKULIB 里的条目（inst#<target>/site ← raku-pm 的包在这）
  → ~/.raku                （zef home）
  → rakudo 的 site / vendor / core
```

所以只要你 export 了 `RAKULIB`（`raku-pm env` 生成），脚本里：

| 写法 | 加载谁 |
| --- | --- |
| `use Foo;` | **raku-pm 装的那份**（RAKULIB 排最前，链上第一个命中） |
| `use Foo:ver<0.1.0>;` | zef 装的 0.1.0（raku-pm site 没有这个版本，落到下一站） |

不设 `RAKULIB` 则完全看不到 raku-pm 的包，一切照旧走 zef。

排查用 `raku-pm version Foo`：它把两个管理器装的版本一起列出来，
并标出「激活」的是哪份（不指定版本时 `use Foo` 实际加载的那个）。

**更直接的工具：`raku-pm which`（0.48.0）。** 上面那句「链上第一个命中」听着简单，
但你机器上通常**不止两个仓库** —— 实测这台三层都不止：

| 仓库 | 路径 | 发行版数（实测） |
| --- | --- | --- |
| home | `~/.raku` | 69 |
| rakudo 的 site（zef 装的） | `<rakudo>/share/perl6/site` | 113 |
| raku-pm 的 site | `$RAKUPM_TARGET/site` | 12 |

实测**有 24 个发行版存在于多个仓库**（其中 `HTTP::Tiny`、`JSON::Fast`、`MIME::Base64`
连版本都不一样）。同时 `PATH` 上还可能有 home 优先于 site 的效应：不设 RAKULIB 时
`use JSON::Fast` 命中的是 home 的 0.20.1，而不是 site 的 0.19。

所以别靠推算：

```bash
raku-pm which JSON::Fast     # 这个模块实际从哪加载、版本多少；多份全列出
raku-pm which                # 跨仓库冲突总览（哪些包在多个仓库里、各自什么版本）
```

`which` 给【模块名】（如 `JSON::Fast`）而不是发行版名；不带参数时按仓库链序号
列出全部冲突，序号越小越优先。

一个容易混淆的地方：**「包重名」和「命令重名」是两件事**。上面讲的是前者
（同一个模块装在多个仓库）。后者是 `PATH` 上有多份 `raku-pm` 可执行文件 ——
Windows 用 `PATHEXT` 解析，`.EXE` 优先于 `.BAT`，于是 zef 时代留下的
`<rakudo>/site/bin/raku-pm.exe` 会**遮蔽** raku-pm 自己写的 bash/`.bat` wrapper，
表现是「升级成功了，敲 `raku-pm version` 还是旧版」。0.48.0 起安装/升级会做
**入口体检**：算出实际会被执行的那一份，若不是 raku-pm 写的就改名备份为
`<名字>.zef-old`（可逆），并打印说明。`raku-pm env` 也会把候选按**系统实际解析
顺序**列出，并标出哪一份真的会被执行。

**设计说明：为什么不需要单独的「本地包索引」**。三层结构各司其职：

1. `installed.json`（账本）——已装包的本地索引：名字、全部版本、provides、
   指纹、**来源目录**（自装/git 的包会记录从哪来）。依赖解析查它（O(1)），
   `installed` / `version` 展示它；
2. `site/` 本身是 CUR::Installation——Rakudo 用 `short/`+`dist/` 维护
   自增索引，`use` 的解析直接用，不需要任何遍历；
3. `store/`——源码缓存，任何已装包都能取回完整源码（重装不用重新下载）。

「每次遍历目录」既不必要也不够用：遍历只能发现「目录里有什么」，
而依赖解析要的是「已装了什么、版本是否满足」——这正是账本的职责。
另有一个显式的 `local:` 仓库（`RAKUPM_REPO` 指向的目录，布局
`repo/包名/META6.json`）用于「一堆本地包当仓库用」的场景，按需扫描。


## 锁文件

`raku-pm.lock` 记录精确版本 + 内容指纹：

```json
{
  "version": 1,
  "entries": [
    { "name": "JSON", "version": "2.0.0", "auth": "demo:raku",
      "digest": "d47078e2...", "depends": [] }
  ]
}
```

- 普通 `install` 会**自动更新**锁；
- `--locked` 开启**严格模式**：锁与解析结果不符则直接报错，适合 CI。

### 可提交锁文件（0.54.0）

锁文件默认写在**当前工作目录**的 `raku-pm.lock`（仿 Cargo.lock），所以可以随项目
提交进版本库，实现「换台机器 / 换时间装出完全一样的版本」：

```bash
cd my-project
raku-pm install JSON            # 解析后把精确版本钉进 ./raku-pm.lock
git add -f raku-pm.lock         # 提交（默认被 .gitignore 忽略，需 -f 强制加入）
# 队友克隆后：
raku-pm install --locked        # 严格复用锁里的版本；锁缺失 / 漂移直接报错
```

- 锁描述的是**项目的依赖闭包**，与安装位置（`--target`）无关：即使把包装进
  `.raku-env` 这种独立前缀，锁仍写在项目根 —— 提交的是锁、不是前缀。
- `--lock-file=<路径>` 可把锁改到任意位置（CI 里常钉死到仓库固定路径）。
  `install` / `reinstall` / `self-upgrade` / `lock` 都认这个旗标。
- `raku-pm lock` 查看当前锁内容。
- 注意：默认 `.gitignore` 忽略了 `raku-pm.lock`（避免开发残留污染），要提交可复现
  锁请用 `git add -f`，或在你项目的 `.gitignore` 加 `!raku-pm.lock` 取消忽略。

## 并发：跨进程文件锁

一次安装是「读 `raku-pm.lock` → 解析依赖 → 写 store → 装进 site → 回写锁文件」
这一长串写操作，两个 raku-pm 同时跑会互相踩：

- 同时往 store 放同一个版本 → 留下半份文件，指纹对不上，之后 `verify` 必失败；
- 同时回写 `raku-pm.lock` → 后写的把先写的整份冲掉，装过的信息凭空消失；
- 同时 promote bin / 装进 site → wrapper 指向还没写完的路径。

所以所有**写命令**（`install` / `uninstall` / `upgrade` / `fetch` / `self-upgrade` /
`repos add|remove|update`）都会先拿一把跨进程文件锁，别的 raku-pm 只能排队：

```
$ raku-pm install Foo          # 另一个终端同时装别的包
⏳ 另一个 raku-pm 正在写入 /home/user/.raku-pm，等待它结束…
```

细节（都在 `RakuPM::FileLock`）：

- **用 flock，不是「锁文件存在就算锁住」**：进程被 kill、Ctrl+C、机器重启时锁由
  操作系统回收，不会留下需要手工清理的陈旧锁。锁文件是 `目标目录/.raku-pm.run.lock`，
  里面不存状态，只在同一目录的 `.owner` 旁路文件里写「谁、在干什么、什么时候开始的」
  —— 因为 Windows 的 LockFileEx 是**强制锁**，持锁期间连读锁文件本身都会被拒。
- **超时而不是无限等**：默认最多等 600 秒（`RAKUPM_LOCK_TIMEOUT` 可调），
  等不到就明确报错并说明是谁在占着，不卡死。
- **同一进程可重入**：`install` 内部还会调 `install` / `upgrade`，靠引用计数管理，
  只有最外层 release 才真正 unlock —— 否则嵌套释放会把外层的锁提前交出去。
- **持锁期间给子进程下「凭证」**：包的 Build.pm 里再调 `raku-pm install X` 是常态，
  那种子进程不该等自己父进程手里的锁（会自锁到超时）。做法是持锁时下发一个随机
  token（写进锁旁的 `.token` 文件 + 环境变量 `RAKUPM_LOCK_TOKEN`），子进程回来时
  必须同时满足「盘上 token 一致」**且**「锁**此刻**确实被占」才免锁放行 ——
  凭证随锁作废，父进程一放锁，晚到的子进程就老实排队；另一个终端手动跑的
  raku-pm 根本没有这张凭证，同样排队。
  （0.44.0 之前这里用的是「持锁就广播 `RAKUPM_NO_LOCK=1`」——那等于**给所有人
  开门**：任何继承了该变量的进程都自动拿到免锁权限，连在锁内跑的测试都把锁
  当没加，断言恒真。）
- **逃生舱**：`--no-lock` 或 `RAKUPM_NO_LOCK=1` 完全跳过锁 —— 并发写会损坏
  store 与锁文件，只在确认没有别的 raku-pm 在跑时用。这是**用户**显式要求的旁路，
  与上面的子进程凭证是两回事：它不校验任何东西，设了就生效（所以别写进自动化）。

顺带一个同源问题：生态索引缓存（10MB 上下）以前是 `$cache.spurt($text)` 直接写，
两个进程同时刷新会交错写出半份 JSON，而受害者是**下一次**命令（现场已消失，极难排查）。
现在改成写临时文件 + `rename` 覆盖（同一分区上 rename 是原子的），读者只会看到
旧文件或新文件。

## 测试并发（0.38.0）

安装时跑 `t/` 下的测试，**默认并发**执行：每个测试文件一个独立的 `raku` 子进程
（进程隔离，但不是沙箱），并发度 `auto = min(CPU 核数, 测试文件数, 8)`。并发只加速、
不改变单个测试的结果。

```
$ raku-pm install Foo
  · 运行测试：Foo 0.1.0（3 个文件，并发 3）
    ✓ 01-basic.rakutest
    ✗ 02-race.rakutest
    | Failed test 'concurrent push' at …/02-race.rakutest line 12
    ↻ 串行复验 1 个失败用例一次（并发/时序敏感的用例会偶发失败）
    ✓ 02-race.rakutest（复验通过 —— 这个用例本身不稳定）
```

几个要点（0.38.3 起作为【定型默认值】， intentional defaults）：

- **① 并发度默认 `auto`**：`auto = min(CPU 核数, 测试文件数, 8)`，上限 8 防止把
  机器打满；`--test-jobs=N`（`1`=纯串行）或 `RAKUPM_TEST_JOBS` 可显式指定。
- **② 日志位置默认随安装目标**：完整输出落
  `<目标>/log/<包名>/<版本>/<测试文件>.log`（`<目标>` 默认 `~/.raku-pm`），
  **重装覆盖、无保留份数**（按「每发行版每版本每文件」天然隔离）。设
  `RAKUPM_TEST_LOG_DIR=<某目录>` 可把日志根改到全局位置（如 `~/.raku-pm`），
  便于跨 target 集中查看。
- **③ 前台只印失败首行**（唯一例外：**嵌套编译错误** —— `===SORRY!===` 外壳之后的
  最内层病因行会印最多 3 行，见 `RakuPM::Client::Tester.!failure-lines`）：完整输出落
  上面的日志文件，前台不刷屏、方便事后排查。
- **④ 超时默认 300s**：`--test-timeout=N` 或 `RAKUPM_TEST_TIMEOUT` 给每个测试文件
  设上限，超时即 `kill` 子进程并判该文件失败（仍走下面的串行复验）。
- **⑤ 实时进度（仅终端）**：跑测试时在 `stderr` 上原地刷「预热 `i/N`」「测试 `i/N`
  百分比 + 当前文件」——串行预热 + 并发执行两段可能好几分钟没有别的输出，没有进度
  会被误认为卡死。**非 TTY（管道 / 重定向 / 测试捕获）自动静默**，`stdout` 与日志
  文件零影响；`RAKUPM_TEST_PROGRESS=0` 强制关、`=1` 强制开。
- **并发失败自动串行复验一次**：时序敏感用例（如 `stress.rakutest`）会偶发失败，
  复验通过即视为 flake，不让一次概率性失败阻断安装。
- **已知平台 bug 软通过**（`Log::Async` 在 Windows 上的 `t/12-context.rakutest` 等）
  与「缺编译工具」提示逻辑保持不变，照常生效。

## 缓存回收：`raku-pm clean`

store 只增不减 —— self-upgrade 每升一次就留一份快照，升级留下的旧版本、
卸载后剩下的 store 条目、下载解压的源码包全都堆在那里。实测一台用了一段
时间的机器：**store 193M（其中 RakuPM 一个包 30 个版本）、`cache/dist` 110M**，
而真正装着的只有最新那份。

```bash
raku-pm clean                 # 试算：列出能回收什么（默认一个字节都不删）
raku-pm clean --yes           # 确认后真删
raku-pm clean --all --yes     # 连索引缓存与 git 克隆缓存一并回收
raku-pm clean --older-than=30 # 只回收 30 天没动过的
raku-pm clean --name=RakuPM   # 只看某一个发行版
```

回收四类，默认就做：

| 类别 | 是什么 | 删了会怎样 |
| --- | --- | --- |
| 旧版本快照 | store 里没被引用的历史版本 | 下次重装要重新下载/入库 |
| 入库残骸 | `store/<名>/<版本>/` 里没有 `META.json`（入库中断） | 只有清理价值 |
| 预编译产物 | store 条目里的 `.precomp` | Rakudo 按需重建 |
| 下载缓存 | `cache/dist/` 下的 tar 包与解压目录 | 下次重新下载 |

`--all` 才追加两类（重建成本是网络/克隆，默认留着）：`cache/index-*.json`
索引缓存、`git-cache/` 克隆缓存。

**安全边界**是这套东西唯一要紧的地方：只删「没有被任何地方引用」的版本，
受保护的有三类 ——

1. `installed.json` 账本里记的版本（多版本共存时 `versions` 里的全部版本）；
2. 自家 `site/`（CUR::Installation）里真实装着的版本 —— 账本可能缺记，以磁盘为准；
3. `raku-pm.lock` 锁定的版本 —— `--locked` 安装会直接复用它。

`site/` 里已装的内容不受影响（它跟 store 是两份拷贝），删掉 store 条目最坏
的结果是下次重装时重新下载，不会让已装好的包失效。删除前还有一道护栏：
只删 `$RAKUPM_TARGET` 以内的路径。

删文件不可撤销，所以**默认是试算**；执行时逐项删，某一项被占用（Windows 上
常见）不会中断整轮，最后汇总说明哪几项没删掉。

## 从零重来：`raku-pm flush`

`clean` 是**有保护**的回收（每条规则都是「什么不能删」）。要「整个推倒重装」时用
`flush`：它清掉当前前缀里 raku-pm 装过的一切，**连它自己的入口一起**。

```bash
raku-pm flush          # 试算：列出会删什么（默认一个字节都不删）
raku-pm flush --yes    # 真删
```

清的：前缀内的 `store/` `site/` `git-cache/` `cache/` `log/` `generations/` `stage/`
`bin/` `installed.json` `raku-pm.lock`，以及**前缀外**那几份自装入口
（`<rakudo>/share/perl6/site/bin` 下的 `raku-pm` / `.bat` / `.ps1`）。

**两道护栏**（这是全删命令，护栏比功能重要）：

1. 目录必须**看起来就是一份 raku-pm 前缀**（`store/`、`site/`、`installed.json`
   至少有一个），且**不是家目录本身、不是文件系统根** —— 否则直接拒绝执行。
   `--target` / `RAKUPM_TARGET` 打错一个字符时，这一条能兜住。
2. 只删**认得的条目名**，前缀里别的东西一律不动（会列出来给你看）。
   所以即使前缀跟别的文件共处一个目录，也不会误伤。

**不去动别人的东西**：zef 装的 RakuPM 不在本前缀内（要清就 `zef uninstall RakuPM`），
`<名>.exe.zef-old`（zef 入口的唯一备份）也只提示不删。

⚠ **入口会被一起清掉，所以 flush 之后就没有 `raku-pm` 命令了**。装回来：

```bash
zef install <raku-pm 仓库路径>                     # zef 装一份，它会写好入口
raku <仓库路径>/bin/raku-pm.raku install .         # 或直接用仓库里的脚本，它自己会写入口
```

`flush` 与相邻命令的分工：`clean` = 能安全回收的；`self-remove` = 只卸 raku-pm 自己；
**`flush` = 全清，为了从零重来**。刻意分成三个而不是合成一个 —— 免得有人把
`flush` 当成 `clean` 的加强版顺手敲出去。

## 与 zef 的对应关系

| raku-pm 组件 | zef 对应 | 作用 |
|---|---|---|
| `RakuPM::Distribution` | `META6.json` + `Zef::Distribution` | 发行版元数据 |
| `RakuPM::Repository` (role) | `Zef::Repository` | 包源抽象 |
| `RakuPM::Repository::Local` | `Zef::Repository::LocalCache` | 本地仓库 |
| `RakuPM::Repository::Ecosystem` | `Zef::Repository::Ecosystems` | 远程生态 |
| `RakuPM::Resolver` | `find-candidates` + `find-prereq-candidates` | 依赖解析 |
| `RakuPM::Installer` | `Zef::Service::InstallRakuDistribution` | 安装 |
| `RakuPM::Client` | `Zef::Client` | 编排 |

## 核心设计思想

### 1. 发行版 = 元数据文件（META6.json）

每个包是一个目录，根下有个 `META6.json` 描述它：

```json
{
  "name": "HTTP-Client",
  "version": "1.2.0",
  "auth": "demo:raku",
  "provides": ["HTTP::Client"],
  "depends": { "JSON": ">= 1.0.0" }
}
```

关键点：`provides`（提供哪些模块）和 `name`（发行版名）是**两个概念**。
一个发行版 `HTTP-Client` 可以提供多个模块，模块名 `HTTP::Client` 用 `::` 而非 `-`。

### 2. 仓库是可插拔的 role

`RakuPM::Repository` 是一个 role，只要实现这些方法就能成为新的包源：

```raku
method find-providers(Str $module --> List)     # 谁能提供这个模块
method all-distributions(--> List)              # 所有包
method available-versions(Str $name --> List)   # 某包的所有版本
method fetch-distribution(Str $name, Str $version)  # 物化元数据
method source-dir-for(Str $name, Str $version)  # 源码目录（本地仓库才有）
```

这就是 zef 里"新服务后端只需改 config.json 就能接入"的简化版。

注意 `source-dir-for`：**客户端不该猜仓库的内部布局**。目录名与发行版名
可以不同（如目录 `JSON2/` 里放着发行版 `JSON` 2.0.0），所以定位源码的职责
必须留在仓库内部。

### 3. 依赖解析是递归 + 拓扑排序

- **递归解析**：从目标模块出发，DFS 遍历所有依赖。
- **冲突检测**：同一模块被不同版本约束要求时，检查是否兼容。
- **循环处理**：生态数据里真有互相依赖的发行版，所以不再一发现回环就报错，
  而是记下来提示一声，拓扑排序排不动的部分按名字补在末尾（绝不静默丢包）。
- **拓扑排序**（Kahn 算法）：保证依赖先于被依赖者安装。
- **约束语义**：`>=`/`>`/`<=`/`<` 是范围；`=` 与 `==` 是**精确匹配**；
  多个约束用逗号连接是 AND 关系；`*` 或空表示任意。
- **请求串里怎么写**（`install` / `search` / `installed` / `store` 同款）：
  `Foo:ver<>=1.0>`（≥）、`Foo:ver<>1.0>`（>）、`Foo:ver<<=1.0>`（≤）、
  `Foo:ver<<1.0>`（<）、`Foo:ver<>=1.0, <2.0>`（区间）。
  `>=` 还有等价的后缀写法 `Foo:ver<1.0+>`（at-least）。
  注意串尾那个 `>` 是 phaser 的**闭合括号**，不属于约束本身。

### 4. 脚本语言安装 = 把源码交给 Raku 的仓库机制

对 Raku/Python/Perl 这类脚本语言，"安装"本质上就是把源码放进模块搜索路径。
但有版本区分的那一步不能省：raku-pm 从 `store/` 取出某个版本，交给
`CompUnit::Repository::Installation` 装进 `site/`，并在 `installed.json`
记下装过哪些版本（详见「多版本与 `use Foo:ver<1.2.3>`」一节）。

### 5. 内容指纹（借鉴 nix 的内容寻址）

每个入 store 的包会计算 MD5 指纹，覆盖 `META.json` + 全部 `lib/` 文件：

- 内容变 → 指纹变 → 能发现缓存被篡改；
- `verify` 命令批量校验，`install` 前也会自动校验，不通过则拒绝安装。

这与 nix 的 `/nix/store/<hash>-name` 思路同源，只是简化为"校验"而非"寻址"。
