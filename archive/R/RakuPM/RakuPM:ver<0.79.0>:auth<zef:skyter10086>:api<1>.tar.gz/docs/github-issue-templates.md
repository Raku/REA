# GitHub Issue 拆单模板（可直接复制）

下面按当前重构路线图给出 9 个 Issue 模板。  
每个 Issue 对应一个 PR，可直接粘贴到 GitHub。

---

## Issue 1：文档拆分与快速上手

**标题**
- `refactor(docs): split README and add quickstart`

**标签**
- `docs`
- `refactor`
- `M1`

**正文**

### 目标
降低新用户上手成本，把 README 拆成“快速入口 + 深度文档”。

### 改动范围
- `README.md`
- `README.en.md`
- `docs/quickstart.md`（新增）
- `docs/architecture.md`（新增）

### 任务
- [ ] README 只保留项目介绍、安装、最小用法
- [ ] 架构/锁文件/世代/平台差异迁移到 `docs/architecture.md`
- [ ] 新增 `docs/quickstart.md`
- [ ] 中英文文档同步
- [ ] `tools/run-suite.raku --precommit` 通过

### 验收标准
- [ ] 新用户只看 README 可快速跑通核心安装
- [ ] 原有内容不丢失，只是位置迁移
- [ ] 文档一致性检查通过

---

## Issue 2：CLI 元数据声明化

**标题**
- `refactor(cli): extract command spec metadata`

**标签**
- `cli`
- `refactor`
- `M1`

**正文**

### 目标
把 CLI 从“大入口”改成“可维护的声明式结构”。

### 改动范围
- `bin/raku-pm.raku`
- `lib/RakuPM/CliSpec.rakumod`（新增）
- `lib/RakuPM/CliAlias.rakumod`（可选）

### 任务
- [ ] 抽取 `%CMD_FLAGS`
- [ ] 抽取 `%CMD_ALIASES`
- [ ] 抽取命令分组/写锁需求/联网需求
- [ ] CLI 仅保留解析、校验、派发

### 验收标准
- [ ] `completions` 输出不变
- [ ] `help` 输出不变
- [ ] 新增 flag 只改声明表

---

## Issue 3：用户面消息层收口

**标题**
- `refactor(cli): unify user-facing message style`

**标签**
- `cli`
- `ux`
- `M1`

**正文**

### 目标
统一 warn/error/hint 风格，统一退出码语义。

### 改动范围
- `lib/RakuPM/Message.rakumod`（新增）
- CLI 高频提示
- `doctor/verify/native` 相关输出

### 任务
- [ ] 建立消息层
- [ ] 迁移 CLI 校验报错
- [ ] 迁移 doctor/verify 输出
- [ ] 统一退出码说明

### 验收标准
- [ ] 常见提示风格一致
- [ ] 退出码语义兼容
- [ ] 不改变命令核心行为

---

## Issue 4：作者侧 tutorial 文档

**标题**
- `docs(authoring): add end-to-end publish tutorial`

**标签**
- `docs`
- `authoring`
- `M2`

**正文**

### 目标
让作者侧流程（new → refresh → check → dist → publish）可教、可复现。

### 改动范围
- `docs/authoring.md`（新增）
- `examples/minimal-dist/`（新增）

### 任务
- [ ] 编写作者侧端到端文档
- [ ] 提供最小示例仓库
- [ ] 验证 publish 到本地仓库流程

### 验收标准
- [ ] 用户按文档可独立完成本地发布
- [ ] 示例仓库可被 `raku-pm install` 安装

---

## Issue 5：依赖解析诊断命令

**标题**
- `feat(resolve): add explain/why diagnostic command`

**标签**
- `feature`
- `resolver`
- `M2`

**正文**

### 目标
让依赖解析过程可解释，不再是黑盒。

### 改动范围
- `lib/RakuPM/Resolver.rakumod`
- `lib/RakuPM/Client/Reporter.rakumod`
- CLI 命令注册

### 任务
- [ ] 新增 `resolve --explain` 或 `why` 命令
- [ ] 输出候选版本来源
- [ ] 输出淘汰原因
- [ ] 输出冲突约束

### 验收标准
- [ ] 正常安装不受影响
- [ ] 单模块可输出 explain
- [ ] 冲突依赖可输出双方信息

---

## Issue 6：HTTP 可观察性增强

**标题**
- `refactor(http): improve observability and fallback logging`

**标签**
- `http`
- `refactor`
- `M2`

**正文**

### 目标
增强 HTTP 层排障能力，明确后端选择与回落结果。

### 改动范围
- `lib/RakuPM/HTTP.rakumod`
- `lib/RakuPM/HTTP/Tinyish.rakumod`
- `lib/RakuPM/HTTP/HTTPTiny.rakumod`

### 任务
- [ ] 增加 debug 级日志
- [ ] 统一离线/缓存命中提示
- [ ] 明确失败后端与回退结果

### 验收标准
- [ ] `--offline` 输出明确
- [ ] 后端回落结果可观测
- [ ] 默认不刷屏

---

## Issue 7：平台行为矩阵与测试标签

**标题**
- `docs(platform): add platform matrix and test mapping`

**标签**
- `docs`
- `platform`
- `M3`

**正文**

### 目标
把平台差异固化到文档与测试映射中。

### 改动范围
- `docs/platform-matrix.md`（新增）
- `t/native-lib.t`
- `t/native-search-path.t`

### 任务
- [ ] 梳理 Windows/Linux/macOS 行为差异
- [ ] 建立平台行为矩阵
- [ ] 标注相关测试与平台约束

### 验收标准
- [ ] 文档与测试可一一对应
- [ ] 三平台核心规则可查

---

## Issue 8：关键链路 golden e2e

**标题**
- `test(e2e): add golden end-to-end regression flows`

**标签**
- `test`
- `e2e`
- `M3`

**正文**

### 目标
固化关键安装链路，避免单测绿、链路红。

### 改动范围
- `xt/e2e-local-install.t`（新增）
- `xt/e2e-git-install.t`（新增）
- `xt/e2e-verify.t`（新增）
- `xt/e2e-uninstall-autoremove.t`（新增）

### 任务
- [ ] 本地仓库 install + upgrade + rollback
- [ ] git URL install + 冲突
- [ ] verify --fix 边界
- [ ] uninstall + autoremove

### 验收标准
- [ ] 四条 e2e 稳定通过
- [ ] 可本地重复执行
- [ ] 全量 suite 通过

---

## Issue 9：InstallContext 收敛安装参数

**标题**
- `refactor(installer): consolidate install options into context`

**标签**
- `refactor`
- `installer`
- `M3`

**正文**

### 目标
降低 install/uninstall/reinstall/self-upgrade 参数传递复杂度。

### 改动范围
- `lib/RakuPM/InstallOptions.rakumod`
- `lib/RakuPM/Client.rakumod`
- install 相关入口

### 任务
- [ ] 建立统一 InstallContext
- [ ] 收敛 dry/force/no-test/no-build/no-native-check/pin 等策略
- [ ] 逐步替换零散布尔传参

### 验收标准
- [ ] 现有安装命令行为不变
- [ ] 新增策略只改 context 定义
- [ ] 测试覆盖关键路径
