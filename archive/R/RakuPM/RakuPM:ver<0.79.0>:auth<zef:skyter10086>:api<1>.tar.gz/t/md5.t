use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::MD5;

# 内置 MD5 的正确性：RFC 1321 官方测试向量。
# Store 的内容指纹全靠它，算错一个位所有 store 条目的指纹就全变了
# （老条目 verify 会集体失败）—— 所以向量必须钉死在这里。

my @vectors = (
    '',                              'd41d8cd98f00b204e9800998ecf8427e',
    'a',                             '0cc175b9c0f1b6a831c399e269772661',
    'abc',                           '900150983cd24fb0d6963f7d28e17f72',
    'message digest',                'f96b697d7cb7938d525a2f31aaf161d0',
    'abcdefghijklmnopqrstuvwxyz',    'c3fcd3d76192e4007dfb496cca67e13b',
    '1234567890' x 8,                '57edf4a22be3c955ac49da2e2107b67a',
);

for @vectors -> $input, $expect {
    is md5-hex($input), $expect,
       "RFC 1321 向量：「{$input.chars > 20 ?? $input.substr(0,20) ~ '…' !! $input}」";
}

# Blob 入口（Store 实际用的形态）
is md5-hex('abc'.encode('utf-8')), '900150983cd24fb0d6963f7d28e17f72',
   'Blob 入口与 Str 入口结果一致';

# 多块消息（>64 字节，覆盖跨块处理与长度字段的 64 位小端）
is md5-hex('raku-pm' x 40), md5-hex('raku-pm' x 40), '同输入两次结果稳定';

# ---- 非 Windows 分支不能引用 Distrib 上不存在的方法（回归）----
#
# 曾经 system-md5 里写 `$*DISTRO.is-macosx`：Windows 上 is-win 为真、elsif
# 直接短路，那行永远执行不到，于是全套测试全绿；一换到 Linux/macOS 就
# 「No such method 'is-macosx' for invocant of type 'Distro'」，直接崩在
# md5-file 里 —— 而 md5-file 是 Store 算内容指纹的必经之路。
#
# 这里用 `my $*DISTRO` 遮蔽动态变量（Raku 的动态查找是运行期的），
# 让 Windows 开发机也能真实走进 linux / macosx 两个分支。
{
    # ≥64KB 才会走系统 md5 命令那条路（小于它是纯 Raku 直通）
    my $blob   = ('raku-pm-md5' x 10000).encode('utf-8');
    my $big    = $*TMPDIR.add('rakupm-md5-big-' ~ $*PID ~ '.bin');
    $big.spurt($blob, :bin);
    LEAVE { $big.unlink if $big.e }

    ok $big.s >= 64 * 1024, "临时大文件够大（{$big.s} 字节 ≥ 64KB，会走系统命令分支）";

    my $expect = md5-hex($blob);   # 纯 Raku 结果即标准答案

    for <linux macosx> -> $dname {
        my $*DISTRO = Distro.new(:name($dname));
        # 先确认遮蔽真的生效了 —— 否则下面两条断言等于没跑，会假绿
        is $*DISTRO.name, $dname, "遮蔽 \$*DISTRO 生效（name=$dname）";

        my $got  = '';
        my $err  = '';
        {
            $got = try { md5-file($big) } // '';
            $err = $!.Str if $!;
        }
        ok !$err.chars,
           "\$*DISTRO.name=$dname 时 md5-file 不抛异常" ~ ($err.chars ?? "：$err" !! '');
        is $got, $expect,
           "\$*DISTRO.name=$dname 时指纹与纯 Raku 一致（系统命令不可用也能回退）";
    }
}

done-testing;
