use Test;
use RakuPM::Version;
use RakuPM::Distribution;

# 用 done-testing：用例按场景分块，写死数量容易对不上（曾踩过）。

# 版本解析
my $v = RakuPM::Version.from-string("1.2.3");
is $v.major, 1, 'major';
is $v.minor, 2, 'minor';
is $v.patch, 3, 'patch';

# 约束匹配
ok RakuPM::Version.from-string("1.2.0").satisfies(">= 1.0.0"), '>= 满足';
ok RakuPM::Version.from-string("1.5.0").satisfies(">=1.0.0, <2.0.0"), '区间约束';
nok RakuPM::Version.from-string("0.9.0").satisfies(">= 1.0.0"), '不满足 >=';
ok RakuPM::Version.from-string("0.0.1").satisfies("*"), '通配符';

# 版本挑选
my $best = RakuPM::Version.new.pick-best(">= 1.0.0", <0.9.0 1.0.0 1.5.0 2.0.0>);
is $best, "2.0.0", 'pick-best 选最高满足版本';

# --- 生态索引里的脏版本号（回归：曾把 "v0.2" 丢给 + 直接抛异常） ---
my $v2 = RakuPM::Version.from-string("v0.2");
is $v2.major, 0, 'v 前缀：major';
is $v2.minor, 2, 'v 前缀：minor';
is RakuPM::Version.from-string("v1.2.3").patch, 3, 'v 前缀：patch';
is RakuPM::Version.from-string("2rc1").major, 2, '非数字尾巴退化为该段数字';
is RakuPM::Version.from-string("").major, 0, '空串不抛异常';
ok RakuPM::Version.from-string("v0.2").satisfies("0.2+"), 'v 前缀版本照常参与约束匹配';

# pick-best 必须返回仓库里的「原始串」，否则 0.2 会被归一成 0.2.0 而对不上
is RakuPM::Version.new.pick-best("0.2+", <0.1 0.2 0.3>), "0.3",
   'pick-best 返回原始版本串';

# ===== zef 风格安装规格串的解析（Foo:ver<1.2.3>:auth<x> / Foo@1.2.3）=====
# 这是 identity() 的逆操作，用于 `raku-pm install 'Foo:ver<1.2.3>'`
{
    my %h = RakuPM::Distribution.parse-spec('Foo::Bar');
    is %h<module>, 'Foo::Bar', '纯模块名：module 原样';
    is %h<ver>,  '',           '纯模块名：ver 为空';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3>');
    is %h<module>, 'Foo::Bar', ':ver<>：模块名不带 phaser';
    is %h<ver>,    '1.2.3',    ':ver<>：版本取到';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3+>');
    is %h<ver>, '1.2.3+', ':ver<>：zef 的 + 后缀（至少）保留下来';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3>:auth<zef:x>');
    is %h<ver>,  '1.2.3',  '多个 phaser：ver 对';
    is %h<auth>, 'zef:x',  '多个 phaser：auth 对';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3>:auth<zef:x>:api<1>');
    is %h<auth>, 'zef:x', '三个 phaser：auth 对';
    is %h<api>,  '1',     '三个 phaser：api 对';

    # @ 简写归一成 :ver<>
    %h = RakuPM::Distribution.parse-spec('Foo::Bar@1.2.3');
    is %h<module>, 'Foo::Bar', '@ 简写：模块名对';
    is %h<ver>,    '1.2.3',    '@ 简写：等价于 :ver<1.2.3>';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar@1.2.3+');
    is %h<ver>, '1.2.3+', '@ 简写：+ 后缀保留';

    # 只有 auth 没有 ver 也要能解析
    %h = RakuPM::Distribution.parse-spec('Foo::Bar:auth<zef:x>');
    is %h<module>, 'Foo::Bar', '只给 auth：模块名对';
    is %h<ver>,    '',         '只给 auth：ver 为空';
    is %h<auth>,   'zef:x',    '只给 auth：auth 对';

    # 模块名里的 :: 不能被当成 phaser（这是最容易写错的地方）
    %h = RakuPM::Distribution.parse-spec('Foo::Bar::Baz:ver<1.0>');
    is %h<module>, 'Foo::Bar::Baz', '深层模块名 :: 不会被误判成 phaser';
    is %h<ver>,    '1.0',           '深层模块名 + :ver<> 正常';
}

# 版本排序（统一入口 sort-versions）
# 回归：installed 的 zef 侧展示曾用 .unique.sort（字典序），
# 把 0.9.2 排到 0.13.0 后面 —— 与 raku-pm 账本侧（semver）不一致。
{
    my @in  = <0.9.2 0.13.0 0.10.0 0.2.0>;
    my @got = RakuPM::Version.new.sort-versions(@in);

    is @got.join(', '), '0.2.0, 0.9.2, 0.10.0, 0.13.0',
       'sort-versions 按 semver 升序（不是字典序）';

    # 排序结果的最高版本必须是 semver 意义上的最高
    is @got[*-1], '0.13.0', '取末位得到 semver 最高版本（字典序会错成 0.9.2）';

    # 去重 + 去空串
    my @dup = RakuPM::Version.new.sort-versions(['1.0.0', '', '1.0.0', '0.1.0', Str]);
    is @dup.join(', '), '0.1.0, 1.0.0', 'sort-versions 去重并去掉空版本串';

    # 单元素 / 空输入不能炸
    is RakuPM::Version.new.sort-versions(['2.0.0']).join(','), '2.0.0', '单元素正常';
    is RakuPM::Version.new.sort-versions([]).elems, 0, '空输入返回空列表';
}

# ===== ^ / ~ 糖语法与范围（uninstall --version 范围卸载）=====
ok RakuPM::Version.from-string("1.5.0").satisfies("^1.0"),  '^1.0 兼容区间：含 1.5.0';
ok RakuPM::Version.from-string("1.0.0").satisfies("^1.0"),  '^1.0 含下界 1.0.0';
nok RakuPM::Version.from-string("2.0.0").satisfies("^1.0"), '^1.0 不含 2.0.0（上界开）';
nok RakuPM::Version.from-string("0.9.0").satisfies("^1.0"), '^1.0 不含 0.9.0';
ok RakuPM::Version.from-string("0.2.5").satisfies("^0.2.3"), '^0.2.3 锁 minor：含 0.2.5';
nok RakuPM::Version.from-string("0.3.0").satisfies("^0.2.3"), '^0.2.3 不含 0.3.0';
ok RakuPM::Version.from-string("0.0.3").satisfies("^0.0.3"), '^0.0.3 锁 patch：含 0.0.3';
nok RakuPM::Version.from-string("0.0.4").satisfies("^0.0.3"), '^0.0.3 不含 0.0.4（上界开）';

ok RakuPM::Version.from-string("1.2.3").satisfies("~1.2.3"), '~1.2.3 含下界';
ok RakuPM::Version.from-string("1.2.9").satisfies("~1.2.3"), '~1.2.3 含 1.2.9';
nok RakuPM::Version.from-string("1.3.0").satisfies("~1.2.3"), '~1.2.3 不含 1.3.0';
ok RakuPM::Version.from-string("1.2.5").satisfies("~1.2"),   '~1.2 含 1.2.5';
ok RakuPM::Version.from-string("1.5.0").satisfies("~1"),     '~1 锁 major：含 1.5.0';
nok RakuPM::Version.from-string("2.0.0").satisfies("~1"),     '~1 不含 2.0.0';

# 区间 / 范围（卸载一批）
ok RakuPM::Version.from-string("0.9.0").satisfies("<1.0"),       '<1.0 含 0.9.0';
nok RakuPM::Version.from-string("1.0.0").satisfies("<1.0"),       '<1.0 不含 1.0.0（开区间）';
ok RakuPM::Version.from-string("1.2.0").satisfies(">=1.0, <2.0"), '区间 >=1.0,<2.0 含 1.2.0';
nok RakuPM::Version.from-string("2.0.0").satisfies(">=1.0, <2.0"), '区间不含上界 2.0.0';

done-testing;
