use lib 'lib';
use Test;
use RakuPM::HTTP;
use RakuPM::HTTP::HTTPTiny;
use RakuPM::HTTP::Backend;

# 钉死三个「后端 ↔ HTTP 客户端 / 语言行为不匹配」的回归（都是 0.36.20 修的）：
#
#   1) If-None-Match 必须真的出现在【请求头】里。曾经把 headers 塞进 .new()，
#      而 HTTP::Tiny / HTTP::Tinyish 的构造选项叫 default-headers，headers 被
#      静默丢弃 → 条件 GET 空转，TTL 一过就全量重下 10~18MB 的索引。
#      只有 .get($url, headers => …) 才会真的发出去。
#   2) Tinyish 的超时必须真的生效。曾经传 max-time（实际选项是 timeout）→
#      curl 没有 --max-time，链路一停流就无限挂（Windows / WSL 都一样）。
#   3) 后端加载不了时要【回落到下一个后端】。曾经用 `~~ Failure` 判断 try 的
#      结果，而本 Rakudo 的 try 失败返回的是 Nil → 守卫永不命中 → 直接崩。
#
# 全程走 127.0.0.1 本地假服务器，不触网。端口绑不上（受限沙箱 / CI 无 loopback
# 监听权限）时整文件 skip —— 不能把 zef install 的测试阶段搞挂。

plan 10;

sub inm-seen(@seen --> Bool) { so @seen.first({ $_ ~~ /:i 'If-None-Match' / }) }

# 绑一个本地监听端口（多试几个，避开占用 / 权限问题）
sub bind-server(Int $from, Int $to) {
    for $from .. $to -> $port {
        my $s = try { IO::Socket::INET.new(:localhost('127.0.0.1'), :localport($port), :listen) };
        next if $s ~~ Failure || !$s.defined;
        return ($s, $port);
    }
    Nil
}

my ($sock, $port) = bind-server(18910, 18940) // (Nil, 0);
unless $sock.defined {
    skip('无法绑定本地端口（受限环境），跳过线级 HTTP 用例', 10);
    exit 0;
}

# 一个接受循环服务所有用例：
#   $mode='304' → 回 304 并记录请求头；$mode='200' → 回 200 + hello；
#   $mode='slow' → 先睡 3s 再回 200（验证调用侧超时，且不留永久卡死的线程）；
#   $mode='hang' → accept 后永不响应（把 sleep 丢进子线程，接受循环还能继续接）
my $mode = '304';
my @seen;
my @hangs;
my $server = start {
    while (my $conn = try { $sock.accept }) {
        if $mode eq 'hang' { @hangs.push($conn); start { sleep 120 }; next }
        my @lines;
        while (my $line = $conn.get) {
            last if $line.chomp eq '';
            @lines.push($line.chomp);
        }
        @seen.push(|@lines);
        sleep 3 if $mode eq 'slow';
        if $mode eq '304' {
            $conn.print("HTTP/1.1 304 Not Modified\r\n"
                      ~ "ETag: \"v1\"\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
        }
        else {
            $conn.print("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nConnection: close\r\n\r\nhello");
        }
        try $conn.close;
    }
}
sleep 0.3;
END { try $sock.close }

# ---------- 1~2) HTTPTiny 的条件 GET ----------
{
    my $be = RakuPM::HTTP::HTTPTiny.new(:max-time(10));
    my $resp = $be.get-text-conditional("http://127.0.0.1:$port/x", :if-none-match('v1'));
    sleep 0.3;
    ok inm-seen(@seen), 'HTTPTiny：If-None-Match 真的出现在请求头里（不能塞进 .new）';
    ok $resp.not-modified, 'HTTPTiny：304 被识别为「未修改」';
}

# ---------- 3~4) Tinyish 的条件 GET ----------
unless (try { require RakuPM::HTTP::Tinyish; True }) // False {
    skip('未安装 HTTP::Tinyish，跳过 Tinyish 用例', 8);
    exit 0;
}
{
    @seen = ();
    my $be = RakuPM::HTTP::Tinyish.new(:max-time(10));
    my $resp = $be.get-text-conditional("http://127.0.0.1:$port/y", :if-none-match('v1'));
    sleep 0.3;
    ok inm-seen(@seen), 'Tinyish：If-None-Match 真的出现在请求头里（不能塞进 .new）';
    ok $resp.not-modified, 'Tinyish：304 被识别为「未修改」';
}

# ---------- 5~6) 后端加载不了 → 回落到下一个后端（不能整个请求崩） ----------
{
    $mode = '200';
    RakuPM::HTTP.register-backend('bogus-nope', 'No::Such::Module');
    my $h = RakuPM::HTTP.new(:order('bogus-nope,httptiny'), :attempts(1), :base-delay(0.001));
    my $r = try { $h.get-text("http://127.0.0.1:$port/fallback") };
    ok $r.defined, '后端加载失败时不崩（要回落到下一个后端，而不是整个请求失败）';
    is($r // '', 'hello', '回落到的 httptiny 真的把内容取回来了');
}

# ---------- 7~8) Tinyish 的超时真的生效 ----------
{
    $mode = 'hang';
    my $t0 = DateTime.now.Instant;
    my $worker = start {
        my $r = try { RakuPM::HTTP::Tinyish.new(:max-time(2)).get-text("http://127.0.0.1:$port/slow"); 'ok' };
        # 注意：本 Rakudo 的 try 失败返回的是 Nil 而不是 Failure，不能用 ~~ Failure 判
        $r.defined ?? $r !! 'err'
    };
    # 自己守一道 20s 的闸：超时若失效，是【测试失败】而不是把整个套件挂住
    for ^200 { last if $worker.status ~~ Kept; sleep 0.1 }
    my $elapsed = (DateTime.now.Instant - $t0).round(0.1);
    my $done    = $worker.status ~~ Kept;

    ok $done && $elapsed < 15, "Tinyish：停流时 2s 超时生效（实测 {$elapsed}s，未无限挂）";
    is($done ?? $worker.result !! '-', 'err', 'Tinyish：超时后后端按失败处理（不是静默成功）');
}

# ---------- 9~10) HTTPTiny 的超时（客户端自己没有，靠 !with-timeout 兜） ----------
# 这里【不】用「永不响应」的服务器：那会留下一个卡在 socket 读上的线程，实测会让
# 测试进程在退出时挂住（生产倒没事，但套件不能挂）。改成「响应很慢」的服务器 ——
# 一样能验证超时的闸，而被放弃的那个线程 3s 后会自己读完退出。
{
    $mode = 'slow';
    my $t0 = DateTime.now.Instant;
    my $worker = start {
        my $r = try { RakuPM::HTTP::HTTPTiny.new(:max-time(1)).get-text("http://127.0.0.1:$port/slow2"); 'ok' };
        $r.defined ?? $r !! 'err'
    };
    for ^100 { last if $worker.status ~~ Kept; sleep 0.1 }   # 10s 的闸
    my $elapsed = (DateTime.now.Instant - $t0).round(0.1);
    my $done    = $worker.status ~~ Kept;

    ok $done && $elapsed < 5, "HTTPTiny：响应过慢时 1s 超时生效（实测 {$elapsed}s，未无限等）";
    is($done ?? $worker.result !! '-', 'err', 'HTTPTiny：超时后按失败处理（不是静默成功）');
}

# 收尾：把还挂着的连接关掉，别让遗留线程拖住进程退出
try { .close } for @hangs;
