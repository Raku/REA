use lib 'lib';
use Test;
use RakuPM::HTTP;
use RakuPM::HTTP::Backend;

# Issue 6（HTTP 可观察性）的回归用例。
#
# 全程用【纯假后端】（不触网、不依赖 curl / HTTP::Tinyish / HTTP::Tiny），只验证
# debug 级日志的「有无」与「内容」：
#   · 默认关 → 零 http: 行（输出与现状一致，不刷屏）；
#   · 开（:$debug 或 RAKUPM_HTTP_DEBUG）→ 报出后端顺序 / 覆盖来源 / 用的哪个后端 /
#     回落 / 304 缓存命中 / 离线硬拦；
#   · 行为不变 —— 离线仍被 assert-online 硬拦。
#
# 排障行前缀统一为「  · http: 」，刻意不含 ⚠ / [RakuPM]（tools/run-suite.raku 在
# t/ 下把这两个标记当「生产级噪音」判失败），所以本文件即使 debug 开着也不会误红。

# ---------- 纯假后端 ----------
class FakeOK does RakuPM::HTTP::Backend {
    method get-text(Str $u, *%o --> Str) { 'ok-body' }
    method download(Str $u, IO::Path $d, *%o --> Nil) { $d.spurt('ok') }
    method get-text-conditional(Str $u, Str :$if-none-match = ''
                                --> RakuPM::HTTP::ConditionalResponse) {
        RakuPM::HTTP::ConditionalResponse.new(:status(200), :body('fresh'))
    }
}
class Fake304 does RakuPM::HTTP::Backend {
    method get-text(Str $u, *%o --> Str) { 'x' }
    method download(Str $u, IO::Path $d, *%o --> Nil) { $d.spurt('x') }
    method get-text-conditional(Str $u, Str :$if-none-match = ''
                                --> RakuPM::HTTP::ConditionalResponse) {
        RakuPM::HTTP::ConditionalResponse.new(:status(304))
    }
}
class FakeFail does RakuPM::HTTP::Backend {
    method get-text(Str $u, *%o --> Str) { die 'boom' }
    method download(Str $u, IO::Path $d, *%o --> Nil) { die 'boom' }
}

RakuPM::HTTP.register-backend('dbg-ok',    FakeOK.new);
RakuPM::HTTP.register-backend('dbg-304',   Fake304.new);
RakuPM::HTTP.register-backend('dbg-fail',  FakeFail.new);
RakuPM::HTTP.register-backend('dbg-bogus', 'No::Such::Module');   # 加载失败 → 不可用

# 捕获 stderr（note 走 $*ERR）的小工具。&op 若抛异常会在内部 try 掉，
# 调用方只关心抓回的 stderr 行。
sub capture-debug(&op) {
    my $log = ($*TMPDIR // '/tmp'.IO)
        .add("rakupm-dbg-{now.to-posix[0].Int}-{$*PID}-{(rand * 1e9).Int}.log");
    my $fh = $log.open(:w);
    temp $*ERR = $fh;
    try &op();
    $fh.flush;
    $fh.close;
    my @l = $log.e ?? $log.slurp.lines !! ();
    $log.unlink;
    @l;
}

plan 13;

# 1) 默认关：不产生任何 http: 行（输出与现状一致）
{
    temp %*ENV<RAKUPM_HTTP_DEBUG>;   # 确保本例不被外部环境变量打开
    my @l = capture-debug({ RakuPM::HTTP.new(:order('dbg-ok')).get-text('http://x/a') });
    ok @l.grep({ $_.contains('http:') }).elems == 0,
       '默认关：get-text 不产生 http: debug 行（不刷屏）';
}

# 2~4) :debug + 显式 order：报后端顺序、报使用的后端、不报「默认」来源
{
    my @l = capture-debug({ RakuPM::HTTP.new(:debug, :order('dbg-ok')).get-text('http://x/b') });
    ok @l.grep({ $_.contains('后端顺序 = [dbg-ok]') }).elems == 1,
       'debug：报出后端顺序';
    ok @l.grep({ $_.contains('用后端 dbg-ok 发请求') }).elems == 1,
       'debug：报出实际使用的后端';
    ok @l.grep({ $_.contains('默认 tinyish→httptiny') }).elems == 0,
       'debug：显式 order 时不报「默认」来源';
}

# 5) 覆盖来源：RAKUPM_HTTP_BACKEND 被报出（排查「为什么这次用的是 httptiny」）
{
    temp %*ENV<RAKUPM_HTTP_BACKEND> = 'dbg-ok';
    my @l = capture-debug({ RakuPM::HTTP.new(:debug).get-text('http://x/c') });
    ok @l.grep({ $_.contains('覆盖来源：RAKUPM_HTTP_BACKEND=dbg-ok') }).elems == 1,
       'debug：报出 RAKUPM_HTTP_BACKEND 覆盖来源';
}

# 6) 304 缓存命中：统一措辞
{
    my @l = capture-debug({
        RakuPM::HTTP.new(:debug, :order('dbg-304')).get-text-conditional('http://x/d', :if-none-match('v1'));
    });
    ok @l.grep({ $_.contains('304 命中本地缓存') }).elems == 1,
       'debug：条件 GET 命中缓存统一为「304 命中本地缓存（不重新下载）」';
}

# 7) 离线 + debug：明确报出 离线=ON（绝不静默联网）
{
    temp %*ENV<RAKUPM_OFFLINE> = '1';
    my @l = capture-debug({ try { RakuPM::HTTP.new(:debug, :order('dbg-ok')).get-text('http://x/e') } });
    ok @l.grep({ $_.contains('离线=ON') }).elems == 1,
       'debug：离线时明确报出 离线=ON（绝不静默改成联网）';
}

# 8) 离线行为不变：get-text 被 assert-online 硬拦
{
    temp %*ENV<RAKUPM_OFFLINE> = '1';
    my $r = try { RakuPM::HTTP.new(:order('dbg-ok')).get-text('http://x/f') };
    ok $r !~~ Str || $r eq '', '离线模式：get-text 被 assert-online 硬拦（行为不变）';
}

# 9) 回落：后端不可用 → 落到下一个可用后端（两个维度都报）
{
    my @l = capture-debug({
        RakuPM::HTTP.new(:debug, :order('dbg-bogus,dbg-ok'), :attempts(1), :base-delay(0.001))
            .get-text('http://x/g');
    });
    ok @l.grep({ $_.contains('dbg-bogus') && $_.contains('不可用') }).elems == 1,
       'debug：后端加载失败时报「不可用，落到下一个」';
    ok @l.grep({ $_.contains('用后端 dbg-ok 发请求') }).elems == 1,
       'debug：确实回落到下一个可用后端';
}

# 10) 全部后端不可用：报出「所有后端都失败：[...]」
{
    my @l = capture-debug({
        try { RakuPM::HTTP.new(:debug, :order('dbg-bogus'), :attempts(1)).get-text('http://x/h') }
    });
    ok @l.grep({ $_.contains('所有后端都失败：[dbg-bogus]') }).elems == 1,
       'debug：全部后端不可用时报出「所有后端都失败：[...]」';
}

# 11) 请求失败：仍报出所用后端（落到哪个后端可见）
{
    my @l = capture-debug({
        try { RakuPM::HTTP.new(:debug, :order('dbg-fail'), :attempts(1), :base-delay(0.001))
                  .get-text('http://x/i') }
    });
    ok @l.grep({ $_.contains('用后端 dbg-fail 发请求') }).elems == 1,
       'debug：请求失败时仍报出所用后端（便于定位落到哪个后端）';
}

# 12) 环境变量 RAKUPM_HTTP_DEBUG 也能开（无需改任何调用点）
{
    temp %*ENV<RAKUPM_HTTP_DEBUG> = '1';
    my @l = capture-debug({ RakuPM::HTTP.new(:order('dbg-ok')).get-text('http://x/j') });
    ok @l.grep({ $_.contains('http:') }).elems >= 1,
       'RAKUPM_HTTP_DEBUG=1：不开 :debug 也能打开排障（不改动调用点）';
}
