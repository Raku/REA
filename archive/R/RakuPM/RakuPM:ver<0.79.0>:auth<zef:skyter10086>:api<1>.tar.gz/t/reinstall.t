use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;
use JSON::Fast;

# reinstall 命令的回归测试（全离线：本地目录仓库，不碰网络）。
#
# 覆盖：
#   1. 已装包 reinstall → 卸掉再按【完全相同版本】装回，账本版本号不变（不被升级）；
#   2. reinstall --dry → 只打印计划，不真正卸载（状态不变）；
#   3. 完全没装过的包 reinstall → 退化为一次普通 install（落入账本）。
# 这些保证 0.53.0 新增的 reinstall 行为正确，且复用 uninstall/install 不引入回归。

my $base = $*TMPDIR.add("rakupm-reinstall-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

sub make-dist($dir, :$name, :$version, :@provides, :$test) {
    $dir.mkdir;
    $dir.add('lib').mkdir;
    for @provides -> $mod {
        my $mf = $dir.add("lib/{$mod.subst('::', '/', :g)}.rakumod");
        $mf.parent.mkdir;
        $mf.spurt("unit module $mod;\nsay 'load $mod';\n");
    }
    if $test {
        $dir.add('t').mkdir;
        $dir.add('t/basic.t').spurt(qq:to/TEST/);
            use Test;
            plan 1;
            ok True, '$name 基本测试通过';
            TEST
    }
    my %meta = name => $name, version => $version, auth => 'demo:raku',
               provides => @provides;
    $dir.add('META6.json').spurt(to-json(%meta, :sorted-keys));
}

make-dist($base.add('RePkg'),   :name('RePkg'),   :version('1.0.0'),
          :provides(['Re::Pkg']), :test);
# 一个【在仓库里、但故意不先安装】的包，专门验 reinstall 的「退化成 install」分支
make-dist($base.add('FreshPkg'), :name('FreshPkg'), :version('0.5.0'),
          :provides(['Fresh::Pkg']), :test);

# 同包两个版本（DuoPkg 1.0.0 / 2.0.0），专门验 B2：reinstall 的规格串 :ver<>
# 约束被尊重，只重装匹配版本、不动其它版本。
make-dist($base.add('DuoPkg-1'), :name('DuoPkg'), :version('1.0.0'),
          :provides(['Duo::Pkg']), :test);
make-dist($base.add('DuoPkg-2'), :name('DuoPkg'), :version('2.0.0'),
          :provides(['Duo::Pkg']), :test);

my $repo   = RakuPM::Repository::Local.new(:root($base));
my $client = RakuPM::Client.new(:target($base.add('target')), :repos([$repo]));

sub installed-versions($n) {
    # 直接用 Installer 的多版本接口（委托 Ledger.versions-of，正确合并
    # <versions> 数组与 <version> 激活版；手搓 .map(*<version>) 会漏非激活版本）。
    $client.installer.installed-versions($n).List;
}

plan 16;

# ---- 先装 RePkg ----
{
    my $ok = try { $client.install('RePkg', ''); True }
    ok $ok.defined, 'install RePkg 成功（不抛）';
    my @v = installed-versions('RePkg');
    is @v.elems, 1, '装完后账本里 RePkg 恰一条';
    is @v[0], '1.0.0', '装上的版本是 1.0.0';
}

# ---- reinstall 已装包：版本不变、状态保留 ----
{
    my $ok = try { $client.reinstall('RePkg', ''); True }
    ok $ok.defined, 'reinstall 已装包不抛异常';
    my @v = installed-versions('RePkg');
    is @v.elems, 1, 'reinstall 后账本仍恰一条 RePkg';
    is @v[0], '1.0.0', 'reinstall 后版本仍是 1.0.0（未被解析成升级）';
}

# ---- reinstall --dry：只预览，不卸载 ----
{
    my $cap;
    {
        my $*OUT = open($base.add('dry.out'), :w);
        my $ok = try { $client.reinstall('RePkg', '', :dry); True }
        ok $ok.defined, 'reinstall --dry 不抛异常';
    }
    $cap = $base.add('dry.out').slurp;
    ok $cap.contains('重装'), 'reinstall --dry 打印重装计划（含「重装」字样）';
    my @v = installed-versions('RePkg');
    is @v.elems, 1, 'reinstall --dry 后仍已装（dry 没真正卸载）';
}

# ---- reinstall 未装过的包：退化为 install ----
{
    is installed-versions('FreshPkg').elems, 0, 'FreshPkg 起初未安装';
    my $ok = try { $client.reinstall('FreshPkg', ''); True }
    ok $ok.defined, 'reinstall 未装包退化为 install 不抛异常';
    is installed-versions('FreshPkg').elems, 1, '退化 install 后 FreshPkg 落入账本';
}

# ---- B2 回归：reinstall 规格串约束被尊重（只重装匹配版本）----
{
    # 同包两个版本都装好
    $client.install('DuoPkg', '', :version('1.0.0'));
    $client.install('DuoPkg', '', :version('2.0.0'));
    my @v = installed-versions('DuoPkg');
    is @v.sort.join(','), '1.0.0,2.0.0', 'DuoPkg 两个版本都装好';

    # 只重装 2.0.0：捕获输出，断言没有重装 1.0.0。
    # 修复前（B2）这里完全忽略约束，会把 1.0.0 和 2.0.0 都重装一遍。
    my $cap;
    {
        my $*OUT = open($base.add('b2.out'), :w);
        $client.reinstall('DuoPkg', '2.0.0');
    }
    $cap = $base.add('b2.out').slurp;
    ok $cap.contains('重装 DuoPkg:ver<2.0.0>'),
       'reinstall :ver<2.0.0> 重装了 2.0.0';
    nok $cap.contains('重装 DuoPkg:ver<1.0.0>'),
       'B2 修复后：reinstall :ver<2.0.0> 不再重装 1.0.0（之前会全部重装）';

    # 两个版本都还在（reinstall 是卸一个装一个，不动另一个）
    my @after = installed-versions('DuoPkg');
    is @after.sort.join(','), '1.0.0,2.0.0', 'reinstall 后两个版本仍在（只重装匹配的）';
}
