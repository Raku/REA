use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Message;

# RakuPM::Message —— 用户面消息出口与退出码常量。
#
# 本轮（0.68.0）是【收口】：把散落 bin 里 20 多处的裸 die / note 归到统一出口，
# 且**不改任何文案、不改任何退出码** —— 那一点由探针的「stdout + stderr + exit code
# 三者逐字节比对」保证（24 个固定输入探针 × 3 类产物 = 72 个文件全 IDENTICAL）。
# 这个测试文件守的是更底层的三条契约：
#   ① 退出码常量值固定（历史就是 0/1，外部脚本已依赖；本轮刻意不拆成 2）；
#   ② die 类出口【原样】抛出传入的消息（不加前缀、不改写、不吞）；
#   ③ msg-* 只写 stderr、且【不加任何前缀】—— 一旦加了，"逐字节不变"就不成立了。

my $lib = $*PROGRAM.parent.parent.add('lib').Str;

# ---------- ① 退出码常量 ----------
is EXIT-OK,   0, 'EXIT-OK = 0（成功；含无参数打印帮助这种纯查询）';
is EXIT-FAIL, 1, 'EXIT-FAIL = 1（业务失败与用法错共用 —— 勿轻改成 2）';

# ---------- ② die 类：message 逐字原样 ----------
{
    my $caught = '<未抛出>';
    try {
        usage-die '请指定要安装的模块名';
        CATCH { default { $caught = .message } }
    }
    is $caught, '请指定要安装的模块名', 'usage-die 抛出的 message 与传入逐字一致';
}
{
    my $caught = '<未抛出>';
    try {
        fail-die '测试未通过（foo.t 失败）';
        CATCH { default { $caught = .message } }
    }
    is $caught, '测试未通过（foo.t 失败）', 'fail-die 抛出的 message 与传入逐字一致';
}

# ---------- ③ msg-* 的去向与格式 ----------
# 起真子进程，直接看真实 fd —— 比在进程内捕获更接近用户看到的实际情况。
{
    my $prog = 'use RakuPM::Message; msg-error "E"; msg-warn "W"; msg-hint "H";';
    my $p = run('raku', '-I', $lib, '-e', $prog, :out, :err);
    my $o = $p.out.slurp(:close);
    my $e = $p.err.slurp(:close);

    is $p.exitcode, 0, 'msg-* 不改变退出码（正常结束为 0）';
    is $o, '',        'msg-* 不写 stdout —— 正常输出流不被报错污染';
    is $e, "E\nW\nH\n",
       'msg-error/warn/hint 各写一行到 stderr，且【不加任何前缀】';
}

# ---------- 与 RakuPM::UI 的边界 ----------
# Message 只管「说什么」；上色是 UI 的事。这里钉住「Message 的输出里没有 ANSI 转义」，
# 否则「非 TTY / NO_COLOR 自动降级」那条约束会从 Message 这里漏出去。
{
    my $prog = 'use RakuPM::Message; msg-error "colored?"; usage-die "boom";';
    my $p = run('raku', '-I', $lib, '-e', $prog, :out, :err);
    my $all = $p.out.slurp(:close) ~ $p.err.slurp(:close);
    nok $all.contains("\e["), 'Message 的输出不含任何 ANSI 转义（上色归 RakuPM::UI 管）';
}

done-testing;
