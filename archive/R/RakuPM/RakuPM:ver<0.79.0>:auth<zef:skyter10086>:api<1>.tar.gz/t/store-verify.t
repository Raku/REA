use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Store;
use RakuPM::Distribution;

# 回归：Store.verify 必须容忍 store 目录里被 Rakudo 重新生成的 .precomp，
# 否则「装同一版本第二次」会被误报「内容已被修改」而安装失败。
# 这是 v0.27.3 修的真 bug：用户 `raku-pm install .` 重装同名版本被拦死，
# 而 Windows PowerShell 下因时序不同偶发能过。
#
# 指纹只覆盖源码（lib/META），不算 .precomp 这类派生产物；真篡改（改了
# lib 内容）仍应判 False。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try $p.rmdir }
    else    { try $p.unlink }
}

my $tmp = $*TMPDIR.add('rakupm-store-verify-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $src = $tmp.add('src').mkdir;
$src.add('lib').mkdir;
$src.add('lib/Foo.rakumod').spurt(q:to/EOF/);
    unit module Foo;
    our $v = 1;
    EOF
$src.add('META6.json').spurt(q:to/EOF/);
    { "name": "Foo", "version": "0.1.0", "auth": "git:local",
      "provides": { "Foo": "lib/Foo.rakumod" } }
    EOF

my $store = RakuPM::Store.new(:root($tmp.add('store')));
my $dist  = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));

plan 4;

$store.put($dist, $src);
ok $store.verify('Foo', '0.1.0'), '初次入库后 verify 通过';

# 模拟「包被加载后 Rakudo 在 store 里生成 .precomp」
my $dir = $store.path-for('Foo', '0.1.0');
$dir.add('.precomp').mkdir;
$dir.add('.precomp/x.precomp').spurt('bytecode');
ok $store.verify('Foo', '0.1.0'),
   'store 里有了 .precomp 后 verify 仍通过（不误报篡改）';

# 真篡改：改了源码内容
$dir.add('lib/Foo.rakumod').spurt(q:to/EOF2/);
    unit module Foo;
    our $v = 2;
    EOF2
nok $store.verify('Foo', '0.1.0'), '篡改源码内容 → verify 判 False';

# 删掉 .digest 视为不可校验
$dir.add('.digest').unlink;
nok $store.verify('Foo', '0.1.0'), '缺少 .digest → verify 判 False';
