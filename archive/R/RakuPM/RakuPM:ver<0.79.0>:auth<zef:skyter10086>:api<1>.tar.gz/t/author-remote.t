use Test;
use lib 'lib';
use RakuPM::Author;
use RakuPM::Fs;
use JSON::Fast;

# 让 check 门禁在测试环境里稳定通过（auth 与 dist 一致，不告警不报错）
%*ENV<RAKUPM_AUTHOR_AUTH> = 'github:tester';
# 凭据落到临时目录，隔离真实 ~/.raku-pm（login 写 credentials.json 的位置）
my $tmp = ($*TMPDIR // '/tmp'.IO).add("rakupm-remote-test-{now.to-posix[0].Int}");
$tmp.mkdir;
%*ENV<RAKUPM_TARGET> = $tmp.absolute.Str;

sub make-dist(Str $tag, Str :$version = '0.1.0' --> IO::Path) {
    my $d = $tmp.add("D-{$tag}");
    $d.mkdir;
    my %meta = %(
        name => 'Dist::Sample', version => $version, auth => 'github:tester',
        api => '1', description => 'a sample dist', authors => ['tester'],
        license => 'Artistic-2.0', raku => '6.d',
        provides => { 'Dist::Sample' => 'lib/Dist/Sample.rakumod' },
        depends => %( runtime => %( requires => [] ) ),
        test-depends => ['Test'],
    );
    $d.add('META6.json').spurt(to-json(%meta, :sorted-keys));
    my $lib = $d.add('lib/Dist/Sample.rakumod'); mkdir-p($lib.parent);
    $lib.spurt("unit module Dist::Sample;\n");
    $d.add('Changes').spurt("# Change log for Dist::Sample\n\n## {$version}\n\n- init\n");
    $d
}

# 场景1：login --api-key 把 key 写进凭据文件（仅属主可读，落 RAKUPM_TARGET 下）
{
    my $r = RakuPM::Author.login(:api-key('abc123secret'), :quiet(True));
    ok $r<ok>, '场景1：login --api-key 返回 ok';
    my $cf = $tmp.add('credentials.json');
    ok $cf.e, '场景1：凭据文件已写入 RAKUPM_TARGET 下';
    my %c = from-json($cf.slurp);
    is %c<api-key>, 'abc123secret', '场景1：api-key 已存储';
    is %c<host>, 'https://42.zef.pm', '场景1：host 已存储（默认上传端点）';
}

# 场景2：resolve-api-key 优先从文件读
is RakuPM::Author.resolve-api-key, 'abc123secret', '场景2：resolve-api-key 读到文件里的 key';

# 场景3：环境变量 RAKUPM_API_KEY 优先于凭据文件
%*ENV<RAKUPM_API_KEY> = 'envkey999';
is RakuPM::Author.resolve-api-key, 'envkey999', '场景3：RAKUPM_API_KEY 优先于文件';
%*ENV<RAKUPM_API_KEY>:delete;

# 场景4：publish --remote --dry 构造请求、不发网络、不本地部署
{
    my $d = make-dist('remote-dry');
    my $r = RakuPM::Author.publish($d, :remote, :dry, :quiet(True));
    ok $r<ok>, '场景4：publish --remote --dry 返回 ok';
    ok $r<remote>, '场景4：--remote 标记为真';
    is $r<endpoint>, 'https://42.zef.pm/upload', '场景4：endpoint 为规范上传端点';
    nok ?$tmp.dir.first({ .d && .basename eq 'Dist-Sample-0.1.0' }),
        '场景4：remote --dry 未部署任何本地目录';
}

# 场景5：publish --remote --dry 缺凭据直接报错（预览也需要凭据以打印认证头）
{
    $tmp.add('credentials.json').unlink if $tmp.add('credentials.json').e;
    %*ENV<RAKUPM_API_KEY>:delete;
    my $d = make-dist('remote-nocred');
    dies-ok { RakuPM::Author.publish($d, :remote, :dry, :quiet(True)) },
        '场景5：publish --remote 缺凭据报错';
}

done-testing;

# 清理临时目录（best-effort，纯 Raku 递归删除，不读平台变量）
LEAVE {
    sub rmtree(IO::Path $p) {
        return unless $p.e;
        if $p.d {
            for $p.dir -> $c { rmtree($c) }
            try $p.rmdir;
        }
        else {
            try $p.unlink;
        }
    }
    try rmtree($tmp);
}
