# t/install-options.t — Issue 9 单元验收
#
# 验证 RakuPM::InstallOptions 已收口五个散落策略（--pin / --recursive /
# --keep-store / --test-jobs / --test-timeout）：默认值、with() 不可变派生、
# describe() 输出。开关「透传子链」的行为由 xt/install-opts.t 覆盖（pins 与
# no-native-check / allow-test-failure 走同一条 $opts 通道，等价验证）。

use Test;
use RakuPM::InstallOptions;

plan 15;

# ---- 默认值 ----
my $o = RakuPM::InstallOptions.new;
is $o.test-jobs, 0,           'test-jobs 默认 0';
is $o.test-timeout, 0,        'test-timeout 默认 0';
is $o.pins.elems, 0,          'pins 默认空';
ok !$o.recursive,             'recursive 默认 False';
ok !$o.keep-store,            'keep-store 默认 False';
is $o.describe, '(默认)',     '全默认时 describe 返回 (默认)';

# ---- with() 派生不可变副本 ----
my $o2 = $o.with(:test-jobs(4), :pins(%('Foo' => '1.0')));
is $o2.test-jobs, 4,          'with 改 test-jobs 生效';
is $o2.pins<Foo>, '1.0',      'with 改 pins 生效';
is $o.test-jobs, 0,           '原对象不被污染（不可变）';
is $o.pins.elems, 0,          '原对象 pins 不变';

# ---- describe() 仅列「非默认」字段 ----
my $o3 = RakuPM::InstallOptions.new(
    :test-jobs(2), :test-timeout(60),
    :pins(%('A' => '1')), :recursive, :keep-store);
my $d = $o3.describe;
ok $d.contains('--test-jobs=2'),     'describe 含 test-jobs';
ok $d.contains('--test-timeout=60'), 'describe 含 test-timeout';
ok $d.contains('--recursive'),       'describe 含 recursive';
ok $d.contains('--keep-store'),      'describe 含 keep-store';
ok $d.contains('--pin(1)'),          'describe 含 pins 计数';

done-testing;
