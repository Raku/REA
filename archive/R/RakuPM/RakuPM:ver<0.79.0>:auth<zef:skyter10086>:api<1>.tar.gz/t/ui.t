use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::UI;

# RakuPM::UI（终端展示层：色彩 / 表格）的单元测试。
# 重点验证两件事：
#   ① 显示宽度按【东亚宽度】算（中文 / 全角标点 = 2 列），否则表格列会歪；
#   ② 非富文本（非 TTY / 管道 / 测试捕获）时【绝不】输出 ANSI 转义码 ——
#      这是现有测试断言不被染色破坏的前提，也是「自动降级」承诺的核心。

# ---------- 显示宽度 ----------
is ui-width('abc'), 3, '纯 ASCII：每字符 1 列';
is ui-width('中文'), 4, '中文（East_Asian_Width=W）：每字 2 列';
is ui-width('，'), 2, '全角标点（F）：2 列';
is ui-width('（'), 2, '全角括号（F）：2 列';
is ui-width('a中b'), 4, '混合：1+2+1';
is ui-width(''), 0, '空串 0 列';
is ui-width("\e[31mred\e[0m"), 3, 'ANSI 转义序列不计入显示宽度';

# ---------- 按显示宽度填充 ----------
is ui-pad('ab', 5), 'ab   ', '左对齐填充到指定显示宽度';
is ui-pad('中', 4), '中  ', '中文按 2 列算 → 补 2 个空格';
is ui-pad('ab', 5, :right), '   ab', '右对齐填充';
is ui-pad('abcdef', 3), 'abcdef', '已超宽不截断（宁可溢出也不丢内容）';

# ---------- 省略（表格里的长路径）----------
is ui-ellipsis('short', 10), 'short', '未超上限：原样返回';
my $e = ui-ellipsis('C:/very/long/path/to/Foo-1.0', 20);
ok $e.starts-with('…'),   '超上限：从头部省略，以 … 开头';
ok $e.ends-with('Foo-1.0'), '超上限：保留尾部（目录名信息量最大）';
ok ui-width($e) <= 20,    '省略后不超过上限（按显示宽度）';

# ---------- 非富文本：无色、无 Unicode 边框 ----------
ui-set-rich(False);
ok !ui-rich(), '显式关闭后 ui-rich 返回 False';
is ui-red('x'), 'x',    '非富文本：ui-red 不包裹转义码';
is ui-green('x'), 'x',  '非富文本：ui-green 同';
is ui-bold('x'), 'x',   '非富文本：ui-bold 同';

# 【写测试时的大坑，务必注意尾随逗号】
# Raku 的 [ ... ] 数组构造器在「唯一参数本身就是数组」时会再展平一层：
#   [['1','2']]  求值得到  ['1','2']   （一层！嵌套被吃掉）
#   (['1','2'],) 求值得到  [['1','2'],]（正确）
# 只有一行数据的表格必须写成 (['...'],)，否则会被当成「两个单格行」。
# （生产代码里传的是 @rows 变量，不经字面量构造器，故不受影响。）
my $plain = ui-table(['A', 'B'], (['1', '2'],));
ok $plain.contains('+'), '非富文本：表格用 ASCII 边框';
nok $plain.contains('│'), '非富文本：不含 Unicode 制表符';
nok $plain.contains("\e["), '非富文本：不含任何 ANSI 转义';
ok $plain.contains('| A | B |'), '表头行';
ok $plain.contains('| 1 | 2 |'), '单行数据不被展平（回归：Raku [..] 构造器坑）';

# ---------- 中文列对齐（本模块的存在意义）----------
my $t = ui-table(['包名', '版本'], (['Dual', '0.13.0'],));
# 第 1 列宽 = max(width('包名')=4, width('Dual')=4) = 4
# 第 2 列宽 = max(width('版本')=4, width('0.13.0')=6) = 6
ok $t.contains('| 包名 | 版本   |'), '中文表头按显示宽度补齐 → 列对齐';
ok $t.contains('| Dual | 0.13.0 |'), '数据行同样按显示宽度补齐';

# ---------- 键值表（无表头，键右对齐）----------
my $kv = ui-kv-table((['描述', '教学包管理器'], ['作者', 'abc']));
ok $kv.contains('| 描述 |'), '键值表：长键原样占满';
ok $kv.contains('| 作者 |'), '键值表：短键右对齐补齐';
ok !$kv.contains('字段'),    '键值表：不渲染表头';

# 单行键值表（同样验证「单元素不展平」）
my $kv1 = ui-kv-table((['描述', 'x'],));
ok $kv1.contains('| 描述 | x |'), '键值表：单行也对（回归）';

# ---------- 富文本：真的有色彩与 Unicode 边框 ----------
ui-set-rich(True);
ok ui-rich(), '显式开启后 ui-rich 返回 True';
ok ui-red('x').contains("\e[31m"), '富文本：ui-red 带 ANSI 颜色码';
ok ui-green('x').contains("\e[32m"), '富文本：ui-green 带 ANSI 颜色码';
my $rich = ui-table(['A'], [['1']]);
ok $rich.contains('│'), '富文本：表格用 Unicode 边框';

# ---------- 复位：别把强制开启泄漏给同进程后续断言 ----------
ui-set-rich(False);
ok !ui-rich(), '复位后回到非富文本';

# ---------- 横幅（艺术字标题）：非 rich 空串，rich 出艺术字 ----------
# 关键约定：非 rich 返回 ''，于是 help 的纯文本输出与「加横幅之前」逐字节一致。
ui-set-rich(False);
is ui-banner(), '', '非富文本：横幅为空串（不污染管道/测试的纯文本）';

ui-set-rich(True);
my Str $banner = ui-banner();
ok $banner.chars > 0, '富文本：横幅非空';
ok $banner.contains("\e[36m"), '富文本：横幅带青色';
ok $banner.contains('raku-pm help'), '富文本：横幅带一行提示';
my @art = $banner.lines.head(6);      # 前 6 行是艺术字（之后是提示语行 + 空行）
is @art.elems, 6, '横幅艺术字 6 行';
# 第 6 行是 `╚═╝…` 不含 █，故两种字符任一命中即算艺术字块
is @art.grep({ .contains('█') || .contains('╚') }).elems, 6, '6 行全是艺术字块';
my @bw = @art.map({ ui-width($_) }).unique;
is @bw.elems, 1, '横幅艺术字每行显示宽度一致（终端里不会歪）';

# ---------- help 高亮：非 rich 原样；rich 上色但不改宽度 ----------
my Str $sample = "  待高亮\n\n  install <模块> [--version=X] [--dry]\n  --offline  等价于 RAKUPM_OFFLINE=1\n";
ui-set-rich(False);
is ui-colorize-help($sample), $sample, '非富文本：help 高亮原样返回（逐字节不变）';

ui-set-rich(True);
my Str $col = ui-colorize-help($sample);
ok $col.contains("\e[1m\e[32minstall"), '富文本：命令名染成粗体绿';
ok $col.contains("\e[33m--version"), '富文本：旗标染黄';
ok $col.contains("\e[33m--offline"), '富文本：行首旗标也染黄';
ok $col.contains("\e[35m<模块>"), '富文本：占位符染品红';
# 注意：旗标上色后是 `--version\e[0m=X`，字面的 `--version=X` 已不存在 —— 故断言分开
ok $col.contains('install') && $col.contains('=X') && $col.contains('<模块>'),
   '富文本：上色不吞字符（文本都在）';
is ui-width($col), ui-width($sample), '高亮后显示宽度不变（ANSI 不计宽）';

# ---------- 树形连接符 ----------
ui-set-rich(False);
is ui-tree-branch(False), '|- ', '非富文本：树连接符 ASCII（非末项）';
is ui-tree-branch(True),  '`- ', '非富文本：树连接符 ASCII（末项）';
is ui-tree-child(False),  '|  ', '非富文本：树子前缀 ASCII';

ui-set-rich(True);
is ui-tree-branch(False), '├─ ', '富文本：树连接符 Unicode（非末项）';
is ui-tree-branch(True),  '└─ ', '富文本：树连接符 Unicode（末项）';
is ui-tree-child(False),  '│  ', '富文本：树子前缀 Unicode';

ui-set-rich(False);
ok !ui-rich(), '最后复位，不泄漏给同进程后续断言';

done-testing;
