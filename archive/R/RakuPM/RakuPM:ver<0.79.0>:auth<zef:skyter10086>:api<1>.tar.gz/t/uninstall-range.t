use Test;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Fs;

# 回归：uninstall 支持 semver 版本范围（--version 承载约束串）。
#   · 精确串（"1.0.0" / "1.0"）退化为单版本匹配（向后兼容）；
#   · 区间（"<1.0" / ">=1.0, <2.0"）、通配（"*"）、npm 糖语法（"^1.0" / "~1.2"）
#     一次卸掉所有满足约束的版本；
#   · --keep-store 与范围组合时，被卸版本的 store 快照按范围保留/清理。

my $tmp = $*TMPDIR.add("_t-uninstall-range-{$*PID}-" ~ now.floor);
END { try { rm-tree($tmp) if $tmp.d } }

sub json-dist($v) {
    RakuPM::Distribution.new(:name('JSON'), :version($v), :auth('t:me'),
                             :provides(['JSON']));
}

my $src = $tmp.add('src');
$src.add('lib').mkdir;
$src.add('lib/JSON.rakumod').spurt("unit module JSON;\n");
$src.add('META6.json').spurt(q:to/META/);
    { "name": "JSON", "version": "1.0.0", "auth": "t:me",
      "provides": { "JSON": "lib/JSON.rakumod" } }
    META

my $store = RakuPM::Store.new(:root($tmp.add('store')));
my $inst  = RakuPM::Installer.new(:target($tmp), :store($store));

# 装四个版本（store 同时有源码快照）
for <0.9.0 1.0.0 1.5.0 2.0.0> -> $v {
    $store.put(json-dist($v), $src);
    $inst.install(json-dist($v));
}
ok  $store.has('JSON', '0.9.0') && $store.has('JSON', '1.0.0')
   && $store.has('JSON', '1.5.0') && $store.has('JSON', '2.0.0'),
   '前提：四版快照都在';
is  $inst.installed-versions('JSON').join(', '), '0.9.0, 1.0.0, 1.5.0, 2.0.0',
   '前提：账本记下四个版本';

# ---- 范围 <1.0：只卸 0.9.0 ----
$inst.uninstall('JSON', version => '<1.0');
is  $inst.installed-versions('JSON').join(', '), '1.0.0, 1.5.0, 2.0.0',
   '范围 <1.0 只卸掉 0.9.0（账本留 1.0.0/1.5.0/2.0.0）';
nok $store.has('JSON', '0.9.0'), '范围 <1.0：0.9.0 的 store 快照被清';
ok  $store.has('JSON', '1.0.0') && $store.has('JSON', '1.5.0')
   && $store.has('JSON', '2.0.0'),
   '范围 <1.0：其余版本 store 快照不受影响';

# ---- 范围 ^1.0（= >=1.0.0, <2.0.0）：卸 1.0.0/1.5.0，留 2.0.0 ----
$inst.uninstall('JSON', version => '^1.0');
is  $inst.installed-versions('JSON').join(', '), '2.0.0',
   '范围 ^1.0 卸掉 1.0.0/1.5.0，留 2.0.0';
nok $store.has('JSON', '1.0.0') && $store.has('JSON', '1.5.0'),
   '^1.0：被卸版本的 store 快照清掉';
ok  $store.has('JSON', '2.0.0'), '^1.0：2.0.0 store 快照保留';

# ---- 范围 *：卸掉剩余全部（整包清空）----
$inst.uninstall('JSON', version => '*');
ok  $inst.installed-versions('JSON').elems == 0, '范围 * 卸掉剩余全部版本（整包清空）';
nok $store.has('JSON', '2.0.0'), '*：最后版本 store 快照也清掉';

# ---- --keep-store + 范围：store 快照按范围保留 ----
$store.put(json-dist('0.9.0'), $src); $inst.install(json-dist('0.9.0'));
$store.put(json-dist('1.0.0'), $src); $inst.install(json-dist('1.0.0'));
$inst.uninstall('JSON', version => '<1.0', :keep-store);
is  $inst.installed-versions('JSON').join(', '), '1.0.0',
   '--keep-store+<1.0：账本只留 1.0.0';
ok  $store.has('JSON', '0.9.0'), '--keep-store+<1.0：0.9.0 的 store 快照保留（供秒级重装）';

done-testing;
