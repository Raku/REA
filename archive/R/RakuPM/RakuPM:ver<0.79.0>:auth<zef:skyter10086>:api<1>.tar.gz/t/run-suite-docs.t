use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 门禁脚本自身的守护测试。
#
# 为什么需要它：`tools/run-suite.raku` 的文档纪律校验（META6 版本 ↔ 两份 README
# 的版本示例 ↔ Changes 条目；provides 与 lib/ 下文件互为全集）此前完全靠人肉自觉，
# 已经漂移过多次。把它接到 t/ 里，git 克隆后 `zef install` 的测试阶段就会跑到，
# 漂移会在装包时立刻暴露而不是等用户发现。
#
# 注意：只调 --docs-only（不递归跑 t/，否则无限套娃；门禁脚本的子进程只做校验）。

plan 3;

my $root   = $*PROGRAM.parent.parent;
my $runner = $root.add('tools/run-suite.raku');

ok $runner.f, 'tools/run-suite.raku 存在（回归门禁脚本不许被删）';

my $p = run($*EXECUTABLE.Str, $runner.absolute.Str, '--docs-only',
            :out, :err, :cwd($root.Str));
my $out = $p.out.slurp(:close);
my $err = $p.err.slurp(:close);
my $all = $out ~ $err;
my $rc  = $p.exitcode;

is $rc, 0, '文档纪律校验通过（退出码 0）';
diag $all if $rc != 0;

is $all.lines.grep({ .trim.starts-with('FAIL') }).elems, 0,
    '文档纪律校验没有 FAIL 项（版本号三处一致 / provides 与 lib 互为全集）';
