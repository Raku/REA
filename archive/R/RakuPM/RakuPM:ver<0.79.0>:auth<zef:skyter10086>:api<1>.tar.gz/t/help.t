use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Help;
use RakuPM::CliSpec;

# ---------------------------------------------------------------------------
# help 分级（0.78.0）：RakuPM::Help 把原先一坨 358 行的 help 正文拆成三层
#   · help-summary  —— 默认：紧凑分组索引（必须一屏内）
#   · help-command  —— raku-pm help <命令>：单命令详情
#   · help-all      —— raku-pm help all：完整手册
#
# 这里守两件事：
#   ① 分层本身正确（summary 紧凑、command 给详情、all 是合集、未知命令为空）；
#   ② summary 的【完备性】—— 命令与别名都从 CliSpec 现取，必须一个不漏
#      （xt/cli-output-stability.t 从 CLI 端也守这件事，这里从模块端再守一遍）。
# ---------------------------------------------------------------------------

my $s = help-summary();

ok $s.lines[0].contains('用法'), 'summary：首行是用法说明';
ok $s.lines.elems <= 40, "summary：紧凑到一屏内（实际 {$s.lines.elems} 行）";

# 完备性：所有规范命令（除 help 自身）都出现
my @miss-cmd = cmd-flags().keys.grep({ $_ ne 'help' && !$s.contains($_) }).sort;
is @miss-cmd.join(', '), '', "summary：列出全部规范命令（漏：{@miss-cmd.join(', ') || '无'}）";

# 完备性：所有别名都出现
my @miss-alias = cmd-aliases().keys.grep({ !$s.contains($_) }).sort;
is @miss-alias.join(', '), '', "summary：列出全部别名（漏：{@miss-alias.join(', ') || '无'}）";

# 幂等：同一进程内两次调用字节一致
is help-summary(), $s, 'summary：幂等（两次字节一致）';

# ---- help-command：单命令详情 ----
ok help-command('install').chars > 0, 'help-command：install 有内容';
ok help-command('install').contains('install'), 'help-command：install 详情含命令名';
ok help-command('install').lines.elems > 3, 'help-command：install 是详细用法（多行）';
is help-command('rdep'), help-command('rdepends'), 'help-command：别名 rdep 归一到 rdepends';
is help-command('i'),    help-command('install'),  'help-command：别名 i 归一到 install';
is help-command('nope'), '', 'help-command：未知命令返回空';

# ---- known-command ----
ok known-command('install'), 'known-command：认得 install';
ok known-command('rdep'),    'known-command：认得别名 rdep';
nok known-command('nope'),   'known-command：不认得 nope';

# ---- help-all：完整手册 ----
my $all = help-all();
ok $all.contains('用法'), 'help-all：含 summary 段';
ok $all.contains('锁文件'), 'help-all：含总览主题（锁文件）';
ok $all.contains('环境变量'), 'help-all：含环境变量主题';
ok $all.lines.elems > 300, "help-all：是完整手册（实际 {$all.lines.elems} 行）";

done-testing;
