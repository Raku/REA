use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Client;
use RakuPM::Installer;
use RakuPM::Fs;

# 回归：具名实参「名字写错」导致参数被静默丢弃（本机 Rakudo 对 method 不报错）。
#
# ============================================================
# 背景：本机 Rakudo（v2026.08）实测行为差异
# ============================================================
#   sub  s(:$x = 1)        ; s(:zzz(9))  → 报 Unexpected named argument 'zzz'
#   method m(:$x = 1)      ; $o.m(:zzz(9)) → 【静默忽略】，$x 取默认值，无任何提示
# 私有方法、role 方法同样静默。也就是说：**方法调用点上的具名实参名字拼错，
# 编译器、运行时都不会告诉你，参数会凭空失效**。本项目「开关传了但不起作用」
# 那一类缺陷正好落在盲区里。
#
# ============================================================
# 本文件钉死两处【已经真实发生过】的接线错误
# ============================================================
# 两处都是「形参名与实际写法不一致」，都在实测中确认会被静默丢弃。
# 之所以各自需要一个守卫，是因为它们的作用面不同：
#   · ① 卸载按版本：写错会让 `--version` 约束消失 → 用户以为只卸一个版本，
#        实际整包连根拔起（数据丢失级）。
#   · ② self-upgrade 的 source：写错会让帮助里承诺的「在仓库里跑则 pull
#        当前仓库」那条分支永远走不到（开发者的本地提交被无视）。
#
# 【为什么既有测试没抓到 ①】t/multi-version.t 用的是 `$inst.uninstall(:version(...))`
# ——它在【Installer 层】直接调，绕过了出问题的那一层（Reporter 转发）。
# 所以这里刻意从【Client 公开 API】走一遍。

my IO::Path $tmp = $*TMPDIR.add("rakupm-wiring-{$*PID}");
LEAVE rm-tree($tmp) if $tmp.e;

my $target = $tmp.add('t');
my $client = RakuPM::Client.new(:target($target));

sub mk-src(Str $ver --> IO::Path) {
    my $d = $tmp.add("src-{$ver}").mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add('Wire.rakumod').spurt(
        'unit module Wire:ver<' ~ $ver ~ ">;\n");
    # 注意用 %( ) 而不是 ( )：Raku 里圆括号是【列表】构造，
    # 写 ( name => .., version => .. ) 会得到一个 Pair 列表，
    # to-json 出来是 JSON 数组 → from-meta-file 报「顶层应为 JSON 对象」。
    $d.add('META6.json').spurt(to-json(%(
        name     => 'Wire',
        version  => $ver,
        auth     => 'demo:test',
        provides => { 'Wire' => 'lib/Wire.rakumod' },
        depends  => {},
    ), :sorted-keys));
    $d
}

my $s11 = mk-src('1.1.0');
my $s20 = mk-src('2.0.0');
my $d11 = RakuPM::Distribution.from-meta6-file($s11.add('META6.json'));
my $d20 = RakuPM::Distribution.from-meta6-file($s20.add('META6.json'));

# ---------- ① 走 Client 公开 API 的「按版本卸载」 ----------
$client.store.put($d11, $s11);
$client.store.put($d20, $s20);
$client.installer.install($d11);
$client.installer.install($d20);

is $client.installer.installed-versions('Wire').sort.join(','), '1.1.0,2.0.0',
   '前提：两个版本都已装';

$client.uninstall('Wire', version => '2.0.0');

is $client.installer.installed-versions('Wire').join(','), '1.1.0',
   '按版本卸载：只清掉 2.0.0，1.1.0 保留'
   ~ '（修复前 `:$ver` 被静默丢弃 → 两个版本全被删掉）';
is $client.installer.list-installed.elems, 1,
   '账本条目仍在（不是把整包连根拔起）';

# ---------- ② self-upgrade 的 source 参数必须真的接上线 ----------
# 这里只能做文本级断言：真跑 self-upgrade 要联网 + 改本机安装，不适合放进 t/。
# 断言的是「调用形式」，因为问题恰恰出在形式上 —— `:$src` 与 `source => $src`
# 在编译器眼里毫无区别，只有运行时才知道名字对不上。
{
    # 0.79.0：CLI 主体已从 bin 搬进 RakuPM::CLI（bin 退化成薄壳，见该模块头部说明），
    # 故文本级断言要指向模块 —— 代码在哪就查哪，别钉死 bin。
    my IO::Path $code = $*PROGRAM.parent.parent.add('lib/RakuPM/CLI.rakumod');
    ok $code.f, 'lib/RakuPM/CLI.rakumod 存在';

    my Str $src = $code.slurp;
    ok $src.contains('source => $src'),
       'self-upgrade 用 `source => $src` 传参'
       ~ '（形参叫 :source；写 `:$src` 会被静默丢弃，'
       ~ '「在仓库里跑则 pull 当前仓库」那条分支永远走不到）';
    nok $src.contains(':$src,'),
       'self-upgrade 那行没有残留的 `:$src`';
}

done-testing;
