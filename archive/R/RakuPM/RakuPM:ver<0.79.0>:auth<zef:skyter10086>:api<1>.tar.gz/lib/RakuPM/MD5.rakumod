# RakuPM::MD5 — 内置的 MD5（RFC 1321），Store 内容指纹专用
#
# 只有一个用途：Store 的内容指纹。之前依赖生态的 Digest::MD5
# （发行版名叫 "Digest"，grondilu 维护），但它的解析在部分环境
# （WSL 上 zef 报「已安装」而 use 找不到）极不可靠 —— raku-pm 自己
# 的安装/测试全被这一个外部依赖卡死。
#
# MD5 只用于「检测内容是否变化」，不用于密码学。RFC 1321 全套
# 测试向量在 t/md5.t 里钉死，指纹值与生态版完全一致（老 store 兼容）。
#
# 性能（重要）：纯 Raku 的 MD5 只有 ~0.25 MB/s，对 3.8MB 的 store 条目
# 要十几秒。这里做两级策略：
#   1. 纯 Raku 路径去装箱（buf8.allocate + 原生 int @S/@K/@M + 按偏移索引，
#      不再 rotor 出中间数组），小文件能到 ~4 MB/s；
#   2. ≥64KB 的文件走系统 md5 命令（Linux md5sum / macOS md5 -q /
#      Windows certutil -hashfile），统一入口是 md5-file(IO::Path)。
# 关键取舍：不是「总是调外部命令」——命令不存在、退出码非 0、输出不匹配
# ^[0-9a-f]{32}$ 时静默回退纯 Raku，指纹永远算得出来。RAKUPM_MD5=raku
# 强制走纯 Raku（调试/验证用）。

use RakuPM::Platform;

unit module RakuPM::MD5;

# RFC 1321 的 64 个移位位数（原生 int，去装箱）
my int @S = flat (7,12,17,22) xx 4, (5, 9,14,20) xx 4,
                 (4,11,16,23) xx 4, (6,10,15,21) xx 4;

# 64 个常量：floor(2^32 × |sin(i+1)|)
my int @K = (0..63).map(-> $i { (2**32 * abs(sin($i + 1))).floor +& 0xFFFFFFFF }).Array;

sub rol(uint32 $x, int $n --> uint32) {
    ((($x +< $n) +& 0xFFFFFFFF) +| ($x +> (32 - $n))) +& 0xFFFFFFFF
}

# 核心：对任意 Blob 做 MD5，返回 32 位小写十六进制。
# 去装箱版：不再 @msg = $data.list（每字节一个 Scalar 容器），也不再
# rotor 出中间数组；改用 buf8.allocate + 按偏移索引填充，主循环全用原生 int。
multi md5-hex(Blob $data --> Str) is export {
    my int $n     = $data.elems;
    my int $total = (($n + 8) div 64 + 1) * 64;   # +1(0x80) + 8(长度) 对齐到 64
    my $buf = buf8.allocate($total);

    # 拷贝原始数据
    my int $i = 0;
    while $i < $n { $buf[$i] = $data[$i]; ++$i }
    $buf[$n] = 0x80;
    # 64 位小端长度（bit 数）
    my $bits = $n * 8;
    my int $t = $total - 8;
    my int $j = 0;
    while $j < 8 { $buf[$t + $j] = ($bits +> (8 * $j)) +& 0xFF; ++$j }

    my int $a0 = 0x67452301;
    my int $b0 = 0xEFCDAB89;
    my int $c0 = 0x98BADCFE;
    my int $d0 = 0x10325476;

    my int @M;

    my int $off = 0;
    while $off < $total {
        # 小端 32 位字
        my int $k = 0;
        while $k < 16 {
            my int $p = $off + 4 * $k;
            @M[$k] = $buf[$p]          +| ($buf[$p + 1] +< 8)
                   +| ($buf[$p + 2] +< 16) +| ($buf[$p + 3] +< 24);
            ++$k;
        }

        my int $A = $a0; my int $B = $b0; my int $C = $c0; my int $D = $d0;

        my int $i2 = 0;
        while $i2 < 64 {
            my int $F; my int $g;
            if $i2 < 16 {
                $F = ($B +& $C) +| (($B +^ 0xFFFFFFFF) +& $D);
                $g = $i2;
            }
            elsif $i2 < 32 {
                $F = ($D +& $B) +| (($D +^ 0xFFFFFFFF) +& $C);
                $g = (5 * $i2 + 1) % 16;
            }
            elsif $i2 < 48 {
                $F = $B +^ $C +^ $D;
                $g = (3 * $i2 + 5) % 16;
            }
            else {
                $F = $C +^ ($B +| ($D +^ 0xFFFFFFFF));
                $g = (7 * $i2) % 16;
            }
            $F = ($F + $A + @K[$i2] + @M[$g]) +& 0xFFFFFFFF;
            $A = $D;
            $D = $C;
            $C = $B;
            $B = ($B + rol($F, @S[$i2])) +& 0xFFFFFFFF;
            ++$i2;
        }

        $a0 = ($a0 + $A) +& 0xFFFFFFFF;
        $b0 = ($b0 + $B) +& 0xFFFFFFFF;
        $c0 = ($c0 + $C) +& 0xFFFFFFFF;
        $d0 = ($d0 + $D) +& 0xFFFFFFFF;
        $off += 64;
    }

    # ---- 输出：四个字各按小端展开成十六进制（小写、零填充）----
    my $out = '';
    for $a0, $b0, $c0, $d0 -> $w {
        my int $j2 = 0;
        while $j2 < 4 {
            $out ~= (($w +> (8 * $j2)) +& 0xFF).fmt('%02x');
            ++$j2;
        }
    }
    $out
}

multi md5-hex(Str $s --> Str) is export {
    md5-hex($s.encode('utf-8'))
}

# ---- 文件入口（Store.!fingerprint 调这个）----

# 读取文件全部字节。绕开 Rakudo 2026.07 的一个 bug：IO::Path.slurp(:bin)
# 在文件恰好 1048576 字节（2^20）时抛「Out of range: attempted to read 0
# bytes from filehandle」（1048575 / 1048577 都正常），open(:bin).slurp(:close)
# 不受影响。
sub slurp-bytes(IO::Path $path --> Buf) {
    my $fh = $path.open(:bin);
    my $buf = $fh.slurp(:close);
    $buf
}

# 平台判断统一走 RakuPM::Platform —— 那是全项目唯一读 $*DISTRO 的地方，
# 因而可以被测试用 `my $*DISTRO = ...` 遮蔽，在 Windows 开发机上真实走进
# Linux / macOS 两支（见 t/platform.t）。历史教训写在那边模块头注释里：
# 这里曾经写 `$*DISTRO.is-macosx`（Distro 根本没这个方法），Windows 上
# is-win 为真、elsif 短路，全套测试全绿；一到 Linux 就崩在 Store 的指纹计算上。

# 用系统 md5 命令算文件指纹；失败/格式不对返回 ''。
sub system-md5(IO::Path $path --> Str) {
    # 只探测一次：一次调用里平台不会变，旧实现分两处各判一次。
    my $os = os-key();

    my @cmd = md5-command($path, $os);

    my $proc = try { run(@cmd, :out, :err) };
    return '' unless $proc ~~ Proc;
    my $out = try { $proc.out.slurp(:close) } // '';
    try { $proc.err.slurp(:close) };
    my $code = try { $proc.exitcode } // -1;
    return '' unless $code == 0;

    # 输出格式各平台不同（certutil 第二行 / md5 -q 第一行 / md5sum 第一个词），
    # 由 Platform.parse-md5-output 按平台取 —— 那边可被遮蔽测试覆盖。
    my $hex = parse-md5-output($out, $os).trim.lc;
    return '' unless $hex ~~ /^ <[0..9 a..f]> ** 32 $/;
    $hex
}

# 文件内容指纹的统一入口：≥64KB 优先走系统命令，否则（或命令不可用/被强制）
# 回退纯 Raku。
sub md5-file(IO::Path $path --> Str) is export {
    return md5-hex(slurp-bytes($path)) if (%*ENV<RAKUPM_MD5> // '') eq 'raku';
    my $size = try { $path.s } // 0;
    return md5-hex(slurp-bytes($path)) if $size < 64 * 1024;
    my $hex = system-md5($path);
    return $hex if $hex;
    md5-hex(slurp-bytes($path))   # 回退纯 Raku，指纹永远算得出来
}
