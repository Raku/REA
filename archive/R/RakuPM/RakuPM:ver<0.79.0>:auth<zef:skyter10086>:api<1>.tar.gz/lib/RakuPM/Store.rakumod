# RakuPM::Store — 包的本地存储（"下载下来存哪"的答案）
#
# 目录布局（仿 cargo 的 registry/cache，并借鉴 nix 的内容寻址做校验）：
#
#   ~/.raku-pm/store/
#     └── <发行版名>/
#           └── <版本>/
#                 ├── META.json     原始元数据
#                 ├── lib/          源码
#                 └── .sha1         内容指纹，用于完整性校验
#
# 关键设计：多版本共存。store 里可以同时有 JSON/1.0.0 和 JSON/2.0.0，
# 安装时决定"激活"哪个版本到 lib/。这就是版本管理的物理基础。

use RakuPM::Distribution;
use RakuPM::Fs;
use JSON::Fast;
use RakuPM::MD5;

unit class RakuPM::Store;

has IO::Path $.root is required;

# 把发行版名转成安全的目录段。
# Windows 上 `:` 是保留字符，所以 `File::Temp` 必须用 `File-Temp` 这种形式。
# 反向还原靠每个目录里的 META.json（那里仍存真名）。
method !safe-name(Str $name --> Str) {
    $name.subst('::', '-', :g)
}

# 某个发行版某版本在 store 中的目录
method path-for(Str $name, Str $version --> IO::Path) {
    $!root.add(self!safe-name($name)).add($version)
}

# 该版本是否已在 store 中
method has(Str $name, Str $version --> Bool) {
    self.path-for($name, $version).add('META.json').e
}

# 条目是否是「老格式」，需要重新入库。两类：
#   1. 有 META.json 但缺标准 META6.json —— 0.2.x 之前入库的，直接激活会炸
#      （Installer 报「缺少 META6.json」）；
#   2. META6.json 有，但发行版声明了 resources 而 store 里存的是空列表 ——
#      0.4.0（resources 支持落地）之前入库的：资源文件没复制、声明也是空，
#      激活后 %?RESOURCES<key> 查不到，资源对象回退成 resources 目录，
#      模块一 .open 就崩（如 Data::Generators 的 csv 资源）。
# :$dist 传发行版对象时才做第 2 类检查（它带元数据里声明的资源清单）。
method needs-readmit(Str $name, Str $version, RakuPM::Distribution :$dist --> Bool) {
    return False unless self.has($name, $version);
    my $dir = self.path-for($name, $version);
    return True unless $dir.add('META6.json').e;
    if $dist.defined && $dist.resources.elems {
        my $j = try from-json($dir.add('META6.json').slurp);
        # 元数据损坏读不出（from-json 返回未定义的 Any）→ 当作需要重新入库（安全侧）
        return True if $j ~~ Failure || ! $j.defined;
        my %m6 = $j;
        my @stored = @(%m6<resources> // []);
        return True unless @stored.elems;
    }
    False
}

# store 中某个发行版的所有已缓存版本（读 META.json 拿到真名匹配）
method cached-versions(Str $name --> List) {
    my $dir = $!root.add(self!safe-name($name));
    return () unless $dir.d;
    my @vs;
    for $dir.dir.grep(*.d) -> $sub {
        my $meta = $sub.add('META.json');
        next unless $meta.e;
        my $dist = RakuPM::Distribution.from-meta-file($meta);
        @vs.push($dist.version) if $dist.name eq $name;
    }
    @vs.List
}

# store 中所有发行版（读 META.json 取真名，去重）
method all-names(--> List) {
    return () unless $!root.d;
    my %seen;
    for $!root.dir.grep(*.d) -> $sub {
        for $sub.dir.grep(*.d) -> $ver-dir {
            my $meta = $ver-dir.add('META.json');
            next unless $meta.e;
            my $dist = RakuPM::Distribution.from-meta-file($meta);
            %seen{$dist.name}++;
        }
    }
    %seen.keys.List
}

# 某发行版（其全部已缓存版本并集）提供的模块名。
# 供 show-store 用「模块名」也能找到发行版：store 目录名是发行版名
# （Web-App），用户常只记得模块名（Web::App）。本方法只返回数据，
# 匹配判定由 RakuPM::Repository::Matching 统一负责。
method provides-of(Str $name --> List) {
    my $dir = $!root.add(self!safe-name($name));
    return () unless $dir.d;
    my %seen;
    for $dir.dir.grep(*.d) -> $sub {
        my $meta = $sub.add('META.json');
        next unless $meta.e;
        my $dist = try RakuPM::Distribution.from-meta-file($meta);
        next unless $dist.defined;
        next unless $dist.name eq $name;
        for @($dist.provides // []) -> $m { %seen{$m} = True }
    }
    %seen.keys.List
}

# 物化：把一个源码目录收进 store（相当于"下载并解包"后的落盘）
# 返回内容指纹
#
# :%build 是「构建事实」（RakuPM::Builder.facts 产出），落成条目的 build.json 旁车。
# 不传（测试、或不经构建阶段的直接入库）就记成 mode='not-recorded'。
method put(RakuPM::Distribution $dist, IO::Path $source, :%build = %() --> Str) {
    my $dest = self.path-for($dist.name, $dist.version);
    mkdir-p($dest);

    # 写入标准 META.json（规范化，保证之后能独立读取）
    $dest.add('META.json').spurt($dist.to-meta-json);

    # 复制 lib/
    my $src-lib = $source.add('lib');
    die "发行版 {$dist.name} 缺少 lib/ 目录" unless $src-lib.d;
    my $dest-lib = $dest.add('lib');
    mkdir-p($dest-lib);
    copy-tree($src-lib, $dest-lib);

    # 复制 resources/（如果存在）。
    # 之前只复制 lib/，结果装完之后 %?RESOURCES 指向一个不存在的文件 ——
    # native 包常把 .so/.dll 放在 resources/libraries/ 下，这条缺失会直接废掉它们。
    # 测试阶段看不出来（我们从源码目录跑测试，resources/ 就在旁边），
    # 装完才暴露，属于很阴的一类 bug。
    my $src-res = $source.add('resources');
    if $src-res.d {
        my $dest-res = $dest.add('resources');
        mkdir-p($dest-res);
        copy-tree($src-res, $dest-res);
    }

    # 复制 bin/（可执行脚本）。CUR::Installation 装包时不会自动处理 bin 字段——
    # 这是 Distribution::Path 的语义盲点；zef 走独立的 ExtractBin 服务。
    # 我们在这里就复制好，让 store 是发行版内容的「完整快照」，
    # 之后 Installer.!install-bin 从 store 里取脚本做 wrapper。
    my $src-bin = $source.add('bin');
    if $src-bin.d {
        my $dest-bin = $dest.add('bin');
        mkdir-p($dest-bin);
        copy-tree($src-bin, $dest-bin);
    }

    # 再写一份 Raku 标准 META6.json。
    # 它是 CompUnit::Repository::Installation（zef 装包用的那套机制）唯一认的元数据，
    # 而且 provides 是「模块名 => 相对路径」——比我们的 META.json 多一样东西。
    # resources 也必须写进去，否则 CUR::Installation 不知道这个包带了资源，
    # %?RESOURCES 依然取不到（文件复制过去了也没用）。
    $dest.add('META6.json').spurt(to-json(self!meta6-for($dist, $dest, $source), :sorted-keys));

    # 构建痕迹「旁车」：记录构建阶段发生了什么，以及【声明过但磁盘上没有的资源】。
    # 必须放在这里 —— 资源已经复制完，!existing-resources 看到的就是最终状态；
    # 而且它要与 !meta6-for 用同一套判定（共用私有方法，不另写一份）。
    self!write-build-trace($dest, $source, $dist, %build);

    # 计算并写入内容指纹（放在最后：指纹覆盖 META.json + META6.json + lib + resources 全部文件）
    my $digest = self!fingerprint($dest);
    $dest.add('.digest').spurt($digest);
    $digest
}

# 生成 Raku 标准的 META6.json 内容。
# 与我们的 META.json 的差别就在 provides：META6 要求「模块名 => 相对路径」，
# 而 RakuPM::Distribution.provides 只留了模块名（路径在解析索引时就被丢掉了），
# 所以这里得从 lib/ 目录把路径反推回来。
#
# :$source 传进来是为了在 META6.json 里保留 bin 字段（Distribution 没存它，
# 我们从源码目录的 META6.json 直接读；bin 脚本本来在源码里也是必要的）。
method !meta6-for(RakuPM::Distribution $dist, IO::Path $root, IO::Path $source? --> Hash) {
    my %m =
        name      => $dist.name,
        version   => $dist.version,
        auth      => $dist.auth,
        api       => '1',
        # 「模块名 → lib/ 相对路径」已上移到 RakuPM::Distribution（消费侧与生产侧
        # 共用的单一实现处），这里只调用，不再自带一份私有实现。
        provides  => RakuPM::Distribution.provides-with-paths($root, $dist.provides),
        # depends / build-depends / test-depends 必须【原样】保留上游声明的
        # 版本/作者约束，不能只写模块名——否则已安装 META6 退化成裸名，会：
        #   ① 让读 installed 元数据的包/测试拿到错误依赖（Identity::Utils 的
        #      "can we get dependencies from identity" 测试因此挂）；
        #   ② 污染 raku-pm 自己的反向依赖图（Installer.!depends-of 把约束读成 *）。
        # 策略（$source 是上游原始 META6，zef 也是原样保留）：
        #   · 优先照搬源 META6 的对应字段（数组 / 平铺 Hash / depends.<phase>.requires
        #     嵌套结构都原封不动）；
        #   · 源缺失时退回「用归一后 %!depends 重建 module:ver<constraint>」至少保版本
        #     （auth 在归一时被丢弃，此处无法恢复——比裸名强，但仍建议带源保证完整）。
        depends       => self!faithful-depends($dist.depends, $source, 'depends'),
        build-depends => self!faithful-depends($dist.build-depends, $source, 'build-depends'),
        test-depends  => self!faithful-depends($dist.test-depends, $source, 'test-depends'),
        # 只声明「磁盘上真实存在」的资源：声明了却找不到会让 CUR::Installation
        # 装不上，宁可少声明也别瞎声明（文件缺失属于包本身的问题，另说）。
        # 声明清单 = $dist 给的 ∪ 源码 META6.json 写的（见 !declared-resources）。
        #
        # 【注意】这层过滤会把「构建没跑成功 → 资源没生成」的证据一并抹掉。
        # 补偿手段是 build.json 旁车（!write-build-trace）：被剔掉的是哪些，
        # 那边原样记着，verify 才查得出来。
        resources => self!existing-resources(
            $root.add('resources'),
            self!declared-resources($dist, $source)),
        # bin 字段：源码里有 bin 目录就照搬。CUR::Installation 不处理它，但
        # 我们自己的 Installer.!install-bin 靠它来决定要不要建 wrapper。
        bin       => $source.defined ?? self!bin-from-source($source) !! [];
    # builder 也要落进 store 的快照：它是 META6 规范里的合法字段，
    # CUR::Installation 不读它，但「这个包需要构建」是发行版的事实，
    # store 作为完整快照不该丢。丢了的话 verify 就判断不了
    # 「一个没有构建痕迹的条目本来该不该有」（no-build-trace 那条检查用它）。
    # 空值不写，免得几十个纯 Raku 包的 META6 里都挂一个没意义的空字段。
    my $b = $dist.builder;
    %m<builder> = $b if $b.defined && $b.trim.chars;
    %m
}

# 依赖字段（depends / build-depends / test-depends）保真写回 installed META6.json：
# 优先照搬源 META6 的 $source-field 对应键（数组 / 平铺 Hash / depends.<phase>.requires
# 嵌套结构都原样），源缺失时退回「用归一后 %!dep 重建 module:ver<constraint>」，至少保版本。
# 退化成裸模块名会让读 installed 元数据的包/测试拿错依赖，并污染反向依赖图——必须避免。
method !faithful-depends(Associative $dist-dep, IO::Path $source, Str $source-field --> Any) {
    if $source.defined && $source.add('META6.json').e {
        my %s = (try from-json($source.add('META6.json').slurp)) // %();
        my $raw = %s{$source-field};
        return $raw if $raw.defined;
    }
    $dist-dep.kv.map(-> $k, $v { "$k :ver<$v>" }).sort.List
}

# 入库时要写进 META6.json 的 resources 声明清单。
#
# $dist 是【索引条目】构造出来的（各生态索引质量参差，resources 字段可能缺失，
# 早期版本 Ecosystem 构造 Distribution 时干脆漏传了它），而源码目录里的
# META6.json 是这个发行版自己的权威元数据。两者取并集，再交给
# !existing-resources 按磁盘存在性过滤。
#
# 实测案例：Data::Generators 0.1.11 索引里其实写了
# resources=["dfEnglishWords.csv","dfPetNameCounts.csv"]，但因为 Distribution
# 上这一位是空的，store 的 META6.json 里 resources 变成空清单 ——
# 资源文件明明复制过去了，CUR::Installation 却不知道有资源，
# %?RESOURCES<key> 取不到 → 回退成 resources 目录 → 模块 .open 目录即崩
# （现象：zef 装正常，raku-pm 装在激活阶段挂）。这层兜底让「索引不全」不再致命。
method !declared-resources($dist, IO::Path $source? --> List) {
    my @out = |@($dist.resources // ());
    if $source.defined {
        my $m6 = $source.add('META6.json');
        if $m6.e {
            my %meta = (try { from-json($m6.slurp) }) // %();
            my $r = %meta<resources>;
            @out.append($r.keys.sort)  if $r ~~ Hash;
            @out.append($r.map(*.Str)) if $r ~~ Positional;
        }
    }
    @out.unique.List
}

# 读源码目录的 META6.json 的 bin 字段；读不到就空列表。
# 跟 provides/resources 不同：bin 字段是纯字符串数组（路径列表），
# 没必要做磁盘存在性过滤（反正复制那一步已经做了）。
method !bin-from-source(IO::Path $source --> List) {
    my $m6 = $source.add('META6.json');
    return () unless $m6.e;
    my $j = try from-json($m6.slurp);
    return () if $j ~~ Failure || ! $j.defined;     # META6 损坏 → 当没有 bin 字段处理
    my %meta = $j;
    (%meta<bin> // ()).flat.List
}

# 从声明的 resources 清单里挑出真实存在的那些。
# $dist.resources 是元数据里写的（可能不全、可能有笔误），磁盘才是真相。
#
# 【libraries/ 的特殊约定】Rakudo 的 CUR::Installation 把 resources/libraries/
# 下的资源当 native 库：META6 里声明【逻辑名】libraries/<name>（不带 lib 前缀、
# 不带扩展名），安装时按平台找实际文件：
#     Windows  →  <name>.dll            （实测：声明 libraries/libres.bin 找 libres.bin.dll）
#     Linux    →  lib<name>.so          （实测：声明 libraries/libdemo 找 liblibdemo.so！
#                                Rakudo 无条件加 lib 前缀，连名字已带 lib 也不放过）
#     macOS    →  lib<name>.dylib       （按同一约定推断）
# Build 阶段生成的正是这种带平台形状的文件 —— 声明名本身在磁盘上不存在，
# 直接 .e 检查会把它漏掉。
method !existing-resources(IO::Path $res-dir, @declared --> List) {
    return () unless $res-dir.d;
    @declared.unique.grep({ self!resource-exists($res-dir, $_) }).sort.List
}

method !resource-exists(IO::Path $res-dir, Str $name --> Bool) {
    return True if $res-dir.add($name).e;
    # 只有 libraries/ 子树走平台形状匹配；其他目录保持严格存在性检查
    return False unless $name.starts-with('libraries/');
    # lib 前缀要加在【叶子名】上：$name 是 'libraries/mydemo' 这样的完整相对路径，
    # 直接 "lib$name.so" 会拼出 libraries/liblibraries/mydemo.so（WSL 上踩过）。
    my ($dir-part, $leaf) = $name.split('/', 2);
    my @shapes = (
        "$leaf.dll", "$leaf.so", "$leaf.dylib",
        "lib$leaf.so", "lib$leaf.dylib", "lib$leaf.dll",
    ).map({ "$dir-part/$_" });
    for @shapes -> $c {
        return True if $res-dir.add($c).e;
    }
    False
}

# 写构建痕迹「旁车」build.json。
#
# 【它要解决的正是「查不出来」】
# !meta6-for 只声明磁盘上真实存在的资源（必须如此，否则 CUR::Installation 装不上），
# 于是「构建没跑成功 → 声明过的 resources 压根没生成」在 store 的 META6.json 里
# 被静默剔除。事后看那份 META6 干干净净，`raku-pm verify` 无从判断。
# 这里把【被剔掉的是什么】原样记下来：
#   resources-declared  元数据声明要有的（$dist ∪ 源码 META6）
#   resources-present   实际进 store 的
#   resources-missing   声明了却没有的  ← 构建多半没跑成功（此前完全不留痕）
# 另有 build.* 记「构建阶段本身做了什么」（见 RakuPM::Builder.facts）。
#
# 【为什么是旁车、且不计入内容指纹】
# 它是「条目怎么产出的」的记录，不是发行版内容：不计入指纹（!fingerprint 的
# skip-names 里有它），所以时间戳这类自然变动不会让 verify 误报「内容已被修改」；
# 它也不进 CUR::Installation 的视野（那个只读 META6.json 声明的东西）。
method !write-build-trace(IO::Path $dest, IO::Path $source,
                          RakuPM::Distribution $dist, %build --> Nil) {
    my $res-dir   = $dest.add('resources');
    my @declared  = self!declared-resources($dist, $source).unique.sort;
    my @present   = @declared.grep({   self!resource-exists($res-dir, $_) }).List;
    my @missing   = @declared.grep({ ! self!resource-exists($res-dir, $_) }).List;

    $dest.add('build.json').spurt(to-json(%(
        at   => DateTime.now.Str,
        raku => $*EXECUTABLE.Str,
        # 编译器【发行版号】（如 2026.08）—— 别用 $*RAKU.version，那是语言版本
        # （6.d），对「预编译指纹/ABI 是否同一个 raku」这类诊断没用。
        # 取不到就留空：宁可没有证据，也不留假证据。
        raku-version       => ((try $*RAKU.compiler.version.Str) // ''),
        raku-lang          => ((try $*RAKU.version.Str) // ''),
        build              => %build,
        resources-declared => @declared.List,
        resources-present  => @present,
        resources-missing  => @missing,
    ), :sorted-keys));
}

# 原 !provides-with-paths（模块名 → lib/ 相对路径）已上移到
# RakuPM::Distribution.provides-with-paths —— 那里是「发行版 ↔ 磁盘文件」的
# 归属地，消费侧（本类入库写 META6.json）与生产侧（refresh / check / dist）
# 共用一份。反方向 RakuPM::Distribution.scan-provides（扫 lib/ 反推模块名）也在那儿。

# 从 store 读出一个 Distribution
method get(Str $name, Str $version --> RakuPM::Distribution) {
    die "store 中没有 $name $version" unless self.has($name, $version);
    RakuPM::Distribution.from-meta-file(self.path-for($name, $version).add('META.json'))
}

# 校验某个已缓存包的内容是否被篡改
method verify(Str $name, Str $version --> Bool) {
    my $dir = self.path-for($name, $version);
    my $digest-file = $dir.add('.digest');
    return False unless $digest-file.e;
    my $stored = $digest-file.slurp.trim;
    # 主路径：内容指纹（不含 .precomp）。包被加载后 Rakudo 会在 store 目录里
    # 重新生成 .precomp，但它只是派生产物，不该让「内容是否被篡改」误报。
    # 见下方 !fingerprint / !collect-files 对 .precomp 的排除。
    my $fp = self!fingerprint($dir);
    return True if $fp eq $stored;
    # 旧条目兼容：早期 !copy-tree 没有跳过 .precomp，那时的 .digest 是「含
    # .precomp」算出来的。若内容指纹对不上、但把 .precomp 算进去能对上，
    # 说明是旧条目而非被篡改 —— 接受，并把 .digest 重写为内容指纹完成迁移，
    # 之后就不再走这条兼容分支。
    if $dir.add('.precomp').d {
        my $fp2 = self!fingerprint($dir, :include-precomp);
        if $fp2 eq $stored {
            try $digest-file.spurt($fp);   # 迁移：重写为内容指纹
            return True;
        }
    }
    False
}

# 读取已记录的内容指纹
method digest-of(Str $name, Str $version --> Str) {
    my $f = self.path-for($name, $version).add('.digest');
    $f.e ?? $f.slurp.trim !! ''
}

# 从 store 移除某个版本（清理缓存）
method remove(Str $name, Str $version --> Nil) {
    my $dir = self.path-for($name, $version);
    rm-tree($dir) if $dir.d;
    # 该发行版已无任何版本时，清掉空目录
    my $parent = $!root.add(self!safe-name($name));
    $parent.rmdir if $parent.d && !$parent.dir.elems;
}

# 内容指纹：对 META.json + 所有 lib 下文件做 MD5
# 借鉴 nix 的「内容寻址」思想：内容变了指纹就变，可用于防篡改与缓存失效
#
# 默认【排除 .precomp】：它是预编译字节码——派生产物，包被加载时 Rakudo 会
# 在 store 目录里重新生成，不是发行版内容。指纹一旦把它算进去，正常重装/复用
# 就会因 .precomp 漂移而误报「内容已被修改」（install 复用同一版本被拦死就是这个
# 原因）。:include-precomp 仅用于 verify 对旧条目的兼容回退。
method !fingerprint(IO::Path $dir, Bool :$include-precomp = False --> Str) {
    # 遍历统一走 RakuPM::Fs.walk-files（急切收集目录句柄 + 按绝对路径稳定排序）。
    # 【跳过规则对历史条目逐字兼容】：只跳 .digest（自指）、.precomp（派生产物；
    # :include-precomp 时连它一起收，供 verify 对老条目做兼容回退）与 build.json
    # （构建痕迹「旁车」——是「条目怎么产出的」的记录，不是发行版内容；它带时间戳，
    # 计入指纹就会每次重算都漂移、误报「内容已被修改」）。
    # 新增 build.json 到跳过名单【不会改变任何历史条目的指纹】——老条目里没有这个
    # 文件，跳到不存在的东西等于没跳。故此处调整是安全的（与 0.41.x 那次不同）。
    # 刻意【不】套用 Fs 的默认 VCS 跳过 —— 内容指纹的值必须与历史条目逐位一致，
    # 否则所有已入库条目都会被判「内容已被修改」而触发全量重新入库。
    my @skip-dirs = $include-precomp ?? ().List !! ('.precomp',).List;
    my @files = walk-files($dir, :skip-dirs(@skip-dirs),
                           :skip-names(['.digest', 'build.json']))
                    .map({ .relative($dir).Str }).sort;
    my @parts;
    for @files -> $rel {
        @parts.push($rel);
        # md5-file 是大文件加速的统一入口：≥64KB 走系统 md5 命令，否则纯 Raku，
        # 见 RakuPM::MD5。指纹语义不变，只是不再对每个文件全量跑纯 Raku MD5。
        @parts.push(md5-file($dir.add($rel)));
    }
    md5-hex(@parts.join("\0").encode('utf-8'))
}

# 文件遍历 / 复制 / 删除统一在 RakuPM::Fs（原先本类各私有一份，
# 与 Installer / Cleaner / Git 重复，跳过规则与异常兜底互不一致）。

# md5-file / md5-hex 来自 RakuPM::MD5。md5-file 对 ≥64KB 文件走系统 md5 命令
# 加速（内容指纹语义不变，指纹值与纯 Raku 版 / 生态版 Digest::MD5 完全一致），
# 老 store 条目兼容。

# 收进 store 时的目录复制走 Fs.copy-tree，它跳过 .precomp：
# 预编译字节码是派生产物，装包时会重新生成，不是发行版内容。实测一份 RakuPM：
# 源码 lib 224KB，而 lib/.precomp 有 3.8MB（49 个文件）＝ 17 倍。收进来只会让
# store 无谓膨胀，更要命的是内容指纹得把这 3.8MB 全读一遍算哈希（纯 Raku MD5
# 只有 ~0.2MB/s），单版本就要十几秒 —— `raku-pm store` 在多版本 RakuPM 上
# 「卡住」就是它。
#
# 注意：!fingerprint 也跳过 .precomp（见上），因此指纹只覆盖「源码」而非预编译
# 产物，store 条目无论新旧都不会因 .precomp 漂移而误报篡改。早期版本（!copy-tree
# 还没跳过 .precomp 时）写下的 .digest 是「含 .precomp」的，verify 里保留了对
# 它们的兼容回退（含 .precomp 重算一次对上就接受并迁移成内容指纹）。
