# RakuPM::InstallOptions — 安装链的选项载体（替代 7+ 个布尔开关逐层抄写）
#
# 【为什么要有这个类】
# 安装链是 install → install-from-git / install-from-dir → !install-local-dist
# → !install-chain → !install-chain-inner → !ensure-phase-deps / !ensure-git-deps，
# 共 6 层。原先每个方法签名里都把同一批布尔开关（no-test / no-build /
# no-test-deps / no-native-check / force / allow-test-failure / mark-explicit）
# 重新抄一遍，于是：
#   · 加一个新开关要改 6 处（`--no-test-deps` 那次就改了 6 处才真正生效）；
#   · 漏抄一处就出现「开关传了但不起作用」——这是本项目实际发生过的 bug：
#       !ensure-git-deps 漏传 :no-native-check
#       !ensure-phase-deps 漏传 :no-native-check 与 :allow-test-failure
#     后果是「git 依赖 / 构建依赖 / 测试依赖」这几条子链不认用户的开关，
#     仍会跑本机库检查并可因此 die、把整条链回滚。
# 收成一个对象后，链上只需传一个参数，**结构性消灭**了这类漏传。
#
# 【不可变】with() 返回副本而不原地改：同一条链上不同阶段需要不同组合
# （例如依赖子链要 mark-explicit=False，测试子链要 no-test-deps 生效），
# 原地改会污染外层、造成难查的串味。
#
# 零依赖：只用 Raku 内置属性，任何模块都能安全 use。
#
# 【Issue 9 扩展】原类只承载 install 链的用户/内部布尔开关。本版把分散在
# install / uninstall / reinstall 各入口的零散策略（`--pin` / `--recursive` /
# `--keep-store` / `--test-jobs` / `--test-timeout`）也收进来，统一成一个
# 载体，消除「install 链里 %pins 另成一条并行线程、test-jobs/timeout 又走
# Client 实例属性」的割裂。详见 REFACTOR-ISSUES.md Issue 9。

unit class RakuPM::InstallOptions;

# ---- 用户可见的开关（对应 CLI 同名旗标）----
has Bool $.no-test            = False;   # 跳过测试阶段
has Bool $.no-build           = False;   # 跳过构建阶段（Build.pm / META6 builder）
has Bool $.no-test-deps       = False;   # 跳过「测试依赖」的安装（仅测试期生效）
has Bool $.no-native-check    = False;   # 跳过本地库（:from<native> 与运行时 is native）探测
has Bool $.force              = False;   # 已装的照常重走构建/测试/安装，不跳过
has Bool $.allow-test-failure = False;   # 测试失败只警告不中止（软通过）
has Bool $.locked             = False;   # --locked：锁文件缺失或与解析结果不符即报错
has Bool $.dry                = False;   # 只解析不落盘
has Bool $.no-lock            = False;   # 跳过跨进程写锁（逃生舱）

# ---- 内部开关（不对应 CLI 旗标，由链内部决定）----
# mark-explicit：本次链的目标包是否标成「用户点名要的」（explicit）。
#   依赖子链（构建/测试依赖、git 依赖）必须传 False —— 它们是「为了别人才装的」，
#   标成 explicit 会导致卸掉目标包之后它们永远回收不掉（autoremove 的判据）。
has Bool $.mark-explicit      = True;

# ---- Issue 9 新增：跨 install / uninstall / reinstall 的零散策略收敛 ----
# pins：--pin 钉版表（模块名 => 版本约束）。install 链解析依赖时按它把对应模块
#   钉死到指定版本。原先是 install 家族方法签名里的 `:%pins` 独立线程，逐层转发；
#   收进本类后，链上只需读 $opts.pins，不再有第二条并行通道。
has Hash $.pins             = %();   # --pin Mod@ver（可多次）；install 链解析依赖时钉版
# test-jobs：测试并发度（0 = 自动，沿用 Tester 默认；>0 时覆写）。
has Int  $.test-jobs        = 0;     # --test-jobs N（0=auto）
# test-timeout：单测试超时（秒，0 = 用默认/环境变量；>0 时覆写）。
has Int  $.test-timeout     = 0;     # --test-timeout N（秒，0=默认）
# recursive：卸载/重装被依赖的包时，把依赖它的包也一并卸掉。
#   仅 uninstall / reinstall 侧生效，install 链忽略。
has Bool $.recursive        = False; # --recursive（uninstall/reinstall）
# keep-store：卸载时保留 store 快照（不删源码缓存，给「秒级离线重装」等高级场景）。
#   仅 uninstall 侧生效，install 链忽略。
has Bool $.keep-store       = False; # --keep-store（uninstall）

# 派生一份改了若干项的副本。用法：$opts.with(:mark-explicit(False))
# 参数用 *%over（任意命名参数），键名与属性名一致（连字符写法如 :no-test-deps）。
method with(*%over --> RakuPM::InstallOptions) {
    my %h =
        'no-test'            => $!no-test,
        'no-build'           => $!no-build,
        'no-test-deps'       => $!no-test-deps,
        'no-native-check'    => $!no-native-check,
        'force'              => $!force,
        'allow-test-failure' => $!allow-test-failure,
        'locked'             => $!locked,
        'dry'                => $!dry,
        'no-lock'            => $!no-lock,
        'mark-explicit'      => $!mark-explicit,
        'pins'               => $!pins,
        'test-jobs'          => $!test-jobs,
        'test-timeout'       => $!test-timeout,
        'recursive'          => $!recursive,
        'keep-store'         => $!keep-store,
    ;
    for %over.kv -> $k, $v { %h{$k} = $v }
    RakuPM::InstallOptions.new(|%h)
}

# 便于日志/调试：一行列出所有为真的开关（全默认时返回 '(默认)'）。
method describe(--> Str) {
    my @on;
    for <no-test no-build no-test-deps no-native-check force allow-test-failure
         locked dry no-lock> -> $name {
        @on.push('--' ~ $name) if self."$name"();
    }
    @on.push('mark-explicit=False') unless $!mark-explicit;
    # Issue 9 新增字段：仅在「非默认」时才列出，避免默认噪音。
    @on.push('--test-jobs=' ~ $!test-jobs)       if $!test-jobs > 0;
    @on.push('--test-timeout=' ~ $!test-timeout) if $!test-timeout > 0;
    @on.push('--pin(' ~ $!pins.elems ~ ')')      if $!pins.elems;
    @on.push('--recursive')                      if $!recursive;
    @on.push('--keep-store')                     if $!keep-store;
    @on.elems ?? @on.join(' ') !! '(默认)'
}
