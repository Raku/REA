# RakuPM::Client::Tester — role（从 RakuPM::Client 拆出）

use RakuPM::Distribution;
use RakuPM::InstallOptions;
# 平台判断统一走 RakuPM::Platform（唯一读 $*DISTRO 的地方，可被测试遮蔽）。
# 必须在下面这个 sub 之前 use —— 它就用了 is-windows()。
use RakuPM::Platform;

# 识别「Windows 平台上的已知上游测试失败」。
# 这类失败与 raku-pm 无关、也不影响包的实际使用，安装时在 Windows 上自动软通过
# （见 Tester.!run-tests），不让一个上游 bug 阻断 Windows 上的安装。
#
# 判定规则外置在 lib/RakuPM/Client/known-windows-test-failures.json（JSON 数组），
# 社区无需改代码即可贡献新规则；每条规则字段：
#   name             : 包名（精确匹配，如 "Log::Async"）
#   test-starts-with : 测试文件名前缀（可选，如 "12-context"）
#   test-contains    : 测试文件名子串（可选，与上面二选一）
#   contains         : 失败输出里需出现的子串列表（任一命中即匹配失败特征；必填）
# 判定必须够窄（具体包 + 测试文件 + 失败特征 + Windows），绝不泛化，避免真 bug
# 被静默掩盖。
#
# ⚠️ 文件缺失兜底（0.64.3 修复）：known-windows-test-failures.json 不在 META6
# provides 里（provides 只列 .rakumod），安装到 site/ 时不会被拷过去；而 self-upgrade
# 跑测试时 Tester 可能从【已安装的 site】加载，导致 $?FILE 兄弟文件不存在、规则集被
# 掏空 → Windows 上 is-known-windows-test-failure 误返 False → 该软通过的没软通过、
# 安装被无辜回滚（0.64.2 的 self-upgrade --force 在原生 Windows 上就栽在这）。故这里
# 先塞一份【内置兜底规则】，文件存在时再叠加社区规则；文件缺失不再退化为「无规则」。
# 可用 RAKUPM_KNOWN_FAILURES_JSON 覆盖路径（测试 / 高级用户用）。
my @BUILTIN-KNOWN-WINDOWS-FAILURES = (
    { name => 'Log::Async', 'test-starts-with' => '12-context',
      contains => ['Log\Async.rakumod', 'Log/Async.rakumod'] },
);
my @KNOWN-WINDOWS-FAILURES := do {
    my @rules = @BUILTIN-KNOWN-WINDOWS-FAILURES;   # 内置兜底，永不为空
    my $path = (%*ENV<RAKUPM_KNOWN_FAILURES_JSON> // '').chars
        ?? %*ENV<RAKUPM_KNOWN_FAILURES_JSON>.IO
        !! $?FILE.IO.sibling('known-windows-test-failures.json');
    if $path.e && $path.r {
        try {
            my @raw = from-json($path.slurp);
            for @raw -> %r {
                next unless %r ~~ Hash;
                @rules.push(%r);
            }
        }
    }
    @rules;
};

sub is-known-windows-test-failure(Str $dist-name, Str $test-basename, Str $output --> Bool) is export {
    # 仅 Windows 需要识别（Linux/macOS 上这些用例本就通过）。
    return False unless is-windows();
    return False unless @KNOWN-WINDOWS-FAILURES.elems;
    # 二次确认失败特征前，先把 Raku 测试框架转义的双反斜杠还原成单反斜杠。
    # 关键陷阱（0.36.17 修复）：失败输出来自上游 is-deeply 的 diag，Raku 会把
    # 反斜杠转义渲染成 \\（双反斜杠）；而我们要匹配的是 Windows 实际路径里的单
    # 反斜杠。若不先还原，实测会漏匹配 → 该软通过的没软通过、安装被无辜回滚
    # （t/known-test-failure.t 的夹具已改用真实双反斜杠形态，专抓这个回归）。
    my $norm = $output.subst(:global, '\\\\', '\\');
    for @KNOWN-WINDOWS-FAILURES -> %r {
        # ① 包名精确匹配
        next unless (%r<name> // '') eq $dist-name;
        # ② 测试文件名过滤（可选）
        if %r<test-starts-with>:exists && (%r<test-starts-with> // '').Str.chars {
            next unless $test-basename.starts-with(%r<test-starts-with>.Str);
        }
        if %r<test-contains>:exists && (%r<test-contains> // '').Str.chars {
            next unless $test-basename.contains(%r<test-contains>.Str);
        }
        # ③ 失败特征：contains 列表里任一子串出现在归一化输出即命中
        my @needles = %r<contains> ~~ Array ?? %r<contains>.list !! ();
        next unless @needles.elems;
        for @needles -> $n {
            return True if $norm.contains($n.Str);
        }
    }
    return False;
}

use RakuPM::Fs;
use JSON::Fast;
unit role RakuPM::Client::Tester;

# ---------------- 测试阶段实时进度（只碰 stderr，绝不改 stdout / 日志）----------------
# 【为什么需要】测试阶段有两段「长静默」：① 串行预热预编译（逐文件 -c，无输出）；
# ② 并发跑测试（结果先收集、跑完才汇总打印）。合起来可能几分钟毫无动静，用户会
# 以为卡死。这里在 stderr 上用 `\r` **原地重画一行**进度（计数 + 百分比 + 当前文件），
# 让终端始终有动静。
# 【为什么零风险】只有 stderr 是终端（真人在终端里跑）才显示 —— 管道 / 重定向 /
# 测试捕获（$*ERR.t 为 False）时整段静默，stdout 与既有断言、日志文件都不受影响。
# RAKUPM_TEST_PROGRESS=1 强制开、=0 强制关（CI 里想显式关掉时用）。
method !progress-on(--> Bool) {
    my Str $env = (%*ENV<RAKUPM_TEST_PROGRESS> // '').trim;
    return False if $env eq '0';
    return True  if $env eq '1';
    (try { $*ERR.t }) // False
}

# 在 stderr 上原地重画一行；返回本次文本，供下次清除时算需要覆盖的宽度。
method !progress-line(Str $text, Str $prev --> Str) {
    my Int $pad = $prev.chars > $text.chars ?? $prev.chars - $text.chars !! 0;
    $*ERR.print("\r" ~ $text ~ (' ' x $pad));
    $*ERR.flush;
    $text
}

# 擦掉进度行（留白覆盖 + 光标归位），免得残影盖住随后 stdout 的正常输出。
method !progress-clear(Str $prev --> Nil) {
    return unless $prev.chars;
    $*ERR.print("\r" ~ (' ' x $prev.chars) ~ "\r");
    $*ERR.flush;
}

# 组装一行进度文本：`测试 3/12  25%  ✓ 02-gc.rakutest`
method !progress-text(Int $done, Int $total, %r --> Str) {
    my Int $pct = $total > 0 ?? (100 * $done / $total).round !! 100;
    my Str $mark = (%r<ok> // False) ?? '✓' !! '✗';
    "    测试 {$done}/{$total}  {$pct}%  {$mark} {%r<test>.basename}"
}

# 在源码目录上运行 t/ 下的测试（用 raku -I 同时加载源码 lib 与已装依赖）。
# 任一测试失败即中止安装（除非调用方已传 :no-test 跳过，或 :allow-test-failure
# 软通过 —— 后者只打 warning 不中断，给已知平台 bug 留逃生口）。
method !run-tests(RakuPM::Distribution $dist, IO::Path $source,
                  Bool :$allow-test-failure = False,
                  RakuPM::InstallOptions :$opts --> Nil) {
    my @tests = self.test-files($source);
    return unless @tests.elems;

    # 并发度：0 = auto = 按 CPU 核数并行（默认就并行，不再为躲竞态而永远串行）。
    # 并发会让多个 raku 子进程同时首次编译同一份 lib/*.rakumod（及其依赖），偶发
    # 触发 rakudo 预编译缓存竞态（表现为某测试文件报 "===SORRY!=== Error while
    # compiling" 却能串行复验通过）。两道安全网已就位、故可默认并行：
    #   ① 下面「防御性预热」（仅 $jobs>1 时）先把每个文件 -c 编译一遍把 precomp 写热；
    #   ② 跑完再对失败用例做【串行复验】，竞态/时序敏感假失败会被剔除。
    # 显式 --test-jobs=N 可覆盖（设 1 = 完全串行）。zef 串行是按生态主流，raku-pm
    # 选择默认并行以利用多核，代价由上述安全网吸收。
    # 并发度：0 = auto = 按 CPU 核数并行（上限 8）。优先级：CLI --test-jobs
    # （走 $opts.test-jobs）> 环境变量 RAKUPM_TEST_JOBS > 自动按 CPU 核数。
    # 设 1 = 完全串行。默认并行以利用多核，预编译竞态由预热 + 串行复验两道安全网吸收。
    my $env-jobs = (try (%*ENV<RAKUPM_TEST_JOBS> // 'auto').Int) // 0;
    my $jobs = $opts.test-jobs > 0 ?? $opts.test-jobs
             !! ($env-jobs > 0 ?? $env-jobs !! min(cpu-cores, 8));
    $jobs max= 1;
    # 单测试超时（秒）：CLI --test-timeout（走 $opts.test-timeout）> 环境变量
    # RAKUPM_TEST_TIMEOUT > 默认 300。超时即 kill 子进程并判该文件失败（含复验）。
    my $env-timeout = (try (%*ENV<RAKUPM_TEST_TIMEOUT> // 300).Int) // 300;
    my $timeout = $opts.test-timeout > 0 ?? $opts.test-timeout !! $env-timeout;

    # 终端里显示实时进度（stderr 原地重画一行；非 TTY 自动静默 —— 见 !progress-on）。
    my Bool $progress = self!progress-on();

    say "  · 运行测试：{$dist.name} {$dist.version}（{@tests.elems} 个文件，并发 $jobs）";
    # 立刻刷出这一行：否则块缓冲会把它压到随后的进度行之后（看起来像「先跑后说」）。
    $*OUT.flush if $progress;
    my $lib       = $source.add('lib');
    # 依赖从 CUR::Installation 里加载（inst# 前缀不可省，否则读不到多版本元数据）
    my $repo-spec = self.installer.raku-lib-spec;
    # 整树事务化期间的暂存 CUR：构建/测试期间所有包（含其依赖）都只装进它、
    # 尚未晋升到真实 site。必须把它的 inst# 前缀作为【独立 -I】放在最前——
    # ① 本包（native 包）只有从 CUR 加载时 %?RESOURCES 才被填充，平铺 -I lib
    #    加载时 %?RESOURCES 是 Nil，native 包 is native(Nil) 会报
    #    "expected IO::Path but got Slip (Empty)"（GDBM 现场）；② 本包的运行时/
    #    测试依赖若此刻只在暂存 CUR 里（尚未晋升），也必须从这里解析。
    # 事务未开启（standalone `raku-pm test .`）时 pending 为空串，不注入，
    # 退回原 -I lib + 真实 site 行为（零行为变化）。
    my $pending   = self.installer.pending-lib-spec;

    # @inc 顺序很关键：pending CUR（若有）放在【最前】，让 `use <本包>` 与依赖都
    # 优先从暂存 CUR 解析；其余路径保持原样：源码 lib、t/lib、最终 target CUR（inst#）。
    my @inc;
    @inc.push('-I', $pending) if $pending.chars;
    @inc.push('-I', $lib.Str);
    @inc.push('-I', $source.add('t/lib').Str) if $source.add('t/lib').d;
    @inc.push('-I', $repo-spec);

    # 日志目录：<日志根>/log/<dist-name>/<version>/<test-basename>.log
    # 默认日志根 = 安装目标目录（即 <target>/log/...，随安装目标走，重装隔离）；
    # 设 RAKUPM_TEST_LOG_DIR 可把日志根改到全局位置（如 ~/.raku-pm），便于跨
    # target 集中查看测试日志。每个测试文件的完整输出都落盘（重装覆盖），
    # 前台只显示成败与失败首行（嵌套编译错误例外，见 !failure-lines）。
    my $log-root = (%*ENV<RAKUPM_TEST_LOG_DIR> // '').chars
        ?? %*ENV<RAKUPM_TEST_LOG_DIR>.IO
        !! self.target;
    my $log-dir = $log-root.add('log').add($dist.name).add($dist.version);

    # 防御性预热：仅「并发且多测试文件」时，先串行把每个文件【编译一遍】
    # （-c 只编译不执行），把共享模块 / 依赖的 precomp 缓存写热，消除并发首跑时
    # 多个进程同时首次编译同一份 lib/*.rakumod 的竞态（表现为偶发的
    # "===SORRY!=== Error while compiling" 却被串行复验误当用例本身 flaky）。
    # 设 RAKUPM_NO_PRECOMP_WARMUP 可跳过（回归 / 调试用）。
    #
    # 注意：0.64.4 起默认已是【并行】（auto = 按 CPU 核数，上限 8），因此这段
    # 【默认就会执行】—— 它正是并行默认路径的安全网，在并发首跑前把共享 precomp
    # 写热、从根上消除竞态。用户显式 `--test-jobs=1` 或设 RAKUPM_NO_PRECOMP_WARMUP
    # 时这段才跳过。
    if $jobs > 1 && @tests.elems > 1 {
        self!warmup-precomp(@tests, @inc, $source, :$progress);
    }

    # 并发跑所有测试文件（每文件一个独立子进程，进程隔离但非沙箱）
    my @results = self!run-tests-concurrent(@tests, @inc, $source, $log-dir, $jobs, :test-timeout($timeout), :$progress);

    # ---- 前台汇总：通过打 ✓；失败印【最有信息量的几行】（完整输出仍进日志）----
    # 具体挑哪几行见 !failure-lines：默认仍只印首个非空行，唯独「嵌套编译错误」
    # 会把真正的病因行挑出来（原因见那里的注释）。
    my @fails;        # 收集「复验也挂」的用例文件名
    my @fail-outputs; # 对应的完整输出，用于识别「已知平台 bug」
    for @results -> %r {
        if %r<ok> {
            say "    ✓ {%r<test>.basename}";
        }
        else {
            note "    ✗ {%r<test>.basename}";
            for self!failure-lines(%r<output>) -> $l {
                note "    | $l";
            }
            @fails.push(%r<test>.basename);
            @fail-outputs.push(%r<output>);
        }
    }

    # ---- 失败用例串行复验一次：区分「假失败」与「真失败」 ----
    # raku-pm 认定的「假失败」有两种来源，**串行复验对两者都可能翻盘**：
    #   ① 并行（--test-jobs>1）时多个 raku 子进程同时【首次编译】同一份
    #      lib/*.rakumod，偶发触发 rakudo 预编译缓存竞态：某个测试文件报
    #      "===SORRY!=== Error while compiling" 却能在串行重跑时通过；
    #   ② 上游测试自己就是 flaky 的 —— 实测 Concurrent::Stack 1.3 的
    #      stress.rakutest 连跑 10 次挂 3 次（上游 push/pop 竞态丢数据）。
    #      那是上游 bug，但用户不该为一个概率性失败而装不上包。
    # 所以【两种模式下都复验】：复验仍挂才算真失败。
    # 代价：真实失败会多跑一遍（只发生在失败路径上，可接受；不能为了省这一遍
    # 而把 ② 类假失败变成安装失败）。0.64.4 起默认即并行，首跑确实并发，
    # 故提示语写「并发首跑」是准确的（见下方 ✓ 文案）；唯一要避免的是把复验通过
    # 一律归因为「用例本身 flaky」—— 首跑失败也可能是编译/环境瞬时问题（日志已保留）。
    if @fails.elems {
        say "    ↻ 串行复验 {@fails.elems} 个失败用例一次（并行编译竞态 / 上游 flaky 都可能）";
        my @still-fail;
        my @still-outputs;
        for @fails -> $name {
            my %orig = @results.first({ .<test>.basename eq $name });
            # :serial + :log-suffix('.flake') —— 复验这轮不再重复打印「缺命令」提示，
            # 且复验日志写 <name>.flake.log，不覆盖首跑的失败日志（保留诊断线索）。
            my %r2 = self!run-one-test-async(%orig<test>, @inc, $source, $log-dir,
                                            :serial, :log-suffix('.flake'),
                                            :test-timeout($timeout));
            if %r2<ok> {
                # 注意：首跑失败可能是编译错误/环境瞬时问题，不一定是「用例本身不稳定」，
                # 措辞不要下此定论；首跑全文保留在 <name>.log 供事后查看。
                say "    ✓ $name（复验通过 —— 并行首跑的失败判定为假失败，已忽略；首跑日志保留在 {$name}.log）";
            }
            else {
                @still-fail.push($name);
                @still-outputs.push(%r2<output>);
            }
        }
        @fails = @still-fail;
        @fail-outputs = @still-outputs;
    }

    if @fails.elems == 0 {
        return;  # 全过（含复验翻盘的 flake）
    }

    if $allow-test-failure {
        # 软通过：把失败用例列在 warning 里给用户看，不中断 install。
        # 用例场景：Log::Async 0.0.17 的 t/12-context.rakutest 在 Windows 上
        # 必挂（Log::Async::Context.generate 用 .contains('Log/Async') 过滤
        # 自己的帧，Windows 路径是 Log\Async，正斜杠子串匹配不上 → 把模块
        # 自己的帧当 caller 返回 —— 这是 Log::Async 上游 bug，不是 raku-pm 的）。
        note "⚠ 测试失败：{$dist.name} 有 {@fails.elems} 个用例未通过（--allow-test-failure 软通过）：";
        for @fails -> $n { note "    · $n" }
        note "  这通常意味着上游包有平台特定的已知 bug。";
        note "  完整日志在：$log-dir";
        return;
    }
    # 全部失败都能识别为「Windows 平台上的已知上游 bug」→ 自动软通过，
    # 不让一个与 raku-pm 无关的上游 bug 阻断 Windows 上的安装。判定够窄
    # （具体包 + 测试文件 + 失败特征），真 bug 不会被掩盖。Linux/macOS 上
    # 这些用例本就通过，不会走到这里。
    my $combined = @fail-outputs.join("\n");
    if @fails.map(-> $fn { is-known-windows-test-failure($dist.name, $fn, $combined) }).all {
        note "⚠ 测试失败：{$dist.name} 有 {@fails.elems} 个用例未通过，但被识别为";
        note "  Windows 平台上的已知上游 bug（不影响包的实际使用），已自动软通过：";
        for @fails -> $n { note "    · $n" }
        note "  （例：Log::Async 的 t/12-context.rakutest 用 .contains('Log/Async')";
        note "   过滤调用帧，Windows 反斜杠路径匹配不上 → 把模块自己的帧当 caller 返回）";
        note "  完整日志在：$log-dir";
        return;
    }
    self!hint-missing-tool($combined);
    die "测试失败：{$dist.name} 有 {@fails.elems} 个用例未通过（已自动重试过一次；"
      ~ "完整日志在 $log-dir；仍要用 --no-test 跳过，或用 --allow-test-failure 软通过）";
}

# 一个源码目录里所有测试文件（t/*.t 与 t/*.rakutest）。
# 两种扩展名都要收：老包用 t/foo.t，新包（zef 生态主流）用 t/foo.rakutest。
# 排序让跑的顺序稳定（并发轮与串行复验都一致）。
# 返回 List 而不是惰性 Seq：调用方要 .elems 判空，惰性 Seq 上反复遍历会重读目录
# （Windows 上尤其要避免 —— 目录句柄握在手里会让调用方随后的 rmdir 失败）。
# 公开给 test-dir 用（raku-pm test 要先知道「有没有测试可跑」才好给提示，
# 而不是打一句误导的「✓ 测试通过」）。
# 无 `!` 前缀：role 内的方法默认是公开的，这里保持可被其它 role / 测试直接调用。
method test-files(IO::Path $source --> List) {
    my $t = $source.add('t');
    return () unless $t.d;
    $t.dir.grep({ .extension.lc eq 't' || .extension.lc eq 'rakutest' }).sort.List
}

# 并发跑多个测试文件：用 Channel 当信号量限制同时跑的子进程数（上限 $jobs）。
# 每个文件交给 !run-one-test-async（异步、进程隔离、带超时）；返回结果列表。
# $jobs <= 1 时退化为纯串行（与旧版行为一致，便于对照/调试）。
method !run-tests-concurrent(@tests, @inc, IO::Path $source, IO::Path $log-dir,
                             Int $jobs, :$test-timeout, Bool :$progress = False --> Array) {
    my Int $total = @tests.elems;

    # 串行路径（--test-jobs=1）：逐文件跑、逐文件刷新进度。
    if $jobs <= 1 {
        my @rs;
        my Str $cur = '';
        for @tests.kv -> $i, $test {
            my %r = self!run-one-test-async($test, @inc, $source, $log-dir, :test-timeout($test-timeout));
            @rs.push(%r);
            $cur = self!progress-line(self!progress-text($i + 1, $total, %r), $cur) if $progress;
        }
        self!progress-clear($cur) if $progress;
        return @rs.Array;
    }

    # worker 池：先放 $jobs 个空闲槽，派发时取一个、子进程跑完释放一个，
    # 从而把并发数稳定压在 $jobs 以内（不会因为 @tests 多就一次性全开）。
    # 注意：$slots.receive 是【同步阻塞】的（返回取到的槽，不是 Promise），
    # 不能 await 它；主线程在此阻塞等待空闲槽，worker 在别的线程跑。
    my $slots = Channel.new;
    $slots.send(True) for ^$jobs;
    my @promises;
    # 进度计数：多个 worker 线程都会自增，用 Lock 把「自增 + 原地重画一行」这一对
    # 操作保护起来，保证同一时刻只有一个线程在写那一行、且计数不丢。
    my $lock = Lock.new;
    my Int $done = 0;
    my Str $cur = '';
    for @tests -> $test {
        $slots.receive;     # 阻塞等一个空闲槽
        @promises.push: start {
            LEAVE $slots.send(True);  # 跑完释放槽
            my %r = self!run-one-test-async($test, @inc, $source, $log-dir, :test-timeout($test-timeout));
            if $progress {
                $lock.protect({
                    $done++;
                    $cur = self!progress-line(self!progress-text($done, $total, %r), $cur);
                });
            }
            %r;
        }
    }
    my @results = await @promises;
    $slots.close;
    self!progress-clear($cur) if $progress;
    @results;
}
# 防御性预热：串行编译每个测试文件（仅编译、不执行），把共享模块与依赖的 precomp
# 缓存写热。动机：运行测试时每个文件是独立 raku 子进程；并发（test-jobs>1）且文件
# 数>1 时，多个进程可能同时【首次编译】同一份 lib/*.rakumod（及其依赖），偶发触发
# rakudo 预编译缓存竞态，表现为某个测试文件报 "===SORRY!=== Error while compiling"
# 却在之后串行复验中通过 —— 这种「假失败」会被复验误当成用例本身 flaky。
# 预热让所有首次编译都发生在【串行】阶段，真实并发轮只读已暖热的缓存，从根上消除
# 这类竞态。预热本身的非致命编译错误不在此拦截（真实测试轮会照样报出并决定是否阻断）。
# 用 -c（compile-only）而非真跑：既暖缓存，又不会重复执行测试、不产生 TAP 输出。
method !warmup-precomp(@tests, @inc, IO::Path $source, Bool :$progress = False --> Nil) {
    return if %*ENV<RAKUPM_NO_PRECOMP_WARMUP>:exists;
    say "    · 预热预编译（串行，{@tests.elems} 个文件，避免并发首编竞态）";
    $*OUT.flush if $progress;
    my Str $cur = '';
    for @tests.kv -> $i, $test {
        # 预热是「串行且全程无输出」最长的一段；逐文件刷一行进度，用户才知道没卡死。
        $cur = self!progress-line(
            "    预热 {($i + 1)}/{@tests.elems} … {$test.basename}", $cur) if $progress;
        # 复用与真实测试轮完全一致的相对调用形态与 :cwd，确保写进的 precomp 缓存
        # 键（编译器 id + 源路径 + 包含路径）与真实轮可复用。
        my $rel  = self.test-invocation-rel-path($test, $source);
        my @cmd  = 'raku', '-c', |@inc, $rel;
        my $proc = Proc::Async.new(|@cmd, :!merge);
        my $out  = '';
        my $err  = '';
        $proc.stdout.tap: -> $c { $out ~= $c };
        $proc.stderr.tap: -> $c { $err ~= $c };
        my $exit;
        try {
            my $p    = $proc.start(:cwd($source.Str));
            $exit = await $p;
            CATCH { default { $exit = (.can('proc') && .proc ?? .proc !! Nil) } }
        }
        # 预热失败（如模块真有编译错误）不致命：真实测试轮会用同一文件再次编译并
        # 按正常逻辑报出 / 软通过；这里不打日志，避免安装日志被预热噪声污染。
    }
    self!progress-clear($cur) if $progress;
}
# 计算测试文件的【调用路径】（相对发行版根目录，zef 语义）。
# 公开方法（无 !）：让回归测试能直接钉死这个契约，不依赖真去跑一个子进程
# （Windows 的 Rakudo 会把 $?FILE 无条件规范化成绝对路径，夹具在 Windows
# 上验不出相对形态，但路径计算本身在哪都能验）。
method test-invocation-rel-path(IO::Path $test, IO::Path $source --> Str) {
    # 注意：这版 Rakudo 没有 relative-to，只有 IO::Path.relative($base)；
    # absolute+relative 是为了不依赖 $test/$source 原本是不是相对形式。
    $test.absolute.IO.relative($source.absolute.IO).Str
}
# 从失败输出里挑【最有信息量的几行】给前台看（完整输出始终进日志文件）。
#
# 【默认契约不变】一般失败只印【第一个非空行】（前台不刷屏，是既有约定，
# xt/tester-defaults.t 与 xt/tester-async.t 都钉着它）。
# 【唯一例外：嵌套编译错误】Raku 编译失败时 stderr 常长这样 ——
#     ===SORRY!=== Error while compiling <测试文件>
#     ===SORRY!=== Error while compiling <模块.rakumod> (Some::Module)
#     Could not find Foo:ver<1.2+>:auth<zef:someone> in: …
# 开头连续几行都是「Error while compiling」外壳，真正的病因在最内层。
# 只印首行 = 把病因完全藏起来；而日志目录在安装失败【回滚】时可能被清空，
# 用户事后根本查不到 —— 实测 SBOM::Raku 0.0.14 就是这种情形：真正的
# "Version must be specified" 被两层 SORRY 外壳挡住，前台只剩一句无信息量的
# "Error while compiling t/…"。
# 故：开头有 ≥2 行连续 SORRY 外壳时，跳过外壳、印从第一行真错误起的最多 3 行。
method !failure-lines(Str $output --> List) {
    my @ln = $output.lines.grep({ .trim.chars });
    return () unless @ln.elems;

    my Int $shell = 0;
    $shell++ while $shell < @ln.elems && @ln[$shell].contains('===SORRY!===');
    # 至少两层外壳才算「嵌套编译错误」；单层 SORRY 本身就是病因，照旧印它。
    return (@ln[0],) unless $shell >= 2 && $shell < @ln.elems;

    my Int $last = ($shell + 2) min (@ln.elems - 1);
    @ln[$shell .. $last].List
}

# 跑单个测试文件（异步、进程隔离、带超时）。
# 返回 %( test => IO::Path, ok => Bool, output => Str, timed-out => Bool )。
# 完整输出写入 $log-dir/<basename>.log，前台只显示成败（失败详情见 !run-tests 汇总 / !failure-lines）。
method !run-one-test-async(IO::Path $test, @inc, IO::Path $source, IO::Path $log-dir,
                           Bool :$serial = False, Str :$log-suffix = '',
                           :$test-timeout --> Hash) {
    # 【关键一】用【相对路径】调用测试文件（zef 语义）。zef 是在发行版根目录下
    # 跑 `raku t/foo.rakutest` 的，不少上游测试会把 $?FILE / callframe 的 file
    # 写进断言 —— 传绝对路径的话编译器记录的就是绝对路径，这类用例【必然】失败，
    # 且重试也没用（不是偶发，是路径形态）。注意：这只能解决「测试自己检查
    # $?FILE」的用例；Log::Async 0.0.17 的 t/12-context.rakutest 在 Windows 上
    # 失败是另一个上游 bug（Context.generate 用 .contains('Log/Async') 过滤调用
    # 帧，反斜杠路径匹配不上），由 !run-tests 的已知平台失败识别去自动软通过，
    # 不是这里能修的。
    my $rel  = self.test-invocation-rel-path($test, $source);
    my @cmd  = 'raku', |@inc, $rel;

    # Proc::Async：子进程对象，提供 stdout/stderr 两个 Supply + start 返回的
    # Proc（含 .kill）。用 :!merge 让 stdout/stderr 各走一个 Supply，分别累加。
    my $proc = Proc::Async.new(|@cmd, :!merge);
    my $out  = '';
    my $err  = '';
    $proc.stdout.tap: -> $chunk { $out ~= $chunk };
    $proc.stderr.tap: -> $chunk { $err ~= $chunk };

    # 【关键二】必须把工作目录切到包自己的源码目录。理由见 !run-tests 注释，
    # 不设 :cwd 会让相对路径与 t/lib 全部错位 —— 那是「zef 能装、raku-pm
    # 装不了」的主因之一（zef 是在发行版根目录跑测试的）。
    # 关键更正（实测）：Proc::Async.new(:cwd) 被静默吞掉（签名是
    # (Proc::Async $:: |)），但 start(:cwd) 生效（签名才带 :$cwd）。这版
    # Rakudo 下只有 start 能传 :cwd，zef 也正是用 start(:cwd)。
    my $timed-out = False;
    my $exit;
    my $p;
    my $finished = False;
    try {
        $p = $proc.start(:cwd($source.Str));
        # 取真实 PID：Proc::Async.start 返回的是 Promise，pid 本身也是个 Promise，
        # 必须 await 一下才能拿到整数 PID（供 Windows 的 taskkill 用）。
        my $pid = await $proc.pid;
        # 超时看门狗：到点强制杀掉子进程。
        # 具体怎么杀是平台差异（Windows 上 Proc::Async.kill 对所有信号都无效，
        # 必须 taskkill /F /T；Unix 用 SIGKILL）→ 走 RakuPM::Platform.kill-tree。
        # 【传 $proc 而不是 $p】：$p 是 start() 返回的 Promise，它没有 .kill；
        # 曾经 Unix 分支传的就是 $p，`try $p.kill(9)` 被静默吞掉 →
        # Linux 上的看门狗从未生效（Windows 走 taskkill 所以一直没暴露）。
        # 用 $finished 守卫：进程已正常退出就不再杀，否则一个很快通过的测试
        # 也会被误判超时。
        my $timer = Promise.in($test-timeout).then: {
            return if $finished;
            $timed-out = True;
            kill-tree($proc, $pid);
        };
        $exit = await $p;
        $finished = True;
        CATCH { default {
            $finished = True;
            # 正常测试失败（exit ≠ 0）也会让 Proc::Async.start 的 Promise 破裂，
            # 这【不是】启动失败：异常带 .proc（X::Proc::Unsuccessful），保留它用
            # exitcode 判成败即可；只有真正起不来的情况才记「启动失败」。
            $exit = (.can('proc') && .proc ?? .proc !! Nil);
            if !$exit.defined {
                $err ~= "启动/等待测试子进程失败：{.Str}\n";
            }
        } }
    }
    my $full = $out ~ $err;
    my $ok   = $exit.defined && !$timed-out && $exit.exitcode == 0;

    # 落日志：每个测试文件一份。默认名 <basename>.log；串行复验那轮传
    # :log-suffix('.flake') 写成 <basename>.flake.log，【不覆盖】首跑的失败日志 ——
    # 否则并发首跑的（编译/环境）错误全文会被复验的成功日志冲掉，失去诊断线索。
    # 重装覆盖仍成立（天然按「每发行版每版本每文件」隔离）。
    try {
        mkdir-p($log-dir) unless $log-dir.d;
        my $header = $timed-out ?? "# 超时（>{$test-timeout}s）已被终止\n" !! '';
        $log-dir.add($test.basename ~ $log-suffix ~ '.log').spurt($header ~ $full);
    }

    # 缺命令/编译器识别（仅首次打印，复验那轮 :serial 不重复刷）
    self!hint-missing-tool($full) unless $ok || $serial;

    %( test => $test, ok => $ok, output => $full, timed-out => $timed-out );
}

# 测试失败如果是因为【缺命令/编译器】，说清楚 —— 否则很容易被当成 raku-pm 的锅。
#
# 典型现场：Windows 上 NativeLibs 的 t/20-compile.rakutest 要调 MSVC 的 cl 编 C。
# 普通 PowerShell 里没有 cl，报错只有一行
#     'cl' is not recognized as an internal or external command
# 而同样的包在 VS 的 Developer Command Prompt 下就装得过（用户实测确认）。
# 这类失败与环境有关、与包无关，值得单独指出来。
method !hint-missing-tool(Str $output --> Nil) {
    my @missing;
    for $output.lines -> $l {
        # Windows："'cl' is not recognized as an internal or external command"
        if $l.contains('is not recognized as an internal or external command') {
            my $a = $l.index("'");
            if $a.defined {
                my $b = $l.index("'", $a + 1);
                @missing.push($l.substr($a + 1, $b - $a - 1)) if $b.defined && $b > $a + 1;
            }
        }
        # Unix："sh: 1: cc: not found" / "cc: command not found"
        elsif $l.contains('command not found') || $l ~~ / ': not found' $ / {
            my @parts = $l.split(':').map(*.trim).grep(*.chars);
            @missing.push(@parts[*-1]) if @parts.elems;
        }
    }
    @missing = @missing.grep({ .chars && !.contains(' ') }).unique;
    return unless @missing.elems;

    note "";
    note "  💡 这个用例失败的原因是【缺命令】，不是包本身有问题：{@missing.join(', ')}";
    if is-windows() {
        note "     Windows 上若缺 cl（MSVC）：改用 VS 的 Developer Command Prompt，";
        note "     或 winget install Microsoft.VisualStudio.2022.BuildTools 装构建工具。";
    }
    else {
        note "     请先用系统包管理器装好对应工具（如 Debian/Ubuntu 的 build-essential）。";
    }
    note "     不想配置环境的话，用 --no-test 或 --allow-test-failure 跳过测试即可装上。";
    note "";
}
