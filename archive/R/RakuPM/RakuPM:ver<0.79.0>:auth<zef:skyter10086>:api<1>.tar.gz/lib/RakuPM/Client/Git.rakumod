# RakuPM::Client::Git — role（从 RakuPM::Client 拆出）

use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::Fs;
use RakuPM::InstallOptions;
use RakuPM::Net;
# 平台差异统一走 RakuPM::Platform（唯一读 $*DISTRO 的地方，可被测试遮蔽）——
# look 起交互 shell 时要用 is-windows() 选 COMSPEC / $SHELL。
use RakuPM::Platform;

unit role RakuPM::Client::Git;
# 从 git URL 安装一个发行版【及其全部依赖】。
#
# 流程与仓库安装完全一致：clone → 解析 META6.json → 递归解析依赖
# → 自底向上 入 store / 跑测试 / 装进 site/ → 写锁。
method install-from-git(Str $url,
                        Bool :$locked = False, Bool :$dry = False,
                        Bool :$no-test = False, Bool :$no-build = False,
                        Bool :$no-test-deps = False,
                        Bool :$no-native-check = False, Bool :$force = False,
                        Bool :$preserve-version = False,
                        Bool :$allow-test-failure = False,
                        Int :$test-jobs = 0, Int :$test-timeout = 0,
                        RakuPM::InstallOptions :$opts, :%pins --> Nil) {
    die "找不到 git 命令，请先安装 Git 并加入 PATH" unless self!has-git;

    # :$opts 是【安装链内部】的通道 —— !ensure-git-deps 会把整份选项透传下来
    # （这样 git 依赖的子链也认用户的每个开关）。外部调用（CLI / SelfManager /
    # 测试）走上面那组布尔开关，这里按同名字段组一份 —— 两条入口共用同一条链，
    # 不需要在链上各抄一遍参数。并发度 / 超时 / pin 表一并并入 $o。
    my $o = ($opts // RakuPM::InstallOptions.new(
        :$locked, :$dry, :$no-test, :$no-build, :$no-test-deps,
        :$no-native-check, :$force, :$allow-test-failure,
        :$test-jobs, :$test-timeout)).with(:pins(%pins));

    # clone（或复用已有 clone）并读出 META6.json
    my $cache-dir = self!ensure-git-clone($url);
    my $dist      = self!distribution-from-git($url, $cache-dir, :$preserve-version);

    self!install-local-dist($dist, $cache-dir, "   ← git: $url", $o);

    # 记录安装时对应的 git 提交号：self-upgrade 的「同版本不同内容」检测靠它
    # 判断「版本号没变但上游被强推 / 改写历史」—— 此时版本相同、内容已不同。
    # --dry 不落盘，不记录；安装失败（Installer 抛错）也走不到这里。
    unless $o.dry {
        my $sha = self!git-short-sha($cache-dir);
        self.installer.set-git-sha($dist.name, $dist.version, $sha);
    }
}
# git URL 规范化：`git://` 协议已被主流托管商关闭（GitHub 2022-01 起不再提供
# 9418 端口的未加密 git 协议），Draku 这类老包的 depends 里写的 git:// URL 现在
# clone 必失败（exit=128）。官方迁移路径就是 git:// → https://，对公开仓库语义
# 等价。自建且仍开着 git daemon 的极少见；教学工具直接升级协议，clone 失败时
# 报错会带 stderr 供排查。
# 公开（去掉 !）：纯字符串函数，测试要直接断言各形态的改写结果。
method normalize-git-url(Str $url --> Str) {
    $url.starts-with('git://') ?? 'https://' ~ $url.substr('git://'.chars) !! $url
}
# 从本地目录安装一个发行版【及其全部依赖】—— 对应 zef 的 `zef install .`。
#
# 注意：不能靠 `RAKUPM_REPO=<发行版根目录>` 来做这件事。Local 仓库的布局是
# 「一个仓库目录下挂多个发行版子目录」（repo/DistA/META6.json），它只扫子目录；
# 而一个发行版的 META6.json 就在自己的根目录上，扫不到。
method install-from-dir(IO::Path $dir,
                        Bool :$locked = False, Bool :$dry = False,
                        Bool :$no-test = False, Bool :$no-build = False,
                        Bool :$no-test-deps = False,
                        Bool :$no-native-check = False, Bool :$force = False,
                        Bool :$allow-test-failure = False,
                        Int :$test-jobs = 0, Int :$test-timeout = 0,
                        RakuPM::InstallOptions :$opts, :%pins --> Nil) {
    my $path = $dir.absolute.IO;
    die "目录不存在：{$path}" unless $path.d;

    my $o = ($opts // RakuPM::InstallOptions.new(
        :$locked, :$dry, :$no-test, :$no-build, :$no-test-deps,
        :$no-native-check, :$force, :$allow-test-failure,
        :$test-jobs, :$test-timeout)).with(:pins(%pins));

    my $meta = self!find-meta-file($path);
    die "{$path} 里找不到 META6.json，无法识别为一个发行版"
        unless $meta.defined;

    my $dist = RakuPM::Distribution.from-meta-file($meta);
    self!install-local-dist($dist, $path, "   ← 本地目录: {$path}", $o);

    # 本地目录若是 git 工作树（开发者 `install .` 自装），记录 HEAD 提交号。
    # 这样 self-upgrade 能走「提交号一致即跳过」的快路径，而不是退化成
    # 逐文件比对——store 快照只含 lib/bin/resources/META，不含 t/README，
    # 与整仓 clone 逐文件比对永远判「内容已变」而误重装（见下面 #2）。
    # 非 git 目录不记录（!in-git-repo 返回 False），不影响普通本地安装。
    unless $o.dry {
        if self!in-git-repo($path.Str) {
            my $sha = self!git-short-sha($path);
            self.installer.set-git-sha($dist.name, $dist.version, $sha) if $sha.chars;
        }
    }
}
# 在一个目录里找元数据文件：只认 Raku 标准的 META6.json
# （0.37.0 起不再回退 META.json：第三方包永远只有 META6.json，
# 回退读一个本不该存在的 META.json 只会误把杂散文件当发行版）
method !find-meta-file(IO::Path $dir --> IO::Path) {
    my $f = $dir.add('META6.json');
    return $f if $f.e;
    IO::Path
}
# git / 本地目录两条安装路径的公共部分。
# $dist 是目标包，$source 是它的源码目录（clone 目录或本地目录），
# $tag 只是打印时标注一下来源。
method !install-local-dist(RakuPM::Distribution $dist, IO::Path $source, Str $tag,
                           RakuPM::InstallOptions $opts --> Nil) {
    # --locked 要求锁文件已存在：没有锁直接报错（git / 本地目录安装同样受保护）。
    self!assert-lock-exists($opts.locked);

    # 递归解析依赖：与仓库安装同一套 Resolver，各索引候选合并后取满足约束的最高版本
    my @deps  = self.resolve-deps-of($dist, :pins($opts.pins));
    # 目标包接在最后 —— 它不在仓库里，Resolver 看不见它
    my @order = (|@deps, $dist);

    self.lock.enforce(@order) if $opts.locked;

    say "将安装 {@order.elems} 个发行版（自底向上，依赖优先）：";
    for @order -> $d {
        my $t = $d === $dist ?? $tag !! '';
        say "  · {$d.identity()}{$t}";
    }

    # 本地库检查覆盖整条链：依赖包同样可能依赖系统库
    self!check-native-libs(@order)   unless $opts.no-native-check;
    # 外部命令（:from<bin>）同理，只提示不安装
    self!check-external-deps(@order) unless $opts.no-native-check;

    if $opts.dry {
        say "--dry：仅解析，未落盘";
        return;
    }

    # 目标包的源码目录不在仓库里，用调用方给的这份
    my %override = "{ $dist.name }\0{ $dist.version }" => $source;
    # 注意这里显式传 %()：目标包自己要走完整构建/测试，不是「已在主链处理过」。
    self!install-chain(@order, %override, %(), $opts);

    self.lock.write(@order, :store(self.store));
    say "✓ 完成。锁文件已更新：{self.lock-path}";
}
# 检测 git 是否可用
method !has-git(--> Bool) {
    # 测试钩子：置 RAKUPM_NO_GIT 可强制「无 git」分支（避免真的去连网络）。
    return False if %*ENV<RAKUPM_NO_GIT>;
    try { run('git', '--version', :out); True } // False
}
# 把 git URL 规整成一个本地 cache 目录，已存在则 pull，否则 clone。
# clone 前先把 git:// 升级成 https://（见 normalize-git-url）——这里是不管
# 从哪进来的唯一克隆汇聚点：install-from-git / git URL 依赖 / self-upgrade
# 的 clone/pull 全走它。
method !ensure-git-clone(Str $url is copy --> IO::Path) {
    $url = self.normalize-git-url($url);
    my $cache-root = self.target.add('git-cache');
    my $key        = self!git-cache-key($url);
    my $cache-dir  = $cache-root.add($key);

    # ---- 离线模式：git 是子进程、不走 RakuPM::HTTP 门面，只能自己判（0.51.0）----
    # 有本地 clone 就直接复用（跳过 pull）—— 这正是离线模式最有用的地方：
    # 之前联网拉过的仓库，之后断网也能照常装、照常自升级。
    # 没有副本就只能报错，且必须说清是「离线所以拿不到」：把 git 的 exit=128
    # 原样抛出去，看起来会像「仓库坏了 / 认证失败」，方向完全错。
    if offline() {
        if $cache-dir.d {
            say "==> 离线模式（--offline）：复用本地 clone，跳过 git pull：{$cache-dir}";
            return $cache-dir;
        }
        die "离线模式下没有 {$url} 的本地副本，无法安装。\n"
          ~ "  本地缓存目录：{$cache-dir}\n"
          ~ "  先联网跑一次同样的命令（去掉 --offline）把它 clone 下来，之后即可离线复用。";
    }

    if $cache-dir.d {
        say "==> 更新本地缓存：$cache-dir";
        my $proc = run('git', '-C', $cache-dir.Str, 'pull', '--ff-only',
                       :out, :err);
        if $proc.exitcode != 0 {
            note "git pull 失败，尝试复用本地缓存";
        }
    }
    else {
        mkdir-p($cache-root);
        say "==> 克隆到本地缓存：$cache-dir";
        my $proc = run('git', 'clone', '--depth', '1', $url, $cache-dir.Str,
                       :out, :err);
        if $proc.exitcode != 0 {
            # 裸报 exit code 用户没法排查（真实原因在网络/认证，藏在 stderr）。
            # 取 stderr 尾部几行拼进报错，超时的 DNS/端口/代理问题一眼可见。
            my $why = $proc.err.slurp(:close).lines.grep(*.chars).tail(2).join(' ｜ ');
            die "git clone 失败（exit={$proc.exitcode}）{$why.chars ?? "：{$why}" !! ''}";
        }
    }

    $cache-dir
}
# 把 URL 规整成文件系统安全的相对路径：
#   https://github.com/raku-community-modules/File-Temp.git
#   → github.com/raku-community-modules/File-Temp.git
#   git@github.com:foo/bar.git
#   → github.com/foo/bar.git
method !git-cache-key(Str $url --> Str) {
    my $u = $url;
    my Bool $local = True;    # 没命中任何协议前缀 → 当【本地路径】处理

    if $u.starts-with('git@') {
        # git@host:path → host/path（去掉 git@ 前缀，冒号换斜杠）
        $u = $u.substr(4);
        $u = $u.subst(':', '/');
        $local = False;
    }
    elsif $u.starts-with('https://') {
        $u = $u.substr('https://'.chars);
        $local = False;
    }
    elsif $u.starts-with('http://') {
        $u = $u.substr('http://'.chars);
        $local = False;
    }
    elsif $u.starts-with('git://') {
        $u = $u.substr('git://'.chars);
        $local = False;
    }

    $u ~~ s/^ \/+ //;
    $u = $u.subst(/ <[\/\\]> /, '/', :g);

    # 本地路径（如 `self-upgrade --from C:/path/to/repo`）不能直接当目录名：
    # Windows 路径里的【盘符冒号】在文件名中非法，mkdir 会直接报
    # "Invalid argument"（实测：clone 到 git-cache 时就死在这里）。
    # 统一挪进 local/ 前缀并去掉冒号 —— 既保证名字合法，也避免与 https 的
    # host 段（如 github.com）撞名。
    $u = 'local/' ~ $u.subst(':', '', :g) if $local;

    $u
}
# 从 clone 出的目录读 META6.json 构造 Distribution。
# 普通 git 安装：版本号用 0.0.0-<git-sha7>，auth 用 git:<host>。
#   （HEAD 没有 tag 版本概念，不解析 tag 当版本。）
# :$preserve-version —— 升级 raku-pm 自己时传 True：META6.json 里的 version
#   才是权威（每次发版都 bump），必须用真版本，否则 `raku-pm version`
#   会显示 0.0.0-* 这种伪版本（Windows 下 wrapper 在 target/bin，
#   读不到仓库根 META6.json，只能回退到仓库链里装的那份 → 误导成 0.0.0）。
method !distribution-from-git(Str $url, IO::Path $cache-dir,
                              Bool :$preserve-version = False
                              --> RakuPM::Distribution) {
    my $meta6 = $cache-dir.add('META6.json');
    die "git 仓库 $url 缺少 META6.json（不是 Raku 发行版？）" unless $meta6.e;

    my $sha = self!git-short-sha($cache-dir);
    my $dist = RakuPM::Distribution.from-meta6-file($meta6);
    my $host = self!host-of($url);

    # 升级 raku-pm 自己：保留 META6.json 里的真版本与 auth。
    # 用 clone-with() 而不是手工挑字段 —— 手工挑字段曾在这里漏掉
    # git-deps / native-libs / resources / build-depends / builder / test-depends
    # （每次漏都造成真实故障，见 Distribution.clone-with 的注释）。
    # 传空参即等价拷贝，新增字段自动带上。
    return $dist.clone-with() if $preserve-version;

    # 强制覆盖 version 与 auth（git 仓库拿 HEAD，不读 tag 当版本）。
    # 同样走 clone-with —— 除这两项外其余字段原样保留，结构上不可能再漏。
    $dist.clone-with(:version("0.0.0-{$sha}"), :auth("git:{$host}"))
}
method !git-short-sha(IO::Path $dir --> Str) {
    my $proc = run('git', '-C', $dir.Str, 'rev-parse', '--short=7', 'HEAD',
                   :out);
    $proc.out.slurp(:close).trim
}
method !host-of(Str $url --> Str) {
    if $url.starts-with('https://') {
        return $url.substr(8).split('/', 2)[0] // 'unknown';
    }
    if $url.starts-with('http://') {
        return $url.substr(7).split('/', 2)[0] // 'unknown';
    }
    if $url.starts-with('git@') {
        # git@host:path
        my $rest = $url.substr(4);
        return $rest.split(':', 2)[0] // 'unknown';
    }
    if $url.starts-with('git://') {
        my $rest = $url.substr('git://'.chars);
        return $rest.split('/', 2)[0] // 'unknown';
    }
    'unknown'
}
# 取源码到目录 —— fetch 与 look 的公共实现：
#   解析（模块名 → 发行版名 → 版本）→ 读元数据 → 物化源码（下载/解缓存）→ 复制到目标。
#
# 刻意不复用 !resolve：那边会把依赖一起解析，而这里只想要目标这一份源码；
# 本地场景里依赖未必在任何仓库中，一 resolve 就死。
#
# 从 fetch 里抽出来，是因为 look 需要**完全同一套**解析逻辑，而两者对
# 「取到之后干什么」的表述不同（fetch 要提示怎么加成仓库，look 要进目录）。
# 复制一份迟早两边漂移 —— 本项目已经吃过「同一逻辑两处实现」的亏（见 Fs / Ledger）。
#
# 返回 Hash：name / version / src（物化后的源码目录，可能在缓存里）/ dest（目标副本）。
#
# :$version  精确版本；不给则取满足约束的最高版本（即最新）
# :$to       目标目录，默认当前目录。会在其下建 <发行版名>/ 子目录。
# :$constraint 版本约束串（"1.2+" / ">=1.0"…，CLI 由规格串解析填入，
#              `raku-pm fetch 'Foo:ver<1.2+>'`）。与 :$version 同时给时
#              精确版本优先 —— 与 install 的优先级一致。
method !fetch-source(Str $spec, Str :$to = '.', Str :$version = '',
                     Str :$constraint = '' --> Hash) {
    # 精确版本优先于约束串（与 install 的优先级一致）。这条归一化只写在这里，
    # 定位逻辑（Client.!resolve-dist-for-spec）只管接一个算好的约束。
    my $eff = $version.trim.chars        ?? "= {$version.trim}"
            !! $constraint.trim.chars    ?? $constraint.trim
            !! '';

    my %got  = self!resolve-dist-for-spec($spec, $eff);
    my $dist = %got<dist>;
    my $ver  = %got<version>;
    my $safe = %got<name>.subst('::', '-', :g);

    # 生态仓库会在这一步下载 tar 包并解包（带缓存，重复取不重复下载）
    my $src = self!source-dir-for($dist);

    my $dest-root = $to.IO;
    mkdir-p($dest-root);
    my $dest = $dest-root.add($safe);
    # 同名不同版本并存：目录已存在就带上版本号，避免静默覆盖
    $dest = $dest-root.add("{$safe}-{$ver}") if $dest.d;

    copy-tree($src, $dest);

    %( name => %got<name>, version => $ver, src => $src, dest => $dest );
}
# 只取源码、不安装（zef 无对应命令，是 raku-pm 自己加的）。
#
# 主要用途是填充「本地目录仓库」：
#   raku-pm fetch HTTP::Client --to=~/my-dists
#   raku-pm repos add ~/my-dists
# 之后这些包就能按名安装、能被依赖解析自动找到、也能被 search 搜到。
method fetch(Str $spec, Str :$to = '.', Str :$version = '',
             Str :$constraint = '' --> Nil) {
    my %r    = self!fetch-source($spec, :$to, :$version, :$constraint);
    my $root = $to.IO;

    say "==> 已取到源码：{%r<name>} {%r<version>}";
    say "    源  ：{%r<src>.absolute}";
    say "    目标：{%r<dest>.absolute}";
    say "";
    say "把它加成仓库就能按名安装（依赖解析与 search 也认）：";
    say "    raku-pm repos add {$root.absolute}";
}
# 取源码并进去看（对应 zef 的 `zef look`）。
#
# 【默认不起 shell】默认只把源码取到目录并打印路径。理由：
#   · 可预测、可脚本化（`cd "$(raku-pm look Foo | tail -1)"` 这种用法才成立）；
#   · 能测 —— 起交互 shell 的代码在 CI 里没法验，只能靠人肉点一次。
# 要真进交互 shell 加 `--shell`；而且**只在交互终端里才起**（$*IN.t），
# 管道 / CI 里起交互 shell 只会挂在那儿等输入（比报错更难查）。
#
# 【目录是持久的，不是临时目录】默认放 <前缀>/cache/look。zef 用临时目录、
# 退出即删；但反复看同一个包时复用已取的副本能省一次下载，用户回头再来看也还在。
# 想一次性的就自己给方向：look Foo --to=/tmp/x（等将来有需求再说）。
method look(Str $spec, Str :$version = '', Str :$constraint = '',
            Bool :$shell = False --> Nil) {
    my $dest-root = self.target.add('cache', 'look');
    my %r    = self!fetch-source($spec, :to($dest-root.Str),
                                 :$version, :$constraint);
    my $dest = %r<dest>;

    say "==> 源码：{%r<name>} {%r<version>}";
    say "    {$dest.absolute}";

    my $interactive = $*IN.t;
    if $shell && !$interactive {
        say "  （--shell 已忽略：当前不是交互终端，起了也是一直等输入）";
    }
    unless $shell && $interactive {
        say "";
        say "看源码：cd {$dest.absolute}";
        say "要直接进去：raku-pm look {$spec} --shell";
        return;
    }

    # 平台差异只在 RakuPM::Platform 判（t/platform-centralized.t 强制）：
    # Windows 用 COMSPEC（cmd.exe），类 Unix 用 $SHELL 兜 /bin/sh。
    my $sh = is-windows() ?? (%*ENV<COMSPEC> // 'cmd.exe')
                          !! (%*ENV<SHELL> // '/bin/sh');
    say "==> 进入 {$sh}（exit 退出后回到原目录）";
    # 不带 :out/:err → 子进程继承本进程的标准流，交互才能真正可用。
    run($sh, :cwd($dest.Str));
}
# 递归复制目录树（fetch 用）统一在 RakuPM::Fs.copy-tree —— 它跳过 .precomp
# 与 VCS 元数据（.git/.hg/.svn/blib），并拒绝「目标在源目录内部」的自我复制
# （后者会无限递归到路径长度爆炸）。原先本 role 私有一份，与 Store 重复。
