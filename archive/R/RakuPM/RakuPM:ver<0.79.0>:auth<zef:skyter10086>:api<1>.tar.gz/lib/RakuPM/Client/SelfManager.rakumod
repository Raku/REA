# RakuPM::Client::SelfManager — role（从 RakuPM::Client 拆出）

use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::MD5;
use RakuPM::Fs;
use RakuPM::Platform;

unit role RakuPM::Client::SelfManager;
# raku-pm 的默认上游 git 仓库。self-upgrade 不依赖是否把 RakuPM 发布到
# 生态索引（目前没发布），统一从 git 远端拉源码重装；这个地址就是缺省来源。
my constant DEFAULT-UPSTREAM = 'https://gitee.com/skyter10086/raku-pm.git';
# 升级 raku-pm 自己。
#
# 为什么单独给个命令、而不是让用户敲 `upgrade RakuPM`：
#   · raku-pm 很可能是 zef 装的，那样它并【不在我们自己的账本里】，
#     而 `upgrade` 一上来就按自家账本查 installed-version，会直接 die
#     "尚未安装" —— 需要一个不依赖账本是否已记录的入口；
#   · 语义更明确：一眼看出这是在动工具本身，而不是某个普通的包。
#   · raku-pm 没发布到任何生态索引，所以不再走仓库查找（那是之前
#     "在所有已配置的仓库里都找不到 RakuPM" 报错的根因）。
#
# 来源优先级：
#   1. 显式 --from <url>：从指定 git 远端拉取并升级（覆盖一切）；
#   2. 当前这份来自某个 git 仓库（$source，开发者自装/自跑）→ pull 该仓库 + 重装；
#   3. 否则从默认上游（gitee）拉取升级。
#
# :$current 由 CLI 传入（raku-pm-version()），仅用于信息展示，不影响升级动作
# （git HEAD 即权威版本，不与已装版本号做比较）。
method self-upgrade(Str :$current = '', Bool :$dry = False,
                    Str :$source = '', Str :$from = '', Str :$from-dir = '',
                    Bool :$force = False, Bool :$no-test = False,
                    Bool :$no-native-check = False, :@passthru --> Nil) {
    # self-upgrade 只升级 raku-pm 自己 —— 它是纯 Raku、META6 不声明任何
    # :from<native> 依赖，也从不运行时加载系统库。因此【默认跳过】运行时本地库
    # 检查：这个检查扫描源码里的 is native('...')，而 raku-pm 自己的文档注释 /
    # POD 里恰好有 `is native('foo')` / `is native('...')` 这样的【样例】，旧扫描
    # 器会把它误当成真实依赖、报「缺少 foo/... 」而放弃自装，造成「永远升不上去」
    # 的死循环（旧版 self-upgrade 跑旧版扫描器，旧版扫描器又卡在全新源码的样例上）。
    # 跳过检查对 raku-pm 自身始终安全；这里统一用 True（调用方如需强制检查可改）。
    my $skip-native = True;

    # 0) --from-dir：直接用【本地源码目录】升级（不 clone、不联网）。
    #    这是【两阶段自举】第二阶段的入口：外层（旧版）把源码取到本地后，
    #    用那份源码里的【新版】bin 带 --from-dir 重跑本命令 —— 于是「执行安装的
    #    代码」就是新版，而不是旧版。见 !bootstrap-into 的说明。
    if $from-dir.trim.chars {
        my $dir = $from-dir.trim.IO;
        die "self-upgrade --from-dir 指向的目录不存在：{$dir.absolute}"
            unless $dir.d;
        self!install-self-from($dir, :$dry, :$force, :$no-test,
                               :no-native-check($skip-native));
        return;
    }
    # 1) 显式 --from：从指定 git 远端升级（最高优先级，覆盖一切）
    if $from.trim.chars {
        self!upgrade-from-remote($from.trim, :$dry, :$force, :$no-test,
                                  :no-native-check($skip-native), :@passthru);
        return;
    }
    # 2) 当前这份来自 git 仓库（开发者模式）：直接 pull 该仓库 + 本地重装
    if $source.trim.chars && self!in-git-repo($source.trim) {
        self!upgrade-from-git($source.trim, :$dry, :$no-test,
                               :no-native-check($skip-native));
        return;
    }
    # 3) 默认：从上游 git 远端（gitee）拉取升级
    self!upgrade-from-remote(DEFAULT-UPSTREAM, :$dry, :$force, :$no-test,
                              :no-native-check($skip-native), :@passthru);
}
# 判断某目录是否位于某个 git 仓库内（向上查找 .git）。
# 用于 self-upgrade 识别「当前这份 raku-pm 是从源码仓库跑的」。
method !in-git-repo(Str $dir --> Bool) {
    my $p = $dir.IO;
    for ^20 {
        return True if $p.add('.git').d || $p.add('.git').e;
        my $up = $p.parent;
        last if $up eq $p;
        $p = $up;
    }
    False
}
# 判断是否需要升级：比较「远端版本」与「本地已装版本」，版本相同时再校验内容。
# 返回 True = 需要装；False = 已提示并跳过。
#
# 版本相同时的内容校验，按可靠性从高到低三级：
#   1. 记录的 git 提交号 == 远端提交号 → 内容一致，跳过（0.27.0+ 装的都有记录）；
#   2. 记录的提交号 != 远端提交号 → 上游被强推/改写，重装；
#   3. 没记录过提交号（老版本装的）→ 【逐文件比对】远端源码与 store 里已装的
#      源码快照（:$remote-source），内容一致才跳过、不一致就重装 ——
#      不再依赖"装的时候有没有记账"，install . / 老版本 self-upgrade 装的都能校验。
# 公开方法（去 ! ）：要能从测试里直接调它做判定逻辑的回归。
method upgrade-needed(Str $name, Str $remote-ver, Str $remote-sha,
                      Bool :$force = False, IO::Path :$remote-source --> Bool) {
    my @have = self.installer.installed-versions($name);
    my $local-ver = @have.elems ?? @have[*-1] !! '';

    # 本地没装过 → 必装
    unless $local-ver.chars {
        return True;
    }

    my $cmp = RakuPM::Version.from-string($remote-ver).cmp(
                  RakuPM::Version.from-string($local-ver));

    if $cmp == Less {
        say "✓ 本地 {$name} {$local-ver} 比远端 {$remote-ver} 还新，跳过（避免降级）。";
        say "  要强制安装远端版本：raku-pm self-upgrade --force" if $name eq 'RakuPM';
        return False;
    }

    if $cmp == Same && !$force {
        my $rec = self.installer.recorded-git-sha($name, $local-ver);
        if $rec.chars && $rec eq $remote-sha {
            say "✓ 已是最新：{$name} {$local-ver}，远端提交 {$remote-sha} 与安装时一致，跳过。";
            return False;
        }
        if $rec.chars {   # 不一致：版本没动、内容动了（强推/改写历史）
            say "==> 版本相同（{$local-ver}）但内容已变：";
            say "    安装时提交 {$rec} → 远端现在 {$remote-sha}";
            say "    按远端内容重装。";
            return True;
        }
        # 没记录提交号（老版本装的）→ 别急着保守跳过：远端 clone 与 store 里的
        # 已装源码快照都在本地，逐文件比对即可（用户指出：不必依赖账本记录）。
        if $remote-source.defined {
            my $local-src = self.store.path-for($name, $local-ver);
            if $local-src.d {
                my ($same, $n) = self!content-diff($remote-source, $local-src);
                if $same {
                    say "✓ 已是最新：{$name} {$local-ver}，远端与已装源码 {$n} 个文件比对一致，跳过。";
                    return False;
                }
                say "==> 版本相同（{$local-ver}）但内容已变（远端与已装源码逐文件比对不一致），重装。";
                return True;
            }
            say "✓ 本地已是 {$local-ver}，与远端版本相同，跳过。";
            say "  （store 里没有该版本的源码快照，无法比对内容——如 zef 装的那份；";
            say "    要强制重装：raku-pm self-upgrade --force）";
            return False;
        }
        # 老路径：既没提交号、也没给远端源码可比
        say "✓ 本地已是 {$local-ver}，与远端版本相同，跳过。";
        say "  （该次安装未记录 git 提交号，无法校验内容是否一致；";
        say "    要强制重装：raku-pm self-upgrade --force）";
        return False;
    }

    say "==> 有新版本：{$local-ver} → {$remote-ver}" if $cmp == More;
    True
}
# 真正会装进 site 的源码内容（其余 t/README/.github/META6.json 不计入「代码是否变」）。
# store 的 META6.json 是依据 lib/ 反推重建的，与仓库原 META6.json 必然不同，
# 若把它算进比对，self-upgrade 会对任何包永远误报「内容已变」而重装。
my @SOURCE-ROOTS = 'lib', 'bin', 'resources';
# 逐文件比较两个发行版【源码内容】。返回 (是否一致, 文件数)。
# 只比 lib/bin/resources（见 @SOURCE-ROOTS）——其余文件（t/README/.github、
# META6.json、.git）要么 store 快照里就没有，要么 store 是重建的、与仓库原样不同，
# 都不代表「已装代码变没变」，算进去会让 MD5 兜底分支永远误判重装。
# 比对：文件集合 → 逐文件 MD5。RakuPM 源码量级小（几十文件 / 几百 KB），
# 纯 Raku MD5 的代价在 self-upgrade 场景可接受，且只在没有提交号记录时才走到。
method !content-diff(IO::Path $remote, IO::Path $local --> List) {
    my %r = self!content-map($remote, :roots(@SOURCE-ROOTS));
    my %l = self!content-map($local, :roots(@SOURCE-ROOTS));
    my $n = %r.elems;
    return (False, $n) unless $n == %l.elems;
    for %r.kv -> $rel, $sum {
        return (False, $n) unless %l{$rel}:exists && %l{$rel} eq $sum;
    }
    (True, $n)
}
# 目录内容清单：相对路径（统一 / 分隔）→ 文件内容 MD5。
# :roots 给定时只收这些顶层子树（源码内容比对用），否则收整个目录。
method !content-map(IO::Path $root, :@roots = () --> Hash) {
    my %out;
    return %out unless $root.d;
    if @roots {
        for @roots -> $r {
            my $d = $root.add($r);
            next unless $d.d;
            self!collect-content($d, $r, %out);
        }
    }
    else {
        self!collect-content($root, '', %out);
    }
    %out
}
method !collect-content(IO::Path $dir, Str $prefix, %out --> Nil) {
    for $dir.dir -> $e {
        my $rel = $prefix.chars ?? "$prefix/" ~ $e.basename !! $e.basename;
        # 跳过派生产物 / VCS 元数据：
        #   · 顶层与任意子目录里的 .git/.precomp/.digest 都排除
        #     （.precomp 可能出现在 lib/ 等任意子目录，不能只排顶层）。
        #   · .git 整段子树按前缀排除（clone 里有 .git，快照里没有）。
        next if $e.basename eq '.git' || $e.basename eq '.precomp'
             || $e.basename eq '.digest';
        next if $rel.starts-with('.git/') || $rel.starts-with('.precomp/');
        if $e.d {
            self!collect-content($e, $rel, %out);
        }
        else {
            %out{$rel} = md5-hex($e.slurp(:bin));
        }
    }
}
# 从指定 git 远端（URL 或本地仓库路径）升级 raku-pm 自己：
# clone/pull 到本地缓存 + 从源码重装。
#
# 先做升级检查（版本 + 提交号内容比对），已是最新就不下载不安装 ——
# git-cache 的 pull 是增量的，检查本身代价很小。
method !upgrade-from-remote(Str $url, Bool :$dry = False, Bool :$force = False,
                          Bool :$no-test = False, Bool :$no-native-check = False,
                          :@passthru --> Nil) {
    die "升级 raku-pm 需要 git，请先安装 Git 并加入 PATH"
        unless self!has-git;
    say "==> 从 git 远端升级 raku-pm：{$url}";

    # 升级检查：clone/pull 到 git-cache（增量），读远端 META6.json 的版本 +
    # 当前 HEAD 提交号。检查本身不装任何东西。
    my $cache = self!ensure-git-clone($url);
    my $remote-meta = $cache.add('META6.json');
    die "git 仓库 {$url} 缺少 META6.json（不是 Raku 发行版？）" unless $remote-meta.e;
    my $remote-ver  = RakuPM::Distribution.from-meta6-file($remote-meta).version;
    my $remote-sha  = self!git-short-sha($cache);

    # 升级检查：已是最新（版本一致且提交号一致，或无提交号记录时远端与已装
    # 源码逐文件比对一致）就跳过 —— upgrade-needed 内部已打印跳过原因。
    # :remote-source 把 clone 目录递过去供内容比对用（老安装没有提交号记录）。
    my $need = self.upgrade-needed('RakuPM', $remote-ver, $remote-sha,
                                   :$force, :remote-source($cache));
    return if !$need;

    # ---- 优先走【两阶段自举】：让拉到的【新版代码】自己装自己 ----
    if self!bootstrap-into($cache, :$dry, :$force, :$no-test, :@passthru) {
        return;
    }

    # ---- 回退：clone 里没有可用入口（老版本源码无 bin/ 等）→ 用当前代码装 ----
    note "⚠  无法用新版代码自举，改用当前版本执行安装（见上方说明）。";
    # install-from-git 会复用 git-cache（代价小）并重装。
    # :force($force || $need) —— 「版本相同但内容已变」这个场景必须 force，
    # 否则 install-chain 的「已安装跳过」会把这次重装拦掉；用户显式 --force 同理。
    self.install-from-git($url, :$dry, :force($force || $need),
                          :preserve-version, :$no-test, :$no-native-check,
                          :test-jobs(1));
    # 覆盖安装语义：装完自动清掉 RakuPM 的旧版本，免得升级完还得手动 uninstall。
    self!prune-old-self-versions(:$dry);
    say "";
    say "✓ raku-pm 已从 git 远端升级（{$url}）。";
    say "  跑 `raku-pm version` 确认 —— 若显示的还是旧版，";
    say "  多半是 PATH 里排在前面的那份没被换掉（见 `raku-pm env`）。";
}

# 【两阶段自举】用拉到的【新版代码】执行安装，而不是拿当前（旧版）代码去装。
#
# 为什么必须这样：self-upgrade 过去是「旧版进程执行 install-from-git」。可新版一旦
# 改了安装链里的任何行为（测试门禁、依赖解析、bin / wrapper 写法、账号校验……），
# 旧版的那套逻辑就可能装不动新版 —— 表现成「新版自己能装自己、旧版装它必失败」
# 的升不上去死循环。改成：clone 拿到源码后，用 clone 里的 bin/raku-pm.raku
# （配合 -I clone/lib 加载新版模块）重跑 `self-upgrade --from-dir=<clone>`，
# 于是从解析到落地全部由新版代码完成，旧版只负责「取源码 + 决定要不要升」。
#
# 锁不用特殊处理：父进程此刻正持着 <target>/.raku-pm.run.lock，FileLock 已把
# 继承凭证下发（环境变量 RAKUPM_LOCK_TOKEN + 锁旁的 .token 文件），子进程
# should-bypass 三条件成立 → 直接免锁放行，不会自锁。**这也是必须透传
# --target 的原因** —— 不走同一个 target 就会去抢另一把锁，保护范围就错位了。
#
# 返回 True = 子进程已成功完成（外层不要再装）；False = 不能或未能自举，调用方回退。
method !bootstrap-into(IO::Path $cache, Bool :$dry = False, Bool :$force = False,
                       Bool :$no-test = False, :@passthru --> Bool) {
    my @cmd = self.bootstrap-command($cache, :$dry, :$no-test, :@passthru);
    unless @cmd.elems {
        say "  （{$cache} 里没有 bin/raku-pm.raku —— 源码太旧，无法自举）";
        return False;
    }
    say "==> 两阶段自举：改用拉到的【新版代码】执行安装";
    say "    {@cmd.join(' ')}";
    # 先把自己这几行刷出去，再让子进程接管终端 —— 否则 Perl6 的 stdout 缓冲会把
    # 外层输出压到子进程输出【之后】，看起来像「都装完了才说要做自举」，非常反直觉。
    $*OUT.flush;
    # 不捕获 stdout/stderr：让新版子进程的输出直接透到用户终端（实时可读）。
    my $code = run(|@cmd).exitcode;
    if $code == 0 {
        say "";
        say "✓ raku-pm 已由【新版代码】完成升级。";
        return True;
    }
    note "⚠  新版子进程退出码 {$code}，自举失败。";
    False;
}

# 组装自举子进程的命令行。公开（去掉 !）便于单测 —— 这是「新版自己装自己」的
# 关键一步，拼错一个参数（尤其漏掉 --target）就会静默退化成「用旧代码装」或
# 装错位置，很难从输出上看出来。
# 返回空 List = clone 里没有可用入口（老版本源码没有 bin/ 或 lib/）。
method bootstrap-command(IO::Path $cache, Bool :$dry = False, Bool :$no-test = False,
                         :@passthru --> List) {
    my $lib      = $cache.add('lib');
    my $launcher = $cache.add('bin').add('raku-pm.raku');
    return () unless $lib.d && $launcher.f;

    # $*EXECUTABLE 是当前 raku 可执行文件（子进程必须用同一个 raku 跑）。
    my @cmd = $*EXECUTABLE.Str, '-I', $lib.absolute, $launcher.absolute,
              'self-upgrade', '--from-dir=' ~ $cache.absolute;
    # --force 必带：self-upgrade 的语义就是覆盖安装，而且「版本号没变、内容变了」
    # （上游强推）这种情况不加 --force 会被 install 链的「已安装跳过」拦掉。
    @cmd.push('--force');
    @cmd.push('--dry')     if $dry;
    @cmd.push('--no-test') if $no-test;
    # 透传：--target（必须，见方法头注释）、--lock-file、--offline、promote-bin 等
    @cmd.append(@passthru);
    @cmd;
}

# 用一份【本地源码目录】把 raku-pm 装成当前版本（覆盖安装 + 只留这一版）。
# 两个调用方：用户显式 --from-dir，以及两阶段自举的第二阶段（新版进程跑的就是它）。
method !install-self-from(IO::Path $dir, Bool :$dry = False, Bool :$force = False,
                          Bool :$no-test = False, Bool :$no-native-check = False --> Nil) {
    say "==> 从本地源码目录升级 raku-pm：{$dir.absolute}";
    # :force(True) —— self-upgrade 的语义是覆盖安装，不受 --force 是否给过影响。
    # 注意别写 `:force`：本方法形参里就有 $force，那样会传成「用户的 --force 值」，
    # 不给 --force 时就不再覆盖，反而静默变成「已安装就跳过」。
    # :test-jobs(1) —— self-upgrade 装的是 raku-pm 自己，会跑本项目 t/。并行首跑时
    # 多个 raku 子进程同时首次编译 lib/*.rakumod 偶发触发预编译缓存竞态（Tester 的
    # 串行复验会吸收，升级仍成功），但前台会先打出一个吓人但良性的 `✗ <某测试>.t`。
    # self-upgrade 很低频，串行足够快，且从根上消除该竞态、不再出现假失败噪音。
    self.install-from-dir($dir, :$dry, :force(True), :$no-test, :$no-native-check,
                           :test-jobs(1));
    # 覆盖安装语义：装完自动清掉 RakuPM 的旧版本，免得升级完还得手动 uninstall。
    self!prune-old-self-versions(:$dry);
    say "";
    say "✓ raku-pm 已从本地源码升级。";
    say "  跑 `raku-pm version` 确认 —— 若显示的还是旧版，";
    say "  多半是 PATH 里排在前面的那份没被换掉（见 `raku-pm env`）。";
}
# 从当前这份所在的 git 仓库升级 raku-pm 自己：git pull 最新 + 从本地源码重装。
# 这是开发者自装/自跑 raku-pm 时 self-upgrade 的优化路径（省一次 clone）。
method !upgrade-from-git(Str $repo-dir, Bool :$dry = False, Bool :$no-test = False,
                       Bool :$no-native-check = False --> Nil) {
    # 1) 拉取最新（仅当装了 git、且非 --dry）。
    #    --ff-only：不会把本地提交和远端合并，避免误吞本地改动；
    #    若有未提交改动或分叉导致 pull 失败，降级为「用当前本地源码重装」并提示。
    my $did-pull = False;
    if $dry {
        say "（--dry）不执行 git pull，仅用当前本地源码重装";
    }
    elsif !self!has-git {
        note "未检测到 git 命令，将直接用当前本地源码重装（不拉取最新）";
    }
    else {
        my $proc = run('git', '-C', $repo-dir, 'pull', '--ff-only', :out, :err);
        if $proc.exitcode == 0 {
            say "==> git pull 完成：{$repo-dir}";
            $did-pull = True;
        }
        else {
            note "git pull 失败（可能本地有未提交改动或分叉），将用当前本地源码重装：\n"
               ~ ($proc.err.slurp(:close) // '');
        }
    }

    # 2) 从本地源码重装（:force 保证覆盖，即便版本号未变也同步最新代码）。
    self.install-from-dir($repo-dir.IO, :$dry, :force, :$no-test, :$no-native-check,
                           :test-jobs(1));
    # 覆盖安装语义：装完自动清掉 RakuPM 的旧版本，免得升级完还得手动 uninstall。
    self!prune-old-self-versions(:$dry);
    say "";
    say "✓ raku-pm 已从本地仓库升级（{ $did-pull ?? '已 git pull 最新' !! '使用当前本地源码' }）。";
    say "  跑 `raku-pm version` 确认 —— 若显示的还是旧版，";
    say "  多半是 PATH 里排在前面的那份没被换掉（见 `raku-pm env`）。";

    # 3) 装完顺手给 PowerShell 用户提个醒：.ps1 wrapper 已写到 target/bin，
    #    但 Windows 默认 PATHEXT 是 .COM;.EXE;.BAT;.CMD... 不含 .PS1，
    #    所以 `raku-pm` 仍然会走 .bat 入口，< > & | 这些字符依然会撞 cmd。
    #    一行命令让 PowerShell 也能用 .ps1：
    if is-windows() && self!ps1-pathhelp-needed {
        say "";
        say "  ※ Windows PowerShell 用户：";
        say "    target/bin/raku-pm.ps1 已写好，但需要先把 .PS1 加进 PATHEXT 才会优先用它";
        say "    （绕开 cmd 的 < > 重定向二次解析，< > & | % 全程安全）。一次性：";
        say "      [Environment]::SetEnvironmentVariable('PATHEXT', \$env:PATHEXT + ';.PS1', 'User')";
        say "    然后【新开一个】PowerShell 窗口生效。验证：raku-pm help 应该指向 ps1 wrapper。";
    }
}

# 用户当前 session 的 PATHEXT 是否已含 .PS1？没含就提示 PowerShell 用户。
# 读注册表 HKCU\Environment\PATHEXT —— 永久生效版本；也读 $env:PATHEXT
# 当下（用户可能已经 `setx` 过但还没重开，或临时 export 过）。任一处含
# .PS1 就不再提示。
method !ps1-pathhelp-needed(--> Bool) {
    my $cur = (%*ENV<PATHEXT> // '').uc;
    return False if $cur.contains('.PS1');

    try {
        my $key = 'HKCU\Environment';   # Raku 字面量里 \E 是反斜杠转义符；用单引号避免
        my $val = run('reg', 'query', $key, '/v', 'PATHEXT', :out, :err);
        return False if $val.exitcode != 0;
        my $s = $val.out.slurp(:close).uc;
        return False if $s.contains('.PS1');
    }
    return True;
}
# self-upgrade 成功后，把 RakuPM 在 CUR / store / 账本里【除刚装的这一版外】的所有
# 旧版本都清掉 —— 让 self-upgrade 等价于「覆盖安装」，升级完不用再手动 uninstall。
#
# 背景：install() 只摘「同版本」、!record 把每个版本都累加进账本 versions[]，
# 于是升级后旧版本仍残留在 CUR / store / 账本里（wrapper 永远跑 store 最新版，所以
# 功能上新版在跑，但旧版占着空间、还出现在 list/outdated 里）。raku-pm 自己只该
# 留一份，多版本共存是给用户包用的特性，对工具自身反而是累赘。
#
# :$dry 时只报告、不实际删除（与 install 的 --dry 一致）。
method !prune-old-self-versions(Bool :$dry = False --> Nil) {
    my @have = self.installer.installed-versions('RakuPM');
    return unless @have.elems;
    my $keep = @have[*-1];                     # 最高版本 = 刚装的那版
    my @old  = @have.grep(* ne $keep);
    unless @old.elems {
        say "  ✓ raku-pm 只有 {$keep} 一个版本，无需清理旧版本。";
        return;
    }
    if $dry {
        say "  （--dry）self-upgrade 完成后将清理旧版本 {@old.join(', ')}，"
          ~ "仅保留 {$keep}（不实际删除）。";
        return;
    }
    say "  · 清理旧版本（保留 {$keep}）：{@old.join(', ')}";
    self.installer.prune-other-versions('RakuPM', $keep);
    say "  ✓ 已只保留 raku-pm {$keep}，旧版本由 self-upgrade 自动清理。";
}
# 卸载 raku-pm 自己。
#
# 与 `uninstall RakuPM` 的区别：那个只是从 CUR::Installation 摘掉发行版，
# 这个还会清掉 raku-pm 自己在磁盘上留下的东西：
#   · store/RakuPM/（各版本的源码快照，往往占大头）
#   · target/bin/ 下的 wrapper（raku-pm / raku-pm.bat）
#   · 账本与锁文件里的条目
# 另外必须提醒：zef 装的那份不在我们管理范围内 ——
# 卸完 `raku-pm` 命令可能仍然存在（会跑 zef 装的那份）。
method self-remove(Bool :$dry = False --> Nil) {
    my @versions = self.installer.installed-versions('RakuPM');

    # 1) CUR::Installation + 自家账本 + 锁文件
    unless $dry {
        self.installer.uninstall('RakuPM');
        try { self.lock.remove('RakuPM') };
    }

    # 2) store 里的源码快照
    my $snap = self.store.root.add('RakuPM');
    if $snap.d {
        say "  清理存储快照：{$snap.absolute}";
        rm-tree($snap) unless $dry;
    }

    # 3) target/bin 下的 wrapper
    for 'raku-pm', 'raku-pm.bat', 'raku-pm.ps1' -> $name {
        my $w = self.target.add('bin').add($name);
        next unless $w.e;
        say "  删除 wrapper：{$w.absolute}";
        try { $w.unlink } unless $dry;
    }

    say "";
    say "已卸载 raku-pm"
      ~ (@versions.elems ?? "（原版本 {@versions.join(', ')}）" !! "")
      ~ ($dry ?? "（dry-run，未实际删除）" !! "") ~ "。";
    say "";
    say "注意：如果 zef 也曾装过 raku-pm，那份不在我们管理范围内 ——";
    say "      `raku-pm` 命令可能仍然存在（会跑 zef 装的那份）。";
    say "      要一并清掉：zef uninstall RakuPM";
}
# 递归删除统一在 RakuPM::Fs（原先本 role 私有一份，与 Installer / Store / Cleaner
# 的实现重复，且各自的异常兜底与目录句柄处理不一致）。
