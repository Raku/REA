# RakuPM::Client — 编排器
#
# 仿 zef 的 Zef::Client：自己不干活，只把 Builder / Resolver / Store / Installer / Lock
# 按顺序编排起来。完整安装流程现在是：
#
#   解析(resolve) → 构建(build) → 入存储(store) → 测试(test) → 激活(install) → 写锁(lock)

use RakuPM::Repository::Local;
use RakuPM::Repository::Ecosystem;
use RakuPM::Repositories;
use RakuPM::Resolver;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Builder;
use RakuPM::Lock;
use RakuPM::NativeLib;
use RakuPM::MD5;
use RakuPM::FileLock;
use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::InstallOptions;
use RakuPM::Platform;
use RakuPM::Prefix;
use RakuPM::Client::SelfManager;
use RakuPM::Client::Tester;
use RakuPM::Client::Git;
use RakuPM::Client::Reporter;
use RakuPM::Client::Flusher;
use RakuPM::Cleaner;

unit class RakuPM::Client
    does RakuPM::Client::SelfManager
    does RakuPM::Client::Tester
    does RakuPM::Client::Git
    does RakuPM::Client::Reporter
    does RakuPM::Client::Flusher;

has RakuPM::Repository @.repos;
has RakuPM::Repositories $.repositories;
has IO::Path  $.target is required;   # 安装根目录，如 ~/.raku-pm
has IO::Path  $.store-root;           # 包存储目录
has IO::Path  $.lock-path;            # 锁文件路径
has RakuPM::Store     $.store;
has RakuPM::Installer $.installer;
has RakuPM::Builder   $.builder;
has RakuPM::Lock      $.lock;
# 装完把 bin wrapper 也复制进 rakudo site/bin（zef 同款：装完即用）。
#
# 【刻意不写默认值 —— 不写就是「未指定」】未显式传入时由 TWEAK 按**前缀**自动决定
# （见 RakuPM::Prefix.default-promote-bin）：默认前缀 → True；自定义前缀 → False。
# 为什么不能写 `= False`：那样就没法区分「调用方没传」与「调用方显式要求关」，
# 自动策略只能推给每个调用方自己算，于是「什么算默认前缀」又多出若干份实现。
# `has Bool $.x;` 读出的是未定义的 Bool（实测），正好当「未指定」用。
has Bool $.promote-bin;
# 测试并发度 / 单测试超时不再存为 Client 实例属性：统一由 RakuPM::InstallOptions
# 承载（test-jobs / test-timeout 字段），经 install* 入口合并进 $opts，最终在
# RakuPM::Client::Tester.!run-tests 消费（含 RAKUPM_TEST_JOBS / RAKUPM_TEST_TIMEOUT
# 环境变量的 auto 回退）。这样「散落策略」只剩 InstallOptions 这一个载体。
# 自装 raku-pm 时的 RAKULIB 遮蔽警告：每个进程只提示一次，避免重复刷屏
# 同时让测试可以断言「确实出了警告」而不是 grep stderr。
# 标记、提示方法都是 public，便于测试访问；项目本身只在自己内部调用。
has Bool $.did-self-shadow-warn = False;
# git URL 依赖（depends 里的裸 URL）安装去重守卫：同一 URL 在一次命令里
# 只 clone + 装一次。嵌套 git 依赖可能成环（A 的 git 依赖是 B、B 又依赖 A），
# 没有这个已见集合会无限递归下去。
has SetHash $!git-seen = SetHash.new;

# 把 Git Bash / MSYS 风格的路径（/c/Users/foo）转成 Windows 原生路径（C:\Users\foo）。
# 否则 Raku 会把 /c/Users/foo 当字面相对路径，写到 C:\c\Users\foo 这种鬼位置。
# PowerShell/CMD 直接传 C:\... 时不会触发。
#
# 实现已上移到 RakuPM::Platform.native-path —— 那边【按平台门控】：在 Linux 上
# `/c/foo` 是合法绝对路径，无条件转换会把它篡改成 C:\foo（旧实现没门控）。
# 这里保留同名门面，四处调用点不动。
our sub normalize-path(Str $p --> IO::Path) {
    native-path($p)
}

submethod TWEAK(:$repo-root) {
    # 修正 Git Bash / MSYS 路径
    $!target = normalize-path($!target.Str);
    my $rr     = normalize-path(($repo-root // '.').Str);

    # 仓库是【数组】：可同时挂多个生态索引（zef / rea / cpan…）+ 本地目录。
    # 来源优先级：repositories.json > RAKUPM_ECOSYSTEM（可逗号分隔多个）> 默认 zef。
    # 解析时各索引的候选会合并，取满足约束的最高版本。
    unless @!repos.elems {
        $!repositories //= RakuPM::Repositories.new(
            :config-file(self!repos-config-file),
            :cache-root($!target.add('cache')),
            :repo-root($rr.Str),
        );
        $!repositories.load;
        @!repos = $!repositories.build;
    }

    # 锁文件默认位置：bin 层在构造 Client 时总会显式传 :lock-path
    # （默认 $*CWD/raku-pm.lock，项目级、可提交；或 --lock-file 指定的路径），
    # 所以下面这行「库默认兜底」在 CLI 路径下几乎从不生效——只在库被直接调用
    # 且没传 lock-path 时才落到 target 下。锁（项目级）与包（全局 target）默认
    # 有意分离：锁记录「当前项目的依赖闭包」，包装在全局前缀里共享。
    $!store-root //= $!target.add('store');
    $!lock-path  //= $!target.add('raku-pm.lock');

    $!store     = RakuPM::Store.new(:root($!store-root));

    # promote-bin 未显式指定 → 按前缀自动决定（默认前缀才写全局 site/bin）。
    # 必须放在构造 Installer 之前：Installer 只认这个布尔值。
    $!promote-bin = default-promote-bin($!target) unless $!promote-bin.defined;

    $!installer = RakuPM::Installer.new(:target($!target), :store($!store),
                                        :promote-bin($!promote-bin));
    $!builder   = RakuPM::Builder.new;
    $!lock      = RakuPM::Lock.new(:path($!lock-path));
}

# ============ 并发保护：跨进程文件锁 ============
#
# 会写 target 的命令（store / site / installed.json / repositories.json / 索引缓存）
# 都必须走这里。两个 raku-pm 同时跑的典型事故：
#   · 同时往 store 放同一个版本 → 半份文件，指纹对不上，之后 verify 必失败；
#   · 同时回写 installed.json → 后写的把先写的整份冲掉，装过的信息凭空消失；
#   · 同时 promote bin / 装进 site → wrapper 指向还没写完的路径。
#
# 锁是 flock（详见 RakuPM::FileLock）：进程崩了由内核回收，不会留下陈旧锁；
# 同一进程内可重入（install 内部还会调 install / upgrade），靠引用计数管理，
# 只有最外层 release 才真正 unlock。
method !run-lock-path(--> IO::Path) {
    %*ENV<RAKUPM_LOCK_FILE>.defined
        ?? normalize-path(%*ENV<RAKUPM_LOCK_FILE>)
        !! $!target.add('.raku-pm.run.lock')
}

method with-write-lock(&block, Str :$what = '写操作',
                       Bool :$no-lock = False, Int :$timeout is copy) {
    # 两种「跳过锁」完全不同，别混在一起：
    #
    #  a) 用户逃生舱（$no-lock / RAKUPM_NO_LOCK）—— 用户显式要求，设了就生效。
    #     并发写会损坏 store / installed.json，只在确认没有别的 raku-pm 在跑时用。
    #
    #  b) 子进程继承（下面的 should-bypass）—— 父进程持锁期间派生的子进程
    #     （包的 Build.pm、测试里再调 `raku-pm install X`）不该等自己父进程
    #     手里的锁，否则自锁到超时。但这条路【不是】靠一个布尔环境变量开门：
    #     子进程必须带着父进程下的凭证、且校验「锁此刻确实被占」才放行。
    #     0.44.0 之前两条路共用 RAKUPM_NO_LOCK，等于给所有人开门 —— 任何继承
    #     了该变量的进程都自动获得 bypass 权限，连在锁内跑的测试都把锁当没加
    #     （真锁从未持起、断言恒真）。现在凭证是随机 token，伪造不了。
    #
    # 同进程嵌套（install 里再调 install 是常态）两条路都不走 —— 由
    # FileLock 的引用计数处理（见 should-bypass 首行的 %HELD 判定）。
    #
    # 注意 LEAVE 要在最前面声明并用 .defined 兜着：下面那条 return 发生在
    # $lock 赋值之前，不兜的话 LEAVE 会对 Any 调 release 直接崩。
    my $lock;
    LEAVE { $lock.release if $lock.defined }

    return &block()
        if $no-lock || ?(%*ENV<RAKUPM_NO_LOCK> // '').match(/\S/);

    my $lock-path = self!run-lock-path;
    return &block() if RakuPM::FileLock.should-bypass($lock-path);

    $timeout //= (%*ENV<RAKUPM_LOCK_TIMEOUT> // 600).Int;
    $lock  = RakuPM::FileLock.new(:path($lock-path));
    $lock.acquire(:$what, :$timeout);   # 持锁期间由 FileLock 给子进程下凭证

    &block()
}

method !repos-config-file(--> IO::Path) {
    %*ENV<RAKUPM_REPOS_FILE>.defined
        ?? normalize-path(%*ENV<RAKUPM_REPOS_FILE>)
        !! $!target.add('repositories.json')
}

# ============ 仓库管理 ============

method list-repos(--> Nil) {
    if $!repositories.defined {
        say $!repositories.describe;
        return;
    }
    for @!repos.kv -> $i, $r {
        say "  [$i] {$r.id}";
    }
}

# :$name 仅对本地目录仓库有意义（目录名不好看时可以自己起一个）。
method add-repo(Str $spec, Str :$name = '' --> Nil) {
    self!ensure-configurable;
    say $!repositories.add($spec, :$name);
}

method remove-repo(Str $spec --> Nil) {
    self!ensure-configurable;
    say $!repositories.remove($spec);
}

# 强制刷新生态索引缓存（zef update 同款）。$spec 空 → 全部，否则指定名字/URL。
method update-repos(Str $spec = '' --> Nil) {
    self!ensure-configurable;
    $!repositories.update($spec);
}

# repos add/remove 需要能落盘，若 Client 是被外部直接注入 repos 构造的就没有配置对象
method !ensure-configurable(--> Nil) {
    unless $!repositories.defined {
        die "当前 Client 未使用配置文件管理仓库（repos 是通过参数注入的）";
    }
}

# ============ 安装 ============

# 安装一个模块及其依赖（自底向上：依赖先于被依赖者）
# :version   精确指定版本（如 "1.2.0"）
# :locked    lock 与解析结果不符时直接报错（CI 用）
# :dry       只解析不落地
# :no-test           跳过测试阶段（默认会跑 t/ 下的测试，失败则中止）
# :no-build          跳过构建阶段（Build.pm / META6 builder）
# :no-test-deps      跳过「测试依赖（test-depends）」的安装（仅跑测试期生效）
# :no-native-check   跳过本地库（:from<native>）探测（CI 里可能不想看到系统级告警）
# :force             强制重装：已安装的照常重走构建/测试/安装，不跳过
method install(Str $module, Str $constraint = '',
               Str :$version, Str :$auth, Bool :$locked = False, Bool :$dry = False,
               Bool :$no-test = False, Bool :$no-build = False,
               Bool :$no-test-deps = False,
               Bool :$no-native-check = False, Bool :$force = False,
               Bool :$allow-test-failure = False,
               Int :$test-jobs = 0, Int :$test-timeout = 0, :%pins --> Nil) {

    # 把这一堆开关收成一个对象往下传（链上 6 层不再各抄一遍，见 InstallOptions 注释）。
    # 并发度 / 超时 / pin 表也并入 $opts，统一由 Tester / Resolver 在链上消费。
    my $opts = RakuPM::InstallOptions.new(
        :$locked, :$dry, :$no-test, :$no-build, :$no-test-deps,
        :$no-native-check, :$force, :$allow-test-failure,
        :pins(%pins), :$test-jobs, :$test-timeout,
    );

    # --locked 要求锁文件已存在（对齐 Cargo 语义）：没有锁直接报错，而不是静默放行。
    self!assert-lock-exists($opts.locked);

    # 精确版本优先级高于范围约束
    my $effective = $version.defined ?? "= $version" !! $constraint;

    # 目标已装且满足约束 → 不折腾（对齐 zef 的「All candidates are
    # currently installed」）。放在 resolve 之前：自装的本地包不在任何
    # 仓库里，先 resolve 会直接死。
    if !$opts.force && !$opts.dry && self!dep-satisfied($module, $effective) {
        say "==> 已安装：{$module}（满足约束，跳过；--force 强制重装）";
        return;
    }

    # 钉版提示：把用户 --pin 的模块列出来，让用户确认解析器在按他钉的版本装。
    if %pins.elems {
        my @p = %pins.sort.map({ "{.key}" ~ '@' ~ "{.value}" });
        say "==> 钉版（--pin）：{@p.join(', ')}";
    }

    my @order = self!resolve($module, $effective, $auth, :pins($opts.pins));

    if @order.elems == 0 {
        note "没有需要安装的内容";
        return;
    }

    # 严格模式：lock 与解析结果必须一致（锁存在性已在 !assert-lock-exists 兜住）
    $!lock.enforce(@order) if $opts.locked;

    say "将安装 {@order.elems} 个发行版（自底向上，依赖优先）：";
    for @order -> $dist {
        say "  · {$dist.identity()}";
    }

    # :from<native> 不是 Raku 包，只是系统级本地库，逐个探测后按需提示
    self!check-native-libs(@order)   unless $opts.no-native-check;
    # :from<bin>/:from<Perl5> 是外部命令 / 别的语言，同样只提示不安装
    self!check-external-deps(@order) unless $opts.no-native-check;

    if $opts.dry {
        say "--dry：仅解析，未落盘";
        return;
    }

    # 逐包：构建 → 入 store → 跑测试 → 激活到 site
    self!install-chain(@order, {}, %(), $opts);

    # 写锁文件
    $!lock.write(@order, :store($!store));
    say "✓ 完成。锁文件已更新：{$!lock-path}";
}

# 重装：把当前已装的某个（或某版本）包卸掉再按【完全相同版本】装回来。
# 对应 zef 的 `zef reinstall` —— 典型用途：某个包装坏了 / 想重跑它的构建与测试 /
# 想确保源码与 store 里的快照一致。`uninstall` 缺省会做反向依赖保护（有人依赖就
# 拦下或 --recursive 一并卸），`reinstall` 直接复用它，所以重装一个被依赖的包
# 同样会被拦（除非 --force / --recursive），不会静默弄坏依赖链。
#
# 语义要点：
#   · 按【账本里已装的版本】精确钉回（install 传 :version，避免被解析成升级）；
#   · 完全没装过 → 退化为一次普通 install（对齐 zef reinstall 的宽松语义）；
#   · 只认【包名 / 它提供的模块名】，不支持 git URL / 本地路径（那种用
#     uninstall + install-from-git/-dir 即可）。
#   · --dry：只打印「将重装哪些版本」并预览安装计划（uninstall 无 --dry，故 dry
#     时跳过卸载，只调 install :dry，不落盘）。
method reinstall(Str $module, Str $constraint = '',
                 Str :$version, Str :$auth, Bool :$force = False,
                 Bool :$recursive = False, Bool :$dry = False,
                 Bool :$no-test = False, Bool :$no-build = False,
                 Bool :$no-test-deps = False, Bool :$no-native-check = False,
                 Bool :$allow-test-failure = False,
                 Int :$test-jobs = 0, Int :$test-timeout = 0, :%pins --> Nil) {
    # 找当前已装的版本：按包名或它提供的模块名匹配（兼容 Foo 与 Foo::Bar 两种叫法）
    my @entries = self.installer.list-installed;
    my @have = @entries.grep({
        .<name> eq $module || ($module (elem) (.<provides> // []))
    }).map(*<version>).unique;
    if $version.defined && $version.chars {
        # --version 优先级最高（精确匹配）
        @have = @have.grep({ $_ eq $version });
    }
    elsif $constraint.defined && $constraint.chars {
        # 规格串里的 :ver<>（如 reinstall Foo:ver<1.0>）—— 与 install / version /
        # installed 等命令同义：用 satisfies 解释约束（'1.0' 精确、'1.0+' 范围）。
        # 修复前这里完全忽略 $constraint，导致 reinstall 某版本会把所有已装版本全重装，
        # 与 install / upgrade 都认规格串约束的行为不一致（见 review 清单 B2）。
        @have = @have.grep({ RakuPM::Version.from-string($_).satisfies($constraint) });
    }

    if @have.elems {
        for @have -> $v {
            say "==> 重装 {$module}:ver<$v>";
            # --dry：uninstall 没有 --dry，所以 dry 时只预览安装计划，不真正卸载
            unless $dry {
                self.uninstall($module, :version($v), :force($force), :$recursive, :keep-store);
            }
            # 装回同一版本：:version 精确钉住，避免被解析成升级；:force 确保即使
            # 卸载有残留也重走构建/测试/安装。
            self.install($module, '', :version($v), :auth($auth),
                         :dry($dry), :no-test($no-test), :no-build($no-build),
                         :no-test-deps($no-test-deps), :no-native-check($no-native-check),
                         :force(True), :allow-test-failure($allow-test-failure),
                         :test-jobs($test-jobs), :test-timeout($test-timeout), :%pins);
        }
        say "✓ 重装完成：{$module}（{@have.elems} 个版本）";
    }
    else {
        note "{$module} 当前未安装 —— 退化为一次全新安装";
        self.install($module, $constraint, :version($version), :auth($auth),
                     :dry($dry), :no-test($no-test), :no-build($no-build),
                     :no-test-deps($no-test-deps), :no-native-check($no-native-check),
                     :force($force), :allow-test-failure($allow-test-failure),
                     :test-jobs($test-jobs), :test-timeout($test-timeout), :%pins);
    }
}

# --locked 要求锁文件已存在：没有锁就报错，而不是静默放行。
# 之前是 `if $locked && $!lock.exists` 才 enforce —— 锁不存在时整段检查被跳过，
# CI 里锁漏提交、--locked 照样装出非预期版本，等于没有保护。对齐 Cargo 语义：
# 要求 --locked 却没有锁 = 报错。
method !assert-lock-exists(Bool $locked --> Nil) {
    return unless $locked;
    return if $!lock.exists;
    die "--locked 要求锁文件已存在，但没有找到：{$!lock-path}\n"
      ~ "提示：先不带 --locked 跑一次 install 生成锁，并把它提交进版本库。";
}

# 自底向上把一批发行版落地：构建 → 入 store → 跑测试 → 激活到 site。
# 仓库安装与 git 安装共用这一段，保证两条路径行为一致。
#
# %source-override 用于「源码目录不在任何仓库里」的包 —— 也就是 git 模式的目标包，
# 它的源码就是 clone 出来的那份。键是 "<name>\0<version>"，值是源码目录；
# 其余包仍由各自的仓库回答（Client 不该猜仓库内部布局）。
#
# %build-guard 是重入护栏：某发行版的 build-depends 会先被递归安装，可能与
# 主链重叠，也可能自己又带 build-depends —— 用它防重复安装与递归环。
#
# 跳过规则（都可用 --force 关掉）：
#   1. 该版本已安装（raku-pm 自己装的，或 zef 装的）→ 整个跳过；
#   2. 该版本已在 store 里 → 跳过构建与测试（入库时已经做过），直接激活；
#   3. store 里有该版本但是老格式（缺标准 META6.json）→ 自动重新入库。
#
# 所有开关收在 InstallOptions 一个对象里往下传 —— 原先 7 个布尔开关要在 6 层
# 签名里各抄一遍，漏抄一处就「开关传了但不起作用」（!ensure-git-deps /
# !ensure-phase-deps 就真漏过）。见 RakuPM::InstallOptions。
method !install-chain(@order, %source-override, %build-guard,
                      RakuPM::InstallOptions $opts) {
    # ---- P6 原子安装 + 整树事务化 ----
    # 整条链先把所有包装进【整树暂存 CUR】（target/stage/pending），测试也在
    # 那里跑；只有【全部通过】后才由 promote-pending 一次性原子晋升到真实
    # CUR + 账本 + bin。期间真实 CUR / installed.json 【自始未被触碰】—— 任一包
    # 失败或进程中断，直接丢弃暂存即可，无需逐个回滚（崩溃-safe）。成功则落一个
    # 世代，可 `raku-pm rollback` 退回。事务可嵌套：最外层那次才真正开世代 /
    # 晋升 / 清理，内层复用外层事务。
    my $outer = $!installer.transaction-depth == 0;
    $!installer.begin-transaction();
    my $failure;
    {
        self!install-chain-inner(@order, %source-override, %build-guard, $opts);
        CATCH { default { $failure = $_ } }
    }
    if $failure.defined {
        # 失败：真实 CUR 未被触碰，只需丢弃暂存；rollback 仅清事务状态
        #（无真实改动可撤，但会丢弃本次的世代目录、复位账本快照）。
        $!installer.discard-pending;
        $!installer.rollback-transaction();
        $failure.rethrow;
    }
    # 整树全过 → 原子晋升到真实 CUR（仅最外层执行一次；内层复用外层事务）。
    if $outer {
        try {
            $!installer.promote-pending;
            CATCH { default { $failure = $_ } }
        }
        if $failure.defined {
            # 晋升中途失败：已写入真实 CUR 的部分由 rollback 摘掉。
            $!installer.discard-pending;
            $!installer.rollback-transaction();
            $failure.rethrow;
        }
        $!installer.cleanup-stage-all;   # 晋升完成，清暂存目录
    }
    # 自底向上的顺序里最后一个就是本次的【目标包】（依赖都在它前面）。
    # 把它标成 explicit —— 用户点名要的；其余保持 dependency（依赖拉进来的）。
    # 卸载时的依赖回收靠这个区分：只回收 dependency 且已无人依赖的孤儿。
    $!installer.mark-explicit(@order[*-1].name) if @order.elems && $opts.mark-explicit;
    $!installer.commit-transaction();
}

method !install-chain-inner(@order, %source-override, %build-guard,
                      RakuPM::InstallOptions $opts) {
    for @order -> $dist {
        my $key = "{$dist.name}\0{$dist.version}";
        next if %build-guard{$key};
        %build-guard{$key} = True;

        # 自装 raku-pm 本身时的遮蔽警告：raku-pm 装出来的副本会进 site/ 并
        # 在 RAKULIB 上排第一，把之后 `zef install . --force-install` 装进去
        # 的新版盖住。所以默认推荐升级走 zef；自装的副本用户自己清理。
        # 用户的旧场景：~/.raku-pm/site/ 里残留旧版 RakuPM，git pull + 重装都没用，
        # 因为 RAKULIB 第一位永远是那个旧版。
        if $dist.name eq 'RakuPM' {
            self.warn-self-shadow($dist.version);
        }

        # ---- 跳过规则 1：已安装（自己的账本 + zef 的 site/home/vendor）----
        # zef 装过的包我们再装一遍纯属浪费：同样的下载、同样的测试。
        # 但注意只按「精确版本」判断 —— 解析挑的是满足约束的最高版本，
        # 若已装版本不同则照常装（多版本本来就是支持的）。
        my $chain = $*REPO.repo-chain;
        if !$opts.force && self.is-installed($dist, :$chain) {
            # 已装但账本缺记（历史版本格式差异 / 安装中断 / `raku-pm installed`
            # 自愈没跑过）→ 在被跳过时顺手补记，否则 `raku-pm installed` 会
            # 看不到它。用户的 Grammar::DSN 案例：旧代码版本装的、账本从未记到。
            self.maybe-adopt($dist, :$chain);
            # 已装跳过也要把条目补进锁：否则锁长期缺这个包（虽然它已装）。
            self!record-installed-to-lock($dist);
            say "==> 已安装：{$dist.name} {$dist.version}（跳过，--force 强制重装）";
            next;
        }

        my $source = %source-override{$key} // self!source-dir-for($dist);

        # 早失败并说清楚是哪个包，别等到 store.put 里再抛个不相干的错误
        unless $source.defined && $source.d {
            die "找不到 {$dist.name} {$dist.version} 的源码目录" ~
                "（已配置的仓库：{@!repos.map(*.id).join(', ')}）";
        }

        # ---- 跳过规则 3：store 里需要重新入库 → 重新入库 ----
        # 两类：老格式（0.2.x 之前缺标准 META6.json / 资源声明过时），
        # 以及内容被篡改（!needs-readmit 里的 verify 不通过）。后者之前
        # 会「跳过入库 → Installer 完整性校验直接 die」，用户除了手删整个
        # store 没别的办法；现在自动重新入库，从干净源码恢复。
        my $readmit = !$opts.force && self!needs-readmit($dist);
        if $readmit {
            say "==> 存储条目需要重新入库：{$dist.name} {$dist.version}"
              ~ "（老格式或内容校验未通过，自动恢复）";
        }

        # ---- 跳过规则 2：store 里已有完整条目 → 跳过构建与测试 ----
        # 入库的前提就是构建和测试都通过了，再来一遍纯属浪费时间。
        # （--force 时照常全跑，用于「我就是想重验一遍」。）
        # 构建事实：交给 Store.put 落成条目的 build.json 旁车（见 RakuPM::Builder.facts）
        my %build = %();
        if $readmit || !$opts.force && $!store.has($dist.name, $dist.version) {
            # 老格式重新入库前也要先构建：老条目入库时可能还没支持 Build 阶段，
            # 生成的资源文件在源码目录上，重新入库才能把它们复制进去。
            my $needs-build = $!builder.needs-build($source, $dist);
            # git URL 依赖先进场：构建脚本可能要 use 它们。
            # 【调用时机与原实现逐字一致】：只在「确实要构建」时调（--no-build
            # 跳过构建时不装 git 依赖）。
            self!ensure-git-deps($dist, $opts) if $needs-build && !$opts.no-build;
            %build = self!build-phase($dist, $source, %build-guard, $opts);
            if $readmit {
                my $digest = $!store.put($dist, $source, build => %build);
                say "==> 重新入库完成：{$dist.name} {$dist.version} ({$digest.substr(0,8)})";
            }
            else {
                say "==> 已在存储中：{$dist.name} {$dist.version}"
                  ~ "（跳过构建与测试，--force 强制重跑）";
            }
            # 整树事务化：即便本分支跳过构建与测试，也要把包装进整树暂存 CUR，
            # 否则整链通过后晋升会漏掉它（与「即时 install 到真实 CUR」的旧行为
            # 在最终落地结果上一致，只是推迟到晋升阶段）。
            $!installer.install-pending($dist, :source($source.absolute));
        }
        else {
            # git URL 依赖先进场：build 与 test 都可能要 use 它们（Draku 案例）
            self!ensure-git-deps($dist, $opts);

            # 构建阶段（zef 的顺序：build 在 test 之前 —— 测试可能要用构建产物）。
            # 必须在 store.put 之前：Build 生成的 resources 才会被复制进 store。
            # 唯一的实现处见 !build-phase（此前这里与上面的 readmit 分支各写一遍，
            # 加一个字段就要改两处 —— 项目最高产的漏传模式）。
            %build = self!build-phase($dist, $source, %build-guard, $opts);

            my $digest = $!store.put($dist, $source, build => %build);
            say "==> 存入存储：{$dist.name} {$dist.version} ({$digest.substr(0,8)})";

            # 运行时 native 库（`is native('...')`）缺失即放弃安装：这些库名
            # 不在 META6 的 :from<native> 里，静态检查看不到，只能等测试阶段
            # 加载库失败才暴露。这里取到源码后、跑测试/激活前就挖出来查，缺了
            # 直接 die（由外层 CATCH 回滚）。--no-native-check 可整体跳过（与
            # :from<native> 检查同一开关）。
            self!check-runtime-native-libs($dist, $source) unless $opts.no-native-check;

            # 整树事务化：本包装进【整树暂存 CUR】（target/stage/pending），不写
            # 真实 CUR / 账本。测试从暂存 CUR 加载（native 包才能拿到
            # %?RESOURCES），依赖也优先从暂存 CUR 解析——二者由 Tester 通过独立的
            # pending-lib-spec（pending 激活时恒非空）注入 @inc 最前实现，不再依赖
            # 把 pending 拼进 raku-lib-spec（那会被 Rakudo 当单条 -I 吞掉，0.60.0 修复）。
            # 整条链全过后才由 promote-pending 原子晋升到真实 CUR。
            $!installer.install-pending($dist, :source($source.absolute));

            # 测试：在源码目录上跑 t/，本包与依赖都优先从暂存 CUR 加载（见 Tester @inc 顺序）
            unless $opts.no-test {
                # 测试依赖（test-depends）必须在跑测试前可用：典型如 Test::META，
                # 只在测试期被 use，装完即可回收。与 build-depends 同思路——自底向上，
                # 走 :!mark-explicit，卸掉目标包后能被 autoremove 回收。
                # --no-test-deps 时可跳过安装（用户自担风险：测试可能因缺依赖而挂）。
                self!ensure-phase-deps($dist, %build-guard, 'test', $opts);
                self!run-tests($dist, $source, :allow-test-failure($opts.allow-test-failure), :$opts);
            }
        }

        # 事务化激活：本包已装进整树暂存 CUR（install-pending），不再直接写真实
        # CUR / 账本——失败时真实 CUR 自始未被触碰，无需逐个回滚。整链全过后由
        # promote-pending 一次性原子晋升到真实 CUR。
        say "==> 已暂存 {$dist.name} {$dist.version}（待整链通过后晋升）";
    }
}

# store 里的条目是否需要重新入库（在「已入 store → 跳过」之前判定）。
# 两类需要：
#   1. 老格式：Store.needs-readmit（缺标准 META6.json / 资源声明过时）；
#   2. 内容被篡改：store 有条目但 verify 不通过（.digest 对不上）—— 之前这种
#      条目会被「跳过入库」，紧接着 Installer 的完整性校验直接 die，用户除了
#      手删整个 store 没别的办法。现在自动重新入库，从干净源码恢复。
method !needs-readmit(RakuPM::Distribution $dist --> Bool) {
    return True if $!store.needs-readmit($dist.name, $dist.version, :$dist);
    return True if $!store.has($dist.name, $dist.version)
                 && !$!store.verify($dist.name, $dist.version);
    False
}

# 「已装跳过」路径也要把条目补进锁：否则锁长期缺这个包（虽然它已装）。
# ensure-entry 只在锁里没有同名条目时补记，绝不覆盖已有记录。
method !record-installed-to-lock(RakuPM::Distribution $dist --> Nil) {
    $!lock.ensure-entry($dist, :store($!store));
}

# 这个发行版这个版本是否已经装好 —— 两处账本：
#   1. raku-pm 自己的 installed.json（我们装进 target/site 的）；
#   2. 进程的仓库链（$*REPO.repo-chain）里的所有 Installation 仓库 ——
#      zef 装的包在 site/home/vendor 里，默认就在链上，直接读它的发行版清单。
# :$chain 可注入（测试用），生产路径不传。
method is-installed(RakuPM::Distribution $dist,
                    :$chain = $*REPO.repo-chain --> Bool) {
    # 自己装的
    return True if $dist.version (elem) $!installer.installed-versions($dist.name);

    # zef 装的：遍历所有 Installation 仓库的已装清单
    for @$chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        for $repo.installed -> $d {
            my $n = $d.meta<name>  // '';
            my $v = $d.meta<version> // $d.meta<ver> // '';
            return True if $n eq $dist.name && $v eq $dist.version;
        }
    }
    False
}

# 构建阶段（唯一的实现处）。返回「构建事实」，交给 Store.put 落成 build.json 旁车。
#
# 【为什么抽出来】此前两处分支（readmit / 新装）各写一遍
# `needs-build` → `ensure-phase-deps` → `run` → `die`。加一个字段就要改两处
# —— 这正是本项目最高产的缺陷模式（resources / builder / build-depends /
# test-depends 全都这样漏过）。
#
# 【为什么要把「跳过」也记下来】构建是唯一一个「失败了却可能不留痕」的阶段：
# Store 只把【磁盘上真实存在】的资源写进 store 的 META6（必须如此，否则
# CUR::Installation 装不上），于是「构建没跑成功 → 资源没生成」在元数据里被
# 静默剔除。记下 mode 之后，verify 才能区分「构建失败」「被 --no-build 跳过」
# 「本来就不需要构建」「没有记录」这四种情形。
#
# 注意：本方法【只做构建】。ensure-git-deps 的调用时机在两处原有差异
# （分支 A 仅在确实要构建时调、分支 B 无条件先调），刻意留在调用方不动。
method !build-phase(RakuPM::Distribution $dist, IO::Path $source, %build-guard,
                    RakuPM::InstallOptions $opts --> Hash) {
    return $!builder.facts($source, $dist, :mode('not-needed'))
        unless $!builder.needs-build($source, $dist);
    if $opts.no-build {
        say "==> 跳过构建（--no-build）：{$dist.name} {$dist.version}";
        return $!builder.facts($source, $dist, :mode('skipped-no-build'));
    }
    self!ensure-phase-deps($dist, %build-guard, 'build', $opts);
    my $ok = $!builder.run($dist, $source,
                           :repo-spec($!installer.raku-lib-spec),
                           :pending-spec($!installer.pending-lib-spec));
    die "构建失败：{$dist.name} {$dist.version}（--no-build 可跳过构建阶段）"
        unless $ok;
    $!builder.facts($source, $dist, :mode('built'), :ran, :ok($ok));
}

# git URL 形式的依赖（depends 里的裸 URL）先行安装。
# 典型：Draku 的 META6.json 依赖里直接写
#   "git://github.com/jkramer/p6-Text-Wrap.git"
# 这种依赖没法按名字进仓库解析，只能在轮到该发行版之前先把仓库 clone 下来、
# 当普通发行版走完整安装链（install-from-git 内部会递归处理它自己的依赖）。
# 与 !ensure-phase-deps 同一思路；$!git-seen 记 URL 防环（A→B→A 死循环）。
method !ensure-git-deps(RakuPM::Distribution $dist,
                        RakuPM::InstallOptions $opts --> Nil) {
    my @urls = $dist.git-deps;
    return unless @urls.elems;

    for @urls -> $url {
        next if $url (elem) $!git-seen;
        $!git-seen{$url} = True;   # 先标记再装：嵌套成环时靠它截断
        say "";
        say "==> {$dist.name} 声明了 git 仓库依赖（先装它）：{$url}";
        # 【整份 opts 透传】—— 原先这里只挑 4 个开关抄（no-test / no-build /
        # force / allow-test-failure），漏掉了 no-native-check：用户加
        # `--no-native-check` 装一个带 git 依赖的包时，那个 git 依赖仍会跑本机
        # 库检查，缺库就 die，把整条链回滚 —— 用户明明关了检查却照样被拦。
        # 收成一个对象后这类漏传在结构上不可能再发生。
        # :mark-explicit(False)：git 依赖是「为了别人才装的」，不该标 explicit。
        # :%pins：把用户钉的版本也带进 git 依赖的子链解析。
        self.install-from-git($url, :opts($opts.with(:mark-explicit(False))), :pins($opts.pins));
    }
}

# 按「阶段」先行安装依赖：build 相（构建依赖）或 test 相（测试依赖）。
# 两阶段逻辑完全同构，区别仅在：取哪个 *.depends 访问器、以及 test 相可被
# --no-test-deps 显式跳过。0.35.0 初版曾把 build/test 各写一份方法，正是
# 《软件设计哲学》点名的「浅层重复 + 纠缠」——改归一逻辑得同时改两处；收成一份后
# build/test 归一永远同步，注释也不会漂移。
# 自底向上原则同样适用：这些依赖必须在构建/测试开始前可用。
method !ensure-phase-deps(RakuPM::Distribution $dist, %build-guard, Str $phase,
                          RakuPM::InstallOptions $opts --> Nil) {
    return if $phase eq 'test' && $opts.no-test-deps;   # 仅 test 相支持跳过
    # 自己提供的模块不算外部依赖（与 resolve-deps-of 同一规则）
    my %deps = $phase eq 'test' ?? $dist.test-depends !! $dist.build-depends;
    return unless %deps.elems;

    my @specs;
    for %deps.kv -> $module, $constraint {
        next if $dist.provides-module($module);
        @specs.push(%( module => $module, constraint => $constraint ));
    }
    return unless @specs;

    my $resolver = RakuPM::Resolver.new(:repos(@!repos));
    my @order = $resolver.resolve-all(@specs, :pins($opts.pins));
    self!report-cycles($resolver.cycles);
    # 已被主链处理过（或正在处理）的跳过，防重复
    @order = @order.grep({ !%build-guard{"{.name}\0{.version}"} });
    return unless @order.elems;

    my $label = $phase eq 'test' ?? '测试依赖' !! '构建依赖';
    say "  · 先装{$label}：{@order.map(*.name).join(', ')}";
    # 【整份 opts 透传】—— 原先这里也只挑 3 个开关抄，漏了 no-native-check
    # 与 allow-test-failure：构建/测试依赖的安装因此永远无法软通过已知平台失败、
    # 也无法跳过本机库检查。收成一个对象后漏传在结构上不可能再发生。
    # :mark-explicit(False) —— 这些依赖不是用户点名要的，保持 dependency，
    # 这样卸掉依赖它的包之后，它们能被 autoremove 回收。
    self!install-chain(@order, %(), %build-guard, $opts.with(:mark-explicit(False)));
}

# 在「已安装跳过」路径上顺手把账本补齐。
# is-installed 只回答「有没有」，不保证 raku-pm 自己的账本里有该条目。
# 这种「site 有、账本没有」的状态来源有几种：
#   · 用早期 raku-pm（0.11 之前）装的，install 没有 !record 这一步；
#   · 安装中断（用 --force-install 这种 zef 命令人为中断）；
#   · 直接 cp -r 把 store 目录搬过来，没经过 raku-pm 装入逻辑。
# 不补的话 `raku-pm installed` 看不到它，依赖判定也少一份数据。
# 「自家 site」用 prefix 比对，只补自管的发行版；zef 侧的不归我们账本管。
# 公开方法：! 前缀会让外部调用编译报错，所以这里去掉 ! 让测试方便。
method maybe-adopt(RakuPM::Distribution $dist,
                   :$chain = $*REPO.repo-chain --> Nil) {
    # 账本已记 → nothing（避免无谓写）
    return if $dist.version (elem) $!installer.installed-versions($dist.name);

    my $own-prefix = $!installer.repo-prefix.absolute;
    for @$chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        # 只在自己 site 里找 —— 装进 zef 站的发行版不该出现在我们账本里
        my $prefix = (try { $repo.prefix.absolute }) // '';
        next unless $prefix && $prefix eq $own-prefix;
        for $repo.installed -> $d {
            next unless ($d.meta<name> // '') eq $dist.name;
            my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
            next unless $v eq $dist.version;
            my %prov = $d.meta<provides> // {};
            my @p = %prov ~~ Hash ?? %prov.keys !! @(%prov);
            say "==> 账本缺记，已从自家 site 补记：{$dist.name} {$dist.version}";
            my $rd = RakuPM::Distribution.new(
                :name($dist.name), :version($v),
                :auth(($d.meta<auth> // '').Str),
                :provides(@p), :depends({}));
            $!installer.record-entry($rd);
            return;
        }
    }
}

# 自装 raku-pm 自身时的 RAKULIB 遮蔽警告（每进程一次）。
# 抽出独立方法是为了测试可断言（看 $.did-self-shadow-warn），不必抓 stderr。
method warn-self-shadow(Str $version --> Nil) {
    return if $!did-self-shadow-warn;
    $!did-self-shadow-warn = True;
    note "";
    note "⚠  你正在自装 raku-pm 自身（'RakuPM' {$version}）。";
    note "   自装的 RakuPM 会进 site/ 并占据 RAKULIB 首位，";
    note "   遮蔽后续 `zef install . --force-install` 装进去的更新版。";
    note "   推荐升级方式：";
    note "       zef install <raku-pm 仓库路径> --force-install";
    note "   升级后请清理 ~/.raku-pm/site/ 里旧版 RakuPM 残留，避免再次被遮蔽。";
    note "";
}

# ============ 本地库（:from<native>）检查 ============






# 升级：把已安装的包升到仓库中满足约束的最高版本
method upgrade(Str $name, Str :$version = '', Bool :$only = False, Bool :$dry = False --> Bool) {
    my $current = $!installer.installed-version($name);
    die "$name 尚未安装" unless $current.defined;

    my $target = $version.trim.chars ?? $version.trim !! self!latest-version-of($name);
    my $cmp = RakuPM::Version.from-string($target).cmp(RakuPM::Version.from-string($current));

    if $cmp == Same {
        say "$name 已是版本 $current";
        return False;
    }

    my @higher = self!installed-higher-than($name, $target);

    # ---- 降级：只有 --only 才会让 use 真的切到目标版本 ----
    if $cmp == Less && $only {
        if @higher {
            say "降级 $name：先卸载更高的版本 {@higher.join(', ')}";
            for @higher -> $v {
                $!installer.uninstall($name, :version($v)) unless $dry;
            }
        }
    }

    say ($cmp == Less ?? "降级" !! "升级") ~ " $name：{$current} -> {$target}"
      ~ ($cmp == Less && $only ?? "（--only：已清理更高版本）" !! "");
    # 注意：不能写成 `:$version($target)` —— upgrade 自己就有 `Str :$version`
    # 形参，那种写法会被解析成「短配对 (version => $version) 再拿 ($target) 去
    # 调用它」，触发 No such method 'CALL-ME' for invocant of type 'Pair'。
    # 用显式 fat-comma `version => $target` 才是「具名参数 version 取值 $target」。
    self.install($name, version => $target, :$dry);

    # 没清掉更高的版本 → use Foo 仍会加载最高的那个，必须说清楚，
    # 不能装完就撒手让用户以为降级生效了。
    if $cmp == Less && !$only && @higher {
        my $top = @higher[*-1];
        say "";
        say "⚠  注意：$name 仍装有更高的版本 {@higher.join(', ')}。";
        say "   Raku 的 `use $name`（不带版本约束）永远加载最高版本 ——";
        say "   这是 Rakudo 的行为，raku-pm 改不了（t/multi-version.t 已钉死）。";
        say "   所以现在实际生效的仍是 $top，不是刚装的 $target。";
        say "   要让 $target 生效：";
        say "     · 加 --only 重装（会先卸载更高的版本）；或";
        # 这里必须用拼接：写成 "use $name:ver<$target>" 会让 Raku 把
        # :ver<...> 当成变量 $name 的 adverb，整段被解析成一个未声明的变量名。
        say '     · 代码里显式写 use ' ~ $name ~ ':ver<' ~ $target ~ '>';
    }
    True
}

# 更新【所有】已装包 —— `raku-pm upgrade` 不带包名时的行为，
# 与 zef upgrade / apt upgrade / npm update 的惯例一致。
# 单个包失败不中断其余（记下来最后汇总），因为一批包里有一个装不上
# 不该连累别的。
method upgrade-all(Bool :$dry = False --> Nil) {
    self.reconcile-installed;
    my @entries = $!installer.list-installed;
    my @names   = @entries.map({ $_<name> }).unique.sort;

    unless @names.elems {
        say "还没有通过 raku-pm 安装任何包。";
        return;
    }

    say "检查 {@names.elems} 个已装包的新版本……";
    my (@upgraded, @skipped, @failed);
    for @names -> $n {
        # 本地目录 / git 装的包不在任何仓库里，无从判断"最新版" —— 跳过并说明
        my $e = @entries.first({ $_<name> eq $n });
        if $e && ($e<source> // '').chars {
            say "  · $n：源码安装（{$e<source>}），跳过";
            @skipped.push($n);
            next;
        }
        # 【三态】upgrade 的返回值语义（别再写成 try { ...; True }）：
        #   · 返回 True  → 真的升/降了级
        #   · 返回 False → 已是最新版，无需升级（不是失败！）
        #   · 抛异常     → 升级失败
        # 之前写成 `try { self.upgrade($n, :$dry); True }` —— try 块最后一句
        # 是字面 True，于是「失败」和「已是最新」统统被计进 @upgraded，
        # 汇总永远显示「已更新 N 个」且 N 恒等于包总数。
        my $ok = try { self.upgrade($n, :$dry) };
        if $!.defined {
            my $why = $!.Str.chars ?? $!.Str.lines[0] !! '原因未知';
            note "  ! $n 升级失败：$why";
            @failed.push($n);
        }
        elsif $ok {
            @upgraded.push($n);
        }
        else {
            # 已是最新版 —— upgrade 内部已打过 "$name 已是版本 X"
            @skipped.push($n);
        }
    }

    say "";
    say "已更新 {@upgraded.elems} 个" ~ (@upgraded.elems ?? "：{@upgraded.join(', ')}" !! "");
    if @skipped.elems {
        say "无需更新 {@skipped.elems} 个（已是最新 / 源码安装）";
    }
    if @failed.elems {
        say "失败 {@failed.elems} 个：{@failed.join(', ')}（上面的错误里有原因）";
    }
}

# `raku-pm outdated` —— 列出已装包中可升级的（当前激活版本 → 生态里的最新版本）。
# 只读：不联网安装、不改账本、不进写锁；纯对比，对应 `npm outdated` /
# `apt list --upgradable`。离线或生态里找不到某包的版本时跳过并说明，不报错。
method outdated(--> Nil) {
    # 直接读账本（不经过 reconcile-installed，避免这个只读命令顺手改写账本）
    my @entries = $!installer.list-installed;
    my @names   = @entries.map({ $_<name> }).unique.sort;

    unless @names.elems {
        say "还没有通过 raku-pm 安装任何包。";
        return;
    }

    my (@rows, @skipped);
    for @names -> $n {
        my $e = @entries.first({ $_<name> eq $n });
        # 源码 / git 装的包不在任何仓库里，无从判断「最新版本」——跳过
        if $e && ($e<source> // '').chars {
            @skipped.push($n);
            next;
        }
        my $current = $!installer.installed-version($n);
        # 生态里的最新版本：离线 / 索引未刷新 / 名字不在任何仓库时都会失败，
        # 这些都不是 outdated 的错，静默跳过（不污染「可升级」列表）。
        my $latest;
        try { $latest = self!latest-version-of($n) }
        if $!.defined || !$latest.defined {
            @skipped.push($n);
            next;
        }
        my $cmp = RakuPM::Version.from-string($latest).cmp(
                      RakuPM::Version.from-string($current));
        if $cmp == More {
            @rows.push: %(:name($n), :current($current), :latest($latest));
        }
    }

    if @rows.elems {
        say "可升级的包（{@rows.elems} 个）：";
        for @rows.sort(*<name>) -> %r {
            # 用 %-Ns 左对齐（Raku 字符串无 .pad 方法，踩过）
            say "  {%r<name>.fmt('%-28s')} {%r<current>.fmt('%-12s')} → {%r<latest>}";
        }
        say "";
        say "升级全部：raku-pm upgrade";
        say "升级单个：raku-pm upgrade <包名>";
    }
    else {
        say "全部已是最新（raku-pm 管理的包）。";
    }
    if @skipped.elems {
        say "（跳过 {@skipped.elems} 个：源码安装 / 生态里找不到，可 `raku-pm upgrade` 看详情）";
    }
}

# 该包已装的、比 $version 更高的版本（降级时要处理的对象）
method !installed-higher-than(Str $name, Str $version --> List) {
    my $t = RakuPM::Version.from-string($version);
    $!installer.installed-versions($name).grep({
        RakuPM::Version.from-string($_).cmp($t) == More
    }).List
}

# 仓库里能提供的最高版本
method !latest-version-of(Str $name --> Str) {
    my @versions;
    for self!dist-names-for-module($name) -> $dn {
        for @!repos -> $repo {
            @versions.append(|$repo.available-versions($dn));
        }
    }
    @versions = @versions.unique;
    my $latest = RakuPM::Version.new.pick-best('', @versions);
    die "无法解析 $name 的可用版本" unless $latest;
    $latest
}

# ============ 对 raku-pm 自己的操作 ============













# ============ 查询 ============














# ============ 源码目录安装（git clone / 本地目录）============
#
# 这两种情况本质相同：目标包【不在任何仓库里】，Resolver 看不见它，
# 只能由我们把它接到依赖链的最后。区别只是它的源码目录从哪来。





# 递归解析一个发行版的依赖，返回【不含它自己】的自底向上安装顺序。
#
# 用于 git 安装：目标包不在任何仓库里，Resolver 只能看见它的依赖，
# 由调用方把目标包拼到最后。公开出来是为了可测，也方便外部拿到
# 「某个发行版的完整依赖闭包」。
# 依赖是否已被已安装的包满足。对齐 zef 的「只装缺失的依赖」：
# 依赖模块若已安装（raku-pm 账本或 zef 的仓库链上都有）且版本满足约束，
# 就不必再从仓库解析 —— 这也是本地自装包能被其他本地包当依赖的前提
# （它们不在任何生态索引里，纯靠仓库解析必死）。
# 模块名按 provides 匹配（提供者的发行版名可能不同于模块名）。
method !dep-satisfied(Str $module, Str $constraint --> Bool) {
    # 数据源 1：raku-pm 自己的账本。
    # 依赖名也可能按【发行版名】声明（fez:ver<38+> 这种，provides 里没有小写 fez），
    # 所以发行版名相同同样算满足。
    my $ledger = $!installer.list-installed
        .first({ $module (elem) @($_<provides> // []) || $_<name> eq $module });
    if $ledger.defined {
        my @vs = |@($ledger<versions> // []), ($ledger<version> // '');
        for @vs.grep(*.chars).unique -> $v {
            return True if RakuPM::Version.from-string($v).satisfies($constraint);
        }
    }
    # 数据源 2：进程仓库链上的 Installation 仓库（zef 装的）
    for $*REPO.repo-chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        for $repo.installed -> $d {
            my %prov = $d.meta<provides> // {};
            my @names = %prov ~~ Hash ?? %prov.keys !! @(%prov);
            next unless $module (elem) @names || ($d.meta<name> // '') eq $module;
            my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
            return True if $v.chars
                && RakuPM::Version.from-string($v).satisfies($constraint);
        }
    }
    False
}

# 把一个「模块名或发行版名」规格定位到一个具体的发行版（含版本挑选）。
# 返回 Hash：name（索引里的发行版名）/ version（选中的版本）/ dist（元数据对象）。
#
# 【只读元数据，不物化源码】这是它有别于 !fetch-source 的关键：`raku-pm depends`
# 只想看一眼依赖图，不该为了看一眼就把 tarball 下下来。
#
# 挑版本走 RakuPM::Version.pick-best（semver），不是字典序 —— 字典序会把
# 0.9.2 判成高于 0.13.0，显示与「取最高」都会错。
#
# $eff 是**已归一化**的版本约束（'' / '>=1.0' / '= 1.2.3'），由调用方算好：
# 「--version 精确版优先于约束串」这条优先级只在一处写，别在这里再写一遍。
#
# 【为什么放在 Client 而不是各 role】fetch（Git role）与 depends（Reporter role）
# 都要用它。各写一份就会漂移 —— 本项目在 Fs / Ledger / Distribution 上已经反复
# 吃过这个亏。挑不到就 die：对调用方来说这是「查不到」，不是「可忽略」。
method !resolve-dist-for-spec(Str $spec, Str $eff = '' --> Hash) {
    # 既能按模块名（provides）也能按发行版名取
    my @names = |self!dist-names-for-module($spec);
    @names.push($spec) unless @names.elems;

    my ($name, $ver) = ('', '');
    for @names.unique -> $n {
        my @vs;
        for self.repos -> $r { @vs.append(|$r.available-versions($n)) }
        @vs = @vs.grep(*.chars).unique;
        next unless @vs.elems;
        my $best = RakuPM::Version.new.pick-best($eff, @vs);
        next unless $best.chars;
        ($name, $ver) = ($n, $best);
        last;
    }

    unless $name.chars {
        die "在所有已配置的仓库里都找不到 {$spec}"
          ~ ($eff.chars ?? "（版本约束 {$eff}）" !! '')
          ~ "。\n已配置的仓库：{self.repos.map(*.id).join(', ')}";
    }

    for self.repos -> $r {
        my $d = try $r.fetch-distribution($name, $ver);
        return %( name => $name, version => $ver, dist => $d ) if $d.defined;
    }
    die "无法从仓库读取 {$name} {$ver} 的元数据";
}

method resolve-deps-of(RakuPM::Distribution $dist, :%pins --> List) {
    my @specs;
    for $dist.depends.kv -> $module, $constraint {
        # 自己提供的模块不算外部依赖（有些包的 META6 会把自己提供的模块也写进 depends）
        next if $dist.provides-module($module);
        # 已被已安装的包满足（raku-pm 或 zef 装的）→ 不再要求仓库里有。
        # 对齐 zef 的「只装缺失的依赖」—— 你自装的本地包（Grammar::DSN 这类
        # 生态索引里没有的）因此可以被其他本地包当依赖使用。
        next if self!dep-satisfied($module, $constraint);
        @specs.push(%( module => $module, constraint => $constraint ));
    }
    return () unless @specs;

    my $resolver = RakuPM::Resolver.new(:repos(@!repos));
    my @order = $resolver.resolve-all(@specs, :%pins);
    self!report-cycles($resolver.cycles);

    # 目标包自己也提供某些模块。若依赖树里出现了另一个「提供同一模块」的发行版，
    # 以目标包为准 —— 用户明确指定要装 git 上的这一份。
    @order.grep({
        !$_.provides.first({ $dist.provides-module($_) })
    }).List
}








# ============ 本地发行版的单阶段执行（raku-pm test / build）============
#
# 对应 zef 的 `zef test .` 与 `zef build .`：只跑一个阶段，不安装、不写 store、
# 不动账本、不碰锁文件。典型用途是开发时改完代码立刻跑一遍测试。
#
# 【刻意不替你装依赖】这两个命令只**报告**缺哪些 phase 依赖，不顺手去装。理由：
#   · 用户的意图是「跑一下看看」，不是「改我的环境」；
#   · 安装要走跨进程写锁 + 事务，而这两个命令是只读的 —— 混在一起会让一条
#     只读命令随时可能变成一个长时间的联网安装（还会改写 store 与账本）。
# 缺依赖时给一句明确的下一步，而不是替用户决定。
#
# 【为什么不是 install --no-...】install 的每个开关都在安装链上（resolve → store
# → test → activate），没有「只跑到 test 就停」的形态；硬凑会出现「半装」状态。

# 从本地目录读出一个发行版。识别判据与 install-from-dir 同一份（只认 META6.json）。
method !dist-from-dir(IO::Path $dir --> RakuPM::Distribution) {
    my $path = $dir.absolute.IO;
    die "目录不存在：{$path}" unless $path.d;
    my $meta = self!find-meta-file($path);
    die "{$path} 里找不到 META6.json，无法识别为一个发行版" unless $meta.defined;
    RakuPM::Distribution.from-meta-file($meta);
}
# 报告某个阶段（test / build）缺哪些依赖 —— 只报告、不安装（理由见上）。
# 为什么值得单独报：不报的话「缺依赖」会以「某个用例里的 use 失败」的形态出现，
# 输出里只有一堆堆栈，指不到「你少了 3 个包」这个结论。
method !report-missing-phase-deps(RakuPM::Distribution $dist, Str $phase --> Nil) {
    my %deps = $phase eq 'test' ?? $dist.test-depends !! $dist.build-depends;
    my @missing;
    for %deps.kv -> $mod, $cons {
        next if $dist.provides-module($mod);
        next if self!dep-satisfied($mod, $cons);
        @missing.push($cons.chars && $cons ne '*' ?? "{$mod} {$cons}" !! $mod);
    }
    return unless @missing;
    note "⚠ {$phase} 阶段缺 {@missing.elems} 个依赖（这两个命令不会替你装）：";
    note "    {@missing.join(', ')}";
    note "  先跑 `raku-pm install .`（它连 {$phase} 依赖一起装好），之后就都能用了。";
}
# 只跑测试（raku-pm test <路径>）。
method test-dir(IO::Path $dir, Bool :$allow-test-failure = False,
                Int :$test-jobs = 0, Int :$test-timeout = 0 --> Nil) {
    my $path = $dir.absolute.IO;
    my $dist = self!dist-from-dir($path);

    my @tests = self.test-files($path);
    unless @tests.elems {
        note "{$dist.name} 没有可跑的测试（没有 t/ 目录，或 t/ 下没有 .t / .rakutest）。";
        return;
    }

    say "==> 测试 {$dist.identity()}（不安装）";
    self!report-missing-phase-deps($dist, 'test');
    # !run-tests 的语义正好是我们要的：任一用例失败即 die（→ 非零退出码），
    # 「命令的成败 = 测试的成败」。它自己会打印每个文件的成败与日志位置。
    self!run-tests($dist, $path, :$allow-test-failure,
                   :opts(RakuPM::InstallOptions.new(:$test-jobs, :$test-timeout)));
    say "✓ 测试通过：{$dist.name} {$dist.version}";
}
# 只跑构建（raku-pm build <路径>），不安装。
method build-dir(IO::Path $dir --> Nil) {
    my $path = $dir.absolute.IO;
    my $dist = self!dist-from-dir($path);

    unless self.builder.needs-build($path, $dist) {
        say "==> {$dist.name} {$dist.version} 没有构建步骤"
          ~ "（既无 Build 文件，META6 也没声明 builder）—— 无需构建";
        return;
    }

    say "==> 构建 {$dist.identity()}（不安装）";
    self!report-missing-phase-deps($dist, 'build');
    # repo-spec 传 inst#<target>/site：Build 脚本里 use 的依赖（LibraryMake 这类）
    # 从已装的 CUR 里加载 —— 与安装链里跑构建时用的是同一个规格串。
    my $ok = self.builder.run($dist, $path,
                              :repo-spec(self.installer.raku-lib-spec),
                              :pending-spec(self.installer.pending-lib-spec));
    die "构建失败：{$dist.name} {$dist.version}（细节见上方输出）" unless $ok;
    say "✓ 构建成功：{$dist.name} {$dist.version}";
}

# 冒烟测试：取源码并跑测试（仿 zef smoke）。
# 给定规格 → 逐个取源码（走 !source-dir-for，带缓存）后跑 test-dir，统计通过/失败/跳过；
# 不给规格 → 对所有已装发行版逐一尝试（best-effort，离线或取不到源码的会跳过），
# 这与 `zef smoke` 默认测全部已装一致，但可能很慢，按需使用。
# !source-dir-for 对生态发行版要联网下载（离线会被 try 兜住 → 计为跳过）。
method smoke(*@specs, Bool :$allow-test-failure = False,
             Int :$test-jobs = 0, Int :$test-timeout = 0 --> Nil) {
    my @targets = @specs.elems
        ?? @specs.map(*.Str).unique.List
        !! self.installer.list-installed.map(*<name>).unique.List;
    unless @targets.elems {
        say "没有可冒烟测试的包（也没指定要测的包）。";
        return;
    }
    my ($pass, $fail, $skip) = 0, 0, 0;
    for @targets -> $spec {
        my %root;
        my $ok = try { %root = self!resolve-dist-for-spec($spec, ''); True };
        unless $ok.defined && %root<dist>.defined {
            note "  ⊘ 跳过 {$spec}（仓库里找不到，无法取源码）";
            $skip++; next;
        }
        my $dist = %root<dist>;
        my $dir = try { self!source-dir-for($dist) };
        unless $dir.defined && $dir.d {
            note "  ⊘ 跳过 {$dist.name} {$dist.version}（无法取得源码目录，可能离线）";
            $skip++; next;
        }
        # test-dir 默认「任一用例失败即 die」→ 被 try 兜住计为失败；
        # --allow-test-failure 时它不 die，正常结束计为通过。
        my $res = try { self.test-dir($dir, :$allow-test-failure, :$test-jobs, :$test-timeout); True };
        if $res.defined {
            say "  ✓ {$dist.name} {$dist.version}";
            $pass++;
        }
        else {
            note "  ✗ {$dist.name} {$dist.version} 测试失败";
            $fail++;
        }
    }
    say "";
    say "冒烟测试完成：{$pass} 通过 / {$fail} 失败 / {$skip} 跳过（共 {@targets.elems} 个）";
}

# ============ 缓存回收（raku-pm clean / gc）============
#
# store 只增不减：self-upgrade 每次留一份快照、升级留下的旧版本、卸载后
# 剩下的 store 条目，日积月累能到几百 MB。回收判定（哪些版本还在被用）
# 与实际的删除都交给 RakuPM::Cleaner，这里只负责把它接起来。
method clean(Bool :$all = False, Bool :$yes = False,
             Int :$older-than = 0, Str :$name = '' --> Nil) {
    my $cleaner = RakuPM::Cleaner.new(
        :target($!target), :store($!store),
        :installer($!installer), :lock($!lock));
    # 默认试算：删文件不可撤销，必须显式 --yes 才落盘
    $cleaner.run(:$all, :$older-than, :$name, :dry(!$yes));
}

# ============ 内部 ============

method !resolve(Str $module, Str $constraint, Str $auth = '', :%pins --> List) {
    my $resolver = RakuPM::Resolver.new(:repos(@!repos));
    my @order = $resolver.resolve($module, $constraint, :auth($auth), :%pins);
    self!report-cycles($resolver.cycles);
    @order.List
}

# 依赖环提示。生态索引里确实存在互相依赖的发行版数据，Resolver 已经把它们
# 排到末尾继续装了，这里只是告诉用户「顺序上我们做了妥协」。
method !report-cycles(@cycles --> Nil) {
    return unless @cycles.elems;
    note "";
    note "⚠  检测到依赖环（已按名字兜底排序，不影响安装，但顺序可能与作者预期不同）：";
    for @cycles.unique -> $c {
        note "    · $c";
    }
}

# 从仓库定位某发行版的源码目录。
# 关键：由仓库自己回答（它才知道内部布局），Client 不靠目录名猜测。
method !source-dir-for(RakuPM::Distribution $dist --> IO::Path) {
    for @!repos -> $repo {
        my $dir = $repo.source-dir-for($dist.name, $dist.version);
        return $dir if $dir.defined && $dir.d;
    }
    die "无法定位发行版 {$dist.name} {$dist.version} 的源码目录";
}



# 找到能提供某模块名的发行版名字
method !dist-names-for-module(Str $module --> List) {
    my @out;
    for @!repos -> $repo {
        @out.append(|$repo.find-providers($module));
    }
    @out.unique.List
}
