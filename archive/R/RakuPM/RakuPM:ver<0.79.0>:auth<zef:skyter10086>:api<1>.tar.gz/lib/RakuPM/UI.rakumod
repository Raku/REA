# RakuPM::UI — 终端展示层：色彩 / 表格 / 阶段条（零第三方依赖）
#
# 为什么自写而不是 use Terminal::Table / Terminal::ANSIColor：
#   raku-pm 是【包管理器】。界面美化若引入第三方依赖，会变成它自己的安装负担：
#   ① 用户装 raku-pm 前得先装那几个库（自举链多一环）；
#   ② 门禁/CI 会依赖「本机 site 恰好装了它们」这一手工状态，换台机器就红；
#   ③ 本机 zef 的 tar 解压已损坏（GNU tar 1.35 + zef 1.1.3），装任何外部包都得绕。
#   而 Raku 内置 uniprop('East_Asian_Width') 已足够算中文列宽，故全部自写。
#
# 两条铁律：
#   【自动降级】非 TTY（管道 / 重定向 / 测试捕获）或设了 NO_COLOR / RAKUPM_NO_COLOR
#     时一律输出纯文本：无 ANSI 转义码、边框退化成 ASCII。现有测试捕获 stdout，
#     因此拿到的仍是可断言的纯文本，改造不会撞红。
#   【按显示宽度对齐】中文是双宽字符，必须按【显示宽度】而非 .chars 填充，
#     否则表格列会歪。W(宽) / F(全角) 记 2 列，其余记 1 列，组合字符记 0。
unit module RakuPM::UI;

# ---------- 富文本模式（色彩 + Unicode 边框）----------
# 一次性判定并缓存：$*OUT 是不是终端。ui-set-rich 可显式覆盖（CLI --no-color / 测试）。
my Bool $rich-forced = False;
my Bool $rich-cached = False;
my Bool $rich-ready  = False;

sub ui-set-rich(Bool $on --> Nil) is export {
    $rich-forced = True;
    $rich-cached = $on;
    $rich-ready  = True;
}

sub ui-rich(--> Bool) is export {
    return $rich-cached if $rich-ready;
    # 注意：别把两个 :exists 用 || 连起来写 ——
    # `%*ENV<A>:exists || %*ENV<B>:exists` 会被 Raku 解析成给 `||` 加 adverb
    # 而报 "You can't adverb &infix:<||>"。拆成独立分支最稳。
    my Bool $r;
    if %*ENV<NO_COLOR>:exists {
        $r = False;
    }
    elsif %*ENV<RAKUPM_NO_COLOR>:exists {
        $r = False;
    }
    else {
        # $*OUT.t：句柄是否连着终端。捕获/管道/重定向时为 False，异常也退 False。
        $r = (try { $*OUT.t }) // False;
    }
    $rich-cached = $r;
    $rich-ready  = True;
    $r
}

# ---------- 语义色（自动降级：非 rich 时原样返回）----------
sub ansi-wrap(Str $code, Str $s --> Str) {
    ui-rich() ?? "\e[{$code}m{$s}\e[0m" !! $s;
}

sub ui-red(Str $s --> Str) is export     { ansi-wrap('31', $s) }
sub ui-green(Str $s --> Str) is export   { ansi-wrap('32', $s) }
sub ui-yellow(Str $s --> Str) is export  { ansi-wrap('33', $s) }
sub ui-blue(Str $s --> Str) is export    { ansi-wrap('34', $s) }
sub ui-magenta(Str $s --> Str) is export { ansi-wrap('35', $s) }
sub ui-cyan(Str $s --> Str) is export    { ansi-wrap('36', $s) }
sub ui-bold(Str $s --> Str) is export    { ansi-wrap('1', $s) }
sub ui-dim(Str $s --> Str) is export     { ansi-wrap('2', $s) }

# ---------- 显示宽度 ----------
# 字符串的终端显示列数：先剥掉 ANSI 转义序列，再逐字符按东亚宽度累加。
sub ui-width(Str $s --> Int) is export {
    # 只匹配 SGR 序列 \e[<数字;分号>m。字符类必须写 <[...]>，用 \d 而非 0-9
    # （Rakudo 2026.08 会把字符类里的 0-9 当范围报错）。
    my Str $plain = $s.subst(:g, / \e \[ <[\d;]>* m /, '');
    my Int $w = 0;
    for $plain.comb -> $c {
        my Int $cp = $c.ord;
        next if $cp < 32 || $cp == 127;              # 控制字符不占列
        my Str $gc = (try { $c.uniprop('General_Category') }) // '';
        next if $gc eq 'Mn' || $gc eq 'Me' || $gc eq 'Cf';   # 组合/格式字符不占列
        my Str $ea = (try { $c.uniprop('East_Asian_Width') }) // '';
        $w += ($ea eq 'W' || $ea eq 'F') ?? 2 !! 1;  # 宽/全角 = 2，其余 = 1
    }
    $w
}

# 按【显示宽度】左（默认）或右填充到 $width 列。
sub ui-pad(Str $s, Int $width, Bool :$right = False --> Str) is export {
    my Int $gap = $width - ui-width($s);
    return $s if $gap <= 0;
    $right ?? (' ' x $gap) ~ $s !! $s ~ (' ' x $gap);
}

# 超出 $max 显示宽度时从【头部】省略（保留尾部 —— 路径的目录名信息量最大）。
# 用于表格里的长路径，避免一列把整张表撑爆。
sub ui-ellipsis(Str $s, Int $max --> Str) is export {
    return $s if ui-width($s) <= $max;
    return $s if $max <= 1;
    my Str $acc = '';
    for $s.comb.reverse -> $c {
        my Str $cand = $c ~ $acc;
        last if ui-width($cand) > $max - 1;
        $acc = $cand;
    }
    '…' ~ $acc;
}

# ---------- 表格 ----------
# $headers：表头单元格列表；$rows：行列表（每行是单元格列表）。
# 整格内容按【显示宽度】对齐（中文按 2 列）；rich 时用 Unicode 制表符，
# 否则退化成 ASCII（保证管道 / 日志 / 测试里是纯 ASCII）。
#
# 【坑 1 · 出在调用点】Raku 的 [ ... ] 构造器在「唯一参数本身就是数组」时会再展平一层：
#     [['1','2']]   求值 → ['1','2']     （一行被拆成两行，第二列全空！）
#     (['1','2'],)  求值 → [['1','2'],]  （正确）
#   所以「只有一行」的字面量必须写成 (['...'],)（或加尾随逗号 [['...'],]）。
#   传【变量】（如 @rows）不受影响 —— 生产代码走的都是变量，故只有测试会踩。
# 【坑 2 · 出在形参】同理别用 @-sigil 形参收这些列表（@ 形参也会展平一层），
#   故这里统一用标量形参，内部自己 .list 遍历。
sub ui-table($headers, $rows --> Str) is export {
    my @h = $headers.list.map({ $_.Str });
    my @r = $rows.list.map({ [ $_.list.map({ $_.Str }) ] });
    # 表头可以为空（键值表场景）：此时列数从第一行推。
    my Int $cols = @h.elems || (@r[0] // []).elems;
    return '' unless $cols;

    # 每列宽度 = 表头与所有该列单元格显示宽度的最大值
    my @w = (^$cols).map(-> $i {
        my Int $m = ui-width(@h[$i] // '');
        for @r -> $row { $m = $m max ui-width($row[$i] // '') }
        $m
    });

    my Bool $rich = ui-rich();
    my Str $v  = $rich ?? '│' !! '|';
    my Str $hh = $rich ?? '─' !! '-';
    my Str $tl = $rich ?? '┌' !! '+';
    my Str $tm = $rich ?? '┬' !! '+';
    my Str $tr = $rich ?? '┐' !! '+';
    my Str $ml = $rich ?? '├' !! '+';
    my Str $mm = $rich ?? '┼' !! '+';
    my Str $mr = $rich ?? '┤' !! '+';
    my Str $bl = $rich ?? '└' !! '+';
    my Str $bm = $rich ?? '┴' !! '+';
    my Str $br = $rich ?? '┘' !! '+';

    my &hrule = -> $l, $m, $rr { $l ~ @w.map({ $hh x ($_ + 2) }).join($m) ~ $rr };
    my &datarow = -> @cells {
        $v ~ @w.kv.map(-> $i, $cw { ' ' ~ ui-pad(@cells[$i] // '', $cw) ~ ' ' }).join($v) ~ $v
    };

    my Bool $with-head = @h.elems > 0;
    my @out;
    @out.push(&hrule($tl, $tm, $tr));
    if $with-head {
        @out.push(&datarow(@h));
        @out.push(&hrule($ml, $mm, $mr));
    }
    for @r -> $rowcells { @out.push(&datarow($rowcells)) }
    @out.push(&hrule($bl, $bm, $br));
    @out.join("\n")
}

# 直接打印表格（返回 Nil，避免调用点再写 say）。
sub ui-print-table($headers, $rows --> Nil) is export {
    say ui-table($headers, $rows);
}

# 键值表（无表头两列）：@pairs 是 (label, value) 对的列表。
# 键名右对齐成同宽，值左对齐 —— 比逐行 `say "描述：..."` 更整齐。
sub ui-kv-table($pairs --> Str) is export {
    my @rows = $pairs.list.map({ [ $_.[0].Str, $_.[1].Str ] });
    return '' unless @rows.elems;
    # 键名统一右对齐宽度，值列不定宽（交给表格按内容算）
    my Int $kw = @rows.map({ ui-width($_[0]) }).max;
    my @padded = @rows.map({ [ ui-pad($_[0], $kw, :right), $_[1] ] });
    ui-table((), @padded)
}

# ---------- 键值卡片（show-info 用）----------
# label 统一宽度的两栏：label 用青色（rich 时），值原样。
sub ui-field(Str $label, Str $value --> Str) is export {
    ui-rich() ?? (ui-cyan($label) ~ $value) !! "{$label}{$value}"
}

# ---------- 阶段条（预留：安装/升级流程的 [i/n] 进度）----------
sub ui-stage(Int $done, Int $total, Str $label --> Str) is export {
    my Str $counter = ui-dim("[{$done}/{$total}]");
    "{$counter} {$label}"
}

# ---------- 启动横幅：艺术字标题（仅 rich 时返回，管道/测试下一律为空串）----------
# 关键设计：非 rich 返回 ''，于是 help 的纯文本输出与「加横幅之前」【逐字节一致】——
# 终端里好看，又不惊动任何以 stdout 为纯文本的既有断言（如「help 首行含『用法』」）。
sub ui-banner(--> Str) is export {
    return '' unless ui-rich();
    my Str $art = q:to/ART/;
    ██████╗  █████╗ ██╗  ██╗██╗   ██╗        ██████╗ ███╗   ███╗
    ██╔══██╗██╔══██╗██║ ██╔╝██║   ██║        ██╔══██╗████╗ ████║
    ██████╔╝███████║█████╔╝ ██║   ██║██████╗ ██████╔╝██╔████╔██║
    ██╔══██╗██╔══██║██╔═██╗ ██║   ██║╚═════╝ ██╔═══╝ ██║╚██╔╝██║
    ██║  ██║██║  ██║██║  ██╗╚██████╔╝        ██║     ██║ ╚═╝ ██║
    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝         ╚═╝     ╚═╝     ╚═╝
    ART
    my Str $tag = '  ' ~ ui-dim('一个教学用的 Raku 包管理器')
                ~ ui-dim('  ·  ') ~ ui-cyan('raku-pm help') ~ ui-dim('  查看全部命令');
    ui-bold(ui-cyan($art)) ~ $tag ~ "\n\n";
}

# ---------- help 正文上色（仅 rich；非 rich 原样返回，逐字节不变）----------
# 只「套色」不改字符：关掉色彩后与原文完全相同，故对管道 / 测试零影响。
#   命令名（行首两空格后的标识符）→ 粗体绿；--长旗标 → 黄；<占位符> → 品红。
sub ui-colorize-help(Str $text --> Str) is export {
    return $text unless ui-rich();
    my @out;
    for $text.lines -> $line {
        my Str $l = $line;
        # ① 行首命令名：两空格 + 小写标识符 + 后随空白。
        #    「后随空白」这个约束顺手排除了 `i=install` 这类别名行（= 不是空白），
        #    而 `--offline` 这类旗标行以 `-` 开头，本就命不中 [a-z]。
        # 注：Raku 正则不支持 \s{2} 这种 {N} 量词，必须写 `\s ** 2`。
        $l = $l.subst(/^ (\s ** 2) (<[a..z]>) (<[\w-]>*) <?before \s> /,
                      -> $/ { $0 ~ ui-bold(ui-green($1 ~ $2)) });
        # ② 长旗标 --xxx（到 = 或非 [\w-] 为止，故 --version=X 只染 --version）
        $l = $l.subst(:g, / '--' <[\w-]>+ /, -> $/ { ui-yellow(~$/) });
        # ③ 短旗标 -x：两侧都不是 [\w-]（避免撞上 Web-App、--help）
        $l = $l.subst(:g, / <!after <[\w-]>> '-' (\w) <!before <[\w-]>> /,
                      -> $/ { ui-yellow(~$/) });
        # ④ 占位符 <xxx>
        $l = $l.subst(:g, / '<' (<-[>]>+) '>' /, -> $/ { ui-magenta('<' ~ $0 ~ '>') });
        @out.push($l);
    }
    @out.join("\n") ~ ($text.ends-with("\n") ?? "\n" !! '');
}

# ---------- 树形连接符（rich=Unicode 制表符，非 rich=ASCII）----------
# 与表格同口径：管道 / 日志 / 测试里退化成 ASCII，终端里才是漂亮的制表符。
sub ui-tree-branch(Bool $last --> Str) is export {
    ui-rich() ?? ($last ?? '└─ ' !! '├─ ') !! ($last ?? '`- ' !! '|- ');
}
sub ui-tree-child(Bool $last --> Str) is export {
    ui-rich() ?? ($last ?? '   ' !! '│  ') !! ($last ?? '   ' !! '|  ');
}
