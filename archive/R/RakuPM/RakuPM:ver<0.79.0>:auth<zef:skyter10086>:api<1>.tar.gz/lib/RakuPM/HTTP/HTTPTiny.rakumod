use RakuPM::HTTP::Backend;
use HTTP::Tiny;

# RakuPM::HTTP::HTTPTiny — 用纯 Raku 的 HTTP::Tiny 发请求（无外部进程依赖）。
#
# 这是 raku-pm 的【兜底】内置 HTTP 后端：默认顺序里排第二（tinyish 优先）。
# 机器上没装 curl 时，tinyish 不可用，本后端仍能发请求。失败（success=False）
# 一律 die，由门面统一重试 / 回退。本地索引文件（非 http(s)）不走这里，由
# Ecosystem 直接用 IO::Path 读取，不进本网络层。
unit class RakuPM::HTTP::HTTPTiny does RakuPM::HTTP::Backend;

has Str      $.proxy    = '';     # 代理 URL，空串=不代理
has Numeric  $.max-time = 120;    # 单次请求超时（秒）；<=0 表示不设上限

# 【自己实现超时（0.36.21）】HTTP::Tiny 没有可用超时（它的 timeout 只在内部
# Handle 上声明且全文零读取，也不是 .new 的公开选项），链路一停流就会无限等 ——
# 曾经的「raku-pm 卡死」就是这个（与 Windows 管道无关，WSL 一样复现）。
# 做法：把请求丢进线程，轮询等它，超过 max-time 就抛错，交给门面去重试 / 回落。
#
# 诚实的边界：被放弃的那个线程【杀不掉】（它卡在 socket 读上，Raku 没有线程
# 取消机制），会一直挂到进程退出；实测确认它不会阻止进程正常退出。所以最坏
# 情况是「重试 3 次 = 最多 3 个悬挂线程」，而不是「永久卡住不返回」。
method !with-timeout(&op) {
    return &op() if $!max-time <= 0;          # 未设上限：直接跑，不加这层
    my $p = start { &op() };
    my $ticks = ($!max-time * 10).Int max 1;  # 0.1s 一跳
    for ^$ticks {
        last unless $p.status ~~ Planned;
        sleep 0.1;
    }
    return $p.result if $p.status ~~ Kept;
    $p.cause.rethrow if $p.status ~~ Broken;
    die "HTTP::Tiny 请求超过 {$!max-time}s 未完成（已放弃本次请求；"
      ~ "HTTP::Tiny 自身没有超时机制，这一层是我们自己加的闸）";
}

method get-text(Str $url --> Str) {
    self!with-timeout({
        my $res = HTTP::Tiny.new(|self!attrs).get($url);
        $res<success> or die "HTTP::Tiny 获取 $url 失败：status={$res<status>}";
        $res<content> ~~ Blob ?? $res<content>.decode('utf-8') !! $res<content>.Str
    })
}

method download(Str $url, IO::Path $dest --> Nil) {
    self!with-timeout({
        my $res = HTTP::Tiny.new(|self!attrs).get($url);
        $res<success> or die "HTTP::Tiny 下载 $url 失败：status={$res<status>}";
        if $res<content> ~~ Blob {
            $dest.spurt($res<content>, :bin);
        }
        else {
            $dest.spurt($res<content>.Str);
        }
    })
}

# 条件 GET：带 If-None-Match 请求。HTTP::Tiny 对 304 的 success=False，
# 所以这里直接按 status 判断（200=新内容 / 304=未修改），其它状态抛错触发重试。
#
# 【关键陷阱（0.36.20 修复）】请求头必须传给 .get()，不能塞进 .new()：
# HTTP::Tiny 的构造选项叫 default-headers，`.new(headers => …)` 会被静默丢弃，
# 请求里根本没有 If-None-Match —— 条件 GET 形同虚设，每次都全量重下整个索引。
# 只有 `.get($url, headers => …)`（→ request 的 :%headers）才会真正发出去。
method get-text-conditional(Str $url, Str :$if-none-match = ''
                            --> RakuPM::HTTP::ConditionalResponse) {
    self!with-timeout({
        my %opt = timeout => $!max-time;
        %opt<proxy> = $!proxy if $!proxy.chars;
        my $client = HTTP::Tiny.new(|%opt);
        my $res = $if-none-match.chars
            ?? $client.get($url, headers => %( 'If-None-Match' => $if-none-match ))
            !! $client.get($url);
        my $status = ($res<status> // 0).Int;
        unless $status == 200 || $status == 304 {
            die "HTTP::Tiny 条件获取 $url 失败：status=$status";
        }
        my $body = $res<content> // '';
        $body = $body ~~ Blob ?? $body.decode('utf-8') !! $body.Str;
        my Str $etag = '';
        if $res<headers> ~~ Associative {
            for $res<headers>.kv -> $k, $v {
                $etag = $v.Str.trim if $k.lc eq 'etag';
            }
        }
        RakuPM::HTTP::ConditionalResponse.new(:$status, :$body, :$etag)
    })
}

method !attrs(--> Hash) {
    # 注意：HTTP::Tiny 0.2.6 里 timeout 只在内部 Handle 上声明且从未被读取，
    # 也不是 .new 的公开选项 —— 这个选项其实不起作用。真正的超时由本类的
    # !with-timeout 在【调用侧】兜（见上），别指望客户端自己会超时。
    my %a = timeout => $!max-time;
    %a<proxy> = $!proxy if $!proxy.chars;     # 代理
    %a
}
