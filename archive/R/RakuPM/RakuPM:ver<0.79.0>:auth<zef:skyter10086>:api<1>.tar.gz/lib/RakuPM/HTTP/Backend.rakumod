# RakuPM::HTTP::Backend — HTTP 客户端插件接口。
#
# 任何想接入 raku-pm 网络层的实现都 `does` 这个 role：
#   · get-text($url, *%opts --> Str)        拉取文本（如生态索引 JSON）
#   · download($url, $dest, *%opts --> Nil) 下载二进制到本地文件
#   · get-text-conditional($url, :if-none-match) 条件拉取（带 304 语义）
#
# %opts 约定键：:proxy(Str)、:max-time(Numeric 秒)。
# 约定：失败一律 die，由 RakuPM::HTTP 门面统一做重试/退避与多后端回退。
#
# 内置实现见同目录的 HTTPTiny.rakumod；用户也可在代码里
# `RakuPM::HTTP.register-backend('myclient', MyClient)` 注册自己的实现。

# 条件 GET 的返回：status 200=有新内容 / 304=未修改（复用缓存），
# body 为响应正文（304 时为空），etag 为上游返回的 ETag（供下次条件请求）。
class RakuPM::HTTP::ConditionalResponse is export {
    has Int  $.status = 200;
    has Str  $.body   = '';
    has Str  $.etag   = '';
    method not-modified(--> Bool) { $!status == 304 }
}

role RakuPM::HTTP::Backend {
    method get-text(Str $url, *%opts --> Str) { ... }
    method download(Str $url, IO::Path $dest, *%opts --> Nil) { ... }

    # 条件请求：带 If-None-Match 去拉，远端没变就回 304（body 空），调用方
    # 据此复用本地缓存、跳过下载。默认实现退化为普通 GET（永远 200 + 正文、
    # etag 空），所以自定义后端 / 测试桩即使不重写此方法也能直接用。
    method get-text-conditional(Str $url, Str :$if-none-match = ''
                                --> RakuPM::HTTP::ConditionalResponse) {
        RakuPM::HTTP::ConditionalResponse.new(:status(200), :body(self.get-text($url)));
    }
}
