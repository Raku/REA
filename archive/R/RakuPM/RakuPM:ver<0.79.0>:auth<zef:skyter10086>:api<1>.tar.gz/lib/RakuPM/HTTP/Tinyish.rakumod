use RakuPM::HTTP::Backend;
use HTTP::Tinyish;

# RakuPM::HTTP::Tinyish — 用 HTTP::Tinyish（底层走系统 curl）发请求。
#
# 这是 raku-pm 的【首选】内置 HTTP 后端：curl 对 TLS / 代理（含 HTTPS 走代理的
# CONNECT 隧道）支持最稳，能拉通那些纯 Raku 的 HTTP::Tiny 在「代理拦截 TLS」环境下
# 会报 status=599 / sslv3 alert handshake failure 的源。失败（success=False 或
# 非 2xx/304）一律 die，由门面统一做重试 / 多后端回退。
#
# 与已删除的自管 curl 子进程（旧 Curl.rakumod，曾因 run() 管道句柄泄漏挂死）不同，
# 这里整个网络由成熟依赖 HTTP::Tinyish 自己管理子进程生命周期，raku-pm 不碰 run()，
# 不会重蹈覆辙。本地索引文件（非 http(s)）不走这里，由 Ecosystem 直接用 IO::Path 读。
unit class RakuPM::HTTP::Tinyish does RakuPM::HTTP::Backend;

has Str      $.proxy    = '';     # 代理 URL，空串=不代理（HTTP::Tinyish 也会读环境代理）
has Numeric  $.max-time = 120;    # 单次请求超时（秒）→ 以 timeout 传给后端（curl --max-time）

method !attrs(--> Hash) {
    # 【关键陷阱（0.36.20 修复）】选项名是 timeout，不是 max-time。
    # HTTP::Tinyish::Curl 的属性是 $!timeout（内省确认），写 max-time 会被静默丢弃
    # —— 实测：max-time=3 时 59s 仍不返回，timeout=3 时 3.1s 就返回 status=599。
    # 超时没生效 = 链路一停流就无限挂，而且与平台无关（Windows / WSL 都一样）。
    my %a = timeout => $!max-time;
    %a<proxy> = $!proxy if $!proxy.chars;     # 代理
    %a
}

method get-text(Str $url --> Str) {
    my %r = HTTP::Tinyish.new(|self!attrs).get($url);
    %r<success> or die "HTTP::Tinyish 获取 $url 失败：status={%r<status> // 'n/a'} reason={%r<reason> // ''}";
    my $c = %r<content> // '';
    $c ~~ Blob ?? $c.decode('utf-8') !! $c.Str
}

method download(Str $url, IO::Path $dest --> Nil) {
    # 源码包是二进制（tar.gz 等）：必须给 .get 传 :bin，让 HTTP::Tinyish 的
    # request(..., Bool :$bin) 命中命名参数、底层 IO.slurp(:bin) 返回 Buf[uint8]。
    # 注意不能把 bin 放进 new(|%opt) 或 %opts 里——那样只会落到 .new（无此属性，
    # 被忽略）而 .get($url) 仍不带 bin，request 永远用 :$bin=False 把响应体当
    # UTF-8 解码，遇到二进制字节直接抛「Malformed UTF-8 near byte ...」。文本类
    # 请求（get-text / 条件 GET）则不带 :bin，拿解码后的 Str。
    my %r = HTTP::Tinyish.new(|self!attrs).get($url, :bin);
    %r<success> or die "HTTP::Tinyish 下载 $url 失败：status={%r<status> // 'n/a'} reason={%r<reason> // ''}";
    my $c = %r<content> // Buf[uint8].new;
    if $c ~~ Blob {
        $dest.spurt($c, :bin);
    }
    else {
        $dest.spurt($c.Str);
    }
}

# 条件 GET：带 If-None-Match 请求。直接按 status 判断（200=新内容 / 304=未修改），
# 其它状态抛错触发重试（实测 HTTP::Tinyish 对 304 的 success 是 True，不能看 success）。
#
# 【关键陷阱（0.36.20 修复）】请求头必须传给 .get()，不能塞进 .new()：
# HTTP::Tinyish 的构造选项叫 default-headers，`.new(headers => …)` 会被静默丢弃，
# 请求里根本没有 If-None-Match —— 条件 GET 形同虚设，每次都全量重下整个索引。
method get-text-conditional(Str $url, Str :$if-none-match = ''
                            --> RakuPM::HTTP::ConditionalResponse) {
    my %opt = self!attrs;
    my $client = HTTP::Tinyish.new(|%opt);
    my %r = $if-none-match.chars
        ?? $client.get($url, headers => %( 'If-None-Match' => $if-none-match ))
        !! $client.get($url);
    my $status = (%r<status> // 0).Int;
    unless $status == 200 || $status == 304 {
        die "HTTP::Tinyish 条件获取 $url 失败：status=$status";
    }
    my $body = %r<content> // '';
    $body = $body ~~ Blob ?? $body.decode('utf-8') !! $body.Str;
    my Str $etag = '';
    if %r<headers> ~~ Associative {
        for %r<headers>.kv -> $k, $v {
            $etag = $v.Str.trim if $k.lc eq 'etag';
        }
    }
    RakuPM::HTTP::ConditionalResponse.new(:$status, :$body, :$etag)
}
