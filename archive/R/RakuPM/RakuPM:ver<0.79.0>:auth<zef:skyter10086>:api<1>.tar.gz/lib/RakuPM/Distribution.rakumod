# RakuPM::Distribution — 一个「发行版」的数据模型
#
# 对应 zef 里的 META6.json 概念：一个发行版 = 名字 + 版本 + 作者 + 提供的模块 + 依赖。
# 第三方包永远只带 Raku 标准的 META6.json（0.37.0 起不再回退 META.json）；
# raku-pm 自己在 store 内部另写一份 META.json 仅用于反查，两者格式都靠 from-meta-file 解析。

use JSON::Fast;
use RakuPM::Spec;
use RakuPM::Fs;
use RakuPM::Platform;

unit class RakuPM::Distribution;

has Str  $.name;                 # 发行版名字，如 "RakuPM::JSON"
has Str  $.version;              # 语义化版本，如 "1.2.3"
has Str  $.auth;                 # 作者标识，如 "github:someone"
has Str  $.description = '';     # 一句话描述
has      @.provides;             # 这个发行版「提供」哪些模块（模块名列表）
has      %!depends;              # 依赖：模块名 => 版本约束字符串
has      @.native-libs;          # 非 Raku 的本地库依赖（zef 用 :from<native> 标记）
has      @.external-deps;        # 外部命令 / 非 Raku 依赖（zef 用 :from<bin>、:from<Perl5> 标记）
                                 # 典型：Doc::TypeGraph 要 graphviz 的 dot、Documentable 要 node
                                 # 这些不是 Raku 包，装不了也解析不得，只在安装时提示
has      @.git-deps;             # git 仓库形式的依赖 —— URL 本身就是依赖（zef 也认）
                                 # 典型：Draku 依赖 "git://github.com/jkramer/p6-Text-Wrap.git"
                                 # 装法：clone → 读 META6.json → 当普通发行版走完整安装链
has      @.resources;            # 随包分发的资源文件（%?RESOURCES 取的那批）
                                 # 常见用途：native 库放在 resources/libraries/ 下
has Str  $.builder = '';         # META6 "builder" 字段（Distribution::Builder::* 类名）
                                 # 空串 = 没声明（可能走 Legacy Build.pm 路径）
has      %!build-depends;        # build-depends：构建阶段才需要的包（如 MakeFromJSON）
has      %!test-depends;         # test-depends：测试阶段才需要的包（如 Test::META）

# 用构造器把 %depends / @native-libs / @resources 接收进来
submethod BUILD(:$!name!, :$!version!, :$!auth = 'unknown',
                :$!description = '', :@provides = [$!name],
                :%depends = {}, :@!native-libs = (), :@!external-deps = (),
                :@!git-deps = (), :@!resources = (),
                :$!builder = '', :%build-depends = {}, :%test-depends = {}) {
    @!provides    = @provides;
    %!depends     = %depends;
    %!build-depends = %build-depends;
    %!test-depends  = %test-depends;
    # 注意：@!native-libs 与 @!resources 用 :@!xxx 直接绑到属性上，
    # 所以这里不能再写一遍 `@!resources = @resources` —— 没有 @resources 这个变量。
}

# 暴露只读的依赖视图
method depends(--> Hash) { %!depends.clone }

# 构建依赖的只读视图（shape 与 depends 相同：模块名 => 约束串）
method build-depends(--> Hash) { %!build-depends.clone }

# 测试依赖的只读视图（shape 与 depends 相同：模块名 => 约束串）
method test-depends(--> Hash) { %!test-depends.clone }

# 完整身份标识，仿 zef 的 Identity：name:ver:auth
method identity(--> Str) {
    "{$!name}:ver<{$!version}>:auth<{$!auth}>"
}

# 检查这个发行版是否「提供」某个模块
method provides-module(Str $mod --> Bool) {
    $mod (elem) @!provides
}

# 从 META 文件解析出一个 Distribution
# 同时支持两种格式：
#   1. 我们的 META.json（provides=Array，depends=平铺 Hash）
#   2. Raku 标准的 META6.json（provides=Hash{name=>path}，depends={runtime:{requires:[...]}}）
method from-meta-file(IO::Path $path --> RakuPM::Distribution) {
    my $parsed = try from-json($path.slurp);
    # from-json 在损坏输入上返回未定义的 Any（而非抛异常），两种都算解析失败；
    # 兜住并给出清晰报错（含文件名），而不是把底层 "Malformed JSON" 栈甩给用户。
    ($parsed ~~ Failure || ! $parsed.defined)
        and die "META 文件 {$path} 不是有效的 JSON（顶层应为对象，却得到 {$parsed.^name}）";
    # 防御：META 文件顶层必须是 JSON 对象（Hash/Map）。某些场景下会传进一个
    # JSON 数组——典型如本地仓库根目录里有个把整个生态索引 dump 进去的
    # META.json——直接 my %meta = $parsed 会把数组当 hash initializer，触发
    # "Odd number of elements found where hash initializer expected" 并刷屏成千上万条
    # "Use of uninitialized value element of type Any" 警告。这里改成明确的单条报错，
    # 由调用方（Local 仓库）try 兜住后跳过该文件，而不是拖垮整个安装。
    $parsed ~~ Associative
        or die "META 文件 {$path} 不是有效的发行版元数据：顶层应为 JSON 对象，"
             ~ "却得到 {$parsed.^name}（{$parsed.elems} 个元素）。"
             ~ "确认它不是把生态索引/别的 JSON 数组误当成了 META6.json。";
    my %meta = $parsed;
    # 注意：用普通 scalar 中转再赋值给 Hash/Array，不要直接写
    #   my (%dep, @native) = ...
    # Raku 在「同一声明里混合 Hash 和 Array 解构」时遇到 Array 字面量会把它
    # 当作 hash initializer 的特殊元素，触发 "Odd number of elements"。
    my ($dep-hash, $native-list, $external-list, $git-list) = self!normalize-depends(%meta<depends> // {});
    RakuPM::Distribution.new:
        :name(%meta<name>),
        :version(%meta<version>),
        :auth(self!normalize-auth(%meta<auth>)),
        :description(%meta<description> // ''),
        :provides(self.normalize-provides(%meta<provides>)),
        :depends($dep-hash),
        :native-libs($native-list),
        :external-deps($external-list),
        :git-deps($git-list),
        :resources(self!normalize-resources(%meta<resources>)),
        :builder(%meta<builder> // ''),
        :build-depends(self.build-depends-from(%meta)),
        :test-depends(self.test-depends-from(%meta));
}

# auth 在 META6 规范里是字符串，但生态里确实有包把它写成了数组 ——
# 大多是照抄 authors 的格式（"auth": ["zef:someone"]）。
# 直接把字段塞给 Str 类型的 $.auth 会在构造时炸：
#   Type check failed in assignment to $!auth; expected Str but got Array
# 一个字段的写法偏差不该让整个包解析不出来，所以这里归一成字符串：
#   Str        → 原样（trim）
#   Positional → 取第一个非空元素（数组形态）
#   Hash       → 取第一个非空键
#   缺失/空    → 'unknown'
method !normalize-auth($a --> Str) {
    my $s = do given $a {
        when !.defined  { '' }
        when Str        { $_ }
        when Positional { (.map(*.Str).first({ .chars }) // '') }
        when Hash       { (.keys.first({ .chars }) // '') }
        default         { .Str }
    };
    ($s.defined && $s.trim.chars) ?? $s.trim !! 'unknown'
}

# resources 在 META6.json 里多数是数组（["data.txt", "libraries/libfoo.so"]），
# 也有写成 Hash 的（{"libraries/libfoo.so": "..."}）。两种都要认：
# 数组直接取元素，Hash 取键 —— 我们要的只是「有哪些资源」这个清单。
method !normalize-resources($r --> List) {
    return () unless $r.defined;
    return $r.keys.sort.List       if $r ~~ Hash;
    return $r.map(*.Str).sort.List if $r ~~ Positional;
    ()                              # 其他形态（字符串、数字）当没有，别让整个解析挂掉
}

# Raku 标准的 META6.json 用同一解析逻辑（顶层字段名一致，只是子结构不同）
method from-meta6-file(IO::Path $path --> RakuPM::Distribution) {
    self.from-meta-file($path);
}

# ============ 单一构造入口（根治「手工挑字段漏传」）============
#
# 【为什么这两个方法必须存在】
# Distribution 的字段会随能力演进不断增加（resources → git-deps → builder →
# build-depends → test-depends → native-libs …）。而此前有 3 处代码在「手工挑
# 字段重建 Distribution」：Ecosystem.fetch-distribution 与 Git.!distribution-from-git
# 的两个分支。每加一个新字段，那 3 处就各漏一次 —— 这已经是本项目最高产的
# 缺陷模式，实际造成的故障：
#   · 漏 resources     → %?RESOURCES 取不到 → 资源对象回退成 resources 目录 → .open 即崩
#   · 漏 git-deps      → 裸 git URL 依赖在链上消失（Draku）
#   · 漏 builder       → 构建阶段被整个跳过 → native 库根本没编出来（GDBM；
#                        360.zef.pm 索引里 120 个包同时受影响）
#   · 漏 build-depends → 构建依赖不装 → builder 类 use 不到
#   · 漏 test-depends  → 测试依赖不装 → use Test::META 崩
# 结论：**派生/重建必须只经由下面两个入口**，它们对着属性清单写全，新增字段
# 只需改这一处（t/distribution-fields.t 会盯着它）。

# 派生一份改了若干字段的副本（不传就是等价拷贝）。
# 用法：$dist.clone-with(:version("0.0.0-abc1234"), :auth("git:host"))
method clone-with(*%over --> RakuPM::Distribution) {
    my %h =
        'name'          => $!name,
        'version'       => $!version,
        'auth'          => $!auth,
        'description'   => $!description,
        'provides'      => @!provides.List,
        'depends'       => %!depends.clone,
        'native-libs'   => @!native-libs.List,
        'external-deps' => @!external-deps.List,
        'git-deps'      => @!git-deps.List,
        'resources'     => @!resources.List,
        'builder'       => $!builder,
        'build-depends' => %!build-depends.clone,
        'test-depends'  => %!test-depends.clone,
    ;
    for %over.kv -> $k, $v { %h{$k} = $v }
    RakuPM::Distribution.new(|%h)
}

# 从【生态索引行】（外部 JSON 数据）构造 Distribution。
# 归一逻辑（provides/resources 可能是 Hash 或 Array、depends 有 5+ 种写法、
# auth 可能写在 dist 串里）必须集中在这里，而不是散在各仓库各自手挑。
method from-index-row(%row --> RakuPM::Distribution) {
    my ($dep-hash, $native-libs, $external-deps, $git-deps) =
        self!normalize-depends(%row<depends> // {});
    RakuPM::Distribution.new:
        :name(%row<name>),
        :version(%row<version>),
        :auth(self.auth-of-row(%row)),
        :description(%row<description> // ''),
        :provides(self.normalize-provides(%row<provides>)),
        :depends($dep-hash),
        :native-libs($native-libs),
        :external-deps($external-deps),
        :git-deps($git-deps),
        # resources 不能省：它决定入库时 store 的 META6.json 能不能声明资源。
        # 少了它，CUR::Installation 不知道这个包带了资源，%?RESOURCES<key> 取不到
        # → 资源对象回退成 resources 目录 → 模块一 .open 就崩（Data::Generators）。
        :resources(self!normalize-resources(%row<resources>)),
        # builder 不能省：少了它 needs-build 恒假 → 构建阶段被整个跳过 →
        # native 库（resources/libraries/*.so）根本没被编出来（GDBM）。
        :builder(%row<builder> // ''),
        # build-depends / test-depends 不能省：前者决定构建前要不要先装 builder 类，
        # 后者决定跑测试前要不要先装 test-depends 里的包（use Test::META 之类）。
        :build-depends(self.build-depends-from(%row)),
        :test-depends(self.test-depends-from(%row));
}

# 索引行里的 auth：顶层 auth 优先；REA 等索引把身份写在 dist 串里
# （"ADT:ver<0.5>:auth<github:timo>"），此时从串里取。
# 取不到才给 'unknown'（与 from-meta-file 的 !normalize-auth 同语义）。
# 【公开】索引行的 auth 解析是「索引数据 → 发行版身份」的知识，与 provides/
# depends 的归一同类，归属这个类；Ecosystem.search-rows 展示 auth 也要用它。
method auth-of-row(%row --> Str) {
    my $a = %row<auth>;
    return $a if $a.defined && $a.chars;

    my $d = (%row<dist> // '').Str;
    my $i = $d.index(':auth<');
    return 'unknown' unless $i.defined;
    my $s = $i + 6;                       # ':auth<' 的长度
    my $e = $d.index('>', $s);
    return 'unknown' unless $e.defined;
    $d.substr($s, $e - $s)
}

# 【公开】按「阶段」从 META 哈希（生态索引行，或 META6.json 的解析结果）归一依赖。
# $phase 为 'build' 时等价于旧 build-depends-from，'test' 时等价于 test-depends-from；
# build/test 共用一份逻辑，避免 0.35.0 初版「复制两份归一函数」造成的漂移纠缠。
# 生态里每种写法都存在，必须都认：
#   1) 顶层 "<phase>-depends": ["Foo"] 或 {"Foo" => "0.1+"}
#   2) META6 分阶段写法 "depends": { "<phase>": { "requires": [...] } }
#      —— GDBM 0.1.4 的 builder 写在 depends.build.requires；Test::META 之类写在
#         depends.test.requires。只写顶层 "<phase>-depends" 的话，分阶段同相依赖
#         会恒为空 → 构建/测试前不会去装它们 → require 不到而失败。
# 索引行还把 "<phase>-depends" 显式写成【空数组】，所以「定义了但为空」也
# 要继续回退到 depends.<phase>，不能就此收手。
# 统一在这里归一，避免 Ecosystem / from-meta-file 各写一遍各漏一半。
method phase-depends-from(%meta, Str $phase --> Hash) {
    my $top = %meta{ $phase ~ '-depends' };
    my $empty = !$top.defined
             || ($top ~~ Positional && !$top.elems)
             || ($top ~~ Hash       && !$top.elems);
    # depends 也可能是【数组】（"depends": ["Foo","Bar"] 这种平铺写法很常见），
    # 直接 %meta<depends>{$phase} 会对 Array 做关联索引 →
    # "Type Array does not support associative indexing"（0.31.8 实测刷屏警告）。
    # 所以先确认它是 Hash 再取 <$phase>。
    my $dep = %meta<depends>;
    $top = $dep if $empty && ($dep ~~ Hash) && ($dep{$phase} ~~ Hash);
    return {} unless $top.defined;

    my $v = $top;
    $v = ($top{$phase}<requires> // []) if $top ~~ Hash && $top{$phase} ~~ Hash;
    self.normalize-dependencies($v)
}

# build-depends 归一（见 phase-depends-from；GDBM 的 builder 走 depends.build.requires 回退）。
method build-depends-from(%meta --> Hash) { self.phase-depends-from(%meta, 'build') }

# test-depends 归一（见 phase-depends-from；Test::META 之类走 depends.test.requires 回退）。
method test-depends-from(%meta --> Hash) { self.phase-depends-from(%meta, 'test') }

# build-depends（构建阶段依赖）归一化。真实生态的写法：
#   - 数组（主流）：["Distribution::Builder::MakeFromJSON:ver<...>"]
#   - 平铺 Hash：  { "LibraryMake" => "0.1+" }
#   - 分阶段 Hash：{ build => { requires => [...] } }（与 depends 的 phases 同构，
#     但这里取的是 build 相而不是 runtime 相）
# 复用 !normalize-depends 做元素级解析（含 :from<native> 剔除），只是先展开外层。
method !normalize-build-depends($d --> Hash) {
    return {} unless $d.defined;
    my $v = $d;
    if $d ~~ Hash && ($d<build> ~~ Hash || $d<runtime> ~~ Hash) {
        # 分阶段结构：build 相优先，没有就退回 runtime 相
        my $phase = $d<build> ~~ Hash ?? $d<build> !! $d<runtime>;
        $v = $phase<requires> // [];
    }
    self!normalize-depends($v)[0]
}

# provides 在两种格式里分别是 Array 与 Hash{name=>path}。
#
# 【公开】与 normalize-dependencies 同性质：给「原始 META6 的 provides 字段」，
# 归一化成模块名清单。from-meta-file 用它；生产侧（RakuPM::Author.refresh）
# 也要用它来对比「声明里有什么 vs 磁盘上有什么」，所以不能再是 private。
method normalize-provides($p --> List) {
    return () unless $p.defined;
    return $p.keys.List if $p ~~ Hash;
    return @$p.List    if $p ~~ Positional;
    ()
}

# depends 在真实生态里形态多样，统一归一化成 {模块名 => 约束字符串}：
#   - 平铺 Hash：        { "Foo::Bar" => "1.0" }
#   - META6 结构：       { runtime => { requires => [...] }, build => {...}, test => {...} }
#   - 纯数组：           [ "MIME::Base64", "Foo::Bar:ver<1.0+>:auth<zef:x>" ]
#   - 数组内 Hash 元素：  [ { :name<X>, :ver<1.0>, :auth<...> } ]
#   - 平台条件依赖：      [ { "name" => { "by-distro.name" => { "mswin32" => "X" } } } ]
#                        （见 !collect-by-distro，按当前发行版挑，挑不到就是没有依赖）
#   - 裸 git URL：       [ "git://github.com/jkramer/p6-Text-Wrap.git" ]
#                        URL 本身就是依赖（zef 也认），装法只能是 clone 后当
#                        普通发行版装 —— 收集到 git-deps，不进模块依赖表。
# 约束字符串支持 "1.0" / ">=1.0" / "0.2+"（at-least）等写法。
# 返回 (raku-deps-hash, native-libs-list, external-deps-list, git-url-list)：
#   · :from<native> 这类 phaser 表示「需要本地库，不是 Raku 包」，
#     我们不替用户装（也无能为力），只收集到 native-libs 列表里在安装时提示；
#   · :from<bin> / :from<Perl5> 表示「需要外部命令 / 别的语言运行时」
#     （如 Doc::TypeGraph 要 graphviz 的 dot），同样收集起来只提示，不能当成
#     Raku 模块去查仓库（否则会报“找不到模块 'dot'”）；
#   · 裸 git URL（git:// / git@ / https://…/.git 等）收集到 git-url-list，
#     由安装链 clone 后安装 —— 也不能当成模块名去仓库里找；
#   · 其他 phaser（:build<cake>、:api<>、:test<> 等）属于配置信息，
#     直接忽略（不影响名字与版本解析）。
method !normalize-depends($d --> List) {
    return ({}, [], [], []) unless $d.defined;

    my @reqs;
    my @native;                     # :from<native>   —— 本地库
    my @external;                   # :from<bin>/<Perl5> —— 外部命令 / 别的语言
    my @git;                        # 裸 git URL —— 依赖本身就是仓库地址
    if $d ~~ Hash {
        # 平台条件依赖写在顶层：{ "by-distro.name" => { "mswin32" => "X" } }
        my %dspec;
        return (%dspec, @native, @external, @git) if self!collect-by-distro($d, %dspec, @external);

        # META6 分阶段依赖：安装时只关心 runtime.requires（构建/测试依赖留给测试阶段）。
        if $d<runtime> ~~ Hash {
            @reqs.append: |@($d<runtime><requires> // []);
        }
        # 若不是分阶段结构，则当作「平铺 Hash：模块 => 约束」
        if @reqs.elems == 0 {
            my %h;
            for $d.kv -> $k, $v {
                next if $k eq 'runtime' | 'build' | 'test';
                # 极端形态：git URL 直接当键（值是约束），同数组形态一样收集
                if self!is-git-url($k) { @git.push: $k; next }
                %h{$k} = self!constraint-from($v);
            }
            return (%h, @native, @external, @git) if %h.elems || @git.elems;
        }
    }
    elsif $d ~~ Positional {
        @reqs = @$d;
    }
    else {
        @reqs = [$d.Str];
    }

    my %h;
    for @reqs -> $req {
        if $req ~~ Hash {
            my $raw = $req<name> // $req<module>;
            # name 字段本身又是一层平台条件结构（File::Which 1.0.4 就是这个形态）
            if $raw ~~ Hash {
                self!collect-by-distro($raw, %h, @external);
                next;
            }
            next if self!collect-by-distro($req, %h, @external);

            # {"any": [...]} 多选一（zef 语法）：取第一个 Raku 备选，
            # 外部命令 / 本地库类的备选只记不装。生态里目前只出现在
            # App::Ebread 上（elinks/links/lynx 任选一个浏览器）。
            if $req<any> ~~ Positional {
                for @($req<any>) -> $alt {
                    my $s = ($alt ~~ Hash ?? ($alt<name> // '') !! $alt).Str.trim;
                    next unless $s.chars;
                    my ($an, $ac, $ak) = self!parse-req-str($s);
                    next if $ak eq 'native';
                    if $ak eq 'bin' || $ak eq 'external' { @external.push: $an; next }
                    %h{$an} = $ac;
                    last;
                }
                next;
            }

            my $n = $raw // next;
            # name 字段直接写了 git URL 的形态（{ name => "https://…/x.git" }）
            if self!is-git-url($n.Str) { @git.push: $n.Str; next }
            given self!dep-kind($req<from> // '') {
                when 'native'   { @native.push: $n.Str }
                when 'bin'      { @external.push: $n.Str }
                when 'external' { @external.push: $n.Str }
                default {
                    %h{$n.Str} = self!constraint-from($req<ver> // $req<version> // '*');
                }
            }
        }
        else {
            my $s = $req.Str.trim;
            # git URL 不能当模块名解析（否则报「找不到模块 'git://…'」），
            # 也不该进依赖表 —— clone 后当普通发行版装（见 !is-git-url）
            if self!is-git-url($s) { @git.push: $s; next }
            my ($n, $c, $kind) = self!parse-req-str($s);
            if $kind eq 'native' {
                @native.push: $n;
            }
            elsif $kind eq 'bin' || $kind eq 'external' {
                @external.push: $n;
            }
            else {
                %h{$n} = $c;
            }
        }
    }
    (%h, @native, @external, @git)
}

# 判断一个依赖串是不是「裸 git URL」—— URL 本身就是依赖（zef 也认这种写法）。
# 真实样本：Draku 的 META6.json 里直接写了
#   "git://github.com/jkramer/p6-Text-Wrap.git"
# 它没法进仓库按名字解析，装法只能是 clone → 读 META6.json → 当普通发行版装。
# 识别范围（模块名绝不会长这样，可放心判定）：
#   git://…       老式 git 协议（draku 那个样本就是）
#   git@…         SSH 简写（git@github.com:user/repo.git）
#   https://…/.git 带 .git 结尾的 https 仓库（GitHub/Gitee 克隆地址最常见）
method !is-git-url(Str $s --> Bool) {
    my $t = $s.trim;
    return False unless $t.chars;
    return True if $t ~~ /^ 'git://' /;
    return True if $t ~~ /^ 'git@' /;
    # 注意 s? 的量词要写在引号外面（'https?://' 会匹配字面问号，永远不中）
    # http(s) 只有带 .git 结尾才算仓库（否则可能是别的协议，宁可不猜）
    return True if $t ~~ /^ 'http' 's'? '://' / && $t ~~ /'.git' $/;
    False
}

# 平台条件依赖（zef 的 META6 扩展，不在核心规范里但生态普遍使用）：
#
#   "depends": [ { "name": { "by-distro.name": { "": "", "mswin32": "Win32::Registry" } } } ]
#
# 含义：按当前 $*DISTRO.name（mswin32 / ubuntu / macos …）挑依赖，键 "" 是兜底
# （其它平台的取值）—— 也就是「Windows 专有依赖」。同理还有 by-kernel.name。
#
# 真实样本：File::Which 1.0.4（REA 与 cpan 索引里都是这个形态），它只在 Windows
# 上需要 Win32::Registry。以前我们不认这个语法，直接把整个 Hash 当模块名塞进依赖
# 表，Hash 字符串化后变成 "by-distro.name\nmswin32\tWin32::Registry"，于是
# Linux/WSL 上也会去解析这个根本不存在的模块：
#   raku-pm install Digest::SHA1::Native
#   → 在所有已配置的仓库里都找不到模块 'by-distro.name
#     mswin32 Win32::Registry'
#
# 取值：优先当前平台键，其次 '*'，最后 '' 兜底；取不到（也没有兜底）就等于
# 【没有这条依赖】—— 平台条件依赖本来就是「别的平台不用装」，不能反过来
# 把所有分支的依赖都装上（那样 Linux 上会去装 Win32::Registry，必失败）。
# 返回值：是否命中了这个语法（没命中就交给常规解析，保持原行为）。
method !collect-by-distro(Hash $spec, %h, @external --> Bool) {
    my $hit = False;
    # 平台名走 RakuPM::Platform（唯一读 $*DISTRO/$*KERNEL 的地方，可被测试遮蔽）。
    my @keys = ('by-distro.name', distro-name()), ('by-kernel.name', kernel-name());
    for @keys -> $pair {
        my $key = $pair[0];
        my $cur = $pair[1].Str;
        my $m = $spec{$key} // next;
        next unless $m ~~ Hash;
        $hit = True;
        my $pick = $m{$cur}:exists ?? $m{$cur}
                !! ($m{'*'}:exists  ?? $m{'*'}
                !! ($m{''}:exists   ?? $m{''} !! Nil));
        next unless $pick.defined;
        for flat($pick) -> $dep {
            my $s = ($dep ~~ Hash ?? ($dep<name> // '') !! $dep).Str.trim;
            next unless $s.chars;
            my ($n, $c, $kind) = self!parse-req-str($s);
            next if $kind eq 'native';      # 本地库：由 !normalize-depends 的调用方提示
            if $kind eq 'bin' || $kind eq 'external' { @external.push: $n; next }
            %h{$n} = $c;
        }
    }
    $hit
}

# :from<...> 是 zef 用来标记「这个依赖不是普通 Raku 包」的 phaser，
# 可以写在依赖串里（Module:from<native>），也可以写在独立的 from 字段里。
# 生态里实际出现的只有三种取值（扫 REA + cpan 索引确认）：
#   native → 本地库（libfoo.so），不装，只提示
#   bin    → 外部命令（graphviz 的 dot、node…），不装，只提示
#   Perl5  → Perl 5 模块，装不了
# 返回 'native' / 'bin' / 'external' / ''（'' = 普通 Raku 包）。
method !dep-kind($from --> Str) {
    my $v = ($from // '').Str.trim;
    return '' unless $v.chars;
    $v = $0.Str if $v ~~ / 'from<' (<-[>]>+) '>' /;
    $v .= subst(/^ ':' /, '');
    given $v.lc {
        when 'native' { 'native' }
        when 'bin'    { 'bin' }
        when 'perl5'  { 'external' }
        default       { '' }
    }
}

# 把约束值归一成字符串（处理 * / Str / {ver,auth} Hash 三种形态）
method !constraint-from($v --> Str) {
    return '*' unless $v.defined;
    return '*' if $v eq '*' || $v eq '';
    return $v.Str if $v ~~ Str;
    if $v ~~ Hash {
        return ($v<ver> // '*').Str;
    }
    $v.Str
}

# 解析 zef 风格的**安装规格串**，是 identity() 的逆操作：
#
#   Foo::Bar / Foo::Bar:ver<1.2.3> / Foo::Bar:ver<1.2.3+> / Foo::Bar@1.2.3 /
#   Foo::Bar:ver<1.2.3>:auth<zef:x>:api<1>
#
# 逻辑已抽到独立的 RakuPM::Spec（search / installed / store 等查询命令
# 也要认这套写法，而它们不该为了解析规格串把 Distribution 拖起来）。
# 这里保留同签名的方法作为委托，老调用方（含 bin 的 require 表达式用法）不受影响。
method parse-spec(Str $spec --> Hash) {
    RakuPM::Spec.parse($spec)
}

# 从 "Foo::Bar:ver<1.0+>:auth<zef:x>" 这类 require 字符串里
# 解析出 (name, ver, kind)。kind 是 'raku'（默认）或 'native'。
# 用逐字符扫描而非正则回溯，避免 Raku 正则对「较早冒号失败后再回溯到更后的冒号」
# 的已知怪异行为。
# 识别这些 phaser：
#   :ver<x>     版本约束
#   :auth<x>    作者标识
#   :from<...>  「提供方式」，from<native> 表示「非 Raku，是本地系统库」（最关键）
#   :api<x>     API 版本（配置）
#   :build<...> 构建器（配置）
#   :test<...>  测试器（配置）
#   :repo<...>  仓库源（配置）
# 出现 :from<native> 时把这条依赖标记为 native，名字仍然取。
method !parse-req-str(Str $s --> List) {
    my $ver  = '*';
    my $name = $s;
    my $kind = 'raku';
    my $name-set = False;   # 名字只在第一个「真正 phaser」冒号处取一次（:: 双冒号不算）
    my $i = 0;
    while $i < $s.chars {
        if $s.substr($i, 1) eq ':' {
            my $p = $i + 1;
            my $word = '';
            while $p < $s.chars && $s.substr($p, 1) ~~ /<alnum>/ {
                $word ~= $s.substr($p, 1);
                $p++;
            }
            if $word.chars && $p < $s.chars
               && ($s.substr($p, 1) eq '<' || $s.substr($p, 1) eq '(') {
                # 名字取「第一个真正 phaser 冒号之前」的部分，且只取一次：
                # 模块名里的 :: 双冒号不是 phaser 起符，不能在这里被截断；
                # 多 phaser 串（Foo:ver<1.0>:from<native>）后续冒号也不能覆盖名字。
                $name = $s.substr(0, $i) unless $name-set;
                $name-set = True;
                my $open  = $s.substr($p, 1);
                my $close = $open eq '<' ?? '>' !! ')';
                # 闭合括号定位统一走 RakuPM::Spec.close-bracket-index：裸 index('>')
                # 会把「大于」运算符 `>=` / `>` 自带的 `>` 当闭合，把约束截成空串
                # （`Foo:ver<>=1.0>` 静默退化成"任意版本"）。查询侧 Spec.parse 同一份。
                my $e = RakuPM::Spec.close-bracket-index($s, $p, $close);
                # 闭合括号缺失 → 依赖串畸形，无法继续解析，到此收尾
                last unless $e.defined;
                my $val = $s.substr($p + 1, $e - $p - 1);
                if $word eq 'ver' {
                    $ver = $val;
                }
                elsif $word eq 'from' {
                    # 读 from<...>：native / bin / Perl5 都不是 Raku 包，
                    # 决定这条依赖的类型，必须在扫描后续 phaser 前设好。
                    $kind = self!dep-kind($val) if $val.chars;
                }
                # 关键：不能 last！否则 :ver<...>:from<native> 后续的 :from
                # 会被丢掉，把本地库依赖误判成 Raku 模块（去仓库找一个不存在的
                # 包，装错/装崩）。auth/api/build/test/repo 只用于身份/展示，
                # 提取后跳到闭合括号之后继续往下扫下一个 phaser。
                $i = $e + 1;
                next;
            }
        }
        $i++;
    }
    ($name.trim, $ver, $kind)
}

# 公开封装：供 RakuPM::Repository::Ecosystem 等外部在「不落地 META 文件」
# 的情况下，直接把生态索引里的 depends 字段归一化成标准 Hash。
# 只返回 raku 依赖（隐藏 native-libs 的存在）；如果调用方需要原生库列表，
# 用 normalize-dependencies-and-native-libs。
method normalize-dependencies($d --> Hash) {
    return self!normalize-depends($d)[0]
}

# 同时返回 raku 依赖、本地库列表与 git URL 依赖。
# Ecosystem 等生产代码应使用此方法（返回 4 元组；只需要模块依赖时
# 取 [0] 即可，多余元素在列表解构中被自然忽略）。
method normalize-dependencies-and-native-libs($d --> List) {
    self!normalize-depends($d)
}

# 序列化成 META.json 内容
method to-meta-json(--> Str) {
    to-json({
        name        => $!name,
        version     => $!version,
        auth        => $!auth,
        description => $!description,
        provides    => @!provides,
        depends     => %!depends,
    }, :sorted-keys);
}

# ============ 「发行版 ↔ 磁盘上的 lib/」两个方向 ============
#
# 为什么放在 Distribution 而不是 Store：这是「发行版 ↔ 文件」的知识，与
# from-meta-file / from-meta6-file（读盘）和 to-meta-json（写盘）同类——
# Distribution 本来就不是纯数据模型。而且它有两个消费方：
#   · 消费侧：Store 入库时写标准 META6.json 要用（provides 要「模块名=>路径」）
#   · 生产侧：将来的 refresh / check / dist 要用（重生成 META6.json）
# 单一实现处，避免两边各抄一份再漂移（同 Repository::Matching 的理由）。

# 模块名 -> META6 provides 需要的「发行版根相对路径」，如 Foo::Bar → lib/Foo/Bar.rakumod。
# 两种扩展名都认（.rakumod 与 .pm6；老包用 .pm6）。找不到的模块直接跳过——
# provides 里写了但文件不存在，写进 META6.json 只会让 CUR::Installation 装不上。
#
# 注意：.rakudoc 是 RakuDoc 文档文件，不是可加载模块，绝不能算进 provides——
# 否则 Rakudo 的模块加载器会去"加载"一个文档文件而失败。所以扩展名列表里没有它。
method provides-with-paths(IO::Path $root, @modules --> Hash) {
    my $lib = $root.add('lib');
    my %h;
    for @modules.unique -> $mod {
        my @parts = $mod.split('::');
        for '.rakumod', '.pm6' -> $ext {
            my @seg  = 'lib', |@parts[0..*-2], @parts[*-1] ~ $ext;
            my $rel  = @seg.join('/');           # 统一正斜杠：Windows 的 \ 会让 Distribution::Path 拼错路径
            if $lib.add(@seg[1..*].join('/')).e {
                %h{$mod} = $rel;
                last;
            }
        }
    }
    %h
}

# 反方向：扫 root/lib 下的模块源文件 —— 反推模块名列表（provides 的候选全集）。
#
# 与 provides-with-paths 互为反向：那边是「给模块名找路径」，这边是「看磁盘上有什么」。
# 作者侧 refresh / new / check 需要它（等价于 mi6 的 AutoScanPackages）：
# 把 lib/ 当真相，重生成 META6.json 的 provides。
#
# 只看 .rakumod / .pm6（.rakudoc 是文档不是模块）；跳过任何以 `.` 开头的路径段
# （典型 .precomp —— 那是 Rakudo 加载时生成的派生字节码，不是源码）。
method scan-provides(IO::Path $root --> List) {
    my $lib = $root.add('lib');
    return () unless $lib.d;
    my %seen;
    for self!walk-source-files($lib) -> $f {
        my @seg = $f.relative($lib).Str.subst('\\', '/', :g).split('/').grep(*.chars);
        next unless @seg.elems;
        my $leaf = @seg.pop;
        $leaf = $leaf.subst(/'.' \w+ $/, '');    # 去掉扩展名（/'.'/ 是字面点号）
        next unless $leaf.chars;
        @seg.push($leaf);
        %seen{@seg.join('::')} = True;
    }
    %seen.keys.sort.List
}

# 递归收集目录下的模块源文件，跳过以 `.` 开头的路径段。
#
# 遍历走 RakuPM::Fs.walk-files（急切收集目录句柄 + 按绝对路径稳定排序），
# 再做两层过滤，语义与旧实现一致：
#   1) 丢弃【任何路径段】以 `.` 开头的文件 —— Fs 已按默认规则跳过
#      .precomp/.git/.hg/.svn/blib 这些目录，这里再逐段确认，
#      保持「点开头的路径段一律不算模块源」；
#   2) 只保留 .rakumod / .pm6 —— .rakudoc 是文档不是可加载模块，绝不能算进
#      provides，否则 Rakudo 的加载器会去「加载」一个文档文件而失败。
method !walk-source-files(IO::Path $dir --> List) {
    # 从文件往上逐级看 basename，直到 root（root 自己不计）。
    sub has-dot-segment(IO::Path $p, IO::Path $root --> Bool) {
        my $root-abs = $root.absolute.Str;
        my $cur = $p;
        loop {
            last if $cur.absolute.Str eq $root-abs;   # 到 root 即停
            return True if $cur.basename.starts-with('.');
            my $up = $cur.parent;
            last if $up eq $cur;                      # 已到文件系统根
            $cur = $up;
        }
        False
    }
    # 注意：块里不能用 `return`（在 Raku 里会从外层方法返回），写成表达式。
    walk-files($dir).grep(-> $f {
        my $b = $f.basename.lc;
        !has-dot-segment($f, $dir)
            && ($b.ends-with('.rakumod') || $b.ends-with('.pm6'))
    }).List
}
