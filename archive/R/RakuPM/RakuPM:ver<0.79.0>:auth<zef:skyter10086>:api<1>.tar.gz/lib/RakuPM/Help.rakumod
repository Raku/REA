# RakuPM::Help — help 文本的结构化数据与【分级】渲染
#
# 【为什么从 bin 抽出来】
# 原先 help 正文是一段 ~358 行的 q:to heredoc 躺在 bin/raku-pm.raku 里。两个后果：
#   ① bin 脚本 raku【不做 precomp】，每次调用都要重新编译整份 bin —— 这段 heredoc
#      让 bin 长期 1300+ 行，`raku-pm help` 光编译就要 ~0.8s（实测）。
#      移到本模块后模块可 precomp，bin 也瘦下来。
#   ② heredoc 是无结构的一坨，没法只显示「某个命令」的用法 —— 只能一次全刷出来。
#
# 【分级设计】（0.78.0）
#   默认 `raku-pm help`      → help-summary()  紧凑分组索引（一屏内，含全部命令与别名）
#   `raku-pm help <命令>`    → help-command()  该命令的用法与说明
#   `raku-pm help all`       → help-all()      摘要 + 全部命令详情 + 总览主题（完整手册）
#
# 【命令清单的真源仍是 RakuPM::CliSpec】本模块只提供「描述文本」；命令名、分组、
# 别名一律从 CliSpec 现取并用 command-group() 归类 —— 于是新增命令时索引自动跟上，
# 不会出现「加了命令忘了写 help」。xt/cli-output-stability.t 的完备性断言继续成立。
#
# 【文本不改写为 UI 上色】返回的都是纯文本；上色由 bin 调 RakuPM::UI 的
# ui-colorize-help 完成（非 TTY 原样），故管道 / 测试拿到的仍是纯文本。
unit module RakuPM::Help;

use RakuPM::CliSpec;
use RakuPM::UI;

# ---------------------------------------------------------------------------
# 每个命令的详情（用法 + 说明）。键 = 规范命令名（CliSpec 归一化之后的名字）。
# 别名（i / un / ls …）不在这里登记 —— help-command 会先归一到规范名。
# ---------------------------------------------------------------------------
my %CMD-HELP;
%CMD-HELP<version> = q:to/TXT/;
version
  显示 raku-pm 版本号（含 rakudo / VM 信息）。
version <模块>
  查该模块已装版本与激活版本，可带约束：version 'Foo:ver<1.0>'
TXT

%CMD-HELP<install> = q:to/TXT/;
install <模块> [约束] [--version=X] [--pin=Mod@ver] [--locked]
        [--no-test] [--no-build] [--no-test-deps] [--no-native-check] [--dry]
        [--allow-test-failure] [--test-jobs=N] [--test-timeout=N] [--lock-file=路径]
  安装模块及依赖。默认从已配置的仓库按模块名解析、下载 tar 包、递归解析依赖，
  自底向上【构建 → 跑测试 → 入库 → 装进 site/】。多个索引的候选会合并，取满足
  约束的最高版本。锁默认写到当前目录 raku-pm.lock（可随项目提交）。
install <git-url> [--locked] [--no-test] [--no-build] [--no-test-deps] [--dry] [--allow-test-failure]
  从 git 仓库安装（clone → 读 META6.json → 解析依赖 → 顺序安装，含依赖）。
install <路径> [--locked] [--no-test] [--no-build] [--no-test-deps] [--dry] [--allow-test-failure]
  从本地目录安装（读该目录的 META6.json），如 install .（等价 zef install .）。
  目录里没有 META6.json 会直接报错；本地发行版依赖走同一套递归解析。
  ※ 不能用 RAKUPM_REPO=<发行版根> 替代：本地仓库布局是「一个仓库目录下挂多个发行版
    子目录」，它只扫子目录，而发行版自己的 META6.json 就在根上，扫不到。
  已装过的包（raku-pm 或 zef 装的、版本完全一致）自动跳过；已在 store 的包跳过
  构建与测试。依赖解析失败 / 构建失败 / 测试不通过会中止（可用 --no-build /
  --no-test / --no-test-deps 分别跳过；--allow-test-failure 允许测试失败但继续）。
  终端里跑测试时 stderr 会原地刷「预热 / 测试 i/N 百分比」实时进度；非 TTY（管道 /
  重定向）自动静默，RAKUPM_TEST_PROGRESS=0/1 可关/强制开。
  构建阶段：包里有 Build.pm（约定 class Build 的 build 方法）或 META6 写了 "builder"
  字段（如 Distribution::Builder::MakeFromJSON）时会先执行构建，native 包常用它编译
  C 源生成 resources/libraries/*.so。
TXT

%CMD-HELP<upgrade> = q:to/TXT/;
upgrade [--dry]
  升级所有已装包（不加名 = 全部，同 zef / apt）。
upgrade <模块名> [--version=X] [--only] [--dry]
  升级 / 降级到 X（不加 --version = 最新）。
  ※ upgrade 取【最新版】、不读锁文件（--locked 才会钉死）；要可复现请用 install --locked。
TXT

%CMD-HELP<uninstall> = q:to/TXT/;
uninstall <模块名> [--version=X] [--keep-store] [--recursive] [--force]
  卸载（不给 --version = 卸掉所有版本）。默认连 store 源码快照一起清，不用再 clean；
  --keep-store 才保留快照（供秒级离线重装）。还有包依赖它时会拒绝，--recursive 一并卸、
  --force 强卸。
TXT

%CMD-HELP<reinstall> = q:to/TXT/;
reinstall <模块名> [--version=X] [--dry] [...]
  重装：卸掉再按完全相同版本装回（没装过 = 退化为 install）。--dry 只预览（不卸载）。
TXT

%CMD-HELP<autoremove> = q:to/TXT/;
autoremove [--dry]
  回收不再被依赖的包（当初作为依赖装进来的那些）。
TXT

%CMD-HELP<fetch> = q:to/TXT/;
fetch <模块> [--version=X] [--to=<目录>]
  取源码到指定目录（不安装），用来搭本地仓库。
TXT

%CMD-HELP<look> = q:to/TXT/;
look <模块> [--version=X] [--shell]
  取源码并给出目录路径（--shell 才进交互 shell）。
TXT

%CMD-HELP<depends> = q:to/TXT/;
depends <模块>
  显示完整依赖树（已装 / 待装 / 找不到一眼看清）。
TXT

%CMD-HELP<rdepends> = q:to/TXT/;
rdepends <包或模块名>
  反查谁依赖了它（反向依赖）。
TXT

%CMD-HELP<why> = q:to/TXT/;
why <模块> [<模块> ...] [--pin=Mod@ver]
  诊断依赖解析：为什么解析出这个版本 / 冲突的双方各是什么约束。
TXT

%CMD-HELP<search> = q:to/TXT/;
search <关键词>
  搜索发行版（仓库索引 + 本地已装的包）。关键词可带版本：search 'Foo:ver<1.0+>'
TXT

%CMD-HELP<list> = q:to/TXT/;
list
  列出仓库可安装的包。
TXT

%CMD-HELP<installed> = q:to/TXT/;
installed [模块名]
  列出已安装（多版本全列；给模块名只看它的版本）。模块名可带版本 / 作者：
  installed 'Foo:ver<1.0>'
TXT

%CMD-HELP<info> = q:to/TXT/;
info <包或模块名>
  显示发行版详情（版本 / 描述 / 依赖 / 源码地址，仿 zef info）。
TXT

%CMD-HELP<browse> = q:to/TXT/;
browse <包或模块名>
  在浏览器打开主页 / 源码（仿 zef browse）。
TXT

%CMD-HELP<locate> = q:to/TXT/;
locate <模块名>
  定位模块在磁盘上的真实文件位置（仿 zef locate）。
TXT

%CMD-HELP<outdated> = q:to/TXT/;
outdated
  列出可升级的已装包（当前版本 → 生态最新版；只读）。
TXT

%CMD-HELP<smoke> = q:to/TXT/;
smoke [包或模块名…] [--allow-test-failure] [--test-jobs=N] [--test-timeout=N]
  冒烟测试：取源码并跑测试（不给规格 = 测全部已装，可能很慢）。
TXT

%CMD-HELP<repos> = q:to/TXT/;
repos
  列出已配置的仓库（可配置多个，按优先级从上到下依次查找）。
repos add <别名|URL|本地目录> [--name=名字]
  添加索引或本地目录仓库（给目录 = 本地仓库）。内置别名：
    zef   https://360.zef.pm                     当前版本，约 8k 个发行版
    rea   …/Raku/REA/main/META.json              生态存档，约 15k，含历史版本
    cpan  …/Perl6-ecosystems/master/cpan1.json   CPAN 上的 Perl6 模块
    p6c   …/Perl6-ecosystems/master/p6c1.json    旧生态存档
repos remove <名字|URL|本地目录>
  移除仓库。
repos update [名字|URL]
  刷新索引缓存（不加名 = 全部）。
TXT

%CMD-HELP<update> = q:to/TXT/;
update [仓库名字|URL]
  刷新仓库索引（= repos update；不加名 = 全部）。
TXT

%CMD-HELP<native> = q:to/TXT/;
native <本地库>… [--paths] [--os=…] [--distro=…]
  检查本机有没有某个本地库（同一逻辑名在不同系统上是不同文件：Windows 找
  sqlite3.dll，macOS 找 libsqlite3.dylib，Linux 找 libsqlite3.so）。
  native ssl curl --paths      一次查多个，--paths 顺便打印搜索路径
  native sqlite3 --os=linux --distro=ubuntu
                               不切机器也能查「另一台机器该装什么」
native --installed
  扫锁文件，列出已装发行版声明的全部本地库。
TXT

%CMD-HELP<store> = q:to/TXT/;
store [模块名] [--verify]
  查看本地存储（给模块名只看它，附各版本完整路径）。模块名可带版本：store 'Foo@1.0'
  --verify 才重算内容指纹（默认不校验：很慢）。
TXT

%CMD-HELP<verify> = q:to/TXT/;
verify [--content] [--fix]
  校验：内容完整性 + 安装一致性（账本 / CUR / store / resources 是否对得上）。
TXT

%CMD-HELP<lock> = q:to/TXT/;
lock [--lock-file=路径]
  查看锁文件（默认当前目录的 raku-pm.lock）。
TXT

%CMD-HELP<generations> = q:to/TXT/;
generations
  列出安装世代（每次成功安装留一个，可回滚）。
TXT

%CMD-HELP<rollback> = q:to/TXT/;
rollback [世代号]
  退回上一世代（不给世代号 = 上一个；给 = 指定那个）。
TXT

%CMD-HELP<doctor> = q:to/TXT/;
doctor
  一次性体检：RAKULIB / PATH 顺序 / 残留暂存 / 账本↔CUR 一致性 / rakudo 版本，
  给修复建议。
TXT

%CMD-HELP<env> = q:to/TXT/;
env
  打印 RAKULIB / PATH 该怎么设（含：敲 raku-pm 实际会跑哪一份 wrapper）。
TXT

%CMD-HELP<shell> = q:to/TXT/;
shell [--shell=bash|fish|pwsh|cmd]
  只打印可 eval 的环境赋值，灌进当前 shell：eval "$(raku-pm shell)"
TXT

%CMD-HELP<which> = q:to/TXT/;
which [模块名]
  查「这个包到底从哪加载」：给模块名 = 实际命中的仓库与版本（多份会全列出）；
  不给 = 跨仓库冲突总览（zef 与 raku-pm 装了同名包时用它定位）。
TXT

%CMD-HELP<clean> = q:to/TXT/;
clean [--all] [--yes] [--older-than=N] [--name=模块]
  回收缓存（默认只试算，--yes 才真删）。回收四类：store 里的旧版本快照、入库
  中断的残骸、store 里的 .precomp 预编译产物、cache/dist 下已下载的源码包与
  解压目录。--all 才追加索引缓存（cache/index-*.json）与 git 克隆缓存（git-cache/）
  —— 这两个重建要重新下载 / 克隆，默认留着。
  raku-pm clean                     试算：列出可以回收什么（默认不删任何文件）
  raku-pm clean --yes               确认后真删
  raku-pm clean --all --yes         连索引缓存与 git 克隆缓存一并回收
  raku-pm clean --older-than=30     只回收 30 天没动过的
  raku-pm clean --name=RakuPM       只看某一个发行版
  【安全边界】只删「没有被任何地方引用」的版本。受保护三类：installed.json 账本里
  记的版本、自家 site/ 里真实装着的版本、raku-pm.lock 锁定的版本。site/ 已装内容
  不受影响（跟 store 是两份拷贝），最坏是下次重装时重新下载。
TXT

%CMD-HELP<gc> = q:to/TXT/;
gc [...]
  clean 的别名，参数同 clean。
TXT

%CMD-HELP<flush> = q:to/TXT/;
flush [--yes]
  清空当前前缀（含 raku-pm 自己），回到可重装状态。默认只试算，--yes 才真删。
  clean 是【有保护】的回收；要从零重来用 flush。
  它清掉前缀里 raku-pm 装过的一切（store/ site/ 缓存 日志 世代 账本 锁文件 bin/），
  以及【自装入口】—— 全局 site/bin 下 raku-pm 自己写的那几份 wrapper。
  两道保险：① 目录必须「看起来就是 raku-pm 前缀」（store/ 、site/ 、installed.json
  至少有一个），且不是家目录本身、不是文件系统根，否则拒绝执行（--target 打错时能兜住）；
  ② 只删【认得的】条目名，前缀里别的东西一律不动（会列出来给你看）。
  它不动别的包管理器：zef 装的 RakuPM 不在本前缀内（要清就 zef uninstall RakuPM），
  也不删 <名>.exe.zef-old（那是 zef 入口的唯一备份）—— 都只提示，不动手。
TXT

%CMD-HELP<self-upgrade> = q:to/TXT/;
self-upgrade [--from=<git-url>] [--from-dir=<目录>] [--dry] [--force] [--no-test]
  升级 raku-pm 自身。源码来源：--from <git-url>（默认 gitee 上游）/ --from-dir <目录>
  （直接用本地源码）/ 在 git 仓库里跑则 pull 当前仓库。--force 强制重装；--no-test
  升级时不跑测试。
  升级走【两阶段自举】：先把源码取到 git-cache 并判断是否需要升，再用【取到的新版
  代码】执行安装 —— 这样即便新版改了安装链行为，也不会出现「旧版装不动新版」的
  死循环；自举不可用时回退用当前版本装。默认跳过运行时本地库检查（raku-pm 是纯
  Raku、无 native 依赖，且其文档样例会被旧扫描器误报）。
TXT

%CMD-HELP<self-remove> = q:to/TXT/;
self-remove [--dry]
  卸载 raku-pm 自身（含 store 快照与 bin wrapper）。
TXT

%CMD-HELP<test> = q:to/TXT/;
test [路径] [--allow-test-failure] [--test-jobs=N] [--test-timeout=N]
  只跑测试、不安装（默认路径 = 当前目录）。
TXT

%CMD-HELP<build> = q:to/TXT/;
build [路径]
  只跑构建、不安装（默认路径 = 当前目录）。
TXT

%CMD-HELP<preflight> = q:to/TXT/;
preflight [--filter=子串] [--jobs=N]
  提交前检查（须在 raku-pm 源码仓库里跑）：文档纪律 + 具名实参 + t/ 全绿 才给出
  「可以提交了」；与预提交钩子共用同一份门禁实现。
TXT

%CMD-HELP<completions> = q:to/TXT/;
completions <bash|zsh|fish|pwsh>
  生成对应 shell 的补全脚本（输出到 stdout，source 即可）。
TXT

%CMD-HELP<help> = q:to/TXT/;
help [<命令>|all]
  显示帮助。默认给紧凑命令索引；给命令名看它的用法；all 给完整手册。
TXT

%CMD-HELP<refresh> = q:to/TXT/;
refresh [路径] [--dry]
  以磁盘为准重建 META6.json 的 provides（默认当前目录）：lib/ 下新增 / 改名的模块
  会加入；声明里有、磁盘上没有的会剔除（写了也装不上）；其余字段原样保留。
  --dry 只预览将要发生的改动，不写文件。
TXT

%CMD-HELP<new> = q:to/TXT/;
new <模块名> [--into=目录] [--auth=…] [--version=X] [--with-readme] [--bin=<x>] [--force] [--dry]
  创建新发行版骨架（作者侧起点）：生成 META6.json + lib/<模块>.rakumod +
  t/01-basic.rakutest + Changes + .gitignore；--with-readme 再给 README.md、
  --bin=<x> 给 bin/<x>.raku。目录名默认 模块名 ::→-（--into= 显式指定；. = 当前目录）。
  auth 默认 RAKUPM_AUTHOR_AUTH 或 zef:skyter10086、version 0.1.0。
TXT

%CMD-HELP<check> = q:to/TXT/;
check [路径] [--remote]
  发布前预检（上架前安全闸门，默认当前目录）：校验 META6 合法、name 合法模块名、
  version≠*、auth 与 RAKUPM_AUTHOR_AUTH 一致、provides 与磁盘 lib/ 一致、bin 文件
  存在、license/description/authors 齐全；任何硬错误都以非零退出。加 --remote 再
  联网查同版本是否已发布（同版本不可重传；离线或查不到只告警、不阻断）。
TXT

%CMD-HELP<dist> = q:to/TXT/;
dist [路径] [--to=目录] [--no-build] [--dry]
  打包 sdist（发布前必需，默认当前目录）：先跑 check 门禁（有硬错误直接拒），再可选
  跑 Build.pm 构建阶段（--no-build 跳过），最后打成 <name>-<version>.tar.gz 源分发
  （排除 .git/blib/.precomp 与 . 开头的隐藏项；自动排除自身；发行版根有 .distignore
  则再按其清单排除）。是 publish 的输入物。
TXT

%CMD-HELP<bump> = q:to/TXT/;
bump [路径] [--to=X.Y.Z | --major | --minor] [--date=YYYY-MM-DD] [--dry] [--no-sync-docs]
  版本编排：一次做完「递增版本」的三件事 —— 按 semver 递增 META6 version（默认
  --patch，或 --minor/--major/--to= 精确指定）、Changes 顶部加 ## X.Y.Z - DATE
  版本头、把文档里的 <name>:ver<旧> 示例同步为新版（--no-sync-docs 关掉，发布第三方
  包时用）；位置参数像版本号时当 --to，否则当目录。
TXT

%CMD-HELP<publish> = q:to/TXT/;
publish [路径] [--to=<repo-dir>] [--from=<tar.gz>] [--no-build] [--force] [--dry] [--remote] [--quiet]
  部署到本地目录仓库（fez publish 的本地 / 教学等价物）：把 sdist 解包进 --to 指定的
  目录仓库（或 RAKUPM_PUBLISH_REPO），使其立即可被 raku-pm install 解析。默认先跑
  check + 打包（--from 复用现成包）；同版本目录已存在会被拦（先 bump，或 --force 覆盖）。
  --remote 走真实生态上传（multipart PUT 到 42.zef.pm/upload，需先 login 或设
  RAKUPM_API_KEY），--dry 只预览不发网。落点 <repo>/<name>-<version>/（仅不带
  --remote 时生效，--remote 只上传）。
TXT

%CMD-HELP<login> = q:to/TXT/;
login [--api-key=<key>] [--username=<u> --password=<p>]
  生产侧凭据管理：把生态 api-key 存到 ~/.raku-pm/credentials.json（仅属主可读），
  供 publish --remote 自动读取。--api-key 直接导入一把已有 key（与 fez 共用同一把）；
  --username/--password 真实联网登录 42.zef.pm/login 换 key（密码不落盘）。也可不设
  凭据、直接 RAKUPM_API_KEY 环境变量读取。
TXT

%CMD-HELP<logout> = q:to/TXT/;
logout
  注销：删除本地凭据文件（与 login 配对）。本来就没凭据文件时只提示「没有已登录的
  会话」，不报错。
TXT

# ---------------------------------------------------------------------------
# 总览主题：不属于单个命令的说明性章节（锁文件 / 并发 / 环境变量 …）。
# help-all 会按这里的顺序追加在命令详情之后。
# ---------------------------------------------------------------------------
my @TOPICS;
@TOPICS.push: q:to/TXT/;
离线模式（--offline，对所有会联网的命令都生效）：
  --offline
      等价于环境变量 RAKUPM_OFFLINE=1：本轮不联网，只用本地缓存 / 已装内容 /
      本地目录仓库。索引与 git 缓存有就复用（可能不是最新），没有就明确报错 ——
      绝不会静默改成联网。用途：网络受限环境、CI 要确定性、离线复现。
      看当前状态：raku-pm env
TXT

@TOPICS.push: q:to/TXT/;
输出样式（--no-color，对所有命令都生效）：
  --no-color
      关闭彩色与表格，回到纯文本输出。非 TTY（管道 / 重定向 / 测试捕获）时本就
      自动降级为纯文本；也可用 NO_COLOR 环境变量（业界惯例）。installed / list /
      info 已用表格 + 色彩展示。
TXT

@TOPICS.push: q:to/TXT/;
装完之后：
  包在 <前缀>/site/ 里，要让 raku 找得到必须设 RAKULIB；<前缀>/bin/ 里是 raku-pm
  的自包含 wrapper，加到 PATH 就能直接敲 `raku-pm`：
    raku-pm env                      打印下面这两行（直接复制执行即可）
    export RAKULIB="inst#<前缀>/site"
    export PATH="<前缀>/bin:$PATH"
    raku-pm shell                    # → 打印 export RAKULIB=… / export PATH=…
    eval "$(raku-pm shell)"          # bash / zsh / Git Bash / sh 立刻生效
    raku-pm shell --shell=pwsh | Invoke-Expression   # PowerShell
    raku-pm shell --shell=fish | source              # fish
  提示：要把 <前缀>/bin 放到 PATH 最前，在 rakudo site/bin 之前 —— 否则旧版 zef 装的
  raku-pm wrapper 可能排在前面让你敲到错的版本。Windows 上同样是「PATH 顺序」说了算，
  只有同一个目录内部才轮到 PATHEXT 比扩展名。
  inst# 前缀不能省 —— 少了它 Rakudo 会把 site/ 当普通目录，多版本元数据就读不出来，
  use Foo:ver<1.2.3> 也就失效了。
TXT

@TOPICS.push: q:to/TXT/;
本地目录仓库（不需要任何索引文件）：
  一个目录下挂多个「发行版子目录」，每个子目录里放 META6.json + lib/ 即被收录：
    ~/my-dists/
      ├── HTTP-Client/{META6.json, lib/...}
      └── Web-App/{META6.json, lib/...}
  配置它：raku-pm repos add ~/my-dists        （给的是目录 → 自动识别为本地仓库）
  填内容：raku-pm fetch HTTP::Client --to=~/my-dists   或自己把包目录放 / 软链进去
  之后：  install / search / 依赖解析 都会认这个仓库里的包。
  注意：本地仓库是【源码来源】，不是已安装的包 —— 已装的在 $RAKUPM_TARGET/site/。
  单个正在开发的包不必建仓库，直接 raku-pm install ./my-pkg 即可（会自动装依赖）。
TXT

@TOPICS.push: q:to/TXT/;
安装位置（前缀）：
  --target=<路径> 指定安装前缀（优先于环境变量 RAKUPM_TARGET，默认 ~/.raku-pm）。
  RAKUPM_TARGET 是等价的环境变量写法。路径里的前导 `~` 会被展开。
  ★ 一个前缀就是一份独立的包环境：--target=<项目>/.raku-env 之后，装进来的东西只
    属于这个前缀，不跟别的项目或系统里的包串味（RAKULIB 指向它、<前缀>/bin 放在
    PATH 最前即可）。
  ★ 前缀自洽：<前缀>/bin 里的 wrapper 会把前缀显式传给 CLI —— 敲哪个前缀的 wrapper
    就在哪个前缀里干活，跟 venv 的 <venv>/bin/python 同一语义。所以「用哪个环境」
    = 「用哪个 wrapper」/「PATH 里哪个 bin 排在前面」。
  --promote-bin / --no-promote-bin
      装完要不要把 wrapper 也复制进全局 site/bin（<rakudo>/share/perl6/site/bin，
      zef 用的那个目录，在 PATH 上）：默认前缀 → 复制（装完命令立即可用）；自定义
      前缀 → 不复制（免得局部安装污染整机环境、多个前缀互相覆盖）。
TXT

@TOPICS.push: q:to/TXT/;
锁文件（可提交，0.54.0 起默认落在项目目录）：
  raku-pm 解析依赖后把「精确版本」钉进锁文件 raku-pm.lock（格式仿 Cargo.lock）。
  默认位置 = 当前工作目录，所以它能随项目提交进版本库，实现可复现安装：
    仓库根目录放 raku-pm.lock → git add raku-pm.lock 提交 → 队友 raku-pm install --locked
    装出的版本与你完全一致（--locked 下锁缺失或与解析结果不符会直接报错）。
  --lock-file=<路径> 可改位置（CI 常用）；install / reinstall / self-upgrade / lock 都认。
  锁描述的是「项目的依赖闭包」，与安装位置（--target）无关 —— 即使把包装到 .raku-env
  这种独立前缀，锁仍写在项目根，提交的是锁、不是前缀。
  锁文件默认被 .gitignore 忽略；要在项目里提交可复现锁请用 `git add -f raku-pm.lock`
  （或在该项目 .gitignore 加 `!raku-pm.lock` 取消忽略）。
TXT

@TOPICS.push: q:to/TXT/;
并发保护：
  install / uninstall / upgrade / fetch / self-upgrade / repos 等写命令会先拿一把
  跨进程文件锁（目标目录下的 .raku-pm.run.lock，flock 实现），别的 raku-pm 只能排队等
  —— 两个进程同时写 store 与 installed.json 会互相覆盖，必须串行。默认最多等 600 秒
  （RAKUPM_LOCK_TIMEOUT 可调），超时会明确报错而不是无限等。确认无并发时可加 --no-lock
  （或 RAKUPM_NO_LOCK=1）跳过；进程被 kill 时锁由操作系统回收，不会留下卡死的陈旧锁。
  持锁期间会给子进程下一张随机凭证（RAKUPM_LOCK_TOKEN，锁旁的 .token 文件），让包的
  Build.pm 里再调 raku-pm 时不至于等自己父进程的锁（自锁）。
TXT

@TOPICS.push: q:to/TXT/;
指定版本（三种写法等价，跟 zef 一致）：
  raku-pm install 'Foo:ver<1.2.3>'      精确 1.2.3
  raku-pm install 'Foo@1.2.3'           @ 简写，等价上面
  raku-pm install Foo --version=1.2.3   传统写法
  raku-pm install 'Foo:ver<1.2+>'       至少 1.2（zef 的 + 后缀，挑满足的最高版）
  raku-pm install 'Foo:ver<1.2.3>:auth<zef:someone>'
                                        再按作者过滤；auth 对不上会报错，不会偷偷装另一份
  raku-pm install 'Foo:ver<1.2.3>:auth<zef:x>:api<1>'
                                        版本 + 作者 + api
  优先级：--version > 规格串里的 :ver<> > 位置参数约束。
  这套规格写法不止 install 认 —— 查询 / 取源码命令同样支持：
    search 'Foo:ver<1.2+>'     搜索时按版本筛（同名在满足约束的版本里取最高）
    installed 'Foo:ver<1.0>'   已装列表只看满足约束的版本
    store 'Foo@1.0'            store 缓存只看满足约束的版本
    version 'Foo:ver<1.0>'     查询已装版本时按约束筛
    fetch 'Foo:ver<1.2+>'      取源码时按约束挑版本（--version 仍为精确语义）
  <> 是 shell 重定向符，各平台怎么写：
  · bash / zsh —— 整串加引号即可：search 'Foo:ver<1.2+>'
  · Windows cmd —— 加引号也不够：.bat 会对 %* 二次解析，引号在传进来前就被剥掉了，
    照样报「命令语法不正确」。改用不带尖括号的 @ 写法，任何 shell 都不用转义：
      raku-pm search Foo@1.2+
      raku-pm installed Foo@1.0
TXT

@TOPICS.push: q:to/TXT/;
生产侧（作者侧）命令直接作用于【当前这个发行版目录】，与安装目标无关。
  等价 mi6 的 `mi6 build`（重生成 provides）+ fez 的 `fez build` 拆出的「打包」半截；
  已覆盖 new / refresh / check / dist / publish / bump / login / logout；真实生态上传
  （publish --remote，multipart PUT 到 42.zef.pm/upload）已落地。
TXT

@TOPICS.push: q:to/TXT/;
环境变量：
  RAKUPM_ECOSYSTEM   生态索引地址，逗号 / 分号分隔多个
                     ※ 不设时用内置多索引（zef + cpan + rea + local）；设了就只查你给的
  RAKUPM_REPO        本地仓库根（扫描其下 META6.json）    默认: 当前目录
                     ※ 调用级设置，会覆盖 repositories.json 里存的本地路径
  RAKUPM_TARGET      安装前缀（等价于 --target=）          默认: ~/.raku-pm
                     （store/ + site/ + bin/ + git-cache/ + 锁文件）
  RAKULIB            ★ 要让 raku 找得到装好的包，得把它设成
                     inst#<RAKUPM_TARGET>/site    （用 `raku-pm env` 生成）
  RAKUPM_API_KEY     真实生态上传用的 api-key（login 也可写入本地凭据文件）  默认: 空
                     ※ publish --remote 用它或 ~/.raku-pm/credentials.json 里的 key
TXT

# ---------------------------------------------------------------------------
# 分组的中文标题与展示顺序（组的键来自 CliSpec 的 command-group）。
# ---------------------------------------------------------------------------
my @GROUP-ORDER = < packages repos env self meta author dev other >;
my %GROUP-TITLE =
    packages => '包管理',
    repos    => '仓库',
    env      => '环境诊断',
    self     => '自管理',
    meta     => '元信息',
    author   => '作者侧',
    dev      => '开发门禁',
    other    => '其他',
;

# ---------------------------------------------------------------------------
# 命令清单 / 别名清单 —— 一律从 CliSpec 现取，保证与单一事实来源同步。
# ---------------------------------------------------------------------------
sub canonical-cmds(--> List) {
    # .sort 返回 Seq，必须 .List 收成 List（否则撞返回类型约束）
    cmd-flags().keys.sort.List
}

sub cmds-by-group(--> Hash) {
    my %g;
    for canonical-cmds() -> $c { %g{command-group($c)}.push: $c }
    %g
}

# ---------------------------------------------------------------------------
# 紧凑索引：分组列出全部命令（自动按显示宽度折行）+ 别名速查表。
# 刻意【不含】长说明 —— 那是一屏放不下的根源；要看详情用 help-command。
# 设计约束（被 xt/cli-output-stability.t 守着）：首行含「用法」、列出每个规范命令、
# 列出每个别名。故索引必须由 CliSpec 生成，不能手写。
# ---------------------------------------------------------------------------
sub help-summary(--> Str) is export {
    my @lines;
    @lines.push: '用法：raku-pm <命令> [参数]';
    @lines.push: '';
    @lines.push: '查看单个命令的用法：raku-pm help <命令>';
    @lines.push: '查看完整手册（锁文件 / 并发 / 环境变量…）：raku-pm help all';
    @lines.push: '';

    my %by-group = cmds-by-group();
    my Int $indent = 9;   # 组名占的显示列宽（左对齐）
    for @GROUP-ORDER -> $g {
        my @cmds = (%by-group{$g} // ()).sort;
        next unless @cmds.elems;
        my Str $title = ui-pad(%GROUP-TITLE{$g} // $g, $indent);
        my @chunks;
        my Str $cur = '';
        for @cmds -> $c {
            if $cur.chars && ui-width($title ~ $cur ~ '  ' ~ $c) > 78 {
                @chunks.push($cur);
                $cur = $c;
            }
            else {
                $cur = $cur.chars ?? "{$cur}  {$c}" !! $c;
            }
        }
        @chunks.push($cur) if $cur.chars;
        @lines.push($title ~ @chunks.shift);
        for @chunks -> $ch { @lines.push((' ' x $indent) ~ $ch) }
    }

    @lines.push: '';
    @lines.push: '命令简写别名（少打字）：';
    my @entries = cmd-aliases().pairs.map({ "{$_.key}={$_.value}" }).sort;
    my Str $cur = '';
    for @entries -> $e {
        if $cur.chars && ui-width('  ' ~ $cur ~ '  ' ~ $e) > 78 {
            @lines.push('  ' ~ $cur);
            $cur = $e;
        }
        else {
            $cur = $cur.chars ?? "{$cur}  {$e}" !! $e;
        }
    }
    @lines.push('  ' ~ $cur) if $cur.chars;

    @lines.join("\n") ~ "\n"
}

# 该命令是否是我们认得的（ClisSpec 里登记过，help 自身也算）。
sub known-command(Str $cmd --> Bool) is export {
    my Str $c = canonical-command($cmd);
    # 注：两个 :exists 不能写成 `A:exists || B:exists` —— Raku 会把后一个 :exists
    # 当成给 `||` 加 adverb 而报「You can't adverb &infix:<||>」（UI 模块也踩过）。
    return True if %CMD-HELP{$c}:exists;
    return True if cmd-flags(){$c}:exists;
    False
}

# 单个命令的详情。未知命令返回带提示的空结果（调用方按退出码处理）。
sub help-command(Str $cmd --> Str) is export {
    my Str $c = canonical-command($cmd);
    return '' unless %CMD-HELP{$c}:exists;
    %CMD-HELP{$c}.trim-trailing ~ "\n"
}

# 完整手册 = 紧凑索引 + 全部命令详情 + 总览主题。
sub help-all(--> Str) is export {
    my @out;
    @out.push: help-summary().trim-trailing;
    @out.push: '';
    @out.push: '── 命令详情 ' ~ ('─' x 60);
    for canonical-cmds() -> $c {
        next unless %CMD-HELP{$c}:exists;
        @out.push: '';
        @out.push: %CMD-HELP{$c}.trim-trailing;
    }
    @out.push: '';
    @out.push: '── 总览 ' ~ ('─' x 64);
    for @TOPICS -> $t {
        @out.push: '';
        @out.push: $t.trim-trailing;
    }
    @out.join("\n") ~ "\n"
}
