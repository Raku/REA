# RakuPM::Fs — 文件系统小工具（递归删除 / 复制 / 遍历 / 体积）
#
# 【为什么要把这几行抽出来】
# 这些操作原先散在 8 个模块里各写一份，而且每份的细节都不一样：
#   · rm-tree   4 份：Installer / Store / Cleaner / SelfManager
#   · copy-tree 2 份：Store / Git
#   · 目录遍历  5 份：Distribution / NativeLib / SelfManager / Store / Author
# 重复的代价不只是行数：
#   1) 跳过规则不一致 —— 「跳过 .precomp」这类修正在一处生效、在另一处漏掉
#      （0.36.14 之前 Store 收了 .precomp 导致指纹漂移 + store 膨胀 17 倍）；
#   2) 异常兜底不一致 —— 有的 try 兜底有的没有，Windows 上 rmdir 静默失败；
#   3) **最隐蔽的一条**：惰性 `for $d.dir` 会在整个递归期间持有目录句柄，
#      Windows 上句柄要等 GC 才关，调用方随后 rmdir 该目录会因「目录在使用中」
#      失败（NativeLib 曾因此残留空目录；测试的 LEAVE 清理也踩过）。
# 所以本模块统一：**一律急切收集 `my @entries = $d.dir`** + 统一的跳过规则
# + 统一的 try 兜底。以后这类修正只需要改一处。
#
# 零依赖：只用 Raku 内置 IO，任何模块都能安全 use（不引入模块图）。

unit module RakuPM::Fs;

# 派生 / 元数据产物，不属于「发行版内容」，递归时默认跳过。
#   .git/.hg/.svn  VCS 元数据
#   .precomp       Rakudo 预编译字节码（派生，会自动重建）
#   blib           传统 Perl/Raku 构建输出目录
constant DEFAULT-SKIP-DIRS is export = < .git .hg .svn .precomp blib >;

# 递归删目录树（路径不存在时无操作）。
# best-effort：单个条目删不掉不中断（Windows 上文件被占用很常见），
# 失败留给调用方按「目录是否还在」自行判断，而不是让整轮清理崩掉。
sub rm-tree(IO::Path $path --> Nil) is export {
    return unless $path.e;
    unless $path.d {
        try $path.unlink;
        return;
    }
    # 急切收集：及时释放目录句柄，之后才能 rmdir 成功
    my @entries = $path.dir;
    rm-tree($_) for @entries;
    try $path.rmdir;
}

# 逐级创建目录（等价 `mkdir -p`），已存在则无操作。返回 $p 以便链式调用。
#
# 为什么不用 IO::Path.mkdir 的 :parents / :p —— Rakudo 2026.08 上它的签名是
#     :(IO::Path:D $: Int(Any) $mode = 511, *%_)
# 只有 $mode，**没有任何 :parents**；传 :parents / :p 会被 *%_ 静默吞掉 ——
# 不报错、也不生效。Windows 上因为 CreateDirectoryW 本身就会自动建父目录而
# 「看起来正常」，Linux 上 mkdir(2) 不建父目录，于是
# `<root>/<name>/<version>` 这类深层路径会直接失败。属于「只在 Linux/CI 上炸、
# 本机 Windows 测不出来」的一类，实测签名确认过才改成逐级创建。
sub mkdir-p(IO::Path $p --> IO::Path) is export {
    return $p if $p.d;
    my @missing;
    my $cur = $p;
    loop {
        last if $cur.e;
        my $parent = $cur.parent;
        last if $parent.absolute.Str eq $cur.absolute.Str;   # 已经到根
        @missing.push($cur);
        $cur = $parent;
    }
    for @missing.reverse { try { $_.mkdir } }
    $p
}

# 递归收集 $path 下的全部【普通文件】，返回 IO::Path 列表。
#   :@skip-dirs  跳过的目录名（默认 DEFAULT-SKIP-DIRS）
#   :@skip-names 跳过的文件名
# 结果按【绝对路径】排序 —— 让指纹计算、tar 清单、provides 扫描都稳定可复现
# （同一份内容在任何机器上得到同样的遍历顺序）。
sub walk-files(IO::Path $path,
               :@skip-dirs = DEFAULT-SKIP-DIRS,
               :@skip-names = () --> List) is export {
    my @out;
    sub recurse(IO::Path $dir) {
        return unless $dir.e && $dir.d;
        my @entries = $dir.dir;      # 急切收集
        for @entries -> $entry {
            my $base = $entry.basename;
            if $entry.d {
                next if $base (elem) @skip-dirs;
                recurse($entry);
            }
            elsif $base (elem) @skip-names {
                next;
            }
            else {
                @out.push($entry);
            }
        }
    }
    recurse($path);
    # .sort 返回 Seq，签名承诺 List —— 必须显式 .List
    @out.sort({ .absolute.Str }).List
}

# 递归复制目录树。$dest 不存在则创建；已存在则**合并**（不删除 $dest 里多余的文件）。
# 调用方通常先 rm-tree 清空再 copy（保证结果可复现），见 Installer.pending-cur-spec
# / cleanup-stage-all（整树事务化暂存路径）。
#
# 【防呆】目标若位于源目录内部，`$dest.mkdir` 之后 `$src.dir` 就已经包含 $dest，
# 递归会自我复制到路径长度爆炸（实测报 "Failed to mkdir: name too long" 并把
# 几百层目录留在磁盘上）。这里直接拒绝，把一个难查的无限递归变成一条清晰报错。
sub copy-tree(IO::Path $src, IO::Path $dest,
              :@skip-dirs = DEFAULT-SKIP-DIRS --> Nil) is export {
    my $sep = $*SPEC.dir-sep;
    die "copy-tree：目标目录不能位于源目录内部（{$dest.absolute} 在 {$src.absolute} 内）"
        if $dest.absolute.Str.starts-with($src.absolute.Str ~ $sep);
    mkdir-p($dest);
    my @entries = $src.dir;          # 急切收集
    for @entries -> $entry {
        next if $entry.basename (elem) @skip-dirs;
        my $d = $dest.add($entry.basename);
        $entry.d ?? copy-tree($entry, $d, :@skip-dirs) !! $entry.copy($d);
    }
}

# 递归统计目录体积（字节）。拿不到的文件按 0 计（不抛）。
sub dir-size(IO::Path $path --> Int) is export {
    return 0 unless $path.e;
    return (try { $path.s }) // 0 unless $path.d;
    my $n = 0;
    for (try { $path.dir }) // () -> $e { $n += dir-size($e) }
    $n
}
