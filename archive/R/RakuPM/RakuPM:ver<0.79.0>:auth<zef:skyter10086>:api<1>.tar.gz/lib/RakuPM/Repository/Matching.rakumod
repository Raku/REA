# RakuPM::Repository::Matching — 「关键词怎么算匹配一个发行版」的唯一实现处
#
# 为什么要有这个 role：
#   早先这段匹配逻辑散在四个地方各写一遍 —— Ecosystem.!search-score、
#   Local.search-rows（内联评分）、Reporter.!installed-matching 的两个分支
#   （账本侧 + zef 侧）。于是同一个语义要在四处同步：改「要不要扫 description」
#   「相关度怎么分级」得同时改四处，漏一处就出现「search 太广 / 结果不排序」
#   这类不一致（用户实测反馈过）。
#
#   归一之后：RakuPM::Repository 基 role `does` 本 role，**所有仓库自动获得**；
#   RakuPM::Client::Reporter 也 `does` 它（查询命令 side）。search / store /
#   installed / install 的「匹配」从此只有这一份定义。
#
# 纯函数式、零依赖：入参只有 (发行名, provided 模块名列表, 关键词)，
# **不碰网络、不碰索引、不碰磁盘**。所以测试可以直接喂数据断言，
# 不必构造仓库、不必起 HTTP 桩 —— 这正是把逻辑抽到这里的第二个好处。
#
# 匹配范围只含【发行名 + provided 模块名】，**特意不扫 description**：
# 很多 dist 的 description 会写「provides method xxx」，扫描述会把方法名
# 也当成匹配项、结果过宽（这是用户反馈「search 连方法名都匹配」的根因）。
unit role RakuPM::Repository::Matching;

# 相关度等级（越小越相关，供调用方排序 / 设阈值）。无匹配 → Nil。
#
#   0 发行名精确   1 发行名前缀   2 发行名子串
#   3 模块名精确   4 模块名前缀   5 模块名子串
#
# 把「模块名」再拆成精确/前缀/子串三档（而不是只在 0/1/2 之外给一个笼统的 3），
# 是为了让定向查询（store / installed）能只取「精确」两档（0 与 3）——
# 既支持「用模块名找发行版」（目录名 Web-App、模块 Web::App），
# 又不会被「子串命中」放大成误匹配（`installed Web` 不该列出 `Web::App`）。
method match-score(Str $name, @provides, Str $kw) {
    my $lc = $kw.lc;
    my $n  = $name.lc;
    if $n.chars {
        return 0 if $n eq $lc;
        return 1 if $n.starts-with($lc);
        return 2 if $n.contains($lc);
    }
    for @provides -> $m {
        my $ml = ($m // '').lc;
        next unless $ml.chars;
        return 3 if $ml eq $lc;
        return 4 if $ml.starts-with($lc);
        return 5 if $ml.contains($lc);
    }
    Nil
}

# 定向查询用：名字或任一 provided 模块名【精确】命中才算匹配。
#
# store / installed 这类命令要的是「用户打的那个名字」，不是模糊推荐：
#   `raku-pm installed JSON::Fast`  → 精确 dist 名 / 精确模块名，命中
#   `raku-pm installed json`        → 不命中（子串留给 search 去做）
# 与 install 的解析同源：install 用仓库的 find-providers（精确模块名反查），
# 语义上等价于本方法的 level 3 那一档。
method match-exact(Str $name, @provides, Str $kw --> Bool) {
    my $s = self.match-score($name, @provides, $kw);
    $s.defined && ($s == 0 || $s == 3);
}

# 模糊查询用：任一级命中即可（search 的默认语义）。
method match-any(Str $name, @provides, Str $kw --> Bool) {
    self.match-score($name, @provides, $kw).defined;
}
