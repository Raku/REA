# RakuPM::Platform — 「这台机器是什么平台」的唯一出处
#
# 为什么要有这个模块（审查报告 H9）：
#
#   `if $*DISTRO.is-win { ... } else { ... }` 这类分支在【当前平台】上是单向
#   短路的 —— 在 Windows 开发机上，else 分支（Linux/macOS 的逻辑）永远不执行，
#   于是它的错误【永远测不出来】。本项目真实栽过：MD5.system-md5 里写了
#   `$*DISTRO.is-macosx`（Distro 根本没有这个方法），Windows 上 is-win 为真、
#   elsif 直接短路，全套测试全绿；一到 Linux 就
#   「No such method 'is-macosx' for invocant of type 'Distro'」，
#   崩在 Store 的内容指纹计算上 —— 而那是 store/verify 的必经之路。
#
#   对策分两层：
#
#     1) 平台差异【只能】在这里判断。别处一律调用本模块的函数，于是
#        「这台机器是什么平台」在全项目只有一个读 `$*DISTRO` 的地方。
#        强制力由 t/platform-centralized.t 提供：它扫描 lib/ 下除本文件以外
#        的所有源码，发现任何直接用 `$*DISTRO` / `$*KERNEL` 的地方就报错。
#
#     2) 本模块的函数一律在【调用时】读 `$*DISTRO`，因此测试可以用
#        `my $*DISTRO = Distro.new(:name('linux'))` 词法遮蔽它（Raku 的动态
#        变量查找是运行期的，并且能穿透进被调用的模块/方法）。见 t/platform.t：
#        三个平台 × 每个函数都有断言，在任何一台机器上都能真跑。
#
#   「模拟另一台机器」的显式覆盖（`raku-pm native --os=linux`）走同一个模块的
#   $os 形参：传空则自动探测，传值则按那台机器回答。
#
# 约定：所有返回列表的函数都返回 `.List`（不要 Seq/Array 混用，调用方常
# 直接 .raku 比较）。所有 $os 形参传空串表示「按本机」。

unit module RakuPM::Platform;

# ============ OS 判别 ============

# 规范化外部传入的 os 名（`raku-pm native --os=...`）。
# 别名都收进来，因为人们会写 windows / macos / macOS / osx / win32 各种形态。
# 认不出来（含空串 / 'auto'）→ 返回空串，表示「交回自动探测」。
sub normalize-os-key(Str $os --> Str) is export {
    given $os.trim.lc {
        when 'win32' | 'windows' | 'win' | 'mswin32'    { 'win32'  }
        when 'darwin' | 'macos' | 'macosx' | 'osx' | 'mac' { 'darwin' }
        when 'linux' | 'unix' | 'gnu'                   { 'linux'  }
        default                                         { ''       }
    }
}

# 自动探测本机：'win32' | 'darwin' | 'linux'。
# 其余 Unix（FreeBSD 等）也归到 linux 这一支 —— 它们的库命名/搜索路径规则一致。
#
# 注意两件事：
#   ① Distro 只有 is-win，没有 is-macosx（这就是当年踩坑的那一点）；
#   ② **name 也要看** —— 实测 `Distro.new(:name('win32')).is-win` 是 False
#      （Rakudo 只把 name 'mswin32' 判成 win），而 raku-pm 自己的平台键就叫
#      'win32'。若只信 is-win，测试里按本模块的键遮蔽成 'win32' 就会被
#      静默判成 linux —— 遮蔽测试于是验的是错的那一支，白测。
#   ③ 顺序要紧：**darwin 必须排在 'win' 之前判断** —— 字符串 "darwin"
#      里就含 "win"（da-rwin），先看 'win' 会把 macOS 判成 Windows。
sub os-key(--> Str) is export {
    return 'win32' if $*DISTRO.is-win;
    my $n = ($*DISTRO.name // '').lc;
    return 'darwin' if $n.contains('macos') || $n.contains('darwin') || $n.contains('osx');
    return 'win32'  if $n.contains('win');   # darwin 已在上一步排掉；Linux 发行版名不含 win
    'linux'
}

# 统一入口：显式 $os 优先（规范化后仍认不出就走探测）。
sub resolve-os(Str $os = '' --> Str) is export {
    my $k = normalize-os-key($os);
    $k.chars ?? $k !! os-key()
}

sub is-windows(Str $os = '' --> Bool) is export { resolve-os($os) eq 'win32'  }
sub is-macos(Str $os = '' --> Bool)   is export { resolve-os($os) eq 'darwin' }
sub is-linux(Str $os = '' --> Bool)   is export { resolve-os($os) eq 'linux'  }

sub os-label(Str $os = '' --> Str) is export {
    given resolve-os($os) {
        when 'win32'  { 'Windows'    }
        when 'darwin' { 'macOS'      }
        default       { 'Linux/Unix' }
    }
}

# ============ 发行版 / 内核名 ============
#
# META6 的 `by-distro.name` / `by-kernel.name` 条件依赖要拿这两个名字去匹配
# （mswin32 / ubuntu / macos …），所以它们也算平台知识，收在这里。

sub distro-name(--> Str) is export { ($*DISTRO.name // '').Str }
sub distro-desc(--> Str) is export { ($*DISTRO.desc // '').Str }
sub kernel-name(--> Str) is export { ($*KERNEL.name // '').Str }

# 逻辑 CPU 核数（并发度默认上限的来源）。读 $*KERNEL 只许在本模块，
# 全项目其它地方一律调本函数（t/platform-centralized.t 纪律）。
sub cpu-cores(--> Int) is export { (try { $*KERNEL.cpu-cores } // 4).Int }

# ============ 环境变量里的目录列表 ============

# 列表分隔符：Windows 用分号，其余用冒号。
sub path-list-sep(Str $os = '' --> Str) is export {
    is-windows($os) ?? ';' !! ':'
}

# 读某个环境变量并按平台分隔符拆成目录列表（PATH / LD_LIBRARY_PATH / …）。
sub env-dirs(Str $name, Str $os = '' --> List) is export {
    my $v = %*ENV{$name};
    return () unless $v.defined && $v.chars;
    $v.split(path-list-sep($os)).grep(*.chars).List
}

# PATH 在不同平台/宿主里大小写不一（Windows 常见是 `Path`）。
sub path-dirs(--> List) is export {
    my $v = (%*ENV<PATH> // %*ENV<Path> // %*ENV<path> // '').Str;
    $v.split(path-list-sep()).grep(*.chars).List
}

# ============ 可执行文件 ============

# 命令名要按什么顺序补扩展名去试。
#
# Unix：只有无扩展名那一种（可执行位由文件系统决定）。
#
# Windows（0.48.0 修正）：**必须按 PATHEXT 来，且无扩展名要排在最后**。
# 旧实现写的是 `('', '.exe', '.bat', '.cmd', '.ps1')` —— 把无扩展名排第一，
# 那是 Unix 语义：cmd.exe / PowerShell 解析命令名时**只查 PATHEXT 里列出的
# 扩展名**，一个没有扩展名的 `raku-pm` 文件根本不会被执行。于是
# `raku-pm env` 报「第一个就是实际跑的那份」时指到了 bash wrapper，
# 而实测真正被执行的是排在它后面的 `raku-pm.exe`（用户现场：升级到 0.47.0
# 后敲 `raku-pm version` 仍显示 0.46.1）。顺序错 = 自查工具把人引向错答案。
#
# PATHEXT 从环境读（用户可能改过，也可能加了 .PS1）；读不到时用 Windows 默认值。
#
# 刻意**不**追加无扩展名兜底：cmd.exe / PowerShell 解析命令名时只查 PATHEXT
# 里列出的扩展名，一个叫 `raku-pm` 的没有扩展名的文件**不会被执行**。把它列成
# 候选会让「敲这个名字实际会跑哪个文件」的判定变错 —— 而那个判定正被
# `raku-pm env` 和入口体检当依据（0.48.0 改这里的原因）。
# Unix 相反：只有无扩展名那一种。
sub exec-suffixes(Str $os = '' --> List) is export {
    return ('',).List unless is-windows($os);
    my $pathext = (%*ENV<PATHEXT> // '').Str;
    $pathext.chars
        ?? $pathext.split(';').map({ .trim.lc }).grep({ .chars && .starts-with('.') }).List
        !! < .com .exe .bat .cmd >.List
}

# 在 $dir 里按平台解析规则找出「用户敲这个命令名时，系统实际会执行哪个文件」。
# 找不到返回未定义的 IO::Path。这是唯一的一处判定，供入口体检与 `env` 共用，
# 避免两处各写一套、又对不上（0.47.0 的 env 就是这么错的）。
sub pick-command-file(IO::Path $dir, Str $base, Str $os = '' --> IO::Path) is export {
    return IO::Path unless $dir.defined && $dir.Str.chars;
    for exec-suffixes($os) -> $sfx {
        my $p = $dir.add($base ~ $sfx);
        return $p if $p.e;
    }
    IO::Path
}

# 在 PATH 里查一个可执行文件，返回它的路径；找不到返回未定义的 IO::Path。
sub find-executable(Str $cmd --> IO::Path) is export {
    return IO::Path unless $cmd.chars;
    for path-dirs() -> $dir {
        my $d = $dir.IO;
        for exec-suffixes() -> $sfx {
            my $p = $d.add($cmd ~ $sfx);
            return $p if $p.f;
        }
    }
    IO::Path
}

sub has-executable(Str $cmd --> Bool) is export {
    find-executable($cmd).defined
}

# ============ 路径形态 ============

# 把 Git Bash / MSYS 风格的路径（/c/Users/foo）转成 Windows 原生路径
# （C:\Users\foo）。否则 Raku 会把 /c/Users/foo 当【字面相对路径】，
# 写到 C:\c\Users\foo 这种鬼位置。
#
# 【必须按平台门控】：在 Linux 上 `/c/foo` 是一个合法的绝对路径，
# 无条件转换会把它篡改成 C:\foo —— 旧实现没门控，就是这个隐患。
# PowerShell / CMD 直接传 C:\... 时不触发。
sub native-path(Str $p --> IO::Path) is export {
    return IO::Path.new($p) unless is-windows;

    # 用 \x5C = 反斜杠，\x2F = 正斜杠（避免 Raku 把 / 当 regex 分界符）
    my $BS = "\x5C";
    my $SL = "\x2F";

    # MSYS / Git Bash 风格：/c/Users/foo
    if $p ~~ m{^ '/' (<[a..z]>) '/'} {
        my $drive = $0.uc;
        my $rest  = $p.substr(3).comb.map({ $_ eq $SL ?? $BS !! $_ }).join('');
        return IO::Path.new: $drive ~ ':' ~ $BS ~ $rest;
    }
    # 已经是 Windows 路径：c:\foo 或 C:\foo（也容忍正斜杠）
    if $p ~~ m{^ (<[a..z A..Z]>) ':' <[\\ \x2F]>} {
        my $clean = $p.substr(2).comb.map({ $_ eq $SL ?? $BS !! $_ }).join('');
        return IO::Path.new: $0.uc ~ ':' ~ $clean;
    }
    # 纯相对路径：交给 IO 抽象层
    IO::Path.new($p)
}

# ============ 进程 ============

# 强杀一个子进程（含它的子进程树）。
#
# 实测（重要）：Windows 上 `Proc::Async.kill` 对任意信号都【无效】—— 子进程
# 照跑不误，超时看门狗形同虚设；必须走 `taskkill /PID <pid> /F /T`。
# Unix 上 `Proc::Async.kill(9)`（SIGKILL）有效。
#
# 【契约】第一个参数必须「能 kill」——即 **Proc::Async**，不是
# `$proc.start(...)` 返回的 Promise。用 `where *.can('kill')` 而不是
# `Proc::Async` 具体类型，是为了（a）同样在**平台分支之前**报错，
# 又（b）允许测试传替身对象（`Proc::Async` 是内置类型，没法给替身加上 `does`）。
#
# 为什么必须让它在分支之前报错：Unix 分支用 `try` 包着（进程已退出时 kill 会抛），
# 于是「传错对象」也会被 try 吞掉、**静默不杀**；而 Windows 分支只用 $pid、碰都
# 不碰这个参数 —— 若签名不加约束，传 Promise 在 Windows 上照样一切正常，
# **这个 bug 在开发机上永远暴露不了**（0.46.1 的 Unix 看门狗从未生效就是这么来的）。
# 加了约束之后，传错对象在任何平台上都立刻失败，`xt/tester-async.t` 场景 3 会变红
# —— 0.47.0 开发时正是它把我自己的回归抓出来的。
# t/platform.t 同时钉住「误传 Promise 立刻抛」与「两个分支各调什么」。
#
# $pid 是真实整数 PID（Proc::Async 的 .pid 是 Promise，要先 await）。
sub kill-tree($proc where *.can('kill'), $pid, Str $os = '' --> Nil) is export {
    if is-windows($os) {
        my $tk = try { run('taskkill', '/PID', ~$pid, '/F', '/T', :out, :err) };
        # run(:out,:err) 之后必须吞掉管道，否则 Windows 句柄泄漏、子进程不退
        if $tk ~~ Proc {
            try { $tk.out.slurp(:close) if $tk.out }
            try { $tk.err.slurp(:close) if $tk.err }
        }
    }
    else {
        try $proc.kill(9);
    }
}

# 查命令用的工具：Windows 用 where（返回原生路径），其余用 which。
# 不依赖 cygpath。
sub which-command(--> Str) is export { is-windows() ?? 'where' !! 'which' }

# ============ 系统 md5 命令 ============
#
# 「哪个平台用哪条命令、输出长什么样」也是平台知识，而且是**非当前平台就
# 永远测不到**的典型：在 Windows 上跑，Linux/macOS 那两条命令行与解析分支
# 根本执行不到。放在这里就能被 t/platform.t 用遮蔽测个遍。
# RakuPM::MD5 拿这两个函数拼自己的进程流程（超时/回退/校验仍归它）。

# 各平台的 md5 命令行。
sub md5-command(IO::Path $path, Str $os = '' --> List) is export {
    given resolve-os($os) {
        when 'win32'  { ('certutil', '-hashfile', $path.Str, 'MD5').List }
        when 'darwin' { ('md5', '-q', $path.Str).List }
        default       { ('md5sum', $path.Str).List }
    }
}

# 从系统 md5 命令的 stdout 里取出十六进制摘要（未做小写/长度校验）。
sub parse-md5-output(Str $out, Str $os = '' --> Str) is export {
    given resolve-os($os) {
        # certutil 输出三行，第二行是哈希值，第一行/第三行是说明文字
        when 'win32'  { $out.lines[1] // '' }
        # md5 -q 只打印一行哈希，没有文件名
        when 'darwin' { $out.lines[0] // '' }
        # md5sum 打印 "<hex>  <文件名>"（两个空格）
        default       { $out.words[0] // '' }
    }
}

# ============ 库文件名规则 ============

# 逻辑名 → 该平台上的候选文件名（【不含】NativeLib 的 %LIBS 已知库表）。
# Windows 是「不加 lib 前缀」的那一支，macOS 用 .dylib。
sub library-file-names(Str $key, Str $os = '' --> List) is export {
    given resolve-os($os) {
        when 'win32'  { ("$key.dll", "lib$key.dll").List }
        when 'darwin' { ("lib$key.dylib", "$key.dylib").List }
        default       { ("lib$key.so", "$key.so").List }
    }
}

# ============ 库搜索路径 ============

# rakudo 自己的 bin 目录：Windows 的 DLL 搜索顺序第一条就是【可执行文件所在
# 目录】，所以 <rakudo>/bin 下的 DLL（moar.dll、readline.dll，以及各发行版
# 自己拷进去的 sqlite3.dll 之类）NativeCall 加载得到 —— 检查路径必须包含它。
# 取不到就返回空，不影响其它搜索路径。
sub rakudo-bin-dirs(--> List) {
    my @out;
    try {
        my $bin = $*EXECUTABLE.absolute.IO.parent;
        @out.push($bin.absolute) if $bin.defined && $bin.d;
    }
    @out.unique.List
}

# Debian/Ubuntu 的多架构目录（x86_64-linux-gnu、aarch64-linux-gnu 等）。
# 现代 Debian 系把库全挪到了这里，只搜 /usr/lib 会漏掉。
sub multiarch-dirs(--> List) {
    my @archs = 'x86_64-linux-gnu', 'aarch64-linux-gnu', 'arm-linux-gnueabihf',
                'i386-linux-gnu', 'riscv64-linux-gnu';
    my @out;
    for '/usr/lib', '/lib' -> $base {
        @out.append(@archs.map({ "$base/$_" }));
    }
    # 机器上真实存在的架构目录优先（用 dir 反查，避免猜错）
    my $ul = '/usr/lib'.IO;
    if $ul.d {
        @out.append($ul.dir.grep({ .d && .basename.ends-with('-linux-gnu') })
                          .map(*.Str));
    }
    @out.List
}

# 本平台的库搜索路径（按可能性从高到低）。
sub library-search-paths(Str $os = '' --> List) is export {
    my @raw = do given resolve-os($os) {
        when 'win32' {
            # Windows 找 DLL 的顺序：① 可执行文件所在目录 ② 系统目录 ③ PATH …
            # ① 就是 rakudo 的 bin 目录，必须放在 PATH 之前（见上面注释）。
            ( rakudo-bin-dirs(),
              'C:/Windows/System32', 'C:/Windows/SysWOW64',
              env-dirs('PATH', 'win32'),
              'C:/vcpkg/installed/x64-windows/bin',
              'C:/vcpkg/installed/x86-windows/bin',
            ).flat
        }
        when 'darwin' {
            ( env-dirs('DYLD_LIBRARY_PATH', 'darwin'),
              env-dirs('DYLD_FALLBACK_LIBRARY_PATH', 'darwin'),
              '/opt/homebrew/lib',      # Apple Silicon 的 Homebrew
              '/usr/local/lib',         # Intel Mac 的 Homebrew
              '/opt/local/lib',         # MacPorts
              '/usr/lib',
            ).flat
        }
        default {
            ( env-dirs('LD_LIBRARY_PATH', 'linux'),
              '/usr/local/lib', '/usr/lib', '/lib',
              '/usr/lib64', '/lib64',
              multiarch-dirs(),
            ).flat
        }
    };

    # 去掉结尾的分隔符，避免拼出双斜杠。Windows 的 PATH 条目常以【反斜杠】
    # 结尾（C:\foo\），原先只处理了正斜杠，反斜杠会漏掉。
    # 最后去重（环境变量与内置候选常常重复）。
    @raw.grep({ .defined && .chars > 1 })    # 过滤 PATH 里的垃圾条目（如单独的 "C"）
        .map({ .subst(/ <[\\/]> $ /, '') })
        .unique
        .List
}

# ============ Linux 发行版族 ============

# 把发行版名/描述里的关键词归到包管理器族。因为 apt / dnf / pacman / apk /
# zypper 的包名各不相同，给错命令等于没给。
my %FAMILY =
    debian => ('debian', 'ubuntu', 'mint', 'raspbian', 'pop', 'elementary',
               'kali', 'devuan'),
    rhel   => ('rhel', 'centos', 'fedora', 'rocky', 'almalinux', 'amzn',
               'redhat', 'amazon'),
    arch   => ('arch', 'manjaro', 'endeavouros', 'artix', 'garuda'),
    alpine => ('alpine',),
    suse   => ('suse', 'opensuse', 'sled'),
;

# Linux 发行版族；认不出来就给泛用 'linux'。
# $name 一般传发行版名（$*DISTRO.name 或 --distro 强制的值）；
# $desc 只在 $name 认不出来时当补充线索（强制指定 distro 时不要传 desc，
# 避免真实机器的描述串干扰结果 —— 那是 NativeLib 的既有语义）。
sub linux-family(Str $name, Str $desc = '' --> Str) is export {
    my $n = $name.lc;
    my $d = $desc.lc;
    for %FAMILY.kv -> $fam, @names {
        return $fam if @names.first({ $n.contains($_) || $d.contains($_) });
    }
    'linux'
}

# 决定用哪套「安装本地库」命令的键：
#   Windows → 'win32'，macOS → 'darwin'，Linux → 发行版族（debian/rhel/arch…）
# $name/$desc 缺省时用本机真实值（$os 指向别的平台时，本机发行版值无意义，
# 调用方应显式传）。
sub package-key(Str :$os = '', Str :$name = '', Str :$desc = '' --> Str) is export {
    my $k = resolve-os($os);
    return $k unless $k eq 'linux';
    my $n = $name.chars ?? $name !! distro-name();
    my $d = $name.chars ?? $desc !! distro-desc();   # 显式给了 name 就不再拿本机 desc 兜底
    linux-family($n, $d)
}

# 在默认浏览器里打开一个 URL（browse 命令用）。
# 平台分支集中在这里（t/platform-centralized.t 的纪律）：
#   Windows → `cmd /c start "" <url>`（start 是 cmd 内建，不能直接 run；
#            第一个空串参数是 start 的「窗口标题」位，不能省，否则带空格的
#            URL 会被当成标题而打不开）；
#   macOS   → `open <url>`；
#   Linux   → `xdg-open <url>`。
# 浏览器是独立进程，打开即返回；exitcode 不可靠（start 总返回 0），这里只认
# 「命令本身能起动」—— 起动失败（系统没默认浏览器 / 命令不存在）返回 False。
# :$os 可注入，便于测试在任意宿主上验三套语义。
sub open-url(Str $url, Str $os = '' --> Bool) is export {
    my $proc = try {
        is-windows($os)
            ?? run('cmd', '/c', 'start', '', $url, :out, :err)
            !! run(is-macos($os) ?? 'open' !! 'xdg-open', $url, :out, :err)
    };
    return False unless $proc.defined;
    try { $proc.out.slurp(:close) } if $proc.out.?opened;
    try { $proc.err.slurp(:close) } if $proc.err.?opened;
    return $proc.exitcode == 0;
}
