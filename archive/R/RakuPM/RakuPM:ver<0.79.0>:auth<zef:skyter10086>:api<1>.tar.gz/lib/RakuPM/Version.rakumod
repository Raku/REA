# RakuPM::Version — 语义化版本 (semver) 的解析、比较、约束匹配
#
# 支持约束： "1.2.3"（精确）、">= 1.0"、">1.0"、"<=2.0"、">=1.0, <2.0"（区间）、
#           "*" 或空（任意版本）。
# 这是「解析阶段」的核心：判断「某版本是否满足某约束」。

unit class RakuPM::Version;

has Int $.major = 0;
has Int $.minor = 0;
has Int $.patch = 0;
has Str $.prerelease = '';

# 从 "1.2.3" / "1.2.3-alpha" / "v0.2" 解析。
# 生态索引里的版本号很脏（有 "v0.2"、"0.2rc1" 这类），而 pick-best 会对
# 【所有候选版本】调用本方法，任何一个坏串都会让整个解析阶段崩掉，
# 所以这里对非数字片段一律退化为 0，而不是抛异常。
method from-string(Str $s --> RakuPM::Version) {
    my $t = ($s // '').trim;
    $t ~~ s{^ <[vV]> } = '';                 # "v0.2" -> "0.2"
    my ($core, $pre) = $t.split('-', 2);
    my @parts = $core.split('.');
    RakuPM::Version.new:
        :major(self!num-part(@parts[0])),
        :minor(self!num-part(@parts[1])),
        :patch(self!num-part(@parts[2])),
        :prerelease($pre // '');
}

# 取字符串开头的数字部分，取不到（空 / 非数字 / "2rc1"）就当 0
method !num-part($x --> Int) {
    my $n = ($x // '').trim;
    return 0 unless $n.chars;
    $n ~~ /^ (\d+) / ?? +$0 !! 0
}

# 数值化：转成可比较的元组。正式版 > 预发布版（同 core 时）
method key(--> List) {
    ($!major, $!minor, $!patch, $!prerelease eq '' ?? 1 !! 0)
}

# 三向比较：返回 Order::Less / Same / More
method cmp(RakuPM::Version $other --> Order) {
    self.key cmp $other.key
}

# 便捷运算符
multi sub infix:<eqv-ver>(RakuPM::Version $a, RakuPM::Version $b --> Bool) { $a.cmp($b) == Same }
multi sub infix:«<ver»(RakuPM::Version $a, RakuPM::Version $b --> Bool) { $a.cmp($b) == Less }

# ============ 约束解析 ============

# 检查某个版本是否满足一个「约束字符串」
method satisfies(Str $constraint --> Bool) {
    return True if $constraint.trim eq '' or $constraint.trim eq '*';

    # 先把 npm/cargo 风格的 ^ / ~ 糖语法展开成 >= / < 比较器对，再走下面的通用解析。
    # 只处理「符号后跟版本字符」的情形，不会误伤本项目已有的其它写法。
    my $c = self.expand-sugar($constraint);

    # 用逗号拆成多个子约束，必须「全部」满足（AND 关系）
    for $c.split(',') -> $part {
        my $p = $part.trim;
        next if $p eq '';

        # 用字符串前缀匹配解析运算符，避免正则里 < > 的歧义
        my ($op, $ver) = self.parse-constraint-part($p);
        my $target = RakuPM::Version.from-string($ver);
        my $c = self.cmp($target);

        given $op {
            # 注意：'=' 与 '==' 是「精确匹配」，只接受相等，不能放宽成 >=
            when '==' | '=' { return False unless $c == Same; }
            when '>=' | ''  { return False unless $c == More || $c == Same; }
            when '>'        { return False unless $c == More; }
            when '<='       { return False unless $c == Less || $c == Same; }
            when '<'        { return False unless $c == Less; }
            default         { die "未知的约束运算符: $op"; }
        }
    }
    True
}

# 解析单个子约束，如 ">= 1.0.0" -> (">=", "1.0.0")
method parse-constraint-part(Str $p --> List) {
    # zef 风格 "0.2+" 表示「至少 0.2」（at-least）。
    # 仅当约束以数字开头、以 + 结尾时才按 at-least 处理，
    # 避免误伤 ">=" 这类自身不带 + 的写法，也避免把 "1.0+" 当普通字符串。
    if $p ~~ /^ \d .*? '+' $ / {
        my $ver = $p.substr(0, $p.chars - 1).trim;
        return ('>=', $ver) if $ver.chars;
    }
    # 注意顺序：先匹配双字符运算符，再匹配单字符
    my @ops = ['>=', '<=', '==', '>', '<', '='];
    for @ops -> $op {
        if $p.starts-with($op) {
            my $ver = $p.substr($op.chars).trim;
            return ($op, $ver);
        }
    }
    # 没有运算符，视为精确匹配
    return ('=', $p);
}

# ============ ^ / ~ 糖语法展开（npm / cargo 风格）============
# 把 ^（caret，兼容区间）与 ~（tilde，近似区间）展开成项目统一的 >= / < 比较器对，
# 再交给 parse-constraint-part 解析。展开产物里不含 ^ / ~，不会二次展开。
#   ^1.2.3 → >=1.2.3, <2.0.0      ^0.2.3 → >=0.2.3, <0.3.0
#   ^0.0.3 → >=0.0.3, <0.0.4      ^1    → >=1.0.0, <2.0.0
#   ~1.2.3 → >=1.2.3, <1.3.0      ~1.2  → >=1.2.0, <1.3.0
#   ~1     → >=1.0.0, <2.0.0
method expand-sugar(Str $c is copy --> Str) {
    # 只认「符号后跟版本字符（数字 / v / . / x / *）」，其余写法原样保留
    $c = $c.subst(:g, / \^ \s* (<[ \d v V . x X * ]>+) /,
        -> $/ { ">= $0, <" ~ self!caret-upper(~$0) ~ ">" });
    $c = $c.subst(:g, / \~ \s* (<[ \d v V . x X * ]>+) /,
        -> $/ { ">= $0, <" ~ self!tilde-upper(~$0) ~ ">" });
    $c
}

# caret 上界：左起第一个非零位 +1、其余清零；全零则按「最后指定的位」+1。
method !caret-upper(Str $v --> Str) {
    my $p = RakuPM::Version.from-string($v);
    my $n = ($v.subst(/^<[vV]>/, '')).trim.comb('.').elems;  # 用户给了几位：1 / 2 / 3
    return "{$p.major + 1}.0.0" if $p.major > 0;
    return "0.{$p.minor + 1}.0" if $p.minor > 0;
    return "0.0.{$p.patch + 1}" if $p.patch > 0;
    # 全零：按最后指定的位 +1（^0 → 1.0.0；^0.0 → 0.1.0；^0.0.0 → 0.0.1）
    return $n >= 3 ?? "0.0.1" !! ($n == 2 ?? "0.1.0" !! "1.0.0");
}

# tilde 上界：给了 minor（>= 2 位）就锁 minor（+1、patch 归零）；只给 major 就锁 major（+1）。
method !tilde-upper(Str $v --> Str) {
    my $p = RakuPM::Version.from-string($v);
    my $n = ($v.subst(/^<[vV]>/, '')).trim.comb('.').elems;
    return "{$p.major}.{$p.minor + 1}.0" if $n >= 2;
    "{$p.major + 1}.0.0"
}

# 从一组可用版本里挑出「满足约束的最高版本」（返回版本字符串或空串）
method pick-best(Str $constraint, @versions --> Str) {
    my @ok = @versions
        .map({ ($_, RakuPM::Version.from-string($_)) })   # (原始串, Version 对象)
        .grep({ .[1].satisfies($constraint) })
        .sort({ $^b[1].cmp($^a[1]) });          # 从高到低
    return '' unless @ok;
    # 返回仓库里出现的「原始版本串」，而不是规范化后的 major.minor.patch，
    # 否则像 "0.2" 会被归一成 "0.2.0"，与 available-versions 对不上导致找不到。
    @ok[0][0]
}

# 版本字符串列表按 semver 升序（去重 + 去空）。
#
# 不能用字典序：字典序里 "0.13.0" < "0.9.2"（因为 '1' < '9'），
# 会把 0.9.2 误当成最高版本（用户的实测案例：装了 0.9.2 与 0.13.0 后，
# installed 的星号标在 0.9.2 上）。
#
# 这是全项目统一的版本排序入口——别在调用处再手写比较器，
# 否则容易有的地方 semver、有的地方字典序，显示与取最高版本就会不一致。
method sort-versions(@versions --> List) {
    # .defined 不能省：账本里偶尔会混进未定义值，直接 .chars 会刷一屏警告
    @versions.grep({ .defined && .chars }).unique
        .sort({ RakuPM::Version.from-string($^a).cmp(RakuPM::Version.from-string($^b)) })
        .List
}
