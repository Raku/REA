use Test;
use lib 'lib';
use RakuPM::Author;
use RakuPM::Fs;
use JSON::Fast;

# 真跑一遍命令行超长的发行版：预检必须拦住（而不是让 Windows run() 返回 -16
# 再误报「tar 未找到」），加 .distignore 排除后又能正常打包且不含临时文件。
# 800 个长名文件 ≈ 50KB 参数，稳超 32767；文件数比实测现场的 3592 个少，
# 但足够触线，跑起来也快。

%*ENV<RAKUPM_AUTHOR_AUTH> = 'github:tester';

plan 4;

my $tmp = ($*TMPDIR // '/tmp'.IO).add("rakupm-cmdline-{$*PID}");
mkdir-p($tmp);
LEAVE { try rm-tree($tmp) if $tmp.e }

my $d = $tmp.add('Big-Dist');
mkdir-p($d);
my %meta = %(
    name => 'Cmdline::Big', version => '0.1.0', auth => 'github:tester',
    api => '1', description => 'cmdline limit probe', authors => ['tester'],
    license => 'Artistic-2.0', raku => '6.d',
    provides => { 'Cmdline::Big' => 'lib/Cmdline/Big.rakumod' },
    depends => %( runtime => %( requires => [] ) ),
    test-depends => ['Test'],
);
$d.add('META6.json').spurt(to-json(%meta, :sorted-keys));
my $mod = $d.add('lib/Cmdline/Big.rakumod');
mkdir-p($mod.parent);
$mod.spurt("unit module Cmdline::Big;\n");
my $tf = $d.add('t/01-basic.rakutest');
mkdir-p($tf.parent);
$tf.spurt("use Test; use-ok 'Cmdline::Big'; done-testing;\n");
$d.add('Changes').spurt("# Changes\n\n## 0.1.0\n\n- init\n");

for 1..800 -> $i {
    my $f = $d.add("tmp/big/d{$i}/" ~ ('a' x 40) ~ '.txt');
    mkdir-p($f.parent);
    $f.spurt('x');
}

dies-ok { RakuPM::Author.dist($d, :to($tmp.absolute.Str), :no-build, :quiet(True)) },
        '命令行超限时 dist 拒绝打包（不再 spawn 一个必失败的长命令行）';
nok $tmp.dir.grep({ .basename.ends-with('.tar.gz') }).elems,
    '失败后没有留下半截归档';

$d.add('.distignore').spurt("tmp/\n");
my $r = RakuPM::Author.dist($d, :to($tmp.absolute.Str), :no-build, :quiet(True));
ok $r<ok>, '排除 tmp/ 后打包成功';

my @members = RakuPM::Author.tar-archive-list($r<file>.IO);
ok @members.elems > 0 && !@members.grep({ .starts-with('tmp/') }),
   '归档里没有 tmp/ 残骸';
