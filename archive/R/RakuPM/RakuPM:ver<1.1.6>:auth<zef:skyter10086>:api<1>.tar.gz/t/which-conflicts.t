use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client::Query;

# `raku-pm which`（不带参数 = 冲突总览）曾在本机 WSL 上抛
# "No such method 'key' for string '1'"：格式化 per 时用了
# `%per.kv.sort({ .key })`，而 Hash.kv 是扁平列表、不是 Pair 列表。
# 1.1.5 把格式化抽成公开方法 conflict-parts，在这里锁住行为。
# 用匿名类消费 role 即可单测其公开方法，无需构造完整 Client。

plan 5;

my $q = (class QueryProbe does RakuPM::Client::Query {}).new;

is-deeply $q.conflict-parts({}),
          [], '空 per 返回空数组';

is-deeply $q.conflict-parts({ 0 => '1.1.4' }),
          ['[0]=1.1.4'], '单仓库只有一个片段';

is-deeply $q.conflict-parts({ 2 => '1.0', 0 => '1.1.4' }),
          ['[0]=1.1.4', '[2]=1.0'], '按仓库序号升序（与 Hash 插入顺序无关）';

is-deeply $q.conflict-parts({ 10 => '2.0', 2 => '1.0', 0 => '1.1.4' }),
          ['[0]=1.1.4', '[2]=1.0', '[10]=2.0'],
          '序号按数值排序，[10] 不会排到 [2] 前面';

# 真跑一遍 CLI：有跨仓库重名发行版时会走 !which-conflicts；没有时也应正常退出。
# 只断言退出码与「不再抛 .key 异常」，不依赖本机一定存在冲突。
my $root = $*PROGRAM.parent.parent.absolute.IO;  # .absolute 返回 Str，要 .IO 才能 .add
my $cli  = $root.add('bin/raku-pm.raku').Str;
my $p    = run($*EXECUTABLE.Str, "-I{$root.add('lib')}", $cli, 'which', :out, :err);
my $out  = $p.out.slurp(:close);
my $err  = $p.err.slurp(:close);
is $p.exitcode, 0, 'raku-pm which 真跑不崩'
    or diag "STDOUT:/n$out/nSTDERR:/n$err";
