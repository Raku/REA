use Test;
use lib 'lib';
use RakuPM::Author;

# 1.1.6：dist 打包前的命令行长度预检与诊断（纯函数层）。
# 真跑层（800 个长名文件 → 被拦 → 加 .distignore → 成功）在 xt/dist-cmdline.t。
# 两层都要有：文本层锁死诊断文案，真跑层保证 !tar-gz 真的会拦、也真的能恢复。

plan 10;

my @small = ('tar', '-czf', 'out.tar.gz', '-C', '/tmp/pkg',
             'META6.json', 'lib/Foo.rakumod');
my @files = (1..800).map({ "tmp/big/d{$_}/" ~ ('a' x 40) ~ '.txt' });
my @big   = (|@small, |@files);

my $small-len = RakuPM::Author.estimate-cmdline(@small);
my $big-len   = RakuPM::Author.estimate-cmdline(@big);
ok $small-len > 0 && $small-len < 1000, "少量参数长度合理（{$small-len}）";
ok $big-len > 32767, "800 个长名文件超过 32767（{$big-len}）";
is RakuPM::Author.tar-cmdline-diagnostic(@small), '', '未超限返回空串';

my $diag = RakuPM::Author.tar-cmdline-diagnostic(@big, :files(@files));
like $diag, /'命令行过长'/, '诊断说明是命令行过长';
like $diag, /'32767'/, '诊断带上上限数值';
like $diag, /'.distignore'/, '诊断给出 .distignore 建议';
ok $diag.contains('tmp/'), '诊断列出占用最多的顶层目录';
like $diag, /'.gitignore'/, '提醒 dist 不读 .gitignore';
nok $diag.contains('tar 未找到'), '不再误报成 tar 未安装';
isnt RakuPM::Author.tar-cmdline-diagnostic(@small, :limit(20)), '',
     '可注入小 limit 触发诊断（便于跨平台单测）';
