use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::NativeLib;

# 回归：normalize 必须把「同一逻辑库的多平台候选」归并成一个逻辑名，并丢弃别的
# 平台的候选。否则 raku-pm 自装时（自身 MD5 声明了一组 libcrypto 多平台候选）
# 会把 libcrypto.dylib / libcrypto.3.dylib / libcrypto-3-x64.dll / libcrypto.so.1.1
# 全判成「缺失」而放弃安装 —— 其实这些候选是「任一存在即满足」的 OR 关系。
#
# 用 NativeLib.new(:os<...>) 强制平台，让三条平台分支在同一台机器上都被覆盖
# （os-key 尊重 $.os，绕过本机真实 $*DISTRO）。

plan 8;

# ---- Linux：crypto 多平台候选应归并成 'crypto'，且非 Linux 候选被丢弃 ----
{
    my $nl = RakuPM::NativeLib.new(:os<linux>);
    my @raw = <libcrypto libcrypto.so libcrypto.so.3 libcrypto.so.1.1
               libcrypto.dylib libcrypto.3.dylib libcrypto-3-x64.dll>;
    my @got = $nl.normalize(@raw);
    is @got.sort.join(','), 'crypto',
       'Linux：crypto 多平台候选归并为单一逻辑名 crypto';
    nok @got.grep({ $_ ~~ /\.dylib/ || $_ ~~ /\.dll/ }),
       'Linux：macOS/Windows 候选被丢弃';
}

# ---- macOS：同样归并为 crypto，且 .so / .dll 候选被丢弃 ----
{
    my $nl = RakuPM::NativeLib.new(:os<darwin>);
    my @raw = <libcrypto libcrypto.so libcrypto.so.3 libcrypto.so.1.1
               libcrypto.dylib libcrypto.3.dylib libcrypto-3-x64.dll>;
    my @got = $nl.normalize(@raw);
    is @got.sort.join(','), 'crypto',
       'macOS：crypto 多平台候选归并为单一逻辑名 crypto';
    nok @got.grep({ $_ ~~ /\.so/ || $_ ~~ /\.dll/ }),
       'macOS：Linux/Windows 候选被丢弃';
}

# ---- Windows：同样归并为 crypto，且 .so / .dylib 候选被丢弃 ----
{
    my $nl = RakuPM::NativeLib.new(:os<win32>);
    my @raw = <libcrypto libcrypto.so libcrypto.so.3 libcrypto.so.1.1
               libcrypto.dylib libcrypto.3.dylib libcrypto-3-x64.dll>;
    my @got = $nl.normalize(@raw);
    is @got.sort.join(','), 'crypto',
       'Windows：crypto 多平台候选归并为单一逻辑名 crypto';
    nok @got.grep({ $_ ~~ /\.so/ || $_ ~~ /\.dylib/ }),
       'Windows：Linux/macOS 候选被丢弃';
}

# ---- 未知库、无扩展名：原样保留（走通用命名规则，不误并）----
{
    my $nl = RakuPM::NativeLib.new(:os<linux>);
    my @raw = <duckdb zzz-rakupm-absent-lib>;
    my @got = $nl.normalize(@raw);
    is @got.sort.join(','), 'duckdb,zzz-rakupm-absent-lib',
       '未知/无扩展名库原样保留，不被误并';
}

# ---- 单库单平台声明：保持原样（Duckie 的 is native('duckdb') 不被改动）----
{
    my $nl = RakuPM::NativeLib.new(:os<linux>);
    my @single = <duckdb>;
    my @got = $nl.normalize(@single);
    is @got.sort.join(','), 'duckdb',
       '单一平台无关库名保持不变';
}
