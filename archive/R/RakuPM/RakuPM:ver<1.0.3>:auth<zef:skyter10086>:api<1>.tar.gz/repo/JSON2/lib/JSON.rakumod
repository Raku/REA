unit module JSON;

sub encode($data --> Str) is export {
    "JSON-v2-encoded"
}
