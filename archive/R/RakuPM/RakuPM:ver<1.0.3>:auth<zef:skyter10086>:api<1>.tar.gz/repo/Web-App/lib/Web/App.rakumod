unit module Web::App;

sub serve(--> Str) is export {
    "Web app serving on :8080"
}
