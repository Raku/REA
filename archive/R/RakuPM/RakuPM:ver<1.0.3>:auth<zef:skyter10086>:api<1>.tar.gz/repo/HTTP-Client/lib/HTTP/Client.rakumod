unit module HTTP::Client;

sub get(Str $url --> Str) is export {
    "GET $url -> 200 OK"
}
