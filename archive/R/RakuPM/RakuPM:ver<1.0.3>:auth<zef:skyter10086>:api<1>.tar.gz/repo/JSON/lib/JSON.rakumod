unit module JSON;

sub encode(%data --> Str) is export {
    "JSON-encoded({%data.keys.join(',')})"
}
