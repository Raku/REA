# Quick start

[English](../README.md) · [Architecture & deep dive](./architecture.en.md)

Get raku-pm running and install + load your first package in about 5 minutes.

## 1. Get raku-pm

Recommended: run from source (skip zef, no global writes):

```bash
git clone https://gitee.com/skyter10086/raku-pm.git
cd raku-pm
raku bin/raku-pm.raku --help      # prints help => environment is OK
```

> Want a global command instead? `zef install .` (then `raku-pm` is on PATH). Below we use the source form; both entry points behave identically.

## 2. Set two environment variables

```bash
export RAKUPM_REPO=repo              # repo dir (indexes + local repos live here)
export RAKUPM_TARGET=$HOME/.raku-pm  # install target: store/ + site/ + lockfile
```

Both directories are created automatically on first run.

## 3. Install a real-world package

```bash
raku bin/raku-pm.raku install File::Temp
```

Sample output (real run; version numbers shift as the ecosystem updates):

```
将安装 2 个发行版（自底向上，依赖优先）：
  · File::Directory::Tree:ver<0.2>:auth<zef:raku-community-modules>
  · File::Temp:ver<0.0.12>:auth<zef:raku-community-modules>
==> 下载源码包 [zef]：https://360.zef.pm/F/IL/FILE_DIRECTORY_TREE/8f155b8a....tar.gz
==> 存入存储：File::Directory::Tree 0.2 (24be1140)
  · 运行测试：File::Directory::Tree 0.2
    ✓ 01-basic.rakutest
==> 已激活 File::Directory::Tree 0.2
==> 下载源码包 [zef]：https://360.zef.pm/F/IL/FILE_TEMP/9e97bc86....tar.gz
==> 存入存储：File::Temp 0.0.12 (3ad733c0)
  · 运行测试：File::Temp 0.0.12
    ✓ 01-basic.rakutest
    ✓ 02-gc.rakutest
    ✓ 03-tempfile.rakutest
==> 已激活 File::Temp 0.0.12
✓ 完成。
```

Dependencies are installed bottom-up — the ones depended on go first, the target last. That ordering is the heart of a package manager.

## 4. Use it

```bash
export RAKULIB="inst#$HOME/.raku-pm/site"
raku -e 'use File::Temp; say "loaded File::Temp OK"'
```

If it prints `loaded File::Temp OK`, the package is installed and loadable. Pick an exact version with `use File::Temp:ver<0.0.12>`.

## Next steps

- More commands (`search` / `installed` / `upgrade` / `uninstall` / `repos`): see "Quick start" in [../README.md](../README.md).
- Architecture, atomic install, lockfile, generation rollback, mapping onto zef: see [./architecture.en.md](./architecture.en.md).
