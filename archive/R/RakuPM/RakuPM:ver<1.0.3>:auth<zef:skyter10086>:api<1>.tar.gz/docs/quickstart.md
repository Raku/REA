# 快速上手

[中文](../README.md) · [架构与深度设计](./architecture.md)

5 分钟把 raku-pm 跑起来，装好第一个包，并用 `use` 加载它。

## 1. 拿到 raku-pm

推荐直接跑源码（不用 zef 装，省去全局写入）：

```bash
git clone https://gitee.com/skyter10086/raku-pm.git
cd raku-pm
raku bin/raku-pm.raku --help      # 能看到帮助即说明环境 OK
```

> 想装成全局命令也行：`zef install .`（装完有 `raku-pm` 入口）。下文统一用「源码跑法」，两种入口行为完全一致。

## 2. 设两个环境变量

```bash
export RAKUPM_REPO=repo              # 仓库目录（索引与本地仓库放这）
export RAKUPM_TARGET=$HOME/.raku-pm # 安装目标：store/ + site/ + 锁文件
```

第一次跑会自动建好这两个目录。

## 3. 装一个真实世界的包

```bash
raku bin/raku-pm.raku install File::Temp
```

示例输出（来自真实运行；版本号会随生态更新而变化）：

```
将安装 2 个发行版（自底向上，依赖优先）：
  · File::Directory::Tree:ver<0.2>:auth<zef:raku-community-modules>
  · File::Temp:ver<0.0.12>:auth<zef:raku-community-modules>
==> 下载源码包 [zef]：https://360.zef.pm/F/IL/FILE_DIRECTORY_TREE/8f155b8a....tar.gz
==> 存入存储：File::Directory::Tree 0.2 (24be1140)
  · 运行测试：File::Directory::Tree 0.2
    ✓ 01-basic.rakutest
==> 已激活 File::Directory::Tree 0.2
==> 下载源码包 [zef]：https://360.zef.pm/F/IL/FILE_TEMP/9e97bc86....tar.gz
==> 存入存储：File::Temp 0.0.12 (3ad733c0)
  · 运行测试：File::Temp 0.0.12
    ✓ 01-basic.rakutest
    ✓ 02-gc.rakutest
    ✓ 03-tempfile.rakutest
==> 已激活 File::Temp 0.0.12
✓ 完成。
```

装的是依赖树里「被依赖的先装、最后装目标包」—— 这正是包管理器的核心顺序。

## 4. 用起来

把安装目标加进模块搜索路径，然后 `use` 加载：

```bash
export RAKULIB="inst#$HOME/.raku-pm/site"
raku -e 'use File::Temp; say "loaded File::Temp OK"'
```

打印出 `loaded File::Temp OK` 就说明装好也能加载了。要精确选版本：`use File::Temp:ver<0.0.12>`。

## 下一步

- 更多命令（`search` / `installed` / `upgrade` / `uninstall` / `repos`）：见 [../README.md](../README.md) 的「快速开始」。
- 想了解架构、原子安装、锁文件、世代回滚、与 zef 的对应关系：见 [./architecture.md](./architecture.md)。
