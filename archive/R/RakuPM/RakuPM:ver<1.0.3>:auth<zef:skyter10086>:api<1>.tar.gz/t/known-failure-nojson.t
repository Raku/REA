# 回归测试：known-windows-test-failures.json 缺失时，内置兜底规则仍生效
# （0.64.3 修复：该 .json 不在 META6 provides，安装到 site 后不存在；
#  self-upgrade 从 site 加载 Tester 时文件缺失会让规则集被掏空，
#  导致 Windows 上 is-known-windows-test-failure 误返 False → 安装回滚）
#
# 这里用 RAKUPM_KNOWN_FAILURES_JSON 指向不存在的路径，模拟「文件缺失」，
# 并强制 $*DISTRO 为 win32，断言内置规则仍能把 Log::Async 12-context 识别为已知失败。

BEGIN %*ENV<RAKUPM_KNOWN_FAILURES_JSON> = '/nonexistent/known-windows-test-failures.json';

use RakuPM::Client::Tester;
use RakuPM::Platform;
use Test;

my $*DISTRO = Distro.new(:name('win32'));   # 模拟原生 Windows

my $la-output = q:to/OUT/;
# expected: $["file t\12-context.rakutest, line 18, message yàsu"]
#      got: $["file C:\\Users\\user\\.raku-pm\\cache\\dist\\zef\\Log-Async\\0.0.17\\Log-Async-0.0.17\\lib\\Log\\Async.rakumod (Log::Async), line 81, message yàsu"]
OUT

is is-known-windows-test-failure('Log::Async', '12-context.rakutest', $la-output),
   True,
   'JSON 缺失时，内置兜底规则仍识别 Log::Async 12-context（Windows）';

is is-known-windows-test-failure('Foo::Bar', '12-context.rakutest', $la-output),
   False,
   'JSON 缺失时，非 Log::Async 包仍不识别';

done-testing;
