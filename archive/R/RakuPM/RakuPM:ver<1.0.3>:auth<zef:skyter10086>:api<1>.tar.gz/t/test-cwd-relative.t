use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 回归：测试文件必须以【相对路径】调用（zef 语义：cd 发行版根目录 + raku t/foo.rakutest）。
# 上游测试会把 $?FILE / callframe 的 file 写进断言（实测 Log::Async 0.0.17 的
# 12-context.rakutest 期望 "file t/12-context.rakutest, line 18"）；传绝对路径
# 这类用例必挂且重试无效。
#
# 两层验证：
#   1. 命令层（跨平台，硬契约）：test-invocation-rel-path 对 t/ 下的文件必须算出
#      `t/xxx` 形态 —— 这是真正的契约，哪都能验；
#   2. 集成层：夹具包的测试把 $?FILE 记进 marker，断言它【以 t/01-rel.rakutest
#      结尾】。Linux 的 rakudo 是真实二进制会保持相对（精确等于，强校验）；
#      Windows 的 rakudo 是 .bat 包装器会把 $?FILE 绝对化，但后缀一致，
#      故两平台都不假死 —— 同时仍真实验证「以相对路径 t/... 调用」。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-relpath-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $marker = $tmp.add('file.marker');
$marker.spurt('');

my $src = $tmp.add('relsrc').mkdir;
$src.add('lib').mkdir;
$src.add('lib').add('RelProbe.rakumod').spurt('unit module RelProbe;');
$src.add('META6.json').spurt(to-json({
    name => 'RelProbe', version => '0.1.0', auth => 'demo',
    provides => { RelProbe => 'lib/RelProbe.rakumod' }, depends => {},
}, :sorted-keys));

# marker 路径写死进测试文件 —— Windows 反斜杠在双引号字符串里是转义序列，
# 统一换正斜杠（两边的 IO 层都认），同 skip-installed.t。
# 夹具正文用 q:to（不内插）+ 占位符替换，避免转义地狱；
# 断言用 is-absolute 取反 —— 完全不含反斜杠（q:to 里 '\\\\' 会被折叠，
# 单引号串里 '\' 反而变成转义引号，都是坑）。
my $marker-fwd = $marker.absolute.comb
    .map({ $_ eq "\x5C" ?? '/' !! $_ }).join('');
my $body = q:to/END/;
    use Test;
    plan 1;
    'MARKER'.IO.open(:a).put: $?FILE;
    # 跨平台断言：无论 $?FILE 被规范化成绝对还是保持相对，只要它以
    # `t/01-rel.rakutest` 结尾，就证明 raku-pm 是在发行版根目录下用相对
    # 路径 `t/01-rel.rakutest` 调用了它（zef 语义）。Linux 的 rakudo 是真实
    # 二进制会保持相对（精确等于），Windows 的 rakudo 是 .bat 包装器会
    # 绝对化，但后缀一致，故两平台都不假死。
    my $f = $?FILE.comb.map({ $_ eq "\x5C" ?? '/' !! $_ }).join('');
    ok $f.ends-with('t/01-rel.rakutest'),
       "test invoked as relative t/ path under dist root: $?FILE";
    END
$src.add('t').mkdir;
$src.add('t').add('01-rel.rakutest').spurt($body.subst('MARKER', $marker-fwd));

my $client = RakuPM::Client.new(
    :target($tmp.add('target')),
    :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]),
);

sub fwd($s) { $s.comb.map({ $_ eq "\x5C" ?? '/' !! $_ }).join('') }

plan 3;

# 1) 命令层：调用路径必须是 t/ 相对形态（zef 语义）
is fwd($client.test-invocation-rel-path($src.add('t').add('01-rel.rakutest'), $src)),
   't/01-rel.rakutest',
   '测试文件的调用路径按 zef 语义计算为 t/ 相对形式';

# 2) 集成：安装（含跑测试）不炸
lives-ok { $client.install-from-dir($src, :no-build) },
    '夹具测试记录 $?FILE 并断言调用形态 → 安装不炸';

# 3) marker：测试确实跑了，且记录的路径以 t/01-rel.rakutest 结尾（zef 语义）
my $recorded = $marker.lines.elems ?? $marker.lines[0].trim !! '';
ok fwd($recorded).ends-with('t/01-rel.rakutest'),
   "marker 记录路径以 t/01-rel.rakutest 结尾（zef 语义的相对调用），实际：{$recorded || '(空)'}";
