use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Installer::ShellTemplates;

# 自装 wrapper 必须【保留】用户已有的 RAKULIB（追加，而不是整条替换）。
#
# 背景（用户现场）：用户机器上 RAKULIB 指向自己的模块开发目录（一个 FileSystem
# 仓库）。旧 wrapper 直接 `export RAKULIB="inst#<target>/site"` —— 整条替换，
# 于是 raku-pm 会话里用户自己的那些模块**突然看不见了**，而用户无从察觉。
# 现在三个平台模板统一为：先存原值 → 设 raku-pm 的 site（排最前，保住
# 「raku-pm 装的包优先」）→ 原值非空则追加在后面。
#
# 这里只断言生成文本（快、无环境依赖）；「真的执行一遍」在 xt/wrapper-rakulib-run.t。

plan 12;

my $site = 'C:/tgt/site';
my $bash = bash-wrapper-body('C:/tgt', 'C:/tgt/store/RakuPM', $site, 'C:/rakudo/bin/raku.exe',
                             'C:/tgt/store/RakuPM/9.9.9/bin/raku-pm.raku');
my $bat  = win-bat-body('9.9.9', 'C:/tgt', $site, 'C:/rakudo/bin/raku.exe',
                        'C:/tgt/store/RakuPM/9.9.9/bin/raku-pm.raku');
my $ps1  = win-ps1-body('9.9.9', 'C:/tgt', $site, 'C:/rakudo/bin/raku.exe',
                        'C:/tgt/store/RakuPM/9.9.9/bin/raku-pm.raku');

# --- bash ---
ok $bash.contains("RAKUPM_PREV_LIB=\"\$RAKULIB\""), 'bash：先把用户已有的 RAKULIB 存起来';
ok $bash.contains("export RAKULIB=\"inst#{$site}\""), 'bash：先设成 raku-pm 的 site（保持优先）';
ok $bash.contains("if [ -n \"\$RAKUPM_PREV_LIB\" ]"), 'bash：原值非空才追加';
ok $bash.contains("export RAKULIB=\"inst#{$site},\$RAKUPM_PREV_LIB\""),
   'bash：原值被追加在 site 之后';

# --- bat ---
ok $bat.contains('set "RAKUPM_PREV_LIB=%RAKULIB%"'), 'bat：先存原值';
ok $bat.contains('if defined RAKUPM_PREV_LIB'), 'bat：原值非空才追加';

# --- ps1 ---
ok $ps1.contains('$env:RAKUPM_PREV_LIB = $env:RAKULIB'), 'ps1：先存原值';
ok $ps1.contains('if ($env:RAKUPM_PREV_LIB)'), 'ps1：原值非空才追加';

# --- 三段都要把前缀显式传给 CLI（0.49.0）---
# 这是「前缀自洽」的另一半：RAKULIB 指向自己那份 site，CLI 也必须知道自己该动
# 哪个前缀。缺了它，自定义前缀下命令装进 A、模块却从 B 找（已实测确认）。
ok $bash.contains(q{'--target=C:/tgt'}), 'bash：显式传前缀（wrapper 属于哪个前缀就动哪个）';
ok $bat.contains('"--target=C:/tgt"'),  'bat：显式传前缀';
ok $ps1.contains(q{'--target=C:/tgt'}), 'ps1：显式传前缀';

# 顺序不变式：raku-pm 的 site 必须仍在最前（否则「raku-pm 装的包优先于 zef 的」
# 这条设计就失效了 —— 见 README 的仓库解析说明）。
{
    my $line = $bash.lines.first({ .contains('inst#') && .contains('RAKUPM_PREV_LIB') });
    my $i-site = $line.defined ?? $line.index("inst#{$site}") !! Nil;
    my $i-prev = $line.defined ?? $line.index('$RAKUPM_PREV_LIB') !! Nil;
    ok $i-site.defined && $i-prev.defined && $i-site < $i-prev,
       'bash：拼接顺序 = 「raku-pm 的 site 在前、用户的仓库在后」';
}
