use lib 'lib';
use Test;
use RakuPM::Distribution;

# 守护：Distribution 的字段【一个都不能漏传】。
#
# 背景（本项目最高产的缺陷模式）：Distribution 的字段随能力演进不断增加
# （resources → git-deps → builder → build-depends → test-depends → native-libs），
# 而此前有 3 处代码在「手工挑字段重建 Distribution」。每加一个字段，那 3 处
# 就各漏一次，实际造成过：
#   · 漏 resources     → %?RESOURCES 取不到 → 模块 .open 即崩（Data::Generators）
#   · 漏 git-deps      → 裸 git URL 依赖在链上消失（Draku）
#   · 漏 builder       → 构建阶段被整个跳过 → native 库没编出来（GDBM，120 个包受影响）
#   · 漏 build-depends → 构建依赖不装 → builder 类 use 不到
#   · 漏 test-depends  → 测试依赖不装 → use Test::META 崩
#
# 现在字段派生只走 Distribution.clone-with()（克隆）与 from-index-row()（索引行）。
# 本测试用两条互补的守护：
#   ① 反射式：遍历 Distribution 的【全部属性】，断言 clone-with 逐个保留。
#      → 以后新增属性却忘了加进 clone-with，这里立刻红（不需要维护白名单）。
#   ② 端到端式：构造一条「每个字段都有值」的索引行，断言 from-index-row 全部解析出来。
#      → 以后新增字段却忘了在 from-index-row 里归一，这里立刻红。

# 列表比较用统一形态：两边都 .List.raku，避免 Array/List/Seq 的 raku 形态差异
# （`("a",)` vs `["a"]` vs `("a",).Seq`）造成假失败。
sub rl($v) { $v.List.raku }

# ============ ① 反射式守护：clone-with 必须保留每一个属性 ============
{
    my $full = RakuPM::Distribution.new(
        :name('Full::Dist'),
        :version('1.2.3'),
        :auth('zef:someone'),
        :description('a full distribution'),
        :provides(['Full::Dist', 'Full::Dist::Helper']),
        :depends({ 'Dep::One' => '1+', 'Dep::Two' => '>=2.0' }),
        :native-libs(['sqlite3', 'ssl']),
        :external-deps(['dot', 'node']),
        :git-deps(['git://example.com/a.git']),
        :resources(['data.csv', 'libraries/libfoo']),
        :builder('Distribution::Builder::MakeFromJSON'),
        :build-depends({ 'Builder::X' => '2+' }),
        :test-depends({ 'Test::META' => '*' }),
    );

    # 前置：确认守护关心的属性真的都在属性表里（否则下面的循环会「空转通过」）
    my @attrs = RakuPM::Distribution.^attributes.map({ .name.substr(2) }).sort;
    ok @attrs.elems >= 13, "Distribution 至少 13 个属性（实得 {@attrs.elems}）";
    ok (@attrs.grep(* eq 'resources')).elems == 1,    '属性表含 resources（守护有实义）';
    ok (@attrs.grep(* eq 'builder')).elems == 1,      '属性表含 builder（守护有实义）';
    ok (@attrs.grep(* eq 'test-depends')).elems == 1, '属性表含 test-depends（守护有实义）';
    ok (@attrs.grep(* eq 'native-libs')).elems == 1,  '属性表含 native-libs（守护有实义）';

    my $copy = $full.clone-with();

    # 逐个属性比对：新增属性若没同步进 clone-with，这里会以「空值 vs 有值」失败
    for @attrs -> $n {
        is $copy."$n"().raku, $full."$n"().raku, "clone-with 原样保留 $n";
    }

    # 覆盖：clone-with 带参时只改指定的项，且不污染原对象
    my $renamed = $full.clone-with(:version('9.9.9'), :auth('git:host'));
    is $renamed.version, '9.9.9', 'clone-with 覆盖 version';
    is $renamed.auth, 'git:host', 'clone-with 覆盖 auth';
    is $full.version, '1.2.3', 'clone-with 不原地修改原对象（version）';
    is $renamed.build-depends.raku, $full.build-depends.raku,
       'clone-with 覆盖部分字段时其余字段仍完整保留';
    is $renamed.resources.List.raku, $full.resources.List.raku,
       'clone-with 覆盖部分字段时 resources 仍完整保留';
}

# ============ ② 端到端：from-index-row 必须解析出每一个字段 ============
{
    my %row =
        name        => 'Idx::Full',
        version     => '2.0',
        auth        => 'zef:idx',
        description => 'index row demo',
        provides    => { 'Idx::Full' => 'lib/Idx/Full.rakumod',
                        'Idx::Full::Sub' => 'lib/Idx/Full/Sub.rakumod' },
        depends     => { runtime => { requires => [
                            'Dep::One:ver<1+>',
                            'zzz-sqlite:from<native>',
                            'zzz-dot:from<bin>',
                            'git://example.com/idxdep.git',
                        ] } },
        resources       => ['data.csv', 'libraries/libidx'],
        builder         => 'Distribution::Builder::MakeFromJSON',
        'build-depends' => ['Builder::X:ver<2+>'],
        'test-depends'  => ['Test::META'],
    ;

    my $d = RakuPM::Distribution.from-index-row(%row);

    is $d.name, 'Idx::Full', 'from-index-row：name';
    is $d.version, '2.0', 'from-index-row：version';
    is $d.auth, 'zef:idx', 'from-index-row：auth（顶层优先）';
    is $d.description, 'index row demo', 'from-index-row：description';
    is $d.provides.elems, 2, 'from-index-row：provides（Hash 形态取键）';
    is rl($d.depends.keys.sort), rl(['Dep::One']),
       'from-index-row：depends 只含 Raku 依赖';
    is $d.depends<Dep::One>, '1+', 'from-index-row：depends 约束值';
    is rl($d.native-libs), rl(['zzz-sqlite']),
       'from-index-row：native-libs（从 :from<native> 提取）';
    is rl($d.external-deps), rl(['zzz-dot']),
       'from-index-row：external-deps（从 :from<bin> 提取）';
    is rl($d.git-deps), rl(['git://example.com/idxdep.git']),
       'from-index-row：git-deps（裸 URL 提取）';
    is rl($d.resources.sort), rl(['data.csv', 'libraries/libidx']),
       'from-index-row：resources';
    is $d.builder, 'Distribution::Builder::MakeFromJSON',
       'from-index-row：builder（漏了构建会被整个跳过）';
    is rl($d.build-depends.keys.sort), rl(['Builder::X']),
       'from-index-row：build-depends';
    is rl($d.test-depends.keys.sort), rl(['Test::META']),
       'from-index-row：test-depends';
}

# ============ auth 兜底：REA 等索引把身份写在 dist 串里 ============
{
    my $d = RakuPM::Distribution.from-index-row(
        %( name => 'X', version => '1', dist => 'X:ver<1>:auth<github:timo>' ));
    is $d.auth, 'github:timo', 'from-index-row：顶层无 auth 时从 dist 串兜底';

    my $u = RakuPM::Distribution.from-index-row(%( name => 'Y', version => '1' ));
    is $u.auth, 'unknown', 'from-index-row：都取不到时给 unknown';
}

done-testing;
