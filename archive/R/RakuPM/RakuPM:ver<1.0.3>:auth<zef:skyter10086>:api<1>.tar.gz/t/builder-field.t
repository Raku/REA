use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use JSON::Fast;

# builder / build-depends 字段的传递（GDBM 现场回归）
#
# 背景：360.zef.pm 索引里 GDBM 写着
#     "builder": "Distribution::Builder::MakeFromJSON"
# 但 RakuPM::Repository::Ecosystem.fetch-distribution 是【手工挑字段】构造
# Distribution 的，漏传了 builder → Builder.needs-build 恒为假 → 构建阶段被
# 整个跳过 → native 库 resources/libraries/libgdbmhelper.so 根本没被编出来 →
# 测试期 %?RESOURCES<libraries/gdbmhelper> 回退成 resources 目录，NativeCall
# 去找 <CUR>/libresources.so 而崩（"Cannot locate native library .../libresources.so"）。
# 索引里 120 个包声明了 builder，全都受影响，不只是 GDBM。
#
# 同源的第二个坑：GDBM 把构建依赖写作 depends.build.requires（而非顶层
# build-depends），且索引行还会把 build-depends 显式写成【空数组】——
# 两种形态都必须能取到，否则构建前不会去装 MakeFromJSON，构建照样失败。

my $tmp = $*TMPDIR.add('rakupm-builder-field-test');
$tmp.mkdir;

sub write-meta(Str $name, %meta --> IO::Path) {
    my $p = $tmp.add("$name.json");
    $p.spurt(to-json(%meta));
    $p
}

# ---- 1) GDBM 同款：builder + 构建依赖写在 depends.build.requires ----
my $gdbm-like = write-meta('gdbm-like', {
    name      => 'GDBMLike',
    version   => '0.1.4',
    auth      => 'zef:someone',
    provides  => { 'GDBMLike' => 'lib/GDBMLike.rakumod' },
    resources => ['libraries/gdbmhelper'],
    builder   => 'Distribution::Builder::MakeFromJSON',
    depends   => {
        build   => { requires => ['Distribution::Builder::MakeFromJSON:ver<0.6+>'] },
        runtime => { requires => ['gdbm:from<native>'] },
    },
});

my $d = RakuPM::Distribution.from-meta-file($gdbm-like);
is $d.builder, 'Distribution::Builder::MakeFromJSON',
   'META6 的 builder 字段被读进发行版对象';
my %bd1 = $d.build-depends;
ok %bd1{'Distribution::Builder::MakeFromJSON'}:exists,
   '构建依赖能从 depends.build.requires 取到（GDBM 的写法）';
is %bd1{'Distribution::Builder::MakeFromJSON'}, '0.6+',
   '构建依赖的版本约束被保留';
is $d.resources.elems, 1, 'resources 仍被读取';

# ---- 2) 索引行形态：build-depends 显式为空数组，真值在 depends.build ----
my %row = (
    name          => 'GDBM',
    version       => '0.1.3',
    builder       => 'Distribution::Builder::MakeFromJSON',
    build-depends => [],
    depends       => {
        build   => { requires => ['Distribution::Builder::MakeFromJSON:ver<0.6+>'] },
        runtime => { requires => ['gdbm:from<native>'] },
    },
);
my %bd2 = RakuPM::Distribution.build-depends-from(%row);
ok %bd2{'Distribution::Builder::MakeFromJSON'}:exists,
   '索引行 build-depends 为空数组时回退到 depends.build.requires';

# ---- 3) 顶层 build-depends（数组）仍要认，不能回归 ----
my %row2 = ( 'build-depends' => ['LibraryMake'] );
my %bd3 = RakuPM::Distribution.build-depends-from(%row2);
ok %bd3{'LibraryMake'}:exists,
   '顶层 build-depends 数组仍被识别（不回归）';

# ---- 4) 没有构建依赖时为空，且【不】把 runtime 依赖误当构建依赖 ----
my %row3 = ( depends => { runtime => { requires => ['Some::Runtime'] } } );
my %bd4 = RakuPM::Distribution.build-depends-from(%row3);
is %bd4.elems, 0,
   '只有 runtime 依赖时不产生构建依赖（不被误当成 build-depends）';

# ---- 5) 没声明 builder 的包不能被误判为「需要构建」 ----
my $plain = write-meta('plain', {
    name     => 'Plain',
    version  => '1.0',
    auth     => 'x:y',
    provides => { 'Plain' => 'lib/Plain.rakumod' },
});
is RakuPM::Distribution.from-meta-file($plain).builder, '',
   '未声明 builder 的包 builder 为空（needs-build 不会误触发）';

# ---- 6) depends 写成【数组】时不能炸（0.31.8 现场：Array 关联索引警告刷屏）----
# "depends": ["Foo","Bar"] 这种平铺数组写法在生态里很常见。
# 若不做 Hash 判断就写 %meta<depends><build>，会对 Array 做关联索引，
# 每次解析都刷一条 "Type Array does not support associative indexing"。
my %row4 = ( depends => ['Some::Runtime', 'Other'], 'build-depends' => [] );
my %bd5;
lives-ok { %bd5 = RakuPM::Distribution.build-depends-from(%row4) },
         'depends 为数组时不抛异常（不对 Array 做关联索引）';
is %bd5.elems, 0,
   'depends 为数组时不产生构建依赖';

done-testing;
