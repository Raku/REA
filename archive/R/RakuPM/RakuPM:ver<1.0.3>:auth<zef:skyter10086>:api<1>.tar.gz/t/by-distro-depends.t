use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;

# 平台条件依赖（zef 的 META6 扩展）：
#   "depends": [ { "name": { "by-distro.name": { "": "", "mswin32": "Win32::Registry" } } } ]
#
# 真实样本 File::Which 1.0.4（REA 与 cpan 索引都是这个形态）：只有 Windows 需要
# Win32::Registry，其它平台是空串。不认这个语法时，整块 Hash 会被当成模块名，
# Hash 字符串化后变成 "by-distro.name\t\t\nmswin32\tWin32::Registry"，于是
# Linux/WSL 上 `raku-pm install Digest::SHA1::Native` 会报
# “找不到模块 'by-distro.name / mswin32 Win32::Registry'”—— 装任何依赖它的包都失败。

sub deps(Str $json --> Hash) {
    RakuPM::Distribution.normalize-dependencies(from-json($json))
}

# File::Which 1.0.4 的真实 depends 字段
my $FW = q[ [ { "name": { "by-distro.name": { "": "", "mswin32": "Win32::Registry" } } } ] ];

# ---------- 1. 真实样本：按当前平台取舍 ----------
{
    my %h = deps($FW);
    if $*DISTRO.is-win {
        is %h.keys.sort.join(','), 'Win32::Registry', 'Windows 上取出 Win32::Registry';
    }
    else {
        is %h.elems, 0, '非 Windows 上这条依赖为空（不该去装 Win32::Registry）';
    }
}

# ---------- 2. 绝不能把 Hash 当模块名（回归防线） ----------
{
    my %h = deps($FW);
    my @bad = %h.keys.grep({ .contains("\n") || .contains("\t") });
    is @bad.elems, 0, '依赖表里没有含换行/制表符的畸形模块名';
}

# ---------- 3. 当前平台对应的键必须被选中 ----------
{
    my $cur = $*DISTRO.name.Str;
    my %h = deps(to-json([ %( name => %( 'by-distro.name' => %( $cur => 'Needs::This', '' => '' ) ) ) ]));
    is %h.keys.sort.join(','), 'Needs::This', '命中当前 $*DISTRO.name 的分支';
    is %h<Needs::This>, '*', '未指定版本时约束为 *';
}

# ---------- 4. 非目标平台（无兜底键）就是没有依赖 ----------
{
    my %h = deps(q[ [ { "name": { "by-distro.name": { "plan9": "Plan9::Only" } } } ] ]);
    is %h.elems, 0, '没有匹配平台且无兜底键 → 视为无依赖';
}

# ---------- 5. 顶层就写 by-distro.name 的形态 ----------
{
    my %h = deps(q[ { "by-distro.name": { "": "", "mswin32": ["Win32::Registry", "Foo::Bar:ver<1.0+>"] } } ]);
    if $*DISTRO.is-win {
        is %h.keys.sort.join(','), 'Foo::Bar,Win32::Registry', '顶层形态：取值可以是数组';
        is %h<Foo::Bar>, '1.0+', '顶层形态：版本约束被保留';
    }
    else {
        is %h.elems, 0, '顶层形态：非 Windows 上为空';
        is %h<Foo::Bar>, Any, '顶层形态：非 Windows 上不引入 Foo::Bar';
    }
}

# ---------- 6. 常规形态不能被这次改动破坏 ----------
{
    is deps(q[ ["MIME::Base64", "Foo::Bar:ver<1.0+>"] ]).keys.sort.join(','),
       'Foo::Bar,MIME::Base64', '纯数组依赖解析不变';
    is deps(q[ { "runtime": { "requires": ["AAA"] }, "build": { "requires": ["BBB"] } } ]).keys.join(','),
       'AAA', 'META6 分阶段依赖仍只取 runtime';
    is deps(q[ { "X::Y": "1.0" } ]).keys.join(','), 'X::Y', '平铺 Hash 依赖解析不变';
    is deps(q[ [ { "name": "libfoo", "from": "native" } ] ]).elems, 0, ':from<native> 仍不计入 raku 依赖';
}

# ---------- 7. 端到端：从 META6.json 文件解析 ----------
{
    my $tmp = $*TMPDIR.add('rakupm-bydistro-' ~ $*PID ~ '-' ~ now.floor).mkdir;
    LEAVE { try { .unlink } for $tmp.dir; try { $tmp.rmdir } }

    sub meta-with(Str $depends-json --> Hash) {
        my $dir = $tmp.add('src-' ~ $depends-json.chars ~ '-' ~ now.Int % 100000).mkdir;
        $dir.add('META6.json').spurt(to-json({
            name => 'ByDistro::Demo', version => '1.0', auth => 'demo',
            provides => { 'ByDistro::Demo' => 'lib/Demo.rakumod' },
            depends => from-json($depends-json),
        }, :sorted-keys));
        RakuPM::Distribution.from-meta6-file($dir.add('META6.json')).depends
    }

    my %plain = meta-with(q[ ["Always::Needed"] ]);
    is %plain.keys.join(','), 'Always::Needed', 'META6 文件：普通依赖照常解析';

    my %cond = meta-with($FW);
    if $*DISTRO.is-win {
        is %cond.keys.join(','), 'Win32::Registry', 'META6 文件：Windows 上带出条件依赖';
    }
    else {
        is %cond.elems, 0, 'META6 文件：非 Windows 上条件依赖不生效';
    }
}

done-testing;
