use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Prefix;
use RakuPM::Repository::Local;
use RakuPM::Platform;
use RakuPM::Fs;
use JSON::Fast;

# 前缀隔离（0.49.0）—— 「一个前缀就是一份独立包环境」这条承诺的三层守护。
#
# 背景：--target 早就存在，但它当时是**断的插座**（0.49.0 实测确认）：
#   ① 三份 wrapper 都不把前缀传给 CLI → CLI 回落到默认前缀（~/.raku-pm），
#      而 wrapper 设的 RAKULIB 指向自己那份 site：命令装进 A、模块却从 B 找；
#   ② promote-bin 无条件为真 → 自定义前缀也会往**全局 site/bin** 写 wrapper，
#      全局环境被局部安装污染（0.47.0 开发时自己的临时 target 就接管过一次）。
#
# 这里钉三层：
#   层1 CLI 策略   —— 自定义前缀不再默认动全局，并在会写前缀的命令上如实告知；
#   层2 Client 策略 —— promote-bin 未显式指定时按前缀自动决定，显式值可覆盖；
#   层3 行为事实   —— 真装一个带 bin 的发行版进临时前缀，断言**前缀外零写入**。
#
# 【层3 必须带正控】只断言「全局 site/bin 里没有」是**假绿高发区**：万一
# !install-bin 根本没跑（比如 META6 的 bin 字段没被识别），否定断言照样通过。
# 所以先断言「它确实落进了自己的前缀」，否则后面那句毫无意义。

plan 20;

my $root = $*TMPDIR.add("rakupm-prefix-iso-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }
mkdir-p($root);

# 空本地仓库：让 Client 不去读 repositories.json / 生态索引（测试必须离线）
my $empty-repo = $root.add('empty-repo');
mkdir-p($empty-repo);
# 注意用 *%extra 透传而不是 `:$promote-bin?`：`Bool` 是原生类型，属性【省略】是
# 「未指定」（自动策略生效），但显式传一个未定义的 Any 会直接类型检查失败
# （Type check failed in assignment to $!promote-bin; expected Bool but got Any）。
sub new-client(IO::Path $target, *%extra) {
    RakuPM::Client.new(:$target, :repos([RakuPM::Repository::Local.new(:root($empty-repo))]),
                       |%extra);
}

# ============ 层2：promote-bin 的默认由前缀决定 ============
{
    my $custom = new-client($root.add('tgt-default'));
    nok $custom.promote-bin,
        '自定义前缀：promote-bin 自动为假（不会往全局 site/bin 写）';
    ok $custom.installer.promote-bin ~~ Bool:D && !$custom.installer.promote-bin,
        '自定义前缀：这个判定真的传到了 Installer（不只是 Client 上的一个字段）';

    ok new-client($root.add('tgt-forced'), :promote-bin(True)).promote-bin,
        '显式 :promote-bin(True) 能覆盖自动判定（否则就没法回到 zef 行为）';

    nok new-client(default-target(), :promote-bin(False)).promote-bin,
        '默认前缀 + 显式关：同样尊重显式值（--no-promote-bin 那条路）';
}

# ============ 层1：CLI 的自定义前缀提示与旗标校验 ============
my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;

sub run-cli(*@args --> List) {
    my $p = run($raku, '-Ilib', $bin, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}
# 用一个默认【dry】的写命令（clean 不给 --yes 只试算）来验策略，避免测试落盘。
my $pfx = $root.add('pfx-cli');

{
    my ($c, $o, $e) = run-cli('clean', "--target={$pfx.absolute}");
    is $c, 0, '自定义前缀 + 写命令：正常执行（提示不阻断）';
    my $all = $o ~ $e;
    ok $all.contains('非默认'), '如实告知「前缀非默认」';
    ok $all.contains($pfx.add('bin').absolute.Str),
       '告知该把哪个 bin 目录放进 PATH（给的是前缀自己的，不是全局 site/bin）';
    ok $all.contains('--promote-bin'),
       '告知想回到 zef 行为该加什么旗标（不让人猜）';
}

{
    # 显式 --no-promote-bin：用户自己知道，不必再念一遍
    my ($c, $o, $e) = run-cli('clean', "--target={$pfx.absolute}", '--no-promote-bin');
    is $c, 0, '--no-promote-bin 被接受';
    nok ($o ~ $e).contains('非默认'),
        '用户显式要求关掉时不再重复提示（同一件事说第二遍是噪音）';
}

{
    my ($c, $o, $e) = run-cli('clean', "--target={$pfx.absolute}",
                              '--promote-bin', '--no-promote-bin');
    isnt $c, 0, '两个互斥旗标同时给 → 非 0 退出';
    ok ($o ~ $e).contains('互斥'), '报错说明「互斥」（而不是静默挑一个）';
}

{
    # --target 不带值：修复前会被静默当成「没给」而回落默认前缀 ——
    # 用户以为指定了前缀，其实装到了 ~/.raku-pm。
    my ($c, $o, $e) = run-cli('clean', '--target');
    isnt $c, 0, '--target 不带值 → 非 0 退出（不静默回落默认前缀）';
    ok ($o ~ $e).contains('--target=<目录>'), '报错给出正确写法';
}

{
    # `~` 展开：Rakudo 自己不展开 IO::Path 里的 `~`，不处理的活会建一个
    # 字面叫 `~` 的目录（修复前实测行为）。
    my ($c, $o, $e) = run-cli('env', '--target=~/rakupm-tilde-probe');
    is $c, 0, 'env 带 ~ 前缀正常执行' or diag $e;
    my $line = ($o ~ $e).lines.first({ .contains('export RAKULIB=') }) // '';
    ok $line.chars, '拿到 RAKULIB 那一行';
    my $norm = $line.subst("\x5C", '/', :g);
    nok $norm.contains('~'), '~ 已展开（没有残留字面 `~`）';
    ok $norm.lc.contains(canonical($*HOME.Str)),
       '展开成了 $HOME 下的路径';
}

# ============ 层3：真装一次，断言前缀外零写入 ============
# 带 bin 字段的发行版才会走 !install-bin（promote 的入口）。
{
    my $probe = "rakupm-promo-probe-{$*PID}";
    my $src = $root.add('src');
    mkdir-p($src.add('lib'));
    mkdir-p($src.add('bin'));
    $src.add('lib').add('PromoProbe.rakumod').spurt("unit module PromoProbe;\n");
    $src.add('bin').add("{$probe}.raku").spurt("#!/usr/bin/env raku\nsay 'PROBE';\n");
    $src.add('META6.json').spurt(to-json({
        name      => 'PromoProbe',
        version   => '1.0',
        auth      => 'demo:test',
        provides  => { 'PromoProbe' => 'lib/PromoProbe.rakumod' },
        bin       => ["bin/{$probe}.raku"],
        depends   => {},
    }, :sorted-keys));

    my $target = $root.add('tgt-real');
    my $client = new-client($target);
    $client.install-from-dir($src, :no-test);

    # 正控：bin 确实被装进了【自己的前缀】（否则下面的否定断言是假绿）
    ok $target.add('bin').add($probe).e,
       '正控：bin wrapper 确实落进了自己的前缀 <前缀>/bin/';

    # 主题：前缀之外一个文件都没多
    my $global = $client.installer.global-site-bin-dir;
    if $global.defined && $global.Str.chars {
        my @leaked = ("{$probe}", "{$probe}.bat", "{$probe}.ps1")
            .map({ $global.add($_) }).grep(*.e).map(*.basename).List;
        is @leaked.elems, 0,
           "自定义前缀装包后，全局 site/bin（{$global.absolute}）里没有该 wrapper"
            or diag "泄漏：{@leaked.join(', ')}";
    }
    else {
        skip '当前仓库链里没有可写的全局 site/bin，跳过泄漏检查', 1;
    }
}
