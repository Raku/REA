use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repositories;
use JSON::Fast;

# 本地目录仓库：repos add <目录> 应识别为 local（而不是当成远程索引 URL）。
#
# 以前 Repositories.add 只认 ecosystem，传目录进来会存成
# {type:'ecosystem', url:'./repo'} —— 不报错，但之后拿它当 JSON 索引去 HTTP 拉，必失败。
#
# 离线、确定性：只测 Repositories 的配置条目与 Client.fetch 的本地源路径，不碰网络。

my $base = $*TMPDIR.add("rakupm-localrepo-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

my $cfg   = $base.add('repositories.json');
my $cache = $base.add('cache');
my $dists = $base.add('my-dists');
$dists.mkdir;

my $ru = RakuPM::Repositories.new(:config-file($cfg), :cache-root($cache),
                                  :repo-root('.'));
$ru.load;

plan 9;

# —— 1) 本地目录被识别为 local 仓库 ——
my $msg = $ru.add($dists.absolute);
ok $msg.contains('本地仓库'), "传目录 → 识别为本地仓库（$msg）";

my @local = $ru.entries.grep({ .<type> eq 'local' && (.<path> // '') eq $dists.absolute });
is @local.elems, 1, '配置里写入了 1 条该目录的 local 条目';
is @local[0]<name>, 'my-dists', '名字默认取目录 basename';

# —— 2) 存的是绝对路径（换 cwd 跑也不会漂移）——
ok $dists.absolute.IO.is-absolute && @local[0]<path>.IO.is-absolute,
   '本地仓库路径存为绝对路径';

# —— 3) 自定义名字 ——
my $d2 = $base.add('vendor');
$d2.mkdir;
$ru.add($d2.absolute, :name('myvendor'));
ok $ru.entries.first({ .<type> eq 'local' && .<name> eq 'myvendor' }).defined,
   '--name 可自定义本地仓库名字';

# —— 4) 重复添加同一目录不会建两条 ——
my $dup = $ru.add($dists.absolute);
ok $dup.contains('已在列表中'), "重复添加会被挡住（$dup）";
is $ru.entries.grep({ .<type> eq 'local' && (.<path> // '') eq $dists.absolute }).elems, 1,
   '重复添加后仍然只有 1 条';

# —— 5) 能按路径/名字移除 ——
my $rm = $ru.remove($dists.absolute);
ok $rm.contains('my-dists'), "按路径可移除本地仓库（$rm）";
is $ru.entries.grep({ .<type> eq 'local' && (.<path> // '') eq $dists.absolute }).elems, 0,
   '移除后条目已消失';

done-testing;
