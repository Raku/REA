use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Repository::Matching;

# 回归：模块匹配逻辑的唯一实现处 RakuPM::Repository::Matching。
#
# 为什么值得单独测：这段逻辑原先散在 Ecosystem.!search-score / Local.search-rows
# / Reporter.!installed-matching 四处各写一遍，语义容易漂移。归一成 role 后
# 它是【纯函数】（入参只有 发行名 / provided 模块名 / 关键词），
# 所以能在这里直接喂数据断言 —— **不需要构造仓库、不需要 HTTP 桩、不碰网络**。

# 一个最小的宿主类：只要 does 这个 role 就能拿到匹配方法（仓库与 Reporter 同理）。
class Matcher does RakuPM::Repository::Matching { }
my $m = Matcher.new;

plan 17;

# ===== match-score：六档相关度（越小越相关）=====
is $m.match-score('Foo',    ['Foo'],      'Foo'), 0, '发行名精确 → 0';
is $m.match-score('Foobar', ['Foobar'],   'Foo'), 1, '发行名前缀 → 1';
is $m.match-score('Barfoo', ['Barfoo'],   'Foo'), 2, '发行名子串 → 2';
is $m.match-score('Qux',    ['Foo'],      'Foo'), 3, '模块名精确 → 3';
is $m.match-score('Quux',   ['Foobar'],   'Foo'), 4, '模块名前缀 → 4';
is $m.match-score('Corge',  ['Baz::Foo'], 'Foo'), 5, '模块名子串 → 5';

# 完全不命中 → Nil（调用方据此过滤）
nok $m.match-score('Nope', ['Nope::Mod'], 'Foo').defined, '无命中 → 未定义（Nil）';
nok $m.match-score('',     [],            'Foo').defined, '空名 + 空模块表 → 未定义（不崩）';

# ===== 大小写不敏感 + 档位取最优 =====
is $m.match-score('foo', ['foo'], 'FOO'), 0, '大小写不敏感';
is $m.match-score('Foo', ['Foo'], 'Foo'), 0, '名字档优先于模块名档（取最优/最小）';

# ===== 不扫 description：描述里的方法名不该被匹配 =====
# description 根本不在入参里 —— 这正是「search 连方法名都匹配」修不掉的根因：
# 旧实现扫了 description，于是 'provide method json' 这类文本把方法名拖了进来。
nok $m.match-score('JSON::Fast', ['JSON::Fast'], 'method').defined,
    '不匹配描述文本/方法名（method）——匹配只看发行名与模块名';

# ===== match-exact：只有「精确名」或「精确模块名」算命中（store/installed 用）=====
ok  $m.match-exact('JSON::Fast', [],           'JSON::Fast'), 'match-exact 精确发行名 → True';
ok  $m.match-exact('Web-App',    ['Web::App'], 'Web::App'),
    'match-exact 精确模块名 → True（目录名 Web-App ≠ 模块名 Web::App）';
nok $m.match-exact('JSON::Fast', [],           'json'),       'match-exact 子串不命中（子串留给 search）';
nok $m.match-exact('Web-App',    ['Web::App'], 'Web'),        'match-exact 模块名前缀不命中';

# ===== match-any：任一档命中即真（search 用）=====
ok  $m.match-any('JSON::Fast', [], 'json'), 'match-any 子串命中 → True';
nok $m.match-any('JSON::Fast', [], 'zzz'),  'match-any 无命中 → False';

done-testing;
