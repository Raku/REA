use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 门禁脚本自身的守护测试。
#
# 为什么需要它：`tools/run-suite.raku` 的文档纪律校验（META6 版本 ↔ 两份 README
# 的版本示例 ↔ Changes 条目；provides 与 lib/ 下文件互为全集）此前完全靠人肉自觉，
# 已经漂移过多次。把它接到 t/ 里，git 克隆后 `zef install` 的测试阶段就会跑到，
# 漂移会在装包时立刻暴露而不是等用户发现。
#
# 注意：只调 --docs-only（不递归跑 t/，否则无限套娃；门禁脚本的子进程只做校验）。

plan 7;

my $root   = $*PROGRAM.parent.parent;
my $runner = $root.add('tools/run-suite.raku');

ok $runner.f, 'tools/run-suite.raku 存在（回归门禁脚本不许被删）';

# 接线断言（同 t/named-arg-wiring.t 的路子：这类「静默失效」编译器不会报）。
# 「内部文档不许进发布包」的检查必须**真的被 check-docs 调到**，否则它只是个
# 死函数：删除调用点不会有任何测试变红，而泄漏只在发布那一刻生效。
# 断言写成「有【一整行】恰好是这个调用」而不是 .contains：后者对
# `# @fails.append(check-shipped-docs())` 这种【被注释掉】的接线同样成立 ——
# 变异验证时实测漏判过（把接线注释掉、测试照样绿）。
ok $runner.slurp.lines.grep({ .trim eq '@fails.append(check-shipped-docs());' }).elems == 1,
   '发布包内容纪律检查（check-shipped-docs）仍作为独立一行接在 check-docs 上';

my $p = run($*EXECUTABLE.Str, $runner.absolute.Str, '--docs-only',
            :out, :err, :cwd($root.Str));
my $out = $p.out.slurp(:close);
my $err = $p.err.slurp(:close);
my $all = $out ~ $err;
my $rc  = $p.exitcode;

is $rc, 0, '文档纪律校验通过（退出码 0）';
diag $all if $rc != 0;

is $all.lines.grep({ .trim.starts-with('FAIL') }).elems, 0,
    '文档纪律校验没有 FAIL 项（版本号三处一致 / provides 与 lib 互为全集）';

# 耗时小结的接线断言（同上面 check-shipped-docs 的路子）。
# 「默认打印每用例耗时 + 最慢排行」是排查"门禁为什么慢"的唯一依据：一旦有人把
# `print-timings();` 这行删掉/注释掉，计时数据会**静默消失**，编译器不报、
# 套件照样全绿 —— 而下次再问"为什么慢"时又只能靠猜。故钉住"有【一整行】恰好是
# 这个调用"（用 .contains 的话，注释掉的那行也能让它为真）。
my Str $src = $runner.slurp;
ok $src.lines.grep({ .trim eq 'print-timings();' }).elems == 1,
   '耗时小结（print-timings）仍作为独立一行被调用';

# 旗标必须同时出现在参数解析与帮助文本里：只在解析里加、忘了写 usage，用户就无从
# 得知；只在 usage 里写、解析里没有，则 --no-timings 会被当成「未知选项」直接 exit 2。
ok $src.contains('--no-timings') && $src.contains("'--no-timings'"),
   '--no-timings 既在帮助文本里、也在参数解析里（两处缺一都是坑）';

# 合并调度（t/ + xt/ 同一池、LPT 分桶）之后，最危险的失败模式变成了「调度自己漏跑
# 用例」：输出上一切正常、退出码 0，实际却少测了几个文件 —— 这类假绿比红灯危险得多。
# 守住那条防漏跑断言仍在：
ok $src.lines.grep({ .trim eq 'my @missing = @plan.map(*.<rel>).grep({ !%ran{$_} }).List;' }).elems == 1,
   '防漏跑检查仍作为独立一行留在调度里（未执行的用例不许变成绿灯）';
