#!/usr/bin/env raku
# raku-pm check 的单元测试：直接调 RakuPM::Author.check（:quiet，不打印），
# 断言结构化结果。覆盖：干净通过 / version=* / auth 不匹配 / 同版本已发布缝 /
# 缺模块文件 / bin 缺失 / license 缺失警告。
use v6;
use Test;
use JSON::Fast;
use RakuPM::Author;

plan 17;

my $base = ($*TMPDIR // '/tmp'.IO).add('author-check-' ~ $*PID);
$base.mkdir;
END { try {
    sub rm(IO::Path $x){ for $x.dir { .d ?? rm($_) !! .unlink }; try $x.rmdir }
    rm($base) if $base.e;
} }

# 造一个干净发行版：scaffold + refresh
my $dist = $base.add('Clean');
RakuPM::Author.scaffold('Clean::Mod', :into($dist), :force);
RakuPM::Author.refresh($dist);

sub meta-of(IO::Path $d) { from-json($d.add('META6.json').slurp) }
sub set-meta(IO::Path $d, %m) { $d.add('META6.json').spurt(to-json(%m, :sorted-keys)) }

# 1-2. 干净发行版应通过
{
    my %r = RakuPM::Author.check($dist, :quiet);
    ok %r<ok>, '干净发行版 check 通过（ok=True）';
    is %r<errors>.elems, 0, '干净发行版无错误';
}

# 3-4. version = '*' → 错误
{
    my %m = meta-of($dist);
    %m<version> = '*';
    set-meta($dist, %m);
    my %r = RakuPM::Author.check($dist, :quiet);
    nok %r<ok>, 'version=* 时不通过';
    ok (%r<errors>.first(*.contains('占位符')).defined), 'version=* 报错含「占位符」';
}

# 复原 version
{
    my %m = meta-of($dist);
    %m<version> = '0.1.0';
    set-meta($dist, %m);
}

# 5-6. auth 与 RAKUPM_AUTHOR_AUTH 不一致 → 错误
{
    temp %*ENV<RAKUPM_AUTHOR_AUTH> = 'github:bob';
    my %r = RakuPM::Author.check($dist, :quiet);
    nok %r<ok>, 'auth 与 RAKUPM_AUTHOR_AUTH 不一致时不通过';
    ok (%r<errors>.first(*.contains('不一致')).defined), 'auth 不一致报错含「不一致」';
}

# 7-8. 同版本已发布（version-exists 缝返回 True）→ 错误
{
    my %r = RakuPM::Author.check($dist, :quiet,
                                 :version-exists(-> $n, $v, $a { True }));
    nok %r<ok>, '同版本已发布（缝=True）时不通过';
    ok (%r<errors>.first(*.contains('已发布')).defined), '已发布报错含「已发布」';
}

# 9. 同版本未发布（缝返回 False）→ 通过
{
    my %r = RakuPM::Author.check($dist, :quiet,
                                 :version-exists(-> $n, $v, $a { False }));
    ok %r<ok>, '同版本未发布（缝=False）时通过';
}

# 10. 联网未能确认（缝返回 Nil，等价真实网络不可达）→ 警告但不阻断
{
    my %r = RakuPM::Author.check($dist, :quiet,
                                 :version-exists(-> $n, $v, $a { Nil }));
    ok %r<ok>, '联网未能确认（缝=Nil）时仍通过';
    ok (%r<warnings>.first(*.contains('未能联网确认')).defined),
       '未能确认警告含「未能联网确认」';
}

# 10-11. 声明了磁盘上不存在的模块 → 错误
{
    my %m = meta-of($dist);
    %m<provides> = %( 'Clean::Ghost' => 'lib/Clean/Ghost.rakumod' );
    set-meta($dist, %m);
    my %r = RakuPM::Author.check($dist, :quiet);
    nok %r<ok>, 'provides 声明磁盘上不存在的模块时不通过';
    ok (%r<errors>.first(*.contains('找不到文件')).defined), '缺模块文件报错含「找不到文件」';
}

# 复原 provides
{
    my %m = meta-of($dist);
    %m<provides> = %( 'Clean::Mod' => 'lib/Clean/Mod.rakumod' );
    set-meta($dist, %m);
}

# 11-12. bin 文件缺失 → 错误
{
    my %m = meta-of($dist);
    %m<bin> = ['bin/missing.raku'];
    set-meta($dist, %m);
    my %r = RakuPM::Author.check($dist, :quiet);
    nok %r<ok>, 'bin 文件缺失时不通过';
    ok (%r<errors>.first(*.contains('bin 声明的可执行文件')).defined), 'bin 缺失报错含「bin 声明的可执行文件」';
}

# 复原 bin
{
    my %m = meta-of($dist);
    %m<bin>:delete;
    set-meta($dist, %m);
}

# 13-14. license 缺失 → 警告但不阻断
{
    my %m = meta-of($dist);
    %m<license>:delete;
    set-meta($dist, %m);
    my %r = RakuPM::Author.check($dist, :quiet);
    ok %r<ok>, 'license 缺失只是警告、仍通过';
    ok (%r<warnings>.first(*.contains('license')).defined), 'license 缺失警告含「license」';
}

done-testing;
