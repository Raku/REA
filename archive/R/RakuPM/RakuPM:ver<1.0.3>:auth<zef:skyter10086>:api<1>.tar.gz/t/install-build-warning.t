use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Builder;
use RakuPM::Fs;

# 回归：H10 —— install() 装完主动读 build.json，把构建类问题在安装时就提示出来，
# 不再等到 verify。验证「有构建问题 → 装完告警；无构建问题 → 不刷噪音」。

my IO::Path $tmp = $*TMPDIR.add("rakupm-installbuildwarn-{$*PID}");
LEAVE rm-tree($tmp) if $tmp.e;

my $store   = RakuPM::Store.new(:root($tmp.add('store')));
my $inst    = RakuPM::Installer.new(:target($tmp.add('target')), :store($store));
my $builder = RakuPM::Builder.new;

sub make-src(Str $name, Bool :$builder = False, :@resources = () --> IO::Path) {
    my $d = $tmp.add("src-{$name}").mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add("{$name}.rakumod").spurt("unit module {$name};\n");
    my %m = (
        name     => $name,
        version  => '1.0',
        auth     => 'test:me',
        api      => '1',
        provides => { $name => "lib/{$name}.rakumod" },
        depends  => {},
    );
    %m<builder>   = 'RakuPM::Test::Builder' if $builder;
    %m<resources> = @resources.List        if @resources;
    $d.add('META6.json').spurt(to-json(%m, :sorted-keys));
    $d
}

# 捕获一次 install 的 stderr（note 走 $*ERR），返回捕获到的文本。
sub install-stderr($dist --> Str) {
    my $cap = '';
    my $fh = IO::Handle.new but role ::R {
        method print(*@t) { $cap ~= @t.join; $cap }
        method say($x)    { $cap ~= $x ~ "\n"; $cap }
    };
    {
        temp $*ERR = $fh;
        $inst.install($dist);
    }
    $cap
}

# ---- 1) 构建没跑成功、资源没生成 → 装完必须告警点名资源 ----
my $s1 = make-src('NoRes', :builder, :resources['libraries/ghost']);
my $d1 = RakuPM::Distribution.from-meta-file($s1.add('META6.json'));
my %f1 = $builder.facts($s1, $d1, :mode('built'), :ran, :ok);
$store.put($d1, $s1, build => %f1);

my $out1 = install-stderr($d1);
ok $out1.contains('⚠ 构建痕迹'), 'NoRes：install 主动提示「构建痕迹」';
ok $out1.contains('libraries/ghost'), 'NoRes：告警点名缺失的资源 libraries/ghost';

# 同一事实仍能被 verify 查到（抽取没破坏原逻辑）
ok $inst.consistency-issues.grep({ .<kind> eq 'missing-build-resource' }).elems == 1,
   'NoRes：consistency-issues 仍能报出（抽取未破坏）';

# ---- 2) 用 --no-build 装进去 → 装完告警 build-skipped ----
my $s2 = make-src('Skipped', :builder);
my $d2 = RakuPM::Distribution.from-meta-file($s2.add('META6.json'));
my %f2 = $builder.facts($s2, $d2, :mode('skipped-no-build'));
$store.put($d2, $s2, build => %f2);
my $out2 = install-stderr($d2);
ok $out2.contains('构建痕迹') && $out2.contains('--no-build'),
   'Skipped：install 提示被 --no-build 跳过';

# ---- 3) 纯 Raku 包、构建正常 → 装完不刷任何构建类噪音 ----
my $s3 = make-src('PlainY');
my $d3 = RakuPM::Distribution.from-meta-file($s3.add('META6.json'));
my %f3 = $builder.facts($s3, $d3, :mode('not-needed'));
$store.put($d3, $s3, build => %f3);
my $out3 = install-stderr($d3);
ok !$out3.contains('构建痕迹'), 'PlainY：正常包 install 不刷构建噪音';

done-testing;
