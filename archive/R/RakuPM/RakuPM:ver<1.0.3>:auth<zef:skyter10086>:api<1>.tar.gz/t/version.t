use Test;
use RakuPM::Version;
use RakuPM::Distribution;

# 用 done-testing：用例按场景分块，写死数量容易对不上（曾踩过）。

# 版本解析
my $v = RakuPM::Version.from-string("1.2.3");
is $v.major, 1, 'major';
is $v.minor, 2, 'minor';
is $v.patch, 3, 'patch';

# 约束匹配
ok RakuPM::Version.from-string("1.2.0").satisfies(">= 1.0.0"), '>= 满足';
ok RakuPM::Version.from-string("1.5.0").satisfies(">=1.0.0, <2.0.0"), '区间约束';
nok RakuPM::Version.from-string("0.9.0").satisfies(">= 1.0.0"), '不满足 >=';
ok RakuPM::Version.from-string("0.0.1").satisfies("*"), '通配符';

# 版本挑选
my $best = RakuPM::Version.new.pick-best(">= 1.0.0", <0.9.0 1.0.0 1.5.0 2.0.0>);
is $best, "2.0.0", 'pick-best 选最高满足版本';

# --- 生态索引里的脏版本号（回归：曾把 "v0.2" 丢给 + 直接抛异常） ---
my $v2 = RakuPM::Version.from-string("v0.2");
is $v2.major, 0, 'v 前缀：major';
is $v2.minor, 2, 'v 前缀：minor';
is RakuPM::Version.from-string("v1.2.3").patch, 3, 'v 前缀：patch';
is RakuPM::Version.from-string("2rc1").major, 2, '非数字尾巴退化为该段数字';
is RakuPM::Version.from-string("").major, 0, '空串不抛异常';
ok RakuPM::Version.from-string("v0.2").satisfies("0.2+"), 'v 前缀版本照常参与约束匹配';

# pick-best 必须返回仓库里的「原始串」，否则 0.2 会被归一成 0.2.0 而对不上
is RakuPM::Version.new.pick-best("0.2+", <0.1 0.2 0.3>), "0.3",
   'pick-best 返回原始版本串';

# ===== zef 风格安装规格串的解析（Foo:ver<1.2.3>:auth<x> / Foo@1.2.3）=====
# 这是 identity() 的逆操作，用于 `raku-pm install 'Foo:ver<1.2.3>'`
{
    my %h = RakuPM::Distribution.parse-spec('Foo::Bar');
    is %h<module>, 'Foo::Bar', '纯模块名：module 原样';
    is %h<ver>,  '',           '纯模块名：ver 为空';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3>');
    is %h<module>, 'Foo::Bar', ':ver<>：模块名不带 phaser';
    is %h<ver>,    '1.2.3',    ':ver<>：版本取到';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3+>');
    is %h<ver>, '1.2.3+', ':ver<>：zef 的 + 后缀（至少）保留下来';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3>:auth<zef:x>');
    is %h<ver>,  '1.2.3',  '多个 phaser：ver 对';
    is %h<auth>, 'zef:x',  '多个 phaser：auth 对';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar:ver<1.2.3>:auth<zef:x>:api<1>');
    is %h<auth>, 'zef:x', '三个 phaser：auth 对';
    is %h<api>,  '1',     '三个 phaser：api 对';

    # @ 简写归一成 :ver<>
    %h = RakuPM::Distribution.parse-spec('Foo::Bar@1.2.3');
    is %h<module>, 'Foo::Bar', '@ 简写：模块名对';
    is %h<ver>,    '1.2.3',    '@ 简写：等价于 :ver<1.2.3>';

    %h = RakuPM::Distribution.parse-spec('Foo::Bar@1.2.3+');
    is %h<ver>, '1.2.3+', '@ 简写：+ 后缀保留';

    # 只有 auth 没有 ver 也要能解析
    %h = RakuPM::Distribution.parse-spec('Foo::Bar:auth<zef:x>');
    is %h<module>, 'Foo::Bar', '只给 auth：模块名对';
    is %h<ver>,    '',         '只给 auth：ver 为空';
    is %h<auth>,   'zef:x',    '只给 auth：auth 对';

    # 模块名里的 :: 不能被当成 phaser（这是最容易写错的地方）
    %h = RakuPM::Distribution.parse-spec('Foo::Bar::Baz:ver<1.0>');
    is %h<module>, 'Foo::Bar::Baz', '深层模块名 :: 不会被误判成 phaser';
    is %h<ver>,    '1.0',           '深层模块名 + :ver<> 正常';
}

# 版本排序（统一入口 sort-versions）
# 回归：installed 的 zef 侧展示曾用 .unique.sort（字典序），
# 把 0.9.2 排到 0.13.0 后面 —— 与 raku-pm 账本侧（semver）不一致。
{
    my @in  = <0.9.2 0.13.0 0.10.0 0.2.0>;
    my @got = RakuPM::Version.new.sort-versions(@in);

    is @got.join(', '), '0.2.0, 0.9.2, 0.10.0, 0.13.0',
       'sort-versions 按 semver 升序（不是字典序）';

    # 排序结果的最高版本必须是 semver 意义上的最高
    is @got[*-1], '0.13.0', '取末位得到 semver 最高版本（字典序会错成 0.9.2）';

    # 去重 + 去空串
    my @dup = RakuPM::Version.new.sort-versions(['1.0.0', '', '1.0.0', '0.1.0', Str]);
    is @dup.join(', '), '0.1.0, 1.0.0', 'sort-versions 去重并去掉空版本串';

    # 单元素 / 空输入不能炸
    is RakuPM::Version.new.sort-versions(['2.0.0']).join(','), '2.0.0', '单元素正常';
    is RakuPM::Version.new.sort-versions([]).elems, 0, '空输入返回空列表';
}

# ===== ^ / ~ 糖语法与范围（uninstall --version 范围卸载）=====
#
# 【为什么这里必须两侧都断言，而且要对展开串逐字断言】0.87.2 修掉的是一个
# 「**约束过宽**」类 bug：旧实现用 `.comb('.').elems` 数「用户写了几段」，
# 而 `comb` 返回的是**匹配到的分隔符本身**（'1.2'.comb('.') → 1 个元素，
# 而段数是 2）—— 整整差一位，于是「按最后指定的位 +1」的分支全部错位：
#   ~1.2 → <2.0.0（应 <1.3.0）   ^0.0 → <1.0.0（应 <0.1.0）   ^0.0.0 → <0.1.0（应 <0.0.1）
# 当时这里对 `~1.2` **只有正面断言**（"含 1.2.5"）—— 上界放宽到 2.0.0 之后它照样为真，
# 于是整个 bug 在套件里隐形。教训：放宽类 bug 只能靠**负面断言**（"不含 1.3.0"）
# 与**展开串逐字断言**抓住，正面断言再多也没用。

# 矩阵：约束 → 精确展开串 / 应含（下界侧） / 应不含（上界侧）
# 展开串末尾那个 `>` 是 expand-sugar 的既有格式（`">= $0, <" ~ upper ~ ">"`），
# parse-constraint-part 靠「取开头数字」把它吃掉，不影响语义 —— 别顺手"美化"掉它。
my @sugar =
    ('^1.2.3', '>= 1.2.3, <2.0.0>', '1.9.9',  '2.0.0'),
    ('^0.2.3', '>= 0.2.3, <0.3.0>', '0.2.9',  '0.3.0'),
    ('^0.0.3', '>= 0.0.3, <0.0.4>', '0.0.3',  '0.0.4'),
    ('^1',     '>= 1, <2.0.0>',     '1.9.9',  '2.0.0'),
    ('^0',     '>= 0, <1.0.0>',     '0.9.9',  '1.0.0'),
    ('^0.0',   '>= 0.0, <0.1.0>',   '0.0.9',  '0.1.0'),   # 修复前是 <1.0.0
    ('^0.0.0', '>= 0.0.0, <0.0.1>', '0.0.0',  '0.0.1'),   # 修复前是 <0.1.0
    ('~1.2.3', '>= 1.2.3, <1.3.0>', '1.2.9',  '1.3.0'),
    ('~1.2',   '>= 1.2, <1.3.0>',   '1.2.9',  '1.3.0'),   # 修复前是 <2.0.0（最常见的两段写法）
    ('~1',     '>= 1, <2.0.0>',     '1.9.9',  '2.0.0'),
    ('~0.1',   '>= 0.1, <0.2.0>',   '0.1.9',  '0.2.0'),   # 修复前是 <1.0.0
    ('~0.0',   '>= 0.0, <0.1.0>',   '0.0.9',  '0.1.0'),   # 修复前是 <1.0.0
    ;
for @sugar -> ($c, $expanded, $yes, $no) {
    is RakuPM::Version.new.expand-sugar($c), $expanded,
       "expand-sugar 逐字展开：{$c} → {$expanded}";
    ok RakuPM::Version.from-string($yes).satisfies($c), "{$c} 含 {$yes}";
    nok RakuPM::Version.from-string($no).satisfies($c), "{$c} 不含 {$no}（上界开）";
}

# 下界含（闭）、上界不含（开）这条性质单独钉一下（与上面的矩阵互为印证）
ok RakuPM::Version.from-string("1.0.0").satisfies("^1.0"),  '^1.0 含下界 1.0.0（下界闭）';
nok RakuPM::Version.from-string("0.9.0").satisfies("^1.0"), '^1.0 不含 0.9.0';
ok RakuPM::Version.from-string("1.2.3").satisfies("~1.2.3"), '~1.2.3 含下界（下界闭）';

# 区间 / 范围（卸载一批）
ok RakuPM::Version.from-string("0.9.0").satisfies("<1.0"),       '<1.0 含 0.9.0';
nok RakuPM::Version.from-string("1.0.0").satisfies("<1.0"),       '<1.0 不含 1.0.0（开区间）';
ok RakuPM::Version.from-string("1.2.0").satisfies(">=1.0, <2.0"), '区间 >=1.0,<2.0 含 1.2.0';
nok RakuPM::Version.from-string("2.0.0").satisfies(">=1.0, <2.0"), '区间不含上界 2.0.0';

# ===== 预发布版的比较与排序（semver 2.0.0 §11）=====
#
# 【为什么单独成块、而且必须断言「顺序无关」】0.87.3 修掉的是一个「**丢失精度**」
# 类 bug：旧 key 把整个预发布段折成一个布尔（`$!prerelease eq '' ?? 1 !! 0`），
# 于是 alpha / beta / rc1 的 key **完全相同**、cmp 一律判 Same —— 它不报错、不崩，
# 而是给出「取决于输入顺序」的静默错答：
#   pick-best("*", <1.0.0-alpha 1.0.0-beta 1.0.0-rc1>) → 1.0.0-alpha   ← 错
#   pick-best("*", <1.0.0-rc1 1.0.0-beta 1.0.0-alpha>) → 1.0.0-rc1     ← 对（纯属运气）
# 旧测试这里只有一条 `> 0` 式的存在性断言 —— 那种断言在修复前后**都为真**，
# 所以整个 bug 在套件里隐形。要抓住它只能靠：① cmp 的三向结果逐对断言；
# ② 同一集合**颠倒输入**后结果不变。下面两块都写上。
{
    # ---- ① cmp 的三向结果逐对断言（含 semver 的细节规则）----
    # 「数字标识符 < 字母数字标识符」「同位数字比数值（不是字典序）」
    # 「build metadata 不参与优先级」这三条是 semver §11 里最容易漏的。
    my @pairs =
        ('1.0.0-alpha',    '1.0.0-beta',   'Less'),
        ('1.0.0-beta',     '1.0.0-rc1',    'Less'),
        ('1.0.0-rc1',      '1.0.0',        'Less'),   # 正式版 > 预发布
        ('1.0.0-rc1',      '1.0.0-beta',   'More'),   # 反向
        ('1.0.0-alpha',    '1.0.0-alpha',  'Same'),
        ('1.0.0-1',        '1.0.0-alpha',  'Less'),   # 数字标识符 < 字母数字标识符
        ('1.0.0-2',        '1.0.0-11',     'Less'),   # 同位数比数值：2 < 11（字典序会反）
        ('1.0.0-alpha',    '1.0.0-alpha.1','Less'),   # 前缀相同 → 字段少的更低
        ('1.0.0+build',    '1.0.0',        'Same'),   # build metadata 不参与优先级
        ('1.0.0-alpha+b1', '1.0.0-alpha',  'Same'),
        ;
    for @pairs -> ($a, $b, $want) {
        is RakuPM::Version.from-string($a).cmp(RakuPM::Version.from-string($b)).gist, $want,
           "cmp({$a}, {$b}) = {$want}";
    }

    # ---- ② semver 规范原文给的示例序列，整条严格升序 ----
    # 单点断言容易互相掩盖；整条序列能把「某一对判 Same（顺序塌陷）」一并抓出来。
    my @asc = <1.0.0-alpha 1.0.0-alpha.1 1.0.0-alpha.beta 1.0.0-beta
               1.0.0-beta.2 1.0.0-beta.11 1.0.0-rc.1 1.0.0>;
    my @violations;
    for @asc.rotor(2 => -1) -> ($a, $b) {
        my $o = RakuPM::Version.from-string($a).cmp(RakuPM::Version.from-string($b));
        @violations.push("{$a} 应 < {$b}，实得 {$o.gist}") unless $o == Less;
    }
    ok @violations.elems == 0,
       'semver §11 示例序列严格升序：alpha < alpha.1 < alpha.beta < beta < beta.2 < beta.11 < rc.1 < 正式版';
    diag "  {$_}" for @violations;

    # ---- ③ pick-best 必须与输入顺序无关（旧实现这里两次答案不同）----
    for (<1.0.0-alpha 1.0.0-beta 1.0.0-rc1>, <1.0.0-rc1 1.0.0-beta 1.0.0-alpha>) -> @in {
        is RakuPM::Version.new.pick-best('*', @in), '1.0.0-rc1',
           "pick-best 取最高预发布版且与输入顺序无关（输入：{@in.join(' ')}）";
    }
    for (<1.0.0 1.0.0-rc1>, <1.0.0-rc1 1.0.0>) -> @in {
        is RakuPM::Version.new.pick-best('^1.0', @in), '1.0.0',
           "pick-best 在正式版与 rc 之间选正式版（semver：正式版 > 预发布）";
    }

    # ---- ④ sort-versions 同理 ----
    # 期望串刻意让预发布之间也有序：旧实现会把三者判 Same、退化成输入顺序。
    is RakuPM::Version.new.sort-versions(<1.0.0-rc1 1.0.0 1.0.0-alpha 1.0.0-beta>).join(', '),
       '1.0.0-alpha, 1.0.0-beta, 1.0.0-rc1, 1.0.0',
       'sort-versions：预发布按 semver 排在正式版之前，彼此也有序';

    # ---- ⑤ satisfies 侧的一致性：预发布低于同 core 的正式版 ----
    nok RakuPM::Version.from-string('1.0.0-alpha').satisfies('>= 1.0.0'),
        '1.0.0-alpha 不满足 >= 1.0.0（semver：它低于 1.0.0）';
    ok  RakuPM::Version.from-string('1.0.0-alpha').satisfies('>= 1.0.0-alpha'),
        '1.0.0-alpha 满足 >= 1.0.0-alpha（下界闭）';
    ok  RakuPM::Version.from-string('1.0.0').satisfies('>= 1.0.0-alpha'),
        '1.0.0 满足 >= 1.0.0-alpha（正式版高于预发布）';
}

done-testing;
