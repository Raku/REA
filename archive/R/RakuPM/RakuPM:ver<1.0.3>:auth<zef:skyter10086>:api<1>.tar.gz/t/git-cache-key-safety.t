use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Fs;

# !git-cache-key 的路径安全回归（0.88.6）。
#
# 【为什么必须有这个文件】git 地址的全部三条入口 —— CLI 直接输入、恶意发行版
# META6.json 里的 git-deps、以及 self-upgrade --from —— 都汇聚到
# !ensure-git-clone → !git-cache-key。而这个 key 会被拼到 `target/git-cache/` 下面
# 交给文件系统建目录，**Raku 的 IO::Path 不折叠 `..`**（`.absolute` 与 `.cleanup`
# 都原样保留），真正解析 `..` 的是内核 —— 所以在修之前，`https://host/x/../../../tmp/evil.git`
# 能把目录建到 git-cache 之外（实测确认过）。
#
# ★ 本文件刻意**不靠字符串断言**做核心判定：因为 Raku 不折叠 `..`，
# `$root.add($key).absolute.starts-with($root.absolute)` 对含 `..` 的路径**恒为真**
# （字面上确实在下面）—— 那正是 assert-under 在这类穿越面前失效的原因。
# 所以"是否逃逸"这条断言改用**真实文件系统**判定：让内核去建目录，再看它落在哪。

my $base = $*TMPDIR.add("rakupm-gitkey-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

my $target = $base.add('target');
my $client = RakuPM::Client.new(:target($target), :repos([]));
my $key-method = $client.^private_method_table<git-cache-key>;
die "取不到私有方法 git-cache-key（是不是改名了？）" unless $key-method.defined;

sub cache-key(Str $url --> Str) { $key-method($client, $url) }

plan 12;

# ---- 一、正常地址的 key 逐字节不变（改了会让老 store / 老 clone 失联）----
is cache-key('https://github.com/foo/bar.git'), 'github.com/foo/bar.git',
   'https 地址 → host/path，逐字节不变';
is cache-key('git@github.com:foo/bar.git'), 'github.com/foo/bar.git',
   'git@ 形态 → host/path（冒号换斜杠）';
is cache-key('git://github.com/foo/bar.git'), 'github.com/foo/bar.git',
   'git:// 形态同样规整（真实链路里 normalize-git-url 会先把它升级成 https）';

# ---- 二、`..` 段必须被吸收掉 ----
my Str $evil = cache-key('https://github.com/foo/../../../tmp/evil.git');
nok $evil.contains('..'), '含 `..` 的地址：key 里不再残留 `..` 段';
is $evil, 'tmp/evil.git',
   '上溯到顶后剩余段就是 key（本该逃到 git-cache 外的那一层被吃掉了）';

is cache-key('https://host/../../../../a/b.git'), 'a/b.git',
   '越界的 `..` 被静默丢弃而不是 die（本地路径 `--from ../../repo` 依赖这一点）';

# ---- 三、★ 真正的判据：让文件系统去建，看它落在哪 ----
#
# 【为什么先建中间层】`..` 的落点只有在**中间层级都存在**时才能被内核一路解析到底
# （真实攻击里是 `git clone` 自己 `mkdir -p` 整条路径）。不先铺好
# `git-cache/github.com/foo`，`mkdir-p` 可能在某个 `..` 段上卡住，导致"没建出来"
# 被误读成"没逃逸" —— 变异验证时实测过这个假阴性。
{
    my IO::Path $cache-root = $target.add('git-cache');
    mkdir-p($cache-root.add('github.com/foo'));
    mkdir-p($cache-root.add($evil));      # 修复后 $evil = tmp/evil.git（根内）
    ok $cache-root.add('tmp').d,
       '★ 目录建在 git-cache/tmp 内（净化后确实还在缓存根下）';
    # 落点是 `target/git-cache` 上溯三层 = `target`，所以"外面"就是 target 那一层
    # （第一版这里写成 $base/tmp，那是永远不存在的位置 —— 变异验证时暴露为假阴性）。
    nok $target.add('tmp').d,
       '★ 没有建到 git-cache 之外（上溯三层本该落到 target/tmp）—— 逃逸已堵死';
    is $target.dir.grep(*.d).map(*.basename).sort.join(','), 'git-cache',
       '★ target 下只有 git-cache 一个目录（这条与上溯层数无关，兜底）';
}

# ---- 四、本地路径（含 `..` 是合法的）与既有语义 ----
{
    my Str $lk = cache-key('/home/user/../repos/proj');
    ok $lk.starts-with('local/'), '本地路径仍走 local/ 前缀（不与 host 段撞名）';
    nok $lk.contains('..'), '本地路径里的 `..` 同样被吸收（不再是"合法可穿越"）';
}

is cache-key('https://host/a*b/c.git'), 'host/a%2Ab/c.git',
   'Windows 保留字符仍走 path-component 的百分号编码（净化的既有语义没被绕过）';
