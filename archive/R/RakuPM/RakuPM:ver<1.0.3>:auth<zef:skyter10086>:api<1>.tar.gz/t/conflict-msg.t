use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::Repository;
use RakuPM::Resolver;

# 回归测试：版本冲突的报错必须给出【完整请求链】，否则用户看到
# 「ANSI 选了 0.0.25 但要求 0.0.24」根本没法决定该 pin 哪边。
# 历史 bug：输出行尾多了个 '}'、顶层请求显示成空串而非 <top-level>。

class MemRepo does RakuPM::Repository {
    has @.rows;
    method id(--> Str) { 'mem:conflict' }
    method find-providers(Str $m --> List) {
        self.rows.grep({ $m (elem) @(.<provides>) }).map(*<name>).unique.List
    }
    method all-distributions(--> List) { self.rows.map(*<name>).unique.List }
    method available-versions(Str $n --> List) {
        self.rows.grep(*<name> eq $n).map(*<version>).unique.List
    }
    method fetch-distribution(Str $n, Str $v --> RakuPM::Distribution) {
        my $row = self.rows.first({ .<name> eq $n && .<version> eq $v });
        die "假仓库里找不到 $n $v" unless $row;
        RakuPM::Distribution.new:
            :name($row<name>),
            :version($row<version>),
            :provides(@($row<provides>)),
            :depends(RakuPM::Distribution.normalize-dependencies($row<depends> // {}));
    }
    method source-dir-for(Str $, Str $ --> IO::Path) { IO::Path }
}

sub resolver-for(@rows) {
    RakuPM::Resolver.new(:repos([MemRepo.new(:rows(@rows))]))
}

# 捕获异常消息（die 会打断后续用例，所以包一层 try）
sub resolve-all-err(@rows, @specs) {
    try { resolver-for(@rows).resolve-all(@specs) }
    $! ?? $!.Str !! ''
}

# ===== 场景：A 要 Foo 0.0.25，B 要 Foo 0.0.24，同时装 A B =====
# 这就是用户遇到的「ANSI 0.0.25 vs 0.0.24」的复现骨架。
my @ab =
    %( name => 'A',    version => '1.0', provides => ['A'],
       depends => { 'Foo' => '0.0.25' } ),
    %( name => 'B',    version => '1.0', provides => ['B'],
       depends => { 'Foo' => '0.0.24' } ),
    %( name => 'Foo',  version => '0.0.25', provides => ['Foo'], depends => {} ),
    %( name => 'Foo',  version => '0.0.24', provides => ['Foo'], depends => {} ),
;

my $m1 = resolve-all-err(@ab, (%( module => 'A', constraint => '' ), %( module => 'B', constraint => '' )));
ok $m1.contains('依赖冲突'),                 '间接冲突报「依赖冲突」';
ok $m1.contains("'Foo'"),                   '报错点名了冲突模块 Foo';
ok $m1.contains('最后选定的版本'),            '提示已选定的版本';
ok $m1.contains('A → Foo'),                 '链路里能看到请求人 A';
ok $m1.contains('B → Foo'),                 '链路里能看到请求人 B';
ok $m1.contains('A → Foo 0.0.25'),          'A 要的版本写全了';
ok $m1.contains('B → Foo 0.0.24'),          'B 要的版本写全了';
ok $m1.contains('0.0.25') && $m1.contains('0.0.24'), '两个版本号都出现';
nok $m1.contains('<top-level> → Foo'),
   '间接冲突时请求人是发行版名而非 <top-level>';

# 行尾不得有历史 bug 留下的 '}'（{%r<version>}} 的残渣）
my @lines = $m1.lines.grep({ / '→ Foo ' / });
ok @lines.elems == 2, "冲突清单恰好两行（得到 {@lines.elems} 行）";
for @lines -> $l {
    nok $l ~~ / '}' \s* $ /, "行尾干净：{$l}";
}

# ===== 场景：顶层直接给同一模块两个互斥约束 =====
# raku-pm install 'Foo:ver<0.0.25>' 'Foo:ver<0.0.24>' 的样子
my $m2 = resolve-all-err(@ab,
    (%( module => 'Foo', constraint => '0.0.25' ), %( module => 'Foo', constraint => '0.0.24' )));
ok $m2.contains('依赖冲突'),                 '顶层互斥约束也报冲突';
ok $m2.contains('<top-level> → Foo'),       '顶层请求人显示为 <top-level>';

# ===== 场景：一边要 '*'、另一边要精确版 —— 交集非空，**不该**报冲突 =====
# 用户实测（装 Terminal::UI）：
#     Log::Async   → Terminal::ANSI '*'
#     Terminal::UI → Terminal::ANSI '0.0.24'
# 解析器先给 '*' 挑了最新的 0.0.25，于是 '0.0.24' 看上去冲突并直接 die ——
# 但 0.0.24 同样满足 '*'，交集非空，正确行为是**改选 0.0.24** 而不是报错。
# 修复前这两条都会红（第一条 die 会直接把测试文件打断）。
my @star =
    %( name => 'Log::Async',   version => '1.0', provides => ['Log::Async'],
       depends => { 'Share' => '*' } ),
    %( name => 'Terminal::UI', version => '1.0', provides => ['Terminal::UI'],
       depends => { 'Share' => '0.0.24' } ),
    %( name => 'Share', version => '0.0.25', provides => ['Share'], depends => {} ),
    %( name => 'Share', version => '0.0.24', provides => ['Share'], depends => {} ),
;
my @star-res;
lives-ok {
    @star-res = resolver-for(@star).resolve-all(
        (%( module => 'Log::Async',   constraint => '' ),
         %( module => 'Terminal::UI', constraint => '' ))
    );
}, "'*' 与 '0.0.24' 交集非空 —— 不报冲突（多约束求交集）";
is @star-res.map({ .name ~ ':' ~ .version }).sort.join(','),
   'Log::Async:1.0,Share:0.0.24,Terminal::UI:1.0',
   "改选到交集中的 0.0.24（不是误报冲突，也不是死守最新的 0.0.25）";

# ===== 场景：依赖里出现「Raku 编译器」Rakudo —— 应跳过，而不是去下载 =====
# 生态里部分发行版用 "Rakudo:ver<2026.07>" 声明「需要 Raku 编译器 >= 某版本」。
# 它不是可安装的包：编译器已经在跑，索引条目也根本没有 tarball 可下。
# 用户实测：装 DB::MySQL 时依赖链里冒出 Rakudo:ver<2026.07>，解析器把它当
# 普通包去下载 → 索引缺 source-url → 整个安装崩掉（zef 则是直接跳过）。
my @crew =
    %( name => 'DB::MySQL', version => '0.8', provides => ['DB::MySQL'],
       depends => { 'Rakudo' => '', 'DB' => '0.5' } ),
    %( name => 'DB', version => '0.5', provides => ['DB'], depends => {} ),
    # REA 索引里确实存在 Rakudo 这个条目，所以解析器能「选中」它
    %( name => 'Rakudo', version => '2026.07', provides => ['Rakudo'], depends => {} ),
;
my @crew-res = resolver-for(@crew).resolve-all(
    (%( module => 'DB::MySQL', constraint => '' ),)
);
is @crew-res.map({ .name ~ ':' ~ .version }).sort.join(','),
   'DB:0.5,DB::MySQL:0.8',
   '依赖里的 Rakudo（编译器本身）被跳过，不进安装列表也不去下载';

# 编译器版本不满足时要明确报错，而不是静默装个假的或去下载
my $future = ($*RAKU.compiler.version.Str.subst(/^v/, '').Int + 1).Str;
my @crew2 =
    %( name => 'DB::MySQL', version => '0.8', provides => ['DB::MySQL'],
       depends => { 'Rakudo' => $future, 'DB' => '0.5' } ),
    %( name => 'DB', version => '0.5', provides => ['DB'], depends => {} ),
;
my $crew-err = resolve-all-err(@crew2, (%( module => 'DB::MySQL', constraint => '' ),));
ok $crew-err.contains('Rakudo 版本不满足'),
   "编译器版本不满足时明确报错（要求 $future，当前更旧）";
ok $crew-err.contains('当前运行的 Raku 编译器'),
   '报错里带上当前编译器版本，便于用户决定要不要升级';

# ===== 场景：依赖【核心模块】NativeCall —— 它其实由 Rakudo 发行版提供 =====
# 这是真实生态的形态，比上一节更狡猾（用户装 DB::MySQL 踩的就是这个）：
# 依赖数组里写的是 "NativeCall"，**不是** "Rakudo"；而 REA 索引里 provides
# NativeCall 的恰好是 "Rakudo" 这个发行版（它 provides 24 个核心模块，
# 且条目没有 source-url）。
#
# 于是解析器是在 find-best **选中之后**才发现选到了编译器 ——
# 只按请求的模块名判断（上一节 @crew 的做法）根本拦不住，
# 必须看 find-best 实际选出来的发行版名。
my @core =
    %( name => 'DB::MySQL', version => '0.8', provides => ['DB::MySQL'],
       depends => { 'NativeCall' => '', 'JSON::Fast' => '0.20.1' } ),
    %( name => 'JSON::Fast', version => '0.20.1', provides => ['JSON::Fast'],
       depends => {} ),
    # 模拟 REA 的 Rakudo 条目：provides 核心模块，没有 source-url
    %( name => 'Rakudo', version => '2026.07', provides => ['NativeCall'], depends => {} ),
;
my @core-res = resolver-for(@core).resolve-all(
    (%( module => 'DB::MySQL', constraint => '' ),)
);
is @core-res.map({ .name ~ ':' ~ .version }).sort.join(','),
   'DB::MySQL:0.8,JSON::Fast:0.20.1',
   '依赖核心模块 NativeCall（由 Rakudo 提供）：跳过编译器，其余照常装';

# ===== 兼容路径：无冲突的正常解析不受影响 =====
# A 要 0.0.25，顶层也要 0.0.25 —— 约束一致，不该误报
my @ok = resolver-for(@ab).resolve-all(
    (%( module => 'A', constraint => '' ), %( module => 'Foo', constraint => '0.0.25' ))
);
is @ok.map({ .name ~ ':' ~ .version }).sort.join(','), 'A:1.0,Foo:0.0.25',
   '无冲突时正常解析，不误报';

# 但 A（要 0.0.25）与顶层 0.0.24 是真实冲突 —— 应当照常报错
my $m3 = resolve-all-err(@ab,
    (%( module => 'A', constraint => '' ), %( module => 'Foo', constraint => '0.0.24' )));
ok $m3.contains('A → Foo 0.0.25'),
   '与顶层互斥时仍列出 A 的完整约束';

done-testing;
