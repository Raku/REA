# 回归：Ecosystem 的索引在内存里以 HASH 组织（%!by-nv + %!provides），
# 而非线性扫描 @!rows。本测试直接驱动 Ecosystem（注入假 HTTP 后端），
# 锁定「按名+版本定位」与「按发行名匹配」的语义不因存储结构改写而漂走。
#
# 关键历史 bug：App::Mi6 依赖 fez:ver<38+>，而 fez 发行版的 provides 里
# 只有大写的 Fez、没有小写 fez —— 必须按【发行版名】也能匹配。旧实现靠
# 查询时 `|| %row<name> eq $module`；新实现靠构建期把发行名登记进 %!provides
# 反向索引。两种实现结果必须一致，否则这个案例会静默丢失。

use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Repository::Ecosystem;
use JSON::Fast;

plan 16;

# —— 假 HTTP 后端：get-text 返回索引 raw array，download 空操作 ——
class FakeHTTP {
    has @.rows;
    method get-text(Str $ --> Str) { to-json(@!rows) }
    method download(Str $, IO::Path $ --> Nil) { }
}

# 注意：必须用标量持有每个 Hash 再装进数组。若写成
#   my @rows = [ %( ... ) ]
# Raku 的列表赋值会把内层 Hash 展平成它的若干 Pair，于是 @rows 里装的是
# Pair 而非 Hash，Ecosystem 拿到的就不是「发行记录数组」了。
my $fez    = %( name => 'fez',   version => '43',  provides => { Fez => 'lib/Fez.rakumod' },          depends => {} );
my $multi1 = %( name => 'Multi', version => '1.0', provides => { Multi => 'lib/Multi.rakumod' },       depends => {} );
my $multi2 = %( name => 'Multi', version => '2.0', provides => { Multi => 'lib/Multi.rakumod' },       depends => {} );
my $plain  = %( name => 'Plain', version => '0.1', provides => ['PlainMod'],                           depends => {} );
my @rows = ( $fez, $multi1, $multi2, $plain );

my $tmp = $*TMPDIR.add("rakupm-eco-mem-{+$*PID}");
$tmp.mkdir;
my $fake = FakeHTTP.new(:rows(@rows));

my $eco = RakuPM::Repository::Ecosystem.new(
    :index-url('https://test.example/meta.json'),
    :cache-root($tmp),
    :http($fake),
    :refresh(False),
);
$eco.refresh;

# 1) 按 provides 模块名匹配
is $eco.find-providers('Fez').join(','), 'fez',
   'find-providers 按 provides 模块名命中';

# 2) 按发行名匹配（fez 案例的核心）
is $eco.find-providers('fez').join(','), 'fez',
   'find-providers 按【发行名】也能命中（fez 案例）';

# 3) 多版本发行
is $eco.find-providers('Multi').join(','), 'Multi',
   'find-providers 命中多版本发行';

# 4) 数组式 provides 也能建索引
is $eco.find-providers('PlainMod').join(','), 'Plain',
   '数组式 provides 也进反向索引';

# 5) available-versions 多版本
is $eco.available-versions('Multi').sort.join(','), '1.0,2.0',
   'available-versions 返回该发行全部版本';

# 6) available-versions 单版本
is $eco.available-versions('fez').join(','), '43',
   'available-versions 单版本';

# 7) all-distributions 列出全部发行名
is $eco.all-distributions.sort.join(','), 'Multi,Plain,fez',
   'all-distributions 返回全部发行名';

# 8) versions-providing 按模块名+发行名
is $eco.versions-providing('Fez', 'fez').join(','), '43',
   'versions-providing(模块名, 发行名) 命中';

# 9) versions-providing 多版本
is $eco.versions-providing('Multi', 'Multi').sort.join(','), '1.0,2.0',
   'versions-providing 返回该发行全部版本';

# 10) fetch-distribution 经 !row-for 定位，字段完整
my $d = $eco.fetch-distribution('fez', '43');
is $d.name,    'fez', 'fetch-distribution: name';
is $d.version, '43',  'fetch-distribution: version';
ok $d.provides.grep(* eq 'Fez'), 'fetch-distribution: provides 含 Fez';

# 11) fetch-distribution 不存在的版本 → 抛错（!row-for 返回空 Hash）
dies-ok { $eco.fetch-distribution('fez', '99') },
   'fetch-distribution 找不到版本时抛错';

# 12) search-rows 模糊匹配（从 %!by-nv 展开后遍历）
is $eco.search-rows('mult').map(*<name>).unique.join(','), 'Multi',
   'search-rows 模糊命中发行名';

# 13) 缺版本时不返回 (%!by-nv 无该 key)
is $eco.available-versions('Nope').join(','), '',
   'available-versions 对未知发行返回空';

# 14) 反向索引去重：fez 只出现一次（不重复登记 provides 模块名与发行名）
is $eco.find-providers('fez').elems, 1,
   '反向索引对同名发行去重';

# 清理
try $tmp.rmdir;
