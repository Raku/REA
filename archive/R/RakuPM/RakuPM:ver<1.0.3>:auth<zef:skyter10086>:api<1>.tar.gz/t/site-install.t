use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;

# site 安装的集成测试 —— 用户报的痛点（0.28.0 拆 Client role 时漏登记 META6 provides，
# 装上后 site/sources 预编译 RakuPM::Client 时找不到 RakuPM::Client::SelfManager，
# 整个 raku-pm 直接 "Could not find" 崩掉；测试套件全过是因为 raku -Ilib 走的是源码）。
#
# 这两个测试共同把"安装到 site 后子目录模块必须可用"这条集成路径钉死：
#   1. 端到端：构造 lib/ 下有子目录模块的发行版，install 后通过外部 raku 进程
#      用 RAKULIB=raku-lib-spec 能 use 到子目录模块。
#      （CUR::Installation 用内容寻址存文件，不在 site/lib/<子目录>/<模块>.rakumod
#      留明文；测试只断言"外部能 use"，不强制物理路径。）
#   2. 静态：raku-pm 自带的 META6 provides 必须覆盖 lib/ 下所有 .rakumod——
#      这是 (1) 能通过的必要前置，但 (1) 通过并不等于 (2) 通过
#      （CUR::Installation 可能容忍某些差异），所以两个都加。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-site-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# ---------- 1. 安装后外部 raku 进程能 use 子目录模块 ----------
{
    my $src = $tmp.add('subdir-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('Sub').mkdir;
    $src.add('lib').add('Sub').add('Child.rakumod').spurt(
        'unit module Sub::Child;' ~ "\n" ~
        'sub ping is export { "pong" }' ~ "\n");
    $src.add('META6.json').spurt(to-json({
        name => 'SubPkg', version => '1.0', auth => 'demo',
        provides => { 'Sub::Child' => 'lib/Sub/Child.rakumod' },
        depends => {},
    }, :sorted-keys));

    my $client = RakuPM::Client.new(
        :target($tmp.add('subdir-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]),
    );
    $client.install-from-dir($src, :no-test);

    # 钉死：CUR::Installation 列出的发行版包含 SubPkg
    my @installed = $client.installer.repo-prefix.IO ?? [] !! [];
    # 用 Installation 仓库直接查 installed 列表（最权威）
    my $repo = CompUnit::Repository::Installation.new(
        :prefix($client.installer.repo-prefix.absolute));
    my $hit = $repo.installed.first({ (.meta<name> // '') eq 'SubPkg' });
    ok $hit, 'CUR::Installation 认得 SubPkg（provides 路径生效）';
    # CUR::Installation 里 meta<provides> 是嵌套 Hash<Str, Hash<Str, %{file,time}>>：
    #   module-name → path → %{file, time}
    # 所以验证 requires keys 包含 Sub::Child 即可（无需验证路径，因为路径是 hash key）
    my %prov = ($hit ?? ($hit.meta<provides> // {}) !! {});
    ok %prov.keys.contains('Sub::Child'),
       'CUR::Installation 里 SubPkg 的 provides 包含 Sub::Child（嵌套 hash）';

    # 钉死：外部 raku 进程通过 raku-lib-spec 能 use 到这个子目录模块
    my $proc = run('raku', '-I', $client.installer.raku-lib-spec, '-e',
                   'use Sub::Child; print ping()', :out, :err);
    is $proc.out.slurp(:close), 'pong', 'raku -I <lib-spec> 能 use Sub::Child 并调 ping()';
    ok $proc.exitcode == 0, '子进程成功退出（不在编译时报"找不到模块"）';

    # 反向验证 —— 用错误的模块名，应该找不到（证明上面不是被缓存干扰的假阳性）
    my $proc-fail = run('raku', '-I', $client.installer.raku-lib-spec, '-e',
                        'use Sub::NoSuch; print "x"', :out, :err);
    nok $proc-fail.exitcode == 0, 'use 不存在的模块确实会失败（防假阳性）';
}

# ---------- 2. 静态：META6 provides 必须覆盖 lib/ 下所有 .rakumod ----------
# 路径以仓库根为基准：扫描出的是 lib/<X>，provides value 也是 lib/<X>，直接比对。
{
    my $repo-root = $*PROGRAM.parent.parent;
    my $lib-root  = $repo-root.add('lib');
    my $meta      = from-json($repo-root.add('META6.json').slurp);
    my %provides  = %(try { $meta<provides> } // {});

    my @rak-files;
    sub scan(IO::Path $d --> Nil) {
        for $d.dir -> $e {
            if $e.d {
                scan($e);
            }
            elsif $e.Str.ends-with('.rakumod') {
                # 归一化成正斜杠：Windows 下 IO::Path.relative 默认反斜杠，
                # 但 provides value 是正斜杠；用 trans 做字符转换（不是正则）。
                my $rel = $e.relative($repo-root).Str;
                $rel .= trans('\\' => '/');
                @rak-files.push($rel);
            }
        }
    }
    scan($lib-root);

    my %have-set = %(flat %provides.values.map({ $_ => True }));
    my @missing = @rak-files.grep({ not (%have-set{$_}:exists) }).sort;
    ok @missing.elems == 0,
       "lib/ 下所有 .rakumod 都在 META6 provides 里（缺失: {@missing.join(', ') || '无'}）";
}

done-testing;