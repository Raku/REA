use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Repository::Local;

# Local 仓库索引的进程内缓存 —— !index 要扫目录 + 解析每个 META*.json，
# 而这个对象在一次 install 里会被问 7 次（find-providers /
# available-versions / versions-providing / source-dir-for / search-rows /
# all-distributions …），每次全量重扫纯属浪费（Ecosystem 早就用 $!loaded
# 做了同样的事）。
#
# 缓存的代价：目录内容中途变了（往仓库里放新包）不会自动可见 —— 这正是
# 本测试钉死的行为：新包在 refresh 之前看不见，refresh 之后看得见。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-lidx-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $repo-root = $tmp.add('repo').mkdir;

# 往仓库里放一个发行版
sub put-dist(IO::Path $root, Str $name, Str $ver --> IO::Path) {
    my $d = $root.add($name).mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add($name ~ '.rakumod').spurt('unit module ' ~ $name ~ ';');
    $d.add('META6.json').spurt(to-json({
        name => $name, version => $ver, auth => 'demo',
        provides => { ($name) => ('lib/' ~ $name ~ '.rakumod') },
        depends => {},
    }, :sorted-keys));
    $d
}

put-dist($repo-root, 'Alpha', '1.0');

my $repo = RakuPM::Repository::Local.new(:root($repo-root));

# ---------- 1. 首次查询能看到 Alpha ----------
{
    my @all = $repo.all-distributions;
    ok 'Alpha' (elem) @all, '首次查询：仓库里有 Alpha';
    is $repo.available-versions('Alpha').List, ('1.0',), 'Alpha 版本正确';
}

# ---------- 2. 缓存生效：目录里新增的包，refresh 之前看不见 ----------
{
    put-dist($repo-root, 'Beta', '2.0');
    # 磁盘上确实已经有了
    ok $repo-root.add('Beta').d, '（前置）磁盘上已放入 Beta 目录';

    my @all = $repo.all-distributions;
    nok 'Beta' (elem) @all, '缓存生效：新增的 Beta 在 refresh 之前不可见';
    ok  'Alpha' (elem) @all, '缓存里的 Alpha 仍在';
}

# ---------- 3. refresh 之后看得见 ----------
{
    $repo.refresh;
    my @all = $repo.all-distributions;
    ok 'Beta' (elem) @all, 'refresh 之后 Beta 可见（缓存被清掉重扫）';
    ok 'Alpha' (elem) @all, 'refresh 之后 Alpha 仍在';
    is $repo.available-versions('Beta').List, ('2.0',), 'Beta 版本正确';
}

# ---------- 4. 后续查询仍然一致（缓存重建后稳定） ----------
{
    is $repo.find-providers('Beta').List, ('Beta',), 'find-providers 能找到 Beta';
    ok $repo.source-dir-for('Beta', '2.0').defined, 'source-dir-for 能给出 Beta 的源码目录';
}

# ---------- 5. 缓存不会让重复查询返回不同结果（幂等） ----------
{
    my @a = $repo.all-distributions;
    my @b = $repo.all-distributions;
    is @a.sort.List, @b.sort.List, '重复查询返回相同结果（缓存幂等）';
}

done-testing;