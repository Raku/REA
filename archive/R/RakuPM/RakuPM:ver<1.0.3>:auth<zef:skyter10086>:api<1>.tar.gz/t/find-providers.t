use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use JSON::Fast;
use RakuPM::Repository::Ecosystem;

# 回归测试：Ecosystem.find-providers 必须返回【扁平的发行名字符串列表】，
# 不能返回嵌套数组（如 [["Log::Async"]]）。
#
# 历史 bug（0.36.14 引入 / 暴露）：反向索引 %!provides{$m} 是「存进哈希的
# Array（被 Scalar 包裹）」，find-providers 里 `my @names = %!provides{$m}`
# 会被当成单个 item 整体塞成单元素数组（Raku 列表赋值对 Scalar 包裹的 Array
# 不扁平化），于是返回 [["Log::Async"]]。Resolver 把该元素当 $dist-name 喂给
# versions-providing(Str $module, Str $dist-name) 就抛
# 「expected Str but got Array」，导致 `raku-pm install Log::Async` 直接崩。
#
# 本测试用真实 Ecosystem + 本地夹具索引复现，断言返回值是扁平 Str 列表，
# 且能直接喂给 versions-providing 而不崩。

plan 6;

my $tmp   = $*TMPDIR.add('rakupm-findprov-' ~ $*PID);
my $cache = $tmp.add('cache');
my $idx   = $tmp.add('index.json');
$tmp.mkdir; $cache.mkdir;
LEAVE { try $idx.unlink; try $cache.rmdir; try $tmp.rmdir; }

# 造一个夹具：一个发行版 Log::Async，provides 同时含模块名与发行版名本身，
# 多版本；再放一个别的发行版也 provides 同模块（漂移场景）。
my @rows =
    %( name => 'Log::Async', version => '0.0.17',
       provides => { 'Log::Async' => 'lib/Log/Async.rakumod',
                     'Log::Async::Logger' => 'lib/Log/Async/Logger.rakumod' },
       depends => {} ),
    %( name => 'Log::Async', version => '0.0.16',
       provides => { 'Log::Async' => 'lib/Log/Async.rakumod' }, depends => {} ),
    %( name => 'Some::Other', version => '1.2.3',
       provides => { 'Log::Async' => 'lib/Some/Other.rakumod' }, depends => {} ),
;
$idx.spurt(to-json(@rows));

my $eco = RakuPM::Repository::Ecosystem.new(
    :name('fixture'), :index-url($idx.absolute), :cache-root($cache));
$eco.refresh;

# 1) find-providers 返回扁平列表，每个元素都是 Str（不是 Array）
my @prov = $eco.find-providers('Log::Async');
ok @prov, 'find-providers(Log::Async) 非空';
ok @prov.all ~~ Str, 'find-providers 每个元素都是 Str（无嵌套数组）';

# 2) 按发行版名查也要命中（反向索引登记了发行名本身）
my @byprov = $eco.find-providers('Log::Async::Logger');
ok @byprov.all ~~ Str && @byprov.grep(* eq 'Log::Async').elems,
   'find-providers(Log::Async::Logger) 命中发行版 Log::Async';

# 3) 关键：find-providers 的结果能直接喂给 versions-providing，不崩、出 Str 版本
my $ok = True;
try {
    for @prov -> $dn {
        # $dn 必须是 Str；若仍是 Array 会在这里触发类型检查失败
        my @v = $eco.versions-providing('Log::Async', $dn);
        $ok = $ok && (@v.all ~~ Str);
    }
}
ok $ok, 'versions-providing 能消费 find-providers 的结果（无 Array 类型错误）';

# 4) 结果里确实包含了 Log::Async 这个发行名（多版本都算提供）
ok @prov.grep(* eq 'Log::Async').elems, '结果含正主发行版 Log::Async';
ok @prov.grep(* eq 'Some::Other').elems, '结果含漂移发行版 Some::Other';
