use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 可提交锁文件（0.54.0）回归测试。
#
# 覆盖：
#   1. Client 层：显式 :lock-path 覆盖 → 锁落到该路径，target 内不再生成锁；
#   2. Client 层：不给 lock-path（旧默认）→ 锁仍在 target/raku-pm.lock（行为不变，
#      保证不经过 CLI 的库调用方 / 测试不污染仓库根）；
#   3. CLI 层：--lock-file=<路径> 透传到 Client，锁落到指定路径（target 不被污染）；
#   4. CLI 层：不给 --lock-file → 锁默认落到【当前工作目录】raku-pm.lock（可提交），
#      target 内同样不生成锁。
# 全部离线：本地目录安装、发行版无依赖，不碰生态索引 / 网络。

my $base = $*TMPDIR.add("rakupm-lockfile-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

sub make-dist($dir, :$name, :$version, :@provides) {
    $dir.mkdir;
    $dir.add('lib').mkdir;
    for @provides -> $mod {
        my $mf = $dir.add("lib/{$mod.subst('::', '/', :g)}.rakumod");
        $mf.parent.mkdir;
        $mf.spurt("unit module $mod;\n");
    }
    my %meta = name => $name, version => $version, auth => 'demo:raku',
               provides => @provides;
    $dir.add('META6.json').spurt(to-json(%meta, :sorted-keys));
}

make-dist($base.add('MyDist'), :name('MyDist'), :version('1.2.3'),
          :provides(['My::Dist']));
my $dist = $base.add('MyDist');

# ---- 1) Client 层：显式 :lock-path 覆盖 ----
{
    my $target = $base.add('target-override');
    my $lock   = $base.add('proj.lock');
    my $client = RakuPM::Client.new(
        :target($target),
        :lock-path($lock),
        :repos([RakuPM::Repository::Local.new(:root($base))]),
    );
    my $ok = try { $client.install-from-dir($dist, :no-test); True }
    ok $ok.defined, 'override: install-from-dir 不抛异常';
    ok $lock.e, 'override: 锁落到显式 lock-path';
    nok $target.add('raku-pm.lock').e,
       'override: target 内不再生成 raku-pm.lock（已外置到项目路径）';
}

# ---- 2) Client 层：不给 lock-path（旧默认行为保留）----
{
    my $target = $base.add('target-default');
    my $client = RakuPM::Client.new(
        :target($target),
        :repos([RakuPM::Repository::Local.new(:root($base))]),
    );
    my $ok = try { $client.install-from-dir($dist, :no-test); True }
    ok $ok.defined, 'default: install-from-dir 不抛异常';
    ok $target.add('raku-pm.lock').e, 'default: 锁仍在 target/raku-pm.lock';
    is $client.lock-path.absolute, $target.add('raku-pm.lock').absolute,
       'default: lock-path 默认等于 target/raku-pm.lock（库调用方行为不变）';
}

# ---- CLI 层：用真实二进制验证旗标与默认推导 ----
my $bin = $*PROGRAM.parent(2).add('bin').add('raku-pm.raku');

# run-bin：用 Proc::Async 跑真实二进制，:cwd 决定「当前工作目录」（锁默认落点）。
# start(:cwd) 才生效（new(:cwd) 无效，见 RakuPM 平台笔记）。
sub run-bin(*@args, :$cwd = $*CWD) {
    my $p = Proc::Async.new($*EXECUTABLE.absolute.Str, $bin.absolute.Str,
                            |@args, :out, :err);
    my $stdout = '';
    my $stderr = '';
    $p.stdout.tap: { $stdout ~= $_ };
    $p.stderr.tap: { $stderr ~= $_ };
    my $rc = await $p.start(:cwd($cwd));
    ($rc, $stdout, $stderr)
}

# ---- 3) CLI 层：--lock-file 透传 ----
{
    my $proj   = $base.add('cli-proj');
    my $target = $base.add('cli-target-lf');
    $proj.mkdir; $target.mkdir;
    my ($rc, $out, $err) = run-bin(
        'install', $dist.absolute.Str,
        '--target=' ~ $target.absolute.Str,
        '--lock-file=' ~ $proj.add('myproj.lock').absolute.Str,
        '--no-test', '--offline',
        :cwd($proj),
    );
    ok $rc ~~ 0, 'CLI --lock-file: 退出码 0'
        or note "STDERR: $err\nSTDOUT: $out";
    ok $proj.add('myproj.lock').e, 'CLI --lock-file: 锁落到指定路径';
    nok $target.add('raku-pm.lock').e, 'CLI --lock-file: target 内不生成锁';
}

# ---- 4) CLI 层：默认落当前工作目录 ----
{
    my $proj   = $base.add('cli-cwd');
    my $target = $base.add('cli-target-cwd');
    $proj.mkdir; $target.mkdir;
    my ($rc, $out, $err) = run-bin(
        'install', $dist.absolute.Str,
        '--target=' ~ $target.absolute.Str,
        '--no-test', '--offline',
        :cwd($proj),
    );
    ok $rc ~~ 0, 'CLI cwd 默认: 退出码 0'
        or note "STDERR: $err\nSTDOUT: $out";
    ok $proj.add('raku-pm.lock').e,
       'CLI cwd 默认: 锁落到当前工作目录 raku-pm.lock（可提交）';
    nok $target.add('raku-pm.lock').e, 'CLI cwd 默认: target 内不生成锁';
}

done-testing;
