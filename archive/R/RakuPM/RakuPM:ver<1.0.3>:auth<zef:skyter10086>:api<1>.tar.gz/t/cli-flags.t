use lib 'lib';
use Test;

# 回归：CLI 选项是「开放式」接收的（任何 --key 都进 %opts），必须有白名单挡拼错。
#
# 修复前的行为（静默，很坑）：
#   · `raku-pm install Foo --no-tets` → 照常跑测试，用户以为跳过了；
#   · `--verison=1.2` 被静默丢弃；
#   · 旗标写在【命令位之前】时更糟：Raku MAIN 会抛一句莫名的内部错误
#     "rindex search target requires a concrete string, but got null"，
#     用户完全看不出是旗标位置问题。
# 修复后：未知旗标一律给出「未知选项 + 本命令可用选项」；且旗标写在命令前/后等价。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;

sub run-cli(*@args) {
    my $p = run($raku, '-Ilib', $bin, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

my $tmp = $*TMPDIR.add("rakupm-cliflags-{$*PID}");
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# ---- 未知旗标：命令之后 ----
{
    my ($code, $out, $err) = run-cli('install', 'Foo', '--no-tets');
    isnt $code, 0, '拼错的旗标（命令之后）导致非 0 退出';
    my $all = $out ~ $err;
    ok $all.contains('未知选项'), '报错里说明是「未知选项」';
    ok $all.contains('--no-tets'), '报错里点名拼错的旗标';
    ok $all.contains('--no-test'), '报错里列出正确的可用选项（便于对照）';
}

# ---- 未知旗标：命令之前（修复前是 Rakudo 的内部错误）----
{
    my ($code, $out, $err) = run-cli('--no-tets', 'install', 'Foo');
    isnt $code, 0, '拼错的旗标（命令之前）同样非 0 退出';
    ok ($out ~ $err).contains('未知选项'),
       '命令之前的未知旗标给「未知选项」而不是 Rakudo 内部错误';
}

# ---- 只给旗标、不给命令 ----
{
    my ($code, $out, $err) = run-cli('--zzz');
    isnt $code, 0, '只有未知旗标时非 0 退出（不静默打印帮助）';
    ok ($out ~ $err).contains('未知选项'), '只有未知旗标时也说明是未知选项';
}

# ---- 回归：只带【公共旗标】、不给命令 → 应显示帮助（而不是「未知选项」）----
# 发行版 wrapper 每次都会隐式注入 `--target=<前缀>`（见 ShellTemplates），所以敲裸
# `raku-pm` 的真实形态其实是 `raku-pm --target=…`。曾经它被当成「未知选项」报错，
# 症状就是「不带参数输入 raku-pm 不显示 help」（用户实测）。公共旗标不蕴含命令，
# 故一律放行；`--dry` 这种每命令旗标无命令时仍应报错（见下面那条）。
{
    for '--target=/tmp/xyz', '--no-color', '--offline' -> $f {
        my ($code, $out, $err) = run-cli($f);
        is $code, 0, "只带公共旗标 `{$f}`（无命令）退出码 0";
        ok ($out ~ $err).contains('用法：raku-pm'),
           "只带公共旗标 `{$f}`（无命令）显示帮助（wrapper 裸调用回归）";
    }
    my ($cd, $od, $ed) = run-cli('--dry');
    isnt $cd, 0, '每命令旗标 `--dry` 无命令时仍非 0 退出（不放行）';
    ok ($od ~ $ed).contains('未知选项'), '`--dry` 无命令时仍报「未知选项」';
}

# ---- 合法旗标：两种位置都要能跑到命令本身 ----
{
    my $tgt = $tmp.add('target').absolute.Str;
    my ($c1, $o1, $e1) = run-cli('clean', "--target=$tgt");
    is $c1, 0, '合法旗标（命令之后）正常执行';
    ok ($o1 ~ $e1).contains('扫描缓存'), '确实走到了 clean 命令';

    my $tgt2 = $tmp.add('target2').absolute.Str;
    my ($c2, $o2, $e2) = run-cli("--target=$tgt2", 'clean');
    is $c2, 0, '合法旗标写在【命令之前】同样正常执行（修复前会被 MAIN 拦掉）';
    ok ($o2 ~ $e2).contains('扫描缓存'), '命令之前的旗标确实生效（走到了 clean）';
}

# ---- 帮助入口都要能用 ----
{
    for 'help', '?', '--help-', '--help', '-h' -> $form {
        my ($code, $out, $err) = run-cli($form);
        is $code, 0, "帮助入口 `{$form}` 退出码 0";
        ok ($out ~ $err).contains('用法：raku-pm'), "帮助入口 `{$form}` 打印了用法";
    }
}

# ---- 未知命令仍报「未知命令」而不是「未知选项」 ----
{
    my ($code, $out, $err) = run-cli('nosuchcmd');
    isnt $code, 0, '未知命令非 0 退出';
    ok ($out ~ $err).contains('未知命令'), '未知命令报「未知命令」';
}

done-testing;
