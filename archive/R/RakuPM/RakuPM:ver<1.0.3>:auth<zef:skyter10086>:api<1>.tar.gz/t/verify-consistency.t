use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;

# raku-pm verify 的第二段：安装一致性。
# 「内容完整性」只查 store 源码有没有被改，看不见下面这些 —— 而它们才是
# 今天真正咬人的坑：
#   · 账本有、CUR 没有（= site/dist/<id> 损坏那类半截状态）
#   · CUR 有、账本没记（影响 installed / 依赖回收 / 世代回滚）
#   · 声明了 resources 但文件没生成（构建没跑成功 → libresources.so）
#   · 账本有、store 没有（回滚装不回来）

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-verify-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub make-dist(Str $name, Str $ver, :@resources = () --> IO::Path) {
    my $d = $tmp.add("src-$name-$ver").mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add("$name.rakumod").spurt("unit module $name;\n");
    my %m = (
        name     => $name,
        version  => $ver,
        auth     => 'test:me',
        api      => '1',
        provides => { $name => "lib/$name.rakumod" },
        depends  => {},
    );
    %m<resources> = @resources if @resources;
    $d.add('META6.json').spurt(to-json(%m, :sorted-keys));
    $d
}

my $store = RakuPM::Store.new(:root($tmp.add('store')));
my $inst  = RakuPM::Installer.new(:target($tmp.add('target')), :store($store));
my $ledger = $inst.repo-prefix.parent.add('installed.json');

sub install-dist(IO::Path $src --> Nil) {
    my $d = RakuPM::Distribution.from-meta-file($src.add('META6.json'));
    $store.put($d, $src);
    $inst.install($d);
}

# ---------- 1) 干净安装：没有不一致 ----------
my $plain = make-dist('Plain', '1.0');
install-dist($plain);
is $inst.consistency-issues.elems, 0, '干净安装没有任何不一致';

# ---------- 2) CUR 有、账本没记 → 可修（补记） ----------
$ledger.spurt('[]');                       # 假装账本空了（CUR 里还在）
my @i2 = $inst.consistency-issues;
is @i2.grep({ .<kind> eq 'missing-in-ledger' }).elems, 1,
   'CUR 有、账本没记 → 报 missing-in-ledger';
ok @i2.first({ .<kind> eq 'missing-in-ledger' })<fixable>,
   '这类问题标记为可自动修复';

is $inst.adopt-from-cur, 1, '--fix 补记了 1 条';
is $inst.installed-versions('Plain').join(','), '1.0', '补记后账本里有 Plain 1.0';
is $inst.consistency-issues.elems, 0, '补记后没有不一致了';

# ---------- 3) 账本有、CUR/store 没有 → 不可自动修 ----------
my @l = from-json($ledger.slurp);
for @l -> %e {
    next unless (%e<name> // '') eq 'Plain';
    %e<versions> = ('1.0', '9.9');          # 9.9 从没装过
}
$ledger.spurt(to-json(@l, :sorted-keys));

my @i3 = $inst.consistency-issues;
is @i3.grep({ .<kind> eq 'missing-in-cur'   && .<version> eq '9.9' }).elems, 1,
   '账本记着 9.9 但 CUR 没有 → 报 missing-in-cur';
is @i3.grep({ .<kind> eq 'missing-in-store' && .<version> eq '9.9' }).elems, 1,
   'store 里也没有 → 报 missing-in-store';
nok @i3.first({ .<kind> eq 'missing-in-cur' })<fixable>,
   '这类不可自动修复（需重装）';

# 还原，免得污染后面的断言
$ledger.spurt(to-json(
    from-json($ledger.slurp).map(-> %e {
        %e<versions> = ('1.0',) if (%e<name> // '') eq 'Plain';
        %e;
    }), :sorted-keys));

# ---------- 4) 入库时声明过的资源，文件后来没了 ----------
# 注意边界：store 的 META6 只声明【磁盘上真实存在】的资源
# （Store.!existing-resources 的取舍：声明了却找不到会让 CUR 装不上）。
# 所以「构建没跑成功 → 资源压根没生成」在 store 里不留痕迹，查不出来；
# 这里查的是「入库时声明过、但文件后来没了」。
my $wr-src = make-dist('WithRes', '1.0', :resources['libraries/thing']);
# 资源文件名必须按【本平台】形状造（与 t/build.t 同一套约定）：
# Windows 找 thing.dll；Linux 找 libthing.so；macOS 找 libthing.dylib。
# 造错形状的话 CUR::Installation 装包时会直接 "Failed to open file ..."。
my $res-file = $*DISTRO.is-win ?? 'thing.dll'
             !! ($*DISTRO.name ~~ /mac|darwin/ ?? 'libthing.dylib' !! 'libthing.so');
$wr-src.add('resources').mkdir;
$wr-src.add('resources').add('libraries').mkdir;
$wr-src.add('resources').add('libraries').add($res-file).spurt('');
install-dist($wr-src);
is $inst.consistency-issues.grep({ .<kind> eq 'missing-resource' }).elems, 0,
   '资源文件在 → 不报（且能认本平台的库文件形状）';

$store.path-for('WithRes', '1.0')
      .add('resources').add('libraries').add($res-file).unlink;
is $inst.consistency-issues.grep({
        .<kind> eq 'missing-resource' && .<name> eq 'WithRes' }).elems, 1,
   '入库时声明过的资源文件后来没了 → 报 missing-resource';

done-testing;
