use lib 'lib';
use RakuPM::Repository::Ecosystem;
use RakuPM::HTTP::Backend;
use JSON::Fast;
use Test;

# 索引「增量更新」（条件 GET / ETag / 304 复用缓存）回归测试。
#
# 核心：TTL 过期后再刷新时，带上次存的 ETag 发 If-None-Match；远端没变回 304，
# raku-pm 直接复用本地磁盘缓存、跳过下载。本测试用假后端模拟 200 / 304，
# 验证 ETag 被持久化并在下次请求里透传，且 304 时复用的是缓存而非重新拉取。

plan 8;

my @rows = [
    %( name => 'fez', version => '43', provides => { Fez => 'lib/Fez.rakumod' }, depends => {} ),
    %( name => 'Multi', version => '1.0', provides => { Multi => 'lib/Multi.rakumod' }, depends => {} ),
];

# 条件 GET 后端：按 mode 返回 200（新内容+etag）或 304（未修改）
class FakeCondHTTP {
    has @.rows;
    has Str $.mode is required;          # '200' | '304'
    has $.calls      = 0;
    has $.last-inm   = '';                # 记录收到的 If-None-Match
    method get-text-conditional(Str $url, Str :$if-none-match = ''
                                --> RakuPM::HTTP::ConditionalResponse) {
        $!calls++;
        $!last-inm = $if-none-match;
        return RakuPM::HTTP::ConditionalResponse.new(:status(200), :body(to-json(@!rows)), :etag('v1'))
            if $!mode eq '200';
        RakuPM::HTTP::ConditionalResponse.new(:status(304), :body(''), :etag('v1'))
    }
    method get-text(Str $ --> Str) { to-json(@!rows) }
    method download(Str $, IO::Path $ --> Nil) { }
}

# 只实现 get-text、没有 get-text-conditional 的桩（退化路径）
class PlainHTTP {
    has @.rows;
    has $.get-text-calls = 0;
    method get-text(Str $ --> Str) { $!get-text-calls++; to-json(@!rows) }
    method download(Str $, IO::Path $ --> Nil) { }
}

my $tmp = $*TMPDIR.add("rakupm-cond-{+$*PID}");
$tmp.mkdir;
END { try $tmp.rmdir }

# --- 场景 1：首次刷新，200 拉取并落盘（缓存 + etag） ---
my $h1 = FakeCondHTTP.new(:rows(@rows), :mode<200>);
my $eco1 = RakuPM::Repository::Ecosystem.new(:index-url('https://t.example/m.json'),
                                             :cache-root($tmp), :name('test'),
                                             :http($h1), :refresh);
$eco1.refresh;
ok $h1.calls == 1, '第一次刷新走条件 GET（200）';
is $eco1.available-versions('fez').join(','), '43',
   '首次加载使用拉取到的行';

# --- 场景 2：缓存已落盘，TTL 过期再刷新，远端未变 → 304 复用缓存 ---
my $h2 = FakeCondHTTP.new(:rows([]), :mode<304>);
my $eco2 = RakuPM::Repository::Ecosystem.new(:index-url('https://t.example/m.json'),
                                             :cache-root($tmp), :name('test'),
                                             :http($h2), :refresh);
$eco2.refresh;
ok $h2.calls == 1, '第二次刷新仍走条件 GET';
is $h2.last-inm, 'v1', '把上次存的 ETag 透传进 If-None-Match';
is $eco2.available-versions('fez').join(','), '43',
   '304 命中：复用本地缓存行（未重新拉取，fez 仍在）';
is $eco2.available-versions('Multi').join(','), '1.0',
   '304 复用缓存：Multi 也在';

# --- 场景 3：后端无 get-text-conditional → 退化为普通 GET（不崩） ---
my $h3 = PlainHTTP.new(:rows(@rows));
my $eco3 = RakuPM::Repository::Ecosystem.new(:index-url('https://t.example/m.json'),
                                             :cache-root($tmp), :name('test'),
                                             :http($h3), :refresh);
$eco3.refresh;
ok $h3.get-text-calls == 1, '无 get-text-conditional 的后端退化为普通 GET';
is $eco3.available-versions('fez').join(','), '43',
   '退化路径同样正确加载索引';
