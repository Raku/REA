use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use JSON::Fast;

# RakuPM::Author.refresh（0.37.7）：以磁盘为准重建 META6.json 的 provides。
#
# 用【真 CLI 子进程】跑，而不是直接调方法 —— 两个理由：
#   1. refresh 会 say 一堆进度，直接在测试进程里调会把输出混进 TAP 流；
#   2. 顺便把 CLI 接线（分支、--dry 选项解析、错误路径的退出码）一起测了。
# 与 t/query-installed-store.t 同一套路。
#
# 注意每次 run(:out, :err) 后都必须把两个管道 slurp(:close) 读完再关，
# 否则 Windows 上句柄泄漏会让进程挂住。

sub rm-tree(IO::Path $d) {
    for $d.dir -> $e { $e.d ?? rm-tree($e) !! (try $e.unlink) }
    try $d.rmdir;
}

my $bin = $*PROGRAM.parent(2).add('bin').add('raku-pm.raku');
my $tmp = $*TMPDIR.add("rakupm-author-refresh-{$*PID}-" ~ now.floor);
$tmp.mkdir;
END { rm-tree($tmp) if $tmp.e }

sub mk(IO::Path $p, Str $c = '') { $p.parent.mkdir; $p.spurt($c) }

# 跑 CLI 并同时取回 stdout / stderr（两条都要读，见文件头注释）
sub cli(*@args) {
    my $p = run('raku', $bin.absolute.Str, |@args, :out, :err);
    my $o = $p.out ?? $p.out.slurp(:close) !! '';
    my $e = $p.err ?? $p.err.slurp(:close) !! '';
    ($p.exitcode, $o, $e)
}

# 夹具：lib/ 下三个模块（含一个 .pm6 老包）；META6.json 的 provides 故意写成
# 「对了一个（Demo）、多两个不存在的（Missing1/2）、漏两个存在的（Extra/Gone）」
# —— 每边都是【多个】，这样「for 标量 List 只迭代一次、多个挤一行」的回归才会被测到。
my $dist = $tmp.add('Demo-Dist');
$dist.mkdir;
mk($dist.add('lib/Demo.rakumod'),       "unit module Demo;\n");
mk($dist.add('lib/Demo/Extra.rakumod'), "unit module Demo::Extra;\n");
mk($dist.add('lib/Demo/Gone.pm6'),      "unit module Demo::Gone;\n");
$dist.add('META6.json').spurt(to-json({
    name         => 'Demo-Dist',
    version      => '1.2.3',
    auth         => 'demo:raku',
    description  => 'refresh 测试夹具',
    tags         => ['demo', 'test'],
    'source-url' => 'https://example.com/demo.git',
    depends      => ['JSON::Fast'],
    provides     => %(
        'Demo'           => 'lib/Demo.rakumod',
        'Demo::Missing1' => 'lib/Demo/Missing1.rakumod',
        'Demo::Missing2' => 'lib/Demo/Missing2.rakumod',
    ),
}, :sorted-keys));

sub meta-of(IO::Path $d --> Hash) { from-json($d.add('META6.json').slurp) }

# 断言「某一行独占以 $prefix 开头」（钉死一行一个，防 for 标量 List 只迭代一次）
sub line-once(Str $out, Str $prefix --> Bool) {
    $out.lines.grep({ .trim.starts-with($prefix) }).elems == 1;
}

# ---------- 1) 首次 refresh：加入 Extra/Gone、剔除 Missing1/Missing2 ----------
{
    my ($rc, $out, $err) = cli('refresh', $dist.absolute.Str);
    is $rc, 0, 'refresh 退出码 0';

    # 逐行断言：多个模块必须各占一行
    ok line-once($out, '+ Demo::Extra'), '「+ Demo::Extra」独占一行';
    ok line-once($out, '+ Demo::Gone'),  '「+ Demo::Gone」独占一行（.pm6 老包也被扫到）';
    ok line-once($out, '- Demo::Missing1'), '「- Demo::Missing1」独占一行';
    ok line-once($out, '- Demo::Missing2'), '「- Demo::Missing2」独占一行';

    my %m = meta-of($dist);
    ok (%m<provides><Demo::Extra>:exists), 'provides 含新增模块 Demo::Extra';
    is %m<provides><Demo::Extra>, 'lib/Demo/Extra.rakumod', '新增模块路径正确（正斜杠）';
    ok (%m<provides><Demo::Gone>:exists),  'provides 含新增的 .pm6 老包 Demo::Gone';
    is %m<provides><Demo::Gone>, 'lib/Demo/Gone.pm6', '老包路径保留 .pm6 扩展名';
    nok (%m<provides><Demo::Missing1>:exists), '磁盘上不存在的 Demo::Missing1 被剔除';
    nok (%m<provides><Demo::Missing2>:exists), '磁盘上不存在的 Demo::Missing2 被剔除';
    is %m<provides><Demo>, 'lib/Demo.rakumod', '原有正确条目保持不变';
}

# ---------- 2) 其余字段原样保留（refresh 只动 provides）----------
{
    my %m = meta-of($dist);
    is %m<name>,            'Demo-Dist',                    'name 原样保留';
    is %m<version>,         '1.2.3',                        'version 原样保留';
    is %m<auth>,            'demo:raku',                    'auth 原样保留';
    is %m<description>,     'refresh 测试夹具',              'description 原样保留';
    is %m<tags>.join(','),  'demo,test',                    'tags 原样保留';
    is %m<source-url>,      'https://example.com/demo.git',  'source-url 原样保留';
    is %m<depends>.join(','), 'JSON::Fast',                  'depends 原样保留';
}

# ---------- 3) 无改动：不重写文件 ----------
{
    my $before = $dist.add('META6.json').slurp;
    my ($rc, $out, $err) = cli('refresh', $dist.absolute.Str);
    is $rc, 0, 'refresh（无改动）退出码 0';
    ok $out.contains('未改动文件'), '无改动时明确提示「未改动文件」';
    is $dist.add('META6.json').slurp, $before, '无改动时文件内容逐字未变';
}

# ---------- 4) --dry：只预览，不写文件 ----------
{
    mk($dist.add('lib/Demo/New.rakumod'), "unit module Demo::New;\n");
    my $before = $dist.add('META6.json').slurp;
    my ($rc, $out, $err) = cli('refresh', $dist.absolute.Str, '--dry');
    is $rc, 0, 'refresh --dry 退出码 0';
    ok $out.contains('仅预览'), '--dry 明确提示未写入';
    ok line-once($out, '+ Demo::New'), '--dry 也照常逐行报出将要加入的模块';
    is $dist.add('META6.json').slurp, $before, '--dry 不写文件（内容逐字未变）';
}

# ---------- 5) 再去掉 --dry：新模块被真正写入 ----------
{
    my ($rc, $out, $err) = cli('refresh', $dist.absolute.Str);
    is $rc, 0, 'refresh（写入）退出码 0';
    ok (meta-of($dist)<provides><Demo::New>:exists), 'Demo::New 已写入 provides';
}

# ---------- 6) 错误路径：目录里没有 META6.json ----------
{
    my $empty = $tmp.add('Empty'); $empty.mkdir;
    my ($rc, $out, $err) = cli('refresh', $empty.absolute.Str);
    ok $rc != 0, '没有 META6.json 时非 0 退出';
    ok $err.contains('没有 META6.json'), '报错说清了原因';
}

# ---------- 7) 错误路径：META6.json 顶层是数组（坏元数据）----------
{
    my $bad = $tmp.add('Bad'); $bad.mkdir;
    $bad.add('META6.json').spurt('[1, 2, 3]');
    my ($rc, $out, $err) = cli('refresh', $bad.absolute.Str);
    ok $rc != 0, '顶层是数组的 META6.json → 非 0 退出';
    ok $err.contains('不是有效的 JSON 对象'),
        '报错指出顶层不是对象（而不是底层的 Odd number of elements 栈）';
}

done-testing;
