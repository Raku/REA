use lib 'lib';
use Test;
use RakuPM::HTTP;
use RakuPM::HTTP::Backend;

# 钉死两个「后端 ↔ HTTP 客户端 / 语言行为不匹配」的回归（都是 0.36.20 修的）：
#
#   1) If-None-Match 必须真的出现在【请求头】里。曾经把 headers 塞进 .new()，
#      而 HTTP::Tinyish 的构造选项叫 default-headers，headers 被静默丢弃 →
#      条件 GET 空转，TTL 一过就全量重下 10~18MB 的索引。只有
#      .get($url, headers => …) 才会真的发出去。
#   2) Tinyish 的超时必须真的生效。曾经传 max-time（实际选项是 timeout）→
#      curl 没有 --max-time，链路一停流就无限挂（Windows / WSL 都一样）。
#
# 0.82.0 起 HTTP 单后端（curl / Tinyish），故只测这一条路径。
# 全程走 127.0.0.1 本地假服务器，不触网。端口绑不上（受限沙箱 / CI 无 loopback
# 监听权限）时整文件 skip —— 不能把 zef install 的测试阶段搞挂。

plan 4;

sub inm-seen(@seen --> Bool) { so @seen.first({ $_ ~~ /:i 'If-None-Match' / }) }

# 绑一个本地监听端口（多试几个，避开占用 / 权限问题）
sub bind-server(Int $from, Int $to) {
    for $from .. $to -> $port {
        my $s = try { IO::Socket::INET.new(:localhost('127.0.0.1'), :localport($port), :listen) };
        next if $s ~~ Failure || !$s.defined;
        return ($s, $port);
    }
    Nil
}

my ($sock, $port) = bind-server(18910, 18940) // (Nil, 0);
unless $sock.defined {
    skip('无法绑定本地端口（受限环境），跳过线级 HTTP 用例', 4);
    exit 0;
}

# 单后端要真发请求，必须装有 HTTP::Tinyish（否则整文件 skip —— 线级用例无从测起）。
unless (try { require RakuPM::HTTP::Tinyish; True }) // False {
    skip('未安装 HTTP::Tinyish，跳过线级用例', 4);
    exit 0;
}

# 一个接受循环服务所有用例：
#   $mode='304'  → 回 304 并记录请求头；$mode='200' → 回 200 + hello；
#   $mode='hang' → accept 后不读不答（socket 由 @hangs 持着保持打开 → 客户端会挂住，
#                  用于验证调用侧超时；不需要另起 sleep 线程，那样会拖住进程退出）
my $mode = '304';
my @seen;
my @hangs;
my $stop = False;                    # 收尾时置 True + 连一个哨兵连接把 accept 唤醒
my $server = start {
    while (my $conn = try { $sock.accept }) {
        last if $stop;
        if $mode eq 'hang' { @hangs.push($conn); next }
        my @lines;
        while (my $line = $conn.get) {
            last if $line.chomp eq '';
            @lines.push($line.chomp);
        }
        @seen.push(|@lines);
        if $mode eq '304' {
            $conn.print("HTTP/1.1 304 Not Modified\r\n"
                      ~ "ETag: \"v1\"\r\nContent-Length: 0\r\nConnection: close\r\n\r\n");
        }
        else {
            $conn.print("HTTP/1.1 200 OK\r\nContent-Length: 5\r\nConnection: close\r\n\r\nhello");
        }
        try $conn.close;
    }
}
sleep 0.3;

# ---------- 1~2) 条件 GET：If-None-Match 真的进了请求头 ----------
{
    my $be = RakuPM::HTTP::Tinyish.new(:max-time(10));
    my $resp = $be.get-text-conditional("http://127.0.0.1:$port/y", :if-none-match('v1'));
    sleep 0.3;
    ok inm-seen(@seen), 'Tinyish：If-None-Match 真的出现在请求头里（不能塞进 .new）';
    ok $resp.not-modified, 'Tinyish：304 被识别为「未修改」';
}

# ---------- 3~4) 超时真的生效（停流的服务器上 2s 返回，而不是无限挂） ----------
{
    $mode = 'hang';
    my $t0 = DateTime.now.Instant;
    my $worker = start {
        my $r = try { RakuPM::HTTP::Tinyish.new(:max-time(2)).get-text("http://127.0.0.1:$port/slow"); 'ok' };
        # 注意：本 Rakudo 的 try 失败返回的是 Nil 而不是 Failure，不能用 ~~ Failure 判
        $r.defined ?? $r !! 'err'
    };
    # 自己守一道 20s 的闸：超时若失效，是【测试失败】而不是把整个套件挂住
    for ^200 { last if $worker.status ~~ Kept; sleep 0.1 }
    my $elapsed = (DateTime.now.Instant - $t0).round(0.1);
    my $done    = $worker.status ~~ Kept;

    ok $done && $elapsed < 15, "Tinyish：停流时 2s 超时生效（实测 {$elapsed}s，未无限挂）";
    is($done ?? $worker.result !! '-', 'err', 'Tinyish：超时后后端按失败处理（不是静默成功）');
}

# 收尾：先把服务器线程从 accept 里唤醒并让它退出，再关掉挂起的连接。
# 为什么要哨兵连接：Windows 上 close 掉正在 accept 的监听套接字【不保证】唤醒 accept，
# 服务器线程会一直阻塞、把整个进程吊住（实测能挂 10 分钟以上）。连一个本地连接令
# accept 立刻返回，循环看到 $stop 即退出。
$stop = True;
try { my $c = IO::Socket::INET.new(:host('127.0.0.1'), :port($port), :timeout(2)); $c.close }
try { .close } for @hangs;
END { try $sock.close }
