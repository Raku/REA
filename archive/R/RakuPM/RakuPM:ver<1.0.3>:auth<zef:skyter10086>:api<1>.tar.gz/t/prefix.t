use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Prefix;
use RakuPM::Platform;
use RakuPM::Fs;

# RakuPM::Prefix —— 「安装前缀」的唯一出处（0.49.0 新增）。
#
# 它存在的理由是**两个消费者不能互相依赖**：CLI 要在 require 模块图之前就知道
# 前缀，而 Client 要按「是否默认前缀」决定 promote-bin。这里钉住三件事：
#   ① 默认前缀只有一个答案；
#   ② 「是不是默认前缀」按路径值判、而不是按「有没有写 --target」判；
#   ③ 前缀解析顺序 --target > RAKUPM_TARGET > 默认，且 `~` 会被展开。
#
# ③ 是顺手修掉的真实缺陷（0.49.0 实测）：Rakudo **不展开 IO::Path 里的 `~`** ——
# `'~/.raku-pm'.IO.absolute` 得到的是 <当前目录>/~/.raku-pm。所以修复前
# `raku-pm --target=~/myenv install Foo` 会在当前目录下建一个字面叫 `~` 的目录。
# 这条既钉 Prefix 的实现，也钉住「入口必须展开」这个行为契约。

plan 21;

my $home = $*HOME.add('.raku-pm');
my $tmp  = $*TMPDIR.add("rakupm-prefix-{$*PID}");
LEAVE { rm-tree($tmp) if $tmp.defined && $tmp.e }

# ---------- 1. 默认前缀 ----------
is default-target().absolute.Str, $home.absolute.Str,
   '默认前缀 = ~/.raku-pm';
ok is-default-target(default-target()),
   '默认前缀被判为「默认」（自反）';
nok is-default-target($tmp),
   '临时目录不是默认前缀';

# ---------- 2. 路径值比较的各种形态 ----------
{
    my $with-slash = ($home.absolute.Str ~ '/').IO;
    ok is-default-target($with-slash), '尾部多一个斜杠仍算默认前缀';

    # 反斜杠/正斜杠混写（跨平台统一）
    my $mixed = $home.absolute.Str.subst("\x5C", '/', :g).IO;
    ok is-default-target($mixed), '分隔符写成正斜杠仍算默认前缀';
}

# 大小写：Windows 文件系统不敏感 → 同一前缀；Unix 敏感 → 不同前缀
{
    my $upper = $home.absolute.Str.uc.IO;
    if is-windows() {
        ok is-default-target($upper), 'Windows：大小写不同仍是同一个前缀';
    }
    else {
        nok is-default-target($upper), 'Unix：大小写不同是不同前缀';
    }
}

# ---------- 3. 前缀解析顺序 ----------
{
    my $a = $tmp.add('a');
    my $b = $tmp.add('b');
    is resolve().absolute.Str, $home.absolute.Str,
       '都不给 → 默认前缀';
    is resolve(:flag(''), :env('')).absolute.Str, $home.absolute.Str,
       '空串等同没给（不会解析成当前目录）';
    is resolve(:flag('   ')).absolute.Str, $home.absolute.Str,
       '纯空白同样等同没给';
    is resolve(:env($b.absolute.Str)).absolute.Str, $b.absolute.Str,
       '只给 RAKUPM_TARGET → 用它';
    is resolve(:flag($a.absolute.Str), :env($b.absolute.Str)).absolute.Str,
       $a.absolute.Str, '--target 优先于 RAKUPM_TARGET';
}

# ---------- 4. `~` 展开（真实缺陷的守护）----------
{
    my $r = resolve(:flag('~/rakupm-prefix-probe'));
    is canonical($r.Str), canonical($*HOME.add('rakupm-prefix-probe').Str),
       '--target=~/x 展开成 $HOME/x（修复前会建一个字面叫 `~` 的目录）';
    nok canonical($r.Str).contains('~'),
       '展开结果里不该再残留 `~`';
}

# ---------- 5. promote 策略 ----------
ok default-promote-bin(default-target()),
   '默认前缀 → 装完写全局 site/bin（保持 zef 同款「装完即用」）';
nok default-promote-bin($tmp),
   '自定义前缀 → 不写全局 site/bin（不污染整机环境）';

# ---------- 6. canonical 只用于比较 ----------
is canonical($home.absolute.Str ~ '//'), canonical($home.absolute.Str),
   'canonical 折掉多余与尾部斜杠';

# ---------- 7. 文件系统根判定（`flush` 的护栏用它）----------
# 抽成公开谓词就是为了这几条能被直接触发：根路径没法在测试里当 `flush` 的参数
# 构造出来（临时目录的 canonical 形式不可能是根）。
# 这几条**刻意不按平台分叉**：`C:` 那类在 Linux 上被认成根只是让护栏更严一点
# （没人会把前缀命名成 `C:`），而漏掉一个真根才是危险的。
ok is-fs-root('/'), '根 / 被认出';
ok is-fs-root('///'), '多个斜杠同样认作根（canonical 折叠后是 /）';
ok is-fs-root('C:\\'), 'Windows 盘根 C:\ 被认出';
ok is-fs-root('c:'), '裸盘符 c: 被认出 —— 必须在 normalize 之前判，否则会被绝对化成 <cwd>/c: 而漏掉';
nok is-fs-root($home.absolute.Str), '正常前缀目录不是根';
