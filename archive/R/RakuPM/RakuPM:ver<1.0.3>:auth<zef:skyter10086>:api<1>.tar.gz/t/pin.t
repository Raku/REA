use lib 'lib';
use Test;
use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::Repository;
use RakuPM::Resolver;

# 回归测试：--pin 依赖钉版（H8 正式修复）。
# 核心语义：pin 用精确约束 `= ver` 覆盖任何来路的约束（依赖方提出的、CLI 位置参数
# 给的），优先级最高；pin 到不存在的版本应报错；pin 还能统一两条互斥的依赖约束。

class MemRepo does RakuPM::Repository {
    has @.rows;
    method id(--> Str) { 'mem:pin' }
    method find-providers(Str $m --> List) {
        self.rows.grep({ $m (elem) @(.<provides>) }).map(*<name>).unique.List
    }
    method all-distributions(--> List) { self.rows.map(*<name>).unique.List }
    method available-versions(Str $n --> List) {
        self.rows.grep(*<name> eq $n).map(*<version>).unique.List
    }
    method fetch-distribution(Str $n, Str $v --> RakuPM::Distribution) {
        my $row = self.rows.first({ .<name> eq $n && .<version> eq $v });
        die "假仓库里找不到 $n $v" unless $row;
        RakuPM::Distribution.new:
            :name($row<name>),
            :version($row<version>),
            :provides(@($row<provides>)),
            :depends(RakuPM::Distribution.normalize-dependencies($row<depends> // {}));
    }
    method source-dir-for(Str $, Str $ --> IO::Path) { IO::Path }
}

sub resolver-for(@rows) {
    RakuPM::Resolver.new(:repos([MemRepo.new(:rows(@rows))]))
}

# 捕获异常消息（die 会打断后续用例，所以包一层 try）
sub resolve-all-err(@rows, @specs, %pins = %()) {
    try { resolver-for(@rows).resolve-all(@specs, :pins(%pins)) }
    $! ?? $!.Str !! ''
}

# ===== 场景：App 依赖 Foo('*')，仓库里 Foo 有 1.0 与 2.0 =====
my @rows =
    %( name => 'App', version => '1.0', provides => ['App'], depends => { 'Foo' => '*' } ),
    %( name => 'Foo', version => '1.0', provides => ['Foo'], depends => {} ),
    %( name => 'Foo', version => '2.0', provides => ['Foo'], depends => {} ),
;

# 不 pin 时，传递依赖 Foo 取最新 2.0
my @no-pin = resolver-for(@rows).resolve-all(
    (%( module => 'App', constraint => '' ),));
is @no-pin.map({ .name ~ ':' ~ .version }).sort.join(','), 'App:1.0,Foo:2.0',
   '不 pin 时传递依赖 Foo 取最新 2.0';

# pin Foo@1.0：传递依赖也被钉到 1.0（非最新）
my @pinned = resolver-for(@rows).resolve-all(
    (%( module => 'App', constraint => '' ),), :pins(%('Foo' => '1.0')));
is @pinned.map({ .name ~ ':' ~ .version }).sort.join(','), 'App:1.0,Foo:1.0',
   'pin 让传递依赖 Foo 选到非最新版 1.0';

# 顶层 pin：直接装 Foo，pin 1.0 而非最新 2.0
my @top = resolver-for(@rows).resolve-all(
    (%( module => 'Foo', constraint => '' ),), :pins(%('Foo' => '1.0')));
is @top[0].version, '1.0', '顶层 pin 让 Foo 选到 1.0 而非最新 2.0';

# 即便依赖方显式要了别的高版本，pin 仍优先（pin 优先级最高）
my @overrule =
    %( name => 'App', version => '1.0', provides => ['App'], depends => { 'Foo' => '2.0' } ),
    %( name => 'Foo', version => '1.0', provides => ['Foo'], depends => {} ),
    %( name => 'Foo', version => '2.0', provides => ['Foo'], depends => {} ),
;
my @over = resolver-for(@overrule).resolve-all(
    (%( module => 'App', constraint => '' ),), :pins(%('Foo' => '1.0')));
is @over.map({ .name ~ ':' ~ .version }).sort.join(','), 'App:1.0,Foo:1.0',
   '依赖方要 2.0 时，pin 1.0 仍然优先（钉版优先级最高）';

# pin 到不存在的版本 → 报错「找不到」
my $missing = resolve-all-err(@rows,
    (%( module => 'Foo', constraint => '' ),), %('Foo' => '9.9'));
ok $missing.contains('找不到'), 'pin 到不存在的版本 → 报错找不到该模块';
ok $missing.contains(q[找不到模块 'Foo']), '报错点名模块 Foo';
ok $missing.contains('9.9'), '报错带上被钉的版本 9.9';

# pin 统一两条互斥的依赖约束：A 要 3.0、B 要 4.0
my @conflict =
    %( name => 'A', version => '1.0', provides => ['A'], depends => { 'Foo' => '3.0' } ),
    %( name => 'B', version => '1.0', provides => ['B'], depends => { 'Foo' => '4.0' } ),
    %( name => 'Foo', version => '2.0', provides => ['Foo'], depends => {} ),
    %( name => 'Foo', version => '3.0', provides => ['Foo'], depends => {} ),
    %( name => 'Foo', version => '4.0', provides => ['Foo'], depends => {} ),
;
my $c-err = resolve-all-err(@conflict,
    (%( module => 'A', constraint => '' ), %( module => 'B', constraint => '' )));
ok $c-err.contains('依赖冲突'), 'A(要3.0) 与 B(要4.0) 不 pin 时冲突';

# pin Foo@2.0：两条约束都被覆盖成 =2.0，2.0 存在且一致 → 不冲突，选 2.0
my @c-res = resolver-for(@conflict).resolve-all(
    (%( module => 'A', constraint => '' ), %( module => 'B', constraint => '' )),
    :pins(%('Foo' => '2.0')));
is @c-res.map({ .name ~ ':' ~ .version }).sort.join(','), 'A:1.0,B:1.0,Foo:2.0',
   'pin 统一互斥约束：两条都被覆盖成 =2.0，选到 2.0、不冲突';

# ===== CLI 层：--pin 解析（不依赖网络，解析在构造 Client 之后、真正安装之前）=====
sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}
my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;
sub run-cli(*@args) {
    my $p = run($raku, '-Ilib', $bin, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}
{
    my ($code, $out, $err) = run-cli('install', 'Foo', '--pin=Bad');
    isnt $code, 0, 'pin 格式错误导致非 0 退出';
    ok ($out ~ $err).contains('无效的 --pin 写法'), 'pin 格式错误给出明确报错';
}
{
    my ($code, $out, $err) = run-cli('search', 'Foo', '--pin=x');
    isnt $code, 0, 'pin 用在不支持的命令上被拒';
    ok ($out ~ $err).contains('未知选项'), 'pin 用在不支持的命令上提示未知选项';
}

done-testing;
