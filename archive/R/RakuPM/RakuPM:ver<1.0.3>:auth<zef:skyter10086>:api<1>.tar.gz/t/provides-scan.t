use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;

# 「发行版 ↔ 磁盘 lib/」两个方向的单测（0.37.6）。
#
#   · provides-with-paths：模块名 → 发行版根相对路径（消费侧：Store 入库写 META6.json）
#   · scan-provides      ：扫 lib/ → 模块名（生产侧：refresh / new / check 用；
#                          等价于 mi6 的 AutoScanPackages）
#
# 两者原先一个藏在 Store 的私有方法里、一个根本不存在；现在都归到
# RakuPM::Distribution，是唯一实现处（同 Repository::Matching 的收敛理由）。
#
# 【扩展名口径】.rakumod / .pm6 / .pm 自 0.87.1 起只有一处定义 ——
# RakuPM::Distribution 里的 @MODULE-EXTS。别再往任何地方内联扩展名清单：
# 那份清单原先在两处各写一遍、都漏了 .pm，直接造成生态里的 .pm 包装完 use 不到
# （幽灵安装）。t/ghost-provides.t 里有一条静态守卫专门盯着这件事。
#
# 纯本地：不构造 Store、不碰网络、不安装任何东西。
#
# 注：断言里用标量 $scanned 接 List —— 赋给 `my @a` 会变成 Array，
# 而 is-deeply 按容器类型严格比较（Array eqv List 为 False）会假失败。

my $base = $*TMPDIR.add("rakupm-provides-scan-{$*PID}-" ~ now.floor);
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! (try $e.unlink) }
            try $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

# 建文件（必要时先建父目录，否则 spurt 报 No such file or directory）
sub mk(IO::Path $p, Str $content = '') {
    $p.parent.mkdir;
    $p.spurt($content);
}

my $root = $base.add('Demo-Dist');
$root.mkdir;

# lib/ 下铺各种情况
mk($root.add('lib/Foo.rakumod'),                "unit module Foo;\n");
mk($root.add('lib/Foo/Bar.rakumod'),            "unit module Foo::Bar;\n");
mk($root.add('lib/Foo/Baz.pm6'),                "unit module Foo::Baz;\n");     # 老包用 .pm6
mk($root.add('lib/Foo/Legacy.pm'),              "unit module Foo::Legacy;\n");  # 更老的包用 .pm（0.87.1 起才认）
mk($root.add('lib/HTTP/Client.rakumod'),        "unit class HTTP::Client;\n");  # 多级目录
mk($root.add('lib/Foo/Qux.rakudoc'),            "=begin pod\nQux docs\n=end pod\n");  # 文档，不是模块
mk($root.add('lib/README.md'),                  "# not a module\n");            # 非模块文件
mk($root.add('lib/.precomp/Junk/Only.rakumod'), "compiled junk\n");            # 派生字节码，跳过
mk($root.add('lib/Deep/.hidden/X.rakumod'),     "unit module X;\n");            # 隐藏目录段，跳过

# ---------- scan-provides：扫 lib/ 反推模块名 ----------
my $scanned = RakuPM::Distribution.scan-provides($root);
is-deeply $scanned, ('Foo', 'Foo::Bar', 'Foo::Baz', 'Foo::Legacy', 'HTTP::Client'),
    'scan-provides：扫出全部模块（含多级目录与 .pm6 / .pm 老包），顺序稳定';
nok $scanned.grep({ $_ eq 'Foo::Qux' }).elems,
    'scan-provides：.rakudoc 是文档，不算模块';
nok $scanned.grep({ $_ eq 'Junk::Only' }).elems,
    'scan-provides：跳过 .precomp（Rakudo 加载时生成的派生字节码）';
nok $scanned.grep({ $_ eq 'Deep::X' }).elems,
    'scan-provides：跳过以 . 开头的目录段（.hidden）';
nok $scanned.grep({ .contains('README') }).elems,
    'scan-provides：非模块扩展名（README.md）不算';

# ---------- provides-with-paths：模块名 → 发行版根相对路径 ----------
my %paths = RakuPM::Distribution.provides-with-paths($root,
    ['Foo', 'Foo::Bar', 'Foo::Baz', 'Foo::Legacy', 'HTTP::Client', 'Foo::Qux', 'Missing::Mod']);
is %paths<Foo>,          'lib/Foo.rakumod',         'provides-with-paths：Foo → lib/Foo.rakumod';
is %paths<Foo::Bar>,     'lib/Foo/Bar.rakumod',     'provides-with-paths：Foo::Bar → lib/Foo/Bar.rakumod';
is %paths<Foo::Baz>,     'lib/Foo/Baz.pm6',         'provides-with-paths：.pm6 老包也认';
is %paths<Foo::Legacy>,  'lib/Foo/Legacy.pm',       'provides-with-paths：.pm 老包也认（0.87.1 补的第三个扩展名）';
is %paths<HTTP::Client>, 'lib/HTTP/Client.rakumod', 'provides-with-paths：多级目录用正斜杠';
nok (%paths<Foo::Qux>:exists),
    'provides-with-paths：.rakudoc 不进 provides（0.37.3 的 C 修复规则没丢）';
nok (%paths<Missing::Mod>:exists),
    'provides-with-paths：文件不存在的模块直接跳过';

# ---------- 两个方向互为反向：scan 的结果应全部能映射回路径 ----------
my %roundtrip = RakuPM::Distribution.provides-with-paths($root, $scanned);
is-deeply %roundtrip.keys.sort.List, $scanned,
    '往返一致：scan-provides 的每个模块都能在 provides-with-paths 里找到路径';

# ---------- 边界：目标目录不存在时不崩 ----------
is RakuPM::Distribution.scan-provides($base.add('NoSuchDist')).elems, 0,
    'scan-provides：lib/ 不存在 → 空列表（不崩）';
is RakuPM::Distribution.provides-with-paths($base.add('NoSuchDist'), ['Foo']).elems, 0,
    'provides-with-paths：lib/ 不存在 → 空 Hash（不崩）';

done-testing;
