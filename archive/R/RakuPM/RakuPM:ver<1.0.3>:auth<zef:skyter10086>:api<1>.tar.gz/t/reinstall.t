use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;
use JSON::Fast;

# reinstall 命令的回归测试（全离线：本地目录仓库，不碰网络）。
#
# 覆盖：
#   1. 已装包 reinstall → 卸掉再按【完全相同版本】装回，账本版本号不变（不被升级）；
#   2. reinstall --dry → 只打印计划，不真正卸载（状态不变）；
#   3. 完全没装过的包 reinstall → 退化为一次普通 install（落入账本）。
# 这些保证 0.53.0 新增的 reinstall 行为正确，且复用 uninstall/install 不引入回归。

my $base = $*TMPDIR.add("rakupm-reinstall-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

sub make-dist($dir, :$name, :$version, :@provides, :$test) {
    $dir.mkdir;
    $dir.add('lib').mkdir;
    for @provides -> $mod {
        my $mf = $dir.add("lib/{$mod.subst('::', '/', :g)}.rakumod");
        $mf.parent.mkdir;
        $mf.spurt("unit module $mod;\nsay 'load $mod';\n");
    }
    if $test {
        $dir.add('t').mkdir;
        $dir.add('t/basic.t').spurt(qq:to/TEST/);
            use Test;
            plan 1;
            ok True, '$name 基本测试通过';
            TEST
    }
    my %meta = name => $name, version => $version, auth => 'demo:raku',
               provides => @provides;
    $dir.add('META6.json').spurt(to-json(%meta, :sorted-keys));
}

make-dist($base.add('RePkg'),   :name('RePkg'),   :version('1.0.0'),
          :provides(['Re::Pkg']), :test);
# 一个【在仓库里、但故意不先安装】的包，专门验 reinstall 的「退化成 install」分支
make-dist($base.add('FreshPkg'), :name('FreshPkg'), :version('0.5.0'),
          :provides(['Fresh::Pkg']), :test);

# 同上，但专门验【CLI 形态】的退化分支：CLI 在没给 --version 时曾把 version 兜底成
# 空串 ''，而上面 FreshPkg 走的是 API 直调（version 是【未定义】值）—— 两种形态在
# Client 里表现不同（`.chars` 都为假，但 `.defined` 一个真一个假），所以老测试一直绿，
# 用户用 CLI 却报"找不到模块"。这个包就是为「传空串」那条路径准备的。
make-dist($base.add('FreshPkg2'), :name('FreshPkg2'), :version('0.6.0'),
          :provides(['Fresh::Pkg2']), :test);

# 同包两个版本（DuoPkg 1.0.0 / 2.0.0），专门验 B2：reinstall 的规格串 :ver<>
# 约束被尊重，只重装匹配版本、不动其它版本。
make-dist($base.add('DuoPkg-1'), :name('DuoPkg'), :version('1.0.0'),
          :provides(['Duo::Pkg']), :test);
make-dist($base.add('DuoPkg-2'), :name('DuoPkg'), :version('2.0.0'),
          :provides(['Duo::Pkg']), :test);

my $repo   = RakuPM::Repository::Local.new(:root($base));
my $client = RakuPM::Client.new(:target($base.add('target')), :repos([$repo]));

sub installed-versions($n) {
    # 直接用 Installer 的多版本接口（委托 Ledger.versions-of，正确合并
    # <versions> 数组与 <version> 激活版；手搓 .map(*<version>) 会漏非激活版本）。
    $client.installer.installed-versions($n).List;
}

plan 21;

# ---- 先装 RePkg ----
{
    my $ok = try { $client.install('RePkg', ''); True }
    ok $ok.defined, 'install RePkg 成功（不抛）';
    my @v = installed-versions('RePkg');
    is @v.elems, 1, '装完后账本里 RePkg 恰一条';
    is @v[0], '1.0.0', '装上的版本是 1.0.0';
}

# ---- reinstall 已装包：版本不变、状态保留 ----
{
    my $ok = try { $client.reinstall('RePkg', ''); True }
    ok $ok.defined, 'reinstall 已装包不抛异常';
    my @v = installed-versions('RePkg');
    is @v.elems, 1, 'reinstall 后账本仍恰一条 RePkg';
    is @v[0], '1.0.0', 'reinstall 后版本仍是 1.0.0（未被解析成升级）';
}

# ---- reinstall --dry：只预览，不卸载 ----
{
    my $cap;
    {
        my $*OUT = open($base.add('dry.out'), :w);
        my $ok = try { $client.reinstall('RePkg', '', :dry); True }
        ok $ok.defined, 'reinstall --dry 不抛异常';
    }
    $cap = $base.add('dry.out').slurp;
    ok $cap.contains('重装'), 'reinstall --dry 打印重装计划（含「重装」字样）';
    my @v = installed-versions('RePkg');
    is @v.elems, 1, 'reinstall --dry 后仍已装（dry 没真正卸载）';
}

# ---- reinstall 未装过的包：退化为 install ----
{
    is installed-versions('FreshPkg').elems, 0, 'FreshPkg 起初未安装';
    my $ok = try { $client.reinstall('FreshPkg', ''); True }
    ok $ok.defined, 'reinstall 未装包退化为 install 不抛异常';
    is installed-versions('FreshPkg').elems, 1, '退化 install 后 FreshPkg 落入账本';
}

# ---- B2 回归：reinstall 规格串约束被尊重（只重装匹配版本）----
{
    # 同包两个版本都装好
    $client.install('DuoPkg', '', :version('1.0.0'));
    $client.install('DuoPkg', '', :version('2.0.0'));
    my @v = installed-versions('DuoPkg');
    is @v.sort.join(','), '1.0.0,2.0.0', 'DuoPkg 两个版本都装好';

    # 只重装 2.0.0：捕获输出，断言没有重装 1.0.0。
    # 修复前（B2）这里完全忽略约束，会把 1.0.0 和 2.0.0 都重装一遍。
    my $cap;
    {
        my $*OUT = open($base.add('b2.out'), :w);
        $client.reinstall('DuoPkg', '2.0.0');
    }
    $cap = $base.add('b2.out').slurp;
    ok $cap.contains('重装 DuoPkg:ver<2.0.0>'),
       'reinstall :ver<2.0.0> 重装了 2.0.0';
    nok $cap.contains('重装 DuoPkg:ver<1.0.0>'),
       'B2 修复后：reinstall :ver<2.0.0> 不再重装 1.0.0（之前会全部重装）';

    # 两个版本都还在（reinstall 是卸一个装一个，不动另一个）
    my @after = installed-versions('DuoPkg');
    is @after.sort.join(','), '1.0.0,2.0.0', 'reinstall 后两个版本仍在（只重装匹配的）';
}

# ---- 回归（0.88.4）：CLI 形态的【空串 version】不许把「退化 install」弄坏 ----
#
# 用户现场：`raku-pm reinstall <没装过的包>`（不带 --version）→
#   「在所有已配置的仓库里都找不到模块 'CSV::Table' (约束 = )」。
# 根因：CLI 把"没给 --version"兜底成空串 ''，而 Client 用 `.defined` 判断"有没有
# 指定版本" —— 空串是【已定义】的，于是 install 里得到 `"= "`（等于空版本）约束，
# 解析器谁都不匹配。本块**照 CLI 修复前的形态**传 `:version('')`，所以它能抓住这个
# 洞；而上面 FreshPkg 那块（version 传未定义值）抓不住 —— 这正是老测试漏掉它的原因。
{
    is installed-versions('FreshPkg2').elems, 0, 'FreshPkg2 起初未安装';
    my $ok = try { $client.reinstall('FreshPkg2', '', :version('')); True }
    ok $ok.defined, 'reinstall 未装包 + :version("")（CLI 修复前的兜底形态）不抛异常';
    my @v = installed-versions('FreshPkg2');
    is @v.elems, 1, '空串 version 走退化 install 后仍落入账本';
    is @v[0], '0.6.0',
       '装的是仓库里那个版本（修复前会因"= "约束而报「找不到模块」）';
}

# ---- 静态守卫：调 install / reinstall 的地方，version 的兜底值不许写成空串 ----
#
# 上面那条行为断言守的是 Client 侧；这里守**发生地**：CLI 传参表达式。两处都要守 ——
# Client 侧的加固被删掉不会有任何行为测试变红（除非 CLI 同时退回空串），而 CLI 侧退回
# 空串则会把"未定义"这个正确语义悄悄丢掉。
#
# 【为什么只守 install / reinstall，不一刀切禁掉所有 `:version(… !! '')`】
#   · `install` 的签名是 `Str :$version`（**没有默认值**），内部用 `$version.defined`
#     判断"有没有指定版本" → 空串（已定义）会被当成"指定了空版本" ⇒ 这就是本 bug。
#   · 而 `upgrade` / `uninstall` / `fetch`（Client/Git）/ `look`（Client/Git）的签名是
#     `Str :$version = ''`，**它们就是用空串表示"没指定"** ⇒ 那几处 `!! ''` 是对的。
#   一刀切会把 4 处正确写法误报成红，所以按"被调方语义"来守：只看传给 install /
#   reinstall 的那些。
{
    my @lines = $*PROGRAM.parent.parent.add('lib/RakuPM/CLI.rakumod').slurp.lines;
    my @bad;
    for @lines.kv -> $i, $line {
        next unless $line.contains('$client.install(') || $line.contains('$client.reinstall(');
        my Int $last = min($i + 20, @lines.end);   # 注意：`min` 是子例程，`(20).min(...)` 不是方法
        for @lines[$i + 1 .. $last].grep({ .contains(':version(') }) -> $vl {
            @bad.push($vl.trim) if $vl.contains("!! ''");
        }
    }
    nok @bad.elems,
       '调 install/reinstall 时 version 的兜底值不是空串（须与 install 一致用未定义 Str）'
       ~ (@bad.elems ?? '｜命中：' ~ @bad.join(' / ') !! '');
}
