use lib 'lib';
use Test;

# A2 回归：upgrade 不带包名默认升级全部，跑前应打印一句醒目提示，
# 且不阻塞（不要求输入，避免卡 CI / 脚本）。--offline 下 upgrade-all
# 会因 assert-online 快速失败，但提示在此之前已输出，可断言命中。

my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;

sub run-cli(*@args) {
    my $p = run($raku, '-Ilib', $bin, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

my $tmp = $*TMPDIR.add("rakupm-upg-warn-{$*PID}");
$tmp.mkdir;
LEAVE { try rmrf($tmp) }
sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

# ---- 不带名 + 非 --dry：应打印升级全部提示 ----
{
    my $tgt = $tmp.add('empty').absolute.Str;
    my ($code, $out, $err) = run-cli('upgrade', "--target=$tgt", '--offline');
    my $all = $out ~ $err;
    ok $all.contains('将升级【全部已装包】到最新版'),
       'upgrade 不带名时打印「升级全部」醒目提示（A2）';
    ok $all.contains('raku-pm upgrade <包名>'),
       '提示里引导用户显式指定包名（A2）';
}

# ---- 带 --dry：试算不应再打印该提示（避免噪声） ----
{
    my $tgt = $tmp.add('empty2').absolute.Str;
    my ($code, $out, $err) = run-cli('upgrade', "--target=$tgt", '--offline', '--dry');
    my $all = $out ~ $err;
    ok !$all.contains('将升级【全部已装包】到最新版'),
       'upgrade --dry 不带名时不打印升级全部提示（A2）';
}

done-testing;
