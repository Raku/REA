use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Builder;

# Builder.!quote 的回归测试 —— 把路径塞进 Raku 单引号字符串前的转义。
#
# 背景（实测钉死的 bug）：
#   原实现只把 ' 转成 \'，不处理反斜杠。于是路径【以反斜杠结尾】时
#   （C:\Users\user\、盘符根 C:\），末尾的 \ 与收尾的 ' 连成 \' ——
#   被解析成转义的引号，字符串没闭合，生成的 -e 代码直接编译失败
#   （实测 exit=1 / ===SORRY!===）。Windows 路径必然含 \，所以是必现。
#   修法：先把 \ 转义成 \\，再把 ' 转义成 \'（顺序不能反）。
#
# 另外 builder 名（$bn）原先直接进 q|$bn| —— 名字里含 | 会提前闭合分隔符，
# 后半截被当成代码拼进 -e（恶意包可注入）。改成走单引号 + !quote。

# !quote 是私有方法，测试里用元对象内省调用（第一个参数是 invocant）。
my $builder = RakuPM::Builder.new;
my &quote = RakuPM::Builder.^find_private_method('quote');

sub q(Str $p --> Str) { &quote($builder, $p) }

# ---------- 1. 转义结果的单元验证 ----------
{
    my $bs = chr(92);
    my $q  = chr(39);

    # 反斜杠必须被双写（否则末尾反斜杠会吃掉收尾引号）
    is q("C:\\Users\\user\\"), "C:\\\\Users\\\\user\\\\" .subst('\\\\', $bs x 2, :g),
       '反斜杠被双写（含结尾反斜杠）';

    # 单引号被转义成 \'
    is q("C:\\path\\with'single"), "C:\\\\path\\\\with\\'single".subst('\\\\', $bs x 2, :g),
       '单引号被转义成反斜杠+引号';

    # 普通 Unix 路径不受影响（没有反斜杠也没有引号 → 原样返回）
    is q('/home/user/pkg'), '/home/user/pkg', '普通 Unix 路径原样返回';

    # 顺序不能反：先 \ 后 '。若先转义 ' 再把 \ 双写，刚生成的 \' 会变成 \\'
    ok q("a'b").contains("\\'"), "转义结果含 \\'（顺序正确：先 \\ 后 '）";
}

# ---------- 2. 端到端：把转义结果放进 Raku 代码，能编译且值不变 ----------
# 这是真正的验收标准 —— 转义对不对，编译器说了算。
for (
    "C:\\Users\\user\\",            # 结尾反斜杠（原实现在这里炸）
    "C:\\Users\\user",              # 普通 Windows 路径
    "C:\\path\\with'single",         # 含单引号
    '/home/user/pkg',                 # 普通 Unix 路径
    'C:\\',                          # 盘符根
) -> $path {
    my $esc = q($path);
    my $code = "my \$x = '$esc'; print \$x;";
    my $proc = run('raku', '-e', $code, :out, :err);
    my $out  = ($proc.out.slurp(:close) // '') if $proc.out;
    my $err  = ($proc.err.slurp(:close) // '') if $proc.err;
    my $ok   = $proc.exitcode == 0 && ($out // '') eq $path;
    ok $ok, "转义后能编译且值不变：{$path.raku}"
          ~ ($ok ?? '' !! " (exit={$proc.exitcode} out={($out//'').raku} err={($err//'').lines[0] // ''})");
}

# ---------- 3. 回归对照：只转义 ' 不转义 \ 的旧实现会炸 ----------
# 把这个「错误实现」也端到端跑一遍，确认它确实在结尾反斜杠上失败。
# 钉死这个反例，防止以后有人把 !quote「简化」回去。
{
    my $q-ch = chr(39);
    sub old-quote(Str $p --> Str) { $p.trans([$q-ch] => [chr(92) ~ $q-ch]) }

    my $path = "C:\\Users\\user\\";
    my $code = "my \$x = '" ~ old-quote($path) ~ "'; print \$x;";
    my $proc = run('raku', '-e', $code, :out, :err);
    ($proc.out.slurp(:close) // '') if $proc.out;
    ($proc.err.slurp(:close) // '') if $proc.err;
    nok $proc.exitcode == 0,
        '反例：旧实现（不转义反斜杠）在结尾反斜杠路径上编译失败';
}

# ---------- 4. builder 名不再用 q|...|（防 | 注入）----------
{
    # 源码里应当找不到 q|$bn| 这种写法
    my $src = $*PROGRAM.parent.parent.add('lib/RakuPM/Builder.rakumod').slurp;
    nok $src.contains('q|$bn|'),
        '源码不再用 q|$bn| 做 builder 名分隔符（含 | 会被截断）';
    ok  $src.contains("::('\$esc-bn')"),
        'builder 名走单引号 + !quote 转义';
}

done-testing;