use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use lib $*PROGRAM.parent.parent.add('tools').Str;
use NamedArgCheck;

# NamedArgCheck 的测试。
#
# 这个工具的价值全在「能不能抓到真问题」—— 而它的第一版（0.44.0 的
# t/named-args.t）恰恰是**假绿**：扫到了 67 个 routine 定义，但形参集合始终为空
# → 所有命中都被误判成「已声明」→ 检查器永远输出"通过"。
# 所以这里每个场景都是「喂人造源码 → 断言报 / 不报」，而不是只断言"能跑"。
#
# 最后一条是**项目自检**：把整棵仓库丢进去必须 0 嫌疑。它同时是门禁的守护
# （有人在 lib 里写下 :no-tets 这类拼错时，这条会红）。

plan 13;

my $decl = q:to/SRC/;
unit class Demo;
has Str $.path;
has $!token;
method store(Str :$version, Bool :$force) { }
method go(Str :$name) { }
SRC

sub names-of(@f --> Str) { @f.map(*<name>).sort.join(',') }

sub findings-for(Str $call --> List) {
    check-texts('demo.rakumod' => ($decl ~ "\n" ~ $call ~ "\n"))
}

# ① 真 bug：形参叫 :version，调用点写成 :ver（项目里栽过的同款）
{
    my @f = findings-for("Demo.new.store(:ver('1.0'));");
    is names-of(@f), 'ver', '① 抓到 :ver（形参其实叫 :version）';
}

# ② 正确写法不报
{
    is names-of(findings-for("Demo.new.store(:version('1.0'), :force);")), '',
       '② 正确名字不报';
}

# ③ 属性绑定：has $.path ↔ .new(:$path)
{
    is names-of(findings-for("Demo.new(:path('/tmp'), :token('t'));")), '',
       '③ 属性名算已声明（has $.path / has $!token）';
}

# ④ 核心 API 白名单
{
    is names-of(findings-for("run('x', :out, :err, :cwd('/tmp'));")), '',
       '④ 核心 API（run 的 :out/:err/:cwd）在白名单里';
}

# ⑤ 类型笑脸不是具名实参
{
    is names-of(findings-for("my Str:D \$s = 'a'; say \$s;")), '',
       '⑤ Mu:D / Str:D 类型笑脸不算 colonpair';
}

# ⑥ 包分隔符不是 colonpair
{
    is names-of(findings-for("use RakuPM::Client::SelfManager;")), '',
       '⑥ RakuPM::Foo::Bar 的 :: 不算 colonpair';
}

# ⑦ Hash 字面量的键不算具名实参
{
    is names-of(findings-for("my %h = %( :url('u'), :zzz(1) );")), '',
       '⑦ %( ... ) 里的键豁免（Hash 字面量）';
}

# ⑧ 行注释里的 colonpair 不算
{
    is names-of(findings-for("my \$x = 1;  # 用 :ver<> 指定版本")), '',
       '⑧ 行注释里的 :ver 不报';
}

# ⑨⑩ heredoc：内容要遮蔽，但【不能一路吞下去】
{
    my $hd = "my \$doc = q:to/DOC/;\n用法：:nope\nDOC\nDemo.new.store(:ver(1));\n";
    my @f = check-texts('hd.rakumod' => ($decl ~ "\n" ~ $hd));
    nok names-of(@f).contains('nope'), '⑨ heredoc 内容里的 :nope 不报';
    ok  names-of(@f).contains('ver'),  '⑩ heredoc 结束后代码恢复正常（遮蔽没一路吞掉后面）';
}

# ⑪ 多行签名的形参也要收全
{
    # 注意 `\{ \}` 的转义：双引号串里的 { } 是【插值块】，空块会返回 Nil
    # 并打一句 "Use of Nil in string context"（作者在这里踩过一次）。
    my $multi = "unit class D2;\nmethod m(\n    Str :\$alpha,\n    Bool :\$beta,\n) \{ \}\n";
    my @f = check-texts('d2.rakumod' => ($multi ~ "\nD2.new.m(:alpha('a'), :beta);\n"));
    is names-of(@f), '', '⑪ 跨行签名的形参收全（:alpha/:beta 都认）';
}

# ⑫ 反向保护：起始判据误判（有起始行、却没有结束标记）时不能一路吞掉后面
#    —— 单遍实现会遮蔽到文件末尾，把后面的真实代码静默吃掉（0.46.1 修的就是它）
{
    my $bad = "my \$s = q:to/NEVER/;\nDemo.new.store(:ver(1));\n";
    my @f = check-texts('bad.rakumod' => ($decl ~ "\n" ~ $bad));
    ok names-of(@f).contains('ver'),
       '⑫ 结束标记不存在时不当作 heredoc（否则会静默吞掉后面整段代码）';
}

# ⑬ 项目自检：整棵仓库必须 0 嫌疑
{
    my $root = $*PROGRAM.parent.parent;
    my @f = check-named-args($root);
    is @f.elems, 0, '⑬ 项目自身 0 嫌疑（工具对自己也要成立）';
    diag '  嫌疑明细 = ' ~ @f.raku if @f.elems;
}
