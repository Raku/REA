use Test;
use RakuPM::Distribution;
use RakuPM::Store;

# 回归：store 条目不得携带 .precomp（预编译字节码）。
#
# 背景：!copy-tree 以前把源码 lib/ 整个搬进 store，连 lib/.precomp 一起。
# 实测一份 RakuPM：源码 lib 只有 224KB，而 lib/.precomp 有 3.8MB（49 文件），
# 是源码的 17 倍。后果有两个：
#   1) store 无谓膨胀；
#   2) !fingerprint 用纯 Raku MD5（~0.2MB/s）把这几 MB 全读一遍算哈希，
#      单版本就要十几秒 —— `raku-pm store` 在多版本 RakuPM 上「卡住」就是它。
# .precomp 是派生产物（装包时会重新生成），本来就不该进 store。

my $base = $*TMPDIR.add("rakupm-store-precomp-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

plan 6;

# 造一个"源码目录"，lib/ 里带 .precomp（模拟真实 git checkout / 装过的目录）
my $src = $base.add('src');
$src.mkdir;
$src.add('lib').mkdir;
$src.add('lib/Foo.rakumod').spurt("unit module Foo;\n");
my $pc = $src.add('lib/.precomp');
$pc.mkdir;
# 内容不必大——这里只验证「有没有被排除」，不是压测性能
$pc.add('CACHEDIR.TAG').spurt("Signature: 8a477f597d28d172789f06886806bc55\n");
$pc.add('blob.repo-id').spurt("fake-precomp-bytecode\n");
$src.add('META6.json').spurt(q:to/META/);
    { "name": "Foo", "version": "1.0.0", "auth": "t:me",
      "provides": { "Foo": "lib/Foo.rakumod" } }
    META

my $store = RakuPM::Store.new(:root($base.add('store')));
my $dist  = RakuPM::Distribution.new(
                :name('Foo'), :version('1.0.0'), :auth('t:me'),
                :provides(['Foo']));

my $digest = $store.put($dist, $src);
ok $digest.chars, 'put 返回了内容指纹';

my $entry = $store.path-for('Foo', '1.0.0');

ok !$entry.add('lib/.precomp').e,
   'store 条目里不含 .precomp（否则指纹计算会慢十几倍）';
ok $entry.add('lib/Foo.rakumod').e,
   '真正的源码文件仍然收进了 store';
ok $entry.add('META6.json').e, 'META.json 仍然写进了 store';

# 指纹必须与「当前条目内容」自洽——排除 .precomp 后 digest 是重算过的，
# 不能拿老算法的值来比（老条目含 .precomp，digest 当初也含它，二者各自自洽）。
ok $store.verify('Foo', '1.0.0'),
   '新条目的指纹与自身内容一致（verify 通过）';

# 不能误改源目录
ok $src.add('lib/.precomp').d,
   '源码目录自己的 .precomp 没有被破坏（只影响 store 副本）';

done-testing;
