# 测试辅助：操作一把 FileLock，供 t/file-lock.t 与 t/file-lock-token.t 起子进程
# 验证跨进程互斥 / 锁凭证继承。
#
# 用法：raku -Ilib t/file-lock-helper.raku <锁文件路径> <秒数> [mode] [额外参数]
#   mode=hold（默认）：拿锁 → 打印 "HELD <pid>" → 持 N 秒 → 释放 → 打印 RELEASED
#   mode=try        ：只试一次（:timeout(0)），打印 GOT 或 FAIL 后退出
#   mode=hold-flag  ：拿锁 → 打印 HELD → 等第 4 个参数指定的【旗标文件】出现
#                     → 释放 → 打印 RELEASED。测试用它精确控制持有窗口，
#                     不靠猜时长（固定 sleep 的跨进程测试在慢机器上必闪。）
#   mode=waittry    ：走 Client.with-write-lock（:timeout(0)）试一次：
#                     旁路放行则打印 BYPASSED/DONE，被挡则 BLOCKED。
#                     第 4 个参数是 target 目录（Client 的写目标）。
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::FileLock;
use RakuPM::Client;
use RakuPM::Repository::Local;

my ($path, $secs, $mode) = @*ARGS;
my $extra = (@*ARGS[3] // '');

if ($mode // '') eq 'try' {
    my $lock = RakuPM::FileLock.new(:path($path.IO));
    my $ok   = (try { $lock.acquire(:what('helper 试锁'), :timeout(0), :wait(False)); True }) // False;
    say $ok ?? 'GOT' !! 'FAIL';
    exit 0;
}

if ($mode // '') eq 'hold-flag' {
    my $flag = $extra.IO;
    my $lock = RakuPM::FileLock.new(:path($path.IO));
    $lock.acquire(:what('helper 持锁'), :timeout(30));
    say "HELD {$*PID}";
    $*OUT.flush;
    loop { last if $flag.e; sleep 0.05 }
    $lock.release;
    say "RELEASED {$*PID}";
    exit 0;
}

if ($mode // '') eq 'waittry' {
    # 让 Client 用调用方指定的锁文件（默认按 target 推导，这里显式钉死，
    # 保证子进程与父进程看的是同一个锁）。
    %*ENV<RAKUPM_LOCK_FILE> = $path;
    my $target = ($extra.chars ?? $extra.IO !! $path.IO.parent);
    my $client = RakuPM::Client.new(
        :target($target), :repo-root('.'),
        :repos(RakuPM::Repository::Local.new(:root($target))),
    );
    # :timeout(0) —— 拿不到就立刻放弃，好在测试里区分「放行」与「排队」。
    # 旁路成功时根本不会走到 acquire，block 直接执行 → 打印 BYPASSED。
    my $ok = (try {
        $client.with-write-lock({ say 'BYPASSED' }, :what('helper 试锁'), :timeout(0));
        True
    }) // False;
    say $ok ?? 'DONE' !! 'BLOCKED';
    exit 0;
}

my $lock = RakuPM::FileLock.new(:path($path.IO));
$lock.acquire(:what('helper 持锁'), :timeout(30));
say "HELD {$*PID}";
$*OUT.flush;
sleep ($secs // 3).Int;
$lock.release;
say "RELEASED {$*PID}";
