# 回归测试：Windows 已知测试失败豁免名单（known-windows-test-failures.json）
#
# H6 把 Tester.is-known-windows-test-failure 里写死的 Log::Async 逻辑外置成 JSON。
# 这里锁定【数据文件本身】的契约，确保「规则的唯一真相来源是 JSON、不是代码里
# 的硬编码」—— 一旦有人把规则又写回代码、或改坏 JSON 结构，这份测试就报警。
#
# 配套行为测试在 t/known-test-failure.t（它直接打 is-known-windows-test-failure，
# 而该函数读的就是本 JSON；删掉本文件会让它在 Windows 上变红 —— 即变异验证）。

use JSON::Fast;
use Test;

my $json = $?FILE.IO.parent.add('..').add('lib').add('RakuPM').add('Client')
                .add('known-windows-test-failures.json');

ok $json.e && $json.r, '数据文件存在且可读';

my @rules = from-json($json.slurp);
ok @rules.elems > 0, '规则数组非空';

# 必须含 Log::Async 这条（历史上写死在代码里、最易被人误改回硬编码的）
my %la = @rules.first({ .<name> // '' eq 'Log::Async' });
ok %la.elems, '含 Log::Async 规则';

is %la<test-starts-with> // '', '12-context',
   'Log::Async 规则按测试文件名前缀 12-context 过滤';

my @needles = %la<contains> ~~ Array ?? %la<contains>.list !! ();
ok @needles.elems >= 2, 'Log::Async 规则含失败特征子串列表';
ok @needles.grep(*.Str.contains('Log\\Async.rakumod')), '含 Windows 反斜杠形态';
ok @needles.grep(*.Str.contains('Log/Async.rakumod')),  '含正斜杠形态';

# 字段契约：每条规则必须带 name 与 contains（否则不会真正匹配，纯噪声）
for @rules -> %r {
    ok (%r<name> // '').chars, "规则 {(%r<name>//'?').Str} 有 name";
    my @c = %r<contains> ~~ Array ?? %r<contains>.list !! ();
    ok @c.elems > 0, "规则 {(%r<name>//'?').Str} 有 contains 子串列表";
}

done-testing;
