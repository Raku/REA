use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Help;
use RakuPM::CliSpec;

# ---------------------------------------------------------------------------
# help 分级（0.78.0）：RakuPM::Help 把原先一坨 358 行的 help 正文拆成三层
#   · help-summary  —— 默认：紧凑分组索引（必须一屏内）
#   · help-command  —— raku-pm help <命令>：单命令详情
#   · help-all      —— raku-pm help all：完整手册
#
# 这里守两件事：
#   ① 分层本身正确（summary 紧凑、command 给详情、all 是合集、未知命令为空）；
#   ② summary 的【完备性】—— 命令与别名都从 CliSpec 现取，必须一个不漏
#      （xt/cli-output-stability.t 从 CLI 端也守这件事，这里从模块端再守一遍）。
# ---------------------------------------------------------------------------

my $s = help-summary();

ok $s.lines[0].contains('用法'), 'summary：首行是用法说明';
ok $s.lines.elems <= 40, "summary：紧凑到一屏内（实际 {$s.lines.elems} 行）";

# 完备性：所有规范命令（除 help 自身）都出现
my @miss-cmd = cmd-flags().keys.grep({ $_ ne 'help' && !$s.contains($_) }).sort;
is @miss-cmd.join(', '), '', "summary：列出全部规范命令（漏：{@miss-cmd.join(', ') || '无'}）";

# 完备性：所有别名都出现
my @miss-alias = cmd-aliases().keys.grep({ !$s.contains($_) }).sort;
is @miss-alias.join(', '), '', "summary：列出全部别名（漏：{@miss-alias.join(', ') || '无'}）";

# 幂等：同一进程内两次调用字节一致
is help-summary(), $s, 'summary：幂等（两次字节一致）';

# ---- 索引里的分组导航（0.84.0）----
# 动机：author（8 个发布相关命令）/ dev 两组对「只装别人包」的用户是纯噪声，
# 但删命令是破坏性的。折中是两层导航：① 索引里给这两个组一句注记（这组要不要看）；
# ② `raku-pm help <组名>` 给分组总览。这里守住「注记与入口确实在」。
ok $s.contains('只装别人包不需要'), 'summary：作者侧有「这组要不要看」的注记';
ok $s.contains('help <组名>'),     'summary：给出分组总览的入口提示';

# ---- help-group：分组总览（`raku-pm help author`）----
my $ga = help-group('author');
ok $ga.chars > 0, 'help-group：author 有内容';
ok $ga.contains('作者侧'), 'help-group：标题用中文组名';
ok $ga.contains('发布'),   'help-group：说清这组是发布/打包用的';

# 完备性：组内每个命令都出现在总览里（组内命令从 CliSpec 现取，漏一个即红）
my @author-cmds = cmd-flags().keys.grep({ command-group($_) eq 'author' }).sort;
my @miss-g = @author-cmds.grep({ !$ga.contains($_) }).sort;
is @miss-g.join(', '), '', "help-group：author 总览列出全部组内命令（漏：{@miss-g.join(', ') || '无'}）";

is help-group('作者侧'), $ga, 'help-group：中文标题与英文组名等价';
is help-group('author'), $ga, 'help-group：幂等（两次字节一致）';
is help-group('nosuch'), '', 'help-group：未知分组返回空';
ok help-group('packages').chars > 0, 'help-group：packages 也有总览（不是只给 author 特判）';

# ---- help-command：单命令详情 ----
ok help-command('install').chars > 0, 'help-command：install 有内容';
ok help-command('install').contains('install'), 'help-command：install 详情含命令名';
ok help-command('install').lines.elems > 3, 'help-command：install 是详细用法（多行）';
is help-command('rdep'), help-command('rdepends'), 'help-command：别名 rdep 归一到 rdepends';
is help-command('i'),    help-command('install'),  'help-command：别名 i 归一到 install';
is help-command('nope'), '', 'help-command：未知命令返回空';

# ---- known-command ----
ok known-command('install'), 'known-command：认得 install';
ok known-command('rdep'),    'known-command：认得别名 rdep';
nok known-command('nope'),   'known-command：不认得 nope';

# ---- help-all：完整手册 ----
my $all = help-all();
ok $all.contains('用法'), 'help-all：含 summary 段';
ok $all.contains('锁文件'), 'help-all：含总览主题（锁文件）';
ok $all.contains('环境变量'), 'help-all：含环境变量主题';
ok $all.lines.elems > 300, "help-all：是完整手册（实际 {$all.lines.elems} 行）";

done-testing;
