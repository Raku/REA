# http-post-json.t —— 验证 RakuPM::HTTP.post-json 的真实 wire 契约输出
#
# 背景（真实端到端验证发现）：42.zef.pm/login 的 from-body 只认 application/json，
# 发 multipart/form-data 会让服务端 500（「Odd number of elements found where hash
# initializer expected」）。post-json 就是为此新增的 JSON POST 方法（login 专用）。
#
# 本测试用「假 curl」（RAKUPM_CURL 指向一个 .raku 脚本）捕获 post-json 实际生成的
# 命令行参数，断言：
#   · 含 -H 'Content-Type: application/json'
#   · 含 -d '<json>'，且 JSON 体可解析、含 username/password
#   · 不含 -F（确认不是 multipart）
#   · 带 auth 时含 -H 'Authorization: Zef <key>'
# 全程不联网：assert-online 在离线标志未置时放行，假 curl 只记录参数、模拟 200。

use Test;
use RakuPM::HTTP;
use JSON::Fast;

plan 9;

my $tmp      = ($*TMPDIR // '/tmp'.IO).absolute.IO;
my $rec-file = $tmp.add("rakupm-pj-rec-{($*PID)}.args");
my $fake     = $tmp.add("rakupm-pj-fakecurl-{($*PID)}.raku");

# 假 curl：把 @*ARGS 落盘，向 -o 目标写一个模拟成功 JSON，向 stdout 打印 200。
$fake.spurt: q:to/RAKU/;
    my $rec = %*ENV<RAKUPM_FAKECURL_REC>;
    spurt($rec, @*ARGS.join("\n") ~ "\n");
    my $out;
    for @*ARGS.kv -> $i, $a {
        $out = @*ARGS[$i + 1] if $a eq '-o';
    }
    if $out.defined && $out.chars {
        spurt($out, '{"success":true,"api-key":"fakekey123"}');
    }
    $*OUT.print("200\n");
    $*OUT.flush;
RAKU

my $fake-path = $fake.absolute.Str;
%*ENV<RAKUPM_CURL>        = $fake-path;
%*ENV<RAKUPM_FAKECURL_REC> = $rec-file.absolute.Str;
%*ENV<RAKUPM_OFFLINE>     = '0';          # 不置离线标志 → assert-online 放行

# ---- 不带 auth 的 JSON POST ----
if $rec-file.e { $rec-file.unlink }
my %resp = RakuPM::HTTP.new.post-json(
    'https://42.zef.pm/login',
    :json(%('username' => 'u1', 'password' => 'p1')),
);
ok %resp<ok>,                 'post-json 模拟成功（ok=True）';
is %resp<status>, 200,        'post-json 模拟状态码 200';

my @args = $rec-file.e ?? $rec-file.slurp.lines.List !! ();
ok @args.grep(*.contains('Content-Type: application/json')),
   '命令行含 -H Content-Type: application/json';
ok @args.grep(* eq '-F').elems == 0,
   '命令行不含 -F（不是 multipart）';

# 找到 -d 后的 JSON 体，解析并断言含 username/password
my $d-idx = @args.first({ $_ eq '-d' }, :k);
ok ?$d-idx.defined,           '命令行含 -d（JSON 请求体）';
my $json-body = @args[$d-idx + 1] // '';
my $parsed;
try { $parsed = from-json($json-body) }
ok $parsed.defined && ($parsed ~~ Associative),
   'JSON 体可被解析为对象';
is ($parsed<username> // ''), 'u1', 'JSON 体含 username=u1';
is ($parsed<password> // ''), 'p1', 'JSON 体含 password=p1';

# ---- 带 auth 的 JSON POST ----
if $rec-file.e { $rec-file.unlink }
%resp = RakuPM::HTTP.new.post-json(
    'https://42.zef.pm/login',
    :json(%('username' => 'u2', 'password' => 'p2')),
    :auth('realkey999'),
);
@args = $rec-file.e ?? $rec-file.slurp.lines.List !! ();
ok @args.grep(*.contains('Authorization: Zef realkey999')),
   '带 auth 时命令行含 -H Authorization: Zef <key>';

# 清理
try $rec-file.unlink;
try $fake.unlink;
