use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client::Query;
use RakuPM::Fs;

# `raku-pm env` 的「敲 raku-pm 实际跑哪一份」判定。
#
# 0.48.0 修的两件事，这里各钉一条：
#   ① 顺序以前来自 which/where 的输出，而 Windows 的 where 会按自己的顺序列
#      （实测：无扩展名 → .bat → .exe），与系统解析（PATHEXT：.EXE 优先）不符
#      → env 指错了「实际执行的那份」。现在自己按 PATH×PATHEXT 模拟解析。
#   ② 目录顺序优先于扩展名优先级：PATH 靠前的目录里的 .bat 胜过后一个目录里的 .exe。
#      这一点常被搞反 —— 只有**同一目录内**才是扩展名说了算。
#
# 【0.49.2 修：本文件以前是「只在 Windows 上能过」的测试】
# 用户现场（WSL/Linux）：`raku-pm install .` 跑到 t/ 时本文件必红 ——
# 上面两条断言写的是 Windows 语义（目录里放 `.bat`/`.exe`），但**没有注入平台**，
# 于是 Linux 上 exec-suffixes 只认无扩展名、一个候选都找不到；测试红了就把整次
# 安装回滚（0.49.1 无法在 Linux 上装起来）。
# 被测逻辑本身没问题（唯一判定处 Platform.pick-command-file 是对的），
# 错在**测试把宿主当成了被验对象**。现在两套语义都用 `:os('win32'/'linux')` 注入，
# 于是：任何宿主上都能验两个方向；Windows 分支不再只能靠「恰好在这台机器上」验证。
#
# Query 是 role，直接构造宿主即可（只需要 target 访问器）。
# 注意 `:dirs([...])` 要显式写成数组：`:dirs($a, $b)` 会被解析成单个参数
# 传给 slurpy 数组、类型检查失败（写这条测试时踩到）。

class BinProbe does RakuPM::Client::Query {
    has IO::Path $.target is required;
}

plan 11;

my $root = $*TMPDIR.add("rakupm-binpath-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }

my $p = BinProbe.new(:target($root.add('tgt')));

# 安全取值：候选数组可能为空（正是失败时的常见形态），直接 `@got[0]<path>` 会抛异常
# 而不是干净失败 —— 那会让文件在第一条断言就中断，后面的断言全不跑、报告只剩半截。
my sub base-at(@got, Int $i --> Str) {
    return '<缺>' unless @got.elems > $i;
    # 注意不能写 `(@got.elems > $i && @got[$i]<path>.IO.basename) // '<缺>'`：
    # 短路时 `&&` 求值成【False】——那是 defined 的，`//` 不会兜，于是返回值是 Bool
    # 而 `--> Str` 当场类型检查失败，整个测试文件中断（这版就是踩了这个才写的 return）。
    (@got[$i]<path>.IO.basename // '<缺>').Str
}

# ============ Windows 语义（注入 :os('win32')，在 Linux 上也照跑）============
# 注意注入后不再读宿主的 PATHEXT：Platform.exec-suffixes 在 $*ENV<PATHEXT> 缺失时
# 回落到内置的 < .com .exe .bat .cmd >，所以代价是「宿主 PATHEXT 很特殊时这里验不到
# 那个特例」—— 那个由 t/platform.t 单独覆盖（它直接喂 PATHEXT 样本）。
{
    my $a = $root.add('w-a'); mkdir-p($a);
    my $b = $root.add('w-b'); mkdir-p($b);
    $a.add('cmd-a.bat').spurt('x');
    $b.add('cmd-a.exe').spurt('x');
    my @got = $p.detect-bin-on-path('cmd-a',
        :dirs([$a.absolute.Str, $b.absolute.Str]), :os('win32'));
    is @got.elems, 2, 'win：两个目录各有一个候选';
    is base-at(@got, 0), 'cmd-a.bat',
       'win：PATH 靠前的目录优先（即使后面的目录里有 .exe）';
    is base-at(@got, 1), 'cmd-a.exe', 'win：第二个候选来自后面的目录';
}

# 同一目录内：扩展名优先级（.exe 胜 .bat）。
# 用户现场就是这三份并存：raku-pm 写的 bash wrapper + 它写的 .bat + zef 残留的 .exe
{
    my $d = $root.add('w-c'); mkdir-p($d);
    $d.add('cmd-b').spurt('x');
    $d.add('cmd-b.bat').spurt('x');
    $d.add('cmd-b.exe').spurt('x');
    my @got = $p.detect-bin-on-path('cmd-b', :dirs([$d.absolute.Str]), :os('win32'));
    is @got.elems, 1, 'win：同一目录只产生一个候选（只有它会被执行，其余都进不来）';
    is base-at(@got, 0), 'cmd-b.exe',
       'win：同目录内 .exe 优先（PATHEXT）—— 这正是「升级了却还是旧版」的成因';
}

# ours 标记：位于 <target>/bin 下才算「自装的」
{
    my $tgt = $root.add('w-tgt');
    my $tb = $tgt.add('bin'); mkdir-p($tb);
    $tb.add('cmd-c.bat').spurt('x');
    my $q = BinProbe.new(:target($tgt));
    my @got = $q.detect-bin-on-path('cmd-c', :dirs([$tb.absolute.Str]), :os('win32'));
    ok @got.elems && @got[0]<ours>, 'win：位于 <target>/bin 下的候选被标记为 ours';
}

# ============ Unix 语义（注入 :os('linux')）============
# 这一节就是 0.49.1 那次 Linux 失败的反向守护：它证明了「同一个方法在 Unix 上
# 只看无扩展名」，而上面那节证明了「在 Windows 上看 PATHEXT」。
{
    my $d = $root.add('l-a'); mkdir-p($d);
    $d.add('cmd-d').spurt('x');
    my @got = $p.detect-bin-on-path('cmd-d', :dirs([$d.absolute.Str]), :os('linux'));
    is @got.elems, 1, 'linux：无扩展名的文件会被命中';
    is base-at(@got, 0), 'cmd-d', 'linux：命中的就是文件本身（不拼后缀）';
}

{
    # 关键的一条：Linux 不按扩展名解析命令名，所以只有 .bat/.exe 时一个候选都没有。
    # 修复前这条断言在 Linux 宿主上「碰巧」变成了对 Windows 语义的期望 → 必红。
    my $d = $root.add('l-b'); mkdir-p($d);
    $d.add('cmd-e.bat').spurt('x');
    $d.add('cmd-e.exe').spurt('x');
    my @got = $p.detect-bin-on-path('cmd-e', :dirs([$d.absolute.Str]), :os('linux'));
    is @got.elems, 0,
       'linux：只有 .bat/.exe 时零候选（Unix 不按扩展名解析命令名）';
}

{
    my $a = $root.add('l-c'); my $b = $root.add('l-d');
    mkdir-p($a); mkdir-p($b);
    $a.add('cmd-f').spurt('x');
    $b.add('cmd-f').spurt('x');
    my @got = $p.detect-bin-on-path('cmd-f',
        :dirs([$a.absolute.Str, $b.absolute.Str]), :os('linux'));
    # 写成 `ok A && B eq C` 而不是先 `is` elems 再索引 `@got[0]`：同一个目录名在两处
    # 都存在，basename 分不出先后，必须比全路径；而空数组上索引会抛异常而不是「干净失败」。
    ok @got.elems && @got[0]<path>.IO.absolute.Str eq $a.add('cmd-f').absolute.Str,
       'linux：PATH 靠前的目录优先';
}

# 目录里没有该命令 → 不产生候选
{
    my $e = $root.add('l-e'); mkdir-p($e);
    is $p.detect-bin-on-path('nope', :dirs([$e.absolute.Str]), :os('linux')).elems, 0,
       '空目录不产生候选（两个平台一致）';
}
