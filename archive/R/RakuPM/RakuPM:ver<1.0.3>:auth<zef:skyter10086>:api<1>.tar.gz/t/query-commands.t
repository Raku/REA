use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;
use JSON::Fast;

# info / browse / locate / smoke 四条查询命令的回归测试。
#
# 设计：全部走本地目录仓库（RakuPM::Repository::Local），不碰网络 —— 离线、确定性。
#   · info    —— 解析本地仓库里的包并打印元数据（含依赖 / 提供的模块）。
#   · smoke   —— 取本地仓库里带 t/ 的包源码并跑测试（离线可跑）。
#   · browse  —— 仓库行缺 source-url / support 时，必须明确说「无法打开」而不是崩。
#   · locate  —— 模块在仓库链上找不到时，必须明确说「没有任何仓库提供」。
#
# 这些命令镜像 zef 的同名命令；本测试保证「缺这 8 个」里的后 4 个在 raku-pm 里
# 真的可用（前 4 个 depends/test/build/look 已在 0.51.0 测过）。

my $base = $*TMPDIR.add("rakupm-query-cmds-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

# 造一个带依赖 + 带测试目录的本地发行版。license / source-url / support 可选，
# 用来验证 info 把 META6 里的「主页 / 许可证」类字段也打出来（走 Local.raw-row）。
sub make-dist($dir, :$name, :$version, :$desc, :@provides, :%depends, :$test,
              :$license = '', :$source-url = '', :%support = %()) {
    $dir.mkdir;
    $dir.add('lib').mkdir;
    for @provides -> $mod {
        my $mf = $dir.add("lib/{$mod.subst('::', '/', :g)}.rakumod");
        $mf.parent.mkdir;
        $mf.spurt("unit module $mod;\nsay 'load $mod';\n");
    }
    if $test {
        $dir.add('t').mkdir;
        $dir.add('t/basic.t').spurt(qq:to/TEST/);
            use Test;
            plan 1;
            ok True, '$name 基本测试通过';
            TEST
    }
    my %meta = name => $name, version => $version, auth => 'demo:raku',
               description => $desc, provides => @provides, depends => %depends;
    %meta<license>    = $license    if $license.chars;
    %meta<source-url> = $source-url if $source-url.chars;
    %meta<support>    = %support    if %support;
    $dir.add('META6.json').spurt(to-json(%meta, :sorted-keys));
}

my %demo-depends = runtime => { requires => ['JSON::Fast'] };
make-dist($base.add('Demo-Pkg'), :name('Demo-Pkg'), :version('1.0.0'),
          :desc('演示包，依赖 JSON::Fast'), :provides(['Demo::Pkg']),
          :depends(%demo-depends), :test);
# 一个【没有 source-url / support】的包，专门验 browse 的「无法打开」分支
make-dist($base.add('NoUrl'), :name('NoUrl'), :version('0.1.0'),
          :desc('没有主页地址的包'), :provides(['NoUrl']), :test);
# 一个【带 license / source-url / support】的包，专门验 info 把主页/许可证打出来
make-dist($base.add('MetaPkg'), :name('MetaPkg'), :version('2.3.4'),
          :desc('带元数据的包'), :provides(['Meta::Pkg']), :test,
          :license('Artistic-2.0'),
          :source-url('https://example.com/MetaPkg.tar.gz'),
          :support({ source => 'https://example.com/MetaPkg.git' }));

my $repo = RakuPM::Repository::Local.new(:root($base));
my $client = RakuPM::Client.new(:target($base.add('target')), :repos([$repo]));

plan 14;

# ---- info：解析本地包并打印元数据 ----
{
    # show-info 声明为 --> Nil，返回恒为 Nil；这里只验证它正常执行、不抛异常
    my $ok = try { $client.show-info('Demo-Pkg'); True }
    ok $ok.defined, 'show-info 正常执行、不抛异常';
}

# 用 capture 验证实际打印内容（info 含身份 / 依赖 / 提供的模块）
{
    my $cap;
    {
        my $*OUT = open($base.add('info.out'), :w);
        $client.show-info('Demo-Pkg');
    }
    $cap = $base.add('info.out').slurp;
    ok $cap.contains('Demo-Pkg:ver<1.0.0>:auth<demo:raku>'), 'info 打印身份';
    ok $cap.contains('Demo::Pkg'), 'info 打印提供的模块';
    ok $cap.contains('运行时依赖'), 'info 打印依赖段';
    ok $cap.contains('JSON::Fast'), 'info 打印具体依赖 JSON::Fast';
}

# info 必须把 META6 里的 license / source-url / support 也打出来（走 Local.raw-row，
# 绕过 search-rows 的精简行）—— 这是 0.52.1 修的真·生态联调暴露的坑。
{
    my $fh = open($base.add('info-meta.out'), :w);
    {
        my $*OUT = $fh;
        $client.show-info('MetaPkg');
    }
    $fh.close;
    my $cap = $base.add('info-meta.out').slurp;
    ok $cap.contains('MetaPkg:ver<2.3.4>:auth<demo:raku>'), 'info(MetaPkg) 打印身份';
    ok $cap.contains('Artistic-2.0'), 'info 打印许可证（来自 raw-row）';
    ok $cap.contains('https://example.com/MetaPkg.tar.gz'), 'info 打印 source-url（来自 raw-row）';
    ok $cap.contains('https://example.com/MetaPkg.git'), 'info 打印 support.source（来自 raw-row）';
}

# ---- browse：仓库行缺 source-url 时必须明确说无法打开（不崩）----
{
    # browse 的「找不到」提示走 note（stderr），这里把 *OUT 与 *ERR 都重定向到文件
    my $fh = open($base.add('browse.out'), :w);
    {
        my $*OUT = $fh;
        my $*ERR = $fh;
        $client.browse('NoUrl');
    }
    $fh.close;
    my $cap = $base.add('browse.out').slurp;
    ok $cap.contains('无法打开') || $cap.contains('没有记录'),
       'browse 对缺 source-url 的包明确说明无法打开（不静默、不崩）';
}

# ---- locate：仓库链上找不到模块时必须明确说明 ----
{
    my $fh = open($base.add('locate.out'), :w);
    {
        my $*OUT = $fh;
        my $*ERR = $fh;
        $client.locate('绝对不存在的模块::ZZZ');
    }
    $fh.close;
    my $cap = $base.add('locate.out').slurp;
    ok $cap.contains('没有任何仓库提供') || $cap.contains('✗'),
       'locate 对不存在的模块明确说明找不到（不崩）';
}

# ---- smoke：取本地仓库里带 t/ 的包源码并跑测试，应统计通过 ----
{
    my $cap;
    {
        my $*OUT = open($base.add('smoke.out'), :w);
        $client.smoke('Demo-Pkg');
    }
    $cap = $base.add('smoke.out').slurp;
    ok $cap.contains('冒烟测试完成'), 'smoke 打印汇总行';
    ok $cap.contains('通过'), 'smoke 统计到通过的包';
    # 取了源码就必然跑过测试（t/basic.t 的 plan 1），不抛异常即通过
}

# ---- smoke 没有源码可取时应跳过而不是崩 ----
{
    my $cap;
    {
        my $*OUT = open($base.add('smoke2.out'), :w);
        $client.smoke('仓库里根本没有的包::ZZZ');
    }
    $cap = $base.add('smoke2.out').slurp;
    ok $cap.contains('跳过') && $cap.contains('冒烟测试完成'),
       'smoke 对取不到源码的包跳过并正常汇总（不崩）';
}

LEAVE {
    try { $base.add('info.out').unlink if $base.add('info.out').e }
    try { $base.add('browse.out').unlink if $base.add('browse.out').e }
    try { $base.add('locate.out').unlink if $base.add('locate.out').e }
    try { $base.add('smoke.out').unlink if $base.add('smoke.out').e }
    try { $base.add('smoke2.out').unlink if $base.add('smoke2.out').e }
}
