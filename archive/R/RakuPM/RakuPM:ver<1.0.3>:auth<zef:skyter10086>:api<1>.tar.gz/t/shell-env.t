use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 独立 `shell` 命令（0.55.0）：只输出可 eval 的环境赋值，把 raku-pm 环境
# 灌进当前交互式 shell。覆盖四种格式：bash（默认）/ fish / pwsh / cmd。
#
# 设计要点（也是本测试要锁的契约）：
#   - 输出【只有赋值行、无注释、无多余输出】，才能安全 eval；
#   - bash 两行 export；fish 两行 set -gx；pwsh 两行 $env:；cmd 两行 set；
#   - RAKULIB 用 inst#<target>/site，PATH 把 <target>/bin 放最前。
# 全程离线：shell 只读 target，不碰生态索引 / 网络。

my $bin    = $*PROGRAM.parent(2).add('bin').add('raku-pm.raku');
my $target = $*TMPDIR.add("rakupm-shell-{$*PID}-" ~ now.floor);
$target.mkdir;

# run-bin：用 Proc::Async 跑真实二进制，捕获 stdout/stderr。
# start(:cwd) 才生效（new(:cwd) 无效，见 RakuPM 平台笔记）。
sub run-bin(*@args, :$cwd = $*CWD) {
    my $p = Proc::Async.new($*EXECUTABLE.absolute.Str, $bin.absolute.Str,
                            |@args, :out, :err);
    my $stdout = '';
    my $stderr = '';
    $p.stdout.tap: { $stdout ~= $_ };
    $p.stderr.tap: { $stderr ~= $_ };
    my $rc = await $p.start(:cwd($cwd));
    ($rc, $stdout, $stderr)
}

my $bin-path = $target.add('bin').absolute.Str;
my $site     = $target.add('site').absolute.Str;

# ---- bash（默认格式）----
{
    my ($rc, $out, $err) = run-bin('shell', '--shell=bash',
                                   '--target=' ~ $target.absolute.Str);
    ok $rc ~~ 0, 'bash: 退出码 0' or note "STDERR: $err";
    my @lines = $out.lines.grep(*.chars);
    is @lines.elems, 2, 'bash: 恰好两行赋值（无注释 / 无多余输出）';
    ok @lines[0].starts-with('export RAKULIB='), 'bash: 第 1 行是 export RAKULIB';
    ok @lines[0].contains($site), 'bash: RAKULIB 指向 <target>/site';
    ok @lines[1].starts-with('export PATH='), 'bash: 第 2 行是 export PATH';
    ok @lines[1].contains($bin-path), 'bash: PATH 含 <target>/bin';
    ok @lines[1].contains('$PATH'), 'bash: PATH 把原 $PATH 接在后面';
}

# ---- fish ----
{
    my ($rc, $out, $err) = run-bin('shell', '--shell=fish',
                                   '--target=' ~ $target.absolute.Str);
    ok $rc ~~ 0, 'fish: 退出码 0' or note "STDERR: $err";
    my @lines = $out.lines.grep(*.chars);
    is @lines.elems, 2, 'fish: 恰好两行赋值';
    ok @lines[0].starts-with('set -gx RAKULIB '), 'fish: 第 1 行 set -gx RAKULIB';
    ok @lines[0].contains($site), 'fish: RAKULIB 指向 <target>/site';
    ok @lines[1].starts-with('set -gx PATH '), 'fish: 第 2 行 set -gx PATH';
    ok @lines[1].contains($bin-path), 'fish: PATH 含 <target>/bin';
}

# ---- pwsh / PowerShell ----
{
    my ($rc, $out, $err) = run-bin('shell', '--shell=pwsh',
                                   '--target=' ~ $target.absolute.Str);
    ok $rc ~~ 0, 'pwsh: 退出码 0' or note "STDERR: $err";
    my @lines = $out.lines.grep(*.chars);
    is @lines.elems, 2, 'pwsh: 恰好两行赋值';
    ok @lines[0].starts-with('$env:RAKULIB = '), 'pwsh: 第 1 行 $env:RAKULIB';
    ok @lines[0].contains($site), 'pwsh: RAKULIB 指向 <target>/site';
    ok @lines[1].starts-with('$env:PATH = '), 'pwsh: 第 2 行 $env:PATH';
    ok @lines[1].contains($bin-path), 'pwsh: PATH 含 <target>/bin';
    ok @lines[1].contains('$env:PATH'), 'pwsh: PATH 把原 $env:PATH 接在后面';
}

# ---- cmd.exe ----
{
    my ($rc, $out, $err) = run-bin('shell', '--shell=cmd',
                                   '--target=' ~ $target.absolute.Str);
    ok $rc ~~ 0, 'cmd: 退出码 0' or note "STDERR: $err";
    my @lines = $out.lines.grep(*.chars);
    is @lines.elems, 2, 'cmd: 恰好两行赋值';
    ok @lines[0].starts-with('set RAKULIB='), 'cmd: 第 1 行 set RAKULIB';
    ok @lines[0].contains($site), 'cmd: RAKULIB 指向 <target>/site';
    ok @lines[1].starts-with('set PATH='), 'cmd: 第 2 行 set PATH';
    ok @lines[1].contains($bin-path), 'cmd: PATH 含 <target>/bin';
    ok @lines[1].contains('%PATH%'), 'cmd: PATH 把原 %PATH% 接在后面';
}

# ---- 冒烟：不指定 --shell 也不报错（自动识别宿主）----
{
    my ($rc, $out, $err) = run-bin('shell', '--target=' ~ $target.absolute.Str);
    ok $rc ~~ 0, '默认(自动识别): 退出码 0' or note "STDERR: $err";
    ok $out.lines.grep(*.chars).elems > 0, '默认: 有输出';
}

END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($target) if $target.d;
    }
}
