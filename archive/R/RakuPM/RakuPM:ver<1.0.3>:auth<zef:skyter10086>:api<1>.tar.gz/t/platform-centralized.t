use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# H9 的第二半：把「平台判断只能有一处」变成可执行的规矩。
#
# t/platform.t 证明了 Platform 的每个函数在三个平台下都对，但那只覆盖了
# 【已经收进去的东西】。如果以后有人在别的模块里又写一句
# `if $*DISTRO.is-win { ... } else { ... }`，它就绕过了那套遮蔽测试 ——
# 而且非当前平台的那一半代码在这台机器上永远跑不到（H9 的病根）。
#
# 所以这里做静态检查：lib/ 下除 RakuPM/Platform.rakumod 以外，
# 任何地方都不许直接使用 $*DISTRO / $*KERNEL。
#
# 需要新的平台判断时怎么办：加到 RakuPM::Platform 里（顺便在 t/platform.t
# 补上三平台的断言），而不是就地写 if。
#
# 已知边界（诚实声明）：只做去注释后的文本匹配，不解析 Raku 语法。字符串里
# （如 `say "on $*DISTRO.name"`）也会被算作命中 —— 这是有意的：那种输出同样
# 依赖平台，也应当走 Platform 的 os-label()/os-key()。真遇到必须放行的场合，
# 把 (文件, 片段) 写进下面 %ALLOWED 并注明理由，它本身就是一条审查记录。

my $root = $*PROGRAM.parent.parent.absolute.IO;
my $plat = $root.add('lib/RakuPM/Platform.rakumod');

# 允许名单：目前为空。加条目时必须写理由（键是 "<相对路径>:<行号>"）。
my %ALLOWED;

# 去掉行尾注释。# 可能藏在引号里（本项目 regex 里有 <["']> 这种字符类），
# 所以只在「该行 # 之前的文本不含引号」时才剥；否则整行原样保留（宁可多报）。
sub code-part(Str $line --> Str) {
    my $t = $line.trim;
    return '' if $t.starts-with('#');
    my $i = $line.index('#');
    return $line unless $i.defined;
    my $head = $line.substr(0, $i);
    return $line if $head.contains("'") || $head.contains('"');
    $head
}

sub walk-rakumod(IO::Path $dir --> List) {
    my @out;
    for $dir.dir.sort({ .basename }) -> $e {
        next if $e.basename eq '.precomp';
        if $e.d { @out.append(walk-rakumod($e)) }
        elsif $e.extension.lc eq 'rakumod' { @out.push($e) }
    }
    @out.List
}

my @hits;
for walk-rakumod($root.add('lib')) -> $f {
    next if $f.absolute.Str eq $plat.absolute.Str;
    my $rel = $f.relative($root).Str;
    for $f.lines.kv -> $i, $raw {
        my $code = code-part($raw);
        next unless $code.contains('$*DISTRO') || $code.contains('$*KERNEL');
        next if %ALLOWED{"$rel:$i"}:exists;
        @hits.push("$rel:" ~ ($i + 1) ~ "  " ~ $raw.trim);
    }
}

is @hits.elems, 0,
   'lib/ 里除 Platform 外没有直接使用 $*DISTRO / $*KERNEL 的地方';

diag "  命中：" ~ $_ for @hits.head(20);
diag "  怎么改：把平台判断加到 RakuPM::Platform（并在 t/platform.t 补三平台断言），"
   ~ "别在调用方就地写 if。" if @hits.elems;

# 反向保护：Platform 自己必须真的在读 $*DISTRO。
# 否则（比如有人把整个模块删空）上面那条会「因为没有别处使用」而假绿。
ok $plat.f, 'RakuPM::Platform 存在';
my $plat-src = $plat.slurp;
ok $plat-src.contains('$*DISTRO'), 'Platform 自己确实在读 $*DISTRO（否则本检查形同虚设）';
ok $plat-src.contains('$*KERNEL'), 'Platform 也在读 $*KERNEL（by-kernel.name 用）';

# Platform 必须被真正用起来：至少这些模块要 use 它（防止有人绕开它自己实现一份）。
#
# 0.86.0 起 **MD5 不在此列**：它改用 NativeCall 绑系统 libcrypto（多候选库名探测 +
# 首次调用自校验），**不再需要任何平台信息** —— 而它原先之所以需要 Platform，正是因为
# 「≥64KB 走 certutil / md5 -q / md5sum」那条带平台分支的老路。删掉那条路、少一条平台
# 分支正是这次简化的目标，所以把它从本清单移除（是「不再需要」，不是「绕过检查」）。
for <NativeLib Client Distribution Installer Client/Tester Client/Query Client/SelfManager> -> $m {
    my $f = $root.add("lib/RakuPM/$m.rakumod");
    next unless $f.f;
    ok $f.slurp.contains('use RakuPM::Platform'),
       "$m 通过 use RakuPM::Platform 取平台信息";
}

done-testing;
