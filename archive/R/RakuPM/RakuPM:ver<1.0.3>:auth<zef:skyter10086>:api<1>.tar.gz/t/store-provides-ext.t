use Test;
use JSON::Fast;
use RakuPM::Distribution;
use RakuPM::Store;

# 回归（0.37.3 / 复查报告 C）：provides 路径反推
# （0.37.6 起在 RakuPM::Distribution.provides-with-paths，原 Store 私有方法）时，
# .rakudoc 是 RakuDoc 文档，不是可加载模块，绝不能算进 META6.json 的 provides。
# 否则 Rakudo 的模块加载器会去"加载"一个文档文件而失败。同时确认 .rakumod 与
# .pm6 仍被正确识别。
#
# 本文件测的是【行为结果】（入库后写出的 META6.json），所以实现上移到
# Distribution 后它应继续通过 —— 正好当这次迁移的回归守护。
# 两个方向的直接单测在 t/provides-scan.t。
#
# 注意：C 修复发生在「路径反推」那一层（写进 META6.json 的 provides=Hash{名=>路径}），
# 不是 raku-pm 自己的 META.json（那里只存模块名清单，保留 Foo::Baz 是合法的）。
# 所以这里直接解析写出的 META6.json 来验证。

my $base = $*TMPDIR.add("rakupm-provides-ext-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

plan 5;

# 造一个"源码目录"：lib/ 下同时有 .rakumod（真模块）、.pm6（老式模块）、.rakudoc（文档）
my $src = $base.add('src');
$src.mkdir;
$src.add('lib').mkdir;
$src.add('lib/Foo').mkdir;
$src.add('lib/Foo/Bar.rakumod').spurt("unit module Foo::Bar;\n");   # 真模块
$src.add('lib/Foo/Baz.rakudoc').spurt("=begin pod\nRakuDoc for Foo::Baz\n=end pod\n");  # 文档，不是模块
$src.add('lib/Qux.pm6').spurt("unit module Qux;\n");                # 老式扩展名，仍认
$src.add('META6.json').spurt(q:to/META/);
    { "name": "Demo", "version": "1.0.0", "auth": "t:me",
      "provides": { "Foo::Bar": "lib/Foo/Bar.rakumod",
                    "Foo::Baz": "lib/Foo/Baz.rakudoc",
                    "Qux":      "lib/Qux.pm6" } }
    META

my $store = RakuPM::Store.new(:root($base.add('store')));
my $dist  = RakuPM::Distribution.new(
                :name('Demo'), :version('1.0.0'), :auth('t:me'),
                :provides(['Foo::Bar', 'Foo::Baz', 'Qux']));

my $digest = $store.put($dist, $src);
ok $digest.chars, 'put 返回了内容指纹';

# 读回入库后写出的 META6.json（provides=Hash{模块名=>相对路径}）
my $meta6 = from-json($store.path-for('Demo', '1.0.0').add('META6.json').slurp);
my %provides = $meta6<provides>;

is %provides<Foo::Bar>, 'lib/Foo/Bar.rakumod',
   '.rakumod 模块 Foo::Bar 仍然被识别进 META6 provides';
is %provides<Qux>, 'lib/Qux.pm6',
   '.pm6 模块 Qux 仍然被识别进 META6 provides（没把有效扩展名一并误删）';
ok !(%provides<Foo::Baz>:exists),
   '.rakudoc 文档 Foo::Baz 不计入 META6 provides（C 修复：文档不是模块）';
nok $meta6<provides>.values.grep(*.contains('.rakudoc')),
   'META6.json provides 的值里不含任何 .rakudoc 路径';

done-testing;
