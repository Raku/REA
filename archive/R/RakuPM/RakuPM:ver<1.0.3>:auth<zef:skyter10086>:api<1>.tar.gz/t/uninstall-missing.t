use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Fs;
use RakuPM::Client;
use RakuPM::Repository::Local;
use JSON::Fast;

# 卸载「其实什么都没发生」的情形必须报错 + 退出码 1 —— 0.87.3 修复。
#
# 【修复前的症状】Client.uninstall 不看 Installer.uninstall 的返回值，无条件打印
# 「已卸载 Foo」，于是四类情形全部报成功 + rc=0：
#   ① 包根本没装           → "已卸载 NoSuchPkg"
#   ② 指定的版本不存在      → "已卸载 Top 9.9.9"
#   ③ 范围没匹配到任何版本  → "已卸载 Top <0.1"
#   ④ 反向依赖拒绝卸载      → 打印拒绝提示后 return（同样 rc=0）
# 脚本靠退出码判断成败（`set -e`、`uninstall X && …`）会被全部骗过；而且报的是
# 「已卸载」，比不报更糟 —— 用户以为卸干净了。
#
# 【断言策略】
#   · 进程内断言「抛不抛」（抛 = CLI 里就是 rc=1），并断言**没有打印「已卸载」**
#     —— 那正是 bug 的症状，比逐字比对错误文案更贴本质、也更抗文案调整；
#   · 端到端再断言**真实退出码**：子进程输出在 Windows 上随控制台代码页变，中文
#     比不得，退出码才是稳定判据；
#   · 失败之后必须断言**包还在**（失败的卸载不能有副作用）。
#
# 【为什么必须有端到端那一层】进程内「抛异常」只证明库层行为；退出码要经过 CLI
# 的 guarded / 写锁包装 / Raku 顶层异常处理才成形 —— 漏接线的话进程内断言照样全绿。

my IO::Path $root = $*TMPDIR.add("rakupm-uninstall-missing-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }
mkdir-p($root);

# ---- 本地仓库：UnTop → UnMid → UnLeaf（UnTop 是用户点名装的）----
sub make-dist(Str $name, %deps) {
    my $d = $root.add('repo').add($name);
    mkdir-p($d.add('lib'));
    $d.add('lib').add("{$name}.rakumod").spurt("unit module {$name};\n");
    $d.add('META6.json').spurt(to-json({
        name     => $name,
        version  => '1.0',
        auth     => 'demo:test',
        provides => { $name => "lib/{$name}.rakumod" },
        depends  => %deps,
    }, :sorted-keys));
}
my $repo = $root.add('repo'); mkdir-p($repo);
make-dist('UnLeaf', %());
make-dist('UnMid',  %('UnLeaf' => '*'));
make-dist('UnTop',  %('UnMid'  => '*'));

my IO::Path $tgt = $root.add('target');
my $client = RakuPM::Client.new(
    :target($tgt),
    :repos([RakuPM::Repository::Local.new(:root($repo))]),
);

# 把一段代码的 stdout/stderr 收进内存。t/ 门禁要求输出洁净（见 t/ghost-provides.t），
# 而这里还要断言「打印了什么」，所以统一收走再检查。
# 返回 (是否抛错, 异常文本, 实际打印出来的文本)。
sub run-quiet(&code --> List) {
    my $sink = $root.add('sink.txt');
    my $fh = $sink.open(:w);
    my $died = False;
    my $msg  = '';
    {
        my $*OUT = $fh;
        my $*ERR = $fh;
        # 【不能用 `try {} CATCH {}` 组合】try 自己就把异常吞了，外层 CATCH 永不触发
        # （本项目踩过：端到端断言变成"既不绿也不红"）。裸块 + CATCH 才拿得到异常。
        { code() }
        CATCH { default { $died = True; $msg = .Str } }
    }
    $fh.close;
    my $text = $sink.slurp;
    try { $sink.unlink }
    ($died, $msg, $text)
}

# ---- 前提：UnTop（连带 UnMid / UnLeaf）装上 ----
{
    my ($died, $msg, $text) = run-quiet({ $client.install('UnTop', :no-test, :no-build) });
    ok !$died, '前提：UnTop 安装成功' ~ ($died ?? "（失败：{$msg.lines.head}）" !! '');
    is $client.installer.installed-versions('UnTop').join(','), '1.0', '前提：UnTop 已装';
    is $client.installer.installed-versions('UnMid').join(','), '1.0', '前提：依赖 UnMid 已装';
    is $client.installer.installed-versions('UnLeaf').join(','), '1.0', '前提：依赖 UnLeaf 已装';
}

# ============================================================================
# 一、四类「什么都没卸掉」的情形：必须抛错，且不得打印「已卸载」
# ============================================================================

# ---- ① 包根本没装 ----
{
    my ($died, $msg, $text) = run-quiet({ $client.uninstall('UnNothingAtAll') });
    ok $died, '① 卸载没装的包：抛错（CLI 里即 rc=1）';
    ok $msg.contains('没有安装'), '① 错误信息说明「没有安装」，而不是抛内部异常';
    nok $text.contains('已卸载'), '① 不再谎报「已卸载」（这正是修复前的症状）';
}

# ---- ② 已装，但指定的版本不存在 ----
{
    my ($died, $msg, $text) = run-quiet({ $client.uninstall('UnTop', :version('9.9.9')) });
    ok $died, '② 卸载不存在的版本：抛错';
    ok $msg.contains('9.9.9'), '② 错误信息点出用户给的那个版本串（好定位）';
    ok $msg.contains('1.0'),   '② 错误信息同时列出实际已装版本（好对照改正）';
    nok $text.contains('已卸载'), '② 不再谎报「已卸载」';
}

# ---- ③ 已装，但范围没匹配到任何版本 ----
{
    my ($died, $msg, $text) = run-quiet({ $client.uninstall('UnTop', :version('<0.1')) });
    ok $died, '③ 范围没匹配到任何版本：抛错';
    ok $msg.contains('<0.1'), '③ 错误信息带上用户给的范围串';
    nok $text.contains('已卸载'), '③ 不再谎报「已卸载」';
}

# ---- ④ 被别的包依赖 → 拒绝卸载（修复前打印提示后 return，rc=0）----
{
    my ($died, $msg, $text) = run-quiet({ $client.uninstall('UnMid') });
    ok $died, '④ 反向依赖拒绝卸载：抛错（修复前是 msg-warn + return → rc=0）';
    ok $msg.contains('依赖'), '④ 错误信息说清是「被依赖」而拒绝';
    ok $msg.contains('--recursive') && $msg.contains('--force'),
       '④ 给出两条出路（--recursive 一并卸 / --force 强行卸）';
    nok $text.contains('已卸载'), '④ 不再谎报「已卸载」';
}

# ---- 四次失败之后：状态必须一点没变（失败的卸载不能有副作用）----
is $client.installer.installed-versions('UnTop').join(','),  '1.0',
   '四次失败后 UnTop 仍在（失败的卸载无副作用）';
is $client.installer.installed-versions('UnMid').join(','),  '1.0', '……UnMid 仍在';
is $client.installer.installed-versions('UnLeaf').join(','), '1.0', '……UnLeaf 仍在';

# ============================================================================
# 二、端到端：真实退出码（脚本判断卸载成败用的就是它）
# ============================================================================
{
    # .absolute 在本机 Rakudo 上返回 Str（不是 IO::Path），必须 .IO 显式转一次
    my IO::Path $repo-root = $*PROGRAM.parent.parent.absolute.IO;
    my Str $bin = $repo-root.add('bin/raku-pm.raku').Str;
    my IO::Path $empty-in = $root.add('empty.stdin');
    $empty-in.spurt('');
    my %env = %*ENV.Hash;
    %env<RAKUPM_REPO> = $repo.Str;    # 让子进程只看这个本地仓库，别去读真实生态索引

    sub cli-rc(*@args --> Int) {
        # 【:in 必须传【已打开的句柄】】实测（本机）：传路径（IO::Path / Str / 'NUL'）
        # 会让子进程直接被杀（exitcode -16、零输出、无报错），只有传句柄正常。
        # 显式喂 EOF 是为了避开另一个坑：stdin 是「永不投递数据的管道」时，Rakudo 的
        # CUR 安装/预编译路径会无限阻塞（零 CPU、无子进程，完美伪装成死锁）。
        my $h = $empty-in.open(:r);
        my $p = run($*EXECUTABLE.Str, $bin, |@args,
                    '--target=' ~ $tgt.Str, '--offline',
                    :in($h), :out, :err, :cwd($repo-root), :env(%env));
        $p.out.slurp(:close);
        $p.err.slurp(:close);
        $h.close;
        $p.exitcode
    }

    is cli-rc('uninstall', 'UnNothingAtAll'), 1,
       '端到端：卸载没装的包 → 退出码 1（修复前 0，脚本会被骗过）';
    is cli-rc('uninstall', 'UnTop', '--version=9.9.9'), 1,
       '端到端：卸载不存在的版本 → 退出码 1';
    is cli-rc('uninstall', 'UnMid'), 1,
       '端到端：被依赖而拒绝卸载 → 退出码 1（修复前打印提示后 rc=0）';
    is cli-rc('uninstall', 'UnTop'), 0,
       '端到端正控：正常卸载 → 退出码 0（别把成功路径也一并弄坏）';
    is $client.installer.installed-versions('UnTop').elems, 0,
       '端到端正控：UnTop 确实被卸掉了（不是只报个 rc）';
}

# ============================================================================
# 三、Installer.uninstall 的返回值契约（Client 的判定依据，单独钉一下）
# ============================================================================
{
    my @none = $client.installer.uninstall('UnNothingAtAll', :version(''));
    is @none.elems, 0, 'Installer.uninstall：什么都没摘到时返回空列表（Client 据此判失败）';
}
{
    my @got = $client.installer.uninstall('UnLeaf', :version(''));
    is @got.join(','), '1.0', 'Installer.uninstall：真摘掉时返回被摘的版本串';
    is $client.installer.installed-versions('UnLeaf').elems, 0, '……且 UnLeaf 确实没了';
}

done-testing;
