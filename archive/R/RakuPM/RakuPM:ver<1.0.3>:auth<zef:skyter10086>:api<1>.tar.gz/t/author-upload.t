use Test;
use lib 'lib';
use RakuPM::Author;
use RakuPM::HTTP;
use RakuPM::Fs;
use JSON::Fast;

# 凭据 / 上传目标隔离到临时目录
my $tmp = ($*TMPDIR // '/tmp'.IO).add("rakupm-upload-test-{now.to-posix[0].Int}");
$tmp.mkdir;
%*ENV<RAKUPM_TARGET> = $tmp.absolute.Str;
%*ENV<RAKUPM_AUTHOR_AUTH> = 'github:tester';

# ---- mock curl：替换真实 curl，验证生产代码构造出的 wire 契约 ----
# 本环境（Rakudo/Windows）的 IO::Socket::INET :listen 会抛 "Invalid port (Int)"、
# IO::Socket::Async 在第 3 个连接数据 Supply 不触发——两种本地 mock 上传服务器都起不来；
# 而真实 curl 上行又会被环境代理劫持（HTTP 502）。于是改用【替换 curl 二进制】的方式：
# RAKUPM_CURL 直接指向 t/mock-curl.raku（假 curl 脚本），由 RakuPM::HTTP.post-form 检测
# 到 .raku 后缀后用当前解释器 $*EXECUTABLE 直接运行它——这绕开了 Windows 上 run()→cmd /c
# →.bat 对含空格实参（如 -H "Authorization: Zef <key>"）的引号错位（否则带空格字段会让
# .bat 启动失败、拿不到响应）。mock 解析与 post-form 完全一致的参数（-o / -F / -H / URL），
# 把「请求」重建为可读文本写入 RAKUPM_MOCK_CAPTURE，把假响应体写入 -o 文件，向 stdout
# 打印 200（模拟 curl -w '%{http_code}'）。完全离线、确定性、无 socket、无代理依赖——
# 直接验证 RakuPM::HTTP.post-form / upload-multipart / RakuPM::Author.login /
# publish --remote 真实构造出的上传契约。
my $mock-curl = $?FILE.IO.parent.add('mock-curl.raku').absolute.Str;
%*ENV<RAKUPM_CURL> = $mock-curl;
%*ENV<RAKUPM_MOCK_CAPTURE> = $tmp.add('capture.txt').absolute.Str;
# mock 诊断输出（args/exc）随捕获文件一起落到 $tmp，由测试 LEAVE 统一清理，不污染 t/。
%*ENV<RAKUPM_MOCK_LOGDIR> = $tmp.absolute.Str;
# 上传端点指向占位（mock 不联网，仅用于让生成的 URL 直观），并清掉所有代理环境变量，
# 确保即便误走真实 curl 也是直连（双保险，避免被环境代理劫持成 502）。
%*ENV<RAKUPM_UPLOAD_HOST> = 'http://mock.invalid';
for <HTTP_PROXY HTTPS_PROXY http_proxy https_proxy ALL_PROXY all_proxy> -> $k {
    %*ENV{$k}:delete;
}

# 读取 mock 写回的「请求」文本（latin-1 解码以无损容纳真实 sdist 的二进制 tar.gz 内容）。
sub cap(--> Str) {
    return %*ENV<RAKUPM_MOCK_CAPTURE>.IO.e
        ?? %*ENV<RAKUPM_MOCK_CAPTURE>.IO.slurp(:bin).decode('latin-1')
        !! '';
}

sub make-dist(Str $tag, Str :$version = '0.1.0' --> IO::Path) {
    my $d = $tmp.add("D-{$tag}");
    $d.mkdir;
    my %meta = %(
        name => 'Dist::Sample', version => $version, auth => 'github:tester',
        api => '1', description => 'a sample dist', authors => ['tester'],
        license => 'Artistic-2.0', raku => '6.d',
        provides => { 'Dist::Sample' => 'lib/Dist/Sample.rakumod' },
        depends => %( runtime => %( requires => [] ) ),
        test-depends => ['Test'],
    );
    $d.add('META6.json').spurt(to-json(%meta, :sorted-keys));
    my $lib = $d.add('lib/Dist/Sample.rakumod'); mkdir-p($lib.parent);
    $lib.spurt("unit module Dist::Sample;\n");
    $d.add('Changes').spurt("# Change log for Dist::Sample\n\n## {$version}\n\n- init\n");
    $d
}

plan 3;

# 场景A：upload-multipart 发出正确 wire 格式（直接调门面）
subtest 'upload-multipart 发出正确 wire 格式' => {
    plan 5;
    my $file = $tmp.add('sample.tar.gz');
    $file.spurt("SAMPLE-TAR-MARKER-XYZ");
    my $r = RakuPM::HTTP.new.upload-multipart("http://mock.invalid/upload", $file, :auth('testkey'));
    my $txt = cap;
    ok $r<ok>, 'upload-multipart 返回 ok（mock 回 200）';
    like $txt, / 'Authorization: Zef testkey' /, '上传请求带 Authorization: Zef <key> 头';
    like $txt, / 'name="dist"' /,                 'multipart 字段名为 dist';
    like $txt, / 'filename="sample.tar.gz"' /,     'dist 字段文件名正确';
    like $txt, / 'SAMPLE-TAR-MARKER-XYZ' /,        '请求体含文件内容';
}

# 场景B：login --username/--password 真实联网换 key（mock 回 JSON key）
#   注意：42.zef.pm/login 的 from-body 只认 application/json，所以 login 发的是
#   JSON 体（Content-Type: application/json + -d '{...}'），不是 multipart 字段。
subtest 'login --username/--password 联网换 key（JSON 体）' => {
    plan 5;
    my $r = RakuPM::Author.login(:username('bob'), :password('hunter2'), :quiet(True));
    my $txt = cap;
    ok $r<ok>, 'login --username/--password 返回 ok';
    is $r<stored>, 'api-key', 'login 已存 api-key（真实登录，非 M2 延迟路径）';
    my $cf = $tmp.add('credentials.json');
    my %c = from-json($cf.slurp);
    is %c<api-key>, 'fakekey123', '凭据文件存的是服务端返回的 key';
    like $txt, / 'Content-Type: application/json' /, '登录请求发 JSON 体（Content-Type）';
    like $txt, / '"username"' .* '"password"' | '"password"' .* '"username"' /,
        '登录请求的 JSON 体含 username / password 字段';
}

# 场景C：publish --remote 非 dry 真实上传（走完整 publish 流程，mock 接收）
subtest 'publish --remote 真实上传' => {
    plan 4;
    %*ENV<RAKUPM_API_KEY> = 'testkey';        # 用 env key，不依赖 login
    my $d = make-dist('upload-live');
    my $r = RakuPM::Author.publish($d, :remote, :quiet(True));
    my $txt = cap;
    ok $r<ok>, 'publish --remote 返回 ok（真实上传成功）';
    ok $r<remote>, 'publish --remote 标记为真';
    like $txt, / 'name="dist"' /, '上传请求字段为 dist';
    like $txt, / 'filename="Dist-Sample-0.1.0.tar.gz"' /, '上传的文件名是打包出的 sdist';
    %*ENV<RAKUPM_API_KEY>:delete;
}

done-testing;

# 清理临时目录（best-effort，纯 Raku 递归删除）
LEAVE {
    sub rmtree(IO::Path $p) {
        return unless $p.e;
        if $p.d {
            for $p.dir -> $c { rmtree($c) }
            try $p.rmdir;
        }
        else {
            try $p.unlink;
        }
    }
    try rmtree($tmp);
}
