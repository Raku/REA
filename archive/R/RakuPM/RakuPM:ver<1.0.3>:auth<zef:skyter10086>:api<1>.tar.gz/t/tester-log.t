use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 回归：测试阶段改为【异步 + 进程隔离 + 并发】后，每个测试文件的【完整输出】
# 必须落盘到 <target>/log/<包名>/<版本>/<测试文件>.log，前台只显示成败。
# 这里只跑「全通过」的夹具（不触发 ⚠），保证 t/ 安静，并钉死「日志文件存在 +
# 含完整 TAP」这个契约。并发 / 失败首行 / 超时 由 xt/tester-async.t 覆盖。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-tlog-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $src = $tmp.add('logsrc').mkdir;
$src.add('lib').mkdir;
$src.add('lib').add('LogProbe.rakumod').spurt('unit module LogProbe;');
$src.add('META6.json').spurt(to-json({
    name => 'LogProbe', version => '0.1.0', auth => 'demo',
    provides => { LogProbe => 'lib/LogProbe.rakumod' }, depends => {},
}, :sorted-keys));
$src.add('t').mkdir;
$src.add('t').add('01-basic.rakutest').spurt(q:to/END/);
    use Test;
    plan 1;
    ok 1, 'logged';
    END

my $client = RakuPM::Client.new(
    :target($tmp.add('target')),
    :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]),
);

plan 2;

# 1) 安装（含跑测试）不炸
lives-ok { $client.install-from-dir($src, :no-build) },
    '夹具测试通过 → 安装不炸（异步 tester 跑通）';

# 2) 完整输出已落日志到正确路径
my $log = $tmp.add('target').add('log').add('LogProbe').add('0.1.0')
               .add('01-basic.rakutest.log');
ok $log.e && $log.slurp.contains('ok 1 - logged'),
   '测试完整输出已落日志 <target>/log/<包>/<版本>/<测试>.log';
