use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Platform;
use RakuPM::NativeLib;

# H9：平台分支的可达性测试。
#
# 背景（审查报告 H9 / 项目真实事故）：`if $*DISTRO.is-win { ... } else { ... }`
# 这类分支在当前平台上是【单向短路】的 —— Windows 开发机上 else 分支永不执行，
# 于是它的错误永远测不出来。项目真实栽过：MD5.system-md5 里写了
# `$*DISTRO.is-macosx`（Distro 根本没有这个方法），Windows 上 is-win 为真、
# elsif 短路，全套测试全绿；一到 Linux 就崩在 Store 的内容指纹计算上。
#
# 做法：所有平台差异都收敛到 RakuPM::Platform，而它的函数一律在【调用时】
# 读 $*DISTRO；于是用 `my $*DISTRO = Distro.new(:name(...))` 词法遮蔽，就能在
# 任何一台机器上把三个平台的分支都真跑一遍。这个文件就是那套矩阵。
#
# 本文件必须保持安静（t/ 是 zef install 会跑的那批）——只用 is/ok，不喷生产级警告。

my $real-os = os-key();          # 本机真实平台，最后用来验收「遮蔽没有泄漏」
my @OS = <win32 darwin linux>;

# 各平台的期望值。三列都写全，是为了让「加一个平台维度」时非改不可。
my %EX =
    win32 => %(
        label    => 'Windows',
        # exec-suffixes 在 Windows 上按 PATHEXT 算 —— 那是环境变量，用户可改，
        # 所以不做精确值断言（用下面的结构断言：末位是无扩展名、.exe 先于 .bat）。
        sep      => ';',
        libs     => ('demo.dll', 'libdemo.dll'),
        win      => True,  mac => False, linux => False,
        which    => 'where',
        path-in  => '/c/Users/foo',
        path-out => "C:\\Users\\foo",
        # Windows 找 DLL 的第一条就是 rakudo 的 bin 目录
        in-paths => 'C:/Windows/System32',
    ),
    darwin => %(
        label    => 'macOS',
        sep      => ':',
        libs     => ('libdemo.dylib', 'demo.dylib'),
        win      => False, mac => True,  linux => False,
        which    => 'which',
        # macOS/Linux 上 /c/Users/foo 是【合法绝对路径】，绝不能被篡改成 C:\...
        path-in  => '/c/Users/foo',
        path-out => '/c/Users/foo',
        in-paths => '/opt/homebrew/lib',
    ),
    linux => %(
        label    => 'Linux/Unix',
        sep      => ':',
        libs     => ('libdemo.so', 'demo.so'),
        win      => False, mac => False, linux => True,
        which    => 'which',
        path-in  => '/c/Users/foo',
        path-out => '/c/Users/foo',
        in-paths => '/usr/lib',
    ),
;

# ---------- 1. 遮蔽本身生效（后面所有断言的前提）----------
for @OS -> $os {
    my $*DISTRO = Distro.new(:name($os));
    is $*DISTRO.name.Str, $os,
       "遮蔽 \$*DISTRO 生效：name=$os（不生效则本文件全部假绿）";
    is os-key(), $os, "os-key() 跟随遮蔽 → $os";
}

# ---------- 2. 平台函数矩阵：三平台都走一遍 ----------
for @OS -> $os {
    my %e = %EX{$os};
    my $*DISTRO = Distro.new(:name($os));

    is os-label(),            %e<label>,              "[$os] os-label()";
    is path-list-sep(),       %e<sep>,                "[$os] 环境变量目录分隔符";
    # exec-suffixes：Windows 走 PATHEXT（.exe 优先、无扩展名不在其列→排末位），
    # Unix 只有无扩展名。精确顺序由第 8 节用固定场景覆盖，这里断言结构性事实。
    if %e<win> {
        my @s = exec-suffixes();
        ok @s.elems > 1,      "[$os] exec-suffixes 按 PATHEXT 给出多个候选";
        nok @s.first({ $_ eq '' }).defined,
            "[$os] exec-suffixes 不含无扩展名（cmd 不会执行这种文件）";
    }
    else {
        is exec-suffixes().List, ('',), "[$os] exec-suffixes 只有无扩展名";
    }
    is library-file-names('demo'), %e<libs>.List,     "[$os] 通用库文件名规则";
    is is-windows(),          %e<win>,                "[$os] is-windows()";
    is is-macos(),            %e<mac>,                "[$os] is-macos()";
    is is-linux(),            %e<linux>,              "[$os] is-linux()";
    is which-command(),       %e<which>,              "[$os] which/where";

    # 路径形态：只有 Windows 才做 MSYS 转换
    is native-path(%e<path-in>).Str, %e<path-out>,
       "[$os] native-path()（Windows 转 MSYS，Unix 原样保留）";

    # 库搜索路径
    my @sp = library-search-paths();
    ok @sp.elems > 0,                    "[$os] 库搜索路径非空";
    # 用【完全相等】而不是 contains：一条路径打错字（/opt/homebrew/libX）仍然
    # contains /opt/homebrew/lib（前缀也是子串），contains 会把这种 bug 放过去。
    # 这条断言被变异验证抓过一次，别改回去。
    ok @sp.grep({ $_ eq %e<in-paths> }).elems > 0,
       "[$os] 搜索路径含 %e<in-paths>（完全相等）";
    is @sp.grep({ .chars <= 1 }).elems, 0, "[$os] 搜索路径无垃圾条目";
    is @sp.elems, @sp.unique.elems,        "[$os] 搜索路径已去重";
    is @sp.grep({ $_ ~~ / <[\\\/]> $ / }).elems, 0, "[$os] 搜索路径已去尾部斜杠";

    # ---------- 3. 消费方必须跟着走（这才是「分支可达」的证明）----------
    my $nl = RakuPM::NativeLib.new;
    is $nl.os-key(),   $os,       "[$os] NativeLib.os-key 跟随遮蔽";
    is $nl.os-label(), %e<label>, "[$os] NativeLib.os-label 跟随遮蔽";
    is $nl.candidates('demo'), %e<libs>.List,
       "[$os] NativeLib.candidates 用该平台的命名规则";
    ok $nl.search-paths().elems > 0, "[$os] NativeLib.search-paths 非空";
}

# ---------- 5. 显式 --os 覆盖：不受遮蔽影响 ----------
{
    my $*DISTRO = Distro.new(:name('win32'));   # 假装在 Windows
    is resolve-os('linux'), 'linux', '显式 --os=linux 覆盖当前平台';
    is package-key(:os<linux>, :name<ubuntu>), 'debian',
       '--os=linux --distro=ubuntu → debian 族';
    is path-list-sep('linux'), ':',  '显式 os 决定分隔符';
    is path-list-sep('win32'), ';',  '显式 os=win32 → 分号';
}

# ---------- 5b. kill-tree：契约 + 真杀一次 ----------
#
# 为什么要单测：这个错误【在 Windows 上几乎不可能被发现】—— Windows 分支只用
# $pid（走 taskkill），碰都不碰第一个参数；而 Unix 分支用 try 包着，「传错对象」
# 会被 try 吞掉、静默不杀。0.46.1 的 Unix 超时看门狗从未生效就是这么来的
# （那时传的是 start() 返回的 Promise，而 Promise 没有 .kill）。
# 对策有两层，这里把两层都钉住：
#   ① 签名写严（Proc::Async）→ 传错对象在**平台分支之前**就抛类型错；
#   ② 下面真起一个长睡子进程、真的杀掉它 → 当前平台那条分支是**真跑过**的。
{
    # ① 误传 Promise 必须【立刻】抛错，而不是被 try 静默吞掉
    my $prom = start { 1 };
    dies-ok { kill-tree($prom, 999999) },
        '误传 Promise（没有 .kill）立刻抛错，不会被静默吞掉';
    await $prom;
}

{
    # ② 两个平台分支各调什么 —— 用替身对象记录收到的信号（所以签名用
    #    `where *.can('kill')` 而不是具体类型：替身才有机会被传进去）。
    my class FakeProc {
        has Int $.signal = 0;
        method kill(Int $sig) { $!signal = $sig }
    }

    {
        my $*DISTRO = Distro.new(:name('linux'));
        my $fake = FakeProc.new;
        kill-tree($fake, 999999);
        is $fake.signal, 9, 'Unix 分支调 Proc.kill(9)（SIGKILL）';
    }

    {
        # Windows 分支走 taskkill，【不碰】第一个参数 —— 这正是「传错对象」
        # 在 Windows 上查不出来的原因（假 PID，taskkill 只会报错、无副作用）
        my $*DISTRO = Distro.new(:name('win32'));
        my $fake = FakeProc.new;
        kill-tree($fake, 999999);
        is $fake.signal, 0, 'Windows 分支不调 Proc.kill（走 taskkill）';
    }
}

{
    # ③ 真杀一次：起一个睡 3600 秒的子进程，看 kill-tree 能否让它立刻结束。
    # 用当前平台（不遮蔽）—— 这样验的就是本机实际会走的那条分支。
    my $proc = Proc::Async.new($*EXECUTABLE.Str, '-e', 'sleep 3600');
    my $started = $proc.start;
    my $pid = await $proc.pid;
    ok $pid.defined, '拿到子进程 PID（kill-tree 的 Windows 分支要用）';

    my $t0 = now;
    kill-tree($proc, $pid);
    my $exited = await Promise.anyof($started, Promise.in(20));
    my $elapsed = now - $t0;

    ok $exited.defined, '长睡子进程被杀掉了（20 秒内退出）';
    ok $elapsed < 15, "kill-tree 见效很快（{$elapsed.round(0.1)}s，远小于 3600s）";
}

# ---------- 6. os 名别名归一化 ----------
{
    is normalize-os-key('Windows'), 'win32',  'Windows → win32';
    is normalize-os-key('macOS'),   'darwin', 'macOS → darwin';
    is normalize-os-key('osx'),     'darwin', 'osx → darwin';
    is normalize-os-key('linux'),   'linux',  'linux → linux';
    is normalize-os-key('auto'),    '',       'auto → 交回自动探测';
    is normalize-os-key('haiku'),   '',       '不认识 → 交回自动探测';
    is resolve-os('haiku'), $real-os,         '不认识的值回落到本机（不静默判错）';
}

# ---------- 7. 遮蔽不泄漏：循环结束后必须回到本机 ----------
is os-key(), $real-os, '全部遮蔽块结束后，os-key() 回到本机真实平台';

# 覆盖率自检：NativeLib 的 %LIBS 表三平台都有条目（防止新加库时漏一列）
{
    my $w = RakuPM::NativeLib.new(:os<win32>);
    my $d = RakuPM::NativeLib.new(:os<darwin>);
    my $l = RakuPM::NativeLib.new(:os<linux>);
    for <sqlite3 openssl zlib> -> $lib {
        ok $w.candidates($lib).elems > 0, "已知库 $lib 有 win32 候选";
        ok $d.candidates($lib).elems > 0, "已知库 $lib 有 darwin 候选";
        ok $l.candidates($lib).elems > 0, "已知库 $lib 有 linux 候选";
    }
}

# ---------- 8. 命令名解析：exec-suffixes / pick-command-file（PATHEXT 感知）----------
# 0.48.0 修的正是这里：旧实现把「无扩展名」排在候选第一位（Unix 语义），于是
# `raku-pm env` 声称「第一个就是实际跑的那份」时指到了 bash wrapper；而 Windows
# 用 PATHEXT 解析命令名，真正被执行的是排在后面的 .exe（用户现场：升级到 0.47.0
# 后敲 `raku-pm version` 仍是 0.46.1）。自查工具给出错答案，比不给答案更糟。
{
    {
        my $*DISTRO = Distro.new(:name('mswin32'));
        my @s = exec-suffixes();
        ok @s.elems > 1, 'Windows：exec-suffixes 给出多个候选';
        nok @s.first({ $_ eq '' }).defined,
            'Windows：候选里【不含】无扩展名（cmd 不会执行这种文件）';
        my $i-exe = @s.first({ $_ eq '.exe' }, :k) // -1;
        my $i-bat = @s.first({ $_ eq '.bat' }, :k) // -1;
        ok $i-exe >= 0 && $i-bat >= 0 && $i-exe < $i-bat,
           'Windows：.exe 优先于 .bat（按 PATHEXT）';
    }
    {
        my $*DISTRO = Distro.new(:name('linux'));
        is exec-suffixes().List, ('',), 'Unix：只有无扩展名一种候选';
    }

    # pick-command-file：三种同名文件并存 —— 正是用户现场的样子
    # （raku-pm 自己的 bash wrapper + 它写的 .bat + zef 时代残留的 .exe）
    my $d = $*TMPDIR.add("rakupm-pick-{$*PID}");
    $d.mkdir;
    $d.add('cmd-a').spurt('x');
    $d.add('cmd-a.bat').spurt('x');
    $d.add('cmd-a.exe').spurt('x');
    {
        my $*DISTRO = Distro.new(:name('mswin32'));
        is pick-command-file($d, 'cmd-a').IO.basename, 'cmd-a.exe',
           'Windows：三份并存时选 .exe（这解释「升级了却还是旧版」）';
    }
    {
        my $*DISTRO = Distro.new(:name('linux'));
        is pick-command-file($d, 'cmd-a').IO.basename, 'cmd-a',
           'Unix：选无扩展名那份（bash wrapper）';
    }
    $d.add('cmd-a.exe').unlink;
    {
        my $*DISTRO = Distro.new(:name('mswin32'));
        is pick-command-file($d, 'cmd-a').IO.basename, 'cmd-a.bat',
           'Windows：没有 .exe 时落到 .bat';
    }
    # 收尾（不依赖 Fs，保持本文件只测 Platform）
    for $d.dir { .unlink }
    $d.rmdir;
    ok !$d.e, '临时目录已清理';
}

done-testing;
