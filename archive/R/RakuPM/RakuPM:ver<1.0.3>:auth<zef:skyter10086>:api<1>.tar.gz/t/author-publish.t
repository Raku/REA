use Test;
use lib 'lib';
use RakuPM::Author;
use RakuPM::Fs;
use JSON::Fast;

# 让 check 门禁在测试环境里稳定通过（auth 与 dist 一致，不告警不报错）
%*ENV<RAKUPM_AUTHOR_AUTH> = 'github:tester';

plan 12;

my $tmp = ($*TMPDIR // '/tmp'.IO).add("rakupm-publish-test-{now.to-posix[0].Int}");
$tmp.mkdir;

sub make-dist(Str $tag, Str :$version = '0.1.0' --> IO::Path) {
    my $d = $tmp.add("D-{$tag}");
    $d.mkdir;
    my %meta = %(
        name => 'Dist::Sample', version => $version, auth => 'github:tester',
        api => '1', description => 'a sample dist', authors => ['tester'],
        license => 'Artistic-2.0', raku => '6.d',
        provides => { 'Dist::Sample' => 'lib/Dist/Sample.rakumod' },
        depends => %( runtime => %( requires => [] ) ),
        test-depends => ['Test'],
    );
    $d.add('META6.json').spurt(to-json(%meta, :sorted-keys));
    my $lib = $d.add('lib/Dist/Sample.rakumod'); mkdir-p($lib.parent);
    $lib.spurt("unit module Dist::Sample;\n");
    $d.add('Changes').spurt("# Change log for Dist::Sample\n\n## {$version}\n\n- init\n");
    $d
}

sub meta-name-ver(IO::Path $dir --> List) {
    my $m = from-json($dir.add('META6.json').slurp);
    ($m<name>.Str, $m<version>.Str).List
}

# 场景1：正常发布到本地仓库 —— 解包出 <repo>/<name>-<version>/ 且内容完整
{
    my $d    = make-dist('ok');
    my $repo = $tmp.add('repo1'); $repo.mkdir;
    my $r = RakuPM::Author.publish($d, :to($repo.absolute.Str), :quiet(True));
    ok $r<ok>, '场景1：publish 返回 ok';
    my $drop = $repo.add('Dist-Sample-0.1.0');
    ok $drop.e && $drop.d, '场景1：落点目录 <repo>/Dist-Sample-0.1.0/ 已创建';
    ok $drop.add('META6.json').e && $drop.add('lib/Dist/Sample.rakumod').e,
        '场景1：落点含 META6.json 与 lib/Dist/Sample.rakumod';
    my ($n, $v) = meta-name-ver($drop);
    is $n, 'Dist::Sample', '场景1：落点 META6 name 正确';
    is $v, '0.1.0',       '场景1：落点 META6 version 正确';
}

# 场景2：碰撞（同版本目录已存在）无 --force 直接拒
{
    my $d    = make-dist('collide');
    my $repo = $tmp.add('repo2'); $repo.mkdir;
    RakuPM::Author.publish($d, :to($repo.absolute.Str), :quiet(True));
    dies-ok { RakuPM::Author.publish($d, :to($repo.absolute.Str), :quiet(True)) },
        '场景2：同版本已存在、无 --force → 拒绝';
}

# 场景3：碰撞加 --force 可覆盖
{
    my $d    = make-dist('force');
    my $repo = $tmp.add('repo3'); $repo.mkdir;
    RakuPM::Author.publish($d, :to($repo.absolute.Str), :quiet(True));
    my $r = RakuPM::Author.publish($d, :to($repo.absolute.Str), :force, :quiet(True));
    ok $r<ok>, '场景3：--force 覆盖同版本目录，返回 ok';
    ok $repo.add('Dist-Sample-0.1.0/lib/Dist/Sample.rakumod').e,
        '场景3：覆盖后内容仍在';
}

# 场景4：--dry 只试算，不写任何文件
{
    my $d    = make-dist('dry');
    my $repo = $tmp.add('repo4'); $repo.mkdir;
    my $r = RakuPM::Author.publish($d, :to($repo.absolute.Str), :dry(True), :quiet(True));
    ok $r<ok> && !$repo.add('Dist-Sample-0.1.0').e,
        '场景4：--dry 返回 ok 且落点目录未创建';
}

# 场景5：--from 复用现成 sdist（不再重新打包）
{
    my $d    = make-dist('from');
    my $tar  = RakuPM::Author.dist($d, :to($tmp.absolute.Str), :quiet(True))<file>.IO;
    my $repo = $tmp.add('repo5'); $repo.mkdir;
    my $r = RakuPM::Author.publish($d, :from($tar.absolute.Str), :to($repo.absolute.Str), :quiet(True));
    ok $r<ok>, '场景5：--from 复用现成包，返回 ok';
    ok $repo.add('Dist-Sample-0.1.0/META6.json').e,
        '场景5：复用包的落点含 META6.json';
    $tar.unlink if $tar.e;
}

# 场景6：check 门禁拦截（version=*）直接拒，不会发布
{
    my $d    = make-dist('badstar', :version('*'));
    my $repo = $tmp.add('repo6'); $repo.mkdir;
    dies-ok { RakuPM::Author.publish($d, :to($repo.absolute.Str), :quiet(True)) },
        '场景6：version=* 预检不过，publish 拒发布';
}

done-testing;
