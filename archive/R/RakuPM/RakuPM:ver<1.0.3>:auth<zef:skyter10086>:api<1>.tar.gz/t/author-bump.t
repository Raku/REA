use Test;
use lib 'lib';
use RakuPM::Author;
use JSON::Fast;

plan 12;

my $tmp = ($*TMPDIR // '/tmp'.IO).add("rakupm-bump-test-{now.to-posix[0].Int}");
$tmp.mkdir;

sub make-dist(Str $tag, Str :$version = '0.1.0' --> IO::Path) {
    my $d = $tmp.add("B-{$tag}");
    $d.mkdir;
    my %meta = %(
        name => 'Bump::Sample', version => $version, auth => 'github:tester',
        api => '1', description => 'x', authors => ['tester'],
        license => 'Artistic-2.0', raku => '6.d',
        provides => { 'Bump::Sample' => 'lib/Bump/Sample.rakumod' },
    );
    $d.add('META6.json').spurt(to-json(%meta, :sorted-keys));
    $d.add('Changes').spurt("# Change log for Bump::Sample\n\n## {$version}\n\n- init\n");
    $d
}

sub ver-of(IO::Path $d --> Str) { from-json($d.add('META6.json').slurp)<version>.Str }
sub changes-has(IO::Path $d, Str $h --> Bool) { $d.add('Changes').slurp.contains($h) }

# patch（默认）
{
    my $d = make-dist('patch');
    RakuPM::Author.bump($d);
    is ver-of($d), '0.1.1', 'patch：0.1.0 → 0.1.1';
    ok changes-has($d, '## 0.1.1'), 'patch：Changes 加了 ## 0.1.1';
    ok changes-has($d, '## 0.1.0'), 'patch：旧版本头 ## 0.1.0 保留';
}

# minor
{
    my $d = make-dist('minor');
    RakuPM::Author.bump($d, :minor);
    is ver-of($d), '0.2.0', 'minor：0.1.0 → 0.2.0';
}

# major
{
    my $d = make-dist('major');
    RakuPM::Author.bump($d, :major);
    is ver-of($d), '1.0.0', 'major：0.1.0 → 1.0.0';
}

# --to= 精确指定
{
    my $d = make-dist('to');
    RakuPM::Author.bump($d, :to('2.5.0'));
    is ver-of($d), '2.5.0', 'to：→ 2.5.0';
}

# version=* 无法推断 → 报错
{
    my $d = make-dist('star', :version('*'));
    dies-ok { RakuPM::Author.bump($d) }, 'star：当前版本 * 无法推断，bump 报错';
}

# --dry 不改文件，但返回目标版本
{
    my $d = make-dist('dry');
    my $r = RakuPM::Author.bump($d, :dry);
    is ver-of($d), '0.1.0', 'dry：META6 未被改动';
    is $r<to>, '0.1.1', 'dry：返回目标版本 0.1.1';
}

# 缺 Changes 时创建
{
    my $d = make-dist('nochanges');
    $d.add('Changes').unlink;
    RakuPM::Author.bump($d);
    ok $d.add('Changes').e && changes-has($d, '## 0.1.1'),
        'nochanges：缺失 Changes 时创建并加版本头';
}

# 已有 `# 标题` 的 Change log：新条目要插在标题【之后】，别把文件标题挤到下面
# （旧实现无条件前插，会造成「新版本条目在文件标题之上」的颠倒结构）
{
    my $d = make-dist('headline');
    RakuPM::Author.bump($d);
    my Str $c = $d.add('Changes').slurp;
    ok $c.starts-with('# Change log for Bump::Sample'),
        'headline：文件标题仍在最前面（没被新条目挤下去）';
    ok $c.index('## 0.1.1') > $c.index('# Change log for Bump::Sample'),
        'headline：新版本条目落在标题之后';
}
