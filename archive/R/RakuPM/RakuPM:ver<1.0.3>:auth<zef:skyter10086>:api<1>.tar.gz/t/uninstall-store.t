use Test;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Fs;

# 回归：uninstall 默认把【被卸版本的源码快照（store）】一并清掉，
# 普通用户「卸了就该没了」，不用卸完再跑一次 clean。
#   · 整包卸载（不给 --version）→ store 里该包所有版本都没了；
#   · --keep-store → 快照保留（给秒级离线重装）；
#   · --version 卸单版 → 只清那一版的 store，其余版本快照不受影响。

my $tmp = $*TMPDIR.add("_t-uninstall-store-{$*PID}-" ~ now.floor);
END { try { rm-tree($tmp) if $tmp.d } }

sub json-dist($v) {
    RakuPM::Distribution.new(:name('JSON'), :version($v), :auth('t:me'),
                             :provides(['JSON']));
}

my $src = $tmp.add('src');
$src.add('lib').mkdir;
$src.add('lib/JSON.rakumod').spurt("unit module JSON;\n");
$src.add('META6.json').spurt(q:to/META/);
    { "name": "JSON", "version": "1.0.0", "auth": "t:me",
      "provides": { "JSON": "lib/JSON.rakumod" } }
    META

my $store = RakuPM::Store.new(:root($tmp.add('store')));
my $inst  = RakuPM::Installer.new(:target($tmp), :store($store));

# 装两个版本（store 同时有源码快照）
$store.put(json-dist('1.0.0'), $src);
$store.put(json-dist('2.0.0'), $src);
$inst.install(json-dist('1.0.0'));
$inst.install(json-dist('2.0.0'));
ok  $store.has('JSON', '1.0.0') && $store.has('JSON', '2.0.0'),
   '前提：store 里两版快照都在';

# ---- 整包卸载：默认清 store ----
$inst.uninstall('JSON');
nok $store.has('JSON', '1.0.0'), '整包卸载默认清掉 1.0.0 的 store 快照';
nok $store.has('JSON', '2.0.0'), '整包卸载默认清掉 2.0.0 的 store 快照';
nok $store.path-for('JSON', '1.0.0').d || $store.path-for('JSON', '2.0.0').d,
   'store 目录也一并清掉（不用再 clean）';

# ---- --keep-store：保留快照 ----
$store.put(json-dist('2.0.0'), $src);
$inst.install(json-dist('2.0.0'));
$inst.uninstall('JSON', :keep-store);
ok $store.has('JSON', '2.0.0'), '--keep-store 时 store 快照保留';
ok $store.path-for('JSON', '2.0.0').d, 'store 目录还在';

# ---- 按 --version 卸单版：只清那一版的 store ----
$store.put(json-dist('1.0.0'), $src);
$inst.install(json-dist('1.0.0'));   # 现在 store 有 1.0.0 + 2.0.0，CUR/账本有两者
$inst.uninstall('JSON', version => '1.0.0');
nok $store.has('JSON', '1.0.0'), '按 --version 卸载只清那一版的 store';
ok  $store.has('JSON', '2.0.0'), '另一版 store 快照不受影响（仍留着）';

done-testing;
