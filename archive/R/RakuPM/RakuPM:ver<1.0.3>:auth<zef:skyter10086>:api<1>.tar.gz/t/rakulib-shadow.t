# t/rakulib-shadow.t — H11：CLI 冷启动自检 RAKULIB 遮蔽
#
# 直接测 RakuPM::CliCheck::check-rakulib-shadowing(:@chain)，用鸭子类型假仓库，
# 不依赖真实安装链，也不拖起 Client 模块图。覆盖四类：
#   1) 链上零个 RakuPM        → 静默
#   2) 单一版本（1 仓库）     → 静默
#   3) 单一版本（2 仓库同版） → 静默（只认「不同版本」才算遮蔽）
#   4) 两个不同版本（2 仓库） → 打印警告，且含「多个 RakuPM 版本」
#   5) 不响应 .installed 的仓库（FileSystem 型）→ 被排除，不影响结论

use Test;
use RakuPM::CliCheck;

# 鸭子类型假仓库：响应 .installed，dist 用 .meta 暴露 name/version。
class FakeDist {
    has %.meta;
}
class FakeRepo {
    has @.dists;
    has Str $.label = 'repo';
    method installed { @!dists }
    method path { $!label }
}

# 不响应 .installed 的仓库（模拟开发期 `use lib` 前置的 FileSystem 仓库）
class FileSystemRepo {
    has Str $.label = 'FileSystem';
}

# 在本进程内把 $*ERR 重定向到临时文件，跑 &code，返回捕获到的 stderr 文本。
sub capture-err(&code --> Str) {
    my $tmp = $*TMPDIR.add('raku-pm-shadow-' ~ $*PID ~ '-' ~ (^1_000_000).pick ~ '.txt');
    my $fh  = $tmp.open(:w);
    {
        my $*ERR = $fh;
        &code();
    }
    $fh.close;
    my $out = $tmp.slurp;
    $tmp.unlink;
    $out
}

sub dist(Str $ver --> FakeDist) { FakeDist.new(:meta(%(:name<RakuPM>, :version($ver)))); }
sub repo(Str $label, *@dists --> FakeRepo) {
    FakeRepo.new(:label($label), :dists(@dists));
}

plan 8;

# 1) 零个 RakuPM
{
    my $err = capture-err({ check-rakulib-shadowing(chain => (repo('a'),)); });
    ok $err !~~ /RakuPM/, '1) 链上无 RakuPM：静默';
}

# 2) 单一版本（1 仓库）
{
    my $err = capture-err({
        check-rakulib-shadowing(chain => (repo('a', dist('0.54.1')),));
    });
    ok $err !~~ /'多个 RakuPM'/, '2) 单一版本：静默';
}

# 3) 单一版本散落 2 仓库（同版）→ 仍静默
{
    my $err = capture-err({
        check-rakulib-shadowing(chain => (
            repo('home', dist('0.54.1')),
            repo('vendor', dist('0.54.1')),
        ));
    });
    ok $err !~~ /'多个 RakuPM'/, '3) 同版散落多仓库：静默';
}

# 4) 两个不同版本（跨 2 仓库）→ 警告
{
    my $err = capture-err({
        check-rakulib-shadowing(chain => (
            repo('home',   dist('0.54.1')),
            repo('old-site', dist('0.36.14')),
        ));
    });
    ok $err ~~ /'多个 RakuPM 版本'/, '4) 跨仓库多版本：打印警告';
    ok $err ~~ /'0.54.1'/,          '4) 警告含当前版本号';
    ok $err ~~ /'0.36.14'/,          '4) 警告含被遮蔽的旧版本号';
}

# 5) FileSystem 型（无 .installed）被排除 + 单一安装版本 → 静默
{
    my $err = capture-err({
        check-rakulib-shadowing(chain => (
            FileSystemRepo.new(:label('lib')),
            repo('home', dist('0.54.1')),
        ));
    });
    ok $err !~~ /'多个 RakuPM'/, '5) FileSystem 仓库被排除，不误报';
}

# 6) 同一仓库内多版本（CUR 多版本共存，Rakudo 取最高）→ 静默（用户现场误报场景）
{
    my $err = capture-err({
        check-rakulib-shadowing(chain => (
            repo('home', dist('0.63.0'), dist('0.64.1')),
        ));
    });
    ok $err !~~ /'多个 RakuPM'/, '6) 单仓库内多版本：静默（CUR 取最高，无害）';
}
