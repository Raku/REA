use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Fs;
use RakuPM::Distribution;
use RakuPM::Client;
use RakuPM::Repository::Local;
use RakuPM::Store;
use JSON::Fast;

# 路径安全（0.87.0 安全修复）—— 发行版名 / 版本号是**发布者可控的字符串**，
# 却被直接当作路径分量拼进 store、下载缓存、日志目录：
#     <root>/store/<name>/<version>/...
#
# 修复前 Store 里只做 `subst('::','-')`（旧私有方法 !safe-name —— 名字叫 safe，
# 其实只处理模块分隔符），而同一条路径的 `$version` 连这层都没有。实测：
#     name = "../../../../../../tmp/PWNED"
# 会把 store 内容写到 target **之外**（逃到 C:\Users\<me>\tmp\PWNED），
# 即「发布一个包就能往用户机器任意位置写文件」。
#
# 【为什么必须有端到端那几条，而单测 path-component 不够】
# 单测只能证明"净化函数本身正确"。真正要守的是**所有拼路径的地方都接了它** ——
# 漏掉任意一处，单测照样全绿而洞还在（本项目已有前科：删 role 私有方法时只 grep
# 了本文件）。所以下面必须有一条"真装一个恶意发行版，断言它被拒 + 目标之外零新增"。
#
# 【正控（照 prefix-isolation.t 的纪律）】只断言"恶意的不行"是假绿高发区：万一
# 安装链根本没走到拼路径那一步（比如 META6 没被识别），否定断言照样通过。
# 所以先断言"合法名字**确实**装成了"，后面的否定断言才有意义。

plan 85;

my $root = $*TMPDIR.add("rakupm-path-safety-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }
mkdir-p($root);

# 空本地仓库：让 Client 不去读 repositories.json / 生态索引（测试必须离线）
my $empty-repo = $root.add('empty-repo');
mkdir-p($empty-repo);

sub client(IO::Path $target) {
    RakuPM::Client.new(:$target,
                       :repos([RakuPM::Repository::Local.new(:root($empty-repo))]));
}

# 造一个最小发行版目录（name/version 原样写进 META6.json，不做任何转义）
sub make-dist(IO::Path $parent, Str $dir-name, Str $name, Str $version --> IO::Path) {
    # 【注意】发行版的**内容**是与 $name 无关的固定模块（lib/Legit/Mod.rakumod）：
    # 只把 $name / $version 写进 META6。这是刻意的 —— 负控用例会传 `../../evil`
    # 这类名字，若拿它去拼磁盘路径，造测试数据这一步自己就穿越了。
    # 代价：写断言时不能想当然按 $name 推路径（我踩过），要按这里的实际内容推。
    my $d = $parent.add($dir-name);
    mkdir-p($d.add('lib'));
    $d.add('META6.json').spurt: to-json(
        %( name => $name, version => $version,
           provides => %( 'Legit::Mod' => 'lib/Legit/Mod.rakumod' ),
         ), :sorted-keys);
    $d.add('lib/Legit').mkdir;
    $d.add('lib/Legit/Mod.rakumod').spurt("unit module Legit::Mod;\n");
    $d
}

# 跑一段代码，返回 (是否抛错, 错误消息)。Raku 限制「一个块只能有一个 CATCH」，
# 而在同一个块里要连续验多个"应当抛错"的调用，所以统一走这个 helper。
sub try-catch(&code --> List) {
    my $died = False;
    my $msg  = '';
    {
        code();
        CATCH { default { $died = True; $msg = .Str } }
    }
    ($died, $msg)
}

# 静默执行：把 $*OUT / $*ERR 临时接到一个文件上。
# 【必须有】安装失败会走回滚，回滚会 note 出 `⚠ 安装未全部成功，正在回滚…`；
# 而 t/ 的门禁标准是「输出里出现 ⚠ 或 [RakuPM] 即失败」（那些是给 zef install
# 日志看的生产级警告，测试不该喷）。测试要验的是"恶意输入被拒"，不是让警告漏出去。
sub quiet(&code) {
    my $sink = $root.add('quiet-sink.txt');
    my $fh   = $sink.open(:w);
    my $res;
    {
        my $*OUT = $fh;
        my $*ERR = $fh;
        $res = code();
    }
    $fh.close;
    $res
}

# ============================================================================
# 一、path-component 的接受 / 拒绝矩阵（净化函数本身）
# ============================================================================

# ---- 接受侧：合法名必须原样通过，且映射与 0.87.0 之前逐字节相同 ----
{
    # 旧实现 = subst('::','-')；新实现对以下输入必须给出同一结果，
    # 否则历史 store 条目会在升级后全部"失联"（被判成未入库 → 全量重装）。
    my %same =
        'JSON::Fast'   => 'JSON-Fast',
        'File::Temp'   => 'File-Temp',
        'A::B::C'      => 'A-B-C',
        'RakuPM'       => 'RakuPM',
        'foo-bar'      => 'foo-bar',
        'v0.2.0'       => 'v0.2.0',
        '0.2'          => '0.2',
        '1.0.0+meta'   => '1.0.0+meta',
        '2026.08'      => '2026.08';
    for %same.kv -> $in, $want {
        is path-component($in), $want,
           "合法分量「{$in}」→「{$want}」（与旧映射一致，历史条目不失联）";
    }

    # 单个冒号归一到 -：真实生态里存在 App:Ralc / Slang:Date（共 5 条），
    # 而 `:` 在 Windows 上是 ADS 分隔符（mkdir App:Ralc 会写成文件 App 的备用数据流）
    is path-component('App:Ralc'), 'App-Ralc', '单个冒号也归一到 -（避开 Windows ADS）';
    is path-component('Slang:Date'), 'Slang-Date', '同上（第二个真实样本）';
}

# ---- 拒绝侧：危险分量必须 die，且错误信息里点名是哪个分量、为什么 ----
{
    # (输入, 期望消息里出现的关键词, 说明)
    my @bad =
        ('../../evil',        '路径分隔符', '相对穿越（本漏洞的原始载荷）'),
        ('..',                '. 或 ..',    '分量恰为 ..'),
        ('.',                 '. 或 ..',    '分量恰为 .'),
        ('a/b',               '路径分隔符', '内嵌正斜杠'),
        ('a\\b',              '路径分隔符', '内嵌反斜杠（Windows 分隔符）'),
        ('C:/Windows/x',      '路径分隔符', '盘符 + 绝对路径'),
        ('../../../../x/y',   '路径分隔符', '多层穿越 + 嵌套'),
        ('trail.',            '以点结尾',   '结尾点（Windows 会静默剥掉 → 与 trail 撞车）'),
        ('',                  '为空',       '空串'),
        ('   ',               '为空',       '纯空白');
    for @bad -> ($in, $kw, $why) {
        my $err = '';
        my $got = do { my $r = try { path-component($in); CATCH { default { $err = .Str } } }; $r };
        ok !$got.defined, "拒绝「{$in.gist}」（$why）";
        ok $err.contains($kw), "  错误信息点名原因（含「{$kw}」）：{$err.lines[0]}";
    }
}

# ---- 归一（编码）侧：Windows 保留字符 → 百分号编码，而不是拒绝 ----
#
# 【为什么既不是"接受原样"也不是"拒绝"】`* ? " < > |` 不含路径分隔符、也不含
# `.`/`..`，**拼不出目标之外的路径**，所以没有安全含义；它们唯一的后果是
# 「这个文件名 Windows 建不出来」。旧行为把它们原样放进路径 → Windows 上报
# `Invalid argument`（重试 3 次后回滚，报错完全看不出真因）、其它平台则造出一个
# 名字就是 `*` 的垃圾文件（还会被 shell 的 glob 展开）。0.87.4 起按百分号编码归一。
{
    my %encode =
        '*' => '%2A', '?' => '%3F', '"' => '%22',
        '<' => '%3C', '>' => '%3E', '|' => '%7C', '%' => '%25';
    for %encode.kv -> $in, $want {
        is path-component($in), $want,
           "Windows 保留字符「{$in}」编码成「{$want}」（不拒绝，理由见上）";
    }
    is path-component('1.0*'),  '1.0%2A',    '版本占位符 1.0* → 1.0%2A';
    is path-component('v<1>'),  'v%3C1%3E',  'v<1> → v%3C1%3E';
    is path-component('a?b|c'), 'a%3Fb%7Cc', '多个保留字符逐个编码';

    # ★ 单射性：编码必须**一一对应**，否则两个不同分量会撞进同一个目录 ——
    #   那正是"静默清理"最危险的地方（也是这里选编码而非替换成 `_` 的原因）。
    #   · `%` 一起编码是为这条服务的：字面量 "%2A" 必须与"编码后的 *"落在不同目录；
    #   · 输入里**必须带上 `_` 类样本**：若有人把 `*` 换成 `_` 这类"好看"的替换，
    #     就会与真实存在的 `_` 撞车 —— 没有这些样本，那种错误实现是抓不到的。
    my @in = '*', '%2A', '%', '?', '%3F', 'a*', 'a%2A', 'a%25', 'A*B',
             '_', 'a_', 'A_B';
    my %out;
    my @collide;
    for @in -> $i {
        my $o = path-component($i);
        if %out{$o}:exists { @collide.push("{$i} 与 {%out{$o}} 都 → {$o}") }
        else { %out{$o} = $i }
    }
    is @collide.join('; '), '', '单射性：上述 12 个不同输入没有任何一对撞车（含 `_` 类样本）';
    is %out.elems, @in.elems, '输出个数 == 输入个数（编码没有把两个输入合并成一个）';
    isnt path-component('*'), path-component('%2A'),
         '「*」与字面量「%2A」映射到不同结果（这就是 % 必须一起编码的原因）';
}

# ---- assert-under：containment 第二道防线 ----
{
    my $base = $root.add('contain');
    mkdir-p($base);
    my $child = $base.add('a/b');
    mkdir-p($child);

    my $ok = (try { assert-under($child, $base); True }) // False;
    ok $ok, 'assert-under：子路径在根内 → 通过';

    my $self = (try { assert-under($base, $base); True }) // False;
    ok $self, 'assert-under：等于根本身 → 通过';

    my $out = (try { assert-under($base.parent.add('elsewhere'), $base); True }) // False;
    nok $out, 'assert-under：根之外的路径 → die';

    # ★ 经典陷阱：同前缀的兄弟目录 /a/bc 会被朴素的 starts-with 误判为"在 /a/b 内"。
    #   所以断言必须比对「root + 分隔符」而不是裸前缀。
    my $sib = $root.add('contain-elsewhere');
    mkdir-p($sib);
    my $sib-ok = (try { assert-under($sib, $base); True }) // False;
    nok $sib-ok, 'assert-under：同前缀兄弟目录（contain-elsewhere vs contain）→ die（不能只比裸前缀）';
}

# ============================================================================
# 二、端到端：恶意发行版必须被拒，且【目标之外零新增】
# ============================================================================
# 每个用例用一个干净的目标目录，并快照目标的**父目录**：逃逸落点一定落在那里
# （例：<root>/e1/tgt/store + ../../evil = <root>/e1/evil）。
my $work = $root.add('e2e');
mkdir-p($work);

sub snapshot(IO::Path $d --> List) {
    $d.d ?? dir($d).map(*.basename).sort.List !! ().List
}

# ---- 正控：合法名字确实能装上（否则下面的否定断言没有意义）----
{
    my $case = $work.add('ctl');
    my $tgt  = $case.add('tgt');
    mkdir-p($tgt);
    my $dist   = make-dist($case, 'src', 'Legit::Mod', '1.0.0');
    my $before = snapshot($case);        # 快照必须在造好 src 之后、安装之前

    my $ok = (try { quiet({ client($tgt).install-from-dir($dist, :no-build, :no-test) }); True }) // False;
    ok $ok, '正控：合法 name/version（Legit::Mod 1.0.0）安装成功';
    ok $tgt.add('store/Legit-Mod/1.0.0/lib/Legit/Mod.rakumod').e,
       '正控：内容确实落进了 <target>/store/<name>/<version>（证明安装链走到了拼路径那一步）';
    is-deeply snapshot($case), $before.sort.List,
       '正控：只有预期的目录，父目录无额外条目';
}

# ---- 真实生态形态：版本号是占位符 `*`（109 条）必须装得成 ----
#
# 实测（全量索引 25117 条）：version 恰为 `*` 的有 **109 个发行版**
# （Add / Algorithm::Viterbi / Apache::LogFormat…）。它们的 source-url 本身是好的
# （URL 里是 `%2A` 编码），坏的只有本地路径 —— 所以这里必须**端到端**钉住
# 「装得成 + 落在编码后的目录名里」，只测净化函数证明不了这一层。
{
    my $case = $work.add('winstar');
    my $tgt  = $case.add('tgt');
    mkdir-p($tgt);
    my $dist = make-dist($case, 'src', 'WinStar', '*');

    my ($died, $msg) = try-catch({
        quiet({ client($tgt).install-from-dir($dist, :no-build, :no-test) })
    });
    ok !$died,
       '版本号是占位符 `*` 的发行版装得成（修复前在 Windows 上报 Invalid argument）'
       ~ ($died ?? "（失败：{$msg.lines.head}）" !! '');
    # 用 .d 兜一下：装失败时 store 不存在，直接 .dir 会抛异常而不是给出一条红。
    is ($tgt.add('store/WinStar').d
            ?? $tgt.add('store/WinStar').dir.map(*.basename).sort.join(',')
            !! '(无)'), '%2A',
       '它落在编码后的目录 store/WinStar/%2A 下，且 store 里没有别的版本目录';
    # 内容检查用 `lib/` + `META.json`（不是某个具体模块文件）：make-dist 的发行版内容
    # 是【固定】的 lib/Legit/Mod.rakumod（见 helper 注释），写死具体路径会把测试
    # 和 helper 的内部细节绑死 —— 我第一版就是这么写错的。
    ok $tgt.add('store/WinStar/%2A/lib').d
       && $tgt.add('store/WinStar/%2A/META.json').e,
       '发行版内容确实落进了那个编码目录（lib/ + META.json 都在，不是只建了个空壳）';
}

# ---- 负控：恶意 name / version 一律被拒，且【具体逃逸落点】不存在 ----
# 每例多给一个 escape 路径：这是**按旧实现推算**出来的实际落点。
# 【为什么不用"快照 case 目录"代替】实测发现快照粒度太粗：version 的逃逸落点
# （<tgt>/evil）比 case 深一层，快照 case 看不出变化 → 变异验证时该条不会红，
# 等于假绿。必须断言具体路径。
{
    my @cases =
        # tag        name              version         为什么有害            推算的逃逸落点
        ('n-rel',   '../../evil',      '1.0.0',        'name 相对穿越',      -> $c, $t { $c.add('evil') }),
        ('n-dot',   '..',              '1.0.0',        'name 恰为 ..',       -> $c, $t { $t.add('1.0.0') }),
        ('n-slash', 'a/b',             '1.0.0',        'name 内嵌 /（嵌套目录）', -> $c, $t { $t.add('store/a') }),
        ('n-deep',  '../../../../deep','1.0.0',        'name 多层穿越',      -> $c, $t { $root.add('deep') }),
        ('n-drv',   'C:/evil',         '1.0.0',        'name 盘符 + 绝对路径', -> $c, $t { $t.add('store/C-/evil') }),
        ('v-rel',   'Victim',          '../../evil',   'version 相对穿越',   -> $c, $t { $t.add('evil') }),
        ('v-deep',  'Victim',          '../../../../vdeep', 'version 多层穿越', -> $c, $t { $work.add('vdeep') }),
        # version 恰为 .. 时 $dest 塌缩成 store 根本身 → META.json 直接写进 store 根
        ('v-dot',   'Victim',          '..',           'version 恰为 ..',    -> $c, $t { $t.add('store/META.json') });

    for @cases -> ($tag, $name, $version, $why, &escape-of) {
        my $case = $work.add($tag);
        mkdir-p($case);
        my $dist = make-dist($case, 'src', $name, $version);
        my $tgt  = $case.add('tgt');
        mkdir-p($tgt);
        my $escape = escape-of($case, $tgt);

        my ($died, $msg) = try-catch({
            quiet({ client($tgt).install-from-dir($dist, :no-build, :no-test) })
        });

        ok $died, "端到端拒绝：$why（{$name} / {$version}）";
        ok $msg.contains('穿越') || $msg.contains('路径分隔符') || $msg.contains('以点结尾')
                                || $msg.contains('. 或 ..') || $msg.contains('为空'),
           "  拒绝原因可读（不是内部异常）：{$msg.lines[0]}";

        # ★ 关键断言：不能只断言"命令报错"——必须断言**旧实现的逃逸落点确实不存在**。
        #   修复前这条会红：会把整个 store 条目写到 <case>/evil、<tgt>/evil 或更上层。
        nok $escape.e, "  旧实现的逃逸落点不存在：{$escape.relative($root)}（$why）";
    }
}

# ---- 逃逸落点逐一核对（把"祖先目录被污染"钉死）----
# 修复前 name=../../evil 会从 <case>/n-rel/tgt/store 逃到 <case>/n-rel/evil；
# 多层穿越会继续往上。这里显式断言这些祖先位置都没有被写入任何东西。
{
    my @escapes =
        $work.add('n-rel/evil'),
        $work.add('n-deep/deep'),
        $work.add('v-rel/evil'),
        $work.add('v-deep/vdeep'),
        $root.add('evil'),
        $root.add('deep'),
        $root.add('vdeep');
    my @hit = @escapes.grep(*.e);
    is-deeply @hit.List, ().List, '所有推算出的逃逸落点都不存在（祖先目录未被污染）';
}

# ============================================================================
# 三、path-for 自身对所有入口都净化（含 unpack 之外的那些调用点）
# ============================================================================
{
    my $store = RakuPM::Store.new(:root($root.add('st')));

    my ($died, $msg) = try-catch({ $store.path-for('../../evil', '1.0.0') });
    ok $died, 'Store.path-for(name) 净化 → 恶意 name 直接 die';
    ok $msg.contains('穿越') || $msg.contains('路径分隔符'),
       "  报错点名路径穿越：{$msg.lines[0]}";

    my ($died2, $msg2) = try-catch({ $store.path-for('Fine', '../../evil') });
    ok $died2, 'Store.path-for(version) 也净化（修复前 version 完全没处理）';
    ok $msg2.contains('版本号'), "  报错点名是【版本号】这个分量：{$msg2.lines[0]}";

    # 用逐级 .add 构造期望值，不要拼 '/'-分隔的字符串：Windows 上 .add 用反斜杠，
    # 裸字符串比较会假红（实测踩过）。
    is $store.path-for('JSON::Fast', '0.19').Str,
       $root.add('st').add('JSON-Fast').add('0.19').Str,
       'Store.path-for 对合法输入映射不变（历史条目路径不变）';
}

# ============================================================================
# 四、静态守卫：旧的不安全惯用法不得再出现在 lib/ 里
# ============================================================================
# 上面那些是**行为**测试，只覆盖 Store / Tester 这两条能端到端跑到的路径。
# 其余 4 处（Ecosystem 下载缓存 / Installer 临时名 / Author 归档名 / Git fetch 落点）
# 要造出端到端场景代价很高，而它们的保护都来自同一个 `path-component`
# —— 所以这里用一条**静态**守卫兜住"有人重新引入旧惯用法"这个回归：
# `subst('::','-')` 直接拼路径正是漏洞的根源（它只处理模块分隔符）。
# 允许出现的唯一地方是净化器自己（Fs.rakumod）。
{
    my $lib = $*PROGRAM.parent.parent.add('lib');
    my @bad;
    for walk-files($lib).grep({ .extension.lc eq 'rakumod' }) -> $f {
        next if $f.basename eq 'Fs.rakumod';          # 净化器的实现本体
        for $f.lines.pairs -> $p {
            my Str $line = $p.value;
            next if $line.trim.starts-with('#');      # 注释里提到不算
            if $line.contains("subst('::', '-'") {
                @bad.push("{$f.relative($lib)}:{$p.key + 1}  {$line.trim}");
            }
        }
    }
    is-deeply @bad.List, ().List,
      'lib/ 里没有 `subst(\'::\', \'-\')` 直接拼路径的旧惯用法'
      ~ '（一切路径分量必须走 path-component）'
      ~ (@bad.elems ?? "\n" ~ @bad.join("\n") !! '');
}
