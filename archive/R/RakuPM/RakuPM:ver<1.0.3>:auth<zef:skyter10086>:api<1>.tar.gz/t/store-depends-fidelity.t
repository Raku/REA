use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;

# 回归：store 写进 META6.json 的依赖字段（depends / build-depends / test-depends）
# 必须【原样】保留上游声明的版本/作者约束，不能退化成裸模块名。退化会导致两类错误：
#   ① 读 installed 元数据的包/测试拿到错误依赖——真实案例是 Identity::Utils
#      0.0.29 的 "can we get dependencies from identity"，上游 depends 是
#      String::Utils:ver<0.0.35+>:auth<zef:lizmat>，raku-pm 0.72.x 装出来变成
#      裸 "String::Utils"，该测试 not ok 176；
#   ② 污染 raku-pm 自己的反向依赖图（Installer.!depends-of 把约束读成 *，
#      卸载保护据此判断时会失准）。
# zef 是把原始 META6 的依赖字段原样保留，本测试钉住 raku-pm 同款行为。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-dep-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub make-src(Str $name, :$depends, :$build-depends, :$test-depends --> IO::Path) {
    my $src = $tmp.add($name);
    $src.mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add("$name.rakumod").spurt("unit module $name;");
    my %meta =
        name     => $name,
        version  => '1.0',
        auth     => 'demo:test',
        provides => { $name => "lib/$name.rakumod" };
    %meta<depends>       = $depends       if $depends.defined;
    %meta<build-depends> = $build-depends if $build-depends.defined;
    %meta<test-depends>  = $test-depends  if $test-depends.defined;
    $src.add('META6.json').spurt(to-json(%meta, :sorted-keys));
    $src
}

my $store = RakuPM::Store.new(:root($tmp.add('store')));

# ---------- 1. runtime.requires 结构（Identity::Utils 真实形态）----------
{
    my $src = make-src('DepRuntime',
        :depends({ runtime => { requires => ['String::Utils:ver<0.0.35+>:auth<zef:lizmat>'] } }));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    $store.put($dist, $src);

    my %m6 = from-json($store.path-for('DepRuntime', '1.0').add('META6.json').slurp);
    is %m6<depends><runtime><requires>[0],
       'String::Utils:ver<0.0.35+>:auth<zef:lizmat>',
       'runtime.requires 结构的 depends 原样保留 ver+auth 约束';

    # raku-pm 自己读回这份 META6 也应解析出正确版本约束（不是 *）
    my $re = RakuPM::Distribution.from-meta-file(
        $store.path-for('DepRuntime', '1.0').add('META6.json'));
    is $re.depends{'String::Utils'}, '0.0.35+',
       '反向解析 store META6：依赖版本约束正确（不是 *）';
}

# ---------- 2. 数组形式（每个元素是完整规格串）----------
{
    my $src = make-src('DepArray',
        :depends(['Foo::Bar:ver<1.2.3+>:auth<zef:x>', 'Baz:ver<0.1+>']));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    $store.put($dist, $src);

    my %m6 = from-json($store.path-for('DepArray', '1.0').add('META6.json').slurp);
    is %m6<depends>[0], 'Foo::Bar:ver<1.2.3+>:auth<zef:x>',
       '数组形式 depends 原样保留完整规格串（含 auth）';
    is %m6<depends>[1], 'Baz:ver<0.1+>',
       '数组形式 depends 第二个元素保留 ver 约束';
}

# ---------- 3. 回归保护：不再退化成裸模块名 ----------
{
    my $src = make-src('DepBare',
        :depends({ runtime => { requires => ['String::Utils:ver<0.0.35+>:auth<zef:lizmat>'] } }));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    $store.put($dist, $src);
    my %m6 = from-json($store.path-for('DepBare', '1.0').add('META6.json').slurp);
    my $flat = %m6<depends>.raku;
    nok $flat.contains('"String::Utils"') && !$flat.contains('ver<'),
       'depends 不含裸模块名（必须带 ver 约束）';
}

# ---------- 4. build-depends 原样保留（顶层数组形式，构建期依赖）----------
{
    my $src = make-src('DepBuild',
        :build-depends(['Distribution::Builder::MakeFromJSON:ver<0.1+>:auth<zef:lizmat>']));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    $store.put($dist, $src);

    my %m6 = from-json($store.path-for('DepBuild', '1.0').add('META6.json').slurp);
    is %m6<build-depends>[0],
       'Distribution::Builder::MakeFromJSON:ver<0.1+>:auth<zef:lizmat>',
       'build-depends 原样保留完整规格串（含 ver+auth）';

    my $re = RakuPM::Distribution.from-meta-file(
        $store.path-for('DepBuild', '1.0').add('META6.json'));
    is $re.build-depends{'Distribution::Builder::MakeFromJSON'}, '0.1+',
       '反向解析 store META6：build-depends 版本约束正确';
}

# ---------- 5. test-depends 原样保留（顶层数组形式，测试期依赖）----------
{
    my $src = make-src('DepTest',
        :test-depends(['Test::META:ver<0.0.8+>:auth<zef:lizmat>']));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    $store.put($dist, $src);

    my %m6 = from-json($store.path-for('DepTest', '1.0').add('META6.json').slurp);
    is %m6<test-depends>[0],
       'Test::META:ver<0.0.8+>:auth<zef:lizmat>',
       'test-depends 原样保留完整规格串（含 ver+auth）';

    my $re = RakuPM::Distribution.from-meta-file(
        $store.path-for('DepTest', '1.0').add('META6.json'));
    is $re.test-depends{'Test::META'}, '0.0.8+',
       '反向解析 store META6：test-depends 版本约束正确';
}

# ---------- 6. 三字段齐全：嵌套 depends.build.requires 时顶层 build-depends 也保真 ----------
{
    my $src = make-src('DepAll',
        :depends({ runtime => { requires => ['Foo:ver<1.0+>:auth<zef:a>'] },
                   build   => { requires => ['Maker:ver<2.0+>:auth<zef:b>'] },
                   test    => { requires => ['Tester:ver<3.0+>:auth<zef:c>'] } }),
        :build-depends(['Maker:ver<2.0+>:auth<zef:b>']),
        :test-depends(['Tester:ver<3.0+>:auth<zef:c>']));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    $store.put($dist, $src);

    my %m6 = from-json($store.path-for('DepAll', '1.0').add('META6.json').slurp);
    is %m6<depends><build><requires>[0], 'Maker:ver<2.0+>:auth<zef:b>',
       '嵌套 depends.build.requires 原样保留';
    is %m6<build-depends>[0], 'Maker:ver<2.0+>:auth<zef:b>',
       '顶层 build-depends 与嵌套结构并存时各自保真';
    is %m6<test-depends>[0], 'Tester:ver<3.0+>:auth<zef:c>',
       '顶层 test-depends 与嵌套结构并存时各自保真';
}

done-testing;
