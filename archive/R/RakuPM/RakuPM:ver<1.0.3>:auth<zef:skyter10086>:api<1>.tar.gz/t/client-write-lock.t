use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# Client.with-write-lock：CLI 每个写命令都走它。这里钉死的是「加了但没加对」
# 最常见的三种走样：
#   1. 嵌套调用（install 内部再调 install）把自己锁死；
#   2. 提前 return（--no-lock）时 LEAVE 对未初始化的 $lock 调 release 而崩；
#   3. 持锁期间没给子进程下凭证，导致 Build.pm 里再调 raku-pm 时自锁等到超时。

# 本文件在【锁的持有时段内】也可能被跑：raku-pm 自升级/自装（self-upgrade、
# install-from-git、`raku-pm install .`）时，外层写命令持着 ~/.raku-pm 上的锁，
# 而这里要跑的测试套件是它的子进程。0.44.0 之前外层会广播 RAKUPM_NO_LOCK=1，
# 子进程一继承，with-write-lock 全走 no-lock 快路径 —— 真锁从未持起，
# 「锁文件没建、另一个进程拿得到锁」三个用例当场失真（假绿）。
#
# 现在外层只下【凭证】（RAKUPM_LOCK_TOKEN），且凭证要「盘上 token 一致 +
# 锁此刻确实被占」才放行（判定见 t/file-lock-token.t）。本测试的锁在 $*TMPDIR
# 的临时 target 上、外层那把在 ~/.raku-pm 上，是不同文件 —— 凭证对不上，
# 不会误放行。但用户手动 export 的逃生舱仍会透传下来，所以照旧清干净：
%*ENV<RAKUPM_NO_LOCK>:delete;
%*ENV<RAKUPM_LOCK_TOKEN>:delete;
%*ENV<RAKUPM_LOCK_FILE>:delete;

my $dir  = $*TMPDIR.add('rakupm-wl-' ~ $*PID ~ '-' ~ now.floor).mkdir;
LEAVE { try { .unlink } for $dir.dir; try { $dir.rmdir } }
my $lib-str = $*PROGRAM.parent.parent.add('lib').Str;
my $helper  = $*PROGRAM.parent.parent.add('t').add('file-lock-helper.raku');
my $lock-file = $dir.add('.raku-pm.run.lock');

# 用空的本地目录仓库，避免测试联网拉生态索引
my $empty-repo = $*TMPDIR.add('rakupm-wlrepo-' ~ $*PID ~ '-' ~ now.floor).mkdir;
LEAVE { try { $empty-repo.rmdir } }

my $client = RakuPM::Client.new(
    :target($dir),
    :repo-root('.'),
    :repos(RakuPM::Repository::Local.new(:root($empty-repo))),
);

# ---------- 1. 正常执行，返回 block 的值 ----------
{
    my $r = $client.with-write-lock({ '返回值' }, :what('测试'));
    is $r, '返回值', 'with-write-lock 返回 block 的值';
    ok $lock-file.e, '锁文件在 target 下被创建';
}

# ---------- 2. 持锁期间别的进程拿不到（CLI 层的锁真的生效） ----------
{
    $client.with-write-lock({
        my $p = run($*EXECUTABLE, '-I', $lib-str, $helper.Str,
                    $lock-file.Str, '1', 'try', :out, :err);
        is $p.out.slurp(:close).trim, 'FAIL', '持锁期间另一个进程拿不到锁';
    }, :what('外层'));

    my $p = run($*EXECUTABLE, '-I', $lib-str, $helper.Str,
                $lock-file.Str, '1', 'try', :out, :err);
    is $p.out.slurp(:close).trim, 'GOT', 'block 结束后锁被释放';
}

# ---------- 3. 嵌套调用不死锁（install 里再调 install 是常态） ----------
{
    my &nested = {
        $client.with-write-lock({
            $client.with-write-lock({ '内层' }, :what('内层'));
        }, :what('外层'));
    };
    lives-ok(&nested, '嵌套 with-write-lock 不死锁');
}

# ---------- 4. 持锁期间给子进程下凭证，且不再广播布尔逃生舱 ----------
{
    $client.with-write-lock({
        my $tok = %*ENV<RAKUPM_LOCK_TOKEN>;
        ok $tok.defined && $tok.chars,
           '持锁期间下发凭证（Build.pm / 测试里再调 raku-pm 不会自锁）';
        nok %*ENV<RAKUPM_NO_LOCK>.defined,
           '不再广播 RAKUPM_NO_LOCK —— 那是用户逃生舱，程序不该代按（H6）';
    }, :what('凭证'));

    nok %*ENV<RAKUPM_LOCK_TOKEN>.defined,
        'block 结束后凭证被作废（不能污染后续命令）';
}

# ---------- 5. --no-lock 跳过锁，且不会因 LEAVE 崩溃 ----------
{
    my $r = '';
    my &skipped = { $r = $client.with-write-lock({ '跳过' }, :what('x'), :no-lock(True)) };
    lives-ok(&skipped, '--no-lock 时不会崩（LEAVE 里 $lock 还没赋值）');
    is $r, '跳过', '--no-lock 时 block 照常执行';
}

done-testing;
