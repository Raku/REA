use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;

# 验证 Installer.prune-other-versions：把某发行版在 CUR / store / 账本里
# 除 keep 外的所有版本一次性清掉（self-upgrade 的「覆盖安装」语义靠它）。
# 普通用户包刻意支持多版本共存，本方法只给「工具自身只该留一份」的场景用。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-prune-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 造一个声明自己版本号的模块——只有模块自带 :ver<>，才能验证真正加载了哪一份。
sub make-dist(Str $ver, IO::Path $dir) {
    $dir.mkdir;
    my $lib = $dir.add('lib');
    $lib.mkdir;
    $lib.add('PruneMe.rakumod').spurt(
        'unit module PruneMe:ver<' ~ $ver ~ '>;' ~ "\n" ~
        'sub who() is export { "我是 ' ~ $ver ~ '" }' ~ "\n");
    $dir.add('META6.json').spurt(to-json({
        name     => 'PruneMe',
        version  => $ver,
        auth     => 'demo:test',
        provides => { 'PruneMe' => 'lib/PruneMe.rakumod' },
        depends  => {},
    }, :sorted-keys));
    RakuPM::Distribution.from-meta6-file($dir.add('META6.json'));
}

my $target = $tmp.add('target');
my $store  = RakuPM::Store.new(:root($tmp.add('store')));
my $inst   = RakuPM::Installer.new(:target($target), :store($store));

my $src10 = $tmp.add('src-1.0.0');
my $src20 = $tmp.add('src-2.0.0');
my $src30 = $tmp.add('src-3.0.0');
my $d10 = make-dist('1.0.0', $src10);
my $d20 = make-dist('2.0.0', $src20);
my $d30 = make-dist('3.0.0', $src30);

# 模拟 self-upgrade 留下的「多版本共存」：三个版本都在 store + CUR + 账本里。
$store.put($d10, $src10);
$store.put($d20, $src20);
$store.put($d30, $src30);
$inst.install($d10);
$inst.install($d20);
$inst.install($d30);

is $inst.installed-versions('PruneMe').sort.join(','), '1.0.0,2.0.0,3.0.0',
   'prune 前：三个版本都记为已安装';

sub loaded-version(Str $spec --> Str) {
    my $proc = run('raku', '-I', $inst.raku-lib-spec, '-e',
                   "use PruneMe$spec; print who()", :out, :err);
    return '' if $proc.exitcode != 0;
    $proc.out.slurp(:close).trim
}

is loaded-version(':ver<1.0.0>'), '我是 1.0.0', 'prune 前：1.0.0 可加载';
is loaded-version(':ver<2.0.0>'), '我是 2.0.0', 'prune 前：2.0.0 可加载';
is loaded-version(':ver<3.0.0>'), '我是 3.0.0', 'prune 前：3.0.0 可加载';

# ===== 核心：只保留 3.0.0，清掉 1.0.0 与 2.0.0 =====
$inst.prune-other-versions('PruneMe', '3.0.0');

is $inst.installed-versions('PruneMe').join(','), '3.0.0',
   'prune 后：账本 versions[] 只剩 keep 版本 3.0.0';
is $inst.installed-version('PruneMe'), '3.0.0',
   'prune 后：激活版本字段同步为 3.0.0';

# store 侧：旧版本目录应被删，keep 版本目录还在
nok $store.path-for('PruneMe', '1.0.0').d, 'store：1.0.0 快照已删除';
nok $store.path-for('PruneMe', '2.0.0').d, 'store：2.0.0 快照已删除';
ok  $store.path-for('PruneMe', '3.0.0').d, 'store：3.0.0 快照保留';

# CUR 侧：旧版本不再可加载（证明真的从 CUR 摘掉了），keep 版本正常
is loaded-version(''), '我是 3.0.0', 'prune 后：无约束 use 拿到 3.0.0';
{
    my $p1 = run('raku', '-I', $inst.raku-lib-spec, '-e',
                 'use PruneMe:ver<1.0.0>; print who()', :out, :err);
    nok $p1.exitcode == 0, 'prune 后：use :ver<1.0.0> 失败（已从 CUR 摘掉）';
    ok ($p1.err.slurp(:close) // '').contains('Could not find'),
       'prune 后：1.0.0 报「找不到」';
}
{
    my $p2 = run('raku', '-I', $inst.raku-lib-spec, '-e',
                 'use PruneMe:ver<2.0.0>; print who()', :out, :err);
    nok $p2.exitcode == 0, 'prune 后：use :ver<2.0.0> 失败（已从 CUR 摘掉）';
}

# 整包卸载后，prune 一个不存在的包不该炸（防御性）
lives-ok { $inst.prune-other-versions('PruneMe', '3.0.0') },
   '已无旧版本时再调用 prune 是 no-op 不报错';

done-testing;
