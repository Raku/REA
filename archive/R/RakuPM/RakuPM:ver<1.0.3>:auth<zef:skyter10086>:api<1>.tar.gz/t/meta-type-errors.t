use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Fs;
use RakuPM::Distribution;
use JSON::Fast;

# 回归（0.88.1）：META6 里【声明为字符串的字段】写错类型时，必须给出人话报错，
# 而不是把裸的 Raku 内部异常甩给用户。
#
# 修复前（实测）：
#   $ raku-pm install ./VerNum
#   Type check failed in assignment to $!version; expected Str but got Rat (1.0)
# 没有文件名、没有字段上下文、也没有"该怎么改" —— 而用户其实只要给版本号加对引号。
# 受影响字段：name / version / description / builder（auth 早已单独归一成字符串）。
#
# 【为什么这些字段"报错"而不是像 auth 那样"归一"】auth 只是备注；而 name/version 是
# 发行版的**身份**（要进 store 路径与账本），且这类值**没法无损转字符串** ——
# `"version": 1.0` 到 Raku 里是 Rat，`~1.0` 得到 "1" 而不是 "1.0"。悄悄转成 "1"
# 会把用户装的东西记成另一个版本，比直接失败糟得多。

my IO::Path $root = $*TMPDIR.add("rakupm-meta-type-{$*PID}");
LEAVE { try { rm-tree($root) if $root.d } }
mkdir-p($root);

# 写一份 META6 并解析它，返回 (是否抛错, 异常文本)。
# 【CATCH 必须放在更内层的块里】它处理完异常会从【所在块】提前返回（该块值为 Nil），
# 若与 $died/$msg 同在 sub 的块里，下面 `($died, $msg)` 那行根本执行不到 → 假阴性。
sub parse(Str $file-name, Str $json --> List) {
    my $d = $root.add($file-name);
    mkdir-p($d);
    $d.add('META6.json').spurt($json);
    my $died = False;
    my $msg = '';
    {
        RakuPM::Distribution.from-meta-file($d.add('META6.json'));
        CATCH { default { $died = True; $msg = .Str } }
    }
    ($died, $msg)
}

# ---- 正控：合法 META6 必须照常解析（否则下面的否定断言没有意义）----
{
    # 【别用 q{{...}} 包 JSON】q{ } 会把**最外层花括号吃掉**（实测 `q{{A}}` → `A`），
    # 于是"合法的 JSON"变成不合法的、正控反而红了。JSON 里只有双引号没有单引号，
    # 直接用单引号字面量最稳。
    my ($died, $msg) = parse('ok-case',
        '{ "name": "Good", "version": "1.0.0", "provides": { "Good": "lib/Good.rakumod" } }');
    ok !$died, '正控：合法的 META6 解析成功' ~ ($died ?? "（{$msg.lines.head}）" !! '');
}

# ---- 类型写错：报错必须点名【文件】+【字段】+【期望/实际类型】----
{
    # (标签, META6 内容, 期望消息里出现的片段, 说明)
    my @cases =
        ('version 是数字（最常见的笔误）',
         '{ "name": "A", "version": 1.0, "provides": {} }',
         ('「version」', '期望字符串', 'Rat'), 'JSON 里版本号忘了加引号'),
        ('name 是数字',
         '{ "name": 123, "version": "1.0.0", "provides": {} }',
         ('「name」', '期望字符串', 'Int'), '名字写成了数字'),
        ('version 是数组',
         '{ "name": "A", "version": ["1.0.0"], "provides": {} }',
         ('「version」', '期望字符串', 'Array'), '照抄了别处的数组格式'),
        ('description 是数字',
         '{ "name": "A", "version": "1.0.0", "description": 42, "provides": {} }',
         ('「description」', '期望字符串', 'Int'), '描述写成数字'),
        ('builder 是数字',
         '{ "name": "A", "version": "1.0.0", "builder": 42, "provides": {} }',
         ('「builder」', '期望字符串', 'Int'), 'builder 写成数字'),
        ;
    for @cases.kv -> $i, ($label, $json, @kw, $why) {
        my ($died, $msg) = parse("bad-{$i}", $json);
        ok $died, "{$label}：抛错（{$why}）";
        my $head = ($msg.lines.head // '') ~ ' ' ~ ($msg.lines[1] // '');
        ok $head.contains('META6.json'),
           "  「{$label}」报错点名了文件（用户能定位到哪个文件）";
        for @kw -> $k {
            ok $head.contains($k), "  「{$label}」报错含「{$k}」";
        }
    }
}

# ---- 缺失 / null：同样给明确报错，且说清"这个字段不能省"----
{
    for ('缺 name', '{ "version": "1.0.0", "provides": {} }', 'name'),
        ('缺 version', '{ "name": "A", "provides": {} }', 'version'),
        ('version 是 null', '{ "name": "A", "version": null, "provides": {} }', 'version')
        -> ($label, $json, $field) {
        my ($died, $msg) = parse('miss-' ~ $field ~ '-' ~ ($json.chars), $json);
        ok $died, "{$label}：抛错（不是裸的 Type check failed）";
        ok ($msg.lines.head // '').contains('缺少必填字段'),
           "  「{$label}」报错说明是「缺少必填字段」";
        ok $msg.contains($field), "  「{$label}」报错点名缺失的是「{$field}」";
    }
}

# ---- 【防回退】数值分支不得回显"改好的字面量"----
#
# Rat 会把 1.0 归一成 1（gist 就是 "1"）。若照着解析后的值给出
# `"version": "1"` 这样的建议，用户照抄就会把版本从 1.0 悄悄改成 1 ——
# 比不给建议更糟。所以只给"加引号"的方法，不给字面量。
{
    my ($died, $msg) = parse('rat-hint', '{ "name": "A", "version": 1.0, "provides": {} }');
    ok $died, '（前提）version 写成 1.0 会抛错';
    nok $msg.contains(q{"version": "1"}),
        '数值分支不回显会改变语义的字面量（1.0 的 gist 是 1，照抄会把版本改成 1）';
    ok $msg.contains('引号'),
       '  改为给出方法性提示（加一对引号），而不是让用户照抄一个值';
}

# ---- 生态索引行：同样是外部数据，也要给人话（而不是裸异常）----
{
    my $died = False;
    my $msg = '';
    {
        RakuPM::Distribution.from-index-row(%( name => 'Idx', version => 1.5 ));
        CATCH { default { $died = True; $msg = .Str } }
    }
    ok $died, '生态索引行：version 是数字同样给可读报错（不抛裸 Type check failed）';
    ok $msg.contains('生态索引行') && $msg.contains('Idx'),
       '  报错点名数据来源（生态索引行）与条目名（便于定位到具体索引行）';
}

# ---- 端到端：用户实际看到的东西（退出码 + 能在 stderr 里找到文件与字段）----
{
    my IO::Path $repo-root = $*PROGRAM.parent.parent.absolute.IO;
    my Str $bin = $repo-root.add('bin/raku-pm.raku').Str;
    my $case = $root.add('cli');
    mkdir-p($case.add('lib'));
    $case.add('META6.json').spurt(
        '{ "name": "Clix", "version": 1.0, "provides": { "Clix": "lib/Clix.rakumod" } }');
    $case.add('lib/Clix.rakumod').spurt("unit module Clix;\n");

    # :in 必须传【已打开的句柄】（传路径会让子进程直接被杀），并显式喂 EOF
    my IO::Path $empty-in = $root.add('empty.stdin');
    $empty-in.spurt('');
    my $h = $empty-in.open(:r);
    my $p = run($*EXECUTABLE.Str, $bin, 'install', $case.Str,
                '--target=' ~ $root.add('clitgt').Str,
                '--no-build', '--no-test', '--offline',
                :in($h), :out, :err, :cwd($repo-root));
    my $err = $p.err.slurp(:close);
    $p.out.slurp(:close);
    $h.close;

    is $p.exitcode, 1, '端到端：安装「版本号类型写错」的包 → 退出码 1';
    # 只断言 ASCII 片段：子进程输出的中文编码随控制台代码页变，比不得
    ok $err.contains('META6.json'), '  stderr 里能找到出问题的文件名';
    ok $err.contains('version'),    '  stderr 里能找到出问题的字段名';
    nok $err.contains('Type check failed'),
        '  不再把裸的 Raku 内部异常（Type check failed）甩给用户';
}

# ---- 数组里的 null：滤掉，别喷 uninitialized 警告、也别造出空串资源名 ----
#
# 真实索引实测 `"resources": [null]`（Config 1.3.0 / 1.3.1，cpan 与 rea 各 2 行）。
# 旧实现 `.map(*.Str)` 会对 null 调 `~Nil` → 每次解析都在 stderr 上喷
#   Use of uninitialized value @result of type Any in string context
# 而且把空串当成一个资源名收进列表（下游拿它拼路径就是垃圾）。
{
    my $sink = $root.add('res-sink.txt');
    my $fh = $sink.open(:w);
    my $dist;
    {
        my $*ERR = $fh;
        $dist = RakuPM::Distribution.from-index-row(
            %( name => 'ResNull', version => '1.0.0', resources => [Any] ));
    }
    $fh.close;
    my $err = $sink.slurp;
    is $dist.resources.elems, 0, 'resources 里的 null 元素被滤掉（不留下空串资源名）';
    nok $err.contains('uninitialized'),
        '不喷 "Use of uninitialized value" 警告（修复前 Config 1.3.0 会喷）';
    is $dist.name, 'ResNull', '（顺带）该行其余字段照常解析';
}

# ---- 索引行里的 auth 是数组：归一成字符串，而不是撞返回类型 ----
#
# 真实索引实测 cpan 的 `Text::Sift4` 是 `"auth": ["github:titsuki"]`（5 行）。
# 旧实现只判 `.defined && .chars`，数组能通过判断却被原样返回，撞上
# `auth-of-row(--> Str)` 的返回约束：
#   Type check failed for return value; expected Str but got Array
# —— 一条真实发行版带着裸异常倒下。from-meta-file 那条路早有 !normalize-auth 兜着，
# 索引这条路漏了；现在对齐到同一实现。
{
    for ('数组形态（实测 Text::Sift4）', ['github:titsuki'], 'github:titsuki'),
        ('null 形态（实测 58 行是 "auth": null）', Any, 'unknown')
        -> ($label, $auth, $want) {
        # 【为什么要包 try-catch】不包的话，旧的坏实现会让 from-index-row 抛异常、
        # 整个测试文件在这儿**硬中止**（门禁虽然仍判失败，但拿不到"是哪条断言红"）。
        # 包起来之后回归会给出干净的 not ok + 异常文本，定位快得多。
        my $dist;
        my $died = False;
        my $msg = '';
        {
            $dist = RakuPM::Distribution.from-index-row(
                %( name => 'AuthShape', version => '1.0.0', auth => $auth ));
            CATCH { default { $died = True; $msg = .Str } }
        }
        ok !$died, "auth 是{$label}：能解析（不回退成裸异常）"
                   ~ ($died ?? "（{$msg.lines.head}）" !! '');
        is ($dist.defined ?? $dist.auth !! '(解析失败)'), $want,
           "auth 是{$label} → 归一成「{$want}」";
    }
}

done-testing;
