use Test;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Lock;
use RakuPM::Cleaner;

# 缓存回收（raku-pm clean / gc）。
#
# 背景：store 只增不减 —— self-upgrade 每升一次留一份快照、升级后的旧版本、
# 卸载后剩下的 store 条目都堆在那里。实测一台机器上 store 193M（其中 RakuPM
# 一个包 30 个版本）、cache/dist 110M。这个测试钉死两件事：
#   1. 判定边界：还在被用的版本【一个都不能删】；
#   2. 默认试算：不显式执行就一个字节都不能少。

my $tmp = $*TMPDIR.add("_t-clean-{$*PID}-" ~ now.floor);
END { try { rm-tree($tmp) if $tmp.d } }

sub rm-tree(IO::Path $d) {
    for $d.dir -> $e { $e.d ?? rm-tree($e) !! (try $e.unlink) }
    try $d.rmdir;
}

# ---------- 造一个「源码目录」 ----------
my $src = $tmp.add('src');
$src.add('lib').mkdir;
$src.add('lib/JSON.rakumod').spurt("unit module JSON;\n");
$src.add('META6.json').spurt(q:to/META/);
    { "name": "JSON", "version": "1.0.0", "auth": "t:me",
      "provides": { "JSON": "lib/JSON.rakumod" } }
    META

sub json-dist($v) {
    RakuPM::Distribution.new(:name('JSON'), :version($v), :auth('t:me'),
                             :provides(['JSON']));
}

# ---------- 三个版本的 store 条目 ----------
my $store = RakuPM::Store.new(:root($tmp.add('store')));
$store.put(json-dist('1.0.0'), $src);
$store.put(json-dist('2.0.0'), $src);
$store.put(json-dist('3.0.0'), $src);

my $inst = RakuPM::Installer.new(:target($tmp), :store($store));
my $lock = RakuPM::Lock.new(:path($tmp.add('raku-pm.lock')));

# 2.0.0 → 账本（installed.json）；3.0.0 → 只锁不装；1.0.0 → 谁都不认
$inst.install(json-dist('2.0.0'));
$lock.write((json-dist('3.0.0'),), :store($store));

# ---------- 其它类别的缓存 ----------
# 受保护条目里的 .precomp（派生产物）
my $pc = $store.path-for('JSON', '2.0.0').add('.precomp');
$pc.mkdir;
$pc.add('blob').spurt('x' x 64);
# 入库残骸：目录在但没有 META.json
my $orphan = $tmp.add('store').add('Broken').add('9.9.9');
$orphan.mkdir;
$orphan.add('half-written').spurt('...' x 32);
# 下载缓存 / 索引缓存 / git 克隆 / 原子写残留
my $dist = $tmp.add('cache/dist/zef/JSON/1.0.0');
$dist.mkdir;
$dist.add('META6.json').spurt('{}');
$tmp.add('cache/index-zef.json').spurt('[]');
my $git = $tmp.add('git-cache/github.com/foo/Bar.git');
$git.mkdir;
$git.add('HEAD').spurt('ref: refs/heads/main');
$tmp.add('cache/index-zef.json.tmp-4242').spurt('half');

my $cleaner = RakuPM::Cleaner.new(:target($tmp), :$store,
                                  :installer($inst), :$lock);
sub key(Str $n, Str $v) { $n ~ "\0" ~ $v }

# ---------- 受保护集合 ----------
my %keep = $cleaner.protected-versions;
ok %keep{key('JSON', '2.0.0')}, '账本里的版本受保护';
ok %keep{key('JSON', '3.0.0')}, '锁文件锁定的版本受保护';
nok %keep{key('JSON', '1.0.0')}, '没人认领的版本不在受保护集合里';

# ---------- 试算：默认行为 ----------
my %plan = $cleaner.plan;
my %by-kind = %plan<items>.classify(*<kind>);

ok %by-kind<store>:exists, '默认计划里有 store 旧版本';
is %by-kind<store>.elems, 1, '只回收那一个没人认领的版本';
is %by-kind<store>[0]<label>, 'JSON 1.0.0', '回收的正是 1.0.0（2.0.0/3.0.0 要留）';
ok %by-kind<orphan>:exists && %by-kind<orphan>.elems == 1, '识别出入库残骸';
ok %by-kind<precomp>:exists, '识别出受保护条目里的 .precomp（派生产物）';
ok %by-kind<dist>:exists, '默认回收下载缓存 cache/dist';
ok %by-kind<tmp>:exists, '默认回收原子写残留的 .tmp-*';
nok %by-kind<index>:exists, '索引缓存默认【不】回收（重建要重新下载）';
nok %by-kind<git>:exists, 'git 克隆缓存默认【不】回收（重建要重新 clone）';
ok %plan<bytes> > 0, "算出了可回收空间（{%plan<bytes>} 字节）";

# 试算绝不能动文件
ok $store.path-for('JSON', '1.0.0').d, '试算后 1.0.0 仍在（plan 不删任何东西）';
ok $dist.d, '试算后下载缓存仍在';

# ---------- --all：追加索引与 git 缓存 ----------
my %all = $cleaner.plan(:all);
ok %all<items>.classify(*<kind>)<index>:exists, '--all 时回收索引缓存';
ok %all<items>.classify(*<kind>)<git>:exists, '--all 时回收 git 克隆缓存';

# ---------- --name：只看指定发行版 ----------
my %named = $cleaner.plan(:name('JSON'));
# （同名发行版保留条目里的 .precomp 也一起清，所以是 precomp + store 两类）
is %named<items>.map(*<kind>).unique.sort.List, ('precomp', 'store'),
   '--name 时只回收该发行版的条目（dist/index 等不受影响）';

# ---------- --older-than：刚建的目录不该被回收 ----------
is $cleaner.plan(:older-than(1))<items>.elems, 0,
   '--older-than=1 天时刚建的缓存不回收';

# ---------- 执行：dry ----------
$cleaner.run(:dry);
ok $store.path-for('JSON', '1.0.0').d, 'run(:dry) 不删任何东西';

# ---------- 执行：真删 ----------
$cleaner.run(:dry(False));
nok $store.path-for('JSON', '1.0.0').d, '真删后 1.0.0 没了';
ok  $store.path-for('JSON', '2.0.0').d, '账本里的 2.0.0 还在';
ok  $store.path-for('JSON', '3.0.0').d, '锁定的 3.0.0 还在';
nok $pc.d, '.precomp 被清掉（受保护的条目本身还在）';
ok  $store.path-for('JSON', '2.0.0').add('META.json').e,
    '清 .precomp 没伤到条目本体';
nok $orphan.d, '残骸被清掉';
nok $tmp.add('cache/dist/zef').d, '下载缓存被清掉';
ok  $tmp.add('cache/index-zef.json').e, '索引缓存默认保留（没被顺手删了）';
ok  $git.d, 'git 克隆缓存默认保留';

# ---------- 收尾：再算一次应当没有可回收的了 ----------
is $cleaner.plan<items>.elems, 0, '回收完再算：默认范围内没有可删的了';
is $cleaner.plan(:all)<items>.map(*<kind>).sort.List, ('git', 'index'),
   '回收完再算：--all 只剩索引与 git 缓存（这两个是刻意保留的）';

# ---------- 来源 4：保留世代 manifest 引用的版本也受保护 ----------
# 隔离小场景（不干扰上面的主线）：store 里有 JSON 1.0.0；账本 / 锁 / 自家 site
# 都不认它；但一个保留世代的 manifest.json 记着它 → 必须保护，否则 rollback-to
# 那个世代时 store 已空、装不回（只能留空世代 + 警告）。这是 H3 修的真实缺口。
{
    my $g = $tmp.add('gen2');
    my $gstore = RakuPM::Store.new(:root($g.add('store')));
    $gstore.put(json-dist('1.0.0'), $src);
    my $ginst = RakuPM::Installer.new(:target($g), :store($gstore));
    my $glock = RakuPM::Lock.new(:path($g.add('raku-pm.lock')));
    # 故意：不 install（不写账本）、不 lock —— 只在世代 manifest 里出现
    my $ggen = $g.add('generations');
    $ggen.add('000001').mkdir;
    $ggen.add('000001/manifest.json').spurt(q:to/MF/);
    [ { "name": "JSON", "version": "1.0.0", "auth": "t:me",
        "provides": [ "JSON" ], "versions": [ "1.0.0" ] } ]
    MF
    $ggen.add('current').spurt('000001');

    my $gc = RakuPM::Cleaner.new(:target($g), :store($gstore),
                                 :installer($ginst), :lock($glock));

    my %gkeep = $gc.protected-versions;
    ok %gkeep{key('JSON', '1.0.0')},
       '来源4：保留世代 manifest 引用的版本（1.0.0）受保护';
    nok %gkeep{key('JSON', '9.9.9')},
       '来源4：manifest 里没出现的版本不在保护集（仍可被回收）';

    my %gplan = $gc.plan;
    my @gstore-items = %gplan<items>.grep(*<kind> eq 'store');
    nok @gstore-items.first({ .<label> eq 'JSON 1.0.0' }),
       '有世代引用时，1.0.0 不进 store 回收列表';
    is @gstore-items.elems, 0,
       '该场景下没有可回收的 store 版本（全部被保护）';
    # 试算绝不落盘：1.0.0 仍在
    ok $gstore.path-for('JSON', '1.0.0').d, '来源4 试算后 1.0.0 仍在';
}

done-testing;
