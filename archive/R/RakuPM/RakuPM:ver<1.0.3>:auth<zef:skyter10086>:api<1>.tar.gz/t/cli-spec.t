use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::CliSpec;

# RakuPM::CliSpec —— CLI 命令元数据表的单元测试。
#
# 这些表原先埋在 bin/raku-pm.raku 里，改一处要记得改好几处，而且没法单测。
# 抽成模块后可以直接断言「表与表之间的关系」—— 这类错误（漏登记分组、别名指向
# 不存在的命令、别名与规范名撞车、旗标白名单漏了公共项）以前只能靠人眼看。
#
# 注意分工：本文件只验【表本身】；生成产物（help / 补全脚本）的【逐字节等价】
# 由重构时的探针比对保证，并由 xt/ 的端到端测试长期守着。

my %flags   = cmd-flags();
my %aliases = cmd-aliases();

# ---------- 命令表 ----------
ok %flags.elems > 40, "命令表规模合理（{%flags.elems} 条）";
my @blank = %flags.keys.grep({ !$_.chars }).sort;
is @blank.join(','), '', "命令名都非空（空的：{@blank.join(',') || '无'}）";

# ---------- 别名表 ----------
my @clash = %aliases.keys.grep({ %flags{$_}:exists }).sort;
is @clash.join(','), '', "别名不与任何规范命令名撞车（撞车：{@clash.join(',') || '无'}）";

# 注意 `%h.kv` 给的是「key, value, key, value …」扁平列表，不是 Pair 列表 ——
# 对它调 `.value` 会报 "No such method 'value' for string"。要 Pair 用 `.pairs`。
# `!%h{...}:exists` 有优先级歧义（Raku 会提示 "perhaps you meant :!exists"）→ 加括号。
my @dangling = %aliases.keys.grep({ !(%flags{%aliases{$_}}:exists) }).sort;
is @dangling.join(','), '', "每个别名都指向存在的规范命令（悬空：{@dangling.join(',') || '无'}）";

# ---------- 归一化 ----------
is canonical-command('i'),   'install',   '别名 i → install';
is canonical-command('rm'),  'uninstall', '别名 rm → uninstall';
is canonical-command('ls'),  'list',      '别名 ls → list';
is canonical-command('install'), 'install',      '规范名原样返回';
is canonical-command('nosuch'),  'nosuch',       '未知名原样返回（交给后面报「未知命令」）';
is canonical-command('su'),  'self-upgrade', '别名 su → self-upgrade';

# ---------- 旗标白名单 ----------
my @common = common-flags();
ok @common.elems > 0, "公共旗标非空（{@common.elems} 项）";

for < install version clean > -> $c {
    my @missing = @common.grep({ !allowed-flags($c){$_} });
    is @missing.join(','), '', "公共旗标都进了 {$c} 的白名单（缺：{@missing.join(',') || '无'}）";
}

ok  allowed-flags('install'){'pin'},     'install 自己的旗标在（--pin）';
nok allowed-flags('version'){'pin'},     '别的命令的旗标不在（version 没有 --pin）';
nok allowed-flags('install'){'no-tets'}, '拼错的旗标不在白名单 —— 这正是它能被拦下的依据';

# ---------- 分组覆盖（新增命令忘了登记分组会在这里红）----------
my @nogroup = %flags.keys.grep({ command-group($_) eq 'other' }).sort;
is @nogroup.join(','), '', "每个命令都有分组（漏登：{@nogroup.join(',') || '无'}）";

# ---------- 两个维度 ----------
ok  writes-prefix('install'),   'install 会写前缀';
ok  writes-prefix('self-upgrade'), 'self-upgrade 会写前缀';
nok writes-prefix('installed'), 'installed 是读命令，不算写前缀';
nok writes-prefix('which'),     'which 是读命令，不算写前缀';

ok  needs-network('install'),   'install 可能联网';
ok  needs-network('search'),    'search 可能联网';
nok needs-network('installed'), 'installed 不联网';
nok needs-network('help'),      'help 不联网';

# ---------- 补全脚本（四种 shell 都要能生成，且含各自的标志性片段）----------
for < bash zsh fish pwsh > -> $sh {
    ok completion-script($sh).chars > 0, "completion-script({$sh}) 非空";
}
ok completion-script('bash').contains('_raku_pm'),  'bash 补全含函数名 _raku_pm';
ok completion-script('zsh').contains('bashcompinit'), 'zsh 走 bashcompinit';
ok completion-script('fish').contains('complete -c raku-pm'), 'fish 用 complete -c';
ok completion-script('pwsh').contains('Register-ArgumentCompleter'),
   'pwsh 用 Register-ArgumentCompleter';
is completion-script('pwsh'), completion-script('powershell'),
   'pwsh 与 powershell 是同一个别名（输出一致）';

done-testing;
