use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Fs;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Client;
use RakuPM::Repository::Local;
use JSON::Fast;

# 幽灵安装（ghost install）—— 0.87.1 修复。
#
# 【现象】install 报成功（rc=0）、账本记着已装、`installed` 列得出来、
# verify 说「✓ 没有不一致」，而 `use` 永远找不到那个模块。
#
# 【根因（两条独立成因，必须一起修）】
#   ① `provides` 是 META6 里【可以缺】的字段，生态索引里真有一大批条目缺它
#      （本机全量索引实测 25117 条里缺 146 条 / 53 个发行版，含 MIME::Base64、
#        Digest::MD5、LWP::Simple、FindBin-libs、C::Parser、JSON::RPC…）。
#      缺了它，旧代码照样写出一份 provides 为【空】的标准 META6.json →
#      CUR::Installation 一个模块都不挂。provides 被写成字符串
#      （"provides": "lib/Foo.rakumod"）也会被归一成空，同一个坑。
#   ② 就算改成「从 lib/ 反推」，反推器原先只认 .rakumod/.pm6 ——
#      FindBin-libs 3.0.2 是 `lib/FindBin/libs.pm`，照样推不出东西。
#
# 【本文件要钉死的三层】
#   A. 反推逻辑本身（provides-from-disk 的判定顺序 + .pm 识别）；
#   B. 端到端：三类发行版装完，外部 raku 进程**真的 use 得到**（唯一决定性判据）；
#   C. 兜底不再静默：lib/ 里有文件却一个模块都认不出 → 拒绝入库（而不是装个空包）；
#      已装的历史幽灵条目 → verify/doctor 能报出来。
#
# 【为什么必须有 B 那一层】A 只证明函数正确；漏接线（比如 Store 忘了换成
# provides-from-disk）单测照样全绿而洞还在 —— 本项目已有前科（初稿只列了 2 处
# 净化点，实为 6 处）。所以必须有一条「真装、真 use」的端到端。

my IO::Path $root = $*TMPDIR.add("rakupm-ghost-provides-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }
mkdir-p($root);

# 空本地仓库：让 Client 不去读 repositories.json / 生态索引（测试必须离线）
my $empty-repo = $root.add('empty-repo');
mkdir-p($empty-repo);

# 跑一段代码，把 stdout/stderr 都接走 —— t/ 门禁要求输出里不得出现 ⚠ 或 [RakuPM]
# （失败安装会打「⚠ 安装未全部成功，正在回滚…」，不接走就是门禁失败）。
sub quiet(&code) {
    my $sink = $root.add('quiet-sink.txt');
    my $fh   = $sink.open(:w);
    my $res;
    {
        my $*OUT = $fh;
        my $*ERR = $fh;
        $res = code();
    }
    $fh.close;
    $res
}

# 跑一段代码，返回 (是否抛错, 错误消息)。Raku 限制「一个块只能有一个 CATCH」，
# 而同一个块里要连验多个"应当抛错"的调用，所以统一走这个 helper。
# 【别改成 `try {} CATCH {}`】`try` 自己就把异常吞掉了，外层 CATCH 永不触发。
sub try-catch(&code --> List) {
    my $died = False;
    my $msg  = '';
    {
        code();
        CATCH { default { $died = True; $msg = .Str } }
    }
    ($died, $msg)
}

sub client(IO::Path $target) {
    RakuPM::Client.new(:$target,
                       :repos([RakuPM::Repository::Local.new(:root($empty-repo))]));
}

# 造一个最小发行版：%meta 原样写进 META6.json（想测畸形就写畸形），
# %files = 发行版根相对路径 => 内容。
sub make-dist(Str $tag, %meta, %files --> IO::Path) {
    my $d = $root.add("src-{$tag}");
    mkdir-p($d);
    $d.add('META6.json').spurt(to-json(%meta, :sorted-keys));
    for %files.kv -> $rel, $content {
        my $f = $d.add($rel);
        mkdir-p($f.parent);
        $f.spurt($content);
    }
    $d
}

# 读 store 条目里【标准 META6.json】的 provides 键 —— CUR 真正消费的就是这一份。
sub store-provides(IO::Path $target, Str $dir-name, Str $version --> List) {
    my $f = $target.add('store').add($dir-name).add($version).add('META6.json');
    return () unless $f.e;
    my $j = (try from-json($f.slurp)) // %();
    my $p = $j<provides>;
    return $p.keys.sort.List          if $p ~~ Hash;
    return $p.map({ .Str }).sort.List if $p ~~ Positional;
    ()
}

# 读 store 条目里【我们自己的 META.json】的 provides 数组（store 内部反查用）。
sub store-meta-provides(IO::Path $target, Str $dir-name, Str $version --> List) {
    my $f = $target.add('store').add($dir-name).add($version).add('META.json');
    return () unless $f.e;
    my $j = (try from-json($f.slurp)) // %();
    @($j<provides> // []).map({ .Str }).List
}

# 读账本条目里记的 provides（installed / autoremove 靠它按模块名找发行版）。
sub ledger-entry(IO::Path $target, Str $name --> Hash) {
    my $f = $target.add('installed.json');
    return %() unless $f.e;
    my $j = (try from-json($f.slurp)) // [];
    return %() unless $j ~~ Positional;
    ($j.first({ ($_<name> // '') eq $name }) // %())
}

sub ledger-provides(IO::Path $target, Str $name --> List) {
    my %e = ledger-entry($target, $name);
    %e.elems ?? @(%e<provides> // []).map({ .Str }).List !! ()
}

# 用【外部 raku 进程】验证「装完真的能 use 到」—— 幽灵安装唯一的决定性判据。
#
# 【stdin 要显式喂 EOF，但只能传「已打开的句柄」】本项目踩过的坑是「stdin 是永不投递
# 数据的管道时，Rakudo 的 CUR 安装/预编译路径会无限阻塞」（零 CPU、无子进程，完美伪装
# 成死锁），所以子进程应该显式给 EOF。但**别传路径** —— 实测（Windows，本机）：
#     :in($path.IO) / :in($path.Str) / :in('NUL')  → 子进程直接被杀：exitcode -16、零输出
#     :in($已打开的句柄)                            → 正常
# 传路径时是 Rakudo 自己去开那个文件，这条路在本环境下走不通；传句柄就绕开了它。
my $empty-in = $root.add('empty.stdin');
$empty-in.spurt('');
sub try-use(Str $spec, Str $mod --> Hash) {
    my $in = $empty-in.open(:r);
    my $p = run('raku', '-I', $spec, '-e',
                "use {$mod}; print 'USE_OK ', {$mod}::probe();",
                :in($in), :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    $in.close;
    %( rc => $p.exitcode, out => $out, err => $err )
}

# ============================================================================
# 一、provides-from-disk 的判定顺序（改造后的唯一入口）
# ============================================================================

my $unit = $root.add('unit');
mkdir-p($unit);

# (a) 声明有效 → 用声明（与 0.87.0 之前逐字节一致，不能因为改造而改变既有行为）
{
    my $d = $unit.add('Declared');
    mkdir-p($d.add('lib'));
    $d.add('lib/Declared.rakumod').spurt(q{unit module Declared;});
    is-deeply RakuPM::Distribution.provides-from-disk($d, ['Declared']),
              %('Declared' => 'lib/Declared.rakumod'),
              'provides-from-disk：有声明且磁盘上找得到 → 用声明（既有行为不变）';
}

# (b) 声明为空（= 索引行缺 provides）→ 扫 lib/ 反推
{
    my $d = $unit.add('NoDecl');
    mkdir-p($d.add('lib'));
    $d.add('lib/NoDecl.rakumod').spurt(q{unit module NoDecl;});
    is-deeply RakuPM::Distribution.provides-from-disk($d, ()),
              %('NoDecl' => 'lib/NoDecl.rakumod'),
              'provides-from-disk：无声明 → 按磁盘 lib/ 反推（F2 的主路径）';
}

# (c) 声明的模块在磁盘上一个都对不上 → 也反推（元数据写坏时的自愈）
{
    my $d = $unit.add('StaleDecl');
    mkdir-p($d.add('lib'));
    $d.add('lib/StaleDecl.rakumod').spurt(q{unit module StaleDecl;});
    is-deeply RakuPM::Distribution.provides-from-disk($d, ['Ghost::Nope']),
              %('StaleDecl' => 'lib/StaleDecl.rakumod'),
              'provides-from-disk：声明的模块在磁盘上都不存在 → 反推（而不是写一份空声明）';
}

# (d) 两边都空 → 空（调用方 Store 会据此拒绝入库）
{
    my $d = $unit.add('Nothing');
    mkdir-p($d.add('lib'));
    is-deeply RakuPM::Distribution.provides-from-disk($d, ()), %(),
              'provides-from-disk：lib/ 里没有可识别模块 → 空 Hash（交给护栏拒绝）';
}

# ============================================================================
# 二、.pm 也是模块源（F3）+ 扩展名口径只有一处
# ============================================================================

{
    is-deeply RakuPM::Distribution.module-extensions, ('.rakumod', '.pm6', '.pm'),
              'module-extensions：唯一口径，且含 .pm（老包用 .pm / .pm6）';

    my $d = $unit.add('Exts');
    mkdir-p($d.add('lib/Old'));
    $d.add('lib/A.rakumod').spurt(q{unit module A;});
    $d.add('lib/B.pm6').spurt(q{unit module B;});
    $d.add('lib/Old/C.pm').spurt(q{unit module Old::C;});

    is-deeply RakuPM::Distribution.scan-provides($d), ('A', 'B', 'Old::C'),
              'scan-provides：.rakumod / .pm6 / .pm 都算模块源';
    is-deeply RakuPM::Distribution.provides-with-paths($d, ['A', 'B', 'Old::C']),
              %('A' => 'lib/A.rakumod', 'B' => 'lib/B.pm6', 'Old::C' => 'lib/Old/C.pm'),
              'provides-with-paths：三条路径都能反推到（.pm 不再漏）';
}

# 静态守卫：别的模块不许再内联一份扩展名清单（F3 就是因为同一份知识写了两遍才漏的）
{
    my $repo-root = $*PROGRAM.parent.parent;
    my @inline;
    for walk-files($repo-root.add('lib')) -> $f {
        next unless $f.extension.lc eq 'rakumod';
        for $f.lines.kv -> $i, $ln {
            next unless $ln.contains("'.pm6'");
            next if $ln.contains('@MODULE-EXTS');    # 唯一允许处：常量定义那一行
            @inline.push("{$f.basename}:{$i + 1}");
        }
    }
    is @inline.elems, 0,
       "lib/ 里没有别处再内联扩展名清单（都走 @MODULE-EXTS / module-extensions）："
       ~ "{@inline.join(', ') || '无'}";
}

# ============================================================================
# 三、端到端：三类畸形元数据的发行版，装完外部进程必须真的 use 得到
# ============================================================================
#
# 三类各自对应一个真实成因：
#   NoProv —— 索引行整个缺 provides（53 个发行版）；
#   ProvStr —— 手写 META6 把 provides 写成字符串（normalize-provides 归一成空）；
#   PmOnly  —— 模块源是 .pm（FindBin-libs），旧反推器认不出。
#
# 【内容里的花括号必须走 q{}】Raku 双引号串里的 `{ 42 }` 会被当插值块求值 → 文件里
# 的 `{ 42 }` 被悄悄吃掉，模块编译报 "Missing block"（本测试第一版就栽在这上面）。

my @e2e =
    (%( tag => 'NoProv',  mod => 'NoProv',  dir => 'NoProv',  probe => 42,
       meta => %( name => 'NoProv', version => '1.0.0' ),
       files => %( 'lib/NoProv.rakumod' => q{unit module NoProv; our sub probe { 42 }} ) ),
     %( tag => 'ProvStr', mod => 'ProvStr', dir => 'ProvStr', probe => 43,
       meta => %( name => 'ProvStr', version => '1.0.0',
                  provides => 'lib/ProvStr.rakumod' ),
       files => %( 'lib/ProvStr.rakumod' => q{unit module ProvStr; our sub probe { 43 }} ) ),
     %( tag => 'PmOnly',  mod => 'FindBin::libs', dir => 'PmOnly', probe => 44,
       meta => %( name => 'PmOnly', version => '1.0.0' ),
       files => %( 'lib/FindBin/libs.pm' => q{unit module FindBin::libs; our sub probe { 44 }} ) ),
    );

for @e2e -> %c {
    my $src = make-dist(%c<tag>, %c<meta>, %c<files>);
    my $tgt = $root.add("tgt-{%c<tag>}");

    my ($died, $msg) = try-catch({ quiet({ client($tgt).install-from-dir($src, :no-build, :no-test) }) });
    nok $died, "端到端（{%c<tag>}）：安装成功，不再因元数据畸形而失败"
        ~ ($died ?? "（实际失败：{$msg.lines[0]}" !! '');

    # ① store 的标准 META6.json 必须真的声明了模块 —— 这份是 CUR 唯一消费的元数据
    is-deeply store-provides($tgt, %c<dir>, '1.0.0'), (%c<mod>,).List,
              "端到端（{%c<tag>}）：store 的 META6.json 声明了 {%c<mod>}";

    # ② 我们自己的 META.json 也要写生效 provides（show-store / provides-of 靠它）
    is-deeply store-meta-provides($tgt, %c<dir>, '1.0.0'), (%c<mod>,).List,
              "端到端（{%c<tag>}）：store 的 META.json 也记生效 provides";

    # ③ 账本要记【生效的】provides，否则 installed / autoremove 按模块名找不到它
    is-deeply ledger-provides($tgt, %c<meta><name>), (%c<mod>,).List,
              "端到端（{%c<tag>}）：账本记的是生效 provides（不是索引行的空声明）";

    # ④ 决定性判据：外部 raku 进程 use 得到
    my %r = try-use(client($tgt).installer.raku-lib-spec, %c<mod>);
    is %r<out>, "USE_OK {%c<probe>}",
       "端到端（{%c<tag>}）：外部 raku 进程真的 `use {%c<mod>}` 成功（幽灵安装已消除）"
       ~ (%r<out> eq '' ?? "；stderr：{%r<err>.lines.grep({ .trim.chars }).head(2).join(' | ')}" !! '');
    is %r<rc>, 0, "端到端（{%c<tag>}）：子进程正常退出（不是「装上了却加载不了」）";
}

# ============================================================================
# 四、负控：lib/ 里有文件却一个模块都认不出 → 必须拒绝，而不是装个空包
# ============================================================================
#
# 这是护栏：没有它，「修好 53 个」会变成「把静默空包装成静默空包 + 更少的日志」。
# 判定刻意放在【落盘之前】，所以拒绝时连目录都不会建。
{
    my $src = make-dist('GhostText',
        %( name => 'GhostText', version => '1.0.0' ),
        %( 'lib/notes.txt' => "这不是模块\n" ));
    my $tgt = $root.add('tgt-GhostText');

    my ($died, $msg) = try-catch({ quiet({ client($tgt).install-from-dir($src, :no-build, :no-test) }) });
    ok $died, '负控：lib/ 里只有非模块文件 → 安装明确失败（不再静默成功）';
    ok $msg.contains('拒绝入库') && $msg.contains('lib/'),
       "负控：错误信息点名「拒绝入库」与 lib/，而不是甩底层异常：{$msg.lines[0]}";
    nok $tgt.add('store/GhostText').e,
        '负控：store 里连目录都不建（判定在落盘之前）';
    is ledger-provides($tgt, 'GhostText').elems, 0,
        '负控：账本里没有该条目（不会被 installed 列出来骗人）';
}

# 附带钉死：失败安装不能破坏【已有】账本（事务性）
{
    my $tgt = $root.add('tgt-tx');
    my $good = make-dist('Good', %( name => 'Good', version => '1.0.0',
                                    provides => %('Good' => 'lib/Good.rakumod') ),
                                 %( 'lib/Good.rakumod' => q{unit module Good;} ));
    quiet({ client($tgt).install-from-dir($good, :no-build, :no-test) });
    is ledger-entry($tgt, 'Good').elems > 0, True, '事务性先决条件：正常包已记进账本';

    my $bad = make-dist('Bad', %( name => 'Bad', version => '1.0.0' ),
                                %( 'lib/notes.txt' => "x\n" ));
    try-catch({ quiet({ client($tgt).install-from-dir($bad, :no-build, :no-test) }) });
    is ledger-entry($tgt, 'Good').elems > 0, True,
       '事务性：后一次安装失败不会抹掉账本里已有的记录';
    is ledger-provides($tgt, 'Bad').elems, 0, '事务性：失败的包没有混进账本';
}

# ============================================================================
# 五、已装的历史幽灵条目必须能被 verify / doctor 查到
# ============================================================================
#
# 0.87.1 之前入库的条目已经带着空 provides 躺在用户的 store 里了；光修新安装
# 不够，必须让**旧条目**也能被查出来，否则用户永远不知道自己的包是坏的。
# 这里手造一个「lib/ 里有模块、标准 META6.json 却零声明」的条目。
{
    my $tgt = $root.add('tgt-verify');
    my $st  = RakuPM::Store.new(:root($tgt.add('store')));

    my $ghost = $st.path-for('Ghosty', '1.0.0');
    mkdir-p($ghost.add('lib'));
    $ghost.add('lib/Ghosty.rakumod').spurt(q{unit module Ghosty;});
    $ghost.add('META.json').spurt(to-json(%(
        name => 'Ghosty', version => '1.0.0', auth => 'test:me',
        provides => [], depends => %(),
    ), :sorted-keys));
    $ghost.add('META6.json').spurt(to-json(%(
        name => 'Ghosty', version => '1.0.0', auth => 'test:me', api => '1',
        provides => %(), depends => [],
    ), :sorted-keys));

    # 正控：一个健康的条目（META6.json 声明了模块）—— 绝不能被误报成幽灵
    my $ok-dir = $st.path-for('Healthy', '1.0.0');
    mkdir-p($ok-dir.add('lib'));
    $ok-dir.add('lib/Healthy.rakumod').spurt(q{unit module Healthy;});
    $ok-dir.add('META.json').spurt(to-json(%(
        name => 'Healthy', version => '1.0.0', auth => 'test:me',
        provides => ['Healthy'], depends => %(),
    ), :sorted-keys));
    $ok-dir.add('META6.json').spurt(to-json(%(
        name => 'Healthy', version => '1.0.0', auth => 'test:me', api => '1',
        provides => %('Healthy' => 'lib/Healthy.rakumod'), depends => [],
    ), :sorted-keys));

    # 【账本必须用 push 逐个加】Raku 的 `[%(...), %(...)]` 会把 Hash 展平成 Pair 序列
    # （`[...]` 单参展平那条规则），写出来的 JSON 会变成「一堆单键对象」而不是
    # 「两个完整条目」—— 测试会假绿（list-installed 里全是缺 name 的碎对象）。
    my @ledger;
    @ledger.push: %( name => 'Ghosty',  version => '1.0.0', versions => ['1.0.0'], provides => [] );
    @ledger.push: %( name => 'Healthy', version => '1.0.0', versions => ['1.0.0'], provides => ['Healthy'] );
    $tgt.add('installed.json').spurt(to-json(@ledger, :sorted-keys));

    my $inst = RakuPM::Installer.new(:target($tgt), :store($st));
    # 【用标量接 List】`quiet` 经标量把 List 带回来，再赋给 `@issues` 会得到
    # 「单元素数组（里面装着整个 List）」而不是 N 条 issue —— 断言会静默变成假绿。
    # 本项目的既有惯例也是「List 一律用 $ 接」（见 t/provides-scan.t 的注释）。
    my $issues = quiet({ $inst.consistency-issues });

    my $ghosts = $issues.grep({ (.<kind> // '') eq 'ghost-provides' });
    is $ghosts.elems, 1, 'verify：历史幽灵条目被查出（0.87.1 之前装的包不再是盲区）';
    is ($ghosts[0]<name> // ''), 'Ghosty', 'verify：报出的正是那条幽灵条目';
    ok ($ghosts[0]<detail> // '').contains('--force'),
       'verify：给出可执行的修复建议（重装），而不是只说「有问题」';
    is $issues.grep({ (.<kind> // '') eq 'ghost-provides' && (.<name> // '') eq 'Healthy' }).elems, 0,
       'verify 正控：健康条目（META6 声明了模块）不会被误报成幽灵';
}

done-testing;
