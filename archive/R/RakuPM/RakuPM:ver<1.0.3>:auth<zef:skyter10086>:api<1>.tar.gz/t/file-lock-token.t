use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::FileLock;
use RakuPM::Repository::Local;

# H6：锁的继承凭证（RAKUPM_LOCK_TOKEN）。
#
# 背景（真实事故）：0.44.0 之前，持锁进程靠 `RAKUPM_NO_LOCK=1` 给子进程开绿灯。
# 那是个「设了就开门」的全局布尔开关，任何继承了它的进程都自动拿到 bypass 权限：
#   · 在锁内跑的 t/client-write-lock.t 把锁当成没加，3 条断言恒真（假绿）；
#   · 用户随手 export 一下就绕过了锁，还无从察觉。
# 现在改成凭证制：子进程必须带父进程下的【随机 token】，且校验「盘上 token 一致」
# 加「锁此刻真的被占」。本文件钉死这个不变式，重点是两句：
#   ② 光设个变量进不了门   ⑥ 凭证随锁作废（不独立生效）

plan 20;

# 本文件可能本身跑在某个 raku-pm 写锁内（self-install 会跑 t/）——
# 清掉继承来的旁路变量，保证这里验的是真锁。
%*ENV<RAKUPM_NO_LOCK>:delete;
%*ENV<RAKUPM_LOCK_TOKEN>:delete;
%*ENV<RAKUPM_LOCK_FILE>:delete;

my $dir = $*TMPDIR.add("rakupm-locktok-{$*PID}-{now.floor}").mkdir;
my $lf  = $dir.add('.raku-pm.run.lock');
my $tf  = $dir.add('.raku-pm.run.lock.token');
my $flag = $dir.add('release.flag');          # 放行 holder 的旗标

sub rm-tree(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        my @e = $p.dir;                       # 急切收集：惰性迭代器会在 Windows 上留着目录句柄
        rm-tree($_) for @e;
        try { $p.rmdir }
    }
    else { try { $p.unlink } }
}
LEAVE { rm-tree($dir) if $dir.e }

my $lib-str = $*PROGRAM.parent.parent.add('lib').Str;
my $helper  = $*PROGRAM.parent.parent.add('t').add('file-lock-helper.raku').Str;

# ---------- 1. 凭证的生命周期（走 Client —— 必须验到编排层这一层，
#              直接拿 FileLock 测会「假绿」：那样验的是 FileLock 不设
#              RAKUPM_NO_LOCK，而该变量历史上是 Client 设的） ----------
my $empty-repo = $*TMPDIR.add("rakupm-locktok-repo-{$*PID}").mkdir;
LEAVE { try { $empty-repo.rmdir } }

my $client = RakuPM::Client.new(
    :target($dir), :repo-root('.'),
    :repos(RakuPM::Repository::Local.new(:root($empty-repo))),
);

{
    $client.with-write-lock({
        my $tok = %*ENV<RAKUPM_LOCK_TOKEN>;
        ok $tok.defined && $tok.chars, '持锁期间下发凭证（环境变量）';
        ok $tf.e, '凭证同时落到锁旁的 .token 文件（子进程据此核对）';
        is $tf.slurp.trim, ($tok // ''), '盘上凭证与环境变量一致';
        nok %*ENV<RAKUPM_NO_LOCK>.defined,
            'Client 持锁期间不广播 RAKUPM_NO_LOCK（用户逃生舱不该由程序代按）';
    }, :what('凭证测试'));

    nok %*ENV<RAKUPM_LOCK_TOKEN>.defined, '释放后环境变量里的凭证作废';
    nok $tf.e, '释放后凭证文件被清除';
}

# ---------- 2. 同进程重入不走旁路（交给引用计数） ----------
{
    my $lock = RakuPM::FileLock.new(:path($lf));
    $lock.acquire(:what('重入'), :timeout(0));
    my $outer = %*ENV<RAKUPM_LOCK_TOKEN>;
    nok RakuPM::FileLock.should-bypass($lf),
        '持锁进程自己不走旁路（否则内层会绕过引用计数、提前放锁）';

    my $inner = RakuPM::FileLock.new(:path($lf));
    $inner.acquire(:what('内层'), :timeout(0));
    is %*ENV<RAKUPM_LOCK_TOKEN>, $outer, '内层持锁不重发凭证（沿用外层）';

    $inner.release;
    nok RakuPM::FileLock.held-by-other($lf), '内层释放后锁仍在本进程手里（计数未归零）';

    $lock.release;
    nok %*ENV<RAKUPM_LOCK_TOKEN>.defined, '外层释放后凭证才作废';
}

# ---------- 3. 别的进程持锁时：三要素判定 ----------
my $holder = Proc::Async.new($*EXECUTABLE, '-I', $lib-str, $helper,
                             $lf.Str, '0', 'hold-flag', $flag.Str);
my $ready = Promise.new;
$holder.stdout.lines.tap({ $ready.keep if $_.starts-with('HELD') });
$holder.stderr.lines.tap(-> $line { });       # 丢弃，避免管道缓冲把子进程堵住
my $holder-done = $holder.start;
await $ready;                                 # 子进程已确实持锁

my $real = $tf.e ?? $tf.slurp.trim !! '';
ok $real.chars, '另一个进程持锁时盘上有凭证';
ok RakuPM::FileLock.held-by-other($lf), '（前提）锁确被另一个进程占着';

%*ENV<RAKUPM_LOCK_TOKEN>:delete;
nok RakuPM::FileLock.should-bypass($lf), '① 无凭证 → 不放行';

%*ENV<RAKUPM_LOCK_TOKEN> = 'forged-token';
nok RakuPM::FileLock.should-bypass($lf), '② 伪造凭证 → 不放行（光设变量进不了门）';

%*ENV<RAKUPM_LOCK_TOKEN> = $real;
ok RakuPM::FileLock.should-bypass($lf), '③ 正确凭证 + 锁被占 → 放行';

# ---------- 4. 端到端：子进程凭凭证直接执行（不自锁） ----------
{
    my $p = run($*EXECUTABLE, '-I', $lib-str, $helper,
                $lf.Str, '0', 'waittry', $dir.Str, :out, :err);
    my $out = $p.out.slurp(:close);
    $p.err.slurp(:close);
    ok $out.contains('BYPASSED'),
        '④ 带父进程凭证的子进程直接执行（Build.pm 里再调 raku-pm 不自锁）';
}

# ---------- 5. 端到端反面：伪造凭证必须被挡在门外 ----------
{
    my $saved = %*ENV<RAKUPM_LOCK_TOKEN>;
    %*ENV<RAKUPM_LOCK_TOKEN> = 'forged-token';
    my $p = run($*EXECUTABLE, '-I', $lib-str, $helper,
                $lf.Str, '0', 'waittry', $dir.Str, :out, :err);
    my $out = $p.out.slurp(:close);
    $p.err.slurp(:close);
    %*ENV<RAKUPM_LOCK_TOKEN> = $saved;
    ok $out.contains('BLOCKED'),
        '⑤ 伪造凭证的子进程被挡（排队，不放行）—— 相对旧机制的关键修复';
}

$flag.spurt('');                              # 放行 holder
await $holder-done;

# ---------- 6. 凭证随锁作废 ----------
nok $tf.e, '父进程释放后凭证文件被清除';
%*ENV<RAKUPM_LOCK_TOKEN> = $real;             # 拿着已经过期的凭证
nok RakuPM::FileLock.should-bypass($lf), '⑥ 过期凭证不放行（父进程已放锁）';

# 凭证不独立生效：锁没人占时，token 对得上也不放行
my $lonely = $dir.add('lonely.lock');
$lonely.spurt('');
$dir.add('lonely.lock.token').spurt('stale-token');
%*ENV<RAKUPM_LOCK_TOKEN> = 'stale-token';
nok RakuPM::FileLock.should-bypass($lonely), '⑦ 凭证对应的锁没被占 → 不放行';

%*ENV<RAKUPM_LOCK_TOKEN>:delete;
