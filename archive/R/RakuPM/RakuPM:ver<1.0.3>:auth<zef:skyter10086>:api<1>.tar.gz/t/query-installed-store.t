use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use JSON::Fast;
use RakuPM::Client;
use RakuPM::Repository::Local;

# installed [模块名] / store [模块名]：带模块名参数查看某包的版本，
# store 按版本号列出完整路径。用临时 RAKUPM_TARGET 跑真 CLI 子进程验证。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $bin = $*PROGRAM.parent(2).add('bin').add('raku-pm.raku');
my $tmp = $*TMPDIR.add('rakupm-query-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $target = $tmp.add('t');
my $client = RakuPM::Client.new(
    :target($target),
    :repos([RakuPM::Repository::Local.new(:root($tmp.add('r').mkdir))]),
);

# 真装两版本：Dual 0.9.2 + 0.13.0（store 会有两套缓存），再加 Lone 1.2.3
sub mk-src($name, $ver) {
    my $s = $tmp.add("{ $name }-{ $ver }-src").mkdir;
    $s.add('lib').mkdir;
    $s.add('lib').add("$name.rakumod").spurt("unit module $name;");
    $s.add('META6.json').spurt(to-json({
        name => $name, version => $ver, auth => 'demo',
        provides => { $name => "lib/$name.rakumod" }, depends => {},
    }, :sorted-keys));
    $s
}
$client.install-from-dir(mk-src('Dual', '0.9.2'),  :no-test);
$client.install-from-dir(mk-src('Dual', '0.13.0'), :no-test);
$client.install-from-dir(mk-src('Lone', '1.2.3'),  :no-test);

sub cli(@args) {
    my %env = %( %*ENV, RAKUPM_TARGET => $target.absolute );
    run('raku', $bin.absolute.Str, |@args, :out, :err, :env(%env))
}

# ---------- installed 无参数：全部列出（0.65.0 起为表格渲染）----------
{
    my $p  = cli(('installed',));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed 退出码 0';
    # 表格里包名与版本被竖线分隔（| Dual | 0.13.0 |），不再空格相连，
    # 故断言「两个字段各自出现」。非 TTY 走 ASCII 边框，无 ANSI 转义。
    ok $out.contains('Dual') && $out.contains('0.13.0'), 'installed：列出 Dual 0.13.0';
    ok $out.contains('0.9.2'),  'installed：列出 Dual 0.9.2（多版本全列）';
    ok $out.contains('Lone') && $out.contains('1.2.3'),  'installed：列出 Lone';
}

# ---------- installed Dual：只看这一个包 ----------
{
    my $p  = cli(('installed', 'Dual'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed <模块> 退出码 0';
    ok $out.contains('已安装（raku-pm）：Dual'), 'installed <模块>：只查 Dual';
    # 激活标记：非 TTY 下退化为 *（富文本终端下是绿点 ●），断言 * 即可
    ok $out.contains('*'), 'installed <模块>：激活版本（最高）标 *';
    ok $out.contains('0.13.0') && $out.contains('0.9.2'),
       'installed <模块>：两个版本都列出';
    nok $out.contains('Lone'),         'installed <模块>：不列出其它包';
    ok $out.contains('来源'),          'installed <模块>：显示来源列';
}

# ---------- installed 不存在的模块：明确提示 ----------
{
    my $p  = cli(('installed', 'NoSuchMod'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed <不存在> 退出码 0';
    ok $out.contains('NoSuchMod 未安装'), 'installed <不存在>：提示未安装';
}

# ---------- store 无参数：全部 + 每版本完整路径 ----------
{
    my $p  = cli(('store',));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'store 退出码 0';
    ok $out.contains('Dual 0.13.0'), 'store：列出 Dual 0.13.0';
    ok $out.contains('Dual 0.9.2'),  'store：列出 Dual 0.9.2';
    # 完整路径断言（版本目录用实际 disk 路径）
    my $path = $client.store.path-for('Dual', '0.13.0').absolute;
    ok $out.contains($path), "store：显示版本目录完整路径（{$path}）";
}

# ---------- store Dual：只看这一个包 ----------
{
    my $p  = cli(('store', 'Dual'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'store <模块> 退出码 0';
    ok $out.contains('Dual 的缓存版本'), 'store <模块>：标题带模块名';
    ok $out.contains('Dual 0.9.2'),      'store <模块>：列出低版本';
    ok $out.contains('* Dual 0.13.0'),   'store <模块>：激活版本标 *';
    nok $out.contains('Lone'),           'store <模块>：不列出其它包';
    my $path = $client.store.path-for('Dual', '0.9.2').absolute;
    ok $out.contains($path), 'store <模块>：低版本也带完整路径';
}

# ---------- store 不存在的模块：提示 ----------
{
    my $p  = cli(('store', 'NoSuchMod'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'store <不存在> 退出码 0';
    ok $out.contains('store 里没有 NoSuchMod'), 'store <不存在>：提示没有';
}

done-testing;
