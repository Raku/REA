use Test;
use lib 'lib';
use RakuPM::Author;
use RakuPM::Fs;
use JSON::Fast;

# 让 check 门禁在测试环境里稳定通过（auth 与 dist 一致，不告警不报错）
%*ENV<RAKUPM_AUTHOR_AUTH> = 'github:tester';

plan 19;

my $tmp = ($*TMPDIR // '/tmp'.IO).add("rakupm-dist-test-{now.to-posix[0].Int}");
$tmp.mkdir;

sub make-dist(Str $tag, Str :$version = '0.1.0', Bool :$with-build = False --> IO::Path) {
    my $d = $tmp.add("D-{$tag}");
    $d.mkdir;
    my %meta = %(
        name => 'Dist::Sample', version => $version, auth => 'github:tester',
        api => '1', description => 'a sample dist', authors => ['tester'],
        license => 'Artistic-2.0', raku => '6.d',
        provides => { 'Dist::Sample' => 'lib/Dist/Sample.rakumod' },
        depends => %( runtime => %( requires => [] ) ),
        test-depends => ['Test'],
    );
    $d.add('META6.json').spurt(to-json(%meta, :sorted-keys));
    my $lib = $d.add('lib/Dist/Sample.rakumod'); mkdir-p($lib.parent);
    $lib.spurt("unit module Dist::Sample;\n");
    my $t = $d.add('t/01-basic.rakutest'); mkdir-p($t.parent);
    $t.spurt("use Test; use-ok 'Dist::Sample'; done-testing;\n");
    $d.add('Changes').spurt("# Change log for Dist::Sample\n\n## {$version}\n\n- init\n");
    if $with-build {
        $d.add('Build.pm').spurt(q:to/BUILD/);
        spurt('generated.txt', "built\n");
        BUILD
    }
    $d
}

# 读归档内容交给模块自身的 tar-archive-list 做路径转换：原生 Windows（BSD tar）
# 收 C:/…，Git Bash（GNU tar）收 /c/…，两种 tar 都能正确读，不在此重复转换逻辑。
sub tar-list(IO::Path $out --> List) {
    RakuPM::Author.tar-archive-list($out);
}

# 场景1：正常打包（含门禁通过）
{
    my $d = make-dist('ok');
    my $r = RakuPM::Author.dist($d, :to($tmp.absolute.Str), :quiet(True));
    my $out = $tmp.add('Dist-Sample-0.1.0.tar.gz');
    ok $out.e, '场景1：tar 包已生成';
    my @list = tar-list($out);
    ok @list.grep({ $_ eq 'META6.json' }), '场景1：含 META6.json';
    ok @list.grep({ $_ eq 'lib/Dist/Sample.rakumod' }), '场景1：含 lib/Dist/Sample.rakumod';
    ok @list.grep({ $_ eq 't/01-basic.rakutest' }), '场景1：含 t/01-basic.rakutest';
    ok $r<ok> && $r<name> eq 'Dist::Sample' && $r<version> eq '0.1.0',
        '场景1：返回 ok/name/version 正确';
    ok @list.grep(*.contains('Dist-Sample-0.1.0.tar.gz')) == 0,
        '场景1：正在生成的包自身被排除';
    $out.unlink;
}

# 场景2：构建阶段产物进包
{
    my $d = make-dist('build', :with-build);
    RakuPM::Author.dist($d, :to($tmp.absolute.Str), :quiet(True));
    my $out = $tmp.add('Dist-Sample-0.1.0.tar.gz');
    my @list = tar-list($out);
    ok @list.grep({ $_ eq 'generated.txt' }), '场景2：Build.pm 产物 generated.txt 进包';
    $out.unlink;
}

# 场景3：--no-build 跳过构建
{
    my $d = make-dist('nobuild', :with-build);
    RakuPM::Author.dist($d, :to($tmp.absolute.Str), :no-build, :quiet(True));
    my $out = $tmp.add('Dist-Sample-0.1.0.tar.gz');
    my @list = tar-list($out);
    ok @list.grep({ $_ eq 'generated.txt' }) == 0, '场景3：--no-build 时构建产物不在包内';
    $out.unlink;
}

# 场景4：check 门禁失败（version=*）直接拒
{
    my $d = make-dist('badstar', :version('*'));
    dies-ok { RakuPM::Author.dist($d, :to($tmp.absolute.Str), :quiet(True)) },
        '场景4：version=* 预检不过，dist 拒打包';
}

# 场景5：--dry 不生成文件
{
    my $d = make-dist('dry');
    my $r = RakuPM::Author.dist($d, :to($tmp.absolute.Str), :dry(True), :quiet(True));
    my $out = $tmp.add('Dist-Sample-0.1.0.tar.gz');
    ok !$out.e && $r<ok>, '场景5：--dry 未生成 tar 包且返回 ok';
}

# 场景6：隐藏项（.gitignore / .workbuddy / .workflow）不进 sdist
# 回归 0.74.1：dist 按【目录】扫描、不读 .gitignore，曾把被 gitignore 的私有目录
# （如仓库里的 .workbuddy/ 工作记忆）一起打进发布包发到公开生态。
{
    my $d = make-dist('hidden');
    mkdir-p($d.add('.workbuddy/memory'));
    $d.add('.workbuddy/memory/2026-01-01.md').spurt("private note\n");
    mkdir-p($d.add('.workflow'));
    $d.add('.workflow/ci.yml').spurt("name: ci\n");
    $d.add('.gitignore').spurt(".precomp/\n");
    $d.add('.gitattributes').spurt("* text=auto\n");
    $d.add('raku-pm.lock').spurt("lock\n");
    RakuPM::Author.dist($d, :to($tmp.absolute.Str), :quiet(True));
    my $out = $tmp.add('Dist-Sample-0.1.0.tar.gz');
    my @list = tar-list($out);
    ok @list.grep({ $_ eq 'META6.json' }), '场景6：常规文件照常进包';
    ok @list.grep(*.contains('workbuddy')) == 0, '场景6：.workbuddy/ 私有目录不进包';
    ok @list.grep(*.contains('workflow')) == 0, '场景6：.workflow/ 不进包';
    ok @list.grep({ $_ eq '.gitignore' || $_ eq '.gitattributes' }) == 0,
        '场景6：根级 dot 文件不进包';
    ok @list.grep({ $_ eq 'raku-pm.lock' }) == 0, '场景6：raku-pm.lock 锁文件不进包';
    $out.unlink;
}

# 场景7：.distignore 自定义排除清单（文件保留在仓库、但不进 sdist）
# 回归 0.75.0：隐藏项过滤只挡「以 . 开头」的东西，挡不住【名字正常的内部文件】
# （AI 指令 / 内部路线图 / 内部手册）。作者在发行版根写 .distignore 逐条列出即可。
# 注意本场景里所有条目都能匹配到真实文件 —— 若有拼错，`!tar-gz` 会往 stderr 喷
# `⚠ …没有匹配到任何文件`，而 t/ 门禁要求测试输出洁净，于是会直接变红（即隐式断言）。
{
    my $d = make-dist('distignore');
    $d.add('CODEBUDDY.md').spurt("internal ai notes\n");
    $d.add('REFACTOR-ISSUES.md').spurt("internal roadmap\n");
    mkdir-p($d.add('internal/notes'));
    $d.add('internal/notes/plan.md').spurt("internal plan\n");
    $d.add('.distignore').spurt(
        "# 注释行与空行不该有影响\n"
      ~ "CODEBUDDY.md        # 行尾注释也认（# 前须有空白）\n"
      ~ "REFACTOR-ISSUES.md\n"
      ~ "\n"
      ~ "internal/           # 目录条目覆盖整棵子树\n"
    );
    RakuPM::Author.dist($d, :to($tmp.absolute.Str), :quiet(True));
    my $out = $tmp.add('Dist-Sample-0.1.0.tar.gz');
    my @list = tar-list($out);
    ok @list.grep({ $_ eq 'CODEBUDDY.md' }) == 0,
        '场景7：.distignore 列出的文件不进包';
    ok @list.grep(*.contains('REFACTOR-ISSUES')) == 0,
        '场景7：第二条同样生效（行尾注释/空行不影响匹配）';
    ok @list.grep(*.contains('internal/')) == 0,
        '场景7：目录条目覆盖整棵子树';
    ok @list.grep({ $_ eq 'META6.json' }) && @list.grep({ $_ eq '.distignore' }) == 0,
        '场景7：常规文件照常进包，且 .distignore 自身不进包';
    $out.unlink;
}
