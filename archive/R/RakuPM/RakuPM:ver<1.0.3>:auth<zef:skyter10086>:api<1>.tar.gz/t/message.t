use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Message;

# RakuPM::Message —— 用户面消息出口与退出码常量。
#
# 本轮（0.68.0）是【收口】：把散落 bin 里 20 多处的裸 die / note 归到统一出口，
# 且**不改任何文案、不改任何退出码** —— 那一点由探针的「stdout + stderr + exit code
# 三者逐字节比对」保证（24 个固定输入探针 × 3 类产物 = 72 个文件全 IDENTICAL）。
# 这个测试文件守的是更底层的三条契约：
#   ① 退出码常量值固定（历史就是 0/1，外部脚本已依赖；本轮刻意不拆成 2）；
#   ② die 类出口【原样】抛出传入的消息（不加前缀、不改写、不吞）；
#   ③ msg-* 只写 stderr、且【不加任何前缀】—— 一旦加了，"逐字节不变"就不成立了。

my $lib = $*PROGRAM.parent.parent.add('lib').Str;

# ---------- ① 退出码常量 ----------
is EXIT-OK,   0, 'EXIT-OK = 0（成功；含无参数打印帮助这种纯查询）';
is EXIT-FAIL, 1, 'EXIT-FAIL = 1（业务失败与用法错共用 —— 勿轻改成 2）';

# ---------- ② die 类：message 逐字原样 ----------
{
    my $caught = '<未抛出>';
    try {
        usage-die '请指定要安装的模块名';
        CATCH { default { $caught = .message } }
    }
    is $caught, '请指定要安装的模块名', 'usage-die 抛出的 message 与传入逐字一致';
}
{
    my $caught = '<未抛出>';
    try {
        fail-die '测试未通过（foo.t 失败）';
        CATCH { default { $caught = .message } }
    }
    is $caught, '测试未通过（foo.t 失败）', 'fail-die 抛出的 message 与传入逐字一致';
}

# ---------- 环境噪音过滤：RAKULIB 里的 `.pm` 会让 rakudo 喷提示 ----------
#
# 【为什么必须有这一层】rakudo 每个进程都会检查 RAKULIB 链上的 FileSystem 仓库，
# 只要那里有 `.pm` 扩展名的模块就往 stderr 喷一段 deprecation 提示：
#
#   Saw 1 occurrence of deprecated code.
#   ================================================================================
#   .pm file extension in raku library path seen at:
#     file#/home/user/raku-modules, line 0
#   --------------------------------------------------------------------------------
#   Please contact the author to have these occurrences of deprecated code
#   adapted, so that this message will disappear!
#
# 而"用户自己的 RAKULIB 目录里放着模块源码"**正是 raku-pm 的目标场景**（见
# Installer/ShellTemplates 那条注释：raku-pm 装的东西要能在 `~/raku-modules` 这种
# FileSystem 仓库里被看见）。于是**在这类机器上，下面"stderr 逐字节等于 E/W/H"的
# 断言会假红**，原因却与 raku-pm 毫无关系 —— 实测：用户 `~/raku-modules` 里出现一个
# `B-Raku/lib/B/Raku.pm` 之后，本文件立刻变红。
#
# 【过滤的边界】只丢**rakudo 自己那块提示**（首行 `Saw N occurrence … of deprecated
# code.` 到尾行 `… this message will disappear!`，含其中分隔线），其余一个字节都不动：
# 产品自己多写一行仍会让断言红 —— 下面有专门的负面断言钉住这一点。
# （放宽类改动必须配负面断言，否则"过滤"会悄悄退化成"什么都放过"。）
sub strip-rakudo-env-noise(Str $s --> Str) {
    my Bool $in = False;
    my @keep;
    for $s.lines -> $l {
        if !$in && $l.starts-with('Saw ') && $l.contains('of deprecated code') {
            $in = True;
            next;
        }
        if $in {
            $in = False if $l.contains('this message will disappear');
            next;
        }
        @keep.push($l);
    }
    @keep.elems ?? (@keep.join("\n") ~ "\n") !! ''
}

{
    my Str $noise = "Saw 1 occurrence of deprecated code.\n"
                  ~ ("=" x 80) ~ "\n"
                  ~ ".pm file extension in raku library path seen at:\n"
                  ~ "  file#/home/user/raku-modules, line 0\n"
                  ~ ("-" x 80) ~ "\n"
                  ~ "Please contact the author to have these occurrences of deprecated code\n"
                  ~ "adapted, so that this message will disappear!\n";
    is strip-rakudo-env-noise("E\nW\nH\n"), "E\nW\nH\n",
       '环境噪音过滤：没有噪音时逐字节原样保留（过滤不是"顺手清屏"）';
    is strip-rakudo-env-noise("E\nW\nH\n" ~ $noise), "E\nW\nH\n",
       '环境噪音过滤：剥掉 rakudo 的 .pm 提示块（噪音在产品输出之后）';
    is strip-rakudo-env-noise($noise ~ "E\nW\nH\n"), "E\nW\nH\n",
       '环境噪音过滤：噪音在产品输出之前同样剥掉';
    nok strip-rakudo-env-noise("E\nW\nH\nEXTRA\n") eq "E\nW\nH\n",
       '环境噪音过滤【不放松】：产品自己多写的一行不许被当作噪音丢掉（负面断言）';
}

# ---------- ③ msg-* 的去向与格式 ----------
# 起真子进程，直接看真实 fd —— 比在进程内捕获更接近用户看到的实际情况。
{
    my $prog = 'use RakuPM::Message; msg-error "E"; msg-warn "W"; msg-hint "H";';
    my $p = run('raku', '-I', $lib, '-e', $prog, :out, :err);
    my $o = $p.out.slurp(:close);
    my $e = $p.err.slurp(:close);

    is $p.exitcode, 0, 'msg-* 不改变退出码（正常结束为 0）';
    is $o, '',        'msg-* 不写 stdout —— 正常输出流不被报错污染';
    is strip-rakudo-env-noise($e), "E\nW\nH\n",
       'msg-error/warn/hint 各写一行到 stderr，且【不加任何前缀】'
       ~ '（rakudo 自身的 RAKULIB 提示已按上面的边界剥离）';
}

# ---------- 与 RakuPM::UI 的边界 ----------
# Message 只管「说什么」；上色是 UI 的事。这里钉住「Message 的输出里没有 ANSI 转义」，
# 否则「非 TTY / NO_COLOR 自动降级」那条约束会从 Message 这里漏出去。
{
    my $prog = 'use RakuPM::Message; msg-error "colored?"; usage-die "boom";';
    my $p = run('raku', '-I', $lib, '-e', $prog, :out, :err);
    my $all = $p.out.slurp(:close) ~ $p.err.slurp(:close);
    nok $all.contains("\e["), 'Message 的输出不含任何 ANSI 转义（上色归 RakuPM::UI 管）';
}

done-testing;
