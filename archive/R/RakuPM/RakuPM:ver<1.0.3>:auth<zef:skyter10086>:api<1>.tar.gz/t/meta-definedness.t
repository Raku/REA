use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 回归守卫：读【外部】CUR 元数据时必须先兜 undefined，再做字符串比较。
#
# 现场（0.46.1 在 Linux 上，用户报的）：
#     $ raku-pm version
#     Use of Nil in string context
#     in block  at .../site/resources/12FDAD76... line 76
#     raku-pm v0.46.1
#     ...
# 根因：bin/raku-pm.raku 里
#     return ($d.meta<version> // $d.meta<ver> // 'unknown')
#         if $d.meta<name> eq 'RakuPM';
# 是【一条跨行语句】。`eq` 是字符串比较，会对左操作数调 .Str；某些已装发行版的
# meta 里没有 name 字段 → Nil → 警告。Rakudo 报的行号是这条语句的起始行（76），
# 所以现场指到了看起来毫无插值的第 76 行。
#
# 注意这不是平台 bug —— 是「拿外部数据做字符串比较却没兜 undefined」。
# 之所以 Linux 上才现形，只是那台机器的仓库链里恰好有一个无 name 的发行版。
# 项目里 20+ 处读 CUR meta 的地方本来就都写了 `// ''`，只有 CLI 这一处漏了。

# ---------- 1. 先证明这个坑是真的（否则本文件就是空谈）----------
sub run-raku(Str $file) {
    my $p = run($*EXECUTABLE.Str, $file, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

# 同一份探针，只差「有没有那行守卫」——用来证明守卫是承重的。
# 用单引号拼（双引号会把 %m 插值掉）。
my @body-lines =
    'my %m = Hash.new;',
    q{%m<version> = '0.46.1';   # 故意没有 name},
    'my $out = "unknown";',
    'for 1..1 -> $d {',
    '    next unless GUARD;',
    '    $out = (%m<version> // %m<ver> // "unknown");',
    '}',
    'say $out;',
;
my $body = @body-lines.join("\n") ~ "\n";

my $dir = $*TMPDIR.add("rakupm-metaguard-{$*PID}");
$dir.mkdir;
LEAVE {
    return unless $dir.e;
    for $dir.dir { try .unlink }
    try $dir.rmdir;
}

my $f-unguarded = $dir.add('unguarded.raku');
my $f-guarded   = $dir.add('guarded.raku');
$f-unguarded.spurt($body.subst('GUARD', q[%m<name> eq 'RakuPM']));
$f-guarded.spurt($body.subst('GUARD', q[((%m<name> // '') eq 'RakuPM')]));

my ($rc-u, $out-u, $err-u) = run-raku($f-unguarded.Str);
my ($rc-g, $out-g, $err-g) = run-raku($f-guarded.Str);

ok $err-u.contains('string context'),
   '不加守卫时确实喷 string-context 警告（这就是要防的坑）';
is $rc-u, 0, '警告不影响退出码（所以它很容易被忽略，只在 stderr 上刷一行）';
is $out-u.trim, 'unknown', '不加守卫时语义仍正确（只是吵）';

nok $err-g.contains('string context'),
   '加上 // 兜底后完全没有 string-context 警告';
is $rc-g, 0, '加了守卫仍正常退出';
is $out-g.trim, 'unknown', '加了守卫语义不变';

# 两种写法必须给出同一个结论（守卫只消除噪音，不改判定）
is $out-g.trim, $out-u.trim, '两种写法的判定结果一致';

# ---------- 2. 全库静态检查：不许再出现 meta<...> 直接 eq/ne ----------
#
# 只扫【产品代码 + 测试】：meta<KEY> 后面（同行内）紧跟 eq/ne 就是漏了守卫。
# 正确写法中间隔着 `// '' )`，不会命中。
my $root = $*PROGRAM.parent.parent.absolute.IO;

sub walk-code(IO::Path $dir --> List) {
    my @out;
    for $dir.dir.sort({ .basename }) -> $e {
        next if $e.basename eq '.precomp' || $e.basename eq '.git';
        if $e.d { @out.append(walk-code($e)) }
        elsif $e.extension.lc eq 'rakumod' | 'raku' | 't' | 'rakutest' { @out.push($e) }
    }
    @out.List
}

my regex UNGUARDED { 'meta<' <[A..Za..z0..9_-]>+ '>' \s* [ 'eq' | 'ne' ] <|w> }

my @hits;
for <lib bin tools t xt> -> $sub {
    my $d = $root.add($sub);
    next unless $d.d;
    for walk-code($d) -> $f {
        # 本文件自身会提到这个模式（就在上面这行 regex 和注释里），跳过自己
        next if $f.absolute.Str eq $*PROGRAM.absolute.Str;
        for $f.lines.kv -> $i, $line {
            next if $line.trim.starts-with('#');
            next unless $line ~~ &UNGUARDED;
            @hits.push($f.relative($root).Str ~ ':' ~ ($i + 1) ~ '  ' ~ $line.trim);
        }
    }
}

is @hits.elems, 0, '没有任何 meta<...> 直接做字符串比较的地方（都必须先 // 兜 undefined）';
diag "  命中：$_" for @hits.head(20);
diag "  改法：把 ((X.meta<name> // '') eq 'Y') 写全，别指望 Nil 能安静地参与字符串比较。"
    if @hits.elems;

done-testing;
