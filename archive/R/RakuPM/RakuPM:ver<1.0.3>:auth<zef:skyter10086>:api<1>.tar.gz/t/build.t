use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Builder;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Repository::Local;
use RakuPM::Client;

# 构建阶段（Build.pm / META6 builder）的回归测试。
# 语义对照 zef 的两个构建实现（Zef::Service::Shell::LegacyBuild / DistributionBuilder）：
#   · Build 文件里要有 class Build 的 build 方法，返回真 = 成功，cwd 是发行版根目录；
#   · META6 "builder" 字段指定的类 new(:meta).build(dist-path)，真 = 成功。
# 场景对应真实生态的 native 包：Build 阶段生成 resources/libraries/*.so，
# 之后 %?RESOURCES<libraries/xxx> 必须能读到（Rakudo 约定：声明无扩展名，
# CUR 安装时按平台补 .dll/.so/.dylib）。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-build-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 平台的 native 库文件形状（Rakudo CUR 约定，META6 声明逻辑名 libraries/mydemo）：
# Windows 找 mydemo.dll；Linux 找 libmydemo.so；macOS 找 libmydemo.dylib。
# 【注意】Linux 会无条件加 lib 前缀 —— 声明 libraries/libdemo 会找 liblibdemo.so！
my $lib-file = $*DISTRO.is-win ?? 'mydemo.dll'
              !! ($*DISTRO.name ~~ /mac/ ?? 'libmydemo.dylib' !! 'libmydemo.so');
my $builder = RakuPM::Builder.new;

# ---------- 1. 检测逻辑 ----------
{
    my $src = $tmp.add('plain').mkdir;
    my $d = RakuPM::Distribution.new(:name<Plain>, :version<1.0>, :depends({}));
    nok $builder.needs-build($src, $d), '没有 Build 文件也没有 builder 字段 → 不构建';

    $src.add('Build.pm6').spurt('class Build { method build($d) { True } }');
    is $builder.build-file($src).basename, 'Build.pm6',
       '三种文件名按 rakumod > pm6 > pm 的优先级取第一个存在的';
    ok $builder.needs-build($src, $d), '有 Build 文件 → 需要构建';
}

{
    is $builder.builder-name(
        RakuPM::Distribution.new(:name<X>, :version<1.0>, :builder('MakeFromJSON'))),
       'Distribution::Builder::MakeFromJSON',
       '短名 MakeFromJSON 自动补全名（zef 同款兼容）';
    is $builder.builder-name(
        RakuPM::Distribution.new(:name<X>, :version<1.0>, :builder('My::Builder'))),
       'My::Builder', '全名原样保留';
    is $builder.builder-name(
        RakuPM::Distribution.new(:name<X>, :version<1.0>)),
       '', '没写 builder 字段 → 空串';
}

# ---------- 2. build-depends 归一化 ----------
{
    my $meta = $tmp.add('bd-meta').mkdir;
    sub meta-with-build-depends($bd) {
        $meta.add('META6.json').spurt(to-json({
            name => 'BD', version => '1.0', provides => { BD => 'lib/BD.rakumod' },
            'build-depends' => $bd, depends => {},
        }, :sorted-keys));
        RakuPM::Distribution.from-meta6-file($meta.add('META6.json')).build-depends
    }
    is meta-with-build-depends(['LibraryMake:ver<0.1+>']).keys.join(','), 'LibraryMake',
       'build-depends 数组形式';
    is meta-with-build-depends({ 'LibraryMake' => '0.1+' }).keys.join(','), 'LibraryMake',
       'build-depends 平铺 Hash 形式';
    is meta-with-build-depends({ build => { requires => ['LibraryMake'] } }).keys.join(','),
       'LibraryMake', 'build-depends 分阶段 Hash（取 build 相）';
}

# ---------- 3. Legacy Build.pm：成功 / 返回假 / 抛异常 ----------
sub make-legacy-dist($name, Str $body --> IO::Path) {
    my $src = $tmp.add($name).mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add("$name.rakumod").spurt("unit module $name;");
    $src.add('Build.pm').spurt($body);
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '1.0',
        provides => { $name => "lib/$name.rakumod" }, depends => {},
    }, :sorted-keys));
    $src
}

{
    # Build 生成一个资源文件 —— 模拟 LibraryMake 包编译 C 源出 .so 的样子。
    # 注意 META6 里声明【逻辑名】libraries/mydemo（Rakudo 平台形状约定）。
    my $src = $tmp.add('ok-legacy').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('WithBuild.rakumod').spurt(
        'unit module WithBuild;' ~ "\n" ~
        'sub lib-marker() is export { %?RESOURCES<libraries/mydemo>.slurp }' ~ "\n");
    $src.add('Build.pm').spurt(
        'class Build {' ~ "\n" ~
        '    method build($d) {' ~ "\n" ~
        '        my $libs = $d.IO.add("resources").add("libraries");' ~ "\n" ~
        '        $libs.mkdir unless $libs.e;' ~ "\n" ~
        '        $libs.add("' ~ $lib-file ~ '").spurt("BUILT-LIB-CONTENT");' ~ "\n" ~
        '        True' ~ "\n" ~
        '    }' ~ "\n" ~
        '}' ~ "\n");
    $src.add('META6.json').spurt(to-json({
        name      => 'WithBuild', version => '1.0', auth => 'demo:test',
        provides  => { 'WithBuild' => 'lib/WithBuild.rakumod' },
        resources => ['libraries/mydemo'],
        depends   => {},
    }, :sorted-keys));
    my $d = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));

    ok $builder.needs-build($src, $d), 'WithBuild：检测到 Build.pm';
    ok $builder.run($d, $src), 'Legacy Build.pm 执行成功';
    ok $src.add('resources').add('libraries').add($lib-file).e,
       'Build 生成的文件落在源码目录的 resources/ 下';
}

{
    my $src = make-legacy-dist('FailFalse', 'class Build { method build($d) { False } }');
    my $d = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    # :quiet：预期失败的用例别把 die 堆栈喷出来 —— zef install . 跑套件时
    # 这些输出会原样出现在用户面前，看着像出了大事，其实测试是过的
    nok $builder.run($d, $src, :quiet), 'build 返回 False → 构建（子进程 exit 1）失败';
}

{
    my $src = make-legacy-dist('FailDie', 'class Build { method build($d) { die "boom" } }');
    my $d = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    nok $builder.run($d, $src, :quiet), 'build 抛异常 → 构建失败';
}

# ---------- 4. META6 builder 字段 ----------
{
    my $src = $tmp.add('with-builder').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('RakuPM').mkdir;
    $src.add('lib').add('RakuPM').add('Test').mkdir;
    $src.add('lib').add('RakuPM').add('Test').add('DistBuilder.rakumod').spurt(
        'unit class RakuPM::Test::DistBuilder;' ~ "\n" ~
        'method build($path) { "$path/built-marker.txt".IO.spurt("BUILDER-RAN"); True }' ~ "\n");
    $src.add('META6.json').spurt(to-json({
        name     => 'WithBuilder', version => '1.0', auth => 'demo:test',
        builder  => 'RakuPM::Test::DistBuilder',
        provides => { 'WithBuilder' => 'lib/WithBuilder.rakumod' },
        depends  => {},
    }, :sorted-keys));
    my $d = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));

    is $d.builder, 'RakuPM::Test::DistBuilder', 'builder 字段解析进发行版对象';
    ok $builder.needs-build($src, $d), '只有 builder 字段（无 Build 文件）也要构建';
    ok $builder.run($d, $src, :quiet), 'builder 类执行成功';
    is $src.add('built-marker.txt').slurp, 'BUILDER-RAN',
       'builder 类真的被调用并写出了构建产物';
}

# ---------- 5. 端到端：构建产物经 store 装进 site，%?RESOURCES 可读 ----------
{
    my $src = $tmp.add('ok-legacy');
    my $d   = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    my $store = RakuPM::Store.new(:root($tmp.add('store')));
    my $inst  = RakuPM::Installer.new(:target($tmp.add('target')), :store($store));

    # Builder.run → Store.put → Installer.install，与 Client 的阶段顺序一致
    ok $builder.run($d, $src, :quiet), 'e2e 前再构建一次（静默）';
    $store.put($d, $src);

    my %m6 = from-json($store.path-for('WithBuild', '1.0').add('META6.json').slurp);
    ok %m6<resources>.first(* eq 'libraries/mydemo'),
       'store 的 META6 保留了无扩展名的 libraries/mydemo 声明（平台形状约定）';
    ok $store.path-for('WithBuild', '1.0').add('resources').add('libraries')
             .add($lib-file).e,
       'Build 产物被复制进 store';

    $inst.install($d);
    my $proc = run('raku', '-I', $inst.raku-lib-spec, '-e',
                   'use WithBuild; print lib-marker()', :out, :err);
    is $proc.exitcode, 0, '装完后加载 WithBuild 成功'
        or note $proc.err.slurp(:close);
    is $proc.out.slurp(:close).trim, 'BUILT-LIB-CONTENT',
       '装完后 %?RESOURCES<libraries/mydemo> 读到的是【构建产物】的内容';
}

# ---------- 6. Client 级：build-depends 先装，构建时可用 ----------
{
    # 本地仓库里放一个构建依赖包
    my $repo-dir = $tmp.add('repo').mkdir;
    my $helper-src = $repo-dir.add('BuildHelper').mkdir;
    $helper-src.add('lib').mkdir;
    $helper-src.add('lib').add('BuildHelper.rakumod').spurt(
        'unit module BuildHelper;' ~ "\n" ~
        'sub helper-note() is export { "HELPER-WAS-HERE" }' ~ "\n");
    $helper-src.add('META6.json').spurt(to-json({
        name => 'BuildHelper', version => '0.1', auth => 'demo:test',
        provides => { 'BuildHelper' => 'lib/BuildHelper.rakumod' }, depends => {},
    }, :sorted-keys));

    # 目标包：构建时 use BuildHelper（构建开始前必须已装好）
    my $app-src = $tmp.add('app').mkdir;
    $app-src.add('lib').mkdir;
    $app-src.add('lib').add('BuildApp.rakumod').spurt(
        'unit module BuildApp;' ~ "\n" ~
        'sub marker() is export { %?RESOURCES<built.txt>.slurp }' ~ "\n");
    $app-src.add('Build.pm').spurt(
        'use BuildHelper;' ~ "\n" ~
        'class Build {' ~ "\n" ~
        '    method build($d) {' ~ "\n" ~
        '        my $res = $d.IO.add("resources");' ~ "\n" ~
        '        $res.mkdir unless $res.e;' ~ "\n" ~
        '        $res.add("built.txt").spurt(helper-note() ~ "-BY-BUILD");' ~ "\n" ~
        '        True' ~ "\n" ~
        '    }' ~ "\n" ~
        '}' ~ "\n");
    $app-src.add('META6.json').spurt(to-json({
        name => 'BuildApp', version => '1.0', auth => 'demo:test',
        provides => { 'BuildApp' => 'lib/BuildApp.rakumod' },
        'build-depends' => ['BuildHelper'],
        resources => ['built.txt'],
        depends => {},
    }, :sorted-keys));

    my $client = RakuPM::Client.new(
        :target($tmp.add('client-target')),
        :repos([RakuPM::Repository::Local.new(:root($repo-dir))]),
    );
    $client.install-from-dir($app-src, :no-test);

    is $client.installer.installed-versions('BuildHelper').join(','), '0.1',
       'build-depends 被先安装进 site';
    ok $client.installer.installed-versions('BuildApp').elems,
       '目标包 BuildApp 安装成功';

    my $stored = $client.store.path-for('BuildApp', '1.0');
    is $stored.add('resources').add('built.txt').slurp, 'HELPER-WAS-HERE-BY-BUILD',
       '构建产物（借助 build-depends 生成）被复制进 store';

    my $proc = run('raku', '-I', $client.installer.raku-lib-spec, '-e',
                   'use BuildApp; print marker()', :out, :err);
    is $proc.exitcode, 0, '装完后加载 BuildApp 成功'
        or note $proc.err.slurp(:close);
    is $proc.out.slurp(:close).trim, 'HELPER-WAS-HERE-BY-BUILD',
       '装完后 %?RESOURCES<built.txt> 读到构建时写入的内容';
}

# ---------- 7. Linux 形状回归：lib 前缀文件也要被识别 ----------
# WSL 实测：CUR 在 Linux 找的是 lib<逻辑名>.so（lib 前缀无条件加），
# Build 生成的就是这种文件；Store 的存在性检查漏了它就会丢声明、
# 装完 %?RESOURCES 键 miss。Windows 上测不出这个 bug —— 这里手工
# 构造 Linux 磁盘形态，任何平台都能回归它。
{
    my $src = $tmp.add('linux-shape').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('LS.rakumod').spurt('unit module LS;');
    $src.add('resources').mkdir;
    $src.add('resources').add('libraries').mkdir;
    $src.add('resources').add('libraries').add('libmydemo.so').spurt('LS-PAYLOAD');
    $src.add('META6.json').spurt(to-json({
        name      => 'LS', version => '1.0', auth => 'demo',
        provides  => { LS => 'lib/LS.rakumod' },
        resources => ['libraries/mydemo'],
        depends   => {},
    }, :sorted-keys));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    my $store = RakuPM::Store.new(:root($tmp.add('ls-store')));
    $store.put($dist, $src);
    nok $store.needs-readmit('LS', '1.0', :$dist),
       'Linux 形状（lib<名>.so）的资源声明不被误判为过时';
    my %m = from-json($store.path-for('LS', '1.0').add('META6.json').slurp);
    ok %m<resources>.first(* eq 'libraries/mydemo'),
       'store META6 保留 libraries/mydemo 声明（磁盘上是 libmydemo.so）';
}

done-testing;
