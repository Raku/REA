use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use JSON::Fast;
use RakuPM::Distribution;
use RakuPM::Repository::Local;

plan 14;

my $tmp = "./_t-meta6-{$*PID}";
END { for $tmp.IO.dir -> $e { $e.d ?? rm-tree($e) !! $e.unlink }; $tmp.IO.rmdir if $tmp.IO.d }
sub rm-tree(IO::Path $d) { for $d.dir -> $e { $e.d ?? rm-tree($e) !! $e.unlink }; $d.rmdir }

mkdir $tmp;

# ===== META6 解析：provides 是 Hash，depends 是 runtime.requires =====
my $meta6-path = "$tmp/File-Temp/META6.json".IO;
mkdir "$tmp/File-Temp".IO;
$meta6-path.spurt(to-json({
    name        => 'File::Temp',
    version     => '0.0.12',
    auth        => 'zef:raku-community-modules',
    description => 'Create temporary files & directories',
    provides    => { 'File::Temp' => 'lib/File/Temp.rakumod' },
    depends     => {
        runtime => { requires => [
            'File::Directory::Tree:ver<0.2+>:auth<zef:raku-community-modules>',
            'IO::Path',
        ] },
        test => { requires => ['Test'] },
    },
}, :sorted-keys));

my $dist = RakuPM::Distribution.from-meta6-file($meta6-path);
is $dist.name, 'File::Temp', 'name';
is $dist.version, '0.0.12', 'version';
is $dist.auth, 'zef:raku-community-modules', 'auth';
is $dist.provides.elems, 1, 'provides 平铺为模块名列表';
ok $dist.provides-module('File::Temp'), 'provides-module 命中';
is $dist.depends.keys.sort.join(','),
   'File::Directory::Tree,IO::Path',
   'depends 平铺为 name => constraint';
is $dist.depends<File::Directory::Tree>, '0.2+',
   'ver<> 内约束被正确提取';
is $dist.depends<IO::Path>, '*', '无约束默认为 *';

# ===== Local repo 同时识别 META6.json =====
my $file-temp-dir = $meta6-path.parent;
$file-temp-dir.add('lib/File').mkdir;
$file-temp-dir.add('lib/File/Temp.rakumod').spurt("unit module File::Temp;\n");

my $repo = RakuPM::Repository::Local.new(:root($tmp.IO));
my @names = $repo.all-distributions;
is @names.elems, 1, 'Local repo 识别 META6.json';
is @names[0], 'File::Temp', '发行版名字取自 META6';

# ===== 0.37.0 起：不再回退 META.json，旧版 META.json 不再被当发行版识别 =====
mkdir "$tmp/JSON-legacy";
"$tmp/JSON-legacy/META.json".IO.spurt(to-json({
    name    => 'JSON',
    version => '1.0.0',
    auth    => 'demo:raku',
    provides => ['JSON'],
    depends => {},
}, :sorted-keys));

$repo = RakuPM::Repository::Local.new(:root($tmp.IO));
my @names2 = $repo.all-distributions.sort;
is @names2.join(','), 'File::Temp',
   '0.37.0 起 META.json 不再被当发行版识别（只有 META6.json 算数）';

# ===== auth 写成数组的老包：不能崩，要归一成字符串 =====
# 用户实测（装 KittyTorrents::Archive 0.1.1）：它的 META6.json 里
#   "auth": ["zef:skyter10086"]     ← 照抄 authors 的格式写成了数组
# 而 $.auth 声明是 Str，直接塞进去会在构造时炸：
#   Type check failed in assignment to $!auth; expected Str but got Array
# 一个字段的写法偏差不该让整个包解析不出来 —— 就像 provides/resources 那样归一。
mkdir "$tmp/AuthArray".IO;
"$tmp/AuthArray/META6.json".IO.spurt(to-json({
    name     => 'AuthArray',
    version  => '0.1.1',
    auth     => ['zef:skyter10086'],
    authors  => ['zef:skyter10086'],
    provides => { 'AuthArray' => 'lib/AuthArray.rakumod' },
    depends  => ['URI:ver<0.3.8>', 'HTTP::Tinyish'],
}, :sorted-keys));

my $aa = RakuPM::Distribution.from-meta-file("$tmp/AuthArray/META6.json".IO);
is $aa.auth, 'zef:skyter10086', 'auth 写成数组时归一成字符串（不再类型检查失败）';
is $aa.identity, 'AuthArray:ver<0.1.1>:auth<zef:skyter10086>',
   '数组形态的 auth 正常参与 identity 拼接';
# 同一份 META6 里 depends 也是数组形态，顺带钉住它的解析（含 :ver<> 约束）
is-deeply $aa.depends, %( 'URI' => '0.3.8', 'HTTP::Tinyish' => '*' ),
   'depends 写成数组（含 URI:ver<0.3.8> 约束）也能解析出每个依赖';