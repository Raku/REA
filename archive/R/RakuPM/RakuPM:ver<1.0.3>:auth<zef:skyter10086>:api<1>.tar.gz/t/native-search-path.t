use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::NativeLib;

# Windows 的 DLL 搜索顺序第一条是【可执行文件所在目录】= rakudo 的 bin 目录。
# zef / 各发行版常把配套 DLL 直接放在 <rakudo>/bin 下（本机实测就有
# moar.dll / readline.dll / libwinpthread-1.dll …），NativeCall 加载得到，
# 但 raku-pm 的检查原先只看 PATH + 系统目录 + vcpkg，于是会把一个
# 【明明可用】的库报成「未找到」。

my $nl = RakuPM::NativeLib.new;

# ---------- 通用：搜索路径本身要干净 ----------
my @p = $nl.search-paths;
ok @p.elems, '搜索路径非空';
is @p.elems, @p.unique.elems, '搜索路径没有重复项';
ok @p.grep({ .subst('\\', '/', :g).ends-with('/') }).elems == 0,
   '搜索路径没有以分隔符结尾的（避免拼出双斜杠）';

# ---------- Windows：必须包含 rakudo 的 bin 目录 ----------
if $*DISTRO.is-win {
    my $bin = $*EXECUTABLE.absolute.IO.parent;
    ok @p.first({ .IO.absolute eq $bin.absolute }),
       "Windows 搜索路径包含 rakudo 的 bin 目录（{$bin.absolute}）";

    # 端到端：moar.dll 就在 rakudo/bin 下，应当被探测到
    my @r = $nl.check(['moar']);
    is @r.elems, 1, 'check 返回 1 条结果';
    ok @r[0]<found>,
       'rakudo/bin 下的 moar.dll 能被探测到（修复前会被报成「未找到」）';
    ok (@r[0]<path> // '').contains('moar'),
       "探测到的路径指向 moar（{@r[0]<path>}）";
}
else {
    skip '非 Windows：rakudo/bin 的 DLL 搜索属 Windows 特有行为', 2;
}

done-testing;
