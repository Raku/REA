# 回归测试：本地仓库（Local）要容忍根目录/子目录里「解析不了的 META 文件」，
# 而不是整个 install 崩掉。
#
# 真实现场（WSL/Linux）：用户在某目录跑 `raku-pm install X`，该目录（或某个
# 子目录）里有个把整个生态索引（一个 JSON 数组）误存成的 META.json。旧代码
# 直接 my %meta = from-json($path.slurp)，数组被当 hash initializer → 刷屏
# 15000+ 条 "Use of uninitialized value" + 最终 "Odd number of elements"。
# 修复后：from-meta-file 对非对象 JSON 抛清晰报错，Local.!index 的 try 兜住后
# 跳过该文件，正常包照常索引。

use lib 'lib';
use Test;
use RakuPM::Repository::Local;

plan 4;

# 递归清理（IO::Path 没有内置 rmtree），LEAVE 保证测试后不留垃圾。
sub rmtree(IO::Path $p) {
    if $p.d {
        for $p.dir -> $c { rmtree($c) }
        try $p.rmdir;
    }
    else {
        try $p.unlink;
    }
}

my $tmp = $*TMPDIR.add('rakupm-local-badmeta-' ~ $*PID);
$tmp.mkdir;
LEAVE rmtree($tmp);

# 根目录放一个坏的 META.json：内容是整个生态索引（JSON 数组），正是崩溃现场。
$tmp.add('META.json').spurt(q:to/ROOTBAD/);
[{"name":"Fake::FromIndex","version":"1.0","provides":["Fake::FromIndex"]}]
ROOTBAD

# 子目录也放一个坏的 META.json（覆盖子目录扫描分支）。
my $badsub = $tmp.add('bad-sub');
$badsub.mkdir;
$badsub.add('META.json').spurt(q:to/SUBBAD/);
[{"name":"Bad::Sub","version":"0.1","provides":["Bad::Sub"]}]
SUBBAD

# 一个正常的包目录：标准 META6.json。
my $good = $tmp.add('good');
$good.mkdir;
$good.add('META6.json').spurt(q:to/GOOD/);
{"name":"Good::Pkg","version":"1.0.0","provides":["Good::Pkg"]}
GOOD

my $repo = RakuPM::Repository::Local.new(:root($tmp.IO), :name('local'));

# 1) 索引不能崩：正常包要能索引到。
my @dists = $repo.all-distributions;
ok @dists.grep(* eq 'Good::Pkg'), '坏 META 文件被跳过，正常包 Good::Pkg 仍被索引';

# 2) 坏文件（根 + 子目录）没有被当成发行版收录。
ok @dists.grep(* eq 'Fake::FromIndex').elems == 0, '根目录坏 META 数组未被当成发行版';
ok @dists.grep(* eq 'Bad::Sub').elems == 0, '子目录坏 META 数组未被当成发行版';

# 3) find-providers 能找到正常包提供的模块。
my @p = $repo.find-providers('Good::Pkg');
ok @p.grep(* eq 'Good::Pkg'), 'find-providers(Good::Pkg) 命中 Good::Pkg';

# vim: set filetype=raku:
