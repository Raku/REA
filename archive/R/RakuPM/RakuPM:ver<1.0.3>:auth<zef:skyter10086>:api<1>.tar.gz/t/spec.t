use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Spec;
use RakuPM::Distribution;

# RakuPM::Spec：zef 风格规格串的解析（从 Distribution.parse-spec 抽出）。
# 这套写法 install / search / installed / store / version / fetch 都认，
# 所以解析器本身的形态与约束合法性在这里钉死。

# ---------- parse：各形态 ----------
# (输入, 期望 module, ver, auth, api, 说明)
my @cases = (
    ('Foo::Bar',                          'Foo::Bar',   '',       '',     '',  '不带版本'),
    ('JSON::Fast:ver<1.2.3>',             'JSON::Fast', '1.2.3',  '',     '',  ':ver 精确'),
    ('JSON::Fast:ver<1.2.3+>',            'JSON::Fast', '1.2.3+', '',     '',  ':ver at-least（zef 的 +）'),
    ('Foo:ver<1.2.3>:auth<zef:x>',        'Foo',        '1.2.3',  'zef:x','',   'ver + auth'),
    ('Foo:ver<1.2.3>:auth<zef:x>:api<1>', 'Foo',        '1.2.3',  'zef:x','1', 'ver + auth + api'),
    ('Foo@1.2.3',                         'Foo',        '1.2.3',  '',     '',  '@ 简写'),
    ('Foo::Bar@1.0',                      'Foo::Bar',   '1.0',    '',     '',  '@ 简写 + 模块名带 ::'),
    ('Foo@1.0+',                          'Foo',        '1.0+',   '',     '',  '@ 简写 + at-least'),
    ('Foo@1.2.3#zef:x',                   'Foo',        '1.2.3',  'zef:x','',   '@ver + #auth（Windows cmd 安全写法）'),
    ('Foo::Bar@1.2.3#cpan:JNTHN',         'Foo::Bar',   '1.2.3',  'cpan:JNTHN','','@ver#auth + 模块名带 :: + 复合 author'),
    ('Foo@1.0+#zef:x',                    'Foo',        '1.0+',   'zef:x','',   '@ver#auth + at-least 组合'),
    ('Foo:api<2>',                        'Foo',        '',       '',     '2', '只给 api'),
    ('Foo:ver<>',                         'Foo',        '',       '',     '',  ':ver 空值 = 不指定版本'),
    # 回归：`>=` / `>` 运算符自带一个 `>` 且紧跟开括号。裸 index('>') 会把它当闭合，
    # 值被截成空串 —— 约束静默退化成「任意版本」，`>=` / `>` 完全失效。
    ('Foo:ver<>=1.0>',                    'Foo',        '>=1.0',  '',     '',  ':ver >= 运算符不被截断'),
    ('Foo:ver<>1.0>',                     'Foo',        '>1.0',   '',     '',  ':ver > 运算符不被截断'),
    # 注意：串尾那个 `>` 是 phaser 的闭合括号，值本身是 `>=1.0, <2.0`
    # （右界的 `<` 是运算符、不配对自己的 `>` —— 与 Version 的区间写法一致）。
    ('Foo:ver<>=1.0, <2.0>',              'Foo',        '>=1.0, <2.0', '',  '',  '区间左界用 >= 也正确'),
    ('  JSON::Fast:ver<1.0+>  ',          'JSON::Fast', '1.0+',   '',     '',  '首尾空白被 trim'),
);
for @cases -> ($spec, $mod, $ver, $auth, $api, $why) {
    my %s = RakuPM::Spec.parse($spec);
    is %s<module>, $mod,  "parse($spec)：module = $mod（$why）";
    is %s<ver>,    $ver,  "parse($spec)：ver = '$ver'";
    is %s<auth>,   $auth, "parse($spec)：auth = '$auth'";
    is %s<api>,    $api,  "parse($spec)：api = '$api'";
}

# 模块名里的 :: 不会被误当 phaser 起点（这是当初弃用正则回溯的原因）
{
    my %s = RakuPM::Spec.parse('Foo::Bar:Baz<qux>');
    is %s<module>, 'Foo::Bar', 'parse：:: 后跟非 alnum 不吃掉模块名';
}
# 未知 phaser：不进结果、不吞模块名
{
    my %s = RakuPM::Spec.parse('Foo:stage<build>:ver<1.0>');
    is %s<module>, 'Foo', 'parse：未知 phaser 不吞模块名';
    nok %s<stage>:exists, 'parse：未知 phaser 不进结果';
    is %s<ver>, '1.0', 'parse：未知 phaser 之后的 :ver 照常解析';
}

# 回归（0.37.5）：ver 值里带 `>` 时，闭合括号定位不能串到下个 phaser。
# 多 phaser 串里每个 phaser 的闭合括号要各自定位 —— 这也是不能用 rindex 的原因。
{
    my %s = RakuPM::Spec.parse('Foo:ver<>=0.1.0>:auth<zef:x>');
    is %s<ver>,  '>=0.1.0', 'parse：ver<>=0.1.0> 的闭合括号不与 :auth 串味';
    is %s<auth>, 'zef:x',   'parse：ver 含 > 时后续 phaser 仍照常解析';
    is %s<module>, 'Foo',   'parse：ver 含 > 时模块名仍正确';
}
# close-bracket-index：找不到闭合返回未定义（畸形串由调用方收尾）
{
    nok RakuPM::Spec.close-bracket-index('Foo:ver<1.0', 7).defined,
        'close-bracket-index：缺闭合括号返回未定义';
    is RakuPM::Spec.close-bracket-index('Foo:ver<>', 7), 8,
        'close-bracket-index：空值仍定位到正确的 >';
}

# ---------- constraint-valid：合法约束 ----------
# 注意别用 <...> 词引用装 '>1.0' 这类带 > 的串 —— 第一个 > 会提前闭合引构
for '1.0', '1.2.3', '0.13.0', '>=1.0', '>1.0', '<=2.0', '<2.0',
    '>=1.0, <2.0', '1.0+', 'v1.2', '= 1.2.3', '*' -> $c {
    ok RakuPM::Spec.constraint-valid($c), "constraint-valid('$c')：合法";
}
# ---------- constraint-valid：非法约束 ----------
# 「bar」这类纯单词尤其重要：satisfies 的 from-string 对坏片段退化成 0、
# '=' 分支永不 die，光靠 try 探针拦不住它 —— 拦不住的话 search foo@bar
# 会把所有版本筛没。所以形状校验必须先拒绝。
for '', 'bar', '1.0.x', '>=abc', 'foo bar', '>=' -> $c {
    nok RakuPM::Spec.constraint-valid($c), "constraint-valid('$c')：非法";
}

# ---------- Distribution.parse-spec 委托等价 ----------
# 抽取后 Distribution 保留同签名方法做委托：老调用方（含 bin 的 require 用法）
# 不能受影响。钉死两者对同一批输入返回完全一致的结果。
{
    my $d = RakuPM::Distribution.new(
        :name('Demo'), :version('1.0.0'), :provides(['Demo']), :depends({}));
    for ('Foo::Bar', 'JSON::Fast:ver<1.2.3>', 'Foo@1.0',
         'Foo:ver<1.0+>:auth<zef:x>:api<1>') -> $spec {
        is-deeply $d.parse-spec($spec), RakuPM::Spec.parse($spec),
            "Distribution.parse-spec('$spec') 与 Spec.parse 委托等价";
    }
}

done-testing;
