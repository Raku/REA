use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Repositories;

# 默认索引覆盖回归测试（0.36.8）。
#
# 背景：用户 `zef install raku-pm` 后装 `Terminal::Spinners` 报
# 「在所有已配置的仓库里都找不到模块」。根因不是解析代码坏掉，而是
# 默认只挂了 zef 一个索引，而该模块只在 cpan / REA 里有。这次把默认
# 索引扩成 zef + cpan + rea，本地目录仍挂 local。
#
# 本测试只验证「无 repositories.json 时默认 entries 的名字集合」，不触网，
# 也不依赖本地缓存索引内容——保证 `zef install` 一次就能拿到完整候选来源。

plan 3;

my $tmp = $*TMPDIR.add("rakupm-repdef-{+$*PID}");
$tmp.mkdir;
END { try $tmp.rmdir }

# 不存在的 config 文件 → 走默认分支
my $repos = RakuPM::Repositories.new(
    :config-file($tmp.add('repositories.json')),
    :cache-root($tmp), :repo-root($tmp.Str));
$repos.load;

my @names = $repos.entries.map(*<name>);
is @names.join(', '), 'zef, cpan, rea, local',
    '默认索引为 zef + cpan + rea + 本地';

# 顺序也要稳定：zef 在前（主索引），local 在最后
is @names[0], 'zef', 'zef 是第一个默认索引';
is @names[*-1], 'local', 'local 在默认列表末尾';
