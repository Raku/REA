use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Repository::Ecosystem;

# %?RESOURCES 端到端验证：resources/ 目录要被 store 复制、写进 META6.json、
# 由 CUR::Installation 装到 site/ 下 —— 最后用户代码里 %?RESOURCES 才取得到。
# 历史 bug：只复制 lib/ 不复制 resources/，测试阶段（在源码目录跑）看不出来，
# 装完才炸，属于最阴的一类。
#
# 【注意】资源名别放 resources/libraries/ 下做无扩展名文件：
# Rakudo 会把该目录视为 native 库目录，安装时给叶子名自动追加平台扩展
# （libres.bin → 找 libres.bin.dll）。这是 Rakudo CUR 自己的约定，zef 装
# 同款包行为一致，不属于 raku-pm 的 bug —— 这里用普通嵌套目录验证复制链路。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

# 在目录里递归找一个内容等于 $content 的文件（证明资源物理落到了安装前缀）。
# 「未找到」必须返回【确定的实例】而不是 IO::Path 类型对象 —— 类型对象调 .e
# 直接抛「Invocant must be an object instance」（WSL 上递归未命中时就炸过）。
my $NOT-FOUND = IO::Path.new('___rakupm-not-found___');
sub find-file-with(IO::Path $dir, Str $content --> IO::Path) {
    return $NOT-FOUND unless $dir.d;
    for $dir.dir -> $p {
        return $p if $p.f && ($p.slurp // '') eq $content;
        my $hit = find-file-with($p, $content);
        return $hit if $hit.e;
    }
    $NOT-FOUND
}

my $tmp = $*TMPDIR.add('rakupm-res-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# ---------- 造一个带 resources/ 的包 ----------
my $src = $tmp.add('src');
$src.mkdir;
$src.add('lib').mkdir;
$src.add('resources').mkdir;
$src.add('resources').add('native').mkdir;

# 模块导出资源【对象】的读取函数。注意 Distribution::Resource 没有 .e / .f 这类
# 存在性方法（它不是完整 IO::Path），物理存在性由 site/resources/ 扫描断言，
# 这里直接测 .slurp 内容。
$src.add('lib').add('ResDemo.rakumod').spurt(
    'unit module ResDemo;' ~ "\n" ~
    'sub txt-content()    is export { %?RESOURCES<data.txt>.slurp }' ~ "\n" ~
    'sub nested-content() is export { %?RESOURCES<native/libres.bin>.slurp }' ~ "\n");

my $txt = 'hello-resources';
my $bin = 'BINARY-PAYLOAD';
$src.add('resources').add('data.txt').spurt($txt);
$src.add('resources').add('native').add('libres.bin').spurt($bin);

$src.add('META6.json').spurt(to-json({
    name      => 'ResDemo',
    version   => '1.0',
    auth      => 'demo:test',
    provides  => { 'ResDemo' => 'lib/ResDemo.rakumod' },
    resources => ['data.txt', 'native/libres.bin'],
    depends   => {},
}, :sorted-keys));
my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));

is $dist.resources.sort.join(','), 'data.txt,native/libres.bin',
   '解析出的资源清单与 META6.json 一致';

my $target = $tmp.add('target');
my $store  = RakuPM::Store.new(:root($tmp.add('store')));
my $inst   = RakuPM::Installer.new(:target($target), :store($store));

# ---------- 1. store 入库：resources/ 要真的被复制 ----------
$store.put($dist, $src);
my $stored = $store.path-for('ResDemo', '1.0');
ok $stored.add('resources').add('data.txt').e,       'store 复制了 resources/data.txt';
ok $stored.add('resources').add('native').add('libres.bin').e,
   'store 复制了嵌套的 resources/native/libres.bin';
is $stored.add('resources').add('data.txt').slurp, $txt,
   '复制的资源内容正确';
ok $store.verify('ResDemo', '1.0'),
   '指纹覆盖 resources/ 后校验仍通过';

my %m6 = from-json($stored.add('META6.json').slurp);
is %m6<resources>.sort.join(','), 'data.txt,native/libres.bin',
   'store 的 META6.json 声明了 resources';
nok %m6<resources>.first(*.contains('\\')),
   '资源路径是正斜杠（反斜杠会让 CUR::Installation 拼错）';

# ---------- 2. 安装：site/ 下要有资源的实体 ----------
$inst.install($dist);
is $inst.installed-versions('ResDemo').join(','), '1.0', '安装记录正常';

ok find-file-with($inst.repo-prefix.add('resources'), $txt).e,
   '资源内容真实落在 site/resources/ 下（物理文件存在）';

# ---------- 3. 用户侧：装完后 %?RESOURCES 真的能用 ----------
# 用子进程模拟用户写代码 —— 模块自己用 %?RESOURCES 读资源
sub resource-report(--> Str) {
    my $proc = run('raku', '-I', $inst.raku-lib-spec, '-e',
                   'use ResDemo; print txt-content() ~ "|" ~ nested-content()',
                   :out, :err);
    return '' if $proc.exitcode != 0;
    $proc.out.slurp(:close).trim
}

my $report = resource-report;
is $report, $txt ~ '|' ~ $bin,
   '装完后 %?RESOURCES 能读到 data.txt 与嵌套的 libres.bin 的内容';

# ---------- 4. 卸载后资源随之消失 ----------
$inst.uninstall('ResDemo');
is $inst.list-installed.elems, 0, '卸载后账本为空';
{
    my $proc = run('raku', '-I', $inst.raku-lib-spec, '-e',
                   'use ResDemo; print txt().e.so', :out, :err);
    nok $proc.exitcode == 0, '卸载后 use ResDemo 失败';
}

# ---------- 5. 回归：索引条目的 resources 不能丢 ----------
# 用户实测（Windows）：zef 装 Data::Generators 0.1.11 正常，raku-pm 装却在
# 激活阶段崩 `'...site\resources' is a directory, cannot do '.open'`。
# 根因：**从索引条目构造 Distribution 时漏传了 resources**。
# 索引里明明写着 resources=["dfEnglishWords.csv","dfPetNameCounts.csv"]，
# 但 Distribution 上这一位是空的 → store 的 META6.json 里 resources 是空清单 →
# 资源文件复制过去了，CUR::Installation 却不知道这个包带了资源 →
# %?RESOURCES<key> 取不到 → 回退成 resources 目录 → 模块 .open 目录即崩。
# 两条测试分别钉住「索引→Distribution」和「源码兜底」两个环节，
# 在修复前都会红。
{
    # A. 索引条目 → Distribution：resources 必须被带上
    my $idx = $tmp.add('eco-src').mkdir.add('index.json');
    $idx.spurt(to-json([
        %( name => 'ResEco', version => '1.0', auth => 'demo:eco',
           provides  => { 'ResEco' => 'lib/ResEco.rakumod' },
           resources => ['words.csv', 'pets.csv'],
           depends   => {} ),
    ], :sorted-keys));
    my $url = $idx.absolute;   # 本地索引：直接传 IO::Path 绝对路径，不走网络层
    my $eco = RakuPM::Repository::Ecosystem.new(
        :name('eco-res'), :index-url($url),
        :cache-root($tmp.add('eco-cache').mkdir));
    $eco.refresh;
    is $eco.fetch-distribution('ResEco', '1.0').resources.sort.join(','),
       'pets.csv,words.csv',
       '索引条目里的 resources 传进了 Distribution（丢了会导致激活阶段 %?RESOURCES 崩）';

    # B. Store 兜底：即使 Distribution 上 resources 是空的（索引漏字段），
    #    入库也要从源码目录的 META6.json 补回来 —— 索引质量参差，源码才是权威
    my $b-src = $tmp.add('bare-src').mkdir;
    $b-src.add('lib').mkdir.add('BareRes.rakumod').spurt('unit module BareRes;');
    $b-src.add('resources').mkdir.add('words.csv').spurt('a,b,c');
    $b-src.add('META6.json').spurt(to-json({
        name      => 'BareRes',
        version   => '1.0',
        auth      => 'demo:bare',
        provides  => { 'BareRes' => 'lib/BareRes.rakumod' },
        resources => ['words.csv'],
        depends   => {},
    }, :sorted-keys));

    # 故意不传 resources（Distribution 默认空）—— 模拟索引漏字段的旧行为
    my $bare = RakuPM::Distribution.new(
        :name('BareRes'), :version('1.0'), :auth('demo:bare'),
        :provides(['BareRes']), :depends({}), :native-libs(()));
    is $bare.resources.elems, 0,
       '构造出的 Distribution 上 resources 为空（模拟索引漏字段）';

    my $b-store = RakuPM::Store.new(:root($tmp.add('bare-store')));
    $b-store.put($bare, $b-src);
    my %b-m6 = from-json($b-store.path-for('BareRes', '1.0').add('META6.json').slurp);
    is %b-m6<resources>.sort.join(','), 'words.csv',
       'Distribution 上 resources 为空时，入库仍从源码 META6.json 补回资源声明';
}

done-testing;
