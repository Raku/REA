use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Client;
use RakuPM::Installer;
use RakuPM::Fs;

# 回归：具名实参「名字写错」导致参数被静默丢弃（本机 Rakudo 对 method 不报错）。
#
# ============================================================
# 背景：本机 Rakudo（v2026.08）实测行为差异
# ============================================================
#   sub  s(:$x = 1)        ; s(:zzz(9))  → 报 Unexpected named argument 'zzz'
#   method m(:$x = 1)      ; $o.m(:zzz(9)) → 【静默忽略】，$x 取默认值，无任何提示
# 私有方法、role 方法同样静默。也就是说：**方法调用点上的具名实参名字拼错，
# 编译器、运行时都不会告诉你，参数会凭空失效**。本项目「开关传了但不起作用」
# 那一类缺陷正好落在盲区里。
#
# ============================================================
# 本文件钉死一处【已经真实发生过】的接线错误
# ============================================================
# 「形参名与实际写法不一致」，实测确认会被静默丢弃，故各自需要一个守卫：
#   · ① 卸载按版本：写错会让 `--version` 约束消失 → 用户以为只卸一个版本，
#        实际整包连根拔起（数据丢失级）。
#
# （原先还有 ② self-upgrade 的 source 接线；自 0.83.0 起该形参已随
#  「当前在 git 仓库里就就地 pull 当前仓库」那条路径一并删除，② 不再适用。）
#
# 【为什么既有测试没抓到 ①】t/multi-version.t 用的是 `$inst.uninstall(:version(...))`
# ——它在【Installer 层】直接调，绕过了出问题的那一层（Reporter 转发）。
# 所以这里刻意从【Client 公开 API】走一遍。

my IO::Path $tmp = $*TMPDIR.add("rakupm-wiring-{$*PID}");
LEAVE rm-tree($tmp) if $tmp.e;

my $target = $tmp.add('t');
my $client = RakuPM::Client.new(:target($target));

sub mk-src(Str $ver --> IO::Path) {
    my $d = $tmp.add("src-{$ver}").mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add('Wire.rakumod').spurt(
        'unit module Wire:ver<' ~ $ver ~ ">;\n");
    # 注意用 %( ) 而不是 ( )：Raku 里圆括号是【列表】构造，
    # 写 ( name => .., version => .. ) 会得到一个 Pair 列表，
    # to-json 出来是 JSON 数组 → from-meta-file 报「顶层应为 JSON 对象」。
    $d.add('META6.json').spurt(to-json(%(
        name     => 'Wire',
        version  => $ver,
        auth     => 'demo:test',
        provides => { 'Wire' => 'lib/Wire.rakumod' },
        depends  => {},
    ), :sorted-keys));
    $d
}

my $s11 = mk-src('1.1.0');
my $s20 = mk-src('2.0.0');
my $d11 = RakuPM::Distribution.from-meta6-file($s11.add('META6.json'));
my $d20 = RakuPM::Distribution.from-meta6-file($s20.add('META6.json'));

# ---------- ① 走 Client 公开 API 的「按版本卸载」 ----------
$client.store.put($d11, $s11);
$client.store.put($d20, $s20);
$client.installer.install($d11);
$client.installer.install($d20);

is $client.installer.installed-versions('Wire').sort.join(','), '1.1.0,2.0.0',
   '前提：两个版本都已装';

$client.uninstall('Wire', version => '2.0.0');

is $client.installer.installed-versions('Wire').join(','), '1.1.0',
   '按版本卸载：只清掉 2.0.0，1.1.0 保留'
   ~ '（修复前 `:$ver` 被静默丢弃 → 两个版本全被删掉）';
is $client.installer.list-installed.elems, 1,
   '账本条目仍在（不是把整包连根拔起）';

done-testing;
