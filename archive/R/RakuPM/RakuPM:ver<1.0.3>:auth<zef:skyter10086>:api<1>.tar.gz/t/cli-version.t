use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use JSON::Fast;

# `raku-pm version` 子命令：版本号单一来源是 META6.json。
# 开发模式（脚本旁两级有 META6.json）与 zef 安装模式（脚本在 site/bin，
# 从仓库链上已装的 RakuPM 元数据读）都要能报出 semver 版本号。

my $bin = $*PROGRAM.parent(2).add('bin').add('raku-pm.raku');
ok $bin.e, 'bin/raku-pm.raku 存在';

my $proc = run('raku', $bin.absolute.Str, 'version', :out, :err);
is $proc.exitcode, 0, 'version 命令退出码 0';

my $out = $proc.out.slurp(:close);
like $out, /'raku-pm v' \d+ '.' \d+ '.' \d+/, "报出版本号：{$out.lines[0]}";
like $out, /'raku' \s+ \S+/, '附带 raku 版本（排查环境问题用）';

# ---------- version <模块名>：查已装/激活版本 ----------
# 用独立的临时 RAKUPM_TARGET，不碰用户真实的账本
my $tmp = $*TMPDIR.add('rakupm-cliver-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
END { try { $tmp.add('installed.json').unlink; $tmp.rmdir } }
my %env = %( %*ENV, RAKUPM_TARGET => $tmp.absolute );

# 未安装的模块：不报错，明确说没装
$proc = run('raku', $bin.absolute.Str, 'version', 'NoSuch::Module-XYZ',
            :out, :err, :env(%env));
is $proc.exitcode, 0, '查询未安装模块退出码 0';
ok $proc.out.slurp(:close).contains('未安装'), '未安装时明确提示';

# 预置账本：FakeMod 1.2.3 → 应报出版本并标激活
my $seed = %( name => 'FakeMod', version => '1.2.3', auth => 'demo',
              provides => ['FakeMod'], digest => '' );
$tmp.add('installed.json').spurt(to-json(($seed,), :sorted-keys));
$proc = run('raku', $bin.absolute.Str, 'version', 'FakeMod',
            :out, :err, :env(%env));
my $mod-out = $proc.out.slurp(:close);
is $proc.exitcode, 0, '查询已装模块退出码 0';
ok $mod-out.contains('1.2.3'), '报出账本里的版本号';
ok $mod-out.contains('激活'), '标出激活版本';

# ---------- uninstall 不带包名：必须报错，绝不能"默认卸载自己" ----------
# 少打一个包名就把包管理器删掉属于破坏性的隐式行为（npm/pip/zef 无参数都是报错），
# 所以要求显式写出名字：要卸自己就写 raku-pm uninstall RakuPM。
$proc = run('raku', $bin.absolute.Str, 'uninstall', :out, :err, :env(%env));
nok $proc.exitcode == 0, 'uninstall 不带包名时报错（而不是默默卸载 raku-pm 自身）';
my $unin-err = $proc.err.slurp(:close);
ok $unin-err.contains('raku-pm uninstall Foo'),
   '报错里给出正确的用法示例';
ok $unin-err.contains('raku-pm uninstall RakuPM'),
   '并说明卸载自身需要显式写出名字';

done-testing;
