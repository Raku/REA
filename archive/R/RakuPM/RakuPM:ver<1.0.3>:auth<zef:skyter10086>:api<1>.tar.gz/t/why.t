use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::Repository;
use RakuPM::Resolver;

# Issue 5：`why` 依赖解析诊断命令的引擎（RakuPM::Resolver.explain-all）。
# 用内存仓库跑，不联网，验证「候选 + 来源仓库 + 淘汰原因 + 冲突双方约束」都能讲清。

class MemRepo does RakuPM::Repository {
    has @.rows;
    method id(--> Str) { 'mem:test' }
    method find-providers(Str $m --> List) {
        self.rows.grep({ $m (elem) @(.<provides>) }).map(*<name>).unique.List
    }
    method all-distributions(--> List) { self.rows.map(*<name>).unique.List }
    method available-versions(Str $n --> List) {
        self.rows.grep(*<name> eq $n).map(*<version>).unique.List
    }
    method fetch-distribution(Str $n, Str $v --> RakuPM::Distribution) {
        my $row = self.rows.first({ .<name> eq $n && .<version> eq $v });
        die "假仓库里找不到 $n $v" unless $row;
        RakuPM::Distribution.new:
            :name($row<name>),
            :version($row<version>),
            :provides(@($row<provides>)),
            :depends(RakuPM::Distribution.normalize-dependencies($row<depends> // {}));
    }
    method source-dir-for(Str $, Str $ --> IO::Path) { IO::Path }
}

sub resolver-for(@rows) {
    RakuPM::Resolver.new(:repos([MemRepo.new(:rows(@rows))]))
}

# A 要 Foo 0.0.25，B 要 Foo 0.0.24 —— 与 conflict-msg.t 同款骨架
my @ab =
    %( name => 'A',   version => '1.0', provides => ['A'],
       depends => { 'Foo' => '0.0.25' } ),
    %( name => 'B',   version => '1.0', provides => ['B'],
       depends => { 'Foo' => '0.0.24' } ),
    %( name => 'Foo', version => '0.0.25', provides => ['Foo'], depends => {} ),
    %( name => 'Foo', version => '0.0.24', provides => ['Foo'], depends => {} ),
;

# ===== 场景 1：单模块无约束 —— 解析到最高版本，低版本标注「版本较低」=====
{
    my %d = resolver-for(@ab).explain-all(
        (%( module => 'Foo', constraint => '' ),));
    ok %d<ok>, '单模块无约束：解析成功';
    my %foo = %d<modules><Foo>;
    is %foo<chosen><version>, '0.0.25', '选中最高版本 0.0.25';
    is %foo<chosen><repo>, 'mem:test', '选中的来源仓库也带了出来';
    is %foo<constraint>, '*', '无约束时有效约束为 *';

    # 候选：0.0.25 选中、0.0.24 被淘汰（版本较低）
    my %by-v = %foo<candidates>.list.map({ .<version> => $_ }).Hash;
    ok %by-v<0.0.25><satisfies>, '0.0.25 满足约束';
    ok %by-v<0.0.24><satisfies>, '0.0.24 也满足约束（* 是任意）';
    ok %by-v<0.0.25><reason>.contains('选中'), '0.0.25 标注为选中';
    ok %by-v<0.0.24><reason>.contains('版本较低'), '0.0.24 标注「版本较低」';
}

# ===== 场景 2：带约束 —— 不满足约束的候选明确标出原因 =====
{
    my %d = resolver-for(@ab).explain-all(
        (%( module => 'Foo', constraint => '0.0.24' ),));
    ok %d<ok>, '带约束 0.0.24：解析成功';
    my %foo = %d<modules><Foo>;
    is %foo<chosen><version>, '0.0.24', '约束 0.0.24 → 选 0.0.24';
    is %foo<constraint>, '0.0.24', '有效约束透传为 0.0.24';

    my %by-v = %foo<candidates>.list.map({ .<version> => $_ }).Hash;
    nok %by-v<0.0.25><satisfies>, '0.0.25 不满足约束 0.0.24';
    ok %by-v<0.0.25><reason>.contains('不满足约束'), '0.0.25 标注「不满足约束」';
    ok %by-v<0.0.24><satisfies>, '0.0.24 满足约束';
}

# ===== 场景 3：冲突 —— 双方约束都讲清楚（不 die）=====
{
    my %d = resolver-for(@ab).explain-all(
        (%( module => 'A', constraint => '' ), %( module => 'B', constraint => '' )));
    nok %d<ok>, 'A + B 一起解析：依赖冲突，ok=False';
    is %d<conflict><module>, 'Foo', '冲突模块是 Foo';
    is %d<conflict><existing><version>, '0.0.25', '冲突里记录了最后选定的版本 0.0.25';

    # 双方约束都在 requesters 里
    my @reqs = %d<conflict><requesters>.list;
    ok @reqs.first({ .<requester> eq 'A' && .<version> eq '0.0.25' }).defined,
       '冲突链含 A → Foo 0.0.25';
    ok @reqs.first({ .<requester> eq 'B' && .<version> eq '0.0.24' }).defined,
       '冲突链含 B → Foo 0.0.24';

    # 冲突模块的诊断细节也在 modules 里（帮用户决定 pin 哪边）
    ok %d<modules><Foo>:exists, '冲突模块 Foo 的诊断细节也返回了';
    my %foo = %d<modules><Foo>;
    is %foo<chosen><version>, '0.0.25', '冲突场景下 Foo 仍显示已选 0.0.25';
    ok %foo<wanted>.list.elems >= 2, 'Foo 的「谁要求了它」含 A、B 两条';
}

# ===== 场景 4：顶层互斥约束 —— 请求人显示为 <top-level> =====
{
    my %d = resolver-for(@ab).explain-all(
        (%( module => 'Foo', constraint => '0.0.25' ),
         %( module => 'Foo', constraint => '0.0.24' )));
    nok %d<ok>, '顶层给 Foo 两个互斥约束：冲突';
    my @reqs = %d<conflict><requesters>.list;
    ok @reqs.first({ .<requester> eq '<top-level>' && .<version> eq '0.0.25' }).defined,
       '顶层请求人显示为 <top-level>';
    ok @reqs.first({ .<requester> eq '<top-level>' && .<version> eq '0.0.24' }).defined,
       '另一条顶层约束也在';
}

# ===== 场景 5：正常解析行为不受影响（explain 不应污染 resolve）=====
{
    my @res = resolver-for(@ab).resolve-all(
        (%( module => 'A', constraint => '' ), %( module => 'Foo', constraint => '0.0.25' )));
    is @res.map({ .name ~ ':' ~ .version }).sort.join(','), 'A:1.0,Foo:0.0.25',
       'explain-all 之外，普通 resolve-all 行为不变';
}

# ===== 场景 6：chosen-detail 暴露来源仓库 =====
{
    my $r = resolver-for(@ab);
    $r.resolve('Foo', '');
    my %detail = $r.chosen-detail;
    is %detail<Foo><name>, 'Foo', 'chosen-detail 给发行版名';
    is %detail<Foo><version>, '0.0.25', 'chosen-detail 给版本';
    is %detail<Foo><repo>, 'mem:test', 'chosen-detail 给来源仓库';
}

done-testing;
