use v6;
use Test;
use RakuPM::Resolver;
use RakuPM::Distribution;

# 回归：随 Rakudo 发布的核心模块（Test 等）不是可安装包，
# 解析器不应把它们当成外部依赖去仓库里找（否则 self-upgrade 装 RakuPM
# 自身时 test-depends 含 Test → 解析失败 → 整个升级回滚）。

# 没有仓库 → 任何「真找不到」的模块都会 die；这用来证明
# 核心模块跳过是【精确作用】的，不会顺手吞掉真正的「找不到」。
my $resolver = RakuPM::Resolver.new(:repos([]));

# 1) 直接解析核心模块 Test：应当不报错、且不物化成待安装发行版
lives-ok {
    my @o = $resolver.resolve('Test');
    is @o.elems, 0, 'resolve(Test): 核心模块不被物化';
}, 'resolve(Test) 不报错（无仓库也不应 die）';

# 2) 模拟 ensure-phase-deps 的真实调用：从某发行版的 test-depends 构造 specs 再 resolve-all
my $dist = RakuPM::Distribution.new(
    :name<RakuPM>, :version<0.36.3>,
    :test-depends({ Test => '*' }));
my @specs = $dist.test-depends.kv.map: -> $m, $c {
    %( module => $m, constraint => $c )
};
lives-ok {
    my @o = $resolver.resolve-all(@specs);
    is @o.elems, 0, 'test-depends={Test} 解析后无任何待安装项';
}, 'resolve-all( test-depends 含 Test ) 不报错';

# 3) 反向确认：一个确实不存在的模块（无仓库）仍然要 die，
#    证明核心模块跳过没有把「真找不到」也一并吞掉。
throws-like {
    $resolver.resolve('This::Module::Is::Not::Real::At::All::XYZ');
}, X::AdHoc, '找不到真实模块仍报错（核心模块跳过是精确作用）';

done-testing;
