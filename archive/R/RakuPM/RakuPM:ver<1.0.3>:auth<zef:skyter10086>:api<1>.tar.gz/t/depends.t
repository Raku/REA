use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Version;

plan 28;

# ===== 数组形式 depends（真实生态里大量存在，曾因只处理 runtime.requires 而丢失）=====
my %d-array = RakuPM::Distribution.normalize-dependencies(
    [ "MIME::Base64", "File::Directory::Tree:ver<0.2+>:auth<zef:raku-community-modules>" ]
);
is %d-array.keys.sort.join(','), 'File::Directory::Tree,MIME::Base64',
   '数组形式：所有元素都被展开';
is %d-array<MIME::Base64>, '*', '数组元素无约束默认为 *';
is %d-array<File::Directory::Tree>, '0.2+', '数组元素内 :ver<0.2+> 被提取';

# ===== 数组内 Hash 元素（{ :name, :ver } 写法）=====
my %d-hash = RakuPM::Distribution.normalize-dependencies(
    [ { name => 'JSON::Fast', ver => '0.10' }, { name => 'Foo', auth => 'zef:x' } ]
);
is %d-hash<JSON::Fast>, '0.10', '数组内 Hash 元素：ver 被提取';
is %d-hash<Foo>, '*', '数组内 Hash 元素：仅 auth 时约束为 *';

# ===== 平铺 Hash 形式（META.json 风格）=====
my %d-flat = RakuPM::Distribution.normalize-dependencies(
    { "Foo::Bar" => "1.0", "Baz" => "*" }
);
is %d-flat<Foo::Bar>, '1.0', '平铺 Hash：约束保留';
is %d-flat<Baz>, '*', '平铺 Hash：通配符';

# ===== 分阶段结构只取 runtime（构建/测试依赖不计入安装依赖树）=====
my %d-phase = RakuPM::Distribution.normalize-dependencies(
    {
        runtime => { requires => ['A'] },
        test    => { requires => ['Test'] },
        build   => { requires => ['B'] },
    }
);
is %d-phase.keys.sort.join(','), 'A', '分阶段：只取 runtime.requires';

# ===== 版本约束 "0.2+"（at-least）=====
ok RakuPM::Version.from-string('0.3').satisfies('0.2+'),  '0.2+ 满足 0.3';
ok RakuPM::Version.from-string('0.2').satisfies('0.2+'),  '0.2+ 满足 0.2';
nok RakuPM::Version.from-string('0.1').satisfies('0.2+'), '0.2+ 不满足 0.1';

# ===== :from<native> 标记（DB::SQLite 之类的包需要系统库 libsqlite3）=====
# 不当 Raku 模块去查仓库，而是收集到 native-libs 列表里提示用户。
my %d-native = RakuPM::Distribution.normalize-dependencies(
    [ 'JSON::Fast', 'sqlite3:from<native>', 'libffi:from<native>', 'DB' ]
);
is %d-native.keys.sort.join(','), 'DB,JSON::Fast',
   'native 依赖被排除出 raku 依赖表';
my ($d-h, $native) = RakuPM::Distribution.normalize-dependencies-and-native-libs(
    [ 'JSON::Fast', 'sqlite3:from<native>', 'libffi:from<native>', 'DB' ]
);
is $native.sort.join(','), 'libffi,sqlite3',
   'native 依赖按出现顺序去重收集到 native-libs';

# ===== Hash 形式里的 :from<native>（{ from => "native" } 字段）=====
my ($d-h2, $native2) = RakuPM::Distribution.normalize-dependencies-and-native-libs(
    [ { name => 'Foo' }, { name => 'bar', from => 'native' } ]
);
is $d-h2.keys.sort.join(','), 'Foo', 'Hash 形式：普通依赖进入 raku 依赖';
is $native2, ('bar',), 'Hash 形式：from<native> 进入 native-libs';

# ===== 发行版对象暴露 native-libs =====
my $tmpd = $*TMPDIR.add('rakupm-native-test-' ~ $*PID ~ '-' ~ now.floor).mkdir;
my $meta = $tmpd.add('META6.json');
$meta.spurt(to-json({
    name     => 'DB::SQLite',
    version  => '0.7',
    auth     => 'cpan:CTILMES',
    provides => { 'DB::SQLite' => 'lib/DB/SQLite.rakumod' },
    depends  => {
        runtime => { requires => [
            'BitEnum', 'DB',
            'NativeLibs:ver<0.0.7+>:auth<github:salortiz>',
            'sqlite3:from<native>',
        ] }
    },
}, :sorted-keys));
my $dist = RakuPM::Distribution.from-meta6-file($meta);
is $dist.native-libs.sort.join(','), 'sqlite3', '发行版对象可读出 native-libs';
my $has-raku = $dist.depends<DB>.defined && $dist.depends<BitEnum>.defined;
ok $has-raku, 'raku 依赖仍正确解析';
nok $dist.depends<sqlite3>.defined, 'sqlite3 不在 raku 依赖里';

# ===== A 修复（0.37.1）：依赖串多个 phaser 不能只解析第一个就 last =====
# 字符串依赖 'Foo:ver<1.0>:from<native>' 曾因第一个 phaser 后 last，把 :from<native>
# 丢掉 → 本地库依赖被误判成 raku 模块，去仓库找一个不存在的包，装错/装崩。
my ($rA, $nA) = RakuPM::Distribution.normalize-dependencies-and-native-libs(
    'Foo:ver<1.0>:from<native>'
);
ok $nA.grep('Foo'), 'Foo:ver<1.0>:from<native> → 进 native 列表（不被误判为 raku）';
nok $rA<Foo>:exists, 'Foo 不应出现在 raku 依赖表';

# :from 在前、:ver 在后 也要正确（两个顺序都得扫到）
my ($rA2, $nA2) = RakuPM::Distribution.normalize-dependencies-and-native-libs(
    'Bar:from<native>:ver<2.0>'
);
ok $nA2.grep('Bar'), 'Bar:from<native>:ver<2.0> → 仍进 native 列表';

# 普通 raku 依赖（只 :ver）约束保留
my ($rA3,) = RakuPM::Distribution.normalize-dependencies-and-native-libs('Baz:ver<3.0>');
is $rA3<Baz>, '3.0', 'Baz:ver<3.0> → raku 依赖表，约束 3.0';

# ===== >= / > 解析修复（0.37.5）：运算符自带的 > 不能被当闭合括号 =====
# 裸 index('>') 会把 `Foo:ver<>=0.1.0>` 截成空约束 —— 静默退化成「任意版本」，
# 依赖约束 `>=` 完全失效（是"装错版本"级别的静默 bug，不是报错）。
my ($rG,) = RakuPM::Distribution.normalize-dependencies-and-native-libs('Foo:ver<>=0.1.0>');
is $rG<Foo>, '>=0.1.0', 'Foo:ver<>=0.1.0> → 约束 >=0.1.0（不再被截成空串）';
my ($rG2,) = RakuPM::Distribution.normalize-dependencies-and-native-libs('Foo:ver<>0.1.0>');
is $rG2<Foo>, '>0.1.0', 'Foo:ver<>0.1.0> → 约束 >0.1.0';
my ($rG3,) = RakuPM::Distribution.normalize-dependencies-and-native-libs('Foo:ver<>=1.0, <2.0>');
# 值本身是 `>=1.0, <2.0`（串尾 `>` 是 phaser 闭合括号；右界 `<` 是运算符）
is $rG3<Foo>, '>=1.0, <2.0', 'Foo:ver<>=1.0, <2.0> → 区间左界 >= 正确、右界不丢';
# 多 phaser：ver 值里带 > 时闭合括号定位不能串到后面的 :from
my ($rG4, $nG4) = RakuPM::Distribution.normalize-dependencies-and-native-libs(
    'Foo:ver<>=0.1.0>:from<native>');
is $rG4.elems, 0, 'ver<>=0.1.0> + from<native>：不进 raku 依赖表';
is $nG4.join(','), 'Foo', 'ver<>=0.1.0> + from<native>：仍归入 native-libs';

# ===== D 硬化（0.37.1）：损坏 JSON 的 META 文件抛出清晰报错（含文件名）=====
# 不再把底层 "Malformed JSON" 栈甩给用户；由调用方（Local 仓库）的 try 兜住后跳过。
my $bad = $tmpd.add('BAD-META.json');
$bad.spurt('{ this is not valid json,,, ');
throws-like { RakuPM::Distribution.from-meta-file($bad) },
    Exception, message => /'META 文件'/,
    '损坏 JSON：from-meta-file 报错含文件名，而非底层 Malformed JSON 栈';
LEAVE { try { $bad.unlink if $bad.e } }

# 用 LEAVE 块清理临时目录，异常路径也能跑。
# 顺序必须是「先删文件，再删目录」—— Windows 上 .rmdir 在非空目录上静默失败，
# 留下垃圾会让 zef install 的退出清理（[FAIL] Failed to remove the directory …）
# 把整个测试套件判失败，但本地 `raku -I lib t/depends.t` 单独跑看不出来。
LEAVE {
    try { $meta.unlink if $meta.e }
    try { $tmpd.rmdir if $tmpd.d }
}
