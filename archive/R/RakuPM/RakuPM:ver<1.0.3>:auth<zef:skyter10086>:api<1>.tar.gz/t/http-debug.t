use lib 'lib';
use Test;
use RakuPM::HTTP;
use RakuPM::HTTP::Backend;

# Issue 6（HTTP 可观察性）的回归用例。
#
# 全程用【纯假后端】（不触网、不依赖 curl / HTTP::Tinyish），只验证 debug 级日志的
# 「有无」与「内容」：
#   · 默认关 → 零 http: 行（输出与现状一致，不刷屏）；
#   · 开（:$debug 或 RAKUPM_HTTP_DEBUG）→ 报出用的哪个后端 / 304 缓存命中 / 离线硬拦；
#   · 行为不变 —— 离线仍被 assert-online 硬拦。
#
# 0.82.0 起 HTTP 单后端（curl）：不再有「后端顺序 / 覆盖来源 / 回落」这些 debug 行，
# 替身经构造器 :backend 注入。
#
# 排障行前缀统一为「  · http: 」，刻意不含 ⚠ / [RakuPM]（tools/run-suite.raku 在
# t/ 下把这两个标记当「生产级噪音」判失败），所以本文件即使 debug 开着也不会误红。

# ---------- 纯假后端 ----------
class FakeOK does RakuPM::HTTP::Backend {
    method get-text(Str $u, *%o --> Str) { 'ok-body' }
    method download(Str $u, IO::Path $d, *%o --> Nil) { $d.spurt('ok') }
    method get-text-conditional(Str $u, Str :$if-none-match = ''
                                --> RakuPM::HTTP::ConditionalResponse) {
        RakuPM::HTTP::ConditionalResponse.new(:status(200), :body('fresh'))
    }
}
class Fake304 does RakuPM::HTTP::Backend {
    method get-text(Str $u, *%o --> Str) { 'x' }
    method download(Str $u, IO::Path $d, *%o --> Nil) { $d.spurt('x') }
    method get-text-conditional(Str $u, Str :$if-none-match = ''
                                --> RakuPM::HTTP::ConditionalResponse) {
        RakuPM::HTTP::ConditionalResponse.new(:status(304))
    }
}
class FakeFail does RakuPM::HTTP::Backend {
    method get-text(Str $u, *%o --> Str) { die 'boom' }
    method download(Str $u, IO::Path $d, *%o --> Nil) { die 'boom' }
}

# 门面 + 注入的替身后端。默认给很小的重试退避，免得失败用例慢慢等。
# 注意 :debug 要【按需透传】—— 若一律传 :debug(False)，会把门面「未传 :debug 就去读
# RAKUPM_HTTP_DEBUG 环境变量」的兜底路径堵死（False // env = False），第 9 条就测不到了。
sub http-with($backend, *%opts --> RakuPM::HTTP) {
    RakuPM::HTTP.new(:$backend, :base-delay(0.001), |%opts);
}

# 捕获 stderr（note 走 $*ERR）的小工具。&op 若抛异常会在内部 try 掉，
# 调用方只关心抓回的 stderr 行。
sub capture-debug(&op) {
    my $log = ($*TMPDIR // '/tmp'.IO)
        .add("rakupm-dbg-{now.to-posix[0].Int}-{$*PID}-{(rand * 1e9).Int}.log");
    my $fh = $log.open(:w);
    temp $*ERR = $fh;
    try &op();
    $fh.flush;
    $fh.close;
    my @l = $log.e ?? $log.slurp.lines !! ();
    $log.unlink;
    @l;
}

plan 9;

# 1) 默认关：不产生任何 http: 行（输出与现状一致）
{
    temp %*ENV<RAKUPM_HTTP_DEBUG>;   # 确保本例不被外部环境变量打开
    my @l = capture-debug({ http-with(FakeOK.new).get-text('http://x/a') });
    ok @l.grep({ $_.contains('http:') }).elems == 0,
       '默认关：get-text 不产生 http: debug 行（不刷屏）';
}

# 2~3) :debug：报出 GET 目标 + 实际使用的后端
{
    my @l = capture-debug({ http-with(FakeOK.new, :debug).get-text('http://x/b') });
    ok @l.grep({ $_.contains('GET http://x/b') }).elems == 1,
       'debug：报出 GET 目标';
    ok @l.grep({ $_.contains('用后端') && $_.contains('FakeOK') }).elems == 1,
       'debug：报出实际使用的后端（注入替身的类名）';
}

# 4) 304 缓存命中：统一措辞
{
    my @l = capture-debug({
        http-with(Fake304.new, :debug).get-text-conditional('http://x/d', :if-none-match('v1'));
    });
    ok @l.grep({ $_.contains('304 命中本地缓存') }).elems == 1,
       'debug：条件 GET 命中缓存统一为「304 命中本地缓存（不重新下载）」';
}

# 5) 离线 + debug：明确报出 离线=ON（绝不静默联网）
{
    temp %*ENV<RAKUPM_OFFLINE> = '1';
    my @l = capture-debug({ try { http-with(FakeOK.new, :debug).get-text('http://x/e') } });
    ok @l.grep({ $_.contains('离线=ON') }).elems == 1,
       'debug：离线时明确报出 离线=ON（绝不静默改成联网）';
}

# 6) 离线行为不变：get-text 被 assert-online 硬拦
{
    temp %*ENV<RAKUPM_OFFLINE> = '1';
    my $r = try { http-with(FakeOK.new).get-text('http://x/f') };
    ok $r !~~ Str || $r eq '', '离线模式：get-text 被 assert-online 硬拦（行为不变）';
}

# 7) 请求失败：仍报出所用后端（便于定位）
{
    my @l = capture-debug({
        try { http-with(FakeFail.new, :debug, :attempts(1)).get-text('http://x/i') }
    });
    ok @l.grep({ $_.contains('用后端') && $_.contains('FakeFail') }).elems == 1,
       'debug：请求失败时仍报出所用后端（便于定位）';
}

# 8) download 也走 debug（报 DOWNLOAD 目标）
{
    my $tmpf = ($*TMPDIR // '/tmp').add("rakupm-dbg-dl-{$*PID}.bin");
    my @l = capture-debug({ http-with(FakeOK.new, :debug).download('http://x/j', $tmpf) });
    ok @l.grep({ $_.contains('DOWNLOAD http://x/j') }).elems == 1,
       'debug：download 报出 DOWNLOAD 目标';
    $tmpf.unlink if $tmpf.e;
}

# 9) 环境变量 RAKUPM_HTTP_DEBUG 也能开（无需改任何调用点）
{
    temp %*ENV<RAKUPM_HTTP_DEBUG> = '1';
    my @l = capture-debug({ http-with(FakeOK.new).get-text('http://x/k') });
    ok @l.grep({ $_.contains('http:') }).elems >= 1,
       'RAKUPM_HTTP_DEBUG=1：不开 :debug 也能打开排障（不改动调用点）';
}
