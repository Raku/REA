use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::NativeLib;
use RakuPM::Distribution;

plan 50;

# 关键设计：os / distro 可以强制指定，所以三套规则能在同一台机器上被完整覆盖，
# 不必真的去开三台机器。

# ===== 系统识别 =====
is RakuPM::NativeLib.new(:os<win32>).os-key,  'win32',  '强制 win32';
is RakuPM::NativeLib.new(:os<darwin>).os-key, 'darwin', '强制 darwin';
is RakuPM::NativeLib.new(:os<linux>).os-key,  'linux',  '强制 linux';
ok RakuPM::NativeLib.new.os-key eq 'win32' | 'darwin' | 'linux',
   '不指定时自动探测出三者之一';

is RakuPM::NativeLib.new(:os<win32>).os-label,  'Windows',    'os-label：Windows';
is RakuPM::NativeLib.new(:os<darwin>).os-label, 'macOS',      'os-label：macOS';
is RakuPM::NativeLib.new(:os<linux>).os-label,  'Linux/Unix', 'os-label：Linux/Unix';

# ===== 文件名解析：同一个逻辑名在三套系统上是三个文件 =====
my $w = RakuPM::NativeLib.new(:os<win32>);
my $d = RakuPM::NativeLib.new(:os<darwin>);
my $l = RakuPM::NativeLib.new(:os<linux>);

is $w.candidates('sqlite3'), ('sqlite3.dll',),
   'Windows：sqlite3 → sqlite3.dll（无 lib 前缀）';
is $d.candidates('sqlite3'), ('libsqlite3.dylib', 'libsqlite3.0.dylib'),
   'macOS：sqlite3 → libsqlite3.dylib';
is $l.candidates('sqlite3'), ('libsqlite3.so', 'libsqlite3.so.0'),
   'Linux：sqlite3 → libsqlite3.so';

# 这是本次要修的核心：三个系统给出的文件名必须两两不同
ok ($w.candidates('sqlite3') (^) $d.candidates('sqlite3')).elems > 0
   && ($d.candidates('sqlite3') (^) $l.candidates('sqlite3')).elems > 0,
   'sqlite3 在三套系统上确实是三个不同的文件名';

# ===== 未知库走通用命名规则 =====
is $w.candidates('myweirdlib'), ('myweirdlib.dll', 'libmyweirdlib.dll'),
   '未知库 Windows：优先不带 lib 前缀';
is $d.candidates('myweirdlib'), ('libmyweirdlib.dylib', 'myweirdlib.dylib'),
   '未知库 macOS：优先带 lib 前缀';
is $l.candidates('myweirdlib'), ('libmyweirdlib.so', 'myweirdlib.so'),
   '未知库 Linux：优先带 lib 前缀';

# 已经写了扩展名的不再加前缀后缀
is $l.candidates('libfoo.so.7'),  ('libfoo.so.7',),  '带 .so.N 的原样返回';
is $w.candidates('Foo.Bar.dll'),  ('Foo.Bar.dll',),  '带 .dll 的原样返回';

# 空输入与纯空白
is $w.candidates('').elems,   0, '空字符串没有候选';
is $w.candidates('   ').elems, 0, '纯空白没有候选';

# ===== Linux 发行版族（决定给 apt 还是 dnf 还是 pacman）=====
is RakuPM::NativeLib.new(:os<linux>, :distro<ubuntu>).package-key, 'debian',
   'Ubuntu → debian 族（apt）';
is RakuPM::NativeLib.new(:os<linux>, :distro<fedora>).package-key, 'rhel',
   'Fedora → rhel 族（dnf）';
is RakuPM::NativeLib.new(:os<linux>, :distro<arch>).package-key,   'arch',
   'Arch → arch 族（pacman）';
is RakuPM::NativeLib.new(:os<linux>, :distro<alpine>).package-key, 'alpine',
   'Alpine → alpine 族（apk）';
is RakuPM::NativeLib.new(:os<linux>, :distro<opensuse>).package-key, 'suse',
   'openSUSE → suse 族（zypper）';
is RakuPM::NativeLib.new(:os<linux>, :distro<someunknownos>).package-key, 'linux',
   '认不出的发行版退回泛用 linux';
is RakuPM::NativeLib.new(:os<win32>).package-key, 'win32',
   'Windows 直接按系统给命令，不细分发行版';

# ===== 安装命令随系统变化 =====
# 认不出具体发行版时，把 Linux 各家族的命令都列出来；
# 尤其不能退成 Windows 的 vcpkg 命令（这是实现时踩过的坑）
my $vague = RakuPM::NativeLib.new(:os<linux>, :distro<someunknownos>)
              .install-hint('sqlite3');
ok $vague.contains('apt') && $vague.contains('dnf') && $vague.contains('pacman'),
   'Linux 认不出发行版时列出各家族命令';
nok $vague.contains('vcpkg'), '且不会误给 Windows 的安装命令';

ok $w.install-hint('sqlite3').contains('vcpkg'), 'Windows 提示 vcpkg/choco';
ok $d.install-hint('sqlite3').contains('brew'),  'macOS 提示 brew';
ok RakuPM::NativeLib.new(:os<linux>, :distro<ubuntu>)
     .install-hint('sqlite3').contains('apt'),
   'Ubuntu 提示 apt';
ok RakuPM::NativeLib.new(:os<linux>, :distro<fedora>).install-hint('sqlite3')
     .contains('dnf'),
   'Fedora 上给的是 dnf 命令而不是 apt';

# 表里没收录的库不瞎猜包名
ok $w.install-hint('totally-made-up-lib').contains('未'),
   '未知库不瞎编安装命令';

# ===== 搜索路径 =====
ok $w.search-paths.elems > 0, 'Windows 有搜索路径';
ok $d.search-paths.elems > 0, 'macOS 有搜索路径';
ok $l.search-paths.elems > 0, 'Linux 有搜索路径';

# 路径集合也随系统不同：Windows 看 PATH，Unix 看 /usr/lib 之类
ok $w.search-paths.grep({ .contains('Windows') || .contains(':') }).elems > 0,
   'Windows 搜索路径里含盘符或 Windows 系统目录';
ok $d.search-paths.grep(*.starts-with('/')).elems > 0,
   'macOS 搜索路径是 Unix 风格绝对路径';
ok $l.search-paths.grep(*.starts-with('/')).elems > 0,
   'Linux 搜索路径是 Unix 风格绝对路径';
ok $l.search-paths.grep({ .contains('linux-gnu') }).elems > 0,
   'Linux 搜索路径含 Debian 系的多架构目录';

# PATH 里的垃圾条目（如单独的 "C"）应被过滤
ok $w.search-paths.grep({ .chars <= 1 }).elems == 0,
   '过滤掉长度不足的无效 PATH 条目';

# ===== 探测：造一个真的存在的文件，验证能找到 =====
my $tmp = $*TMPDIR.add('rakupm-nativelib-' ~ $*PID ~ '-' ~ now.floor).mkdir;
my $probe = RakuPM::NativeLib.new(:os<win32>);
# 把临时目录塞进 PATH，验证 Windows 分支确实会扫 PATH
%*ENV<PATH> = $tmp.Str ~ ';' ~ %*ENV<PATH>;
$tmp.add('fakeprobe123.dll').spurt('');
is $probe.find('fakeprobe123').basename, 'fakeprobe123.dll',
   '能在搜索路径里找到库（按本系统文件名规则拼出名字）';
ok $probe.installed('fakeprobe123'), 'installed 返回 True';
nok $probe.installed('definitely-not-here-xyz'), '找不到的库返回 False';
is $probe.find('definitely-not-here-xyz'), IO::Path,
   'find 找不到时返回未定义的 IO::Path';

# ===== check 批量接口 =====
my @res = $probe.check(('fakeprobe123', 'definitely-not-here-xyz'));
is @res.elems, 2, 'check 返回每项一个结果';
is @res[0]<found>, True,  'check：存在的库 found=True';
is @res[1]<found>, False, 'check：缺失的库 found=False';
ok @res[1]<hint>.chars > 0, 'check：缺失的库带安装提示';

# ===== 与 Distribution 联动：:from<native> 解析出来的名字能直接查 =====
my $meta = $tmp.add('META6.json');
$meta.spurt(to-json({
    name     => 'DB::SQLite',
    version  => '0.7',
    provides => { 'DB::SQLite' => 'lib/DB/SQLite.rakumod' },
    depends  => { runtime => { requires => [
        'BitEnum', 'sqlite3:from<native>', 'libffi:from<native>',
    ] } },
}, :sorted-keys));
my $dist = RakuPM::Distribution.from-meta6-file($meta);
my @checked = RakuPM::NativeLib.new(:os<win32>).check($dist.native-libs);
is @checked.map(*<name>).sort.join(','), 'libffi,sqlite3',
   'Distribution.native-libs 直接喂给 check';
ok @checked.map(*<files>).all.contains('.dll'),
   'Windows 上两条 native 依赖都解析成 .dll 文件名';

# 用 LEAVE 块清理，异常路径下也能跑（顺序固定：先删文件，再删目录）。
# 否则 zef install 跑测试时会因 [FAIL] Failed to remove the directory ...
# 把整个套件判失败，单跑 raku 时看不出问题。
LEAVE {
    try { $tmp.add('fakeprobe123.dll').unlink }
    try { $meta.unlink }
    try { $tmp.rmdir if $tmp.d }
}
