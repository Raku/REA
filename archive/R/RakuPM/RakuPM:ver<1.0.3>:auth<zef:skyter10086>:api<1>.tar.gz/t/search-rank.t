use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Repository::Local;
use JSON::Fast;

# 回归：search 结果必须按【相关度】排序，而不是纯字母序。
# 相关度由 RakuPM::Repository::Matching.match-score 统一给出（0 最优）：
#   0 发行名精确 / 1 发行名前缀 / 2 发行名子串
#   3 模块名精确 / 4 模块名前缀 / 5 模块名子串
# 这是对用户反馈「search 结果不是按名称和版本号匹配度排序」的修复。
#
# 离线、确定性：只测 Local 仓库对象，不碰网络。

my $base = $*TMPDIR.add("rakupm-search-rank-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

sub make-dist($dir, :$name, :$version, :$desc, :@provides) {
    $dir.mkdir;
    $dir.add('lib').mkdir;
    for @provides -> $mod {
        my $mod-file = $dir.add("lib/{$mod.subst('::', '/', :g)}.rakumod");
        $mod-file.parent.mkdir;
        $mod-file.spurt("unit module $mod;\n");
    }
    $dir.add('META6.json').spurt(to-json({
        name => $name, version => $version, auth => 'demo:raku',
        description => $desc, provides => @provides, depends => {},
    }, :sorted-keys));
}

# 六个发行版对同一查询 'foo' 分别落在六个相关度档位：
#   Foo     → 精确名               score 0
#   Foobar  → 名字前缀 (foo*)      score 1
#   Barfoo  → 名字子串 (*foo*)     score 2
#   Qux     → 提供的模块名 Foo     score 3
#   Quux    → 提供的模块名 Foobar  score 4
#   Corge   → 提供的模块名 Baz::Foo score 5
make-dist($base.add('Foo'),    :name('Foo'),    :version('1.0.0'), :desc('exact'),      :provides(['Foo']));
make-dist($base.add('Foobar'), :name('Foobar'), :version('1.0.0'), :desc('prefix'),     :provides(['Foobar']));
make-dist($base.add('Barfoo'), :name('Barfoo'), :version('1.0.0'), :desc('substring'),  :provides(['Barfoo']));
make-dist($base.add('Qux'),    :name('Qux'),    :version('1.0.0'), :desc('mod-exact'),  :provides(['Foo']));
make-dist($base.add('Quux'),   :name('Quux'),   :version('1.0.0'), :desc('mod-prefix'), :provides(['Foobar']));
make-dist($base.add('Corge'),  :name('Corge'),  :version('1.0.0'), :desc('mod-substr'), :provides(['Baz::Foo']));

my $repo = RakuPM::Repository::Local.new(:root($base));

plan 8;

# 1) 六个包都该命中（覆盖六种匹配方式）
my @got = $repo.search-rows('foo');
is @got.elems, 6, 'foo 命中全部 6 个包（名 3 档 + 模块名 3 档）';

# 2) 顺序必须是 精确 → 前缀 → 子串 → 模块精确 → 模块前缀 → 模块子串
my @order = @got.sort({ .<_score> }).map(*<name>);
is @order.join(','), 'Foo,Foobar,Barfoo,Qux,Quux,Corge',
   'search 按相关度排序：名精确(0) < 名前缀(1) < 名子串(2) < 模块精确(3) < 模块前缀(4) < 模块子串(5)';

# 3) _score 字段确实反映了分级
my %by-name = @got.map({ .<name> => .<_score> });
is %by-name<Foo>,    0, 'Foo 名精确 _score=0';
is %by-name<Foobar>, 1, 'Foobar 名前缀 _score=1';
is %by-name<Barfoo>, 2, 'Barfoo 名子串 _score=2';
is %by-name<Qux>,    3, 'Qux 模块名精确 _score=3';
is %by-name<Quux>,   4, 'Quux 模块名前缀 _score=4';
is %by-name<Corge>,  5, 'Corge 模块名子串 _score=5';

done-testing;
