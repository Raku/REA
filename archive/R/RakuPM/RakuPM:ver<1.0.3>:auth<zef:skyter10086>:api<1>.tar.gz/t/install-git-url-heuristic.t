use lib 'lib';
use Test;

# A3 回归：install 顶层参数对 git URL 的探测是启发式的。
# 旧逻辑：任何以 `.git` 结尾的字符串都被当成 git URL —— 于是本地目录
# `./my.repo.git` 会被误判、拿去 `git clone` 而失败（报 not a git repository）。
# 修复：以 `.git` 结尾、但磁盘上确实存在的本地路径，优先当本地目录装
#       （bin 的 `.git$` 判断加了 `&& !$spec.IO.e`）。

my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;

sub run-cli(*@args) {
    my $p = run($raku, '-Ilib', $bin, |@args, :out, :err);
    ($p.exitcode, $p.out.slurp(:close), $p.err.slurp(:close))
}
sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add("rakupm-a3-{$*PID}");
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 故意把本地发行版目录命名为 dist.git（触发旧误判）
my $dist = $tmp.add('dist.git');
$dist.mkdir;
$dist.add('META6.json').spurt(q:to/END/);
{
  "name": "DistGit",
  "version": "0.1.0",
  "author": "t",
  "provides": { "DistGit": "lib/DistGit.rakumod" },
  "depends": []
}
END
$dist.add('lib').mkdir;
$dist.add('lib/DistGit.rakumod').spurt("unit module DistGit;\n");

my $tgt = $tmp.add('tgt').absolute.Str;
my ($code, $out, $err) = run-cli('install', $dist.absolute.Str, '--dry', "--target=$tgt", '--offline');
my $all = $out ~ $err;

# 核心断言：本地 .git 目录不应被拿去 git clone（旧 bug 会报 not a git repository）
ok !$err.contains('not a git repository'),
   'A3: 本地 .git 目录未被误当 git URL 去 clone';
# 积极证据：走了 install-from-dir（识别为本地目录、解析成功）
ok $all.contains('本地目录') || $code == 0,
   'A3: 本地 .git 目录被当本地安装（install-from-dir）';

done-testing;
