use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Installer::Generations;
use RakuPM::Fs;

# RakuPM::Installer::Generations 是 0.43.0 从 Installer 里提出来的值对象：
# <target>/generations/ 的格式（id 分配 / before.json / meta.json / manifest.json /
# current / 裁剪）从此只有一处定义。这里把它当纯目录操作来测 —— 不碰 CUR 也不碰 store，
# 这正是当初把它提出来的理由之一。
#
# 造 fixture 时**不要**写 `installed => [%(name=>..., version=>...)]`：Raku 会把数组里的
# Hash 展平成一堆单键 Hash（本项目踩过三次），于是 {"name"}/{"version"} 各自成对、取不到对方
# 的键。一律用 `.push(%(...))`。

my IO::Path $root = $*TMPDIR.add("rakupm-gens-{$*PID}");
LEAVE rm-tree($root) if $root.e;

my $g = RakuPM::Installer::Generations.new(:dir($root.add('generations')));

sub installed-pair(Str $n, Str $v --> List) {
    my @l;
    @l.push(%( name => $n, version => $v ));
    @l.List
}

# ---- 空状态 ----
is $g.current, '', '没有世代时 current 是空串';
is $g.list.elems, 0, '没有世代时 list 为空';
is $g.next-id, '000001', '目录还不存在时 next-id 也返回 000001（不炸）';

# ---- begin ----
my %tx = $g.begin(:label('install'), before => '[]');
is %tx<id>, '000001', 'begin 分配 000001';
ok %tx<dir>.d, 'begin 建了世代目录';
ok %tx<dir>.add('before.json').e, 'begin 写了 before.json（回滚的真值来源）';
is $g.current, '', 'begin 不动 current —— 只有提交才算数';

# ---- finish ----
$g.finish(%tx,
    ledger-json => '[{"name":"A","version":"1.0"}]',
    installed   => installed-pair('A', '1.0'));
is $g.current, '000001', 'finish 把该世代设为 current';
is $g.list.elems, 1, 'finish 后有 1 个世代';
is $g.list[0]<installed>.List.raku, ('A 1.0',).List.raku,
    'meta.json 记下本次装了 A 1.0（"name version" 形式）';
is $g.list[0]<current>, True, 'list 标出当前世代';
ok %tx<dir>.add('manifest.json').e, 'finish 写了 manifest.json（提交后的账本）';

# ---- discard：半成品世代不留痕 ----
my %tx2 = $g.begin(:label('rollback'), before => '[]');
is %tx2<id>, '000002', '第二个世代 id 递增';
$g.discard(%tx2);
nok %tx2<dir>.e, 'discard 删掉了半成品世代';
is $g.list.elems, 1, 'discard 不影响已有世代';

# ---- id 复用：discard 掉的号会被下一个世代重新拿到 ----
# 这是刻意的：next-id 按磁盘上还剩的最大 id 递增，不留空洞 → 世代编号永远连续，
# 用户 `raku-pm generations` 看到的就是 1..N 而不是带缺口的一串。
my %tx3 = $g.begin(:label('again'), before => '[]');
is %tx3<id>, '000002', 'discard 掉的 id 被复用（不留空洞）';
$g.finish(%tx3, installed => installed-pair('B', '2.0'));

# ---- prune ----
for 4..5 -> $i {
    my %t = $g.begin(:label("n{$i}"), before => '[]');
    $g.finish(%t, installed => installed-pair("P{$i}", '1'));
}
is $g.list.elems, 4, '累计 4 个世代（000001..000004）';
is $g.current, '000004', '当前世代是最新的';
$g.prune(3);
is $g.list.elems, 3, 'prune(3) 只留 3 个';
is $g.current, '000004', '当前世代永不被裁掉';
is $g.list.map(*<id>).List.raku, ('000002', '000003', '000004').List.raku,
    '留下的是最新的 3 个（id 是零填充十进制，字典序 == 数值序）';
is $g.generation-dir('000003').d, True, 'generation-dir 能定位到某个世代';
nok $g.generation-dir('000001').e, '被裁掉的世代目录真的没了';

done-testing;
