# 回归测试：test-depends 的归一化与携带（与 build-depends 同构）
#
# 验证三件事：
#   1) 顶层 "test-depends"（数组 / Hash 带约束）都能归一成 {模块 => 约束}
#   2) 顶层 test-depends 为空时回退到 META6 分阶段写法 depends.test.requires
#   3) from-meta-file 把派生出的 test-depends 带进 Distribution
# 不涉及网络/安装，纯单元验证归一逻辑（这部分最容易因写法多样而出错）。

use RakuPM::Distribution;
use Test;

# 顶层 test-depends（数组形式：生态主流）
my %meta1 = (
    name => 'Foo', version => '1.0.0', auth => 'zef:x',
    provides => ['Foo'],
    test-depends => ['Test::META'],
);
is-deeply RakuPM::Distribution.test-depends-from(%meta1),
          {'Test::META' => '*'},
          '顶层 test-depends（数组）归一为 {模块 => 约束}';

# 顶层 test-depends（Hash 形式，带约束）
my %meta2 = (
    name => 'Foo', version => '1.0.0', auth => 'zef:x',
    provides => ['Foo'],
    test-depends => {'Test::META' => '0.1+'},
);
is-deeply RakuPM::Distribution.test-depends-from(%meta2),
          {'Test::META' => '0.1+'},
          '顶层 test-depends（Hash 带约束）归一';

# depends.test.requires 分阶段写法（顶层 test-depends 为空数组时回退）
my %meta3 = (
    name => 'Foo', version => '1.0.0', auth => 'zef:x',
    provides => ['Foo'],
    test-depends => [],
    depends => { test => { requires => ['Test::META:ver<0.2+>'] } },
);
is-deeply RakuPM::Distribution.test-depends-from(%meta3),
          {'Test::META' => '0.2+'},
          '顶层 test-depends 为空数组时回退到 depends.test.requires';

# 完全无 test-depends → 空 Hash（不是 Nil / 类型对象）
my %meta4 = ( name => 'Foo', version => '1.0.0', auth => 'zef:x', provides => ['Foo'] );
is-deeply RakuPM::Distribution.test-depends-from(%meta4), {}, '无 test-depends → 空 Hash';

# from-meta-file 把 test-depends 带进 Distribution（手工写 META.json，避免依赖 to-json）
my $tmp = $*TMPDIR.add('raku-pm-test-depends-' ~ $*PID ~ '.json');
spurt $tmp, '{"name":"Foo","version":"1.0.0","auth":"zef:x","provides":["Foo"],"test-depends":["Test::META"]}';
my $dist = RakuPM::Distribution.from-meta-file($tmp);
is-deeply $dist.test-depends, {'Test::META' => '*'}, 'from-meta-file 保留 test-depends';
$tmp.unlink;

# 合并回归：phase-depends-from 必须与旧 build/test-depends-from 完全等价，
# 防止 0.35.0「复制两份归一函数」的纠缠退化重现。
is-deeply RakuPM::Distribution.phase-depends-from(%meta1, 'test'),
          RakuPM::Distribution.test-depends-from(%meta1),
          'phase-depends-from(test) 等价于 test-depends-from';

my %meta-build = (
    name => 'Foo', version => '1.0.0', auth => 'zef:x', provides => ['Foo'],
    build-depends => ['LibraryMake'],
);
is-deeply RakuPM::Distribution.phase-depends-from(%meta-build, 'build'),
          {'LibraryMake' => '*'},
          'phase-depends-from(build) 归一顶层 build-depends';
is-deeply RakuPM::Distribution.phase-depends-from(%meta-build, 'build'),
          RakuPM::Distribution.build-depends-from(%meta-build),
          'phase-depends-from(build) 等价于 build-depends-from';

done-testing;
