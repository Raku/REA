use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Client::Query;

# 外部依赖（zef 的 :from<bin> / :from<Perl5>）—— 不是 Raku 包，不能当模块解析。
# 生态里的真实例子：Doc::TypeGraph 2.x 依赖 graphviz 的 `dot:from<bin>`、
# Documentable 依赖 `node:from<bin>`；以前这些条目会被塞进依赖表，
# 于是安装必然死在“在所有已配置的仓库里都找不到模块 'dot'”。

sub split3(Str $json --> List) {
    RakuPM::Distribution.normalize-dependencies-and-native-libs(from-json($json))
}

# ---------- 1. 外部命令不进 Raku 依赖表 ----------
{
    my ($h, $nat, $ext) = split3(q[ ["dot:from<bin>", "node:from<bin>", "URI"] ]);
    is $h.keys.join(','), 'URI', ':from<bin> 不进 Raku 依赖，普通依赖照常保留';
    is $ext.sort.join(','), 'dot,node', ':from<bin> 收集到 external 列表';
    is $nat.elems, 0, ':from<bin> 不会被误当本地库';
}

# ---------- 2. :from<Perl5> 同样不算 Raku 包 ----------
{
    my ($h, $nat, $ext) = split3(q[ ["POSIX:from<Perl5>"] ]);
    is $h.elems, 0, ':from<Perl5> 不进 Raku 依赖';
    is $ext.join(','), 'POSIX', ':from<Perl5> 收集到 external 列表';
}

# ---------- 3. :from<native> 仍然走本地库通道，不与外部命令混淆 ----------
{
    my ($h, $nat, $ext) = split3(q[ ["ogg:from<native>"] ]);
    is $nat.join(','), 'ogg', ':from<native> 仍进 native-libs';
    is $ext.elems, 0, ':from<native> 不进 external 列表';
    is $h.elems, 0, ':from<native> 不进 Raku 依赖';
}

# ---------- 4. Hash 形式的 from 字段（{"name":..., "from":"bin"}） ----------
{
    my ($h, $nat, $ext) = split3(q[ [ { "name": "cmake", "from": "bin" }, { "name": "Real::Mod" } ] ]);
    is $h.keys.join(','), 'Real::Mod', 'Hash 形态：from=bin 不算 Raku 依赖';
    is $ext.join(','), 'cmake', 'Hash 形态：from=bin 进 external 列表';
}

# ---------- 5. {"any": [...]} 多选一 ----------
{
    my ($h1, $n1, $e1) = split3(q[ [ { "any": ["elinks:from<bin>", "lynx:from<bin>"] } ] ]);
    is $h1.elems, 0, 'any 里全是外部命令 → 不产生 Raku 依赖';
    is $e1.sort.join(','), 'elinks,lynx', 'any 里的外部命令仍被记录下来';

    my ($h2, $n2, $e2) = split3(q[ [ { "any": ["elinks:from<bin>", "Fallback::Mod"] } ] ]);
    is $h2.keys.join(','), 'Fallback::Mod', 'any 里有 Raku 模块时取它作依赖';
}

# ---------- 6. 发行版对象暴露 external-deps ----------
{
    my $dir = $*TMPDIR.add('rakupm-ext-' ~ $*PID ~ '-' ~ now.floor).mkdir;
    LEAVE { try { .unlink } for $dir.dir; try { $dir.rmdir } }
    $dir.add('META6.json').spurt(to-json({
        name => 'Needs::Dot', version => '1.0', auth => 'demo',
        provides => { 'Needs::Dot' => 'lib/Needs/Dot.rakumod' },
        depends => from-json(q[ ["dot:from<bin>", "URI"] ]),
    }, :sorted-keys));

    my $d = RakuPM::Distribution.from-meta6-file($dir.add('META6.json'));
    is $d.external-deps.join(','), 'dot', 'META6 文件解析出 external-deps';
    is $d.depends.keys.join(','), 'URI', 'META6 文件：Raku 依赖不含外部命令';
}

# ---------- 7. Reporter 汇总 + PATH 探测 ----------
{
    my class Probe does RakuPM::Client::Query { }
    my $probe = Probe.new;

    my $d1 = RakuPM::Distribution.new(:name<A>, :version<1>, :depends({}), :external-deps(['dot', 'definitely-not-a-real-command-xyz']));
    my $d2 = RakuPM::Distribution.new(:name<B>, :version<1>, :depends({}), :external-deps(['dot']));
    my @need = $probe.check-external-deps(($d1, $d2));
    is @need.join(','), 'definitely-not-a-real-command-xyz,dot', 'external 依赖去重并排序后汇总';

    # raku 自己一定在 PATH 里（本测试就是它跑的），缺的一定不在
    ok $probe.check-external-deps(($d1, $d2)).elems == 2, '汇总结果条数正确';
}

done-testing;
