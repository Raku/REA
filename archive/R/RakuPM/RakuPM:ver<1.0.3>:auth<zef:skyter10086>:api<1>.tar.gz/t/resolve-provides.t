use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::Repository;
use RakuPM::Resolver;

plan 24;

# 一个内存里的假仓库，用来复现真实生态索引里的畸形数据。
# 行格式：%( name, version, provides(Array), depends(Hash) )
class MemRepo does RakuPM::Repository {
    has @.rows;
    method id(--> Str) { 'mem:test' }
    method find-providers(Str $m --> List) {
        # provides 匹配之外，发行版名与依赖名相同也算提供（fez 案例）
        my @n = self.rows.grep({ $m (elem) @(.<provides>) }).map(*<name>);
        @n.push($m) if self.rows.grep(*<name> eq $m).elems;
        @n.unique.List
    }
    method all-distributions(--> List) { self.rows.map(*<name>).unique.List }
    method available-versions(Str $n --> List) {
        self.rows.grep(*<name> eq $n).map(*<version>).unique.List
    }
    method fetch-distribution(Str $n, Str $v --> RakuPM::Distribution) {
        my $row = self.rows.first({ .<name> eq $n && .<version> eq $v });
        die "假仓库里找不到 $n $v" unless $row;
        RakuPM::Distribution.new:
            :name($row<name>),
            :version($row<version>),
            :provides(@($row<provides>)),
            :depends(RakuPM::Distribution.normalize-dependencies($row<depends> // {}));
    }
    method source-dir-for(Str $, Str $ --> IO::Path) { IO::Path }
}

# 同上，但实现了 versions-providing 的快速路径（直接扫行，不必物化每个版本）。
# MemRepo 走角色里的默认实现，两者结果必须一致，否则说明快路径写错了。
class IndexedRepo is MemRepo {
    method versions-providing(Str $m, Str $n --> List) {
        # 发行版名依赖：dist 名与依赖名相同时全部版本都算提供
        return self.available-versions($n).List if $n eq $m;
        self.rows.grep({ .<name> eq $n && $m (elem) @(.<provides>) })
                 .map(*<version>).unique.List
    }
}

sub resolver-for($cls, @rows) {
    RakuPM::Resolver.new(:repos([$cls.new(:rows(@rows))]))
}

# 统一捕获异常消息，避免 die 打断后续用例
sub resolve-err($cls, @rows, Str $mod, Str $c = '') {
    try { resolver-for($cls, @rows).resolve($mod, $c) }
    $! ?? $!.Str !! ''
}

# ===== 场景数据 =====

# 真实案例：DBIish 0.5.5–0.6.1 曾把 NativeLibs 打在自己包里，0.6.2 之后拆了出去。
# 于是「NativeLibs 这个模块」同时出现在两个发行版的 provides 历史里，
# 但 0.6.8（最高版本）其实根本不含它。
my @drift =
    %( name => 'DBIish',    version => '0.6.8', provides => ['DBIish'],                 depends => {} ),
    %( name => 'DBIish',    version => '0.6.1', provides => ['DBIish', 'NativeLibs'],   depends => {} ),
    %( name => 'NativeLibs',version => '0.0.9', provides => ['NativeLibs'],             depends => {} ),
    %( name => 'NativeLibs',version => '0.0.5', provides => ['NativeLibs'],             depends => {} ),
;

# 两个都提供 Shared，但都没有「正主」名字，只能比版本。
# 字符串比较会得出 "0.9" > "0.10" 的错误结论。
my @shared =
    %( name => 'Alpha', version => '0.9',  provides => ['Shared'], depends => {} ),
    %( name => 'Beta',  version => '0.10', provides => ['Shared'], depends => {} ),
;

# 互相依赖：生态里真实存在（NativeLibs 与它提供的模块之间就出现过）。
# 不该被判成环而整包安装失败。
my @mutual =
    %( name => 'P', version => '1.0', provides => ['P'], depends => { 'Q' => '*' } ),
    %( name => 'Q', version => '1.0', provides => ['Q'], depends => { 'P' => '*' } ),
;

# 自环：发行版自己提供 Helper 又依赖 Helper（拓扑排序里入度永远减不到 0）
my @selfy =
    %( name => 'Selfy', version => '1.0', provides => ['Selfy', 'Helper'],
       depends => { 'Helper' => '*' } ),
;

# 真冲突：Root 要 C>=2.0，D 要 C<2.0，两条路径不可能同时满足
my @conflict =
    %( name => 'Root', version => '1.0', provides => ['Root'],
       depends => { 'C' => '>= 2.0', 'D' => '*' } ),
    %( name => 'D',    version => '1.0', provides => ['D'], depends => { 'C' => '< 2.0' } ),
    %( name => 'C',    version => '2.0', provides => ['C'], depends => {} ),
    %( name => 'C',    version => '1.5', provides => ['C'], depends => {} ),
;

# 依赖顺序：C <- A <- Root，B 独立
my @chain =
    %( name => 'Root', version => '1.0', provides => ['Root'],
       depends => { 'A' => '*', 'B' => '*' } ),
    %( name => 'A', version => '1.0', provides => ['A'], depends => { 'C' => '*' } ),
    %( name => 'B', version => '1.0', provides => ['B'], depends => {} ),
    %( name => 'C', version => '1.0', provides => ['C'], depends => {} ),
;

for (MemRepo, IndexedRepo) -> $cls {
    my $tag = $cls.^name;

    # --- provides 随版本漂移 ---
    my @r1 = resolver-for($cls, @drift).resolve('NativeLibs', '0.0.7+');
    is @r1.map(*.name).join(','), 'NativeLibs',
       "$tag：只挑真正提供该模块的版本（DBIish 0.6.8 被排除）";
    is @r1[0].version, '0.0.9', "$tag：正主发行版胜出";

    my @r2 = resolver-for($cls, @drift).resolve('NativeLibs', '');
    is @r2.map({ .name ~ ':' ~ .version }).join(','), 'NativeLibs:0.0.9',
       "$tag：无约束时也不会被别家的 0.6.8 骗走";

    my @r3 = resolver-for($cls, @drift).resolve('NativeLibs', '0.6+');
    is @r3.map({ .name ~ ':' ~ .version }).join(','), 'DBIish:0.6.1',
       "$tag：正主版本不满足时才退让给其他发行版";

    # --- 版本比较走 semver ---
    my @r4 = resolver-for($cls, @shared).resolve('Shared', '');
    is @r4.map({ .name ~ ':' ~ .version }).join(','), 'Beta:0.10',
       "$tag：0.10 > 0.9（不是字符串比较）";

    # --- 互相依赖 / 自环 ---
    my @r5 = resolver-for($cls, @mutual).resolve('P', '');
    is @r5.map(*.name).sort.join(','), 'P,Q', "$tag：互相依赖不再被判成环";

    my @r6 = resolver-for($cls, @selfy).resolve('Selfy', '');
    is @r6.elems, 1, "$tag：自环不会让包从结果里消失";

    # --- 真冲突仍然报错 ---
    my $msg = resolve-err($cls, @conflict, 'Root');
    ok $msg.contains('依赖冲突'), "$tag：版本冲突仍然报「依赖冲突」";

    # --- 发行版名依赖：依赖名是发行版名而非 provides 里的模块名 ---
    # 真实案例：App::Mi6 依赖 fez:ver<38+>，而 fez 发行版的 provides 里
    # 只有大写的 Fez，没有小写的 fez —— 按【发行版名】匹配才能找到。
    my @distname =
        %( name => 'fez', version => '43', provides => ['Fez'], depends => {} ),
    ;
    my @r7 = resolver-for($cls, @distname).resolve('fez', '38+');
    is @r7.elems, 1, "$tag：发行版名依赖能解析（fez 38+ → fez 43）";
    is @r7[0].name, 'fez', "$tag：命中发行版 fez";
    is @r7[0].version, '43', "$tag：版本满足 38+";

    # --- 拓扑顺序 ---
    my @names = resolver-for($cls, @chain).resolve('Root', '').map(*.name);
    my %pos = @names.antipairs;
    ok %pos<C> < %pos<A> < %pos<Root>, "$tag：依赖先于被依赖者（C<A<Root）";
}
