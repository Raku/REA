use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Repository::Local;
use JSON::Fast;

# 回归：本地目录仓库必须能被 search 搜到。
#
# 背景：Client.search 里是 `next unless $repo.can('search-rows')`，
# 而 search-rows 原先只在 Ecosystem 上实现，Local 没有 → 本地仓库被整个跳过。
# 结果：本地目录仓库里明明有的包，`raku-pm list` 看得到（走 all-distributions），
# `raku-pm search` 却搜不到，两个命令对同一批包给出不一致的答案。
#
# 离线、确定性：只测 Local 仓库对象，不碰网络。

my $base = $*TMPDIR.add("rakupm-search-local-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

# 造本地仓库：一个目录下每个子目录是一个发行版
sub make-dist($dir, :$name, :$version, :$desc, :@provides) {
    $dir.mkdir;
    $dir.add('lib').mkdir;
    for @provides -> $mod {
        my $mod-file = $dir.add("lib/{$mod.subst('::', '/', :g)}.rakumod");
        # 模块名含 :: 时会有中间目录（HTTP::Client → lib/HTTP/Client.rakumod），
        # 父目录得先建好，否则 spurt 会 "No such file or directory"
        $mod-file.parent.mkdir;
        $mod-file.spurt("unit module $mod;\n");
    }
    $dir.add('META6.json').spurt(to-json({
        name => $name, version => $version, auth => 'demo:raku',
        description => $desc, provides => @provides, depends => {},
    }, :sorted-keys));
}

# 注意：发行版目录名（Web-App）与它提供的模块名（Web::App）不同 ——
# 这是本地开发包的常态，也是为什么匹配要看 provides。
make-dist($base.add('HTTP-Client'), :name('HTTP-Client'), :version('1.2.0'),
          :desc('HTTP 客户端'), :provides(['HTTP::Client']));
make-dist($base.add('Web-App'), :name('Web-App'), :version('2.0.0'),
          :desc('Web 应用，依赖 HTTP-Client 和 JSON'), :provides(['Web::App']));

# 仓库根上自己也放一份 META6.json —— 模拟"容器目录 + 单包"两种布局并存
# （比如站在某个源码仓库根目录里，根是它自己、子目录里还有别的包）
$base.add('META6.json').spurt(to-json({
    name => 'SelfDist', version => '3.1.0', auth => 'demo:raku',
    description => '仓库根上的发行版', provides => ['SelfDist'], depends => {},
}, :sorted-keys));

my $repo = RakuPM::Repository::Local.new(:root($base));

plan 11;

# —— 最关键的回归断言：Client.search 就是靠这个 can() 决定要不要跳过本仓库 ——
ok $repo.can('search-rows'),
   'Local 仓库必须实现 search-rows（否则 Client.search 会静默跳过本地仓库）';

# 按发行版名搜
my @r1 = $repo.search-rows('HTTP-Client');
ok @r1.elems >= 1, '按发行版名能搜到本地包';
is @r1.first({ .<name> eq 'HTTP-Client' })<version>, '1.2.0',
   '搜到的版本正确';

# 按模块名搜（provides）—— 目录名与模块名不同时这条才有用
my @r2 = $repo.search-rows('Web::App');
ok @r2.elems >= 1 && @r2.first({ .<name> eq 'Web-App' }).defined,
   '按 provides 的模块名也能搜到（目录名 Web-App / 模块 Web::App）';

# 按描述搜 → 现在应【搜不到】：search 只按模块/发行名匹配，不扫 description
# （'依赖' 只出现在 Web-App 的描述里，名字与提供的模块都不含，故返回空）
my @r3 = $repo.search-rows('依赖');
is @r3.elems, 0, 'search 不按 description 命中（方法名被误匹配的问题已修）';

# 大小写不敏感
ok $repo.search-rows('http-client').elems >= 1, '搜索大小写不敏感';

# 搜不到就是搜不到
is $repo.search-rows('绝对不存在的包名ZZZ').elems, 0, '搜不到时返回空列表';

# 契约：Client.search 会读这 5 个键，缺一个就会显示成空/undefined
my %row = $repo.search-rows('HTTP-Client').first({ .<name> eq 'HTTP-Client' });
is %row.keys.sort.join(','), '_score,auth,description,name,repo,version',
   '返回的记录含 Client.search 需要的全部字段（含相关度 _score）';

# —— 仓库根上自己是发行版（单包布局）也应被收录 ——
# 场景：站在某个包的源码仓库根目录里，local:. 指向这里。
# 以前 Local 只扫子目录，根上的 META6.json 看不见 → search 自己的名字"未找到"
# （RakuPM 没发布到任何生态索引，两层都落空）。
my $single = RakuPM::Repository::Local.new(:root($base));
my @own = $single.all-distributions;
ok @own.first({ $_ eq 'SelfDist' }).defined,
   '仓库根上的 META6.json 也被收录（单包布局）';

my @srow = $single.search-rows('SelfDist');
is @srow.elems, 1, '单包布局下 search 能搜到自己';
is @srow[0]<version>, '3.1.0', '搜到的是根上 META6.json 的版本';

done-testing;
