use v6.d;
use Test;
use JSON::Fast;

use RakuPM::Author;

# bump 的「文档版本示例同步」—— 这是 Issue 10 的本体：
# 过去 bump 只改 META6 + Changes，README 里的 `<name>:ver<旧版>` 示例会与 META6 漂移，
# 而文档纪律门禁恰好要求两者一致，于是每次 bump 后都得手工补，漏了就一提交就红。
#
# 本测试钉死四件事：
#   ① 同步发生（根 README、英文 README、docs/ 子目录都扫到）
#   ② 只替换【恰好等于旧版本】的实例 —— 历史引用（:ver<0.0.9>）必须原样保留
#   ③ --no-sync-docs 关闭
#   ④ --dry 一个字节都不改

plan 14;

my IO::Path $tmp = $*TMPDIR.add("author-bump-docs-{$*PID}-{(now * 1000).Int}");
$tmp.mkdir;

sub mk-dist(Str $name, Str :$readme = '', Str :$readme-en = '', Str :$guide = '' --> IO::Path) {
    my IO::Path $d = $tmp.add("{$name}-dist");
    $d.mkdir;
    $d.add('META6.json').spurt(to-json({
        name     => $name,
        version  => '0.1.0',
        auth     => 'test',
        provides => {},
        depends  => {},
    }, :sorted-keys));
    $d.add('Changes').spurt("# Changes\n\n## 0.1.0 - 2026-01-01\n\n- init\n");
    $d.add('README.md').spurt($readme)       if $readme.chars;
    $d.add('README.en.md').spurt($readme-en) if $readme-en.chars;
    if $guide.chars {
        $d.add('docs').mkdir;
        $d.add('docs').add('guide.md').spurt($guide);
    }
    $d;
}

# ---------------- ① ② 正常 bump：同步 + 不动历史引用 ----------------
{
    my IO::Path $d = mk-dist('Alpha',
        readme    => "# Alpha\n\n是 `Alpha:ver<0.1.0>:auth<test>` 形式的包。\n",
        readme-en => "Alpha is available as `Alpha:ver<0.1.0>`.\n",
        guide     => "旧版 `Alpha:ver<0.0.9>` 起支持 X；当前 `Alpha:ver<0.1.0>`。\n",
    );

    my %r = RakuPM::Author.bump($d);

    is %r<from>, '0.1.0', '① 返回旧版本';
    is %r<to>,   '0.1.1', '① 返回新版本（默认 patch）';

    ok $d.add('META6.json').slurp.contains('"0.1.1"'),
       '① META6.json 版本已递增';

    ok $d.add('README.md').slurp.contains('Alpha:ver<0.1.1>'),
       '① README.md 的版本示例已同步为新版';
    ok $d.add('README.en.md').slurp.contains('Alpha:ver<0.1.1>'),
       '① README.en.md 的版本示例已同步（双语必须一起走）';
    ok $d.add('docs').add('guide.md').slurp.contains('Alpha:ver<0.1.1>'),
       '① docs/ 子目录的 .md 也在扫描范围内';

    ok $d.add('docs').add('guide.md').slurp.contains('Alpha:ver<0.0.9>'),
       '② 历史引用 Alpha:ver<0.0.9> 原样保留（只替换恰好等于旧版本的实例）';

    ok $d.add('README.md').slurp.contains('Alpha:ver<0.1.0>') == False,
       '② 旧版本的示例已被替换掉（不是两份都留）';

    ok $d.add('Changes').slurp.contains('## 0.1.1'),
       '① Changes 顶部加了新版本头';

    is %r<docs>.elems, 3, '① 返回值列出 3 个被同步的文件（两份 README + docs/guide.md）';
}

# ---------------- ③ --no-sync-docs ----------------
{
    my IO::Path $d = mk-dist('Beta',
        readme => "# Beta\n\n`Beta:ver<0.1.0>`\n",
    );
    RakuPM::Author.bump($d, :no-sync-docs);

    ok $d.add('README.md').slurp.contains('Beta:ver<0.1.0>'),
       '③ --no-sync-docs：README 保持旧版本示例（不同步）';
    ok $d.add('META6.json').slurp.contains('"0.1.1"'),
       '③ --no-sync-docs 只关文档同步，版本照样递增';
}

# ---------------- ④ --dry 不落盘 ----------------
{
    my IO::Path $d = mk-dist('Gamma',
        readme => "# Gamma\n\n`Gamma:ver<0.1.0>`\n",
    );
    my $before = $d.add('README.md').slurp;
    RakuPM::Author.bump($d, :dry);

    is $d.add('README.md').slurp, $before, '④ --dry：README 一个字节都没改';
    ok $d.add('META6.json').slurp.contains('"0.1.0"'),
       '④ --dry：META6 版本保持原样';
}

done-testing;
