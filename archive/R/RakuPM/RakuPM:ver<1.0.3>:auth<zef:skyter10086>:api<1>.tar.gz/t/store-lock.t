use Test;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Lock;

# 每个测试用独立临时目录。
# 放 $*TMPDIR 而不是当前工作目录：早先写成 "./_t-store-lock-<PID>"，异常路径下
# END 块清不干净，会在仓库根目录留下 _t-store-lock-* 垃圾（git status 冒出未跟踪
# 文件，还容易被误提交）。系统临时目录由 OS 回收，干净得多。
my $tmp = $*TMPDIR.add("_t-store-lock-{$*PID}");
END { rm-tree($tmp) if $tmp.d }

sub rm-tree(IO::Path $d) {
    for $d.dir -> $e { $e.d ?? rm-tree($e) !! $e.unlink }
    $d.rmdir;
}

plan 16;

my $store = RakuPM::Store.new(:root("$tmp/store".IO));
my $inst  = RakuPM::Installer.new(:target($tmp.IO), :store($store));
my $lock  = RakuPM::Lock.new(:path("$tmp/raku-pm.lock".IO));

sub json-dist($v) {
    RakuPM::Distribution.new(:name("JSON"), :version($v), :auth("demo"), :provides(["JSON"]));
}

# --- Store：多版本共存 ---
$store.put(json-dist("1.0.0"), "repo/JSON".IO);
$store.put(json-dist("2.0.0"), "repo/JSON2".IO);
is-deeply $store.cached-versions("JSON").sort.List, ("1.0.0", "2.0.0"), 'store 多版本共存';

# --- Store：内容指纹校验 ---
ok $store.verify("JSON", "1.0.0"), '未篡改时校验通过';
is $store.digest-of("JSON", "1.0.0").chars, 32, '指纹是 32 位十六进制';

# --- Installer：版本切换 ---
$inst.install(json-dist("1.0.0"));
is $inst.installed-version("JSON"), "1.0.0", '安装 1.0.0 并激活';
$inst.install(json-dist("2.0.0"));
is $inst.installed-version("JSON"), "2.0.0", '切换到 2.0.0';
is $inst.list-installed.elems, 1, '重复安装不产生重复条目（回归 bug）';

# --- Installer：卸载清理 ---
$inst.uninstall("JSON");
is $inst.list-installed.elems, 0, '卸载后无记录';
nok "$tmp/lib/JSON.rakumod".IO.e, '卸载后模块文件被清除';

# --- Lock：生成与读取 ---
my @dists = (json-dist("1.0.0"),);
$lock.write(@dists, :store($store));
ok $lock.exists, '锁文件已生成';
is $lock.locked-version("JSON"), "1.0.0", '锁文件记录精确版本';

# --- Lock：严格模式拦截版本漂移 ---
my @conflict = (json-dist("2.0.0"),);
dies-ok { $lock.enforce(@conflict) }, '锁与实际解析不一致时报错';

# --- Lock：enforce 也拦「锁里没有的包」（--locked 下新增依赖同样算冲突）---
my $newpkg = RakuPM::Distribution.new(:name<NewPkg>, :version("1.0"), :auth<demo>, :provides(["NewPkg"]));
my @missing = (json-dist("1.0.0"), $newpkg);
dies-ok { $lock.enforce(@missing) }, '锁里没有的包在 --locked 下也算冲突';

# --- Lock：ensure-entry 补记但不覆盖已有条目 ---
$lock.ensure-entry($newpkg, :store($store));
is $lock.locked-version("NewPkg"), "1.0", 'ensure-entry 补记新条目';
$lock.ensure-entry(json-dist("2.0.0"), :store($store));
is $lock.locked-version("JSON"), "1.0.0", 'ensure-entry 不覆盖已有条目';

# --- Lock：E 修复（0.37.2）— 版本比较走 semver，不是字符串 ne ---
# 锁里 1.0.0、本次解析 1.0 是同一版本，不应报冲突；
# 旧代码 `ne` 把 "1.0.0" ne "1.0" 当成版本漂移，误报冲突。
my $lock-e = RakuPM::Lock.new(:path("$tmp/raku-pm-e.lock".IO));
$lock-e.write((json-dist("1.0.0"),), :store($store));
is $lock-e.check-against((json-dist("1.0"),)).elems, 0,
   'E: 锁 1.0.0 与解析 1.0 视为同一版本（不误报冲突）';
is $lock-e.check-against((json-dist("1.5.0"),)).elems, 1,
   'E: 锁 1.0.0 与解析 1.5.0 仍报冲突';

done-testing;
