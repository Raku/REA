use lib 'lib';
use Test;

# P1 三个只读命令的回归：outdated / doctor / completions。
# 三者都不写任何东西（不进写锁、不改账本、不改 CUR），纯检查 / 纯输出。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;

sub run-cli(*@args) {
    my $p = run($raku, '-Ilib', $bin, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

my $tmp = $*TMPDIR.add("rakupm-p1-{$*PID}");
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# ---- outdated：空前缀不报错，给出明确结论 ----
{
    my $tgt = $tmp.add('empty').absolute.Str;
    my ($code, $out, $err) = run-cli('outdated', "--target=$tgt");
    is $code, 0, 'outdated 退出码 0';
    my $all = $out ~ $err;
    ok $all.contains('还没有通过 raku-pm 安装任何包')
        || $all.contains('全部已是最新'),
       'outdated 在空前缀下给出明确结论';
}

# ---- doctor：五个小节都出现，退出码 0 ----
{
    my $tgt = $tmp.add('doctor').absolute.Str;
    my ($code, $out, $err) = run-cli('doctor', "--target=$tgt");
    is $code, 0, 'doctor 退出码 0';
    my $all = $out ~ $err;
    for '〔1/7〕RAKULIB', '〔2/7〕PATH', '〔3/7〕残留暂存',
        '〔4/7〕账本', '〔5/7〕运行环境', '〔6/7〕锁文件', '〔7/7〕作者侧凭据', '总评' -> $sec {
        ok $all.contains($sec), "doctor 含小节：$sec";
    }
}

# ---- completions：四种 shell 都生成，且包含新命令 ----
{
    my ($b-code, $b-out, $b-err) = run-cli('completions', 'bash');
    is $b-code, 0, 'completions bash 退出码 0';
    ok ($b-out ~ $b-err).contains('_raku_pm'), 'bash 补全含 _raku_pm 函数';
    ok ($b-out ~ $b-err).contains('outdated')
        && ($b-out ~ $b-err).contains('doctor')
        && ($b-out ~ $b-err).contains('completions'),
       'bash 补全含三个新命令';

    # B1 回归：补全命令清单取自 %CMD_FLAGS 单一事实来源，'update' 此前漏进了
    # %CMD_FLAGS（命令实现了、help 也写了，但补全脚本里没有）。这里钉死它必须出现。
    ok ($b-out ~ $b-err).contains('update'),
       'bash 补全含 update（B1：补全脚本与 %CMD_FLAGS 同一来源）';

    my ($f-code, $f-out, $f-err) = run-cli('completions', 'fish');
    is $f-code, 0, 'completions fish 退出码 0';
    ok ($f-out ~ $f-err).contains('complete -c raku-pm'), 'fish 补全含 complete -c raku-pm';

    my ($z-code, $z-out, $z-err) = run-cli('completions', 'zsh');
    is $z-code, 0, 'completions zsh 退出码 0';
    ok ($z-out ~ $z-err).contains('bashcompinit'), 'zsh 补全含 bashcompinit 引导';

    my ($p-code, $p-out, $p-err) = run-cli('completions', 'pwsh');
    is $p-code, 0, 'completions pwsh 退出码 0';
    ok ($p-out ~ $p-err).contains('Register-ArgumentCompleter'),
       'pwsh 补全含 Register-ArgumentCompleter';
}

# ---- completions：不支持的 shell 报错（不静默） ----
{
    my ($code, $out, $err) = run-cli('completions', 'tcsh');
    isnt $code, 0, 'completions 不支持的 shell 非 0 退出';
    ok ($out ~ $err).contains('不支持的 shell'), '报错说明不支持的 shell';
}

# ---- 命令简写别名：归一化派发到规范命令（端到端） ----
# 别名表是唯一事实来源，这里证明 `raku-pm <别名>` 与 `raku-pm <规范名>` 行为一致。
{
    my $tgt = $tmp.add('alias').absolute.Str;

    # e → env（只读，打印环境赋值）
    my ($e-code, $e-out, $e-err) = run-cli('e', "--target=$tgt");
    is $e-code, 0, '别名 e 退出码 0（= env）';
    ok ($e-out ~ $e-err).contains('RAKULIB')
        || ($e-out ~ $e-err).contains('前缀')
        || ($e-out ~ $e-err).contains('PATH'),
       '别名 e 真的派发到 env（输出环境赋值）';

    # doc → doctor（只读，含「总评」小节）
    my ($d-code, $d-out, $d-err) = run-cli('doc', "--target=$tgt");
    is $d-code, 0, '别名 doc 退出码 0（= doctor）';
    ok ($d-out ~ $d-err).contains('总评'), '别名 doc 真的派发到 doctor';

    # un → uninstall：无位置参数时也必须给出与 uninstall 相同的用法报错
    # （证明别名不是只走「只读」路径，而是完整派发到规范命令的 when 分支）
    my ($u-code, $u-out, $u-err) = run-cli('un', "--target=$tgt");
    isnt $u-code, 0, '别名 un 无参数非 0 退出（= uninstall 的用法校验）';
    ok ($u-out ~ $u-err).contains('请指定要卸载'),
       '别名 un 派发到 uninstall 的报错分支';

    # 补全脚本必须包含别名（i / rm），证明补全清单与别名表同源
    my ($b-code2, $b-out2, $b-err2) = run-cli('completions', 'bash');
    ok ($b-out2 ~ $b-err2).contains(' i ')
        && ($b-out2 ~ $b-err2).contains('rm '),
       'bash 补全含简写别名 i / rm';
}

# ---- A8 回归：upgrade help 强调「不读锁、要可复现用 install --locked」 ----
# 0.78.0 起 help 分级：默认 help 只给紧凑命令索引，upgrade 的详情在 help upgrade 里。
{
    my ($code, $out, $err) = run-cli('help', 'upgrade');
    is $code, 0, 'help upgrade 退出码 0';
    ok ($out ~ $err).contains('要可复现请用 install --locked'),
       'help upgrade 段强调可复现提示（A8）';
}

# ---- A7 回归：help 别名速查表须列出 rdeps / gens（这两个拼写实际可用） ----
{
    my ($code, $out, $err) = run-cli('help');
    is $code, 0, 'help 退出码 0（A7）';
    my $all = $out ~ $err;
    ok $all.contains('rdeps'), 'help 别名表列出 rdeps（= rdepends，A7）';
    ok $all.contains('gens'),  'help 别名表列出 gens（= generations，A7）';
}

done-testing;
