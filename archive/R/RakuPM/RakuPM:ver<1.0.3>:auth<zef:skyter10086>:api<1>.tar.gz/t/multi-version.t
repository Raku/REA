use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;

# 用 done-testing：用例按场景分块，写死数量容易对不上。

# ---------- 临时目录与清理 ----------
# Raku 的 IO::Path 没有 rmtree，自己写递归删除。
# 必须真递归：store/ 下面是 <发行版>/<版本>/lib/... 好几层，
# 只删两层会留下垃圾，zef install 的退出清理就会把整个套件判 FAIL。
sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-multiver-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 造两个版本的同一个发行版，模块里【声明自己的版本号】——
# 这点很关键：只有模块自带 :ver<>，才能验证 Raku 到底加载了哪一份。
sub make-dist(Str $ver, IO::Path $dir) {
    $dir.mkdir;
    my $lib = $dir.add('lib');
    $lib.mkdir;
    # 用单引号拼接而不是双引号内插：模块源码里本身就有双引号，
    # 写进双引号字符串要到处转义，容易把 Raku 解析器搞晕。
    $lib.add('MultiVer.rakumod').spurt(
        'unit module MultiVer:ver<' ~ $ver ~ '>;' ~ "\n" ~
        'sub who() is export { "我是 ' ~ $ver ~ '" }' ~ "\n");
    $dir.add('META6.json').spurt(to-json({
        name     => 'MultiVer',
        version  => $ver,
        auth     => 'demo:test',
        provides => { 'MultiVer' => 'lib/MultiVer.rakumod' },
        depends  => {},
    }, :sorted-keys));
    RakuPM::Distribution.from-meta6-file($dir.add('META6.json'));
}

my $target = $tmp.add('target');
my $store  = RakuPM::Store.new(:root($tmp.add('store')));
my $inst   = RakuPM::Installer.new(:target($target), :store($store));

my $src11 = $tmp.add('src-1.1.0');
my $src20 = $tmp.add('src-2.0.0');
my $d11 = make-dist('1.1.0', $src11);
my $d20 = make-dist('2.0.0', $src20);

# ===== 1. store 里要同时有标准 META.json 与 Raku 的 META6.json =====
$store.put($d11, $src11);
$store.put($d20, $src20);

is $store.cached-versions('MultiVer').sort.join(','), '1.1.0,2.0.0',
   'store 里两个版本共存';

my $dir11 = $store.path-for('MultiVer', '1.1.0');
ok $dir11.add('META.json').e,  'store 写了 raku-pm 的 META.json';
ok $dir11.add('META6.json').e, 'store 也写了 Raku 标准的 META6.json';

# META6.json 的 provides 必须是「模块名 => 相对路径」，
# 而 RakuPM::Distribution.provides 只有模块名，路径是靠扫 lib/ 反推的
my %m6 = from-json($dir11.add('META6.json').slurp);
is %m6<provides><MultiVer>, 'lib/MultiVer.rakumod',
   'META6.json 的 provides 是 模块名=>相对路径（由 lib/ 反推）';
ok %m6<provides><MultiVer>.contains('/'),
   '路径用正斜杠（Windows 的反斜杠会让 Distribution::Path 拼错）';
is %m6<name>, 'MultiVer', 'META6.json 记了发行版名';
is %m6<version>, '1.1.0',  'META6.json 记了版本';

# 指纹必须覆盖 META6.json：否则改了元数据也验不出来
ok $store.verify('MultiVer', '1.1.0'), '加了 META6.json 后指纹校验仍通过';

# provides 里写了但文件不存在的模块，不该写进 META6.json
# （写进去会让 Distribution::Path 收文件时炸）
{
    my $ghost = $tmp.add('src-ghost');
    $ghost.add('lib').mkdir;
    $ghost.add('lib').add('Real.rakumod').spurt('unit module Real;');
    my $d = RakuPM::Distribution.new(
        :name('Ghost::Pkg'), :version('1.0'), :auth('demo'),
        :provides(['Real', 'Ghost::Missing']), :depends({}));
    $store.put($d, $ghost);
    my %g = from-json($store.path-for('Ghost::Pkg','1.0').add('META6.json').slurp);
    ok %g<provides><Real>:exists,        '真实存在的模块进了 provides';
    nok %g<provides><Ghost::Missing>:exists, '文件不存在的模块被跳过';
}

# ===== 2. 安装两个版本，两个都要可用 =====
$inst.install($d11);
$inst.install($d20);

is $inst.installed-versions('MultiVer').join(','), '1.1.0,2.0.0',
   '两个版本都记为已安装';
is $inst.installed-version('MultiVer'), '2.0.0',
   'installed-version 取最高的那个';
is $inst.list-installed.elems, 1,
   '同一发行版的多版本只占一条记录';

# 安装目录用的是 CUR::Installation（site），不是平铺的 lib/
ok $inst.repo-prefix.d, '存在 CUR::Installation 的 prefix 目录';
ok $inst.raku-lib-spec.starts-with('inst#'),
   'RAKULIB 条目带 inst# 前缀（少了它读不到版本元数据）';

# ===== 3. 核心：真的能按版本挑到对应的那份 =====
# 用子进程跑 raku，模拟用户实际的 `use MultiVer:ver<...>`。
# 模块自己声明了 :ver<>，所以 who() 报出来的就是被加载的那一份。
sub loaded-version(Str $spec --> Str) {
    my $proc = run('raku', '-I', $inst.raku-lib-spec, '-e',
                   "use MultiVer$spec; print who()", :out, :err);
    return '' if $proc.exitcode != 0;
    $proc.out.slurp(:close).trim
}

is loaded-version(':ver<1.1.0>'), '我是 1.1.0',
   'use :ver<1.1.0> 真的拿到 1.1.0（关键：不是被激活的 2.0.0）';
is loaded-version(':ver<2.0.0>'), '我是 2.0.0',
   'use :ver<2.0.0> 拿到 2.0.0';
is loaded-version(''),            '我是 2.0.0',
   '不指定版本时拿到最高的那个';
is loaded-version(':ver<1.1+>'),  '我是 2.0.0',
   '范围约束 :ver<1.1+> 匹配到 2.0.0';
is loaded-version(':ver<1.0+>'),  '我是 2.0.0',
   '范围约束 :ver<1.0+> 匹配到 2.0.0';

# 装了 1.1.0 和 2.0.0，要 1.5.0 必须报错——绝不能静默给个错的版本
{
    my $proc = run('raku', '-I', $inst.raku-lib-spec, '-e',
                   'use MultiVer:ver<1.5.0>; say who()', :out, :err);
    nok $proc.exitcode == 0, '要一个没装的版本会失败';
    ok ($proc.err.slurp(:close) // '').contains('Could not find'),
       '且报的是「找不到」，而不是加载了别的版本';
}

# ===== 3.5 按版本卸载：只清掉指定版本，其余保留 =====
# 多版本共存下的常见需求：只想清掉某个出问题的版本，而不是把整个包连根拔起。
# 账本也要同步 —— versions 里去掉那一个，version（激活）回落到剩余里最高的。
{
    is $inst.installed-versions('MultiVer').sort.join(','), '1.1.0,2.0.0',
       '按版本卸载前：1.1.0 与 2.0.0 都在';

    $inst.uninstall('MultiVer', :version('2.0.0'));

    is $inst.installed-versions('MultiVer').join(','), '1.1.0',
       '按版本卸载：2.0.0 被清掉，1.1.0 保留';
    is $inst.installed-version('MultiVer'), '1.1.0',
       '激活版本回落到剩余里最高的 1.1.0';
    is $inst.list-installed.elems, 1,
       '账本条目仍在（整包没被连根拔起）';
    # 关键行为验证：卸掉最高版本后，无约束的 use 会改加载剩下那个 ——
    # 这正是「降级必须卸掉更高版本」的原因（见 upgrade 的 --only）。
    is loaded-version(''), '我是 1.1.0',
       '卸掉最高的 2.0.0 后，无约束 use 改加载 1.1.0';
}

# ===== 4. 卸载：整个发行版（所有版本）一起摘掉 =====
# 接着上一节 —— 此时只剩 1.1.0。不给 version 就是整包清空。
$inst.uninstall('MultiVer');
is $inst.list-installed.elems, 0, '不给 version：整包卸载后账本为空';
is $inst.installed-versions('MultiVer').elems, 0, '整包卸载后查不到任何版本';

# 卸载后 Raku 也不该再找得到
{
    my $proc = run('raku', '-I', $inst.raku-lib-spec, '-e',
                   'use MultiVer; say who()', :out, :err);
    nok $proc.exitcode == 0, '卸载后 use 该模块会失败';
}

# ===== 5. 老账本兼容：只有 version 字段、没有 versions 数组 =====
{
    my $legacy = $target.add('installed.json');
    # 注意：不能写 `[ %( ... ) ]` 或 `[ %rec ]` —— `[ ]` 会把哈希展平成
    # 一堆单键哈希。必须用 `(%rec,)` 尾逗号写法（与 Resolver.resolve 里同一个坑）。
    my %rec = %( name => 'Old', version => '3.1.4',
                 auth => 'demo', provides => ['Old'], digest => '' );
    $legacy.spurt(to-json((%rec,), :sorted-keys));
    is $inst.installed-versions('Old').join(','), '3.1.4',
       '老账本（无 versions 字段）也能读出版本';
    is $inst.installed-version('Old'), '3.1.4', '老账本的 installed-version 正常';
}

done-testing;
