# 回归测试：Windows 平台「已知上游测试失败」识别（Log::Async 12-context）
#
# raku-pm 在 Windows 上会把这个已知上游 bug 自动软通过（见 Tester.!run-tests），
# 不让它阻断安装。这里验证识别函数本身够窄、不会误伤：
#   · 只认具体「包名 + 测试文件 + 失败特征 + Windows」
#   · 非 Windows 平台恒为 False（识别函数内部已按 is-windows() 门控）
#   · 通用失败（语法错误等）永不被识别
#
# 关键：失败输出来自上游 is-deeply 的 diag，Raku 测试框架会把反斜杠转义成 \\（双
# 反斜杠）。识别函数必须先还原再匹配；夹具必须用【真实双反斜杠】形态，否则会像
# 0.36.16 那样「测试通过但线上漏匹配」，导致该软通过的没软通过、安装被无辜回滚
# （实测：真实输出是 C:\\Users\\...\\lib\\Log\\Async.rakumod，单反斜杠匹配永远 False）。

use RakuPM::Client::Tester;
use RakuPM::Platform;
use Test;

# 真实形态：上游测试 is-deeply 的 diag 把反斜杠转义成 \\（双反斜杠）。
# q:to 是非插值 heredoc，源里的 \\ 即字符串里的两个反斜杠，正好对应线上输出。
my $la-output = q:to/OUT/;
# expected: $["file t\12-context.rakutest, line 18, message yàsu"]
#      got: $["file C:\\Users\\user\\.raku-pm\\cache\\dist\\zef\\Log-Async\\0.0.17\\Log-Async-0.0.17\\lib\\Log\\Async.rakumod (Log::Async), line 81, message yàsu"]
OUT

# 在 Windows 上识别为已知失败；其它平台恒 False（sub 内部已用 is-windows() 门控，
# 故期望值也必须用同一个谓词——不能写 $*DISTRO.is-win，否则在 name='win32' 的
# Windows 上 is-win 为 False 而 is-windows() 为 True，测试会假红，导致该软通过的
# 没软通过、安装被无辜回滚，见 0.36.17 那次线上事故）。
is is-known-windows-test-failure('Log::Async', '12-context.rakutest', $la-output),
   is-windows(),
   'Log::Async 12-context 的 Windows 失败特征被正确识别（真实双反斜杠形态，仅 Windows）';

# 兼容性：理想单反斜杠形态也应识别（防未来有人把夹具改回单反斜杠时漏测）
my $la-output-single = q:to/OUT/;
# expected: $["file t\12-context.rakutest, line 18, message yàsu"]
#      got: $["file C:\Users\user\.raku-pm\cache\dist\zef\Log-Async\0.0.17\Log-Async-0.0.17\lib\Log\Async.rakumod (Log::Async), line 81, message yàsu"]
OUT
is is-known-windows-test-failure('Log::Async', '12-context.rakutest', $la-output-single),
   is-windows(),
   'Log::Async 12-context（理想单反斜杠形态）也能识别';

# 不匹配的测试文件 → 永远 False
is is-known-windows-test-failure('Log::Async', '99-meta.rakutest', $la-output),
   False,
   '非 12-context 测试文件不识别';

# 不匹配的包名 → 永远 False
is is-known-windows-test-failure('Foo::Bar', '12-context.rakutest', $la-output),
   False,
   '非 Log::Async 包不识别';

# 通用失败（语法错误）→ 永远 False（不会被静默掩盖）
is is-known-windows-test-failure('Log::Async', '12-context.rakutest',
   "===SORRY=== Error while compiling: syntax error"),
   False,
   '通用语法错误不识别为已知失败';

done-testing;
