use v6;
# mock-curl.raku —— 测试用的「假 curl」可执行桩，由 t/mock-curl.bat 调起。
#
# 为什么需要它：本环境（Rakudo/Windows）的 IO::Socket::INET :listen 会抛
# "Invalid port (Int)"、IO::Socket::Async 在第 3 个连接数据 Supply 不触发——
# 两种本地 mock 上传服务器都起不来。而真实 curl 上行会被环境代理劫持（502）。
# 于是改为【替换 curl 二进制】来验证真实生产代码路径（RakuPM::HTTP.post-form /
# upload-multipart / RakuPM::Author.login / publish --remote）构造出的 wire 契约：
#   · 解析与 post-form 完全一致的参数（-o / -F / -H / URL）；
#   · 把「请求」重建为可读文本写入 RAKUPM_MOCK_CAPTURE（字段名 / 文件名 / 文件内容 / 头）；
#   · 把假响应体写入 -o 文件（/login 回 {"key":"fakekey123"}，其余回 ok）；
#   · 仅向 stdout 打印 200（模拟 curl -w '%{http_code}' 的输出，供 post-form 解析）。
# 完全离线、确定性、无 socket、无代理依赖。
#
# 诊断输出：任何异常 / 收到的原始参数都写到 RAKUPM_MOCK_LOGDIR（测试显式指向临时目录）
# 下的 mock-curl-exc.txt / mock-curl-args.txt，不污染 t/、也不依赖 $?FILE 解析。

# 日志目录（保持 IO::Path：只用 .IO / .parent，绝不 .absolute —— 本环境 Rakudo 的
# IO::Path.absolute 返回 Str 而非 IO::Path，对它再 .add 会抛「No such method 'add'
# for string」，让整个 mock 在启动期崩溃）。优先 RAKUPM_MOCK_LOGDIR（测试显式指定到 t/）；
# 回退捕获文件所在目录；再回退脚本目录。最终要字符串时再 .add(...).absolute.Str。
my $log-dir = do {
    if %*ENV<RAKUPM_MOCK_LOGDIR>:exists && %*ENV<RAKUPM_MOCK_LOGDIR>.defined {
        %*ENV<RAKUPM_MOCK_LOGDIR>.IO
    }
    elsif %*ENV<RAKUPM_MOCK_CAPTURE>:exists && %*ENV<RAKUPM_MOCK_CAPTURE>.defined {
        %*ENV<RAKUPM_MOCK_CAPTURE>.IO.parent
    }
    else {
        $?FILE.IO.parent
    }
};
my $exc-f  = $log-dir.add('mock-curl-exc.txt').absolute.Str;
my $args-f = $log-dir.add('mock-curl-args.txt').absolute.Str;

sub log-args() {
    my $fh = open($args-f, :a);
    $fh.say("ARGS[" ~ @*ARGS.elems ~ "]:");
    $fh.say("  [$_.raku]") for @*ARGS;
    $fh.close;
}

sub die-log(Str $msg, $bt?) {
    my $fh = open($exc-f, :a);
    $fh.say("=== " ~ now.Str ~ " ===");
    $fh.say("MSG: " ~ $msg);
    $fh.say("BT: " ~ ($bt ?? $bt.Str !! '(none)'));
    $fh.say("ARGS: " ~ @*ARGS.map({.raku}).join(' '));
    $fh.close;
}

log-args;

try {
    my @a = @*ARGS;
    my $body-out;
    my @fields;
    my @json-body;
    my @headers;
    my $url;
    my $i = 0;
    my @trace;
    while $i < @a.elems {
        my $x = @a[$i];
        if $x eq '-o'      { $body-out = @a[$i+1]; $i += 2; @trace.push("o:$body-out") }
        elsif $x eq '-F'   { @fields.push(@a[$i+1]); $i += 2; @trace.push("F:@fields[*-1]") }
        elsif $x eq '-d'   { @json-body.push(@a[$i+1]); $i += 2; @trace.push("D:[@json-body[*-1]]") }
        elsif $x eq '-H'   { @headers.push(@a[$i+1]); $i += 2; @trace.push("H:@headers[*-1]") }
        elsif $x eq '-w'   { $i += 2 }
        elsif $x eq '-S' | $x eq '-s' { $i += 1 }
        else               { $url = $x unless $x ~~ / ^ '-' /; $i += 1 }
    }

    my $cap = "URL: {$url // ''}\n";
    $cap ~= "HEADERS:\n";
    $cap ~= "  $_\n" for @headers;
    $cap ~= "FIELDS:\n";
    for @fields -> $f {
        if $f ~~ / ^ (.+?) '=@' (.+) $ / {
            my $nm = ~$0;
            my $pth = ~$1;
            # 本环境 Rakudo 的 IO::Path.basename 在 Windows 路径上返回整串，不可靠；
            # 手动取最后一段（最后一个 / 或 \ 之后的部分）。
            my $fn = $pth ~~ / <[\\/]> (<-[\\/]>+) $ / ?? ~$0 !! $pth;
            # 上传文件可能是二进制 sdist（真实 tar.gz）——按 :bin 读回再 latin-1 解码，
            # 避免默认 UTF-8 解码对二进制内容抛「Malformed UTF-8」（仅 A 的纯文本样本能过，
            # C 的真实 tar.gz 会炸）。latin-1 逐字节可逆，且对纯 ASCII 文本等价。
            my $ct = do {
                if $pth.IO.e {
                    my $b = $pth.IO.slurp(:bin);
                    try $b.decode('utf-8') // $b.decode('latin-1')
                }
                else {
                    '(missing file)'
                }
            };
            $cap ~= "  name=\"$nm\" filename=\"$fn\" content=[$ct]\n";
        }
        else {
            my ($n, $v) = $f.split('=', 2);
            $cap ~= "  name=\"$n\" value=\"$v\"\n";
        }
    }
    # JSON POST 体（-d，login 专用；服务端 42.zef.pm/login 的 from-body 只认
    # application/json）。原样记录，供测试断言 username/password 在 JSON 体中。
    if @json-body.elems {
        $cap ~= "JSON-BODY:\n";
        $cap ~= "  $_\n" for @json-body;
    }

    my $capfile = %*ENV<RAKUPM_MOCK_CAPTURE> // ($log-dir.add('mock-cap.txt').absolute.Str);
    my $cfh = open($capfile, :a);
    $cfh.print("===CALL url=[$url]===\n" ~ $cap ~ "===END===\n");
    $cfh.close;

    my $resp = ($url // '') ~~ / 'login' / ?? '{"key":"fakekey123"}' !! 'ok';
    if $body-out.defined && $body-out.chars {
        spurt $body-out, $resp;
    }
    print '200';

    CATCH {
        default {
            die-log("EXCEPTION: " ~ .message, .backtrace);
            exit 1;
        }
    }
}
