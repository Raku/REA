use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Store;
use RakuPM::Distribution;
use RakuPM::MD5;
use JSON::Fast;

# 回归：Store.verify 必须容忍 store 目录里被 Rakudo 重新生成的 .precomp，
# 否则「装同一版本第二次」会被误报「内容已被修改」而安装失败。
# 这是 v0.27.3 修的真 bug：用户 `raku-pm install .` 重装同名版本被拦死，
# 而 Windows PowerShell 下因时序不同偶发能过。
#
# 指纹只覆盖源码（lib/META），不算 .precomp 这类派生产物；真篡改（改了
# lib 内容）仍应判 False。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try $p.rmdir }
    else    { try $p.unlink }
}

my $tmp = $*TMPDIR.add('rakupm-store-verify-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $src = $tmp.add('src').mkdir;
$src.add('lib').mkdir;
$src.add('lib/Foo.rakumod').spurt(q:to/EOF/);
    unit module Foo;
    our $v = 1;
    EOF
$src.add('META6.json').spurt(q:to/EOF/);
    { "name": "Foo", "version": "0.1.0", "auth": "git:local",
      "provides": { "Foo": "lib/Foo.rakumod" } }
    EOF

my $store = RakuPM::Store.new(:root($tmp.add('store')));
my $dist  = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));

plan 9;

$store.put($dist, $src);
ok $store.verify('Foo', '0.1.0'), '初次入库后 verify 通过';

# 模拟「包被加载后 Rakudo 在 store 里生成 .precomp」
my $dir = $store.path-for('Foo', '0.1.0');
$dir.add('.precomp').mkdir;
$dir.add('.precomp/x.precomp').spurt('bytecode');
ok $store.verify('Foo', '0.1.0'),
   'store 里有了 .precomp 后 verify 仍通过（不误报篡改）';

# 真篡改：改了源码内容
$dir.add('lib/Foo.rakumod').spurt(q:to/EOF2/);
    unit module Foo;
    our $v = 2;
    EOF2
nok $store.verify('Foo', '0.1.0'), '篡改源码内容 → verify 判 False';

# 删掉 .digest 视为不可校验
$dir.add('.digest').unlink;
nok $store.verify('Foo', '0.1.0'), '缺少 .digest → verify 判 False';

# =========================================================================
# 校验清单旁车 .files.json（0.85.0）
#
# 动机：内容校验要逐文件算 MD5，而纯 Raku MD5 只有 ~0.16 MB/s（store 实测 296 个
# 文件 10.7s；并行/多进程都无效 —— 8 线程仅 1.18x）。所以给每个条目存一份
# (size, mtime, md5) 清单，size+mtime 未变的文件下次直接复用 md5。
# 下面用一个【独立条目】把三件事钉死：① 清单确实落盘且可解析；② 命中清单时
# 确实复用了旧 md5（**连同它的取舍一起明示**：这种「改了内容但保持 size+mtime」
# 的改动查不出来）；③ 逃生门 RAKUPM_VERIFY_NOCACHE=1 能强制回到全量哈希。
# =========================================================================
my $src2 = $tmp.add('src2').mkdir;
$src2.add('lib').mkdir;
$src2.add('lib/Bar.rakumod').spurt("unit module Bar;\nour \$v = 1;\n");
$src2.add('META6.json').spurt(q:to/EOF3/);
    { "name": "Bar", "version": "0.1.0", "auth": "git:local",
      "provides": { "Bar": "lib/Bar.rakumod" } }
    EOF3
my $dist2 = RakuPM::Distribution.from-meta6-file($src2.add('META6.json'));
$store.put($dist2, $src2);
ok $store.verify('Bar', '0.1.0'), '新条目（独立场景）入库后 verify 通过';

my $bdir = $store.path-for('Bar', '0.1.0');
my $mf   = $bdir.add('.files.json');
ok $mf.e, '入库即生成校验清单旁车 .files.json';
ok ((try from-json($mf.slurp)) ~~ Hash && (try from-json($mf.slurp)<v>) == 1),
   '清单可解析且带格式版本号';

{
    my $f2 = $bdir.add('lib/Bar.rakumod');
    my $orig-md5 = md5-file($f2);            # 与 .digest 里记录的一致
    $f2.spurt("unit module Bar;\nour \$v = 2;\n");   # 改内容，size 保持相同
    # 伪造清单：size/mtime 取【当前】值、md5 仍是旧的 → 命中 → 复用旧 md5
    my %m = (from-json($mf.slurp)<files>);
    my $key = %m.keys.first(*.ends-with('Bar.rakumod'));
    %m{$key} = [$f2.s, $f2.modified.Num, $orig-md5];
    $mf.spurt(to-json({ v => 1, files => %m }, :sorted-keys));

    ok $store.verify('Bar', '0.1.0'),
       '清单命中（size+mtime 未变）→ 复用上次 md5、判「完好」——这是换速度的取舍';

    {
        temp %*ENV<RAKUPM_VERIFY_NOCACHE> = '1';
        nok $store.verify('Bar', '0.1.0'),
            'RAKUPM_VERIFY_NOCACHE=1 强制全量哈希 → 同一状态被正确判为「已修改」';
    }
}
