use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Installer::ShellTemplates;

# RakuPM::Installer::ShellTemplates 是 0.43.0 从 Installer 里提出来的纯字符串函数：
# 三段平台 shell 模板（bash / Windows .bat / PowerShell .ps1）不再埋在安装逻辑里。
#
# 这些模板是**用户可见契约**（wrapper 长什么样、设什么环境变量），历史上为它们 debug 过
# 好几轮（GNU vs BSD sort、cmd 的二次解析、PATHEXT、RAKUPM_RAKU 兜底），所以要用结构断言
# 钉住。改模板必须同时更新这些断言 —— 那条「改分支就要有人为触发该分支的测试」的规则。

# 0.78.0 起 bash wrapper 的入口写死为【安装时已知的版本路径】；写死路径不在时才
# 退回探测最新版本目录。给一个真实存在的入口路径，断言写死 + fallback 两段都在。
my $entry = '/tgt/store/RakuPM/1.2.3/bin/raku-pm.raku';
my $bash = bash-wrapper-body('/tgt', '/tgt/store/RakuPM', '/tgt/site', '/opt/raku/bin/raku', $entry);

ok $bash.starts-with('#!/usr/bin/env bash'), 'bash：以 shebang 开头（否则 exec 不了）';
nok $bash.contains("\r"), 'bash：必须是 LF（带 CR 会让 Unix 上的 exec 失败）';
ok $bash.contains("/tgt/store/RakuPM"), 'bash：内嵌 store 绝对路径（不靠符号链接解析）';
ok $bash.contains('export RAKULIB="inst#/tgt/site"'),
    'bash：设 RAKULIB 且带 inst# 前缀（少了它 Rakudo 读不出多版本元数据）';
ok $bash.contains("SRC='{$entry}'"),
    'bash：入口写死为安装时的版本（0.78.0 起免掉每次调用 ls|sort -V 的外部进程开销）';
ok $bash.contains('if [ ! -f "$SRC" ]'),
    'bash：写死入口不在时才退回探测最新版本（fallback）';
ok $bash.contains('sort -V'), 'bash：fallback 里优先用 GNU sort -V 挑最新版本';
ok $bash.contains('sort | tail -1'), 'bash：fallback 里 BSD sort 没有 -V 时退回字典序';
ok $bash.contains('command -v raku'), 'bash：优先用 PATH 上的 raku（跟系统更新走）';
ok $bash.contains("/opt/raku/bin/raku"),
    'bash：PATH 找不到 raku 时兜底到安装时的绝对路径（zef install 场景实测 exit 127）';
# 0.49.0：三段模板都必须把前缀显式传给 CLI —— 否则 CLI 回落到默认前缀，
# 而 wrapper 设的 RAKULIB 指向自己那份 site（命令装进 A、模块从 B 找）。
# 用 q{} 而不是 %Q{}：断言串里含 `$SRC`，双引号系会当场把它插值掉（写测试踩过）。
ok $bash.contains(q{exec raku "$SRC" '--target=/tgt'}),
    'bash：显式把前缀传给 CLI（--target），wrapper 属于哪个前缀就动哪个前缀';

my $bat = win-bat-body('1.2.3', 'C:/tgt', 'C:/tgt/site', 'C:/raku/bin/raku.exe',
                       'C:/tgt/store/RakuPM/1.2.3/bin/raku-pm.raku');

ok $bat.contains("\r\n"), '.bat：用 CRLF（cmd 的传统行尾）';
ok $bat.contains('set "RAKULIB=inst#C:/tgt/site"'), '.bat：设 RAKULIB';
ok $bat.contains('1.2.3'), '.bat：注释里带生成时的版本号';
ok $bat.contains('C:/tgt/store/RakuPM/1.2.3/bin/raku-pm.raku'),
    '.bat：入口写死绝对路径（cmd 没有 semver sort，做不到运行时挑最新）';
ok $bat.contains('if errorlevel 1'), '.bat：有 fallback 分支（raku 不在 PATH 时用绝对路径）';
ok $bat.contains('rem 不要在前面探测'),
    '.bat：注释明确禁止在前面用 where 探测（where 不认 Git Bash 的 /c/... 路径，会误判找不到）';
ok $bat.contains('"--target=C:/tgt"'),
    '.bat：显式传前缀（整段加双引号，带空格的路径才传得完整）';

my $ps1 = win-ps1-body('1.2.3', 'C:/tgt', 'C:/tgt/site', 'C:/raku/bin/raku.exe',
                       'C:/tgt/store/RakuPM/1.2.3/bin/raku-pm.raku');

ok $ps1.contains("\r\n"), '.ps1：CRLF（仅为与 .bat 对齐，PowerShell 本身不挑）';
ok $ps1.contains("\$env:RAKULIB = 'inst#C:/tgt/site'"), '.ps1：设 RAKULIB';
ok $ps1.contains('@args'), '.ps1：用 @args 传参（绕开 cmd 的二次解析）';
ok $ps1.contains('try {'), '.ps1：有 try 块';
ok $ps1.contains('Win32Exception'),
    '.ps1：捕获 Win32Exception —— raku 不在 PATH 时 & 抛的就是它';
ok $ps1.contains("'--target=C:/tgt'"),
    '.ps1：显式传前缀（单引号串，不做插值）';

done-testing;
