use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::MD5;

# 内置 MD5 的正确性：RFC 1321 官方测试向量。
# Store 的内容指纹全靠它，算错一个位所有 store 条目的指纹就全变了
# （老条目 verify 会集体失败）—— 所以向量必须钉死在这里。

my @vectors = (
    '',                              'd41d8cd98f00b204e9800998ecf8427e',
    'a',                             '0cc175b9c0f1b6a831c399e269772661',
    'abc',                           '900150983cd24fb0d6963f7d28e17f72',
    'message digest',                'f96b697d7cb7938d525a2f31aaf161d0',
    'abcdefghijklmnopqrstuvwxyz',    'c3fcd3d76192e4007dfb496cca67e13b',
    '1234567890' x 8,                '57edf4a22be3c955ac49da2e2107b67a',
);

for @vectors -> $input, $expect {
    is md5-hex($input), $expect,
       "RFC 1321 向量：「{$input.chars > 20 ?? $input.substr(0,20) ~ '…' !! $input}」";
}

# Blob 入口（Store 实际用的形态）
is md5-hex('abc'.encode('utf-8')), '900150983cd24fb0d6963f7d28e17f72',
   'Blob 入口与 Str 入口结果一致';

# 多块消息（>64 字节，覆盖跨块处理与长度字段的 64 位小端）
is md5-hex('raku-pm' x 40), md5-hex('raku-pm' x 40), '同输入两次结果稳定';

# ---- 原生路径（NativeCall 绑 libcrypto）与纯 Raku 必须逐位一致（0.86.0）----
#
# CPU 密集的 MD5 交给系统原生实现：同一批 store 文件（296 个 / 2.1 MB）实测
# 0.246s vs 纯 Raku 10.97s —— 而并行/多进程都救不了纯 Raku（8 线程仅 1.18x）。
# 原生库不是每台机器都有（Linux 上常常只有带版本的 libcrypto.so.3、macOS 是系统的
# libcrypto.dylib、Windows 看有没有 libcrypto.dll），所以有探测 + 纯 Raku 回退。
# 这里【不】断言「必须有原生」（那会让没装库的机器假红），而是钉住三件事：
#   ① 探测结果是个 Bool 且不抛错；
#   ② 原生可用时，其结果与纯 Raku 逐位一致（否则 store 指纹会随平台变化）；
#   ③ RAKUPM_MD5=raku 能强制走纯 Raku（对照 / 排障）。
{
    ok native-md5-available() ~~ Bool, 'native-md5-available 返回 Bool（不抛错）';

    my @samples = '', 'a', 'abc', 'message digest', 'raku-pm' x 40, '中文内容 · 测试';
    for @samples -> $s {
        my Str $native = md5-hex($s);
        my Str $raku   = do { temp %*ENV<RAKUPM_MD5> = 'raku'; md5-hex($s) };
        my Str $label  = $s.chars == 0 ?? '（空串）'
                       !! ($s.chars > 16 ?? $s.substr(0, 16) ~ '…' !! $s);
        is $native, $raku, "原生与纯 Raku 结果一致：{$label}";
    }
}

done-testing;
