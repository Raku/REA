use lib $*PROGRAM.parent.parent.add('lib');
use Test;
use JSON::Fast;
use RakuPM::Repository::Ecosystem;
use RakuPM::HTTP::Backend;   # 导出 RakuPM::HTTP::ConditionalResponse

# search-rows / find-providers 必须自加载索引（0.36.12 修的「raku-pm search 查不到」）。
# 用 FakeHTTP 直接喂一个迷你索引：不触网、不依赖本地 ~/.raku-pm 缓存、可移植。
#
# 复现路径：之前 search 子命令走 Reporter.search → $repo.search-rows，但 search-rows
# 没有像 !rows 那样 `self.refresh unless $!loaded`，而 install 那条路在 Repositories
# 开头统一 refresh 过，所以 install 能命中、search 永远扑空（即使远程索引里明明有）。

class FakeHTTP
{
    has Str $.body;
    method get-text(Str $ --> Str) { $!body }
    method get-text-conditional(Str $, Str :$if-none-match = ''
                                --> RakuPM::HTTP::ConditionalResponse) {
        RakuPM::HTTP::ConditionalResponse.new(:status(200), :body($!body))
    }
    method download(Str $, IO::Path $ --> Nil) { }
}

my @rows = (
    %( name => 'Terminal::Spinners', version => '0.1.0',
       auth => 'cpan:foo', description => 'terminal spinners for raku' ),
    %( name => 'JSON::Fast', version => '0.19',
       auth => 'zef:x', description => 'fast json for raku' ),
);
my $idx = to-json(@rows);

my $tmp = $*SPEC.tmpdir.add('rakupm-search-test-' ~ $*PID);
$tmp.mkdir;
END { try $tmp.rmdir }

my $eco = RakuPM::Repository::Ecosystem.new(
    :index-url('https://example.com/cpan1.json'),
    :cache-root($tmp),
    :http(FakeHTTP.new(:body($idx))),
);

plan 5;

# 1) 按发行名命中（第一调用会触发自加载）
my @found = $eco.search-rows('Terminal::Spinners');
ok @found.elems == 1 && @found[0]<name> eq 'Terminal::Spinners',
   'search-rows 按发行名找到 Terminal::Spinners（自加载索引）';

# 2) 大小写不敏感（contains 匹配，仍走已加载的索引）
my @lc = $eco.search-rows('terminal::spinners');
ok @lc.elems == 1, 'search-rows 大小写不敏感';

# 3) 按【发行名子串】命中（'json' 出现在 'JSON::Fast' 名字里），不误伤其它包
my @desc = $eco.search-rows('json');
ok @desc.elems == 1 && @desc[0]<name> eq 'JSON::Fast',
   'search-rows 按发行名子串命中 JSON::Fast';

# 4) 描述专属关键词不再命中 —— search 只按模块/发行名匹配，不扫 description
#    （两个包的描述都含 'raku'，但名字都不含，故应返回空，避免方法名被误匹配）
my @desc-only = $eco.search-rows('raku');
is @desc-only.elems, 0, 'search-rows 不按 description 命中（太广问题已修）';

# 5) find-providers 同样自加载（按「发行名」写法依赖也能解析）
my @prov = $eco.find-providers('Terminal::Spinners');
ok @prov.elems == 1 && @prov[0] eq 'Terminal::Spinners',
   'find-providers 自加载索引后按发行名反向命中';
