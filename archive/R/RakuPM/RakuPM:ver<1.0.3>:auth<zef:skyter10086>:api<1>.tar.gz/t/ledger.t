use lib 'lib';
use Test;
use RakuPM::Ledger;

# RakuPM::Ledger 是账本（installed.json）的唯一读写入口 —— 它现在承载
# 「格式、排序、损坏报错、序列化选项」的单一真相，所以值得有自己的单测。
#
# 重点覆盖三件容易出错的事：
#   1) 版本排序必须走 semver（字典序会把 0.9.2 判成高于 0.13.0）；
#   2) modify 是 upsert、modify-existing 只改已存在条目（不能凭空造记录）；
#   3) 损坏账本给单条清晰报错，而不是把底层栈甩给用户。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add("rakupm-ledger-{$*PID}");
rmrf($tmp);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $path = $tmp.add('installed.json');
my $led = RakuPM::Ledger.new(:$path);

# ---- 空账本 ----
nok $led.exists, '未写入前 exists 为假';
is $led.entries.elems, 0, '不存在时 entries 返回空';
is $led.installed-versions('Nothing').elems, 0, '未装过的包版本列表为空';
is $led.installed-version('Nothing'), Str, '未装过的包激活版本是 Str 空值';
is $led.recorded-git-sha('Nothing', '1.0'), '', '未装过的包提交号为空串';

# ---- modify 是 upsert ----
$led.modify('Foo', -> %e { %e<version> = '1.0'; %e<versions> = ['1.0']; });
is $led.entries.elems, 1, 'modify 在条目不存在时新建';
is $led.installed-version('Foo'), '1.0', '新建条目的激活版本正确';

$led.modify('Foo', -> %e { %e<versions> = ['1.0', '2.0']; %e<version> = '2.0'; });
is $led.entries.elems, 1, 'modify 对已存在条目是就地更新（不新增）';
is $led.installed-version('Foo'), '2.0', '更新后激活版本跟着变';

$led.modify('Bar', -> %e { %e<version> = '0.1'; });
is $led.entries.elems, 2, '第二个包被追加';

# ---- modify-existing：只改已存在条目 ----
my $created = $led.modify-existing('NoSuchPkg', -> %e { %e<version> = '9.9' });
nok $created, 'modify-existing 对不存在的条目返回 False';
is $led.entries.elems, 2, 'modify-existing 不会凭空造出条目';
my $touched = $led.modify-existing('Foo', -> %e { %e<reason> = 'explicit' });
ok $touched, 'modify-existing 对已存在条目返回 True';
is $led.entries.first({ $_<name> eq 'Foo' })<reason>, 'explicit',
   'modify-existing 的修改已落盘';

# ---- 版本排序必须 semver ----
$led.modify('Multi', -> %e { %e<version> = '0.13.0'; %e<versions> = ['0.9.2', '0.13.0']; });
is $led.installed-versions('Multi').raku, ('0.9.2', '0.13.0').List.raku,
   'installed-versions 按 semver 升序（0.9.2 在 0.13.0 之前）';
is $led.installed-version('Multi'), '0.13.0',
   'installed-version 取 semver 最高（不是字典序最高 0.9.2）';
is $led.versions-of(%( name => 'X', version => '0.9.2', versions => ['0.9.2', '0.13.0'] )).raku,
   ('0.9.2', '0.13.0').List.raku,
   'versions-of(%entry) 同样走 semver 排序';

# ---- 老格式兼容：只有 version 字段、没有 versions 数组 ----
is $led.versions-of(%( name => 'Old', version => '1.5' )).raku, ('1.5',).List.raku,
   'versions-of 兼容只有 version 字段的老条目';

# ---- git 提交号往返 ----
$led.modify('GitPkg', -> %e { %e<version> = '1.0'; });
$led.set-git-sha('GitPkg', '1.0', 'abc1234');
is $led.recorded-git-sha('GitPkg', '1.0'), 'abc1234', 'git 提交号可写可读';

# ---- remove：按版本 / 整包 ----
$led.modify('Multi2', -> %e { %e<version> = '2.0'; %e<versions> = ['1.0', '2.0'] });
$led.remove('Multi2', :version('1.0'));
is $led.installed-versions('Multi2').raku, ('2.0',).List.raku,
   'remove(:version) 只去掉指定版本';
is $led.installed-version('Multi2'), '2.0', '去掉低版本后激活版本仍是 2.0';

$led.remove('Multi2', :version('2.0'));
is $led.entries.grep({ ($_<name> // '') eq 'Multi2' }).elems, 0,
   '版本全被去掉后整条移除';

$led.remove('Foo');
is $led.entries.grep({ ($_<name> // '') eq 'Foo' }).elems, 0, 'remove 无版本参数时整包移除';
ok $led.entries.grep({ ($_<name> // '') eq 'Bar' }).elems == 1, 'remove 不误伤别的包';

# ---- 序列化：:sorted-keys（键有序，保证 diff 稳定） ----
is $path.slurp.lines[1].trim.substr(0, 1), '{', '账本落盘是 JSON 对象行';
ok $path.slurp.contains('"reason"') || $path.slurp.contains('"version"'),
   '落盘内容含预期字段';

# ---- 损坏账本：单条清晰报错，不抛底层栈 ----
my $bad = $tmp.add('bad.json');
$bad.spurt('{ this is not json');
my $bl = RakuPM::Ledger.new(:path($bad));
my $msg = '';
try { $bl.entries };
$msg = $!.Str if $!;
ok $msg.contains('解析失败'), '损坏账本报「解析失败」（可读）';
ok $msg.contains($bad.Str), '报错里带上账本路径（便于定位）';

# ---- 主键由账本保证：调用方只改业务字段也不该写坏条目 ----
$led.modify('KeyPkg', -> %e { %e<version> = '1.0' });   # 刻意【不】设 name
is $led.entries.first({ ($_<name> // '') eq 'KeyPkg' }).<version>, '1.0',
   'modify 自动写死主键 name（调用方漏设也不会写出无主键条目）';
$led.modify('KeyPkg', -> %e { %e<version> = '2.0' });
is $led.entries.grep({ ($_<name> // '') eq 'KeyPkg' }).elems, 1,
   '再次 modify 同名校验为主键命中，不产生重影条目';

done-testing;
