use lib 'lib';
use Test;
use RakuPM::NativeLib;

# 回归：runtime-native-libs 必须只认【代码里】的 is native('...')，
# 不能把模块自身文档注释或 POD 里的 `is native('foo')` / `is native('duckdb')`
# / `is native('...')` 样板当成真实依赖（raku-pm 自身曾因此 self-upgrade
# 误报缺 duckdb/foo/... 而放弃安装）。
#
# 覆盖两种文档形态：
#   · # 行注释（含行尾注释）
#   · Raku POD：=begin/=end 定界块 与 =for 缩写块（到空行结束）
#
# 【第二组夹具】heredoc / 多行字符串里的 `=` 行首内容：
# heredoc 的正文是【字符串】，但逐行扫描器看不出 —— 正文里以 `=` 开头的行
# （内嵌 Markdown / 配置片段很常见）会被误判成 POD 缩写块，而缩写块按 Raku
# 规则要到【空行】才结束，于是紧随其后的真实 `is native(...)` 声明会被一起
# 吞掉（漏报真实依赖 → 不报缺库 → 安装照跑 → 运行期才以 Slip(Empty) 崩）。
# 这组夹具刻意【不留空行】，正是上述漏报的最小复现。

plan 12;

my $dir = ($*TMPDIR // '/tmp'.IO).add("rakupm-native-scan-{now.to-posix[0].Int}");
$dir.mkdir;

# 跨平台递归删除（IO::Path 没有 rmtree 方法）
sub rm-tree(IO::Path $p) {
    return unless $p.e;
    if $p.d { rm-tree($_) for $p.dir }
    $p.d ?? $p.rmdir !! $p.unlink;
}
LEAVE rm-tree($dir) if $dir.e;

my $lib = $dir.add('lib/Fake/Native');
$lib.mkdir;
# 用单引号 heredoc，避免 # 与 $ 被插值
$lib.add('Native.rakumod').spurt(q:to/EOF/);
unit module Fake::Native;

# 文档注释里的样板：is native('foo') / is native('duckdb') / is native('...')
# 这些只是说明，扫描器必须忽略。

sub real_version(--> int64) is native('zzz-real') { * }   # 行尾注释 is native('commented-out')

method m() is native('another-real') { * }

=begin pod

=head1 运行时原生库示例

下面只是文档里的样例，扫描器必须忽略：

    sub libfoo_version(--> int64) is native('pod-foo') { * }
    sub libduckdb_query() is native('pod-duckdb') { * }
    sub ellipsis() is native('...') { * }

=end pod

=for example
    # 又一段 POD 缩写块里的样例
    method x() is native('pod-bar') { * }

# POD 之后回到代码：这个真实声明必须被识别（证明 POD 状态已正确复位）
sub after_pod(--> int64) is native('after-real') { * }
EOF

my $nl = RakuPM::NativeLib.new;
my @got = $nl.runtime-native-libs($dir);

ok @got.grep('zzz-real'),      '真实声明（注释前）被识别：zzz-real';
ok @got.grep('another-real'),  '真实声明（独立行）被识别：another-real';
ok @got.grep('after-real'),    'POD 之后的真实声明仍被识别：after-real（状态复位）';
nok @got.grep('foo'),          '注释里的 is native(\'foo\') 样板被忽略';
nok @got.grep('duckdb'),       '注释里的 is native(\'duckdb\') 样板被忽略';
nok @got.grep('...'),          '注释里的 is native(\'...\') 样板被忽略';
nok @got.grep('commented-out'), '行尾注释里的样板被忽略：commented-out';
nok @got.grep('pod-foo'),      'POD =begin 块里的样例被忽略：pod-foo';
nok @got.grep('pod-duckdb'),   'POD =begin 块里的样例被忽略：pod-duckdb';
nok @got.grep('pod-bar'),      'POD =for 缩写块里的样例被忽略：pod-bar';

# ---- 第二组：heredoc 正文里的 `=` 行首内容不得污染 POD 状态 ----
$lib.add('Heredoc.rakumod').spurt(q:to/EOF2/);
unit module Fake::Native::Heredoc;

# 内嵌一段文档到字符串里（正文含以 = 开头的行），紧随其后【不留空行】写真实声明
my $doc = q:to/ENDDOC/;
=head1 Usage
is native('heredoc-fake')
ENDDOC
sub real_after_heredoc(--> int64) is native('heredoc-real') { * }
EOF2

my @got2 = RakuPM::NativeLib.new.runtime-native-libs($dir);
ok @got2.grep('heredoc-real'),
   'heredoc 之后（无空行）的真实声明仍被识别：heredoc-real';
nok @got2.grep('heredoc-fake'),
   'heredoc 正文里的 is native(...) 样板被忽略：heredoc-fake';
