# RakuPM::Installer — 把 store 里的包「激活」到 Raku 能找到的地方
#
# 【为什么不是简单地往 lib/ 里复制文件】
# Raku 的 `use Foo:ver<1.2.3>` 是要按版本挑模块的，而一个平铺的
# `target/lib/*.rakumod` 目录**没有任何版本元数据**——Raku 的
# CompUnit::Repository::FileSystem 只能从文件路径推出模块名，推不出版本，
# 于是 `:ver<>` 约束会被无条件满足：
#
#     lib/ 里是 2.0.0，写 `use MultiVer:ver<1.1.0>` 会【静默加载 2.0.0】。
#
# 这是最糟的一类失败——不报错，只是给你错的版本。
#
# 正确做法是用 Raku 官方的 **CompUnit::Repository::Installation**
# （也就是 zef 装包用的那套机制，site / home / vendor 都是它）：
#   · 它按「发行版」存元数据，同一模块的多个版本可以并存；
#   · `use Foo:ver<1.1.0>` 由 Rakudo 自己解析，挑不到就报错；
#   · 预编译（.precomp）由它管理，不用我们自己调 raku -M；
#   · 卸载有原生支持。
#
# 所以「安装」= 把 store 里的发行版交给 CUR::Installation 装进
# `$RAKUPM_TARGET/site/`；raku-pm 自己的 installed.json 只作账本用。

use RakuPM::InstallOptions;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Version;
use RakuPM::Fs;
use RakuPM::Ledger;
use RakuPM::Platform;
use RakuPM::Installer::ShellTemplates;
use RakuPM::Installer::Generations;
use JSON::Fast;

unit class RakuPM::Installer;

has IO::Path $.target is required;       # 安装根目录，如 ~/.raku-pm
has RakuPM::Store $.store is required;   # 包存储
has Bool $.promote-bin = False;          # 装完把 wrapper 复制进 rakudo site/bin
                                         # （zef 同款：site/bin 在 PATH 上，装完即用）。
                                         # 默认关：库调用方（测试/嵌入）不该动系统目录，
                                         # 只有 CLI（bin/raku-pm.raku）显式开启。
has $!cur;                               # CompUnit::Repository::Installation（惰性创建）
has $!ledger;                            # RakuPM::Ledger（installed.json 的唯一读写入口，惰性创建）
                                         # 原先账本读写逻辑在本类与 Client/Cleaner 三处各写一遍
                                         # （6 个样板块），格式演进要同步 6 处 —— 收敛见 Ledger 注释。
has $!gens;                              # RakuPM::Installer::Generations（<target>/generations/ 的读写）

# ---- P6：原子安装 + 世代回滚 ----
# 事务是可嵌套的：install-chain 里装 git 依赖时会递归回到 install-chain，
# 只有最外层那一次真正开世代 / 提交 / 回滚。
has Int  $!tx-depth = 0;     # 嵌套深度（>1 表示内层复用外层事务）
has      %!tx;               # 当前事务：{ id, dir, label, before(账本快照) }
has      @!tx-installed;     # 本次事务装进 CUR 的 { name, version }
has      @!tx-bins;          # 本次事务新建的 bin 文件（回滚时删掉）

# ---- 整树事务化：单一整树暂存 CUR（target/stage/pending）----
# 安装链期间，所有包先装进这一个【共享】暂存 CUR，测试也在这里跑；
# 整条链全过之后，才由 promote-pending 原子晋升到真实 CUR（target/site）。
# 这样：① 测试失败 / 进程中断时，真实 CUR 与账本【自始未被触碰】，无需逐个回滚；
#        ② 晋升只在「全部通过」后发生，天然全有或全无。
has $!pending;          # 暂存 CUR（惰性创建）
has Str $!pending-spec; # 暂存 CUR 的 inst# 前缀串
has @!pending;          # 暂存清单：%( dist => RakuPM::Distribution, source => Str )

# ============ 对外接口 ============

# Raku 侧的仓库目录，也是用户要加进 RAKULIB 的那个路径
method repo-prefix(--> IO::Path) { $!target.add('site') }

# 用户要把这个串加进 RAKULIB 才能 use 到装好的包。
# `inst#` 前缀是必须的：它告诉 Rakudo「按 Installation 仓库解析这个目录」，
# 否则会被当成普通文件仓库，多版本元数据就读不出来了。
#
# 用户要把这个串加进 RAKULIB 才能 use 到装好的包。它【始终只返回真实 CUR】——
# 整树事务化期间也不例外：构建 / 测试子进程需要的「暂存 CUR」由独立的
# pending-lib-spec 另给，绝不与本串拼接（Rakudo 不会把含空格的 -I 参数拆成两条
# 包含路径，0.60.0 修复：早先空格拼接导致暂存 CUR 从未生效）。standalone 的
# `raku-pm build / test .` 不开启事务，pending 未激活，pending-lib-spec 返回空串。
method raku-lib-spec(--> Str) {
    'inst#' ~ self.repo-prefix.absolute
}

# 整树事务化期间（pending CUR 已激活）返回【暂存 CUR 的 inst# 前缀】，
# 否则空串。Builder 与 Tester 把它作为【独立 -I】注入子进程——构建 / 测试
# 期间，新装进暂存的依赖（尚未晋升到真实 CUR）才能被解析到，且本包（native
# 包）的 %?RESOURCES 也只在从 CUR 加载时才被填充。
method pending-lib-spec(--> Str) { $!pending-spec // '' }

# zef 同款 bin 目录：仓库链上 basename 为 site 的 Installation 仓库的 bin/。
# zef 装包时把 bin wrapper 放进 <rakudo>/share/perl6/site/bin/ —— 这个目录在
# rakudo 安装时就进了用户的 PATH，所以 zef 装完命令立即能用。我们也把
# wrapper 复制一份过去，达成同款效果。找不到 site 仓库时返回空。
# :$chain 可注入（测试用）；生产路径不传，走进程仓库链。
method site-bin-dir(:$chain = $*REPO.repo-chain --> IO::Path) {
    for @$chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        my $prefix = (try { $repo.prefix.absolute }) // '';
        next unless $prefix.chars;
        my $io = $prefix.IO;
        return $io.add('bin') if $io.basename eq 'site';
    }
    # 兜底：第一个 Installation 仓库的 bin（如没有名为 site 的）
    for @$chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        my $prefix = (try { $repo.prefix.absolute }) // '';
        return $prefix.IO.add('bin') if $prefix.chars;
    }
    IO::Path.new('')
}

# 「全局 site/bin」= 仓库链上 basename 为 site、且**不是 raku-pm 自己那个 site** 的
# 安装仓库的 bin/。这才是真正天然在用户 PATH 上的目录（rakudo 安装时就加好了），
# 也是 wrapper 要打进去的地方。
#
# 为什么不直接用 site-bin-dir：后者取「链上第一个 basename 为 site 的仓库」，而
# raku-pm 自己的 `~/.raku-pm/site` 也叫 site。于是通过 raku-pm 的 wrapper 启动
# （RAKULIB=inst#<target>/site，链首就是它）时，promote 会把 wrapper 写进
# `~/.raku-pm/site/bin` —— 那个目录**不在 PATH 上**，用户永远敲不到（0.48.0 修正；
# 此前只有从 .exe 启动、链上没有 raku-pm 的 site 时才会落到正确的全局 site/bin，
# 所以这个偏差一直没被注意）。
method global-site-bin-dir(:$chain = $*REPO.repo-chain --> IO::Path) {
    my &key = -> $p { $p.Str.subst('\\', '/', :g).lc };
    my $own = key($!target.add('site').absolute);
    for @$chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        my $prefix = (try { $repo.prefix.absolute }) // '';
        next unless $prefix.Str.chars;
        next if key($prefix) eq $own;                 # 排除 raku-pm 自己的 site
        return $prefix.IO.add('bin') if $prefix.IO.basename eq 'site';
    }
    IO::Path.new('')
}

# 从 store 激活某个包到 CUR::Installation。
# :source 记录包的来源目录（本地目录/git clone 的那份）—— 账本里带上它，
# `raku-pm installed` 才能告诉用户「这个包的源码在哪」，重装/修改有迹可循。
method install(RakuPM::Distribution $dist, Str :$source = '',
               Str :$reason = 'dependency' --> Nil) {
    # 校验 store 中确有该版本且内容完整
    die "store 中没有 {$dist.name} {$dist.version}" unless $!store.has($dist.name, $dist.version);
    unless $!store.verify($dist.name, $dist.version) {
        die "完整性校验失败：{$dist.name} {$dist.version} 内容已被修改";
    }

    my $dir  = $!store.path-for($dist.name, $dist.version);
    my $meta = $dir.add('META6.json');
    die "{$dist.name} {$dist.version} 缺少 META6.json（老版本 store，请重新入库）" unless $meta.e;

    # Distribution::Path 会自己按 META6.json 里的 provides 把 lib/ 下的文件收进来
    my $d6 = Distribution::Path.new($dir, :meta-file($meta));
    # :force —— 重复安装同一版本时覆盖，而不是抛「已安装」。
    # :precompile(False) —— 关键：CUR::Installation.install 的预编译只把【目标
    # CUR 自身】当加载上下文，不含 rakudo core 仓库。native 包 `use NativeCall`
    # 在预编译期就因 core 不在链上而「Could not find NativeCall」崩溃，导致
    # 整个安装失败。跳过安装期预编译，让模块在用户首次 `use` 时（那时 core
    # 在 $*REPO 链上）再懒预编译 —— 与 zef 装 native 包同源机理（zef 把目标
    # CUR 注册进仓库链，所以它能预编译；这里退一步用懒预编译，效果等价）。
    # 同版本重装前先摘掉 CUR 里的旧条目。
    # 理由（用户的 GDBM 现场）：上一次安装可能留下「sources/<hash> 还在、
    # dist/<id> 却没了」的半截条目。这时 use 会解析到那份旧源码，而
    # %?RESOURCES 指向已不存在的 site/dist/<id> → 报 "Failed to open file
    # .../site/dist/<id>"。install(:force) 并不总能覆盖干净这种残缺状态，
    # 所以显式先摘后装，保证这一版是干净写进去的（同版本，不影响多版本共存）。
    for self!repo.installed.grep({
            (.meta<name> // '') eq $dist.name && (.meta<version> // '') eq $dist.version
    }) -> $old {
        try self!repo.uninstall($old);
    }

    self!repo.install($d6, :force, :precompile(False));

    # P6：事务开着就把这次装进去的 (name, version) 记下来 —— 回滚时按这张清单
    # 从 CUR 摘掉。CUR 支持多版本并存，所以摘掉新版本不会动到旧版本。
    @!tx-installed.push(%( name => $dist.name, version => $dist.version )) if $!tx-depth;

    # bin 字段（CUR::Installation 不处理它，zef 也是另起一个 ExtractBin 服务）
    self!install-bin($dir);

    self!record($dist, :$source, :$reason);

    # H10：装完主动读 build.json，把「构建没跑成功 / 被 --no-build 跳过 / 缺资源」
    # 这类事后才暴露、运行期才崩的问题，在【安装时就提示】出来（不再等到 verify）。
    # 同一份事实走 !build-issues-for（与 consistency-issues 共用），纯警告不中断。
    for self!build-issues-for($dist.name, $dist.version) -> %iss {
        note "  ⚠ 构建痕迹：{%iss<detail>}";
    }
}

# 把某个包标记为「用户点名要的」（explicit）。依赖回收永远不会动它。
# 自底向上的安装顺序里，@order 最后一个就是本次的目标包（依赖在前），
# 所以 Client 在链跑完后拿它来标 explicit。
method mark-explicit(Str $name --> Nil) {
    return unless self!ledger.exists;
    my $cur = self!ledger.entries.first({ ($_<name> // '') eq $name });
    # 只改已存在的条目；已是 explicit 就不写（避免无谓落盘 / mtime 变动）
    return unless $cur.defined;
    return if ($cur<reason> // '') eq 'explicit';
    self!ledger.modify-existing($name, -> %e { %e<reason> = 'explicit' });
}

# ============ 整树事务化：暂存 CUR 与原子晋升 ============
#
# 【旧每包独立暂存已收敛进本路径（0.60.1）】
# 早先的 per-package 暂存（Installer.stage / cleanup-stage / purge-cur-entry，
# 各自在 target/stage/<name>-<ver> 建一个独立 CUR）已全部删除：
#   · 它们的职责已被 install-pending（写整树共享暂存 CUR target/stage/pending）
#     + pending-cur-spec（+ raku-lib-spec / pending-lib-spec 注入子进程 -I）
#     完整覆盖；
#   · 清理由 cleanup-stage-all（成功晋升后）与 discard-pending（失败路径）统一
#     负责，不再有「逐包删自己那个暂存目录」的散落逻辑；
#   · 同版本重装的去旧逻辑改由 install-pending 内部对暂存 CUR 做 uninstall、
#     以及 install() 对真实 CUR 做 uninstall 承担，purge-cur-entry（针对真实
#     site 的整份摘除）已无调用方。
# 详见下方「整树事务化：暂存 CUR 与原子晋升」一节。

# 设计（区别于 0.59.0 的逐包即时激活）：安装链期间所有包只进「整树暂存 CUR」
# target/stage/pending，测试也在那里跑；整条链全过之后，promote-pending 才把
# 它们逐个正式 install 到真实 CUR + 账本 + bin。好处：
#   · 失败 / 进程中断 → 真实 CUR 与 installed.json 自始未被触碰，只需丢弃暂存，
#     无需逐个回滚（0.59.0 的失败路径因缺 cleanup-stage-all 直接崩、且从不回滚）。
#   · 晋升只在「全部通过」后发生，天然全有或全无（P6 原子语义的真正落地）。

# 当前事务嵌套深度（0 = 没有打开的事务）。Client 用它判断自己是「最外层」还是
# 「内层复用」，从而决定晋升 / 清理只由最外层执行一次。
method transaction-depth(--> Int) { $!tx-depth }

# 整树暂存 CUR 的 inst# 前缀串，惰性创建该 CUR。安装链上第一个 install-pending
# 之前就可能需要它（测试 @inc 要引用），所以这里确保目录与 CUR 已就绪；
# 每次安装开新暂存（先清空旧目录，避免上一轮 / 上次崩溃留下的半截 CUR 干扰）。
method pending-cur-spec(--> Str) {
    unless $!pending-spec.defined {
        my $dir = $!target.add('stage').add('pending');
        try rm-tree($dir);
        mkdir-p($dir);
        $!pending = CompUnit::Repository::Installation.new(prefix => $dir.absolute);
        $!pending-spec = 'inst#' ~ $dir.absolute;
    }
    $!pending-spec
}

# 把包装进【整树暂存 CUR】，不写账本、不装 bin、不进 @!tx-installed（晋升时才做）。
# 整条链测试通过后才由 promote-pending 晋升到真实 CUR。同一 (name,version) 只
# 暂存一次（跨嵌套子链去重，避免重复晋升）。
method install-pending(RakuPM::Distribution $dist, Str :$source = '' --> Nil) {
    return unless $!store.has($dist.name, $dist.version);
    my $key = "{$dist.name}\0{$dist.version}";
    return if @!pending.first({ "{.<dist>.name}\0{.<dist>.version}" eq $key });
    my $dir  = $!store.path-for($dist.name, $dist.version);
    my $meta = $dir.add('META6.json');
    return unless $meta.e;
    # 确保暂存 CUR 已创建（顺便拿到 $!pending）
    my $cur = self.pending-cur-spec;
    # 同版本重暂存前先摘掉暂存 CUR 里的旧条目（--force 重装场景）
    for $!pending.installed.grep({
            (.meta<name> // '') eq $dist.name && (.meta<version> // '') eq $dist.version
    }) -> $old {
        try $!pending.uninstall($old);
    }
    my $d6 = Distribution::Path.new($dir, :meta-file($meta));
    $!pending.install($d6, :force, :precompile(False));
    @!pending.push(%( dist => $dist, source => $source ));
}

# 原子晋升：把整树暂存里的所有包，逐个用正式 install 落到真实 CUR + 账本 + bin。
# 只在「整条链测试全过」后由最外层事务调用一次。若中途失败，调用方会触发
# rollback-transaction 把已写入真实 CUR 的部分摘掉（install 会记 @!tx-installed）。
method promote-pending(--> Nil) {
    return unless @!pending.elems;
    for @!pending -> %e {
        self.install(%e<dist>, :source(%e<source> // ''));
    }
    @!pending = ();
}

# 清空整个 target/stage/（含整树暂存 CUR pending 与历史遗留的 per-package 暂存），
# 并复位暂存状态。成功晋升后、以及任何失败路径都会调用——保证暂存目录不论
# 成败都被清干净（0.59.0 漏定义此方法，失败路径会先因「找不到方法」崩溃，且从未
# 真正回滚；0.60.0 与整树事务化一并补上）。
method cleanup-stage-all(--> Nil) {
    self!reset-pending;
    try rm-tree($!target.add('stage'));
}

# 仅丢弃整树暂存 CUR（失败路径用）：真实 CUR 自始未动，只需把 pending 删掉。
method discard-pending(--> Nil) {
    self!reset-pending;
    try rm-tree($!target.add('stage').add('pending'));
}

method !reset-pending(--> Nil) {
    $!pending      = Nil;
    $!pending-spec = Str;
    @!pending      = ();
}

# 注：递归删除 / 复制 / 遍历已统一到 RakuPM::Fs（原先本类私有一份，
# 与 Store / Cleaner / SelfManager 各写一遍 —— 跳过规则与异常兜底各不相同，
# 且惰性 `for $d.dir` 会在 Windows 上持住目录句柄让后续 rmdir 失败）。

# ============ P6：原子安装 + 世代回滚 ============
#
# 借鉴 Nix 的「原子世代」：一次 install 要么完全生效、要么完全不生效；
# 每次成功落地都留一个世代（installed.json 的快照 + 本次装了什么），
# 随时可以 `raku-pm rollback` 退回上一世代。
#
# 【为什么用「账本快照」而不是拷贝整个 site】
# CUR::Installation 天然支持多版本并存：装新版本不会抹掉旧版本。所以
# 「回滚」= 把本次装进去的版本从 CUR 摘掉 + 把账本恢复成事务前那份 ——
# 旧版本本来就还在 CUR 里，不需要从别处搬回来。世代因此只是一份几 KB 的
# JSON，不用复制几百 MB 的 site/。这是 Raku 的 CUR 设计送的便宜。
#
# 【边界（诚实声明）】
#   · build / test 阶段发生在源码目录，不碰 target，本来就是原子的；
#     本事务保护的是「激活进 target CUR + 写账本 + 放 bin」这一段。
#   · 同版本 --force 重装被回滚时，CUR 里那份会被摘掉，此时若 store 里还有
#     该版本会重新装回（见 rollback-transaction 末尾的补齐）。

method generations-dir(--> IO::Path) { self!gens.dir }

# 开事务（可嵌套）。返回事务哈希。
method begin-transaction(Str :$label = 'install' --> Hash) {
    $!tx-depth++;
    return %!tx if $!tx-depth > 1;      # 内层：复用外层事务

    @!tx-installed = ();
    @!tx-bins      = ();
    # before.json 由 Generations.begin 落盘（它同时也把快照放进返回的事务哈希）。
    my $ledger = $!target.add('installed.json');
    %!tx = self!gens.begin(:$label,
                           before => ($ledger.e ?? $ledger.slurp !! '[]'));
    %!tx
}

# 提交：把「提交后」的账本存成这个世代的 manifest，设为当前世代，裁剪老的。
method commit-transaction(--> Nil) {
    return unless $!tx-depth;
    $!tx-depth--;
    return if $!tx-depth > 0;           # 内层：等最外层一起提交

    my %tx = %!tx;
    return unless %tx<id>.defined;

    # 本次其实没装任何东西（全是「已安装，跳过」）→ 不留世代，
    # 否则 `raku-pm install` 反复敲会刷出一堆内容相同的空世代。
    if @!tx-installed.elems == 0 {
        self!gens.discard(%tx);
        %!tx = (); @!tx-installed = (); @!tx-bins = ();
        return;
    }

    my $ledger = $!target.add('installed.json');
    self!gens.finish(%tx,
        ledger-json => ($ledger.e ?? $ledger.slurp !! '[]'),
        installed   => @!tx-installed.List);

    %!tx = (); @!tx-installed = (); @!tx-bins = ();
}

# 回滚：把 target 恢复成事务开始前的样子。
method rollback-transaction(--> Nil) {
    return unless $!tx-depth;
    $!tx-depth = 0;                     # 一旦回滚就是整条链作废
    my %tx = %!tx;
    return unless %tx<id>.defined;

    note "⚠ 安装未全部成功，正在回滚到本次操作前的状态…";

    # 1) 删掉本次新建的 bin
    for @!tx-bins -> $p { try $p.IO.unlink if $p.IO.e }
    # 2) 从 CUR 摘掉本次装进去的版本（旧版本仍在 CUR 里，不受影响）
    for @!tx-installed.reverse -> %d {
        try self.uninstall(%d<name>, :version(%d<version>),
                            :opts(RakuPM::InstallOptions.new(:keep-store)));  # 回滚是内部恢复：store 是还原源，绝不可删
    }
    # 3) 恢复账本（放最后：uninstall 会改账本，最终态必须与快照一致）
    $!target.add('installed.json').spurt(%tx<before>);
    # 4) 补齐：快照里有、但 CUR 里已经没了的版本（同版本 --force 重装的回滚）
    #    从 store 装回，避免「账本说装了、实际加载不到」。
    self!restore-missing-from-store(%tx<before>);
    # 5) 丢弃这个半成品世代
    self!gens.discard(%tx);

    %!tx = (); @!tx-installed = (); @!tx-bins = ();
}

# 账本里有、但 CUR 里没有的版本 → 从 store 装回（best-effort）。
#
# 【只补「激活版本」，绝不按 versions[] 逐个补】
# 账本的 versions[] 现在只镜像 CUR 的【当前激活集】（不再存历史，见 !record），
# 所以这里本就只会碰到激活版本；按它装回不会把历史版本重装一遍。
# 若按 versions[] 逐个装回，就会把历史上每个版本都重装一遍：
#   · 每装一次就重写一遍 bin wrapper（自包含 wrapper 带版本号）→ 输出刷屏，
#     看着像死循环（用户的 LibXML 现场：构建失败后回滚，刷了几十行
#     "bin/raku-pm ← 自包含 bash wrapper"，只能 ^C）；
#   · 更糟的是 wrapper 最后可能指向一个【旧版本】的 raku-pm。
# 回滚的目标是「恢复成事务前的样子」，而那个样子就是当时的【激活版本】。
method !restore-missing-from-store(Str $ledger-json --> Nil) {
    my @entries = (try from-json($ledger-json)) // ();
    return unless @entries.elems;
    for @entries -> %e {
        my $name = %e<name> // next;
        my $v = self!active-version-of(%e);
        next unless $v.chars;
        next if self.cur-has($name, $v);
        next unless $!store.has($name, $v);
        my $meta = $!store.path-for($name, $v).add('META6.json');
        next unless $meta.e;
        try self.install(RakuPM::Distribution.from-meta-file($meta));
    }
}

# CUR 里是否已装了某个包的某个版本
# CUR（site）里是否已装了某个包的某个版本。
# 公开：回滚/世代回滚都靠它判断「要不要装回」，测试也要能查。
method cur-has(Str $name, Str $version --> Bool) {
    so self!repo.installed.first({
        (.meta<name> // '') eq $name && (.meta<version> // '') eq $version
    })
}

method !set-current-generation(Str $id --> Nil) {
    self!gens.set-current($id);
}

# 当前世代 id（没有世代则空串）
method current-generation(--> Str) {
    self!gens.current
}

# 所有世代（按 id 升序），每条含 id / created-at / label / installed 列表
method list-generations(--> List) {
    self!gens.list
}

# 只保留最近 $keep 个世代（当前世代永不删）
method !prune-generations(Int $keep = 10 --> Nil) {
    self!gens.prune($keep);
}

# 退回到某个世代：让 target 与该世代的 manifest 一致。
#   · 现在有、目标世代没有的版本 → 卸载
#   · 目标世代有、现在没有的版本 → 从 store 装回
# 装不回（store 里已被 gc 掉）会警告，不中断 —— 直接把世代切成当前。
method rollback-to(Str $id --> Nil) {
    my $dir = self!gens.generation-dir($id);
    die "没有世代「$id」（用 `raku-pm generations` 看看有哪些）" unless $dir.d;
    my $mf = $dir.add('manifest.json');
    die "世代「$id」缺少 manifest.json（可能是不完整的旧世代）" unless $mf.e;

    my @want = (try from-json($mf.slurp)) // ();
    my @now  = self.list-installed;

    # 1) 多余的版本 → 卸载
    for @now -> %e {
        my $name = %e<name> // next;
        my %w  = @want.first({ (.<name> // '') eq $name }) // %();
        my @wv = self!versions-of(%w);
        for self!versions-of(%e) -> $v {
            next if $v (elem) @wv;
            self.uninstall($name, :version($v),
                           :opts(RakuPM::InstallOptions.new(:keep-store)));  # 世代回滚：store 是还原源，保留以便回滚后再装回
        }
    }
    # 2) 缺失的版本 → 从 store 装回
    for @want -> %w {
        my $name = %w<name> // next;
        for self!versions-of(%w) -> $v {
            next if self.cur-has($name, $v);
            unless $!store.has($name, $v) {
                note "  ⚠ store 里没有 {$name} {$v}，无法装回（跳过）";
                next;
            }
            my $meta = $!store.path-for($name, $v).add('META6.json');
            next unless $meta.e;
            self.install(RakuPM::Distribution.from-meta-file($meta));
        }
    }
    self!set-current-generation($id);
}

# ============ 安装一致性检查（raku-pm verify 的第二段） ============
#
# 「内容完整性」只回答 store 源码有没有被改；这里回答的是更致命的问题：
# 账本 / CUR / store / resources 四者是否对得上。今天踩的坑基本都在这里：
#   · 账本记着已装、CUR 里没有（= site/dist/<id> 损坏那类半截状态）
#   · CUR 有、账本没记（影响 installed / 依赖回收 / 世代回滚）
#   · 声明了 resources 但文件没生成（构建没跑成功 → libresources.so）
#   · 账本有、store 没有（回滚装不回来）
#
# 返回 [{ kind, name, version, detail, fixable }]。
method consistency-issues(--> List) {
    my @issues;

    # CUR 里实际装着什么
    my %cur;
    for self!repo.installed -> $d {
        my $n = ($d.meta<name> // '').Str;
        my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
        next unless $n.chars && $v.chars;
        %cur{"$n\0$v"} = True;
    }

    # ① 账本有、CUR 没有 / ② 账本有、store 没有
    for self.list-installed -> %e {
        my $name = %e<name> // next;
        for self!versions-of(%e) -> $v {
            unless %cur{"$name\0$v"}:exists {
                @issues.push(%( kind => 'missing-in-cur', name => $name, version => $v,
                    detail => '账本记着已装，但 CUR 里没有（dist 条目可能损坏）',
                    fixable => False ));
            }
            unless $!store.has($name, $v) {
                @issues.push(%( kind => 'missing-in-store', name => $name, version => $v,
                    detail => 'store 里没有源码（回滚/重装装不回来）',
                    fixable => False ));
            }
        }
    }

    # ③ CUR 有、账本没记
    my %ledger;
    for self.list-installed -> %e {
        my $name = %e<name> // next;
        %ledger{"$name\0$_"} = True for self!versions-of(%e);
    }
    for self!repo.installed -> $d {
        my $n = ($d.meta<name> // '').Str;
        my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
        next unless $n.chars && $v.chars;
        next if %ledger{"$n\0$v"}:exists;
        @issues.push(%( kind => 'missing-in-ledger', name => $n, version => $v,
            detail => 'CUR 里装着，但账本没记（不影响加载，影响 installed / 依赖回收 / 回滚）',
            fixable => True ));
    }

    # ④ 入库时声明过的 resources，文件后来没了。
    # 【这条只管「后来没了」】：它能查的是「store 的 META6 声明了、但文件现在不在」。
    # 至于「构建压根没跑成功、资源从来没生成过」——Store.!existing-resources 会把
    # 那类资源从 store 的 META6 里剔除（声明了却找不到会让 CUR::Installation 装不上），
    # 所以它在元数据里【不留痕迹】，④ 看不到。这一类的证据在 ⑤ 的 build.json 旁车里。
    for self.list-installed -> %e {
        my $name = %e<name> // next;
        my $v = self!active-version-of(%e);
        next unless $v.chars && $!store.has($name, $v);
        my $mf = $!store.path-for($name, $v).add('META6.json');
        next unless $mf.e;
        my $dist = try RakuPM::Distribution.from-meta-file($mf);
        next unless $dist.defined;
        my $dir = $!store.path-for($name, $v);
        for @($dist.resources) -> $res {
            next unless $res.chars;
            next if self!resource-present($dir, $res);
            @issues.push(%( kind => 'missing-resource', name => $name, version => $v,
                detail => "声明了资源 {$res} 但文件没生成（构建可能没跑成功）",
                fixable => False ));
        }
    }
    # ⑤ 构建痕迹（store 条目的 build.json 旁车）。逻辑抽到 !build-issues-for：
    # 同一份事实既供 verify（下面）也供 install() 装完主动提示（H10），不写两遍。
    for self.list-installed -> %e {
        my $name = %e<name> // next;
        my $v = self!active-version-of(%e);
        @issues.push($_) for self!build-issues-for($name, $v);
    }

    # ⑥ 幽灵安装：store 的标准 META6.json 一个模块都没声明，而 lib/ 里明明有模块源。
    # 0.87.1 之前入库的条目会这样（provides 字段缺失、或写成字符串等形态 →
    # 写出一份空 provides 的标准 META6 → CUR::Installation 挂不上任何模块）。
    # 症状最恶劣：install 报成功、账本记着已装、`installed` 列得出来，而 `use`
    # 永远找不到 —— 而且旧的 verify 会报「✓ 没有不一致」，用户拿不到任何线索。
    # 【修不了】--fix 只补记账本；这类只能重装（重装会走 0.87.1 的磁盘反推）。
    for self.list-installed -> %e {
        my $name = %e<name> // next;
        my $v = self!active-version-of(%e);
        next unless $v.chars && $!store.has($name, $v);
        next if $!store.effective-provides($name, $v).elems;
        my @on-disk = RakuPM::Distribution.scan-provides($!store.path-for($name, $v));
        next unless @on-disk.elems;
        @issues.push(%( kind => 'ghost-provides', name => $name, version => $v,
            detail => "标准 META6.json 一个模块都没声明，而 store 的 lib/ 里有 "
                    ~ "{@on-disk.elems} 个模块（幽灵安装：`use` 不到任何东西）"
                    ~ "——重装可修：raku-pm install {$name} --force",
            fixable => False ));
    }
    @issues.List
}

# 读取单个已装条目的构建痕迹（build.json 旁车），返回它暴露的构建类不一致列表。
# 抽出来是因为：① consistency-issues 的 ⑤ 段用它；② install() 装完也要主动提示
# （H10）—— 同一份事实，不该两套逻辑。每条 issue 形如
# { kind, name, version, detail, fixable }，与 consistency-issues 的其它段一致。
#
# 【专门补上「查不出来」的那个洞】见 ④。这里读的是入库时记下来的事实：
#   · resources-missing 非空  → 构建后声明过的资源仍不存在（构建没跑成功）
#   · build.mode = skipped-no-build 且包声明了 builder → 主动跳过了构建
#   · build.ran && !build.ok  → 构建失败却仍入库（不该发生）
#   · 没有 build.json 且声明了 builder → 旧版 raku-pm 装的，无从确认
# 全部 fixable=False：这类只能重装（`raku-pm install <包> --force`）或去
# 看构建日志；凭空补一条痕迹只会把问题藏起来。
method !build-issues-for(Str $name, Str $v --> List) {
    return () unless $v.chars && $!store.has($name, $v);
    my $dir = $!store.path-for($name, $v);

    # store 的 META6 里有没有 builder —— 决定「没有痕迹」算不算异常。
    # 不给每个纯 Raku 包都刷一条无意义的不一致。
    my %m6 = (try { from-json($dir.add('META6.json').slurp) }) // %();
    my Bool $declares-builder = (%m6<builder> // '').Str.trim.chars > 0;

    my $bt = $dir.add('build.json');
    unless $bt.e {
        # build.json 是 0.43.1 才有的；旧条目没有它属正常，只在该包
        # 本来就需要构建时才提一句。
        if $declares-builder {
            return (%( kind => 'no-build-trace', name => $name, version => $v,
                detail => 'store 声明了 builder 却没有构建痕迹（旧版 raku-pm 装的）'
                        ~ ' —— 无法确认构建产物是否齐备，建议重装一遍',
                fixable => False ),);
        }
        return ();
    }

    my %t = (try { from-json($bt.slurp) }) // %();
    my %b = %(%t<build> // {});

    my @out;
    for @(%t<resources-missing> // []) -> $res {
        @out.push(%( kind => 'missing-build-resource', name => $name, version => $v,
            detail => "构建后 resources/{$res} 仍不存在（构建多半没跑成功），"
                    ~ '已从 store 的声明里剔除 —— 运行期 %?RESOURCES 取不到，'
                    ~ '用到它的模块会在取资源时崩',
            fixable => False ));
    }

    my Str $mode = (%b<mode> // '').Str;
    if $mode eq 'skipped-no-build' && $declares-builder {
        @out.push(%( kind => 'build-skipped', name => $name, version => $v,
            detail => '这份是用 --no-build 装进 store 的，而包声明了 builder'
                    ~ ' —— 若它需要构建产物，运行期会失败',
            fixable => False ));
    }
    elsif %b<ran> && !%b<ok> {
        @out.push(%( kind => 'build-failed', name => $name, version => $v,
            detail => '上次构建以失败告终却仍被入库（不应发生）—— 建议重装',
            fixable => False ));
    }
    @out.List
}

# 资源文件是否已经生成。
# libraries/* 用【包含匹配】而不是硬编平台文件名：
# libraries/gdbmhelper 在磁盘上可能是 libgdbmhelper.so / gdbmhelper.dll /
# libgdbmhelper.dylib，声明里带不带 lib 前缀两种写法都有，硬编形状必误报。
method !resource-present(IO::Path $store-dir, Str $res --> Bool) {
    return True if $store-dir.add('resources').add($res).e;
    if $res.starts-with('libraries/') {
        my $base = $res.substr('libraries/'.chars);
        my $ldir = $store-dir.add('resources').add('libraries');
        return True if $ldir.d && $ldir.dir.first({ .basename.contains($base) });
    }
    False
}

# 把「CUR 有、账本没记」的条目补进账本（verify --fix）。返回补了几条。
method adopt-from-cur(:$chain --> Int) {
    my $n = 0;
    # 默认用【自己这个 CUR】，不要用进程的 $*REPO 链：
    # 库调用/测试场景下 $*REPO 里根本没有 inst#<target>/site（CLI 之所以能靠它，
    # 是因为 wrapper 设了 RAKULIB），拿进程链去找会认不到自己的包；更糟的是
    # 若不过滤，会把 zef 站里的发行版也补进我们的账本（实测会误补 51 条）。
    my @repos = $chain.defined ?? @$chain !! (self!repo,);
    my $own-prefix = self.repo-prefix.absolute;
    for @repos -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        # 显式传 :$chain 时才需要按前缀筛（只认自家 site）
        if $chain.defined {
            my $prefix = (try { $repo.prefix.absolute }) // '';
            next unless $prefix && $prefix eq $own-prefix;
        }
        for $repo.installed -> $d {
            my $name = ($d.meta<name> // '').Str;
            my $v    = ($d.meta<version> // $d.meta<ver> // '').Str;
            next unless $name.chars && $v.chars;
            next if $v (elem) self.installed-versions($name);
            # 先把 CUR 的 dist 元数据落成临时 META6.json，再走 from-meta-file ——
            # 不手工挑字段构造 Distribution（漏字段这个坑已经踩过三次）。
            # 【0.87.0】名字/版本要净化后才能拼进文件名：它们最终来自包自己的
            # META6.json（发布者可控），`foo/../bar` 这种会让临时文件写到 TMPDIR 之外。
            my $tmp = $*TMPDIR.add('rakupm-adopt-'
                ~ $*PID ~ '-'
                ~ path-component($name, :what('发行版名')) ~ '-'
                ~ path-component($v,    :what('版本号')) ~ '.json');
            my $dist = do {
                my $ok = try { $tmp.spurt(to-json($d.meta)); True };
                $ok ?? (try RakuPM::Distribution.from-meta-file($tmp)) !! Nil;
            };
            try $tmp.unlink;
            next unless $dist.defined;
            self.record-entry($dist);
            $n++;
        }
    }
    $n
}

# 一条账本/清单条目里的全部版本（兼容只有 version 字段的老格式）。
# 实现已上移到 RakuPM::Ledger.versions-of —— 排序走 semver（字典序会把
# 0.9.2 判成高于 0.13.0，导致回滚时「激活版本」选错）。这里保留薄转发，
# 免得改掉所有调用点。
method !versions-of(%e --> List) {
    self!ledger.versions-of(%e)
}

# 把 META6.json bin 字段里的脚本放到 $!target/bin/ 下，去掉 .raku/.rakumod 后缀。
#
# 为什么不靠 CUR::Installation：Distribution::Path 的 install 语义只覆盖
# provides/lib 的模块挂载，bin 字段是「可执行脚本」另一回事。zef 在
# lib/Zef/Service/Shell/ExtractBin.rakumod 单独做这件事，raku-pm 走自己的实现。
#
# 软链 vs 复制：
#   · 软链：源文件改了，目标立即生效；装新版时直接换 symlink。
#   · 复制：跨文件系统 / 无 symlink 权限时退路。
#   都尝试，软链失败就退化到复制。
method !install-bin(IO::Path $dist-dir --> Nil) {
    my $meta-file = $dist-dir.add('META6.json');
    return unless $meta-file.e;
    my $j = try from-json($meta-file.slurp);
    return if $j ~~ Failure || ! $j.defined;     # META6 损坏 → 当没有 bin 字段（方法返回 Nil）
    my %meta = $j;
    my @bin = (%meta<bin> // ()).flat;
    return unless @bin.elems;

    my $bin-dir = $!target.add('bin');
    mkdir-p($bin-dir);

    # 自装 RakuPM 自身时，生成「自包含 wrapper」——不靠软链解析、不靠
    # $*PROGRAM.parent(2) 推 lib/ 位置（复制品场景会失）。bash wrapper
    # hardcode 目标绝对路径，从 store 里挑最新的 RakuPM 副本 + 设 RAKULIB。
    # 这样不管是软链还是复制品，wrapper 在 PATH 里都能跑；旧版 zef 装的
    # 断链 wrapper 也就不会干扰用户。
    my $is-self = (%meta<name> // '') eq 'RakuPM';

    for @bin -> $rel {
        my $src = $dist-dir.add($rel);
        next unless $src.e;

        # 目标文件名：去掉 .raku / .rakumod 后缀（POSIX 风格的可执行命令名）。
        my $src-name = $src.IO.basename;
        my $base = $src-name;
        $base ~~ s/ '.' rakumod $//;
        $base ~~ s/ '.' raku    $//;

        my $dst = $bin-dir.add($base);

        if $is-self {
            my $version = (%meta<version> // '').Str;
            self.write-self-wrapper($dst, :$version);
        }
        else {
            # 其他发行版：软链优先；不行就 copy（覆盖旧版本用的可能是更旧符号链）
            my $linked = try {
                if $dst.e && $dst.l { $dst.unlink }
                $dst.symlink($src.absolute);
                $dst.l
            };
            if $linked && $dst.l {
                say "==> bin/{$base} → 软链 → {$rel}";
            }
            else {
                try $dst.unlink if $dst.e && $dst.l;
                $src.copy($dst);
                try $dst.chmod(0o755) if $dst.e;   # Windows 上 chmod 是 noop
                say "==> bin/{$base} ← 复制";
            }
        }

        # zef 同款：把 wrapper 也放进 rakudo 的 site/bin（它在用户 PATH 上）。
        # 默认关（$.promote-bin=False），只有 CLI 安装显式开启。
        # 失败（目录只读）就静默 —— target/bin 那份 + `raku-pm env` 提示是兜底。
        self.promote-to-site-bin($dst) if $!promote-bin;
        # Windows cmd/PowerShell 不执行无后缀 bash 脚本，额外生成的 .bat/.ps1
        # 也一并 promote。0.48.0 起 .ps1 也推（此前漏了它：三个 wrapper 只有两个
        # 进得了 site/bin，而输出却声称写了三个）。
        my $bat = $bin-dir.add($base ~ '.bat');
        self.promote-to-site-bin($bat) if $!promote-bin && $bat.e;
        my $ps1 = $bin-dir.add($base ~ '.ps1');
        self.promote-to-site-bin($ps1) if $!promote-bin && $ps1.e;
        # 入口体检：确认用户敲 $base 时命中的是刚 promote 上去的 wrapper，
        # 而不是 zef/CUR 时代留下的 <base>.exe（Windows 上 .EXE 优先级最高，会遮蔽）。
        self.ensure-bin-entry($base) if $!promote-bin;
        # P6：事务开着就记下本次新建的 bin，回滚时一并删掉
        if $!tx-depth {
            @!tx-bins.push($dst.absolute);
            @!tx-bins.push($bat.absolute)      if $bat.e;
            @!tx-bins.push($ps1.absolute)      if $ps1.e;
        }
    }
}

# zef 同款：把 target/bin 下的 wrapper 再复制一份到 rakudo 的 site/bin。
# 返回是否成功（成功 = 用户可以直接敲命令名）。
# :$site-bin 可注入（测试传假目录）；生产路径不传，自动找「全局 site/bin」
# （见 global-site-bin-dir —— 排除 raku-pm 自己的 site，否则会写进一个不在
# PATH 上的目录，用户敲不到）。
method promote-to-site-bin(IO::Path $wrapper, IO::Path :$site-bin? --> Bool) {
    my $site-bin-dir = $site-bin // self.global-site-bin-dir;
    return False unless $site-bin-dir.defined && $site-bin-dir.Str.chars;

    my $ok = try {
        mkdir-p($site-bin-dir);
        my $dst = $site-bin-dir.add($wrapper.IO.basename);
        $wrapper.copy($dst);
        try $dst.chmod(0o755) if $dst.e;
        True
    } // False;

    if $ok {
        say "==> bin/{$wrapper.IO.basename} 已放入 {$site-bin-dir.absolute}";
        say "    （zef 同款：site/bin 在你的 PATH 上，现在就可以直接敲 `{$wrapper.IO.basename}`）";
    }
    else {
        say "    （未能写入 {$site-bin-dir.absolute}，可能是权限不足。";
        say "      把 {$wrapper.IO.parent.absolute} 加进 PATH 即可用 `raku-pm env` 查看）";
    }
    $ok
}

# 入口体检 + 接管：确保用户敲 `$base` 时实际命中的是 raku-pm 写的 wrapper。
#
# 为什么需要（用户现场，Windows）：Windows 用 PATHEXT 解析命令名，`.EXE` 优先于
# `.BAT`，也优先于没有扩展名的文件。若 site/bin 里留着 zef / CUR 时代生成的
# `<base>.exe`，它会**永久遮蔽** raku-pm 写的 bash/.bat wrapper —— self-upgrade
# 明明把新版装进了 store，账本、lock 也都更新了，用户敲 `raku-pm` 跑出来的却还是
# 旧版（本机实测仍是 0.46.1）。而 raku-pm 此前从不处理这个 `.exe`（它只写自己那
# 三类 wrapper），所以「升级成功」与「用户用到新版」之间断了一环。
#
# 做法：按平台解析规则（RakuPM::Platform.pick-command-file，与 `raku-pm env`
# 共用同一处判定，避免两边再对不上）算出实际会被执行的文件；若不是 raku-pm 写的
# （<base> / <base>.bat / <base>.ps1），就**改名备份**——可逆、不删数据——让解析
# 自然落到我们的 wrapper 上，并打印做了什么、怎么还原。
#
# 幂等：接管过一次之后目录里就没有遮蔽者了，重复执行不会做任何事。
#
# 公开而非私有：与 promote-to-site-bin 同例 —— 需要能单独测（私有方法外部不可调，
# `$obj!Pkg::method` 会报 "does not trust the 'GLOBAL' package"），也便于将来
# 让 CLI 提供「修复入口」这类命令复用。
#
# :$os 与 :$dir 一样是**注入口**（0.49.2）：透传给 pick-command-file，于是测试能在
# 任何宿主上分别验「Windows 按 PATHEXT 解析、会认出 .exe」「Unix 只看无扩展名、
# .exe 根本不参与」两套语义。生产路径不传 → 行为与以前完全一致。
# 为什么必须能注入：xt/entry-check.t 原先没注入，几条断言写的是 Windows 语义，
# 于是在 Linux 上「一个都认不出来 → 不接管 → 断言全红」——和 t/bin-path-order.t
# 是同一次事故的第二个现场（t/ 那个会挡住 install，xt/ 这个只挡你自己跑门禁）。
method ensure-bin-entry(Str $base, IO::Path :$dir?, Str :$os = '' --> Nil) {
    my $d = $dir // self.global-site-bin-dir;
    return unless $d.defined && $d.Str.chars && $d.d;
    # 自己那份都没写进去（权限不足等）就别接管 —— 否则用户会连命令都没有。
    return unless $d.add($base).e || $d.add($base ~ '.bat').e;

    my $hit = pick-command-file($d, $base, $os);
    return unless $hit.defined;
    my $name = $hit.IO.basename;
    my @own = ($base, $base ~ '.bat', $base ~ '.ps1');
    return if @own.first({ $_ eq $name }).defined;

    # rename 到已存在的目标会直接覆盖（实测），无需先删。
    my $bak-name = $name ~ '.zef-old';
    my $bak = $d.add($bak-name);
    my $done = False;
    try { $done = so $hit.rename($bak) }

    if $done && !$hit.e && $bak.e {
        say "==> 入口体检：敲 `{$base}` 原本会执行 {$name}（不是 raku-pm 装的，多半是 zef 时代的残留）";
        say "    已改名为 {$bak-name}，现在会执行 raku-pm 的 wrapper";
        say "    想还原：把 {$bak-name} 改回 {$name} 即可";
    }
    else {
        say "⚠  入口体检：{$name} 会遮蔽 raku-pm 的 wrapper，但改名失败（权限？）";
        say "    请手动把 {$d.add($name).absolute} 改名或删除，否则敲 `{$base}` 跑的一直是它";
    }
}

# 自装 RakuPM 时写到 target/bin/ 的 wrapper（bash + Windows 下 .bat）。
# 设计目标：「wrapper 在 PATH 哪里都能跑」，不依赖：
#   · 软链是否 resolve（Raku 各版本行为不一致；软链断了直接挂）
#   · $*PROGRAM.parent(2) 能否找到 lib/（复制品场景失）
#   · 外部 RAKULIB（用户很少主动设）
# 而是：
#   · wrapper 内 hardcode target 绝对路径（target 一般是 ~/.raku-pm，固定）
#   · 启动时挑 store/RakuPM 里最新版本
#   · 自动 export RAKULIB=inst#<target>/site
#   · exec raku <store/.../bin/raku-pm.raku>
# 这样放在 target/bin/，PATH 里排第一就能用；旧 zef wrapper 不再混淆。
# :$version 传入本次装的版本 —— Windows 的 .bat 直接写死这条路径
#（cmd 没有 bash/没有 semver sort，做不到运行时挑最新；升级重装会重写 .bat）。
#
# RAKUPM_RAKU fallback：bash 子进程在某些场景（zef install 流程、WSL Git Bash
# 隔离）PATH 里可能找不到 raku —— 实测 exit 127。直接用 $*EXECUTABLE.absolute
# 作为 fallback（这是启动本次 installer 的 raku 自己的绝对路径，绝对有效），
# 不调 which（which 在跨平台/断链时不可靠，是 0.18.0~0.19.0 一连串 bug 的根源）。
method write-self-wrapper(IO::Path $dst, Str :$version = '' --> Nil) {
    self!write-bash-wrapper($dst, :$version);
    if is-windows() {
        # site-abs / entry-abs / target-abs / raku-abs 各自重算（带连字符的 named
        # 参数得写全：site-abs => $site-abs，不能用 :$site-abs 简写 —— 编译器不会
        # 报错但接收端拿到 undef；这一行就当文档留下）。
        my $target-abs = $!target.absolute;
        my $raku-abs   = $*EXECUTABLE.absolute;
        my $site-abs   = $!target.add('site').absolute;
        my $entry-abs  = $!target.add('store', 'RakuPM', $version, 'bin', 'raku-pm.raku').absolute;
        self!write-win-wrappers($dst, :$version,
            :$target-abs, :$raku-abs,
            site-abs => $site-abs, entry-abs => $entry-abs);
    }
}
method !write-bash-wrapper(IO::Path $dst, Str :$version --> Nil) {
    my $target-abs = $!target.absolute;
    # 三段平台 shell 模板已提到 RakuPM::Installer::ShellTemplates（纯字符串函数，
    # 不碰文件系统与 CUR，可单独单测）。这里只负责算路径、落盘、打印。
    # entry-abs：写死入口（安装时版本已知），让 bash wrapper 不必每次运行时
    # `ls | sort -V` 挑最新版 —— 那一句在 Windows/Git Bash 下要 ~0.7s。
    # version 为空时不写死（传空串），wrapper 里 [ ! -f "" ] 成立 → 自动走探测 fallback。
    my $entry-abs = $version.chars
        ?? $!target.add('store', 'RakuPM', $version, 'bin', 'raku-pm.raku').absolute
        !! '';
    my $body = bash-wrapper-body(
        $target-abs,
        $!target.add('store', 'RakuPM').absolute,
        $!target.add('site').absolute,
        $*EXECUTABLE.absolute,
        $entry-abs,
    );

    # 覆盖旧 wrapper
    try $dst.unlink if $dst.e;
    $dst.spurt($body);
    try $dst.chmod(0o755) if $dst.e;
    say "==> bin/{$dst.IO.basename} ← 自包含 bash wrapper（target={$target-abs}）";
}
# Windows 上生成 .bat（cmd 入口）与 .ps1（PowerShell 入口，优先被解析）。
#
# .bat：raku "...raku-pm.raku" %* —— cmd 会二次解析 %*，< > & | 都会被当
#       重定向符，加引号也救不回来（引号在 CRT 阶段就剥掉）。
# .ps1：& raku "...raku-pm.raku" @args —— PowerShell 直接 spawn raku 进程，
#       按 Windows CRT 规则给参数加引号，< > & | 全程安全。前提是用户先
#       把 .PS1 加进 PATHEXT（PowerShell 默认 PATHEXT 不含 .PS1）。
# 写两个并存：cmd 用户用 .bat（并接受 < > 撞墙的现实），PowerShell 用户
# 把 PATHEXT 加上 .PS1 后就会优先选 .ps1。
method !write-win-wrappers(IO::Path $dst, Str :$version, :$target-abs, :$raku-abs, :$site-abs, :$entry-abs --> Nil) {
    # 模板在 RakuPM::Installer::ShellTemplates（.ps1 的 LF->CRLF 也在那边做）。
    # 三段模板都要拿到 target-abs：wrapper 会把前缀显式传给 CLI（--target），
    # 这样「敲哪个前缀的 wrapper 就在哪个前缀里干活」（见 ShellTemplates 顶部说明）。
    my $bat = $dst.IO.parent.add($dst.IO.basename ~ '.bat');
    $bat.spurt(win-bat-body($version, $target-abs, $site-abs, $raku-abs, $entry-abs));
    say "==> bin/{$bat.IO.basename} ← Windows .bat wrapper（version={$version}）";

    my $ps1 = $dst.IO.parent.add($dst.IO.basename ~ '.ps1');
    $ps1.spurt(win-ps1-body($version, $target-abs, $site-abs, $raku-abs, $entry-abs));
    say "==> bin/{$ps1.IO.basename} ← Windows PowerShell .ps1 wrapper（version={$version}）";
}

# 把仓库链上发现、但账本缺失的发行版补记进账本（自愈）。
# 历史版本写入格式差异、安装中断等都可能造成「site 里有、账本没有」——
# 不补记的话 installed 看不到、依赖判定也少一份依据。
method record-entry(RakuPM::Distribution $dist --> Nil) {
    self!record($dist)
}

# 卸载：从 CUR::Installation 摘掉，并更新账本
# :$version 为空（默认）→ 该发行版的所有版本都摘掉；
# 指定版本 → 只摘那一个版本，其余保留（多版本共存下这是常见需求：
#           只想清掉某个出问题的版本，而不是把整个包连根拔起）。
#
# 【返回值 0.87.3】本次【真的从 CUR 摘掉】的版本字符串列表（可能为空）。
# Client.uninstall 靠它判断「卸载到底成没成」—— 此前本方法返回 Nil、调用方也不看，
# 于是「卸一个根本没装的包」照样打印「已卸载 Foo」且 rc=0，脚本按退出码判断会被骗过。
# 以 CUR 为准（而不是账本）：CUR 才是「装没装」的事实来源。
method uninstall(Str $name, Str :$version = '',
                  RakuPM::InstallOptions :$opts, Bool :$keep-store = False --> List) {
    my $ver = $version.trim;
    # 兼容两种入口：Client 的 uninstall 走 :$opts（含 keep-store 字段），测试 / 内部回滚仍可用
    # 裸 :$keep-store。统一进 $o 后只认这一个载体（Issue 9 收口）。
    my $o = $opts // RakuPM::InstallOptions.new(:$keep-store);

    # CUR 侧：版本筛选走 semver 约束（RakuPM::Version.satisfies）。
    # 给精确版本（"1.0.0" / "1.0"）时退化为单版本匹配；给范围（"<1.0" /
    # ">=1.0, <2.0" / "^1.0" / "~1.2"）时卸载所有满足的版本——这就是
    # 「uninstall 支持 semver 范围」的承载点。
    my @removed;
    for self!repo.installed.grep({ (.meta<name> // '') eq $name }) -> $d {
        next if $ver.chars
            && !RakuPM::Version.from-string($d.meta<version> // '').satisfies($ver);
        @removed.push(($d.meta<version> // '').Str);
        self!repo.uninstall($d);
    }

    # store 侧：uninstall 默认把【被卸版本的源码快照】一并清掉。普通用户心智里
    # 「卸了就该没了」，不该再留个占盘的缓存逼人家卸完再跑一次 clean。范围卸载时
    # 只清「满足约束的那些版本」（从已装清单筛），不碰不满足约束的版本；整包卸
    # 才清全部。--keep-store 才保留快照（给「秒级离线重装」这类高级场景；raku-pm
    # 自身 self-upgrade 走 prune-other-versions，不在这里）。
    unless $o.keep-store {
        my @store-versions = $ver.chars
            ?? self.installed-versions($name)
                 .grep({ RakuPM::Version.from-string($_).satisfies($ver) })
            !! self.installed-versions($name);
        for @store-versions.grep(*.chars) -> $v {
            try $!store.remove($name, $v) if $!store.has($name, $v);
        }
    }

    # 账本侧：整段交给 RakuPM::Ledger.remove（版本比较也走 satisfies，同样支持
    # 范围）。账本文件不存在就什么都不做 ——
    # 不能因为一次卸载就在 target 里凭空造出一个空账本。
    self!ledger.remove($name, :version($ver)) if self!ledger.exists;

    # 只报告【CUR 里真的摘掉了】的版本（见方法头的说明）。注意：store 快照的清理
    # 与账本更新是无条件的，所以返回空只代表「这个包在 CUR 里本来就不存在」，
    # 不代表什么都没动（那种情况下的 store/账本本来也没东西可动）。
    @removed.List
}

# 把 $name 在 CUR / store / 账本里的【除 $keep 外的所有版本】一次性清掉。
#
# 刻意与 uninstall 区分：uninstall 是「用户主动卸包」，支持按版本卸单个、或整包
# 清空；本方法是「同发行版只留一份」的批量收口，给 raku-pm 自己（self-upgrade）
# 这种「工具永远只该留最新版」的场景用。普通用户包刻意支持多版本共存，绝不调用。
#
# 三处一致性（与 install / uninstall 同一套事实来源）：
#   · CUR：摘掉所有「同名且版本 != keep」的已装条目（用私有 !repo，避免公开
#     uninstall 再走一遍 ledger.remove 造成双重写盘）；
#   · store：删掉非 keep 版本的源码快照（版本清单从账本 installed-versions 取，
#     先 has 判断再 remove，避免对不存在的版本报错）；
#   · 账本：versions[] 只剩 [keep]，version 字段同步为 keep（modify 只改这两个
#     字段，其余 auth/provides/digest/... 原样保留）。
method prune-other-versions(Str $name, Str $keep --> Nil) {
    # 1) CUR：先收集再摘，避免边迭代边卸载改动底层集合
    my @olds = self!repo.installed.grep({
        ($^d.meta<name> // '') eq $name
     && ($^d.meta<version> // '') ne $keep
    }).list;
    for @olds -> $d {
        try self!repo.uninstall($d);
    }

    # 2) store：删非 keep 版本的源码快照
    for self.installed-versions($name).grep(* ne $keep) -> $v {
        try $!store.remove($name, $v) if $!store.has($name, $v);
    }

    # 3) 账本：versions[] 只留 keep，version 字段同步
    if self!ledger.exists {
        self!ledger.modify($name, -> %e {
            %e<version>  = $keep;
            %e<versions> = [$keep];
        });
    }
}

# 列出已安装（每包一条，含版本与指纹）
method list-installed(--> List) {
    self!ledger.entries
}

# ============ 反向依赖 / 依赖回收 ============
#
# 依赖声明写的是【模块名】（"depends": { "Foo::Bar" => "1.0" }），而账本记的是
# 【发行版名】。两者必须靠 provides 打通：
#   A 的 depends 里有模块 M → 找哪个已装发行版 provides 了 M → 得到「A 依赖 B」。
# 反向依赖就是这张图的反向边。

# 某个已装版本的运行时依赖（模块名 => 约束串）
method !depends-of(Str $name, Str $version --> Hash) {
    # 优先用 store 里的 META6.json（完整，与安装时一致）
    if $!store.has($name, $version) {
        my $mf = $!store.path-for($name, $version).add('META6.json');
        if $mf.e {
            my $d = try RakuPM::Distribution.from-meta-file($mf);
            return $d.defined ?? $d.depends !! {};
        }
    }
    # 退回 CUR 里的发行版元数据（store 被 clean 掉时）
    for self!repo.installed -> $dist {
        next unless ($dist.meta<name> // '')    eq $name
                 && ($dist.meta<version> // '') eq $version;
        return RakuPM::Distribution.normalize-dependencies($dist.meta<depends> // {});
    }
    {}
}

# 哪些已装发行版提供了某个模块（用账本里记的 provides）
method !dists-providing(Str $module, @installed --> List) {
    @installed.grep({ $module (elem) @(.<provides> // []) })
              .map({ .<name> }).unique.List
}

# 该发行版当前激活（最高）版本 —— 用它来读依赖
method !active-version-of(%e --> Str) {
    my @v = self!versions-of(%e);
    @v ?? @v[*-1] !! (%e<version> // '')
}

# 【反向依赖】哪些已装的包依赖了 $name。
# 返回 [{ name, version, module, constraint }, ...]；module 是它依赖的那个模块名
#（可能与发行版名不同 —— 一个 dist 可以提供很多模块）。
method reverse-dependencies(Str $name, Str :$version = '' --> List) {
    my @installed = self.list-installed;
    my @out;
    my %seen;
    for @installed -> %e {
        my $dn = %e<name> // next;
        next if $dn eq $name;                    # 自己不算（自依赖会被误判成环）
        my %dep = self!depends-of($dn, self!active-version-of(%e));
        for %dep.kv -> $module, $constraint {
            for self!dists-providing($module, @installed) -> $provider {
                next unless $provider eq $name;
                my $key = "$dn\0$module";
                next if %seen{$key};
                %seen{$key} = True;
                @out.push(%( name       => $dn,
                             version    => self!active-version-of(%e),
                             module     => $module,
                             constraint => $constraint ));
            }
        }
    }
    @out.List
}

# 【可回收的孤儿】当初是作为依赖装进来、且现在已经没有任何已装包依赖它的那些。
#
# 只回收 reason='dependency' 的。用户点名装过的（explicit）永远不动 —— 就算暂时
# 没人依赖它，那也是用户自己要的（命令行工具、想留着的库）。这正是 apt 的
# auto/manual 标记的用意：没有这个区分，「自动回收」就变成「乱删」。
method orphaned-dependencies(--> List) {
    my @installed = self.list-installed;
    my %depended;                                # 被别人依赖的发行版集合
    for @installed -> %e {
        my $dn = %e<name> // next;
        my %dep = self!depends-of($dn, self!active-version-of(%e));
        for %dep.keys -> $module {
            for self!dists-providing($module, @installed) -> $p {
                %depended{$p} = True unless $p eq $dn;   # 自依赖不算「被依赖」
            }
        }
    }
    @installed.grep({
        my $n = .<name> // '';
        $n.chars
            && !%depended{$n}
            && ((.<reason> // 'explicit') eq 'dependency')
    }).List
}

# 查某个包当前激活的版本（装过多个版本时取最高的那个）
method installed-version(Str $name --> Str) {
    self!ledger.installed-version($name)
}

# 记录 / 读取某次安装对应的 git 提交号。
#
# self-upgrade 的「版本相同但内容不同」检测靠它：git 仓库的 HEAD 提交号与
# 安装时不一致，说明上游被强推或改写了历史 —— 即便 META6 版本号没变，
# 内容也已经不是当初装的那份，该重装。版本号是唯一可靠的「内容指纹」来源时
# （git 装的包没有 tar 包校验和），提交号就是最便宜且足够强的替代品。
#
# 按版本分别记录（一条账本条目可有多个版本，各自来自不同提交）。
# 只改已存在的条目（不存在说明这个包根本没记进账本，不该凭空造一条）。
method set-git-sha(Str $name, Str $version, Str $sha --> Nil) {
    return unless self!ledger.exists;
    self!ledger.set-git-sha($name, $version, $sha);
}

# 读某版本安装时记录的提交号；没记录过（老版本装的）返回空串。
method recorded-git-sha(Str $name, Str $version --> Str) {
    self!ledger.recorded-git-sha($name, $version)
}

# 查某包已安装的【全部】版本（升序）。多版本共存后这才是真相，
# installed-version 只是它的「取最高」视图。
#
# 排序走 semver，不能用字符串字典序——字典序里 "0.13.0" < "0.9.2"
# （因为 '1' < '9'），会误把 0.9.2 当成最高版本。用户的实测案例：装 0.9.2
# 与 0.13.0 之后 installed 显示星号在 0.9.2 上，明明最后装的是 0.13.0。
# 实现已上移到 RakuPM::Ledger.installed-versions（账本的知识归账本）。
method installed-versions(Str $name --> List) {
    self!ledger.installed-versions($name)
}

# ============ 内部实现 ============

# 账号本读写：全体走 RakuPM::Ledger（惰性创建）。
# 账本格式（字段、排序、损坏报错、序列化选项）从此只有一处定义。
method !ledger {
    $!ledger //= RakuPM::Ledger.new(:path($!target.add('installed.json')));
}

# 世代目录的读写：全体走 RakuPM::Installer::Generations（惰性创建）。
# 目录格式（id 分配 / before.json / meta.json / manifest.json / current / 裁剪）
# 从此只有一处定义 —— 原先散在本类的 6 个私有方法里。
method !gens {
    $!gens //= RakuPM::Installer::Generations.new(:dir($!target.add('generations')));
}

# 惰性创建 CUR::Installation（它是内置类型，不需要 use）
method !repo {
    return $!cur if $!cur.defined;
    my $prefix = self.repo-prefix;
    mkdir-p($prefix);
    $!cur = CompUnit::Repository::Installation.new(prefix => $prefix.absolute);
}

# 记录安装信息。同一包的多版本合并成一条：version 记最新，
# versions 数组记全部——多版本共存后单看 version 是不够的。
# 读-改-写交给 Ledger.modify（它负责「不存在则新建」与统一落盘）。
method !record(RakuPM::Distribution $dist, Str :$source = '', Str :$reason = '' --> Nil) {
    self!ledger.modify($dist.name, -> %entry {
        %entry<name>         = $dist.name;
        %entry<version>      = $dist.version;
        %entry<auth>         = $dist.auth;
        # provides 记【生效的那份】（store 标准 META6.json 里的模块清单），而不是
        # 索引行 / 本地 META6 声明的那份 —— 0.87.1 起，声明缺失或形态不对时会由
        # Store 扫 lib/ 反推补齐，此时声明侧是空的；照抄进账本会让「按模块名查已装包」
        # （installed / list）与反向依赖图（autoremove）对这类包双双失灵。
        # 取不到（store 条目异常）才退回声明值。
        my @eff = $!store.effective-provides($dist.name, $dist.version);
        %entry<provides>     = @eff.elems ?? @eff.List !! $dist.provides.List;
        # 补记的包可能不在 store 里（古早条目），digest 取不到就留空
        %entry<digest> = (try { $!store.digest-of($dist.name, $dist.version) }) // '';
        %entry<installed-at> = DateTime.now.Str;
        %entry<source> = $source if $source.chars;

        # reason：为什么装这个包 —— 'explicit'（用户点名要的）/'dependency'
        #（作为依赖被拉进来的）。卸载时的依赖回收【只回收】'dependency' 且已经没人
        # 再依赖它的那些，绝不碰 'explicit'。老账本没有这个字段时按 explicit 处理：
        # 宁可不回收，也不能把用户自己装的东西悄悄删掉。
        if $reason.chars {
            my $cur = %entry<reason>;
            # 只有「已明确标记为 explicit」时，才不被一次依赖安装降级成 dependency
            %entry<reason> = ($cur.defined && $cur eq 'explicit' && $reason ne 'explicit')
                ?? 'explicit' !! $reason;
        }

        my @vs = |@(%entry<versions> // []), $dist.version;
        # 同样按 semver 升序存（与 installed-versions 同规则）。虽然读取时会重新
        # 按 semver 排序，但让盘上的顺序也正确，免得以后有人直接取 [*-1] 踩坑。
        %entry<versions> = RakuPM::Version.new.sort-versions(@vs);
    });
}
