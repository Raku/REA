# RakuPM::Repository — 仓库抽象
#
# 仿 zef 的「可插拔后端」思想：把「从哪里找包」抽象成一个角色 (role)。
# 任何实现了这个角色的类，都能作为包源被 Client 使用。
# 这就是 zef 里 Zef::Repository::Ecosystems / LocalCache 的简化版。

use RakuPM::Distribution;
use RakuPM::Repository::Matching;

# 所有仓库共用「关键词 → 是否/多相关地匹配一个发行版」的判定：
# match-score / match-exact / match-any 由这个 role 提供（唯一实现处，
# 见 lib/RakuPM/Repository/Matching.rakumod）。search / store / installed /
# install 的匹配语义因此收敛到一份。
unit role RakuPM::Repository does RakuPM::Repository::Matching;

# 核心接口：给定模块名，返回「能提供这个模块」的所有发行版（名字列表）。
#
# 这是 install 那条路的模块匹配：**精确**模块名反查（索引化 O(1)）。
# 与 RakuPM::Repository::Matching.match-exact 的「模块名精确」档
# （score 3）语义一致——查询命令与安装解析因此不会各有一套「匹配」定义。
method find-providers(Str $module --> List) { ... }

# 列出这个仓库里的全部发行版名字
method all-distributions(--> List) { ... }

# 获取某个发行版的所有可用版本（字符串列表）
method available-versions(Str $name --> List) { ... }

# 某发行版中【真正提供】$module 的那些版本。
#
# 不能只用 find-providers：索引里同一个发行版的 provides 是随版本变化的。
# 真实案例：DBIish 0.5.5–0.6.1 曾把 NativeLibs 打在自己包里，0.6.2 之后
# 拆成了独立的 NativeLibs 发行版。若只拿「某个版本提供过」去挑最高版本，
# 就会挑中 DBIish 0.6.8 —— 而它压根不含 NativeLibs。
method versions-providing(Str $module, Str $dist-name --> List) {
    # 角色里的通用兜底：逐个版本物化后检查 provides（慢，但任何仓库都能用）。
    # 发行版名依赖（dist 名与依赖名相同）则全部版本都算提供。
    return self.available-versions($dist-name).List if $dist-name eq $module;
    self.available-versions($dist-name).grep({
        $module (elem) self.fetch-distribution($dist-name, $_).provides
    }).List
}

# 把一个发行版「物化」成 Distribution 对象（可能需要下载/解包）
method fetch-distribution(Str $name, Str $version --> RakuPM::Distribution) { ... }

# 某版本源码所在的本地目录（仅本地仓库可真正提供；远程仓库返回未定义）
method source-dir-for(Str $name, Str $version --> IO::Path) { ... }

# 仓库的唯一标识，用于日志
method id(--> Str) { ... }
