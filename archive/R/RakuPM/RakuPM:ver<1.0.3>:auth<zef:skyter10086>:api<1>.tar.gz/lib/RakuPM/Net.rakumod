# RakuPM::Net — 「这一轮能不能联网」的唯一判定处（离线模式）
#
# 【为什么需要它】
# 0.49.5 把「索引拉取失败且无缓存」从 die 改成降级，解决的是「网络不好时别崩」。
# 但那是**被动兜底**。真正缺的是**主动**的「这轮根本别联网」：
#   · 国内网络下 cpan / rea 挂在 raw.githubusercontent.com 上，本就不可达，
#     每次命令都去撞一遍、每次重试 3 轮退避，纯属浪费时间；
#   · CI 要确定性（不该因为上游索引变了就构建出不同的结果）；
#   · 演示 / 教学时不希望意外打到公网。
# 于是有 `--offline`（等价 `RAKUPM_OFFLINE=1`）。
#
# 【为什么是独立模块，而不是 Client 的一个属性】
# 网络出口分属三层、彼此不共享同一个 Client 实例：
#   · `RakuPM::HTTP`           —— 索引与 tarball 下载的底层门面
#   · `Repository::Ecosystem`  —— 决定「要不要去拉索引」
#   · `Client::Git`            —— git 是子进程，不走 HTTP 门面
# 只能有一个**进程级**的判定处。而且声明式读 `%*ENV` 有个直接好处：
# **测试可以用词法遮蔽 `%*ENV` 来开 / 关它**，不必去改进程的真实环境
# （与 `RakuPM::Platform` 里「函数调用时才读 `$*DISTRO`」同一套路，
# 也正是那套遮蔽测试能跑起来的前提）。
#
# 【取值语义】只有**明确为真**才算开：1 / true / yes / on（大小写不敏感）。
# 特别地 `RAKUPM_OFFLINE=0` 与空串都算**关** —— 否则「关掉」只能靠 unset，
# 而 shell 里 `export RAKUPM_OFFLINE=$FLAG` 传空值（或传 0）是很常见的写法，
# 那种情况下把用户带进离线的静默降级是最糟的。
#
# 本模块零依赖：CLI 要在 `require RakuPM::Client`（整个模块图）之前就知道
# 离线与否，好决定是否打印提示 —— 依赖任何东西都会把冷启动拖慢。

unit module RakuPM::Net;

# 认定为「开」的字面量。用列表而不是 Bool 判断，是为了让 0/no/false 也能关。
#
# 【必须写引号，不能用 <1 true yes on>】词引用会把数字形态的词自动转成
# **IntStr**（实测 `@T.raku` 是 `[IntStr.new(1, "1"), "true", ...]`），
# 而 `(elem)` 用的是 `===`（身份比较），`'1' === IntStr.new(1,"1")` 为 **假** ——
# 于是 `RAKUPM_OFFLINE=1` 这种最常见的写法会被判成「没开」，
# 整个离线开关静默失效（本节作者就是这样踩的：CLI 照常发起了索引请求）。
# 所以：字面量一律带引号，且比较用 `eq`（值比较）而不是 `(elem)`。
my @TRUTHY = ('1', 'true', 'yes', 'on');

# 这一轮是否处于离线模式。
# 值来自 %*ENV，调用时才读 —— 于是测试可以用词法遮蔽 %*ENV 开关它，
# 也能让 CLI 在解析完 --offline 后写进环境、下游立刻可见。
sub offline(--> Bool) is export {
    my $v = %*ENV<RAKUPM_OFFLINE>;
    return False unless $v.defined;
    # .Str 归一：%*ENV 里取出来的可能是带数值含义的对象，别指望它就是 Str。
    my $s = $v.Str.trim.lc;
    return False unless $s.chars;
    my $hit = @TRUTHY.first({ $_ eq $s });
    $hit.defined;
}

# 报错 / 提示文案里统一用它，省得每处各写一遍「怎么关掉」。
sub offline-hint(--> Str) is export {
    '离线模式（--offline / RAKUPM_OFFLINE=1）：要联网请去掉 --offline，'
    ~ '或 unset RAKUPM_OFFLINE';
}

# 网络出口的**硬闸门**。
#
# $what 描述这次请求想干什么（如「拉取索引 https://…」），拼进错误里便于定位。
# 刻意放在 HTTP 门面这一层：三个后端（tinyish / httptiny / 自定义）都要经过它，
# 于是「离线时绝不发出请求」是结构性保证，而不是靠每个调用点自觉 ——
# 调用点忘记判断时，这里会立刻炸出来（吵，但绝不会静默联网）。
sub assert-online(Str $what --> Nil) is export {
    return unless offline();
    die "离线模式：不允许联网，已中止「{$what}」。\n  " ~ offline-hint();
}
