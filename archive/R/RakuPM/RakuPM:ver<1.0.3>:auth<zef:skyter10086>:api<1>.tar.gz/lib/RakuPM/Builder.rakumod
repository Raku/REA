# RakuPM::Builder — 构建阶段（Build.pm / META6 builder）
#
# native 包常在安装前需要编译 C 源、生成 resources/libraries/*.so，
# 这一步由包自带的构建脚本完成。zef 有两种构建机制，这里照搬同样的语义：
#
# 1) 【Legacy Build 文件】（大部分生态包用这种）
#    发行版根目录有 Build.rakumod / Build.pm6 / Build.pm（META6 里【不声明】它）。
#    zef 的 Zef::Service::Shell::LegacyBuild 起 raku 子进程执行：
#        require '<Build 文件绝对路径>';
#        ::('Build').new.build('<发行版根目录>') ?? exit(0) !! exit(1);
#    即约定：Build 文件里要定义一个 Build 类，build 方法返回真/假。
#    cwd 是发行版根目录 —— 构建脚本里所有相对路径都以此为基准。
#
# 2) 【META6 builder 字段】（MakeFromJSON 等，较新）
#    META6.json 写 "builder": "Distribution::Builder::MakeFromJSON"。
#    zef 的 Zef::Service::Shell::DistributionBuilder 起子进程：
#        (require ::(builder)).new(:meta(发行版元数据)).build(发行版根目录)
#    返回真则 exit 0。注意短名 MakeFromJSON 要补全成 Distribution::Builder:: 前缀。
#
# 与 zef 的差异（教学版的取舍，都在注释里写明）：
#   · zef 用异步流式收集输出，我们用 run + :out/:err（简单，输出在结束时一次性回显）；
#   · builder 类本身若是独立包（MakeFromJSON 通常在 build-depends 里），
#     依赖解析由 Client 在构建前补装（ensure-build-deps）。
#
# 【阶段顺序】构建在入 store 之前（生成的资源要被复制进 store），
# 也在跑测试之前（测试可能要用构建产物）—— 与 zef 的 build → test → install 一致。

use RakuPM::Distribution;

unit class RakuPM::Builder;

# 生态惯例的文件名优先级（与 zef 的 !guess-build-file 完全一致）
my @BUILD-FILES = <Build.rakumod Build.pm6 Build.pm>;

# 找到构建文件（没有则 Nil）
method build-file(IO::Path $source --> IO::Path) {
    @BUILD-FILES.map({ $source.add($_) }).first(*.e)
}

# META6 的 builder 字段归一化：短名 MakeFromJSON 补全名（zef 同款兼容逻辑）
method builder-name(RakuPM::Distribution $dist --> Str) {
    my $b = $dist.builder;
    return '' unless $b.defined && $b.trim ne '';
    $b.trim eq 'MakeFromJSON' ?? 'Distribution::Builder::MakeFromJSON' !! $b.trim
}

# 是否需要构建：有 Build 文件，或 META6 声明了 builder
method needs-build(IO::Path $source, RakuPM::Distribution $dist --> Bool) {
    self.build-file($source).defined || self.builder-name($dist) ne ''
}

# 组装「构建事实」，交给 Store.put 落成 store 条目里的 build.json 旁车。
#
# 【为什么要专门记这个】
# 构建是唯一一个「失败了却可能完全不留痕」的阶段。原因在 Store.!meta6-for：
# 它只声明磁盘上【真实存在】的资源（声明了却找不到会让 CUR::Installation 装不上），
# 于是「构建没跑成功 → 声明过的 resources 压根没生成」在 store 的 META6.json 里
# 被静默剔除 —— 事后 `raku-pm verify` 看到的是一份"干净"的元数据，查无可查。
# 把事实单独记一份，「被剔除的是什么」就有据可依了。
#
# :$mode 取值（verify 靠它区分四种情形）：
#   'built'              真的跑了构建（:$ok 表示成败）
#   'skipped-no-build'   用户传了 --no-build 主动跳过
#   'not-needed'         这个包压根不需要构建
#   'not-recorded'       调用方没提供事实（Store.put 被直接调用，如测试/其它路径）
method facts(IO::Path $source, RakuPM::Distribution $dist,
             Str :$mode = 'not-recorded', Bool :$ran = False, Bool :$ok = False --> Hash) {
    my $bf = self.build-file($source);
    %(
        mode    => $mode,
        needed  => self.needs-build($source, $dist),
        ran     => $ran,
        ok      => $ok,
        builder => self.builder-name($dist),
        # 有的包走 Legacy Build 文件而不是 builder 字段，两个都记，便于对账
        file    => $bf.defined ?? $bf.basename !! '',
        raku    => $*EXECUTABLE.Str,
    )
}

# 执行构建。返回 True/False（False = 构建失败，调用方应中止安装）。
# :repo-spec 传 Installer.raku-lib-spec（inst#<target>/site）——
# Build 脚本里 use 的依赖（如 LibraryMake）从这里加载：自底向上安装保证了
# 该包的 runtime 依赖此刻已经装好。
# :pending-spec 传 Installer.pending-lib-spec（整树事务化期间的暂存 CUR）——
# 它必须作为【独立的 -I】注入，排在真实 site 之前：构建依赖（build-depends）
# 此刻只装进了暂存 CUR、尚未晋升，若不单独给这条 -I，构建脚本 `use` 不到它
#（0.60.0 修复：早先把它与 repo-spec 用空格拼成一个串，Rakudo 不会拆分，
# 导致暂存依赖在构建子进程里解析不到）。
method run(RakuPM::Distribution $dist, IO::Path $source,
           Str :$repo-spec = '', Str :$pending-spec = '',
           Bool :$quiet = False --> Bool) {

    my $bf = self.build-file($source);
    my $bn = self.builder-name($dist);
    return True unless $bf.defined || $bn ne '';
    die "构建目标目录不存在：{$source}" unless $source.d;

    # -I 搜索路径：包自己的 lib + 暂存 CUR（构建依赖所在）+ 已装依赖所在的 site 仓库
    my $lib = $source.add('lib');
    my @inc;
    @inc.push('-I', $lib.Str) if $lib.d;
    @inc.push('-I', $pending-spec) if $pending-spec ne '';
    @inc.push('-I', $repo-spec) if $repo-spec ne '';

    my ($cmd, $label);
    if $bf.defined {
        # —— Legacy：require Build 文件，调 ::('Build').new.build(<dist 路径>)
        my $esc     = self!quote($bf.absolute);
        my $esc-src = self!quote($source.absolute);
        $cmd   = "require '$esc'; ::('Build').new.build('$esc-src')"
               ~ " ?? exit(0) !! exit(1);";
        $label = $bf.basename;
    }
    else {
        # —— META6 builder：new(:meta(元数据)).build(<dist 路径>)
        # 元数据用 Distribution::Path 从源码目录现读（builder 类可能要用
        # META6 里的非标准字段，比如 MakeFromJSON 的 "build" 哈希）。
        my $meta-file = $source.add('META6.json');
        die "{$dist.name}：META6 声明了 builder '$bn' 但找不到 META6.json"
            unless $meta-file.e;

        my $esc-src  = self!quote($source.absolute);
        my $esc-meta = self!quote($meta-file.absolute);
        # builder 名同样要转义，且别用 q|...| 做分隔符：
        # 它来自 META6.json 的 "builder" 字段，名字里含 | 就会提前闭合分隔符，
        # 后半截被当成代码拼进 -e（恶意包可注入）。统一走单引号 + !quote。
        my $esc-bn   = self!quote($bn);
        $cmd   = "exit((require ::('$esc-bn')).new("
               ~ ":meta(Distribution::Path.new('$esc-src'.IO,"
               ~ ":meta-file('$esc-meta'.IO)).meta.hash)"
               ~ ").build('$esc-src') ?? 0 !! 1);";
        $label = $bn;
    }

    # :quiet 静默模式：预期失败的调用方（比如测试里的「构建返回 False」用例）
    # 不该把 die 的堆栈回溯喷到输出里 —— zef install . 跑测试套件时那些
    # "boom" 堆栈会原样出现在用户面前，看着像出了大事，其实测试是过的。
    say "  · 构建：{$dist.name} {$dist.version}（$label）" unless $quiet;
    my $proc = run('raku', |@inc, '-e', $cmd,
                   :cwd($source.Str), :out, :err);
    my $out-text = '';
    my $err-text = '';
    if $quiet {
        # 仍要读完管道（防子进程写满缓冲区卡死），只是不回显
        $out-text = $proc.out.slurp(:close);
        $err-text = $proc.err.slurp(:close);
    }
    else {
        # 构建脚本往往打进度信息，原样回显（带 | 前缀区分是我们的转发）
        $out-text = $proc.out.slurp(:close);
        for $out-text.lines -> $l { say "    | $l" }
        $err-text = $proc.err.slurp(:close);
        note "    ! $err-text".trim-trailing if $err-text.trim ne '';
    }
    my $ok = $proc.exitcode == 0;
    # 失败时给一句人话提示：native 包最常见的失败原因是缺 -dev 系统包，
    # 但报错只有一行 "fatal error: libxml/tree.h: No such file or directory"，
    # 不看明白的人只会以为包坏了（用户的 LibXML 现场：缺 libxml2-dev）。
    self!hint-missing-dev-deps($out-text ~ "\n" ~ $err-text) unless $ok || $quiet;
    $ok
}

# 构建输出里若出现「缺 C 头文件」，提示去装对应的 -dev 系统包。
# 只做字符串匹配，不猜包名（各发行版包名不同，猜错更误导）。
method !hint-missing-dev-deps(Str $output --> Nil) {
    my @missing;
    for $output.lines -> $l {
        next unless $l.contains('fatal error:')
                 && $l.contains('.h')
                 && $l.contains('No such file');
        my $i = $l.index('fatal error:');
        next unless $i.defined;
        my $rest = $l.substr($i + 12).trim;
        $rest .= subst(/^ '<' /, '');                 # <libxml/tree.h>
        my $h = $rest.split(':')[0].trim;
        @missing.push($h) if $h.ends-with('.h');
    }
    @missing .= unique;
    return unless @missing.elems;

    note "";
    note "  💡 症结像是【缺 C 头文件】—— native 包编译时要先有对应的 -dev 系统包：";
    for @missing -> $h { note "       缺 {$h}" }
    note "       这不是 raku-pm 或这个包坏了，先用系统包管理器装好再重试。";
    note "       例：Debian/Ubuntu 上 libxml/tree.h 对应 libxml2-dev。";
    note "       已声明的本地库依赖可用 `raku-pm native --installed` 查看。";
}

# 把路径塞进 Raku 单引号字符串前要转义的字符：反斜杠 + 单引号。
# 【顺序不能反】必须先把 \ 转义成 \\，再把 ' 转义成 \'：
#   · 先 ' 后 \ 的话，刚生成的 \' 里的 \ 会被二次转义成 \\，引号又裸了。
#   · 不转义 \ 的话，路径以反斜杠结尾时（C:\Users\user\、盘符根 C:\）
#     末尾的 \ 会和收尾的 ' 连成 \' —— 被解析成【转义的引号】，字符串
#     没闭合，生成的 -e 代码直接编译失败（实测 exit=1 / ===SORRY!===）。
#     Windows 路径必然含 \，所以这不是理论边界，是必现 bug。
# 用 chr(39) / chr(92) 写字面量，避免源码里引号与反斜杠的嵌套地狱。
method !quote(Str $p --> Str) {
    my $bs = chr(92);   # \
    my $q  = chr(39);   # '
    $p.trans([$bs, $q] => [$bs ~ $bs, $bs ~ $q])
}
