# raku-pm — 一个教学用 Raku 包管理器
#
# 命令：
#   install <模块> [约束] [--version=X] [--locked] [--no-test] [--no-build] [--no-test-deps] [--no-native-check] [--dry]
#                                                               安装模块及依赖
#   install <git-url> [--locked] [--no-test] [--no-build] [--no-test-deps] [--dry]  从 git 仓库安装（含依赖）
#   version                                                      显示版本号
#   version <模块>                                        查该模块已装/激活版本
#   native <本地库>…                                             检查系统本地库是否可用
#   upgrade [--dry]                                       升级所有已装包（不加名 = 全部）
#   upgrade <模块名> [--version=X] [--only] [--dry]         升级/降级；不给 --version 就取最新
#   uninstall <模块名> [--version=X] [--keep-store]         卸载；不给 --version 就卸所有版本
#                                                         （默认连 store 源码快照一起清，不用再 clean；
#                                                          --keep-store 才保留快照供秒级离线重装；
#                                                          还有包依赖它时会拒绝；--recursive 一并卸、--force 强卸）
#   rdepends <包或模块名>                                  反查谁依赖了它
#   depends <模块>                                         显示完整依赖树（rdepends 的反面）
#   test [路径]                                            只跑测试、不安装
#   build [路径]                                           只跑构建、不安装
#   look <模块> [--shell]                                  取源码进目录看
#   autoremove                                            回收不再被依赖的包
#   self-upgrade [--from=<git-url>] [--from-dir=<目录>] [--dry]
#                                                          升级 raku-pm 自身（默认 gitee 上游；
#                                                          两阶段自举：取到源码后由新版代码执行安装）
#   self-remove [--dry]                                   卸载 raku-pm 自身（含快照与 wrapper）
#
#   卸载 raku-pm 时注意：如果 zef 也曾装过，那份不在我们管理范围内，
#   卸完 `raku-pm` 命令可能仍然存在（会跑 zef 装的那份）。
#
#   降级的坑：Raku 的 `use Foo`（不带版本约束）永远加载**最高**版本，
#   所以装一个更旧的版本默认不会让 use 切过去，只会多一份并存。
#   要让旧版真的生效，加 --only（先卸掉更高的版本），
#   或在代码里写 use Foo:ver<旧版>。
#   list                                                         仓库可安装的包
#   installed [模块名]                                           已安装（多版本全列出，可只看一个）
#   env                                                          打印 RAKULIB 该怎么设（含 wrapper 体检）
#   which [模块名]                                               查这个包实际从哪个仓库加载 / 跨仓库冲突总览
#   store [模块名]                                                查看本地存储（可只看一个，附完整路径）
#   lock                                                         查看锁文件
#   verify [--content] [--fix]                                    校验：内容完整性 + 安装一致性
#   generations                                                  列出安装世代（原子安装留下的可回滚快照）
#   rollback [世代号]                                             退回上一世代（不给 = 上一个，给 = 指定那个）
#   outdated                                                      列出可升级的已装包（只读）
#   doctor                                                        一次性体检（RAKULIB / PATH / 残留暂存 / 一致性 / 版本）
#   completions <bash|zsh|fish|pwsh>                              生成 shell 补全脚本
#
# 目录布局：
#   $RAKUPM_TARGET/
#     ├── store/<name>/<version>/    包存储（多版本共存）
#     ├── site/                      ★ 模块搜索路径：CompUnit::Repository::Installation
#     │                                多版本并存，use Foo:ver<1.2.3> 由 Rakudo 自己解析
#     ├── git-cache/                 git 安装的 clone 缓存
#     ├── log/<name>/<version>/      测试输出日志（每个测试文件一份，重装覆盖）
#     ├── installed.json             已安装清单
#     └── raku-pm.lock               锁文件（注：CLI 默认把锁写在当前工作目录，见下方「锁文件」段；
#                                    仅当直接以 target 为锁位置、且不经过 CLI 时落在这里）
#
# 注意：包装在 site/ 里，要让 raku 找得到必须设
#   RAKULIB="inst#$RAKUPM_TARGET/site"      ← 用 `raku-pm env` 生成
# `inst#` 前缀不能省，少了它 Rakudo 会把 site/ 当普通目录，版本元数据就读不出来了。
#
# 设计上仿 zef 的分层架构：
#   bin/raku-pm (CLI) → RakuPM::Client (编排) → Resolver + Store + Installer + Lock

# RakuPM::Client 特意不在顶部 use —— 它会拖起整条模块图（Resolver / Store /
# Installer / Builder / Lock / …），冷编译要好几秒。`raku-pm version` / help
# 根本用不到它，却在每次调用都付这笔钱 —— 这正是 version 卡顿（每次升级后
# 新 store 快照目录的首跑都要冷编译）的主因。改为在 MAIN 里确定需要时 require
# （见 $client 构造点）；version 在那之前就 exit（一个模块都不编），help 只加载
# 轻量的 RakuPM::Help（不碰 Client 那条重图）。
unit module RakuPM::CLI;

use RakuPM::NativeLib;
use RakuPM::Platform;  # --os 的取值校验（零依赖，冷启动无负担）
use RakuPM::Spec;      # 规格串解析（Foo:ver<1.2.3> / Foo@1.2.3）—— 零依赖，冷启动无负担
use RakuPM::Prefix;    # 前缀解析（--target / RAKUPM_TARGET / 默认）—— 零依赖，同上
use RakuPM::Net;       # 离线开关（--offline / RAKUPM_OFFLINE）—— 零依赖，同上
use RakuPM::CliCheck;   # H11 冷启动自检（RAKULIB 遮蔽）—— 零依赖，同上
use RakuPM::UI;         # 终端展示层（色彩 / 表格）—— 零依赖，冷启动无负担
use RakuPM::CliSpec;    # 命令元数据（旗标 / 别名 / 分组 / 补全）—— 唯一事实来源，零依赖
use RakuPM::Message;    # 用户面消息与退出码（措辞 / 语义的唯一出口）—— 零依赖
use JSON::Fast;

# raku-pm 自己的版本号。单一事实来源是 META6.json：
#   · 开发模式：META6.json 就在脚本旁边两级（repo 根）；
#   · zef 安装模式：脚本在 site/bin，旁边没有 META6.json，
#     改从仓库链上已装的 RakuPM 发行版元数据里读（site/home/vendor 都在链上）。
sub raku-pm-version(--> Str) {
    my $meta = $*PROGRAM.parent(2).add('META6.json');
    if $meta.e {
        my $m = try from-json($meta.slurp);
        return $m<version>.Str if $m ~~ Associative && $m<version>;
    }
    for $*REPO.repo-chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        for $repo.installed -> $d {
            # 必须先 // '' 再比较：`eq` 是【字符串】比较，会对左操作数调 .Str；
            # 某些已装发行版的 meta 里没有 name 字段，遍历到它就喷
            # "Use of Nil in string context"（Linux 上实测，每次 `raku-pm version`
            # 都多一行警告）。用 // '' 兜住 undefined，语义不变、输出干净。
            next unless (($d.meta<name> // '') eq 'RakuPM');
            return ($d.meta<version> // $d.meta<ver> // 'unknown');
        }
    }
    'unknown'
}

# raku-pm 当前这份是否来自某个 git 仓库？返回仓库根目录（绝对路径），否则 ''。
# 目前只有 preflight 用它（它要在 raku-pm 源码仓库里跑）；self-upgrade 自 0.83.0 起
# 不再依赖它 —— 那条「当前在 git 仓库里就就地 pull 当前仓库」的路径已删除。
sub raku-pm-git-root(--> Str) {
    my $p = $*PROGRAM.parent;
    for ^12 {
        return $p.absolute if $p.add('.git').d || $p.add('.git').e;
        my $up = $p.parent;
        last if $up eq $p;
        $p = $up;
    }
    ''
}

# 判断一个 install 参数是「本地路径」还是「模块名」。
# 模块名永远不会以 . / ~ 开头、也不会是已存在的目录，所以这几条判据是安全的。
# Windows 的 C:\... 靠最后的 .IO.d 兜住（try 包一下，防模块名里的 :: 惹事）。
sub looks-like-path(Str $s --> Bool) {
    return True if $s.starts-with('.') || $s.starts-with('/') || $s.starts-with('~');
    return True if try { $s.IO.d };
    False
}


# help 分级渲染：默认紧凑命令索引；给命令名看它的详情；all 给完整手册。
# 惰性 require RakuPM::Help —— help 正文已抽到该模块（可 precomp；bin 因此瘦身，
# 冷编译更快）。别的命令走不到这里，不会为它付加载成本。
sub print-help(*@topic) {
    # 注：Raku 的 require 之后【全限定名】调不到 is export 的 sub（实测
    # `RakuPM::Help::help-summary()` 报 Could not find symbol），必须带导入列表
    # 把符号拉进本作用域。
    require RakuPM::Help <&help-summary &help-command &help-all &help-group>;
    if @topic.elems && @topic[0] eq 'all' {
        print ui-banner() ~ ui-colorize-help(help-all());
        return;
    }
    if @topic.elems {
        my Str $c    = @topic[0];
        my Str $text = help-command($c);
        if $text.chars {
            print ui-banner() ~ ui-colorize-help($text);
            return;
        }
        # 不是命令？再试分组名（author / 作者侧 / dev …）—— `raku-pm help author`
        # 给该组总览。命令优先：将来若真出现与组名同名的命令，命令语义更具体，先赢。
        my Str $grp = help-group($c);
        if $grp.chars {
            print ui-banner() ~ ui-colorize-help($grp);
            return;
        }
        msg-error "没有名为 '{$c}' 的命令或分组";
        msg-hint  "  查看全部命令：raku-pm help";
        msg-hint  "  查看某一组：raku-pm help author（也可 packages / repos / env / self / dev）";
        exit EXIT-FAIL;
    }
    print ui-banner() ~ ui-colorize-help(help-summary());
}

# 注：入口刻意叫 run-cli 而【不是】run —— 本模块内部多处调用 Raku 内建的 run()
# 起子进程；若在这里定义 `sub run`，会把内建 run 遮蔽掉，那些调用会静默变成
# 「再跑一遍 CLI」（0.79.0 首次重构就踩了这个坑，被 xt/preflight.t 抓到：
# preflight 转调 run-suite 时变成了 `raku-pm raku tools/run-suite.raku …`）。
our sub run-cli(*@args, *%early) is export {
    # H11（2026-09-17）：冷启动第一件事 —— 加载链上若有多个不同版本的 RakuPM，
    # 提示用户（典型坑：RAKULIB / 多个 site 指向旧版，跑着旧版却以为新版）。
    # 纯警告，零代价，不拖 Client 模块图；必须在 `require RakuPM::Client` 之前跑。
    check-rakulib-shadowing();

    # 【为什么要 *%early】Raku 的 MAIN 会把【命令位之前】的 `--flag` 当成命名参数：
    #   · 不声明 *% 的话，`raku-pm --target=/x install Foo` 会被 Raku 判成 USAGE；
    #   · 更糟的是某些形态（`--help-`、任意未知长旗标）会直接抛一句莫名的内部错误
    #     "rindex search target requires a concrete string, but got null"，
    #     用户完全看不出是自己旗标写错了位置（v0.41.4 及以前一直如此）。
    # 用 *%early 接住它们，再合并进 %opts，于是「旗标写在命令前 / 后」等价，
    # 拼错也能被下面的白名单校验给出人话报错。
    #
    # --no-color 必须在任何输出【之前】生效：下面三处 help 分支都早于 %opts 的解析，
    # 若不在此处先判一次，`raku-pm --no-color help`（以及 `help --no-color`）会漏掉
    # 横幅与 help 配色。命令位之后的 --no-color 由 @args 里的字面量兜住。
    ui-set-rich(False) if (%early<no-color> // False) || @args.grep({ $_ eq '--no-color' }).elems;
    unless @args {
        # `raku-pm` / `raku-pm --help` / `raku-pm -h` → 帮助；其它【未知】旗标要明确
        # 报错，不能静默打印帮助（那会让用户以为命令执行了）。
        # 注意 `-h` 会被 Raku MAIN 归成短选项 `h` 收进 %early。
        #
        # 【公共旗标必须放行】发行版的 wrapper 每次都会隐式注入 `--target=<前缀>`
        # （见 RakuPM::Installer::ShellTemplates 三份模板都是 `exec raku "$SRC"
        # '--target=…' "$@"`），所以「没有位置参数」不等于「没有旗标」。此前只放行
        # help/-h，导致敲裸 `raku-pm`（wrapper 形态）得到的是「未知选项：--target」
        # 而不是帮助（真实 bug，用户实测）。公共旗标（target / no-lock /
        # promote-bin / no-promote-bin / offline / no-color）都不蕴含某个命令，
        # 故一律放行；只有真·拼错的旗标才报错（防「拼错却静默跑出帮助」）。
        my %common = common-flags().map({ $_ => True });
        my @bad = %early.keys.grep({ !%common{$_} && $_ ne 'help' && $_ ne 'help-' && $_ ne 'h' }).sort;
        if @bad {
            msg-error "未知选项：{@bad.map({ '--' ~ $_ }).join(', ')}";
            msg-hint  "  完整帮助：raku-pm help";
            exit EXIT-FAIL;
        }
        print-help();
        exit EXIT-OK;
    }

    my $cmd = @args.shift;

    # 简写别名归一化：让 `raku-pm i Foo` 等价于 `raku-pm install Foo`。
    # 别名表是唯一事实来源（见 RakuPM::CliSpec）；在此处一次性归一化成规范名，
    # 之后 help / version / allowed-flags / given 派发全部只看规范命令名，
    # 别名绝不导致任何分支重复或漂移。
    $cmd = canonical-command($cmd);

    # 注：`--help` / `-h` 在 zef 生成的 wrapper 层会被 `*%` 命名参数吃掉（走 Raku
    # 默认 USAGE，传不进来）；直接跑本脚本时则由上面的 *%early 接住。所以这两种
    # 情形与 `help` 子命令都要走帮助。
    if $cmd eq 'help' | '?' | '--help-' | '--help' | '-h' {
        print-help(|@args);
        exit EXIT-OK;
    }

    if $cmd eq 'version' && !@args {
        say "raku-pm v{raku-pm-version()}";
        say "raku {$*RAKU.version()} on {$*VM.name}";
        exit EXIT-OK;
    }

    my $repo-root = %*ENV<RAKUPM_REPO>   // '.';

    # 解析 --key 或 --key=value 形式的选项
    my (%opts, @positional);
    for @args -> $a {
        if $a.starts-with('--') {
            my ($k, $v) = $a.substr(2).split('=', 2);
            %opts{$k} = $v // True;
        }
        else {
            @positional.push($a);
        }
    }

    # 把命令位【之前】的旗标（Raku MAIN 收进 %early）并进来 —— 两个位置从此等价。
    # 命令位之后的写法优先（同名时以 %opts 为准）。
    for %early.kv -> $k, $v { %opts{$k} = $v unless %opts{$k}:exists }

    # 任何情况下都允许要帮助（zef 生成的 wrapper 用 `*%` 吃掉了 --help，
    # 所以约定用 `--help-` 绕过它 —— 见 help 文案）。
    # `-h` 会被 MAIN 归成短选项 h 收进 %early。
    if %opts<help> || %opts<help-> || %opts<h> {
        print-help();
        exit EXIT-OK;
    }

    # ---- 未知旗标必须报错，不能静默忽略 ----
    # 选项是开放式接收的（任何 --key 都进 %opts），原先从不校验。后果是
    # 拼错旗标完全无声：`raku-pm install Foo --no-tets` 会照常跑测试（用户以为
    # 跳过了）；`--verison=1.2` 被静默丢弃（用户以为装的是 1.2）。
    # 对包管理器这类工具，「参数拼错」的代价很高（装了不该装的、跑了不该跑的），
    # 而且这类错误事后极难联想。所以这里显式挡住，并把可用选项列出来。
    my %allowed = allowed-flags($cmd);
    my @unknown = %opts.keys.grep({ $_.chars && !%allowed{$_} }).sort;
    if @unknown {
        usage-die "未知选项：{@unknown.map({ '--' ~ $_ }).join(', ')}\n"
          ~ "  `raku-pm {$cmd}` 可用选项："
          ~ (%allowed.keys.sort.map({ '--' ~ $_ }).join(', ') || '（本命令没有命名选项）') ~ "\n"
          ~ "  完整帮助：raku-pm help";
    }

    # ---- 色彩开关：--no-color 显式关闭 ----
    # 非 TTY（管道 / 重定向 / 测试捕获）与 NO_COLOR / RAKUPM_NO_COLOR 已由
    # RakuPM::UI 自动降级；这里只是给「在终端里也想临时关掉」的用户一个旗标。
    # 必须在任何 UI 输出之前调用。
    ui-set-rich(False) if %opts<no-color>;

    # ---- 生产侧（作者侧）命令：与安装目标无关，不构造 Client、不进写锁 ----
    # 刻意放在 Client 构造【之前】：它们只操作【当前这个发行版目录】，
    # 不该为了改一个 META6.json 去初始化整条消费侧模块图
    # （target / store / installer / 生态索引缓存）。
    # preflight 是本区唯一的【仓库级】命令（其余都作用于一个发行版目录）：
    # 它转调本仓库的 tools/run-suite.raku —— 与预提交钩子【同一份门禁实现】，
    # 所以这里不复制任何校验逻辑（两套实现必然漂移）。退出码原样透传
    # （run-suite：0 全过 / 1 有失败 / 2 参数错）。
    if $cmd eq 'preflight' {
        my Str $root = raku-pm-git-root();
        if !$root.chars {
            usage-die "preflight 要在 raku-pm 的 git 仓库里跑（向上找不到 .git）；\n"
                    ~ "  它检查的是【这个仓库】的版本纪律 / 具名实参 / 测试。";
        }
        my $suite = $root.IO.add('tools/run-suite.raku');
        if !$suite.f {
            usage-die "找不到 {$suite} —— 这不是 raku-pm 的源码仓库？";
        }
        say "==> 提交前检查：{$root}（当前版本 {raku-pm-version()}）";
        say "    与预提交钩子共用同一份门禁：raku tools/run-suite.raku --no-xt";
        say "";
        my @args = ('raku', $suite.absolute.Str, '--no-xt');
        @args.push("--filter={%opts<filter>}") if %opts<filter> ~~ Str && %opts<filter>.chars;
        @args.push("--jobs={%opts<jobs>}")     if %opts<jobs> ~~ Str && %opts<jobs>.chars;
        # 子进程会直接往 stdout 写：先 flush，否则上面几行会被缓冲压到它后面。
        $*OUT.flush;
        my Int $code = run(|@args, :cwd($root)).exitcode;
        say "";
        say $code == 0
            ?? "✅ 可以提交了（文档纪律 + 具名实参 + t/ 全部通过）"
            !! "❌ 还不能提交：上面有失败项，修好再跑一次。";
        exit $code;
    }

    if $cmd eq 'refresh' {
        my $path = (@positional[0] // '.').IO;
        (require RakuPM::Author).refresh($path, :dry(?%opts<dry>));
        exit EXIT-OK;
    }

    if $cmd eq 'new' {
        usage-die "请指定要创建的模块名，例如：raku-pm new Foo::Bar"
            unless @positional;
        my $name = @positional.shift;
        # 注意：--into/--auth/--version/--bin 未给时是 Any（非 Str），传类型对象/
        # 空 Str 让 scaffold 自己取默认值（--into 传 IO::Path 类型对象 = 未指定）。
        (require RakuPM::Author).scaffold(
            $name,
            :into(%opts<into> ~~ Str ?? %opts<into>.IO !! IO::Path),
            :auth(%opts<auth> ~~ Str ?? %opts<auth> !! Str),
            :version(%opts<version> ~~ Str ?? %opts<version> !! Str),
            :with-readme(?%opts<with-readme>),
            :bin(%opts<bin> ~~ Str ?? %opts<bin> !! Str),
            :force(?%opts<force>),
            :dry(?%opts<dry>),
        );
        exit EXIT-OK;
    }

    if $cmd eq 'check' {
        my $path = (@positional[0] // '.').IO;
        my $r = (require RakuPM::Author).check($path, :remote(?%opts<remote>));
        exit $r<ok> ?? EXIT-OK !! EXIT-FAIL;
    }

    if $cmd eq 'dist' {
        my $path = (@positional[0] // '.').IO;
        (require RakuPM::Author).dist($path,
            :to(%opts<to> ~~ Str ?? %opts<to> !! ''),
            :no-build(?%opts<no-build>),
            :dry(?%opts<dry>),
        );
        exit EXIT-OK;
    }

    if $cmd eq 'bump' {
        # 位置参数：像版本号（v?N.N.N）就当 --to，否则当目录
        my $bump-dir = '.';
        # --to=X.Y.Z 也要生效：此前这里只认【位置参数】里的版本号，`bump --to=0.73.0`
        # 被静默忽略 → 退化成 patch（0.72.7→0.72.8），而 help 明确写了 `--to=` ——
        # 是真实缺陷（Author.bump 本就支持 :to）。此处补上；位置参数仍优先。
        my $bump-to  = %opts<to> ~~ Str ?? %opts<to> !! '';
        if @positional {
            my $p = @positional[0];
            if $p ~~ /^ 'v'? <[0..9]>+ [ '.' <[0..9]>+ ]* $/ {
                $bump-to = $p;
            }
            else {
                $bump-dir = $p;
            }
        }
        (require RakuPM::Author).bump($bump-dir.IO,
            :to($bump-to),
            :major(?%opts<major>),
            :minor(?%opts<minor>),
            :date(%opts<date> ~~ Str ?? %opts<date> !! ''),
            :dry(?%opts<dry>),
            :no-sync-docs(?%opts<no-sync-docs>),
        );
        exit EXIT-OK;
    }

    if $cmd eq 'login' {
        # 生产侧凭据管理：与安装目标无关，不构造 Client、不进写锁。
        # 选项值是开放式接收的：--api-key=XYZ 收到 Str，裸 --api-key 收到 Bool(True)
        # （无值），后者按「未给」处理、交给 login 报错。
        my $r = (require RakuPM::Author).login(
            :api-key(%opts<api-key> ~~ Str ?? %opts<api-key> !! ''),
            :username(%opts<username> ~~ Str ?? %opts<username> !! ''),
            :password(%opts<password> ~~ Str ?? %opts<password> !! ''),
            :quiet(?%opts<quiet>),
        );
        exit $r<ok> ?? EXIT-OK !! EXIT-FAIL;
    }

    if $cmd eq 'logout' {
        # 作者侧凭据管理：删掉本地保存的 api-key（与 login 配对）。
        # 与安装目标无关 —— 凭据文件由 RakuPM::Author.credentials-file 自己按
        # RAKUPM_TARGET / ~/.raku-pm 决定位置，不构造 Client、不进写锁。
        my $r = (require RakuPM::Author).logout();
        if $r<ok> {
            if $r<deleted> {
                say "==> 已注销：删除了本地凭据文件 {$r<path>}";
            }
            else {
                say "==> 本地本来就没有凭据文件（没有已登录的会话）";
            }
        }
        else {
            msg-error "注销失败：{$r<error>}";
        }
        exit $r<ok> ?? EXIT-OK !! EXIT-FAIL;
    }

    if $cmd eq 'publish' {
        # 作者侧部署：把 sdist 解包进本地目录仓库，使其可被 install 解析。
        # 与 new/refresh/check/dist/bump 同待遇——不构造 Client、不进写锁。
        my $path = (@positional[0] // '.').IO;
        my $r = (require RakuPM::Author).publish($path,
            :to(%opts<to> ~~ Str ?? %opts<to> !! ''),
            :from(%opts<from> ~~ Str ?? %opts<from> !! ''),
            :no-build(?%opts<no-build>),
            :force(?%opts<force>),
            :dry(?%opts<dry>),
            :remote(?%opts<remote>),
            :quiet(?%opts<quiet>),
        );
        exit $r<ok> ?? EXIT-OK !! EXIT-FAIL;
    }

    if $cmd eq 'completions' {
        # 生成 shell 补全脚本（只读、不构造 Client、不进写锁）。
        # 命令清单与旗标全部取自 RakuPM::CliSpec，与 allowed-flags 同一事实来源。
        # shell 可以是位置参数（completions bash）或 --shell=bash。
        my $sh = (@positional[0] // '').trim.lc
                    || (%opts<shell> ~~ Str ?? %opts<shell>.trim.lc !! '')
                    || 'bash';
        if $sh !~~ any(< bash zsh fish pwsh powershell >) {
            usage-die "不支持的 shell：$sh（支持 bash / zsh / fish / pwsh）";
        }
        print completion-script($sh);
        exit EXIT-OK;
    }

    # 安装前缀：--target= > 环境变量 RAKUPM_TARGET > 默认 ~/.raku-pm
    # （命令行显式指定优先于环境，两级都允许。）解析逻辑只有 RakuPM::Prefix.resolve
    # 一处实现，CLI 与库调用方共用一个事实来源；它还会展开前导 `~` —— **Rakudo
    # 自己不展开**（'~/.raku-pm'.IO.absolute 得到的是 <当前目录>/~/.raku-pm），
    # 不展开的话 `--target=~/myenv` 会静默装到当前目录下一个字面叫 `~` 的目录里。
    # 注意：--target= 写在命令【前】或【后】都可以（MAIN 用 *%early 接住命令位
    # 之前的旗标再并入 %opts）。早期版本必须写在命令后面，否则会被 Raku MAIN
    # 当成命名参数拦掉 —— 那个限制已消除。
    if %opts<target>:exists && !(%opts<target> ~~ Str && %opts<target>.trim.chars) {
        usage-die "--target 要带路径，写成 --target=<目录>（现在给的是「{%opts<target>}」）";
    }
    # 注意：这里必须用 use 导进来的【词法名】resolve，不能写
    # `RakuPM::Prefix.resolve(...)` —— 那是方法调用语法，会报
    # "No such method 'resolve' for invocant of type 'RakuPM::Prefix'"。
    # （`is export` 的 sub 用全限定名同样不行，见 Platform 里的同类注释。）
    my $target = resolve(
        :flag(%opts<target> ~~ Str ?? %opts<target> !! ''),
        :env(%*ENV<RAKUPM_TARGET> // ''),
    );

    # ---- 锁文件路径（可提交锁文件，0.54.0）----
    # 默认把锁写到【当前工作目录】的 raku-pm.lock，这样它能随项目一起提交进版本库
    # （Cargo.lock 同款语义），实现「换台机器 / 换时间装出完全一样的版本」。
    # 之前锁写在 target/raku-pm.lock（默认全局前缀 ~/.raku-pm）—— 整机共享一份、
    # 没法按项目提交、也不能复现单个项目的依赖闭包。
    #   --lock-file=<路径> 可显式指定（CI 里常钉死到仓库固定位置）。
    # 锁描述的是「项目的依赖闭包」，与安装位置（--target）无关：即使把包装进
    # .raku-env 这种独立前缀，锁仍写在项目根，提交的是锁、不是前缀。
    my $lock-path = %opts<lock-file> ~~ Str && %opts<lock-file>.trim.chars
        ?? native-path(%opts<lock-file>.trim)
        !! $*CWD.add('raku-pm.lock');

    # ---- promote-bin：装完要不要把 wrapper 也复制进 rakudo site/bin ----
    # 那是 zef 用的目录（在 PATH 上，装完命令立即可用、不必改 PATH），但只适合
    # 【默认前缀】：全局 site/bin 是整机共享的，自定义前缀往里写等于让局部安装
    # 污染全局环境，而且多个前缀会互相覆盖 —— 最后 PATH 上那份指向哪个前缀只看
    # 装包顺序（0.47.0 开发时就这样被自己的临时 target 接管过一次）。
    # 所以默认值按前缀算（RakuPM::Prefix.default-promote-bin），两个旗标可显式覆盖。
    if %opts<promote-bin> && %opts<no-promote-bin> {
        usage-die "--promote-bin 与 --no-promote-bin 互斥，只能给一个";
    }
    my $promote;
    if      %opts<promote-bin>    { $promote = True }
    elsif   %opts<no-promote-bin> { $promote = False }
    else                          { $promote = default-promote-bin($target) }

    # 自定义前缀时明确说清「这次不碰全局」，并给出该配什么 —— 否则用户以为
    # 装完敲不到命令是自己装错了。只对【会写前缀】的命令提示，读命令保持干净。
    if writes-prefix($cmd) && !$promote && !%opts<no-promote-bin> {
        say "==> 前缀：{$target.absolute}（非默认）—— 装包只写入这里，不动全局 site/bin";
        say "    用之前把 {$target.add('bin').absolute} 放到 PATH 最前并设 RAKULIB"
          ~ "（`raku-pm env` 会打印这两行）";
        say "    想要 zef 那种「装完即用」：加 --promote-bin（会写入全局 site/bin）";
    }

    # ---- 离线模式：--offline 是 RAKUPM_OFFLINE=1 的等价写法 ----
    # 与 --target / RAKUPM_TARGET 同一套惯例：命令行旗标只是把环境变量固化下来。
    # 三处网络出口（HTTP 门面 / 生态索引 / git 子进程）读的都是 RakuPM::Net
    # 那一个来源 —— 所以「怎么进来的」在实现上不是两条路。
    # 【为什么写进 %*ENV 而不是传参数】git 是子进程、生态索引在别的对象里，
    # 没有一条能把参数递给所有出口的调用链；环境变量本来就是它们的共同上下文。
    %*ENV<RAKUPM_OFFLINE> = '1' if %opts<offline>;
    if offline() {
        # 只对**可能联网**的命令提示。读命令（version / installed / which /
        # env / lock …）本来就只碰本地，多一行提示纯属噪声。
        # 只列【会跑到这里、且靠软提示有意义】的联网命令。
        # 作者侧 refresh/check/publish/new/dist 在更早的 `if $cmd eq` 分支就 exit 0
        # （见 766/791/862 一带），永远不会到达本块 —— 列在这里是死配置，
        # 已移除，避免与真实分流脱节（离线 UX 逻辑集中在这一个来源）。
        if needs-network($cmd) {
            say "==> 离线模式：本轮不联网，只用本地缓存 / 已装内容 / 本地目录仓库";
            say "    要联网：去掉 --offline，或 unset RAKUPM_OFFLINE";
        }
    }

    # 惰性加载模块图：version / help 在更早处已 exit，永远不走这里。
    # require 是幂等的：同进程二次 require 只返回已加载的类型对象。
    my $client = (require RakuPM::Client).new(:repo-root($repo-root), :target($target),
                                              :promote-bin($promote), :lock-path($lock-path));

    # --pin=Mod@ver[,Mod2@ver2]：把钉版规格解析成 模块名 => 版本 的哈希，透传给
    # 解析器（见 RakuPM::Resolver 的 %!pins）。钉版会覆盖依赖方提出的任何约束，
    # 优先级最高；多个用逗号分隔，例如 --pin=JSON::Fast@0.10,URI@0.5。
    my %pins;
    if %opts<pin> ~~ Str && %opts<pin>.trim.chars {
        for %opts<pin>.split(',') -> $pair {
            my ($m, $v) = $pair.split('@', 2);
            unless $m.defined && $v.defined && $m.trim.chars && $v.trim.chars {
                usage-die "无效的 --pin 写法「{$pair.trim}」：应为 Mod\@ver（多个用逗号分隔）";
            }
            %pins{$m.trim} = $v.trim;
        }
    }

    # 写命令统一包一层跨进程文件锁：两个 raku-pm 同时跑会互相踩 store 与
    # installed.json（详见 RakuPM::FileLock）。--no-lock 可跳过。
    sub guarded(Str $what, &block) {
        $client.with-write-lock(&block, :$what, :no-lock(?%opts<no-lock>));
    }

    given $cmd {
        when 'install' {
            usage-die "请指定要安装的模块名、路径或 git URL" unless @positional;
            my $spec = @positional.shift;
            # git URL：clone 下来当源码目录装（会递归解析依赖）
            # git:// 开头也要认 —— 老式 Raku 生态习惯写 git://… 且未必带 .git
            if $spec ~~ /^ https? '://' / || $spec ~~ /^ 'git@' / || $spec ~~ /^ 'git://' /
               || ($spec ~~ /'.git' $/ && !$spec.IO.e) {
                guarded("install $spec", {
                $client.install-from-git(
                    $spec,
                    :locked(?%opts<locked>),
                    :dry(?%opts<dry>),
                    :no-test(?%opts<no-test>),
                    :no-build(?%opts<no-build>),
                    :no-test-deps(?%opts<no-test-deps>),
                    :no-native-check(?%opts<no-native-check>),
                    :force(?%opts<force>),
                    :allow-test-failure(?%opts<allow-test-failure>),
                    :test-timeout(%opts<test-timeout> ~~ Str ?? %opts<test-timeout>.Int !! 0),
                    :%pins,
                );
                });
            }
            # 本地路径：对应 zef 的 `zef install .`
            elsif looks-like-path($spec) {
                guarded("install $spec", {
                $client.install-from-dir(
                    $spec.IO,
                    :locked(?%opts<locked>),
                    :dry(?%opts<dry>),
                    :no-test(?%opts<no-test>),
                    :no-build(?%opts<no-build>),
                    :no-test-deps(?%opts<no-test-deps>),
                    :no-native-check(?%opts<no-native-check>),
                    :force(?%opts<force>),
                    :allow-test-failure(?%opts<allow-test-failure>),
                    :test-timeout(%opts<test-timeout> ~~ Str ?? %opts<test-timeout>.Int !! 0),
                    :%pins,
                );
                });
            }
            else {
                # 解析 zef 风格规格串：Foo:ver<1.2.3>:auth<x> 或 Foo@1.2.3
                # 解析器在 RakuPM::Spec（顶部已 use，零依赖不拖模块图）。
                # 以前这里用 require RakuPM::Distribution 再调它的 parse-spec ——
                # 现在 parse-spec 只是委托 RakuPM::Spec 的壳，直接用 Spec。
                my %s = RakuPM::Spec.parse($spec);
                my $module = %s<module>;
                # 约束来源优先级：规格里的 :ver<> > 命令行位置参数
                my $constraint = %s<ver>.chars
                    ?? %s<ver>
                    !! (@positional.elems ?? @positional.join(' ') !! '');
                guarded("install $module", {
                $client.install(
                    $module,
                    $constraint,
                    :version(%opts<version> ~~ Str ?? %opts<version> !! Str),
                    :auth(%s<auth>),
                    :locked(?%opts<locked>),
                    :dry(?%opts<dry>),
                    :no-test(?%opts<no-test>),
                    :no-build(?%opts<no-build>),
                    :no-test-deps(?%opts<no-test-deps>),
                    :no-native-check(?%opts<no-native-check>),
                    :force(?%opts<force>),
                    :allow-test-failure(?%opts<allow-test-failure>),
                    :test-timeout(%opts<test-timeout> ~~ Str ?? %opts<test-timeout>.Int !! 0),
                    :%pins,
                );
                });
            }
        }
        when 'version' {
            usage-die "请指定模块名，如：raku-pm version DB（查看 raku-pm 自身用 `raku-pm version`）"
                unless @positional;
            # 查询命令也认规格串：version 'Foo:ver<1.0>' 只看满足约束的版本
            my %s = RakuPM::Spec.parse(@positional[0]);
            $client.module-version(%s<module>, :constraint(%s<ver>));
        }
        when 'upgrade' {
            # 不带包名 = 更新所有已装包（zef upgrade / apt upgrade / npm update 的惯例）。
            # 只更新自己请显式写：raku-pm upgrade RakuPM
            unless @positional {
                # A2：升级全部偏激进（教学场景可能拉不兼容版本）。跑前给一句醒目提示，
                # 非阻塞（不要求输入，避免卡 CI / 脚本）；--dry 只试算不会真改，故不提示。
                unless %opts<dry> {
                    say "==> 注意：未指定包名，将升级【全部已装包】到最新版";
                    say "    · 可能引入不兼容变更；要可复现请用 install --locked 或锁文件";
                    say "    · 只升某个包请显式写：raku-pm upgrade <包名>";
                    say "    · 仅试跑（不改动）加 --dry";
                }
                guarded('upgrade-all', { $client.upgrade-all(:dry(?%opts<dry>)) });
                exit EXIT-OK;
            }
            guarded("upgrade @positional[0]", {
            $client.upgrade(@positional[0],
                            :version(%opts<version> ~~ Str ?? %opts<version> !! ''),
                            :only(?%opts<only>),
                            :dry(?%opts<dry>));
            });
        }
        when 'fetch' {
            # 只取源码不安装。用于填充本地目录仓库：
            #   raku-pm fetch Foo --to=~/my-dists && raku-pm repos add ~/my-dists
            usage-die "请指定要获取的模块名，例如：raku-pm fetch Foo --to=./my-dists"
                unless @positional;
            # fetch 也认规格串：fetch 'Foo:ver<1.2+>' / fetch 'Foo@1.2.3'
            # 精确度优先级与 install 一致：--version > 规格串里的 :ver<>
            my %s = RakuPM::Spec.parse(@positional[0]);
            guarded("fetch %s<module>", {
            $client.fetch(%s<module>,
                          :to(%opts<to> ~~ Str ?? %opts<to> !! '.'),
                          :version(%opts<version> ~~ Str ?? %opts<version> !! ''),
                          :constraint(%s<ver>));
            });
        }
        when 'search' {
            usage-die "请指定搜索关键词" unless @positional;
            # search 内部先做规格串解析：'JSON::Fast:ver<1.0+>' 的名字部分当
            # 关键词、版本当筛选；不像规格串就整串当关键词（行为与旧版一致）
            $client.search(@positional.join(' '));
        }
        when 'uninstall' {
            # 不带包名绝不能"默认卸载自己" —— 少打一个参数就把包管理器删了，
            # 属于破坏性的隐式行为。要卸自己就显式写出名字。
            usage-die "请指定要卸载的模块名，例如：raku-pm uninstall Foo\n"
              ~ "  只卸某个版本：raku-pm uninstall Foo --version=0.1\n"
              ~ "  卸一批（semver 范围）：raku-pm uninstall Foo --version='<1.0'\n"
              ~ "    （也支持区间 >=1.0,<2.0、通配 *、以及 npm 风格糖语法 ^1.0 / ~1.2）\n"
              ~ "  默认连 store 源码快照一起清（不用再 clean）；保留快照供秒级重装加 --keep-store\n"
              ~ "  卸载 raku-pm 自身：raku-pm uninstall RakuPM（需显式写出名字）"
              unless @positional;
            guarded("uninstall @positional[0]", {
            $client.uninstall(@positional[0],
                              :version(%opts<version> ~~ Str ?? %opts<version> !! ''),
                              :force(?%opts<force>),
                              :recursive(?%opts<recursive>),
                              :keep-store(?%opts<keep-store>));
            });
        }
        when 'reinstall' {
            # 重装已装的包（卸掉再按完全相同版本装回）。只认包名 / 它提供的模块名，
            # 不认 git URL / 本地路径（那种用 uninstall + install … 即可）。
            # 完全没装过则退化为一次普通 install。
            usage-die "请指定要重装的包名，例如：raku-pm reinstall Foo\n"
              ~ "  只重装某个版本：raku-pm reinstall Foo --version=1.0.0"
                unless @positional;
            my %s = RakuPM::Spec.parse(@positional[0]);
            guarded("reinstall %s<module>", {
                $client.reinstall(%s<module>, %s<ver>,
                    # 与上面 install 同款：没给 --version 时传【未定义】的 Str，而不是
                    # 空串。Client 侧（reinstall 与 install 都是）用 `.defined` 判断
                    # "有没有指定版本"，空串会被当成"指定了空版本" → 退化成 install
                    # 时得到 `"= "` 约束 → 报"找不到模块"。
                    :version(%opts<version> ~~ Str ?? %opts<version> !! Str),
                    :auth(%s<auth>),
                    :force(?%opts<force>),
                    :recursive(?%opts<recursive>),
                    :dry(?%opts<dry>),
                    :no-test(?%opts<no-test>),
                    :no-build(?%opts<no-build>),
                    :no-test-deps(?%opts<no-test-deps>),
                    :no-native-check(?%opts<no-native-check>),
                    :allow-test-failure(?%opts<allow-test-failure>),
                    :test-timeout(%opts<test-timeout> ~~ Str ?? %opts<test-timeout>.Int !! 0),
                    :%pins);
            });
        }
        when 'rdepends' | 'rdeps' {
            usage-die "请指定要反查的包（或模块）名，例如：raku-pm rdepends GDBM"
              unless @positional;
            $client.show-rdepends(@positional[0]);
        }
        when 'depends' {
            # 正向依赖树（rdepends 的反面）。也认规格串：depends 'Foo:ver<1.0>'
            usage-die "请指定要查的模块或包名，例如：raku-pm depends GDBM\n"
              ~ "  （它只查仓库里的发行版；本地已装的包用 installed / rdepends 看）"
              unless @positional;
            my %s = RakuPM::Spec.parse(@positional[0]);
            $client.show-depends(%s<module>, :constraint(%s<ver>));
        }
        when 'test' {
            # 只跑测试、不安装（对应 zef test .）。默认路径 = 当前目录，
            # 与 zef 需要显式给 `.` 不同 —— 这个命令的常见用法就是「在当前包里跑」。
            my $p = @positional.elems ?? @positional[0] !! '.';
            $client.test-dir($p.IO,
                :allow-test-failure(?%opts<allow-test-failure>),
                :test-timeout(%opts<test-timeout> ~~ Str ?? %opts<test-timeout>.Int !! 0));
        }
        when 'build' {
            my $p = @positional.elems ?? @positional[0] !! '.';
            $client.build-dir($p.IO);
        }
        when 'look' {
            # 取源码进目录看（对应 zef look）。默认只打印路径，--shell 才进交互 shell。
            usage-die "请指定要看的模块名，例如：raku-pm look GDBM" unless @positional;
            my %s = RakuPM::Spec.parse(@positional[0]);
            $client.look(%s<module>,
                         :version(%opts<version> ~~ Str ?? %opts<version> !! ''),
                         :constraint(%s<ver>),
                         :shell(?%opts<shell>));
        }
        when 'info' {
            # 显示发行版详情（仿 zef info）。仓库里没有的本地包退回到已装账本。
            usage-die "请指定要查的包名，例如：raku-pm info JSON::Fast\n" unless @positional;
            my %s = RakuPM::Spec.parse(@positional[0]);
            $client.show-info(@positional[0], :constraint(%s<ver>));
        }
        when 'browse' {
            # 在浏览器打开发行版主页 / 源码（仿 zef browse）。
            usage-die "请指定要打开主页的包名，例如：raku-pm browse JSON::Fast\n" unless @positional;
            my %s = RakuPM::Spec.parse(@positional[0]);
            $client.browse(@positional[0], :constraint(%s<ver>));
        }
        when 'locate' {
            # 定位模块在磁盘上的真实位置（仿 zef locate）。
            usage-die "请指定要定位的【模块名】，例如：raku-pm locate JSON::Fast\n" unless @positional;
            $client.locate(@positional[0]);
        }
        when 'why' {
            # 依赖解析诊断：讲清楚「为什么解析到这个版本 / 冲突的双方约束」。
            # 只读、不写锁、不改账本，纯解释（仿 zef 没有、但 npm ls / cargo tree 有）。
            usage-die "请指定要诊断的模块（或包）名，例如：raku-pm why JSON::Fast\n"
              ~ "  （可给多个模块一起诊断，以暴露依赖冲突的双方约束）"
              unless @positional;
            $client.show-why(@positional, :%pins);
        }
        when 'smoke' {
            # 冒烟测试：取源码并跑测试（仿 zef smoke）。不给规格则测全部已装。
            my @specs = @positional.map(*.Str);
            $client.smoke(|@specs,
                :allow-test-failure(?%opts<allow-test-failure>),
                :test-timeout(%opts<test-timeout> ~~ Str ?? %opts<test-timeout>.Int !! 0));
        }
        when 'autoremove' {
            guarded("autoremove", {
                $client.autoremove(:dry(?%opts<dry>));
            });
        }
        when 'self-upgrade' {
            # 升级 raku-pm 自己。
            #   --from <url>      ：从指定 git 远端拉取源码升级（默认 gitee 上游）；
            #   --from-dir <目录> ：直接用本地源码目录升级（不 clone）。它也是
            #                       两阶段自举第二阶段的入口：外层先 clone 到缓存，
            #                       再用缓存里【新版】的 bin 重跑本命令，让新版代码
            #                       自己装自己 —— 避免旧版安装链逻辑装不动新版。
            #   不传上述两者时：从默认上游（gitee）拉取升级。
            my $from     = %opts<from> ~~ Str ?? %opts<from> !! '';
            my $from-dir = %opts<from-dir> ~~ Str ?? %opts<from-dir> !! '';

            # 透传给【自举子进程】的参数。
            #   · --target 必带：写锁是按 target 定位的（<target>/.raku-pm.run.lock），
            #     子进程必须锁同一个文件，才能凭父进程下发的 token 免锁放行
            #     （见 RakuPM::FileLock.should-bypass）；顺带保证装到同一前缀。
            #   · 其余只在用户显式给了才透传，避免把默认值固化下去。
            my @passthru = ('--target=' ~ $target.absolute);
            @passthru.push('--lock-file=' ~ $lock-path.absolute)
                if %opts<lock-file> ~~ Str && %opts<lock-file>.trim.chars;
            @passthru.push('--promote-bin')    if %opts<promote-bin>;
            @passthru.push('--no-promote-bin') if %opts<no-promote-bin>;
            @passthru.push('--offline')        if offline();

            guarded('self-upgrade', {
            $client.self-upgrade(:current(raku-pm-version()),
                                 :dry(?%opts<dry>), :$from,
                                 :$from-dir, :force(?%opts<force>),
                                 :no-test(?%opts<no-test>),
                                 :passthru(@passthru));
            });
        }
        when 'self-remove' {
            # 卸载 raku-pm 自己（含 store 快照与 bin wrapper）。
            # 想先看会删什么就加 --dry。
            guarded('self-remove', { $client.self-remove(:dry(?%opts<dry>)) });
        }
        when 'update' {
            # 顶层别名：刷新仓库索引（与 `repos update` 同义；无参刷新全部）。
            # 对应 zef 的 `zef update`（更新包列表），不是升级已装包
            # （升级用 `upgrade`）。--offline 下会走 needs-network 判定的离线提示分支。
            guarded('update', {
                $client.update-repos(@positional[0] // '');
            });
        }
        when 'repos' {
            my $sub = @positional.shift // 'list';
            given $sub {
                when 'list' | 'ls' { $client.list-repos; }
                when 'add' {
                    usage-die "请指定要添加的仓库：别名 / URL / 本地目录\n"
                      ~ "  例：repos add rea            （生态索引别名）\n"
                      ~ "      repos add https://...    （生态索引 URL）\n"
                      ~ "      repos add ./my-dists     （本地目录，目录即索引）"
                        unless @positional;
                    # --name= 只在添加【本地目录】时有意义（目录名不好看时可自起）
                    my $nm = %opts<name> ~~ Str ?? %opts<name> !! '';
                    guarded("repos add @positional[0]", {
                        $client.add-repo(@positional[0], :name($nm));
                    });
                }
                when 'remove' | 'rm' | 'del' {
                    usage-die "请指定要移除的仓库名字或 URL" unless @positional;
                    guarded("repos remove @positional[0]", {
                        $client.remove-repo(@positional[0]);
                    });
                }
                when 'update' {
                    # 不加名字更新全部索引；加名字只更新那一个
                    guarded('repos update', {
                        $client.update-repos(@positional[0] // '');
                    });
                }
                default { usage-die "未知的 repos 子命令 '$sub'（list / add / remove / update）"; }
            }
        }
        when 'clean' | 'gc' {
            # 回收缓存（store 历史版本 / 下载缓存 / 残骸 …）。
            # 默认只试算不删 —— 删文件不可撤销，必须显式 --yes。
            guarded('clean', {
                $client.clean(
                    :all(?%opts<all>),
                    :yes(?(%opts<yes> // %opts<force>)),
                    :older-than(%opts<older-than> ~~ Str ?? %opts<older-than>.Int !! 0),
                    :name(%opts<name> ~~ Str ?? %opts<name> !! ''),
                );
            });
        }
        when 'flush' {
            # 全清：清掉当前前缀里 raku-pm 装过的一切（含它自己的入口），
            # 回到「可以重新安装」的状态。与 clean 的区别：
            #   clean = 有保护的回收（只动没被引用的版本，默认还留着索引/克隆缓存）
            #   flush = 无保护的清空（整个前缀 + 自装入口），只为「从零重来」
            # 删文件不可撤销 → 默认只试算，--yes 才真删（与 clean 同一约定）。
            guarded('flush', {
                $client.flush(:yes(?(%opts<yes> // %opts<force>)));
            });
        }
        when 'native' {
            # 本地库（:from<native>）探测。os / distro 可强制指定，
            # 便于不切机器就查另一套系统该装什么。
            my $os     = %opts<os>     ~~ Str ?? %opts<os>     !! '';
            my $distro = %opts<distro> ~~ Str ?? %opts<distro> !! '';
            # --os 只认三个平台键（含 windows / macos / osx 等别名）。拼错必须
            # 明确报错：Platform.resolve-os 对认不出的值会回落成「本机」，那就成了
            # 「用户以为在查 Windows、其实查的是本机」—— 静默判错平台比报错更糟。
            if $os.chars && !normalize-os-key($os).chars {
                usage-die "无法识别的 --os=「{$os}」：只认 win32 / windows、"
                  ~ "darwin / macos / osx、linux / unix";
            }
            my $nl = RakuPM::NativeLib.new(:os($os), :distro($distro));

            my @libs = @positional;
            if %opts<installed> {
                @libs = (|@libs, |$client.lock.native-libs).unique;
            }
            unless @libs {
                usage-die "请指定本地库逻辑名（如 sqlite3），" ~
                    "或用 --installed 扫描已装发行版声明的本地库";
            }

            say "系统：{$nl.os-label}    包管理器族：{$nl.package-key}";
            say "";
            for $nl.check(@libs) -> $r {
                if $r<found> {
                    say "  ✓ {$r<name>}   {$r<path>}";
                }
                else {
                    say "  ✗ {$r<name>}   未找到（本系统需要 {$r<files>}）";
                    say "      安装：{$r<hint>}";
                }
            }

            if %opts<paths> {
                say "";
                say "搜索路径（{$nl.search-paths.elems} 个，* 表示目录存在）：";
                for $nl.search-paths -> $p {
                    say "    {$p.IO.d ?? '*' !! ' '} $p";
                }
            }
        }
        when 'list'      { $client.list-available; }
        when 'installed' {
            # 认规格串：installed 'Foo:ver<1.0>' 只看满足约束的版本，
            # installed 'Foo:auth<zef:x>' 再按作者筛
            my %s = @positional.elems ?? RakuPM::Spec.parse(@positional[0])
                                     !! %( module => '', ver => '', auth => '' );
            $client.list-installed(:name(%s<module>),
                                   :constraint(%s<ver>), :auth(%s<auth>));
        }
        when 'env'       { $client.show-env; }
        when 'shell'     { $client.shell-env(:shell(%opts<shell> // '')); }
        when 'which'     {
            # 不带参数 = 跨仓库冲突总览；带【模块名】= 这个模块实际从哪个仓库加载
            $client.show-which(@positional.elems ?? @positional[0] !! '');
        }
        when 'store'     {
            # 认规格串：store 'Foo:ver<1.0>' 只看满足约束的缓存版本
            my %s = @positional.elems ?? RakuPM::Spec.parse(@positional[0])
                                     !! %( module => '', ver => '' );
            $client.show-store(%s<module>, :constraint(%s<ver>),
                               :verify(?%opts<verify>));
        }
        when 'lock'      { $client.show-lock; }
        when 'verify'    { $client.verify-all(:content-only(?%opts<content>),
                                              :fix(?%opts<fix>)); }
        when 'outdated'  { $client.outdated; }
        when 'doctor'    { $client.doctor; }
        when 'generations' | 'gens' { $client.list-generations; }
        when 'rollback' {
            # 写命令：包进跨进程文件锁（会改 CUR 与账本）
            my $to = @positional.elems ?? @positional[0] !! '';
            guarded("rollback", { $client.rollback($to) });
        }
        default          { usage-die "未知命令 '$cmd'（试试 `raku-pm help`）"; }
    }

    # 顶层兜底：业务失败（测试未过 / 本地库缺失 / 用法错误等）只印干净消息，
    # 不打印内部调用栈——否则用户会看到一大段 "in method … at … line …" 的崩溃信息。
    # 要排查真正的内部 bug，设 RAKUPM_DEBUG=1 重跑即可看到完整栈。
    CATCH {
        default {
            msg-error .message;
            if %*ENV<RAKUPM_DEBUG> {
                msg-hint "";
                msg-hint "--- 调试栈（RAKUPM_DEBUG 开启）---";
                msg-hint .backtrace.Str;
            }
            exit EXIT-FAIL;
        }
    }
}
