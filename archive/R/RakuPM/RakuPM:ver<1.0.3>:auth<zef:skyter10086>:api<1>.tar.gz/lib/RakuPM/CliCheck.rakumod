# RakuPM::CliCheck — CLI 冷启动时的轻量自检（H11，2026-09-17）
#
# 解决的问题：加载链（$*REPO.repo-chain）上若出现【多个不同版本】的 RakuPM，
# 说明全局 RAKULIB / 多个 site（cur / home / vendor）指向了不同版本，
# `require RakuPM::Client` 实际加载的那份未必是用户以为的那份 —— 典型坑：
# 装了新版、却因 RAKULIB 指向旧 site 而一直跑着旧版（表现成「version 显示新版、
# 行为却是旧版」）。
#
# 为什么只查「能对 .installed 响应」的仓库：开发模式里 bin 顶部 `use lib <repo>/lib`
# 会前置一个 FileSystem 仓库（装的是仓库里这份 RakuPM），它【不响应】.installed，
# 自动被排除，不会在开发期产生误报。真正会互相遮蔽的，是安装型仓库（inst# / cur /
# home / vendor，以及 RAKULIB 指向的那份）—— 它们都响应 .installed。
#
# 零代价：$*REPO 是语言级动态变量，随时可读；本模块零依赖，不拖起 Client 那条
# 模块图（否则会毁掉 `raku-pm version` / help 的冷启动速度）。
#
# 设计取舍：单一版本（哪怕来自多个仓库）不算遮蔽，静默；同一仓库内的多版本
# （CUR::Installation 天然多版本共存，Rakudo 永远按 semver 取最高，无害）也静默；
# 只有【跨仓库出现不同版本】——链序靠前的仓库赢、靠后的新版可能被永久遮蔽——
# 才打扰用户。这是一个纯警告，不改变任何加载行为。

unit module RakuPM::CliCheck;

sub check-rakulib-shadowing(:$chain = $*REPO.repo-chain --> Nil) is export {
    # 按「仓库」归集该仓库里出现的 RakuPM 版本集合。
    # 区分单仓库多版本（无害）与跨仓库多版本（遮蔽风险）的关键：前者只命中一个
    # 仓库，后者命中 ≥2 个仓库。
    my %repo-versions;   # repo-path(Str) => %( version(Str) => True )
    for $chain.list -> $repo {
        # 不响应 .installed 的仓库（FileSystem / NQP / Perl5 / …）一律跳过：
        # 它们要么不是安装型仓库，要么是开发期 lib，不算遮蔽来源。
        next unless $repo.defined && $repo.can('installed');
        my $where = $repo.can('path') ?? $repo.path.Str !! $repo.Str;
        for (try $repo.installed // []) -> $d {
            next unless $d.defined;
            # 先 // '' 再比较：meta 缺 name 时 `eq` 会对左操作数调 .Str 喷
            # "Use of Nil in string context"。用 // '' 兜住，语义不变、输出干净。
            next unless (($d.meta<name> // '') eq 'RakuPM');
            my $v = ($d.meta<version> // $d.meta<ver> // 'unknown').Str;
            %repo-versions{$where}{$v} = True;
        }
    }
    # 含 RakuPM 的仓库不足 2 个：零个、或仅一个仓库（哪怕它内部多版本也无害）→ 静默。
    my @repos = %repo-versions.keys;
    return if @repos.elems < 2;
    # 合并所有版本去重；同版本散落多仓库（如 0.54.1 在 home 与 vendor 各一份）不算遮蔽。
    my $all-versions = (@repos.map({ %repo-versions{$_}.keys }).flat).unique;
    return if $all-versions.elems <= 1;

    # 跨仓库 + 多版本：链序靠前的仓库赢，靠后的新版可能被永久遮蔽。
    note "⚠  加载链上检测到多个 RakuPM 版本（分属不同 site 仓库）：";
    for %repo-versions.kv -> $where, %vs {
        next unless %vs.elems;
        note "    · {$where}：v{ %vs.keys.sort.join(', v') }";
    }
    note "   本进程会加载链上最前的那份（raku-pm version 显示的就是它）。";
    note "   若与预期不符，多半是全局 RAKULIB / 多个 site 指向了旧版 raku-pm 目录。";
    note "   （同一 site 仓库内的多版本由 Rakudo 自动取最高，无需处理。）";
}
