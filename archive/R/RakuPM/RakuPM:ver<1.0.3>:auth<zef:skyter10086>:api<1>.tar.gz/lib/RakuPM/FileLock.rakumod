# RakuPM::FileLock — 跨进程互斥锁（flock）
#
# 为什么需要：raku-pm 的一次安装是「读 installed.json → 解析依赖 → 写 store
# → 写 site → 回写 installed.json」这一长串写操作，两个进程同时跑就会互相踩：
#   · 同时往 store 里放同一个版本 → 半份文件，指纹对不上（下次 verify 必失败）
#   · 同时回写 installed.json → 后写的把先写的整份冲掉（装过的信息凭空消失）
#   · 同时 promote bin / 装进 site → wrapper 指向还没写完的路径
#
# 为什么用 flock 而不是「锁文件存在就算锁住」：
#   进程被 kill、Ctrl+C、机器重启时，flock 由操作系统回收（Unix 上是
#   fd 关闭即释放，Windows 上是 LockFileEx 同样随句柄关闭释放），
#   不会留下永久卡死的陈旧锁 —— 也就不需要「检测陈旧锁并强删」这套易错逻辑。
#
# 语义：
#   · 独占锁，非阻塞轮询 + 超时（默认 10 分钟），超时就明确报错而不是无限等；
#   · 同一进程内可重入（install 内部还会调 install 之类），用计数管理，
#     只有最外层 release 才真正 unlock —— 否则嵌套释放会把外层的锁提前交出去；
#   · 锁文件里写的是持有者信息（PID / 在做什么 / 开始时间），纯粹给报错和
#     排查用，锁本身由内核保证。

use RakuPM::Fs;
unit class RakuPM::FileLock;

# 进程内重入表：绝对路径 => 句柄 + 引用计数。
# 用绝对路径做 key，两个 FileLock 实例指向同一个文件（比如 Client 里 new 两次）
# 也能正确共享同一把锁。
my class Held {
    has IO::Handle $.fh;
    has Int        $.count is rw;
}
my %HELD;

# 持有者给自己派生的【子进程】下的凭证（锁的继承令牌）。
#
# 与 RAKUPM_NO_LOCK 的区别是本机制的要害：
#   · RAKUPM_NO_LOCK 是【用户】的逃生舱 —— 用户显式要求跳过锁，设了就生效；
#   · RAKUPM_LOCK_TOKEN 是【程序】的凭证 —— 子进程光"有这个变量"进不了门，
#     必须 token 与盘上一致、且锁【此刻】真的被占着（见 should-bypass）。
# 0.44.0 之前两者共用 RAKUPM_NO_LOCK 那一个布尔开关，等于"给所有人开门"：
# 任何继承了该变量的进程都自动获得 bypass 权限，连在锁内跑的测试也把锁
# 当没加（真锁从未持起，3 条断言恒真 —— 假绿）。
# 这是内部协议，不在 README 的常规环境变量表里宣传。
my constant ENV-TOKEN = 'RAKUPM_LOCK_TOKEN';

# 凭证的进程内序号（同一纳秒内连开两把锁也不会撞上）
my $SEQ = 0;

has IO::Path $.path is required;   # 锁文件路径
has IO::Path $.owner-path;         # 持有者信息（旁路灯，见下）
has Str      $.info = '';          # 拿到锁后写进 owner-path 的持有者信息
has Bool     $.acquired = False;

method !key(--> Str) { $!path.absolute }

# 持有者信息为什么不写在锁文件里：Windows 的 LockFileEx 是**强制锁**——
# 进程 A 持锁时，连 A 自己用另一个句柄读这个文件都会被拒（Permission denied），
# 更别说想告诉用户「谁在占着」的 B 进程了。所以另开一个不受锁保护的旁路文件
# （锁文件名 + .owner），内容与锁同步维护，纯粹给排查用。
submethod TWEAK {
    $!owner-path //= $!path.parent.add($!path.basename ~ '.owner');
}

# 获取锁。成功返回；拿不到就一直等到 $timeout 秒，然后 die。
#   :$timeout = 0 且 :$wait 为真 → 只试一次，失败立刻报错
method acquire(Str :$what = 'raku-pm 操作', Int :$timeout = 600, Bool :$wait = True --> Nil) {
    return if $!acquired;                 # 同一实例重复 acquire：忽略

    my $k = self!key;
    if %HELD{$k} {                        # 同一进程内已经拿着了 → 只加计数
        %HELD{$k}.count++;
        $!acquired = True;
        return;
    }

    mkdir-p($!path.parent) unless $!path.parent.e;
    my $fh = $!path.open(:a);             # :a —— 文件不存在时创建

    my $deadline  = now + $timeout;
    my $started   = now;
    my $last-note = Nil;
    loop {
        last if self!try-lock($fh);

        if !$wait || now >= $deadline {
            my $busy = self!owner-info;
            $fh.close;
            $!acquired = False;
            die "另一个 raku-pm 正在修改 {$!path.parent.absolute}，拿不到文件锁。\n"
              ~ ($busy.chars ?? "  持有者：{$busy}\n" !! '')
              ~ "  已等待 {($timeout max 0)} 秒。确认没有别的 raku-pm 在跑之后，\n"
              ~ "  可以删掉 {$!path.absolute} 再试，或用 --no-lock 强行继续\n"
              ~ "  （并发写会损坏 store 与 installed.json，仅在确认无并发时使用）。";
        }

        # 第一次等待就告诉用户「在等」，之后每 15 秒提醒一次，别刷屏
        if !$last-note.defined {
            note "⏳ 另一个 raku-pm 正在写入 {$!path.parent.absolute}，等待它结束…";
            $last-note = now;
        }
        elsif now - $last-note >= 15 {
            note "⏳ 仍在等待另一个 raku-pm —— 已等 { (now - $started).Int } 秒"
               ~ "（不想等可以 Ctrl+C，或用 --no-lock 强行继续）。";
            $last-note = now;
        }
        sleep 0.25;
    }

    %HELD{$k} = Held.new(:$fh, :count(1));
    $!acquired = True;

    # 给【本进程随后派生的子进程】下凭证：Build.pm / 测试里再调 raku-pm 时，
    # 它们带着这个 token 回来，should-bypass 校验通过才免锁放行。
    # 凭证同时落到锁旁边的 .token 文件（供子进程核对）与环境变量（供继承）。
    self!publish-token;

    # 写持有者信息（失败无所谓 —— 锁本身由内核保证，这只是给人看的）
    self!write-info($what);
}

# 非阻塞地试一次；成功 True，被别人占着 False
# （Rakudo 在拿不到非阻塞锁时抛 X::IO::Lock，这里统一吞成布尔值）
method !try-lock(IO::Handle $fh --> Bool) {
    (try { $fh.lock(:non-blocking); True }) // False
}

method !write-info(Str $what --> Nil) {
    my $stamp = DateTime.new(now.Int).Str.subst(/\.\d+ $/, '');
    $!info = "pid={$*PID}  {$what}  started {$stamp}";
    try { $!owner-path.spurt($!info ~ "\n") }
}

# 最近一次持有者（给报错用的诊断信息），读不到就空串。
# 注意是「最近一次」：锁已释放但文件还在时，这里说的可能是上一个持有者。
method !owner-info(--> Str) {
    ($!owner-path.e ?? (try { $!owner-path.slurp } // '') !! '').trim
}

# 释放锁。可重入：计数归零才真正 unlock。
method release(--> Nil) {
    return unless $!acquired;
    $!acquired = False;

    my $k = self!key;
    my $h = %HELD{$k};
    return unless $h;                     # 理论上到不了：acquired 但未登记

    $h.count--;
    return if $h.count > 0;               # 还有内层在用它

    %HELD{$k}:delete;
    self!clear-token;                     # 凭证随锁一起作废：晚到的子进程必须老实排队
    try { $h.fh.unlock }
    try { $h.fh.close }
}

# ---- 锁的继承凭证（见 ENV-TOKEN 的说明）----

# 凭证文件：锁文件旁边，同名 + .token。
# 为什么不塞进锁文件本身：Windows 的 LockFileEx 是强制锁，持有者之外的进程
# 连【读】锁文件都会被拒（Permission denied），而子进程恰恰必须能读它。
# 同款理由见上面 owner 旁路灯的注释。
method !token-path(--> IO::Path) {
    $!path.parent.add($!path.basename ~ '.token')
}

# 生成凭证值。只需在「本次持锁期间」唯一即可，不承担密码学强度 —— 它的作用是
# 让子进程能证明「占着这把锁的正是把我派出来的那个进程」，而不是一个谁都能
# 随手设一下的布尔开关。
method !new-token(--> Str) {
    $SEQ++;
    "{$*PID}-{now.Int}-{$SEQ}-{(rand * 1_000_000).Int}"
}

method !publish-token(--> Nil) {
    my $token = self!new-token;
    try { self!token-path.spurt($token) }
    %*ENV{ENV-TOKEN} = $token;
}

method !clear-token(--> Nil) {
    try { self!token-path.unlink }
    %*ENV{ENV-TOKEN}:delete;
}

# ---- 供编排层（Client）用的判定 ----

# 判定「本进程是某个持锁进程派生出来的后代，可以免锁直接执行」。
#
# 三件事必须同时成立，缺一不可 —— 这是与「设个 RAKUPM_NO_LOCK=1 就开门」的
# 本质区别（那条老路让任何继承了环境的进程自动获得 bypass 权限，连用户手动
# 设一下都能绕过锁）：
#   1. 环境里带着 token（父进程持锁时下的凭证）；
#   2. 盘上的 token 与它一致（占着锁的确实就是给我凭证的那个进程）；
#   3. 锁【此刻】真的被占（凭证只在持锁期间有效 —— 父进程一放锁就作废，
#      晚到的子进程不会凭一张过期凭证进门）。
method should-bypass(IO::Path $path --> Bool) {
    return False if %HELD{$path.absolute};   # 同进程重入：交给 acquire 的引用计数

    my $env = %*ENV{ENV-TOKEN};
    return False unless $env.defined && $env.chars;

    my $tok-path = $path.parent.add($path.basename ~ '.token');
    return False unless $tok-path.e;
    my $disk = ((try { $tok-path.slurp }) // '').trim;
    return False unless $disk.chars && $disk eq $env;

    self.held-by-other($path)
}

# 非阻塞探一次锁：被【别的进程】占着返回 True，否则 False。
# 探到就立刻还回去 —— 只用来判「此刻有没有人占」，不改变归属。
method held-by-other(IO::Path $path --> Bool) {
    return False if %HELD{$path.absolute};   # 本进程占着的不算「别人」
    try { mkdir-p($path.parent) unless $path.parent.e }
    my $fh = (try { $path.open(:a) }) // Nil;
    return False unless $fh.defined;         # 打不开就当没人占，让调用方走正常取锁
    my $got = ((try { $fh.lock(:non-blocking); True }) // False);
    if $got { try { $fh.unlock } }
    try { $fh.close }
    $got ?? False !! True
}

# 方便写法：$lock.hold({ ... }) —— 离开作用域（含抛异常）自动释放
method hold(&block, Str :$what = 'raku-pm 操作', Int :$timeout = 600, Bool :$wait = True) {
    self.acquire(:$what, :$timeout, :$wait);
    LEAVE { self.release }
    &block()
}

# 进程退出兜底：正常流程走 release，这里防的是「忘记释放」或异常路径
submethod DESTROY { self.release }
