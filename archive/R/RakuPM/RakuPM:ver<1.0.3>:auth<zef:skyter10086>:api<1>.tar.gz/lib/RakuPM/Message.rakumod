# RakuPM::Message — 用户面消息与退出码（「说什么、用什么退出码」的唯一出口）
#
# ── 与 RakuPM::UI 的分工（必须守住，否则两个模块会互相打架）──────────────
#   · RakuPM::UI      —— 管【怎么显示】：颜色、表格、显示宽度、非 TTY 降级
#   · RakuPM::Message —— 管【说什么、以什么身份说】：措辞、语义分级、退出码
# Message 需要上色时**调 UI 的函数**，不得自己拼 ANSI 转义 —— 否则「NO_COLOR /
# 非 TTY 自动降级」这条约束会在 Message 这里漏出一个口子。
#
# ── 退出码语义（沿用历史，勿轻改）────────────────────────────────────
#   0  成功。含「`raku-pm` 无参数打印帮助」「help」「completions」这类纯查询。
#   1  失败。**业务失败与用法错共用**：
#        · 用法错：未知选项 / 未知命令 / 缺参数 / 互斥旗标 / --target 格式
#        · 业务失败：测试未过 / 本地依赖库缺失 / 依赖冲突 / 账本损坏
#   历史上两者都是 1（`die` 的默认退出码），脚本已经依赖这一行为，所以本轮
#   **不拆分成 2**。将来若真要区分，只需改本模块的 EXIT-* 与 usage-die/fail-die
#   两处 —— 这正是把它们显式化（而不是散落 20 多个裸 `die`）的意义。
#
#   失败信息一律走**终端 stderr**（`note`），正常输出才走 stdout：
#   这样 `raku-pm installed > out.txt` 不会把报错混进数据里。
unit module RakuPM::Message;

# 退出码常量（CLI 用它们，别在 bin 里写裸数字 —— 裸数字改起来要全文搜）。
constant EXIT-OK    is export = 0;
constant EXIT-FAIL  is export = 1;

# ---------------------------------------------------------------------------
# 分层出口。四条路的**当前实现**都等价于原来的裸写法（die / note），
# 抽出来是为了让「这是什么性质的问题」显式可见，且将来要统一前缀 / 语气 / 退出码时
# 只改这一处。
# ---------------------------------------------------------------------------

# 用法错：用户把命令敲错了（未知选项、缺参数、旗标互斥…）。
# 调用点保持原文案不变 —— 本轮是收口，不是改文案。
sub usage-die(Str $msg --> Nil) is export {
    die $msg;
}

# 业务失败：命令用对了，但事情没办成（测试没过、依赖库缺失、账本损坏…）。
sub fail-die(Str $msg --> Nil) is export {
    die $msg;
}

# 错误 / 警告 / 提示 —— 都写 stderr，与正常输出分流。
sub msg-error(Str $msg --> Nil) is export { note $msg }
sub msg-warn(Str $msg --> Nil)  is export { note $msg }
sub msg-hint(Str $msg --> Nil)  is export { note $msg }
