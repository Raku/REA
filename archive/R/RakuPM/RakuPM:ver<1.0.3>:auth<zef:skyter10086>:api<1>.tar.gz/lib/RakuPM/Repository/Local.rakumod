# RakuPM::Repository::Local — 本地目录仓库
#
# 一个目录下每个子目录是一个「发行版」，里面带 META6.json（0.37.0 起只认 META6.json）。
# 用于安装本地开发中的包（zef install . 那种场景）。

use RakuPM::Distribution;
use RakuPM::Repository;
use JSON::Fast;

unit class RakuPM::Repository::Local does RakuPM::Repository;

has IO::Path $.root is required;
# 仓库名（配置里给的）。多本地仓库时 search 结果靠它区分来自哪个仓库；
# 缺省 'local' 对应那条内置的 local:. 目录仓库。
has Str $.name = 'local';

# 索引的进程内缓存。!index 要扫目录 + 解析每个 META*.json，而这个仓库对象
# 在一次 install 里会被问 7 次（find-providers / available-versions /
# versions-providing / source-dir-for / search-rows / all-distributions …），
# 每次全量重扫纯属浪费 —— Ecosystem 那边早就用 $!loaded 做了同样的事。
# 目录内容中途变了（比如往仓库里放了新包）就调 refresh 清掉。
has %!idx-cache;
has Bool $!indexed = False;

method id(--> Str) { "local:{$!root}" }

# 丢弃缓存，下次 !index 重新扫描目录。
# 对齐 Ecosystem.refresh 的语义（那边是「重新拉远端索引」）。
method refresh(--> Nil) {
    $!indexed = False;
    %!idx-cache = %();
}

# 扫描 root 下所有含 META*.json 的子目录，构建索引。
# 只认 Raku 标准 META6.json（0.37.0 起不再回退 META.json：第三方包永远只有 META6.json）。
# 注意：目录名不重要，身份由 meta 文件里的 name+version 决定。
# 这样同一个发行版的多个版本可以放在任意目录（如 JSON/ 与 JSON2/）。
method !index(--> Hash) {
    return %!idx-cache if $!indexed;
    my %providers;                     # module => @dist-names
    my %dist-version;                  # dist-name => @versions
    my %dist-meta;                     # dist-name => @metas (每个版本一份)
    my %source-dir;                    # "name\0version" => 源码目录

    if $!root.d {
        for $!root.dir.grep(*.d) -> $dir {
            # 只认 Raku 标准 META6.json（0.37.0 起：不再把 META.json 当同义文件，
            # 第三方包永远只有 META6.json；回退读一个本不该存在的 META.json 只会
            # 误把杂散 / 无关文件当发行版）。
            my $meta = $dir.add('META6.json');
            my $parser = 'from-meta6-file';
            next unless $meta.e;

            # 目录仓库要容忍杂散/损坏的 META6 文件：某个子目录里的 META6.json
            # 可能不是发行版元数据（比如把生态索引整个 dump 进去的数组），
            # 解析失败时跳过该目录，别让一个坏文件拖垮整个 install。
            my $dist;
            try {
                $dist = RakuPM::Distribution."$parser"($meta);
                CATCH {
                    default {
                        note "raku-pm: 忽略无法解析的本地 META 文件 {$meta}：{.message}";
                    }
                }
            }
            next unless $dist.defined;
            my $name = $dist.name;
            %dist-meta{$name}.push($dist);
            %dist-version{$name}.push($dist.version);
            %source-dir{"$name\0{$dist.version}"} = $dir;
            for @(($dist.provides) // []) -> $mod {
                %providers{$mod}.push($name);
            }
        }

        # 仓库根上自己就是一个发行版（META6.json 在根目录）也收录。
        #
        # 之前只扫子目录，于是「指向一个正在开发的单个包的目录」永远看不见它：
        # 站在 raku-pm 源码仓库根目录里 `search RakuPM` 会报"未找到"——
        # RakuPM 没发布到任何生态索引，local:. 又看不见根上的 META6.json。
        # 现在两种布局都认：容器目录（repo/DistA/META6.json）与单包目录
        # （my-pkg/META6.json）。根上没有 META 文件时行为与以前完全一致。
        my $root-meta = $!root.add('META6.json');
        if $root-meta.e {
            # 根目录自己的 META6.json 也可能是坏文件（典型：把生态索引数组当成了
            # META6.json）。解析失败就跳过、别拖垮 install。
            my $dist;
            try {
                $dist = RakuPM::Distribution.from-meta6-file($root-meta);
                CATCH {
                    default {
                        note "raku-pm: 忽略无法解析的本地 META 文件 {$root-meta}：{.message}";
                    }
                }
            }
            if $dist.defined {
                my $name   = $dist.name;
                %dist-meta{$name}.push($dist);
                %dist-version{$name}.push($dist.version);
                %source-dir{"$name\0{$dist.version}"} = $!root;
                for @(($dist.provides) // []) -> $mod {
                    %providers{$mod}.push($name);
                }
            }
        }
    }
    %!idx-cache = %(providers => %providers, versions => %dist-version,
                    metas => %dist-meta, source-dirs => %source-dir);
    $!indexed = True;
    %!idx-cache
}

# 某发行版某版本的源码目录（仓库内部才知道布局，不该由 Client 猜）
method source-dir-for(Str $name, Str $version --> IO::Path) {
    my %idx = self!index;
    %idx<source-dirs>{"$name\0$version"} // IO::Path
}

method find-providers(Str $module --> List) {
    my %idx = self!index;
    my @p = @(%idx<providers>{$module} // []);
    # 发行版名依赖：目录里的发行版名与依赖名相同也算提供（对齐 Ecosystem）
    @p.push($module) if $module (elem) %idx<versions>;
    @p.unique.List
}

method all-distributions(--> List) {
    my %idx = self!index;
    %idx<versions>.keys.List
}

# search 子命令用：返回匹配关键词的发行版精简记录。
#
# 必须与 Ecosystem.search-rows 同契约（name/version/auth/description/repo），
# 否则 Client.search 里的 `next unless $repo.can('search-rows')` 会把本地仓库
# 整个跳过 —— 结果就是：本地目录仓库里明明有的包（本地开发的、自己放进去的），
# `raku-pm list` 看得到（它走 all-distributions），`raku-pm search` 却搜不到，
# 两个命令对同一批包给出不一致的答案。
#
# 匹配范围含【发行名 + provided 模块名】：本地发行版的目录名常与模块名不同
# （目录 Web-App/ 提供模块 Web::App），只按发行版名搜会漏掉用户真正记得的名字。
# 判定逻辑（等级 + 不扫 description）由 RakuPM::Repository::Matching 统一提供，
# 与 Ecosystem.search-rows 完全同源 —— 改一处两边同步。
method search-rows(Str $q --> List) {
    my %idx = self!index;
    my @out;
    for %idx<metas>.kv -> $name, @metas {
        for @metas -> $d {
            # 匹配与相关度分级统一走 RakuPM::Repository::Matching（基 role 组合而来），
            # 与 Ecosystem.search-rows 是同一份实现 —— 不再是本类内联的一套。
            # 只按【发行名 + provided 模块名】匹配，不扫 description（描述常写
            # 「method xxx」，扫它会把方法名误当成匹配项、结果过宽）。
            my $score = self.match-score($name, @($d.provides // []), $q);
            next unless $score.defined;
            @out.push(%( name        => $name,
                         version     => $d.version,
                         auth        => $d.auth // '',
                         description => $d.description // '',
                         repo        => $!name,
                         _score      => $score ));
        }
    }
    @out.List
}

# 完整 META6 行（含 RakuPM::Distribution 模型不收的 source-url / license / support）—— info / browse 用。
# 直接回源 META6.json 文件，因为只有那里才有这些字段。
# 不传版本取最高版本；传了版本精确匹配；找不到返回安全空 Hash（非 Nil）。
method raw-row(Str $name, Str $version = '' --> Hash) {
    my %idx = self!index;
    return {} unless %idx<metas>{$name}:exists;
    my @metas = @(%idx<metas>{$name});
    my $d;
    if $version.chars {
        $d = @metas.first({ .version eq $version });
    }
    else {
        my @vs = @metas.map(*.version).grep(*.chars).unique;
        return {} unless @vs.elems;
        my $best = RakuPM::Version.new.pick-best('', @vs);
        $d = @metas.first({ .version eq $best });
    }
    return {} unless $d.defined;
    my $dir = %idx<source-dirs>{"$name\0{$d.version}"};
    my $meta = $dir.defined ?? $dir.add('META6.json') !! IO::Path;
    return {} unless $meta.defined && $meta.e;
    my %m = try { from-json($meta.slurp) } // {};
    return %m;
}

method available-versions(Str $name --> List) {
    my %idx = self!index;
    @(%idx<versions>{$name} // [])
}

# 本地仓库的元信息本来就已经全部物化好了，直接查 provides
method versions-providing(Str $module, Str $dist-name --> List) {
    my %idx = self!index;
    # 发行版名依赖：dist 名与依赖名相同时，其全部版本都算提供
    return @(%idx<versions>{$module} // []).List
        if $dist-name eq $module && (%idx<versions>{$module}:exists);
    @(%idx<metas>{$dist-name} // [])
        .grep({ $module (elem) @(.provides) })
        .map(*.version)
        .unique
        .List
}

method fetch-distribution(Str $name, Str $version --> RakuPM::Distribution) {
    my %idx = self!index;
    my @metas = @(%idx<metas>{$name} // []);
    for @metas -> $d {
        return $d if $d.version eq $version;
    }
    die "仓库 {self.id} 中找不到 $name 版本 $version";
}
