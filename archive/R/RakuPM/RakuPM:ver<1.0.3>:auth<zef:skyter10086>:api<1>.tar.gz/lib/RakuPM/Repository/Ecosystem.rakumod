# RakuPM::Repository::Ecosystem — 远程 JSON 生态仓库（真实可用）
#
# 仿 zef 的 Ecosystem：向一个生态索引（默认 https://360.zef.pm）发 HTTP 请求，
# 索引本身是一个 JSON 数组，每条是一个发行版记录：
#
#   { "name":"File::Temp", "version":"0.0.12", "auth":"zef:...",
#     "provides":{"File::Temp":"lib/File/Temp.rakumod"},
#     "depends":{ "runtime": { "requires": [ "File::Directory::Tree:ver<0.2+>:auth<...>" ] } },
#     "path":"F/IL/FILE_TEMP/9e97....tar.gz" }
#
# 我们把索引缓存到本地（cache-root/index-<host>.json），作为可查询的「仓库」。
# 安装某版本时，按 path 拼出 tar 包 URL，下载并解压到 cache-root/dist/<name>/<ver>/，
# 返回含 META6.json + lib/ 的源码目录。

use RakuPM::Distribution;
use RakuPM::Repository;
use RakuPM::HTTP;
use RakuPM::Net;
use JSON::Fast;
use URI;

use RakuPM::Fs;
unit class RakuPM::Repository::Ecosystem does RakuPM::Repository;

has Str      $.name       = '';                   # 人类可读名（zef / rea / cpan…）
has Str      $.index-url  is required;            # 如 https://360.zef.pm
has Str      $.base-url   = self!derive-base($!index-url);
has IO::Path $.cache-root is required;            # 索引 + tar 包 + 解压目录
has Bool     $.refresh    = False;                # 强制重新拉取索引
has Str      $.proxy      = '';                   # 代理 URL（空串=不代理），透传给 HTTP 门面
has          $.http;                               # HTTP 客户端门面（类型不锁定以便注入测试桩；
                                                  # 默认 Nil，BUILD 里再按 proxy 自建）

has @!rows;               # 全行视图（供 search 等模糊遍历，从 HASH 展开）
has %!by-nv;              # name => version => row   （O(1) 按「名+版本」定位）
has %!provides;           # module => [dist-names]   （O(1) 反向查 provides）
has Bool $!loaded;

# 本次索引是「降级」拿到的吗？（0.49.5）—— 三种正常之外的来路：用了过期旧缓存、
# 或拉取失败且无缓存（按空索引处理）。**公开属性**，理由与 Client.did-self-shadow-warn
# 同款：警告要能被测试**断言**，而不是让测试去 grep stderr（那种写法一改文案就假绿）。
# 将来若要汇总「本次结果可能不完整」，也从这里取数。
has Bool $.degraded = False;

submethod BUILD(:$!index-url!, :$!cache-root!, :$!name = '', :$!refresh = False,
                :$!proxy = '', :$!http,
                :$!base-url = self!derive-base($!index-url)) {
    $!base-url = $!base-url || self!derive-base($!index-url);
    $!name     = $!name || self!derive-name($!index-url);
    # 没显式传 HTTP 门面就用默认（按 proxy 建一个；门面内部再读环境代理）。
    # 不能用 `=:= Any` 判：未传时 Raku 给的是 Any 的**新实例**，不是类型对象。
    # 用 duck-type（能不能 get-text）兜底：测试桩 FakeHTTP 没 get-text 时也能注入。
    $!http = RakuPM::HTTP.new(:proxy($!proxy)) unless $!http.can('get-text');
}

# 由 URL 推出一个名字（仅在本模块被直接 new、没传 name 时用）
method !derive-name(Str $u --> Str) {
    my $s = $u.subst('https://', '').subst('http://', '');
    my @seg = $s.split('/').grep(*.chars);
    if @seg.elems >= 2 {
        my $file = @seg.tail.subst(/\.json$/, '');
        return $file.lc if $file.chars && $file.lc ne 'meta';
    }
    my $host = @seg[0] // $s;
    my @lab = $host.split('.');
    # 纯数字开头的主机（360.zef.pm）取后一段更可读 → zef。
    # 注意：必须「全标签都是数字」才算真 IP，不能只判首标签 —— 否则
    # 123.foo.example.com 这种首标签是数字、其余不是的普通主机名会被误判成 IP，
    # 错误返回 @lab[1]="foo" 而非想要的二级域名 @lab[*-2]="example"。
    return @lab[1].lc if @lab.elems >= 3 && @lab.all ~~ /^ \d+ $/;
    # 一般主机取二级域名（example.com → example）
    return @lab[*-2].lc if @lab.elems >= 2;
    $host.lc
}

# 由索引 URL 推出 tar 包的基础地址：取 scheme://host（去掉路径部分）。
# 例如 https://360.zef.pm      -> https://360.zef.pm
#      https://a.b/x.json      -> https://a.b
method !derive-base(Str $u --> Str) {
    if $u ~~ /^ ( 'https://' | 'http://' ) ( <-[/]>+ ) / {
        return $0 ~ $1;
    }
    $u
}

# 索引缓存文件：用 name + URL 的安全化后缀命名。
# 不能只按 host 命名——rea 和 cpan 两个索引都挂在 raw.githubusercontent.com 上，
# 按 host 命名会让它们互相覆盖缓存。
method !index-cache-file(--> IO::Path) {
    my $tag = $!name ~ '-' ~ $!index-url;
    $tag = $tag.comb.map({ $_ ~~ /<[A..Za..z0..9._-]>/ ?? $_ !! '_' }).join('');
    $tag = $tag.substr(0, 80) if $tag.chars > 80;
    $!cache-root.add("index-{$tag}.json")
}

# ETag 副车文件：与 index-<tag>.json 同目录，单独存上游返回的 ETag，
# 供下次条件 GET 的 If-None-Match。和 JSON 正文分开，避免为读 ETag 而解析 10MB。
method !etag-file(IO::Path $cache --> IO::Path) {
    $cache.parent.add($cache.basename.subst(/\.json$/, '') ~ '.etag')
}

# 拉取并缓存索引（仅在未加载时执行一次）。
#
# TTL（解决对比文档点名的「缓存一旦生成便持续使用、不手动 update 就永远看到旧快照
# 的静默断裂」）：
#   · RAKUPM_INDEX_TTL 缺省（或 ≤0）→ 老行为：有缓存就用，除非 :refresh 强制重拉；
#   · RAKUPM_INDEX_TTL > 0            → 缓存未过期（age ≤ TTL）才复用，过期则重新拉取。
#   默认 86400 秒（1 天）。
# 韧性：重新拉取若失败但本地有旧缓存，则回退用旧缓存并告警，而不是让整个安装崩掉
# （单点网络抖动不应升级成安装失败）。
#
# 缓存文件格式（0.36.0 起）：{"_rakupm_t": <unix>, "rows": [...]}。
# 把 fetched_at 塞进 JSON 而不是用 IO::Path.changed，是因为这版 Windows Rakudo 上
# IO::Path.changed 几乎总是一个远小于 Unix 时代的常量（~Instant:1.5，无法
# 与 now 比较、无法区分「新写」与「几分钟前」）——靠文件系统 mtime 不可靠。
# 把时间写进缓存文件本身：单文件、原子写、跨平台一致，且未来改格式也不依赖
# OS 层回退。
method refresh(--> Nil) {
    return if $!loaded;
    my $cache = self!index-cache-file;
    if self!cache-valid($cache) {
        self!build-index(self!load-rows($cache));
        $!loaded = True;
        return;
    }
    self!refetch-index($cache);
}

# 缓存是否可以直接复用:未强制刷新、文件存在、且(无 TTL 或 未过期)
method !cache-valid(IO::Path $cache --> Bool) {
    return False if $!refresh || !$cache.e;
    my $ttl = self!index-ttl;
    return True  if $ttl <= 0;                 # 无 TTL：有就用
    my $t = self!read-fetched-at($cache);
    return False unless $t.defined;            # 老格式/损坏 → 不算新鲜
    ($t + $ttl) > now.Int                       # 未过期（用 Int 避免 Instant 单位歧义）
}

method !index-ttl(--> Int) {
    my $e = %*ENV<RAKUPM_INDEX_TTL>;
    return $e.defined && $e.chars ?? ($e.Int // 86400) !! 86400;
}

# 从缓存文件抽 fetched_at 字段。文件不在或损坏 → 不算新鲜（让调用方去 refetch）。
#
# 【为什么只扫头尾各 4KB，而不是 slurp + from-json 整个文件】
# 索引缓存最大 24MB（实测 rea 23.6MB / zef 12.6MB / cpan 2.6MB），
# slurp + from-json 一遍要 0.3~2.4s；而**紧接着 !load-rows 还会把同一份文件再解析
# 一遍**，于是每次 refresh 白花一倍解析时间（0.84.2 实测：`raku-pm search` 12s 里
# 约 4.2s 就是这笔重复解析）。这里要的只是 wrapper 里的一个整数时间戳，而它总是落在
# 文件的最前或最后几个字节 —— 实测 rea / cpan 在偏移 5（`{"_rakupm_t": …` 在前），
# zef 在距末尾 24 字节（`…, "_rakupm_t": …}` 在后）：两种键序都在用，故头尾各扫一段。
# 解码用 latin-1（字节↔字符一一对应，即使截断多字节字符也不会抛错），只需匹配 ASCII。
method !read-fetched-at(IO::Path $cache --> Int) {
    return Nil unless $cache.e;
    my Str $scan = '';
    try {
        my Int $size = $cache.s;
        my $fh = $cache.open(:bin);
        $scan = $fh.read(4096).decode('latin-1');
        if $size > 8192 {
            $fh.seek($size - 4096);
            $scan ~= "\n" ~ $fh.read(4096).decode('latin-1');
        }
        $fh.close;
    }
    return Nil unless $scan.chars;
    # 紧凑（`"_rakupm_t":123`）与 pretty（`"_rakupm_t": 123`）两种写法都匹配；
    # 旧格式（无 wrapper 的裸数组）扫不到 → 返回 Nil，与原先同语义（调用方去 refetch）。
    return +$0 if $scan ~~ / '_rakupm_t"' \s* ':' \s* (\d+) /;
    Nil
}

# 从缓存文件抽 rows 数组（旧 raw-array 格式无 wrapper 时返回空，触发 refetch）
method !load-rows(IO::Path $cache --> List) {
    try {
        my $obj = from-json($cache.slurp);
        # 注意：返回类型签名是 List，| 在 $rows 只有 1 个元素时会被压平成
        # 那个元素本身（Hash），不再包成 List，违反返回类型 → 抛 Type check。
        # 改用 $rows.List 永远保留 List 包装（哪怕只有 0/1 个元素）。
        return ($obj<rows> // ()).List if $obj ~~ Hash;
        return $obj.List if $obj ~~ Array;        # 旧格式（pre-0.36.0）兜底
    }
    ()
}

# 把加载来的索引行（List of Hash）建成本地 O(1) 内存索引：
#   %!by-nv    —— name => version => row，供 !row-for / available-versions /
#                 versions-providing 直接定位，不再线性扫全表；
#   %!provides —— module => [dist-names]，反向索引，供 find-providers O(1)
#                 命中。构建时把【发行名本身】也登记进去，于是「按发行名
#                 声明依赖」的写法（fez / App::Mi6 依赖 fez:ver<38+>）自动涵盖，
#                 无需在查询时再单独判 %row<name> eq $module。
# @!rows 仍保留为【全行视图】，供 search-rows 这类模糊遍历使用。
method !build-index(@rows --> Nil) {
    @!rows = @rows;
    %!by-nv    = Hash.new;
    %!provides = Hash.new;
    for @rows -> $row {
        my %row = $row;
        my $n = %row<name>;
        next unless $n.defined && $n.chars;
        %!by-nv{$n} //= Hash.new;
        %!by-nv{$n}{%row<version>} = %row;
        # 反向索引：provides 的每个模块名 + 发行名本身（去重）
        my @mods = self!norm-provides(%row<provides>).list;
        @mods.push($n) unless $n (elem) @mods;
        for @mods -> $m {
            next unless $m.chars;
            %!provides{$m} //= Array.new;
            %!provides{$m}.push($n) unless $n (elem) %!provides{$m};
        }
    }
}

# 真正去拉索引（带条件 GET + 旧缓存兜底）
#
# 增量更新核心：带已存 ETag 发 If-None-Match。远端没变回 304 → 复用磁盘缓存、
# 只刷新 TTL（不重下、不重解析网络内容）；变了回 200 → 正常落盘并记下新 ETag。
# 上游标准生态源（360.zef.pm / REA）都返回 ETag，所以 TTL 过期后绝大多数情况
# 是 304，省掉每次重下 9–18MB。自定义/本地源若不带 ETag，则退化为普通 GET。
# 索引是本地文件（不是网络 URL）？——非 http/https 即按本地路径处理，
# 直接用 IO::Path 读，不进 HTTP 层。生产里生态索引都是 http(s)，
# 本地路径仅用于端到端测试夹具。
# 用 URI 模块解析索引地址的 scheme，决定走网络层还是本地 IO::Path：
#   · http / https / ftp(s) → 网络层（RakuPM::HTTP）
#   · file                  → 本地文件，由 URI 解出路径后走 IO::Path
#   · 无 scheme / 单字母 scheme（Windows 盘符 C:\... 被 URI 误判成 scheme 'c'）
#     → 直接当作本地文件系统路径走 IO::Path
method !index-scheme(--> Str) {
    my $u = try { URI.new($!index-url) };
    return '' unless $u && $u.scheme.defined && $u.scheme.chars;
    $u.scheme.lc;
}

method !is-local-index(--> Bool) {
    my $s = self!index-scheme;
    $s eq '' || $s eq 'file' || $s.chars == 1;
}

# 把本地索引地址解析成 IO::Path（只在 !is-local-index 为真时调用）：
#   · file:// URL → 用 URI 解出路径，剥掉 Windows 盘符前那一个开头的 '/'
#     （这是剔除 URL 工件，不是路径拼接；IO::Path 接受正斜杠，跨平台一致）
#   · 纯文件系统路径（含 Windows C:\...）→ 直接 .IO，不碰字符串
method !local-index-path(--> IO::Path) {
    if self!index-scheme eq 'file' {
        my $uri = URI.new($!index-url);
        my $p = ($uri.path // '').Str;
        $p = $p.substr(1) if $p ~~ m{^ '/' <[A..Z a..z]> ':' };
        return $p.IO;
    }
    $!index-url.IO
}

method !refetch-index(IO::Path $cache --> Nil) {
    # 本地索引文件（非 http/https，源文件就在磁盘上）：直接读，不进网络层。
    # 本地地址就是 IO::Path，HTTP 层只管 http(s)，没有 file:// 这种 URL 概念。
    if self!is-local-index {
        my $src = self!local-index-path;
        $src.e or die "本地索引文件不存在：{$!index-url}";
        my $text = $src.slurp;
        mkdir-p($!cache-root);
        self!atomic-spurt($cache, $text);
        self!build-index((try { from-json($text).List }) // ());
        $!loaded = True;
        return;
    }
    # ---- 离线模式：这一轮绝不联网（0.51.0）----
    # 位置很关键：必须在 is-local-index 分支【之后】—— 本地索引文件是磁盘读取、
    # 与网络无关，离线时照样该能用（把它拦掉就等于离线连本地仓库都不能装包了）。
    #
    # 有缓存就复用。注意这里仍然置 degraded：缓存可能是旧的，按 degraded 的原义
    # （「本次索引内容未必完整 / 最新」）就该置。区分「离线」与「拉取失败」靠文案
    # 和 RakuPM::Net.offline()，不靠这个标记。
    if offline() {
        if $cache.e {
            my @r = self!load-rows($cache);
            if @r {
                self!build-index(@r);
                $!degraded = True;
                $!loaded   = True;
                note "  · 离线模式（--offline）：复用本地索引缓存（{$!name}）";
                return;
            }
        }
        $!degraded = True;
        self!build-index(());
        $!loaded = True;
        note "⚠ 离线模式（--offline）且本地无索引缓存（{$!name}）：本次按空索引处理";
        note "  若这个包本该在这个索引里：先联网跑一次 `raku-pm repos update` 建好缓存，";
        note "  之后就能一直离线复用了。";
        return;
    }
    say "==> 拉取生态索引 [{$!name}]：{$!index-url}";
    my $etag-file = self!etag-file($cache);
    my $old-etag  = $etag-file.e ?? $etag-file.slurp.trim !! '';
    # 条件请求（带旧 ETag）或退化普通 GET；整段包 try：网络层抛错（含重试耗尽）
    # 都算「拉取失败」，落到下面的旧缓存韧性兜底，而非直接 die。
    my $resp;
    try {
        $resp = $!http.can('get-text-conditional')
            ?? $!http.get-text-conditional($!index-url, :if-none-match($old-etag))
            !! RakuPM::HTTP::ConditionalResponse.new(:status(200), :body($!http.get-text($!index-url)));
    }
    if $resp && $resp.not-modified {
        # 304：远端未变，复用磁盘缓存文本，仅刷新 TTL（避免重下 / 重解析网络内容）。
        self!refresh-cache-ttl($cache);
        self!build-index(self!load-rows($cache));
        $!loaded = True;
        note "  · 索引未变更（ETag 命中 304），复用本地缓存，跳过下载" if %*ENV<RAKUPM_DEBUG>;
        return;
    }
    my $text = $resp ?? $resp.body !! '';
    if $text.defined && $text.chars {
        mkdir-p($!cache-root);
        self!atomic-spurt($cache, $text);
        $etag-file.spurt($resp.etag) if $resp.etag.chars;   # 记下 ETag 供下次条件请求
        # 远端直给 raw array；写入本地时再 wrap。
        self!build-index((try { from-json($text).List }) // ());
        $!loaded = True;
        return;
    }
    # 拉取失败但本地有旧缓存 → 韧性兜底
    if $cache.e {
        my @r = self!load-rows($cache);
        if @r {
            self!build-index(@r);
            $!degraded = True;
            note "⚠ 索引拉取失败，暂用本地旧缓存（{$!name}）：可能已过期，跑 `raku-pm repos update` 可强制刷新";
            $!loaded = True;
            return;
        }
    }
    # 拉取失败**且无任何缓存** → 本次按【空索引】处理，不 die（0.49.5 改）。
    #
    # 【为什么不能 die】这是多索引里的**一环**，而解析器会把每个仓库都问一遍。
    # 只要有一个索引在本次不可达、又恰好没缓存过，整条命令就崩 —— 哪怕答案本来
    # 就在可达的仓库里（本地目录仓库，或 zef 索引）。用户现场（国内网络）：
    #   # You planned 8 tests, but ran 0
    #   生态索引拉取失败且本地无缓存（https://raw.githubusercontent.com/Raku/REA/main/META.json）
    # 那次解析的 `Lib::A` 明明在本地仓库里，却因为 REA 不可达而整条命令失败。
    # 这与本文件上方写下的原则「单点网络抖动不应升级成安装失败」直接矛盾 ——
    # 那条原则原先只在「有旧缓存」时兑现，现在补全。
    #
    # 【为什么不是静默降级】note 一行 ⚠，点名索引与 URL；并且置 $!degraded 供测试断言。
    # 若最终「在所有已配置的仓库里都找不到模块」，这条 ⚠ 就紧挨在上面，足以定位。
    $!degraded = True;
    note "⚠ 索引拉取失败且本地无缓存（{$!name}：{$!index-url}）：本次按空索引处理，结果可能不完整";
    self!build-index(());
    $!loaded = True;
}

# 304 命中后只刷新 _rakupm_t 时间戳，不改动 rows（避免重下 / 重解析网络内容）。
# 代价是重解析一次本地 JSON（低频：304 仅在 TTL 过期且远端未变时发生）。
method !refresh-cache-ttl(IO::Path $cache --> Nil) {
    my @rows = self!load-rows($cache);
    return unless @rows;
    self!atomic-spurt($cache, to-json(@rows));
}

# 原子写：先写同目录的临时文件，再 rename 覆盖目标。
#
# 直接 `$cache.spurt($text)` 在并发下会出事：索引有 10MB 上下，两个 raku-pm
# 同时刷新（比如一个在 search、一个在 install）就会把两份内容交错写进同一个
# 文件，留下的半份 JSON 下次 from-json 必然报错，而且受害者是**下一次**命令，
# 现场已经没了，极难排查。rename 在同一分区上是原子的，读者只会看到旧文件或
# 新文件，不会看到写了一半的。
#
# 临时文件名带 PID：并发两个进程各自写自己的临时文件，不会互相截断。
#
# 同时把 $text（远端原始 raw array JSON）包成 {_rakupm_t, rows}
# 格式再写：fetched_at 内嵌其中，跨平台无需依赖 IO::Path.changed。
method !atomic-spurt(IO::Path $path, Str $text --> Nil) {
    my $rows;
    try { $rows = from-json($text) }
    # 远端不是合法 JSON 也照原样塞 rows（出问题时 human-readable）
    my $obj = { _rakupm_t => now.Int.Int, rows => $rows // $text };
    my $wrapped = to-json($obj);
    my $tmp = $path.parent.add($path.basename ~ ".tmp-{$*PID}");
    $tmp.spurt($wrapped);
    unless try { $tmp.rename($path) } {
        # rename 失败（跨分区 / 权限 / Windows 上目标被占用）时退回普通写：
        # 仍有并发风险，但总比把索引丢了强
        try { $tmp.unlink }
        $path.spurt($wrapped);
    }
}

method !rows(--> List) {
    self.refresh unless $!loaded;
    @!rows
}

method id(--> Str) { "eco:{$!name}:{$!index-url}" }

# provides 可能是 Hash（模块=>路径）或数组（模块名列表），统一取模块名列表
method !norm-provides($p --> List) {
    return () unless $p.defined;
    return $p.keys.List if $p ~~ Associative;
    return @$p.List    if $p ~~ Positional;
    ()
}

# 注：索引行 → Distribution 的字段归一（provides / resources / depends /
# builder / build-depends / test-depends / auth）已全部上移到
# RakuPM::Distribution.from-index-row —— fetch-distribution 直接调它，
# 本类不再保留一份 resources 归一（原 !norm-resources 已随之上移并删除）。

# 注意：找不到时返回【空 Hash】而不是 Nil / Hash 类型对象。
# 调用方写的是 `my %row = self!row-for(...)`：
#   - 返回 Hash 类型对象或 Nil（会被 `-->` 约束强制成 Hash 类型对象）时，
#     赋值语句本身就抛 "Odd number of elements found where hash initializer expected"，
#     后面的 `unless %row` 判空根本执行不到；
#   - 返回 {} 则是安全的空 Hash，布尔上下文中为 False。
method !row-for(Str $name, Str $version --> Hash) {
    return {} unless %!by-nv{$name}:exists;
    my %v := %!by-nv{$name};
    return %v{$version}:exists ?? %v{$version} !! {};
}

method find-providers(Str $module --> List) {
    # 反向索引 %!provides 已经在构建时把 provides 模块名与发行名本身都登记了，
    # 所以「按模块名」与「按发行名」两种依赖写法都命中，O(1)。
    # 自加载守卫：本条与 search-rows / !rows 同款。否则在「解析链上游没先 refresh」
    # 的情况下（如单独调用或 search 子命令）会读到空索引、静默返回空，群众误以为
    # 「仓库里没有这个包」。install 能命中是因为 Repositories 在开头统一 refresh 过。
    self.refresh unless $!loaded;
    # 注意：%!provides{$module} 是「存进哈希的 Array（被 Scalar 包裹）」。直接
    # `my @names = %!provides{$module}` 会被当成【单个 item】整体塞成单元素数组
    # （Raku 的列表赋值对 Scalar 包裹的 Array 不做扁平化），于是返回
    # [["Log::Async"]] 这种嵌套结构，调用方再拿它当 $dist-name 喂给
    # versions-providing 就触发「expected Str but got Array」。用 .flat 把元素
    # （以及任何意外嵌套）摊平，保证返回的是扁平的发行名字符串列表。
    my @names = (%!provides{$module} // ()).flat;
    @names.unique.List
}

method all-distributions(--> List) {
    %!by-nv.keys.List
}

method available-versions(Str $name --> List) {
    return () unless %!by-nv{$name}:exists;
    %!by-nv{$name}.keys.unique.List
}

# 直接扫该发行的所有版本即可，不必（像角色兜底那样）把每个版本都物化一遍
method versions-providing(Str $module, Str $dist-name --> List) {
    return () unless %!by-nv{$dist-name}:exists;
    my %v = %!by-nv{$dist-name};
    %v.keys.grep({
        my %row = %v{$_};
        $module (elem) self!norm-provides(%row<provides>) || %row<name> eq $module
    }).unique.List
}

method fetch-distribution(Str $name, Str $version --> RakuPM::Distribution) {
    my %row = self!row-for($name, $version);
    die "生态 {self.id} 中找不到 $name 版本 $version" unless %row;
    # 【单一构造入口】字段归一与「挑哪些字段」全部交给 Distribution.from-index-row：
    # 原先这里是手工挑字段，每加一个新字段就漏一次（resources / builder /
    # build-depends / test-depends 都漏过，其中漏 builder 会让 120 个包的构建
    # 阶段被整个跳过）。新增字段只需改 Distribution 那一处。
    RakuPM::Distribution.from-index-row(%row);
}

# search 子命令用：返回匹配关键词的发行版精简记录
method search-rows(Str $q --> List) {
    # 自加载守卫：与 !rows / find-providers 同款。search 子命令不会走 install 那条
    # 先 refresh 的路径，若这里不加载，%!by-nv 永远是空 → 搜什么都是空（即使远程
    # 索引里明明白白有这个包）。这是 0.36.12 修的「raku-pm search 查不到」根因。
    self.refresh unless $!loaded;
    my @all = %!by-nv.values.map(*.values).flat;
    @all.map(-> $row {
        # 匹配与相关度分级统一走 RakuPM::Repository::Matching（本类经基 role
        # 组合而来）——不再在本类里维护一份评分逻辑。等级：0 名精确 / 1 名前缀 /
        # 2 名子串 / 3 模块名精确 / 4 模块名前缀 / 5 模块名子串；只按模块名匹配，
        # 不扫 description（扫描述会把「method xxx」这类方法名误当成匹配项）。
        my $score = self.match-score(($row<name> // ''),
                                     self!norm-provides($row<provides>).list, $q);
        $score.defined
            ?? %( name => $row<name>, version => $row<version>,
                  auth => RakuPM::Distribution.auth-of-row($row),
                  description => $row<description> // '',
                  repo => $!name, _score => $score )
            !! Nil
    }).grep(*.defined).List
}

# 返回某个发行版的【完整索引行】—— 含 source-url / license / support / path 这些
# search-rows 为精简显示而丢弃的字段。info / browse 靠它拿主页与许可证信息。
# 不传版本取最高版本；传了版本精确匹配；仓库里没有则返回安全空 Hash（非 Nil）。
method raw-row(Str $name, Str $version = '' --> Hash) {
    self.refresh unless $!loaded;
    return {} unless %!by-nv{$name}:exists;
    if $version.chars {
        return %!by-nv{$name}{$version}:exists ?? %!by-nv{$name}{$version} !! {};
    }
    my @vs = %!by-nv{$name}.keys.grep(*.chars).unique;
    return {} unless @vs.elems;
    my $best = RakuPM::Version.new.pick-best('', @vs);
    return %!by-nv{$name}{$best} // {};
}

# 下载 tar 包并解压，返回含 META6.json / lib 的源码目录。
# 已存在则直接复用（缓存命中，不重复下载）。
method source-dir-for(Str $name, Str $version --> IO::Path) {
    my %row = self!row-for($name, $version);
    # 该发行版不在本生态里：返回未定义的 IO::Path，让 Client 落到下一个仓库
    # （例如本地 repo/），而不是在这里直接 die。
    return IO::Path unless %row;

    # 【0.87.0】名字与版本来自**索引行**（发布者可控），要当路径分量用就必须净化：
    # 这里是下载/解压缓存 <cache>/dist/<仓库>/<名字>/<版本>/，发生在 store 之前，
    # 未净化时 `version: "../../../../evil"` 会让下载物落到缓存目录之外。
    my $safe = path-component($name,     :what('发行版名'));
    my $vseg = path-component($version,  :what('版本号'));
    # 缓存目录按【仓库名】隔离：同一个发行版+版本可能同时存在于多个索引
    # （zef 和 rea 里都有 File::Temp 0.0.12），不隔离会互相命中对方的解压结果。
    my $dist-dir = $!cache-root.add('dist').add($!name).add($safe);
    assert-under($dist-dir, $!cache-root, :what("下载缓存目录（{$name} {$version}）"));
    my $dest = $dist-dir.add($vseg);

    my $cached = self!find-source($dest);
    return $cached if $cached.defined;

    # tar 包地址有两种写法，取决于索引：
    #   · source-url：完整绝对 URL（REA 存档、cpan1.json 用这种）
    #   · path      ：相对路径，需与索引同主机拼接（360.zef.pm 用这种）
    my $url = self!tarball-url(%row);
    # 这个仓库拿不到 tarball 地址（索引条目缺 source-url / path）→ 优雅返回
    # 未定义，让 Client 落到下一个仓库；契约与 !row-for 未命中时一致。
    return IO::Path unless $url.chars;
    # 用净化后的版本段拼文件名（不能拿原始 $version：`../x` 会在这条同样穿越）
    my $tarball = $dist-dir.add($vseg ~ '.tar.gz');

    say "==> 下载源码包 [{$!name}]：$url";
    mkdir-p($tarball.parent);
    $!http.download($url, $tarball);

    mkdir-p($dest);
    # 注意：Windows 上 GNU tar 会把参数里 `C:/...` 的 `C:` 当成远程主机
    # （host:file 语法同时作用于 -C 与目标文件），导致 "Cannot connect to C:"。
    # 规避办法：切到目标目录 $dest，以【相对文件名】../<ver>.tar.gz 调用 tar，
    # 把内容解压进 $dest（tar 包顶层目录会变成 $dest 的子目录，便于后续定位 lib/）。
    my $rel = $tarball.relative($dest).Str.subst('\\', '/', :g);
    my $proc = run(self!tar-exe, '-xzf', $rel, :cwd($dest.Str), :out, :err);
    unless $proc.exitcode == 0 {
        die "解压失败：$url\n" ~ ($proc.err.slurp(:close) // '');
    }

    my $src = self!find-source($dest) // $dest;
    die "解压后未在 $dest 找到 META6.json / lib" unless $src.defined;
    $src
}

# 拼出 tar 包 URL：优先用索引里写死的 source-url，否则把相对 path 拼到索引所在主机上
method !tarball-url(%row --> Str) {
    my $u = %row<source-url>;
    return $u if $u.defined && $u.chars && ($u.starts-with('http://') || $u.starts-with('https://'));

    # 缺 source-url / path：这个条目提供不了 tarball。典型例子是 REA 里的
    # Rakudo 条目（编译器本身，没有可下载的包）。返回空串让调用方优雅降级 ——
    # 一条索引数据不全不该让整个安装崩掉（以前这里直接 die）。
    my $path = %row<path>;
    return '' unless $path.defined && $path.chars;
    # 索引 URL 去掉最后一段（文件名）当基址，再拼 path。
    # 360.zef.pm 的索引就在根上，此时 base-url 即主机本身。
    my $base = $!index-url.subst(/\/? <[^\/]>* $/, '');
    $base ~ '/' ~ $path
}

# 在 dest（或其直接子目录）里定位含 META6.json / lib 的源码根
method !find-source(IO::Path $dir --> IO::Path) {
    return IO::Path unless $dir.d;
    return $dir if $dir.add('META6.json').e || $dir.add('lib').d;
    for $dir.dir.grep(*.d) -> $sub {
        return $sub if $sub.add('META6.json').e || $sub.add('lib').d;
    }
    IO::Path
}

# 找一个可用的 tar 可执行文件（Windows 上优先用 Git 自带的 GNU tar）
method !tar-exe(--> Str) {
    return 'tar' if %*ENV<RAKUPM_TAR>.defined;     # 允许用户显式指定
    for 'tar',
        'C:/Program Files/Git/usr/bin/tar.exe',
        'C:/Program Files (x86)/Git/usr/bin/tar.exe' -> $c {
        return $c if $c eq 'tar' || $c.IO.e;
    }
    'tar'
}

# 注意：HTTP 细节已全部抽到 RakuPM::HTTP 门面（单后端：curl/Tinyish）；
# 本地索引文件由 Ecosystem 直接读 IO::Path，不再内联任何 HTTP / curl 细节。
