# RakuPM::Cleaner — 缓存回收（raku-pm clean / gc）
#
# 为什么需要它：store 只增不减。
#   实测一台用了一段时间的机器：store 193M、cache/dist 110M、git-cache 6.3M，
#   其中 store 里 RakuPM 一个包就攒了 30 个版本（self-upgrade 每次留一份快照），
#   而 site 里真正装着的只有最新那个。硬盘就这么被历史快照吃掉了，
#   在此之前唯一的清理办法是手删 ~/.raku-pm/store。
#
# 【安全边界】删哪些、留哪些，判据只有一条：**这个版本还在不在被用**。
# 受保护的（绝不删）来自四处，取并集：
#   1. installed.json 账本里记的版本（多版本共存时全部记在 versions 里）；
#   2. 自家 site/（CUR::Installation）里实际装着的版本 —— 账本可能缺记，
#      以磁盘为准；
#   3. raku-pm.lock 锁定的版本 —— `--locked` 安装会直接复用它，删了要重下；
#   4. 保留世代的 manifest.json 里记的版本 —— rollback-to 会把账本恢复到某个
#      世代的 manifest，缺失版本从 store 装回；若被回收就装不回了（只能留空世代）。
# 除此之外都是缓存：删了最坏的结果是下次重装时重新下载/重新入库，
# 不会让已装好的包失效（site/ 是另一份拷贝，不依赖 store）。
#
# 回收粒度（默认）：
#   store     未被保护的历史版本目录
#   orphan    入库中断留下的残骸（store/<Name>/<ver>/ 里没有 META.json）
#   precomp   store 条目里的 .precomp —— 纯派生产物，Store 连指纹都不算它
#   dist      cache/dist/ 下已下载的 tar 包与解压目录
# --all 追加（这两个重建成本是网络/克隆，默认留着）：
#   index     cache/index-*.json 生态索引缓存（下次自动重新拉取）
#   git       git-cache/ 下的 clone（下次重新 clone）
#
# 默认【试算】不落盘（删文件不可撤销），要真删得显式 --yes。

use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Installer::Generations;
use RakuPM::Lock;
use RakuPM::Distribution;
use RakuPM::Fs;
use nqp;

unit class RakuPM::Cleaner;

has IO::Path          $.target    is required;   # ~/.raku-pm
has RakuPM::Store     $.store     is required;
has RakuPM::Installer $.installer is required;
has RakuPM::Lock      $.lock      is required;

# 各回收类别的人话说明（报告用）
my %KIND-LABEL =
    store   => '旧版本快照',
    orphan  => '入库残骸',
    precomp => '预编译缓存',
    dist    => '下载缓存',
    tmp     => '临时文件残留',
    index   => '索引缓存',
    git     => 'git 克隆缓存',
;

# ============ 计划 ============

# 扫一遍算出「可以删什么」。不碰任何文件，可安全重复调用。
# 返回 %( items => @items, bytes => 总字节, kept => 受保护版本数,
#         scanned => 扫到的 store 条目数 )
#
# 每个 item：%( kind, label, path(IO::Path), bytes(Int), reason(Str) )
method plan(Bool :$all = False, Int :$older-than = 0, Str :$name = '' --> Hash) {
    my @items;
    # --older-than=N：只回收 N 天没动过的。0 = 不看时间。
    my $cutoff = $older-than > 0
        ?? (time - ($older-than * 86400))
        !! 0;

    my %keep = self.protected-versions;

    # ---- store：历史版本 / 残骸 / .precomp ----
    my $scanned = 0;
    my %doomed;   # 已经决定要整目录删掉的，就不必再单列它的 .precomp
    for self!store-entries -> %e {
        $scanned++;
        my $dir = %e<dir>;

        # 残骸：入库写到一半崩了，目录在但没有 META.json
        if !%e<has-meta> {
            next unless self!eligible($dir, $cutoff, $name, %e<name>);
            %doomed{$dir.absolute} = True;
            @items.push(self!item('orphan', $dir.basename, $dir,
                                  '入库中断的残骸（没有 META.json）'));
            next;
        }

        if %keep{"{%e<name>}\0{%e<version>}"} {
            # 保留的版本：整体不能动，但 .precomp 是派生产物，删了会自动重建
            self!collect-precomp($dir, @items, :$cutoff, :$name, :entry-name(%e<name>));
            next;
        }

        next unless self!eligible($dir, $cutoff, $name, %e<name>);
        %doomed{$dir.absolute} = True;
        my $reason = %keep{%e<name>}:exists
            ?? '不是当前安装/锁定的版本'
            !! '该发行版已不在账本与锁文件里';
        @items.push(self!item('store', "{%e<name>} {%e<version>}", $dir, $reason));
    }

    # ---- 下面的类别跟具体包无关，--name 时跳过（只清 store 部分）----
    unless $name.chars {
        @items.append(self!cache-dist-items($cutoff));

        # 原子写留下的 .tmp-<pid> 残留（见 Ecosystem!atomic-spurt）：
        # 进程被 kill 时临时文件不会自动消失，它是纯垃圾，默认就清。
        @items.append(self!tmp-items($cutoff));

        if $all {
            @items.append(self!index-items($cutoff));
            @items.append(self!git-items($cutoff));
        }
    }

    %(
        items   => @items,
        bytes   => @items.map(*<bytes>).sum,
        kept    => %keep.elems,
        scanned => $scanned,
    )
}

# 受保护的「发行版名\0版本」集合。公开成方法是为了可测（回收的正确性
# 全押在这一个集合上），也方便外部复用这套判据。
method protected-versions(--> Hash) {
    my %keep;

    # 来源 1：raku-pm 自己的账本（多版本共存时 versions 是数组）
    for $!installer.list-installed -> %e {
        my $n = (%e<name> // '').Str;
        next unless $n.chars;
        for (|@(%e<versions> // []), (%e<version> // '')).map(*.Str).grep(*.chars) -> $v {
            %keep{"$n\0$v"} = True;
        }
    }

    # 来源 2：自家 site/ 里真实装着的（账本可能与 CUR 不一致，以磁盘为准）。
    # 只认自己的 site —— zef 侧的仓库不由我们管，也不该影响回收判定。
    my $own = (try { $!installer.repo-prefix.absolute }) // '';
    if $own.chars {
        for $*REPO.repo-chain -> $repo {
            next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
            my $prefix = (try { $repo.prefix.absolute }) // '';
            next unless $prefix && $prefix eq $own;
            for $repo.installed -> $d {
                my $n = ($d.meta<name> // '').Str;
                my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
                next unless $n.chars && $v.chars;
                %keep{"$n\0$v"} = True;
            }
        }
    }

    # 来源 3：锁文件锁定的版本
    for $!lock.entries.values -> %e {
        my $n = (%e<name> // '').Str;
        my $v = (%e<version> // '').Str;
        %keep{"$n\0$v"} = True if $n.chars && $v.chars;
    }

    # 来源 4：保留世代的 manifest 引用的版本 —— rollback-to 会把这些版本从
    # store 装回，若被 clean 回收就装不回了（只能留空世代 + 警告）。只认自家
    # generations/（与 site 同源），不碰别的目录。格式知识全在 Generations 里。
    my $gen-dir = $!target.add('generations');
    if $gen-dir.d {
        my $gens = RakuPM::Installer::Generations.new(:dir($gen-dir));
        for $gens.protected-versions.kv -> $k, $v {
            %keep{$k} = $v;
        }
    }

    %keep
}

# ============ 执行 ============

# :dry 默认 True —— 只打印计划，不动文件。真正删除要显式 :!dry。
method run(Bool :$all = False, Int :$older-than = 0, Str :$name = '',
           Bool :$dry = True --> Nil) {
    my %plan = self.plan(:$all, :$older-than, :$name);

    say "==> 扫描缓存：$!target";
    say "";
    self!print-plan(%plan, :$all);

    unless %plan<items>.elems {
        say "没有可回收的缓存。";
        return;
    }

    if $dry {
        say "这是【试算】，没有删除任何文件。";
        say "确认无误后执行：raku-pm clean --yes" ~ ($all ?? ' --all' !! '');
        return;
    }

    say "";
    say "==> 删除 {%plan<items>.elems} 项……";
    my ($freed, @failed);
    for @(%plan<items>) -> %it {
        my $p = %it<path>;
        next unless $p.e;
        # 一个删不掉不该中断整轮回收（Windows 上文件被占用很常见），
        # 记下来最后汇总。
        my $ok = (try { self!remove($p); True }) // False;
        $ok ?? ($freed += %it<bytes>) !! @failed.push(%it);
    }

    say "✓ 已释放 {fmt-bytes($freed)}";
    if @failed.elems {
        note "⚠  {@failed.elems} 项删除失败（可能被占用，可稍后重试）：";
        for @failed -> %it {
            note "    · {%it<label>}  {%it<path>}";
        }
    }
}

# ============ 各类目的扫描 ============

# store 里的全部版本目录（含残骸），一次扫完，避免每类各遍历一遍
method !store-entries(--> List) {
    my @out;
    my $root = $!store.root;
    return () unless $root.d;
    for $root.dir.grep(*.d) -> $dist-dir {
        for $dist-dir.dir.grep(*.d) -> $ver-dir {
            my $meta = $ver-dir.add('META.json');
            my $name = '';
            if $meta.e {
                # 元数据可能是半截 JSON（写入中断），读不出来就当残骸处理
                my $d = try RakuPM::Distribution.from-meta-file($meta);
                $name = ($d.defined ?? ($d.name // '') !! '').Str;
            }
            @out.push(%( dir => $ver-dir, version => $ver-dir.basename,
                         name => $name, has-meta => $meta.e ));
        }
    }
    @out.List
}

# 某个 store 条目里的 .precomp（派生产物，删了 Rakudo 会按需重建）
method !collect-precomp(IO::Path $entry, @items, :$cutoff, :$name,
                        Str :$entry-name = '' --> Nil) {
    my $pc = $entry.add('.precomp');
    return unless $pc.d;
    return unless self!eligible($pc, $cutoff, $name, $entry-name);
    @items.push(self!item('precomp', "{$entry.basename}/.precomp", $pc,
                          '预编译字节码，会自动重建'));
}

# cache/dist/<repo>/<dist>/<ver>/ —— 下载的 tar 包与解压目录。
# 源码已经进 store 了，这里只是下载缓存，删了下次重新下载。
method !cache-dist-items($cutoff --> List) {
    my $root = $!target.add('cache').add('dist');
    return () unless $root.d;
    # 按 <repo> 粒度列一行，不然几十个发行版会刷屏
    $root.dir.grep({ .d && self!eligible($_, $cutoff, '') }).map({
        self!item('dist', "cache/dist/{$_.basename}", $_,
                  '已入库的源码包与解压目录（可重新下载）')
    }).List
}

# 原子写的临时残留：cache/index-*.json.tmp-<pid>
method !tmp-items($cutoff --> List) {
    my $cache = $!target.add('cache');
    return () unless $cache.d;
    $cache.dir.grep({
        .f && .basename.contains('.tmp-') && self!eligible($_, $cutoff, '')
    }).map({
        self!item('tmp', $_.basename, $_, '原子写中断留下的临时文件')
    }).List
}

# 索引缓存 cache/index-*.json（--all 才清）
method !index-items($cutoff --> List) {
    my $cache = $!target.add('cache');
    return () unless $cache.d;
    $cache.dir.grep({
        .f && .basename.starts-with('index-') && .basename.ends-with('.json')
        && self!eligible($_, $cutoff, '')
    }).map({
        self!item('index', $_.basename, $_, '索引缓存（`repos update` 会重新拉取）')
    }).List
}

# git-cache/<host>/<path>.git —— clone 缓存（--all 才清）
method !git-items($cutoff --> List) {
    my $root = $!target.add('git-cache');
    return () unless $root.d;
    $root.dir.grep({ self!eligible($_, $cutoff, '') }).map({
        self!item('git', "git-cache/{$_.basename}", $_,
                  'git 克隆缓存（下次安装会重新 clone）')
    }).List
}

# ============ 工具 ============

method !item(Str $kind, Str $label, IO::Path $path, Str $reason --> Hash) {
    %( kind => $kind, label => $label, path => $path,
       bytes => dir-size($path), reason => $reason )
}

# --name 只过滤 store 相关条目；$cutoff 为 0 表示不看时间。
# 拿不到真实 mtime 时按「不老」处理 —— 宁可少删，不能错删。
method !eligible(IO::Path $p, $cutoff, Str $name, Str $entry-name = '' --> Bool) {
    return False if $name.chars && $entry-name ne $name;
    return True unless $cutoff;
    my $m = mtime-of($p);
    $m > 0 && $m < $cutoff
}

# 文件的修改时间（epoch 秒）。
#
# 不用 IO::Path.modified：它在 Windows 上这版 Rakudo 返回的是个莫名其妙的
# 小数值 —— 实测 README.md 的 .modified 是 Instant:-0.909807136，而真实
# mtime 是 1788831075。拿它去比 --older-than，所有东西都会被判成「很久
# 以前」，于是刚建的缓存也被回收（t/clean.t 里那条「刚建的不回收」就是
# 被它打掉的）。nqp::stat 走的是系统 stat / GetFileTime，两个平台都对。
#
# 拿不到真实 mtime 时返回 0：调用方会把它当「不老」，也就是不删。
sub mtime-of(IO::Path $p --> Num) {
    # nqp::stat 的 7 号参数是 mtime（nqp::const::STAT_MTIME 在本机 Rakudo 上
    # 取不到，只能按序号写，见上面注释）
    my $t = (try { nqp::stat($p.Str, 7).Num }) // 0;
    return $t if $t > 1_000_000_000;          # 合理的时间戳（2001 年之后）
    my $m = (try { $p.modified.Numeric }) // 0;
    return $m if $m > 1_000_000_000;
    0
}

# 删除文件/目录树。只删 $!target 以内的东西 —— 路径算错时这条护栏
# 能把损失挡在自家目录里，而不是去删用户的别处文件。
method !remove(IO::Path $p --> Nil) {
    my $t  = $!target.absolute.IO.resolve;
    my $pp = (try { $p.resolve }) // $p.absolute.IO;
    # 注意要带分隔符比：否则 /tmp/foo-bar 会被 /tmp/foo 误判成「在自己里面」
    my $sep = $*SPEC.dir-sep;
    die "拒绝删除 target 之外的路径：$p"
        unless $pp.Str eq $t.Str || $pp.Str.starts-with($t.Str ~ $sep);
    $pp.d ?? rm-tree($pp) !! $pp.unlink;
}

# 递归删除 / 体积统计统一在 RakuPM::Fs（原先本文件各有一份 sub，
# 与 Installer / Store / SelfManager 的实现重复且兜底策略不同）。

sub fmt-bytes($n is copy --> Str) {
    my $v = ($n // 0).Real;
    return "{$v.Int} B" if $v < 1024;
    for 'KB', 'MB', 'GB', 'TB' -> $u {
        $v /= 1024;
        return "{ $v.fmt('%.1f') } $u" if $v < 1024 || $u eq 'TB';
    }
    "{ $v.fmt('%.1f') } TB"
}

method !print-plan(%plan, Bool :$all = False --> Nil) {
    my @items = @(%plan<items>);

    for <store orphan precomp dist tmp index git> -> $kind {
        my @k = @items.grep({ $_<kind> eq $kind });
        next unless @k.elems;
        say "{%KIND-LABEL{$kind}}（{@k.elems} 项，{fmt-bytes(@k.map(*<bytes>).sum)}）：";
        for @k.sort({ $^b<bytes> <=> $^a<bytes> }) -> %it {
            say "  · {%it<label>}";
            say "      {fmt-bytes(%it<bytes>)}  {%it<reason>}";
            say "      {%it<path>}";
        }
        say "";
    }

    say "────────────────────────────────────────";
    say "可释放 {fmt-bytes(%plan<bytes>)}（{@items.elems} 项）"
      ~ "，受保护保留 {%plan<kept>} 个版本"
      ~ "（store 中共扫到 {%plan<scanned>} 个版本目录）";
    unless $all {
        say "提示：索引缓存与 git 克隆缓存默认保留（重建要重新下载/克隆），"
          ~ "加 --all 一并回收。";
    }
}
