# RakuPM::Installer::Generations — <target>/generations/ 的读写
#
# 世代（generation）是「一次成功安装落地后的账本快照 + 本次装了什么」。
# 目录布局：
#   <target>/generations/current       当前世代 id（内容形如 "000003"）
#   <target>/generations/000003/
#        before.json     事务【开始前】的账本（回滚的真值来源）
#        meta.json       { id, label, created-at, started-at, installed[] }
#        manifest.json   事务【提交后】的账本
#
# 【为什么用「账本快照」而不是拷贝整个 site】
# CUR::Installation 天然支持多版本并存：装新版本不会抹掉旧版本。所以「回滚」=
# 把本次装进去的版本从 CUR 摘掉 + 把账本恢复成事务前那份 —— 旧版本本来就还在
# CUR 里，不需要从别处搬回来。世代因此只是一份几 KB 的 JSON，不用复制几百 MB
# 的 site/。这是 Raku 的 CUR 设计送的便宜。
#
# 【这个类不管什么】卸载 CUR 条目、装回缺失版本、判断事务嵌套深度 —— 那些需要
# CUR / store / 账本，留在 RakuPM::Installer。本类只负责**这个目录的格式与生命周期**：
# 分配 id、写三个 json、记 current、列举、裁剪。因此它是纯目录操作，可以独立单测。

use JSON::Fast;
use RakuPM::Fs;

unit class RakuPM::Installer::Generations;

has IO::Path $.dir is required;      # 即 <target>/generations

# 某个世代的目录
method generation-dir(Str $id --> IO::Path) { $!dir.add($id) }

# 分配下一个世代 id（六位零填充的十进制，字典序 == 数值序）。
method next-id(--> Str) {
    return '000001' unless $!dir.d;
    my @ids = $!dir.dir.grep(*.d).map(*.basename).grep(/^ \d+ $/).sort;
    (@ids ?? @ids[*-1].Int + 1 !! 1).fmt('%06d')
}

# 记录当前世代
method set-current(Str $id --> Nil) {
    mkdir-p($!dir);
    $!dir.add('current').spurt($id);
}

# 当前世代 id（没有世代则空串）
method current(--> Str) {
    my $f = $!dir.add('current');
    $f.e ?? $f.slurp.trim !! ''
}

# 所有世代（按 id 升序），每条含 id / current / created-at / label / installed
method list(--> List) {
    return () unless $!dir.d;
    my $cur = self.current;
    $!dir.dir.grep(*.d).map(*.basename).grep(/^ \d+ $/).sort.map(-> $id {
        my $mf = $!dir.add($id).add('meta.json');
        my %m  = $mf.e ?? ((try from-json($mf.slurp)) // {}) !! {};
        %(
            id         => $id,
            current    => ($id eq $cur),
            created-at => (%m<created-at> // ''),
            label      => (%m<label> // ''),
            installed  => (%m<installed> // []),
        )
    }).List
}

# 所有保留世代的 manifest 里出现过的 (name\0version) 集合。
# 供 RakuPM::Cleaner.protected-versions 合并：rollback-to 会把账本恢复到某个
# 世代的 manifest，缺了的版本从 store 装回（见 Installer.!restore-missing-from-store）。
# 若 clean 把这些版本从 store 回收了，回滚就只能留空世代 + 警告。所以这些版本
# 【绝不能进回收列表】，哪怕它们已经不在当前账本 / 锁 / 自家 site 里。
# 返回 %( "Name\0ver" => True, ... )，空目录 / 解析失败都安全返回空集合。
method protected-versions(--> Hash) {
    my %keep;
    return %keep unless $!dir.d;
    for $!dir.dir.grep(*.d).map(*.basename).grep(/^ \d+ $/) -> $id {
        my $mf = $!dir.add($id).add('manifest.json');
        next unless $mf.e;
        my @entries = (try from-json($mf.slurp)) // ();
        for @entries -> %e {
            my $n = (%e<name> // '').Str;
            next unless $n.chars;
            for (|@(%e<versions> // []), (%e<version> // '')).map(*.Str).grep(*.chars) -> $v {
                %keep{"$n\0$v"} = True;
            }
        }
    }
    %keep
}

# 只保留最近 $keep 个世代（当前世代永不删）。
# 注意：裁剪发生在**提交之后**，所以当前世代一定在 @g 里且一定不会被删。
method prune(Int $keep = 10 --> Nil) {
    my @g = self.list;
    return if @g.elems <= $keep;
    for @g[0 ..^ (@g.elems - $keep)] -> %g {
        next if %g<current>;
        try rm-tree($!dir.add(%g<id>));
    }
}

# 开一个世代目录，写入 before.json，返回事务哈希 { id, dir, label, started, before }。
# $before 是事务【开始前】的账本 JSON 文本（调用方负责读，没有账本时传 '[]'）。
method begin(Str :$label = 'install', Str :$before = '[]' --> Hash) {
    mkdir-p($!dir);
    my $id = self.next-id;
    my %tx = (
        id      => $id,
        dir     => $!dir.add($id),
        label   => $label,
        started => DateTime.now.Str,
        before  => $before,
    );
    mkdir-p(%tx<dir>);
    %tx<dir>.add('before.json').spurt($before);
    %tx
}

# 提交：写 meta.json（本次装了什么）与 manifest.json（提交后的账本），
# 把该世代设为 current，然后裁剪最老的世代。
method finish(%tx, Str :$ledger-json = '[]', List :$installed = () --> Nil) {
    return unless %tx<id>.defined;
    %tx<dir>.add('meta.json').spurt(to-json({
        id         => %tx<id>,
        label      => %tx<label>,
        created-at => DateTime.now.Str,
        started-at => (%tx<started> // ''),
        # // '' 守卫：调用方若误把 Hash 展平成 Pair 传进来（Raku 里 [%h] 会摊成
        # 单键 Hash），直接插值会喷一屏 "Use of Nil in string context"。宁可写空。
        installed  => $installed.map({ "{.<name> // ''} {.<version> // ''}" }).List,
    }, :sorted-keys));
    %tx<dir>.add('manifest.json').spurt($ledger-json);
    self.set-current(%tx<id>);
    self.prune;
}

# 丢弃这个半成品世代（回滚 / 本次什么都没装时用）
method discard(%tx --> Nil) {
    return unless %tx<id>.defined;
    try rm-tree(%tx<dir>);
}
