# RakuPM::Resolver — 依赖解析器
#
# 这是包管理器的灵魂。给定「我要装哪些模块」，输出一个「安装顺序」：
#   1. 从仓库找到能提供该模块的发行版
#   2. 递归解析它的依赖（用版本约束挑版本）
#   3. 检测冲突（同一模块被两个版本约束要求）
#   4. 拓扑排序（依赖先于被依赖者安装）
#
# 对应 zef 的 find-candidates + find-prereq-candidates。

use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::Repository;

unit class RakuPM::Resolver;

has RakuPM::Repository @.repos;

# 已选择的发行版：模块名 => Distribution（保证每个模块只装一份）
has %!chosen;
# 与 %!chosen 平行：模块名 => 选中该发行版的【来源仓库 id】。
# Distribution 模型本身不带仓库信息（它只认名字/版本/依赖），而「这个版本是从
# 哪个仓库解析出来的」是 `why` 诊断命令要回答的问题，所以解析时把仓库 id 一起记下来。
has %!chosen-repo;
# 同一个模块被哪些「请求人」要求过什么版本？冲突时报错要把这个完整链打出来，
# 光说「被选为 X、但要求 Y」没用 —— 用户没法决定该 pin 哪边、报告哪边。
# 形状：Hash[Str, Array[Hash[Str,Str]]] = module => [ {requester => $dist.name, version => $constraint}, ... ]
has %!wanted;
# 正在解析中的栈，用于检测循环依赖
has @!stack;
# 解析过程中发现的依赖环。生态数据里真实存在互相依赖的发行版
# （典型：NativeLibs 提供模块 NativeHelpers::Blob，而 NativeHelpers::Blob
#  又声明依赖 NativeLibs），直接 die 会把一大批包误杀掉，所以这里只记录 + 提示。
has @!cycles;
# 冲突重试时已经试过的版本：module => SetHash[version]。
# 防止「改选 → 新版本的依赖又冲突 → 再改选」来回震荡。
has %!retried;
# 钉版：模块名 => 版本字符串。用户用 --pin 显式指定的版本，解析时覆盖任何来路
# 的约束（依赖方提出的、CLI 位置参数给的都算），用精确匹配（=）锁定。用于固定
# 某个（哪怕只是传递的）依赖版本，避免解析器挑到不兼容的新版。
has %!pins;
# 最近一次冲突的结构化记录（`!die-conflict` 在 die 之前填好）。
# `why` 诊断命令不靠 die 来报冲突，而是读这里拿到「冲突模块 + 双方约束」，
# 与 fatal 路径共用同一份数据，避免两套实现漂移。无冲突时为 Nil。
has %!last-conflict;

# 供调用方（Client）在解析后读取，用于打印提示
method cycles(--> List) { @!cycles.List }

# 调试/诊断用：解析结果「模块名 => 发行版名」
method chosen(--> Hash) {
    my %h;
    for %!chosen.kv -> $m, $d { %h{$m} = $d.name ~ ':' ~ $d.version }
    %h
}

# 入口：解析一个模块名 + 可选版本约束，返回拓扑排序后的发行版列表
# :auth 用于 zef 风格的 `Foo:ver<1.0>:auth<zef:x>` —— 只在候选里挑 auth 匹配的那份
method resolve(Str $module, Str $constraint = '', Str :$auth = '', :%pins --> List) {
    # 注意：不能写成 `resolve-all([%( module => ..., constraint => ... )])`。
    # `[ ... ]` 会把 %() 展平成【两个独立的 Pair】，于是 resolve-all 收到的是
    # 两个「哈希」而不是一个含一个哈希的数组，%s<module> 拿到 Nil。
    # 用 `(%spec,)` 这种尾逗号写法才能构造出「单元素列表里的一个哈希」。
    my %spec = %( module => $module, constraint => $constraint, auth => $auth );
    self.resolve-all((%spec,), :%pins);
}

# 调试/诊断用：解析结果「模块名 => { 发行版名, 版本, 来源仓库 id }」。
# 与 chosen() 不同，这里把来源仓库也一起带出来（`why` 命令要报「从哪个仓库解析的」）。
method chosen-detail(--> Hash) {
    my %h;
    for %!chosen.kv -> $m, $d {
        %h{$m} = %(
            name    => $d.name,
            version => $d.version,
            repo    => %!chosen-repo{$m} // '',
        );
    }
    %h
}

# ============ `why` 依赖解析诊断 ============
#
# 把「解析是怎么发生的」讲清楚，不再是黑盒。给定一组根规格（形如
# %( module => 'Foo', constraint => '1.0+', auth => '' )），它跑一遍解析，
# 然后返回一个结构化诊断：每个被点名的模块（以及冲突涉及的模块）的
#   · chosen        —— 最后选中的发行版名 / 版本 / 来源仓库（解析失败时可能为空）
#   · constraint    —— 合并后的有效约束（多个约束用 ' / ' 连接；只有 '*' 时为 '*'）
#   · candidates    —— 全部候选（名称 / 版本 / 仓库 / 是否满足约束 / 淘汰原因）
#   · wanted        —— 谁因为什么要求过这个模块（完整请求链，冲突报错就靠它）
# 以及整次解析的汇总：
#   · ok            —— 是否解析成功（无冲突、无找不到）
#   · conflict      —— 若有冲突：{ module, existing => {name,version}, requesters => [...] }
#   · error         —— 若失败但不是冲突（如找不到模块）：fatal 路径的原始报错
#
# 与 install 用的 resolve-all 的区别：这里**不 die**。冲突时把冲突信息存进
# %!last-conflict 并返回 ok=False，让调用方（why 命令）把「双方约束」友好地讲出来，
# 而不是抛一句「依赖冲突」打断用户。正常安装路径仍走 resolve-all（会 die）。
method explain-all(@specs, :%pins --> Hash) {
    %!chosen = Hash.new;
    %!chosen-repo = Hash.new;
    %!wanted = Hash.new;
    @!stack  = ();
    @!cycles = ();
    %!retried = Hash.new;
    %!last-conflict = %();
    %!pins = %pins;

    my $died = False;
    my $err-msg = '';
    try {
        for @specs -> %s {
            self!resolve-one(%s<module>, %s<constraint> // '', %s<auth> // '');
        }
        self!topo-sort;
        CATCH { default { $died = True; $err-msg = .Str; } }
    }

    # 要展示的模块：用户点名的 + 冲突涉及的（冲突模块可能不在点名列表里）
    my %mods;
    for @specs -> %s { %mods{%s<module>} = True }
    if %!last-conflict && %!last-conflict<module>.defined {
        %mods{%!last-conflict<module>} = True;
    }
    my %out-modules;
    for %mods.keys.sort -> $m {
        %out-modules{$m} = self!explain-module($m);
    }

    %(
        :ok( !$died ),
        :conflict( %!last-conflict // %() ),
        :error( $died ?? $err-msg !! '' ),
        :modules( %out-modules ),
    )
}

# 单个模块的诊断细节（explain-all 的内部）。见 explain-all 的字段说明。
method !explain-module(Str $m --> Hash) {
    my %r;
    %r<chosen> = %();
    if %!chosen{$m}:exists && %!chosen{$m}.defined {
        %r<chosen> = %(
            name    => %!chosen{$m}.name,
            version => %!chosen{$m}.version,
            repo    => %!chosen-repo{$m} // '',
        );
    }

    # 合并约束：收集对该模块的所有「非空且非 '*'」约束（去掉重复）
    my @constraints = (%!wanted{$m} // []).list.map(-> %w { (%w<version> // '').trim })
        .grep({ .chars && $_ ne '*' }).unique;
    %r<constraint> = @constraints.elems ?? @constraints.join(' / ') !! '*';

    # 候选：逐个标注「是否满足约束」与「淘汰原因」
    my @cands = self!candidates-sorted($m).map(-> %c {
        my $v = RakuPM::Version.from-string(%c<version>);
        my $sat = @constraints.elems
            ?? so all(@constraints.map({ $v.satisfies($_) }))
            !! True;
        my $reason = do {
            if !$sat {
                "不满足约束 {%r<constraint>}"
            }
            elsif %r<chosen><version> eq %c<version> {
                "满足约束 {%r<constraint>} 的最高版本（选中）"
            }
            else {
                "满足约束但版本较低，{%r<chosen><version>} 更高"
            }
        };
        %(
            name      => %c<name>,
            version   => %c<version>,
            repo      => %c<repo>,
            satisfies => ?$sat,
            reason    => $reason,
        );
    }).List;
    %r<candidates> = @cands;

    # 完整请求链（谁因为什么要求过这个模块）
    %r<wanted> = (%!wanted{$m} // []).list.map(-> %w {
        %( requester => (%w<requester> || '<top-level>'),
           version   => %w<version> )
    }).List;

    %r
}

# 同时解析多个根模块。每项形如 %( module => 'Foo', constraint => '1.0+' )。
# auth 可选（依赖串里也可能带 :auth<>，但生态数据里同一个模块通常只有一个 auth，
# 所以只支持在顶层指定，传递依赖不按 auth 过滤）。
#
# 与「逐个调用 resolve 再把结果拼起来」的区别：整批共享同一份 %!chosen，
# 所以
#   · 同一模块只会被选一次，不会装两份；
#   · 跨依赖的版本冲突能被检出（A 要 Foo>=2，B 要 Foo<2 会报冲突）；
#   · 拓扑排序一次完成，安装顺序是自底向上的全局顺序。
# git 安装就是典型场景：目标包的依赖是一组根，而不是单个根。
method resolve-all(@specs, :%pins --> List) {
    %!chosen = Hash.new;
    %!chosen-repo = Hash.new;
    %!wanted = Hash.new;
    @!stack  = ();
    @!cycles = ();
    %!retried = Hash.new;
    %!last-conflict = %();
    %!pins = %pins;
    for @specs -> %s {
        self!resolve-one(%s<module>, %s<constraint> // '', %s<auth> // '');
    }
    self!topo-sort;
}

# 递归解析单个模块
# $requester 是谁因为什么要把这个模块装上 —— 用于冲突时报错定位
# （顶层的 resolve 传 ''，递归时传当前正在解析的发行版名）
method !resolve-one(Str $module, Str $constraint is copy, Str $auth = '', Str $requester = '') {
    # Raku 编译器本身：生态里有些发行版写 "Rakudo:ver<2026.07>" 来表达
    # 「需要 Raku 编译器 >= 某版本」。它不是一个可安装的包 —— 编译器已经在跑了，
    # 也没有 tarball 可下载。zef 同样是直接跳过。
    # 用户实测：装 DB::MySQL 时依赖链里冒出 Rakudo:ver<2026.07>，
    # 解析器把它当普通包去下载，索引条目没有 source-url，于是整个安装崩掉。
    if self!is-compiler($module) {
        self!check-compiler($module, $constraint, $requester);
        return;
    }

    # 核心模块（随 Rakudo 一起发布、不在任何生态索引里，永远可用）。
    # 典型：Test（单元测试框架）常被写进 test-depends，但它不是可安装的包，
    # 解析器若拿它去仓库里找会直接 die —— self-upgrade 装 RakuPM 自身时
    # 就踩到（META6.test-depends 含 Test → 解析失败 → 整个升级回滚）。
    # 与上面的编译器处理同构：zef 同样是直接跳过。
    # 注意：只放【确实随编译器发布、确定不在任何生态里】的模块；
    # 像 Test::More 是第三方包，绝不能放进来（否则会漏装真依赖）。
    if self!is-core-module($module) {
        return;
    }

    # 无论是否已选、是否冲突，都把这次请求记下来 —— 冲突时要从这里取完整链路
    %!wanted{$module} //= [];
    %!wanted{$module}.push: { requester => $requester, version => $constraint };

    # 钉版（--pin）：用户显式指定了这个模块的版本，用精确约束覆盖任何来路的约束
    # （依赖方提出的、CLI 位置参数给的都算）。钉版与下面的冲突检测共用同一个
    # $constraint 变量，所以钉版优先级最高 —— 即便某依赖要求别的版本，仍以用户
    # 钉的为准；若二者无法同时满足，冲突报错里会把这条钉版也列出来，便于定位。
    if %!pins{$module}:exists {
        $constraint = "= {%!pins{$module}}";
    }

    # 【顺序很重要】先判「已选好」，再判环。
    # 生态里确实存在互相依赖的发行版，若先判环就会把它们全部误杀：
    #   解析 NativeLibs -> 其 provides 含 NativeHelpers::Blob
    #                   -> 后者依赖 NativeLibs（此刻 NativeLibs 还在栈里）
    # 由于 NativeLibs 已经选定了版本，直接返回即可，不会死递归。
    if %!chosen{$module}:exists {
        my $existing = %!chosen{$module};
        # 版本冲突检测：新约束与已选版本是否兼容
        if $constraint.trim ne '' && $constraint.trim ne '*' {
            my $v = RakuPM::Version.from-string($existing.version);
            unless $v.satisfies($constraint) {
                # 【先别急着判冲突】已选版本不满足新约束，并不代表无解 ——
                # 很可能只是先前挑得太新了。先拿这个模块被要求过的**全部**
                # 约束求交集，能找到「同时满足所有约束」的版本就改选它。
                # 典型场景：A 要 '*'、B 要 '0.0.24'，解析器先给 A 挑了最新的
                # 0.0.25 —— 但 0.0.24 也满足 '*'，交集非空，不该报冲突。
                return if self!retry-with-intersection($module, $existing);
                self!die-conflict($module, $existing, $constraint, $requester);
            }
        }
        return;
    }

    # 兜底防死递归：模块在解析栈中且尚未选定。正常流程到不了这里
    # （入栈与选定是同时发生的），留着是为了逻辑完备 + 记录环。
    if $module (elem) @!stack {
        @!cycles.push((@!stack, $module).join(' -> '));
        return;
    }

    # 找能提供这个模块的发行版（含来源仓库 id）
    my $got = self!find-best($module, $constraint, $auth);
    unless $got && $got<dist>.defined {
        my $extra = $constraint && $constraint.trim ne '' ?? " (约束 $constraint)" !! '';
        $extra ~= " (auth $auth)" if $auth.trim ne '';
        die "在所有已配置的仓库里都找不到模块 '$module'$extra。\n"
          ~ "  已配置的仓库：{@!repos.map(*.id).join(', ')}\n"
          ~ "  提示：\n"
          ~ "    · 用 `raku-pm repos list` 看当前挂了哪些仓库；\n"
          ~ "    · 用 `raku-pm repos add rea` 加上 Raku 生态存档（收录更全，含历史版本）；\n"
          ~ "    · 也可以直接装 git 仓库：`raku-pm install https://github.com/<owner>/<repo>.git`";
    }
    my $dist = $got<dist>;

    # 【关键】选出来的发行版可能是 Raku 编译器本身。
    #
    # 生态里有包依赖 NativeCall 这类**核心模块**，而 REA 索引里正是
    # "Rakudo" 这个发行版 provides 了它们 —— 实测 Rakudo 2026.07 provides
    # 24 个模块（NativeCall / MoarVM::* / Pod::To::Text …）且条目没有
    # source-url。编译器已经在运行，那个条目也没有源码可下，zef 同样不装。
    #
    # 只看请求的【模块名】拦不住这种情况（请求的是 NativeCall，不是 Rakudo），
    # 必须看 find-best 实际选出来的【发行版名】。
    if self!is-compiler($dist.name) {
        self!check-compiler($dist.name, $constraint, $requester);
        return;
    }

    @!stack.push($module);
    %!chosen{$module} = $dist;
    %!chosen-repo{$module} = $got<repo> // '';

    # 递归解析依赖（把当前发行版名传下去当请求人）
    for $dist.depends.kv -> $dep-module, $dep-constraint {
        self!resolve-one($dep-module, $dep-constraint, '', $dist.name);
    }

    @!stack.pop;
}

# 这个「模块」其实是 Raku 编译器本身吗？生态里统一用发行版名 Rakudo 表达
# 对编译器版本的要求（REA 索引里确实有 Rakudo 这个条目）。
method !is-compiler(Str $module --> Bool) {
    $module eq 'Rakudo' || $module eq 'rakudo' || $module eq 'Raku' || $module eq 'raku'
}

# 随 Rakudo 一起发布的语言内置模块：不在任何生态索引里、永远可用，
# 不应被当成可安装依赖去解析。典型的就是 Test（单元测试框架），
# 很多模块的 test-depends 都写它；它不是包，硬去仓库里找会直接 die
# （自升级 RakuPM 自身时就踩到：test-depends 含 Test → 解析失败回滚）。
# 注意：只放真正随编译器发布、确定不在任何生态里的模块；
# 像 Test::More 是第三方包，绝不能放进来（否则会漏装真依赖）。
my constant CORE-MODULES = set <Test>;
method !is-core-module(Str $module --> Bool) {
    $module (elem) CORE-MODULES
}

# 核对当前运行的 Raku 编译器版本是否满足约束。
# 满足（或约束为空 / '*'）→ 静默返回，调用方跳过安装；
# 不满足 → 明确报错，因为包确实声明了需要更新的编译器。
method !check-compiler(Str $module, Str $constraint, Str $requester --> Nil) {
    my $have = $*RAKU.compiler.version.Str.subst(/^v/, '');   # 如 2026.08
    return if $constraint.trim eq '' || $constraint.trim eq '*';
    return if RakuPM::Version.from-string($have).satisfies($constraint);

    my $who = $requester.chars ?? "（由 {$requester} 要求）" !! '';
    die "{$module} 版本不满足{$who}：需要 {$constraint}，当前运行的 Raku 编译器是 {$have}。\n"
      ~ "  请升级 Rakudo 后重试，或改装对编译器版本要求更低的旧版本。";
}

# 版本冲突时给出【完整】冲突信息，否则光说「X 选了 A、B 要 B」根本没法动手。
# 形如：
#   依赖冲突：模块 'ANSI' 同时被这些发行版要求不同版本
#       Foo::Bar 1.0   →  ANSI:ver<0.0.25>
#       Baz 2.3       →  ANSI:ver<0.0.24>
#     最后选定的版本是 0.0.25
#
# 接下来你可以：pin 其中一边的版本让约束一致，或者报告上游。
method !die-conflict(Str $module, RakuPM::Distribution $existing, Str $constraint, Str $requester --> Nil) {
    # 取该模块被要求过的所有 {requester, version}，按 (请求人,版本) 排重
    my %seen;
    my @reqs;
    for %!wanted{$module}.list -> %r {
        my $key = (%r<requester> // '<top-level>') ~ "\0" ~ %r<version>;
        next if %seen{$key}++;
        # 注意：这里是 () 不是 : —— Raku 方法调用里 ":" 是命名参数语法，
        # `push: %r` 会被当成 :r(%r) 而不是位置参数，%r 就不进数组。
        @reqs.push(%r);
    }

    # 顺手把冲突结构化存下来：`why` 诊断命令不靠 die 来报冲突，而是读这里
    # 拿到「冲突模块 + 双方约束 + 最后选定的版本」，与 fatal 路径共用同一份数据。
    %!last-conflict = %(
        :module($module),
        :existing(%( name => $existing.name, version => $existing.version )),
        :requesters(@reqs.map(-> %r {
            %( requester => (%r<requester> || '<top-level>'),
               version   => %r<version> )
        }).List),
    );

    # 先说选定的，再说谁要什么 —— 顺序反了读者要先想一步「为什么这两条不相容」
    my $msg = "依赖冲突：模块 '$module' 同时被这些发行版要求不同版本 — 无法同时满足\n";
    $msg ~= "  最后选定的版本是 {$existing.version}（被 {$existing.name} 提供）\n";
    $msg ~= "  冲突的版本要求：\n";
    for @reqs.list -> %r {
        # 用 %r<requester> 拿请求人名；%r<version> 拿约束串。
        # 注意是 %r（参数）不是 $r —— $r 绑的是字符串，%r 才是 Hash（参数本身）。
        # 顶层调用时 requester 是空串，falsy —— 用 || 触发默认；// 只对 undef 生效，对 '' 没用。
        my $r = %r<requester> || '<top-level>';
        $msg ~= "    {$r} → {$module} {%r<version>}\n";
    }
    die $msg;
}
#
# 挑版本有三个坑，这里逐一处理：
#   1) 同一发行版的 provides 会随版本变化 —— 必须先按「该版本确实提供此模块」
#      过滤，否则会挑中一个根本不含该模块的高版本
#      （DBIish 0.6.8 之于模块 NativeLibs 就是这种）。
#   2) 不同发行版之间的版本号没有可比性 —— 优先选「发行版名与模块名一致」
#      的正主（NativeLibs 模块应由 NativeLibs 发行版提供），再比版本高低。
#   3) 版本比较必须走 semver，不能用字符串 cmp（"0.9" > "0.10" 是错的）。
#
# $auth 非空时只在 auth 匹配的候选里挑 —— 对应 zef 的 `Foo:ver<1.0>:auth<x>`。
# 收集某模块的全部候选 (发行版名, 版本) 并排好序 —— 不做约束过滤。
# 排序：同名正主优先 → 版本降序 → 名字字典序（保证结果稳定可复现）。
method !candidates-sorted(Str $module --> List) {
    # 找到所有「某版本曾提供过」该模块的发行版名字
    my @dist-names;
    for @!repos -> $repo {
        @dist-names.append(|$repo.find-providers($module));
    }
    @dist-names = @dist-names.unique;

    # 展开成「确实提供该模块」的 (发行版, 版本, 来源仓库) 组合
    my @cands;
    for @dist-names -> $dn {
        for @!repos -> $repo {
            for $repo.versions-providing($module, $dn) -> $v {
                @cands.push(%( name => $dn, version => $v, repo => $repo.id ));
            }
        }
    }
    return () unless @cands.elems;
    # 同一个 (发行版,版本) 可能在多个索引里重复出现，去重保证结果稳定
    @cands = @cands.unique(as => { .<name> ~ "\0" ~ .<version> });

    # .sort 返回的是 Seq，而签名承诺 List —— 必须显式 .List，
    # 否则「Type check failed for return value; expected List but got Seq」。
    @cands.sort(-> $a, $b {
        my $ca = ($a<name> eq $module) ?? 1 !! 0;
        my $cb = ($b<name> eq $module) ?? 1 !! 0;
        ($cb <=> $ca)
            || (RakuPM::Version.from-string($b<version>)
                  .cmp(RakuPM::Version.from-string($a<version>)))
            || ($a<name> cmp $b<name>)
    }).List
}

# 从【已排序】的候选里自上而下取第一个能物化的（候选为空时返回 Nil）。
# 要按 auth 过滤时在已排序的候选上自上而下挑，于是结果仍是
# 「满足约束且 auth 匹配的最高版本」—— 不必为过滤 auth 去物化所有候选。
# 返回 %( dist => Distribution, repo => 仓库id ) 或 Nil：调用方要报「来自哪个仓库」。
method !materialize-first(@sorted, Str $auth = '' --> Hash) {
    for @sorted -> $c {
        for @!repos -> $repo {
            next unless $c<version> (elem) $repo.available-versions($c<name>);
            my $d = $repo.fetch-distribution($c<name>, $c<version>);
            next unless $d.defined;
            return %( dist => $d, repo => $repo.id )
                if $auth.trim eq '' || $d.auth eq $auth;
        }
    }
    Nil
}

# 单个约束：找满足它的最高版本（空串与 '*' 在 satisfies 里视为「任意」）
method !find-best(Str $module, Str $constraint, Str $auth = '' --> Hash) {
    my @ok = self!candidates-sorted($module).grep({
        RakuPM::Version.from-string(.<version>).satisfies($constraint)
    });
    self!materialize-first(@ok, $auth)
}

# 多个约束：找【同时满足所有约束】的最高版本 —— 即多约束求交集。
#
# 这是「'*' 与 '0.0.24' 被误判为冲突」的解药（用户装 Terminal::UI 时踩到）：
# 解析器先给要 '*' 的那边挑了最新的 0.0.25，于是要 '0.0.24' 的那边看起来
# 冲突；但 0.0.24 同样满足 '*' —— 交集非空，应当改选 0.0.24 而不是报错。
method !find-best-satisfying-all(Str $module, @constraints, Str $auth = '' --> Hash) {
    my @sorted = self!candidates-sorted($module);
    return Nil unless @sorted.elems;
    # 空串与 '*' 不参与过滤（satisfies 里也视为「任意」）。
    # 注意这里必须写中缀 `$_ ne '*'` —— 写成 `.ne '*'` 会被解析成
    # 「方法 .ne」后跟一个裸字符串，直接 "Two terms in a row" 编译错。
    my @cs = @constraints.map(*.trim).grep({ $_.chars && $_ ne '*' }).unique;
    return self!materialize-first(@sorted, $auth) unless @cs.elems;

    my @ok = @sorted.grep({
        my $v = RakuPM::Version.from-string(.<version>);
        so all(@cs.map({ $v.satisfies($_) }))
    });
    self!materialize-first(@ok, $auth)
}

# 收集某模块的全部候选（发行版名, 版本, 来源仓库 id），不做约束过滤、已排序。
# 暴露给 `why` 诊断命令：它要把「所有候选 + 谁被淘汰 + 淘汰原因」一次性列出来。
method candidates-for(Str $module --> List) {
    self!candidates-sorted($module).map(-> %c {
        %( name => %c<name>, version => %c<version>, repo => %c<repo> )
    }).List
}

# 已选版本不满足新约束时，尝试改选一个「同时满足该模块所有已知约束」的版本。
# 返回 True 表示改选成功（调用方应直接 return，不要报冲突）。
method !retry-with-intersection(Str $module, $existing --> Bool) {
    # 这个模块被要求过的所有约束（新来的那个在调用前已 push 进 %!wanted）
    my @constraints = %!wanted{$module}.list.map({ ($_<version> // '').trim });

    # 记录已试过的版本：当前这个刚证明不行，别再选回它
    %!retried{$module} //= SetHash.new;
    %!retried{$module}.set($existing.version);

    my $better = self!find-best-satisfying-all($module, @constraints);
    return False unless $better.defined && $better<dist>.defined;
    # 这个版本已经试过 → 说明改选后又被绕回来了，再试只会震荡，交给 die-conflict
    return False if %!retried{$module}{$better<dist>.version};

    %!retried{$module}.set($better<dist>.version);

    # 改选，并重新解析它的依赖 —— 新版本的依赖可能与旧版本不同
    %!chosen{$module} = $better<dist>;
    %!chosen-repo{$module} = $better<repo> // '';
    @!stack.push($module);
    for $better<dist>.depends.kv -> $dep-module, $dep-constraint {
        self!resolve-one($dep-module, $dep-constraint, '', $better<dist>.name);
    }
    @!stack.pop;
    True
}

# 拓扑排序：用 Kahn 算法，确保依赖先于被依赖者
method !topo-sort(--> List) {
    # %deps{A} = [B, C] 表示 A 依赖 B、C（安装时 B、C 应在 A 之前）
    my %deps;
    my %in-degree;   # A 的入度 = A 还有多少个依赖没装
    my %by-name;
    for %!chosen.values -> $dist {
        %by-name{$dist.name} = $dist;
        %in-degree{$dist.name} //= 0;
        for $dist.depends.keys -> $dep {
            # 依赖模块名 -> 提供它的发行版名字
            my $dep-dist-name = self!dist-name-for-module($dep);
            # 自环（发行版依赖自己提供的模块）会让入度永远减不到 0，直接忽略
            %deps{$dist.name}.push($dep-dist-name)
                if $dep-dist-name && $dep-dist-name ne $dist.name;
        }
    }

    # 计算入度：A 依赖 B，则 A 的入度 +1（A 要等 B 装完）
    for %deps.kv -> $dist-name, @ds {
        %in-degree{$dist-name} += @ds.elems;
    }

    # Kahn 拓扑排序：入度为 0（无未满足依赖）的先装
    my @queue = %in-degree.keys.grep({ %in-degree{$_} == 0 }).sort;
    my @result;
    my %visited;
    while @queue {
        my $name = @queue.shift;
        next if %visited{$name}++;
        @result.push($name);
        # A 装好后，所有「依赖 A」的包（B where deps[B] 含 A）入度 -1
        for %deps.kv -> $depender, @ds {
            if $name (elem) @ds {
                %in-degree{$depender}--;
                @queue.push($depender) if %in-degree{$depender} == 0;
            }
        }
    }

    # 生态数据里存在真实的依赖环（如 NativeLibs ⟷ NativeHelpers::Blob），
    # Kahn 算法排不出来。这部分绝不能丢掉——否则包会静默消失、装完却用不了。
    # 兜底：按名字排序补在最后，并记录到 @!cycles 让调用方提示用户。
    if @result.elems < %by-name.elems {
        my %done = @result.map({ $_ => True });
        my @left = %by-name.keys.grep({ !%done{$_} }).sort;
        if @left {
            @!cycles.push(@left.join(' ⟷ '));
            @result.append(@left);
        }
    }

    # 返回发行版对象（按安装顺序：依赖在前）
    @result.map({ %by-name{$_} }).grep(*.defined).List
}

# 通过模块名找到「提供它的发行版名字」
method !dist-name-for-module(Str $module --> Str) {
    for %!chosen.kv -> $mod, $dist {
        return $dist.name if $mod eq $module;
    }
    Str
}
