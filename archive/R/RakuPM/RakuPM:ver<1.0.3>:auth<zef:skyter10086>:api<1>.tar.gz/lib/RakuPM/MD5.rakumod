# RakuPM::MD5 — 内置的 MD5（RFC 1321），Store 内容指纹专用
#
# 只有一个用途：Store 的内容指纹。之前依赖生态的 Digest::MD5
# （发行版名叫 "Digest"，grondilu 维护），但它的解析在部分环境
# （WSL 上 zef 报「已安装」而 use 找不到）极不可靠 —— raku-pm 自己
# 的安装/测试全被这一个外部依赖卡死。
#
# MD5 只用于「检测内容是否变化」，不用于密码学。RFC 1321 全套
# 测试向量在 t/md5.t 里钉死，指纹值与生态版完全一致（老 store 兼容）。
#
# 性能（重要）：纯 Raku 的 MD5 只有约 0.16 MB/s —— store 里 296 个文件（2.1 MB）
# 要 10.9 秒。并行 / 多进程都救不了（实测 8 线程仅 1.18x：MoarVM 上纯 Raku 的
# CPU 密集计算不真正并行；多进程又被每个 raku 子进程 ~1s 的启动成本吃掉）。
# 所以结论是那句朴素的话：**CPU 密集的活交给原生代码**。两级策略：
#   1. 原生实现（首选）：NativeCall 绑系统 libcrypto 的 MD5()。同一批文件实测
#      **0.246s**（比纯 Raku 快 44 倍）。库名跨平台不同（Linux 常常只有带版本的
#      libcrypto.so.3 / libcrypto.so.1.1、macOS 是系统的 libcrypto.dylib、Windows
#      看机器上有没有 libcrypto.dll），故写成多个候选 sub，首次调用逐个试并用
#      RFC 1321 向量自校验；全不可用才落到第 2 级。
#   2. 纯 Raku 回退：去装箱版（buf8.allocate + 原生 int @S/@K/@M + 按偏移索引），
#      保证「任何环境都算得出来」。它慢，但配合 store 的校验清单旁车
#      （见 RakuPM::Store 的 .files.json）也只在「内容真的变过」时才付这笔钱。
# RAKUPM_MD5=raku 可强制走纯 Raku（调试 / 与原生路径对照用）。
#
# 【要不要额外装 OpenSSL？不用。】libcrypto 是**系统库**，不是 raku-pm 的新依赖 ——
# META6.json 里没加任何依赖，zef 也不会去装它。设计是「有就用、没有就自动回退纯 Raku」，
# 两边算出的指纹逐位一致，只是慢一点。各平台实际情况：
#   · macOS：系统自带 /usr/lib/libcrypto.dylib（Apple 的 LibreSSL）—— 开箱可用；
#   · Linux：libcrypto.so.3 通常随 openssl 包，绝大多数发行版默认已装
#     （curl / git / ssh 的依赖链）—— 基本开箱可用；
#   · Windows：**不保证**。有的机器 system32（或某个软件目录）里有 libcrypto.dll
#     （本项目开发机实测是 LibreSSL 3.8.2，随某个软件带进来的），全新装机可能没有 ——
#     那就走纯 Raku + 校验清单旁车兜底（约 1.9s，见 RakuPM::Store）。
#
# 【历史】0.85.0 及以前还有一条中间层「≥64KB 的文件走系统 md5 命令」
# （Windows certutil -hashfile / Linux md5sum / macOS md5 -q）。0.86.0 删掉：
#   · 原生绑定在 Linux/macOS 上普遍可用、且快得多（0.25s 一次算完全部文件，
#     而不是每个文件起一个进程）；
#   · 那条路径带一堆平台特例和真坑 —— 中文 Windows 上 certutil 输出是 GBK，
#     `slurp` 按 UTF-8 解码抛错又被吞掉，曾让这条「加速路径」**静默失效**：
#     每个大文件白起一次进程 + 再跑一遍纯 Raku，比直接用纯 Raku 还慢。
# 少一条路径 = 少一类只在某个平台上才暴露的 bug。

use NativeCall;

unit module RakuPM::MD5;

# ---- 原生 MD5：NativeCall 绑系统 libcrypto -------------------------------------
# 标准签名：unsigned char *MD5(const unsigned char *d, size_t n, unsigned char *md)
# 库名在 NativeCall 里必须是编译期字面量，所以每个候选写一个 sub；真正的库加载与
# 调用发生在【首次调用】时（拿不到库会抛错，由 native-md5() 里的 try 接住）。
sub md5-libcrypto(      Blob, size_t, Blob --> Pointer) is native('libcrypto')         is symbol('MD5') { * }
sub md5-libcrypto-so3(  Blob, size_t, Blob --> Pointer) is native('libcrypto.so.3')    is symbol('MD5') { * }
sub md5-libcrypto-so11( Blob, size_t, Blob --> Pointer) is native('libcrypto.so.1.1')  is symbol('MD5') { * }
sub md5-libcrypto-so(   Blob, size_t, Blob --> Pointer) is native('libcrypto.so')      is symbol('MD5') { * }
sub md5-libcrypto-dy3(  Blob, size_t, Blob --> Pointer) is native('libcrypto.3.dylib') is symbol('MD5') { * }
sub md5-libcrypto-dy(   Blob, size_t, Blob --> Pointer) is native('libcrypto.dylib')   is symbol('MD5') { * }

# Windows 补充候选：与 macOS/Linux 不同，**Windows 不自带** libcrypto，全新装机多半
# 一个都命中不了（那也没关系 —— 探测失败就跳过，落纯 Raku + 清单兜底）。但
# Git for Windows 几乎是人人都装的，它自带一份 libcrypto-3-x64.dll：既可能在 PATH 上
# （裸名命中），也可能只在安装目录（绝对路径命中）。实测开发机上两者都能加载。
# 单引号字符串不做转义，反斜杠就是字面量。
sub md5-git-x64(        Blob, size_t, Blob --> Pointer) is native('C:\Program Files\Git\mingw64\bin\libcrypto-3-x64.dll')       is symbol('MD5') { * }
sub md5-git-x86(        Blob, size_t, Blob --> Pointer) is native('C:\Program Files (x86)\Git\mingw64\bin\libcrypto-3-x64.dll') is symbol('MD5') { * }
sub md5-git-name(       Blob, size_t, Blob --> Pointer) is native('libcrypto-3-x64.dll') is symbol('MD5') { * }

# 首次调用时探测：逐个候选 + 用 RFC 1321 的 'abc' 向量自校验（防「库在、但符号
# 行为不对」这类意外）。结果缓存（&fn 或 Nil）。**刻意不在模块 import 期探测** ——
# 那会让每条命令的启动都付一次库加载钱，而多数命令根本不碰 MD5。
sub native-md5(--> Mu) {
    state $fn = do {
        my Blob $probe = 'abc'.encode('utf-8');
        my Str  $want  = '900150983cd24fb0d6963f7d28e17f72';
        my $found;
        for &md5-libcrypto, &md5-libcrypto-so3, &md5-libcrypto-so11, &md5-libcrypto-so,
            &md5-libcrypto-dy3, &md5-libcrypto-dy,
            &md5-git-x64, &md5-git-x86, &md5-git-name -> &f {
            my $ok = (try {
                my $out = buf8.allocate(16);
                f($probe, $probe.elems, $out);
                # 注意 List.fmt(%fmt) 的默认分隔符是 ", " —— 必须显式给空串，
                # 否则拼出来是 "90, 01, 50, …" 而不是纯 hex（自校验会全部误判失败）。
                $out.list.fmt('%02x', '') eq $want;
            }) // False;
            if $ok { $found = &f; last }
        }
        $found
    };
    $fn
}

# 原生路径当前是否可用（供诊断 / 测试用）。
sub native-md5-available(--> Bool) is export { native-md5().defined }

# RFC 1321 的 64 个移位位数（原生 int，去装箱）
my int @S = flat (7,12,17,22) xx 4, (5, 9,14,20) xx 4,
                 (4,11,16,23) xx 4, (6,10,15,21) xx 4;

# 64 个常量：floor(2^32 × |sin(i+1)|)
my int @K = (0..63).map(-> $i { (2**32 * abs(sin($i + 1))).floor +& 0xFFFFFFFF }).Array;

sub rol(uint32 $x, int $n --> uint32) {
    ((($x +< $n) +& 0xFFFFFFFF) +| ($x +> (32 - $n))) +& 0xFFFFFFFF
}

# 核心：对任意 Blob 做 MD5，返回 32 位小写十六进制。
# 【首选原生】CPU 密集的活交给 libcrypto（见文件头注释）：同一批 store 文件实测
# 0.246s vs 纯 Raku 10.97s。RAKUPM_MD5=raku 可强制跳过原生（调试 / 对照）。
multi md5-hex(Blob $data --> Str) is export {
    unless (%*ENV<RAKUPM_MD5> // '') eq 'raku' {
        with native-md5() -> &f {
            my $out = buf8.allocate(16);
            f($data, $data.elems, $out);
            return $out.list.fmt('%02x', '');
        }
    }
    # ---- 纯 Raku 回退（下面这条路径在任何环境都要能算出正确结果）----
    my int $n     = $data.elems;
    my int $total = (($n + 8) div 64 + 1) * 64;   # +1(0x80) + 8(长度) 对齐到 64
    my $buf = buf8.allocate($total);

    # 拷贝原始数据
    my int $i = 0;
    while $i < $n { $buf[$i] = $data[$i]; ++$i }
    $buf[$n] = 0x80;
    # 64 位小端长度（bit 数）
    my $bits = $n * 8;
    my int $t = $total - 8;
    my int $j = 0;
    while $j < 8 { $buf[$t + $j] = ($bits +> (8 * $j)) +& 0xFF; ++$j }

    my int $a0 = 0x67452301;
    my int $b0 = 0xEFCDAB89;
    my int $c0 = 0x98BADCFE;
    my int $d0 = 0x10325476;

    my int @M;

    my int $off = 0;
    while $off < $total {
        # 小端 32 位字
        my int $k = 0;
        while $k < 16 {
            my int $p = $off + 4 * $k;
            @M[$k] = $buf[$p]          +| ($buf[$p + 1] +< 8)
                   +| ($buf[$p + 2] +< 16) +| ($buf[$p + 3] +< 24);
            ++$k;
        }

        my int $A = $a0; my int $B = $b0; my int $C = $c0; my int $D = $d0;

        my int $i2 = 0;
        while $i2 < 64 {
            my int $F; my int $g;
            if $i2 < 16 {
                $F = ($B +& $C) +| (($B +^ 0xFFFFFFFF) +& $D);
                $g = $i2;
            }
            elsif $i2 < 32 {
                $F = ($D +& $B) +| (($D +^ 0xFFFFFFFF) +& $C);
                $g = (5 * $i2 + 1) % 16;
            }
            elsif $i2 < 48 {
                $F = $B +^ $C +^ $D;
                $g = (3 * $i2 + 5) % 16;
            }
            else {
                $F = $C +^ ($B +| ($D +^ 0xFFFFFFFF));
                $g = (7 * $i2) % 16;
            }
            $F = ($F + $A + @K[$i2] + @M[$g]) +& 0xFFFFFFFF;
            $A = $D;
            $D = $C;
            $C = $B;
            $B = ($B + rol($F, @S[$i2])) +& 0xFFFFFFFF;
            ++$i2;
        }

        $a0 = ($a0 + $A) +& 0xFFFFFFFF;
        $b0 = ($b0 + $B) +& 0xFFFFFFFF;
        $c0 = ($c0 + $C) +& 0xFFFFFFFF;
        $d0 = ($d0 + $D) +& 0xFFFFFFFF;
        $off += 64;
    }

    # ---- 输出：四个字各按小端展开成十六进制（小写、零填充）----
    my $out = '';
    for $a0, $b0, $c0, $d0 -> $w {
        my int $j2 = 0;
        while $j2 < 4 {
            $out ~= (($w +> (8 * $j2)) +& 0xFF).fmt('%02x');
            ++$j2;
        }
    }
    $out
}

multi md5-hex(Str $s --> Str) is export {
    md5-hex($s.encode('utf-8'))
}

# ---- 文件入口（Store.!fingerprint 调这个）----

# 读取文件全部字节。绕开 Rakudo 2026.07 的一个 bug：IO::Path.slurp(:bin)
# 在文件恰好 1048576 字节（2^20）时抛「Out of range: attempted to read 0
# bytes from filehandle」（1048575 / 1048577 都正常），open(:bin).slurp(:close)
# 不受影响。
sub slurp-bytes(IO::Path $path --> Buf) {
    my $fh = $path.open(:bin);
    my $buf = $fh.slurp(:close);
    $buf
}

# 文件内容指纹的统一入口：读进内存后交给 md5-hex（原生优先，纯 Raku 回退）。
#
# 0.86.0 起【删掉了】原先「≥64KB 就走系统 md5 命令」的中间层：
#   · 原生绑定可用时它完全多余（一次算完全部文件 0.25s，而系统命令是每个文件
#     起一个进程）；
#   · 原生不可用时它也救不了小文件（起进程 ~0.25s 比纯 Raku 算一个小文件还慢），
#     却长期带着一堆平台特例：certutil / md5 -q / md5sum 三种输出格式、平台命令
#     名、以及中文 Windows 上 certutil 输出 GBK 导致整条路径静默失效的坑。
# 现在只剩两条路：原生 → 纯 Raku，任何环境都算得出来，且没有平台分支。
sub md5-file(IO::Path $path --> Str) is export {
    md5-hex(slurp-bytes($path))
}
