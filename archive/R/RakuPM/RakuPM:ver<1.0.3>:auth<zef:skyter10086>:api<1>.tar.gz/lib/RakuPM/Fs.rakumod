# RakuPM::Fs — 文件系统小工具（递归删除 / 复制 / 遍历 / 体积）
#
# 【为什么要把这几行抽出来】
# 这些操作原先散在 8 个模块里各写一份，而且每份的细节都不一样：
#   · rm-tree   4 份：Installer / Store / Cleaner / SelfManager
#   · copy-tree 2 份：Store / Git
#   · 目录遍历  5 份：Distribution / NativeLib / SelfManager / Store / Author
# 重复的代价不只是行数：
#   1) 跳过规则不一致 —— 「跳过 .precomp」这类修正在一处生效、在另一处漏掉
#      （0.36.14 之前 Store 收了 .precomp 导致指纹漂移 + store 膨胀 17 倍）；
#   2) 异常兜底不一致 —— 有的 try 兜底有的没有，Windows 上 rmdir 静默失败；
#   3) **最隐蔽的一条**：惰性 `for $d.dir` 会在整个递归期间持有目录句柄，
#      Windows 上句柄要等 GC 才关，调用方随后 rmdir 该目录会因「目录在使用中」
#      失败（NativeLib 曾因此残留空目录；测试的 LEAVE 清理也踩过）。
# 所以本模块统一：**一律急切收集 `my @entries = $d.dir`** + 统一的跳过规则
# + 统一的 try 兜底。以后这类修正只需要改一处。
#
# 零依赖：只用 Raku 内置 IO，任何模块都能安全 use（不引入模块图）。

unit module RakuPM::Fs;

# 派生 / 元数据产物，不属于「发行版内容」，递归时默认跳过。
#   .git/.hg/.svn  VCS 元数据
#   .precomp       Rakudo 预编译字节码（派生，会自动重建）
#   blib           传统 Perl/Raku 构建输出目录
constant DEFAULT-SKIP-DIRS is export = < .git .hg .svn .precomp blib >;

# 递归删目录树（路径不存在时无操作）。
# best-effort：单个条目删不掉不中断（Windows 上文件被占用很常见），
# 失败留给调用方按「目录是否还在」自行判断，而不是让整轮清理崩掉。
sub rm-tree(IO::Path $path --> Nil) is export {
    return unless $path.e;
    unless $path.d {
        try $path.unlink;
        return;
    }
    # 急切收集：及时释放目录句柄，之后才能 rmdir 成功
    my @entries = $path.dir;
    rm-tree($_) for @entries;
    try $path.rmdir;
}

# 逐级创建目录（等价 `mkdir -p`），已存在则无操作。返回 $p 以便链式调用。
#
# 为什么不用 IO::Path.mkdir 的 :parents / :p —— Rakudo 2026.08 上它的签名是
#     :(IO::Path:D $: Int(Any) $mode = 511, *%_)
# 只有 $mode，**没有任何 :parents**；传 :parents / :p 会被 *%_ 静默吞掉 ——
# 不报错、也不生效。Windows 上因为 CreateDirectoryW 本身就会自动建父目录而
# 「看起来正常」，Linux 上 mkdir(2) 不建父目录，于是
# `<root>/<name>/<version>` 这类深层路径会直接失败。属于「只在 Linux/CI 上炸、
# 本机 Windows 测不出来」的一类，实测签名确认过才改成逐级创建。
sub mkdir-p(IO::Path $p --> IO::Path) is export {
    return $p if $p.d;
    my @missing;
    my $cur = $p;
    loop {
        last if $cur.e;
        my $parent = $cur.parent;
        last if $parent.absolute.Str eq $cur.absolute.Str;   # 已经到根
        @missing.push($cur);
        $cur = $parent;
    }
    for @missing.reverse { try { $_.mkdir } }
    $p
}

# 把一段【外来字符串】净化成「单个安全的路径分量」，不可信则直接 die。
#
# 【为什么必须有这个函数（0.87.0 安全修复）】
# 发行版名与版本号来自**包自己的 META6.json / 生态索引行** —— 即由发布者控制。
# 而它们会被直接当作路径分量拼进 store / 下载缓存 / 日志目录：
#     <root>/store/<name>/<version>/...
# 修复前这里只做 `subst('::', '-')`（旧名 !safe-name，名字叫 safe 其实只做模块
# 分隔符替换），`version` 连这层都没有。于是
#     name = "../../../../../../tmp/PWNED"
# 会把文件写到 target **之外**（实测逃到 C:\Users\<me>\tmp\PWNED，任意文件写入）。
# 同类的还有 version、以及 Ecosystem 的下载缓存路径（索引行可控）。
#
# 【为什么用 die 而不是「静默清理」——这条只适用于**穿越类**字符】
# 静默把 `../x` 改成 `x` 会让不同发行版**撞进同一个目录**（互相覆盖），比拒绝更危险；
# 而且这类名字 100% 是恶意的或数据损坏，没有"用户其实想要这个"的合法场景。
# 失败要吵、要指名道姓。
#
# 【两类字符，处理方式刻意不同（0.87.4 明确划线，别混起来）】
#   · **穿越类**（`/` `\` `:` 控制字符、恰为 `.` / `..`、结尾点）→ 直接 **die**。
#     它们要么能逃出目标目录，要么会让两个不同名字落到同一处 —— 有安全含义，
#     而且没有"用户其实想要这个"的场景。
#   · **Windows 保留类**（`* ? " < > |`）→ **百分号编码**（见函数体第 5 步）。
#     它们拼不出目标之外的路径（既不是分隔符也不是 `.`/`..`），只是让文件名在
#     Windows 上非法；拒绝它们等于让真实存在的一批包彻底装不上 —— 实测里
#     version 是占位符 `*` 的条目有 109 条（Add / Algorithm::Viterbi / Apache::LogFormat…）。
#     既然不存在"清理导致撞车"的风险，就该让它可用，而不是拒绝。
#
# 【向后兼容】对一切合法输入，本函数与旧的 `subst('::','-')` **输出逐字节相同**
# （JSON::Fast → JSON-Fast），所以历史 store 条目仍然可达、不会被判成"未入库"。
# 例外有二，都是**本来就无法当路径**的输入，不存在"历史条目失联"的顾虑：
#   ① 名字里含**单个冒号**的少数发行版（真实生态有 App:Ralc、Slang:Date 共 5 条），
#      0.87.0 起归一到 `-`；它们在 Windows 上本来就无法作目录名（`mkdir App:Ralc`
#      会写成文件 App 的 ADS），归一等于修好它们。
#   ② 含 `* ? " < > |` 的（实测只有那 109 条 `*`），0.87.4 起按下方规则编码；
#      它们在 Windows 上本来就建不出文件（报 Invalid argument）。
sub path-component(Str $s, Str :$what = '路径分量' --> Str) is export {
    my $t = ($s // '').trim;
    die "$what 为空，不能作为路径分量" unless $t.chars;

    # 生态惯例：模块分隔符落成 -（保持 0.87.0 之前的既有映射）。
    # 单个冒号也一并归一到 -：它在 Windows 上是 ADS 分隔符（`App:Ralc` 会变成
    # 文件 App 的备用数据流），Linux 上虽合法却与同名目录产生歧义；归一后两边一致。
    my $c = $t.subst('::', '-', :g).subst(':', '-', :g);

    # 1) 路径分隔符：这一条就杀掉了 `../x`、`a/b`、`..\x` 等全部相对/嵌套写法
    die "$what「{$s}」含路径分隔符（/ 或 \\），拒绝——疑似路径穿越"
        if $c ~~ / <[ / \\ ]> /;

    # 2) 恰为 . 或 .. ——（1）已挡掉 `../x`，剩下的唯一穿越形态就是分量本身是 ..
    die "$what「{$s}」是 . 或 ..，拒绝——疑似路径穿越"
        if $c eq '.' | '..';

    # 3) 控制字符：会把日志/终端输出搞乱，也是各类路径解析差异的来源
    die "$what「{$s}」含控制字符，拒绝"
        if $c ~~ / <[ \x00..\x1f \x7f ]> /;

    # 4) 结尾的点：Windows 会**静默剥掉**，于是 "foo." 与 "foo" 落到同一处
    #    —— 属于"看起来装了两个、实际互相覆盖"那类难查的问题。
    #    （结尾空格在上面的 trim 里已经规范化掉了，故这里实际只拦点。\s 保留是
    #     为了兜住 trim 覆盖不到的情形，属防御性冗余。）
    die "$what「{$s}」以点结尾（Windows 会静默剥掉，与同名前缀目录冲突），拒绝"
        if $c ~~ / <[ . \s ]> $ /;

    # 5) Windows 保留字符 → 百分号编码（上面几条是「拒绝」，这里是「归一」，见函数头
    #    的「两类字符」说明：这些字符拼不出目标之外的路径，只是文件名在 Windows 上非法）。
    #
    #    实测影响面（全量索引 25117 条）：`*` 出现在 109 条（全是 version 占位符，
    #    如 Add / Algorithm::Viterbi / Apache::LogFormat），`? " < > | %` 各 0 条。
    #    这 109 条的 source-url 本身是好的（URL 里是 `%2A` 编码），坏的只有本地缓存
    #    路径：旧行为在 Windows 上把路径变成 `.../<name>/*.tar.gz` → 打开失败报
    #    `Invalid argument`、重试 3 次后回滚，报错完全看不出真因；其它平台上则会造出
    #    一个名字就是 `*` 的垃圾文件（还会被 shell 的 glob 展开）。编码后两边都对。
    #
    #    【为什么编码而不是替换成 `_` 之类】编码是**单射**的 —— 不同输入永远落到不同
    #    输出，所以不会出现两个分量撞进同一个目录（那正是"静默清理"最危险的地方）；
    #    而且可逆，能从目录名读回原始值。`%` 自己必须一起编码，否则 "a%2A" 与 "a*"
    #    会撞车（这就是下表里 `%` → `%25` 的原因，也是它必须与其它字符**同一次替换**
    #    完成的原因：分两次做会把先写进去的 `%` 再编码一遍）。
    my %ENCODE = '%' => '%25', '*' => '%2A', '?' => '%3F',
                 '"' => '%22', '<' => '%3C', '>' => '%3E', '|' => '%7C';
    $c = $c.subst(/ <[ % * ? " < > | ]> /, -> $m { %ENCODE{~$m} }, :g);

    $c
}

# containment 断言：$child 必须落在 $root 之内（含 $root 自身）。不满足直接 die。
#
# 这是**第二道防线**：path-component 已经在入口挡住了穿越，但"入口"会随代码演进而
# 增多（新加一处拼路径就可能漏做净化）。在真正落盘前再断言一次，任何遗漏都会立刻
# 变成一条明确的错误，而不是一次静默的越界写入。
sub assert-under(IO::Path $child, IO::Path $root, Str :$what = '路径' --> Nil) is export {
    my $c   = $child.absolute.Str;
    my $r   = $root.absolute.Str;
    my $sep = $*SPEC.dir-sep;
    return if $c eq $r || $c.starts-with($r ~ $sep);
    die "$what 逃出根目录：{$c} 不在 {$r} 内";
}

# 递归收集 $path 下的全部【普通文件】，返回 IO::Path 列表。
#   :@skip-dirs  跳过的目录名（默认 DEFAULT-SKIP-DIRS）
#   :@skip-names 跳过的文件名
# 结果按【绝对路径】排序 —— 让指纹计算、tar 清单、provides 扫描都稳定可复现
# （同一份内容在任何机器上得到同样的遍历顺序）。
sub walk-files(IO::Path $path,
               :@skip-dirs = DEFAULT-SKIP-DIRS,
               :@skip-names = () --> List) is export {
    my @out;
    sub recurse(IO::Path $dir) {
        return unless $dir.e && $dir.d;
        my @entries = $dir.dir;      # 急切收集
        for @entries -> $entry {
            my $base = $entry.basename;
            if $entry.d {
                next if $base (elem) @skip-dirs;
                recurse($entry);
            }
            elsif $base (elem) @skip-names {
                next;
            }
            else {
                @out.push($entry);
            }
        }
    }
    recurse($path);
    # .sort 返回 Seq，签名承诺 List —— 必须显式 .List
    @out.sort({ .absolute.Str }).List
}

# 递归复制目录树。$dest 不存在则创建；已存在则**合并**（不删除 $dest 里多余的文件）。
# 调用方通常先 rm-tree 清空再 copy（保证结果可复现），见 Installer.pending-cur-spec
# / cleanup-stage-all（整树事务化暂存路径）。
#
# 【防呆】目标若位于源目录内部，`$dest.mkdir` 之后 `$src.dir` 就已经包含 $dest，
# 递归会自我复制到路径长度爆炸（实测报 "Failed to mkdir: name too long" 并把
# 几百层目录留在磁盘上）。这里直接拒绝，把一个难查的无限递归变成一条清晰报错。
sub copy-tree(IO::Path $src, IO::Path $dest,
              :@skip-dirs = DEFAULT-SKIP-DIRS --> Nil) is export {
    my $sep = $*SPEC.dir-sep;
    die "copy-tree：目标目录不能位于源目录内部（{$dest.absolute} 在 {$src.absolute} 内）"
        if $dest.absolute.Str.starts-with($src.absolute.Str ~ $sep);
    mkdir-p($dest);
    my @entries = $src.dir;          # 急切收集
    for @entries -> $entry {
        next if $entry.basename (elem) @skip-dirs;
        my $d = $dest.add($entry.basename);
        $entry.d ?? copy-tree($entry, $d, :@skip-dirs) !! $entry.copy($d);
    }
}

# 递归统计目录体积（字节）。拿不到的文件按 0 计（不抛）。
sub dir-size(IO::Path $path --> Int) is export {
    return 0 unless $path.e;
    return (try { $path.s }) // 0 unless $path.d;
    my $n = 0;
    for (try { $path.dir }) // () -> $e { $n += dir-size($e) }
    $n
}
