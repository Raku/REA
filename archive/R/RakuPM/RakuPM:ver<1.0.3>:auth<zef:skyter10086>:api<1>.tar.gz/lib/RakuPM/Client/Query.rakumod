# RakuPM::Client::Query — 只读 / 诊断 role
#
# 原名 Reporter，但里面实际还塞了 uninstall / rollback / autoremove 等写命令，
# 名字误导人（以为只是「报告」）。0.79.4 起把三个写命令拆回 RakuPM::Client
# （编排器），本 role 从此只承载【只读查询 + 诊断 + native 库检查】：
#   list / which / why / depends / rdepends / locate / browse / info / store /
#   doctor / verify / search / list-available / env / lock / generations
# 与安装流程共享的 native 库检查（check-native-libs 等）留在本 role，
# 因为 Client / Git role 的安装前检查也通过 self! 调用它们。

use RakuPM::Distribution;
use RakuPM::Version;
use RakuPM::Spec;
use RakuPM::NativeLib;
use RakuPM::Net;
use RakuPM::Platform;
use RakuPM::Repository::Matching;
use RakuPM::UI;       # 终端展示层（色彩 / 表格）—— 零依赖，非 TTY 自动降级为纯文本
use RakuPM::Message;  # 用户面消息与退出码的唯一出口（warn/error/hint/fail-die）；
                      # 本报告角色里的 stderr 端提示一律走它，不再裸 note/die，
                      # 与 bin 的 CLI 校验报错保持同一套「措辞 + 退出码」出口。
use RakuPM::InstallOptions;

# `raku-pm which`（不带参数 = 冲突总览）最多列几条。
# 放在 unit 之前 = 模块作用域常量，不随 role 实例化（role 体内的 `my` 是每实例一份）。
constant MAX-SHOWN = 15;

# does RakuPM::Repository::Matching：查询命令（search / store / installed）
# 的「关键词怎么算匹配一个发行版」与仓库层共用同一份实现。search 用
# match-score（模糊 + 相关度分级），store / installed 用 match-exact
# （精确名或精确模块名）。见 lib/RakuPM/Repository/Matching.rakumod。
unit role RakuPM::Client::Query does RakuPM::Repository::Matching;
# 汇总一批发行版声明的本地库，逐个探测（返回详细信息供 CLI 展示）
method check-native-libs(@dists --> List) {
    my @libs = @dists.map(*.native-libs).flat.unique;
    return () unless @libs;
    RakuPM::NativeLib.new.check(@libs)
}
# 外部命令依赖（META6 的 :from<bin> / :from<Perl5>）：不是 Raku 包，raku-pm
# 既不会去仓库里找它、也装不了它。以前这类条目会被当普通模块解析，于是
# Doc::TypeGraph（要 graphviz 的 dot）之类直接报“找不到模块 'dot'”而装不上。
# 现在只在 PATH 里查一下，缺了就提示，不阻断安装。
method check-external-deps(@dists --> List) {
    @dists.map(*.external-deps).flat.map(*.Str).unique.sort.List
}

method !check-external-deps(@order --> Nil) {
    my @need = self.check-external-deps(@order);
    return unless @need;
    my (@ok, @miss);
    for @need -> $cmd {
        self!has-command($cmd) ?? @ok.push($cmd) !! @miss.push($cmd);
    }
    return unless @miss;              # 全都有就不啰嗦

    say "";
    say "外部命令依赖检查（raku-pm 不负责安装系统命令）：";
    say "    ✓ $_  已在 PATH 中" for @ok;
    say "    ✗ $_  未在 PATH 中找到" for @miss;
    msg-hint "";
    msg-warn "⚠  缺少 {@miss.elems} 个外部命令：{@miss.join(', ')}";
    msg-hint "   请先用系统包管理器装好（apt / brew / choco …）；Raku 代码照常会装好。";
}

# 在 PATH 里找可执行文件（Windows 上补 .exe/.bat/.cmd 后缀）。
# 平台差异（分隔符、扩展名）走 RakuPM::Platform —— 那里可被测试遮蔽。
method !has-command(Str $cmd --> Bool) {
    has-executable($cmd)
}

# 安装流程里的检查 + 打印。
# 已装的不啰嗦（一行 ✓），缺的才展开说明并给本系统的安装命令。
method !check-native-libs(@order --> Nil) {
    return unless @order;
    my @got = self.check-native-libs(@order);
    return unless @got;
    self!report-native(@got);
}

# 运行时 native 库（`is native('...')`，源码里直接 NativeCall，META6 不声明
# `:from<native>`）的缺失检查。与 !check-native-libs 互补：Duckie 的 libduckdb
# 就是这种，静态依赖检查看不到，这里在「取到源码后、跑测试前」补上。
# 在事务内调用，缺失即 die → 由 !install-chain 的 CATCH 回滚（不会误触发回滚
# 之外的动作）。随包分发的 resources/libraries/<x> 由 Rakudo 经 %?RESOURCES 解析，
# 不算系统缺失，跳过（避免误杀 GDBM 这类把库打进 resources 的包）。
method !check-runtime-native-libs(RakuPM::Distribution $dist, IO::Path $source --> Nil) {
    return unless $source.defined && $source.d;
    my @rt = RakuPM::NativeLib.new.runtime-native-libs($source);
    return unless @rt;

    # 已纳入 :from<native> 覆盖的不再重复；随包 resources/libraries/ 分发的跳过
    my @known  = $dist.native-libs.list;
    my @bundle = $dist.resources.grep(*.starts-with('libraries/'))
                           .map(*.substr(10))          # 去 'libraries/' 前缀
                           .map(*.subst(/\..*$/, '')); # 去扩展名，留逻辑名
    my @check  = @rt.grep({ $_ !~~ @known && $_ !~~ @bundle });
    return unless @check;

    my @got = RakuPM::NativeLib.new.check(@check);
    return unless @got;
    self!report-native(@got, :note("（含运行时 `is native(...)` 加载的库）"));
}

# 统一的「打印探测结果 + 缺失即放弃安装」逻辑，供上面两个检查共用。
# :$note 可选，附在标题后说明这批库的来源（静态 / 运行时）。
method !report-native(@got, Str :$note = '' --> Nil) {
    return unless @got;
    my $nl = RakuPM::NativeLib.new;
    say "";
    say "本地库依赖检查（{$nl.os-label}，raku-pm 不打包系统库）{$note}";
    for @got -> $r {
        if $r<found> {
            say "    ✓ {$r<name>}  已在 {$r<path>}";
        }
        else {
            say "    ✗ {$r<name>}  未找到 —— 本系统需要 {$r<files>}";
            say "                  安装：{$r<hint>}";
        }
    }

    my @missing = @got.grep({ !$_<found> }).map(*<name>);
    if @missing {
        # 缺失即放弃安装：继续往下走也只会在「加载库」阶段才炸（如 Duckie 缺
        # libduckdb.so 时 18 个测试失败），还附一大段内部调用栈，不如现在就明说。
        # --no-native-check 由调用方在更外层跳过本方法，故这里不用再判那个开关。
        fail-die "⚠  {$nl.os-label} 上缺少 {@missing.elems} 个本地库，放弃安装："
          ~ "{@missing.join(', ')}\n"
          ~ "   请先按上面的命令装好本地库，再重试安装。\n"
          ~ "   （`raku-pm native <名字>` 可单独查询；如确需跳过本检查，"
          ~ "可加 --no-native-check，但运行时加载这些库仍会失败）";
    }
    say "    → 全部就绪。";
}
# 展示 store 中缓存了哪些包。
# :$name 可选 —— 给模块名时只看那一个（展示它的全部缓存版本与各自的完整路径）；
# 不给则列全部。行内星号 = 当前激活版本。
# :$constraint 版本约束（"1.0" / ">=1.0" / "1.0+"…）：只显示满足约束的版本。
#   CLI 侧由规格串解析填进来（`raku-pm store 'Foo:ver<1.0>'` / `store Foo@1.0`）。
#
# :$verify 默认 False —— 这是个「列目录」命令，不该顺手把每个版本的全部文件
# 读一遍算 MD5。纯 Raku 的 MD5 只有 ~0.2MB/s，store 里存了多份 RakuPM 时
# （每份含 lib + bin）光哈希就要几十秒，看起来像卡死。
# 真要校验内容完整性请用 --verify，或用专门的 `raku-pm verify`。
method show-store(Str $name = '', Str :$constraint = '', Bool :$verify = False --> Nil) {
    # 名字匹配走共用的 match-exact：精确发行名 或 精确 provided 模块名
    # （store 目录叫 Web-App，`store Web::App` 也能找到）。
    my @names = $name.chars
        ?? self.store.all-names.grep({
               self.match-exact($_, self.store.provides-of($_), $name)
           })
        !! self.store.all-names;

    if @names.elems == 0 {
        say $name.chars
            ?? "store 里没有 {$name}（试试 `raku-pm store` 看缓存了哪些包）"
            !! "存储为空（{self.store-root}）";
        return;
    }

    my $store-root = self.store-root.Str;
    say $name.chars
        ?? "{$name} 的缓存版本（{$store-root}）："
        !! "本地存储 {$store-root}：";

    my $shown = 0;   # 带约束时可能一个版本都筛不出来，别让输出静默为空
    for @names.sort -> $n {
        my @vs = self.store.cached-versions($n);
        my $active = self.installer.installed-version($n);
        # 版本目录按 semver 升序（与 installed-versions 同规则，不用字典序）
        @vs = RakuPM::Version.new.sort-versions(@vs);
        # 版本约束筛选（`store 'Foo:ver<1.0>'` 同款语义）：不满足的版本不显示
        if $constraint.chars {
            @vs = @vs.grep({ RakuPM::Version.from-string($_).satisfies($constraint) });
            next unless @vs.elems;
        }
        $shown++;
        for @vs -> $v {
            my $mark = ($active.defined && $active eq $v) ?? '*' !! ' ';
            # 默认不校验（见方法头注释）：只标出「有没有记过指纹」，O(1) 不读文件内容。
            my $ok = $verify
                ?? (self.store.verify($n, $v) ?? '' !! '  [校验失败]')
                !! (self.store.digest-of($n, $v).chars ?? '' !! '  [无指纹]');
            # 完整路径 = store 的真实磁盘目录（名称里的 :: 已换成 -，path-for 给出真相）
            my $path = self.store.path-for($n, $v).absolute;
            say "  {$mark} {$n} {$v}{$ok}";
            say "       {$path}";
        }
    }
    say "" if $shown;
    if $shown == 0 && $constraint.chars {
        say "（没有版本满足约束 {$constraint}）";
    }
    elsif $verify {
        say "（* = 当前激活版本；[校验失败] = 内容指纹对不上，可能被改动过）";
    }
    else {
        say "（* = 当前激活版本；路径是 store 里该版本源码缓存的完整位置，重装不需要再下载）";
        say "（默认不重算内容指纹——那要把每个版本的文件全读一遍，很慢；";
        say "  要校验完整性请加 --verify，或用 `raku-pm verify`）";
    }
}
# 对账自愈：site/（自己的安装仓库）里有、账本却缺记的包 → 补记。
# 历史版本格式差异、安装中断都可能造成这种不一致；不补记的话
# installed 看不到它，用户会以为 raku-pm 把自己装的包弄丢了。
# :$chain 可注入（测试用），生产路径默认走进程仓库链。
method reconcile-installed(:$chain = $*REPO.repo-chain --> Nil) {
    my %have = self.installer.list-installed.map({; $_<name> => True });
    for @$chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        # 只补记自己 site 里的包；zef 侧的包在 installed 里单独展示
        my $prefix = try { $repo.prefix.absolute } // '';
        next unless $prefix && $prefix eq self.installer.repo-prefix.absolute;
        for $repo.installed -> $d {
            my $n = $d.meta<name> // '';
            next if %have{$n};
            my %prov = $d.meta<provides> // {};
            my @p = %prov ~~ Hash ?? %prov.keys !! @(%prov);
            my $v = ($d.meta<version> // $d.meta<ver> // '0.0.0').Str;
            my $rd = RakuPM::Distribution.new(
                :name($n), :version($v),
                :auth(($d.meta<auth> // '').Str),
                :provides(@p), :depends({}));
            say "  · 账本缺记，从 site 补记：{$n} {$v}";
            self.installer.record-entry($rd);
            %have{$n} = True;
        }
    }
}
# 列出已安装。
# :$name 可选 —— 给模块名时只看那一个（它的全部版本、激活标记与来源）；
# 不给则列全部（own + zef 侧）。
# :$constraint / :$auth —— 版本约束与作者筛选（CLI 由规格串解析填入，
# `raku-pm installed 'Foo:ver<1.0>'` / `installed 'Foo:auth<zef:x>'`）。
# 只显示满足约束的版本；一个都不满足时明确提示，而不是悄悄什么都不出。
# 版本字符串列表按 semver 升序（去重 + 去空）。
# 走 RakuPM::Version.sort-versions 统一入口——字典序会把 0.9.2 误判成
# 高于 0.13.0，显示与「取最高版本」都会错。
method !sort-versions(@v --> List) {
    RakuPM::Version.new.sort-versions(@v)
}
method list-installed(Str :$name = '', Str :$constraint = '', Str :$auth = '' --> Nil) {
    self.reconcile-installed;

    # 数据源 1：raku-pm 账本
    my @list = self.installer.list-installed;
    # 名字匹配走共用的 match-exact：精确发行名 或 精确 provided 模块名
    # （`installed Web::App` 也能命中目录名是 Web-App 的包）。子串留给 search。
    @list = @list.grep({ self.match-exact($_<name>, @($_<provides> // []), $name) })
        if $name.chars;
    # auth 规格（`installed 'Foo:auth<zef:x>'`）：账本条目的 auth 是最后
    # 安装版本的 auth，同名多 auth 的极端情况按条目粒度取舍
    @list = @list.grep({ ($_<auth> // '') eq $auth }) if $auth.chars;
    # 版本约束预筛：整包没有任何版本满足约束时连条目一起剔除，
    # 让后面的「未安装」提示统一覆盖这种情况
    if $constraint.chars {
        @list = @list.grep({
            self.installer.installed-versions($_<name>)
                .first({ RakuPM::Version.from-string($_).satisfies($constraint) }).defined
        });
    }

    # 数据源 2：zef 侧（仓库链上、不由 raku-pm 管理，但依赖解析会认）
    my %own = @list.map({; $_<name> => True });
    my %zef;
    for $*REPO.repo-chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        for $repo.installed -> $d {
            my $n = $d.meta<name> // '';
            next if %own{$n};
            next if !$n.chars;
            # 与账本侧同一判定：精确发行名 或 精确 provided 模块名
            if $name.chars {
                my %prov = $d.meta<provides> // %%;
                my @pn = %prov ~~ Hash ?? %prov.keys !! @(%prov);
                next unless self.match-exact($n, @pn, $name);
            }
            next if $auth.chars && (($d.meta<auth> // '').Str ne $auth);
            my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
            next unless $v.chars;
            # 版本约束（`installed 'Foo:ver<1.0>'`）同样作用于 zef 侧
            next if $constraint.chars
                && !RakuPM::Version.from-string($v).satisfies($constraint);
            %zef{$n}.push($v);
        }
    }

    if $name.chars && @list.elems == 0 && %zef.elems == 0 {
        if $constraint.chars || $auth.chars {
            my $spec = $name
                ~ ($constraint.chars ?? ":ver<{$constraint}>" !! '')
                ~ ($auth.chars       ?? ":auth<{$auth}>"       !! '');
            say "{$spec} 未安装（raku-pm 与 zef 的仓库里都没有满足约束的版本）。";
            say "试试：raku-pm installed {$name}   ← 不带约束看它已装的全部版本";
        }
        else {
            say "{$name} 未安装（raku-pm 与 zef 的仓库里都没有）。";
            say "试试：raku-pm install {$name}";
        }
        return;
    }
    if !$name.chars && @list.elems == 0 && %zef.elems == 0 {
        say "尚未安装任何包。";
        return;
    }

    if @list.elems {
        my Str $head = $name.chars ?? "已安装（raku-pm）：{$name}" !! "已安装（raku-pm）";
        say ui-bold($head);
        my @rows;
        for @list -> $r {
            # 多版本共存：同一个包可能装了几个版本，都列出来，最高的那个标激活
            my @vs = self.installer.installed-versions($r<name>);
            # 版本约束（`installed 'Foo:ver<1.0>'`）：只显示满足约束的版本行
            @vs = @vs.grep({ RakuPM::Version.from-string($_).satisfies($constraint) })
                if $constraint.chars;
            my $top = self.installer.installed-version($r<name>);
            # 来源：自装/克隆的包记了目录 —— 重装或改代码时知道去哪找。
            # 长路径按显示宽度省略头部（保留目录名），免得一列把整张表撑爆。
            my Str $src = ($r<source>.defined && $r<source>.chars)
                ?? ui-ellipsis($r<source>.Str, 44) !! '';
            for @vs -> $v {
                # 激活版本标绿点；非富文本（管道/重定向/测试）退化成 * 以保证纯 ASCII
                my Str $mark = ($v eq $top)
                    ?? (ui-rich() ?? ui-green('●') !! '*')
                    !! '';
                @rows.push([ $r<name>.Str, $v.Str, $mark, $src ]);
            }
        }
        say ui-table(['包名', '版本', '激活', '来源'], @rows);
        say "";
        say "（{ui-rich() ?? '●' !! '*'} = 不指定版本时 `use` 会拿到的那个；`use <模块>:ver<x.y.z>` 可精确选版本）";
        say "（要让 raku 找得到这些包：{self.installer.raku-lib-spec}）";
    }

    if %zef.elems {
        say "" unless $name.chars;
        my @zrows;
        if $name.chars {
            @zrows.push([ $name.Str, self!sort-versions(%zef{$name}).join(', ') ]);
        }
        else {
            for %zef.keys.sort -> $n {
                @zrows.push([ $n.Str, self!sort-versions(%zef{$n}).join(', ') ]);
            }
        }
        say ui-bold("zef 侧已装（不由 raku-pm 管理，但依赖解析会认）");
        say ui-table(['包名', '版本'], @zrows);
    }
}
# 打印让 raku 能找到已装包所需的环境变量设置。
# 多版本解析依赖 CUR::Installation 的元数据，所以必须用 `inst#` 前缀——
# 少了它，Rakudo 会把目录当普通文件仓库，`:ver<>` 约束就形同虚设。
# ---------- 跨仓库冲突：同名发行版在多个仓库里都装过 ----------
#
# 为什么需要：zef 装到 rakudo 的 site，raku-pm 装到自己的 site，用户还可能手动
# 设了 home（~/.raku）/ 自己的 RAKULIB 目录 —— 同一台机器上同一个包很容易装好几份。
# Rakudo 的解析规则是「仓库链上第一个提供的赢」，**同仓库内多版本取最高**；
# 名字重了不会报错，只会静默用靠前那份。所以「我怎么知道程序加载的是哪一份」
# 必须能查（`raku-pm which`），否则只能靠猜。
#
# 返回 List of Hash：name / variants（不同版本数）/ per（repo 序号 => 版本）。
# 公开：测试直接调用。
method repo-conflicts(--> List) {
    my %by-name;
    my @inst;
    for $*REPO.repo-chain -> $r {
        next unless $r.defined && $r ~~ CompUnit::Repository::Installation;
        @inst.push($r);
    }
    for @inst.kv -> $i, $r {
        try {
            for $r.installed -> $d {
                my $nm = ($d.meta<name> // '').Str;
                next unless $nm.chars;
                my $v = ($d.meta<version> // $d.meta<ver> // '0').Str;
                (%by-name{$nm} //= %{}){$i} = $v;
            }
        }
    }
    my @out;
    for %by-name.kv -> $nm, %per {
        next unless %per.elems >= 2;
        @out.push: %(
            :name($nm),
            :variants(%per.values.unique.elems),
            :per(%per),
        );
    }
    @out.sort({ -$_.<variants>, $_.<name> }).List
}

# 仓库链上的 Installation 仓库（按链顺序，即解析优先级）。
method repo-chain-installations(--> List) {
    my @out;
    for $*REPO.repo-chain -> $r {
        next unless $r.defined && $r ~~ CompUnit::Repository::Installation;
        @out.push($r);
    }
    @out.List
}

# `raku-pm which [模块名]`
#   不给名字：列出全部跨仓库冲突（同一发行版装在多个仓库里），并说明谁生效。
#   给了名字：报出这个**模块**实际从哪个仓库解析、版本多少；多份时全部列出。
method show-which(Str $name = '' --> Nil) {
    my @inst = self.repo-chain-installations;
    if !@inst.elems {
        say "仓库链上没有 Installation 仓库（RAKULIB = " ~ (%*ENV<RAKULIB> // '(未设)') ~ "）";
        return;
    }
    say "仓库链（按解析优先级，越靠前越先赢）：";
    for @inst.kv -> $i, $r { say "  [{$i}] {$r}" }
    say "";

    if $name.chars {
        self!which-module($name, @inst);
        return;
    }
    self!which-conflicts(@inst);
}

method !which-module(Str $name, @inst --> Nil) {
    my @hits;
    for @inst.kv -> $i, $r {
        my $cu = try { $r.resolve(CompUnit::DependencySpecification.new(:short-name($name))) };
        next unless $cu.defined;
        my $meta = (try { $cu.distribution.meta }) // %();
        @hits.push: %(
            :idx($i),
            :repo($r.Str),
            :dist(($meta<name> // '?').Str),
            :ver(($meta<version> // '?').Str),
        );
    }
    if !@hits.elems {
        say "✗ 仓库链上没有任何仓库提供模块 `{$name}`。";
        say "  注意这里要写【模块名】（如 JSON::Fast / RakuPM::Version），不是发行版名；";
        say "  也可能它确实没装（raku-pm search $name 搜生态）。";
        return;
    }
    say "模块 `{$name}` 实际加载：";
    say "  ✓ {@hits[0]<dist>} {@hits[0]<ver>}   来自 [{@hits[0]<idx>}] {@hits[0]<repo>}";
    if @hits.elems > 1 {
        say "";
        say "⚠  另有 {@hits.elems - 1} 份存在但被遮蔽（链上靠前的赢）：";
        for @hits.skip(1) -> $h {
            say "      [{$h<idx>}] {$h<dist>} {$h<ver>}   {$h<repo>}   ← 被上面的遮蔽";
        }
        say "    要改用某一份：把它所在的仓库在 RAKULIB 里排到更前面（见 `raku-pm env`）。";
    }
}

method !which-conflicts(@inst --> Nil) {
    my @clash = self.repo-conflicts;
    if !@clash.elems {
        say "✓ 没有跨仓库冲突：每个发行版只在一个仓库里。";
        return;
    }
    my $diff = @clash.grep({ .<variants> > 1 }).elems;
    say "发现 {@clash.elems} 个发行版存在于多个仓库（其中 {$diff} 个版本还不一样）：";
    say "";
    for @clash.head(MAX-SHOWN) -> $c {
        my @parts;
        # 按仓库序号排序输出（Hash 的 kv 顺序不保证）—— 用户要按这个顺序读优先级。
        for $c<per>.kv.sort({ .key }) -> $k, $v { @parts.push("[{$k}]={$v}") }
        my $flag = $c<variants> > 1 ?? '   ← 版本不同，最危险' !! '';
        say "  {$c<name>}{$flag}";
        say "      " ~ @parts.join('  ');
    }
    if @clash.elems > MAX-SHOWN {
        say "  … 还有 {@clash.elems - MAX-SHOWN} 个（用 `raku-pm which <模块名>` 单查）";
    }
    say "";
    say "怎么读：中括号里的数字是仓库链序号（见上，越小越优先），值是该仓库里的版本。";
    say "        Rakudo 只会用**链上靠前**那份，其余静默失效；同一仓库内多版本取最高。";
    say "怎么处理：① 只走一个包管理器的入口（都走 raku-pm 的 wrapper，或都裸用 raku）；";
    say "          ② 确认没用之后，用对应管理器卸掉多余那份（raku-pm uninstall / zef uninstall）。";
}

# 环境自检：给用户 RAKULIB / PATH 该配什么，并报出「敲 raku-pm 实际会跑哪一份」。
method show-env(--> Nil) {
    my $spec     = self.installer.raku-lib-spec;
    my $bin-path = self.target.add('bin').absolute;
    say "# bash / zsh / Git Bash：";
    say "export RAKULIB=\"$spec\"";
    say "# 重要：要把 \$bin-path 放到 PATH 最前（在 rakudo site/bin 之前）——";
    say "# 否则 zef 装的旧 raku-pm wrapper（断链/过期）会排在前面让你敲错版本。";
    say "export PATH=\"$bin-path:\$PATH\"";
    say "";
    say "# 嫌复制麻烦？直接灌进当前 shell（可 eval，自动识别 shell 类型）：";
    say "eval \"\$(raku-pm shell)\"";
    say "";
    say "# PowerShell：";
    say "\$env:RAKULIB = \"$spec\"";
    say "\$env:PATH = \"$bin-path;\$env:PATH\"";
    say "";
    say "# cmd.exe：";
    my $w = $spec.subst('\\', '\\\\', :g);
    my $b = $bin-path.subst('\\', '\\\\', :g);
    say "set RAKULIB=$w";
    say "set PATH=$b;%PATH%";
    say "";
    say "# 或者每次运行临时指定：";
    say "raku -I\"$spec\" your-script.raku";
    say "";
    say "# bin/ 里是装包时自动放进去的可执行脚本 wrapper（如 raku-pm）——";
    say "# 加到 PATH 后就能直接敲命令名运行。Windows cmd/PowerShell 上";
    say "# 如果 PATH 找不到，看看 `$bin-path` 下是不是有 wrapper 文件。";
    say "";

    # 扫 PATH 中所有 raku-pm 候选：用户装了多个版本后最容易踩这个坑
    self!show-rakupm-on-path();
    say "";
    say "想查「某个包实际从哪个仓库加载、有哪些同名包被遮蔽」：raku-pm which [模块名]";
    say "";
    # 离线状态也在这里报。`--offline` 是个**会改变行为**的开关：排查
    # 「为什么查不到新版本 / 为什么索引没刷新 / 为什么 git 没 pull」时，
    # 第一个该确认的就是它 —— 而它恰恰是设置完就忘的那种状态。
    if offline() {
        say "# 离线模式：已开启（--offline / RAKUPM_OFFLINE=1）";
        say "#   本轮不联网，只用本地缓存与已装内容；去掉 --offline 或 unset 即可联网。";
    }
    else {
        say "# 离线模式：未开启（加 --offline 或设 RAKUPM_OFFLINE=1 可强制只走本地缓存）";
    }
}

# 只输出「可 eval 的环境赋值」，把 raku-pm 环境灌进【当前交互式 shell】。
# 子进程改不了父进程环境，只能把赋值打印出来让用户 eval —— 与 opam / conda 同款：
#   bash / zsh / Git Bash / sh：  eval "$(raku-pm shell)"
#   PowerShell：                  raku-pm shell --shell=pwsh | Invoke-Expression
#   fish：                       raku-pm shell --shell=fish | source
#   cmd.exe：                    raku-pm shell --shell=cmd
# 与 show-env（带说明、给人看）不同，本方法【只打印赋值、无注释、无多余输出】，
# 这样才能安全 eval 进 shell。:$shell 强制格式；不给则按 $*SHELL / COMSPEC 自动判断，
# 回退 bash。
method shell-env(Str :$shell = '' --> Nil) {
    my $spec     = self.installer.raku-lib-spec;
    my $bin-path = self.target.add('bin').absolute;
    my $fmt = $shell.trim.lc || self!detect-shell;
    given $fmt {
        when 'fish' {
            say qq{set -gx RAKULIB "$spec"};
            say qq{set -gx PATH "$bin-path" \$PATH};
        }
        when 'pwsh' | 'powershell' {
            say qq{\$env:RAKULIB = "$spec"};
            say qq{\$env:PATH = "$bin-path;\$env:PATH"};
        }
        when 'cmd' {
            # cmd 里 set 不需要转义，直接给原路径即可（RAKULIB/PATH 用反斜杠或
            # 正斜杠 Rakudo 都认）；不要对反斜杠做翻倍，否则 set 进去的是双反斜杠。
            my $w = $spec;
            my $b = $bin-path;
            say 'set RAKULIB=' ~ $w;
            say 'set PATH=' ~ $b ~ ';%PATH%';
        }
        default {  # bash / zsh / sh / Git Bash
            say qq{export RAKULIB="$spec"};
            say qq{export PATH="$bin-path:\$PATH"};
        }
    }
}

# 按宿主自动判断 shell 格式。顺序：SHELL → COMSPEC → 回退 bash。
method !detect-shell(--> Str) {
    my $shell = %*ENV<SHELL> // '';
    return 'fish'      if $shell ~~ /fish/;
    return 'pwsh'      if $shell ~~ / 'pwsh' | 'powershell' /;
    return 'bash'      if $shell ~~ / 'bash' | 'zsh' | 'sh' /;
    my $comspec = %*ENV<COMSPEC> // '';
    return 'pwsh'      if $comspec ~~ / 'pwsh' /;
    return 'cmd'       if $comspec ~~ / 'cmd'  /;
    return 'bash';
}
# 列出 PATH 中所有 raku-pm 候选位置 + 状态。
# 这是「装了多个版本后哪个 raku-pm 会被敲到」的真相来源 —— 如果最前面
# 那个不是 self.target/bin/raku-pm，用户敲 raku-pm 跑的就是别的副本。
method !show-rakupm-on-path(--> Nil) {
    my @cands = self.detect-bin-on-path('raku-pm');
    return unless @cands;
    say "PATH 中的 raku-pm 候选（按系统实际解析顺序 —— [0] 就是敲 `raku-pm` 时执行的那份）：";
    for @cands.kv -> $i, $c {
        my $tag = $c<ours> ?? '  ← 自装的（本次）' !! '';
        # Raku 的 Str **没有 .pad 方法**（那是别的语言的 API）——
        # 写成 .pad 会直接 "No such method 'pad' for string" 崩掉，
        # 用户跑 `raku-pm env` 时当场炸。左对齐要用 .fmt('%-Ns')。
        # 单独存变量：插值里塞引号+格式化串很容易踩转义坑（踩过多次）。
        my $state = $c<status>.Str.fmt('%-18s');
        my $note  = $c<status> eq 'broken-symlink' ?? '  （断链：不会被命中，建议清理）'
                  !! $i == 0                        ?? '  ← 实际执行这份'
                  !!                                   '  （被前面那份遮蔽，不会被执行）';
        say "  [$i] $state {$c<path>}$tag$note";
    }
    if @cands.first({ !.<ours> && .<status> ~~ any('broken-symlink', 'missing') }) {
        say "";
        say "⚠  有断链 / 不存在的旧 wrapper，请手动删除。";
    }
    # 多份并存时点名最该处理的那一个：被遮蔽的自装 wrapper 等于没生效，
    # 用户会以为「升级了却还是旧版」。这与入口体检（Installer.ensure-bin-entry）
    # 处理的是同一件事，只是这里只报告、不动手。
    my $shadowed-own = @cands.skip(1).first({ .<ours> });
    if $shadowed-own.defined {
        say "";
        say "⚠  自装的 wrapper 被前面的 {@cands[0]<path>} 遮蔽了 —— 敲 `raku-pm` 跑的不是它。";
        say "    重装/升级时会自动把遮蔽者改名备份（<名字>.zef-old），也可以手动处理。";
    }
}
# 通用 PATH 候选扫描（按命令名）。返回 List of Hash: path / status / ours，
# **顺序 = 系统实际的解析顺序**（第一个就是敲这个命令名时会执行的那份）。
#
# 为什么不再用 which/where 的输出顺序（0.48.0 修正，用户现场）：
#   `where raku-pm` 会把同一目录下的候选按它自己的顺序列出来（实测是
#   无扩展名 → .bat → .exe），而 Windows 解析命令名走 PATHEXT（.EXE 优先于
#   .BAT，且根本不含无扩展名）。于是 `env` 声称「第一个就是实际跑的那份」，
#   却指到了 bash wrapper —— 真正被执行的是排在后面的 .exe。本机实测：
#   self-upgrade 升到 0.47.0 之后敲 `raku-pm version` 仍显示 0.46.1，
#   而 `raku-pm env` 却说命中的是 bash wrapper。自查工具给错答案比不给更糟。
#
# 现在改为自己模拟解析：按 PATH 目录顺序，每个目录用
# RakuPM::Platform.pick-command-file（PATHEXT 感知）取该目录会命中的文件；
# 第一个目录的命中即为实际执行的那份。
#   status = real-file | symlink-ok
#   ours   = True 当且仅当命中文件位于 self.target/bin/
# 另外把「存在但断链」的同类文件追加在末尾（它们不会被命中，但值得提示清理）。
# 公开（去掉 !）：测试要直接调，私有方法外部调不到。
# :@dirs 可注入（测试用）；生产路径不传 = 走真实 PATH。
# :$os 同样可注入，并透传给 pick-command-file / exec-suffixes —— 于是测试能在
# **任何宿主**上分别验「Windows 按 PATHEXT 解析」与「Unix 只看无扩展名」两套语义。
#
# 【为什么必须能注入平台】0.49.1 的用户现场：t/bin-path-order.t 原本没注入平台，
# 那几条断言写的是 Windows 语义（目录里放 .bat/.exe），于是**只在 Windows 上过**；
# Linux 上 `raku-pm install .` 跑 t/ 时它必红、把整次安装回滚。判定逻辑（唯一出处
# 在 Platform.pick-command-file）本来是对的，错的是测试把宿主当成了被验对象。
method detect-bin-on-path(Str $name, :@dirs?, Str :$os = '' --> List) {
    my @out;
    my &key = -> $p { $p.absolute.Str.subst('\\', '/', :g).lc };
    my $own-bin = key(self.target.add('bin'));
    my @path = @dirs.elems ?? @dirs.List !! path-dirs();

    for @path -> $dir {
        my $d = $dir.IO;
        my $hit = pick-command-file($d, $name, $os);
        if $hit.defined {
            my $status = 'real-file';
            if $hit.l {
                my $t = try { $hit.resolve.Str } // '';
                $status = (!$t.chars || !$t.IO.e) ?? 'broken-symlink' !! 'symlink-ok';
            }
            @out.push: %(
                path   => $hit.absolute.Str,
                status => $status,
                ours   => key($hit).starts-with($own-bin),
            );
            next;
        }
        # 该目录里没有「会被命中」的文件，但可能有断链的同类文件
        for exec-suffixes($os) -> $sfx {
            my $p = $d.add($name ~ $sfx);
            next unless $p.l;
            my $t = try { $p.resolve.Str } // '';
            next if $t.chars && $t.IO.e;
            @out.push: %(
                path   => $p.absolute.Str,
                status => 'broken-symlink',
                ours   => key($p).starts-with($own-bin),
            );
        }
    }
    @out
}
method list-available(--> Nil) {
    my @rows;
    my %seen;
    for self.repos -> $repo {
        # 仓库 id 对本地目录库是 `local:<绝对路径>`（很长）—— 按显示宽度省略头部
        my Str $rid = ui-ellipsis((try { $repo.id.Str }) // '?', 40);
        for $repo.all-distributions -> $name {
            # 跨仓库去重：同一个发行版出现在多个索引里只列一次（先命中者胜）
            next if %seen{$name.Str}++;
            @rows.push([ $name.Str, $rid ]);
        }
    }
    if @rows.elems == 0 {
        say "（仓库里没有可安装的发行版）";
        return;
    }
    say ui-bold("仓库中的发行版（共 {@rows.elems} 个）");
    say ui-table(['发行版', '仓库'], @rows);
}
# 在生态里按名字/描述搜索发行版（同名只显示最新版本）。
#
# 查询词也认安装规格串的写法（与 install 同一套解析，RakuPM::Spec）：
#   raku-pm search 'JSON::Fast:ver<1.0+>'   名字部分当关键词，版本当筛选
#   raku-pm search 'JSON::Fast@1.0'         @ 简写同款
#   raku-pm search 'Foo:auth<zef:x>'        再按作者过滤
# ver 不是合法约束（如 `foo@bar`）或没有名字部分时，整串当普通关键词，
# 行为与不带版本写法的旧版完全一致。
#
# 已安装的包（raku-pm 账本 + zef 侧仓库链）也纳入结果：
# search 的真实意图往往是「这东西在哪 / 我装没装」，而不只是「仓库里有没有」。
# RakuPM 自己就是典型——它不在任何索引里，但已装在 site/（self-upgrade 装的），
# 过去 search 永远扑空，用户会误以为要把它塞进某个仓库才搜得到。
method search(Str $q --> Nil) {
    my ($kw, $constraint, $auth) = self!split-query-spec($q);

    my @found;
    for self.repos -> $repo {
        next unless $repo.can('search-rows');
        @found.append($repo.search-rows($kw));
    }

    my %installed = self!installed-matching($kw);

    # 版本约束同样作用在「本地已装」侧：只留满足约束的版本，筛空了就不算命中。
    # （%installed 的值是版本串列表，没有 auth 信息，auth 筛选只作用于仓库行。）
    if $constraint.chars {
        for %installed.keys -> $n {
            my @ok = RakuPM::Version.new.sort-versions(%installed{$n})
                .grep({ RakuPM::Version.from-string($_).satisfies($constraint) });
            # 注意别写成 `?? !! %installed{$n}:delete` —— :delete 在值表达式
            # 位置会被解析成 adverb 直接编译错（"You can't adverb ??"）
            if @ok.elems { %installed{$n} = @ok } else { %installed{$n}:delete }
        }
    }

    # 同名只留一个 row：无约束时取全部里的最高版（旧行为）；
    # 带约束时在【满足约束】的版本里取最高 —— 最高版本不满足约束、
    # 低版本满足的包也能被搜出来（这正是带版本搜索的意义）。
    my %best;
    for @found -> %r {
        next if $constraint.chars
            && !RakuPM::Version.from-string(%r<version>).satisfies($constraint);
        next if $auth.chars && (%r<auth> // '') ne $auth;
        my $name = %r<name>;
        # 注意用 cmp 而不是 > ：RakuPM::Version 只实现了 cmp，
        # 用 > 会去找 Real/Numeric 而报 "Cannot resolve caller Real(...)"。
        unless %best{$name}:exists
            && RakuPM::Version.from-string(%best{$name}<version>).cmp(
                   RakuPM::Version.from-string(%r<version>)) != Less {
            %best{$name} = %r;
        }
    }
    # 只装了、仓库里没有的（RakuPM 自己、纯本地开发的包……）
    my @only-installed = %installed.keys.grep({ %best{$_}:!exists }).sort;

    if %best.elems == 0 && @only-installed.elems == 0 {
        say "未找到匹配 '$q' 的发行版（仓库与已装包里都没有）";
        return;
    }

    # 提示行把约束带出来，用户能看出版本筛选生效了
    my $filters = '';
    $filters ~= "，版本约束 {$constraint}" if $constraint.chars;
    $filters ~= "，auth {$auth}"           if $auth.chars;
    say "匹配到 {%best.elems + @only-installed.elems} 个发行版{$filters}：";
    # 按相关度排序：_score 越小越相关（0 精确名 / 1 前缀 / 2 子串 / 3 模块名命中），
    # 同分时按名字升序。同名已去重取最高版本，这里只决定展示顺序。
    for %best.values.sort(-> %r {
        (%r<_score> // 9) ~ "\x00" ~ %r<name>
    }) -> %r {
        # 注意：字符串里 `$tag{...}` 会被 Raku 当成对 $tag 的关联下标访问
        # （"Type Str does not support associative indexing"），
        # 所以这里必须用 `{$tag}` 显式插值块。
        my $tag = %r<repo> ?? "[{%r<repo>}] " !! '';
        # 仓库里有、且本地也装了 → 标注已装版本。装了很多个时只报最高 + 数量，
        # 否则一行能拖出十几屏（自装的 RakuPM 就是重灾区）。
        my @iv = @(%installed{%r<name>} // []);
        my $have = @iv.elems
            ?? "  （已装 " ~ (@iv.elems > 1
                                ?? "{@iv[*-1]} 等 {@iv.elems} 个版本"
                                !! @iv[0]) ~ "）"
            !! '';
        say "  · {$tag}{%r<name>} {%r<version>}  ({%r<auth> // '?'}){$have}";
        say "    {%r<description> // ''}" if %r<description>;
    }
    for @only-installed -> $n {
        my @iv = @(%installed{$n});
        my $vs = @iv.elems > 1 ?? "{@iv[*-1]} 等 {@iv.elems} 个版本" !! (@iv[0] // '');
        say "  · [已装] $n $vs";
    }
    say "\n（[方括号] 为发行版来自哪个仓库；同名只显示最高版本；";
    say "  [已装] = 本地已安装但不在任何仓库索引里）";
}

# 把查询词拆成 (关键词, 版本约束, auth)。
# 不是规格串（没拆出 ver/auth、或 ver 不是合法约束）时整串当关键词。
method !split-query-spec(Str $q --> List) {
    my %s = RakuPM::Spec.parse($q);
    my $kw = (%s<module> // '').trim;
    my $c  = (%s<ver>   // '').Str;
    my $a  = (%s<auth>  // '').Str;
    # ver 部分不是合法约束（如 `foo@bar` 里的 bar）→ 整串当关键词，
    # 别让坏约束把所有版本筛没，行为退回与旧版一致
    if $c.chars && !RakuPM::Spec.constraint-valid($c) {
        return ($q, '', '');
    }
    ($kw, $c, $a)
}
# 收集本地已安装、且匹配关键词的包：name => 版本列表。
# 数据源两路：raku-pm 账本（含 self-upgrade 装的 RakuPM 自己）+
# 仓库链上 zef 装的（跳过自己的 site/，那份已在账本里）。
# 匹配范围：发行版名 + provides（装了的包常只记得模块名）——用与仓库侧
# search-rows 同一个 match-score（模糊），这样「仓库里搜到的包」与
# 「本地已装的包」两边的命中口径一致，已装标记才不会错位。
method !installed-matching(Str $q --> Hash) {
    my %out;

    for self.installer.list-installed -> $e {
        my $n = $e<name> // '';
        next unless $n.chars;
        my @prov = @($e<provides> // []);
        next unless self.match-any($n, @prov, $q);
        # 外层括号必须加：slurpy 展开会让 sort-versions 收到多个独立参数而报错
        my @v = RakuPM::Version.new.sort-versions(
            (|@($e<versions> // []), ($e<version> // '')));
        %out{$n} = @v if @v.elems;
    }

    my $own = self.installer.repo-prefix.absolute;
    for $*REPO.repo-chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        next if (try $repo.prefix.absolute) eq $own;
        for $repo.installed -> $d {
            my $n = $d.meta<name> // '';
            next unless $n.chars;
            my %prov = $d.meta<provides> // %%;
            my @names = %prov ~~ Hash ?? %prov.keys !! @(%prov);
            next unless self.match-any($n, @names, $q);
            my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
            next unless $v.chars;
            %out{$n} = [] unless %out{$n}:exists;
            %out{$n}.push($v) unless $v (elem) @(%out{$n});
        }
    }
    %out
}
# 展示锁文件内容
method show-lock(--> Nil) {
    print self.lock.describe;
}

# ============ P6：世代（原子安装留下的可回滚快照） ============

# 列出所有世代。每个世代是「那次成功安装之后 installed.json 的样子」，
# 因此回滚 = 让 target 与某个世代的清单一致。
method list-generations(--> Nil) {
    my @gens = self.installer.list-generations;
    unless @gens.elems {
        say "还没有任何世代（成功安装一次后就会出现）";
        return;
    }
    say "共 {@gens.elems} 个世代（当前：{self.installer.current-generation || '—'}）：";
    say "";
    for @gens.reverse -> %g {
        my $mark = %g<current> ?? '*' !! ' ';
        my @ins  = @(%g<installed> // []);
        say "  {$mark} 世代 {%g<id>}  {%g<created-at>}";
        if @ins.elems {
            say "      本次装入：{@ins.join('、')}";
        }
        else {
            say "      本次装入：（无记录）";
        }
    }
    say "";
    say "  退回上一世代：raku-pm rollback";
    say "  退回指定世代：raku-pm rollback <世代号>";
}

# 校验。两段：
#   ① 内容完整性 —— store 里的源码有没有被改动（覆盖 versions[] 全部版本，
#      原来只查激活版本，历史版本是盲区）
#   ② 安装一致性 —— 账本 / CUR / store / resources 四者对不对得上。
#      只做 ① 是不够的：GDBM 那次 CUR 已经半残（site/dist/<id> 丢了），
#      而 store 副本完好无损 —— ① 会报「全部正常」，等于虚假安全感。
# :$content-only 只看 ①（旧行为）；:$fix 顺便修能修的（补记账本）。
method verify-all(Bool :$content-only = False, Bool :$fix = False --> Nil) {
    say "内容完整性（store 源码有没有被改动）：";
    my ($bad, $checked) = 0, 0;
    for self.installer.list-installed -> $r {
        my $name = $r<name> // next;
        my @vs = (|@($r<versions> // []), ($r<version> // ''))
                    .grep({ .defined && .chars }).unique;
        for @vs -> $v {
            next unless self.store.has($name, $v);
            $checked++;
            unless self.store.verify($name, $v) {
                $bad++;
                say "  ✗ {$name} {$v}: 已被修改";
            }
        }
    }
    say $bad == 0
        ?? "  ✓ {$checked} 个 store 副本完好"
        !! "  ✗ {$bad} / {$checked} 个副本校验失败";

    return if $content-only;

    say "";
    say "安装一致性（账本 / CUR / store / resources 是否对得上）：";
    my @issues = self.installer.consistency-issues;
    unless @issues.elems {
        say "  ✓ 没有不一致";
        return;
    }
    for @issues -> %i {
        say "  ✗ {%i<name>} {%i<version>}：{%i<detail>}";
    }
    say "  共 {@issues.elems} 处不一致";

    if $fix {
        my $n = self.installer.adopt-from-cur;
        say "  --fix：补记了 {$n} 条账本条目";
        my @left = self.installer.consistency-issues;
        if @left.elems {
            say "  还剩 {@left.elems} 处无法自动修复，需重装对应包：";
            for @left.map({ .<name> }).unique -> $nm {
                say "      raku-pm install {$nm} --force";
            }
        }
        else {
            say "  ✓ 已全部修复";
        }
    }
    else {
        my $fixable = @issues.grep({ .<fixable> }).elems;
        msg-hint "  --fix 可自动修复 {$fixable} 处（补记账本）；"
           ~ "其余需重装对应包（raku-pm install <包> --force）" if $fixable;
    }
}

# `raku-pm doctor` —— 一次性体检：把「装了却 use 不到 / 敲到旧版」这类隐晦排障
# 收敛成一条命令。只读、不改任何东西，纯检查 + 给修复建议。教学价值高：
# 它把 RAKULIB / PATH 顺序 / 残留 mock / 账本-CUR 一致性 / rakudo 版本这些散落
# 的知识点显式串成一份清单。
method doctor(--> Nil) {
    my $spec     = self.installer.raku-lib-spec;   # 期望的 inst#<target>/site
    my $bin-path = self.target.add('bin').absolute;
    my @issues;                                    # 收集问题，最后给总评

    # ---- 1. RAKULIB 是否指向我们的 site ----
    say "〔1/7〕RAKULIB（让 raku 找得到已装包）";
    my $rakulib = %*ENV<RAKULIB> // '';
    if !$rakulib.chars {
        say "  ✗ 未设置 RAKULIB —— 已装的包 raku 一个都找不到";
        say "      修复：raku-pm env  然后按提示设置（或 eval \"\$(raku-pm shell)\"）";
        @issues.push('RAKULIB 未设置');
    }
    elsif $rakulib !~~ / $spec / {
        say "  ⚠ RAKULIB 已设，但不含本前缀的 site：{$rakulib}";
        say "      期望包含：$spec";
        say "      修复：raku-pm env  重新设置";
        @issues.push('RAKULIB 未指向本前缀');
    }
    else {
        say "  ✓ RAKULIB 已正确指向本前缀 site";
    }

    # ---- 2. PATH 顺序（<target>/bin 是否排在 rakudo site/bin 之前）----
    say "";
    say "〔2/7〕PATH（敲 raku-pm 实际跑哪一份）";
    my @cands = self.detect-bin-on-path('raku-pm');
    if !@cands.elems {
        say "  ⚠ PATH 里没有 raku-pm —— 敲 `raku-pm` 会找不到命令";
        say "      修复：把 $bin-path 加到 PATH 最前（raku-pm env）";
        @issues.push('PATH 缺 raku-pm');
    }
    else {
        my $first = @cands[0];
        if $first<ours> {
            say "  ✓ 实际执行的是本前缀的 raku-pm（{$first<path>}）";
        }
        else {
            say "  ⚠ 实际执行的是【别的】副本（被它遮蔽）：{$first<path>}";
            say "      本前缀的 wrapper 在：$bin-path（需把它放到 PATH 最前）";
            @issues.push('raku-pm 被别的副本遮蔽');
        }
        # 断链 / 不存在的旧 wrapper
        for @cands.grep({ !.<ours> && .<status> ~~ any('broken-symlink','missing') }) -> %c {
            say "  ⚠ 有断链 / 不存在的旧 wrapper：{%c<path>}（建议手动删除）";
            @issues.push('存在断链的旧 wrapper');
        }
    }

    # ---- 3. 残留 mock（target/stage 是否非空）----
    say "";
    say "〔3/7〕残留暂存（中断的安装遗留）";
    my $stage = self.target.add('stage');
    my $stage-kids = ($stage.e ?? try { $stage.dir.elems } !! 0) // 0;
    if $stage-kids > 0 {
        say "  ⚠ target/stage 存在且非空（{$stage-kids} 个条目）—— 多半是上次安装中断遗留";
        say "      正常安装结束后它会自动清空；残留说明某次安装没干净收尾。";
        say "      修复：raku-pm clean  或手动删除 {$stage.absolute}";
        @issues.push('target/stage 残留');
    }
    else {
        say "  ✓ 没有残留暂存（target/stage 不存在或为空）";
    }

    # ---- 4. 账本 ↔ CUR 一致性 ----
    say "";
    say "〔4/7〕账本 ↔ CUR 一致性";
    my @consistency = self.installer.consistency-issues;
    if !@consistency.elems {
        say "  ✓ 账本与 site 里的 CUR 完全一致";
    }
    else {
        my $f = @consistency.grep({ .<fixable> }).elems;
        say "  ✗ 发现 {@consistency.elems} 处不一致（其中 {$f} 处 --fix 可自动修）";
        for @consistency.head(5) -> %i {
            say "      · {%i<name>} {%i<version>}：{%i<detail>}";
        }
        say "      修复：raku-pm verify --fix   （其余需 raku-pm install <包> --force）";
        @issues.push('账本/CUR 不一致');
    }

    # ---- 5. rakudo / 编译器版本 ----
    say "";
    say "〔5/7〕运行环境";
    say "  · rakudo：{$*RAKU.version}";
    say "  · 编译器：{$*RAKU.compiler.version}（{$*RAKU.compiler.name}）";
    say "  · 虚拟机：{$*VM.name} {$*VM.version}";
    say "  · 平台：{kernel-name()} / {distro-name()}";
    say "  · 离线模式：{ offline() ?? '已开启（--offline / RAKUPM_OFFLINE）' !! '未开启' }";

    # ---- 6. 锁文件 / 可复现性 ----
    say "";
    say "〔6/7〕锁文件 / 可复现性";
    my $lp = self.lock.path;
    if self.lock.exists {
        my %le = self.lock.entries;
        say "  ✓ 锁文件存在：{$lp.absolute}（{%le.elems} 个条目）";
        say "      记录「当前项目依赖闭包」的精确版本，随项目提交可换机复现";
    }
    else {
        say "  · 锁文件不存在：{$lp.absolute}";
        say "      锁默认写在【当前目录】raku-pm.lock（项目级、可 git add 提交）";
        say "      install 会自动生成；要钉死版本可复现请用 install --locked";
    }
    say "  · 锁在【当前目录】，包装在 <target>={self.target.absolute} —— 两者有意分离";
    say "    （锁是项目级的，包是全局前缀共享的；upgrade 不读锁、会取最新版）";

    # ---- 7. 作者侧凭据状态 ----
    say "";
    say "〔7/7〕作者侧凭据（publish --remote / check --remote 需要）";
    my $cred = self.target.add('credentials.json');
    if $cred.e {
        say "  ✓ 已登录（凭据文件：{$cred.absolute}）";
    }
    else {
        say "  · 未登录（无 {$cred.absolute}）";
        say "      publish --remote / check --remote 需先 `raku-pm login --api-key=<key>`";
        say "      仅做本地发布（publish 不带 --remote）不受影响";
    }

    # ---- 总评 ----
    say "";
    if @issues.elems {
        say "总评：发现 {@issues.elems} 项需关注 —— { @issues.join('、') }";
        say "（以上均为本地检查，未做任何修改；逐项按提示修复即可）";
    }
    else {
        say "总评：✓ 一切正常，环境健康。";
    }
}


# 正向依赖树（`raku-pm depends`）—— 与 rdepends 互补：那边回答「谁依赖了我」。
#
# 【为什么不能直接复用 resolve-deps-of】安装链里那个刻意**跳过已被满足的依赖**
# （zef 的「只装缺失的」语义），所以它返回的列表不能当「这个包的依赖」看。
# 这里要的是**完整**依赖图：每个依赖都列出来，并标注「已装 / 待装 / 找不到」。
#
# 【已装的不往下展开】它的依赖由它自己那份元数据负责，展开会让输出爆炸
# （真实生态里一个装过的包往往牵连出几十个节点）。想追就单独 `depends <它>`，
# 输出更短也更好读 —— 这比给一个几百行的树有用。
#
# 【环】生态里真实存在互相依赖的发行版（NativeLibs ↔ NativeHelpers::Blob），
# 所以必须有 %seen 守卫，否则递归不终止。第二次遇到同一个发行版时**明确标注**
# 并停下，不静默跳过 —— 静默跳过会让人以为依赖树就只有这么多。
method show-depends(Str $spec = '', Str :$constraint = '' --> Nil) {
    unless $spec.chars {
        note "请指定要查的包（或模块）名，例如：raku-pm depends GDBM";
        return;
    }

    # 定位根发行版。查不到就说清「只查仓库」这个边界：本地已装的包（比如
    # RakuPM 自己）不在任何索引里，不说清的话用户很容易以为命令坏了。
    my %root;
    my $ok = try { %root = self!resolve-dist-for-spec($spec, $constraint); True };
    unless $ok.defined && %root<dist>.defined {
        note "在已配置的仓库里找不到「{$spec}」（depends 只查仓库里的发行版）。";
        note "  如果它是你本地装的包：`raku-pm installed` 看它在不在，"
           ~ "`raku-pm rdepends {$spec}` 反查谁依赖它。";
        return;
    }
    my $dist = %root<dist>;

    say ui-bold("{$dist.identity()} 的依赖：");

    my %seen = ($dist.name => True);   # 根也记进去：依赖若有环能绕回来
    my @need;                          # 本次需要安装的发行版（深度优先序）
    self!walk-deps($dist, '', %seen, @need);

    # 外部命令依赖（META6 的 :from<bin>）：不是 Raku 包、装不了，但缺了包也
    # 用不起来。顺手报出来，省得用户去翻 META6.json。
    my @ext = self.check-external-deps((|@need, $dist));
    if @ext.elems {
        my @miss = @ext.grep({ !self!has-command($_) });
        say "";
        if @miss.elems {
            msg-warn "⚠ 另有 {@miss.elems} 个外部命令依赖不在 PATH 中：{@miss.join(', ')}";
            msg-hint "  raku-pm 不装系统命令，用系统包管理器装（apt / brew / choco …）";
        }
        else {
            say "外部命令依赖：{@ext.join(', ')}（都在 PATH 中）";
        }
    }

    say "";
    if @need.elems {
        say ui-bold("共 {@need.elems} 个发行版需要安装：");
        for @need -> $d { say "  " ~ ui-green('·') ~ " {$d.name} {$d.version}" }
        say "";
        say "装：raku-pm install {$spec}";
    }
    else {
        say "依赖都已满足，不需要装任何东西。";
    }
}

# 递归打印依赖树（show-depends 的实现细节）。
# %seen 是「已展开过的发行版名」集合，@need 累积「本次需要安装」的那些。
# 两个容器都是**按引用**往下传的（Hash / Array 参数传的是容器本身，不是副本），
# 所以递归里 push 的东西调用方能直接读到。
method !walk-deps(RakuPM::Distribution $dist, Str $indent, %seen, @need --> Nil) {
    # 自己提供的模块不算外部依赖（有些包的 META6 会把自己也写进 depends）
    #
    # 【必须是 .pairs 而不是 .kv】Hash.kv 返回的是**扁平列表** (键, 值, 键, 值…)
    # 而不是 Pair 列表，于是 grep 的块拿到的是字符串，`.key` 会报
    # "No such method 'key' for string 'FxFoo'"（实测踩到）。
    # 下面 `for @deps.kv -> $i, $pair` 里的 .kv 反而是对的 —— 那个 .kv 作用在
    # **List** 上，给的是 (下标, 元素)。
    my @deps = $dist.depends.pairs.grep({ !$dist.provides-module(.key) }).list;
    return unless @deps.elems;

    for @deps.kv -> $i, $pair {
        my $mod  = $pair.key.Str;
        # 约束值可能是非 Str（META6 里写成 null 之类）→ 一律 .Str，否则后面
        # 传给 !dep-satisfied / 拼进字符串时会类型检查失败。
        my $cons = $pair.value.Str;
        my $last = $i == @deps.elems - 1;
        # 树形连接符走 UI：rich=Unicode 制表符（├─ / └─ / │），非 rich=ASCII（|- / `- / |）
        # —— 与表格同一套降级口径，管道/日志里不会出现制表符。
        my $branch = ui-tree-branch($last);
        my $child  = $indent ~ ui-tree-child($last);
        my $cv     = ($cons.chars && $cons ne '*') ?? " {$cons}" !! '';

        # 已装（raku-pm 装的或 zef 装的都算）→ 叶子，不再往下展开
        if self!dep-satisfied($mod, $cons) {
            say "{$indent}{$branch}{ui-green($mod)}{$cv}  {ui-dim('（已装）')}";
            next;
        }

        # 用 `try { …; True }` 认「解析失败」：Raku 的 try 失败返回的是 Nil，
        # 直接 `my %h = try { … }` 在失败时会拿 Nil 赋给 Hash 而炸（踩过多次）。
        my %got;
        my $found = try { %got = self!resolve-dist-for-spec($mod, $cons); True };
        unless $found.defined && %got<dist>.defined {
            note "{$indent}{$branch}{ui-red($mod)}{$cv}  "
               ~ ui-red('★ 找不到') ~ "（所有仓库里都没有提供它的发行版）";
            note "{$child}   " ~ ui-dim(
                '看看挂了哪些索引：raku-pm repos list；收录更全的生态存档：raku-pm repos add rea');
            next;
        }

        my $d     = %got<dist>;
        my $label = "{$d.name} {$d.version}";
        if %seen{$d.name} {
            say "{$indent}{$branch}{ui-dim($label)}{$cv}  {ui-dim('★（已在上方展开）')}";
            next;
        }
        %seen{$d.name} = True;
        @need.push($d);
        say "{$indent}{$branch}{ui-yellow($label)}{$cv}  {ui-yellow('★')}";
        self!walk-deps($d, $child, %seen, @need);
    }
}

# 反查谁依赖了我（既接受发行版名，也接受它提供的模块名）。
method show-rdepends(Str $spec = '' --> Nil) {
    unless $spec.chars {
        note "请指定要反查的包（或模块）名，例如：raku-pm rdepends GDBM";
        return;
    }
    my @installed = self.installer.list-installed;
    my $dist = @installed.first({ (.<name> // '') eq $spec })
            // @installed.first({ $spec (elem) @(.<provides> // []) });
    unless $dist.defined {
        note "没有已安装的包叫「{$spec}」（也不是任何已装包提供的模块）";
        return;
    }
    my $name = $dist<name>;
    my $v    = self.installer.installed-version($name);
    if self.installer.reverse-dependencies($name).elems == 0 {
        say "没有已安装的包依赖 {$name} {$v}（它在依赖图里是顶端）";
        return;
    }
    # 反向依赖【树】：从目标包往上长（谁依赖我 → 谁又依赖它们 …）。每层标出
    # 「经由哪个模块 + 什么约束」；%seen 防环（已装图里 A↔B 是可能的）。
    say ui-bold("{$name} {$v}") ~ ui-dim(' 的反向依赖树（谁（直接或间接）依赖了它）：');
    my %seen = ($name => True);
    my Int $n = self!walk-rdeps($name, '', %seen);
    say "";
    say ui-dim("共 {$n} 个已装包依赖它。");
}

# 反向依赖树的递归打印（show-rdepends 的实现细节），返回本次打印的节点数。
# 与正向 !walk-deps 对称：连接符走 UI（rich=Unicode / 非 rich=ASCII），带 %seen 防环。
method !walk-rdeps(Str $name, Str $indent, %seen --> Int) {
    my @rd = self.installer.reverse-dependencies($name);
    return 0 unless @rd.elems;
    my Int $n = 0;
    for @rd.kv -> $i, %r {
        my $last = $i == @rd.elems - 1;
        my $branch = ui-tree-branch($last);
        my $child  = $indent ~ ui-tree-child($last);
        my Str $nm   = (%r<name>       // '').Str;
        my Str $nv   = (%r<version>    // '').Str;
        my Str $mod  = (%r<module>     // '').Str;
        my Str $cons = (%r<constraint> // '*').Str;
        my Str $label = "{$nm} {$nv}";
        # 「经由哪个模块依赖」：模块名青色，非 * 的约束用暗色附在后面。
        my Str $via = $mod.chars
            ?? ('  ' ~ ui-dim('经 ') ~ ui-cyan($mod)
                ~ ($cons ne '*' ?? ui-dim(" {$cons}") !! ''))
            !! '';
        $n++;
        if %seen{$nm} {
            say "{$indent}{$branch}{ui-dim($label)}{$via}  {ui-dim('（已在上方展开）')}";
            next;
        }
        %seen{$nm} = True;
        say "{$indent}{$branch}{ui-magenta($label)}{$via}";
        $n += self!walk-rdeps($nm, $child, %seen);
    }
    $n;
}

# ============ `why` 依赖解析诊断（让解析过程可解释，不再是黑盒）============
#
# 给定一个或多个根规格（可以是包名 / 模块名 / 带约束的规格串，如 'Foo:ver<1.0>'），
# 跑一遍解析，把「每个模块最终解析到哪个版本、从哪个仓库来、为什么淘汰了别的候选、
# 谁因为什么要求它」讲清楚。多模块一起给还能暴露依赖冲突的【双方约束】。
# :%pins 透传 --pin（钉版会覆盖任何来路的约束，与 install 同语义）。
method show-why(@specs is copy, :%pins --> Nil) {
    unless @specs.elems {
        note "请指定要诊断的模块（或包）名，例如：raku-pm why JSON::Fast";
        return;
    }
    my @r-specs = @specs.map(-> $s {
        my %p = RakuPM::Spec.parse($s.Str);
        %( module => %p<module>, constraint => (%p<ver> // '').Str,
           auth   => (%p<auth> // '').Str )
    });
    my $resolver = RakuPM::Resolver.new(:repos(self.repos));
    my %diag = $resolver.explain-all(@r-specs, :%pins);

    # 冲突路径：把「双方约束」友好地讲出来（不靠 die 打断用户）
    if %diag<conflict> && %diag<conflict><module>.defined {
        my $m = %diag<conflict><module>;
        self!format-conflict(%diag<conflict>, %diag<modules>{$m});
    }
    # 非冲突的解析失败（如找不到模块）：直接把 fatal 路径的原始报错转述出来
    elsif !%diag<ok> {
        note %diag<error> // "依赖解析失败（原因不明）";
        return;
    }

    # 逐个模块打印诊断细节（冲突模块已在上面单独展开，这里跳过避免重复）
    my $conflict-mod = %diag<conflict><module> // '';
    for %diag<modules>.keys.sort -> $m {
        next if $m eq $conflict-mod;
        self!format-why-module($m, %diag<modules>{$m});
    }

    say "";
    say "（用 raku-pm depends <模块> 看完整依赖树；冲突时可用 --pin 钉住一边版本）";
}

# 单个模块的诊断详情（候选 + 请求链）。不含「=> 解析 …」大标题，便于冲突路径复用。
method !format-why-detail(Str $m, %mod --> Nil) {
    my %ch  = %mod<chosen>;
    my @cands = %mod<candidates>.list;
    if @cands.elems {
        say "  候选版本（共 {@cands.elems} 个，* = 选中）：";
        for @cands -> %c {
            my $mark = (%ch<version> // '') eq %c<version> ?? ' *' !! '  ';
            my $repo = %c<repo> || '?';
            say "    {$mark} {%c<version>}   {%c<name>} @ {$repo}";
            say "         └ {%c<reason>}";
        }
    }
    else {
        say "  没有可用的候选版本（仓库里没有能提供的发行版）";
    }

    my @w = %mod<wanted>.list;
    if @w.elems {
        say "  谁要求了它：";
        for @w -> %r {
            my $req = %r<requester> || '<top-level>';
            my $ver = %r<version>.chars ?? " {%r<version>}" !! ' *';
            say "    {$req} → {$m}{$ver}";
        }
    }
}

# 单个模块的诊断（带大标题）。用于「正常解析」路径。
method !format-why-module(Str $m, %mod --> Nil) {
    my %ch = %mod<chosen>;
    say "";
    if %ch && %ch<name>.defined && %ch<name>.chars {
        say "=> 解析 {$m}：选中 {%ch<name>}:{%ch<version>}（来自仓库 {%ch<repo> || '?'}）";
    }
    else {
        # 选不到：可能是 Raku 核心模块 / 编译器本身（解析器直接跳过，不进闭包），
        # 也可能是所有候选都不满足约束。两者都不进依赖闭包，给个提示避免用户困惑。
        say "=> 解析 {$m}：未选定版本（不进入依赖闭包）";
        if %mod<candidates>.elems == 0 && %mod<wanted>.elems {
            say "   该模块是 Raku 核心模块或编译器本身，raku-pm 不解析也不安装它";
        }
    }
    if %mod<constraint>.chars && %mod<constraint> ne '*' {
        say "  有效约束：{%mod<constraint>}";
    }
    self!format-why-detail($m, %mod);
}

# 冲突路径的诊断：先讲「双方约束」，再展开冲突模块的候选细节（帮助决定 pin 哪边）。
method !format-conflict(%c, %mod --> Nil) {
    my $m   = %c<module>;
    my %ex  = %c<existing>;
    say "依赖冲突：模块 '$m' 同时被这些发行版要求不同版本 —— 无法同时满足";
    say "  最后选定的版本是 {%ex<version>}（由 {%ex<name>} 提供）";
    say "  冲突的版本要求：";
    for %c<requesters>.list -> %r {
        my $req = %r<requester> || '<top-level>';
        say "    {$req} → {$m} {%r<version>}";
    }
    say "";
    say "=> 模块 {$m} 的候选版本（决定 pin 哪一边时看这里）：";
    self!format-why-detail($m, %mod);
}
# 查某个模块的已装版本与激活版本（raku-pm version <模块名>）。
# :$constraint 版本约束（CLI 由规格串解析填入：`raku-pm version 'Foo:ver<1.0>'`）。
#   只显示满足约束的版本；激活标记仍按全局激活版本算 —— `use` 实际加载的
#   那份不受查询约束影响，若激活版本不满足约束它自然不会带星号。
# 数据源两处：raku-pm 自己的账本（target/site），以及进程仓库链上的
# Installation 仓库（zef 装的 site/home/vendor）。激活 = `use <模块>` 时
# 实际加载的那份：raku-pm site 在 RAKULIB 上排最前，有就取其中最高版本；
# 否则取仓库链上第一个命中的版本。
method module-version(Str $name, Str :$constraint = '' --> Nil) {
    my @own = self.installer.installed-versions($name);
    @own = @own.grep({ RakuPM::Version.from-string($_).satisfies($constraint) })
        if $constraint.chars;

    my @chain;
    for $*REPO.repo-chain -> $repo {
        next unless $repo.defined && $repo ~~ CompUnit::Repository::Installation;
        for $repo.installed -> $d {
            next unless ($d.meta<name> // '') eq $name;
            my $v = ($d.meta<version> // $d.meta<ver> // '').Str;
            next unless $v.chars;
            # 版本约束（`version 'Foo:ver<1.0>'`）同样作用于 zef 侧；
            # 注意要先筛约束再去重 —— @own 可能已被约束筛掉一部分
            next if $constraint.chars
                && !RakuPM::Version.from-string($v).satisfies($constraint);
            # raku-pm site 里已列过的版本不再重复（RAKULIB 设了时自己的 site 也在链上）
            next if $v (elem) @own;
            my $prefix = try { $repo.prefix.absolute } // '';
            @chain.push(%( version => $v, source => $prefix ));
        }
    }

    unless @own.elems || @chain.elems {
        if $constraint.chars {
            say "{$name}:ver<{$constraint}> 没有已安装的版本满足约束。";
            say "试试：raku-pm version {$name}   ← 不带约束看它已装的全部版本";
        }
        else {
            say "{$name} 未安装（raku-pm 与 zef 的仓库里都没找到）。";
            say "试试：raku-pm install {$name}";
        }
        return;
    }

    say "{$name} 的已安装版本：";
    my $active = @own.elems ?? self.installer.installed-version($name) !! @chain[0]<version>;
    for @own -> $v {
        my $mark = ($v eq $active) ?? '   ← 激活（raku-pm site）' !! '';
        say "  {$v}{$mark}";
    }
    for @chain -> $r {
        my $mark = (!@own.elems && $r<version> eq $active)
            ?? '   ← 激活（仓库链第一个命中）' !! '';
        say "  {$r<version>}   （{$r<source>}）{$mark}";
    }
    say "";
    say "激活 = 不指定版本时 `use {$name}` 实际加载的那份；";
    say "多版本精确选：`use {$name}:ver<x.y.z>`（RAKULIB：{self.installer.raku-lib-spec}）。";
}

# ============ P7：info / browse / locate（发行版元信息查询） ============

# 在已装账本里找一个发行版条目（按发行版名或它提供的模块名匹配）。
# 仓库里查不到的本地包（如 raku-pm 自己）退回这里，info/browse 才能看到它。
method !installed-entry-for(Str $spec --> Hash) {
    for self.installer.list-installed -> %e {
        return %e if (%e<name> // '') eq $spec;
        return %e if $spec (elem) @(%e<provides> // []);
    }
    return %();
}

# 跨仓库取某个发行版名对应的「生态索引原始行」—— 含 source-url / support /
# license 这些 Distribution 模型不收的字段（info / browse 要用）。
# 不传版本取最高版本；传了版本优先精确匹配。仓库里没有就返回空 Hash。
method !raw-row-for(Str $name, Str $version = '' --> Hash) {
    # 优先用仓库的「完整行」访问器 raw-row（含 source-url / license / support 这些
    # search-rows 为精简显示而丢弃的字段）；取第一个能提供该发行版的仓库的行即可。
    for self.repos -> $repo {
        next unless $repo.can('raw-row');
        my %r = $repo.raw-row($name, $version);
        return %r if %r && %r<name>.defined;
    }
    # 兜底：老仓库类型没有 raw-row，退回 search-rows 的精简行（拿不到 license/support，
    # 但至少 identity 类字段有）。
    for self.repos -> $repo {
        next unless $repo.can('search-rows');
        for $repo.search-rows($name) -> %r {
            next unless %r<name> eq $name;
            return %r if $version.chars ?? (%r<version> // '').Str eq $version.Str
                           !! True;
        }
    }
    return %();
}

method !fmt-list(@items, Str $label --> Nil) {
    return unless @items.elems;
    # 分区标题加粗 + 带条目数；列表项保留 ·（中文环境下字体本就支持）
    say ui-bold("{$label}（{@items.elems}）：");
    for @items.sort -> $x { say "  · $x" }
}

# 显示发行版详情（仿 zef info）。
# 优先从仓库解析（能拿到 description / depends / source-url 全套）；仓库里没有的
# 本地包（如 raku-pm 自己）退回到已装账本，至少给出名字/版本/提供的模块。
method show-info(Str $spec = '', Str :$constraint = '' --> Nil) {
    unless $spec.chars {
        note "请指定要查的包（或模块）名，例如：raku-pm info JSON::Fast";
        return;
    }
    my $dist;
    my %root;
    my $ok = try { %root = self!resolve-dist-for-spec($spec, $constraint); True };
    if $ok.defined && %root<dist>.defined {
        $dist = %root<dist>;
    }
    else {
        my %e = self!installed-entry-for($spec);
        unless %e<name>.defined {
            note "在已配置的仓库与已装包里都找不到「{$spec}」。";
            note "  若它是本地目录里的包：raku-pm fetch {$spec} 先看能不能取到源码。";
            return;
        }
        $dist = RakuPM::Distribution.new(
            :name(%e<name>), :version(%e<version> // '0.0.0'),
            :auth(%e<auth> // 'unknown'),
            :provides(@(%e<provides> // [])),
            :depends({}));
    }

    say ui-bold("{$dist.identity}");

    # 发行版元信息收进键值表：比一列 `键：值` 更整齐，中文键也对齐
    my @kv;
    @kv.push([ '描述', $dist.description.Str ]) if $dist.description.chars;
    @kv.push([ '作者', $dist.auth.Str ]);
    # source-url / license / support 来自生态索引原始行（离线时可能取不到）
    my %row = self!raw-row-for($dist.name, $dist.version);
    @kv.push([ '源码地址', %row<source-url>.Str ])
        if %row<source-url>.defined && %row<source-url>.chars;
    @kv.push([ '许可证', %row<license>.Str ])
        if %row<license>.defined && %row<license>.chars;
    @kv.push([ '项目主页', %row<support><source>.Str ])
        if %row<support> ~~ Hash && (%row<support><source> // '').chars;
    say ui-kv-table(@kv);

    self!fmt-list($dist.provides.sort,         '提供模块');
    self!fmt-list($dist.depends.keys.sort,      '运行时依赖');
    self!fmt-list($dist.build-depends.keys.sort, '构建依赖');
    self!fmt-list($dist.test-depends.keys.sort,  '测试依赖');
    self!fmt-list($dist.native-libs,           '本地库依赖');
    self!fmt-list($dist.external-deps,         '外部命令依赖');
    self!fmt-list($dist.git-deps,             'git 依赖');
    self!fmt-list($dist.resources,            '资源文件');

    say "";
    say "（要看源码目录：raku-pm look {$dist.name}；要开浏览器：raku-pm browse {$dist.name}）";
}

# 在默认浏览器打开发行版主页 / 源码地址（仿 zef browse）。
# 地址优先级：META6 的 support.source > 索引行的 source-url；都没有就明说
# 无法打开（而不是静默什么都不做）。
method browse(Str $spec = '', Str :$constraint = '' --> Nil) {
    unless $spec.chars {
        note "请指定要打开主页的包名，例如：raku-pm browse JSON::Fast";
        return;
    }
    my $dist;
    my $ok = try {
        my %root = self!resolve-dist-for-spec($spec, $constraint);
        $dist = %root<dist>;
        True;
    };
    unless $ok.defined && $dist.defined {
        my %e = self!installed-entry-for($spec);
        unless %e<name>.defined {
            note "在仓库与已装包里都找不到「{$spec}」—— 无法浏览。";
            return;
        }
        $dist = RakuPM::Distribution.new(:name(%e<name>), :version(%e<version> // '0.0.0'));
    }
    my %row = self!raw-row-for($dist.name, $dist.version);
    my $url = (%row<support> ~~ Hash ?? (%row<support><source> // '') !! '')
            || (%row<source-url> // '');
    unless $url.chars {
        msg-hint "「{$dist.name}」没有记录主页 / 源码地址（META6 缺 source-url / "
           ~ "support.source），无法打开浏览器。";
        return;
    }
    say "==> 在默认浏览器打开：{$url}";
    unless open-url($url) {
        msg-warn "⚠  打开浏览器失败（可能系统没有默认浏览器，或命令不可用）。";
    }
}

# 定位一个【模块】在磁盘上的真实位置（仿 zef locate）。
# 走仓库链解析（与 show-which 同一套），打印实际加载的那份 .rakumod/.pm6 文件路径；
# 多份共存时只报链上靠前的（被遮蔽的也列出来，避免「我装的到底用哪份」的困惑）。
method locate(Str $module = '' --> Nil) {
    unless $module.chars {
        note "请指定要定位的【模块名】，例如：raku-pm locate JSON::Fast";
        return;
    }
    my @inst = self.repo-chain-installations;
    unless @inst.elems {
        note "仓库链上没有 Installation 仓库（RAKULIB = " ~ (%*ENV<RAKULIB> // '(未设)') ~ "）";
        return;
    }
    my @hits;
    for @inst.kv -> $i, $r {
        my $cu = try { $r.resolve(CompUnit::DependencySpecification.new(:short-name($module))) };
        next unless $cu.defined;
        my $meta = (try { $cu.distribution.meta }) // %();
        my $name = ($meta<name> // '?').Str;
        my $ver  = ($meta<version> // $meta<ver> // '?').Str;
        my $prefix = try { $r.prefix.absolute } // '';
        @hits.push: %(:idx($i), :repo($r.Str), :dist($name), :ver($ver), :prefix($prefix));
    }
    unless @hits.elems {
        note "✗ 仓库链上没有任何仓库提供模块 `{$module}`。";
        note "  注意这里要写【模块名】（如 JSON::Fast），不是发行版名；也可能它没装。";
        return;
    }
    say "模块 `{$module}` 实际加载：";
    my %top = @hits[0];
    my $rel = 'lib/' ~ $module.subst('::', '/', :g);
    my $file = '';
    # 扩展名口径统一走 Distribution（0.87.1 收敛成唯一一份）：.rakumod / .pm6 / .pm。
    # 这里漏了 .pm 的话，`raku-pm which` 会对一个确实装好的模块报一个空的「文件：」
    # —— 与 store 侧的识别口径必须一致，别再内联字面量。
    for RakuPM::Distribution.module-extensions -> $ext {
        my $cand = (%top<prefix> // '').IO.add($rel ~ $ext);
        if $cand.e { $file = $cand.absolute; last }
    }
    say "  ✓ {%top<dist>} {%top<ver>}";
    say "    文件：{$file}" if $file.chars;
    say "    仓库：[{%top<idx>}] {%top<repo>}";
    if @hits.elems > 1 {
        say "";
        say "⚠  另有 {@hits.elems - 1} 份存在但被遮蔽（链上靠前的赢）：";
        for @hits.skip(1) -> %h {
            say "      [{%h<idx>}] {%h<dist>} {%h<ver>}  {%h<repo>}  ← 被上面的遮蔽";
        }
    }
}
