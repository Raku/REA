# RakuPM::Client::Flusher — `raku-pm flush`：把当前前缀整个清空，回到「可以重新安装」
#
# 【为什么要有它】`clean` 是**有保护**的回收（只动没被引用的版本，且默认留索引/克隆
# 缓存）；`self-remove` 只卸 raku-pm 自己。想要「从零重来」时两者都不顺手：
# 得先 self-remove、再 clean --all --yes、再手动收拾。flush 就是那一步到位 ——
# 清掉前缀里 raku-pm 装过的一切（含它自己的入口），让下一次安装是干净的。
#
# 【与 clean 刻意分开，不合并】两者意图相反：clean 的每条规则都是「什么不能删」，
# flush 则是「全删」。合成一个命令迟早会有人把 flush 当成 clean 的加强版敲出去。
#
# 【默认只试算】删文件不可撤销 —— 与 clean 同一约定：`raku-pm flush` 只列出计划，
# `--yes` 才真删。
#
# 【护栏：必须拦】`RAKUPM_TARGET` 打错一个字符就指向别处，而这个命令是全删。
# 两道保险：
#   ① `!assert-flushable`：目录必须**看起来就是一份 raku-pm 前缀**（store/ 、site/ 、
#      installed.json 至少有一个），且不是 $*HOME、不是文件系统根 —— 否则直接 die；
#   ② 只删 `@KNOWN-ENTRIES` 里**认得的条目名**，别的一律不动 —— 于是即使前缀与
#      别的文件混在同一目录，也不会误伤（并把不认识的列出来给人看）。
#
# 【入口目录必须可注入】`<rakudo>.../site/bin` 下那份 wrapper 是本机真正的
# `raku-pm` 命令。测试若走生产路径就会把开发机上的命令删掉 —— 所以 :$entry-dir 与
# `promote-to-site-bin(:$site-bin)` / `ensure-bin-entry(:$dir)` 同一惯例可注入，
# 生产不传才是真的全局 site/bin。
unit role RakuPM::Client::Flusher;

use RakuPM::Fs;
use RakuPM::Prefix;

# 前缀里「认得」的条目 —— 全是 raku-pm 自己造的目录/文件。
# 刻意**不含** `.raku-pm.run.lock` / `.raku-pm.run.lock.owner` / 锁凭证：执行 flush
# 时本进程正持有那把锁（CLI 走 with-write-lock），删掉文件会让释放路径对不存在的
# 东西操作。它们不是安装产物，留着也不影响重装。
my @KNOWN-ENTRIES = < store site git-cache cache log generations stage bin
                       installed.json raku-pm.lock >.List;

# raku-pm 自写 wrapper 的**结构**标记（见 !is-our-wrapper）。
my $WRAPPER-MARKER = 'RAKUPM_RAKU';

# 自装入口的三个文件名（与 ShellTemplates 生成的三份一致）。
my @WRAPPER-NAMES = < raku-pm raku-pm.bat raku-pm.ps1 >.List;

# 人类可读体积（与 clean 的输出风格一致）。
my sub fmt-size(Int $n --> Str) {
    return '0 B' if $n <= 0;
    for (('GB', 1024**3), ('MB', 1024**2), ('KB', 1024)) -> ($unit, $div) {
        return sprintf('%.1f %s', $n / $div, $unit) if $n >= $div;
    }
    "{$n} B"
}

# 清空当前前缀。
# :$yes   真删（默认 False = 只试算）
# :$entry-dir  自装入口所在目录（可注入，测试用；生产不传 = 全局 site/bin）
method flush(Bool :$yes = False, IO::Path :$entry-dir? --> Nil) {
    my $dry    = !$yes;
    # 注意别写 `my $target = self.target.absolute` —— 本版 Rakudo 上
    # IO::Path.absolute 返回的是 **Str**（见 CODEBUDDY），按 IO::Path 用会一路报类型不符。
    # 这里保持 IO::Path，需要字符串时才 .absolute。
    my $target = self.target;
    self!assert-flushable($target);

    say "==> flush{$dry ?? '（试算，不会删除任何文件）' !! ''}";
    say "    前缀：{$target.absolute}";
    say "";

    # ---------- 1) 前缀里认得的条目 ----------
    # 急切收进数组再排序，不写 `$target.dir.sort(...)` 那种懒链：
    #   ① 后面要 rmdir 前缀，Windows 上必须及时释放目录句柄（本项目的老教训）；
    #   ② 本版 Rakudo 上 `Seq.sort({...})` 会把 Seq 本身当成参数喂给比较块，
    #      实测报 "No such method 'basename' for invocant of type 'Seq'"。
    my @entries = $target.dir;
    @entries .= sort({ .basename });
    my @unknown;
    my $total     = 0;
    my $removed   = 0;
    my $present   = 0;
    for @entries -> $e {
        unless @KNOWN-ENTRIES.Set{$e.basename} {
            @unknown.push($e.basename);
            next;
        }
        $present++;
        my $size = $e.d ?? dir-size($e) !! ($e.f ?? $e.s !! 0);
        $total += $size;
        say "    · {$e.basename}{$e.d ?? '/' !! ''}   {fmt-size($size)}";
        unless $dry {
            rm-tree($e);
            $removed++ if !$e.e;
        }
    }
    if $present == 0 {
        say "    （前缀里没有认得的条目 —— 可能已经清过了）";
    }
    else {
        say "    共 {$present} 项，{fmt-size($total)}";
    }

    # ---------- 2) 自装入口（前缀之外的那几份副本）----------
    my $gbin = $entry-dir // self.installer.global-site-bin-dir;
    my @own;
    my @foreign;
    if $gbin.defined && $gbin.Str.chars && $gbin.d {
        for @WRAPPER-NAMES -> $name {
            my $f = $gbin.add($name);
            next unless $f.e;
            self!is-our-wrapper($f) ?? @own.push($f) !! @foreign.push($f);
        }
    }
    say "";
    if @own.elems {
        say "  自装入口（{$gbin.absolute}）—— 内容确认是 raku-pm 自己写的：";
        for @own -> $f {
            say "    · {$f.basename}";
            try { $f.unlink } unless $dry;
        }
    }
    else {
        say "  自装入口：{$gbin.defined && $gbin.Str.chars ?? "{$gbin.absolute} 下没有 raku-pm 写的 wrapper" !! '（未找到全局 site/bin）'}";
    }
    # 同名的外来入口**不删** —— 可能是别的包管理器放的（Unix 上 zef 生成的入口
    # 就叫 `.<名>` 无扩展名形式），删了等于替别人做决定。
    for @foreign -> $f {
        say "    ⚠ 未动 {$f.basename}：它不是 raku-pm 写的（内容里没有 {$WRAPPER-MARKER} 标记）";
    }

    # ---------- 3) 只报告、绝不动的东西 ----------
    my @leftover;
    if $gbin.defined && $gbin.Str.chars && $gbin.d {
        @leftover = $gbin.dir.grep({ .basename.ends-with('.zef-old') }).map(*.basename).List;
    }
    say "";
    if @unknown.elems {
        say "  前缀里还有 {@unknown.elems} 个不认得的条目，未动：{@unknown.join(', ')}";
    }
    if @leftover.elems {
        say "  未动 {@leftover.join(', ')}：那是别的包管理器（zef）入口的**唯一备份**，删了就没得还原。";
        say "    确实不要了再自己删，或先 `raku-pm which` 确认现状。";
    }
    say "  未动其它仓库里的 RakuPM（若 zef 也装过，那份不在本前缀内）——";
    say "    要一并清掉：zef uninstall RakuPM";

    say "";
    if $dry {
        say "试算完成，**没有删除任何文件**（{$present} 项前缀条目 + {@own.elems} 份入口）。";
        say "确认无误后执行：raku-pm flush --yes";
    }
    else {
        # 前缀目录若已空（只剩运行锁那类文件之外的什么都没了）就顺手收掉；
        # 删不掉（还有东西 / 还有锁文件）就静默留着 —— 不是失败。
        try { $target.rmdir };
        say "✓ 已清空（{$removed}/{$present} 项 + {@own.elems} 份入口）。";
        say "";
        # 这里**不能**写「重新安装：raku-pm self-upgrade」—— 入口刚被我们一起删了，
        # 此刻已经没有 `raku-pm` 命令可敲了（写这句话就是把人指进死胡同）。
        say "注意：入口也一并清掉了，所以此刻已经没有 `raku-pm` 命令。装回来的两种办法：";
        say "  zef install <raku-pm 仓库路径>                  （zef 装一份，它会写好入口）";
        say "  raku <仓库路径>/bin/raku-pm.raku install .      （用仓库里的脚本装，它会自己写入口）";
    }
}

# 护栏：确认 $target 看起来就是一份 raku-pm 前缀，否则拒绝执行。
#
# 三件事都要成立（任一不满足就 die —— 不"猜一个安全范围"，因为这是全删操作）：
#   ① 至少存在 store/ 、site/ 、installed.json 之一：这是一份前缀的最小特征，
#      三者全无的目录里根本没有 raku-pm 装过的东西，删它纯属误伤；
#   ② 不是 $*HOME 本身；
#   ③ 不是文件系统根（`/`、`C:` 这类）。
# 比较一律走 RakuPM::Prefix.canonical（统一分隔符、折尾斜杠、Windows 上折大小写）——
# 自己写字符串比较很容易漏掉 `C:\Users\x\.raku-pm` 与 `c:/users/x/.raku-pm` 是同一个目录。
method !assert-flushable(IO::Path $target --> Nil) {
    my $has-marker = ('store', 'site', 'installed.json').first({ $target.add($_).e }).defined;
    unless $has-marker {
        die "拒绝执行：{$target} 看起来不是 raku-pm 前缀"
          ~ "（store/ 、site/ 、installed.json 都不存在）。\n"
          ~ "  确认 --target / RAKUPM_TARGET 指对了再试 —— 这个命令会清空整个前缀。\n"
          ~ "  （如果刚刚 flush 过，这就是正常的：前缀里已经没有 raku-pm 的东西了。）";
    }
    my $c    = canonical($target.Str);
    my $home = canonical($*HOME.Str);
    if $c eq $home {
        die "拒绝执行：前缀指向了家目录本身（{$target}）。\n"
          ~ "  raku-pm 的前缀应当是家目录下的一个子目录（默认 ~/.raku-pm）。";
    }
    if $c eq '' || is-fs-root($target.Str) {
        die "拒绝执行：前缀指向了文件系统根（{$target}）。";
    }
}

# 这份入口是 raku-pm 自己写的 wrapper 吗？
#
# 【按内容判，不按文件名】同一个目录里可能躺着别人放的入口，名字还就叫 `raku-pm`
# （Unix 上 zef 生成的入口就是无扩展名的 `<名>`）。按名字删会删掉别人的东西；
# 按内容只删自己写的那三份 —— 它们都设 `RAKUPM_RAKU` 作为启动兜底，
# 这是**结构**标记（改文案改不动它），比 match 注释里的中文可靠。
# 读之前先看体积：万一有人把 `raku-pm` 换成了一个巨大的二进制，别去 slurp 它。
method !is-our-wrapper(IO::Path $f --> Bool) {
    return False unless $f.f;
    my $size = try { $f.s } // 0;
    return False if $size > 65536;
    my $text = try { $f.slurp } // '';
    $text.contains($WRAPPER-MARKER);
}
