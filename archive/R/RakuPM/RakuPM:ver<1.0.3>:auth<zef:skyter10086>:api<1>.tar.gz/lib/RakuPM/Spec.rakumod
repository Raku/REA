# RakuPM::Spec — zef 风格「安装规格串」的解析（从 RakuPM::Distribution 抽出）
#
#   Foo::Bar                                   → 不指定版本
#   Foo::Bar:ver<1.2.3>                        → 精确 1.2.3
#   Foo::Bar:ver<1.2.3+>                       → 至少 1.2.3（zef 的 + 后缀）
#   Foo::Bar:ver<1.2.3>:auth<zef:someone>      → 版本 + 作者
#   Foo::Bar:ver<1.2.3>:auth<zef:x>:api<1>     → 再加 api
#   Foo::Bar@1.2.3                             → @ 简写，等价于 :ver<1.2.3>
#   Foo::Bar@1.2.3#zef:someone                 → @ver 后跟 #auth，等价 :auth<...>
#                                               （# 在所有 shell 里都不是元字符，
#                                                Windows cmd 下唯一不会撞重定向的
#                                                写法 —— :auth<> 一律要绕路）
#
# 返回 %( module, ver, auth, api )，没写的字段是空串。
#
# 为什么独立成模块：这套写法最早只有 install 在用（解析逻辑也就写在
# Distribution 里）。后来 search / installed / store / version 这些查询命令
# 也要认 `JSON::Fast:ver<1.0>` / `Foo@1.2` 这类输入，而查询路径不该为了解析
# 一个规格串把 Distribution（及其依赖）拖起来 —— 于是抽成零依赖的轻量模块，
# Distribution.parse-spec 保留为委托（老调用方不受影响）。
#
# 约束字符串的匹配交给 RakuPM::Version.satisfies：
#   "1.2.3"（精确）/ ">=1.0" / ">1.0" / "<=2.0" / ">=1.0, <2.0"（区间）
#   / "1.0+"（at-least）/ "*" 或空（任意）。
use RakuPM::Version;

unit class RakuPM::Spec;

# 解析规格串。与旧 Distribution.parse-spec 完全同款逻辑：
# 逐字符扫描而非正则回溯，避开 Raku 正则在多个冒号上的回溯怪癖
# （模块名里的 :: 会被误当 phaser 起点）。
method parse(Str $spec --> Hash) {
    my $s = $spec.trim;

    # @ 简写先归一成 :ver<>，后面走同一条路。
    # 兼容尾部 #auth：Foo@1.2.3#zef:x → Foo:ver<1.2.3>:auth<zef:x>
    # （只切第一个 # 之后；不切的话 zef:x 里也有 :，反而让后面 phaser 扫描误判）
    if $s ~~ /^ ( <-[@]>+ ) '@' ( <-[#]>+ ) ['#' ( <-[#]>+ )]? $ / {
        my $auth = $2.defined ?? 'auth<' ~ $2.Str ~ '>' !! '';
        $s = $0.Str ~ ':ver<' ~ $1.Str ~ '>' ~ ($auth ?? ':' ~ $auth !! '');
    }

    my %out = module => $s, ver => '', auth => '', api => '';
    my $i = 0;
    # 见过任何一个 :word<...>（含未知 word）就不再改 module。
    # 判定「第一个 phaser」不能只看 ver/auth/api 是否为空 —— 未知 phaser
    # （如 :stage<build>）不写这三个键，会让后面真正的 :ver 把 module
    # 改成 "Foo:stage<build>" 这种残段（install 也会中招）。
    my $seen-phaser = False;
    while $i < $s.chars {
        if $s.substr($i, 1) eq ':' {
            my $p    = $i + 1;
            my $word = '';
            while $p < $s.chars && $s.substr($p, 1) ~~ /<alnum>/ {
                $word ~= $s.substr($p, 1);
                $p++;
            }
            # 必须是 :word<...> 才算 phaser；模块名里的 :: 不带 < 所以不会被误伤
            if $word.chars && $p < $s.chars && $s.substr($p, 1) eq '<' {
                %out<module> = $s.substr(0, $i) unless $seen-phaser;
                $seen-phaser = True;
                my $e = self.close-bracket-index($s, $p);
                my $val = $e.defined ?? $s.substr($p + 1, $e - $p - 1) !! '';
                %out{$word} = $val if $word eq 'ver' | 'auth' | 'api';
                $i = $e.defined ?? $e + 1 !! $s.chars;
                next;
            }
        }
        $i++;
    }
    %out<module> .= trim;
    %out
}

# 找 phaser 值的闭合括号下标（$open-at 是开括号 `<` / `(` 的下标）。找不到返回 Nil。
#
# 【为什么不能裸 index($close)】请求串用 `<>` 当外壳，而「大于」运算符 `>=` / `>`
# 自带一个 `>`，且它可能紧跟开括号、也可能出现在区间里：
#     Foo:ver<>=0.1.0>          → 值是 `>=0.1.0`
#     Foo:ver<>0.1.0>           → 值是 `>0.1.0`
#     Foo:ver<>=1.0, <2.0>      → 值是 `>=1.0, <2.0>`（内部还有个 `<2.0>` 的 `>`）
# 裸 index('>') 会在第一个 `>` 处就闭合 → 值被截成空串/半截 —— 约束静默退化成
# 「任意版本 `*`」或丢右界（"装错版本"级别的静默 bug，不报错）。
#
# 【也不能直接 rindex('>')】多 phaser 串 `Foo:ver<>=1.0>:auth<zef:x>` 里，
# 全局最后一个 `>` 属于 `:auth<>`，会把两个 phaser 的值连在一起。
#
# 【做法】先求【本次 phaser 值的右边界】：从开括号往后找下一个 phaser 起点
# （`:word<` / `:word(`），找不到就到串尾。版本约束与 auth 值里都不含 `:`（auth
# 里的 `:` 如 `zef:x` 后面不跟 `<`，不会被误判），所以这个边界是可靠的。
# 再在边界内 rindex 取最后一个 $close。
method close-bracket-index(Str $s, Int $open-at, Str $close = '>' --> Int) {
    my $limit = $s.chars;
    my $j = $open-at + 1;
    while $j < $s.chars {
        if $s.substr($j, 1) eq ':' {
            my $k = $j + 1;
            my $w = '';
            while $k < $s.chars && $s.substr($k, 1) ~~ /<alnum>/ {
                $w ~= $s.substr($k, 1);
                $k++;
            }
            my $nc = $k < $s.chars ?? $s.substr($k, 1) !! '';
            if $w.chars && ($nc eq '<' || $nc eq '(') { $limit = $j; last }
        }
        $j++;
    }
    my $seg = $s.substr($open-at + 1, $limit - $open-at - 1);
    my $idx = $seg.rindex($close);
    return Nil unless $idx.defined;
    $open-at + 1 + $idx
}

# 约束字符串是否合法（search 这类查询命令用它决定「ver 部分当约束还是当关键词」）。
#
# 仅靠 satisfies 的 try 探针不够：from-string 对坏片段退化为 0、'=' 分支
# 永不 die，"bar" 这种纯单词会被当成「= 0.0.0」的合法约束 —— 于是
# `search foo@bar` 会把所有版本筛没。所以先做形状校验：必须以可选的比较
# 运算符开头、后面是版本字符（数字 / v 前缀 / 点 / + / 逗号 / 区间空格），
# 再用 satisfies 的 try 探针兜底（它对未知运算符会 die）。
method constraint-valid(Str $c --> Bool) {
    my $t = ($c // '').trim;
    return False unless $t.chars;         # 空约束交给调用方按「无约束」处理
    return True if $t eq '*';
    # 形状一：可选比较运算符 + 可选 v 前缀 + 必须以数字开头
    return False unless $t ~~ /^ ['>=' | '<=' | '==' | '>' | '<' | '=']? \s* <[vV]>? \d /;
    # 形状二：整串只含版本字符（含区间用的逗号/空格、at-least 的 +、通配 *）
    return False unless $t ~~ /^ <[ \d v V . + \- , \s < > = * ]>+ $/;
    try { RakuPM::Version.from-string('0.0.0').satisfies($t); True } // False
}
