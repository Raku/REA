# RakuPM::Ledger — 安装账本（installed.json）的【唯一】读写入口
#
# 【为什么要有这个类】
# installed.json 是全项目最核心的状态，却原先被 Installer / Client / Cleaner
# 三方直接读写，同一套「解析 → 守卫 → 改 → 序列化」的样板复制了 6 处：
#   !record / mark-explicit / uninstall / list-installed / set-git-sha / recorded-git-sha
# 后果：
#   · 账本格式一变（加 reason、git-shas、versions…）要在 6 处同步，漏一处就写出
#     不一致的状态；
#   · 每个字段都要重新决定一次「要不要 :sorted-keys」「损坏时怎么报错」，容易漂移；
#   · 想换存储形态（比如分片、加索引）得动 6 个地方。
# 收敛到本类后：所有读改写只经过 entries / save / modify / modify-existing / remove，
# 损坏报错、序列化选项、版本排序都只有一处定义。
#
# 【兼容性】Installer 上原有的公开方法（list-installed / installed-versions /
# record-entry / mark-explicit / set-git-sha / recorded-git-sha / uninstall）保留
# 为薄转发，外部调用方与测试不受影响。

use RakuPM::Version;
use JSON::Fast;

unit class RakuPM::Ledger;

has IO::Path $.path is required;     # 通常 <target>/installed.json

method exists(--> Bool) { $!path.e }

# 读全部条目（保持盘上顺序）。文件不存在 → 空列表。
# 损坏（非法 JSON / 顶层不是数组）→ 单条清晰报错，而不是把底层栈甩给用户。
method entries(--> List) {
    return () unless self.exists;
    my $j = try from-json($!path.slurp);
    # from-json 在损坏输入上返回未定义的 Any（而非抛异常），两种都算解析失败
    ($j ~~ Failure || !$j.defined)
        and die "安装账本 {$!path} 解析失败（可能已损坏）：{$!.message}";
    $j.List
}

# 覆盖写。统一 :sorted-keys —— 否则同一份账本会随写入者不同而产生无意义的差异，
# 既污染 git diff，也让「内容是否变化」的判断失真。
method save(@entries --> Nil) {
    $!path.spurt(to-json(@entries.List, :sorted-keys));
}

# 按发行版名定位条目下标（找不到→未定义）
method !index-of(@list, Str $name) {
    @list.first({ ($_<name> // '') eq $name }, :k)
}

# 【upsert】读-改-写：把该 name 的条目（不存在则新建空 Hash）交给 &fn 修改后落盘。
#
# 【主键由账本自己保证】：name 在调用 &fn 前后都被写死成 $name ——
# 调用方只需要关心要改的业务字段，不必（也不该）记得填 name。
# 少了这一手，&fn 漏设 name 就会写出一条「没有主键」的条目：它读得出来、
# 但按 name 再也找不到（后续 modify 会当成新条目追加），账本会静默长重影。
method modify(Str $name, &fn --> Nil) {
    my @list = self.entries;
    my $idx  = self!index-of(@list, $name);
    my %entry = $idx.defined ?? @list[$idx] !! %();
    %entry<name> = $name;
    &fn(%entry);
    %entry<name> = $name;          # 防 &fn 内部误改主键
    $idx.defined ?? (@list[$idx] = %entry) !! @list.push(%entry);
    self.save(@list);
}

# 【只改已存在】条目不存在就什么都不做，返回 False（区别于 modify 的 upsert）。
# 用于「标记 explicit」「记 git 提交号」这类只应作用于已装条目的场景 ——
# 不该因为一次误调用就凭空造出一条已装记录。
method modify-existing(Str $name, &fn --> Bool) {
    my @list = self.entries;
    my $idx  = self!index-of(@list, $name);
    return False unless $idx.defined;
    my %entry = @list[$idx];
    &fn(%entry);
    @list[$idx] = %entry;
    self.save(@list);
    True
}

# 删条目：$version 为空 → 该发行版整条移除（所有版本）；
# 指定版本/范围 → 只去掉满足约束的版本，其余保留（多版本共存下这是常见需求：
# 只想清掉某个出问题的版本，而不是把整个包连根拔起；范围则一次清一批）。
# 版本比较走 semver 约束（RakuPM::Version.satisfies）：精确串退化为单版本匹配，
# "<1.0" / "^1.0" / "~1.2" 这类范围会摘掉所有满足的版本。
method remove(Str $name, Str :$version = '' --> Nil) {
    my $ver = $version.trim;
    my @remaining;
    for self.entries -> %e {
        if (%e<name> // '') ne $name {
            @remaining.push(%e);            # 别的包：原样保留
            next;
        }
        next unless $ver.chars;             # 目标包 + 整包卸载 → 这条直接丢弃
        my @vs = self.versions-of(%e)
                     .grep({ !RakuPM::Version.from-string($_).satisfies($ver) });
        if @vs.elems {
            my %kept = %e;
            %kept<versions> = @vs.List;
            %kept<version>  = @vs[*-1];     # 激活版本回落到剩余里最高的
            @remaining.push(%kept);
        }
    }
    self.save(@remaining);
}

# ---- 版本相关的小工具（账本最频繁的两个问题）----

# 一条账本记录里的全部版本（升序、去重、去空）。
# 兼容老格式：早期只记单个 version 字段，没有 versions 数组。
#
# 排序【必须走 semver】：字典序里 "0.13.0" < "0.9.2"（'1' < '9'），
# 会让「最高版本」判成 0.9.2 —— 用户的实测案例就是装的 0.9.2 与 0.13.0 之后
# installed 的星号标在 0.9.2 上。这里统一到 RakuPM::Version.sort-versions。
# 【公开】因为回滚/一致性检查要拿「一条记录里的版本清单」判断「激活的是哪版」。
method versions-of(%e --> List) {
    RakuPM::Version.new.sort-versions(
        (|@(%e<versions> // []), (%e<version> // '')).map(*.Str))
}

# 某发行版已装的全部版本（升序）。没装过 → 空列表。
method installed-versions(Str $name --> List) {
    my $r = self.entries.first({ ($_<name> // '') eq $name });
    return () unless $r.defined;
    self.versions-of($r)
}

# 当前激活（最高）版本；未装过 → Str 空值。
method installed-version(Str $name --> Str) {
    my @v = self.installed-versions($name);
    @v ?? @v[*-1] !! Str
}

# 读某版本安装时记录的 git 提交号；没记录过（老版本装的 / 非 git 安装）返回空串。
method recorded-git-sha(Str $name, Str $version --> Str) {
    my $r = self.entries.first({ ($_<name> // '') eq $name });
    return '' unless $r.defined;
    return '' unless $r<git-shas>;
    (%($r<git-shas>){$version} // '')
}

# 记录某次安装对应的 git 提交号（按版本分别记：一条条目可有多个版本，
# 各自来自不同提交）。self-upgrade 的「版本相同但内容不同」检测靠它 ——
# git 装的包没有 tar 校验和，提交号是最便宜且足够强的内容指纹。
# 只改已存在条目（没记过这个包就不该凭空造一条已装记录）。
method set-git-sha(Str $name, Str $version, Str $sha --> Nil) {
    self.modify-existing($name, -> %e {
        my %shas = %e<git-shas> ?? %(%e<git-shas>) !! %();
        %shas{$version} = $sha;
        %e<git-shas> = %shas;
    });
}
