# RakuPM::Lock — 锁文件（"可复现安装"的保证）
#
# 为什么需要 lock：META.json 里写的是「范围约束」（如 JSON >= 1.0.0），
# 同一个约束今天解析出 1.0.0，明天仓库出了 1.5.0 就解析出 1.5.0。
# lock 把「某次解析的精确结果」钉死，保证换台机器/换个时间装出来一模一样。
#
# 格式（仿 Cargo.lock）：
# {
#   "version": 1,
#   "entries": [
#     { "name":"JSON", "version":"1.0.0", "auth":"demo:raku",
#       "digest":"f34d14...", "depends":[] }
#   ]
# }

use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Version;
use JSON::Fast;

unit class RakuPM::Lock;

has IO::Path $.path is required;
has Int     $.format-version = 1;

# ============ 读取 ============

method exists(--> Bool) { $!path.e }

# 读取全部条目（name => 条目哈希）
method entries(--> Hash) {
    return {} unless self.exists;
    my $data = try from-json($!path.slurp);
    # from-json 在损坏输入上返回未定义的 Any（而非抛异常），两种都算解析失败
    ($data ~~ Failure || ! $data.defined)
        and die "锁文件 {$!path} 解析失败（可能已损坏）：{$!.message}。"
            ~ "删除该文件后重试即可重新解析依赖。";
    my %out;
    for @($data<entries> // []) -> $e {
        %out{$e<name>} = $e;
    }
    %out
}

# 查某个包被锁定的版本（没锁定返回 Str 空值）
method locked-version(Str $name --> Str) {
    my %e = self.entries;
    %e{$name}:exists ?? %e{$name}<version> !! Str
}

# 查某个包被锁定的内容指纹
method locked-digest(Str $name --> Str) {
    my %e = self.entries;
    %e{$name}:exists ?? (%e{$name}<digest> // '') !! ''
}

# ============ 写入 ============

# 用一批 Distribution 生成/更新锁文件
# @dists 是本次解析出的完整闭包（含依赖）
method write(@dists, RakuPM::Store :$store --> Nil) {
    my @entries = @dists.map({ self!entry-for($_, $store) });
    self!persist(@entries);
}

# 仅当锁里没有同名条目时补记一条（绝不覆盖已有记录）。
# 用于「已装跳过」路径：装完一个包后，即使它之前因历史原因没进锁，
# 也把条目补上，保证锁长期完整（write/remove 之外的第三种写入）。
method ensure-entry(RakuPM::Distribution $dist, RakuPM::Store :$store --> Nil) {
    my %entries = self.entries;
    return if %entries{$dist.name}:exists;
    %entries{$dist.name} = self!entry-for($dist, $store);
    self!persist(%entries.values);
}

# 删除某个包的锁定条目
method remove(Str $name --> Nil) {
    return unless self.exists;
    my @remaining = self.entries.values.grep({ $_<name> ne $name });
    self!persist(@remaining);
}

# 单个锁条目的哈希（write / ensure-entry 共用）
method !entry-for(RakuPM::Distribution $dist, RakuPM::Store $store? --> Hash) {
    %(
        name    => $dist.name,
        version => $dist.version,
        auth    => $dist.auth,
        digest  => ($store.defined && $store.has($dist.name, $dist.version))
                    ?? $store.digest-of($dist.name, $dist.version)
                    !! '',
        depends => $dist.depends.keys.sort.List,
        # :from<native> 的本地库依赖也记进锁里，这样 `raku-pm native --installed`
        # 能反查「已装的包需要哪些系统库」，不用重新解析一遍依赖树
        native-libs => $dist.native-libs.sort.List,
    )
}

# 统一的落盘路径（write / remove / ensure-entry 共用）。
# 避免三处各写一遍「排序 + 序列化 + spurt」，保证锁格式一致。
method !persist(@entries --> Nil) {
    $!path.spurt(to-json({
        version      => $!format-version,
        generated-at => DateTime.now.Str,
        entries      => @entries.sort({ $^a<name> cmp $^b<name> }),
    }, :sorted-keys));
}

# ============ 校验 ============

# 检查现有 lock 是否满足所有约束。
# 返回不满足的条目列表（空列表表示 lock 可以直接复用）。
# 语义边界：只比对「锁里已有的条目」的版本是否漂移，「本次要新增的依赖」
# 在这里不算冲突 —— 新增由 enforce 单独补一轮（见下）。
method check-against(@dists --> List) {
    my %locked = self.entries;
    my @conflicts;
    for @dists -> $dist {
        if %locked{$dist.name}:exists {
            my $lv = %locked{$dist.name}<version>;
            # 版本比较走 semver，不能用字符串 ne：
            # "1.0.0" ne "1.0" 会被误判成版本漂移，乱报冲突。
            if RakuPM::Version.from-string($lv)
               .cmp(RakuPM::Version.from-string($dist.version)) != Same {
                @conflicts.push({
                    name     => $dist.name,
                    locked   => $lv,
                    resolved => $dist.version,
                });
            }
        }
    }
    @conflicts.List
}

# 严格模式：如果 lock 与本次解析结果不一致就报错（CI 场景常用）。
# 两种不一致都要拦：
#   1. 版本漂移（lock 锁定 A 1.0，本次解析出 A 1.5）—— check-against 覆盖；
#   2. lock 里根本没有这个包（本次要新增依赖）—— check-against 只比对已有
#      条目，新增在它看来不算冲突，但 --locked 下照样不能装。这里补一轮。
method enforce(@dists --> Nil) {
    my @conflicts = self.check-against(@dists);

    my %locked = self.entries;
    for @dists -> $dist {
        next if %locked{$dist.name}:exists;
        @conflicts.push({
            name     => $dist.name,
            locked   => '（锁里没有此条目）',
            resolved => $dist.version,
        });
    }

    return unless @conflicts;
    my $msg = "锁文件 {$!path} 与当前解析结果不一致（用 --locked 时不会自动更新）：\n";
    for @conflicts -> $c {
        $msg ~= "  · {$c<name>}: 锁定 {$c<locked>}，实际解析 {$c<resolved>}\n";
    }
    die $msg;
}

# 锁文件里所有发行版声明的本地库（去重排序）。
# 老锁文件没有 native-libs 字段，这里用 // [] 兼容。
method native-libs(--> List) {
    self.entries.values
        .map({ |@($_<native-libs> // []) })
        .unique.sort.List
}

# 列出锁文件内容（供 CLI 展示）
method describe(--> Str) {
    return "无锁文件（{$!path}）" unless self.exists;
    my %e = self.entries;
    my $out = "锁文件 {$!path}（{%e.elems} 个条目）：\n";
    for %e.keys.sort -> $name {
        my $e = %e{$name};
        $out ~= "  · {$e<name>} {$e<version>}" ~
                ($e<digest> ?? "  digest={$e<digest>.substr(0,8)}" !! '') ~ "\n";
    }
    $out
}
