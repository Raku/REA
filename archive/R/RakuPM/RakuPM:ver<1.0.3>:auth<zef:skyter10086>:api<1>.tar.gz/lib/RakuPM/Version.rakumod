# RakuPM::Version — 语义化版本 (semver) 的解析、比较、约束匹配
#
# 支持约束： "1.2.3"（精确）、">= 1.0"、">1.0"、"<=2.0"、">=1.0, <2.0"（区间）、
#           "*" 或空（任意版本）。
# 这是「解析阶段」的核心：判断「某版本是否满足某约束」。

unit class RakuPM::Version;

has Int $.major = 0;
has Int $.minor = 0;
has Int $.patch = 0;
has Str $.prerelease = '';

# 从 "1.2.3" / "1.2.3-alpha" / "v0.2" 解析。
# 生态索引里的版本号很脏（有 "v0.2"、"0.2rc1" 这类），而 pick-best 会对
# 【所有候选版本】调用本方法，任何一个坏串都会让整个解析阶段崩掉，
# 所以这里对非数字片段一律退化为 0，而不是抛异常。
method from-string(Str $s --> RakuPM::Version) {
    my $t = ($s // '').trim;
    $t ~~ s{^ <[vV]> } = '';                 # "v0.2" -> "0.2"
    my ($core, $pre) = $t.split('-', 2);
    # semver：build metadata（`+build`）【不参与】优先级比较，必须先剥掉。
    # 不剥的话 `1.0.0-alpha+1` 与 `1.0.0-alpha` 会被排成两个不同版本（实际比的是
    # "+1" 这个字符串），而 semver 规定二者优先级【相同】。core 上也可能带
    # （`1.0.0+build`）。剥掉的只是比较用的内部表示 —— 对外返回给用户的版本串
    # 始终是原始字符串（pick-best 与各处展示都取原始串），所以不受影响。
    $core = $core.split('+', 2)[0];
    $pre  = ($pre // '').split('+', 2)[0];
    my @parts = $core.split('.');
    RakuPM::Version.new:
        :major(self!num-part(@parts[0])),
        :minor(self!num-part(@parts[1])),
        :patch(self!num-part(@parts[2])),
        :prerelease($pre // '');
}

# 取字符串开头的数字部分，取不到（空 / 非数字 / "2rc1"）就当 0
method !num-part($x --> Int) {
    my $n = ($x // '').trim;
    return 0 unless $n.chars;
    $n ~~ /^ (\d+) / ?? +$0 !! 0
}

# 数值化：转成可比较的元组（cmp / sort-versions / pick-best 全走这里）。
#
# 第 4 位是【预发布段的比较键】，按 semver 2.0.0 §11 的优先级规则展开成可比较结构：
#   · 正式版 > 同 core 的预发布版        → 正式版是 (1,)，预发布是 (0, …)
#   · 数字标识符 < 字母数字标识符        → 数字 (0, N, '')，字母 (1, 0, S)
#   · 同位数字比数值，同位字母比 ASCII
#   · 前面的都相同则【字段少的更低】      → 1.0.0-alpha < 1.0.0-alpha.1
#     （靠 List 的 cmp 天然满足：`(0,…) cmp (0,…,x)` 是 Less；已实测）
#
# 【0.87.3 修的坑】原实现是 `$!prerelease eq '' ?? 1 !! 0` —— 把整段预发布折成一个
# 布尔，于是 alpha / beta / rc1 的 key **完全相同**、cmp 一律判 Same。它不报错、也不
# 崩，而是给出「取决于输入顺序」的静默错答：
#   pick-best("*", <1.0.0-alpha 1.0.0-beta 1.0.0-rc1>)  → 1.0.0-alpha   ← 错
#   pick-best("*", <1.0.0-rc1 1.0.0-beta 1.0.0-alpha>)  → 1.0.0-rc1     ← 对（纯属运气）
# 同一集合换个顺序就换答案，这比显式报错难查得多 —— 也正是「放宽/丢失精度类缺陷只能
# 靠逐字断言抓」的又一例（旧的 `t/version.t` 对预发布只有一个 `> 0` 的存在性断言）。
method key(--> List) {
    ($!major, $!minor, $!patch, |self!pre-key)
}

# 预发布段的比较键（规则见上面 key 的注释）。
# 空（正式版）→ `(1,)`，比任何预发布键 `(0, …)` 都大。
method !pre-key(--> List) {
    return (1,) if $!prerelease eq '';
    (0, |$!prerelease.split('.').map(-> $id {
        # 纯数字 → 数值比较（rank 0）；其余 → ASCII 比较（rank 1，比数字大）
        $id ~~ /^ \d+ $/ ?? (0, +$id, '') !! (1, 0, $id)
    }).List)
}

# 三向比较：返回 Order::Less / Same / More
method cmp(RakuPM::Version $other --> Order) {
    self.key cmp $other.key
}

# 便捷运算符
multi sub infix:<eqv-ver>(RakuPM::Version $a, RakuPM::Version $b --> Bool) { $a.cmp($b) == Same }
multi sub infix:«<ver»(RakuPM::Version $a, RakuPM::Version $b --> Bool) { $a.cmp($b) == Less }

# ============ 约束解析 ============

# 检查某个版本是否满足一个「约束字符串」
method satisfies(Str $constraint --> Bool) {
    return True if $constraint.trim eq '' or $constraint.trim eq '*';

    # 先把 npm/cargo 风格的 ^ / ~ 糖语法展开成 >= / < 比较器对，再走下面的通用解析。
    # 只处理「符号后跟版本字符」的情形，不会误伤本项目已有的其它写法。
    my $c = self.expand-sugar($constraint);

    # 用逗号拆成多个子约束，必须「全部」满足（AND 关系）
    for $c.split(',') -> $part {
        my $p = $part.trim;
        next if $p eq '';

        # 用字符串前缀匹配解析运算符，避免正则里 < > 的歧义
        my ($op, $ver) = self.parse-constraint-part($p);
        my $target = RakuPM::Version.from-string($ver);
        my $c = self.cmp($target);

        given $op {
            # 注意：'=' 与 '==' 是「精确匹配」，只接受相等，不能放宽成 >=
            when '==' | '=' { return False unless $c == Same; }
            when '>=' | ''  { return False unless $c == More || $c == Same; }
            when '>'        { return False unless $c == More; }
            when '<='       { return False unless $c == Less || $c == Same; }
            when '<'        { return False unless $c == Less; }
            default         { die "未知的约束运算符: $op"; }
        }
    }
    True
}

# 解析单个子约束，如 ">= 1.0.0" -> (">=", "1.0.0")
method parse-constraint-part(Str $p --> List) {
    # zef 风格 "0.2+" 表示「至少 0.2」（at-least）。
    # 仅当约束以数字开头、以 + 结尾时才按 at-least 处理，
    # 避免误伤 ">=" 这类自身不带 + 的写法，也避免把 "1.0+" 当普通字符串。
    if $p ~~ /^ \d .*? '+' $ / {
        my $ver = $p.substr(0, $p.chars - 1).trim;
        return ('>=', $ver) if $ver.chars;
    }
    # 注意顺序：先匹配双字符运算符，再匹配单字符
    my @ops = ['>=', '<=', '==', '>', '<', '='];
    for @ops -> $op {
        if $p.starts-with($op) {
            my $ver = $p.substr($op.chars).trim;
            return ($op, $ver);
        }
    }
    # 没有运算符，视为精确匹配
    return ('=', $p);
}

# ============ ^ / ~ 糖语法展开（npm / cargo 风格）============
# 把 ^（caret，兼容区间）与 ~（tilde，近似区间）展开成项目统一的 >= / < 比较器对，
# 再交给 parse-constraint-part 解析。展开产物里不含 ^ / ~，不会二次展开。
#   ^1.2.3 → >=1.2.3, <2.0.0      ^0.2.3 → >=0.2.3, <0.3.0
#   ^0.0.3 → >=0.0.3, <0.0.4      ^1    → >=1.0.0, <2.0.0
#   ~1.2.3 → >=1.2.3, <1.3.0      ~1.2  → >=1.2.0, <1.3.0
#   ~1     → >=1.0.0, <2.0.0
method expand-sugar(Str $c is copy --> Str) {
    # 只认「符号后跟版本字符（数字 / v / . / x / *）」，其余写法原样保留
    $c = $c.subst(:g, / \^ \s* (<[ \d v V . x X * ]>+) /,
        -> $/ { ">= $0, <" ~ self!caret-upper(~$0) ~ ">" });
    $c = $c.subst(:g, / \~ \s* (<[ \d v V . x X * ]>+) /,
        -> $/ { ">= $0, <" ~ self!tilde-upper(~$0) ~ ">" });
    $c
}

# 用户在糖语法里写了几段版本：`1` → 1；`1.2` → 2；`1.2.3` → 3。
#
# 【0.87.2 修的坑，别再改回 comb】原实现写的是 `.comb('.').elems`，注释还写着
# 「用户给了几位」—— 但 `comb` 返回的是**匹配到的分隔符本身**，不是被分隔的段：
#   '1'     .comb('.') → ()      elems=0   （应为 1）
#   '1.2'   .comb('.') → (.)     elems=1   （应为 2）
#   '1.2.3' .comb('.') → (. .)   elems=2   （应为 3）
# 整整差一位，于是「按最后指定的位 +1」那类分支全部错位，表现为**约束过宽**
# （比写严了危险得多：用户以为锁住了 minor，实际放进来了整个大版本）：
#   ~1.2   → <2.0.0（应 <1.3.0）  ← 最常见的两段写法，全错
#   ~0.1   → <1.0.0（应 <0.2.0）
#   ^0.0   → <1.0.0（应 <0.1.0）
#   ^0.0.0 → <0.1.0（应 <0.0.1）
# 注意 `~1.2.3` 与 `^1` 当年「看起来是对的」纯属歪打正着（差一位后恰好落进正确分支），
# 所以只测这两种形态的断言抓不到这个 bug —— 见 t/version.t 的糖语法矩阵（两侧都断言）。
# 用 `split` 数段数才不歧义（尾部空段保留，`:skip-empty` 不需要）。
method !spec-parts(Str $v --> Int) {
    my $t = $v.subst(/^ <[vV]> /, '').trim;
    return 0 unless $t.chars;
    $t.split('.').elems
}

# caret 上界（npm 语义：允许「不改变最左非零位」的升级）
#   有 major(>0) → major+1.0.0          例：^1.2.3 → 2.0.0
#   否则有 minor(>0) → 0.(minor+1).0    例：^0.2.3 → 0.3.0
#   否则有 patch(>0) → 0.0.(patch+1)    例：^0.0.3 → 0.0.4
#   全零 → 按【用户写了几段】+1          ^0 → 1.0.0；^0.0 → 0.1.0；^0.0.0 → 0.0.1
method !caret-upper(Str $v --> Str) {
    my $p = RakuPM::Version.from-string($v);
    my $n = self!spec-parts($v);
    return "{$p.major + 1}.0.0" if $p.major > 0;
    return "0.{$p.minor + 1}.0" if $p.minor > 0;
    return "0.0.{$p.patch + 1}" if $p.patch > 0;
    # 全零：按最后指定的位 +1（^0 → 1.0.0；^0.0 → 0.1.0；^0.0.0 → 0.0.1）
    return $n >= 3 ?? "0.0.1" !! ($n == 2 ?? "0.1.0" !! "1.0.0");
}

# tilde 上界（npm 语义：允许 patch 级升级；只写 major 时退化成允许 minor 级升级）
#   给了 minor（>= 2 段）→ major.(minor+1).0    例：~1.2.3 → 1.3.0；~1.2 → 1.3.0
#   只给 major（1 段）  → (major+1).0.0         例：~1 → 2.0.0
method !tilde-upper(Str $v --> Str) {
    my $p = RakuPM::Version.from-string($v);
    my $n = self!spec-parts($v);
    return "{$p.major}.{$p.minor + 1}.0" if $n >= 2;
    "{$p.major + 1}.0.0"
}

# 从一组可用版本里挑出「满足约束的最高版本」（返回版本字符串或空串）
method pick-best(Str $constraint, @versions --> Str) {
    my @ok = @versions
        .map({ ($_, RakuPM::Version.from-string($_)) })   # (原始串, Version 对象)
        .grep({ .[1].satisfies($constraint) })
        .sort({ $^b[1].cmp($^a[1]) });          # 从高到低
    return '' unless @ok;
    # 返回仓库里出现的「原始版本串」，而不是规范化后的 major.minor.patch，
    # 否则像 "0.2" 会被归一成 "0.2.0"，与 available-versions 对不上导致找不到。
    @ok[0][0]
}

# 版本字符串列表按 semver 升序（去重 + 去空）。
#
# 不能用字典序：字典序里 "0.13.0" < "0.9.2"（因为 '1' < '9'），
# 会把 0.9.2 误当成最高版本（用户的实测案例：装了 0.9.2 与 0.13.0 后，
# installed 的星号标在 0.9.2 上）。
#
# 这是全项目统一的版本排序入口——别在调用处再手写比较器，
# 否则容易有的地方 semver、有的地方字典序，显示与取最高版本就会不一致。
method sort-versions(@versions --> List) {
    # .defined 不能省：账本里偶尔会混进未定义值，直接 .chars 会刷一屏警告
    @versions.grep({ .defined && .chars }).unique
        .sort({ RakuPM::Version.from-string($^a).cmp(RakuPM::Version.from-string($^b)) })
        .List
}
