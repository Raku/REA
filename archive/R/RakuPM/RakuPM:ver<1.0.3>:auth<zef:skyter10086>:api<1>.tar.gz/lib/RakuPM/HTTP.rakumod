use RakuPM::HTTP::Backend;
use RakuPM::Net;
use JSON::Fast;               # post-json 用 to-json 构造 JSON 请求体

# RakuPM::HTTP — 网络层门面（单后端：HTTP::Tinyish，底层走系统 curl；+ 重试 + 代理 + TTL）。
#
# 设计目标：
#
#   1) 单后端（curl）：读路径（拉索引 / 下 tar / 条件 GET）全部经 RakuPM::HTTP::Tinyish，
#      底层是系统 curl —— TLS / 代理（含 HTTPS 走代理的 CONNECT 隧道）最稳。
#      【0.82.0 起不再有第二后端】：曾同时带一个纯 Raku 的 HTTP::Tiny 兜底 + 自动回退
#      顺序 + 可插拔注册表（RAKUPM_HTTP_BACKEND / register-backend），但那份「插件化」
#      对单机教学场景收益低、维护面大，已整体移除。与已删除的自管 curl 子进程（旧
#      Curl.rakumod，曾因 run() 管道句柄泄漏挂死）不同，这里整个网络由成熟依赖
#      HTTP::Tinyish 自己管子进程，raku-pm 不碰 run()。
#      测试若需替身，用构造器 :backend 注入一个实现了 RakuPM::HTTP::Backend 的假后端即可。
#   2) 韧性：每一次调用都被 !with-retry 包裹（指数退避 + 抖动），最后一击失败才抛错；
#      单次请求超时透传 :max-time。
#   3) 代理：从环境 HTTPS_PROXY/HTTP_PROXY（及小写变体）读取，或构造时 :proxy 传入。
#   4) 门面只管网络：HTTP/HTTPS 之外的地址（本地索引文件）不进本门面，
#      由调用方（Ecosystem）直接用 IO::Path 读取，零外部进程依赖。
unit class RakuPM::HTTP;

has $.backend;                                    # 单个后端实例；未显式注入则首次用到时懒建 Tinyish
has Str      $.proxy;                             # 代理 URL（空串=不代理）
has Int      $.attempts   = 3;                     # 最多重试几次
has Numeric  $.base-delay = 1;                     # 退避基数（秒），第 i 次失败后等 base*2**i
has Numeric  $.max-time   = 120;                   # 单次请求超时（秒）
has Bool     $.debug      = False;                 # debug 级日志开关（默认关；详见 !dbg）

submethod BUILD(:$backend, :$proxy, :$attempts, :$base-delay, :$max-time, :$debug) {
    # 注意：默认值不放签名里（签名默认值在编译期求值，不能前向引用私有方法），
    # 统一在方法体里按「未传则取默认」处理。
    $!backend    = $backend;      # 仅测试注入替身时才给；生产留空 → 首次用到时懒建 Tinyish
    $!proxy      = ($proxy.defined && $proxy.chars) ?? $proxy !! self!proxy-from-env;
    $!attempts   = $attempts   // 3;
    $!base-delay = $base-delay // 1;
    $!max-time   = $max-time   // 120;
    # debug 开关：构造器 :$debug 优先；未传则看环境变量 RAKUPM_HTTP_DEBUG
    #（1/true/yes/on 算开，与 RakuPM::Net.offline 的判定口径一致）。默认关，
    # 关时本层零新增输出 —— 既不影响正常用户，也不让测试因为噪音标记（⚠/[RakuPM]）
    # 误判失败（见 tools/run-suite.raku 的「输出洁净」检查）。
    $!debug = $debug // do {
        my $e = %*ENV<RAKUPM_HTTP_DEBUG>;
        # 用 .first + eq 比较，不用 (elem) / any：① <1 true yes on> 里的 1 会被词引用
        # 转成 IntStr，而 (elem) 走 === 身份比较，Str('1') === IntStr('1') 为 False
        #（正是 RakuPM::Net 注释里记的那坑）；② any() 返回 Junction，赋给 Bool 属性会
        # 触发 Type check 失败（本 Rakudo 不会对 Junction 做 Bool 坍缩），反而让设了
        # 该环境变量的每次 new 都抛异常。这里返回普通 Bool。
        return False unless $e.defined;
        my $s = $e.Str.trim.lc;
        ?(<1 true yes on>.first({ $s eq $_ }));
    };
}

method !proxy-from-env(--> Str) {
    for <HTTPS_PROXY https_proxy HTTP_PROXY http_proxy> {
        return %*ENV{$_} if %*ENV{$_}:exists && %*ENV{$_}.chars;
    }
    ''
}

# debug 级日志（Issue 6：HTTP 可观察性）。
#
# 设计：默认关（$.debug=False），关时本方法直接返回、零输出；开时把排障信息打到
# stderr（note）。所有行以「  · http: 」前缀，刻意【不含】 `⚠` 与 `[RakuPM]` —— 后者
# 是 tools/run-suite.raku 在 t/ 下判「输出洁净」的噪音标记（生产级告警会搞乱
# zef install 日志），debug 日志若带这俩标记会让用例误红。前缀里的 `·` 与现有
# `!with-retry` 的 `  · HTTP 请求失败…` 风格一致，便于肉眼归类。
#
# 开的方式（双入口，互不冲突）：① 构造器 :$debug；② 环境变量 RAKUPM_HTTP_DEBUG。
# 后者让【不改动任何调用点】就能打开排障（用户 / CI 设个环境变量即可）。
method !dbg(Str $msg --> Nil) {
    return unless $!debug;
    note "  · http: {$msg}";
}

# 当前后端的标签（debug 用）：注入了替身就报它的类名，否则报将要懒建的 Tinyish。
method !backend-label(--> Str) {
    $!backend.defined ?? $!backend.^name !! 'RakuPM::HTTP::Tinyish';
}

# 取【唯一】后端实例：显式注入的先用；否则首次用到时懒建 Tinyish（带 proxy/max-time）并缓存。
# 懒加载的意义：只用本地索引、从不联网的路径不必把 HTTP::Tinyish 拉起来。
# 加载 / 构造失败一律 die —— 单后端没有「回落到下一个」了。
method !backend-instance() {
    return $!backend if $!backend.defined;
    my Str $name = 'RakuPM::HTTP::Tinyish';
    # 【关键陷阱（0.36.20 实测）】本 Rakudo 里 `try { … }` 失败返回的是【Nil】而不是
    # Failure（`my $r = try { die "x" }` → $r 是未定义 Any，`$r ~~ Failure` 为 False）——
    # 所以别用 `~~ Failure` 判加载失败；改用「try 块显式返回 True，看有没有定义」。
    my $ok = try { require ::($name); True };
    die "HTTP 后端不可用：无法加载 {$name}（raku-pm 网络层需要系统 curl + HTTP::Tinyish）"
        unless $ok.defined;
    my $class = ::($name);
    my $inst = try { $class.new(:proxy($!proxy), :max-time($!max-time)) };
    die "HTTP 后端不可用：{$name}.new 失败" unless $inst.defined;
    $!backend = $inst;    # 缓存实例，别每次请求都重建
    $inst;
}

# 【离线硬闸门】三个请求出口的第一行都是 assert-online：离线时直接报错。
#
# 为什么放在门面这一层，而不是各调用点自己判断：
#   · 调用点有几处（拉索引、下 tarball、将来还会有别的）；
#   · 任何一处忘了判断，行为就变成「离线时偷偷联网」——最难查的一类问题
#     （用户以为断网了，实际在慢慢超时；CI 以为确定性，实际打到了公网）。
# 放在这里，漏判会立刻炸出来：吵，但方向明确。
method get-text(Str $url --> Str) {
    self!dbg("GET {$url}  离线={ offline() ?? 'ON（assert-online 将硬拦，绝不静默联网）' !! 'off' }");
    assert-online("HTTP GET {$url}");
    my $be = self!backend-instance;
    self!dbg("用后端 {self!backend-label} 发请求");
    self!with-retry({ $be.get-text($url) })
}

method download(Str $url, IO::Path $dest --> Nil) {
    self!dbg("DOWNLOAD {$url}  离线={ offline() ?? 'ON（assert-online 将硬拦）' !! 'off' }");
    assert-online("下载 {$url}");
    my $be = self!backend-instance;
    self!dbg("用后端 {self!backend-label} 下载到 {$dest}");
    self!with-retry({ $be.download($url, $dest); True });
}

# 条件 GET：带 If-None-Match 去拉索引，远端未变回 304（调用方复用缓存、跳过下载）。
# 后端若未实现 get-text-conditional（自定义/测试桩），退化为普通 GET（200 + 正文）。
method get-text-conditional(Str $url, Str :$if-none-match = ''
                            --> RakuPM::HTTP::ConditionalResponse) {
    self!dbg("条件 GET {$url}{ $if-none-match.chars ?? "  If-None-Match={$if-none-match}" !! '' }"
        ~ "  离线={ offline() ?? 'ON（assert-online 将硬拦）' !! 'off' }");
    assert-online("条件获取 {$url}");
    my $be = self!backend-instance;
    self!dbg("用后端 {self!backend-label} 发条件请求");
    my $resp = self!with-retry({
        $be.can('get-text-conditional')
            ?? $be.get-text-conditional($url, :if-none-match($if-none-match))
            !! RakuPM::HTTP::ConditionalResponse.new(:status(200), :body($be.get-text($url)))
    });
    # 统一「缓存命中」措辞：304 = 命中本地缓存、不重新下载；其余 = 拿到新内容。
    # 这条口径与 Net.offline() 的「三出口」一致 —— HTTP / 生态索引都经本门面，
    # 命中缓存即「离线也能用」，git 走的是另一条子进程出口（不在本层）。
    self!dbg($resp.not-modified
        ?? "条件获取结果：304 命中本地缓存（Not Modified，复用本地，不重新下载）"
        !! "条件获取结果：{$resp.status} 有新内容（已下载）");
    $resp
}

# 上行请求（raku-pm 唯一的上行路径，其余都是 GET）：multipart/form POST。
#
# 为什么用 curl 而不是 HTTP::Tinyish 后端：下载走 HTTP::Tinyish（底层 curl）没问题，
# 但【multipart 文件上传】HTTP::Tinyish/HTTP::Tiny 都不原生支持（要手工拼 body），
# 而 fez/zef 服务端 42.zef.pm/upload 期望的正好是 curl `-F "dist=@<file>"` 那种
# multipart 表单。raku-pm 已依赖 curl（tar 也用），直接复用最稳、最贴合服务端。
#
# 与已删除的旧 Curl.rakumod（常驻管道、句柄泄漏挂死）不同，这里是【一次性子进程】：
# run 之后必须 slurp(:close) 关掉 :out/:err 两条管道（见 RakuPM::Fs 记忆——不关会
# Windows 句柄泄漏、子进程不退出）。用 -o 落响应体、-w '%{http_code}' 拿状态码，
# 这样既能拿到服务端 JSON 错误体，又能精确判 HTTP 状态（不靠 curl 退出码近似）。
# 离线时 assert-online 直接硬拦（与三个 GET 出口一致）。
method upload-multipart(Str $url, IO::Path $file, Str :$auth = '' --> Hash) {
    # dist 字段值带前导 @ → curl 当作「上传该文件」（与 fez 一致）。
    # 注意：@ 必须字面拼接，不能写进双引号插值（@{} 会被当数组插值而报编译错）。
    my $dist-field = '@' ~ $file.absolute.Str;
    self.post-form($url, :fields(%('dist' => $dist-field)), :$auth);
}

# 通用 multipart POST（login / upload 共用）。:%fields 的「值」若以 @ 开头，curl
# 会当作文件上传（upload 的 dist 字段就是这种）；其余按普通表单字段发送。
# 返回 %{ ok, status, body, error }：ok 看 HTTP 2xx；error 仅在失败时填 stderr。
method post-form(Str $url, :%fields, Str :$auth = '' --> Hash) {
    self!dbg("POST（curl 表单）{$url}  离线={ offline() ?? 'ON（assert-online 将硬拦）' !! 'off' }");
    # RAKUPM_CURL 默认是系统 curl；测试时指向一个 .raku/.rakumod 脚本（「假 curl」）。
    # 若指向 raku 脚本，则用当前解释器 $*EXECUTABLE 直接运行它——这同时绕开了 Windows 上
    # run()→cmd /c→.bat 对含空格实参（如 -H "Authorization: Zef <key>"）的引号错位，
    # 否则带空格的字段会让 .bat 启动失败、整个上传链路拿不到响应。
    my $curl = %*ENV<RAKUPM_CURL> // 'curl';
    self!dbg("curl 实现 = {$curl}{ %*ENV<RAKUPM_CURL>.defined ?? '  （覆盖来源：RAKUPM_CURL）' !! '  （默认系统 curl）' }");
    assert-online("POST {$url}");
    my @curl-cmd = do {
        if $curl ~~ / '.raku' $ / || $curl ~~ / '.rakumod' $ / {
            ($*EXECUTABLE.absolute.Str, $curl)
        }
        else {
            ($curl,)
        }
    };
    my $body-file = ($*TMPDIR // '/tmp'.IO)
        .add("rakupm-post-{($*PID)}-{now.to-posix[0].Int}.body");
    my @args = |@curl-cmd, '-S', '-s', '-o', self!http-path($body-file.absolute.Str),
               '-w', '%{http_code}';
    for %fields.kv -> $k, $v {
        @args.push('-F', "{$k}={$v}");
    }
    @args.push('-H', "Authorization: Zef {$auth}") if $auth.chars;
    @args.push(self!http-path($url));

    my $p = run(|@args, :out, :err);
    # 子进程 stdout / stderr 按二进制读回，再 utf-8 解码；解码失败时退回 latin-1。
    # 关键：Windows 上子进程（含 .bat 包装）的 stderr 可能是系统代码页（如 GBK）文本，
    # 严格 utf-8 解码会抛「Malformed UTF-8」直接炸掉整个上传链路 —— 这里宽容处理，
    # 保证「服务端/网络报错」能被正常捕获成 error 文本，而不是让上传崩溃。
    my $code-s = self!lenient-decode($p.out.slurp(:bin)).subst("\r", '');
    my $err    = self!lenient-decode($p.err.slurp(:bin));
    my $code   = ($code-s ~~ / (\d+) /) ?? $0.Int !! $p.exitcode;
    my $body   = $body-file.e ?? $body-file.slurp(:bin) !! Buf[uint8].new;
    $body-file.unlink;
    my $body-str = $body ~~ Blob ?? self!lenient-decode($body) !! $body.Str;
    my $ok = $code ~~ 200..299;
    return %( ok => $ok, status => $code, body => $body-str,
              error => ($ok ?? '' !! $err.trim) );
}

# JSON POST（login 专用）：服务端 42.zef.pm/login 的 from-body 只认
# application/json（实测 multipart/form-data 与 urlencoded 都会让服务端 500
# 「Odd number of elements found where hash initializer expected」——它从 JSON 体里
# 取 username/password）。所以登录必须发 JSON 体，而不是复用 post-form 的 multipart。
# 返回 %{ ok, status, body, error }：ok 看 HTTP 2xx；error 仅在失败时填 stderr。
method post-json(Str $url, :%json, Str :$auth = '' --> Hash) {
    self!dbg("POST（curl JSON）{$url}  离线={ offline() ?? 'ON（assert-online 将硬拦）' !! 'off' }");
    # RAKUPM_CURL 默认是系统 curl；测试时指向一个 .raku/.rakumod 脚本（「假 curl」），
    # 用当前解释器 $*EXECUTABLE 直接运行（绕开 Windows run()→cmd/c→.bat 对含空格
    # 实参的引号错位，见 post-form 注释）。
    my $curl = %*ENV<RAKUPM_CURL> // 'curl';
    self!dbg("curl 实现 = {$curl}{ %*ENV<RAKUPM_CURL>.defined ?? '  （覆盖来源：RAKUPM_CURL）' !! '  （默认系统 curl）' }");
    assert-online("POST {$url}");
    my @curl-cmd = do {
        if $curl ~~ / '.raku' $ / || $curl ~~ / '.rakumod' $ / {
            ($*EXECUTABLE.absolute.Str, $curl)
        }
        else {
            ($curl,)
        }
    };
    my $body-file = ($*TMPDIR // '/tmp'.IO)
        .add("rakupm-post-{($*PID)}-{now.to-posix[0].Int}.body");
    my $json-str = to-json(%json, :sorted-keys, :!pretty);
    my @args = |@curl-cmd, '-S', '-s', '-o', self!http-path($body-file.absolute.Str),
               '-w', '%{http_code}',
               '-H', 'Content-Type: application/json';
    @args.push('-H', "Authorization: Zef {$auth}") if $auth.chars;
    @args.push('-d', $json-str);
    @args.push(self!http-path($url));

    my $p = run(|@args, :out, :err);
    # 子进程 stdout / stderr 按二进制读回，再 utf-8 解码；解码失败时退回 latin-1
    # （见 post-form 对 Windows 系统代码页的宽容处理）。
    my $code-s = self!lenient-decode($p.out.slurp(:bin)).subst("\r", '');
    my $err    = self!lenient-decode($p.err.slurp(:bin));
    my $code   = ($code-s ~~ / (\d+) /) ?? $0.Int !! $p.exitcode;
    my $body   = $body-file.e ?? $body-file.slurp(:bin) !! Buf[uint8].new;
    $body-file.unlink;
    my $body-str = $body ~~ Blob ?? self!lenient-decode($body) !! $body.Str;
    my $ok = $code ~~ 200..299;
    return %( ok => $ok, status => $code, body => $body-str,
              error => ($ok ?? '' !! $err.trim) );
}

# 给 curl 用的路径：Windows 上 curl 是原生程序，收原生 C:/…（不要 MSYS /c/…）。
# 这里不像 tar 那样探测 GNU/BSD，因为 curl 本就是 fez 用的那支、原生形态即可。
method !http-path(Str $p --> Str) { $p.subst('\\', '/', :g) }

# 把子进程管道读回的 Buf 解码成 Str：先试 utf-8（绝大多数情况），失败退回 latin-1
# （逐字节可逆，绝不会抛「Malformed UTF-8」）。避免 Windows 上子进程 stderr 是系统
# 代码页（GBK 等）时，严格 utf-8 解码直接炸掉调用方（见 post-form）。
method !lenient-decode(Blob $buf --> Str) {
    return '' unless $buf.defined && $buf.elems;
    my $s = try $buf.decode('utf-8');
    return $s.defined ?? $s !! $buf.decode('latin-1');
}

# 指数退避重试：第 i 次失败后等 base*2**i 秒（带 ±25% 抖动，避免多进程同步重试），
# 最多 attempts 次；最后一次失败把原异常抛出。
method !with-retry(&op) {
    my $last;
    for ^$!attempts -> $i {
        try {
            my $v := &op();
            return $v;
        }
        $last = $!;
        if $i < $!attempts - 1 {
            my $wait = self!backoff($i);
            my $msg  = $last.message.lines.head;
            note "  · HTTP 请求失败（第 {$i+1}/{$!attempts} 次）：{$msg} —— {$wait}s 后重试";
            sleep $wait;
        }
    }
    $last.throw;
}

method !backoff(Int $i --> Numeric) {
    my $base = $!base-delay * 2 ** $i;
    $base * (0.75 + rand * 0.5)        # ±25% 抖动
}
