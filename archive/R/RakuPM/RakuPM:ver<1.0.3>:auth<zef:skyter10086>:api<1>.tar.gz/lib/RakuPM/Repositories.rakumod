# RakuPM::Repositories — 仓库列表（可配置、可持久化）
#
# 设计动机：Raku 世界不止一个生态索引，且它们收录范围不同、字段细节也不同：
#
#   别名    索引 URL                                                          条数(2026-09)
#   zef     https://360.zef.pm                                                ~8k   当前版本
#   rea     https://raw.githubusercontent.com/Raku/REA/main/META.json         ~15k  含历史版本
#   cpan    .../ugexe/Perl6-ecosystems/master/cpan1.json                      ~2k   CPAN 上的 Perl6 模块
#   p6c     .../ugexe/Perl6-ecosystems/master/p6c1.json                       —      旧生态存档
#
# 单个索引装不全所有包（用户实测：某些包只在 REA 里有），所以仓库必须是「数组」，
# 解析时把多个索引的候选合并，再挑满足约束的最高版本——Resolver 本来就是这么写的，
# 本模块只负责「这个数组从哪来、怎么增删改、怎么落盘」。
#
# 配置来源优先级（高 → 低）：
#   1. $RAKUPM_TARGET/repositories.json   （repos add/remove 命令维护，持久化）
#   2. $RAKUPM_ECOSYSTEM 环境变量          （支持逗号/分号分隔多个 URL）
#   3. 默认：zef + cpan + rea 三个索引 + 本地 $RAKUPM_REPO 目录

use JSON::Fast;
use RakuPM::Repository::Local;
use RakuPM::Repository::Ecosystem;

use RakuPM::Fs;
unit class RakuPM::Repositories;

# 内置索引目录：让用户能 `raku-pm repos add rea` 而不是抄长 URL。
# 用 my 而不是 our：Raku 里跨模块访问 `our` 包变量语法别扭且容易拿到空值，
# 统一走下面的 index-aliases / url-for-alias 类方法暴露。
my %INDEX-ALIASES =
    'zef'  => 'https://360.zef.pm',
    'rea'  => 'https://raw.githubusercontent.com/Raku/REA/main/META.json',
    'cpan' => 'https://raw.githubusercontent.com/ugexe/Perl6-ecosystems/master/cpan1.json',
    'p6c'  => 'https://raw.githubusercontent.com/ugexe/Perl6-ecosystems/master/p6c1.json',
;

# 别名 → URL 的只读映射（CLI 帮助、测试、外部工具用）
method index-aliases(--> Hash) { %INDEX-ALIASES }

# 把一个 spec（别名或 URL）解析成 URL；不是已知别名就原样返回
method url-for-alias(Str $spec --> Str) {
    %INDEX-ALIASES{$spec.lc} // $spec
}

has IO::Path $.config-file is required;   # repositories.json
has IO::Path $.cache-root  is required;   # 索引缓存目录
has Str      $.repo-root   = '.';         # 本地仓库根（$RAKUPM_REPO）
has          @.entries;                   # 配置项：[{name,type,url|path}, ...]

# ============ 载入 ============

# 按优先级载入配置。文件不存在时用环境变量 / 默认值兜底，但【不立即落盘】
# （避免只是想跑个 --dry 就在 HOME 里生成文件）。
method load(--> Nil) {
    if $!config-file.e {
        my $data = try from-json($!config-file.slurp);
        if $data.defined && $data<repos> ~~ Positional {
            @!entries = |$data<repos>;
            self!apply-env-overrides;
            return;
        }
        note "⚠ 仓库配置文件解析失败，改用默认配置：{$!config-file}";
    }
    @!entries = self!entries-from-env;
}

# $RAKUPM_REPO 是【调用级】设置（等价于「这次在哪个目录找本地包」），即使配置
# 文件里已经存了 local 的路径，命令行显式指定时也必须听它的。
# 否则 `RAKUPM_REPO=./vendor raku-pm install Foo` 会静默用回上次存下的路径，
# 表现为「明明把包放进去了却找不到」。
# 注意这与 $RAKUPM_ECOSYSTEM 不同：生态索引是用 repos add/remove 管理的
# 【持久配置】，所以只有配置文件不存在时才用环境变量兜底。
method !apply-env-overrides(--> Nil) {
    my $repo = %*ENV<RAKUPM_REPO>;
    return unless $repo.defined && $repo.trim;
    my $i = @!entries.first({ .<type> eq 'local' }, :k);
    if $i.defined {
        @!entries[$i]<path> = $repo.trim;
    }
    else {
        @!entries.push(%( name => 'local', type => 'local', path => $repo.trim ));
    }
}

# 从环境变量 + 默认值构造条目（不读文件）
method !entries-from-env(--> List) {
    my @out;
    my $eco = %*ENV<RAKUPM_ECOSYSTEM> // '';
    if $eco.trim {
        # 支持多个：逗号或分号分隔，每项可以是 URL 也可以是内置别名
        for $eco.split(/<[,;]>/) -> $spec {
            my $s = $spec.trim;
            next unless $s;
            my $url = self.url-for-alias($s);
            @out.push(%( name => self.name-for-url($url), type => 'ecosystem', url => $url ));
        }
    }
    else {
        # 默认挂三个索引：zef（主）+ cpan + rea。单个索引装不全所有包
        # （实测 Terminal::Spinners 只在 cpan/REA 里有，zef 里查不到 →
        # 「在所有已配置的仓库里都找不到模块」）。多索引候选在 Resolver 里
        # 合并、挑满足约束的最高版本，首次会多下两个索引（cpan ~2.6M、
        # rea ~18M），但一次性的，之后有 TTL 缓存。用户可用
        # `raku-pm repos remove cpan|rea` 精简，或用 RAKUPM_ECOSYSTEM 覆盖。
        for 'zef', 'cpan', 'rea' -> $alias {
            @out.push(%( name => $alias, type => 'ecosystem',
                        url => %INDEX-ALIASES{$alias} ));
        }
    }
    @out.push(%( name => 'local', type => 'local', path => $!repo-root ));
    @out
}

# 由 URL 推出一个人类可读的名字：先反查别名，再退化到文件名/host
method name-for-url(Str $url --> Str) {
    for %INDEX-ALIASES.kv -> $k, $v {
        return $k if $v eq $url;
    }
    my $u = $url.subst('https://', '').subst('http://', '');
    my @seg = $u.split('/').grep(*.chars);
    # raw.githubusercontent.com/OWNER/REPO/.../FILE.json → 用 OWNER 下的仓库名不够直观，
    # 退化规则：有文件名就用文件名（去扩展名），否则用 host
    if @seg.elems >= 2 {
        my $file = @seg.tail;
        $file .= subst(/\.json$/, '');
        return $file.lc if $file.chars && $file.lc ne 'meta';
    }
    # 纯主机（没有路径）：360.zef.pm → zef，example.com → example
    my $host = @seg[0] // $u;
    my @lab = $host.split('.');
    # 必须「全标签都是数字」才算真 IP，不能只判首标签（123.foo.example.com 会被误判成 IP，
    # 错误返回 @lab[1]="foo" 而非二级域名 @lab[*-2]="example"）
    return @lab[1].lc if @lab.elems >= 3 && @lab.all ~~ /^ \d+ $/;
    return @lab[*-2].lc if @lab.elems >= 2;
    $host.lc
}

# ============ 构造仓库对象 ============

# 把配置条目实例化成真正的 Repository 对象（Local 与 Ecosystem）
method build(--> List) {
    my @repos;
    for @!entries -> %e {
        given %e<type> {
            when 'local' {
                @repos.push(RakuPM::Repository::Local.new(
                    :root((%e<path> // $!repo-root).IO),
                    # 名字用于 search 结果里区分「来自哪个本地仓库」
                    :name(%e<name> // 'local')));
            }
            when 'ecosystem' {
                @repos.push(RakuPM::Repository::Ecosystem.new(
                    :name(%e<name> // self.name-for-url(%e<url>)),
                    :index-url(%e<url>),
                    :cache-root($!cache-root),
                ));
            }
            default {
                note "⚠ 忽略未知仓库类型 '{%e<type>}'";
            }
        }
    }
    @repos.List
}

# ============ 增删改 ============

# 添加一个仓库。
#
# $spec 可以是三种东西，按这个顺序判定：
#   1. 本地目录（$spec.IO.d）      → type=local，path=绝对路径
#   2. 内置别名（rea / cpan / …）  → type=ecosystem
#   3. 完整 URL                    → type=ecosystem
#
# 以前只认 ecosystem，传个目录进来会被当成 URL 存下（"已添加仓库 'repo' → ./repo"），
# 不报错但之后拿它当 JSON 索引去 HTTP 拉，必失败——静默的坑。
#
# 名字：--name 显式指定 > 本地目录取 basename > URL 由 name-for-url 推。
# 本地路径存【绝对路径】：local:. 那种相对路径是刻意的（跟随 cwd），
# 但用户 add 进来的仓库不该跟着 cwd 漂移，换目录跑就找不到了。
method add(Str $spec, Str :$name = '' --> Str) {
    if $spec.IO.d {
        my $path  = $spec.IO.absolute;
        my $lname = $name.trim || $path.IO.basename || 'local';
        if @!entries.first({ .<type> eq 'local' && (.<path> // '') eq $path }) {
            return "本地仓库 '$lname' 已在列表中（$path）";
        }
        my $at = @!entries.elems;
        @!entries.push(%( :name($lname), type => 'local', :$path ));
        self.save;
        return "已添加本地仓库 '$lname' → $path（优先级 #{$at}）\n"
             ~ "  目录即索引：往里放「含 META6.json 的子目录」就等于收录一个发行版";
    }

    my $url  = self.url-for-alias($spec);
    my $ename = $name.trim || self.name-for-url($url);
    if @!entries.first({ .<type> eq 'ecosystem' && .<url> eq $url }) {
        return "仓库 '$ename' 已在列表中";
    }
    # 追加到【最后一个远程索引之后】（也就是 local 之前），而不是顶到最前面。
    # 理由：后加的通常是 rea / cpan 这类补充源，收录杂、版本老；
    # 让主索引 zef 保持在最前，解析时的提示信息与缓存归属才符合直觉。
    # （Resolver 会把所有索引的版本候选合并后取最高，所以顺序只影响平局时的归属。）
    my $at = @!entries.first({ .<type> ne 'ecosystem' }, :k) // @!entries.elems;
    @!entries.splice($at, 0, %( :name($ename), type => 'ecosystem', :$url ));
    self.save;
    "已添加索引仓库 '$ename' → $url（优先级 #{$at}）"
}

# 移除仓库。$spec 可以是名字（rea / local / 自己 add 的目录名）、完整 URL，
# 或本地目录路径（本地条目存的是 path 不是 url，得一并匹配，否则按路径删不掉）。
method remove(Str $spec --> Str) {
    my $lc = $spec.lc;
    my $idx = @!entries.first({
        (.<name> // '').lc eq $lc
        || (.<url>  // '').lc eq $lc
        || (.<path> // '').lc eq $lc
        || (.<path>.defined && $spec.IO.d && (.<path> // '') eq $spec.IO.absolute)
    }, :k);
    return "未找到仓库 '$spec'" unless $idx.defined;
    my %gone = @!entries.splice($idx, 1)[0];
    self.save;
    "已移除仓库 '{%gone<name>}'"
}

# 强制重新拉取生态索引缓存（对应 zef 的 update）。会覆盖本地缓存文件，
# 下次安装/查询立刻用上新索引。
# $spec 为空 → 更新全部 ecosystem 仓库；否则按名字或 URL 指定一个。
# 逐个更新，个别失败不影响其它；全部失败或一个都没有时报错。
method update(Str $spec = '' --> Nil) {
    my @targets = $spec.chars
        ?? @!entries.grep({ .<type> eq 'ecosystem'
                && ((.<name> // '').lc eq $spec.lc || (.<url> // '').lc eq $spec.lc) })
        !! @!entries.grep({ .<type> eq 'ecosystem' });

    unless @targets.elems {
        die $spec.chars
            ?? "未找到生态仓库 '$spec'（repos list 可查看名字；本地目录不需要更新）"
            !! "没有可更新的生态索引（repos list 可查看配置）";
    }

    my @errors;
    for @targets -> %e {
        my $url  = %e<url>;
        my $name = %e<name> // self.name-for-url($url);
        say "==> 更新索引 [{$name}]：{$url}";
        my $ok = try {
            # :refresh(True) 绕过本地缓存强制重拉（Ecosystem 缓存存在时默认复用）
            my $repo = RakuPM::Repository::Ecosystem.new(
                :$name, :index-url($url), :cache-root($!cache-root), :refresh(True));
            $repo.refresh;
            my $n = $repo.all-distributions.elems;
            say "✓ [{$name}] 已更新：索引里 {$n} 个发行版";
            True
        } // False;
        @errors.push("[{$name}] 更新失败：{$!}") unless $ok;
    }

    if @errors.elems {
        note "";
        note "⚠  {@errors.elems} 个索引更新失败：";
        note "    {$_}" for @errors;
        note "    （不影响其它仓库；可稍后重试 repos update）";
        die "生态索引更新失败 {@errors.elems} 个" if @errors.elems == @targets.elems;
    }
}

method save(--> Nil) {
    mkdir-p($!config-file.parent);
    $!config-file.spurt(to-json(%( version => 1, repos => @!entries ), :sorted-keys));
}

# ============ 展示 ============

# 列出所有仓库：序号 / 名字 / 类型 / 地址
method describe(--> Str) {
    return "（没有配置任何仓库）" unless @!entries.elems;
    my @lines = "已配置的仓库（共 {@!entries.elems} 个，按优先级从上到下）：";
    for @!entries.kv -> $i, %e {
        my $where = %e<type> eq 'local' ?? (%e<path> // $!repo-root) !! (%e<url> // '?');
        my $tag   = %e<type> eq 'local' ?? '本地目录' !! '远程索引';
        @lines.push("  [{$i}] {%e<name> // '?'}  {$tag}  {$where}");
    }
    @lines.join("\n")
}
