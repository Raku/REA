# RakuPM::CliSpec — CLI 的命令元数据（唯一事实来源）
#
# 为什么单独成模块：这些表原本躺在 bin/raku-pm.raku 里，而 bin 同时承担解析、校验、
# 派发与大量命令实现，三者纠缠的后果是「加一个旗标要改好几处、而且没法单测」。
# 抽出来之后：bin 只保留解析 / 校验 / 派发；这张表可以直接被 t/ 测（不必起子进程）；
# 新增旗标只改这里一处。
#
# 【严格约束】completion-script 生成的文本是**用户可见产物**（用户 source 进 shell），
# help 文本同理。本模块的任何改动都必须保持 help / completions 输出【逐字节不变】——
# 注意补全脚本里出现的 `%CMD_FLAGS` 等字样本身就是产物的一部分，别顺手"美化"。
#
# 三个维度（原先散在 bin 的派发逻辑各处，现在收拢到这里）：
#   · writes-prefix(命令)   —— 会写安装前缀（store / site / 账本 / bin）
#   · needs-network(命令)   —— 可能出网（用于「离线模式」提示）
#   · command-group(命令)   —— 命令分组（供 help 分区 / 补全分类 / 覆盖自检）
# 注：跨进程写锁的实际包裹仍由 bin 逐处 guarded(...) 决定，本轮重构【不改行为】。
unit module RakuPM::CliSpec;

# ---------------------------------------------------------------------------
# 公共旗标：每个命令都认。
# 原先 allowed-flags 与 completion-script 里各写了一份内容相同的清单（改一个要记得改
# 两处），这里合并成一份。`offline` 也放在公共项而不是逐命令登记 —— 它只改变「允不
# 允许出网」，不改变命令语义，漏登记某个命令的后果是「--offline 被当成拼错的旗标」。
# ---------------------------------------------------------------------------
my @COMMON = < target no-lock promote-bin no-promote-bin offline no-color >;

sub common-flags(--> List) is export { @COMMON.List }

# ---------------------------------------------------------------------------
# 命令 → 命名选项白名单（唯一事实来源）。allowed-flags 与 completions 都读它，
# 新增命令/选项时只改这里一处，补全脚本与旗标校验自动同步。
# ---------------------------------------------------------------------------
my %CMD_FLAGS =
    # 安装三入口共用同一组（git / 本地目录没有 --version，但多给一个不报错）
    'install'      => < locked dry no-test no-build no-test-deps no-native-check
                        force allow-test-failure test-timeout version
                        lock-file pin >,
        'upgrade'      => < dry version only >,
        'fetch'        => < to version >,
        'repos'        => < name >,
        'update'       => (),   # 顶层别名：刷新仓库索引（= repos update；无参刷新全部）
        'uninstall'    => < version force recursive keep-store >,
        'reinstall'    => < version force recursive dry no-test no-build
                            no-test-deps no-native-check allow-test-failure
                            test-timeout pin >,
        'autoremove'   => < dry >,
        'self-upgrade' => < from from-dir dry force no-test lock-file >,
        'self-remove'  => < dry >,
        'clean'        => < all yes force older-than name >,
        'gc'           => < all yes force older-than name >,
        'flush'        => < yes force >,
        'native'       => < os distro installed paths >,
        'store'        => < verify >,
        'verify'       => < content fix >,
        'rollback'     => (),
        'version'      => (),
        'search'       => (),
        'rdepends'     => (),
        'rdeps'        => (),
        'depends'      => (),
        'info'         => (),
        'browse'       => (),
        'locate'       => (),
        'why'          => < pin >,
        'smoke'        => < allow-test-failure test-timeout >,
        'list'         => (),
        'installed'    => (),
        'env'          => (),
        'shell'        => < shell >,
        'which'        => (),
        'lock'         => (),
        'generations'  => (),
        'gens'         => (),
        'outdated'     => (),
        'doctor'       => (),
        'completions'  => < shell >,
        'help'         => (),
        # 本地发行版的单阶段执行（只读：不装、不改账本、不写锁）
        'test'         => < allow-test-failure test-timeout >,
        'build'        => (),
        # 仓库级提交前检查：跑本仓库的文档纪律 + 具名实参 + t/（内部调 tools/run-suite.raku，
        # 与预提交钩子共用同一份门禁实现，不另起一套）。--filter / --jobs 透传给 run-suite，
        # 便于「只验某个用例」时不必等全量。
        'preflight'    => < filter jobs >,
        # 取源码进目录
        'look'         => < version shell >,
        # 作者侧（面向一个发行版目录）
        'refresh'      => < dry >,
        'new'          => < into auth version with-readme bin force dry >,
        'check'        => < remote >,
        'dist'         => < to no-build dry >,
        'bump'         => < to major minor date dry no-sync-docs >,
        'publish'      => < to from no-build force dry remote quiet >,
        'login'        => < api-key username password quiet >,
        'logout'       => (),
    ;

sub cmd-flags(--> Hash) is export { %CMD_FLAGS }

# ---------------------------------------------------------------------------
# 命令简写别名 → 规范命令名（唯一事实来源）。
# 设计意图：长命令（install / uninstall / upgrade …）在交互里敲着累，
# 给一套短别名（仿 git/shell 习惯：i / un / up / ls / rm / doc …）。
# 别名只在此表登记一处，派发时一次性归一化成规范名，
# 之后 help / version / allowed-flags / given 派发全部只看规范名 —— 别名不会让任何分支重复。
# 注意：别名不得与规范命令名或彼此冲突（如 rm 专指 uninstall，不与任何命令前缀撞车）。
# ---------------------------------------------------------------------------
my %CMD_ALIASES =
    'i'    => 'install',
    'un'   => 'uninstall',
    'rm'   => 'uninstall',
    'up'   => 'upgrade',
    'upd'  => 'update',
    'ri'   => 'reinstall',
    'ls'   => 'list',
    'li'   => 'installed',
    'inf'  => 'info',
    'dep'  => 'depends',
    'rdep' => 'rdepends',
    's'    => 'search',
    't'    => 'test',
    'b'    => 'build',
    'f'    => 'fetch',
    'doc'  => 'doctor',
    'out'  => 'outdated',
    'gen'  => 'generations',
    'rb'   => 'rollback',
    'ar'   => 'autoremove',
    'nat'  => 'native',
    'vfy'  => 'verify',
    'st'   => 'store',
    'w'    => 'which',
    'e'    => 'env',
    'sh'   => 'shell',
    'loc'  => 'locate',
    'br'   => 'browse',
    'wh'   => 'why',
    'su'   => 'self-upgrade',
    'sr'   => 'self-remove',
    'repo' => 'repos',
    'lk'   => 'lock',
    'sm'   => 'smoke',
    ;

sub cmd-aliases(--> Hash) is export { %CMD_ALIASES }

# 把可能带别名的命令名归一化成规范名。非别名原样返回。
# 派发前调用一次，之后的校验 / 派发 / 元数据查询都只看规范名。
# 名字刻意不叫 `canonical`：RakuPM::Prefix 已经导出同名 sub，而 bin 两个都 use ——
# 同名导入会直接编译失败（"Cannot import symbol '&canonical' ... already exists"）。
sub canonical-command(Str $cmd --> Str) is export { %CMD_ALIASES{$cmd} // $cmd }

# ---------------------------------------------------------------------------
# 维度 1：会写安装前缀的命令（原本是 bin 里的 %prefix-writer）
# 用途：自定义 --target 时提示「这次不碰全局 site/bin，用之前要把 <target>/bin 放进 PATH」。
# 读命令（version / installed / which / env / lock / help / completions …）刻意不在内，
# 免得它们也刷这句提示。
# ---------------------------------------------------------------------------
my %WRITES-PREFIX = < install upgrade reinstall uninstall autoremove fetch look
                      self-upgrade self-remove repos update clean gc rollback
                      flush >.SetHash;

sub writes-prefix(Str $cmd --> Bool) is export { %WRITES-PREFIX{$cmd}.so }

# ---------------------------------------------------------------------------
# 维度 2：可能联网的命令（原本是 bin 里的 %net-cmd）
# 用途：--offline 时只在「本来会联网」的命令上打一行「本轮不联网」提示，
# 读命令多这两行纯属噪声。
# ---------------------------------------------------------------------------
my %NEEDS-NETWORK = < install upgrade update fetch look depends search list
                      repos self-upgrade
                      info browse smoke outdated why >.SetHash;

sub needs-network(Str $cmd --> Bool) is export { %NEEDS-NETWORK{$cmd}.so }

# ---------------------------------------------------------------------------
# 维度 3：命令分组（新增，供 help 分区 / 补全分类 / 覆盖自检）
# t/cli-spec.t 会断言「每个 %CMD_FLAGS 里的命令都有分组」，防止新增命令时漏登。
# ---------------------------------------------------------------------------
my %GROUP-OF;
%GROUP-OF{$_} = 'packages' for < install upgrade reinstall uninstall autoremove
                                 fetch look search list info outdated browse
                                 locate smoke installed depends rdepends rdeps why >;
%GROUP-OF{$_} = 'repos'    for < repos update >;
%GROUP-OF{$_} = 'env'      for < env shell which doctor verify generations gens
                                 rollback clean gc flush store native lock >;
%GROUP-OF{$_} = 'self'     for < self-upgrade self-remove >;
%GROUP-OF{$_} = 'meta'     for < version help completions >;
%GROUP-OF{$_} = 'author'   for < refresh new check dist bump publish login logout >;
%GROUP-OF{$_} = 'dev'      for < test build preflight >;

sub command-group(Str $cmd --> Str) is export { %GROUP-OF{$cmd} // 'other' }

# ---------------------------------------------------------------------------
# 旗标白名单：公共项 + 该命令自己的项。
# 选项是「开放式」接收的（任何 --key 都进 %opts），所以必须有一份白名单来挡拼错的
# 旗标 —— 见 bin 的 MAIN。
# ---------------------------------------------------------------------------
sub allowed-flags(Str $cmd --> SetHash) is export {
    my %per = %CMD_FLAGS;
    my %out;
    %out{$_} = True for @COMMON;
    %out{$_} = True for (%per{$cmd} // ()).list;
    %out.SetHash
}

# ---------------------------------------------------------------------------
# 生成某 shell 的补全脚本（到 stdout，用户 source 即可）。
# 命令清单与旗标全部取自 %CMD_FLAGS（allowed-flags 的唯一事实来源），
# 新增命令/选项后无需改这里 —— 补全自动跟上。支持 bash / zsh / fish / pwsh。
# ---------------------------------------------------------------------------
sub completion-script(Str $shell --> Str) is export {
    # 补全清单同时列出规范命令名与简写别名（别名表是唯一事实来源）
    my @cmds   = (|%CMD_FLAGS.keys, |%CMD_ALIASES.keys).unique.sort;
    my &flag-str = -> $c {
        my $real = %CMD_ALIASES{$c} // $c;
        my @f = (|@COMMON, |(%CMD_FLAGS{$real} // ()).list).unique;
        @f ?? (@f.map({ "--$_" }).join(' ')) !! ''
    };

    given $shell.lc {
        when 'fish' {
            my @lines;
            @lines.push: '# raku-pm fish 补全（自动生成，命令/旗标取自 %CMD_FLAGS）';
            @lines.push: "complete -c raku-pm -n '__fish_use_subcommand' -a '"
                       ~ @cmds.join(' ') ~ "'";
            for @cmds -> $c {
                my $f = flag-str($c);
                next unless $f.chars;
                @lines.push: "complete -c raku-pm -n '__fish_seen_subcommand_from $c' "
                           ~ "-a '$f'";
            }
            return @lines.join("\n") ~ "\n";
        }
        when 'pwsh' | 'powershell' {
            my $cmds-str = @cmds.map({ "'$_'" }).join(', ');
            my @switch;
            # 每条命令的补全行模板（q:to 不插值：PowerShell 的 $ / { } / [ ] 全字面）
            my $cmd-tmpl = q:to/CMD/;
        '__C__' { @(__F__) | Where-Object { $_ -like "$wordToComplete*" } | ForEach-Object { [System.Management.Automation.CompletionResult]::new($_) } }
CMD
            for @cmds -> $c {
                my $f = flag-str($c);
                next unless $f.chars;
                my $fq-str = $f.words.map({ "'$_'" }).join(', ');
                @switch.push: $cmd-tmpl.subst('__C__', $c).subst('__F__', $fq-str);
            }
            # q:to 不插值：PowerShell 脚本里的 $ / { } 全是字面量，避免被 Raku 当插值块
            my $script = q:to/PWSH/;
# raku-pm PowerShell 补全（自动生成，命令/旗标取自 %CMD_FLAGS）
Register-ArgumentCompleter -CommandName raku-pm -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $cmds = @(__CMDS__)
    $cmd = ($commandAst.CommandElements | Select-Object -Skip 1 | Select-Object -First 1).Extent.Text
    if (-not $cmd) {
        $cmds | Where-Object { $_ -like "$wordToComplete*" } | ForEach-Object { [System.Management.Automation.CompletionResult]::new($_) }
        return
    }
    switch ($cmd) {
__SWITCH__
    }
}
PWSH
            $script .= subst('__CMDS__', $cmds-str);
            $script .= subst('__SWITCH__', @switch.join("\n"));
            return $script;
        }
        default {  # bash / zsh（zsh 走 bashcompinit）
            my @lines;
            @lines.push: '# raku-pm bash/zsh 补全（自动生成，命令/旗标取自 %CMD_FLAGS）';
            @lines.push: '_raku_pm() {';
            @lines.push: '    local cur="${COMP_WORDS[COMP_CWORD]}"';
            @lines.push: '    local cmd="${COMP_WORDS[1]}"';
            @lines.push: '    local cmds="' ~ @cmds.join(' ') ~ '"';
            @lines.push: '    COMPREPLY=()';
            @lines.push: '    if [ "$COMP_CWORD" -eq 1 ]; then';
            @lines.push: '        COMPREPLY=( $(compgen -W "$cmds" -- "$cur") )';
            @lines.push: '        return';
            @lines.push: '    fi';
            @lines.push: '    case "$cmd" in';
            for @cmds -> $c {
                my $f = flag-str($c);   # 已含公共旗标（见 flag-str）
                @lines.push: "        $c) COMPREPLY=( \$(compgen -W \"$f\" -- \"\$cur\") ) ;;" if $f.chars;
            }
            @lines.push: '    esac';
            @lines.push: '}';
            if $shell.lc eq 'zsh' {
                @lines.push: 'autoload -U bashcompinit && bashcompinit';
                @lines.push: 'complete -F _raku_pm raku-pm';
            }
            else {
                @lines.push: 'complete -F _raku_pm raku-pm';
            }
            return @lines.join("\n") ~ "\n";
        }
    }
}
