# RakuPM::Prefix — 「安装前缀」这个概念的唯一出处
#
# 【为什么单独成文件，而不是塞进 Client 或 Platform】
#   · 默认前缀（~/.raku-pm）有两个消费者，而它们**不能互相依赖**：
#       - bin/raku-pm.raku —— 必须在 require RakuPM::Client **之前**就知道前缀
#         （version / help 要零模块图冷启动，见该文件顶部注释）；
#       - RakuPM::Client —— TWEAK 里要按「是否默认前缀」决定 promote-bin。
#     两处各写一遍 ~/.raku-pm 就是两个事实来源，迟早漂移；
#     而 CLI 若为了拿这个常量去 require Client，version 的冷启动就白优化了。
#   · 塞进 Platform 不合适：Platform 的职责是「平台差异的唯一出处」，
#     而「装到哪个目录」是产品决策、跟操作系统无关。
#   · 零依赖（只用 Platform 的 is-windows / native-path），CLI 顶部 use 它
#     不会拖起任何模块图。
#
# 【这个模块就是「插座」】—— 外部工具（将来的工具链管理器，或某个项目脚本）
# 只要两件事就能把 raku-pm 当后端用：
#   ① 告诉它前缀（--target=<路径> 或 RAKUPM_TARGET）；
#   ② 把 <前缀>/bin 放到 PATH 最前。
# 前缀内部怎么组织（store / site / 账本 / 世代）全由 raku-pm 负责，外部不必知道。
unit module RakuPM::Prefix;

use RakuPM::Platform;

# 默认安装前缀：~/.raku-pm。
# 刻意与 zef 的 site 仓库（<rakudo>/share/perl6/site）分开 —— 两者是并行的
# 两个 Installation 仓库，互不覆盖（见 README「安装位置」）。
sub default-target(--> IO::Path) is export {
    $*HOME.add('.raku-pm');
}

# 把连续的 `/` 折成一个，并去掉尾部斜杠（保留根与前导斜杠）。
# 刻意不写正则：正则字面量的分界符就是 `/`，要匹配 `/` 得转义或加引号，
# 很容易写成 `$/`（那是匹配对象变量）或 `** 2..*` 这类需要推敲的形态 ——
# 这里用 split/grep/join，读起来没有歧义。
my sub canon-slashes(Str $s --> Str) {
    my $lead = $s.starts-with('/');
    my $body = $s.split('/').grep(*.chars).join('/');
    $lead ?? "/{$body}" !! $body;
}

# 展开前导 `~`（`~/x` 与 `~\x`；不处理 `~user` —— 跨平台语义不一致，宁可不猜）。
#
# 【为什么必须自己做】0.49.0 实测：**Rakudo 不展开 IO::Path 里的 `~`** ——
#   '~/.raku-pm'.IO.absolute  →  <当前目录>/~/.raku-pm
# 于是 `raku-pm --target=~/myenv install Foo` 会真的在当前目录下建一个字面叫
# `~` 的目录。`--target=~/x` 是最自然的写法之一，静默装到别处属于「事后极难
# 联想」的那类错误，所以在入口就展开掉。
my sub expand-tilde(Str $s --> Str) {
    return $s unless $s.starts-with('~');
    my $rest = $s.substr(1);
    return $s if $rest.chars && !($rest.starts-with('/') || $rest.starts-with("\x5C"));
    my $home = $*HOME.absolute.Str.subst("\x5C", '/', :g);
    $rest = $rest.substr(1) if $rest.chars;
    $rest.chars ?? "{$home}/{$rest}" !! $home;
}

# 把用户写的路径串解析成可用的绝对路径（保留原生分隔符）。
# 顺序有讲究：先展 `~`，再交给 Platform.native-path 处理 MSYS 风格
# （它按平台门控：Linux 上 /c/foo 是合法路径、不能篡改），最后才绝对化 ——
# 反过来的话 Windows 上 `/c/foo` 会先被 .absolute 拼成 C:\c\foo，救不回来。
sub normalize(Str $p --> IO::Path) is export {
    my $s  = expand-tilde($p.trim);
    my $np = native-path($s);
    # 实测（Rakudo 2026.08）：**IO::Path.absolute 返回的是 Str，不是 IO::Path**
    # （`.^name` = Str；写成 `--> IO::Path` 的返回类型会当场断言失败）。所以这里
    # 要显式 .IO 转回去。`try` 失败返回 Nil（Raku 的 try 没有 else 分支）。
    my $abs = try { $np.absolute };
    $abs.defined ?? $abs.IO !! $np;
}

# 解析最终前缀：--target > RAKUPM_TARGET > 默认。
# 单一入口 —— CLI 与测试都走这里，「哪个优先」只有一处实现。
sub resolve(Str :$flag = '', Str :$env = '' --> IO::Path) is export {
    for $flag, $env -> $cand {
        next unless $cand.defined;
        my $s = $cand.trim;
        next unless $s.chars;
        return normalize($s);
    }
    default-target();
}

# 用于【比较】的规范形式：绝对路径、统一正斜杠、折掉重复与尾部斜杠，
# Windows 上折小写（文件系统大小写不敏感：`C:\Users\X\.raku-pm` 与
# `c:/users/x/.raku-pm` 是同一个前缀）。
#
# 只用于比较，不用于落盘 —— 所以 UNC 的 `//server/share` 会被折成
# `/server/share`（前缀永远不会是 UNC，取值域够窄，不值得为此复杂化）。
sub canonical(Str $p --> Str) is export {
    my $s = canon-slashes(normalize($p).Str.subst("\x5C", '/', :g));
    is-windows() ?? $s.lc !! $s;
}

# 这个前缀是不是「默认前缀」。
# 判据是**路径值相等**，而不是「用户有没有写 --target」：
# 把 RAKUPM_TARGET=~/.raku-pm 写进 shell 配置的人，意图就是默认前缀。
sub is-default-target(IO::Path $target --> Bool) is export {
    canonical($target.Str) eq canonical(default-target().Str);
}

# 这个路径是文件系统根吗（`/`、`C:`、`C:/` 这类）？
#
# 抽成公开谓词而不是埋在 `flush` 的护栏里，是为了它**能被测试直接触发** ——
# 那个护栏是「全删」命令的保护，而根路径没法在测试里当参数构造出来（临时目录的
# canonical 形式不可能是根）。项目规矩：新增的分支必须有人为触发它的测试。
#
# 【盘符那一支必须在 normalize 之前判】`C:` / `C:\` 在 normalize 里会被
# `IO::Path.new(...).absolute` 当成**相对**路径，前缀上当前目录变成 `<cwd>/C:`
# （实测），于是永远匹配不到「根」。所以先在原始串上认一次盘符 ——
# 且**不按平台门控**：Linux 上把 `C:` 当根只是让护栏更严一点（没人会把前缀
# 命名成 `C:`），比漏掉一个真根安全得多。
sub is-fs-root(Str $p --> Bool) is export {
    my $raw = $p.trim.subst("\x5C", '/', :g);
    # 注意字符类要写 <[A..Za..z]> 而不是 <[a..Z]> —— 后者是**倒序区间**（a=97 > Z=90），
    # 编译期直接报 "Illegal reversed character range in regex: a..Z"。
    return True if $raw ~~ /^ <[A..Za..z]> ':' '/'? $/;
    my $c = canonical($p);
    return True if $c eq '' || $c eq '/';
    # 必须用 so(...) 把整个布尔表达式收成 Bool：`a || b || $x ~~ /re/` 里的
    # `~~` 求值出的是 **Match 对象**，而 `||` 返回的是「第一个真值」——
    # 于是子例程会返回 Match，撞上 `--> Bool` 当场类型检查失败。
    so $c ~~ /^ <[a..z]> ':' $/;
}

# 装完是否把 bin wrapper 也复制进「全局 site/bin」（<rakudo>/share/perl6/site/bin，
# zef 统一用的那个目录）。
#
# 策略：**默认前缀 → 是；自定义前缀 → 否。**
#   · 默认前缀下保持 zef 同款体验（装完命令立刻能敲，不必改 PATH）；
#   · 自定义前缀（一个项目一份环境）绝不该往全局 site/bin 写 —— 那里的文件
#     在 PATH 上、被整台机器共享，写进去等于「局部安装污染全局环境」；
#     而且多个前缀会互相覆盖，最后 PATH 上那份指向哪个前缀只看装包顺序。
#     （0.47.0 开发时就踩过：为复现 bug 用 --target=_h9repro/target 装了一次，
#      全局 raku-pm 立刻被指向那个临时目录。）
#   · 用 PATH 而不是全局 site/bin 时，前缀自己的 wrapper 会把前缀显式传给 CLI
#     （见 ShellTemplates），于是「敲哪个 wrapper 就在哪个前缀里干活」——
#     与 venv 的 <venv>/bin/python 同一个语义。
sub default-promote-bin(IO::Path $target --> Bool) is export {
    is-default-target($target);
}
