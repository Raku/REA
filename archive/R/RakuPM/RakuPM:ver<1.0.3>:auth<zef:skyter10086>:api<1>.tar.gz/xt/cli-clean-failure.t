use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 集成测试（0.38.1）：失败安装应只印【干净消息】、绝不打印内部调用栈。
# 放在 xt/：会触发 ⚠（native 缺失提示），且要跑真实 CLI 子进程，
# 不进 zef install 的纯净度守卫（t/ 必须安静）。
#
# 覆盖两件事：
#   1. 测试失败：前台只印「测试失败：…」友好消息，stderr 无
#      "in method/block …" / "at … line N" 的栈行（即用户看到的「崩溃信息」）；
#   2. 本地库缺失（:from<native> 静态声明）：在事务之外就放弃安装，stderr 含
#      「放弃安装」且同样无栈行；
#   3. 运行时 native 缺失（源码里 is native('...')，META6 不写 :from<native>，
#      典型如 Duckie 的 libduckdb）：在取到源码后、跑测试前挖出来查，同样
#      放弃安装 + 无栈行。这正是对 0.38.0「Duckie 装不上」行为的正确提前拦截。
#
# 之所以必须走真实 CLI 子进程：去栈的 CATCH 写在 bin/raku-pm.raku 的 sub MAIN 里，
# 进程内直接调 Client 方法绕过了它，测不到。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $raku = $*EXECUTABLE.absolute;
my $bin  = $*PROGRAM.parent.parent.add('bin').add('raku-pm.raku').absolute;

my $tmp = $*TMPDIR.add('rakupm-cleanfail-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub mk-dist(Str $name, :$depends, :$module-body, :@tests) {
    my $src = $tmp.add($name).mkdir;
    $src.add('lib').mkdir;
    my $body = $module-body.defined ?? $module-body !! "unit module $name;";
    $src.add('lib').add($name ~ '.rakumod').spurt($body);
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '0.1.0', auth => 'demo',
        provides => { $name => "lib/$name.rakumod" },
        depends  => ($depends ~~ Array ?? $depends !! ($depends ?? $depends !! {})),
    }, :sorted-keys));
    if @tests {
        $src.add('t').mkdir;
        for @tests -> $p {
            $src.add('t').add($p.key).spurt($p.value);
        }
    }
    $src
}

# 跑一次真实 CLI，返回 (exitcode, stderr)，stdout 单独吞掉。
sub run-cli(IO::Path $target, IO::Path $src, *@extra --> List) {
    my $p = run($raku, '-Ilib', $bin, 'install', $src.absolute,
                '--target=' ~ $target.absolute, '--no-build', |@extra,
                :out, :err);
    $p.out.slurp(:close);
    ($p.exitcode, $p.err.slurp(:close))
}

plan 11;

# ---------- 场景 1：测试失败 → 干净消息 + 无栈 ----------
my $srcFail = mk-dist('CleanFail',
    tests => [ '01.rakutest' => "use Test; plan 1; ok 0, 'boom';\n" ]);
my ($ec1, $err1) = run-cli($tmp.add('tFail'), $srcFail);
isnt $ec1, 0, '场景1：测试失败的安装以非零退出';
ok $err1.contains('测试失败'), '场景1：stderr 含友好「测试失败」消息';
ok $err1 !~~ / ^ \s* 'in ' \w+ /,
   '场景1：stderr 无 "in method/block …" 栈行';
ok $err1 !~~ / 'at ' .+ ' line ' \d+ /,
   '场景1：stderr 无 "at … line N" 栈行';

# ---------- 场景 2：本地库缺失 → 放弃安装 + 无栈 ----------
# 用一个【肯定不存在】的逻辑名（不在已知库表、且本机不可能有这个文件），
# 走通用命名规则必判为缺失 → 在事务外就 die「放弃安装」。
my $srcNat = mk-dist('CleanNat',
    depends => [ 'zzz-rakupm-absent-lib:from<native>' ]);
my ($ec2, $err2) = run-cli($tmp.add('tNat'), $srcNat, '--no-test');
isnt $ec2, 0, '场景2：本地库缺失以非零退出';
ok $err2.contains('放弃安装'), '场景2：stderr 含「放弃安装」提示';
ok $err2 !~~ / ^ \s* 'in ' \w+ /,
   '场景2：stderr 无 "in method/block …" 栈行';
ok $err2 !~~ / 'at ' .+ ' line ' \d+ /,
   '场景2：stderr 无 "at … line N" 栈行';

# ---------- 场景 3：运行时 native 缺失（is native('...')，无 :from<native>）----------
# 模拟 Duckie 的真实失败模式：模块在源码里 is native('zzz-rakupm-absent-lib')，
# META6 不写 :from<native>。静态检查看不到，必须靠源码扫描在跑测试前挖出来并
# 放弃安装。验证「0.38.0 装不上」的直觉在 0.38.1+ 也成立（且更早、更干净）。
my $srcRt = mk-dist('CleanRuntime',
    module-body => q:to/EOF/,
use NativeCall;
my sub duck_version(Str --> int64) is native('zzz-rakupm-absent-lib') { * }
sub duck-version is export { duck_version('x') }
EOF
    tests => [ '01.rakutest' => "use Test; use CleanRuntime; plan 1; ok 1;\n" ]);
my ($ec3, $err3) = run-cli($tmp.add('tRt'), $srcRt);
isnt $ec3, 0, '场景3：运行时 native 缺失以非零退出';
ok $err3.contains('放弃安装'), '场景3：运行时 native 缺失也含「放弃安装」';
ok $err3 !~~ / 'at ' .+ ' line ' \d+ /,
   '场景3：stderr 无 "at … line N" 栈行';
