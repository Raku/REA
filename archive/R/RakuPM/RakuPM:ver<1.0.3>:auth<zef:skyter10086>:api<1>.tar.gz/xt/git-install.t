use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Repository;
use RakuPM::Resolver;
use RakuPM::Client;

# 用 done-testing：用例按场景分块，写死数量容易对不上。

# 内存假仓库（与 t/resolve-provides.t 同一套路）
class MemRepo does RakuPM::Repository {
    has @.rows;
    method id(--> Str) { 'mem:git' }
    method find-providers(Str $m --> List) {
        self.rows.grep({ $m (elem) @(.<provides>) }).map(*<name>).unique.List
    }
    method all-distributions(--> List) { self.rows.map(*<name>).unique.List }
    method available-versions(Str $n --> List) {
        self.rows.grep(*<name> eq $n).map(*<version>).unique.List
    }
    method versions-providing(Str $m, Str $n --> List) {
        self.rows.grep({ .<name> eq $n && $m (elem) @(.<provides>) })
                 .map(*<version>).unique.List
    }
    method fetch-distribution(Str $n, Str $v --> RakuPM::Distribution) {
        my $row = self.rows.first({ .<name> eq $n && .<version> eq $v });
        die "假仓库里找不到 $n $v" unless $row;
        RakuPM::Distribution.new:
            :name($row<name>),
            :version($row<version>),
            :provides(@($row<provides>)),
            :depends(RakuPM::Distribution.normalize-dependencies($row<depends> // {}));
    }
    method source-dir-for(Str $, Str $ --> IO::Path) { IO::Path }
}

# 依赖图（故意做成菱形 + 共享叶子，能测出去重与拓扑序）：
#   App ─┬─> LibA ─> Deep
#        └─> LibB ─┬> Deep
#                  └> Helper
my @rows =
    %( name => 'App',    version => '1.0', provides => ['App'],
       depends => { 'LibA' => '*', 'LibB' => '*' } ),
    %( name => 'LibA',   version => '1.0', provides => ['LibA'],
       depends => { 'Deep' => '*' } ),
    %( name => 'LibB',   version => '1.0', provides => ['LibB'],
       depends => { 'Deep' => '*', 'Helper' => '*' } ),
    %( name => 'Deep',   version => '1.0', provides => ['Deep'],   depends => {} ),
    %( name => 'Helper', version => '1.0', provides => ['Helper'], depends => {} ),
;

sub client-with(@r) {
    RakuPM::Client.new(:target($*TMPDIR.add('rakupm-git-test-' ~ $*PID ~ '-' ~ now.floor)),
                       :repo-root('.'), :repos(@r))
}

my $c = client-with([MemRepo.new(:rows(@rows))]);

# ===== Resolver.resolve-all：多个根共享同一份选择表 =====
{
    my $r = RakuPM::Resolver.new(:repos([MemRepo.new(:rows(@rows))]));
    my @order = $r.resolve-all((
        %( module => 'LibA', constraint => '*' ),
        %( module => 'LibB', constraint => '*' ),
    ));
    # 两个根都依赖 Deep，Deep 只能装一份
    is @order.map(*.name).sort.join(','), 'Deep,Helper,LibA,LibB',
       'resolve-all：两个根的共享依赖（Deep）只装一份';
    is @order.grep(*.name eq 'Deep').elems, 1, 'Deep 不重复';

    my %pos = @order.map(*.name).antipairs;
    ok %pos<Deep> < %pos<LibA> && %pos<Deep> < %pos<LibB>,
       'resolve-all：Deep 排在 LibA / LibB 之前';
}

# 跨根的版本冲突必须能检出（逐个 resolve 就检不出来）
{
    my @conflict =
        %( name => 'Root', version => '1.0', provides => ['Root'],
           depends => { 'C' => '>= 2.0' } ),
        %( name => 'Other', version => '1.0', provides => ['Other'],
           depends => { 'C' => '< 2.0' } ),
        %( name => 'C', version => '2.0', provides => ['C'], depends => {} ),
        %( name => 'C', version => '1.5', provides => ['C'], depends => {} ),
    ;
    my $r = RakuPM::Resolver.new(:repos([MemRepo.new(:rows(@conflict))]));
    my $msg = '';
    try { $r.resolve-all((%( module => 'Root', constraint => '*' ),
                          %( module => 'Other', constraint => '*' ))) }
    $msg = $!.Str if $!;
    ok $msg.contains('依赖冲突'), 'resolve-all：跨根的版本冲突被检出';
}

# ===== Client.resolve-deps-of：git 包的依赖闭包 =====

# 1) 递归到两层深（App → LibA/LibB → Deep/Helper）
my $git1 = RakuPM::Distribution.new(
    :name<MyGitApp>, :version<1.0>, :provides(['MyGitApp']),
    :depends({ 'App' => '*' }));
is $c.resolve-deps-of($git1).map(*.name).sort.join(','),
   'App,Deep,Helper,LibA,LibB',
   'git 包依赖被递归解析（两层深，菱形依赖图）';

# 2) 自底向上顺序正确：Deep 与 Helper 先于 LibA/LibB，后者先于 App
{
    my @names = $c.resolve-deps-of($git1).map(*.name);
    my %pos = @names.antipairs;
    ok %pos<Deep>   < %pos<LibA>, 'Deep 先于 LibA';
    ok %pos<Deep>   < %pos<LibB>, 'Deep 先于 LibB';
    ok %pos<Helper> < %pos<LibB>, 'Helper 先于 LibB';
    ok %pos<LibA>   < %pos<App>,  'LibA 先于 App';
    ok %pos<LibB>   < %pos<App>,  'LibB 先于 App';
    is @names.elems, @names.unique.elems, '依赖闭包里没有重复发行版';
}

# 3) 自己提供的模块不算外部依赖（有些包会把自己提供的模块也写进 depends）
my $git2 = RakuPM::Distribution.new(
    :name<HasHelper>, :version<1.0>, :provides(['HasHelper', 'Helper']),
    :depends({ 'Helper' => '*' }));
is $c.resolve-deps-of($git2).elems, 0,
   'git 包自己提供的模块不会被当成外部依赖';

# 4) 目标包提供的模块，优先于依赖树里另一个提供同名模块的发行版。
#    用户明确指定要装 git 上这一份，不该再装一份仓库里的 Helper。
my $git3 = RakuPM::Distribution.new(
    :name<GitHelper>, :version<1.0>, :provides(['GitHelper', 'Helper']),
    :depends({ 'App' => '*' }));
my @deps3 = $c.resolve-deps-of($git3);
ok @deps3.map(*.name).none eq 'Helper',
   '目标包提供的模块优先：仓库里的 Helper 不再装';
is @deps3.map(*.name).sort.join(','), 'App,Deep,LibA,LibB',
   '其余依赖照常解析';

# 5) 装不上的依赖报「所有仓库」错误
my $git4 = RakuPM::Distribution.new(
    :name<NeedsGhost>, :version<1.0>, :provides(['NeedsGhost']),
    :depends({ 'Ghost::Module' => '*' }));
{
    my $msg = '';
    try { $c.resolve-deps-of($git4) }
    $msg = $!.Str if $!;
    ok $msg.contains("在所有已配置的仓库里都找不到模块 'Ghost::Module'"),
       'git 包装不上的依赖报「所有已配置的仓库」';
}

# 6) 没有依赖的 git 包返回空闭包
my $git5 = RakuPM::Distribution.new(
    :name<Solo>, :version<1.0>, :provides(['Solo']), :depends({}));
is $c.resolve-deps-of($git5).elems, 0, '无依赖的 git 包返回空闭包';

# 7) 本地库依赖不参与 raku 依赖解析（:from<native> 已在 Distribution 层摘掉）
my $git6 = RakuPM::Distribution.new(
    :name<NeedsNative>, :version<1.0>, :provides(['NeedsNative']),
    :depends({ 'App' => '*' }), :native-libs(['sqlite3']));
is $c.resolve-deps-of($git6).map(*.name).sort.join(','),
   'App,Deep,Helper,LibA,LibB',
   'native 依赖不混进 raku 依赖解析';

done-testing;
