use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository;

# self-upgrade / self-remove 命令的测试。
#
# 设计上这两个命令最常踩的坑是：
#   · self-upgrade 不能依赖「自家账本有没有记录 RakuPM」（zef 装的就不在账本里），
#     也不能依赖「是否把 RakuPM 发布到了生态索引」（目前没发布，去仓库找必死）；
#     正确做法是统一从 git 远端拉源码重装（默认 gitee 上游，--from 可覆盖）。
#     【0.83.0 起】只剩两条路：本地源码目录（--from-dir）与 git 远端（--from/默认）；
#     原先「当前在 git 仓库里就就地 pull 当前仓库」那条已删，故不再有对应用例。
#   · self-remove 误删 / 漏删 —— 所以 --dry 必须真的只报告不落地。
#
# 为了离线、确定性：
#   · self-upgrade 用【临时本地 git 仓库】模拟远端（git clone 本地路径，无需网络），
#     必要时置 RAKUPM_NO_GIT 环境变量来测「缺 git」分支；
#   · self-remove 走 CLI、用临时 RAKUPM_TARGET 并种入假文件，全程离线。

# 临时目录 + 进程级清理
my $base = $*TMPDIR.add('rakupm-selfmgmt-' ~ $*PID ~ '-' ~ now.floor);
$base.mkdir;
END {
    try {
        # 递归删临时根（Raku 没有 rmtree，手动来）
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

# =========================================================================
# 一、self-upgrade —— Client 单测（注入假仓库，离线）
# =========================================================================

# 让"需要 git"的分支在无 git 环境下也能确定性报错（不真的去连网络）：
# 置 RAKUPM_NO_GIT 环境变量即可（Client 的 !has-git 认这个钩子）。
# 远端路径（--from 给定）：进入远端升级分支；无 git 时明确报错（证明走的是远端）
{
    %*ENV<RAKUPM_NO_GIT> = '1';
    LEAVE %*ENV<RAKUPM_NO_GIT>:delete;
    my $c = RakuPM::Client.new(:target($base.add('rf-tgt1')));
    my $died = False;
    try {
        $c.self-upgrade(:from('https://example.com/x/raku-pm.git'), :current('0.23.0'));
        CATCH { default { $died = True; ok .Str.contains('需要 git'),
                          'self-upgrade --from：进入远端分支（无 git → 明确报错）'; } }
    }
    ok $died, 'self-upgrade --from：无 git 时抛错';
}

# 2) 没给 --from / --from-dir → 走默认远端（gitee）；无 git → 明确报错
#    （证明默认也走「远端」这条需要 git 的路，而不是误报「找不到 RakuPM」）
{
    %*ENV<RAKUPM_NO_GIT> = '1';
    LEAVE %*ENV<RAKUPM_NO_GIT>:delete;
    my $tmp   = $base.add('up-nogit-tgt'); $tmp.mkdir;
    my $c     = RakuPM::Client.new(:target($tmp));
    my $died  = False;
    try {
        $c.self-upgrade();
        CATCH { default { $died = True; ok .Str.contains('需要 git'),
                          'self-upgrade: 无 git 时明确报错（需要 git）'; } }
    }
    ok $died, 'self-upgrade: 默认远端路径 + 无 git → 抛错';
}

# =========================================================================
# 二、self-remove —— CLI 测试（临时 target，种入假文件，离线）
# =========================================================================

my $bin = $*PROGRAM.parent(2).add('bin').add('raku-pm.raku');
ok $bin.e, 'bin/raku-pm.raku 存在';

sub run-self($args, $target --> Proc) {
    my %env = %( %*ENV, RAKUPM_TARGET => $target.absolute );
    run('raku', $bin.absolute.Str, |$args, :out, :err, :env(%env));
}

# 4) self-remove --dry 在空 target 上：退出 0、报 dry-run、什么都没删
{
    my $tmp = $base.add('rm-dry-empty');
    $tmp.mkdir;
    my $proc = run-self(['self-remove', '--dry'], $tmp);
    is $proc.exitcode, 0, 'self-remove --dry（空 target）退出码 0';
    my $out = $proc.out.slurp(:close);
    ok $out.contains('未实际删除'), 'self-remove --dry：明确提示未实际删除';
    ok $tmp.d, 'self-remove --dry：target 目录仍存在（未删）';
}

# 5) self-remove --dry 不删除已种入的 wrapper 与 store 快照
{
    my $tmp = $base.add('rm-dry-planted');
    $tmp.mkdir;
    my $bin-dir = $tmp.add('bin');  $bin-dir.mkdir;
    my $wrap    = $bin-dir.add('raku-pm');  $wrap.spurt('# wrapper');
    my $snap    = $tmp.add('store').add('RakuPM').add('0.0.1');
    $snap.mkdir;  $snap.add('x.txt').spurt('hi');

    my $proc = run-self(['self-remove', '--dry'], $tmp);
    is $proc.exitcode, 0, 'self-remove --dry（已种入文件）退出码 0';
    ok $wrap.e,  'self-remove --dry：wrapper 未被删除';
    ok $snap.e,  'self-remove --dry：store 快照未被删除';
    ok $proc.out.slurp(:close).contains('未实际删除'),
        'self-remove --dry：输出含 dry-run 提示';
}

# 6) self-remove 真实运行：删掉 wrapper 与 store 快照，退出 0
{
    my $tmp = $base.add('rm-real');
    $tmp.mkdir;
    my $bin-dir = $tmp.add('bin');  $bin-dir.mkdir;
    my $wrap    = $bin-dir.add('raku-pm');  $wrap.spurt('# wrapper');
    my $wrap-bat= $bin-dir.add('raku-pm.bat'); $wrap-bat.spurt('@echo');
    my $snap    = $tmp.add('store').add('RakuPM').add('0.0.1');
    $snap.mkdir;  $snap.add('x.txt').spurt('hi');

    my $proc = run-self(['self-remove'], $tmp);
    is $proc.exitcode, 0, 'self-remove（真实）退出码 0';
    ok !$wrap.e,    'self-remove：wrapper raku-pm 已删除';
    ok !$wrap-bat.e,'self-remove：wrapper raku-pm.bat 已删除';
    ok !$snap.e && !$snap.parent.d, 'self-remove：store/RakuPM 快照已删除';
    my $out = $proc.out.slurp(:close);
    ok $out.contains('删除 wrapper'), 'self-remove：输出含"删除 wrapper"';
    ok $out.contains('已卸载 raku-pm'), 'self-remove：输出含"已卸载 raku-pm"';
}

done-testing;
