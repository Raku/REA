use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use JSON::Fast;

# 回归测试：self-upgrade 的远端路径走 install-from-git，旧实现会把版本
# 强制改写成 0.0.0-<git-sha>，导致 `raku-pm version` 在 Windows 的
# target/bin wrapper 下读到 0.0.0-*。修复：self-upgrade 现在传
# :preserve-version，用 META6.json 里的真版本（如 0.24.0）。
#
# 这里直接验证该机制：install-from-git 带 / 不带 :preserve-version 时，
# 装进账本的版本分别应是「真版本」与「0.0.0-* 伪版本」。
#
# 离线、确定性：用【本地 git 仓库】模拟远端（git clone 本地路径，无需网络）。

# git 不可用就整体跳过
my $has-git = ?(try { my $p = run('git', '--version', :out); $p.exitcode == 0 });
if !$has-git {
    plan 1;
    skip-rest 'git 不可用，跳过 git 版本保留测试';
    exit 0;
}
plan 3;

my $base = $*TMPDIR.add('rakupm-gitver-' ~ $*PID ~ '-' ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

# 造一个本地 git 仓库（模拟远端），里面放一个最小发行版
my $repo = $base.add('repo');
$repo.mkdir;
$repo.add('lib').mkdir;
$repo.add('lib/TestGitDist.rakumod').spurt("unit module TestGitDist;\n");
$repo.add('META6.json').spurt(to-json({
    name        => 'TestGitDist',
    version     => '9.9.9',
    auth        => 'test:me',
    description => 'regression',
    provides    => { TestGitDist => 'lib/TestGitDist.rakumod' },
}, :sorted-keys));

sub git(*@a) {
    run('git', '--git-dir=' ~ $repo.add('.git').absolute,
              '--work-tree=' ~ $repo.absolute, |@a, :out, :err);
}
git('init');
# 设本地身份，避免 WSL/CI 等"裸 git 环境"里没配全局 user.email 导致 commit 失败。
# （不污染全局配置；只写进这个临时仓库的 .git/config。）
git('config', 'user.email', 'test@example.com');
git('config', 'user.name',  'raku-pm-test');
git('add', '-A');
my $commit = git('commit', '-m', 'init');
unless $commit.exitcode == 0 {
    diag "git commit 失败（exit={$commit.exitcode}）：{$commit.err.slurp}";
    skip-rest '无法在临时仓库里 git commit（环境问题），跳过 git 版本保留测试';
    exit 0;
}
ok True, '本地 git 仓库提交成功';

# 安装路径用相对路径 'repo'，避免在 Windows 上 cache key 带冒号导致失败
temp $*CWD = $base;

# 1) self-upgrade 远端分支用的机制：install-from-git :preserve-version
my $t1 = $base.add('t1');
my $cl1 = RakuPM::Client.new(:repo-root($base.absolute), :target($t1),
                             :promote-bin(False));
$cl1.install-from-git('repo', :preserve-version, :no-test, :no-build,
                      :no-native-check, :force);
my @led1 = from-json($t1.add('installed.json').slurp);
my $v1 = (@led1.first({ .<name> eq 'TestGitDist' }))<versions>
            .grep(*.chars).unique.sort.tail;
is $v1, '9.9.9',
   'install-from-git :preserve-version 保留真版本（修复 self-upgrade 0.0.0  bug）';

# 2) 对照：不带 preserve-version 应仍是 0.0.0-* 伪版本（常规 git 安装约定不变）
my $t2 = $base.add('t2');
my $cl2 = RakuPM::Client.new(:repo-root($base.absolute), :target($t2),
                             :promote-bin(False));
$cl2.install-from-git('repo', :no-test, :no-build, :no-native-check, :force);
my @led2 = from-json($t2.add('installed.json').slurp);
my $v2 = (@led2.first({ .<name> eq 'TestGitDist' }))<versions>
            .grep(*.chars).unique.sort.tail;
ok $v2.starts-with('0.0.0-'),
   "不带 preserve-version 仍是 0.0.0-* 伪版本（约定不变）: $v2";
