use Test;
use JSON::Fast;
use lib 'lib';
use RakuPM::Client;
use RakuPM::Repository::Local;
use RakuPM::Fs;

# ============================================================================
# golden e2e：verify --fix（命令层跨阶段串联）
#
# 【为何现有 xt / t 覆盖不到】
#   · t/verify-consistency.t 在【Installer 引擎层】直接调
#     `consistency-issues` / `adopt-from-cur`，验证「引擎能算出问题、能补记」。
#   · 但它从不走【Client 命令层】的 `verify-all(:fix)` —— 也就是 CLI
#     `raku-pm verify --fix` 真正调用的那条路径。verify-all 自己还有
#     `:content-only` 短路、`--fix` 才调 adopt-from-cur、无 --fix 只报不修
#     这三段分支，引擎测试一个都没覆盖。
#   · 单点都绿 ≠ 命令层绿：万一哪天 verify-all 把 `:$fix` 接错位、或
#     adopt-from-cur 的返回值没被消费，引擎测试仍全绿，CLI 却悄悄不修。
#
# 本测试走【Client 命令层】（与 CLI 同一套 verify-all），制造「CUR 有、账本被
# 清空」的真实半截状态，证明：
#   1) 刚装完一致性为零；
#   2) `verify-all(:fix)` 真的把账本自动补记回来（命令层 --fix 生效）；
#   3) `verify-all()`（无 --fix）只报不动（账本仍是空的）。
# ============================================================================

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-golden-vfy-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $repo-root = $tmp.add('repo'); $repo-root.mkdir;
my $target    = $tmp.add('tgt');  $target.mkdir;
$target.add('repositories.json').spurt(to-json({ repos => [] }, :sorted-keys));

# 一个本地包 Plain 1.0（verify 不需要版本常量，模块极简即可）。
sub mk-pkg(Str $ver --> IO::Path) {
    my $d = $repo-root.add("Plain-$ver");
    $d.mkdir; $d.add('lib').mkdir;
    $d.add('lib').add('Plain.rakumod').spurt("unit module Plain;\n");
    $d.add('META6.json').spurt(to-json({
        name => 'Plain', version => $ver, auth => 'test:me', api => '1',
        provides => { Plain => "lib/Plain.rakumod" }, depends => {},
    }, :sorted-keys));
    $d;
}
mk-pkg('1.0');

my $client  = RakuPM::Client.new(
    :target($target),
    :repos([ RakuPM::Repository::Local.new(:root($repo-root)) ]),
);
# 账本是 <target>/installed.json —— 与 Installer 内部写盘位置一致。
my $ledger = $target.add('installed.json');

# ---------- 1) 干净安装：一致性零问题 ----------
$client.install('Plain', '1.0');
is $client.installer.installed-versions('Plain').join(','), '1.0',
   'install Plain 1.0 → 账本记了 1.0';
is $client.installer.consistency-issues.elems, 0,
   '刚装完：没有任何不一致';

# ---------- 2) 命令级 verify --fix：CUR 有、账本被清空 → 自动补记 ----------
$ledger.spurt('[]');                       # 清空账本，制造 missing-in-ledger
ok $client.installer.consistency-issues.grep({ .<kind> eq 'missing-in-ledger' }).elems > 0,
   '清空账本后：引擎报出 missing-in-ledger';
$client.verify-all(:fix);                  # 走命令层 --fix（adopt-from-cur）
is $client.installer.installed-versions('Plain').join(','), '1.0',
   'verify --fix → 账本被自动补记回 Plain 1.0';
is $client.installer.consistency-issues.elems, 0,
   'verify --fix → 补记后没有任何不一致';
# （账本确实写回，已由上面「installed-versions 重新读出 1.0」间接证明：
#  installed-versions 只读 <target>/installed.json，未补记则必为 ''）

# ---------- 3) 命令级 verify（无 --fix）：只报不修 ----------
$ledger.spurt('[]');                       # 再清空
$client.verify-all();                      # 无 --fix
ok $client.installer.consistency-issues.grep({ .<kind> eq 'missing-in-ledger' }).elems > 0,
   '无 --fix 仍报出 missing-in-ledger';
is $client.installer.installed-versions('Plain').join(','), '',
   '无 --fix：账本仍是空的（没有自动补记）';

done-testing;
