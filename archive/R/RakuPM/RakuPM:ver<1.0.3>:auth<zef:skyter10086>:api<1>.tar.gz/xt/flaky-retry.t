use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 回归：上游 flaky 的测试会【偶发】失败（flaky test），不该让用户为一个
# 概率装不上包。（0.80.0 起测试串行，此机制改为纯粹兜「上游 flaky」，与并发无关。）
#
# 上游真有这种情况 —— 实测 Concurrent::Stack 1.3 的 stress.rakutest
# 连跑 10 次挂 3 次（3 个线程各 push 50000 再各 pop，报
# "Cannot pop from an empty concurrent stack"，是上游 push 的竞态丢数据）。
# 那是上游的 bug，不是 raku-pm 的，但安装流程该扛住：失败重试一次。
#
# 这里用一个「第一次失败、第二次成功」的测试文件精确模拟 flaky ——
# 靠环境变量传进来的标记文件记录"跑过没"。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-flaky-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 造一个测试文件：用外部传入的标记文件决定这次成功还是失败
sub make-pkg(Str $name, Str $test-body) {
    my $src = $tmp.add($name).mkdir;
    $src.add('lib').mkdir.add($name ~ '.rakumod').spurt("unit module $name;");
    $src.add('t').mkdir.add('probe.rakutest').spurt($test-body);
    $src.add('META6.json').spurt(to-json({
        name      => $name,
        version   => '1.0',
        auth      => 'demo',
        provides  => { $name => "lib/$name.rakumod" },
        depends   => {},
    }, :sorted-keys));
    $src
}

# 测试文件模板：$mode = flaky（首次失败后续成功） / always-fail（永远失败）
sub test-body(Str $mode --> Str) {
    'use Test;' ~ "\n" ~
    'my $m = %*ENV<FLAKY_MARKER> // "";' ~ "\n" ~
    'my $first = !$m.IO.e;' ~ "\n" ~
    # 注意 `}` 后面必须有分号：少了它，下一行的函数调用（flunk ...）会被当成
    # 这一行的延续，报 "Two terms in a row across lines"。
    'if $first { $m.IO.spurt("x") };' ~ "\n" ~
    (
        $mode eq 'flaky'
        ?? 'if $first { flunk "first run fails on purpose" } else { ok True, "retry passes" }'
        !! 'flunk "always fails"'
    ) ~ "\n" ~
    'done-testing;' ~ "\n"
}

my $client = RakuPM::Client.new(
    :target($tmp.add('target')),
    :repos([RakuPM::Repository::Local.new(:root($tmp.add('repo').mkdir))]),
);

# ===== 1. flaky：第一次失败、重试通过 → 安装照常完成 =====
{
    my $marker = $tmp.add('marker-flaky');
    %*ENV<FLAKY_MARKER> = $marker.absolute;
    LEAVE { %*ENV<FLAKY_MARKER>:delete }

    my $src = make-pkg('FlakyPkg', test-body('flaky'));
    lives-ok { $client.install-from-dir($src) },
       'flaky 用例失败一次后重试通过，安装不中断';
    is $client.installer.installed-version('FlakyPkg'), '1.0',
       '包确实装上了（重试通过就算装成功）';
}

# ===== 2. 真失败：重试仍失败 → 必须照常报错 =====
# 这条更重要 —— 重试不能变成"掩盖真问题"的万能挡箭牌。
{
    my $marker = $tmp.add('marker-always');
    %*ENV<FLAKY_MARKER> = $marker.absolute;
    LEAVE { %*ENV<FLAKY_MARKER>:delete }

    my $src = make-pkg('BrokenPkg', test-body('always-fail'));
    my $err = '';
    try { $client.install-from-dir($src) };
    $err = $!.Str if $!;
    ok $err.contains('测试失败'), '一直失败的用例：重试后仍照常报错';
    nok $client.installer.list-installed.first({ $_<name> eq 'BrokenPkg' }).defined,
       '失败的包不会被记进账本';
}

done-testing;
