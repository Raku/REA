use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Repository::Local;
use RakuPM::Client;

# 跳过规则的回归测试（用户报的痛点：zef 装过的 / store 里已有的包，
# raku-pm 还要再下载一遍、再跑一遍测试 —— 没必要）。
#   1. 已安装（自己的账本 或 zef 的 Installation 仓库）→ 整个跳过；
#   2. 已在 store → 跳过构建与测试，直接激活；
#   3. store 老格式（缺标准 META6.json）→ 自动重新入库（修截图里的崩溃）；
#   4. --force 全部重跑。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-skip-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# ---------- 1. Store.needs-readmit ----------
{
    my $src = $tmp.add('ra-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('RA.rakumod').spurt('unit module RA;');
    $src.add('META6.json').spurt(to-json({
        name => 'RA', version => '1.0', auth => 'demo',
        provides => { RA => 'lib/RA.rakumod' }, depends => {},
    }, :sorted-keys));
    my $store = RakuPM::Store.new(:root($tmp.add('ra-store')));
    my $d = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    $store.put($d, $src);
    nok $store.needs-readmit('RA', '1.0'), '新入库的条目不需要重新入库';
    # 模拟 0.2.x 之前的老条目：只有 META.json，没有标准 META6.json
    $store.path-for('RA', '1.0').add('META6.json').unlink;
    ok $store.needs-readmit('RA', '1.0'), '缺 META6.json 的老条目被识别（截图里的崩溃源头）';
}

# ---------- 2. is-installed：自己的账本 + zef 侧仓库链 ----------
{
    my $client = RakuPM::Client.new(:target($tmp.add('client-target')));
    my $src = $tmp.add('probe-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('SkipProbe.rakumod').spurt('unit module SkipProbe;');
    $src.add('META6.json').spurt(to-json({
        name => 'SkipProbe', version => '2.0', auth => 'demo',
        provides => { SkipProbe => 'lib/SkipProbe.rakumod' }, depends => {},
    }, :sorted-keys));
    my $d = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));

    nok $client.is-installed($d), '没装过 → False';

    $client.store.put($d, $src);
    $client.installer.install($d);
    ok $client.is-installed($d), 'raku-pm 自己装的（账本命中）';
    my $d-other = RakuPM::Distribution.new(:name<SkipProbe>, :version<9.9>, :depends({}));
    nok $client.is-installed($d-other), '版本不同不算已装（多版本语义）';

    # 模拟 zef 装的包：独立的 Installation 仓库（zef 的 site/home/vendor 就是这种，
    # 生产路径从 $*REPO.repo-chain 里读到它们；测试注入伪造的链）
    my $zsrc = $tmp.add('zeflike-src').mkdir;
    $zsrc.add('lib').mkdir;
    $zsrc.add('lib').add('ZefSide.rakumod').spurt('unit module ZefSide;');
    $zsrc.add('META6.json').spurt(to-json({
        name => 'ZefSide', version => '0.3', auth => 'zef:someone',
        provides => { ZefSide => 'lib/ZefSide.rakumod' }, depends => {},
    }, :sorted-keys));
    my $fakesite = $tmp.add('fakesite');
    my $zrepo = CompUnit::Repository::Installation.new(prefix => $fakesite.absolute);
    $zrepo.install(Distribution::Path.new($zsrc, :meta-file($zsrc.add('META6.json'))));

    my $zd = RakuPM::Distribution.from-meta6-file($zsrc.add('META6.json'));
    ok $client.is-installed($zd, :chain([$zrepo])),
       'zef 侧 Installation 仓库里的包被识别为已装';
    nok $client.is-installed($zd), '不注入链时（默认链上没有它）不误报';
}

# ---------- 3. Client 级：第二次安装跳过测试；--force 重跑 ----------
{
    my $marker = $tmp.add('test-run.counter');
    $marker.spurt('');
    my $src = $tmp.add('skipme-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('SkipMe.rakumod').spurt('unit module SkipMe;');
    # 测试每次执行都往计数文件追加一行 —— 用行数断言「测试跑了几遍」
    $src.add('t').mkdir;
    $src.add('META6.json').spurt(to-json({
        name => 'SkipMe', version => '1.0', auth => 'demo',
        provides => { SkipMe => 'lib/SkipMe.rakumod' }, depends => {},
    }, :sorted-keys));

    my $client = RakuPM::Client.new(
        :target($tmp.add('client-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]),
    );

    # 测试文件里要写死 marker 路径 —— Windows 的反斜杠在 Raku 双引号字符串里
    # 会被当转义序列（\U 直接编译错），统一换成正斜杠（Windows 的 IO 层都认）
    my $marker-fwd = $marker.absolute.comb
        .map({ $_ eq "\x5C" ?? '/' !! $_ }).join('');
    $src.add('t').add('01-count.rakutest').spurt(
        '"' ~ $marker-fwd ~ '".IO.open(:a).put;'  ~ "\n" ~
        'use Test; pass "counter";' ~ "\n");

    $client.install-from-dir($src, :no-build);
    is $marker.lines.elems, 1, '第一次安装：测试跑了 1 遍';

    $client.install-from-dir($src, :no-build);
    is $marker.lines.elems, 1, '第二次安装：已安装 → 整个跳过，测试没有再跑';

    $client.install-from-dir($src, :no-build, :force);
    is $marker.lines.elems, 2, '--force：测试强制重跑';

    # 老格式重新入库：卸载 + 删掉 store 的 META6.json，再装应自动重新入库
    $client.uninstall('SkipMe', :keep-store);  # 测试要验证「老格式重新入库」，store 必须留着
    $client.store.path-for('SkipMe', '1.0').add('META6.json').unlink;
    ok $client.store.needs-readmit('SkipMe', '1.0'), '构造出老格式 store 条目';
    $client.install-from-dir($src, :no-build);
    ok $client.store.path-for('SkipMe', '1.0').add('META6.json').e,
       '重新入库后 META6.json 回来了（截图里的崩溃不再发生）';
    ok $client.installer.installed-versions('SkipMe').elems, '且重新激活成功';
    is $marker.lines.elems, 2, '重新入库不重跑测试（老条目入库时已验过，只有元数据格式过时）';
}

# ---------- 5. 资源声明过时的老条目（0.4.0 之前入库）----------
# 0.4.0 才有 resources 支持：之前入库的条目 META6.json 存在但 resources 是空列表，
# 激活后 %?RESOURCES<key> 查不到，模块一 .open 就崩（Data::Generators 的真实案例）。
{
    my $src = $tmp.add('ra2-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('RA2.rakumod').spurt('unit module RA2;');
    $src.add('resources').mkdir;
    $src.add('resources').add('data.csv').spurt('a,b');
    $src.add('META6.json').spurt(to-json({
        name => 'RA2', version => '1.0', auth => 'demo',
        provides => { RA2 => 'lib/RA2.rakumod' },
        resources => ['data.csv'], depends => {},
    }, :sorted-keys));
    my $dist = RakuPM::Distribution.from-meta6-file($src.add('META6.json'));
    my $store = RakuPM::Store.new(:root($tmp.add('ra2-store')));
    $store.put($dist, $src);
    nok $store.needs-readmit('RA2', '1.0', :$dist), '新条目（带资源）不需要重新入库';

    # 模拟 0.4.0 之前的入库结果：META6.json 在，但 resources 是空列表
    my $m6 = $store.path-for('RA2', '1.0').add('META6.json');
    my %m = from-json($m6.slurp);
    %m<resources> = [];
    $m6.spurt(to-json(%m, :sorted-keys));

    ok $store.needs-readmit('RA2', '1.0', :$dist),
       '声明了资源但存的是空列表 → 识别为过时（Data::Generators 案例）';
    nok $store.needs-readmit('RA2', '1.0'),
       '不传 dist 时退回第一类检查（向后兼容）';
}

# ---------- 6. Client 级：过时资源声明的条目重装时自动重新入库 ----------
{
    my $src = $tmp.add('resmod-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('ResMod.rakumod').spurt(
        'unit module ResMod;' ~ "\n" ~
        'sub csv() is export { %?RESOURCES<data.csv>.slurp }' ~ "\n");
    $src.add('resources').mkdir;
    $src.add('resources').add('data.csv').spurt('x,y');
    $src.add('META6.json').spurt(to-json({
        name => 'ResMod', version => '1.0', auth => 'demo',
        provides => { ResMod => 'lib/ResMod.rakumod' },
        resources => ['data.csv'], depends => {},
    }, :sorted-keys));

    my $client = RakuPM::Client.new(
        :target($tmp.add('client-target-res')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]),
    );
    $client.install-from-dir($src, :no-test);

    # 模拟老条目：卸载 + 篡改 store 的 META6.json 清空 resources
    $client.uninstall('ResMod', :keep-store);  # 测试要验证「重装重新入库」，store 必须留着
    my $m6p = $client.store.path-for('ResMod', '1.0').add('META6.json');
    my %m = from-json($m6p.slurp);
    %m<resources> = [];
    $m6p.spurt(to-json(%m, :sorted-keys));

    $client.install-from-dir($src, :no-test);
    my %m6 = from-json($m6p.slurp);
    ok %m6<resources>.first(* eq 'data.csv'), '重装时自动重新入库，资源声明恢复';

    my $proc = run('raku', '-I', $client.installer.raku-lib-spec, '-e',
                   'use ResMod; print csv()', :out, :err);
    is $proc.out.slurp(:close), 'x,y', '装完 %?RESOURCES 可读（截图里的崩溃不再发生）';
}

# ---------- 8. 依赖已被已装包满足 → 不要求仓库里有（DB-Source/Grammar-DSN 案例）----------
# 自装的本地包不在任何生态索引里；此前另一个本地包依赖它时，
# 解析直接死「找不到模块」。对齐 zef 的「只装缺失的依赖」。
{
    my $client = RakuPM::Client.new(
        :target($tmp.add('client-target-dep')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo3').mkdir))]),
    );

    # 先自装 LibPkg 0.5（生态里没有的本地包）
    my $lib = $tmp.add('libpkg-src').mkdir;
    $lib.add('lib').mkdir;
    $lib.add('lib').add('LibPkg.rakumod').spurt('unit module LibPkg;');
    $lib.add('META6.json').spurt(to-json({
        name => 'LibPkg', version => '0.5', auth => 'demo',
        provides => { LibPkg => 'lib/LibPkg.rakumod' }, depends => {},
    }, :sorted-keys));
    $client.install-from-dir($lib, :no-test);
    my $entry = $client.installer.list-installed.first({ $_<name> eq 'LibPkg' });
    ok $entry<source>.defined && $entry<source>.contains('libpkg-src'),
       '自装包在账本里记录了来源目录';

    # App2 依赖 LibPkg（约束 *）—— 空仓库里没有它，但已装的就该算数
    my $app = $tmp.add('app2-src').mkdir;
    $app.add('lib').mkdir;
    $app.add('lib').add('App2.rakumod').spurt('unit module App2;');
    $app.add('META6.json').spurt(to-json({
        name => 'App2', version => '1.0', auth => 'demo',
        provides => { App2 => 'lib/App2.rakumod' },
        depends => ['LibPkg'],
    }, :sorted-keys));
    lives-ok { $client.install-from-dir($app, :no-test) },
        '依赖已被已装包满足 → 不再要求仓库里有';
    ok $client.installer.installed-versions('App2').elems, 'App2 安装成功';

    # 约束不满足（要 9.9，装的是 0.5）→ 照常要求仓库，解析失败
    my $app3 = $tmp.add('app3-src').mkdir;
    $app3.add('lib').mkdir;
    $app3.add('lib').add('App3.rakumod').spurt('unit module App3;');
    $app3.add('META6.json').spurt(to-json({
        name => 'App3', version => '1.0', auth => 'demo',
        provides => { App3 => 'lib/App3.rakumod' },
        depends => ['LibPkg:ver<9.9>'],
    }, :sorted-keys));
    dies-ok { $client.install-from-dir($app3, :no-test) },
        '约束不满足时仍要求仓库里有';

    # install <已装模块> → 早退跳过（空仓库下此前会先死在解析）
    lives-ok { $client.install('LibPkg') }, 'install 已装模块直接跳过（zef 同款）';

    # ---------- 8b. 发行版名依赖（fez 案例）----------
    # 已装的发行版名叫 tooling、provides 里只有大写 Tooling，
    # 依赖声明是小写的 tooling:ver<38+> —— 按【发行版名】也应判定满足。
    # （真实案例：App::Mi6 依赖 fez:ver<38+>，fez 的 provides 里只有 Fez。）
    my $tool = $tmp.add('tooling-src').mkdir;
    $tool.add('lib').mkdir;
    $tool.add('lib').add('Tooling.rakumod').spurt('unit module Tooling;');
    $tool.add('META6.json').spurt(to-json({
        name => 'tooling', version => '43', auth => 'demo',
        provides => { Tooling => 'lib/Tooling.rakumod' }, depends => {},
    }, :sorted-keys));
    $client.install-from-dir($tool, :no-test);

    my $app4 = $tmp.add('app4-src').mkdir;
    $app4.add('lib').mkdir;
    $app4.add('lib').add('App4.rakumod').spurt('unit module App4;');
    $app4.add('META6.json').spurt(to-json({
        name => 'App4', version => '1.0', auth => 'demo',
        provides => { App4 => 'lib/App4.rakumod' },
        depends => ['tooling:ver<38+>'],
    }, :sorted-keys));
    lives-ok { $client.install-from-dir($app4, :no-test) },
        '发行版名依赖（provides 无同名模块）按已装判定满足';
    ok $client.installer.installed-versions('App4').elems, 'App4 安装成功';

    # ---------- 9. 对账自愈：site 里有、账本缺记 → installed 时补记 ----------
    # 用户实测：raku-pm 自己装的包 installed 里看不到 —— 历史版本格式差异
    # 或安装中断都可能造成 site 与账本不一致。自愈后不再丢包。
    my $json-path = $tmp.add('client-target-dep').add('installed.json');
    my @kept = from-json($json-path.slurp).grep({ $_<name> ne 'LibPkg' });
    $json-path.spurt(to-json(@kept, :sorted-keys));
    nok $client.installer.list-installed.first({ $_<name> eq 'LibPkg' }).defined,
        '构造出「site 有、账本缺记」的不一致';

    # site 就是 client-target-dep/site —— 伪造成真实链（生产路径 RAKULIB 会在链上）
    my $fake-chain = [CompUnit::Repository::Installation.new(
        prefix => $client.installer.repo-prefix.absolute)];
    lives-ok { $client.reconcile-installed(:chain($fake-chain)) }, '对账执行成功';
    ok $client.installer.list-installed.first({ $_<name> eq 'LibPkg' }).defined,
       '账本缺记的包被从 site 补记回来';
    ok '0.5' (elem) $client.installer.installed-versions('LibPkg'),
       '补记的版本正确';
}

# ---------- 10. 安装链上的账本自愈（!maybe-adopt）----------
# 已装 + 账本缺记：在 install-chain 跳过分支里当场补记，
# 不必等 `raku-pm installed` 来触发对账自愈。
# 真实场景：用户的 Grammar::DSN 是旧代码装的、账本从未记到，
# 「已安装(跳过)」永远命中、但账本空着 —— 现在 install 顺手补。
{
    my $client = RakuPM::Client.new(
        :target($tmp.add('client-target-adopt')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-a').mkdir))]),
    );

    # 用 App2 + LibPkg 这一对还在 chain 上的 setup（前面 section 8 已经装过 LibPkg，
    # 但每个 block 用独立 tmp 目录，重头来一遍更直观）
    my $lib = $tmp.add('a-lib').mkdir;
    $lib.add('lib').mkdir;
    $lib.add('lib').add('Adopted.rakumod').spurt('unit module Adopted;');
    $lib.add('META6.json').spurt(to-json({
        name => 'Adopted', version => '0.1', auth => 'demo',
        provides => { Adopted => 'lib/Adopted.rakumod' }, depends => {},
    }, :sorted-keys));
    $client.install-from-dir($lib, :no-test);
    ok $client.installer.list-installed.first({ $_<name> eq 'Adopted' }).defined,
       '先装好 Adopted，正常记账';

    # 删账本里 Adopted 的条目 → 模拟「site 有、账本没有」
    my $json = $client.target.add('installed.json');
    my @kept = from-json($json.slurp).grep({ $_<name> ne 'Adopted' });
    $json.spurt(to-json(@kept, :sorted-keys));
    nok $client.installer.list-installed.first({ $_<name> eq 'Adopted' }).defined,
       '构造不一致：账本无、site 有';
    ok try { CompUnit::Repository::Installation.new(
              :prefix($client.installer.repo-prefix.absolute)
           # (meta<name> // '') 兜 undefined：`eq` 是字符串比较，读到没有 name
           # 字段的发行版会喷 "Use of Nil in string context"（t/meta-definedness.t
           # 有专门守卫，禁的就是裸写 meta<...> eq）。
           ).installed.first({ (($_.meta<name> // '') eq 'Adopted') }).defined },
       '构造不一致：自家 site 仍认得 Adopted';

    # 注入自家 site chain，模拟生产路径 RAKULIB 包含自家 site 的场景
    my $chain = [CompUnit::Repository::Installation.new(
        :prefix($client.installer.repo-prefix.absolute))];

    my $dist = RakuPM::Distribution.new(
        :name<Adopted>, :version<0.1>, :auth<demo>,
        :provides(['Adopted',]), :depends({}));

    ok $client.is-installed($dist, :$chain),
       'is-installed：链上命中自家 site';

    # 调私有方法！账本当场被补
    lives-ok { $client.maybe-adopt($dist, :$chain) }, 'maybe-adopt 执行无异常';
    my $entry = $client.installer.list-installed.first({ $_<name> eq 'Adopted' });
    ok $entry, '账本已被当场补记';
    ok '0.1' (elem) $client.installer.installed-versions('Adopted'),
       '补记的版本正确';

    # 已记账时再调用不应再补——但「是否再写盘」是次要的（即便写也内容等价），
    # 所以这里只断言 installed-versions 仍然正确即可。
    lives-ok { $client.maybe-adopt($dist, :$chain) }, '再调一次 no-op';

    # 自装 RakuPM 时的 RAKULIB 遮蔽警告：
    # 通过「同一进程只触发一次」的内部标志断言，不必抓 stderr。
    my $self-src = $tmp.add('self-src').mkdir;
    $self-src.add('lib').mkdir;
    $self-src.add('lib').add('RakuPM.rakumod').spurt('unit module RakuPM;');
    $self-src.add('META6.json').spurt(to-json({
        name => 'RakuPM', version => '0.13', auth => 'zef:skyter10086',
        api => '1', description => 'self-test fixture',
        provides => { RakuPM => 'lib/RakuPM.rakumod' }, depends => {},
    }, :sorted-keys));
    $client.install-from-dir($self-src, :no-test);
    ok $client.did-self-shadow-warn, '自装 RakuPM 触发 RAKULIB 遮蔽警告';
}

done-testing;
