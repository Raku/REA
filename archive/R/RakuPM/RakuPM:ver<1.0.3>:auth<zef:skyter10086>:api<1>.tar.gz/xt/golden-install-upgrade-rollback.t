use Test;
use JSON::Fast;
use lib 'lib';
use RakuPM::Client;
use RakuPM::Repository::Local;
use RakuPM::Fs;

# ============================================================================
# golden e2e：install → upgrade → rollback 完整链路（跨阶段串联）
#
# 【为何现有 xt 覆盖不到】
#   · xt/generations.t 在【Installer 引擎层】测了事务回滚、世代切换、rollback-to，
#     但它从不「升级」、也从不「实际加载模块验证版本内容」——只查 installed-versions
#     与世代 JSON。
#   · xt/upgrade-all.t 只测了「批量升级」的统计恒真 bug，不回滚。
#   两者都没把「装 V1 → 升到 V2 → 退回 V1 且实际加载到的版本跟着变」这条用户
#   最常在终端走的链路串起来验证。单点都绿 ≠ 链路绿，所以这是真正的跨阶段缺口。
#
# 本测试走【Client 命令层】（与 CLI 同一套 install/upgrade/rollback），并在每个
# 阶段用子进程真实 `use` 该包、读出其版本常量，证明「安装状态」与「实际加载到的
# 版本」一致——这是 generations.t 没做的硬验证。
# ============================================================================

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-golden-iur-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $repo-root = $tmp.add('repo'); $repo-root.mkdir;
my $target    = $tmp.add('tgt');  $target.mkdir;
# 本地仓库需要 repositories.json 才能被当成本地仓库根（与 fetch.t 同款套路）
$target.add('repositories.json').spurt(to-json({ repos => [] }, :sorted-keys));

# 造一个本地仓库：包 Pkg 同时有 1.0 与 2.0，每个版本的模块导出自己的版本常量。
sub mk-pkg(Str $ver --> IO::Path) {
    my $d = $repo-root.add("Pkg-$ver");
    $d.mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add('Pkg.rakumod').spurt(
        "unit module Pkg;\n" ~
        "our \$VER = '$ver';\n" ~
        "our sub ver \{ \$VER \}\n");
    $d.add('META6.json').spurt(to-json({
        name    => 'Pkg', version => $ver, auth => 'test:me', api => '1',
        description => "Pkg $ver",
        provides => { Pkg => "lib/Pkg.rakumod" },
        depends  => {},
    }, :sorted-keys));
    $d;
}
mk-pkg('1.0');
mk-pkg('2.0');

my $client = RakuPM::Client.new(
    :target($target),
    :repos([ RakuPM::Repository::Local.new(:root($repo-root)) ]),
);

# 在目标 CUR 里真正加载 Pkg（不指定版本 → 取最高版），读出其版本常量。
sub loaded-ver(--> Str) {
    my $lib-spec = $client.installer.raku-lib-spec;
    my $p = run($*EXECUTABLE, '-I', $lib-spec, '-e',
                'use Pkg; say Pkg::ver()', :out, :err);
    my $out = $p.out.slurp(:close).trim;
    $p.err.slurp(:close);
    $out;
}

# ---------- 1) 安装 V1 ----------
$client.install('Pkg', '1.0');
is $client.installer.installed-versions('Pkg').join(','), '1.0',
   'install V1 → 账本只记了 1.0';
is loaded-ver(), '1.0',
   'install V1 → 实际加载到的就是 1.0';

# ---------- 2) 升级到最新（V2） ----------
ok $client.upgrade('Pkg'), 'upgrade → 返回 True（真的升了级）';
ok $client.installer.installed-versions('Pkg').grep(* eq '2.0'),
   'upgrade → 2.0 已装入（多版本并存）';
is loaded-ver(), '2.0',
   'upgrade → 实际加载到最高版 2.0（不用 :ver 也取最高）';

# ---------- 3) 回滚到第一个世代（只含 V1） ----------
my @gens   = $client.installer.list-generations;
my $gen-id = (@gens.first({ .<id> eq '000001' }) // @gens[0])<id>;
$client.rollback($gen-id);
is $client.installer.installed-versions('Pkg').join(','), '1.0',
   'rollback 到 gen1 → 2.0 被卸掉，账本只剩 1.0';
is loaded-ver(), '1.0',
   'rollback → 实际加载回到 1.0（升级的版本确实被摘掉了）';
is $client.installer.current-generation, $gen-id,
   'rollback → 当前世代切回 ' ~ $gen-id;

done-testing;
