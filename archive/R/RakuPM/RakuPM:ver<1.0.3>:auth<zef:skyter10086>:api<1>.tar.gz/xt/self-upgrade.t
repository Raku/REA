use Test;
use RakuPM::Client;

# 临时 target：模拟「已装 RakuPM 0.25.0，安装时对应提交 abc1234」
my $tmp = $*TMPDIR.add('rakupm-self-upgrade-' ~ $*PID);
$tmp.mkdir;
$tmp.add('installed.json').spurt: q:to/JSON/;
    [
      {
        "name": "RakuPM",
        "version": "0.25.0",
        "versions": ["0.25.0"],
        "auth": "zef:skyter10086",
        "git-shas": { "0.25.0": "abc1234" }
      }
    ]
    JSON

my $client = RakuPM::Client.new(:target($tmp), :repos([]));

# 未安装过包的空 target（用来测「本地没装过 → 必装」）
my $tmp2 = $*TMPDIR.add('rakupm-self-upgrade-empty-' ~ $*PID);
$tmp2.mkdir;
my $client2 = RakuPM::Client.new(:target($tmp2), :repos([]));

plan 10;

# 1) 远端版本更新 → 升级
ok $client.upgrade-needed('RakuPM', '0.26.0', 'def5678'),
   '远端版本更新（0.25.0 → 0.26.0）→ 需要升级';

# 2) 版本相同 + 提交号相同 → 跳过（这正是「已是最新还要重装」的修复点）
nok $client.upgrade-needed('RakuPM', '0.25.0', 'abc1234'),
   '版本相同且提交号一致 → 跳过（已是最新，不重复下载安装）';

# 3) 版本相同 + 提交号不同（上游被强推 / 改写历史）→ 升级
ok $client.upgrade-needed('RakuPM', '0.25.0', 'zzz9999'),
   '版本相同但提交号不同（强推）→ 需要重装';

# 4) 显式 --force → 即便最新也升级
ok $client.upgrade-needed('RakuPM', '0.25.0', 'abc1234', :force),
   '显式 --force → 强制升级';

# 5) 本地比远端还新 → 跳过（避免降级）
nok $client.upgrade-needed('RakuPM', '0.24.0', 'old0000'),
   '本地版本比远端新 → 跳过（避免降级）';

# 6) 本地没装过 → 升级
ok $client2.upgrade-needed('RakuPM', '0.25.0', 'abc1234'),
   '本地从未安装过 → 需要升级';

# ---------- 7-10) 内容比对兜底：同版本、账本里没有 git 提交号记录 ----------
# （老版本装的 / install . 装的都属此类。远端 clone 与 store 源码快照逐文件比对。）
{
    my $tmp3 = $*TMPDIR.add('rakupm-self-upgrade-cmp-' ~ $*PID);
    $tmp3.mkdir;
    $tmp3.add('installed.json').spurt: q:to/JSON/;
        [
          { "name": "RakuPM", "version": "0.27.0", "versions": ["0.27.0"],
            "auth": "zef:skyter10086" }
        ]
        JSON

    # store 源码快照：store/RakuPM/0.27.0/{META6.json, lib/RakuPM/Foo.rakumod}
    my $snap = $tmp3.add('store').add('RakuPM').add('0.27.0');
    $snap.add('lib').add('RakuPM').mkdir;
    $snap.add('META6.json').spurt('{"name":"RakuPM","version":"0.27.0"}');
    $snap.add('lib').add('RakuPM').add('Foo.rakumod').spurt('unit module RakuPM::Foo;');

    # 远端 clone（自带 .git —— 比对必须排除它）
    my $remote = $tmp3.add('clone');
    $remote.add('lib').add('RakuPM').mkdir;
    $remote.add('.git').mkdir;
    $remote.add('META6.json').spurt('{"name":"RakuPM","version":"0.27.0"}');
    $remote.add('lib').add('RakuPM').add('Foo.rakumod').spurt('unit module RakuPM::Foo;');

    my $c3 = RakuPM::Client.new(:target($tmp3), :repos([]));

    # 7) 内容一致 → 跳过（这正是用户场景：老安装无提交号，但内容没变）
    nok $c3.upgrade-needed('RakuPM', '0.27.0', 'aaaa1111', :remote-source($remote)),
       '同版本+无提交号记录+源码逐文件一致 → 跳过';

    # 8) 改了文件内容 → 重装
    $remote.add('lib').add('RakuPM').add('Foo.rakumod')
           .spurt('unit module RakuPM::Foo; # changed');
    ok $c3.upgrade-needed('RakuPM', '0.27.0', 'aaaa1111', :remote-source($remote)),
       '同版本+源码内容已变 → 重装';

    # 9) 远端新增文件 → 重装
    $remote.add('lib').add('RakuPM').add('Foo.rakumod').spurt('unit module RakuPM::Foo;');
    $remote.add('lib').add('RakuPM').add('Bar.rakumod').spurt('unit module RakuPM::Bar;');
    ok $c3.upgrade-needed('RakuPM', '0.27.0', 'aaaa1111', :remote-source($remote)),
       '同版本+远端新增文件 → 重装';

    # 10) store 里没有该版本源码快照（如 zef 装的）→ 退回保守跳过
    my $tmp4 = $*TMPDIR.add('rakupm-self-upgrade-nosnap-' ~ $*PID);
    $tmp4.mkdir;
    $tmp4.add('installed.json').spurt: q:to/JSON/;
        [
          { "name": "RakuPM", "version": "0.27.0", "versions": ["0.27.0"] }
        ]
        JSON
    my $c4 = RakuPM::Client.new(:target($tmp4), :repos([]));
    nok $c4.upgrade-needed('RakuPM', '0.27.0', 'aaaa1111', :remote-source($remote)),
       '同版本+无提交号+无快照可比 → 保守跳过';
}

done-testing;
