use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
# 本文件验证【失败首行+日志 / 超时 kill】（0.80.0 起测试已改串行，原并发场景随之删除）。
use RakuPM::Client;
use RakuPM::Repository::Local;

# 集成测试：测试阶段的【进程隔离 + 超时】能力（0.38.0）。
# 放在 xt/ 而非 t/：失败用例会触发 ⚠（测试软通过提示），按项目纪律
# 只能进 xt/（不进 zef install 的纯净度守卫）。
#
# 覆盖两件事：
#   1. 失败首行 + 完整日志：失败用例前台只印第一行，完整输出进日志；
#   2. 超时：单测试 sleep 远超 --test-timeout，看门狗 kill 子进程并判失败。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}
my $tmp = $*TMPDIR.add('rakupm-tasync-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub mk-dist(Str $name, @tests) {
    # @tests: List of Pair (basename => body)
    my $src = $tmp.add($name).mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add($name ~ '.rakumod').spurt("unit module $name;");
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '0.1.0', auth => 'demo',
        provides => { $name => "lib/$name.rakumod" }, depends => {},
    }, :sorted-keys));
    $src.add('t').mkdir;
    for @tests -> $p {
        $src.add('t').add($p.key).spurt($p.value);
    }
    $src
}
sub client(IO::Path $target) {
    RakuPM::Client.new(
        :target($target),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo').mkdir))]),
    )
}
sub log-file(IO::Path $target, Str $name, Str $test) {
    $target.add('log').add($name).add('0.1.0').add($test ~ '.log');
}

# ---------- 场景 2：失败首行 + 完整日志 ----------
plan 6;
my $srcB = mk-dist('AsyncFail', (
    '01-pass.rakutest' => "use Test; plan 1; ok 1, 'win';\n",
    '02-fail.rakutest' => "use Test; plan 1; ok 0, 'boom';\n",
));
my $clientB = client($tmp.add('tB'));
my $err-cap = '';
{
    my $cap = class {
        has $.buf = '';
        method print(*@a) { $!buf ~= @a.join; $!buf }
        method say(*@a)   { self.print(@a.join ~ "\n") }
        method put(*@a)   { self.print(@a.join ~ "\n") }
    }.new;
    my $*ERR = $cap;
    try {
        $clientB.install-from-dir($srcB, :no-build, :force,
                                  :allow-test-failure);
    }
    $err-cap = $cap.buf;
}
ok $err-cap.contains('| 1..1'),
   '场景2：失败用例前台只印【第一行】（带 "|" 缩进前缀，首行为 TAP plan 行）';
my $fail-log = log-file($tmp.add('tB'), 'AsyncFail', '02-fail.rakutest');
ok $fail-log.e && $fail-log.slurp.contains('not ok 1 - boom'),
   '场景2：失败用例完整 TAP 已落日志（含 not ok）';
my $pass-log = log-file($tmp.add('tB'), 'AsyncFail', '01-pass.rakutest');
ok $pass-log.e && $pass-log.slurp.contains('ok 1 - win'),
   '场景2：通过用例日志也有完整输出';

# ---------- 场景 3：超时 kill ----------
my $srcC = mk-dist('AsyncTimeout', (
    '01-hang.rakutest' => "use Test; plan 1; sleep 30; ok 1, 'never';\n",
));
my $t0c = now;
lives-ok { client($tmp.add('tC')).install-from-dir($srcC, :no-build, :force,
              :test-timeout(1), :allow-test-failure) },
    '场景3：sleep 30 的测试被超时看门狗 kill（不卡 30s）';
my $elapsedC = now - $t0c;
ok $elapsedC < 15,
   "场景3：安装在 {$elapsedC.fmt('%.2f')}s 内返回（看门狗超时 1s；留足 taskkill/reap/写日志延迟余量，仍远小于 30s 挂死，证明看门狗生效）";
my $hang-log = log-file($tmp.add('tC'), 'AsyncTimeout', '01-hang.rakutest');
ok $hang-log.e && $hang-log.slurp.contains('超时'),
   '场景3：日志标记录杀（含「超时」字样）';
