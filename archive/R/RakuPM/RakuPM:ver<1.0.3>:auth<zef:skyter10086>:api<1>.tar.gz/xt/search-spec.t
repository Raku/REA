use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use JSON::Fast;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 查询/取源码命令的规格串支持（与 install 同一套 RakuPM::Spec 解析）：
#   installed 'Dual:ver<0.9.2>'   只列满足约束的版本
#   installed 'Dual:auth<demo>'   再按作者筛
#   store    'Dual@0.13.0'        @ 简写同款
#   version  'Dual:ver<9.9>'      无满足版本 → 明确提示（查询命令不报错退出）
#   fetch    'Lone@1.0+'          按约束挑版本取源码
#   search   'Dual:ver<0.9.2>'    仓库与已装两侧都按约束筛
# ver 不是合法约束（foo@bar）→ 整串当关键词，行为退回旧版。
#
# CLI 子进程验证（基建同 query-installed-store.t），但源码目录造在 Local
# 仓库根里 —— 既能 install-from-dir 造账本，又能被子进程的 search 搜到。
#
# 离线保障：默认配置会挂 zef 远程索引（search/fetch 一调用就拉索引），
# 所以预写 repositories.json 只留空条目，RAKUPM_REPO 会把本地根补进去，
# 子进程里就只有 Local 一个仓库，全程不联网。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $bin = $*PROGRAM.parent(2).add('bin').add('raku-pm.raku');
my $tmp = $*TMPDIR.add('rakupm-spec-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $repo-root = $tmp.add('r').mkdir;
my $target    = $tmp.add('t').mkdir;
# 子进程仓库配置：空条目 + RAKUPM_REPO 注入本地根（见文件头「离线保障」）
$target.add('repositories.json').spurt(to-json({ repos => [] }, :sorted-keys));

my $client = RakuPM::Client.new(
    :target($target),
    :repos([RakuPM::Repository::Local.new(:root($repo-root))]),
);

# Dual 0.9.2 + 0.13.0（多版本）、Lone 1.2.3
sub mk-src($name, $ver) {
    my $s = $repo-root.add("{ $name }-{ $ver }-src").mkdir;
    $s.add('lib').mkdir;
    $s.add('lib').add("$name.rakumod").spurt("unit module $name;");
    $s.add('META6.json').spurt(to-json({
        name => $name, version => $ver, auth => 'demo',
        provides => { $name => "lib/$name.rakumod" }, depends => {},
    }, :sorted-keys));
    $s
}
$client.install-from-dir(mk-src('Dual', '0.9.2'),  :no-test);
$client.install-from-dir(mk-src('Dual', '0.13.0'), :no-test);
$client.install-from-dir(mk-src('Lone', '1.2.3'),  :no-test);

sub cli(@args) {
    my %env = %( %*ENV,
        RAKUPM_TARGET => $target.absolute,
        RAKUPM_REPO   => $repo-root.absolute,
    );
    run('raku', $bin.absolute.Str, |@args, :out, :err, :env(%env))
}

# ---------- installed 规格：:ver 精确约束 ----------
{
    my $p  = cli(('installed', 'Dual:ver<0.9.2>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed :ver：退出码 0';
    ok  $out.contains('已安装（raku-pm）：Dual'), 'installed :ver：命中 Dual';
    # 表格里包名与版本被竖线分隔（| Dual | 0.9.2 |），不再空格相连，故分开断言
    ok  $out.contains('Dual') && $out.contains('0.9.2'),
        'installed :ver：0.9.2 满足约束被列出';
    # 用 'Dual 0.13.0'（版本行）而不是裸 '0.13.0'：账本的「源：」路径里
    # 有 Dual-0.13.0-src（最后安装版本的源码目录），裸串会误中
    nok $out.contains('Dual 0.13.0'),             'installed :ver：0.13.0 不满足被筛掉';
}

# ---------- installed 规格：@ 简写等价 ----------
{
    my $p  = cli(('installed', 'Dual@0.9.2'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed @ 简写：退出码 0';
    ok  $out.contains('Dual') && $out.contains('0.9.2'),
        'installed @ 简写：0.9.2 被列出';
    nok $out.contains('Dual 0.13.0'), 'installed @ 简写：与 :ver<> 写法等价';
}

# ---------- installed 规格：不带版本 = 不筛选（旧行为） ----------
{
    my $p  = cli(('installed', 'Dual'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed 不带版本：退出码 0';
    ok $out.contains('Dual') && $out.contains('0.9.2'),
        'installed 不带版本：0.9.2 在列';
    ok $out.contains('Dual') && $out.contains('0.13.0'),
        'installed 不带版本：0.13.0 在列（空 ver 不筛选）';
}

# ---------- installed 规格：约束无满足版本 → 明确提示 ----------
{
    my $p  = cli(('installed', 'Dual:ver<9.9>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed 约束未命中：退出码 0（查询命令不报错）';
    ok $out.contains('未安装'),             'installed 约束未命中：明确提示';
    ok $out.contains('没有满足约束的版本'), 'installed 约束未命中：提示带原因';
    ok $out.contains('installed Dual'),     'installed 约束未命中：建议不带约束再看';
}

# ---------- installed 规格：auth 筛选 ----------
{
    my $p  = cli(('installed', 'Dual:auth<demo>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed auth 匹配：退出码 0';
    ok $out.contains('Dual') && $out.contains('0.9.2'),
        'installed auth 匹配：0.9.2 在列';
    ok $out.contains('Dual') && $out.contains('0.13.0'),
        'installed auth 匹配：0.13.0 在列';
}
{
    my $p  = cli(('installed', 'Dual:auth<nobody>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'installed auth 不匹配：退出码 0';
    ok $out.contains('未安装'), 'installed auth 不匹配：按未安装提示';
}

# ---------- store 规格 ----------
{
    my $p  = cli(('store', 'Dual:ver<0.9.2>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'store :ver：退出码 0';
    ok  $out.contains('Dual 0.9.2'), 'store :ver：0.9.2 缓存在列';
    ok  $out.contains($client.store.path-for('Dual', '0.9.2').absolute),
        'store :ver：带完整路径';
    nok $out.contains('0.13.0'), 'store :ver：0.13.0 被筛掉';
}
{
    my $p  = cli(('store', 'Dual@0.13.0'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'store @ 简写：退出码 0';
    ok  $out.contains('Dual 0.13.0'), 'store @ 简写：0.13.0 在列';
    nok $out.contains('0.9.2'),       'store @ 简写：0.9.2 被筛掉';
}
{
    my $p  = cli(('store', 'Dual:ver<9.9>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'store 约束未命中：退出码 0';
    ok $out.contains('没有版本满足约束 9.9'),
        'store 约束未命中：提示（不静默空输出）';
}

# ---------- version 规格 ----------
{
    my $p  = cli(('version', 'Dual:ver<0.9.2>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'version :ver：退出码 0';
    ok  $out.contains('Dual 的已安装版本'), 'version :ver：标题';
    ok  $out.contains('0.9.2'),             'version :ver：满足约束的 0.9.2 在列';
    nok $out.contains('0.13.0'),            'version :ver：0.13.0 被筛掉';
}
{
    my $p  = cli(('version', 'Dual:ver<9.9>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'version 约束未命中：退出码 0';
    ok $out.contains('没有已安装的版本满足约束'), 'version 约束未命中：提示';
    ok $out.contains('version Dual'),              'version 约束未命中：建议不带约束再看';
}

# ---------- fetch 规格 ----------
{
    my $to  = $tmp.add('fetch-a').mkdir;
    my $p   = cli(('fetch', 'Lone@1.2.3', "--to={$to.absolute}"));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'fetch @ 精确：退出码 0';
    ok $out.contains('已取到源码：Lone 1.2.3'), 'fetch @ 精确：按约束取到 1.2.3';
    my $dest = $to.add('Lone');
    ok $dest.add('META6.json').e,               'fetch @ 精确：META6.json 落盘';
    ok $dest.add('lib').add('Lone.rakumod').e,  'fetch @ 精确：lib 源码落盘';
}
{
    # at-least 约束（zef 的 + 后缀）：1.0+ → 满足约束的最高版 1.2.3
    my $to  = $tmp.add('fetch-b').mkdir;
    my $p   = cli(('fetch', 'Lone@1.0+', "--to={$to.absolute}"));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'fetch at-least：退出码 0';
    ok $out.contains('已取到源码：Lone 1.2.3'), 'fetch at-least：1.0+ 挑到最高的 1.2.3';
}
{
    # 取源码失败（约束无满足版本）是操作失败，该让它非 0 退出
    my $to  = $tmp.add('fetch-c').mkdir;
    my $p   = cli(('fetch', 'Lone@9.9', "--to={$to.absolute}"));
    my $err = $p.err.slurp(:close);
    isnt $p.exitcode, 0, 'fetch 约束未命中：非 0 退出';
    ok $err.contains('9.9'), 'fetch 约束未命中：报错带约束';
}

# ---------- search 规格 ----------
{
    my $p  = cli(('search', 'Dual:ver<0.9.2>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'search :ver：退出码 0';
    ok  $out.contains('匹配到 1 个发行版'), 'search :ver：只命中 1 个';
    ok  $out.contains('版本约束 0.9.2'),    'search :ver：提示行带约束';
    ok  $out.contains('Dual 0.9.2'),        'search :ver：0.9.2 被搜出（最高版不满足也命中低版）';
    nok $out.contains('0.13.0'),            'search :ver：0.13.0 不满足被筛掉';
}
{
    my $p  = cli(('search', 'Dual:auth<demo>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'search auth 匹配：退出码 0';
    ok  $out.contains('auth demo'),   'search auth 匹配：提示行带 auth';
    ok  $out.contains('Dual 0.13.0'), 'search auth 匹配：无版本约束时取最高版';
}
{
    # 设计内行为（Reporter 注释有说明）：auth 筛选只作用于仓库行 ——
    # %installed 是「名字 => 版本列表」，没有 auth 信息，已装的包仍以
    # [已装] 出现；仓库行则被 auth 筛掉
    my $p  = cli(('search', 'Dual:auth<nobody>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'search auth 不匹配：退出码 0';
    ok  $out.contains('auth nobody'), 'search auth 不匹配：提示行带 auth';
    ok  $out.contains('[已装]'),      'search auth 不匹配：已装侧不受 auth 筛（设计内）';
    nok $out.contains('[local]'),     'search auth 不匹配：仓库行被 auth 筛掉';
}
{
    my $p  = cli(('search', 'Dual:ver<9.9>'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'search 约束未命中：退出码 0';
    ok $out.contains('未找到匹配'), 'search 约束未命中：明确提示';
}
{
    # ver 不是合法约束（bar）→ 整串当关键词，别让坏约束把版本全筛没
    my $p  = cli(('search', 'foo@bar'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'search 非法约束：退出码 0';
    ok $out.contains("未找到匹配 'foo@bar'"), 'search 非法约束：整串当关键词回退';
}
{
    my $p  = cli(('search', 'Lone'));
    my $out = $p.out.slurp(:close);
    is $p.exitcode, 0, 'search 不带版本：退出码 0';
    ok $out.contains('Lone 1.2.3'), 'search 不带版本：旧行为不变';
}

done-testing;
