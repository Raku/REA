use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;
use RakuPM::Fs;

# `raku-pm flush`（0.50.0）—— 把当前前缀整个清空，回到「可以重新安装」的状态。
#
# 这是**破坏性命令**的守护，所以有三条纪律写在最前面：
#
#   ① **永远注入 `:entry-dir`**。不注入的话 flush 会去动本机全局 site/bin 里那份
#      真正的 `raku-pm` 命令 —— 跑一次测试就把开发机上的命令删了。
#      （与 promote-to-site-bin(:$site-bin) / ensure-bin-entry(:$dir) 同一惯例。）
#   ② 每条断言都要问两遍：**该删的删了没**、**不该删的还在不在**。
#      只验前者的话，一个「把前缀目录整个 rm -rf」的实现也能全绿 ——
#      而那恰恰是最该被挡住的实现（前缀可能和别的文件共处一个目录）。
#   ③ 护栏必须有测试：不像前缀的目录、家目录本身、文件系统根。
#      根那条没法在这里构造（临时目录的 canonical 不可能是根），所以判定抽成了
#      `RakuPM::Prefix.is-fs-root`，由 t/prefix.t 第 7 节直接触发。
#
# 放 xt/ 而不是 t/：本文件会触发「发现外来入口」分支，那行会打印 ⚠，
# 而 t/ 有洁净度硬约束（zef install 会跑 t/）。顺带也避免把破坏性测试放进
# `raku-pm install .` 会跑的批次里。

plan 19;

my $root = $*TMPDIR.add("rakupm-flush-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }
mkdir-p($root);

# 空本地仓库：让 Client 不去读 repositories.json / 生态索引（测试必须离线、无网络）
my $empty-repo = $root.add('empty-repo');
mkdir-p($empty-repo);
sub new-client(IO::Path $target) {
    RakuPM::Client.new(:$target, :repos([RakuPM::Repository::Local.new(:root($empty-repo))]));
}

# 造一个「像前缀」的目录：认得的条目齐全 + 一个不认得的条目（必须留着）
sub make-prefix(IO::Path $p, IO::Path $gbin) {
    mkdir-p($p.add('store', 'Foo', '1.0'));
    $p.add('store', 'Foo', '1.0', 'ximg.bin').spurt('x' x 64);
    mkdir-p($p.add('site'));
    mkdir-p($p.add('bin'));
    $p.add('bin', 'raku-pm').spurt("#!/usr/bin/env bash\nRAKUPM_RAKU='/x'\n");
    mkdir-p($p.add('log'));
    mkdir-p($p.add('generations'));
    mkdir-p($p.add('cache'));
    $p.add('installed.json').spurt('{}');
    $p.add('raku-pm.lock').spurt('{}');
    $p.add('用户的笔记.txt').spurt('别删我');       # 不认得 → 必须留着
    # 假入口目录：一份是 raku-pm 写的（含结构标记），一份是 zef 入口的备份
    mkdir-p($gbin);
    $gbin.add('raku-pm').spurt("#!/usr/bin/env bash\nRAKUPM_RAKU='/x'\n");
    $gbin.add('raku-pm.bat').spurt("set \"RAKUPM_RAKU=x\"\r\n");
    $gbin.add('raku-pm.exe.zef-old').spurt('ZEF-BACKUP');     # 别人的备份 → 必须留着
}

# ============ 1) 默认只试算：一个文件都不许动 ============
my $p    = $root.add('prefix-1');
my $gbin = $root.add('gbin-1');
make-prefix($p, $gbin);
my $c1 = new-client($p);
$c1.flush(:entry-dir($gbin));                    # 不给 :yes → 试算
ok $p.add('store', 'Foo', '1.0', 'ximg.bin').e, '试算：store 里的内容没动';
ok $p.add('installed.json').e,                  '试算：账本没动';
ok $p.add('bin', 'raku-pm').e,                  '试算：前缀内的入口没动';
ok $gbin.add('raku-pm').e,                      '试算：前缀外的自装入口没动';
ok $p.add('用户的笔记.txt').e,                   '试算：不认得的条目没动';

# ============ 2) 护栏：不像 raku-pm 前缀的目录 → 拒绝 ============
{
    my $not-a-prefix = $root.add('not-a-prefix');
    mkdir-p($not-a-prefix);
    $not-a-prefix.add('重要数据.txt').spurt('别动我');
    my $c = new-client($not-a-prefix);
    dies-ok { $c.flush(:entry-dir($gbin)) },
        '护栏：store/ 、site/ 、installed.json 都不存在 → 拒绝执行（防 --target 打错）';
    ok $not-a-prefix.add('重要数据.txt').e, '护栏拒绝后目录原样未动';
}

# ============ 3) 护栏：前缀指向家目录本身 → 拒绝 ============
{
    my $fake-home = $root.add('fake-home');
    mkdir-p($fake-home.add('store'));            # 让它「像前缀」，才能走到家目录那一条判据
    my $c = new-client($fake-home);
    my $err = '';
    {
        my $*HOME = $fake-home;                  # 词法遮蔽：护栏读的正是 $*HOME
        # 注意这里**不能**写 `try { $c.flush(...) } CATCH {...}`：`try` 会把异常
        # 吞掉（返回 Nil），后面的 CATCH 就成了死代码 —— 于是消息永远是空串、
        # 断言假红（写这条时就踩了）。要拿消息就只用 CATCH。
        $c.flush(:entry-dir($gbin));
        CATCH { default { $err = .message } }
    }
    ok $err.contains('拒绝执行'), '护栏：前缀 = 家目录本身 → 拒绝执行';
    ok $err.contains('家目录'),   '护栏：报错说明「指向了家目录本身」（而不是一句泛泛的拒绝）';
}

# ============ 4) --yes：该删的删掉、不该删的留着 ============
$c1.flush(:yes, :entry-dir($gbin));
nok $p.add('store').e,          '真删：store/ 已清除';
nok $p.add('installed.json').e, '真删：账本已清除';
nok $p.add('raku-pm.lock').e,   '真删：锁文件已清除';
nok $gbin.add('raku-pm').e,     '真删：前缀外的自装入口（bash）已清除';
nok $gbin.add('raku-pm.bat').e, '真删：前缀外的自装入口（.bat）已清除';
ok $p.add('用户的笔记.txt').e,   '保留：不认得的条目仍在（只删认得的条目名）';
ok $gbin.add('raku-pm.exe.zef-old').e,
   '保留：<名>.exe.zef-old 未动（那是 zef 入口的唯一备份，删了没得还原）';

# ============ 5) 同名但不是 raku-pm 写的入口 → 不删 ============
# Unix 上 zef 生成的入口就是无扩展名的 `<名>`，跟我们写的同名 —— 按名字删会删掉
# 别人的东西；所以按**内容**判（我们的 wrapper 都设 RAKUPM_RAKU 作启动兜底）。
{
    my $p2    = $root.add('prefix-2');
    my $gbin2 = $root.add('gbin-2');
    make-prefix($p2, $gbin2);
    $gbin2.add('raku-pm').spurt("#!/usr/bin/env bash\nexec raku '/somewhere/x.raku'\n");  # 外来
    new-client($p2).flush(:yes, :entry-dir($gbin2));
    nok $gbin2.add('raku-pm.bat').e, '外来入口同处一室时，自己写的 .bat 仍被清掉';
    ok $gbin2.add('raku-pm').e,      '而外来的同名 `raku-pm` 原样保留（内容里没有我们的标记）';
}

# ============ 6) 清过之后再跑：不再像前缀 → 护栏拒绝（而不是崩） ============
# 这是预期行为，不是 bug：store/ 与 installed.json 都没了，它就「不是一份前缀」了。
# 护栏的报错文案里也提示了这种情形（刚 flush 过属正常）。
dies-ok { new-client($p).flush(:entry-dir($gbin)) },
    '清空后再跑会被护栏拒绝（前缀特征已不存在），不会误删别的目录';
