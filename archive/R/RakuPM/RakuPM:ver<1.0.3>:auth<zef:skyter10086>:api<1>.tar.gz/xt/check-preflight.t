#!/usr/bin/env raku
# raku-pm check 端到端测试：真 CLI 子进程。覆盖退出码 + 报告内容。
# 复用 raku-pm new 造 fixture，再用 JSON::Fast 改 META6 制造各类错误。
use v6;
use Test;
use JSON::Fast;

plan 10;

my $raku = $*EXECUTABLE.absolute;
my $bin  = $*PROGRAM.parent.parent.add('bin').add('raku-pm.raku');
ok $bin.e, "CLI 脚本存在：{$bin}";

my $base = ($*TMPDIR // '/tmp'.IO).add('check-cli-' ~ $*PID);
$base.mkdir;
END { try {
    sub rm(IO::Path $x){ for $x.dir { .d ?? rm($_) !! .unlink }; try $x.rmdir }
    rm($base) if $base.e;
} }

sub run-check(IO::Path $d, *%env) {
    my $p = run($raku, '-Ilib', $bin, 'check', $d.absolute,
                 :out, :err, :%env);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out ~ $err)
}

sub meta-of(IO::Path $d) { from-json($d.add('META6.json').slurp) }
sub set-meta(IO::Path $d, %m) { $d.add('META6.json').spurt(to-json(%m, :sorted-keys)) }

# 造一个干净发行版
my $dist = $base.add('Demo');
{
    my $p = run($raku, '-Ilib', $bin, 'new', 'Demo::Mod', '--into=' ~ $dist.absolute,
                 :out, :err);
    $p.out.slurp(:close); $p.err.slurp(:close);
}
ok $dist.add('META6.json').e, 'new 生成了 META6.json';

# 场景1：description 改成真实值 + 设匹配的 RAKUPM_AUTHOR_AUTH → 0 错误 0 警告 → 通过
{
    my %m = meta-of($dist);
    %m<description> = 'A demo module for testing.';
    set-meta($dist, %m);
    my ($code, $out) = run-check($dist, RAKUPM_AUTHOR_AUTH => 'zef:skyter10086');
    is $code, 0, '场景1：干净发行版 check 退出码为 0';
    ok $out.contains('一切就绪'), '场景1：报告含「一切就绪」';
}

# 场景2：version = '*' → 不通过
{
    my %m = meta-of($dist);
    %m<version> = '*';
    set-meta($dist, %m);
    my ($code, $out) = run-check($dist);
    nok $code == 0, '场景2：version=* 退出码非 0';
    ok $out.contains('占位符'), '场景2：报告含「占位符」错误';
}

# 复原 version
{
    my %m = meta-of($dist);
    %m<version> = '0.1.0';
    set-meta($dist, %m);
}

# 场景3：auth 与 RAKUPM_AUTHOR_AUTH 不一致 → 不通过
{
    my ($code, $out) = run-check($dist, RAKUPM_AUTHOR_AUTH => 'github:bob');
    nok $code == 0, '场景3：auth 不一致退出码非 0';
    ok $out.contains('不一致'), '场景3：报告含「不一致」错误';
}

# 场景4：bin 文件缺失 → 不通过
{
    my %m = meta-of($dist);
    %m<bin> = ['bin/missing.raku'];
    set-meta($dist, %m);
    my ($code, $out) = run-check($dist);
    nok $code == 0, '场景4：bin 文件缺失退出码非 0';
    ok $out.contains('bin 声明的可执行文件'), '场景4：报告含 bin 缺失错误';
}

done-testing;
