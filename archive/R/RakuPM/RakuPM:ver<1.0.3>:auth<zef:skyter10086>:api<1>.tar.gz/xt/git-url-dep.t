use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Distribution;
use JSON::Fast;

# 回归测试：META6.json 的 depends 里写裸 git URL（URL 本身就是依赖，
# zef 也认这种写法）。Draku 的 META6.json 就依赖
#   "git://github.com/jkramer/p6-Text-Wrap.git"
# 旧实现把整个 URL 当模块名去仓库解析 → 报「找不到模块 'git://…'」装不上。
# 修法：Distribution 层把这类串收集到 git-deps，安装链在轮到该包之前
# 先 clone + 当普通发行版装完（install-from-git 递归）。
#
# 离线、确定性：用【本地 git 仓库】模拟远端。依赖仓库的 git-cache 目录
# 预先放一份真实拷贝，让嵌套 install-from-git 走「已有缓存 → git pull
# 失败（无 remote）→ 复用」分支，不碰网络。
#
# 依赖关系：
#   GitMain（git 仓库，被顶层 install-from-git 装）
#     └─ depends: [ "https://github.com/example/GitDep.git" ]   ← 裸 git URL
#          └─ GitDep（另一个 git 仓库，提供模块 GitDep）

my $has-git = ?(try { my $p = run('git', '--version', :out); $p.exitcode == 0 });
if !$has-git {
    plan 1;
    skip-rest 'git 不可用，跳过 git URL 依赖测试';
    exit 0;
}
plan 17;

my $base = $*TMPDIR.add('rakupm-giturldep-' ~ $*PID ~ '-' ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

# ---- 造依赖仓库：GitDep（提供模块 GitDep）----
my $dep = $base.add('GitDep-src');
$dep.mkdir;
$dep.add('lib').mkdir;
$dep.add('lib/GitDep.rakumod').spurt("unit module GitDep;\n");
$dep.add('META6.json').spurt(to-json({
    name        => 'GitDep',
    version     => '2.5.0',
    auth        => 'test:dep',
    description => 'git URL dep fixture',
    provides    => { GitDep => 'lib/GitDep.rakumod' },
    depends     => [],
}, :sorted-keys));

sub git-init(IO::Path $dir) {
    run('git', '--git-dir=' ~ $dir.add('.git').absolute,
              '--work-tree=' ~ $dir.absolute, 'init', :out, :err);
    run('git', '--git-dir=' ~ $dir.add('.git').absolute,
              '--work-tree=' ~ $dir.absolute, 'config', 'user.email',
              'test@example.com', :out, :err);
    run('git', '--git-dir=' ~ $dir.add('.git').absolute,
              '--work-tree=' ~ $dir.absolute, 'config', 'user.name',
              'raku-pm-test', :out, :err);
    run('git', '--git-dir=' ~ $dir.add('.git').absolute,
              '--work-tree=' ~ $dir.absolute, 'add', '-A', :out, :err);
    run('git', '--git-dir=' ~ $dir.add('.git').absolute,
              '--work-tree=' ~ $dir.absolute, 'commit', '-m', 'init', :out, :err);
}
git-init($dep);
ok True, '依赖仓库 GitDep 提交成功';

# ---- 造主仓库：GitMain，depends 里写裸 git URL（Draku 同款写法）----
my $main = $base.add('GitMain-src');
$main.mkdir;
$main.add('lib').mkdir;
$main.add('lib/GitMain.rakumod').spurt("unit module GitMain;\n");
$main.add('META6.json').spurt(to-json({
    name        => 'GitMain',
    version     => '4.1.0',
    auth        => 'test:main',
    description => 'git URL dep fixture (Draku-style)',
    provides    => { GitMain => 'lib/GitMain.rakumod' },
    # Draku 的写法：requires 数组里直接一条 git URL，没有任何 :from<> phaser
    depends     => [ 'https://github.com/example/GitDep.git' ],
}, :sorted-keys));
git-init($main);
ok True, '主仓库 GitMain 提交成功';

my $url = 'https://github.com/example/GitDep.git';

# ---- 预置依赖仓库的 git-cache：让嵌套 clone 走「复用缓存」分支 ----
# ensure-git-clone 的 cache 目录 = target/git-cache/<url 去 scheme 的 key>
# （https://github.com/example/GitDep.git → github.com/example/GitDep.git）
my $target = $base.add('t');
my $cache = $target.add('git-cache').add('github.com/example/GitDep.git');
$cache.parent.mkdir;
sub copy-tree(IO::Path $src, IO::Path $dst) {
    $dst.mkdir;
    for $src.dir -> $e {
        my $d = $dst.add($e.basename);
        $e.d ?? copy-tree($e, $d) !! $e.copy($d);
    }
}
copy-tree($dep, $cache);
ok $cache.add('META6.json').e, '依赖仓库缓存已预置到 git-cache（离线可跑）';

# ---- 顶层安装 GitMain（相对路径模拟远端，与 t/git-version.t 同一套路）----
my $cl = RakuPM::Client.new(:repo-root($base.absolute), :target($target),
                            :promote-bin(False));
temp $*CWD = $base;
my $err = '';
try { $cl.install-from-git('GitMain-src', :no-test, :no-build, :no-native-check) }
$err = $!.Str if $!;
ok !$err.chars, "顶层 git 安装不抛错" ~ ($err.chars ?? "：$err" !! '');

# 账本里应同时有主包与 git URL 依赖包
my @led = from-json($target.add('installed.json').slurp);
my @names = @led.map(*<name>).sort;
ok 'GitDep' (elem) @names, '裸 git URL 依赖（GitDep）被装进账本';
ok 'GitMain' (elem) @names, '主包（GitMain）被装进账本';
my $dep-row = @led.first({ .<name> eq 'GitDep' });
ok $dep-row.defined, '账本里 GitDep 有条目';

# ---- 幂等：再装一次主包，git 依赖已装则走「已装跳过」，不重复报错 ----
my $err2 = '';
try { $cl.install-from-git('GitMain-src', :no-test, :no-build, :no-native-check) }
$err2 = $!.Str if $!;
ok !$err2.chars, "重复安装不抛错" ~ ($err2.chars ?? "：$err2" !! '');

# ---- Distribution 层：多种裸 URL 形态都被收进 git-deps，普通模块不受影响 ----
{
    my $meta = from-json(q:to/JSON/);
    { "name": "X", "version": "1",
      "depends": [
        "git://github.com/jkramer/p6-Text-Wrap.git",
        "git@github.com:user/repo.git",
        "https://github.com/user/repo.git",
        "http://example.com/other.git",
        "JSON::Fast",
        "JSON::Fast:ver<1.0+>"
      ] }
    JSON
    # from-meta-file 需要真文件，这里直接走 normalize 构造
    my ($h, $nl, $el, $gl) =
        RakuPM::Distribution.normalize-dependencies-and-native-libs($meta<depends>);
    is $gl.elems, 4, 'git:// / git@ / https://…git / http://…git 四种形态都收进 git-deps';
    ok $gl.first({ .contains('p6-Text-Wrap.git') }).defined,
       'Draku 那个 git:// 样本被识别';
    is $h.keys.sort.join(','), 'JSON::Fast',
       '普通模块（含 :ver<> 规格）不进 git-deps，照常留在模块依赖表';
}

# ---- 平铺 Hash 形态里夹 git URL 键的极端情况也不炸 ----
{
    my %d = %( 'JSON::Fast' => '*', 'git://github.com/x/y.git' => '*' );
    my ($h, $nl, $el, $gl) =
        RakuPM::Distribution.normalize-dependencies-and-native-libs(%d);
    is $gl.join(','), 'git://github.com/x/y.git', '平铺 Hash 键为 git URL 时收进 git-deps';
    is $h.keys.sort.join(','), 'JSON::Fast', '平铺 Hash 里普通模块键不受影响';
}

# ---- git:// 协议升级（clone 前自动改成 https://）----
# GitHub 2022-01 关闭 git 协议（9418 端口）后，Draku 那种 git:// URL 直接
# clone 必失败；ensure-git-clone 在克隆前把 git:// 升级成 https://。
{
    is $cl.normalize-git-url('git://github.com/jkramer/p6-Text-Wrap.git'),
       'https://github.com/jkramer/p6-Text-Wrap.git',
       'git:// → https://（GitHub 已关 git 协议，Draku 场景）';
    is $cl.normalize-git-url('git://git.example.com/a/b.git'),
       'https://git.example.com/a/b.git',
       'git:// 任意 host 都升级（host/路径保留）';
    is $cl.normalize-git-url('https://github.com/a/b.git'),
       'https://github.com/a/b.git',
       'https:// 不变';
    is $cl.normalize-git-url('git@github.com:a/b.git'),
       'git@github.com:a/b.git',
       'ssh 形态（git@…）不变';
}

done-testing;
