use Test;
use lib 'lib';
use JSON::Fast;
use RakuPM::Author;

# 端到端：真实 CLI 子进程跑 new → dist → bump，验证整条作者侧闭环
%*ENV<RAKUPM_AUTHOR_AUTH> = 'github:tester';

plan 11;

my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;
my $tmp  = ($*TMPDIR // '/tmp'.IO).add("rakupm-cli-distbump-{now.to-posix[0].Int}");
$tmp.mkdir;
my $cli  = $tmp.add('Cli');   # new 的 --into 目标

sub run-cli(*@args, :$cwd = '') {
    my %opts = :out, :err;
    %opts<cwd> = $cwd if $cwd.defined && $cwd.chars;
    my $p = run($raku, '-Ilib', $bin, |@args, |%opts);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

# 列 tar 内容：用 RakuPM::Author.tar-archive-list —— 它内部走 !tar-path，
# 会探测 tar 是 GNU 还是 BSD（Windows 10+ 自带 bsdtar），两种都能正确读取。
# 【别再自己写路径转换】：本机 tar 是 bsdtar，硬编码 MSYS 的 /c/… 会让 tar
# 报错并返回空列表，测试假失败（这个 bug 就发生在这一行上）。

# 场景1：new 创建骨架
{
    my ($code, $out, $err) = run-cli('new', 'Foo::Cli', "--into={$cli}", '--version=0.1.0', '--auth=github:tester');
    is $code, 0, '场景1：new 退出码 0';
    ok $cli.add('META6.json').e && $cli.add('lib/Foo/Cli.rakumod').e, '场景1：生成 META6 + lib';
}

# 场景2：dist 打包（cwd = 发行版目录，包落到本目录，自身排除）
{
    my ($code, $out, $err) = run-cli('dist', :cwd($cli.absolute));
    is $code, 0, '场景2：dist 退出码 0';
    my $tgz = $cli.add('Foo-Cli-0.1.0.tar.gz');
    ok $tgz.e, '场景2：生成 Foo-Cli-0.1.0.tar.gz';
    # 解列校验内含 META6.json 且不含自身
    my @list = RakuPM::Author.tar-archive-list($tgz);
    ok @list.grep({ $_ eq 'META6.json' }), '场景2：tar 含 META6.json';
    ok @list.grep(*.contains('Foo-Cli-0.1.0.tar.gz')) == 0, '场景2：包自身被排除';
}

# 场景3：bump --minor → 0.2.0
{
    my ($code, $out, $err) = run-cli('bump', '--minor', :cwd($cli.absolute));
    is $code, 0, '场景3：bump --minor 退出码 0';
    my %m = from-json($cli.add('META6.json').slurp);
    is %m<version>.Str, '0.2.0', '场景3：META6 升到 0.2.0';
    ok $cli.add('Changes').slurp.contains('## 0.2.0'), '场景3：Changes 加了 ## 0.2.0';
}

# 场景4：bump 位置参数像版本号 → 精确指定 3.0.0
{
    my ($code, $out, $err) = run-cli('bump', '3.0.0', :cwd($cli.absolute));
    is $code, 0, '场景4：bump 3.0.0 退出码 0';
    my %m = from-json($cli.add('META6.json').slurp);
    is %m<version>.Str, '3.0.0', '场景4：META6 升到 3.0.0';
}

# 收尾
sub rm-rec(IO::Path $x) {
    return unless $x.e;
    if $x.d { for $x.dir { rm-rec($_) }; try $x.rmdir }
    else    { try $x.unlink }
}
rm-rec($tmp);
