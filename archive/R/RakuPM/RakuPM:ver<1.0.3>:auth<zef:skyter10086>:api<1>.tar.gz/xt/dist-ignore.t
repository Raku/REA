use Test;
use lib 'lib';
use RakuPM::Author;
use RakuPM::Fs;

# 端到端：真实 CLI 子进程验证 `.distignore` 自定义排除清单。
# 为什么放 xt/ 而不是 t/：本文件要断言「拼错的条目会往 stderr 喷 ⚠ 提示」，
# 那次输出发生在子进程里、被 capture 掉；但更重要的是 —— t/ 门禁要求测试
# 自身输出洁净，这类「故意制造警告」的用例只适合放 xt/（xt 只判成败）。
%*ENV<RAKUPM_AUTHOR_AUTH> = 'github:tester';

plan 6;

my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;
my $tmp  = ($*TMPDIR // '/tmp'.IO).add("rakupm-distignore-{now.to-posix[0].Int}");
$tmp.mkdir;
my $cli  = $tmp.add('Cli');

sub run-cli(*@args, :$cwd = '') {
    my %opts = :out, :err;
    %opts<cwd> = $cwd if $cwd.defined && $cwd.chars;
    my $p = run($raku, '-Ilib', $bin, |@args, |%opts);
    ($p.exitcode, $p.out.slurp(:close), $p.err.slurp(:close))
}

# 场景1：建骨架，再塞入「名字正常的内部文件」——隐藏项过滤挡不住这一类
{
    my ($code, $out, $err) = run-cli('new', 'Foo::Ig', "--into={$cli}",
                                     '--version=0.1.0', '--auth=github:tester');
    is $code, 0, '场景1：new 退出码 0';
    $cli.add('CODEBUDDY.md').spurt("internal ai notes\n");
    mkdir-p($cli.add('internal'));
    $cli.add('internal/plan.md').spurt("internal plan\n");
    # 故意混入一条拼错的条目：打包不该失败，但必须提示到 stderr
    $cli.add('.distignore').spurt(
        "# 内部文档\nCODEBUDDY.md\nTYPO-DOES-NOT-EXIST.md\n"
    );
}

# 场景2：dist —— 列出的排除、未列出的照常进包、.distignore 自身不进包
{
    my ($code, $out, $err) = run-cli('dist', :cwd($cli.absolute));
    is $code, 0, '场景2：dist 退出码 0（拼错条目不阻断打包）';
    my $tgz = $cli.add('Foo-Ig-0.1.0.tar.gz');
    my @list = RakuPM::Author.tar-archive-list($tgz);
    ok @list.grep({ $_ eq 'CODEBUDDY.md' }) == 0,
        '场景2：.distignore 列出的文件不进包';
    ok @list.grep({ $_ eq 'internal/plan.md' }),
        '场景2：未列出的文件照常进包（清单是白名单式精确排除，不是整目录封杀）';
    ok @list.grep({ $_ eq '.distignore' }) == 0,
        '场景2：.distignore 自身不进包（隐藏项天然被排除）';
    ok $err.contains('没有匹配到任何文件') && $err.contains('TYPO-DOES-NOT-EXIST.md'),
        '场景3：写了却匹配不到任何文件的条目会提示到 stderr（防静默漏排除）';
}

# 收尾
sub rm-rec(IO::Path $x) {
    return unless $x.e;
    if $x.d { for $x.dir { rm-rec($_) }; try $x.rmdir }
    else    { try $x.unlink }
}
rm-rec($tmp);
