use v6.d;
use Test;

# preflight 是「提交前检查」命令：它本身不做任何校验，而是转调本仓库的
# tools/run-suite.raku --no-xt —— 与预提交钩子**共用同一份门禁实现**（不另起一套，
# 否则两套必然漂移）。本测试验证的是这条「转调」链路本身：
#   ① 命令能启动、找到仓库根、把结论打出来
#   ② 退出码从 run-suite 原样透传（这里用不存在的 --filter 收窄到 0 个用例 → 0）
#
# 刻意**不**在这里跑全量：全量由门禁自己去跑；测试里跑全量会拖慢整条链路，
# 而且 preflight 内部再跑一次套件会形成自我递归的观感。
# 也刻意带上 RAKUPM_NO_PRECOMP_WARMUP：xt/ 可能并行，避免与别的用例抢预编译缓存。

plan 4;

my IO::Path $root = $*PROGRAM.parent.parent.absolute.IO;
my IO::Path $bin  = $root.add('bin/raku-pm.raku');

ok $bin.f, '① 找到 bin/raku-pm.raku';

# 用文件重定向而不是 :out/:err 捕获 —— run-suite 会派生孙进程，
# 若共用一个管道，输出量一大就可能互相等死（项目里踩过这个坑）。
my IO::Path $out-f = $*TMPDIR.add("preflight-{$*PID}.out");
my IO::Path $err-f = $*TMPDIR.add("preflight-{$*PID}.err");

# run(:env) 是**替换**整个环境，故先克隆再覆盖，保留用户已有的 RAKULIB 等
my %env = %*ENV.Hash;
%env<RAKUPM_NO_PRECOMP_WARMUP> = '1';

# run 的 :out/:err 收的是【已打开的句柄】—— 直接给路径会被当文件名去打开，
# 报 "Failed to open file ...: No such file or directory"。
my $fh-out = $out-f.open(:w);
my $fh-err = $err-f.open(:w);
my $p = run('raku', $bin.Str, 'preflight', '--filter=__preflight_nonexistent__',
            :out($fh-out), :err($fh-err), :cwd($root), :env(%env));
my Int $code = $p.exitcode;
$fh-out.close;
$fh-err.close;

my Str $all = $out-f.slurp ~ $err-f.slurp;
$out-f.unlink if $out-f.e;
$err-f.unlink if $err-f.e;

is $code, 0, '① 0 个匹配用例时退出码 0（从 run-suite 透传）';
ok $all.contains('提交前检查'), '① 打出「提交前检查」抬头（说明真的转调了 run-suite）';
ok $all.contains('可以提交了'), '② 给出明确结论「可以提交了」';

done-testing;
