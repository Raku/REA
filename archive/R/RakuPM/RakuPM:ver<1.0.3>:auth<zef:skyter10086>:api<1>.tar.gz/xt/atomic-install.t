use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# P6 原子安装（用户可见的那一条语义）：
#   一次 install 要么完全生效、要么完全不生效。
#
# 场景：装 TopBad，它依赖 DepGood。解析顺序是 [DepGood, TopBad]
# （自底向上，依赖优先），DepGood 会先被装进 CUR；随后 TopBad 的测试失败。
# 没有事务时，target 会停在「DepGood 装了、TopBad 没装」的半截状态 ——
# 这正是 P6 要消灭的东西。有了事务，DepGood 也必须被摘掉，target 回到原样。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-atomic-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# ---- 仓库里的依赖包（本身没问题）----
my $repo-dir = $tmp.add('repo').mkdir;
my $dep-src  = $repo-dir.add('DepGood').mkdir;
$dep-src.add('lib').mkdir;
$dep-src.add('lib').add('DepGood.rakumod').spurt("unit module DepGood;\n");
$dep-src.add('META6.json').spurt(to-json({
    name => 'DepGood', version => '1.0', auth => 'demo:test',
    provides => { 'DepGood' => 'lib/DepGood.rakumod' },
    depends => {},
}, :sorted-keys));

# ---- 目标包：依赖 DepGood，但测试故意失败 ----
my $top-src = $tmp.add('TopBad').mkdir;
$top-src.add('lib').mkdir;
$top-src.add('lib').add('TopBad.rakumod').spurt("unit module TopBad;\n");
$top-src.add('t').mkdir;
$top-src.add('t').add('01-bad.t').spurt(
    "use Test;\n" ~
    "ok False, '故意失败：用来验证安装失败会整体回滚';\n" ~
    "done-testing;\n");
$top-src.add('META6.json').spurt(to-json({
    name => 'TopBad', version => '1.0', auth => 'demo:test',
    provides => { 'TopBad' => 'lib/TopBad.rakumod' },
    depends => { 'DepGood' => '*' },
}, :sorted-keys));

my $client = RakuPM::Client.new(
    :target($tmp.add('target')),
    :repos([RakuPM::Repository::Local.new(:root($repo-dir))]),
);

# 没错：整个安装应该失败（TopBad 测试不过）
dies-ok { $client.install-from-dir($top-src) },
        '安装失败：TopBad 的测试不过';

# 【P6 的核心断言】失败的这一次不能留下「装了一半」的状态
is $client.installer.installed-versions('TopBad').elems, 0,
   '回滚后：TopBad 没有留在 target 里';
is $client.installer.installed-versions('DepGood').elems, 0,
   '回滚后：先装成功的 DepGood 也被摘掉（原子：全有或全无）';
is $client.installer.list-generations.elems, 0,
   '失败的安装不产生世代';

# ---- 反面对照：把坏测试拿掉，同样的两个包就应该都装上 ----
$top-src.add('t').add('01-bad.t').unlink;
$top-src.add('META6.json').spurt(to-json({
    name => 'TopBad', version => '1.0', auth => 'demo:test',
    provides => { 'TopBad' => 'lib/TopBad.rakumod' },
    depends => { 'DepGood' => '*' },
}, :sorted-keys));

lives-ok { $client.install-from-dir($top-src) },
         '去掉坏测试后安装成功';
is $client.installer.installed-versions('TopBad').join(','),  '1.0',
   '成功后：TopBad 1.0 已装';
is $client.installer.installed-versions('DepGood').join(','), '1.0',
   '成功后：DepGood 1.0 已装（依赖优先，自底向上）';
is $client.installer.list-generations.elems, 1,
   '成功的安装留下 1 个世代';

done-testing;
