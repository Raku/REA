use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Fs;      # mkdir-p

# 【这不是修 bug，是钉住一个安全前提】
#
# 审计报告（AUDIT.md 的 M-1）指出 `Repository::Ecosystem.source-dir-for` 解压源码包时
# 是裸调 `tar -xzf`、没有任何安全标志，理论上恶意 tar 能写到 $dest 之外。
#
# 实测结论：**GNU tar / bsdtar 默认就拒绝**含 `..` 的成员与前导 `/` 的绝对路径 ——
# GNU tar 打印 "Removing leading `../' from member names" + "Member name contains '..'"
# 并以非零退出，一个文件都不解出来。所以当前**不可利用**：最坏结果是解压失败 →
# 装不上，而不是被写到目标目录外。（与本项目 1.0 审查时"归档路径穿越不可利用"的
# 实证结论一致。）
#
# 那为什么还要这个测试：上面那条前提**依赖 tar 实现的行为**，而它没有任何测试保护。
# 真正危险的是将来有人为了让某个包能装而加上 `-P`（保留绝对路径/`..`），或换成行为
# 宽松的实现 —— 那种改动不会让现有任何测试变红。这里把"含穿越成员的包不会写出
# 目标目录"钉死。
#
# 放在 xt/ 而不是 t/：它需要真实的 tar 可执行文件（外部工具），属于集成层。

my $base = $*TMPDIR.add("rakupm-tarescape-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

my $tar = 'tar';
{
    my $v = try { run($tar, '--version', :out, :err) };
    skip-rest "tar 不可用，跳过（前提不成立）" unless $v.defined && $v.exitcode == 0;
    $v.out.slurp(:close);
    $v.err.slurp(:close);
}

# 源文件放在 src/ 下；包里的成员名写成 `../escaped.txt` —— 若解压时被采纳，
# 它会落到 **$dest 的父目录**（也就是 $base）下，而不是 $dest 里。
my IO::Path $inner = $base.add('src').add('inner');
mkdir-p($inner);
$base.add('src').add('escaped.txt').spurt("PWNED\n");

# 造包：-P 强行保留 `..` 成员。
# 必须用【相对路径 + cwd】调用：Windows 上 GNU tar 会把参数里 `C:/…` 的 `C:` 当成
# 远程主机（host:file 语法），报 "Cannot connect to C:"（Ecosystem 里有同款注释）。
{
    # 输出包放到 $base 下（从 $base/src/inner 上溯两级），解压时就落在 $dest 的父目录
    my $p = run($tar, '-czPf', '../../evil.tar.gz', '../escaped.txt',
                :cwd($inner.Str), :out, :err);
    $p.out.slurp(:close);
    my Str $e = $p.err.slurp(:close);
    skip-rest "tar 连打包 `..` 成员都不允许（前提已天然成立）：{$e.lines.head(1) // ''}"
        unless $p.exitcode == 0;
    # 防"打包打到了别处"：包必须在预期位置，否则下面的解压测的是空气
    skip-rest "打包没有产出预期的 evil.tar.gz（路径算错了？）"
        unless $base.add('evil.tar.gz').e;
}

my IO::Path $dest = $base.add('dest');
mkdir-p($dest);

# 按 Ecosystem 的方式解压（-xzf + cwd），不带 -P
my $proc = run($tar, '-xzf', '../evil.tar.gz', :cwd($dest.Str), :out, :err);
$proc.out.slurp(:close);
my Str $err = $proc.err.slurp(:close);
diag "tar 解压退出码 {$proc.exitcode}；stderr 首行：{$err.lines.head(1) // '(无)'}";

# ★ 只看"有没有东西跑出 $dest" —— 不假设解压成败。不同实现可能"剥离后照常解出来"，
#   那同样是安全的；而"解压失败"更安全。不变量只有一个：**没有文件离开目标目录**。
nok $base.add('escaped.txt').e,
    '★ 没有文件被写到 $dest 之外（$base/escaped.txt 不存在）—— 穿越成员被 tar 拒绝或剥离';

done-testing;
