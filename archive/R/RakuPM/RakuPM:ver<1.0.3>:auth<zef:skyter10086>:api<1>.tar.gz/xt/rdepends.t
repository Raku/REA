use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# 反向依赖 + 卸载时的依赖回收（README「待实现」第 1、2 条）
#
# 依赖图：Top → Mid → Leaf（Top 是用户点名装的，Mid / Leaf 是被拉进来的）
#   · rdepends           反查谁依赖了我
#   · uninstall          还有包依赖我时拒绝（--force / --recursive 例外）
#   · autoremove         回收「作为依赖装进来、且现在没人依赖」的包
#
# 关键区分：只回收 reason='dependency' 的，用户点名装过的（explicit）永不回收 ——
# 没有这个区分，「自动回收」就变成「乱删」（apt 的 auto/manual 标记同款用意）。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-rdeps-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 造三个包：Top 依赖 Mid，Mid 依赖 Leaf
sub make-dist(Str $name, %deps --> IO::Path) {
    my $d = $tmp.add('repo').add($name).mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add("$name.rakumod").spurt("unit module $name;\n");
    $d.add('META6.json').spurt(to-json({
        name     => $name,
        version  => '1.0',
        auth     => 'demo:test',
        provides => { $name => "lib/$name.rakumod" },
        depends  => %deps,
    }, :sorted-keys));
    $d
}
my $repo = $tmp.add('repo').mkdir;
make-dist('Leaf', {});
make-dist('Mid',  { 'Leaf' => '*' });
make-dist('Top',  { 'Mid'  => '*' });

my $client = RakuPM::Client.new(
    :target($tmp.add('target')),
    :repos([RakuPM::Repository::Local.new(:root($repo))]),
);
my $inst = $client.installer;

$client.install('Top');

# ---------- 1) 三个都装上了，且目标包被标成 explicit ----------
for <Leaf Mid Top> -> $n {
    is $inst.installed-versions($n).join(','), '1.0', "$n 已安装 1.0";
}
my %top-entry = $inst.list-installed.first({ .<name> eq 'Top' });
my %mid-entry = $inst.list-installed.first({ .<name> eq 'Mid' });
is %top-entry<reason>, 'explicit',   'Top 是用户点名装的 → explicit';
is %mid-entry<reason>, 'dependency', 'Mid 是依赖拉进来的 → dependency';

# ---------- 2) 反向依赖 ----------
my @rd-mid = $inst.reverse-dependencies('Mid');
is @rd-mid.elems, 1, '有 1 个包依赖 Mid';
is @rd-mid[0]<name>, 'Top', '依赖 Mid 的是 Top';

my @rd-leaf = $inst.reverse-dependencies('Leaf');
is @rd-leaf.elems, 1, '有 1 个包依赖 Leaf';
is @rd-leaf[0]<name>, 'Mid', '依赖 Leaf 的是 Mid';

is $inst.reverse-dependencies('Top').elems, 0,
   '没有包依赖 Top（它在依赖图顶端）';

# ---------- 3) 全都还有人依赖 → 没有孤儿 ----------
is $inst.orphaned-dependencies.elems, 0,
   '依赖图完整时没有可回收的孤儿';

# ---------- 4) 卸载被依赖的包：默认拒绝（不留下坏掉的依赖） ----------
#
# 【0.87.3】拒绝现在是 **die**（把退出码带成 1），而不是「打印提示后静默 return」。
# 理由：拒绝卸载是「命令没办成」，rc 必须是 1，否则 `raku-pm uninstall X && …`
# 这种脚本会以为卸成功了继续往下跑（与「卸不存在的包也报成功」是同一个坑）。
# 所以这里用裸块 + CATCH 接住它 —— 注意不能用 `try {} CATCH {}` 组合：
# try 自己就把异常吞了，外层 CATCH 永不触发。
{
    my $rejected = False;
    {
        $client.uninstall('Mid');
    }
    CATCH { default { $rejected = True } }
    ok $rejected, '被 Top 依赖时卸载 Mid 被拒绝（0.87.3 起以 die 表达 → CLI rc=1）';
}
is $inst.installed-versions('Mid').join(','), '1.0',
   '被 Top 依赖时卸载 Mid 被拒绝（Mid 仍在，不会留下坏依赖）';

# ---------- 5) 卸掉 Top 后，Mid 变孤儿；autoremove 会连带回收 Leaf ----------
$inst.uninstall('Top');
is $inst.installed-versions('Top').elems, 0, 'Top 已卸载';

my @orphans = $inst.orphaned-dependencies.map(*<name>).sort;
is @orphans.join(','), 'Mid',
   'Top 没了以后，Mid 成为孤儿（Leaf 还被 Mid 依赖着，暂时不是）';

# autoremove：卸 Mid 会带出 Leaf 这个新孤儿，应循环到收敛
$client.autoremove;
is $inst.installed-versions('Mid').elems,  0, 'autoremove 回收了 Mid';
is $inst.installed-versions('Leaf').elems, 0, 'autoremove 连带回收了 Leaf（收敛到不再有孤儿）';
is $inst.orphaned-dependencies.elems, 0, '回收后没有残留孤儿';

# ---------- 6) 用户点名装的包，即使无人依赖也不回收 ----------
$client.install('Leaf');     # 这次是用户点名装的
is $inst.list-installed.first({ .<name> eq 'Leaf' })<reason>, 'explicit',
   '这次 Leaf 是 explicit';
is $inst.orphaned-dependencies.elems, 0,
   'explicit 的包即便无人依赖也不算孤儿（不会被 autoremove 误删）';

done-testing;
