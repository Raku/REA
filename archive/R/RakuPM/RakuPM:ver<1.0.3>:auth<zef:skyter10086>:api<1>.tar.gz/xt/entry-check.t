use Test;
use File::Temp;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Installer;
use RakuPM::Store;
use RakuPM::Fs;

# 入口体检：Windows 上 `raku-pm.exe`（zef/CUR 时代留下的）会遮蔽 raku-pm 自己写的
# bash/.bat wrapper —— PATHEXT 里 .EXE 优先，于是 self-upgrade 装完新版、账本与
# store 都更新了，用户敲 `raku-pm` 跑的还是旧版（本机实测 0.46.1）。
# 体检要认出「实际会被执行的那份」，把不是自己写的那个**改名备份**（可逆）。
#
# 放 xt/ 而非 t/：失败分支会打印 `⚠`，而 t/ 有洁净度硬约束（zef install 会跑 t/）。
#
# 【0.49.2：注入平台】场景 1-5 写的是 **Windows 语义**（靠 `.exe`/`.bat` 参与命令解析），
# 但原先没有注入 `$os` → 在 Linux 上 `pick-command-file` 只看无扩展名，一个都认不出来
# → 不接管 → 前两条断言全红（用户 WSL 现场：`raku tools/run-suite.raku` 报 xt/entry-check.t
# 挂了）。`ensure-bin-entry` 因此新增 `:$os` 注入口（与 `:@dirs` 同一惯例），
# 下面 Windows 场景统一写 `:os('win32')`、Unix 场景写 `:os('linux')` ——
# 于是任何宿主上两套语义都被真跑一遍，不再靠「开发机恰好是 Windows」。
plan 10;

my $root = $*TMPDIR.add("rakupm-entry-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }

my $inst = RakuPM::Installer.new(
    :target($root.add('target')),
    :store(RakuPM::Store.new(:root($root.add('store')))),
);

# ---------- 场景 1：残留的 .exe 遮蔽自写的 .bat ----------
{
    my $d = $root.add('bin1');
    mkdir-p($d);
    $d.add('raku-pm.exe').spurt('FAKE-OLD-EXE');
    $d.add('raku-pm.bat').spurt('FAKE-OUR-BAT');

    $inst.ensure-bin-entry('raku-pm', :dir($d), :os('win32'));

    ok !$d.add('raku-pm.exe').e, '场景1：遮蔽用的 .exe 已从原位置移走';
    ok $d.add('raku-pm.exe.zef-old').e, '场景1：以 .zef-old 备份保留（可逆，没删数据）';
    is $d.add('raku-pm.exe.zef-old').slurp, 'FAKE-OLD-EXE', '场景1：备份内容与原文件一致';
    ok $d.add('raku-pm.bat').e, '场景1：自写的 .bat 原样保留';
}

# ---------- 场景 2：幂等 ----------
{
    my $d = $root.add('bin1');
    my $before = $d.dir.map(*.basename).sort.List;
    $inst.ensure-bin-entry('raku-pm', :dir($d), :os('win32'));
    is $d.dir.map(*.basename).sort.List, $before, '场景2：重复执行幂等（不产生新文件）';
}

# ---------- 场景 3：本来就只有自写的 wrapper → 一个都不动 ----------
{
    my $d = $root.add('bin3');
    mkdir-p($d);
    $d.add('raku-pm').spurt('OUR-BASH');
    $d.add('raku-pm.bat').spurt('OUR-BAT');
    $inst.ensure-bin-entry('raku-pm', :dir($d), :os('win32'));
    is $d.dir.map(*.basename).sort.List, ('raku-pm', 'raku-pm.bat'),
       '场景3：全是自写的 → 不动手';
}

# ---------- 场景 4：没有自写 wrapper（promote 失败等）→ 也不能接管 ----------
# 否则把唯一入口改名走，用户会连命令都没有 —— 比遮蔽更糟。
{
    my $d = $root.add('bin4');
    mkdir-p($d);
    $d.add('raku-pm.exe').spurt('ONLY-EXE');
    $inst.ensure-bin-entry('raku-pm', :dir($d), :os('win32'));
    ok $d.add('raku-pm.exe').e, '场景4：没有自写 wrapper 时不接管（避免制造「没入口」）';
}

# ---------- 场景 5：别的命令不受牵连 ----------
{
    my $d = $root.add('bin5');
    mkdir-p($d);
    $d.add('raku-pm.bat').spurt('OURS');
    $d.add('zef.exe').spurt('OTHER-TOOL');
    $inst.ensure-bin-entry('raku-pm', :dir($d), :os('win32'));
    ok $d.add('zef.exe').e, '场景5：别的命令（zef.exe）不被牵连';
}

# ---------- 场景 6（Unix 语义）：`.exe` 在 Linux 上根本不参与命令解析 ----------
# 这条是「宿主混淆」的反向守护：同一份代码在 Unix 下必须**不认** .exe
# （Linux 的可执行文件没有扩展名约定），所以那种外来 .exe 不该被改名 ——
# 改名在 Linux 上毫无意义（它本来就永远不会被执行），还会白白改动别人的文件。
{
    my $d = $root.add('bin6');
    mkdir-p($d);
    $d.add('raku-pm').spurt('OUR-BASH');          # 自写的（Linux 上执行的就是它）
    $d.add('raku-pm.exe').spurt('FOREIGN-EXE');   # 外来，但 Linux 永不会执行它
    $inst.ensure-bin-entry('raku-pm', :dir($d), :os('linux'));
    ok $d.add('raku-pm.exe').e,
       '场景6：linux 下 .exe 原样保留（不参与命令解析，没理由改名）';
    nok $d.add('raku-pm.exe.zef-old').e,
       '场景6：linux 下没有产生 .zef-old 备份';
}
