use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;

# P6：原子安装 + 世代回滚（设计见《CUR 模块构建分析》§七，借鉴 Nix 的原子世代）
#
# 语义：
#   · 一次 install 要么完全生效、要么完全不生效 —— 任一包失败就把 target
#     恢复成本次操作前的样子，不留「装了一半」的坏状态。
#   · 每次成功落地留一个世代（installed.json 的快照 + 本次装了什么），
#     可 `raku-pm rollback` 退回。
#   · CUR 天然支持多版本并存，所以回滚只是「摘掉本次装的版本 + 恢复账本」，
#     世代因此只是几 KB 的 JSON，不用复制整个 site/。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-gens-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 造一个最小发行版：name / 版本 / 一个同名模块
sub make-dist(Str $name, Str $ver --> IO::Path) {
    my $d = $tmp.add("src-$name-$ver");
    $d.mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add("$name.rakumod").spurt("unit class $name;\nmethod hi \{ '$name $ver' \}\n");
    $d.add('META6.json').spurt(to-json({
        name        => $name,
        version     => $ver,
        auth        => 'test:me',
        api         => '1',
        description => "$name $ver",
        provides    => { $name => "lib/$name.rakumod" },
    }, :sorted-keys));
    $d
}

my $store = RakuPM::Store.new(:root($tmp.add('store')));
my $inst  = RakuPM::Installer.new(:target($tmp.add('target')), :store($store));

my $alpha-src = make-dist('Alpha', '1.0');
my $beta-src  = make-dist('Beta',  '1.0');
my $alpha = RakuPM::Distribution.from-meta-file($alpha-src.add('META6.json'));
my $beta  = RakuPM::Distribution.from-meta-file($beta-src.add('META6.json'));
$store.put($alpha, $alpha-src);
$store.put($beta,  $beta-src);

# ---------- 1) 事务回滚：装了又回滚 → target 回到原样，且不留世代 ----------
$inst.begin-transaction();
$inst.install($alpha);
ok $inst.installed-versions('Alpha').elems, '事务内：Alpha 已装进 CUR';
$inst.rollback-transaction();
is $inst.installed-versions('Alpha').elems, 0,
   '回滚后：Alpha 从 CUR 摘掉（target 恢复原状）';
is $inst.list-generations.elems, 0,
   '回滚不产生世代';

# ---------- 2) 提交：装 Alpha 并提交 → 产生世代 000001 ----------
$inst.begin-transaction();
$inst.install($alpha);
$inst.commit-transaction();
is $inst.installed-versions('Alpha').join(','), '1.0', '提交后：Alpha 1.0 已装';
is $inst.list-generations.elems, 1, '提交产生 1 个世代';
is $inst.current-generation, '000001', '当前世代是 000001';

# ---------- 3) 原子性：一个事务里装两个，回滚 → 两个都不留 ----------
# 关键是 Alpha【原本就已装】，回滚后它必须还在（由 store 补齐），
# 不能因为「本次事务也碰过它」就被一起摘掉。
$inst.begin-transaction();
$inst.install($alpha);          # 已存在的包，本次又装了一遍
$inst.install($beta);           # 新包
ok $inst.installed-versions('Beta').elems, '事务内：Beta 已装';
$inst.rollback-transaction();
is $inst.installed-versions('Beta').elems, 0,
   '回滚后：本次新装的 Beta 被摘掉';
is $inst.installed-versions('Alpha').join(','), '1.0',
   '回滚后：原本就有的 Alpha 仍在（账本快照 + store 补齐）';
is $inst.list-generations.elems, 1,
   '失败的本次事务不产生新世代';

# ---------- 4) 再提交一次 → 第二个世代 ----------
$inst.begin-transaction();
$inst.install($beta);
$inst.commit-transaction();
is $inst.list-generations.elems, 2, '第二次提交产生第 2 个世代';
is $inst.current-generation, '000002', '当前世代是 000002';
ok $inst.installed-versions('Beta').elems, 'Beta 已装';

# ---------- 5) 回滚到上一世代 → Beta 消失、Alpha 保留 ----------
$inst.rollback-to('000001');
is $inst.installed-versions('Beta').elems, 0,
   '退回世代 000001 后：Beta 被卸载';
is $inst.installed-versions('Alpha').join(','), '1.0',
   '退回世代 000001 后：Alpha 1.0 仍在';
is $inst.current-generation, '000001', '当前世代已切回 000001';

# ---------- 6) 世代列表带 current 标记 ----------
my @gens = $inst.list-generations;
is @gens.elems, 2, '仍是 2 个世代（回滚不新增世代，Nix 语义）';
is @gens.grep({ .<current> }).elems, 1, '恰有 1 个世代被标记为 current';
is @gens.first({ .<current> })<id>, '000001', '被标记 current 的是 000001';

done-testing;
