use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 集成测试（0.38.3 / 修订 0.80.0）：钉死「tester 的默认值」——这些在实现时各自
# 落了具体值，但当时没正式确认、也没写进文档。本测试把它们锁死，防止日后静默改掉：
#   ① 测试【串行】执行（0.80.0 起取消并发；输出行标明「N 个文件，串行」）；
#   ② 日志默认落在 <目标>/log/<包>/<版本>/，设 RAKUPM_TEST_LOG_DIR 可改根目录；
#   ③ 前台只印失败首行（唯一例外：嵌套编译错误会印出最内层病因行，见场景4），完整输出落日志；
#   ④ 超时默认 300s（已由 xt/tester-async.t 场景3 覆盖，本文件不重复）。
#
# 放 xt/：会跑真实 CLI 子进程，不进 zef install 的纯净度守卫（t/ 必须安静）。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $raku = $*EXECUTABLE.absolute;
my $bin  = $*PROGRAM.parent.parent.add('bin').add('raku-pm.raku').absolute;

my $tmp = $*TMPDIR.add('rakupm-tdefaults-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub mk-dist(Str $name, :$module-body, :@tests) {
    my $src = $tmp.add($name).mkdir;
    $src.add('lib').mkdir;
    my $body = $module-body.defined ?? $module-body !! "unit module $name;";
    $src.add('lib').add($name ~ '.rakumod').spurt($body);
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '0.1.0', auth => 'demo',
        provides => { $name => "lib/$name.rakumod" },
    }, :sorted-keys));
    if @tests {
        $src.add('t').mkdir;
        for @tests -> $p {
            $src.add('t').add($p.key).spurt($p.value);
        }
    }
    $src
}

# 跑一次真实 CLI，返回 (exitcode, stdout, stderr)。
sub run-cli(IO::Path $target, IO::Path $src, *@extra --> List) {
    my $p = run($raku, '-Ilib', $bin, 'install', $src.absolute,
                '--target=' ~ $target.absolute, '--no-build', |@extra,
                :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

plan 12;

# ---------- 场景 1：测试【串行】执行，输出标明文件数 ----------
# 0.80.0 起取消测试并发：一律串行。运行行形如「运行测试：Foo 0.1.0（3 个文件，串行）」。
my $srcPass = mk-dist('DefaultPass',
    tests => [
        '01.rakutest' => "use Test; plan 1; ok 1, 'a';\n",
        '02.rakutest' => "use Test; plan 1; ok 1, 'b';\n",
        '03.rakutest' => "use Test; plan 1; ok 1, 'c';\n",
    ]);
my ($ec1, $out1, $err1) = run-cli($tmp.add('tPass'), $srcPass);
is $ec1, 0, '场景1：3 个通过的测试 → 安装成功（exit 0）';
ok ($out1 ~ $err1) ~~ / '3 个文件，串行' /,
   '场景1：运行行标明「3 个文件，串行」';

# ---------- 场景 2：失败首行 + 日志落 <目标>/log/<包>/<版本>/ ----------
# 失败测试：stdout 第一行是 RAKUPM_FIRST_LINE，后面还有 RAKUPM_SECOND_LINE；
# 前台只应出现第一行，完整输出（含第二行）应进日志文件。
my $srcFail = mk-dist('DefaultLog',
    tests => [
        '01.rakutest' => "say 'RAKUPM_FIRST_LINE';\n" ~
                         "say 'RAKUPM_SECOND_LINE';\n" ~
                         "exit 1;\n",
    ]);
my $tgt2 = $tmp.add('tLog');
my ($ec2, $out2, $err2) = run-cli($tgt2, $srcFail);
isnt $ec2, 0, '场景2：测试失败 → 非零退出';
my $default-log = $tgt2.add('log').add('DefaultLog').add('0.1.0').add('01.rakutest.log');
ok $default-log.e, '场景2：日志默认落在 <目标>/log/<包>/<版本>/<测试>.log';
my $log2 = $default-log.e ?? $default-log.slurp !! '';
ok $log2.contains('RAKUPM_SECOND_LINE'),
   '场景2：完整输出（含第二行）写入日志文件';
ok ($out2 ~ $err2).contains('RAKUPM_FIRST_LINE'),
   '场景2：前台含失败首行';
ok ($out2 ~ $err2) !~~ / RAKUPM_SECOND_LINE /,
   '场景2：前台不含失败第二行（只印首行）';

# ---------- 场景 3：RAKUPM_TEST_LOG_DIR 改日志根目录 ----------
# 设全局日志根 → 日志应落 <全局>/log/<包>/<版本>/，而非 <目标>/log/。
my $global = $tmp.add('global-logs');
my $srcFail3 = mk-dist('DefaultLog3',
    tests => [
        '01.rakutest' => "say 'RAKUPM_FIRST_LINE';\n" ~
                         "say 'RAKUPM_SECOND_LINE';\n" ~
                         "exit 1;\n",
    ]);
my $tgt3 = $tmp.add('tLog3');
%*ENV<RAKUPM_TEST_LOG_DIR> = $global.absolute;
my ($ec3, $out3, $err3) = run-cli($tgt3, $srcFail3);
try %*ENV<RAKUPM_TEST_LOG_DIR>:delete;   # 用完即清，避免污染后续场景
isnt $ec3, 0, '场景3：测试失败 → 非零退出';
my $global-log = $global.add('log').add('DefaultLog3').add('0.1.0').add('01.rakutest.log');
ok $global-log.e, '场景3：设 RAKUPM_TEST_LOG_DIR 后日志改落全局根目录';
ok !$tgt3.add('log').add('DefaultLog3').add('0.1.0').add('01.rakutest.log').e,
   '场景3：默认 <目标>/log/ 下不再生成日志（根目录已重定向）';

# ---------- 场景 4：嵌套编译错误 → 前台印出【真正病因行】，而非只印外壳 ----------
# 背景（0.78.1）：Raku 编译失败时 stderr 是【嵌套】的 ——
#   ===SORRY!=== Error while compiling <测试文件>
#   ===SORRY!=== Error while compiling <模块.rakumod> (Some::Module)
#   Could not find Foo:ver<1.2+>:auth<zef:someone> in: …
# 开头连续的 SORRY 行只是外壳，病因在最内层。旧实现只印首行 → 用户只看得到一句
# 无信息量的 "Error while compiling t/…"（且日志目录在安装失败【回滚】时可能被
# 清空，等于彻底丢线索；实测 SBOM::Raku 0.0.14 正是如此）。本场景锁住新行为：
# 嵌套编译错误时前台必须出现最内层错误行，且不再单独印 SORRY 外壳行。
# （普通失败的「只印首行」契约由场景 2 继续钉着。）
my $srcNest = mk-dist('NestFail',
    module-body => "unit module NestFail;\n"
                 ~ "use NoSuch::Module:ver<1.0>:auth<zef:nobody>;\n",
    tests => [
        '01.rakutest' => "use NestFail;\nuse Test; plan 1; ok 1, 'never';\n",
    ]);
my ($ec4, $out4, $err4) = run-cli($tmp.add('tNest'), $srcNest,
                                  '--allow-test-failure');
my $fg4 = $out4 ~ $err4;
ok $fg4.contains('Could not find NoSuch::Module'),
   '场景4：嵌套编译错误 → 前台印出最内层病因行（不再只印 ===SORRY!=== 外壳）';
ok !$fg4.contains('| ===SORRY!==='),
   '场景4：不再把 SORRY 外壳行当失败详情印出';
