use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;

# upgrade-all 的统计恒真 bug —— 回归测试。
#
# 原实现：if try { self.upgrade($n, :$dry); True } // False
#         try 块的最后一句是字面 True，于是【失败】和【已是最新】统统被
#         计进 @upgraded，汇总永远显示「已更新 N 个」且 N 恒等于包总数 ——
#         用户完全看不出有没有包真的升了级、有没有包失败了。
#
# upgrade 的真实语义是三态：
#   · 返回 True  → 真的升/降了级
#   · 返回 False → 已是最新版，无需升级（不是失败！）
#   · 抛异常     → 升级失败
# 现在三态分别进 @upgraded / @skipped / @failed。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

# 抓 stdout（upgrade-all 是 --> Nil，只能通过输出断言它的分类结果）
sub capture-stdout(&body --> Str) {
    my $f  = $*TMPDIR.add('rakupm-out-' ~ $*PID ~ '-' ~ now.floor ~ '.txt');
    my $fh = $f.open(:w);
    my $orig = $*OUT;
    $*OUT = $fh;
    try { body() };
    $*OUT = $orig;
    $fh.flush; $fh.close;
    my $t = $f.slurp;
    try $f.unlink;
    $t
}

# 用子类把 upgrade 换成可控的桩：
#   True = 真的升了级 / False = 已是最新 / die = 失败
class StubClient is RakuPM::Client {
    has %.plan;
    method upgrade(Str $name, Str :$version = '', Bool :$only = False,
                   Bool :$dry = False --> Bool) {
        given %!plan{$name} {
            when 'upgraded' { True }
            when 'latest'   { say "$name 已是版本 1.0"; False }
            when 'fail'     { die "mock failure: $name" }
            default         { False }
        }
    }
}

my $tmp = $*TMPDIR.add('rakupm-upg-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my $target = $tmp.add('target');
$target.mkdir;
# 预置账本：三个包，都不带 source（带 source 会被当成「源码安装」直接跳过）
$target.add('installed.json').spurt(to-json([
    { name => 'PkgA', version => '1.0', versions => ['1.0'], auth => 'demo' },
    { name => 'PkgB', version => '1.0', versions => ['1.0'], auth => 'demo' },
    { name => 'PkgC', version => '1.0', versions => ['1.0'], auth => 'demo' },
], :sorted-keys));

my $client = StubClient.new(
    :target($target),
    :repos([RakuPM::Repository::Local.new(:root($tmp.add('repo').mkdir))]),
    :plan({ PkgA => 'upgraded', PkgB => 'latest', PkgC => 'fail' }),
);

my $out = capture-stdout({ $client.upgrade-all });

# ---------- 1. 三类各自计数正确（这是 bug 的核心） ----------
like $out, /'已更新 1 个'/, '已更新计数 = 1（只有 PkgA 真升级）';
like $out, /PkgA/,          '已更新列表里是 PkgA';
like $out, /'无需更新 1 个'/, '无需更新计数 = 1（PkgB 已是最新，不是失败）';
like $out, /'失败 1 个'/,    '失败计数 = 1（PkgC 抛异常）';
like $out, /PkgC/,          '失败列表里是 PkgC';

# ---------- 2. 关键：已是最新（False）不能被算成「已更新」 ----------
# 这是原 bug 最直接的体现：PkgB 返回 False，旧实现会把它计进 @upgraded，
# 于是「已更新」变成 2（PkgA+PkgB）而不是 1。
nok $out.contains('已更新 2 个'), '已是最新的包没被误算进「已更新」（原 bug 会显示 2）';
nok $out.contains('已更新 3 个'), '失败的包没被误算进「已更新」（原 bug 会显示 3）';

# ---------- 3. 全成功 / 全最新 的边界 ----------
{
    my $t2 = $tmp.add('target2'); $t2.mkdir;
    $t2.add('installed.json').spurt(to-json([
        { name => 'PkgX', version => '1.0', versions => ['1.0'], auth => 'demo' },
        { name => 'PkgY', version => '1.0', versions => ['1.0'], auth => 'demo' },
    ], :sorted-keys));
    my $c2 = StubClient.new(
        :target($t2),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('repo2').mkdir))]),
        :plan({ PkgX => 'upgraded', PkgY => 'upgraded' }),
    );
    my $o2 = capture-stdout({ $c2.upgrade-all });
    like $o2, /'已更新 2 个'/, '两个都升级 → 已更新 2';
    nok  $o2.contains('失败'),  '两个都升级 → 不出现失败字样';
}
{
    my $t3 = $tmp.add('target3'); $t3.mkdir;
    $t3.add('installed.json').spurt(to-json([
        { name => 'PkgZ', version => '1.0', versions => ['1.0'], auth => 'demo' },
    ], :sorted-keys));
    my $c3 = StubClient.new(
        :target($t3),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('repo3').mkdir))]),
        :plan({ PkgZ => 'latest' }),
    );
    my $o3 = capture-stdout({ $c3.upgrade-all });
    like $o3, /'已更新 0 个'/,  '已是最新 → 已更新 0';
    like $o3, /'无需更新 1 个'/, '已是最新 → 无需更新 1';
}

done-testing;