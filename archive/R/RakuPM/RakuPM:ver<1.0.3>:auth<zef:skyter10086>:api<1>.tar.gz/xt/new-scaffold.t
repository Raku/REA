# xt/new-scaffold.t — raku-pm new 脚手架端到端测试（真实 CLI 子进程）
#
# 跑真 `raku-pm new` 子进程，验证生成物与默认值。属于集成测试（启动整条模块图），
# 按项目纪律放 xt/（不污染 t/ 的洁净度）。
#
# 关键：run(:out,:err) 两个管道都必须 slurp(:close)，否则 Windows 句柄泄漏会让
# 子进程不退出、父进程挂死（见项目调试纪律）。

use Test;
use JSON::Fast;

my $raku = $*EXECUTABLE.absolute;
my $bin  = $*PROGRAM.parent.parent.add('bin').add('raku-pm.raku').absolute;

# 工作目录：所有 new 的生成物都落在它下面（模块名不同，互不覆盖）。
#
# 名字里带 $*PID 与时间戳两道：只靠 $*PID 会踩「PID 重用」—— 上一次跑留下的
# 目录还在，这一次同 PID 又撞上，场景1 的 `new Foo::Bar` 就会因「目标目录已存在」
# 而退出 1。本文件曾在套件里偶发失败，根因就是这个（单独跑却总是绿的）。
my $work = ($*TMPDIR // '/tmp'.IO).add("raku-pm-new-xt-{$*PID}-{now.Int}");
$work.mkdir;

# 用完就清：本文件以前不清，TMPDIR 里攒了十几个 raku-pm-new-xt-* 残骸，
# 也正是上面那个偶发失败的温床。
sub rm-tree(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        my @e = $p.dir;                    # 急切收集（Windows 目录句柄）
        rm-tree($_) for @e;
        try { $p.rmdir }
    }
    else { try { $p.unlink } }
}
LEAVE { rm-tree($work) if $work.e }

sub run-new(*@args) {
    # 注意参数顺序：模块名是位置参数，选项紧跟。cwd 设到工作目录。
    my $p = run($raku, '-Ilib', $bin, 'new', |@args, :cwd($work), :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err);
}

sub meta-of(IO::Path $d --> Hash) {
    my $f = $d.add('META6.json');
    return %() unless $f.e;
    my $parsed = try from-json($f.slurp);
    return ($parsed ~~ Associative) ?? $parsed !! %();
}

plan 23;

# 场景1：默认 new 生成完整骨架（无 --into 时目录名 = 模块名 ::→-）
{
    my ($code, $out, $err) = run-new('Foo::Bar');
    is $code, 0, '场景1：new Foo::Bar 退出 0';
    my $d = $work.add('Foo-Bar');
    ok $d.add('META6.json').e,        '场景1：生成 META6.json';
    ok $d.add('lib/Foo/Bar.rakumod').e, '场景1：生成 lib/Foo/Bar.rakumod';
    ok $d.add('t/01-basic.rakutest').e, '场景1：生成 t/01-basic.rakutest';
    ok $d.add('Changes').e,           '场景1：生成 Changes';
    ok $d.add('.gitignore').e,        '场景1：生成 .gitignore';
    nok $d.add('README.md').e,        '场景1：默认不带 --with-readme 故无 README.md';
    nok $d.add('bin').e,              '场景1：默认不带 --bin 故无 bin/';
    my %m = meta-of($d);
    is %m<name>,    'Foo::Bar',        '场景1：META6 name = Foo::Bar';
    is %m<version>, '0.1.0',           '场景1：META6 version 默认 0.1.0';
    # auth 默认取 RAKUPM_AUTHOR_AUTH 或 zef:skyter10086（任一都非空且含 ':'）；
    # 不绑定具体值，避免 CI 环境自带该变量的干扰。
    ok (%m<auth> ~~ Str && %m<auth>.chars && %m<auth> ~~ /':'/),
       '场景1：META6 auth 有默认且格式合法（含 :）';
    is %m<provides><Foo::Bar>, 'lib/Foo/Bar.rakumod',
       '场景1：META6 provides 指向正确相对路径';
}

# 场景2：目标目录已存在且非空，默认拒绝（不静默覆盖）
{
    my ($code, $out, $err) = run-new('Foo::Bar');   # Foo-Bar 已存在（场景1）
    isnt $code, 0, '场景2：重复 new 非零退出';
    like $err, /非空/, '场景2：stderr 提示目标目录非空';
}

# 场景3：--force 可覆盖同名脚手架文件
{
    my ($code, $out, $err) = run-new('Foo::Bar', '--force');
    is $code, 0, '场景3：--force 覆盖成功（退出 0）';
}

# 场景4：--bin / --auth / --version 全部生效
{
    my ($code, $out, $err) = run-new('Baz::Qux', '--bin=quxrun',
                                      '--auth=github:who', '--version=0.3.0');
    is $code, 0, '场景4：new Baz::Qux --bin/--auth/--version 退出 0';
    my $d = $work.add('Baz-Qux');
    ok $d.add('bin/quxrun.raku').e, '场景4：生成 bin/quxrun.raku';
    my %m = meta-of($d);
    is %m<auth>,    'github:who', '场景4：--auth 覆盖生效';
    is %m<version>, '0.3.0',      '场景4：--version 覆盖生效';
    is %m<bin>[0],  'bin/quxrun.raku', '场景4：META6 bin 含 bin/quxrun.raku';
}

# 场景5：--into 指定目录名（目录名不再由模块名推出）
{
    my ($code, $out, $err) = run-new('My::Mod', '--into=CustomDir');
    is $code, 0, '场景5：new My::Mod --into=CustomDir 退出 0';
    ok $work.add('CustomDir').add('META6.json').e, '场景5：用 --into 目录名生成';
    my %m = meta-of($work.add('CustomDir'));
    is %m<name>, 'My::Mod', '场景5：META6 name 仍是模块名 My::Mod（不受目录名影响）';
}
