use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;
use RakuPM::Builder;
use RakuPM::Fs;

# 回归：store 条目的构建痕迹「旁车」build.json，以及 verify 对它的检查。
#
# 【它补的是哪个洞】
# Store.!existing-resources 只把「磁盘上真实存在」的资源写进 store 的 META6
# （必须如此：声明了却找不到会让 CUR::Installation 装不上）。于是
# 「构建没跑成功 → 声明过的资源压根没生成」在元数据里被【静默剔除】——
# 事后看那份 META6 干干净净，verify 无从判断，只能干看着运行期崩。
# build.json 把「被剔掉的是哪些、构建阶段到底做了什么」记下来，
# 这一类问题才第一次变得可查。
#
# 【为什么 build.json 不进内容指纹】
# 它是「条目怎么产出的」的记录，不是发行版内容；带时间戳，计入指纹会让每次
# 重算都漂移、误报「内容已被修改」。所以它与 .digest 同级，被 !fingerprint 跳过。

my IO::Path $tmp = $*TMPDIR.add("rakupm-buildtrace-{$*PID}");
LEAVE rm-tree($tmp) if $tmp.e;

my $store   = RakuPM::Store.new(:root($tmp.add('store')));
my $inst    = RakuPM::Installer.new(:target($tmp.add('target')), :store($store));
my $builder = RakuPM::Builder.new;

sub make-src(Str $name, Bool :$builder = False, :@resources = () --> IO::Path) {
    my $d = $tmp.add("src-{$name}").mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add("{$name}.rakumod").spurt("unit module {$name};\n");
    my %m = (
        name     => $name,
        version  => '1.0',
        auth     => 'test:me',
        api      => '1',
        provides => { $name => "lib/{$name}.rakumod" },
        depends  => {},
    );
    %m<builder>   = 'RakuPM::Test::Builder' if $builder;
    %m<resources> = @resources.List        if @resources;
    $d.add('META6.json').spurt(to-json(%m, :sorted-keys));
    $d
}

sub trace-of(Str $name --> Hash) {
    my $f = $store.path-for($name, '1.0').add('build.json');
    return %() unless $f.e;
    (try { from-json($f.slurp) }) // %()
}

sub store-meta(Str $name --> Hash) {
    (try { from-json($store.path-for($name, '1.0').add('META6.json').slurp) }) // %()
}

# 资源文件名必须按【本平台】形状造（与 t/build.t / t/verify-consistency.t 同一套约定）
my $res-file = $*DISTRO.is-win ?? 'thing.dll'
             !! ($*DISTRO.name ~~ /mac|darwin/ ?? 'libthing.dylib' !! 'libthing.so');

# ---------- 1) 构建成功、资源齐备 ----------
my $s1 = make-src('Built', :builder, :resources['libraries/thing']);
$s1.add('resources').mkdir;
$s1.add('resources').add('libraries').mkdir;
$s1.add('resources').add('libraries').add($res-file).spurt('');
my $d1 = RakuPM::Distribution.from-meta-file($s1.add('META6.json'));

ok $builder.needs-build($s1, $d1), '声明了 builder → needs-build 为真';

my %f1 = $builder.facts($s1, $d1, :mode('built'), :ran, :ok);
is %f1<mode>,  'built',                 'facts：mode = built';
is %f1<ran>,   True,                    'facts：ran = True';
ok %f1<ok>,                             'facts：ok = True';
is %f1<needed>, True,                   'facts：needed = True';
is %f1<builder>, 'RakuPM::Test::Builder', 'facts：记下 builder 名（Legacy Build 文件另记 file）';
ok (%f1<raku> // '').chars,              'facts：记下构建用的 raku 可执行文件';

$store.put($d1, $s1, build => %f1);
my %t1 = trace-of('Built');
is %t1<build><mode>, 'built', 'build.json 记下构建模式';
is %t1<resources-declared>.List.raku, ('libraries/thing',).List.raku, 'build.json 记下声明的资源';
is %t1<resources-missing>.List.raku, ().List.raku, '资源齐备 → missing 为空';
ok (%t1<raku-version> // '').chars, 'build.json 记下编译器发行版号（预编译 / ABI 诊断要用）';
is store-meta('Built')<builder>, 'RakuPM::Test::Builder',
   'store 的 META6 保留了 builder —— 快照不再丢掉「这个包需要构建」这个事实';

ok $store.verify('Built', '1.0'), '条目内容自洽（verify 通过）';
$inst.install($d1);
is $inst.consistency-issues.grep({ .<name> eq 'Built' }).elems, 0,
   '构建正常 → 不产生任何构建类不一致';

# ---------- 2) 声明了资源但没产出（= 构建没跑成功）——此前完全不留痕 ----------
my $s2 = make-src('NoRes', :builder, :resources['libraries/ghost']);
my $d2 = RakuPM::Distribution.from-meta-file($s2.add('META6.json'));
my %f2 = $builder.facts($s2, $d2, :mode('built'), :ran, :ok);
$store.put($d2, $s2, build => %f2);

my %t2 = trace-of('NoRes');
is %t2<resources-missing>.List.raku, ('libraries/ghost',).List.raku,
   '资源没生成 → 原样记进 resources-missing（这就是此前被静默剔除、事后无从得知的那批）';
nok store-meta('NoRes')<resources>.List.first(* eq 'libraries/ghost'),
   'store 的 META6 仍然【不声明】它（声明了会让 CUR::Installation 装不上）—— 正因为如此才需要旁车';

$inst.install($d2);
my @i2 = $inst.consistency-issues.grep({ .<kind> eq 'missing-build-resource' });
is @i2.elems, 1, 'verify 报出 missing-build-resource（这条检查是本次新增的）';
ok @i2[0]<detail>.contains('libraries/ghost'), '报错里点名是哪个资源，不让人去猜';
nok @i2[0]<fixable>, '这类不可自动修复（要重装 / 看构建日志）';

# ---------- 3) 用 --no-build 装进去的 ----------
my $s3 = make-src('Skipped', :builder);
my $d3 = RakuPM::Distribution.from-meta-file($s3.add('META6.json'));
my %f3 = $builder.facts($s3, $d3, :mode('skipped-no-build'));
is %f3<ran>, False, 'facts：跳过时 ran = False（记录「跳过」而不是伪装成做过）';
$store.put($d3, $s3, build => %f3);
$inst.install($d3);
my @i3 = $inst.consistency-issues.grep({ .<kind> eq 'build-skipped' });
is @i3.elems, 1, '声明了 builder 却被 --no-build 跳过 → verify 报 build-skipped';

# ---------- 4) 本来就不需要构建 → 不该刷噪音 ----------
my $s4 = make-src('PlainX');
my $d4 = RakuPM::Distribution.from-meta-file($s4.add('META6.json'));
my %f4 = $builder.facts($s4, $d4, :mode('not-needed'));
is %f4<needed>, False, 'facts：无需构建时 needed = False';
$store.put($d4, $s4, build => %f4);
$inst.install($d4);
is $inst.consistency-issues.grep({ .<name> eq 'PlainX' }).elems, 0,
   '不需要构建的包不出任何构建类不一致（不刷噪音）';

# ---------- 5) 旧条目：声明了 builder 却没有痕迹 ----------
my $s5 = make-src('Legacy', :builder);
my $d5 = RakuPM::Distribution.from-meta-file($s5.add('META6.json'));
$store.put($d5, $s5);                                            # 不给构建事实
$store.path-for('Legacy', '1.0').add('build.json').unlink;       # 模拟 0.43.0 及更早装的条目
$inst.install($d5);
my @i5 = $inst.consistency-issues.grep({ .<kind> eq 'no-build-trace' });
is @i5.elems, 1, '没有构建痕迹、但声明了 builder → verify 报 no-build-trace';
nok @i5[0]<fixable>, '不可自动修复（旧条目的构建情况无从复原）';

# ---------- 6) build.json 是「旁车」：不参与内容指纹 ----------
my $bt = $store.path-for('Built', '1.0').add('build.json');
my $orig = $bt.slurp;
$bt.spurt('{"tampered":true}');
ok $store.verify('Built', '1.0'),
   '改写 build.json 不影响 verify —— 它按「条目怎么产出的记录」处理，不是发行版内容';
$bt.spurt($orig);

my $dig = $store.digest-of('Built', '1.0');
$store.put($d1, $s1, build => %f1);          # 重新入库：build.json 的时间戳必然变了
is $store.digest-of('Built', '1.0'), $dig,
   '重新入库得到同一个内容指纹（时间戳不参与指纹）';

done-testing;
