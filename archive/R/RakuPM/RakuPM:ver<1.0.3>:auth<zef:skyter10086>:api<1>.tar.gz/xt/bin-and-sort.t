use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Repository::Local;
use RakuPM::Client;

# 两个 bug 的回归：
#   1. bin 字段不被 CUR::Installation 自动处理 → $!target/bin/ 应当出现 wrapper；
#   2. installed-versions 字符串字典序排序 → 多版本装好后激活版本错了
#      （0.13.0 < 0.9.2 因为 '1' < '9'）。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-bin-sort-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# Windows 上 `bash` 默认解析到 C:\Windows\System32\bash.exe —— 那是 **WSL 启动器**，
# 不是 Git Bash。真正的 Git Bash 在 C:\Program Files\Git\bin\bash.exe，而 PowerShell
# 的 PATH 里只有 Git\cmd（里面没有 bash.exe），所以 PowerShell 下敲 bash 进的是 WSL。
#
# 这带来的后果：WSL bash 执行 Windows 路径（C:\...）的 wrapper 时路径语义不兼容 ——
# WSL 只认 /mnt/c/...。于是同一套测试在 Git Bash 下全绿（MSYS2 认 C:\...），
# 在 PowerShell 下必然假失败（跨 Windows/WSL 边界，不是 wrapper 的缺陷：wrapper
# 是给同环境用的 —— Windows 走 .bat，在 WSL 里生成的就是 POSIX 路径）。
#
# 检测必须是纯文件系统检查：绝不能执行 bash 来探测（一执行就启动 WSL）。
sub bash-is-wsl(--> Bool) {
    return False unless $*DISTRO.is-win;
    for (%*ENV<PATH> // '').split(';') -> $dir {
        next unless $dir.chars;
        my $cand = $dir.IO.add('bash.exe');
        next unless $cand.e;
        return so $cand.absolute ~~ /:i 'System32'/;
    }
    False
}

# ---------- 1. bin 字段被处理 ----------
{
    my $client = RakuPM::Client.new(
        :target($tmp.add('bin-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-b').mkdir))]),
    );
    my $src = $tmp.add('b-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('BMod.rakumod').spurt('unit module BMod;');
    $src.add('bin').mkdir;
    # 关键：脚本第一行是 shebang —— 装好后作为可执行命令能找到 raku 解释器
    $src.add('bin').add('mytool.raku').spurt(
        "#!/usr/bin/env raku\n" ~
        "use BMod;\n" ~
        "say \"mytool ran\";\n");
    $src.add('META6.json').spurt(to-json({
        name => 'BMod', version => '0.1', auth => 'demo',
        provides => { BMod => 'lib/BMod.rakumod' },
        bin => ['bin/mytool.raku'],
        depends => {},
    }, :sorted-keys));

    $client.install-from-dir($src, :no-test);

    my $bin-dir = $client.target.add('bin');
    ok $bin-dir.d, 'target/bin/ 创建出来了';

    my $wrapper = $bin-dir.add('mytool');
    ok ($wrapper.e || $wrapper.l),
       'mytool wrapper 出现（POSIX 软链或实际文件）';
    # 源脚本有 shebang
    my $read-back = $wrapper.l ?? $wrapper.resolve.Str.IO.slurp !! $wrapper.slurp;
    ok $read-back.contains('#!/usr/bin/env raku'),
       'wrapper 内容包含 shebang（无论软链还是复制）';
    ok $read-back.contains('say "mytool ran"'),
       'wrapper 内容是原脚本';

    # 没 bin 字段的发行版不应创建 wrapper 或破坏 bin/ 目录
    my $src-nobin = $tmp.add('nb-src').mkdir;
    $src-nobin.add('lib').mkdir;
    $src-nobin.add('lib').add('NoBin.rakumod').spurt('unit module NoBin;');
    $src-nobin.add('META6.json').spurt(to-json({
        name => 'NoBin', version => '1.0', auth => 'demo',
        provides => { NoBin => 'lib/NoBin.rakumod' },
        depends => {},
    }, :sorted-keys));
    $client.install-from-dir($src-nobin, :no-test);
    ok $bin-dir.d, '无 bin 字段时 bin/ 还在（不要被清空）';
    nok $bin-dir.add('nobin').e, '无 bin 字段时不应创建 wrapper';
}

# ---------- 2. installed-versions 按 semver 排序 ----------
# 关键案例：0.9.2 与 0.13.0 —— 字符串字典序里 0.13.0 < 0.9.2（'1' < '9'），
# 旧 sort 取到的「最高」是 0.9.2，是错的。
{
    my $client = RakuPM::Client.new(
        :target($tmp.add('sort-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-s').mkdir))]),
    );
    my $src = $tmp.add('s-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('SortProbe.rakumod').spurt('unit module SortProbe;');
    $src.add('META6.json').spurt(to-json({
        name => 'SortProbe', version => '0.9.2', auth => 'demo',
        provides => { SortProbe => 'lib/SortProbe.rakumod' },
        depends => {},
    }, :sorted-keys));
    $client.install-from-dir($src, :no-test);

    my @vs = $client.installer.installed-versions('SortProbe');
    is-deeply @vs, ['0.9.2'], '单版本：装 0.9.2';

    # 手工往账本里塞一个 0.13.0，模拟「已装 0.9.2、又装了一个新版本」
    my $json-path = $client.target.add('installed.json');
    my @list = from-json($json-path.slurp);
    my $entry = @list.first({ $_<name> eq 'SortProbe' });
    $entry<version> = '0.13.0';
    $entry<versions> = ['0.9.2', '0.13.0'];
    $json-path.spurt(to-json(@list, :sorted-keys));

    @vs = $client.installer.installed-versions('SortProbe');
    is-deeply @vs, ['0.9.2', '0.13.0'], '两版本按 semver 升序，不是字典序';

    is $client.installer.installed-version('SortProbe'), '0.13.0',
       '激活版本 = 最高版本（0.13.0，不是字典序里的 0.9.2）';

    # 再加一个更新版 1.0.0，确认三版本排序正确
    @list = from-json($json-path.slurp);
    $entry = @list.first({ $_<name> eq 'SortProbe' });
    $entry<version> = '1.0.0';
    $entry<versions> = ['0.9.2', '0.13.0', '1.0.0'];
    $json-path.spurt(to-json(@list, :sorted-keys));

    @vs = $client.installer.installed-versions('SortProbe');
    is-deeply @vs, ['0.9.2', '0.13.0', '1.0.0'], '三版本升序';
    is $client.installer.installed-version('SortProbe'), '1.0.0',
       '激活版本 = 最高 1.0.0';

    # 字符串字典序里 1.0.0 > 0.13.0 是 True，但 0.13.0 > 0.9.2 在字典序是 False；
    # semver 排序下三者的真正顺序是 0.9.2 < 0.13.0 < 1.0.0，旧 sort 会排成
    # 0.13.0 < 0.9.2 < 1.0.0 把 0.13.0 错当成「最低」。
}

# ---------- 3. 自装 RakuPM 生成「自包含 bash wrapper」 ----------
# 用户实测：自装后 ~/.raku-pm/bin/raku-pm 已经有了，但敲 `raku-pm` 仍然跑到
# zef 装的旧 wrapper（断链）。wrapper 必须自包含：
#   · 不靠 Raku 软链解析（不同版本 Raku 对 $*PROGRAM 的软链处理不一致）
#   · 不靠外部 RAKULIB（用户很少主动设）
#   · 不靠 $0 推断 lib/（复制品场景下 $0 在 ~/.raku-pm/bin 而 lib/ 在别处）
# 而要：
#   · hardcode target 绝对路径（target 一般 ~/.raku-pm 固定）
#   · 启动时挑 store/RakuPM 里最新版本
#   · 自动 export RAKULIB=inst#<target>/site
#   · exec raku <store/.../bin/raku-pm.raku>
{
    my $client = RakuPM::Client.new(
        :target($tmp.add('self-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-self').mkdir))]),
    );

    # 模拟自装 RakuPM（用一个简单测试 fixture：name=RakuPM、bin 字段是普通脚本）
    my $src = $tmp.add('self-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('RakuPM.rakumod').spurt('unit module RakuPM;');
    $src.add('bin').mkdir;
    # 原始脚本里的 shebang + use lib，模拟真实 raku-pm.raku 第一段
    $src.add('bin').add('raku-pm.raku').spurt(
        "#!/usr/bin/env raku\n" ~
        "use lib \$*PROGRAM.parent.parent.add('lib').Str;\n" ~
        "say \"REAL script ran\";\n");
    $src.add('META6.json').spurt(to-json({
        name => 'RakuPM', version => '0.99', auth => 'gitee:test',
        api => '1',
        provides => { RakuPM => 'lib/RakuPM.rakumod' },
        bin => ['bin/raku-pm.raku'],
        depends => {},
    }, :sorted-keys));

    $client.install-from-dir($src, :no-test);

    my $wrapper = $client.target.add('bin').add('raku-pm');
    ok $wrapper.e, 'wrapper 存在（~/.raku-pm/bin/raku-pm）';

    my $body = $wrapper.slurp;
    ok $body.starts-with("#!/usr/bin/env bash\n"), 'wrapper 是 bash 脚本（自包含）';
    ok $body.contains('export RAKULIB='),
       'wrapper 自动设 RAKULIB（不依赖外部环境变量）';
    ok $body.contains("TARGET='"),
       'wrapper hardcode 了 target 绝对路径（TARGET=...）';
    ok $body.contains("STORE='"),
       'wrapper hardcode 了 store 绝对路径（STORE=...，由 IO::Path 生成）';
    ok $body.contains("\$STORE/\$LATEST/bin/raku-pm.raku"),
       'wrapper 从 store 里挑最新版的 RakuPM 跑（STORE 前缀 + 运行时版本目录）';
    ok $body.contains('sort -V 2>/dev/null'),
       'wrapper 优先 GNU sort -V（semver）';
    ok $body.contains('| sort | tail -1'),
       'wrapper 有 BSD sort 兜底（macOS 没有 -V）';
    ok $body.contains("exec raku"),
       'wrapper 优先 PATH 里的 raku（command -v raku）';
    ok $body.contains("RAKUPM_RAKU="),
       'wrapper 硬编码了安装时的 raku 绝对路径（bash 子进程 PATH 找不到时的 fallback）';
    ok $body.contains('command -v raku'),
       'wrapper 用 command -v 检测 PATH 里的 raku（比 which 跨平台更稳）';

    # Windows：cmd/PowerShell 需要 .bat wrapper（zef 同款）
    if $*DISTRO.is-win {
        my $bat = $client.target.add('bin').add('raku-pm.bat');
        ok $bat.e, 'Windows 下额外生成 raku-pm.bat';
        my $bat-body = $bat.slurp;
        # 入口路径由 IO::Path.add 生成（Windows 上自动反斜杠），生成时就算好，
        # .bat 里不再用 %TARGET%\store\... 手写拼接。
        my $entry-abs = $client.target.add('store','RakuPM','0.99','bin','raku-pm.raku').absolute;
        ok $bat-body.contains('raku-pm.raku'), '.bat 指向真正入口脚本';
        ok $bat-body.contains('raku "' ~ $entry-abs ~ '"'),
           '.bat 直接调 raku（入口是 IO::Path 算出的绝对路径，不靠 where 探测）';
        # 0.49.0：wrapper 必须把前缀显式传给 CLI —— 否则 CLI 回落到默认前缀，
        # 而 .bat 设的 RAKULIB 指向自己那份 site（命令装进 A、模块从 B 找）。
        ok $bat-body.contains('"--target=' ~ $client.target.absolute ~ '"'),
           '.bat 把前缀显式传给 CLI（wrapper 属于哪个前缀就在哪个前缀里干活）';
        ok $bat-body.contains('if errorlevel 1'),
           '.bat 用 errorlevel 兜底（避免 cmd 的 && || 链陷阱）';
        ok $bat-body.contains('RAKUPM_RAKU='),
           '.bat 硬编码了安装时的 raku 路径（cmd 子进程找不到 raku 时的 fallback）';
        nok $bat-body.contains('where raku'),
           '.bat 不再用 where 探测 raku（where.exe 在 Git Bash 风格 PATH 下不可靠）';

        # fallback 行引号必须精确：`"%RAKUPM_RAKU%" "<入口绝对路径>" %*`
        # （错误形态是 `""%RAKUPM_RAKU%" ... %*"` —— 前导/尾随各多一个引号，
        # cmd 里是语法错误）。contains 抓不到这种多余引号（子串仍匹配），
        # 所以：正向 contains + 两个 nok 负向抓多余引号，最直白不易错。
        ok $bat-body.contains('"%RAKUPM_RAKU%" "' ~ $entry-abs ~ '" "--target='),
           '.bat fallback 主体正确（"%RAKUPM_RAKU%" 引号包裹 + 绝对路径 + 前缀 + %* 透传）';
        nok $bat-body.contains('""%RAKUPM_RAKU%'),
           '.bat fallback 无多余前导引号（不会出现 ""%VAR%"）';
        nok $bat-body.contains('%*"'),
           '.bat fallback 无多余尾随引号（不会出现 %*"）';
    }

    # wrapper 一定不是原脚本（不再依赖 *PROGRAM.parent.parent）
    nok $body.contains('*PROGRAM.parent.parent.add'),
       'wrapper 不再依赖源脚本里的 *PROGRAM 路径推断';
    nok $body.contains('REAL script ran'),
       'wrapper 不是原脚本（已被替换）';
}

# ---------- 4. detect-bin-on-path 扫 PATH 候选 ----------
# 用户的实测场景：zef 装过 raku-pm 留下 rakudo/share/perl6/site/bin/raku-pm 软链，
# 后来旧版被清；敲 `raku-pm` 命中它就报 "No such file or directory"。
# 我们的 show-env 应该列出所有候选并建议清理。
# 简化版：只用 which/where，不碰 cygpath。
{
    my $bin = $*TMPDIR.add("rakupm-fake-bin-{ $*PID }");
    try $bin.rmdir;
    $bin.mkdir;
    my $real-fake = $bin.add('raku-pm');
    $real-fake.spurt("#!/bin/bash\n# fake\n");
    try $real-fake.chmod(0o755);
    # Windows 的 where 只找标准可执行扩展名，额外创建 .bat 让 where 能搜到
    if $*DISTRO.is-win {
        $bin.add('raku-pm.bat').spurt("@echo off\nrem fake\n");
    }

    my $self-bin = $*TMPDIR.add("rakupm-self-bin-{ $*PID }");
    my $self-target = $self-bin.add('bin').mkdir;
    my $self-wrapper = $self-target.add('raku-pm');
    $self-wrapper.spurt("#!/bin/bash\n# self\n");
    try $self-wrapper.chmod(0o755);
    if $*DISTRO.is-win {
        $self-target.add('raku-pm.bat').spurt("@echo off\nrem self\n");
    }

    # 把 fake-bin 加到 PATH 前面让 which/where 能找到
    my $old-path = %*ENV<PATH>;
    my $sep = $*DISTRO.is-win ?? ';' !! ':';
    %*ENV<PATH> = "{$bin.absolute}{$sep}{ $old-path }";
    LEAVE { %*ENV<PATH> = $old-path;
            try $self-bin.rmdir if $self-bin.d }

    my $client = RakuPM::Client.new(
        :target($self-target.parent),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-p').mkdir))]),
    );
    my @cands = $client.detect-bin-on-path('raku-pm');
    ok @cands.elems >= 1, '扫到至少一个候选';

    my $first = @cands[0];
    ok $first, '第一个候选路径存在';
    ok $first<path> ~~ /raku\-pm/, '第一个候选路径正确';
    ok ($first<status> eq 'real-file' || $first<status> eq 'symlink-ok'),
       "状态识别正确（real-file 或 symlink-ok），实际={$first<status>}";
    nok $first<ours>, 'fake-bin 不是自装的';
}

# ---------- 5. site-bin-dir + promote-to-site-bin（zef 同款：装完即用）----------
# zef 把 bin wrapper 放进 <rakudo>/share/perl6/site/bin/（默认在 PATH 上），
# 所以 `zef install Foo` 装完命令立即可用。我们模仿：wrapper 复制一份到
# site-bin-dir。测试不碰真实 rakudo —— 注入假 chain / 假 site-bin。
{
    my $client = RakuPM::Client.new(
        :target($tmp.add('promote-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-pr').mkdir))]),
    );
    my $installer = $client.installer;

    # site-bin-dir 从注入的 chain 里挑 basename == 'site' 的仓库
    my $fake-site = $tmp.add('fake-rakudo').add('share').add('perl6').add('site');
    $fake-site.mkdir;
    my $fake-chain = [
        CompUnit::Repository::Installation.new(:prefix($fake-site.absolute)),
        # 另一个不像 site 的仓库（应被跳过）
        CompUnit::Repository::Installation.new(
            :prefix($tmp.add('fake-vendor').mkdir.absolute)),
    ];
    my $found = $installer.site-bin-dir(:chain($fake-chain));
    is $found.absolute, $fake-site.add('bin').absolute,
       'site-bin-dir：chain 里挑 basename==site 的仓库的 bin/';

    # promote：把一个 wrapper 复制进 site-bin
    my $wrapper = $tmp.add('promote-target').add('bin').add('raku-pm');
    $wrapper.parent.mkdir;
    $wrapper.spurt("#!/usr/bin/env bash\necho demo\n");
    try $wrapper.chmod(0o755);

    my $ok = $installer.promote-to-site-bin($wrapper, :site-bin($fake-site.add('bin')));
    ok $ok, 'promote 到假 site-bin 成功';
    ok $fake-site.add('bin').add('raku-pm').e, 'wrapper 出现在假 site/bin/ 下';
    ok $fake-site.add('bin').add('raku-pm').slurp.contains('demo'),
       'promote 的是同一个 wrapper（内容一致）';

    # 兜底：chain 里没有 site 时退回第一个 Installation 仓库
    my $only-vendor = [CompUnit::Repository::Installation.new(
        :prefix($tmp.add('only-vendor').mkdir.absolute))];
    is $installer.site-bin-dir(:chain($only-vendor)).absolute,
       $tmp.add('only-vendor').add('bin').absolute,
       'chain 无 site → 退回第一个 Installation 仓库';
}

# ---------- 6. 真跑自装 wrapper（模拟 Linux/WSL：装完即用）----------
# 前面测的都是「wrapper 文件长什么样」；这一段真的拿 bash 跑一遍生成的
# wrapper —— 证明自装后敲 `raku-pm`（即 target/bin/raku-pm）能定位 store
# 里的 RakuPM 副本、设好 RAKULIB 并 exec raku。
# Git Bash / Linux / macOS 都有 bash；缺 bash 或 raku 就跳过。
{
    # PowerShell 下 bash 是 WSL 启动器 → 不能用（详见文件顶部 bash-is-wsl 的注释）
    my $has-bash = !bash-is-wsl()
        && (try { run('bash', '--version', :out, :err).exitcode == 0 } // False);
    # 必须用 bash 找 raku：run('raku') 走 Windows API 找 raku.exe，
    # 但 wrapper 在 bash 子进程里 `exec raku`，bash 用自己的 PATH 解析。
    my $has-raku = $has-bash
        ?? (try { run('bash', '-c', 'raku --version', :out, :err).exitcode == 0 } // False)
        !! False;

    # 关键：Raku 的 skip **只标记跳过测试，不会中断后面的代码**——
    # 只写 `skip ... unless ...` 的话，下面 run('bash', ...) 照样执行
    # （PowerShell 下那就是启动 WSL，跨边界路径不兼容，必然假失败）。
    # 所以必须真用 if/else 把 body 包起来。
    if $has-bash && $has-raku {

    my $client = RakuPM::Client.new(
        :target($tmp.add('exec-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-ex').mkdir))]),
    );

    # fixture：真实自装形态（bin/raku-pm.raku 打印自身信息，不依赖 RakuPM::Client）
    my $src = $tmp.add('exec-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('RakuPM.rakumod').spurt('unit module RakuPM;');
    $src.add('bin').mkdir;
    # 注意：
    #   1. 内容必须用单引号 heredoc（q:to）——双引号里 %*ENV<RAKULIB> 会被
    #      Raku hash 插值成空，生成的脚本直接编译错；
    #   2. 别用 `//` defined-or —— Raku 会把它解析成空 regex，用 ?? !!。
    my $rakusrc = q:to/RAKUSRC/;
#!/usr/bin/env raku
say "MARKER-SRC ", $*PROGRAM.IO.basename;
my $rl = %*ENV<RAKULIB>;
say "MARKER-RAKULIB ", ($rl.defined ?? $rl !! '(none)');
RAKUSRC
    $src.add('bin').add('raku-pm.raku').spurt($rakusrc);
    $src.add('META6.json').spurt(to-json({
        name => 'RakuPM', version => '0.99', auth => 'gitee:test', api => '1',
        provides => { RakuPM => 'lib/RakuPM.rakumod' },
        bin => ['bin/raku-pm.raku'], depends => {},
    }, :sorted-keys));

    $client.install-from-dir($src, :no-test);

    my $wrapper = $client.target.add('bin').add('raku-pm');
    ok $wrapper.e, '自装后 wrapper 存在';

    my $proc = run('bash', $wrapper.Str, :out, :err);
    my $out  = $proc.out.slurp(:close);
    is $proc.exitcode, 0, '直接跑 wrapper 退出码 0（bash，模拟 Linux 形态）';
    ok $out.contains('MARKER-SRC raku-pm.raku'),
       'wrapper 定位并 exec 了 store 里的 raku-pm.raku（不是复制品/断链）';
    ok $out.contains('MARKER-RAKULIB inst#'), 'wrapper 自动设好了 RAKULIB';
    }
    else {
        skip '环境无 bash（或 bash 是 WSL 启动器）或 bash 里找不到 raku，跳过端到端执行', 3;
    }
}

# ---------- 7. macOS：BSD sort 没有 -V 时 wrapper 仍能跑 ----------
# wrapper 里挑最新版本用 `sort -V`（GNU 扩展）；macOS 自带的 BSD sort 遇到
# -V 会报错且无输出。伪造一个「无 -V 的 sort」放 PATH 最前，模拟 macOS，
# 验证 wrapper 退回字典序后仍能定位 RakuPM 并执行。
{
    my $has-bash = !bash-is-wsl()
        && (try { run('bash', '--version', :out, :err).exitcode == 0 } // False);
    my $has-raku-in-bash = $has-bash
        ?? (try { run('bash', '-c', 'raku --version', :out, :err).exitcode == 0 } // False)
        !! False;

    # 同 section 6：skip 不会中断代码，必须真用 if/else 包住 body
    if $has-raku-in-bash {

    # 复用 section 6 的 target（已在 store 里放了 RakuPM 0.99）
    my $client = RakuPM::Client.new(
        :target($tmp.add('exec-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-ex2').mkdir))]),
    );
    my $wrapper = $client.target.add('bin').add('raku-pm');
    ok $wrapper.e, 'wrapper 还在（与前一段同一 target）';

    # fakebin/sort：凡是带 -V 就直接失败（模拟 BSD sort），否则委托真 sort
    my $fakebin = $tmp.add('fake-bsd-bin').mkdir;
    my $fake-sort = $fakebin.add('sort');
    $fake-sort.spurt("#!/usr/bin/env bash\n" ~
        "for a in \"\$@\"; do\n" ~
        "    if [ \"\$a\" = \"-V\" ]; then\n" ~
        "        exit 1\n" ~
        "        fi\n" ~
        "    done\n" ~
        "exec /usr/bin/sort \"\$@\"\n");
    try $fake-sort.chmod(0o755);

    my $old-path = %*ENV<PATH>;
    %*ENV<PATH> = "$fakebin.absolute:{ $old-path }";
    LEAVE { %*ENV<PATH> = $old-path }

    # Git Bash 的 which/bash 子进程要 POSIX 形态的 PATH —— 上面拼的是 Windows
    # 路径，Raku run 的子进程（bash）看得到 env，但 Windows 反斜杠在 bash 里
    # 不认。把 fakebin 转成 POSIX 再拼。
    # 注意 `try { run(...).out.slurp.trim } // 兜底` 这个写法是**错的**：
    # cygpath 不存在时 run 不抛异常，.out 返回 Nil，Nil.slurp → ""，.trim → "",
    # 整条链不抛错、try 不激活，结果是空字符串（defined），`//` 兜底不生效。
    # 必须显式查退出码 + .chars 判空（0.18.3 踩过同一个坑）。
    my $fake-posix = '';
    try {
        my $p = run('cygpath', '-u', $fakebin.absolute.Str, :out, :err);
        if $p.defined && $p.exitcode == 0 {
            my $got = $p.out.slurp(:close).trim;
            $fake-posix = $got if $got.chars;
        }
    }
    $fake-posix = $fakebin.absolute.Str unless $fake-posix.chars;
    %*ENV<PATH> = "$fake-posix:$old-path";

    my $proc = run('bash', $wrapper.Str, :out, :err);
    my $out  = $proc.out.slurp(:close);
    is $proc.exitcode, 0, 'BSD sort 无 -V：wrapper 兜底后仍正常执行';
    ok $out.contains('MARKER-SRC raku-pm.raku'),
       '字典序兜底也定位到了正确的 raku-pm.raku';
    }
    else {
        skip '环境无 bash（或 bash 是 WSL 启动器）或 bash 里找不到 raku，跳过 macOS sort 模拟', 2;
    }
}

# ---------- 8. Windows: 真跑 .bat wrapper ----------
# 用户的实测场景：v0.20.1 在 WSL 下 OK，但在 Windows pwsh 下失败。
# 根因：.bat wrapper 用 `where raku && (raku ...) || (RAKUPM_RAKU ...)`，
# where.exe 不认 Git Bash 风格的 /c/... 路径，find 不到就直接退出，
# 不触发 fallback。修复后改成「直接调 raku，靠 if errorlevel 1 兜底」。
# 这一段真的把 .bat 跑起来，验证 fallback 链路真的有效。
if $*DISTRO.is-win {
    my $client = RakuPM::Client.new(
        :target($tmp.add('bat-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-bat').mkdir))]),
    );

    my $src = $tmp.add('bat-src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add('RakuPM.rakumod').spurt('unit module RakuPM;');
    $src.add('bin').mkdir;
    my $raku-src = q:to/RAKUSRC/;
#!/usr/bin/env raku
say "BAT-MARKER-SRC ", $*PROGRAM.IO.basename;
say "BAT-MARKER-RAKULIB ", (%*ENV<RAKULIB> // '(none)');
RAKUSRC
    $src.add('bin').add('raku-pm.raku').spurt($raku-src);
    $src.add('META6.json').spurt(to-json({
        name => 'RakuPM', version => '0.99', auth => 'gitee:test', api => '1',
        provides => { RakuPM => 'lib/RakuPM.rakumod' },
        bin => ['bin/raku-pm.raku'], depends => {},
    }, :sorted-keys));

    $client.install-from-dir($src, :no-test);

    my $bat = $client.target.add('bin').add('raku-pm.bat');
    ok $bat.e, '.bat wrapper 存在';

    # 在 cmd 子进程里执行 .bat：拿退出码和输出（不要直接 run .bat —— Raku 的
    # run() 调 .bat 时会用 cmd.exe 间接执行，但 PATH/参数传递在 Windows 上
    # 行为很迷；显式指定 cmd.exe /c 最稳）
    #
    # 不能用 `where raku` 测试 PATH 是否能找到 raku：
    #   - 用户的 raku 装在 Git Bash 风格的 /c/... 路径下，where.exe 找不到
    #   - 这正是 .bat 要兜底的原因
    # 直接靠 RAKUPM_RAKU 兜底路径（绝对路径，绝对有效）。
    # cmd 的输出可能是 Windows 代码页（非 UTF-8），用 :bin 避免解码失败
    my $proc = run('cmd.exe', '/c', $bat.Str, :out, :err, :bin);
    my $out  = $proc.out.slurp(:close).decode('utf-8-c8');
    my $err  = $proc.err.slurp(:close).decode('utf-8-c8');
    ok $proc.exitcode == 0, ".bat 退出码 0（RAKUPM_RAKU 兜底），实际={$proc.exitcode}, stderr={$err}";
    ok $out.contains('BAT-MARKER-SRC raku-pm.raku'),
       ".bat 定位并 exec 了 store 里的 raku-pm.raku";
    ok $out.contains('BAT-MARKER-RAKULIB inst#') && $out.contains('\\site'),
       '.bat 自动设好了 RAKULIB';

    # —— 核心回归测试：真跑 fallback ——
    # 模拟用户在 pwsh 下遇到的场景：cmd 的 PATH 里没有 raku → 第一行 `raku`
    # 失败（errorlevel 非 0）→ 走 `if errorlevel 1` fallback（RAKUPM_RAKU 绝对路径）。
    #
    # 【为什么不用 :env 屏蔽 PATH —— 一个让测试假绿的坑】
    # 之前用 run(:env(%no-raku-env)) 把子进程 PATH 换成不含 raku 的。实测
    # **Raku 的 run(:env) 在 Windows 下不可靠**：传 %*ENV 的**拷贝**时子进程
    # 仍然继承父进程 PATH（只有传全新 Hash 才生效）。于是「屏蔽 PATH」根本没
    # 成立、fallback 从未被触发 —— 测试在 PowerShell 下假绿，在 Git Bash 下
    # 才真跑，正是「测试跑通 ≠ 覆盖真实分支」的典型。
    # 探针证据：:env 传 %*ENV 拷贝 → 子进程 `echo %PATH%` 输出的仍是父 PATH。
    #
    # 所以改成**直接改 .bat 内容**：把第一行的命令名换成一个必然不存在的，
    # 强制第一行失败，从而必然走 fallback 分支。不依赖任何环境传递。
    my $entry-abs = $client.target.add('store','RakuPM','0.99','bin','raku-pm.raku').absolute;
    my $no-raku-cmd = 'raku-NOPE-not-a-real-command';

    my $fallback-bat = $client.target.add('bin').add('raku-pm-fallback.bat');
    $fallback-bat.spurt($bat.slurp.lines.map({
        $_.starts-with('raku "')
            ?? $no-raku-cmd ~ ' "' ~ $entry-abs ~ '" %*'
            !! $_
    }).join("\r\n"));

    my $proc3 = run('cmd.exe', '/c', $fallback-bat.Str, :out, :err, :bin);
    my $out3  = $proc3.out.slurp(:close).decode('utf-8-c8');
    my $err3  = $proc3.err.slurp(:close).decode('utf-8-c8');
    ok $proc3.exitcode == 0,
       "fallback 真跑成功（第一行命令不存在→errorlevel→RAKUPM_RAKU 兜底），exit={$proc3.exitcode}，stderr={$err3}";
    ok $out3.contains('BAT-MARKER-SRC raku-pm.raku'),
       'fallback 也定位并 exec 了 store 里的 raku-pm.raku（不是崩溃）';

    # 额外验证：两条路都失效（第一行命令不存在 + RAKUPM_RAKU 指向不存在的路径）
    # 时，wrapper 应干净地失败（非 0），而不是崩出 cmd 语法错误。
    my $bad-bat = $client.target.add('bin').add('raku-pm-bad.bat');
    $bad-bat.spurt($bat.slurp.lines.map({
        $_.starts-with('raku "')
            ?? $no-raku-cmd ~ ' "' ~ $entry-abs ~ '" %*'
            !! ($_.starts-with('set "RAKUPM_RAKU=')
                    ?? 'set "RAKUPM_RAKU=C:\nonexistent\raku.exe"'
                    !! $_)
    }).join("\r\n"));
    my $proc2 = run('cmd.exe', '/c', $bad-bat.Str, :out, :err, :bin);
    ok $proc2.exitcode != 0,
       "两条路都失效时干净退出（非 0），exit={$proc2.exitcode}";
}

# ---------- 9. `raku-pm env` 的 PATH 候选列表不能崩 ----------
# 用户实测：跑 `raku-pm env` 直接崩
#     No such method 'pad' for string 'real-file'
# 根因：Raku 的 Str **没有 .pad 方法**（那是别的语言的 API），
# 左对齐要用 .fmt('%-Ns')。这段代码只在「PATH 里真的存在 raku-pm 候选」时
# 才走到，而以前从没有测试覆盖过它 —— 又一个「没被覆盖的分支」。
#
# 所以这条测试必须**先确认候选列表那段真的执行了**（断言输出里有那行标题），
# 否则一旦 PATH 没设成功，show-env 会提前 return，测试就成了假绿。
{
    my $bin = $*TMPDIR.add("rakupm-env-bin-{ $*PID }");
    try $bin.rmdir;
    $bin.mkdir;
    $bin.add('raku-pm').spurt("#!/bin/bash\n# fake\n");
    try $bin.add('raku-pm').chmod(0o755);
    # Windows 的 where 只认标准可执行扩展名，额外建 .bat 才能被搜到
    $bin.add('raku-pm.bat').spurt("@echo off\nrem fake\n") if $*DISTRO.is-win;

    my $old-path = %*ENV<PATH>;
    my $sep = $*DISTRO.is-win ?? ';' !! ':';
    %*ENV<PATH> = "{$bin.absolute}{$sep}{ $old-path }";
    LEAVE { %*ENV<PATH> = $old-path }

    my $client = RakuPM::Client.new(
        :target($tmp.add('env-target')),
        :repos([RakuPM::Repository::Local.new(:root($tmp.add('empty-repo-env').mkdir))]),
    );

    # show-env 用的是 say（写 $*OUT）。临时把 $*OUT 换成文件句柄来捕获输出，
    # 顺带验证整个过程不抛异常。
    my $out-file = $tmp.add('env-out.txt');
    {
        my $fh = $out-file.open(:w);
        my $*OUT = $fh;
        $client.show-env;
        $fh.close;
    }
    my $out = $out-file.slurp;

    ok $out.contains('RAKULIB'), 'show-env 输出了 RAKULIB 设置';
    # 关键前提：候选列表那段真的走到了（不然这条测试等于没测）
    ok $out.contains('PATH 中的 raku-pm 候选'),
       'show-env 真的走到了候选列表分支（PATH 里有 raku-pm 候选）';
    nok $out.contains('No such method'),
       'show-env 没有 "No such method" 崩溃（Str.pad 那类 API 误用）';
    ok $out.contains('raku-pm'), '候选列表里列出了 raku-pm 的路径';
}

done-testing;
