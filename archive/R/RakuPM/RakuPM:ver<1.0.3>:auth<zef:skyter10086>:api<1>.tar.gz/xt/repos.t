use Test;
use RakuPM::Repositories;
use RakuPM::Client;
use JSON::Fast;

# 用 done-testing 而不是 plan N：这里用例是按场景分块写的，
# 写死数量每次加场景都要同步改，容易对不上。

# ---------- 纯配置层 ----------

my $tmp = $*TMPDIR.add('rakupm-repos-test-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
# Raku 的 IO::Path 没有 rmtree，自己写一个递归删除
sub rmrf(IO::Path $p --> Nil) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir.List;   # 先 materialize，边遍历边删会出问题
        $p.rmdir;
    }
    else {
        $p.unlink;
    }
}
END { rmrf($tmp) }

my $cache = $tmp.add('cache');
my $cfg   = $tmp.add('repositories.json');

# 1-3 默认配置：zef + cpan + rea 三个索引 + 本地目录（0.36.8 起默认挂多索引）
my $r = RakuPM::Repositories.new(:config-file($cfg), :cache-root($cache), :repo-root('.'));
$r.load;
is $r.entries.elems, 4, '默认配置 4 个仓库（zef+cpan+rea+local）';
is $r.entries[0]<name>, 'zef', '默认第一个是 zef 索引';
is $r.entries[*-1]<type>, 'local', '默认最后一个是本地目录';

# 4-5 内置别名：rea / cpan 能被解析成完整 URL
ok RakuPM::Repositories.index-aliases<rea>.defined, '内置别名里有 rea';
is RakuPM::Repositories.name-for-url(
       'https://raw.githubusercontent.com/Raku/REA/main/META.json'),
   'rea', 'REA 的 URL 反查得到名字 rea';

# 4b 首标签是数字、其余不是的普通主机名不能误判成 IP：
#   360.zef.pm → zef（取二级域名），而非被当成 IP 返回 "foo"
is RakuPM::Repositories.name-for-url('https://360.zef.pm'),
   'zef', '360.zef.pm 不是 IP，应取二级域名 zef';

# 4c 真正会误判的场景：123.foo.example.com 首标签数字、其余非数字（且 URL 不带路径，
#   才能走到纯主机分支）→ 必须返回 example.com 的二级域名 example。
#   （旧 bug：只判首标签 @lab[0] ~~ /^ \d+ $/，会把这种主机名当成 IP 返回 @lab[1]="foo"）
is RakuPM::Repositories.name-for-url('https://123.foo.example.com'),
   'example', '123.foo.example.com 不被误判成 IP，应取二级域名 example';

# 6-8 add：追加一个新远程索引到「最后一个远程索引之后」（local 之前），保持主索引优先。
# 默认已是 4 个，这里加一个全新的 URL 索引（名字由文件名推出），不与默认里的 rea 重复。
$r.add('https://example.com/my-eco.json');
is $r.entries.elems, 5, 'add 后 5 个仓库（4 默认 + 1 新增）';
is $r.entries[0]<name>, 'zef',  'add 不会把新仓库顶到最前';
is $r.entries[3]<name>, 'my-eco', '新仓库排在最后一个远程索引之后（rea 之后）';
is $r.entries[*-1]<type>, 'local', 'local 始终在最后';

# 9 重复 add 被拒绝（默认里的 rea 也算已存在）
is $r.add('rea'), "仓库 'rea' 已在列表中", '重复添加被拒绝';

# 10-11 持久化：落盘后能被重新读出来
ok $cfg.e, '配置已写入 repositories.json';
my $r2 = RakuPM::Repositories.new(:config-file($cfg), :cache-root($cache), :repo-root('.'));
$r2.load;
is $r2.entries.elems, 5, '重新载入后仍是 5 个仓库';

# 12-13 remove
is $r2.remove('rea'), "已移除仓库 'rea'", 'remove 返回提示';
is $r2.entries.elems, 4, 'remove 后剩 4 个';

# 14 移除不存在的
is $r2.remove('nope'), "未找到仓库 'nope'", '移除不存在的仓库有提示';

# 15 build 出真正的仓库对象
my @repos = $r.build;
is @repos.elems, 5, 'build 出 5 个仓库对象（4 默认 + 1 新增）';
is @repos[0].^name, 'RakuPM::Repository::Ecosystem', '第一个是 Ecosystem';
is @repos[*-1].^name, 'RakuPM::Repository::Local',   '最后一个是 Local';

# 16 多个索引的 id 互不相同（否则解析时无法区分来源）
is @repos.map(*.id).unique.elems, 5, '各仓库 id 唯一';

# 17-18 环境变量：支持逗号分隔多个索引 + 别名混用
my $c = RakuPM::Client.new(
    :target($tmp.add('tgt')), :repo-root('.'),
);
# Client 在 TWEAK 里已按默认装配；这里直接验证 Repositories 的环境变量分支
{
    temp %*ENV<RAKUPM_ECOSYSTEM> = 'https://360.zef.pm,rea';
    my $r3 = RakuPM::Repositories.new(:config-file($tmp.add('none.json')),
                                      :cache-root($cache), :repo-root('.'));
    $r3.load;
    is $r3.entries.elems, 3, '环境变量逗号分隔 → 2 个索引 + local';
    is $r3.entries[1]<name>, 'rea', '环境变量里的别名 rea 被展开成 URL';
}

# 19 缓存文件名按仓库隔离（rea 与 cpan 同在 raw.githubusercontent.com 上）
my $eco1 = RakuPM::Repository::Ecosystem.new(:name('rea'),
               :index-url(RakuPM::Repositories.index-aliases<rea>),  :cache-root($cache));
my $eco2 = RakuPM::Repository::Ecosystem.new(:name('cpan'),
               :index-url(RakuPM::Repositories.index-aliases<cpan>), :cache-root($cache));
ok $eco1.id ne $eco2.id, '同主机上的两个索引 id 不同（缓存不会互相覆盖）';

# 20 未传 name 时能从 URL 推出名字
my $eco3 = RakuPM::Repository::Ecosystem.new(
               :index-url(RakuPM::Repositories.index-aliases<zef>), :cache-root($cache));
is $eco3.name, 'zef', '未传 name 时从 URL 推出 zef';

# 21 RAKUPM_REPO 要能覆盖配置文件里已存的 local 路径。
# 否则 `RAKUPM_REPO=./vendor raku-pm install Foo` 会静默用回上次 add 时存下的路径，
# 表现为「明明把包放进去了却找不到」。
{
    temp %*ENV<RAKUPM_ECOSYSTEM> = Any;    # 让它走配置文件分支
    my $cfg = $tmp.add('repos-override.json');
    $cfg.spurt(to-json(%( version => 1, repos => [
        %( name => 'zef',   type => 'ecosystem', url => 'https://360.zef.pm' ),
        %( name => 'local', type => 'local',     path => '/some/old/path' ),
    ]), :sorted-keys));

    my $r4 = RakuPM::Repositories.new(:config-file($cfg), :cache-root($cache),
                                      :repo-root('/some/old/path'));
    $r4.load;
    my $before = $r4.entries.first({ .<type> eq 'local' })<path>;
    is $before, '/some/old/path', '未设 RAKUPM_REPO 时沿用配置文件里的 local 路径';

    temp %*ENV<RAKUPM_REPO> = '/fresh/new/path';
    my $r5 = RakuPM::Repositories.new(:config-file($cfg), :cache-root($cache),
                                      :repo-root('/some/old/path'));
    $r5.load;
    is $r5.entries.first({ .<type> eq 'local' })<path>, '/fresh/new/path',
       'RAKUPM_REPO 覆盖了配置文件里已存的 local 路径';
    is $r5.entries.grep({ .<type> eq 'local' }).elems, 1,
       '覆盖时不重复插入 local 条目';
}

# ---------- repos update（zef update 同款：强制重拉索引缓存）----------
# 用本地 file:// 索引做端到端验证，不依赖真实网络：
#   · update 全部 / 指定仓库名 都能把索引刷新进缓存
#   · 索引内容变了之后 update 会强制重拉（而不是复用旧缓存）
#   · 指定的仓库不存在 / 是本地目录 → 报错
{
    my $dir = $tmp.add('upd');
    $dir.mkdir;
    my $idx  = $dir.add('fake-eco.json');
    # 注意：Raku 里 `my @x = ( %(a=>1) )` 会把 hash 展平成键值对（5 个元素），
    # 必须 push 才保留为单元素。
    my @rows;
    @rows.push(%( name => 'Upd::Mod', version => '1.0', auth => 'demo',
                  provides => { 'Upd::Mod' => 'lib/Upd/Mod.rakumod' },
                  depends => {} ));
    $idx.spurt(to-json(@rows, :sorted-keys));

    # 本地索引：直接传 IO::Path 绝对路径（Windows 上是 C:\...），Ecosystem 识别为非
    # http(s) 就走本地文件读取；file:// URL 也支持（由 URI 解出路径再走 IO::Path）。
    # 二者都不经过 HTTP 层。
    my $url = $idx.absolute;

    my $cfg-u  = $dir.add('repositories.json');
    $cfg-u.spurt(to-json(%( version => 1, repos => [
        %( name => 'fake-eco', type => 'ecosystem', url => $url ),
        %( name => 'local',    type => 'local',     path => '.' ),
    ]), :sorted-keys));
    my $cache-u = $dir.add('cache');
    my $ru = RakuPM::Repositories.new(:config-file($cfg-u), :cache-root($cache-u),
                                      :repo-root('.'));
    $ru.load;
    is $ru.entries.grep({ .<type> eq 'ecosystem' }).elems, 1, 'update 场景：配置 1 个生态索引';

    # 用一个不带 refresh 的新对象来读缓存，验证 update 落盘的东西能直接被复用
    sub cache-rows(--> Int) {
        my $eco = RakuPM::Repository::Ecosystem.new(
            :name('fake-eco'), :index-url($url), :cache-root($cache-u));
        $eco.refresh;
        $eco.all-distributions.elems
    }

    lives-ok { $ru.update }, 'update（全部）：无异常';
    is cache-rows, 1, 'update 后索引已缓存，能读到 1 个发行版';

    # 索引内容变了：加一个发行版 → 只 update 指定仓库
    @rows.push(%( name => 'Upd::Two', version => '0.5', auth => 'demo',
                  provides => { 'Upd::Two' => 'lib/Upd/Two.rakumod' },
                  depends => {} ));
    $idx.spurt(to-json(@rows, :sorted-keys));

    lives-ok { $ru.update('fake-eco') }, 'update <仓库名>：无异常';
    is cache-rows, 2, 'update 强制重新拉取：索引里 2 个发行版（没吃旧缓存）';

    # 更新不存在的仓库 / 本地目录 → 明确报错
    dies-ok { $ru.update('no-such-eco') }, 'update 不存在的仓库报错';
    dies-ok { $ru.update('local') },       'update 指向本地目录报错';
}

# ---------- file:// 索引 URL：URI 解出本地路径后走 IO::Path ----------
# 与「纯路径」分支互为补充：file:// 这种带 scheme 的地址，由 URI 模块解析出
# 路径（Windows 上剥掉开头的 '/'），再交给 IO::Path 读，不自己拼字符串。
{
    my $dir  = $tmp.add('fileurl');
    $dir.mkdir;
    my $idx  = $dir.add('fileurl-eco.json');
    my @rows;
    @rows.push(%( name => 'File::URL', version => '9.9', auth => 'demo',
                  provides => { 'File::URL' => 'lib/File/URL.rakumod' },
                  depends => {} ));
    $idx.spurt(to-json(@rows, :sorted-keys));
    # 正确 file:// 形式：file:/// + 绝对路径（正斜杠）
    my $url = 'file:///' ~ $idx.absolute.subst('\\', '/', :g);
    my $fe  = RakuPM::Repository::Ecosystem.new(
        :name('fileurl'), :index-url($url), :cache-root($dir.add('cache')));
    $fe.refresh;
    is $fe.available-versions('File::URL').elems, 1,
       'file:// 索引 URL 被 URI 解码并走 IO::Path 读取';
}

done-testing;
