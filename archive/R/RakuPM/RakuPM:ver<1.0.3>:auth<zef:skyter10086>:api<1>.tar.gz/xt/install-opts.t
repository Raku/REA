use lib 'lib';
use Test;
use JSON::Fast;
use RakuPM::Client;
use RakuPM::Repository::Local;
use RakuPM::InstallOptions;

# 回归：安装链的开关必须【传到依赖子链】。
#
# 背景（真实 bug）：安装链是 install → !install-local-dist → !install-chain
# → !install-chain-inner → !ensure-phase-deps / !ensure-git-deps 共 6 层，
# 原先每个方法都把同一批布尔开关重新抄一遍签名，结果漏抄了两处：
#   · !ensure-git-deps  漏 :no-native-check
#   · !ensure-phase-deps 漏 :no-native-check 与 :allow-test-failure
# 后果：用户给「构建依赖 / 测试依赖 / git 依赖」加 --no-native-check 或
# --allow-test-failure 时，**子链不认**，仍会跑本机库检查并可因此 die、
# 把整条链回滚 —— 用户明明关了开关却照样被拦。
#
# 本测试用「目标包的 build-depends / test-depends 里放一个会触发该检查的包」
# 来让子链真的跑到那一步：
#   场景 A：构建依赖的源码声明了不存在的运行时 native 库
#           → 默认必失败（证明检查确实生效）
#           → 加 :no-native-check 后必须成功（证明开关传到了子链）← 修复前会红
#   场景 B：测试依赖自带的测试永远失败
#           → 默认必失败（证明测试确实在跑）
#           → 加 :allow-test-failure 后必须成功（证明确实传到了子链）← 修复前会红
#
# 修复方式是把这批开关收成 RakuPM::InstallOptions 一个对象往下传，
# 从结构上消灭「漏抄一个开关」这类错误。

plan 9;

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add("rakupm-opts-{$*PID}");
rmrf($tmp);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# ---- 单元：InstallOptions 本身 ----
{
    my $d = RakuPM::InstallOptions.new;
    nok $d.no-test, '默认 no-test 为假';
    nok $d.no-native-check, '默认 no-native-check 为假';
    ok $d.mark-explicit, '默认 mark-explicit 为真（目标包算用户点名要的）';
    my $a = RakuPM::InstallOptions.new(:no-native-check, :no-test);
    my $b = $a.with(:mark-explicit(False));
    ok $b.no-native-check && $b.no-test && !$b.mark-explicit,
       'with() 派生副本保留原有开关并覆盖指定项';
    ok $a.mark-explicit, 'with() 不原地修改原对象（避免链上互相污染）';
}

# ---- 依赖包 fixture ----
my $repo = $tmp.add('repo');
$repo.mkdir;

sub write-pkg(IO::Path $dir, Str $name, %meta, :%files!) {
    $dir.mkdir;
    for %files.kv -> $rel, $content {
        my $f = $dir.add($rel);
        $f.parent.mkdir unless $f.parent.e;
        $f.spurt($content);
    }
    $dir.add('META6.json').spurt(to-json(%( name => $name, version => '1.0',
        auth => 'demo', %meta ), :sorted-keys));
}

# BuildDepA：源码里有 is native('<不存在>') → 运行时本地库检查必然报缺
write-pkg($repo.add('BuildDepA'), 'BuildDepA',
    %( provides => { 'BuildDepA' => 'lib/BuildDepA.rakumod' },
       depends  => { runtime => { requires => [] } } ),
    :files(%(
        'lib/BuildDepA.rakumod' =>
            "unit module BuildDepA;\n"
            ~ "sub need_missing() is native('zzz-no-such-native-xyz') \{ * \}\n",
    )));

# BuildDepB：自带的测试永远失败
write-pkg($repo.add('BuildDepB'), 'BuildDepB',
    %( provides => { 'BuildDepB' => 'lib/BuildDepB.rakumod' },
       depends  => { runtime => { requires => [] } } ),
    :files(%(
        'lib/BuildDepB.rakumod' => "unit module BuildDepB;\n",
        't/01.t'                => "use Test;\nflunk 'always fails';\ndone-testing;\n",
    )));

my $repo-obj = RakuPM::Repository::Local.new(:root($repo));

# 目标包 TgtA：有 Build.pm（needs-build 为真）+ build-depends → BuildDepA
my $tgtA = $tmp.add('TgtA');
write-pkg($tgtA, 'TgtA',
    %( provides => { 'TgtA' => 'lib/TgtA.rakumod' },
       depends  => { runtime => { requires => [] } },
       'build-depends' => { 'BuildDepA' => '*' } ),
    :files(%(
        'lib/TgtA.rakumod' => "unit module TgtA;\n",
        'Build.pm' => "class Build \{\n    method build(\$dir) \{ True \}\n\}\n",
    )));

# 目标包 TgtB：test-depends → BuildDepB
my $tgtB = $tmp.add('TgtB');
write-pkg($tgtB, 'TgtB',
    %( provides => { 'TgtB' => 'lib/TgtB.rakumod' },
       depends  => { runtime => { requires => [] } },
       'test-depends' => { 'BuildDepB' => '*' } ),
    :files(%(
        'lib/TgtB.rakumod' => "unit module TgtB;\n",
        't/01.t' => "use Test;\nok True, 'target ok';\ndone-testing;\n",
    )));

# ---- 场景 A：构建依赖里的运行时 native 库检查 ----
{
    my $client = RakuPM::Client.new(:target($tmp.add('targetA')),
                                    :repos([$repo-obj]));
    my $err = '';
    try { $client.install-from-dir($tgtA) };
    $err = $!.Str if $!;
    ok $err.contains('本地库') || $err.contains('未找到'),
       '构建依赖的源码声明了缺失的 native 库 → 默认安装失败（检查确实生效）';

    my $client2 = RakuPM::Client.new(:target($tmp.add('targetA2')),
                                     :repos([$repo-obj]));
    lives-ok { $client2.install-from-dir($tgtA, :no-native-check(True)) },
       ':no-native-check 必须传到【构建依赖】子链（修复前会红）';
}

# ---- 场景 B：测试依赖的 allow-test-failure ----
{
    my $client = RakuPM::Client.new(:target($tmp.add('targetB')),
                                    :repos([$repo-obj]));
    my $err = '';
    try { $client.install-from-dir($tgtB) };
    $err = $!.Str if $!;
    ok $err.contains('测试失败'),
       '测试依赖自带的测试失败 → 默认安装失败（测试确实在跑）';

    my $client2 = RakuPM::Client.new(:target($tmp.add('targetB2')),
                                     :repos([$repo-obj]));
    lives-ok { $client2.install-from-dir($tgtB, :allow-test-failure(True)) },
       ':allow-test-failure 必须传到【测试依赖】子链（修复前会红）';
}
