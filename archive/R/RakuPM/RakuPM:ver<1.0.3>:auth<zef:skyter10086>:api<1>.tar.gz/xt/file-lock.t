use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::FileLock;

# 跨进程互斥（flock）—— 两个 raku-pm 同时跑会互相踩：
#   · 同时往 store 放同一个版本 → 半份文件，指纹对不上
#   · 同时回写 installed.json  → 后写的把先写的整份冲掉
# 所以写命令必须先拿锁。这里钉死四件事：
#   1. 同进程可重入（install 内部还会调 install），且只有最外层才真正释放；
#   2. 跨进程真互斥（起一个真的子进程持锁，主进程拿不到）；
#   3. 持锁进程死掉后锁自动释放（flock 由内核回收，不留陈旧锁）；
#   4. 等待能被超时打断，报错里带得上持有者信息。
#
# 注：进程内重入表按【绝对路径】共享，两个实例指向同一文件也算同一把锁。

my $dir = $*TMPDIR.add('rakupm-flock-' ~ $*PID ~ '-' ~ now.floor).mkdir;
LEAVE { try { .unlink } for $dir.dir; try { $dir.rmdir } }
my $lock-file = $dir.add('.raku-pm.run.lock');

sub new-lock(--> RakuPM::FileLock) { RakuPM::FileLock.new(:path($lock-file)) }

my $lib-str = $*PROGRAM.parent.parent.add('lib').Str;
my $helper  = $*PROGRAM.parent.parent.add('t').add('file-lock-helper.raku');

# 在【另一个进程】里试一次锁，返回 'GOT' / 'FAIL'
sub try-lock-from-other-process(--> Str) {
    my $p = run($*EXECUTABLE, '-I', $lib-str, $helper.Str,
                $lock-file.Str, '1', 'try', :out, :err);
    my $s = $p.out.slurp(:close).trim;
    $s eq 'GOT' | 'FAIL' ?? $s !! "UNKNOWN($s)"
}

# ---------- 1. 基本获取 / 释放 ----------
{
    my $l = new-lock;
    lives-ok { $l.acquire(:what('测试')) }, '空闲时 acquire 正常返回';
    ok $l.acquired, 'acquired 标记为 True';
    ok $lock-file.e, '锁文件被创建';
    # 持有者信息在旁路文件里（锁文件本身被强制锁挡住，读不了）
    ok $lock-file.basename ~ '.owner'
       && $dir.add('.raku-pm.run.lock.owner').slurp.contains('pid='),
       '持有者信息（含 PID）写在旁路 .owner 文件里';
    $l.release;
    nok $l.acquired, 'release 后 acquired 变为 False';
}

# ---------- 2. 释放后别人能拿到 ----------
{
    my $a = new-lock;
    $a.acquire(:what('A'));
    $a.release;
    my $b = new-lock;
    lives-ok { $b.acquire(:what('B'), :timeout(1)) }, '释放之后另一个实例能拿到锁';
    $b.release;
}

# ---------- 3. 同进程重入：内层 release 不能把外层的锁交出去 ----------
{
    my $outer = new-lock;
    $outer.acquire(:what('outer'));
    my $inner = new-lock;                       # 另一个实例，同一路径
    lives-ok { $inner.acquire(:what('inner')) }, '同一进程内再次 acquire 不死锁（可重入）';
    $inner.release;                             # 内层先释放

    # 关键：外层还持有，别的【进程】必须拿不到（引用计数生效）
    is try-lock-from-other-process, 'FAIL', '内层 release 之后外层仍然持有（引用计数生效）';

    $outer.release;
    is try-lock-from-other-process, 'GOT', '外层 release 之后别的进程才拿得到';
}

# ---------- 4. 跨进程互斥（真子进程持锁）+ 等待 ----------
{
    my $out = '';
    my $proc = Proc::Async.new($*EXECUTABLE, '-I', $lib-str,
                               $helper.Str, $lock-file.Str, '4');
    $proc.stdout.tap({ $out ~= $_ });
    $proc.stderr.tap({ $out ~= $_ });
    my $done = $proc.start;

    # 轮询等它拿到锁（最多 30 秒）
    my $waited = 0;
    until $out.contains('HELD') || $waited > 30 { sleep 0.2; $waited += 0.2 }
    ok $out.contains('HELD'), '（前置）子进程已持有锁';

    # 主进程此刻必须拿不到（超时 0，立刻失败）
    my $mine = new-lock;
    my $err  = '';
    try { $mine.acquire(:what('主进程'), :timeout(0), :wait(False)) } or $err = $!.Str;
    ok $err.chars, '别的进程持锁时 acquire 会失败（跨进程真互斥）';
    ok $err.contains('另一个 raku-pm'), '失败信息说明了是谁在占用';
    ok $err.contains('pid='), '失败信息里带上了持有者的 PID';

    # 子进程持 4 秒后释放，等待模式应该能排到
    my $later = new-lock;
    lives-ok { $later.acquire(:what('排队'), :timeout(60)) }, '持锁进程释放后，等待的一方成功拿到锁';
    $later.release;

    await $done;
}

# ---------- 5. 持锁进程被杀 → 锁自动释放（不留陈旧锁） ----------
{
    my $out = '';
    my $proc = Proc::Async.new($*EXECUTABLE, '-I', $lib-str,
                               $helper.Str, $lock-file.Str, '120');
    $proc.stdout.tap({ $out ~= $_ });
    $proc.stderr.tap({ $out ~= $_ });
    my $done = $proc.start;

    my $waited = 0;
    until $out.contains('HELD') || $waited > 30 { sleep 0.2; $waited += 0.2 }
    ok $out.contains('HELD'), '（前置）子进程已持有锁（长时间）';

    $proc.kill;                                  # 模拟 Ctrl+C / 进程被杀
    try await Promise.anyof($done, Promise.in(10));

    my $mine = new-lock;
    lives-ok { $mine.acquire(:what('接盘'), :timeout(10)) },
             '持锁进程被杀后锁自动释放（flock 由内核回收，不需要清理陈旧锁）';
    $mine.release;
}

# ---------- 6. hold()：离开作用域自动释放，抛异常也一样 ----------
{
    my $l = new-lock;
    my $r = $l.hold({ 'block 返回值' }, :what('hold 测试'), :timeout(1));
    is $r, 'block 返回值', 'hold 返回 block 的值';
    nok $l.acquired, 'hold 结束后自动释放';

    my $l2 = new-lock;
    (try { $l2.hold({ die '意外' }, :what('抛异常'), :timeout(1)) }) // Nil;
    nok $l2.acquired, 'block 抛异常时 hold 也会释放锁';

    my $l3 = new-lock;
    lives-ok { $l3.acquire(:what('再次确认'), :timeout(1)) }, '异常路径之后锁确实可用';
    $l3.release;
}

done-testing;
