use Test;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;
use RakuPM::Repository::Local;
use JSON::Fast;

# fetch：把发行版源码取到指定目录（不安装），用来搭建本地目录仓库。
#
# 离线、确定性：源用【本地目录仓库】模拟（把本项目的 t 固件目录当源仓库），
# 不去网络。取来的目录应当符合 Local 仓库的布局要求
# （<目录>/<发行版>/{META6.json, lib/...}），加进仓库后就能按名安装。
#
# 【0.49.5 修：它以前并不离线】本文件声称「不去网络」，但构造 Client 时只传了
# `:repo-root`、**没传 `:repos`** → Client 会去读 repositories.json / RAKUPM_ECOSYSTEM
# 并挂上 zef+cpan+rea 三个**远程索引**。于是解析 `Lib::A` 之前先要拉三个网络索引，
# 其中任一不可达且无缓存就整条命令崩 —— 用户现场（国内网络）：
#   # You planned 8 tests, but ran 0
#   生态索引拉取失败且本地无缓存（https://raw.githubusercontent.com/Raku/REA/main/META.json）
# 而答案其实就在本地仓库里，跟网络毫无关系。现在显式只挂源仓库，注释与行为一致，
# 门禁也不再随网络抖动变红。
my $base = $*TMPDIR.add("rakupm-fetch-{$*PID}-" ~ now.floor);
$base.mkdir;
END {
    try {
        sub rm(IO::Path $d) {
            for $d.dir -> $e { $e.d ?? rm($e) !! $e.unlink }
            $d.rmdir;
        }
        rm($base) if $base.d;
    }
}

# 源仓库：造两个发行版，其中一个依赖另一个（顺带验证 fetch 不解析依赖）
sub make-dist($dir, :$name, :$version, :@provides, :%depends) {
    $dir.mkdir;
    $dir.add('lib').mkdir;
    for @provides -> $mod {
        my $f = $dir.add("lib/{$mod.subst('::', '/', :g)}.rakumod");
        $f.parent.mkdir;
        $f.spurt("unit module $mod;\n");
    }
    $dir.add('META6.json').spurt(to-json({
        name => $name, version => $version, auth => 'demo:raku',
        description => "$name 测试发行版", provides => @provides, depends => %depends,
    }, :sorted-keys));
}

my $src-repo = $base.add('src-repo');
make-dist($src-repo.add('Lib-A'), :name('Lib-A'), :version('1.0.0'),
          :provides(['Lib::A']));
make-dist($src-repo.add('App-B'), :name('App-B'), :version('2.0.0'),
          :provides(['App::B']), :depends({ 'Lib::A' => '>= 1.0.0' }));

my $target = $base.add('target');
# :repos 显式只挂源仓库 —— 这是「离线」的关键；不传就会挂上远程生态索引（见顶部说明）。
my $client = RakuPM::Client.new(:repo-root($src-repo), :target($target),
                                :repos([RakuPM::Repository::Local.new(:root($src-repo))]),
                                :promote-bin(False));

plan 8;

# —— 1) 基本取包 ——
my $dest = $base.add('my-dists');
$client.fetch('Lib::A', :to($dest.absolute));
my $got = $dest.add('Lib-A');
ok $got.d, 'fetch 在目标目录下建了发行版子目录';
ok $got.add('META6.json').e, '取来的目录含 META6.json（可被 Local 仓库收录）';
ok $got.add('lib').d, '取来的目录含 lib/';

# —— 2) 取来的目录能直接当本地仓库用 ——
{
    use RakuPM::Repository::Local;
    my $r = RakuPM::Repository::Local.new(:root($dest));
    ok $r.all-distributions.first({ $_ eq 'Lib-A' }).defined,
       '取来的目录作为 Local 仓库能读到该发行版';
}

# —— 3) fetch 不解析依赖（依赖没取也该成功）——
my $dest2 = $base.add('d2');
lives-ok { $client.fetch('App-B', :to($dest2.absolute)) },
         'fetch 不解析依赖：依赖缺失也能取到目标包';
ok $dest2.add('App-B').d, 'App-B 已取到';

# —— 4) 指定版本 ——
my $dest3 = $base.add('d3');
lives-ok { $client.fetch('Lib::A', :to($dest3.absolute), :version('1.0.0')) },
         'fetch 可指定精确版本';

# —— 5) 同名重复取不会静默覆盖（带版本号另建目录）——
$client.fetch('Lib::A', :to($dest3.absolute), :version('1.0.0'));
ok $dest3.add('Lib-A-1.0.0').d,
   '目标已存在时改用 <名字>-<版本> 目录，避免静默覆盖';

done-testing;
