use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Distribution;
use RakuPM::Store;
use RakuPM::Installer;

# 回滚只能补【激活版本】，不能把 versions[] 里的历史版本挨个重装。
#
# 现场（用户，LibXML 缺 libxml2-dev 导致构建失败 → 回滚）：
# 回滚会调 !restore-missing-from-store 补回「账本里有、CUR 里没有」的版本。
# 而账本的 versions[] 是【历史】（raku-pm 自己每次 self-upgrade 就多一条），
# 里面很多版本早就不在 CUR 里了。按 versions[] 逐个装回的结果是：
#   · 把历史上每个版本都重装一遍 → 每装一次重写一遍自包含 bin wrapper
#     → 输出刷屏、看着像死循环，只能 ^C；
#   · 更糟的是 wrapper 最后可能指向一个旧版本的 raku-pm。
# 回滚要恢复的是「事务前的样子」，那等于当时的【激活版本】。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d { rmrf($_) for $p.dir; try { $p.rmdir } }
    else    { try { $p.unlink } }
}

my $tmp = $*TMPDIR.add('rakupm-restore-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub make-dist(Str $name, Str $ver --> IO::Path) {
    my $d = $tmp.add("src-$name-$ver").mkdir;
    $d.add('lib').mkdir;
    $d.add('lib').add("$name.rakumod").spurt("unit module $name;\n");
    $d.add('META6.json').spurt(to-json({
        name     => $name,
        version  => $ver,
        auth     => 'test:me',
        api      => '1',
        provides => { $name => "lib/$name.rakumod" },
        depends  => {},
    }, :sorted-keys));
    $d
}

my $store = RakuPM::Store.new(:root($tmp.add('store')));
my $inst  = RakuPM::Installer.new(:target($tmp.add('target')), :store($store));

my $s1 = make-dist('Multi', '1.0');
my $s2 = make-dist('Multi', '2.0');
$store.put(RakuPM::Distribution.from-meta-file($s1.add('META6.json')), $s1);
$store.put(RakuPM::Distribution.from-meta-file($s2.add('META6.json')), $s2);
$inst.install(RakuPM::Distribution.from-meta-file($s1.add('META6.json')));
$inst.install(RakuPM::Distribution.from-meta-file($s2.add('META6.json')));

ok $inst.cur-has('Multi', '1.0'), 'Multi 1.0 已装进 CUR';
ok $inst.cur-has('Multi', '2.0'), 'Multi 2.0 已装进 CUR';
is $inst.installed-version('Multi'), '2.0', '激活版本是 2.0';

# ---- 造出「账本记着 1.0、但 CUR 里已经没有 1.0」的历史残留 ----
$inst.uninstall('Multi', :version('1.0'), :keep-store);  # 测试要验证「从 store 回滚」，store 必须留着
nok $inst.cur-has('Multi', '1.0'), '1.0 已从 CUR 摘掉';
# 手动把 1.0 写回账本的 versions（模拟历史版本没在 CUR 里的常见状态）
my $ledger = $inst.repo-prefix.parent.add('installed.json');
my @list = from-json($ledger.slurp);
for @list -> %e {
    next unless (%e<name> // '') eq 'Multi';
    %e<versions> = ('1.0', '2.0');   # 必须是字符串：<1.0 2.0> 会变成 Rat
}
$ledger.spurt(to-json(@list, :sorted-keys));
is $inst.installed-version('Multi'), '2.0', '账本的激活版本仍是 2.0';
ok '1.0' (elem) @($inst.list-installed.first({.<name> eq 'Multi'})<versions>),
   '账本历史里仍记着 1.0';

# ---- 触发一次回滚：应该什么都不补（激活版本 2.0 还在 CUR 里） ----
$inst.begin-transaction();
$inst.install(RakuPM::Distribution.from-meta-file($s2.add('META6.json')));
$inst.rollback-transaction();

nok $inst.cur-has('Multi', '1.0'),
    '回滚没有把历史版本 1.0 装回 CUR（只补激活版本）';
ok $inst.cur-has('Multi', '2.0'),
   '回滚后激活版本 2.0 仍在 CUR 里';

# ---- 反面对照：激活版本真丢了，回滚要补回来 ----
$inst.uninstall('Multi', :version('2.0'), :keep-store);  # 同上：store 留着供回滚装回
nok $inst.cur-has('Multi', '2.0'), '先把激活版本 2.0 从 CUR 摘掉';
# uninstall 会把账本的激活版本改成剩下的 1.0；这里手动改回「激活 = 2.0」，
# 才能造出「账本说装的是 2.0、而 CUR 里没有 2.0」这个真正需要补回的情形。
my @l2 = from-json($ledger.slurp);
for @l2 -> %e {
    next unless (%e<name> // '') eq 'Multi';
    %e<versions> = ('1.0', '2.0');
    %e<version>  = '2.0';
}
$ledger.spurt(to-json(@l2, :sorted-keys));
is $inst.installed-version('Multi'), '2.0', '账本激活版本是 2.0（但 CUR 里没有）';

$inst.begin-transaction();
$inst.rollback-transaction();      # 直接回滚（本次没装东西也会走到补回逻辑）

ok $inst.cur-has('Multi', '2.0'),
   '激活版本丢了时，回滚会把它从 store 装回（这正是补回逻辑的用途）';

done-testing;
