use Test;
use lib $*PROGRAM.parent(2).add('lib').Str;
use RakuPM::Client;

# self-upgrade 的【两阶段自举】：先把源码 clone 到 git-cache，再改用【拉到的源码】
# 里的 bin/raku-pm.raku（配合 -I <clone>/lib 加载新版模块）重跑安装 —— 让新版代码
# 自己装自己。这样即便新版改了安装链行为（测试门禁 / 依赖解析 / wrapper 写法…），
# 也不会出现「旧版装不动新版」的升不上去死循环。
#
# 这里覆盖三件事：
#   ① 自举命令行拼装 —— 尤其 --target 不能漏：写锁按 target 定位
#      （<target>/.raku-pm.run.lock），漏了子进程就去抢另一把锁；
#   ② --from-dir 直接升级（自举第二阶段跑的就是这条）；
#   ③ 真自举端到端：本地 git 仓库冒充远端 + 在新源码 bin 里埋标记，
#      标记出现即证明「执行安装的确实是新版代码」。这一步走真 CLI，
#      顺带验证父进程持锁时子进程能凭 token 免锁放行（不会自锁到超时）。

my $root = $*PROGRAM.parent(2);
my $bin  = $root.add('bin').add('raku-pm.raku');
my $lib  = $root.add('lib');

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else { try { $p.unlink } }
}

# 递归拷贝一棵树（跳过 .git / .precomp / git-cache）：把当前【工作树】做成一份
# 「源码发行版」，供 ③ 当远端用。刻意不从 git clone 取 —— 那样拿到的是【已提交】
# 版本，未提交的改动不在里面，测试会与提交状态耦合。
sub copy-tree(IO::Path $from, IO::Path $to) {
    $to.mkdir;
    for $from.dir -> $e {
        next if $e.basename eq any(< .git .precomp git-cache >);
        my $d = $to.add($e.basename);
        $e.d ?? copy-tree($e, $d) !! $d.spurt($e.slurp(:bin));
    }
}

my $tmp = $*TMPDIR.add('rakupm-bootstrap-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

my %env = %( %*ENV );

# ---------- ① bootstrap-command 拼装 ----------
{
    my $src = $tmp.add('s1');
    $src.add('lib').mkdir;
    $src.add('bin').mkdir;
    $src.add('bin').add('raku-pm.raku').spurt(q{# stub} ~ "\n");

    my $c = RakuPM::Client.new(:target($tmp.add('t1')), :repos([]));
    # 【坑】方法调用的具名数组实参别写成 `:passthru(< ... >)` —— 那种形式在这里会
    # 被解析成【单个 Str】，绑到 :@passthru 时直接抛 "expected Positional but got
    # Str"（包在 try 里就变成静默失败，很难查）。先赋给变量或写 `[< ... >]` 最稳。
    my @pt = < --target=/custom/path >;
    my @cmd = $c.bootstrap-command($src, :passthru(@pt));

    ok @cmd.elems > 0, '① 有 bin+lib → 生成自举命令';
    ok @cmd.first(* eq 'self-upgrade').defined,
       '① 子命令是 self-upgrade';
    ok @cmd.first({ $_.starts-with('--from-dir=') }).defined,
       '① 带 --from-dir=<源码目录>（第二阶段入口）';
    ok @cmd.first(* eq '--force').defined,
       '① 必带 --force（覆盖安装；否则版本没变时会被「已安装跳过」拦掉）';
    ok @cmd.first(* eq '--target=/custom/path').defined,
       '① 透传参数原样带到（--target 决定写锁路径，漏了就抢错锁）';
    ok @cmd.first({ $_.ends-with('raku-pm.raku') }).defined,
       '① 跑的是源码目录里的 bin/raku-pm.raku（不是当前这份）';
    ok @cmd.first(* eq '-I').defined,
       '① 用 -I 指到源码目录的 lib（加载新版模块）';

    # 源码缺 bin/（老版本仓库）→ 返回空，调用方据此回退
    my $src2 = $tmp.add('s2');
    $src2.add('lib').mkdir;
    is $c.bootstrap-command($src2).elems, 0,
       '① 源码缺 bin → 返回空 List（触发回退到「用当前代码装」）';
}

# ---------- ② --from-dir 端到端（自举第二阶段走的就是这条）----------
{
    my $target = $tmp.add('t2');
    my $p = run('raku', '-I', $lib.Str, $bin.Str,
                'self-upgrade', '--from-dir=' ~ $root.Str,
                '--target=' ~ $target.Str, '--no-test',
                :out, :err, :env(%env));
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    my $all = $out ~ $err;

    is $p.exitcode, 0, '② self-upgrade --from-dir 退出码 0'
                     ~ ($p.exitcode == 0 ?? '' !! "\n{$err}");
    ok $all.contains('已从本地源码升级'), '② 打印成功提示';

    my $c = RakuPM::Client.new(:target($target), :repos([]));
    my @vs = $c.installer.installed-versions('RakuPM');
    is @vs.elems, 1, '② 只留一个版本（覆盖安装语义：旧版被自动清理）';
}

# ---------- ③ 真自举端到端（需 git）----------
{
    my $has-git = (try { run('git', '--version', :out); True }) // False;
    if !$has-git {
        skip 'git 不可用，跳过自举端到端', 5;
    }
    else {
        # 造「远端」：当前工作树副本 + 在 bin 的 MAIN 里埋一个标记 + git init
        my $newsrc = $tmp.add('newsrc');
        copy-tree($root, $newsrc);
        my $nbin = $newsrc.add('bin').add('raku-pm.raku');
        my $MARK = 'BOOTSTRAP-MARKER-PROOF';
        my $txt  = $nbin.slurp;
        my $needle = 'sub MAIN(*@args, *%early) {';
        ok $txt.contains($needle), '③ 源码里找到 MAIN 入口（准备埋标记）';
        # 用拼接而非嵌套引用：q{...} 往生成的源码里写容易把分隔符搞乱，
        # 生成出来的 bin 编译不过（实测踩过），自举就变成「子进程 exit 1 → 回退」。
        my $inject = q{    say "} ~ $MARK ~ q{";};
        $txt = $txt.subst($needle, $needle ~ "\n" ~ $inject);
        $nbin.spurt($txt);

        # 跑 git 并【必须 slurp 关管道】：run(:out,:err) 之后不关，Windows 上会
        # 泄漏句柄导致子进程不退出（项目里踩过的坑）。失败时把 stderr 打出来，
        # 否则只能看到一个 exitcode，无从排查。
        my &git-ok = -> @args {
            my $p = run('git', |@args, :out, :err);
            my $e = $p.err.slurp(:close);
            $p.out.slurp(:close);
            note "git {@args.join(' ')} → exit {$p.exitcode}\n{$e}"
                if $p.exitcode != 0;
            $p.exitcode == 0;
        };

        my $ok-init = git-ok(['-C', $newsrc.Str, 'init', '-q']);
        my $ok-add  = $ok-init && git-ok(['-C', $newsrc.Str, 'add', '-A']);
        my $ok-cm   = $ok-add  && git-ok(['-C', $newsrc.Str,
                                          '-c', 'user.email=t@t',
                                          '-c', 'user.name=t',
                                          'commit', '-q', '-m', 'test']);

        if !($ok-init && $ok-add && $ok-cm) {
            skip 'git init/add/commit 失败，跳过自举端到端', 4;
        }
        else {
            my $target = $tmp.add('t3');
            # 【必须重定向到文件，不能写 :out/:err 捕获】：
            # 本测试是「祖父进程」，被捕获的 raku-pm 是子进程、它又派生自举孙进程，
            # 三者共享同一条管道；祖父要等子进程结束才 slurp，中间任何一环写满
            # 64KB 管道缓冲就互相等死。落文件既没有这个死结，卡住时还能直接看
            # 日志（捕获式一旦死锁，日志一个字也拿不到，完全没法排查）。
            my $log-out = $tmp.add('t3.out');
            my $log-err = $tmp.add('t3.err');
            my $fh-out  = $log-out.open(:w);
            my $fh-err  = $log-err.open(:w);
            my $p = run('raku', '-I', $lib.Str, $bin.Str,
                        'self-upgrade', '--from=' ~ $newsrc.Str,
                        '--target=' ~ $target.Str, '--no-test',
                        :out($fh-out), :err($fh-err), :env(%env));
            my $code = $p.exitcode;
            $fh-out.close;
            $fh-err.close;
            my $all = ($log-out.slurp // '') ~ ($log-err.slurp // '');

            is $code, 0, '③ 自举升级退出码 0（父进程持锁，子进程未死锁）'
                       ~ ($code == 0 ?? '' !! "\n" ~ ($log-err.slurp // ''));
            ok $all.contains('两阶段自举'), '③ 走了两阶段自举路径';
            ok $all.contains($MARK),
               '③ 关键：执行安装的是【新版】bin（新源码里的标记被打出来了）';
            my $ok-final = $all.contains('已由【新版代码】完成升级');
            ok $ok-final, '③ 外层确认由新版完成';
            note "③ 未匹配到结束语，实际输出共 {$all.chars} 字符，尾部：\n"
               ~ $all.lines.tail(12).join("\n") unless $ok-final;
        }
    }
}

done-testing;
