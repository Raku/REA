use Test;
use File::Temp;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Installer::ShellTemplates;
use RakuPM::Platform;
use RakuPM::Fs;

# 真跑一遍 bash wrapper，验证「保留用户已有的 RAKULIB」在 shell 里确实成立
# （t/wrapper-rakulib.t 只断言生成文本，验不了 shell 语义 —— 比如变量展开
#  顺序、`[ -n ]` 判断、逗号拼接位置）。
#
# 为什么放 xt/：需要真的 bash，Windows 上还必须是 Git Bash。注意
# `C:\Windows\system32\bash.exe` 是 **WSL 的入口**（语义完全不同：另一个
# 文件系统、另一个 PATH），绝不能拿它当 shell 用。

sub find-real-bash(--> IO::Path) {
    # 1) 从 git 的位置推 Git for Windows 自带的 bash（最可靠）
    my $git = find-executable('git');
    if $git.defined {
        my $root = $git.parent.parent;                       # <Git>/cmd/git.exe → <Git>
        for $root.add('bin', 'bash.exe'), $root.add('usr', 'bin', 'bash.exe') -> $c {
            return $c if $c.e;
        }
    }
    # 2) PATH 里的 bash，但排除 WSL（system32 / WindowsApps）
    for < bash bash.exe > -> $n {
        my $p = find-executable($n);
        next unless $p.defined;
        my $s = $p.Str.lc;
        next if $s.contains('system32') || $s.contains('windowsapps');
        return $p;
    }
    IO::Path
}

my $bash = find-real-bash;
unless $bash.defined {
    skip '找不到可用的 Git Bash（WSL 的 bash 不算），跳过真实执行验证；文本层由 t/wrapper-rakulib.t 覆盖', 5;
    exit 0;
}

plan 6;

my $root = $*TMPDIR.add("rakupm-wrap-run-{$*PID}");
LEAVE { rm-tree($root) if $root.defined && $root.e }

# 最小 store：store/RakuPM/0.9.0/bin/raku-pm.raku —— 打印它看到的 RAKULIB 与参数
my $store = $root.add('store', 'RakuPM');
my $entry = $store.add('0.9.0', 'bin', 'raku-pm.raku');
mkdir-p($entry.parent);
# 注意用 q{} 而不是双引号：双引号里 `%*ENV<RAKULIB>` 会在**写文件时**就被本进程
# 插值成当前值，写进去的就不是 Raku 代码了（第一次写这条测试就踩了：假入口变成
# `say 'SEEN=' ~ (C:\Users\...\raku-modules // ...)` → 子进程编译 "Confused"）。
# 第二行打印收到的参数 —— 用来验「wrapper 把前缀显式传下去了」（0.49.0）。
$entry.spurt(
    q{say 'SEEN=' ~ (%*ENV<RAKULIB> // '(none)');} ~ "\n" ~
    q{say 'ARGS=' ~ @*ARGS.join('|');} ~ "\n");

my &fwd = -> $p { $p.absolute.Str.subst('\\', '/', :g) };
my $site = fwd($root.add('site'));
my $body = bash-wrapper-body(fwd($root), fwd($store), $site,
                             $*EXECUTABLE.Str.subst('\\', '/', :g),
                             fwd($entry));
my $sh = $root.add('wrapper.sh');
$sh.spurt($body);

my $bash-x = fwd($bash);
my $sh-x   = fwd($sh);

# 用外层 bash -c 预置环境变量：不能走 run(:env) —— **Windows 上 :env 不生效**
# （本项目踩过：写错的测试因为 :env 被忽略而假绿）。
sub run-wrapper(Str $pre --> List) {
    my $script = ($pre.chars ?? "{$pre}; " !! '') ~ "'{$bash-x}' '{$sh-x}'";
    my $p = run($bash.Str, '-c', $script, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

# 1) 语法
{
    my $p = run($bash.Str, '-n', $sh-x, :out, :err);
    $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    is $p.exitcode, 0, 'bash -n 通过（生成的 wrapper 语法正确）' or diag $err;
}

# 2) 用户没设 RAKULIB → 只有 raku-pm 的 site
{
    my ($rc, $out, $err) = run-wrapper('unset RAKULIB');
    is $rc, 0, '不带 RAKULIB 时正常退出' or diag $err;
    is $out.lines[0].trim, "SEEN=inst#{$site}",
       '不带 RAKULIB 时 = 只有 raku-pm 的 site（没有多余逗号）';
}

# 3) 用户设有 RAKULIB → 追加保留，且 raku-pm 的 site 仍在最前
{
    my ($rc, $out, $err) = run-wrapper("RAKULIB='/tmp/user-own-repo'");
    is $rc, 0, '带原 RAKULIB 时正常退出' or diag $err;
    is $out.lines[0].trim, "SEEN=inst#{$site},/tmp/user-own-repo",
       '原 RAKULIB 被追加在 raku-pm 的 site 之后（不是整条替换）';

    # 4) 前缀必须被显式传给 CLI（0.49.0）—— 这是「前缀自洽」的执行侧证据。
    # 只断言生成文本不够：变量拼接、引号、参数顺序都可能在 shell 里变样。
    is $out.lines[1].trim, "ARGS=--target={fwd($root)}",
       'wrapper 真的把 --target=<自己的前缀> 传给了子进程';
}
