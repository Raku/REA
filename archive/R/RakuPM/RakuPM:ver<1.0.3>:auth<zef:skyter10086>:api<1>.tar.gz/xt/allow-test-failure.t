use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;
use RakuPM::Client;

# --allow-test-failure 软通过选项的回归测试：
#   1. 默认模式（不传 :allow-test-failure）：测试失败 → install dies
#   2. :allow-test-failure → install 成功 + warning 列出失败用例
# 典型场景：Log::Async 0.0.17 的 t/12-context.rakutest 在 Windows 上必挂
# （Log::Async::Context.generate 用 .contains('Log/Async') 过滤自己的帧，
# Windows 路径是 Log\Async，正斜杠子串匹配不上 → 把模块自己的帧当 caller
# 返回 —— 这是 Log::Async 上游 bug，不是 raku-pm 的）。用户用
# --allow-test-failure 软通过。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $tmp = $*TMPDIR.add('rakupm-allow-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

# 构造一个故意失败的发行版
sub make-failing-dist(IO::Path $root, Str :$name = 'Mod' --> IO::Path) {
    my $src = $root.add('src').mkdir;
    $src.add('lib').mkdir;
    $src.add('lib').add($name ~ '.rakumod').spurt('unit module ' ~ $name ~ ';');
    $src.add('t').mkdir;
    $src.add('t').add('01-ok.rakutest').spurt(
        'use Test; plan 1; pass "first";' ~ "\n");
    $src.add('t').add('99-broken.rakutest').spurt(
        'use Test; plan 1; flunk "always fails";' ~ "\n");
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '1.0', auth => 'demo',
        provides => { ($name) => ('lib/' ~ $name ~ '.rakumod') }, depends => {},
    }, :sorted-keys));
    $src
}

# 临时重定向 $*ERR 到文件，调用闭包后恢复并返回内容
sub capture-stderr(--> Str) {
    my $captured = '';
    # Raku 没有原生 tee，但 $*ERR 是 dynamic scope；用 IO::Handle 替换。
    # 简单方案：开文件、临时指向 $*ERR，跑代码，再恢复。
    my $errfile = $*TMPDIR.add('test-stderr-' ~ $*PID ~ '-' ~ now.floor ~ '.txt');
    my $fh = $errfile.open(:w);
    my $orig = $*ERR;
    $*ERR = $fh;
    try {
        # 调用方代码 — 这里抛错我们 catch 住，保证 $*ERR 一定恢复
        return '<<DID_NOT_RUN>>';
    };
    $*ERR = $orig;
    $fh.flush; $fh.close;
    my $txt = $errfile.slurp;
    try $errfile.unlink;
    $txt;
}

# 上面那个 helper 写错了——应该把要跑的代码用 & 闭包传进来。重写为更通用的
# helper，把 stderr 重定向到文件，跑 &body，返回文件内容。
sub with-stderr-captured(&body --> Str) {
    my $errfile = $*TMPDIR.add('test-stderr-' ~ $*PID ~ '-' ~ now.floor ~ '.txt');
    my $fh = $errfile.open(:w);
    my $orig = $*ERR;
    $*ERR = $fh;
    try { body() };
    $*ERR = $orig;
    $fh.flush; $fh.close;
    my $txt = $errfile.slurp;
    try $errfile.unlink;
    $txt
}

# ---------- 默认模式：测试失败 → dies ----------
{
    my $fixture = $tmp.add('default').mkdir;
    my $src = make-failing-dist($fixture);
    my $client = RakuPM::Client.new(
        :target($fixture.add('target')),
        :repos([RakuPM::Repository::Local.new(:root($fixture.add('repo').mkdir))]),
    );
    dies-ok { $client.install-from-dir($src, :no-build) },
        '默认模式：有失败用例时 install dies（契约保持）';
    nok $client.installer.list-installed.first({ $_<name> eq 'Mod' }).defined,
        '默认模式失败时未装入（账本无 Mod）';
}

# ---------- 软失败模式：lives + 账本有 Mod + warning 文案 ----------
{
    my $fixture = $tmp.add('soft').mkdir;
    my $src = make-failing-dist($fixture);
    my $client = RakuPM::Client.new(
        :target($fixture.add('target')),
        :repos([RakuPM::Repository::Local.new(:root($fixture.add('repo').mkdir))]),
    );

    my $err = with-stderr-captured({
        $client.install-from-dir($src, :no-build, :allow-test-failure);
    });
    nok $err eq '<<DID_NOT_RUN>>', 'with-stderr-captured 的 body 实际执行了';
    ok $client.installer.list-installed.first({ $_<name> eq 'Mod' }).defined,
        '软失败模式：即使测试失败仍装入 site（账本有 Mod）';
    ok $err.contains('未通过'),
        '软失败 warning 含「未通过」';
    ok $err.contains('99-broken.rakutest'),
        '软失败 warning 列出失败的测试文件名';
    ok $err.contains('--allow-test-failure'),
        '软失败 warning 提示取消旗标可看完整报错';
}

# ---------- 控制：默认模式（不传旗标）warning 文案不会出现 ----------
{
    # 钉死「warning 文案只在软失败模式下出现」—— 否则上面 contains 检查会假阳性。
    my $fixture = $tmp.add('control').mkdir;
    my $src = make-failing-dist($fixture, :name<Bar>);
    my $client = RakuPM::Client.new(
        :target($fixture.add('target')),
        :repos([RakuPM::Repository::Local.new(:root($fixture.add('repo').mkdir))]),
    );

    my $err = '';
    try {
        $err = with-stderr-captured({
            $client.install-from-dir($src, :no-build);
        });
    };
    nok $err.contains('--allow-test-failure'),
        '默认模式 stderr 不含「--allow-test-failure」字样（防假阳性）';
}

done-testing;