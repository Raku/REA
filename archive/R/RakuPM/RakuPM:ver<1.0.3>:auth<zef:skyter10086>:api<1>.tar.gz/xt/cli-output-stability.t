use lib 'lib';
use Test;
use RakuPM::CliSpec;

# ===========================================================================
# CLI 用户可见产物的【稳定性】回归（Issue 2 验收：help / completions 逐字节不变）
#
# 为什么不用「冻结 84KB 快照」比对：help / completions 是用户会读、也常微调措辞
# 的产物，冻结全文会让每次改文案都误红；而真正的回归风险是【CliSpec 漂移】——
# 新增/改名命令或旗标后，help / 补全脚本没同步跟上（历史上发生过 B1：update 漏进
# 补全脚本）。所以本测试守两件事：
#   ① 幂等性：同一命令连跑两次，字节完全一致（防 hash 顺序 / 日期 / 路径等非确定）；
#   ② 完备性：CliSpec 里每一个命令、别名、旗标都出现在对应产物里（防 CliSpec 漂移）。
# 这两条加起来等价「help / completions 由 CliSpec 单一事实来源确定性生成」，
# 正是 Issue 2 抽模块后要锁住的不变量。
# ===========================================================================

my $raku = $*EXECUTABLE.Str;
my $bin  = $*PROGRAM.parent.parent.add('bin/raku-pm.raku').absolute.Str;

sub run-cli(*@args) {
    my $p = run($raku, '-Ilib', $bin, |@args, :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

my %flags   = cmd-flags();
my %aliases = cmd-aliases();
my @common  = common-flags();

# ---------- 1. help：幂等 + 完备 + 结构 ----------
{
    my ($c1, $h1, $e1) = run-cli('help');
    my ($c2, $h2, $e2) = run-cli('help');
    is $c1, 0, 'help 退出码 0（第一次）';
    is $c2, 0, 'help 退出码 0（第二次）';

    # 幂等性：两次 stdout 字节完全一致（help 不写 stderr，故只比 stdout）
    is $h1, $h2, 'help 输出幂等（两次字节一致）';

    # 结构不变量：首行是用法说明
    ok $h1.lines[0].contains('用法'), 'help 首行是用法说明';

    # 完备性：每个规范命令名都出现在 help 里（漏登即红）。
    # 例外：help 是元命令，自身不列自己（completions 是普通用户命令，会列）。
    my @missing = %flags.keys.grep({ $_ ne 'help' && !$h1.contains($_) }).sort;
    is @missing.join(', '), '', "help 列出所有规范命令（漏：{@missing.join(', ') || '无'}）";

    # 别名速查表：每个别名也出现（rdeps / gens 这类「拼写可用但易漏」曾在 A7 翻过）
    my @missing-alias = %aliases.keys.grep({ !$h1.contains($_) }).sort;
    is @missing-alias.join(', '), '',
       "help 别名速查表列出所有别名（漏：{@missing-alias.join(', ') || '无'}）";
}

# ---------- 2. completions：四 shell 幂等 + 完备 + 结构 ----------
for < bash zsh fish pwsh > -> $sh {
    my ($c1, $o1, $e1) = run-cli('completions', $sh);
    my ($c2, $o2, $e2) = run-cli('completions', $sh);
    my $out1 = $o1 ~ $e1;
    my $out2 = $o2 ~ $e2;

    is $c1, 0, "completions {$sh} 退出码 0（第一次）";
    is $c2, 0, "completions {$sh} 退出码 0（第二次）";

    # 幂等性：同 shell 两次产物字节一致
    is $out1, $out2, "completions {$sh} 输出幂等（两次字节一致）";

    # 结构不变量：每种 shell 的标志性片段必须在
    given $sh {
        when 'bash' { ok $out1.contains('_raku_pm'),            'bash 补全含 _raku_pm 函数'; }
        when 'zsh'  { ok $out1.contains('bashcompinit'),        'zsh 补全含 bashcompinit 引导'; }
        when 'fish' { ok $out1.contains('complete -c raku-pm'), 'fish 补全含 complete -c raku-pm'; }
        when 'pwsh' { ok $out1.contains('Register-ArgumentCompleter'),
                                                 'pwsh 补全含 Register-ArgumentCompleter'; }
    }

    # 完备性：每个规范命令名 + 每个别名都出现在补全清单里
    my @miss-cmd = %flags.keys.grep({ !$out1.contains($_) }).sort;
    is @miss-cmd.join(', '), '',
       "completions {$sh} 含所有规范命令（漏：{@miss-cmd.join(', ') || '无'}）";
    my @miss-alias = %aliases.keys.grep({ !$out1.contains($_) }).sort;
    is @miss-alias.join(', '), '',
       "completions {$sh} 含所有别名（漏：{@miss-alias.join(', ') || '无'}）";

    # 完备性：每个旗标（公共 + 各命令）都以 --flag 形式出现在补全脚本里
    # 这是 B1 类回归的直接守门：CliSpec 加了旗标，补全脚本必须跟上。
    # 注意：%flags 的值是「每命令一个 List」，要逐命令拍平，不能对整个 Hash
    # 值做一层 flat（那样 List 元素会被当成整体、拼成 "to version" 这类复合串）。
    my @all-flags = @common;
    for %flags.values -> $v { @all-flags.push($_) for $v.list }
    @all-flags .= unique;
    my @miss-flag = @all-flags.grep({ !$out1.contains("--$_") }).sort;
    is @miss-flag.join(', '), '',
       "completions {$sh} 含所有旗标（漏：{@miss-flag.join(', ') || '无'}）";
}

done-testing;
