#!/usr/bin/env raku
# ==============================================================================
# tools/install-hooks.raku — 把 tools/git-hooks/* 安装到本仓库的 .git/hooks/
#
# 一次性本地操作，不改任何被跟踪的文件（.git/ 不入库）。在仓库根目录运行：
#     raku tools/install-hooks.raku
# 临时跳过钩子：git commit --no-verify
# ==============================================================================

my IO::Path $root = $*PROGRAM.parent.parent.absolute.IO;
my IO::Path $src  = $root.add('tools/git-hooks');
my IO::Path $dst  = $root.add('.git/hooks');

die "找不到 {$src}（这个脚本要在仓库里运行）" unless $src.d;
die "找不到 {$dst} —— 这不是一个 git 工作树？" unless $dst.d;

my @hooks = $src.dir.grep({ .f }).sort({ .basename });
die "{$src} 下没有钩子文件" unless @hooks.elems;

for @hooks -> $h {
    my IO::Path $target = $dst.add($h.basename);
    if $target.e {
        my IO::Path $bak = $dst.add($h.basename ~ '.bak');
        $target.copy($bak);
        say "已备份原有钩子：{$bak.basename}";
    }
    $h.copy($target);
    # Unix 上必须可执行；Windows 的 Git 忽略该位，但设了无害。
    try $target.chmod(0o755);
    say "已安装钩子：.git/hooks/{$h.basename}";
}

say "";
say "完成。钩子会在每次 git commit 前跑「文档纪律 + 编译暂存文件」（秒级）。";
say "临时跳过：git commit --no-verify";
