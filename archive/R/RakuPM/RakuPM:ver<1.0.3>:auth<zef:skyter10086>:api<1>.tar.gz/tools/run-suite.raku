#!/usr/bin/env raku
# ==============================================================================
# tools/run-suite.raku — raku-pm 本地全量回归 + 文档纪律校验
#
# 【为什么需要它】
#   · 项目此前没有「一条命令跑完」的入口，全靠临时手写 for 循环；而 CI（Gitee Go）
#     需要自有主机、实际长期没跑，等于没有门禁。
#   · prove6 不能用：它把「Subtest N doesn't have a plan」这类无害解析告警当失败
#     （exit=1）→ 常年假红。只有逐个 `raku <file>` 的真实退出码才是成败信号。
#   · 文档纪律（META6 版本 ↔ 两份 README 的版本示例 ↔ Changes 条目；provides 清单
#     与 lib/ 下实际文件是否互为全集）此前无人校验，已漂移过多次。
#
# 本脚本是**唯一**的判定口径：本地跑它、CI 跑它，是同一条代码路径。
#
# 【用法】
#   raku tools/run-suite.raku                  # t/ + xt/ + 静态检查 + 文档纪律 + 个人痕迹
#   raku tools/run-suite.raku --no-xt          # 跳过 xt/（网络/重测试）
#   raku tools/run-suite.raku --only=t         # 只跑 t/
#   raku tools/run-suite.raku --docs-only      # 只做静态检查 + 文档纪律 + 个人痕迹（秒级）
#   raku tools/run-suite.raku --precommit      # 预提交门禁：上者 + 编译暂存文件
#   raku tools/run-suite.raku --filter=native  # 只跑文件名含 native 的
#   raku tools/run-suite.raku --jobs=4         # 并行度（默认按 CPU 核数、上限 8）
#   raku tools/run-suite.raku --no-timings     # 不打印每用例耗时与最慢排行
#
# 退出码：0 全过 / 1 有失败 / 2 参数错。
#
# 【环境变量】
#   RAKUPM_SUITE_TIMINGS=<路径>   用例耗时缓存位置（默认 ~/.raku-pm/suite-timings.json）。
#                                 它只是 LPT 排序的输入：删掉只会让下次排序差一点，
#                                 不影响任何判定。
#   RAKUPM_NO_PRECOMP_WARMUP=1    跳过跑前的 lib 预编译预热（调试用）。
#
# 【计时：为什么默认就打印】「门禁慢」是个长期抱怨，但"慢在哪"靠感觉是查不出来的：
# 只有每个用例一行墙钟，才能区分三种完全不同的病因 ——
#   ① 所有用例都≈同一个数（比如 2s）= 瓶颈是 **raku 进程启动**本身，优化方向是
#      减少进程数（合并用例 / 复用进程），去抠某个测试的逻辑是白费力气；
#   ② 少数用例显著高出一截 = 那几个才值得单独优化（通常是网络 / 大量子进程）；
#   ③ 用例耗时之和远大于墙钟 = 并行在起作用；反过来接近 1x 就要看 jobs / 预热。
# 故本脚本在结尾打印「最慢 15 个 + 串行合计 + 实际墙钟 + 启动基线占比」。
# 启动基线（min of 3 次 `raku -e ''`）是关键分母：它把"启动开销"从"测试内容"里
# 摘出来，否则任何优化都无从判断收益。--no-timings 可关掉（CI 日志想干净时）。
#
# 【首轮实测（0.88.2，本机 8 并发）—— 它推翻了"瓶颈是进程数"的直觉】
#   135 个用例、耗时合计 1917s（平均 14.2s）；t/ 墙钟 282s、xt/ 394s，加速比 2.83x；
#   而 `raku -e ''` 启动基线只有 0.22s，占用例合计 **2%**。
#   ⇒ 本项目的瓶颈是**重测试本身**（xt/ 里跑真实 install/upgrade 的那种，单个 30–160s）
#     与**分批调度**，不是起进程的开销。所以「启动占比低」绝不能当成"没问题"的结论；
#     看的是最慢排行前几名，以及加速比与 jobs 的差距（差距大 = 长尾）。
#   教训：这段注释最早写的是"各用例耗时都贴近启动基线 ⇒ 瓶颈是进程数"——先验假设，
#   实测直接否掉。判据要等数据，别把猜测写成结论。
# 加速比为什么只有 2.83x（8 并发）的**三个**原因 —— 0.88.3/0.88.4 逐个改掉：
#   ① 按 basename 分批 ⇒ 长任务随机落在批次尾部，批尾常只剩 1–2 个长任务在跑（长尾）
#      → 改成**合并池 + LPT 分桶**（长短用例同一池、最长用例优先；见下方调度段注释）；
#   ② t/ 与 xt/ 两段串行、各预热一次 → 改成**一个池跑完 + 只预热一次**；
#   ③ 各条道**按层同步**（第 i 层一起跑、等全层完成才进下一层）⇒ 每层末尾一道屏障，
#      某条道上排着 160s 的用例时别的道空等 → 改成**每条道独立连续跑**。
#   ①②落地后 699.8s → 544.8s（加速比 5.05x），③ 之后再降一截。
#
# 【为什么现在默认并行】此前为躲「并发首编译 lib 触发预编译竞态」而默认串行，但那
# 等于把多核机当单核用（24 核只跑 1 个）。如今默认按 CPU 核数并行（上限 8），并加两
# 道安全网：① 跑前先把 lib 预热编译（-c）把 precomp 写热；② 跑完对失败用例【串行复验】
# 一次，竞态/时序敏感假失败被剔除。要纯串行就 --jobs=1。RAKUPM_NO_PRECOMP_WARMUP 跳预热。
#
# 【调度：t/ 与 xt/ 合池 + LPT 分桶 + 每条道连续跑】细节见下方「用例清单 / 历史耗时 /
# LPT 调度」段。一句话：长任务先起、短任务填空槽，分配到 $jobs 条道上各跑各的（**不设
# 层屏障**，谁先空谁接下一个）。分桶是**划分**，并配防漏跑断言（计划里有用例没被执行
# → 直接中止门禁）—— 调度 bug 不允许以绿灯的形式存在。
# ==============================================================================

use v6.d;
use JSON::Fast;

use lib $*PROGRAM.parent.Str;
use NamedArgCheck;                       # 具名实参静态检查（本目录下的开发工具）

my IO::Path $root = $*PROGRAM.parent.parent.absolute.IO;
my $raku = $*EXECUTABLE.Str;

# 测试一律以【工作树】的 lib/ 为准。用绝对路径而不是 `-Ilib`：后者依赖 cwd，一旦 cwd
# 不是仓库根，链上就没有 lib/，测试会静默改用系统里**已安装**的 RakuPM —— 那正是
# 0.49.2 在用户 Linux 机上暴露的事故（详见 tests-see-worktree 的注释）。
my $lib-abs = $root.add('lib').absolute.Str;

my Bool $do-t    = True;
my Bool $do-xt   = True;
my Bool $do-docs = True;
my Bool $do-static = True;               # 具名实参静态检查（秒级，预提交也跑）
my Bool $do-timings = True;              # 每用例耗时 + 最慢排行（见文件顶注释）
my Str  $filter  = '';
my Int  $jobs    = do { my $n = try ($*KERNEL.cpu-cores // 4) // 4; min($n, 8) }; # 默认按 CPU 核数并行，上限 8

# ---------------------------------- 参数 --------------------------------------
my @argv = @*ARGS;
while @argv.elems {
    my $a = @argv.shift;
    if $a eq '--help' || $a eq '-h' || $a eq 'help' {
        print usage-text();
        exit 0;
    }
    elsif $a eq '--only=t'      { $do-xt = False; $do-docs = False; $do-static = False }
    elsif $a eq '--only=xt'     { $do-t  = False; $do-docs = False; $do-static = False }
    elsif $a eq '--no-t'        { $do-t  = False }
    elsif $a eq '--no-xt'       { $do-xt = False }
    elsif $a eq '--docs-only'   { $do-t  = False; $do-xt = False }
    elsif $a eq '--no-docs'     { $do-docs = False }
    elsif $a eq '--no-static'   { $do-static = False }
    elsif $a eq '--no-timings'  { $do-timings = False }
    elsif $a eq '--precommit'   { $do-t = False; $do-xt = False; $do-docs = True }
    elsif $a ~~ /^ '--filter=' (.+) $/ { $filter  = ~$0 }
    elsif $a ~~ /^ '--jobs='   (\d+) $/ { $jobs    = +$0 }
    else {
        note "未知选项：$a";
        note "  用 `raku tools/run-suite.raku --help` 看用法（不接受拼错的旗标）";
        exit 2;
    }
}
$jobs max= 1;

# --------------------------------- 小工具 -------------------------------------

# ------------------------------- 计时（见文件顶注释） --------------------------
my $script-t0 = now;            # 整个脚本的墙钟起点（含静态/文档检查）
my @timings;                    # 每用例：%( rel, secs, retry )
my @phase-secs;                 # 每个测试目录的墙钟：%( label, secs )
my @warm-secs;                  # 预热预编译：%( label, secs )

# 形参收 Real 而不是 Num：`$sum / @real.elems` 这类除法结果是 Rat，写成 Num 会
# "Type check failed"。同理 `now - $t0` 得到的是 Duration，必须 `.Num` 才有数值
# （Duration 直接返回会报 "expected Num but got Duration"）。
sub fmt-secs(Real $s --> Str) { sprintf('%.2f', $s) }

# raku 进程启动基线：min of 3 次 `raku -e ''`。
# 【为什么是 min 而不是平均】这里要量的是"启动这件事本身的下限"；平均值会被磁盘
# 抖动 / 首次触碰 exe 拉高，反而看不清地板在哪。取 min = 该机上单次启动的最优值。
sub startup-baseline(--> Num) {
    my @s;
    for ^3 {
        my $t0 = now;
        capture([$raku, '-e', '']);
        @s.push((now - $t0).Num);
    }
    @s.min
}

sub print-timings(--> Nil) {
    return unless $do-timings;
    my @real = @timings.grep({ !.<retry> });
    return unless @real.elems;
    say "";
    say "===== 用例耗时（单文件墙钟，含 raku 启动；最慢 15 个） =====";
    for @real.sort({ -.<secs> }).head(15) -> %t {
        say sprintf('  %8s  %s', fmt-secs(%t<secs>) ~ 's', %t<rel>);
    }
    # 注意这些统计量一律【不加类型约束】：空列表的 `.sum` 返回 Int 0，写成
    # `my Num $x` 会 "Type check failed … expected Num but got Int (0)"（实测踩过）。
    my $sum = @real.map(*.<secs>).sum;
    say "";
    say "  用例耗时合计（= 若串行跑一遍的下限）: {fmt-secs($sum)}s（{@real.elems} 个用例，"
      ~ "平均 {fmt-secs($sum / @real.elems)}s）";
    for @phase-secs -> %p {
        say "  {sprintf('%-3s', %p<label>)} 实际墙钟: {fmt-secs(%p<secs>)}s";
    }
    my $wall = @phase-secs.map(*.<secs>).sum;
    # 单个用例时"加速比"没有意义（预热/自检占比还很高），别让它误导人。
    if @real.elems > 1 && $wall > 0 {
        say "  并行加速比: {sprintf('%.2f', $sum / $wall)}x（用例合计 ÷ 墙钟；"
          ~ "墙钟含预热/串行复验/自检）";
    }
    for @warm-secs -> %w {
        say "  ↳ 其中 {%w<label>} 预热预编译: {fmt-secs(%w<secs>)}s（已含在墙钟内）";
    }
    my $retry-sum = @timings.grep({ .<retry> }).map(*.<secs>).sum;
    if $retry-sum > 0 {
        say "  ↳ 其中串行复验: {fmt-secs($retry-sum)}s"
          ~ "（{@timings.grep({ .<retry> }).elems} 个用例，已含在墙钟内）";
    }
    my $base = startup-baseline();
    my Int $n = @real.elems;
    say "  raku 启动基线（min of 3 × `raku -e \"\"`）: {fmt-secs($base)}s";
    say "  → 光启动就占用例合计的 {sprintf('%.0f', 100 * $base * $n / $sum)}%"
      ~ "（{$n} × {fmt-secs($base)}s = {fmt-secs($base * $n)}s）"
      ~ "；用例内容本身的净耗时约 {fmt-secs($sum - $base * $n)}s";
    say "  注：加速比 = 用例合计 ÷ 墙钟。加速比远低于 jobs 通常是【分批不当的长尾】"
      ~ "（长任务落批尾、批尾只剩 1–2 个在跑），而不是并行没生效。"
      ~ "两头都要看：启动基线占比高 ⇒ 瓶颈是进程数；占比低（本机实测 2%，平均 14.2s 用例）"
      ~ "⇒ 瓶颈是重测试本身，先看上面的排行前几名。";
}
sub usage-text(--> Str) {
    q:to/USAGE/;
    raku tools/run-suite.raku — raku-pm 本地全量回归 + 静态检查 + 文档纪律 + 个人痕迹检查

      （无参数）        t/ + xt/ + 具名实参检查 + 文档纪律 + 个人痕迹
      --no-xt           跳过 xt/（网络 / 重 / 故意失败的集成测试）
      --no-t            跳过 t/
      --only=t          只跑 t/
      --only=xt         只跑 xt/
      --docs-only       只做静态检查 + 文档纪律 + 个人痕迹（秒级，适合预提交）
      --precommit       静态检查 + 文档纪律 + 个人痕迹 + 编译暂存的 .rakumod/bin 文件（快，适合 git hook）
      --no-docs         不做文档纪律校验（个人痕迹检查也随之跳过）
      --no-static       不做具名实参检查（tools/check-named-args.raku）
      --filter=SUBSTR   只跑文件名含 SUBSTR 的用例
      --jobs=N          t/ xt/ 并发度（默认按 CPU 核数、上限 8；设 1 则完全串行）
      --no-timings      不打印每用例耗时 / 最慢排行 / 启动基线（CI 日志求干净时用）
      -h, --help        本帮助

    退出码：0 全过 / 1 有失败 / 2 参数错。
    USAGE
}

# 急切收集（Windows 上惰性迭代会持住目录句柄），按 basename 稳定排序。
# 刻意**不**依赖 lib/RakuPM/Fs —— 门禁脚本必须在源码坏掉时仍能跑起来。
sub walk-files(IO::Path $d --> List) {
    return () unless $d.d;
    my @out;
    my @entries = $d.dir;               # 急切收集
    for @entries.sort({ .basename }) -> $e {
        $e.d ?? @out.append(walk-files($e)) !! @out.push($e);
    }
    @out.List
}

sub norm(Str $p --> Str) { $p.subst('\\', '/', :g) }

sub rel-str(IO::Path $f --> Str) { norm($f.relative($root).Str) }

# 测试子进程的**统一**启动参数。
#
# 必须收敛成一个函数：自检（tests-see-worktree）与真正跑测试（run-one）要共用它，
# 否则自检只是「自说自话」—— 比如有人把 run-one 里的 -I 删了，自检仍然绿。
# 共用之后，任何一处动了 -I，自检立刻变红。
sub test-args(Str $target, *@extra --> List) {
    ($raku, '-I' ~ $lib-abs, $target, |@extra)
}

sub test-files(Str $dir, Str $filter --> List) {
    my $d = $root.add($dir);
    return () unless $d.d;
    my @files = $d.dir.grep({
        .f && (.extension.lc eq 't' || .extension.lc eq 'rakutest')
    }).sort({ .basename });
    @files = @files.grep({ .basename.contains($filter) }) if $filter.chars;
    @files.List
}

# ------------------- 自检：测试必须看到【工作树】的 lib/ -------------------
#
# 【为什么必须有这一条】0.49.2 的用户现场：本脚本以前是
#   run($raku, $rel, :out, :err, :cwd($root));      # ← 没有 -Ilib
# 于是**任何没有写 `use lib` 的测试文件都在测系统里已安装的 RakuPM，而不是工作树**。
# Linux 上一口气红了 5 个文件（author-check / store-lock / store-provides-ext /
# repos / http），而开发机 Windows 上全过 —— 只因那台机器已装的那份 RakuPM 恰好
# 自洽。这是一类「门禁看着绿、其实测的不是这份代码」的假绿，比没有门禁更危险。
#
# 现在测试一律带 `-I<绝对路径>/lib`，并且**跑之前先用同一个启动方式证明它生效**：
# 链首必须是本仓库的 lib/。判据用 `$*REPO.repo-chain.head`（实测 head 就是 `-I`
# 那个 FileSystem 仓库），不去解析具体模块 —— 便宜，且不依赖任何模块能否加载。
# 已实测对照：带 -Ilib 时链首是本仓库 lib/；不带时链首直接是用户的 RAKULIB 目录，
# 本仓库 lib/ 根本不在链上。
# 起子进程并【并发】抽干 stdout / stderr → %( out, err, code )。
#
# 【为什么必须并发，别改回顺序 slurp】子进程若把某一条流写满管道缓冲（Windows 上约
# 64KB），它会阻塞在 write 上；父进程若「先 slurp stdout 再 slurp stderr」，就永远等
# 不到那条流的 EOF → **双向死锁**。表现极具欺骗性：CPU 0%、无子进程、无限等待，
# 看起来只是"套件跑得慢"。0.87.1 实测：`xt/http.t` 的 stderr 有 258KB（stdout 仅
# 1.4KB），用顺序版跑它 61 秒零进展、stderr 恰好停在管道容量 64777 字节，整份
# `--only=xt` 因此卡在它上面 23 分钟一动不动。项目记忆里早已记过同一坑
# （「捕获 + 孙进程继承同管道」会死锁）。
sub capture(@argv, :$cwd = $root --> Hash) {
    my $p = run(|@argv, :out, :err, :cwd($cwd));
    my $out-p = start { $p.out.slurp(:close) };
    my $err-p = start { $p.err.slurp(:close) };
    # 先把两个 await 落到变量里再组 Hash —— 写成 `%( out => await $a, err => await $b )`
    # 的话，`await` 是 slurpy，会把后面的 `err => …`/`code => …` 当成它自己的具名参数
    # （实测报 "Cannot resolve caller await(Promise:D, :code(Int))"）。
    my $out = await $out-p;
    my $err = await $err-p;
    %( out => $out, err => $err, code => $p.exitcode )
}

sub tests-see-worktree(--> Bool) {
    my $probe = q{my $h = $*REPO.repo-chain.head; say $h.defined ?? $h.Str !! ''};
    my %r = capture(test-args('-e', $probe));
    my $out = %r<out>.trim;
    return False unless %r<code> == 0;
    # 折大小写：Windows 上同一条路径的大小写形式可能不同；Linux 上两侧同时折也不出错。
    norm($out).lc eq norm($lib-abs).lc
}

# ------------------------------- 跑一个测试文件 -------------------------------
sub run-one(IO::Path $f, Bool $strict --> Hash) {
    my $rel = rel-str($f);
    my $t0 = now;
    my %r = capture(test-args($rel));
    # 计时覆盖"起进程 → 退出"的整段（含 raku 启动与 precomp 检查）：这正是门禁
    # 真正付出的代价。别改成只计时测试体内的部分 —— 那会低估到失去意义（见顶注释）。
    my Num $secs = (now - $t0).Num;
    my $out = %r<out>;
    my $err = %r<err>;
    my $code = %r<code>;
    my $all = $out ~ $err;
    my @noise = $strict
        ?? $all.lines.grep({ $_.contains('⚠') || $_.contains('[RakuPM]') }).List
        !! ().List;
    %(
        rel   => $rel,
        code  => $code,
        noise => @noise,
        ok    => ($code == 0 && !@noise.elems),
        tail  => $all.lines.tail(25).join("\n"),
        secs  => $secs,
        strict => $strict,
    )
}

sub report(%r --> Nil) {
    my Str $t = $do-timings ?? '（' ~ fmt-secs(%r<secs>) ~ 's）' !! '';
    if %r<ok> {
        say "  ok    {%r<rel>}{$t}";
        return;
    }
    say "  FAIL  {%r<rel>}{$t}";
    say "        （退出码 {%r<code>}）" if %r<code> != 0;
    if %r<noise>.elems {
        say "        （喷了生产级警告 ⚠ / [RakuPM]，会搞乱 zef install 日志）：";
        for %r<noise>.head(5) -> $n { say "          {$n.trim}" }
    }
    if %r<tail>.trim.chars {
        say "        --- 输出尾部 ---";
        for %r<tail>.lines -> $l { say "        {$l}" }
    }
}

# 预热：把 lib/ 下每个 .rakumod 各编译一遍（-c，不执行），把 precomp 缓存写热。
# 以 $jobs 并发编译，避免后续测试进程并发首跑同一份模块触发 rakudo 预编译竞态
# （表现为偶发的 ===SORRY!=== Error while compiling 假失败）。RAKUPM_NO_PRECOMP_WARMUP
# 可跳过（回归/调试用）。
sub warmup-precomp(Int $jobs --> Num) {
    my @mods = walk-files($root.add('lib'))
        .grep({ .extension.lc eq 'rakumod' })
        .sort({ .basename });
    return 0e0 unless @mods.elems;
    say "  （预热 lib 预编译缓存：{@mods.elems} 个模块，并发 {$jobs}）";
    my $t0 = now;
    my @queue = @mods.list;
    while @queue.elems {
        my @batch = @queue.splice(0, $jobs);
        await @batch.map(-> $m {
            start {
                capture([$raku, '-I' ~ $lib-abs, '-c', $m.Str]);
            }
        });
    }
    (now - $t0).Num
}

# ----------------- 用例清单 / 历史耗时 / LPT 调度（0.88.3） -------------------
#
# 【为什么不按目录分开跑】0.88.2 实测：135 个用例、耗时合计 1917s，8 并发却只拿到
# 2.83x。病根是"按文件名分批"—— 长任务随机落在批次尾部，批尾常只剩一两个还在跑、
# 其余并发槽空转（`xt/self-upgrade-bootstrap` 单个 158.7s，足以独占一条尾巴）。
# 合成一个池之后，t/ 里那些 1–8s 的短用例正好填进 xt/ 长用例留下的空槽。
#
# 【为什么是 LPT 分桶，而不是"谁先空谁抢下一个"】LPT（最长处理时间优先 + 依次放进
# 当前最空的桶）实现上只是**一次排序 + 一次划分**，没有"哪个子进程刚结束"的异步
# 状态机；而它是**划分**：每个用例恰好属于一个桶。配合下面的防漏跑断言，"漏跑用例"
# 这种最可怕的假绿在结构上就不可能悄悄发生 —— 事件驱动调度也许还能再快一点，但门禁
# 因为调度自己出 bug 而漏跑，得到的绿灯比红灯危险得多，不值得换。
my %est;                       # rel => 该用例"本身有多重"（秒），供 LPT 排序

# 历史耗时缓存：默认 ~/.raku-pm/suite-timings.json（RAKUPM_SUITE_TIMINGS 可覆盖）。
# 【为什么不放仓库里】它若落在仓库根，就得同时进 .gitignore 与 .distignore，而
# .distignore 里"写了却匹配不到文件"的条目会让 Author 打包时喷 ⚠（干净 clone 首次
# 打包必然匹配不到）—— 为一个纯提示性的缓存去动打包面，不值得。
sub timings-cache-path() {
    my Str $env = %*ENV<RAKUPM_SUITE_TIMINGS> // '';
    return $env.IO if $env.chars;
    my Str $home = (%*ENV<USERPROFILE> // %*ENV<HOME> // '');
    return IO::Path unless $home.chars;      # 拿不到家目录 → 不持久化（只是排序差些）
    $home.IO.add('.raku-pm').add('suite-timings.json')
}

sub load-estimates(--> Nil) {
    my $p = timings-cache-path();
    return unless $p.defined && $p.f;
    my $j = try { from-json($p.slurp) };
    return unless $j ~~ Associative && $j<cases> ~~ Associative;
    for $j<cases>.pairs -> $kv {
        %est{$kv.key} = +$kv.value if $kv.value ~~ Real && +$kv.value > 0;
    }
}

sub save-estimates(--> Nil) {
    my $p = timings-cache-path();
    return unless $p.defined;
    return unless %est.elems;
    # 缓存写失败绝不能把门禁弄红：它只是排序提示。故整段 try，失败就算了。
    try {
        $p.parent.mkdir unless $p.parent.d;
        $p.spurt(to-json({ cases => %est, updated => ~DateTime.now }));
    }
}

# 无历史时的粗启发式：只为让"第一次跑"也能把显然更重的目录排到前面。
# 第二次起就有实测数据了（跑完会写回缓存）。
sub default-est(Str $dir --> Num) { $dir eq 'xt' ?? 20e0 !! 6e0 }

sub plan-entries(Str $dir, Bool $strict --> List) {
    my @out;
    for test-files($dir, $filter) -> $f {
        my Str $rel = rel-str($f);
        @out.push(%(
            rel    => $rel,
            dir    => $dir,
            strict => $strict,
            est    => (%est{$rel} // default-est($dir)),
        ));
    }
    @out.List
}

# LPT 分桶：按预估耗时降序，依次放进当前累计负载最小的桶。
sub partition-lpt(@plan, Int $lanes --> List) {
    my @buckets;
    @buckets.push([]) for ^$lanes;
    my @load = 0e0 xx $lanes;
    for @plan.sort({ -.<est> }) -> %t {
        my Int $i = @load.minpairs.head.key;
        @buckets[$i].push(%t);
        @load[$i] += %t<est>;
    }
    @buckets.List
}

# 并发打印锁：多条道同时推进时，report 会从不同线程调用 —— 用锁把"一次 report"串起来，
# 保证每行输出都完整（单次 say 通常原子，但日志完整性不值得赌）。
my $print-lock = Lock.new;

# 跑整份计划，返回**仍然失败**的用例清单（并发假失败已串行复验剔除）。
sub run-plan(@plan --> List) {
    my %strict-by-rel = @plan.map({ .<rel> => .<strict> });
    my @results;
    my %ran;
    # jobs==1 时不做 LPT：串行总时间与顺序无关，保持文件名顺序（与旧行为一致，
    # 免得按顺序读日志时对不上）。
    my @lanes = $jobs > 1 ?? partition-lpt(@plan, $jobs) !! (@plan.List,);
    if $jobs > 1 {
        say "  （LPT 调度：{@plan.elems} 个用例 / {$jobs} 条道，最长用例优先；每条道连续跑）";
    }

    # 【每条道独立连续跑 —— 不要退回"按层同步"】
    # 上一版是「第 i 层 = 每条道的第 i 个元素，一起跑完再进下一层」，那会在每层末尾立起
    # 一道**屏障**：某条道上排着 160s 的用例、别的道该层只要 5s，那几条道就得空等 155s。
    # 实测总墙钟 545s、理论下界 ≈371s，差的正是这个（下界 = max(最长用例 195s, 合计/jobs)）。
    # 各道独立推进后，谁先跑空谁立刻接下一个，屏障消失；并发上限仍是 $jobs（每条道同时
    # 只跑一个子进程），所以不会突然把机器压爆。
    #
    # 【线程安全】worker 只做两件事：① 实时打印，经 $print-lock 串行化（单行不会交错）；
    # ② 把结果 push 进【自己的】数组并作为返回值交回。共享容器（@results / @timings /
    # %est）一律由主线程在 await 之后统一更新 —— 多线程并发写 Array/Hash 在 Raku 里
    # 没有保证，宁可多一轮汇总也不要赌。
    my @lane-results = await @lanes.map(-> @lane {
        start {
            my @out;
            for @lane -> %t {
                my %r = run-one($root.add(%t<rel>), %t<strict>);
                $print-lock.protect({ report(%r) });
                @out.push(%r);
            }
            @out;
        }
    });
    for @lane-results -> @rs {
        for @rs -> %r {
            %ran{%r<rel>} = True;
            @results.push(%r);
            @timings.push(%( rel => %r<rel>, secs => %r<secs>, retry => False )) if $do-timings;
            # 耗时回填：并发下测得的值会被 IO/CPU 竞争放大，故与历史取 min ——
            # 我们要的是"这个用例本身有多重"，偏保守的值排序更稳。
            my $s = %r<secs>;
            %est{%r<rel>} = %est{%r<rel>}:exists ?? min(%est{%r<rel>}, $s) !! $s;
        }
    }

    # ★ 防漏跑（门禁自身的假绿防线）：计划里每个用例必须恰好执行一次。
    # 未执行的用例 = 没测 = 绝不能算绿，而且从输出上完全看不出来 —— 故直接中止。
    my @missing = @plan.map(*.<rel>).grep({ !%ran{$_} }).List;
    if @missing.elems || @results.elems != @plan.elems {
        say "";
        say "===== 调度自检失败（中止） =====";
        say "  计划 {@plan.elems} 个用例，实际执行 {@results.elems} 个。";
        if @missing.elems {
            say "  以下用例【没有被执行到】（未执行的用例等于没测，绝不当作绿灯）：";
            for @missing.head(10) -> $m { say "    {$m}" }
        }
        else {
            say "  有用例被重复执行 —— 调度划分有 bug。";
        }
        exit 1;
    }

    # 并发假失败兜底：把失败的用例【串行复验】一次（并行竞态 / 时序敏感的偶发失败
    # 会在串行复验中通过，从而不污染最终结果，与 Tester 同款机制）。
    my @failed = @results.grep({ !.<ok> }).map(*.<rel>).List;
    if $jobs > 1 && @failed.elems {
        my @still;
        for @failed -> $rel {
            my %r = run-one($root.add($rel), %strict-by-rel{$rel});
            @timings.push(%( rel => %r<rel>, secs => %r<secs>, retry => True )) if $do-timings;
            if %r<ok> {
                say "    ↻ 串行复验通过（疑似并发假失败，已从失败清单剔除）：{$rel}";
            }
            else {
                @still.push($rel);
            }
        }
        @failed = @still;
    }

    # 分组小结：实时输出是混着来的（合并调度的必然结果），故末尾按目录再给一眼可读的结论。
    my @dirs = @results.map({ .<rel>.starts-with('xt/') ?? 'xt' !! 't' }).unique.sort;
    if @dirs.elems > 1 {
        say "";
        say "----- 分组小结 -----";
        for @dirs -> $d {
            my @sub = @results.grep({ .<rel>.starts-with("{$d}/") }).List;
            my Int $bad = @sub.grep({ !.<ok> }).elems;
            say "  {$d}/  {@sub.elems} 个：{$bad ?? "失败 {$bad} 个（见汇总）" !! '全过'}";
        }
    }
    @failed.List
}

# ------------------------------ 文档纪律校验 ----------------------------------
sub check-docs(--> List) {
    my @fails;

    my $meta-path = $root.add('META6.json');
    if !$meta-path.f {
        return ("META6.json 不存在",).List;
    }

    my $meta;
    try { $meta = from-json($meta-path.slurp) }
    if !$meta.defined {
        return ("META6.json 无法解析 —— 发布前必须先修好它",).List;
    }
    unless $meta ~~ Associative {
        return ("META6.json 顶层必须是对象（Associative），实为 {$meta.WHAT.raku}",).List;
    }

    my $version = ($meta<version> // '').Str;
    @fails.push("META6.json 缺 version 字段") unless $version.chars;

    # 1) 版本号示例一致性（RakuPM:ver<x.y.z>）
    #    基准文件 README.md / README.en.md：**必须**含版本示例，且全部等于 META6 版本。
    #    文档目录 docs/*.md（递归）：若含版本示例则必须与 META6 一致（**不强制必须有**）——
    #    版本示例迁到 docs/ 后，该校验范围必须同步扩展，否则每次提交必红（见 Issue 1 修正）。
    my @doc-files = ('README.md', 'README.en.md');
    my %strict = 'README.md' => True, 'README.en.md' => True;
    if $root.add('docs').d {
        for walk-files($root.add('docs')).grep({ .extension.lc eq 'md' }) -> $p {
            @doc-files.push(norm($p.relative($root).Str));
        }
    }
    for @doc-files -> $rn {
        my $f = $root.add($rn);
        if !$f.f {
            @fails.push("{$rn} 不存在");
            next;
        }
        my @found;
        for $f.lines -> $line {
            # 注意 <[ ... ]> 里的范围必须写 `..`（`0-9` 会被 Rakudo 拒为
            # 「Unsupported use of - as character range」）—— 见 Author.rakumod 同款写法。
            my @ms = $line.match(/ 'RakuPM:ver<' (<[0..9.]>+) '>' /, :g) // ();
            for @ms -> $m { @found.push(~$m[0]) }
        }
        my $strict = %strict{$rn} // False;
        if !@found.elems {
            @fails.push("{$rn} 里找不到 `RakuPM:ver<x.y.z>` 版本示例（约定：必须与 META6 同步）")
                if $strict;
            next;
        }
        for @found.unique -> $v {
            @fails.push("{$rn} 的版本示例 RakuPM:ver<{$v}> 与 META6 的 {$version} 不一致")
                if $v ne $version;
        }
    }

    # 2) Changes 顶部条目 = META6 版本
    my $ch = $root.add('Changes');
    if !$ch.f {
        @fails.push("Changes 不存在（约定：每次改动必须补条目）");
    }
    else {
        my $first = $ch.lines.first({ $_ ~~ /^ '## ' / });
        if !$first.defined {
            @fails.push("Changes 里找不到 `## X.Y.Z` 形式的版本标题");
        }
        else {
            my $m = $first.match(/ '## ' (<[0..9.]>+) /);
            my $cv = $m.defined ?? ~$m[0] !! '';
            @fails.push("Changes 最新条目 {$cv} 与 META6 的 {$version} 不一致")
                if $cv.chars && $cv ne $version;
        }
    }

    # 3) provides ↔ lib/ 下实际 .rakumod 互为全集
    my %provides = %($meta<provides> // {});
    my @declared = %provides.values.map({ norm($_.Str) }).sort.unique;
    my @actual = walk-files($root.add('lib'))
        .grep({ .extension.lc eq 'rakumod' })
        .map({ rel-str($_) }).sort;
    for @actual -> $f {
        @fails.push("lib 下的 {$f} 未在 META6 provides 里声明（装了也 use 不到）")
            unless $f (elem) @declared;
    }
    for @declared -> $f {
        @fails.push("META6 provides 声明的 {$f} 不存在") unless $root.add($f).f;
    }

    # 4) bin 清单里的文件必须存在
    my @bins = ($meta<bin> // []).List;
    for @bins -> $b {
        my $p = norm($b.Str);
        @fails.push("META6 bin 声明的 {$p} 不存在") unless $root.add($p).f;
    }

    # 5) 依赖清单里不能有空项（空字符串会让解析器拿到无意义约束）
    my %depends = %($meta<depends> // {});
    my %runtime = %(%depends<runtime> // {});
    my @req = (%runtime<requires> // []).List;
    for @req -> $r {
        @fails.push("META6 depends.runtime.requires 里有空项")
            unless $r.defined && $r.Str.trim.chars;
    }

    # 6) 发布包内容纪律：哪些 .md 允许进包 / .distignore 条目是否还有效
    #    （独立成 sub：它要复用 walk-shipped / dist-ignored-entries，那两个在下面定义）
    @fails.append(check-shipped-docs());

    @fails.List
}

# ---------------------------- 暂存文件的编译门禁 ------------------------------
sub staged-source-files(--> List) {
    my %r = capture(['git', 'diff', '--cached', '--name-only', '--diff-filter=ACM']);
    my $out = %r<out>;
    return ().List unless %r<code> == 0;
    $out.lines.map(*.trim).grep({
        .chars && !.starts-with('#') &&
        (.ends-with('.rakumod') || .ends-with('.raku') || .ends-with('.pm6') ||
         .ends-with('.rakutest') || .ends-with('.t'))
    }).grep({ $root.add($_).f }).List
}

sub check-staged-compile(--> List) {
    my @fails;
    my @files = staged-source-files();
    return @fails.List unless @files.elems;
    say "";
    say "===== 编译暂存文件（{@files.elems} 个） =====";
    for @files -> $f {
        my %r = capture([$raku, '-Ilib', '-c', $f]);
        my $out = %r<out>;
        my $err = %r<err>;
        if %r<code> == 0 {
            say "  ok    {$f}";
        }
        else {
            say "  FAIL  {$f}";
            for (($out ~ $err).lines.tail(15)) -> $l { say "        {$l}" }
            @fails.push("{$f} 编译失败");
        }
    }
    @fails.List
}

# ------------------------------ 个人痕迹检查 ----------------------------------
#
# 【为什么需要它 · 血的教训】这类泄漏会以「换个写法再写一遍」的形式复发：
#   · 0.74.1 清掉了历史文档里的个人用户名；
#   · 0.75.0 的 Changes 在说明「我清理了那个用户名」时，又把该用户名原样写了进去
#     —— 语义上是在报告修复，效果上等于换个地方把它发到公开生态；
#   · 0.75.1 的条目描述「本机用户名 → 中性占位」时，又把本机用户名写了回来。
# 靠人「发版前记得 grep 一下」不可靠，故钉进门禁 —— 它在 --docs-only / --precommit /
# 全量门禁三种口径下都会跑。
#
# 【本函数里的黑名单不能写字面量】要禁的字符串若在此出现字面量，本文件自己就成了
# 泄漏源（tools/ 同样会进 sdist）。故一律用 `'a' ~ 'b'` 拼接构造。
#
# 扫描范围 = **会进发布包的内容**：跳过 dot 目录（打包层已确认 .git/.precomp/
# .workbuddy 等不进 sdist）与 blib，并跳过 `.distignore` 里列出的条目 —— 否则
# 内部文档（CODEBUDDY.md 之类）里的路径会把门禁误报成红。
sub walk-shipped(IO::Path $d --> List) {
    return () unless $d.d;
    my @out;
    for $d.dir.sort({ .basename }) -> $e {
        if $e.d {
            next if $e.basename.starts-with('.') || $e.basename eq 'blib';
            @out.append(walk-shipped($e));
        }
        else {
            @out.push($e);
        }
    }
    @out.List
}

sub dist-ignored-entries(--> List) {
    my $f = $root.add('.distignore');
    return () unless $f.f;
    my @out;
    for $f.lines -> $line {
        my Str $s = $line.trim;
        next unless $s.chars;
        next if $s.starts-with('#');
        # 行尾注释：`#` 前须有空白（与 .gitignore 同款语义；Author.!dist-ignores 同规则）
        $s = $s.subst(/ \s+ '#' .* $ /, '').trim;
        next unless $s.chars;
        @out.push($s.subst('\\', '/', :g).subst(/^ '.\/' /, '').subst(/\/+$/, ''));
    }
    @out.List
}

# ------------------- 发布包内容纪律（内部文档不许静默进包） --------------------
#
# 【为什么需要它 · 血的教训】`.distignore` 的注释写着「内部开发文档不宜发到公开生态」，
# 但它的匹配是**按路径**的：REFACTOR-ISSUES.md 一直被排除着，而它的 docs/ 版本
# `docs/refactor-roadmap.md`（298 行）是后来新增/搬家的 —— 没人补 .distignore，
# 于是它**静默进了 sdist**（写本条时实测 `tar -tzf` 清单里确有其名）。
# 这类泄漏不会让任何测试变红：它只在发布那一刻才生效，事后无从察觉。
#
# 故把「哪些 .md 允许进包」改成**显式白名单**：新增一个 .md 时二者必居其一 ——
#   · 登记进本函数的 @public（＝决定公开）；或
#   · 写进 .distignore（＝内部文件）；
# 否则门禁红。
#
# 【刻意不查「.distignore 的条目是否指向真实存在的文件」】—— 那条规则已经有人管了：
# Author 打包时对「写了却匹配不到任何文件」的条目会往 stderr 喷 ⚠（见
# xt/dist-ignore.t 场景 3）。同一条规则实现两遍＝日后改一处忘一处，故这里不复刻。
sub check-shipped-docs(--> List) {
    my @fails;
    # 允许进发布包的文档（＝有意公开）。新增公开文档时在此登记。
    my @public = <
        README.md README.en.md
        docs/MANUAL.md docs/MANUAL.en.md
        docs/architecture.md docs/architecture.en.md
        docs/quickstart.md docs/quickstart.en.md
        docs/nav-map.md
    >;
    for @public -> $rn {
        @fails.push("公开文档白名单里的 {$rn} 不存在（白名单过期）")
            unless $root.add($rn).f;
    }
    my @ignores = dist-ignored-entries();
    for walk-shipped($root).grep({ .extension.lc eq 'md' }) -> $f {
        my Str $rel = rel-str($f);
        next if $rel (elem) @public;
        my Bool $ignored = so @ignores.first({ $rel eq $_ || $rel.starts-with("{$_}/") });
        next if $ignored;
        @fails.push("{$rel} 会进发布包，却不在公开文档白名单里："
            ~ "要公开就登记进 tools/run-suite.raku 的 @public，要内部就写进 .distignore");
    }
    @fails.List
}

sub check-personal-traces(--> List) {
    my @fails;
    my $workspace = 'Work' ~ 'Buddy';   # ① 本机工作区根目录名
    my $legacy    = 'z' ~ 'by';         # ② 历史遗留的短用户名
    # ③ 中性占位白名单：这些「名字」是技术示例，允许出现在路径里
    my @neutral = <user User USER username foo bar baz x X tester test me
                   example sample alice bob someone name public nobody>;

    my @ignores = dist-ignored-entries();
    my @ext-ok = <md rakumod raku t json yml yaml txt pm ps1 bat sh
                  gitignore gitattributes distignore>;
    my @scan = walk-shipped($root).grep(-> IO::Path $f {
        my Str $rel = rel-str($f);
        my Bool $ignored = so @ignores.first({ $rel eq $_ || $rel.starts-with("{$_}/") });
        !$ignored && ($f.extension (elem) @ext-ok || $f.basename eq 'Changes')
    }).List;

    my @hit-path; my @hit-legacy; my @hit-user;
    for @scan -> $f {
        my Str $text = (try { $f.slurp } // '');
        next unless $text.chars;
        my Str $rel = rel-str($f);
        for $text.lines.kv -> $i, $line {
            my Int $n = $i + 1;
            @hit-path.push("{$rel}:{$n}") if $line.contains($workspace);
            @hit-legacy.push("{$rel}:{$n}") if $line.contains($legacy);
            for ($line.match(/ 'Users' <[\\\/]>+ (\w+) /, :g) // ()) -> $m {
                my Str $who = ~$m[0];
                @hit-user.push("{$rel}:{$n}（Users\\{$who}）") unless $who (elem) @neutral;
            }
        }
    }

    # 注意必须显式 `.List`：`Seq` 不是 Positional，`append` 不会展平它，会把它当
    # 【单个元素】塞进去（元素 stringify 成内容拼接，空 Seq 就是空串）—— 症状是
    # 「明明命中 3 处、打印出来却是 3 行空白」。踩过一次，别再省这个 `.List`。
    my @all;
    @all.append(@hit-path.map({ "① 本机工作区绝对路径痕迹：{$_}" }).List);
    @all.append(@hit-legacy.map({ "② 历史遗留用户名痕迹：{$_}" }).List);
    @all.append(@hit-user.map({ "③ 非中性占位的 Windows 用户名：{$_}" }).List);
    return @all.List if @all.elems <= 15;
    @all.head(15).List.push("…另有 {@all.elems - 15} 处（全部：grep -rn 手工确认）");
}

# ---------------------------------- 主流程 ------------------------------------
my @failed;

# 自证「测试看到的是工作树」——否则后面所有绿灯都不可信，直接中止（不假绿）。
if $do-t || $do-xt {
    unless tests-see-worktree() {
        say "";
        say "===== 门禁自检失败（中止） =====";
        say "  测试看不到工作树的 lib/：仓库链首不是 {$lib-abs}。";
        say "  再跑下去只会得到「测了系统里那份已安装的 RakuPM」的假绿，故不继续。";
        say "  排查：`raku -I{$lib-abs} -e 'say \$*REPO.repo-chain.head.Str'`";
        exit 1;
    }
}

if $do-t || $do-xt {
    load-estimates();
    my @plan;
    @plan.append(plan-entries('t', True))  if $do-t;
    @plan.append(plan-entries('xt', False)) if $do-xt;

    if !@plan.elems {
        say "";
        say "===== 没有匹配的用例 =====";
        say "  （filter={$filter}）" if $filter.chars;
    }
    else {
        my Int $n-t  = @plan.grep({ .<dir> eq 't' }).elems;
        my Int $n-xt = @plan.grep({ .<dir> eq 'xt' }).elems;
        say "";
        if $n-t && $n-xt {
            say "===== 全量回归（t/ {$n-t} + xt/ {$n-xt} = {@plan.elems} 个用例） =====";
            say "  合并调度（长短用例同一池，避免批尾长尾）；t/ 强制安静、xt/ 只判成败，各自判定。";
        }
        elsif $n-t {
            say "===== 单测（zef install 测试阶段跑的就是这一批，强制安静） (t/, {$n-t} 个用例) =====";
        }
        else {
            say "===== 集成测试（重 / 网络 / 故意失败；只判成败不判噪音） (xt/, {$n-xt} 个用例) =====";
        }
        say "  （--no-xt：本轮跳过 xt/）" if $do-t && !$do-xt;

        # 预热共享 lib 的 precomp 缓存：避免多个 raku 子进程同时首编译同一份
        # lib/*.rakumod 触发预编译竞态假失败。合并调度后只做一次（以前每段各一次）。
        # 串行（jobs==1）无此风险；RAKUPM_NO_PRECOMP_WARMUP 可强制跳过。
        if $jobs > 1 && !(%*ENV<RAKUPM_NO_PRECOMP_WARMUP> // '').chars {
            my Num $w = warmup-precomp($jobs);
            @warm-secs.push(%( label => 'lib', secs => $w )) if $do-timings && $w > 0;
        }

        my $suite-t0 = now;
        @failed.append(run-plan(@plan));
        @phase-secs.push(%( label => '全部', secs => (now - $suite-t0).Num )) if $do-timings;
        save-estimates();
    }
}

if $do-static {
    say "";
    say "===== 具名实参检查（method 会【静默忽略】未知具名实参，编译器不报） =====";
    my @nf = check-named-args($root);
    if !@nf.elems {
        say "  ok    没有「名字不在任何形参/属性里」的调用点";
    }
    else {
        say "  FAIL 发现 {@nf.elems} 处：";
        for @nf.head(15) -> $x {
            say "        {$x<file>}:{$x<line>}  :{$x<name>}   {$x<snippet>}";
        }
        say "        …另有 {@nf.elems - 15} 处（raku tools/check-named-args.raku --verbose 看全部）"
            if @nf.elems > 15;
        @failed.append("具名实参检查（{@nf.elems} 处。逐个核对被调方签名；"
                     ~ "确属项目外 API 的，加进 tools/NamedArgCheck.rakumod 的 %ALLOWED 并写明理由）");
    }
}

if $do-docs {
    say "";
    say "===== 文档纪律校验（版本号一致性 / provides 完整性 / bin / Changes） =====";
    my @df = check-docs();
    if !@df.elems {
        say "  ok    版本号三处一致、provides 与 lib/ 互为全集、bin 与依赖清单正常";
    }
    else {
        for @df -> $m { say "  FAIL  {$m}" }
        @failed.append(@df);
    }
    if @*ARGS.grep({ $_ eq '--precommit' }).elems {
        @failed.append(check-staged-compile());
    }

    say "";
    say "===== 个人痕迹检查（会进发布包的内容里，不该有本机用户名 / 绝对路径） =====";
    my @pf = check-personal-traces();
    if !@pf.elems {
        say "  ok    没有本机工作区路径 / 历史用户名 / 非中性 Windows 用户名";
    }
    else {
        for @pf -> $m { say "  FAIL  {$m}" }
        @failed.append("个人痕迹检查（{@pf.elems} 处。改成中性占位：user / foo / tester 之类；"
                     ~ "路径示例写 C:\\Users\\user\\）");
    }
}

# ---------------------------------- 汇总 --------------------------------------
print-timings();

say "";
say "=========================== 汇总 ===========================";
if @failed.elems {
    say "失败 {@failed.elems} 项：";
    for @failed -> $f { say "  · {$f}" }
    say "";
    say "**回归不通过** —— 修好再提交/推送。";
    exit 1;
}
say "全部通过 ✅（串行判定口径；jobs={$jobs}）";
my Num $total = (now - $script-t0).Num;
say "总墙钟：{fmt-secs($total)}s（本次脚本从启动到退出，含静态/文档检查）" if $do-timings;
exit 0;
