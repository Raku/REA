# CLI：具名实参名的静态检查。门禁（tools/run-suite.raku）会调它，也可单独跑。
#
#   raku tools/check-named-args.raku              # 扫 lib/bin/t/xt/tools
#   raku tools/check-named-args.raku --verbose    # 每处嫌疑都列出来
#   raku tools/check-named-args.raku --dirs=lib   # 只扫某几个目录
#
# 退出码：0 = 干净，1 = 有嫌疑（门禁据此判红）。
use lib $*PROGRAM.parent.Str;
use NamedArgCheck;

my @dirs = <lib bin t xt tools>;
my $verbose = False;
for @*ARGS -> $a {
    if    $a.starts-with('--dirs=') { @dirs = $a.substr(7).split(',').List }
    elsif $a eq '--verbose'         { $verbose = True }
}

my $root = $*PROGRAM.absolute.IO.parent.parent;
my @findings = check-named-args($root, :@dirs);

if @findings.elems == 0 {
    say "ok    具名实参检查：没有「名字不在任何形参/属性里」的调用点"
      ~ "（扫描 {@dirs.join(' ')}）";
    exit 0;
}

say "发现 {@findings.elems} 处疑似「具名实参名不存在」：";
my %by-name;
for @findings -> $x {
    my $nm = $x<name>;
    %by-name{$nm} = [] unless %by-name{$nm}.defined;
    %by-name{$nm}.push($x);
}
my @names = %by-name.keys.sort({ %by-name{$^b}.elems <=> %by-name{$^a}.elems });
for @names -> $nm {
    my @g = %by-name{$nm}.List;
    say "  :{$nm}  ×{@g.elems}";
    my $show = $verbose ?? @g.elems !! (@g.elems min 2);
    for @g.head($show) -> $x {
        say "      {$x<file>}:{$x<line>}   {$x<snippet>}";
    }
    say "      …另 {@g.elems - $show} 处（--verbose 看全部）" if @g.elems > $show;
}
say "";
say "为什么要报：method 会【静默忽略】未知具名实参（而 sub 会报错），";
say "参数会凭空失效、编译器不提示。逐个核对被调方的签名；";
say "确属项目外 API 的，把名字加进 tools/NamedArgCheck.rakumod 的 %ALLOWED 并写明理由。";
exit 1;
