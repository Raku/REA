use Test;
use JSON::Fast;
use lib $*PROGRAM.parent.parent.add('lib').Str;

# 集成测试（0.38.3）：钉死「异步 tester 的 4 个默认值」——这些在 0.38.0 实现时
# 各自落了具体值，但当时没正式确认、也没写进文档。本测试把它们锁死，防止日后
# 静默改掉：
#   ① 并发度默认 auto = 按 CPU 核数并行（上限 8；--test-jobs=1 才强制串行）；
#   ② 日志默认落在 <目标>/log/<包>/<版本>/，设 RAKUPM_TEST_LOG_DIR 可改根目录；
#   ③ 前台只印失败首行，完整输出落日志；
#   ④ 超时默认 300s（已由 xt/tester-async.t 场景3 覆盖，本文件不重复）。
#
# 放 xt/：会跑真实 CLI 子进程，不进 zef install 的纯净度守卫（t/ 必须安静）。

sub rmrf(IO::Path $p) {
    return unless $p.e;
    if $p.d {
        rmrf($_) for $p.dir;
        try { $p.rmdir }
    }
    else {
        try { $p.unlink }
    }
}

my $raku = $*EXECUTABLE.absolute;
my $bin  = $*PROGRAM.parent.parent.add('bin').add('raku-pm.raku').absolute;

my $tmp = $*TMPDIR.add('rakupm-tdefaults-' ~ $*PID ~ '-' ~ now.floor);
$tmp.mkdir;
LEAVE { rmrf($tmp) }

sub mk-dist(Str $name, :$module-body, :@tests) {
    my $src = $tmp.add($name).mkdir;
    $src.add('lib').mkdir;
    my $body = $module-body.defined ?? $module-body !! "unit module $name;";
    $src.add('lib').add($name ~ '.rakumod').spurt($body);
    $src.add('META6.json').spurt(to-json({
        name => $name, version => '0.1.0', auth => 'demo',
        provides => { $name => "lib/$name.rakumod" },
    }, :sorted-keys));
    if @tests {
        $src.add('t').mkdir;
        for @tests -> $p {
            $src.add('t').add($p.key).spurt($p.value);
        }
    }
    $src
}

# 跑一次真实 CLI，返回 (exitcode, stdout, stderr)。
sub run-cli(IO::Path $target, IO::Path $src, *@extra --> List) {
    my $p = run($raku, '-Ilib', $bin, 'install', $src.absolute,
                '--target=' ~ $target.absolute, '--no-build', |@extra,
                :out, :err);
    my $out = $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    ($p.exitcode, $out, $err)
}

plan 10;

# ---------- 场景 1：并发度默认 auto = 按 CPU 核数并行（上限 8）----------
# 0.64.4 起默认并行：auto = min(CPU 核数, 8)。并行会让多个 raku 子进程同时首次
# 编译同一份 lib/*.rakumod，偶发触发 rakudo 预编译缓存竞态 —— 但已用两道安全网
# 兜住（① 并发前串行预热 precomp；② 失败用例串行复验），故可默认并行加速。
# 要强制串行用 --test-jobs=1。期望值与 Tester 里的公式保持一致。
my $exp-jobs = min($*KERNEL.cpu-cores // 4, 8);
my $srcPass = mk-dist('DefaultPass',
    tests => [
        '01.rakutest' => "use Test; plan 1; ok 1, 'a';\n",
        '02.rakutest' => "use Test; plan 1; ok 1, 'b';\n",
        '03.rakutest' => "use Test; plan 1; ok 1, 'c';\n",
    ]);
my ($ec1, $out1, $err1) = run-cli($tmp.add('tPass'), $srcPass);
is $ec1, 0, '场景1：3 个通过的测试 → 安装成功（exit 0）';
if $out1 ~~ / '并发 ' (\d+) / {
    is +$0, $exp-jobs, "场景1：默认并发度 = min(CPU 核数, 8) = $exp-jobs";
}
else {
    flunk '场景1：输出里没找到「并发 N」行';
}

# ---------- 场景 2：失败首行 + 日志落 <目标>/log/<包>/<版本>/ ----------
# 失败测试：stdout 第一行是 RAKUPM_FIRST_LINE，后面还有 RAKUPM_SECOND_LINE；
# 前台只应出现第一行，完整输出（含第二行）应进日志文件。
my $srcFail = mk-dist('DefaultLog',
    tests => [
        '01.rakutest' => "say 'RAKUPM_FIRST_LINE';\n" ~
                         "say 'RAKUPM_SECOND_LINE';\n" ~
                         "exit 1;\n",
    ]);
my $tgt2 = $tmp.add('tLog');
my ($ec2, $out2, $err2) = run-cli($tgt2, $srcFail);
isnt $ec2, 0, '场景2：测试失败 → 非零退出';
my $default-log = $tgt2.add('log').add('DefaultLog').add('0.1.0').add('01.rakutest.log');
ok $default-log.e, '场景2：日志默认落在 <目标>/log/<包>/<版本>/<测试>.log';
my $log2 = $default-log.e ?? $default-log.slurp !! '';
ok $log2.contains('RAKUPM_SECOND_LINE'),
   '场景2：完整输出（含第二行）写入日志文件';
ok ($out2 ~ $err2).contains('RAKUPM_FIRST_LINE'),
   '场景2：前台含失败首行';
ok ($out2 ~ $err2) !~~ / RAKUPM_SECOND_LINE /,
   '场景2：前台不含失败第二行（只印首行）';

# ---------- 场景 3：RAKUPM_TEST_LOG_DIR 改日志根目录 ----------
# 设全局日志根 → 日志应落 <全局>/log/<包>/<版本>/，而非 <目标>/log/。
my $global = $tmp.add('global-logs');
my $srcFail3 = mk-dist('DefaultLog3',
    tests => [
        '01.rakutest' => "say 'RAKUPM_FIRST_LINE';\n" ~
                         "say 'RAKUPM_SECOND_LINE';\n" ~
                         "exit 1;\n",
    ]);
my $tgt3 = $tmp.add('tLog3');
%*ENV<RAKUPM_TEST_LOG_DIR> = $global.absolute;
my ($ec3, $out3, $err3) = run-cli($tgt3, $srcFail3);
try %*ENV<RAKUPM_TEST_LOG_DIR>:delete;   # 用完即清，避免污染后续场景
isnt $ec3, 0, '场景3：测试失败 → 非零退出';
my $global-log = $global.add('log').add('DefaultLog3').add('0.1.0').add('01.rakutest.log');
ok $global-log.e, '场景3：设 RAKUPM_TEST_LOG_DIR 后日志改落全局根目录';
ok !$tgt3.add('log').add('DefaultLog3').add('0.1.0').add('01.rakutest.log').e,
   '场景3：默认 <目标>/log/ 下不再生成日志（根目录已重定向）';
