use RakuPM::Author;
my $a = RakuPM::Author.new;
my $key = $a!login-remote("skyter10086", "Yumen2013");
say "KEY={$key}";
