# RakuPM::Author — 生产侧（作者侧）操作：面向【当前这个发行版目录】
#
# 消费侧（RakuPM::Client）管「装什么、装到哪」，持有 target / store / installer
# 这些「安装目标」状态；本类管「我这个包本身」：从磁盘上的一个发行版目录出发，
# 维护它自己的元数据（META6.json）。
#
# 为什么不塞进 Client：Client 是消费侧编排器，作者侧操作与安装目标无关，
# 不该为了改一个 META6.json 去初始化整条消费侧模块图，也不该被卷进写锁。
# 两者生命周期不同，分开更清楚（见 README「已实现 vs 待实现」的生产侧一节）。
#
# 为什么用类方法而不是实例：这些操作没有状态可持有，入参就是那个目录。
# new 已实现；后续 check / build / dist / bump / publish 都会落在本类。
use RakuPM::Distribution;
use RakuPM::Fs;
use RakuPM::Platform;            # is-windows（凭据文件权限收紧的跨平台判断入口）
use RakuPM::Net;                 # assert-online（真实上传/登录离线硬拦时复用）
use RakuPM::HTTP;                # post-form / upload-multipart（M3 真实上行：curl -F）
use JSON::Fast;

unit class RakuPM::Author;

# 真实生态上传端点（M1 调研确认，来自 fez 的 resources/config.json `host` 字段）：
#   https://42.zef.pm   ——  规范的 fez/zef 上传后端（POST /upload，multipart 字段 dist）
# 注意：raku-pm 默认用的 360.zef.pm 只是【只读索引镜像】，没有上传 API，
# 所以真实上传必须打 42.zef.pm。M2 负责「构造请求 + 本地校验」，M3 接通真实
# multipart 上传（curl -F）与用户名+密码登录换 key。
our $ECO-UPLOAD-HOST = 'https://42.zef.pm';

# raku-pm refresh [路径] —— 以【磁盘】为准重建发行版 META6.json 的 provides。
#
# 解决什么问题：往 lib/ 里加了新模块、或改了模块文件名之后，META6.json 的
# provides（模块名 => 相对路径）就与磁盘不一致了。手工维护极易漏，而 provides
# 一旦不对，装出来的包就 `use` 不到 —— 属于「本地看着没事、别人装了就错」的坑。
# 这是作者侧的高频操作，等价于 mi6 的 `mi6 build`（AutoScanPackages 那部分）。
#
# 语义边界（刻意保守，只做能由磁盘唯一推导的事）：
#   · 只动 provides —— 它完全可由 lib/ 推导出来；
#   · resources / bin 不做增删：前者靠显式声明管理（mi6 的做法是 `fez resource`
#     单管，不在 build 里自动扫），后者的值是「路径数组」、无法从磁盘唯一确定；
#   · 其余字段（name / version / auth / depends / tags / source-url …）原样保留；
#   · 声明里有、磁盘上没有的模块会被剔除（写了也装不上）；
#   · 磁盘上有、声明里没有的模块会被加入（这正是本命令的价值）。
#
# :$dry 只打印将要发生的改动，不写文件。
method refresh(IO::Path $root, Bool :$dry = False --> Nil) {
    my $dir       = ($root // '.').IO.absolute.IO;
    my $meta-file = $dir.add('META6.json');

    # 注意用 .e 判存在：IO::Path.d 对不存在的路径会抛 X::IO::DoesNotExist
    unless $dir.e && $dir.d {
        die "目录不存在：{$dir}";
    }
    unless $meta-file.e {
        die "{$dir} 里没有 META6.json —— refresh 是【重建已有发行版】的元数据，"
          ~ "不负责创建发行版。要新建发行版请用 `raku-pm new <模块名>`，"
          ~ "它会生成 META6.json + lib/ + t/ + Changes 等骨架。";
    }

    my $parsed = try from-json($meta-file.slurp);
    # 与 from-meta-file 同款守卫：JSON::Fast 对坏输入返回未定义 Any（不抛、非 Failure），
    # 而顶层若是数组，`my %h = $array` 会在赋值那一刻抛 Odd number of elements。
    ($parsed ~~ Failure || ! $parsed.defined || !($parsed ~~ Associative))
        and die "META6.json 不是有效的 JSON 对象：{$meta-file}";
    my %meta = $parsed;

    # 以磁盘为准：扫 lib/ 反推模块名 → 映射成 provides 需要的相对路径
    my $mods         = RakuPM::Distribution.scan-provides($dir);
    my %new-provides = RakuPM::Distribution.provides-with-paths($dir, $mods);
    my $new-mods     = %new-provides.keys.sort.List;
    my $old-mods     = RakuPM::Distribution.normalize-provides(%meta<provides>);

    my $added   = $new-mods.grep(-> $m { !($m (elem) $old-mods) }).sort.List;
    my $removed = $old-mods.unique.sort.grep(-> $m { !(%new-provides{$m}:exists) }).List;

    say "==> 重建 META6.json 的 provides：{$dir}";
    say "    磁盘 lib/ 下扫到 {$new-mods.elems} 个模块";
    # 注意 `.list`：`for $scalarVar` 对【任何】容器值（List / Array / Seq）
    # 都只迭代一次（把整个值当单个元素），只有 `@` 数组变量才逐元素。
    # 所以这里必须显式 `.list`，否则三个模块会挤在一行输出。
    if $added.elems {
        say "  · 加入（磁盘上有、声明里没有）：";
        for $added.list -> $m { say "      + {$m}" }
    }
    if $removed.elems {
        say "  · 剔除（声明里有、磁盘上没有，写了也装不上）：";
        for $removed.list -> $m { say "      - {$m}" }
    }

    # 「有没有变」看结果的 JSON，而不是只看模块名集合：模块名没变但扩展名从
    # .pm6 换成 .rakumod（路径变了）也算变。没变就不写文件（别白改 mtime）。
    my $changed = to-json((%meta<provides> // %()), :sorted-keys)
               ne to-json(%new-provides, :sorted-keys);
    unless $changed {
        say "  · 已与现有 provides 一致，未改动文件";
        return;
    }

    if $dry {
        say "  （--dry：仅预览，未写入任何文件）";
        return;
    }

    %meta<provides> = %new-provides;
    $meta-file.spurt(to-json(%meta, :sorted-keys));
    say "  ✓ 已更新 {$meta-file}";
}

# raku-pm new <模块名> [--into=目录] [--auth=...] [--version=X] [--with-readme]
#              [--bin=<可执行名>] [--force] [--dry]
#   —— 作者侧起点：在当前位置创建一个【全新】发行版骨架。与安装目标无关，
#   不构造 Client、不进写锁（跟 refresh 一个待遇）。
#
# 生成物：
#   <dist-dir>/META6.json           name/version/auth/api/provides/depends/test-depends/bin
#   <dist-dir>/lib/<...>.rakumod    主模块占位（unit module + 一个 our sub 冒烟）
#   <dist-dir>/t/01-basic.rakutest  use-ok 冒烟测试
#   <dist-dir>/Changes              初始版本头
#   <dist-dir>/.gitignore           忽略 .precomp
#   <dist-dir>/README.md            占位（仅 --with-readme）
#   <dist-dir>/bin/<x>.raku         可执行（仅 --bin=<x>），META6 的 bin 同步含之
#
# 目录名默认 = 模块名里 :: → -（mi6 惯例）；--into=<路径> 显式指定（. = 当前目录）。
# 目标目录若存在且非空、又没 --force，直接报错，绝不静默覆盖用户已有文件
# （--force 只覆盖我们生成的这些同名脚手架文件，不删用户其他文件）。
method scaffold(Str $name,
                IO::Path :$into,
                Str :$auth,
                Str :$version,
                Bool :$with-readme = False,
                Str :$bin,
                Bool :$force = False,
                Bool :$dry = False --> Nil) {
    # 模块名合法性：Foo 或 Foo::Bar::Baz（每段必须以字母/下划线开头）
    unless $name ~~ /^ <[A..Za..z_]> <[A..Za..z0..9_]>* ( '::' <[A..Za..z_]> <[A..Za..z0..9_]>* )* $/ {
        die "非法的模块名：$name（应为 Foo 或 Foo::Bar 形式，每段以字母/下划线开头）";
    }

    # auth 默认顺序：显式 --auth > 环境变量 RAKUPM_AUTHOR_AUTH > 项目作者惯例
    my $auth-final = ($auth.defined && $auth.trim.chars)
        ?? $auth.trim
        !! (%*ENV<RAKUPM_AUTHOR_AUTH> // 'zef:skyter10086');
    my $version-final = ($version.defined && $version.trim.chars)
        ?? $version.trim
        !! '0.1.0';

    # 目标目录：--into 优先，否则模块名 :: → -
    # 【0.87.0】这里走统一的 path-component 只是**防御性冗余**：上面的正则已经
    # 保证名字形如 Foo / Foo::Bar（不含 / \ .. :），映射结果与旧的 subst 完全相同
    # —— 留着是为了日后有人放宽那个正则时不至于静默打开一个路径穿越。
    my $dist-dir = ($into.defined && $into.Str.trim.chars)
        ?? $into.IO
        !! path-component($name, :what('模块名')).IO;
    $dist-dir = $dist-dir.absolute.IO;

    # 冲突：目录存在且顶层非空，没 --force 就拒（避免覆盖用户已有文件）
    if $dist-dir.e && $dist-dir.d && !$force {
        my $has = ?$dist-dir.dir.first(*.defined);   # 顶层有内容即算非空（.dir 默认不含 . / ..）
        if $has {
            die "目标目录非空：{$dist-dir}（用 --force 覆盖同名脚手架文件）";
        }
    }

    # 主模块相对路径：lib/<段>/<段>.rakumod
    my $mod-rel = 'lib/' ~ $name.split('::').join('/') ~ '.rakumod';

    # 作者名：从 auth 的 ':' 后取（zef:skyter10086 → skyter10086）；auth 空则空数组
    my @authors = $auth-final.chars
        ?? [ ($auth-final.split(':', 2))[1] // $auth-final ]
        !! [];

    my %meta = %(
        name        => $name,
        version     => $version-final,
        auth        => $auth-final,
        api         => '1',
        description => "TODO: describe {$name}",
        authors     => @authors,
        license     => 'Artistic-2.0',
        raku        => '6.d',
        provides    => { $name => $mod-rel },
        depends     => %(
            runtime => %(
                requires => [],
            ),
        ),
        test-depends => ['Test'],
    );

    # 文件计划：相对路径 => 内容
    my %plan = %(
        $mod-rel => "unit module {$name};\n\nour sub hello(--> Str) \{\n    \"Hello from {$name}\"\n\}\n",
        't/01-basic.rakutest' => "use Test;\nuse-ok '{$name}';\ndone-testing;\n",
        'Changes' => "# Change log for {$name}\n\n## {$version-final}\n\n- Initial release.\n",
        '.gitignore' => "# Rakudo precompiled bytecode\n.precomp/\n",
    );
    if $bin.defined && $bin.trim.chars {
        my $bn = $bin.trim;
        %plan{"bin/$bn.raku"} = "#!/usr/bin/env raku\nuse {$name};\nsay \"Hello from {$name}\";\n";
        %meta<bin> = ["bin/$bn.raku"];
    }
    if $with-readme {
        %plan{'README.md'} = "# {$name}\n\nTODO: write a description.\n\n## Installation\n\n    raku-pm install {$name}\n\n## Usage\n\n    use {$name};\n";
    }
    %plan{'META6.json'} = to-json(%meta, :sorted-keys);

    say "==> 创建发行版骨架：{$dist-dir}";
    for %plan.kv -> $rel, $content {
        my $f = $dist-dir.add($rel);
        say "  · {$rel}";
        next if $dry;
        mkdir-p($f.parent) unless $f.parent.e;
        $f.spurt($content);
    }
    if $dry {
        say "  （--dry：仅预览，未写入任何文件）";
        return;
    }
    say "  ✓ 完成。下一步：cd {$dist-dir} && raku-pm refresh && raku-pm install .";
}

# raku-pm check [路径] [--remote] [--quiet]
#   —— 发布前预检（上架前安全闸门）：在真去连服务器发布之前，先把「客户端能确定的
#   硬错误」全查一遍。等价 fez 发布前 / mi6 release 前的 meta 校验，但覆盖更全：
#     · META6.json 存在且是合法 JSON 对象
#     · name 存在且是合法模块名（Foo / Foo::Bar）
#     · version 存在且 ≠ '*'（'*' 是「任意版本」占位符，不能发布）
#     · auth 存在，且与 RAKUPM_AUTHOR_AUTH 一致（auth 必须与上传账号相同，
#       否则服务器会拒；客户端只能预检，不能替代服务器校验）
#     · provides 与磁盘 lib/ 一致：声明里有、磁盘上没有 → 错误（装不上）；
#       磁盘上有、声明里没有 → 警告（建议 raku-pm refresh）
#     · bin 列出的脚本文件都必须存在
#     · license / description（非 TODO）/ authors 建议填写（警告，不阻断）
#     · depends / test-depends / build-depends 形态可解析（畸形 → 警告）
#   --remote：额外联网查已配置仓库，若 name:ver<X> 已存在则报错（同版本不可重传）。
#     默认不联网、纯本地、秒级；联网失败只告警、不阻断（最终由服务器强制校验）。
#   返回结构化结果 %{ ok, errors, warnings, name, version, auth } 并打印报告
#   （--quiet 时不打印，供单测直接调用断言）。
method check(IO::Path $root, Bool :$remote = False, Bool :$quiet = False,
             :$version-exists = Nil --> Hash) {
    my $dir       = ($root // '.').IO.absolute.IO;
    my $meta-file = $dir.add('META6.json');

    my @errors;
    my @warnings;
    my $name    = '';
    my $version = '';
    my $auth    = '';

    sub err(Str $msg)  { @errors.push($msg) }
    sub warn(Str $msg) { @warnings.push($msg) }

    # ---- 目录 / META6 存在且合法 ----
    unless $dir.e && $dir.d {
        die "目录不存在：{$dir}";
    }
    unless $meta-file.e {
        die "{$dir} 里没有 META6.json —— check 是针对一个发行版目录的预检，无法检查。";
    }
    my %meta;
    {
        my $parsed = try from-json($meta-file.slurp);
        if $parsed ~~ Failure || ! $parsed.defined || !($parsed ~~ Associative) {
            err("META6.json 不是有效的 JSON 对象：{$meta-file}");
            self!emit-check-report($dir, @errors, @warnings) unless $quiet;
            return %(
                ok => False, errors => @errors, warnings => @warnings,
                name => '', version => '', auth => '',
            );
        }
        %meta = $parsed;
    }

    # ---- name ----
    $name = (%meta<name> // '').Str;
    if !$name.chars {
        err("缺少 name 字段（发行版名字，如 Foo::Bar）");
    }
    elsif $name !~~ /^ <[A..Za..z_]> <[A..Za..z0..9_]>* ( '::' <[A..Za..z_]> <[A..Za..z0..9_]>* )* $/ {
        err("name 不是合法的模块名：{$name}（应为 Foo 或 Foo::Bar 形式）");
    }

    # ---- version ----
    $version = (%meta<version> // '').Str;
    if !$version.chars {
        err("缺少 version 字段（发布必须指定具体版本号，如 0.1.0）");
    }
    elsif $version.trim eq '*' {
        err("version 不能是占位符 '*'（'*' 表示「任意版本」，不能发布；请指定具体版本）");
    }

    # ---- auth（缺失 / 与上传账号不一致 = 硬错误）----
    my $auth-raw = %meta<auth>;
    $auth = do given $auth-raw {
        when !.defined  { '' }
        when Str        { $_ }
        when Positional { (.map(*.Str).first({ .chars }) // '') }
        when Hash       { (.keys.first({ .chars }) // '') }
        default         { .Str }
    };
    $auth = $auth.trim if $auth.chars;
    if !$auth.chars || $auth eq 'unknown' {
        err("缺少 auth 字段（发布必须指定作者身份，如 gitee:yourname 或 github:yourname）");
    }
    elsif %*ENV<RAKUPM_AUTHOR_AUTH> ~~ Str && %*ENV<RAKUPM_AUTHOR_AUTH>.trim.chars {
        my $expect = %*ENV<RAKUPM_AUTHOR_AUTH>.trim;
        if $auth ne $expect {
            err("auth '{$auth}' 与 RAKUPM_AUTHOR_AUTH '{$expect}' 不一致——发布会用后者身份上传，"
              ~ "META6 的 auth 必须改成一致才能发布");
        }
    }
    else {
        warn("未设置 RAKUPM_AUTHOR_AUTH，无法确认 auth '{$auth}' 是否与你的上传账号一致；"
          ~ "发布时由服务器强制校验");
    }

    # ---- provides 与磁盘 lib/ 一致 ----
    if $name.chars {
        my $disk = RakuPM::Distribution.scan-provides($dir);          # 磁盘 lib/ 下所有模块
        my @decl-mods = RakuPM::Distribution.normalize-provides(%meta<provides>);
        my %decl = RakuPM::Distribution.provides-with-paths($dir, @decl-mods);
        # 声明里有、磁盘上没有 → 错误（写了也装不上）。
        # 注意：用 provides-with-paths 反查「该模块名对应的文件是否存在」，
        # 而不能直接用 %meta<provides> 的路径（provides-with-paths 对不存在的文件
        # 不返回，正好用来判定缺失）。
        for @decl-mods -> $m {
            unless %decl{$m}:exists {
                err("provides 声明的模块 {$m} 在磁盘上找不到文件（写了也装不上）");
            }
        }
        # 磁盘上有、声明里没有 → 警告（建议 refresh）
        my @undeclared = $disk.grep(-> $m { !(%decl{$m}:exists) }).sort;
        if @undeclared.elems {
            warn("lib/ 下有 {@undeclared.elems} 个模块未声明在 provides 中：{@undeclared.join(', ')}"
              ~ "（建议先跑 `raku-pm refresh` 重建 provides）");
        }
        # 单模块发行版：name 应等于唯一 provides 键（信息性警告）
        if @decl-mods.elems == 1 && $disk.elems == 1 {
            my $only = @decl-mods[0];
            warn("name '{$name}' 与 provides 里的模块名 '{$only}' 不同；"
              ~ "单模块发行版通常应同名") unless $only eq $name;
        }
    }

    # ---- bin 文件存在 ----
    if %meta<bin> ~~ Positional {
        for @(%meta<bin>) -> $b {
            my $bf = $dir.add($b.Str);
            err("bin 声明的可执行文件不存在：{$b}") unless $bf.e && $bf.f;
        }
    }

    # ---- license / description / authors 建议项 ----
    unless %meta<license>:exists && (%meta<license> // '').Str.chars {
        warn("缺少 license 字段（建议填写，如 Artistic-2.0）");
    }
    my $desc = (%meta<description> // '').Str;
    if !$desc.chars {
        warn("缺少 description 字段");
    }
    elsif $desc ~~ / 'TODO' / {
        warn("description 仍是占位 TODO：{$desc}（发布前请改成真实描述）");
    }
    given %meta<authors> {
        when Positional { warn("authors 为空（建议填写作者名）") unless .elems; }
        when Str        { warn("authors 为空（建议填写作者名）") unless .trim.chars; }
        default         { warn("缺少 authors 字段（建议填写作者名）"); }
    }

    # ---- depends / test-depends / build-depends 形态（畸形 → 警告）----
    for <depends test-depends build-depends> -> $k {
        next unless %meta{$k}:exists;
        my $ok = try {
            RakuPM::Distribution.normalize-dependencies-and-native-libs(%meta{$k});
            True
        };
        warn("依赖字段 {$k} 解析异常：{$!}") unless $ok;
    }

    # ---- 可选：联网查同版本是否已发布 ----
    # --remote 走真联网探针；给了 version-exists 缝（测试用）也走它，
    # 这样单测可在不联网、不开 --remote 的情况下验证「已发布」分支。
    if ($remote || $version-exists ~~ Callable)
       && $name.chars && $version.chars && $version ne '*' {
        my $exists = $version-exists ~~ Callable
            ?? $version-exists.($name, $version, $auth)
            !! self!probe-remote($name, $version, $auth);
        if $exists === True {
            err("版本已发布：{$name}:ver<{$version}> 在已配置仓库中已存在，无法重传"
              ~ "（请 bump 版本后用 raku-pm bump）");
        }
        elsif $exists ~~ Bool {
            # False：确认未发布，ok
        }
        else {
            warn("未能联网确认版本是否已发布（离线或索引拉取失败）；发布时由服务器强制校验");
        }
    }

    self!emit-check-report($dir, @errors, @warnings) unless $quiet;
    return %(
        ok => @errors.elems == 0,
        errors => @errors, warnings => @warnings,
        name => $name, version => $version, auth => $auth,
    );
}

# raku-pm dist [路径] [--to=目录] [--no-build] [--dry] [--quiet]
#   —— 打包 sdist（发布前必需）：把校验过的发行版卷成可上传的【源码】归档
#   <name>-<version>.tar.gz（含 META6 + lib/ + bin/ + t/ + resources + LICENSE +
#   README 等，排除 .git / blib / .precomp / .DS_Store 等以及任何 . 开头的隐藏项）。它是 publish 的输入物。
#   顺序：
#     1) 先跑 check 门禁（硬错误直接拒，绝不打包一个过不了预检的包）；
#     2) 可选地跑构建阶段（发现 Build.pm 才跑；--no-build 跳过）—— 原生扩展类
#        发行版靠它在原地编出 resources/libraries/*.so，产物会进 tar 包；
#     3) 打成 tar.gz，默认放当前目录（--to= 指定），打包时自动排除自身避免循环。
#   产物是源码分发：生态只传源码，消费者在自己机器上编译，所以不打预编译字节。
method dist(IO::Path $root, Str :$to = '', Bool :$no-build = False,
            Bool :$dry = False, Bool :$quiet = False --> Hash) {
    my $dir = ($root // '.').IO.absolute.IO;
    my $meta-file = $dir.add('META6.json');
    unless $dir.e && $dir.d {
        die "目录不存在：{$dir}";
    }
    unless $meta-file.e {
        die "{$dir} 里没有 META6.json，无法打包（它是发行版的根）";
    }

    my %meta;
    {
        my $parsed = try from-json($meta-file.slurp);
        if $parsed ~~ Failure || ! $parsed.defined || !($parsed ~~ Associative) {
            die "META6.json 不是有效的 JSON 对象：{$meta-file}";
        }
        %meta = $parsed;
    }
    my $name    = (%meta<name> // '').Str;
    my $version = (%meta<version> // '').Str;
    unless $name.chars && $version.chars {
        die "META6.json 缺少 name 或 version，无法命名归档";
    }

    # 1) 门禁：check 有硬错误直接拒（绝不打包过不了预检的包）
    my $r = self.check($dir, :quiet(True));
    if !$r<ok> {
        die "预检未通过，已拒绝打包（先 `raku-pm check` 修复 {$r<errors>.elems} 个错误）：\n  "
          ~ $r<errors>.join("\n  ");
    }

    # 2) 可选构建阶段（声明了才跑；--no-build 跳过）
    unless $no-build {
        self!run-build($dir, :quiet($quiet));
    }

    # 3) 输出位置：默认当前目录，归档名 <name>-<version>.tar.gz
    my $to-dir = ($to.defined && $to.trim.chars)
        ?? $to.trim.IO.absolute.IO
        !! $*CWD.absolute.IO;
    mkdir-p($to-dir) unless $to-dir.e;
    # 归档名按 Raku 生态惯例把 :: 替换成 -（JSON::Fast → JSON-Fast-0.19.tar.gz），
    # 同时避开 Windows 把 `:` 当保留字符/ADS 的坑。
    # 【0.87.0】改用统一的 path-component：名字/版本来自项目自己的 META6.json，
    # 而项目可能来自 clone —— 未净化时 name 里的 `/`、`..` 会让 tar 包写到输出目录之外。
    my $safe-name = path-component($name,    :what('发行版名'));
    my $safe-ver  = path-component($version, :what('版本号'));
    my $out = $to-dir.add("{$safe-name}-{$safe-ver}.tar.gz");

    if $dry {
        say "==> [dry] 将打包 {$dir} → {$out}";
        say "  （未生成任何文件）";
        return %( ok => True, file => $out.absolute.Str, name => $name, version => $version );
    }

    unless $quiet { say "==> 打包 sdist：{$out}" }
    my $ok = self!tar-gz($dir, $out);
    unless $ok {
        die "打包失败：未能生成 {$out}（tar 可能未安装，或目录无可打包文件）";
    }
    unless $quiet { say "  ✓ 已生成 {$out}" }
    return %( ok => True, file => $out.absolute.Str, name => $name, version => $version );
}

# raku-pm publish [路径] [--to=<repo-dir>] [--from=<tar.gz>] [--no-build]
#                 [--force] [--dry] [--remote] [--quiet]
#   —— 把打包好的发行版【部署】到本地目录仓库，使 `raku-pm install` 能从该仓库
#   解析并装上它。这是 fez publish 在「本地 / 教学」场景下的等价物：真实生态是
#   把 sdist 上传到远端索引服务器（42.zef.pm/upload，multipart 字段 dist，带
#   Authorization: Zef <key>），本地
#   场景则是把源码放进一个目录仓库（已用 `repos add` 登记的目录），别人或 CI 就能
#   从那里装。闭合作者侧工作流：new → refresh → check → dist → publish。
#
#   顺序：
#     1) 先跑 check 门禁（dist 内部已跑，硬错误直接拒，绝不发布过不了预检的包）；
#     2) 可选构建阶段（--no-build 跳过；默认发现 Build.pm 才跑）；
#     3) 打成 sdist 源分发（复用 dist；或用 --from=<tar.gz> 直接吃现成包）；
#     4) 确定发布目标目录（--to= 优先；否则 RAKUPM_PUBLISH_REPO 环境变量）；
#     5) 碰撞检查：目标下 <name>-<version>/ 已存在 → 报错（先 bump），除非 --force；
#        --remote 还额外联网查已配置远程生态索引里是否已有同名同版本
#        （离线模式会硬拦，不静默放过去）；
#     6) 解包 sdist 进目标目录，使其立即可被该仓库收录（Local 仓库扫子目录 META6.json）。
#   --dry 只装机读结果与落点、不写入任何文件。默认打印进度，--quiet 静音。
#
#   设计要点：落点用 <repo>/<name>-<version>/（name 的 :: 换成 -），多版本各占一目录，
#   与 Local 仓库「一个子目录一个发行版」的布局一致；解包用 dist 打出的同一个 tar，
#   因此「能被发布出去的」与「别人 install 时拿到的」是同一份内容（不另起一套拷贝）。
method publish(IO::Path $root, Str :$to = '', Str :$from = '',
               Bool :$no-build = False, Bool :$force = False,
               Bool :$dry = False, Bool :$remote = False, Bool :$quiet = False --> Hash) {
    my $dir = ($root // '.').IO.absolute.IO;
    my $meta-file = $dir.add('META6.json');
    unless $dir.e && $dir.d {
        die "目录不存在：{$dir}";
    }
    unless $meta-file.e {
        die "{$dir} 里没有 META6.json，无法发布（它是发行版的根）";
    }

    my %meta;
    {
        my $parsed = try from-json($meta-file.slurp);
        if $parsed ~~ Failure || ! $parsed.defined || !($parsed ~~ Associative) {
            die "META6.json 不是有效的 JSON 对象：{$meta-file}";
        }
        %meta = $parsed;
    }
    my $name    = (%meta<name> // '').Str;
    my $version = (%meta<version> // '').Str;
    unless $name.chars && $version.chars {
        die "META6.json 缺少 name 或 version，无法发布";
    }
    # 【0.87.0】净化后再拼路径分量（见 !dist 里的同款说明）
    my $safe-name = path-component($name,    :what('发行版名'));
    my $safe-ver  = path-component($version, :what('版本号'));

    # 3) 得到 sdist：要么复用现成包，要么复用 dist 现打一份
    my $tar;
    my $built-internally = False;
    if $from.defined && $from.trim.chars {
        $tar = $from.trim.IO.absolute.IO;
        unless $tar.e && $tar.f {
            die "指定的 sdist 不存在：{$tar}";
        }
        unless $quiet { say "==> 复用已构建的 sdist：{$tar}" }
    }
    else {
        # dist 内部会先跑 check 门禁、再可选构建、最后打包，返回文件路径。
        # 产物落临时目录（不污染当前目录）；发布成功后再清理。
        my $tmp-dir = ($*TMPDIR // '/tmp'.IO).absolute.IO;
        mkdir-p($tmp-dir) unless $tmp-dir.e;
        my $r = self.dist($dir, :to($tmp-dir.absolute.Str), :no-build($no-build), :quiet(True));
        unless $r<ok> {
            die "打包失败，无法发布（先 `raku-pm dist` 看错误）";
        }
        $tar = $r<file>.IO.absolute.IO;
        $built-internally = True;
        unless $quiet { say "==> 已构建 sdist：{$tar}" }
    }

    # 3.5) --remote：真实生态上传路径（M3：POST 42.zef.pm/upload，字段 dist=@<tar>）。
    #   放在本地部署（step 4 需要 --to）【之前】短路 —— 这样 `publish --remote` 不要求
    #   配置本地目录仓库，纯上传 / 预览即可。sdist 已在 step 3 备好（$tar 可用）。
    if $remote {
        # 凭据：环境变量 RAKUPM_API_KEY > ~/.raku-pm/credentials.json 的 api-key。
        my $key = self.resolve-api-key;
        unless $key.chars {
            die "缺少上传凭据：先 `raku-pm login --api-key=<key>`（或用 --username/--password 登录），"
              ~ "或设环境变量 RAKUPM_API_KEY。\n"
              ~ "  （raku-pm 默认上传端点是 {$ECO-UPLOAD-HOST}，需要该生态的 api-key；"
              ~ "与 fez 共用同一把 key）";
        }
        if $dry {
            # 离线预览：只打印将要发出的上传请求；不发网络、也不本地部署。
            say "==> [dry] 将上传到真实生态：{$ECO-UPLOAD-HOST}/upload";
            say "    方法：POST   multipart 字段 dist";
            say "    认证：Authorization: Zef {$key.substr(0, 4)}…（key 已隐去）";
            say "    文件：{$tar.absolute}";
            say "    （--dry：未发送任何请求、未写入本地仓库）";
            return %( ok => True, file => $tar.absolute.Str, remote => True, dry => True,
                       name => $name, version => $version,
                       endpoint => "{$ECO-UPLOAD-HOST}/upload" );
        }
        # 非 dry：真实上传（multipart POST，字段 dist=@<tar>，Authorization: Zef <key>）。
        # 离线时 post-form 内的 assert-online 会硬拦，不会静默联网；失败给出含
        # 「同版本已存在 / auth 不匹配」提示的友好报错，由服务端强制校验。
        my $resp = RakuPM::HTTP.new.upload-multipart("{self!upload-host}/upload", $tar, :auth($key));
        unless $resp<ok> {
            die "上传失败（HTTP {$resp<status>}）：{$resp<error> || $resp<body>}\n"
              ~ "  （服务端可能因「同版本已存在」「auth 不匹配上传者」或网络问题拒绝；"
              ~ "先用 `raku-pm check --remote` 确认版本未发布、auth 与账号一致）";
        }
        unless $quiet {
            say "==> 已上传到真实生态：{$ECO-UPLOAD-HOST}/upload";
            say "    文件：{$tar.absolute}  版本：{$name}:ver<{$version}>";
            if $resp<body>.trim.chars {
                say "    服务端响应：{$resp<body>.trim.substr(0, 200)}";
            }
        }
        # 内部构建的临时 tar 不再需要（用户用 --from 给的不动）
        try $tar.unlink if $built-internally;
        return %( ok => True, file => $tar.absolute.Str, remote => True,
                   name => $name, version => $version,
                   endpoint => "{$ECO-UPLOAD-HOST}/upload", status => $resp<status> );
    }

    # 4) 发布目标目录：--to= > RAKUPM_PUBLISH_REPO > 报错让用户显式给
    my $dest = do {
        if $to.defined && $to.trim.chars {
            $to.trim.IO.absolute.IO
        }
        elsif %*ENV<RAKUPM_PUBLISH_REPO>:exists
             && %*ENV<RAKUPM_PUBLISH_REPO>.defined
             && %*ENV<RAKUPM_PUBLISH_REPO>.trim.chars {
            %*ENV<RAKUPM_PUBLISH_REPO>.trim.IO.absolute.IO
        }
        else {
            die "请指定发布目标目录：--to=<repo-dir>，或设置 RAKUPM_PUBLISH_REPO。"
              ~ "\n  目标目录应是用 `raku-pm repos add` 登记过的本地目录仓库"
              ~ "（`install` 才能从那里解析到这个包）";
        }
    };
    # 落点：<dest>/<name>-<version>/（与 Local 仓库「子目录即发行版」布局一致）
    my $drop = $dest.add("{$safe-name}-{$safe-ver}");

    # 5) 碰撞检查：同版本目录已存在则拒绝（先 bump 或加 --force）
    if $drop.e && $drop.d && !$force {
        die "版本已发布到 {$drop}（同版本目录已存在）。要覆盖请加 --force，"
          ~ "或先 `raku-pm bump` 升版本。";
    }
    if $dry {
        say "==> [dry] 将把 sdist 解包到：{$drop}";
        say "  （未写入任何文件）";
        return %( ok => True, file => $tar.absolute.Str, dest => $drop.absolute.Str,
                   name => $name, version => $version );
    }

    # 6) 解包：建目标仓库目录（若不存在）+ 落点目录 + tar -xzf
    #    （成员是相对路径、无顶层前缀，直接落进 drop）
    mkdir-p($dest) unless $dest.e;
    mkdir-p($drop);
    my $ok = self!tar-extract($tar, $drop);
    unless $ok {
        # 解包失败清掉可能生成的半截目录，避免留下不完整的包
        try $drop.rmdir if $drop.e && !$drop.dir.elems;
        die "解包失败：未能把 {$tar} 解到 {$drop}（tar 可能未安装，或包已损坏）";
    }
    # 内部构建的临时 tar 不再需要；用户用 --from 给的不动
    try $tar.unlink if $built-internally;

    unless $quiet {
        say "==> 已发布到本地仓库：{$drop}";
        say "    现在其它机器 `raku-pm repos add {$dest.absolute}` 后即可 `raku-pm install {$name}`";
    }
    return %( ok => True, file => $tar.absolute.Str, dest => $drop.absolute.Str,
               name => $name, version => $version );
}

# raku-pm bump [路径] [--to=X.Y.Z | --major | --minor] [--date=YYYY-MM-DD] [--dry]
#              [--no-sync-docs]
#   —— 版本编排：一次做完「递增版本」需要的三件事，别让作者漏改任何一处：
#     ① 按 semver 递增 META6.json 的 version；
#     ② 在 Changes 顶部加版本头（## X.Y.Z - DATE）；
#     ③ 同步文档里的身份版本示例（<name>:ver<旧版> → <name>:ver<新版>，见下）。
#   默认 --patch（修 bug）；--minor 新能力；--major 不兼容变更；--to= 精确指定
#   目标版本（覆盖推断）。--dry 只预览不改文件。
#   约定（与项目纪律一致）：patch=修 bug / minor=新能力 / major=磁盘布局或不兼容变更。
#
# 【③ 为什么要同步文档】bump 只改 META6 的话，README 里那句
# `RakuPM:ver<0.68.0>` 示例就与 META6 漂了 —— 而 tools/run-suite.raku 的文档纪律
# 校验恰好要求「版本示例与 META6 一致」，于是每次 bump 后都要手工补两份 README，
# 漏了就一提交就红。这一步把「靠人记」变成「命令顺手做掉」。
# 【只替换恰好等于旧版本的实例】README 里可能有历史引用（如「0.60.0 起支持 X」），
# 把那个也改掉是【错的】。所以只替换 `<name>:ver<旧版>` 这种精确串，
# 版本号对不上的引用原样留着（门禁若因此报红，那是真需要人工判断的漂移）。
# 扫描范围：发行版目录下所有 .md（递归，跳过 .git/.precomp 等隐藏目录）。
# --no-sync-docs 关掉这一步（发布第三方包、其文档版本示例是别人的身份时用）。
method bump(IO::Path $root, Str :$to = '', Bool :$major = False, Bool :$minor = False,
            Str :$date = '', Bool :$dry = False, Bool :$no-sync-docs = False --> Hash) {
    my $dir = ($root // '.').IO.absolute.IO;
    my $meta-file = $dir.add('META6.json');
    unless $dir.e && $dir.d {
        die "目录不存在：{$dir}";
    }
    unless $meta-file.e {
        die "{$dir} 里没有 META6.json，无法 bump 版本";
    }

    my %meta;
    {
        my $parsed = try from-json($meta-file.slurp);
        if $parsed ~~ Failure || ! $parsed.defined || !($parsed ~~ Associative) {
            die "META6.json 不是有效的 JSON 对象：{$meta-file}";
        }
        %meta = $parsed;
    }
    my $cur = (%meta<version> // '').Str.trim;
    # 注意：列表赋值 `($ma,$mi,$pa) = X` 返回的是左值容器列表（恒为真），
    # 不能接 `or die` 当守卫。这里先收进 @v 再数段数。
    my @v = self!parse-ver($cur);
    unless @v.elems == 3 {
        die "无法从当前版本 '{$cur}' 推断递增；请用 --to=X.Y.Z 指定目标版本";
    }
    my ($ma, $mi, $pa) = @v;

    my $new = do {
        if $to.defined && $to.trim.chars {
            self!parse-ver($to.trim)
                or die "非法的目标版本：{$to}（应为 X.Y.Z，如 1.2.3）";
            $to.trim.subst(/^ 'v' /, '');
        }
        elsif $major { "{$ma+1}.0.0" }
        elsif $minor { "{$ma}.{$mi+1}.0" }
        else         { "{$ma}.{$mi}.{$pa+1}" }
    };
    unless $new ~~ /^ <[0..9]>+ '.' <[0..9]>+ '.' <[0..9]>+ $/ {
        die "目标版本格式不对：{$new}（应为 X.Y.Z）";
    }

    my $today = ($date.defined && $date.trim.chars) ?? $date.trim !! Date.today.Str;

    my Str $pkg-name = (%meta<name> // '').Str;

    if $dry {
        say "==> [dry] {$cur} → {$new}（Changes 顶部加 ## {$new} - {$today}）";
        unless $no-sync-docs {
            my @plan = self!sync-doc-versions($dir, $pkg-name, $cur, $new, :dry);
            if @plan.elems {
                say "==> [dry] 文档版本示例：" ~ @plan.map({ "{$_<file>}×{$_<count>}" }).join('、')
                  ~ "（{$pkg-name}:ver<{$cur}> → {$pkg-name}:ver<{$new}>）";
            }
            else {
                say "==> [dry] 文档版本示例：找不到 {$pkg-name}:ver<{$cur}>，无需同步";
            }
        }
        say "  （未修改任何文件）";
        return %( ok => True, from => $cur, to => $new, changes => '', docs => () );
    }

    # 写 META6
    %meta<version> = $new;
    $meta-file.spurt(to-json(%meta, :sorted-keys));
    say "==> META6.json 版本 {$cur} → {$new}";

    # 写 Changes：已有则插入新版本头（位置见 !insert-changelog-entry），没有则从标题起创建
    my $changes-file = $dir.add('Changes');
    my $entry = "## {$new} - {$today}\n\n- Bump to {$new}.\n\n";
    if $changes-file.e {
        $changes-file.spurt(self!insert-changelog-entry($changes-file.slurp, $entry));
    }
    else {
        my $name = (%meta<name> // '').Str;
        $changes-file.spurt("# Change log for {$name}\n\n" ~ $entry);
    }
    say "==> Changes 顶部加 ## {$new} - {$today}";

    # ③ 同步文档里的身份版本示例（只替换恰好等于旧版本的实例；见方法头注释）
    my @docs = ();
    unless $no-sync-docs {
        @docs = self!sync-doc-versions($dir, $pkg-name, $cur, $new);
        if @docs.elems {
            say "==> 文档版本示例同步：" ~ @docs.map({ "{$_<file>}×{$_<count>}" }).join('、');
        }
    }

    return %( ok => True, from => $cur, to => $new, changes => $changes-file.absolute.Str,
              docs => @docs );
}

# ------------------- bump 的私有辅助实现 -------------------------------------

# 把新条目插进 Change log 的【正确位置】：文件以一级标题（`# xxx`）开头时，
# 条目要落在标题【之后】；否则直接前插。
#
# 【为什么需要】旧实现是无条件前插（`$entry ~ $slurp`），于是带 `# Changes` 标题的
# 文件会变成：
#     ## 0.69.0 - 2026-09-21
#     - Bump to 0.69.0.
#     # Changes                ← 文件标题被挤到新条目【下面】，结构颠倒
#     ## 0.68.0 - …
# 既有测试只断言 `contains('## X.Y.Z')`、不看位置，所以这个错位一直没被发现。
# 保留原文件末尾换行（lines/join 会吃掉它），故这里用 substr 而不是 lines。
method !insert-changelog-entry(Str $old, Str $entry --> Str) {
    my $m = $old.match(/^ ('#' \N* \n)/);
    return $entry ~ $old unless $m.defined;
    my Str $head = ~$m[0];
    my Str $rest = $old.substr($head.chars).subst(/^ \n+/, '');
    $head ~ "\n" ~ $entry ~ $rest;
}

# 列出发行版目录下所有 .md（递归；跳过以 . 开头的目录与文件，避开 .git / .precomp）。
# 不用外部 find/shell：要在任意源码目录里跨平台可靠。
method !md-files(IO::Path $dir --> List) {
    my @out;
    my @queue = ($dir,);
    while @queue.elems {
        my $d = @queue.shift;
        next unless $d.d;
        for $d.dir -> $e {
            next if $e.basename.starts-with('.');
            if $e.d { @queue.push($e) }
            elsif $e.f && $e.extension.lc eq 'md' { @out.push($e) }
        }
    }
    # .List 不能省：sort 返回 Seq，而本方法声明 --> List（严格返回类型会直接抛错）
    @out.sort({ $_.absolute.Str }).List;
}

# 把文档里的 `<name>:ver<旧版>` 同步为 `<name>:ver<新版>`。
# 返回 [ %( file => 相对路径, count => 替换处数 ), … ]；:dry 时只报告不落盘。
# 【为什么只替换精确串】README 里的历史引用（如「0.60.0 起支持 X」）不该被本次 bump
# 改掉 —— 改掉反而成了错误信息。版本号对不上的引用原样保留，交由文档纪律门禁去报，
# 那种才是真需要人判断的漂移。subst 的第一个参数传 Str 时按【字面量】匹配，
# 所以 `<` `>` 不会被当正则元字符。
method !sync-doc-versions(IO::Path $dir, Str $name, Str $old, Str $new,
                          Bool :$dry = False --> List) {
    return ().List unless $name.chars && $old.chars && $new.chars && $old ne $new;
    my Str $from = "{$name}:ver<{$old}>";
    my Str $to   = "{$name}:ver<{$new}>";
    my @changed;
    for self!md-files($dir) -> $f {
        my $txt = $f.slurp;
        next unless $txt.contains($from);
        my Int $n = $txt.comb($from).elems;
        $f.spurt($txt.subst($from, $to, :g)) unless $dry;
        @changed.push(%( file => $f.relative($dir).Str.subst('\\', '/', :g), count => $n ));
    }
    @changed.List
}

# raku-pm login [--api-key=<key>] [--username=<u> --password=<p>]
#   —— 生产侧凭据管理：把 fez/zef 生态的上传 api-key 存到本地凭据文件
#   （~/.raku-pm/credentials.json，权限仅属主可读，类 ssh key），后续
#   publish --remote 自动读取。两种取得 key 的方式：
#     · --api-key=<key>        直接导入一把已有 key（最常见的路径：用 fez login
#       取得的同一把 key，或 RAKUPM_API_KEY 环境变量）；
#     · --username=<u> --password=<p>  真实联网登录 42.zef.pm/login 换 key
#       （密码不落盘，只存服务端发的 key；与 fez 一致）。
#   api-key 认证形态：请求头 Authorization: Zef <key>。返回 %{ ok, stored, host }。
method login(Str :$api-key = '', Str :$username = '', Str :$password = '',
             Bool :$quiet = False --> Hash) {
    my %creds = self.load-credentials;
    my $stored = '';
    if $api-key.defined && $api-key.trim.chars {
        # 直接导入一把已有 key（最常见的 M2 路径：用 fez login 取得的同一把 key）。
        %creds<api-key> = $api-key.trim;
        $stored = 'api-key';
        if $username.defined && $username.trim.chars {
            %creds<username> = $username.trim;
        }
    }
    elsif ($username.defined && $username.trim.chars)
          && ($password.defined && $password.trim.chars) {
        # M3：真实联网登录 42.zef.pm/login，用服务端返回的 api-key 存凭据。
        # 密码不落盘（与 fez 一致，只存服务端发的 key）。
        my $key = self!login-remote($username.trim, $password.trim);
        %creds<api-key> = $key;
        %creds<username> = $username.trim;
        $stored = 'api-key';
        unless $quiet {
            say "==> 已用账号 {$username.trim} 登录 {$ECO-UPLOAD-HOST}，取得 api-key 并保存";
        }
    }
    else {
        die "login 需要 --api-key=<key>（导入一把已有 key），"
          ~ "或 --username=<u> --password=<p>（联网登录换取 api-key）。\n"
          ~ "  也可不设凭据、直接 `RAKUPM_API_KEY=<key> raku-pm publish --remote --dry` 预览。";
    }
    %creds<host> = $ECO-UPLOAD-HOST;
    self.save-credentials(%creds);
    unless $quiet {
        say "==> 已保存上传凭据到 {self.credentials-file}（仅属主可读）";
        say "    端点：{$ECO-UPLOAD-HOST}  已存：{$stored}";
    }
    return %( ok => True, stored => $stored, host => $ECO-UPLOAD-HOST.Str );
}

# 凭据文件路径：~/.raku-pm/credentials.json（RAKUPM_TARGET 优先，与安装前缀同根）。
method credentials-file(--> IO::Path) {
    my $target = do {
        my $t = %*ENV<RAKUPM_TARGET>.defined && %*ENV<RAKUPM_TARGET>.trim.chars
            ?? %*ENV<RAKUPM_TARGET>.trim
            !! '';
        $t.chars ?? $t.IO !! ($*HOME.add('.raku-pm')).IO;
    };
    return $target.add('credentials.json');
}

# 读凭据文件；不存在/损坏返回空 Hash（不抛，调用方决定怎么处理）。
method load-credentials(--> Hash) {
    my $f = self.credentials-file;
    return %() unless $f.e;
    my $parsed = try from-json($f.slurp);
    return %() if $parsed ~~ Failure || !$parsed.defined || !($parsed ~~ Associative);
    return $parsed;
}

# 写凭据文件：先建父目录（幂等），落盘 JSON，权限收紧到仅属主可读（类 ssh key，
# 避免别的账号读到 api-key）。平台判断走 RakuPM::Platform 单一入口。
#   · POSIX：chmod 600。
#   · Windows：没有 POSIX chmod 语义，改用 icacls 把 ACL 收敛到**仅当前用户**
#     （去掉继承权限 + 显式只授当前用户完全控制）。best-effort：权限命令失败
#     不致命（默认 ACL 已限制到当前用户），且**不向 stdout/stderr 喷任何标记**，
#     以免被 t/ 洁净门禁当成程序噪声误判失败。
method save-credentials(%creds --> Nil) {
    my $f = self.credentials-file;
    mkdir-p($f.parent) unless $f.parent.e;
    $f.spurt(to-json(%creds, :sorted-keys));
    if is-windows() {
        my $who = self!windows-current-user;
        if $who.chars {
            my Str $grant = $who ~ ':F';
            try {
                run('icacls', $f.absolute.Str, '/inheritance:r',
                    '/grant:r', $grant, :!out, :!err);
            }
        }
    }
    else {
        try { run('chmod', '600', $f.absolute.Str, :!out, :!err) }
    }
}

# Windows 上取当前登录用户（icacls 授权用）。返回空串表示拿不到 → 跳过 ACL 加固。
# 按字节读（系统命令编码随区域设置变，中文 Windows 上 icacls/whoami 是 GBK），
# 这里只取 ASCII 的 `HOST\user`，latin-1 解码即可保真。
method !windows-current-user(--> Str) {
    try {
        my $p = run('whoami', :out, :!err);
        my $who = $p.out.slurp(:close, :bin).decode('latin-1').trim;
        return ($p.exitcode == 0 && $who.chars) ?? $who !! '';
    }
    return '';
}

# 解析当前可用的 api-key：环境变量 RAKUPM_API_KEY > 凭据文件。都没有返回空串。
method resolve-api-key(--> Str) {
    if %*ENV<RAKUPM_API_KEY>:exists && %*ENV<RAKUPM_API_KEY>.defined
       && %*ENV<RAKUPM_API_KEY>.trim.chars {
        return %*ENV<RAKUPM_API_KEY>.trim;
    }
    my %c = self.load-credentials;
    return (%c<api-key> // '').Str.trim;
}

# 注销：删除本地凭据文件（~/.raku-pm/credentials.json 或 RAKUPM_TARGET 下的），
# 与 login 配对 —— 凭据是 api-key，一旦泄露或不再需要就该能删掉。文件本来就不存在
# 也算成功（但 existed/deleted 为 False，表示「本就没东西可删」）。
# 返回 %( ok, existed, deleted, path, error? ) 供 CLI 打印不同文案。
method logout(--> Hash) {
    my $f = self.credentials-file;
    my $existed = $f.e;
    if $existed {
        try {
            $f.unlink;
            CATCH {
                return %( ok => False, existed => True, deleted => False,
                          path => $f.absolute.Str,
                          error => "删除凭据失败：{.message}" );
            }
        }
    }
    return %( ok => True, existed => $existed, deleted => $existed,
              path => $f.absolute.Str );
}

# 真实上传端点：默认 $ECO-UPLOAD-HOST（42.zef.pm），可被 RAKUPM_UPLOAD_HOST 覆盖
# （测试指向本地 mock；高级用户也可指向自建/镜像的上传后端）。
method !upload-host(--> Str) {
    my $h = %*ENV<RAKUPM_UPLOAD_HOST>;
    return ($h.defined && $h.chars) ?? $h.trim !! $ECO-UPLOAD-HOST;
}

# 真实联网登录：POST 42.zef.pm/login（JSON 体，字段 username / password；
# 服务端 from-body 只认 application/json，multipart/urlencoded 会 500），从响应里
# 健壮抽取 api-key 返回。响应形状随服务端，按 JSON 解析取 key/api-key/api_key/token，
# 取不到再退化成「整个响应体就是裸 key」。登录失败或取不到 key 都 die。
method !login-remote(Str $username, Str $password --> Str) {
    my $resp = RakuPM::HTTP.new.post-json(
        "{self!upload-host}/login",
        :json(%('username' => $username, 'password' => $password)),
    );
    unless $resp<ok> {
        die "登录 {$ECO-UPLOAD-HOST}/login 失败（HTTP {$resp<status>}）：{$resp<error> || $resp<body>}";
    }
    my $body = $resp<body>;
    my $key  = '';
    my $parsed = try from-json($body);
    if $parsed ~~ Associative {
        for <key api-key api_key token> -> $k {
            my $v = ($parsed{$k} // '').Str.trim;
            if $v.chars { $key = $v; last }
        }
    }
    elsif $parsed ~~ Str {
        $key = $parsed.trim;
    }
    $key ||= $body.trim;
    die "登录成功，但响应里找不到 api-key（响应前 200 字：{$body.substr(0,200)}）" unless $key.chars;
    return $key;
}

# 打印预检报告（✗ 错误 / ! 警告）。空结果给一句「就绪」。
method !emit-check-report(IO::Path $dir, @errors, @warnings --> Nil) {
    say "==> 预检 {$dir} 的发布资格";
    for @errors  -> $e { say "  [✗] {$e}" }
    for @warnings -> $w { say "  [!] {$w}" }
    my $n-e = @errors.elems;
    my $n-w = @warnings.elems;
    if $n-e == 0 && $n-w == 0 {
        say "  ✓ 一切就绪，可以发布";
    }
    else {
        say "  发现 {$n-e} 个错误、{$n-w} 个警告。";
        say "  （错误必须修复后才能发布；警告不阻断，但建议处理）" if $n-e == 0;
    }
}

# 联网查已配置仓库里 name:ver<X> 是否已存在。
# 返回 True=已发布 / False=确认未发布 / Nil=无法确认（离线或索引拉取失败）。
# 仅 --remote 时调用；懒加载 RakuPM::Repositories（重图），默认不拖。
method !probe-remote(Str $name, Str $version, Str $auth --> Bool) {
    my $target = do {
        my $t = %*ENV<RAKUPM_TARGET>.defined && %*ENV<RAKUPM_TARGET>.trim.chars
            ?? %*ENV<RAKUPM_TARGET>.trim
            !! '';
        $t.chars ?? $t.IO !! ($*HOME.add('.raku-pm')).IO;
    };
    my $repos = try {
        (require RakuPM::Repositories).new(
            :config-file($target.add('repositories.json')),
            :cache-root($target.add('cache')),
            :repo-root(%*ENV<RAKUPM_REPO> // '.'),
        )
    };
    return Nil unless $repos.defined;
    try $repos.load;
    my @rs = try $repos.build;
    return Nil unless @rs.elems;
    my Bool $any-queried = False;
    for @rs -> $repo {
        # 只查远程生态索引；本地目录仓库里的「自己」不算已发布
        next unless $repo.WHAT.^name eq 'RakuPM::Repository::Ecosystem';
        my $found = try {
            $repo.refresh;
            $any-queried = True;
            $version (elem) $repo.available-versions($name)
        };
        return True if $found ~~ Bool && $found;
    }
    $any-queried ?? False !! Nil
}

# 探测当前 tar 是否为 GNU tar（而非 Windows 自带的 BSD libarchive tar）。
# 两者路径语义相反：GNU tar 把 C: 当成远程磁带机主机，需要 /c/…；
# BSD tar（C:\Windows\System32\tar.exe，Windows 10+ 默认）认原生 C:/…。
# 探测失败（tar --version 跑不动）时保守当作「非 GNU」→ 走原生 Windows 路径，
# 即默认假设原生 Windows，而非 Git Bash。结果缓存一次，跨调用复用。
method !tar-is-gnu(--> Bool) {
    state $cached;
    return $cached if $cached ~~ Bool;
    my $tar = %*ENV<RAKUPM_TAR> // 'tar';
    my $ver = '';
    try {
        my $p = run($tar, '--version', :out, :err);
        $ver = ($p.out.slurp(:close) // '') ~ ($p.err.slurp(:close) // '');
    }
    $cached = so ($ver ~~ / 'GNU tar' /);
    $cached
}

# 把路径转成「当前 tar 认得的形态」。统一先反斜杠转正斜杠；
# 仅当 tar 是 GNU tar 时，才把盘符 C:/… 转成 MSYS 的 /c/…。
# 默认（原生 Windows / BSD tar）保留 C:/… 原生形态——本管理器面向原生 Windows，
# 不假设 Git Bash；若用户确用 GNU tar，探测后会自动走 /c/…。
method !tar-path(Str $p --> Str) {
    my $s = $p.subst('\\', '/', :g);
    if self!tar-is-gnu {
        my @c = $s.comb;
        if @c.elems >= 3 && @c[0] ~~ /<[A..Za..z]>/
           && @c[1] eq ':' && @c[2] eq '/' {
            $s = '/' ~ @c[0].lc ~ $s.substr(2);
        }
    }
    $s
}

# 把版本串解析成 (major, minor, patch) Int 列表；容忍 v 前缀与缺失的后段（补 0）。
# 解析不了返回空列表（调用方 `or die`）。
method !parse-ver(Str $v --> List) {
    my $s = $v.trim.subst(/^ 'v' /, '');
    return () unless $s.chars;
    if $s ~~ /^ (<[0..9]>+) [ '.' (<[0..9]>+) ]? [ '.' (<[0..9]>+) ]? $/ {
        return ($0.Int, ($1 ?? $1.Int !! 0), ($2 ?? $2.Int !! 0)).List;
    }
    return ();
}

# 可选构建阶段：发现 Build.pm（约定 class Build 的 build 方法）就原地跑一遍。
# 原生扩展类发行版靠它编译 C 源生成 resources/libraries/*.so，产物会进 tar 包。
# META6 的 builder 字段（Distribution::Builder::*）暂不在 dist 内分发执行：
# 源分发不带预编译产物，真正的构建在消费者 install 时由 Builder 角色完成。
method !run-build(IO::Path $dir, Bool :$quiet = False --> Nil) {
    my $build-pm = $dir.add('Build.pm');
    if $build-pm.e && $build-pm.f {
        unless $quiet { say "==> 运行构建阶段 Build.pm" }
        # 注意：rakudo 是原生 Windows 程序，收原生路径（C:\...），不能走 !tar-path 的
        # MSYS /c/... 转换（那只在 tar 是 GNU tar 时才会发生）。否则会 "Failed to stat file"。
        my $proc = run($*EXECUTABLE.Str, $build-pm.absolute.Str,
                       :cwd($dir.absolute), :out, :err);
        $proc.out.slurp(:close);
        my $err = $proc.err.slurp(:close);
        if $proc.exitcode != 0 {
            die "构建阶段失败（Build.pm 退出码 {$proc.exitcode}）：{$err.trim}";
        }
    }
}

# 把发行版目录打成 gzip 压缩的 tar 源分发。
# 做法：递归收集相对路径清单（排除 VCS / 预编译 / 临时文件，以及输出包自身），
# 写临时清单后 `tar -czf <out> -C <dir> --files-from=<清单>`，避免命令行过长、
# 也避免把正在生成的 tar 包自己打进去。RAKUPM_TAR 可覆盖 tar 命令。
# 返回 True/False（失败原因已 note，由调用方决定 die）。
method !tar-gz(IO::Path $dir, IO::Path $out --> Bool) {
    # 走统一的 RakuPM::Fs.walk-files：默认跳过 .git/.hg/.svn/.precomp/blib，
    # 这里再额外排除备份文件，以及【正在生成的 tar 包自身】—— 不排除的话会把
    # 写到一半的包打进包里（自包含 / 体积翻倍）。顺序稳定（按绝对路径排序），
    # 因此同一份内容每次打包得到的成员清单一致。
    # 相对路径交给 !tar-path 转成当前 tar 认得的形态（GNU tar 要 /c/…、
    # Windows 自带 bsdtar 要原生 C:/…），这两种都验过。
    # 排除「相对发行版根、路径中含隐藏分量（以 . 开头）」的条目 —— 覆盖 VCS 元数据、
    # 私有工作目录（.workbuddy）、CI 配置（.workflow）、编辑器目录（.vscode/.idea），
    # 以及根级 dot 文件（.gitignore/.gitattributes）。
    # 【为什么在 dist 这层收紧、而不是改 walk-files 的默认跳过集】walk-files 还用于
    # 内容指纹（Store）与 provides 扫描 —— 动它的默认跳过集会改变既有包的指纹；
    # 只在打包这层过滤，影响面最小。
    # 【背景 · 0.74.1 修】dist 是按【目录】扫描、**不读 .gitignore**，所以被 gitignore
    # 的私有目录（如仓库里的 .workbuddy/ 工作记忆）此前会被打进发布包发到公开生态。
    my &hidden-component = -> IO::Path $f {
        $f.relative($dir).Str.subst('\\', '/', :g).split('/')
            .first({ .starts-with('.') }).defined
    };
    # 【0.75.0 新增】用户可自定义的排除清单：发行版根下的 `.distignore`。
    # 隐藏项过滤能挡住「以 . 开头」的东西，但挡不住【非隐藏的内部文件】——
    # 例如仓库里放着的 AI 指令 / 重构路线图 / 内部手册，它们名字正常、却不该
    # 发到公开生态。作者在 `.distignore` 里逐条列出即可（保留在仓库、不进包）。
    # 注意 `.distignore` 自身以 . 开头，所以按上面的规则本就不会进包。
    my @ignores = self!dist-ignores($dir);
    my &ignored = -> IO::Path $f {
        my Str $rel = $f.relative($dir).Str.subst('\\', '/', :g);
        # 匹配 = 相对路径【恰好相等】或以【条目/】开头（于是目录条目自动覆盖其子树）
        so @ignores.first({ $rel eq $_ || $rel.starts-with("{$_}/") });
    };
    # 额外排除：备份文件、以及 raku-pm 自己的锁文件（作者若在发行版目录里跑过
    # `raku-pm install`，cwd 就会留下 raku-pm.lock —— 那是本地状态，不该进发布包）。
    my @walked = walk-files($dir, :skip-names(['.DS_Store', 'META6.json.bak', 'raku-pm.lock']))
        .grep({ .absolute.Str ne $out.absolute.Str })
        .List;

    # 安全网：.distignore 里写了、却在发行版里找不到任何对应条目的行，八成是笔误
    # （文件名拼错 / 路径写歪）。静默忽略会让【本该排除的文件照样发出去】——
    # 这正是这套机制最该避免的事故，所以显式提示（不致命，不阻断打包）。
    if @ignores.elems {
        my @rels = @walked.map({ .relative($dir).Str.subst('\\', '/', :g) }).List;
        my @unmatched = @ignores.grep(-> $e {
            !@rels.first({ $_ eq $e || $_.starts-with("{$e}/") })
        }).sort.List;
        if @unmatched.elems {
            note "⚠  .distignore 里有 {@unmatched.elems} 条没有匹配到任何文件"
               ~ "（可能拼错了，本次打包不会排除它们）：{@unmatched.join('、')}";
        }
    }

    my @files = @walked
        .grep({ !hidden-component($_) })
        .grep({ !ignored($_) })
        .map({ self!tar-path(.relative($dir).Str).subst(/^ '.\/' /, '') })
        .List;
    return False unless @files.elems;

    my $list-file = ($*TMPDIR // '/tmp'.IO)
        .add("rakupm-dist-{($*PID)}-{now.to-posix[0].Int}.list");
    $list-file.spurt(@files.join("\n"));

    my $tar = %*ENV<RAKUPM_TAR> // 'tar';
    # 防御：先删掉可能残留的旧包。作用有二——
    # 1) 避免 GNU tar 在「覆盖已存在输出文件」时若用户配了 ~/.tarrc 或
    #    TAR_OPTIONS=--backup，会对输出文件做备份而报
    #    "modify_backup: Couldn't visit directory" 且退出码 1（包其实已生成）；
    # 2) 保持幂等，不留上次失败残留的半截包。
    # 注意：不传 --backup=none 之类的 GNU 专有旗标——Windows 自带的是 BSD
    # libarchive tar，会把它当未知选项直接报错；本管理器默认面向原生 Windows。
    try $out.unlink if $out.e;
    my $proc = run($tar, '-czf', self!tar-path($out.absolute.Str),
                   '-C', self!tar-path($dir.absolute.Str),
                   '--files-from=' ~ self!tar-path($list-file.absolute.Str),
                   :out, :err);
    $proc.out.slurp(:close);
    my $err = $proc.err.slurp(:close);
    $list-file.unlink;
    if $proc.exitcode != 0 {
        note "tar 打包失败（退出码 {$proc.exitcode}）：{$err.trim}";
        return False;
    }
    return True;
}

# 读发行版根下的 `.distignore`（可选），返回【相对路径条目】列表供 !tar-gz 过滤。
# 语法刻意做得很小、很可预测：
#   · 一行一条，相对发行版根的路径，统一用 `/` 分隔；
#   · 空行、以及以 `#` 开头的行忽略（可写注释）；行尾注释也认 —— `#` 前面
#     必须有空白（与 .gitignore 同款语义），否则整行原样当路径。**这条很关键**：
#     不剥行尾注释的话，「`FOO.md   # 内部文档`」会被当成一个含空格的长文件名而
#     静默失配 —— 正好是这套机制最该避免的事故；
#   · 行首 `./` 与行尾多余的 `/` 会被剥掉（目录写法两种都收）；
#   · 匹配 = 相对路径恰好相等，或以 `<条目>/` 开头（目录条目覆盖整棵子树）；
#   · **不支持通配符** —— 刻意如此：`*` 在一个包管理器里容易造成「以为排除了、
#     其实没有」的静默事故，宁可要求作者逐条写清楚。
# 文件不存在 → 空清单（零成本、零行为变化）。
method !dist-ignores(IO::Path $dir --> List) {
    my $f = $dir.add('.distignore');
    return () unless $f.f;
    my @out;
    for $f.lines -> $line {
        my Str $s = $line.trim;
        next unless $s.chars;
        next if $s.starts-with('#');
        # 行尾注释：`#` 前必须有空白，否则整行都算路径（与 .gitignore 语义一致）
        $s = $s.subst(/ \s+ '#' .* $ /, '').trim;
        next unless $s.chars;
        $s = $s.subst('\\', '/', :g).subst(/^ '.\/' /, '').subst(/\/+$/, '');
        @out.push($s) if $s.chars;
    }
    @out.List;
}

# 把 sdist 源分发解包进目标目录（publish 用）。成员是相对路径、无顶层前缀
# （见 !tar-gz：相对 dir 且剥离了 ./），所以 `tar -xzf <tar> -C <dest>` 直接把
# META6 / lib/ / bin/ / t/ … 落到 <dest> 下。路径转换复用 !tar-path：原生 Windows
# （BSD libarchive tar）收 C:/…、Git Bash（GNU tar）收 /c/…，两种 tar 一致。
# 返回 True/False（失败原因已 note，由调用方决定 die）。
method !tar-extract(IO::Path $tar, IO::Path $dest --> Bool) {
    my $t = %*ENV<RAKUPM_TAR> // 'tar';
    my $p = run($t, '-xzf', self!tar-path($tar.absolute.Str),
                '-C', self!tar-path($dest.absolute.Str),
                :out, :err);
    $p.out.slurp(:close);
    my $err = $p.err.slurp(:close);
    if $p.exitcode != 0 {
        note "tar 解包失败（退出码 {$p.exitcode}）：{$err.trim}";
        return False;
    }
    return True;
}

# 列出 tar.gz 归档内的成员名（供自检与回归测试用）。复用与 !tar-gz 完全一致的
# !tar-path 路径转换：原生 Windows（BSD libarchive tar）收 C:/…、Git Bash（GNU
# tar）收 /c/…，两种 tar 都能正确读取，避免测试里再硬编码一套路径转换。
method tar-archive-list(IO::Path $out --> List) {
    my $tar = %*ENV<RAKUPM_TAR> // 'tar';
    my $p = run($tar, '-tzf', self!tar-path($out.absolute.Str), :out, :err);
    my $o = $p.out.slurp(:close);
    $p.err.slurp(:close);
    return $p.exitcode == 0 ?? $o.lines.List !! ();
}
