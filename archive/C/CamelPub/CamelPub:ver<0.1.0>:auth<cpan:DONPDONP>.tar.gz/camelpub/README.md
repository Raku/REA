client side
```
donp@jewel actpub $ ./bin/actpub follow donpdonp@mastodon.xyz
webfinger donpdonp@mastodon.xyz => https://mastodon.xyz/.well-known/webfinger?resource=acct:donpdonp@mastodon.xyz
link to profile https://mastodon.xyz/users/donpdonp
{
  "object": "https://mastodon.xyz/users/donpdonp",
  "@context": "https://www.w3.org/ns/activitystreams",
  "id": "uuid",
  "type": "Follow",
  "actor": "https://donpark.org/"
}
POST INBOX https://mastodon.xyz/users/donpdonp/inbox
(request-target): post /users/donpdonp/inbox
host: mastodon.xyz
date: Mon, 23 Jul 2018 22:41:51 GMT
authorization: keyId="https://donpark.org/",algorithm="rsa-sha256",headers="(request-target) host date",signature="FOi4glCNJj5zPdNu8BEbvmi+vCpeRR9z+246w70wjHhphV2h3rUt/DvBgmdZE13LIEJXJkCzLycHmMSlkx1oH6XULes0ICXdBa92iuOz3B+3RGj4RIDTS+vNO2yfcUA0qsl0EQaBBM2Els+ymjlTCXCvk98lDGYCVwHSoamwFVpAsMGOskxQqKb+ECsOEkpPrttrocv/XubXWzkfoA8Bw/Zi8aFb9OpwCArbE6EDSh3V3y+Ko6YfqsSdOa98ngspHbRxG2uR+KUJrr1w4GsWlMEbdmGQ0jxoPeQp8Foa7up4af5UOehYTZBzRNkkg3Oc1wgdN9NM0eUE+nAdzzuD9Q=="
inbox post 202 body: ""
donp@jewel actpub $
```


Server side
```
donp@jewel actpub $ ./bin/actpub listen
server listening :2314
POST ["activitypub", "inbox"]
 Content-Type: application/activity+json
 Signature: keyId="https://mastodon.xyz/users/donpdonp#main-key",algorithm="rsa-sha256",headers="(request-target) user-agent host date accept-encoding digest content-type",signature="b33jNGe/6zFmpmajHrkHMevAl4oRTjicKmQpXohuTgRWOae/bMfQM7B3OEWKKWhX2H9e1CY3P2jFuEgyR7lgEVChwg8w/5RNNJWpq8jadp9FiU0CVCXT32Ub5juXhGpsHTYzCXqZjOGMPJpxgUjHj17WK7cqkuOLSVorUkfXJTVEuEezp4zHIymq5A8Lf3RtCqY9RJxCPMhmPrisHRkKRs2GPkiohMc2ajMSDXDaN688cCYJZaUcqgq2uu+zZDIL1pZdCWLGR+/jKiDQ9FuF4xOMfkuEudK49dxM/0eC4xf+c140lLOc8+4u/3Kkw9Bm2u7bBomLIhi19eC1mQGPfA=="
-> {
  "actor": "https://mastodon.xyz/users/donpdonp",
  "type": "Accept",
  "object": {
    "actor": "https://donpark.org/",
    "type": "Follow",
    "object": "https://mastodon.xyz/users/donpdonp",
    "id": "https://donpark.org/#follows/"
  },
  "signature": {
    "signatureValue": "MB803Sjbe3oBfh1E1YQySdbv8be/b8A+fU5EvS/Q8G4YhUMce+7IyLRW0EDOR9vy+MNf7nIYG5qvz+SCULM5UuGoA5f+t2ITe8jKZyah+0U8KPt0AwL7/lLGynX0gzfRnj6B9jNKcwbseuNb6Dl1ofa1Vrp2QR5D8sVgPdFP3mfB4VqwYK4Hr3gxN85bY4kpTD0kd443WBiHINqK8oE4zTZ5A/tN2dsadqYrOh/A3LV88X9DHYsuZlDBdebRRBoxlHq+n3pFi2eT3h0yZd9ef6Ub5bZACC43rVcPHKkjveLdqrbd8ThKA6fJfuD8VYVPaQeYYw3BO6K5jrgIdJOX9g==",
    "type": "RsaSignature2017",
    "creator": "https://mastodon.xyz/users/donpdonp#main-key",
    "created": "2018-07-23T22:41:52Z"
  },
  "id": "https://mastodon.xyz/users/donpdonp#accepts/follows/",
  "@context": [
    "https://www.w3.org/ns/activitystreams",
    "https://w3id.org/security/v1",
    {
      "value": "schema:value",
      "featured": "toot:featured",
      "inReplyToAtomUri": "ostatus:inReplyToAtomUri",
      "movedTo": "as:movedTo",
      "PropertyValue": "schema:PropertyValue",
      "toot": "http://joinmastodon.org/ns#",
      "conversation": "ostatus:conversation",
      "sensitive": "as:sensitive",
      "schema": "http://schema.org#",
      "manuallyApprovesFollowers": "as:manuallyApprovesFollowers",
      "focalPoint": {
        "@container": "@list",
        "@id": "toot:focalPoint"
      },
      "ostatus": "http://ostatus.org#",
      "Emoji": "toot:Emoji",
      "Hashtag": "as:Hashtag",
      "atomUri": "ostatus:atomUri"
    }
  ]
}

```
