# Config::Parser::json
A JSON parser for [Config](https://github.com/scriptkitties/p6-Config).


## Installation
```bash
zef install Config::Parser::json
```

## License
GPL|Artistic-2.0
