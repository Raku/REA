CLASS
=====

`Config::BINDish::Grammar::OptionProps` - option statement properties

DESCRIPTION
===========

Does [`Config::BINDish::Grammar::StatementProps`](StatementProps.md), [`Config::BINDish::Grammar::ContainerProps`](ContainerProps.md), [`Config::BINDish::Grammar::DeclarationProps`](DeclarationProps.md).

SEE ALSO
========

[`Config::BINDish`](../../BINDish.md), [`Config::BINDish::Grammar`](../Grammar.md), [`Config::BINDish::Grammar::BlockProps`](BlockProps.md)

AUTHOR
======

Vadim Belman <vrurg@cpan.org>

