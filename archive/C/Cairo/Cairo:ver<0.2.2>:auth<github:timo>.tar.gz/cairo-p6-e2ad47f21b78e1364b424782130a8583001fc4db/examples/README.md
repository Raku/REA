- `multi-page-pdf.pl` demonstrates the creation of a two page PDF.
- `svg-surface.pl` demonstrates creation of a SVG graphic.
- all other examples produce PNG images.

Please see https://cairographics.org/samples for expected output and equivalent C programs.
