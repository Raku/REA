`multi-page-pdf.pl` demonstrates the creation of a two page PDF.

For other examples, please see https://cairographics.org/samples
for expected output and equivalent C programs.
