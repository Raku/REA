- `multi-page-pdf.p6` demonstrates the creation of a two page PDF.
- `svg-surface.p6` demonstrates creation of a SVG graphic.
- all other examples produce PNG images.

Please see https://cairographics.org/samples for expected output and equivalent C programs.
