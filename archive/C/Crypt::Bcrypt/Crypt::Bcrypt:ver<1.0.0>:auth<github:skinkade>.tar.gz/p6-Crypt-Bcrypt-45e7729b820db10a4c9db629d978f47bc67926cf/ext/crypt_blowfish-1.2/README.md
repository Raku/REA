See the header of [crypt_blowfish.c](crypt_blowfish.c)
