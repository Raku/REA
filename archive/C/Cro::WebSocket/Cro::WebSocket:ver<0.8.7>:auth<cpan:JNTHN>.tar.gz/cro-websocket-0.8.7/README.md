# Cro::WebSocket ![Build Status](https://github.com/croservices/cro-websocket/actions/workflows/ci.yml/badge.svg)

This is part of the Cro libraries for implementing services and distributed
systems in Raku. See the [Cro website](http://cro.services/) for further
information and documentation.
