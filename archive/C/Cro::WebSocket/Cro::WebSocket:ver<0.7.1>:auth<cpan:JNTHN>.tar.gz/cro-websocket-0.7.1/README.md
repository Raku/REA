# Cro::WebSocket [![Build Status](https://travis-ci.org/croservices/cro-websocket.svg?branch=master)](https://travis-ci.org/croservices/cro-websocket)

This is part of the Cro libraries for implementing services and distributed
systems in Perl 6. See the [Cro website](http://cro.services/) for further
information and documentation.
