Cro::HTTP::Session::Redis
=========================

This is part of the Cro libraries for implementing services and distributed systems in Perl 6. See the [Cro website](http://cro.services/) for further information and documentation.

