Cro::HTTP::Session::Redis ![Build Status](https://github.com/croservices/cro-http-session-redis/actions/workflows/ci.yml/badge.svg)
=========================

This is part of the Cro libraries for implementing services and distributed systems in Raku. See the [Cro website](http://cro.services/) for further information and documentation.

