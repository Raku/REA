use v6;
use Test;
use Compress::Zlib;

my $empty = compress(Buf.new);
ok $empty.bytes > 0, 'an empty payload has a complete zlib stream';
is uncompress($empty).bytes, 0, 'an empty payload roundtrips';

for -1, 0, 1, 6, 9 -> $level {
	my $payload = Buf.new((^1024).map(* % 256));
	is-deeply uncompress(compress($payload, $level)).list, $payload.list,
		"all byte values roundtrip at compression level $level";
	is uncompress(compress(Buf.new, $level)).bytes, 0,
		"empty payload roundtrips at compression level $level";
}
for -2, 10 -> $level {
	throws-like { compress(Buf.new(1, 2, 3), $level) }, X::AdHoc,
		message => / 'compression level must be between -1 and 9' /,
		"invalid compression level $level is rejected";
}

my $expanded = ('A' x 65536).encode;
my $small = compress($expanded);
ok $small.bytes < 256, 'fixture requires repeated output buffer growth';
is-deeply uncompress($small).list, $expanded.list,
	'high expansion roundtrip preserves every byte';

throws-like { uncompress(Buf.new) }, X::AdHoc,
	message => / 'uncompress data error' /, 'empty compressed input is rejected';
for Buf.new(0), Buf.new(255 xx 20), 'not compressed'.encode -> $invalid {
	throws-like { uncompress($invalid) }, X::AdHoc,
		message => / 'uncompress data error' /, 'invalid compressed input is rejected';
}

my $complete = compress('truncation check'.encode);
for 1 ..^ $complete.bytes -> $length {
	my $truncated = Buf.new($complete.list.head($length));
	throws-like { uncompress($truncated) }, X::AdHoc,
		message => / 'uncompress data error' /,
		"truncated input of $length bytes is rejected";
}
my $bad-checksum = Buf.new($complete.list);
$bad-checksum[*-1] +^= 1;
throws-like { uncompress($bad-checksum) }, X::AdHoc,
	message => / 'uncompress data error' /, 'incorrect checksum is rejected';

for 'inflate', 'deflate' -> $operation {
	my $stream = Compress::Zlib::Stream.bless(:window-bits(100));
	for 1, 2 -> $attempt {
		throws-like { $stream."$operation"(Buf.new(1, 2, 3)) }, X::AdHoc,
			message => / 'Cannot initialize ' $operation ' stream: zlib status -2' /,
			"invalid $operation initialization is rejected on attempt $attempt";
	}
	lives-ok { $stream.finish }, "failed $operation initialization can be cleaned up";
	ok !$stream.finished, "failed $operation initialization never marked the stream initialized";
}

done-testing;
