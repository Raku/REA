unit role CSS::Specification::Compiler::Grammars;

use CSS::Specification::Compiler::Util;

method actions { ... }
method defs { ... }

proto sub compile (|c) is export(:compile) {
    {*}
}

multi sub modifier('i') { RakuAST::Regex::InternalModifier::IgnoreCase.new }
multi sub modifier('!r') { RakuAST::Regex::InternalModifier::Ratchet.new: :modifier<r>, :negated }

sub rule(RakuAST::Name:D $name, $body) {
    RakuAST::RuleDeclaration.new(
            :$name,
            :$body,
        )
}

sub property-decl(Str:D $sym, :$quant, Str:D :$base-val!) {
    my RakuAST::Name $name = "decl:sym<$sym>".&name;
    my RakuAST::Regex $regex-body = $base-val.&assertion;

    $regex-body .= &quantified: $_
        with $quant;

    $name.&rule(
        seq (
            'i'.&modifier,
            RakuAST::Regex::CapturingGroup.new(
                $sym.&lit'r.&seq
            ).&ws,

            RakuAST::Regex::Quote.new(
                RakuAST::QuotedString.new(
                    segments   => (
                        ":".&lit's,
                    )
                )
            ).&ws,

            RakuAST::Regex::Assertion::Named::Args.new(
                name      => 'val'.&name,
                args      => RakuAST::ArgList.new(
                    RakuAST::QuotedRegex.new(
                        body => $regex-body.&ws,
                    ),
                    RakuAST::Var::Compiler::Routine.new.&postfix('WHY'.&call),
                ),
                :capturing
            )
        )
    );
}

sub at-rule-decl(Str:D $sym, Str:D :$base-val!) {
    my RakuAST::Name $rule-name = "decl:sym<\@$sym>".&name;
    my RakuAST::Regex::Assertion::Named $assertion = $base-val.&assertion(:!capturing);
    my $rule-body = ('@'.&lit'r,
                     RakuAST::Regex::Assertion::Alias.new(
                         :name<at-rule>, :$assertion
                     )
                    ).&seq;
    $rule-name.&rule($rule-body);
}

multi sub compile(:%prop-spec! (:@props!, :$default, Pair :$spec! is copy, Str :$synopsis!, Bool :$inherit = True)) {
    my $quant;

    if $spec.key eq 'occurs' && $spec.value.head ~~ [*, 4] {
        ($quant, $spec) = $spec.value.List;
    }

    my RakuAST::Regex $body = $spec.&compile;
    $body = ('i'.&modifier, $body.&ws, ).&seq;
    my Str $leading = (@props.head, ': ', $_, "\n").join
        given $synopsis;

    my RakuAST::Statement::Expression @exprs;

    for @props -> $prop {
        my $base-val = 'prop-val-' ~ $prop;
        @exprs.push: $prop.&property-decl(:$quant, :$base-val).declarator-docs(
            :$leading
        ).&expression;
        @exprs.push: $base-val.&name.&rule($body).&expression
            unless $*ACTIONS.rules{$base-val};
    }

    @exprs;
}

multi sub compile(:rule-spec(%)! (Str :$rule!, :$spec!, Str :$synopsis!)) {
    my RakuAST::Regex $body = $spec.&compile;
    $body = ('i'.&modifier, $body.&ws, ).&seq;

    my Str $leading = "<%s> = %s\n".sprintf: $rule, $synopsis;
    my RakuAST::Name $name = $rule.&name;

    $name.&rule($body).declarator-docs(
        :$leading
    ).&expression.List
}

multi sub compile(:at-rule-spec(%)! (Str :$at-rule!, :$spec!, Str :$synopsis!)) {
    my RakuAST::Regex $body = $spec.&compile;
    $body = (
        RakuAST::Regex::CapturingGroup.new(('i'.&modifier, $at-rule.&lit'r).&seq).&ws,
        $body.&ws,
    ).&seq;
    my $base-val = 'at-rule-' ~ $at-rule;

    my Str $leading = "\@%s %s\n".sprintf: $at-rule, $synopsis;
    my RakuAST::Statement::Expression @exprs;
    @exprs.push: $at-rule.&at-rule-decl(:$base-val).declarator-docs(
            :$leading
        ).&expression;
    @exprs.push: $base-val.&name.&rule($body).&expression
        unless $*ACTIONS.rules{$base-val};
    @exprs;
}

multi sub compile(:alias(%)! (Str:D :$ref!, Str:D :$rule!)) {
    my Str:D $name = $ref;
    RakuAST::Regex::Assertion::Alias.new(
        :$name,
        assertion => RakuAST::Regex::Assertion::Named.new(
            name => $rule.&name,
        )
    )
}

sub op(Str:D $op) { :$op.&compile } 

# <a>#? , <b>  ->  [:!r [<a> +% ','] ',']? <b>
multi sub compile(:occurs(@)! ( '?', :$trailing! where ',', :occurs(@)! (',', *%term))) {
    my RakuAST::Regex $atom = (|%term).&compile.&group.&ws;
    my RakuAST::Regex $lhs = $atom.&quantified('+', :separator($trailing.&op.&ws));
    ['!r'.&modifier, $lhs.&ws, $trailing.&op].&group.&quantified: '?';
}

# <a>? , <b>   ->  [:!r <a> ',']? <b>
multi sub compile(:occurs(@)! ( '?', :$trailing! where ',', *%term)) {
    my RakuAST::Regex $atom = (|%term).&compile.&group.&ws;
    [$atom, $trailing.&op].&group.&quantified: '?';
}

multi sub compile(:occurs(@)! ( $quant!, :$trailing, *%term)) {
    warn "ignoring trailing {.raku}" with $trailing;
    my RakuAST::Regex $atom = (|%term).&compile.&group.&ws;
    $atom.&quantified: $quant;
}

multi sub quant('?') { RakuAST::Regex::Quantifier::ZeroOrOne.new }
multi sub quant('*') { RakuAST::Regex::Quantifier::ZeroOrMore.new }
multi sub quant('+') { RakuAST::Regex::Quantifier::OneOrMore.new }
multi sub quant(',') { RakuAST::Regex::Quantifier::OneOrMore.new }
multi sub quant(@ ( UInt:D $min, UInt:D $max, *@) ) {
    RakuAST::Regex::Quantifier::Range.new: :$min, :$max
}
multi sub quant(@ ( Str:D $_, ',') ) {  # list-maybe
    .&quant;
}

sub look-ahead(RakuAST::Regex::Assertion $assertion, Bool :$negated = False) is export {
    RakuAST::Regex::Assertion::Lookahead.new(
        :$assertion, :$negated
    );
}

proto sub assertion(|) is export {*}
multi sub assertion(Str:D $id, Bool :$capturing = True, RakuAST::ArgList :$args!) {
    my RakuAST::Name $name := $id.&name;
    RakuAST::Regex::Assertion::Named::Args.new(
        :$name, :$capturing, :$args,
    );
}

multi sub assertion(Str:D $id, Bool :$capturing = True) {
    my RakuAST::Name $name := $id.&name;
    RakuAST::Regex::Assertion::Named.new(
        :$name, :$capturing,
    );
}

proto sub arg(|) is export {*}
multi sub arg(Str:D $arg) {
    RakuAST::ArgList.new: $arg.&lit's;
}

multi sub arg(Int:D $arg) {
    RakuAST::ArgList.new: $arg.&lit'i;
}

multi sub whitespaced(RakuAST::Regex::WithWhitespace) { True }
multi sub whitespaced(RakuAST::Regex::Sequence $_ )   { .terms.tail.&whitespaced }
multi sub whitespaced(RakuAST::Regex::Branching $_)   { .branches.tail.&whitespaced }
multi sub whitespaced($) { False }

proto sub ws($) is export {*}
multi sub ws(RakuAST::Regex $w where .&whitespaced) { $w }
multi sub ws(RakuAST::Regex::Term $r) { RakuAST::Regex::WithWhitespace.new($r) }
multi sub ws(RakuAST::Regex $r) {
    $r.&group.&ws;
}

multi sub group(@seq) { @seq.&seq.&group }
multi sub group(RakuAST::Regex::Group $g) {$g}
multi sub group(RakuAST::Regex::Assertion $a) {$a}
multi sub group(RakuAST::Regex $r) is export  {
    RakuAST::Regex::Group.new: $r
}

sub alt(@choices) is export {
    RakuAST::Regex::Alternation.new: |@choices;
}

multi sub seq(@seq, :alt($)! where .so) {
    RakuAST::Regex::SequentialAlternation.new: |@seq
}
multi sub seq(@seq) {
    RakuAST::Regex::Sequence.new(|@seq);
}
multi sub seq($seq) { $seq }

sub conjunct(RakuAST::Regex $r1, RakuAST::Regex $r2) is export {
    RakuAST::Regex::Conjunction.new($r1, $r2);
}

sub lexical(Str:D $sym) is export {
    RakuAST::Var::Lexical.new($sym)
}

sub array-index($_) is export {
    RakuAST::Postcircumfix::ArrayIndex.new(
        index => RakuAST::SemiList.new(.&expression)
    )
}

sub call(Str:D $id, :@args) is export {
    my RakuAST::Name $name = $id.&name;
    my RakuAST::ArgList $args .= new(|@args)
        if @args;
    RakuAST::Call::Method.new: :$name, :$args;
}

multi sub postfix($operand, Str:D $operator) {
    $operand.&postfix: RakuAST::Postfix.new(:$operator);
}

multi sub postfix($operand, $postfix) {
    RakuAST::ApplyPostfix.new(
        :$operand, :$postfix
    )
}

sub unseen(Str:D $var) is export {
    my RakuAST::Var $operand = $var.&lexical;
    my RakuAST::Blockoid $body .= new(
        RakuAST::StatementList.new(
            expression $operand.&postfix('++')
        )
    );
    my RakuAST::Block $block .= new: :$body;
    RakuAST::Regex::Assertion::PredicateBlock.new(
        :$block, :negated,
    )
 }

multi sub compile(Str:D :$keyw!) {
    group conjunct $keyw.&lit-ws, 'keyw'.&assertion.&ws;
}

multi sub compile(Str:D() :$num!) {
    conjunct $num.&lit-ws, 'number'.&assertion;
}

sub choice(@lits, RakuAST::Regex $term2) {
    my RakuAST::Regex $term1 = @lits == 1 ?? @lits[0] !! @lits.&alt.&group;
    conjunct($term1, $term2);
}

multi sub compile(Str:D :$rule!) {
    $rule.&assertion;
}

multi sub compile(Str:D :at-rule($rule)!) {
    my $at-rule = 'at-rule-' ~ $rule;
    ('@'.&lit'r, $at-rule.&assertion).&seq;
}

multi sub compile(:@keywords!) {
    choice @keywords.map(&lit-ws), 'keyw'.&assertion.&ws;
}

multi sub compile(:@numbers!) {
    choice @numbers.map(&lit-ws), 'number'.&assertion;
}

sub lit-ws(Str:D() $_) is export { .&lit'r.&ws }

multi sub compile(Str:D :$op! where $_ eq ',' && $*IN-PROTO) {
    $op.&lit'r
}
multi sub compile(Str:D :lit($_)!) { .&lit'r }
multi sub compile(Str:D :$op!) {
    my RakuAST::ArgList $args = $op.&arg;
    'op'.&assertion(:$args);
}

multi sub compile(:@alt!)   { @alt.map(&compile).map(&ws).&seq(:alt) }
multi sub compile(:@seq!)   { @seq.map(&compile).map(&ws).&seq }
multi sub compile(:$group!) { $group.&compile.&group }

multi sub compile(:required(@combo)!) {
    compile(:@combo, :required);
}

multi sub quantified($atom, '!') {
    # todo. One of the children must be present
    $atom;
}
multi sub quantified($atom, $_, *%opt) {
    %opt<separator> //= ','.&op.&quantified('?').&ws if .tail ~~ ',';
    my RakuAST::Regex::Quantifier $quantifier = .&quant;
    RakuAST::Regex::QuantifiedAtom.new: :$atom, :$quantifier, |%opt;
}

multi sub compile(:@combo!, Bool :$required) {
     my @atoms = @combo.map: {
        my \id = $*VAR++;
        my $desigilname = id.&name;
        my RakuAST::VarDeclaration::Simple $decl .= new(
            :sigil('$*'), :$desigilname,
        );
        my RakuAST::Regex::Statement $unseen-var-decl .= new: $decl.&expression;
        my RakuAST::Regex::Assertion $unseen-assertion = ('$*'~id).&unseen;
        my RakuAST::Regex $term = .&compile;
        [$term.&ws, $unseen-var-decl, $unseen-assertion].&seq;
    }
    my $atom = @atoms == 1 ?? @atoms.head !! @atoms.&seq(:alt).&group;
    my UInt $n = +@combo;

    my $quant = $required ?? [$n, $n] !! '+';
    $atom.&quantified: $quant;
}

multi sub compile(Str:D :func($rule)!, |c) {
    compile :$rule, |c;
}

multi sub compile(:%proto! ( :$func!, *%) ) {
    # nb: prototype has been saved in %.actions.funcs
    compile :$func;
}

multi sub compile(:%signature! ( :@args! is copy ) ) {
    my @seq;
    my @optional = @args.pop.value.List
       if @args.tail ~~ Pair && @args.tail.key ~~ 'optional';
    for @args {
        @seq.push: ','.&lit-ws if @seq;
        @seq.push: .&compile.&ws;
    }
    if @optional {
        # expand shorthand for optional trailing parameters: 
        # a, b?, c? ... -> a [',' b [',' c ... ]? ]?
        my $opt := [','.&lit-ws, @optional.pop.&compile.&ws].&group.&quantified('?').&ws;
        while @optional {
            $opt := [','.&lit-ws, (@optional.pop.&compile.&ws, $opt).&seq].&group.&quantified('?').&ws;
        }
        @seq.append: $opt;
    }

    @seq == 1 ?? @seq[0] !! @seq.&seq;
}
multi sub compile(:%signature!) { compile |%signature }

multi sub compile(:%paren! (:%signature!)) {
    ['('.&op.&ws, (:%signature).&compile, ')'.&op.&ws].&seq;
}

multi sub compile(:%func-spec! ( :$func!, :$rule=$func, :%signature!, :$synopsis!) ) {

    my $*IN-PROTO = True;
    my constant Usage =  RakuAST::Regex::Assertion::Named::Args.new(
        name      => 'usage'.&name,
        args      => RakuAST::ArgList.new(
            RakuAST::Var::Compiler::Routine.new.&postfix('WHY'.&call),
        ),
        :capturing
    );
    my $args = [(:%signature).&compile.&ws, Usage].&seq(:alt).&ws.&group;
    my $body = ['i'.&modifier,
                ($func ~ '(').&lit-ws, $args.&ws, ')'.&lit'r].&seq.&ws;
    my Str $leading = $_ ~ "\n" given $synopsis;
    $rule.&name.&rule($body).declarator-docs(:$leading);
}

multi sub compile($arg) { compile |$arg }

method compile-grammar(@grammar-id, Str :$scope = 'our', Bool :$role) {
    my $*ACTIONS = $.actions;
    my $*IN-PROTO = False;
    my RakuAST::Name $name = @grammar-id.&name;
    my @compiled = flat @.defs.map: { my $*VAR = 'A'; .&compile};
    my RakuAST::StatementList $statements .= new: |@compiled;
    my RakuAST::Blockoid $block .= new: $statements;

    if $role {
        my RakuAST::RoleBody $body  .= new: :body($block);
        RakuAST::Role.new(
            :$name,
            :$body,
            :$scope,
        );
    }
    else {
        my RakuAST::Block $body .= new: :body($block);

        RakuAST::Grammar.new(
            :$name,
            :$body,
            :$scope,
        );
    }
}
