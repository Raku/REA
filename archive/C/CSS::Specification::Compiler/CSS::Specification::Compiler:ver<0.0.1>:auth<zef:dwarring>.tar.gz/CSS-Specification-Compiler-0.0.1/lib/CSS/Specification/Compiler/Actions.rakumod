unit role CSS::Specification::Compiler::Actions;

use CSS::Specification::Compiler::Util;

method actions { ... }
method defs { ... }

method compile-actions(@actions-id, Str :$scope = 'our', Bool :$role) {
    my RakuAST::Method @methods = self!actions-methods;
    my RakuAST::Statement::Expression @expressions = @methods.map(&expression);
    my RakuAST::StatementList $statements = @expressions.&statements;
    my RakuAST::Blockoid $body .= new: $statements;
    my RakuAST::Name $name = @actions-id.&name;
    $role
        ?? RakuAST::Role.new( :$name, :body(RakuAST::RoleBody.new: :$body), :$scope)
        !! RakuAST::Class.new(:$name, :body(RakuAST::Block.new: :$body), :$scope );
}

method link-actions(@group-id, @modules, Str :$scope = 'our') {
    my RakuAST::Name @module-names = @modules.map(&name);
    my RakuAST::Statement @used = @module-names.map: -> $module-name { RakuAST::Statement::Use.new: :$module-name }
    my RakuAST::Trait::Is @traits =  @module-names.map: -> $name {
        RakuAST::Trait::Is.new: :$name;
    }
    my RakuAST::Name $name = @group-id.&name;
    my RakuAST::Blockoid $body .= new: @used.&statements;
    RakuAST::Class.new(:$name, :$scope, :$body, :@traits );
}

sub call-make-func(Str $name) {
    my RakuAST::StrLiteral $lit = $name.&lit's;
    my RakuAST::QuotedString $qstr .= new: :segments($lit,);
    RakuAST::Blockoid.new(
        RakuAST::Var::Attribute::Public.new(
            :name('$.make-func'),
            args => RakuAST::ArgList.new(
                $qstr,
                RakuAST::Var::Lexical.new("\$/")
            )
        ).&expression.&statements
    );

}

sub compile-build-action(Str $action) {
    RakuAST::Blockoid.new(
        RakuAST::Call::Name::WithoutParentheses.new(
            name => "make".&name,
            args => RakuAST::ArgList.new(
                RakuAST::ApplyPostfix.new(
                    operand => RakuAST::Var::Attribute::Public.new(
                        name => "\$.build"
                    ),
                    postfix => RakuAST::Call::Method.new(
                        name => $action.&name,
                        args => RakuAST::ArgList.new(
                            RakuAST::Var::Lexical.new("\$/")
                        )
                    )
                )
            )
        ).&expression.&statements
    );
}

sub compile-rule(Str $id) {
    RakuAST::Blockoid.new(
        RakuAST::Call::Name::WithoutParentheses.new(
            name => "make".&name,
            args => RakuAST::ArgList.new(
                RakuAST::ApplyPostfix.new(
                    operand => RakuAST::Var::NamedCapture.new(
                        RakuAST::QuotedString.new(
                            processors => <words val>,
                            segments   => (
                                $id.&lit's,
                            )
                        )
                    ),
                    postfix => RakuAST::Call::Method.new(
                        name => "ast".&name,
                    )
                )
            )
        ).&expression.&statements
    );
}

multi sub compile-def(:%rule-spec! (:$rule!, :$spec!, *%), :$signature!) {
    my RakuAST::Name $name = $rule.&name;
    my RakuAST::Blockoid $body = 'rule'.&compile-build-action;
    [ RakuAST::Method.new(:$name, :$signature, :$body), ]
}
multi sub compile-def(:%at-rule-spec! (:at-rule($sym)!, *%), :$signature!) {
    my $proto-name = "at-rule:sym<$sym>".&name;
    my $at-rule = 'at-rule-' ~ $sym;
    my $body = $at-rule.&compile-rule;
    my RakuAST::Name $name = $at-rule.&name;
    my RakuAST::Blockoid $at-rule-body = 'at-rule'.&compile-build-action;

    [ RakuAST::Method.new(name => $proto-name, :$signature, :$body),
      RakuAST::Method.new(:$name, :$signature, body => $at-rule-body) ]
}
multi sub compile-def( :%func-spec! (:$rule!, :$func!, *%), :$signature!) {
    my RakuAST::Name $name = $rule.&name;
    my RakuAST::Blockoid $body = $func.&call-make-func;
    [ RakuAST::Method.new(:$name, :$signature, :$body), ]
}
multi sub compile-def(:%func-spec!, :signature($)) { [] }
multi sub compile-def(:%prop-spec!, :signature($)) { [] }

method !actions-methods {
    my RakuAST::Method @methods;

    my RakuAST::Signature $signature .= new(
        :parameters[ '$/'.&param ]
    );

    @methods.append: compile-def(|$_, :$signature) for @.defs;

    for $.actions.funcs.keys.sort {
        my $name = .&name;
        my $body = .&call-make-func;
        @methods.push: RakuAST::Method.new: :$name, :$signature, :$body;
    }

    @methods;
}
