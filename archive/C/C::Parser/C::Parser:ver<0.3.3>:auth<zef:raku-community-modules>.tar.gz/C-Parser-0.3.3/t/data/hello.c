int puts(const char *);
int putif(const char *, int, float);

int main() {
    puts("Hello World!");
    return 0;
}
