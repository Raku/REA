unit class Foo::Bar::Baz;

method qux { 42 }
