[![Actions Status](https://github.com/FCO/CSS-Nested/actions/workflows/test.yml/badge.svg)](https://github.com/FCO/CSS-Nested/actions)

NAME
====

CSS::Nested - CSS::Grammar, but nested

SYNOPSIS
========

```raku
use CSS::Nested;
```

DESCRIPTION
===========

CSS::Nested is CSS, but nested

Still very early stage of development. It has no tests yet!

AUTHOR
======

Fernando Corrêa de Oliveira <fco@cpan.org>

COPYRIGHT AND LICENSE
=====================

Copyright 2025 Fernando Corrêa de Oliveira

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

