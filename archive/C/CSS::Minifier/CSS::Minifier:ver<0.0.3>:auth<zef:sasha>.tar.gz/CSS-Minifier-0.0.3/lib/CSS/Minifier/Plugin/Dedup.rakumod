use CSS::Stylesheet;
use CSS::Ruleset;
use CSS::Minifier::Plugin;
use CSS::Minifier::Util;

class CSS::Minifier::Plugin::Dedup:ver<0.0.3>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'dedup' }

    method run(CSS::Stylesheet $stylesheet --> Nil) {
        self!dedup-rules($stylesheet);
        self!dedup-font-face($stylesheet);
    }

    method !dedup-rules(CSS::Stylesheet $stylesheet) {
        my %seen;
        my @kept;

        for $stylesheet.rules -> $rule {
            unless $rule.properties {
                @kept.push: $rule;
                next;
            }
            my $sel-key = $rule.selectors.xpath;
            my $prop-key = $rule.properties.Str(:optimize);
            my $media-key = media-key($stylesheet, $rule);
            my $key = $sel-key ~ "\0" ~ $prop-key ~ "\0" ~ $media-key;
            @kept.push: $rule unless %seen{$key}++;
        }

        $stylesheet.rules = @kept;
    }

    method !dedup-font-face(CSS::Stylesheet $stylesheet) {
        my %seen;
        my @kept;

        for $stylesheet.font-face -> $ff {
            next unless $ff.font-family;
            # NB: CSS::Font::Descriptor uses .weight/.style/.stretch
            # (not .font-weight/.font-style/.font-stretch — those don't exist)
            my $key = join("\0",
                $ff.font-family.raku,
                $ff.src.raku,
                $ff.weight.raku,
                $ff.style.raku,
                $ff.stretch.raku,
            );
            @kept.push: $ff unless %seen{$key}++;
        }

        $stylesheet.font-face = @kept;
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Dedup - Duplicate removal plugin

=head1 DESCRIPTION

Removes duplicate CSS rulesets and C<@font-face> blocks at level 2.

=head3 Ruleset dedup

Two rulesets are considered duplicates if they have the same selectors
(via C<.selectors.xpath>) and identical property sets (via
C<.Str(:optimize)>). Only the first occurrence is kept.

=head3 @font-face dedup

Two C<@font-face> blocks are considered duplicates if their
C<font-family>, C<src>, C<weight>, C<style>, and C<stretch> values
match. Only the first occurrence is kept.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
