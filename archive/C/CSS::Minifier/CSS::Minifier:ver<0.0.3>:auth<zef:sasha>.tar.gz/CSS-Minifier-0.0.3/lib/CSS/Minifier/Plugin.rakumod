use CSS::Stylesheet;

role CSS::Minifier::Plugin:ver<0.0.3>:auth<zef:sasha> {
    method name(--> Str) { ... }
    method run(CSS::Stylesheet $stylesheet --> Nil) { ... }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin - Plugin role for CSS minification passes

=head1 DESCRIPTION

Plugins perform individual optimisation passes on a parsed C<CSS::Stylesheet>.
Each plugin implements the C<run> method which receives the stylesheet and
mutates it in place. Plugins are registered in a L<CSS::Minifier::Pipeline>
and run sequentially.

=head2 Methods

=item C<name> - Returns a unique string identifier for the plugin.
=item C<run($stylesheet)> - Applies the plugin's transformation.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
