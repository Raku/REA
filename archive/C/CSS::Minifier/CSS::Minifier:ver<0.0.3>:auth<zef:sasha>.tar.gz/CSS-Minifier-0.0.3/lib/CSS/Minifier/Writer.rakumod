use CSS::Writer;

class CSS::Minifier::Writer:ver<0.0.3>:auth<zef:sasha> is CSS::Writer {
    has Str $.sep = '';

    method nl returns Str { '' }

    multi method write-num( 1, 'em' ) { '1em' }
    multi method write-num( 1, 'ex' ) { '1ex' }

    method write-declarations(List $_) {
        my $decls = $.write-declaration-list($_);
        # Assumes final ';' is the declaration-list separator, not part of a value
        $decls ~~ s/';' \s* $// or die "cannot find trailing ';' in declaration list; CSS::Writer format may have changed";
        '{' ~ $decls ~ '}';
    }

    method write-stylesheet(List $_) {
        $.write: $_, :sep($.sep);
    }

    method write-ruleset(% (:$selectors, :$declarations), |c) {
        $.write-selectors($selectors) ~ $.write-declarations($declarations);
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Writer - Compact CSS writer

=head1 DESCRIPTION

Subclass of L<CSS::Writer> that produces minified CSS output:

=item Empty newlines (C<nl> returns C<''>)
=item No trailing semicolon before closing brace
=item No space before opening brace
=item Configurable C<$.sep> between rulesets (default empty for compact output)

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
