unit class CSS::Minifier:ver<0.0.3>:auth<zef:sasha>;

use CSS::Stylesheet;
use CSS::Minifier::Pipeline;
use CSS::Minifier::Plugin::Values;
use CSS::Minifier::Plugin::Dedup;
use CSS::Minifier::Plugin::Merging;
use CSS::Minifier::Util;
use CSS::Minifier::Writer;
use CSS::Selector::To::XPath;
CSS::Selector::To::XPath.^add_method('xpath-pseudo-elem', method (Str $name) { $name });

my constant %SAFE-AT-RULES = Set.new: <@media @page @font-face>;
my constant %SHORTHAND = Map.new(
    # CSS::Properties consolidates these longhands to shorthands at parse time
    'background-color'    => 'background',
    'background-image'    => 'background',
    'background-repeat'   => 'background',
    'background-position' => 'background',
    'background-attachment' => 'background',
    'background-clip'     => 'background',
    'background-origin'   => 'background',
    'background-size'     => 'background',
    'border-color'     => 'border',
    'border-style'     => 'border',
    'border-width'     => 'border',
    'border-top-color'   => 'border-top',
    'border-top-style'   => 'border-top',
    'border-top-width'   => 'border-top',
    'border-right-color'   => 'border-right',
    'border-right-style'   => 'border-right',
    'border-right-width'   => 'border-right',
    'border-bottom-color'   => 'border-bottom',
    'border-bottom-style'   => 'border-bottom',
    'border-bottom-width'   => 'border-bottom',
    'border-left-color'   => 'border-left',
    'border-left-style'   => 'border-left',
    'border-left-width'   => 'border-left',
    'outline-color' => 'outline',
    'outline-style' => 'outline',
    'outline-width' => 'outline',
    'list-style-type'     => 'list-style',
    'list-style-position' => 'list-style',
    'list-style-image'    => 'list-style',
    'font-style'      => 'font',
    'font-weight'     => 'font',
    'font-stretch'    => 'font',
    'font-size'       => 'font',
    'line-height'     => 'font',
    'font-family'     => 'font',
    'margin-top'      => 'margin',
    'margin-right'    => 'margin',
    'margin-bottom'   => 'margin',
    'margin-left'     => 'margin',
    'padding-top'     => 'padding',
    'padding-right'   => 'padding',
    'padding-bottom'  => 'padding',
    'padding-left'    => 'padding',
);

# note: CSS::Stylesheet strips all comments at parse time, so we extract
# /*! */ license comments from the raw string before parsing.
method minify(Str $css, :$level = 1, Bool :$verbose = False, Bool :$preserve-licenses,
    Bool :$color-masks = True, Bool :$preserve-unknown = True, :@extra-plugins, *%opts) returns Str {
    my @licenses = self!extract-licenses($css) if $preserve-licenses;
    my @braceless;
    my %unknown-decls;
    my @order;
    my $walk-css = '';
    {
        my $i = 0;
        while $i < $css.chars {
            given $css.substr($i, 1) {
                when '@' {
                    if $css.substr($i) ~~ / ^ \@ (import|charset|namespace) / {
                        my $end = find-semicolon($css, $i + $/.chars);
                        if $end.defined {
                            @braceless.push: $css.substr($i, $end - $i + 1);
                            $i = $end + 1;
                            next;
                        }
                    }
                }
                when '"'  { my $e = skip-quoted($css, $i, '"');  $walk-css ~= $css.substr($i, $e - $i) if $preserve-unknown; $i = $e; next }
                when "'"  { my $e = skip-quoted($css, $i, "'");  $walk-css ~= $css.substr($i, $e - $i) if $preserve-unknown; $i = $e; next }
                when '/'  { if $css.substr($i, 2) eq '/*' {
                                $i = ($css.index('*/', $i+2) // $css.chars) + 2; next
                            } }
            }
            $walk-css ~= $css.substr($i, 1) if $preserve-unknown;
            $i++;
        }
    }
    $walk-css = $css unless $preserve-unknown;

    self!walk-decls($walk-css, '', %unknown-decls, @order) if $preserve-unknown;

    my $stylesheet;
    my Pair $ast;
    {
        temp $*ERR = $preserve-unknown
            ?? class { method print(|) { }; method say(|) { }; method note(|) { } }.new
            !! $*ERR;
        $stylesheet = CSS::Stylesheet.parse($css);

        my @plugins = self!plugins-for($level);
        for @extra-plugins -> $p {
            die "Extra plugin {$p.^name} does not implement CSS::Minifier::Plugin"
                unless $p ~~ CSS::Minifier::Plugin;
        }
        @plugins.append: @extra-plugins;

        my CSS::Minifier::Pipeline $pipeline .= new:
            :$verbose,
            :@plugins;

        $pipeline.run($stylesheet);

        $ast = $stylesheet.ast(:optimize);
    }
    my CSS::Minifier::Writer $writer .= new:
        :!pretty,
        :$color-masks,
        |%opts;

    my $output = $writer.write($ast);
    $output = self!merge-decls($output, %unknown-decls, @order, :$color-masks) if $preserve-unknown;
    $output = self!normalize-all-decls($output, :$color-masks);
    $output = @licenses.join("\n") ~ "\n" ~ $output if @licenses;
    $output = @braceless.join("\n") ~ ($output ?? "\n" ~ $output !! '') if @braceless;
    $output;
}

# Extract declarations from raw CSS before parsing.
# Uses recursive brace-counting to handle at-rules like @media, @supports,
# @container, @layer, etc. — any at-rule with a { } block.
# When $unsafe is True (inside an at-rule CSS::Stylesheet drops, e.g.
# @keyframes, @supports), ALL declarations are captured to prevent data
# loss. When False (top-level or inside @media/@page/@font-face), all
# declarations are captured (the known-props filter was removed to catch
# CSS3 values that the pipeline drops). The %SHORTHAND map in
# !prop-exists prevents re-injecting longhands already consolidated to
# shorthands by CSS::Properties.
# Returns a Map of qualified-selector => [(property => value), ...].
method !walk-decls(Str $s, Str $prefix, %by-sel, @order, Bool :$unsafe = False) {
    my $i = 0;
    my $len = $s.chars;

    while $i < $len {
        given $s.substr($i,1) {
            when /\s/ { $i++; next }
            when '/'  { if $s.substr($i,2) eq '/*' {
                            $i = ($s.index('*/', $i+2) // $len) + 2; next
                        } }
            when '"'  { $i = skip-quoted($s, $i, '"'); next }
            when "'"  { $i = skip-quoted($s, $i, "'"); next }
            when '}'  { $i++; next }
        }

        my $brace = $i;
        while $brace < $len {
            given $s.substr($brace,1) {
                when '{' { last }
                when '"' { $brace = skip-quoted($s, $brace, '"') }
                when "'" { $brace = skip-quoted($s, $brace, "'") }
                when '/' { if $s.substr($brace,2) eq '/*' {
                               $brace = ($s.index('*/', $brace+2) // $len) + 2
                           } else { $brace++ } }
                default  { $brace++ }
            }
        }
        last if $brace >= $len;

        my $raw = $s.substr($i, $brace - $i).trim;
        $raw ~~ s:g/ \s+ / /;
        my $end = matching-close($s, $brace);

        if $raw.starts-with('@') {
            my $at-name = $raw.split(/\s+/)[0];
            my $new-unsafe = $unsafe || $at-name ∉ %SAFE-AT-RULES;
            my $body = $s.substr($brace+1, $end - $brace - 1);
            self!walk-decls($body,
                           $prefix ~ $raw ~ ' ', %by-sel, @order, :unsafe($new-unsafe));
            # Declaration-only at-rules (e.g. @font-face) have no { } in body.
            # Capture their declarations directly since the recursive walk
            # finds nothing.
            if !has-brace($body) {
                my @decls = parse-body($body);
                if @decls {
                    my $qual = $prefix ~ $raw;
                    # Use a NUL-suffixed counter to disambiguate multiple
                    # blocks of the same at-rule (e.g. multiple @font-face).
                    # The counter is stripped back off in !prop-exists and
                    # !merge-qualified.
                    my $n = +%by-sel.keys.grep({ $_ eq $qual || .starts-with("$qual\x[0]") });
                    my $unique-qual = $n ?? "$qual\x[0]$n" !! $qual;
                    unless %by-sel{$unique-qual}:exists { @order.push: $unique-qual }
                    %by-sel{$unique-qual}.append(@decls);
                }
            }
        }
        elsif $raw {
            my $raw-sel = $raw.index(',')
                ?? self!normalize-selector($raw)
                !! $raw;
            my $qual = $prefix ?? "$prefix\{$raw-sel\}" !! $raw-sel;
            my $body = $s.substr($brace+1, $end - $brace - 1);
            my @decls = parse-body($body);
            if @decls {
                unless %by-sel{$qual}:exists { @order.push: $qual }
                %by-sel{$qual}.append(@decls);
            }
        }

        $i = $end + 1;
    }
}

sub matching-close(Str $s, Int $start --> Int) {
    my $depth = 1;
    my $i = $start + 1;
    while $i < $s.chars && $depth > 0 {
        given $s.substr($i, 1) {
            when '{'  { $depth++; $i++ }
            when '}'  { $depth--; $i++ }
            when '"'  { $i = skip-quoted($s, $i, '"') }
            when "'"  { $i = skip-quoted($s, $i, "'") }
            when '/'  { if $s.substr($i,2) eq '/*' {
                            $i = ($s.index('*/', $i+2) // $s.chars) + 2
                        } else { $i++ } }
            default   { $i++ }
        }
    }
    $i - 1
}

sub has-brace(Str $s --> Bool) {
    my $i = 0;
    while $i < $s.chars {
        given $s.substr($i, 1) {
            when '{' { return True }
            when '"' { $i = skip-quoted($s, $i, '"'); next }
            when "'" { $i = skip-quoted($s, $i, "'"); next }
        }
        $i++;
    }
    False
}

sub find-semicolon(Str $s, Int $start --> Int) {
    my $i = $start;
    my $depth = 0;
    while $i < $s.chars {
        given $s.substr($i, 1) {
            when '('  { $depth++ }
            when ')'  { $depth-- }
            when '"'  { $i = skip-quoted($s, $i, '"');  next }
            when "'"  { $i = skip-quoted($s, $i, "'");  next }
            when '/'  { if $s.substr($i, 2) eq '/*' {
                            $i = ($s.index('*/', $i+2) // $s.chars) + 2; next
                        } }
            when ';'  { return $i if $depth == 0 }
        }
        $i++;
    }
    Int
}

sub skip-quoted(Str $s, Int $i, Str $q --> Int) {
    my $pos = $i + 1;
    while $pos < $s.chars {
        given $s.substr($pos, 1) {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $s.chars
}

# Parse declarations from the body of a ruleset or declaration-only at-rule.
# Handles ; and } inside strings, parens, and /* */ comments by tracking
# depth — unlike the naive <-[:;]>+ / <-[;}]>+ regex.
sub parse-body(Str $body --> List) {
    my @decls;
    my $i = 0;
    my $len = $body.chars;

    while $i < $len {
        # Skip whitespace, semicolons, and comments between declarations.
        while $i < $len {
            given $body.substr($i,1) {
                when /\s/     { $i++ }
                when ';'      { $i++ }
                when '}'      { $i++; return @decls }
                when '/'      { if $body.substr($i,2) eq '/*' {
                                    $i = ($body.index('*/', $i+2) // $len) + 2
                                } else { last } }
                default       { last }
            }
        }
        last if $i >= $len;

        # Parse key — collect until ':' at paren-depth 0.
        my $key = '';
        my $depth = 0;
        while $i < $len {
            given $body.substr($i,1) {
                when '('   { $depth++; $key ~= '('; $i++ }
                when ')'   { $depth--;  $key ~= ')'; $i++ }
                when ':'   { $i++; last if $depth == 0; $key ~= ':' }
                when '"'   { my $end = skip-quoted($body, $i, '"');  $key ~= $body.substr($i, $end - $i); $i = $end }
                when "'"   { my $end = skip-quoted($body, $i, "'");  $key ~= $body.substr($i, $end - $i); $i = $end }
                when '/'   { if $body.substr($i,2) eq '/*' {
                                 my $end = ($body.index('*/', $i+2) // $len) + 2; $i = $end
                             } else { $key ~= '/'; $i++ } }
                default    { $key ~= $body.substr($i,1); $i++ }
            }
        }
        last if $i >= $len;

        # Skip whitespace after colon.
        while $i < $len && $body.substr($i,1) ~~ /\s/ {
            $i++;
        }

        # Parse value — collect until ';' or '}' at paren-depth 0.
        my $value = '';
        $depth = 0;
        while $i < $len {
            given $body.substr($i,1) {
                when '('   { $depth++; $value ~= '('; $i++ }
                when ')'   { $depth--;  $value ~= ')'; $i++ }
                when ';'   { $i++; last if $depth == 0; $value ~= ';' }
                when '}'   { last if $depth == 0; $value ~= '}'; $i++ }
                when '"'   { my $end = skip-quoted($body, $i, '"');  $value ~= $body.substr($i, $end - $i); $i = $end }
                when "'"   { my $end = skip-quoted($body, $i, "'");  $value ~= $body.substr($i, $end - $i); $i = $end }
                when '/'   { if $body.substr($i,2) eq '/*' {
                                 my $end = ($body.index('*/', $i+2) // $len) + 2; $i = $end
                             } else { $value ~= '/'; $i++ } }
                default    { $value ~= $body.substr($i,1); $i++ }
            }
        }

        @decls.push: $key.trim => $value.trim;
    }

    @decls
}

# Extract /*! */ license comments from raw CSS, correctly skipping over
# quoted strings and regular /* comments */.
method !extract-licenses(Str $s --> List) {
    my @licenses;
    my $i = 0;
    my $len = $s.chars;
    my $buf = '';
    my $in-license = False;

    while $i < $len {
        given $s.substr($i, 1) {
            when '"'  { $i = skip-quoted($s, $i, '"') }
            when "'"  { $i = skip-quoted($s, $i, "'") }
            when '/'  {
                if $s.substr($i,2) eq '/*' {
                    if $s.substr($i+2,1) eq '!' {
                        $in-license = True;
                        $buf = '/*!';
                        $i += 3;
                    } else {
                        $i = ($s.index('*/', $i+2) // $len) + 2;
                    }
                } else {
                    $i++;
                }
            }
            when '*'  {
                if $s.substr($i,2) eq '*/' && $in-license {
                    $buf ~= '*/';
                    @licenses.push: $buf;
                    $in-license = False;
                    $i += 2;
                } else {
                    $i++;
                }
            }
            default  {
                $buf ~= $s.substr($i,1) if $in-license;
                $i++;
            }
        }
    }

    @licenses
}

# Normalize a media query prelude to match pipeline output:
# add space after colon in media features: (max-width:700px) → (max-width: 700px)
sub normalize-prelude(Str $p --> Str) {
    $p ~~ s:g/ \(  (<-[):]>+) ':' (\S) /({$0}: {$1})/;
    $p;
}

# Find the position of the opening brace for the Nth (0-indexed)
# at-rule block matching $prelude, accounting for the writer's
# optional space before {. Returns the index of {, or Nil.
method !find-at-rule-block(Str $out, Str $prelude, Int :$skip = 0 --> Int) {
    my $at = 0;
    my $count = 0;
    my $brace;
    my $norm-prelude = $prelude ~~ /\(.*:.*\)/ ?? normalize-prelude($prelude) !! '';
    loop {
        my $pos = $out.index($prelude ~ '{', $at)
               // $out.index($prelude ~ ' {', $at);
        if !$pos.defined && $norm-prelude {
            $pos = $out.index($norm-prelude ~ '{', $at)
                // $out.index($norm-prelude ~ ' {', $at);
        }
        return Nil unless $pos.defined;
        $brace = $pos + $out.substr($pos).index('{');
        last if $count == $skip;
        $count++;
        $at = $brace + 1;
    }
    $brace;
}

# Scoped property-exists check: return True if $key: appears within
# the ruleset matching $qual in $out.
# Check if $key:~ (or its shorthand) appears within the ruleset body
# at the given brace position in $out.
method !check-key-in-body(Str $out, Int $brace-pos, Str $key --> Bool) {
    my $end = matching-close($out, $brace-pos);
    my $body = $out.substr($brace-pos + 1, $end - $brace-pos - 1);
    so $body.contains($key ~ ':')
        || %SHORTHAND{$key} && $body.contains(%SHORTHAND{$key} ~ ':');
}

method !prop-exists(Str $out, Str $qual, Str $key --> Bool) {
    if $qual.starts-with('@') {
        my $open = $qual.index('{');
        if !$open.defined {
            # Declaration-only at-rule (e.g. @font-face).
            # Extract NUL counter to check the correct Nth block.
            # Fall back to block 0 when the Nth block was deduped away.
            my $prelude = $qual.subst(/\x[0]\d+$/, '');
            my $n = 0;
            $n = +$0 if $qual ~~ /\x[0](\d+)$/;
            my $pos = self!find-at-rule-block($out, $prelude, :skip($n));
            $pos //= self!find-at-rule-block($out, $prelude);
            return False unless $pos.defined;
            return self!check-key-in-body($out, $pos, $key);
        }
        my $close = $qual.rindex('}') // return False;
        # Normalise quotes so pre-scanned inner selector (with "dark")
        # matches pipeline output (with 'dark').
        my $nqual = $qual.subst('"', "'", :g);
        my $prelude = $nqual.substr(0, $open).trim;
        my $inner   = $nqual.substr($open+1, $close - $open - 1).trim;
        my $pos = self!find-at-rule-block($out, $prelude);
        return False unless $pos.defined;
        my $block-end = matching-close($out, $pos);
        my $block-body = $out.substr($pos + 1, $block-end - $pos - 1);

        # Try exact match for the inner selector
        my $inner-head = $inner ~ '{';
        my $inner-pos = $block-body.index($inner-head);
        if $inner-pos.defined {
            return self!check-key-in-body($block-body, $inner-pos, $key);
        }
        # Fallback: inner selector may be part of a merged group
        $inner-pos = $block-body.index(',' ~ $inner)
                  // $block-body.index($inner ~ ',');
        if $inner-pos.defined {
            my $brace = $block-body.index('{', $inner-pos);
            return self!check-key-in-body($block-body, $brace, $key) if $brace.defined;
        }
        return False;
    }
    else {
        # Normalise quotes so pre-scanned selectors (with "dark") match
        # pipeline output (with 'dark').
        my $nqual = $qual.subst('"', "'", :g);
        # Try all exact matches: $nqual followed by {, scanning past each
        # ruleset so duplicate-selector rulesets at level 1 are all checked.
        my $at = 0;
        loop {
            my $pos = $out.index($nqual ~ '{', $at);
            last unless $pos.defined;
            # Boundary guard: $nqual must be the full selector, not a suffix
            # (e.g. #header{ should not match inside [data-bs-theme='dark'] #header{).
            # Walk backwards past whitespace to find the true boundary character.
            my $b = $pos - 1;
            $b-- while $b >= 0 && $out.substr($b, 1) ~~ /\s/;
            if $b < 0 || $out.substr($b, 1) eq '}' || $out.substr($b, 1) eq ',' {
                my $brace-pos = $pos + $nqual.chars;
                return True if self!check-key-in-body($out, $brace-pos, $key);
            }
            $at = matching-close($out, $pos + $nqual.chars) + 1;
        }
        # Fallback: $nqual may be first in a merged group (e.g. "h1,h2{")
        # Note: substring-based matching, so first "{$pos, ...}" match wins.
        # If $nqual is short (e.g. "a") the "a," hit could be in an unrelated
        # selector group. Worst case: a missed re-injection (content loss).
        $at = 0;
        loop {
            my $pos = $out.index($nqual ~ ',', $at);
            last unless $pos.defined;
            # Walk backwards past whitespace to find the true boundary character.
            my $b = $pos - 1;
            $b-- while $b >= 0 && $out.substr($b, 1) ~~ /\s/;
            if $b < 0 || $out.substr($b, 1) eq '}' || $out.substr($b, 1) eq ',' {
                my $brace = $out.index('{', $pos);
                if $brace.defined {
                    return True if self!check-key-in-body($out, $brace, $key);
                    $at = matching-close($out, $brace) + 1;
                    next;
                }
            }
            $at = $pos + 1;
        }
        # Fallback: $nqual may be non-first in a merged group (e.g. "h2" in "h1,h2{")
        $at = 0;
        loop {
            my $pos = $out.index(',' ~ $nqual, $at);
            last unless $pos.defined;
            # Right-side boundary guard: the character after $nqual must be
            # {, whitespace, or , to prevent ,h1 matching inside ,h10{.
            my $after-pos = $pos + 1 + $nqual.chars;
            my $after = $out.substr($after-pos, 1);
            if $after eq '{' || $after eq ' ' || $after eq ',' {
                my $brace = $out.index('{', $pos);
                if $brace.defined {
                    return True if self!check-key-in-body($out, $brace, $key);
                    $at = matching-close($out, $brace) + 1;
                    next;
                }
            }
            $at = $pos + 1;
        }
        return False;
    }
}

# Normalize a selector text to match pipeline output format:
# split by top-level commas, trim parts, join with ', '.
# This prevents re-minification growth when the raw input uses
# comma-separated selectors without spaces (e.g. "h1,h2") that
# the pipeline normalizes to "h1, h2".
method !normalize-selector(Str $sel --> Str) {
    my @parts;
    my $start = 0;
    my $bracket = 0;
    my $paren = 0;
    my $i = 0;
    while $i < $sel.chars {
        given $sel.substr($i, 1) {
            when '[' { $bracket++; $i++ }
            when ']' { $bracket--; $i++ }
            when '(' { $paren++;  $i++ }
            when ')' { $paren--;  $i++ }
            when '"' {
                $i++;
                $i++ while $i < $sel.chars && $sel.substr($i, 1) ne '"';
                $i++ if $i < $sel.chars;
            }
            when "'" {
                $i++;
                $i++ while $i < $sel.chars && $sel.substr($i, 1) ne "'";
                $i++ if $i < $sel.chars;
            }
            when ',' {
                if $bracket == 0 && $paren == 0 {
                    @parts.push: $sel.substr($start, $i - $start).trim;
                    $i++;
                    while $i < $sel.chars && $sel.substr($i, 1) ~~ /\s/ { $i++ }
                    $start = $i;
                } else { $i++ }
            }
            default { $i++ }
        }
    }
    my $last = $sel.substr($start).trim if $start < $sel.chars;
    @parts.push: $last if $last;
    @parts.join(', ');
}

# Strip unsupported pseudo-class functions (:is(), :where(), :has())
# from a selector string, reconstructing what CSS::Stylesheet likely
# produced (it drops these pseudo-classes entirely, keeping everything
# before and after). Handles only top-level selectors (not at-rule wrapped).
method !short-selector(Str $qual --> Str) {
    my $s = $qual;
    my @patterns = <:is( :where( :has(>;
    loop {
        my ($earliest, $pat);
        for @patterns -> $p {
            with $s.index($p) {
                $earliest //= $_;
                $pat = $p if $_ <= $earliest;
            }
        }
        last without $earliest;

        my $depth = 1;
        my $i = $earliest + $pat.chars;
        while $i < $s.chars && $depth > 0 {
            given $s.substr($i, 1) {
                when '(' { $depth++; $i++ }
                when ')' { $depth--; $i++ }
                when '"' { $i = skip-quoted($s, $i, '"') }
                when "'" { $i = skip-quoted($s, $i, "'") }
                default  { $i++ }
            }
        }

        # Concatenate before and after the stripped pseudo-class
        $s = $s.substr(0, $earliest) ~ $s.substr($i);
    }
    $s ~~ s:g/ \s+ / /;
    $s.trim;
}

# Remove all top-level rulesets with the given selector from $result.
# Uses brace-depth tracking to only match at depth 0 (top-level).
method !remove-selector(Str $result is rw, Str $sel) {
    my $search = $sel ~ '{';
    my $depth = 0;
    my $i = 0;
    while $i < $result.chars {
        given $result.substr($i, 1) {
            when '{' {
                my $before = $i - $search.chars;
                $before-- while $before >= 0 && $result.substr($before, 1) ~~ /\s/;
                if $depth == 0 && $i >= $search.chars - 1
                && $result.substr($i - $search.chars + 1, $search.chars) eq $search
                && ($before < 0 || $result.substr($before, 1) eq '}') {
                    my $close = matching-close($result, $i);
                    last without $close;
                    $result.substr-rw($i - $search.chars + 1,
                                      $close - ($i - $search.chars + 1) + 1) = '';
                    $i = max(0, $i - $search.chars);
                    next;
                }
                $depth++;
                $i++;
            }
            when '}' {
                $depth-- if $depth > 0;
                $i++;
            }
            when '"' { $i = skip-quoted($result, $i, '"') }
            when "'" { $i = skip-quoted($result, $i, "'") }
            when '/' { if $result.substr($i,2) eq '/*' {
                           $i = ($result.index('*/', $i+2) // $result.chars) + 2
                       } else { $i++ } }
            default  { $i++ }
        }
    }
}

# Check if $sel appears as a standalone inner selector in any %by-sel key,
# either top-level ($k eq $sel) or inside an at-rule block (ends with {$sel}).
method !has-selector-in(%by-sel, Str $sel --> Bool) {
    so %by-sel.keys.first: -> $k {
        $k eq $sel || $k.match(/ \{ \s* { $sel.quotemeta } \s* \} $ /)
    }
}

# When CSS::MediaQuery transforms a media feature it doesn't recognise
# (e.g. prefers-color-scheme) to 'not all', the pipeline outputs a bogus
# @media not all { ... } block. This method finds that block and replaces
# it with the original media query, using %by-sel to avoid replacing a
# genuine @media not all from the input CSS.
method !replace-bogus-not-all(Str $result is rw, Str $qual, Str $decls, %by-sel --> Bool) {
    return False unless $qual ~~ /^ '@media' \s+ /;

    my $open = $qual.index('{') // return False;
    my $close = $qual.rindex('}') // return False;
    my $nqual = $qual.subst('"', "'", :g);
    my $prelude = $nqual.substr(0, $open).trim;
    my $inner = $nqual.substr($open+1, $close - $open - 1).trim;
    return False if $inner eq '';

    # If the original prelude already exists, normal path works
    return False if self!find-at-rule-block($result, $prelude).defined;

    # Scan for @media not all blocks that might be translations
    my $i = 0;
    while $i < $result.chars {
        my $pos = $result.index('@media not all', $i) // last;

        # Skip if this is part of a longer query (e.g. @media not all and ...)
        my $after = $result.substr($pos + 14, 1);
        next unless $after eq '{' || $after eq ' ';

        my $brace = $result.index('{', $pos) // last;
        my $close-brace = matching-close($result, $brace);
        last unless $close-brace.defined;

        my $body = $result.substr($brace + 1, $close-brace - $brace - 1);

        # Check if this block's inner selector matches our qualifier's inner selector
        if $body.contains($inner ~ '{') {
            # Verify it's not a genuine @media not all from the original CSS
            my $genuine = %by-sel.keys.first: {
                .starts-with('@media not all {') && .contains('{' ~ $inner ~ '}') }
            unless $genuine {
                $result.substr-rw($pos, $close-brace - $pos + 1) =
                    $prelude ~ '{' ~ $inner ~ '{' ~ $decls ~ '}' ~ '}';
                return True;
            }
        }
        $i = $close-brace + 1;
    }

    return False;
}

# Re-inject declarations that were dropped during minification.
# For each qualified selector, checks whether each property appears in the
# output (by name, scoped to the correct ruleset). Missing declarations
# are appended as a new ruleset.
# For at-rule qualified selectors (e.g. @media screen { h1 }), re-injects
# into the existing at-rule block, creating one if missing.
method !merge-decls(Str $out, %by-sel, @order, Bool :$color-masks = True --> Str) {
    my $result = $out;

    # Phase 1: Remove spurious top-level rulesets produced by CSS::Stylesheet
    # dropping unsupported pseudo-class functions (:is(), :where(), :has()).
    # The pipeline generates a ruleset with the TRUNCATED selector; we remove
    # it when %by-sel has no legitimate standalone entry for that prefix.
    # (When a standalone entry exists, the Merging plugin at level 2 already
    #  deduplicates the two rulesets; at level 1 a harmless extra rule remains.)
    for %by-sel.keys -> $qual {
        next if $qual.starts-with('@');
        my $short = self!short-selector($qual);
        next if $short eq $qual;
        unless self!has-selector-in(%by-sel, $short) {
            self!remove-selector($result, $short);
        }
    }

    # Phase 2: Normal re-injection (iterate in order to preserve keyframe selector order)
    for @order -> $qual {
        my @decls = %by-sel{$qual}.list;
        # Dedup the selector list so qualifiers match output after pipeline
        # dedup (e.g. '[a], [a]' → '[a]'). This prevents spurious re-injection
        # when the pipeline removes duplicate selectors from a list.
        my $dqual = $qual;
        if $qual.index(',') {
            my @parts = split-selectors($qual);
            my %seen;
            my @uniq = @parts.grep({ !%seen{$_}++ });
            $dqual = @uniq.join(', ') if @uniq != @parts;
        }
        my @missing;
        for @decls -> (:$key, :$value) {
            @missing.push(self!minify-value($key, $value, :$color-masks))
                unless self!prop-exists($result, $dqual, $key);
        }
        next unless @missing;
        my $joined = @missing.join(';');

        if $qual.starts-with('@') {
            unless self!replace-bogus-not-all($result, $qual, $joined, %by-sel) {
                self!merge-qualified($result, $qual, $joined);
            }
        }
        else {
            $result ~= $dqual ~ '{' ~ $joined ~ '}';
        }
    }
    $result;
}

method !merge-qualified(Str $result is rw, Str $qual, Str $decls) {
    my $open = $qual.index('{');
    if !$open.defined {
        # Declaration-only at-rule (e.g. @font-face, @view-transitions).
        # Extract NUL counter to target the correct Nth block; without
        # suffix (counter=0) inject into the first existing block.
        # Fall back to block 0 when the Nth block was deduped away.
        my $prelude = $qual.subst(/\x[0]\d+$/, '');
        my $n = 0;
        $n = +$0 if $qual ~~ /\x[0](\d+)$/;
        my $pos = self!find-at-rule-block($result, $prelude, :skip($n));
        $pos //= self!find-at-rule-block($result, $prelude);
        if $pos.defined {
            my $close-brace = matching-close($result, $pos);
            my $need-semi = $result.substr($close-brace - 1, 1) eq ';' ?? '' !! ';';
            $result.substr-rw($close-brace, 0) = $need-semi ~ $decls ~ ';';
        }
        else {
            $result ~= $prelude ~ '{' ~ $decls ~ '}';
        }
        return;
    }
    my $close = $qual.rindex('}') // return;
    my $nqual = $qual.subst('"', "'", :g);
    my $prelude = $nqual.substr(0, $open).trim;
    my $inner = $nqual.substr($open+1, $close - $open - 1).trim;

    if my $pos = self!find-at-rule-block($result, $prelude) {
        $result.substr-rw(matching-close($result, $pos), 0) =
            $inner ~ '{' ~ $decls ~ '}';
    }
    else {
        $result ~= $prelude ~ '{' ~ $inner ~ '{' ~ $decls ~ '}' ~ '}';
    }
}

# Normalize a single declaration value for re-injection.
# CSS::Properties can't be used directly since it doesn't apply color-masks
# or font-weight normalization — those are done by the pipeline's Writer and
# Values plugin respectively. Instead, we apply a few targeted normalizations.
method !minify-value(Str $key, Str $value, Bool :$color-masks = True, Bool :$named-colors = True --> Str) {
    my $v = $value;

    # Quote normalization: single quotes are shorter and preferred
    if $v.index('"').defined && !$v.index("'").defined {
        $v ~~ s:g/\"/\'/;
    }

    # Zero-unit removal
    $v ~~ s:g/ <!after \d> 0 (px|em|ex|ch|rem|vh|vw|vmin|vmax|cm|mm|in|pt|pc) /0/;

    # Font-weight normalization
    if $key eq 'font-weight' {
        given $v {
            when 'bold'   { $v = '700' }
            when 'normal' { $v = '400' }
        }
    }

    # Color shortening:
    #   named colors → hex (e.g. red → #F00) — skip when !$named-colors
    #   6-char hex → 3-char (e.g. #aabbcc → #abc)
    if $color-masks {
        state %named =
            red    => '#F00',  maroon => '#800000',  yellow  => '#FF0',
            olive  => '#808000',  green => '#008000',  lime   => '#0F0',
            aqua   => '#0FF',  teal   => '#008080',  blue   => '#00F',
            navy   => '#000080', fuchsia => '#F0F',  purple => '#800080',
            orange => '#FFA500', white  => '#FFF',   silver => '#C0C0C0',
            gray   => '#808080', black  => '#000',
        ;
        $v = %named{$v.lc} if $named-colors && %named{$v.lc}.defined;
        $v ~~ s:g[ <[#]> ( <xdigit> ) $0 ( <xdigit> ) $1 ( <xdigit> ) $2 ] = '#' ~ $0 ~ $1 ~ $2;
    }

    $key ~ ':' ~ $v;
}

# Normalize values + dedup declarations in ALL {…} blocks in the
# output string, catching blocks the pipeline can't reach (e.g.
# @keyframes keyframe blocks, nested at-rules).
method !normalize-all-decls(Str $css, Bool :$color-masks = True --> Str) {
    my $result = '';
    my $i = 0;
    my $len = $css.chars;

    while $i < $len {
        my $ch = $css.substr($i++, 1);

        if $ch eq '"' || $ch eq "'" {
            $result ~= $ch;
            my $q = $ch;
            while $i < $len {
                my $c = $css.substr($i++, 1);
                $result ~= $c;
                last if $c eq $q && $css.substr($i-2, 1) ne '\\';
            }
        }
        elsif $ch eq '{' {
            my $depth = 1;
            my $content = '';
            while $i < $len && $depth > 0 {
                my $c = $css.substr($i++, 1);
                if $c eq '"' || $c eq "'" {
                    $content ~= $c;
                    my $q = $c;
                    while $i < $len {
                        my $sc = $css.substr($i++, 1);
                        $content ~= $sc;
                        last if $sc eq $q && $css.substr($i-2, 1) ne '\\';
                    }
                }
                elsif $c eq '{' { $depth++; $content ~= $c; }
                elsif $c eq '}' { $depth--; $content ~= $c unless $depth == 0; }
                else { $content ~= $c; }
            }
            if $content.index('{').defined {
                $result ~= '{' ~ self!normalize-all-decls($content, :$color-masks) ~ '}';
            }
            else {
                $result ~= '{' ~ self!normalize-block($content, :$color-masks) ~ '}';
            }
        }
        else {
            $result ~= $ch;
        }
    }

    $result;
}

# Parse, normalize, and dedup declarations inside a leaf {…} block.
method !normalize-block(Str $content, Bool :$color-masks = True --> Str) {
    return '' unless $content.chars;
    my @decls;
    my $i = 0;
    my $len = $content.chars;

    while $i < $len {
        $i++ while $i < $len && $content.substr($i, 1) ~~ /\s/;
        last if $i >= $len;

        my $key = '';
        while $i < $len && $content.substr($i, 1) ne ':' {
            $key ~= $content.substr($i++, 1);
        }
        $i++;
        $i++ while $i < $len && $content.substr($i, 1) ~~ /\s/;

        my $value = '';
        my $depth = 0;
        while $i < $len {
            my $c = $content.substr($i, 1);
            if $c eq '"' || $c eq "'" {
                $value ~= $c;
                $i++;
                my $q = $c;
                while $i < $len && $content.substr($i, 1) ne $q {
                    if $content.substr($i, 1) eq '\\' {
                        $value ~= $content.substr($i++, 1);
                    }
                    $value ~= $content.substr($i++, 1);
                }
                $value ~= $content.substr($i++, 1) if $i < $len;
            }
            elsif $c eq '(' { $depth++; $value ~= $c; $i++; }
            elsif $c eq ')' { $depth--; $value ~= $c; $i++; }
            elsif $c eq ';' && $depth == 0 { $i++; last; }
            else { $value ~= $c; $i++; }
        }

        $key = $key.trim;
        $value = $value.trim;
        next unless $key.chars && $value.chars;

        @decls.push: { key => $key, value => $value };
    }

    return '' unless @decls;

    # Dedup by property name (last wins), except custom properties (--*)
    # which may be intentionally duplicated.
    my %index;
    my @uniq;
    for @decls -> $d {
        if $d<key>.starts-with('--') {
            @uniq.push: $d;
        }
        elsif %index{$d<key>}:exists {
            @uniq[%index{$d<key>}] = $d;
        }
        else {
            %index{$d<key>} = @uniq.elems;
            @uniq.push: $d;
        }
    }

    my $result = @uniq.map({ self!minify-value(.<key>, .<value>, :$color-masks, :!named-colors) }).join(';');
    $result ~= ';' if $content.ends-with(';');
    $result;
}

my constant @PLUGIN-DEFS = (
    { :level(1), :class(CSS::Minifier::Plugin::Values) },
    { :level(2), :class(CSS::Minifier::Plugin::Dedup) },
    { :level(2), :class(CSS::Minifier::Plugin::Merging) },
);

method !plugins-for($level) {
    $level ~~ 1..2 or die "Invalid level: $level. Use 1 or 2.";
    @PLUGIN-DEFS.grep({ .<level> <= $level }).map({ .<class>.new }).list;
}

=begin pod

=head1 NAME

CSS::Minifier - CSS Minifier

=head1 SYNOPSIS

=begin code :lang<raku>

use CSS::Minifier;
say CSS::Minifier.minify($css, :level(2));

=end code

=head1 DESCRIPTION

A CSS minifier that parses, optimizes, and re-serializes CSS stylesheets.
Intended as a class method (call C<CSS::Minifier.minify($css)>).

=head2 Options

=item level - optimization level (1 = safe, 2 = structural, default 1)
=item verbose - log plugin names to stderr during processing
=item preserve-licenses - keep /*! */ license comments (extracted from raw CSS before parse; prepended to output)
=item color-masks - shorten hex colors  (default True)
=item color-names - convert hex to named colors (default False)
=item preserve-unknown - re-inject declarations dropped by the pipeline (default True). This catches both unknown properties (C<text-decoration-line>) and CSS3-only values on known properties (C<display: flex>, C<position: sticky>). Set to C<False> to skip the post-minification merge pass. All properties inside at-rules that CSS::Stylesheet drops (e.g. C<@keyframes>, C<@supports>, C<@container>, C<@layer>) are also preserved regardless of whether they are known to CSS::Module::CSS3 — they come back without minification since they bypass the standard pipeline. Known properties inside C<@media>, C<@page>, and C<@font-face> are always handled by the pipeline.
=item sep - separator between rulesets (default '' for compact; use C<"\n"> for readable output)

Note: license comments are extracted via a character-walking state machine
that correctly skips quoted strings and regular comments, so patterns
like C<content: "/*! not a license */"> are not falsely matched.

=head1 PRESERVING UNKNOWN PROPERTIES

CSS::Properties recognizes standard CSS properties and drops those it
doesn't know (e.g. C<text-decoration-line>, C<outline-offset>),
as well as CSS3-only values on known properties (C<display: flex>,
C<position: sticky>). C<CSS::Minifier> works around this by
pre-scanning the raw CSS before parsing and re-injecting any
declarations that are missing from the minified output.

All declarations are pre-scanned from the raw CSS (not just unknown
ones). After the pipeline runs, any declaration missing from the
minified output is re-injected, which catches CSS3-only values
(C<display: flex>, C<position: sticky>, C<overflow: clip>, etc.)
that CSS::Module::CSS3's grammar drops.

Longhands that CSS::Properties consolidates into shorthands
(e.g. C<background-color> → C<background>) are detected by an
internal C<%SHORTHAND> map and are not re-injected, preserving the
optimizer's work.

Unknown properties inside at-rules (C<@media>, C<@supports>,
C<@container>, C<@layer>, etc.) are also preserved. The extraction
uses recursive brace-counting on the raw CSS, so any at-rule with a
C<{...}> body is handled.

Unsafe at-rules (C<@keyframes>, C<@supports>, C<@container>, C<@layer>,
C<@scope>, etc.) that CSS::Stylesheet has no grammar rule for are an
extreme case: the entire block body is extracted and re-injected verbatim,
bypassing the pipeline entirely. However, a post-processing pass
(C<!normalize-all-decls>) walks the final output and normalizes values
(color shortening, font-weight, zero-unit removal) and deduplicates
declarations inside ALL C<{...}> blocks, including these at-rules.


=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
