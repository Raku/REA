use CSS::Minifier::Document;
use CSS::Minifier::Util;

class CSS::Minifier::Writer:ver<0.0.14>:auth<zef:sasha> {
    has Str  $.sep = '';
    has Bool $.color-masks = True;
    has Bool $.color-names = False;

    # --- Write a Document tree to minified CSS ---

    method write-document(Document $doc --> Str) {
        my $result = '';

        $result ~= $doc.licenses.join("\n") ~ "\n" if $doc.licenses;
        if $doc.statements {
            my @stmts = $doc.statements.map({ self!write-statement($_) });
            $result ~= @stmts.grep(?*).join($.sep);
        }

        $result;
    }

    method !write-statement(Statement $stmt --> Str) {
        given $stmt {
            when RuleSet { self!write-ruleset($_) }
            when AtRule  { self!write-at-rule($_) }
            default { die 'unknown statement type: ' ~ $stmt.^name }  # guard for future Statement types
        }
    }

    method !write-ruleset(RuleSet $rs --> Str) {
        my $sels = $rs.selectors.map({ self!url-quote-selector($_) }).join(', ');
        my $decls = self!write-decls($rs.declarations);
        $decls ?? $sels ~ '{' ~ $decls ~ '}' !! '';
    }

    method !write-at-rule(AtRule $ar --> Str) {
        my $prefix = '@' ~ $ar.name;
        $prefix ~= ' ' ~ $ar.prelude if $ar.prelude;

        if $ar.braceless {
            return $prefix ~ ';';
        }

        my $brace-space = $ar.prelude ?? ' ' !! '';

        my $inner = '';
        $inner ~= self!write-decls($ar.declarations) if $ar.declarations.elems > 0;
        $inner ~= ';' if $ar.declarations.elems > 0 && ($ar.statements.elems > 0 || $ar.trailing-declarations.elems > 0);
        $inner ~= $ar.statements.map({ self!write-statement($_) }).join($.sep) if $ar.statements.elems > 0;
        $inner ~= ';' if $ar.statements.elems > 0 && $ar.trailing-declarations.elems > 0;
        $inner ~= self!write-decls($ar.trailing-declarations) if $ar.trailing-declarations.elems > 0;

        return '' unless $inner;  # Empty block at-rules are dead code — drop silently
        $prefix ~ $brace-space ~ '{' ~ $inner ~ '}';
    }

    method !write-decls(Declaration @decls --> Str) {
        return '' unless @decls;
        @decls.map({
            my $v        = .value;
            my $is-custom = is-custom-prop(.property);
            my $lc-prop   = $is-custom ?? '' !! .property.lc;
            my $is-fw     = !$is-custom && $lc-prop eq 'font-weight';
            my $full-norm = $!color-masks && !$!color-names;

            $v = self!apply-color-names(.property, $v) if $!color-names;

            unless $is-custom {
                if $full-norm {
                    $v = .normalized // normalize-value(.property, $v);
                    .normalized = $v;
                }
                elsif $is-fw {
                    $v = .normalized // normalize-value(.property, $v);
                }
                else {
                    $v = strip-zero-units($v);
                }
            }

            my $key = $is-custom ?? .property !! $lc-prop;
            my $result = self!normalize-quotes($key, $v);
            $result ~= '!important' if .important;
            $result;
        }).join(';');
    }

    method !dq-to-sq(Str $s is copy --> Str) {
        $s ~~ s:g[ '\\"' ] = $SENTINEL;
        $s ~~ s:g/ '"' /'/;
        $s ~~ s:g[ $SENTINEL ] = '"';
        $s;
    }

    method !url-quote-selector(Str $s --> Str) {
        my $r = $s;
        unless $r.contains("'") {
            $r = self!dq-to-sq($r);
        }
        self!url-quote-value($r);
    }

    method !normalize-quotes(Str $property, Str $value --> Str) {
        my $v = $value;
        unless $v.contains("'") {
            $v = self!dq-to-sq($v);
        }
        my $s = self!url-quote-value($v);
        $property ~ ':' ~ $s;
    }

    method !url-quote-value(Str $s is copy --> Str) {
        my @chars = $s.comb;
        my $i = 0;
        my $out = '';
        loop {
            my $start = $s.index('url(', $i);
            last without $start;
            $out ~= $s.substr($i, $start - $i);
            my $depth = 1;
            my $j = $start + 4;
            while $j < @chars.elems && $depth > 0 {
                my $c = @chars[$j];
                if $c eq '(' { $depth++ }
                elsif $c eq ')' { $depth-- }
                elsif $c eq '"' || $c eq "'" { $j = skip-quoted(@chars, $j, $c); next }
                $j++;
            }
            my $inner = $s.substr($start + 4, $j - $start - 5);
            $inner ~~ / ^ (\s*) (.*?) (\s*) $ /;
            $out ~= 'url(' ~ $0 ~ self!url-quote(~$1) ~ $2 ~ ')';
            $i = $j;
        }
        $out ~= $s.substr($i) if $i < $s.chars;
        $out;
    }

    method !url-quote(Str $u --> Str) {
        return "'" ~ $u.substr(1, *-1).subst("'", "\\'", :g) ~ "'"
            if $u.starts-with("'") && $u.ends-with("'");
        return '"' ~ $u.substr(1, *-1).subst('"', '\\"', :g) ~ '"'
            if $u.starts-with('"') && $u.ends-with('"');
        "'" ~ $u.subst("'", "\\'", :g) ~ "'"
    }

    method !apply-color-names(Str $key, Str $value --> Str) {
        return $value unless %COLOR-PROPS{$key.lc} && $value !~~ $UNSAFE-RE;
        with-url-quarantine($value, -> $v is copy {
            $v = hsl-to-hex($v);
            $v = normalize-hex-value($v, :short($!color-masks));
            $v ~~ s:g/ <$HEX-TO-NAMED-RE> /%HEX-TO-NAME{lc $/}/;
            $v;
        });
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Writer — Document-tree CSS serializer

=head1 DESCRIPTION

Serializes a C<Document> tree back into minified CSS.  Handles:

=item Quote normalization (double → single, with escaped-quote protection)
=item Color masking (named → hex, hex shortening, rgb → hex)
=item Color naming (hex → named, when C<:color-names> is set)
=item Font-weight normalization (bold → 700, normal → 400)
=item Zero-unit removal (0px → 0)
=item URL quote wrapping
=item Space insertion before C<{> for at-rules with a prelude

=head2 Attributes

=item C<$.sep> — separator between top-level statements (default '')
=item C<$.color-masks> — enable hex color shortening (default True)
=item C<$.color-names> — convert hex to named colors (default False)

When both C<:color-names> and C<:color-masks> are enabled, C<:color-names>
takes precedence (colors are named rather than hex-shortened).

=head2 Methods

=item C<write-document(Document $doc --> Str)> — renders the document
tree to a minified CSS string

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
