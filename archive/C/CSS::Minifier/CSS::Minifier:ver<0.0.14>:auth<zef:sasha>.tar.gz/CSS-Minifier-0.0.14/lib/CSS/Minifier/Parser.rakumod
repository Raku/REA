use CSS::Minifier::Document;
use CSS::Minifier::Util;

unit class CSS::Minifier::Parser:ver<0.0.14>:auth<zef:sasha>;

my constant $WS = ' ' | "\t" | "\n" | "\r" | "\f";

# CSS-wide value keywords that are never valid as selector starts.
# Used by !heuristic-selector-start to avoid misclassifying values
# as selectors in mixed declaration+block contexts.
my constant %VALUE-KEYWORDS =
    set <auto none normal inherit initial unset revert revert-layer
         cover contain ellipsis clip
         visible hidden scroll collapse
         transparent currentcolor
         thin medium thick
         bold bolder lighter
         solid dashed dotted double groove ridge inset outset
         flex grid inline-flex inline-grid block inline-block inline-table table flow-root contents list-item run-in
         relative absolute fixed sticky
         serif sans-serif monospace cursive fantasy>;
my sub skip-ws(@chars, Int $i is rw --> Nil) {
    $i++ while $i < @chars.elems && @chars[$i] ~~ $WS;
}

# Maximum input size in bytes; configurable via CSS_MINIFIER_MAX_INPUT env var.
my constant MAX-INPUT = (%*ENV<CSS_MINIFIER_MAX_INPUT> // 10_000_000).Int;

# Parser entry point: turns raw CSS into a Document tree.
# Uses brace-counting for block structure and parse-body for
# declaration extraction.
method parse(Str $css, Bool :$preserve-licenses = False --> Document) {
    die "Input exceeds MAX-INPUT ({MAX-INPUT} bytes)" if $css.chars > MAX-INPUT;
    my $doc = Document.new;

    my $pair = self!extract-braceless($css, :$preserve-licenses);
    my $clean = $pair.key;
    $doc.licenses.push: $_ for $pair.value;

    $doc.statements = self!parse-block($clean);

    $doc;
}

# Recursively parse a CSS string into top-level statements.
method !parse-block(Str $s) {
    my Statement @stmts;
    my $i = 0;
    my $len = $s.chars;
    my @chars := comb-cached($s);

    while $i < $len {
        given @chars[$i] {
            when $WS  { $i++; next }
            when '"'   { $i = skip-quoted(@chars, $i, '"');  next }
            when "'"   { $i = skip-quoted(@chars, $i, "'");  next }
            when '}'   { $i++; next }
            when '/'  {
                if $i + 1 < $len && @chars[$i+1] eq '*' {
                    $i += 2;
                    skip-comment-chars(@chars, $i, $len);
                    next;
                }
                $i++; next
            }
        default {
            # `{` falls through to !find-block-range below (starts a block).
            # `@` is caught here; anything else is a regular char.
            next if @chars[$i] eq '@' && self!extract-braceless-at($s, @chars, $i, @stmts);
        }
        }

        my ($brace, $close) = self!find-block-range(@chars, $i);
        last if $brace >= $len;

        my $head = $s.substr($i, max(0, $brace - $i)).trim;
        my $body = $s.substr($brace + 1, max(0, $close - $brace - 1));

        if $head.starts-with('@') {
            @stmts.push: self!parse-at-rule($head, $body);
        }
        elsif $head {
            @stmts.push: self!parse-ruleset($head, $body);
        }

        $i = $close + 1;
    }

    # Braceless at-rule at EOF without trailing ;
    if $i < $len {
        my $tail = $s.substr($i).trim;
        if $tail && $tail.starts-with('@') {
            @stmts.push: self!parse-at-rule($tail, '', :braceless);
        }
    }

    @stmts;
}

# Single-pass block scanner — returns (brace-pos, close-pos).
method !find-block-range(@chars, Int $start --> List) {
    my $i = $start;
    my $len = @chars.elems;
    my $depth = 0;
    my Int $brace = Nil;

    while $i < $len {
        given @chars[$i] {
            when '\\' { $i += 2 }
            when '{'  {
                if $depth == 0 {
                    $brace = $i;
                    $depth = 1;
                } else {
                    $depth++;
                }
                $i++
            }
            when '}'  {
                $depth-- if $depth > 0;
                if $depth == 0 {
                    return ($brace // $len, $i);
                }
                $i++
            }
            when '"'  { $i = skip-quoted(@chars, $i, '"')  }
            when "'"  { $i = skip-quoted(@chars, $i, "'")  }
            when '/'  {
                if $i + 1 < $len && @chars[$i+1] eq '*' {
                    $i += 2;
                    skip-comment-chars(@chars, $i, $len);
                } else { $i++ }
            }
            default   { $i++ }
        }
    }
    ($brace // $len, $len)
}

# Convert a parse-body Pair ("key" => "value") into a Declaration,
# stripping trailing !important.
method !make-declaration(Pair $p --> Declaration) {
    my $v = $p.value;
    my $imp = False;
    my $lc = $v.lc;
    my $pos = $lc.rindex('!important');
    if $pos.defined && $lc.substr($pos + 10).trim eq '' {
        $imp = True;
        $v = $v.substr(0, $pos);
    }
    Declaration.new(:property($p.key), :value($v.trim), :important($imp));
}

# Shared helper: extract a braceless at-rule starting at $pos in $src.
# On success pushes the parsed AtRule to @target, advances $pos past it,
# and returns True.  On failure $pos is unchanged and returns False.
method !extract-braceless-at(Str $src, @chars, Int $pos is rw, @target --> Bool) {
    my $end = find-braceless-end(@chars, $pos);
    return False unless $end.defined && $end < @chars.elems;
    my $raw = $src.substr($pos, $end - $pos + 1);
    my $h = strip-braceless-comments($raw).trim;
    $h .= substr(0, *-1) if $h.ends-with(';');
    $h = $h.trim;
    @target.push: self!parse-at-rule($h, '', :braceless) if $h.starts-with('@');
    $pos = $end + 1;
    True
}

method !parse-at-rule(Str $head, Str $body, Bool :$braceless = False --> AtRule) {
    # Split " @name prelude " into name and prelude
    my @parts = $head.split(/ \s+ /, 2);
    my $name = @parts[0].subst('@', '', :1st);
    my $keyframes = $name.fc eq 'keyframes';
    my $prelude = @parts[1] // '';

    my AtRule $ar .= new(:$name, :$prelude, :$braceless);
    return $ar if $braceless;

    my @body-chars := comb-cached($body);
    my ($brace, $close) = self!find-block-range(@body-chars, 0);

    # No braces at all → declaration-only at-rule (e.g. @font-face)
    if $brace >= @body-chars.elems {
        $ar.declarations = parse-body($body, @body-chars).map({ self!make-declaration($_) }).List;
        return $ar;
    }

    my @declarations;
    my @statements;
    my $pos = 0;
    my $len = @body-chars.elems;

    # Walk the body alternating between gap text and {blocks}
    loop {
        # Skip whitespace and inline braceless at-rules before the next block
        while $pos < $len {
            if @body-chars[$pos] ~~ $WS { $pos++; next }
            next if @body-chars[$pos] eq '@' && self!extract-braceless-at($body, @body-chars, $pos, @statements);
            last;
        }
        last if $pos >= $len;

        # Find the next {block}  (ruleset, nested at-rule, or trailing decls)
        my ($b, $c) = self!find-block-range(@body-chars, $pos);
        last if $b >= $len;

        # Scan the gap text between here and the block (may contain declarations + braceless at-rules)
        my $before = $body.substr($pos, $b - $pos);
        if $before.trim {
            my $gpos = 0;
            my $glen = $before.chars;
            my @gchars := comb-cached($before);
            my $gap-buf = self!scan-gap-text($gpos, $glen, @gchars, $before, @statements);
            $before = self!split-gap-buffer($gap-buf, @declarations);
        }

        # Recursively parse the block contents
        my $head-text = $before.trim;
        $head-text .= lc if $keyframes;
        my $inner = $body.substr($b + 1, $c - $b - 1);

        if $head-text.starts-with('@') {
            @statements.push: self!parse-at-rule($head-text, $inner);
        } elsif $head-text {
            @statements.push: self!parse-ruleset($head-text, $inner);
        }

        $pos = $c + 1;
    }

    # Any remaining text after the last block becomes trailing-declarations
    if $pos < $len {
        my $trailing = $body.substr($pos);
        if $trailing.trim {
            $ar.trailing-declarations = parse-body($trailing)
                .grep({ !.key.starts-with('@') })
                .map({ self!make-declaration($_) }).List;
        }
    }

    $ar.declarations = @declarations.List;
    $ar.statements = @statements;
    $ar;
}

method !parse-ruleset(Str $head, Str $body --> RuleSet) {
    my @selectors = self!split-selectors($head);
    self!normalize-combinator-spacing(@selectors);
    my @decls = parse-body($body);

    RuleSet.new(:@selectors, :declarations(@decls.map({ self!make-declaration($_) })));
}

# Accumulate gap text segments (semicolon-terminated or not).
method !scan-gap-text(Int $gpos is copy, Int $glen, @gchars, Str $src, @statements --> Str) {
    my $decl-buf = '';
    while $gpos < $glen {
        skip-ws(@gchars, $gpos);
        last if $gpos >= $glen;

        next if @gchars[$gpos] eq '@' && self!extract-braceless-at($src, @gchars, $gpos, @statements);

        my $semi = self!find-semicolon(@gchars, $gpos, $glen);
        if $semi.defined {
            $decl-buf ~= $src.substr($gpos, $semi - $gpos + 1);
            $gpos = $semi + 1;
        } else {
            $decl-buf ~= $src.substr($gpos);
            last;
        }
    }
    $decl-buf
}

# Find next unquoted semicolon. Returns position or Nil.
method !find-semicolon(@chars, Int $gpos, Int $glen --> Int) {
    my $scan = $gpos;
    while $scan < $glen {
        given @chars[$scan] {
            when ';' { return $scan }
            when '"' { $scan = skip-quoted(@chars, $scan, '"') }
            when "'" { $scan = skip-quoted(@chars, $scan, "'") }
            when '/' {
                if $scan + 1 < $glen && @chars[$scan+1] eq '*' {
                    $scan += 2;
                    skip-comment-chars(@chars, $scan, $glen);
                } else { $scan++ }
            }
            default  { $scan++ }
        }
    }
    Nil
}

# Try to split a gap-text buffer into declarations + trailing selector.
method !split-gap-buffer(Str $decl-buf, @declarations --> Str) {
    return '' unless $decl-buf.trim;

    my $semi = $decl-buf.rindex(';');
    if $semi.defined {
        my @decls = parse-body($decl-buf.substr(0, $semi))
            .grep({ !.key.starts-with('@') });
        @declarations.append(@decls.map({ self!make-declaration($_) }));
        return $decl-buf.substr($semi + 1);
    }

    my @tries = parse-body($decl-buf).grep({ !.key.starts-with('@') });
    return $decl-buf unless @tries == 1;

    my $val = @tries[0].value;
    my $sp = $val.rindex(' ');
    return $decl-buf unless $sp.defined;

    my $tok = $val.substr($sp + 1);
    if self!heuristic-selector-start($tok) && $tok !~~ /<["'(]>/ {
        @tries[0] = @tries[0].key => $val.substr(0, $sp).trim;
        @declarations.push(self!make-declaration(@tries[0]));
        return $tok;
    }
    $decl-buf
}

# Check if a token looks like the start of a selector.
method !heuristic-selector-start(Str $tok --> Bool) {
    $tok.starts-with('.') || $tok.starts-with('#')
        || $tok.starts-with('[') || $tok.starts-with(':')
        || $tok eq '*' || $tok eq '&'
        || ($tok ~~ /^<[a..zA..Z]>/ && $tok !~~ %VALUE-KEYWORDS)
}

# Split selector text by top-level commas and normalize spacing
# around combinators (+, >, ~).  This prevents re-minification
# growth when the raw input uses comma-separated selectors without
# spaces.
method !split-selectors(Str $sel --> List) {
    # Fast path: single simple selector — no commas, brackets, parens, or quotes
    if $sel.index(',') === Nil
        && $sel.index('[') === Nil
        && $sel.index('(') === Nil
        && $sel.index('"') === Nil
        && $sel.index("'") === Nil {
        my $t = $sel.trim;
        return $t ?? ($t,) !! ();
    }
    my @parts;
    my $start = 0;
    my $bracket = 0;
    my $paren = 0;
    my $i = 0;
    my $len = $sel.chars;
    while $i < $len {
        my $c = $sel.substr($i, 1);
        if $c eq '[' { $bracket++; $i++ }
        elsif $c eq ']' { $bracket--; $i++ }
        elsif $c eq '(' { $paren++;  $i++ }
        elsif $c eq ')' { $paren--;  $i++ }
        elsif $c eq '"' || $c eq "'" {
            my $j = $i + 1;
            while $j < $len {
                my $d = $sel.substr($j, 1);
                if $d eq '\\' { $j += 2; next }
                last if $d eq $c;
                $j++;
            }
            $i = $j + 1;
        }
        elsif $c eq ',' {
            if $bracket == 0 && $paren == 0 {
                @parts.push: $sel.substr($start, $i - $start).trim;
                $i++;
                $i++ while $i < $len && $sel.substr($i, 1) ~~ $WS;
                $start = $i;
            } else { $i++ }
        }
        else { $i++ }
    }
    my $last = $sel.substr($start).trim if $start < $len;
    @parts.push: $last if $last;
    @parts;
}

method !normalize-combinator-spacing(@parts) {
    my Str @norm;
    for @parts -> $sel {
        # Fast path: no combinators, brackets, parens, quotes, or spaces → unchanged
        if !($sel.contains('+') || $sel.contains('>') || $sel.contains('~')
                || $sel.contains('|')
                || $sel.contains('[') || $sel.contains('(')
                || $sel.contains('"') || $sel.contains("'")
                || $sel.contains(' ')) {
            @norm.push($sel);
            next;
        }
        my Str @out;
        my $bracket = 0;
        my $paren = 0;
        my $i = 0;
        my $last-comb = '';
        # $last-comb tracks the last combinator emitted ('+', '>', '~', '||', or '').
        # When two consecutive whitespace-combinator groups use the same combinator,
        # the second is skipped (a > > b is invalid CSS; the first combinator wins).
        # Reset to '' after any non-whitespace non-combinator token is emitted,
        # and after closing bracket/paren groups.
        my $sel-chars = $sel.chars;
        my @sel-chars := comb-cached($sel);
        while $i < $sel-chars {
            my $c = @sel-chars[$i];
            if $c eq '[' { $bracket++; @out.push('['); $i++ }
            elsif $c eq ']' { $bracket--; @out.push(']'); $i++; $last-comb = '' if $bracket == 0 }
            elsif $c eq '(' { $paren++;  @out.push('('); $i++ }
            elsif $c eq ')' { $paren--; @out.push(')'); $i++; $last-comb = '' if $paren == 0 }
            elsif $c eq '"' || $c eq "'" {
                my $e = skip-quoted(@sel-chars, $i, $c);
                @out.push($sel.substr($i, $e - $i));
                $i = $e;
            }
            elsif $c ~~ $WS {
                if $bracket == 0 && $paren == 0 {
                    if @out { @out[*-1] ~= ' ' unless @out[*-1].ends-with(' ') } else { @out.push(' ') }
                    $i++;
                    skip-ws(@sel-chars, $i);
                } else {
                    @out.push($c); $i++;
                }
            }
            elsif $c eq '+' || $c eq '>' || $c eq '~' {
                if $bracket == 0 && $paren == 0 {
                    if $last-comb ne $c {
                        if @out {
                            @out[*-1] = @out[*-1].substr(0, *-1) if @out[*-1].ends-with(' ');
                            @out[*-1] ~= " $c ";
                        } else { @out.push(" $c ") }
                        $last-comb = $c;
                    }
                    $i++;
                    skip-ws(@sel-chars, $i);
                } else {
                    @out.push($c); $i++;
                }
            }
            elsif $c eq '|'  {
                if $i + 1 < $sel-chars && @sel-chars[$i+1] eq '|' {
                    if $bracket == 0 && $paren == 0 {
                        if $last-comb ne '||' {
                            if @out { @out[*-1] = @out[*-1].trim ~ ' || ' } else { @out.push(' || ') }
                            $last-comb = '||';
                        }
                        $i += 2;
                        skip-ws(@sel-chars, $i);
                    } else {
                        @out.push('||'); $i += 2;
                    }
                } else {
                    @out.push('|'); $i++; $last-comb = '';
                }
            }
            else { @out.push($c); $i++; $last-comb = '' }
        }
        @norm.push(@out.join.trim);
    }
    @parts = @norm;
}

# Extract /*! */ license comments and return remaining CSS.
# Walks the CSS one character at a time in a single pass, tracking
# whether we're inside a /*! license block (with nesting support).
method !extract-braceless(Str $css, Bool :$preserve-licenses --> Pair) {
    return $css => [] unless $css.contains('/*');
    my Str @out;
    my $i = 0;
    my $len = $css.chars;
    my @chars := comb-cached($css);
    my Str @buf;
    my Bool $in-license = False;
    my Int  $license-depth = 0;
    my Str @licenses;
    while $i < $len {
        given @chars[$i] {
            when '/'  {
                if $in-license {
                    if $css.substr-eq('/*', $i) {
                        $license-depth++; @buf.push('/*'); $i += 2; next
                    }
                    @buf.push('/'); $i++; next
                }
                if $css.substr-eq('/*!', $i) && $preserve-licenses {
                    $in-license = True; $license-depth = 1; @buf = '/*!'; $i += 3; next
                }
                if $css.substr-eq('/*', $i) {
                    $i = ($css.index('*/', $i+2) // $len - 2) + 2; next
                }
            }
            when '*' {
                if $in-license {
                    if $i + 1 < $len && @chars[$i+1] eq '/' {
                        $license-depth--; @buf.push('*/'); $i += 2;
                        if $license-depth == 0 {
                            @licenses.push: @buf.join; $in-license = False;
                        }
                        next;
                    }
                    @buf.push('*'); $i++; next
                }
                if $i + 1 < $len && @chars[$i+1] eq '/' { $i += 2; next }
            }
            when '"'  {
                my $end = skip-quoted($css, $i, '"');
                if $in-license { @buf.push($css.substr($i, $end - $i)); $i = $end; next }
                @out.push($css.substr($i, $end - $i)); $i = $end; next
            }
            when "'"  {
                my $end = skip-quoted($css, $i, "'");
                if $in-license { @buf.push($css.substr($i, $end - $i)); $i = $end; next }
                @out.push($css.substr($i, $end - $i)); $i = $end; next
            }
        }

        if $in-license {
            @buf.push(@chars[$i]);
        } else {
            @out.push(@chars[$i]);
        }
        $i++;
    }

    @licenses.push: @buf.join if $in-license;
    @out.join => @licenses;
}

# Strip comments from braceless at-rule text, preserving quoted strings.
sub strip-braceless-comments(Str $raw --> Str) is export {
    my @clean;
    my $trailing-ws = '';
    my $j = 0;
    my $rlen = $raw.chars;
    my @rchars := comb-cached($raw);
    while $j < $rlen {
        if @rchars[$j] eq '"' || @rchars[$j] eq "'" {
            my $qend = skip-quoted($raw, $j, @rchars[$j]);
            @clean.push: $trailing-ws ~ $raw.substr($j, $qend - $j);
            $trailing-ws = '';
            $j = $qend;
        } elsif @rchars[$j] eq '/' && $j + 1 < $rlen && @rchars[$j+1] eq '*' {
            $trailing-ws = '';
            skip-comment-str($raw, $j, $rlen);
            $j++ while $j < $rlen && @rchars[$j] eq ' ';
            @clean.push: ' ' unless $j >= $rlen || @rchars[$j] eq ';';
        } elsif @rchars[$j] ~~ $WS {
            $trailing-ws ~= @rchars[$j];
            $j++;
        } else {
            @clean.push: $trailing-ws ~ @rchars[$j];
            $trailing-ws = '';
            $j++;
        }
    }
    @clean.push: $trailing-ws if $trailing-ws.chars;
    @clean.join;
}

# Find the end of a braceless at-rule: semicolon at top level.
# Returns Nil if a { is encountered first (block at-rule).
multi sub find-braceless-end(Str $s, Int $start --> Int) is export {
    find-braceless-end(comb-cached($s), $start);
}
multi sub find-braceless-end(@chars, Int $start --> Int) is export {
    my $i = $start;
    my $depth = 0;
    my $len = @chars.elems;
    while $i < $len {
        given @chars[$i] {
            when '('  { $depth++; $i++ }
            when ')'  { $depth-- if $depth > 0; $i++ }
            when '\\' { $i += 2 }
            when '"'  { $i = skip-quoted(@chars, $i, '"'); next }
            when "'"  { $i = skip-quoted(@chars, $i, "'"); next }
            when '/'  {
                if $i + 1 < $len && @chars[$i+1] eq '*' {
                    $i += 2;
                    skip-comment-chars(@chars, $i, $len);
                    $i++;
                } else { $i++ }
            }
            when '{'  { return Nil if $depth == 0; $i++ }
            when ';'  { return $i if $depth == 0; $i++ }
            default   { $i++ }
        }
    }
    $len
}

# Parse declarations from the body of a ruleset or declaration-only at-rule.
# NB: comments are already stripped by !extract-braceless before reaching this point.
# Returns a list of Pair("key" => "value").
sub parse-body(Str $body, @chars? is copy --> List) is export(:parse-body) {
    @chars = comb-cached($body).list unless @chars.elems;
    my @decls;
    my $i = 0;
    my $len = @chars.elems;

    while $i < $len {
        while $i < $len {
            given @chars[$i] {
                when $WS { $i++ }
                when ';'  { $i++ }
                when '}'  { $i++; return @decls }
            default   { last }
            }
        }
        last if $i >= $len;

        my @key;
        my $depth = 0;
        while $i < $len {
            given @chars[$i] {
                when '('   { $depth++; @key.push('('); $i++ }
                when ')'   { $depth--;  @key.push(')'); $i++ }
                when ':'   { $i++; last if $depth == 0; @key.push(':') }
                when ';' | '}' { last if $depth == 0; @key.push(@chars[$i]); $i++ }
                when '"'   { my $end = skip-quoted(@chars, $i, '"');  @key.push($body.substr($i, $end - $i)); $i = $end }
                when "'"   { my $end = skip-quoted(@chars, $i, "'");  @key.push($body.substr($i, $end - $i)); $i = $end }
                default    { @key.push(@chars[$i]); $i++ }
            }
        }
        my $key = @key.join.trim;

        skip-ws(@chars, $i);

        my @value;
        $depth = 0;
        while $i < $len {
            given @chars[$i] {
                when '('   { $depth++; @value.push('('); $i++ }
                when ')'   { $depth--;  @value.push(')'); $i++ }
                when ';'   { $i++; last if $depth == 0; @value.push(';') }
                when '}'   { last if $depth == 0; @value.push('}'); $i++ }
                when '"'   { my $end = skip-quoted(@chars, $i, '"');  @value.push($body.substr($i, $end - $i)); $i = $end }
                when "'"   { my $end = skip-quoted(@chars, $i, "'");  @value.push($body.substr($i, $end - $i)); $i = $end }
                default    { @value.push(@chars[$i]); $i++ }
            }
        }
        my $value = @value.join.trim;
        @decls.push: $key => $value if $key;
    }

    @decls
}

=begin pod

=head1 NAME

CSS::Minifier::Parser — custom brace-counting CSS parser

=head1 DESCRIPTION

Parses raw CSS into a Document tree using brace-counting and
character-level scanning.
Handles strings (single/double quotes with escapes), comments,
braceless at-rules (C<@import>, C<@charset>, C<@namespace>), and
recursive block structure for nested at-rules.

Note: CSS native nesting (e.g. C<& b { ... }>) is not supported
and will silently misparse. Nested rulesets must be flattened
before minification. C<@keyframes> (percentage/from/to keyframe
selectors) IS handled correctly.

=head2 Methods

=item C<parse(Str $css, Bool :$preserve-licenses --> Document)>
— parses CSS and returns a Document tree.  When C<:$preserve-licenses>
is True, C</*! */> comments are extracted into C<Document.licenses>.

=head1 EXPORTED SUBS

=item C<parse-body(Str $body --> List)> — parses the body of a ruleset
or declaration-only at-rule into a list of key => value Pair objects.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
