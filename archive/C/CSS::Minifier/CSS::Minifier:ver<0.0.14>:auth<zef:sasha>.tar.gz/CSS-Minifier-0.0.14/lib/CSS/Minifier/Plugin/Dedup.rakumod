use CSS::Minifier::Document;
use CSS::Minifier::Plugin;

class CSS::Minifier::Plugin::Dedup:ver<0.0.14>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'dedup' }

    method run(Document $doc --> Nil) {
        $doc.statements = self!dedup-block($doc.statements);
    }

    method !dedup-block(Statement @stmts --> Array[Statement]) {
        my %seen;
        my Statement @kept;

        for @stmts -> $stmt {
            given $stmt {
                when RuleSet {
                    next unless .declarations;
                    my $key = self!ruleset-key($_);
                    @kept.push: $stmt unless %seen{$key}++;
                }
                when AtRule {
                    # Declaration-only at-rules (e.g. @font-face, @view-transitions) deduped by content
                    if .statements.elems == 0 && (.declarations || .trailing-declarations) {
                        my $key = self!at-rule-decl-key($_);
                        unless %seen{$key}++ {
                            @kept.push: $stmt;
                        }
                    }
                    else {
                        # Recurse into nested statements
                        .statements = self!dedup-block(.statements);
                        @kept.push: $stmt;
                    }
                }
                default { @kept.push: $stmt }
            }
        }

        @kept;
    }

    method !ruleset-key(RuleSet $rs --> Str) {
        my $sel = $rs.selectors.sort.join(',');
        $rs.decl-key = declarations-to-key($rs.declarations) unless $rs.decl-key;
        "$sel\0$rs.decl-key";
    }

    method !at-rule-decl-key(AtRule $ar --> Str) {
        $ar.name.fc ~ "\0" ~ $ar.prelude.fc ~ "\0" ~ declarations-to-key($ar.declarations)
            ~ "\0" ~ declarations-to-key($ar.trailing-declarations);
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Dedup — duplicate ruleset and @font-face removal

=head1 DESCRIPTION

Removes duplicate rulesets (same selectors + same declarations) and
duplicate C<@font-face> blocks at the same level.  Custom properties
are preserved verbatim and not deduped.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
