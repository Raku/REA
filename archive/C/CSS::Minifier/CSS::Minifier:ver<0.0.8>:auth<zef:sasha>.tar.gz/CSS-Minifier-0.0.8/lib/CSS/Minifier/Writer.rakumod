use CSS::Minifier::Document;
use CSS::Minifier::Util;

class CSS::Minifier::Writer:ver<0.0.8>:auth<zef:sasha> {
    has Str  $.sep = '';
    has Bool $.color-masks = True;
    has Bool $.color-names = False;

    # --- Write a Document tree to minified CSS ---

    method write-document(Document $doc --> Str) {
        my $result = '';

        $result ~= $doc.licenses.join("\n") ~ "\n" if $doc.licenses;
        if $doc.braceless {
            my $b = self!url-quote-value($doc.braceless.join("\n"));
            $b ~= "\n" if $doc.statements;
            $result ~= $b;
        }
        if $doc.statements {
            my @stmts = $doc.statements.map({ self!write-statement($_) });
            $result ~= @stmts.join($.sep);
        }

        $result;
    }

    method !write-statement(Statement $stmt --> Str) {
        given $stmt {
            when RuleSet { self!write-ruleset($_) }
            when AtRule  { self!write-at-rule($_) }
        }
    }

    method !write-ruleset(RuleSet $rs --> Str) {
        my $sels = $rs.selectors.map({ self!url-quote-selector($_) }).join(', ');
        my $decls = self!write-decls($rs.declarations);
        $decls ?? $sels ~ '{' ~ $decls ~ '}' !! '';
    }

    method !write-at-rule(AtRule $ar --> Str) {
        my $prefix = '@' ~ $ar.name;
        $prefix ~= ' ' ~ $ar.prelude if $ar.prelude;
        my $space = $ar.prelude ?? ' ' !! '';

        if $ar.statements {
            my $inner = $ar.statements.map({ self!write-statement($_) }).join($.sep);
            $prefix ~ $space ~ '{' ~ $inner ~ '}';
        }
        elsif $ar.declarations {
            my $decls = self!write-decls($ar.declarations);
            $prefix ~ $space ~ '{' ~ $decls ~ '}';
        }
        else {
            $prefix ~ $space ~ '{}';
        }
    }

    method !write-decls(Declaration @decls --> Str) {
        return '' unless @decls;
        @decls.map({
            my $v = .value;
            $v = self!apply-color-masks(.property, $v) if $!color-masks;
            if $!color-names {
                $v = rgb-values-to-hex($v);
                unless $!color-masks {
                    $v ~~ s:g[ <[#]> ( <xdigit> ) $0 ( <xdigit> ) $1 ( <xdigit> ) $2 ] = '#' ~ $0.uc ~ $1.uc ~ $2.uc;
                    $v ~~ s:g[ '#' (<[0..9 A..F a..f]>+) ] = '#' ~ $0.uc;
                }
                $v = self!apply-color-names(.property, $v);
            }
            $v = self!apply-font-weight(.property, $v) if .property eq 'font-weight';
            $v = self!strip-zero-units($v);
            my $s = .property ~ ':' ~ $v;
            $s ~= '!important' if .important;
            self!normalize-quotes($s);
        }).join(';');
    }

    method !url-quote-selector(Str $s --> Str) {
        my $r = $s;
        # Normalize double quotes to single, but protect escaped double quotes
        $r ~~ s:g[ '\\"' ] = "\x0";
        $r ~~ s:g/ '"' /'/;
        $r ~~ s:g[ "\x0" ] = '"';
        self!url-quote-value($r);
    }

    method !normalize-quotes(Str $s is copy --> Str) {
        my $colon = $s.index(':');
        my $value = $colon.defined ?? $s.substr($colon + 1) !! $s;
        unless $value.contains("'") {
            $value ~~ s:g/ '"' /'/;
            $s = $colon.defined ?? $s.substr(0, $colon + 1) ~ $value !! $value;
        }
        self!url-quote-value($s);
    }

    method !url-quote-value(Str $s is copy --> Str) {
        $s ~~ s:g[ :i url\( (\s*) (<-[>)]>+) (\s*) \) ] = 'url(' ~ $0 ~ self!url-quote(~$1) ~ $2 ~ ')';
        $s;
    }

    method !url-quote(Str $u --> Str) {
        $u ~~ / ^ \' .* \' $ / ?? $u !! ($u ~~ / ^ \" .* \" $ / ?? $u !! "'$u'");
    }

    # Color shortening: named colors -> hex, 6-char hex -> 3-char,
    # rgb() -> hex, rgba(...,1) -> hex.
    my constant %NON-COLOR-PROPS = Set.new(<font-family content>);
    my constant %COLOR-PROPS = Set.new(<
        color background background-color
        border border-color border-top border-right border-bottom border-left
        border-top-color border-right-color border-bottom-color border-left-color
        border-block border-inline border-block-start border-block-end
        border-inline-start border-inline-end
        border-block-color border-inline-color
        border-block-start-color border-block-end-color
        border-inline-start-color border-inline-end-color
        outline outline-color
        text-decoration text-decoration-color
        text-decoration-thickness text-underline-offset
        text-shadow box-shadow
        column-rule column-rule-color
        caret-color accent-color
        scrollbar-color scrollbar-face-color scrollbar-track-color
        scrollbar-arrow-color scrollbar-thumb-color
        -webkit-tap-highlight-color
    >);
    my constant %HEX-TO-NAME = %NAMED.map({ .value.lc => .key }).Map;
    my constant $UNITS = rx/
        px|em|ex|ch|rem|cap|ic|lh|rlh|
        vh|vw|vmin|vmax|vb|vi|svw|svh|lvw|lvh|dvw|dvh|
        cqw|cqh|cqi|cqb|cqmin|cqmax|
        cm|mm|in|pt|pc|q|
        deg|grad|rad|turn|s|ms|Hz|kHz|
        dpi|dpcm|dppx|fr
    /;
    my $NAMED-RE;
    my $HEX-TO-NAMED-RE;
    BEGIN {
        $NAMED-RE = rx:i/ << @(%NAMED.keys) >> /;
        $HEX-TO-NAMED-RE = rx:i/ <!after <xdigit>> @(%NAMED.values) <!before <xdigit>> /;
    }

    method !apply-color-masks(Str $key, Str $value --> Str) {
        return $value if %NON-COLOR-PROPS{$key};
        return $value unless %COLOR-PROPS{$key};
        return $value if $value ~~ $UNSAFE-RE;
        my $v = $value;
        my @urls;
        $v ~~ s:g/ url\( <-[)]>+ \) /{@urls.push(~$/); "\x0" ~ @urls.end}/;
        $v ~~ s:g/ <$NAMED-RE> /%NAMED{lc $/}/;
        $v = rgb-values-to-hex($v);
        $v ~~ s:g[ <[#]> ( <xdigit> ) $0 ( <xdigit> ) $1 ( <xdigit> ) $2 ] = '#' ~ $0.uc ~ $1.uc ~ $2.uc;
        $v ~~ s:g[ '#' (<[0..9 A..F a..f]>+) ] = '#' ~ $0.uc;
        $v ~~ s:g/ \x0(\d+) /{@urls[$0]}/;
        $v;
    }

    method !apply-font-weight(Str $key, Str $value --> Str) {
        return $value unless $key eq 'font-weight';
        return $value if $value ~~ $UNSAFE-RE;
        given $value {
            when 'bold'   { return '700' }
            when 'normal' { return '400' }
        }
        $value;
    }

    method !strip-zero-units(Str $value --> Str) {
        return $value if $value ~~ $UNSAFE-RE;
        my $v = $value;
        $v ~~ s:g/ (\d+) '.0' (<$UNITS>) /{$0 ~ $1}/;
        $v ~~ s:g/ <!after <[\d.]>> 0 <$UNITS> /0/;
        $v;
    }

    method !apply-color-names(Str $key, Str $value --> Str) {
        return $value if %NON-COLOR-PROPS{$key};
        return $value unless %COLOR-PROPS{$key};
        return $value if $value ~~ $UNSAFE-RE;
        my $v = $value;
        my @urls;
        $v ~~ s:g/ url\( <-[)]>+ \) /{@urls.push(~$/); "\x0" ~ @urls.end}/;
        $v ~~ s:g/ <$HEX-TO-NAMED-RE> /%HEX-TO-NAME{lc $/}/;
        $v ~~ s:g/ \x0(\d+) /{@urls[$0]}/;
        $v;
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Writer — Document-tree CSS serializer

=head1 DESCRIPTION

Serializes a C<Document> tree back into minified CSS.  Handles:

=item Quote normalization (double → single, with escaped-quote protection)
=item Color masking (named → hex, hex shortening, rgb → hex)
=item Color naming (hex → named, when C<:color-names> is set)
=item Font-weight normalization (bold → 700, normal → 400)
=item Zero-unit removal (0px → 0)
=item URL quote wrapping
=item Space insertion before C<{> for at-rules with a prelude

=head2 Attributes

=item C<$.sep> — separator between top-level statements (default '')
=item C<$.color-masks> — enable hex color shortening (default True)
=item C<$.color-names> — convert hex to named colors (default False)

=head2 Methods

=item C<write-document(Document $doc --> Str)> — renders the document
tree to a minified CSS string

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
