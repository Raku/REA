use CSS::Minifier::Document;

role CSS::Minifier::Plugin:ver<0.0.8>:auth<zef:sasha> {
    method name(--> Str) { ... }
    method run(Document $doc --> Nil) { ... }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin — plugin role for the CSS minifier

=head1 DESCRIPTION

Role that all minifier plugins must implement.  Plugins operate on
a Document tree and are run by L<CSS::Minifier::Pipeline>.

=head2 Required methods

=item C<name(--> Str)> — returns the plugin name for logging
=item C<run(Document $doc --> Nil)> — transforms the document in place

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
