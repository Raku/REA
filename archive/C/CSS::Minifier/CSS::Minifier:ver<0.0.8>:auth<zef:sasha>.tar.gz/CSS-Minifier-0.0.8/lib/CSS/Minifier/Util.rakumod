

unit module CSS::Minifier::Util:ver<0.0.8>:auth<zef:sasha>;

my %COMB-CACHE;
my constant COMB-CACHE-MAX = 500;
my $CACHE-LOCK = Lock.new;
sub comb-cached(Str $s) is export {
    return $s.comb.Array if $s.chars > 100_000;
    $CACHE-LOCK.protect: {
        %COMB-CACHE = {} if %COMB-CACHE.elems > COMB-CACHE-MAX;
        %COMB-CACHE{$s} //= $s.comb.Array
    }
}
sub clear-comb-cache(--> Nil) is export {
    $CACHE-LOCK.protect: { %COMB-CACHE = {} }
}

our constant %NAMED is export =
    red => '#F00', maroon => '#800000', yellow => '#FF0',
    olive => '#808000', green => '#008000', lime => '#0F0',
    aqua => '#0FF', teal => '#008080', blue => '#00F',
    navy => '#000080', fuchsia => '#F0F', purple => '#800080',
    orange => '#FFA500', white => '#FFF', silver => '#C0C0C0',
    gray => '#808080', black => '#000',
;

my constant $UNSAFE-RE is export = rx/ var\( | calc\( | env\( | min\( | max\( | clamp\( /;

sub rgb-values-to-hex(Str $v is copy --> Str) is export {
    $v ~~ s:g:i[ rgb\( \s* (\d+) \s* \, \s* (\d+) \s* \, \s* (\d+) \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgba\( \s* (\d+) \s* \, \s* (\d+) \s* \, \s* (\d+) \s* \, \s* 1(\.0+)? \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgb\( \s* (\d+) \s+ (\d+) \s+ (\d+) \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgba\( \s* (\d+) \s+ (\d+) \s+ (\d+) \s* \/ \s* 1(\.0+)? \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v;
}

sub has-top-level-comma(Str $v --> Bool) is export {
    my $i = 0;
    my $depth = 0;
    my $len = $v.chars;
    my @chars := comb-cached($v);
    while $i < $len {
        given @chars[$i] {
            when '('   { $depth++; $i++ }
            when ')'   { $depth--; $i++ }
            when '"'   { $i = skip-quoted($v, $i, '"') }
            when "'"   { $i = skip-quoted($v, $i, "'") }
            when ','   { return True if $depth == 0; $i++ }
            default    { $i++ }
        }
    }
    False
}

sub split-top-level(Str $v --> List) is export {
    my @parts;
    my $start = 0;
    my $depth = 0;
    my $i = 0;
    my $len = $v.chars;
    my @chars := comb-cached($v);
    while $i < $len {
        given @chars[$i] {
            when '('   { $depth++; $i++ }
            when ')'   { $depth--; $i++ }
            when '"'   { $i = skip-quoted($v, $i, '"') }
            when "'"   { $i = skip-quoted($v, $i, "'") }
            when ','   {
                if $depth == 0 {
                    my $seg = $v.substr($start, $i - $start).trim;
                    @parts.push: $seg if $seg.chars;
                    $start = $i + 1;
                }
                $i++
            }
            default    { $i++ }
        }
    }
    my $last = $v.substr($start).trim;
    @parts.push: $last if $last.chars;
    @parts
}

sub skip-quoted(Str $s, Int $i, Str $q --> Int) is export {
    my $pos = $i + 1;
    my $len = $s.chars;
    my @chars := comb-cached($s);
    while $pos < $len {
        given @chars[$pos] {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $len
}

=begin pod

=head1 NAME

CSS::Minifier::Util — utility functions for CSS parsing

=head1 DESCRIPTION

Low-level helper subroutines used by the parser and normalizer.

=head2 Subs

=item C<has-top-level-comma(Str $v --> Bool)> — returns True if a
comma appears at paren depth 0 (used to detect multi-layer background
values and other comma-separated top-level constructs)

=item C<split-top-level(Str $v --> List)> — splits a string on commas
at paren depth 0, trimming each segment and skipping empty ones.
Returns a list of strings. Inverse of has-top-level-comma.

=item C<skip-quoted(Str $s, Int $i, Str $q --> Int)> — skips to the
position after a closing quote character C<$q>, handling backslash
escapes.  Returns C<$s.chars> if the closing quote is not found.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
