use CSS::Minifier::Document;
use CSS::Minifier::Util;

unit class CSS::Minifier::Parser:ver<0.0.8>:auth<zef:sasha>;

# Parser entry point: turns raw CSS into a Document tree.
# Uses brace-counting for block structure and parse-body for
# declaration extraction — no grammar dependency, so no data loss.
method parse(Str $css, Bool :$preserve-licenses = False --> Document) {
    clear-comb-cache();
    my $doc = Document.new;

    my $clean = self!extract-braceless($css, $doc, :$preserve-licenses);

    $doc.statements = self!parse-block($clean);

    $doc;
}

# Recursively parse a CSS string into top-level statements.
method !parse-block(Str $s) {
    my Statement @stmts;
    my $i = 0;
    my $len = $s.chars;
    my @chars := comb-cached($s);

    while $i < $len {
        given @chars[$i] {
            when /\s/  { $i++; next }
            when '/'   {
                if $s.substr($i, 2) eq '/*' {
                    $i = ($s.index('*/', $i+2) // $len) + 2; next
                }
                $i++; next
            }
            when '"'   { $i = skip-quoted($s, $i, '"');  next }
            when "'"   { $i = skip-quoted($s, $i, "'");  next }
            when '}'   { $i++; next }
        }

        my $brace = self!find-brace($s, $i);
        last if $brace >= $len;

        my $head = $s.substr($i, max(0, $brace - $i)).trim;
        my $end  = matching-close($s, $brace);
        my $body = $s.substr($brace + 1, max(0, $end - $brace - 1));

        if $head.starts-with('@') {
            @stmts.push: self!parse-at-rule($head, $body);
        }
        elsif $head {
            @stmts.push: self!parse-ruleset($head, $body);
        }

        $i = $end + 1;
    }

    @stmts;
}

# Find the next '{' that is not inside a string or comment.
method !find-brace(Str $s, Int $start --> Int) {
    my $i = $start;
    my $len = $s.chars;
    my @chars := comb-cached($s);

    while $i < $len {
        given @chars[$i] {
            when '{'  { return $i }
            when '"'  { $i = skip-quoted($s, $i, '"') }
            when "'"  { $i = skip-quoted($s, $i, "'") }
            when '/'  { if $s.substr($i, 2) eq '/*' {
                           $i = ($s.index('*/', $i+2) // $len) + 2
                        } else { $i++ } }
            default   { $i++ }
        }
    }
    $len
}

method !parse-at-rule(Str $head, Str $body --> AtRule) {
    my @parts = $head.split(/ \s+ /, 2);
    my $name = @parts[0].subst('@', '', :1st);
    my $prelude = @parts[1] // '';

    my Bool $has-nested-blocks = has-brace($body);

    my AtRule $ar .= new(:$name, :$prelude);

    if $has-nested-blocks {
        $ar.statements = self!parse-block($body);
    }
    else {
        $ar.declarations = parse-body($body).map({
            my $v = .value;
            my $imp = so $v ~~ s/ \s* '!important' \s* $ //;
            Declaration.new(:property(.key), :value($v.trim), :important($imp));
        }).List;
    }

    $ar;
}

method !parse-ruleset(Str $head, Str $body --> RuleSet) {
    my @selectors = self!split-selectors($head);
    self!normalize-combinator-spacing(@selectors);
    my @decls = parse-body($body);

    RuleSet.new(:@selectors, :declarations(@decls.map({
        my $v = .value;
        my $imp = so $v ~~ s/ \s* '!important' \s* $ //;
        Declaration.new(:property(.key), :value($v.trim), :important($imp));
    })));
}

# Split selector text by top-level commas and normalize spacing
# around combinators (+, >, ~).  This prevents re-minification
# growth when the raw input uses comma-separated selectors without
# spaces.
method !split-selectors(Str $sel --> List) {
    my @parts;
    my $start = 0;
    my $bracket = 0;
    my $paren = 0;
    my $i = 0;
    my $sel-chars = $sel.chars;
    my @chars := comb-cached($sel);
    while $i < $sel-chars {
        given @chars[$i] {
            when '[' { $bracket++; $i++ }
            when ']' { $bracket--; $i++ }
            when '(' { $paren++;  $i++ }
            when ')' { $paren--;  $i++ }
            when '"' { $i = skip-quoted($sel, $i, '"') }
            when "'" { $i = skip-quoted($sel, $i, "'") }
            when ',' {
                if $bracket == 0 && $paren == 0 {
                    @parts.push: $sel.substr($start, $i - $start).trim;
                    $i++;
                    while $i < $sel-chars && @chars[$i] ~~ /\s/ { $i++ }
                    $start = $i;
                } else { $i++ }
            }
            default { $i++ }
        }
    }
    my $last = $sel.substr($start).trim if $start < $sel-chars;
    @parts.push: $last if $last;
    @parts;
}

method !normalize-combinator-spacing(@parts) {
    for @parts -> $p is rw {
        my $out = '';
        my $bracket = 0;
        my $paren = 0;
        my $i = 0;
        my $p-chars = $p.chars;
        my @p-chars := comb-cached($p);
        while $i < $p-chars {
            my $c = @p-chars[$i];
            given $c {
                when '[' { $bracket++; $out ~= '['; $i++ }
                when ']' { $bracket--; $out ~= ']'; $i++ }
                when '(' { $paren++;  $out ~= '('; $i++ }
                when ')' { $paren--;  $out ~= ')'; $i++ }
                when '"' { my $e = skip-quoted($p, $i, '"');  $out ~= $p.substr($i, $e - $i); $i = $e }
                when "'" { my $e = skip-quoted($p, $i, "'"); $out ~= $p.substr($i, $e - $i); $i = $e }
                when /\s/ {
                    if $bracket == 0 && $paren == 0 {
                        $out = $out.trim ~ ' ';
                        $i++;
                        while $i < $p-chars && @p-chars[$i] ~~ /\s/ { $i++ }
                    } else {
                        $out ~= $c; $i++;
                    }
                }
                when '+' | '>' | '~' {
                    if $bracket == 0 && $paren == 0 {
                        $out = $out.trim ~ " $c ";
                        $i++;
                        while $i < $p-chars && @p-chars[$i] ~~ /\s/ { $i++ }
                    } else {
                        $out ~= $c; $i++;
                    }
                }
                default { $out ~= $c; $i++ }
            }
        }
        $p = $out.trim;
    }
}

# Extract braceless at-rules (@import, @charset, @namespace) and
# optionally /*! */ license comments. Returns the remaining CSS.
method !extract-braceless(Str $css, Document $doc, Bool :$preserve-licenses --> Str) {
    my $out = '';
    my $i = 0;
    my $depth = 0;
    my $len = $css.chars;
    my @chars := comb-cached($css);
    my ($buf, $in-license);

    while $i < $len {
        given @chars[$i] {
            when '{'  { if $in-license { $buf ~= '{'; $i++; next }; $depth++; $out ~= '{'; $i++; next }
            when '}'  { if $in-license { $buf ~= '}'; $i++; next }; $depth--; $out ~= '}'; $i++; next }
            when '@'  {
                if $depth == 0 && $css.substr($i) ~~ / ^ \@ (import|charset|namespace) / {
                    my $end = find-semicolon($css, $i + $/.chars);
                    if $end.defined {
                        $doc.braceless.push: $css.substr($i, $end - $i + 1);
                        $i = $end + 1;
                        next;
                    }
                }
            }
            when '"'  {
                if $in-license { $buf ~= @chars[$i]; $i++; next }
                my $e = skip-quoted($css, $i, '"'); $out ~= $css.substr($i, $e - $i); $i = $e; next
            }
            when "'"  {
                if $in-license { $buf ~= @chars[$i]; $i++; next }
                my $e = skip-quoted($css, $i, "'"); $out ~= $css.substr($i, $e - $i); $i = $e; next
            }
            when '/'  {
                if $in-license { $buf ~= '/'; $i++; next }
                if $css.substr($i,3) eq '/*!' && $preserve-licenses {
                    $in-license = True;
                    $buf = '/*!';
                    $i += 3;
                    next;
                }
                if $css.substr($i,2) eq '/*' {
                    $i = ($css.index('*/', $i+2) // $len) + 2;
                    next;
                }
            }
        }

        # Inside a license comment: check for closing */ (starts with *,
        # so * falls through the given above; / is handled by when '/' and
        # appends to $buf before next — / can never close */).
        if $in-license {
            if $css.substr($i,2) eq '*/' {
                $buf ~= '*/';
                $doc.licenses.push: $buf;
                $in-license = False;
                $i += 2;
                next;
            }
            $buf ~= @chars[$i];
        }
        else {
            $out ~= @chars[$i];
        }
        $i++;
    }

    $out;
}

# Find the matching closing brace, handling strings and comments.
sub matching-close(Str $s, Int $start --> Int) is export {
    my $depth = 1;
    my $i = $start + 1;
    my $len = $s.chars;
    my @chars := comb-cached($s);
    while $i < $len && $depth > 0 {
        given @chars[$i] {
            when '{'  { $depth++; $i++ }
            when '}'  { $depth--; $i++ }
            when '"'  { $i = skip-quoted($s, $i, '"')  }
            when "'"  { $i = skip-quoted($s, $i, "'")  }
            when '/'  { if $s.substr($i, 2) eq '/*' {
                           $i = ($s.index('*/', $i+2) // $len) + 2
                        } else { $i++ } }
            default   { $i++ }
        }
    }
    $i - 1
}

sub has-brace(Str $s --> Bool) {
    my $i = 0;
    my $len = $s.chars;
    my @chars := comb-cached($s);
    while $i < $len {
        given @chars[$i] {
            when '{' { return True }
            when '"' { $i = skip-quoted($s, $i, '"'); next }
            when "'" { $i = skip-quoted($s, $i, "'"); next }
            when '/'  { if $s.substr($i, 2) eq '/*' {
                           $i = ($s.index('*/', $i+2) // $len) + 2
                        } else { $i++ } }
        }
        $i++;
    }
    False
}

sub find-semicolon(Str $s, Int $start --> Int) {
    my $i = $start;
    my $depth = 0;
    my $len = $s.chars;
    my @chars := comb-cached($s);
    while $i < $len {
        given @chars[$i] {
            when '('  { $depth++; $i++ }
            when ')'  { $depth--; $i++ }
            when '"'  { $i = skip-quoted($s, $i, '"');  next }
            when "'"  { $i = skip-quoted($s, $i, "'");  next }
            when '/'  { if $s.substr($i, 2) eq '/*' {
                           $i = ($s.index('*/', $i+2) // $len) + 2; next
                        }
                        $i++ }
            when ';'  { return $i if $depth == 0 }
            default   { $i++ }
        }
    }
    Nil
}

# Parse declarations from the body of a ruleset or declaration-only at-rule.
# Returns a list of Pair("key" => "value").
sub parse-body(Str $body --> List) is export(:parse-body) {
    my @decls;
    my $i = 0;
    my $len = $body.chars;
    my @chars := comb-cached($body);

    while $i < $len {
        while $i < $len {
            given @chars[$i] {
                when /\s/ { $i++ }
                when ';'  { $i++ }
                when '}'  { $i++; return @decls }
                when '/'  { if $body.substr($i, 2) eq '/*' {
                               $i = ($body.index('*/', $i+2) // $len) + 2
                            } else { last } }
                default   { last }
            }
        }
        last if $i >= $len;

        my $key = '';
        my $depth = 0;
        while $i < $len {
            given @chars[$i] {
                when '('   { $depth++; $key ~= '('; $i++ }
                when ')'   { $depth--;  $key ~= ')'; $i++ }
                when ':'   { $i++; last if $depth == 0; $key ~= ':' }
                when '"'   { my $end = skip-quoted($body, $i, '"');  $key ~= $body.substr($i, $end - $i); $i = $end }
                when "'"   { my $end = skip-quoted($body, $i, "'");  $key ~= $body.substr($i, $end - $i); $i = $end }
                when '/'   { if $body.substr($i,2) eq '/*' {
                                my $end = ($body.index('*/', $i+2) // $len) + 2; $i = $end
                             } else { $key ~= '/'; $i++ } }
                default    { $key ~= @chars[$i]; $i++ }
            }
        }

        while $i < $len && @chars[$i] ~~ /\s/ { $i++ }

        my $value = '';
        $depth = 0;
        while $i < $len {
            given @chars[$i] {
                when '('   { $depth++; $value ~= '('; $i++ }
                when ')'   { $depth--;  $value ~= ')'; $i++ }
                when ';'   { $i++; last if $depth == 0; $value ~= ';' }
                when '}'   { last if $depth == 0; $value ~= '}'; $i++ }
                when '"'   { my $end = skip-quoted($body, $i, '"');  $value ~= $body.substr($i, $end - $i); $i = $end }
                when "'"   { my $end = skip-quoted($body, $i, "'");  $value ~= $body.substr($i, $end - $i); $i = $end }
                when '/'   { if $body.substr($i, 2) eq '/*' {
                                my $end = ($body.index('*/', $i+2) // $len) + 2; $i = $end
                             } else { $value ~= '/'; $i++ } }
                default    { $value ~= @chars[$i]; $i++ }
            }
        }

        @decls.push: $key.trim => $value.trim;
    }

    @decls
}

=begin pod

=head1 NAME

CSS::Minifier::Parser — custom brace-counting CSS parser

=head1 DESCRIPTION

Parses raw CSS into a Document tree using brace-counting and
character-level scanning — no grammar dependency, so no data loss.
Handles strings (single/double quotes with escapes), comments,
braceless at-rules (C<@import>, C<@charset>, C<@namespace>), and
recursive block structure for nested at-rules.

=head2 Methods

=item C<parse(Str $css, Bool :$preserve-licenses --> Document)>
— parses CSS and returns a Document tree.  When C<:$preserve-licenses>
is True, C</*! */> comments are extracted into C<Document.licenses>.

=head1 EXPORTED SUBS

=item C<parse-body(Str $body --> List)> — parses the body of a ruleset
or declaration-only at-rule into a list of key => value Pair objects.
=item C<matching-close(Str $s, Int $start --> Int)> — finds the
matching closing brace for an opening brace at C<$start>, respecting
strings and comments.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
