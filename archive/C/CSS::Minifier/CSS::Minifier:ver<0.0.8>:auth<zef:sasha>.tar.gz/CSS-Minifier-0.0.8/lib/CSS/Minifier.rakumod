use CSS::Minifier::Document;
use CSS::Minifier::Parser;
use CSS::Minifier::Normalizer;
use CSS::Minifier::Writer;
use CSS::Minifier::Pipeline;
use CSS::Minifier::Plugin::Dedup;
use CSS::Minifier::Plugin::Merging;

unit class CSS::Minifier:ver<0.0.8>:auth<zef:sasha>;

method minify(Str $css, :$level = 2, Bool :$verbose = False, Bool :$preserve-licenses,
    Bool :$color-masks = True, Bool :$color-names = False,
    :@extra-plugins, Str :$sep = '', *%opts) returns Str {

    die "Invalid level: $level (must be 1 or 2)" unless $level ~~ 1|2;

    my $parser = CSS::Minifier::Parser.new;
    my $doc = $parser.parse($css, :$preserve-licenses);

    my $normalizer = CSS::Minifier::Normalizer.new;
    $normalizer.normalize($doc);

    if $level >= 2 {
        my @plugins;
        for @extra-plugins -> $p {
            die "Extra plugin {$p.^name} does not implement CSS::Minifier::Plugin"
                unless $p ~~ CSS::Minifier::Plugin;
            @plugins.push: $p;
        }
        @plugins.push: CSS::Minifier::Plugin::Dedup.new;
        @plugins.push: CSS::Minifier::Plugin::Merging.new;

        my $pipeline = CSS::Minifier::Pipeline.new(:$verbose, :@plugins);
        $pipeline.run($doc);
    }

    my $writer = CSS::Minifier::Writer.new(:$color-masks, :$color-names, :$sep);
    $writer.write-document($doc);
}

=begin pod

=head1 NAME

CSS::Minifier — CSS minification library

=head1 SYNOPSIS

=begin code :lang<raku>

use CSS::Minifier;

my $min = CSS::Minifier.minify($css, :level(2));

=end code

=head1 DESCRIPTION

C<CSS::Minifier> produces smaller CSS through value normalization,
color shortening, shorthand consolidation, and structural
deduplication/merging.

Two optimization levels are available:

=item Level 1 — safe normalizations (color shortening, font-weight
normalization, zero-unit removal, quote normalization, comment
removal, shorthand consolidation)
=item Level 2 — structural optimizations (duplicate ruleset and
C<@font-face> removal, same-selector ruleset merging,
same-declaration selector combination)

Shorthand consolidation covers C<margin>, C<padding>, C<border>,
C<border>-{top,right,bottom,left}, C<outline>, C<list-style>,
C<background> (single and multi-layer), and C<font>.

Custom properties (C<--*>) are preserved verbatim and not
deduplicated.

=head2 Options

=item C<:$level> — optimization level (1 or 2, default 2)
=item C<:$verbose> — log plugin names to stderr
=item C<:$preserve-licenses> — keep C</*! */> license comments
=item C<:$color-masks> — hex color shortening (default True)
=item C<:$color-names> — convert hex to named colors (default False)
=item C<:@extra-plugins> — additional plugin objects implementing
the C<CSS::Minifier::Plugin> role
=item C<:$sep> — separator between top-level statements (default '')

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
