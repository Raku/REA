use CSS::Minifier::Document;
use CSS::Minifier::Util;

unit class CSS::Minifier::Parser:ver<0.0.11>:auth<zef:sasha>;

# Parser entry point: turns raw CSS into a Document tree.
# Uses brace-counting for block structure and parse-body for
# declaration extraction.
method parse(Str $css, Bool :$preserve-licenses = False --> Document) {
    my $doc = Document.new;

    my $clean = self!extract-braceless($css, $doc, :$preserve-licenses);

    $doc.statements = self!parse-block($clean);

    $doc;
}

# Recursively parse a CSS string into top-level statements.
method !parse-block(Str $s) {
    my Statement @stmts;
    my $i = 0;
    my $len = $s.chars;
    my @chars := comb-cached($s);

    while $i < $len {
        given @chars[$i] {
            when ' ' | "\t" | "\n" | "\r" | "\f"  { $i++; next }
            when '"'   { $i = skip-quoted($s, $i, '"');  next }
            when "'"   { $i = skip-quoted($s, $i, "'");  next }
            when '}'   { $i++; next }
            when '/'  {
                if $i + 1 < $len && @chars[$i+1] eq '*' {
                    my $end = $s.index('*/', $i+2);
                    $i = ($end // $len - 2) + 2;
                    next;
                }
                $i++; next
            }
        default {
            next if @chars[$i] eq '@' && self!extract-braceless-at($s, $i, @stmts);
        }
        }

        my ($brace, $close) = self!find-block-range($s, $i);
        last if $brace >= $len;

        my $head = $s.substr($i, max(0, $brace - $i)).trim;
        my $body = $s.substr($brace + 1, max(0, $close - $brace - 1));

        if $head.starts-with('@') {
            @stmts.push: self!parse-at-rule($head, $body);
        }
        elsif $head {
            @stmts.push: self!parse-ruleset($head, $body);
        }

        $i = $close + 1;
    }

    @stmts;
}

# Single-pass block scanner — returns (brace-pos, close-pos).
method !find-block-range(Str $s, Int $start --> List) {
    my $i = $start;
    my $len = $s.chars;
    my @chars := comb-cached($s);
    my $depth = 0;
    my Int $brace = Nil;

    while $i < $len {
        given @chars[$i] {
            when '{'  {
                if $depth == 0 {
                    $brace = $i;
                    $depth = 1;
                } else {
                    $depth++;
                }
                $i++
            }
            when '}'  {
                $depth-- if $depth > 0;
                if $depth == 0 {
                    return ($brace, $i);
                }
                $i++
            }
            when '"'  { $i = skip-quoted($s, $i, '"')  }
            when "'"  { $i = skip-quoted($s, $i, "'")  }
            when '/'  {
                if $i + 1 < $len && @chars[$i+1] eq '*' {
                    $i = ($s.index('*/', $i+2) // $len - 2) + 2;
                } else { $i++ }
            }
            default   { $i++ }
        }
    }
    ($brace // $len, $len)
}

# Convert a parse-body Pair ("key" => "value") into a Declaration,
# stripping trailing !important.
method !make-declaration(Pair $p --> Declaration) {
    my $v = $p.value;
    my $imp = so $v ~~ s:i/ \s* '!important' \s* $ //;
    Declaration.new(:property($p.key), :value($v.trim), :important($imp));
}

# Shared helper: extract a braceless at-rule starting at $pos in $src.
# On success pushes the parsed AtRule to @target, advances $pos past it,
# and returns True.  On failure $pos is unchanged and returns False.
method !extract-braceless-at(Str $src, Int $pos is rw, @target --> Bool) {
    my $end = find-braceless-end($src, $pos);
    return False unless $end.defined && $end < $src.chars;
    my $raw = $src.substr($pos, $end - $pos + 1);
    my $h = strip-braceless-comments($raw).trim;
    $h .= substr(0, *-1) if $h.ends-with(';');
    $h = $h.trim;
    @target.push: self!parse-at-rule($h, '', :braceless) if $h.starts-with('@');
    $pos = $end + 1;
    True
}

method !parse-at-rule(Str $head, Str $body, Bool :$braceless = False --> AtRule) {
    my @parts = $head.split(/ \s+ /, 2);
    my $name = @parts[0].subst('@', '', :1st);
    my $prelude = @parts[1] // '';

    my AtRule $ar .= new(:$name, :$prelude, :$braceless);
    return $ar if $braceless;

    my ($brace, $) = self!find-block-range($body, 0);

    if $brace >= $body.chars {
        $ar.declarations = parse-body($body).map({ self!make-declaration($_) }).List;
        return $ar;
    }

    my @declarations;
    my @statements;
    my $pos = 0;
    my $len = $body.chars;
    my @body-chars := comb-cached($body);

    loop {
        # Collect braceless at-rules before the next block
        while $pos < $len {
            if @body-chars[$pos] ~~ ' ' | "\t" | "\n" | "\r" | "\f" { $pos++; next }
            next if @body-chars[$pos] eq '@' && self!extract-braceless-at($body, $pos, @statements);
            last;
        }
        last if $pos >= $len;

        my ($b, $c) = self!find-block-range($body, $pos);
        last if $b >= $len;

        # Scan gap text for braceless at-rules and declarations
        my $before = $body.substr($pos, $b - $pos);
        if $before.trim {
            my $gpos = 0;
            my $glen = $before.chars;
            my @gchars := comb-cached($before);
            my $decl-buf = '';

            while $gpos < $glen {
                while $gpos < $glen && @gchars[$gpos] ~~ ' ' | "\t" | "\n" | "\r" | "\f" { $gpos++ }
                last if $gpos >= $glen;

                next if @gchars[$gpos] eq '@' && self!extract-braceless-at($before, $gpos, @statements);

                my $semi = $before.index(';', $gpos);
                if $semi.defined {
                    $decl-buf ~= $before.substr($gpos, $semi - $gpos + 1);
                    $gpos = $semi + 1;
                } else {
                    $decl-buf ~= $before.substr($gpos);
                    $gpos = $glen;
                }
            }

            if $decl-buf.trim {
                my $semi = $decl-buf.rindex(';');
                if $semi.defined {
                    my @decls = parse-body($decl-buf.substr(0, $semi))
                        .grep({ !.key.starts-with('@') });
                    @declarations.append(@decls.map({ self!make-declaration($_) }));
                    $before = $decl-buf.substr($semi + 1);
                } else {
                    my @tries = parse-body($decl-buf)
                        .grep({ !.key.starts-with('@') });
                    if @tries == 1 {
                        my $val = @tries[0].value;
                        my $sp = $val.rindex(' ');
                        if $sp.defined {
                            my $tok = $val.substr($sp + 1);
                            if $tok.starts-with('.') || $tok.starts-with('#')
                                || $tok.starts-with('[') || $tok.starts-with(':') {
                                @tries[0] = @tries[0].key => $val.substr(0, $sp).trim;
                                @declarations.push(self!make-declaration(@tries[0]));
                                $before = $tok;
                            } else {
                                $before = $decl-buf;
                            }
                        } else {
                            $before = $decl-buf;
                        }
                    } else {
                        $before = $decl-buf;
                    }
                }
            } else {
                $before = '';
            }
        }

        my $head-text = $before.trim;
        my $inner = $body.substr($b + 1, $c - $b - 1);

        if $head-text.starts-with('@') {
            @statements.push: self!parse-at-rule($head-text, $inner);
        } elsif $head-text {
            @statements.push: self!parse-ruleset($head-text, $inner);
        }

        $pos = $c + 1;
    }

    if $pos < $len {
        my $trailing = $body.substr($pos);
        if $trailing.trim {
            $ar.trailing-declarations = parse-body($trailing)
                .grep({ !.key.starts-with('@') })
                .map({ self!make-declaration($_) }).List;
        }
    }

    $ar.declarations = @declarations.List;
    $ar.statements = @statements;
    $ar;
}

method !parse-ruleset(Str $head, Str $body --> RuleSet) {
    my @selectors = self!split-selectors($head);
    self!normalize-combinator-spacing(@selectors);
    my @decls = parse-body($body);

    RuleSet.new(:@selectors, :declarations(@decls.map({ self!make-declaration($_) })));
}

# Split selector text by top-level commas and normalize spacing
# around combinators (+, >, ~).  This prevents re-minification
# growth when the raw input uses comma-separated selectors without
# spaces.
method !split-selectors(Str $sel --> List) {
    my @parts;
    my $start = 0;
    my $bracket = 0;
    my $paren = 0;
    my $i = 0;
    my $sel-chars = $sel.chars;
    my @chars := comb-cached($sel);
    while $i < $sel-chars {
        given @chars[$i] {
            when '[' { $bracket++; $i++ }
            when ']' { $bracket--; $i++ }
            when '(' { $paren++;  $i++ }
            when ')' { $paren--;  $i++ }
            when '"' { $i = skip-quoted($sel, $i, '"') }
            when "'" { $i = skip-quoted($sel, $i, "'") }
            when ',' {
                if $bracket == 0 && $paren == 0 {
                    @parts.push: $sel.substr($start, $i - $start).trim;
                    $i++;
                    while $i < $sel-chars && @chars[$i] ~~ ' ' | "\t" | "\n" | "\r" | "\f" { $i++ }
                    $start = $i;
                } else { $i++ }
            }
            default { $i++ }
        }
    }
    my $last = $sel.substr($start).trim if $start < $sel-chars;
    @parts.push: $last if $last;
    @parts;
}

method !normalize-combinator-spacing(@parts) {
    for @parts -> $sel is rw {
        my $out = '';
        my $bracket = 0;
        my $paren = 0;
        my $i = 0;
        my $last-comb = '';
        my $sel-chars = $sel.chars;
        my @sel-chars := comb-cached($sel);
        while $i < $sel-chars {
            my $c = @sel-chars[$i];
            given $c {
                when '[' { $bracket++; $out ~= '['; $i++ }
                when ']' { $bracket--; $out ~= ']'; $i++; $last-comb = '' if $bracket == 0 }
                when '(' { $paren++;  $out ~= '('; $i++ }
                when ')' { $paren--; $out ~= ')'; $i++; $last-comb = '' if $paren == 0 }
                when '"' { my $e = skip-quoted($sel, $i, '"');  $out ~= $sel.substr($i, $e - $i); $i = $e }
                when "'" { my $e = skip-quoted($sel, $i, "'"); $out ~= $sel.substr($i, $e - $i); $i = $e }
                when ' ' | "\t" | "\n" | "\r" | "\f" {
                    if $bracket == 0 && $paren == 0 {
                        $out = $out.trim ~ ' ';
                        $i++;
                        while $i < $sel-chars && @sel-chars[$i] ~~ ' ' | "\t" | "\n" | "\r" | "\f" { $i++ }
                    } else {
                        $out ~= $c; $i++;
                    }
                }
                when '+' | '>' | '~' {
                    if $bracket == 0 && $paren == 0 {
                        if $last-comb ne $c {
                            $out = $out.trim ~ " $c ";
                            $last-comb = $c;
                        }
                        $i++;
                        while $i < $sel-chars && @sel-chars[$i] ~~ ' ' | "\t" | "\n" | "\r" | "\f" { $i++ }
                    } else {
                        $out ~= $c; $i++;
                    }
                }
                when '|'  {
                    if $i + 1 < $sel-chars && @sel-chars[$i+1] eq '|' {
                        if $bracket == 0 && $paren == 0 {
                            if $last-comb ne '||' {
                                $out = $out.trim ~ ' || ';
                                $last-comb = '||';
                            }
                            $i += 2;
                            while $i < $sel-chars && @sel-chars[$i] ~~ ' ' | "\t" | "\n" | "\r" | "\f" { $i++ }
                        } else {
                            $out ~= '||'; $i += 2;
                        }
                    } else {
                        $out ~= '|'; $i++; $last-comb = '';
                    }
                }
                default { $out ~= $c; $i++; $last-comb = '' }
            }
        }
        $sel = $out.trim;
    }
}

# Extract /*! */ license comments and return remaining CSS.
method !extract-braceless(Str $css, Document $doc, Bool :$preserve-licenses --> Str) {
    return $css unless $css.contains('/*');
    my $out = '';
    my $i = 0;
    my $len = $css.chars;
    my @chars := comb-cached($css);
    my Str $buf = '';
    my Bool $in-license = False;
    my Int  $license-depth = 0;
    while $i < $len {
        given @chars[$i] {
            # Inside a license comment: buffer everything until */ closes
            when '/'  {
                if $in-license {
                    if $css.substr-eq('/*', $i) {
                        $license-depth++; $buf ~= '/*'; $i += 2; next
                    }
                    $buf ~= '/'; $i++; next
                }
                if $css.substr-eq('/*!', $i) && $preserve-licenses {
                    $in-license = True; $license-depth = 1; $buf = '/*!'; $i += 3; next
                }
                if $css.substr-eq('/*', $i) {
                    $i = ($css.index('*/', $i+2) // $len - 2) + 2; next
                }
            }
            when '*' {
                if $in-license {
                    if $i + 1 < $len && @chars[$i+1] eq '/' {
                        $license-depth--; $buf ~= '*/'; $i += 2;
                        if $license-depth == 0 {
                            $doc.licenses.push: $buf; $in-license = False;
                        }
                        next;
                    }
                    $buf ~= '*'; $i++; next
                }
                # Stray */ — skip silently
                if $i + 1 < $len && @chars[$i+1] eq '/' { $i += 2; next }
            }
            when '"'  {
                my $end = skip-quoted($css, $i, '"');
                if $in-license { $buf ~= $css.substr($i, $end - $i); $i = $end; next }
                $out ~= $css.substr($i, $end - $i); $i = $end; next
            }
            when "'"  {
                my $end = skip-quoted($css, $i, "'");
                if $in-license { $buf ~= $css.substr($i, $end - $i); $i = $end; next }
                $out ~= $css.substr($i, $end - $i); $i = $end; next
            }
            when '@'  {
                if $in-license { $buf ~= '@'; $i++; next }
                $out ~= '@'; $i++; next
            }
        }

        if $in-license {
            $buf ~= @chars[$i];
        } else {
            $out ~= @chars[$i];
        }
        $i++;
    }

    if $in-license {
        $doc.licenses.push: $buf;
        $in-license = False;
    }
    $out;
}

# Strip comments from braceless at-rule text, preserving quoted strings.
sub strip-braceless-comments(Str $raw --> Str) is export {
    my $clean = '';
    my $j = 0;
    my $rlen = $raw.chars;
    my @rchars := comb-cached($raw);
    while $j < $rlen {
        if @rchars[$j] eq '"' || @rchars[$j] eq "'" {
            my $qend = skip-quoted($raw, $j, @rchars[$j]);
            $clean ~= $raw.substr($j, $qend - $j);
            $j = $qend;
        } elsif @rchars[$j] eq '/' && $j + 1 < $rlen && @rchars[$j+1] eq '*' {
            $clean ~~ s/ \s+ $//;
            my $cend = $raw.index('*/', $j+2);
            $j = ($cend // $rlen - 2) + 2;
            $j++ while $j < $rlen && @rchars[$j] eq ' ';
            $clean ~= ' ' unless $j >= $rlen || @rchars[$j] eq ';';
        } else {
            $clean ~= @rchars[$j];
            $j++;
        }
    }
    $clean;
}

# Find the end of a braceless at-rule: semicolon at top level.
# Returns Nil if a { is encountered first (block at-rule).
sub find-braceless-end(Str $s, Int $start --> Int) is export {
    my $i = $start;
    my $depth = 0;
    my $len = $s.chars;
    my @chars := comb-cached($s);
    while $i < $len {
        given @chars[$i] {
            when '('  { $depth++; $i++ }
            when ')'  { $depth-- if $depth > 0; $i++ }
            when '"'  { $i = skip-quoted($s, $i, '"'); next }
            when "'"  { $i = skip-quoted($s, $i, "'"); next }
            when '/'  {
                if $i + 1 < $len && @chars[$i+1] eq '*' {
                    $i = ($s.index('*/', $i+2) // $len - 2) + 2;
                } else { $i++ }
            }
            when '{'  { return Nil }
            when ';'  { return $i if $depth == 0; $i++ }
            default   { $i++ }
        }
    }
    $len
}

# Parse declarations from the body of a ruleset or declaration-only at-rule.
# Returns a list of Pair("key" => "value").
sub parse-body(Str $body --> List) is export(:parse-body) {
    my @decls;
    my $i = 0;
    my $len = $body.chars;
    my @chars := comb-cached($body);

    while $i < $len {
        while $i < $len {
            given @chars[$i] {
                when ' ' | "\t" | "\n" | "\r" | "\f" { $i++ }
                when ';'  { $i++ }
                when '}'  { $i++; return @decls }
            default   { last }
            }
        }
        last if $i >= $len;

        my $key = '';
        my $depth = 0;
        while $i < $len {
            given @chars[$i] {
                when '('   { $depth++; $key ~= '('; $i++ }
                when ')'   { $depth--;  $key ~= ')'; $i++ }
                when ':'   { $i++; last if $depth == 0; $key ~= ':' }
                when ';' | '}' { last if $depth == 0; $key ~= @chars[$i]; $i++ }
                when '"'   { my $end = skip-quoted($body, $i, '"');  $key ~= $body.substr($i, $end - $i); $i = $end }
                when "'"   { my $end = skip-quoted($body, $i, "'");  $key ~= $body.substr($i, $end - $i); $i = $end }
                default    { $key ~= @chars[$i]; $i++ }
            }
        }

        while $i < $len && @chars[$i] ~~ ' ' | "\t" | "\n" | "\r" | "\f" { $i++ }

        my $value = '';
        $depth = 0;
        while $i < $len {
            given @chars[$i] {
                when '('   { $depth++; $value ~= '('; $i++ }
                when ')'   { $depth--;  $value ~= ')'; $i++ }
                when ';'   { $i++; last if $depth == 0; $value ~= ';' }
                when '}'   { last if $depth == 0; $value ~= '}'; $i++ }
                when '"'   { my $end = skip-quoted($body, $i, '"');  $value ~= $body.substr($i, $end - $i); $i = $end }
                when "'"   { my $end = skip-quoted($body, $i, "'");  $value ~= $body.substr($i, $end - $i); $i = $end }
                default    { $value ~= @chars[$i]; $i++ }
            }
        }

        @decls.push: $key.trim => $value.trim if $key.trim;
    }

    @decls
}

=begin pod

=head1 NAME

CSS::Minifier::Parser — custom brace-counting CSS parser

=head1 DESCRIPTION

Parses raw CSS into a Document tree using brace-counting and
character-level scanning.
Handles strings (single/double quotes with escapes), comments,
braceless at-rules (C<@import>, C<@charset>, C<@namespace>), and
recursive block structure for nested at-rules.

Note: CSS native nesting (e.g. C<& b { ... }>) is not supported
and will silently misparse. Nested rulesets must be flattened
before minification. C<@keyframes> (percentage/from/to keyframe
selectors) IS handled correctly.

=head2 Methods

=item C<parse(Str $css, Bool :$preserve-licenses --> Document)>
— parses CSS and returns a Document tree.  When C<:$preserve-licenses>
is True, C</*! */> comments are extracted into C<Document.licenses>.

=head1 EXPORTED SUBS

=item C<parse-body(Str $body --> List)> — parses the body of a ruleset
or declaration-only at-rule into a list of key => value Pair objects.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
