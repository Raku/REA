use CSS::Minifier::Document;
use CSS::Minifier::Util;

my constant %SHORTHAND =
    margin      => [<margin-top    margin-right  margin-bottom margin-left>],
    padding     => [<padding-top   padding-right padding-bottom padding-left>],
    border      => [<border-width  border-style  border-color>],
    border-top  => [<border-top-width    border-top-style    border-top-color>],
    border-right=> [<border-right-width  border-right-style  border-right-color>],
    border-bottom=>[<border-bottom-width border-bottom-style border-bottom-color>],
    border-left => [<border-left-width   border-left-style   border-left-color>],
    outline     => [<outline-width outline-style outline-color>],
    list-style  => [<list-style-type list-style-position list-style-image>],
    background  => [<background-color background-image background-repeat
                     background-attachment background-position background-size
                     background-origin background-clip>],
    font        => [<font-style font-variant font-weight font-stretch font-size line-height font-family>],
;

my constant %LONGHAND-TO-SHORTHAND =
    gather for %SHORTHAND.kv -> $sh, @lhs {
        take $_ => $sh for @lhs;
    };

my constant $CSS-WIDE-RE = rx:i/ ^ (initial | inherit | unset | revert | revert\-layer) $ /;

unit class CSS::Minifier::Normalizer:ver<0.0.11>:auth<zef:sasha>;

my constant %DISPATCHABLE = Set.new(<background font>);

method normalize(Document $doc --> Nil) {
    for $doc.statements -> $stmt {
        self!walk($stmt);
    }
}

method !walk(Statement $stmt) {
    given $stmt {
        when RuleSet { self!normalize-ruleset($_) }
        when AtRule  {
            $_.declarations = self!normalize-declarations($_.declarations);
            $_.trailing-declarations = self!normalize-declarations($_.trailing-declarations);
            self!walk($_) for .statements;
        }
    }
}

method !normalize-ruleset(RuleSet $rs) {
    $rs.declarations = self!normalize-declarations($rs.declarations);
}

method !dedup-declarations(@decls) {
    my Declaration @uniq;
    my Int %seen;
    for @decls.reverse -> $d {
        my $k = $d.property.starts-with('--') ?? $d.property !! $d.property.lc;
        if %seen{$k}:exists {
            my $kept = @uniq[%seen{$k}];
            @uniq[%seen{$k}] = $d if $d.important && !$kept.important;
        } else {
            %seen{$k} = @uniq.elems;
            @uniq.push: $d;
        }
    }
    @uniq.reverse.Array;
}

method !consolidate-shorthands(@decls --> List) {
    my Declaration %by-prop;
    %by-prop{$_.property.starts-with('--') ?? $_.property !! $_.property.lc} = $_ for @decls;

    my %consolidated;
    # %by-prop maps ALL declarations by property name, including ones
    # whose shorthand already exists.  The :exists check below skips
    # groups where the user wrote the shorthand explicitly, preventing
    # double-consolidation.
    for %SHORTHAND.kv -> $shorthand, @longhands {
        next if %by-prop{$shorthand}:exists;
        next unless $shorthand ∈ %DISPATCHABLE || @longhands.all ~~ { %by-prop{$_}:exists };

        my $joined;
        my @present;
        if $shorthand ∈ %DISPATCHABLE {
            @present = @longhands.grep({ %by-prop{$_}:exists });
            next unless @present;
            if $shorthand eq 'font' {
                next unless %by-prop<font-size>.defined && %by-prop<font-family>.defined;
            }
            my @pv = @present.map({ %by-prop{$_}.value });
            next if @pv.any ~~ $UNSAFE-RE || @pv.any ~~ $CSS-WIDE-RE;
            given $shorthand {
                when 'background' { $joined = self!assemble-background(%by-prop) }
                when 'font'       { $joined = self!assemble-font(%by-prop) }
            }
            next unless $joined.defined;
        } else {
            @present = @longhands;
            my @vals = @present.map({ %by-prop{$_}.value });
            next if @vals.any ~~ $UNSAFE-RE;
            next if @vals.any ~~ $CSS-WIDE-RE;
            if $shorthand ne 'margin' && $shorthand ne 'padding' {
                next if @vals.any ~~ /\s/;
            }
            $joined = @vals.join(' ');
        }
        my @imp = @present.map({ %by-prop{$_}.important });
        next if @imp.unique.elems > 1;
        my $important = @imp[0];

        %by-prop{$_}:delete for @longhands;
        %by-prop{$shorthand} = Declaration.new(
            :property($shorthand),
            :value($joined),
            :$important,
        );
        %consolidated{$shorthand} = True;
    }

    # Preserve original order: emit shorthand at the position of its last longhand
    my %seen-group;
    my @result;
    for @decls.reverse -> $d {
        my $prop = $d.property;

        my $sh = %LONGHAND-TO-SHORTHAND{$prop};
        if $sh.defined && %consolidated{$sh} {
            # Consolidated group — emit shorthand once, skip remaining longhands
            next if %seen-group{$sh}++;
            @result.push: %by-prop{$sh};
            next;
        }
        my $k = $prop.starts-with('--') ?? $prop !! $prop.lc;
        @result.push: %by-prop{$k} if %by-prop{$k}:exists;
    }
    @result.reverse.Array;
}

method !assemble-background(%by-prop --> Str) {
    for <background-color background-image background-repeat
         background-attachment background-position background-size
         background-origin background-clip> -> $p {
        if %by-prop{$p} && split-top-level(%by-prop{$p}.value).elems > 1 {
            return self!assemble-background-multi(%by-prop);
        }
    }
    self!assemble-background-single(%by-prop)
}

method !origin-clip-parts($origin, $clip --> List) {
    if $origin.defined && $clip.defined {
        return $origin eq $clip ?? ($origin,) !! ($origin, $clip);
    }
    if $origin.defined { return ($origin, 'border-box') }
    if $clip.defined   { return ('padding-box', $clip) }
    ()
}

method !assemble-background-single(%by-prop --> Str()) {
    my @parts;
    for <background-color background-image background-repeat
         background-attachment> -> $p {
        next without %by-prop{$p};
        @parts.push: %by-prop{$p}.value;
    }

    # position [ / size ]
    my $pos  = %by-prop<background-position>;
    my $size = %by-prop<background-size>;
    if $pos || $size {
        @parts.push: ($pos ?? $pos.value !! '0% 0%')
                    ~ ($size ?? ' / ' ~ $size.value !! '');
    }

    # origin / clip
    my $origin = %by-prop<background-origin>;
    my $clip   = %by-prop<background-clip>;
    if $origin || $clip {
        @parts.append: self!origin-clip-parts(
            $origin ?? $origin.value !! Nil,
            $clip   ?? $clip.value   !! Nil,
        );
    }
    return Nil unless @parts;
    @parts.join(' ')
}

method !build-background-layer(%vals, Int $i --> Str()) {
    my @parts;
    for <background-image background-repeat background-attachment> -> $p {
        %vals{$p}:exists or next;
        @parts.push: %vals{$p}[$i % %vals{$p}.elems];
    }
    my $pos  = %vals<background-position>
               ?? %vals<background-position>[$i % %vals<background-position>.elems]
               !! Nil;
    my $size = %vals<background-size>
               ?? %vals<background-size>[$i % %vals<background-size>.elems]
               !! Nil;
    if $pos || $size {
        @parts.push: ($pos // '0% 0%') ~ ($size ?? ' / ' ~ $size !! '');
    }
    my $origin = %vals<background-origin>
                 ?? %vals<background-origin>[$i % %vals<background-origin>.elems]
                 !! Nil;
    my $clip   = %vals<background-clip>
                 ?? %vals<background-clip>[$i % %vals<background-clip>.elems]
                 !! Nil;
    if $origin || $clip {
        @parts.append: self!origin-clip-parts($origin, $clip);
    }
    return Nil unless @parts;
    @parts.join(' ');
}

method !assemble-background-multi(%by-prop --> Str()) {
    my $color = %by-prop<background-color>
                ?? %by-prop<background-color>.value
                !! Nil;

    my %vals;
    for <background-image background-repeat background-attachment
         background-position background-size
         background-origin background-clip> -> $p {
        next without %by-prop{$p};
        %vals{$p} = split-top-level(%by-prop{$p}.value);
        next unless %vals{$p}.elems;
    }

    my $n = 0; $n max= .elems for %vals.values;
    return Nil unless $n;

    my @layers;
    for 0..^$n -> $i {
        my $layer = self!build-background-layer(%vals, $i);
        next unless $layer.defined;
        $layer ~= " $color" if $color.defined && $i == $n - 1;
        @layers.push: $layer;
    }

    @layers.join(',')
}

method !assemble-font(%by-prop --> Str()) {
    my $size   = %by-prop<font-size> ?? %by-prop<font-size>.value !! Nil;
    my $family = %by-prop<font-family> ?? %by-prop<font-family>.value !! Nil;
    return Nil unless $size.defined && $family.defined;

    my @parts;
    for <font-style font-variant font-weight font-stretch> -> $p {
        my $v = %by-prop{$p} ?? %by-prop{$p}.value !! 'normal';
        if $p eq 'font-weight' {
            $v = '700' if $v.lc eq 'bold';
            next if $v eq 'normal' || $v eq '400';
        } elsif $p eq 'font-stretch' {
            next if $v eq 'normal';
        } else {
            next if $v eq 'normal';
        }
        @parts.push: $v;
    }
    @parts.push: $size;

    if %by-prop<line-height> -> $lh {
        return Nil if $lh.value ~~ $CSS-WIDE-RE;
        @parts[*-1] ~= '/' ~ $lh.value;
    }

    @parts.push: $family;
    @parts.join(' ');
}

method !normalize-declarations(@decls --> List) {
    self!consolidate-shorthands(self!dedup-declarations(@decls))
}

=begin pod

=head1 NAME

CSS::Minifier::Normalizer — declaration normalization and dedup

=head1 DESCRIPTION

Walks the document tree and deduplicates declarations (last-wins).

=head2 Methods

=item C<normalize(Document $doc)> — walks the document tree and
normalizes all declarations in place

=item C<!assemble-background(%by-prop)> — assembles background shorthand
from present longhands; handles both single and multi-layer
(comma-separated) backgrounds. Includes background-size via position/size
syntax, background-origin and background-clip as box values; defaults
position to 0% 0% when size present without position. Multi-layer
handles cycling per CSS spec when layer counts differ across longhands.

=item C<!assemble-font(%by-prop)> — assembles font shorthand from
font-size and font-family (required) plus font-style, font-variant,
font-weight (optional) and line-height (optional, consumed into
size/line-height syntax if present); normalizes bold→700, normal→400;
skips default values

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
