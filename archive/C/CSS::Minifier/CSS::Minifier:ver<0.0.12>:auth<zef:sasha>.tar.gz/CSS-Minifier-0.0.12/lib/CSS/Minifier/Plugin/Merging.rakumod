use CSS::Minifier::Document;
use CSS::Minifier::Plugin;
use CSS::Minifier::Util;

class CSS::Minifier::Plugin::Merging:ver<0.0.12>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'merging' }

    method run(Document $doc --> Nil) {
        $doc.statements = self!merge-same-declarations($doc.statements);
        $doc.statements = self!merge-adjacent-same-selectors($doc.statements);
        self!dedup-selector-lists($doc.statements);
    }

    # --- Same-declaration merging ---
    # Adjacent rulesets with identical declarations have their
    # selectors combined into a comma-separated list.
    method !merge-same-declarations(Statement @stmts) {
        my Statement @result = self!merge-same-in-list(@stmts);
        for @result -> $stmt {
            if $stmt ~~ AtRule {
                $stmt.statements = self!merge-same-declarations($stmt.statements);
            }
        }
        @result;
    }

    method !merge-same-in-list(Statement @stmts --> Array[Statement]) {
        my Statement @merged;
        my int $i;

        while $i < @stmts {
            my $current = @stmts[$i];
            $i++;

            given $current {
                when RuleSet {
                    unless .declarations {
                        @merged.push: $current;
                        next;
                    }
                    # Same-decl-key merge would drop custom property duplicates
                    if .declarations.first({ is-custom-prop(.property) }) {
                        @merged.push: $current;
                        next;
                    }

                    my $cur = $_;
                    $cur.decl-key ||= declarations-to-key($cur.declarations);

                    while $i < @stmts {
                        my $next = @stmts[$i];
                        given $next {
                            when RuleSet {
                                unless .declarations { $i++; next }
                                $next.decl-key = declarations-to-key($next.declarations) unless $next.decl-key;
                                last unless $next.decl-key eq $cur.decl-key;
                                $current.selectors.append: .selectors;
                            }
                            when AtRule {
                                if .declarations || .statements || .trailing-declarations || .braceless { last }
                                $i++;
                                next;
                            }
                        }
                        $i++;
                    }
                    @merged.push: $current;
                }
                when AtRule {
                    @merged.push: $current;
                }
            }
        }

        @merged;
    }

    # --- Same-selector merging ---
    # Adjacent rulesets with the same selectors have their
    # declarations combined (respecting !important).
    method !merge-adjacent-same-selectors(Statement @stmts) {
        my Statement @result = self!merge-sel-in-list(@stmts);
        for @result -> $stmt {
            if $stmt ~~ AtRule {
                $stmt.statements = self!merge-adjacent-same-selectors($stmt.statements);
            }
        }
        @result;
    }

    method !merge-sel-in-list(Statement @stmts --> Array[Statement]) {
        my Statement @merged;
        my int $i;

        while $i < @stmts {
            my $current = @stmts[$i];
            $i++;

            given $current {
                when RuleSet {
                    unless .declarations {
                        @merged.push: $current;
                        next;
                    }

                    my @cur-sel = $current.selectors.sort.Array;
                    my %by-prop;
                    %by-prop{is-custom-prop(.property) ?? .property !! .property.lc} = $_ for $current.declarations;
                    while $i < @stmts {
                        my $next = @stmts[$i];
                        given $next {
                            when RuleSet {
                                unless .declarations { $i++; next }
                                my @next-sel = $next.selectors.sort.Array;
                                last unless @cur-sel eqv @next-sel;
                                self!merge-decls($current, $next, %by-prop);
                            }
                            when AtRule {
                                last if .declarations || .statements || .trailing-declarations || .braceless;
                                $i++;
                                next;
                            }
                        }
                        $i++;
                    }
                    @merged.push: $current;
                }
                when AtRule {
                    @merged.push: $current;
                }
            }
        }

        @merged;
    }

    method !merge-decls(RuleSet $target, RuleSet $source, %by-prop --> Nil) {
        for $source.declarations -> $sd {
            my $key = is-custom-prop($sd.property) ?? $sd.property !! $sd.property.lc;
            if %by-prop{$key} -> $td {
                unless $td.important && !$sd.important {
                    $td.value     = $sd.value;
                    $td.important = $sd.important;
                    $td.normalized = Str;
                }
            } else {
                my $new = Declaration.new(:property($sd.property), :value($sd.value), :important($sd.important));
                $target.declarations.push: $new;
                %by-prop{$key} = $new;
            }
        }
        $target.decl-key = Str;
    }

    # --- Selector list dedup ---
    method !dedup-selector-lists(Statement @stmts --> Nil) {
        for @stmts -> $stmt {
            given $stmt {
                when RuleSet {
                    my @uniq;
                    my %seen;
                    for .selectors -> $sel {
                        %seen{$sel}++ or @uniq.push: $sel;
                    }
                    .selectors = @uniq if @uniq.elems != .selectors.elems;
                }
                when AtRule {
                    self!dedup-selector-lists(.statements);
                }
            }
        }
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Merging — ruleset merging for the CSS minifier

=head1 DESCRIPTION

Performs two types of structural merging at level 2:

=item Same-declaration merging — adjacent rulesets with identical
declarations have their selectors combined (e.g. C<h1{color:#F00}>
C<h2{color:#F00}> → C<h1,h2{color:#F00}>).  Custom properties act
as a barrier; rulesets containing them are not merged.

=item Same-selector merging — adjacent rulesets with identical
selectors have their declarations merged.  Custom property
declarations are preserved verbatim rather than overwritten.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
