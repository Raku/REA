use CSS::Minifier::Document;
use CSS::Minifier::Plugin;

class CSS::Minifier::Plugin::Merging:ver<0.0.9>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'merging' }

    method run(Document $doc --> Nil) {
        $doc.statements = self!merge-same-declarations($doc.statements);
        $doc.statements = self!merge-adjacent-same-selectors($doc.statements);
        self!dedup-selector-lists($doc.statements);
    }

    # --- Same-declaration merging ---
    # Adjacent rulesets with identical declarations have their
    # selectors combined into a comma-separated list.
    method !merge-same-declarations(Statement @stmts) {
        my Statement @result = self!merge-same-in-list(@stmts);
        for @result -> $stmt {
            if $stmt ~~ AtRule {
                $stmt.statements = self!merge-same-declarations($stmt.statements);
            }
        }
        @result;
    }

    method !merge-same-in-list(Statement @stmts --> Array[Statement]) {
        my Statement @merged;
        my int $i;
        my %key;

        while $i < @stmts {
            my $current = @stmts[$i];
            $i++;

            given $current {
                when RuleSet {
                    unless .declarations {
                        @merged.push: $current;
                        next;
                    }
                    # Same-decl-key merge would drop custom property duplicates
                    if .declarations.first({ .property.starts-with('--') }) {
                        @merged.push: $current;
                        next;
                    }

                    my $decl-key = %key{$current.WHICH} //= declarations-to-key(.declarations);

                    while $i < @stmts {
                        my $next = @stmts[$i];
                        given $next {
                            when RuleSet {
                                last unless .declarations;
                                last unless (%key{$next.WHICH} //= declarations-to-key(.declarations)) eq $decl-key;
                                $current.selectors.append: .selectors;
                            }
                            when AtRule {
                                if .declarations || .statements { last }
                                $i++;
                                next;
                            }
                        }
                        $i++;
                    }
                    @merged.push: $current;
                }
                when AtRule {
                    @merged.push: $current;
                }
            }
        }

        @merged;
    }

    # --- Same-selector merging ---
    # Adjacent rulesets with the same selectors have their
    # declarations combined (respecting !important).
    method !merge-adjacent-same-selectors(Statement @stmts) {
        my Statement @result = self!merge-sel-in-list(@stmts);
        for @result -> $stmt {
            if $stmt ~~ AtRule {
                $stmt.statements = self!merge-adjacent-same-selectors($stmt.statements);
            }
        }
        @result;
    }

    method !merge-sel-in-list(Statement @stmts --> Array[Statement]) {
        my Statement @merged;
        my int $i;

        while $i < @stmts {
            my $current = @stmts[$i];
            $i++;

            given $current {
                when RuleSet {
                    unless .declarations {
                        @merged.push: $current;
                        next;
                    }

                    while $i < @stmts {
                        my $next = @stmts[$i];
                        given $next {
                            when RuleSet {
                                last unless .declarations;
                                last unless self!same-selectors($current, $next);
                                self!merge-decls($current, $next);
                            }
                            when AtRule {
                                last if .declarations || .statements;
                                $i++;
                                next;
                            }
                        }
                        $i++;
                    }
                    @merged.push: $current;
                }
                when AtRule {
                    @merged.push: $current;
                }
            }
        }

        @merged;
    }

    method !same-selectors(RuleSet $a, RuleSet $b --> Bool) {
        $a.selectors eqv $b.selectors
    }

    method !merge-decls(RuleSet $target, RuleSet $source --> Nil) {
        my (%important, %by-prop);
        for $target.declarations -> $d {
            %by-prop{$d.property} = $d;
            %important{$d.property} = True if $d.important;
        }

        for $source.declarations -> $sd {
            if %by-prop{$sd.property} -> $td {
                unless %important{$td.property} && !$sd.important {
                    $td.value     = $sd.value;
                    $td.important = $sd.important;
                }
            } else {
                $target.declarations.push: $sd;
            }
        }
    }

    # --- Selector list dedup ---
    method !dedup-selector-lists(Statement @stmts --> Nil) {
        for @stmts -> $stmt {
            given $stmt {
                when RuleSet {
                    my @uniq;
                    my %seen;
                    for .selectors -> $sel {
                        %seen{$sel}++ or @uniq.push: $sel;
                    }
                    .selectors = @uniq if @uniq.elems != .selectors.elems;
                }
                when AtRule {
                    self!dedup-selector-lists(.statements);
                }
            }
        }
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Merging — ruleset merging for the CSS minifier

=head1 DESCRIPTION

Performs two types of structural merging at level 2:

=item Same-declaration merging — adjacent rulesets with identical
declarations have their selectors combined (e.g. C<h1{color:#F00}>
C<h2{color:#F00}> → C<h1,h2{color:#F00}>).  Custom properties act
as a barrier; rulesets containing them are not merged.

=item Same-selector merging — adjacent rulesets with identical
selectors have their declarations merged.  Custom property
declarations are preserved verbatim rather than overwritten.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
