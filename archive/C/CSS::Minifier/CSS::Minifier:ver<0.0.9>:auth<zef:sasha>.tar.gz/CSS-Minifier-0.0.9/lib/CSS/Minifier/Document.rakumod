

unit module CSS::Minifier::Document:ver<0.0.9>:auth<zef:sasha>;

use CSS::Minifier::Util;

class Declaration is export {
    has Str  $.property;
    has Str  $.value is rw;
    has Bool $.important is rw = False;
}

role Statement is export { }

class RuleSet is export does Statement {
    has Str         @.selectors;
    has Declaration @.declarations;
}

class AtRule is export does Statement {
    has Str         $.name;
    has Str         $.prelude = '';
    has Statement   @.statements;
    has Declaration @.declarations;
}

sub declarations-to-key(@decls --> Str) is export {
    my @sorted = @decls > 1 ?? @decls.sort({ .property }) !! @decls;
    @sorted.map({
        .property.starts-with('--')
            ?? "{.property}:{.value}" ~ (.important ?? '!i' !! '')
            !! do {
                my $v = .value;
                $v = normalize-hex-value($v);
                if $v ~~ /<[a..zA..Z]>/ {
                    $v ~~ s:g/ <$NAMED-RE> /%NAMED{lc $/}/;
                    $v ~~ s:g/ :i << bold >> /700/;
                    $v ~~ s:g/ :i << normal >> /400/;
                }
                $v = strip-zero-units($v);
                "{.property}:$v" ~ (.important ?? '!i' !! '')
            }
    }).join(';');
}

class Document is export {
    has Str       @.braceless;
    has Statement @.statements;
    has Str       @.licenses;
}

=begin pod

=head1 NAME

CSS::Minifier::Document — Document-tree data types for the CSS minifier

=head1 DESCRIPTION

Provides the AST node types used by the CSS minifier pipeline.
All parsing, normalization, and writing operates on these types.

=head2 Types

=item C<Declaration> — a single CSS property declaration with
C<$.property>, C<$.value> (C<is rw>), and C<$.important> (C<is rw>)

=item C<Statement> — role that C<RuleSet> and C<AtRule> do

=item C<RuleSet> — a selector block with C<@.selectors> and
C<@.declarations>

=item C<AtRule> — an at-rule with C<$.name>, C<$.prelude>,
C<@.statements> (nested), and C<@.declarations> (for declaration-only
at-rules like C<@font-face>)

=item C<Document> — the top-level node holding C<@.braceless>,
C<@.statements>, and C<@.licenses>

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
