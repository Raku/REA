use CSS::Minifier::Document;
use CSS::Minifier::Util;

class CSS::Minifier::Writer:ver<0.0.9>:auth<zef:sasha> {
    has Str  $.sep = '';
    has Bool $.color-masks = True;
    has Bool $.color-names = False;

    # --- Write a Document tree to minified CSS ---

    method write-document(Document $doc --> Str) {
        my $result = '';

        $result ~= $doc.licenses.join("\n") ~ "\n" if $doc.licenses;
        if $doc.braceless {
            # braceless at-rules (@import, @charset, @namespace) must
            # be on their own lines; join with "\n" regardless of $.sep.
            my $b = self!url-quote-value($doc.braceless.join("\n"));
            $b ~= "\n" if $doc.statements;
            $result ~= $b;
        }
        if $doc.statements {
            my @stmts = $doc.statements.map({ self!write-statement($_) });
            $result ~= @stmts.grep(?*).join($.sep);
        }

        $result;
    }

    method !write-statement(Statement $stmt --> Str) {
        given $stmt {
            when RuleSet { self!write-ruleset($_) }
            when AtRule  { self!write-at-rule($_) }
        }
    }

    method !write-ruleset(RuleSet $rs --> Str) {
        my $sels = $rs.selectors.map({ self!url-quote-selector($_) }).join(', ');
        my $decls = self!write-decls($rs.declarations);
        $decls ?? $sels ~ '{' ~ $decls ~ '}' !! '';
    }

    method !write-at-rule(AtRule $ar --> Str) {
        my $prefix = '@' ~ $ar.name;
        $prefix ~= ' ' ~ $ar.prelude if $ar.prelude;
        my $brace-space = $ar.prelude ?? ' ' !! '';

        if $ar.statements {
            my $inner = $ar.statements.map({ self!write-statement($_) }).join($.sep);
            $prefix ~ $brace-space ~ '{' ~ $inner ~ '}';
        }
        elsif $ar.declarations {
            my $decls = self!write-decls($ar.declarations);
            $prefix ~ $brace-space ~ '{' ~ $decls ~ '}';
        }
        else {
            $prefix ~ $brace-space ~ '{}';
        }
    }

    method !write-decls(Declaration @decls --> Str) {
        return '' unless @decls;
        @decls.map({
            my $v = .value;
            if $!color-names {
                $v = self!apply-color-names(.property, $v);
            } elsif $!color-masks {
                $v = self!apply-color-masks(.property, $v);
            }
            $v = self!apply-font-weight(.property, $v) if .property eq 'font-weight';
            $v = strip-zero-units($v);
            my $s = .property ~ ':' ~ $v;
            $s ~= '!important' if .important;
            self!normalize-quotes($s);
        }).join(';');
    }

    method !url-quote-selector(Str $s --> Str) {
        my $r = $s;
        return $r if $r.contains("'");
        # Protect escaped \" with null sentinel → normalize " → ' → restore
        $r ~~ s:g[ '\\"' ] = "\x0";
        $r ~~ s:g/ '"' /'/;
        $r ~~ s:g[ "\x0" ] = '"';
        self!url-quote-value($r);
    }

    method !normalize-quotes(Str $s is copy --> Str) {
        my $colon = $s.index(':');
        my $value = $colon.defined ?? $s.substr($colon + 1) !! $s;
        unless $value.contains("'") {
            $value ~~ s:g[ '\\"' ] = "\x0";
            $value ~~ s:g/ '"' /'/;
            $value ~~ s:g[ "\x0" ] = '"';
            $s = $colon.defined ?? $s.substr(0, $colon + 1) ~ $value !! $value;
        }
        self!url-quote-value($s);
    }

    method !url-quote-value(Str $s is copy --> Str) {
        $s ~~ s:g[ :i url\( (\s*) ( \' .*? \' | \".*?\" | <-[)>]>+ ) (\s*) \) ] = 'url(' ~ $0 ~ self!url-quote(~$1) ~ $2 ~ ')';
        $s;
    }

    method !url-quote(Str $u --> Str) {
        return $u if $u.starts-with("'") && $u.ends-with("'");
        return $u if $u.starts-with('"') && $u.ends-with('"');
        "'$u'"
    }

    # Color shortening: named colors -> hex, 6-char hex -> 3-char,
    # rgb() -> hex, rgba(...,1) -> hex.
    my constant %COLOR-PROPS = Set.new(<
        color background background-color
        border border-color border-top border-right border-bottom border-left
        border-top-color border-right-color border-bottom-color border-left-color
        border-block border-inline border-block-start border-block-end
        border-inline-start border-inline-end
        border-block-color border-inline-color
        border-block-start-color border-block-end-color
        border-inline-start-color border-inline-end-color
        outline outline-color
        text-decoration text-decoration-color
        text-shadow box-shadow
        column-rule column-rule-color
        caret-color accent-color
        scrollbar-color scrollbar-face-color scrollbar-track-color
        scrollbar-arrow-color scrollbar-thumb-color
        -webkit-tap-highlight-color
    >);
    my constant %HEX-TO-NAME = %NAMED.map({ .value.lc => .key }).Map;
    method !with-url-quarantine(Str $v is copy, &op --> Str) {
        my @urls;
        $v ~~ s:g/ url\( <-[)]>+ \) /{@urls.push(~$/); "\x0" ~ @urls.end}/;
        $v = &op($v);
        $v ~~ s:g/ \x0(\d+) /{@urls[$0]}/;
        $v;
    }



    method !apply-color-masks(Str $key, Str $value --> Str) {
        return $value unless %COLOR-PROPS{$key};
        return $value if $value ~~ $UNSAFE-RE;
        self!with-url-quarantine($value, -> $v is copy {
            $v ~~ s:g/ <$NAMED-RE> /%NAMED{lc $/}/;
            $v = normalize-hex-value($v);
            $v;
        });
    }

    method !apply-font-weight(Str $key, Str $value --> Str) {
        return $value if $value ~~ $UNSAFE-RE;
        given $value {
            when 'bold'   { return '700' }
            when 'normal' { return '400' }
        }
        $value;
    }

    method !apply-color-names(Str $key, Str $value --> Str) {
        return $value unless %COLOR-PROPS{$key};
        return $value if $value ~~ $UNSAFE-RE;
        self!with-url-quarantine($value, -> $v is copy {
            $v = normalize-hex-value($v);
            $v ~~ s:g/ <$HEX-TO-NAMED-RE> /%HEX-TO-NAME{lc $/}/;
            $v;
        });
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Writer — Document-tree CSS serializer

=head1 DESCRIPTION

Serializes a C<Document> tree back into minified CSS.  Handles:

=item Quote normalization (double → single, with escaped-quote protection)
=item Color masking (named → hex, hex shortening, rgb → hex)
=item Color naming (hex → named, when C<:color-names> is set)
=item Font-weight normalization (bold → 700, normal → 400)
=item Zero-unit removal (0px → 0)
=item URL quote wrapping
=item Space insertion before C<{> for at-rules with a prelude

=head2 Attributes

=item C<$.sep> — separator between top-level statements (default '')
=item C<$.color-masks> — enable hex color shortening (default True)
=item C<$.color-names> — convert hex to named colors (default False)

=head2 Methods

=item C<write-document(Document $doc --> Str)> — renders the document
tree to a minified CSS string

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
