

unit module CSS::Minifier::Util:ver<0.0.9>:auth<zef:sasha>;

my %COMB-CACHE;
my constant COMB-CACHE-MAX = %*ENV<CSS_MINIFIER_CACHE_MAX> // 500;
my $CACHE-LOCK = Lock.new;
sub comb-cached(Str $s) is export {
    $CACHE-LOCK.protect: {
        if %COMB-CACHE.elems > COMB-CACHE-MAX {
            my @keys = %COMB-CACHE.keys.sort;
            %COMB-CACHE{@keys[^250]}:delete;
        }
        %COMB-CACHE{$s} //= $s.comb.Array
    }
}
sub clear-comb-cache(--> Nil) is export {
    $CACHE-LOCK.protect: { %COMB-CACHE := {} }
}

our constant %NAMED is export =
    red => '#F00', maroon => '#800000', yellow => '#FF0',
    olive => '#808000', green => '#008000', lime => '#0F0',
    aqua => '#0FF', teal => '#008080', blue => '#00F',
    navy => '#000080', fuchsia => '#F0F', purple => '#800080',
    orange => '#FFA500', white => '#FFF', silver => '#C0C0C0',
    gray => '#808080', black => '#000',
;

my constant $UNSAFE-RE is export = rx:i/ var\( | calc\( | env\( | min\( | max\( | clamp\( /;

our $LENGTH-UNITS is export;
our $UNITS is export;
BEGIN {
    $LENGTH-UNITS = rx/
        px|em|ex|ch|rem|cap|ic|lh|rlh|
        vh|vw|vmin|vmax|vb|vi|svw|svh|lvw|lvh|dvw|dvh|
        cqw|cqh|cqi|cqb|cqmin|cqmax|
        cm|mm|in|pt|pc|q|
        fr
    /;
    $UNITS = rx/
        <$LENGTH-UNITS> |
        deg|grad|rad|turn|s|ms|Hz|kHz|
        dpi|dpcm|dppx
    /;
}

sub normalize-hex-value(Str $v --> Str) is export {
    my $v2 = rgb-values-to-hex($v);
    $v2 ~~ s:g[ <[#]> ( <xdigit> ) $0 ( <xdigit> ) $1 ( <xdigit> ) $2 ] = '#' ~ $0.uc ~ $1.uc ~ $2.uc;
    $v2 ~~ s:g[ '#' (<[0..9 A..F a..f]>+) ] = '#' ~ $0.uc;
    $v2;
}

sub strip-zero-units(Str $value --> Str) is export {
    return $value if $value ~~ $UNSAFE-RE;
    return $value unless $value ~~ /<[\d.]>/;
    my $v = $value;
    # .0 stripping applies to all units (line 58 — $UNITS includes angle/time/freq);
    # zero-value stripping (line 59) is length-only — preserving 0deg, 0s, etc.
    $v ~~ s:g/ (\d+) '.' 0+ (<$UNITS>) /{$0 ~ $1}/;
    $v ~~ s:g/ <!after <[\d.]>> 0 <$LENGTH-UNITS> /0/;
    $v;
}

our $NAMED-RE is export;
our $HEX-TO-NAMED-RE is export;
BEGIN {
    $NAMED-RE = rx:i/ << @(%NAMED.keys) >> /;
    $HEX-TO-NAMED-RE = rx:i/ <!after <xdigit>> @(%NAMED.values) <!before <xdigit>> /;
}

sub rgb-values-to-hex(Str $v is copy --> Str) is export {
    return $v unless $v.contains('rgb', :i);
    $v ~~ s:g:i[ rgb\( \s* (\d+) \s* \, \s* (\d+) \s* \, \s* (\d+) \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgba\( \s* (\d+) \s* \, \s* (\d+) \s* \, \s* (\d+) \s* \, \s* 1(\.0+)? \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgb\( \s* (\d+) \s+ (\d+) \s+ (\d+) \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgba\( \s* (\d+) \s+ (\d+) \s+ (\d+) \s* \/ \s* 1(\.0+)? \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgb\( \s* (\d+) \s+ (\d+) \s+ (\d+) \s* \/ \s* 1(\.0+)? \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
    $v ~~ s:g:i[ rgb\( \s* (\d+[.]?\d*) \% \s* \, \s* (\d+[.]?\d*) \% \s* \, \s* (\d+[.]?\d*) \% \s* \) ] = '#' ~ ($0*255/100).round.fmt('%02X') ~ ($1*255/100).round.fmt('%02X') ~ ($2*255/100).round.fmt('%02X');
    $v ~~ s:g:i[ rgba\( \s* (\d+[.]?\d*) \% \s* \, \s* (\d+[.]?\d*) \% \s* \, \s* (\d+[.]?\d*) \% \s* \, \s* 1(\.0+)? \) ] = '#' ~ ($0*255/100).round.fmt('%02X') ~ ($1*255/100).round.fmt('%02X') ~ ($2*255/100).round.fmt('%02X');
    $v ~~ s:g:i[ rgb\( \s* (\d+[.]?\d*) \% \s+ (\d+[.]?\d*) \% \s+ (\d+[.]?\d*) \% \s* \) ] = '#' ~ ($0*255/100).round.fmt('%02X') ~ ($1*255/100).round.fmt('%02X') ~ ($2*255/100).round.fmt('%02X');
    $v ~~ s:g:i[ rgba\( \s* (\d+[.]?\d*) \% \s+ (\d+[.]?\d*) \% \s+ (\d+[.]?\d*) \% \s* \/ \s* 1(\.0+)? \s* \) ] = '#' ~ ($0*255/100).round.fmt('%02X') ~ ($1*255/100).round.fmt('%02X') ~ ($2*255/100).round.fmt('%02X');
    $v ~~ s:g:i[ rgb\( \s* (\d+[.]?\d*) \% \s+ (\d+[.]?\d*) \% \s+ (\d+[.]?\d*) \% \s* \/ \s* 1(\.0+)? \s* \) ] = '#' ~ ($0*255/100).round.fmt('%02X') ~ ($1*255/100).round.fmt('%02X') ~ ($2*255/100).round.fmt('%02X');
    $v;
}

sub has-top-level-comma(Str $v --> Bool) is export {
    my $i = 0;
    my $depth = 0;
    my $len = $v.chars;
    my @chars := comb-cached($v);
    while $i < $len {
        given @chars[$i] {
            when '('   { $depth++; $i++ }
            when ')'   { $depth--; $i++ }
            when '"'   { $i = skip-quoted($v, $i, '"') }
            when "'"   { $i = skip-quoted($v, $i, "'") }
            when ','   { return True if $depth == 0; $i++ }
            default    { $i++ }
        }
    }
    False
}

sub split-top-level(Str $v --> List) is export {
    my @parts;
    my $start = 0;
    my $depth = 0;
    my $i = 0;
    my $len = $v.chars;
    my @chars := comb-cached($v);
    while $i < $len {
        given @chars[$i] {
            when '('   { $depth++; $i++ }
            when ')'   { $depth--; $i++ }
            when '"'   { $i = skip-quoted($v, $i, '"') }
            when "'"   { $i = skip-quoted($v, $i, "'") }
            when ','   {
                if $depth == 0 {
                    my $seg = $v.substr($start, $i - $start).trim;
                    @parts.push: $seg if $seg.chars;
                    $start = $i + 1;
                }
                $i++
            }
            default    { $i++ }
        }
    }
    my $last = $v.substr($start).trim;
    @parts.push: $last if $last.chars;
    @parts
}

sub skip-quoted(Str $s, Int $i, Str $q --> Int) is export {
    my $pos = $i + 1;
    my $len = $s.chars;
    my @chars := comb-cached($s);
    while $pos < $len {
        given @chars[$pos] {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $len
}

=begin pod

=head1 NAME

CSS::Minifier::Util — utility functions for CSS parsing

=head1 DESCRIPTION

Low-level helper subroutines used by the parser and normalizer.

=head2 Subs

=item C<has-top-level-comma(Str $v --> Bool)> — returns True if a
comma appears at paren depth 0 (used to detect multi-layer background
values and other comma-separated top-level constructs)

=item C<split-top-level(Str $v --> List)> — splits a string on commas
at paren depth 0, trimming each segment and skipping empty ones.
Returns a list of strings. Inverse of has-top-level-comma.

=item C<skip-quoted(Str $s, Int $i, Str $q --> Int)> — skips to the
position after a closing quote character C<$q>, handling backslash
escapes.  Returns C<$s.chars> if the closing quote is not found.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
