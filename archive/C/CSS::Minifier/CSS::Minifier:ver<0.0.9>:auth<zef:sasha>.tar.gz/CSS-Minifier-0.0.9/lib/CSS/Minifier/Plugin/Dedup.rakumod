use CSS::Minifier::Document;
use CSS::Minifier::Plugin;

class CSS::Minifier::Plugin::Dedup:ver<0.0.9>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'dedup' }

    method run(Document $doc --> Nil) {
        $doc.statements = self!dedup-block($doc.statements);
    }

    method !dedup-block(Statement @stmts --> Array[Statement]) {
        my %seen;
        my Statement @kept;

        for @stmts -> $stmt {
            given $stmt {
                when RuleSet {
                    next unless .declarations;
                    my $key = self!ruleset-key($_);
                    @kept.push: $stmt unless %seen{$key}++;
                }
                when AtRule {
                    # For @font-face (declaration-only), dedup by content
                    if .statements.elems == 0 && .declarations {
                        my $key = self!at-rule-decl-key($_);
                        unless %seen{$key}++ {
                            @kept.push: $stmt;
                        }
                    }
                    else {
                        # Recurse into nested statements
                        .statements = self!dedup-block(.statements);
                        @kept.push: $stmt;
                    }
                }
                default { @kept.push: $stmt }
            }
        }

        @kept;
    }

    method !ruleset-key(RuleSet $rs --> Str) {
        my $sel = $rs.selectors.join(',');
        my $decl = declarations-to-key($rs.declarations);
        "$sel\0$decl";
    }

    method !at-rule-decl-key(AtRule $ar --> Str) {
        $ar.name.fc ~ "\0" ~ $ar.prelude.fc ~ "\0" ~ declarations-to-key($ar.declarations);
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Dedup — duplicate ruleset and @font-face removal

=head1 DESCRIPTION

Removes duplicate rulesets (same selectors + same declarations) and
duplicate C<@font-face> blocks at the same level.  Selector-list
dedup (removing duplicate selectors within a single ruleset) is also
performed.  Custom properties are preserved verbatim and not deduped.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
