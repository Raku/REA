use CSS::Stylesheet;
use CSS::Minifier::Plugin;

class CSS::Minifier::Pipeline:ver<0.0.1> {
    has CSS::Minifier::Plugin @.plugins;
    has Bool $.verbose = False;

    method run(CSS::Stylesheet $stylesheet --> Nil) {
        for @!plugins -> $plugin {
            if $!verbose {
                my $t0 = now;
                $plugin.run($stylesheet);
                note sprintf "plugin: %s (%.3fs)", $plugin.name, now - $t0;
            } else {
                $plugin.run($stylesheet);
            }
        }
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Pipeline - Plugin pipeline runner

=head1 DESCRIPTION

Holds an ordered list of L<CSS::Minifier::Plugin> objects and runs them
sequentially against a L<CSS::Stylesheet>. Each plugin mutates the stylesheet
in place before the next plugin runs.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
