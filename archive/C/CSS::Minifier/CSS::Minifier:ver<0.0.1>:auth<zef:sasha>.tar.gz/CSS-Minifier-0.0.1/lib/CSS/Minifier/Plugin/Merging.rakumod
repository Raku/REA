use CSS::Stylesheet;
use CSS::Ruleset;
use CSS::Properties;
use CSS::Minifier::Plugin;
use CSS::Minifier::Util;

class CSS::Minifier::Plugin::Merging:ver<0.0.1> does CSS::Minifier::Plugin {
    method name(--> Str) { 'merging' }

    method run(CSS::Stylesheet $stylesheet --> Nil) {
        self!merge-same-declarations($stylesheet);
        self!merge-adjacent-same-selectors($stylesheet);
        self!dedup-selector-lists($stylesheet);
    }

    method !dedup-selector-lists(CSS::Stylesheet $stylesheet) {
        for $stylesheet.rules -> $rule {
            next unless $rule.selectors && $rule.ast.value<selectors>.elems > 1;
            my @sels = $rule.ast.value<selectors>.list;
            # split on ', ' assumes no selector contains that sequence (e.g. attr selectors)
            my @xps  = $rule.selectors.xpath.split(', ');
            next unless @xps == @sels;
            my (@uniq, %seen);
            for @sels.kv -> $i, $sel {
                %seen{@xps[$i]}++ or @uniq.push: $sel;
            }
            $rule.ast.value<selectors> = @uniq if @uniq != @sels;
        }
    }

    method !merge-adjacent-same-selectors(CSS::Stylesheet $stylesheet) {
        my @rules = $stylesheet.rules.list;
        my @merged;
        my int $i;

        while $i < @rules {
            my $current = @rules[$i];
            $i++;
            unless $current.properties {
                @merged.push: $current;
                next;
            }

            while $i < @rules
            && @rules[$i].properties
            && self!same-selectors($current, @rules[$i])
            && same-media($stylesheet, $current, @rules[$i]) {
                self!merge-props($current.properties, @rules[$i].properties);
                $i++;
            }

            @merged.push: $current;
        }

        $stylesheet.rules = @merged;
    }

    method !same-selectors(CSS::Ruleset $a, CSS::Ruleset $b --> Bool) {
        return False unless $a.selectors && $b.selectors;
        $a.selectors.xpath eq $b.selectors.xpath;
    }

    # Last-write-wins: if both rules declare the same property, the later
    # (source) value wins — correct CSS cascade for adjacent same-selector rules.
    method !merge-props(CSS::Properties $target, CSS::Properties $source) {
        for $source.properties -> $k {
            $target."$k"() = $source."$k"();
        }
    }

    method !merge-same-declarations(CSS::Stylesheet $stylesheet) {
        my @rules = $stylesheet.rules.list;
        my @merged;
        my int $i;

        while $i < @rules {
            my $current = @rules[$i];
            $i++;
            unless $current.properties {
                @merged.push: $current;
                next;
            }
            my $cur-props = $current.properties.Str(:optimize);
            my @skipped;

            while $i < @rules {
                my $next = @rules[$i];
                if $next.properties {
                    # Propertyful rules with different declarations act as barriers
                    last unless $next.properties.Str(:optimize) eq $cur-props;
                    # same-media check prevents merging across @media boundaries
                    last unless same-media($stylesheet, $current, $next);

                    # CSS::Ruleset.selectors is read-only, so we mutate %.ast directly.
                    # The change IS reflected in .selectors.xpath after mutation.
                    # Note: !dedup-selector-lists assumes ', ' as separator — keep in sync.
                    $current.ast.value<selectors>.append: |$next.ast.value<selectors>.list;
                    $next.ast.value<selectors> = Empty;
                } else {
                    # Propertyless rules (at-rules, empty rulesets) are skipped —
                    # merge proceeds across them. Re-appended after $current.
                    @skipped.push: $next;
                }
                $i++;
            }

            @merged.push: $current;
            @merged.append: @skipped;
        }

        $stylesheet.rules = @merged;
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Merging - Ruleset merging plugin

=head1 DESCRIPTION

Merges CSS rulesets to reduce output size at level 2.

Note on asymmetry: same-selector merging requires strict adjacency;
same-declaration merging skips propertyless rules (parsing artifacts)
to merge across non-strictly-adjacent rulesets.

=head2 Same-selector merging

When two adjacent rulesets have the same selectors (strictly adjacent),
their properties are combined into a single rule:

    h1 { color: red; }
    h1 { margin: 0; }
    →
    h1 { color: red; margin: 0; }

=head2 Same-declaration merging

When two rulesets have identical property declarations, their selectors
are combined into a comma-separated list. Propertyless rules (parsing
artifacts) between them are skipped:

    h1 { color: red; }
    h2 { color: red; }
    →
    h1, h2 { color: red; }

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
