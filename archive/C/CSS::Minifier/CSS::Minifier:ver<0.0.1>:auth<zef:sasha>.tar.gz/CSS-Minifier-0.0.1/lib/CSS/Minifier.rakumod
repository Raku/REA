unit class CSS::Minifier:ver<0.0.1>;

use CSS::Stylesheet;
use CSS::Minifier::Pipeline;
use CSS::Minifier::Plugin::Values;
use CSS::Minifier::Plugin::Dedup;
use CSS::Minifier::Plugin::Merging;
use CSS::Minifier::Writer;

my constant %KNOWN-PROPS = do {
    my $ss = CSS::Stylesheet.parse('h1{}');
    $ss.module.prop-names.map(*.key).Set;
};
my constant %SAFE-AT-RULES = Set.new: <@media @page @font-face>;

# note: CSS::Stylesheet strips all comments at parse time, so we extract
# /*! */ license comments from the raw string before parsing.
method minify(Str $css, :$level = 1, Bool :$verbose = False, Bool :$preserve-licenses,
    Bool :$color-masks = True, Bool :$preserve-unknown = True, :@extra-plugins, *%opts) returns Str {
    my @licenses = $css.comb(/ '/*!' .*? '*/' /) if $preserve-licenses;
    my %unknown-decls;
    self!walk-decls($css, '', %unknown-decls) if $preserve-unknown;

    my $stylesheet;
    my Pair $ast;
    {
        temp $*ERR = $preserve-unknown
            ?? class { method print(|) { }; method say(|) { }; method note(|) { } }.new
            !! $*ERR;
        $stylesheet = CSS::Stylesheet.parse($css);

        my @plugins = self!plugins-for($level);
        for @extra-plugins -> $p {
            die "Extra plugin {$p.^name} does not implement CSS::Minifier::Plugin"
                unless $p ~~ CSS::Minifier::Plugin;
        }
        @plugins.append: @extra-plugins;

        my CSS::Minifier::Pipeline $pipeline .= new:
            :$verbose,
            :@plugins;

        $pipeline.run($stylesheet);

        $ast = $stylesheet.ast(:optimize);
    }
    my CSS::Minifier::Writer $writer .= new:
        :!pretty,
        :$color-masks,
        |%opts;

    my $output = $writer.write($ast);
    $output = self!merge-decls($output, %unknown-decls) if $preserve-unknown;
    $output = @licenses.join("\n") ~ "\n" ~ $output if @licenses;
    $output;
}

# Extract declarations from raw CSS before parsing.
# Uses recursive brace-counting to handle at-rules like @media, @supports,
# @container, @layer, etc. — any at-rule with a { } block.
# When $unsafe is True (inside an at-rule CSS::Stylesheet drops, e.g.
# @keyframes, @supports), ALL declarations are captured to prevent data
# loss. When False (top-level or inside @media/@page/@font-face), only
# properties not in %KNOWN-PROPS are captured (known ones are minified
# by the pipeline).
# Returns a Map of qualified-selector => [(property => value), ...].
method !walk-decls(Str $s, Str $prefix, %by-sel, Bool :$unsafe = False) {
    my $i = 0;
    my $len = $s.chars;

    while $i < $len {
        given $s.substr($i,1) {
            when /\s/ { $i++; next }
            when '/'  { if $s.substr($i,2) eq '/*' {
                            $i = ($s.index('*/', $i+2) // $len) + 2; next
                        } }
            when '"'  { $i = skip-quoted($s, $i, '"'); next }
            when "'"  { $i = skip-quoted($s, $i, "'"); next }
            when '}'  { $i++; next }
        }

        my $brace = $i;
        while $brace < $len {
            given $s.substr($brace,1) {
                when '{' { last }
                when '"' { $brace = skip-quoted($s, $brace, '"') }
                when "'" { $brace = skip-quoted($s, $brace, "'") }
                when '/' { if $s.substr($brace,2) eq '/*' {
                               $brace = ($s.index('*/', $brace+2) // $len) + 2
                           } else { $brace++ } }
                default  { $brace++ }
            }
        }
        last if $brace >= $len;

        my $raw = $s.substr($i, $brace - $i).trim;
        $raw ~~ s:g/ \s+ / /;
        my $end = matching-close($s, $brace);

        if $raw.starts-with('@') {
            my $at-name = $raw.split(/\s+/)[0];
            my $new-unsafe = $unsafe || $at-name ∉ %SAFE-AT-RULES;
            self!walk-decls($s.substr($brace+1, $end - $brace - 1),
                           $prefix ~ $raw ~ ' ', %by-sel, :unsafe($new-unsafe));
        }
        elsif $raw {
            my $qual = $prefix ?? "$prefix\{$raw\}" !! $raw;
            my $body = $s.substr($brace+1, $end - $brace - 1);
            my @decls;
            for $body.match(:g, / $<key>=<-[:;]>+ \s* ':' \s* $<val>=<-[;}]>+ ';'? /) -> $m {
                my $key = $m<key>.Str.trim;
                next if !$unsafe && $key ∈ %KNOWN-PROPS;
                @decls.push: $key => $m<val>.Str.trim;
            }
            %by-sel{$qual}.append(@decls) if @decls;
        }

        $i = $end + 1;
    }
}

sub matching-close(Str $s, Int $start --> Int) {
    my $depth = 1;
    my $i = $start + 1;
    while $i < $s.chars && $depth > 0 {
        given $s.substr($i, 1) {
            when '{'  { $depth++; $i++ }
            when '}'  { $depth--; $i++ }
            when '"'  { $i = skip-quoted($s, $i, '"') }
            when "'"  { $i = skip-quoted($s, $i, "'") }
            when '/'  { if $s.substr($i,2) eq '/*' {
                            $i = ($s.index('*/', $i+2) // $s.chars) + 2
                        } else { $i++ } }
            default   { $i++ }
        }
    }
    $i - 1
}

sub skip-quoted(Str $s, Int $i, Str $q --> Int) {
    my $pos = $i + 1;
    while $pos < $s.chars {
        given $s.substr($pos, 1) {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $s.chars
}

# Find the position of the opening brace for an at-rule block,
# accounting for the writer's optional space before {.
# Returns the index of {, or Nil.
method !find-at-rule-block(Str $out, Str $prelude --> Int) {
    my $pos = $out.index($prelude ~ '{') // $out.index($prelude ~ ' {');
    return Nil unless $pos.defined;
    $pos + $out.substr($pos).index('{');
}

# Scoped property-exists check: return True if $key: appears within
# the ruleset matching $qual in $out.
method !prop-exists(Str $out, Str $qual, Str $key --> Bool) {
    if $qual.starts-with('@') {
        my $open = $qual.index('{') // return False;
        my $close = $qual.rindex('}') // return False;
        my $prelude = $qual.substr(0, $open).trim;
        my $inner   = $qual.substr($open+1, $close - $open - 1).trim;
        return False unless my $pos = self!find-at-rule-block($out, $prelude);
        my $block-end = matching-close($out, $pos);
        my $block-body = $out.substr($pos + 1, $block-end - $pos - 1);
        my $inner-head = $inner ~ '{';
        return False unless my $inner-pos = $block-body.index($inner-head);
        my $inner-end = matching-close($block-body, $inner-pos + $inner-head.chars - 1);
        my $inner-body = $block-body.substr(
            $inner-pos + $inner-head.chars,
            $inner-end - $inner-pos - $inner-head.chars,
        );
        return $inner-body.contains($key ~ ':');
    }
    else {
        my $head = $qual ~ '{';
        return False unless my $pos = $out.index($head);
        my $end = matching-close($out, $pos + $head.chars - 1);
        my $body = $out.substr($pos + $head.chars, $end - $pos - $head.chars);
        return $body.contains($key ~ ':');
    }
}

# Re-inject declarations that were dropped during minification.
# For each qualified selector, checks whether each property appears in the
# output (by name, scoped to the correct ruleset). Missing declarations
# are appended as a new ruleset.
# For at-rule qualified selectors (e.g. @media screen { h1 }), re-injects
# into the existing at-rule block, creating one if missing.
method !merge-decls(Str $out, %by-sel --> Str) {
    my $result = $out;
    for %by-sel.kv -> $qual, @decls {
        my @missing;
        for @decls -> (:$key, :$value) {
            @missing.push($key ~ ':' ~ $value)
                unless self!prop-exists($result, $qual, $key);
        }
        next unless @missing;
        my $joined = @missing.join(';');

        if $qual.starts-with('@') {
            self!merge-qualified($result, $qual, $joined);
        }
        else {
            $result ~= $qual ~ '{' ~ $joined ~ '}';
        }
    }
    $result;
}

method !merge-qualified(Str $result is rw, Str $qual, Str $decls) {
    my $open = $qual.index('{') // return;
    my $close = $qual.rindex('}') // return;
    my $prelude = $qual.substr(0, $open).trim;
    my $inner = $qual.substr($open+1, $close - $open - 1).trim;

    if my $pos = self!find-at-rule-block($result, $prelude) {
        $result.substr-rw(matching-close($result, $pos), 0) =
            $inner ~ '{' ~ $decls ~ '}';
    }
    else {
        $result ~= $prelude ~ '{' ~ $inner ~ '{' ~ $decls ~ '}' ~ '}';
    }
}

my constant @PLUGIN-DEFS = (
    { :level(1), :class(CSS::Minifier::Plugin::Values) },
    { :level(2), :class(CSS::Minifier::Plugin::Dedup) },
    { :level(2), :class(CSS::Minifier::Plugin::Merging) },
);

method !plugins-for($level) {
    $level ~~ 1..2 or die "Invalid level: $level. Use 1 or 2.";
    @PLUGIN-DEFS.grep({ .<level> <= $level }).map({ .<class>.new }).list;
}

=begin pod

=head1 NAME

CSS::Minifier - CSS Minifier

=head1 SYNOPSIS

=begin code :lang<raku>

use CSS::Minifier;
say CSS::Minifier.minify($css, :level(2));

=end code

=head1 DESCRIPTION

A CSS minifier that parses, optimizes, and re-serializes CSS stylesheets.
Intended as a class method (call C<CSS::Minifier.minify($css)>).

=head2 Options

=item level - optimization level (1 = safe, 2 = structural, default 1)
=item verbose - log plugin names to stderr during processing
=item preserve-licenses - keep /*! */ license comments (extracted from raw CSS before parse; prepended to output)
=item color-masks - shorten hex colors  (default True)
=item color-names - convert hex to named colors (default False)
=item preserve-unknown - re-inject declarations for properties not handled by the pipeline (default True). Set to C<False> to skip the post-minification merge pass. All properties inside at-rules that CSS::Stylesheet drops (e.g. C<@keyframes>, C<@supports>, C<@container>, C<@layer>) are also preserved regardless of whether they are known to CSS::Module::CSS3 — they come back without minification since they bypass the standard pipeline. Known properties inside C<@media>, C<@page>, and C<@font-face> are always handled by the pipeline.
=item sep - separator between rulesets (default '' for compact; use C<"\n"> for readable output)

Note: license comments are matched via C<m/'/*!' .*? '*/'>, a pattern
extracted from the raw CSS before the parser strips all comments. A known
limitation: the pattern may also match inside string values
(e.g. C<content: "...">). This is extremely rare in practice; some minifiers
share the same limitation.

=head1 PRESERVING UNKNOWN PROPERTIES

CSS::Properties recognizes standard CSS properties and drops those it
doesn't know (e.g. C<text-decoration-line>, C<outline-offset>).
C<CSS::Minifier> works around this by pre-scanning the raw CSS before
parsing, extracting unknown property declarations, and re-injecting any
that are missing from the minified output.

Only properties not in CSS::Module::CSS3's property list are tracked;
known properties that the optimizer consolidates into shorthands are
never re-injected, so the output remains semantically correct.

Unknown properties inside at-rules (C<@media>, C<@supports>,
C<@container>, C<@layer>, etc.) are also preserved. The extraction
uses recursive brace-counting on the raw CSS, so any at-rule with a
C<{...}> body is handled.

Additionally, CSS::Stylesheet drops entire at-rules it does not have
dedicated grammar rules for (C<@keyframes>, C<@supports>, C<@container>,
C<@layer>, C<@scope>, etc.). Known properties inside these blocks would
otherwise be silently lost. C<CSS::Minifier> detects these at-rules and
extracts all declarations (both known and unknown) from them, re-injecting
the full raw text. Known properties re-injected this way are not minified
since they bypass the standard pipeline.

A known limitation: strings and comments containing C<{> or C<}> can
break brace-matching, though this is extremely rare in practice.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
