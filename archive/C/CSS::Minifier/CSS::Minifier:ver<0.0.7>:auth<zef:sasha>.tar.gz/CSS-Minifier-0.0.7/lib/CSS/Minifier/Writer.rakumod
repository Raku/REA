use CSS::Minifier::Document;

class CSS::Minifier::Writer:ver<0.0.7>:auth<zef:sasha> {
    has Str  $.sep = '';
    has Bool $.color-masks = True;
    has Bool $.color-names = False;

    # --- Write a Document tree to minified CSS ---

    method write-document(Document $doc --> Str) {
        my $result = '';

        $result ~= $doc.licenses.join("\n") ~ "\n" if $doc.licenses;
        if $doc.braceless {
            my $b = $doc.braceless.join("\n");
            $b ~= "\n" if $doc.statements;
            $result ~= $b;
        }
        if $doc.statements {
            my @stmts = $doc.statements.map({ self!write-statement($_) });
            $result ~= @stmts.join($.sep);
        }

        $result;
    }

    method !write-statement(Statement $stmt --> Str) {
        given $stmt {
            when RuleSet { self!write-ruleset($_) }
            when AtRule  { self!write-at-rule($_) }
        }
    }

    method !write-ruleset(RuleSet $rs --> Str) {
        my $sels = $rs.selectors.map({ self!url-quote-selector($_) }).join(', ');
        my $decls = self!write-decls($rs.declarations);
        $decls ?? $sels ~ '{' ~ $decls ~ '}' !! '';
    }

    method !write-at-rule(AtRule $ar --> Str) {
        my $prefix = '@' ~ $ar.name;
        $prefix ~= ' ' ~ $ar.prelude if $ar.prelude;
        my $space = $ar.prelude ?? ' ' !! '';

        if $ar.statements {
            my $inner = $ar.statements.map({ self!write-statement($_) }).join($.sep);
            $prefix ~ $space ~ '{' ~ $inner ~ '}';
        }
        elsif $ar.declarations {
            my $decls = self!write-decls($ar.declarations);
            $prefix ~ $space ~ '{' ~ $decls ~ '}';
        }
        else {
            $prefix ~ $space ~ '{}';
        }
    }

    method !write-decls(Declaration @decls --> Str) {
        return '' unless @decls;
        @decls.map({
            my $v = .value;
            $v = self!apply-color-masks(.property, $v) if $!color-masks;
            $v = self!apply-color-names(.property, $v) if $!color-names;
            $v = self!apply-font-weight(.property, $v);
            $v = self!strip-zero-units($v);
            my $s = .property ~ ':' ~ $v;
            $s ~= '!important' if .important;
            self!normalize-quotes($s);
        }).join(';');
    }

    method !url-quote-selector(Str $s --> Str) {
        my $r = $s;
        # Normalize double quotes to single, but protect escaped double quotes
        $r ~~ s:g[ '\\"' ] = "\x[0]";
        $r ~~ s:g/ '"' /'/;
        $r ~~ s:g[ "\x[0]" ] = '"';
        $r ~~ s:g[ :i url\( (\s*) (<-[>)]>+?) (\s*) \) ] = 'url(' ~ $0 ~ self!url-quote(~$1) ~ $2 ~ ')';
        $r;
    }

    method !normalize-quotes(Str $s is copy --> Str) {
        my $value = $s.contains(':') ?? $s.split(':')[1..*].join(':') !! $s;
        unless $value.contains("'") {
            $s ~~ s:g/ '"' /'/;
        }
        $s ~~ s:g[ :i url\( (\s*) (<-[>)]>+?) (\s*) \) ] = 'url(' ~ $0 ~ self!url-quote(~$1) ~ $2 ~ ')';
        $s;
    }

    method !url-quote(Str $u --> Str) {
        $u ~~ / ^ \' .* \' $ / || $u ~~ / ^ \" .* \" $ / ?? $u !! "'$u'";
    }

    # Color shortening: named colors -> hex, 6-char hex -> 3-char,
    # rgb() -> hex, rgba(...,1) -> hex.
    my constant %NAMED = Map.new(
        red => '#F00', maroon => '#800000', yellow => '#FF0',
        olive => '#808000', green => '#008000', lime => '#0F0',
        aqua => '#0FF', teal => '#008080', blue => '#00F',
        navy => '#000080', fuchsia => '#F0F', purple => '#800080',
        orange => '#FFA500', white => '#FFF', silver => '#C0C0C0',
        gray => '#808080', black => '#000',
    );

    method !apply-color-masks(Str $key, Str $value --> Str) {
        my $v = $value;
        # Replace named colors with hex (word boundaries to handle compound values)
        for %NAMED.kv -> $name, $hex {
            $v ~~ s:g/ << $name >> /$hex/;
        }
        $v ~~ s:g:i[ rgb\( (\d+) \s* \, \s* (\d+) \s* \, \s* (\d+) \s* \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
        $v ~~ s:g:i[ rgba\( (\d+) \s* \, \s* (\d+) \s* \, \s* (\d+) \s* \, \s* 1[\.0+]? \) ] = '#' ~ $0.fmt('%02X') ~ $1.fmt('%02X') ~ $2.fmt('%02X');
        $v ~~ s:g[ <[#]> ( <xdigit> ) $0 ( <xdigit> ) $1 ( <xdigit> ) $2 ] = '#' ~ $0.uc ~ $1.uc ~ $2.uc;
        $v ~~ s:g[ '#' (<[0..9 A..F a..f]>+) ] = '#' ~ $0.uc;
        $v;
    }

    method !apply-font-weight(Str $key, Str $value --> Str) {
        return $value unless $key eq 'font-weight';
        given $value {
            when 'bold'   { return '700' }
            when 'normal' { return '400' }
        }
        $value;
    }

    method !strip-zero-units(Str $value --> Str) {
        my $v = $value;
        $v ~~ s:g/ <!after \d> 0 (px|em|ex|ch|rem|vh|vw|vmin|vmax|cm|mm|in|pt|pc) /0/;
        $v;
    }

    method !apply-color-names(Str $key, Str $value --> Str) {
        my $v = $value;
        for %NAMED.kv -> $name, $hex {
            if $v.lc eq $hex.lc {
                return $name;
            }
        }
        $v;
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Writer — Document-tree CSS serializer

=head1 DESCRIPTION

Serializes a C<Document> tree back into minified CSS.  Handles:

=item Quote normalization (double → single, with escaped-quote protection)
=item Color masking (named → hex, hex shortening, rgb → hex)
=item Color naming (hex → named, when C<:color-names> is set)
=item Font-weight normalization (bold → 700, normal → 400)
=item Zero-unit removal (0px → 0)
=item URL quote wrapping
=item Space insertion before C<{> for at-rules with a prelude

=head2 Attributes

=item C<$.sep> — separator between top-level statements (default '')
=item C<$.color-masks> — enable hex color shortening (default True)
=item C<$.color-names> — convert hex to named colors (default False)

=head2 Methods

=item C<write-document(Document $doc --> Str)> — renders the document
tree to a minified CSS string

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
