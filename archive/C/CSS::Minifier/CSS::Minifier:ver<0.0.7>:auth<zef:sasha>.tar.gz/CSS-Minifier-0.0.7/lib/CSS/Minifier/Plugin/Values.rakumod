use CSS::Minifier::Document;
use CSS::Minifier::Plugin;

class CSS::Minifier::Plugin::Values:ver<0.0.7>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'values' }

    # font-weight normalization is now handled by CSS::Minifier::Writer.
    # This plugin exists only for backward compatibility with the plugin
    # pipeline interface.
    method run(Document $doc --> Nil) { }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Values — placeholder values plugin (no-op)

=head1 DESCRIPTION

A no-op plugin included for API compatibility.  Value normalization
(font-weight, colors, zero-unit removal)
is performed by CSS::Minifier::Writer at serialization time, so this
plugin exists only as a pipeline placeholder.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
