

unit module CSS::Minifier::Util:ver<0.0.7>:auth<zef:sasha>;

sub has-top-level-comma(Str $v --> Bool) is export {
    my $i = 0;
    my $depth = 0;
    while $i < $v.chars {
        given $v.substr($i, 1) {
            when '('   { $depth++; $i++ }
            when ')'   { $depth--; $i++ }
            when '"'   { $i = skip-quoted($v, $i, '"') }
            when "'"   { $i = skip-quoted($v, $i, "'") }
            when ','   { return True if $depth == 0; $i++ }
            default    { $i++ }
        }
    }
    False
}

sub split-top-level(Str $v --> List) is export {
    my @parts;
    my $start = 0;
    my $depth = 0;
    my $i = 0;
    while $i < $v.chars {
        given $v.substr($i, 1) {
            when '('   { $depth++; $i++ }
            when ')'   { $depth--; $i++ }
            when '"'   { $i = skip-quoted($v, $i, '"') }
            when "'"   { $i = skip-quoted($v, $i, "'") }
            when ','   {
                if $depth == 0 {
                    my $seg = $v.substr($start, $i - $start).trim;
                    @parts.push: $seg if $seg.chars;
                    $start = $i + 1;
                }
                $i++
            }
            default    { $i++ }
        }
    }
    my $last = $v.substr($start).trim;
    @parts.push: $last if $last.chars;
    @parts
}

sub skip-quoted(Str $s, Int $i, Str $q --> Int) is export {
    my $pos = $i + 1;
    while $pos < $s.chars {
        given $s.substr($pos, 1) {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $s.chars
}

=begin pod

=head1 NAME

CSS::Minifier::Util — utility functions for CSS parsing

=head1 DESCRIPTION

Low-level helper subroutines used by the parser and normalizer.

=head2 Subs

=item C<has-top-level-comma(Str $v --> Bool)> — returns True if a
comma appears at paren depth 0 (used to detect multi-layer background
values and other comma-separated top-level constructs)

=item C<split-top-level(Str $v --> List)> — splits a string on commas
at paren depth 0, trimming each segment and skipping empty ones.
Returns a list of strings. Inverse of has-top-level-comma.

=item C<skip-quoted(Str $s, Int $i, Str $q --> Int)> — skips to the
position after a closing quote character C<$q>, handling backslash
escapes.  Returns C<$s.chars> if the closing quote is not found.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
