use CSS::Minifier::Document;
use CSS::Minifier::Util;

my constant %SHORTHAND =
    margin      => [<margin-top    margin-right  margin-bottom margin-left>],
    padding     => [<padding-top   padding-right padding-bottom padding-left>],
    border      => [<border-color  border-style  border-width>],
    border-top  => [<border-top-color    border-top-style    border-top-width>],
    border-right=> [<border-right-color  border-right-style  border-right-width>],
    border-bottom=>[<border-bottom-color border-bottom-style border-bottom-width>],
    border-left => [<border-left-color   border-left-style   border-left-width>],
    outline     => [<outline-color outline-style outline-width>],
    list-style  => [<list-style-type list-style-position list-style-image>],
    background  => [<background-color background-image background-repeat
                     background-attachment background-position background-size
                     background-origin background-clip>],
    font        => [<font-style font-variant font-weight font-stretch font-size font-family>],
;

my constant %CUSTOM =
    background => 'assemble-background',
    font       => 'assemble-font',
;

my constant %LONGHAND-TO-SHORTHAND =
    gather for %SHORTHAND.kv -> $sh, @lhs {
        take $_ => $sh for @lhs;
    };

my constant $UNSAFE-RE   = rx/ var\( | calc\( | env\( | min\( | max\( | clamp\( /;
my constant $CSS-WIDE-RE = rx/ ^ (initial | inherit | unset | revert) $ /;

unit class CSS::Minifier::Normalizer:ver<0.0.7>:auth<zef:sasha>;

has Bool $.color-masks = True;

method normalize(Document $doc --> Nil) {
    for $doc.statements -> $stmt {
        self!walk($stmt);
    }
}

method !walk(Statement $stmt) {
    given $stmt {
        when RuleSet { self!normalize-ruleset($_) }
        when AtRule  {
            $_.declarations = self!normalize-declarations($_.declarations);
            .statements».&{ self!walk($_) }
        }
    }
}

method !normalize-ruleset(RuleSet $rs) {
    $rs.declarations = self!normalize-declarations($rs.declarations);
}

method !dedup-declarations(@decls) {
    my @uniq;
    my %seen;
    for @decls.reverse -> $d {
        if $d.property.starts-with('--') {
            @uniq.push: $d;
        }
        elsif !%seen{$d.property}++ {
            @uniq.push: $d;
        }
    }
    @uniq.reverse.Array;
}

method !consolidate-shorthands(@decls --> List) {
    my Declaration %by-prop;
    %by-prop{$_.property} = $_ for @decls;

    my %consolidated;
    for %SHORTHAND.kv -> $shorthand, @longhands {
        next if %by-prop{$shorthand}:exists;
        next unless %CUSTOM{$shorthand} || @longhands.all ~~ { %by-prop{$_}:exists };

        my $joined;
        if %CUSTOM{$shorthand} -> $method {
            my @present = @longhands.grep({ %by-prop{$_}:exists });
            next unless @present;
            if $shorthand eq 'font' {
                next unless %by-prop<font-size>.defined && %by-prop<font-family>.defined;
            }
            my @pv = @present.map({ %by-prop{$_}.value });
            next if @pv.any ~~ $UNSAFE-RE || @pv.any ~~ $CSS-WIDE-RE;
            $joined = self!"$method"(%by-prop) // next;
            %by-prop<line-height>:delete if $shorthand eq 'font';
        } else {
            my @vals = @longhands.map({ %by-prop{$_}.value });
            next if @vals.any ~~ $UNSAFE-RE;
            next if @vals.any ~~ $CSS-WIDE-RE;
            $joined = @vals.join(' ');
        }
        my @imp = @longhands.map({ %by-prop{$_} ?? %by-prop{$_}.important !! False });
        next if @imp.unique > 1;
        my $important = @imp[0];

        %by-prop{$_}:delete for @longhands;
        %by-prop{$shorthand} = Declaration.new(
            :property($shorthand),
            :value($joined),
            :$important,
        );
        %consolidated{$shorthand} = True;
    }

    # Preserve original order: emit shorthand at the position of its last longhand
    my %seen-group;
    my @result;
    for @decls.reverse -> $d {
        my $prop = $d.property;

        my $sh = %LONGHAND-TO-SHORTHAND{$prop};
        if $sh.defined && %consolidated{$sh} {
            # Consolidated group — emit shorthand once, skip remaining longhands
            next if %seen-group{$sh}++;
            @result.push: %by-prop{$sh};
        }
        elsif %by-prop{$prop}:exists {
            @result.push: %by-prop{$prop};
        }
    }
    @result.reverse.Array;
}

method !assemble-background(%by-prop --> Str) {
    return Nil if %by-prop<background-color>
                 && has-top-level-comma(%by-prop<background-color>.value);

    for <background-image background-repeat background-attachment
         background-position background-size
         background-origin background-clip> -> $p {
        if %by-prop{$p} && has-top-level-comma(%by-prop{$p}.value) {
            return self!assemble-background-multi(%by-prop);
        }
    }

    self!assemble-background-single(%by-prop)
}

method !assemble-background-single(%by-prop --> Str) {
    my @parts;
    for <background-color background-image background-repeat
         background-attachment> -> $p {
        next without %by-prop{$p};
        @parts.push: %by-prop{$p}.value;
    }

    # position [ / size ]
    my $pos  = %by-prop<background-position>;
    my $size = %by-prop<background-size>;
    if $pos || $size {
        @parts.push: ($pos ?? $pos.value !! '0% 0%')
                    ~ ($size ?? ' / ' ~ $size.value !! '');
    }

    # origin / clip
    my $origin = %by-prop<background-origin>;
    my $clip   = %by-prop<background-clip>;
    if $origin && $clip {
        if $origin.value eq $clip.value {
            @parts.push: $origin.value;
        } else {
            @parts.push: $origin.value;
            @parts.push: $clip.value;
        }
    } elsif $origin {
        @parts.push: $origin.value;
    } elsif $clip {
        @parts.push: 'padding-box';
        @parts.push: $clip.value;
    }
    return Nil unless @parts;
    @parts.join(' ')
}

method !assemble-background-multi(%by-prop --> Str) {
    my $color = %by-prop<background-color>
                ?? %by-prop<background-color>.value
                !! Nil;

    my %vals;
    for <background-image background-repeat background-attachment
         background-position background-size
         background-origin background-clip> -> $p {
        next without %by-prop{$p};
        %vals{$p} = split-top-level(%by-prop{$p}.value);
    }

    my $n = %vals.values».elems.max // 0;
    return Nil unless $n;

    my @layers;
    for 0..^$n -> $i {
        my @parts;

        for <background-image background-repeat background-attachment> -> $p {
            %vals{$p}:exists or next;
            @parts.push: %vals{$p}[$i % %vals{$p}.elems];
        }

        # position [ / size ]
        my $pos  = %vals<background-position>
                   ?? %vals<background-position>[$i % %vals<background-position>.elems]
                   !! Nil;
        my $size = %vals<background-size>
                   ?? %vals<background-size>[$i % %vals<background-size>.elems]
                   !! Nil;
        if $pos || $size {
            @parts.push: ($pos // '0% 0%') ~ ($size ?? ' / ' ~ $size !! '');
        }

        # origin / clip
        my $origin = %vals<background-origin>
                     ?? %vals<background-origin>[$i % %vals<background-origin>.elems]
                     !! Nil;
        my $clip   = %vals<background-clip>
                     ?? %vals<background-clip>[$i % %vals<background-clip>.elems]
                     !! Nil;
        if $origin || $clip {
            if $origin && $clip {
                if $origin eq $clip {
                    @parts.push: $origin;
                } else {
                    @parts.push: $origin;
                    @parts.push: $clip;
                }
            } elsif $origin {
                @parts.push: $origin;
            } elsif $clip {
                @parts.push: 'padding-box';
                @parts.push: $clip;
            }
        }

        return Nil unless @parts;

        if $color.defined && $i == $n - 1 {
            @parts.push: $color;
        }

        @layers.push: @parts.join(' ');
    }

    @layers.join(',')
}

method !assemble-font(%by-prop --> Str) {
    my $size   = %by-prop<font-size> ?? %by-prop<font-size>.value !! Nil;
    my $family = %by-prop<font-family> ?? %by-prop<font-family>.value !! Nil;
    return Nil unless $size.defined && $family.defined;
    return Nil if $size.contains('/');

    my @parts;
    for <font-style font-variant font-weight font-stretch> -> $p {
        my $v = %by-prop{$p} ?? %by-prop{$p}.value !! 'normal';
        if $p eq 'font-weight' {
            $v = '700' if $v eq 'bold';
            next if $v eq 'normal' || $v eq '400';
        } elsif $p eq 'font-stretch' {
            next if $v eq 'normal';
        } else {
            next if $v eq 'normal';
        }
        @parts.push: $v;
    }
    @parts.push: $size;

    if %by-prop<line-height> -> $lh {
        @parts[*-1] ~= '/' ~ $lh.value;
    }

    @parts.push: $family;
    @parts.join(' ');
}

method !normalize-declarations(@decls --> List) {
    self!consolidate-shorthands(self!dedup-declarations(@decls))
}

=begin pod

=head1 NAME

CSS::Minifier::Normalizer — declaration normalization and dedup

=head1 DESCRIPTION

Walks the document tree and deduplicates declarations (last-wins).

=head2 Attributes

=item C<$.color-masks> — enable hex color shortening (default True)

=head2 Methods

=item C<normalize(Document $doc)> — walks the document tree and
normalizes all declarations in place

=item C<!assemble-background(%by-prop)> — assembles background shorthand
from present longhands; handles both single and multi-layer
(comma-separated) backgrounds. Includes background-size via position/size
syntax, background-origin and background-clip as box values; defaults
position to 0% 0% when size present without position. Multi-layer
handles cycling per CSS spec when layer counts differ across longhands.

=item C<!assemble-font(%by-prop)> — assembles font shorthand from
font-size and font-family (required) plus font-style, font-variant,
font-weight (optional) and line-height (optional, consumed into
size/line-height syntax if present); normalizes bold→700, normal→400;
skips default values

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
