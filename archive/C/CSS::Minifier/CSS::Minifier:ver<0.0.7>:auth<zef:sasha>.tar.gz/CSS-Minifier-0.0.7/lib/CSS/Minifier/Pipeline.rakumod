use CSS::Minifier::Document;
use CSS::Minifier::Plugin;

class CSS::Minifier::Pipeline:ver<0.0.7>:auth<zef:sasha> {
    has CSS::Minifier::Plugin @.plugins;
    has Bool $.verbose = False;

    method run(Document $doc --> Nil) {
        for @!plugins -> $plugin {
            if $!verbose {
                my $t0 = now;
                $plugin.run($doc);
                note sprintf "plugin: %s (%.3fs)", $plugin.name, now - $t0;
            } else {
                $plugin.run($doc);
            }
        }
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Pipeline — plugin runner for the CSS minifier

=head1 DESCRIPTION

Runs an ordered list of plugin objects against a Document tree.
When C<:verbose> is set, each plugin's runtime is logged to stderr.

=head2 Attributes

=item C<@.plugins> — list of C<CSS::Minifier::Plugin> objects
=item C<$.verbose> — log plugin timings (default False)

=head2 Methods

=item C<run(Document $doc)> — runs each plugin in sequence

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
