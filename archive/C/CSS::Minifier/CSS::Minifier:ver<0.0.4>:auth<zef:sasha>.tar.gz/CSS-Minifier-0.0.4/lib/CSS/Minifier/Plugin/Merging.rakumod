use CSS::Stylesheet;
use CSS::Ruleset;
use CSS::Properties;
use CSS::Minifier::Plugin;
use CSS::Minifier::Util;

class CSS::Minifier::Plugin::Merging:ver<0.0.4>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'merging' }

    method run(CSS::Stylesheet $stylesheet --> Nil) {
        self!merge-same-declarations($stylesheet);
        self!merge-adjacent-same-selectors($stylesheet);
        self!dedup-selector-lists($stylesheet);
    }

    method !dedup-selector-lists(CSS::Stylesheet $stylesheet) {
        for $stylesheet.rules -> $rule {
            next unless $rule.selectors && $rule.ast.value<selectors>.elems > 1;
            my @sels = $rule.ast.value<selectors>.list;
            my @xps  = split-xpath($rule.selectors.xpath);
            next unless @xps == @sels;
            my (@uniq, %seen);
            for @sels.kv -> $i, $sel {
                %seen{@xps[$i]}++ or @uniq.push: $sel;
            }
            $rule.ast.value<selectors>.splice(0, *, @uniq) if @uniq != @sels;
        }
    }

    method !merge-adjacent-same-selectors(CSS::Stylesheet $stylesheet) {
        my @rules = $stylesheet.rules.list;
        my @merged;
        my int $i;

        while $i < @rules {
            my $current = @rules[$i];
            $i++;
            unless $current.properties {
                @merged.push: $current;
                next;
            }

            while $i < @rules
            && @rules[$i].properties
            && self!same-selectors($current, @rules[$i])
            && same-media($stylesheet, $current, @rules[$i]) {
                self!merge-props($current.properties, @rules[$i].properties);
                $i++;
            }

            @merged.push: $current;
        }

        $stylesheet.rules = @merged;
    }

    method !same-selectors(CSS::Ruleset $a, CSS::Ruleset $b --> Bool) {
        return False unless $a.selectors && $b.selectors;
        $a.selectors.xpath eq $b.selectors.xpath;
    }

    # Merge properties respecting !important cascade.
    # If target has !important and source doesn't, target wins (keep target).
    # Otherwise, source (later rule) wins with its !important flag.
    method !merge-props(CSS::Properties $target, CSS::Properties $source) {
        for $source.properties -> $k {
            next if $target.important($k) && !$source.important($k);
            $target."$k"() = $source."$k"();
            $target.important($k) = $source.important($k);
        }
    }

    method !merge-same-declarations(CSS::Stylesheet $stylesheet) {
        my @rules = $stylesheet.rules.list;
        my @merged;  # Array of Pair: $last-pos => $ruleset
        my int $i;

        while $i < @rules {
            my $current = @rules[$i];
            my $last-pos = $i;  # track position of last rule merged into this group
            $i++;
            unless $current.properties {
                @merged.push: $last-pos => $current;
                next;
            }
            my $cur-props = $current.properties.Str(:optimize);

            while $i < @rules {
                my $next = @rules[$i];
                if $next.properties {
                    # Propertyful rules with different declarations act as barriers
                    last unless $next.properties.Str(:optimize) eq $cur-props;
                    # same-media check prevents merging across @media boundaries
                    last unless same-media($stylesheet, $current, $next);

                    # CSS::Ruleset.selectors is read-only, so we mutate %.ast directly.
                    # The change IS reflected in .selectors.xpath after mutation.
                    $current.ast.value<selectors>.append: |$next.ast.value<selectors>.list;
                    $last-pos = $i;   # update to position of this merged rule
                } else {
                    # Propertyless rules: skip and continue (don't act as barrier)
                    $i++;
                    next;
                }
                $i++;
            }

            @merged.push: $last-pos => $current;
        }

        # Sort by source position to preserve cascade order:
        # merged groups appear at the position of their LAST constituent rule.
        my @ordered = @merged.sort(*.key).map(*.value);
        $stylesheet.rules = @ordered;
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Merging - Ruleset merging plugin

=head1 DESCRIPTION

Merges CSS rulesets to reduce output size at level 2.

Note: propertyless rules act as barriers in both merging passes, so
same-declaration merging only applies to strictly-adjacent propertyful
rulesets.

=head2 Same-selector merging

When two adjacent rulesets have the same selectors (strictly adjacent),
their properties are combined into a single rule:

    h1 { color: red; }
    h1 { margin: 0; }
    →
    h1 { color: red; margin: 0; }

=head2 Same-declaration merging

When two rulesets have identical property declarations, their selectors
are combined into a comma-separated list. Propertyless rules (parsing
artifacts) between them are skipped:

    h1 { color: red; }
    h2 { color: red; }
    →
    h1, h2 { color: red; }

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
