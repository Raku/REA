use CSS::Minifier::Document;
use CSS::Minifier::Util;

class CSS::Minifier::Writer:ver<0.0.10>:auth<zef:sasha> {
    has Str  $.sep = '';
    has Bool $.color-masks = True;
    has Bool $.color-names = False;

    # --- Write a Document tree to minified CSS ---

    method write-document(Document $doc --> Str) {
        my $result = '';

        $result ~= $doc.licenses.join("\n") ~ "\n" if $doc.licenses;
        if $doc.braceless {
            # braceless at-rules (@import, @charset, @namespace) must
            # be on their own lines; join with "\n" regardless of $.sep.
            my $b = self!url-quote-value($doc.braceless.join("\n"));
            $b ~= "\n" if $doc.statements;
            $result ~= $b;
        }
        if $doc.statements {
            my @stmts = $doc.statements.map({ self!write-statement($_) });
            $result ~= @stmts.grep(?*).join($.sep);
        }

        $result;
    }

    method !write-statement(Statement $stmt --> Str) {
        given $stmt {
            when RuleSet { self!write-ruleset($_) }
            when AtRule  { self!write-at-rule($_) }
        }
    }

    method !write-ruleset(RuleSet $rs --> Str) {
        my $sels = $rs.selectors.map({ self!url-quote-selector($_) }).join(', ');
        my $decls = self!write-decls($rs.declarations);
        $decls ?? $sels ~ '{' ~ $decls ~ '}' !! '';
    }

    method !write-at-rule(AtRule $ar --> Str) {
        my $prefix = '@' ~ $ar.name;
        $prefix ~= ' ' ~ $ar.prelude if $ar.prelude;

        if $ar.braceless {
            return $prefix ~ ';';
        }

        my $brace-space = $ar.prelude ?? ' ' !! '';

        my $inner = '';
        $inner ~= self!write-decls($ar.declarations) if $ar.declarations;
        $inner ~= ';' if $ar.declarations && ($ar.statements || $ar.trailing-declarations);
        $inner ~= $ar.statements.map({ self!write-statement($_) }).join($.sep) if $ar.statements;
        $inner ~= self!write-decls($ar.trailing-declarations) if $ar.trailing-declarations;

        return '' unless $inner;
        $prefix ~ $brace-space ~ '{' ~ $inner ~ '}';
    }

    method !write-decls(Declaration @decls --> Str) {
        return '' unless @decls;
        @decls.map({
            my $v = .value;
            if $!color-names {
                $v = self!apply-color-names(.property, $v);
            } elsif $!color-masks {
                $v = self!apply-color-masks(.property, $v);
            }
            $v = self!apply-font-weight(.property, $v) if .property.lc eq 'font-weight';
            $v = strip-zero-units($v) unless .property.starts-with('--');
            my $s = (.property.starts-with('--') ?? .property !! .property.lc) ~ ':' ~ $v;
            $s ~= '!important' if .important;
            self!normalize-quotes($s);
        }).join(';');
    }

    method !dq-to-sq(Str $s is copy --> Str) {
        $s ~~ s:g[ '\\"' ] = "\x0";
        $s ~~ s:g/ '"' /'/;
        $s ~~ s:g[ "\x0" ] = '"';
        $s;
    }

    method !url-quote-selector(Str $s --> Str) {
        my $r = $s;
        unless $r.contains("'") {
            $r = self!dq-to-sq($r);
        }
        self!url-quote-value($r);
    }

    method !normalize-quotes(Str $s is copy --> Str) {
        my $colon = $s.index(':');
        my $value = $colon.defined ?? $s.substr($colon + 1) !! $s;
        unless $value.contains("'") {
            $value = self!dq-to-sq($value);
            $s = $colon.defined ?? $s.substr(0, $colon + 1) ~ $value !! $value;
        }
        self!url-quote-value($s);
    }

    method !url-quote-value(Str $s is copy --> Str) {
        $s ~~ s:g[ :i url\( (\s*) ( \' .*? \' | \".*?\" | <-[()]>* [ \( ~ \) [ <-[()]>* ] ]* <-[()]>* ) (\s*) \) ] = do {
            my $c = $1;
            $c.contains('(') && $c.indices('(') != $c.indices(')')
                ?? ~$/
                !! 'url(' ~ $0 ~ self!url-quote(~$c) ~ $2 ~ ')'
        };
        $s;
    }

    method !url-quote(Str $u --> Str) {
        return $u if $u.starts-with("'") && $u.ends-with("'");
        return $u if $u.starts-with('"') && $u.ends-with('"');
        "'" ~ $u.subst("'", "\\'", :g) ~ "'"
    }

    # Color shortening: named colors -> hex, 6-char hex -> 3-char,
    # rgb() -> hex, rgba(...,1) -> hex.
    method !with-url-quarantine(Str $v is copy, &op --> Str) {
        return &op($v) unless $v.contains('url(');
        my @urls;
        $v ~~ s:g/ url\( ( \'.*?\' | \".*?\" | <-[()]>* [ \( ~ \) [ <-[()]>* ] ]* <-[()]>* ) \) /{
            my $c = $0;
            $c.contains('(') && $c.indices('(') != $c.indices(')')
                ?? ~$/
                !! (@urls.push(~$/) and "\x0" ~ @urls.end)
        }/;
        $v = &op($v);
        $v ~~ s:g/ \x0(\d+) /{@urls[$0]}/;
        $v;
    }



    method !guard-color(Str $key, Str $value --> Bool) {
        %COLOR-PROPS{$key.lc} && $value !~~ $UNSAFE-RE
    }

    method !apply-color-masks(Str $key, Str $value --> Str) {
        return $value unless self!guard-color($key, $value);
        self!with-url-quarantine($value, -> $v is copy {
            $v ~~ s:g/ <$NAMED-RE> /%NAMED{lc $/}/;
            $v = hsl-to-hex($v);
            $v = normalize-hex-value($v);
            $v;
        });
    }

    method !apply-font-weight(Str $key, Str $value --> Str) {
        return $value if $value ~~ $UNSAFE-RE;
        given $value {
            when /:i ^ bold $/   { return '700' }
            when /:i ^ normal $/ { return '400' }
        }
        $value;
    }

    method !apply-color-names(Str $key, Str $value --> Str) {
        return $value unless self!guard-color($key, $value);
        self!with-url-quarantine($value, -> $v is copy {
            $v = hsl-to-hex($v);
            $v = normalize-hex-value($v);
            $v ~~ s:g/ <$HEX-TO-NAMED-RE> /%HEX-TO-NAME{lc $/}/;
            $v;
        });
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Writer — Document-tree CSS serializer

=head1 DESCRIPTION

Serializes a C<Document> tree back into minified CSS.  Handles:

=item Quote normalization (double → single, with escaped-quote protection)
=item Color masking (named → hex, hex shortening, rgb → hex)
=item Color naming (hex → named, when C<:color-names> is set)
=item Font-weight normalization (bold → 700, normal → 400)
=item Zero-unit removal (0px → 0)
=item URL quote wrapping
=item Space insertion before C<{> for at-rules with a prelude

=head2 Attributes

=item C<$.sep> — separator between top-level statements (default '')
=item C<$.color-masks> — enable hex color shortening (default True)
=item C<$.color-names> — convert hex to named colors (default False)

When both C<:color-names> and C<:color-masks> are enabled, C<:color-names>
takes precedence (colors are named rather than hex-shortened).

=head2 Methods

=item C<write-document(Document $doc --> Str)> — renders the document
tree to a minified CSS string

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
