use CSS::Stylesheet;
use CSS::Ruleset;

unit module CSS::Minifier::Util:ver<0.0.6>:auth<zef:sasha>;

sub skip-quoted(Str $s, Int $i, Str $q --> Int) {
    my $pos = $i + 1;
    while $pos < $s.chars {
        given $s.substr($pos, 1) {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $s.chars
}

# Split an xpath selector list on ' | ' only when not inside brackets,
# parens, or string literals. This handles attribute selectors like
# [data-foo='bar, baz'] which naive split(', ') would break.
# CSS::Selector::To::XPath uses ' | ' (the XPath union operator) as the
# separator between selectors in a comma-separated CSS selector list.
sub split-xpath(Str $xpath --> List) is export {
    my @parts;
    my $start = 0;
    my $bracket = 0;
    my $paren = 0;
    my $i = 0;
    while $i < $xpath.chars {
        given $xpath.substr($i, 1) {
            when '[' { $bracket++; $i++ }
            when ']' { $bracket--; $i++ }
            when '(' { $paren++; $i++ }
            when ')' { $paren--; $i++ }
            when "'" { $i = skip-quoted($xpath, $i, "'") }
            when '|' {
                if $bracket == 0 && $paren == 0
                && $i > 0 && $i + 2 < $xpath.chars
                && $xpath.substr($i - 1, 3) eq ' | ' {
                    @parts.push: $xpath.substr($start, $i - $start - 1);
                    $i += 2;
                    $start = $i;
                } else { $i++ }
            }
            default { $i++ }
        }
    }
    @parts.push: $xpath.substr($start) if $start < $xpath.chars;
    @parts;
}

# Split a CSS selector list on ', ' only when not inside brackets, parens,
# or string literals. This preserves attribute selectors like
# [data-foo="bar, baz"] which naive split(', ') would break.
sub split-selectors(Str $s --> List) is export {
    my @parts;
    my $start = 0;
    my $bracket = 0;
    my $paren = 0;
    my $i = 0;
    while $i < $s.chars {
        given $s.substr($i, 1) {
            when '[' { $bracket++; $i++ }
            when ']' { $bracket--; $i++ }
            when '(' { $paren++; $i++ }
            when ')' { $paren--; $i++ }
            when '"' { $i = skip-quoted($s, $i, '"') }
            when "'" { $i = skip-quoted($s, $i, "'") }
            when ',' {
                if $bracket == 0 && $paren == 0
                && $i + 1 < $s.chars && $s.substr($i, 2) eq ', ' {
                    my $part = $s.substr($start, $i - $start);
                    @parts.push: $part if $part;
                    $i += 2;
                    $start = $i;
                } else { $i++ }
            }
            default { $i++ }
        }
    }
    my $last = $s.substr($start) if $start < $s.chars;
    @parts.push: $last if $last;
    @parts;
}

# CSS::MediaQuery has no .Str() or .xpath(). .ast.raku is the only
# reliable serialization — identical queries produce identical AST output.
sub media-key(CSS::Stylesheet $ss, CSS::Ruleset $rule --> Str) is export {
    $ss.rule-media{$rule}.defined
        ?? $ss.rule-media{$rule}.ast.raku
        !! '';
}

sub same-media(CSS::Stylesheet $ss, CSS::Ruleset $a, CSS::Ruleset $b --> Bool) is export {
    media-key($ss, $a) eq media-key($ss, $b);
}

=begin pod

=head1 NAME

CSS::Minifier::Util - Shared utility functions for minification plugins

=head1 DESCRIPTION

Provides common helper routines used by multiple plugins to avoid code
duplication.

=head2 C<split-xpath(Str $xpath)>

Splits an XPath selector list on C< | > (XPath union operator), skipping
string literals, brackets, and parentheses. This preserves attribute-value
commas inside predicates (e.g. C<[@data-foo='bar, baz']>) that naive
C<split(' | ')> would break. Used by the Merging plugin's
C<!dedup-selector-lists>.

=head2 C<split-selectors(Str $s)>

Splits a CSS selector list on C<, > (comma-space), respecting strings,
brackets, and parentheses. This preserves attribute-value commas inside
selectors (e.g. C<[data-foo="bar, baz"]>). Used by C<!merge-decls> to
dedup qualifier selector lists before checking property existence against
pipeline-deduped output.

=head2 C<media-key($ss, $rule)>

Returns a string key representing the C<@media> context of a rule. Rules
outside any C<@media> block return an empty string. Used by the Dedup plugin
to prevent cross-media duplicates.

=head2 C<same-media($ss, $a, $b)>

Returns True if both rules share the same C<@media> context (or both are
unwrapped). Used by the Merging plugin to prevent cross-media merging.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
