# CSS::Minifier

Raku CSS minifier - produces smaller CSS through value normalization, color shortening, shorthand consolidation, and structural deduplication/merging.

## Features
- **Plugin pipeline** - modular optimization passes (values, colors, dedup, merging)
- **Two levels** - level 1 (safe normalizations) vs level 2 (structural optimizations)
- **Color optimization** - shorten hex colors, optionally convert to named colors
- **Shorthand consolidation** - margin, padding, border, border-{top,right,bottom,left}, outline, list-style, background, font longhands consolidated to shorthand
- **Value normalization** - `bold` → `700`, `normal` → `400`
- **Duplicate removal** - identical rulesets and `@font-face` blocks deduplicated
- **Ruleset merging** - same-selector rules merged, same-declaration selectors combined
- **License preservation** - `/*! */` comments kept with `--preserve-licenses`
- **Custom property support** - `--*` declarations preserved verbatim, not dedupped
- **CLI tool** - `cssminify` with stdin/file input and output redirection

## Installation

```bash
zef install CSS::Minifier
```

### Installing from source

```bash
cd /path/to/CSS-Minifier
zef install .
```

Requires Raku 6.d or later.

## Usage

### Command Line

```bash
# Read from file
cssminify input.css > output.css

# Level 2 (structural optimizations: dedup, merging)
cssminify -l2 input.css > output.css

# Write to file
cssminify -o output.css input.css

# Read from stdin
cat input.css | cssminify

# Preserve license comments
cssminify -p input.css

# Disable hex color shortening (keep #FF0000 instead of #F00)
cssminify --no-color-masks input.css

# Separate rules with newlines (readable output)
cssminify -r input.css

# Convert hex colors to named colors
cssminify -n input.css

# Verbose output (log plugin names)
cssminify -v input.css

# Print version
cssminify --version
```

#### Flags

| Short | Long | Description |
|---|---|---|
| `-o` | `--output` | Write to file instead of stdout |
| `-l` | `--level` | Optimization level: 1 (safe normalizations) or 2 (structural, default) |
| `-p` | `--preserve-licenses` | Keep `/*! */` license comments |
| `-n` | `--color-names` | Convert hex colors to named colors |
| `-m` / `-/m` | `--color-masks` / `--no-color-masks` | Enable/disable hex color shortening |
| `-r` | `--readable` | Separate rules with newlines |
| `-v` | `--verbose` | Log plugin names to stderr |
| | `--version` | Print version and exit |

Short flags with values can use `=`, fused, or space-separated syntax: `-l=2`, `-l2`, or `-l 2`.

### Environment

| Variable | Description |
|---|---|
| `CSS_MINIFIER_CACHE_MAX` | Max internal character-array cache entries (default 500). Increase for large stylesheets to reduce repeated string scanning during parsing. |

### Library

```raku
use CSS::Minifier;

# Level 2 - structural optimizations (dedup, merging, default)
my $min = CSS::Minifier.minify($css);

# Level 1 - safe normalizations only
my $min = CSS::Minifier.minify($css, :level(1));

# Preserve license comments
my $min = CSS::Minifier.minify($css, :preserve-licenses);

# Convert hex colors to named colors
my $min = CSS::Minifier.minify($css, :color-names);

# Disable hex color shortening
my $min = CSS::Minifier.minify($css, :!color-masks);

# Add custom plugins (runs after all level plugins, in append order)
# Custom plugins must implement the CSS::Minifier::Plugin role.
my $min = CSS::Minifier.minify($css, :level(2), :extra-plugins[$my-plugin]);
```

## Optimization Levels

### Level 1
- Font-weight normalization (`bold` → `700`, `normal` → `400`)
- Color shortening (`#FF0000` → `#F00`, `red` → `#F00`)
- Comment removal (`/*! */` kept with `--preserve-licenses`)
- Whitespace and quote normalization
- Shorthand consolidation (margin, padding, border, border-*, outline, list-style, background, font)

### Level 2 (default)
- Duplicate ruleset removal
- `@font-face` deduplication
- Same-selector ruleset merging
- Same-declaration selector combination

## Examples

### Input
```css
h1 { color: red; }
h2 { color: red; }
h1 { margin: 0; }
```

### Level 1 Output
```css
h1{color:#F00}h2{color:#F00}h1{margin:0}
```

### Level 2 Output
```css
h1,h2{color:#F00}h1{margin:0}
```

## AUTHOR

Sasha Abbott <sashaa@disroot.org>

## LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

Contains HSL→RGB conversion code adapted from
[Color](https://github.com/raku-community-modules/Color)
(Artistic License 2.0) — see `LICENSE.ARTISTIC`.
