unit module CSS::Minifier::Util:ver<0.0.13>:auth<zef:sasha>;

my constant COMB-CACHE-MAX  = max(min((%*ENV<CSS_MINIFIER_CACHE_MAX> // 500).Int, 10_000), 1);
my constant COMB-CACHE-SMALL = (%*ENV<CSS_MINIFIER_COMB_SMALL> // 80).Int;
constant $SENTINEL is export = "\x[E000]\x[E001]";
sub is-custom-prop(Str $p --> Bool) is export { $p.starts-with('--') }
my %COMB-CACHE;
my @COMB-ORDER;
my $COMB-POS = 0;
my $COMB-LOCK = Lock.new;

# Skip past a /* ... */ comment in a char array, stopping at the */.
# Expects @chars[$i-1] eq '/' && @chars[$i] eq '*' (i.e. the /* has been consumed
# and $i points to the first char after /*).
sub skip-comment-chars(@chars, Int $i is rw, Int $len --> Nil) is export {
    $i++ while $i < $len && !(@chars[$i-1] eq '*' && @chars[$i] eq '/');
}

# Skip past a /* ... */ comment using string-based index lookup.
# $i points to the '/' of the opening /* before the call.
sub skip-comment-str(Str $raw, Int $i is rw, Int $len --> Nil) is export {
    my $end = $raw.index('*/', $i+2);
    $i = ($end // $len - 2) + 2;
}

sub comb-cached(Str $s) is export {
    return $s.comb.List if $s.chars < COMB-CACHE-SMALL;

    my $found = $COMB-LOCK.protect: {
        if %COMB-CACHE{$s}:exists {
            my $entry = %COMB-CACHE{$s};
            if %COMB-CACHE.elems >= COMB-CACHE-MAX {
                my $pos = $entry[1];
                if $pos != $COMB-POS {
                    my $at-cursor = @COMB-ORDER[$COMB-POS];
                    my $cursor-entry = %COMB-CACHE{$at-cursor};
                    $cursor-entry[1] = $pos if $cursor-entry.defined;
                    @COMB-ORDER[$pos] = $at-cursor;
                    @COMB-ORDER[$COMB-POS] = $s;
                    $entry[1] = $COMB-POS;
                }
            }
            $COMB-POS = ($COMB-POS + 1) % COMB-CACHE-MAX;
            $entry[0]
        }
    }
    return $found if $found.defined;

    my $list = $s.comb.List;
    $COMB-LOCK.protect: {
        if %COMB-CACHE{$s}:exists {
            %COMB-CACHE{$s}[0]
        } elsif %COMB-CACHE.elems >= COMB-CACHE-MAX {
            my $oldest = @COMB-ORDER[$COMB-POS];
            %COMB-CACHE{$oldest}:delete if $oldest.defined;
            @COMB-ORDER[$COMB-POS] = $s;
            $COMB-POS = ($COMB-POS + 1) % COMB-CACHE-MAX;
            %COMB-CACHE{$s} = [$list, ($COMB-POS - 1) % COMB-CACHE-MAX];  # slot $COMB-POS - 1 ≡ (old $COMB-POS) before line 57 advanced it
            $list
        } else {
            @COMB-ORDER.push: $s;
            %COMB-CACHE{$s} = [$list, @COMB-ORDER.end];
            $list
        }
    }
}

# Clears the internal character-combination cache used by comb-cached.
# Call this between independent parse jobs to free memory when the
# cache holds strings from a prior batch that won't be reused.
sub clear-comb-cache(--> Nil) is export {
    $COMB-LOCK.protect: {
        %COMB-CACHE = ();
        @COMB-ORDER = ();
        $COMB-POS = 0;
    }
}

our constant %NAMED is export =
    aliceblue                    => '#F0F8FF',
    antiquewhite                 => '#FAEBD7',
    aqua                         => '#00FFFF',
    aquamarine                   => '#7FFFD4',
    azure                        => '#F0FFFF',
    beige                        => '#F5F5DC',
    bisque                       => '#FFE4C4',
    black                        => '#000000',
    blanchedalmond               => '#FFEBCD',
    blue                         => '#0000FF',
    blueviolet                   => '#8A2BE2',
    brown                        => '#A52A2A',
    burlywood                    => '#DEB887',
    cadetblue                    => '#5F9EA0',
    chartreuse                   => '#7FFF00',
    chocolate                    => '#D2691E',
    coral                        => '#FF7F50',
    cornflowerblue               => '#6495ED',
    cornsilk                     => '#FFF8DC',
    crimson                      => '#DC143C',
    cyan                         => '#00FFFF',
    darkblue                     => '#00008B',
    darkcyan                     => '#008B8B',
    darkgoldenrod                => '#B8860B',
    darkgray                     => '#A9A9A9',
    darkgreen                    => '#006400',
    darkgrey                     => '#A9A9A9',
    darkkhaki                    => '#BDB76B',
    darkmagenta                  => '#8B008B',
    darkolivegreen               => '#556B2F',
    darkorange                   => '#FF8C00',
    darkorchid                   => '#9932CC',
    darkred                      => '#8B0000',
    darksalmon                   => '#E9967A',
    darkseagreen                 => '#8FBC8F',
    darkslateblue                => '#483D8B',
    darkslategray                => '#2F4F4F',
    darkslategrey                => '#2F4F4F',
    darkturquoise                => '#00CED1',
    darkviolet                   => '#9400D3',
    deeppink                     => '#FF1493',
    deepskyblue                  => '#00BFFF',
    dimgray                      => '#696969',
    dimgrey                      => '#696969',
    dodgerblue                   => '#1E90FF',
    firebrick                    => '#B22222',
    floralwhite                  => '#FFFAF0',
    forestgreen                  => '#228B22',
    fuchsia                      => '#FF00FF',
    gainsboro                    => '#DCDCDC',
    ghostwhite                   => '#F8F8FF',
    gold                         => '#FFD700',
    goldenrod                    => '#DAA520',
    gray                         => '#808080',
    green                        => '#008000',
    greenyellow                  => '#ADFF2F',
    grey                         => '#808080',
    honeydew                     => '#F0FFF0',
    hotpink                      => '#FF69B4',
    indianred                    => '#CD5C5C',
    indigo                       => '#4B0082',
    ivory                        => '#FFFFF0',
    khaki                        => '#F0E68C',
    lavender                     => '#E6E6FA',
    lavenderblush                => '#FFF0F5',
    lawngreen                    => '#7CFC00',
    lemonchiffon                 => '#FFFACD',
    lightblue                    => '#ADD8E6',
    lightcoral                   => '#F08080',
    lightcyan                    => '#E0FFFF',
    lightgoldenrodyellow         => '#FAFAD2',
    lightgray                    => '#D3D3D3',
    lightgreen                   => '#90EE90',
    lightgrey                    => '#D3D3D3',
    lightpink                    => '#FFB6C1',
    lightsalmon                  => '#FFA07A',
    lightseagreen                => '#20B2AA',
    lightskyblue                 => '#87CEFA',
    lightslategray               => '#778899',
    lightslategrey               => '#778899',
    lightsteelblue               => '#B0C4DE',
    lightyellow                  => '#FFFFE0',
    lime                         => '#00FF00',
    limegreen                    => '#32CD32',
    linen                        => '#FAF0E6',
    magenta                      => '#FF00FF',
    maroon                       => '#800000',
    mediumaquamarine             => '#66CDAA',
    mediumblue                   => '#0000CD',
    mediumorchid                 => '#BA55D3',
    mediumpurple                 => '#9370DB',
    mediumseagreen               => '#3CB371',
    mediumslateblue              => '#7B68EE',
    mediumspringgreen            => '#00FA9A',
    mediumturquoise              => '#48D1CC',
    mediumvioletred              => '#C71585',
    midnightblue                 => '#191970',
    mintcream                    => '#F5FFFA',
    mistyrose                    => '#FFE4E1',
    moccasin                     => '#FFE4B5',
    navajowhite                  => '#FFDEAD',
    navy                         => '#000080',
    oldlace                      => '#FDF5E6',
    olive                        => '#808000',
    olivedrab                    => '#6B8E23',
    orange                       => '#FFA500',
    orangered                    => '#FF4500',
    orchid                       => '#DA70D6',
    palegoldenrod                => '#EEE8AA',
    palegreen                    => '#98FB98',
    paleturquoise                => '#AFEEEE',
    palevioletred                => '#DB7093',
    papayawhip                   => '#FFEFD5',
    peachpuff                    => '#FFDAB9',
    peru                         => '#CD853F',
    pink                         => '#FFC0CB',
    plum                         => '#DDA0DD',
    powderblue                   => '#B0E0E6',
    purple                       => '#800080',
    rebeccapurple                => '#663399',
    red                          => '#FF0000',
    rosybrown                    => '#BC8F8F',
    royalblue                    => '#4169E1',
    saddlebrown                  => '#8B4513',
    salmon                       => '#FA8072',
    sandybrown                   => '#F4A460',
    seagreen                     => '#2E8B57',
    seashell                     => '#FFF5EE',
    sienna                       => '#A0522D',
    silver                       => '#C0C0C0',
    skyblue                      => '#87CEEB',
    slateblue                    => '#6A5ACD',
    slategray                    => '#708090',
    slategrey                    => '#708090',
    snow                         => '#FFFAFA',
    springgreen                  => '#00FF7F',
    steelblue                    => '#4682B4',
    tan                          => '#D2B48C',
    teal                         => '#008080',
    thistle                      => '#D8BFD8',
    tomato                       => '#FF6347',
    turquoise                    => '#40E0D0',
    violet                       => '#EE82EE',
    wheat                        => '#F5DEB3',
    white                        => '#FFFFFF',
    whitesmoke                   => '#F5F5F5',
    yellow                       => '#FFFF00',
    yellowgreen                  => '#9ACD32',
;

our constant %COLOR-PROPS is export = Set.new(<
    color background background-color
    border border-color border-top border-right border-bottom border-left
    border-top-color border-right-color border-bottom-color border-left-color
    border-block border-inline border-block-start border-block-end
    border-inline-start border-inline-end
    border-block-color border-inline-color
    border-block-start-color border-block-end-color
    border-inline-start-color border-inline-end-color
    outline outline-color
    text-decoration text-decoration-color
    text-shadow box-shadow
    column-rule column-rule-color
    caret-color accent-color
    scrollbar-color scrollbar-face-color scrollbar-track-color
    scrollbar-arrow-color scrollbar-thumb-color
    -webkit-tap-highlight-color
    fill stroke stop-color flood-color lighting-color
    text-fill-color text-stroke-color
    -webkit-text-fill-color -webkit-text-stroke-color
>);

our constant %HEX-TO-NAME is export = do {
    my %map = %NAMED.map({ .value.lc => .key });
    %map.append: %NAMED.map({
        my $v = .value.lc;
        my $short = $v.subst(/ ^ '#' (<xdigit>) $0 (<xdigit>) $1 (<xdigit>) $2 $ /, { '#' ~ $0 ~ $1 ~ $2 });
        $v eq $short ?? Empty !! ($short => .key)
    });
    %map;
};

our constant $UNSAFE-RE is export = rx:i/
    var\s*\( | calc\s*\( | env\s*\( |
    min\s*\( | max\s*\( | clamp\s*\( |
    round\s*\( | mod\s*\( | rem\s*\( |
    sin\s*\( | cos\s*\( | tan\s*\( |
    asin\s*\( | acos\s*\( | atan\s*\( | atan2\s*\( |
    pow\s*\( | sqrt\s*\( | hypot\s*\( |
    exp\s*\( | log\s*\( |
    abs\s*\( | sign\s*\(
/;

our $LENGTH-UNITS is export;
our $UNITS is export;
BEGIN {
    $LENGTH-UNITS = rx/
        px|em|ex|ch|rem|cap|ic|lh|rlh|
        vh|vw|vmin|vmax|vb|vi|svw|svh|lvw|lvh|dvw|dvh|
        cqw|cqh|cqi|cqb|cqmin|cqmax|
        cm|mm|in|pt|pc|q
    /;
    $UNITS = rx/
        <$LENGTH-UNITS> |
        deg|grad|rad|turn|s|ms|Hz|kHz|
        dpi|dpcm|dppx|
        fr
    /;
}

sub normalize-hex-value(Str $v, Bool :$short = True --> Str) is export {
    my $v2 = rgb-values-to-hex($v);
    $v2 ~~ s:g[ <[#]> ( <xdigit> ) $0 ( <xdigit> ) $1 ( <xdigit> ) $2 ( <xdigit> ) $3 ] = '#' ~ $0.uc ~ $1.uc ~ $2.uc ~ $3.uc if $short;
    $v2 ~~ s:g[ <[#]> ( <xdigit> ) $0 ( <xdigit> ) $1 ( <xdigit> ) $2 <!before <xdigit>> ] = '#' ~ $0.uc ~ $1.uc ~ $2.uc if $short;
    $v2 ~~ s:g[ '#' (<[0..9 A..F a..f]>+) <!before <xdigit>> ] = '#' ~ $0.uc if $short;
    $v2;
}

sub strip-zero-units(Str $value --> Str) is export {
    return $value unless $value ~~ /<[\d.]>/;
    return $value if $value ~~ $UNSAFE-RE;
    return $value if $value.contains('url(');
    my $v = $value;

    unless $v.contains('"') || $v.contains("'") {
        $v ~~ s:g/ (\d*) '.' 0+ (<$UNITS>) /{($0 || '0') ~ $1}/;
        $v ~~ s:g/ (\d*) '.' 0+ <!before <[\d.]>> /{$0 || '0'}/;
        $v ~~ s:g/ <!after <[\d._]>> <!after <:L>> <[+-]>? 0 <$LENGTH-UNITS> <?!alpha> /0/;
        return $v;
    }

    my @chars = $v.comb;
    my $out = '';
    my $buf = '';
    my $i = 0;
    my $len = @chars.elems;
    while $i < $len {
        my $c = @chars[$i];
        if $c eq '"' || $c eq "'" {
            $buf ~~ s:g/ (\d*) '.' 0+ (<$UNITS>) /{($0 || '0') ~ $1}/;
            $buf ~~ s:g/ (\d*) '.' 0+ <!before <[\d.]>> /{$0 || '0'}/;
            $buf ~~ s:g/ <!after <[\d._]>> <!after <:L>> <[+-]>? 0 <$LENGTH-UNITS> <?!alpha> /0/;
            $out ~= $buf;
            $buf = '';
            my $end = skip-quoted($v, $i, $c);
            $out ~= $v.substr($i, $end - $i);
            $i = $end;
        } else {
            $buf ~= $c;
            $i++;
        }
    }
    $buf ~~ s:g/ (\d*) '.' 0+ (<$UNITS>) /{($0 || '0') ~ $1}/;
    $buf ~~ s:g/ (\d*) '.' 0+ <!before <[\d.]>> /{$0 || '0'}/;
    $buf ~~ s:g/ <!after <[\d._]>> <!after <:L>> <[+-]>? 0 <$LENGTH-UNITS> <?!alpha> /0/;
    $out ~= $buf;
    $out;
}

# Quarantine url() so internal color names and parens aren't
# falsely normalized; restore after &op.  Handles arbitrary
# paren nesting depth by counting parens character-by-character.
sub with-url-quarantine(Str $v is copy, &op --> Str) is export {
    return &op($v) unless $v.contains('url(');
    my Str @urls;
    my @chars = $v.comb;
    my $out = '';
    my $i = 0;
    loop {
        my $start = $v.index('url(', $i);
        last without $start;
        $out ~= $v.substr($i, $start - $i);
        my $depth = 1;
        my $j = $start + 4;
        while $j < @chars.elems && $depth > 0 {
            my $c = @chars[$j];
            if $c eq '(' { $depth++ }
            elsif $c eq ')' { $depth-- }
            elsif $c eq '"' || $c eq "'" { $j = skip-quoted($v, $j, $c); next }
            $j++;
        }
        @urls.push: $v.substr($start, $j - $start);
        $out ~= $SENTINEL ~ @urls.end;
        $i = $j;
    }
    $out ~= $v.substr($i) if $i < $v.chars;
    $v = &op($out);
    $v ~~ s:g/ $SENTINEL (\d+) /{@urls[$0]}/;
    $v;
}

our $NAMED-RE is export;
our $HEX-TO-NAMED-RE is export;
BEGIN {
    $NAMED-RE = rx:i/ << @(%NAMED.keys) >> /;
    $HEX-TO-NAMED-RE = rx:i/ <!after <xdigit>> @(%HEX-TO-NAME.keys) <!before <xdigit>> /;
}

sub normalize-value(Str $property, Str $value --> Str) is export {
    return $value if is-custom-prop($property);
    my $v = $value;
    if %COLOR-PROPS{$property.lc} && $v !~~ $UNSAFE-RE {
        $v = with-url-quarantine($v, -> $v is copy {
            $v ~~ s:g/ <$NAMED-RE> /%NAMED{lc $/}/ if $v ~~ /<[a..zA..Z]>/;
            $v = hsl-to-hex($v);
            $v = normalize-hex-value($v);
            $v;
        });
    }
    if $property.lc eq 'font-weight' {
        $v ~~ s/ :i ^ bold $ /700/;
        $v ~~ s/ :i ^ normal $ /400/;
    }
    $v = strip-zero-units($v);
    $v;
}

my sub conv($x, $pct) {
    $pct
        ?? (((+$x * 255 / 100).round max 0) min 255).fmt('%02X')
        !! (((+$x).round max 0) min 255).fmt('%02X')
}

# rgba? is faster and clearer than [rgb|rgba] — no backtrack for rgba(…
sub rgb-values-to-hex(Str $v is copy --> Str) is export {
    return $v unless $v.contains('rgb', :i);
    $v ~~ s:g:i[
        rgba?\( \s*
        (\d*\.?\d+) (\%?)
        [ \s* ',' \s* | \s+ ]
        (\d*\.?\d+) (\%?)
        [ \s* ',' \s* | \s+ ]
        (\d*\.?\d+) (\%?)
        [ \s* [ '/' | ',' ] \s* [ 1 ['.' 0*]? | 100 '%'? ] ]?
        \s* \)
    ] = '#' ~ conv($0, $1 eq '%') ~ conv($2, $3 eq '%') ~ conv($4, $5 eq '%');
    $v;
}

sub split-top-level(Str $v --> List) is export {
    my @parts;
    my $start = 0;
    my $depth = 0;
    my $i = 0;
    my $len = $v.chars;
    my @chars := comb-cached($v);
    while $i < $len {
        given @chars[$i] {
            when '('   { $depth++; $i++ }
            when ')'   { $depth--; $i++ }
            when '"'   { $i = skip-quoted($v, $i, '"') }
            when "'"   { $i = skip-quoted($v, $i, "'") }
            when '/'  {
                if $i + 1 < $len && @chars[$i+1] eq '*' {
                    skip-comment-str($v, $i, $len);
                } else { $i++ }
            }
            when ','   {
                if $depth == 0 {
                    my $seg = $v.substr($start, $i - $start).trim;
                    @parts.push: $seg if $seg.chars;
                    $start = $i + 1;
                }
                $i++
            }
            default    { $i++ }
        }
    }
    my $last = $v.substr($start).trim;
    @parts.push: $last if $last.chars;
    @parts
}

multi sub skip-quoted(Str $s, Int $i, Str $q --> Int) is export {
    skip-quoted(comb-cached($s), $i, $q);
}
multi sub skip-quoted(@chars, Int $i, Str $q --> Int) is export {
    my $pos = $i + 1;
    my $len = @chars.elems;
    while $pos < $len {
        given @chars[$pos] {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $len
}

# HSL→RGB conversion adapted from Color::Conversion (https://github.com/raku-community-modules/Color)
# Copyright 2015-2018 Zoffix Znet
# Copyright 2019-2022 Raku Community
# Licensed under Artistic License 2.0 — see LICENSE.ARTISTIC
sub hsl2rgb($h is copy, $s is copy, $l is copy) is export {
    $s /= 100;
    $l /= 100;
    $h %= 360;
    my $c = (1 - abs(2*$l - 1)) * $s;
    my $x = $c * (1 - abs( (($h/60) % 2) - 1 ));
    my $m = $l - $c/2;
    rgb-from-c-x-m($h, $c, $x, $m)
}

sub rgb-from-c-x-m($h, $c, $x, $m) is export {
    my ($r, $g, $b);
    given $h {
        when   0..^60  { ($r, $g, $b) = ($c, $x, 0) }
        when  60..^120 { ($r, $g, $b) = ($x, $c, 0) }
        when 120..^180 { ($r, $g, $b) = (0, $c, $x) }
        when 180..^240 { ($r, $g, $b) = (0, $x, $c) }
        when 240..^300 { ($r, $g, $b) = ($x, 0, $c) }
        when 300..^360 { ($r, $g, $b) = ($c, 0, $x) }
    }
    ($r, $g, $b) = ($r,$g,$b).map: { ($_ + $m) * 255 };
    (+$r.round, +$g.round, +$b.round)
}

sub hsl-capture-to-hex($h-str, $h-unit, $s-str, $l-str, $a-str) is export {
    my $h = +($h-str // 0);
    given ($h-unit // '').lc {
        when 'rad'  { $h = $h * 180 / π }
        when 'grad' { $h = $h * 0.9 }
        when 'turn' { $h = $h * 360 }
    }
    if $a-str.chars {
        my $a = +($a-str.ends-with('%') ?? $a-str.substr(0, *-1) !! $a-str);
        return Nil unless $a == 1 || $a == 100;
    }
    my ($r, $g, $b) = hsl2rgb($h, +($s-str // 0), +($l-str // 0));
    sprintf('#%02X%02X%02X', $r, $g, $b)
}

# Convert all hsl() / hsla() in a string to hex. Skips when alpha ≠ 1.
sub hsl-to-hex(Str $value --> Str) is export {
    my $v = $value;
    my $result = '';
    my $pos = 0;
    for $v ~~ m:g:i{
        hsla?\( \s*
        ( <[+-]>? \d* \.? \d+ ) (deg|rad|grad|turn)? \s*
        [ ',' \s* | \s+ ]
        ( <[+-]>? \d* \.? \d+ ) '%' \s*
        [ ',' \s* | \s+ ]
        ( <[+-]>? \d* \.? \d+ ) '%' \s*
        [ [ '/' | ',' ] \s* ( [ 1 ['.' 0*]? | 100 '%' | 100 ] ) \s* ]?
        \)
    } -> $match {
        $result ~= $v.substr($pos, $match.from - $pos);
        $result ~= hsl-capture-to-hex(
            ~($match[0] // ''), ~($match[1] // ''), ~($match[2] // ''),
            ~($match[3] // ''), ~($match[4] // ''))
            // $match.Str;
        $pos = $match.to;
    }
    $result ~= $v.substr($pos);
    $result
}

=begin pod

=head1 NAME

CSS::Minifier::Util — utility functions for CSS parsing

=head1 DESCRIPTION

Low-level helper subroutines used by the parser and normalizer.

=head2 Subs

=item C<split-top-level(Str $v --> List)> — splits a string on commas
at paren depth 0, trimming each segment and skipping empty ones.
Returns a list of strings. No inverse needed — C<.elems E<gt> 1> on the result is the equivalent check.

=item C<skip-quoted(Str $s, Int $i, Str $q --> Int)> — skips to the
position after a closing quote character C<$q>, handling backslash
escapes.  Returns C<$s.chars> if the closing quote is not found.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify
it under CC0.

=end pod
