unit class CSS::Minifier:ver<0.0.2>:auth<zef:sasha>;

use CSS::Stylesheet;
use CSS::Minifier::Pipeline;
use CSS::Minifier::Plugin::Values;
use CSS::Minifier::Plugin::Dedup;
use CSS::Minifier::Plugin::Merging;
use CSS::Minifier::Writer;

my constant %SAFE-AT-RULES = Set.new: <@media @page @font-face>;
my constant %SHORTHAND = Map.new(
    # CSS::Properties consolidates these longhands to shorthands at parse time
    'background-color'    => 'background',
    'background-image'    => 'background',
    'background-repeat'   => 'background',
    'background-position' => 'background',
    'background-attachment' => 'background',
    'background-clip'     => 'background',
    'background-origin'   => 'background',
    'background-size'     => 'background',
    'border-color'     => 'border',
    'border-style'     => 'border',
    'border-width'     => 'border',
    'border-top-color'   => 'border-top',
    'border-top-style'   => 'border-top',
    'border-top-width'   => 'border-top',
    'border-right-color'   => 'border-right',
    'border-right-style'   => 'border-right',
    'border-right-width'   => 'border-right',
    'border-bottom-color'   => 'border-bottom',
    'border-bottom-style'   => 'border-bottom',
    'border-bottom-width'   => 'border-bottom',
    'border-left-color'   => 'border-left',
    'border-left-style'   => 'border-left',
    'border-left-width'   => 'border-left',
    'outline-color' => 'outline',
    'outline-style' => 'outline',
    'outline-width' => 'outline',
    'list-style-type'     => 'list-style',
    'list-style-position' => 'list-style',
    'list-style-image'    => 'list-style',
    'font-style'      => 'font',
    'font-weight'     => 'font',
    'font-stretch'    => 'font',
    'font-size'       => 'font',
    'line-height'     => 'font',
    'font-family'     => 'font',
    'margin-top'      => 'margin',
    'margin-right'    => 'margin',
    'margin-bottom'   => 'margin',
    'margin-left'     => 'margin',
    'padding-top'     => 'padding',
    'padding-right'   => 'padding',
    'padding-bottom'  => 'padding',
    'padding-left'    => 'padding',
);

# note: CSS::Stylesheet strips all comments at parse time, so we extract
# /*! */ license comments from the raw string before parsing.
method minify(Str $css, :$level = 1, Bool :$verbose = False, Bool :$preserve-licenses,
    Bool :$color-masks = True, Bool :$preserve-unknown = True, :@extra-plugins, *%opts) returns Str {
    my @licenses = $css.comb(/ '/*!' .*? '*/' /) if $preserve-licenses;
    my %unknown-decls;
    self!walk-decls($css, '', %unknown-decls) if $preserve-unknown;

    my $stylesheet;
    my Pair $ast;
    {
        temp $*ERR = $preserve-unknown
            ?? class { method print(|) { }; method say(|) { }; method note(|) { } }.new
            !! $*ERR;
        $stylesheet = CSS::Stylesheet.parse($css);

        my @plugins = self!plugins-for($level);
        for @extra-plugins -> $p {
            die "Extra plugin {$p.^name} does not implement CSS::Minifier::Plugin"
                unless $p ~~ CSS::Minifier::Plugin;
        }
        @plugins.append: @extra-plugins;

        my CSS::Minifier::Pipeline $pipeline .= new:
            :$verbose,
            :@plugins;

        $pipeline.run($stylesheet);

        $ast = $stylesheet.ast(:optimize);
    }
    my CSS::Minifier::Writer $writer .= new:
        :!pretty,
        :$color-masks,
        |%opts;

    my $output = $writer.write($ast);
    $output = self!merge-decls($output, %unknown-decls) if $preserve-unknown;
    $output = @licenses.join("\n") ~ "\n" ~ $output if @licenses;
    $output;
}

# Extract declarations from raw CSS before parsing.
# Uses recursive brace-counting to handle at-rules like @media, @supports,
# @container, @layer, etc. — any at-rule with a { } block.
# When $unsafe is True (inside an at-rule CSS::Stylesheet drops, e.g.
# @keyframes, @supports), ALL declarations are captured to prevent data
# loss. When False (top-level or inside @media/@page/@font-face), all
# declarations are captured (the known-props filter was removed to catch
# CSS3 values that the pipeline drops). The %SHORTHAND map in
# !prop-exists prevents re-injecting longhands already consolidated to
# shorthands by CSS::Properties.
# Returns a Map of qualified-selector => [(property => value), ...].
method !walk-decls(Str $s, Str $prefix, %by-sel, Bool :$unsafe = False) {
    my $i = 0;
    my $len = $s.chars;

    while $i < $len {
        given $s.substr($i,1) {
            when /\s/ { $i++; next }
            when '/'  { if $s.substr($i,2) eq '/*' {
                            $i = ($s.index('*/', $i+2) // $len) + 2; next
                        } }
            when '"'  { $i = skip-quoted($s, $i, '"'); next }
            when "'"  { $i = skip-quoted($s, $i, "'"); next }
            when '}'  { $i++; next }
        }

        my $brace = $i;
        while $brace < $len {
            given $s.substr($brace,1) {
                when '{' { last }
                when '"' { $brace = skip-quoted($s, $brace, '"') }
                when "'" { $brace = skip-quoted($s, $brace, "'") }
                when '/' { if $s.substr($brace,2) eq '/*' {
                               $brace = ($s.index('*/', $brace+2) // $len) + 2
                           } else { $brace++ } }
                default  { $brace++ }
            }
        }
        last if $brace >= $len;

        my $raw = $s.substr($i, $brace - $i).trim;
        $raw ~~ s:g/ \s+ / /;
        my $end = matching-close($s, $brace);

        if $raw.starts-with('@') {
            my $at-name = $raw.split(/\s+/)[0];
            my $new-unsafe = $unsafe || $at-name ∉ %SAFE-AT-RULES;
            self!walk-decls($s.substr($brace+1, $end - $brace - 1),
                           $prefix ~ $raw ~ ' ', %by-sel, :unsafe($new-unsafe));
        }
        elsif $raw {
            my $qual = $prefix ?? "$prefix\{$raw\}" !! $raw;
            my $body = $s.substr($brace+1, $end - $brace - 1);
            my @decls;
            for $body.match(:g, / $<key>=<-[:;]>+ \s* ':' \s* $<val>=<-[;}]>+ ';'? /) -> $m {
                my $key = $m<key>.Str.trim;
                @decls.push: $key => $m<val>.Str.trim;
            }
            %by-sel{$qual}.append(@decls) if @decls;
        }

        $i = $end + 1;
    }
}

sub matching-close(Str $s, Int $start --> Int) {
    my $depth = 1;
    my $i = $start + 1;
    while $i < $s.chars && $depth > 0 {
        given $s.substr($i, 1) {
            when '{'  { $depth++; $i++ }
            when '}'  { $depth--; $i++ }
            when '"'  { $i = skip-quoted($s, $i, '"') }
            when "'"  { $i = skip-quoted($s, $i, "'") }
            when '/'  { if $s.substr($i,2) eq '/*' {
                            $i = ($s.index('*/', $i+2) // $s.chars) + 2
                        } else { $i++ } }
            default   { $i++ }
        }
    }
    $i - 1
}

sub skip-quoted(Str $s, Int $i, Str $q --> Int) {
    my $pos = $i + 1;
    while $pos < $s.chars {
        given $s.substr($pos, 1) {
            when '\\' { $pos += 2 }
            when $q  { return $pos + 1 }
            default  { $pos++ }
        }
    }
    $s.chars
}

# Find the position of the opening brace for an at-rule block,
# accounting for the writer's optional space before {.
# Returns the index of {, or Nil.
method !find-at-rule-block(Str $out, Str $prelude --> Int) {
    my $pos = $out.index($prelude ~ '{') // $out.index($prelude ~ ' {');
    return Nil unless $pos.defined;
    $pos + $out.substr($pos).index('{');
}

# Scoped property-exists check: return True if $key: appears within
# the ruleset matching $qual in $out.
# Check if $key:~ (or its shorthand) appears within the ruleset body
# at the given brace position in $out.
method !check-key-in-body(Str $out, Int $brace-pos, Str $key --> Bool) {
    my $end = matching-close($out, $brace-pos);
    my $body = $out.substr($brace-pos + 1, $end - $brace-pos - 1);
    so $body.contains($key ~ ':')
        || %SHORTHAND{$key} && $body.contains(%SHORTHAND{$key} ~ ':');
}

method !prop-exists(Str $out, Str $qual, Str $key --> Bool) {
    if $qual.starts-with('@') {
        my $open = $qual.index('{') // return False;
        my $close = $qual.rindex('}') // return False;
        my $prelude = $qual.substr(0, $open).trim;
        my $inner   = $qual.substr($open+1, $close - $open - 1).trim;
        my $pos = self!find-at-rule-block($out, $prelude);
        return False unless $pos.defined;
        my $block-end = matching-close($out, $pos);
        my $block-body = $out.substr($pos + 1, $block-end - $pos - 1);

        # Try exact match for the inner selector
        my $inner-head = $inner ~ '{';
        my $inner-pos = $block-body.index($inner-head);
        if $inner-pos.defined {
            return self!check-key-in-body($block-body, $inner-pos, $key);
        }
        # Fallback: inner selector may be part of a merged group
        $inner-pos = $block-body.index(',' ~ $inner)
                  // $block-body.index($inner ~ ',');
        if $inner-pos.defined {
            my $brace = $block-body.index('{', $inner-pos);
            return self!check-key-in-body($block-body, $brace, $key) if $brace.defined;
        }
        return False;
    }
    else {
        # Try exact match: $qual followed by {
        my $pos = $out.index($qual ~ '{');
        if $pos.defined {
            return self!check-key-in-body($out, $pos + ($qual ~ '{').chars - 1, $key);
        }
        # Fallback: $qual may be first in a merged group (e.g. "h1,h2{")
        # Note: substring-based matching, so first "{$pos, ...}" match wins.
        # If $qual is short (e.g. "a") the "a," hit could be in an unrelated
        # selector group. Worst case: a missed re-injection (content loss).
        $pos = $out.index($qual ~ ',');
        if $pos.defined {
            my $brace = $out.index('{', $pos);
            return self!check-key-in-body($out, $brace, $key) if $brace.defined;
        }
        # Fallback: $qual may be non-first in a merged group (e.g. "h2" in "h1,h2{")
        $pos = $out.index(',' ~ $qual);
        if $pos.defined {
            my $brace = $out.index('{', $pos);
            return self!check-key-in-body($out, $brace, $key) if $brace.defined;
        }
        return False;
    }
}

# Re-inject declarations that were dropped during minification.
# For each qualified selector, checks whether each property appears in the
# output (by name, scoped to the correct ruleset). Missing declarations
# are appended as a new ruleset.
# For at-rule qualified selectors (e.g. @media screen { h1 }), re-injects
# into the existing at-rule block, creating one if missing.
method !merge-decls(Str $out, %by-sel --> Str) {
    my $result = $out;
    for %by-sel.kv -> $qual, @decls {
        my @missing;
        for @decls -> (:$key, :$value) {
            @missing.push($key ~ ':' ~ $value)
                unless self!prop-exists($result, $qual, $key);
        }
        next unless @missing;
        my $joined = @missing.join(';');

        if $qual.starts-with('@') {
            self!merge-qualified($result, $qual, $joined);
        }
        else {
            $result ~= $qual ~ '{' ~ $joined ~ '}';
        }
    }
    $result;
}

method !merge-qualified(Str $result is rw, Str $qual, Str $decls) {
    my $open = $qual.index('{') // return;
    my $close = $qual.rindex('}') // return;
    my $prelude = $qual.substr(0, $open).trim;
    my $inner = $qual.substr($open+1, $close - $open - 1).trim;

    if my $pos = self!find-at-rule-block($result, $prelude) {
        $result.substr-rw(matching-close($result, $pos), 0) =
            $inner ~ '{' ~ $decls ~ '}';
    }
    else {
        $result ~= $prelude ~ '{' ~ $inner ~ '{' ~ $decls ~ '}' ~ '}';
    }
}

my constant @PLUGIN-DEFS = (
    { :level(1), :class(CSS::Minifier::Plugin::Values) },
    { :level(2), :class(CSS::Minifier::Plugin::Dedup) },
    { :level(2), :class(CSS::Minifier::Plugin::Merging) },
);

method !plugins-for($level) {
    $level ~~ 1..2 or die "Invalid level: $level. Use 1 or 2.";
    @PLUGIN-DEFS.grep({ .<level> <= $level }).map({ .<class>.new }).list;
}

=begin pod

=head1 NAME

CSS::Minifier - CSS Minifier

=head1 SYNOPSIS

=begin code :lang<raku>

use CSS::Minifier;
say CSS::Minifier.minify($css, :level(2));

=end code

=head1 DESCRIPTION

A CSS minifier that parses, optimizes, and re-serializes CSS stylesheets.
Intended as a class method (call C<CSS::Minifier.minify($css)>).

=head2 Options

=item level - optimization level (1 = safe, 2 = structural, default 1)
=item verbose - log plugin names to stderr during processing
=item preserve-licenses - keep /*! */ license comments (extracted from raw CSS before parse; prepended to output)
=item color-masks - shorten hex colors  (default True)
=item color-names - convert hex to named colors (default False)
=item preserve-unknown - re-inject declarations dropped by the pipeline (default True). This catches both unknown properties (C<text-decoration-line>) and CSS3-only values on known properties (C<display: flex>, C<position: sticky>). Set to C<False> to skip the post-minification merge pass. All properties inside at-rules that CSS::Stylesheet drops (e.g. C<@keyframes>, C<@supports>, C<@container>, C<@layer>) are also preserved regardless of whether they are known to CSS::Module::CSS3 — they come back without minification since they bypass the standard pipeline. Known properties inside C<@media>, C<@page>, and C<@font-face> are always handled by the pipeline.
=item sep - separator between rulesets (default '' for compact; use C<"\n"> for readable output)

Note: license comments are matched via C<m/'/*!' .*? '*/'>, a pattern
extracted from the raw CSS before the parser strips all comments. A known
limitation: the pattern may also match inside string values
(e.g. C<content: "...">). This is extremely rare in practice; some minifiers
share the same limitation.

=head1 PRESERVING UNKNOWN PROPERTIES

CSS::Properties recognizes standard CSS properties and drops those it
doesn't know (e.g. C<text-decoration-line>, C<outline-offset>),
as well as CSS3-only values on known properties (C<display: flex>,
C<position: sticky>). C<CSS::Minifier> works around this by
pre-scanning the raw CSS before parsing and re-injecting any
declarations that are missing from the minified output.

All declarations are pre-scanned from the raw CSS (not just unknown
ones). After the pipeline runs, any declaration missing from the
minified output is re-injected, which catches CSS3-only values
(C<display: flex>, C<position: sticky>, C<overflow: clip>, etc.)
that CSS::Module::CSS3's grammar drops.

Longhands that CSS::Properties consolidates into shorthands
(e.g. C<background-color> → C<background>) are detected by an
internal C<%SHORTHAND> map and are not re-injected, preserving the
optimizer's work.

Unknown properties inside at-rules (C<@media>, C<@supports>,
C<@container>, C<@layer>, etc.) are also preserved. The extraction
uses recursive brace-counting on the raw CSS, so any at-rule with a
C<{...}> body is handled.

Unsafe at-rules (C<@keyframes>, C<@supports>, C<@container>, C<@layer>,
C<@scope>, etc.) that CSS::Stylesheet has no grammar rule for are an
extreme case: the entire block body is extracted and re-injected verbatim,
bypassing the pipeline entirely. Known properties inside these blocks
are therefore not minified.

A known limitation: strings and comments containing C<{> or C<}> can
break brace-matching, though this is extremely rare in practice.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
