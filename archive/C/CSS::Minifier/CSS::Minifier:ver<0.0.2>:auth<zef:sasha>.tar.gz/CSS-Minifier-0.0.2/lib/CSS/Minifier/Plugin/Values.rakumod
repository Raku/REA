use CSS::Stylesheet;
use CSS::Minifier::Plugin;

class CSS::Minifier::Plugin::Values:ver<0.0.2>:auth<zef:sasha> does CSS::Minifier::Plugin {
    method name(--> Str) { 'values' }

    my constant $BOLD   = /:i ^ bold   $/;
    my constant $NORMAL = /:i ^ normal $/;

    # CSS::Properties handles 0px→0, opacity:1.0→1, border:none→"" etc at
    # parse time — no plugin action needed for them.
    method run(CSS::Stylesheet $stylesheet --> Nil) {
        for $stylesheet.rules -> $rule {
            next without $rule.properties;
            my $props = $rule.properties;
            for $props.properties -> $prop {
                given $prop {
                    when 'font-weight' {
                        my $val = $props.font-weight;
                        if    $val ~~ $BOLD   { $props.font-weight = 700 }
                        elsif $val ~~ $NORMAL { $props.font-weight = 400 }
                    }
                }
            }
        }
    }
}

=begin pod

=head1 NAME

CSS::Minifier::Plugin::Values - Value normalization plugin

=head1 DESCRIPTION

Normalises CSS property values to their shortest equivalent form:

=item C<font-weight: bold> → C<font-weight: 700>
=item C<font-weight: normal> → C<font-weight: 400>

Zero-value unit removal (C<0px>, C<0em>, C<0%> → C<0>) is handled at
parse time by L<CSS::Properties> and requires no plugin action.

Normalization only applies to regular rulesets, not to
C<@font-face> descriptors or at-rules.

Runs at level 1 (safe normalizations).

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
