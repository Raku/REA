use CSS::Stylesheet;
use CSS::Ruleset;

unit module CSS::Minifier::Util:ver<0.0.2>:auth<zef:sasha>;

# CSS::MediaQuery has no .Str() or .xpath(). .ast.raku is the only
# reliable serialization — identical queries produce identical AST output.
sub media-key(CSS::Stylesheet $ss, CSS::Ruleset $rule --> Str) is export {
    $ss.rule-media{$rule}.defined
        ?? $ss.rule-media{$rule}.ast.raku
        !! '';
}

sub same-media(CSS::Stylesheet $ss, CSS::Ruleset $a, CSS::Ruleset $b --> Bool) is export {
    media-key($ss, $a) eq media-key($ss, $b);
}

=begin pod

=head1 NAME

CSS::Minifier::Util - Shared utility functions for minification plugins

=head1 DESCRIPTION

Provides common helper routines used by multiple plugins to avoid code
duplication.

=head2 C<media-key($ss, $rule)>

Returns a string key representing the C<@media> context of a rule. Rules
outside any C<@media> block return an empty string. Used by the Dedup plugin
to prevent cross-media duplicates.

=head2 C<same-media($ss, $a, $b)>

Returns True if both rules share the same C<@media> context (or both are
unwrapped). Used by the Merging plugin to prevent cross-media merging.

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This library is free software; you can redistribute it and/or modify it under CC0.

=end pod
