# Cro [![Build Status](https://travis-ci.org/croservices/cro.svg?branch=master)](https://travis-ci.org/croservices/cro)

This is part of the Cro libraries for implementing services and distributed
systems in Raku. See the [Cro website](https://cro.services/) for further
information and documentation.
