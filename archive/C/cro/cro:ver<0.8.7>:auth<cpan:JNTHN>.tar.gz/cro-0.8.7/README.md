# Cro ![Build Status](https://github.com/croservices/cro/actions/workflows/ci.yml/badge.svg)

This is part of the Cro libraries for implementing services and distributed
systems in Raku. See the [Cro website](https://cro.services/) for further
information and documentation.
