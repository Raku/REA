# Cro::WebSocket::MessageParser

This class represents a parser for messages and is implemented as
`Cro::Transform` that consumes `Cro::WebSocket::Frame` and produces
`Cro::WebSocket::Message`.
