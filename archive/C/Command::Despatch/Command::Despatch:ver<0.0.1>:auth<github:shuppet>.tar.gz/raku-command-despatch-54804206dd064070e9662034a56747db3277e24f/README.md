![logo](https://user-images.githubusercontent.com/12242877/92306033-2db85c80-ef84-11ea-9b76-dc375d5b5bd7.png)

Perl 6 module for parsing generic commands and arguments from a hash table.
