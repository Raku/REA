-- sub base-query(--> TypeHere)
SELECT 1;