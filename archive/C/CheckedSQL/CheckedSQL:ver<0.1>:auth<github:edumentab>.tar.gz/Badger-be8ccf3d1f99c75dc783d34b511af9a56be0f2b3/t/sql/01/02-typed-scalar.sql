-- sub base-query(--> Result2 $)
SELECT 1 AS result;