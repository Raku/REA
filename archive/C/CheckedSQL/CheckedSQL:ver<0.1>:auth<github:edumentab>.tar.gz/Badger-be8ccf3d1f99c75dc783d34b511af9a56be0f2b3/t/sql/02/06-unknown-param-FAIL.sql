-- sub base-query(Int $a, Int $b)
SELECT $a + $b + $c;