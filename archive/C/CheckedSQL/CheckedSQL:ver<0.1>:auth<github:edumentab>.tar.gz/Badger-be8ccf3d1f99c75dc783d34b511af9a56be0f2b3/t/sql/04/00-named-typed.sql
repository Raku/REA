-- sub query-typed(Int :$a)
SELECT $a; 
