-- sub query($a, :$a)
SELECT 1;
