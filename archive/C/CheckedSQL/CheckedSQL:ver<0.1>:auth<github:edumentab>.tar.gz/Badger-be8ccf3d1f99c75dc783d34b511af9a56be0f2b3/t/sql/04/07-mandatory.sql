-- sub query(:$a!, :$b!)
SELECT $a + $b;
