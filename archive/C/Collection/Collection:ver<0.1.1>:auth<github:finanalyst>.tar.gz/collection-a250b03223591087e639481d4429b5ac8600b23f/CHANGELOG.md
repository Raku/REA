# Changlog

----
----
## Table of Contents
[2021-01-22 Collection spun out of Raku-Alt-Documentation](#2021-01-22-collection-spun-out-of-raku-alt-documentation)  
[2021-01-24 Adding tests](#2021-01-24-adding-tests)  
[2021-01-27 Redesign](#2021-01-27-redesign)  
[2021-01-31](#2021-01-31)  

----
# 2021-01-22 Collection spun out of Raku-Alt-Documentation
*  this had been planned.

*  tests are needed for Collection.pm6

# 2021-01-24 Adding tests
*  t/01-sanity only has use-ok

*  meta-ok in xt

*  other tests

# 2021-01-27 Redesign
*  plugin management made constistent

*  rewritten README to include new design

*  test written for process upto milestone pre-render, passing

*  Exceptions spun into separate file

# 2021-01-31


*  Compilation milestone adds plugins to convert collected data into compiled data.

*  All tests working

*  API mostly complete

*  TODO add a sorting key to config where the order of the files to be completed is important.





----
Rendered from CHANGELOG at 2021-01-31T14:24:19Z