[![Build Status](https://travis-ci.org/avuserow/p6-crypt-argon2.svg?branch=master)](https://travis-ci.org/avuserow/p6-crypt-argon2)



