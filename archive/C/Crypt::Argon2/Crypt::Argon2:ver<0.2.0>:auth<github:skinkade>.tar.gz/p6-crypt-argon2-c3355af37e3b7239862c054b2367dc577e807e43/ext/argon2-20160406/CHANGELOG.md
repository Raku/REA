# 20160406

* Version 1.3 of Argon2
* Version number in encoded hash
* Refactored low-level API
* Visibility control for library symbols
* Microsft Visual Studio solution
* New bindings
* Minor bug and warning fixes (no security issue)


# 20151206

* Python bindings
* Password read from stdin, instead of being an argument
* Compatibility FreeBSD, NetBSD, OpenBSD
* Constant-time verification
* Minor bug and warning fixes (no security issue)
