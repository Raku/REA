#!/usr/bin/env perl6

use Test;

use CSS::Grammar::Test;

use CSS::Specification;
use CSS::Specification::Extended;
use CSS::Specification::Actions;

for (
    'values' => {
        input => 'thin',
        ast => :keyw<thin>,
    },
    'values' => {
        input => 'thin?',
        ast => :occurs['?', :keyw<thin>],
    },
    'values' => {
        input => 'thick | thin',
        ast => :keywords<thick thin>,
    },
    'values' => {
        input => '35 | 7',
        ast =>  :numbers[35, 7],
    },
    'values' => {
        input => '35 | 7 | 42?',
        ast => :alt[ :numbers[35, 7], :occurs['?', :num(42)] ]
    },
    'values' => {
        :extended, # forced precedence
        input => '<a> | ! <b> |!! <c> |!<d> |<e>',
        ast => :alt[ :rule<c>, :rule<b>, :rule<d>, :rule<a>, :rule<e>, ],
    },
    'values' => {
        # <ident> is mapped to the CSS::Grammar <Ident> rule, to
        # bypass Raku built-in <ident> rule.
        input => "<rule-ref> <ident>",
        ast => :seq(:rule<rule-ref>, :rule<Ident>),
    },
    'values' => {
        input => "<rule-ref> [ 'css21-prop' <'css3-prop'> ]?",
        ast => :seq[ :rule<rule-ref>,
                     :occurs['?', :group(:seq[:rule<prop-val-css21-prop>, :rule<prop-val-css3-prop>]) ]
                   ],
    },
    'values' => {
        input => "<rule-ref> [, [ 'css21-prop' | <'css3-prop'> ] ]*",
        ast => :seq[ :rule<rule-ref>,
                     :occurs['*',
                             :group(:seq[:op<,>, :group(:alt[:rule<prop-val-css21-prop>, :rule<prop-val-css3-prop>]) ])
                            ],
                   ]
    },
    'values' => {
        :extended, # property alias
        input => q{<'font-variant'=.font-variant-css2>},
        ast => :alias{ :ref<prop-val-font-variant>, :rule<font-variant-css2> },
        rule-refs => ["font-variant-css2"],
    },
    'values' => {
        input => '<length>{4}',
        ast => :occurs[ [4,4], :rule<length> ],
    },
    'values' => {
        input => '<length>#',
        ast => :occurs[ ',', :rule<length> ],
    },
    'values' => {
        input => '<length>#{1,4}',
        ast => :occurs[ [1,4,','], :rule<length> ],
    },
    # precedence tests taken from: https://developer.mozilla.org/en-US/docs/CSS/Value_definition_syntax
    'values' => {
        input => 'bold thin && <length>',
        ast => :required[
                        :seq[ :keyw<bold>, :keyw<thin> ]
                        :rule<length>,
                    ]
    },
    'values' => {
        input => 'bold || thin && <length>',
        ast => :combo[ :keyw<bold>,
                       :required[ :keyw<thin>, :rule<length>],
                     ]
    },
    'values' => {
        input => 'example( first? , second? , third? )',
        ast => :func<example>,
    },
    'values' => {
        input => '<@annotation>',
        ast => :at-rule<annotation>,
    },
    term => {
        input => '[<length> | auto]#{4,4}',
        ast => :occurs[[4,4, ','], :group{ :alt[ :rule<length>, :keyw<auto> ] } ],
    },
    'func-proto' => {
        input => 'attr(<identifier>)',
        ast => :proto{:func<attr>, :signature{ :args[:rule<identifier>] }, :synopsis('attr(<identifier>)')},
    },
    'func-proto' => {
        input => 'linear-gradient( [ <linear-gradient-syntax> ] )',
        ast => :proto{:func<linear-gradient>, :signature{ :args[:group(:rule<linear-gradient-syntax>)] }, :synopsis('linear-gradient( [ <linear-gradient-syntax> ] )'), },
        
    },
    'func-spec' => {
        input => '<linear-gradient()> = linear-gradient( [ <linear-gradient-syntax> ] )',
        ast => :func-spec{:func<linear-gradient>, :signature{ :args[:group(:rule<linear-gradient-syntax>)] }, :synopsis("linear-gradient( [ <linear-gradient-syntax> ] )")},
        child-rules => %( :linear-gradient["linear-gradient-syntax"] );
    },
   'values' => {
        input => '[ <length-percentage [0,∞]> | auto ]{1,2} | cover | contain',
        ast => :alt[:occurs[[1, 2], :group(:alt[:rule<length-percentage>, :keyw<auto>])], :keywords["cover", "contain"]],
    },
    'values' => {
        input => '<bg-layer>#? <final-bg-layer>',
        ast => :seq[:occurs["?", :occurs[",", :rule<bg-layer>]], :rule<final-bg-layer>],

    },
    'rule-spec' => {
         input => '<color-stop-list> = <linear-color-stop> , [ <linear-color-hint>? , <linear-color-stop> ]#?',
         ast => :rule-spec{
             :rule<color-stop-list>,
             :spec(:seq[:rule<linear-color-stop>, :op<,>, :occurs["?", :occurs[",", :group(:seq[:occurs["?", :rule<linear-color-hint>, :trailing<,>], :rule<linear-color-stop>])]]]),
             :synopsis("<linear-color-stop> , [ <linear-color-hint>? , <linear-color-stop> ]#?")},
    },
    'rule-spec' => {
        input => '<reversed-counter-name> = reversed( <counter-name> )',
        ast => :func-spec{:func<reversed>, :rule<reversed-counter-name>, :signature{:args[:rule<counter-name>]}, :synopsis("reversed( <counter-name> )")},
    },
    'rule-spec' => {
        input => '<shape> = <rect()>',
        ast => :rule-spec{
            :rule<shape>
            :spec(:func<rect>),
            :synopsis("<rect()>")
        },
    },
    'values' => {
        input => '<bg-layer>#? , <final-bg-layer>',
        ast =>
        :seq[:occurs["?", :occurs[",", :rule<bg-layer>], :trailing<,>], :rule<final-bg-layer>],

    },
    'at-rule-spec' => {
        input => '@font-feature-values = @font-feature-values <font-family-name># { <declaration-rule-list> }',
        ast => :at-rule-spec{
            :at-rule<font-feature-values>,
            :synopsis('<font-family-name># { <declaration-rule-list> }'),
            :spec(
                :seq[ { :occurs[",", { :rule<font-family-name>, } ] },
                      :lit<{>, :rule<declaration-rule-list>, :lit<}>,
                    ]
            ),
        }
    },
    'prop-spec' => {
        input => "'direction'	ltr | rtl | inherit	ltr	all elements, but see prose	yes",
        ast => :prop-spec{
            :props['direction'],
            :default<ltr>,
            :synopsis('ltr | rtl | inherit'),
            :spec(:keywords['ltr', 'rtl', 'inherit']),
            :inherit
        },
    },
    'prop-spec' => {
        input => "soft-test\t<rule-ref> [ <'css3-prop'> | <.'css3-soft-prop'> ]?\txxx",
        :extended,
        ast => :prop-spec{
            :props['soft-test'],
            :default<xxx>,
            :synopsis(q{<rule-ref> [ <'css3-prop'> | <.'css3-soft-prop'> ]?}),
            :spec(:seq[ :rule<rule-ref>,
                     :occurs['?', :group(:alt[:rule<prop-val-css3-prop>, :rule<prop-val-css3-soft-prop>]) ]
                      ]),
        },
        child-rules => %(
            :prop-val-soft-test["rule-ref", "prop-val-css3-prop", "prop-val-css3-soft-prop"],
        ),
 
        child-props => %(
            :prop-val-soft-test["css3-prop"],
        ),
 
    },
    'prop-spec' => {
        input => "'content'\tnormal | none | [ <string> | <uri> | <counter> | attr(<identifier>) | open-quote | close-quote | no-open-quote | no-close-quote ]+ | inherit	normal	:before and :after pseudo-elements	no",
        ast => :prop-spec{:props['content'],
                :default<normal>,
                :synopsis('normal | none | [ <string> | <uri> | <counter> | attr(<identifier>) | open-quote | close-quote | no-open-quote | no-close-quote ]+ | inherit'),
                :spec(:alt[:keywords["normal", "none"], :occurs['+', :group(:alt[:rule("string"), :rule("uri"), :rule("counter"), :func("attr"), :keywords["open-quote", "close-quote", "no-open-quote", "no-close-quote"]])], :keyw<inherit>]),
                :!inherit,
               },
        child-rules => %(:prop-val-content["string", "uri", "counter", "identifier"]),
    },
    func-spec => {
        input => q{<calc()> = calc( <calc-sum> )},
        ast => :func-spec{:func<calc>, :signature{:args[:rule("calc-sum")]}, :synopsis("calc( <calc-sum> )")},
    },
    func-spec => {
        input => '<example()> = example( first , second? , third? )',
        ast => :func-spec{
            :func<example>,
            :signature{:args[:keyw<first>, :optional[ :keyw<second>, :keyw<third>]]},
            :synopsis("example( first , second? , third? )"),
        }
    },
    func-spec => {
        input => '<icc-color()> = icc-color(<name> [,<number>]{2}?)',
        ast => :func-spec{
            :func<icc-color>,
            :signature{:seq[:rule<name>, :occurs['?', :occurs[[2,2], :group(:seq[:op<,>, :rule<number>])]]]},
            :synopsis('icc-color(<name> [,<number>]{2}?)'),
        },
        child-rules => %(:icc-color["name", "name", "number"]),
    },

    rule-spec => {
        input => q{<calc-sum> = <calc-product> [ [ '+' | '-' ] <calc-product> ]*},
        ast => :rule-spec{
            :rule<calc-sum>,
            :spec(:seq[:rule<calc-product>, :occurs["*", :group(:seq[:group(:alt[:op("+"), :op("-")]), :rule<calc-product>])]]),
            :synopsis("<calc-product> [ [ '+' | '-' ] <calc-product> ]*")
        },
        child-rules => %(:calc-sum["calc-product", "calc-product"]),
    },
    # css1 spec with property name and '*' junk
    prop-spec => {
        input => "'width' *\t<length> | <percentage> | auto	auto	all elements but non-replaced inline elements, table rows, and row groups	no",
        ast => Mu,
    },
    prop-spec => {
        input => q{'border'	[ 'border-width' || 'border-style' || 'border-color' ] | inherit	see individual properties	 	no	 	visual},
        ast => Mu,
        child-rules => %(:prop-val-border["prop-val-border-width", "prop-val-border-style", "prop-val-border-color"]),
    },
    ) {

    my $rule     := .key;
    my $expected := .value;
    my $input    := $expected<input>;
    my $extended := $expected<extended>;
    subtest "$rule: $input", {

        my CSS::Specification::Actions $actions .= new;
        my $grammar := $extended
                        ?? CSS::Specification::Extended
                        !! CSS::Specification;

        my @*DECL-NAMES = [];

        CSS::Grammar::Test::parse-tests(
            $grammar, $input,
            :$rule,
            :$actions,
            :suite<spec>,
            :$expected
        );

        if $expected<child-rules> -> $child-rules {
            is-deeply $actions.child-rules, $child-rules, 'child-rules';
        }
        if $expected<child-props> -> $child-props {
            is-deeply $actions.child-props, $child-props, 'child-props';
        }
    }
}

done-testing;
