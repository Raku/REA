unit class CSS::Specification::Actions;

use Method::Also;

# these actions translate a CSS property specification to an
# intermediate AST
has %.rules is rw;
has %.at-rules is rw;
has %.at-rule-refs is rw;
has %.rule-refs is rw;
has %.funcs is rw;
has %.protos is rw;
has %.func-refs is rw;
has %.props is rw;
has %.child-rules is rw;
has %.child-props is rw;

method !check-symbols {
    my %ruleish = %!rules, %!rule-refs;
    for %ruleish.keys.sort {
        warn "$_ used as both a rule and a function"
            if %!funcs{$_} || %!func-refs{$_};
    }
}

method TOP($/) {
    self!check-symbols;
    make @<def>>>.ast;
};

method prop-spec($/) {
    my @props = @($<prop-names>.ast);
    %.props{$_}++ for @props;

    my $spec = $<values>.ast;
    my $synopsis = ~$<values>;

    my %prop-spec = :@props, :$spec, :$synopsis;

    %prop-spec<inherit> = .ast with $<inherit>;

    %prop-spec<default> = ~$_
        with $<default>;

    make (:%prop-spec);
}

multi method rule-spec($/ where $<func-proto>) {
    my $rule = $<rule-ref>.ast;
    my $proto = $<func-proto>.ast<proto>;
    my $func = $proto<func>;
    my $synopsis = ~$<func-proto>;
    my $signature = $proto<signature>;

    my %func-spec = (
        :$func, :$rule, :$signature, :$synopsis,
        );

    %!rules{$rule}++;
    make (:%func-spec);
}

multi method rule-spec($/ where $<values>) {
    my $rule = $<rule-ref>.ast,
    my $spec = $<values>.ast;
    my $synopsis = ~$<values>;

    my %rule-spec = (
        :$rule, :$synopsis, :$spec
        );

    %!rules{$rule}++;
    make (:%rule-spec);
}

method func-spec($/) {
    my $func = $<func-ref>.ast;
    my $proto = $<func-decl>.ast<proto>;
    my $synopsis = ~$<func-decl>;
    my $signature = $proto<signature>;
    given $proto<func> {
        warn "prototype mismatch $func vs $_" unless $func eq $_;
    }

    my %func-spec = (
        :$func, :$signature, :$synopsis,
        );

    %!funcs{$func}++;
    make (:%func-spec);
}

method at-rule-spec($/) {
    my $at-rule = $<def>.ast;
    my $spec = $<values>.ast;
    my $synopsis = ~$<values>;

    given $<ref>.ast {
        warn '@rule mismatch @%s vs @%s'.sprintf($at-rule, $_)
            unless $at-rule eq $_;
    }

    %!at-rules{$at-rule}++;
    my %at-rule-spec = (
        :$at-rule, :$synopsis, :$spec
    );
    make (:%at-rule-spec);
}

method at-rule-ref($/) {
    %!at-rule-refs{$<id>.ast}++;
    make $<id>.ast
}

method arg($/) {
    make $<value>.ast;
}

method optional-arg($/) {
    make $<value>.ast;
}

method structured-args($/) {
    my %spec;
    my @args = @<arg>>>.ast;
    my @optional = @<optional-arg>>>.ast;
    @args.push: (:@optional)
        if @optional;
    make (:@args);
}

method signature($/) {
    my %signature = $<args>.ast;
    make (:%signature);
}

method func-proto($/) {
    my $synopsis = $/.trim;
    my $func = $<id>.ast;
    my %proto = :$func, :$synopsis;
    %proto ,= .ast with $<signature>;

    make (:%proto);
}

method func-decl($/) {
    my %proto = $<func-proto>.ast<proto>;
    with %!protos{ %proto<func> } {
       my $synopsis = %proto<synopsis>;
       warn "inconsistant function declaration: {$synopsis.raku} vs {.<synopsis>.raku}"
           unless .<signature> eqv %proto<signature>;
    }
    else {
        $_ = %proto;
    }
    make (:%proto);
}

method yes($/) { make True }
method no($/)  { make False }

method values($/) {
    make $<seq>.ast;
}

method prop-names($/) {
    my @prop-names = $<id>>>.ast;
    make @prop-names;
}

method unexpected($/) is hidden-from-backtrace {
    die "Unexpected input: " ~$/;
}

method id($/)        { make ~$/ }
method prop-ref($/)  { make $<id>.ast }
method prop-val($/)  { make 'prop-val-' ~ $<ref>.ast }
method keyw($/)      { make 'keyw' => ~$<id> }
method digits($/)    { make 'num' => $/.Int }
method rule-ref($/)  {
    my $id = $<id>.ast;
    # avoid Raku built-in <ident> in favor of CSS-specifc <Ident>
    $id = 'Ident' if $id eq 'ident';
    make $id;
}
method func-ref($/)  { make $<id>.ast }

method !make-term($/, $name) {
    my @term =  @<term>>>.ast;
    make @term == 1 ?? @term[0] !! ($name => @term);
}

method seq($/) is also<term-seq> {
    self!make-term: $/, 'seq';
}

method term-options($/) {
    my @terms =  @<term>>>.ast;
    if @terms == 1 {
        make @terms[0];
    }
    else {
        my @precedence = .map({.chars * -10000}) with $<precedence>;
        @terms = @terms.pairs.sort({.key + @precedence[.key]}).map(*.value)
            if @precedence.first(*.so);
        make 'alt' => @terms;
    }
}

method term-combo($/) {
    self!make-term: $/, 'combo';
}

method term-required($/) {
    self!make-term: $/, 'required';
}

method term($/) {
    my $value = $<value>.ast;

    for @<occurs> -> $/ {
        my @occurs = [$/.ast, $value];
        @occurs.push: (:trailing<,>) if $<trailing-comma>;
        $value = :@occurs;
    }

    make $value;
}

method occurs:sym<maybe>($/)     { make '?' }
method occurs:sym<once-plus>($/) { make '+' }
method occurs:sym<zero-plus>($/) { make '*' }
method occurs:sym<must>($/)      { make '!' }
multi method occurs:sym<list>($/ where $<range>) {
    make [$<range>.ast.Slip, ','];
}
multi method occurs:sym<list>($/) {
    make ','
}
method occurs:sym<range>($/)     { make $<range>.ast }
method range($/) {
    my $min = $<min>.ast.value;
    my $max = ($<max> // $<min>).ast.value;
    warn "$min > $max" if $min > $max;
    make [$min, $max];
}

method stringchar:sym<escape>($/)   { make $<escape>.ast }
method stringchar:sym<nonascii>($/) { make $<nonascii>.ast }
method stringchar:sym<ascii>($/)    { make ~$/ }
method !to-unicode($hex-str --> Str) {
    my $char  = chr( :16($hex-str) );
    CATCH {
        default {
            $.warning('invalid unicode code-point', 'U+' ~ $hex-str.uc );
            $char = chr(0xFFFD); # �
        }
    }
    $char;
}

method unicode($/)  { make self!to-unicode(~$0) }

method regascii($/) { make ~$/ }
method nonascii($/) { make ~$/ }

method escape($/)   { make do with $<char> { .ast } else { '' } }

method single-quote($/) { make "'" }
method double-quote($/) { make '"' }

method !string-token($/) {
    make [~] $<stringchar>>>.ast;
}

proto method string {*}
method string:sym<single-q>($/) { self!string-token($/) }

method string:sym<double-q>($/) { self!string-token($/) }

multi method value:sym<keywords>($/ where @<keyw> == 1) {
    make @<keyw>.head.ast;
}
multi method value:sym<keywords>($/) {
    my @keywords = @<keyw>.map: {.ast.value};
    make (:@keywords);
}

multi method value:sym<numbers>($/ where @<digits> == 1) {
    make @<digits>.head.ast;
}
multi method value:sym<numbers>($/) {
    my @numbers = @<digits>.map: {.ast.value };
    make (:@numbers);
}

method value:sym<keyw>($/) {
    make $<keyw>.ast;
}

method value:sym<num>($/) {
    make $<digits>.ast;
}

method value:sym<group>($/) {
    my $group = $<seq>.ast;
    make (:$group);
}

method value:sym<rule-ref>($/) {
    my $rule = ~$<rule-ref>.ast;
    %!rule-refs{ $rule }++;
    %!child-rules{$_}.push: $rule for @*DECL-NAMES;
    make (:$rule);
}

method value:sym<at-rule-ref>($/) {
    my $at-rule = ~$<at-rule-ref>.ast;
    %!at-rule-refs{ $at-rule }++;
    make (:$at-rule);
}

method value:sym<func-ref>($/) {
    my $func = ~$<func-ref>.ast;
    %!func-refs{ $func }++;
    make (:$func);
}

method value:sym<func-decl>($/) {
    my $func = ~$<func-decl>.ast<proto><func>;
    # todo process prototypes
    %!func-refs{ $func }++;
    make (:$func);
}

method value:sym<delim>($/) { my $op = $/.trim; make (:$op); }
method value:sym<punc>($/)  { my $lit = $/.trim; make (:$lit); }

method property-val:sym<css21>($/) { make $<val>.ast }
method property-ref:sym<css3>($/)  { make $<val>.ast }
method value:sym<prop-val>($/)        {
    my Str:D $rule = $<property-val><val>.ast;
    my Str:D $prop =  $<property-val><val><ref>.ast;
    %!rule-refs{ $rule }++;

    for @*DECL-NAMES {
        %!child-rules{$_}.push: $rule;
        %!child-props{$_}.push: $prop
            unless $<property-val><inline>;
    }

    make (:$rule);
}
method value:sym<prop-alias>($/) {
    my Str:D $ref  = $<val>.ast;
    my Str:D $rule = $<rule>.ast;
    %!rule-refs{ $rule }++;
    my %alias = :$ref, :$rule;
    make (:%alias);
}

method value:sym<string>($/)  { make 'op' => $<string>.ast }
method value:sym<parenthesized>($/)  {
    my %paren = $<signature>.ast;
    make (:%paren);
}

method value:sym<inf>($/) {
    make 'num' => ($<sign> ~~ '-' ?? -Inf !! Inf);
}
