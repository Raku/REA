#| property calculator and measurement tool.
unit class CSS::Properties::Calculator;

use CSS::Units :Lengths, :&dimension, :pt, :px;
use CSS::Properties::Util :&from-ast;

=begin pod
=head2 Synopsis
=begin code :lang<raku>
use CSS::Properties;
use CSS::Properties::Calculator;
my CSS::Properties $css .= new: :style("font:12pt Helvetica;");
my CSS::Properties::Calculator $calc .= new: :$css, :units<mm>, :veiwport-width<250>;
# Converts a value to a numeric quantity;
my Numeric $font-size = $css.measure: :font-size; # get current font size (mm)
$font-size = $css.measure: :font-size<smaller>;   # compute a smaller font-size
$font-size = $css.measure: :font-size(120%);      # compute a larger font-size
$font-size = "calc(1.5rem + 3vw)";                # compute a calculated font-size
$font-size = $css.measure: :font-size;
my $weight = $css.measure: :font-weight;          # get current font weight 100..900
$weight = $css.measure: :font-weight<bold>;       # compute bold font weight
=end code

=head2 Description

This module supports conversion or evaluation of quantities to numerical values.
=item CSS length quantities may rely on context. For example `ex` depends on the current font and font-size
=item Furthermore the `measure` method converts lengths to preferred units (by default `pt`).
=item `font-weight` is converted to a numerical value in the range 100 .. 900
=item Basic evaluation of L<calc()|https://www.w3.org/TR/css-values-3/#calc-notation> arithmetic expressions in
      property values is supported for CSS3 and SVG.

Note: L<CSS::Properties>, L<CSS::Box> and L<CSS::Font> objects all encapsulate a calculator object which handles `measure` and `calculate` methods.
=begin code
my CSS::Properties $css .= new: :style("font:12pt Helvetica;"), :units<mm>, :veiwport-width<250>;
my Numeric $font-size = $css.measure: :font-size;
=end code
=end pod

has $.css is required;
has Str $.units = 'pt';
has Numeric $!scale = Lengths.enums{$!units};
has Numeric $.em is rw = 12pt.scale($!units);
has Numeric $.font-weight is rw = 400;
has Numeric $!rem = $!em; # original $!em
method ex { $!em * 3/4 }
has Numeric $.viewport-width = 1024px.scale($!units);
has Numeric $.viewport-height = 768px.scale($!units);
has Numeric $.reference-width = $!viewport-width;
has Numeric $.user-width = 1.0;
method reference-width is rw {
    sub FETCH($) { $!reference-width // 0 }
    sub STORE($, Numeric:D() $v) {
            my $units = $v.?units // $!units;
            $!reference-width = CSS::Units.value($v, $units).scale: $!units;
    }
    Proxy.new: :&FETCH, :&STORE
}

subset FontWeight is export(:FontWeight) of Numeric where { 100 <= $_ <= 900 && $_ %% 100 }

my constant %FontSizes = %(
    :xx-small(6pt), :x-small(7.5pt), :small(10pt), :medium(12pt),
    :large(13.5pt), :x-large(18pt), :xx-large(24pt)
);

method !em($v = $!em) { CSS::Units.value: $v, $!units }

subset XKeyw of Str:D where 'left'|'center'|'right';
subset YKeyw of Str:D where 'top'|'center'|'bottom';

# e.g. '20%', '20% top'
multi sub bg-pos(Numeric:D $x, YKeyw $yk = 'center') {
    ('left', $x), ($yk,)
}
# e.g. '10px 20%'
multi sub bg-pos(Numeric:D $x, Numeric:D $y) {
    ('left', $x), ('top', $y)
}
# e.g. 'center 20%'
multi sub bg-pos(XKeyw $xk, Numeric:D $y) {
    ($xk,), ('top',$y);
}
# e.g. 'top 10px'
multi sub bg-pos(YKeyw $yk, Numeric:D $x) {
    ('left', $x,), ($yk,);
}
# e.g. 'center', 'center top'
multi sub bg-pos(XKeyw $xk, YKeyw $yk = 'center') {
    ($xk,), ($yk,);
}
# e.g 'top', 'top left'
multi sub bg-pos(YKeyw $yk, XKeyw $xk = 'center') {
    ($xk,), ($yk,);
}
# e.g. 'center top 10px'
multi sub bg-pos(XKeyw $xk, YKeyw $yk, Numeric:D $y) {
    ($xk,), ($yk,$y);
}
# e.g. 'top center 10px'
multi sub bg-pos(YKeyw $yk, XKeyw $xk, Numeric:D $x) {
    ($xk,$x), ($yk,);
}
# e.g. 'left 1px center', 'left 1px center 2px'
multi sub bg-pos(XKeyw $xk, Numeric $x, YKeyw $yk, Numeric $y?) {
    ($xk,$x), ($yk,$y);
}
# e.g. 'top 1px center', 'top 1px center 2px'
multi sub bg-pos(YKeyw $yk, Numeric $y, XKeyw $xk, Numeric $x?) {
    ($xk,$x), ($yk,$y);
}

my Method %Compute;
BEGIN %Compute = (
    font-size => method ($_) {
        when %FontSizes{$_}:exists { %FontSizes{$_}.scale: $!units }
        when 'larger'   { self!em: ($!em * 1.2).round: 0.5 }
        when 'smaller'  { self!em: ($!em / 1.2).round: 0.5 }
        default { $.measure($_, :ref($!em)) }
    },
    font-weight => method ($_) {
        self!weigh($_);
    },
    letter-spacing => method ($_) {
        when .?type ~~ 'num'|Any:U  { self!em: $_ * $!em; }
        when 'normal' { self!em: 0.0 }
        default { %Compute<font-size>(self, $_) }
    },
    line-height => method ($_) {
        when 'normal'        { self!em: $!em * 1.2 }
        when .?type ~~ 'num'|Any:U {self!em: $!em * $_  }
        default { %Compute<font-size>(self, $_) }
    },
    word-spacing => method ($_) {
        when 'normal' { self!em }
        default { self.measure: $_, :ref($!em) }
    },
    'border-top-width'|'border-right-width'|'border-bottom-width'|'border-left-width' => method ($_, :$ref = $!reference-width) {
        self.measure($_, :$ref); # percentage needs to be supplied
    },
    'width'|'height'|'min-width'|'max-width'|'min-height'|'max-height'|'padding-top'|'padding-right'|'padding-bottom'|'padding-left'|'margin-top'|'margin-right'|'margin-bottom'|'margin-left' => method ($_) {
        self.measure($_, :ref($!reference-width));
    },
    # SVG
    'stroke-width'|'stroke-dasharray' =>  method ($_) {
        when .?type ~~ 'num'|Any:U  { self!em($_ * $!user-width); }
        default { self.measure($_, :ref($!viewport-width)); }
    },
    'fill-opacity'|'opacity'|'stop-opacity'|'stroke-opacity' => method (Numeric:D $v is copy) {
        $v /= 100 if $v.?type ~~ 'percent';
        max(0.0, min($v, 1.0));
    },
    'background-position' => method (@layers, :@ref!) {
        @layers.grep(* !~~ ',').map({
            my :(@x, @y) := bg-pos(|$_);
            my $x = self.measure(@x[0], :ref(@ref[0]));
            $x += self.measure($_, :ref(@ref[0])) with @x[1];

            my $y = self.measure(@y[0], :ref(@ref[1]));
            $y += self.measure($_, :ref(@ref[1])) with @y[1];

            ($x, $y)
        }).List;
    }
);

#| converts a weight name to a three digit number:
#| 100 lightest ... 900 heaviest
method !weigh($_, Int $delta = 0) returns FontWeight {
    my $v = do given .lc {
        when FontWeight       { .Int }
        when 'normal'         { 400 }
        when 'bold'           { 700 }
        when 'lighter'        { $!font-weight - 300 }
        when 'bolder'         { $!font-weight + 300 }
        default {
            if /^ <[1..9]>00 $/ {
                .Int
            }
            else {
                warn "unhandled font-weight: $_";
                400;
            }
        }
    };
    $v = ($v + $delta).&max(100).&min(900);
    CSS::Units.value($v, 'int');
}

proto method measure(|c) {*}

multi method measure(:font-size($_)!) {
    when Bool { CSS::Units.value($!em, $!units) }
    default   { %Compute<font-size>(self, $_) }
}

multi method measure(:font-weight($_)!) {
    when Bool { CSS::Units.value($!font-weight, 'int') }
    default   { %Compute<font-weight>(self, $_) }
}

multi method measure(:background-position($_)! where $!css.module.name.starts-with('Snapshot'), :@ref = ($!viewport-width, $!viewport-height) ) {
    # Snapshot 2026 onwards has multipler layers
    my @layers = .isa(Bool) ?? $!css.background-position.List !! .List;
    %Compute<background-position>(self, @layers, :@ref)
}

multi method measure(:background-position($_)!, :@ref = ($!viewport-width, $!viewport-height)) {
    # css1, css21, css3 only have a single layer
    my @layer = .isa(Bool) ?? $!css.background-position !! $_;
    %Compute<background-position>(self, @layer, :@ref)
}

multi method measure(:$ref = $!em, *%misc where .elems == 1) {
    my :($prop, $value) := %misc.kv;
    given $value {
        my $v = .isa(Bool) ?? $!css."$prop"() !! $_;
        with %Compute{$prop} {
            .(self, $v, :$ref);
        }
        else {
            $.measure($v, :$ref);
        }
    }
}

# unary expression
multi sub calc( % ( :@expr! ) ) {
    calc |@expr;
}

# parenthesized sub-expression
my constant OpenParen  = %( :op<(> );
my constant CloseParen = %( :op<)> );
multi sub calc(OpenParen, %expr, CloseParen ) {
    calc %expr;
}

# binary left associative arithmetic operation
multi sub calc( %lhs, % ( :$op! ),  *@rhs (%, *@) ) {
    use CSS::Units :ops; # Use arithmetic operator overloading
    my $v1 := calc(%lhs);
    my $v2 := calc(|@rhs);
    given $op {
        when '+' { $v1 + $v2 }
        when '-' { $v1 - $v2 }
        when '*' { $v1 * $v2 }
        when '/' { $v1 / $v2 }
    }
}

# numeric constant
multi sub calc( % ( Numeric:D :$num! ) ) {
    $num;
}

# named constant
multi sub calc( % ( Str:D :$keyw! ) ) {
    given $keyw {
        when 'e'         { e }
        when 'pi'        { pi }
        when 'infinity'  { Inf }
        when '-infinity' { -Inf }
        when 'Nan'       { Mu }
        default {
            warn "Unhandled calc keyword {.raku}";
            Any
        }
    }
}

# css quantity
multi sub calc( %ast ) {
    $*calc.measure: from-ast(%ast), :$*ref;
}

multi sub calc( *@expr ) {
    warn "Unhandled expression: {@expr.map(*.raku).join: "|"}";
}

multi sub func('calc', @expr) {
    calc |@expr;
}

multi sub func($ident, |) {
    warn "Unrecognised function: " ~ $ident;
}

sub evaluate(:%func! ( :$ident!, :@expr! )) {
    func $ident, @expr;
}
multi method measure($*calc: Pair $expr, Numeric :$*ref = $!em) {
    evaluate |$expr;
}
multi method measure(@v, :$ref = $!em) {
    @v.grep(* !~~ ',').map({$.measure($_, :$ref)}).List;
}
multi method measure(Numeric $v is copy,
                     Numeric :$ref = $!em,
              ) {
    my Str $units = $v.?type // $!units;

    my Numeric $scale = do given $units {
        when 'none' { $v = Nil }
        when 'em'   { $!em }
        when 'ch'   { $!em * .8 } # todo: should be advance width of '0'
        when 'rem'  { $!rem }
        when 'ex'   { $.ex }
        when 'vw'   { $!viewport-width }
        when 'vh'   { $!viewport-height }
        when 'vmin' { min($!viewport-width, $!viewport-height) }
        when 'vmax' { max($!viewport-width, $!viewport-height) }
        when 'percent' { $ref * $!scale / 100; }
        default     {
            given .&dimension {
                when Enumeration { .enums{$units} }
                default {
                    warn "Unknown units: $units";
                    1;
                }
            }
        }
    };
    with $scale {
        CSS::Units.value($v * $_ / $!scale, $!units);
    }
    else {
        $v;
    }
}

multi method measure('none', |) {
    Mu;
}
multi method measure(Str $v, :$ref = $!em) {
    my Numeric $n;
    with $v {
        when 'thin'   { $n := 1pt.scale: $!units }
        when 'medium' { $n := 2pt.scale: $!units }
        when 'thick'  { $n := 3pt.scale: $!units }
        when 'top'|'left' { $n := 0 }
        when 'center' { $n := $ref / 2 }
        when 'bottom'|'right' { $n := $ref }
    }

    with $n {
        CSS::Units.value($_, $!units);
    }
    else {
        $v;
    }
}
multi method measure($_) { $_ }

method computed(Str $prop) {
    self.measure: |($prop => True);
}
