# A list of Plugins to be implemented, or change in templates
>


*  finish Test::CollectionPlugins

	*  check to see if callables match signatures

*  alter Collection Readme to distinguish between callables at milestones, and plugins

*  create plugin management CLI

*  Implement numbered lists for items.

*  **UI rakudoc** This is needed to create page templates, so that titles, footnotes, tabs in the header can be defined as Rakudoc files, and hence have in different languages.





----
Rendered from TODO at 2022-08-30T22:24:41Z