# Change log for the Collection-Plugins module
>
## Table of Contents
[2022-08-09 v0.0.2](#2022-08-09-v002)  

----
# 2022-08-09 v0.0.2


*  First structural draft.

*  got `LeafletMap` to work

*  added ordering logic to `gather-js`





----
Rendered from CHANGELOG at 2022-08-09T20:53:44Z