use nqp;
use experimental :rakuast;

# I would like to have .wrap to do this automaticaly but you
# can't call .wrap stuff at compile time apparently.
# also coercion would be nice but that doesn't seem possible.
sub handle($_) {
    when CompUnit::Handle:D { $_ }
    when CompUnit:D { .handle }
    default { find-loaded($_).handle }
}

# The legacy frontend exposes its World as $*W at BEGIN time; the RakuAST
# frontend exposes a RakuAST::Resolver::Compile as $*R instead. The scope-*
# subs below abstract over the two so everything else can stay frontend
# agnostic. A "scope" is a QAST::Block ($*UNIT / $*W.cur_lexpad) on legacy
# and a RakuAST::LexicalScope ($*CU / $*R.current-scope) on RakuAST.
my class NO-SYMBOL {}

# Values this module has installed, keyed by scope identity and name. Loading
# a module imports its GLOBALish symbols as generated declarations on the
# unit scope, which can alias setting-owned packages (EXPORTHOW in
# particular), so a bare generated-declaration lookup cannot distinguish our
# installs from those.
my %installed;

my sub unit-scope is raw { $*W ?? $*UNIT !! $*CU }

my sub pad-scope is raw { $*W ?? $*W.cur_lexpad !! $*R.current-scope }

my sub scope-install(Mu \scope, $name, Mu $value --> Nil) {
    if $*W {
        $*W.install_lexical_symbol(scope,$name,$value);
    }
    else {
        scope.merge-generated-lexical-declaration:
            RakuAST::Declaration::Import.new(
                :lexical-name($name), :compile-time-value($value)
            ),
            :resolver($*R), :force;
        %installed{nqp::objectid(scope) ~ '|' ~ $name} := $value;
    }
    Nil;
}

my sub scope-get(Mu \scope, $name) is raw {
    if $*W {
        my $existing := scope.symbol($name);
        return $existing<value>:exists ?? $existing<value> !! NO-SYMBOL;
    }

    my \key = nqp::objectid(scope) ~ '|' ~ $name;
    return %installed{key} if %installed{key}:exists;

    # scope.find-lexical would prime the scope's AST declaration cache while
    # it is still being compiled, so lookups are limited to the resolver's
    # live view of the current scope, declarations generated at BEGIN time,
    # and the unit implicits the resolver tracks itself.
    my $decl := scope =:= $*R.current-scope
        ?? $*R.resolve-lexical-constant($name, :current-scope-only)
        !! scope.find-generated-lexical($name);
    if !nqp::isconcrete($decl) && scope =:= $*CU {
        if $name eq 'EXPORT' {
            my \pkg = nqp::getattr($*R,RakuAST::Resolver,'$!export-package');
            return pkg unless nqp::eqaddr(pkg,Mu);
        }
        elsif $name eq 'GLOBALish' {
            my \pkg = $*R.get-global;
            return pkg unless nqp::eqaddr(pkg,Mu);
        }
    }
    unless nqp::isconcrete($decl) && nqp::istype($decl,RakuAST::CompileTimeValue) {
        return NO-SYMBOL;
    }

    # A value aliasing the setting's constant of the same name got here via
    # an import, not a declaration in this scope. Report it absent rather
    # than hand out a setting-owned object for callers to mutate.
    my \value = $decl.compile-time-value;
    my $setting := $*R.resolve-lexical-constant-in-setting($name);
    nqp::isconcrete($setting)
        && nqp::eqaddr(nqp::decont(value),nqp::decont($setting.compile-time-value))
        ?? NO-SYMBOL
        !! value;
}

sub vivify-QBlock-pkg(Mu \qblock is raw,$name) {
    my \existing = scope-get(qblock,$name);
    if existing =:= NO-SYMBOL {
        my $new := Metamodel::PackageHOW.new_type(:name($name));
        scope-install(qblock,$name,$new);
        $new;
    } else {
        existing;
    }
}

sub set-in-QBlock(Mu \qblock is raw,$path,Mu $value) {
    my ($first,@parts) = $path.split('::');
    if @parts {
        my $pkg = vivify-QBlock-pkg(qblock,$first);
        set-in-WHO($pkg.WHO,@parts.join('::'),$value);
    } else {
        scope-install(qblock,$first,$value);
    }
    Nil;
}

sub get-in-QBblock(Mu \qblock is raw,$path) {
    my ($first,@parts) = $path.split('::');
    my \top = scope-get(qblock,$first);
    if top =:= NO-SYMBOL {
        return Nil;
    }
    if @parts {
        return descend-WHO(top.WHO,@parts.join('::'));
    } else {
        return top;
    }
}

sub load(Str:D $short-name,*%opts --> CompUnit:D) is export(:load){
    $*REPO.need(CompUnit::DependencySpecification.new(:$short-name,|%opts));
}

sub find-loaded($match --> CompUnit) is export(:find-loaded)  {
    my $repo = $*REPO;
    my $found;

    repeat {
        if my $compunit = $repo.loaded.first($match) {
            $found = $compunit;
            last;
        }
    } while $repo .= next-repo;

    return $found || fail "unable find loaded compunit matching '{$match.gist}'";
}

sub all-loaded is export(:all-loaded){
    $*REPO.repo-chain.map(*.loaded).flat;
}

sub all-repos is export(:all-repos) {
    $*REPO.repo-chain;
}

sub at-unit($handle is copy,Str:D $path) is export(:at-unit){
    use nqp;
    $handle .= &handle;
    my ($key,*@path) = $path.split('::');

    do if nqp::existskey($handle.unit,$key) {
        my $val = nqp::atkey($handle.unit,$key);
        return do if @path {
            descend-WHO($val.WHO,@path.join('::'));
        } else {
            $val;
        }
    } else {
        Nil;
    }
}

sub descend-WHO($WHO is copy,Str:D $path) is export(:who){
    my @parts = $path.split('::');
    while @parts.shift -> $part {
        if @parts == 0 {
            return $WHO{$part};
        } else {
            return Nil unless $WHO{$part}:exists;
            $WHO = $WHO{$part}.WHO;
        }
    }
}

sub set-in-WHO($WHO is copy,$path,$value --> Nil) is export(:who) {
    use nqp;
    my @parts = $path.split('::');
    while @parts.shift -> $part {
        if @parts == 0 {
            # if no decont the goofs may happen
            $WHO.{$part} := nqp::decont($value);
        } else {
            if not $WHO.{$part}:exists {
                # if it doesn't exist create it
                $WHO.package_at_key($part);
            }
            $WHO = $WHO.{$part}.WHO;
        }
    }
    Nil;
}

sub unit-to-hash($handle? is copy) is export(:unit-to-hash) {
    use nqp;
    my $unit := $handle.unit;
    my Mu $iter := nqp::iterator($unit);
    my %hash;
    while $iter {
        my $i := nqp::shift($iter);
        %hash{nqp::iterkey_s($i)} = nqp::iterval($i);
    }
    return %hash;
}

sub capture-import($handle is copy, *@pos, *%named --> Hash:D) is export(:capture-import){
    $handle .= &handle;
    my $EXPORT     = $handle.export-package;
    my %sym;

    %named<DEFAULT> = True unless %named or @pos;

    for %named.keys {
        %sym.append($EXPORT{$_}.WHO);
    }

    with $handle.export-sub {
        %sym.append: .(|@pos);
    }

    with $handle.globalish-package {
        %sym.append: .WHO;
    }

    return %sym;
}

sub re-export($handle is copy --> Nil)  is export(:re-export) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    $handle .= &handle;
    get-unit('EXPORT').WHO.merge-symbols($handle.export-package);
    Nil;
}

sub re-exporthow($handle is copy --> Nil) is export(:re-export){
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    $handle .= &handle;

    if $handle.export-how-package -> $target-WHO {
        my $my-WHO := vivify-QBlock-pkg(unit-scope,'EXPORTHOW').WHO;
        $my-WHO.merge-symbols($target-WHO);
    }
    Nil;
}

sub steal-export-sub($handle is copy --> Nil) is export(:re-export){
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    $handle .= &handle;
    if my $EXPORT  = $handle.export-sub {
        set-unit('&EXPORT',$EXPORT);
    }
    Nil;
}

sub steal-globalish($handle is copy --> Nil) is export(:re-export){
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    $handle .= &handle;
    my $target = $handle.globalish-package;
    get-unit('GLOBALish').WHO.merge-symbols($target);
    Nil;
}

sub re-export-everything($_ is copy --> Nil) is export(:re-export) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    $_ .= &handle;
    .&re-export;
    .&re-exporthow;
    .&steal-export-sub;
    .&steal-globalish;
    Nil;
}

sub set-unit(Str:D $path,Mu $value --> Nil) is export(:set-symbols) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    set-in-QBlock(unit-scope,$path,$value);
    Nil;
}

sub set-lexpad(Str:D $path,Mu $value --> Nil) is export(:set-symbols) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    set-in-QBlock(pad-scope,$path,$value);
    Nil;
}


sub push-multi(Routine:D $target where { .is_dispatcher },Routine:D $r --> Nil) is export(:push-multi) {
    $target.add_dispatchee(nqp::decont($r));
    Nil;
}

sub push-QBlock-multi(Mu \qblock,$path,$multi is copy) {
    if get-in-QBblock(qblock,$path) -> $existing {
        if $multi.is_dispatcher {
            die "cannot add dispatcher to '$path' because it already exists";
        } else {
            push-multi($existing,$multi);
        }
    } else {
        my $install = do given $multi {
            when .multi { .dispatcher }
            when .is_dispatcher { $multi }
            default {
                ## not multi or dispatcher have to create one to attach to
                ## XXX: this results in Missing serialize REPR function for REPR MVMContext
                # my $new_proto = (my proto anon (|) {*}).clone;
                # push-multi($new_proto,$multi);
                # $new_proto;
                die "can't push a non-multi sub onto a non-existent routine";
            }
        }
        set-in-QBlock(qblock,$path,$install);
    }
    Nil;
}

sub push-unit-multi(Str:D $path, $multi --> Nil) is export(:push-multi) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    push-QBlock-multi(unit-scope,$path,$multi);
    Nil;
}

sub push-lexpad-multi(Str:D $path,$multi --> Nil) is export(:push-multi) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    push-QBlock-multi(pad-scope,$path,$multi);
    Nil;
}

sub push-lexical-multi(Str:D $path, $multi --> Nil) is export(:push-multi) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    if get-lexpad($path) -> $existing {
        push-multi($existing,$multi);
    }
    elsif get-lexical($path) -> $existing {
        if $existing.is_dispatcher {
            my $new := $existing.clone().derive_dispatcher();
            push-multi($new,$multi);
            push-lexpad-multi($path,$new);
        }
    }
    else {
        push-lexpad-multi($path,$multi);
    }
    Nil;
}

sub get-unit(Str:D $path) is export(:get-symbols) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    return get-in-QBblock(unit-scope,$path);
}

sub get-lexpad(Str:D $path) is export(:get-symbols) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    return get-in-QBblock(pad-scope,$path);
}

sub get-lexical(Str:D $path) is export(:get-symbols) {
    die "{&?ROUTINE.name} can only be called at BEGIN time" unless $*W || $*R;
    die "cannot have '::' in get-lexical lookup (got '$path'). Patch needed!" if $path ~~ /'::'/;
    # this should work with :: but it doesn't
    if $*W {
        try {
            return $*W.find_symbol(nqp::split('::',$path));
        }
    }
    else {
        my $decl := $*R.resolve-lexical-constant($path);
        return $decl.compile-time-value if nqp::isconcrete($decl);
    }
    Nil;
}

=pod This is just some pod to test at-unit('CompUnit::Util','$=pod');

# vim: expandtab shiftwidth=4
