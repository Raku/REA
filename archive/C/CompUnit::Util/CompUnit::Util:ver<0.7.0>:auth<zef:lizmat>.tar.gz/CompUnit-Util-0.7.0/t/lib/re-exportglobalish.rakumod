use CompUnit::Util :re-export, :load;

BEGIN steal-globalish(load('exports-stuff'));

# vim: expandtab shiftwidth=4
