use CompUnit::Util :re-export;
need no-stuff;

BEGIN re-exporthow('no-stuff');

# vim: expandtab shiftwidth=4
