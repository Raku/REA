use CompUnit::Util :re-export, :load;

BEGIN re-export-everything(load('exports-stuff'));

# vim: expandtab shiftwidth=4
