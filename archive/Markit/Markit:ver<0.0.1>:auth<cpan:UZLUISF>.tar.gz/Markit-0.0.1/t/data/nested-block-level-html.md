<div>
_parent_
<div>
_child_
</div>
<pre>
_adopted child_
</pre>
</div>

_outside_