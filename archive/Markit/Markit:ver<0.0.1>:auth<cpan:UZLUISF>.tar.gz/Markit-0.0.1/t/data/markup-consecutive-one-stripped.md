<div><p>Stripped markup</p></div>
_No markdown_

**Markdown**