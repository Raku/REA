&amp; &copy; &#123;
