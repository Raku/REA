> quote

indented:
   > quote

no space after `>`:
>quote

---

>>> Info 1 text

>>> Info 2 text
