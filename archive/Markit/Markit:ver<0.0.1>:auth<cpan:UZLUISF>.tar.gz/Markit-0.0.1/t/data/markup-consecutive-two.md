<div>First markup</div><p>and second markup on the same line.</p>
_No markdown_

**Markdown**