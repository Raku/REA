<div>One markup on
two lines</div>
_No markdown_

**Markdown**