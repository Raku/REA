<div>First markup</div><p>and partial markup
on two lines.</p>
_No markdown_

**Markdown**