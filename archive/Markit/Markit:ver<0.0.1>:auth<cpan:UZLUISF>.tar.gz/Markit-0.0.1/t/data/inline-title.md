[single quotes](http://example.com 'Example') and [double quotes](http://example.com "Example")
