* Prudence
* Justice
* Temperance
* Fortitude
