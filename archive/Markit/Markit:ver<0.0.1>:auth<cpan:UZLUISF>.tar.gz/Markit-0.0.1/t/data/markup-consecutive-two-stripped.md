<div><p>Stripped markup
on two lines</p></div>
_No markdown_

**Markdown**