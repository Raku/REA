trailing space
== 

trailing space
-- 

leading and trailing space
 == 

leading and trailing space
 -- 

1 leading space
 ==

1 leading space
 --

3 leading spaces
   ==

3 leading spaces
   --

too many leading spaces
    ==

too many leading spaces
    --
