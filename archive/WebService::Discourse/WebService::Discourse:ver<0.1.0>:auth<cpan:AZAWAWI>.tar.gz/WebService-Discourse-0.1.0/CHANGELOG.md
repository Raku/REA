# Changelog for WebService::Discourse

## 0.0.1 - 2018-11-??
  - :tada: :art: Initial version hits the cinemas :smile:
