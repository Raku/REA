# This module is deprecated

Please see [Cro::TLS](https://github.com/croservices/cro-tls) instead.
