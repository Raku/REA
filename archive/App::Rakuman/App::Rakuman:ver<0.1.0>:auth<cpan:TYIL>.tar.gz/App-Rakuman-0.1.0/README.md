NAME
====

App::Rakuman

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.1.0

Description
===========

A program to read the main Pod6 document of Raku modules

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install App::Rakuman
```

License
=======

This module is distributed under the terms of the AGPL-3.0.

