#!bash

tom --remove rvm
tom --profile ruby
tom --remove rvm
