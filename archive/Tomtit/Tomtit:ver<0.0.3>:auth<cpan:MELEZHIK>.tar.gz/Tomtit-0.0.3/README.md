# Tomtit

Tomtit - Perl6 "Makefile" tool based on Sparrowdo [Sparrowdo](https://github.com/melezhik/sparrowdo) plugins.

# INSTALL

    zef install Tomtit

# Bootstrap

You need to bootstrap your system to start using tomtit, it's a one time operation,
where you install Sparrow which is underlying tomtit runner.
    
    tom --bootstrap 

# USAGE

    tom # get help

    tom --list # list available scenarios

    tom --run=$scenario # run scenario

    tom --last # show last scenario

    tom --clean # clean tomtit's cache

Example:

    tom --list

    [scenarios list]
    test
    build
    install

    tom --run=test        

# Scenario example

    cat .tom/install.pl6

    bash "zef install --force-install ."

# Defining scenarios

Tomtit scenarios are just Sparrowdo scenarios you create in `.tom` directory:
  
    mkdir .tom/
    nano .tom/build.pl6
    nano .tom/test.pl6
    nano .tom/install.pl6

You want to ignore tomtit cache which commit files to SCM:

    git add .tom/
    echo .tom/.cache >> .gitignore

# Other options

    --verbose # run scenrios in verbose mode
    --quiet   # run scenrios in less verbose mode

# Author

Alexey Melezhik


# Thanks to

God Who gives me inspiration in my work

