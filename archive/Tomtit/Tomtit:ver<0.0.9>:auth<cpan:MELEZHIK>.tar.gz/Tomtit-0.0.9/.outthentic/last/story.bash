#!/bin/bash

set -e

tom hello
echo LAST
tom --last
echo LAST
