#!/bash

tom foobar
echo
