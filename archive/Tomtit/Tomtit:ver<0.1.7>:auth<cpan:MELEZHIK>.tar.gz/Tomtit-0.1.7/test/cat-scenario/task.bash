#!/bin/bash

set -e

tom --cat world

