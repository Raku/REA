#!/bin/bash

set -e

tom --cat --lines world

