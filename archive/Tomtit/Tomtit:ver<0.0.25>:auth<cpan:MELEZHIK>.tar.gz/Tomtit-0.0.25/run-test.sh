strun --root .outthentic --recu
