[![Build Status](https://travis-ci.org/FCO/Math-PascalTriangle.svg?branch=master)](https://travis-ci.org/FCO/Math-PascalTriangle)

# Math-PascalTriangle
Simple Pascal's Triangle module
