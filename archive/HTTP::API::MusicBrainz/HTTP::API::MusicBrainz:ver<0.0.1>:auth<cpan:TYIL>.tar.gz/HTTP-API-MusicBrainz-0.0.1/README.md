### has URL $!root-url

The base URL object to create all URLs from.

### has Mu $!user-agent

The user agent which will be used internally for handling HTTP requests.

### method search

```perl6
method search(
    Str:D $entity,
    Str:D $query,
    Int $limit = 30,
    Int $offset = 0
) returns Mu
```

Private method to perform search requests.

class Str:D $entity
-------------------

The name of the entity to search for.

class Str:D $query
------------------

The query to search for.

class Int $limit = 30
---------------------

The number of results to fetch.

class Int $offset = 0
---------------------

The offset from the start.

### method http-request

```perl6
method http-request(
    URL:D $url
) returns Associative
```

Private method to handle the actual HTTP requests.

class URL:D $url
----------------

The URL to make the request to.

class $query
------------

A string to search for.

class Int $limit = Int
----------------------

The maximum number of results to fetch.

class Int $offset = Int
-----------------------

An offset from the start of the result set.

NAME
====

HTTP::API::MusicBrainz

VERSION
=======

0.0.1

AUTHOR
======

Patrick Spek <p.spek@tyil.nl>

LICENSE
=======

Copyright © 2020

This program is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License along with this program. If not, see http://www.gnu.org/licenses/.

