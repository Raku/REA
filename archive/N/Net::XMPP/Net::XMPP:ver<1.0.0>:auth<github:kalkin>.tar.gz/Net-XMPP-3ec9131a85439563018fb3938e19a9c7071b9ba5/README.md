P6-Net-XMPP
===========

Net::XMPP is an XMPP client module. Currently does the initial connection for you,
and then allows you to send and receive stanzas.
