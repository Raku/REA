
## What is this? 

This folder contains files used in the tests only. Nothing here is relevant to the 
functioning module.
