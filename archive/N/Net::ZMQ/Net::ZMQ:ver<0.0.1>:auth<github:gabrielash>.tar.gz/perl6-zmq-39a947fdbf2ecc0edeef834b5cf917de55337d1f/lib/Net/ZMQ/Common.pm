#!/usr/bin/env perl6

unit module Net::ZMQ::Common;
use NativeCall;
use v6;
