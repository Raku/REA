## Directory native

## Description

This folder holds intermediate files that are used in the development. There
are of no interest to end users and are not needed for installation. 
