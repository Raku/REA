
#include "buffer-helper.h"


void *array_offset_byte( void *array, int index) {
    return array + index;
} 
