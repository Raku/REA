
#ifndef _BUFFER_HELPER_H_
#define _BUFFER_HELPER_H_


void *array_offset_byte( void *array, int index);


#endif