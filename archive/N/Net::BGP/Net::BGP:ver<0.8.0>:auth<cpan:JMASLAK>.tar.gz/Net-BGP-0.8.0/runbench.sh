#!/bin/bash

#
# Copyright (C) 2019 Joelle Maslak
# All Rights Reserved - See License
#

PERL6LIB=lib time perl6 t/benchmark.pl6

