[![Actions Status](https://github.com/raku-community-modules/NativeLibs/actions/workflows/linux.yml/badge.svg)](https://github.com/raku-community-modules/NativeLibs/actions) [![Actions Status](https://github.com/raku-community-modules/NativeLibs/actions/workflows/macos.yml/badge.svg)](https://github.com/raku-community-modules/NativeLibs/actions)

NAME
====

NativeLibs - Native libraries utilities

SYNOPSIS
========

```raku
# This also re-exports NativeCall :DEFAULTS for convenience
use NativeLibs;

# Load the needed library
my $Lib = INIT NativeLibs::Loader.load('libsomelib.so.4')
  orelse .fail;

sub some_native_func() is native {*} # Note no library needed
```

DESCRIPTION
===========

The `NativeLibs` distribution provides a number of alternatives to loading binary libraries with `NativeCall`.

NativeLibs::Loader.load
=======================

This class method provides a Raku version of the raw binary library loading function as found in MoarVM.

NativeLibs::Searcher.at-runtime
===============================

If you need to check for a number of versions of the binary library you can do this with this class method:

```raku
use NativeLibs;

constant LIB = NativeLibs::Searcher.at-runtime(
  'mysqlclient', # The library short name
  'mysql_init',  # A 'well known symbol'
  16..20	     # A List of supported versions, a range in this example
);

sub mysql_get_client_info(--> Str) is export is native(LIB) {*}
```

AUTHORS
=======

  * Salvador Ortiz

  * Raku Community

COPYRIGHT AND LICENSE
=====================

Copyright 2016 - 2021 by Salvador Ortiz

Copyright 2026 Raku Community

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

