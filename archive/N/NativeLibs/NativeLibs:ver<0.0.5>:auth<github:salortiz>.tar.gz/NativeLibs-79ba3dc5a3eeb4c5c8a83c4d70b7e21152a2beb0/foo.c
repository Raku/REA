#include <stdio.h>

int main() {
    printf("size: %lu", sizeof(int));
}
