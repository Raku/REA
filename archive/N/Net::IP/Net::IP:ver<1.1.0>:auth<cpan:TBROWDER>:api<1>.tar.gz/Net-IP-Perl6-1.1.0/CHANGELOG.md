# 2019-10-15
- v1.1.0
- added two functions with tests:
    + ip-int2ip
    + ip-ip2int
- deleted old docs
- added leading declarator doc for all subs


# 2018-01-24
- v1.0.0
- initial release
