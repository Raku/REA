use v6;

class Net::OSC {

  method pack-message(*@args) returns Buf {

  }

  method unpack-message(Blob:D $message) returns List:D {

  }
}
