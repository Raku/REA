use v6;

class Net::OSC::Bundle {

}
