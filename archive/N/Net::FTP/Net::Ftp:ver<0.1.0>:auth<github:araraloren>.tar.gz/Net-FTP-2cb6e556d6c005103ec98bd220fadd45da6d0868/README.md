# Net-Ftp
perl6 Net::Ftp
A simple ftp client module written in perl6.
