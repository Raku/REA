NAME
====

Net::NetRC - parse <.netrc> files

SYNOPSIS
========

```raku
use Net::NetRC;
```

DESCRIPTION
===========

Net::NetRC is ...

AUTHOR
======

Humberto Massa <humbertomassa@gmail.com>

COPYRIGHT AND LICENSE
=====================

Copyright 2022 Humberto Massa

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

