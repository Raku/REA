
images based on https://kayne-stock.deviantart.com/art/butterfly-1-2264235

