#!/bin/bash

cd $HOME/work

start-notebook.sh
