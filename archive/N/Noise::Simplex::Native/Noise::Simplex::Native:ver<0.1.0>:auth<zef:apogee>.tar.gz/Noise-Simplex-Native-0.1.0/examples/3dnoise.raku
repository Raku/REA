#!/usr/bin/env raku

use lib 'lib';
use Noise::Simplex::Native;
use Image::PNG::Portable;

# Set width/height/number of z levels for noise images.
# Each z-level becomes its own image.
my $width = 512;
my $height = 512;

# Create a new Simplex (native) with seed 12345, then return a 3D noise map.
my $simplex = Noise::Simplex::Native::Simplex.new(seed => 12345);
my &noise3d = $simplex.create-noise3d;

mkdir 'img' unless 'img'.IO.d;

# For each z value
for 0 ..^ 8 -> $z {
    my $img = Image::PNG::Portable.new: :$width, :$height, :alpha(False);
    for 0 ..^ $height -> $y {
        for 0 ..^ $width -> $x {
            my $n = noise3d($x / 64, $y / 64, $z / 64);
            my $val = ($n + 1) * 127.5;
            $img.set: $x, $y, $val.round, $val.round, $val.round;
        }
    }
    $img.write: "img/3d-z$z.png";
}
