use Test;
use lib 'lib';
use Noise::Simplex::Native;

# Author-only test: this module's permutation table must byte-for-byte
# match the pure-Raku Noise::Simplex's for the same seed. That parity
# is the foundation of the bit-identical 2D / typically-ULP-close 3D
# contract — without it nothing in xt/02 / xt/03 holds.
#
# Lives in xt/ because Noise::Simplex is otherwise an author-time
# dep only; no reason to make every `zef install` user pull it in.

plan 1;

require Noise::Simplex;
my $OrigSimplex = ::("Noise::Simplex::EXPORT::DEFAULT::Simplex");

my @seeds = 1, 12345, 54321, 0, 2 ** 31 - 1;

subtest 'permutation table matches Noise::Simplex byte-for-byte' => {
    plan +@seeds;
    for @seeds -> $seed {
        my $native = Noise::Simplex::Native::Simplex.new(:$seed);
        my $orig   = $OrigSimplex.new(:$seed);
        is-deeply $native.build-permutation-table,
                  $orig.build-permutation-table,
                  "seed $seed: permutation tables match";
    }
}

done-testing;
