#| Build.rakumod for Noise::Simplex::Native.
#|
#| Mirrors CRoaring's two-path install flow:
#|
#|   1. Prebuilt binary download from GitHub Releases for the detected
#|      (OS, arch) pair. ~1-3 seconds on a decent connection, no
#|      compiler needed. Artefacts have no dependencies beyond libc /
#|      libm.
#|
#|   2. Fallback: compile the vendored src/simplex_native.c with `cc`
#|      (or `cl` on Windows/MSVC). Takes well under a second; needs a
#|      C toolchain but no other system deps — the source is ~270
#|      lines and uses only <math.h> + <stdint.h> + <stdlib.h> +
#|      <string.h>.
#|
#| Linux prebuilts are built on ubuntu-22.04 (glibc 2.35 — see the
#| $MIN-GLIBC constant). On systems with older glibc the prebuilt
#| .so loads but dies at first symbol use with "GLIBC_2.xx not
#| found". Build detects this via `ldd --version` and short-circuits
#| to source compile before the download.
#|
#| Compile flags (both prebuilt CI and source fallback) include
#| `-fno-fast-math -ffp-contract=off`. These are the determinism
#| guardrails: without them, the compiler is free to reorder FP
#| operations and fuse multiply-adds (especially clang on Apple
#| Silicon), which would break the bit-identical-2D contract with
#| the pure-Raku Noise::Simplex.
#|
#| Env-var knobs:
#|
#|   NOISE_SIMPLEX_NATIVE_BUILD_FROM_SOURCE=1
#|       skip the prebuilt path, always compile.
#|   NOISE_SIMPLEX_NATIVE_BINARY_ONLY=1
#|       refuse to fall back to source compile.
#|   NOISE_SIMPLEX_NATIVE_BINARY_URL=<url>
#|       override the GitHub release base URL (mirrors,
#|       air-gapped repos).
#|   NOISE_SIMPLEX_NATIVE_CACHE_DIR=<path>
#|       override cache dir (default $XDG_CACHE_HOME / ~/.cache).
#|
#| Binary artefacts are versioned independently of the Raku dist:
#| the Raku dist version moves for binding / Raku-side fixes; the
#| binary tag in BINARY_TAG only moves when src/simplex_native.c or
#| the static-link recipe changes. Raku bugfix releases keep
#| pointing at the same binary tag so existing caches stay valid.

class Build {

    # --- Constants ------------------------------------------------------

    constant $DEFAULT-BASE-URL =
        'https://github.com/m-doughty/Noise-Simplex-Native/releases/download';

    # Minimum glibc the prebuilt Linux archives are compatible with.
    # Bump in lockstep with the CI runner OS in
    # .github/workflows/build-binaries.yml.
    constant $MIN-GLIBC = v2.35;

    # Map (OS, hardware) → platform slug used in both the release
    # artefact filename and the cache directory layout. Both Darwin
    # arches share the macos-universal slug: CI publishes one fat
    # dylib with arm64 + x86_64 slices.
    my %PLATFORM-SLUGS =
        'darwin-arm64'    => 'macos-universal',
        'darwin-x86_64'   => 'macos-universal',
        'linux-x86_64'    => 'linux-x86_64-glibc',
        'linux-aarch64'   => 'linux-aarch64-glibc',
        'win32-x86_64'    => 'windows-x86_64',
        'win32-aarch64'   => 'windows-arm64',
        'mswin32-x86_64'  => 'windows-x86_64',
        'mswin32-aarch64' => 'windows-arm64',
    ;

    # --- Entry point ----------------------------------------------------

    method build($dist-path) {
        my Bool $force-source = ?%*ENV<NOISE_SIMPLEX_NATIVE_BUILD_FROM_SOURCE>;
        my Bool $binary-only  = ?%*ENV<NOISE_SIMPLEX_NATIVE_BINARY_ONLY>;

        my Str $binary-tag = self!binary-tag($dist-path);
        my Str $plat = self!detect-platform;
        without $plat {
            note "⚠️  Unknown platform ({$*KERNEL.name}-{$*KERNEL.hardware}); "
                ~ "falling back to source build.";
            self!compile-from-source($dist-path);
            return True;
        }

        # Glibc guard: fall back to source compile before even attempting
        # the prebuilt download on systems older than $MIN-GLIBC, where
        # the prebuilt would load but fail at first symbol use.
        if !$force-source && $plat.ends-with('-glibc') {
            my Version $have = self!detect-glibc-version;
            if $have.defined && $have cmp $MIN-GLIBC == Less {
                if $binary-only {
                    die "NOISE_SIMPLEX_NATIVE_BINARY_ONLY=1 set but system glibc "
                      ~ "$have is older than prebuilt target $MIN-GLIBC "
                      ~ "($plat / $binary-tag).";
                }
                note "⚠️  System glibc $have is older than prebuilt "
                   ~ "target $MIN-GLIBC — falling back to source build "
                   ~ "to avoid runtime loader errors.";
                self!compile-from-source($dist-path);
                say "✅ Compiled Noise::Simplex::Native from vendored source.";
                return True;
            }
        }

        unless $force-source {
            if self!try-prebuilt($dist-path, $plat, $binary-tag) {
                say "✅ Installed prebuilt Noise::Simplex::Native binary "
                   ~ "($plat) for $binary-tag.";
                return True;
            }
            if $binary-only {
                die "NOISE_SIMPLEX_NATIVE_BINARY_ONLY=1 set but prebuilt "
                  ~ "download failed for $plat ($binary-tag).";
            }
            note "⚠️  Prebuilt binary unavailable for $plat ($binary-tag) "
               ~ "— compiling from source.";
        }

        self!compile-from-source($dist-path);
        say "✅ Compiled Noise::Simplex::Native from vendored source.";
        True;
    }

    # --- Prebuilt binary path -------------------------------------------

    #| Attempt to download, verify, and install the prebuilt artefact
    #| for $plat. Returns True on success, False on any failure — Build
    #| falls back to source compile on False (unless BINARY_ONLY is set).
    method !try-prebuilt($dist-path, Str $plat, Str $binary-tag --> Bool) {
        my Str $artifact = self!artifact-name($plat);
        my IO::Path $cache-dir = self!cache-dir($binary-tag);
        my IO::Path $cached = $cache-dir.add($artifact);
        my Str $base-url = %*ENV<NOISE_SIMPLEX_NATIVE_BINARY_URL>
            // $DEFAULT-BASE-URL;
        my Str $url = "$base-url/$binary-tag/$artifact";

        unless $cached.e {
            $cache-dir.mkdir;
            say "⬇️  Fetching $artifact from $url";
            # `run` with arg list avoids shell quoting entirely.
            # Essential on Windows where cmd.exe treats single quotes
            # as literals and a quoted Windows path looks like a
            # malformed URL to curl.
            my $rc = run 'curl', '-fL', '--progress-bar',
                         '-o', $cached.Str, $url;
            unless $rc.exitcode == 0 {
                $cached.unlink if $cached.e;
                return False;
            }
        }

        my Str $expected = self!expected-sha($dist-path, $artifact);
        without $expected {
            note "No checksum recorded for $artifact in resources/checksums.txt "
                ~ "— refusing prebuilt (bundled checksums are a hard security boundary).";
            return False;
        }

        my Str $actual = self!sha256($cached);
        unless $actual.defined && $actual.lc eq $expected.lc {
            note "Checksum mismatch for $artifact "
                ~ "(expected $expected, got {$actual // 'unknown'}).";
            $cached.unlink;
            return False;
        }

        self!install-artefact($cached, $dist-path, $plat);
        self!stage-stubs($dist-path);
        True;
    }

    method !artifact-name(Str $plat --> Str) {
        my Str $ext = $plat.starts-with('windows') ?? 'dll'
                    !! $plat.starts-with('macos')  ?? 'dylib'
                    !! 'so';
        "libnoise_simplex_native-$plat.$ext";
    }

    method !install-artefact(IO::Path $src, $dist-path, Str $plat) {
        my IO::Path $dest-dir = "$dist-path/resources/lib".IO;
        $dest-dir.mkdir;

        my Str $ext = $plat.starts-with('windows') ?? 'dll'
                    !! $plat.starts-with('macos')  ?? 'dylib'
                    !! 'so';
        my IO::Path $dest = $dest-dir.add("libnoise_simplex_native.$ext");
        copy $src, $dest;
    }

    method !cache-dir(Str $binary-tag --> IO::Path) {
        my Str $base = %*ENV<NOISE_SIMPLEX_NATIVE_CACHE_DIR>
            // %*ENV<XDG_CACHE_HOME>
            // "{%*ENV<HOME> // '.'}/.cache";
        "$base/Noise-Simplex-Native-binaries/$binary-tag".IO;
    }

    #| Read the binary tag from the top-level BINARY_TAG file. Same
    #| file is read by .github/workflows/build-binaries.yml so there
    #| is one source of truth for which release tag this Build expects.
    method !binary-tag($dist-path --> Str) {
        my IO::Path $file = "$dist-path/BINARY_TAG".IO;
        unless $file.e {
            die "❌ Missing BINARY_TAG file at { $file }. This file must "
              ~ "contain the pinned binary release tag "
              ~ "(e.g. 'binaries-noise-simplex-native-0.1.0-r1') and "
              ~ "ship with the distribution.";
        }
        my Str $tag = $file.slurp.trim;
        die "❌ BINARY_TAG file is empty." unless $tag.chars;
        $tag;
    }

    method !expected-sha($dist-path, Str $artifact --> Str) {
        my IO::Path $file = "$dist-path/resources/checksums.txt".IO;
        return Str unless $file.e;
        for $file.slurp.lines -> Str $line {
            my Str $trimmed = $line.trim;
            next if $trimmed eq '' || $trimmed.starts-with('#');
            my @parts = $trimmed.words;
            next unless @parts.elems >= 2;
            return @parts[0] if @parts[1] eq $artifact;
        }
        Str;
    }

    method !sha256(IO::Path $file --> Str) {
        # `run` with arg list avoids shell quoting quirks (same reason
        # as the curl invocation above).
        if $*DISTRO.is-win {
            my $proc = run 'certutil', '-hashfile', $file.Str, 'SHA256',
                           :out, :err;
            my $out = $proc.out.slurp(:close);
            $proc.err.slurp(:close);
            # certutil output: header line, hex digest (one line per
            # locale — sometimes space-separated bytes "AB CD EF…"
            # on older Windows, no spaces on Win10+), trailer line.
            for $out.lines -> Str $line {
                my Str $t = $line.subst(/\s+/, '', :g).lc;
                return $t if $t.chars == 64 && $t ~~ /^ <[0..9a..f]>+ $/;
            }
            return Str;
        }
        my $proc = run 'shasum', '-a', '256', $file.Str, :out, :err;
        my $out = $proc.out.slurp(:close);
        $proc.err.slurp(:close);
        $out.words.head;
    }

    # --- Source compile path --------------------------------------------

    #| Compile src/simplex_native.c. Uses the same hardened flags as the
    #| CI-side prebuilt recipe so the resulting binary is behaviour-
    #| identical (modulo strip-debug differences).
    #|
    #| Critical FP flags:
    #|   -fno-fast-math    determinism gate against FP reassociation,
    #|                     flush-to-zero, etc.
    #|   -ffp-contract=off blocks FMA contraction (a*b+c → fma()).
    #|                     Critical on Apple Silicon, where clang
    #|                     defaults to contraction even with
    #|                     -fno-fast-math, producing output that
    #|                     diverges from the pure-Raku reference.
    method !compile-from-source($dist-path) {
        self!check-toolchain;

        my Str $os = $*KERNEL.name.lc;
        my Str $src = "$dist-path/src/simplex_native.c";
        my Str $outdir = "$dist-path/resources/lib";
        $outdir.IO.mkdir;

        my Str $build-cmd;
        my Str $strip-cmd = '';

        if $os ~~ /darwin/ {
            # `-install_name @rpath/...` keeps the lib relocatable
            # after it's copied into resources/lib/.
            # `-arch arm64 -arch x86_64` produces a universal dylib
            # matching what CI publishes, so the source-compile path
            # is behaviour-identical to the prebuilt path.
            $build-cmd = qq{cc -O3 -dynamiclib -fPIC }
                       ~ qq{-fno-fast-math -ffp-contract=off }
                       ~ qq{-std=c11 -Wall -Wextra }
                       ~ qq{-arch arm64 -arch x86_64 }
                       ~ qq{-install_name \@rpath/libnoise_simplex_native.dylib }
                       ~ qq{$src -lm }
                       ~ qq{-o $outdir/libnoise_simplex_native.dylib};
            $strip-cmd = qq{strip -x $outdir/libnoise_simplex_native.dylib};
        }
        elsif $os ~~ /win/ {
            # MSVC: separate compile + link. /O2 for optimisation,
            # /fp:precise to match GCC's -fno-fast-math semantics
            # (ordered evaluation, no surprising contraction). The
            # exported symbols (simplex_create / _destroy / _noise2d /
            # _noise3d / _fill2d_grid / _fill3d_grid) are exported via
            # __declspec(dllexport) — see src/simplex_native.c.
            $build-cmd = qq{cl /O2 /fp:precise /c }
                       ~ qq{/Fo:$dist-path\\src\\simplex_native.obj $src }
                       ~ qq{&& link /DLL }
                       ~ qq{/OUT:$outdir\\libnoise_simplex_native.dll }
                       ~ qq{$dist-path\\src\\simplex_native.obj};
            # MSVC Release doesn't embed PDB by default; nothing to strip.
        }
        else {
            $build-cmd = qq{cc -O3 -shared -fPIC }
                       ~ qq{-fno-fast-math -ffp-contract=off }
                       ~ qq{-std=c11 -Wall -Wextra }
                       ~ qq{$src -lm }
                       ~ qq{-o $outdir/libnoise_simplex_native.so};
            $strip-cmd = qq{strip --strip-unneeded $outdir/libnoise_simplex_native.so};
        }

        my $rc = shell $build-cmd;
        die "❌ Failed compiling Noise::Simplex::Native from source."
            unless $rc.exitcode == 0;

        # Non-fatal: strip failing just leaves a slightly larger lib.
        shell $strip-cmd if $strip-cmd;

        self!stage-stubs($dist-path);
    }

    method !check-toolchain() {
        my Str $probe = $*DISTRO.is-win
            ?? 'cl /? > nul 2>&1'
            !! 'cc --version > /dev/null 2>&1';
        unless shell($probe).exitcode == 0 {
            die qq:to/ERR/;
                ❌ No C compiler found. Install one of:
                    macOS:         xcode-select --install
                    Debian/Ubuntu: sudo apt install build-essential
                    Fedora:        sudo dnf install gcc
                    Arch:          sudo pacman -S base-devel
                    openSUSE:      sudo zypper in gcc
                    Windows:       install Visual Studio Build Tools (MSVC)
                ERR
        }
    }

    # --- Shared helpers -------------------------------------------------

    method !detect-platform(--> Str) {
        my Str $key = "{$*KERNEL.name.lc}-{$*KERNEL.hardware.lc}";
        %PLATFORM-SLUGS{$key};
    }

    #| Parse `ldd --version` for the system's glibc version. Returns a
    #| Version on glibc systems, Nil on musl (ldd --version exits
    #| non-zero) or when ldd is absent / unparseable. Only meaningful
    #| on Linux.
    method !detect-glibc-version(--> Version) {
        my $proc = try { run 'ldd', '--version', :out, :err };
        return Version without $proc;
        my $out = $proc.out.slurp(:close);
        $proc.err.slurp(:close);
        return Version unless $proc.exitcode == 0;
        my $first = $out.lines.head // '';
        if $first ~~ / (\d+ '.' \d+ [ '.' \d+ ]?) \s* $ / {
            return Version.new(~$0);
        }
        Version;
    }

    #| Create empty placeholder files for the two platform-specific
    #| library names we're NOT on, so META6.json's `resources` list
    #| stays satisfiable on every platform.
    method !stage-stubs($dist-path) {
        for <libnoise_simplex_native.dylib
             libnoise_simplex_native.so
             libnoise_simplex_native.dll> -> Str $name {
            my Str $path = "$dist-path/resources/lib/$name";
            $path.IO.spurt('') unless $path.IO.f;
        }
    }
}
