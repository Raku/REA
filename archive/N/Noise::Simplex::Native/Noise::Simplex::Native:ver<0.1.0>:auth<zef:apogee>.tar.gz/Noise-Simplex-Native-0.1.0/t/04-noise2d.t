use Test;
use lib 'lib';
use Noise::Simplex::Native;

# Port of Noise_Simplex/t/02_noise2d.t — same assertions, against the
# native module.

plan 7;

my $simplex = Noise::Simplex::Native::Simplex.new(seed => 12345);
my &n2d = $simplex.create-noise2d;

# 1. Returns a number
ok n2d(0.5, 0.5) ~~ Numeric, 'Returns a number';

# 2. Value within reasonable range
my $val = n2d(0.5, 0.5);
ok $val >= -1.2 && $val <= 1.2, "Value within reasonable range: $val";

# 3. Reproducibility with same seed
my $simplex2 = Noise::Simplex::Native::Simplex.new(seed => 12345);
my &n2d-b = $simplex2.create-noise2d;
is-approx n2d(0.7, 0.7), n2d-b(0.7, 0.7), 'Same seed gives same output';

# 4. Different seed gives different output (usually)
my $simplex3 = Noise::Simplex::Native::Simplex.new(seed => 54321);
my &n2d-c = $simplex3.create-noise2d;
nok n2d(0.5, 0.5) == n2d-c(0.5, 0.5), 'Different seed → different output (1)';
nok n2d(0.3, 0.7) == n2d-c(0.3, 0.7), 'Different seed → different output (2)';

# 5. Smoothness — nearby inputs give similar output
my $delta  = abs(n2d(0.10, 0.10) - n2d(0.11, 0.10));
my $delta2 = abs(n2d(0.20, 0.20) - n2d(0.20, 0.21));
ok $delta  < 0.1, "Noise smooth in x: Δ = $delta";
ok $delta2 < 0.1, "Noise smooth in y: Δ = $delta2";

done-testing;
