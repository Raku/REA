use Test;
use lib 'lib';
use Noise::Simplex::Native;

plan 6;

my $simplex = Noise::Simplex::Native::Simplex.new(seed => 12345);
my @perm = $simplex.build-permutation-table;

# 1. 512 elements (256 duplicated)
is @perm.elems, 512, 'Permutation table has 512 elements';

# 2. First 256 elements are a permutation of 0..255
my %seen;
@perm[0..255].map({ %seen{$_}++ });
is %seen.keys.sort({ .Int }), (0..255), 'First half is a permutation of 0..255';

# 3. Second half duplicates the first
is-deeply @perm[256..511], @perm[0..255], 'Second half duplicates the first';

# 4. All values in 0..255
ok all(@perm) ~~ Int && all(@perm) >= 0 && all(@perm) <= 255,
    'All values in 0..255';

# 5. Reproducibility with the same seed
my $another = Noise::Simplex::Native::Simplex.new(seed => 12345);
is-deeply $another.build-permutation-table, @perm, 'Same seed gives same table';

# 6. Different seed gives different table
my $other = Noise::Simplex::Native::Simplex.new(seed => 54321);
isnt $other.build-permutation-table.head(8).join(','),
     @perm.head(8).join(','),
    'Different seed gives different table (first 8 differ)';

done-testing;

# The cross-module parity assertion (this module's permutation table
# byte-for-byte matches the pure-Raku Noise::Simplex's for the same
# seed) lives in xt/01-permutation-table-cross-module.t. It depends
# on Noise::Simplex, which we don't want to require for normal users
# running zef install — only the author's xt/ run pulls it in.
