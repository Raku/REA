use Test;
use lib 'lib';
use Noise::Simplex::Native;

plan 4;

my $s = Noise::Simplex::Native::Simplex.new(seed => 12345);
ok $s.defined, 'Simplex constructed';
is $s.seed, 12345, 'seed accessor returns the constructor value';

my &n2d = $s.create-noise2d;
ok &n2d.defined, 'create-noise2d returned a callable';

lives-ok { $s.dispose }, 'dispose runs cleanly';

done-testing;
