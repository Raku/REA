use Test;
use lib 'lib';
use Noise::Simplex::Native;

# Port of Noise_Simplex/t/03_noise3d.t — same assertions, against
# the native module.

plan 7;

my $seed = 12345;
my $simplex = Noise::Simplex::Native::Simplex.new(:$seed);
my &n3d = $simplex.create-noise3d;

# 1. Returns a number
my $out = n3d(0.1, 0.2, 0.3);
ok $out ~~ Numeric, 'Returns a number';

# 2. Value within [-1, 1]
ok $out >= -1 && $out <= 1, "Noise value in range [-1, 1]";

# 3. Determinism
my $out2 = n3d(0.1, 0.2, 0.3);
is-approx $out, $out2, 1e-12, 'Same seed & input gives same output';

# 4. Different seed gives different value
my $simplex2 = Noise::Simplex::Native::Simplex.new(seed => $seed + 1);
my &n3d-other = $simplex2.create-noise3d;
ok n3d-other(0.1, 0.2, 0.3) != $out, 'Different seed gives different output';

# 5. Continuity — small input change → small output change
my $delta = abs(n3d(0.1, 0.2, 0.3) - n3d(0.1001, 0.2001, 0.3001));
ok $delta < 0.01, "Small input change yields small output change";

# 6. Origin
ok n3d(0, 0, 0) ~~ Numeric, 'Noise at origin returns number';

# 7. Range across multiple samples
my $all-in-range = all (0..10).map: {
    my $v = n3d($_/5, $_/7, $_/11);
    $v >= -1 && $v <= 1
};
ok $all-in-range, 'All sampled outputs within [-1, 1]';

done-testing;
