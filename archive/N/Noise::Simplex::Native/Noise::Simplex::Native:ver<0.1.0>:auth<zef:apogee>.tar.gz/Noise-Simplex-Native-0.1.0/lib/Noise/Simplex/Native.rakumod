unit module Noise::Simplex::Native;

use NativeCall;
use Math::Random::MT;
use Noise::Simplex::Native::FFI;

#| Noise::Simplex::Native::Simplex — drop-in NativeCall port of
#| Noise::Simplex::Simplex.
#|
#| API parity with the pure-Raku Simplex class:
#|   .new(:$seed!)          — build instance and native ctx
#|   .build-permutation-table → Array[Int] (512 elems)
#|   .create-noise2d        → sub ($x, $y --> Num)
#|   .create-noise3d        → sub ($x, $y, $z --> Num)
#|
#| Plus an additive RAII surface:
#|   .dispose               — idempotent; releases the native ctx
#|   submethod DESTROY      — runs .dispose at GC; users do not need
#|                            to call .dispose manually
#|
#| The closures returned by create-noise2d / create-noise3d capture
#| `self` strongly, so the native ctx cannot be freed while a closure
#| is still held. This keeps the memory model invisible to callers.
class Simplex is export {
	has Int     $.seed is required;
	has         $!ctx;            # SimplexCtx; Nil after dispose
	has         @!perm;           # Raku-side cached perm table

	submethod BUILD(:$!seed) {
		@!perm = self.build-permutation-table;

		# Hand the first 256 bytes (the unique permutation; the upper
		# 256 are a duplicate the C side produces itself) to the
		# native constructor.
		my $first256 = CArray[uint8].new(@!perm[0..255]».Int);
		$!ctx = simplex_create($first256);
		die "Noise::Simplex::Native: simplex_create returned null"
			unless $!ctx.defined;
	}

	#| Build the 512-element permutation table — exact copy of the
	#| pure-Raku original (lib/Noise/Simplex.rakumod:241-251) so the
	#| same seed produces the same table on both modules.
	method build-permutation-table {
		my $rng = Math::Random::MT.mt19937_64;
		$rng.setSeed($!seed);

		my @table = (0 .. 255);
		for 0 .. 254 -> $i {
			my $r = $i + $rng.nextInt(256 - $i);
			@table[$i, $r] = @table[$r, $i];
		}
		@table.append: @table;
	}

	#| Returns a closure `sub ($x, $y --> Num)` that samples 2D
	#| simplex noise. Inputs are coerced to Num at the boundary so
	#| callers may pass Int / Rat freely. The closure captures `self`
	#| to keep the native ctx alive for the closure's lifetime.
	method create-noise2d {
		my $obj = self;
		sub ($x, $y) {
			$obj!sample2d($x.Num, $y.Num);
		}
	}

	#| Returns a closure `sub ($x, $y, $z --> Num)` that samples 3D
	#| simplex noise. See create-noise2d notes on coercion + lifetime.
	method create-noise3d {
		my $obj = self;
		sub ($x, $y, $z) {
			$obj!sample3d($x.Num, $y.Num, $z.Num);
		}
	}

	method !sample2d(num64 $x, num64 $y --> num64) {
		die "Noise::Simplex::Native::Simplex used after dispose"
			unless $!ctx.defined;
		simplex_noise2d($!ctx, $x, $y);
	}

	method !sample3d(num64 $x, num64 $y, num64 $z --> num64) {
		die "Noise::Simplex::Native::Simplex used after dispose"
			unless $!ctx.defined;
		simplex_noise3d($!ctx, $x, $y, $z);
	}

	#| Fill a 2D regular grid of samples in a single native call.
	#|
	#| For a w*h grid with origin (x0, y0) and step (dx, dy), returns a
	#| CArray[num64] of length w*h where index `j*w + i` holds
	#| noise2d(x0 + i*dx, y0 + j*dy). Bit-identical to calling the
	#| per-sample closure with the same coordinates, but pays the
	#| NativeCall boundary cost once instead of w*h times — the
	#| typical win on a 256x256 grid is around 5-10x over per-sample.
	method fill-noise2d-grid(
		Num()   :$x0!, Num() :$dx!, Int :$w!,
		Num()   :$y0!, Num() :$dy!, Int :$h!,
		--> CArray[num64]
	) {
		die "Noise::Simplex::Native::Simplex used after dispose"
			unless $!ctx.defined;
		die "fill-noise2d-grid: w and h must be positive"
			unless $w > 0 && $h > 0;
		my $out = CArray[num64].allocate($w * $h);
		simplex_fill2d_grid($!ctx, $x0, $dx, $w, $y0, $dy, $h, $out);
		$out;
	}

	#| Fill a 3D regular grid of samples in a single native call.
	#|
	#| For a w*h*d volume, returns a CArray[num64] of length w*h*d
	#| where index `(k*h + j)*w + i` holds
	#| noise3d(x0 + i*dx, y0 + j*dy, z0 + k*dz). Z-major iteration
	#| matches examples/3dnoise.raku, so the natural per-z-slice
	#| traversal hits cache-warm rows.
	method fill-noise3d-grid(
		Num()   :$x0!, Num() :$dx!, Int :$w!,
		Num()   :$y0!, Num() :$dy!, Int :$h!,
		Num()   :$z0!, Num() :$dz!, Int :$d!,
		--> CArray[num64]
	) {
		die "Noise::Simplex::Native::Simplex used after dispose"
			unless $!ctx.defined;
		die "fill-noise3d-grid: w, h, and d must be positive"
			unless $w > 0 && $h > 0 && $d > 0;
		my $out = CArray[num64].allocate($w * $h * $d);
		simplex_fill3d_grid($!ctx,
			$x0, $dx, $w,
			$y0, $dy, $h,
			$z0, $dz, $d,
			$out);
		$out;
	}

	#| Release the native ctx. Idempotent — safe to call multiple
	#| times. After dispose, any sample call throws.
	method dispose(--> Nil) {
		if $!ctx.defined {
			simplex_destroy($!ctx);
			$!ctx = Nil;
		}
	}

	submethod DESTROY() {
		self.dispose;
	}
}

=begin pod

=head1 NAME

Noise::Simplex::Native — Fast NativeCall port of L<Noise::Simplex>.

=head1 SYNOPSIS

=begin code :lang<raku>
use Noise::Simplex::Native;

my $s   = Noise::Simplex::Native::Simplex.new(seed => 42);
my &n2d = $s.create-noise2d;
say n2d(12.3, 9.8);          # → value ≈ [-1, 1]

my &n3d = $s.create-noise3d;
say n3d(1.0, 2.0, 0.5);

# RAII: the native ctx is released automatically when $s and any
# closures derived from it go out of scope. No manual cleanup needed.
=end code

=head1 DESCRIPTION

Noise::Simplex::Native is a drop-in replacement for L<Noise::Simplex>
with the per-sample hot loop implemented in C and called via
NativeCall. The public API matches the pure-Raku original exactly,
plus an additive C<dispose> method for callers that want
deterministic teardown.

The permutation table is built in Raku using the same
L<Math::Random::MT> seeding as the original, then handed to the C
side. This means C<.new(seed => N)> produces an identical permutation
on both modules.

=head1 PERFORMANCE

The pure-Raku original spends nearly all its time in the per-sample
closure: array indexing, six squarings, several multiplies, a couple
of permutation lookups. NativeCall removes the closure overhead and
runs the math in IEEE 754 double directly. On a 65k-sample 2D fill
the speedup over pure Raku is around 15-20× on Apple Silicon; YMMV
across hardware.

The per-sample closures still cross the NativeCall boundary once per
call. For dense regular-grid fills, prefer the bulk-fill methods
below — they pay the boundary cost once and let the C compiler
inline the noise function at C<-O3>, typically another 5-10× on top.

=head1 BULK FILL

For dense regular-grid sampling, two methods produce all samples in
a single NativeCall:

=item C<.fill-noise2d-grid(:$x0!, :$dx!, :$w!, :$y0!, :$dy!, :$h!)>
→ C<CArray[num64]> of length C<$w * $h>. Index C<$j * $w + $i> holds
C<noise2d($x0 + $i * $dx, $y0 + $j * $dy)>.

=item C<.fill-noise3d-grid(:$x0!, :$dx!, :$w!, :$y0!, :$dy!, :$h!, :$z0!, :$dz!, :$d!)>
→ C<CArray[num64]> of length C<$w * $h * $d>. Index
C<($k * $h + $j) * $w + $i> holds
C<noise3d($x0 + $i * $dx, $y0 + $j * $dy, $z0 + $k * $dz)>. Z-major
iteration matches the natural per-z-slice traversal in animation
code.

Output is bit-identical to calling the per-sample closure with the
same coordinates — verified by C<t/08-bulk-fill.t>.

=begin code :lang<raku>
my $s = Noise::Simplex::Native::Simplex.new(seed => 42);
my $field = $s.fill-noise2d-grid(
    :x0(0e0), :dx(1/64e0), :w(512),
    :y0(0e0), :dy(1/64e0), :h(512),
);
# $field[$y * 512 + $x] is the noise sample at ($x/64, $y/64).
=end code

=head1 MEMORY MANAGEMENT

The native ctx is held inside the C<Simplex> object and released by
C<submethod DESTROY> at garbage-collection time. You do not need to
call C<.dispose> — RAII covers the common case.

The closures returned by C<create-noise2d> / C<create-noise3d>
capture C<self>, so the C<Simplex> instance (and its native ctx)
stays alive as long as any closure holds a reference. This is the
key safety property: closures returned to a caller are valid even
if the original C<Simplex> binding goes out of scope.

C<.dispose> exists for callers who want deterministic release (e.g.
to free the ~20 KB ctx eagerly in a long-running batch job). It is
idempotent. Calling any sample closure after C<.dispose> throws.

=head1 DETERMINISM

Output relative to the pure-Raku L<Noise::Simplex>, for the same
seed:

=item B<2D> — bit-identical when inputs are exactly representable in
IEEE 754 double (integers, powers-of-2 fractions, etc.). For inputs
the original keeps in Rat at any intermediate step (e.g. C<-3.3>),
the result may diverge by ≤1 ULP. The native module coerces
C<.Num> at the boundary; the original computes Rat-precision sums
where it can.

=item B<3D> — typically within ULPs, but can diverge by O(0.001) at
simplex-diagonal coordinates. The original 3D pipeline computes in
arbitrary-precision Rat (its C<$f3 = 1/3> and C<$g3 = 1/6> are Rat
literals, and Rat propagates through floor / X0 / x0). At
coordinates where C<x0>, C<y0>, or C<z0> are exactly equal in Rat
(e.g. on the C<x = y> plane), Raku's exact comparison and C's
accumulated-error comparison can pick I<different> simplex corners.
The two outputs are then both valid simplex noise, but not the same
sample. This is fundamental — no compiler flag can fix it.

Across-platform determinism within this module is preserved by
compiling with C<-fno-fast-math> and C<-ffp-contract=off> (see
Build.rakumod), so the compiler may not reorder FP operations or
fuse multiply-adds.

=head1 ENVIRONMENT

=item C<NOISE_SIMPLEX_NATIVE_LIB> — full path to a hand-built
shared library, overriding the bundled one. For custom builds,
system copies, or air-gapped installs.

=head1 SEE ALSO

L<Noise::Simplex> — the original pure-Raku implementation.

=head1 AUTHOR

Matt Doughty

=head1 LICENSE

Artistic-2.0

=end pod
