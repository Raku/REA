unit module Noise::Simplex::Native::FFI;

use NativeCall;

constant $os = $*KERNEL.name.lc;
constant $libname = $os ~~ /darwin/ ?? 'libnoise_simplex_native.dylib' !!
                    $os ~~ /win/    ?? 'libnoise_simplex_native.dll'   !!
                                       'libnoise_simplex_native.so';

#| Resolve the native library path. Precedence:
#|
#|     1. $NOISE_SIMPLEX_NATIVE_LIB — explicit override; full path to
#|        the shared library. Power-user escape hatch for custom
#|        builds, system copies, or air-gapped setups.
#|     2. %?RESOURCES — staged at install time by Build.rakumod from
#|        the vendored src/simplex_native.c. The normal path.
sub _libpath() {
	with %*ENV<NOISE_SIMPLEX_NATIVE_LIB> -> $override {
		return $override if $override.chars && $override.IO.e;
	}
	%?RESOURCES{"lib/$libname"}.IO.Str;
}

#| Opaque handle to the native SimplexCtx struct (see src/simplex_native.c).
class SimplexCtx is repr('CPointer') is export {}

# --- Lifecycle ---

sub simplex_create(CArray[uint8] --> SimplexCtx)
	is native(&_libpath) is export { * }

sub simplex_destroy(SimplexCtx)
	is native(&_libpath) is export { * }

# --- Per-sample sampling ---

sub simplex_noise2d(SimplexCtx, num64, num64 --> num64)
	is native(&_libpath) is export { * }

sub simplex_noise3d(SimplexCtx, num64, num64, num64 --> num64)
	is native(&_libpath) is export { * }

# --- Bulk grid fills ---
#
# `out` is a CArray[num64] of length:
#     2D: w * h
#     3D: w * h * d
# See doc/README.rakudoc for the indexing convention.

sub simplex_fill2d_grid(
	SimplexCtx,
	num64, num64, size_t,
	num64, num64, size_t,
	CArray[num64],
) is native(&_libpath) is export { * }

sub simplex_fill3d_grid(
	SimplexCtx,
	num64, num64, size_t,
	num64, num64, size_t,
	num64, num64, size_t,
	CArray[num64],
) is native(&_libpath) is export { * }
