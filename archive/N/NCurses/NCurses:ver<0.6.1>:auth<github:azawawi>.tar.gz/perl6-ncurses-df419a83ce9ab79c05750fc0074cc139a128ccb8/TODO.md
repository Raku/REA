
#TODO

- `sudo apt install ncurses-examples`

- `/usr/lib/ncurses/examples/fireworkt`

- `/usr/lib/ncurses/examples/gdc`

- `/usr/lib/ncurses/examples/hanoi`

- `/usr/lib/ncurses/examples/lrtest`

- `/usr/lib/ncurses/examples/railroad`

- `/usr/lib/ncurses/examples/rain`

- `/usr/lib/ncurses/examples/tclock`

- `/usr/lib/ncurses/examples/worm`

- `/usr/lib/ncurses/examples/xmas`
