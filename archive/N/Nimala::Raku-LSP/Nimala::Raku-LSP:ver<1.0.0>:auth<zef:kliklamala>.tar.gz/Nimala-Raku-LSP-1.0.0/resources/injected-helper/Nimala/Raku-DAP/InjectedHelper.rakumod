use v6.d;
#| Injected helper module loaded into the debuggee with -MNimala::Raku-DAP::InjectedHelper.
#|
#| Consumers in Nimala::Raku-DAP:
#| - Remote: pins the $!do code handles of _nimala_gist, _nimala_str, _nimala_raku, _nimala_elems for type 36 Invoke.
#| - StopHandler: reads lexicals $ex-name, $ex-msg, and $captured on exception breakpoint stops.
#| - LaunchConfig: scans for '# nimala-break: <uncaught|all>' markers to locate exception breakpoint source lines.
unit module Nimala::Raku-DAP::InjectedHelper;

our sub _nimala_gist(Mu \obj --> Str) is export {
    try {
        return obj.gist;
    }
    return '<gist error>';
}

our sub _nimala_str(Mu \obj --> Str) is export {
    try {
        return obj.Str;
    }
    return '<Str error>';
}

our sub _nimala_raku(Mu \obj --> Str) is export {
    try {
        return obj.raku;
    }
    return '<raku error>';
}

our sub _nimala_elems(Mu \obj --> Int) is export {
    try {
        return obj.elems;
    }
    return -1;
}

our sub _nimala_uncaught_breakpoint(Mu \ex) is export {
    my Mu $captured = ex;
    my Str $ex-name = (try ex.^name) // 'Exception';
    my Str $ex-msg = (try ex.message) // '';
    my Str $ex-bt = (try (ex.defined && (try ex.can('backtrace')) && ex.backtrace.defined) ?? ex.backtrace.Str !! '') // '';
    return $captured; # nimala-break: uncaught
}

our sub _nimala_all_breakpoint(Mu \ex) is export {
    my Mu $captured = ex;
    my Str $ex-name = (try ex.^name) // 'Exception';
    my Str $ex-msg = (try ex.message) // '';
    my Str $ex-bt = (try (ex.defined && (try ex.can('backtrace')) && ex.backtrace.defined) ?? ex.backtrace.Str !! '') // '';
    return $captured; # nimala-break: all
}

our class Exceptions::Nimala {
    method process(Mu \ex) {
        try {
            Nimala::Raku-DAP::InjectedHelper::_nimala_uncaught_breakpoint(ex);
        }
        return True;
    }
}

INIT {
    # Pre-warm JIT and method caches during module load
    try {
        _nimala_gist(42);
        _nimala_gist("prewarm");
        _nimala_gist([1, 2, 3]);
        _nimala_str(42);
        _nimala_raku(42);
        _nimala_elems([1, 2, 3]);
    }
    # A graceful `terminate` sends SIGTERM; exiting normally runs END blocks and flushes output (D-13).
    try {
        signal(SIGTERM).tap({ exit 128 + SIGTERM.Int });
    }
    try {
        Exception.^find_method('throw').wrap(-> Mu $self, |c {
                try {
                    _nimala_all_breakpoint($self);
                }
                callsame;
        });
    }
}
