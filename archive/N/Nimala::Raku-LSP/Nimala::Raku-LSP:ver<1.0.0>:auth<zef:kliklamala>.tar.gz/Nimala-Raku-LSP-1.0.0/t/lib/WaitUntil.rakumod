use v6.d;

unit module WaitUntil;

our sub wait-until(&cond, Real :$timeout = 10, Real :$step = 0.01 --> Bool) is export {
    return True if cond();
    my Instant $deadline = now + $timeout;
    while now < $deadline {
        sleep $step;
        return True if cond();
    }
    return False;
}
