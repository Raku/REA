use v6.d;

unit module HostTiming;

use Nimala::Raku-DAP::MessagePack;

#| Seconds this machine needs to decode a MoarVM-like collection reply of $elements elements.
#| Timing tests bound their measurements by a multiple of it, scaling with host speed.
our sub reference-decode-seconds(Int $elements = 10_000 --> Real) is export {
    my @contents = (^$elements).map({
            %( kind => 'obj', type => 'Scalar', handle => 100_000 + $_, concrete => True, container => True )
    });
    my Blob $reply = encode(%( type => 43, id => 7, contents => @contents ));
    my Instant $t0 = now;
    decode($reply, 0);
    my Real $dur = (now - $t0).Real;
    return $dur > 0.000001 ?? $dur !! 0.000001;
}

#| Seconds this machine needs for an in-memory / channel round trip.
our sub reference-roundtrip-seconds(Int $iterations = 50 --> Real) is export {
    my Channel $req .= new;
    my Channel $resp .= new;
    my $w = start {
        for ^$iterations {
            my $val = $req.receive;
            $resp.send($val);
        }
    };
    my Instant $t0 = now;
    for ^$iterations -> $i {
        $req.send($i);
        my $back = $resp.receive;
    }
    await $w;
    my Real $dur = (now - $t0).Real;
    return $dur > 0.000001 ?? $dur !! 0.000001;
}
