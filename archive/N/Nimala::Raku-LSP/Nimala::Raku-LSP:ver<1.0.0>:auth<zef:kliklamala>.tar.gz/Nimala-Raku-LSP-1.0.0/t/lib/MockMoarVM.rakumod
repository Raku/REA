use v6.d;

#| Lightweight mock MoarVM debug server for transport-level testing (DK-3).
#| Provides handshake, framing, received message recording, and user-supplied handler table.
unit class MockMoarVM;

use Nimala::Raku-DAP::MessagePack;

has Str $.host = '127.0.0.1';
has Int $.major = 1;
has Int $.minor = 0;
has %.handlers;
has &.after-handshake;
has Int $.port;

has @!received;
has Lock $!lock .= new;
has $!listener;
has @!conns;

submethod TWEAK(:$host, :$major, :$minor, :%handlers, :&after-handshake) {
    $!host = $host if $host.defined;
    $!major = $major if $major.defined;
    $!minor = $minor if $minor.defined;
    %!handlers = %handlers if %handlers.defined;
    &!after-handshake = &after-handshake if &after-handshake.defined;

    $!listener = IO::Socket::Async.listen($!host, 0).tap(-> $conn {
            $!lock.protect: { @!conns.push($conn); }
            self!handle-client($conn);
    });
    $!port = (await $!listener.socket-port).Int;
}

method received(--> Array) {
    $!lock.protect: { @!received.Array }
}

method send(%data --> Nil) {
    $!lock.protect: {
        for @!conns -> $c {
            if %data ~~ Blob || %data ~~ Buf {
                try $c.write(%data);
            } else {
                try $c.write(encode(%data));
            }
        }
    }
}

method stop(--> Nil) {
    if $!listener.defined {
        try $!listener.close;
        $!listener = Nil;
    }
    $!lock.protect: {
        for @!conns -> $c {
            try $c.close;
        }
        @!conns = ();
    }
}

submethod DESTROY() {
    self.stop;
}

method !handle-client($conn --> Nil) {
    # Handshake greeting: 20 bytes magic + 2 bytes major + 2 bytes minor
    my Buf $greeting .= new;
    $greeting.append("MOARVM-REMOTE-DEBUG\0".encode('latin-1').list);
    $greeting.push(($!major +> 8) +& 0xFF, $!major +& 0xFF);
    $greeting.push(($!minor +> 8) +& 0xFF, $!minor +& 0xFF);
    $conn.write($greeting);

    my Bool $shaken = False;
    my Buf $in-buf .= new;

    $conn.Supply(:bin).tap(
        -> Blob $chunk {
            $in-buf.append($chunk.list);
            unless $shaken {
                if $in-buf.bytes >= 24 {
                    my Str $client-ok = $in-buf.subbuf(0, 24).decode('latin-1');
                    if $client-ok eq "MOARVM-REMOTE-CLIENT-OK\0" {
                        $shaken = True;
                        $in-buf = Buf.new($in-buf.subbuf(24));
                        my $after = &!after-handshake // %!handlers<after-handshake>;
                        $after($conn) if $after.defined && $after ~~ Callable;
                    } else {
                        $conn.close;
                        return;
                    }
                }
            }

            if $shaken {
                loop {
                    last if $in-buf.bytes == 0;
                    my ($msg, int $consumed) = decode($in-buf);
                    last if $consumed == 0;
                    $in-buf = Buf.new($in-buf.subbuf($consumed));

                    if $msg.defined && $msg ~~ Associative {
                        $!lock.protect: {
                            @!received.push($msg);
                        }
                        self!dispatch-message($msg, $conn);
                    }
                }
            }
        },
        QUIT => -> $err {},
        DONE => -> {}
    );
}

method !dispatch-message(%msg, $conn --> Nil) {
    my Int $type = (%msg<type> // -1).Int;
    my $handler = %!handlers{$type} // %!handlers{$type.Str};
    return unless $handler.defined;

    if $handler ~~ Callable {
        my $res = $handler.count == 1 ?? $handler(%msg) !! $handler(%msg, $conn);
        self!send-reply($res, %msg, $conn);
    } else {
        self!send-reply($handler, %msg, $conn);
    }
}

method !send-reply($reply, %msg, $conn --> Nil) {
    return unless $reply.defined;
    if $reply ~~ Promise {
        $reply.then(-> $p {
                self!send-reply($p.result, %msg, $conn) if $p.status ~~ Kept;
        });
    } elsif $reply ~~ Positional {
        for $reply.list -> $item {
            self!send-reply($item, %msg, $conn);
        }
    } elsif $reply ~~ Blob || $reply ~~ Buf {
        $conn.write($reply);
    } elsif $reply ~~ Associative {
        my %resp = %$reply;
        if %msg<id>.defined && !%resp<id>.defined {
            %resp<id> = %msg<id>;
        }
        $conn.write(encode(%resp));
    }
}
