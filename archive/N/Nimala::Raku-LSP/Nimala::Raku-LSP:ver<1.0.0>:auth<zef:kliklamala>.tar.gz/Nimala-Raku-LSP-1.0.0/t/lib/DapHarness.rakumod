use v6.d;

#| Test harness coordinating MockMoarVM, Protocol, Translate, and StopHandler.
#| Replaces hand-wired mock setups across DAP tests (D5).
unit class DapHarness;

use MockMoarVM;
use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Translate;
use Nimala::Raku-DAP::BreakpointRegistry;
use Nimala::Raku-DAP::StopHandler;

has MockMoarVM $.mock;
has Nimala::Raku-DAP::Protocol $.protocol;
has Nimala::Raku-DAP::Translate $.translate;
has Nimala::Raku-DAP::BreakpointRegistry $.registry;
has Nimala::Raku-DAP::StopHandler $.stop-handler;
has @!responses;
has @!events;

submethod TWEAK(:%handlers, :$registry, Str :$program-file = '/tmp/prog.raku') {
    my %default-handlers = (
        5 => -> %r { %( type => 2, id => %r<id> ) },   # Suspend All
        6 => -> %r { %( type => 2, id => %r<id> ) },   # Resume All
    );
    my %merged = (%default-handlers, %handlers).hash;
    $!mock = MockMoarVM.new(handlers => %merged);
    $!protocol = Nimala::Raku-DAP::Protocol.new;
    await $!protocol.connect('127.0.0.1', $!mock.port, :timeout(10));
    $!registry = $registry // Nimala::Raku-DAP::BreakpointRegistry.new;
    $!translate = Nimala::Raku-DAP::Translate.new(
        protocol => $!protocol,
        registry => $!registry,
        send-response => -> %req, %body, :$success = True, :$message = '' {
            @!responses.push(%( command => %req<command>, :$success, :$message, :%body ));
        },
        send-event => -> Str $ev, %body {
            @!events.push(%( :$ev, :%body ));
        },
        :$program-file,
    );
    $!translate.connected;
    $!stop-handler = $!translate.stop-handler;
}

method responses(--> List) {
    @!responses.List
}

method events(--> List) {
    @!events.List
}

method handles {
    $!translate.handles
}

method threads {
    $!translate.threads
}

method thread-state(Int $id) {
    $!translate.thread-state($id)
}

method remote {
    $!translate.remote
}

proto method request(Str $, |) {*}
multi method request(Str $command, %arguments --> Hash) {
    my Int $before = @!responses.elems;
    await $!translate.dispatch-request(%( seq => 1, type => 'request', :$command, :%arguments ));
    my Instant $deadline = now + 10;
    sleep 0.01 while @!responses.elems == $before && now < $deadline;
    @!responses.elems > $before ?? @!responses.tail !! %();
}
multi method request(Str $command, *%arguments --> Hash) {
    self.request($command, %arguments);
}

method stop-event(%event --> Promise) {
    $!stop-handler.handle-stop(%event);
}

method stop(--> Nil) {
    try $!protocol.close if $!protocol.defined;
    try $!mock.stop if $!mock.defined;
}
