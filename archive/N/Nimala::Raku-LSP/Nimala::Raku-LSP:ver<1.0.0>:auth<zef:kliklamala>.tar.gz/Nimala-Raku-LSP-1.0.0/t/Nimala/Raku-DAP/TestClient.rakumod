use JSON::Fast;
use Nimala::Raku-DAP::MessagePack;

unit class Nimala::Raku-DAP::TestClient;
has Proc::Async $!proc;
has Supplier $!stdin;
has Int $!seq = 1;
has @!messages;
has Int @!seq-log;
has Supplier $!msg-supplier .= new;
has Str $!parse-error;
has Lock $!lock .= new;
has Promise $!exited;
has Str $.repo;
has Bool $.verbose is rw = False;
#| Opt-in: announce supportsRunInTerminalRequest and answer runInTerminal by spawning the command like a terminal.
has Bool $.run-in-terminal = False;
#| When defined, runInTerminal is refused with this message instead.
has Str $.refuse-terminal;
has Proc::Async $!terminal;
has Promise $!terminal-exited;
has Str $!terminal-out = '';

#| Starts the adapter. :@cmd replaces the default command line, :%env and :$cwd are passed to the process.
method start(
    Str $bin = "bin/nimala-raku-dap", :@cmd, :%env, Str :$cwd, Str :$repo, Bool :$verbose
    --> Nimala::Raku-DAP::TestClient
) {
    $!repo = $repo if $repo.defined;
    $!verbose = $verbose if $verbose.defined;
    my Str $effective-repo = $!repo // $cwd // $*CWD.absolute;
    my Str $dap-bin = (%*ENV<DAP_BIN> // ($bin.starts-with('/') ?? $bin !! "$effective-repo/$bin"));
    my @run = @cmd || ($*EXECUTABLE.absolute, "-I$effective-repo/lib", $dap-bin);
    $!proc = Proc::Async.new(|@run, :w);

    my Buf $buf .= new;
    my Int $scan-offset = 0;
    $!proc.stdout(:bin).tap: -> $blob {
        $buf.append($blob);
        loop {
            my Int $delimiter-pos = -1;
            my Int $delimiter-len = 0;
            if $buf.elems >= 4 {
                my Int $start = max(0, $scan-offset - 3);
                for $start .. ($buf.elems - 4) -> $i {
                    if $buf[$i] == 13 && $buf[$i+1] == 10 && $buf[$i+2] == 13 && $buf[$i+3] == 10 {
                        $delimiter-pos = $i;
                        $delimiter-len = 4;
                        last;
                    }
                }
            }
            if $delimiter-pos == -1 && $buf.elems >= 2 {
                my Int $start = max(0, $scan-offset - 1);
                for $start .. ($buf.elems - 2) -> $i {
                    if $buf[$i] == 10 && $buf[$i+1] == 10 {
                        $delimiter-pos = $i;
                        $delimiter-len = 2;
                        last;
                    }
                }
            }

            if $delimiter-pos == -1 {
                $scan-offset = max(0, $buf.elems);
                last;
            }

            my Str $headers = $buf.subbuf(0, $delimiter-pos).decode('latin-1');
            my Int $len = 0;
            if $headers ~~ / :i 'Content-Length:' \s* (\d+) / {
                $len = +$0;
            } else {
                my Str $err = "Undecodable DAP frame: Missing Content-Length header; header starts {$headers.substr(0, min(80, $headers.chars))}";
                $!lock.protect: {
                    $!parse-error = $err;
                    $!msg-supplier.emit(Nil);
                }
                last;
            }

            my Int $total-needed = $delimiter-pos + $delimiter-len + $len;
            if $buf.elems < $total-needed {
                $scan-offset = $delimiter-pos;
                last;
            }

            my Buf $payload = $buf.subbuf($delimiter-pos + $delimiter-len, $len);
            $buf = $buf.subbuf($total-needed);
            $scan-offset = 0;

            my Str $str;
            my Bool $decoded-ok = True;
            try {
                $str = $payload.decode('utf-8');
                CATCH {
                    default {
                        $decoded-ok = False;
                        my Str $err = "Undecodable DAP frame: {$_.message}; payload starts {$payload.subbuf(0, min(80, $payload.bytes)).decode('latin-1')}";
                        $!lock.protect: {
                            $!parse-error = $err;
                            $!msg-supplier.emit(Nil);
                        }
                    }
                }
            }
            if $decoded-ok && $str.defined {
                try {
                    my %msg = from-json($str);
                    %msg<_t> = now;
                    if (%msg<type> // '') eq 'request' && (%msg<command> // '') eq 'runInTerminal' {
                        self!answer-run-in-terminal(%msg);
                    }
                    $!lock.protect: {
                        @!seq-log.push((%msg<seq> // -1).Int);
                        @!messages.push(%msg);
                        $!msg-supplier.emit(%msg);
                    }
                    CATCH {
                        default {
                            my Str $err = "Undecodable DAP frame: {$_.message}; payload starts {$str.substr(0, min(80, $str.chars))}";
                            $!lock.protect: {
                                $!parse-error = $err;
                                $!msg-supplier.emit(Nil);
                            }
                        }
                    }
                }
            }
        }
    };
    $!proc.stderr.tap: -> $err { note "PROC STDERR: $err" if $!verbose; };

    my %opts;
    my %proc-env = (%env || %*ENV).hash;
    # The test runner prepends relative entries (`prove6 -l`: `lib`), which would resolve against the adapter's
    # cwd. Drop only those: removing absolute ones such as `inst#/usr/local/share/rakulib` makes the adapter
    # resolve other dependency versions than the test process, and both then fight over `lib/.precomp`.
    unless %env {
        for <RAKULIB PERL6LIB> -> Str $var {
            next unless %proc-env{$var}:exists;
            my Str @kept = %proc-env{$var}.split(',').grep({ .split('#').tail.IO.is-absolute });
            if @kept { %proc-env{$var} = @kept.join(',') } else { %proc-env{$var}:delete }
        }
    }
    %opts<ENV> = %proc-env;
    my $target-cwd = $cwd // $!repo;
    %opts<cwd> = $target-cwd if $target-cwd.defined;
    $!exited = $!proc.start(|%opts);
    return self;
}

#| Acts as the client's terminal: spawns `arguments.args` with `cwd` and `env` (a null value removes a variable),
#| keeps its stdin open for `terminal-write`, and answers with the launcher's processId.
method !answer-run-in-terminal(%req --> Nil) {
    my %resp = type => 'response', request_seq => %req<seq>, command => 'runInTerminal', seq => $!seq++;
    if $!refuse-terminal.defined || !$!run-in-terminal {
        %resp<success> = False;
        %resp<message> = $!refuse-terminal // 'runInTerminal not supported';
    } else {
        my %args = %req<arguments>;
        my %env = %*ENV;
        for (%args<env> // {}).kv -> $k, $v { if $v.defined { %env{$k} = $v } else { %env{$k}:delete } }
        my $term = Proc::Async.new(|%args<args>, :w);
        $term.stdout.tap(-> $s { $!lock.protect: { $!terminal-out ~= $s } });
        $term.stderr.tap(-> $s { note "TERMINAL STDERR: $s" if $!verbose });
        $!terminal-exited = $term.start(ENV => %env, cwd => (%args<cwd> // $*CWD.absolute));
        $!terminal = $term;
        %resp<success> = True;
        %resp<body> = %( processId => (await $term.pid) );
    }
    my $json = to-json(%resp);
    await $!proc.write("Content-Length: {$json.encode('utf-8').bytes}\r\n\r\n$json".encode('utf-8'));
}

#| Writes to the terminal debuggee's stdin.
method terminal-write(Str $text --> Nil) { await $!terminal.write($text.encode('utf-8')) }

#| Everything the terminal debuggee wrote to stdout so far.
method terminal-output(--> Str) { $!lock.protect: { $!terminal-out } }

#| Kept with the terminal process result once it ends; undefined when no terminal was started.
method terminal-exited(--> Promise) { $!terminal-exited }

method send-request(Str $command, %arguments = {}) {
    my $id = $!seq++;
    my %msg = (
        type => 'request',
        seq => $id,
        command => $command,
        arguments => %arguments
    );
    my $json = to-json(%msg);
    my $payload = "Content-Length: {$json.encode('utf-8').bytes}\r\n\r\n$json";
    await $!proc.write($payload.encode('utf-8'));
    return $id;
}

method send-raw(Str $payload) {
    await $!proc.write($payload.encode('utf-8'));
}

#| Sends a request and awaits its correlated response by request_seq (D7).
method request(Str $cmd, %args = {}, Real :$timeout = 20 --> Hash) {
    my Int $seq = self.send-request($cmd, %args);
    my $found = self.wait-for(-> %m {
            (%m<type> // '') eq 'response' && (%m<request_seq> // -1).Int == $seq
        }, $timeout);
    return ($found.defined && $found ~~ Associative) ?? %$found !! %();
}

method wait-for(Callable $cond, Real $timeout = 20) {
    my $p = Promise.new;
    my $found;
    my $tap;

    $tap = $!msg-supplier.Supply.tap: -> $ {
        $!lock.protect: {
            if $!parse-error.defined {
                $p.break($!parse-error) if $p.status == Planned;
            } else {
                for ^@!messages.elems -> $i {
                    if $cond(@!messages[$i]) {
                        my $msg = @!messages.splice($i, 1)[0];
                        $p.keep($msg) if $p.status == Planned;
                        last;
                    }
                }
            }
        }
    };

    $!lock.protect: {
        if $!parse-error.defined {
            $p.break($!parse-error) if $p.status == Planned;
        } else {
            for ^@!messages.elems -> $i {
                if $cond(@!messages[$i]) {
                    $found = @!messages.splice($i, 1)[0];
                    $p.keep($found) if $p.status == Planned;
                    last;
                }
            }
        }
    }

    if $found.defined {
        $tap.close if $tap.defined;
        return $found;
    }

    my $timer = Promise.in($timeout).then: {
        $!lock.protect: {
            if $p.status == Planned {
                if $!parse-error.defined {
                    $p.break($!parse-error);
                } else {
                    $p.break("Timeout waiting for message");
                }
            }
        }
    };

    await Promise.anyof($p, $timer);
    $tap.close if $tap.defined;
    return await $p;
}

#| Wait until predicate block returns truthy, polling with small sleep intervals
method wait-until(Callable $predicate, Real :$timeout = 5.0, Real :$step = 0.02 --> Bool) {
    wait-until($predicate, :$timeout, :$step);
}

our sub wait-until(Callable $predicate, Real :$timeout = 5.0, Real :$step = 0.02 --> Bool) is export {
    my $deadline = now + $timeout;
    while now <= $deadline {
        my $res = try { $predicate() };
        return True if ?$res;
        sleep $step;
    }
    return ?(try { $predicate() });
}

method get-messages() {
    my @msgs;
    $!lock.protect: { @msgs = @!messages.clone; }
    return @msgs;
}

#| The `seq` of every message read from the adapter, in arrival order.
method seq-log(--> List) {
    $!lock.protect: { @!seq-log.List };
}

#| Kept when the adapter process has ended.
method exited(--> Promise) { $!exited }

method proc(--> Proc::Async) { $!proc; }
method close-stdin() { try $!proc.close-stdin; }
method kill($signal = SIGTERM) { try $!proc.kill($signal); }

method stop(Real $timeout = 5 --> Nil) {
    LEAVE { try $!terminal.kill(SIGKILL) if $!terminal.defined && $!terminal-exited.status ~~ Planned }
    if $!proc.defined && (!$!exited.defined || $!exited.status != Kept) {
        try self.send-request('disconnect');
    }
    if $!exited.defined {
        try await Promise.anyof($!exited, Promise.in($timeout));
        if $!exited.status != Kept {
            try $!proc.kill(SIGKILL);
            try await $!exited;
        }
    }
}

#| Aliases / conveniences for benchmark and smoke tools (D7)
method send(Str $command, %arguments = {} --> Int) {
    self.send-request($command, %arguments);
}

method req(Str $command, %arguments = {}, Real $timeout = 25 --> Hash) {
    self.request($command, %arguments, :$timeout);
}

method resp(Int $id, Real $timeout = 25) {
    self.wait-for(-> %m { (%m<type> // '') eq 'response' && (%m<request_seq> // -1).Int == $id }, $timeout);
}

method event(Str $event, Real $timeout = 25) {
    self.wait-for(-> %m { (%m<type> // '') eq 'event' && (%m<event> // '') eq $event }, $timeout);
}

method wait(Callable $cond, Real $timeout = 25) {
    self.wait-for($cond, $timeout);
}

method boot(Str $program, %bps = {}, *%launch) {
    self.req('initialize', %( clientID => 'bench', linesStartAt1 => True, columnsStartAt1 => True,
            supportsRunInTerminalRequest => $!run-in-terminal ));
    my %r;
    for %bps.kv -> Str $file, @lines {
        %r{$file} = self.req('setBreakpoints', %(
                source => %( path => $file ),
                breakpoints => [ @lines.map({ $_ ~~ Associative ?? $_ !! %( line => $_ ) }) ]
        ));
    }
    my Instant $t0 = now;
    # The debuggee runs with the test's own Raku unless the test names one (T-9).
    my %args = %launch;
    %args<rakuPath> = $*EXECUTABLE.absolute unless (%args<rakuPath>:exists) || (%args<executable>:exists);
    my Int $lid = self.send('launch', %( :$program, |%args ));
    self.req('configurationDone');
    my $l = self.resp($lid, 30);
    return %( launch => $l, bps => %r, t0 => $t0 );
}
