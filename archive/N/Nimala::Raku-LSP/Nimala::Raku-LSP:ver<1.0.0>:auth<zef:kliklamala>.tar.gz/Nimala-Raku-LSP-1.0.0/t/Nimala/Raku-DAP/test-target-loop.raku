my $count = 0;
while $count < 100 {
    sleep 0.1;
    $count++;
}
say "Finished loop: $count";
