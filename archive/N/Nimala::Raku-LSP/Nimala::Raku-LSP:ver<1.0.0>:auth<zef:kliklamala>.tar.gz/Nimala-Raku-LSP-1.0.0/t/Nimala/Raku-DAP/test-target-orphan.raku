my $pid-file = @*ARGS[0];
if $pid-file {
    $pid-file.IO.spurt($*PID ~ "\n");
}
loop {
    sleep 0.1;
}
