my $c = Channel.new;
my $p = start {
    my $sub-var = 42;
    $c.send($sub-var);
    sleep 0.5;
};
my $val = $c.receive;
say "Main received $val";
await $p;
