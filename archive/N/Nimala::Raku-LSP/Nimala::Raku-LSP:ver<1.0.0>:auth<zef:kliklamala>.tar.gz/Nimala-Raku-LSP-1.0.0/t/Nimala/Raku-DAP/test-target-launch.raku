my $a = 1;
my $b = 2;
say "Target output: $a + $b = " ~ ($a + $b);
