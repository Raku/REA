<p align="center"> <img src="https://gitlab.com/nimala/raku/raku-lsp/-/raw/main/Raku-LSP-192.jpeg" alt="Nimala Logo" width="128" /> </p>

NAME
====

Nimala::Raku-LSP - Complete Raku Language Server Protocol (LSP 3.18) & Debug Adapter Protocol (DAP)

DESCRIPTION
===========

Nimala is a full-featured Language Server Protocol (LSP 3.18) and Debug Adapter Protocol (DAP) implementation for the Raku programming language, written entirely in Raku. It provides advanced IDE intelligence, refactoring capabilities, and integrated debugging to any LSP-compatible editor (such as VS Code, Neovim, Helix, or Emacs).

Key Highlights
--------------

  * **100% Coverage of All Useful LSP 3.18 Features**: 72 LSP methods and 20 DAP methods fully implemented and tested.

  * **Multi-Tiered AST & Deep Type Inference**: Combines native NQP compiler AST parsing, resilient fallback grammars, and dynamic MRO / generic type tracking.

  * **Multi-Root Workspace & Reactive Progress Engine**: Dynamic folder indexing, pruning, and bidirectional `$/progress` reporting with RAII scopes.

  * **High Performance & Low Latency**: Persistent SQLite index caching (`.nimala/symbols.db`), prefix-based symbol search, and non-blocking asynchronous event streams (`Supply`, `Proc::Async`, `Lock`).

LSP 3.18 Implementation Matrix
------------------------------

<table class="pod-table">
<thead><tr>
<th>Method</th> <th>Specification</th> <th>Status</th>
</tr></thead>
<tbody>
<tr> <td>B&lt;1. Lifecycle &amp; General&gt;</td> <td>|</td> <td></td> </tr> <tr> <td>C&lt;initialize&gt;</td> <td>L&lt;initialize|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#initialize&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;initialized&gt;</td> <td>L&lt;initialized|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#initialized&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;shutdown&gt;</td> <td>L&lt;shutdown|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#shutdown&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;exit&gt;</td> <td>L&lt;exit|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#exit&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;$/cancelRequest&gt;</td> <td>L&lt;cancelRequest|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#cancelRequest&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;$/progress&gt;</td> <td>L&lt;progress|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#progress&gt;</td> <td>[x] done</td> </tr> <tr> <td>B&lt;2. Document Synchronization&gt;</td> <td>|</td> <td></td> </tr> <tr> <td>C&lt;textDocument/didOpen&gt;</td> <td>L&lt;didOpen|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didOpen&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/didChange&gt;</td> <td>L&lt;didChange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didChange&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/willSave&gt;</td> <td>L&lt;willSave|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_willSave&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/didSave&gt;</td> <td>L&lt;didSave|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didSave&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/didClose&gt;</td> <td>L&lt;didClose|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didClose&gt;</td> <td>[x] done</td> </tr> <tr> <td>B&lt;3. Diagnostics &amp; Code Intelligence&gt;</td> <td>|</td> <td></td> </tr> <tr> <td>C&lt;textDocument/publishDiagnostics&gt;</td> <td>L&lt;publishDiagnostics|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_publishDiagnostics&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/diagnostic&gt;</td> <td>L&lt;pullDiagnostics|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_diagnostic&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/diagnostic&gt;</td> <td>L&lt;workspacePullDiagnostics|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_diagnostic&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/completion&gt;</td> <td>L&lt;completion|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_completion&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;completionItem/resolve&gt;</td> <td>L&lt;completionItem_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#completionItem_resolve&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/inlineCompletion&gt;</td> <td>L&lt;inlineCompletion|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineCompletion&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/hover&gt;</td> <td>L&lt;hover|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_hover&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/signatureHelp&gt;</td> <td>L&lt;signatureHelp|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_signatureHelp&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/definition&gt;</td> <td>L&lt;definition|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_definition&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/declaration&gt;</td> <td>L&lt;declaration|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_declaration&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/typeDefinition&gt;</td> <td>L&lt;typeDefinition|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_typeDefinition&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/implementation&gt;</td> <td>L&lt;implementation|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_implementation&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/references&gt;</td> <td>L&lt;references|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_references&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/documentHighlight&gt;</td> <td>L&lt;documentHighlight|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentHighlight&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/documentSymbol&gt;</td> <td>L&lt;documentSymbol|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentSymbol&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/codeAction&gt;</td> <td>L&lt;codeAction|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_codeAction&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;codeAction/resolve&gt;</td> <td>L&lt;codeAction_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#codeAction_resolve&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/codeLens&gt;</td> <td>L&lt;codeLens|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_codeLens&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;codeLens/resolve&gt;</td> <td>L&lt;codeLens_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#codeLens_resolve&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/documentLink&gt;</td> <td>L&lt;documentLink|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentLink&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;documentLink/resolve&gt;</td> <td>L&lt;documentLink_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#documentLink_resolve&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/formatting&gt;</td> <td>L&lt;formatting|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_formatting&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/rangeFormatting&gt;</td> <td>L&lt;rangeFormatting|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_rangeFormatting&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/onTypeFormatting&gt;</td> <td>L&lt;onTypeFormatting|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_onTypeFormatting&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/rename&gt;</td> <td>L&lt;rename|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_rename&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/prepareRename&gt;</td> <td>L&lt;prepareRename|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_prepareRename&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/foldingRange&gt;</td> <td>L&lt;foldingRange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_foldingRange&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/selectionRange&gt;</td> <td>L&lt;selectionRange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_selectionRange&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/inlayHint&gt;</td> <td>L&lt;inlayHint|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_inlayHint&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;inlayHint/resolve&gt;</td> <td>L&lt;inlayHint_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#inlayHint_resolve&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/inlineValue&gt;</td> <td>L&lt;inlineValue|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_inlineValue&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/linkedEditingRange&gt;</td> <td>L&lt;linkedEditingRange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_linkedEditingRange&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/semanticTokens/full&gt;</td> <td>L&lt;semanticTokens|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_semanticTokens&gt;</td> <td>[x] done</td> </tr> <tr> <td>B&lt;4. Hierarchies&gt;</td> <td>|</td> <td></td> </tr> <tr> <td>C&lt;textDocument/prepareTypeHierarchy&gt;</td> <td>L&lt;prepareTypeHierarchy|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_prepareTypeHierarchy&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;typeHierarchy/supertypes&gt;</td> <td>L&lt;supertypes|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#typeHierarchy_supertypes&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;typeHierarchy/subtypes&gt;</td> <td>L&lt;subtypes|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#typeHierarchy_subtypes&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;textDocument/prepareCallHierarchy&gt;</td> <td>L&lt;prepareCallHierarchy|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_prepareCallHierarchy&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;callHierarchy/incomingCalls&gt;</td> <td>L&lt;incomingCalls|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#callHierarchy_incomingCalls&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;callHierarchy/outgoingCalls&gt;</td> <td>L&lt;outgoingCalls|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#callHierarchy_outgoingCalls&gt;</td> <td>[x] done</td> </tr> <tr> <td>B&lt;5. Workspace &amp; Refreshes&gt;</td> <td>|</td> <td></td> </tr> <tr> <td>C&lt;workspace/symbol&gt;</td> <td>L&lt;symbol|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_symbol&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/executeCommand&gt;</td> <td>L&lt;executeCommand|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_executeCommand&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/didChangeWatchedFiles&gt;</td> <td>L&lt;didChangeWatchedFiles|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_didChangeWatchedFiles&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/workspaceFolders&gt;</td> <td>L&lt;workspaceFolders|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_workspaceFolders&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/didChangeWorkspaceFolders&gt;</td> <td>L&lt;didChangeWorkspaceFolders|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_didChangeWorkspaceFolders&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/didChangeConfiguration&gt;</td> <td>L&lt;didChangeConfiguration|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_didChangeConfiguration&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/willRenameFiles&gt;</td> <td>L&lt;willRenameFiles|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_willRenameFiles&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/applyEdit&gt;</td> <td>L&lt;applyEdit|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_applyEdit&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/codeLens/refresh&gt;</td> <td>L&lt;codeLens_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_codeLens_refresh&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/inlayHint/refresh&gt;</td> <td>L&lt;inlayHint_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_inlayHint_refresh&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/semanticTokens/refresh&gt;</td> <td>L&lt;semanticTokens_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_semanticTokens_refresh&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/foldingRange/refresh&gt;</td> <td>L&lt;foldingRange_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_foldingRange_refresh&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/diagnostic/refresh&gt;</td> <td>L&lt;diagnostic_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_diagnostic_refresh&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;workspace/inlineValue/refresh&gt;</td> <td>L&lt;inlineValue_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_inlineValue_refresh&gt;</td> <td>[x] done</td> </tr> <tr> <td>B&lt;6. Window &amp; Client Interaction&gt;</td> <td>|</td> <td></td> </tr> <tr> <td>C&lt;window/showMessage&gt;</td> <td>L&lt;showMessage|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_showMessage&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;window/showMessageRequest&gt;</td> <td>L&lt;showMessageRequest|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_showMessageRequest&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;window/logMessage&gt;</td> <td>L&lt;logMessage|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_logMessage&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;window/showDocument&gt;</td> <td>L&lt;showDocument|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_showDocument&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;window/workDoneProgress/create&gt;</td> <td>L&lt;workDoneProgress/create|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_workDoneProgress_create&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;window/workDoneProgress/cancel&gt;</td> <td>L&lt;workDoneProgress/cancel|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_workDoneProgress_cancel&gt;</td> <td>[x] done</td> </tr> <tr> <td>C&lt;client/registerCapability&gt;</td> <td>L&lt;registerCapability|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#client_registerCapability&gt;</td> <td>[x] done</td> </tr>
</tbody>
</table>

Programmatic Usage
------------------

The server binary dispatches JSON-RPC through its own `Nimala::Raku-LSP::Dispatcher` (method whitelist, cancellation, concurrent requests). For embedding, the handler can also be driven by `JSON::RPC::Server`, as the test suite does, to analyze Raku code or build custom clients:

```raku
use Nimala::Raku-LSP::Handler;
use JSON::RPC::Server;

# Initialize the LSP Handler
my $handler = Nimala::Raku-LSP::Handler.new;

# Wrap it in a JSON-RPC Server
my $server = JSON::RPC::Server.new(application => $handler);

# Simulate a JSON-RPC Request (e.g., from a client)
my $request = q:to/END/;
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "processId": null,
    "rootUri": null,
    "capabilities": {}
  }
}
END

# Process the request and get the JSON-RPC response
my $response = $server.handler($request);
say $response;
```

Debug Adapter Protocol (DAP) Architecture
-----------------------------------------

Nimala includes a Debug Adapter Protocol (DAP) server (`bin/nimala-raku-dap`). The debugger is built directly on MoarVM's native remote debugging protocol, communicating with the debuggee over loopback TCP using MessagePack framing.

  * **Native VM-Level Execution**: The debuggee runs as standard `raku --debug-port=<port> --debug-suspend <program>`, executing standard precompiled bytecode. This eliminates the precompilation slot mismatches, slow first launches, and compiler `when` statement crashes of earlier statement-hook implementations.

  * **Pure-Raku MessagePack Framing**: Communication uses a fast, dependency-free MessagePack codec and protocol client with monotonic request/response correlation and event dispatch.

  * **Monotonic Handle Management**: Context and object handles allocated during stops are tracked in a lifecycle registry and cleanly released in batches upon resume or disconnect.

  * **Bounded Expressions & Safe Inspection**: Expression evaluation, conditional breakpoints, and logpoints use a bounded expression grammar (variables, attribute/key/index access, comparisons against literals). Arbitrary method calls and mutations are refused; only the whitelisted helpers `.gist`, `.Str`, `.raku` and `.elems` run in the debuggee, at most one per stop.

  * **Smart Stepping**: Configurable smart stepping (`into`, `over`, `disable`) automatically filters out internal compiler, runtime, and NQP frames so stepping stays focused on user code.

For full architectural details, see docs/DEBUG.md and docs/DEBUG-MOARVM.md.

Installation & Dependencies
---------------------------

Nimala requires a working Raku installation (Rakudo 2026.09 recommended) and the `sqlite3` shared library for index persistence. Only Rakudo 2026.09 is tested. Rakudo 2024.07 runs with limitations: the debugger can abort with a MoarVM panic, and the RakuAST-based analysis ignores signature parameters and fails on files with `BEGIN` blocks, so the built-in parser fills in.

### Dependencies

  * **DBIish** & **DBDish::SQLite**: Database independent interface and SQLite driver for persistent, transactional symbol indexing (`.nimala/symbols.db`).

  * **JSON::Fast**: High-performance JSON parser and serializer.

### Install via Zef

```sh
# Install all dependencies and Nimala LSP/DAP binaries
zef install Nimala::Raku-LSP
```

`zef` puts the `nimala-raku-lsp` and `nimala-raku-dap` scripts into the `bin/` directory of the repository it installs to. Without root rights that is usually `~/.raku/bin`, which must be in `PATH` (for example `export PATH="$HOME/.raku/bin:$PATH"` in `~/.bashrc`). Otherwise editors cannot find the server.

Security Considerations
-----------------------

Like standard Raku tooling, the language server executes compile-time code when inspecting documents:

  * **Compile-Time Execution**: Background syntax checking (`raku -c`) and native AST parsing execute `BEGIN`, `CHECK`, and `INIT` blocks as well as compile-time side effects of imported modules (`use`).

  * **Doc Preview Evaluation**: Rendering RakuDoc to HTML (`raku --doc=HTML`) also evaluates compile-time blocks in opened files.

  * **Untrusted Code**: Never open untrusted Raku files or untrusted workspaces without inspecting them first. Always use isolated environments (containers or sandboxes) when reviewing unknown code.

License Artistic-2.0
--------------------

### sub run-tcp-server

```raku
sub run-tcp-server(
    Str :$host = "127.0.0.1",
    Int :$port = 5007,
    Bool :$single-session = Bool::False,
    Promise :$stop-promise = Code.new
) returns Nil
```

Re-export run-tcp-server from Transport::Socket

### sub run-server

```raku
sub run-server(
    IO::Handle :$in = Code.new,
    IO::Handle :$out = Code.new,
    Nimala::Raku-LSP::Handler :$handler = Code.new,
    :$supply = Code.new
) returns Int
```

Start the LSP server loop.

