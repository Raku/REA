use v6.d;
#| file:// URI and path conversion shared by the LSP server and the debug adapter.
unit module Nimala::URI;

#| Percent-decodes an RFC 3986 string into UTF-8.
our sub percent-decode(Str $str --> Str) is export {
    return $str unless $str.contains('%');
    my Buf[uint8] $buf .= new;
    my Blob $bytes = $str.encode('utf-8');
    my Int $i = 0;
    my Int $n = $bytes.elems;
    while $i < $n {
        if $bytes[$i] == 0x25 && $i + 2 < $n { # '%'
            my Str $hex = $bytes.subbuf($i + 1, 2).decode('ascii');
            if $hex ~~ /^ <[0..9A..Fa..f]> ** 2 $/ {
                $buf.push(:16($hex));
                $i += 3;
                next;
            }
        }
        $buf.push($bytes[$i]);
        $i++;
    }
    return try { $buf.decode('utf-8') } // $str;
}

#| Percent-encodes an RFC 3986 path string.
our sub percent-encode(Str $str --> Str) is export {
    my Str $res = "";
    for $str.comb -> Str $ch {
        if $ch ~~ /<[a..zA..Z0..9_\.\-\~\/:\@\+\(\)]>/ {
            $res ~= $ch;
        } else {
            for $ch.encode('utf-8').list -> uint8 $b {
                $res ~= sprintf("%%%02X", $b);
            }
        }
    }
    return $res;
}

#| Converts a file:// URI to a local filesystem IO::Path with percent-decoding.
our sub uri-to-path(Str $uri --> IO::Path) is export {
    my Str $raw = $uri;
    if $raw.starts-with('file://localhost/') {
        $raw = $raw.substr(16);
    } elsif $raw.starts-with('file:///') {
        $raw = $raw.substr(7);
    } elsif $raw.starts-with('file://') {
        $raw = $raw.substr(7);
    }
    my Str $decoded = percent-decode($raw);
    if ($*DISTRO.is-win || $decoded ~~ m{^ '/'? <[a..zA..Z]> ':' }) && $decoded ~~ m{^ '/'? (<[a..zA..Z]>) ':' (.*) } {
        $decoded = $0.lc ~ ':' ~ $1;
    }
    return $decoded.IO;
}

#| Converts an IO::Path or filesystem path string to a file:// URI with percent-encoding.
our sub path-to-uri(Any $path --> Str) is export {
    my Str $str;
    my Str $raw = $path ~~ Str ?? $path !! $path.Str;
    my Bool $is-win = ?($*DISTRO.is-win || ($raw ~~ m{^ <[a..zA..Z]> \: [ '/' | '\\' ] }) || $raw.starts-with('\\\\'));
    if $raw ~~ m{^ (<[a..zA..Z]>) \: [ '/' | '\\' ] (.*) } {
        $str = $0.lc ~ ':/' ~ $1;
    } elsif $raw.starts-with('\\\\') || $raw.starts-with('//') {
        $str = $raw;
    } else {
        my IO::Path $io = $path ~~ IO::Path ?? $path !! $raw.IO;
        $str = $io.is-absolute ?? $io.absolute !! $io.resolve.absolute;
        if $str ~~ m{^ (<[a..zA..Z]>) \: (.*) } {
            $str = $0.lc ~ ':' ~ $1;
        }
    }
    if $is-win {
        $str = $str.subst(/\\/, '/', :g);
    }
    my Str $encoded = percent-encode($str);
    if $encoded.starts-with('/') {
        return "file://" ~ $encoded;
    } else {
        return "file:///" ~ $encoded;
    }
}


#| Canonicalizes a file:// URI to match the standard server representation.
our sub canonicalize-uri(Str $uri --> Str) is export {
    return $uri unless $uri.defined && $uri ~~ m:i/^ 'file:' /;
    my Str $raw = $uri;
    $raw = 'file:' ~ $raw.substr(5);
    if $raw.starts-with('file://localhost/') {
        $raw = 'file://' ~ $raw.substr(16);
    } elsif $raw.starts-with('file://') && !$raw.starts-with('file:///') {
        $raw = 'file:///' ~ $raw.substr(7);
    }
    my Str $path = $raw.substr(7);
    if $path ~~ m{^ '/'? (<[a..zA..Z]>) ':' (.*) } {
        $path = $0.lc ~ ':' ~ $1;
    }
    my Str $decoded = percent-decode($path);
    my Str $encoded = percent-encode($decoded);
    return $encoded.starts-with('/') ?? ('file://' ~ $encoded) !! ('file:///' ~ $encoded);
}

#| Resolves a Raku module name (e.g. Foo::Bar) to an IO::Path relative to the workspace root.
our sub resolve-module-file(Str $module, IO::Path :$root! --> IO::Path) is export {
    my Str @parts = $module.split('::');
    my IO::Path $dir = $root.child('lib');
    for @parts[0..^*-1] -> Str $p {
        $dir = $dir.add($p);
    }
    my Str $leaf = @parts[*-1];
    for <rakumod pm6 raku pm> -> Str $ext {
        my IO::Path $candidate = $dir.add("$leaf.$ext");
        return $candidate if $candidate.e;
    }
    return $dir.add("$leaf.rakumod");
}
