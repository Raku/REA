=begin pod

=head1 NAME

Nimala::Raku-DAP - The Raku Debug Adapter Protocol (DAP) Server

=head1 DESCRIPTION

This module implements the Debug Adapter Protocol (DAP) for Raku. It serves as the
main broker between the IDE (such as VS Code, Neovim, or Emacs) and the target Raku process being debugged.

=head2 Supported DAP Features

=item B<Launch>: Launching scripts with custom CLI arguments and environment variables.
=item B<Line Breakpoints>: Setting line breakpoints with smart alignment to executable statements and conditional expressions.
=item B<Logpoints>: Setting non-breaking logpoints with dynamic expression interpolation.
=item B<Function Breakpoints>: Breakpoints by routine name with conditional evaluation.
=item B<Exception Breakpoints>: Automatic pause on uncaught and all exceptions with full stack trace and exceptionInfo inspection.
=item B<Execution Stepping>: Step Over (`next`), Step In (`stepIn`), Step Out (`stepOut`), Pause (`pause`), and Continue (`continue`).
=item B<Threads & Call Stacks>: Multi-threaded stack frame inspection with file locations, line numbers, and active subroutine names.
=item B<Variable Inspection>: Inspection of Lexical (`Locals`) scopes with lazy navigation of object attributes, positionals, and associatives.
=item B<Interactive REPL & Evaluation>: Real-time bounded expression evaluation in the debug console with safe `.gist` inspection.

=head2 Architecture: Native MoarVM Remote Debugging Protocol

This DAP server communicates directly with MoarVM's built-in remote debugging protocol
over loopback TCP using MessagePack framing.

=item B<Native VM-Level Execution>: The debuggee runs as standard C<raku --debug-port=<port> --debug-suspend <program>>, executing standard precompiled bytecode. This eliminates the precompilation slot mismatches, slow first launches, and compiler C<when> statement crashes of earlier statement-hook implementations.
=item B<Pure-Raku MessagePack Framing>: Communication uses a fast, dependency-free MessagePack codec and protocol client with monotonic request/response correlation and event dispatch.
=item B<Monotonic Handle Management>: Context and object handles allocated during stops are tracked in a lifecycle registry and cleanly released in batches upon resume or disconnect.
=item B<Bounded Expressions & Safe Inspection>: Expression evaluation, conditional breakpoints, and logpoints use a bounded expression grammar (variables, attribute/key/index access, comparisons against literals). Arbitrary method calls and mutations are refused; only the whitelisted helpers C<.gist>, C<.Str>, C<.raku> and C<.elems> run in the debuggee, at most one per stop.
=item B<Smart Stepping>: Configurable smart stepping (C<into>, C<over>, C<disable>) automatically filters out internal compiler, runtime, and NQP frames on builds without line drift, while robust sweep stepping protects stepping on builds with bytecode line drift.

=head2 Public Interface

The public interface of this module is minimal as it primarily acts as an entry point for the DAP server binary.

=item B<run-dap-server()>: Starts the DAP event loop, reading DAP messages from standard input, translating them to MoarVM protocol commands, and relaying events back to the client.

=head2 License
Artistic-2.0

=end pod

unit module Nimala::Raku-DAP:ver<1.0.0>;

use JSON::Fast;
use Nimala::Raku-DAP::Framing;
use Nimala::Raku-DAP::Trace;
use Nimala::Model::SymbolLookup;
use Nimala::Raku-DAP::SymbolScanner;
use Nimala::Raku-DAP::Session;

my Int $seq = 1;
my Lock $send-lock .= new;
my Nimala::Model::SymbolLookup $symbol-lookup;
my Nimala::Raku-DAP::Session $session;

our sub get-symbol-lookup(--> Nimala::Model::SymbolLookup) {
    $symbol-lookup //= Nimala::Raku-DAP::SymbolScanner.new;
}


#| Opens the trace log; a refusal is reported to the client on stderr.
our sub init-trace-logging(Bool $trace-arg = False --> Nil) {
    my Str $refused = Nimala::Raku-DAP::Trace::init-trace-logging($trace-arg);
    send-event('output', %( category => 'stderr', output => $refused )) if $refused;
}

#| Assigns `seq` and writes the frame in one critical section, so `seq` is strictly increasing on the wire.
#| Lock order: send lock, then the framing write lock inside `dap-write`.
sub send-message(%msg --> Nil) {
    my %out = %msg;
    $send-lock.protect: {
        %out<seq> = $seq++;
        my Str $json = to-json(%out, :!pretty);
        log-trace("OUT: " ~ $json) if is-tracing();
        dap-write($json);
    }
}

my %pending-reverse;
my Lock $pending-lock .= new;

#| Sends a reverse request (adapter → client) and returns a Promise kept with the client's response Hash.
#| The Promise is broken when no response arrives within $timeout. The entry is registered under the send lock,
#| so a fast response can never arrive before it; the pending lock is never held while writing.
our sub send-reverse-request(Str $command, %arguments, Real :$timeout = 10 --> Promise) {
    my Promise $p .= new;
    my $vow = $p.vow;
    my Int $id;
    $send-lock.protect: {
        $id = $seq;
        $pending-lock.protect: { %pending-reverse{$id} = $vow };
        send-message(%( type => 'request', command => $command, arguments => %arguments ));
    }
    Promise.in($timeout).then: {
        my $late = $pending-lock.protect: { %pending-reverse{$id}:delete };
        $late.break("No response to reverse request '$command' within {$timeout}s") if $late.defined;
    };
    return $p;
}

#| Keeps the pending reverse request a client response answers. Returns False for an unknown `request_seq`.
our sub route-response(%msg --> Bool) {
    my Int $id = (try (%msg<request_seq> // -1).Int) // -1;
    my $vow = $pending-lock.protect: { %pending-reverse{$id}:delete };
    return False unless $vow.defined;
    $vow.keep(%msg);
    return True;
}

our sub send-response(%req, %body, Bool :$success = True, Str :$message = "" --> Nil) is export {
    my %res = (
        type => 'response',
        request_seq => (try (%req<seq> // 0).Int) // 0,
        success => $success,
        command => (%req<command> // "").Str,
    );
    %res<message> = $message if !$success || $message ne "";
    if !$success {
        my %err-body = %body.clone;
        %err-body<error> //= %(
            id => %res<request_seq>,
            format => ($message ne "" ?? $message !! "Request failed"),
            showUser => ($message ne 'notStopped'),
        );
        %res<body> = %err-body;
    } elsif %body {
        %res<body> = %body;
    }

    send-message(%res);
}

our sub send-event(Str $event, %body --> Nil) {
    send-message({
            type => 'event',
            event => $event,
            body => %body
    });
}

our sub get-session(--> Nimala::Raku-DAP::Session) {
    $session //= Nimala::Raku-DAP::Session.new(
        send-response      => &send-response,
        send-event         => &send-event,
        send-reverse-request => &send-reverse-request,
        symbol-lookup      => get-symbol-lookup(),
    );
}

our sub kill-debuggee(--> Nil) {
    if $session.defined {
        $session.terminate();
    }
}

END {
    kill-debuggee();
}


sub run-dap-server(--> Nil) is export {
    init-trace-logging();
    my $in-channel = dap-read-supply();

    my $sess = get-session();
    $sess.start-worker();

    my @signals = $*DISTRO.is-win ?? (SIGINT, SIGTERM) !! (SIGINT, SIGTERM, SIGHUP);
    for @signals -> $sig {
        try {
            signal($sig).tap(-> $ {
                    log-trace("Signal $sig caught, killing debuggee");
                    kill-debuggee();
                    exit 0;
            });
        }
    }

    react {
        whenever $in-channel -> Str $json-str {
            try {
                log-trace("IN: " ~ $json-str) if is-tracing();
                my $parsed;
                try {
                    $parsed = from-json($json-str);
                    CATCH {
                        default { log-trace("DAP JSON Parse Error: " ~ .message); }
                    }
                }

                unless $parsed.defined && $parsed ~~ Hash {
                    log-trace("DAP envelope error: payload is not a JSON object");
                    next;
                }
                my Hash $msg = $parsed;

                my Str $type = ($msg<type> // "").Str;
                if $type eq '__framing_error' {
                    my Str $error = "Parse error: " ~ ($msg<error> // 'Invalid message').Str;
                    log-trace("DAP framing error: $error");
                    if $msg<seq>.defined {
                        send-response($msg, {}, :!success, message => $error);
                    } else {
                        send-event('output', { category => 'stderr', output => "$error\n" });
                    }
                    next;
                }
                if $type eq 'response' {
                    log-trace("DAP envelope: ignored response to unknown request_seq") unless route-response($msg);
                    next;
                }
                unless $type eq 'request' {
                    log-trace("DAP envelope: ignored non-request message of type '$type'");
                    next;
                }

                my $cmd-raw = $msg<command>;
                my Int $req-seq = (try ($msg<seq> // 0).Int) // 0;

                if !$cmd-raw.defined || $cmd-raw !~~ Str || $cmd-raw.trim eq '' {
                    send-response(
                        hash(seq => $req-seq, command => ($cmd-raw.defined ?? $cmd-raw.Str !! "")),
                        %(),
                        :!success,
                        :message("Malformed request envelope: 'command' must be a non-empty string")
                    );
                    next;
                }

                $sess.enqueue-request($msg);

                CATCH {
                    default {
                        log-trace("DAP unhandled error in request dispatch: " ~ .message ~ "\n" ~ .backtrace.Str);
                        try {
                            if $msg.defined && $msg ~~ Hash {
                                send-response(
                                    $msg,
                                    %(),
                                    :!success,
                                    :message("Internal error handling request: " ~ .message)
                                );
                            }
                        }
                    }
                }
            }
            LAST {
                log-trace("Input channel closed (EOF), killing debuggee");
                kill-debuggee();
            }
            QUIT {
                default {
                    log-trace("Input channel error: " ~ .message);
                    kill-debuggee();
                }
            }
        }
    }

    kill-debuggee();
}
