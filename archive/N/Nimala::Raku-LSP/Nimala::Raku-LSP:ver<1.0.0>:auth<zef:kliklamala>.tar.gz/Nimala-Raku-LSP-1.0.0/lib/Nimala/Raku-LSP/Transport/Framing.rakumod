use v6.d;
#| Generic stream framing and message serialization for Language Server Protocol (LSP).
unit module Nimala::Raku-LSP::Transport::Framing;

#| Frames an outgoing JSON-RPC message with LSP Content-Length headers.
our sub lsp-frame-message(Str $json --> Blob) is export {
    my Blob $encoded = $json.encode('utf-8');
    my Blob $header = "Content-Length: { $encoded.bytes }\r\n\r\n".encode('utf-8');

    my Buf[uint8] $buf = Buf[uint8].new;
    $buf.append($header);
    $buf.append($encoded);
    return $buf;
}

#| Locates the earliest header delimiter (\r\n\r\n = 4 bytes, or \n\n = 2 bytes) in a buffer.
our sub find-header-delimiter(Buf[uint8] $buf --> List) is export {
    my Int $n = $buf.elems;
    return (-1, 0) if $n < 2;

    my Int $i = 0;
    while $i < $n - 1 {
        if $buf[$i] == 13 && $i + 3 < $n && $buf[$i+1] == 10 && $buf[$i+2] == 13 && $buf[$i+3] == 10 {
            return ($i, 4);
        } elsif $buf[$i] == 10 && $buf[$i+1] == 10 {
            return ($i, 2);
        }
        $i++;
    }
    return (-1, 0);
}

#| Decodes a framed message body into UTF-8, or returns a JSON-RPC -32700 error string.
our sub decode-framed-body(Blob $body --> Str) is export {
    my Str $decoded;
    my Bool $ok = True;
    try {
        $decoded = $body.decode('utf-8');
        CATCH { default { $ok = False; } }
    }
    if $ok {
        return $decoded;
    }

    my Str $lossy = $body.decode('latin-1');
    my $id = Any;
    if $lossy ~~ / '"id"' \s* ':' \s* ( \d+ | '"' (<-["]>*) '"' ) / {
        $id = $0.Str.starts-with('"') ?? $0.Str.substr(1, *-1) !! +$0.Str;
    }
    if $id.defined {
        my Str $id-val = $id ~~ Str ?? "\"$id\"" !! $id.Str;
        return '{"jsonrpc":"2.0","id":' ~ $id-val ~ ',"error":{"code":-32700,"message":"Parse error: Invalid UTF-8"}}';
    }
    return Str;
}

#| Parses an asynchronous stream of binary chunks into a Supply of decoded JSON strings.
our sub lsp-parse-stream(Supply $byte-supply --> Supply) is export {
    supply {
        my Buf[uint8] $buf .= new;

        whenever $byte-supply -> Blob $chunk {
            $buf.append($chunk);

            loop {
                my ($delimiter-pos, $delimiter-len) = find-header-delimiter($buf);
                last if $delimiter-pos == -1; # Incomplete header

                my Str $headers = $buf.subbuf(0, $delimiter-pos).decode('latin-1');
                my Int $len = 0;
                if $headers ~~ / :i 'Content-Length:' \s* (\d+) / {
                    $len = +$0;
                } else {
                    # Malformed header without Content-Length: discard and continue
                    $buf = $buf.subbuf($delimiter-pos + $delimiter-len);
                    next;
                }

                my Int $total-needed = $delimiter-pos + $delimiter-len + $len;
                last if $buf.elems < $total-needed; # Incomplete body

                my Blob $body = $buf.subbuf($delimiter-pos + $delimiter-len, $len);
                $buf = $buf.subbuf($total-needed);

                my Str $msg = decode-framed-body($body);
                if $msg.defined {
                    emit $msg;
                }
            }
        }
    }
}

#| Adapts a synchronous IO::Handle into a Supply of decoded JSON strings.
our sub lsp-handle-supply(IO::Handle $in, Int :$chunk-size = 1024 --> Supply) is export {
    try { $in.encoding(Nil) if $in.can('encoding') };
    my Supplier::Preserving $supplier .= new;

    start {
        my Buf[uint8] $buf .= new;
        loop {
            my ($delimiter-pos, $delimiter-len) = find-header-delimiter($buf);

            while $delimiter-pos == -1 {
                my Blob $chunk = $in.read($chunk-size);
                last if !$chunk.elems; # EOF
                $buf.append($chunk);
                ($delimiter-pos, $delimiter-len) = find-header-delimiter($buf);
            }

            last if $delimiter-pos == -1; # EOF before complete header

            my Str $headers = $buf.subbuf(0, $delimiter-pos).decode('latin-1');
            my Int $len = 0;
            if $headers ~~ / :i 'Content-Length:' \s* (\d+) / {
                $len = +$0;
            } else {
                # Malformed header without Content-Length: discard and continue
                $buf = $buf.subbuf($delimiter-pos + $delimiter-len);
                next;
            }

            my Int $total-needed = $delimiter-pos + $delimiter-len + $len;
            while $buf.elems < $total-needed {
                my Blob $chunk = $in.read($total-needed - $buf.elems);
                last if !$chunk.elems; # EOF
                $buf.append($chunk);
            }

            last if $buf.elems < $total-needed;
            my Blob $body = $buf.subbuf($delimiter-pos + $delimiter-len, $len);
            $buf = $buf.subbuf($total-needed);

            my Str $msg = decode-framed-body($body);
            if $msg.defined {
                $supplier.emit($msg);
            }
        }
        $supplier.done();
        CATCH {
            default {
                $supplier.quit($_);
            }
        }
    }

    return $supplier.Supply;
}

#| Adapts a synchronous IO::Handle into a Channel of decoded JSON strings.
our sub lsp-parse-handle(IO::Handle $in, Int :$chunk-size = 1024 --> Channel) is export {
    return lsp-handle-supply($in, :$chunk-size).Channel;
}
