unit module Nimala::Raku-LSP::Analysis::InlineCompletion;

use Nimala::Raku-LSP::Document;

#| Generate multi-line inline completions (ghost-text) based on the line prefix and context.
our sub get-inline-completions(Document $doc, Int $line, Int $character --> Array) is export {
    return [].Array if $line < 0 || $line >= $doc.lines-count;

    my Str $line-text = $doc.line-text($line);
    my Int $grapheme-idx = max(0, min($doc.position-to-offset($line, $character) - $doc.line-offsets[$line], $line-text.chars));
    my Str $prefix = $line-text.substr(0, $grapheme-idx);
    my Str $suffix = $line-text.substr($grapheme-idx);

    # Only provide completions when typing at the end of token or line (suffix is whitespace or empty)
    return [].Array unless $suffix.trim eq "";

    # Extract indentation of the current line
    my Str $indent = "";
    if $prefix ~~ /^ (\s*) / {
        $indent = ~$0;
    }

    my @items;

    # 1. Control flow
    if $prefix ~~ /^ \s* 'for' \s+ $/ {
        @items.push: {
            insertText => '@items -> $item {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'if' \s+ $/ {
        @items.push: {
            insertText => '$condition {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'unless' \s+ $/ {
        @items.push: {
            insertText => '$condition {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'without' \s+ $/ {
        @items.push: {
            insertText => '$var {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'with' \s+ $/ {
        @items.push: {
            insertText => '$var {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'while' \s+ $/ {
        @items.push: {
            insertText => '$condition {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'until' \s+ $/ {
        @items.push: {
            insertText => '$condition {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'loop' \s+ $/ {
        @items.push: {
            insertText => '(my $i = 0; $i < $limit; $i++) {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'given' \s+ $/ {
        @items.push: {
            insertText => '$expr {' ~ "\n$indent    when \$val \{\n$indent        \n$indent    \}\n$indent    default \{\n$indent        \n$indent    \}\n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'try' \s* $/ {
        @items.push: {
            insertText => ' {' ~ "\n$indent    \n$indent\} CATCH \{\n$indent    default \{\n$indent        \n$indent    \}\n$indent\}",
        };
    }

    # 2. Routine and Method Declarations
    elsif $prefix ~~ /^ \s* ('sub' | 'method') \s+ (<[\w\-]>+) \s* $/ {
        @items.push: {
            insertText => '($param --> Any) {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'sub' \s* $/ {
        @items.push: {
            insertText => ' name($param --> Any) {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'method' \s* $/ {
        @items.push: {
            insertText => ' name($param --> Any) {' ~ "\n$indent    \n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* ('class' | 'role') \s+ (<[\w\:\-]>+) \s* $/ {
        @items.push: {
            insertText => ' {' ~ "\n$indent    has \$.attr;\n$indent\}",
        };
    }
    elsif $prefix ~~ /^ \s* 'enum' \s+ (<[\w\:\-]>+) \s* $/ {
        @items.push: {
            insertText => " <\n$indent    Alpha\n$indent    Beta\n$indent>;",
        };
    }
    elsif $prefix ~~ /^ \s* 'unit' \s+ ('class' | 'module' | 'role') \s* $/ {
        @items.push: {
            insertText => " Name;",
        };
    }

    # 3. Pod6 Documentation
    elsif $prefix ~~ /^ \s* '=begin' \s+ 'pod' \s* $/ {
        @items.push: {
            insertText => "\n\n=head1 NAME\n\n\n\n=head1 DESCRIPTION\n\n\n\n=end pod",
        };
    }
    elsif $prefix ~~ /^ \s* '=begin' \s+ (<[\w\-]>+) \s* $/ {
        my $block-name = ~$0;
        @items.push: {
            insertText => "\n\n=end $block-name",
        };
    }
    elsif $prefix ~~ /^ \s* '#|' \s* $/ {
        @items.push: {
            insertText => " Summary description",
        };
    }

    # 4. Testing (.rakutest or t/ or subtest/plan)
    elsif $prefix ~~ /^ \s* 'subtest' \s* $/ {
        @items.push: {
            insertText => ' "description" => {' ~ "\n$indent    plan 1;\n$indent    ok 1, \"passes\";\n$indent\};",
        };
    }
    elsif $prefix ~~ /^ \s* 'plan' \s* $/ {
        @items.push: {
            insertText => " 1;",
        };
    }

    return @items.Array;
}
