unit module Nimala::Raku-LSP::VendorIndex;

use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::SymbolDB;
use JSON::Fast;

my Lock $lock = Lock.new;
my Any %vendor-symbols{Str} = %();
my Any %indexed-modules{Str} = %();

my constant $MAX-VENDOR-WORKERS = 2;
my Channel $worker-semaphore;
my Lock $sem-lock = Lock.new;
sub get-worker-semaphore() {
    $sem-lock.protect: {
        unless $worker-semaphore.defined {
            $worker-semaphore = Channel.new;
            for 1 .. $MAX-VENDOR-WORKERS {
                $worker-semaphore.send(True);
            }
        }
        $worker-semaphore;
    }
}

our sub reset-cache() is export {
    $lock.protect: {
        %vendor-symbols = %();
        %indexed-modules = %();
    }
}

our sub get-vendor-symbols(:$db) is export {
    $lock.protect: {
        my @res;
        for %vendor-symbols.values -> $list {
            @res.append(@($list));
        }
        if !@res && $db && (try { $db.is-open }) {
            @res.append($db.get-vendor-symbols());
        }
        return @res;
    }
}

my Str $mop-extractor-script = q:to/EXTRACTOR/;
use JSON::Fast;
sub MAIN(Str $mod) {
    my @syms;
    try {
        require ::($mod);
        my $target = ::($mod);
        if $target.WHO {
            for $target.WHO.kv -> $k, $v {
                next if $k.starts-with("!") || $k.starts-with('$?');
                if $k.starts-with("&") || (try { $v ~~ Routine }) {
                    my $name = $k.subst(/^\&/, '');
                    my $sig = try { $v.signature.raku } // "";
                    @syms.push: {
                        name => $name,
                        kind => 12,
                        detail => "sub $name$sig",
                        containerName => $mod
                    };
                }
                elsif $k ~~ /^ <[$@%]> / {
                    @syms.push: {
                        name => $k,
                        kind => 13,
                        detail => "our $k",
                        containerName => $mod
                    };
                }
                elsif !(try { $v.DEFINITE }) && (try { $v.HOW.defined && $v.HOW.^name.contains("Metamodel") }) {
                    my $how = try { $v.HOW.^name } // "";
                    my Int $kind = 5;
                    my Str $detail = "class";
                    if $how.contains("Role") {
                        $kind = 11;
                        $detail = "role";
                    } elsif $how.contains("Module") || $how.contains("Package") {
                        $kind = 2;
                        $detail = "module";
                    }
                    @syms.push: {
                        name => $k,
                        kind => $kind,
                        detail => $detail,
                        containerName => $mod
                    };
                }
                else {
                    @syms.push: {
                        name => $k,
                        kind => 14,
                        detail => "constant $k",
                        containerName => $mod
                    };
                }
            }
        }
        try {
            for $target.^methods(:local) -> $m {
                my $name = try { $m.name } // "";
                next if $name eq "" || $name.starts-with("!");
                my $sig = try { $m.signature.raku } // "";
                my $returns = try { $m.returns.raku } // "";
                @syms.push: {
                    name => $name,
                    kind => 6,
                    detail => "method $name$sig" ~ ($returns ne "Mu" && $returns ne "" ?? " --> $returns" !! ""),
                    containerName => $mod
                };
            }
        }
        try {
            for $target.^attributes(:local) -> $a {
                my $name = try { $a.name } // "";
                next if $name eq "";
                my $type = try { $a.type.raku } // "";
                @syms.push: {
                    name => $name,
                    kind => 7,
                    detail => "has $type $name",
                    containerName => $mod
                };
            }
        }
        @syms.push: { name => $mod, kind => 5, detail => "package $mod", containerName => $mod };
        CATCH { default { } }
    }
    say to-json(@syms);
}
EXTRACTOR

my constant @KEYWORD-EXCLUSIONS = <need require use no import unit v6 lib experimental nqp strict trace fatal MONKEY MONKEY-SEE-NO-EVAL MONKEY-GUTS MONKEY-TYPING Test>;

our sub ensure-indexed(Str $module-name, :$db) is export {
    return if $module-name ~~ /^ 'v6' / || $module-name eq any(@KEYWORD-EXCLUSIONS);
    $lock.protect: {
        return if %indexed-modules{$module-name};
        %indexed-modules{$module-name} = True;
    }

    start {
        my $spec = try { CompUnit::DependencySpecification.new(short-name => $module-name) };
        if $spec {
            my $comp = try { $*REPO.resolve($spec) };
            if $comp {
                my Str $version = (try { ($comp.distribution.meta<version> // $comp.distribution.meta<ver>).Str }) // "unknown";
                my Str $auth = (try { $comp.distribution.meta<auth>.Str }) // "unknown";
                my Bool $loaded-from-cache = False;
                if $db && (try { $db.is-open }) {
                    my %info = $db.get-vendor-module-info($module-name);
                    if %info && (%info<version> // "") eq $version {
                        if %info<is-negative> {
                            $lock.protect: {
                                %vendor-symbols{$module-name} = [];
                            }
                            $loaded-from-cache = True;
                        } else {
                            my @cached = $db.get-vendor-symbols-for($module-name);
                            if @cached {
                                $lock.protect: {
                                    %vendor-symbols{$module-name} = @cached;
                                }
                                $loaded-from-cache = True;
                            }
                        }
                    }
                }

                unless $loaded-from-cache {
                    my $sem = get-worker-semaphore();
                    $sem.receive;
                    LEAVE {
                        try { $sem.send(True); }
                    }

                    # 1. Primary: Isolated Out-of-Process MOP Introspection
                    my @syms;
                    my $proc = Proc::Async.new($*EXECUTABLE.absolute, '-e', $mop-extractor-script, '--', $module-name);
                    my $stdout = "";
                    $proc.stdout.tap(-> $v { $stdout ~= $v });
                    $proc.stderr.tap(-> $ { });
                    my $timeout = Promise.in(5);
                    my $p = $proc.start;

                    try {
                        await Promise.anyof($p, $timeout);
                        if $timeout.status == Kept && $p.status != Kept {
                            $proc.kill(SIGKILL);
                        } else {
                            my $json-data = try { from-json($stdout.trim) };
                            if $json-data && $json-data.elems > 0 {
                                @syms = @($json-data);
                            }
                        }
                        CATCH { default { } }
                    }

                    # 2. Fallback: Source file regex extraction if MOP sub-process failed
                    if @syms.elems == 0 {
                        my $provides = try { $comp.distribution.meta<provides>{$module-name} };
                        if $provides {
                            my $file-id;
                            if $provides ~~ Hash {
                                $file-id = $provides.values[0]<file> // $provides.values[0];
                            } else {
                                $file-id = $provides;
                            }
                            if $file-id {
                                my $source-file = try { $comp.repo.prefix.child('sources').child($file-id) };
                                if $source-file && $source-file.e {
                                    my $code = try { $source-file.slurp } // "";
                                    @syms = extract-symbols($code);
                                }
                            }
                        }
                    }

                    if @syms {
                        if $db && (try { $db.is-open }) {
                            $db.set-vendor-symbols($module-name, $version, $auth, @syms);
                        }
                        $lock.protect: {
                            %vendor-symbols{$module-name} = @syms;
                        }
                    } else {
                        $lock.protect: {
                            %vendor-symbols{$module-name} = [];
                        }
                        if $db && (try { $db.is-open }) {
                            $db.set-vendor-symbols($module-name, $version, $auth, []);
                        }
                    }
                }
            }
        }
    }
}
