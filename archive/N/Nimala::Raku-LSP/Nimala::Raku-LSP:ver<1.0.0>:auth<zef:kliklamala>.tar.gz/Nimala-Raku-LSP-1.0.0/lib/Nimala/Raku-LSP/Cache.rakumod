use v6.d;
unit module Nimala::Raku-LSP::Cache;

#| Directory names to ignore during workspace indexing and file traversal
our constant @EXCLUDED-DIRS is export = <.git .nimala .precomp .vscode .vscode-test node_modules scratch .cache blib>;

#| Recognized Raku source file extensions
our constant @SOURCE-EXTENSIONS is export = <raku rakumod pm6 p6 rakutest rakudoc pod6 t t6 nqp>;

#| Find all Raku source files in a folder, skipping excluded directories
sub find-raku-files(IO::Path $folder-path --> Positional) is export {
    return [] unless $folder-path && $folder-path.d;
    my IO::Path @files;
    my IO::Path @stack = $folder-path;
    my $excl-any = any(@EXCLUDED-DIRS);
    my $ext-any  = any(@SOURCE-EXTENSIONS);
    my SetHash $visited-dirs .= new;
    while @stack {
        my IO::Path $curr = @stack.pop;
        if $curr.d {
            next if $curr.basename eq $excl-any;
            # Do not follow directory symlinks to avoid circular traversals (K-31)
            next if $curr.l && $curr.absolute ne $folder-path.absolute;
            my Str $canon = try { $curr.resolve.absolute } // "";
            if $canon ne "" {
                next if $visited-dirs{$canon};
                $visited-dirs.set($canon);
            }
            try {
                @stack.append: $curr.dir;
                CATCH { default { } }
            }
        } elsif $curr.f && $curr.extension && $curr.extension eq $ext-any {
            @files.push: $curr;
        }
    }
    return @files;
}

#| FNV-1a 64-bit hash function for binary buffer
sub hash-buffer(Blob $buf --> Str) is export {
    my int $hash = -3750763034362895579; # 0xcbf29ce484222325
    my int $fnv-prime = 1099511628211;   # 0x100000001b3

    for ^$buf.elems -> $i {
        $hash = $hash +^ $buf[$i];
        $hash = $hash * $fnv-prime;
    }

    return sprintf("%016x", $hash);
}

#| FNV-1a 64-bit hash function for files
sub hash-file(IO::Path $path --> Str) is export {
    return "" unless $path.e;
    return hash-buffer($path.slurp(:bin));
}
