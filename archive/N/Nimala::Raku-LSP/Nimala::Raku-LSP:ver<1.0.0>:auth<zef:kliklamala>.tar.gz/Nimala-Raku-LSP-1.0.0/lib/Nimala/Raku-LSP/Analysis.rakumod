unit module Nimala::Raku-LSP::Analysis;

use Nimala::Raku-LSP::Analysis::Diagnostics;
use Nimala::Raku-LSP::Analysis::Symbols;
use Nimala::Raku-LSP::Analysis::Cursor;
use Nimala::Raku-LSP::Analysis::TypeInference;
use Nimala::Raku-LSP::Analysis::Intelligence;
use Nimala::Raku-LSP::Analysis::Completion;
use Nimala::Raku-LSP::Analysis::InlineCompletion;

BEGIN {
    our package EXPORT::DEFAULT {
        for (
            Nimala::Raku-LSP::Analysis::Diagnostics::EXPORT::DEFAULT::,
            Nimala::Raku-LSP::Analysis::Symbols::EXPORT::DEFAULT::,
            Nimala::Raku-LSP::Analysis::Cursor::EXPORT::DEFAULT::,
            Nimala::Raku-LSP::Analysis::TypeInference::EXPORT::DEFAULT::,
            Nimala::Raku-LSP::Analysis::Intelligence::EXPORT::DEFAULT::,
            Nimala::Raku-LSP::Analysis::Completion::EXPORT::DEFAULT::,
            Nimala::Raku-LSP::Analysis::InlineCompletion::EXPORT::DEFAULT::
        ) -> $stash {
            for $stash.keys -> $sym {
                next unless $sym.starts-with('&');
                OUR::{$sym} := $stash{$sym};
            }
        }
    }
    for EXPORT::DEFAULT::.keys -> $sym {
        OUR::{$sym} := EXPORT::DEFAULT::{$sym};
    }
}
