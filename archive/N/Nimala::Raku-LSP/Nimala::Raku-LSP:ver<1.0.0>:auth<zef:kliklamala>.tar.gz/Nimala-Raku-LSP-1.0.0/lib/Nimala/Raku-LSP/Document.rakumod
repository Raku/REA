unit module Nimala::Raku-LSP::Document;

use Nimala::Raku-LSP::URI;

# Helper to calculate UTF-16 code units for a grapheme
our sub utf16-units-of-grapheme(Str $g --> Int) is export {
    my Int $units = 0;
    for $g.ords -> int $cp {
        $units += ($cp > 0xFFFF) ?? 2 !! 1;
    }
    return $units || 1;
}

# Helper to calculate UTF-16 code units for a string
our sub utf16-length(Str $str --> Int) is export {
    my Int $units = 0;
    for $str.comb -> Str $g {
        $units += utf16-units-of-grapheme($g);
    }
    return $units;
}

class Document is export {
    has Str $.uri is readonly;
    has Str $.languageId is readonly;
    has Int $.version is readonly;
    has Str $.text is readonly = "";
    has Bool $.is-open is readonly = False;
    has Blob[uint8] $!utf16;
    has Int @!line-offsets = [0];
    has Int @!utf16-line-offsets = [0];
    has Bool $!is-ascii = False;
    has Int $!chars = 0;

    has Any $.ast is rw;
    has Array $.symbols is rw;
    has Int $.ast-version is rw = -1;
    has Array $.native-symbols is rw;
    has Int $.native-symbols-version is rw = -1;
    has Array $.semantic-tokens is rw;
    has Array $.semantic-tokens-raw is rw;
    has Int $.semantic-tokens-version is rw = -1;
    has Array $.raw-tokens is rw;
    has Int $.raw-tokens-version is rw = -1;
    has Bool $.native-failed is rw = False;
    has Int $.native-failed-version is rw = -1;
    has Lock $!parse-lock = Lock.new;
    has Promise $!native-run;

    #| In-flight native worker run for this snapshot; read and write only inside `protect-parse`
    method native-run(--> Promise) {
        return $!native-run;
    }

    method set-native-run(Promise $run --> Nil) {
        $!native-run = $run;
    }

    method clear-native-run(--> Nil) {
        $!native-run = Promise;
    }

    method native-run-pending(--> Bool) {
        return $!native-run.defined;
    }

    method is-native-failed(--> Bool) {
        return $!native-failed && ($!native-failed-version == $!version || $!native-failed-version == -1);
    }

    method mark-native-failed(--> Nil) {
        $!native-failed = True;
        $!native-failed-version = $!version;
    }

    method reset-native-failed(--> Nil) {
        $!native-failed = False;
        $!native-failed-version = -1;
    }

    submethod TWEAK(:$utf16) {
        if $utf16.defined {
            $!utf16 = $utf16;
            $!text = $!utf16.decode('utf-16le');
        } else {
            $!utf16 = $!text.encode('utf-16le');
        }
        $!is-ascii = ($!text.codes == $!text.encode('utf-8').bytes);
        $!chars = $!text.chars;
        self!rebuild-line-offsets;
    }

    method protect-parse(&code) {
        return $!parse-lock.protect(&code);
    }

    method line-offsets(--> Positional) {
        return @!line-offsets;
    }

    method utf16-line-offsets(--> Positional) {
        return @!utf16-line-offsets;
    }

    method utf16(--> Blob[uint8]) {
        return $!utf16;
    }

    method is-ascii(--> Bool) {
        return $!is-ascii;
    }

    method lines-count(--> Int) {
        return @!line-offsets.elems;
    }

    method line-text(Int $line --> Str) {
        return "" if $line < 0 || $line >= @!line-offsets.elems;
        my Int $start = @!line-offsets[$line];
        my Int $end = ($line + 1 < @!line-offsets.elems) ?? @!line-offsets[$line + 1] !! $!text.chars;
        my Str $raw = $!text.substr($start, $end - $start);
        if $raw.ends-with("\r\n") {
            return $raw.substr(0, $raw.chars - 1);
        } elsif $raw.ends-with("\n") || $raw.ends-with("\r") {
            return $raw.substr(0, $raw.chars - 1);
        }
        return $raw;
    }

    method !rebuild-line-offsets(--> Nil) {
        my Bool $has-cr = $!text.contains("\r\n") || $!text.contains("\r");
        if $has-cr {
            my @ends = (|$!text.indices("\r\n"), |$!text.indices("\n"), |$!text.indices("\r")).sort;
            @!line-offsets = [0, |@ends.map(* + 1)];
        } else {
            @!line-offsets = [0, |$!text.indices("\n").map(* + 1)];
        }

        # Fast path: in pure ASCII with LF-only line breaks, UTF-16 code unit offsets equal grapheme offsets
        if $!is-ascii && !$has-cr {
            @!utf16-line-offsets = @!line-offsets;
            return;
        }

        # UTF-16 code unit line offsets
        my int $n = $!utf16.bytes div 2;
        my @u16-offsets = [0];
        my int $i = 0;
        while $i < $n {
            my int $b0 = $!utf16[$i * 2];
            my int $b1 = $!utf16[$i * 2 + 1];
            if $b1 == 0 {
                if $b0 == 10 { # \n
                    @u16-offsets.push($i + 1);
                } elsif $b0 == 13 { # \r
                    if $i + 1 < $n && $!utf16[($i + 1) * 2] == 10 && $!utf16[($i + 1) * 2 + 1] == 0 {
                        # CRLF is 2 code units
                        @u16-offsets.push($i + 2);
                        $i++;
                    } else {
                        # Lone \r is 1 code unit
                        @u16-offsets.push($i + 1);
                    }
                }
            }
            $i++;
        }
        @!utf16-line-offsets = @u16-offsets;
    }

    method update(Int $version, Str $text --> Document) {
        return Document.new(
            uri        => $!uri,
            languageId => $!languageId,
            version    => $version,
            text       => $text,
            is-open    => $!is-open
        );
    }

    method !clamp-u16-line-char(Int $line, Int $char, Int $u16-len --> Int) {
        return 0 if $line < 0;
        my Int $offsets-elems = @!utf16-line-offsets.elems;
        return $u16-len if $line >= $offsets-elems;
        my Int $line-start-cu = @!utf16-line-offsets[$line];
        my Int $line-next-cu = ($line + 1 < $offsets-elems) ?? @!utf16-line-offsets[$line + 1] !! $u16-len;

        # Calculate max character on this line before line terminators (\r\n, \n, \r)
        my Int $line-cu-end = $line-next-cu;
        if $line + 1 < $offsets-elems && $line-cu-end > $line-start-cu {
            my int $prev-i = $line-cu-end - 1;
            if $prev-i >= 0 {
                my int $b0 = $!utf16[$prev-i * 2];
                my int $b1 = $!utf16[$prev-i * 2 + 1];
                if $b1 == 0 && ($b0 == 10 || $b0 == 13) {
                    $line-cu-end--;
                    if $b0 == 10 && $prev-i > $line-start-cu {
                        my int $p0 = $!utf16[($prev-i - 1) * 2];
                        my int $p1 = $!utf16[($prev-i - 1) * 2 + 1];
                        if $p1 == 0 && $p0 == 13 {
                            $line-cu-end--;
                        }
                    }
                }
            }
        }
        my Int $max-char = max(0, $line-cu-end - $line-start-cu);
        my Int $clamped-char = max(0, min($char, $max-char));
        return min($line-start-cu + $clamped-char, $u16-len);
    }

    method apply-changes(Int $version, Any $changes --> Document) {
        my Document $current = self;
        my @list;
        if $changes ~~ Positional {
            for @$changes -> $item {
                if $item ~~ Hash {
                    @list.push: $item;
                }
            }
        } elsif $changes ~~ Hash {
            @list.push: $changes;
        }

        for @list -> %change {
            if %change<range>:exists && %change<range>.defined {
                my Int $start-line = +%change<range><start><line>;
                my Int $start-char = +%change<range><start><character>;
                my Int $end-line   = +%change<range><end><line>;
                my Int $end-char   = +%change<range><end><character>;

                my Int $u16-len = $current.utf16.bytes div 2;
                my Int $start-cu = $current!clamp-u16-line-char($start-line, $start-char, $u16-len);
                my Int $end-cu   = $current!clamp-u16-line-char($end-line, $end-char, $u16-len);

                if $end-cu < $start-cu {
                    $end-cu = $start-cu;
                }

                my Int $start-byte = $start-cu * 2;
                my Int $end-byte   = $end-cu * 2;
                my Blob[uint8] $rep-bytes = (%change<text> // "").encode('utf-16le');

                my Blob[uint8] $next-utf16 = Blob[uint8].new(
                    |$current.utf16.subbuf(0, $start-byte),
                    |$rep-bytes,
                    |$current.utf16.subbuf($end-byte)
                );
                $current = Document.new(
                    uri        => $!uri,
                    languageId => $!languageId,
                    version    => $version,
                    utf16      => $next-utf16,
                    is-open    => $!is-open
                );
            } else {
                my Str $next-text = (%change<text> // "").Str;
                $current = Document.new(
                    uri        => $!uri,
                    languageId => $!languageId,
                    version    => $version,
                    text       => $next-text,
                    is-open    => $!is-open
                );
            }
        }
        return $current;
    }

    method position-to-offset(Int $line, Int $character --> Int) {
        return 0 if $line < 0 || $!chars == 0;
        my Int $line-start = ($line < @!line-offsets.elems) ?? @!line-offsets[$line] !! $!chars;
        my Int $line-end = ($line + 1 < @!line-offsets.elems) ?? @!line-offsets[$line + 1] !! $!chars;
        return $line-start if $character <= 0;

        if $!is-ascii {
            my Int $max-char = $line-end - $line-start;
            if $line + 1 < @!line-offsets.elems && $max-char > 0 {
                my int $o = $!text.substr($line-end - 1, 1).ord;
                $max-char-- if $o == 10 || $o == 13;
            }
            return $line-start + ($character < $max-char ?? $character !! $max-char);
        }

        my Str $line-str = $!text.substr($line-start, $line-end - $line-start);
        my Int $cu-accum = 0;
        my Int $grapheme-idx = 0;
        for $line-str.comb -> Str $g {
            my int $o = $g.ord;
            last if $o == 10 || $o == 13;
            my Int $units = utf16-units-of-grapheme($g);
            last if $cu-accum + $units > $character;
            $cu-accum += $units;
            $grapheme-idx++;
        }
        return $line-start + $grapheme-idx;
    }

    method position-at(Int $pos --> Hash) {
        return hash( line => 0, character => 0 ) if $pos <= 0 || $!chars == 0;
        my int $target-pos = $pos > $!chars ?? $!chars !! $pos;

        # Binary search in @!line-offsets for largest line <= target-pos
        my int $low = 0;
        my int $high = @!line-offsets.elems - 1;
        my int $line = 0;
        while $low <= $high {
            my int $mid = ($low + $high) +> 1;
            if @!line-offsets[$mid] <= $target-pos {
                $line = $mid;
                $low = $mid + 1;
            } else {
                $high = $mid - 1;
            }
        }

        my int $line-start = @!line-offsets[$line];
        if $!is-ascii {
            return hash( line => $line, character => $target-pos - $line-start );
        }

        my Str $prefix = $!text.substr($line-start, $target-pos - $line-start);
        my Int $cu = 0;
        for $prefix.comb -> Str $g {
            my int $o = $g.ord;
            next if $o == 10 || $o == 13;
            $cu += utf16-units-of-grapheme($g);
        }
        return hash( line => $line, character => $cu );
    }

    method utf16-column(Int $line, Int $index --> Int) {
        return 0 if $line < 0 || $line >= @!line-offsets.elems;
        return self.position-at(@!line-offsets[$line] + $index)<character>;
    }
}

class DocumentStore is export {
    has Document %!documents{Str} = %();
    has Document %!lru-docs{Str} = %();
    has Str @!lru-order = [];
    has Int $.lru-capacity = 50;
    has Lock $!lock = Lock.new;

    method open(Str :$uri, Str :$languageId, Int :$version, Str :$text --> Nil) {
        my Str $canon-uri = canonicalize-uri($uri);
        $!lock.protect: {
            my Document $doc .= new(uri => $canon-uri, :$languageId, :$version, :$text, :is-open(True));
            %!documents{$canon-uri} = $doc;
            self!evict-lru-uri($canon-uri);
        };
    }

    method update(Int :$version, Str :$uri, Array :$changes?, Str :$text? --> Document) {
        my Str $canon-uri = canonicalize-uri($uri);
        $!lock.protect: {
            if %!documents{$canon-uri}:exists {
                my Document $cur = %!documents{$canon-uri};
                my Document $new-doc;
                if $changes.defined {
                    $new-doc = $cur.apply-changes($version, $changes);
                } elsif $text.defined {
                    $new-doc = $cur.update($version, $text);
                } else {
                    $new-doc = $cur;
                }
                %!documents{$canon-uri} = $new-doc;
                return $new-doc;
            }
            return Nil;
        };
    }

    method close(Str :$uri --> Nil) {
        my Str $canon-uri = canonicalize-uri($uri);
        $!lock.protect: {
            %!documents{$canon-uri}:delete;
        };
    }

    method get(Str $uri --> Document) {
        my Str $canon-uri = canonicalize-uri($uri);
        $!lock.protect: {
            %!documents{$canon-uri};
        }
    }

    method get-or-load(Str $uri --> Document) {
        my Str $canon-uri = canonicalize-uri($uri);
        $!lock.protect: {
            if %!documents{$canon-uri}:exists {
                return %!documents{$canon-uri};
            }
        };
        my IO::Path $path = uri-to-path($canon-uri);
        if $path.e && $path.f {
            my Str $mtime = (try { $path.modified.to-posix[0].Str }) // "0";
            my Str $cache-key = "$canon-uri\0$mtime";

            $!lock.protect: {
                if %!lru-docs{$cache-key}:exists {
                    self!touch-lru($cache-key);
                    return %!lru-docs{$cache-key};
                }
            };

            my Str $text = (try { $path.slurp }) // "";
            my Document $doc .= new(uri => $canon-uri, :languageId('raku'), :version(1), :$text);

            $!lock.protect: {
                if %!lru-docs{$cache-key}:exists {
                    self!touch-lru($cache-key);
                    return %!lru-docs{$cache-key};
                }
                self!evict-lru-uri($canon-uri);

                while @!lru-order.elems >= $!lru-capacity {
                    my Str $oldest = @!lru-order.shift;
                    %!lru-docs{$oldest}:delete;
                }
                %!lru-docs{$cache-key} = $doc;
                @!lru-order.push($cache-key);
                return $doc;
            };
        }
        return Nil;
    }

    method get-all-uris(--> Array) {
        $!lock.protect: {
            %!documents.keys.Array;
        }
    }

    method lru-cache-size(--> Int) {
        $!lock.protect: {
            return %!lru-docs.elems;
        }
    }

    method is-in-lru(Str $uri --> Bool) {
        my Str $canon-uri = canonicalize-uri($uri);
        $!lock.protect: {
            my Str $prefix = "$canon-uri\0";
            return ?@!lru-order.first(*.starts-with($prefix));
        }
    }

    method !touch-lru(Str $key --> Nil) {
        my Int $idx = @!lru-order.first(* eq $key, :k) // -1;
        if $idx >= 0 {
            @!lru-order.splice($idx, 1);
        }
        @!lru-order.push($key);
    }

    method !evict-lru-uri(Str $uri --> Nil) {
        my Str $prefix = "$uri\0";
        my @to-remove = @!lru-order.grep(*.starts-with($prefix));
        for @to-remove -> Str $k {
            my Int $idx = @!lru-order.first(* eq $k, :k) // -1;
            if $idx >= 0 {
                @!lru-order.splice($idx, 1);
            }
            %!lru-docs{$k}:delete;
        }
    }
}
