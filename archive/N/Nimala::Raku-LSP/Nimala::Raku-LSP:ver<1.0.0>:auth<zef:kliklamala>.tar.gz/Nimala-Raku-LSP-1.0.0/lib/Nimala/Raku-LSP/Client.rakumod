unit class Nimala::Raku-LSP::Client;

use JSON::Fast;
use Nimala::Raku-LSP::Transport::Stdio;

# Backward-compatibility aliases for MessageType
constant Error   is export = 1;
constant Warning is export = 2;
constant Info    is export = 3;
constant Log     is export = 4;

has IO::Handle $.out is rw = $*OUT;

submethod TWEAK(IO::Handle :$!out = $*OUT) { }

has Lock $!requests-lock = Lock.new;
has Int $!request-counter = 0;
has %!pending-requests = %();

#| Number of pending requests waiting for a response
method pending-requests-count(--> Int) {
    $!requests-lock.protect: { %!pending-requests.elems }
}

#| Log a message to the client's output console.
method log-message(Any $type, Str $message --> Nil) {
    my Int $t = ($type ~~ Int ?? $type !! ($type.?Int // 3)).Int;
    self.notify("window/logMessage", %(
            type => $t,
            :$message
    ));
}

#| Show a message notification to the user (e.g., popup).
method show-message(Any $type, Str $message --> Nil) {
    my Int $t = ($type ~~ Int ?? $type !! ($type.?Int // 3)).Int;
    self.notify("window/showMessage", %(
            type => $t,
            :$message
    ));
}

#| Send a notification to the client.
method notify(Str $method, %params --> Nil) {
    my %notification = jsonrpc => "2.0", method => $method, params => %params;
    lsp-write(to-json(%notification, :!pretty), $!out);
}

#| Send a fire-and-forget request to the client (does not track pending Promise).
method request(Str $method, %params --> Int) {
    my Int $req-id;
    $!requests-lock.protect: {
        $req-id = ++$!request-counter;
    }
    my %request = jsonrpc => "2.0", id => $req-id, method => $method, params => %params;
    lsp-write(to-json(%request, :!pretty), $!out);
    return $req-id;
}

#| Send a request to the client and return a Promise that resolves with the response, with timeout protection.
method request-async(Str $method, %params, Numeric :$timeout = 15, Numeric :$timeout-seconds? --> Promise) {
    my Numeric $eff-timeout = ($timeout-seconds.defined ?? $timeout-seconds !! $timeout).Numeric;
    my $p = Promise.new;
    my Int $req-id;
    $!requests-lock.protect: {
        $req-id = ++$!request-counter;
        %!pending-requests{$req-id} = $p;
    }
    my %request = jsonrpc => "2.0", id => $req-id, method => $method, params => %params;
    lsp-write(to-json(%request, :!pretty), $!out);

    if $eff-timeout > 0 {
        Promise.in($eff-timeout).then: {
            $!requests-lock.protect: {
                if %!pending-requests{$req-id}:exists {
                    my $pending = %!pending-requests{$req-id}:delete;
                    if $pending.status == Planned {
                        $pending.break("Request $req-id ($method) timed out after {$eff-timeout}s");
                    }
                }
            }
        };
    }

    return $p;
}

#| Handle a response from the client.
method handle-response(%response --> Nil) {
    my $id = %response<id>;
    return unless $id.defined;
    $!requests-lock.protect: {
        if %!pending-requests{$id}:exists {
            my $p = %!pending-requests{$id}:delete;
            if %response<error>:exists && %response<error>.defined {
                $p.break(%response<error>);
            } else {
                $p.keep(%response<result>);
            }
        }
    }
}

#| Request the client to refresh CodeLens.
method refresh-code-lens(--> Int) {
    self.request("workspace/codeLens/refresh", %())
}

#| Request the client to refresh Inlay Hints.
method refresh-inlay-hints(--> Int) {
    self.request("workspace/inlayHint/refresh", %())
}

#| Request the client to refresh Semantic Tokens.
method refresh-semantic-tokens(--> Int) {
    self.request("workspace/semanticTokens/refresh", %())
}

#| Request the client to refresh Folding Ranges.
method refresh-folding-ranges(--> Int) {
    self.request("workspace/foldingRange/refresh", %())
}

#| Request the client to refresh Pull Diagnostics.
method refresh-diagnostics(--> Int) {
    self.request("workspace/diagnostic/refresh", %())
}

#| Request the client to refresh Inline Values.
method refresh-inline-values(--> Int) {
    self.request("workspace/inlineValue/refresh", %())
}

#| Show a message request dialog with action buttons to the user.
method show-message-request(Any $type, Str $message, @actions = [] --> Int) {
    my @formatted-actions = @actions.map(-> $a {
            if $a ~~ Hash {
                $a;
            } else {
                %( title => $a.Str );
            }
    });
    my Int $t = ($type ~~ Int ?? $type !! ($type.?Int // 3)).Int;
    my %params = %(
        type => $t,
        :$message,
    );
    %params<actions> = @formatted-actions if @formatted-actions;
    self.request("window/showMessageRequest", %params);
}

#| Request the client to display a document or open an external URL.
method show-document(Str :$uri!, Bool :$external = False, Bool :$takeFocus = False --> Int) {
    my %params = %(
        :$uri,
        :$external,
        :$takeFocus
    );
    self.request("window/showDocument", %params);
}

#| Request the client to create a workDoneProgress token.
method create-work-done-progress($token --> Int) {
    self.request("window/workDoneProgress/create", %( :$token ));
}

#| Send $/progress notification with kind => 'begin'
method progress-begin($token, Str $title, Str :$message?, Int :$percentage?, Bool :$cancellable = False --> Nil) {
    my %value = %(
        kind => "begin",
        :$title,
        :$cancellable
    );
    %value<message> = $message if $message.defined;
    %value<percentage> = $percentage if $percentage.defined;
    self.notify('$/progress', %( :$token, :%value ));
}

#| Send $/progress notification with kind => 'report'
method progress-report($token, Str :$message?, Int :$percentage?, Bool :$cancellable? --> Nil) {
    my %value = %( kind => "report" );
    %value<message> = $message if $message.defined;
    %value<percentage> = $percentage if $percentage.defined;
    %value<cancellable> = $cancellable if $cancellable.defined;
    self.notify('$/progress', %( :$token, :%value ));
}

#| Send $/progress notification with kind => 'end'
method progress-end($token, Str :$message? --> Nil) {
    my %value = %( kind => "end" );
    %value<message> = $message if $message.defined;
    self.notify('$/progress', %( :$token, :%value ));
}

