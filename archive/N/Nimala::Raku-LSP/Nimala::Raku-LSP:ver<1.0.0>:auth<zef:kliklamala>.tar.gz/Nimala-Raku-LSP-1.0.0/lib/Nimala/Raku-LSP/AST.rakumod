unit module Nimala::Raku-LSP::AST;

class Node is export {
    has Str $.type is rw;
    has Str $.name is rw;
    has Str $.detail is rw;
    has Int $.from is rw = 0;
    has Int $.to is rw = 0;
    has Any $.doc is rw;
    has Hash $.range is rw;
    has Node @.children is rw;
    has Str @.supertypes is rw = Array[Str].new;
    has Str $.return_type is rw = "";

    multi method range(--> Hash) is rw {
        if !$!range.defined && $!doc.defined && $!doc.can('position-at') {
            $!range = hash(
                start => $!doc.position-at($!from // 0),
                end   => $!doc.position-at($!to // 0)
            );
        }
        $!range //= hash(
            start => hash( line => 0, character => 0 ),
            end   => hash( line => 0, character => 0 )
        );
        return-rw $!range;
    }
    multi method range($doc --> Hash) {
        if $doc.defined && $doc.can('position-at') {
            $!range //= hash(
                start => $doc.position-at($!from // 0),
                end   => $doc.position-at($!to // 0)
            );
        }
        return self.range;
    }

    proto method to-hash(|) {*}
    multi method to-hash(--> Hash) {
        return self.to-hash(Any);
    }
    multi method to-hash($doc --> Hash) {
        return %( type => "Error" ) unless self.defined;
        return %(
            type => $!type,
            name => $!name // "",
            detail => $!detail // "",
            return_type => $!return_type // "",
            range => self.range($doc),
            children => @!children.grep(*.defined).map({ $_.to-hash($doc) }).Array,
            supertypes => @!supertypes
        );
    }
}
