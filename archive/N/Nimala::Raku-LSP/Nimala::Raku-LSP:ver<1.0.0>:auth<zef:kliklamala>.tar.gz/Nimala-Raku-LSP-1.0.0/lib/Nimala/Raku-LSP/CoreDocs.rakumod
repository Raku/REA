unit module Nimala::Raku-LSP::CoreDocs;

use DBIish;
use JSON::Fast;

#| Expected schema version stored in schema_meta table
constant SCHEMA-VERSION = 1;

#| Markdown truncation limit (chars)
constant MD-TRUNCATE = 2000;

my $db;
my Bool $db-ok = False;
my Lock $lock .= new;
my %stmts;

sub get-stmt(Str $sql) {
    # Called under $lock
    return %stmts{$sql} if %stmts{$sql}:exists;
    my $sth = try { $db.prepare($sql) };
    %stmts{$sql} = $sth if $sth;
    return $sth;
}

sub db-path(--> IO::Path) {
    with %?RESOURCES<core-docs.db> {
        my IO::Path $p = .IO;
        return $p if $p.e;
    }
    my IO::Path $repo-res = $?FILE.IO.parent(4).child("resources").child("core-docs.db");
    return $repo-res if $repo-res.e;
    return IO::Path;
}

sub open-db(--> Bool) {
    return $db-ok if $db.defined;

    my IO::Path $path = db-path();
    unless $path.defined && $path.e {
        return False;
    }

    $db = try { DBIish.connect("SQLite", database => $path.Str, :RaiseError) };
    unless $db.defined {
        return False;
    }

    # Check schema version
    my $sth = try { $db.prepare("SELECT version FROM schema_meta LIMIT 1") };
    return False unless $sth;
    try { $sth.execute };
    my $row = try { $sth.row };
    $sth.finish;

    if !$row || $row[0].Int != SCHEMA-VERSION {
        try { $db.dispose; }
        $db = Any;
        return False;
    }

    $db-ok = True;
    return True;
}

#| Append a docs.raku.org link footer for a given type
sub docs-url(Str $type --> Str) {
    "\n\n---\n[Full documentation on docs.raku.org](https://docs.raku.org/type/$type)"
}

#| Truncate markdown to MD-TRUNCATE characters, appending a note
sub maybe-truncate(Str $md, Str $type --> Str) {
    if $md.chars > MD-TRUNCATE {
        return $md.substr(0, MD-TRUNCATE) ~ "\n\n*[Documentation truncated]*" ~ docs-url($type);
    }
    $md ~ docs-url($type)
}

#| Get rendered markdown for a method/routine/constant on a type.
#| Returns "" when not found or DB unavailable.
our sub get-doc(Str $type, Str $method --> Str) is export {
    return "" unless $lock.protect({ open-db() });
    my Str $result = "";
    $lock.protect: {
        my $sth = get-stmt(
            "SELECT s.doc_md FROM symbols s JOIN types t ON t.id = s.type_id " ~
            "WHERE t.name = ? AND s.name = ? LIMIT 1"
        );
        return unless $sth;
        try { $sth.execute($type, $method) };
        my $row = try { $sth.row };
        $sth.finish;
        $result = $row[0].Str if $row && $row[0].defined;
    }
    $result
}

#| Get method list for completion on a given type.
#| Returns a list of hashes with 'name' and 'detail' keys.
our sub get-core-methods(Str $type --> Positional) is export {
    return () unless $lock.protect({ open-db() });
    my @methods;
    $lock.protect: {
        my $sth = get-stmt(
            "SELECT s.name, s.signatures FROM symbols s JOIN types t ON t.id = s.type_id " ~
            "WHERE t.name = ? ORDER BY s.name"
        );
        return unless $sth;
        try { $sth.execute($type) };
        while (my $row = try { $sth.row }) {
            last unless $row;
            my Str $name = $row[0].Str;
            my Str $sig-json = $row[1] // "[]";
            my @sigs = try { from-json($sig-json).grep(Str) } // ();
            my Str $detail = @sigs ?? @sigs[0] !! "$type method";
            @methods.push: %( name => $name, detail => $detail );
        }
        $sth.finish;
    }
    @methods
}

#| Get intro documentation for a type (title, subtitle, intro paragraphs).
#| Returns "" when not found or DB unavailable.
our sub get-doc-type(Str $type --> Str) is export {
    return "" unless $lock.protect({ open-db() });
    my Str $result = "";
    $lock.protect: {
        my $sth = get-stmt(
            "SELECT title, subtitle, intro_md, parent, roles FROM types WHERE name = ? LIMIT 1"
        );
        return unless $sth;
        try { $sth.execute($type) };
        my $row = try { $sth.row };
        $sth.finish;
        return unless $row;

        my Str $md = "";
        $md ~= "# " ~ $row[0].Str ~ "\n\n" if $row[0].defined && $row[0].Str ne "";
        $md ~= "*" ~ $row[1].Str ~ "*\n\n" if $row[1].defined && $row[1].Str ne "";
        if $row[3].defined && $row[3].Str ne "" {
            $md ~= "**Inherits from:** `" ~ $row[3].Str ~ "`\n\n";
        }
        if $row[4].defined && $row[4].Str ne "" && $row[4].Str ne "[]" {
            my @roles = try { from-json($row[4].Str).grep(Str) } // ();
            $md ~= "**Does:** " ~ @roles.map({ "`$_`" }).join(", ") ~ "\n\n" if @roles;
        }
        $md ~= $row[2].Str if $row[2].defined && $row[2].Str ne "";
        $result = maybe-truncate($md, $type);
    }
    $result
}

#| Get documentation for a pragma by name (e.g. "strict", "MONKEY-SEE-NO-EVAL").
#| Returns "" when not found or DB unavailable.
our sub get-doc-pragma(Str $name --> Str) is export {
    return "" unless $lock.protect({ open-db() });
    my Str $result = "";
    $lock.protect: {
        my $sth = get-stmt("SELECT doc_md FROM pragmas WHERE name = ? LIMIT 1");
        return unless $sth;
        try { $sth.execute($name) };
        my $row = try { $sth.row };
        $sth.finish;
        $result = $row[0].Str if $row && $row[0].defined;
    }
    $result
}

#| Get documentation for a top-level independent routine (e.g. "say", "EVAL").
#| Returns "" when not found or DB unavailable.
our sub get-doc-routine(Str $name --> Str) is export {
    return "" unless $lock.protect({ open-db() });
    my Str $result = "";
    $lock.protect: {
        my $sth = get-stmt("SELECT doc_md FROM independent_routines WHERE name = ? LIMIT 1");
        return unless $sth;
        try { $sth.execute($name) };
        my $row = try { $sth.row };
        $sth.finish;
        $result = $row[0].Str if $row && $row[0].defined;
    }
    $result
}

END {
    $lock.protect: {
        for %stmts.values -> $sth {
            try { $sth.dispose if $sth.defined; }
        }
        %stmts = ();
        try { $db.dispose if $db.defined; }
    }
}
