#| Role handling workspace and document navigation requests:
#| documentSymbol, definition, references, workspace/symbol,
#| workspaceFolders and executeCommand.
unit role Nimala::Raku-LSP::Handler::Navigation;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use nqp;
use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Workspace;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::URI;






#| Handle textDocument/documentSymbol request.
#| Helper to strip non-standard fields (like supertypes) and format standard DocumentSymbol
sub clean-document-symbol(%sym --> Hash) {
    my %clean = hash(
        name           => %sym<name>,
        kind           => %sym<kind>,
        range          => %sym<range>,
        selectionRange => %sym<selectionRange> // %sym<range>
    );
    %clean<detail> = %sym<detail> if %sym<detail>.defined && %sym<detail> ne "";
    if %sym<children> && %sym<children>.elems > 0 {
        %clean<children> = %sym<children>.map({ clean-document-symbol(%$_) }).Array;
    }
    return %clean;
}

#| Handle textDocument/documentSymbol request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentSymbol>
method textDocument-documentSymbol(:%textDocument, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    if $doc {
        my Any @syms = extract-symbols($doc);
        return @syms.map({ clean-document-symbol(%$_) }).Array;
    }
    return [].Array;
}

#| Handle textDocument/definition request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_definition>
method textDocument-definition(:%textDocument, :%position, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Str $word = get-word-at($doc, %position<line>, %position<character>);
    return [].Array unless $word;

    return [].Array if is-in-comment-or-string($doc, %position<line>, %position<character>);

    my Str $search-word = $word;
    my Str $obj = get-method-call-context($doc, %position<line>, %position<character>);
    if $obj {
        my Any $type = find-variable-type($doc, $obj, %position<line>, %position<character>, self.index);
        if $type {
            my Str $bare-word = $word.subst(/^ \. /, '');
            my $member-sym = self.index.find-member-symbol($type, $bare-word);
            if $member-sym && $member-sym<uri> && $member-sym<range> {
                return [ $%(:uri($member-sym<uri>), :range($member-sym<range>)) ].Array;
            }
            $search-word = "$type\::$bare-word";
        }
    }

    my Any @locations = find-definition($doc, $word);
    if @locations {
        my Any @mapped = @locations.map({ hash( uri => $uri, range => $_<range> ) });
        return @mapped.Array;
    }

    my Any @global = self.index.find-symbol($search-word);
    if !@global && $search-word ne $word {
        # Fallback to method name without type if typed search fails
        @global = self.index.find-symbol($word);
    }
    my IO::Path $project-root;
    if self.root-path.defined && self.root-path.chars {
        $project-root = self.root-path.IO;
    } elsif $doc && $doc.uri.starts-with('file:') {
        my IO::Path $dir = uri-to-path($doc.uri).parent;
        for 0..5 {
            if $dir.child('META6.json').e || $dir.child('lib').e {
                $project-root = $dir;
                last;
            }
            last if $dir.parent eq $dir;
            $dir = $dir.parent;
        }
    }

    if !@global && $doc && $project-root.defined {
        for $doc.text.comb(/ ^^ \s* 'use' \s+ <[\w\:\-]>+ /) -> $mod-line {
            if $mod-line ~~ / 'use' \s+ (<[\w\:\-]>+) / {
                my Str $mod = $0.Str;
                my IO::Path $local-file = resolve-module-file($mod, root => $project-root);
                if (try { $local-file.e && $local-file.f }) {
                    self.index.refresh-from-disk($local-file);
                }
            }
        }
        @global = self.index.find-symbol($search-word);
        if !@global && $search-word ne $word {
            @global = self.index.find-symbol($word);
        }
    }
    @global = @global.grep({ ($_<uri> // '') ne '' }).Array;
    if @global {
        return @global.map({ $%(:uri($_<uri>), :range($_<range>)) }).Array;
    }

    # Fallback: Check if word is a module name and resolves to a local file
    if $project-root.defined {
        my IO::Path $mod-file = resolve-module-file($word, root => $project-root);
        if (try { $mod-file.e && $mod-file.f }) {
            return [ $%(:uri(path-to-uri($mod-file)), :range($%(:start($%(:line(0), :character(0))), :end($%(:line(0), :character(0)))))) ].Array;
        }
    }

    return [].Array;
}

#| Handle textDocument/declaration request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_declaration>
method textDocument-declaration(:%textDocument, :%position, *%other --> Array) {
    return self.textDocument-definition(:%textDocument, :%position, |%other);
}

#| Handle textDocument/documentLink request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentLink>
method textDocument-documentLink(:%textDocument, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Any @links;
    my Int $line-count = $doc.lines-count;

    for 0 ..^ $line-count -> Int $line-num {
        my Str $line = $doc.line-text($line-num);

        # 1. Detect Web URLs (http:// or https://)
        for $line ~~ m:g/ (https? \:\/\/ <[a..zA..Z0..9_\-\.\:\/\?\#\[\]\@\!\$\&\'\(\)\*\+\,\;\=\%]>+) / -> $match {
            my Str $raw-url = $match.Str;
            my Int $start-col = utf16-length($line.substr(0, $match.from));
            while $raw-url ~~ / <[\)\.\,\;\>\]\"\'\:]> $/ {
                $raw-url = $raw-url.chop;
            }
            if $raw-url {
                my Int $end-col = $start-col + utf16-length($raw-url);
                @links.push(hash(
                        range => hash(
                            start => hash(line => $line-num, character => $start-col),
                            end   => hash(line => $line-num, character => $end-col)
                        ),
                        target => $raw-url,
                        tooltip => "Open $raw-url"
                ));
            }
        }

        # 2. Detect `use` or `need` module statements
        if $line ~~ /^ \s* (use|need) \s+ (<[a..zA..Z0..9_\-\:\:]>+) / {
            my Str $mod-name = $1.Str;
            my Int $start-col = utf16-length($line.substr(0, $1.from));
            my Int $end-col = utf16-length($line.substr(0, $1.to));

            my Str $target-uri = "";
            # Try to resolve to local project file
            if self.root-path {
                my IO::Path $mod-file = resolve-module-file($mod-name, root => self.root-path.IO);
                if $mod-file.f {
                    $target-uri = path-to-uri($mod-file);
                }
            }

            # If not in local root-path, check relative to document's directory
            if !$target-uri && $uri.starts-with('file://') {
                my IO::Path $doc-file = uri-to-path($uri);
                my IO::Path $dir = $doc-file.parent;
                for 0..3 -> $i {
                    my IO::Path $check-dir = $dir;
                    $check-dir = $check-dir.parent($i) if $i > 0;
                    my IO::Path $mod-file = resolve-module-file($mod-name, root => $check-dir);
                    if $mod-file.f {
                        $target-uri = path-to-uri($mod-file);
                        last;
                    }
                }
            }

            if $target-uri {
                @links.push(hash(
                        range => hash(
                            start => hash(line => $line-num, character => $start-col),
                            end   => hash(line => $line-num, character => $end-col)
                        ),
                        target => $target-uri,
                        tooltip => "Go to $mod-name"
                ));
            }
        }
    }

    return @links.Array;
}

#| Handle textDocument/typeDefinition request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_typeDefinition>
method textDocument-typeDefinition(:%textDocument, :%position, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Str $word = get-word-at($doc, %position<line>, %position<character>);
    return [].Array unless $word;

    return [].Array if is-in-comment-or-string($doc, %position<line>, %position<character>);

    my Str $target-expr = $word;
    my Str $obj = get-method-call-context($doc, %position<line>, %position<character>);
    if $obj {
        $target-expr = "$obj.$word";
    }

    my Str $type-name = find-variable-type($doc, $target-expr, %position<line>, %position<character>, self.index);
    $type-name ~~ s/ \: <[DU_]> $// if $type-name;

    # 1. Untyped / Any / Mu
    if !$type-name || $type-name eq 'Any' || $type-name eq 'Mu' {
        if self.can('client') && self.client {
            self.client.show-message(Info, "No explicit type defined for '$word'" ~ ($type-name ?? " ($type-name)" !! "") ~ ".");
        }
        return [].Array;
    }

    # 2. Raku Core types check
    my constant %CORE-TYPES = <
    Any Mu Int Num Str Bool Array Hash List Seq Pair Range
    Regex Match Callable Routine Sub Method Block Code Complex
    Rational Rat FatRat Duration Instant Date DateTime
    IO IO::Path IO::Handle Supplier Supply Promise Channel Lock Thread
    Junction Set Bag Mix Map Baggy Setty Mixy Blob Buf
    Attribute Parameter Signature Capture ValueObjAt Positionable
    Associative Iterable Positional
    >.Set;

    my Bool $is-core = %CORE-TYPES{$type-name} // False;

    if $is-core {
        if self.can('client') && self.client {
            my Str $doc-url = "https://docs.raku.org/type/$type-name";
            self.client.show-document(uri => $doc-url, external => True);
        }
        return [].Array;
    }

    # 3. User-defined types
    my Any @global = self.index.find-symbol($type-name);
    if @global {
        my @locs;
        for @global -> $s {
            if $s<uri> && $s<range> {
                @locs.push: %(
                    uri   => $s<uri>,
                    range => $s<range>
                );
            }
        }
        return @locs.Array;
    }

    return [].Array;
}

#| Handle textDocument/references request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_references>
method textDocument-references(:%textDocument, :%position, :%context, :$_id, :$_token, *%other --> Any) {
    my $token = $_token // ($_id.defined ?? self.get-request-token($_id) !! (%other<id>:exists ?? self.get-request-token(%other<id>) !! CancellationToken));
    if $token && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }

    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Document $current-doc = self.doc-store.get($uri);
    if $current-doc && $current-doc.version > $doc.version {
        X::LSP::ContentModified.new.throw;
    }

    my Str $name = get-word-at($doc, %position<line>, %position<character>);
    return [].Array unless $name;

    my Bool $include-decl = (%context<includeDeclaration> // True).Bool;
    my @results = self.index.find-references-everywhere(
        $name,
        doc-store => self.doc-store,
        :$token,
        include-declaration => $include-decl,
        doc-uri => $uri,
        line => +%position<line>,
        character => +%position<character>
    ).Array;

    if $token && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }

    $current-doc = self.doc-store.get($uri);
    if $current-doc && $current-doc.version > $doc.version {
        X::LSP::ContentModified.new.throw;
    }

    return @results.map({ %$_ }).Array;
}

#| Handle textDocument/documentHighlight request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentHighlight>
method textDocument-documentHighlight(:%textDocument, :%position, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Str $word = get-word-at($doc, %position<line>, %position<character>);
    return [].Array unless $word;

    return [].Array if is-in-comment-or-string($doc, %position<line>, %position<character>);

    my Any @refs = find-references($doc, $word);
    my Any @highlights = @refs.map({
            hash(
                range => $_<range>,
                kind => 1
            )
    });

    return @highlights.map({ %$_ }).Array;
}

#| Handle textDocument/implementation request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_implementation>
method textDocument-implementation(:%textDocument, :%position, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Str $word = get-word-at($doc, %position<line>, %position<character>);
    return [].Array unless $word;

    return [].Array if is-in-comment-or-string($doc, %position<line>, %position<character>);

    my Any @symbols = extract-symbols($doc);
    my Any $symbol-at-cursor;

    sub find-sym(@list --> Nil) {
        for @list -> Any $s {
            my Int $sl = $s<range><start><line>;
            my Int $sc = $s<range><start><character>;
            my Int $el = $s<range><end><line>;
            my Int $ec = $s<range><end><character>;
            my Int $l  = %position<line>;
            my Int $c  = %position<character>;

            my Bool $in-range = False;
            if $l > $sl && $l < $el { $in-range = True }
            elsif $l == $sl && $l == $el { $in-range = ($c >= $sc && $c <= $ec) }
            elsif $l == $sl { $in-range = $c >= $sc }
            elsif $l == $el { $in-range = $c <= $ec }

            if $in-range && $s<name> eq $word {
                $symbol-at-cursor = $s;
            }
            find-sym($s<children>) if $s<children>;
        }
    }
    find-sym(@symbols);

    my Any @results;
    my Bool %seen-res{Str};

    # Case A: Cursor is over a method inside a role/interface
    if $symbol-at-cursor && $symbol-at-cursor<kind> == 6 { # Method
        my Str $enclosing-type;
        sub find-enclosing(@list, Any $target --> Nil) {
            for @list -> Any $parent {
                if $parent<children> {
                    for @($parent<children>) -> Any $child {
                        if $child === $target || ($child<name> eq $target<name> && $child<range> eq $target<range>) {
                            $enclosing-type = $parent<name> if $parent<kind> == 5 || $parent<kind> == 11;
                            return;
                        }
                    }
                    find-enclosing($parent<children>, $target) unless $enclosing-type;
                }
            }
        }
        find-enclosing(@symbols, $symbol-at-cursor);

        if $enclosing-type {
            if self.index {
                for self.index.subtypes-of($enclosing-type) -> ($u, $s) {
                    if $s<children> {
                        for @($s<children>) -> Any $c {
                            if $c<kind> == 6 && $c<name> eq $word {
                                my Str $key = "$u:{$c<range><start><line>}:{$c<range><start><character>}";
                                unless %seen-res{$key} {
                                    %seen-res{$key} = True;
                                    @results.push: hash( uri => $u, range => $c<range> );
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    # Case B: Symbol is a Class/Role name or general type lookup
    my Str $target-type-name = $word;
    if self.index {
        for self.index.subtypes-of($target-type-name) -> ($u, $s) {
            my Str $key = "$u:{$s<range><start><line>}:{$s<range><start><character>}";
            unless %seen-res{$key} {
                %seen-res{$key} = True;
                @results.push: hash( uri => $u, range => $s<range> );
            }
        }
    }

    return @results.map({ %$_ }).Array;
}

#| Handle workspace/symbol request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_symbol>
method workspace-symbol(:$query, :$_id, :$_token, *%other --> Any) {
    my $token = $_token // ($_id.defined ?? self.get-request-token($_id) !! (%other<id>:exists ?? self.get-request-token(%other<id>) !! CancellationToken));
    if $token && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }
    my Any @res = self.index.query-symbols($query);
    if $token && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }
    return @res.map({ %$_ }).Array;
}

#| Handle workspace/workspaceFolders request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_workspaceFolders>
method workspace-workspaceFolders(*%other --> Array) {
    if self.workspace-folders && self.workspace-folders.elems > 0 {
        return self.workspace-folders;
    } elsif self.root-path {
        return [ $%(:uri(path-to-uri(self.root-path)), :name(self.root-path.IO.basename)) ].Array;
    }
    return [].Array;
}


