#| Main LSP handler class.
#| Delegates all request/notification handling to focused roles.
unit class Nimala::Raku-LSP::Handler:ver<1.0.0>;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Workspace;

use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::Handler::Base;
use Nimala::Raku-LSP::Handler::Lifecycle;
use Nimala::Raku-LSP::Handler::Sync;
use Nimala::Raku-LSP::Handler::Navigation;
use Nimala::Raku-LSP::Handler::Intelligence;
use Nimala::Raku-LSP::Handler::SemanticTokens;
use Nimala::Raku-LSP::Handler::EditorFeatures;
use Nimala::Raku-LSP::Handler::Diagnostics;
use Nimala::Raku-LSP::Handler::Formatting;
use Nimala::Raku-LSP::Handler::Refactoring;
use Nimala::Raku-LSP::Handler::Hierarchy;
use Nimala::Raku-LSP::Handler::CodeLens;
use Nimala::Raku-LSP::SymbolDB;

also does Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Lifecycle;
also does Nimala::Raku-LSP::Handler::Sync;
also does Nimala::Raku-LSP::Handler::Navigation;
also does Nimala::Raku-LSP::Handler::Intelligence;
also does Nimala::Raku-LSP::Handler::SemanticTokens;
also does Nimala::Raku-LSP::Handler::EditorFeatures;
also does Nimala::Raku-LSP::Handler::Diagnostics;
also does Nimala::Raku-LSP::Handler::Formatting;
also does Nimala::Raku-LSP::Handler::Refactoring;
also does Nimala::Raku-LSP::Handler::Hierarchy;
also does Nimala::Raku-LSP::Handler::CodeLens;

has LSPState $!state = Uninitialized;
has DocumentStore $!doc-store = DocumentStore.new;
has Nimala::Raku-LSP::SymbolDB $.db is rw .= new;
has ProjectIndex  $!index;
has Nimala::Raku-LSP::Client $!client;
has Str $!root-path;
has Array $.workspace-folders is rw = [].Array;
has Int %!latest-version{Str} = %();
method cache(--> Nimala::Raku-LSP::SymbolDB) is rw { $!db }
has Hash $.configuration is rw = %();
has Hash $.client-capabilities is rw = %();
has &.exit-handler is rw;
has Int $.exit-code is rw;
has Any $.dispatcher is rw;

has Lock $!token-lock = Lock.new;
has %!request-tokens = %();
has %!progress-tokens = %();

has Lock $!progress-lock = Lock.new;
has Supplier $!progress-supplier = Supplier.new;
has Supply $.progress-supply = $!progress-supplier.Supply;
has %!active-progress = %();

submethod TWEAK(Nimala::Raku-LSP::Client :$client, IO::Handle :$out = $*OUT, ProjectIndex :$index) {
    $!client = $client // Nimala::Raku-LSP::Client.new(:$out);
    $!index = $index // ProjectIndex.new(:db($!db), :root-path($!root-path));
    $!index.db = $!db;
    $!index.root-path = $!root-path if $!root-path;
    $!index.set-document-provider(sub (Str $u) {
            my $d = $!doc-store.get($u);
            ($d && $d.is-open) ?? $d !! Any
    });
}

method state(--> LSPState) is rw  { $!state     }
method root-path() is rw {
    Proxy.new(
        FETCH => -> $ { $!root-path },
        STORE => -> $, $val {
            $!root-path = $val.defined ?? $val.Str !! Str;
            $!index.root-path = $!root-path if $!index.defined;
        }
    )
}
method doc-store(--> DocumentStore) { $!doc-store }
method client(--> Nimala::Raku-LSP::Client) { $!client    }
method index(--> ProjectIndex) { $!index     }
method latest-version()  is rw { %!latest-version }

#| Queries configuration value using dot-notation with optional default
method get-config(Str $key, $default = Any) {
    return $default unless $!configuration;
    my @parts = $key.split('.');

    # 1. Try prefixed under 'raku.' if not already starting with 'raku.'
    if @parts[0] ne 'raku' && ($!configuration<raku> ~~ Hash) {
        my $val = self!lookup-config-path($!configuration<raku>, @parts);
        return $val if $val.defined;
    }

    # 2. Try direct path
    my $val = self!lookup-config-path($!configuration, @parts);
    return $val if $val.defined;

    return $default;
}

method !lookup-config-path($node, @parts) {
    my $curr = $node;
    for @parts -> $part {
        return Nil unless $curr ~~ Hash;
        return Nil unless $curr{$part}:exists;
        $curr = $curr{$part};
    }
    return $curr;
}

method register-request-token($id, CancellationToken $token --> Nil) {
    return unless $id.defined;
    $!token-lock.protect: {
        %!request-tokens{$id.Str} = $token;
    };
}

method cancel-request-token($id --> Bool) {
    return False unless $id.defined;
    my $token;
    $!token-lock.protect: {
        $token = %!request-tokens{$id.Str};
    };
    if $token {
        $token.cancel();
        return True;
    }
    return False;
}

method unregister-request-token($id --> Nil) {
    return unless $id.defined;
    $!token-lock.protect: {
        %!request-tokens{$id.Str}:delete;
    };
}

method get-request-token($id --> CancellationToken) {
    return CancellationToken unless $id.defined;
    $!token-lock.protect: {
        return %!request-tokens{$id.Str} // CancellationToken;
    };
}

method register-progress-token($token-id, CancellationToken $token --> Nil) {
    return unless $token-id.defined;
    $!token-lock.protect: {
        %!progress-tokens{$token-id.Str} = $token;
    };
}

method cancel-progress-token($token-id --> Bool) {
    return False unless $token-id.defined;
    my $token;
    $!token-lock.protect: {
        $token = %!progress-tokens{$token-id.Str};
    };
    if $token {
        $token.cancel();
        return True;
    }
    return False;
}

method unregister-progress-token($token-id --> Nil) {
    return unless $token-id.defined;
    $!token-lock.protect: {
        %!progress-tokens{$token-id.Str}:delete;
    };
}

method get-progress-token($token-id --> CancellationToken) {
    return CancellationToken unless $token-id.defined;
    $!token-lock.protect: {
        return %!progress-tokens{$token-id.Str} // CancellationToken;
    };
}

method progress-supplier(--> Supplier) { $!progress-supplier }
method progress-lock(--> Lock) { $!progress-lock }
method active-progress(--> Hash) {
    $!progress-lock.protect: {
        return %!active-progress.clone;
    }
}
method active-progress-raw(--> Hash) { %!active-progress }

#| Creates and starts a managed RAII ProgressScope
method start-progress(Str $title, Str :$token?, Int :$total = 0, Bool :$cancellable = False --> ProgressScope) {
    my Str $tok = $token // ("progress-" ~ $*PID ~ "-" ~ (state Int $c = 0)++);
    my CancellationToken $cancel-token;
    if $cancellable {
        $cancel-token = CancellationToken.new;
        self.register-progress-token($tok, $cancel-token);
    }

    my Bool $enabled = (self.client-capabilities<window><workDoneProgress> // False).Bool;
    my Promise $ready-prom;

    if $enabled {
        my $create-p = self.client.request-async("window/workDoneProgress/create", %( :token($tok) ));
        $ready-prom = $create-p.then(-> $res {
                if $res.status == Kept {
                    my $v = try { $res.result };
                    if ($v ~~ Hash) && ($v<error>:exists) {
                        False;
                    } else {
                        self.client.progress-begin($tok, $title, :$cancellable, :percentage($total > 0 ?? 0 !! Nil));
                        True;
                    }
                } else {
                    False;
                }
            });
    }

    return ProgressScope.new(
        token => $tok,
        title => $title,
        total => $total,
        client => self.client,
        cancel-token => $cancel-token,
        :$enabled,
        :$ready-prom,
        on-finish => -> $t {
            self.unregister-progress-token($t) if $cancellable;
        }
    );
}
