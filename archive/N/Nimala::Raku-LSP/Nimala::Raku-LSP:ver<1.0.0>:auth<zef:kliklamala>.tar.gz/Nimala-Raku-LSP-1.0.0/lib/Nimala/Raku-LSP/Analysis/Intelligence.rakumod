unit module Nimala::Raku-LSP::Analysis::Intelligence;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::AST;
use Nimala::Raku-LSP::CoreDocs;
use Nimala::Raku-LSP::Analysis::Symbols;
use Nimala::Raku-LSP::Analysis::Cursor;

#| Returns symbols visible at the given cursor position based on lexical scoping.
our proto sub get-visible-symbols(|) is export {*}
multi sub get-visible-symbols(Document $doc, Int $line, Int $character --> Positional) {
    my $target-pos = $doc.position-to-offset($line, $character);
    my @tree = extract-native-symbols($doc);
    if !@tree {
        my @syms = extract-symbols($doc);
        my @visible;
        sub walk-tier1($sym, $parent-sym) {
            my Str $name = ($sym<name> // "").Str;
            my Int $kind = ($sym<kind> // 1).Int;
            my Bool $is-var = $kind == 13 || $kind == 8 || $kind == 7;
            my Bool $in-scope = False;
            if !$parent-sym {
                $in-scope = True;
            } else {
                my $pr = $parent-sym<range>;
                if $pr && $pr<start> && $pr<end> {
                    my Int $p-sl = +$pr<start><line>;
                    my Int $p-sc = +$pr<start><character>;
                    my Int $p-el = +$pr<end><line>;
                    my Int $p-ec = +$pr<end><character>;
                    if ($p-sl < $line || ($p-sl == $line && $p-sc <= $character))
                    && ($line < $p-el || ($line == $p-el && $character < $p-ec)) {
                        $in-scope = True;
                    }
                }
            }

            if $in-scope && $name ne "" {
                if $is-var {
                    my $sr = $sym<range>;
                    my Int $v-sl = +($sr<start><line> // 0);
                    my Int $v-sc = +($sr<start><character> // 0);
                    if $v-sl < $line || ($v-sl == $line && $v-sc <= $character) {
                        @visible.push($sym);
                    }
                } else {
                    @visible.push($sym);
                }
            }

            if $sym<children> {
                for @($sym<children>) -> $child {
                    walk-tier1($child, ($kind == 5 || $kind == 2 || $kind == 11 || $kind == 6 || $kind == 12) ?? $sym !! $parent-sym);
                }
            }
        }
        for @syms -> $s {
            walk-tier1($s, Nil);
        }
        return @visible;
    }

    my @visible;
    sub walk-node($node, $parent-block) {
        my $k = $node<kind> // "";
        my $is-block = $k eq "block" || $k eq "package_decl" || $k eq "routine_decl";

        my $is-decl = $k eq "variable_decl" || $k eq "routine_decl" || $k eq "type_decl" || $k eq "package_decl";
        if $is-decl && $node<name> {
            my $in-scope = False;
            if !$parent-block {
                $in-scope = True;
            } elsif $parent-block<from> <= $target-pos <= $parent-block<to> {
                $in-scope = True;
            }
            if $in-scope {
                if ($k eq "variable_decl") {
                    @visible.push($node) if ($node<from> // 0) <= $target-pos;
                } else {
                    @visible.push($node);
                }
            }
        }

        my $next-block = $is-block ?? $node !! $parent-block;
        if $node<children> {
            for $node<children>.Array -> $child {
                walk-node($child, $next-block);
            }
        }
    }
    for @tree -> $root {
        walk-node($root, Nil);
    }
    return @visible;
}
multi sub get-visible-symbols(Str $code, Int $line, Int $character --> Positional) {
    my $doc = Document.new(uri => "", languageId => "raku", version => 0, text => $code);
    return get-visible-symbols($doc, $line, $character);
}

#| Returns True if the cursor position permits keyword completions.
our proto sub is-keyword-position(|) is export {*}
multi sub is-keyword-position(Document $doc, Int $line, Int $character --> Bool) {
    return False if $line < 0 || $line >= $doc.lines-count;

    my $line-text = $doc.line-text($line);
    my Int $grapheme-idx = max(0, min($doc.position-to-offset($line, $character) - $doc.line-offsets[$line], $line-text.chars));
    my $prefix = $line-text.substr(0, $grapheme-idx);
    my $word = get-word-at($doc.text, $line, $character);

    # After a dot '.' -> not keyword position
    return False if $prefix ~~ / \. \s* $word? $/;

    my $stripped = $prefix.subst(/ $word? $ /, '');

    # If after '=' (assignment RHS)
    if $stripped ~~ / '=' \s* $ / || ($stripped ~~ / '=' / && $stripped !~~ / '==' | '!=' | '<=' | '>=' | '=>' | '::=' /) {
        return False;
    }

    # Inside call parens or after '(' or ','
    if $stripped ~~ / '(' <-[\)]>* $ / || $stripped ~~ / ',' \s* $ / {
        return False;
    }

    return True;
}
multi sub is-keyword-position(Str $code, Int $line, Int $character --> Bool) {
    my $doc = Document.new(uri => "", languageId => "raku", version => 0, text => $code);
    return is-keyword-position($doc, $line, $character);
}

use Nimala::Raku-LSP::Analysis::Completion;

#| Returns completion suggestions at the given position.
our proto sub get-completions(|) is export {*}
multi sub get-completions(Str $code, Int $line, Int $character, Any $index = Any --> Positional) {
    my $doc = Document.new(uri => "", languageId => "raku", version => 0, text => $code);
    get-type-aware-completions($doc, $line, $character, $index)
}
multi sub get-completions(Document $doc, Int $line, Int $character, Any $index = Any --> Positional) {
    get-type-aware-completions($doc, $line, $character, $index)
}

#| Returns hover information for a symbol name.
our proto sub get-hover-info(|) is export {*}
multi sub get-hover-info(Str $code, Str $symbol-name) {
    my $doc = Document.new(uri => "", languageId => "raku", version => 0, text => $code);
    get-hover-info($doc, $symbol-name)
}
multi sub get-hover-info(Document $doc, Str $symbol-name) {
    my @symbols = extract-symbols($doc);
    sub search(@list) {
        for @list -> $s {
            if $s<name> && $s<name> eq $symbol-name {
                my $kind-name = do given $s<kind> {
                    when 5 { "class" }
                    when 2 { "module" }
                    when 6 { "method" }
                    when 12 { "subroutine" }
                    when 13 { "variable" }
                    when 14 { "constant" }
                    when 11 { "role" }
                    default { "symbol" }
                };

                my $info = "$kind-name $symbol-name";

                # Check for Pod documentation (#|) above the symbol
                my @docs;
                if $s<range> && $s<range><start> {
                    my $line-idx = $s<range><start><line> - 1;
                    while $line-idx >= 0 {
                        my $l = $doc.line-text($line-idx).trim;
                        if $l.starts-with('#|') {
                            @docs.unshift($l.substr(2).trim);
                        } elsif $l eq '' {
                            # Ignore empty lines between doc and symbol
                        } else {
                            last;
                        }
                        $line-idx--;
                    }
                }

                my $docs = @docs ?? @docs.join("\n") !! "";
                return { code => $info, docs => $docs };
            }
            if $s<children> {
                if search($s<children>) -> $found { return $found; }
            }
        }
        return Nil;
    }
    my $found = search(@symbols);
    if $found { return $found; }

    # Fallback for Raku core types and routines
    my @core-types = <Int Str Num Rat FatRat Complex Bool Array Hash List Seq Pair Map Bag Set Mix Nil Any Mu Match Grammar Exception Date DateTime Duration IO::Path IO::Handle Routine Sub Method Block Regex Thread Promise Channel Supply>;
    my @core-routines = <say print put prompt map grep sort reverse keys values kv pairs elems end push pop shift unshift splice join split match comb substr index rindex chars uc lc tc fc tilde wordcase sprintf printf chomp chop flip slip die warn note slurp spurt open close mkdir rmdir dir run shell exit sleep>;

    if $symbol-name ~~ /^ (.*) '::' (.*?) $/ {
        my $type = ~$0;
        my $meth = ~$1;
        if $type eq any(@core-types) {
            my @mro = %CORE-MRO{$type} ?? %CORE-MRO{$type}.list !! ($type, "Any", "Mu");
            for @mro -> $t {
                my $mro-sym = "$t\::$meth";
                my $docs = Nimala::Raku-LSP::CoreDocs::get-doc($t, $meth);
                if $docs && !$docs.starts-with("No direct documentation")
                && !$docs.starts-with("No detailed documentation")
                && !$docs.starts-with("Documentation for") {
                    return { code => "method $meth (from $t)", docs => $docs };
                }
            }
            my $docs = Nimala::Raku-LSP::CoreDocs::get-doc($type, $meth);
            return { code => "method $meth (from $type)", docs => $docs };
        }
    }

    if $symbol-name eq any(@core-routines) || (my $routine-docs = Nimala::Raku-LSP::CoreDocs::get-doc-routine($symbol-name)) {
        my $docs = $routine-docs // Nimala::Raku-LSP::CoreDocs::get-doc-routine($symbol-name);
        if $docs {
            return { code => "subroutine $symbol-name", docs => $docs };
        }
    }

    if $symbol-name eq any(@core-types) || (my $type-docs = Nimala::Raku-LSP::CoreDocs::get-doc-type($symbol-name)) {
        my $docs = $type-docs // Nimala::Raku-LSP::CoreDocs::get-doc-type($symbol-name);
        if $docs {
            return { code => "class $symbol-name", docs => $docs };
        }
    }

    if my $pragma-docs = Nimala::Raku-LSP::CoreDocs::get-doc-pragma($symbol-name) {
        return { code => "pragma $symbol-name", docs => $pragma-docs };
    }

    return Nil;
}

#| Finds the definition location for a symbol name.
our proto sub find-definition(|) is export {*}
multi sub find-definition(Document $doc, Str $symbol-name --> Positional) {
    my @locations;

    # Fast symbol extraction tree
    my @symbols = try { extract-symbols($doc) } // [];
    sub search(@list) {
        for @list -> $s {
            if $s<name> eq $symbol-name {
                @locations.push: hash( uri => $doc.uri, range => $s<range> );
            }
            search($s<children>) if $s<children>;
        }
    }
    search(@symbols);
    return @locations;
}
multi sub find-definition(Str $code, Str $symbol-name --> Positional) {
    my $doc = Document.new(uri => "", languageId => "raku", version => 0, text => $code);
    return find-definition($doc, $symbol-name);
}


#| Find scope-aware references of a word in the document at the given position.
our proto sub find-scoped-references(|) is export {*}
multi sub find-scoped-references(Document $doc, Int $line, Int $character, Bool :$include-declaration = True --> Positional) {
    my $target-pos = $doc.position-to-offset($line, $character);
    my $word = get-word-at($doc, $line, $character);
    return [] unless $word;

    # For non-variables (sub, method, class, role), fallback to document-wide references
    if $word !~~ /^ <[$@%&]>/ {
        return find-references($doc, $word, :include-declaration($include-declaration));
    }

    my $ast = parse-document($doc);
    return [] unless $ast;

    sub is-scope-node($node) {
        return False unless $node;
        my $t = ($node.type // "").trim;
        return True if $t eq 'Block' || $t eq 'StatementList' || $t eq 'routine-declaration';
        return True if $t eq 'package' || $t eq 'class' || $t eq 'role' || $t eq 'module' || $t eq 'grammar';
        return True if $t eq 'sub' || $t eq 'method' || $t eq 'submethod' || $t eq 'token' || $t eq 'rule' || $t eq 'regex';
        return True if $t.contains('sub') || $t.contains('method') || $t.contains('token') || $t.contains('rule') || $t.contains('regex') || $t.contains('multi');
        return False;
    }

    # Collect all scope nodes in the AST
    my @scopes;
    sub collect-scopes($node) {
        return unless $node;
        if is-scope-node($node) {
            @scopes.push: $node;
        }
        for @($node.children) -> $c {
            collect-scopes($c) if $c;
        }
    }
    collect-scopes($ast);

    # Helper: does this scope declare $word?
    sub find-decl-node($scope, Str $w) {
        sub check-node($n) {
            return Nil unless $n;
            if ($n.type eq 'Variable' || $n.type eq 'Parameter' || $n.type eq 'Field') && ($n.name // '') eq $w {
                return $n;
            }
            for @($n.children) -> $c {
                unless is-scope-node($c) {
                    my $found = check-node($c);
                    return $found if $found;
                }
            }
            return Nil;
        }
        return check-node($scope);
    }

    # Find scopes enclosing target-pos
    my @enclosing = @scopes.grep({ $_.from <= $target-pos <= $_.to })
        .sort({ $^b.from <=> $^a.from || ($^a.to - $^a.from) <=> ($^b.to - $^b.from) });

    my $decl-scope = Nil;
    my $decl-node = Nil;
    for @enclosing -> $s {
        $decl-node = find-decl-node($s, $word);
        if $decl-node.defined {
            $decl-scope = $s;
            last;
        }
    }
    $decl-scope //= (@enclosing.elems ?? @enclosing[*-1] !! $ast);
    $decl-node  //= find-decl-node($decl-scope, $word);

    my Int $decl-from = -1;
    my Int $decl-to   = -1;
    if $decl-node.defined {
        my Int $nf = $decl-node.from // -1;
        my Int $nt = $decl-node.to   // -1;
        if $nf >= 0 && $nt > $nf {
            my Str $snippet = $doc.text.substr($nf, $nt - $nf);
            my $eq-idx = $snippet.index('=');
            my Str $lhs = $eq-idx.defined ?? $snippet.substr(0, $eq-idx) !! $snippet;
            my $var-idx = $lhs.index($word);
            if $var-idx.defined {
                $decl-from = $nf + $var-idx;
                $decl-to   = $decl-from + $word.chars;
            } else {
                $decl-from = $nf;
                $decl-to   = $nt;
            }
        }
    }

    my Int $s-from = $decl-scope.from // 0;
    my Int $s-to   = $decl-scope.to // $doc.text.chars;

    # Find child scopes within $decl-scope that shadow $word
    my @shadows;
    for @scopes -> $s {
        if $s !=== $decl-scope && $s.from >= $s-from && $s.to <= $s-to {
            if find-decl-node($s, $word).defined {
                @shadows.push: ($s.from, $s.to);
            }
        }
    }

    # Pre-calculate Pod block ranges so we ignore references inside documentation
    my @pod-ranges;
    my Bool $in-pod-block = False;
    my Str $pod-block-tag = "";
    my Int $pod-block-start = 0;
    for 0..^$doc.lines-count -> $line-idx {
        my Str $line-text = $doc.line-text($line-idx);
        my Int $line-start = $doc.line-offsets[$line-idx];
        my Int $line-end = ($line-idx + 1 < $doc.line-offsets.elems)
        ?? $doc.line-offsets[$line-idx + 1]
        !! $doc.text.chars;

        if $in-pod-block {
            if $line-text ~~ /^ \s* '=end' \s+ $pod-block-tag / {
                $in-pod-block = False;
                @pod-ranges.push: ($pod-block-start, $line-end);
            }
        } elsif $line-text ~~ /^ \s* '=begin' \s+ (\S+) / {
            $in-pod-block = True;
            $pod-block-tag = ~$0;
            $pod-block-start = $line-start;
        } elsif $line-text ~~ /^ \s* '=' <[a..zA..Z]> / {
            @pod-ranges.push: ($line-start, $line-end);
        }
    }
    if $in-pod-block {
        @pod-ranges.push: ($pod-block-start, $doc.text.chars);
    }

    my $regex = rx/ <!after <[\w\$\@\%\&]> > "$word" <!before <[\w\-]> | \' \w > /;
    my @refs;
    for $doc.text.match($regex, :g) -> $m {
        my Int $mf = $m.from;
        my Int $mt = $m.to;
        next if $mf < $s-from || $mt > $s-to;

        # Check Pod block ranges
        my Bool $in-pod = False;
        for @pod-ranges -> ($pf, $pt) {
            if $pf <= $mf < $pt {
                $in-pod = True;
                last;
            }
        }
        next if $in-pod;

        # Ignore escaped sigils like \$z
        my Int $backslashes = 0;
        my Int $bp = $mf - 1;
        while $bp >= 0 && $doc.text.substr($bp, 1) eq '\\' {
            $backslashes++;
            $bp--;
        }
        next if $backslashes % 2 == 1;

        my Bool $in-shadow = False;
        for @shadows -> ($sh-from, $sh-to) {
            if $sh-from <= $mf && $mt <= $sh-to {
                $in-shadow = True;
                last;
            }
        }
        next if $in-shadow;

        my Bool $is-decl = $decl-from >= 0 && $decl-from <= $mf < $decl-to;
        next if !$include-declaration && $is-decl;

        my $pos = $doc.position-at($mf);
        my $line-num = $pos<line>;
        my Int $l-start = $doc.line-offsets[$line-num];
        my Int $l-next = ($line-num + 1 < $doc.line-offsets.elems) ?? $doc.line-offsets[$line-num + 1] !! $doc.text.chars;
        my Str $l-raw = $doc.text.substr($l-start, $l-next - $l-start);
        my Str $l-clean = $l-raw.subst(/ \r? \n? $ /, '');
        my Int $col = $mf - $l-start;

        next if is-ignored-ref-context($l-clean, $col);

        @refs.push: hash(
            uri => $doc.uri,
            range => hash(
                start => $doc.position-at($mf),
                end   => $doc.position-at($mt)
            ),
            is_decl => $is-decl
        );
    }
    return @refs;
}

multi sub find-scoped-references(Str $code, Int $line, Int $character, Str :$uri = "", Bool :$include-declaration = True --> Positional) {
    my Document $doc = Document.new(uri => $uri, text => $code, version => 1);
    return find-scoped-references($doc, $line, $character, :$include-declaration);
}


#| Find all references of a word in the document (global search, useful for cross-file and function references).
our proto sub find-references(|) is export {*}
multi sub find-references(Document $doc, Str $word, Bool :$include-declaration = True --> Positional) {
    my @refs;
    my %seen-ref;
    require Nimala::Raku-LSP::Analysis::Symbols;
    my @native-syms;
    if $doc.is-open {
        @native-syms = Nimala::Raku-LSP::Analysis::Symbols::flatten-native-tree(
            Nimala::Raku-LSP::Analysis::Symbols::extract-native-symbols($doc)
        );
    } elsif $doc.native-symbols.defined && $doc.native-symbols-version == $doc.version {
        @native-syms = Nimala::Raku-LSP::Analysis::Symbols::flatten-native-tree(@($doc.native-symbols));
    } else {
        @native-syms = [];
    }

    my @decl-spans;
    if @native-syms {
        for @native-syms -> $s {
            my Bool $is-decl = $s<kind> eq 'variable_decl' || $s<kind> eq 'routine_decl' || $s<kind> eq 'package_decl' || $s<kind> eq 'type_decl';
            if $is-decl && ($s<name> // "") eq $word {
                my Int $from = ($s<name-from>.defined) ?? $s<name-from> !! $s<from>;
                my Int $to   = ($s<name-to>.defined)   ?? $s<name-to>   !! $s<to>;
                @decl-spans.push: ($from .. $to);
                if $include-declaration {
                    my Hash $start = $doc.position-at($from);
                    my Hash $end   = $doc.position-at($to);
                    my Str $key = "{$start<line>}-{$start<character>}-{$end<line>}-{$end<character>}";
                    unless %seen-ref{$key} {
                        %seen-ref{$key} = True;
                        @refs.push: hash( uri => $doc.uri, range => hash( :$start, :$end ) );
                    }
                }
            }
        }
        for @native-syms -> $s {
            my Bool $is-usage = $s<kind> eq 'variable_usage' || $s<kind> eq 'name_usage';
            if $is-usage && ($s<name> // "") eq $word {
                my Bool $in-decl = False;
                for @decl-spans -> $span {
                    if $s<from> >= $span.min && $s<to> <= $span.max {
                        $in-decl = True;
                        last;
                    }
                }
                next if $in-decl;

                my Hash $start = $doc.position-at($s<from>);
                my Hash $end   = $doc.position-at($s<to>);
                my Str $key = "{$start<line>}-{$start<character>}-{$end<line>}-{$end<character>}";
                unless %seen-ref{$key} {
                    %seen-ref{$key} = True;
                    @refs.push: hash( uri => $doc.uri, range => hash( :$start, :$end ) );
                }
            }
        }
    }

    # Fallback/merge with custom AST parser for usages that the native parser misses (like postfix ops)
    my $ast = parse-document($doc);
    sub search(Node $n) {
        if $n.name && $n.name eq $word {
            my Bool $is-decl = ($n.type // "") ne 'Usage';
            return if $is-decl && !$include-declaration;

            # If it falls within a native decl span and we exclude declarations, skip
            if !$include-declaration && ($n.from // 0) > 0 {
                my Bool $in-decl = False;
                for @decl-spans -> $span {
                    if ($n.from // 0) >= $span.min && ($n.to // 0) <= $span.max {
                        $in-decl = True;
                        last;
                    }
                }
                return if $in-decl;
            }

            my $line = $n.range<start><line>;
            my $start-char = $n.range<start><character>;
            my $end-char = $n.range<end><line> == $line ?? $n.range<end><character> !! 9999;

            my $overlap = False;
            for @refs -> $r {
                if $r<range><start><line> == $line {
                    if $start-char <= $r<range><end><character> && $end-char >= $r<range><start><character> {
                        $overlap = True;
                        last;
                    }
                }
            }

            unless $overlap {
                my $key = "{$n.range<start><line>}-{$n.range<start><character>}-{$n.range<end><line>}-{$n.range<end><character>}";
                unless %seen-ref{$key} {
                    %seen-ref{$key} = True;
                    @refs.push: hash( uri => $doc.uri, range => $n.range );
                }
            }
        }
        if $n.children {
            search($_) for $n.children;
        }
    }
    search($ast) if $ast;

    return @refs;
}
multi sub find-references(Str $code, Str $word, Str $uri = "", Bool :$include-declaration = True --> Positional) {
    my Document $doc = Document.new(uri => $uri, text => $code, version => 1);
    return find-references($doc, $word, :$include-declaration);
}
