unit module Nimala::Raku-LSP::Workspace;

use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::VendorIndex;
use Nimala::Raku-LSP::Cache;
use Nimala::Raku-LSP::URI;
my Lock $ast-lock = Lock.new;

use Nimala::Raku-LSP::SymbolDB;
use Nimala::Model::SymbolLookup;

class ProjectIndex does Nimala::Model::SymbolLookup is export {
    has Lock $!lock = Lock.new;
    has Lock $!chain-lock = Lock.new;
    has Promise %!chain{Str};
    has Callable $!document-provider;

    has Nimala::Raku-LSP::SymbolDB $.db is rw;
    has Str $.root-path is rw;
    has SetHash $!available-modules;
    has Callable $!on-change;

    method set-on-change(&callback --> Nil) {
        $!on-change = &callback;
    }

    method set-document-provider(&provider --> Nil) {
        $!document-provider = &provider;
    }

    my constant @KEYWORD-EXCLUSIONS = <need require use no import unit v6 lib experimental nqp strict trace fatal MONKEY MONKEY-SEE-NO-EVAL MONKEY-GUTS MONKEY-TYPING Test>;

    has Bool $!modules-scanned = False;
    method !ensure-modules-scanned() {
        return if $!lock.protect: { $!modules-scanned };

        my SetHash $scanned .= new;
        self!scan-system-modules($scanned);
        self!scan-local-modules($scanned);

        $!lock.protect: {
            $!available-modules = $scanned;
            $!modules-scanned = True;
        }
    }

    submethod TWEAK(:$db, :$root-path) {
        $!db = $db if $db.defined;
        $!db //= Nimala::Raku-LSP::SymbolDB.new(:memory);
        $!root-path = $root-path if $root-path.defined;
    }

    method !extract-symbols-and-refs(Str $uri, Str $code, $doc, :@syms is raw, :@refs is raw --> Nil) {
        # Trigger vendor indexing for external dependencies without recursing locally
        for $code.comb(/ ^^ \s* 'use' \s+ <[\w\:\-]>+ /) -> $use-line {
            if $use-line ~~ / 'use' \s+ (<[\w\:\-]>+) / {
                my $mod = $0.Str;
                next if $mod ~~ /^ 'v6' / || $mod eq any(@KEYWORD-EXCLUSIONS);

                my Bool $is-local = False;
                if $!root-path.defined && $!root-path.chars {
                    my IO::Path $local-file = resolve-module-file($mod, root => $!root-path.IO);
                    if (try { $local-file.e && $local-file.f }) {
                        $is-local = True;
                    }
                }

                ensure-indexed($mod, db => $!db) unless $is-local;
            }
        }

        if $doc.defined {
            @syms = ($doc.symbols.defined && $doc.ast-version == $doc.version)
            ?? @($doc.symbols)
            !! (try { extract-symbols($doc) } // []);
        } else {
            @syms = try { extract-symbols($code) } // [];
        }
        if !@syms {
            my @lines = ($doc.defined)
            ?? (0 ..^ $doc.lines-count).map({ $doc.line-text($_) })
            !! $code.split(/\r\n|\r|\n/);
            for @lines.kv -> $line-num, $line {
                my Int $line-len = utf16-length($line);
                if $line ~~ /^^ \s* ['multi' \s+]? ['proto' \s+]? ['only' \s+]?
                $<decl>=[ 'sub' | 'method' | 'submethod' ] \s+
                $<name>=[ <[\w\-\!\^]>+ ]/ {
                    my Str $name = ~$<name>;
                    @syms.push: hash(
                        name => $name,
                        containerName => "",
                        detail => $line.trim,
                        kind => 12,
                        range => hash( start => hash( line => $line-num, character => 0 ),
                            end   => hash( line => $line-num, character => $line-len ) ),
                        selectionRange => hash( start => hash( line => $line-num, character => 0 ),
                            end   => hash( line => $line-num, character => $line-len ) ),
                        children => [],
                        supertypes => []
                    );
                }
                elsif $line ~~ /^^ \s* ['unit' \s+]?
                $<decl>=[ 'class' | 'role' | 'grammar' | 'module' ] \s+
                $<name>=[ <[\w\-]>+ ['::' <[\w\-]>+]* ]/ {
                    my Str $name = ~$<name>;
                    my Int $kind = $<decl> eq 'role' ?? 11 !! 5;
                    @syms.push: hash(
                        name => $name,
                        containerName => "",
                        detail => $line.trim,
                        kind => $kind,
                        range => hash( start => hash( line => $line-num, character => 0 ),
                            end   => hash( line => $line-num, character => $line-len ) ),
                        selectionRange => hash( start => hash( line => $line-num, character => 0 ),
                            end   => hash( line => $line-num, character => $line-len ) ),
                        children => [],
                        supertypes => []
                    );
                }
            }
        }
        if $doc.defined {
            @refs = try { extract-references-for-index($doc, @syms) } // [];
        } else {
            @refs = try { extract-references-for-index($code, $uri, @syms) } // [];
        }
    }

    method update-file(Str $uri, Str $code, $? = Any, Document :$doc? --> Nil) {
        my @syms;
        my @refs;
        self!extract-symbols-and-refs($uri, $code, $doc, :@syms, :@refs);

        my IO::Path $io-path = uri-to-path($uri);
        my Int $mtime = (try { $io-path.e ?? $io-path.modified.Int !! 0 }) // 0;
        my Blob $bytes = $code.encode('utf-8');
        my Int $size  = $bytes.bytes;
        my Str $hash  = hash-buffer($bytes);

        unless $!db.is-open {
            $!db.open-memory();
        }
        $!db.update-file-symbols($uri, $hash, @syms, source => 'shallow', :$mtime, :$size, references => @refs);

        if $!on-change.defined {
            try {
                $!on-change($uri);
                CATCH { default { } }
            }
        }
    }

    #| Refresh file from disk into main tables: returns 'missing', 'unchanged', 'touched', or 'indexed'
    method refresh-from-disk(IO::Path $path --> Str) {
        return 'missing' unless (try { $path.e && $path.f });

        my Str $uri = path-to-uri($path.absolute);
        my Int $mtime = (try { $path.modified.Int }) // 0;
        my Int $size  = (try { $path.s }) // 0;

        unless $!db.is-open {
            $!db.open-memory();
        }

        if $!db.is-file-unchanged($uri, $mtime, $size) {
            return 'unchanged';
        }

        my Blob $bytes = try { $path.slurp(:bin) };
        return 'missing' unless $bytes.defined;
        my Str $hash = hash-buffer($bytes);

        if $!db.touch-file($uri, $hash, $mtime, $size) {
            return 'touched';
        }

        my Str $code = try { $bytes.decode('utf-8') } // (try { $path.slurp } // "");
        self.update-file($uri, $code);
        return 'indexed';
    }

    method enqueue-job(Str $uri, &job --> Promise) {
        my Promise $p;
        $!chain-lock.protect: {
            $p = (%!chain{$uri} // Promise.kept(True)).then({
                    &job();
            });
            %!chain{$uri} = $p;
        }
        return $p;
    }

    method update-buffer(Str $uri --> Promise) {
        return self.enqueue-job($uri, { self!do-update-buffer($uri) });
    }

    method drop-buffer(Str $uri --> Promise) {
        return self.enqueue-job($uri, { self!do-drop-buffer($uri) });
    }

    method chain-refresh-from-disk(IO::Path $path --> Promise) {
        my Str $uri = path-to-uri($path.absolute);
        return self.enqueue-job($uri, { self.refresh-from-disk($path) });
    }

    method chain-remove-file(Str $uri --> Promise) {
        return self.enqueue-job($uri, { self.remove-file($uri) });
    }

    method !do-update-buffer(Str $uri --> Nil) {
        return unless $!document-provider.defined;
        my $doc = $!document-provider($uri);
        return unless $doc.defined;

        unless $!db.is-open {
            $!db.open-memory();
        }

        my Int $current-ver = $!db.get-overlay-version($uri);
        if $current-ver >= 0 && $current-ver == $doc.version {
            return;
        }

        my Str $code = $doc.text;
        my Blob $bytes = $code.encode('utf-8');
        my Str $hash = hash-buffer($bytes);

        my @syms;
        my @refs;
        self!extract-symbols-and-refs($uri, $code, $doc, :@syms, :@refs);

        $!db.update-overlay($uri, $hash, $doc.version, @syms, references => @refs);

        if $!on-change.defined {
            try {
                $!on-change($uri);
                CATCH { default { } }
            }
        }
    }

    method !do-drop-buffer(Str $uri --> Nil) {
        $!db.drop-overlay($uri) if $!db.defined && $!db.is-open;
        if $!on-change.defined {
            try {
                $!on-change($uri);
                CATCH { default { } }
            }
        }
    }

    method remove-file(Str $uri --> Nil) {
        $!db.remove-file($uri) if $!db.defined && $!db.is-open;
        if $!on-change.defined {
            try {
                $!on-change($uri);
                CATCH { default { } }
            }
        }
    }

    #| Purge all indexed files and symbols whose URI starts with the given folder URI
    method remove-folder(Str $folder-uri --> Nil) {
        $!db.remove-folder($folder-uri) if $!db.defined && $!db.is-open;
        if $!on-change.defined {
            try {
                $!on-change($folder-uri);
                CATCH { default { } }
            }
        }
    }

    method find-composing-types(Str $role-name --> Positional) {
        return $!db.is-open ?? $!db.get-role-consumers($role-name) !! [];
    }

    #| Yields (uri, symbol) tuples for every class or role whose supertypes contain $name
    method subtypes-of(Str $name --> Positional) {
        return $!db.is-open ?? $!db.get-subtypes($name) !! [];
    }

    #| Full scan across all indexed files in the database. Returns Hash of uri => symbol array.
    method all-files-symbols(--> Hash) {
        my %ret;
        if $!db.defined && $!db.is-open {
            my @uris = $!db.get-all-symbol-uris();
            for @uris -> Str $u {
                %ret{$u} = $!db.get-file-symbols($u);
            }
        }
        return %ret;
    }

    #| Find a symbol by name across all indexed files.
    method find-symbol(Str $name, Str $current-namespace = "" --> Positional) {
        my Any @results;

        # Query DB
        if $!db.is-open {
            if $current-namespace {
                @results = $!db.find-exact("$current-namespace\::$name").Array;
            }
            if !@results {
                @results = $!db.find-exact($name).Array;
            }
        }

        # Search in VendorIndex as a fallback
        if !@results {
            my @vendor = get-vendor-symbols(db => $!db);
            for @vendor -> $s {
                if ($s<name> // "") eq $name {
                    @results.push($s);
                }
                if $s<children> {
                    for $s<children>.Array -> $c {
                        if ($c<name> // "") eq $name || (($s<name> // "") ~ "::" ~ ($c<name> // "")) eq $name {
                            @results.push($c);
                        }
                    }
                }
            }
        }
        return @results;
    }

    #| Find all symbols enclosing a specific line/character in a file.
    method find-enclosing-symbols(Str $uri, Int $line, Int $character --> Positional) {
        return $!db.is-open ?? $!db.find-enclosing($uri, $line, $character).Array !! [];
    }

    #| Search symbols by partial name (for workspace/symbol).
    method query-symbols(Str $query, Bool :$prefix-only = False --> Positional) {
        return $!db.is-open ?? $!db.query-symbols($query, :$prefix-only).Array !! [];
    }

    #| Recursively finds a member symbol in a class and its supertypes
    method find-member-symbol(Str $class-name, Str $member-name --> Any) {
        my Bool %visited;
        my Any @queue = ($class-name,);

        while @queue {
            my Str $curr = @queue.shift;
            next if %visited{$curr};
            %visited{$curr} = True;

            my Any @type-syms = self.find-symbol($curr);
            for @type-syms -> $class-sym {
                if $class-sym<children> {
                    for $class-sym<children>.Array -> $c {
                        my Str $c-name = $c<name> // "";
                        my Bool $matches = $c-name eq $member-name
                        || $c-name eq "!$member-name";
                        if !$matches && ($c<kind> // 0) == 7 { # Public property $.attr
                            my Str $attr-acc = $c-name.subst(/^ <[\$\@\%\&]> \. /, '');
                            $matches = $attr-acc eq $member-name;
                        }
                        if $matches {
                            # Emulate containerName so hover/goto can use it
                            my %res = %($c);
                            %res<containerName> = $curr;
                            # Attach URI from the class symbol
                            if $class-sym<uri> {
                                %res<uri> = $class-sym<uri>;
                            }
                            return %res;
                        }
                    }
                }
                if $class-sym<roles> {
                    for @($class-sym<roles>) -> $r {
                        @queue.push($r) unless %visited{$r};
                    }
                }
                if $class-sym<supertypes> {
                    for @($class-sym<supertypes>) -> $sup {
                        @queue.push($sup) unless %visited{$sup};
                    }
                }
            }

            # Also check vendor symbols for installed modules / classes
            for Nimala::Raku-LSP::VendorIndex::get-vendor-symbols(db => $!db) -> $vs {
                if ($vs<containerName> // "") eq $curr {
                    my Str $v-name = $vs<name> // "";
                    if $v-name eq $member-name || $v-name eq "!$member-name" {
                        return $vs;
                    }
                }
            }
        }
        return Nil;
    }

    #| Find the return type of a method for a given class name
    method find-method-return-type(Str $class-name, Str $method-name --> Str) {
        my $sym = self.find-member-symbol($class-name, $method-name);
        if $sym {
            my Str $det = $sym<detail> // "";
            if $det ~~ / ( 'returns' | '-->' ) \s* ( <[\w:\-]>+ [ '[' <-[\]]>* ']' ]? ) / {
                return $1.Str.trim;
            }
        }
        return "";
    }

    method !scan-system-modules(SetHash $set --> Nil) {
        for $*REPO.repo-chain -> $r {
            if $r.can('installed') {
                for $r.installed -> $dist {
                    if $dist.can('meta') && $dist.meta<provides> {
                        for $dist.meta<provides>.keys -> $mod {
                            $set.set($mod);
                        }
                    }
                }
            }
        }
    }

    method !scan-local-modules(SetHash $set --> Nil) {
        return unless $!root-path.defined && $!root-path.chars;
        my IO::Path $root = $!root-path.IO;
        my $lib-dir = $root.child("lib");
        if $lib-dir.e && $lib-dir.d {
            sub scan($dir) {
                for $dir.dir -> $file {
                    if $file.d {
                        scan($file);
                    } elsif $file.f && $file.extension eq 'rakumod' {
                        my $rel = $file.relative($lib-dir);
                        my $mod = $rel.subst(/\.rakumod$/, '').subst(/ <[/\\]> /, '::', :g);
                        $set.set($mod);
                    }
                }
            }
            scan($lib-dir);
        }
    }

    method get-module-completions(Str $prefix --> Positional) {
        self!ensure-modules-scanned();
        my @modules;
        $!lock.protect: {
            @modules = $!available-modules.keys if $!available-modules.defined;
        }
        my Any @results;
        my SetHash $seen .= new;

        for @modules -> $mod {
            if $mod.starts-with($prefix) {
                my $remainder = $mod.substr($prefix.chars);
                if $remainder.contains('::') {
                    my $idx = $remainder.index('::');
                    my $segment = $prefix ~ $remainder.substr(0, $idx + 2);
                    unless $seen{$segment} {
                        @results.push({ name => $segment });
                        $seen.set($segment);
                    }
                } else {
                    unless $seen{$mod} {
                        @results.push({ name => $mod });
                        $seen.set($mod);
                    }
                }
            }
        }
        return @results;
    }

    #| Normalizes any raw reference or symbol location to standard LSP Location format
    method normalize-location(%loc --> Hash) {
        return normalize-location(%loc);
    }

    #| Centralized workspace-wide reference search coordinating in-memory buffers and SymbolDB
    method find-references-everywhere(
        Str $name,
        :$doc-store,
        :$token,
        Bool :$include-declaration = True,
        Bool :$lexical-only = False,
        Str :$doc-uri = "",
        Int :$line = -1,
        Int :$character = -1
        --> Seq
    ) {
        if $token && $token.is-cancelled {
            return ().Seq;
        }

        my Any @results;
        my Bool %seen-loc;
        my Bool %seen-doc{Str};

        # 1. Lexical-only mode or sigiled variable: search only the target document in memory
        if ($lexical-only || $name ~~ /^ <[$@%&]>/) && $doc-uri {
            my $doc = $doc-store.defined ?? $doc-store.get($doc-uri) !! Nil;
            if $doc {
                my Any @refs;
                if $line >= 0 && $character >= 0 {
                    @refs = find-scoped-references($doc, $line, $character, :$include-declaration);
                } else {
                    @refs = find-references($doc, $name, :$include-declaration);
                }
                for @refs -> %ref {
                    my %norm = normalize-location(%ref);
                    my Str $key = %norm<uri> ~ ":" ~ %norm<range><start><line> ~ ":" ~ %norm<range><start><character>;
                    unless %seen-loc{$key} {
                        %seen-loc{$key} = True;
                        @results.push(%norm);
                    }
                }
            }
            return @results.Seq;
        }

        # 2. Search in all open documents (live buffers take precedence)
        if $doc-store.defined {
            for $doc-store.get-all-uris -> Str $u {
                if $token && $token.is-cancelled {
                    return ().Seq;
                }
                next if ($name ~~ /^ <[$@%&]>/) && $doc-uri && $u ne $doc-uri;
                my $d = $doc-store.get($u);
                if $d {
                    my Any @refs = find-references($d, $name, :include-declaration($include-declaration));
                    for @refs -> %ref {
                        my %norm = normalize-location(%ref);
                        my Str $key = %norm<uri> ~ ":" ~ %norm<range><start><line> ~ ":" ~ %norm<range><start><character>;
                        unless %seen-loc{$key} {
                            %seen-loc{$key} = True;
                            @results.push(%norm);
                        }
                    }
                    %seen-doc{$u} = True;
                }
            }
        }

        # 3. Query indexed references from SymbolDB for unopened files
        # Sigiled variables MUST NEVER be queried across unopened files in SymbolDB
        if $!db.defined && $!db.is-open && $name !~~ /^ <[$@%&]>/ {
            if $token && $token.is-cancelled {
                return ().Seq;
            }
            my @db-refs = $!db.find-references($name, :$include-declaration);
            for @db-refs -> %ref {
                my Str $u = %ref<uri>.Str;
                next if %seen-doc{$u}; # Skip if open in doc-store
                my %norm = normalize-location(%ref);
                my Str $key = %norm<uri> ~ ":" ~ %norm<range><start><line> ~ ":" ~ %norm<range><start><character>;
                unless %seen-loc{$key} {
                    %seen-loc{$key} = True;
                    @results.push(%norm);
                }
            }
        }

        return @results.Seq;
    }
}

our sub normalize-location(%loc --> Hash) is export {
    my Str $uri = (%loc<uri> // "").Str;
    my Int $sl = +(%loc<range><start><line> // %loc<start_line> // 0);
    my Int $sc = +(%loc<range><start><character> // %loc<start_char> // 0);
    my Int $el = +(%loc<range><end><line> // %loc<end_line> // $sl);
    my Int $ec = +(%loc<range><end><character> // %loc<end_char> // $sc);
    return hash(
        uri => $uri,
        range => hash(
            start => hash( line => $sl, character => $sc ),
            end   => hash( line => $el, character => $ec )
        )
    );
}
