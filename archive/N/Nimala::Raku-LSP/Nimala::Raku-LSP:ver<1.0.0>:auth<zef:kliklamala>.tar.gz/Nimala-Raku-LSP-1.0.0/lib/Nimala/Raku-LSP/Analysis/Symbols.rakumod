unit module Nimala::Raku-LSP::Analysis::Symbols;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::AST;
use nqp;

#| Extracts symbols from the code for textDocument/documentSymbol.
our proto sub extract-symbols(|) is export {*}
multi sub extract-symbols(Document $doc --> Positional) {
    if $doc.symbols.defined && $doc.ast-version == $doc.version {
        return @($doc.symbols);
    }
    my $ast = parse-document($doc);
    my @syms = ast-to-symbols($ast, $doc);
    $doc.symbols = @syms;
    return @syms;
}
multi sub extract-symbols(Str $code --> Positional) {
    my $doc = Document.new(uri => "", languageId => "raku", version => 0, text => $code);
    return extract-symbols($doc);
}

#| Extracts precise semantic symbols from the official NQP Raku parser match tree
our proto sub extract-native-symbols(|) is export {*}
multi sub extract-native-symbols(Document $doc --> Positional) {
    if $doc.native-symbols.defined && $doc.native-symbols-version == $doc.version {
        return @($doc.native-symbols);
    }
    if $doc.is-native-failed {
        return [];
    }

    my %res = run-native-worker($doc, :extract(['symbols']));
    if %res<symbols>.defined && %res<symbols>.elems > 0 {
        return @(%res<symbols>);
    }
    return @($doc.native-symbols // []);
}

multi sub extract-native-symbols(Str $code --> Positional) {
    my $doc = Document.new(uri => "", languageId => "raku", version => 0, text => $code);
    return extract-native-symbols($doc);
}

#| Flattens the hierarchical tree returned by extract-native-symbols
our sub flatten-native-tree(Positional $tree --> Positional) is export {
    my @flat;
    sub flatten($node) {
        @flat.push($node);
        if $node<children> {
            for @($node<children>) -> $c { flatten($c) }
        }
    }
    for @($tree) -> $t { flatten($t) }
    return @flat;
}

our proto sub ast-to-symbols(|) is export {*}
multi sub ast-to-symbols($node, $doc? --> Positional) {
    my @symbols;
    if $node && $node.children {
        for $node.children -> $c {
            next unless $c.defined && $c.type ne 'Error';
            if $c.type eq 'Block' || $c.type eq 'StatementList' {
                @symbols.append(ast-to-symbols($c, $doc));
                next;
            }
            next if $c.type eq 'Usage' || $c.type eq 'Expression';
            my $name = $c.name // "";
            next if $name eq "" || $name eq "<unnamed>";

            my $kind = do given $c.type {
                when 'class'   { 5 }
                when 'module'  { 2 }
                when 'package' { 2 }
                when 'grammar' { 5 }
                when 'enum'    { 10 }
                when 'EnumMember' { 22 }
                when 'role'    { 11 }
                when / 'method' | 'submethod' / { 6 }
                when / 'sub' | 'rule' | 'token' | 'regex' / { 12 }
                when 'Variable' | 'Parameter' { 13 }
                when 'Field'    { 8 }
                when 'Property' { 7 }
                default        { 1 }
            };

            my $visibility = "";
            if $kind == 8 || $kind == 7 || $kind == 13 {
                if $name ~~ /^ <[\$\@\%\&]> \! / {
                    $visibility = "private";
                    $kind = 8; # Field for private
                } elsif $name ~~ /^ <[\$\@\%\&]> \. / {
                    $visibility = "public";
                    $kind = 7; # Property for public
                }
            } elsif $kind == 6 {
                if $name ~~ /^ \! / {
                    $visibility = "private";
                } else {
                    $visibility = "public";
                }
            }

            my $range = ($c.can('range') && $doc.defined) ?? $c.range($doc) !! ($c.range // hash(
                    start => hash( line => 0, character => 0 ),
                    end   => hash( line => 0, character => 0 )
            ));

            my $children = [];
            if $kind == 5 || $kind == 2 || $kind == 11 || $kind == 6 || $kind == 12 {
                $children = ast-to-symbols($c, $doc);
            }

            my $sym-detail = $c.detail // "";
            if $visibility {
                $sym-detail = $sym-detail eq "" ?? "($visibility)" !! "$sym-detail ($visibility)";
            }

            my $selection-range = $range;
            if $doc.defined && $name ne "" {
                my Int $sl = +$range<start><line>;
                my Int $sc = +$range<start><character>;
                if $sl < $doc.lines-count {
                    my $line-text = $doc.line-text($sl);
                    my $sc-idx = max(0, $doc.position-to-offset($sl, $sc) - $doc.line-offsets[$sl]);
                    my Int $idx;
                    my $sub = $line-text.substr($sc-idx);
                    if $name ~~ /^ <[\$\@\%\&]> / {
                        my $m = $sub.index($name);
                        $idx = $sc-idx + $m if $m.defined;
                    } else {
                        if $sub ~~ / <!after \w> ( $name ) <!before \w> / {
                            $idx = $sc-idx + $/[0].from;
                        }
                    }
                    $idx //= $line-text.index($name, $sc-idx);
                    $idx //= $line-text.index($name);
                    if $idx.defined {
                        $selection-range = hash(
                            start => hash( line => $sl, character => $doc.utf16-column($sl, $idx) ),
                            end   => hash( line => $sl, character => $doc.utf16-column($sl, $idx + $name.chars) )
                        );
                    }
                }
            }

            my Bool $is-param = so ($c.type eq 'Parameter' || (try $c.is_param));
            my $symbol = hash(
                name => $name,
                kind => $kind,
                detail => $sym-detail,
                range => $range,
                selectionRange => $selection-range,
                children => $children,
                supertypes => ($c.can('supertypes') ?? $c.supertypes !! [])
            );
            $symbol<is_param> = True if $is-param;
            @symbols.push: $symbol;
        }
    }
    return @symbols;
}

my constant %KEYWORD-SET = Set.new(
    <if else elsif unless with without for while until loop repeat given when default
    my our has state constant sub method submethod multi proto class role grammar module package
    use need import require return return-rw is does as keep undo NEXT LAST FIRST QUIT
    say print put note rule token regex enum fail die warn take gather try
    CATCH CONTROL BEGIN CHECK INIT END unit True False Nil Bool Int Num Str Any Mu>
);

#| Extracts all symbol declarations and identifier usages for indexing into SymbolDB
our proto sub extract-references-for-index(|) is export {*}
multi sub extract-references-for-index(Document $doc, @symbols? --> Positional) {
    my @refs;
    my %seen;

    # 1. Collect declarations from @symbols
    my @sym-list = @symbols.defined && @symbols.elems ?? @symbols !! extract-symbols($doc);
    sub add-sym-decls(@list) {
        for @list -> $s {
            my Str $name = ($s<name> // "").Str;
            if $name ne "" && !%KEYWORD-SET{$name} && $s<range> {
                my Int $sl = +($s<range><start><line> // 0);
                my Int $sc = +($s<range><start><character> // 0);
                my Int $el = +($s<range><end><line> // $sl);
                my Int $ec = +($s<range><end><character> // $sc);

                # Prefer selectionRange or compute exact name token range
                if $s<selectionRange> && $s<selectionRange><start> && $s<selectionRange><end> {
                    $sl = +$s<selectionRange><start><line>;
                    $sc = +$s<selectionRange><start><character>;
                    $el = +$s<selectionRange><end><line>;
                    $ec = +$s<selectionRange><end><character>;
                } elsif $doc.defined && $sl < $doc.lines-count {
                    my $line-text = $doc.line-text($sl);
                    my $sc-idx = max(0, $doc.position-to-offset($sl, $sc) - $doc.line-offsets[$sl]);
                    my Int $idx;
                    my $sub = $line-text.substr($sc-idx);
                    if $name ~~ /^ <[\$\@\%\&]> / {
                        my $m = $sub.index($name);
                        $idx = $sc-idx + $m if $m.defined;
                    } else {
                        if $sub ~~ / <!after \w> ( $name ) <!before \w> / {
                            $idx = $sc-idx + $/[0].from;
                        }
                    }
                    $idx //= $line-text.index($name, $sc-idx);
                    $idx //= $line-text.index($name);
                    if $idx.defined {
                        $sc = $doc.utf16-column($sl, $idx);
                        $el = $sl;
                        $ec = $doc.utf16-column($sl, $idx + $name.chars);
                    }
                }
                my Str $key = "$name:$sl:$sc:$el:$ec";
                unless %seen{$key} {
                    %seen{$key} = True;
                    @refs.push: hash(
                        name => $name,
                        range => hash(
                            start => hash( line => $sl, character => $sc ),
                            end   => hash( line => $el, character => $ec )
                        ),
                        is_decl => True
                    );
                }
            }
            add-sym-decls($s<children>) if $s<children>;
        }
    }
    add-sym-decls(@sym-list);

    # 2. Collect usages from AST
    my $ast = parse-document($doc);
    sub walk-ast(Node $n) {
        return unless $n.defined;
        if $n.type eq 'Usage' && $n.name {
            my Str $name = $n.name.Str;
            if $name ne "" && $name ne "<unnamed>" && !%KEYWORD-SET{$name} {
                my Hash $range = ($n.can('range') && $doc.defined) ?? $n.range($doc) !! ($n.range // hash());
                if $range && $range<start> {
                    my Int $sl = +($range<start><line> // 0);
                    my Int $sc = +($range<start><character> // 0);
                    my Int $el = +($range<end><line> // $sl);
                    my Int $ec = +($range<end><character> // $sc);
                    my Str $key = "$name:$sl:$sc:$el:$ec";
                    unless %seen{$key} {
                        %seen{$key} = True;
                        @refs.push: hash(
                            name => $name,
                            range => hash(
                                start => hash( line => $sl, character => $sc ),
                                end   => hash( line => $el, character => $ec )
                            ),
                            is_decl => False
                        );
                    }
                }
            }
        }
        if $n.children {
            walk-ast($_) for $n.children;
        }
    }
    walk-ast($ast) if $ast;

    return @refs;
}

multi sub extract-references-for-index(Str $code, Str $uri = "", @symbols? --> Positional) {
    my Document $doc = Document.new(uri => $uri, text => $code, version => 0);
    return extract-references-for-index($doc, @symbols);
}

#| Finds the enclosing class/role type declaration symbol on or enclosing $line.
our sub find-type-decl(@syms, Int $line --> Any) is export {
    for @syms -> $s {
        if $s<range><start><line> <= $line <= $s<range><end><line> {
            if ($s<kind> == 5 || $s<kind> == 11) && $line == $s<range><start><line> {
                return $s;
            }
            if $s<children> {
                my $child = find-type-decl($s<children>, $line);
                return $child if $child;
            }
        }
    }
    return Nil;
}
