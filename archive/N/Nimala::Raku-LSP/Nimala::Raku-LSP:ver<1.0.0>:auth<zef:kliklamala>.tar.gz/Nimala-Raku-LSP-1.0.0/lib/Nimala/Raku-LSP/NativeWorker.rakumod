use v6.d;
#| Tier 2/3 native analysis, run in an isolated worker subprocess (see `run-native-worker` in
#| `Nimala::Raku-LSP::Parser`): symbols and semantic tokens extracted from RakuAST.
unit module Nimala::Raku-LSP::NativeWorker;

use JSON::Fast;
use experimental :rakuast;

our sub extract-symbols-native(Str $code, Mu :$ast --> Hash) {
    my Mu $node-ast = $ast;
    if !$node-ast.defined {
        try {
            $node-ast = $code.AST;
            CATCH { default { return hash(symbols => [], failed => True); } }
        }
    }
    return hash(symbols => [], failed => True) unless $node-ast;

    my @syms;
    my %seen;
    sub add(%sym --> Nil) {
        my Str $key = (%sym<kind>, %sym<from>, %sym<to>, %sym<name> // '').join("\0");
        @syms.push(%sym) unless %seen{$key}++;
    }
    sub span(Mu $node --> List) {
        my $o = try $node.origin;
        $o ?? ($o.from, $o.to) !! ();
    }
    #| Declaration name with its offsets, taken from the node's RakuAST::Name child.
    sub decl-name(Mu $node --> List) {
        my Mu $name = try $node.name;
        return () unless $name.defined && $name ~~ RakuAST::Name;
        my @s = span($name);
        @s ?? ($name.canonicalize, |@s) !! ();
    }

    sub visit(Mu $node, Bool $in-param) {
        return unless $node.defined && $node.^name.starts-with('RakuAST::');
        my Bool $param = $in-param || $node ~~ RakuAST::ParameterTarget::Var;
        my @s = span($node);

        if @s {
            my ($from, $to) = @s;
            if $node ~~ RakuAST::Package | RakuAST::Routine | RakuAST::Type::Subset | RakuAST::Type::Enum {
                add(%( kind => 'block', :$from, :$to ));
                my ($name, $nf, $nt) = decl-name($node);
                if $name.defined {
                    my Str $kind = $node ~~ RakuAST::Package ?? 'package_decl'
                    !! $node ~~ RakuAST::Routine ?? 'routine_decl' !! 'type_decl';
                    add(%( :$kind, :$name, :$from, :$to, name-from => $nf, name-to => $nt ));
                }
            } elsif $node ~~ RakuAST::Blockoid | RakuAST::StatementList {
                add(%( kind => 'block', :$from, :$to ));
            } elsif $node ~~ RakuAST::VarDeclaration::Simple {
                my Str $name = ~$node.name;
                my $idx = $param ?? $from !! $code.index($name, $from);
                if $idx.defined && ($param || $idx + $name.chars <= $to) {
                    my Mu $type = try $node.type;
                    my Str $type-name = ($type ~~ RakuAST::Type::Simple) ?? $type.name.canonicalize !! '';
                    my %sym = %(
                        kind => 'variable_decl',
                        :$name,
                        from => $idx,
                        to => $idx + $name.chars,
                        name-from => $idx,
                        name-to => $idx + $name.chars,
                        type => $type-name
                    );
                    %sym<is_param> = True if $param;
                    add(%sym);
                }
            } elsif $node ~~ RakuAST::Var::Lexical | RakuAST::Var::Attribute | RakuAST::Var::Dynamic
            | RakuAST::Var::Package {
                add(%( kind => 'variable_usage', name => $code.substr($from, $to - $from), :$from, :$to ));
            } elsif $node ~~ RakuAST::Name {
                add(%( kind => 'name_usage', name => $node.canonicalize, :$from, :$to ));
            }
        }
        $node.visit-children(-> $child { visit($child, $param) }) if $node.can('visit-children');
    }

    try {
        visit($node-ast, False);
        CATCH { default { return hash(symbols => [], failed => True); } }
    }
    @syms = @syms.sort({ $^a<from> <=> $^b<from> || $^b<to> <=> $^a<to> }).Array;
    my @tree;
    my @stack;
    for @syms -> $s {
        while @stack && $s<from> >= (@stack.tail<to> // 0) {
            @stack.pop;
        }
        if @stack {
            @stack.tail<children> //= [];
            @stack.tail<children>.push($s);
        } else {
            @tree.push($s);
        }
        @stack.push($s);
    }
    return hash(symbols => @tree, failed => False);
}

our sub extract-tokens-native(Str $code, Mu :$ast --> Hash) {
    my @tokens;
    my Mu $node-ast = $ast;
    if !$node-ast.defined {
        try {
            $node-ast = $code.AST;
            CATCH { default { return hash(tokens => [], failed => True); } }
        }
    }
    return hash(tokens => [], failed => True) unless $node-ast;

    sub visit(Mu $node --> Nil) {
        return unless $node.defined;
        return unless $node.^name.starts-with('RakuAST::');

        if $node.can('origin') && $node.origin {
            my $type = -1;
            my $mod = 0;
            my $from = $node.origin.from;
            my $to = $node.origin.to;

            my $n = $node.^name;
            if $n eq 'RakuAST::IntLiteral'
            || $n eq 'RakuAST::NumLiteral'
            || $n eq 'RakuAST::RatLiteral'
            || $n eq 'RakuAST::ComplexLiteral' {
                $type = 18;
            } elsif $n eq 'RakuAST::StrLiteral' || $n eq 'RakuAST::QuotedString' {
                $type = 17;
            } elsif $n eq 'RakuAST::Regex' || $n.starts-with('RakuAST::Regex::') {
                $type = 19;
            } elsif $n eq 'RakuAST::Type::Simple' {
                $type = 0;
            } elsif $n eq 'RakuAST::VarDeclaration::Simple' || $n.starts-with('RakuAST::Var::') {
                $type = 7;
                if $n eq 'RakuAST::VarDeclaration::Simple' { $mod = 1; }
                if $n eq 'RakuAST::Var::Attribute' { $type = 8; }

                my Bool $narrowed = False;
                my $name;
                if $node.can('name') && $node.name { $name = $node.name; }
                elsif $node.can('lexical-name') && $node.lexical-name { $name = $node.lexical-name; }

                if $name {
                    my $name-str = try { $name.Str } // "";
                    if $name-str {
                        my $idx = $code.index($name-str, $from);
                        if $idx.defined && $idx <= $to {
                            $from = $idx;
                            $to = $idx + $name-str.chars;
                            $narrowed = True;
                        }
                    }
                }
                unless $narrowed { $type = -1; }
            } elsif $n eq 'RakuAST::Class'
            || $n eq 'RakuAST::Role'
            || $n eq 'RakuAST::Method'
            || $n eq 'RakuAST::Sub'
            || $n eq 'RakuAST::Call::Name::WithoutParentheses'
            || $n eq 'RakuAST::Call::Name::WithParentheses'
            || $n eq 'RakuAST::Call::Method' {
                if $n eq 'RakuAST::Class' { $type = 1; $mod = 1; }
                elsif $n eq 'RakuAST::Role' { $type = 3; $mod = 1; }
                elsif $n eq 'RakuAST::Method' { $type = 12; $mod = 1; }
                elsif $n eq 'RakuAST::Sub' { $type = 11; $mod = 1; }
                elsif $n eq 'RakuAST::Call::Method' { $type = 12; }
                else { $type = 11; }

                my Bool $narrowed = False;
                if $node.can('name') && $node.name {
                    my $name-node = $node.name;
                    if $name-node.can('origin') && $name-node.origin {
                        $from = $name-node.origin.from;
                        $to = $name-node.origin.to;
                        $narrowed = True;
                    } elsif $name-node.can('canonicalize') {
                        my $name-str = try { $name-node.canonicalize } // "";
                        if $name-str {
                            if $code.substr($from, $to - $from) ~~ / <!after \w> $name-str <!before \w> / {
                                my Int $rel = $/.from;
                                $from = $from + $rel;
                                $to = $from + $name-str.chars;
                                $narrowed = True;
                            } else {
                                my $idx = $code.index($name-str, $from);
                                if $idx.defined && $idx <= $to {
                                    $from = $idx;
                                    $to = $idx + $name-str.chars;
                                    $narrowed = True;
                                }
                            }
                        }
                    }
                }
                unless $narrowed { $type = -1; }
            }

            if $type != -1 && $from != $to {
                @tokens.push: { from => $from, to => $to, type => $type, mod => $mod };
            }
        }

        if $node.can('visit-children') {
            $node.visit-children(-> $child { visit($child); True });
        }
    }

    try {
        visit($node-ast);
        CATCH { default { return hash(tokens => [], failed => True); } }
    }
    return hash(tokens => @tokens, failed => False);
}

#| Worker entry point: reads `{code, extract}` JSON from stdin, prints the extraction result as JSON.
#| Started as `raku -I<repo> -MNimala::Raku-LSP::NativeWorker -e 'Nimala::Raku-LSP::NativeWorker::main()'`.
our sub main(--> Nil) {
    my Str $input = $*IN.slurp;
    return unless $input.trim.chars > 0;

    my %req = try { from-json($input) };
    unless %req.defined {
        $*OUT.print(to-json({ error => "Invalid JSON input" }));
        return;
    }

    my Str $code = %req<code> // "";
    my @extract = @(%req<extract> // ["symbols", "tokens"]);
    my %out = ();

    my Mu $ast;
    my Bool $ast-failed = False;
    try {
        $ast = $code.AST;
        CATCH { default { $ast-failed = True; } }
    }
    $ast-failed = True unless $ast.defined;

    if "tokens" (elem) @extract {
        my %res = $ast-failed ?? hash(tokens => [], failed => True) !! extract-tokens-native($code, :$ast);
        %out<tokens> = %res<tokens>;
        %out<tokens_failed> = ?%res<failed>;
    }

    if "symbols" (elem) @extract {
        my %res = $ast-failed ?? hash(symbols => [], failed => True) !! extract-symbols-native($code, :$ast);
        %out<symbols> = %res<symbols>;
        %out<symbols_failed> = ?%res<failed>;
    }

    $*OUT.print(to-json(%out));
}
