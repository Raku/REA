unit module Nimala::Raku-LSP::Analysis::Diagnostics;

use JSON::Fast;
use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::URI;

# Global diagnostics lock and process registry (Option A)
our $DIAGNOSTICS-LOCK = Lock.new;
my %active-procs; # Str $uri => Proc::Async
my Int $running-procs = 0;
my @wait-queue;
my constant $MAX-CONCURRENT = 2;

#| Cancel any active syntax checking process for the given URI.
our sub cancel-syntax-check(Str $uri --> Nil) is export {
    return unless $uri.defined && $uri.chars;
    $DIAGNOSTICS-LOCK.protect: {
        if %active-procs{$uri}:exists {
            my $proc = %active-procs{$uri}:delete;
            try { $proc.kill(SIGKILL); CATCH { default { } } }
        }
    }
}

#| Cancel all active syntax checking processes and clear wait queue.
our sub cancel-all-syntax-checks(--> Nil) is export {
    $DIAGNOSTICS-LOCK.protect: {
        for %active-procs.values -> $proc {
            try { $proc.kill(SIGKILL); CATCH { default { } } }
        }
        %active-procs = %();
        while @wait-queue.elems > 0 {
            my $p = @wait-queue.shift;
            $p.break("Cancelled");
        }
    }
}

#| Runs a syntax check asynchronously using `raku -c`
our proto sub check-syntax(|) is export {*}

multi sub check-syntax(
    Document $doc,
    :@include-paths = [],
    Str :$executable = 'raku',
    Numeric :$timeout = 5,
    Bool :$enabled = True,
    Callable :$on-proc,
    Any :$token,
    Str :$cwd
    --> Promise
) {
    return Promise.kept([]) unless $enabled;
    my @inc = @include-paths;
    my Str $resolved-cwd = $cwd;
    if $doc.uri && $doc.uri.starts-with("file://") {
        my IO::Path $file-path = uri-to-path($doc.uri);
        try {
            my IO::Path $cur = $file-path.parent;
            $resolved-cwd //= $cur.absolute;
            while $cur.defined && $cur.e && $cur.Str ne "." && $cur.Str ne "/" {
                my $has-meta = try { $cur.add("META6.json").e } // False;
                my $has-git  = try { $cur.add(".git").e } // False;
                my $lib-dir  = $cur.add("lib");
                my $has-lib  = try { $lib-dir.e && $lib-dir.d } // False;
                if $has-meta || $has-git || $has-lib {
                    @inc.push($lib-dir.absolute) if $has-lib;
                    @inc.push($cur.absolute);
                    $resolved-cwd = $cur.absolute;
                    last;
                }
                my $parent = $cur.parent;
                last if !$parent.defined || $parent.Str eq $cur.Str || $parent.Str eq "/";
                $cur = $parent;
            }
        }
    }
    check-syntax(
        $doc.text,
        :include-paths(@inc),
        :$executable,
        :$timeout,
        :$enabled,
        :$on-proc,
        :$token,
        cwd => $resolved-cwd,
        uri => $doc.uri,
        :$doc
    );
}

multi sub check-syntax(
    Str $code,
    :@include-paths = [],
    Str :$executable = 'raku',
    Numeric :$timeout = 5,
    Bool :$enabled = True,
    Callable :$on-proc,
    Any :$token,
    Str :$cwd,
    Str :$uri,
    Document :$doc
    --> Promise
) {
    return Promise.kept([]) unless $enabled;
    if $token.defined && $token.can('is-cancelled') && $token.is-cancelled {
        return Promise.kept([]);
    }

    start {
        # 1. Cancel previous in-flight check for this URI
        if $uri.defined && $uri.chars {
            $DIAGNOSTICS-LOCK.protect: {
                if %active-procs{$uri}:exists {
                    my $old = %active-procs{$uri}:delete;
                    try { $old.kill(SIGKILL); CATCH { default { } } }
                }
            }
        }

        # 2. Concurrency throttle (max 2)
        my $slot-promise;
        $DIAGNOSTICS-LOCK.protect: {
            if $running-procs < $MAX-CONCURRENT {
                $running-procs++;
                $slot-promise = Promise.kept(True);
            } else {
                my $p = Promise.new;
                @wait-queue.push($p);
                $slot-promise = $p;
            }
        }

        my Bool $slot-acquired = False;
        my $proc;
        my $cancel-tap;
        my @diagnostics;

        try {
            await $slot-promise;
            $slot-acquired = True;

            # A cancelled run keeps its promise with no diagnostics (`return` here would break it, M-12)
            unless $token.defined && $token.can('is-cancelled') && $token.is-cancelled {
                my Str $bin = ($executable && $executable.trim.chars > 0) ?? $executable !! $*EXECUTABLE.absolute;
                my @cmd = $bin;
                my %seen-inc;
                for @include-paths -> $inc {
                    if $inc && !%seen-inc{$inc} {
                        %seen-inc{$inc} = True;
                        @cmd.push("-I$inc");
                    }
                }

                my Str $run-cwd = ($cwd.defined && $cwd.chars && (try { $cwd.IO.e && $cwd.IO.d } // False)) ?? $cwd !! $*CWD.Str;
                my $lib-path = $run-cwd.IO.add('lib');
                if $run-cwd ne '/' && (try { $lib-path.e && $lib-path.d } // False) && !%seen-inc{$lib-path.absolute} {
                    @cmd.push("-I" ~ $lib-path.absolute);
                    %seen-inc{$lib-path.absolute} = True;
                }
                @cmd.push('-c', '-');

                $proc = Proc::Async.new(|@cmd, :w);
                my $stderr = "";
                $proc.stderr.tap(-> $v { $stderr ~= $v });
                my $stdout = "";
                $proc.stdout.tap(-> $v { $stdout ~= $v });

                $DIAGNOSTICS-LOCK.protect: {
                    %active-procs{$uri} = $proc if $uri.defined && $uri.chars;
                }

                try { $on-proc($proc) if $on-proc.defined; CATCH { default { } } }

                if $token.defined && $token.can('cancellation-supply') {
                    $cancel-tap = $token.cancellation-supply.tap(-> $ {
                            try { $proc.kill(SIGKILL); CATCH { default { } } }
                    });
                }

                my Numeric $sec = ($timeout.defined && $timeout > 0) ?? ($timeout max 1) !! 5;
                my $timeout-p = Promise.in($sec);

                my %ENV = %*ENV;
                %ENV<RAKU_EXCEPTIONS_HANDLER> = 'JSON';

                my $p = $proc.start(:%ENV, cwd => $run-cwd);
                # Await the write (bounded by the timeout): closing stdin first can drop the input under load
                try await Promise.anyof($proc.write($code.encode), $timeout-p);
                $proc.close-stdin;

                my $timed-out = False;
                try {
                    await Promise.anyof($p, $timeout-p);
                    if $timeout-p.status == Kept && $p.status != Kept {
                        $timed-out = True;
                        $proc.kill(SIGKILL);
                    }
                    CATCH { default { } }
                }

                if $timed-out {
                    @diagnostics.push: hash(
                        range => hash(
                            start => hash( line => 0, character => 0 ),
                            end => hash( line => 0, character => 1 ),
                        ),
                        severity => 2,
                        message => "Syntax check timed out after {$sec} seconds",
                        source => "raku"
                    );
                } elsif $token.defined && $token.can('is-cancelled') && $token.is-cancelled {
                    # Cancelled, empty
                } else {
                    @diagnostics = parse-compiler-output($stderr, $code, :$uri);
                }

            }
            CATCH {
                default { }
            }
        }

        LEAVE {
            if $cancel-tap.defined {
                try { $cancel-tap.close; CATCH { default { } } }
            }
            if $slot-acquired {
                $DIAGNOSTICS-LOCK.protect: {
                    if $uri.defined && (%active-procs{$uri}:exists) && (%active-procs{$uri} === $proc) {
                        %active-procs{$uri}:delete;
                    }
                    if @wait-queue.elems > 0 {
                        my $next-p = @wait-queue.shift;
                        $next-p.keep(True);
                    } else {
                        $running-procs = max(0, $running-procs - 1);
                    }
                }
            }
        }

        @diagnostics;
    }
}

#| Parses compiler output (structured JSON exceptions and text warnings) into LSP diagnostics.
our sub parse-compiler-output(Str $stderr, Str $code, Str :$uri --> Array) is export {
    my @diagnostics;
    my @code-lines = $code.lines;

    sub is-current-file(Str $filename --> Bool) {
        return True unless $filename.defined && $filename.chars > 0;
        return True if $filename eq '-' || $filename eq '-e' || $filename eq '<unknown>';
        # The RakuAST frontend reports stdin as "<cwd>/-"
        return True if $filename.IO.basename eq '-';
        if $uri.defined && $uri.starts-with('file://') {
            my Str $path = uri-to-path($uri).Str;
            my Str $norm-file = $filename.subst('\\', '/', :g);
            my Str $norm-path = $path.subst('\\', '/', :g);
            $norm-file = $norm-file.subst(/^ \. \/ /, '');
            if $*DISTRO.is-win {
                return True if $norm-file.lc eq $norm-path.lc
                || $norm-file.lc.ends-with($norm-path.lc)
                || $norm-path.lc.ends-with($norm-file.lc)
                || $norm-path.lc.ends-with('/' ~ $norm-file.lc);
            } else {
                return True if $norm-file eq $norm-path
                || $norm-file.ends-with($norm-path)
                || $norm-path.ends-with($norm-file)
                || $norm-path.ends-with('/' ~ $norm-file);
            }
        }
        return False;
    }

    sub calc-range(Int $line-idx, Str $pre, Str $symbol --> Hash) {
        my Str $line-text = (0 <= $line-idx < @code-lines.elems) ?? @code-lines[$line-idx] !! "";
        my Int $start-cu = 0;
        my Int $len-cu = 1;

        if $symbol.defined && $symbol.chars > 0 {
            my $idx = $line-text.index($symbol);
            if $idx.defined {
                $start-cu = utf16-length($line-text.substr(0, $idx));
                $len-cu = utf16-length($symbol);
            } elsif $pre.defined && $pre.chars > 0 {
                $start-cu = utf16-length($pre);
                $len-cu = utf16-length($symbol);
            }
        } elsif $pre.defined && $pre.chars > 0 {
            my $idx = $line-text.index($pre);
            if $idx.defined {
                $start-cu = utf16-length($line-text.substr(0, $idx + $pre.chars));
            } else {
                $start-cu = utf16-length($pre);
            }
        }

        return hash(
            start => hash( line => $line-idx, character => $start-cu ),
            end   => hash( line => $line-idx, character => $start-cu + ($len-cu max 1) )
        );
    }

    # 1. Attempt structured JSON parsing
    my Bool $parsed-json = False;
    for $stderr.lines.reverse -> $line {
        my $trimmed = $line.trim;
        if $trimmed.starts-with('{') && $trimmed.ends-with('}') {
            try {
                my $data = from-json($trimmed);
                if $data ~~ Associative {
                    $parsed-json = True;
                    parse-json-exception($data, @diagnostics, &is-current-file, &calc-range);
                    last;
                }
                CATCH { default { } }
            }
        }
    }

    # 2. Extract compile-time warnings ("Potential difficulties:")
    if $stderr.contains("Potential difficulties:") {
        my @lines = $stderr.lines;
        my Int $idx = 0;
        while $idx < @lines.elems {
            if @lines[$idx].starts-with("Potential difficulties:") {
                $idx++;
                last;
            }
            $idx++;
        }
        while $idx < @lines.elems {
            my $msg-line = @lines[$idx++].trim;
            last if !$msg-line.chars || $msg-line.starts-with("===SORRY") || $msg-line.starts-with('{');

            my $location_str = ($idx < @lines.elems) ?? @lines[$idx++].trim !! "";
            my $code-line = ($idx < @lines.elems && @lines[$idx].trim.starts-with("------>")) ?? @lines[$idx++].trim !! "";

            if $location_str ~~ / "at " (\S+)\:(\d+) / {
                my Str $fname = ~$0;
                my Int $line-num = $1.Int - 1;
                next unless is-current-file($fname);

                my Int $start-cu = 0;
                my Int $len-cu = 1;
                if $code-line ~~ / \-\-\-\-\-\-\>\s?(.*?) [ \=? \<HERE\> | \⏏ ] / {
                    $start-cu = utf16-length(~$0);
                } elsif $msg-line ~~ / "symbol " \' (\S+) \' / {
                    my Str $sym = ~$0;
                    my Str $line-text = (0 <= $line-num < @code-lines.elems) ?? @code-lines[$line-num] !! "";
                    my $pos = $line-text.index($sym);
                    if $pos.defined {
                        $start-cu = utf16-length($line-text.substr(0, $pos));
                        $len-cu = utf16-length($sym);
                    }
                }
                @diagnostics.push: hash(
                    range    => hash(
                        start => hash( line => $line-num, character => $start-cu ),
                        end   => hash( line => $line-num, character => $start-cu + $len-cu )
                    ),
                    severity => 2,
                    message  => $msg-line,
                    source   => "raku"
                );
            }
        }
    }

    # 3. Fallback text parsing if JSON exception was not detected/handled
    if !@diagnostics.elems && $stderr ~~ / "===SORRY!" .*? \n (.*) / {
        my Str $body = ~$0;
        my Int $line = 0;
        my Int $character = 0;

        # Line number extraction
        if $body ~~ / [ "at " \S+ \: | "used at line " | "at line " ] (\d+) / {
            $line = $0.Int - 1;
        } elsif $body ~~ / \: (\d+) [ \: | \s | $ ] / {
            $line = $0.Int - 1;
        }

        # Check for multiple undeclared routines in text
        if $body ~~ / "Undeclared routine" [ "s:" | ":" ] \s* \n (.*?) [ <?before \-\-\-\-\-\-\> | \n\n > | $ ] / {
            for $0.Str.lines -> $l {
                if $l ~~ / \s* (\S+) \s+ "used at line " (\d+) / {
                    my Str $sym = ~$0;
                    my Int $l-num = $1.Int - 1;
                    my %r = calc-range($l-num, Str, $sym);
                    @diagnostics.push: hash(
                        range    => %r,
                        severity => 1,
                        message  => "Undeclared routine: '$sym'",
                        source   => "raku"
                    );
                }
            }
        }

        if !@diagnostics.elems {
            my @lines = $body.lines;
            my @msg-lines;
            for @lines -> $l {
                last if $l.starts-with("------>");
                last if $l ~~ /^ \s* "at " \S+ \: \d+/;
                if $l.trim ne "" {
                    my $cleaned = $l;
                    $cleaned ~~ s/\s+ "used at line " \d+ .* //;
                    $cleaned ~~ s/\s+ "at line " \d+ .* //;
                    @msg-lines.push($cleaned.trim);
                }
            }
            my Str $msg = @msg-lines.join(" ");
            $msg = $body.trim unless $msg;

            if $stderr ~~ / \-\-\-\-\-\-\>\s?(.*?) [ \=? \<HERE\> | \⏏ ] / {
                $character = utf16-length(~$0);
            } elsif $msg ~~ / "Undeclared name:" \s* (\S+) / {
                my $sym = $0.Str;
                if 0 <= $line < @code-lines.elems {
                    my $idx = @code-lines[$line].index($sym);
                    $character = utf16-length(@code-lines[$line].substr(0, $idx)) if $idx.defined;
                }
            }

            @diagnostics.push: hash(
                range => hash(
                    start => hash( :$line, :$character ),
                    end   => hash( :$line, character => $character + 1 ),
                ),
                severity => 1,
                message  => $msg,
                source   => "raku"
            );
        }
    }

    # Deduplicate diagnostics
    my %seen;
    my @unique;
    for @diagnostics -> %d {
        my Str $k = (%d<range><start><line> // 0) ~ ":" ~ (%d<range><start><character> // 0) ~ ":" ~ (%d<message> // "");
        if !%seen{$k} {
            %seen{$k} = True;
            @unique.push(%d);
        }
    }

    return @unique;
}

sub parse-json-exception(%data, @diagnostics, &is-current-file, &calc-range, Int :$severity?) {
    for %data.kv -> $type, $content {
        next unless $content ~~ Associative;

        if $type eq 'X::Comp::Group' {
            if $content<worries> && $content<worries> ~~ Positional {
                for @($content<worries>) -> $w {
                    parse-json-exception($w, @diagnostics, &is-current-file, &calc-range, :severity(2)) if $w ~~ Associative;
                }
            }
            if $content<sorrows> && $content<sorrows> ~~ Positional {
                for @($content<sorrows>) -> $s {
                    parse-json-exception($s, @diagnostics, &is-current-file, &calc-range, :severity(1)) if $s ~~ Associative;
                }
            }
            if $content<panic>.defined && $content<panic> ~~ Associative {
                parse-json-exception($content<panic>, @diagnostics, &is-current-file, &calc-range, :severity(1));
            } elsif $content<panic>.defined && $content<panic> ~~ Str && $content<panic>.chars > 0 && !@diagnostics.elems {
                @diagnostics.push: hash(
                    range    => hash( start => hash( line => 0, character => 0 ), end => hash( line => 0, character => 1 ) ),
                    severity => 1,
                    message  => $content<panic>,
                    source   => "raku"
                );
            }
        } elsif $type eq 'X::Undeclared::Symbols' {
            if $content<unk_routines> && $content<unk_routines> ~~ Associative {
                for $content<unk_routines>.kv -> $routine, $lines {
                    if $lines ~~ Positional {
                        for @$lines -> $l {
                            my Int $l-num = $l.Int - 1;
                            my %r = calc-range($l-num, Str, $routine.Str);
                            @diagnostics.push: hash(
                                range    => %r,
                                severity => 1,
                                message  => "Undeclared routine '$routine'",
                                source   => "raku"
                            );
                        }
                    }
                }
            }
            if $content<unk_types> && $content<unk_types> ~~ Associative {
                for $content<unk_types>.kv -> $t, $lines {
                    if $lines ~~ Positional {
                        for @$lines -> $l {
                            my Int $l-num = $l.Int - 1;
                            my %r = calc-range($l-num, Str, $t.Str);
                            @diagnostics.push: hash(
                                range    => %r,
                                severity => 1,
                                message  => "Undeclared type '$t'",
                                source   => "raku"
                            );
                        }
                    }
                }
            }
        } else {
            # Single exception
            my Str $fname = ($content<filename> // "").Str;
            next unless is-current-file($fname);

            my Int $l-num = (($content<line> // 1).Int - 1) max 0;
            my Str $sym = ($content<symbol> // "").Str;
            my Str $pre = ($content<pre> // "").Str;
            my Str $msg = ($content<message> // $type).Str.trim;
            my Int $sev = $severity // (($type eq 'X::Redeclaration') ?? 2 !! 1);

            my %r = calc-range($l-num, $pre, $sym);
            @diagnostics.push: hash(
                range    => %r,
                severity => $sev,
                message  => $msg,
                source   => "raku"
            );
        }
    }
}
