use v6.d;
#| Compatibility name for Nimala::URI, which the LSP server and the debug adapter share.
use Nimala::URI;

sub EXPORT { Nimala::URI::EXPORT::DEFAULT:: }
