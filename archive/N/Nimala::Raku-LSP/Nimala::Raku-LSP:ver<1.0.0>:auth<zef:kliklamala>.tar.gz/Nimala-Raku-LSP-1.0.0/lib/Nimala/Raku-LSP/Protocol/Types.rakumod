use v6.d;

#| Auto-generated LSP 3.18.0 Protocol Types from official metaModel.json
#| DO NOT EDIT DIRECTLY. Regenerate using `raku tools/generate-lsp-types.raku`.

#| Base role for all LSP Objects providing JSON-RPC compliant serialization
role LSPObject is export {
    #| Serializes the object to a JSON-ready Hash according to LSP rules.
    method to-lsp-hash(--> Any) {
        return self!serialize-lsp(self);
    }

    method !serialize-lsp(Any $val --> Any) {
        if $val.HOW.^name eq 'Array' {
            return $val.grep({ .defined }).map({ self!serialize-lsp($_) }).Array;
        }
        if $val ~~ LSPObject {
            my %hash;
            for $val.^attributes -> $attr {
                my Str $name = $attr.name.substr(2); # Remove $. or @. or %.
                my Any $v = $attr.get_value($val);
                if $v.defined {
                    %hash{$name} = self!serialize-lsp($v);
                }
            }
            return %hash;
        }
        elsif $val ~~ Positional {
            return $val.grep({ .defined }).map({ self!serialize-lsp($_) }).Array;
        }
        elsif $val ~~ Associative {
            return $val.grep({ .value.defined }).map({ .key => self!serialize-lsp(.value) }).hash;
        }
        elsif $val ~~ Enumeration {
            return $val.value;
        }
        return $val;
    }
}

# ======================================================================
# Type Aliases (23 typeAliases in LSP 3.18.0)
# ======================================================================

#| An identifier to refer to a change annotation stored with a workspace edit.
subset ChangeAnnotationIdentifier of Str is export;

#| The declaration of a symbol representation as one or many {@link Location locations}.
subset Declaration of Any is export;

#| Information about where a symbol is declared.
#| 
#| Provides additional metadata over normal {@link Location location} declarations, including the range of
#| the declaring symbol.
#| 
#| Servers should prefer returning `DeclarationLink` over `Declaration` if supported
#| by the client.
subset DeclarationLink of Any is export;

#| The definition of a symbol represented as one or many {@link Location locations}.
#| For most programming languages there is only one location at which a symbol is
#| defined.
#| 
#| Servers should prefer returning `DefinitionLink` over `Definition` if supported
#| by the client.
subset Definition of Any is export;

#| Information about where a symbol is defined.
#| 
#| Provides additional metadata over normal {@link Location location} definitions, including the range of
#| the defining symbol
subset DefinitionLink of Any is export;

#| The result of a document diagnostic pull request. A report can
#| either be a full report containing all diagnostics for the
#| requested document or an unchanged report indicating that nothing
#| has changed in terms of diagnostics in comparison to the last
#| pull request.
#| 
#| @since 3.17.0
subset DocumentDiagnosticReport of Any is export;

#| The document diagnostic report used when reporting partial result.
#| 
#| When using partial results, the first literal sent needs to be a
#| DocumentDiagnosticReport providing the diagnostics on the document
#| followed by n DocumentDiagnosticReportPartialResult literals providing
#| the diagnostics for related documents.
#| 
#| ```
#| DocumentDiagnosticReport
#| DocumentDiagnosticReportPartialResult
#| DocumentDiagnosticReportPartialResult
#| ...
#| ```
#| 
#| @since 3.18.1
subset DocumentDiagnosticReportProgress of Any is export;

#| A document filter describes a top level text document or
#| a notebook cell document.
#| 
#| @since 3.17.0 - support for NotebookCellTextDocumentFilter.
subset DocumentFilter of Any is export;

#| A document selector is the combination of one or many document filters.
#| 
#| @sample `let sel:DocumentSelector = [{ language: 'typescript' }, { language: 'json', pattern: '**∕tsconfig.json' }]`;
#| 
#| The use of a string as a document filter is deprecated @since 3.16.0.
subset DocumentSelector of Positional is export;

#| The glob pattern. Either a string pattern or a relative pattern.
#| 
#| @since 3.17.0
subset GlobPattern of Any is export;

#| Inline value information can be provided by different means:
#| - directly as a text value (class InlineValueText).
#| - as a name to use for a variable lookup (class InlineValueVariableLookup)
#| - as an evaluatable expression (class InlineValueEvaluatableExpression)
#| The InlineValue types combines all inline value types into one type.
#| 
#| @since 3.17.0
subset InlineValue of Any is export;

#| The LSP any type.
#| Please note that strictly speaking a property with the value `undefined`
#| can't be converted into JSON preserving the property name. However for
#| convenience it is allowed and assumed that all these properties are
#| optional as well.
#| @since 3.17.0
subset LSPAny of Any is export;

#| LSP arrays.
#| @since 3.17.0
subset LSPArray of Positional is export;

#| MarkedString can be used to render human readable text. It is either a markdown string
#| or a code-block that provides a language and a code snippet. The language identifier
#| is semantically equal to the optional language identifier in fenced code blocks in GitHub
#| issues. See https://help.github.com/articles/creating-and-highlighting-code-blocks/#syntax-highlighting
#| 
#| The pair of a language and a value is an equivalent to markdown:
#| ```${language}
#| ${value}
#| ```
#| 
#| Note that markdown strings will be sanitized - that means html will be escaped.
#| @deprecated use MarkupContent instead.
subset MarkedString of Any is export;

#| A notebook document filter denotes a notebook document by
#| different properties. The properties will be match
#| against the notebook's URI (same as with documents)
#| 
#| @since 3.17.0
subset NotebookDocumentFilter of Any is export;

#| The glob pattern to watch relative to the base path. Glob patterns can have the following syntax:
#| - `*` to match zero or more characters in a path segment
#| - `?` to match on one character in a path segment
#| - `**` to match any number of path segments, including none
#| - `{}` to group conditions (e.g. `**​/*.{ts,js}` matches all TypeScript and JavaScript files)
#| - `[]` to declare a range of characters to match in a path segment (e.g., `example.[0-9]` to match on `example.0`, `example.1`, …)
#| - `[!...]` to negate a range of characters to match in a path segment (e.g., `example.[!0-9]` to match on `example.a`, `example.b`, but not `example.0`)
#| 
#| @since 3.17.0
subset Pattern of Str is export;

subset PrepareRenameResult of Any is export;

subset ProgressToken of Any is export;

subset RegularExpressionEngineKind of Str is export;

#| An event describing a change to a text document.
class TextDocumentContentChangeEvent is export does LSPObject { has Any $.range is rw; has Int $.rangeLength is rw; has Str $.text is rw; }

#| A document filter denotes a document by different properties like
#| the {@link TextDocument.languageId language}, the {@link Uri.scheme scheme} of
#| its resource, or a glob-pattern that is applied to the {@link TextDocument.fileName path}.
#| 
#| Glob patterns can have the following syntax:
#| - `*` to match zero or more characters in a path segment
#| - `?` to match on one character in a path segment
#| - `**` to match any number of path segments, including none
#| - `{}` to group sub patterns into an OR expression. (e.g. `**​/*.{ts,js}` matches all TypeScript and JavaScript files)
#| - `[]` to declare a range of characters to match in a path segment (e.g., `example.[0-9]` to match on `example.0`, `example.1`, …)
#| - `[!...]` to negate a range of characters to match in a path segment (e.g., `example.[!0-9]` to match on `example.a`, `example.b`, but not `example.0`)
#| 
#| @sample A language filter that applies to typescript files on disk: `{ language: 'typescript', scheme: 'file' }`
#| @sample A language filter that applies to all package.json paths: `{ language: 'json', pattern: '**package.json' }`
#| 
#| @since 3.17.0
subset TextDocumentFilter of Any is export;

#| A workspace diagnostic document report.
#| 
#| @since 3.17.0
subset WorkspaceDocumentDiagnosticReport of Any is export;

# ======================================================================
# Enumerations (40 enums in LSP 3.18.0)
# ======================================================================

#| Defines how values from a set of defaults and an individual item will be
#| merged.
#| 
#| @since 3.18.0
enum ApplyKind is export (
    ApplyKindReplace => 1,
    ApplyKindMerge => 2,
);

#| A set of predefined code action kinds
enum CodeActionKind is export (
    CodeActionKindEmpty => '',
    CodeActionKindQuickFix => 'quickfix',
    CodeActionKindRefactor => 'refactor',
    CodeActionKindRefactorExtract => 'refactor.extract',
    CodeActionKindRefactorInline => 'refactor.inline',
    CodeActionKindRefactorMove => 'refactor.move',
    CodeActionKindRefactorRewrite => 'refactor.rewrite',
    CodeActionKindSource => 'source',
    CodeActionKindSourceOrganizeImports => 'source.organizeImports',
    CodeActionKindSourceFixAll => 'source.fixAll',
    CodeActionKindNotebook => 'notebook',
);

#| Code action tags are extra annotations that tweak the behavior of a code action.
#| 
#| @since 3.18.0
enum CodeActionTag is export (
    CodeActionTagLLMGenerated => 1,
);

#| The reason why code actions were requested.
#| 
#| @since 3.17.0
enum CodeActionTriggerKind is export (
    CodeActionTriggerKindInvoked => 1,
    CodeActionTriggerKindAutomatic => 2,
);

#| The kind of a completion entry.
enum CompletionItemKind is export (
    CompletionItemKindText => 1,
    CompletionItemKindMethod => 2,
    CompletionItemKindFunction => 3,
    CompletionItemKindConstructor => 4,
    CompletionItemKindField => 5,
    CompletionItemKindVariable => 6,
    CompletionItemKindClass => 7,
    CompletionItemKindInterface => 8,
    CompletionItemKindModule => 9,
    CompletionItemKindProperty => 10,
    CompletionItemKindUnit => 11,
    CompletionItemKindValue => 12,
    CompletionItemKindEnum => 13,
    CompletionItemKindKeyword => 14,
    CompletionItemKindSnippet => 15,
    CompletionItemKindColor => 16,
    CompletionItemKindFile => 17,
    CompletionItemKindReference => 18,
    CompletionItemKindFolder => 19,
    CompletionItemKindEnumMember => 20,
    CompletionItemKindConstant => 21,
    CompletionItemKindStruct => 22,
    CompletionItemKindEvent => 23,
    CompletionItemKindOperator => 24,
    CompletionItemKindTypeParameter => 25,
);

#| Completion item tags are extra annotations that tweak the rendering of a completion
#| item.
#| 
#| @since 3.15.0
enum CompletionItemTag is export (
    CompletionItemTagDeprecated => 1,
);

#| How a completion was triggered
enum CompletionTriggerKind is export (
    CompletionTriggerKindInvoked => 1,
    CompletionTriggerKindTriggerCharacter => 2,
    CompletionTriggerKindTriggerForIncompleteCompletions => 3,
);

#| The diagnostic's severity.
enum DiagnosticSeverity is export (
    DiagnosticSeverityError => 1,
    DiagnosticSeverityWarning => 2,
    DiagnosticSeverityInformation => 3,
    DiagnosticSeverityHint => 4,
);

#| The diagnostic tags.
#| 
#| @since 3.15.0
enum DiagnosticTag is export (
    DiagnosticTagUnnecessary => 1,
    DiagnosticTagDeprecated => 2,
);

#| The document diagnostic report kinds.
#| 
#| @since 3.17.0
enum DocumentDiagnosticReportKind is export (
    DocumentDiagnosticReportKindFull => 'full',
    DocumentDiagnosticReportKindUnchanged => 'unchanged',
);

#| A document highlight kind.
enum DocumentHighlightKind is export (
    DocumentHighlightKindText => 1,
    DocumentHighlightKindRead => 2,
    DocumentHighlightKindWrite => 3,
);

#| Predefined error codes.
enum ErrorCodes is export (
    ErrorCodesParseError => -32700,
    ErrorCodesInvalidRequest => -32600,
    ErrorCodesMethodNotFound => -32601,
    ErrorCodesInvalidParams => -32602,
    ErrorCodesInternalError => -32603,
    ErrorCodesServerNotInitialized => -32002,
    ErrorCodesUnknownErrorCode => -32001,
);

enum FailureHandlingKind is export (
    FailureHandlingKindAbort => 'abort',
    FailureHandlingKindTransactional => 'transactional',
    FailureHandlingKindTextOnlyTransactional => 'textOnlyTransactional',
    FailureHandlingKindUndo => 'undo',
);

#| The file event type
enum FileChangeType is export (
    FileChangeTypeCreated => 1,
    FileChangeTypeChanged => 2,
    FileChangeTypeDeleted => 3,
);

#| A pattern kind describing if a glob pattern matches a file a folder or
#| both.
#| 
#| @since 3.16.0
enum FileOperationPatternKind is export (
    FileOperationPatternKindfile => 'file',
    FileOperationPatternKindfolder => 'folder',
);

#| A set of predefined range kinds.
enum FoldingRangeKind is export (
    FoldingRangeKindComment => 'comment',
    FoldingRangeKindImports => 'imports',
    FoldingRangeKindRegion => 'region',
);

#| Inlay hint kinds.
#| 
#| @since 3.17.0
enum InlayHintKind is export (
    InlayHintKindType => 1,
    InlayHintKindParameter => 2,
);

#| Describes how an {@link InlineCompletionItemProvider inline completion provider} was triggered.
#| 
#| @since 3.18.0
enum InlineCompletionTriggerKind is export (
    InlineCompletionTriggerKindInvoked => 1,
    InlineCompletionTriggerKindAutomatic => 2,
);

#| Defines whether the insert text in a completion item should be interpreted as
#| plain text or a snippet.
enum InsertTextFormat is export (
    InsertTextFormatPlainText => 1,
    InsertTextFormatSnippet => 2,
);

#| How whitespace and indentation is handled during completion
#| item insertion.
#| 
#| @since 3.16.0
enum InsertTextMode is export (
    InsertTextModeasIs => 1,
    InsertTextModeadjustIndentation => 2,
);

enum LSPErrorCodes is export (
    LSPErrorCodesRequestFailed => -32803,
    LSPErrorCodesServerCancelled => -32802,
    LSPErrorCodesContentModified => -32801,
    LSPErrorCodesRequestCancelled => -32800,
);

#| Predefined Language kinds
#| @since 3.18.0
enum LanguageKind is export (
    LanguageKindABAP => 'abap',
    LanguageKindWindowsBat => 'bat',
    LanguageKindBibTeX => 'bibtex',
    LanguageKindClojure => 'clojure',
    LanguageKindCoffeescript => 'coffeescript',
    LanguageKindC => 'c',
    LanguageKindCPP => 'cpp',
    LanguageKindCSharp => 'csharp',
    LanguageKindCSS => 'css',
    LanguageKindD => 'd',
    LanguageKindDelphi => 'pascal',
    LanguageKindDiff => 'diff',
    LanguageKindDart => 'dart',
    LanguageKindDockerfile => 'dockerfile',
    LanguageKindElixir => 'elixir',
    LanguageKindErlang => 'erlang',
    LanguageKindFSharp => 'fsharp',
    LanguageKindGitCommit => 'git-commit',
    LanguageKindGitRebase => 'git-rebase',
    LanguageKindGo => 'go',
    LanguageKindGroovy => 'groovy',
    LanguageKindHandlebars => 'handlebars',
    LanguageKindHaskell => 'haskell',
    LanguageKindHTML => 'html',
    LanguageKindIni => 'ini',
    LanguageKindJava => 'java',
    LanguageKindJavaScript => 'javascript',
    LanguageKindJavaScriptReact => 'javascriptreact',
    LanguageKindJSON => 'json',
    LanguageKindLaTeX => 'latex',
    LanguageKindLess => 'less',
    LanguageKindLua => 'lua',
    LanguageKindMakefile => 'makefile',
    LanguageKindMarkdown => 'markdown',
    LanguageKindObjectiveC => 'objective-c',
    LanguageKindObjectiveCPP => 'objective-cpp',
    LanguageKindPascal => 'pascal',
    LanguageKindPerl => 'perl',
    LanguageKindPerl6 => 'perl6',
    LanguageKindPHP => 'php',
    LanguageKindPlaintext => 'plaintext',
    LanguageKindPowershell => 'powershell',
    LanguageKindPug => 'jade',
    LanguageKindPython => 'python',
    LanguageKindR => 'r',
    LanguageKindRazor => 'razor',
    LanguageKindRuby => 'ruby',
    LanguageKindRust => 'rust',
    LanguageKindSCSS => 'scss',
    LanguageKindSASS => 'sass',
    LanguageKindScala => 'scala',
    LanguageKindShaderLab => 'shaderlab',
    LanguageKindShellScript => 'shellscript',
    LanguageKindSQL => 'sql',
    LanguageKindSwift => 'swift',
    LanguageKindTypeScript => 'typescript',
    LanguageKindTypeScriptReact => 'typescriptreact',
    LanguageKindTeX => 'tex',
    LanguageKindVisualBasic => 'vb',
    LanguageKindXML => 'xml',
    LanguageKindXSL => 'xsl',
    LanguageKindYAML => 'yaml',
);

#| Describes the content type that a client supports in various
#| result literals like `Hover`, `ParameterInfo` or `CompletionItem`.
#| 
#| Please note that `MarkupKinds` must not start with a `$`. This kinds
#| are reserved for internal usage.
enum MarkupKind is export (
    MarkupKindPlainText => 'plaintext',
    MarkupKindMarkdown => 'markdown',
);

#| The message type
enum MessageType is export (
    MessageTypeError => 1,
    MessageTypeWarning => 2,
    MessageTypeInfo => 3,
    MessageTypeLog => 4,
    MessageTypeDebug => 5,
);

#| The moniker kind.
#| 
#| @since 3.16.0
enum MonikerKind is export (
    MonikerKindimport => 'import',
    MonikerKindexport => 'export',
    MonikerKindlocal => 'local',
);

#| A notebook cell kind.
#| 
#| @since 3.17.0
enum NotebookCellKind is export (
    NotebookCellKindMarkup => 1,
    NotebookCellKindCode => 2,
);

#| A set of predefined position encoding kinds.
#| 
#| @since 3.17.0
enum PositionEncodingKind is export (
    PositionEncodingKindUTF8 => 'utf-8',
    PositionEncodingKindUTF16 => 'utf-16',
    PositionEncodingKindUTF32 => 'utf-32',
);

enum PrepareSupportDefaultBehavior is export (
    PrepareSupportDefaultBehaviorIdentifier => 1,
);

enum ResourceOperationKind is export (
    ResourceOperationKindCreate => 'create',
    ResourceOperationKindRename => 'rename',
    ResourceOperationKindDelete => 'delete',
);

#| A set of predefined token modifiers. This set is not fixed
#| an clients can specify additional token types via the
#| corresponding client capabilities.
#| 
#| @since 3.16.0
enum SemanticTokenModifiers is export (
    SemanticTokenModifiersdeclaration => 'declaration',
    SemanticTokenModifiersdefinition => 'definition',
    SemanticTokenModifiersreadonly => 'readonly',
    SemanticTokenModifiersstatic => 'static',
    SemanticTokenModifiersdeprecated => 'deprecated',
    SemanticTokenModifiersabstract => 'abstract',
    SemanticTokenModifiersasync => 'async',
    SemanticTokenModifiersmodification => 'modification',
    SemanticTokenModifiersdocumentation => 'documentation',
    SemanticTokenModifiersdefaultLibrary => 'defaultLibrary',
);

#| A set of predefined token types. This set is not fixed
#| an clients can specify additional token types via the
#| corresponding client capabilities.
#| 
#| @since 3.16.0
enum SemanticTokenTypes is export (
    SemanticTokenTypesnamespace => 'namespace',
    SemanticTokenTypestype => 'type',
    SemanticTokenTypesclass => 'class',
    SemanticTokenTypesenum => 'enum',
    SemanticTokenTypesinterface => 'interface',
    SemanticTokenTypesstruct => 'struct',
    SemanticTokenTypestypeParameter => 'typeParameter',
    SemanticTokenTypesparameter => 'parameter',
    SemanticTokenTypesvariable => 'variable',
    SemanticTokenTypesproperty => 'property',
    SemanticTokenTypesenumMember => 'enumMember',
    SemanticTokenTypesevent => 'event',
    SemanticTokenTypesfunction => 'function',
    SemanticTokenTypesmethod => 'method',
    SemanticTokenTypesmacro => 'macro',
    SemanticTokenTypeskeyword => 'keyword',
    SemanticTokenTypesmodifier => 'modifier',
    SemanticTokenTypescomment => 'comment',
    SemanticTokenTypesstring => 'string',
    SemanticTokenTypesnumber => 'number',
    SemanticTokenTypesregexp => 'regexp',
    SemanticTokenTypesoperator => 'operator',
    SemanticTokenTypesdecorator => 'decorator',
    SemanticTokenTypeslabel => 'label',
);

#| How a signature help was triggered.
#| 
#| @since 3.15.0
enum SignatureHelpTriggerKind is export (
    SignatureHelpTriggerKindInvoked => 1,
    SignatureHelpTriggerKindTriggerCharacter => 2,
    SignatureHelpTriggerKindContentChange => 3,
);

#| A symbol kind.
enum SymbolKind is export (
    SymbolKindFile => 1,
    SymbolKindModule => 2,
    SymbolKindNamespace => 3,
    SymbolKindPackage => 4,
    SymbolKindClass => 5,
    SymbolKindMethod => 6,
    SymbolKindProperty => 7,
    SymbolKindField => 8,
    SymbolKindConstructor => 9,
    SymbolKindEnum => 10,
    SymbolKindInterface => 11,
    SymbolKindFunction => 12,
    SymbolKindVariable => 13,
    SymbolKindConstant => 14,
    SymbolKindString => 15,
    SymbolKindNumber => 16,
    SymbolKindBoolean => 17,
    SymbolKindArray => 18,
    SymbolKindObject => 19,
    SymbolKindKey => 20,
    SymbolKindNull => 21,
    SymbolKindEnumMember => 22,
    SymbolKindStruct => 23,
    SymbolKindEvent => 24,
    SymbolKindOperator => 25,
    SymbolKindTypeParameter => 26,
);

#| Symbol tags are extra annotations that tweak the rendering of a symbol.
#| 
#| @since 3.16
enum SymbolTag is export (
    SymbolTagDeprecated => 1,
);

#| Represents reasons why a text document is saved.
enum TextDocumentSaveReason is export (
    TextDocumentSaveReasonManual => 1,
    TextDocumentSaveReasonAfterDelay => 2,
    TextDocumentSaveReasonFocusOut => 3,
);

#| Defines how the host (editor) should sync
#| document changes to the language server.
enum TextDocumentSyncKind is export (
    TextDocumentSyncKindNone => 0,
    TextDocumentSyncKindFull => 1,
    TextDocumentSyncKindIncremental => 2,
);

enum TokenFormat is export (
    TokenFormatRelative => 'relative',
);

enum TraceValue is export (
    TraceValueOff => 'off',
    TraceValueMessages => 'messages',
    TraceValueVerbose => 'verbose',
);

#| Moniker uniqueness level to define scope of the moniker.
#| 
#| @since 3.16.0
enum UniquenessLevel is export (
    UniquenessLeveldocument => 'document',
    UniquenessLevelproject => 'project',
    UniquenessLevelgroup => 'group',
    UniquenessLevelscheme => 'scheme',
    UniquenessLevelglobal => 'global',
);

enum WatchKind is export (
    WatchKindCreate => 1,
    WatchKindChange => 2,
    WatchKindDelete => 4,
);

# ======================================================================
# Structures (387 structures in LSP 3.18.0)
# ======================================================================

#| A special text edit with an additional change annotation.
#| 
#| @since 3.16.0.
class AnnotatedTextEdit is export does LSPObject {
    #| The actual identifier of the change annotation
    #| Type: ChangeAnnotationIdentifier (typeAlias)
    has Any $.annotationId is rw;
    #| The range of the text document to be manipulated. To insert
    #| text into a document create a range where start === end.
    has Any $.range is rw; #| Type: Range
    #| The string to be inserted. For delete operations use an
    #| empty string.
    has Str $.newText is rw;
}

#| The parameters passed via an apply workspace edit request.
class ApplyWorkspaceEditParams is export does LSPObject {
    #| An optional label of the workspace edit. This label is
    #| presented in the user interface for example on an undo
    #| stack to undo the workspace edit.
    has Str $.label is rw;
    #| The edits to apply.
    has Any $.edit is rw; #| Type: WorkspaceEdit
    #| Additional data about the edit.
    #| 
    #| @since 3.18.0
    has Any $.metadata is rw; #| Type: WorkspaceEditMetadata
}

#| The result returned from the apply workspace edit request.
#| 
#| @since 3.17 renamed from ApplyWorkspaceEditResponse
class ApplyWorkspaceEditResult is export does LSPObject {
    #| Indicates whether the edit was applied or not.
    has Bool $.applied is rw;
    #| An optional textual description for why the edit was not applied.
    #| This may be used by the server for diagnostic logging or to provide
    #| a suitable error for a request that triggered the edit.
    has Str $.failureReason is rw;
    #| Depending on the client's failure handling strategy `failedChange` might
    #| contain the index of the change that failed. This property is only available
    #| if the client signals a `failureHandlingStrategy` in its client capabilities.
    has Int $.failedChange is rw;
}

#| A base for all symbol information.
class BaseSymbolInformation is export does LSPObject {
    #| The name of this symbol.
    has Str $.name is rw;
    #| The kind of this symbol.
    #| Type: SymbolKind (enum)
    has Any $.kind is rw;
    #| Tags for this symbol.
    #| 
    #| @since 3.16.0
    #| Array of SymbolTag
    has Any @.tags is rw;
    #| The name of the symbol containing this symbol. This information is for
    #| user interface purposes (e.g. to render a qualifier in the user interface
    #| if necessary). It can't be used to re-infer a hierarchy for the document
    #| symbols.
    has Str $.containerName is rw;
}

#| @since 3.16.0
class CallHierarchyClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `(TextDocumentRegistrationOptions & StaticRegistrationOptions)`
    #| return value for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
}

#| Represents an incoming call, e.g. a caller of a method or constructor.
#| 
#| @since 3.16.0
class CallHierarchyIncomingCall is export does LSPObject {
    #| The item that makes the call.
    has Any $.from is rw; #| Type: CallHierarchyItem
    #| The ranges at which the calls appear. This is relative to the caller
    #| denoted by {@link CallHierarchyIncomingCall.from `this.from`}.
    #| Array of Range
    has Any @.fromRanges is rw;
}

#| The parameter of a `callHierarchy/incomingCalls` request.
#| 
#| @since 3.16.0
class CallHierarchyIncomingCallsParams is export does LSPObject {
    has Any $.item is rw; #| Type: CallHierarchyItem
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Represents programming constructs like functions or constructors in the context
#| of call hierarchy.
#| 
#| @since 3.16.0
class CallHierarchyItem is export does LSPObject {
    #| The name of this item.
    has Str $.name is rw;
    #| The kind of this item.
    #| Type: SymbolKind (enum)
    has Any $.kind is rw;
    #| Tags for this item.
    #| Array of SymbolTag
    has Any @.tags is rw;
    #| More detail for this item, e.g. the signature of a function.
    has Str $.detail is rw;
    #| The resource identifier of this item.
    has Str $.uri is rw;
    #| The range enclosing this symbol not including leading/trailing whitespace but everything else, e.g. comments and code.
    has Any $.range is rw; #| Type: Range
    #| The range that should be selected and revealed when this symbol is being picked, e.g. the name of a function.
    #| Must be contained by the {@link CallHierarchyItem.range `range`}.
    has Any $.selectionRange is rw; #| Type: Range
    #| A data entry field that is preserved between a call hierarchy prepare and
    #| incoming calls or outgoing calls requests.
    has Any $.data is rw; #| Type: Any
}

#| Call hierarchy options used during static registration.
#| 
#| @since 3.16.0
class CallHierarchyOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| Represents an outgoing call, e.g. calling a getter from a method or a method from a constructor etc.
#| 
#| @since 3.16.0
class CallHierarchyOutgoingCall is export does LSPObject {
    #| The item that is called.
    has Any $.to is rw; #| Type: CallHierarchyItem
    #| The range at which this item is called. This is the range relative to the caller, e.g the item
    #| passed to {@link CallHierarchyItemProvider.provideCallHierarchyOutgoingCalls `provideCallHierarchyOutgoingCalls`}
    #| and not {@link CallHierarchyOutgoingCall.to `this.to`}.
    #| Array of Range
    has Any @.fromRanges is rw;
}

#| The parameter of a `callHierarchy/outgoingCalls` request.
#| 
#| @since 3.16.0
class CallHierarchyOutgoingCallsParams is export does LSPObject {
    has Any $.item is rw; #| Type: CallHierarchyItem
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| The parameter of a `textDocument/prepareCallHierarchy` request.
#| 
#| @since 3.16.0
class CallHierarchyPrepareParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Call hierarchy options used during static or dynamic registration.
#| 
#| @since 3.16.0
class CallHierarchyRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

class CancelParams is export does LSPObject {
    #| The request id to cancel.
    #| Type: Int | Str
    has Any $.id is rw;
}

#| Additional information that describes document changes.
#| 
#| @since 3.16.0
class ChangeAnnotation is export does LSPObject {
    #| A human-readable string describing the actual change. The string
    #| is rendered prominent in the user interface.
    has Str $.label is rw;
    #| A flag which indicates that user confirmation is needed
    #| before applying the change.
    has Bool $.needsConfirmation is rw;
    #| A human-readable string which is rendered less prominent in
    #| the user interface.
    has Str $.description is rw;
}

#| @since 3.18.0
class ChangeAnnotationsSupportOptions is export does LSPObject {
    #| Whether the client groups edits with equal labels into tree nodes,
    #| for instance all edits labelled with "Changes in Strings" would
    #| be a tree node.
    has Bool $.groupsOnLabel is rw;
}

#| Defines the capabilities provided by the client.
class ClientCapabilities is export does LSPObject {
    #| Workspace specific client capabilities.
    has Any $.workspace is rw; #| Type: WorkspaceClientCapabilities
    #| Text document specific client capabilities.
    has Any $.textDocument is rw; #| Type: TextDocumentClientCapabilities
    #| Capabilities specific to the notebook document support.
    #| 
    #| @since 3.17.0
    has Any $.notebookDocument is rw; #| Type: NotebookDocumentClientCapabilities
    #| Window specific client capabilities.
    has Any $.window is rw; #| Type: WindowClientCapabilities
    #| General client capabilities.
    #| 
    #| @since 3.16.0
    has Any $.general is rw; #| Type: GeneralClientCapabilities
    #| Experimental client capabilities.
    has Any $.experimental is rw; #| Type: Any
}

#| @since 3.18.0
class ClientCodeActionKindOptions is export does LSPObject {
    #| The code action kind values the client supports. When this
    #| property exists the client also guarantees that it will
    #| handle values outside its set gracefully and falls back
    #| to a default value when unknown.
    #| Array of CodeActionKind
    has Any @.valueSet is rw;
}

#| @since 3.18.0
class ClientCodeActionLiteralOptions is export does LSPObject {
    #| The code action kind is support with the following value
    #| set.
    has Any $.codeActionKind is rw; #| Type: ClientCodeActionKindOptions
}

#| @since 3.18.0
class ClientCodeActionResolveOptions is export does LSPObject {
    #| The properties that a client can resolve lazily.
    has Str @.properties is rw;
}

#| @since 3.18.0
class ClientCodeLensResolveOptions is export does LSPObject {
    #| The properties that a client can resolve lazily.
    has Str @.properties is rw;
}

#| @since 3.18.0
class ClientCompletionItemInsertTextModeOptions is export does LSPObject {
    #| Array of InsertTextMode
    has Any @.valueSet is rw;
}

#| @since 3.18.0
class ClientCompletionItemOptions is export does LSPObject {
    #| Client supports snippets as insert text.
    #| 
    #| A snippet can define tab stops and placeholders with `$1`, `$2`
    #| and `${3:foo}`. `$0` defines the final tab stop, it defaults to
    #| the end of the snippet. Placeholders with equal identifiers are linked,
    #| that is typing in one will update others too.
    has Bool $.snippetSupport is rw;
    #| Client supports commit characters on a completion item.
    has Bool $.commitCharactersSupport is rw;
    #| Client supports the following content formats for the documentation
    #| property. The order describes the preferred format of the client.
    #| Array of MarkupKind
    has Any @.documentationFormat is rw;
    #| Client supports the deprecated property on a completion item.
    has Bool $.deprecatedSupport is rw;
    #| Client supports the preselect property on a completion item.
    has Bool $.preselectSupport is rw;
    #| Client supports the tag property on a completion item. Clients supporting
    #| tags have to handle unknown tags gracefully. Clients especially need to
    #| preserve unknown tags when sending a completion item back to the server in
    #| a resolve call.
    #| 
    #| @since 3.15.0
    has Any $.tagSupport is rw; #| Type: CompletionItemTagOptions
    #| Client support insert replace edit to control different behavior if a
    #| completion item is inserted in the text or should replace text.
    #| 
    #| @since 3.16.0
    has Bool $.insertReplaceSupport is rw;
    #| Indicates which properties a client can resolve lazily on a completion
    #| item. Before version 3.16.0 only the predefined properties `documentation`
    #| and `details` could be resolved lazily.
    #| 
    #| @since 3.16.0
    has Any $.resolveSupport is rw; #| Type: ClientCompletionItemResolveOptions
    #| The client supports the `insertTextMode` property on
    #| a completion item to override the whitespace handling mode
    #| as defined by the client (see `insertTextMode`).
    #| 
    #| @since 3.16.0
    has Any $.insertTextModeSupport is rw; #| Type: ClientCompletionItemInsertTextModeOptions
    #| The client has support for completion item label
    #| details (see also `CompletionItemLabelDetails`).
    #| 
    #| @since 3.17.0
    has Bool $.labelDetailsSupport is rw;
}

#| @since 3.18.0
class ClientCompletionItemOptionsKind is export does LSPObject {
    #| The completion item kind values the client supports. When this
    #| property exists the client also guarantees that it will
    #| handle values outside its set gracefully and falls back
    #| to a default value when unknown.
    #| 
    #| If this property is not present the client only supports
    #| the completion items kinds from `Text` to `Reference` as defined in
    #| the initial version of the protocol.
    #| Array of CompletionItemKind
    has Any @.valueSet is rw;
}

#| @since 3.18.0
class ClientCompletionItemResolveOptions is export does LSPObject {
    #| The properties that a client can resolve lazily.
    has Str @.properties is rw;
}

#| @since 3.18.0
class ClientDiagnosticsTagOptions is export does LSPObject {
    #| The tags supported by the client.
    #| Array of DiagnosticTag
    has Any @.valueSet is rw;
}

#| @since 3.18.0
class ClientFoldingRangeKindOptions is export does LSPObject {
    #| The folding range kind values the client supports. When this
    #| property exists the client also guarantees that it will
    #| handle values outside its set gracefully and falls back
    #| to a default value when unknown.
    #| Array of FoldingRangeKind
    has Any @.valueSet is rw;
}

#| @since 3.18.0
class ClientFoldingRangeOptions is export does LSPObject {
    #| If set, the client signals that it supports setting collapsedText on
    #| folding ranges to display custom labels instead of the default text.
    #| 
    #| @since 3.17.0
    has Bool $.collapsedText is rw;
}

#| Information about the client
#| 
#| @since 3.15.0
#| @since 3.18.0 ClientInfo type name added.
class ClientInfo is export does LSPObject {
    #| The name of the client as defined by the client.
    has Str $.name is rw;
    #| The client's version as defined by the client.
    has Str $.version is rw;
}

#| @since 3.18.0
class ClientInlayHintResolveOptions is export does LSPObject {
    #| The properties that a client can resolve lazily.
    has Str @.properties is rw;
}

#| @since 3.18.0
class ClientSemanticTokensRequestFullDelta is export does LSPObject {
    #| The client will send the `textDocument/semanticTokens/full/delta` request if
    #| the server provides a corresponding handler.
    has Bool $.delta is rw;
}

#| @since 3.18.0
class ClientSemanticTokensRequestOptions is export does LSPObject {
    #| The client will send the `textDocument/semanticTokens/range` request if
    #| the server provides a corresponding handler.
    #| Type: Bool | Hash
    has Any $.range is rw;
    #| The client will send the `textDocument/semanticTokens/full` request if
    #| the server provides a corresponding handler.
    #| Type: Bool | ClientSemanticTokensRequestFullDelta
    has Any $.full is rw;
}

#| @since 3.18.0
class ClientShowMessageActionItemOptions is export does LSPObject {
    #| Whether the client supports additional attributes which
    #| are preserved and send back to the server in the
    #| request's response.
    has Bool $.additionalPropertiesSupport is rw;
}

#| @since 3.18.0
class ClientSignatureInformationOptions is export does LSPObject {
    #| Client supports the following content formats for the documentation
    #| property. The order describes the preferred format of the client.
    #| Array of MarkupKind
    has Any @.documentationFormat is rw;
    #| Client capabilities specific to parameter information.
    has Any $.parameterInformation is rw; #| Type: ClientSignatureParameterInformationOptions
    #| The client supports the `activeParameter` property on `SignatureInformation`
    #| literal.
    #| 
    #| @since 3.16.0
    has Bool $.activeParameterSupport is rw;
    #| The client supports the `activeParameter` property on
    #| `SignatureHelp`/`SignatureInformation` being set to `null` to
    #| indicate that no parameter should be active.
    #| 
    #| @since 3.18.0
    has Bool $.noActiveParameterSupport is rw;
}

#| @since 3.18.0
class ClientSignatureParameterInformationOptions is export does LSPObject {
    #| The client supports processing label offsets instead of a
    #| simple label string.
    #| 
    #| @since 3.14.0
    has Bool $.labelOffsetSupport is rw;
}

#| @since 3.18.0
class ClientSymbolKindOptions is export does LSPObject {
    #| The symbol kind values the client supports. When this
    #| property exists the client also guarantees that it will
    #| handle values outside its set gracefully and falls back
    #| to a default value when unknown.
    #| 
    #| If this property is not present the client only supports
    #| the symbol kinds from `File` to `Array` as defined in
    #| the initial version of the protocol.
    #| Array of SymbolKind
    has Any @.valueSet is rw;
}

#| @since 3.18.0
class ClientSymbolResolveOptions is export does LSPObject {
    #| The properties that a client can resolve lazily. Usually
    #| `location.range`
    has Str @.properties is rw;
}

#| @since 3.18.0
class ClientSymbolTagOptions is export does LSPObject {
    #| The tags supported by the client.
    #| Array of SymbolTag
    has Any @.valueSet is rw;
}

#| A code action represents a change that can be performed in code, e.g. to fix a problem or
#| to refactor code.
#| 
#| A CodeAction must set either `edit` and/or a `command`. If both are supplied, the `edit` is applied first, then the `command` is executed.
class CodeAction is export does LSPObject {
    #| A short, human-readable, title for this code action.
    has Str $.title is rw;
    #| The kind of the code action.
    #| 
    #| Used to filter code actions.
    #| Type: CodeActionKind (enum)
    has Any $.kind is rw;
    #| The diagnostics that this code action resolves.
    #| Array of Diagnostic
    has Any @.diagnostics is rw;
    #| Marks this as a preferred action. Preferred actions are used by the `auto fix` command and can be targeted
    #| by keybindings.
    #| 
    #| A quick fix should be marked preferred if it properly addresses the underlying error.
    #| A refactoring should be marked preferred if it is the most reasonable choice of actions to take.
    #| 
    #| @since 3.15.0
    has Bool $.isPreferred is rw;
    #| Marks that the code action cannot currently be applied.
    #| 
    #| Clients should follow the following guidelines regarding disabled code actions:
    #| 
    #|   - Disabled code actions are not shown in automatic [lightbulbs](https://code.visualstudio.com/docs/editor/editingevolved#_code-action)
    #|     code action menus.
    #| 
    #|   - Disabled actions are shown as faded out in the code action menu when the user requests a more specific type
    #|     of code action, such as refactorings.
    #| 
    #|   - If the user has a [keybinding](https://code.visualstudio.com/docs/editor/refactoring#_keybindings-for-code-actions)
    #|     that auto applies a code action and only disabled code actions are returned, the client should show the user an
    #|     error message with `reason` in the editor.
    #| 
    #| @since 3.16.0
    has Any $.disabled is rw; #| Type: CodeActionDisabled
    #| The workspace edit this code action performs.
    has Any $.edit is rw; #| Type: WorkspaceEdit
    #| A command this code action executes. If a code action
    #| provides an edit and a command, first the edit is
    #| executed and then the command.
    has Any $.command is rw; #| Type: Command
    #| A data entry field that is preserved on a code action between
    #| a `textDocument/codeAction` and a `codeAction/resolve` request.
    #| 
    #| @since 3.16.0
    has Any $.data is rw; #| Type: Any
    #| Tags for this code action.
    #| 
    #| @since 3.18.0
    #| Array of CodeActionTag
    has Any @.tags is rw;
}

#| The Client Capabilities of a {@link CodeActionRequest}.
class CodeActionClientCapabilities is export does LSPObject {
    #| Whether code action supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| The client support code action literals of type `CodeAction` as a valid
    #| response of the `textDocument/codeAction` request. If the property is not
    #| set the request can only return `Command` literals.
    #| 
    #| @since 3.8.0
    has Any $.codeActionLiteralSupport is rw; #| Type: ClientCodeActionLiteralOptions
    #| Whether code action supports the `isPreferred` property.
    #| 
    #| @since 3.15.0
    has Bool $.isPreferredSupport is rw;
    #| Whether code action supports the `disabled` property.
    #| 
    #| @since 3.16.0
    has Bool $.disabledSupport is rw;
    #| Whether code action supports the `data` property which is
    #| preserved between a `textDocument/codeAction` and a
    #| `codeAction/resolve` request.
    #| 
    #| @since 3.16.0
    has Bool $.dataSupport is rw;
    #| Whether the client supports resolving additional code action
    #| properties via a separate `codeAction/resolve` request.
    #| 
    #| @since 3.16.0
    has Any $.resolveSupport is rw; #| Type: ClientCodeActionResolveOptions
    #| Whether the client honors the change annotations in
    #| text edits and resource operations returned via the
    #| `CodeAction#edit` property by for example presenting
    #| the workspace edit in the user interface and asking
    #| for confirmation.
    #| 
    #| @since 3.16.0
    has Bool $.honorsChangeAnnotations is rw;
    #| Whether the client supports documentation for a class of
    #| code actions.
    #| 
    #| @since 3.18.0
    has Bool $.documentationSupport is rw;
    #| Client supports the tag property on a code action. Clients
    #| supporting tags have to handle unknown tags gracefully.
    #| 
    #| @since 3.18.0
    has Any $.tagSupport is rw; #| Type: CodeActionTagOptions
}

#| Contains additional diagnostic information about the context in which
#| a {@link CodeActionProvider.provideCodeActions code action} is run.
class CodeActionContext is export does LSPObject {
    #| An array of diagnostics known on the client side overlapping the range provided to the
    #| `textDocument/codeAction` request. They are provided so that the server knows which
    #| errors are currently presented to the user for the given range. There is no guarantee
    #| that these accurately reflect the error state of the resource. The primary parameter
    #| to compute code actions is the provided range.
    #| Array of Diagnostic
    has Any @.diagnostics is rw;
    #| Requested kind of actions to return.
    #| 
    #| Actions not of this kind are filtered out by the client before being shown. So servers
    #| can omit computing them.
    #| Array of CodeActionKind
    has Any @.only is rw;
    #| The reason why code actions were requested.
    #| 
    #| @since 3.17.0
    #| Type: CodeActionTriggerKind (enum)
    has Any $.triggerKind is rw;
}

#| Captures why the code action is currently disabled.
#| 
#| @since 3.18.0
class CodeActionDisabled is export does LSPObject {
    #| Human readable description of why the code action is currently disabled.
    #| 
    #| This is displayed in the code actions UI.
    has Str $.reason is rw;
}

#| Documentation for a class of code actions.
#| 
#| @since 3.18.0
class CodeActionKindDocumentation is export does LSPObject {
    #| The kind of the code action being documented.
    #| 
    #| If the kind is generic, such as `CodeActionKind.Refactor`, the documentation will be shown whenever any
    #| refactorings are returned. If the kind if more specific, such as `CodeActionKind.RefactorExtract`, the
    #| documentation will only be shown when extract refactoring code actions are returned.
    #| Type: CodeActionKind (enum)
    has Any $.kind is rw;
    #| Command that is ued to display the documentation to the user.
    #| 
    #| The title of this documentation code action is taken from {@linkcode Command.title}
    has Any $.command is rw; #| Type: Command
}

#| Provider options for a {@link CodeActionRequest}.
class CodeActionOptions is export does LSPObject {
    #| CodeActionKinds that this server may return.
    #| 
    #| The list of kinds may be generic, such as `CodeActionKind.Refactor`, or the server
    #| may list out every specific kind they provide.
    #| Array of CodeActionKind
    has Any @.codeActionKinds is rw;
    #| Static documentation for a class of code actions.
    #| 
    #| Documentation from the provider should be shown in the code actions menu if either:
    #| 
    #| - Code actions of `kind` are requested by the editor. In this case, the editor will show the documentation that
    #|   most closely matches the requested code action kind. For example, if a provider has documentation for
    #|   both `Refactor` and `RefactorExtract`, when the user requests code actions for `RefactorExtract`,
    #|   the editor will use the documentation for `RefactorExtract` instead of the documentation for `Refactor`.
    #| 
    #| - Any code actions of `kind` are returned by the provider.
    #| 
    #| At most one documentation entry should be shown per provider.
    #| 
    #| @since 3.18.0
    #| Array of CodeActionKindDocumentation
    has Any @.documentation is rw;
    #| The server provides support to resolve additional
    #| information for a code action.
    #| 
    #| @since 3.16.0
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link CodeActionRequest}.
class CodeActionParams is export does LSPObject {
    #| The document in which the command was invoked.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The range for which the command was invoked.
    has Any $.range is rw; #| Type: Range
    #| Context carrying additional information.
    has Any $.context is rw; #| Type: CodeActionContext
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link CodeActionRequest}.
class CodeActionRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| CodeActionKinds that this server may return.
    #| 
    #| The list of kinds may be generic, such as `CodeActionKind.Refactor`, or the server
    #| may list out every specific kind they provide.
    #| Array of CodeActionKind
    has Any @.codeActionKinds is rw;
    #| Static documentation for a class of code actions.
    #| 
    #| Documentation from the provider should be shown in the code actions menu if either:
    #| 
    #| - Code actions of `kind` are requested by the editor. In this case, the editor will show the documentation that
    #|   most closely matches the requested code action kind. For example, if a provider has documentation for
    #|   both `Refactor` and `RefactorExtract`, when the user requests code actions for `RefactorExtract`,
    #|   the editor will use the documentation for `RefactorExtract` instead of the documentation for `Refactor`.
    #| 
    #| - Any code actions of `kind` are returned by the provider.
    #| 
    #| At most one documentation entry should be shown per provider.
    #| 
    #| @since 3.18.0
    #| Array of CodeActionKindDocumentation
    has Any @.documentation is rw;
    #| The server provides support to resolve additional
    #| information for a code action.
    #| 
    #| @since 3.16.0
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| @since 3.18.0
class CodeActionTagOptions is export does LSPObject {
    #| The tags supported by the client.
    #| Array of CodeActionTag
    has Any @.valueSet is rw;
}

#| Structure to capture a description for an error code.
#| 
#| @since 3.16.0
class CodeDescription is export does LSPObject {
    #| An URI to open with more information about the diagnostic error.
    has Str $.href is rw;
}

#| A code lens represents a {@link Command command} that should be shown along with
#| source text, like the number of references, a way to run tests, etc.
#| 
#| A code lens is _unresolved_ when no command is associated to it. For performance
#| reasons the creation of a code lens and resolving should be done in two stages.
class CodeLens is export does LSPObject {
    #| The range in which this code lens is valid. Should only span a single line.
    has Any $.range is rw; #| Type: Range
    #| The command this code lens represents.
    has Any $.command is rw; #| Type: Command
    #| A data entry field that is preserved on a code lens item between
    #| a {@link CodeLensRequest} and a {@link CodeLensResolveRequest}
    has Any $.data is rw; #| Type: Any
}

#| The client capabilities  of a {@link CodeLensRequest}.
class CodeLensClientCapabilities is export does LSPObject {
    #| Whether code lens supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Whether the client supports resolving additional code lens
    #| properties via a separate `codeLens/resolve` request.
    #| 
    #| @since 3.18.0
    has Any $.resolveSupport is rw; #| Type: ClientCodeLensResolveOptions
}

#| Code Lens provider options of a {@link CodeLensRequest}.
class CodeLensOptions is export does LSPObject {
    #| Code lens has a resolve provider as well.
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link CodeLensRequest}.
class CodeLensParams is export does LSPObject {
    #| The document to request code lens for.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link CodeLensRequest}.
class CodeLensRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| Code lens has a resolve provider as well.
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| @since 3.16.0
class CodeLensWorkspaceClientCapabilities is export does LSPObject {
    #| Whether the client implementation supports a refresh request sent from the
    #| server to the client.
    #| 
    #| Note that this event is global and will force the client to refresh all
    #| code lenses currently shown. It should be used with absolute care and is
    #| useful for situation where a server for example detect a project wide
    #| change that requires such a calculation.
    has Bool $.refreshSupport is rw;
}

#| Represents a color in RGBA space.
class Color is export does LSPObject {
    #| The red component of this color in the range [0-1].
    has Rat $.red is rw;
    #| The green component of this color in the range [0-1].
    has Rat $.green is rw;
    #| The blue component of this color in the range [0-1].
    has Rat $.blue is rw;
    #| The alpha component of this color in the range [0-1].
    has Rat $.alpha is rw;
}

#| Represents a color range from a document.
class ColorInformation is export does LSPObject {
    #| The range in the document where this color appears.
    has Any $.range is rw; #| Type: Range
    #| The actual color value for this color range.
    has Any $.color is rw; #| Type: Color
}

class ColorPresentation is export does LSPObject {
    #| The label of this color presentation. It will be shown on the color
    #| picker header. By default this is also the text that is inserted when selecting
    #| this color presentation.
    has Str $.label is rw;
    #| An {@link TextEdit edit} which is applied to a document when selecting
    #| this presentation for the color.  When `falsy` the {@link ColorPresentation.label label}
    #| is used.
    has Any $.textEdit is rw; #| Type: TextEdit
    #| An optional array of additional {@link TextEdit text edits} that are applied when
    #| selecting this color presentation. Edits must not overlap with the main {@link ColorPresentation.textEdit edit} nor with themselves.
    #| Array of TextEdit
    has Any @.additionalTextEdits is rw;
}

#| Parameters for a {@link ColorPresentationRequest}.
class ColorPresentationParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The color to request presentations for.
    has Any $.color is rw; #| Type: Color
    #| The range where the color would be inserted. Serves as a context.
    has Any $.range is rw; #| Type: Range
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Represents a reference to a command. Provides a title which
#| will be used to represent a command in the UI and, optionally,
#| an array of arguments which will be passed to the command handler
#| function when invoked.
class Command is export does LSPObject {
    #| Title of the command, like `save`.
    has Str $.title is rw;
    #| An optional tooltip.
    #| 
    #| @since 3.18.0
    has Str $.tooltip is rw;
    #| The identifier of the actual command handler.
    has Str $.command is rw;
    #| Arguments that the command handler should be
    #| invoked with.
    has Any @.arguments is rw;
}

#| Completion client capabilities
class CompletionClientCapabilities is export does LSPObject {
    #| Whether completion supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| The client supports the following `CompletionItem` specific
    #| capabilities.
    has Any $.completionItem is rw; #| Type: ClientCompletionItemOptions
    #| The client supports the following completion item kinds.
    has Any $.completionItemKind is rw; #| Type: ClientCompletionItemOptionsKind
    #| Defines how the client handles whitespace and indentation
    #| when accepting a completion item that uses multi line
    #| text in either `insertText` or `textEdit`.
    #| 
    #| @since 3.17.0
    #| Type: InsertTextMode (enum)
    has Any $.insertTextMode is rw;
    #| The client supports to send additional context information for a
    #| `textDocument/completion` request.
    has Bool $.contextSupport is rw;
    #| The client supports the following `CompletionList` specific
    #| capabilities.
    #| 
    #| @since 3.17.0
    has Any $.completionList is rw; #| Type: CompletionListCapabilities
}

#| Contains additional information about the context in which a completion request is triggered.
class CompletionContext is export does LSPObject {
    #| How the completion was triggered.
    #| Type: CompletionTriggerKind (enum)
    has Any $.triggerKind is rw;
    #| The trigger character (a single character) that has trigger code complete.
    #| Is undefined if `triggerKind !== CompletionTriggerKind.TriggerCharacter`
    has Str $.triggerCharacter is rw;
}

#| A completion item represents a text snippet that is
#| proposed to complete text that is being typed.
class CompletionItem is export does LSPObject {
    #| The label of this completion item.
    #| 
    #| The label property is also by default the text that
    #| is inserted when selecting this completion.
    #| 
    #| If label details are provided the label itself should
    #| be an unqualified name of the completion item.
    has Str $.label is rw;
    #| Additional details for the label
    #| 
    #| @since 3.17.0
    has Any $.labelDetails is rw; #| Type: CompletionItemLabelDetails
    #| The kind of this completion item. Based of the kind
    #| an icon is chosen by the editor.
    #| Type: CompletionItemKind (enum)
    has Any $.kind is rw;
    #| Tags for this completion item.
    #| 
    #| @since 3.15.0
    #| Array of CompletionItemTag
    has Any @.tags is rw;
    #| A human-readable string with additional information
    #| about this item, like type or symbol information.
    has Str $.detail is rw;
    #| A human-readable string that represents a doc-comment.
    #| Type: Str | MarkupContent
    has Any $.documentation is rw;
    #| Indicates if this item is deprecated.
    #| @deprecated Use `tags` instead.
    has Bool $.deprecated is rw;
    #| Select this item when showing.
    #| 
    #| *Note* that only one completion item can be selected and that the
    #| tool / client decides which item that is. The rule is that the *first*
    #| item of those that match best is selected.
    has Bool $.preselect is rw;
    #| A string that should be used when comparing this item
    #| with other items. When `falsy` the {@link CompletionItem.label label}
    #| is used.
    has Str $.sortText is rw;
    #| A string that should be used when filtering a set of
    #| completion items. When `falsy` the {@link CompletionItem.label label}
    #| is used.
    has Str $.filterText is rw;
    #| A string that should be inserted into a document when selecting
    #| this completion. When `falsy` the {@link CompletionItem.label label}
    #| is used.
    #| 
    #| The `insertText` is subject to interpretation by the client side.
    #| Some tools might not take the string literally. For example
    #| VS Code when code complete is requested in this example
    #| `con<cursor position>` and a completion item with an `insertText` of
    #| `console` is provided it will only insert `sole`. Therefore it is
    #| recommended to use `textEdit` instead since it avoids additional client
    #| side interpretation.
    has Str $.insertText is rw;
    #| The format of the insert text. The format applies to both the
    #| `insertText` property and the `newText` property of a provided
    #| `textEdit`. If omitted defaults to `InsertTextFormat.PlainText`.
    #| 
    #| Please note that the insertTextFormat doesn't apply to
    #| `additionalTextEdits`.
    #| Type: InsertTextFormat (enum)
    has Any $.insertTextFormat is rw;
    #| How whitespace and indentation is handled during completion
    #| item insertion. If not provided the clients default value depends on
    #| the `textDocument.completion.insertTextMode` client capability.
    #| 
    #| @since 3.16.0
    #| Type: InsertTextMode (enum)
    has Any $.insertTextMode is rw;
    #| An {@link TextEdit edit} which is applied to a document when selecting
    #| this completion. When an edit is provided the value of
    #| {@link CompletionItem.insertText insertText} is ignored.
    #| 
    #| Most editors support two different operations when accepting a completion
    #| item. One is to insert a completion text and the other is to replace an
    #| existing text with a completion text. Since this can usually not be
    #| predetermined by a server it can report both ranges. Clients need to
    #| signal support for `InsertReplaceEdits` via the
    #| `textDocument.completion.insertReplaceSupport` client capability
    #| property.
    #| 
    #| *Note 1:* The text edit's range as well as both ranges from an insert
    #| replace edit must be a [single line] and they must contain the position
    #| at which completion has been requested.
    #| *Note 2:* If an `InsertReplaceEdit` is returned the edit's insert range
    #| must be a prefix of the edit's replace range, that means it must be
    #| contained and starting at the same position.
    #| 
    #| @since 3.16.0 additional type `InsertReplaceEdit`
    #| Type: TextEdit | InsertReplaceEdit
    has Any $.textEdit is rw;
    #| The edit text used if the completion item is part of a CompletionList and
    #| CompletionList defines an item default for the text edit range.
    #| 
    #| Clients will only honor this property if they opt into completion list
    #| item defaults using the capability `completionList.itemDefaults`.
    #| 
    #| If not provided and a list's default range is provided the label
    #| property is used as a text.
    #| 
    #| @since 3.17.0
    has Str $.textEditText is rw;
    #| An optional array of additional {@link TextEdit text edits} that are applied when
    #| selecting this completion. Edits must not overlap (including the same insert position)
    #| with the main {@link CompletionItem.textEdit edit} nor with themselves.
    #| 
    #| Additional text edits should be used to change text unrelated to the current cursor position
    #| (for example adding an import statement at the top of the file if the completion item will
    #| insert an unqualified type).
    #| Array of TextEdit
    has Any @.additionalTextEdits is rw;
    #| An optional set of characters that when pressed while this completion is active will accept it first and
    #| then type that character. *Note* that all commit characters should have `length=1` and that superfluous
    #| characters will be ignored.
    has Str @.commitCharacters is rw;
    #| An optional {@link Command command} that is executed *after* inserting this completion. *Note* that
    #| additional modifications to the current document should be described with the
    #| {@link CompletionItem.additionalTextEdits additionalTextEdits}-property.
    has Any $.command is rw; #| Type: Command
    #| A data entry field that is preserved on a completion item between a
    #| {@link CompletionRequest} and a {@link CompletionResolveRequest}.
    has Any $.data is rw; #| Type: Any
}

#| Specifies how fields from a completion item should be combined with those
#| from `completionList.itemDefaults`.
#| 
#| If unspecified, all fields will be treated as ApplyKind.Replace.
#| 
#| If a field's value is ApplyKind.Replace, the value from a completion item (if
#| provided and not `null`) will always be used instead of the value from
#| `completionItem.itemDefaults`.
#| 
#| If a field's value is ApplyKind.Merge, the values will be merged using the rules
#| defined against each field below.
#| 
#| Servers are only allowed to return `applyKind` if the client
#| signals support for this via the `completionList.applyKindSupport`
#| capability.
#| 
#| @since 3.18.0
class CompletionItemApplyKinds is export does LSPObject {
    #| Specifies whether commitCharacters on a completion will replace or be
    #| merged with those in `completionList.itemDefaults.commitCharacters`.
    #| 
    #| If ApplyKind.Replace, the commit characters from the completion item will
    #| always be used unless not provided, in which case those from
    #| `completionList.itemDefaults.commitCharacters` will be used. An
    #| empty list can be used if a completion item does not have any commit
    #| characters and also should not use those from
    #| `completionList.itemDefaults.commitCharacters`.
    #| 
    #| If ApplyKind.Merge the commitCharacters for the completion will be the
    #| union of all values in both `completionList.itemDefaults.commitCharacters`
    #| and the completion's own `commitCharacters`.
    #| 
    #| @since 3.18.0
    #| Type: ApplyKind (enum)
    has Any $.commitCharacters is rw;
    #| Specifies whether the `data` field on a completion will replace or
    #| be merged with data from `completionList.itemDefaults.data`.
    #| 
    #| If ApplyKind.Replace, the data from the completion item will be used if
    #| provided (and not `null`), otherwise
    #| `completionList.itemDefaults.data` will be used. An empty object can
    #| be used if a completion item does not have any data but also should
    #| not use the value from `completionList.itemDefaults.data`.
    #| 
    #| If ApplyKind.Merge, a shallow merge will be performed between
    #| `completionList.itemDefaults.data` and the completion's own data
    #| using the following rules:
    #| 
    #| - If a completion's `data` field is not provided (or `null`), the
    #|   entire `data` field from `completionList.itemDefaults.data` will be
    #|   used as-is.
    #| - If a completion's `data` field is provided, each field will
    #|   overwrite the field of the same name in
    #|   `completionList.itemDefaults.data` but no merging of nested fields
    #|   within that value will occur.
    #| 
    #| @since 3.18.0
    #| Type: ApplyKind (enum)
    has Any $.data is rw;
}

#| In many cases the items of an actual completion result share the same
#| value for properties like `commitCharacters` or the range of a text
#| edit. A completion list can therefore define item defaults which will
#| be used if a completion item itself doesn't specify the value.
#| 
#| If a completion list specifies a default value and a completion item
#| also specifies a corresponding value, the rules for combining these are
#| defined by `applyKinds` (if the client supports it), defaulting to
#| ApplyKind.Replace.
#| 
#| Servers are only allowed to return default values if the client
#| signals support for this via the `completionList.itemDefaults`
#| capability.
#| 
#| @since 3.17.0
class CompletionItemDefaults is export does LSPObject {
    #| A default commit character set.
    #| 
    #| @since 3.17.0
    has Str @.commitCharacters is rw;
    #| A default edit range.
    #| 
    #| @since 3.17.0
    #| Type: Range | EditRangeWithInsertReplace
    has Any $.editRange is rw;
    #| A default insert text format.
    #| 
    #| @since 3.17.0
    #| Type: InsertTextFormat (enum)
    has Any $.insertTextFormat is rw;
    #| A default insert text mode.
    #| 
    #| @since 3.17.0
    #| Type: InsertTextMode (enum)
    has Any $.insertTextMode is rw;
    #| A default data value.
    #| 
    #| @since 3.17.0
    has Any $.data is rw; #| Type: Any
}

#| Additional details for a completion item label.
#| 
#| @since 3.17.0
class CompletionItemLabelDetails is export does LSPObject {
    #| An optional string which is rendered less prominently directly after {@link CompletionItem.label label},
    #| without any spacing. Should be used for function signatures and type annotations.
    has Str $.detail is rw;
    #| An optional string which is rendered less prominently after {@link CompletionItem.detail}. Should be used
    #| for fully qualified names and file paths.
    has Str $.description is rw;
}

#| @since 3.18.0
class CompletionItemTagOptions is export does LSPObject {
    #| The tags supported by the client.
    #| Array of CompletionItemTag
    has Any @.valueSet is rw;
}

#| Represents a collection of {@link CompletionItem completion items} to be presented
#| in the editor.
class CompletionList is export does LSPObject {
    #| This list it not complete. Further typing results in recomputing this list.
    #| 
    #| Recomputed lists have all their items replaced (not appended) in the
    #| incomplete completion sessions.
    has Bool $.isIncomplete is rw;
    #| In many cases the items of an actual completion result share the same
    #| value for properties like `commitCharacters` or the range of a text
    #| edit. A completion list can therefore define item defaults which will
    #| be used if a completion item itself doesn't specify the value.
    #| 
    #| If a completion list specifies a default value and a completion item
    #| also specifies a corresponding value, the rules for combining these are
    #| defined by `applyKinds` (if the client supports it), defaulting to
    #| ApplyKind.Replace.
    #| 
    #| Servers are only allowed to return default values if the client
    #| signals support for this via the `completionList.itemDefaults`
    #| capability.
    #| 
    #| @since 3.17.0
    has Any $.itemDefaults is rw; #| Type: CompletionItemDefaults
    #| Specifies how fields from a completion item should be combined with those
    #| from `completionList.itemDefaults`.
    #| 
    #| If unspecified, all fields will be treated as ApplyKind.Replace.
    #| 
    #| If a field's value is ApplyKind.Replace, the value from a completion item
    #| (if provided and not `null`) will always be used instead of the value
    #| from `completionItem.itemDefaults`.
    #| 
    #| If a field's value is ApplyKind.Merge, the values will be merged using
    #| the rules defined against each field below.
    #| 
    #| Servers are only allowed to return `applyKind` if the client
    #| signals support for this via the `completionList.applyKindSupport`
    #| capability.
    #| 
    #| @since 3.18.0
    has Any $.applyKind is rw; #| Type: CompletionItemApplyKinds
    #| The completion items.
    #| Array of CompletionItem
    has Any @.items is rw;
}

#| The client supports the following `CompletionList` specific
#| capabilities.
#| 
#| @since 3.17.0
class CompletionListCapabilities is export does LSPObject {
    #| The client supports the following itemDefaults on
    #| a completion list.
    #| 
    #| The value lists the supported property names of the
    #| `CompletionList.itemDefaults` object. If omitted
    #| no properties are supported.
    #| 
    #| @since 3.17.0
    has Str @.itemDefaults is rw;
    #| Specifies whether the client supports `CompletionList.applyKind` to
    #| indicate how supported values from `completionList.itemDefaults`
    #| and `completion` will be combined.
    #| 
    #| If a client supports `applyKind` it must support it for all fields
    #| that it supports that are listed in `CompletionList.applyKind`. This
    #| means when clients add support for new/future fields in completion
    #| items the MUST also support merge for them if those fields are
    #| defined in `CompletionList.applyKind`.
    #| 
    #| @since 3.18.0
    has Bool $.applyKindSupport is rw;
}

#| Completion options.
class CompletionOptions is export does LSPObject {
    #| Most tools trigger completion request automatically without explicitly requesting
    #| it using a keyboard shortcut (e.g. Ctrl+Space). Typically they do so when the user
    #| starts to type an identifier. For example if the user types `c` in a JavaScript file
    #| code complete will automatically pop up present `console` besides others as a
    #| completion item. Characters that make up identifiers don't need to be listed here.
    #| 
    #| If code complete should automatically be trigger on characters not being valid inside
    #| an identifier (for example `.` in JavaScript) list them in `triggerCharacters`.
    has Str @.triggerCharacters is rw;
    #| The list of all possible characters that commit a completion. This field can be used
    #| if clients don't support individual commit characters per completion item. See
    #| `ClientCapabilities.textDocument.completion.completionItem.commitCharactersSupport`
    #| 
    #| If a server provides both `allCommitCharacters` and commit characters on an individual
    #| completion item the ones on the completion item win.
    #| 
    #| @since 3.2.0
    has Str @.allCommitCharacters is rw;
    #| The server provides support to resolve additional
    #| information for a completion item.
    has Bool $.resolveProvider is rw;
    #| The server supports the following `CompletionItem` specific
    #| capabilities.
    #| 
    #| @since 3.17.0
    has Any $.completionItem is rw; #| Type: ServerCompletionItemOptions
    has Bool $.workDoneProgress is rw;
}

#| Completion parameters
class CompletionParams is export does LSPObject {
    #| The completion context. This is only available it the client specifies
    #| to send this using the client capability `textDocument.completion.contextSupport === true`
    has Any $.context is rw; #| Type: CompletionContext
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link CompletionRequest}.
class CompletionRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| Most tools trigger completion request automatically without explicitly requesting
    #| it using a keyboard shortcut (e.g. Ctrl+Space). Typically they do so when the user
    #| starts to type an identifier. For example if the user types `c` in a JavaScript file
    #| code complete will automatically pop up present `console` besides others as a
    #| completion item. Characters that make up identifiers don't need to be listed here.
    #| 
    #| If code complete should automatically be trigger on characters not being valid inside
    #| an identifier (for example `.` in JavaScript) list them in `triggerCharacters`.
    has Str @.triggerCharacters is rw;
    #| The list of all possible characters that commit a completion. This field can be used
    #| if clients don't support individual commit characters per completion item. See
    #| `ClientCapabilities.textDocument.completion.completionItem.commitCharactersSupport`
    #| 
    #| If a server provides both `allCommitCharacters` and commit characters on an individual
    #| completion item the ones on the completion item win.
    #| 
    #| @since 3.2.0
    has Str @.allCommitCharacters is rw;
    #| The server provides support to resolve additional
    #| information for a completion item.
    has Bool $.resolveProvider is rw;
    #| The server supports the following `CompletionItem` specific
    #| capabilities.
    #| 
    #| @since 3.17.0
    has Any $.completionItem is rw; #| Type: ServerCompletionItemOptions
    has Bool $.workDoneProgress is rw;
}

class ConfigurationItem is export does LSPObject {
    #| The scope to get the configuration section for.
    has Str $.scopeUri is rw;
    #| The configuration section asked for.
    has Str $.section is rw;
}

#| The parameters of a configuration request.
class ConfigurationParams is export does LSPObject {
    #| Array of ConfigurationItem
    has Any @.items is rw;
}

#| Create file operation.
class CreateFile is export does LSPObject {
    #| A create
    has Str $.kind is rw;
    #| The resource to create.
    has Str $.uri is rw;
    #| Additional options
    has Any $.options is rw; #| Type: CreateFileOptions
    #| An optional annotation identifier describing the operation.
    #| 
    #| @since 3.16.0
    #| Type: ChangeAnnotationIdentifier (typeAlias)
    has Any $.annotationId is rw;
}

#| Options to create a file.
class CreateFileOptions is export does LSPObject {
    #| Overwrite existing file. Overwrite wins over `ignoreIfExists`
    has Bool $.overwrite is rw;
    #| Ignore if exists.
    has Bool $.ignoreIfExists is rw;
}

#| The parameters sent in notifications/requests for user-initiated creation of
#| files.
#| 
#| @since 3.16.0
class CreateFilesParams is export does LSPObject {
    #| An array of all files/folders created in this operation.
    #| Array of FileCreate
    has Any @.files is rw;
}

#| @since 3.14.0
class DeclarationClientCapabilities is export does LSPObject {
    #| Whether declaration supports dynamic registration. If this is set to `true`
    #| the client supports the new `DeclarationRegistrationOptions` return value
    #| for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
    #| The client supports additional metadata in the form of declaration links.
    has Bool $.linkSupport is rw;
}

class DeclarationOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

class DeclarationParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

class DeclarationRegistrationOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Client Capabilities for a {@link DefinitionRequest}.
class DefinitionClientCapabilities is export does LSPObject {
    #| Whether definition supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| The client supports additional metadata in the form of definition links.
    #| 
    #| @since 3.14.0
    has Bool $.linkSupport is rw;
}

#| Server Capabilities for a {@link DefinitionRequest}.
class DefinitionOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link DefinitionRequest}.
class DefinitionParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link DefinitionRequest}.
class DefinitionRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
}

#| Delete file operation
class DeleteFile is export does LSPObject {
    #| A delete
    has Str $.kind is rw;
    #| The file to delete.
    has Str $.uri is rw;
    #| Delete options.
    has Any $.options is rw; #| Type: DeleteFileOptions
    #| An optional annotation identifier describing the operation.
    #| 
    #| @since 3.16.0
    #| Type: ChangeAnnotationIdentifier (typeAlias)
    has Any $.annotationId is rw;
}

#| Delete file options
class DeleteFileOptions is export does LSPObject {
    #| Delete the content recursively if a folder is denoted.
    has Bool $.recursive is rw;
    #| Ignore the operation if the file doesn't exist.
    has Bool $.ignoreIfNotExists is rw;
}

#| The parameters sent in notifications/requests for user-initiated deletes of
#| files.
#| 
#| @since 3.16.0
class DeleteFilesParams is export does LSPObject {
    #| An array of all files/folders deleted in this operation.
    #| Array of FileDelete
    has Any @.files is rw;
}

#| Represents a diagnostic, such as a compiler error or warning. Diagnostic objects
#| are only valid in the scope of a resource.
class Diagnostic is export does LSPObject {
    #| The range at which the message applies
    has Any $.range is rw; #| Type: Range
    #| The diagnostic's severity. To avoid interpretation mismatches when a
    #| server is used with different clients it is highly recommended that servers
    #| always provide a severity value.
    #| Type: DiagnosticSeverity (enum)
    has Any $.severity is rw;
    #| The diagnostic's code, which usually appear in the user interface.
    #| Type: Int | Str
    has Any $.code is rw;
    #| An optional property to describe the error code.
    #| Requires the code field (above) to be present/not null.
    #| 
    #| @since 3.16.0
    has Any $.codeDescription is rw; #| Type: CodeDescription
    #| A human-readable string describing the source of this
    #| diagnostic, e.g. 'typescript' or 'super lint'. It usually
    #| appears in the user interface.
    has Str $.source is rw;
    #| The diagnostic's message. It usually appears in the user interface.
    #| 
    #| @since 3.18.0 - support for MarkupContent. This is guarded by the client
    #| capability `textDocument.diagnostic.markupMessageSupport`.
    #| Type: Str | MarkupContent
    has Any $.message is rw;
    #| Additional metadata about the diagnostic.
    #| 
    #| @since 3.15.0
    #| Array of DiagnosticTag
    has Any @.tags is rw;
    #| An array of related diagnostic information, e.g. when symbol-names within
    #| a scope collide all definitions can be marked via this property.
    #| Array of DiagnosticRelatedInformation
    has Any @.relatedInformation is rw;
    #| A data entry field that is preserved between a `textDocument/publishDiagnostics`
    #| notification and `textDocument/codeAction` request.
    #| 
    #| @since 3.16.0
    has Any $.data is rw; #| Type: Any
}

#| Client capabilities specific to diagnostic pull requests.
#| 
#| @since 3.17.0
class DiagnosticClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `(TextDocumentRegistrationOptions & StaticRegistrationOptions)`
    #| return value for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
    #| Whether the clients supports related documents for document diagnostic pulls.
    has Bool $.relatedDocumentSupport is rw;
    #| Whether the client supports `MarkupContent` in diagnostic messages.
    #| 
    #| @since 3.18.0
    has Bool $.markupMessageSupport is rw;
    #| Whether the clients accepts diagnostics with related information.
    has Bool $.relatedInformation is rw;
    #| Client supports the tag property to provide meta data about a diagnostic.
    #| Clients supporting tags have to handle unknown tags gracefully.
    #| 
    #| @since 3.15.0
    has Any $.tagSupport is rw; #| Type: ClientDiagnosticsTagOptions
    #| Client supports a codeDescription property
    #| 
    #| @since 3.16.0
    has Bool $.codeDescriptionSupport is rw;
    #| Whether code action supports the `data` property which is
    #| preserved between a `textDocument/publishDiagnostics` and
    #| `textDocument/codeAction` request.
    #| 
    #| @since 3.16.0
    has Bool $.dataSupport is rw;
}

#| Diagnostic options.
#| 
#| @since 3.17.0
class DiagnosticOptions is export does LSPObject {
    #| An optional identifier under which the diagnostics are
    #| managed by the client.
    has Str $.identifier is rw;
    #| Whether the language has inter file dependencies meaning that
    #| editing code in one file can result in a different diagnostic
    #| set in another file. Inter file dependencies are common for
    #| most programming languages and typically uncommon for linters.
    has Bool $.interFileDependencies is rw;
    #| The server provides support for workspace diagnostics as well.
    has Bool $.workspaceDiagnostics is rw;
    has Bool $.workDoneProgress is rw;
}

#| Diagnostic registration options.
#| 
#| @since 3.17.0
class DiagnosticRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| An optional identifier under which the diagnostics are
    #| managed by the client.
    has Str $.identifier is rw;
    #| Whether the language has inter file dependencies meaning that
    #| editing code in one file can result in a different diagnostic
    #| set in another file. Inter file dependencies are common for
    #| most programming languages and typically uncommon for linters.
    has Bool $.interFileDependencies is rw;
    #| The server provides support for workspace diagnostics as well.
    has Bool $.workspaceDiagnostics is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Represents a related message and source code location for a diagnostic. This should be
#| used to point to code locations that cause or related to a diagnostics, e.g when duplicating
#| a symbol in a scope.
class DiagnosticRelatedInformation is export does LSPObject {
    #| The location of this related diagnostic information.
    has Any $.location is rw; #| Type: Location
    #| The message of this related diagnostic information.
    has Str $.message is rw;
}

#| Cancellation data returned from a diagnostic request.
#| 
#| @since 3.17.0
class DiagnosticServerCancellationData is export does LSPObject {
    has Bool $.retriggerRequest is rw;
}

#| Workspace client capabilities specific to diagnostic pull requests.
#| 
#| @since 3.17.0
class DiagnosticWorkspaceClientCapabilities is export does LSPObject {
    #| Whether the client implementation supports a refresh request sent from
    #| the server to the client.
    #| 
    #| Note that this event is global and will force the client to refresh all
    #| pulled diagnostics currently shown. It should be used with absolute care and
    #| is useful for situation where a server for example detects a project wide
    #| change that requires such a calculation.
    has Bool $.refreshSupport is rw;
}

#| General diagnostics capabilities for pull and push model.
class DiagnosticsCapabilities is export does LSPObject {
    #| Whether the clients accepts diagnostics with related information.
    has Bool $.relatedInformation is rw;
    #| Client supports the tag property to provide meta data about a diagnostic.
    #| Clients supporting tags have to handle unknown tags gracefully.
    #| 
    #| @since 3.15.0
    has Any $.tagSupport is rw; #| Type: ClientDiagnosticsTagOptions
    #| Client supports a codeDescription property
    #| 
    #| @since 3.16.0
    has Bool $.codeDescriptionSupport is rw;
    #| Whether code action supports the `data` property which is
    #| preserved between a `textDocument/publishDiagnostics` and
    #| `textDocument/codeAction` request.
    #| 
    #| @since 3.16.0
    has Bool $.dataSupport is rw;
}

class DidChangeConfigurationClientCapabilities is export does LSPObject {
    #| Did change configuration notification supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
}

#| The parameters of a change configuration notification.
class DidChangeConfigurationParams is export does LSPObject {
    #| The actual changed settings
    has Any $.settings is rw; #| Type: Any
}

class DidChangeConfigurationRegistrationOptions is export does LSPObject {
    #| Type: Str | Str
    has Any $.section is rw;
}

#| The params sent in a change notebook document notification.
#| 
#| @since 3.17.0
class DidChangeNotebookDocumentParams is export does LSPObject {
    #| The notebook document that did change. The version number points
    #| to the version after all provided changes have been applied. If
    #| only the text document content of a cell changes the notebook version
    #| doesn't necessarily have to change.
    has Any $.notebookDocument is rw; #| Type: VersionedNotebookDocumentIdentifier
    #| The actual changes to the notebook document.
    #| 
    #| The changes describe single state changes to the notebook document.
    #| So if there are two changes c1 (at array index 0) and c2 (at array
    #| index 1) for a notebook in state S then c1 moves the notebook from
    #| S to S' and c2 from S' to S''. So c1 is computed on the state S and
    #| c2 is computed on the state S'.
    #| 
    #| To mirror the content of a notebook using change events use the following approach:
    #| - start with the same initial content
    #| - apply the 'notebookDocument/didChange' notifications in the order you receive them.
    #| - apply the `NotebookChangeEvent`s in a single notification in the order
    #|   you receive them.
    has Any $.change is rw; #| Type: NotebookDocumentChangeEvent
}

#| The change text document notification's parameters.
class DidChangeTextDocumentParams is export does LSPObject {
    #| The document that did change. The version number points
    #| to the version after all provided content changes have
    #| been applied.
    has Any $.textDocument is rw; #| Type: VersionedTextDocumentIdentifier
    #| The actual content changes. The content changes describe single state changes
    #| to the document. So if there are two content changes c1 (at array index 0) and
    #| c2 (at array index 1) for a document in state S then c1 moves the document from
    #| S to S' and c2 from S' to S''. So c1 is computed on the state S and c2 is computed
    #| on the state S'.
    #| 
    #| To mirror the content of a document using change events use the following approach:
    #| - start with the same initial content
    #| - apply the 'textDocument/didChange' notifications in the order you receive them.
    #| - apply the `TextDocumentContentChangeEvent`s in a single notification in the order
    #|   you receive them.
    #| Array of TextDocumentContentChangeEvent
    has Any @.contentChanges is rw;
}

class DidChangeWatchedFilesClientCapabilities is export does LSPObject {
    #| Did change watched files notification supports dynamic registration. Please note
    #| that the current protocol doesn't support static configuration for file changes
    #| from the server side.
    has Bool $.dynamicRegistration is rw;
    #| Whether the client has support for {@link  RelativePattern relative pattern}
    #| or not.
    #| 
    #| @since 3.17.0
    has Bool $.relativePatternSupport is rw;
}

#| The watched files change notification's parameters.
class DidChangeWatchedFilesParams is export does LSPObject {
    #| The actual file events.
    #| Array of FileEvent
    has Any @.changes is rw;
}

#| Describe options to be used when registered for text document change events.
class DidChangeWatchedFilesRegistrationOptions is export does LSPObject {
    #| The watchers to register.
    #| Array of FileSystemWatcher
    has Any @.watchers is rw;
}

#| The parameters of a `workspace/didChangeWorkspaceFolders` notification.
class DidChangeWorkspaceFoldersParams is export does LSPObject {
    #| The actual workspace folder change event.
    has Any $.event is rw; #| Type: WorkspaceFoldersChangeEvent
}

#| The params sent in a close notebook document notification.
#| 
#| @since 3.17.0
class DidCloseNotebookDocumentParams is export does LSPObject {
    #| The notebook document that got closed.
    has Any $.notebookDocument is rw; #| Type: NotebookDocumentIdentifier
    #| The text documents that represent the content
    #| of a notebook cell that got closed.
    #| Array of TextDocumentIdentifier
    has Any @.cellTextDocuments is rw;
}

#| The parameters sent in a close text document notification
class DidCloseTextDocumentParams is export does LSPObject {
    #| The document that was closed.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
}

#| The params sent in an open notebook document notification.
#| 
#| @since 3.17.0
class DidOpenNotebookDocumentParams is export does LSPObject {
    #| The notebook document that got opened.
    has Any $.notebookDocument is rw; #| Type: NotebookDocument
    #| The text documents that represent the content
    #| of a notebook cell.
    #| Array of TextDocumentItem
    has Any @.cellTextDocuments is rw;
}

#| The parameters sent in an open text document notification
class DidOpenTextDocumentParams is export does LSPObject {
    #| The document that was opened.
    has Any $.textDocument is rw; #| Type: TextDocumentItem
}

#| The params sent in a save notebook document notification.
#| 
#| @since 3.17.0
class DidSaveNotebookDocumentParams is export does LSPObject {
    #| The notebook document that got saved.
    has Any $.notebookDocument is rw; #| Type: NotebookDocumentIdentifier
}

#| The parameters sent in a save text document notification
class DidSaveTextDocumentParams is export does LSPObject {
    #| The document that was saved.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| Optional the content when saved. Depends on the includeText value
    #| when the save notification was requested.
    has Str $.text is rw;
}

class DocumentColorClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `DocumentColorRegistrationOptions` return value
    #| for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
}

class DocumentColorOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link DocumentColorRequest}.
class DocumentColorParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

class DocumentColorRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Parameters of the document diagnostic request.
#| 
#| @since 3.17.0
class DocumentDiagnosticParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The additional identifier  provided during registration.
    has Str $.identifier is rw;
    #| The result id of a previous response if provided.
    has Str $.previousResultId is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| A partial result for a document diagnostic report.
#| 
#| @since 3.17.0
class DocumentDiagnosticReportPartialResult is export does LSPObject {
    has Any %.relatedDocuments is rw;
}

#| Client capabilities of a {@link DocumentFormattingRequest}.
class DocumentFormattingClientCapabilities is export does LSPObject {
    #| Whether formatting supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
}

#| Provider options for a {@link DocumentFormattingRequest}.
class DocumentFormattingOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link DocumentFormattingRequest}.
class DocumentFormattingParams is export does LSPObject {
    #| The document to format.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The format options.
    has Any $.options is rw; #| Type: FormattingOptions
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Registration options for a {@link DocumentFormattingRequest}.
class DocumentFormattingRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
}

#| A document highlight is a range inside a text document which deserves
#| special attention. Usually a document highlight is visualized by changing
#| the background color of its range.
class DocumentHighlight is export does LSPObject {
    #| The range this highlight applies to.
    has Any $.range is rw; #| Type: Range
    #| The highlight kind, default is {@link DocumentHighlightKind.Text text}.
    #| Type: DocumentHighlightKind (enum)
    has Any $.kind is rw;
}

#| Client Capabilities for a {@link DocumentHighlightRequest}.
class DocumentHighlightClientCapabilities is export does LSPObject {
    #| Whether document highlight supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
}

#| Provider options for a {@link DocumentHighlightRequest}.
class DocumentHighlightOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link DocumentHighlightRequest}.
class DocumentHighlightParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link DocumentHighlightRequest}.
class DocumentHighlightRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
}

#| A document link is a range in a text document that links to an internal or external resource, like another
#| text document or a web site.
class DocumentLink is export does LSPObject {
    #| The range this link applies to.
    has Any $.range is rw; #| Type: Range
    #| The uri this link points to. If missing a resolve request is sent later.
    has Str $.target is rw;
    #| The tooltip text when you hover over this link.
    #| 
    #| If a tooltip is provided, is will be displayed in a string that includes instructions on how to
    #| trigger the link, such as `{0} (ctrl + click)`. The specific instructions vary depending on OS,
    #| user settings, and localization.
    #| 
    #| @since 3.15.0
    has Str $.tooltip is rw;
    #| A data entry field that is preserved on a document link between a
    #| DocumentLinkRequest and a DocumentLinkResolveRequest.
    has Any $.data is rw; #| Type: Any
}

#| The client capabilities of a {@link DocumentLinkRequest}.
class DocumentLinkClientCapabilities is export does LSPObject {
    #| Whether document link supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Whether the client supports the `tooltip` property on `DocumentLink`.
    #| 
    #| @since 3.15.0
    has Bool $.tooltipSupport is rw;
}

#| Provider options for a {@link DocumentLinkRequest}.
class DocumentLinkOptions is export does LSPObject {
    #| Document links have a resolve provider as well.
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link DocumentLinkRequest}.
class DocumentLinkParams is export does LSPObject {
    #| The document to provide document links for.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link DocumentLinkRequest}.
class DocumentLinkRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| Document links have a resolve provider as well.
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| Client capabilities of a {@link DocumentOnTypeFormattingRequest}.
class DocumentOnTypeFormattingClientCapabilities is export does LSPObject {
    #| Whether on type formatting supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
}

#| Provider options for a {@link DocumentOnTypeFormattingRequest}.
class DocumentOnTypeFormattingOptions is export does LSPObject {
    #| A character on which formatting should be triggered, like `{`.
    has Str $.firstTriggerCharacter is rw;
    #| More trigger characters.
    has Str @.moreTriggerCharacter is rw;
}

#| The parameters of a {@link DocumentOnTypeFormattingRequest}.
class DocumentOnTypeFormattingParams is export does LSPObject {
    #| The document to format.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position around which the on type formatting should happen.
    #| This is not necessarily the exact position where the character denoted
    #| by the property `ch` got typed.
    has Any $.position is rw; #| Type: Position
    #| The character that has been typed that triggered the formatting
    #| on type request. That is not necessarily the last character that
    #| got inserted into the document since the client could auto insert
    #| characters as well (e.g. like automatic brace completion).
    has Str $.ch is rw;
    #| The formatting options.
    has Any $.options is rw; #| Type: FormattingOptions
}

#| Registration options for a {@link DocumentOnTypeFormattingRequest}.
class DocumentOnTypeFormattingRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| A character on which formatting should be triggered, like `{`.
    has Str $.firstTriggerCharacter is rw;
    #| More trigger characters.
    has Str @.moreTriggerCharacter is rw;
}

#| Client capabilities of a {@link DocumentRangeFormattingRequest}.
class DocumentRangeFormattingClientCapabilities is export does LSPObject {
    #| Whether range formatting supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Whether the client supports formatting multiple ranges at once.
    #| 
    #| @since 3.18.0
    has Bool $.rangesSupport is rw;
}

#| Provider options for a {@link DocumentRangeFormattingRequest}.
class DocumentRangeFormattingOptions is export does LSPObject {
    #| Whether the server supports formatting multiple ranges at once.
    #| 
    #| @since 3.18.0
    has Bool $.rangesSupport is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link DocumentRangeFormattingRequest}.
class DocumentRangeFormattingParams is export does LSPObject {
    #| The document to format.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The range to format
    has Any $.range is rw; #| Type: Range
    #| The format options
    has Any $.options is rw; #| Type: FormattingOptions
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Registration options for a {@link DocumentRangeFormattingRequest}.
class DocumentRangeFormattingRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| Whether the server supports formatting multiple ranges at once.
    #| 
    #| @since 3.18.0
    has Bool $.rangesSupport is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link DocumentRangesFormattingRequest}.
#| 
#| @since 3.18.0
class DocumentRangesFormattingParams is export does LSPObject {
    #| The document to format.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The ranges to format
    #| Array of Range
    has Any @.ranges is rw;
    #| The format options
    has Any $.options is rw; #| Type: FormattingOptions
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Represents programming constructs like variables, classes, interfaces etc.
#| that appear in a document. Document symbols can be hierarchical and they
#| have two ranges: one that encloses its definition and one that points to
#| its most interesting range, e.g. the range of an identifier.
class DocumentSymbol is export does LSPObject {
    #| The name of this symbol. Will be displayed in the user interface and therefore must not be
    #| an empty string or a string only consisting of white spaces.
    has Str $.name is rw;
    #| More detail for this symbol, e.g the signature of a function.
    has Str $.detail is rw;
    #| The kind of this symbol.
    #| Type: SymbolKind (enum)
    has Any $.kind is rw;
    #| Tags for this document symbol.
    #| 
    #| @since 3.16.0
    #| Array of SymbolTag
    has Any @.tags is rw;
    #| Indicates if this symbol is deprecated.
    #| 
    #| @deprecated Use tags instead
    has Bool $.deprecated is rw;
    #| The range enclosing this symbol not including leading/trailing whitespace but everything else
    #| like comments. This information is typically used to determine if the clients cursor is
    #| inside the symbol to reveal in the symbol in the UI.
    has Any $.range is rw; #| Type: Range
    #| The range that should be selected and revealed when this symbol is being picked, e.g the name of a function.
    #| Must be contained by the `range`.
    has Any $.selectionRange is rw; #| Type: Range
    #| Children of this symbol, e.g. properties of a class.
    #| Array of DocumentSymbol
    has Any @.children is rw;
}

#| Client Capabilities for a {@link DocumentSymbolRequest}.
class DocumentSymbolClientCapabilities is export does LSPObject {
    #| Whether document symbol supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Specific capabilities for the `SymbolKind` in the
    #| `textDocument/documentSymbol` request.
    has Any $.symbolKind is rw; #| Type: ClientSymbolKindOptions
    #| The client supports hierarchical document symbols.
    has Bool $.hierarchicalDocumentSymbolSupport is rw;
    #| The client supports tags on `SymbolInformation`. Tags are supported on
    #| `DocumentSymbol` if `hierarchicalDocumentSymbolSupport` is set to true.
    #| Clients supporting tags have to handle unknown tags gracefully.
    #| 
    #| @since 3.16.0
    has Any $.tagSupport is rw; #| Type: ClientSymbolTagOptions
    #| The client supports an additional label presented in the UI when
    #| registering a document symbol provider.
    #| 
    #| @since 3.16.0
    has Bool $.labelSupport is rw;
}

#| Provider options for a {@link DocumentSymbolRequest}.
class DocumentSymbolOptions is export does LSPObject {
    #| A human-readable string that is shown when multiple outlines trees
    #| are shown for the same document.
    #| 
    #| @since 3.16.0
    has Str $.label is rw;
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link DocumentSymbolRequest}.
class DocumentSymbolParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link DocumentSymbolRequest}.
class DocumentSymbolRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| A human-readable string that is shown when multiple outlines trees
    #| are shown for the same document.
    #| 
    #| @since 3.16.0
    has Str $.label is rw;
    has Bool $.workDoneProgress is rw;
}

#| Edit range variant that includes ranges for insert and replace operations.
#| 
#| @since 3.18.0
class EditRangeWithInsertReplace is export does LSPObject {
    has Any $.insert is rw; #| Type: Range
    has Any $.replace is rw; #| Type: Range
}

#| The client capabilities of a {@link ExecuteCommandRequest}.
class ExecuteCommandClientCapabilities is export does LSPObject {
    #| Execute command supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
}

#| The server capabilities of a {@link ExecuteCommandRequest}.
class ExecuteCommandOptions is export does LSPObject {
    #| The commands to be executed on the server
    has Str @.commands is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link ExecuteCommandRequest}.
class ExecuteCommandParams is export does LSPObject {
    #| The identifier of the actual command handler.
    has Str $.command is rw;
    #| Arguments that the command should be invoked with.
    has Any @.arguments is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Registration options for a {@link ExecuteCommandRequest}.
class ExecuteCommandRegistrationOptions is export does LSPObject {
    #| The commands to be executed on the server
    has Str @.commands is rw;
    has Bool $.workDoneProgress is rw;
}

class ExecutionSummary is export does LSPObject {
    #| A strict monotonically increasing value
    #| indicating the execution order of a cell
    #| inside a notebook.
    has Int $.executionOrder is rw;
    #| Whether the execution was successful or
    #| not if known by the client.
    has Bool $.success is rw;
}

#| Represents information on a file/folder create.
#| 
#| @since 3.16.0
class FileCreate is export does LSPObject {
    #| A URI for the location of the file/folder being created.
    has Str $.uri is rw;
}

#| Represents information on a file/folder delete.
#| 
#| @since 3.16.0
class FileDelete is export does LSPObject {
    #| A URI for the location of the file/folder being deleted.
    has Str $.uri is rw;
}

#| An event describing a file change.
class FileEvent is export does LSPObject {
    #| The file's uri.
    has Str $.uri is rw;
    #| The change type.
    #| Type: FileChangeType (enum)
    has Any $.type is rw;
}

#| Capabilities relating to events from file operations by the user in the client.
#| 
#| These events do not come from the file system, they come from user operations
#| like renaming a file in the UI.
#| 
#| @since 3.16.0
class FileOperationClientCapabilities is export does LSPObject {
    #| Whether the client supports dynamic registration for file requests/notifications.
    has Bool $.dynamicRegistration is rw;
    #| The client has support for sending didCreateFiles notifications.
    has Bool $.didCreate is rw;
    #| The client has support for sending willCreateFiles requests.
    has Bool $.willCreate is rw;
    #| The client has support for sending didRenameFiles notifications.
    has Bool $.didRename is rw;
    #| The client has support for sending willRenameFiles requests.
    has Bool $.willRename is rw;
    #| The client has support for sending didDeleteFiles notifications.
    has Bool $.didDelete is rw;
    #| The client has support for sending willDeleteFiles requests.
    has Bool $.willDelete is rw;
}

#| A filter to describe in which file operation requests or notifications
#| the server is interested in receiving.
#| 
#| @since 3.16.0
class FileOperationFilter is export does LSPObject {
    #| A Uri scheme like `file` or `untitled`.
    has Str $.scheme is rw;
    #| The actual file operation pattern.
    has Any $.pattern is rw; #| Type: FileOperationPattern
}

#| Options for notifications/requests for user operations on files.
#| 
#| @since 3.16.0
class FileOperationOptions is export does LSPObject {
    #| The server is interested in receiving didCreateFiles notifications.
    has Any $.didCreate is rw; #| Type: FileOperationRegistrationOptions
    #| The server is interested in receiving willCreateFiles requests.
    has Any $.willCreate is rw; #| Type: FileOperationRegistrationOptions
    #| The server is interested in receiving didRenameFiles notifications.
    has Any $.didRename is rw; #| Type: FileOperationRegistrationOptions
    #| The server is interested in receiving willRenameFiles requests.
    has Any $.willRename is rw; #| Type: FileOperationRegistrationOptions
    #| The server is interested in receiving didDeleteFiles file notifications.
    has Any $.didDelete is rw; #| Type: FileOperationRegistrationOptions
    #| The server is interested in receiving willDeleteFiles file requests.
    has Any $.willDelete is rw; #| Type: FileOperationRegistrationOptions
}

#| A pattern to describe in which file operation requests or notifications
#| the server is interested in receiving.
#| 
#| @since 3.16.0
class FileOperationPattern is export does LSPObject {
    #| The glob pattern to match. Glob patterns can have the following syntax:
    #| - `*` to match zero or more characters in a path segment
    #| - `?` to match on one character in a path segment
    #| - `**` to match any number of path segments, including none
    #| - `{}` to group sub patterns into an OR expression. (e.g. `**​/*.{ts,js}` matches all TypeScript and JavaScript files)
    #| - `[]` to declare a range of characters to match in a path segment (e.g., `example.[0-9]` to match on `example.0`, `example.1`, …)
    #| - `[!...]` to negate a range of characters to match in a path segment (e.g., `example.[!0-9]` to match on `example.a`, `example.b`, but not `example.0`)
    has Str $.glob is rw;
    #| Whether to match files or folders with this pattern.
    #| 
    #| Matches both if undefined.
    #| Type: FileOperationPatternKind (enum)
    has Any $.matches is rw;
    #| Additional options used during matching.
    has Any $.options is rw; #| Type: FileOperationPatternOptions
}

#| Matching options for the file operation pattern.
#| 
#| @since 3.16.0
class FileOperationPatternOptions is export does LSPObject {
    #| The pattern should be matched ignoring casing.
    has Bool $.ignoreCase is rw;
}

#| The options to register for file operations.
#| 
#| @since 3.16.0
class FileOperationRegistrationOptions is export does LSPObject {
    #| The actual filters.
    #| Array of FileOperationFilter
    has Any @.filters is rw;
}

#| Represents information on a file/folder rename.
#| 
#| @since 3.16.0
class FileRename is export does LSPObject {
    #| A URI for the original location of the file/folder being renamed.
    has Str $.oldUri is rw;
    #| A URI for the new location of the file/folder being renamed.
    has Str $.newUri is rw;
}

class FileSystemWatcher is export does LSPObject {
    #| The glob pattern to watch. See {@link GlobPattern glob pattern} for more detail.
    #| 
    #| @since 3.17.0 support for relative patterns.
    #| Type: GlobPattern (typeAlias)
    has Any $.globPattern is rw;
    #| The kind of events of interest. If omitted it defaults
    #| to WatchKind.Create | WatchKind.Change | WatchKind.Delete
    #| which is 7.
    #| Type: WatchKind (enum)
    has Any $.kind is rw;
}

#| Represents a folding range. To be valid, start and end line must be bigger than zero and smaller
#| than the number of lines in the document. Clients are free to ignore invalid ranges.
class FoldingRange is export does LSPObject {
    #| The zero-based start line of the range to fold. The folded area starts after the line's last character.
    #| To be valid, the end must be zero or larger and smaller than the number of lines in the document.
    has Int $.startLine is rw;
    #| The zero-based character offset from where the folded range starts. If not defined, defaults to the length of the start line.
    has Int $.startCharacter is rw;
    #| The zero-based end line of the range to fold. The folded area ends with the line's last character.
    #| To be valid, the end must be zero or larger and smaller than the number of lines in the document.
    has Int $.endLine is rw;
    #| The zero-based character offset before the folded range ends. If not defined, defaults to the length of the end line.
    has Int $.endCharacter is rw;
    #| Describes the kind of the folding range such as 'comment' or 'region'. The kind
    #| is used to categorize folding ranges and used by commands like 'Fold all comments'.
    #| See {@link FoldingRangeKind} for an enumeration of standardized kinds.
    #| Type: FoldingRangeKind (enum)
    has Any $.kind is rw;
    #| The text that the client should show when the specified range is
    #| collapsed. If not defined or not supported by the client, a default
    #| will be chosen by the client.
    #| 
    #| @since 3.17.0
    has Str $.collapsedText is rw;
}

class FoldingRangeClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration for folding range
    #| providers. If this is set to `true` the client supports the new
    #| `FoldingRangeRegistrationOptions` return value for the corresponding
    #| server capability as well.
    has Bool $.dynamicRegistration is rw;
    #| The maximum number of folding ranges that the client prefers to receive
    #| per document. The value serves as a hint, servers are free to follow the
    #| limit.
    has Int $.rangeLimit is rw;
    #| If set, the client signals that it only supports folding complete lines.
    #| If set, client will ignore specified `startCharacter` and `endCharacter`
    #| properties in a FoldingRange.
    has Bool $.lineFoldingOnly is rw;
    #| Specific options for the folding range kind.
    #| 
    #| @since 3.17.0
    has Any $.foldingRangeKind is rw; #| Type: ClientFoldingRangeKindOptions
    #| Specific options for the folding range.
    #| 
    #| @since 3.17.0
    has Any $.foldingRange is rw; #| Type: ClientFoldingRangeOptions
}

class FoldingRangeOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link FoldingRangeRequest}.
class FoldingRangeParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

class FoldingRangeRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Client workspace capabilities specific to folding ranges
#| 
#| @since 3.18.0
class FoldingRangeWorkspaceClientCapabilities is export does LSPObject {
    #| Whether the client implementation supports a refresh request sent from the
    #| server to the client.
    #| 
    #| Note that this event is global and will force the client to refresh all
    #| folding ranges currently shown. It should be used with absolute care and is
    #| useful for situation where a server for example detects a project wide
    #| change that requires such a calculation.
    #| 
    #| @since 3.18.0
    has Bool $.refreshSupport is rw;
}

#| Value-object describing what options formatting should use.
class FormattingOptions is export does LSPObject {
    #| Size of a tab in spaces.
    has Int $.tabSize is rw;
    #| Prefer spaces over tabs.
    has Bool $.insertSpaces is rw;
    #| Trim trailing whitespace on a line.
    #| 
    #| @since 3.15.0
    has Bool $.trimTrailingWhitespace is rw;
    #| Insert a newline character at the end of the file if one does not exist.
    #| 
    #| @since 3.15.0
    has Bool $.insertFinalNewline is rw;
    #| Trim all newlines after the final newline at the end of the file.
    #| 
    #| @since 3.15.0
    has Bool $.trimFinalNewlines is rw;
}

#| A diagnostic report with a full set of problems.
#| 
#| @since 3.17.0
class FullDocumentDiagnosticReport is export does LSPObject {
    #| A full document diagnostic report.
    has Str $.kind is rw;
    #| An optional result id. If provided it will
    #| be sent on the next diagnostic request for the
    #| same document.
    has Str $.resultId is rw;
    #| The actual items.
    #| Array of Diagnostic
    has Any @.items is rw;
}

#| General client capabilities.
#| 
#| @since 3.16.0
class GeneralClientCapabilities is export does LSPObject {
    #| Client capability that signals how the client
    #| handles stale requests (e.g. a request
    #| for which the client will not process the response
    #| anymore since the information is outdated).
    #| 
    #| @since 3.17.0
    has Any $.staleRequestSupport is rw; #| Type: StaleRequestSupportOptions
    #| Client capabilities specific to regular expressions.
    #| 
    #| @since 3.16.0
    has Any $.regularExpressions is rw; #| Type: RegularExpressionsClientCapabilities
    #| Client capabilities specific to the client's markdown parser.
    #| 
    #| @since 3.16.0
    has Any $.markdown is rw; #| Type: MarkdownClientCapabilities
    #| The position encodings supported by the client. Client and server
    #| have to agree on the same position encoding to ensure that offsets
    #| (e.g. character position in a line) are interpreted the same on both
    #| sides.
    #| 
    #| To keep the protocol backwards compatible the following applies: if
    #| the value 'utf-16' is missing from the array of position encodings
    #| servers can assume that the client supports UTF-16. UTF-16 is
    #| therefore a mandatory encoding.
    #| 
    #| If omitted it defaults to ['utf-16'].
    #| 
    #| Implementation considerations: since the conversion from one encoding
    #| into another requires the content of the file / line the conversion
    #| is best done where the file is read which is usually on the server
    #| side.
    #| 
    #| @since 3.17.0
    #| Array of PositionEncodingKind
    has Any @.positionEncodings is rw;
}

#| The result of a hover request.
class Hover is export does LSPObject {
    #| The hover's content
    #| Type: MarkupContent | MarkedString | MarkedString
    has Any $.contents is rw;
    #| An optional range inside the text document that is used to
    #| visualize the hover, e.g. by changing the background color.
    has Any $.range is rw; #| Type: Range
}

class HoverClientCapabilities is export does LSPObject {
    #| Whether hover supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Client supports the following content formats for the content
    #| property. The order describes the preferred format of the client.
    #| Array of MarkupKind
    has Any @.contentFormat is rw;
}

#| Hover options.
class HoverOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link HoverRequest}.
class HoverParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Registration options for a {@link HoverRequest}.
class HoverRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
}

#| @since 3.6.0
class ImplementationClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `ImplementationRegistrationOptions` return value
    #| for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
    #| The client supports additional metadata in the form of definition links.
    #| 
    #| @since 3.14.0
    has Bool $.linkSupport is rw;
}

class ImplementationOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

class ImplementationParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

class ImplementationRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| The data type of the ResponseError if the
#| initialize request fails.
class InitializeError is export does LSPObject {
    #| Indicates whether the client execute the following retry logic:
    #| (1) show the message provided by the ResponseError to the user
    #| (2) user selects retry or cancel
    #| (3) if user selected retry the initialize method is sent again.
    has Bool $.retry is rw;
}

class InitializeParams is export does LSPObject {
    #| The process Id of the parent process that started
    #| the server.
    #| 
    #| Is `null` if the process has not been started by another process.
    #| If the parent process is not alive then the server should exit.
    #| Type: Int | Any
    has Any $.processId is rw;
    #| Information about the client
    #| 
    #| @since 3.15.0
    has Any $.clientInfo is rw; #| Type: ClientInfo
    #| The locale the client is currently showing the user interface
    #| in. This must not necessarily be the locale of the operating
    #| system.
    #| 
    #| Uses IETF language tags as the value's syntax
    #| (See https://en.wikipedia.org/wiki/IETF_language_tag)
    #| 
    #| @since 3.16.0
    has Str $.locale is rw;
    #| The rootPath of the workspace. Is null
    #| if no folder is open.
    #| 
    #| @deprecated in favour of rootUri.
    #| Type: Str | Any
    has Any $.rootPath is rw;
    #| The rootUri of the workspace. Is null if no
    #| folder is open. If both `rootPath` and `rootUri` are set
    #| `rootUri` wins.
    #| 
    #| @deprecated in favour of workspaceFolders.
    #| Type: Str | Any
    has Any $.rootUri is rw;
    #| The capabilities provided by the client (editor or tool)
    has Any $.capabilities is rw; #| Type: ClientCapabilities
    #| User provided initialization options.
    has Any $.initializationOptions is rw; #| Type: Any
    #| The initial trace setting. If omitted trace is disabled ('off').
    #| Type: TraceValue (enum)
    has Any $.trace is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| The workspace folders configured in the client when the server starts.
    #| 
    #| This property is only available if the client supports workspace folders.
    #| It can be `null` if the client supports workspace folders but none are
    #| configured.
    #| 
    #| @since 3.6.0
    #| Type: WorkspaceFolder | Any
    has Any $.workspaceFolders is rw;
}

#| The result returned from an initialize request.
class InitializeResult is export does LSPObject {
    #| The capabilities the language server provides.
    has Any $.capabilities is rw; #| Type: ServerCapabilities
    #| Information about the server.
    #| 
    #| @since 3.15.0
    has Any $.serverInfo is rw; #| Type: ServerInfo
}

class InitializedParams is export does LSPObject {
}

#| Inlay hint information.
#| 
#| @since 3.17.0
class InlayHint is export does LSPObject {
    #| The position of this hint.
    #| 
    #| If multiple hints have the same position, they will be shown in the order
    #| they appear in the response.
    has Any $.position is rw; #| Type: Position
    #| The label of this hint. A human readable string or an array of
    #| InlayHintLabelPart label parts.
    #| 
    #| *Note* that neither the string nor the label part can be empty.
    #| Type: Str | InlayHintLabelPart
    has Any $.label is rw;
    #| The kind of this hint. Can be omitted in which case the client
    #| should fall back to a reasonable default.
    #| Type: InlayHintKind (enum)
    has Any $.kind is rw;
    #| Optional text edits that are performed when accepting this inlay hint.
    #| 
    #| *Note* that edits are expected to change the document so that the inlay
    #| hint (or its nearest variant) is now part of the document and the inlay
    #| hint itself is now obsolete.
    #| Array of TextEdit
    has Any @.textEdits is rw;
    #| The tooltip text when you hover over this item.
    #| Type: Str | MarkupContent
    has Any $.tooltip is rw;
    #| Render padding before the hint.
    #| 
    #| Note: Padding should use the editor's background color, not the
    #| background color of the hint itself. That means padding can be used
    #| to visually align/separate an inlay hint.
    has Bool $.paddingLeft is rw;
    #| Render padding after the hint.
    #| 
    #| Note: Padding should use the editor's background color, not the
    #| background color of the hint itself. That means padding can be used
    #| to visually align/separate an inlay hint.
    has Bool $.paddingRight is rw;
    #| A data entry field that is preserved on an inlay hint between
    #| a `textDocument/inlayHint` and a `inlayHint/resolve` request.
    has Any $.data is rw; #| Type: Any
}

#| Inlay hint client capabilities.
#| 
#| @since 3.17.0
class InlayHintClientCapabilities is export does LSPObject {
    #| Whether inlay hints support dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Indicates which properties a client can resolve lazily on an inlay
    #| hint.
    has Any $.resolveSupport is rw; #| Type: ClientInlayHintResolveOptions
}

#| An inlay hint label part allows for interactive and composite labels
#| of inlay hints.
#| 
#| @since 3.17.0
class InlayHintLabelPart is export does LSPObject {
    #| The value of this label part.
    has Str $.value is rw;
    #| The tooltip text when you hover over this label part. Depending on
    #| the client capability `inlayHint.resolveSupport` clients might resolve
    #| this property late using the resolve request.
    #| Type: Str | MarkupContent
    has Any $.tooltip is rw;
    #| An optional source code location that represents this
    #| label part.
    #| 
    #| The editor will use this location for the hover and for code navigation
    #| features: This part will become a clickable link that resolves to the
    #| definition of the symbol at the given location (not necessarily the
    #| location itself), it shows the hover that shows at the given location,
    #| and it shows a context menu with further code navigation commands.
    #| 
    #| Depending on the client capability `inlayHint.resolveSupport` clients
    #| might resolve this property late using the resolve request.
    has Any $.location is rw; #| Type: Location
    #| An optional command for this label part.
    #| 
    #| Depending on the client capability `inlayHint.resolveSupport` clients
    #| might resolve this property late using the resolve request.
    has Any $.command is rw; #| Type: Command
}

#| Inlay hint options used during static registration.
#| 
#| @since 3.17.0
class InlayHintOptions is export does LSPObject {
    #| The server provides support to resolve additional
    #| information for an inlay hint item.
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| A parameter literal used in inlay hint requests.
#| 
#| @since 3.17.0
class InlayHintParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The document range for which inlay hints should be computed.
    has Any $.range is rw; #| Type: Range
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Inlay hint options used during static or dynamic registration.
#| 
#| @since 3.17.0
class InlayHintRegistrationOptions is export does LSPObject {
    #| The server provides support to resolve additional
    #| information for an inlay hint item.
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Client workspace capabilities specific to inlay hints.
#| 
#| @since 3.17.0
class InlayHintWorkspaceClientCapabilities is export does LSPObject {
    #| Whether the client implementation supports a refresh request sent from
    #| the server to the client.
    #| 
    #| Note that this event is global and will force the client to refresh all
    #| inlay hints currently shown. It should be used with absolute care and
    #| is useful for situation where a server for example detects a project wide
    #| change that requires such a calculation.
    has Bool $.refreshSupport is rw;
}

#| Client capabilities specific to inline completions.
#| 
#| @since 3.18.0
class InlineCompletionClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration for inline completion providers.
    has Bool $.dynamicRegistration is rw;
}

#| Provides information about the context in which an inline completion was requested.
#| 
#| @since 3.18.0
class InlineCompletionContext is export does LSPObject {
    #| Describes how the inline completion was triggered.
    #| Type: InlineCompletionTriggerKind (enum)
    has Any $.triggerKind is rw;
    #| Provides information about the currently selected item in the autocomplete widget if it is visible.
    has Any $.selectedCompletionInfo is rw; #| Type: SelectedCompletionInfo
}

#| An inline completion item represents a text snippet that is proposed inline to complete text that is being typed.
#| 
#| @since 3.18.0
class InlineCompletionItem is export does LSPObject {
    #| The text to replace the range with. Must be set.
    #| Type: Str | StringValue
    has Any $.insertText is rw;
    #| A text that is used to decide if this inline completion should be shown. When `falsy` the {@link InlineCompletionItem.insertText} is used.
    has Str $.filterText is rw;
    #| The range to replace. Must begin and end on the same line.
    has Any $.range is rw; #| Type: Range
    #| An optional {@link Command} that is executed *after* inserting this completion.
    has Any $.command is rw; #| Type: Command
}

#| Represents a collection of {@link InlineCompletionItem inline completion items} to be presented in the editor.
#| 
#| @since 3.18.0
class InlineCompletionList is export does LSPObject {
    #| The inline completion items
    #| Array of InlineCompletionItem
    has Any @.items is rw;
}

#| Inline completion options used during static registration.
#| 
#| @since 3.18.0
class InlineCompletionOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| A parameter literal used in inline completion requests.
#| 
#| @since 3.18.0
class InlineCompletionParams is export does LSPObject {
    #| Additional information about the context in which inline completions were
    #| requested.
    has Any $.context is rw; #| Type: InlineCompletionContext
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Inline completion options used during static or dynamic registration.
#| 
#| @since 3.18.0
class InlineCompletionRegistrationOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Client capabilities specific to inline values.
#| 
#| @since 3.17.0
class InlineValueClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration for inline value providers.
    has Bool $.dynamicRegistration is rw;
}

#| @since 3.17.0
class InlineValueContext is export does LSPObject {
    #| The stack frame (as a DAP Id) where the execution has stopped.
    has Int $.frameId is rw;
    #| The document range where execution has stopped.
    #| Typically the end position of the range denotes the line where the inline values are shown.
    has Any $.stoppedLocation is rw; #| Type: Range
}

#| To compute an inline value through an expression evaluation.
#| 
#| If only a range is specified, the expression should be
#| extracted from the underlying document.
#| 
#| An optional expression could be evaluated instead of
#| the extracted expression.
#| 
#| @since 3.17.0
class InlineValueEvaluatableExpression is export does LSPObject {
    #| The document range for which the inline value applies.
    #| 
    #| The range could be used to extract the evaluatable expression
    #| from the underlying document.
    has Any $.range is rw; #| Type: Range
    #| If specified the expression could be evaluated instead.
    has Str $.expression is rw;
}

#| Inline value options used during static registration.
#| 
#| @since 3.17.0
class InlineValueOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| A parameter literal used in inline value requests.
#| 
#| @since 3.17.0
class InlineValueParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The document range for which inline values information will be returned.
    has Any $.range is rw; #| Type: Range
    #| Additional information about the context in which inline values information was
    #| requested.
    has Any $.context is rw; #| Type: InlineValueContext
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Inline value options used during static or dynamic registration.
#| 
#| @since 3.17.0
class InlineValueRegistrationOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Returns inline value information as the complete text to be shown.
#| 
#| @since 3.17.0
class InlineValueText is export does LSPObject {
    #| The document range for which the inline value applies.
    has Any $.range is rw; #| Type: Range
    #| The text of the inline value.
    has Str $.text is rw;
}

#| To compute inline value through a variable lookup.
#| 
#| If only a range is specified, the variable name should
#| be extracted from the underlying document.
#| 
#| An optional variable name could be used to lookup instead
#| of the extracted name.
#| 
#| @since 3.17.0
class InlineValueVariableLookup is export does LSPObject {
    #| The document range for which the inline value applies.
    #| 
    #| The range could be used to extract the variable name
    #| from the underlying document.
    has Any $.range is rw; #| Type: Range
    #| If specified the name of the variable to look up.
    has Str $.variableName is rw;
    #| How to perform the lookup.
    has Bool $.caseSensitiveLookup is rw;
}

#| Client workspace capabilities specific to inline values.
#| 
#| @since 3.17.0
class InlineValueWorkspaceClientCapabilities is export does LSPObject {
    #| Whether the client implementation supports a refresh request sent from the
    #| server to the client.
    #| 
    #| Note that this event is global and will force the client to refresh all
    #| inline values currently shown. It should be used with absolute care and is
    #| useful for situation where a server for example detects a project wide
    #| change that requires such a calculation.
    has Bool $.refreshSupport is rw;
}

#| A special text edit to provide an insert and a replace operation.
#| 
#| @since 3.16.0
class InsertReplaceEdit is export does LSPObject {
    #| The string to be inserted.
    has Str $.newText is rw;
    #| The range if the insert is requested
    has Any $.insert is rw; #| Type: Range
    #| The range if the replace is requested.
    has Any $.replace is rw; #| Type: Range
}

#| Client capabilities for the linked editing range request.
#| 
#| @since 3.16.0
class LinkedEditingRangeClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `(TextDocumentRegistrationOptions & StaticRegistrationOptions)`
    #| return value for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
}

class LinkedEditingRangeOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

class LinkedEditingRangeParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

class LinkedEditingRangeRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| The result of a linked editing range request.
#| 
#| @since 3.16.0
class LinkedEditingRanges is export does LSPObject {
    #| A list of ranges that can be edited together. The ranges must have
    #| identical length and contain identical text content. The ranges cannot overlap.
    #| Array of Range
    has Any @.ranges is rw;
    #| An optional word pattern (regular expression) that describes valid contents for
    #| the given ranges. If no pattern is provided, the client configuration's word
    #| pattern will be used.
    has Str $.wordPattern is rw;
}

#| Represents a location inside a resource, such as a line
#| inside a text file.
class Location is export does LSPObject {
    has Str $.uri is rw;
    has Any $.range is rw; #| Type: Range
}

#| Represents the connection of two locations. Provides additional metadata over normal {@link Location locations},
#| including an origin range.
class LocationLink is export does LSPObject {
    #| Span of the origin of this link.
    #| 
    #| Used as the underlined span for mouse interaction. Defaults to the word range at
    #| the definition position.
    has Any $.originSelectionRange is rw; #| Type: Range
    #| The target resource identifier of this link.
    has Str $.targetUri is rw;
    #| The full target range of this link. If the target for example is a symbol then target range is the
    #| range enclosing this symbol not including leading/trailing whitespace but everything else
    #| like comments. This information is typically used to highlight the range in the editor.
    has Any $.targetRange is rw; #| Type: Range
    #| The range that should be selected and revealed when this link is being followed, e.g the name of a function.
    #| Must be contained by the `targetRange`. See also `DocumentSymbol#range`
    has Any $.targetSelectionRange is rw; #| Type: Range
}

#| Location with only uri and does not include range.
#| 
#| @since 3.18.0
class LocationUriOnly is export does LSPObject {
    has Str $.uri is rw;
}

#| The log message parameters.
class LogMessageParams is export does LSPObject {
    #| The message type. See {@link MessageType}
    #| Type: MessageType (enum)
    has Any $.type is rw;
    #| The actual message.
    has Str $.message is rw;
}

class LogTraceParams is export does LSPObject {
    has Str $.message is rw;
    has Str $.verbose is rw;
}

#| Client capabilities specific to the used markdown parser.
#| 
#| @since 3.16.0
class MarkdownClientCapabilities is export does LSPObject {
    #| The name of the parser.
    has Str $.parser is rw;
    #| The version of the parser.
    has Str $.version is rw;
    #| A list of HTML tags that the client allows / supports in
    #| Markdown.
    #| 
    #| @since 3.17.0
    has Str @.allowedTags is rw;
}

#| @since 3.18.0
#| @deprecated use MarkupContent instead.
class MarkedStringWithLanguage is export does LSPObject {
    has Str $.language is rw;
    has Str $.value is rw;
}

#| A `MarkupContent` literal represents a string value which content is interpreted base on its
#| kind flag. Currently the protocol supports `plaintext` and `markdown` as markup kinds.
#| 
#| If the kind is `markdown` then the value can contain fenced code blocks like in GitHub issues.
#| See https://help.github.com/articles/creating-and-highlighting-code-blocks/#syntax-highlighting
#| 
#| Here is an example how such a string can be constructed using JavaScript / TypeScript:
#| ```ts
#| let markdown: MarkdownContent = {
#|  kind: MarkupKind.Markdown,
#|  value: [
#|    '# Header',
#|    'Some text',
#|    '```typescript',
#|    'someCode();',
#|    '```'
#|  ].join('\n')
#| };
#| ```
#| 
#| *Please Note* that clients might sanitize the return markdown. A client could decide to
#| remove HTML from the markdown to avoid script execution.
class MarkupContent is export does LSPObject {
    #| The type of the Markup
    #| Type: MarkupKind (enum)
    has Any $.kind is rw;
    #| The content itself
    has Str $.value is rw;
}

class MessageActionItem is export does LSPObject {
    #| A short title like 'Retry', 'Open Log' etc.
    has Str $.title is rw;
}

#| Moniker definition to match LSIF 0.5 moniker definition.
#| 
#| @since 3.16.0
class Moniker is export does LSPObject {
    #| The scheme of the moniker. For example tsc or .Net
    has Str $.scheme is rw;
    #| The identifier of the moniker. The value is opaque in LSIF however
    #| schema owners are allowed to define the structure if they want.
    has Str $.identifier is rw;
    #| The scope in which the moniker is unique
    #| Type: UniquenessLevel (enum)
    has Any $.unique is rw;
    #| The moniker kind if known.
    #| Type: MonikerKind (enum)
    has Any $.kind is rw;
}

#| Client capabilities specific to the moniker request.
#| 
#| @since 3.16.0
class MonikerClientCapabilities is export does LSPObject {
    #| Whether moniker supports dynamic registration. If this is set to `true`
    #| the client supports the new `MonikerRegistrationOptions` return value
    #| for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
}

class MonikerOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

class MonikerParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

class MonikerRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
}

#| A notebook cell.
#| 
#| A cell's document URI must be unique across ALL notebook
#| cells and can therefore be used to uniquely identify a
#| notebook cell or the cell's text document.
#| 
#| @since 3.17.0
class NotebookCell is export does LSPObject {
    #| The cell's kind
    #| Type: NotebookCellKind (enum)
    has Any $.kind is rw;
    #| The URI of the cell's text document
    #| content.
    has Str $.document is rw;
    #| Additional metadata stored with the cell.
    #| 
    #| Note: should always be an object literal (e.g. LSPObject)
    has Any $.metadata is rw; #| Type: Any
    #| Additional execution summary information
    #| if supported by the client.
    has Any $.executionSummary is rw; #| Type: ExecutionSummary
}

#| A change describing how to move a `NotebookCell`
#| array from state S to S'.
#| 
#| @since 3.17.0
class NotebookCellArrayChange is export does LSPObject {
    #| The start oftest of the cell that changed.
    has Int $.start is rw;
    #| The deleted cells
    has Int $.deleteCount is rw;
    #| The new cells, if any
    #| Array of NotebookCell
    has Any @.cells is rw;
}

#| @since 3.18.0
class NotebookCellLanguage is export does LSPObject {
    has Str $.language is rw;
}

#| A notebook cell text document filter denotes a cell text
#| document by different properties.
#| 
#| @since 3.17.0
class NotebookCellTextDocumentFilter is export does LSPObject {
    #| A filter that matches against the notebook
    #| containing the notebook cell. If a string
    #| value is provided it matches against the
    #| notebook type. '*' matches every notebook.
    #| Type: Str | NotebookDocumentFilter
    has Any $.notebook is rw;
    #| A language id like `python`.
    #| 
    #| Will be matched against the language id of the
    #| notebook cell document. '*' matches every language.
    has Str $.language is rw;
}

#| A notebook document.
#| 
#| @since 3.17.0
class NotebookDocument is export does LSPObject {
    #| The notebook document's uri.
    has Str $.uri is rw;
    #| The type of the notebook.
    has Str $.notebookType is rw;
    #| The version number of this document (it will increase after each
    #| change, including undo/redo).
    has Int $.version is rw;
    #| Additional metadata stored with the notebook
    #| document.
    #| 
    #| Note: should always be an object literal (e.g. LSPObject)
    has Any $.metadata is rw; #| Type: Any
    #| The cells of a notebook.
    #| Array of NotebookCell
    has Any @.cells is rw;
}

#| Structural changes to cells in a notebook document.
#| 
#| @since 3.18.0
class NotebookDocumentCellChangeStructure is export does LSPObject {
    #| The change to the cell array.
    has Any $.array is rw; #| Type: NotebookCellArrayChange
    #| Additional opened cell text documents.
    #| Array of TextDocumentItem
    has Any @.didOpen is rw;
    #| Additional closed cell text documents.
    #| Array of TextDocumentIdentifier
    has Any @.didClose is rw;
}

#| Cell changes to a notebook document.
#| 
#| @since 3.18.0
class NotebookDocumentCellChanges is export does LSPObject {
    #| Changes to the cell structure to add or
    #| remove cells.
    has Any $.structure is rw; #| Type: NotebookDocumentCellChangeStructure
    #| Changes to notebook cells properties like its
    #| kind, execution summary or metadata.
    #| Array of NotebookCell
    has Any @.data is rw;
    #| Changes to the text content of notebook cells.
    #| Array of NotebookDocumentCellContentChanges
    has Any @.textContent is rw;
}

#| Content changes to a cell in a notebook document.
#| 
#| @since 3.18.0
class NotebookDocumentCellContentChanges is export does LSPObject {
    has Any $.document is rw; #| Type: VersionedTextDocumentIdentifier
    #| Array of TextDocumentContentChangeEvent
    has Any @.changes is rw;
}

#| A change event for a notebook document.
#| 
#| @since 3.17.0
class NotebookDocumentChangeEvent is export does LSPObject {
    #| The changed meta data if any.
    #| 
    #| Note: should always be an object literal (e.g. LSPObject)
    has Any $.metadata is rw; #| Type: Any
    #| Changes to cells
    has Any $.cells is rw; #| Type: NotebookDocumentCellChanges
}

#| Capabilities specific to the notebook document support.
#| 
#| @since 3.17.0
class NotebookDocumentClientCapabilities is export does LSPObject {
    #| Capabilities specific to notebook document synchronization
    #| 
    #| @since 3.17.0
    has Any $.synchronization is rw; #| Type: NotebookDocumentSyncClientCapabilities
}

#| A notebook document filter where `notebookType` is required field.
#| 
#| @since 3.18.0
class NotebookDocumentFilterNotebookType is export does LSPObject {
    #| The type of the enclosing notebook.
    has Str $.notebookType is rw;
    #| A Uri {@link Uri.scheme scheme}, like `file` or `untitled`.
    has Str $.scheme is rw;
    #| A glob pattern.
    #| Type: GlobPattern (typeAlias)
    has Any $.pattern is rw;
}

#| A notebook document filter where `pattern` is required field.
#| 
#| @since 3.18.0
class NotebookDocumentFilterPattern is export does LSPObject {
    #| The type of the enclosing notebook.
    has Str $.notebookType is rw;
    #| A Uri {@link Uri.scheme scheme}, like `file` or `untitled`.
    has Str $.scheme is rw;
    #| A glob pattern.
    #| Type: GlobPattern (typeAlias)
    has Any $.pattern is rw;
}

#| A notebook document filter where `scheme` is required field.
#| 
#| @since 3.18.0
class NotebookDocumentFilterScheme is export does LSPObject {
    #| The type of the enclosing notebook.
    has Str $.notebookType is rw;
    #| A Uri {@link Uri.scheme scheme}, like `file` or `untitled`.
    has Str $.scheme is rw;
    #| A glob pattern.
    #| Type: GlobPattern (typeAlias)
    has Any $.pattern is rw;
}

#| @since 3.18.0
class NotebookDocumentFilterWithCells is export does LSPObject {
    #| The notebook to be synced If a string
    #| value is provided it matches against the
    #| notebook type. '*' matches every notebook.
    #| Type: Str | NotebookDocumentFilter
    has Any $.notebook is rw;
    #| The cells of the matching notebook to be synced.
    #| Array of NotebookCellLanguage
    has Any @.cells is rw;
}

#| @since 3.18.0
class NotebookDocumentFilterWithNotebook is export does LSPObject {
    #| The notebook to be synced If a string
    #| value is provided it matches against the
    #| notebook type. '*' matches every notebook.
    #| Type: Str | NotebookDocumentFilter
    has Any $.notebook is rw;
    #| The cells of the matching notebook to be synced.
    #| Array of NotebookCellLanguage
    has Any @.cells is rw;
}

#| A literal to identify a notebook document in the client.
#| 
#| @since 3.17.0
class NotebookDocumentIdentifier is export does LSPObject {
    #| The notebook document's uri.
    has Str $.uri is rw;
}

#| Notebook specific client capabilities.
#| 
#| @since 3.17.0
class NotebookDocumentSyncClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is
    #| set to `true` the client supports the new
    #| `(TextDocumentRegistrationOptions & StaticRegistrationOptions)`
    #| return value for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
    #| The client supports sending execution summary data per cell.
    has Bool $.executionSummarySupport is rw;
}

#| Options specific to a notebook plus its cells
#| to be synced to the server.
#| 
#| If a selector provides a notebook document
#| filter but no cell selector all cells of a
#| matching notebook document will be synced.
#| 
#| If a selector provides no notebook document
#| filter but only a cell selector all notebook
#| document that contain at least one matching
#| cell will be synced.
#| 
#| @since 3.17.0
class NotebookDocumentSyncOptions is export does LSPObject {
    #| The notebooks to be synced
    #| Array of NotebookDocumentFilterWithNotebook | NotebookDocumentFilterWithCells
    has Any @.notebookSelector is rw;
    #| Whether save notification should be forwarded to
    #| the server. Will only be honored if mode === `notebook`.
    has Bool $.save is rw;
}

#| Registration options specific to a notebook.
#| 
#| @since 3.17.0
class NotebookDocumentSyncRegistrationOptions is export does LSPObject {
    #| The notebooks to be synced
    #| Array of NotebookDocumentFilterWithNotebook | NotebookDocumentFilterWithCells
    has Any @.notebookSelector is rw;
    #| Whether save notification should be forwarded to
    #| the server. Will only be honored if mode === `notebook`.
    has Bool $.save is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| A text document identifier to optionally denote a specific version of a text document.
class OptionalVersionedTextDocumentIdentifier is export does LSPObject {
    #| The version number of this document. If a versioned text document identifier
    #| is sent from the server to the client and the file is not open in the editor
    #| (the server has not received an open notification before) the server can send
    #| `null` to indicate that the version is unknown and the content on disk is the
    #| truth (as specified with document content ownership).
    #| Type: Int | Any
    has Any $.version is rw;
    #| The text document's uri.
    has Str $.uri is rw;
}

#| Represents a parameter of a callable-signature. A parameter can
#| have a label and a doc-comment.
class ParameterInformation is export does LSPObject {
    #| The label of this parameter information.
    #| 
    #| Either a string or an inclusive start and exclusive end offsets within its containing
    #| signature label. (see SignatureInformation.label). The offsets are based on a UTF-16
    #| string representation as `Position` and `Range` does.
    #| 
    #| To avoid ambiguities a server should use the [start, end] offset value instead of using
    #| a substring. Whether a client support this is controlled via `labelOffsetSupport` client
    #| capability.
    #| 
    #| *Note*: a label of type string should be a substring of its containing signature label.
    #| Its intended use case is to highlight the parameter label part in the `SignatureInformation.label`.
    #| Type: Str | Any
    has Any $.label is rw;
    #| The human-readable doc-comment of this parameter. Will be shown
    #| in the UI but can be omitted.
    #| Type: Str | MarkupContent
    has Any $.documentation is rw;
}

class PartialResultParams is export does LSPObject {
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Position in a text document expressed as zero-based line and character
#| offset. Prior to 3.17 the offsets were always based on a UTF-16 string
#| representation. So a string of the form `a𐐀b` the character offset of the
#| character `a` is 0, the character offset of `𐐀` is 1 and the character
#| offset of b is 3 since `𐐀` is represented using two code units in UTF-16.
#| Since 3.17 clients and servers can agree on a different string encoding
#| representation (e.g. UTF-8). The client announces it's supported encoding
#| via the client capability [`general.positionEncodings`](https://microsoft.github.io/language-server-protocol/specifications/specification-current/#clientCapabilities).
#| The value is an array of position encodings the client supports, with
#| decreasing preference (e.g. the encoding at index `0` is the most preferred
#| one). To stay backwards compatible the only mandatory encoding is UTF-16
#| represented via the string `utf-16`. The server can pick one of the
#| encodings offered by the client and signals that encoding back to the
#| client via the initialize result's property
#| [`capabilities.positionEncoding`](https://microsoft.github.io/language-server-protocol/specifications/specification-current/#serverCapabilities). If the string value
#| `utf-16` is missing from the client's capability `general.positionEncodings`
#| servers can safely assume that the client supports UTF-16. If the server
#| omits the position encoding in its initialize result the encoding defaults
#| to the string value `utf-16`. Implementation considerations: since the
#| conversion from one encoding into another requires the content of the
#| file / line the conversion is best done where the file is read which is
#| usually on the server side.
#| 
#| Positions are line end character agnostic. So you can not specify a position
#| that denotes `\r|\n` or `\n|` where `|` represents the character offset.
#| 
#| @since 3.17.0 - support for negotiated position encoding.
class Position is export does LSPObject {
    #| Line position in a document (zero-based).
    has Int $.line is rw;
    #| Character offset on a line in a document (zero-based).
    #| 
    #| The meaning of this offset is determined by the negotiated
    #| `PositionEncodingKind`.
    has Int $.character is rw;
}

#| @since 3.18.0
class PrepareRenameDefaultBehavior is export does LSPObject {
    has Bool $.defaultBehavior is rw;
}

class PrepareRenameParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| @since 3.18.0
class PrepareRenamePlaceholder is export does LSPObject {
    has Any $.range is rw; #| Type: Range
    has Str $.placeholder is rw;
}

#| A previous result id in a workspace pull request.
#| 
#| @since 3.17.0
class PreviousResultId is export does LSPObject {
    #| The URI for which the client knowns a
    #| result id.
    has Str $.uri is rw;
    #| The value of the previous result id.
    has Str $.value is rw;
}

class ProgressParams is export does LSPObject {
    #| The progress token provided by the client or server.
    #| Type: ProgressToken (typeAlias)
    has Any $.token is rw;
    #| The progress data.
    has Any $.value is rw; #| Type: Any
}

#| The publish diagnostic client capabilities.
class PublishDiagnosticsClientCapabilities is export does LSPObject {
    #| Whether the client interprets the version property of the
    #| `textDocument/publishDiagnostics` notification's parameter.
    #| 
    #| @since 3.15.0
    has Bool $.versionSupport is rw;
    #| Whether the clients accepts diagnostics with related information.
    has Bool $.relatedInformation is rw;
    #| Client supports the tag property to provide meta data about a diagnostic.
    #| Clients supporting tags have to handle unknown tags gracefully.
    #| 
    #| @since 3.15.0
    has Any $.tagSupport is rw; #| Type: ClientDiagnosticsTagOptions
    #| Client supports a codeDescription property
    #| 
    #| @since 3.16.0
    has Bool $.codeDescriptionSupport is rw;
    #| Whether code action supports the `data` property which is
    #| preserved between a `textDocument/publishDiagnostics` and
    #| `textDocument/codeAction` request.
    #| 
    #| @since 3.16.0
    has Bool $.dataSupport is rw;
}

#| The publish diagnostic notification's parameters.
class PublishDiagnosticsParams is export does LSPObject {
    #| The URI for which diagnostic information is reported.
    has Str $.uri is rw;
    #| Optional the version number of the document the diagnostics are published for.
    #| 
    #| @since 3.15.0
    has Int $.version is rw;
    #| An array of diagnostic information items.
    #| Array of Diagnostic
    has Any @.diagnostics is rw;
}

#| A range in a text document expressed as (zero-based) start and end positions.
#| 
#| If you want to specify a range that contains a line including the line ending
#| character(s) then use an end position denoting the start of the next line.
#| For example:
#| ```ts
#| {
#|     start: { line: 5, character: 23 }
#|     end : { line 6, character : 0 }
#| }
#| ```
class Range is export does LSPObject {
    #| The range's start position.
    has Any $.start is rw; #| Type: Position
    #| The range's end position.
    has Any $.end is rw; #| Type: Position
}

#| Client Capabilities for a {@link ReferencesRequest}.
class ReferenceClientCapabilities is export does LSPObject {
    #| Whether references supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
}

#| Value-object that contains additional information when
#| requesting references.
class ReferenceContext is export does LSPObject {
    #| Include the declaration of the current symbol.
    has Bool $.includeDeclaration is rw;
}

#| Reference options.
class ReferenceOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link ReferencesRequest}.
class ReferenceParams is export does LSPObject {
    has Any $.context is rw; #| Type: ReferenceContext
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link ReferencesRequest}.
class ReferenceRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
}

#| General parameters to register for a notification or to register a provider.
class Registration is export does LSPObject {
    #| The id used to register the request. The id can be used to deregister
    #| the request again.
    has Str $.id is rw;
    #| The method / capability to register for.
    has Str $.method is rw;
    #| Options necessary for the registration.
    has Any $.registerOptions is rw; #| Type: Any
}

class RegistrationParams is export does LSPObject {
    #| Array of Registration
    has Any @.registrations is rw;
}

#| Client capabilities specific to regular expressions.
#| 
#| @since 3.16.0
class RegularExpressionsClientCapabilities is export does LSPObject {
    #| The engine's name.
    #| Type: RegularExpressionEngineKind (typeAlias)
    has Any $.engine is rw;
    #| The engine's version.
    has Str $.version is rw;
}

#| A full diagnostic report with a set of related documents.
#| 
#| @since 3.17.0
class RelatedFullDocumentDiagnosticReport is export does LSPObject {
    #| Diagnostics of related documents. This information is useful
    #| in programming languages where code in a file A can generate
    #| diagnostics in a file B which A depends on. An example of
    #| such a language is C/C++ where marco definitions in a file
    #| a.cpp and result in errors in a header file b.hpp.
    #| 
    #| @since 3.17.0
    has Any %.relatedDocuments is rw;
    #| A full document diagnostic report.
    has Str $.kind is rw;
    #| An optional result id. If provided it will
    #| be sent on the next diagnostic request for the
    #| same document.
    has Str $.resultId is rw;
    #| The actual items.
    #| Array of Diagnostic
    has Any @.items is rw;
}

#| An unchanged diagnostic report with a set of related documents.
#| 
#| @since 3.17.0
class RelatedUnchangedDocumentDiagnosticReport is export does LSPObject {
    #| Diagnostics of related documents. This information is useful
    #| in programming languages where code in a file A can generate
    #| diagnostics in a file B which A depends on. An example of
    #| such a language is C/C++ where marco definitions in a file
    #| a.cpp and result in errors in a header file b.hpp.
    #| 
    #| @since 3.17.0
    has Any %.relatedDocuments is rw;
    #| A document diagnostic report indicating
    #| no changes to the last result. A server can
    #| only return `unchanged` if result ids are
    #| provided.
    has Str $.kind is rw;
    #| A result id which will be sent on the next
    #| diagnostic request for the same document.
    has Str $.resultId is rw;
}

#| A relative pattern is a helper to construct glob patterns that are matched
#| relatively to a base URI. The common value for a `baseUri` is a workspace
#| folder root, but it can be another absolute URI as well.
#| 
#| @since 3.17.0
class RelativePattern is export does LSPObject {
    #| A workspace folder or a base URI to which this pattern will be matched
    #| against relatively.
    #| Type: WorkspaceFolder | Str
    has Any $.baseUri is rw;
    #| The actual glob pattern;
    #| Type: Pattern (typeAlias)
    has Any $.pattern is rw;
}

class RenameClientCapabilities is export does LSPObject {
    #| Whether rename supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Client supports testing for validity of rename operations
    #| before execution.
    #| 
    #| @since 3.12.0
    has Bool $.prepareSupport is rw;
    #| Client supports the default behavior result.
    #| 
    #| The value indicates the default behavior used by the
    #| client.
    #| 
    #| @since 3.16.0
    #| Type: PrepareSupportDefaultBehavior (enum)
    has Any $.prepareSupportDefaultBehavior is rw;
    #| Whether the client honors the change annotations in
    #| text edits and resource operations returned via the
    #| rename request's workspace edit by for example presenting
    #| the workspace edit in the user interface and asking
    #| for confirmation.
    #| 
    #| @since 3.16.0
    has Bool $.honorsChangeAnnotations is rw;
}

#| Rename file operation
class RenameFile is export does LSPObject {
    #| A rename
    has Str $.kind is rw;
    #| The old (existing) location.
    has Str $.oldUri is rw;
    #| The new location.
    has Str $.newUri is rw;
    #| Rename options.
    has Any $.options is rw; #| Type: RenameFileOptions
    #| An optional annotation identifier describing the operation.
    #| 
    #| @since 3.16.0
    #| Type: ChangeAnnotationIdentifier (typeAlias)
    has Any $.annotationId is rw;
}

#| Rename file options
class RenameFileOptions is export does LSPObject {
    #| Overwrite target if existing. Overwrite wins over `ignoreIfExists`
    has Bool $.overwrite is rw;
    #| Ignores if target exists.
    has Bool $.ignoreIfExists is rw;
}

#| The parameters sent in notifications/requests for user-initiated renames of
#| files.
#| 
#| @since 3.16.0
class RenameFilesParams is export does LSPObject {
    #| An array of all files/folders renamed in this operation. When a folder is renamed, only
    #| the folder will be included, and not its children.
    #| Array of FileRename
    has Any @.files is rw;
}

#| Provider options for a {@link RenameRequest}.
class RenameOptions is export does LSPObject {
    #| Renames should be checked and tested before being executed.
    #| 
    #| @since version 3.12.0
    has Bool $.prepareProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link RenameRequest}.
class RenameParams is export does LSPObject {
    #| The new name of the symbol. If the given name is not valid the
    #| request must return a {@link ResponseError} with an
    #| appropriate message set.
    has Str $.newName is rw;
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Registration options for a {@link RenameRequest}.
class RenameRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| Renames should be checked and tested before being executed.
    #| 
    #| @since version 3.12.0
    has Bool $.prepareProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| A generic resource operation.
class ResourceOperation is export does LSPObject {
    #| The resource operation kind.
    has Str $.kind is rw;
    #| An optional annotation identifier describing the operation.
    #| 
    #| @since 3.16.0
    #| Type: ChangeAnnotationIdentifier (typeAlias)
    has Any $.annotationId is rw;
}

#| Save options.
class SaveOptions is export does LSPObject {
    #| The client is supposed to include the content on save.
    has Bool $.includeText is rw;
}

#| Describes the currently selected completion item.
#| 
#| @since 3.18.0
class SelectedCompletionInfo is export does LSPObject {
    #| The range that will be replaced if this completion item is accepted.
    has Any $.range is rw; #| Type: Range
    #| The text the range will be replaced with if this completion is accepted.
    has Str $.text is rw;
}

#| A selection range represents a part of a selection hierarchy. A selection range
#| may have a parent selection range that contains it.
class SelectionRange is export does LSPObject {
    #| The {@link Range range} of this selection range.
    has Any $.range is rw; #| Type: Range
    #| The parent selection range containing this range. Therefore `parent.range` must contain `this.range`.
    has Any $.parent is rw; #| Type: SelectionRange
}

class SelectionRangeClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration for selection range providers. If this is set to `true`
    #| the client supports the new `SelectionRangeRegistrationOptions` return value for the corresponding server
    #| capability as well.
    has Bool $.dynamicRegistration is rw;
}

class SelectionRangeOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| A parameter literal used in selection range requests.
class SelectionRangeParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The positions inside the text document.
    #| Array of Position
    has Any @.positions is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

class SelectionRangeRegistrationOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| @since 3.16.0
class SemanticTokens is export does LSPObject {
    #| An optional result id. If provided and clients support delta updating
    #| the client will include the result id in the next semantic token request.
    #| A server can then instead of computing all semantic tokens again simply
    #| send a delta.
    has Str $.resultId is rw;
    #| The actual tokens.
    has Int @.data is rw;
}

#| @since 3.16.0
class SemanticTokensClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `(TextDocumentRegistrationOptions & StaticRegistrationOptions)`
    #| return value for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
    #| Which requests the client supports and might send to the server
    #| depending on the server's capability. Please note that clients might not
    #| show semantic tokens or degrade some of the user experience if a range
    #| or full request is advertised by the client but not provided by the
    #| server. If for example the client capability `requests.full` and
    #| `request.range` are both set to true but the server only provides a
    #| range provider the client might not render a minimap correctly or might
    #| even decide to not show any semantic tokens at all.
    has Any $.requests is rw; #| Type: ClientSemanticTokensRequestOptions
    #| The token types that the client supports.
    has Str @.tokenTypes is rw;
    #| The token modifiers that the client supports.
    has Str @.tokenModifiers is rw;
    #| The token formats the clients supports.
    #| Array of TokenFormat
    has Any @.formats is rw;
    #| Whether the client supports tokens that can overlap each other.
    has Bool $.overlappingTokenSupport is rw;
    #| Whether the client supports tokens that can span multiple lines.
    has Bool $.multilineTokenSupport is rw;
    #| Whether the client allows the server to actively cancel a
    #| semantic token request, e.g. supports returning
    #| LSPErrorCodes.ServerCancelled. If a server does the client
    #| needs to retrigger the request.
    #| 
    #| @since 3.17.0
    has Bool $.serverCancelSupport is rw;
    #| Whether the client uses semantic tokens to augment existing
    #| syntax tokens. If set to `true` client side created syntax
    #| tokens and semantic tokens are both used for colorization. If
    #| set to `false` the client only uses the returned semantic tokens
    #| for colorization.
    #| 
    #| If the value is `undefined` then the client behavior is not
    #| specified.
    #| 
    #| @since 3.17.0
    has Bool $.augmentsSyntaxTokens is rw;
}

#| @since 3.16.0
class SemanticTokensDelta is export does LSPObject {
    has Str $.resultId is rw;
    #| The semantic token edits to transform a previous result into a new result.
    #| Array of SemanticTokensEdit
    has Any @.edits is rw;
}

#| @since 3.16.0
class SemanticTokensDeltaParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The result id of a previous response. The result Id can either point to a full response
    #| or a delta response depending on what was received last.
    has Str $.previousResultId is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| @since 3.16.0
class SemanticTokensDeltaPartialResult is export does LSPObject {
    #| Array of SemanticTokensEdit
    has Any @.edits is rw;
}

#| @since 3.16.0
class SemanticTokensEdit is export does LSPObject {
    #| The start offset of the edit.
    has Int $.start is rw;
    #| The count of elements to remove.
    has Int $.deleteCount is rw;
    #| The elements to insert.
    has Int @.data is rw;
}

#| Semantic tokens options to support deltas for full documents
#| 
#| @since 3.18.0
class SemanticTokensFullDelta is export does LSPObject {
    #| The server supports deltas for full documents.
    has Bool $.delta is rw;
}

#| @since 3.16.0
class SemanticTokensLegend is export does LSPObject {
    #| The token types a server uses.
    has Str @.tokenTypes is rw;
    #| The token modifiers a server uses.
    has Str @.tokenModifiers is rw;
}

#| @since 3.16.0
class SemanticTokensOptions is export does LSPObject {
    #| The legend used by the server
    has Any $.legend is rw; #| Type: SemanticTokensLegend
    #| Server supports providing semantic tokens for a specific range
    #| of a document.
    #| Type: Bool | Hash
    has Any $.range is rw;
    #| Server supports providing semantic tokens for a full document.
    #| Type: Bool | SemanticTokensFullDelta
    has Any $.full is rw;
    has Bool $.workDoneProgress is rw;
}

#| @since 3.16.0
class SemanticTokensParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| @since 3.16.0
class SemanticTokensPartialResult is export does LSPObject {
    has Int @.data is rw;
}

#| @since 3.16.0
class SemanticTokensRangeParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The range the semantic tokens are requested for.
    has Any $.range is rw; #| Type: Range
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| @since 3.16.0
class SemanticTokensRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| The legend used by the server
    has Any $.legend is rw; #| Type: SemanticTokensLegend
    #| Server supports providing semantic tokens for a specific range
    #| of a document.
    #| Type: Bool | Hash
    has Any $.range is rw;
    #| Server supports providing semantic tokens for a full document.
    #| Type: Bool | SemanticTokensFullDelta
    has Any $.full is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| @since 3.16.0
class SemanticTokensWorkspaceClientCapabilities is export does LSPObject {
    #| Whether the client implementation supports a refresh request sent from
    #| the server to the client.
    #| 
    #| Note that this event is global and will force the client to refresh all
    #| semantic tokens currently shown. It should be used with absolute care
    #| and is useful for situation where a server for example detects a project
    #| wide change that requires such a calculation.
    has Bool $.refreshSupport is rw;
}

#| Defines the capabilities provided by a language
#| server.
class ServerCapabilities is export does LSPObject {
    #| The position encoding the server picked from the encodings offered
    #| by the client via the client capability `general.positionEncodings`.
    #| 
    #| If the client didn't provide any position encodings the only valid
    #| value that a server can return is 'utf-16'.
    #| 
    #| If omitted it defaults to 'utf-16'.
    #| 
    #| @since 3.17.0
    #| Type: PositionEncodingKind (enum)
    has Any $.positionEncoding is rw;
    #| Defines how text documents are synced. Is either a detailed structure
    #| defining each notification or for backwards compatibility the
    #| TextDocumentSyncKind number.
    #| Type: TextDocumentSyncOptions | TextDocumentSyncKind
    has Any $.textDocumentSync is rw;
    #| Defines how notebook documents are synced.
    #| 
    #| @since 3.17.0
    #| Type: NotebookDocumentSyncOptions | NotebookDocumentSyncRegistrationOptions
    has Any $.notebookDocumentSync is rw;
    #| The server provides completion support.
    has Any $.completionProvider is rw; #| Type: CompletionOptions
    #| The server provides hover support.
    #| Type: Bool | HoverOptions
    has Any $.hoverProvider is rw;
    #| The server provides signature help support.
    has Any $.signatureHelpProvider is rw; #| Type: SignatureHelpOptions
    #| The server provides Goto Declaration support.
    #| Type: Bool | DeclarationOptions | DeclarationRegistrationOptions
    has Any $.declarationProvider is rw;
    #| The server provides goto definition support.
    #| Type: Bool | DefinitionOptions
    has Any $.definitionProvider is rw;
    #| The server provides Goto Type Definition support.
    #| Type: Bool | TypeDefinitionOptions | TypeDefinitionRegistrationOptions
    has Any $.typeDefinitionProvider is rw;
    #| The server provides Goto Implementation support.
    #| Type: Bool | ImplementationOptions | ImplementationRegistrationOptions
    has Any $.implementationProvider is rw;
    #| The server provides find references support.
    #| Type: Bool | ReferenceOptions
    has Any $.referencesProvider is rw;
    #| The server provides document highlight support.
    #| Type: Bool | DocumentHighlightOptions
    has Any $.documentHighlightProvider is rw;
    #| The server provides document symbol support.
    #| Type: Bool | DocumentSymbolOptions
    has Any $.documentSymbolProvider is rw;
    #| The server provides code actions. CodeActionOptions may only be
    #| specified if the client states that it supports
    #| `codeActionLiteralSupport` in its initial `initialize` request.
    #| Type: Bool | CodeActionOptions
    has Any $.codeActionProvider is rw;
    #| The server provides code lens.
    has Any $.codeLensProvider is rw; #| Type: CodeLensOptions
    #| The server provides document link support.
    has Any $.documentLinkProvider is rw; #| Type: DocumentLinkOptions
    #| The server provides color provider support.
    #| Type: Bool | DocumentColorOptions | DocumentColorRegistrationOptions
    has Any $.colorProvider is rw;
    #| The server provides workspace symbol support.
    #| Type: Bool | WorkspaceSymbolOptions
    has Any $.workspaceSymbolProvider is rw;
    #| The server provides document formatting.
    #| Type: Bool | DocumentFormattingOptions
    has Any $.documentFormattingProvider is rw;
    #| The server provides document range formatting.
    #| Type: Bool | DocumentRangeFormattingOptions
    has Any $.documentRangeFormattingProvider is rw;
    #| The server provides document formatting on typing.
    has Any $.documentOnTypeFormattingProvider is rw; #| Type: DocumentOnTypeFormattingOptions
    #| The server provides rename support. RenameOptions may only be
    #| specified if the client states that it supports
    #| `prepareSupport` in its initial `initialize` request.
    #| Type: Bool | RenameOptions
    has Any $.renameProvider is rw;
    #| The server provides folding provider support.
    #| Type: Bool | FoldingRangeOptions | FoldingRangeRegistrationOptions
    has Any $.foldingRangeProvider is rw;
    #| The server provides selection range support.
    #| Type: Bool | SelectionRangeOptions | SelectionRangeRegistrationOptions
    has Any $.selectionRangeProvider is rw;
    #| The server provides execute command support.
    has Any $.executeCommandProvider is rw; #| Type: ExecuteCommandOptions
    #| The server provides call hierarchy support.
    #| 
    #| @since 3.16.0
    #| Type: Bool | CallHierarchyOptions | CallHierarchyRegistrationOptions
    has Any $.callHierarchyProvider is rw;
    #| The server provides linked editing range support.
    #| 
    #| @since 3.16.0
    #| Type: Bool | LinkedEditingRangeOptions | LinkedEditingRangeRegistrationOptions
    has Any $.linkedEditingRangeProvider is rw;
    #| The server provides semantic tokens support.
    #| 
    #| @since 3.16.0
    #| Type: SemanticTokensOptions | SemanticTokensRegistrationOptions
    has Any $.semanticTokensProvider is rw;
    #| The server provides moniker support.
    #| 
    #| @since 3.16.0
    #| Type: Bool | MonikerOptions | MonikerRegistrationOptions
    has Any $.monikerProvider is rw;
    #| The server provides type hierarchy support.
    #| 
    #| @since 3.17.0
    #| Type: Bool | TypeHierarchyOptions | TypeHierarchyRegistrationOptions
    has Any $.typeHierarchyProvider is rw;
    #| The server provides inline values.
    #| 
    #| @since 3.17.0
    #| Type: Bool | InlineValueOptions | InlineValueRegistrationOptions
    has Any $.inlineValueProvider is rw;
    #| The server provides inlay hints.
    #| 
    #| @since 3.17.0
    #| Type: Bool | InlayHintOptions | InlayHintRegistrationOptions
    has Any $.inlayHintProvider is rw;
    #| The server has support for pull model diagnostics.
    #| 
    #| @since 3.17.0
    #| Type: DiagnosticOptions | DiagnosticRegistrationOptions
    has Any $.diagnosticProvider is rw;
    #| Inline completion options used during static registration.
    #| 
    #| @since 3.18.0
    #| Type: Bool | InlineCompletionOptions
    has Any $.inlineCompletionProvider is rw;
    #| Workspace specific server capabilities.
    has Any $.workspace is rw; #| Type: WorkspaceOptions
    #| Experimental server capabilities.
    has Any $.experimental is rw; #| Type: Any
}

#| @since 3.18.0
class ServerCompletionItemOptions is export does LSPObject {
    #| The server has support for completion item label
    #| details (see also `CompletionItemLabelDetails`) when
    #| receiving a completion item in a resolve call.
    #| 
    #| @since 3.17.0
    has Bool $.labelDetailsSupport is rw;
}

#| Information about the server
#| 
#| @since 3.15.0
#| @since 3.18.0 ServerInfo type name added.
class ServerInfo is export does LSPObject {
    #| The name of the server as defined by the server.
    has Str $.name is rw;
    #| The server's version as defined by the server.
    has Str $.version is rw;
}

class SetTraceParams is export does LSPObject {
    #| Type: TraceValue (enum)
    has Any $.value is rw;
}

#| Client capabilities for the showDocument request.
#| 
#| @since 3.16.0
class ShowDocumentClientCapabilities is export does LSPObject {
    #| The client has support for the showDocument
    #| request.
    has Bool $.support is rw;
}

#| Params to show a resource in the UI.
#| 
#| @since 3.16.0
class ShowDocumentParams is export does LSPObject {
    #| The uri to show.
    has Str $.uri is rw;
    #| Indicates to show the resource in an external program.
    #| To show, for example, `https://code.visualstudio.com/`
    #| in the default WEB browser set `external` to `true`.
    has Bool $.external is rw;
    #| An optional property to indicate whether the editor
    #| showing the document should take focus or not.
    #| Clients might ignore this property if an external
    #| program is started.
    has Bool $.takeFocus is rw;
    #| An optional selection range if the document is a text
    #| document. Clients might ignore the property if an
    #| external program is started or the file is not a text
    #| file.
    has Any $.selection is rw; #| Type: Range
}

#| The result of a showDocument request.
#| 
#| @since 3.16.0
class ShowDocumentResult is export does LSPObject {
    #| A boolean indicating if the show was successful.
    has Bool $.success is rw;
}

#| The parameters of a notification message.
class ShowMessageParams is export does LSPObject {
    #| The message type. See {@link MessageType}
    #| Type: MessageType (enum)
    has Any $.type is rw;
    #| The actual message.
    has Str $.message is rw;
}

#| Show message request client capabilities
class ShowMessageRequestClientCapabilities is export does LSPObject {
    #| Capabilities specific to the `MessageActionItem` type.
    has Any $.messageActionItem is rw; #| Type: ClientShowMessageActionItemOptions
}

class ShowMessageRequestParams is export does LSPObject {
    #| The message type. See {@link MessageType}
    #| Type: MessageType (enum)
    has Any $.type is rw;
    #| The actual message.
    has Str $.message is rw;
    #| The message action items to present.
    #| Array of MessageActionItem
    has Any @.actions is rw;
}

#| Signature help represents the signature of something
#| callable. There can be multiple signature but only one
#| active and only one active parameter.
class SignatureHelp is export does LSPObject {
    #| One or more signatures.
    #| Array of SignatureInformation
    has Any @.signatures is rw;
    #| The active signature. If omitted or the value lies outside the
    #| range of `signatures` the value defaults to zero or is ignored if
    #| the `SignatureHelp` has no signatures.
    #| 
    #| Whenever possible implementors should make an active decision about
    #| the active signature and shouldn't rely on a default value.
    #| 
    #| In future version of the protocol this property might become
    #| mandatory to better express this.
    has Int $.activeSignature is rw;
    #| The active parameter of the active signature.
    #| 
    #| If `null`, no parameter of the signature is active (for example a named
    #| argument that does not match any declared parameters). This is only valid
    #| if the client specifies the client capability
    #| `textDocument.signatureHelp.noActiveParameterSupport === true`
    #| 
    #| If omitted or the value lies outside the range of
    #| `signatures[activeSignature].parameters` defaults to 0 if the active
    #| signature has parameters.
    #| 
    #| If the active signature has no parameters it is ignored.
    #| 
    #| In future version of the protocol this property might become
    #| mandatory (but still nullable) to better express the active parameter if
    #| the active signature does have any.
    #| 
    #| Since version 3.16.0 the `SignatureInformation` itself provides a
    #| `activeParameter` property and it should be used instead of this one.
    #| Type: Int | Any
    has Any $.activeParameter is rw;
}

#| Client Capabilities for a {@link SignatureHelpRequest}.
class SignatureHelpClientCapabilities is export does LSPObject {
    #| Whether signature help supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| The client supports the following `SignatureInformation`
    #| specific properties.
    has Any $.signatureInformation is rw; #| Type: ClientSignatureInformationOptions
    #| The client supports to send additional context information for a
    #| `textDocument/signatureHelp` request. A client that opts into
    #| contextSupport will also support the `retriggerCharacters` on
    #| `SignatureHelpOptions`.
    #| 
    #| @since 3.15.0
    has Bool $.contextSupport is rw;
}

#| Additional information about the context in which a signature help request was triggered.
#| 
#| @since 3.15.0
class SignatureHelpContext is export does LSPObject {
    #| Action that caused signature help to be triggered.
    #| Type: SignatureHelpTriggerKind (enum)
    has Any $.triggerKind is rw;
    #| Character that caused signature help to be triggered.
    #| 
    #| This is undefined when `triggerKind !== SignatureHelpTriggerKind.TriggerCharacter`
    has Str $.triggerCharacter is rw;
    #| `true` if signature help was already showing when it was triggered.
    #| 
    #| Retriggers occurs when the signature help is already active and can be caused by actions such as
    #| typing a trigger character, a cursor move, or document content changes.
    has Bool $.isRetrigger is rw;
    #| The currently active `SignatureHelp`.
    #| 
    #| The `activeSignatureHelp` has its `SignatureHelp.activeSignature` field updated based on
    #| the user navigating through available signatures.
    has Any $.activeSignatureHelp is rw; #| Type: SignatureHelp
}

#| Server Capabilities for a {@link SignatureHelpRequest}.
class SignatureHelpOptions is export does LSPObject {
    #| List of characters that trigger signature help automatically.
    has Str @.triggerCharacters is rw;
    #| List of characters that re-trigger signature help.
    #| 
    #| These trigger characters are only active when signature help is already showing. All trigger characters
    #| are also counted as re-trigger characters.
    #| 
    #| @since 3.15.0
    has Str @.retriggerCharacters is rw;
    has Bool $.workDoneProgress is rw;
}

#| Parameters for a {@link SignatureHelpRequest}.
class SignatureHelpParams is export does LSPObject {
    #| The signature help context. This is only available if the client specifies
    #| to send this using the client capability `textDocument.signatureHelp.contextSupport === true`
    #| 
    #| @since 3.15.0
    has Any $.context is rw; #| Type: SignatureHelpContext
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Registration options for a {@link SignatureHelpRequest}.
class SignatureHelpRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| List of characters that trigger signature help automatically.
    has Str @.triggerCharacters is rw;
    #| List of characters that re-trigger signature help.
    #| 
    #| These trigger characters are only active when signature help is already showing. All trigger characters
    #| are also counted as re-trigger characters.
    #| 
    #| @since 3.15.0
    has Str @.retriggerCharacters is rw;
    has Bool $.workDoneProgress is rw;
}

#| Represents the signature of something callable. A signature
#| can have a label, like a function-name, a doc-comment, and
#| a set of parameters.
class SignatureInformation is export does LSPObject {
    #| The label of this signature. Will be shown in
    #| the UI.
    has Str $.label is rw;
    #| The human-readable doc-comment of this signature. Will be shown
    #| in the UI but can be omitted.
    #| Type: Str | MarkupContent
    has Any $.documentation is rw;
    #| The parameters of this signature.
    #| Array of ParameterInformation
    has Any @.parameters is rw;
    #| The index of the active parameter.
    #| 
    #| If `null`, no parameter of the signature is active (for example a named
    #| argument that does not match any declared parameters). This is only valid
    #| if the client specifies the client capability
    #| `textDocument.signatureHelp.noActiveParameterSupport === true`
    #| 
    #| If provided (or `null`), this is used in place of
    #| `SignatureHelp.activeParameter`.
    #| 
    #| @since 3.16.0
    #| Type: Int | Any
    has Any $.activeParameter is rw;
}

#| An interactive text edit.
#| 
#| @since 3.18.0
class SnippetTextEdit is export does LSPObject {
    #| The range of the text document to be manipulated.
    has Any $.range is rw; #| Type: Range
    #| The snippet to be inserted.
    has Any $.snippet is rw; #| Type: StringValue
    #| The actual identifier of the snippet edit.
    #| Type: ChangeAnnotationIdentifier (typeAlias)
    has Any $.annotationId is rw;
}

#| @since 3.18.0
class StaleRequestSupportOptions is export does LSPObject {
    #| The client will actively cancel the request.
    has Bool $.cancel is rw;
    #| The list of requests for which the client
    #| will retry the request if it receives a
    #| response with error code `ContentModified`
    has Str @.retryOnContentModified is rw;
}

#| Static registration options to be returned in the initialize
#| request.
class StaticRegistrationOptions is export does LSPObject {
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| A string value used as a snippet is a template which allows to insert text
#| and to control the editor cursor when insertion happens.
#| 
#| A snippet can define tab stops and placeholders with `$1`, `$2`
#| and `${3:foo}`. `$0` defines the final tab stop, it defaults to
#| the end of the snippet. Variables are defined with `$name` and
#| `${name:default value}`.
#| 
#| @since 3.18.0
class StringValue is export does LSPObject {
    #| The kind of string value.
    has Str $.kind is rw;
    #| The snippet string.
    has Str $.value is rw;
}

#| Represents information about programming constructs like variables, classes,
#| interfaces etc.
class SymbolInformation is export does LSPObject {
    #| Indicates if this symbol is deprecated.
    #| 
    #| @deprecated Use tags instead
    has Bool $.deprecated is rw;
    #| The location of this symbol. The location's range is used by a tool
    #| to reveal the location in the editor. If the symbol is selected in the
    #| tool the range's start information is used to position the cursor. So
    #| the range usually spans more than the actual symbol's name and does
    #| normally include things like visibility modifiers.
    #| 
    #| The range doesn't have to denote a node range in the sense of an abstract
    #| syntax tree. It can therefore not be used to re-construct a hierarchy of
    #| the symbols.
    has Any $.location is rw; #| Type: Location
    #| The name of this symbol.
    has Str $.name is rw;
    #| The kind of this symbol.
    #| Type: SymbolKind (enum)
    has Any $.kind is rw;
    #| Tags for this symbol.
    #| 
    #| @since 3.16.0
    #| Array of SymbolTag
    has Any @.tags is rw;
    #| The name of the symbol containing this symbol. This information is for
    #| user interface purposes (e.g. to render a qualifier in the user interface
    #| if necessary). It can't be used to re-infer a hierarchy for the document
    #| symbols.
    has Str $.containerName is rw;
}

#| Describe options to be used when registered for text document change events.
class TextDocumentChangeRegistrationOptions is export does LSPObject {
    #| How documents are synced to the server.
    #| Type: TextDocumentSyncKind (enum)
    has Any $.syncKind is rw;
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
}

#| Text document specific client capabilities.
class TextDocumentClientCapabilities is export does LSPObject {
    #| Defines which synchronization capabilities the client supports.
    has Any $.synchronization is rw; #| Type: TextDocumentSyncClientCapabilities
    #| Defines which filters the client supports.
    #| 
    #| @since 3.18.0
    has Any $.filters is rw; #| Type: TextDocumentFilterClientCapabilities
    #| Capabilities specific to the `textDocument/completion` request.
    has Any $.completion is rw; #| Type: CompletionClientCapabilities
    #| Capabilities specific to the `textDocument/hover` request.
    has Any $.hover is rw; #| Type: HoverClientCapabilities
    #| Capabilities specific to the `textDocument/signatureHelp` request.
    has Any $.signatureHelp is rw; #| Type: SignatureHelpClientCapabilities
    #| Capabilities specific to the `textDocument/declaration` request.
    #| 
    #| @since 3.14.0
    has Any $.declaration is rw; #| Type: DeclarationClientCapabilities
    #| Capabilities specific to the `textDocument/definition` request.
    has Any $.definition is rw; #| Type: DefinitionClientCapabilities
    #| Capabilities specific to the `textDocument/typeDefinition` request.
    #| 
    #| @since 3.6.0
    has Any $.typeDefinition is rw; #| Type: TypeDefinitionClientCapabilities
    #| Capabilities specific to the `textDocument/implementation` request.
    #| 
    #| @since 3.6.0
    has Any $.implementation is rw; #| Type: ImplementationClientCapabilities
    #| Capabilities specific to the `textDocument/references` request.
    has Any $.references is rw; #| Type: ReferenceClientCapabilities
    #| Capabilities specific to the `textDocument/documentHighlight` request.
    has Any $.documentHighlight is rw; #| Type: DocumentHighlightClientCapabilities
    #| Capabilities specific to the `textDocument/documentSymbol` request.
    has Any $.documentSymbol is rw; #| Type: DocumentSymbolClientCapabilities
    #| Capabilities specific to the `textDocument/codeAction` request.
    has Any $.codeAction is rw; #| Type: CodeActionClientCapabilities
    #| Capabilities specific to the `textDocument/codeLens` request.
    has Any $.codeLens is rw; #| Type: CodeLensClientCapabilities
    #| Capabilities specific to the `textDocument/documentLink` request.
    has Any $.documentLink is rw; #| Type: DocumentLinkClientCapabilities
    #| Capabilities specific to the `textDocument/documentColor` and the
    #| `textDocument/colorPresentation` request.
    #| 
    #| @since 3.6.0
    has Any $.colorProvider is rw; #| Type: DocumentColorClientCapabilities
    #| Capabilities specific to the `textDocument/formatting` request.
    has Any $.formatting is rw; #| Type: DocumentFormattingClientCapabilities
    #| Capabilities specific to the `textDocument/rangeFormatting` request.
    has Any $.rangeFormatting is rw; #| Type: DocumentRangeFormattingClientCapabilities
    #| Capabilities specific to the `textDocument/onTypeFormatting` request.
    has Any $.onTypeFormatting is rw; #| Type: DocumentOnTypeFormattingClientCapabilities
    #| Capabilities specific to the `textDocument/rename` request.
    has Any $.rename is rw; #| Type: RenameClientCapabilities
    #| Capabilities specific to the `textDocument/foldingRange` request.
    #| 
    #| @since 3.10.0
    has Any $.foldingRange is rw; #| Type: FoldingRangeClientCapabilities
    #| Capabilities specific to the `textDocument/selectionRange` request.
    #| 
    #| @since 3.15.0
    has Any $.selectionRange is rw; #| Type: SelectionRangeClientCapabilities
    #| Capabilities specific to the `textDocument/publishDiagnostics` notification.
    has Any $.publishDiagnostics is rw; #| Type: PublishDiagnosticsClientCapabilities
    #| Capabilities specific to the various call hierarchy requests.
    #| 
    #| @since 3.16.0
    has Any $.callHierarchy is rw; #| Type: CallHierarchyClientCapabilities
    #| Capabilities specific to the various semantic token request.
    #| 
    #| @since 3.16.0
    has Any $.semanticTokens is rw; #| Type: SemanticTokensClientCapabilities
    #| Capabilities specific to the `textDocument/linkedEditingRange` request.
    #| 
    #| @since 3.16.0
    has Any $.linkedEditingRange is rw; #| Type: LinkedEditingRangeClientCapabilities
    #| Client capabilities specific to the `textDocument/moniker` request.
    #| 
    #| @since 3.16.0
    has Any $.moniker is rw; #| Type: MonikerClientCapabilities
    #| Capabilities specific to the various type hierarchy requests.
    #| 
    #| @since 3.17.0
    has Any $.typeHierarchy is rw; #| Type: TypeHierarchyClientCapabilities
    #| Capabilities specific to the `textDocument/inlineValue` request.
    #| 
    #| @since 3.17.0
    has Any $.inlineValue is rw; #| Type: InlineValueClientCapabilities
    #| Capabilities specific to the `textDocument/inlayHint` request.
    #| 
    #| @since 3.17.0
    has Any $.inlayHint is rw; #| Type: InlayHintClientCapabilities
    #| Capabilities specific to the diagnostic pull model.
    #| 
    #| @since 3.17.0
    has Any $.diagnostic is rw; #| Type: DiagnosticClientCapabilities
    #| Client capabilities specific to inline completions.
    #| 
    #| @since 3.18.0
    has Any $.inlineCompletion is rw; #| Type: InlineCompletionClientCapabilities
}

#| @since 3.18.0
class TextDocumentContentChangePartial is export does LSPObject {
    #| The range of the document that changed.
    has Any $.range is rw; #| Type: Range
    #| The optional length of the range that got replaced.
    #| 
    #| @deprecated use range instead.
    has Int $.rangeLength is rw;
    #| The new text for the provided range.
    has Str $.text is rw;
}

#| @since 3.18.0
class TextDocumentContentChangeWholeDocument is export does LSPObject {
    #| The new text of the whole document.
    has Str $.text is rw;
}

#| Client capabilities for a text document content provider.
#| 
#| @since 3.18.0
class TextDocumentContentClientCapabilities is export does LSPObject {
    #| Text document content provider supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
}

#| Text document content provider options.
#| 
#| @since 3.18.0
class TextDocumentContentOptions is export does LSPObject {
    #| The schemes for which the server provides content.
    has Str @.schemes is rw;
}

#| Parameters for the `workspace/textDocumentContent` request.
#| 
#| @since 3.18.0
class TextDocumentContentParams is export does LSPObject {
    #| The uri of the text document.
    has Str $.uri is rw;
}

#| Parameters for the `workspace/textDocumentContent/refresh` request.
#| 
#| @since 3.18.0
class TextDocumentContentRefreshParams is export does LSPObject {
    #| The uri of the text document to refresh.
    has Str $.uri is rw;
}

#| Text document content provider registration options.
#| 
#| @since 3.18.0
class TextDocumentContentRegistrationOptions is export does LSPObject {
    #| The schemes for which the server provides content.
    has Str @.schemes is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| Result of the `workspace/textDocumentContent` request.
#| 
#| @since 3.18.0
class TextDocumentContentResult is export does LSPObject {
    #| The text content of the text document. Please note, that the content of
    #| any subsequent open notifications for the text document might differ
    #| from the returned content due to whitespace and line ending
    #| normalizations done on the client
    has Str $.text is rw;
}

#| Describes textual changes on a text document. A TextDocumentEdit describes all changes
#| on a document version Si and after they are applied move the document to version Si+1.
#| So the creator of a TextDocumentEdit doesn't need to sort the array of edits or do any
#| kind of ordering. However the edits must be non overlapping.
class TextDocumentEdit is export does LSPObject {
    #| The text document to change.
    has Any $.textDocument is rw; #| Type: OptionalVersionedTextDocumentIdentifier
    #| The edits to be applied.
    #| 
    #| @since 3.16.0 - support for AnnotatedTextEdit. This is guarded using a
    #| client capability.
    #| 
    #| @since 3.18.0 - support for SnippetTextEdit. This is guarded using a
    #| client capability.
    #| Array of TextEdit | AnnotatedTextEdit | SnippetTextEdit
    has Any @.edits is rw;
}

class TextDocumentFilterClientCapabilities is export does LSPObject {
    #| The client supports Relative Patterns.
    #| 
    #| @since 3.18.0
    has Bool $.relativePatternSupport is rw;
}

#| A document filter where `language` is required field.
#| 
#| @since 3.18.0
class TextDocumentFilterLanguage is export does LSPObject {
    #| A language id, like `typescript`.
    has Str $.language is rw;
    #| A Uri {@link Uri.scheme scheme}, like `file` or `untitled`.
    has Str $.scheme is rw;
    #| A glob pattern, like **​/*.{ts,js}. See TextDocumentFilter for examples.
    #| 
    #| @since 3.18.0 - support for relative patterns. Whether clients support
    #| relative patterns depends on the client capability
    #| `textDocuments.filters.relativePatternSupport`.
    #| Type: GlobPattern (typeAlias)
    has Any $.pattern is rw;
}

#| A document filter where `pattern` is required field.
#| 
#| @since 3.18.0
class TextDocumentFilterPattern is export does LSPObject {
    #| A language id, like `typescript`.
    has Str $.language is rw;
    #| A Uri {@link Uri.scheme scheme}, like `file` or `untitled`.
    has Str $.scheme is rw;
    #| A glob pattern, like **​/*.{ts,js}. See TextDocumentFilter for examples.
    #| 
    #| @since 3.18.0 - support for relative patterns. Whether clients support
    #| relative patterns depends on the client capability
    #| `textDocuments.filters.relativePatternSupport`.
    #| Type: GlobPattern (typeAlias)
    has Any $.pattern is rw;
}

#| A document filter where `scheme` is required field.
#| 
#| @since 3.18.0
class TextDocumentFilterScheme is export does LSPObject {
    #| A language id, like `typescript`.
    has Str $.language is rw;
    #| A Uri {@link Uri.scheme scheme}, like `file` or `untitled`.
    has Str $.scheme is rw;
    #| A glob pattern, like **​/*.{ts,js}. See TextDocumentFilter for examples.
    #| 
    #| @since 3.18.0 - support for relative patterns. Whether clients support
    #| relative patterns depends on the client capability
    #| `textDocuments.filters.relativePatternSupport`.
    #| Type: GlobPattern (typeAlias)
    has Any $.pattern is rw;
}

#| A literal to identify a text document in the client.
class TextDocumentIdentifier is export does LSPObject {
    #| The text document's uri.
    has Str $.uri is rw;
}

#| An item to transfer a text document from the client to the
#| server.
class TextDocumentItem is export does LSPObject {
    #| The text document's uri.
    has Str $.uri is rw;
    #| The text document's language identifier.
    #| Type: LanguageKind (enum)
    has Any $.languageId is rw;
    #| The version number of this document (it will increase after each
    #| change, including undo/redo).
    has Int $.version is rw;
    #| The content of the opened text document.
    has Str $.text is rw;
}

#| A parameter literal used in requests to pass a text document and a position inside that
#| document.
class TextDocumentPositionParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
}

#| General text document registration options.
class TextDocumentRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
}

#| Save registration options.
class TextDocumentSaveRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    #| The client is supposed to include the content on save.
    has Bool $.includeText is rw;
}

class TextDocumentSyncClientCapabilities is export does LSPObject {
    #| Whether text document synchronization supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| The client supports sending will save notifications.
    has Bool $.willSave is rw;
    #| The client supports sending a will save request and
    #| waits for a response providing text edits which will
    #| be applied to the document before it is saved.
    has Bool $.willSaveWaitUntil is rw;
    #| The client supports did save notifications.
    has Bool $.didSave is rw;
}

class TextDocumentSyncOptions is export does LSPObject {
    #| Open and close notifications are sent to the server. If omitted open close notification should not
    #| be sent.
    has Bool $.openClose is rw;
    #| Change notifications are sent to the server. See TextDocumentSyncKind.None, TextDocumentSyncKind.Full
    #| and TextDocumentSyncKind.Incremental. If omitted it defaults to TextDocumentSyncKind.None.
    #| Type: TextDocumentSyncKind (enum)
    has Any $.change is rw;
    #| If present will save notifications are sent to the server. If omitted the notification should not be
    #| sent.
    has Bool $.willSave is rw;
    #| If present will save wait until requests are sent to the server. If omitted the request should not be
    #| sent.
    has Bool $.willSaveWaitUntil is rw;
    #| If present save notifications are sent to the server. If omitted the notification should not be
    #| sent.
    #| Type: Bool | SaveOptions
    has Any $.save is rw;
}

#| A text edit applicable to a text document.
class TextEdit is export does LSPObject {
    #| The range of the text document to be manipulated. To insert
    #| text into a document create a range where start === end.
    has Any $.range is rw; #| Type: Range
    #| The string to be inserted. For delete operations use an
    #| empty string.
    has Str $.newText is rw;
}

#| Since 3.6.0
class TypeDefinitionClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `TypeDefinitionRegistrationOptions` return value
    #| for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
    #| The client supports additional metadata in the form of definition links.
    #| 
    #| Since 3.14.0
    has Bool $.linkSupport is rw;
}

class TypeDefinitionOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

class TypeDefinitionParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

class TypeDefinitionRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| @since 3.17.0
class TypeHierarchyClientCapabilities is export does LSPObject {
    #| Whether implementation supports dynamic registration. If this is set to `true`
    #| the client supports the new `(TextDocumentRegistrationOptions & StaticRegistrationOptions)`
    #| return value for the corresponding server capability as well.
    has Bool $.dynamicRegistration is rw;
}

#| @since 3.17.0
class TypeHierarchyItem is export does LSPObject {
    #| The name of this item.
    has Str $.name is rw;
    #| The kind of this item.
    #| Type: SymbolKind (enum)
    has Any $.kind is rw;
    #| Tags for this item.
    #| Array of SymbolTag
    has Any @.tags is rw;
    #| More detail for this item, e.g. the signature of a function.
    has Str $.detail is rw;
    #| The resource identifier of this item.
    has Str $.uri is rw;
    #| The range enclosing this symbol not including leading/trailing whitespace
    #| but everything else, e.g. comments and code.
    has Any $.range is rw; #| Type: Range
    #| The range that should be selected and revealed when this symbol is being
    #| picked, e.g. the name of a function. Must be contained by the
    #| {@link TypeHierarchyItem.range `range`}.
    has Any $.selectionRange is rw; #| Type: Range
    #| A data entry field that is preserved between a type hierarchy prepare and
    #| supertypes or subtypes requests. It could also be used to identify the
    #| type hierarchy in the server, helping improve the performance on
    #| resolving supertypes and subtypes.
    has Any $.data is rw; #| Type: Any
}

#| Type hierarchy options used during static registration.
#| 
#| @since 3.17.0
class TypeHierarchyOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

#| The parameter of a `textDocument/prepareTypeHierarchy` request.
#| 
#| @since 3.17.0
class TypeHierarchyPrepareParams is export does LSPObject {
    #| The text document.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The position inside the text document.
    has Any $.position is rw; #| Type: Position
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

#| Type hierarchy options used during static or dynamic registration.
#| 
#| @since 3.17.0
class TypeHierarchyRegistrationOptions is export does LSPObject {
    #| A document selector to identify the scope of the registration. If set to null
    #| the document selector provided on the client side will be used.
    #| Type: DocumentSelector | Any
    has Any $.documentSelector is rw;
    has Bool $.workDoneProgress is rw;
    #| The id used to register the request. The id can be used to deregister
    #| the request again. See also Registration#id.
    has Str $.id is rw;
}

#| The parameter of a `typeHierarchy/subtypes` request.
#| 
#| @since 3.17.0
class TypeHierarchySubtypesParams is export does LSPObject {
    has Any $.item is rw; #| Type: TypeHierarchyItem
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| The parameter of a `typeHierarchy/supertypes` request.
#| 
#| @since 3.17.0
class TypeHierarchySupertypesParams is export does LSPObject {
    has Any $.item is rw; #| Type: TypeHierarchyItem
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| A diagnostic report indicating that the last returned
#| report is still accurate.
#| 
#| @since 3.17.0
class UnchangedDocumentDiagnosticReport is export does LSPObject {
    #| A document diagnostic report indicating
    #| no changes to the last result. A server can
    #| only return `unchanged` if result ids are
    #| provided.
    has Str $.kind is rw;
    #| A result id which will be sent on the next
    #| diagnostic request for the same document.
    has Str $.resultId is rw;
}

#| General parameters to unregister a request or notification.
class Unregistration is export does LSPObject {
    #| The id used to unregister the request or notification. Usually an id
    #| provided during the register request.
    has Str $.id is rw;
    #| The method to unregister for.
    has Str $.method is rw;
}

class UnregistrationParams is export does LSPObject {
    #| Array of Unregistration
    has Any @.unregisterations is rw;
}

#| A versioned notebook document identifier.
#| 
#| @since 3.17.0
class VersionedNotebookDocumentIdentifier is export does LSPObject {
    #| The version number of this notebook document.
    has Int $.version is rw;
    #| The notebook document's uri.
    has Str $.uri is rw;
}

#| A text document identifier to denote a specific version of a text document.
class VersionedTextDocumentIdentifier is export does LSPObject {
    #| The version number of this document.
    has Int $.version is rw;
    #| The text document's uri.
    has Str $.uri is rw;
}

#| The parameters sent in a will save text document notification.
class WillSaveTextDocumentParams is export does LSPObject {
    #| The document that will be saved.
    has Any $.textDocument is rw; #| Type: TextDocumentIdentifier
    #| The 'TextDocumentSaveReason'.
    #| Type: TextDocumentSaveReason (enum)
    has Any $.reason is rw;
}

class WindowClientCapabilities is export does LSPObject {
    #| It indicates whether the client supports server initiated
    #| progress using the `window/workDoneProgress/create` request.
    #| 
    #| The capability also controls Whether client supports handling
    #| of progress notifications. If set servers are allowed to report a
    #| `workDoneProgress` property in the request specific server
    #| capabilities.
    #| 
    #| @since 3.15.0
    has Bool $.workDoneProgress is rw;
    #| Capabilities specific to the showMessage request.
    #| 
    #| @since 3.16.0
    has Any $.showMessage is rw; #| Type: ShowMessageRequestClientCapabilities
    #| Capabilities specific to the showDocument request.
    #| 
    #| @since 3.16.0
    has Any $.showDocument is rw; #| Type: ShowDocumentClientCapabilities
}

class WorkDoneProgressBegin is export does LSPObject {
    has Str $.kind is rw;
    #| Mandatory title of the progress operation. Used to briefly inform about
    #| the kind of operation being performed.
    #| 
    #| Examples: "Indexing" or "Linking dependencies".
    has Str $.title is rw;
    #| Controls if a cancel button should show to allow the user to cancel the
    #| long running operation. Clients that don't support cancellation are allowed
    #| to ignore the setting.
    has Bool $.cancellable is rw;
    #| Optional, more detailed associated progress message. Contains
    #| complementary information to the `title`.
    #| 
    #| Examples: "3/25 files", "project/src/module2", "node_modules/some_dep".
    #| If unset, the previous progress message (if any) is still valid.
    has Str $.message is rw;
    #| Optional progress percentage to display (value 100 is considered 100%).
    #| If not provided infinite progress is assumed and clients are allowed
    #| to ignore the `percentage` value in subsequent in report notifications.
    #| 
    #| The value should be steadily rising. Clients are free to ignore values
    #| that are not following this rule. The value range is [0, 100].
    has Int $.percentage is rw;
}

class WorkDoneProgressCancelParams is export does LSPObject {
    #| The token to be used to report progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.token is rw;
}

class WorkDoneProgressCreateParams is export does LSPObject {
    #| The token to be used to report progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.token is rw;
}

class WorkDoneProgressEnd is export does LSPObject {
    has Str $.kind is rw;
    #| Optional, a final message indicating to for example indicate the outcome
    #| of the operation.
    has Str $.message is rw;
}

class WorkDoneProgressOptions is export does LSPObject {
    has Bool $.workDoneProgress is rw;
}

class WorkDoneProgressParams is export does LSPObject {
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

class WorkDoneProgressReport is export does LSPObject {
    has Str $.kind is rw;
    #| Controls enablement state of a cancel button.
    #| 
    #| Clients that don't support cancellation or don't support controlling the button's
    #| enablement state are allowed to ignore the property.
    has Bool $.cancellable is rw;
    #| Optional, more detailed associated progress message. Contains
    #| complementary information to the `title`.
    #| 
    #| Examples: "3/25 files", "project/src/module2", "node_modules/some_dep".
    #| If unset, the previous progress message (if any) is still valid.
    has Str $.message is rw;
    #| Optional progress percentage to display (value 100 is considered 100%).
    #| If not provided infinite progress is assumed and clients are allowed
    #| to ignore the `percentage` value in subsequent in report notifications.
    #| 
    #| The value should be steadily rising. Clients are free to ignore values
    #| that are not following this rule. The value range is [0, 100]
    has Int $.percentage is rw;
}

#| Workspace specific client capabilities.
class WorkspaceClientCapabilities is export does LSPObject {
    #| The client supports applying batch edits
    #| to the workspace by supporting the request
    #| 'workspace/applyEdit'
    has Bool $.applyEdit is rw;
    #| Capabilities specific to `WorkspaceEdit`s.
    has Any $.workspaceEdit is rw; #| Type: WorkspaceEditClientCapabilities
    #| Capabilities specific to the `workspace/didChangeConfiguration` notification.
    has Any $.didChangeConfiguration is rw; #| Type: DidChangeConfigurationClientCapabilities
    #| Capabilities specific to the `workspace/didChangeWatchedFiles` notification.
    has Any $.didChangeWatchedFiles is rw; #| Type: DidChangeWatchedFilesClientCapabilities
    #| Capabilities specific to the `workspace/symbol` request.
    has Any $.symbol is rw; #| Type: WorkspaceSymbolClientCapabilities
    #| Capabilities specific to the `workspace/executeCommand` request.
    has Any $.executeCommand is rw; #| Type: ExecuteCommandClientCapabilities
    #| The client has support for workspace folders.
    #| 
    #| @since 3.6.0
    has Bool $.workspaceFolders is rw;
    #| The client supports `workspace/configuration` requests.
    #| 
    #| @since 3.6.0
    has Bool $.configuration is rw;
    #| Capabilities specific to the semantic token requests scoped to the
    #| workspace.
    #| 
    #| @since 3.16.0.
    has Any $.semanticTokens is rw; #| Type: SemanticTokensWorkspaceClientCapabilities
    #| Capabilities specific to the code lens requests scoped to the
    #| workspace.
    #| 
    #| @since 3.16.0.
    has Any $.codeLens is rw; #| Type: CodeLensWorkspaceClientCapabilities
    #| The client has support for file notifications/requests for user operations on files.
    #| 
    #| Since 3.16.0
    has Any $.fileOperations is rw; #| Type: FileOperationClientCapabilities
    #| Capabilities specific to the inline values requests scoped to the
    #| workspace.
    #| 
    #| @since 3.17.0.
    has Any $.inlineValue is rw; #| Type: InlineValueWorkspaceClientCapabilities
    #| Capabilities specific to the inlay hint requests scoped to the
    #| workspace.
    #| 
    #| @since 3.17.0.
    has Any $.inlayHint is rw; #| Type: InlayHintWorkspaceClientCapabilities
    #| Capabilities specific to the diagnostic requests scoped to the
    #| workspace.
    #| 
    #| @since 3.17.0.
    has Any $.diagnostics is rw; #| Type: DiagnosticWorkspaceClientCapabilities
    #| Capabilities specific to the folding range requests scoped to the workspace.
    #| 
    #| @since 3.18.0
    has Any $.foldingRange is rw; #| Type: FoldingRangeWorkspaceClientCapabilities
    #| Capabilities specific to the `workspace/textDocumentContent` request.
    #| 
    #| @since 3.18.0
    has Any $.textDocumentContent is rw; #| Type: TextDocumentContentClientCapabilities
}

#| Parameters of the workspace diagnostic request.
#| 
#| @since 3.17.0
class WorkspaceDiagnosticParams is export does LSPObject {
    #| The additional identifier provided during registration.
    has Str $.identifier is rw;
    #| The currently known diagnostic reports with their
    #| previous result ids.
    #| Array of PreviousResultId
    has Any @.previousResultIds is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| A workspace diagnostic report.
#| 
#| @since 3.17.0
class WorkspaceDiagnosticReport is export does LSPObject {
    #| Array of WorkspaceDocumentDiagnosticReport
    has Any @.items is rw;
}

#| A partial result for a workspace diagnostic report.
#| 
#| @since 3.17.0
class WorkspaceDiagnosticReportPartialResult is export does LSPObject {
    #| Array of WorkspaceDocumentDiagnosticReport
    has Any @.items is rw;
}

#| A workspace edit represents changes to many resources managed in the workspace. The edit
#| should either provide `changes` or `documentChanges`. If documentChanges are present
#| they are preferred over `changes` if the client can handle versioned document edits.
#| 
#| Since version 3.13.0 a workspace edit can contain resource operations as well. If resource
#| operations are present clients need to execute the operations in the order in which they
#| are provided. So a workspace edit for example can consist of the following two changes:
#| (1) a create file a.txt and (2) a text document edit which insert text into file a.txt.
#| 
#| An invalid sequence (e.g. (1) delete file a.txt and (2) insert text into file a.txt) will
#| cause failure of the operation. How the client recovers from the failure is described by
#| the client capability: `workspace.workspaceEdit.failureHandling`
class WorkspaceEdit is export does LSPObject {
    #| Holds changes to existing resources.
    has Any %.changes is rw;
    #| Depending on the client capability `workspace.workspaceEdit.resourceOperations` document changes
    #| are either an array of `TextDocumentEdit`s to express changes to n different text documents
    #| where each text document edit addresses a specific version of a text document. Or it can contain
    #| above `TextDocumentEdit`s mixed with create, rename and delete file / folder operations.
    #| 
    #| Whether a client supports versioned document edits is expressed via
    #| `workspace.workspaceEdit.documentChanges` client capability.
    #| 
    #| If a client neither supports `documentChanges` nor `workspace.workspaceEdit.resourceOperations` then
    #| only plain `TextEdit`s using the `changes` property are supported.
    #| Array of TextDocumentEdit | CreateFile | RenameFile | DeleteFile
    has Any @.documentChanges is rw;
    #| A map of change annotations that can be referenced in `AnnotatedTextEdit`s or create, rename and
    #| delete file / folder operations.
    #| 
    #| Whether clients honor this property depends on the client capability `workspace.changeAnnotationSupport`.
    #| 
    #| @since 3.16.0
    has Any %.changeAnnotations is rw;
}

class WorkspaceEditClientCapabilities is export does LSPObject {
    #| The client supports versioned document changes in `WorkspaceEdit`s
    has Bool $.documentChanges is rw;
    #| The resource operations the client supports. Clients should at least
    #| support 'create', 'rename' and 'delete' files and folders.
    #| 
    #| @since 3.13.0
    #| Array of ResourceOperationKind
    has Any @.resourceOperations is rw;
    #| The failure handling strategy of a client if applying the workspace edit
    #| fails.
    #| 
    #| @since 3.13.0
    #| Type: FailureHandlingKind (enum)
    has Any $.failureHandling is rw;
    #| Whether the client normalizes line endings to the client specific
    #| setting.
    #| If set to `true` the client will normalize line ending characters
    #| in a workspace edit to the client-specified new line
    #| character.
    #| 
    #| @since 3.16.0
    has Bool $.normalizesLineEndings is rw;
    #| Whether the client in general supports change annotations on text edits,
    #| create file, rename file and delete file changes.
    #| 
    #| @since 3.16.0
    has Any $.changeAnnotationSupport is rw; #| Type: ChangeAnnotationsSupportOptions
    #| Whether the client supports `WorkspaceEditMetadata` in `WorkspaceEdit`s.
    #| 
    #| @since 3.18.0
    has Bool $.metadataSupport is rw;
    #| Whether the client supports snippets as text edits.
    #| 
    #| @since 3.18.0
    has Bool $.snippetEditSupport is rw;
}

#| Additional data about a workspace edit.
#| 
#| @since 3.18.0
class WorkspaceEditMetadata is export does LSPObject {
    #| Signal to the editor that this edit is a refactoring.
    has Bool $.isRefactoring is rw;
}

#| A workspace folder inside a client.
class WorkspaceFolder is export does LSPObject {
    #| The associated URI for this workspace folder.
    has Str $.uri is rw;
    #| The name of the workspace folder. Used to refer to this
    #| workspace folder in the user interface.
    has Str $.name is rw;
}

#| The workspace folder change event.
class WorkspaceFoldersChangeEvent is export does LSPObject {
    #| The array of added workspace folders
    #| Array of WorkspaceFolder
    has Any @.added is rw;
    #| The array of the removed workspace folders
    #| Array of WorkspaceFolder
    has Any @.removed is rw;
}

class WorkspaceFoldersInitializeParams is export does LSPObject {
    #| The workspace folders configured in the client when the server starts.
    #| 
    #| This property is only available if the client supports workspace folders.
    #| It can be `null` if the client supports workspace folders but none are
    #| configured.
    #| 
    #| @since 3.6.0
    #| Type: WorkspaceFolder | Any
    has Any $.workspaceFolders is rw;
}

class WorkspaceFoldersServerCapabilities is export does LSPObject {
    #| The server has support for workspace folders
    has Bool $.supported is rw;
    #| Whether the server wants to receive workspace folder
    #| change notifications.
    #| 
    #| If a string is provided the string is treated as an ID
    #| under which the notification is registered on the client
    #| side. The ID can be used to unregister for these events
    #| using the `client/unregisterCapability` request.
    #| Type: Str | Bool
    has Any $.changeNotifications is rw;
}

#| A full document diagnostic report for a workspace diagnostic result.
#| 
#| @since 3.17.0
class WorkspaceFullDocumentDiagnosticReport is export does LSPObject {
    #| The URI for which diagnostic information is reported.
    has Str $.uri is rw;
    #| The version number for which the diagnostics are reported.
    #| If the document is not marked as open `null` can be provided.
    #| Type: Int | Any
    has Any $.version is rw;
    #| A full document diagnostic report.
    has Str $.kind is rw;
    #| An optional result id. If provided it will
    #| be sent on the next diagnostic request for the
    #| same document.
    has Str $.resultId is rw;
    #| The actual items.
    #| Array of Diagnostic
    has Any @.items is rw;
}

#| Defines workspace specific capabilities of the server.
#| 
#| @since 3.18.0
class WorkspaceOptions is export does LSPObject {
    #| The server supports workspace folder.
    #| 
    #| @since 3.6.0
    has Any $.workspaceFolders is rw; #| Type: WorkspaceFoldersServerCapabilities
    #| The server is interested in notifications/requests for operations on files.
    #| 
    #| @since 3.16.0
    has Any $.fileOperations is rw; #| Type: FileOperationOptions
    #| The server supports the `workspace/textDocumentContent` request.
    #| 
    #| @since 3.18.0
    #| Type: TextDocumentContentOptions | TextDocumentContentRegistrationOptions
    has Any $.textDocumentContent is rw;
}

#| A special workspace symbol that supports locations without a range.
#| 
#| See also SymbolInformation.
#| 
#| @since 3.17.0
class WorkspaceSymbol is export does LSPObject {
    #| The location of the symbol. Whether a server is allowed to
    #| return a location without a range depends on the client
    #| capability `workspace.symbol.resolveSupport`.
    #| 
    #| See SymbolInformation#location for more details.
    #| Type: Location | LocationUriOnly
    has Any $.location is rw;
    #| A data entry field that is preserved on a workspace symbol between a
    #| workspace symbol request and a workspace symbol resolve request.
    has Any $.data is rw; #| Type: Any
    #| The name of this symbol.
    has Str $.name is rw;
    #| The kind of this symbol.
    #| Type: SymbolKind (enum)
    has Any $.kind is rw;
    #| Tags for this symbol.
    #| 
    #| @since 3.16.0
    #| Array of SymbolTag
    has Any @.tags is rw;
    #| The name of the symbol containing this symbol. This information is for
    #| user interface purposes (e.g. to render a qualifier in the user interface
    #| if necessary). It can't be used to re-infer a hierarchy for the document
    #| symbols.
    has Str $.containerName is rw;
}

#| Client capabilities for a {@link WorkspaceSymbolRequest}.
class WorkspaceSymbolClientCapabilities is export does LSPObject {
    #| Symbol request supports dynamic registration.
    has Bool $.dynamicRegistration is rw;
    #| Specific capabilities for the `SymbolKind` in the `workspace/symbol` request.
    has Any $.symbolKind is rw; #| Type: ClientSymbolKindOptions
    #| The client supports tags on `SymbolInformation`.
    #| Clients supporting tags have to handle unknown tags gracefully.
    #| 
    #| @since 3.16.0
    has Any $.tagSupport is rw; #| Type: ClientSymbolTagOptions
    #| The client support partial workspace symbols. The client will send the
    #| request `workspaceSymbol/resolve` to the server to resolve additional
    #| properties.
    #| 
    #| @since 3.17.0
    has Any $.resolveSupport is rw; #| Type: ClientSymbolResolveOptions
}

#| Server capabilities for a {@link WorkspaceSymbolRequest}.
class WorkspaceSymbolOptions is export does LSPObject {
    #| The server provides support to resolve additional
    #| information for a workspace symbol.
    #| 
    #| @since 3.17.0
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| The parameters of a {@link WorkspaceSymbolRequest}.
class WorkspaceSymbolParams is export does LSPObject {
    #| A query string to filter symbols by. Clients may send an empty
    #| string here to request all symbols.
    #| 
    #| The `query`-parameter should be interpreted in a *relaxed way* as editors
    #| will apply their own highlighting and scoring on the results. A good rule
    #| of thumb is to match case-insensitive and to simply check that the
    #| characters of *query* appear in their order in a candidate symbol.
    #| Servers shouldn't use prefix, substring, or similar strict matching.
    has Str $.query is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
    #| An optional token that a server can use to report partial results (e.g. streaming) to
    #| the client.
    #| Type: ProgressToken (typeAlias)
    has Any $.partialResultToken is rw;
}

#| Registration options for a {@link WorkspaceSymbolRequest}.
class WorkspaceSymbolRegistrationOptions is export does LSPObject {
    #| The server provides support to resolve additional
    #| information for a workspace symbol.
    #| 
    #| @since 3.17.0
    has Bool $.resolveProvider is rw;
    has Bool $.workDoneProgress is rw;
}

#| An unchanged document diagnostic report for a workspace diagnostic result.
#| 
#| @since 3.17.0
class WorkspaceUnchangedDocumentDiagnosticReport is export does LSPObject {
    #| The URI for which diagnostic information is reported.
    has Str $.uri is rw;
    #| The version number for which the diagnostics are reported.
    #| If the document is not marked as open `null` can be provided.
    #| Type: Int | Any
    has Any $.version is rw;
    #| A document diagnostic report indicating
    #| no changes to the last result. A server can
    #| only return `unchanged` if result ids are
    #| provided.
    has Str $.kind is rw;
    #| A result id which will be sent on the next
    #| diagnostic request for the same document.
    has Str $.resultId is rw;
}

#| The initialize parameters
class _InitializeParams is export does LSPObject {
    #| The process Id of the parent process that started
    #| the server.
    #| 
    #| Is `null` if the process has not been started by another process.
    #| If the parent process is not alive then the server should exit.
    #| Type: Int | Any
    has Any $.processId is rw;
    #| Information about the client
    #| 
    #| @since 3.15.0
    has Any $.clientInfo is rw; #| Type: ClientInfo
    #| The locale the client is currently showing the user interface
    #| in. This must not necessarily be the locale of the operating
    #| system.
    #| 
    #| Uses IETF language tags as the value's syntax
    #| (See https://en.wikipedia.org/wiki/IETF_language_tag)
    #| 
    #| @since 3.16.0
    has Str $.locale is rw;
    #| The rootPath of the workspace. Is null
    #| if no folder is open.
    #| 
    #| @deprecated in favour of rootUri.
    #| Type: Str | Any
    has Any $.rootPath is rw;
    #| The rootUri of the workspace. Is null if no
    #| folder is open. If both `rootPath` and `rootUri` are set
    #| `rootUri` wins.
    #| 
    #| @deprecated in favour of workspaceFolders.
    #| Type: Str | Any
    has Any $.rootUri is rw;
    #| The capabilities provided by the client (editor or tool)
    has Any $.capabilities is rw; #| Type: ClientCapabilities
    #| User provided initialization options.
    has Any $.initializationOptions is rw; #| Type: Any
    #| The initial trace setting. If omitted trace is disabled ('off').
    #| Type: TraceValue (enum)
    has Any $.trace is rw;
    #| An optional token that a server can use to report work done progress.
    #| Type: ProgressToken (typeAlias)
    has Any $.workDoneToken is rw;
}

# ======================================================================
# Protocol Messages & Handshake Wrappers
# ======================================================================

class Message is export does LSPObject { has Str $.jsonrpc = "2.0"; }
class RequestMessage is export is Message { has Any $.id is rw; has Str $.method is rw; has Any $.params is rw; }
class ResponseError is export does LSPObject { has Int $.code is rw; has Str $.message is rw; has Any $.data is rw; }
class ResponseMessage is export is Message { has Any $.id is rw; has Any $.result is rw; has ResponseError $.error is rw; }
class NotificationMessage is export is Message { has Str $.method is rw; has Any $.params is rw; }
