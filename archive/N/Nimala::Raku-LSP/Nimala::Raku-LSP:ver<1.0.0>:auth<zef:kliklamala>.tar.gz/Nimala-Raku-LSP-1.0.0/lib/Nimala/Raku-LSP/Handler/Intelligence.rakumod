#| Role handling code-intelligence requests:
#| hover, completion, signatureHelp.
unit role Nimala::Raku-LSP::Handler::Intelligence;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use nqp;
use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Analysis::Completion;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::CoreDocs;
use Nimala::Raku-LSP::URI;

#| Handle textDocument/hover request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_hover>
method textDocument-hover(:%textDocument, :%position, *%other --> Any) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return Nil unless $doc;

    my Str $word = get-word-at($doc, %position<line>, %position<character>);
    return Nil unless $word;

    return Nil if is-in-comment-or-string($doc, %position<line>, %position<character>);

    my $hover-word = $word;
    my Str $obj = get-method-call-context($doc, %position<line>, %position<character>);
    if $obj {
        my $type = find-variable-type($doc, $obj, %position<line>, %position<character>, self.index);
        if $type {
            my $bare-word = $word.subst(/^ \. /, '');
            my $member-sym = self.index.find-member-symbol($type, $bare-word);
            if $member-sym {
                my $sig-text = $member-sym<detail> // "method $bare-word()";
                my $value = "```raku\n$sig-text\n```";

                my $m-uri = $member-sym<uri>;
                my $m-range = $member-sym<range>;
                if $m-uri && $m-range && self.doc-store {
                    if my $m-doc = self.doc-store.get-or-load($m-uri) {
                        my @docs;
                        my $line-idx = $m-range<start><line> - 1;
                        while $line-idx >= 0 {
                            my $l = $m-doc.line-text($line-idx).trim;
                            if $l.starts-with('#|') {
                                @docs.unshift($l.substr(2).trim);
                            } elsif $l eq '' { }
                            else { last; }
                            $line-idx--;
                        }
                        if @docs {
                            $value ~= "\n\n---\n\n" ~ @docs.join("\n");
                        }
                    }
                }
                return {
                    contents => { kind => "markdown", value => $value }
                };
            }

            # Check CoreDocs for $type and MRO / Any / Mu
            my $bare-type = $type.subst(/ \: <[A..Z]> $/, '');
            my @types-to-check = ($bare-type,);
            if %CORE-MRO{$bare-type}:exists {
                for %CORE-MRO{$bare-type}.list -> $sup {
                    @types-to-check.push($sup) unless $sup eq $bare-type;
                }
            }
            if %CORE-ROLES{$bare-type}:exists {
                for %CORE-ROLES{$bare-type}.list -> $role {
                    @types-to-check.push($role);
                }
            }
            @types-to-check.push('Any') unless 'Any' (elem) @types-to-check;
            @types-to-check.push('Mu') unless 'Mu' (elem) @types-to-check;

            for @types-to-check -> $t {
                my $core-doc = Nimala::Raku-LSP::CoreDocs::get-doc($t, $bare-word);
                if $core-doc {
                    return {
                        contents => { kind => "markdown", value => $core-doc }
                    };
                }
            }

            $hover-word = "$bare-type\::$bare-word";
        }
    } else {
        # Check if the word itself is a variable we can find a type for
        if $word ~~ / ^ <[\$\@\%\&]> / {
            my $type = find-variable-type($doc, $word, %position<line>, %position<character>, self.index);
            if $type {
                return {
                    contents => { kind => "markdown", value => "```raku\n$type $word\n```" }
                };
            }
        }
    }

    my $hover = get-hover-info($doc, $hover-word);
    if !$hover && $obj {
        # Fallback to the method name alone if Type::method isn't documented
        $hover = get-hover-info($doc, $word.subst(/^ \. /, ''));
    }

    if !$hover {
        my Any @global = self.index.find-symbol($hover-word);
        if @global {
            my $sym = @global[0];
            if $sym<uri> {
                my $m-doc = self.doc-store ?? self.doc-store.get-or-load($sym<uri>) !! Nil;
                if $m-doc {
                    $hover = get-hover-info($m-doc, $hover-word);
                }
            }
        }
    }

    if !$hover && self.root-path {
        my IO::Path $mod-file = resolve-module-file($word, root => self.root-path.IO);
        if $mod-file.f {
            my $m-doc = self.doc-store ?? self.doc-store.get-or-load(path-to-uri($mod-file)) !! Nil;
            if $m-doc {
                $hover = get-hover-info($m-doc, $word) // { code => "unit module $word;", docs => "" };
            }
        }
    }

    if $hover {
        my $value = "```raku\n" ~ $hover<code> ~ "\n```";
        if $hover<docs> {
            $value ~= "\n\n---\n\n" ~ $hover<docs>;
        }
        return {
            contents => { kind => "markdown", value => $value }
        };
    }
    return Nil;
}

#| Handle textDocument/completion request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_completion>
method textDocument-completion(:%textDocument, :%position, :%context, *%other --> Hash) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return hash(isIncomplete => False, items => []) unless $doc;
    my @items = get-type-aware-completions($doc, %position<line>, %position<character>, self.index).sort({ $_<sortText> // $_<label> }).Array;
    my Bool $is-incomplete = @items.elems > 50;
    if $is-incomplete {
        @items = @items[^50].Array;
    }

    return hash(
        isIncomplete => $is-incomplete,
        items => @items
    );
}

#| Handle completionItem/resolve request.
method completionItem-resolve(:$_id, :$_token, *%item --> Hash) {
    %item<_token>:delete;
    %item<_id>:delete;
    my $label = %item<label> // "";
    if !%item<documentation> {
        my Str $doc-val = "";
        my Str $type = "";
        if %item<data> && %item<data><type> {
            $type = %item<data><type>.Str;
        } elsif %item<detail> && %item<detail> ~~ /^ (\w+) / {
            $type = $0.Str;
        }

        if $type && $label {
            $doc-val = Nimala::Raku-LSP::CoreDocs::get-doc($type, $label) // "";
        }
        if !$doc-val && $label {
            $doc-val = Nimala::Raku-LSP::CoreDocs::get-doc-routine($label) // "";
        }
        if !$doc-val && $type {
            $doc-val = Nimala::Raku-LSP::CoreDocs::get-doc-type($type) // "";
        }

        if $doc-val {
            %item<documentation> = { kind => "markdown", value => $doc-val };
        }
    }
    return %item;
}

#| Handle textDocument/inlineCompletion request (LSP 3.18).
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineCompletion>
method textDocument-inlineCompletion(:%textDocument, :%position, :%context?, *%other --> Hash) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return hash(items => [].Array) unless $doc;

    my @items = get-inline-completions($doc, %position<line>.Int, %position<character>.Int);
    return hash(
        items => @items
    );
}

#| Handle textDocument/signatureHelp request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_signatureHelp>
method textDocument-signatureHelp(:%textDocument, :%position, :%context?, *%other --> Hash) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return { signatures => [] } unless $doc;

    my ($invocant, $func-name, $active-param) = get-signature-context($doc, %position<line>, %position<character>);
    return { signatures => [] } unless $func-name;

    my $target-symbol;

    if $invocant {
        my $type = find-variable-type($doc, $invocant, %position<line>, %position<character>, self.index);
        if $type {
            my @type-syms = self.index.find-symbol($type);
            if @type-syms {
                my $class-sym = @type-syms[0];
                if $class-sym<children> {
                    $target-symbol = $class-sym<children>.first({ $_<name> eq $func-name && ($_<kind> == 6 || $_<kind> == 12 || $_<kind> == 11) });
                }
            }
        }
    } else {
        # Check local symbols first
        my @symbols = extract-symbols($doc.text);

        sub find-sig($symbols) {
            for @$symbols -> $s {
                if ($s<kind> == 6 || $s<kind> == 12) && $s<name> eq $func-name {
                    $target-symbol = $s;
                    return True;
                }
                if $s<children> {
                    return True if find-sig($s<children>);
                }
            }
            return False;
        }

        find-sig(@symbols);

        # If not found locally, try global index
        unless $target-symbol {
            my @globals = self.index.find-symbol($func-name);
            $target-symbol = @globals.first({ $_<kind> == 6 || $_<kind> == 12 });
        }
    }

    unless $target-symbol {
        my %core-signatures = (
            'say'     => ':(|)',
            'print'   => ':(|)',
            'put'     => ':(|)',
            'note'    => ':(|)',
            'map'     => ':(Code $block, *@list)',
            'grep'    => ':(Code $block, *@list)',
            'first'   => ':(Code $block, *@list)',
            'join'    => ':(Str $separator, *@list)',
            'split'   => ':(Regex $separator, Str $target)',
            'substr'  => ':(Str:D $s, $start, $chars?)',
            'push'    => ':(@array, *@values)',
            'pop'     => ':(@array)',
            'shift'   => ':(@array)',
            'unshift' => ':(@array, *@values)',
            'elems'   => ':($list-or-hash)',
            'keys'    => ':($hash)',
            'values'  => ':($hash)',
            'pairs'   => ':($hash)'
        );

        if %core-signatures{$func-name} {
            my $sig-str = %core-signatures{$func-name};
            my @parameters;

            if $sig-str ~~ / ':(' \s* (.*?) \s* ')' / {
                my $args-str = $0.Str;
                if $args-str && $args-str ne '|' {
                    my @args = $args-str.split(',');
                    for @args -> $arg {
                        @parameters.push: { label => $arg.trim };
                    }
                }
            }

            return %(
                signatures => [
                    %(
                        label => $func-name ~ $sig-str,
                        parameters => @parameters
                    ),
                ],
                activeSignature => 0,
                activeParameter => $active-param
            );
        }
    }

    return { signatures => [] } unless $target-symbol;

    my $label = $target-symbol<detail> // ($target-symbol<name> ~ "()");
    $label ~~ s/ \s* \(<[a..z]>+\) $ //; # Strip (public) / (private)

    # Extract parameters from the signature label (e.g. "sub-name($a, Int $b)")
    my @parameters;
    if $label ~~ / '(' (.*) ')' / {
        my $args-str = $0.Str;
        if $args-str.trim {
            my @args = $args-str.split(',');
            for @args -> $arg {
                my Str $p-label = $arg.trim;
                $p-label ~~ s/\!$//; # Remove trailing '!' for required params
                @parameters.push: { label => $p-label };
            }
        }
    }

    return %(
        signatures => [
            %(
                label => $label,
                parameters => @parameters
            ),
        ],
        activeSignature => 0,
        activeParameter => $active-param
    );
}


