use v6.d;
unit class Nimala::Raku-LSP::Dispatcher;

use JSON::Fast;
use Nimala::Raku-LSP::Handler::Types;

#| Logger for LSP server events (opt-in via NIMALA_LOG=1)
class Logger is export {
    has Bool $.enabled = False;
    has IO::Handle $!fh;
    has Lock $!lock = Lock.new;

    submethod TWEAK() {
        if %*ENV<NIMALA_LOG>:exists && %*ENV<NIMALA_LOG> eq '1' {
            $!enabled = True;
            try {
                my IO::Path $home = $*HOME // $*TMPDIR;
                my IO::Path $state-dir = %*ENV<XDG_STATE_HOME>
                ?? %*ENV<XDG_STATE_HOME>.IO
                !! $home.add('.local').add('state');
                my IO::Path $dir = $state-dir.add("nimala");
                mkdir $dir, 0o700 unless $dir.e;
                chmod 0o700, $dir;
                my IO::Path $file = $dir.child("lsp.log");
                $!fh = $file.open(:a);
                chmod 0o600, $file;
                CATCH { default { $!enabled = False; } }
            }
        }
    }

    method log(Str $msg --> Nil) {
        return unless $!enabled && $!fh;
        $!lock.protect: {
            try {
                $!fh.say("{DateTime.now.utc.Str} $msg");
                $!fh.flush;
                CATCH { default { } }
            }
        }
    }

    method close(--> Nil) {
        $!lock.protect: {
            try { $!fh.close if $!fh; }
        }
    }
}

#| Whitelist mapping standard LSP methods to Handler methods.
our constant %METHODS is export = %(
    # Lifecycle
    'initialize'                            => 'initialize',
    'initialized'                           => 'initialized',
    'shutdown'                              => 'shutdown',
    'exit'                                  => 'exit',
    '$/cancelRequest'                       => '$/cancelRequest',
    '$/progress'                            => 'lsp-progress',
    'window/workDoneProgress/cancel'        => 'window-workDoneProgress-cancel',

    # Workspace
    'workspace/didChangeConfiguration'      => 'workspace-didChangeConfiguration',
    'workspace/didChangeWatchedFiles'       => 'workspace-didChangeWatchedFiles',
    'workspace/didChangeWorkspaceFolders'   => 'workspace-didChangeWorkspaceFolders',
    'workspace/symbol'                      => 'workspace-symbol',
    'workspace/symbol/resolve'              => 'workspace-symbol-resolve',
    'workspaceSymbol/resolve'               => 'workspace-symbol-resolve',
    'workspace/executeCommand'              => 'workspace-executeCommand',
    'workspace/willRenameFiles'             => 'workspace-willRenameFiles',
    'workspace/diagnostic'                  => 'workspace-diagnostic',

    # Document Synchronization
    'textDocument/didOpen'                  => 'textDocument-didOpen',
    'textDocument/didChange'                => 'textDocument-didChange',
    'textDocument/didClose'                 => 'textDocument-didClose',
    'textDocument/didSave'                  => 'textDocument-didSave',
    'textDocument/willSave'                 => 'textDocument-willSave',
    'textDocument/willSaveWaitUntil'        => 'textDocument-willSaveWaitUntil',

    # Language Features
    'textDocument/hover'                    => 'textDocument-hover',
    'textDocument/completion'               => 'textDocument-completion',
    'completionItem/resolve'                => 'completionItem-resolve',
    'textDocument/signatureHelp'            => 'textDocument-signatureHelp',
    'textDocument/declaration'              => 'textDocument-declaration',
    'textDocument/definition'               => 'textDocument-definition',
    'textDocument/typeDefinition'           => 'textDocument-typeDefinition',
    'textDocument/implementation'           => 'textDocument-implementation',
    'textDocument/references'               => 'textDocument-references',
    'textDocument/documentHighlight'        => 'textDocument-documentHighlight',
    'textDocument/documentSymbol'           => 'textDocument-documentSymbol',
    'textDocument/codeAction'               => 'textDocument-codeAction',
    'codeAction/resolve'                    => 'codeAction-resolve',
    'textDocument/codeLens'                 => 'textDocument-codeLens',
    'codeLens/resolve'                      => 'codeLens-resolve',
    'textDocument/documentLink'             => 'textDocument-documentLink',
    'documentLink/resolve'                  => 'documentLink-resolve',
    'textDocument/formatting'               => 'textDocument-formatting',
    'textDocument/rangeFormatting'          => 'textDocument-rangeFormatting',
    'textDocument/onTypeFormatting'         => 'textDocument-onTypeFormatting',
    'textDocument/rename'                   => 'textDocument-rename',
    'textDocument/prepareRename'            => 'textDocument-prepareRename',
    'textDocument/foldingRange'             => 'textDocument-foldingRange',
    'textDocument/selectionRange'           => 'textDocument-selectionRange',
    'textDocument/prepareTypeHierarchy'     => 'textDocument-prepareTypeHierarchy',
    'typeHierarchy/supertypes'              => 'typeHierarchy-supertypes',
    'typeHierarchy/subtypes'                => 'typeHierarchy-subtypes',
    'textDocument/prepareCallHierarchy'     => 'textDocument-prepareCallHierarchy',
    'callHierarchy/incomingCalls'           => 'callHierarchy-incomingCalls',
    'callHierarchy/outgoingCalls'           => 'callHierarchy-outgoingCalls',
    'textDocument/semanticTokens/full'      => 'textDocument-semanticTokens-full',
    'textDocument/semanticTokens/full/delta'=> 'textDocument-semanticTokens-full-delta',
    'textDocument/semanticTokens/range'     => 'textDocument-semanticTokens-range',
    'textDocument/inlayHint'                => 'textDocument-inlayHint',
    'inlayHint/resolve'                     => 'inlayHint-resolve',
    'textDocument/inlineValue'              => 'textDocument-inlineValue',
    'textDocument/inlineCompletion'         => 'textDocument-inlineCompletion',
    'textDocument/linkedEditingRange'       => 'textDocument-linkedEditingRange',
    'textDocument/diagnostic'               => 'textDocument-diagnostic',
);

has $.handler is required;
has &.write-response is required;
has Logger $.logger .= new;
has &.on-exit is rw;

# Lock for serializing writes to the transport
has Lock $!write-lock = Lock.new;

# Tracking in-flight requests for graceful shutdown and concurrency
has Lock $!in-flight-lock = Lock.new;
has %!in-flight; # Str $id => Promise

# Serial notification queue & promise sequencing
has Channel $!notification-channel = Channel.new;
has Promise $!notification-worker;
has Lock $!notif-gate-lock = Lock.new;
has Promise $!last-notification-promise;

submethod TWEAK() {
    if $!handler.^can('dispatcher') {
        $!handler.dispatcher = self;
    }

    # Start serial notification worker
    $!notification-worker = start {
        while $!notification-channel.receive -> %item {
            my Str $method-name = %item<method>;
            my $params          = %item<params>;
            my Promise $prom    = %item<prom>;
            my $method          = %item<lsp-method>;
            try {
                $!logger.log("Notification start: $method");
                if $!handler.^can($method-name) {
                    self!invoke-handler($method-name, $params, Any, CancellationToken);
                } else {
                    $!logger.log("Notification unhandled: $method");
                }
                $!logger.log("Notification done: $method");
                if $method eq 'exit' {
                    self.await-in-flight(:!wait-notifications);
                    my Int $code = $!handler.state == ShuttingDown ?? 0 !! 1;
                    $!handler.exit-code = $code if $!handler.^can('exit-code');
                    if &!on-exit.defined {
                        &!on-exit($code);
                    }
                }
                CATCH {
                    default {
                        $!logger.log("Notification error in $method: {.message}");
                    }
                }
            }
            try {
                $prom.keep(True) if $prom.defined && $prom.status == Planned;
                CATCH { default { } }
            }
        }
    };
}

#| Central JSON-RPC dispatch method
method dispatch(Str $json-message --> Nil) {
    my $request = try { from-json($json-message) };
    if $! {
        $!logger.log("JSON parse error: $!");
        self!write(%(
                jsonrpc => "2.0",
                id      => Any,
                error   => %(
                    code    => -32700,
                    message => "Parse error"
                )
        ));
        return;
    }

    unless $request ~~ Associative {
        self!write(%(
                jsonrpc => "2.0",
                id      => Any,
                error   => %(
                    code    => -32600,
                    message => "Invalid Request: expected JSON object"
                )
        ));
        return;
    }

    # Check if this is a response to a server-initiated request
    if !$request<method>.defined {
        if $request<error>.defined && ($request<error><code> // 0) == -32700 {
            self!write($request);
            return;
        }
        if ($request<result>:exists) || ($request<error>:exists) || ($request<id>.defined && !($request<params>:exists)) {
            $!logger.log("Received client response for id: " ~ ($request<id> // "null"));
            $!handler.client.handle-response($request) if $!handler.client.?can('handle-response');
            return;
        }
        # Missing method and not a response
        self!write(%(
                jsonrpc => "2.0",
                id      => ($request<id> // Any),
                error   => %(
                    code    => -32600,
                    message => "Invalid Request: missing method"
                )
        ));
        return;
    }

    unless $request<method> ~~ Str {
        self!write(%(
                jsonrpc => "2.0",
                id      => ($request<id> // Any),
                error   => %(
                    code    => -32600,
                    message => "Invalid Request: method must be a string"
                )
        ));
        return;
    }

    my Str $method = $request<method>;
    my $id = $request<id>;
    my Bool $is-request = $id.defined;
    my $params = $request<params>;

    # State check: Uninitialized
    if $!handler.state == Uninitialized && $method ne 'initialize' && $method ne 'exit' {
        if $is-request {
            self!write(%(
                    jsonrpc => "2.0",
                    id      => $id,
                    error   => %(
                        code    => -32002,
                        message => "Server is not initialized"
                    )
            ));
        }
        return;
    }

    # State check: Repeated initialize
    if $method eq 'initialize' && $!handler.state != Uninitialized {
        if $is-request {
            self!write(%(
                    jsonrpc => "2.0",
                    id      => $id,
                    error   => %(
                        code    => -32600,
                        message => "Already initialized"
                    )
            ));
        }
        return;
    }

    # State check: ShuttingDown
    if $!handler.state == ShuttingDown && $method ne 'exit' {
        if $is-request {
            self!write(%(
                    jsonrpc => "2.0",
                    id      => $id,
                    error   => %(
                        code    => -32600,
                        message => "Server is shutting down"
                    )
            ));
        }
        return;
    }

    # Method Whitelist Check
    unless %METHODS{$method}:exists {
        $!logger.log("Method not found (whitelist miss): $method");
        if $is-request {
            self!write(%(
                    jsonrpc => "2.0",
                    id      => $id,
                    error   => %(
                        code    => -32601,
                        message => "Method not found: $method"
                    )
            ));
        }
        return;
    }

    # Special handling: $/cancelRequest
    if $method eq '$/cancelRequest' {
        if $params ~~ Hash && $params<id>.defined {
            my $cancel-id = $params<id>;
            $!logger.log("Cancelling request: $cancel-id");
            $!handler.cancel-request-token($cancel-id);
        }
        return; # No response for $/cancelRequest
    }

    my Str $handler-method = %METHODS{$method};

    unless $!handler.^can($handler-method) {
        $!logger.log("Method not found (handler lacks $handler-method): $method");
        if $is-request {
            self!write(%(
                    jsonrpc => "2.0",
                    id      => $id,
                    error   => %(
                        code    => -32601,
                        message => "Method not found: $method"
                    )
            ));
        }
        return;
    }

    if $params.defined && !($params ~~ Hash || $params ~~ Positional) {
        $!logger.log("Invalid params (must be structured): $method (id: $id)");
        if $is-request {
            self!write(%(
                    jsonrpc => "2.0",
                    id      => $id,
                    error   => %(
                        code    => -32602,
                        message => "Invalid params: parameters must be an object or array"
                    )
            ));
        }
        return;
    }

    if $is-request {
        # REQUEST: concurrent async dispatch
        my CancellationToken $token .= new;
        $!handler.register-request-token($id, $token);

        # Snapshot any pending notification promise to ensure order
        my $prior-notif;
        $!notif-gate-lock.protect: {
            $prior-notif = $!last-notification-promise;
        };

        my Str $id-str = $id.Str;
        my Promise $prom = start {
            # Wait for any prior notification that was queued before this request
            if $prior-notif.defined && $prior-notif.status == Planned {
                await $prior-notif;
            }

            if $token.is-cancelled {
                X::LSP::Cancelled.new.throw;
            }

            $!logger.log("Request start: $method (id: $id)");
            my $res = self!invoke-handler($handler-method, $params, $id, $token);
            $res = await $res if $res ~~ Promise;

            if $token.is-cancelled {
                X::LSP::Cancelled.new.throw;
            }

            if $res ~~ Hash {
                $res<_token>:delete;
                $res<_id>:delete;
            }

            if $res ~~ Hash && ($res<error>:exists) && !($res<result>:exists) {
                self!write(%(
                        jsonrpc => "2.0",
                        id      => $id,
                        error   => $res<error>
                ));
            } else {
                self!write(%(
                        jsonrpc => "2.0",
                        id      => $id,
                        result  => ($res // Any)
                ));
            }
            $!logger.log("Request finish: $method (id: $id)");

            CATCH {
                when X::LSP::Cancelled {
                    $!logger.log("Request cancelled: $method (id: $id)");
                    self!write(%(
                            jsonrpc => "2.0",
                            id      => $id,
                            error   => %(
                                code    => -32800,
                                message => .message // "Request cancelled by client"
                            )
                    ));
                }
                when X::LSP::ContentModified {
                    $!logger.log("Request content modified: $method (id: $id)");
                    self!write(%(
                            jsonrpc => "2.0",
                            id      => $id,
                            error   => %(
                                code    => -32801,
                                message => .message // "Content modified; request superseded"
                            )
                    ));
                }
                when X::Method::NotFound {
                    $!logger.log("Method not found: $method (id: $id): {.message}");
                    self!write(%(
                            jsonrpc => "2.0",
                            id      => $id,
                            error   => %(
                                code    => -32601,
                                message => "Method not found: $method"
                            )
                    ));
                }
                when X::TypeCheck::Binding | X::LSP::InvalidParams {
                    $!logger.log("Invalid parameters: $method (id: $id): {.message}");
                    self!write(%(
                            jsonrpc => "2.0",
                            id      => $id,
                            error   => %(
                                code    => -32602,
                                message => "Invalid params: {.message}"
                            )
                    ));
                }
                when X::AdHoc && (.message.contains('parameter') || .message.contains('positional') || .message.contains('argument')) {
                    $!logger.log("Invalid parameters: $method (id: $id): {.message}");
                    self!write(%(
                            jsonrpc => "2.0",
                            id      => $id,
                            error   => %(
                                code    => -32602,
                                message => "Invalid params: {.message}"
                            )
                    ));
                }
                default {
                    $!logger.log("Request internal error: $method (id: $id): {.message}");
                    self!write(%(
                            jsonrpc => "2.0",
                            id      => $id,
                            error   => %(
                                code    => -32603,
                                message => "Internal error: {.message}"
                            )
                    ));
                }
            }
        };

        $!in-flight-lock.protect: {
            %!in-flight{$id-str} = $prom;
        };
        $prom.then: {
            $!handler.unregister-request-token($id);
            $!in-flight-lock.protect: {
                %!in-flight{$id-str}:delete;
            };
        };
    } else {
        # NOTIFICATION: sequential queue
        my Promise $notif-prom .= new;
        $!notif-gate-lock.protect: {
            $!last-notification-promise = $notif-prom;
        };
        $!notification-channel.send(%(
                method     => $handler-method,
                lsp-method => $method,
                params     => $params,
                prom       => $notif-prom
        ));
    }
}

#| Await in-flight requests, e.g. during shutdown
method await-in-flight(Any :$exclude-id, Numeric :$timeout = 10, Bool :$wait-notifications = True --> Nil) {
    my @promises;
    $!in-flight-lock.protect: {
        for %!in-flight.kv -> $id, $p {
            next if $exclude-id.defined && $id eq $exclude-id.Str;
            @promises.push($p);
        }
    };
    if @promises {
        try {
            await Promise.anyof(Promise.allof(@promises), Promise.in($timeout));
        }
    }
    if $wait-notifications {
        my $notif-prom;
        $!notif-gate-lock.protect: {
            $notif-prom = $!last-notification-promise;
        };
        if $notif-prom.defined && $notif-prom.status == Planned {
            try { await Promise.anyof($notif-prom, Promise.in($timeout)); }
        }
    }
}

method stop(--> Nil) {
    try { $!notification-channel.close; }
    $!logger.close if $!logger;
}

method !invoke-handler(Str $method-name, Any $params, Any $id, CancellationToken $token) {
    if $params ~~ Hash {
        return $!handler."$method-name"(|%$params, :_id($id), :_token($token));
    } elsif $params ~~ Positional {
        return $!handler."$method-name"(|@$params);
    } else {
        return $!handler."$method-name"(:_id($id), :_token($token));
    }
}

method !write(%response --> Nil) {
    my Str $json = to-json(%response, :!pretty);
    $!logger.log("Sending response: " ~ (%response<id> // "null") ~ (%response<error>:exists ?? " (error: {%response<error><code>})" !! " (ok)"));
    $!write-lock.protect: {
        try {
            &!write-response($json);
            CATCH { default { $!logger.log("Write error: {.message}"); } }
        }
    };
}
