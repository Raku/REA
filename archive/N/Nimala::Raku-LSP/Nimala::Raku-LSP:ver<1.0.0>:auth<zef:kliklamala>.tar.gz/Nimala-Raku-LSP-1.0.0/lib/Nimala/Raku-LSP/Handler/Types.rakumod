use v6.d;
#| Shared types for the LSP Handler and its roles.
unit module Nimala::Raku-LSP::Handler::Types;

use Nimala::Raku-LSP::Client;

#| Lifecycle states for the LSP server.
enum LSPState is export <Uninitialized Initializing Initialized ShuttingDown>;

#| Thread-safe cancellation token for LSP request and progress operations.
class CancellationToken is export {
    has atomicint $!cancelled = 0;

    method cancel(--> Nil) {
        return unless self.defined;
        cas($!cancelled, 0, 1);
    }

    method is-cancelled(--> Bool) {
        return False unless self.defined;
        $!cancelled == 1;
    }
}

#| Exception thrown when a request is cancelled by client (-32800)
class X::LSP::Cancelled is Exception is export {
    has Str $.message = "Request cancelled by client";
    has Int $.code = -32800;
}

#| Exception thrown when document content was modified during request processing (-32801)
class X::LSP::ContentModified is Exception is export {
    has Str $.message = "Content modified; request superseded";
    has Int $.code = -32801;
}

#| Exception thrown when request parameters are invalid (-32602)
class X::LSP::InvalidParams is Exception is export {
    has Str $.message = "Invalid params";
    has Int $.code = -32602;
}

#| Managed RAII progress scope for tracking and reporting work done progress.
class ProgressScope is export {
    has Str $.token is required;
    has Str $.title is required;
    has Int $.total = 0;
    has Int $.current is rw = 0;
    has Nimala::Raku-LSP::Client $.client is required;
    has CancellationToken $.cancel-token;
    has Bool $.enabled = True;
    has Promise $.ready-prom;
    has Bool $.is-finished is rw = False;
    has Lock $!lock = Lock.new;
    has Callable $.on-finish;
    has Bool $!is-ready = False;
    has Hash $!pending-report;
    has Str $!pending-finish;

    submethod TWEAK() {
        if !$!enabled {
            $!is-finished = True;
            return;
        }
        if $!ready-prom.defined {
            $!ready-prom.then(-> $res {
                    my Bool $ok = ($res.status == Kept && ($res.result // False).Bool);
                    my Bool $send-report = False;
                    my Hash %r;
                    my Bool $send-finish = False;
                    my Str $finish-msg = "";
                    my Callable $finish-cb;
                    $!lock.protect: {
                        if $ok {
                            $!is-ready = True;
                            if $!pending-report.defined {
                                %r = $!pending-report;
                                $!pending-report = Nil;
                                $send-report = True;
                            }
                            if $!pending-finish.defined {
                                $finish-msg = $!pending-finish;
                                $!pending-finish = Nil;
                                $send-finish = True;
                                $finish-cb = $!on-finish;
                            }
                        } else {
                            $!enabled = False;
                            $!is-finished = True;
                        }
                    }
                    if $send-report {
                        $!client.progress-report($!token, |%r);
                    }
                    if $send-finish {
                        $!client.progress-end($!token, :message($finish-msg));
                        if $finish-cb.defined {
                            try { $finish-cb($!token); CATCH { default { } } }
                        }
                    }
            });
        } else {
            $!is-ready = True;
        }
    }

    method ready-prom(--> Promise) {
        $!ready-prom // Promise.kept(True)
    }

    method is-cancelled(--> Bool) {
        $!cancel-token.defined && $!cancel-token.is-cancelled;
    }

    #| Increment progress counter and send percentage/message report
    multi method step(Str $message? --> Nil) {
        return unless $!enabled && !$!is-finished;
        $!lock.protect: {
            $!current++;
            my Int $pct = $!total > 0 ?? (($!current * 100) div $!total) !! Nil;
            my Str $msg = $message // ($!total > 0 ?? "$!current / $!total files" !! "");
            if $!is-ready {
                $!client.progress-report($!token, :percentage($pct), :message($msg));
            } else {
                $!pending-report = %( :percentage($pct), :message($msg) );
            }
        }
    }
    multi method step(Str :$message! --> Nil) {
        self.step($message);
    }

    #| Report arbitrary progress update
    method report(Int :$percentage?, Str :$message?, Bool :$cancellable? --> Nil) {
        return unless $!enabled && !$!is-finished;
        $!lock.protect: {
            if $!is-ready {
                $!client.progress-report($!token, :$percentage, :$message, :$cancellable);
            } else {
                $!pending-report = %( :$percentage, :$message, :$cancellable );
            }
        }
    }

    #| Finish progress reporting and dispatch 'end' event
    multi method finish(Str $message? --> Nil) {
        my Bool $send-end = False;
        my Callable $cb;
        $!lock.protect: {
            return if $!is-finished;
            $!is-finished = True;
            if $!enabled {
                if $!is-ready {
                    $send-end = True;
                    $cb = $!on-finish;
                } else {
                    $!pending-finish = $message // "";
                }
            }
        }
        if $send-end {
            $!client.progress-end($!token, :$message);
            if $cb.defined {
                try { $cb($!token); CATCH { default { } } }
            }
        }
    }
    multi method finish(Str :$message! --> Nil) {
        self.finish($message);
    }
}
