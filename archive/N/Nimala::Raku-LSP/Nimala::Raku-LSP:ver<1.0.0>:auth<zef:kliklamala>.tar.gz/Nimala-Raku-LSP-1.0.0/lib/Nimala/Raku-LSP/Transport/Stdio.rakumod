use v6.d;
#| Standard Input/Output (STDIO) transport for Language Server Protocol (LSP).
unit module Nimala::Raku-LSP::Transport::Stdio;

use Nimala::Raku-LSP::Transport::Framing;

#| Reads LSP messages from an input handle using standard Content-Length framing.
sub lsp-read-supply(IO::Handle $in = $*IN --> Supply) is export {
    try { $in.encoding(Nil) if $in.can('encoding') };
    return lsp-handle-supply($in);
}

my Lock $write-lock = Lock.new;

#| Write an LSP message to an output handle with Content-Length header.
sub lsp-write(Str $json, IO::Handle $out = $*OUT --> Nil) is export {
    my Blob $buf = lsp-frame-message($json);

    $write-lock.protect: {
        $out.write: $buf;
        $out.flush if $out.^can('flush');
    }
}
