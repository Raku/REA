use v6.d;
#| Helper module providing code action generators and lazy resolution logic.
unit module Nimala::Raku-LSP::Handler::CodeActionProviders;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;

our sub quickfix-diagnostics(Str $uri, @diagnostics --> Positional) is export {
    my @actions;
    for @diagnostics -> $diag {
        my $msg = $diag<message> // "";

        # 1. Undeclared Variable
        if $msg ~~ / "Variable '" (<[\$\@\%\&]> <[\w\-]>+) "' is not declared" / {
            my $var-name = $0.Str;
            # Option 1: Declare as local (my)
            @actions.push: {
                title       => "Declare local variable 'my $var-name'",
                kind        => "quickfix",
                diagnostics => [ $diag ],
                edit        => {
                    changes => {
                        $uri => [
                            {
                                range => {
                                    start => { line => $diag<range><start><line>, character => 0 },
                                    end   => { line => $diag<range><start><line>, character => 0 }
                                },
                                newText => "my $var-name;\n"
                            },
                        ]
                    }
                }
            };
            # Option 2: Declare as attribute (has) if it's a sigil var
            if $var-name.starts-with('$') || $var-name.starts-with('@') || $var-name.starts-with('%') {
                @actions.push: {
                    title       => "Declare attribute 'has $var-name'",
                    kind        => "quickfix",
                    diagnostics => [ $diag ],
                    edit        => {
                        changes => {
                            $uri => [
                                {
                                    range => {
                                        start => { line => $diag<range><start><line>, character => 0 },
                                        end   => { line => $diag<range><start><line>, character => 0 }
                                    },
                                    newText => "has $var-name;\n"
                                },
                            ]
                        }
                    }
                };
            }
        }

        # 2. Undeclared Routine
        if $msg ~~ / "Undeclared routine:\n" \s* (<[\w\-]>+) \s* "used at line" / {
            my $routine-name = $0.Str;
            @actions.push: {
                title       => "Create stub for sub $routine-name",
                kind        => "quickfix",
                diagnostics => [ $diag ],
                edit        => {
                    changes => {
                        $uri => [
                            {
                                range => {
                                    start => { line => $diag<range><start><line>, character => 0 },
                                    end   => { line => $diag<range><start><line>, character => 0 }
                                },
                                newText => "sub " ~ $routine-name ~ "() \{\n    ...\n\}\n\n"
                            },
                        ]
                    }
                }
            };

            my %common-modules = (
                'from-json' => 'JSON::Fast',
                'to-json'   => 'JSON::Fast',
                'get'       => 'LWP::Simple',
                'request'   => 'HTTP::UserAgent',
                'nqp'       => 'nqp'
            );

            if %common-modules{$routine-name} {
                my $mod = %common-modules{$routine-name};
                @actions.push: {
                    title       => "Add 'use $mod;'",
                    kind        => "quickfix",
                    diagnostics => [ $diag ],
                    edit        => {
                        changes => {
                            $uri => [
                                {
                                    range => {
                                        start => { line => 0, character => 0 },
                                        end   => { line => 0, character => 0 }
                                    },
                                    newText => "use $mod;\n"
                                },
                            ]
                        }
                    }
                };
            }
        }

        # 3. Missing Semicolon (Two terms in a row)
        if $msg ~~ / "Two terms in a row" / {
            @actions.push: {
                title       => "Insert missing semicolon ';'",
                kind        => "quickfix",
                diagnostics => [ $diag ],
                edit        => {
                    changes => {
                        $uri => [
                            {
                                range => {
                                    start => { line => $diag<range><start><line>, character => $diag<range><start><character> },
                                    end   => { line => $diag<range><start><line>, character => $diag<range><start><character> }
                                },
                                newText => "; "
                            },
                        ]
                    }
                }
            };
        }
    }
    return @actions;
}

our sub organize-imports-v6d(Str $uri --> Hash) is export {
    return {
        title => "Add 'use v6.d;'",
        kind  => "quickfix",
        edit  => {
            changes => {
                $uri => [
                    {
                        range   => {
                            start => { line => 0, character => 0 },
                            end   => { line => 0, character => 0 }
                        },
                        newText => "use v6.d;\n"
                    },
                ]
            }
        }
    };
}

our sub refactor-extract-actions(Str $uri, Document $doc, %range --> Positional) is export {
    my @actions;
    my $start-line = %range<start><line>;
    my $end-line   = %range<end><line>;
    my $start-char = %range<start><character>;
    my $end-char   = %range<end><character>;

    if %range && ($start-line != $end-line || $start-char != $end-char) {
        my $start-off = $doc.position-to-offset($start-line, $start-char);
        my $end-off   = $doc.position-to-offset($end-line, $end-char);
        my $selected-text = $doc.text.substr($start-off, $end-off - $start-off);

        my @syms = extract-symbols($doc);
        my @flat;
        sub walk-syms($n) {
            @flat.push($n);
            if $n<children> { for @($n<children>) -> $k { walk-syms($k) } }
        }
        for @syms -> $s { walk-syms($s) }
        my $enclosing-routine = @flat.grep({
                ($_<kind> == 6 || $_<kind> == 12) &&
                $_<range><start><line> <= $start-line <= $_<range><end><line>
        }).sort({ $^b<range><start><line> <=> $^a<range><start><line> }).first;

        my Int $insert-line = $enclosing-routine
        ?? $enclosing-routine<range><start><line>
        !! $start-line;

        my Str $insert-indent = "";
        if $insert-line < $doc.lines-count {
            $insert-indent = ($doc.line-text($insert-line) ~~ /^ (\s*) /)[0].Str;
        }

        @actions.push: {
            title => "Extract to Method",
            kind  => "refactor.extract",
            data  => {
                uri          => $uri,
                actionType   => "extract-method",
                range        => %range,
                startLine    => $start-line,
                insertLine   => $insert-line,
                indent       => $insert-indent,
                selectedText => $selected-text
            }
        };

        if $start-line == $end-line {
            my $line-text = $doc.line-text($start-line);
            if $selected-text.trim.chars > 0 {
                my $indent = $line-text ~~ /^ (\s*) / ?? $0.Str !! "";
                @actions.push: {
                    title => "Extract to variable",
                    kind  => "refactor.extract",
                    data  => {
                        uri          => $uri,
                        actionType   => "extract-variable",
                        range        => %range,
                        line         => $start-line,
                        indent       => $indent,
                        selectedText => $selected-text.trim
                    }
                };
                @actions.push: {
                    title => "Extract to constant",
                    kind  => "refactor.extract",
                    data  => {
                        uri          => $uri,
                        actionType   => "extract-constant",
                        range        => %range,
                        line         => $start-line,
                        indent       => $indent,
                        selectedText => $selected-text.trim
                    }
                };
            }
        }
    }
    return @actions;
}

our sub refactor-rewrite-actions(Any $handler, Str $uri, Document $doc, %range --> Positional) is export {
    my @actions;
    my $start-line = %range<start><line>;
    my $end-line   = %range<end><line>;
    my $start-char = %range<start><character>;

    return @actions unless $start-line == $end-line;
    my $line-text = $doc.line-text($start-line);

    # 1. Convert if-block to postfix if
    if $line-text ~~ /^ (\s*) if \s+ (.*?) \s* \{ \s* (.*?) \s* \} \s* $/ {
        my $indent = $0.Str;
        my $cond = $1.Str;
        my $stmt = $2.Str;
        $stmt ~~ s/ \s* \; \s* $ //;

        @actions.push: {
            title => "Convert to postfix if",
            kind  => "refactor.rewrite",
            data  => {
                uri        => $uri,
                actionType => "convert-postfix-if",
                line       => $start-line,
                indent     => $indent,
                cond       => $cond,
                stmt       => $stmt,
                lineLength => $doc.utf16-column($start-line, $line-text.chars)
            }
        };
    }

    # 2. Convert double quotes to single quotes
    for $line-text.match(/ \" (<-[\\\"\n]>*) \" /, :global) -> $m {
        my $str-content = $m[0].Str;
        my Int $u16-from = $doc.utf16-column($start-line, $m.from);
        my Int $u16-to   = $doc.utf16-column($start-line, $m.to);
        if $u16-from <= $start-char <= $u16-to {
            @actions.push: {
                title => "Convert to single quotes",
                kind  => "refactor.rewrite",
                data  => {
                    uri        => $uri,
                    actionType => "convert-single-quotes",
                    line       => $start-line,
                    from       => $u16-from,
                    to         => $u16-to,
                    text       => $str-content
                }
            };
        }
    }

    # 3. Inline Variable
    if my $word-res = get-word-range($doc, $start-line, $start-char) {
        my $word = $word-res<word>;
        if $word.starts-with('$') || $word.starts-with('@') || $word.starts-with('%') {
            my @refs = find-scoped-references($doc, $start-line, $start-char, :include-declaration);
            my $decl-ref = @refs.first({ ?$_<is_decl> });
            if $decl-ref {
                my Int $decl-line-idx = $decl-ref<range><start><line>;
                my Str $decl-line = $doc.line-text($decl-line-idx);
                if $decl-line ~~ / 'my' \s+ [ \w+ [ '::' \w+ ]* \s+ ]? "$word" \s* '=' \s* $<val>=(<-[;]>+) ';' / {
                    my Str $val = $<val>.trim;
                    my Bool $on-decl = ($decl-line-idx == $start-line) &&
                    ($decl-ref<range><start><character> <= $start-char <= $decl-ref<range><end><character>);
                    if $on-decl {
                        my @usages = @refs.grep({ !?$_<is_decl> });
                        if @usages.elems > 0 {
                            my @edits;
                            for @usages -> $u {
                                @edits.push: hash(
                                    range => $u<range>,
                                    newText => $val
                                );
                            }
                            my Hash $del-range;
                            if $decl-line-idx + 1 < $doc.lines-count {
                                $del-range = hash(
                                    start => hash( line => $decl-line-idx, character => 0 ),
                                    end   => hash( line => $decl-line-idx + 1, character => 0 )
                                );
                            } else {
                                $del-range = hash(
                                    start => hash( line => $decl-line-idx, character => 0 ),
                                    end   => hash( line => $decl-line-idx, character => utf16-length($decl-line) )
                                );
                            }
                            @edits.push: hash(
                                range => $del-range,
                                newText => ""
                            );
                            @actions.push: {
                                title => "Inline variable $word",
                                kind  => "refactor.inline",
                                data  => {
                                    uri        => $uri,
                                    actionType => "inline-variable",
                                    edits      => @edits
                                }
                            };
                        }
                    } else {
                        @actions.push: {
                            title => "Inline variable $word",
                            kind  => "refactor.inline",
                            data  => {
                                uri        => $uri,
                                actionType => "inline-variable",
                                range      => $word-res<range>,
                                value      => $val
                            }
                        };
                    }
                }
            }
        }
    }

    # 4. Generate Accessor for private attribute
    my @symbols = extract-symbols($doc);
    my $field-decl;
    for @symbols -> $s {
        if $s<kind> == 8 && $s<range><start><line> == $start-line {
            $field-decl = $s;
            last;
        }
        if $s<children> {
            sub find-f($kids) {
                for @($kids) -> $k {
                    if $k<kind> == 8 && $k<range><start><line> == $start-line {
                        return $k;
                    }
                    if $k<children> {
                        my $r = find-f($k<children>);
                        return $r if $r;
                    }
                }
                return Nil;
            }
            $field-decl = find-f($s<children>);
            last if $field-decl;
        }
    }

    if $field-decl && $field-decl<name> ~~ /^ <[\$\@\%\&]> \! (.*) $/ {
        my $base-name = $0.Str;
        my $var-name = $field-decl<name>;
        @actions.push: {
            title => "Generate accessor method for $var-name",
            kind  => "refactor.rewrite",
            data  => {
                uri        => $uri,
                actionType => "generate-accessor",
                line       => $start-line + 1,
                baseName   => $base-name,
                varName    => $var-name
            }
        };
    }

    # 5. Missing Role methods & Move Symbol
    if my $type-decl = find-type-decl(@symbols, $start-line) {
        if $type-decl<kind> == 5 && $handler.can('index') && $handler.index { # Class
            my @supertypes = @($type-decl<supertypes> // []);
            for @supertypes -> $role-name {
                my $role-sym = $handler.index.find-symbol($role-name).grep({ $_<kind> == 11 }).first;
                if $role-sym {
                    my @role-methods = @($role-sym<children>).grep({ $_<kind> == 6 });
                    my @class-methods = @($type-decl<children>).grep({ $_<kind> == 6 });
                    my @missing-methods;
                    for @role-methods -> $rm {
                        unless @class-methods.first({ $_<name> eq $rm<name> }) {
                            @missing-methods.push($rm);
                        }
                    }
                    if @missing-methods {
                        my Int $end-line = $type-decl<range><end><line>;
                        my Str $end-line-text = $doc.line-text($end-line);
                        my $brace-col = $end-line-text.rindex('}');
                        my Int $insert-char = $brace-col.defined ?? $doc.utf16-column($end-line, $brace-col) !! 0;
                        my Bool $is-single-line = ($type-decl<range><start><line> == $end-line);

                        @actions.push: {
                            title => "Implement missing methods from Role $role-name",
                            kind  => "refactor.rewrite",
                            data  => {
                                uri            => $uri,
                                actionType     => "implement-role-methods",
                                endLine        => $end-line,
                                insertLine     => $end-line,
                                insertChar     => $insert-char,
                                isSingleLine   => $is-single-line,
                                missingMethods => [ @missing-methods.map({ $_<name>.Str }) ]
                            }
                        };
                    }
                }
            }
        }

        my $type-name = $type-decl<name>;
        my $kind-name = $type-decl<kind> == 5 ?? "class" !! "role";

        @actions.push: {
            title => "Move $kind-name $type-name to new file",
            kind  => "refactor.extract",
            command => {
                title     => "Move Symbol",
                command   => "nimala.moveSymbol",
                arguments => [ $uri, %range, "auto" ]
            }
        };
    }

    return @actions;
}

our sub resolve-action(%action, %data --> Nil) is export {
    my Str $action-type = (%data<actionType> // "").Str;
    given $action-type {
        when 'extract-method' {
            my Str $uri = (%data<uri> // "").Str;
            my Hash $range = %data<range> // %();
            my Int $insert-line = +(%data<insertLine> // %data<startLine> // 0);
            my Str $indent = (%data<indent> // "").Str;
            my Str $selected-text = (%data<selectedText> // "").Str;

            my Str $body = $selected-text.trim.subst(/\n/, "\n" ~ $indent ~ "    ", :g);
            my @edits;
            @edits.push: {
                range   => { start => { line => $insert-line, character => 0 }, end => { line => $insert-line, character => 0 } },
                newText => $indent ~ "sub new_method() \{\n" ~ $indent ~ "    " ~ $body ~ "\n" ~ $indent ~ "\}\n\n"
            };
            @edits.push: {
                range   => $range,
                newText => "new_method()"
            };
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        when 'extract-variable' {
            my Str $uri = (%data<uri> // "").Str;
            my Hash $range = %data<range> // %();
            my Int $line = +(%data<line> // 0);
            my Str $indent = (%data<indent> // "").Str;
            my Str $selected-text = (%data<selectedText> // "").Str;

            my @edits;
            @edits.push: {
                range   => { start => { line => $line, character => 0 }, end => { line => $line, character => 0 } },
                newText => $indent ~ "my \$newVar = " ~ $selected-text ~ ";\n"
            };
            @edits.push: {
                range   => $range,
                newText => "\$newVar"
            };
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        when 'extract-constant' {
            my Str $uri = (%data<uri> // "").Str;
            my Hash $range = %data<range> // %();
            my Int $line = +(%data<line> // 0);
            my Str $indent = (%data<indent> // "").Str;
            my Str $selected-text = (%data<selectedText> // "").Str;

            my @edits;
            @edits.push: {
                range   => { start => { line => $line, character => 0 }, end => { line => $line, character => 0 } },
                newText => $indent ~ "my constant NEW_CONST = " ~ $selected-text ~ ";\n"
            };
            @edits.push: {
                range   => $range,
                newText => "NEW_CONST"
            };
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        when 'convert-postfix-if' {
            my Str $uri = (%data<uri> // "").Str;
            my Int $line = +(%data<line> // 0);
            my Str $indent = (%data<indent> // "").Str;
            my Str $cond = (%data<cond> // "").Str;
            my Str $stmt = (%data<stmt> // "").Str;
            my Int $len = +(%data<lineLength> // 0);

            my @edits;
            @edits.push: {
                range   => {
                    start => { line => $line, character => 0 },
                    end   => { line => $line, character => $len }
                },
                newText => $indent ~ $stmt ~ " if " ~ $cond ~ ";"
            };
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        when 'convert-single-quotes' {
            my Str $uri = (%data<uri> // "").Str;
            my Int $line = +(%data<line> // 0);
            my Int $from = +(%data<from> // 0);
            my Int $to = +(%data<to> // 0);
            my Str $text = (%data<text> // "").Str;

            my @edits;
            @edits.push: {
                range   => {
                    start => { line => $line, character => $from },
                    end   => { line => $line, character => $to }
                },
                newText => "'" ~ $text ~ "'"
            };
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        when 'inline-variable' {
            my Str $uri = (%data<uri> // "").Str;
            my @edits;
            if %data<edits>.defined && %data<edits>.elems > 0 {
                @edits = @(%data<edits>);
            } else {
                my Hash $range = %data<range> // %();
                my Str $val = (%data<value> // "").Str;
                @edits.push: {
                    range   => $range,
                    newText => $val
                };
            }
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        when 'generate-accessor' {
            my Str $uri = (%data<uri> // "").Str;
            my Int $line = +(%data<line> // 0);
            my Str $base-name = (%data<baseName> // "").Str;
            my Str $var-name = (%data<varName> // "").Str;

            my @edits;
            @edits.push: {
                range   => {
                    start => { line => $line, character => 0 },
                    end   => { line => $line, character => 0 }
                },
                newText => "    method " ~ $base-name ~ "() \{ " ~ $var-name ~ " \}\n"
            };
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        when 'implement-role-methods' {
            my Str $uri = (%data<uri> // "").Str;
            my Int $insert-line = +(%data<insertLine> // %data<endLine> // 0);
            my Int $insert-char = +(%data<insertChar> // 0);
            my Bool $is-single-line = ?(%data<isSingleLine> // False);
            my @missing-methods = @(%data<missingMethods> // []);

            my $newText = $is-single-line ?? "\n" !! "";
            for @missing-methods -> $method-name {
                $newText ~= "    method " ~ $method-name ~ "() \{\n        ...\n    \}\n";
            }

            my @edits;
            @edits.push: {
                range   => {
                    start => { line => $insert-line, character => $insert-char },
                    end   => { line => $insert-line, character => $insert-char }
                },
                newText => $newText
            };
            my %changes;
            %changes{$uri} = @edits;
            %action<edit> = { :%changes };
        }
        default { }
    }
}
