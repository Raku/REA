use v6.d;
unit module Nimala::Raku-LSP::Analysis::Cursor;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::Analysis::Symbols;

#| Helper to extract clean line text, character count, start offset, and UTF-16 length from Document
sub line-bounds(Document $doc, Int $line --> List) {
    return (0, 0, "", 0) if $line < 0 || $line >= $doc.line-offsets.elems;
    my Int $start = $doc.line-offsets[$line];
    my Int $next-start = ($line + 1 < $doc.line-offsets.elems) ?? $doc.line-offsets[$line + 1] !! $doc.text.chars;
    my Str $raw = $doc.text.substr($start, $next-start - $start);
    my Str $clean = $raw.subst(/ \r? \n? $ /, '');
    my Int $utf16-len = $clean.encode('utf-16le').bytes div 2;
    return ($start, $clean.chars, $clean, $utf16-len);
}

#| Returns the word AND its range at the given line and character position.
our proto sub get-word-range(|) is export {*}
multi sub get-word-range(Document $doc, Int $line, Int $character --> Hash) {
    return Nil if $line < 0 || $line >= $doc.line-offsets.elems || $character < 0;
    my ($line-start, $line-chars, $text, $line-utf16-len) = line-bounds($doc, $line);
    return Nil if $character > $line-utf16-len;

    my Int $cursor-offset = $doc.position-to-offset($line, $character);
    my Int $rel-cursor = $cursor-offset - $line-start;

    # Matches sigiled variables OR un-sigiled identifiers (with optional type smiley)
    my $word-regex = rx/
    [
        $<sigil>=<[$@%&]> $<twigil>=<[!.*^?~=]>? $<name>=[ <[a..zA..Z0..9_\-]>+ | <[!/_?\d]> ]
    ]
    |
    [
        $<ident>=( <[a..zA..Z_]> \w* [ <[\-\x27]> \w+ ]* [ '::' <[a..zA..Z_]> \w* [ <[\-\x27]> \w+ ]* ]* )
        [ ':' <!before ':'> $<smiley>=<[a..zA..Z_]>+ ]?
    ]
    /;
    for $text.match($word-regex, :g) -> $m {
        if $m.from <= $rel-cursor <= $m.to {
            my Str $word;
            my Int $len;
            my Str $call = "";
            if $m<ident> {
                $word = ~$m<ident>;
                $len  = $word.chars;
                my Str $before = $text.substr(0, $m.from);
                if $before ~~ / ( \. \^ | \. \? | \. \* | \. \+ | \. | \! ) \s* $ / {
                    $call = ~$0.trim;
                }
            } else {
                $word = $m.Str;
                $len  = $word.chars;
            }

            my Int $abs-from = $line-start + $m.from;
            my Int $abs-to   = $line-start + $m.from + $len;
            return hash(
                word => $word,
                range => hash(
                    start => $doc.position-at($abs-from),
                    end   => $doc.position-at($abs-to)
                ),
                call => $call
            );
        }
    }
    return Nil;
}
multi sub get-word-range(Str $code, Int $line, Int $character --> Hash) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", text => $code);
    return get-word-range($doc, $line, $character);
}

#| Returns the object variable or chained expression if the current position is a method call.
our proto sub get-method-call-context(|) is export {*}
multi sub get-method-call-context(Document $doc, Int $line, Int $character --> Str) {
    return "" if $line < 0 || $line >= $doc.line-offsets.elems || $character < 0;
    my ($line-start, $line-chars, $text, $line-utf16-len) = line-bounds($doc, $line);
    return "" if $character > $line-utf16-len;

    my Int $cursor-offset = $doc.position-to-offset($line, $character);
    my Int $rel-cursor = $cursor-offset - $line-start;
    my Str $before = $text.substr(0, $rel-cursor);

    # Matches: $obj.meth().prop. or @arr[0].meth() or %hash{"key"} or $!attr. or IO::Path.new.
    my $var-regex = /
    <[\$\@\%\&]> <[\!\.\*\^\?\~\=]>? <[a..zA..Z0..9_\-]>+ [ \s* \[ .*? \] | \s* \{ .*? \} | \s* \< .*? \> ]*
    | 'self'
    | <[A..Z]> <[a..zA..Z0..9_\-]>* [ '::' <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ]*
    /;

    if $before ~~ / ( <$var-regex> ) ( [ \s* \. \s* <[a..zA..Z0..9_\-]>+ [ \s* \( .*? \) ]? ]* ) \s* [ \. | \! ] \s* <[\!\*\^]>? \s* <[a..zA..Z0..9_\-]>* $/ {
        return $0.Str ~ $1.Str;
    }

    my Str $char-at-cursor = $rel-cursor < $text.chars ?? $text.substr($rel-cursor, 1) !! "";
    if $char-at-cursor eq '.' || $char-at-cursor eq '!' || $char-at-cursor eq '*' || $char-at-cursor eq '^' {
        if $before ~~ / ( <$var-regex> ) ( [ \s* \. \s* <[a..zA..Z0..9_\-]>+ [ \s* \( .*? \) ]? ]* ) \s* [ \. | \! ]? \s* $/ {
            return $0.Str ~ $1.Str;
        }
    }

    return "";
}
multi sub get-method-call-context(Str $code, Int $line, Int $character --> Str) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", text => $code);
    return get-method-call-context($doc, $line, $character);
}

#| Returns the current namespace (e.g. "App::MyClass") at the given position
our proto sub get-current-namespace(|) is export {*}
multi sub get-current-namespace(Document $doc, Int $line, Int $character --> Str) {
    my @syms = extract-symbols($doc);
    my Str $namespace = "";
    sub search(@list, Str $current-ns) {
        for @list -> $s {
            if $s<range><start><line> <= $line <= $s<range><end><line> {
                if $s<kind> == 5 || $s<kind> == 2 || $s<kind> == 11 {
                    my Str $new-ns = $current-ns eq "" ?? $s<name> !! "$current-ns\::$s<name>";
                    $namespace = $new-ns;
                    search($s<children>, $new-ns) if $s<children>;
                } else {
                    search($s<children>, $current-ns) if $s<children>;
                }
            }
        }
    }
    search(@syms, "");
    return $namespace;
}
multi sub get-current-namespace(Str $code, Int $line, Int $character --> Str) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", text => $code);
    return get-current-namespace($doc, $line, $character);
}

#| Returns the word at the given line and character position.
our proto sub get-word-at(|) is export {*}
multi sub get-word-at(Document $doc, Int $line, Int $character --> Str) {
    my $res = get-word-range($doc, $line, $character);
    return $res<word> // "";
}
multi sub get-word-at(Str $code, Int $line, Int $character --> Str) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", text => $code);
    return get-word-at($doc, $line, $character);
}

#| Returns the function name and active parameter index at the given line and character position.
our proto sub get-signature-context(|) is export {*}
multi sub get-signature-context(Document $doc, Int $line, Int $character --> List) {
    return ("", "", 0) if $line < 0 || $line >= $doc.line-offsets.elems || $character < 0;
    my ($line-start, $line-chars, $text, $line-utf16-len) = line-bounds($doc, $line);
    return ("", "", 0) if $character > $line-utf16-len;

    my Int $active-parameter = 0;
    my Int $paren-depth = 0;

    my Int $cursor-index = $doc.position-to-offset($line, $character);
    my Str $code = $doc.text;
    return ("", "", 0) if $cursor-index <= 0 || $cursor-index > $code.chars;

    my Int $pos = $cursor-index - 1;
    my Str $func-name = "";
    my Str $invocant = "";
    while $pos >= 0 {
        my Str $char = $code.substr($pos, 1);
        if $char eq ')' {
            $paren-depth++;
        } elsif $char eq '(' {
            if $paren-depth > 0 {
                $paren-depth--;
            } else {
                my Int $name-end = $pos - 1;
                while $name-end >= 0 && $code.substr($name-end, 1) eq ' ' {
                    $name-end--;
                }
                my Int $name-start = $name-end;
                while $name-start >= 0 && $code.substr($name-start, 1) ~~ /<[ \w \- ]>/ {
                    $name-start--;
                }
                $func-name = $code.substr($name-start + 1, $name-end - $name-start);

                my Int $dot-pos = $name-start;
                while $dot-pos >= 0 && $code.substr($dot-pos, 1) eq ' ' { $dot-pos-- }
                if $dot-pos >= 0 && ($code.substr($dot-pos, 1) eq '.' || $code.substr($dot-pos, 1) eq '!') {
                    my Int $inv-end = $dot-pos - 1;
                    while $inv-end >= 0 && $code.substr($inv-end, 1) eq ' ' { $inv-end-- }
                    my Int $inv-start = $inv-end;
                    while $inv-start >= 0 && $code.substr($inv-start, 1) ~~ /<[ \w \- \$ \@ \% \& \! \. \* \^ \: ]>/ {
                        $inv-start--;
                    }
                    $invocant = $code.substr($inv-start + 1, $inv-end - $inv-start);
                }

                last;
            }
        } elsif $char eq ',' {
            if $paren-depth == 0 {
                $active-parameter++;
            }
        }
        $pos--;
    }

    return ($invocant, $func-name, $active-parameter);
}
multi sub get-signature-context(Str $code, Int $line, Int $character --> List) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", text => $code);
    return get-signature-context($doc, $line, $character);
}

#| Scans a line tracking single/double quotes, identifier apostrophes, escapes, character classes, and comments.
our sub scan-line-lexical(
    Str $line-text,
    Bool :$in-single is copy = False,
    Bool :$in-double is copy = False
    --> Hash
) is export {
    my Int $opens = 0;
    my Int $closes = 0;
    my Int $comment-from = -1;
    my Bool $in-char-class = False;
    my Bool $escape = False;

    my Int $len = $line-text.chars;
    my @char-in-string;
    my @char-in-single;
    my @char-in-double;
    my @char-in-comment;

    for 0 ..^ $len -> Int $i {
        if $comment-from >= 0 {
            @char-in-comment.push(True);
            @char-in-string.push(False);
            @char-in-single.push(False);
            @char-in-double.push(False);
            next;
        }

        my Str $ch = $line-text.substr($i, 1);

        if $escape {
            $escape = False;
            @char-in-string.push($in-single || $in-double);
            @char-in-single.push($in-single);
            @char-in-double.push($in-double);
            @char-in-comment.push(False);
            next;
        }

        if $ch eq '\\' {
            $escape = True;
            @char-in-string.push($in-single || $in-double);
            @char-in-single.push($in-single);
            @char-in-double.push($in-double);
            @char-in-comment.push(False);
            next;
        }

        # Check for regex character class <[ ... ]> or <-[ ... ]> outside strings
        if !$in-single && !$in-double {
            if !$in-char-class {
                if $ch eq '<' && ($i + 1 < $len) {
                    my Str $next = $line-text.substr($i + 1, 1);
                    if $next eq '[' {
                        $in-char-class = True;
                    } elsif $next eq '-' && ($i + 2 < $len) && $line-text.substr($i + 2, 1) eq '[' {
                        $in-char-class = True;
                    }
                }
            } elsif $ch eq ']' && ($i + 1 < $len) && $line-text.substr($i + 1, 1) eq '>' {
                $in-char-class = False;
                @char-in-string.push(False);
                @char-in-single.push(False);
                @char-in-double.push(False);
                @char-in-comment.push(False);
                next;
            }

            if $in-char-class {
                @char-in-string.push(False);
                @char-in-single.push(False);
                @char-in-double.push(False);
                @char-in-comment.push(False);
                next;
            }
        }

        # Strings
        if $ch eq "'" && !$in-double {
            my Str $prev = $i > 0 ?? $line-text.substr($i - 1, 1) !! "";
            my Str $next = $i + 1 < $len ?? $line-text.substr($i + 1, 1) !! "";
            my Bool $is-ident = (?($prev ~~ /<[\w]>/)) && (?($next ~~ /<[a..zA..Z]>/));
            if $is-ident {
                @char-in-string.push($in-single || $in-double);
                @char-in-single.push($in-single);
                @char-in-double.push($in-double);
                @char-in-comment.push(False);
                next;
            } else {
                $in-single = !$in-single;
                @char-in-string.push(True);
                @char-in-single.push(True);
                @char-in-double.push(False);
                @char-in-comment.push(False);
                next;
            }
        }
        elsif $ch eq '"' && !$in-single {
            $in-double = !$in-double;
            @char-in-string.push(True);
            @char-in-single.push(False);
            @char-in-double.push(True);
            @char-in-comment.push(False);
            next;
        }

        if $in-single || $in-double {
            @char-in-string.push(True);
            @char-in-single.push($in-single);
            @char-in-double.push($in-double);
            @char-in-comment.push(False);
            next;
        }

        # Code outside strings and char classes
        if $ch eq '#' {
            $comment-from = $i;
            @char-in-comment.push(True);
            @char-in-string.push(False);
            @char-in-single.push(False);
            @char-in-double.push(False);
            next;
        }

        if $ch eq '{' || $ch eq '[' || $ch eq '(' {
            $opens++;
        } elsif $ch eq '}' || $ch eq ']' || $ch eq ')' {
            $closes++;
        }

        @char-in-string.push(False);
        @char-in-single.push(False);
        @char-in-double.push(False);
        @char-in-comment.push(False);
    }

    return hash(
        in-single        => $in-single,
        in-double        => $in-double,
        comment-from     => $comment-from,
        opens            => $opens,
        closes           => $closes,
        is-string        => @char-in-string,
        is-single        => @char-in-single,
        is-double        => @char-in-double,
        is-comment       => @char-in-comment
    );
}

#| Checks whether a character index in a line is in a comment or single-quoted string.
our sub is-ignored-ref-context(Str $line-text, Int $char-idx --> Bool) is export {
    return False if $char-idx < 0;
    my %scan = scan-line-lexical($line-text);
    if %scan<comment-from> >= 0 && $char-idx >= %scan<comment-from> {
        return True;
    }
    if $char-idx < %scan<is-single>.elems {
        return ?%scan<is-single>[$char-idx];
    }
    return ?%scan<in-single>;
}

#| Checks whether a given (line, character) position is within a comment.
our proto sub is-comment-context(|) is export {*}
multi sub is-comment-context(Document $doc, Int $line, Int $character --> Bool) {
    return False if $line < 0 || $line >= $doc.lines-count || $character < 0;
    my Str $line-text = $doc.line-text($line);
    my %scan = scan-line-lexical($line-text);
    return False if %scan<comment-from> < 0;
    my Int $comment-u16 = $doc.utf16-column($line, %scan<comment-from>);
    return $character >= $comment-u16;
}
multi sub is-comment-context(Str $code, Int $line, Int $character --> Bool) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", text => $code);
    return is-comment-context($doc, $line, $character);
}

#| Checks whether a given position is inside a comment or string literal.
our proto sub is-in-comment-or-string(|) is export {*}
multi sub is-in-comment-or-string(Document $doc, Int $line, Int $character --> Bool) {
    return False if $line < 0 || $line >= $doc.lines-count || $character < 0;
    my ($line-start, $line-chars, $line-text, $line-utf16-len) = line-bounds($doc, $line);
    return False if $character > $line-utf16-len;

    my Int $cursor-offset = $doc.position-to-offset($line, $character);
    my Int $rel-cursor = $cursor-offset - $line-start;

    my %scan = scan-line-lexical($line-text);
    if %scan<comment-from> >= 0 && $rel-cursor >= %scan<comment-from> {
        return True;
    }
    if $rel-cursor < %scan<is-string>.elems {
        return ?%scan<is-string>[$rel-cursor];
    }
    return (?%scan<in-single> || ?%scan<in-double>);
}
multi sub is-in-comment-or-string(Str $code, Int $line, Int $character --> Bool) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", text => $code);
    return is-in-comment-or-string($doc, $line, $character);
}
