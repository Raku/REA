use v6.d;
#| Role handling pull diagnostics requests:
#| textDocument/diagnostic and workspace/diagnostic.
unit role Nimala::Raku-LSP::Handler::Diagnostics;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::URI;

has Hash $!diagnostic-reports = Hash.new;
has Hash $!in-flight-diagnostics = Hash.new;
has Lock $!diagnostic-lock = Lock.new;

#| Clear cached diagnostic reports for a given URI or all URIs.
method clear-diagnostic-cache(Str $uri? --> Nil) {
    my Str $canon-uri = ($uri.defined && $uri.chars) ?? canonicalize-uri($uri) !! Str;
    $!diagnostic-lock.protect: {
        if $canon-uri.defined && $canon-uri.chars {
            $!diagnostic-reports{$canon-uri}:delete;
        } else {
            $!diagnostic-reports = Hash.new;
        }
    }
}

#| Helper to fetch or calculate diagnostics report with resultId delta-caching.
method !get-diagnostic-report(Document $doc, Str $previous-result-id = "", Any :$token --> Hash) {
    if $token.defined && $token.can('is-cancelled') && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }

    my Str $uri = canonicalize-uri($doc.uri);
    my Int $version = $doc.version // 0;
    my Str $content-hash = $version > 0 ?? "v$version" !! (($doc.text.defined && $doc.text.chars > 0) ?? "c" ~ $doc.text.chars !! "empty");
    my Str $key = "$uri\0$version\0$content-hash";

    $!diagnostic-lock.protect: {
        if $!diagnostic-reports{$uri}:exists {
            my $cached = $!diagnostic-reports{$uri};
            if ($cached<version> // -1) == $version && ($cached<content-hash> // "") eq $content-hash {
                if $previous-result-id.defined && $previous-result-id ne "" && $previous-result-id eq $cached<resultId> {
                    return {
                        kind     => "unchanged",
                        resultId => $previous-result-id
                    };
                } else {
                    return {
                        kind     => "full",
                        resultId => $cached<resultId>,
                        items    => $cached<items>
                    };
                }
            }
        }
    };

    # Compute diagnostics via check-syntax
    my Promise $prom;
    my Bool $we-start-it = False;
    $!diagnostic-lock.protect: {
        # Remove any stale in-flight promises for older versions of this URI
        for $!in-flight-diagnostics.keys -> $k {
            if $k.starts-with("$uri\0") && $k ne $key {
                $!in-flight-diagnostics{$k}:delete;
            }
        }

        if $!in-flight-diagnostics{$key}:exists {
            $prom = $!in-flight-diagnostics{$key};
        } else {
            $prom = Promise.new;
            $!in-flight-diagnostics{$key} = $prom;
            $we-start-it = True;
        }
    };

    if $we-start-it {
        my Bool $enabled = (self.get-config('syntaxCheck.enable', True)).Bool;
        my Str $executable = (self.get-config('executablePath') // self.get-config('rakuPath') // 'raku').Str;
        my Numeric $timeout = (self.get-config('syntaxCheck.timeout', 5)).Numeric;
        my @include-paths = (self.get-config('includePaths') // []).List;
        my Str $workspace-root = self.root-path.defined && self.root-path.chars ?? self.root-path !! Str;
        # NOTE: Do NOT pass caller-specific $token to shared check-syntax; run shared check to completion
        my $sub-p = try { check-syntax($doc, :$executable, :$timeout, :$enabled, :@include-paths, cwd => $workspace-root) };
        if $sub-p.defined && $sub-p ~~ Promise {
            $sub-p.then(-> $p {
                    if $p.status == Kept {
                        $prom.keep($p.result);
                    } else {
                        $prom.break($p.cause);
                    }
                    $!diagnostic-lock.protect: {
                        $!in-flight-diagnostics{$key}:delete if $!in-flight-diagnostics{$key} === $prom;
                    }
            });
        } else {
            $prom.keep([]);
            $!diagnostic-lock.protect: {
                $!in-flight-diagnostics{$key}:delete if $!in-flight-diagnostics{$key} === $prom;
            }
        }
    }

    my Hash @diagnostics;
    if $prom.defined && $prom ~~ Promise {
        try {
            if $token.defined && $token.can('is-cancelled') {
                until $prom.status != Planned {
                    if $token.is-cancelled {
                        X::LSP::Cancelled.new.throw;
                    }
                    await Promise.anyof($prom, Promise.in(0.05));
                }
                if $token.is-cancelled {
                    X::LSP::Cancelled.new.throw;
                }
            }
            my $res = await $prom;
            @diagnostics = $res.map({ %$_ }).Array if $res;
            CATCH {
                when X::LSP::Cancelled {
                        .rethrow;
                }
                default {
                    @diagnostics = [];
                }
            }
        };
    }

    if $token.defined && $token.can('is-cancelled') && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }

    # Lock order: acquire DocumentStore (Level 2) BEFORE $!diagnostic-lock (Level 3)
    my Document $current-doc = self.doc-store.get($uri);
    $!diagnostic-lock.protect: {
        if $current-doc && ($current-doc.version // 0) == $version {
            my Str $new-result-id = "$uri:$version:" ~ (now.to-posix[0].Int) ~ ":" ~ (1..1000000).roll;
            my $report = {
                version      => $version,
                content-hash => $content-hash,
                resultId     => $new-result-id,
                items        => @diagnostics
            };
            $!diagnostic-reports{$uri} = $report;
            return {
                kind     => "full",
                resultId => $new-result-id,
                items    => @diagnostics
            };
        } else {
            my Str $temp-result-id = "$uri:$version:" ~ (now.to-posix[0].Int) ~ ":" ~ (1..1000000).roll;
            return {
                kind     => "full",
                resultId => $temp-result-id,
                items    => @diagnostics
            };
        }
    };
}

#| Handle textDocument/diagnostic request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_diagnostic>
method textDocument-diagnostic(:$textDocument, Str :$previousResultId = "", Str :$identifier?, :$_id?, :$_token?, *%other --> Hash) {
    my $token = $_token // ($_id.defined ?? self.get-request-token($_id) !! (%other<id>:exists ?? self.get-request-token(%other<id>) !! CancellationToken));
    if $token.defined && $token.can('is-cancelled') && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }

    my $doc-param = $textDocument // %other<textDocument>;
    my Str $raw-uri = ($doc-param.defined && $doc-param ~~ Associative) ?? ($doc-param<uri> // "") !! "";
    my Str $uri = $raw-uri.chars ?? canonicalize-uri($raw-uri) !! "";
    my Document $doc = self.doc-store.get($uri);
    return { kind => "full", items => [] } unless $doc;

    my Str $prev-id = $previousResultId || (%other<previousResultId> // "");
    try {
        return self!get-diagnostic-report($doc, $prev-id, :$token);
        CATCH {
            when X::LSP::Cancelled {
                    .rethrow;
            }
            default {
                return { kind => "full", resultId => "", items => [] };
            }
        }
    }
}

#| Handle workspace/diagnostic request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_diagnostic>
method workspace-diagnostic(:$previousResultIds, Str :$identifier?, :$_id?, :$_token?, *%other --> Hash) {
    my $raw = $previousResultIds // %other<previousResultIds>;
    my %prev-ids{Str};
    if $raw.defined && $raw ~~ Positional {
        for @$raw -> $entry {
            if $entry.defined && $entry ~~ Associative && $entry<uri>.defined {
                my Str $u = canonicalize-uri($entry<uri>.Str);
                my Str $v = ($entry<value> // $entry<resultId> // "").Str;
                %prev-ids{$u} = $v;
            }
        }
    }
    my @items;

    try {
        my @uris = self.doc-store.get-all-uris();
        for @uris -> $uri {
            my Document $doc = self.doc-store.get($uri);
            next unless $doc;

            my Str $prev-id = (%prev-ids{$uri}:exists) ?? %prev-ids{$uri} !! "";
            my $rep = try { self!get-diagnostic-report($doc, $prev-id, token => $_token) };
            next unless $rep.defined && $rep ~~ Associative;
            if ($rep<kind> // "") eq "unchanged" {
                @items.push({
                        kind     => "unchanged",
                        uri      => $uri,
                        version  => $doc.version // 0,
                        resultId => $rep<resultId> // ""
                });
            } else {
                @items.push({
                        kind     => "full",
                        uri      => $uri,
                        version  => $doc.version // 0,
                        resultId => $rep<resultId> // "",
                        items    => ($rep<items> // []).Array
                });
            }
        }
        CATCH {
            default {
                return { items => [] };
            }
        }
    }

    return { items => @items };
}
