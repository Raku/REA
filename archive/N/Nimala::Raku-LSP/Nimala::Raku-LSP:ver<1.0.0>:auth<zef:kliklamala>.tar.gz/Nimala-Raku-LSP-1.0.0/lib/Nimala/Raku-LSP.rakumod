=begin pod

<p align="center">
  <img src="https://gitlab.com/nimala/raku/raku-lsp/-/raw/main/Raku-LSP-192.jpeg" alt="Nimala Logo" width="128" />
</p>

=head1 NAME

Nimala::Raku-LSP - Complete Raku Language Server Protocol (LSP 3.18) & Debug Adapter Protocol (DAP)

=head1 DESCRIPTION

Nimala is a full-featured Language Server Protocol (LSP 3.18) and Debug Adapter Protocol (DAP) implementation for the Raku programming language, written entirely in Raku. It provides advanced IDE intelligence, refactoring capabilities, and integrated debugging to any LSP-compatible editor (such as VS Code, Neovim, Helix, or Emacs).

=head2 Key Highlights

=item B<100% Coverage of All Useful LSP 3.18 Features>: 72 LSP methods and 20 DAP methods fully implemented and tested.
=item B<Multi-Tiered AST & Deep Type Inference>: Combines native NQP compiler AST parsing, resilient fallback grammars, and dynamic MRO / generic type tracking.
=item B<Multi-Root Workspace & Reactive Progress Engine>: Dynamic folder indexing, pruning, and bidirectional `$/progress` reporting with RAII scopes.
=item B<High Performance & Low Latency>: Persistent SQLite index caching (`.nimala/symbols.db`), prefix-based symbol search, and non-blocking asynchronous event streams (`Supply`, `Proc::Async`, `Lock`).

=head2 LSP 3.18 Implementation Matrix

=begin table

Method | Specification | Status
===
B<1. Lifecycle & General> | |
C<initialize> | L<initialize|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#initialize> | [x] done
C<initialized> | L<initialized|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#initialized> | [x] done
C<shutdown> | L<shutdown|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#shutdown> | [x] done
C<exit> | L<exit|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#exit> | [x] done
C<$/cancelRequest> | L<cancelRequest|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#cancelRequest> | [x] done
C<$/progress> | L<progress|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#progress> | [x] done
B<2. Document Synchronization> | |
C<textDocument/didOpen> | L<didOpen|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didOpen> | [x] done
C<textDocument/didChange> | L<didChange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didChange> | [x] done
C<textDocument/willSave> | L<willSave|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_willSave> | [x] done
C<textDocument/didSave> | L<didSave|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didSave> | [x] done
C<textDocument/didClose> | L<didClose|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_didClose> | [x] done
B<3. Diagnostics & Code Intelligence> | |
C<textDocument/publishDiagnostics> | L<publishDiagnostics|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_publishDiagnostics> | [x] done
C<textDocument/diagnostic> | L<pullDiagnostics|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_diagnostic> | [x] done
C<workspace/diagnostic> | L<workspacePullDiagnostics|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_diagnostic> | [x] done
C<textDocument/completion> | L<completion|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_completion> | [x] done
C<completionItem/resolve> | L<completionItem_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#completionItem_resolve> | [x] done
C<textDocument/inlineCompletion> | L<inlineCompletion|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineCompletion> | [x] done
C<textDocument/hover> | L<hover|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_hover> | [x] done
C<textDocument/signatureHelp> | L<signatureHelp|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_signatureHelp> | [x] done
C<textDocument/definition> | L<definition|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_definition> | [x] done
C<textDocument/declaration> | L<declaration|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_declaration> | [x] done
C<textDocument/typeDefinition> | L<typeDefinition|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_typeDefinition> | [x] done
C<textDocument/implementation> | L<implementation|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_implementation> | [x] done
C<textDocument/references> | L<references|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_references> | [x] done
C<textDocument/documentHighlight> | L<documentHighlight|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentHighlight> | [x] done
C<textDocument/documentSymbol> | L<documentSymbol|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentSymbol> | [x] done
C<textDocument/codeAction> | L<codeAction|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_codeAction> | [x] done
C<codeAction/resolve> | L<codeAction_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#codeAction_resolve> | [x] done
C<textDocument/codeLens> | L<codeLens|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_codeLens> | [x] done
C<codeLens/resolve> | L<codeLens_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#codeLens_resolve> | [x] done
C<textDocument/documentLink> | L<documentLink|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_documentLink> | [x] done
C<documentLink/resolve> | L<documentLink_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#documentLink_resolve> | [x] done
C<textDocument/formatting> | L<formatting|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_formatting> | [x] done
C<textDocument/rangeFormatting> | L<rangeFormatting|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_rangeFormatting> | [x] done
C<textDocument/onTypeFormatting> | L<onTypeFormatting|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_onTypeFormatting> | [x] done
C<textDocument/rename> | L<rename|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_rename> | [x] done
C<textDocument/prepareRename> | L<prepareRename|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_prepareRename> | [x] done
C<textDocument/foldingRange> | L<foldingRange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_foldingRange> | [x] done
C<textDocument/selectionRange> | L<selectionRange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_selectionRange> | [x] done
C<textDocument/inlayHint> | L<inlayHint|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_inlayHint> | [x] done
C<inlayHint/resolve> | L<inlayHint_resolve|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#inlayHint_resolve> | [x] done
C<textDocument/inlineValue> | L<inlineValue|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_inlineValue> | [x] done
C<textDocument/linkedEditingRange> | L<linkedEditingRange|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_linkedEditingRange> | [x] done
C<textDocument/semanticTokens/full> | L<semanticTokens|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_semanticTokens> | [x] done
B<4. Hierarchies> | |
C<textDocument/prepareTypeHierarchy> | L<prepareTypeHierarchy|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_prepareTypeHierarchy> | [x] done
C<typeHierarchy/supertypes> | L<supertypes|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#typeHierarchy_supertypes> | [x] done
C<typeHierarchy/subtypes> | L<subtypes|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#typeHierarchy_subtypes> | [x] done
C<textDocument/prepareCallHierarchy> | L<prepareCallHierarchy|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#textDocument_prepareCallHierarchy> | [x] done
C<callHierarchy/incomingCalls> | L<incomingCalls|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#callHierarchy_incomingCalls> | [x] done
C<callHierarchy/outgoingCalls> | L<outgoingCalls|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#callHierarchy_outgoingCalls> | [x] done
B<5. Workspace & Refreshes> | |
C<workspace/symbol> | L<symbol|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_symbol> | [x] done
C<workspace/executeCommand> | L<executeCommand|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_executeCommand> | [x] done
C<workspace/didChangeWatchedFiles> | L<didChangeWatchedFiles|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_didChangeWatchedFiles> | [x] done
C<workspace/workspaceFolders> | L<workspaceFolders|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_workspaceFolders> | [x] done
C<workspace/didChangeWorkspaceFolders> | L<didChangeWorkspaceFolders|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_didChangeWorkspaceFolders> | [x] done
C<workspace/didChangeConfiguration> | L<didChangeConfiguration|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_didChangeConfiguration> | [x] done
C<workspace/willRenameFiles> | L<willRenameFiles|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_willRenameFiles> | [x] done
C<workspace/applyEdit> | L<applyEdit|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_applyEdit> | [x] done
C<workspace/codeLens/refresh> | L<codeLens_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_codeLens_refresh> | [x] done
C<workspace/inlayHint/refresh> | L<inlayHint_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_inlayHint_refresh> | [x] done
C<workspace/semanticTokens/refresh> | L<semanticTokens_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_semanticTokens_refresh> | [x] done
C<workspace/foldingRange/refresh> | L<foldingRange_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_foldingRange_refresh> | [x] done
C<workspace/diagnostic/refresh> | L<diagnostic_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_diagnostic_refresh> | [x] done
C<workspace/inlineValue/refresh> | L<inlineValue_refresh|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#workspace_inlineValue_refresh> | [x] done
B<6. Window & Client Interaction> | |
C<window/showMessage> | L<showMessage|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_showMessage> | [x] done
C<window/showMessageRequest> | L<showMessageRequest|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_showMessageRequest> | [x] done
C<window/logMessage> | L<logMessage|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_logMessage> | [x] done
C<window/showDocument> | L<showDocument|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_showDocument> | [x] done
C<window/workDoneProgress/create> | L<workDoneProgress/create|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_workDoneProgress_create> | [x] done
C<window/workDoneProgress/cancel> | L<workDoneProgress/cancel|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#window_workDoneProgress_cancel> | [x] done
C<client/registerCapability> | L<registerCapability|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#client_registerCapability> | [x] done

=end table

=head2 Programmatic Usage

The server binary dispatches JSON-RPC through its own C<Nimala::Raku-LSP::Dispatcher> (method whitelist, cancellation, concurrent requests). For embedding, the handler can also be driven by C<JSON::RPC::Server>, as the test suite does, to analyze Raku code or build custom clients:

=begin code :lang<raku>
use Nimala::Raku-LSP::Handler;
use JSON::RPC::Server;

# Initialize the LSP Handler
my $handler = Nimala::Raku-LSP::Handler.new;

# Wrap it in a JSON-RPC Server
my $server = JSON::RPC::Server.new(application => $handler);

# Simulate a JSON-RPC Request (e.g., from a client)
my $request = q:to/END/;
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "processId": null,
    "rootUri": null,
    "capabilities": {}
  }
}
END

# Process the request and get the JSON-RPC response
my $response = $server.handler($request);
say $response;
=end code

=head2 Debug Adapter Protocol (DAP) Architecture

Nimala includes a Debug Adapter Protocol (DAP) server (C<bin/nimala-raku-dap>). The debugger is built directly on MoarVM's native remote debugging protocol, communicating with the debuggee over loopback TCP using MessagePack framing.

=item B<Native VM-Level Execution>: The debuggee runs as standard C<raku --debug-port=<port> --debug-suspend <program>>, executing standard precompiled bytecode. This eliminates the precompilation slot mismatches, slow first launches, and compiler C<when> statement crashes of earlier statement-hook implementations.
=item B<Pure-Raku MessagePack Framing>: Communication uses a fast, dependency-free MessagePack codec and protocol client with monotonic request/response correlation and event dispatch.
=item B<Monotonic Handle Management>: Context and object handles allocated during stops are tracked in a lifecycle registry and cleanly released in batches upon resume or disconnect.
=item B<Bounded Expressions & Safe Inspection>: Expression evaluation, conditional breakpoints, and logpoints use a bounded expression grammar (variables, attribute/key/index access, comparisons against literals). Arbitrary method calls and mutations are refused; only the whitelisted helpers C<.gist>, C<.Str>, C<.raku> and C<.elems> run in the debuggee, at most one per stop.
=item B<Smart Stepping>: Configurable smart stepping (C<into>, C<over>, C<disable>) automatically filters out internal compiler, runtime, and NQP frames so stepping stays focused on user code.

For full architectural details, see F<docs/DEBUG.md> and F<docs/DEBUG-MOARVM.md>.

=head2 Installation & Dependencies

Nimala requires a working Raku installation (Rakudo 2026.09 recommended) and the C<sqlite3> shared library for index
persistence. Only Rakudo 2026.09 is tested. Rakudo 2024.07 runs with limitations: the debugger can abort with a MoarVM
panic, and the RakuAST-based analysis ignores signature parameters and fails on files with C<BEGIN> blocks, so the
built-in parser fills in.

=head3 Dependencies

=item B<DBIish> & B<DBDish::SQLite>: Database independent interface and SQLite driver for persistent, transactional symbol indexing (C<.nimala/symbols.db>).
=item B<JSON::Fast>: High-performance JSON parser and serializer.

=head3 Install via Zef

=begin code :lang<sh>
# Install all dependencies and Nimala LSP/DAP binaries
zef install Nimala::Raku-LSP
=end code

C<zef> puts the C<nimala-raku-lsp> and C<nimala-raku-dap> scripts into the C<bin/> directory of the repository it
installs to. Without root rights that is usually C<~/.raku/bin>, which must be in C<PATH> (for example
C<export PATH="$HOME/.raku/bin:$PATH"> in C<~/.bashrc>). Otherwise editors cannot find the server.

=head2 Security Considerations

Like standard Raku tooling, the language server executes compile-time code when inspecting documents:

=item B<Compile-Time Execution>: Background syntax checking (C<raku -c>) and native AST parsing execute C<BEGIN>, C<CHECK>, and C<INIT> blocks as well as compile-time side effects of imported modules (C<use>).
=item B<Doc Preview Evaluation>: Rendering RakuDoc to HTML (C<raku --doc=HTML>) also evaluates compile-time blocks in opened files.
=item B<Untrusted Code>: Never open untrusted Raku files or untrusted workspaces without inspecting them first. Always use isolated environments (containers or sandboxes) when reviewing unknown code.

=head2 License
Artistic-2.0

=end pod

unit module Nimala::Raku-LSP:ver<1.0.0>;

use Nimala::Raku-LSP::Dispatcher;
use Nimala::Raku-LSP::Transport::Framing;
use Nimala::Raku-LSP::Transport::Stdio;
use Nimala::Raku-LSP::Transport::Socket ();
use Nimala::Raku-LSP::Handler;
use Nimala::Raku-LSP::Handler::Types;

use JSON::Fast;

#| Re-export run-tcp-server from Transport::Socket
sub run-tcp-server(
    Str :$host = '127.0.0.1',
    Int :$port = 5007,
    Bool :$single-session = False,
    Promise :$stop-promise = Promise.new
    --> Nil) is export {
    Nimala::Raku-LSP::Transport::Socket::run-tcp-server(:$host, :$port, :$single-session, :$stop-promise);
}

#| Start the LSP server loop.
sub run-server(
    IO::Handle :$in = $*IN,
    IO::Handle :$out = $*OUT,
    Nimala::Raku-LSP::Handler :$handler = Nimala::Raku-LSP::Handler.new(:$out),
    Any :$supply = lsp-read-supply($in)
    --> Int) is export {
    my Promise $done-promise .= new;
    my Int $exit-code = 0;

    my sub write-response(Str $json --> Nil) {
        try {
            lsp-write($json, $out);
            CATCH { default { } }
        }
    }

    my Nimala::Raku-LSP::Dispatcher $dispatcher .= new(
        :$handler,
        :&write-response,
        on-exit => -> Int $code {
            $exit-code = $code;
            $done-promise.keep(True) if $done-promise.status == Planned;
            if $handler.^can('exit-handler') && $handler.exit-handler.defined {
                my $cb = $handler.exit-handler;
                $handler.exit-handler = Nil;
                $cb.($code);
            }
        }
    );

    # Process incoming messages using the provided Supply
    react {
        whenever $supply -> Str $json-request {
            $dispatcher.dispatch($json-request);
            LAST {
                done;
            }
            QUIT {
                default {
                    done;
                }
            }
        }
        whenever $done-promise {
            done;
        }
    }

    $dispatcher.await-in-flight();
    $dispatcher.stop;

    if $done-promise.status != Kept {
        # Supply ended (EOF) without exit notification
        my Int $code = $handler.state == ShuttingDown ?? 0 !! 1;
        $exit-code = $code;
        try { $handler.shutdown() if $handler.state != ShuttingDown };
        $handler.exit-code = $code if $handler.^can('exit-code');
        if $handler.^can('exit-handler') && $handler.exit-handler.defined {
            my $cb = $handler.exit-handler;
            $handler.exit-handler = Nil;
            $cb.($code);
        }
    }

    return $exit-code;
}
