use v6.d;
unit class Nimala::Raku-DAP::Launcher;

use Nimala::Raku-DAP::DebuggeeProcess;
use Nimala::Raku-DAP::LaunchConfig;
use Nimala::Raku-DAP::MoarVMProbe;
use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Trace;

class LaunchResult {
    has Nimala::Raku-DAP::Debuggee $.debuggee;
    has Nimala::Raku-DAP::Protocol $.protocol;
    has Bool $.has-drift = False;
    has Str $.failure;
}

has &.send-event is required;
has &.send-reverse-request;
has $!supports-run-in-terminal = False;
has &.on-stderr;
has &.on-spawn;

submethod TWEAK(:$supports-run-in-terminal) {
    $!supports-run-in-terminal = $supports-run-in-terminal if $supports-run-in-terminal.defined;
}

method supports-run-in-terminal(--> Bool) {
    $!supports-run-in-terminal ~~ Callable
    ?? ?$!supports-run-in-terminal()
    !! ?$!supports-run-in-terminal;
}

method launch(Nimala::Raku-DAP::LaunchConfig $config --> Promise) {
    start {
        my Bool $terminal = $config.console ne 'internalConsole';
        if $terminal && !(self.supports-run-in-terminal && &!send-reverse-request.defined) {
            &!send-event(
                'output',
                %(
                    category => 'console',
                    output => "The client cannot run a terminal (no supportsRunInTerminalRequest); "
                    ~ "using console 'internalConsole' instead of '{$config.console}'.\n"
                )
            );
            $terminal = False;
        }

        my ($debuggee, $started) = self!spawn-debuggee($config, :$terminal);

        if !attempt($started, 'debuggee start') {
            my Str $why = $started.status ~~ Broken ?? $started.cause.message !! 'no PID reported';
            LaunchResult.new(
                :$debuggee,
                failure => $terminal
                ?? "Could not start the debuggee in a terminal: $why"
                !! "Could not start debuggee: $why"
            );
        } elsif $config.no-debug {
            await Promise.anyof($started, $debuggee.exited);
            LaunchResult.new(:$debuggee);
        } else {
            self!connect-debuggee($config, $debuggee, $terminal);
        }
    }
}

method !spawn-debuggee(
    Nimala::Raku-DAP::LaunchConfig $config,
    Int :$override-port,
    Bool :$terminal --> List
) {
    my $debuggee = $terminal
    ?? Nimala::Raku-DAP::TerminalProcess.new(
        cmd => $config.debuggee-cmd(:$override-port),
        raku => $config.raku-executable,
        env => $config.env,
        cwd => $config.cwd,
        kind => $config.console eq 'externalTerminal' ?? 'external' !! 'integrated',
        title => $config.program.IO.basename,
        send-reverse-request => &!send-reverse-request,
        on-note => -> Str $str {
            &!send-event('output', %( category => 'console', output => $str ));
        },
    )
    !! Nimala::Raku-DAP::OwnedProcess.new(
        cmd => $config.debuggee-cmd(:$override-port),
        env => $config.env,
        cwd => $config.cwd,
        on-stdout => -> Str $str {
            &!send-event('output', %( category => 'stdout', output => $str ));
        },
        on-stderr => -> Str $str {
            with &!on-stderr {
                &!on-stderr($str);
            }
        },
    );

    with &!on-spawn {
        &!on-spawn($debuggee);
    }
    return ($debuggee, $debuggee.start);
}

method !connect-debuggee(
    Nimala::Raku-DAP::LaunchConfig $config,
    Nimala::Raku-DAP::Debuggee $debuggee is copy,
    Bool $terminal
    --> LaunchResult) {
    my Int $port = $config.port;
    my $proto = Nimala::Raku-DAP::Protocol.new;
    my $connected = attempt($proto.connect('127.0.0.1', $port, :timeout(10)), 'connect');

    # A retry in terminal mode would open a second terminal, so only the adapter's own child is retried.
    if !$connected.defined && !$config.port-explicit && !$terminal {
        $debuggee.kill;
        $port = free-loopback-port();
        $debuggee = self!spawn-debuggee($config, override-port => $port)[0];
        $proto = Nimala::Raku-DAP::Protocol.new;
        $connected = attempt($proto.connect('127.0.0.1', $port, :timeout(10)), 'connect');
    }

    if !$connected.defined {
        return LaunchResult.new(
            :$debuggee,
            failure => "Could not connect to debuggee on port $port"
        );
    }

    my Bool $has-drift = has-line-drift-bug(:raku-executable($config.raku-executable));
    LaunchResult.new(
        :$debuggee,
        protocol => $proto,
        :$has-drift
    );
}
