use v6.d;
unit class Nimala::Raku-DAP::Translate;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Remote;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::ThreadState;
use Nimala::Raku-DAP::FrameClassifier;
use Nimala::Raku-DAP::ExceptionState;
use Nimala::Raku-DAP::Stepping;
use Nimala::Raku-DAP::ValueRenderer;
use Nimala::Raku-DAP::Evaluator;
use Nimala::Raku-DAP::Inspector;
use Nimala::Raku-DAP::StopHandler;
use Nimala::Raku-DAP::BreakpointRegistry;
use Nimala::Raku-DAP::SourceLines ();
use Nimala::Raku-DAP::MoarVMProbe;
use Nimala::Raku-DAP::LaunchConfig ();

has Nimala::Raku-DAP::Protocol $.protocol;
has Nimala::Raku-DAP::Handles $.handles = Nimala::Raku-DAP::Handles.new;
has Nimala::Raku-DAP::Remote $.remote;
has $.symbol-lookup;
has $.project-index;
has Nimala::Raku-DAP::FrameClassifier $.frame-classifier;
has Nimala::Raku-DAP::ValueRenderer $.renderer;
has Nimala::Raku-DAP::Evaluator $.evaluator;
has Nimala::Raku-DAP::Inspector $.inspector;
has Nimala::Raku-DAP::ExceptionState $.exception-state;
has Nimala::Raku-DAP::Stepping $.stepping;
has Nimala::Raku-DAP::StopHandler $.stop-handler;
has Nimala::Raku-DAP::ThreadRegistry $.threads;
has Nimala::Raku-DAP::SourceLines $.source-lines;

method get-symbol-lookup() {
    $!symbol-lookup // $!project-index;
}
has &.send-response is required;
has &.send-event is required;

has Bool $.is-connected = False;

method connected(--> Nil) {
    $!is-connected = True;
}
has Nimala::Raku-DAP::BreakpointRegistry $.registry;

submethod TWEAK(
    Str :$program-file = '',
    Str :$smart-step-mode = 'into',
    Int :$max-skip-count = 500,
    Bool :$has-line-drift-bug = True,
) {
    $!handles //= Nimala::Raku-DAP::Handles.new;
    $!remote //= Nimala::Raku-DAP::Remote.new(
        protocol => $!protocol,
        handles  => $!handles
    );
    $!threads = Nimala::Raku-DAP::ThreadRegistry.new(send-event => &!send-event);
    $!registry //= Nimala::Raku-DAP::BreakpointRegistry.new;
    $!source-lines //= Nimala::Raku-DAP::SourceLines.new;
    $!frame-classifier //= Nimala::Raku-DAP::FrameClassifier.new(
        symbol-lookup => self.get-symbol-lookup(),
        cwd => $*CWD,
        source-lines => $!source-lines
    );
    $!renderer //= Nimala::Raku-DAP::ValueRenderer.new(
        remote  => $!remote,
        handles => $!handles,
    );
    $!evaluator //= Nimala::Raku-DAP::Evaluator.new(
        remote           => $!remote,
        handles          => $!handles,
        renderer         => $!renderer,
        frame-classifier => $!frame-classifier,
        threads          => $!threads,
    );
    $!inspector //= Nimala::Raku-DAP::Inspector.new(
        protocol         => $!protocol,
        handles          => $!handles,
        remote           => $!remote,
        renderer         => $!renderer,
        evaluator        => $!evaluator,
        frame-classifier => $!frame-classifier,
        send-response    => &!send-response,
        threads          => $!threads,
    );
    $!exception-state //= Nimala::Raku-DAP::ExceptionState.new(
        protocol => $!protocol,
        handles => $!handles,
        remote => $!remote,
        send-response => &!send-response,
        inspect-scalar => -> Int $handle, Int $thread { $!inspector.inspect-scalar($handle, $thread) }
    );
    $!stepping //= Nimala::Raku-DAP::Stepping.new(
        protocol => $!protocol,
        handles => $!handles,
        remote => $!remote,
        frame-classifier => $!frame-classifier,
        send-response => &!send-response,
        send-event => &!send-event,
        threads => $!threads,
        is-user-breakpoint-line => -> Str $k { $!registry.is-user-line($k) },
        :$program-file,
        :$smart-step-mode,
        :$max-skip-count,
        :$has-line-drift-bug,
    );
    $!stop-handler //= Nimala::Raku-DAP::StopHandler.new(
        protocol        => $!protocol,
        remote          => $!remote,
        handles         => $!handles,
        threads         => $!threads,
        stepping        => $!stepping,
        exception-state => $!exception-state,
        registry        => $!registry,
        send-event      => &!send-event,
        evaluate        => -> Str $expr { $!evaluator.evaluate-expression($expr, 0) },
        thread-list     => -> { self.user-thread-list(timeout => 1) },
    );
}

method thread-state(Int $thread-id --> Nimala::Raku-DAP::ThreadState) {
    $!threads.thread-state($thread-id);
}

method stopped-thread(--> Int) is rw {
    $!threads.stopped-thread;
}

# Table of supported DAP command handlers
my %HANDLERS = (
    'threads'                 => 'handle-threads',
    'pause'                   => 'handle-pause',
    'continue'                => 'handle-continue',
    'next'                    => 'handle-next',
    'stepIn'                  => 'handle-step-in',
    'stepOut'                 => 'handle-step-out',
    'stackTrace'              => 'handle-stack-trace',
    'stepInTargets'           => 'handle-step-in-targets',
    'scopes'                  => 'handle-scopes',
    'variables'               => 'handle-variables',
    'evaluate'                => 'handle-evaluate',
    'exceptionInfo'           => 'handle-exception-info',
);

# Requests that read a stopped thread's state and must not run while an Invoke executes on it (DK-19)
my %INVOKE-GATED = <stackTrace scopes variables evaluate exceptionInfo>.map(* => True);

method dispatch-request(%req --> Promise) {
    my Str $cmd = %req<command> // '';

    unless %HANDLERS{$cmd}:exists {
        &!send-response(%req, {}, success => False, message => "Unknown or unsupported command: $cmd");
        return Promise.kept(False);
    }

    unless $!is-connected && $!protocol.defined {
        if $cmd eq 'threads' {
            &!send-response(%req, %( threads => [] ));
            return Promise.kept(True);
        }
        &!send-response(%req, {}, success => False, message => "Not connected to debuggee");
        return Promise.kept(False);
    }

    if (%INVOKE-GATED{$cmd}:exists) && $!protocol.invoke-in-flight(self!request-thread(%req)) {
        &!send-response(%req, {}, success => False,
            message => "An expression evaluation is still running in the debuggee; try again when it has finished");
        return Promise.kept(False);
    }

    my Str $method-name = %HANDLERS{$cmd};
    return self."$method-name"(%req);
}

#| Thread whose stopped state a request depends on, for the in-flight Invoke gate.
method !request-thread(%req --> Int) {
    my %a = %req<arguments> // {};
    my $thread = do given %req<command> {
        when 'stackTrace' | 'exceptionInfo' { %a<threadId> }
        when 'scopes' { ((try $!handles.resolve-frame((%a<frameId> // 0).Int)) // {})<thread> }
        when 'variables' {
            ((try $!handles.resolve-ref((%a<variablesReference> // 0).Int)) // {})<thread>
        }
        when 'evaluate' { %a<frameId> ?? ((try $!handles.resolve-frame(%a<frameId>.Int)) // {})<thread> !! Any }
        default { Any }
    };
    ($thread // self.stopped-thread).Int;
}

# --- Command Handlers ---

#| The raw thread list without idle thread-pool workers: a worker is kept only when its stack holds a user frame,
#| or when its stack cannot be read. Kept with the raw thread Hashes.
method user-thread-list(Real :$timeout = 5 --> Promise) {
    $!remote.thread-list(:$timeout).then(-> $p {
            my @raw = ($p.result<threads> // []).flat;
            my @checks = @raw.map(-> %t {
                    $!threads.is-pool-worker(%t)
                    ?? $!remote.stack-trace((%t<thread> // %t<id>).Int, :$timeout).then(-> $st {
                            $st.status !~~ Kept
                            || so ($st.result<frames> // []).flat.first({ !$!frame-classifier.is-internal-frame($_) })
                    })
                    !! Promise.kept(True)
            });
            my @keep = await @checks;
            @raw[(^@raw).grep({ @keep[$_] })].Array;
    });
}

method handle-threads(%req --> Promise) {
    # Protocol message 11: Thread List Request -> 12: Thread List Response
    self.user-thread-list.then(-> $p {
            if $p.status == Kept {
                try {
                    my @threads = $!threads.sync-threads($p.result.list);
                    &!send-response(%req, %( :@threads ));
                    CATCH {
                        default {
                            &!send-response(%req, {}, success => False, message => .message);
                        }
                    }
                }
            } else {
                &!send-response(%req, {}, success => False, message => $p.cause.message);
            }
    });
}

method handle-pause(%req --> Promise) {
    my Int $thread = (%req<arguments><threadId> // self.stopped-thread).Int;
    # Protocol message 5: Suspend All
    $!remote.suspend-all().then(-> $p {
            if $p.status == Kept {
                # The response comes before the stop it causes (D-19)
                &!send-response(%req, {});
                $!threads.emit-stopped($thread, 'pause');
            } else {
                &!send-response(%req, {}, success => False, message => $p.cause.message);
            }
    });
}

method handle-continue(%req --> Promise) {
    $!stepping.handle-continue(%req);
}

method handle-next(%req --> Promise) {
    $!stepping.handle-next(%req);
}

method handle-step-in(%req --> Promise) {
    $!stepping.handle-step-in(%req);
}

method handle-step-out(%req --> Promise) {
    $!stepping.handle-step-out(%req);
}

method handle-stack-trace(%req --> Promise) {
    my Int $thread = (%req<arguments><threadId> // self.stopped-thread).Int;
    my Int $start-frame = (%req<arguments><startFrame> // 0).Int;
    my Int $levels = (%req<arguments><levels> // 0).Int;

    my $t-state = self.thread-state($thread);
    if $t-state.stop-reason eq 'exception' && $t-state.frames.elems > 0 {
        return start {
            my %resp = self!format-and-page-frames($t-state.frames.list, $thread, $start-frame, $levels, :is-exception);
            &!send-response(%req, %resp);
            True;
        };
    }

    # Protocol message 13: Thread Stack Trace
    $!remote.stack-trace($thread).then(-> $p {
            if $p.status == Kept {
                try {
                    my %resp = $p.result;
                    my @raw-frames = (%resp<frames> // []).flat;
                    my %body = self!format-and-page-frames(@raw-frames, $thread, $start-frame, $levels);
                    &!send-response(%req, %body);
                    CATCH {
                        default {
                            &!send-response(%req, {}, success => False, message => .message);
                        }
                    }
                }
            } else {
                &!send-response(%req, {}, success => False, message => $p.cause.message);
            }
    });
}

method handle-step-in-targets(%req --> Promise) {
    my Int $frame-id = (%req<arguments><frameId> // %req<arguments><frame-id> // 0).Int;
    my %frame;
    try {
        %frame = $!handles.resolve-frame($frame-id);
    }
    unless %frame {
        &!send-response(%req, %( targets => [] ));
        return Promise.kept(True);
    }

    my Str $file = (%frame<file> // '').Str;
    my Int $line = (%frame<line> // 0).Int;
    if $file eq '' || $line <= 0 {
        &!send-response(%req, %( targets => [] ));
        return Promise.kept(True);
    }

    my @raw-targets = $!frame-classifier.resolve-callee-targets($file, $line);
    my @targets = @raw-targets.map(-> %t {
            %(
                id    => (%t<id> // 0).Int,
                label => (%t<label> // '').Str,
            )
    });

    &!send-response(%req, %( :@targets ));
    Promise.kept(True);
}

method !format-and-page-frames(
    @raw-frames, Int $thread, Int $start-frame, Int $levels, Bool :$is-exception = False --> Hash
) {
    my Int $total-frames = @raw-frames.elems;
    my @paged-frames = self!translate-stack-frames(@raw-frames, $thread, :$start-frame, :$levels, :$is-exception);
    return %(
        stackFrames => @paged-frames,
        totalFrames => $total-frames
    );
}

method !translate-stack-frames(
    @raw-frames,
    Int $thread,
    Int :$start-frame = 0,
    Int :$levels = 0,
    Bool :$is-exception = False
    --> Array
) {
    my Int $total = @raw-frames.elems;
    return [] if $start-frame >= $total;
    my Int $end = $levels > 0 ?? min($total, $start-frame + $levels) !! $total;

    my $t-state = self.thread-state($thread);
    my @all-dap-frames;
    for $start-frame ..^ $end -> $idx {
        my %f = @raw-frames[$idx];
        my Str $raw-file = (%f<file> // '').Str;
        my Int $line = (%f<line> // 0).Int;
        if !$is-exception {
            if $idx == 0 && $t-state.stopped-breakpoint-line > 0 {
                $line = $t-state.stopped-breakpoint-line;
                if $t-state.stopped-file ne '' {
                    $raw-file = $t-state.stopped-file;
                }
            } elsif $idx == 1 && $t-state.step-context.origin-line > 0 {
                $line = $t-state.step-context.origin-line;
                if $t-state.step-context.origin-file ne '' {
                    $raw-file = $t-state.step-context.origin-file;
                }
            }
        }
        my $frame-id = $!handles.allocate-frame($thread, $idx, :file($raw-file), :line($line));
        my Str $name = (%f<name> // '').Str.trim;
        if $name eq '' || $name eq '()' || $name eq '<routine>'
        || $name eq '<anon>' || $name eq '<anonymous>' {
            $name = '<block>';
        }

        my %source;
        my Str $resolved-path = $!frame-classifier.resolve-compunit-path($raw-file);
        if $resolved-path ne '' {
            %source = %(
                name => $resolved-path.IO.basename,
                path => $resolved-path
            );
        } elsif $raw-file ne '' {
            %source = %(
                name => $raw-file,
                presentationHint => 'deemphasize',
                origin => 'internal',
            );
        } else {
            %source = %(
                name => ($name ne '' && $name ne '<routine>') ?? $name !! '<unknown>',
                presentationHint => 'deemphasize',
                origin => 'internal',
            );
            $line = 0;
        }

        my %frame = %(
            id => $frame-id,
            name => $name,
            line => $line,
            column => 1,
            source => %source
        );
        if !$is-exception && $!frame-classifier.is-internal-frame($raw-file, $name) {
            %frame<presentationHint> = 'subtle';
        }
        @all-dap-frames.push(%frame);
    }
    @all-dap-frames;
}

method handle-scopes(%req --> Promise) {
    $!inspector.handle-scopes(%req);
}

method handle-variables(%req --> Promise) {
    $!inspector.handle-variables(%req);
}

# ponytail: setVariable and source DAP stubs deleted (D-6). Capabilities are unadvertised; clients must not send them.

method handle-evaluate(%req --> Promise) {
    # Release the actor once a helper Invoke is in flight; the response follows from the evaluation (DK-19)
    my Promise $invoke-started .= new;
    Promise.anyof($!inspector.handle-evaluate(%req, :$invoke-started), $invoke-started);
}

method handle-disconnect(%req --> Promise) {
    self.reset-exception;
    my $p = Promise.new;
    start {
        # The debuggee ends with the session, so its handles are dropped locally instead of released one by one
        $!handles.clear;
        $!protocol.close if $!protocol.defined;
        $!is-connected = False;
        &!send-response(%req, {});
        $p.keep(True);
    }
    return $p;
}

method record-exception(%ev --> Nil) {
    my Int $thread = (%ev<thread> // self.stopped-thread).Int;
    my $t-state = self.thread-state($thread);
    $!exception-state.record-exception(%ev, $t-state);
}

method reset-exception(Int $thread = self.stopped-thread --> Nil) {
    my $t-state = self.thread-state($thread);
    $!exception-state.reset-exception($t-state);
    $t-state.step-context.current-skip-count = 0;
}

method handle-exception-info(%req --> Promise) {
    my Int $thread = (%req<arguments><threadId> // self.stopped-thread).Int;
    my $t-state = self.thread-state($thread);
    $!exception-state.handle-exception-info(%req, $t-state);
}


