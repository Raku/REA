use v6.d;

#| Manages the lifecycle of a single DAP debugging session, serializing requests
#| and stop events via a dedicated actor mailbox worker.
unit class Nimala::Raku-DAP::Session;

use Nimala::Model::SymbolLookup;
use Nimala::Raku-DAP::SymbolScanner;
use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Translate;
use Nimala::Raku-DAP::BreakpointRegistry;
use Nimala::Raku-DAP::BreakpointRequests;
use Nimala::Raku-DAP::SourceLines;
use Nimala::Raku-DAP::ClientCoordinates;
use Nimala::Raku-DAP::Launcher;
use Nimala::Raku-DAP::LaunchConfig;
use Nimala::Raku-DAP::DebuggeeProcess;
use Nimala::Raku-DAP::Trace;
use Nimala::URI;

has Nimala::Raku-DAP::Debuggee $!debuggee;
has Lock $!debuggee-lock .= new;
has Bool $!debuggee-killed = False;

has Nimala::Raku-DAP::Protocol $.protocol;
has Nimala::Raku-DAP::Translate $.translator;
has Nimala::Model::SymbolLookup $.symbol-lookup;
has Nimala::Raku-DAP::BreakpointRegistry $.registry .= new;
has Nimala::Raku-DAP::SourceLines $.source-lines .= new;
has Nimala::Raku-DAP::BreakpointRequests $.breakpoint-requests;
has Nimala::Raku-DAP::Launcher $!launcher;

has &.send-response is required;
has &.send-event is required;
has &.send-reverse-request;
has &.on-exit = sub () { start { sleep 0.05; exit 0 } };

has Channel $!mailbox .= new;
has Promise $!worker-promise;

has Str $.workspace-root = "";
has %.launch-args;

has Nimala::Raku-DAP::ClientCoordinates $.coords .= new;
has Str $!client-id = '';
has Bool $!supports-run-in-terminal = False;

method client-id(--> Str) { $!client-id }
method supports-run-in-terminal(--> Bool) { $!supports-run-in-terminal }

method attach(Nimala::Raku-DAP::Translate $t --> Nil) {
    $!translator = $t;
    $t.connected;
}

method !is-connected(--> Bool) {
    so ($!protocol.defined && $!translator.defined && $!translator.is-connected);
}

method stop-handler {
    $!translator.defined ?? $!translator.stop-handler !! Nil
}

# Barrier synchronization
has Lock $!barrier-lock .= new;
has Bool $!config-done-received = False;
has atomicint $!terminated-sent = 0;
has atomicint $!session-generation = 0;

my %SERVER-CAPABILITIES = (
    supportsConfigurationDoneRequest => True, supportsEvaluateForHovers => True,
    supportsStepBack => False, supportsSetVariable => False,
    supportsConditionalBreakpoints => True, supportsHitConditionalBreakpoints => True,
    supportsLogPoints => True, supportsExceptionOptions => False,
    supportsProgressReporting => False, supportsCompletionsRequest => False,
    supportsFunctionBreakpoints => True, supportsExceptionInfoRequest => True,
    supportsDelayedStackTraceLoading => True, supportsVariablePaging => True,
    supportsTerminateRequest => True, supportsTerminateDebuggee => True,
    supportsExceptionFilterOptions => True,
    supportsRestartRequest => True,
    supportsBreakpointLocationsRequest => True,
    supportsStepInTargetsRequest => True,
    supportsClipboardContext => True,
    exceptionBreakpointFilters => [
        {
            filter => 'uncaught',
            label => 'Uncaught Exceptions',
            description => 'Breaks when an exception is thrown and not caught by user code',
            default => True,
            supportsCondition => True,
            conditionDescription => 'Bounded Raku expression (e.g. $x == 42)',
        },
        {
            filter => 'all',
            label => 'All Exceptions',
            description => 'Breaks whenever any exception is thrown, even if caught',
            default => False,
            supportsCondition => True,
            conditionDescription => 'Bounded Raku expression (e.g. $x == 42)',
        }
    ],
);

my %HANDLERS = (
    'initialize'              => 'handle-initialize',
    'setBreakpoints'          => 'handle-set-breakpoints',
    'setFunctionBreakpoints'  => 'handle-set-function-breakpoints',
    'setExceptionBreakpoints' => 'handle-set-exception-breakpoints',
    'breakpointLocations'     => 'handle-breakpoint-locations',
    'configurationDone'       => 'handle-configuration-done',
    'attach'                  => 'handle-attach',
    'launch'                  => 'handle-launch',
    'restart'                 => 'handle-restart',
    'terminate'               => 'handle-terminate',
    'disconnect'              => 'handle-disconnect',
);

submethod TWEAK(:$symbol-lookup, :$workspace-root) {
    $!symbol-lookup = $symbol-lookup // Nimala::Raku-DAP::SymbolScanner.new;
    $!workspace-root = $workspace-root if $workspace-root.defined;
    $!barrier-lock.protect: { $!config-done-received = False; }
    my &orig-resp = &!send-response;
    my &orig-ev = &!send-event;
    &!send-response = sub (%req, %body, *%opt) {
        orig-resp(%req, $!coords.response(%req, %body), |%opt);
    };
    &!send-event = sub (Str $event, %body) {
        orig-ev($event, $!coords.event($event, %body));
    };
    $!breakpoint-requests = Nimala::Raku-DAP::BreakpointRequests.new(
        registry => $!registry,
        source-lines => $!source-lines,
        coords => $!coords,
        send-response => &!send-response,
        send-event => &!send-event,
        connection => { $!protocol if self!is-connected },
        program => { (%!launch-args<program> // '').Str },
        symbol-lookup => $!symbol-lookup,
        workspace-root => { $!workspace-root },
    );
    $!launcher = Nimala::Raku-DAP::Launcher.new(
        send-event => &!send-event,
        send-reverse-request => &!send-reverse-request,
        supports-run-in-terminal => { $!supports-run-in-terminal },
        on-stderr => -> Str $str { self.record-stderr($str) },
        on-spawn => -> $debuggee {
            $!debuggee-lock.protect: {
                $!debuggee = $debuggee;
                $!debuggee-killed = False;
            }
        },
    );
}

#| Start the actor worker loop.
method start-worker(--> Promise) {
    return $!worker-promise if $!worker-promise.defined;
    $!worker-promise = start {
        while True {
            my %item;
            try {
                %item = $!mailbox.receive;
                CATCH { default { last; } }
            }
            last unless %item.defined;
            my Str $kind = %item<kind> // '';
            if $kind eq 'shutdown' {
                last;
            } elsif $kind eq 'request' {
                my %msg = %item<req>;
                try {
                    my $res = self.dispatch-request(%msg);
                    if (%msg<command> // '') ne 'launch' && (%msg<command> // '') ne 'restart' {
                        await $res if $res.defined && $res ~~ Awaitable;
                    }
                    CATCH {
                        default {
                            log-trace("ACTOR REQUEST ERROR: " ~ .message ~ "\n" ~ .backtrace.Str);
                            try &!send-response(%msg, {}, success => False, message => .message);
                        }
                    }
                }
            } elsif $kind eq 'stop_event' {
                if $!translator.defined && $!translator.stop-handler.defined {
                    try {
                        my $res = $!translator.stop-handler.handle-stop(%item<ev>);
                        await $res if $res.defined && $res ~~ Awaitable;
                        CATCH {
                            default {
                                log-trace("ACTOR STOP EVENT ERROR: " ~ .message);
                                try &!send-event('output', %(
                                        category => 'console',
                                        output => "ACTOR STOP EVENT ERROR: " ~ .message ~ "\n"
                                ));
                            }
                        }
                    }
                }
            } elsif $kind eq 'action' {
                try {
                    my $res = %item<code>();
                    await $res if $res.defined && $res ~~ Awaitable;
                    CATCH {
                        default {
                            log-trace("ACTOR ACTION ERROR: " ~ .message);
                        }
                    }
                }
            }
        }
    };
    return $!worker-promise;
}

method enqueue-request(%msg --> Nil)    { try $!mailbox.send(%( kind => 'request', req => %msg )); }
method enqueue-stop-event(%ev --> Nil)  { try $!mailbox.send(%( kind => 'stop_event', ev => %ev )); }
method enqueue-action(&code --> Nil) {
    if $!worker-promise.defined {
        try $!mailbox.send(%( kind => 'action', code => &code ));
    } else {
        try &code();
    }
}

method terminate(Bool :$keep-mailbox = False, Bool :$terminate-debuggee = True --> Nil) {
    my $target;
    $!debuggee-lock.protect: {
        return if $!debuggee-killed && $terminate-debuggee;
        $!debuggee-killed = True if $terminate-debuggee;
        $target = $!debuggee;
    };
    try $!protocol.close if $!protocol.defined && !$!translator.defined;
    if $terminate-debuggee {
        $target.kill if $target.defined;
    }
    try $!mailbox.close unless $keep-mailbox;
}

submethod DESTROY { self.terminate(); }

method dispatch-request(%msg --> Promise) {
    my Str $cmd = (%msg<command> // '').Str;
    if %HANDLERS{$cmd}:exists {
        return self."{%HANDLERS{$cmd}}"(%msg);
    } elsif $!translator.defined {
        return $!translator.dispatch-request(%msg);
    } elsif $cmd eq 'threads' {
        &!send-response(%msg, %( threads => [] ));
        return Promise.kept(True);
    } else {
        &!send-response(%msg, {}, success => False, message => "Debug session not initialized");
        return Promise.kept(False);
    }
}

#| Forwards a stderr chunk of an adapter-owned debuggee. Exception-shaped text also updates the stopped thread's
#| exception information, as an actor action, so it never races the stop pipeline (A-14).
method record-stderr(Str $str --> Nil) {
    &!send-event('output', %( category => 'stderr', output => $str ));
    my $trans = $!translator;
    return unless $trans.defined && $trans.exception-state.looks-like-exception($str);
    self.enqueue-action({
            $trans.exception-state.record-exception-from-text($str, $trans.thread-state($trans.stopped-thread));
    });
}

#| Ends the session once: `exited` with the code of a debuggee that ran, then `terminated`. Without a code (a launch
#| that failed before the program ran), only `terminated` is sent (D-23).
method trigger-session-terminated(Int $exit-code? --> Nil) {
    if $!terminated-sent⚛++ == 0 {
        &!send-event('exited', %( exitCode => $exit-code )) if $exit-code.defined;
        &!send-event('terminated', {});
    }
}

# --- Handlers ---

method handle-initialize(%msg --> Promise) {
    $!barrier-lock.protect: { $!config-done-received = False; }
    my %args = (%msg<arguments>.defined && %msg<arguments> ~~ Hash) ?? %msg<arguments> !! Hash.new;
    my Str $err = $!coords.negotiate(%args);
    if $err.defined {
        &!send-response(%msg, {}, success => False, message => $err);
        return Promise.kept(False);
    }
    $!client-id = (%args<clientID> // '').Str;
    $!supports-run-in-terminal = ?(%args<supportsRunInTerminalRequest> // False);

    &!send-response(%msg, %SERVER-CAPABILITIES);
    &!send-event('initialized', {});
    return Promise.kept(True);
}

method handle-set-breakpoints(%msg --> Promise) {
    $!breakpoint-requests.handle-set-breakpoints(%msg);
}

method handle-set-function-breakpoints(%msg --> Promise) {
    $!breakpoint-requests.handle-set-function-breakpoints(%msg);
}

method handle-set-exception-breakpoints(%msg --> Promise) {
    $!breakpoint-requests.handle-set-exception-breakpoints(%msg);
}

method handle-breakpoint-locations(%msg --> Promise) {
    $!breakpoint-requests.handle-breakpoint-locations(%msg);
}

method handle-configuration-done(%msg --> Promise) {
    &!send-response(%msg, {});
    my Bool $already-connected = False;
    $!barrier-lock.protect: {
        $!config-done-received = True;
        $already-connected = self!is-connected;
    }
    if $already-connected {
        attempt($!breakpoint-requests.apply-exception-filters($!registry.exception-filters), 'apply exception filters');
        attempt($!protocol.send-request(msg-resume-all()), 'resume all');
    }
    return Promise.kept(True);
}

method handle-attach(%msg --> Promise) {
    &!send-response(%msg, {}, success => False, message => "Attaching to a running process is not currently supported");
    return Promise.kept(False);
}

method handle-terminate(%msg --> Promise) {
    &!send-response(%msg, {});
    my $target = $!debuggee-lock.protect: { $!debuggee };
    if $target.defined && $target.is-running {
        if $!protocol.defined {
            try $!protocol.send-request(msg-resume-all());
        }
        $target.terminate(grace => 2.0);
    }
    return Promise.kept(True);
}

method handle-disconnect(%msg --> Promise) {
    my %args = (%msg<arguments>.defined && %msg<arguments> ~~ Hash) ?? %msg<arguments> !! Hash.new;
    my Bool $terminate-debuggee = (%args<terminateDebuggee>:exists) ?? ?%args<terminateDebuggee> !! True;
    my Bool $restart = ?(%args<restart> // False);
    $terminate-debuggee = self!detach-debuggee unless $terminate-debuggee;

    self.terminate(:keep-mailbox($restart), :$terminate-debuggee);
    if $!translator.defined {
        attempt($!translator.handle-disconnect(%msg), 'handle disconnect');
    } else {
        &!send-response(%msg, {});
    }

    if $restart {
        $!debuggee-lock.protect: {
            $!debuggee = Nil;
            $!debuggee-killed = False;
        };
        $!protocol = Nil;
        $!translator = Nil;
        $!registry.reset-session-state();
        $!barrier-lock.protect: { $!config-done-received = False; }
        atomic-assign($!terminated-sent, 0);
    } else {
        &!on-exit();
    }
    return Promise.kept(True);
}

#| `terminateDebuggee: false`. A terminal debuggee is left running without breakpoints (D-12); returns False.
#| An adapter-owned debuggee cannot outlive its output pipes, so it is terminated after all; returns True.
method !detach-debuggee(--> Bool) {
    my $target = $!debuggee-lock.protect: { $!debuggee };
    return True without $target;
    unless $target.can-detach {
        &!send-event('output', %( category => 'console',
                output => "terminateDebuggee: false is not possible here: the debuggee's output pipes end with the "
                ~ "adapter, so it is terminated.\n" ));
        return True;
    }
    if $!protocol.defined {
        attempt($!protocol.send-request(msg-clear-all-breakpoints(), :timeout(2)), 'clear all breakpoints');
        attempt($!protocol.send-request(msg-resume-all(), :timeout(2)), 'resume all');
    }
    $target.detach;
    return False;
}

method !wire-and-resume-debuggee(
    Nimala::Raku-DAP::Protocol $proto, Nimala::Raku-DAP::LaunchConfig $config,
    Nimala::Raku-DAP::Debuggee $debuggee, Bool $has-drift, %msg, Int :$gen = $!session-generation --> Nil
) {
    if $!debuggee-killed || $gen != $!session-generation { try $proto.close; return; }
    $!protocol = $proto;
    $proto.terminated.tap(sub ($) {
            if $gen == $!session-generation {
                start {
                    my Promise $exited = $debuggee.exited;
                    await Promise.anyof($exited, Promise.in(3));
                    if $exited.status ~~ Planned {
                        $debuggee.kill;
                        attempt(Promise.anyof($exited, Promise.in(2)), 'wait for debuggee exit');
                    }
                    if $exited.status ~~ Planned && $gen == $!session-generation {
                        self.trigger-session-terminated(128 + SIGKILL.Int);
                    }
                }
            }
    });

    my $trans = Nimala::Raku-DAP::Translate.new(
        protocol => $proto, send-response => &!send-response, send-event => &!send-event,
        symbol-lookup => $!symbol-lookup, program-file => $config.program,
        smart-step-mode => $config.smart-step-mode, has-line-drift-bug => $has-drift, registry => $!registry,
        source-lines => $!source-lines,
    );
    self.attach($trans);

    $proto.problems.tap(sub (Str $prob) {
            if $gen == $!session-generation {
                &!send-event('output', %( category => 'console', output => "$prob\n" ));
            }
    });
    $proto.events.tap(sub (%ev) {
            if $gen == $!session-generation {
                self.enqueue-stop-event(%ev) if is-stop-event(%ev);
            }
    });

    attempt(
        $!breakpoint-requests.apply-early($proto, program => $config.program, stop-on-entry => $config.stop-on-entry),
        'apply early breakpoints'
    );
    &!send-response(%msg, {});

    self!emit-process($config, $debuggee);

    my Bool $can-resume = False;
    $!barrier-lock.protect: { $can-resume = $!config-done-received; }
    attempt($proto.send-request(msg-resume-all()), 'resume all') if $can-resume;

    $debuggee.exited.then(sub ($p) {
            if $gen == $!session-generation {
                self.trigger-session-terminated($p.result);
            }
    });
}

method handle-launch(%msg --> Promise) {
    atomic-assign($!terminated-sent, 0);
    my Int $gen = ++⚛$!session-generation;
    %!launch-args = (%msg<arguments>.defined && %msg<arguments> ~~ Hash) ?? %msg<arguments> !! Hash.new;
    if %!launch-args<program>.defined {
        %!launch-args<program> = $!coords.in-path(%!launch-args<program>.Str);
    }
    if %!launch-args<cwd>.defined {
        %!launch-args<cwd> = $!coords.in-path(%!launch-args<cwd>.Str);
    }
    with Nimala::Raku-DAP::Trace::init-trace-logging((%!launch-args<trace> // False).Bool) -> $refused {
        &!send-event('output', %( category => 'stderr', output => $refused ));
    }

    my %prep = Nimala::Raku-DAP::LaunchConfig.from-args(
        %!launch-args,
        workspace-root => $!workspace-root,
        exception-filters => (
            $!registry.exception-filters.elems > 0 ?? $!registry.exception-filters.list !! ['uncaught']
        ),
        warn-callback => -> Str $w {
            &!send-event('output', %( category => 'console', output => $w ));
        }
    );

    if !%prep<ok> {
        &!send-response(%msg, {}, success => False, message => %prep<error>.Str);
        self.trigger-session-terminated();
        return Promise.kept(False);
    }

    my Nimala::Raku-DAP::LaunchConfig $config = %prep<config>;
    $!workspace-root = $config.cwd;
    my IO::Path $prog-path = $config.program.IO;
    my Str $p-uri = path-to-uri($prog-path);
    my Str $p-code = try { $prog-path.slurp } // "";
    $!symbol-lookup.update-file($p-uri, $p-code) if $p-code.chars > 0;

    return $!launcher.launch($config).then(-> $p {
            my Nimala::Raku-DAP::Launcher::LaunchResult $res = $p.result;
            self.enqueue-action({
                    if $gen == $!session-generation {
                        if $!debuggee-killed {
                            try $res.protocol.close if $res.protocol.defined;
                        } elsif $res.failure.defined {
                            &!send-response(%msg, {}, success => False, message => $res.failure);
                            $res.debuggee.kill if $res.debuggee.defined;
                            self.trigger-session-terminated;
                        } elsif $config.no-debug {
                            &!send-response(%msg, {});
                            self!emit-process($config, $res.debuggee);
                            $res.debuggee.exited.then(sub ($p) {
                                    if $gen == $!session-generation {
                                        self.trigger-session-terminated($p.result);
                                    }
                            });
                        } else {
                            self!wire-and-resume-debuggee(
                                $res.protocol, $config, $res.debuggee, $res.has-drift, %msg, :$gen
                            );
                        }
                    }
            });
            True;
    });
}

method handle-restart(%msg --> Promise) {
    unless %!launch-args && %!launch-args<program>.defined {
        &!send-response(%msg, {}, success => False, message => "No active launch configuration to restart");
        return Promise.kept(False);
    }

    my Int $gen = ++⚛$!session-generation;

    my %args = (%msg<arguments>.defined && %msg<arguments> ~~ Hash) ?? %msg<arguments> !! Hash.new;
    if %args<arguments>.defined && %args<arguments> ~~ Hash {
        for %args<arguments>.kv -> $k, $v {
            %!launch-args{$k} = $v;
        }
    }

    my $target;
    $!debuggee-lock.protect: {
        $target = $!debuggee;
        $!debuggee = Nil;
        $!debuggee-killed = False;
    };
    try $!protocol.close if $!protocol.defined;
    $!protocol = Nil;
    $!translator = Nil;
    if $target.defined && $target.is-running {
        $target.kill;
    }

    $!registry.reset-session-state();

    $!barrier-lock.protect: {
        $!config-done-received = True;
    }

    my %prep = Nimala::Raku-DAP::LaunchConfig.from-args(
        %!launch-args,
        workspace-root => $!workspace-root,
        exception-filters => (
            $!registry.exception-filters.elems > 0 ?? $!registry.exception-filters.list !! ['uncaught']
        ),
        warn-callback => -> Str $w {
            &!send-event('output', %( category => 'console', output => $w ));
        }
    );

    if !%prep<ok> {
        &!send-response(%msg, {}, success => False, message => %prep<error>.Str);
        self.trigger-session-terminated();
        return Promise.kept(False);
    }

    my Nimala::Raku-DAP::LaunchConfig $config = %prep<config>;
    $!workspace-root = $config.cwd;
    my IO::Path $prog-path = $config.program.IO;
    my Str $p-uri = path-to-uri($prog-path);
    my Str $p-code = try { $prog-path.slurp } // "";
    $!symbol-lookup.update-file($p-uri, $p-code) if $p-code.chars > 0;

    return $!launcher.launch($config).then(-> $p {
            my Nimala::Raku-DAP::Launcher::LaunchResult $res = $p.result;
            self.enqueue-action({
                    if $gen == $!session-generation {
                        if $!debuggee-killed {
                            try $res.protocol.close if $res.protocol.defined;
                        } elsif $res.failure.defined {
                            &!send-response(%msg, {}, success => False, message => $res.failure);
                            $res.debuggee.kill if $res.debuggee.defined;
                            self.trigger-session-terminated;
                        } elsif $config.no-debug {
                            &!send-response(%msg, {});
                            self!emit-process($config, $res.debuggee);
                            $res.debuggee.exited.then(sub ($p) {
                                    if $gen == $!session-generation {
                                        self.trigger-session-terminated($p.result);
                                    }
                            });
                        } else {
                            self!wire-and-resume-debuggee(
                                $res.protocol, $config, $res.debuggee, $res.has-drift, %msg, :$gen
                            );
                        }
                    }
            });
            True;
    });
}

method !emit-process(Nimala::Raku-DAP::LaunchConfig $config, Nimala::Raku-DAP::Debuggee $debuggee --> Nil) {
    &!send-event('process', %(
            name            => $config.program,
            systemProcessId => $debuggee.pid,
            isLocalProcess  => True,
            startMethod     => 'launch',
    ));
}
