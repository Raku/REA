use v6.d;
unit class Nimala::Raku-DAP::FrameClassifier;

use Nimala::Raku-DAP::SymbolScanner;
use Nimala::Raku-DAP::SourceLines;
use Nimala::URI;

has $.symbol-lookup;
has $.cwd = $*CWD;
has Nimala::Raku-DAP::SourceLines $.source-lines;
has Nimala::Raku-DAP::SymbolScanner $!private-scanner .= new;
has Lock $!cache-lock .= new;
has %!file-cache;
has %!compunit-cache;

#| Check whether a line of source code is an executable statement (excluding braces and comments).
#| Backwards compatibility alias for stoppable-line.
our sub is-executable-line(Str $line-text --> Bool) is export {
    stoppable-line($line-text);
}

our proto resolve-compunit-path(|) is export {*}

our multi sub resolve-compunit-path(Str $raw-file, :$project-index, :$cwd = $*CWD --> Str) is export {
    return '' unless $raw-file;

    # Short-circuit internal and generated frames
    if $raw-file.starts-with('SETTING::')
    || $raw-file.ends-with('.nqp')
    || $raw-file.contains('.nqp')
    || $raw-file.contains('CORE.')
    || $raw-file.starts-with('NQP::')
    || $raw-file.starts-with('EVAL_')
    || $raw-file.contains('/EVAL_')
    || $raw-file.starts-with('<ephemeral')
    || $raw-file eq '<unknown>'
    || $raw-file.contains('gen/moar/') {
        return '';
    }

    my Str $clean = $raw-file.subst(/ ':' \d+ $/, '');
    return '' if $clean eq '' || $clean eq '<unknown>' || $clean.starts-with('<ephemeral');

    # 1. If it is already an existing file path
    if $clean.IO.e && $clean.IO.f {
        return $clean.IO.absolute;
    }

    # 2. If relative to cwd
    if $cwd.IO.add($clean).e && $cwd.IO.add($clean).f {
        return $cwd.IO.add($clean).absolute;
    }

    # 3. Extract module name if enclosed in parentheses or compilation unit id
    my Str $mod = $clean;
    if $clean ~~ / '(' (<[\w\:\.\-]>+) ')' / {
        $mod = $0.Str;
    } elsif $clean ~~ /^ (<[\w\:\.\-]>+) / {
        $mod = $0.Str;
    }

    # Try resolving via ProjectIndex if available
    if $project-index.defined {
        my @syms = try { $project-index.find-symbol($mod) } // [];
        for @syms -> $s {
            my Str $uri = ($s<uri> // ($s.can('location') && $s.location ?? $s.location.uri !! '')).Str;
            if $uri.starts-with('file://') {
                my IO::Path $path = uri-to-path($uri);
                if $path.e {
                    return $path.absolute;
                }
            }
        }

        my %files = try { $project-index.all-files-symbols } // %();
        my Str $rel-file = $mod.subst('::', '/', :g);
        for %files.keys -> $uri {
            if $uri.ends-with($rel-file ~ '.rakumod') || $uri.ends-with($rel-file ~ '.pm6') || $uri.ends-with($rel-file) {
                my IO::Path $path = uri-to-path($uri);
                if $path.e {
                    return $path.absolute;
                }
            }
        }
    }

    # Try workspace directory directly
    my Str $rel = $mod.subst('::', '/', :g);
    for ('lib/' ~ $rel ~ '.rakumod', 'lib/' ~ $rel ~ '.pm6', $rel ~ '.rakumod', $rel ~ '.pm6') -> $candidate {
        if $cwd.IO.add($candidate).e {
            return $cwd.IO.add($candidate).absolute;
        }
    }

    return '';
}

our proto is-internal-frame(|) is export {*}

our multi sub is-internal-frame(%frame, :$project-index, :$cwd = $*CWD, :$classifier --> Bool) is export {
    my Str $file = (%frame<file> // '').Str;
    my Str $name = (%frame<name> // '').Str;
    is-internal-frame($file, $name, :$project-index, :$cwd, :$classifier);
}

our multi sub is-internal-frame(Str $file, Str $name = '', :$project-index, :$cwd = $*CWD, :$classifier --> Bool) is export {
    # Unclassifiable / missing file
    return True if !$file.defined || $file eq "";
    return True if $name eq '<main>' || $name eq '<entry>' || $name eq '<mainline>' || $name eq '<unit-outer>';

    # Strip line suffix if present (e.g. "path/to/file.nqp:123" or ":1")
    my Str $clean = $file.subst(/ ':' \d+ $/, '');
    return True if $clean eq "";

    # Injected helper & debugger internal routines
    return True if $clean.contains('InjectedHelper.rakumod') || $name.starts-with('_nimala_');

    # NQP sources
    return True if $clean.ends-with('.nqp') || $clean.contains('.nqp') || $clean.starts-with('NQP::') || $clean.contains('/nqp/');

    # Generated sources
    return True if $clean eq '<ephemeral file>' || $clean.starts-with('<ephemeral')
    || $clean.starts-with('EVAL_') || $clean.contains('/EVAL_')
    || $clean.contains('gen/moar/') || $clean eq '<unknown>';

    # Rakudo / MoarVM installation sources
    return True if $clean.starts-with('SETTING::') || $clean.contains('CORE.setting') || $clean.contains('CORE.c.setting');
    return True if $clean.contains('/share/perl6/') || $clean.contains('/share/nqp/') || $clean.contains('/share/rakudo/')
    || $clean.contains('/perl6/runtime/') || $clean.contains('/perl6/lib/');

    # Compilation unit or module name (e.g. from an installation or Raku module)
    if $clean.contains('#') || $clean.starts-with('CompUnit::') || $clean.contains('::') {
        my Str $resolved = $classifier.defined
        ?? $classifier.resolve-compunit-path($clean)
        !! resolve-compunit-path($clean, :$project-index, :$cwd);
        if $resolved ne '' {
            return False; # Resolves to workspace file -> user code!
        }
        return True; # Unresolvable compunit/module -> internal
    }

    # If it is a file on disk
    if $clean.IO.e && $clean.IO.f {
        my Str $abs = canonical-path($clean);
        if $abs.contains('/share/perl6/') || $abs.contains('/share/nqp/') || $abs.contains('/share/rakudo/') {
            return True;
        }
        return False;
    }

    # If relative to $cwd and exists on disk
    if $cwd.IO.add($clean).e && $cwd.IO.add($clean).f {
        my Str $abs = canonical-path($cwd.IO.add($clean).Str);
        if $abs.contains('/share/perl6/') || $abs.contains('/share/nqp/') || $abs.contains('/share/rakudo/') {
            return True;
        }
        return False;
    }

    # Try resolving via project-index if available
    if $project-index.defined {
        my Str $resolved = $classifier.defined
        ?? $classifier.resolve-compunit-path($clean)
        !! resolve-compunit-path($clean, :$project-index, :$cwd);
        if $resolved ne '' {
            return False;
        }
    }

    # Any other unclassifiable path is internal so stepping doesn't land somewhere unviewable
    return True;
}

method is-internal-frame(Any $file-or-frame, Str $name = '' --> Bool) {
    if $file-or-frame ~~ Associative {
        return is-internal-frame($file-or-frame, :project-index($!symbol-lookup), :cwd($!cwd), :classifier(self));
    }
    is-internal-frame($file-or-frame.defined ?? $file-or-frame.Str !! '', $name, :project-index($!symbol-lookup), :cwd($!cwd), :classifier(self));
}

method resolve-compunit-path(Str $raw-file --> Str) {
    return '' unless $raw-file;
    $!cache-lock.protect: {
        return %!compunit-cache{$raw-file} if %!compunit-cache{$raw-file}:exists;
    }
    my Str $res = resolve-compunit-path($raw-file, :project-index($!symbol-lookup), :cwd($!cwd));
    $!cache-lock.protect: {
        %!compunit-cache{$raw-file} = $res;
    }
    return $res;
}

method !get-file-data(Str $file --> Hash) {
    my IO::Path $path = $file.IO;
    return %() unless $path.e && $path.f;
    my Str $canon = (try $path.resolve.absolute) // $path.absolute;
    my $mtime = try $path.modified;

    $!cache-lock.protect: {
        if %!file-cache{$canon}:exists {
            my %e := %!file-cache{$canon};
            if %e<mtime> === $mtime || (%e<mtime>.defined && $mtime.defined && %e<mtime> == $mtime) {
                return %e;
            }
        }
    }

    my @lines = ($!source-lines // Nimala::Raku-DAP::SourceLines.new).lines-for($canon);
    my Str $code = @lines.join("\n");
    my Str $uri = $canon.starts-with('file://') ?? $canon !! path-to-uri($path);

    my $scanner = $!symbol-lookup;
    my %existing-files = try { $scanner.all-files-symbols } // %();
    if !$scanner.defined || !(%existing-files{$uri}:exists && %existing-files{$uri}.elems) {
        $!private-scanner.update-file($uri, $code);
        $scanner = $!private-scanner;
        %existing-files = try { $scanner.all-files-symbols } // %();
    }

    my @all-file-syms = (%existing-files{$uri} // []).list;
    my @routines = @all-file-syms.grep({ ($_<kind> // 0) == SYM-ROUTINE || ($_<kind> // 0) == SYM-METHOD });

    my SetHash $excluded-lines .= new;
    my @parsed-routines;
    for @routines -> %r {
        my Int $start = (%r<range><start><line> // 0).Int + 1;
        my Int $end   = (%r<range><end><character> // 0) > 0
        ?? (%r<range><end><line> // 0).Int + 1
        !! (%r<range><end><line> // 0).Int;
        $excluded-lines.set($_) for $start..$end;

        my Int @res;
        for $start..$end -> $l {
            if $l <= @lines.elems && stoppable-line(@lines[$l - 1]) {
                @res.push($l);
            }
        }
        @parsed-routines.push(%(
                name => (%r<name> // 'routine').Str,
                start-line => $start,
                end-line => $end,
                lines => Array[Int].new(@res),
        ));
    }

    my Int @mainline;
    for 1..@lines.elems -> $l {
        unless $excluded-lines{$l} {
            if stoppable-line(@lines[$l - 1]) {
                @mainline.push($l);
            }
        }
    }
    my Array[Int] $mainline-lines = Array[Int].new(@mainline);

    my %data = %(
        :$canon,
        :$mtime,
        :$uri,
        lines => @lines,
        :$code,
        :$scanner,
        routines => @parsed-routines,
        mainline-lines => $mainline-lines,
    );

    $!cache-lock.protect: {
        %!file-cache{$canon} = %data;
    }

    return %data;
}

method extract-routine-info(Str $file, Int $line --> Hash) {
    my %data = self!get-file-data($file);
    return %( scope => 'unknown', lines => Array[Int].new ) unless %data;

    my @lines = %data<lines>.list;
    return %( scope => 'unknown', lines => Array[Int].new ) unless @lines.elems > 0;

    my @routines = (%data<routines> // []).list;
    for @routines -> %r {
        if %r<start-line> <= $line <= %r<end-line> {
            return %( scope => %r<name>, lines => %r<lines> );
        }
    }

    return %( scope => 'mainline', lines => (%data<mainline-lines> // Array[Int].new) );
}

method extract-routine-lines(Str $file, Int $line --> Array[Int]) {
    my %info = self.extract-routine-info($file, $line);
    return (%info<lines> // Array[Int].new);
}

method !find-routine-entry(Str $file, Str $name --> Hash) {
    my %data = self!get-file-data($file);
    return %() unless %data;
    my @lines = %data<lines>.list;

    # First check cached symbols for this file
    my Str $uri = %data<uri>;
    my $scanner = %data<scanner>;
    my %files = try { $scanner.all-files-symbols } // %();
    my @syms = (%files{$uri} // []).list.grep({
            (($_<kind> // 0) == SYM-ROUTINE || ($_<kind> // 0) == SYM-METHOD) && ($_<name> // '') eq $name
    });
    if @syms.elems > 0 {
        my Int $target-line = ((@syms[0]<range><start><line> // 0) + 1).Int;
        my Array[Int] $r-lines = self.extract-routine-lines($file, $target-line);
        my Int $entry-line = ($r-lines && $r-lines.elems > 0) ?? $r-lines[0] !! $target-line;
        return %( :$file, line => $entry-line );
    }

    # Fallback to regex scan over lines
    for @lines.kv -> $idx, $ml {
        if $ml ~~ / [ 'sub' | 'method' ] \s+ $name >> / {
            my Int $target-line = $idx + 1;
            my Array[Int] $r-lines = self.extract-routine-lines($file, $target-line);
            my Int $entry-line = ($r-lines && $r-lines.elems > 0) ?? $r-lines[0] !! $target-line;
            return %( :$file, line => $entry-line );
        }
    }
    return %();
}

method resolve-callee-targets(Str $file, Int $line --> Array) {
    return [] unless $file && $file.IO.e && $file.IO.f;
    my %data = self!get-file-data($file);
    return [] unless %data;
    my @lines = %data<lines>.list;
    return [] unless 0 < $line <= @lines.elems;

    my Str $clean = @lines[$line - 1].subst(/ '#' \N* $/, '')
        .subst(/ '"' <-[\"]>* '"' /, '', :g)
        .subst(/ '\'' <-[\']>* '\'' /, '', :g);

    my @names;
    for $clean.comb(/ <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* <?before \s* '('> /) -> $m {
        @names.push(~$m);
    }
    for $clean.comb(/ <?after '.' \s*> <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* /) -> $m {
        @names.push(~$m);
    }

    my Set $keywords = set <
    if with without unless for given when my our state has sub method return say print note die warn
    >;
    my @candidates = @names.grep({ !($keywords{$_}) });
    return [] unless @candidates;

    my @targets;
    my SetHash $seen-names .= new;
    my $lookup = $!symbol-lookup // $!private-scanner;

    for @candidates -> Str $name {
        next if $seen-names{$name};
        $seen-names.set($name);

        # 1. Search same file
        my %entry = self!find-routine-entry($file, $name);

        # 2. Check SymbolLookup if available
        if !%entry && $lookup.defined {
            my @matches = try $lookup.find-symbol($name) // ();
            if @matches {
                my %m = @matches[0];
                my Str $uri = (%m<uri> // '').Str;
                my Str $f = uri-to-path($uri).Str;
                if $f.IO.e {
                    %entry = self!find-routine-entry($f, $name);
                }
            }
        }

        # 3. Check modules 'use'd by current file
        if !%entry {
            for @lines -> $l-text {
                if $l-text ~~ /^ \s* 'use' \s+ (<[\w\-:]>+) / {
                    my Str $mod = ~$0;
                    next if $mod eq 'v6' || $mod eq 'v6.c' || $mod eq 'v6.d' || $mod eq 'lib';
                    my Str $resolved = resolve-compunit-path($mod, :project-index($lookup), :cwd($file.IO.parent));
                    if $resolved ne '' && $resolved.IO.e {
                        %entry = self!find-routine-entry($resolved, $name);
                        last if %entry;
                    }
                }
            }
        }

        if %entry {
            @targets.push(%(
                    id => @targets.elems + 1,
                    label => $name,
                    file => %entry<file>,
                    line => %entry<line>,
            ));
        }
    }
    return @targets.Array;
}

method resolve-callee-target(Str $file, Int $line, Int :$target-id = 0 --> Hash) {
    my @targets = self.resolve-callee-targets($file, $line);
    return %() unless @targets;
    if $target-id > 0 {
        my $found = @targets.first({ .<id> == $target-id });
        return %( file => $found<file>, line => $found<line> ) if $found;
    }
    return %( file => @targets[0]<file>, line => @targets[0]<line> );
}
