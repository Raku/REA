use v6.d;

#| The adapter's opt-in trace log, reachable from every DAP module, and `attempt` for awaited operations whose
#| failure the adapter tolerates: the failure is written to the trace instead of disappearing (A-15).
unit module Nimala::Raku-DAP::Trace;

my IO::Handle $trace-handle;
my Lock $trace-lock .= new;

#| Opens the trace log when `NIMALA_DAP_TRACE` or $requested asks for it. Returns the reason when the log could not
#| be opened, for the caller to report; an undefined Str otherwise.
our sub init-trace-logging(Bool $requested = False --> Str) {
    my Str $refused;
    $trace-lock.protect: {
        my $env-trace = %*ENV<NIMALA_DAP_TRACE>;
        if !$trace-handle.defined && (($env-trace.defined && $env-trace.Bool && $env-trace ne '0') || $requested) {
            my IO::Path $path = $*TMPDIR.add("nimala-dap-trace-{$*PID}.log");
            # Exclusive create: an existing file or planted symlink is neither followed nor truncated (DX-3).
            # The handle stays open, so a deleted log is never recreated with wider permissions.
            $trace-handle = try $path.open(:x, :!out-buffer);
            if $trace-handle.defined {
                $path.chmod(0o600);
            } else {
                $refused = "Tracing disabled: $path already exists\n";
            }
        }
    }
    $refused;
}

our sub is-tracing(--> Bool) is export {
    $trace-handle.defined;
}

our sub log-trace(Str $msg --> Nil) is export {
    if $trace-handle.defined {
        $trace-lock.protect: {
            try $trace-handle.print($msg ~ "\n");
        }
    }
}

#| Awaits $p (a plain value passes through) and returns its result. A failure is not an error for the caller:
#| the cause is written to the trace as "$what failed: <cause>" and Nil is returned.
our sub attempt($p, Str $what) is export {
    return $p<> unless $p ~~ Awaitable;
    my $result = try await $p;
    # Decontainerized, so `my @x = attempt(...)` takes the list as `my @x = await ...` would
    return $result<> without $!;
    log-trace("$what failed: {$!.message}");
    Nil;
}
