unit module Nimala::Raku-DAP::MessagePack;

use nqp;

class X::MessagePack::Error is Exception {
    has Str $.message;
}

class X::MessagePack::Reserved is X::MessagePack::Error {
    has Int $.byte;
    method message() { "Reserved byte { '0x%02x'.sprintf($!byte) } is not a valid MessagePack format" }
}

class X::MessagePack::UnsupportedFormat is X::MessagePack::Error {
    has Str $.format;
    method message() { "Unsupported MessagePack format: $!format" }
}

class X::MessagePack::UnsupportedType is X::MessagePack::Error {
    has Str $.type-name;
    method message() { "Cannot encode value of type $!type-name in MessagePack" }
}

class X::MessagePack::InvalidKey is X::MessagePack::Error {
    has Any $.key;
    method message() { "Map key must be a string, got { $!key.^name } ({ $!key.raku })" }
}

class X::MessagePack::IntegerOutOfRange is X::MessagePack::Error {
    has Int $.int;
    method message() { "Integer $!int is outside representable MessagePack range -2**63 .. 2**64-1" }
}



#| Resumable byte-length scanner for one MessagePack value that arrives in pieces.
#| It keeps its progress and the open-container counts between calls, so a value split over
#| many reads is scanned once in total instead of once per read (DR-2). Progress is stored
#| relative to the value's start, so the caller may compact its buffer between calls.
class MsgpackScanner is export {
    has int $!rel = -1;  # bytes of the current value already scanned; -1 = no scan in progress
    has int @!open;      # items still expected per open container, innermost last

    method reset(--> Nil) {
        $!rel = -1;
        @!open = Empty;
    }

    #| Byte length of the value starting at $offset once it is complete, 0 while it is not.
    method scan(Blob $buf, Int $offset --> Int) {
        if $!rel < 0 {
            $!rel = 0;
            @!open.push(1);
        }
        my int $end = $buf.bytes;
        my int $pos = $offset + $!rel;
        while @!open.elems {
            return self!pause($pos - $offset) if $pos >= $end;
            my int $tag = nqp::atpos_i($buf, $pos);
            my int $hdr = 1;
            my int $len = 0;
            my int $kids = 0;
            if $tag <= 0x7f || $tag >= 0xe0 || $tag == 0xc0 || $tag == 0xc2 || $tag == 0xc3 {
            }
            elsif $tag >= 0xa0 && $tag <= 0xbf { $len = $tag - 0xa0 }
            elsif $tag >= 0x80 && $tag <= 0x8f { $kids = 2 * ($tag - 0x80) }
            elsif $tag >= 0x90 && $tag <= 0x9f { $kids = $tag - 0x90 }
            elsif $tag == 0xcc || $tag == 0xd0 { $hdr = 2 }
            elsif $tag == 0xcd || $tag == 0xd1 { $hdr = 3 }
            elsif $tag == 0xce || $tag == 0xd2 || $tag == 0xca { $hdr = 5 }
            elsif $tag == 0xcf || $tag == 0xd3 || $tag == 0xcb { $hdr = 9 }
            elsif $tag >= 0xd4 && $tag <= 0xd8 { $hdr = 2; $len = 1 +< ($tag - 0xd4) }
            else {
                # Length-prefixed families; an unknown tag (0xc1) counts as one byte and is refused by decode
                my int $w = $tag == 0xd9 || $tag == 0xc4 || $tag == 0xc7 ?? 1
                !! $tag == 0xda || $tag == 0xc5 || $tag == 0xc8 || $tag == 0xdc || $tag == 0xde ?? 2
                !! $tag == 0xdb || $tag == 0xc6 || $tag == 0xc9 || $tag == 0xdd || $tag == 0xdf ?? 4
                !! 0;
                if $w > 0 {
                    return self!pause($pos - $offset) if $pos + 1 + $w > $end;
                    my int $n = $w == 1 ?? $buf.read-uint8($pos + 1)
                    !! $w == 2 ?? $buf.read-uint16($pos + 1, BigEndian)
                    !! $buf.read-uint32($pos + 1, BigEndian);
                    $hdr = 1 + $w + ($tag == 0xc7 || $tag == 0xc8 || $tag == 0xc9 ?? 1 !! 0);
                    if $tag == 0xdc || $tag == 0xdd { $kids = $n }
                    elsif $tag == 0xde || $tag == 0xdf { $kids = 2 * $n }
                    else { $len = $n }
                }
            }
            return self!pause($pos - $offset) if $pos + $hdr + $len > $end;
            $pos += $hdr + $len;
            my int $top = @!open.elems - 1;
            @!open[$top] = @!open[$top] - 1;
            @!open.push($kids) if $kids > 0;
            @!open.pop while @!open.elems && @!open[@!open.elems - 1] == 0;
        }
        my int $size = $pos - $offset;
        self.reset;
        $size;
    }

    method !pause(int $rel --> Int) {
        $!rel = $rel;
        0;
    }
}

# Raised internally when the buffer ends inside a value; decode reports it as consumed = 0
my class X::MessagePack::Incomplete is Exception { }

sub incomplete() { X::MessagePack::Incomplete.new.throw }

#| UTF-8 string of $len bytes at $from, decoded without allocating an intermediate Blob.
sub utf8-at(Blob $buf, int $from, int $len --> Str) {
    nqp::p6box_s(nqp::decode(nqp::slice(nqp::decont($buf), $from, $from + $len - 1), 'utf8'));
}

#| Decode a single MessagePack value from $buf starting at $offset.
#| Returns a List: ($value, Int $consumed).
#| If $buf does not hold a complete value, returns (Nil, 0).
our sub decode(Blob $buf, Int $offset = 0 --> List) is export {
    return (Nil, 0) if $offset >= $buf.bytes;
    my int $pos = $offset;
    my $value := _decode($buf, $pos, $buf.bytes);
    CATCH {
        when X::MessagePack::Incomplete { return (Nil, 0) }
    }
    ($value, $pos - $offset);
}

# ponytail: Byte dispatch table exempt from 120-line limit for serialization throughput
sub _decode(Blob $buf, int $pos is rw, int $end) {
    incomplete() if $pos >= $end;

    my int $tag = nqp::atpos_i($buf, $pos);

    # Positive fixint: 0x00 .. 0x7f
    if $tag <= 0x7f {
        $pos += 1;
        return $tag;
    }

    # Fixmap: 0x80 .. 0x8f
    if $tag <= 0x8f {
        my int $count = $tag - 0x80;
        $pos += 1;
        return _decode-map($buf, $pos, $count, $end);
    }

    # Fixarray: 0x90 .. 0x9f
    if $tag <= 0x9f {
        my int $count = $tag - 0x90;
        $pos += 1;
        return _decode-array($buf, $pos, $count, $end);
    }

    # Fixstr: 0xa0 .. 0xbf
    if $tag <= 0xbf {
        my int $len = $tag - 0xa0;
        incomplete() if $end - $pos < 1 + $len;
        my Str $str = $len == 0 ?? "" !! utf8-at($buf, $pos + 1, $len);
        $pos += 1 + $len;
        return $str;
    }

    # Negative fixint: 0xe0 .. 0xff (-32 .. -1)
    if $tag >= 0xe0 {
        $pos += 1;
        return $tag - 256;
    }

    # Variable formats 0xc0 .. 0xdf
    if $tag == 0xc0 {
        $pos += 1;
        return Any;
    }
    elsif $tag == 0xc1 {
        X::MessagePack::Reserved.new(byte => 0xc1).throw;
    }
    elsif $tag == 0xc2 {
        $pos += 1;
        return False;
    }
    elsif $tag == 0xc3 {
        $pos += 1;
        return True;
    }
    elsif $tag == 0xc4 { # bin 8
        incomplete() if $end - $pos < 2;
        my int $len = $buf.read-uint8($pos + 1);
        incomplete() if $end - $pos < 2 + $len;
        my Blob $bin = $len == 0 ?? Blob.new !! Blob.new($buf.subbuf($pos + 2, $len));
        $pos += 2 + $len;
        return $bin;
    }
    elsif $tag == 0xc5 { # bin 16
        incomplete() if $end - $pos < 3;
        my int $len = $buf.read-uint16($pos + 1, BigEndian);
        incomplete() if $end - $pos < 3 + $len;
        my Blob $bin = $len == 0 ?? Blob.new !! Blob.new($buf.subbuf($pos + 3, $len));
        $pos += 3 + $len;
        return $bin;
    }
    elsif $tag == 0xc6 { # bin 32
        incomplete() if $end - $pos < 5;
        my int $len = $buf.read-uint32($pos + 1, BigEndian);
        incomplete() if $end - $pos < 5 + $len;
        my Blob $bin = $len == 0 ?? Blob.new !! Blob.new($buf.subbuf($pos + 5, $len));
        $pos += 5 + $len;
        return $bin;
    }
    elsif $tag == 0xc7 { # ext 8
        my Bool $is-ts = False;
        if $end - $pos >= 3 {
            my int $type = $buf.read-int8($pos + 2);
            $is-ts = True if $type == -1;
        }
        X::MessagePack::UnsupportedFormat.new(format => $is-ts ?? "timestamp extension (ext 8)" !! "ext 8").throw;
    }
    elsif $tag == 0xc8 { # ext 16
        X::MessagePack::UnsupportedFormat.new(format => "ext 16").throw;
    }
    elsif $tag == 0xc9 { # ext 32
        X::MessagePack::UnsupportedFormat.new(format => "ext 32").throw;
    }
    elsif $tag == 0xca { # float 32
        incomplete() if $end - $pos < 5;
        my Num $val = $buf.read-num32($pos + 1, BigEndian).Num;
        $pos += 5;
        return $val;
    }
    elsif $tag == 0xcb { # float 64
        incomplete() if $end - $pos < 9;
        my Num $val = $buf.read-num64($pos + 1, BigEndian).Num;
        $pos += 9;
        return $val;
    }
    elsif $tag == 0xcc { # uint 8
        incomplete() if $end - $pos < 2;
        my int $val = $buf.read-uint8($pos + 1);
        $pos += 2;
        return $val;
    }
    elsif $tag == 0xcd { # uint 16
        incomplete() if $end - $pos < 3;
        my int $val = $buf.read-uint16($pos + 1, BigEndian);
        $pos += 3;
        return $val;
    }
    elsif $tag == 0xce { # uint 32
        incomplete() if $end - $pos < 5;
        my int $val = $buf.read-uint32($pos + 1, BigEndian);
        $pos += 5;
        return $val;
    }
    elsif $tag == 0xcf { # uint 64
        incomplete() if $end - $pos < 9;
        my Int $val = $buf.read-uint64($pos + 1, BigEndian);
        $pos += 9;
        return $val;
    }
    elsif $tag == 0xd0 { # int 8
        incomplete() if $end - $pos < 2;
        my int $val = $buf.read-int8($pos + 1);
        $pos += 2;
        return $val;
    }
    elsif $tag == 0xd1 { # int 16
        incomplete() if $end - $pos < 3;
        my int $val = $buf.read-int16($pos + 1, BigEndian);
        $pos += 3;
        return $val;
    }
    elsif $tag == 0xd2 { # int 32
        incomplete() if $end - $pos < 5;
        my int $val = $buf.read-int32($pos + 1, BigEndian);
        $pos += 5;
        return $val;
    }
    elsif $tag == 0xd3 { # int 64
        incomplete() if $end - $pos < 9;
        my Int $val = $buf.read-int64($pos + 1, BigEndian);
        $pos += 9;
        return $val;
    }
    elsif $tag == 0xd4 { # fixext 1
        X::MessagePack::UnsupportedFormat.new(format => "fixext 1").throw;
    }
    elsif $tag == 0xd5 { # fixext 2
        X::MessagePack::UnsupportedFormat.new(format => "fixext 2").throw;
    }
    elsif $tag == 0xd6 { # fixext 4
        my Bool $is-ts = False;
        if $end - $pos >= 2 {
            my int $type = $buf.read-int8($pos + 1);
            $is-ts = True if $type == -1;
        }
        X::MessagePack::UnsupportedFormat.new(format => $is-ts ?? "timestamp extension (fixext 4)" !! "fixext 4").throw;
    }
    elsif $tag == 0xd7 { # fixext 8
        my Bool $is-ts = False;
        if $end - $pos >= 2 {
            my int $type = $buf.read-int8($pos + 1);
            $is-ts = True if $type == -1;
        }
        X::MessagePack::UnsupportedFormat.new(format => $is-ts ?? "timestamp extension (fixext 8)" !! "fixext 8").throw;
    }
    elsif $tag == 0xd8 { # fixext 16
        X::MessagePack::UnsupportedFormat.new(format => "fixext 16").throw;
    }
    elsif $tag == 0xd9 { # str 8
        incomplete() if $end - $pos < 2;
        my int $len = $buf.read-uint8($pos + 1);
        incomplete() if $end - $pos < 2 + $len;
        my Str $str = $len == 0 ?? "" !! utf8-at($buf, $pos + 2, $len);
        $pos += 2 + $len;
        return $str;
    }
    elsif $tag == 0xda { # str 16
        incomplete() if $end - $pos < 3;
        my int $len = $buf.read-uint16($pos + 1, BigEndian);
        incomplete() if $end - $pos < 3 + $len;
        my Str $str = $len == 0 ?? "" !! utf8-at($buf, $pos + 3, $len);
        $pos += 3 + $len;
        return $str;
    }
    elsif $tag == 0xdb { # str 32
        incomplete() if $end - $pos < 5;
        my int $len = $buf.read-uint32($pos + 1, BigEndian);
        incomplete() if $end - $pos < 5 + $len;
        my Str $str = $len == 0 ?? "" !! utf8-at($buf, $pos + 5, $len);
        $pos += 5 + $len;
        return $str;
    }
    elsif $tag == 0xdc { # array 16
        incomplete() if $end - $pos < 3;
        my int $count = $buf.read-uint16($pos + 1, BigEndian);
        $pos += 3;
        return _decode-array($buf, $pos, $count, $end);
    }
    elsif $tag == 0xdd { # array 32
        incomplete() if $end - $pos < 5;
        my int $count = $buf.read-uint32($pos + 1, BigEndian);
        $pos += 5;
        return _decode-array($buf, $pos, $count, $end);
    }
    elsif $tag == 0xde { # map 16
        incomplete() if $end - $pos < 3;
        my int $count = $buf.read-uint16($pos + 1, BigEndian);
        $pos += 3;
        return _decode-map($buf, $pos, $count, $end);
    }
    elsif $tag == 0xdf { # map 32
        incomplete() if $end - $pos < 5;
        my int $count = $buf.read-uint32($pos + 1, BigEndian);
        $pos += 5;
        return _decode-map($buf, $pos, $count, $end);
    }

    # Fallback for any unhandled tag
    X::MessagePack::UnsupportedFormat.new(format => "unknown tag 0x%02x".sprintf($tag)).throw;
}

sub _decode-array(Blob $buf, int $pos is rw, int $count, int $end) {
    my @arr;
    @arr.push(_decode($buf, $pos, $end)) for ^$count;
    @arr;
}

sub _decode-map(Blob $buf, int $pos is rw, int $count, int $end) {
    my %map;
    for ^$count {
        my $key := _decode($buf, $pos, $end);
        %map{$key} = _decode($buf, $pos, $end);
    }
    %map;
}

#| Encode a Raku value to a MessagePack Blob using the smallest format that fits.
our sub encode(Any $value --> Blob) is export {
    my Buf $buf .= new;
    _encode($value, $buf);
    return Blob.new($buf);
}

# ponytail: Byte dispatch table exempt from 120-line limit for serialization throughput
sub _encode(Any $value, Buf $buf --> Nil) {
    # Undefined / Nil
    unless $value.defined {
        $buf.push(0xc0);
        return;
    }

    # Bool
    if $value ~~ Bool {
        $buf.push($value ?? 0xc3 !! 0xc2);
        return;
    }

    # Int
    if $value ~~ Int {
        if $value < -(2**63) || $value > 2**64 - 1 {
            X::MessagePack::IntegerOutOfRange.new(int => $value).throw;
        }

        if $value >= 0 {
            if $value <= 127 {
                $buf.push($value);
            }
            elsif $value <= 255 {
                $buf.push(0xcc, $value);
            }
            elsif $value <= 65535 {
                $buf.push(0xcd);
                my int $p = $buf.bytes;
                $buf.reallocate($p + 2);
                $buf.write-uint16($p, $value, BigEndian);
            }
            elsif $value <= 2**32 - 1 {
                $buf.push(0xce);
                my int $p = $buf.bytes;
                $buf.reallocate($p + 4);
                $buf.write-uint32($p, $value, BigEndian);
            }
            else {
                $buf.push(0xcf);
                my int $p = $buf.bytes;
                $buf.reallocate($p + 8);
                $buf.write-uint64($p, $value, BigEndian);
            }
        }
        else { # negative
            if $value >= -32 {
                $buf.push($value + 256);
            }
            elsif $value >= -128 {
                $buf.push(0xd0);
                my int $p = $buf.bytes;
                $buf.reallocate($p + 1);
                $buf.write-int8($p, $value);
            }
            elsif $value >= -32768 {
                $buf.push(0xd1);
                my int $p = $buf.bytes;
                $buf.reallocate($p + 2);
                $buf.write-int16($p, $value, BigEndian);
            }
            elsif $value >= -(2**31) {
                $buf.push(0xd2);
                my int $p = $buf.bytes;
                $buf.reallocate($p + 4);
                $buf.write-int32($p, $value, BigEndian);
            }
            else {
                $buf.push(0xd3);
                my int $p = $buf.bytes;
                $buf.reallocate($p + 8);
                $buf.write-int64($p, $value, BigEndian);
            }
        }
        return;
    }

    # Floating point numbers (Num, Rat, etc.)
    if $value ~~ Numeric {
        $buf.push(0xcb);
        my int $p = $buf.bytes;
        $buf.reallocate($p + 8);
        $buf.write-num64($p, $value.Num, BigEndian);
        return;
    }

    # Str
    if $value ~~ Str {
        my Blob $bytes = $value.encode('utf-8');
        my int $len = $bytes.bytes;
        if $len <= 31 {
            $buf.push(0xa0 +| $len);
        }
        elsif $len <= 255 {
            $buf.push(0xd9, $len);
        }
        elsif $len <= 65535 {
            $buf.push(0xda);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 2);
            $buf.write-uint16($p, $len, BigEndian);
        }
        else {
            $buf.push(0xdb);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 4);
            $buf.write-uint32($p, $len, BigEndian);
        }
        $buf.append($bytes) if $len > 0;
        return;
    }

    # Blob / Buf
    if $value ~~ Blob {
        my int $len = $value.bytes;
        if $len <= 255 {
            $buf.push(0xc4, $len);
        }
        elsif $len <= 65535 {
            $buf.push(0xc5);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 2);
            $buf.write-uint16($p, $len, BigEndian);
        }
        else {
            $buf.push(0xc6);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 4);
            $buf.write-uint32($p, $len, BigEndian);
        }
        $buf.append($value) if $len > 0;
        return;
    }

    # Map (Associative)
    if $value ~~ Associative {
        # Check all keys are Str first
        for $value.keys -> $k {
            if $k !~~ Str {
                X::MessagePack::InvalidKey.new(key => $k).throw;
            }
        }

        my int $count = $value.elems;
        if $count <= 15 {
            $buf.push(0x80 +| $count);
        }
        elsif $count <= 65535 {
            $buf.push(0xde);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 2);
            $buf.write-uint16($p, $count, BigEndian);
        }
        else {
            $buf.push(0xdf);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 4);
            $buf.write-uint32($p, $count, BigEndian);
        }

        # Encode key-value pairs
        for $value.kv -> $k, $v {
            _encode($k.Str, $buf);
            _encode($v, $buf);
        }
        return;
    }

    # Array (Positional)
    if $value ~~ Positional {
        my int $count = $value.elems;
        if $count <= 15 {
            $buf.push(0x90 +| $count);
        }
        elsif $count <= 65535 {
            $buf.push(0xdc);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 2);
            $buf.write-uint16($p, $count, BigEndian);
        }
        else {
            $buf.push(0xdd);
            my int $p = $buf.bytes;
            $buf.reallocate($p + 4);
            $buf.write-uint32($p, $count, BigEndian);
        }

        for @($value) -> $item {
            _encode($item, $buf);
        }
        return;
    }

    # Unsupported type
    X::MessagePack::UnsupportedType.new(type-name => $value.^name).throw;
}
