use v6.d;

#| Launch configuration parser, validator, and debuggee process arguments builder.
unit class Nimala::Raku-DAP::LaunchConfig;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::MoarVMProbe;

has Str $.program;
has Array $.args;
has Str $.cwd;
has %.env;
has Int $.port;
has Bool $.port-explicit;
has Str $.raku-executable;
has Array $.include-paths;
has Str $.smart-step-mode;
has Bool $.stop-on-entry;
has Bool $.trace;
has Str $.console = 'internalConsole';
has Bool $.no-debug = False;

our constant @CONSOLE-MODES = <internalConsole integratedTerminal externalTerminal>;

our sub is-executable-valid(Str $bin --> Bool) is export {
    return False if $bin eq '';
    if $bin.contains('/') || $bin.contains('\\') {
        if $*DISTRO.is-win {
            my @exts = ('', |(%*ENV<PATHEXT> ?? %*ENV<PATHEXT>.split(';') !! <.exe .cmd .bat>));
            for @exts -> $ext {
                my $p = ($bin ~ $ext).IO;
                return True if $p.f;
            }
            return False;
        } else {
            return ($bin.IO.f && $bin.IO.x).Bool;
        }
    }
    my @exts = $*DISTRO.is-win ?? ('', |(%*ENV<PATHEXT> ?? %*ENV<PATHEXT>.split(';') !! <.exe .cmd .bat>)) !! ('',);
    for $*SPEC.path -> $dir {
        next if $dir eq '';
        for @exts -> $ext {
            my $p = $dir.IO.add($bin ~ $ext);
            if $p.f && ($*DISTRO.is-win || $p.x) {
                return True;
            }
        }
    }
    return False;
}

#| Directory for the materialized helper of an installed distribution: <cache-base>/injected-helper/<version>.
our sub helper-cache-dir(Str $version --> IO::Path) is export {
    return cache-base().add('injected-helper').add($version);
}

#| Writes $source to $dir/Nimala/Raku-DAP/InjectedHelper.rakumod unless identical content is already there.
#| Replaces atomically (temp file + rename); a failed write keeps an existing file.
#| Returns $dir when the helper file exists afterwards, otherwise the IO::Path type object.
our sub materialize-helper(Str $source, IO::Path $dir --> IO::Path) is export {
    my IO::Path $file = $dir.add('Nimala/Raku-DAP/InjectedHelper.rakumod');
    return $dir if (try $file.slurp) eqv $source;
    my IO::Path $tmp = $file.sibling("InjectedHelper.rakumod.$*PID.tmp");
    try {
        $file.parent.mkdir;
        $tmp.spurt($source);
        $tmp.rename($file);
    }
    try $tmp.unlink if $tmp.e;
    return $file.e ?? $dir !! IO::Path;
}

our sub helper-lib-path(--> Str) is export {
    # 1. Source checkout: isolated helper directory in resources/
    my IO::Path $candidate = $?FILE.IO.parent(4).add('resources/injected-helper');
    if $candidate.add('Nimala/Raku-DAP/InjectedHelper.rakumod').e {
        return $candidate.absolute;
    }
    # 2. Installed distribution: resources are stored under hashed names, so copy the helper into the user cache
    # (Distribution::Resources has no EXISTS-KEY, so :exists is always False; slurp decides instead)
    my Str $source = (try %?RESOURCES{'injected-helper/Nimala/Raku-DAP/InjectedHelper.rakumod'}.slurp) // return Str;
    my Str $version = (try $?DISTRIBUTION.meta<version>) // 'dev';
    my IO::Path $dir = materialize-helper($source, helper-cache-dir(~$version));
    return $dir.defined ?? $dir.absolute !! Str;
}

our sub helper-file-path() is export {
    my $lib = helper-lib-path();
    return $lib.defined ?? $lib.IO.add('Nimala/Raku-DAP/InjectedHelper.rakumod').absolute !! Nil;
}

our sub helper-exception-breakpoint-lines() is export {
    my $file = helper-file-path();
    return %( uncaught => 0, all => 0 ) unless $file && $file.IO.e;
    my Int $uncaught = 0;
    my Int $all = 0;
    my Int $line-num = 1;
    for $file.IO.lines -> $line {
        if $line.contains('# nimala-break: uncaught') {
            $uncaught = $line-num;
        } elsif $line.contains('# nimala-break: all') {
            $all = $line-num;
        }
        $line-num++;
    }
    return %( :$uncaught, :$all );
}

#| The debuggee command line. With :no-debug, the debug server flags and the injected helper are left out.
our sub build-debuggee-cmd(:$port!, :$program!, :@args = (), Str :$executable = 'raku', :@include-paths = (),
    Str :$helper-lib = helper-lib-path(), Bool :$no-debug = False --> List) is export {
    my Str $bin = ($executable && $executable.trim.chars > 0) ?? $executable !! 'raku';
    my @cmd = $no-debug ?? ($bin,) !! ($bin, "--debug-port=$port", '--debug-suspend');
    for @include-paths -> $inc {
        if $inc && $inc.trim.chars > 0 {
            @cmd.push("-I$inc");
        }
    }
    # -I and -M go together: without the helper directory the debuggee could not load the module
    if $helper-lib.defined && !$no-debug {
        @cmd.push("-I$helper-lib");
        @cmd.push('-MNimala::Raku-DAP::InjectedHelper');
    }
    @cmd.push($program);
    @cmd.append(@args);
    return @cmd;
}

#| Parses and validates launch arguments, returning %( ok => True, config => $cfg ) or %( ok => False, error => $msg ).
method from-args(
    %args,
    Str :$workspace-root = "",
    :@exception-filters = ['uncaught'],
    :&warn-callback = sub (Str $) {}
    --> Hash
) {
    my Str $program = (%args<program> // '').Str.trim;
    my Any @prog-args = (%args<args> // []).list;
    my Str $raw-cwd = (%args<cwd> // "").Str;
    my Str $cwd = "";
    my Bool $stop-on-entry = (%args<stopOnEntry> // False).Bool;
    my Bool $trace = (%args<trace> // False).Bool;
    my $explicit-port = %args<debugPort> // %args<port>;
    my Str $executable = (%args<executable> // %args<rakuPath> // %args<executablePath> // 'raku').Str.trim;
    $executable = 'raku' if $executable eq '';
    my @include-paths = (%args<includePaths> // []).List;
    my Str $smart-step-mode = (%args<smartStepMode> // 'into').Str;
    my Str $console = (%args<console> // 'internalConsole').Str;
    my Bool $no-debug = (%args<noDebug> // False).Bool;
    if $console ∉ @CONSOLE-MODES {
        return %( ok => False, error => "Unsupported console '$console'; expected one of {@CONSOLE-MODES.join(', ')}" );
    }
    if $smart-step-mode ne 'into' && $smart-step-mode ne 'over' && $smart-step-mode ne 'disable' {
        &warn-callback("Warning: unrecognised smartStepMode '$smart-step-mode', falling back to 'into'\n");
        $smart-step-mode = 'into';
    }

    if $program eq '' {
        return %( ok => False, error => "Program not found: " );
    }

    if $raw-cwd ne "" {
        unless $raw-cwd.IO.e && $raw-cwd.IO.d {
            return %( ok => False, error => "Working directory does not exist: $raw-cwd" );
        }
        $cwd = $raw-cwd.IO.absolute;
    } else {
        my $candidate-cwd;
        my $test-path = $program.IO.is-absolute ?? $program.IO !! $*CWD.add($program);
        if $test-path.e {
            my $dir = $test-path.parent;
            while $dir.parent && $dir.parent ne $dir {
                if $dir.add('META6.json').e || $dir.add('.git').d {
                    $candidate-cwd = $dir.absolute;
                    last;
                }
                $dir = $dir.parent;
            }
            $cwd = $candidate-cwd // $test-path.parent.absolute;
        } else {
            $cwd = ($workspace-root ne "" && $workspace-root.IO.d) ?? $workspace-root.IO.absolute !! $*CWD.absolute;
        }
    }

    my IO::Path $prog-path = $program.IO.is-absolute ?? $program.IO !! $cwd.IO.add($program);
    unless $prog-path.e && $prog-path.f {
        return %( ok => False, error => "Program not found: $program" );
    }
    $program = $prog-path.absolute;

    my Int $port;
    my Int $req-port = try { $explicit-port.defined ?? $explicit-port.Int !! 0 } // 0;
    my Bool $port-explicit = $req-port > 0;
    if $port-explicit {
        $port = $req-port;
        my $test-sock = try IO::Socket::INET.new(:listen, localhost => '127.0.0.1', localport => $port);
        if !$test-sock {
            return %( ok => False, error => "Port $port is already in use" );
        }
        $test-sock.close;
    } else {
        $port = free-loopback-port();
    }

    if !is-executable-valid($executable) {
        return %( ok => False, error => "Debuggee executable not found or not executable: $executable" );
    }

    my %env = %*ENV;
    %env<RAKUDO_LINE_BUFFERED> = '1';
    # Strip relative test-runner RAKULIB/PERL6LIB=. inherited by the adapter process
    %env<RAKULIB>:delete if (%env<RAKULIB> // '') eq '.';
    %env<PERL6LIB>:delete if (%env<PERL6LIB> // '') eq '.';
    my @active-exc-filters = @exception-filters.elems > 0 ?? @exception-filters.list !! ['uncaught'];
    if ('uncaught' (elem) @active-exc-filters) || ('all' (elem) @active-exc-filters) {
        %env<RAKU_EXCEPTIONS_HANDLER> = 'Nimala';
    }
    if %args<env>.defined && %args<env> ~~ Hash {
        for %args<env>.kv -> Str $k, Any $v {
            if $v.defined {
                %env{$k} = $v.Str;
            } else {
                %env{$k}:delete;
            }
        }
    }

    my $config = self.bless(
        :$program,
        args => @prog-args.Array,
        :$cwd,
        :%env,
        :$port,
        :$port-explicit,
        raku-executable => $executable,
        include-paths => @include-paths.Array,
        :$smart-step-mode,
        :$stop-on-entry,
        :$trace,
        :$console,
        :$no-debug
    );

    return %( ok => True, :$config );
}

#| The debuggee command line for this configuration.
method debuggee-cmd(Int :$override-port --> List) {
    my Int $port = $override-port // $!port;
    return build-debuggee-cmd(
        :$port,
        program => $!program,
        args => $!args.list,
        executable => $!raku-executable,
        include-paths => $!include-paths.list,
        no-debug => $!no-debug
    );
}

