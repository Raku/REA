use v6.d;
unit module Nimala::Raku-DAP::MoarVMProbe;

use JSON::Fast;
use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Trace;

#| Per-user Nimala cache directory: $XDG_CACHE_HOME/nimala, else $HOME/.cache/nimala.
our sub cache-base(--> IO::Path) is export {
    my IO::Path $base = %*ENV<XDG_CACHE_HOME>
    ?? %*ENV<XDG_CACHE_HOME>.IO
    !! ($*HOME // $*TMPDIR).add('.cache');
    return $base.add('nimala');
}

our sub default-cache-path(--> IO::Path) is export {
    return cache-base().add('moarvm-features.json');
}

our sub get-vm-key(Str $raku-executable = $*EXECUTABLE.absolute --> Str) is export {
    my IO::Path $path = $raku-executable.IO;
    if !$path.is-absolute && !$raku-executable.contains('/') {
        for (%*ENV<PATH> // '').split(':') -> $dir {
            next unless $dir;
            my $cand = $dir.IO.add($raku-executable);
            if $cand.e && $cand.f {
                $path = $cand;
                last;
            }
        }
    }

    my IO::Path $resolved = (try $path.resolve) // $path;
    if $resolved.basename eq 'rakubrew' {
        # A shell version (`rakubrew shell`, RAKUBREW_VERSION) takes precedence over the global one (CURRENT).
        my IO::Path $current = $resolved.parent.parent.add('CURRENT');
        my Str $v = %*ENV<RAKUBREW_VERSION> || ($current.e ?? $current.slurp.trim !! '');
        if $v {
            my IO::Path $v-bin = $resolved.parent.parent.add('versions').add($v).add('bin').add('rakudo');
            $resolved = (try $v-bin.resolve) // $v-bin if $v-bin.e;
        }
    }

    my IO::Path $cur-resolved = (try $*EXECUTABLE.resolve) // $*EXECUTABLE;
    if $resolved.absolute eq $cur-resolved.absolute || $raku-executable eq $*EXECUTABLE.absolute {
        return "{$*VM.name}-{$*VM.version}-{$*RAKU.compiler.version}";
    }

    my $mtime = (try $resolved.modified.Int) // 0;
    return "{$resolved.absolute}-{$mtime}";
}

our sub read-cached-result(Str $vm-key, IO::Path $cache-file = default-cache-path() --> Any) is export {
    if $cache-file.e {
        try {
            my %data = from-json($cache-file.slurp);
            if %data{$vm-key}:exists && %data{$vm-key}<line_drift_bug>.defined {
                return %data{$vm-key}<line_drift_bug>.Bool;
            }
        }
    }
    return Nil;
}

our sub write-cached-result(Str $vm-key, Bool $has-drift, IO::Path $cache-file = default-cache-path() --> Nil) is export {
    try {
        $cache-file.parent.mkdir;
        my %data;
        if $cache-file.e {
            try { %data = from-json($cache-file.slurp); }
        }
        %data{$vm-key} = %(
            line_drift_bug => $has-drift,
            probed_at      => ~DateTime.now
        );
        $cache-file.spurt(to-json(%data, :sorted-keys));
    }
}

#| True when the VM drifts, False when it does not, and an undefined Bool when the probe could not complete
#| (connect, breakpoint or step failed); a failed probe says nothing about the VM and must not be cached (B-9).
our sub probe-line-drift(Str $raku-executable = $*EXECUTABLE.absolute, Real :$timeout = 10 --> Bool) is export {
    my IO::Path $target = $*TMPDIR.add("nimala-probe-$*PID-{(1..100000).pick}.raku");
    $target.spurt(q:to/TARGET/);
    my $x = 0;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    $x = $x + 1;
    say $x;
    TARGET
    LEAVE { try $target.unlink }

    my Int $port = free-loopback-port();
    my Proc::Async $proc .= new($raku-executable,
        "--debug-port=$port",
        '--debug-suspend',
        $target.absolute);
    $proc.stdout.tap(-> $ { });
    $proc.stderr.tap(-> $ { });
    my $proc-p = $proc.start;
    LEAVE { try $proc.kill }

    my $proto = Nimala::Raku-DAP::Protocol.new;

    my $connected = attempt($proto.connect('127.0.0.1', $port, :timeout($timeout)), 'connect');
    unless $connected {
        return Bool;
    }

    my Lock $ev-lock .= new;
    my Int $expected-type = 0;
    my Promise $expected-promise;

    $proto.events.tap(-> %ev {
            $ev-lock.protect: {
                if $expected-type && (%ev<type> // 0) == $expected-type {
                    my $p = $expected-promise;
                    $expected-type = 0;
                    $expected-promise = Nil;
                    # A Promise is False in boolean context until it is resolved, so test its status (M-11)
                    $p.keep(%ev) if $p.defined && $p.status ~~ Planned;
                }
            }
    });

    # Set breakpoint at line 5
    my $bp-res = attempt($proto.send-request(msg-breakpoint-set(
                $target.absolute,
                5,
                :suspend(True),
                :stacktrace(False)
        )), 'breakpoint set');
    unless $bp-res && $bp-res<id>.defined {
        $proto.close;
        return Bool;
    }

    # Arm for breakpoint hit (type 17), then resume to line 5
    my $hit-p;
    $ev-lock.protect: {
        $expected-type = MoarMsg::BreakpointHit.value;
        $expected-promise = $hit-p = Promise.new;
    }
    attempt($proto.send-request(msg-resume-all()), 'resume all');

    # Wait for line 5 breakpoint hit
    await Promise.anyof($hit-p, Promise.in($timeout));
    unless $hit-p.status ~~ Kept {
        $proto.close;
        return Bool;
    }
    attempt($proto.send-request(msg-suspend-all()), 'suspend all');

    # Execute 3 native Step Over (21)
    # Expected after 3 steps from line 5: line 8
    # Single-threaded probe target: thread ID is always 1.
    my Int $reported-line = 0;
    for 1..3 -> $step {
        my $step-p;
        $ev-lock.protect: {
            $expected-type = MoarMsg::StepCompleted.value;
            $expected-promise = $step-p = Promise.new;
        }
        attempt($proto.send-request(msg-step-over(1)), 'step over');
        await Promise.anyof($step-p, Promise.in(3));
        unless $step-p.status ~~ Kept {
            $proto.close;
            return Bool;
        }
        my %ev = $step-p.result;
        my @frames = (%ev<frames> // []).list;
        if @frames.elems > 0 {
            $reported-line = (@frames[0]<line> // 0).Int;
        }
    }

    attempt($proto.send-request(msg-resume-all()), 'resume all');
    $proto.close;

    # If line drifts, reported line will be > 8 (e.g. 9 or 10)
    return $reported-line > 8;
}

our sub has-line-drift-bug(
    Str :$raku-executable = $*EXECUTABLE.absolute,
    IO::Path :$cache-file = default-cache-path(),
    Bool :$force-probe = False
    --> Bool
) is export {
    my Str $vm-key = get-vm-key($raku-executable);
    unless $force-probe {
        my $cached = read-cached-result($vm-key, $cache-file);
        if $cached.defined {
            return $cached;
        }
    }

    my Bool $has-drift = probe-line-drift($raku-executable);
    # A failed probe: use the safe sweep stepping for this session and probe again next time (B-9)
    return True unless $has-drift.defined;
    write-cached-result($vm-key, $has-drift, $cache-file);
    return $has-drift;
}
