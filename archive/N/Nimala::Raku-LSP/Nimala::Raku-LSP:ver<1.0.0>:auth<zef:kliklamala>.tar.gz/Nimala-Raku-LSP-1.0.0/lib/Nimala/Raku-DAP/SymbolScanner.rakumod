use v6.d;
use Nimala::Model::SymbolLookup;
use Nimala::URI;
use Nimala::Raku-LSP::Cache;

our constant SYM-ROUTINE is export = 12;
our constant SYM-METHOD is export = 6;

#| Lightweight standalone regex-based symbol scanner for DAP function breakpoints.
unit class Nimala::Raku-DAP::SymbolScanner does Nimala::Model::SymbolLookup;

has %!file-symbols;
has %!name-symbols;
has %!file-mtimes;
has SetHash $!scanned-terms .= new;
has Lock $!lock .= new;
has Str $.workspace-root = '';

submethod TWEAK(:$workspace-root) {
    $!workspace-root = $workspace-root if $workspace-root.defined;
}

#| Update symbol index for a specific file URI and its source code.
method update-file(Str $uri, Str $content --> Nil) {
    my @lines = $content.split(/\r\n|\r|\n/);
    my @syms;

    for @lines.kv -> $line-num, $line {
        if $line ~~ /^^ \s* [ [ 'my' | 'our' | 'multi' | 'proto' | 'only' ] \s+ ]*
        $<decl>=[ 'sub' | 'method' | 'submethod' | 'regex' | 'token' | 'rule' ] \s+
        $<name>=[ <[\w\-\!\^]>+ ]/ {
            my Str $name = ~$<name>;
            my Str $decl = ~$<decl>;
            my Int $kind = ($decl eq 'method' || $decl eq 'submethod') ?? SYM-METHOD !! SYM-ROUTINE;
            my Int $col = $<name>.from;
            my Int $line-len = $line.chars;

            # Find matching closing brace to determine routine extent
            my Int $end-line = $line-num;
            my Int $end-col  = $line-len;
            my Int $brace-depth = 0;
            my Bool $found-open = False;

            for $line-num..^@lines.elems -> $l {
                my Str $cur = @lines[$l];
                # Stop looking for opening brace if we run into another declaration
                if !$found-open && $l > $line-num
                && $cur ~~ /^^ \s* [ [ 'my' | 'our' | 'multi' | 'proto' | 'only' ] \s+ ]* [ 'sub' | 'method' | 'submethod' | 'regex' | 'token' | 'rule' ] \s+/ {
                    last;
                }
                for $cur.match(/ <[{ }]> /, :g) -> $m {
                    if ~$m eq '{' {
                        $brace-depth++;
                        $found-open = True;
                    } elsif ~$m eq '}' && $brace-depth > 0 {
                        $brace-depth--;
                        if $brace-depth == 0 {
                            $end-line = $l;
                            $end-col  = $m.to;
                            last;
                        }
                    }
                }
                last if $found-open && $brace-depth == 0;
            }

            my %range = %(
                start => %( line => $line-num, character => $col ),
                end   => %( line => $end-line, character => $end-col )
            );

            my %sym = %(
                name          => $name,
                kind          => $kind,
                containerName => "",
                detail        => $line.trim,
                uri           => $uri,
                location      => %(
                    uri   => $uri,
                    range => %range
                ),
                range         => %range,
                selectionRange => %range
            );
            @syms.push(%sym);
        }
    }

    $!lock.protect: {
        # Clean up old symbols for this uri from name index
        if %!file-symbols{$uri}:exists {
            for %!file-symbols{$uri}.list -> %old-sym {
                my Str $old-name = %old-sym<name>;
                if %!name-symbols{$old-name}:exists {
                    %!name-symbols{$old-name} = %!name-symbols{$old-name}.grep({ ($_<uri> // '') ne $uri }).Array;
                    %!name-symbols{$old-name}:delete if !%!name-symbols{$old-name}.elems;
                }
            }
        }

        %!file-symbols{$uri} = @syms;
        for @syms -> %sym {
            my Str $name = %sym<name>;
            %!name-symbols{$name} //= Array.new;
            %!name-symbols{$name}.push(%sym);
        }
        $!scanned-terms = SetHash.new;
    }
}

#| Find all symbols matching a given name.
method find-symbol(Str $name, Str $current-namespace = "" --> Positional) {
    $!lock.protect: {
        return (%!name-symbols{$name} // []).List;
    }
}

#| Find symbols enclosing a given location in a file.
method find-enclosing-symbols(Str $uri, Int $line, Int $col --> Positional) {
    $!lock.protect: {
        my @syms = (%!file-symbols{$uri} // []).list;
        my @enclosing = @syms.grep({
                my Int $s-line = ($_<range><start><line> // 0).Int;
                my Int $e-line = ($_<range><end><line> // $s-line).Int;
                $s-line <= $line <= $e-line
        });
        return @enclosing.List;
    }
}

#| Return all indexed symbols mapped by file URI.
method all-files-symbols(--> Hash) {
    $!lock.protect: {
        return %!file-symbols.clone;
    }
}

#| Scan a directory tree on disk for routine definitions matching a search term or all files.
method scan-directory(IO::Path $dir, Str $search-term = '' --> Nil) {
    return unless $dir.d;
    my Str $canon-dir = (try $dir.resolve.absolute) // $dir.absolute;
    my Str $scan-key = "{$canon-dir}\0{$search-term}";

    $!lock.protect: {
        return if $search-term ne '' && $!scanned-terms{$scan-key};
    }

    my IO::Path @stack = $dir;
    my $excl-any = any(@EXCLUDED-DIRS);
    my $ext-any  = any(@SOURCE-EXTENSIONS);
    my SetHash $visited-dirs .= new;

    while @stack {
        my IO::Path $curr = @stack.pop;
        if $curr.d {
            next if $curr.basename eq $excl-any;
            next if $curr.l && $curr.absolute ne $dir.absolute;
            my Str $canon = try { $curr.resolve.absolute } // "";
            if $canon ne "" {
                next if $visited-dirs{$canon};
                $visited-dirs.set($canon);
            }
            try {
                @stack.append: $curr.dir;
                CATCH { default { } }
            }
        } elsif $curr.f && $curr.extension && $curr.extension eq $ext-any {
            my Str $canon = (try $curr.resolve.absolute) // $curr.absolute;
            my $mtime = try $curr.modified;

            my Bool $cached-mtime = False;
            $!lock.protect: {
                if %!file-mtimes{$canon}:exists && %!file-mtimes{$canon} == $mtime {
                    $cached-mtime = True;
                }
            }

            if $cached-mtime {
                next;
            }

            my Str $content = try { $curr.slurp } // "";
            $!lock.protect: {
                %!file-mtimes{$canon} = $mtime;
            }

            if $search-term eq '' || $content.contains($search-term) {
                my Str $uri = path-to-uri($canon);
                self.update-file($uri, $content);
            }
        }
    }

    if $search-term ne '' {
        my Bool $found;
        $!lock.protect: {
            $found = (%!name-symbols{$search-term} // []).elems > 0;
            unless $found {
                $!scanned-terms.set($scan-key);
            }
        }
    }
}
