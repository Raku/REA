use v6.d;

#| Owner of the debuggee's operating-system process: start, identity, exit code and termination.
#| `Session` talks only to this role; how the process was started is the implementing class's business.
unit module Nimala::Raku-DAP::DebuggeeProcess;

use NativeCall;

sub native-kill(int32, int32 --> int32) is native is symbol('kill') {*}

#| Sends $signal to an arbitrary process; True when it was delivered.
#| `Proc::Async.kill` silently drops every signal after the first one sent to the same process (Rakudo 2026.09),
#| so a SIGTERM followed by SIGKILL never escalates; kill(2) has no such limit.
#| ponytail: POSIX only; on Windows the caller falls back to `Proc::Async.kill` (one signal per process).
our sub posix-kill(Int $pid, Signal $signal --> Bool) is export {
    return False if $pid <= 0 || $*DISTRO.is-win;
    return ((try native-kill($pid, $signal.Int)) // -1) == 0;
}

#| Maps a finished `Proc` to an exit code: 128 + signal number, else the exit code.
our sub proc-exit-code($proc --> Int) is export {
    return 0 without $proc;
    my Int $sig = (try $proc.signal.Int) // 0;
    return $sig > 0 ?? 128 + $sig !! ((try $proc.exitcode.Int) // 0);
}

#| Source of the terminal-mode launcher, run as `raku -e LAUNCHER <statefile> -- <debuggee command>`.
#| It starts the debuggee with the terminal's stdio, appends `pid <n>` to the statefile at once and `exit <code>`
#| at the end, ignores SIGINT itself (Ctrl+C reaches the whole foreground group, so the child gets it directly),
#| forwards SIGTERM/SIGHUP to the child, and exits with the child's code.
our constant LAUNCHER = q:to/LAUNCHER/;
    my ($state, $, *@cmd) = @*ARGS;
    my $fh = $state.IO.open(:a);
    my $child = Proc::Async.new(|@cmd);
    try signal(SIGINT).tap(-> $ { });
    for SIGTERM, SIGHUP -> $sig { try signal($sig).tap({ $child.kill($sig) }) }
    my $done = $child.start;
    $fh.say("pid {await $child.pid}");
    $fh.flush;
    my $r = try await $done;    # try-await: ok (runs in the terminal, without the adapter's Trace)
    my $code = $r.defined ?? ($r.signal ?? 128 + $r.signal !! $r.exitcode) !! 1;
    $fh.say("exit $code");
    $fh.close;
    exit $code;
    LAUNCHER

#| The command a terminal runs: the launcher wrapping @debuggee-cmd.
our sub launcher-cmd(Str $raku, Str $statefile, @debuggee-cmd --> List) is export {
    ($raku, '-e', LAUNCHER, $statefile, '--', |@debuggee-cmd).List;
}

role Nimala::Raku-DAP::Debuggee is export {

    #| Starts the process. The returned Promise is kept with the PID once it is known and broken when starting fails.
    method start(--> Promise) { ... }

    #| The PID, or 0 while it is not known yet.
    method pid(--> Int) { ... }

    #| Kept with the exit code once the process has ended (128 + signal number when a signal ended it).
    method exited(--> Promise) { ... }

    #| Sends `$signal` to the process; a no-op once it has exited.
    method signal(Signal $signal --> Nil) { ... }

    #| True while the process has not exited.
    method is-running(--> Bool) { self.exited.status ~~ Planned }

    #| SIGTERM, then SIGKILL when the process has not exited within $grace seconds. Returns at once.
    method terminate(Real :$grace = 2.0 --> Nil) {
        return unless self.is-running;
        self.signal(SIGTERM);
        my Promise $exited = self.exited;
        start {
            await Promise.anyof($exited, Promise.in($grace));
            self.signal(SIGKILL) if $exited.status ~~ Planned;
        };
    }

    #| SIGKILL; idempotent.
    method kill(--> Nil) {
        self.signal(SIGKILL) if self.is-running;
    }

    #| Whether `detach` can leave the process running after the adapter is gone.
    method can-detach(--> Bool) { False }

    #| Marks the process as detached, so no termination path ends it any more.
    method detach(--> Nil) { }

    #| True after `detach`.
    method detached(--> Bool) { False }
}

#| A debuggee the adapter spawns itself. Its stdout and stderr are decoded (with `utf8-c8` fallback) and handed to
#| the callbacks.
class Nimala::Raku-DAP::OwnedProcess does Nimala::Raku-DAP::Debuggee is export {
    has @.cmd is required;
    has %.env;
    has Str $.cwd;
    has &.on-stdout = sub (Str $) {};
    has &.on-stderr = sub (Str $) {};
    has Proc::Async $!proc;
    has Promise $!exited .= new;
    has $!exited-vow;

    submethod TWEAK() { $!exited-vow = $!exited.vow }

    method start(--> Promise) {
        $!proc = Proc::Async.new(|@!cmd);
        # The adapter's stdin is the DAP channel; the debuggee must never read from it (D-11).
        $!proc.bind-stdin($*SPEC.devnull.IO.open);
        $!proc.stdout(:bin).tap(-> Blob $blob { &!on-stdout(decode-output($blob)) }, quit => -> $ {});
        $!proc.stderr(:bin).tap(-> Blob $blob { &!on-stderr(decode-output($blob)) }, quit => -> $ {});
        my %opts = cwd => $!cwd // $*CWD.absolute;
        %opts<ENV> = %!env if %!env;
        my Promise $done = $!proc.start(|%opts);
        $done.then(-> $p { $!exited-vow.keep($p.status ~~ Kept ?? proc-exit-code($p.result) !! 0) });
        return $!proc.pid;
    }

    method pid(--> Int) {
        return 0 unless $!proc.defined && $!proc.pid.status ~~ Kept;
        return $!proc.pid.result.Int;
    }

    method exited(--> Promise) { $!exited }

    method signal(Signal $signal --> Nil) {
        return unless $!proc.defined && self.is-running;
        try $!proc.kill($signal) unless posix-kill(self.pid, $signal);
    }
}

sub decode-output(Blob $blob --> Str) {
    (try $blob.decode('utf-8')) // $blob.decode('utf8-c8');
}

#| True while a process with this PID exists (kill(2) with signal 0).
sub pid-alive(Int $pid --> Bool) {
    return False if $pid <= 0 || $*DISTRO.is-win;
    return ((try native-kill($pid, 0)) // -1) == 0;
}

#| A debuggee the client starts in its terminal through the `runInTerminal` reverse request. The terminal runs the
#| launcher, which reports the debuggee's PID and exit code through a private statefile.
class Nimala::Raku-DAP::TerminalProcess does Nimala::Raku-DAP::Debuggee is export {
    has @.cmd is required;
    has Str $.raku is required;
    has %.env;
    has Str $.cwd;
    has Str $.kind = 'integrated';
    has Str $.title = 'Raku';
    has &.send-reverse-request is required;
    has Real $.timeout = 10;
    has Real $.poll = 0.1;
    has &.on-note = sub (Str $) {};
    has IO::Path $!state;
    has Int $!pid = 0;
    has Bool $!detached = False;
    has Promise $!exited .= new;
    has $!exited-vow;

    submethod TWEAK() { $!exited-vow = $!exited.vow }

    #| Kept with the debuggee's PID once the launcher reported it; broken when the client refuses the terminal or the
    #| launcher does not report within the timeout.
    method start(--> Promise) {
        $!state = new-statefile();
        start {
            CATCH { default { self!finish(1); .rethrow } }
            my %resp = await &!send-reverse-request('runInTerminal', %(
                    kind  => $!kind,
                    title => $!title,
                    cwd   => $!cwd // $*CWD.absolute,
                    args  => launcher-cmd($!raku, $!state.absolute, @!cmd).Array,
                    env   => self!env-delta,
                    argsCanBeInterpretedByShell => False,
                ), timeout => $!timeout);
            die "runInTerminal failed: {%resp<message> // 'no reason given'}" unless %resp<success>;
            my Instant $deadline = now + $!timeout;
            until $!pid > 0 || now > $deadline {
                $!pid = self!read-state<pid> // 0;
                sleep $!poll unless $!pid;
            }
            die "The terminal did not start the debuggee within {$!timeout}s" unless $!pid;
            self!watch-exit;
            $!pid;
        }
    }

    method pid(--> Int) { $!pid }

    method exited(--> Promise) { $!exited }

    method signal(Signal $signal --> Nil) {
        posix-kill($!pid, $signal) if $!pid > 0 && !$!detached && self.is-running;
    }

    method can-detach(--> Bool) { True }

    method detach(--> Nil) { $!detached = True }

    method detached(--> Bool) { $!detached }

    #| Only the variables that differ from the adapter's own environment; the terminal supplies the rest.
    method !env-delta(--> Hash) {
        %!env.grep({ (%*ENV{.key} // '') ne .value }).Hash;
    }

    method !read-state(--> Hash) {
        my %s;
        for ((try $!state.lines) // ()) -> $line {
            %s{$0.Str} = +$1 if $line ~~ / ^ (pid|exit) ' ' (\d+) $ /;
        }
        %s;
    }

    #| Polls the statefile for the `exit` line. When the debuggee is gone and the launcher never wrote one (for
    #| example because it was killed), the exit code is 1 and a console note says why.
    method !watch-exit(--> Nil) {
        start {
            my Int $missing = 0;
            until $!exited.status !~~ Planned || $!detached {
                my %s = self!read-state;
                if %s<exit>:exists {
                    self!finish(%s<exit>);
                } elsif !pid-alive($!pid) && ++$missing > 10 {
                    &!on-note("The terminal debuggee (PID $!pid) ended without reporting an exit code.\n");
                    self!finish(1);
                } else {
                    sleep $!poll;
                }
            }
        };
    }

    method !finish(Int $code --> Nil) {
        try $!state.unlink if $!state.defined;
        try $!exited-vow.keep($code) if $!exited.status ~~ Planned;
    }
}

my atomicint $statefile-count = 0;
my IO::Path @statefiles;
my Lock $statefiles-lock .= new;

# The adapter may end before a watcher saw the `exit` line; a launcher still holding the file open keeps writing to
# the unlinked inode, which is harmless.
END { $statefiles-lock.protect: { try .unlink for @statefiles } }

#| An empty statefile only this user can read and write; removed when the adapter exits at the latest.
sub new-statefile(--> IO::Path) {
    my IO::Path $f = $*TMPDIR.add("nimala-dap-state-{$*PID}-{++⚛$statefile-count}");
    my $fh = $f.open(:x);
    $fh.close;
    $f.chmod(0o600);
    $statefiles-lock.protect: { @statefiles.push($f) };
    $f;
}
