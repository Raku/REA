use v6.d;
unit class Nimala::Raku-DAP::Handles;

class X::Handles::BaseError is Exception is export {
    has Str $.message;
}

class X::Handles::StaleReference is X::Handles::BaseError is export {
    has Int $.reference;
    method message() { "Stale or unknown variablesReference: $!reference" }
}

class X::Handles::InvalidFrame is X::Handles::BaseError is export {
    has Int $.frame-id;
    method message() { "Unknown or invalid frameId: $!frame-id" }
}

has Lock $!lock = Lock.new;
has Int $!next-ref = 1000;
has Int $!next-frame-id = 1;

has %!var-refs;      # ref-id => %info
has %!frame-ids;     # frame-id => %info
has SetHash $!moar-handles = SetHash.new;
has SetHash $!pinned-handles = SetHash.new;
has %!replies;       # request key => Promise of its reply, valid for the current stop
has Int $!stop-gen = 1;
has Bool $!invoke-spent = False;
has %!invoke-results; # key => %res

# Record a raw MoarVM handle to be released on resume
method record-handle(Int $handle --> Nil) {
    if $handle.defined && $handle > 0 {
        $!lock.protect: {
            $!moar-handles.set($handle) unless $!pinned-handles{$handle};
        }
    }
}

# Pin a handle (e.g. injected helper routine) so it survives stops for the lifetime of the connection
method pin(Int:D $handle --> Nil) {
    if $handle > 0 {
        $!lock.protect: {
            $!pinned-handles.set($handle);
            $!moar-handles.unset($handle);
        }
    }
}

# Atomically spends the one-Invoke budget for this stop and returns the stop generation (or 0 if already spent)
method spend-invoke(--> Int) {
    $!lock.protect: {
        return 0 if $!invoke-spent;
        $!invoke-spent = True;
        $!stop-gen;
    }
}

# Checks whether the one-Invoke budget has already been spent in the current stop
method invoke-spent(--> Bool) {
    $!lock.protect: {
        $!invoke-spent;
    }
}

# Retrieves a cached Invoke result for the current stop
method invoke-result(Str:D $key --> Hash) {
    $!lock.protect: {
        %!invoke-results{$key} // Hash;
    }
}

# Stores an Invoke result for the current stop; ignored if $gen != $!stop-gen (stale result)
method remember-invoke-result(Int:D $gen, Str:D $key, %res --> Nil) {
    $!lock.protect: {
        if $gen == $!stop-gen {
            %!invoke-results{$key} = %res;
        }
    }
}

# Allocate a frame ID for stack trace reporting
method allocate-frame(
    Int $thread, Int $frame-index, Int $context-handle = -1, Str :$file = '', Int :$line = 0
    --> Int
) {
    $!lock.protect: {
        my $id = $!next-frame-id++;
        %!frame-ids{$id} = {
            thread => $thread,
            frame-index => $frame-index,
            context-handle => $context-handle,
            file => $file,
            line => $line,
        };
        if $context-handle > 0 {
            $!moar-handles.set($context-handle);
        }
        return $id;
    }
}

# Allocate a variablesReference for a frame context / scope
method allocate-context-ref(Int $thread, Int $frame-index, Int $context-handle --> Int) {
    $!lock.protect: {
        my $ref = $!next-ref++;
        %!var-refs{$ref} = {
            kind => 'context',
            thread => $thread,
            frame-index => $frame-index,
            handle => $context-handle
        };
        if $context-handle > 0 {
            $!moar-handles.set($context-handle);
        }
        return $ref;
    }
}

# Allocate a variablesReference for an object handle
method allocate-object-ref(
    Int $object-handle, Str :$type = '', Str :$kind = '', Int :$thread = 1, Str :$evaluate-name = ''
    --> Int
) {
    $!lock.protect: {
        my $ref = $!next-ref++;
        %!var-refs{$ref} = {
            kind => 'object',
            handle => $object-handle,
            type => $type,
            object-kind => $kind,
            thread => $thread,
            evaluate-name => $evaluate-name
        };
        if $object-handle > 0 {
            $!moar-handles.set($object-handle);
        }
        return $ref;
    }
}

# Look up evaluate-name by variablesReference
method get-evaluate-name(Int $ref --> Str) {
    $!lock.protect: {
        if %!var-refs{$ref}:exists {
            return (%!var-refs{$ref}<evaluate-name> // '').Str;
        }
    }
    '';
}

# Look up frame details by frame ID
method resolve-frame(Int $frame-id --> Hash) {
    $!lock.protect: {
        if %!frame-ids{$frame-id}:exists {
            return %!frame-ids{$frame-id};
        }
    }
    X::Handles::InvalidFrame.new(:$frame-id).throw;
}

# Look up reference details by variablesReference
method resolve-ref(Int $ref --> Hash) {
    $!lock.protect: {
        if %!var-refs{$ref}:exists {
            return %!var-refs{$ref};
        }
    }
    X::Handles::StaleReference.new(reference => $ref).throw;
}

# Check whether registry is empty
method is-empty(--> Bool) {
    $!lock.protect: {
        return %!var-refs.elems == 0 && %!frame-ids.elems == 0 && $!moar-handles.elems == 0;
    }
}

#| Reply cached under $key for the current stop (DR-3); &fetch runs only on a miss. A failed fetch is retried.
method cached-reply(Str $key, &fetch --> Promise) {
    my $placeholder;
    my Bool $must-fetch = False;
    $!lock.protect: {
        my $p = %!replies{$key};
        if !$p.defined || $p.status == Broken {
            $placeholder = Promise.new;
            %!replies{$key} = $placeholder;
            $must-fetch = True;
        } else {
            $placeholder = $p;
        }
    }
    if $must-fetch {
        try {
            my $actual = fetch();
            $actual.then(-> $res {
                    if $res.status == Kept {
                        $placeholder.keep($res.result);
                    } else {
                        $!lock.protect: { %!replies{$key}:delete; }
                        $placeholder.break($res.cause);
                    }
            });
            CATCH {
                default {
                    $!lock.protect: { %!replies{$key}:delete; }
                    $placeholder.break($_);
                }
            }
        }
    }
    return $placeholder;
}

#| Forgets cached stop replies on resume or step without releasing allocated handles
method clear-replies(--> Nil) {
    $!lock.protect: {
        %!replies = ();
    }
}

#| Forgets everything allocated during this stop, advances the stop generation,
#| resets the Invoke budget and result cache, and returns the MoarVM handles to release (excluding pinned handles).
#| Sending the release is `Remote.end-stop`'s job (A-21, D2).
method end-stop(--> List) {
    $!lock.protect: {
        my @handles = $!moar-handles.keys.map(*.Int).grep({ $_ > 0 && !$!pinned-handles{$_} }).sort;
        %!var-refs = ();
        %!frame-ids = ();
        $!moar-handles = SetHash.new;
        %!replies = ();
        %!invoke-results = ();
        $!invoke-spent = False;
        $!stop-gen++;
        @handles.List;
    }
}

# Clear without sending Release Handles (e.g. on disconnect or before connection)
method clear(--> Nil) {
    $!lock.protect: {
        %!var-refs = ();
        %!frame-ids = ();
        $!moar-handles = SetHash.new;
        $!pinned-handles = SetHash.new;
        %!replies = ();
        %!invoke-results = ();
        $!invoke-spent = False;
        $!stop-gen++;
    }
}
