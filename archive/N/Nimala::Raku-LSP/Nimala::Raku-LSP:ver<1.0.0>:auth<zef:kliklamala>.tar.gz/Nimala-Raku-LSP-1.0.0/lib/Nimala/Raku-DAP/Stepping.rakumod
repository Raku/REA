use v6.d;
unit class Nimala::Raku-DAP::Stepping;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Remote;
use Nimala::Raku-DAP::Trace;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::ThreadState;
use Nimala::Raku-DAP::FrameClassifier;
use Nimala::URI;

our role LeaveOutcome {}
our enum StopOutcome is export does LeaveOutcome <Parked Ran>;
our class Failed is export does LeaveOutcome {
    has Str $.cause;
}

my constant RESUME-BLOCKED = "Cannot step or resume: an expression evaluation is still running in the debuggee";

has Nimala::Raku-DAP::Protocol $.protocol is required;
has Nimala::Raku-DAP::Handles $.handles is required;
has Nimala::Raku-DAP::Remote $.remote is required;
has Nimala::Raku-DAP::FrameClassifier $.frame-classifier is required;
has Nimala::Raku-DAP::ThreadRegistry $.threads is required;
has &.send-response is required;
has &.send-event is required;
has &.is-user-breakpoint-line is required;

has Str $.program-file = '';
has Str $.smart-step-mode is rw = 'into';
has Int $.max-skip-count is rw = 500;
has Bool $.has-line-drift-bug = True;

has Lock $!sweep-lock = Lock.new;
has %!sweep-breakpoints;
has %!sweep-file-lines;

method thread-state(Int $thread-id --> Nimala::Raku-DAP::ThreadState) {
    $!threads.thread-state($thread-id);
}

method stopped-thread(--> Int) {
    $!threads.stopped-thread;
}

method register-sweep-breakpoint(Int $id, Str $file, Int $line, Str $scope = '', Int :$thread = 1 --> Nil) {
    my $ts = self.thread-state($thread);
    # Registrations arrive concurrently from parallel type-15 replies; the SetHash must be written under the lock
    $!sweep-lock.protect({
            %!sweep-breakpoints{$id} = %( file => $file, line => $line, scope => $scope, thread => $thread );
            %!sweep-file-lines{"$file:$line"} = $id;
            $ts.step-context.sweep-ids.set($id) if $ts;
    });
}

method is-sweep-breakpoint(Int $id --> Bool) {
    $!sweep-lock.protect({ %!sweep-breakpoints{$id}:exists });
}

method get-sweep-breakpoint(Int $id --> Hash) {
    $!sweep-lock.protect({ %!sweep-breakpoints{$id} // %() });
}

method is-line-swept(Str $file, Int $line --> Bool) {
    $!sweep-lock.protect({ %!sweep-file-lines{"$file:$line"}:exists });
}

method clear-sweep-breakpoints(Int :$thread --> Promise) {
    my @bps = $!sweep-lock.protect({
            if $thread.defined {
                my @to-remove = %!sweep-breakpoints.grep({ ($_.value<thread> // 1) == $thread });
                my @list = @to-remove.map(*.value);
                for @to-remove -> $pair {
                    %!sweep-breakpoints{$pair.key}:delete;
                }
                %!sweep-file-lines = ();
                for %!sweep-breakpoints.kv -> $id, %info {
                    my Str $k = (%info<file> // '') ~ ':' ~ (%info<line> // 0);
                    %!sweep-file-lines{$k} = $id;
                }
                @list;
            } else {
                my @list = %!sweep-breakpoints.values;
                %!sweep-breakpoints = ();
                %!sweep-file-lines = ();
                @list;
            }
    });
    my @promises;
    for @bps -> %bp {
        my Str $file = (%bp<file> // '').Str;
        my Int $line = (%bp<line> // 0).Int;
        my Str $key = "$file:$line";
        my Bool $is-user-bp = ?&!is-user-breakpoint-line($key);
        my Bool $still-swept = self.is-line-swept($file, $line);
        if $file ne '' && $line > 0 && !$is-user-bp && !$still-swept && ($!protocol.defined || $!remote.defined) {
            @promises.push: $!remote.clear-breakpoint($file, $line);
        }
    }
    if $thread.defined {
        my $ts = self.thread-state($thread);
        $ts.step-context.reset if $ts;
    } else {
        my @all = $!threads.all;
        for @all -> $ts {
            $ts.step-context.reset;
        }
    }
    return Promise.allof(@promises);
}

method !sync-sweep-breakpoints(%desired, Int $thread --> Promise) {
    my $ts = self.thread-state($thread);
    my @actions;

    # 1. Inspect currently armed sweep breakpoints for $thread under lock
    my @retire-bps = $!sweep-lock.protect({
            my @to-retire;
            for %!sweep-breakpoints.kv -> $id, %bp {
                next unless (%bp<thread> // 1) == $thread;
                my Str $file = (%bp<file> // '').Str;
                my Int $line = (%bp<line> // 0).Int;
                my Str $key = "$file:$line";

                if %desired{$key}:exists {
                    # Keep armed, update scope
                    %bp<scope> = %desired{$key}<scope>;
                    %desired{$key}<armed> = True;
                } else {
                    @to-retire.push(%( :$id, :$file, :$line, :$key ));
                }
            }
            for @to-retire -> %r {
                %!sweep-breakpoints{%r<id>}:delete;
                my Str $k = %r<key>;
                # Only delete from %!sweep-file-lines if no other thread sweeps it
                my Bool $other-thread = so %!sweep-breakpoints.values.first({
                        ((%_<file> // '') ~ ':' ~ (%_<line> // 0)) eq $k
                });
                %!sweep-file-lines{$k}:delete unless $other-thread;
                $ts.step-context.sweep-ids.unset(%r<id>) if $ts;
            }
            @to-retire;
    });

    # 2. Clear retired breakpoints on wire (if not a user BP and not swept by another thread)
    for @retire-bps -> %r {
        my Str $file = %r<file>;
        my Int $line = %r<line>;
        my Str $key = %r<key>;
        my Bool $is-user-bp = ?&!is-user-breakpoint-line($key);
        my Bool $still-swept = self.is-line-swept($file, $line);
        if $file ne '' && $line > 0 && !$is-user-bp && !$still-swept && ($!protocol.defined || $!remote.defined) {
            @actions.push($!remote.clear-breakpoint($file, $line));
        }
    }

    # 3. Arm newly desired breakpoints not yet armed
    for %desired.values -> %d {
        next if %d<armed>;
        my Str $file = %d<file>;
        my Int $line = %d<line>;
        my Str $scope = %d<scope>;
        my $p = self!sweep-point-promise($file, $line, $scope, $thread);
        @actions.push($p) if $p.defined;
    }

    @actions ?? Promise.allof(@actions) !! Promise.kept(True);
}

method initiate-sweep-step(
    Str $mode, Int $thread, %req, Str :$cur-file is copy = '', Int :$cur-line is copy = 0 --> Promise
) {
    start {
        my $t-state = self.thread-state($thread);
        my $trace = attempt($!remote.stack-trace($thread), 'stack trace') // %();
        my @frames = ($trace<frames> // []).list;
        my Int $start-depth = @frames.elems;
        my %top = @frames[0] // %();

        if $cur-file eq '' {
            $cur-file = (%top<file> || $!program-file || '').Str;
        }
        if $cur-line <= 0 {
            $cur-line = (%top<line> // 0).Int;
        }

        my $sc = $t-state.step-context;
        $sc.current-skip-count = 0;
        $sc.mode = $mode;
        $sc.start-depth = $start-depth;
        $sc.origin-file = $cur-file;
        $sc.origin-line = $cur-line;

        my %desired;

        if $mode eq 'stepIn' {
            my Int $target-id = (%req<arguments><targetId> // 0).Int;
            my %target = $!frame-classifier.resolve-callee-target($cur-file, $cur-line, :$target-id);
            if %target && %target<file> && %target<line> {
                my Str $tgt-file = %target<file>.Str;
                my Int $tgt-line = %target<line>.Int;
                my Str $k = "$tgt-file:$tgt-line";
                unless &!is-user-breakpoint-line($k) {
                    %desired{$k} = %( file => $tgt-file, line => $tgt-line, scope => 'callee-entry', armed => False );
                }
            }
        }

        # Sweep current routine statements
        if $cur-file ne '' && $cur-line > 0 {
            my %r-info = $!frame-classifier.extract-routine-info($cur-file, $cur-line);
            my Str $scope = (%r-info<scope> // 'routine').Str;
            my Array[Int] $routine-lines = %r-info<lines>;
            for @$routine-lines -> $l {
                next if $l == $cur-line;
                my Str $k = "$cur-file:$l";
                unless &!is-user-breakpoint-line($k) {
                    %desired{$k} = %( file => $cur-file, line => $l, :$scope, armed => False );
                }
            }
        }

        # Caller frame return safety
        if @frames.elems >= 2 {
            my %caller = @frames[1];
            my Str $caller-file = (%caller<file> // '').Str;
            my Int $caller-line = (%caller<line> // 0).Int;
            if $caller-file ne '' && $caller-line > 0 {
                my Array[Int] $caller-lines = $!frame-classifier.extract-routine-lines($caller-file, $caller-line);
                for @$caller-lines -> $cl {
                    my Str $k = "$caller-file:$cl";
                    unless &!is-user-breakpoint-line($k) {
                        %desired{$k} //= %(
                            file => $caller-file, line => $cl, scope => 'caller-return', armed => False
                        );
                    }
                }
            }
        }

        await self!sync-sweep-breakpoints(%desired, $thread);
        await self!resume-or-fail(%req, { $!remote.resume-all() }, :$thread, :emit-continued);
    }
}

method !sweep-point-promise(Str $file, Int $line, Str $scope, Int $thread --> Promise) {
    my Str $key = "$file:$line";
    my Bool $is-user-bp = ?&!is-user-breakpoint-line($key);
    return Promise if self.is-line-swept($file, $line) || $is-user-bp;

    $!remote.set-breakpoint($file, $line, :suspend, :!stacktrace).then(-> $res-prom {
            if $res-prom.status == Kept {
                my $res = $res-prom.result;
                if $res && $res<id>.defined {
                    my Int $bp-id = $res<id>.Int;
                    my Int $c-line = $res<line>.defined ?? $res<line>.Int !! $line;
                    self.register-sweep-breakpoint($bp-id, $file, $c-line, $scope, :$thread);
                }
            }
    });
}

#| False (and the request answered) while an Invoke still runs on any thread (D6).
method !guard-resume(%req, Int $thread --> Bool) {
    return True unless $!protocol.defined && $!protocol.invoke-in-flight();
    &!send-response(%req, {}, success => False, message => RESUME-BLOCKED);
    False;
}

#| Single exit path from a stop (D3). Returns a Promise of LeaveOutcome (Parked | Ran | Failed).
method leave-stop(Int:D $thread, &run --> Promise) {
    my $ts = $!threads.thread-state($thread);
    my Int $other = $!threads.other-stopped-thread($thread);
    if $other > 0 && $ts.is-stopped {
        $!threads.reset-stop($thread);
        $!threads.stopped-thread = $other;
        return Promise.kept(Parked);
    }
    start {
        my $p = try { run() };
        if !$p.defined {
            Failed.new(cause => ($!.defined ?? $!.message !! 'failed'));
        } else {
            await Promise.anyof($p);
            if $p.status ~~ Kept {
                $!threads.reset-all-stops;
                attempt($!remote.end-stop, 'release handles after resume') if $!remote.defined;
                Ran;
            } else {
                my Str $cause = $p.cause.defined ?? $p.cause.message !! 'failed';
                Failed.new(:$cause);
            }
        }
    }
}

#| The debuggee is still stopped: answer the request with the cause, drop the sweep this step armed and keep
#| every thread's stop state and the handles, so the stop can still be inspected and resumed again (A-15).
method !resume-failed(%req, Str $cause, Int :$thread --> Nil) {
    attempt(self.clear-sweep-breakpoints(:$thread), 'clear sweep after failed resume') if $thread.defined;
    &!send-response(%req, {}, success => False, message => "Could not resume: $cause");
}

#| Awaits the resume or step &run via leave-stop; answers with %body on success (Ran or Parked),
#| reports the failure otherwise.
method !resume-or-fail(
    %req,
    &run,
    Int :$thread!,
    :%body = {},
    Bool :$emit-continued = False
    --> Promise
) {
    self.leave-stop($thread, &run).then(-> $p {
            my $outcome = $p.status ~~ Kept ?? $p.result !! Failed.new(cause => 'failed');
            if $outcome ~~ Ran || $outcome ~~ Parked {
                &!send-response(%req, %body);
                if $emit-continued && $outcome ~~ Ran {
                    &!send-event('continued', %( threadId => $thread, allThreadsContinued => True ));
                }
            } else {
                self!resume-failed(%req, $outcome.cause, :$thread);
            }
    });
}

method handle-continue(%req --> Promise) {
    start {
        my Int $thread = (%req<arguments><threadId> // self.stopped-thread).Int;
        if self!guard-resume(%req, $thread) {
            attempt(self.clear-sweep-breakpoints(), 'clear sweep before continue');
            await self!resume-or-fail(
                %req, { $!remote.resume-all() }, :$thread, body => %( allThreadsContinued => True )
            );
        }
    }
}

method !handle-step(%req, Str $step-mode, Int $step-type --> Promise) {
    start {
        my Int $thread = (%req<arguments><threadId> // self.stopped-thread).Int;
        my $t-state = self.thread-state($thread);
        my Str $cur-file = ($t-state.stopped-file || $!program-file || '').Str;
        my Int $cur-line = $t-state.stopped-breakpoint-line.Int;

        if self!guard-resume(%req, $thread) {
            $t-state.step-context.last-step-type = $step-type;
            $t-state.step-context.current-skip-count = 0;

            if !$!has-line-drift-bug {
                attempt(self.clear-sweep-breakpoints(:$thread), 'clear sweep before native step');
                my &step = $step-type == MoarMsg::StepInto.value
                ?? { $!remote.step-into($thread) }
                !! { $!remote.step-over($thread) };
                await self!resume-or-fail(%req, &step, :$thread, :emit-continued);
            } else {
                await self.initiate-sweep-step($step-mode, $thread, %req, :$cur-file, :$cur-line);
            }
        }
    }
}

method handle-next(%req --> Promise) {
    self!handle-step(%req, 'next', MoarMsg::StepOver.value);
}

method handle-step-in(%req --> Promise) {
    self!handle-step(%req, 'stepIn', MoarMsg::StepInto.value);
}

method handle-step-out(%req --> Promise) {
    start {
        my Int $thread = (%req<arguments><threadId> // self.stopped-thread).Int;
        my $t-state = self.thread-state($thread);

        if self!guard-resume(%req, $thread) {
            $t-state.step-context.last-step-type = MoarMsg::StepOut.value;
            $t-state.step-context.current-skip-count = 0;

            my $st-p = attempt($!remote.stack-trace($thread), 'stack trace');
            my @frames = ($st-p<frames> // []).flat;

            if @frames.elems < 2 {
                # Fallback to native message 22 if no caller frame identified
                attempt(self.clear-sweep-breakpoints(:$thread), 'clear sweep before native step-out');
                await self!resume-or-fail(%req, { $!remote.step-out($thread) }, :$thread, :emit-continued);
            } else {
                my %top = @frames[0] // %();
                my $sc = $t-state.step-context;
                $sc.mode = 'stepOut';
                $sc.start-depth = @frames.elems;
                $sc.origin-file = (%top<file> // '').Str;
                $sc.origin-line = (%top<line> // 0).Int;

                # When no caller has a line left after its call, none of these fires again and the program runs
                # to its end: MoarVM steps are line based and native step out (22) is unimplemented (DK-8)
                my %desired;
                for self!step-out-targets(@frames) -> ($file, $l) {
                    my Str $k = "$file:$l";
                    unless &!is-user-breakpoint-line($k) {
                        %desired{$k} = %( :$file, line => $l, scope => 'caller-return', armed => False );
                    }
                }
                await self!sync-sweep-breakpoints(%desired, $thread);
                await self!resume-or-fail(%req, { $!remote.resume-all() }, :$thread, :emit-continued);
            }
        }
    }
}

#| StepOut caller-return escalation: the caller lines to arm, escalating while a
#| call site is the last executable line of its routine.
method !step-out-targets(@frames --> Array) {
    my @targets;
    my Bool $need-escalate = True;
    my Int $frame-idx = 1;
    while $frame-idx < @frames.elems && $need-escalate {
        my %caller-frame = @frames[$frame-idx];
        my Str $target-file = (%caller-frame<file> // '').Str;
        my Int $call-line = (%caller-frame<line> // 0).Int;

        if $target-file ne '' && $call-line > 0 && !$!frame-classifier.is-internal-frame(%caller-frame) {
            if !$target-file.IO.is-absolute {
                my Str $resolved = $!frame-classifier.resolve-compunit-path($target-file);
                $target-file = $resolved if $resolved ne '';
            }
            my Array[Int] $routine-lines = $!frame-classifier.extract-routine-lines($target-file, $call-line);
            @targets.push(($target-file, $_)) for @$routine-lines;

            my @sorted-lines = @$routine-lines.sort;
            $need-escalate = so @sorted-lines && $call-line >= @sorted-lines[*- 1];
        }
        $frame-idx++;
    }
    @targets.unique(:as(*.join(':'))).Array;
}

method !emit-stopped(Int $thread, Str $desc = '' --> Nil) {
    $!threads.emit-stopped($thread, 'step', :description($desc));
}

method handle-step-notification(Int $thread, @event-frames = () --> Promise) {
    start {
        my $ts = self.thread-state($thread);
        my $sc = $ts.step-context;
        $ts.set-stop-location;

        if $!smart-step-mode eq 'disable' {
            self!emit-stopped($thread);
        } else {
            my @frames = @event-frames.elems > 0 ?? @event-frames !! ();
            if !@frames.elems && $!protocol.defined {
                my $trace = attempt($!remote.stack-trace($thread), 'stack trace') // %();
                @frames = ($trace<frames> // []).list;
            }
            if !@frames.elems || !$!frame-classifier.is-internal-frame(@frames[0]) {
                self!emit-stopped($thread);
            } elsif $sc.current-skip-count >= $!max-skip-count {
                self!emit-stopped($thread, 'Smart stepping gave up: step bound reached without finding user code');
            } else {
                $sc.current-skip-count++;
                my Int $next-step-type = $!smart-step-mode eq 'over'
                ?? MoarMsg::StepOver.value
                !! $sc.last-step-type;
                my $outcome = await self.leave-stop($thread, { $!remote.step-raw($thread, $next-step-type) });
                if $outcome ~~ Failed {
                    &!send-event('output', %(
                            category => 'console',
                            output => "Could not step: {$outcome.cause}\n",
                    ));
                }
            }
        }
    }
}
