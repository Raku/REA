use v6.d;
#| Standalone Content-Length framing and stdio transport for the Debug Adapter Protocol (DAP).
unit module Nimala::Raku-DAP::Framing;

my Lock $write-lock .= new;

#| Frames an outgoing JSON string with standard Content-Length headers.
our sub dap-frame-message(Str $json --> Blob) is export {
    my Blob $encoded = $json.encode('utf-8');
    my Blob $header = "Content-Length: { $encoded.bytes }\r\n\r\n".encode('utf-8');

    my Buf[uint8] $buf = Buf[uint8].new;
    $buf.append($header);
    $buf.append($encoded);
    return $buf;
}

#| Adapts a synchronous IO::Handle into a Supply of decoded JSON strings using Content-Length framing.
our sub dap-handle-supply(IO::Handle $in, Int :$chunk-size = 1024 --> Supply) is export {
    try { $in.encoding(Nil) if $in.can('encoding') };
    my Supplier::Preserving $supplier .= new;

    start {
        my Buf[uint8] $buf .= new;
        loop {
            my Int $delimiter-pos = -1;
            my Int $delimiter-len = 0;

            loop {
                if $buf.elems >= 4 {
                    for 0 .. ($buf.elems - 4) -> $i {
                        if $buf[$i] == 13 && $buf[$i+1] == 10 && $buf[$i+2] == 13 && $buf[$i+3] == 10 {
                            $delimiter-pos = $i;
                            $delimiter-len = 4;
                            last;
                        }
                    }
                }
                if $delimiter-pos == -1 && $buf.elems >= 2 {
                    for 0 .. ($buf.elems - 2) -> $i {
                        if $buf[$i] == 10 && $buf[$i+1] == 10 {
                            $delimiter-pos = $i;
                            $delimiter-len = 2;
                            last;
                        }
                    }
                }

                last if $delimiter-pos != -1;

                my Blob $chunk = $in.read($chunk-size);
                last if !$chunk.elems; # EOF
                $buf.append($chunk);
            }

            last if $delimiter-pos == -1; # EOF before complete header

            my Str $headers = $buf.subbuf(0, $delimiter-pos).decode('latin-1');
            my Int $len = 0;
            if $headers ~~ / :i 'Content-Length:' \s* (\d+) / {
                $len = +$0;
            } else {
                $supplier.emit('{"type":"__framing_error","error":"Missing Content-Length header"}');
                $buf = $buf.subbuf($delimiter-pos + $delimiter-len);
                next;
            }

            my Int $total-needed = $delimiter-pos + $delimiter-len + $len;
            while $buf.elems < $total-needed {
                my Blob $chunk = $in.read($total-needed - $buf.elems);
                last if !$chunk.elems; # EOF
                $buf.append($chunk);
            }

            last if $buf.elems < $total-needed;
            my Blob $body = $buf.subbuf($delimiter-pos + $delimiter-len, $len);
            $buf = $buf.subbuf($total-needed);

            my Str $decoded;
            my Bool $ok = True;
            try {
                $decoded = $body.decode('utf-8');
                CATCH { default { $ok = False; } }
            }
            if $ok {
                $supplier.emit($decoded);
            } else {
                # Hand the broker a marker with whatever seq/command can be recovered; the broker answers it
                my Str $lossy = $body.decode('latin-1');
                my Str $marker = '{"type":"__framing_error","error":"Invalid UTF-8"';
                if $lossy ~~ / '"seq"' \s* ':' \s* ( \d+ ) / {
                    $marker ~= ',"seq":' ~ $0.Str;
                }
                if $lossy ~~ / '"command"' \s* ':' \s* '"' ( <[a..zA..Z0..9_\-]>* ) '"' / {
                    $marker ~= ',"command":"' ~ $0.Str ~ '"';
                }
                $supplier.emit($marker ~ '}');
            }
        }
        $supplier.done();
        CATCH {
            default {
                $supplier.quit($_);
            }
        }
    }

    return $supplier.Supply;
}

#| Reads DAP messages from an input handle using Content-Length framing.
our sub dap-read-supply(IO::Handle $in = $*IN --> Supply) is export {
    try { $in.encoding(Nil) if $in.can('encoding') };
    return dap-handle-supply($in);
}

#| Writes a DAP message to an output handle with synchronized Content-Length header.
our sub dap-write(Str $json, IO::Handle $out = $*OUT --> Nil) is export {
    my Blob $buf = dap-frame-message($json);

    $write-lock.protect: {
        $out.write: $buf;
        $out.flush if $out.^can('flush');
    }
}

