use v6.d;
unit package Nimala::Raku-DAP::Protocol::Messages;

#| MoarVM remote debug protocol message types.
our enum MoarMsg is export (
    ErrorCannotProcess       => 0,
    ErrorProcessing          => 1,
    OperationSuccessful      => 2,
    IsExecutionSuspended     => 3,
    ExecutionSuspendedState  => 4,
    SuspendAll               => 5,
    ResumeAll                => 6,
    SuspendOne               => 7,
    ResumeOne                => 8,
    ThreadStarted            => 9,
    ThreadEnded              => 10,
    ThreadList               => 11,
    ThreadListResponse       => 12,
    ThreadStackTrace         => 13,
    ThreadStackTraceResponse => 14,
    SetBreakpoint            => 15,
    SetBreakpointResponse    => 16,
    BreakpointHit            => 17,
    ClearBreakpoint          => 18,
    ClearAllBreakpoints      => 19,
    StepInto                 => 20,
    StepOver                 => 21,
    StepOut                  => 22,
    StepCompleted            => 23,
    ReleaseHandles           => 24,
    HandlesReleased          => 25,
    ContextHandle            => 26,
    ContextLexicals          => 27,
    ContextLexicalsResponse  => 28,
    OuterContext             => 29,
    CallerContext            => 30,
    CodeObjectHandle         => 31,
    ObjectAttributes         => 32,
    ObjectAttributesResponse => 33,
    DecontainerizeHandle     => 34,
    FindMethodHandle         => 35,
    InvokeCodeObject         => 36,
    InvokeResult             => 37,
    UnhandledException       => 38,
    OperationUnsuccessful    => 39,
    ObjectMetadata           => 40,
    ObjectMetadataResponse   => 41,
    ObjectPositionals        => 42,
    ObjectPositionalsResponse=> 43,
    ObjectAssociatives       => 44,
    ObjectAssociativesResponse=>45,
    HandleEquivalence        => 46,
    HandleEquivalenceResponse=> 47,
);

#| Whitelisted helper methods and prefix in debuggee.
our constant @HELPER-METHODS is export = <gist Str raku elems>;
our constant HELPER-PREFIX is export = '_nimala_';

#| Typed builders for outgoing MoarVM debug protocol wire requests.
our sub msg-is-suspended(--> Hash:D) is export {
    %( type => MoarMsg::IsExecutionSuspended.value )
}

our sub msg-suspend-all(--> Hash:D) is export {
    %( type => MoarMsg::SuspendAll.value )
}

our sub msg-resume-all(--> Hash:D) is export {
    %( type => MoarMsg::ResumeAll.value )
}

our sub msg-step-over(Int:D $thread --> Hash:D) is export {
    %( type => MoarMsg::StepOver.value, :$thread )
}

our sub msg-step-into(Int:D $thread --> Hash:D) is export {
    %( type => MoarMsg::StepInto.value, :$thread )
}

our sub msg-step-out(Int:D $thread --> Hash:D) is export {
    %( type => MoarMsg::StepOut.value, :$thread )
}

our sub msg-step-raw(Int:D $thread, Int:D $type --> Hash:D) is export {
    %( :$type, :$thread )
}

our sub msg-breakpoint-set(
    Str:D $file, Int:D $line, Bool :$suspend = True, Bool :$stacktrace = False --> Hash:D
) is export {
    %( type => MoarMsg::SetBreakpoint.value, :$file, :$line, :$suspend, :$stacktrace )
}

our sub msg-breakpoint-clear(Str:D $file, Int:D $line --> Hash:D) is export {
    %( type => MoarMsg::ClearBreakpoint.value, :$file, :$line )
}

our sub msg-clear-all-breakpoints(--> Hash:D) is export {
    %( type => MoarMsg::ClearAllBreakpoints.value )
}

our sub msg-thread-list(--> Hash:D) is export {
    %( type => MoarMsg::ThreadList.value )
}

our sub msg-stack-trace(Int:D $thread --> Hash:D) is export {
    %( type => MoarMsg::ThreadStackTrace.value, :$thread )
}

our sub msg-context(Int:D $thread, Int:D $frame --> Hash:D) is export {
    %( type => MoarMsg::ContextHandle.value, :$thread, :$frame )
}

our sub msg-outer-context(Int:D $handle --> Hash:D) is export {
    %( type => MoarMsg::OuterContext.value, :$handle )
}

our sub msg-lexicals(Int:D $handle --> Hash:D) is export {
    %( type => MoarMsg::ContextLexicals.value, :$handle )
}

our sub msg-attributes(Int:D $handle, Int :$thread = 1 --> Hash:D) is export {
    %( type => MoarMsg::ObjectAttributes.value, :$handle, :$thread )
}

our sub msg-decont(Int:D $handle, Int :$thread = 1 --> Hash:D) is export {
    %( type => MoarMsg::DecontainerizeHandle.value, :$handle, :$thread )
}

our sub msg-metadata(Int:D $handle, Int :$thread = 1 --> Hash:D) is export {
    %( type => MoarMsg::ObjectMetadata.value, :$handle, :$thread )
}

our sub msg-positionals(Int:D $handle, Int :$thread = 1, Int:D :$start = 0, Int:D :$count = 100 --> Hash:D) is export {
    %( type => MoarMsg::ObjectPositionals.value, :$handle, :$thread )
}

our sub msg-associatives(Int:D $handle, Int :$thread = 1 --> Hash:D) is export {
    %( type => MoarMsg::ObjectAssociatives.value, :$handle, :$thread )
}

our sub msg-release-handles(@handles --> Hash:D) is export {
    %( type => MoarMsg::ReleaseHandles.value, handles => @handles.map(*.Int).List )
}

our sub msg-invoke(Int:D $thread, Int:D $code-handle, @arguments --> Hash:D) is export {
    %( type => MoarMsg::InvokeCodeObject.value, :$thread, handle => $code-handle, arguments => @arguments )
}

#| Decoders and event wrapper for inbound MoarVM events.
our sub is-stop-event(Associative:D $event --> Bool:D) is export {
    my int $type = ($event<type> // -1).Int;
    $type == MoarMsg::BreakpointHit.value
    || $type == MoarMsg::StepCompleted.value
    || $type == MoarMsg::UnhandledException.value;
}
