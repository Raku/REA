use v6.d;
unit class Nimala::Raku-DAP::ExceptionState;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Remote;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::ThreadState;

has Nimala::Raku-DAP::Protocol $.protocol is required;
has Nimala::Raku-DAP::Handles $.handles is required;
has Nimala::Raku-DAP::Remote $.remote is required;
has &.send-response is required;
has &.inspect-scalar is required;

#| Record exception metadata from a MoarVM stop event
method record-exception(%ev, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    my Int $h = (%ev<handle> // 0).Int;
    $t-state.last-exception-handle = $h;
    $t-state.frames = (%ev<frames> // []).Array;
    $!handles.record-handle($h) if $!handles && $h > 0;
}

#| Record exception details parsed from CLI or error text output
#| True when a stderr chunk looks like a Raku exception: it starts with `Unhandled exception:`, or it carries a
#| backtrace line (`  in block <unit> at prog.raku line 3`). Plain `note`/`warn` output does not (A-14).
method looks-like-exception(Str $text --> Bool) {
    my Str $first = $text.lines.first(*.trim.chars > 0) // '';
    return True if $first.trim.starts-with('Unhandled exception:');
    so $text.lines.first(/ ^ \s+ 'in ' .+ ' at ' .+ ' line ' \d+ /);
}

method record-exception-from-text(Str $text, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    my @lines = $text.lines.grep(*.trim.chars > 0);
    return unless @lines && $t-state.defined;

    my Str $first = @lines[0].trim;
    my Str $type = "Exception";
    my Str $msg = $first;

    if $first ~~ /^ 'Unhandled exception:' \s* (.*) $/ {
        $msg = (~$0).trim;
    }
    if $msg ~~ /^ (\w+ '::' \w+ [ '::' \w+ ]*) [ ':' \s* (.*) ]? $/ {
        $type = (~$0).trim;
        $msg = ($1.defined && $1.chars > 0) ?? (~$1).trim !! $type;
    }
    $t-state.last-exception-type = $type;
    $t-state.last-exception-message = $msg;
    $t-state.frames = self.parse-backtrace(@lines[1..*].join("\n")).Array;
}

#| Parse text backtrace lines into an array of DAP frame hashes.
method parse-backtrace(Str $text --> Array) {
    my @frames;
    for $text.lines -> $line {
        my Str $trimmed = $line.trim;
        next if $trimmed eq '';
        next if $trimmed.contains('InjectedHelper.rakumod') || $trimmed.contains('(Nimala::Raku-DAP::InjectedHelper)');
        if $trimmed ~~ / 'in ' (.*?) ' at ' (.*?) ' line ' (\d+) / {
            @frames.push(%(
                    name => (~$0).trim,
                    file => (~$1).trim,
                    line => (+$2).Int
            ));
        } elsif $trimmed ~~ / 'at ' (.*?) ':' (\d+) / {
            @frames.push(%(
                    name => '<anonymous>',
                    file => (~$0).trim,
                    line => (+$1).Int
            ));
        }
    }
    return @frames;
}

#| Reset cached exception state for a thread
method reset-exception(Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    return unless $t-state.defined;
    $t-state.last-exception-handle = 0;
    $t-state.last-exception-type = '';
    $t-state.last-exception-message = '';
    $t-state.last-exception-backtrace = '';
    $t-state.last-exception-break-mode = 'unhandled';
    $t-state.frames = Array.new;
}

method !query-exception-handle-details(Int $ex-handle, Int $thread, Str $initial-type, Str $initial-desc --> Promise) {
    start {
        my Str $type-name = $initial-type ne '' ?? $initial-type !! "Exception";
        my Str $description = $initial-desc ne '' ?? $initial-desc !! "Unhandled exception";

        # 1. Query Object Metadata (40)
        try {
            my $meta-res = await $!remote.metadata($ex-handle, :$thread);
            if $meta-res && $meta-res<metadata> && $meta-res<metadata><debug_name> {
                $type-name = $meta-res<metadata><debug_name>.Str;
            }
        }

        # 2. Query Object Attributes (32)
        try {
            my $attr-res = await $!remote.attributes($ex-handle, :$thread);
            if $attr-res && $attr-res<attributes> {
                for <$!message $!payload> -> $attr-target {
                    my %a = attribute-named($attr-res<attributes> // [], $attr-target);
                    next unless %a;
                    if %a<value>.defined && %a<value> ne "" {
                        $description = %a<value>.Str;
                    } elsif %a<handle>.defined && %a<handle> > 0 && &!inspect-scalar.defined {
                        my $val-info = await &!inspect-scalar(%a<handle>.Int, $thread);
                        if $val-info<value>.defined && $val-info<value> ne "" {
                            $description = $val-info<value>.Str;
                        }
                    }
                    last if $description ne "Unhandled exception";
                }
            }
        }
        hash( :$type-name, :$description );
    }
}

method !send-exception-info-response(%req, Str $type-name, Str $description, Str $break-mode, Str $stack-trace --> Nil) {
    &!send-response(%req, %(
            exceptionId => $type-name,
            description => $description,
            breakMode   => $break-mode,
            details     => %(
                typeName   => $type-name,
                message    => $description,
                stackTrace => $stack-trace
            )
    ));
}

#| Build exceptionInfo response according to DAP specification
method handle-exception-info(%req, Nimala::Raku-DAP::ThreadState $t-state --> Promise) {
    my Str $break-mode = $t-state.last-exception-break-mode || 'unhandled';
    my Str $type-name = $t-state.last-exception-type || '';
    my Str $description = $t-state.last-exception-message || '';
    my Str $stack-trace = $t-state.last-exception-backtrace || '';

    if $stack-trace eq '' && $t-state.frames.elems > 0 {
        $stack-trace = $t-state.frames.map(-> %f {
                my $name = %f<name> // '<anonymous>';
                my $file = %f<file> // '<unknown>';
                my $line = %f<line> // 0;
                "  in $name at $file line $line"
        }).join("\n");
    }

    my Int $ex-handle = $t-state.last-exception-handle;
    if ($type-name eq '' || $description eq '') && $ex-handle > 0 {
        return start {
            my %details = await self!query-exception-handle-details(
                $ex-handle, $t-state.thread-id, $type-name, $description
            );
            self!send-exception-info-response(%req, %details<type-name>, %details<description>, $break-mode, $stack-trace);
        };
    }

    if $type-name eq '' && $description eq '' && $ex-handle == 0 {
        &!send-response(%req, %(), success => False, message => "No exception on thread {$t-state.thread-id}");
        return Promise.kept(True);
    }

    $type-name ||= 'Exception';
    $description ||= 'Unhandled exception';

    self!send-exception-info-response(%req, $type-name, $description, $break-mode, $stack-trace);
    return Promise.kept(True);
}
