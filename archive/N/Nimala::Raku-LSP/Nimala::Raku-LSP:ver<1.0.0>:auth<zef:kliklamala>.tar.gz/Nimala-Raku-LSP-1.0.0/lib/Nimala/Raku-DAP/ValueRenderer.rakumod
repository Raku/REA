use v6.d;
unit class Nimala::Raku-DAP::ValueRenderer;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::Remote;
use Nimala::Raku-DAP::Trace;

has Nimala::Raku-DAP::Remote $.remote is required;
has Nimala::Raku-DAP::Handles $.handles is required;

method handles(--> Nimala::Raku-DAP::Handles) {
    $!handles
}

class CollectionDisplay is export {
    has Str $.disp;
    has Int $.elems;
    method Str() { $!disp }
    method gist() { $!disp }
}

our constant @POSITIONAL-TYPES is export = <Array List Seq>;
our constant @ASSOCIATIVE-TYPES is export = <Hash Map>;

#| Pages an item list by start and count; count = 0 means to the end.
our sub page(@items, Int:D $start, Int:D $count --> List) is export {
    return () if $start >= @items.elems || $start < 0;
    my Int $end = $count > 0 ?? min(@items.elems, $start + $count) !! @items.elems;
    @items[$start ..^ $end].List;
}

our proto sub set-child-counts(|) is export {*}

#| Copies indexedVariables and namedVariables from a source hash to a target hash.
our multi sub set-child-counts(%target, %rendered --> Nil) {
    if (%rendered<indexedVariables>:exists) && %rendered<indexedVariables>.defined {
        %target<indexedVariables> = %rendered<indexedVariables>.Int;
    }
    if (%rendered<namedVariables>:exists) && %rendered<namedVariables>.defined {
        %target<namedVariables> = %rendered<namedVariables>.Int;
    }
}

#| Sets indexedVariables or namedVariables on a target hash depending on type and element count.
our multi sub set-child-counts(%target, Str:D $type, Int:D $elems --> Nil) {
    return unless $elems > 0;
    if $type eq any(@POSITIONAL-TYPES) {
        %target<indexedVariables> = $elems;
    } else {
        %target<namedVariables> = $elems;
    }
}

method is-internal-lexical(Str $name --> Bool) {
    return True if $name.starts-with('!');
    return True if $name.starts-with('::?');
    return True if $name.starts-with('&_nimala_');
    return True if $name eq 'Nimala';
    return True if $name eq '$=pod' || $name eq '$=rakudoc' || $name eq '$¢';
    return True if $name eq 'EXPORT' || $name eq 'GLOBALish';
    return True if $name eq '$=finish'
    || $name eq '$?CHECKSUM'
    || $name eq '$?LANGUAGE-REVISION'
    || $name eq '$?PACKAGE'
    || $name eq '$?SOURCE';
    return False;
}

#| Single shared rotor(25, :partial) batch renderer for variable and attribute lists (M-1).
method render-entries(
    @items, Int $thread, Str :$kind = 'scope', Str :$parent-eval-name = '' --> Promise
) {
    start {
        my @vars;
        for @items.rotor(25, :partial) -> @batch {
            my @batch-promises = @batch.map(-> %item {
                    my Str $name = (%item<name> // '').Str;
                    my Str $type = (%item<type> // '').Str;
                    my Str $raw-val = (%item<value> // '').Str;
                    my Str $eval-name = '';
                    if $kind eq 'scope' {
                        $eval-name = $name;
                    } elsif $kind eq 'attributes' {
                        my Str $bare = $name.subst(/^ <[$@%&]>? <[!?.^*]>? /, '');
                        $eval-name = $parent-eval-name.chars && $bare.chars ?? "{$parent-eval-name}.$bare" !! '';
                    } elsif $kind eq 'positional' {
                        $eval-name = $parent-eval-name.chars ?? "{$parent-eval-name}[$name]" !! '';
                    } elsif $kind eq 'associative' {
                        if $parent-eval-name.chars {
                            $eval-name = $name ~~ /^ <[\w\-]>+ $/
                            ?? "{$parent-eval-name}<$name>"
                            !! "{$parent-eval-name}\{'{$name.subst("'", "\\'", :g)}'\}";
                        }
                    }

                    if $type eq 'Rakudo::Internals::LoweredAwayLexical'
                    || $raw-val.contains('LoweredAwayLexical')
                    || $raw-val eq '<optimized out>' {
                        Promise.kept(%(
                                name => $name,
                                value => '<optimized out>',
                                type => '',
                                variablesReference => 0
                        ));
                    } else {
                        self.render-value(
                            (%item<handle> // 0).Int,
                            $thread,
                            :type($type),
                            :kind((%item<kind> // '').Str),
                            :concrete((%item<concrete> // True).Bool),
                            :is-container((%item<container> // False).Bool || $type eq 'Scalar'),
                            :raw-value($raw-val),
                            :evaluate-name($eval-name)
                        ).then(-> $p-res {
                                my %rendered = $p-res.result;
                                my %v = %(
                                    name => $name,
                                    value => %rendered<value>,
                                    type => %rendered<type>,
                                    variablesReference => %rendered<variablesReference>
                                );
                                %v<evaluateName> = $eval-name if $eval-name ne '';
                                set-child-counts(%v, %rendered);
                                %v;
                        });
                    }
            });
            await Promise.allof(@batch-promises);
            @vars.append(@batch-promises.map(*.result));
        }
        @vars;
    }
}

method render-collection-display(Int $handle, Int $thread, Str $type --> Promise) {
    start {
        my $display;
        my $err;
        try {
            if $type eq any(@ASSOCIATIVE-TYPES) {
                my $p-attr = await $!remote.attributes($handle, :$thread);
                my Int $elems = 0;
                if $p-attr {
                    my @attrs = ($p-attr<attributes> // []).flat;
                    my %storage = attribute-named(@attrs, '$!storage');
                    if %storage && %storage<handle> {
                        my Int $stor-handle = %storage<handle>.Int;
                        my $p-meta = await $!remote.metadata($stor-handle, :$thread);
                        if $p-meta && ($p-meta<metadata><ass_features> // False) {
                            $elems = ($p-meta<metadata><mvmhash_num_items> // 0).Int;
                        }
                    }
                }
                $display = CollectionDisplay.new(disp => "{$type}($elems)", elems => $elems);
            }
            else {
                my $p-attr = await $!remote.attributes($handle, :$thread);
                if $p-attr {
                    my @attrs = ($p-attr<attributes> // []).flat;
                    my %todo = attribute-named(@attrs, '$!todo');
                    my %iter = attribute-named(@attrs, '$!iter');
                    my %reified = attribute-named(@attrs, '$!reified');
                    my Bool $is-lazy = ((%todo && %todo<concrete>) || (%iter && %iter<concrete>)).Bool;

                    my Int $elems = 0;
                    if %reified && %reified<handle> {
                        my $p-meta = await $!remote.metadata(%reified<handle>.Int, :$thread);
                        $elems = ($p-meta<metadata><positional_elems> // 0).Int if $p-meta;
                    }

                    if $is-lazy {
                        $display = CollectionDisplay.new(disp => "[...lazy...]", elems => 0);
                    } else {
                        $display = CollectionDisplay.new(disp => "{$type}($elems)", elems => $elems);
                    }
                } else {
                    $display = CollectionDisplay.new(disp => "$type", elems => 0);
                }
            }
            CATCH {
                default {
                    $err = $_;
                }
            }
        }
        if $err.defined {
            if $err ~~ X::MoarVM::Timeout {
                $display = CollectionDisplay.new(disp => "<$type: unreadable (timeout)>", elems => 0);
            } else {
                $display = CollectionDisplay.new(disp => "<$type: unreadable>", elems => 0);
            }
        }
        $display;
    }
}

method fetch-positionals(
    Int $handle,
    Int $thread,
    Bool :$is-lazy = False,
    Int :$start = 0,
    Int :$count = 0,
    Str :$parent-eval-name = ''
    --> Promise
) {
    start {
        my $p = await $!remote.positionals($handle, :$thread, :timeout(30));
        my @contents = ($p<contents> // []).flat;
        my Int $effective-count = $count > 0 ?? $count !! (@contents.elems > 1000 ?? 1000 !! @contents.elems);
        my @slice = page(@contents, $start, $effective-count);

        my Int $cur-idx = $start;
        my @items = @slice.map(-> %elem {
                %(
                    name => "{$cur-idx++}",
                    |%elem
                )
        });

        my @vars = await self.render-entries(@items, $thread, :kind('positional'), :$parent-eval-name);
        if $is-lazy {
            @vars.push(%(
                    name => '...',
                    value => '(lazy sequence)',
                    type => '',
                    variablesReference => 0
            ));
        }
        @vars;
    }
}

method fetch-associatives(
    Int $handle, Int $thread, Int :$start = 0, Int :$count = 0, Str :$parent-eval-name = '' --> Promise
) {
    start {
        my $p = await $!remote.associatives($handle, :$thread, :timeout(15));
        my %contents = $p<contents> // {};
        my @keys = %contents.keys.sort;
        my Int $effective-count = $count > 0 ?? $count !! (@keys.elems > 1000 ?? 1000 !! @keys.elems);
        my @slice-keys = page(@keys, $start, $effective-count);

        my @items = @slice-keys.map(-> $k {
                my %elem = %contents{$k};
                %(
                    name => $k,
                    |%elem
                )
        });

        my @vars = await self.render-entries(@items, $thread, :kind('associative'), :$parent-eval-name);
        if $count == 0 && @keys.elems > 1000 {
            my Int $remaining = @keys.elems - 1000;
            @vars.push(%(
                    name => '...',
                    value => "($remaining more)",
                    type => '',
                    variablesReference => 0
            ));
        }
        @vars;
    }
}

method expand-object(
    Int $raw-handle,
    Int $thread,
    Int :$start = 0,
    Int :$count = 0,
    Str :$filter = '',
    Str :$parent-eval-name = ''
    --> Promise
) {
    start {
        my $p-meta = await $!remote.metadata($raw-handle, :$thread);
        my %raw-meta = $p-meta<metadata> // {};
        my Str $raw-name = (%raw-meta<debug_name> // '').Str;

        my Int $target-handle = $raw-handle;
        if $raw-name eq 'Scalar' {
            my $p-decont = await $!remote.decont($raw-handle, :$thread);
            if $p-decont && $p-decont<handle> {
                $target-handle = $p-decont<handle>.Int;
                self.handles.record-handle($target-handle) if $target-handle > 0;
            }
        }

        my %meta = %raw-meta;
        if $target-handle != $raw-handle {
            my $p-tmeta = await $!remote.metadata($target-handle, :$thread);
            %meta = ($p-tmeta<metadata> // {}) if $p-tmeta;
        }
        my Str $debug-name = (%meta<debug_name> // '').Str;

        if $filter eq 'named' && %meta<pos_features> {
            [];
        }
        elsif $filter eq 'indexed' && (%meta<ass_features> || %meta<attr_features>) {
            [];
        }
        elsif %meta<pos_features> {
            await self.fetch-positionals($target-handle, $thread, :$start, :$count, :$parent-eval-name);
        }
        elsif %meta<ass_features> {
            await self.fetch-associatives($target-handle, $thread, :$start, :$count, :$parent-eval-name);
        }
        elsif %meta<attr_features> {
            await self!expand-object-attributes(
                $target-handle, $thread, $debug-name, :$filter, :$start, :$count, :$parent-eval-name
            );
        }
        else {
            [];
        }
    }
}

method !expand-object-attributes(
    Int $target-handle,
    Int $thread,
    Str $debug-name,
    Str :$filter = '',
    Int :$start = 0,
    Int :$count = 0,
    Str :$parent-eval-name = ''
    --> Promise
) {
    start {
        my $p-attr = await $!remote.attributes($target-handle, :$thread);
        my @attrs = ($p-attr<attributes> // []).flat;

        if $debug-name eq any(@POSITIONAL-TYPES) {
            if $filter eq 'named' {
                [];
            } else {
                my %todo = attribute-named(@attrs, '$!todo');
                my %iter = attribute-named(@attrs, '$!iter');
                my Bool $is-lazy = ((%todo && %todo<concrete>) || (%iter && %iter<concrete>)).Bool;
                my Int $reif-handle = $!remote.collection-storage($target-handle, :$thread);

                if $reif-handle > 0 {
                    await self.fetch-positionals(
                        $reif-handle, $thread, :$is-lazy, :$start, :$count, :$parent-eval-name
                    );
                } elsif $is-lazy {
                    [ %(
                            name => '...',
                            value => '(lazy sequence)',
                            type => '',
                            variablesReference => 0
                        ), ];
                } else {
                    [];
                }
            }
        }
        elsif $debug-name eq any(@ASSOCIATIVE-TYPES) {
            if $filter eq 'indexed' {
                [];
            } else {
                my Int $stor-handle = $!remote.collection-storage($target-handle, :$thread);
                if $stor-handle > 0 {
                    await self.fetch-associatives($stor-handle, $thread, :$start, :$count, :$parent-eval-name);
                } else {
                    [];
                }
            }
        }
        else {
            # General object (e.g. Person)
            if $filter eq 'indexed' {
                [];
            } else {
                my @attr-entries;
                for @attrs -> %a {
                    my Str $attr-name = (%a<name> // '').Str;
                    next if self.is-internal-lexical($attr-name);
                    @attr-entries.push(%( name => $attr-name, |%a ));
                }
                await self.render-entries(@attr-entries, $thread, :kind('attributes'), :$parent-eval-name);
            }
        }
    }
}

method render-value(
    Int $raw-handle,
    Int $thread,
    Str :$type = '',
    Str :$kind = '',
    Bool :$concrete = True,
    Bool :$is-container = False,
    Str :$raw-value = '',
    Str :$evaluate-name = ''
    --> Promise) {
    start {
        my Int $target-handle = $raw-handle;
        my Str $target-type = $type;
        my Str $target-kind = $kind;
        my Bool $target-concrete = $concrete;
        my Str $val-disp = $raw-value;

        if $target-type eq 'Rakudo::Internals::LoweredAwayLexical'
        || $val-disp.contains('LoweredAwayLexical')
        || $val-disp eq '<optimized out>' {
            %(
                value => '<optimized out>',
                type => '',
                variablesReference => 0
            );
        } else {

            # 1. Unpack container if indicated
            if ($is-container || $target-type eq 'Scalar') && $raw-handle > 0 {
                my $p-decont = attempt($!remote.decont($raw-handle, :$thread), 'decont');
                if $p-decont && $p-decont<handle>.defined {
                    $target-handle = $p-decont<handle>.Int;
                    self.handles.record-handle($target-handle) if $target-handle > 0;
                    my $p-meta = attempt($!remote.metadata($target-handle, :$thread), 'metadata');
                    if $p-meta {
                        my %meta = $p-meta<metadata> // {};
                        $target-type = (%meta<debug_name> // $target-type).Str;
                        $target-concrete = %meta<size>.defined.Bool;
                        $target-kind = 'obj';
                    }
                }
            }

            if $target-type eq '' && $target-kind ne '' {
                if $target-kind eq any('int', 'num', 'str') {
                    $target-type = $target-kind.tc;
                }
            }

            # 2. Native primitives or direct values without handle
            if ($val-disp ne '' || $target-kind eq 'str') && $target-handle <= 0 {
                if ($target-type eq 'Str' || $target-kind eq 'str') && $val-disp.chars > 200 {
                    $val-disp = $val-disp.substr(0, 200) ~ '...';
                }
                %(
                    value => ($val-disp eq '' ?? '""' !! $val-disp),
                    type => ($target-type ne '' ?? $target-type !! ($target-kind ne '' ?? $target-kind !! 'int')),
                    variablesReference => 0
                );
            }
            # 3. Type object / non-concrete
            elsif !$target-concrete {
                %(
                    value => "($target-type)",
                    type => $target-type,
                    variablesReference => 0
                );
            }
            # 4. Boxed primitives: Int, Str, Num, Bool
            elsif $target-type eq any('Int', 'Str', 'Num', 'Bool') {
                await self!render-boxed-primitive($target-handle, $thread, $target-type, $val-disp);
            }
            # 5. Positional / Associative collections
            elsif $target-type eq any(|@POSITIONAL-TYPES, |@ASSOCIATIVE-TYPES) {
                await self!render-collection-value($target-handle, $thread, $target-type, :$evaluate-name);
            }
            # 6. General objects
            else {
                my Int $obj-ref = 0;
                if $target-handle > 0 && $target-concrete {
                    $obj-ref = self.handles.allocate-object-ref(
                        $target-handle, :type($target-type), :kind('obj'), :$thread, :$evaluate-name
                    );
                }
                %(
                    value => ($target-type ne '' ?? "<$target-type>" !! "($target-kind)"),
                    type => $target-type,
                    variablesReference => $obj-ref
                );
            }
        }
    }
}

method !render-boxed-primitive(Int $target-handle, Int $thread, Str $target-type, Str $initial-val --> Promise) {
    start {
        my Str $val-disp = $initial-val;
        my Bool $read = $val-disp ne '';
        if $val-disp eq '' && $target-handle > 0 {
            my $p-attr = attempt($!remote.attributes($target-handle, :$thread), 'attributes');
            if $p-attr {
                my @attrs = ($p-attr<attributes> // []).flat;
                my %v = attribute-named(@attrs, '$!value');
                if %v<value>.defined {
                    $val-disp = %v<value>.Str;
                    $read = True;
                }
            }
        }
        if $target-type eq 'Str' && $val-disp.chars > 200 {
            $val-disp = $val-disp.substr(0, 200) ~ '...';
        }
        %(
            value => ($val-disp ne '' ?? $val-disp !! ($read && $target-type eq 'Str' ?? '""' !! "<$target-type>")),
            type => $target-type,
            variablesReference => 0
        );
    }
}

method !render-collection-value(
    Int $target-handle,
    Int $thread,
    Str $target-type,
    Str :$evaluate-name = ''
    --> Promise
) {
    start {
        my Int $obj-ref = 0;
        if $target-handle > 0 {
            $obj-ref = self.handles.allocate-object-ref(
                $target-handle, :type($target-type), :kind('obj'), :$thread, :$evaluate-name
            );
        }
        my $summary = await self.render-collection-display($target-handle, $thread, $target-type);
        my Int $elems = $summary.elems // 0;
        my Str $disp = $summary.disp // $summary.Str;
        my %res = %(
            value => $disp,
            type => $target-type,
            variablesReference => $obj-ref
        );
        set-child-counts(%res, $target-type, $elems);
        %res;
    }
}

method inspect-scalar(Int $handle, Int $thread --> Promise) {
    self.render-value($handle, $thread, :is-container(True));
}
