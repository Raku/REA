use v6.d;

#| Component handling MoarVM stop events, breakpoint conditions, logpoints, and event emission.
unit class Nimala::Raku-DAP::StopHandler;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Remote;
use Nimala::Raku-DAP::Trace;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::Expression;
use Nimala::Raku-DAP::ThreadState;
use Nimala::Raku-DAP::BreakpointRegistry ();
use Nimala::Raku-DAP::Stepping;
use Nimala::Raku-DAP::ExceptionState;

has Nimala::Raku-DAP::Protocol $.protocol is required;
has Nimala::Raku-DAP::Remote $.remote is required;
has Nimala::Raku-DAP::Handles $.handles is required;
has Nimala::Raku-DAP::ThreadRegistry $.threads is required;
has Nimala::Raku-DAP::BreakpointRegistry $.registry is required;
has Nimala::Raku-DAP::Stepping $.stepping is required;
has Nimala::Raku-DAP::ExceptionState $.exception-state is required;
has &.send-event is required;
has &.evaluate is required;
#| Returns a Promise kept with the raw user thread list (see `Translate.user-thread-list`).
has &.thread-list is required;


#| Returns True if a condition evaluation result string represents a truthy value in Raku.
our sub is-truthy(Str $res-val --> Bool) is export {
    so ($res-val eq 'True' || $res-val eq '1' || ($res-val ne 'False' && $res-val ne '0' && $res-val ne 'Nil' && $res-val ne ''))
}

method !emit-stop(
    Int $thread,
    Str $reason,
    Str :$description = '',
    Str :$text = '',
    :@hit-ids = ()
    --> Nil
) {
    if $!protocol.defined && $!remote.defined {
        try {
            my $tl-p = &!thread-list.defined
            ?? &!thread-list()
            !! $!remote.thread-list(:timeout(1)).then({ (.result<threads> // []).flat.Array });
            my @tl = (await Promise.anyof($tl-p, Promise.in(1))) === $tl-p && $tl-p.status ~~ Kept ?? $tl-p.result.list !! ();
            $!threads.sync-threads(@tl) if @tl;
        };
    }
    $!threads.emit-stopped($thread, $reason, :$description, :$text, :@hit-ids);
}

#| Auto-resume through the centralized leave-stop exit path (D3).
method !leave-stop(Int:D $thread = $!threads.stopped-thread --> Nil) {
    my $outcome = await $!stepping.leave-stop($thread, { $!remote.resume-all() });
    if $outcome ~~ Failed {
        &!send-event('output', %(
                category => 'console',
                output => "Could not resume the debuggee: {$outcome.cause}\n"
        )) if &!send-event.defined;
    }
}

#| Interpolate expression placeholders within a logMessage template.
method interpolate-log-message(Str $msg --> Str) {
    my Str $result = '';
    my Int $pos = 0;
    my Int $chars = $msg.chars;
    while $pos < $chars {
        my $open = $msg.index('{', $pos);
        if !$open.defined {
            $result ~= $msg.substr($pos);
            last;
        }
        $result ~= $msg.substr($pos, $open - $pos);
        my $close = $msg.index('}', $open);
        if !$close.defined {
            $result ~= $msg.substr($open);
            last;
        }
        my Str $inner = $msg.substr($open + 1, $close - $open - 1).trim;
        my $parsed = Nimala::Raku-DAP::Expression.parse($inner);
        if $parsed.success {
            my %eval-res = await &!evaluate($inner);
            if %eval-res<success> {
                $result ~= (%eval-res<result> // '').Str;
            } else {
                $result ~= '<not evaluatable>';
            }
        } else {
            $result ~= '<not evaluatable>';
        }
        $pos = $close + 1;
    }
    return $result;
}

method !extract-str-val(%lex-entry, Int $thread --> Str) {
    return '' unless %lex-entry;
    my %unwrapped = attempt($!remote.unwrap-value(%lex-entry, $thread), 'unwrap value') // %();
    return (%unwrapped<val> // %lex-entry<value> // '').Str;
}

#| Process a MoarVM stop event (types BreakpointHit, StepCompleted, UnhandledException).
method handle-stop(%ev --> Promise) {
    start {
        my Int $type = (%ev<type> // -1).Int;
        # FIRST action: Suspend All (5)
        attempt($!remote.suspend-all(), 'suspend all') if $!remote.defined;

        my Int $thread = (%ev<thread> // 1).Int;
        my $t-state = $!threads.thread-state($thread);
        $t-state.is-stopped = True;
        $!threads.stopped-thread = $thread;

        if $type == MoarMsg::UnhandledException.value && $!exception-state.defined {
            $!exception-state.record-exception(%ev, $t-state);
        }

        if $type == MoarMsg::BreakpointHit.value {
            self!handle-breakpoint-stop(%ev, $thread, $t-state);
        } else {
            self!handle-non-breakpoint-stop(%ev, $type, $thread, $t-state);
        }
    }
}

method !handle-breakpoint-stop(%ev, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    my Bool $handled = False;
    if $!registry.entry-bp-file ne '' {
        $handled = self!check-and-handle-entry-hit(%ev, $thread, $t-state);
    }

    unless $handled {
        my Int $bp-id = (%ev<id> // -1).Int;
        if $!stepping.is-sweep-breakpoint($bp-id) {
            self!handle-sweep-hit($bp-id, $thread, $t-state);
        } else {
            my %registered-bp = $!registry.moar-id-to-info{$bp-id} // %();
            my Str $kind = (%registered-bp<kind> // '').Str;
            my Bool $is-uncaught-exc = ($!registry.uncaught-exception-bp-id > 0 && $bp-id == $!registry.uncaught-exception-bp-id)
            || $kind eq 'exception-uncaught';
            my Bool $is-all-exc = ($!registry.all-exception-bp-id > 0 && $bp-id == $!registry.all-exception-bp-id)
            || $kind eq 'exception-all';

            if $is-uncaught-exc || $is-all-exc {
                self!handle-exception-hit($is-uncaught-exc, $thread, $t-state);
            } else {
                self!handle-user-breakpoint-hit(%registered-bp, $thread, $t-state);
            }
        }
    }
}

method !check-and-handle-entry-hit(%ev, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Bool) {
    my %trace = attempt($!remote.stack-trace($thread), 'stack trace') // %();
    my @frames = (%trace<frames> // []).list;
    my %top = @frames.elems > 0 && @frames[0] ~~ Associative ?? %(@frames[0]) !! %();
    my Str $top-file = (%top<file> // '').Str;
    my Int $top-line = (%top<line> // 0).Int;
    my Int $ev-bp-id = (%ev<id> // -1).Int;
    my Bool $is-entry-hit = attempt($!registry.check-and-clear-entry-hit($!protocol, $ev-bp-id, $top-file, $top-line), 'check and clear entry hit');
    if $is-entry-hit {
        $t-state.set-stop-location($top-file, $top-line);
        self!emit-stop($thread, 'entry');
        return True;
    }
    return False;
}

method !handle-sweep-hit(Int $bp-id, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    my %sweep-info = $!stepping.get-sweep-breakpoint($bp-id);
    my Str $exact-file = (%sweep-info<file> // '').Str;
    my Int $exact-line = (%sweep-info<line> // 0).Int;
    my Int $step-thread = (%sweep-info<thread> // 0).Int;

    # Sweep thread affinity (DK-10, Task 3.3):
    if $step-thread > 0 && $thread != $step-thread {
        self!leave-stop($thread);
        return;
    }

    my $sc = $t-state.step-context;
    my Str $mode = $sc.mode;

    my %trace = attempt($!remote.stack-trace($thread), 'stack trace') // %();
    my @frames = (%trace<frames> // []).list;
    my Int $cur-depth = @frames.elems;

    if ($mode eq 'next' && (%sweep-info<scope> // '') ne 'mainline' && $cur-depth > $sc.start-depth)
    || ($mode eq 'stepOut' && $cur-depth >= $sc.start-depth) {
        self!leave-stop($thread);
        return;
    }

    $sc.reset;

    $t-state.set-stop-location($exact-file, $exact-line);
    self!emit-stop($thread, 'step');
}

method !handle-exception-hit(Bool $is-uncaught-exc, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    my Str $ex-name = 'Exception';
    my Str $ex-msg = 'Unhandled exception';
    my Str $ex-bt = '';
    my Int $ex-handle = 0;

    my $ctx-res = attempt($!remote.context($thread, 0), 'context');
    if $ctx-res && $ctx-res<handle> {
        my Int $ctx-h = $ctx-res<handle>.Int;
        $!handles.record-handle($ctx-h) if $ctx-h > 0;
        my $lex-res = attempt($!remote.lexicals($ctx-h), 'lexicals');
        if $lex-res && $lex-res<lexicals> {
            my %lex = $lex-res<lexicals>;
            if %lex{'$ex-name'}:exists {
                my $n = self!extract-str-val(%lex{'$ex-name'}, $thread);
                $ex-name = $n if $n ne '';
            }
            if %lex{'$ex-msg'}:exists {
                my $m = self!extract-str-val(%lex{'$ex-msg'}, $thread);
                $ex-msg = $m if $m ne '';
            }
            if %lex{'$ex-bt'}:exists {
                my $bt = self!extract-str-val(%lex{'$ex-bt'}, $thread);
                $ex-bt = $bt if $bt ne '';
            }
            if %lex{'$captured'}:exists {
                my %c = %lex{'$captured'};
                my Int $ch = (%c<handle> // 0).Int;
                if $ch > 0 {
                    $!handles.record-handle($ch);
                    my $p-attr = attempt($!remote.attributes($ch, :$thread), 'attributes');
                    if $p-attr && $p-attr<attributes> {
                        my %v = attribute-named($p-attr<attributes> // [], '$!value');
                        if %v<handle>.defined && %v<handle> > 0 {
                            $ex-handle = %v<handle>.Int;
                        }
                    }
                    $ex-handle = $ch if $ex-handle == 0;
                }
            }
        }
    }

    my Str $filter-id = $is-uncaught-exc ?? 'uncaught' !! 'all';
    my Str $cond = ($!registry.exception-filter-conditions{$filter-id} // '').Str.trim;
    if $cond ne '' {
        my %eval-res = await &!evaluate($cond);
        if %eval-res<success> {
            my Str $res-val = (%eval-res<result> // '').Str;
            if !is-truthy($res-val) {
                self!leave-stop($thread);
                return;
            }
        } else {
            $ex-msg ~= " (Breakpoint condition failed: " ~ (%eval-res<message> // '') ~ ")";
        }
    }

    my Str $break-mode = $is-uncaught-exc ?? 'unhandled' !! 'always';
    $t-state.is-stopped = True;
    $t-state.stop-reason = 'exception';
    $t-state.last-exception-handle = $ex-handle;
    $t-state.last-exception-type = $ex-name;
    $t-state.last-exception-message = $ex-msg;
    $t-state.last-exception-backtrace = $ex-bt;
    $t-state.last-exception-break-mode = $break-mode;

    my @parsed-frames = $!exception-state.parse-backtrace($ex-bt);
    $t-state.frames = @parsed-frames.Array;
    if @parsed-frames.elems > 0 {
        $t-state.set-stop-location(@parsed-frames[0]<file>, @parsed-frames[0]<line>);
    } else {
        $t-state.set-stop-location;
    }

    my Str $text = $ex-name ne '' ?? "$ex-name: $ex-msg" !! $ex-msg;
    self!emit-stop($thread, 'exception', :description($ex-msg), :$text);
}

method !ensure-frames(Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Array) {
    if $t-state.frames.defined && $t-state.frames.elems > 0 {
        return $t-state.frames;
    }
    my $trace-res = attempt($!remote.stack-trace($thread), 'stack trace');
    my %trace = ($trace-res.defined && $trace-res ~~ Associative) ?? %$trace-res !! %();
    my @frames = (%trace<frames> // []).list;
    $t-state.frames = @frames.Array;
    return $t-state.frames;
}

method !handle-user-breakpoint-hit(%registered-bp, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    $t-state.step-context.reset;

    my Str $cur-file = (%registered-bp<file> // '').Str;
    my Int $cur-line = (%registered-bp<line> // 0).Int;

    if $cur-file eq '' || $cur-line <= 0 {
        my @frames = self!ensure-frames($thread, $t-state);
        my %top = @frames.elems > 0 && @frames[0] ~~ Associative ?? %(@frames[0]) !! %();
        $cur-file = (%top<file> // '').Str;
        $cur-line = (%top<line> // 0).Int;
    }

    if %registered-bp<line>.defined {
        $t-state.set-stop-location(%registered-bp<file>.Str, %registered-bp<line>.Int);
    } else {
        $t-state.set-stop-location;
    }

    my %func-bp = $!registry.find-function-breakpoint($cur-file, $cur-line);
    if %func-bp {
        self!handle-function-bp-hit(%func-bp, $cur-file, $cur-line, $thread, $t-state);
    } else {
        self!handle-line-bp-hit($cur-file, $cur-line, $thread, $t-state);
    }
}

#| Shared evaluation of hitCondition, condition, and truthiness (M-1).
method !evaluate-bp-conditions(%bp, Str $file, Int $line --> Hash) {
    my Str $hit-cond = (%bp<hitCondition> // '').Str.trim;
    if $hit-cond ne '' {
        my Bool $hit-ok = $!registry.evaluate-hit-condition($hit-cond, $file, $line);
        if !$hit-ok {
            return %( should-stop => False, description => '' );
        }
    }

    my Str $cond = (%bp<condition> // '').Str.trim;
    if $cond ne '' {
        my %eval-res = await &!evaluate($cond);
        if !%eval-res<success> {
            return %( should-stop => True, description => "Breakpoint condition failed: " ~ (%eval-res<message> // '') );
        }
        my Str $res-val = (%eval-res<result> // '').Str;
        if !is-truthy($res-val) {
            return %( should-stop => False, description => '' );
        }
    }

    return %( should-stop => True, description => '' );
}

method !handle-function-bp-hit(%func-bp, Str $cur-file, Int $cur-line, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    my Str $fbp-file = (%func-bp<file> // $cur-file).Str;
    my Int $fbp-line = (%func-bp<line> // $cur-line).Int;
    my %cond-res = self!evaluate-bp-conditions(%func-bp, $fbp-file, $fbp-line);

    if !%cond-res<should-stop> {
        self!leave-stop($thread);
    } else {
        self!ensure-frames($thread, $t-state);
        my Int $fbp-id = (%func-bp<id> // %func-bp<dap-id> // 0).Int;
        my @hit-ids = $fbp-id > 0 ?? [ $fbp-id ] !! ();
        my Str $desc = %cond-res<description> // '';
        self!emit-stop($thread, 'function breakpoint', :description($desc), :@hit-ids);
    }
}

method !handle-line-bp-hit(Str $cur-file, Int $cur-line, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    my %matching-bp = $!registry.find-line-breakpoint($cur-file, $cur-line);
    my %cond-res = self!evaluate-bp-conditions(%matching-bp, $cur-file, $cur-line);

    if !%cond-res<should-stop> {
        self!leave-stop($thread);
    } else {
        self!ensure-frames($thread, $t-state);
        my Str $log-msg = (%matching-bp<logMessage> // '').Str;
        if $log-msg ne '' {
            my Str $interpolated = self.interpolate-log-message($log-msg);
            $interpolated ~= "\n" unless $interpolated.ends-with("\n");
            &!send-event('output', %(
                    category => 'console',
                    output => $interpolated,
                    source => %( name => $cur-file.IO.basename, path => $cur-file ),
                    line => $cur-line
            ));
            self!leave-stop($thread);
        } else {
            my Int $matched-id = (%matching-bp<id> // %matching-bp<dap-id> // 0).Int;
            my @hit-ids = $matched-id > 0 ?? [ $matched-id ] !! ();
            my Str $desc = %cond-res<description> // '';
            self!emit-stop($thread, 'breakpoint', :description($desc), :@hit-ids);
        }
    }
}

method !handle-non-breakpoint-stop(%ev, Int $type, Int $thread, Nimala::Raku-DAP::ThreadState $t-state --> Nil) {
    $t-state.set-stop-location;

    if $type == MoarMsg::StepCompleted.value {
        my @ev-frames = (%ev<frames> // []).list;
        await $!stepping.handle-step-notification($thread, @ev-frames);
    } else {
        my Bool $skip-stop = False;
        if $type == MoarMsg::UnhandledException.value {
            my @filters = ($!registry.exception-filters // []).list;
            if !@filters.grep(* eq any('all', 'uncaught')) {
                $skip-stop = True;
                self!leave-stop($thread);
            } else {
                my Str $all-cond = ($!registry.exception-filter-conditions{'all'} // '').Str.trim;
                if $all-cond ne '' {
                    my %eval-res = await &!evaluate($all-cond);
                    if %eval-res<success> {
                        my Str $res-val = (%eval-res<result> // '').Str;
                        if !is-truthy($res-val) {
                            $skip-stop = True;
                            self!leave-stop($thread);
                        }
                    }
                }
            }
        }

        unless $skip-stop {
            my Str $reason = do given $type {
                when MoarMsg::UnhandledException.value { 'exception' }
                default { 'pause' }
            };
            self!emit-stop($thread, $reason);
        }
    }
}
