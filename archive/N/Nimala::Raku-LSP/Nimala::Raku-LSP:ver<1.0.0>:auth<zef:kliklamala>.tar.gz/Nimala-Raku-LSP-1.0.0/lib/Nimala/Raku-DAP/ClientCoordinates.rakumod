use v6.d;
unit class Nimala::Raku-DAP::ClientCoordinates;

use Nimala::URI;

has Bool $.lines-start-at1 = True;
has Bool $.columns-start-at1 = True;
has Str $.path-format = 'path';
has Bool $.supports-variable-type = False;

method identity(--> Bool) {
    $!lines-start-at1 && $!columns-start-at1 && $!path-format eq 'path';
}

method negotiate(%initialize-args --> Str) {
    $!lines-start-at1 = %initialize-args<linesStartAt1>:exists
    ?? ?%initialize-args<linesStartAt1>
    !! True;
    $!columns-start-at1 = %initialize-args<columnsStartAt1>:exists
    ?? ?%initialize-args<columnsStartAt1>
    !! True;
    $!supports-variable-type = %initialize-args<supportsVariableType>:exists
    ?? ?%initialize-args<supportsVariableType>
    !! False;
    my Str $fmt = (%initialize-args<pathFormat> // 'path').Str;
    if $fmt ne 'path' && $fmt ne 'uri' {
        return "Unsupported pathFormat '$fmt'; expected 'path' or 'uri'";
    }
    $!path-format = $fmt;
    Str;
}

method in-line(Int $line --> Int) {
    !$!lines-start-at1 ?? $line + 1 !! $line;
}

method to-client-line(Int $line --> Int) {
    $line > 0 && !$!lines-start-at1 ?? $line - 1 !! $line;
}

method to-client-column(Int $col --> Int) {
    $col > 0 && !$!columns-start-at1 ?? $col - 1 !! $col;
}

method in-path(Str $path --> Str) {
    return $path if $path eq '';
    if $path.starts-with('file://') {
        return (try { uri-to-path($path).Str }) // $path;
    }
    $path;
}

method to-client-path(Str $path --> Str) {
    return $path if $path eq '' || $!path-format ne 'uri';
    return $path if $path.starts-with('file://');
    try { path-to-uri($path.IO) } // $path;
}

method response(%req, %body --> Hash) {
    my Str $cmd = (%req<command> // '').Str;
    if self.identity && ($cmd ne 'variables' || $!supports-variable-type) {
        return %body;
    }
    my %out = %body;
    if ($cmd eq 'setBreakpoints' || $cmd eq 'setFunctionBreakpoints' || $cmd eq 'breakpointLocations') && (%body<breakpoints>:exists) {
        my @bps = (%body<breakpoints> // []).map: -> %b {
            my %nb = %b;
            if (%nb<line>:exists) && %nb<line>.defined {
                %nb<line> = self.to-client-line(%nb<line>.Int);
            }
            if (%nb<source>:exists) && %nb<source> ~~ Associative && (%nb<source><path>:exists) {
                my %ns = %nb<source>;
                %ns<path> = self.to-client-path(%ns<path>.Str);
                %nb<source> = %ns;
            }
            %nb;
        };
        %out = %( |%body, breakpoints => @bps );
    } elsif $cmd eq 'stackTrace' && (%body<stackFrames>:exists) {
        my @frames = (%body<stackFrames> // []).map: -> %f {
            my %nf = %f;
            if (%nf<line>:exists) && %nf<line>.defined {
                %nf<line> = self.to-client-line(%nf<line>.Int);
            }
            if (%nf<column>:exists) && %nf<column>.defined {
                %nf<column> = self.to-client-column(%nf<column>.Int);
            }
            if (%nf<source>:exists) && %nf<source> ~~ Associative && (%nf<source><path>:exists) {
                my %ns = %nf<source>;
                %ns<path> = self.to-client-path(%ns<path>.Str);
                %nf<source> = %ns;
            }
            %nf;
        };
        %out = %( |%body, stackFrames => @frames );
    } elsif $cmd eq 'variables' && !$!supports-variable-type && (%body<variables>:exists) {
        my @vars = (%body<variables> // []).map: -> %v {
            my %nv = %v;
            %nv<type>:delete;
            %nv;
        };
        %out = %( |%body, variables => @vars );
    }
    %out;
}

method event(Str $event, %body --> Hash) {
    return %body if self.identity;
    my %out = %body;
    if $event eq 'breakpoint' && (%body<breakpoint>:exists) && %body<breakpoint> ~~ Associative {
        my %nb = %body<breakpoint>;
        if (%nb<line>:exists) && %nb<line>.defined {
            %nb<line> = self.to-client-line(%nb<line>.Int);
        }
        if (%nb<source>:exists) && %nb<source> ~~ Associative && (%nb<source><path>:exists) {
            my %ns = %nb<source>;
            %ns<path> = self.to-client-path(%ns<path>.Str);
            %nb<source> = %ns;
        }
        %out = %( |%body, breakpoint => %nb );
    } elsif $event eq 'output' {
        my %no = %body;
        my Bool $changed = False;
        if (%no<line>:exists) && %no<line>.defined {
            %no<line> = self.to-client-line(%no<line>.Int);
            $changed = True;
        }
        if (%no<source>:exists) && %no<source> ~~ Associative && (%no<source><path>:exists) {
            my %ns = %no<source>;
            %ns<path> = self.to-client-path(%ns<path>.Str);
            %no<source> = %ns;
            $changed = True;
        }
        %out = %no if $changed;
    }
    %out;
}
