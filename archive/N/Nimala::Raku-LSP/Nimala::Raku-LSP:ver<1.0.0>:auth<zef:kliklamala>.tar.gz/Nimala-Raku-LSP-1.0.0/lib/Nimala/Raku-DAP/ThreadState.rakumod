use v6.d;

use Nimala::Raku-DAP::Protocol::Messages;

#| Encapsulates active stepping operations for a specific thread
class Nimala::Raku-DAP::StepContext {
    has Str $.mode is rw = ''; # 'next', 'stepIn', 'stepOut'
    has Int $.thread-id is required;
    has Int $.start-depth is rw = 0;
    has Str $.origin-file is rw = '';
    has Int $.origin-line is rw = 0;
    has Int $.last-step-type is rw = MoarMsg::StepOver.value;
    has Int $.current-skip-count is rw = 0;
    has SetHash $.sweep-ids .= new;

    method reset(--> Nil) {
        $!mode = '';
        $!start-depth = 0;
        $!origin-file = '';
        $!origin-line = 0;
        $!sweep-ids = SetHash.new;
    }
}

#| Represents the stop and execution state of an individual debuggee thread.
class Nimala::Raku-DAP::ThreadState {
    has Int $.thread-id is required;
    has Str $.name is rw = '';
    has Bool $.is-stopped is rw = False;
    has Str $.stop-reason is rw = '';
    has Str $.stopped-file is rw = '';
    has Int $.stopped-breakpoint-line is rw = 0;
    has Array $.frames is rw = Array.new;
    has Int $.last-exception-handle is rw = 0;
    has Str $.last-exception-type is rw = '';
    has Str $.last-exception-message is rw = '';
    has Str $.last-exception-backtrace is rw = '';
    has Str $.last-exception-break-mode is rw = 'unhandled';
    has Nimala::Raku-DAP::StepContext $.step-context;

    submethod TWEAK() {
        $!step-context //= Nimala::Raku-DAP::StepContext.new(thread-id => $!thread-id);
    }

    method set-stop-location(Str $file = '', Int $line = 0 --> Nil) {
        $!stopped-file = $file;
        $!stopped-breakpoint-line = $line;
    }

    method reset-stop(--> Nil) {
        $!is-stopped = False;
        $!stop-reason = '';
        self.set-stop-location;
        $!frames = Array.new;
        $!last-exception-handle = 0;
        $!last-exception-type = '';
        $!last-exception-message = '';
        $!last-exception-backtrace = '';
        $!last-exception-break-mode = 'unhandled';
    }
}

#| Central registry managing per-thread state, stop emission, and thread lifecycle events.
class Nimala::Raku-DAP::ThreadRegistry {
    has Int $.stopped-thread is rw = 1;
    has &.send-event;
    has %!threads;
    has SetHash $!known-thread-ids .= new;
    has Lock $!lock .= new;

    method thread-state(Int $thread-id --> Nimala::Raku-DAP::ThreadState) {
        $!lock.protect: { %!threads{$thread-id} //= Nimala::Raku-DAP::ThreadState.new(thread-id => $thread-id) }
    }

    method all(--> Array) {
        $!lock.protect: { %!threads.values.Array }
    }

    #| Returns the thread ID of any other thread that is user-stopped (is-stopped && stop-reason ne ''), or 0 if none.
    method other-stopped-thread(Int $exclude --> Int) {
        $!lock.protect: {
            for %!threads.values -> $ts {
                if $ts.thread-id != $exclude && $ts.is-stopped && $ts.stop-reason ne '' {
                    return $ts.thread-id;
                }
            }
            return 0;
        }
    }

    method reset-stop(Int $thread-id = $!stopped-thread --> Nil) {
        self.thread-state($thread-id).reset-stop;
    }

    #| Every resume is Resume All, so every thread's stop state goes stale at once (D-20). Step contexts are kept.
    method reset-all-stops(--> Nil) {
            .reset-stop for self.all;
    }

    method emit-stopped(
        Int $thread,
        Str $reason,
        Str :$description = '',
        Str :$text = '',
        :@hit-ids = ()
        --> Nil
    ) {
        $!stopped-thread = $thread;
        my $ts = self.thread-state($thread);
        $ts.is-stopped = True;
        $ts.stop-reason = $reason;
        $ts.step-context.current-skip-count = 0 if $ts.step-context.defined;

        my %body = %(
            :$reason,
            threadId => $thread,
            allThreadsStopped => True,
        );
        %body<description> = $description if $description ne '';
        %body<text> = $text if $text ne '';
        %body<hitBreakpointIds> = @hit-ids.Array if @hit-ids.elems > 0;

        &!send-event('stopped', %body) if &!send-event.defined;
    }

    #| True for a Rakudo thread-pool worker (pthread names are cut to 15 characters). Workers run user code
    #| (`start`, timers, signal taps) but also sit idle; `Translate.user-thread-list` decides by their stack.
    method is-pool-worker(%raw --> Bool) {
        so ($_ // '') ~~ / ^ \d+ ':' \s* [ 'GeneralWork' | 'TimerWorker' | 'AffinityWork' ] / given %raw<name>;
    }

    method filter-user-threads(@raw-threads --> Array) {
        my @threads = @raw-threads.grep({
                my Str $name = ($_<name> // '').lc;
                !$name.contains('debugserver') &&
                !$name.contains('debug-server') &&
                !$name.contains('spesh') &&
                # Runtime threads that never run user code
                $name ne 'async io thread' &&
                $name !~~ / ^ \d+ ':' \s* 'supervisor' /
        }).map({
                %(
                    id => ($_<thread> // $_<id> // 1).Int,
                    name => ($_<name> // "Thread {$_<thread> // $_<id> // 1}").Str
                )
        });
        @threads = ( %( id => 1, name => 'raku' ), ) unless @threads;
        return @threads.Array;
    }

    method sync-threads(@raw-threads --> Array) {
        my @user-threads = self.filter-user-threads(@raw-threads);
        my @new-events;

        $!lock.protect: {
            my SetHash $current-ids .= new;
            for @user-threads -> %t {
                my Int $id = %t<id>.Int;
                $current-ids.set($id);
                if !$!known-thread-ids{$id} {
                    $!known-thread-ids.set($id);
                    @new-events.push(%( reason => 'started', threadId => $id ));
                }
            }

            for $!known-thread-ids.keys -> $k {
                my Int $id = $k.Int;
                if !$current-ids{$id} {
                    $!known-thread-ids.unset($id);
                    @new-events.push(%( reason => 'exited', threadId => $id ));
                }
            }
        };

        if &!send-event.defined {
            for @new-events -> %ev {
                &!send-event('thread', %ev);
            }
        }

        return @user-threads;
    }
}
