use v6.d;
unit class Nimala::Raku-DAP::Remote;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::Trace;

has Nimala::Raku-DAP::Protocol $.protocol;
has Nimala::Raku-DAP::Handles $.handles is required;

has %!helpers;
has Lock $!helper-lock = Lock.new;

my constant AT-MOST-ONE-MESSAGE =
"MoarVM supports at most one evaluation per stop. Step or resume to evaluate again.";

# --- Cached Reads ---

#| Sends %req once per stop (replies are cached by request identity) and records the handles &collect finds in the
#| reply, so they are released when execution resumes. A failed request breaks the returned Promise.
method !cached-read(%req, &collect, Real :$timeout --> Promise) {
    my Str $key = %req<type thread handle frame>.map({ $_ // '' }).join('|');
    $!handles.cached-reply($key, {
            $!protocol.send-request(%req, :$timeout).then(-> $p {
                    my %res = $p.result;
                    $!handles.record-handle($_) for collect(%res).grep({ .defined && $_ > 0 })».Int;
                    %res;
            });
    });
}

sub no-handles(% --> List) { () }
sub own-handle(%res --> List) { (%res<handle> // 0,) }

#| Looks up an attribute by name in a MoarVM attributes list, returning the attribute Hash or empty Hash.
our sub attribute-named(@attrs, Str:D $name --> Hash) is export {
    my $found = @attrs.flat.first({ ($_<name> // '') eq $name });
    $found.defined && $found ~~ Associative ?? %($found) !! Hash.new;
}

#| Resolves the backing storage handle for collections: $!reified for positional, $!storage for associative, or 0.
method collection-storage(Int:D $handle, Int:D :$thread! --> Int) {
    return 0 unless $handle > 0;
    my $p-attr = attempt(self.attributes($handle, :$thread), 'attributes');
    return 0 unless $p-attr && $p-attr<attributes>;
    my %found = attribute-named($p-attr<attributes> // [], '$!reified');
    %found = attribute-named($p-attr<attributes> // [], '$!storage') unless %found;
    (%found<handle> // 0).Int;
}

method context(Int:D $thread, Int:D $frame, Real :$timeout = 5 --> Promise) {
    self!cached-read(msg-context($thread, $frame), &own-handle, :$timeout);
}

method lexicals(Int:D $ctx-handle, Real :$timeout = 5 --> Promise) {
    $!handles.record-handle($ctx-handle) if $ctx-handle > 0;
    self!cached-read(msg-lexicals($ctx-handle), { (.<lexicals> // {}).values.map(*<handle>).List }, :$timeout);
}

method outer-context(Int:D $ctx-handle, Real :$timeout = 2 --> Promise) {
    $!handles.record-handle($ctx-handle) if $ctx-handle > 0;
    self!cached-read(msg-outer-context($ctx-handle), &own-handle, :$timeout);
}

method attributes(Int:D $handle, Int:D :$thread!, Real :$timeout = 5 --> Promise) {
    $!handles.record-handle($handle) if $handle > 0;
    self!cached-read(msg-attributes($handle, :$thread), { (.<attributes> // []).map(*<handle>).List }, :$timeout);
}

method decont(Int:D $handle, Int:D :$thread!, Real :$timeout = 5 --> Promise) {
    $!handles.record-handle($handle) if $handle > 0;
    self!cached-read(msg-decont($handle, :$thread), &own-handle, :$timeout);
}

method metadata(Int:D $handle, Int:D :$thread!, Real :$timeout = 5 --> Promise) {
    $!handles.record-handle($handle) if $handle > 0;
    self!cached-read(msg-metadata($handle, :$thread), &no-handles, :$timeout);
}

method positionals(Int:D $handle, Int:D :$thread!, Real :$timeout = 30 --> Promise) {
    $!handles.record-handle($handle) if $handle > 0;
    self!cached-read(msg-positionals($handle, :$thread), &no-handles, :$timeout);
}

method associatives(Int:D $handle, Int:D :$thread!, Real :$timeout = 15 --> Promise) {
    $!handles.record-handle($handle) if $handle > 0;
    self!cached-read(msg-associatives($handle, :$thread), &no-handles, :$timeout);
}

# --- Compound Helpers ---

method is-setting-lexpad(%lex --> Bool) {
    if %lex.elems > 500
    || (%lex<EXPORT>:exists)
    || (%lex<GLOBALish>:exists)
    || (%lex<CORE>:exists)
    || (%lex<SETTING::>:exists) {
        return True;
    }
    return False;
}

method walk-outer-contexts(Int:D $start-handle, Int :$max-depth = 32 --> Promise) {
    start {
        my @handles;
        my Int $current = $start-handle;
        my Int $depth = 0;
        while $current > 0 && $depth < $max-depth {
            @handles.push($current);
            $!handles.record-handle($current);
            $depth++;

            my $lex-p = self.lexicals($current, :timeout(2));
            my $outer-p = self.outer-context($current, :timeout(2));

            my $lex-res = attempt($lex-p, 'lexicals');
            if $lex-res && $lex-res<lexicals> {
                last if self.is-setting-lexpad($lex-res<lexicals>);
            }

            my $res = attempt($outer-p, 'outer context');
            last unless $res && $res<handle>.defined;
            $current = $res<handle>.Int;
        }
        @handles;
    }
}

method find-lexical(Int:D $start-handle, Str:D $name, Int :$max-depth = 8 --> Promise) {
    start {
        my Int $current = $start-handle;
        my Int $depth = 0;
        my %entry;
        my Bool $found = False;

        while $current > 0 && $depth < $max-depth {
            $!handles.record-handle($current);
            $depth++;

            my $lex-p = self.lexicals($current, :timeout(2));
            my $outer-p = self.outer-context($current, :timeout(2));

            my $lex-res = attempt($lex-p, 'lexicals');
            if $lex-res && $lex-res<lexicals> {
                my %lex = $lex-res<lexicals>;
                if %lex{$name}:exists {
                    %entry = %lex{$name};
                    $found = True;
                    last;
                }
                last if self.is-setting-lexpad(%lex);
            }

            my $res = attempt($outer-p, 'outer context');
            last unless $res && $res<handle>.defined;
            $current = $res<handle>.Int;
        }

        $found ?? %( :$found, :%entry ) !! %( found => False );
    }
}

method unwrap-value(%entry, Int $thread = 1 --> Promise) {
    start {
        my %cur = %entry;
        my Str $cur-kind = (%cur<kind> // '').Str;
        my Str $cur-type = (%cur<type> // '').Str;
        my Str $cur-val  = (%cur<value> // '').Str;
        my Bool $concrete = (%cur<concrete> // True).Bool;
        my Int $cur-handle = (%cur<handle> // 0).Int;

        if $cur-type eq 'Scalar' && %cur<container> && $cur-handle > 0 {
            my $d = attempt(self.decont($cur-handle, :$thread), 'decont');
            if $d && $d<handle>.defined {
                $cur-handle = $d<handle>.Int;
                my $pm = attempt(self.metadata($cur-handle, :$thread), 'metadata');
                $cur-type = ($pm<metadata><debug_name> // '').Str if $pm;
                $concrete = attempt(self.attributes($cur-handle, :$thread), 'attributes').defined;
            }
        }
        if ($cur-type eq any('Int', 'Str', 'Num', 'Bool') || $cur-type eq '') && $cur-val eq '' && $cur-handle > 0 {
            my $pa = attempt(self.attributes($cur-handle, :$thread), 'attributes');
            if $pa && $pa<attributes> {
                my %v1 = attribute-named($pa<attributes> // [], '$!value');
                if %v1 {
                    if %v1<value>.defined && %v1<value> ne '' {
                        $cur-val = %v1<value>.Str;
                    } elsif %v1<handle>.defined && %v1<handle> > 0 {
                        my Int $h2 = %v1<handle>.Int;
                        my $pa2 = attempt(self.attributes($h2, :$thread), 'attributes');
                        if $pa2 && $pa2<attributes> {
                            my %v2 = attribute-named($pa2<attributes> // [], '$!value');
                            $cur-val = %v2<value>.Str if %v2 && %v2<value>.defined;
                        }
                    }
                }
            }
        }
        hash(
            cur => %cur,
            kind => $cur-kind,
            type => $cur-type,
            val => $cur-val,
            concrete => $concrete,
            handle => $cur-handle
        );
    }
}

method read-failure-message(Any $err, Str $what --> Str) {
    if ($err ~~ Promise && $err.status == Broken && $err.cause ~~ X::MoarVM::Timeout)
    || ($err ~~ X::MoarVM::Timeout) {
        "Timed out reading the $what of the collection from the debuggee";
    } elsif $err ~~ Exception {
        $err.message;
    } else {
        "Could not read the $what of the collection from the debuggee";
    }
}

# --- Control, Stepping, and Breakpoint Methods ---

method suspend-all(:$timeout = 5 --> Promise) {
    $!protocol.send-request(msg-suspend-all(), :$timeout);
}

method resume-all(:$timeout = 5 --> Promise) {
    $!handles.clear-replies;
    $!protocol.send-request(msg-resume-all(), :$timeout);
}

method thread-list(Real :$timeout = 5 --> Promise) {
    self!cached-read(msg-thread-list(), &no-handles, :$timeout);
}

method stack-trace(Int:D $thread, Real :$timeout = 5 --> Promise) {
    self!cached-read(msg-stack-trace($thread), &no-handles, :$timeout);
}

method set-breakpoint(
    Str:D $file, Int:D $line, Bool :$suspend = True, Bool :$stacktrace = False, :$timeout = 5 --> Promise
) {
    $!protocol.send-request(msg-breakpoint-set($file, $line, :$suspend, :$stacktrace), :$timeout);
}

method clear-breakpoint(Str:D $file, Int:D $line, :$timeout = 5 --> Promise) {
    $!protocol.send-request(msg-breakpoint-clear($file, $line), :$timeout);
}

method step-into(Int:D $thread, :$timeout = 5 --> Promise) {
    $!handles.clear-replies;
    $!protocol.send-request(msg-step-into($thread), :$timeout);
}

method step-over(Int:D $thread, :$timeout = 5 --> Promise) {
    $!handles.clear-replies;
    $!protocol.send-request(msg-step-over($thread), :$timeout);
}

method step-out(Int:D $thread, :$timeout = 5 --> Promise) {
    $!handles.clear-replies;
    $!protocol.send-request(msg-step-out($thread), :$timeout);
}

method step-raw(Int:D $thread, Int:D $type, :$timeout = 5 --> Promise) {
    $!handles.clear-replies;
    $!protocol.send-request(msg-step-raw($thread, $type), :$timeout);
}

#| Ends the current stop's handle registry and sends one Release Handles (24) for what it held.
method end-stop(Real :$timeout = 5 --> Promise) {
    my @handles = $!handles.end-stop;
    @handles && $!protocol.defined
    ?? $!protocol.send-request(msg-release-handles(@handles), :$timeout)
    !! Promise.kept(True);
}

#| Resolves helper routines, pins their \$!do handles, and caches them for the connection (D4, D5).
method helper-handle(Str:D $name, Int:D $thread = 1 --> Promise) {
    my $cached = $!helper-lock.protect: { %!helpers{$name} };
    return Promise.kept($cached) if $cached.defined && $cached > 0;

    start {
        my Int $code-handle = 0;
        my $ctx-res = attempt(self.context($thread, 0), 'context');
        if $ctx-res && $ctx-res<handle>.defined {
            my Int $start-ctx = $ctx-res<handle>.Int;
            my @contexts = await self.walk-outer-contexts($start-ctx);

            my sub extract-code-handle(%lex, Str $target-key --> Int) {
                return 0 unless (%lex{$target-key}:exists) && %lex{$target-key}<handle>.defined;
                my Int $sub-handle = %lex{$target-key}<handle>.Int;
                my $attr-res = attempt(self.attributes($sub-handle, :$thread), 'attributes');
                if $attr-res && $attr-res<attributes> {
                    my %do = attribute-named($attr-res<attributes> // [], '$!do');
                    return %do<handle>.Int if %do<handle>.defined;
                }
                return 0;
            }

            my Str $bare = $name.subst(/^'&'/, '');
            $bare = HELPER-PREFIX ~ $bare.lc unless $bare.starts-with(HELPER-PREFIX);
            my Str $sigiled = "&$bare";
            my Str $pkg-sigiled = '&Nimala::Raku-DAP::InjectedHelper::' ~ $bare;

            for ($pkg-sigiled, $sigiled) -> $target-key {
                last if $code-handle > 0;
                for @contexts -> $ch {
                    my $lex-res = attempt(self.lexicals($ch), 'lexicals');
                    if $lex-res && $lex-res<lexicals> {
                        my %lex = $lex-res<lexicals>;
                        if (%lex{$target-key}:exists) && %lex{$target-key}<handle>.defined {
                            $code-handle = extract-code-handle(%lex, $target-key);
                            if $code-handle > 0 {
                                for @HELPER-METHODS -> $m {
                                    my Str $h-bare = HELPER-PREFIX ~ $m.lc;
                                    my Str $h-pkg = '&Nimala::Raku-DAP::InjectedHelper::' ~ $h-bare;
                                    my Str $h-sig = "&$h-bare";
                                    my Int $do = extract-code-handle(%lex, $h-pkg)
                                    || extract-code-handle(%lex, $h-sig);
                                    if $do > 0 {
                                        $!handles.pin($do);
                                        $!helper-lock.protect: {
                                            %!helpers{$m} = $do;
                                            %!helpers{$m.lc} = $do;
                                            %!helpers{$h-bare} = $do;
                                            %!helpers{$h-sig} = $do;
                                            %!helpers{$h-pkg} = $do;
                                        };
                                    }
                                }
                                last;
                            }
                        }
                    }
                }
            }
        }
        $!helper-lock.protect: { %!helpers{$name} // 0 };
    }
}

#| Sole authorized gateway to invoke a helper routine in the debuggee (D5).
#| Enforces helper resolution, global budget spending, and actor unblocking before wire send.
method invoke-helper(
    Str:D $method where @HELPER-METHODS.any,
    Int:D $target,
    Int:D $thread,
    Promise :$started,
    :$timeout = 15
    --> Promise
) {
    start {
        my Int $code = await self.helper-handle($method, $thread);
        fail "Helper routine $method not found in debuggee" unless $code > 0;

        my Int $gen = $!handles.spend-invoke;
        fail AT-MOST-ONE-MESSAGE unless $gen > 0;

        $started.keep if $started.defined && $started.status == Planned;

        my %reply = await $!protocol.invoke(
            $code, $thread, [ %( kind => 'obj', handle => $target ), ], :$timeout
        );
        hash( |%reply, :$gen );
    }
}
