use v6.d;
unit class Nimala::Raku-DAP::BreakpointRequests;

use Nimala::Raku-DAP::BreakpointRegistry;
use Nimala::Raku-DAP::ClientCoordinates;
use Nimala::Raku-DAP::Expression;
use Nimala::Raku-DAP::LaunchConfig;
use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::SourceLines;
use Nimala::Raku-DAP::Trace;

has $.registry is required;
has $.source-lines = Nimala::Raku-DAP::SourceLines.new;
has Nimala::Raku-DAP::ClientCoordinates $.coords is required;
has &.send-response is required;
has &.send-event is required;
has &.connection is required;

has &!program-cb;
has Str $!program = '';
has &!ws-root-cb;
has Str $!workspace-root = '';
has $.symbol-lookup is rw;

submethod TWEAK(:$program, :$workspace-root) {
    if $program.defined {
        if $program ~~ Callable {
            &!program-cb = $program;
        } else {
            $!program = $program.Str;
        }
    }
    if $workspace-root.defined {
        if $workspace-root ~~ Callable {
            &!ws-root-cb = $workspace-root;
        } else {
            $!workspace-root = $workspace-root.Str;
        }
    }
}

method program(--> Str) {
    self!current-program;
}

method workspace-root(--> Str) {
    with &!ws-root-cb {
        my Str $w = try &!ws-root-cb();
        return $w if $w.defined && $w ne '';
    }
    $!workspace-root // '';
}

method !current-program(--> Str) {
    with &!program-cb {
        my Str $p = try &!program-cb();
        return $p if $p.defined && $p ne '';
    }
    $!program // '';
}

method resolve-file-path(Str $file --> Str) {
    $!source-lines.resolve-file-path($file, program => self!current-program);
}

method adjust-breakpoint-line(Str $file, Int $requested-line --> Int) {
    $!source-lines.adjust-breakpoint-line($file, $requested-line, program => self!current-program);
}

#| Resolves candidate positions for an array of function breakpoint requests.
method prepare-function-breakpoint-positions(
    @bps,
    $symbol-lookup,
    Str :$ws-root = self.workspace-root,
    Str :$program = ""
    --> Hash
) {
    my %new-func-positions;
    my @res-bps;

    for @bps -> %bp {
        my Str $name = (%bp<name> // '').Str;
        my Str $cond = (%bp<condition> // '').Str.trim;
        my Str $hit-cond = (%bp<hitCondition> // '').Str.trim;
        my Str $cond-err = validate-breakpoint-conditions($cond, $hit-cond);
        if $cond-err ne '' {
            @res-bps.push(hash(
                    bp => %bp,
                    verified => False,
                    message => $cond-err
            ));
            next;
        }

        my %resolved = $!source-lines.resolve-routine-candidates($name, $symbol-lookup, :$ws-root, :$program);
        if %resolved<status> eq 'not-found' {
            @res-bps.push(hash(
                    bp => %bp,
                    verified => False,
                    message => "Routine '$name' could not be resolved in workspace"
            ));
        } elsif %resolved<status> eq 'outside-workspace' {
            @res-bps.push(hash(
                    bp => %bp,
                    verified => False,
                    message => "Routine '$name' resolves only outside workspace"
            ));
        } else {
            my @matches = (%resolved<matches> // []).list;
            for @matches -> %m {
                my Str $f = %m<file>;
                my Int $l = %m<adj-line>;
                my Str $key = bp-key($f, $l);
                my Int $bp-id = (%bp<dap-id> // %bp<id> // 0).Int;
                %new-func-positions{$key} = hash(
                    id => $bp-id,
                    name => $name,
                    condition => $cond,
                    hitCondition => $hit-cond,
                    file => $f,
                    line => $l
                );
            }
            @res-bps.push(hash( bp => %bp, matches => @matches ));
        }
    }

    return %( positions => %new-func-positions, pending => @res-bps );
}

#| Formats final DAP Breakpoint descriptors from confirmed keys and pending items.
our sub format-function-breakpoint-results(@res-bps, SetHash $confirmed-keys --> Array) is export {
    my @final-bps;
    for @res-bps -> %r {
        my %bp = %r<bp>;
        my Str $name = (%bp<name> // '').Str;
        my $bid = %bp<dap-id> // %bp<id>;
        if %r<verified>:exists {
            my %item = hash(
                verified => %r<verified>,
                message => %r<message>
            );
            %item<id> = $bid.Int if $bid.defined;
            @final-bps.push(%item);
        } else {
            my @matches = %r<matches>.list;
            my @confirmed-m = @matches.grep({
                    $confirmed-keys.defined && $confirmed-keys{bp-key($_<file>, $_<adj-line>)}
            });
            if @confirmed-m.elems > 0 {
                my %m0 = @confirmed-m[0];
                my %bp-info = hash(
                    verified => True,
                    line => %m0<adj-line>,
                    source => hash( path => %m0<file>, name => %m0<file>.IO.basename )
                );
                %bp-info<id> = $bid.Int if $bid.defined;
                %bp-info<message> = "Instrumented {@confirmed-m.elems} positions" if @confirmed-m.elems > 1;
                @final-bps.push(%bp-info);
            } else {
                my %item = hash(
                    verified => False,
                    message => "Debuggee rejected function breakpoint for routine '$name'"
                );
                %item<id> = $bid.Int if $bid.defined;
                @final-bps.push(%item);
            }
        }
    }
    return @final-bps;
}

method resolve-and-send-function-breakpoints(@bps, Nimala::Raku-DAP::Protocol $proto --> Array) {
    my %prep = self.prepare-function-breakpoint-positions(
        @bps, $!symbol-lookup, ws-root => self.workspace-root, program => self!current-program
    );
    my SetHash $confirmed-keys = attempt(
        $!registry.sync-function-positions(%prep<positions>, $proto),
        'sync function positions'
    );
    return format-function-breakpoint-results(%prep<pending>, $confirmed-keys);
}

method handle-set-breakpoints(%msg --> Promise) {
    my Str $raw-file = (%msg<arguments><source><path> // '').Str;
    my Str $file = $!coords.in-path($raw-file);
    my Str $abs-file = self.resolve-file-path($file);
    my Any @bps = (%msg<arguments><breakpoints> // []).list;
    my @adjusted-bps;
    for @bps -> %bp {
        my Int $client-line = %bp<line>.Int;
        my Int $line = $!coords.in-line($client-line);
        my Int $adj-line = self.adjust-breakpoint-line($abs-file, $line);
        my Str $cond = (%bp<condition> // '').Str.trim;
        my Str $hit-cond = (%bp<hitCondition> // '').Str.trim;
        my Str $log-msg = (%bp<logMessage> // '').Str.trim;
        my Str $cond-err = validate-breakpoint-conditions($cond, $hit-cond);
        my Str $msg-err = $cond-err ne ""
        ?? $cond-err
        !! ($adj-line == 0 ?? "No executable code on line $client-line" !! "");
        my Bool $verified = $msg-err eq "";

        my Int $bp-id = (%bp<id> // %bp<dap-id> // $!registry.next-dap-id).Int;
        @adjusted-bps.push(hash(
                id => $bp-id,
                requested-line => $line,
                line => ($adj-line > 0 ?? $adj-line !! $line),
                condition => $cond,
                hitCondition => $hit-cond,
                logMessage => $log-msg,
                :$verified,
                message => $msg-err,
                dap-id => $bp-id
        ));
    }

    my $proto = &!connection();
    my Bool $connected = $proto.defined;
    return start {
        my @dap-bps = attempt(
            $!registry.set-line-breakpoints($abs-file, @adjusted-bps, protocol => $proto, :$connected),
            'set line breakpoints'
        ) // ();
        &!send-response(%msg, { breakpoints => @dap-bps });
        True;
    };
}

method handle-breakpoint-locations(%msg --> Promise) {
    start {
        my %args = (%msg<arguments> // %()).Hash;
        my Str $raw-file = (%args<source><path> // '').Str;
        my Str $file = $!coords.in-path($raw-file);
        my Str $abs-file = self.resolve-file-path($file);
        my Int $client-line = (%args<line> // 1).Int;
        my Int $start-line = $!coords.in-line($client-line);
        my Int $end-line = 0;
        if %args<endLine>.defined {
            $end-line = $!coords.in-line(%args<endLine>.Int);
        }

        my @locs = $!source-lines.breakpoint-locations($abs-file, $start-line, $end-line);
        &!send-response(%msg, %( breakpoints => @locs ));
    }
}

method handle-set-function-breakpoints(%msg --> Promise) {
    my Any @bps = (%msg<arguments><breakpoints> // []).list;
    @bps = @bps.map({ %( |$_, dap-id => (%_<dap-id> // %_<id> // $!registry.next-dap-id) ) });
    $!registry.early-function-breakpoints = @bps.Array;

    my $proto = &!connection();
    if !$proto.defined {
        my @res-bps;
        for @bps -> %bp {
            my Str $cond = (%bp<condition> // '').Str.trim;
            my Str $hit-cond = (%bp<hitCondition> // '').Str.trim;
            my Str $cond-err = validate-breakpoint-conditions($cond, $hit-cond);
            if $cond-err ne '' {
                @res-bps.push(hash( id => %bp<dap-id>, verified => False, message => $cond-err ));
            } else {
                @res-bps.push(hash( id => %bp<dap-id>, verified => True ));
            }
        }
        &!send-response(%msg, { breakpoints => @res-bps });
        return Promise.kept(True);
    }

    return start {
        my @final-bps = self.resolve-and-send-function-breakpoints(@bps, $proto);
        &!send-response(%msg, { breakpoints => @final-bps });
        True;
    };
}

method handle-set-exception-breakpoints(%msg --> Promise) {
    start {
        my %args = (%msg<arguments>.defined && %msg<arguments> ~~ Hash) ?? %msg<arguments> !! Hash.new;
        my SetHash $filters-set .= new;
        my %conditions;
        my @res-bps;

        if %args<filterOptions>:exists {
            for (%args<filterOptions> // []).list -> %opt {
                my Str $fid = (%opt<filterId> // '').Str;
                unless $fid eq 'uncaught' || $fid eq 'all' {
                    @res-bps.push(hash(
                            verified => False,
                            message => "Unknown exception filter '$fid'"
                    ));
                    next;
                }
                my Str $cond = (%opt<condition> // '').Str.trim;
                if $cond ne '' {
                    my $parsed = Nimala::Raku-DAP::Expression.parse($cond);
                    if $parsed.defined && $parsed.success {
                        %conditions{$fid} = $cond;
                        $filters-set.set($fid);
                        @res-bps.push(hash( verified => True ));
                    } else {
                        my Str $err = $parsed.defined ?? $parsed.error-message !! "syntax error";
                        @res-bps.push(hash(
                                verified => False,
                                message => "Condition outside bounded grammar: $err"
                        ));
                    }
                } else {
                    $filters-set.set($fid);
                    @res-bps.push(hash( verified => True ));
                }
            }
        } elsif %args<filters>:exists {
            for (%args<filters> // []).list -> $f {
                my Str $fid = $f.Str;
                if $fid eq 'uncaught' || $fid eq 'all' {
                    $filters-set.set($fid);
                    @res-bps.push(hash( verified => True ));
                } else {
                    @res-bps.push(hash(
                            verified => False,
                            message => "Unknown exception filter '$fid'"
                    ));
                }
            }
        }

        my @filters = $filters-set.keys.sort;
        $!registry.exception-filters = @filters.Array;
        $!registry.exception-filter-conditions = %conditions;
        attempt(self.apply-exception-filters(@filters), 'apply exception filters');
        my %body;
        %body<breakpoints> = @res-bps if (%args<filters>:exists) || (%args<filterOptions>:exists);
        &!send-response(%msg, %body);
        True;
    }
}

method apply-exception-filters(@filters, Nimala::Raku-DAP::Protocol :$protocol --> Promise) {
    start {
        my $proto = $protocol // &!connection();
        if $proto.defined {
            my Str $helper-file = (helper-file-path() // '').Str;
            my %lines = helper-exception-breakpoint-lines();

            attempt(
                $!registry.apply-exception-filters(
                    $proto, @filters,
                    :$helper-file,
                    uncaught-line => (%lines<uncaught> // 0).Int,
                    all-line => (%lines<all> // 0).Int
                ),
                'apply exception filters'
            );
        }
        True;
    }
}

method apply-early-function-breakpoints(Nimala::Raku-DAP::Protocol $proto --> Nil) {
    if $!registry.early-function-breakpoints.elems > 0 {
        my Any @early-f-bps = $!registry.early-function-breakpoints.list;
        my @final-bps = self.resolve-and-send-function-breakpoints(@early-f-bps, $proto);
        for @final-bps.sort({ ?$_<verified> }) -> %bp-info {
            &!send-event('breakpoint', %( reason => 'changed', breakpoint => %bp-info ));
        }
    }
}

method apply-early(
    Nimala::Raku-DAP::Protocol $proto,
    Str :$program = '',
    Bool :$stop-on-entry = False
    --> Promise) {
    start {
        $!program = $program if $program;
        for $!registry.line-breakpoints.kv -> Str $f, Any $bps {
            my @dbps = attempt(
                $!registry.set-line-breakpoints($f, $bps.Array, protocol => $proto, connected => True),
                'set line breakpoints'
            ) // ();
            for @dbps.grep(*<id>.defined) -> %dbp {
                &!send-event('breakpoint', %( reason => 'changed', breakpoint => %dbp ));
            }
        }

        self.apply-early-function-breakpoints($proto);
        my @flt = $!registry.exception-filters.elems > 0 ?? $!registry.exception-filters.list !! ['uncaught'];
        attempt(self.apply-exception-filters(@flt, protocol => $proto), 'apply exception filters');

        if $stop-on-entry {
            my Str $prog = $program || self!current-program;
            my Str $abs = $prog.IO.absolute;
            attempt(
                $!registry.setup-entry-breakpoint($proto, $abs, self.adjust-breakpoint-line($abs, 1)),
                'setup entry breakpoint'
            );
        }
        True;
    }
}
