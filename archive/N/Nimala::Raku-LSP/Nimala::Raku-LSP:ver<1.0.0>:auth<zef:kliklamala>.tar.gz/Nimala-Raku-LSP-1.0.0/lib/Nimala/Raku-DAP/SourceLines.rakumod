use v6.d;

#| Source file path resolution, mtime-cached line retrieval, line adjustment, and workspace routine symbol lookup.
unit class Nimala::Raku-DAP::SourceLines;

use Nimala::URI;
use Nimala::Raku-DAP::SymbolScanner;

#| Resolve a file or file:// URI to a canonical absolute filesystem path.
our sub canonical-path(Str $file --> Str) is export {
    return '' if $file eq '';
    my Str $clean = $file;
    if $clean.starts-with('file://') {
        $clean = uri-to-path($clean).Str;
    }
    return (try $clean.IO.resolve.absolute) // (try $clean.IO.absolute) // $clean;
}

#| Canonical key for a breakpoint line ("canonical-path:line").
our sub bp-key(Str $file, Int() $line --> Str) is export {
    "{canonical-path($file)}:$line"
}

has Str $.workspace-root is rw = "";
has Lock $!cache-lock .= new;
has %!line-cache; # $canon-path => %( mtime => Instant, lines => Array )

#| Returns the lines of a file as a List of Str, using an mtime-based cache.
method lines-for(Str $path --> List) {
    my $io = $path.IO;
    return () unless $io.e && $io.f;
    my $mtime = try $io.modified;
    my Str $canon = (try $io.resolve.absolute) // $io.absolute;

    $!cache-lock.protect: {
        if %!line-cache{$canon}:exists {
            my %entry := %!line-cache{$canon};
            if %entry<mtime> === $mtime || (%entry<mtime>.defined && $mtime.defined && %entry<mtime> == $mtime) {
                return (%entry<lines> // ()).list;
            }
        }
    }

    my @lines = (try $io.lines.Array) // [];

    $!cache-lock.protect: {
        %!line-cache{$canon} = %( :$mtime, lines => @lines );
    }

    return @lines.list;
}

#| Resolves a relative or URI-formatted file path to an absolute filesystem path.
method resolve-file-path(Str $file, Str :$program = "" --> Str) {
    return '' if $file eq '';
    my Str $clean = $file;
    if $clean.starts-with('file://') {
        $clean = uri-to-path($clean).Str;
    }
    if $clean.IO.is-absolute {
        return canonical-path($clean);
    }
    if $!workspace-root ne '' {
        my $p = $!workspace-root.IO.add($clean);
        return $p.resolve.absolute if $p.e && $p.f;
    }
    my $cwd-p = $*CWD.add($clean);
    return $cwd-p.resolve.absolute if $cwd-p.e && $cwd-p.f;

    if $program ne '' {
        my $prog-p = $program.IO.parent.add($clean);
        return $prog-p.resolve.absolute if $prog-p.e && $prog-p.f;
    }

    my $root = $!workspace-root ne '' ?? $!workspace-root.IO !! $*CWD;
    my @stack = ($root,);
    my Int $budget = 300;
    while @stack && $budget-- > 0 {
        my $dir = @stack.shift;
        for (try $dir.dir) // () -> $entry {
            next if $entry.basename.starts-with('.');
            if $entry.d {
                my $cand = $entry.add($clean);
                return $cand.resolve.absolute if $cand.e && $cand.f;
                @stack.push($entry);
            }
        }
    }

    return (try $cwd-p.resolve.absolute) // $cwd-p.absolute;
}

# --- Executable Line Rules ---
# Two distinct rules answer two different questions:
# 1. stoppable-line: where MoarVM can stop. Sweep arming needs this to step onto every reachable line.
#    Header lines like 'sub f($x) {', 'for ... {', 'while False {' are stoppable (declaration/setup stops).
# 2. breakpoint-target-line: where a user breakpoint lands. Setting a breakpoint on 'sub f {' is intended
#    to stop on calls, not on the declaration during mainline execution. It advances to the first body statement.
# Measurement (2026-10-23):
# - 'sub f($x) {' hits 3 times (declaration + calls); body hits 2 times.
# - 'for 1..2 -> $v {' hits 1 time (loop setup); body hits 2 times.
# - 'while False {' hits 1 time.

#| Check whether a line of source code can be stopped on by MoarVM (excluding solitary braces and comments).
our sub stoppable-line(Str $line-text --> Bool) is export {
    my Str $t = $line-text.trim;
    return False if $t eq '' || $t.starts-with('#');
    return False if $t eq '}' || $t eq '{' || $t eq '};';
    return True;
}

#| Scans lines forward from requested 1-based line to find where a user breakpoint should land (0 = none).
method breakpoint-target-line(@lines, Int:D $requested --> Int) {
    return 0 unless @lines;
    return 0 if $requested < 1 || $requested > @lines.elems;

    my Int $idx = $requested - 1; # 0-indexed
    my Str $req-trimmed = @lines[$idx].trim;

    # Solitary closing brace is not an executable statement line
    if $req-trimmed ~~ /^ '}' [ \s* ';' ]? $/ {
        return 0;
    }

    # Scan forward from requested line to find the first executable statement line
    while $idx < @lines.elems {
        my Str $trimmed = @lines[$idx].trim;

        # Skip empty lines
        if $trimmed eq "" {
            $idx++;
            next;
        }

        # Skip pure comment lines
        if $trimmed.starts-with('#') && !$trimmed.starts-with('#=') && !$trimmed.starts-with('#|') {
            $idx++;
            next;
        }

        # Routine and type declarations ending with {
        if $trimmed ~~ /^ ( 'sub' | 'method' | 'multi' | 'proto' | 'only' | 'class' | 'role' | 'module' | 'package' | 'grammar' | 'unit' ) >> / && $trimmed.ends-with('{') {
            $idx++;
            next;
        }

        # Block openers without statement body on the same line
        if $trimmed ~~ /^ ( 'for' | 'while' | 'until' | 'loop' | 'given' | 'try' | 'ENTER' | 'LEAVE' | 'KEEP' | 'UNDO' ) >> / && $trimmed.ends-with('{') {
            $idx++;
            next;
        }

        # Closing brace: boundary of scope reached without finding statement
        if $trimmed ~~ /^ '}' [ \s* ';' ]? $/ {
            return 0;
        }

        # Found an executable line
        return $idx + 1;
    }

    return 0;
}

#| Adjusts a requested breakpoint line number forward past comments/whitespace/declarations to the first executable statement line.
method adjust-breakpoint-line(Str $file, Int $requested-line, Str :$program = "" --> Int) {
    my Str $resolved = self.resolve-file-path($file, :$program);
    return 0 if $resolved eq '';

    my @lines = self.lines-for($resolved);
    self.breakpoint-target-line(@lines, $requested-line);
}

#| Finds stoppable breakpoint locations within a line or range of lines.
method breakpoint-locations(Str $file, Int $start-line, Int $end-line = 0 --> Array) {
    if $end-line <= 0 || $end-line <= $start-line {
        my Int $adj = self.adjust-breakpoint-line($file, $start-line);
        return $adj > 0 ?? [ %( line => $adj ), ] !! [];
    }

    my Str $resolved = self.resolve-file-path($file);
    return [] if $resolved eq '';

    my @lines = self.lines-for($resolved);
    return [] unless @lines;

    my SetHash $seen .= new;
    my @result;
    my Int $max-l = min($end-line, @lines.elems);
    for $start-line .. $max-l -> $l {
        my Int $target = self.breakpoint-target-line(@lines, $l);
        if $target > 0 && $target >= $start-line && $target <= $end-line && !$seen{$target} {
            $seen.set($target);
            @result.push(%( line => $target ));
        }
    }
    return @result.sort({ .<line> }).Array;
}

#| Ensures that files containing candidate routine definitions are indexed by symbol scanner.
method ensure-files-defining-symbol-indexed(
    Str $name,
    $symbol-lookup,
    Str :$ws-root = $!workspace-root,
    Str :$program = ""
    --> Nil
) {
    return unless $symbol-lookup.defined;
    my Any @existing = $symbol-lookup.find-symbol($name);
    my Any @routines = @existing.grep({ (($_<kind> // 0).Int == SYM-METHOD) || (($_<kind> // 0).Int == SYM-ROUTINE) });
    return if @routines.elems > 0;

    my IO::Path $root = ($ws-root ne "" && $ws-root.IO.d ?? $ws-root.IO !! $*CWD);
    my Str $search-term = $name.contains('::') ?? $name.split('::')[*-1] !! $name;
    my IO::Path @search-dirs;
    for 'lib', 'bin' -> $sub {
        my IO::Path $d = $root.add($sub);
        @search-dirs.push($d) if $d.d;
    }
    if $program ne "" {
        my IO::Path $p-dir = $program.IO.parent;
        @search-dirs.push($p-dir) if $p-dir.d;
    }
    @search-dirs.push($root) unless @search-dirs;

    my Bool %seen-dirs;
    for @search-dirs -> $dir {
        my Str $d-abs = $dir.resolve.absolute;
        next if %seen-dirs{$d-abs};
        %seen-dirs{$d-abs} = True;

        if $symbol-lookup.can('scan-directory') {
            $symbol-lookup.scan-directory($dir, $search-term);
        }
    }
}

#| Resolves routine candidate locations across workspace files for a function breakpoint.
method resolve-routine-candidates(
    Str $name,
    $symbol-lookup,
    Str :$ws-root = $!workspace-root,
    Str :$program = ""
    --> Hash
) {
    self.ensure-files-defining-symbol-indexed($name, $symbol-lookup, :$ws-root, :$program);
    my Any @syms = $symbol-lookup.defined ?? $symbol-lookup.find-symbol($name) !! ();
    my Any @routine-syms = @syms.grep({ (($_<kind> // 0).Int == SYM-METHOD) || (($_<kind> // 0).Int == SYM-ROUTINE) });

    if !@routine-syms {
        return hash(
            status => 'not-found',
            matches => []
        );
    }

    my Str $root-abs = ($ws-root ne "" && $ws-root.IO.d ?? $ws-root.IO !! $*CWD).resolve.absolute;
    my Str $sep = $*SPEC.dir-sep;
    my @workspace-matches;
    for @routine-syms -> %s {
        my Str $uri = (%s<uri> // '').Str;
        if $uri.starts-with('file://') {
            my Str $canon = canonical-path($uri);
            if $canon.starts-with($root-abs ~ $sep) || $canon eq $root-abs {
                my Int $decl-line = ((%s<range><start><line> // 0).Int) + 1;
                my Int $adj-line = self.adjust-breakpoint-line($canon, $decl-line, :$program);
                @workspace-matches.push(hash(
                        file => $canon,
                        decl-line => $decl-line,
                        adj-line => $adj-line,
                        name => $name
                ));
            }
        }
    }

    if !@workspace-matches {
        return hash(
            status => 'outside-workspace',
            matches => []
        );
    }

    my Bool %seen;
    my @unique-matches;
    for @workspace-matches -> %m {
        my Str $key = bp-key(%m<file>, %m<adj-line>);
        next if %seen{$key};
        %seen{$key} = True;
        @unique-matches.push(%m);
    }

    return hash(
        status => 'ok',
        matches => @unique-matches
    );
}

