use v6.d;

#| Narrow abstraction for symbol and routine position resolution across files.
unit role Nimala::Model::SymbolLookup;

#| Find all symbols matching a given name.
method find-symbol(Str $name, Str $current-namespace = "" --> Positional) { ... }

#| Find symbols enclosing a given location in a file.
method find-enclosing-symbols(Str $uri, Int $line, Int $col --> Positional) { ... }

#| Return all indexed symbols mapped by file URI.
method all-files-symbols(--> Hash) { ... }

#| Update symbol index for a specific file URI and its source code.
method update-file(Str $uri, Str $content, | --> Nil) { ... }
