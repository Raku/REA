<p align="center"> <img src="https://gitlab.com/nimala/raku/raku-lsp/-/raw/main/Raku-LSP-192.jpeg" alt="Nimala Logo" width="128" /> </p>

NAME
====

Nimala::Raku-LSP - Complete Raku Language Server Protocol (LSP 3.18) & Debug Adapter Protocol (DAP)

DESCRIPTION
===========

Nimala is a full-featured Language Server Protocol (LSP 3.18) and Debug Adapter Protocol (DAP) implementation for the Raku programming language, written entirely in Raku. It provides advanced IDE intelligence, refactoring capabilities, and integrated debugging to any LSP-compatible editor (such as VS Code, Neovim, Helix, or Emacs).

Key Highlights
--------------

  * **Broad LSP 3.18 & DAP Coverage**: 71 of 95 LSP 3.18 methods fully implemented and 2 partially (the rest are niche or low-utility), plus 22 DAP requests.

  * **Multi-Tiered AST & Deep Type Inference**: Combines native RakuAST parsing in an isolated worker process, resilient fallback grammars, and dynamic MRO / generic type tracking.

  * **Multi-Root Workspace & Reactive Progress Engine**: Dynamic folder indexing, pruning, and bidirectional `$/progress` reporting with RAII scopes.

  * **High Performance & Low Latency**: Persistent SQLite index caching (`.nimala/symbols.db`), prefix (completion) and substring (workspace symbols) search, and non-blocking asynchronous event streams (`Supply`, `Proc::Async`, `Lock`).

LSP 3.18 Implementation Matrix
------------------------------

Of the 95 requests and notifications in the LSP 3.18 meta model, 71 are fully implemented and 2 partially; the remaining 22 are niche or low-utility roadmap items. Each method links to its section in the [LSP 3.18 specification](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/). Full audit: [docs/lsp-coverage.md](https://gitlab.com/nimala/raku/raku-lsp/-/blob/main/docs/lsp-coverage.md).

### 1. Lifecycle & General

  * [`initialize`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#initialize)

  * [`initialized`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#initialized)

  * [`shutdown`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#shutdown)

  * [`exit`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#exit)

  * [`$/cancelRequest`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#cancelRequest)

  * [`$/progress`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#progress)

### 2. Document Synchronization

  * [`textDocument/didOpen`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didOpen)

  * [`textDocument/didChange`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didChange)

  * [`textDocument/didClose`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didClose)

  * [`textDocument/didSave`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didSave)

  * [`textDocument/willSave`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_willSave)

### 3. Code Intelligence, Navigation & Editing

  * [`textDocument/hover`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_hover)

  * [`textDocument/completion`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_completion)

  * [`completionItem/resolve`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#completionItem_resolve)

  * [`textDocument/signatureHelp`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_signatureHelp)

  * [`textDocument/declaration`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_declaration)

  * [`textDocument/definition`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_definition)

  * [`textDocument/typeDefinition`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_typeDefinition)

  * [`textDocument/implementation`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_implementation)

  * [`textDocument/references`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_references)

  * [`textDocument/documentHighlight`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_documentHighlight)

  * [`textDocument/documentSymbol`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_documentSymbol)

  * [`textDocument/codeAction`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_codeAction)

  * [`codeAction/resolve`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeAction_resolve)

  * [`textDocument/codeLens`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_codeLens)

  * [`codeLens/resolve`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeLens_resolve)

  * [`textDocument/documentLink`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_documentLink)

  * [`textDocument/formatting`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_formatting)

  * [`textDocument/rangeFormatting`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_rangeFormatting)

  * [`textDocument/onTypeFormatting`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_onTypeFormatting)

  * [`textDocument/rename`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_rename)

  * [`textDocument/prepareRename`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_prepareRename)

  * [`textDocument/foldingRange`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_foldingRange)

  * [`textDocument/selectionRange`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_selectionRange)

  * [`textDocument/semanticTokens/full`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_fullRequest)

  * [`textDocument/semanticTokens/range`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_rangeRequest)

  * [`textDocument/semanticTokens/full/delta`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_deltaRequest)

  * [`textDocument/inlayHint`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlayHint)

  * [`inlayHint/resolve`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#inlayHint_resolve)

  * [`textDocument/inlineCompletion`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineCompletion)

  * [`textDocument/inlineValue`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineValue)

  * [`textDocument/linkedEditingRange`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_linkedEditingRange)

### 4. Hierarchies

  * [`textDocument/prepareTypeHierarchy`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_prepareTypeHierarchy)

  * [`typeHierarchy/supertypes`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#typeHierarchy_supertypes)

  * [`typeHierarchy/subtypes`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#typeHierarchy_subtypes)

  * [`textDocument/prepareCallHierarchy`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_prepareCallHierarchy)

  * [`callHierarchy/incomingCalls`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#callHierarchy_incomingCalls)

  * [`callHierarchy/outgoingCalls`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#callHierarchy_outgoingCalls)

### 5. Diagnostics (Push & Pull)

  * [`textDocument/publishDiagnostics`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_publishDiagnostics)

  * [`textDocument/diagnostic`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_diagnostic)

  * [`workspace/diagnostic`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_diagnostic)

### 6. Workspace & Server-Initiated Refreshes

  * [`workspace/symbol`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_symbol)

  * [`workspace/executeCommand`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_executeCommand)

  * [`workspace/didChangeWatchedFiles`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeWatchedFiles)

  * [`workspace/workspaceFolders`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_workspaceFolders) (partial: folders come from `initialize` and `workspace/didChangeWorkspaceFolders`; the server never sends this request)

  * [`workspace/willRenameFiles`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_willRenameFiles)

  * [`workspace/applyEdit`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_applyEdit)

  * [`workspace/codeLens/refresh`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeLens_refresh)

  * [`workspace/inlayHint/refresh`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_inlayHint_refresh)

  * [`workspace/semanticTokens/refresh`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_refreshRequest)

  * [`workspace/foldingRange/refresh`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_foldingRange_refresh)

  * [`workspace/diagnostic/refresh`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#diagnostic_refresh)

  * [`workspace/inlineValue/refresh`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_inlineValue_refresh)

  * [`workspace/didChangeConfiguration`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeConfiguration)

  * [`workspace/configuration`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_configuration)

  * [`workspace/didChangeWorkspaceFolders`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeWorkspaceFolders)

### 7. Window & Client Interaction

  * [`window/logMessage`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_logMessage)

  * [`window/showMessage`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_showMessage)

  * [`window/showMessageRequest`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_showMessageRequest) (partial: client helper exists, no feature sends it yet)

  * [`window/showDocument`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_showDocument)

  * [`window/workDoneProgress/create`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_workDoneProgress_create)

  * [`window/workDoneProgress/cancel`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_workDoneProgress_cancel)

  * [`client/registerCapability`](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#client_registerCapability)

Programmatic Usage
------------------

The server binary dispatches JSON-RPC through its own `Nimala::Raku-LSP::Dispatcher` (method whitelist, cancellation, concurrent requests). For embedding, the handler can also be driven by `JSON::RPC::Server`, as the test suite does, to analyze Raku code or build custom clients:

```raku
use Nimala::Raku-LSP::Handler;
use JSON::RPC::Server;

# Initialize the LSP Handler
my $handler = Nimala::Raku-LSP::Handler.new;

# Wrap it in a JSON-RPC Server
my $server = JSON::RPC::Server.new(application => $handler);

# Simulate a JSON-RPC Request (e.g., from a client)
# Handler methods use '-' for the LSP '/' (send "textDocument-hover", not "textDocument/hover")
my $request = q:to/END/;
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "processId": null,
    "rootUri": null,
    "capabilities": {}
  }
}
END

# Process the request and get the JSON-RPC response
my $response = $server.handler(json => $request);
say $response;
```

Debug Adapter Protocol (DAP) Architecture
-----------------------------------------

Nimala includes a Debug Adapter Protocol (DAP) server (`bin/nimala-raku-dap`). The debugger is built directly on MoarVM's native remote debugging protocol, communicating with the debuggee over loopback TCP using MessagePack framing.

  * **Native VM-Level Execution**: The debuggee runs as standard `raku --debug-port=<port> --debug-suspend <program>`, executing standard precompiled bytecode. This eliminates the precompilation slot mismatches, slow first launches, and compiler `when` statement crashes of earlier statement-hook implementations.

  * **Pure-Raku MessagePack Framing**: Communication uses a fast, dependency-free MessagePack codec and protocol client with monotonic request/response correlation and event dispatch.

  * **Monotonic Handle Management**: Context and object handles allocated during stops are tracked in a lifecycle registry, released in batches upon resume and dropped locally on disconnect.

  * **Bounded Expressions & Safe Inspection**: Expression evaluation, conditional breakpoints, and logpoints use a bounded expression grammar (variables, attribute/key/index access, comparisons against literals). Arbitrary method calls and mutations are refused; only the whitelisted helpers `.gist`, `.Str`, `.raku` and `.elems` run in the debuggee, at most one per stop.

  * **Smart Stepping**: Configurable smart stepping (`into`, `over`, `disable`) automatically filters out internal compiler, runtime, and NQP frames so stepping stays focused on user code.

For full architectural details, see docs/DEBUG.md and docs/DEBUG-MOARVM.md.

Installation & Dependencies
---------------------------

Nimala requires a working Raku installation (Rakudo 2026.09 recommended) and the `sqlite3` shared library for index persistence. Only Rakudo 2026.09 is tested. Rakudo 2024.07 runs with limitations: the debugger can abort with a MoarVM panic, and the RakuAST-based analysis ignores signature parameters and fails on files with `BEGIN` blocks, so the built-in parser fills in.

### Dependencies

  * **DBIish** & **DBDish::SQLite**: Database independent interface and SQLite driver for persistent, transactional symbol indexing (`.nimala/symbols.db`).

  * **JSON::Fast**: High-performance JSON parser and serializer.

### Install via Zef

```sh
# Install all dependencies and Nimala LSP/DAP binaries
zef install Nimala::Raku-LSP
```

`zef` puts the `nimala-raku-lsp` and `nimala-raku-dap` scripts into the `bin/` directory of the repository it installs to. Without root rights that is usually `~/.raku/bin`, which must be in `PATH` (for example `export PATH="$HOME/.raku/bin:$PATH"` in `~/.bashrc`). Otherwise editors cannot find the server.

Security Considerations
-----------------------

Like standard Raku tooling, the language server executes compile-time code when inspecting documents:

  * **Compile-Time Execution**: Background syntax checking (`raku -c`) and native AST parsing execute `BEGIN`, `CHECK`, and `INIT` blocks as well as compile-time side effects of imported modules (`use`).

  * **Doc Preview Evaluation**: Rendering RakuDoc to HTML (`raku --doc=HTML`) also evaluates compile-time blocks in opened files.

  * **Untrusted Code**: Never open untrusted Raku files or untrusted workspaces without inspecting them first. Always use isolated environments (containers or sandboxes) when reviewing unknown code.

License Artistic-2.0
--------------------

### sub run-tcp-server

```raku
sub run-tcp-server(
    Str :$host = "127.0.0.1",
    Int :$port = 5007,
    Bool :$single-session = Bool::False,
    Promise :$stop-promise = Code.new
) returns Nil
```

Re-export run-tcp-server from Transport::Socket

### sub run-server

```raku
sub run-server(
    IO::Handle :$in = Code.new,
    IO::Handle :$out = Code.new,
    Nimala::Raku-LSP::Handler :$handler = Code.new,
    :$supply = Code.new
) returns Int
```

Start the LSP server loop.

