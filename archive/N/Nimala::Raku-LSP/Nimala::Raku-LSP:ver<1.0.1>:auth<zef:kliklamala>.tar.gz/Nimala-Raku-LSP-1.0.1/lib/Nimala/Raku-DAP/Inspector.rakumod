use v6.d;
unit class Nimala::Raku-DAP::Inspector;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::Remote;
use Nimala::Raku-DAP::ValueRenderer;
use Nimala::Raku-DAP::Evaluator;
use Nimala::Raku-DAP::Expression;
use Nimala::Raku-DAP::ThreadState;
use Nimala::Raku-DAP::FrameClassifier;

has Nimala::Raku-DAP::Protocol $.protocol is required;
has Nimala::Raku-DAP::Handles $.handles is required;
has Nimala::Raku-DAP::Remote $.remote is required;
has Nimala::Raku-DAP::ValueRenderer $.renderer is required;
has Nimala::Raku-DAP::Evaluator $.evaluator is required;
has Nimala::Raku-DAP::FrameClassifier $.frame-classifier is required;
has Nimala::Raku-DAP::ThreadRegistry $.threads is required;
has &.send-response is required;

method handle-scopes(%req --> Promise) {
    my Int $frame-id = (%req<arguments><frameId> // 1).Int;
    my %frame-info;
    try {
        %frame-info = $!handles.resolve-frame($frame-id);
        CATCH {
            default {
                &!send-response(%req, {}, success => False, message => .message);
                return Promise.kept(False);
            }
        }
    }

    my Int $thread = %frame-info<thread>;
    my Int $frame-idx = %frame-info<frame-index>;

    $!remote.context($thread, $frame-idx).then(-> $p {
            my Int $ctx-handle = $p.status == Kept ?? ($p.result<handle> // 0).Int !! 0;
            if $ctx-handle > 0 {
                my Int $ref = $!handles.allocate-context-ref($thread, $frame-idx, $ctx-handle);
                my @scopes = (
                    %(
                        name => 'Locals',
                        presentationHint => 'locals',
                        variablesReference => $ref,
                        expensive => False
                    ),
                );
                &!send-response(%req, %( scopes => @scopes ));
            } else {
                my Str $cause = $p.status == Broken ?? ": {$p.cause.message}" !! '';
                &!send-response(%req, {}, success => False, message => "The frame's context is unavailable$cause");
            }
    });
}

method handle-variables(%req --> Promise) {
    my Int $ref = (%req<arguments><variablesReference> // 0).Int;
    my %ref-info;
    try {
        %ref-info = $!handles.resolve-ref($ref);
        CATCH {
            default {
                &!send-response(%req, {}, success => False, message => .message);
                return Promise.kept(False);
            }
        }
    }

    my Int $thread = %ref-info<thread> // 1;
    my Int $start-idx = (%req<arguments><start> // 0).Int;
    my $count-arg = %req<arguments><count>;
    my Int $count = ($count-arg.defined && $count-arg.Int > 0) ?? $count-arg.Int !! 0;
    my Str $filter = (%req<arguments><filter> // '').Str;

    if %ref-info<kind> eq 'context' {
        my Int $ctx-handle = %ref-info<handle>;
        start {
            try {
                my $p = await $!remote.lexicals($ctx-handle);
                my %lexicals = $p<lexicals> // {};
                my @items;
                for %lexicals.kv -> $name, %val {
                    next if $!renderer.is-internal-lexical($name);
                    @items.push(%(
                            name => $name,
                            |%val
                    ));
                }
                my @vars = await $!renderer.render-entries(@items, $thread, :kind('scope'));
                @vars = @vars.sort(*<name>);
                @vars = page(@vars, $start-idx, $count) if $start-idx > 0 || $count > 0;
                &!send-response(%req, %( variables => @vars.Array ));
                CATCH {
                    default {
                        &!send-response(%req, {}, success => False, message => .message);
                    }
                }
            }
        }
    }
    elsif %ref-info<kind> eq 'object' {
        my Int $handle = %ref-info<handle>;
        my Str $parent-eval = $!handles.get-evaluate-name($ref);
        $!renderer.expand-object(
            $handle, $thread, :start($start-idx), :$count, :$filter, :parent-eval-name($parent-eval)
        ).then(-> $p {
                if $p.status == Kept {
                    my @children = ($p.result // []).list;
                    &!send-response(%req, %( variables => @children.Array ));
                } else {
                    &!send-response(%req, {}, success => False, message => $p.cause.message);
                }
        });
    }
    else {
        &!send-response(%req, %( variables => [] ));
    }
}

method handle-evaluate(%req, Promise :$invoke-started --> Promise) {
    my Str $expression = (%req<arguments><expression> // '').Str;
    my Int $frame-id = (%req<arguments><frameId> // 0).Int;
    my Str $context = (%req<arguments><context> // '').Str;

    $!evaluator.evaluate-expression($expression, $frame-id, :$context, :$invoke-started).then(-> $p {
            if $p.status == Kept {
                my %res = $p.result;
                if %res<success> {
                    my %body = %(
                        result => (%res<result> // '').Str,
                        type => (%res<type> // '').Str,
                        variablesReference => (%res<variablesReference> // 0).Int
                    );
                    set-child-counts(%body, %res);
                    if %res<presentationHint>:exists {
                        %body<presentationHint> = %res<presentationHint>;
                    }
                    &!send-response(%req, %body);
                } else {
                    my Str $msg = (%res<message> // 'Evaluation failed').Str;
                    if $msg eq 'notStopped' {
                        my %err-body = %(
                            error => %(
                                id => (%req<seq> // 0).Int,
                                format => 'Evaluation requires a stopped thread',
                                showUser => False,
                            )
                        );
                        &!send-response(%req, %err-body, success => False, message => 'notStopped');
                    } else {
                        &!send-response(%req, {}, success => False, message => $msg);
                    }
                }
            } else {
                &!send-response(%req, {}, success => False, message => $p.cause.message);
            }
    });
}

method evaluate-expression(
    Str $expression,
    Int $frame-id,
    Str :$context = '',
    Promise :$invoke-started
    --> Promise
) {
    self.evaluator.evaluate-expression($expression, $frame-id, :$context, :$invoke-started);
}

method inspect-scalar(Int $handle, Int $thread --> Promise) {
    self.renderer.inspect-scalar($handle, $thread);
}
