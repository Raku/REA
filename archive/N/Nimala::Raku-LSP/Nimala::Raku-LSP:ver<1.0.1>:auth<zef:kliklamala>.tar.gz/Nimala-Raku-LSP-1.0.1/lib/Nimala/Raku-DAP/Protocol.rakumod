use v6.d;
unit class Nimala::Raku-DAP::Protocol;

use Nimala::Raku-DAP::MessagePack;
use NativeCall;

# Low-latency socket tuning (Linux TCP_QUICKACK)
sub c_setsockopt(int32 $fd, int32 $level, int32 $optname, CArray[int32] $optval, uint32 $optlen --> int32)
is native is symbol('setsockopt') { * }

constant IPPROTO_TCP = 6;
constant TCP_QUICKACK = 12;
constant SOL_SOCKET = 1;
constant SO_RCVBUF = 8;

class X::MoarVM::Error is Exception is export {
    has Str $.message;
}

class X::MoarVM::HandshakeFailed is X::MoarVM::Error is export {
    has Str $.reason;
    method message() { "MoarVM debug handshake failed: $!reason" }
}

class X::MoarVM::Timeout is X::MoarVM::Error is export {
    has Int $.message-type;
    has Int $.id;
    method message() { "Timeout waiting for reply to MoarVM protocol message type $!message-type (id $!id)" }
}

class X::MoarVM::RequestFailed is X::MoarVM::Error is export {
    has Int $.message-type;
    has Str $.reason;
    method message() {
        $!reason.defined && $!reason.chars > 0
        ?? $!reason
        !! "MoarVM debug server rejected request (type $!message-type)"
    }
}

use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Trace;

#| A random loopback port (30000..60000) that nothing accepted a connection on just now (DK-6).
our sub free-loopback-port(--> Int:D) is export {
    loop {
        my Int $port = (30000..60000).pick;
        my $s = try IO::Socket::INET.new(:host<127.0.0.1>, :$port, :timeout(0.01));
        if $s {
            $s.close;
            next;
        }
        return $port;
    }
}

has IO::Socket::Async $.socket;
has int32 $!native-fd = -1;
has int $!quickack-state = -1;
has CArray[int32] $!quickack-val = CArray[int32].new(1);
has CArray[int32] $!quickack-off = CArray[int32].new(0);
has Int $.protocol-major = 0;
has Int $.protocol-minor = 0;
has Lock $!id-lock = Lock.new;
has Int $!next-id = 1;

has Lock $!pending-lock = Lock.new;
has %!pending-requests; # id => Promise
has %!invoke-requests;  # id => thread (two-phase reply tracking)
has %!timed-out-invokes; # id => thread; Invoke still running in the debuggee after its timeout


has Supplier $!events-supplier = Supplier.new;
has Supply $.events = $!events-supplier.Supply;

#| Problems the reader recovered from (undecodable data, failing handlers), as text for the client (B-8)
has Supplier $!problems-supplier = Supplier.new;
has Supply $.problems = $!problems-supplier.Supply;

has Supplier $!terminated-supplier = Supplier.new;
has Supply $.terminated = $!terminated-supplier.Supply;

has Buf $!recv-buf = Buf.new;
has int $!read-offset = 0;
has MsgpackScanner $!scanner .= new;
has Lock $!buf-lock = Lock.new;
has Bool $!handshake-done = False;
has Promise $!handshake-promise = Promise.new;

# Connect to MoarVM debug server and perform 24-byte handshake
method connect(Str $host, Int $port, Real :$timeout = 10 --> Promise) {
    my $p = Promise.new;

    start {
        my @hosts = ($host eq 'localhost' || $host eq '127.0.0.1')
        ?? ('127.0.0.1', '::1')
        !! ($host,);
        my $sock;
        my $t0 = now;
        while now - $t0 < $timeout {
            for @hosts -> $h {
                my $try-connect = attempt(IO::Socket::Async.connect($h, $port), 'connect');
                if $try-connect.defined {
                    $sock = $try-connect;
                    last;
                }
            }
            last if $sock.defined;
            sleep 0.05;
        }

        if !$sock.defined {
            $p.break(X::MoarVM::HandshakeFailed.new(reason => "Could not connect to $host:$port within $timeout seconds"));
        }
        else {
            $!socket = $sock;
            if $*DISTRO.is-win.not && $*KERNEL.name eq 'linux' {
                try {
                    $!native-fd = $sock.native-descriptor;
                    $!quickack-state = -1;
                    if $!native-fd >= 0 {
                        # ponytail: 1MB SO_RCVBUF accommodates up to 100k element replies without tcp window stalls; expand only if multi-MB frames stall.
                        my CArray[int32] $rcvbuf = CArray[int32].new(1024 * 1024);
                        c_setsockopt($!native-fd, SOL_SOCKET, SO_RCVBUF, $rcvbuf, 4);
                    }
                    CATCH { default { $!native-fd = -1; $!quickack-state = -1; } }
                }
            } else {
                $!native-fd = -1;
                $!quickack-state = -1;
            }
            $!next-id = 1; # Reset ID space per connection
            $!handshake-done = False;
            $!handshake-promise = Promise.new;
            $!recv-buf = Buf.new;
            $!read-offset = 0;
            $!scanner.reset;   # a value cut off by an earlier connection must not shape this one (B-10)

            self!start-read-loop();

            # Wait for handshake with remaining timeout
            my $rem = max(1.0, $timeout - (now - $t0));
            Promise.anyof($!handshake-promise, Promise.in($rem)).then(-> $h-res {
                    if $!handshake-promise.status == Kept {
                        $p.keep(self);
                    }
                    elsif $!handshake-promise.status == Broken {
                        $p.break($!handshake-promise.cause);
                    }
                    else {
                        $p.break(X::MoarVM::HandshakeFailed.new(reason => "Handshake timed out after $timeout seconds"));
                    }
            });
        }
    }

    return $p;
}

method !start-read-loop(--> Nil) {
    $!socket.Supply(:bin).tap(
        sub ($chunk) {
            my @messages-to-dispatch;
            my @problems;
            my int $pending = 0;
            my $handshake-error;
            $!buf-lock.protect: {
                $!recv-buf.append($chunk);

                # Handle handshake if not done yet
                unless $!handshake-done {
                    if ($!recv-buf.bytes - $!read-offset) >= 24 {
                        my Str $header = $!recv-buf.subbuf($!read-offset, 20).decode('latin-1');
                        if $header eq "MOARVM-REMOTE-DEBUG\0" {
                            $!protocol-major = $!recv-buf.read-uint16($!read-offset + 20, BigEndian);
                            $!protocol-minor = $!recv-buf.read-uint16($!read-offset + 22, BigEndian);

                            if $!protocol-major != 1 {
                                my $err = X::MoarVM::HandshakeFailed.new(
                                    reason => "Unsupported MoarVM debug protocol version: $!protocol-major.$!protocol-minor (expected major version 1)"
                                );
                                $handshake-error = $err;
                            }
                            else {
                                # Set handshake-done synchronously before sending confirmation to prevent race with early server messages
                                $!handshake-done = True;
                                $!handshake-promise.keep(True);
                                $!read-offset += 24;

                                $!socket.write("MOARVM-REMOTE-CLIENT-OK\0".encode('latin-1'));
                            }
                        }
                        elsif $header.starts-with("MOARVM-REMOTE-DEBUG!") {
                            # Server reported handshake failure
                            my Str $reason = $!recv-buf.subbuf($!read-offset + 20).decode('latin-1');
                            $handshake-error = X::MoarVM::HandshakeFailed.new(:$reason);
                        }
                        else {
                            $handshake-error = X::MoarVM::HandshakeFailed.new(reason => "Invalid magic in greeting: '$header'");
                        }
                    }
                }

                # Frame and decode MessagePack messages if handshake complete
                if $!handshake-done {
                    loop {
                        last if $!recv-buf.bytes - $!read-offset <= 0;
                        # Resumes where the previous read stopped; 0 until the message is complete
                        my int $sz = $!scanner.scan($!recv-buf, $!read-offset);
                        last if $sz == 0;

                        my @decoded;
                        my Str $failure;
                        {
                            @decoded = decode($!recv-buf, $!read-offset);
                            CATCH { default { $failure = .message } }
                        }
                        if $failure.defined {
                            # Skip the value the scanner delimited and keep reading the stream (B-8)
                            my Str $head = $!recv-buf.subbuf($!read-offset, min($sz, 16)).list.fmt('%02x', ' ');
                            @problems.push: "Skipped an undecodable message from the debug server ($failure); "
                            ~ "first bytes: $head";
                            $!read-offset += $sz;
                            next;
                        }
                        last if @decoded[1] == 0;

                        $!read-offset += @decoded[1];
                        @messages-to-dispatch.push(@decoded[0]);
                    }

                    $pending = $!recv-buf.bytes - $!read-offset;

                    # Compact buffer if cursor has advanced significantly
                    if $!read-offset > 65_536 && $!read-offset > ($!recv-buf.bytes div 2) {
                        $!recv-buf = Buf.new($!recv-buf.subbuf($!read-offset));
                        $!read-offset = 0;
                    }
                }
            }

            # A failed handshake ends the connection only after $!buf-lock is released: `terminated` subscribers must
            # never run under a lock (C-4)
            if $handshake-error.defined {
                $!handshake-promise.break($handshake-error) if $!handshake-promise.status ~~ Planned;
                self!handle-disconnect();
                return;
            }

            # Immediate ACKs keep small replies fast (DR-1), but while a large reply streams in they make MoarVM
            # send each small write as its own segment: tens of thousands of tiny reads. Delayed ACKs let it
            # coalesce them (decode-throughput: 100k reply 63k reads -> 1k reads).
            self!set-quickack($pending < 8_192);

            # Dispatch messages outside $!buf-lock. A failing handler must not end the reader (B-8).
            for @messages-to-dispatch -> $msg {
                self!dispatch-message($msg);
                CATCH { default { @problems.push: "Handling a debug server message failed: {.message}" } }
            }
            $!problems-supplier.emit($_) for @problems;
        },
        quit => -> $err {
            self!handle-disconnect();
        },
        done => {
            self!handle-disconnect();
        }
    );
}

method !dispatch-message(Associative $msg --> Nil) {
    my int $type = ($msg<type> // -1).Int;

    # Server-initiated event types (9, 10, 17, 23, 38)
    if is-stop-event($msg)
    || $type == MoarMsg::ThreadStarted.value
    || $type == MoarMsg::ThreadEnded.value {
        $!events-supplier.emit($msg);
        return;
    }

    # Check if message is a reply to an outstanding request (odd id)
    my $id = $msg<id>;
    if $id.defined && $id % 2 == 1 {
        my $promise;
        my Bool $is-invoke = False;
        $!pending-lock.protect: {
            if %!pending-requests{$id}:exists {
                $is-invoke = %!invoke-requests{$id}:exists;
                if $is-invoke && $type == MoarMsg::OperationSuccessful.value {
                    # Stage 1: OperationSuccessful acknowledgment for Invoke (36).
                    # Do not complete or delete %!pending-requests; wait for InvokeResult (37).
                    $promise = Nil;
                } else {
                    $promise = %!pending-requests{$id};
                    %!pending-requests{$id}:delete;
                    %!invoke-requests{$id}:delete;
                }
            }
        }
        if $is-invoke && $type == MoarMsg::OperationSuccessful.value {
            # Initial acknowledgment received, waiting for stage 2 (InvokeResult 37)
            return;
        }
        if $promise.defined {
            # Check for error reply types 0, 1, 39
            if $type == MoarMsg::ErrorCannotProcess.value
            || $type == MoarMsg::ErrorProcessing.value
            || $type == MoarMsg::OperationUnsuccessful.value {
                my Str $reason = $msg<reason> // "";
                $promise.break(X::MoarVM::RequestFailed.new(message-type => $type, :$reason));
            } else {
                $promise.keep($msg);
            }
            return;
        }
        # Late reply arriving after timeout is silently discarded unless timed-out invoke (C-5, D7)
        my Bool $was-timed-out-invoke = False;
        my Bool $delete-timed-out = (
            $type == MoarMsg::InvokeResult.value
            || $type == MoarMsg::ErrorCannotProcess.value
            || $type == MoarMsg::ErrorProcessing.value
            || $type == MoarMsg::OperationUnsuccessful.value
        );
        $!pending-lock.protect: {
            if %!timed-out-invokes{$id}:exists {
                $was-timed-out-invoke = True;
                %!timed-out-invokes{$id}:delete if $delete-timed-out;
            }
        }
        if $was-timed-out-invoke && $type == MoarMsg::InvokeResult.value {
            my Int $late-handle = ($msg<handle> // 0).Int;
            if $late-handle > 0 {
                try self.send-request(msg-release-handles([$late-handle]));
            }
        }
        return;
    }

    # Even id or no id: server-initiated event
    $!events-supplier.emit($msg);
}

#| True while an Invoke (36) sent on $thread (any thread if omitted) has not yet produced its result,
#| including after its timeout.
method invoke-in-flight(Int $thread? --> Bool) {
    $!pending-lock.protect: {
        my @threads = |%!invoke-requests.values, |%!timed-out-invokes.values;
        so $thread.defined ?? @threads.grep(* == $thread) !! @threads;
    }
}

method !next-id(--> Int) {
    $!id-lock.protect: {
        my $id = $!next-id;
        $!next-id += 2;
        $id;
    }
}

method !set-quickack(Bool $on, Bool :$force = False --> Nil) {
    my int32 $fd = $!native-fd;
    return if $fd < 0;
    my int $want = $on ?? 1 !! 0;
    return if !$force && $!quickack-state == $want;
    $!quickack-state = $want;
    try c_setsockopt($fd, IPPROTO_TCP, TCP_QUICKACK, $on ?? $!quickack-val !! $!quickack-off, 4);
}

# Send a request to MoarVM debug server, returning a Promise that resolves with the reply
method send-request(%fields, :$timeout = 5 --> Promise) {
    my int $type = (%fields<type> // -1).Int;
    # Guard: never allow Find Method (35) or Invoke (36) through send-request
    if $type == MoarMsg::FindMethodHandle.value || $type == MoarMsg::InvokeCodeObject.value {
        my $p = Promise.new;
        $p.break(X::MoarVM::Error.new(message => "Calling code in the debuggee is not supported (type $type)"));
        return $p;
    }

    self!send-wire-request(%fields, $type, :$timeout);
}

#| Sole authorized gateway for MoarVM Type 36 (Invoke).
method invoke(
    Int:D $code-handle,
    Int:D $thread,
    @arguments,
    :$timeout = 5
    --> Promise
) {
    my %msg = msg-invoke($thread, $code-handle, @arguments);
    self!send-wire-request(%msg, MoarMsg::InvokeCodeObject.value, :$timeout);
}

method !send-wire-request(%fields, Int:D $type, :$timeout = 5 --> Promise) {
    my int $id = self!next-id();
    my %msg = %( |%fields, id => $id );
    my Blob $encoded = encode(%msg);

    my $promise = Promise.new;
    $!pending-lock.protect: {
        %!pending-requests{$id} = $promise;
        %!invoke-requests{$id} = (%fields<thread> // 0).Int if $type == MoarMsg::InvokeCodeObject.value;
    }

    self!set-quickack(True, :force);
    $!socket.write($encoded).then(-> $w {
            self!set-quickack(True, :force);
            if $w.status == Broken {
                # Only the path that removes the pending entry resolves the request (C-4)
                my $mine = $!pending-lock.protect: {
                    %!invoke-requests{$id}:delete;
                    %!pending-requests{$id}:delete;
                };
                $mine.break($w.cause) if $mine.defined;
            }
    });

    # Handle timeout
    if $timeout > 0 {
        Promise.in($timeout).then(-> $t {
                # A reply that wins the race has already removed the entry; then the timeout does nothing (C-4)
                my $mine = $!pending-lock.protect: {
                    my $p = %!pending-requests{$id}:delete;
                    %!timed-out-invokes{$id} = %!invoke-requests{$id} if $p.defined && (%!invoke-requests{$id}:exists);
                    %!invoke-requests{$id}:delete;
                    $p;
                };
                $mine.break(X::MoarVM::Timeout.new(message-type => $type, :$id)) if $mine.defined;
        });
    }

    return $promise;
}

method !handle-disconnect(--> Nil) {
    # Fail all pending requests
    my @promises;
    $!pending-lock.protect: {
        @promises = %!pending-requests.values;
        %!pending-requests = ();
        %!invoke-requests = ();
        %!timed-out-invokes = ();
    }
    for @promises -> $p {
        $p.break(X::MoarVM::Error.new(message => "Connection closed"));
    }

    # Emit terminated
    $!native-fd = -1;
    $!quickack-state = -1;
    $!terminated-supplier.emit(True);
}

method close(--> Nil) {
    self!handle-disconnect();
    try {
        $!socket.close if $!socket.defined;
        CATCH { default {} }
    }
}
