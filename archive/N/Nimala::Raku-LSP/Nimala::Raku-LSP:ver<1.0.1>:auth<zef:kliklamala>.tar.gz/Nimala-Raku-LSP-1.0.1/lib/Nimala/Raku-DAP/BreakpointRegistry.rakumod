use v6.d;

#| Central registry owning line, function, exception, and entry breakpoints,
#| MoarVM breakpoint IDs, user line tracking, and hit counts (A-2).
unit class Nimala::Raku-DAP::BreakpointRegistry;

use Nimala::URI;
use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Expression;
use Nimala::Raku-DAP::Trace;
use Nimala::Raku-DAP::SourceLines;

#| Predicate on the hit count for a DAP `hitCondition` (`N`, `==N`, `>N`, `>=N`, `<N`, `<=N`, `%N`), or an
#| undefined Callable when the condition cannot be parsed. Shared by validation and evaluation (B-17).
our sub hit-condition-predicate(Str $hit-cond --> Callable) is export {
    given $hit-cond.trim {
        when /^ '=='? \s* (\d+) $/ { my Int $n = +$0; return -> Int $c { $c == $n } }
        when /^ '>=' \s* (\d+) $/  { my Int $n = +$0; return -> Int $c { $c >= $n } }
        when /^ '>' \s* (\d+) $/   { my Int $n = +$0; return -> Int $c { $c > $n } }
        when /^ '<=' \s* (\d+) $/  { my Int $n = +$0; return -> Int $c { $c <= $n } }
        when /^ '<' \s* (\d+) $/   { my Int $n = +$0; return -> Int $c { $c < $n } }
        when /^ '%' \s* (\d+) $/   { my Int $n = +$0; return -> Int $c { $n > 0 && $c %% $n } }
    }
    Callable;
}

#| Validate breakpoint condition and hitCondition expressions (M-1).
#| Returns empty Str if both valid, or diagnostic error message if invalid.
our sub validate-breakpoint-conditions(Str $cond, Str $hit-cond --> Str) is export {
    my Str $c = $cond.trim;
    if $c ne '' {
        my $parsed = Nimala::Raku-DAP::Expression.parse($c);
        if !$parsed.defined || !$parsed.success {
            return "Condition outside bounded grammar: " ~ ($parsed.defined ?? $parsed.error-message !! "syntax error");
        }
    }
    my Str $hc = $hit-cond.trim;
    if $hc ne '' && !hit-condition-predicate($hc).defined {
        return "Invalid hit condition '$hc': use N, ==N, >N, >=N, <N, <=N or %N";
    }
    '';
}

# Monotonic DAP breakpoint ID generator
has Int $!next-dap-id = 1;

# Breakpoint collections
has %.line-breakpoints;            # canonical-path($file) => Array of %bp
has %.active-line-breakpoints;     # canonical-path($file) => Hash of line => confirmed-line
has @.early-function-breakpoints is rw; # Array of %bp buffered before connect
has %.function-positions;          # bp-key($file, $line) => %info
has @.exception-filters is rw;     # Array[Str]
has %.exception-filter-conditions is rw; # Str filter => Str condition
has Int $.uncaught-exception-bp-id = 0;
has Int $.all-exception-bp-id = 0;
has Str $.helper-file = '';
has Int $.helper-uncaught-line = 0;
has Int $.helper-all-line = 0;

# Entry breakpoint state
has Str $.entry-bp-file = '';
has Int $.entry-bp-line = 0;
has Int $.entry-bp-id = 0;
has Bool $.entry-bp-is-temporary = False;

# MoarVM ID lookup and active user lines
has %.moar-id-to-info;             # MoarVM Int ID => %( file => canon, line => Int, kind => Str )
has SetHash $!user-lines .= new;   # canonical bp-key => True
has %!hit-counts;                  # canonical bp-key => Int

method next-dap-id(--> Int) {
    $!next-dap-id++;
}

#| Query whether a file/line position is an active user line (line or function breakpoint).
method is-user-line(Str $file, Int $line? --> Bool) {
    if $line.defined {
        ?($!user-lines{bp-key($file, $line)});
    } elsif $file.contains(':') {
        my ($f, $l) = $file.split(':', 2);
        ?($!user-lines{bp-key($f, $l.Int)});
    } else {
        ?($!user-lines{canonical-path($file)});
    }
}

#| Count a hit at a canonical breakpoint position and evaluate a non-empty hitCondition against the new count.
method evaluate-hit-condition(Str $hit-cond, Str $file, Int $line? --> Bool) {
    return True if $hit-cond.trim eq '';
    my &stops = hit-condition-predicate($hit-cond);
    return False unless &stops.defined;
    my Str $key = $line.defined ?? bp-key($file, $line) !! (if $file.contains(':') { my ($f, $l) = $file.split(':', 2); bp-key($f, $l.Int) } else { canonical-path($file) });
    stops(%!hit-counts{$key} = (%!hit-counts{$key} // 0) + 1);
}

#| Forget the hit counts of every breakpoint in $file (B-17).
method reset-hit-counts(Str $file --> Nil) {
    my Str $canon = canonical-path($file);
    %!hit-counts{$_}:delete for %!hit-counts.keys.grep(*.starts-with("$canon:"));
}

#| Reset per-process MoarVM breakpoint state between debuggee runs (D-9).
method reset-session-state(--> Nil) {
    %!moar-id-to-info = %();
    %!active-line-breakpoints = %();
    %!function-positions = %();
    $!user-lines = SetHash.new;
    %!hit-counts = %();
    $!uncaught-exception-bp-id = 0;
    $!all-exception-bp-id = 0;
    $!entry-bp-id = 0;
    $!entry-bp-file = '';
    $!entry-bp-line = 0;
    $!entry-bp-is-temporary = False;
    $!helper-file = '';
    $!helper-uncaught-line = 0;
    $!helper-all-line = 0;
}

#| Find matching line breakpoint specification for a file and line.
method find-line-breakpoint(Str $file, Int $line --> Hash) {
    return %() unless $file ne '' && $line > 0;
    my Str $canon = canonical-path($file);
    if %!line-breakpoints{$canon}:exists {
        for %!line-breakpoints{$canon}.list -> %bp {
            if %bp<line>.Int == $line && (%bp<verified> // True) {
                return %bp;
            }
        }
    }
    %();
}

#| Find matching function breakpoint specification for a file and line.
method find-function-breakpoint(Str $file, Int $line --> Hash) {
    return %() unless $file ne '' && $line > 0;
    my Str $key = bp-key($file, $line);
    return %!function-positions{$key} if %!function-positions{$key}:exists;
    %();
}

#| Low-level: send MoarVM Type-15 (Set Breakpoint) and record in registry (E-1).
method set-moar-breakpoint(
    Any $proto,
    Str $file,
    Int $line,
    Str :$kind = 'user'
    --> Promise
) {
    my Str $canon-file = canonical-path($file);
    $proto.send-request(msg-breakpoint-set($canon-file, $line, :suspend(True), :stacktrace(False))).then(-> $p {
            if $p.status == Kept {
                my $res = $p.result;
                if $res && $res<id>.defined {
                    my Int $id = $res<id>.Int;
                    my Int $confirmed-line = ($res<line>.defined ?? $res<line>.Int !! $line);
                    %!moar-id-to-info{$id} = %( file => $canon-file, line => $confirmed-line, :$kind );
                    if $kind eq 'line' || $kind eq 'function' {
                        $!user-lines.set(bp-key($canon-file, $confirmed-line));
                    }
                    %( ok => True, id => $id, line => $confirmed-line );
                } else {
                    %( ok => False, id => 0, line => $line, message => "Debuggee rejected breakpoint at {$canon-file.IO.basename}:$line" );
                }
            } else {
                %( ok => False, id => 0, line => $line, message => "Failed to set breakpoint at {$canon-file.IO.basename}:$line" );
            }
    });
}

#| Low-level: remove from registry and send MoarVM Type-18 (Clear Breakpoint) unless a line or function
#| breakpoint still uses that line.
method clear-moar-breakpoint(
    Any $proto,
    Str $file,
    Int $line,
    Int :$moar-id = 0
    --> Promise
) {
    my Str $canon-file = canonical-path($file);
    my Str $key = bp-key($canon-file, $line);
    if $moar-id > 0 {
        %!moar-id-to-info{$moar-id}:delete;
    } else {
        for %!moar-id-to-info.kv -> Str $id, %info {
            if %info<file> eq $canon-file && %info<line> == $line {
                %!moar-id-to-info{$id}:delete;
            }
        }
    }
    my Bool $still-user = self!is-line-still-active($canon-file, $line);
    unless $still-user {
        $!user-lines.unset($key);
        return $proto.send-request(msg-breakpoint-clear($canon-file, $line));
    }
    Promise.kept(True);
}

method !is-line-still-active(Str $canon-file, Int $line --> Bool) {
    my Str $key = bp-key($canon-file, $line);
    return True if %!function-positions{$key}:exists;
    if %!active-line-breakpoints{$canon-file}:exists {
        return True if %!active-line-breakpoints{$canon-file}.values.grep(* == $line);
    }
    False;
}

#| Store line breakpoints, reset hit counts, and synchronize with MoarVM if connected.
method set-line-breakpoints(
    Str $file,
    @adjusted-bps,
    :$protocol = Any,
    Bool :$connected = False
    --> Promise
) {
    start {
        my Str $canon-file = canonical-path($file);
        self.reset-hit-counts($canon-file);
        %!line-breakpoints{$canon-file} = @adjusted-bps.Array;

        my @dap-bps;
        my SetHash $new-lines .= new;
        for @adjusted-bps -> %bp {
            my Int $id = %bp<id>.Int;
            my Int $line = %bp<line>.Int;
            if %bp<verified> {
                $new-lines.set($line);
                @dap-bps.push(hash( :$id, verified => True, :$line ));
            } else {
                @dap-bps.push(hash( :$id, verified => False, :$line, message => (%bp<message> // '').Str ));
            }
        }

        if $connected && $protocol.defined {
            my @old-lines = (%!active-line-breakpoints{$canon-file} // Hash.new).keys.map(*.Int);
            my @to-clear = @old-lines.grep({ !$new-lines{$_} });
            for @to-clear -> $l {
                my Int $line-to-clear = (%!active-line-breakpoints{$canon-file}{$l} // $l).Int;
                %!active-line-breakpoints{$canon-file}{$l}:delete;
                attempt(self.clear-moar-breakpoint($protocol, $canon-file, $line-to-clear), 'clear moar breakpoint');
            }

            my @to-add = $new-lines.keys.map(*.Int).grep({ !(%!active-line-breakpoints{$canon-file}{$_}:exists) });
            for @to-add -> $l {
                my %res = attempt(self.set-moar-breakpoint($protocol, $canon-file, $l, :kind<line>), 'set moar breakpoint') // %();
                if %res<ok> {
                    my Int $confirmed-line = %res<line>.Int;
                    %!active-line-breakpoints{$canon-file} //= Hash.new;
                    %!active-line-breakpoints{$canon-file}{$l} = $confirmed-line;
                    for @dap-bps -> %dbp {
                        if %dbp<line> == $l && %dbp<verified> {
                            %dbp<line> = $confirmed-line;
                        }
                    }
                } else {
                    for @dap-bps -> %dbp {
                        if %dbp<line> == $l && %dbp<verified> {
                            %dbp<verified> = False;
                            %dbp<message> = %res<message> // "Debuggee rejected breakpoint at $canon-file:$l";
                        }
                    }
                }
            }
        }

        @dap-bps;
    }
}

#| Synchronize function breakpoint positions with MoarVM (B-13, E-1).
method sync-function-positions(
    %new-func-positions,
    Any $proto
    --> Promise
) {
    start {
        my SetHash $confirmed-keys .= new;
        if !$proto.defined {
            $confirmed-keys;
        } else {
            for %!function-positions.values -> %old {
                my Str $old-file = canonical-path(%old<file>);
                my Int $old-line = %old<line>.Int;
                my Str $old-key = bp-key($old-file, $old-line);
                unless %new-func-positions{$old-key}:exists {
                    %!function-positions{$old-key}:delete;
                    attempt(self.clear-moar-breakpoint($proto, $old-file, $old-line, :moar-id((%old<moar-id> // 0).Int)), 'clear moar breakpoint');
                }
            }

            for %new-func-positions.kv -> Str $key, %pos {
                my Str $file = canonical-path(%pos<file>);
                my Int $line = %pos<line>.Int;
                if %!function-positions{$key}:exists {
                    $confirmed-keys.set($key);
                } else {
                    my %res = attempt(self.set-moar-breakpoint($proto, $file, $line, :kind<function>), 'set moar breakpoint') // %();
                    if %res<ok> {
                        my %entry = %pos;
                        %entry<file> = $file;
                        %entry<line> = %res<line>.Int;
                        %entry<moar-id> = %res<id>.Int;
                        %!function-positions{$key} = %entry;
                        $confirmed-keys.set($key);
                    }
                }
            }

            $confirmed-keys;
        }
    }
}

#| Synchronize exception breakpoint filters with MoarVM.
method apply-exception-filters(
    Any $proto,
    @filters,
    Str :$helper-file is copy = '',
    Int :$helper-uncaught-line is copy = 0,
    Int :$helper-all-line is copy = 0,
    Int :$uncaught-line = 0,
    Int :$all-line = 0
    --> Promise
) {
    start {
        @!exception-filters = @filters.map(*.Str).Array;
        $!helper-file = $helper-file if $helper-file ne '';
        $!helper-uncaught-line = ($helper-uncaught-line || $uncaught-line).Int if ($helper-uncaught-line || $uncaught-line) > 0;
        $!helper-all-line = ($helper-all-line || $all-line).Int if ($helper-all-line || $all-line) > 0;

        if !($proto.defined && $!helper-file ne '' && $!helper-file.IO.e) {
            True;
        } else {
            my Bool $want-uncaught = 'uncaught' (elem) @!exception-filters;
            my Bool $want-all = 'all' (elem) @!exception-filters;

            if $want-uncaught && $!uncaught-exception-bp-id == 0 && $!helper-uncaught-line > 0 {
                my %res = attempt(self.set-moar-breakpoint($proto, $!helper-file, $!helper-uncaught-line, :kind<exception-uncaught>), 'set moar breakpoint') // %();
                if %res<ok> {
                    $!uncaught-exception-bp-id = %res<id>.Int;
                }
            } elsif !$want-uncaught && $!uncaught-exception-bp-id > 0 {
                attempt(self.clear-moar-breakpoint($proto, $!helper-file, $!helper-uncaught-line, :moar-id($!uncaught-exception-bp-id)), 'clear moar breakpoint');
                $!uncaught-exception-bp-id = 0;
            }

            if $want-all && $!all-exception-bp-id == 0 && $!helper-all-line > 0 {
                my %res = attempt(self.set-moar-breakpoint($proto, $!helper-file, $!helper-all-line, :kind<exception-all>), 'set moar breakpoint') // %();
                if %res<ok> {
                    $!all-exception-bp-id = %res<id>.Int;
                }
            } elsif !$want-all && $!all-exception-bp-id > 0 {
                attempt(self.clear-moar-breakpoint($proto, $!helper-file, $!helper-all-line, :moar-id($!all-exception-bp-id)), 'clear moar breakpoint');
                $!all-exception-bp-id = 0;
            }

            True;
        }
    }
}

#| Set up entry breakpoint for stopOnEntry.
method setup-entry-breakpoint(
    Any $proto,
    Str $prog-path,
    Int $target-line
    --> Promise
) {
    start {
        my Str $canon-prog = canonical-path($prog-path);
        my Bool $has-line = %!active-line-breakpoints{$canon-prog}:exists && (%!active-line-breakpoints{$canon-prog}{$target-line}:exists);
        my Bool $has-func = %!function-positions{bp-key($canon-prog, $target-line)}:exists;
        my Bool $already-has-bp = $has-line || $has-func;
        $!entry-bp-file = $canon-prog;
        $!entry-bp-line = $target-line;
        if !$already-has-bp {
            $!entry-bp-is-temporary = True;
            my %res = attempt(self.set-moar-breakpoint($proto, $canon-prog, $target-line, :kind<entry>), 'set moar breakpoint') // %();
            if %res<ok> {
                $!entry-bp-id = %res<id>.Int;
            }
        } else {
            $!entry-bp-is-temporary = False;
            $!entry-bp-id = 0;
        }
        True;
    }
}

#| Check whether a stop event matches entry breakpoint and clear temporary entry breakpoint if needed.
method check-and-clear-entry-hit(
    Any $proto,
    Int $ev-bp-id,
    Str $top-file,
    Int $top-line
    --> Promise
) {
    start {
        if $!entry-bp-file eq '' {
            False;
        } else {
            my Str $canon-top = canonical-path($top-file);
            my Bool $is-entry-hit = ($!entry-bp-id > 0 && $ev-bp-id == $!entry-bp-id)
            || ($canon-top ne '' && $canon-top eq $!entry-bp-file && $top-line == $!entry-bp-line);
            if $is-entry-hit {
                if $!entry-bp-is-temporary && $!entry-bp-line > 0 && $!entry-bp-file ne '' {
                    attempt(self.clear-moar-breakpoint($proto, $!entry-bp-file, $!entry-bp-line, :moar-id($!entry-bp-id)), 'clear moar breakpoint');
                }
                $!entry-bp-file = '';
                $!entry-bp-line = 0;
                $!entry-bp-id = 0;
                $!entry-bp-is-temporary = False;
                True;
            } else {
                False;
            }
        }
    }
}
