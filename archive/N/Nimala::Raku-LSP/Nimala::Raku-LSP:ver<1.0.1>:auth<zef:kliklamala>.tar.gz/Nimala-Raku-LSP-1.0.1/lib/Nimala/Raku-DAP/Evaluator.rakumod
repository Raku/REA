use v6.d;
unit class Nimala::Raku-DAP::Evaluator;

use Nimala::Raku-DAP::Protocol;
use Nimala::Raku-DAP::Protocol::Messages;
use Nimala::Raku-DAP::Handles;
use Nimala::Raku-DAP::Remote;
use Nimala::Raku-DAP::ValueRenderer;
use Nimala::Raku-DAP::Expression;
use Nimala::Raku-DAP::ThreadState;
use Nimala::Raku-DAP::FrameClassifier;
use Nimala::Raku-DAP::Trace;

has Nimala::Raku-DAP::Remote $.remote is required;
has Nimala::Raku-DAP::Handles $.handles is required;
has Nimala::Raku-DAP::ValueRenderer $.renderer is required;
has Nimala::Raku-DAP::FrameClassifier $.frame-classifier is required;
has Nimala::Raku-DAP::ThreadRegistry $.threads is required;

method handles(--> Nimala::Raku-DAP::Handles) {
    $!handles
}

#| Typed container representing intermediate evaluation values.
class EvalValue is export {
    has Str $.kind = '';
    has Str $.type = '';
    has Str $.val = '';
    has Bool $.concrete = True;
    has Int $.handle = 0;
    has Int $.gen = 0;

    method from-unwrapped(%u --> EvalValue) {
        self.bless(
            kind     => (%u<kind> // '').Str,
            type     => (%u<type> // '').Str,
            val      => (%u<val> // '').Str,
            concrete => (%u<concrete> // True).Bool,
            handle   => (%u<handle> // 0).Int,
            gen      => (%u<gen> // 0).Int
        )
    }
}

method thread-state(Int $thread-id --> Nimala::Raku-DAP::ThreadState) {
    $!threads.thread-state($thread-id);
}

method stopped-thread(--> Int) {
    $!threads.stopped-thread;
}

method evaluate-expression(
    Str $expression,
    Int $frame-id,
    Str :$context = '',
    Promise :$invoke-started
    --> Promise
) {
    start {
        my Int $thread = self.stopped-thread;
        my Int $frame-idx = 0;
        my Bool $frame-valid = True;

        if $frame-id > 0 {
            my %fi = (try self.handles.resolve-frame($frame-id)) // {};
            if %fi {
                $thread = %fi<thread>;
                $frame-idx = %fi<frame-index>;
            } else {
                $frame-valid = False;
            }
        }

        my $t-state = self.thread-state($thread);
        if !$t-state.is-stopped {
            %( success => False, message => "notStopped" );
        } else {
            my $parsed = Nimala::Raku-DAP::Expression.parse($expression);
            if !$parsed.success {
                %( success => False, message => $parsed.error-message );
            } else {
                my $expr = $parsed.expr;
                if $frame-id <= 0 {
                    my @frames = ($t-state.frames // []).flat;
                    if !@frames {
                        my $st-res = attempt($!remote.stack-trace($thread), 'stack trace');
                        @frames = ($st-res<frames> // []).flat if $st-res && $st-res<frames>;
                    }
                    if $!frame-classifier.defined {
                        for @frames.kv -> $idx, %f {
                            my Str $file = (%f<file> // '').Str;
                            my Str $name = (%f<name> // '').Str;
                            if !$!frame-classifier.is-internal-frame($file, $name) {
                                $frame-idx = $idx;
                                last;
                            }
                        }
                    }
                }

                my $helper-acc = $expr.accessors.first({ $_.kind eq 'helper_method' });
                my Bool $has-helper = ?$helper-acc;
                my Str $cache-key = "$thread\0$frame-idx\0$expression";
                my $cached = $has-helper ?? self.handles.invoke-result($cache-key) !! Nil;
                if $cached.defined && $cached.elems > 0 {
                    $cached;
                } elsif $has-helper && ($context eq 'hover' || $context eq 'watch') {
                    %(
                        success => False,
                        message => "Helper method .{$helper-acc.key} is not evaluated on $context"
                    );
                } elsif $has-helper && self.handles.invoke-spent {
                    %(
                        success => False,
                        message => AT-MOST-ONE-MESSAGE
                    );
                } elsif !$frame-valid {
                    %( success => False, message => "Invalid frameId $frame-id" );
                } else {
                    my $ctx-res = attempt($!remote.context($thread, $frame-idx), 'context');
                    my Int $start-ctx = ($ctx-res<handle> // 0).Int;
                    self.handles.record-handle($start-ctx) if $start-ctx > 0;

                    if $start-ctx <= 0 {
                        %( success => False, message => "Context not found for frame" );
                    } else {
                        my %found = await $!remote.find-lexical($start-ctx, $expr.var-name);
                        if !%found<found> {
                            %( success => False, message => "Variable '{$expr.var-name}' not found in frame" );
                        } else {
                            my %res = await self.resolve-and-evaluate(
                                $expr, %found<entry>, $thread, $start-ctx, :expression($expression), :$invoke-started
                            );
                            if $has-helper && (%res<gen> // 0) > 0 && (%res<success> // False) {
                                self.handles.remember-invoke-result(%res<gen>.Int, $cache-key, %res);
                            }
                            %res;
                        }
                    }
                }
            }
        }
    }
}

method resolve-and-evaluate(
    Nimala::Raku-DAP::Expression::ParsedExpr $expr,
    %var-entry,
    Int $thread,
    Int $start-ctx = 0,
    Str :$expression = '',
    Promise :$invoke-started
    --> Promise
) {
    start {
        my %unwrapped = await $!remote.unwrap-value(%var-entry, $thread);
        my EvalValue $cur-val = EvalValue.from-unwrapped(%unwrapped);

        my %step-res = await self!step-accessors($expr, $cur-val, $thread, $start-ctx, :$invoke-started);

        if %step-res<failed> {
            %( success => False, message => %step-res<fail-msg> );
        }
        elsif $expr.is-comparison {
            my EvalValue $ev = %step-res<eval-value>;
            my %cmp-res = self!eval-comparison($expr, $ev.val, $ev.concrete);
            hash( |%cmp-res, gen => $ev.gen );
        }
        else {
            my EvalValue $ev = %step-res<eval-value>;
            my %rendered = await self!render-eval-result(
                $ev.type, $ev.kind, $ev.val, $ev.handle, $ev.concrete, $thread,
                :expression($expression || $expr.var-name)
            );
            hash( |%rendered, gen => $ev.gen );
        }
    }
}

#| Unified accessor stepper loop (M-1) using EvalValue.
method !step-accessors(
    Nimala::Raku-DAP::Expression::ParsedExpr $expr,
    EvalValue $initial,
    Int $thread,
    Int $start-ctx,
    Promise :$invoke-started
    --> Promise
) {
    start {
        my EvalValue $cur-val = $initial;
        my Bool $failed = False;
        my Str $fail-msg = '';

        for $expr.accessors -> $acc {
            if $acc.kind eq 'meta_what' {
                $cur-val = EvalValue.new(
                    kind     => 'type',
                    type     => $cur-val.type,
                    val      => "({$cur-val.type})",
                    concrete => False,
                    handle   => 0
                );
                next;
            }

            my %step = await do given $acc.kind {
                when 'attribute' {
                    self!eval-attribute-accessor($acc.key, $cur-val.handle, $thread);
                }
                when 'positional' {
                    self!eval-positional-accessor($acc.key, $cur-val.type, $cur-val.handle, $thread);
                }
                when 'associative' | 'associative_var' {
                    self!eval-associative-accessor($acc, $cur-val.type, $cur-val.handle, $thread, $start-ctx);
                }
                when 'helper_method' {
                    self!eval-helper-accessor($acc.key, $cur-val.handle, $thread, :$invoke-started);
                }
                default {
                    %( success => False, message => "Unknown accessor kind: {$acc.kind}" );
                }
            };

            if %step<success> {
                $cur-val = EvalValue.from-unwrapped(%step);
            } else {
                $failed = True;
                $fail-msg = (%step<message> // 'Accessor evaluation failed').Str;
                last;
            }
        }

        hash(
            :$failed,
            :$fail-msg,
            eval-value => $cur-val
        );
    }
}

method !eval-attribute-accessor(Str $attr-target, Int $cur-handle, Int $thread --> Promise) {
    start {
        my $p-attr = attempt($!remote.attributes($cur-handle, :$thread), 'attributes');
        my @attrs = ($p-attr<attributes> // []).flat;
        my @candidates = (
            $attr-target, '$!' ~ $attr-target, '!' ~ $attr-target, '$.' ~ $attr-target, '$' ~ $attr-target
        );
        my $match = @attrs.first({ ($_<name> // '').Str (elem) @candidates });
        if $match {
            my %unwrapped = await $!remote.unwrap-value(%($match), $thread);
            %( success => True, |%unwrapped );
        } else {
            %( success => False, message => "Attribute '$attr-target' not found" );
        }
    }
}

method !eval-positional-accessor(Str $key, Str $cur-type, Int $cur-handle, Int $thread --> Promise) {
    start {
        my Int $idx = $key.Int;
        my Int $target-handle = $cur-handle;
        if $cur-type eq any(@POSITIONAL-TYPES) {
            my Int $stor = $!remote.collection-storage($cur-handle, :$thread);
            $target-handle = $stor if $stor > 0;
        }
        my Promise $pos-p = $!remote.positionals($target-handle, :$thread, :timeout(30));
        my $p-pos = attempt($pos-p, 'positionals');
        my @elems = ($p-pos<contents> // []).flat;
        $idx = @elems.elems + $idx if $idx < 0;
        if !$p-pos {
            %( success => False, message => $!remote.read-failure-message($pos-p, 'elements') );
        } elsif $idx >= 0 && $idx < @elems.elems {
            my %unwrapped = await $!remote.unwrap-value(@elems[$idx], $thread);
            %( success => True, |%unwrapped );
        } else {
            %( success => False, message => "Index $key out of bounds" );
        }
    }
}

method !eval-associative-accessor($acc, Str $cur-type, Int $cur-handle, Int $thread, Int $start-ctx --> Promise) {
    start {
        my Str $k = $acc.key;
        my Bool $failed = False;
        my Str $fail-msg = '';

        if $acc.kind eq 'associative_var' {
            my Str $vkey = $acc.key;
            my %found = await $!remote.find-lexical($start-ctx, $vkey);
            if !%found<found> {
                $failed = True;
                $fail-msg = "Variable '$vkey' used as hash key not found in frame";
            } else {
                my %uk = await $!remote.unwrap-value(%found<entry>, $thread);
                $k = %uk<val>;
            }
        }

        if $failed {
            %( success => False, message => $fail-msg );
        } else {
            my Int $target-handle = $cur-handle;
            if $cur-type eq any(@ASSOCIATIVE-TYPES) {
                my Int $stor = $!remote.collection-storage($cur-handle, :$thread);
                $target-handle = $stor if $stor > 0;
            }
            my Promise $ass-p = $!remote.associatives($target-handle, :$thread, :timeout(15));
            my $p-ass = attempt($ass-p, 'associatives');
            my %contents = $p-ass<contents> // {};
            if !$p-ass {
                %( success => False, message => $!remote.read-failure-message($ass-p, 'entries') );
            } elsif (%contents{$k}:exists) {
                my %unwrapped = await $!remote.unwrap-value(%contents{$k}, $thread);
                %( success => True, |%unwrapped );
            } else {
                %( success => False, message => "Key '$k' not found" );
            }
        }
    }
}

method !eval-helper-accessor(Str $m, Int $cur-handle, Int $thread, Promise :$invoke-started --> Promise) {
    start {
        my $invoke-res;
        my Str $fail-msg = '';
        try {
            my Promise $invoke-p = $!remote.invoke-helper(
                $m, $cur-handle, $thread, :started($invoke-started), :timeout(15)
            );
            $invoke-res = await $invoke-p;
            CATCH {
                when X::MoarVM::Timeout {
                    $fail-msg = "Evaluation of .$m timed out and is still running in the debuggee; "
                    ~ "stepping and resuming are refused until it finishes";
                }
                default {
                    $fail-msg = .message eq AT-MOST-ONE-MESSAGE
                    ?? AT-MOST-ONE-MESSAGE
                    !! "Invocation of $m failed: " ~ .message;
                }
            }
        }

        if !$invoke-res {
            %( success => False, message => ($fail-msg ne '' ?? $fail-msg !! "Invocation of $m failed") );
        } else {
            my Str $res-kind = ($invoke-res<kind> // '').Str;
            my Str $res-type = ($invoke-res<obj_type> // '').Str;
            my Bool $res-concrete = ($invoke-res<concrete> // True).Bool;
            my Int $res-handle = ($invoke-res<handle> // 0).Int;
            my Int $gen = ($invoke-res<gen> // 0).Int;

            self.handles.record-handle($res-handle) if $res-handle > 0;

            my $val;
            if ($invoke-res<result>:exists) && $invoke-res<result><value>.defined {
                $val = $invoke-res<result><value>.Str;
            }
            elsif $invoke-res<value>.defined {
                $val = $invoke-res<value>.Str;
            }
            elsif $res-handle > 0 {
                my $p-attr = attempt($!remote.attributes($res-handle, :$thread), 'attributes');
                if $p-attr && $p-attr<attributes> {
                    my %v = attribute-named($p-attr<attributes> // [], '$!value');
                    $val = %v<value>.Str if %v<value>.defined;
                }
            }
            hash(
                success  => True,
                cur      => %(),
                kind     => $res-kind,
                type     => ($res-type ne '' ?? $res-type !! ($m eq 'elems' ?? 'Int' !! 'Str')),
                concrete => $res-concrete,
                handle   => $res-handle,
                val      => ($val // ''),
                gen      => $gen
            );
        }
    }
}

method !eval-comparison($expr, Str $cur-val, Bool $concrete --> Hash) {
    my Bool $cmp = False;
    my Bool $coercion-failed = False;
    my $raw-val = do given $expr.literal-type {
        when 'Int' {
            if $cur-val.defined && $cur-val.trim.chars > 0 && ($cur-val.trim ~~ /^ <[+-]>? \d+ $/) {
                +$cur-val.trim;
            } else {
                $coercion-failed = True;
                Nil;
            }
        }
        when 'Num' {
            my $trimmed = $cur-val.defined ?? $cur-val.trim !! '';
            my $is-num = $trimmed.chars > 0
            && ($trimmed ~~ /^ <[+-]>? [\d+ [\. \d*]? | \. \d+] [<[eE]> <[+-]>? \d+]? $/);
            if $is-num {
                +$trimmed;
            } else {
                $coercion-failed = True;
                Nil;
            }
        }
        when 'Bool' { $cur-val eq 'True' || $cur-val eq '1' }
        when 'Nil'  { $concrete && $cur-val ne 'Nil' ?? $cur-val !! Any }
        default     { $cur-val }
    };
    if !$coercion-failed {
        $cmp = Nimala::Raku-DAP::Expression.eval-comparison(
            $raw-val, $expr.op, $expr.literal, :literal-type($expr.literal-type)
        );
    }
    %(
        success => True,
        result => ($cmp ?? 'True' !! 'False'),
        type => 'Bool',
        variablesReference => 0
    );
}

method !render-eval-result(
    Str $cur-type,
    Str $cur-kind,
    Str $cur-val,
    Int $cur-handle,
    Bool $concrete,
    Int $thread,
    Str :$expression = ''
    --> Promise
) {
    start {
        my Int $vref = 0;
        my Bool $is-box-primitive = ?($cur-type eq any('Int', 'Str', 'Bool', 'Num'));
        if $cur-kind eq 'obj' && $cur-handle > 0 && $concrete && !$is-box-primitive {
            $vref = self.handles.allocate-object-ref(
                $cur-handle, :type($cur-type), :kind($cur-kind), :$thread, :evaluate-name($expression.trim)
            );
        }
        my Str $disp = $cur-val;
        my Bool $is-coll = ?($cur-type eq any(|@POSITIONAL-TYPES, |@ASSOCIATIVE-TYPES));
        my Int $elems = 0;
        if $is-coll && $cur-handle > 0 && $concrete {
            my $rend = $!renderer;
            my $summary = await $rend.render-collection-display($cur-handle, $thread, $cur-type);
            $disp = $summary.Str;
            $elems = ($summary.elems // 0).Int;
        }
        if $disp eq '' || $disp eq "<$cur-type>" {
            if !$concrete {
                $disp = "($cur-type)";
            } elsif $cur-type eq 'Str' && $disp eq '' && ($cur-kind eq 'str' || $cur-handle > 0) {
                $disp = '""';
            } else {
                $disp = $cur-type ne '' ?? "<$cur-type>" !! "($cur-kind)";
            }
        }
        my %res = %(
            success => True,
            result => $disp,
            type => $cur-type,
            variablesReference => $vref
        );
        set-child-counts(%res, $cur-type, $elems);
        if !$concrete {
            %res<presentationHint> = %( kind => 'class' );
        }
        %res;
    }
}
