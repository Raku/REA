use v6.d;
unit class Nimala::Raku-DAP::Expression;

use Nimala::Raku-DAP::Protocol::Messages;

class MemberAccess {
    # 'attribute', 'associative', 'associative_var', 'positional', 'helper_method', 'meta_what'
    has Str $.kind is required;
    has Str $.key is required;  # attribute name, hash key, key variable, array index, or method name
}

class ParsedExpr {
    has Str $.var-name is required;
    has MemberAccess @.accessors;
    has Bool $.is-comparison is rw = False;
    has Str $.op is rw;
    has Any $.literal is rw;
    has Str $.literal-type is rw;
}

class ParseResult {
    has Bool $.success is required;
    has ParsedExpr $.expr;
    has Str $.error-message = '';
}

grammar Grammar {
    rule TOP {
        ^ <ref> [ <comp_op> <literal> ]? $
    }

    token ref {
        <variable> <accessor>*
    }

    token variable {
        <sigil> <twigil>? <ident>
    }

    token sigil { '$' | '@' | '%' | '&' }
    token twigil { '!' | '?' | '*' | '.' }
    token ident { [<:alpha> | '_'] <[\w\-]>* }

    proto token accessor { * }
    token accessor:sym<helper_method> {
        '.' $<method>=[@HELPER-METHODS] <!before <[\w\-]> > [ \s* '(' \s* ')' ]?
    }
    token accessor:sym<what> {
        '.WHAT' <!before <[\w\-]> > [ \s* '(' \s* ')' ]?
    }
    token accessor:sym<dot> {
        '.' <!before [@HELPER-METHODS] <!before <[\w\-]> > > <twigil>? <ident> <!before \s* '('>
    }
    token accessor:sym<angle> {
        '<' ~ '>' <key=angle_key>
    }
    token accessor:sym<curly> {
        '{' ~ '}' [
            | '\'' ~ '\'' <key=single_str>
            | '"' ~ '"' <key=double_str>
            | <var_key=variable>
            | <key=ident>
        ]
    }
    token accessor:sym<bracket> {
        '[' ~ ']' <index=integer>
    }

    token angle_key {
        <-[ > ]>+
    }
    token single_str {
        <-[ ' ]>*
    }
    token double_str {
        <-[ " ]>*
    }
    token integer {
        '-'? <[0..9]>+
    }

    proto token comp_op { * }
    token comp_op:sym<eqeq>     { '==' }
    token comp_op:sym<bangeq>   { '!=' }
    token comp_op:sym<lteq>     { '<=' }
    token comp_op:sym<gteq>     { '>=' }
    token comp_op:sym<lt>       { '<' }
    token comp_op:sym<gt>       { '>' }
    token comp_op:sym<streq>    { 'eq' }
    token comp_op:sym<strne>    { 'ne' }
    token comp_op:sym<strlt>    { 'lt' }
    token comp_op:sym<strle>    { 'le' }
    token comp_op:sym<strgt>    { 'gt' }
    token comp_op:sym<strge>    { 'ge' }

    proto token literal { * }
    token literal:sym<bool> { 'True' | 'False' }
    token literal:sym<nil>  { 'Nil' }
    token literal:sym<num>  { '-'? \d+ [ '.' \d+ ]? <[eE]> <[+-]>? \d+ | '-'? \d+ '.' \d+ }
    token literal:sym<int>  { '-'? \d+ }
    token literal:sym<sstr> { '\'' ~ '\'' <single_str> }
    token literal:sym<dstr> { '"' ~ '"' <double_str> }
}

class Actions {
    method TOP($/) {
        my $ref = $<ref>.made;
        my $expr = ParsedExpr.new(
            var-name => $ref<var-name>,
            accessors => ($ref<accessors> // []).list
        );
        if $<comp_op> {
            $expr.is-comparison = True;
            $expr.op = $<comp_op>.Str;
            $expr.literal = $<literal>.made<value>;
            $expr.literal-type = $<literal>.made<type>;
        }
        make $expr;
    }

    method ref($/) {
        my @acc;
        for $<accessor> -> $a {
            @acc.push($a.made);
        }
        make %( var-name => $<variable>.Str, accessors => @acc );
    }

    method accessor:sym<helper_method>($/) {
        make MemberAccess.new(kind => 'helper_method', key => $<method>.Str);
    }

    method accessor:sym<what>($/) {
        make MemberAccess.new(kind => 'meta_what', key => 'WHAT');
    }

    method accessor:sym<dot>($/) {
        my Str $id = $<ident>.Str;
        my Str $tw = $<twigil> ?? $<twigil>.Str !! '';
        make MemberAccess.new(kind => 'attribute', key => $tw ~ $id);
    }

    method accessor:sym<angle>($/) {
        make MemberAccess.new(kind => 'associative', key => $<key>.Str.trim);
    }

    method accessor:sym<curly>($/) {
        if $<var_key> {
            make MemberAccess.new(kind => 'associative_var', key => $<var_key>.Str);
        } else {
            make MemberAccess.new(kind => 'associative', key => $<key>.Str);
        }
    }

    method accessor:sym<bracket>($/) {
        make MemberAccess.new(kind => 'positional', key => $<index>.Str);
    }

    method literal:sym<bool>($/) {
        make %( value => ($/.Str eq 'True'), type => 'Bool' );
    }

    method literal:sym<nil>($/) {
        make %( value => Nil, type => 'Nil' );
    }

    method literal:sym<num>($/) {
        make %( value => +$/.Str, type => 'Num' );
    }

    method literal:sym<int>($/) {
        make %( value => +$/.Str, type => 'Int' );
    }

    method literal:sym<sstr>($/) {
        make %( value => $<single_str>.Str, type => 'Str' );
    }

    method literal:sym<dstr>($/) {
        make %( value => $<double_str>.Str, type => 'Str' );
    }
}

method parse(Str $expression --> ParseResult) {
    my Str $trimmed = $expression.trim;

    if $trimmed eq "" {
        return ParseResult.new(
            success => False,
            error-message => "expression is outside the supported grammar"
        );
    }

    # 1. Refusal checks, all on the expression with its string literals masked, so that text inside a
    # literal ('=', '++', '<a b>', '.Str' …) never triggers a refusal (DK-17, B-5)
    my Str $masked = $trimmed.subst(/ '\'' [ '\\' . | <-[ ' \\ ]> ]* '\'' | '"' [ '\\' . | <-[ " \\ ]> ]* '"' /, { ' ' x $/.chars }, :g);

    # Reject multiple chained helper methods (DK-20)
    my @helper-calls = $masked.comb(/\. [@HELPER-METHODS] <!before <[\w\-]> >/);
    if @helper-calls.elems > 1 {
        return ParseResult.new(
            success => False,
            error-message => "multiple helper invocations in one expression not supported"
        );
    }

    # Reject multi-key associative slices (DK-17)
    if $masked ~~ /'<' \s* \S+ \s+ \S+ .*? '>'/ {
        return ParseResult.new(
            success => False,
            error-message => "associative slices are not supported"
        );
    }

    # Identity refusal: the adapter only holds copies of debuggee values, so === cannot be compared (B-6)
    if $masked.contains('===') {
        return ParseResult.new(
            success => False,
            error-message => "identity cannot be compared on values copied from the debuggee; use == or eq"
        );
    }

    # Container identity refusal: the adapter only holds copies of debuggee values, so =:= is meaningless
    if $masked.contains('=:=') {
        return ParseResult.new(
            success => False,
            error-message => "container identity cannot be compared on values copied from the debuggee"
        );
    }

    # Method call refusal (except whitelisted helper methods .gist, .Str, .raku, .elems with optional empty parens, and .WHAT)
    if $masked ~~ /(\.\w+ <[\w\-]>*) \s* '(' (.*?) ')'/ {
        my Str $raw-m = ($/[0] // '').Str;
        my Str $args = ($/[1] // '').Str.trim;
        my Str $m = $raw-m.subst(/^\./, '');
        if $args ne '' || !($m eq any(|@HELPER-METHODS, 'WHAT')) {
            return ParseResult.new(
                success => False,
                error-message => "calling code in the debuggee is not supported"
            );
        }
    }

    # Assignment and mutation refusal
    if $masked ~~ /'++' | '--'/
    || $masked ~~ /':='/
    || $masked ~~ /<!after '<' | '>' | '=' | ':' | '!'> '=' <!before '=' | ':'>/ {
        return ParseResult.new(
            success => False,
            error-message => "modifying debuggee state is not supported"
        );
    }

    # 2. Parse with grammar
    my $m = try Grammar.parse($trimmed, :actions(Actions.new));
    if $m && $m.made {
        return ParseResult.new(
            success => True,
            expr => $m.made
        );
    }

    return ParseResult.new(
        success => False,
        error-message => "expression is outside the supported grammar"
    );
}

#| Compare a value read from the debuggee with a literal. A comparison against `Nil` tests definedness:
#| $left is the value, undefined when the debuggee value is undefined (B-4).
method eval-comparison(Any $left, Str $op, Any $right, Str :$literal-type = '' --> Bool) {
    if $literal-type eq 'Nil' {
        my Bool $is-nil = !$left.defined;
        given $op {
            when '==' | 'eq' { return $is-nil }
            when '!=' | 'ne'         { return !$is-nil }
            default                  { return False }
        }
    }
    given $op {
        when '=='  { try { $left == $right } // False }
        when '!='  { try { $left != $right } // False }
        when '<'   { try { $left < $right } // False }
        when '<='  { try { $left <= $right } // False }
        when '>'   { try { $left > $right } // False }
        when '>='  { try { $left >= $right } // False }
        when 'eq'  { ($left // '').Str eq ($right // '').Str }
        when 'ne'  { ($left // '').Str ne ($right // '').Str }
        when 'lt'  { ($left // '').Str lt ($right // '').Str }
        when 'le'  { ($left // '').Str le ($right // '').Str }
        when 'gt'  { ($left // '').Str gt ($right // '').Str }
        when 'ge'  { ($left // '').Str ge ($right // '').Str }
        default    { False }
    }
}
