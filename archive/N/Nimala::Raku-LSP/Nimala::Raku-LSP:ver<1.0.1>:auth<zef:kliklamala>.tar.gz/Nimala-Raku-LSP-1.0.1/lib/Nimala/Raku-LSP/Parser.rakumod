unit module Nimala::Raku-LSP::Parser;

use Nimala::Raku-LSP::AST;
use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::URI;

#| An efficient, simplified Raku Grammar for LSP analysis.
#| Inspired by Rakudo's Raku::Grammar, it focuses on declarations and scopes.
grammar RakuGrammar {
    token TOP {
        <.ws> <top-statementlist>
    }

    rule top-statementlist {
        [ <statement> | '}' ]*:
    }

    token ws {
        <!ww> [
            \s+
            | '#' \N*
            | ^^ '=' 'begin' \h+ \w+ \N* [ \n <!before \h* '=end' > \N* ]* \n \h* '=end' \h+ \w+ \N*
            | ^^ '=' 'pod' \N* [ \n <!before \h* '=cut' > \N* ]* [ \n \h* '=cut' \N* ]?
            | ^^ '=' 'for' \h+ \w+ \N* [ \n \h* \N+ ]*
            | ^^ '=' <[a..zA..Z]> \w* \N*
        ]*
    }

    rule statementlist {
        <statement>*:
    }

    token trait {
        [ 'is' | 'does' ] \s+ <type> [ '(' <-[\)]>* ')' | <colonpair>+ ]?
    }

    rule trait-statement {
        $<also>='also'? [ $<is>='is' | $<does>='does' ] <type> [ '(' <-[\)]>* ')' | <colonpair>+ ]? ';'
    }

    rule statement {
        $<pkg>=<package-declaration>
        || $<enum>=<enum-declaration>
        || $<const>=<constant-declaration>
        || $<subset>=<subset-declaration>
        || $<rtn>=<routine-declaration>
        || $<var>=<variable-declaration>
        || $<trait>=<trait-statement>
        || $<expr>=<expression> ';'
        || $<com>=<comment>
        || $<block>=<generic-block>
        || $<any>=<any-character>
    }

    token any-character {
        | <regex-character-class>
        | <string>
        | '\\' .
        | <-[\s{}\\\"\']>+
        | \s+
    }

    rule generic-block {
        <!before ^^ \h* <statement-starter> >
        [ <regex-character-class> | <string> | '\\' . | <-[\s;{}\\\"\']>+ ]*: '{' $<stmt>=<statementlist> '}'?
    }

    token regex-character-class {
        '<' '-'? '[' [ '\\' . | <-[ \] \\ ]> ]* ']' '>'
    }

    token string {
        | '"'  [ '\\' . | <-[\"\\]> ]*: '"'
        | '\'' [ '\\' . | <-[\'\\]> ]*: '\''
        | '"'  [ '\\' . | <-[\"\n\\]> ]*:
        | '\'' [ '\\' . | <-[\'\n\\]> ]*:
    }

    token role-params {
        '[' [ <string> | <-[ \] ' " ]> ]* ']'
    }

    rule package-declaration {
        ['unit']? <package-declarator> <package-name> <role-params>? <colonpair>*
        [ <trait> ]*
        [
            '{' $<stmt>=<statementlist> '}'?
            | ';' $<stmt>=<statementlist>
        ]
    }

    token colonpair {
        ':' <[\w\-]>+ [ '<' <-[\>]>* '>' | '(' <-[\)]>* ')' | '[' <-[\]]>* ']' | '{' <-[\}]>* '}' ]?
    }

    token package-declarator {
        'class' | 'module' | 'role' | 'package' | 'grammar'
    }

    rule enum-declaration {
        'enum' <package-name> [ 'is' <identifier> ]*
        [
            | '(' $<enum_body_paren>=<enum-body-paren> ')'
            | '<' $<enum_body_words>=<enum-body-words> '>'
            | '<<' $<enum_body_words>=<enum-body-words> '>>'
        ]
        ';'?
    }

    token identifier-or-var {
        <variable> | <identifier>
    }

    token statement-starter {
        [ 'unit' \s+ ]? [ 'class' | 'role' | 'module' | 'grammar' | 'package' | 'sub' | 'method' | 'submethod' | 'rule' | 'token' | 'regex' | 'multi' | 'proto' | 'only' | 'macro' | 'my' | 'our' | 'has' | 'state' | 'constant' | 'subset' | 'enum' ] >>
    }

    rule constant-declaration {
        [ <scope-declarator> ]? <type>? 'constant' $<name>=<identifier-or-var>
        [ <trait> ]* [ '=' [ '{' $<stmt>=<statementlist> '}' | <expression> ] ]? ';'?
    }

    rule subset-declaration {
        [ <scope-declarator> ]? 'subset' <package-name> [ 'of' <type> ]?
        [ 'where' [ '{' $<stmt>=<statementlist> '}' | <expression> ] ]? ';'?
    }

    token enum-body-paren {
        # identifiers optionally with => and comma
        [ \s* <identifier> [ \s* '=>' <-[\,\)]>+ ]? \s* ','? ]*
    }

    token enum-body-words {
        [ \s* <identifier> ]* \s*
    }

    token package-name {
        <[\w\-]>+ [ '::' <[\w\-]>+ ]*
    }

    rule routine-declaration {
        <routine-declarator> <routine-name> <signature>?
        [ '-->' <return-type=type> | 'returns' <return-type=type> ]?
        [ <trait> ]*
        '{' $<stmt>=<statementlist> '}'?
    }

    token routine-declarator {
        | [ [ 'my' | 'our' | 'has' | 'state' ] \s+ ]?
        [ [ 'multi' | 'proto' | 'only' | 'macro' ] \s+ ]?
        [ 'sub' | 'method' | 'submethod' | 'rule' | 'token' | 'regex' ]
        | [ [ 'my' | 'our' | 'has' | 'state' ] \s+ ]?
        [ 'multi' | 'proto' | 'only' | 'macro' ]
    }

    token routine-name {
        <[\!\^]>? <[\w\-]>+
    }

    token signature-body {
        [
            | <string>
            | '(' <signature-body> ')'
            | <!before [ '-->' | 'returns' ] \s* <type> \s* ')' > <-[ ( ) ' " ]>
        ]*
    }

    token signature {
        '(' <signature-body> [ [ '-->' | 'returns' ] \s* <sig-return-type=type> ]? ')'
    }

    rule variable-declaration {
        <scope-declarator> <type>? <variable> [ <trait> ]*
        [ [ '=' | ':=' | '::=' | '.=' | '//=' ] [ '{' $<stmt>=<statementlist> '}' | <expression> ] ]? ';'?
    }

    token type {
        <[\w\-]>+ [ '::' <[\w\-]>+ ]* [ '[' \s* [ <type> | <-[ \] ]> ]+ \s* ']' ]? [ ':' <[a..zA..Z_]> <[\w\-]>* ]?
    }

    token scope-declarator {
        'my' | 'our' | 'has' | 'state'
    }

    token variable {
        <[\$\@\%\&]> <[\!\.]>? <[a..zA..Z_]> <[a..zA..Z0..9_\-]>*
    }

    token identifier {
        <[a..zA..Z_]> <[a..zA..Z0..9_\-]>*
    }

    rule expression {
        [
            <!before ^^ \h* <statement-starter> >
            [ <regex-character-class> | <string> | '\\' . | <variable> | <identifier> | <-[\s;{}\$a..zA..Z_\\'"]>+ ]
        ]+:
    }

    token comment {
        '#' \N*
    }
}

my constant %NON-INHERITANCE-TRAITS = Set.new(<export default pure rw readonly hidden-from-backtrace built nodups DEPRECATED>);

class RakuActions {
    has Document $.doc;

    method TOP(Match $/ --> Any) {
        make $<top-statementlist>.made;
    }

    method top-statementlist(Match $/ --> Any) {
        my Node @children;
        for $<statement> {
            @children.push($_.made) if $_.made;
        }
        make Node.new(
            type => 'StatementList',
            from => $/.from,
            to   => $/.to,
            children => @children
        );
    }

    method statementlist(Match $/ --> Any) {
        my Node @children;
        for $<statement> {
            @children.push($_.made) if $_.made;
        }
        make Node.new(
            type => 'StatementList',
            from => $/.from,
            to   => $/.to,
            children => @children
        );
    }

    method statement(Match $/ --> Any) {
        if $<pkg> { make $<pkg>.made; }
        elsif $<enum> { make $<enum>.made; }
        elsif $<const> { make $<const>.made; }
        elsif $<subset> { make $<subset>.made; }
        elsif $<rtn> { make $<rtn>.made; }
        elsif $<var> { make $<var>.made; }
        elsif $<trait> { make $<trait>.made; }
        elsif $<expr> { make $<expr>.made; }
        elsif $<block> { make $<block>.made; }
        else { make Nil; }
    }

    method trait-statement(Match $/ --> Any) {
        make Node.new(
            type => 'Trait',
            name => $<type>.Str,
            detail => ($<also> ?? 'also ' !! '') ~ ($<is> ?? 'is ' !! 'does ') ~ $<type>.Str,
            from => $/.from,
            to   => $/.to
        );
    }

    method constant-declaration(Match $/ --> Any) {
        my Str $type-str = $<type> ?? $<type>.Str !! "";
        make Node.new(
            type => 'constant',
            name => $<name>.Str.trim,
            detail => $type-str,
            from => $/.from,
            to   => $/.to,
            children => []
        );
    }

    method subset-declaration(Match $/ --> Any) {
        my Str $base-type = $<type> ?? $<type>.Str !! "";
        make Node.new(
            type => 'subset',
            name => $<package-name>.Str,
            detail => $base-type,
            from => $/.from,
            to   => $/.to,
            children => []
        );
    }

    method package-declaration(Match $/ --> Any) {
        my Str @supertypes;
        if $<trait> {
            for $<trait> -> $t {
                if $t<type> {
                    my Str $tname = $t<type>.Str;
                    @supertypes.push($tname) unless %NON-INHERITANCE-TRAITS{$tname};
                }
            }
        }
        if $<type> {
            for $<type> -> $t {
                my Str $tname = $t.Str;
                @supertypes.push($tname) unless %NON-INHERITANCE-TRAITS{$tname};
            }
        }
        my Node $node = Node.new(
            type => $<package-declarator>.Str,
            name => $<package-name>.Str,
            detail => $<package-declarator>.Str ~ " " ~ $<package-name>.Str,
            from => $/.from,
            to   => $/.to,
            supertypes => @supertypes
        );
        if $<stmt> {
            $node.children = $<stmt>.made.children;
            for $node.children -> $c {
                if $c.type eq 'Trait' {
                    @supertypes.push($c.name) unless %NON-INHERITANCE-TRAITS{$c.name};
                }
            }
            $node.supertypes = @supertypes;
        }
        make $node;
    }

    method enum-declaration(Match $/ --> Any) {
        my Node @children;
        if $<enum_body_paren> {
            for $<enum_body_paren>.<identifier> {
                @children.push: Node.new(
                    type => 'EnumMember',
                    name => $_.Str,
                    from => $_.from,
                    to   => $_.to
                );
            }
        }
        if $<enum_body_words> {
            for $<enum_body_words>.<identifier> {
                @children.push: Node.new(
                    type => 'EnumMember',
                    name => $_.Str,
                    from => $_.from,
                    to   => $_.to
                );
            }
        }
        make Node.new(
            type => 'enum',
            name => $<package-name>.Str,
            from => $/.from,
            to   => $/.to,
            children => @children
        );
    }

    method generic-block(Match $/ --> Any) {
        my Node $node = Node.new(
            type => 'Block',
            from => $/.from,
            to   => $/.to
        );
        if $<stmt> {
            $node.children = $<stmt>.made.children;
        }
        make $node;
    }

    method routine-declaration(Match $/ --> Any) {
        my Str $sig = $<signature> ?? $<signature>.Str !! "()";
        my Str $ret-type = "";
        if $<return-type> {
            $ret-type = $<return-type>.Str;
        } elsif $<signature> && $<signature><sig-return-type> {
            $ret-type = $<signature><sig-return-type>.Str;
        }
        if $ret-type && $sig !~~ /'-->'|'returns'/ {
            $sig ~= " --> " ~ $ret-type;
        }
        my Node $node = Node.new(
            type => $<routine-declarator>.Str.trim,
            name => $<routine-name>.Str,
            detail => $<routine-name>.Str ~ $sig,
            return_type => $ret-type,
            from => $/.from,
            to   => $/.to
        );
        my Node @kids;
        if $<stmt> {
            @kids.append($<stmt>.made.children);
        }
        if $<trait> {
            for $<trait> -> $t {
                if $t<type> {
                    @kids.push: Node.new(
                        type => 'Usage',
                        name => $t<type>.Str,
                        from => $t<type>.from,
                        to   => $t<type>.to
                    );
                }
            }
        }
        if $<signature> {
            my Str $sig-str = $<signature>.Str;
            my Int $offset = $<signature>.from;
            do {
                my $/;
                for $sig-str.match(/ [ ( <[A..Z]> <[a..zA..Z0..9_\-:]>* [ '[' \s* [ <[a..zA..Z0..9_\-:]> | <-[ \] ]> ]+ \s* ']' ]? [ ':' <[a..zA..Z_]> <[\w\-]>* ]? ) \s+ ]? ( <[\$\@\%\&]> <[\!\.]>? <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ) /, :g) -> $m {
                    my Str $type-str = $m[0] ?? ~$m[0] !! "";
                    my Str $var-name = ~$m[1];
                    my Int $w-from = $offset + $m[1].from;
                    my Int $w-to = $offset + $m[1].to;
                    @kids.push: Node.new(
                        type => 'Parameter',
                        name => $var-name,
                        detail => $type-str,
                        from => $w-from,
                        to   => $w-to
                    );
                }
            }
        }
        $node.children = @kids;
        make $node;
    }

    method variable-declaration(Match $/ --> Any) {
        my Str $type-str = $<type> ?? $<type>.Str !! "";
        if !$type-str && $<expression> {
            my Str $expr = $<expression>.Str.trim;
            if my Match $m = $expr ~~ / ^ ( <[A..Z]> <[a..zA..Z0..9_\-:]>* ) \. new / {
                $type-str = $m[0].Str;
            }
        }
        my Str $node-type = ($<scope-declarator> && $<scope-declarator>.Str eq 'has') ?? 'Field' !! 'Variable';
        my Node $node = Node.new(
            type => $node-type,
            name => $<variable> ?? $<variable>.Str !! "",
            detail => $type-str,
            from => $/.from,
            to   => $/.to,
            children => []
        );
        if $<type> {
            $node.children.push: Node.new(
                type => 'Usage',
                name => $<type>.Str,
                from => $<type>.from,
                to   => $<type>.to
            );
        }
        if $<expression> && $<expression>.made {
            $node.children.push($<expression>.made);
        }
        make $node;
    }

    method expression(Match $/ --> Any) {
        my Node $node = Node.new(type => 'Expression', from => $/.from, to => $/.to);
        my Node @usages;
        for $<variable> {
            @usages.push: Node.new(
                type => 'Usage',
                name => $_.Str,
                from => $_.from,
                to   => $_.to
            );
        }
        for $<identifier> {
            @usages.push: Node.new(
                type => 'Usage',
                name => $_.Str,
                from => $_.from,
                to   => $_.to
            );
        }
        if @usages {
            $node.children = @usages;
            make $node;
        } else {
            make Nil;
        }
    }

    method comment(Match $/ --> Any) {
        make Nil;
    }
}

sub parse-document(Document $doc --> Node) is export {
    return $doc.protect-parse({
            if $doc.ast-version == $doc.version && $doc.ast.defined {
                return $doc.ast;
            }

            my RakuActions $actions = RakuActions.new(:$doc);
            my Any $match = RakuGrammar.subparse($doc.text, :$actions);
            my Node $ast;
            if $match {
                $ast = $match.made;
            } else {
                $ast = Node.new(type => 'Error', from => 0, to => 0);
            }

            sub attach-doc(Node $n) {
                return unless $n.defined;
                $n.doc = $doc;
                for $n.children {
                    attach-doc($_) if $_.defined;
                }
            }
            attach-doc($ast) if $ast.defined;

            $doc.ast = $ast;
            # Note: symbols cache is handled in Analysis/Symbols.rakumod
            # We clear the symbols if we parsed a new AST
            $doc.symbols = Array;
            $doc.ast-version = $doc.version;

            return $ast;
    });
}

#| Path spec (e.g. `file#/…/lib`, `inst#/…`) of the repository providing the worker module, or Str if none.
#| `.candidates` is used because `.resolve` on a `file#` repository falls through to the rest of the chain.
our sub native-worker-repo-spec(--> Str) is export {
    state Str $spec;
    return $spec if $spec.defined;
    my CompUnit::DependencySpecification $ds .= new(:short-name<Nimala::Raku-LSP::NativeWorker>);
    my CompUnit::Repository $repo = $*REPO.repo-chain.first({ (try .candidates($ds)).so });
    $spec = $repo.path-spec if $repo.defined;
    return $spec;
}

our sub resolve-doc-include-paths(Document $doc --> Array) is export {
    my @inc;
    if $doc.uri && $doc.uri.starts-with("file://") {
        my IO::Path $file-path = uri-to-path($doc.uri);
        try {
            my IO::Path $cur = $file-path.parent;
            while $cur.defined && $cur.e && $cur.Str ne "." && $cur.Str ne "/" && $cur.parent.Str ne $cur.Str {
                my $has-meta = try { $cur.add("META6.json").e } // False;
                my $has-git  = try { $cur.add(".git").e } // False;
                my $lib-dir  = $cur.add("lib");
                my $has-lib  = try { $lib-dir.e && $lib-dir.d } // False;
                if $has-meta || $has-git || $has-lib {
                    @inc.push($lib-dir.absolute) if $has-lib;
                    @inc.push($cur.absolute);
                    last;
                }
                my $parent = $cur.parent;
                last if !$parent.defined || $parent.Str eq $cur.Str || $parent.Str eq "/";
                $cur = $parent;
            }
            CATCH { default { } }
        }
    }
    return @inc;
}

#| True when every requested extraction (symbols/tokens) failed; partial results stay usable.
our sub native-extraction-failed(@requested, %res --> Bool) is export {
    return so @requested && @requested.map({ %res{"{$_}_failed"} // False }).all;
}

#| Spawns the worker for @to-extract and returns its parsed result; `worker_failed` marks a run without
#| usable output (timeout, crash, unparseable JSON). Runs without holding any lock.
sub spawn-native-worker(Document $doc, @to-extract, Str $repo-spec, Numeric $timeout --> Hash) {
    my @inc-args = resolve-doc-include-paths($doc).map({ "-I$_" });

    require JSON::Fast;
    # Own repository first, so a workspace module of the same name cannot shadow the worker
    my @cmd = [$*EXECUTABLE.absolute, "-I$repo-spec", |@inc-args,
        '-MNimala::Raku-LSP::NativeWorker', '-e', 'Nimala::Raku-LSP::NativeWorker::main()'];
    my $proc = Proc::Async.new(|@cmd, :w);
    my Str $stdout = "";
    my Str $stderr = "";
    $proc.stdout.tap(-> $v { $stdout ~= $v });
    $proc.stderr.tap(-> $v { $stderr ~= $v });

    my Numeric $sec = ($timeout.defined && $timeout > 0)
    ?? $timeout
    !! (%*ENV<NIMALA_WORKER_TIMEOUT> // 10.0).Numeric;
    my $timeout-p = Promise.in($sec);
    my $proc-p = $proc.start;

    my $payload = JSON::Fast::to-json({
            code => $doc.text,
            extract => @to-extract.Array
    });

    # Await the write (bounded by the timeout): closing stdin first can drop the input under load
    try await Promise.anyof($proc.write($payload.encode), $timeout-p);
    $proc.close-stdin;

    my Bool $timed-out = False;
    try {
        await Promise.anyof($proc-p, $timeout-p);
        if $timeout-p.status == Kept && $proc-p.status != Kept {
            $timed-out = True;
            $proc.kill(SIGKILL);
        }
        CATCH { default { } }
    }
    return hash(worker_failed => True) if $timed-out;

    try {
        await $proc-p;
        CATCH { default { } }
    }

    my Any $res-raw = try { JSON::Fast::from-json($stdout.trim) };
    if !$res-raw.defined && $stdout.defined && $stdout ~~ / '{' [\s | \S]* '}' / {
        $res-raw = try { JSON::Fast::from-json($/.Str) };
    }
    return hash(worker_failed => True) unless $res-raw.defined && $res-raw ~~ Associative;
    return %$res-raw;
}

our sub run-native-worker(
    Document $doc,
    :@extract = ['symbols', 'tokens'],
    Numeric :$timeout = (%*ENV<NIMALA_WORKER_TIMEOUT> // 10.0).Numeric
    --> Hash
) is export {
    if $doc.is-native-failed {
        return hash(symbols => [], tokens => []);
    }

    my Int $ver = $doc.version;
    my Bool $need-syms = ('symbols' (elem) @extract).so;
    my Bool $need-toks = ('tokens' (elem) @extract).so;

    # Lock → await outside the lock → lock. The parse lock is never held while the worker runs,
    # and callers for the same snapshot share one in-flight run (joining at most once).
    for ^2 -> $attempt {
        my Promise $run;
        my Bool $mine = False;
        my @run-extract;
        my $early = $doc.protect-parse({
                if $doc.is-native-failed {
                    hash(symbols => [], tokens => []);
                } else {
                    my Bool $has-syms = $doc.native-symbols.defined && $doc.native-symbols-version == $ver;
                    my Bool $has-toks = $doc.raw-tokens.defined && $doc.raw-tokens-version == $ver;

                    if ($need-syms && $has-syms) && ($need-toks && $has-toks) {
                        hash(symbols => @($doc.native-symbols), tokens => @($doc.raw-tokens));
                    } elsif $need-syms && $has-syms && !$need-toks {
                        hash(symbols => @($doc.native-symbols), tokens => []);
                    } elsif $need-toks && $has-toks && !$need-syms {
                        hash(symbols => [], tokens => @($doc.raw-tokens));
                    } elsif $doc.native-run-pending {
                        $run = $doc.native-run;
                        Nil;
                    } elsif $attempt > 0 && !(($need-syms && !$has-syms) || ($need-toks && !$has-toks)) {
                        # Joined a run that covered this request: answer from the caches
                        hash(
                            symbols => ($need-syms ?? @($doc.native-symbols // []) !! []),
                            tokens  => ($need-toks ?? @($doc.raw-tokens // []) !! [])
                        );
                    } else {
                        my @to-extract = ['symbols', 'tokens'];

                        my Str $repo-spec = native-worker-repo-spec();
                        if $repo-spec.defined {
                            $run = start { spawn-native-worker($doc, @to-extract, $repo-spec, $timeout) };
                            $doc.set-native-run($run);
                            $mine = True;
                            @run-extract = @to-extract;
                            Nil;
                        } else {
                            $doc.mark-native-failed;
                            hash(symbols => [], tokens => []);
                        }
                    }
                }
        });
        return $early if $early ~~ Hash;

        my %res = (try await $run) // hash(worker_failed => True);
        next unless $mine;

        return $doc.protect-parse({
                LEAVE $doc.clear-native-run;
                if %res<worker_failed> || native-extraction-failed(@run-extract, %res) {
                    $doc.mark-native-failed;
                }
                if !%res<worker_failed> {
                    if %res<symbols>.defined && !%res<symbols_failed> {
                        $doc.native-symbols = @(%res<symbols>).Array;
                        $doc.native-symbols-version = $ver;
                    }
                    if %res<tokens>.defined && !%res<tokens_failed> {
                        $doc.raw-tokens = @(%res<tokens>).Array;
                        $doc.raw-tokens-version = $ver;
                    }
                }
                hash(
                    symbols => ($need-syms ?? @($doc.native-symbols // []) !! []),
                    tokens  => ($need-toks ?? @($doc.raw-tokens // []) !! [])
                );
        });
    }
    return hash(
        symbols => ($need-syms ?? @($doc.native-symbols // []) !! []),
        tokens  => ($need-toks ?? @($doc.raw-tokens // []) !! [])
    );
}
