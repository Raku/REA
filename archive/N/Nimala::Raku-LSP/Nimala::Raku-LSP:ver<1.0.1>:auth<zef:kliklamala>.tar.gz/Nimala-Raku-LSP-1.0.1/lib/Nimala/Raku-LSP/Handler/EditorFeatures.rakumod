use v6.d;
#| Role handling editor features:
#| inlineValue, linkedEditingRange, inlayHint,
#| foldingRange and selectionRange.
unit role Nimala::Raku-LSP::Handler::EditorFeatures;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::CoreDocs;
use Nimala::Raku-LSP::URI;

my constant $INLAY-HINT-TYPE = 1;
my constant $INLAY-HINT-PARAMETER = 2;

#| Handle textDocument/inlineValue request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineValue>
method textDocument-inlineValue(:%textDocument, :%range, :%context?, :$_id, :$_token, *%other --> Array) {
    my $token = $_token // ($_id.defined ?? self.get-request-token($_id) !! (%other<id>:exists ?? self.get-request-token(%other<id>) !! CancellationToken));
    if $token && $token.is-cancelled {
        return [].Array;
    }
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Int $start-line = (%range<start><line> // 0).Int;
    my Int $end-line = (%range<end><line> // 0).Int;

    my @inline-values;
    my $text = $doc.text;
    my %seen-ranges;

    # Cached Tier 2 native symbols (only if current; never starts the native worker), then a line scanner
    require Nimala::Raku-LSP::Analysis::Symbols;
    my @syms = ($doc.native-symbols.defined && $doc.native-symbols-version == $doc.version)
    ?? Nimala::Raku-LSP::Analysis::Symbols::flatten-native-tree(@($doc.native-symbols))
    !! [];
    for @syms -> $s {
        next unless $s<from>.defined && $s<to>.defined;
        my $pos-start = $doc.position-at($s<from>);
        my $pos-end = $doc.position-at($s<to>);
        next if $pos-end<line> < $start-line || $pos-start<line> > $end-line;
        next unless $pos-start<line> >= $start-line && $pos-end<line> <= $end-line;

        if $s<kind> eq 'variable_decl' || $s<kind> eq 'variable_usage' {
            my $name = $s<name> // "";
            next unless $name;
            my $range-key = "$pos-start<line>:$pos-start<character>-$pos-end<line>:$pos-end<character>";
            next if %seen-ranges{$range-key};
            %seen-ranges{$range-key} = True;

            if $name ~~ /^ <[\$\@\%\&]> <[\.\!]> / {
                @inline-values.push: {
                    range => {
                        start => { line => $pos-start<line>, character => $pos-start<character> },
                        end   => { line => $pos-end<line>,   character => $pos-end<character> }
                    },
                    expression => $name
                };
            } else {
                @inline-values.push: {
                    range => {
                        start => { line => $pos-start<line>, character => $pos-start<character> },
                        end   => { line => $pos-end<line>,   character => $pos-end<character> }
                    },
                    variableName => $name,
                    caseSensitiveLookup => True
                };
            }
        }
    }

    for $start-line .. min($end-line, $doc.lines-count - 1) -> $line-idx {
        my $line-str = $doc.line-text($line-idx);
        # Attributes in line (e.g. inside strings or expressions)
        for $line-str.match(/ (<[\$\@\%\&]> <[\.\!]> <[\w\-]>+) /, :g) -> $m {
            my $v-start = $doc.utf16-column($line-idx, $m.from);
            my $v-end = $doc.utf16-column($line-idx, $m.to);
            my $range-key = "$line-idx:$v-start-$line-idx:$v-end";
            unless %seen-ranges{$range-key} {
                %seen-ranges{$range-key} = True;
                @inline-values.push: {
                    range => {
                        start => { line => $line-idx, character => $v-start },
                        end   => { line => $line-idx, character => $v-end }
                    },
                    expression => $m.Str
                };
            }
        }
        # Simple variables in line (e.g. inside strings or expressions)
        for $line-str.match(/ (<[\$\@\%\&]> <[\w\-]>+) /, :g) -> $m {
            my $v-start = $doc.utf16-column($line-idx, $m.from);
            my $v-end = $doc.utf16-column($line-idx, $m.to);
            my $range-key = "$line-idx:$v-start-$line-idx:$v-end";
            unless %seen-ranges{$range-key} {
                %seen-ranges{$range-key} = True;
                @inline-values.push: {
                    range => {
                        start => { line => $line-idx, character => $v-start },
                        end   => { line => $line-idx, character => $v-end }
                    },
                    variableName => $m.Str,
                    caseSensitiveLookup => True
                };
            }
        }
        # Parameterless method calls (e.g. self.is-active, $obj.status, $a.b.c)
        for $line-str.match(/ (<[\$\@\%\&]> \w+ | 'self') [ \. <[\w\-]>+ ]+ <?before [ \s | ';' | ')' | '}' | ',' | $ ]> /, :g) -> $m {
            my $v-start = $doc.utf16-column($line-idx, $m.from);
            my $v-end = $doc.utf16-column($line-idx, $m.to);
            my $range-key = "$line-idx:$v-start-$line-idx:$v-end";
            unless %seen-ranges{$range-key} {
                %seen-ranges{$range-key} = True;
                @inline-values.push: {
                    range => {
                        start => { line => $line-idx, character => $v-start },
                        end   => { line => $line-idx, character => $v-end }
                    },
                    expression => $m.Str
                };
            }
        }
    }

    return @inline-values.map({ %$_ }).Array;
}

#| Implementation of 'textDocument/linkedEditingRange'
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_linkedEditingRange>
method textDocument-linkedEditingRange(:%textDocument, :%position, :$_id, :$_token, *%other --> Any) {
    my $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return Nil unless $doc;

    my Int $line = (%position<line> // 0).Int;
    my Int $char = (%position<character> // 0).Int;
    my Int $line-count = $doc.lines-count;
    return Nil if $line >= $line-count;
    my $curr-line = $doc.line-text($line);
    my Int $char-idx = max(0, $doc.position-to-offset($line, $char) - $doc.line-offsets[$line]);
    return Nil if $char-idx > $curr-line.chars;

    # --- 1. Pod6 Blocks (=begin <name> ... =end <name>) with Hybrid Repair ---
    {
        my @stack;
        my @pod-pairs;
        for 0 .. $line-count - 1 -> $idx {
            my $l = $doc.line-text($idx);
            if $l ~~ / '=begin' \s+ (<[\w-]>+) / {
                @stack.push({
                        line  => $idx,
                        start => $doc.utf16-column($idx, $/[0].from),
                        end   => $doc.utf16-column($idx, $/[0].to),
                        name  => $/[0].Str
                });
            } elsif $l ~~ / '=end' [ \s+ (<[\w-]>+) ]? / {
                if @stack.elems > 0 {
                    my $top = @stack.pop();
                    my Int $end-start = $/[0] ?? $doc.utf16-column($idx, $/[0].from) !! -1;
                    my Int $end-to    = $/[0] ?? $doc.utf16-column($idx, $/[0].to) !! -1;
                    my Str $end-name  = $/[0] ?? $/[0].Str !! "";
                    @pod-pairs.push({
                            begin => $top,
                            end   => {
                                line  => $idx,
                                start => $end-start,
                                end   => $end-to,
                                name  => $end-name
                            }
                    });
                }
            }
        }

        for @pod-pairs -> $p {
            my $b = $p<begin>;
            my $e = $p<end>;
            next if $e<start> < 0; # skip unnamed =end

            my Bool $in-begin = ($line == $b<line> && $char >= $b<start> && $char <= $b<end>);
            my Bool $in-end   = ($line == $e<line> && $char >= $e<start> && $char <= $e<end>);

            if $in-begin || $in-end {
                return {
                    ranges => [
                        {
                            start => { line => $b<line>, character => $b<start> },
                            end   => { line => $b<line>, character => $b<end> }
                        },
                        {
                            start => { line => $e<line>, character => $e<start> },
                            end   => { line => $e<line>, character => $e<end> }
                        }
                    ],
                    wordPattern => '[a-zA-Z0-9_\\-]+'
                };
            }
        }
    }

    # --- 2. Here-Docs (q:to/.../ ... TERMINATOR) ---
    {
        my @heredoc-pairs;
        for 0 .. $line-count - 1 -> $idx {
            my $l = $doc.line-text($idx);
            # Match q:to/DELIM/, qq:to/DELIM/, Q:to/DELIM/, q:to"DELIM", q:to'DELIM', q:to[DELIM], etc.
            if $l ~~ / [ 'q' | 'qq' | 'Q' | 'Q:c' | 'Q:b' | 'q:c' ]? ':to' \s* ( '/' | '"' | '\'' | '<' | '(' | '[' | '{' ) \s* ( <[\w-]>+ ) \s* ( '/' | '"' | '\'' | '>' | ')' | ']' | '}' ) / {
                my $delim = $/[1].Str;
                my $open-start = $doc.utf16-column($idx, $/[1].from);
                my $open-end = $doc.utf16-column($idx, $/[1].to);

                # Look ahead for terminator line: ^ \s* DELIM \s* ;? \s* $
                for ($idx + 1) .. ($line-count - 1) -> $t-idx {
                    my $tl = $doc.line-text($t-idx);
                    if $tl ~~ /^ \s* ($delim) [ \s* ';' ]? \s* $/ {
                        @heredoc-pairs.push({
                                open => { line => $idx, start => $open-start, end => $open-end, name => $delim },
                                term => { line => $t-idx, start => $doc.utf16-column($t-idx, $/[0].from), end => $doc.utf16-column($t-idx, $/[0].to), name => $delim }
                        });
                        last;
                    }
                }
            }
        }

        for @heredoc-pairs -> $p {
            my $o = $p<open>;
            my $t = $p<term>;
            my Bool $in-open = ($line == $o<line> && $char >= $o<start> && $char <= $o<end>);
            my Bool $in-term = ($line == $t<line> && $char >= $t<start> && $char <= $t<end>);

            if $in-open || $in-term {
                return {
                    ranges => [
                        {
                            start => { line => $o<line>, character => $o<start> },
                            end   => { line => $o<line>, character => $o<end> }
                        },
                        {
                            start => { line => $t<line>, character => $t<start> },
                            end   => { line => $t<line>, character => $t<end> }
                        }
                    ],
                    wordPattern => '[a-zA-Z0-9_\\-]+'
                };
            }
        }
    }

    # --- 3. Loop Labels (LABEL: ... last/next/redo/goto LABEL) ---
    {
        for 0 .. $line-count - 1 -> $idx {
            my $l = $doc.line-text($idx);
            if $l ~~ /^ \s* (<[\w-]>+) \s* ':' <!before ':'> \s* [ 'for' | 'while' | 'until' | 'loop' | 'given' | '{' | $ ] / || $l ~~ /^ \s* (<[A..Z0..9_]>+) \s* ':' <!before ':'>/ {
                my $lbl = $/[0].Str;
                my $lbl-start = $doc.utf16-column($idx, $/[0].from);
                my $lbl-end   = $doc.utf16-column($idx, $/[0].to);

                # Track brace scope to find end of loop block
                my Int $brace-depth = 0;
                my Bool $seen-open = False;
                my Int $end-idx = min($idx + 100, $line-count - 1);

                for $idx .. ($line-count - 1) -> $s-idx {
                    my $sl = $doc.line-text($s-idx);
                    for $sl.comb -> $c {
                        if $c eq '{' { $brace-depth++; $seen-open = True; }
                        elsif $c eq '}' { $brace-depth--; }
                    }
                    if $seen-open && $brace-depth <= 0 {
                        $end-idx = $s-idx;
                        last;
                    }
                }

                my @label-ranges;
                @label-ranges.push({
                        start => { line => $idx, character => $lbl-start },
                        end   => { line => $idx, character => $lbl-end }
                });

                for $idx .. $end-idx -> $s-idx {
                    my $sl = $doc.line-text($s-idx);
                    for $sl.match(/ <?after [ 'last' | 'next' | 'redo' | 'goto' ] \s+> ($lbl) >> /, :g) -> $m {
                        @label-ranges.push({
                                start => { line => $s-idx, character => $doc.utf16-column($s-idx, $m.from) },
                                end   => { line => $s-idx, character => $doc.utf16-column($s-idx, $m.to) }
                        });
                    }
                }

                # Check if cursor is in any of these label ranges
                if @label-ranges.elems >= 2 {
                    for @label-ranges -> $r {
                        if $line == $r<start><line> && $char >= $r<start><character> && $char <= $r<end><character> {
                            return {
                                ranges      => @label-ranges,
                                wordPattern => '[a-zA-Z0-9_\\-]+'
                            };
                        }
                    }
                }
            }
        }
    }

    return Nil;
}

#| Handle textDocument/inlayHint request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlayHint>
method textDocument-inlayHint(:%textDocument, :%range, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my @hints;
    my @symbols = extract-symbols($doc);

    my Int $range-start = %range.defined && %range<start>.defined && %range<start><line>.defined
    ?? %range<start><line>.Int !! 0;
    my Int $range-end = %range.defined && %range<end>.defined && %range<end><line>.defined
    ?? %range<end><line>.Int !! ($doc.lines-count - 1);

    sub gather-hints(@list) {
        for @list -> $s {
            if $s<kind> == 13 { # Variable
                # Skip routine parameters for variable-declaration type hints
                if $s<is_param> || ($s<extra> && $s<extra><is_param>) {
                    next;
                }
                my $line = $s<range><start><line>;
                if $line < $range-start || $line > $range-end {
                    gather-hints($s<children>) if $s<children>;
                    next;
                }
                # Skip if variable already has an explicit type (detail)
                my $detail = $s<detail>;
                my $explicit-type = $detail ~~ Str ?? $detail !! "";
                if $explicit-type {
                    my $clean-type = $explicit-type.subst(/ \s* '(' <[a..zA..Z]>+ ')' $ /, '');
                    if $clean-type.trim ne "" {
                        next;
                    }
                }

                my $start-char = $s<range><start><character>;

                my $type = "Any";
                my Hash $pos = hash(
                    line => $s<range><end><line>.Int,
                    character => $s<range><end><character>.Int
                );

                if $line < $doc.lines-count {
                    my $line-text = $doc.line-text($line);
                    my $var-name = $s<name>;

                    # Find where the variable name ends in this line
                    my $g-idx = $line-text.index($var-name);
                    if $g-idx.defined {
                        my Int $end-grapheme = $g-idx + $var-name.chars;
                        my Int $char = $doc.utf16-column($line, $end-grapheme);
                        $pos = hash(line => $line.Int, character => $char.Int);

                        my $rest = $line-text.substr($end-grapheme);
                        if $rest ~~ / ^ \s* '=' \s* $<val>=( \d+ [ \. \d+ ]? | \" <-["]>* \" | \' <-[']>* \' ) \s* [ ';' | $ ] / {
                            my $val = $<val>.Str;
                            if $val ~~ /^ \d+ $/ {
                                $type = "Int";
                            } elsif $val.starts-with('"') || $val.starts-with("'") {
                                $type = "Str";
                            }
                        }
                        # Check for function calls e.g., my $a = func()
                        elsif $rest ~~ / ^ \s* '=' \s* $<func>=( <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ) \s* '(' / {
                            my $func-name = $<func>.Str;
                            my $target = @symbols.first({ ($_<name> // '') eq $func-name && (($_<kind> // 0) == 6 || ($_<kind> // 0) == 12) });
                            if !$target {
                                my @globals = self.index.find-symbol($func-name);
                                $target = @globals.first({ ($_<kind> // 0) == 6 || ($_<kind> // 0) == 12 });
                            }
                            if $target && $target<detail> {
                                if $target<detail> ~~ / '-->' \s* (<[a..zA..Z_]> <[a..zA..Z0..9_\-]>*) / {
                                    $type = $0.Str;
                                } elsif $target<detail> ~~ / 'returns' \s+ (<[a..zA..Z_]> <[a..zA..Z0..9_\-]>*) / {
                                    $type = $0.Str;
                                }
                            }
                        }
                    }
                }

                @hints.push: hash(
                    position => $pos,
                    label => ": $type",
                    kind => $INLAY-HINT-TYPE,
                    paddingLeft => True,
                    paddingRight => False
                );
            }
            gather-hints($s<children>) if $s<children>;
        }
    }
    gather-hints(@symbols);

    # Let's also find function calls in the requested range to provide parameter hints
    my $start-line = %range<start><line>;
    my $end-line = %range<end><line>;
    for $start-line .. min($end-line, $doc.lines-count - 1) -> $line-idx {
        my $line-text = $doc.line-text($line-idx);

        # Skip declaration lines to avoid false parameter hints
        if $line-text ~~ / ^ \s* ( 'sub' | 'method' | 'multi' | 'rule' | 'token' | 'macro' ) \s+ / {
            next;
        }

        # Basic regex to find func(arg1, arg2)
        # Note: robust parsing is better, but this handles basic cases for hints
        for $line-text.match(/ (<[a..zA..Z_]> <[a..zA..Z0..9_\-]>*) \s* '(' \s* (<-[)]>*) ')' /, :g) -> $m {
            my $func-name = $m[0].Str;
            my $args-str = $m[1].Str;
            next unless $args-str.trim;

            # Find the signature
            my $target = @symbols.first({ ($_<name> // '') eq $func-name && (($_<kind> // 0) == 6 || ($_<kind> // 0) == 12) });
            if !$target {
                my @globals = self.index.find-symbol($func-name);
                $target = @globals.first({ ($_<kind> // 0) == 6 || ($_<kind> // 0) == 12 });
            }
            if $target && $target<detail> {
                # Detail usually looks like: `sub myfunc($a, $b) { ... }` or `myfunc($a, Int $b)`
                my @param-names;
                if $target<detail> ~~ / '(' (.*?) ')' / {
                    my $sig-args = $0.Str;
                    $sig-args ~~ s/ \s* [ '-->' | 'returns' ] \s* \S+ //;
                    if $sig-args.trim ne "" {
                        for $sig-args.split(',') -> $p {
                            my $p-trim = $p.trim;
                            next if $p-trim eq "";
                            if $p-trim ~~ / (<[\$\@\%\&]> <[a..zA..Z_]> <[a..zA..Z0..9_\-]>*) / {
                                my $p-name = $0.Str;
                                $p-name ~~ s/^<[\$\@\%\&]>//; # remove sigil
                                @param-names.push($p-name);
                            }
                        }
                    }
                }

                if @param-names {
                    my $current-char = $m[1].from;
                    # Simple split by comma, ignoring nested parens/strings (best effort for now)
                    my @args = $args-str.split(',');

                    for 0..^@args.elems -> $i {
                        my $arg = @args[$i];
                        my $arg-trim = $arg.trim;
                        if $i < @param-names.elems && $arg-trim ne '' {
                            # Position is right before the argument starts
                            my $arg-start-grapheme = $current-char + $arg.index($arg-trim);
                            my Int $arg-u16 = $doc.utf16-column($line-idx, $arg-start-grapheme);
                            @hints.push: hash(
                                position => hash(line => $line-idx.Int, character => $arg-u16.Int),
                                label => @param-names[$i] ~ ":",
                                kind => $INLAY-HINT-PARAMETER,
                                paddingLeft => False,
                                paddingRight => True
                            );
                        }
                        $current-char += $arg.chars + 1; # +1 for comma
                    }
                }
            }
        }
    }

    return @hints.Array;
}

#| Handle inlayHint/resolve request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#inlayHint_resolve>
method inlayHint-resolve(:$_id, :$_token, *%hint --> Hash) {
    %hint<_token>:delete;
    %hint<_id>:delete;
    if !%hint<tooltip> {
        my Str $label = (%hint<label> // "").Str;
        if $label {
            # Type hint (e.g. ": Int" or ": Str")
            if $label ~~ /^ ':' \s* (<[a..zA..Z_]> <[a..zA..Z0..9_\:]>*) $/ {
                my Str $type-name = $0.Str;
                my $doc = Nimala::Raku-LSP::CoreDocs::get-doc-type($type-name);
                if $doc {
                    %hint<tooltip> = { kind => "markdown", value => "### Type `$type-name`\n\n$doc" };
                } else {
                    my @syms = self.index.find-symbol($type-name);
                    if @syms {
                        my $sym = @syms[0];
                        my $detail = $sym<detail> // "type $type-name";
                        %hint<tooltip> = { kind => "markdown", value => "```raku\n$detail\n```" };
                    } else {
                        %hint<tooltip> = { kind => "markdown", value => "Inferred type `$type-name`" };
                    }
                }
            }
            # Parameter hint (e.g. "param:")
            elsif $label ~~ /^ (<[a..zA..Z_]> <[a..zA..Z0..9_\-]>*) ':' $/ {
                my Str $param-name = $0.Str;
                %hint<tooltip> = { kind => "markdown", value => "Parameter `$param-name`" };
            }
            else {
                %hint<tooltip> = { kind => "markdown", value => "Inlay hint `$label`" };
            }
        }
    }
    return %hint;
}

#| Handle textDocument/foldingRange request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_foldingRange>
method textDocument-foldingRange(:%textDocument, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my @folds;

    # 1. Symbol-based code block folding (omit kind per LSP standard)
    my @syms = extract-symbols($doc);
    sub add-folds(@list) {
        for @list -> $s {
            my Int $start-line = $s<range><start><line>;
            my Int $raw-end-line = $s<range><end><line>;
            my Int $end-char = $s<range><end><character> // 0;
            my Int $end-line = ($end-char == 0 && $raw-end-line > $start-line)
            ?? $raw-end-line - 1
            !! $raw-end-line;
            if $start-line < $end-line {
                @folds.push: hash(
                    startLine => $start-line,
                    endLine   => $end-line
                );
            }
            add-folds($s<children>) if $s<children>;
        }
    }
    add-folds(@syms);

    # 2. Pod documentation and comment blocks (kind => "comment")
    my Int $line-count = $doc.lines-count;
    my Int $pod-start = -1;
    my Str $pod-type = "";
    my Int $comment-start = -1;
    my Int $import-start = -1;

    for 0 ..^ $line-count -> Int $i {
        my Str $l = $doc.line-text($i);
        my Str $trim = $l.trim;

        # Pod block tracking
        if $pod-start >= 0 {
            if $trim ~~ /^ '=end' \s+ $pod-type / {
                @folds.push: {
                    startLine => +$pod-start,
                    endLine   => +$i,
                    kind      => "comment"
                };
                $pod-start = -1;
                $pod-type = "";
            }
        } elsif $trim ~~ /^ '=begin' \s+ (\w+) / {
            $pod-start = $i;
            $pod-type = ~$0;
        }

        # Contiguous imports (use / need)
        if $trim ~~ /^ ( 'use' | 'need' ) \s+/ {
            $import-start = $i if $import-start < 0;
        } else {
            if $import-start >= 0 && $i - 1 > $import-start {
                @folds.push: {
                    startLine => +$import-start,
                    endLine   => +($i - 1),
                    kind      => "imports"
                };
            }
            $import-start = -1;
        }

        # Contiguous comment lines
        if $trim ~~ /^ '#' / {
            $comment-start = $i if $comment-start < 0;
        } else {
            if $comment-start >= 0 && $i - 1 > $comment-start {
                @folds.push: {
                    startLine => +$comment-start,
                    endLine   => +($i - 1),
                    kind      => "comment"
                };
            }
            $comment-start = -1;
        }
    }

    # Flush trailing blocks
    if $pod-start >= 0 && $line-count - 1 > $pod-start {
        @folds.push: {
            startLine => +$pod-start,
            endLine   => +($line-count - 1),
            kind      => "comment"
        };
    }
    if $import-start >= 0 && $line-count - 1 > $import-start {
        @folds.push: {
            startLine => +$import-start,
            endLine   => +($line-count - 1),
            kind      => "imports"
        };
    }
    if $comment-start >= 0 && $line-count - 1 > $comment-start {
        @folds.push: {
            startLine => +$comment-start,
            endLine   => +($line-count - 1),
            kind      => "comment"
        };
    }

    return @folds.unique(as => { .<startLine> ~ '-' ~ .<endLine> }).map({ %$_ }).Array;
}

#| Handle textDocument/selectionRange request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_selectionRange>
method textDocument-selectionRange(:%textDocument, :$positions, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my @syms  = extract-symbols($doc);
    my Int $line-count = $doc.lines-count;
    return [].Array if $line-count == 0;

    my @result;

    my @norm-positions;
    if $positions ~~ Positional {
        for @$positions -> $p {
            if $p ~~ Hash {
                @norm-positions.push: $p;
            }
        }
    } elsif $positions ~~ Hash {
        @norm-positions.push: $positions;
    }

    sub pos-cmp(%p1, %p2 --> Order) {
        return (+%p1<line>, +%p1<character>) cmp (+%p2<line>, +%p2<character>);
    }

    sub range-contains(%outer, %inner --> Bool) {
        my $s-cmp = pos-cmp(%outer<start>, %inner<start>);
        my $e-cmp = pos-cmp(%outer<end>, %inner<end>);
        return $s-cmp != More && $e-cmp != Less;
    }

    sub range-eq(%r1, %r2 --> Bool) {
        return pos-cmp(%r1<start>, %r2<start>) == Same && pos-cmp(%r1<end>, %r2<end>) == Same;
    }

    sub range-span(%r --> Int) {
        my Int $line-diff = +%r<end><line> - +%r<start><line>;
        my Int $char-diff = +%r<end><character> - +%r<start><character>;
        return $line-diff * 100_000 + $char-diff;
    }

    my Hash $doc-range = hash(
        start => hash( line => 0, character => 0 ),
        end   => hash( line => $line-count, character => 0 )
    );

    try {
        for @norm-positions -> $pos-item {
            my %pos = $pos-item ~~ Hash ?? %$pos-item !! %($pos-item);
            my Int $line = +%pos<line>;
            my Int $char = +%pos<character>;

            my $word-data  = get-word-range($doc, $line, $char);
            my Hash $word-range = $word-data ?? hash(|$word-data<range>) !! hash(
                start => hash( line => $line, character => $char ),
                end   => hash( line => $line, character => $char )
            );

            my Str $lt     = $line < $line-count ?? $doc.line-text($line) !! "";
            my Int $line-len = utf16-length($lt);
            my Hash $line-range = hash(
                start => hash( line => $line, character => 0 ),
                end   => hash( line => $line, character => $line-len )
            );

            my @candidates;
            @candidates.push: $word-range;

            sub collect-symbol-ranges(@list) {
                for @list -> $s {
                    my $r = $s<range>;
                    if $r && range-contains($r, $word-range) {
                        @candidates.push: hash(|$r);
                    }
                    if $s<selectionRange> && range-contains($s<selectionRange>, $word-range) {
                        @candidates.push: hash(|$s<selectionRange>);
                    }
                    collect-symbol-ranges($s<children>) if $s<children>;
                }
            }
            collect-symbol-ranges(@syms);

            if range-contains($line-range, $word-range) {
                @candidates.push: $line-range;
            }

            @candidates.push: $doc-range;

            my @unique;
            for @candidates -> %c {
                unless @unique.first({ range-eq($_, %c) }) {
                    @unique.push: %c;
                }
            }

            my @sorted = @unique.sort({
                    my $span-diff = range-span($^a) <=> range-span($^b);
                    if $span-diff != Same {
                        $span-diff;
                    } else {
                        my $s = pos-cmp($^b<start>, $^a<start>);
                        $s != Same ?? $s !! pos-cmp($^a<end>, $^b<end>);
                    }
            });

            my @chain;
            for @sorted -> %cand {
                if @chain.elems == 0 {
                    @chain.push: %cand;
                } elsif range-contains(%cand, @chain[*-1]) && !range-eq(%cand, @chain[*-1]) {
                    @chain.push: %cand;
                }
            }

            my $curr;
            if @chain.elems > 0 {
                $curr = %( range => @chain[*-1] );
                if @chain.elems > 1 {
                    for @chain[0 ..^ *-1].reverse -> %r {
                        $curr = %( range => %r, parent => $curr );
                    }
                }
            }
            @result.push: $curr if $curr.defined;
        }
        CATCH {
            default {
                note "ERROR in selectionRange: " ~ .message;
            }
        }
    }

    return @result.Array;
}
