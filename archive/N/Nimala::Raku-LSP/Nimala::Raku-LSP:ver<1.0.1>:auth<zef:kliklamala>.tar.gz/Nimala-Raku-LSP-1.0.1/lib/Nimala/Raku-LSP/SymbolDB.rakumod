use v6.d;
unit class Nimala::Raku-LSP::SymbolDB;

use DBIish;
use JSON::Fast;
use Nimala::Raku-LSP::Cache;
use Nimala::Raku-LSP::URI;

our constant $SCHEMA_VERSION = "4";
our constant $PARSER_VERSION = "1";

has IO::Path $.workspace-root;
has IO::Path $.db-path;
has Any $!dbh;
has Lock $!lock .= new;
has %!statement-cache;

method statement-cache-count(--> Int) {
    $!lock.protect: { %!statement-cache.elems }
}

submethod TWEAK(Bool :$memory = False) {
    if $memory {
        self.open-memory();
    }
}

method open-memory(--> Nil) {
    $!lock.protect: {
        self.close() if $!dbh.defined;
        $!dbh = DBIish.connect("SQLite", :database(":memory:"));
        self!init-schema();
        self!init-connection();
    }
}

method is-open(--> Bool) {
    $!lock.protect: { $!dbh.defined }
}

method !init-connection(--> Nil) {
    self!exec("PRAGMA foreign_keys = ON;");
    self!exec("PRAGMA busy_timeout = 5000;");
    self!exec("PRAGMA temp_store = MEMORY;");

    self!exec(q:to/SQL/);
    CREATE TEMP TABLE IF NOT EXISTS overlay_files (
        uri     TEXT PRIMARY KEY,
        hash    TEXT NOT NULL,
        version INTEGER NOT NULL
    );
    SQL

    self!exec(q:to/SQL/);
    CREATE TEMP TABLE IF NOT EXISTS overlay_symbols (
        id           INTEGER PRIMARY KEY,
        uri          TEXT NOT NULL,
        name         TEXT NOT NULL,
        fqn          TEXT,
        kind         INTEGER NOT NULL,
        start_line   INTEGER NOT NULL,
        start_char   INTEGER NOT NULL,
        end_line     INTEGER NOT NULL,
        end_char     INTEGER NOT NULL,
        detail       TEXT,
        container    TEXT,
        source       TEXT NOT NULL DEFAULT 'shallow',
        data         TEXT
    );
    SQL

    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_sym_uri ON overlay_symbols(uri);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_sym_name ON overlay_symbols(name);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_sym_fqn ON overlay_symbols(fqn);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_sym_name_nocase ON overlay_symbols(name COLLATE NOCASE);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_sym_fqn_nocase ON overlay_symbols(fqn COLLATE NOCASE);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_sym_range ON overlay_symbols(uri, start_line, start_char);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_sym_uri_container ON overlay_symbols(uri, container, source);");

    self!exec(q:to/SQL/);
    CREATE TEMP TABLE IF NOT EXISTS overlay_references (
        id         INTEGER PRIMARY KEY,
        uri        TEXT NOT NULL,
        name       TEXT NOT NULL,
        start_line INTEGER NOT NULL,
        start_char INTEGER NOT NULL,
        end_line   INTEGER NOT NULL,
        end_char   INTEGER NOT NULL,
        is_decl    INTEGER NOT NULL DEFAULT 0
    );
    SQL

    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_ref_name ON overlay_references(name);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_ref_uri ON overlay_references(uri);");

    self!exec(q:to/SQL/);
    CREATE TEMP TABLE IF NOT EXISTS overlay_role_consumers (
        role_name     TEXT NOT NULL,
        consumer_name TEXT NOT NULL,
        uri           TEXT NOT NULL,
        PRIMARY KEY (role_name, consumer_name, uri)
    );
    SQL

    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_role_uri ON overlay_role_consumers(uri);");
    self!exec("CREATE INDEX IF NOT EXISTS idx_ov_role_name ON overlay_role_consumers(role_name);");

    self!exec(q:to/SQL/);
    CREATE TEMP VIEW IF NOT EXISTS symbols AS
      SELECT id, uri, name, fqn, kind, start_line, start_char, end_line, end_char, detail, container, source, data
        FROM main.symbols
       WHERE uri NOT IN (SELECT uri FROM temp.overlay_files)
      UNION ALL
      SELECT id, uri, name, fqn, kind, start_line, start_char, end_line, end_char, detail, container, source, data
        FROM temp.overlay_symbols;
    SQL

    self!exec(q:to/SQL/);
    CREATE TEMP VIEW IF NOT EXISTS symbol_references AS
      SELECT id, uri, name, start_line, start_char, end_line, end_char, is_decl
        FROM main.symbol_references
       WHERE uri NOT IN (SELECT uri FROM temp.overlay_files)
      UNION ALL
      SELECT id, uri, name, start_line, start_char, end_line, end_char, is_decl
        FROM temp.overlay_references;
    SQL

    self!exec(q:to/SQL/);
    CREATE TEMP VIEW IF NOT EXISTS role_consumers AS
      SELECT role_name, consumer_name, uri
        FROM main.role_consumers
       WHERE uri NOT IN (SELECT uri FROM temp.overlay_files)
      UNION ALL
      SELECT role_name, consumer_name, uri
        FROM temp.overlay_role_consumers;
    SQL
}

method !prepare(Str $sql) {
    %!statement-cache{$sql} //= $!dbh.prepare($sql);
}

method !exec(Str $sql, *@params --> Nil) {
    my $sth = $!dbh.prepare($sql);
    $sth.execute(|@params);
    $sth.allrows;
    $sth.dispose;
}

method open(IO::Path $workspace-root --> Nil) {
    $!lock.protect: {
        self.close() if $!dbh.defined;
        $!workspace-root = $workspace-root;
        my $nimala-dir = $!workspace-root.child('.nimala');
        try { mkdir $nimala-dir unless $nimala-dir.e; }
        if !$nimala-dir.e {
            self.open-memory();
            return;
        }
        $!db-path = $nimala-dir.child('symbols.db');

        my Bool $need-recreate = False;
        if $!db-path.e {
            my $temp-dbh = try { DBIish.connect("SQLite", :database($!db-path.Str)) };
            if $temp-dbh {
                my ($version, $p-version) = try {
                    my $sth = $temp-dbh.prepare("SELECT key, value FROM meta WHERE key IN ('schema_version', 'parser_version')");
                    $sth.execute();
                    my @rows = $sth.allrows(:array-of-hash);
                    $sth.dispose;
                    my %m;
                    for @rows -> %r { %m{%r<key>} = %r<value>; }
                    (%m<schema_version>, %m<parser_version>);
                };
                $temp-dbh.dispose;
                if ($version // "") ne $SCHEMA_VERSION || ($p-version // "") ne $PARSER_VERSION {
                    $need-recreate = True;
                }
            } else {
                $need-recreate = True;
            }
        }

        if $need-recreate {
            self!remove-db-files();
        }

        $!dbh = try { DBIish.connect("SQLite", :database($!db-path.Str)) };
        if !$!dbh.defined {
            $!dbh = DBIish.connect("SQLite", :database(":memory:"));
            self!init-schema();
            self!init-connection();
            return;
        }
        self!exec("PRAGMA journal_mode=WAL");
        self!init-schema();
        self!init-connection();
    }
}

method close(--> Nil) {
    $!lock.protect: {
        for %!statement-cache.values -> $sth {
            try { $sth.dispose; }
        }
        %!statement-cache = ();
        if $!dbh.defined {
            try { $!dbh.dispose; }
            $!dbh = Nil;
        }
    }
}

method !remove-db-files() {
    if $!db-path && $!db-path.e {
        try { $!db-path.unlink; }
    }
    my $wal = $!db-path.sibling($!db-path.basename ~ "-wal");
    if $wal.e {
        try { $wal.unlink; }
    }
    my $shm = $!db-path.sibling($!db-path.basename ~ "-shm");
    if $shm.e {
        try { $shm.unlink; }
    }
}

method !init-schema() {
    self!exec(q:to/SQL/);
    CREATE TABLE IF NOT EXISTS main.meta (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    SQL

    self!exec(q:to/SQL/);
    CREATE TABLE IF NOT EXISTS main.files (
        uri        TEXT PRIMARY KEY,
        hash       TEXT NOT NULL,
        mtime      INTEGER NOT NULL DEFAULT 0,
        size       INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    SQL

    try { self!exec("ALTER TABLE main.files ADD COLUMN mtime INTEGER NOT NULL DEFAULT 0;"); }
    try { self!exec("ALTER TABLE main.files ADD COLUMN size INTEGER NOT NULL DEFAULT 0;"); }

    self!exec(q:to/SQL/);
    CREATE TABLE IF NOT EXISTS main.symbols (
        id           INTEGER PRIMARY KEY,
        uri          TEXT NOT NULL REFERENCES files(uri) ON DELETE CASCADE,
        name         TEXT NOT NULL,
        fqn          TEXT,
        kind         INTEGER NOT NULL,
        start_line   INTEGER NOT NULL,
        start_char   INTEGER NOT NULL,
        end_line     INTEGER NOT NULL,
        end_char     INTEGER NOT NULL,
        detail       TEXT,
        container    TEXT,
        source       TEXT NOT NULL DEFAULT 'shallow',
        data         TEXT
    );
    SQL

    self!exec("CREATE INDEX IF NOT EXISTS main.idx_sym_uri ON symbols(uri);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_sym_name ON symbols(name);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_sym_fqn ON symbols(fqn);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_sym_name_nocase ON symbols(name COLLATE NOCASE);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_sym_fqn_nocase ON symbols(fqn COLLATE NOCASE);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_sym_range ON symbols(uri, start_line, start_char);");

    self!exec(q:to/SQL/);
    CREATE TABLE IF NOT EXISTS main.vendor_symbols (
        id        INTEGER PRIMARY KEY,
        module    TEXT NOT NULL,
        version   TEXT,
        auth      TEXT,
        name      TEXT NOT NULL,
        fqn       TEXT,
        kind      INTEGER NOT NULL,
        detail    TEXT,
        container TEXT,
        data      TEXT
    );
    SQL

    self!exec("CREATE INDEX IF NOT EXISTS main.idx_vendor_mod ON vendor_symbols(module);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_vendor_name ON vendor_symbols(name COLLATE NOCASE);");

    self!exec(q:to/SQL/);
    CREATE TABLE IF NOT EXISTS main.role_consumers (
        role_name     TEXT NOT NULL,
        consumer_name TEXT NOT NULL,
        uri           TEXT NOT NULL REFERENCES files(uri) ON DELETE CASCADE,
        PRIMARY KEY (role_name, consumer_name, uri)
    );
    SQL

    self!exec("CREATE INDEX IF NOT EXISTS main.idx_role_uri ON role_consumers(uri);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_role_name ON role_consumers(role_name);");

    self!exec(q:to/SQL/);
    CREATE TABLE IF NOT EXISTS main.symbol_references (
        id         INTEGER PRIMARY KEY,
        uri        TEXT NOT NULL REFERENCES files(uri) ON DELETE CASCADE,
        name       TEXT NOT NULL,
        start_line INTEGER NOT NULL,
        start_char INTEGER NOT NULL,
        end_line   INTEGER NOT NULL,
        end_char   INTEGER NOT NULL,
        is_decl    INTEGER NOT NULL DEFAULT 0
    );
    SQL

    self!exec("CREATE INDEX IF NOT EXISTS main.idx_ref_name ON symbol_references(name);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_ref_uri ON symbol_references(uri);");
    self!exec("CREATE INDEX IF NOT EXISTS main.idx_sym_uri_container ON symbols(uri, container, source);");

    self!exec("INSERT OR REPLACE INTO main.meta (key, value) VALUES ('schema_version', '$SCHEMA_VERSION');");
    self!exec("INSERT OR REPLACE INTO main.meta (key, value) VALUES ('parser_version', '$PARSER_VERSION');");
}

method !flatten-symbols(@symbols, Str $source, @flat, @flat-roles --> Nil) {
    sub walk(@syms, Str $parent-fqn = "", Int $parent-kind = 0) {
        for @syms -> $s {
            my Str $name = ($s<name> // "").Str;
            next if $name eq "";
            my Int $kind = ($s<kind> // 1).Int;
            # Skip routine-local variables from workspace symbol table to prevent clutter and false completions
            if $kind == 13 && ($parent-kind == 6 || $parent-kind == 12) {
                next;
            }
            my Str $container = ($s<containerName> // $s<container> // $parent-fqn).Str;
            my Str $fqn = ($s<fqn> // ($parent-fqn ?? "$parent-fqn\::$name" !! $name)).Str;

            my Int $start-line = 0;
            my Int $start-char = 0;
            my Int $end-line = 0;
            my Int $end-char = 0;
            if $s<range> {
                $start-line = ($s<range><start><line> // 0).Int;
                $start-char = ($s<range><start><character> // 0).Int;
                $end-line = ($s<range><end><line> // 0).Int;
                $end-char = ($s<range><end><character> // 0).Int;
            }

            my %extra;
            for <docs supertypes roles selectionRange> -> $k {
                if $s{$k}.defined {
                    %extra{$k} = $s{$k};
                }
            }
            my Str $data-json = %extra ?? to-json(%extra) !! "";

            @flat.push({
                    name => $name,
                    fqn => $fqn,
                    kind => $kind,
                    start_line => $start-line,
                    start_char => $start-char,
                    end_line => $end-line,
                    end_char => $end-char,
                    detail => ($s<detail> // "").Str,
                    container => $container,
                    source => $source,
                    data => $data-json
            });

            # Collect role/supertype consumers (classes, roles at any depth)
            if $s<supertypes> || $s<roles> {
                my @supers = [|($s<supertypes> // []), |($s<roles> // [])].grep(*.defined).map(*.Str).grep(* ne "").unique;
                for @supers -> $sup {
                    @flat-roles.push: { role => $sup, consumer => $name };
                }
            }

            if $s<children> {
                walk($s<children>, $fqn, $kind);
            }
        }
    }
    walk(@symbols);
}

method !insert-symbols(Str $table, Str $uri, @flat --> Nil) {
    return unless @flat;
    my $sth-ins = $!dbh.prepare(
        "INSERT INTO $table (uri, name, fqn, kind, start_line, start_char, end_line, end_char, detail, container, source, data) " ~
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    for @flat -> $row {
        $sth-ins.execute(
            $uri,
            $row<name>,
            $row<fqn>,
            $row<kind>,
            $row<start_line>,
            $row<start_char>,
            $row<end_line>,
            $row<end_char>,
            $row<detail>,
            $row<container>,
            $row<source>,
            $row<data>
        );
    }
    $sth-ins.dispose;
}

method !insert-references(Str $table, Str $uri, @references --> Nil) {
    return unless @references;
    my $sth-ins-ref = $!dbh.prepare(
        "INSERT INTO $table (uri, name, start_line, start_char, end_line, end_char, is_decl) " ~
        "VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    for @references -> $r {
        my Str $ref-name = ($r<name> // "").Str;
        next if $ref-name eq "";
        my Int $sl = +($r<range><start><line> // $r<start_line> // 0);
        my Int $sc = +($r<range><start><character> // $r<start_char> // 0);
        my Int $el = +($r<range><end><line> // $r<end_line> // $sl);
        my Int $ec = +($r<range><end><character> // $r<end_char> // $sc);
        my Int $is-decl = ($r<is_decl> // $r<is-decl> // 0) ?? 1 !! 0;
        $sth-ins-ref.execute($uri, $ref-name, $sl, $sc, $el, $ec, $is-decl);
    }
    $sth-ins-ref.dispose;
}

method !insert-role-consumers(Str $table, Str $uri, @flat-roles --> Nil) {
    return unless @flat-roles;
    my $sth-ins-roles = $!dbh.prepare(
        "INSERT OR IGNORE INTO $table (role_name, consumer_name, uri) " ~
        "VALUES (?, ?, ?)"
    );
    for @flat-roles -> $rc {
        $sth-ins-roles.execute($rc<role>, $rc<consumer>, $uri);
    }
    $sth-ins-roles.dispose;
}

method update-file-symbols(Str $uri, Str $hash, @symbols, Str :$source = 'shallow', Int :$mtime = 0, Int :$size = 0, :@references = [] --> Nil) {
    my @flat;
    my @flat-roles;
    self!flatten-symbols(@symbols, $source, @flat, @flat-roles);

    $!lock.protect: {
        return unless $!dbh.defined;
        self!exec("BEGIN IMMEDIATE");
        try {
            my $sth-file = $!dbh.prepare(
                "INSERT INTO main.files (uri, hash, mtime, size, updated_at) VALUES (?, ?, ?, ?, unixepoch()) " ~
                "ON CONFLICT(uri) DO UPDATE SET hash = excluded.hash, mtime = excluded.mtime, size = excluded.size, updated_at = excluded.updated_at"
            );
            $sth-file.execute($uri, $hash, $mtime, $size);
            $sth-file.dispose;

            my $sth-del = $!dbh.prepare("DELETE FROM main.symbols WHERE uri = ? AND source = ?");
            $sth-del.execute($uri, $source);
            $sth-del.dispose;

            self!insert-symbols('main.symbols', $uri, @flat);

            my $sth-del-refs = $!dbh.prepare("DELETE FROM main.symbol_references WHERE uri = ?");
            $sth-del-refs.execute($uri);
            $sth-del-refs.dispose;

            self!insert-references('main.symbol_references', $uri, @references);

            my $sth-del-roles = $!dbh.prepare("DELETE FROM main.role_consumers WHERE uri = ?");
            $sth-del-roles.execute($uri);
            $sth-del-roles.dispose;

            self!insert-role-consumers('main.role_consumers', $uri, @flat-roles);

            self!exec("COMMIT");
            CATCH {
                default {
                    try { self!exec("ROLLBACK"); }
                        .rethrow;
                }
            }
        }
    }
}

method update-overlay(Str $uri, Str $hash, Int $version, @symbols, :@references = [] --> Nil) {
    my @flat;
    my @flat-roles;
    self!flatten-symbols(@symbols, 'shallow', @flat, @flat-roles);

    $!lock.protect: {
        return unless $!dbh.defined;
        self!exec("BEGIN");
        try {
            my $sth-file = $!dbh.prepare(
                "INSERT INTO temp.overlay_files (uri, hash, version) VALUES (?, ?, ?) " ~
                "ON CONFLICT(uri) DO UPDATE SET hash = excluded.hash, version = excluded.version"
            );
            $sth-file.execute($uri, $hash, $version);
            $sth-file.dispose;

            my $sth-del = $!dbh.prepare("DELETE FROM temp.overlay_symbols WHERE uri = ?");
            $sth-del.execute($uri);
            $sth-del.dispose;

            self!insert-symbols('temp.overlay_symbols', $uri, @flat);

            my $sth-del-refs = $!dbh.prepare("DELETE FROM temp.overlay_references WHERE uri = ?");
            $sth-del-refs.execute($uri);
            $sth-del-refs.dispose;

            self!insert-references('temp.overlay_references', $uri, @references);

            my $sth-del-roles = $!dbh.prepare("DELETE FROM temp.overlay_role_consumers WHERE uri = ?");
            $sth-del-roles.execute($uri);
            $sth-del-roles.dispose;

            self!insert-role-consumers('temp.overlay_role_consumers', $uri, @flat-roles);

            self!exec("COMMIT");
            CATCH {
                default {
                    try { self!exec("ROLLBACK"); }
                        .rethrow;
                }
            }
        }
    }
}

method drop-overlay(Str $uri --> Nil) {
    $!lock.protect: {
        return unless $!dbh.defined;
        self!exec("BEGIN");
        try {
            my $sth-f = $!dbh.prepare("DELETE FROM temp.overlay_files WHERE uri = ?");
            $sth-f.execute($uri);
            $sth-f.dispose;

            my $sth-s = $!dbh.prepare("DELETE FROM temp.overlay_symbols WHERE uri = ?");
            $sth-s.execute($uri);
            $sth-s.dispose;

            my $sth-r = $!dbh.prepare("DELETE FROM temp.overlay_references WHERE uri = ?");
            $sth-r.execute($uri);
            $sth-r.dispose;

            my $sth-rc = $!dbh.prepare("DELETE FROM temp.overlay_role_consumers WHERE uri = ?");
            $sth-rc.execute($uri);
            $sth-rc.dispose;

            self!exec("COMMIT");
            CATCH {
                default {
                    try { self!exec("ROLLBACK"); }
                        .rethrow;
                }
            }
        }
    }
}

#| Returns the document version stored in the overlay, or -1 if not overlaid
method get-overlay-version(Str $uri --> Int) {
    $!lock.protect: {
        return -1 unless $!dbh.defined;
        my $sth = self!prepare("SELECT version FROM temp.overlay_files WHERE uri = ?");
        $sth.execute($uri);
        my @rows = $sth.allrows;
        return @rows.elems > 0 ?? (@rows[0][0] // -1).Int !! -1;
    }
}

method touch-file(Str $uri, Str $hash, Int $mtime, Int $size --> Bool) {
    $!lock.protect: {
        return False unless $!dbh.defined;
        my Int $changed = 0;
        self!exec("BEGIN IMMEDIATE");
        try {
            my $sth = $!dbh.prepare(
                "UPDATE main.files SET mtime = ?, size = ?, updated_at = unixepoch() WHERE uri = ? AND hash = ?"
            );
            $sth.execute($mtime, $size, $uri, $hash);
            $sth.dispose;
            my $sth-c = $!dbh.prepare("SELECT changes()");
            $sth-c.execute();
            my @r = $sth-c.allrows;
            $changed = (@r[0][0] // 0).Int;
            $sth-c.dispose;
            self!exec("COMMIT");
            CATCH {
                default {
                    try { self!exec("ROLLBACK"); }
                        .rethrow;
                }
            }
        }
        return $changed > 0;
    }
}

method remove-file(Str $uri --> Nil) {
    $!lock.protect: {
        return unless $!dbh.defined;
        self!exec("BEGIN IMMEDIATE");
        try {
            my $sth-f = $!dbh.prepare("DELETE FROM main.files WHERE uri = ?");
            $sth-f.execute($uri);
            $sth-f.dispose;

            self!exec("COMMIT");
            CATCH {
                default {
                    try { self!exec("ROLLBACK"); }
                        .rethrow;
                }
            }
        }
    }
}

method remove-folder(Str $folder-uri --> Nil) {
    my Str $prefix = $folder-uri.ends-with('/') ?? $folder-uri !! ($folder-uri ~ '/');
    my Int $len = $prefix.chars;
    $!lock.protect: {
        return unless $!dbh.defined;
        self!exec("BEGIN IMMEDIATE");
        try {
            my $sth-f = $!dbh.prepare("DELETE FROM main.files WHERE uri = ? OR substr(uri, 1, ?) = ?");
            $sth-f.execute($folder-uri, $len, $prefix);
            $sth-f.dispose;

            self!exec("COMMIT");
            CATCH {
                default {
                    try { self!exec("ROLLBACK"); }
                        .rethrow;
                }
            }
        }
    }
}

method !row-to-symbol(%r --> Hash) {
    my %sym = (
        name => %r<name>.Str,
        fqn => (%r<fqn> // "").Str,
        kind => %r<kind>.Int,
        containerName => (%r<container> // "").Str,
        detail => (%r<detail> // "").Str,
        uri => (%r<uri> // "").Str,
        range => {
            start => { line => %r<start_line>.Int, character => %r<start_char>.Int },
            end   => { line => %r<end_line>.Int, character => %r<end_char>.Int }
        }
    );
    if %r<data> {
        my $extra = try { from-json(%r<data>) };
        if $extra ~~ Hash {
            for $extra.kv -> $k, $v {
                %sym{$k} = $v unless %sym{$k}:exists;
            }
        }
    }
    %sym<selectionRange> //= %sym<range>;
    %sym<children> //= [];
    %sym<supertypes> //= [];
    return %sym;
}

method find-enclosing(Str $uri, Int $line, Int $char --> Seq) {
    my @results;
    $!lock.protect: {
        return () unless $!dbh.defined;
        my $sth = self!prepare(
            "SELECT * FROM symbols WHERE uri = ? AND start_line <= ? AND end_line >= ?"
        );
        $sth.execute($uri, $line, $line);
        my @rows = $sth.allrows(:array-of-hash);

        my %seen;
        for @rows -> %r {
            my Int $sl = %r<start_line>.Int;
            my Int $sc = %r<start_char>.Int;
            my Int $el = %r<end_line>.Int;
            my Int $ec = %r<end_char>.Int;

            if $sl == $line && $sc > $char { next; }
            if $el == $line && $ec < $char { next; }

            my Str $key = %r<name>.Str ~ ":" ~ $sl;
            next if %seen{$key};
            %seen{$key} = True;

            @results.push(self!row-to-symbol(%r));
        }
    }
    return @results.sort({
            ($_<range><end><line> - $_<range><start><line>) * 100000 +
            ($_<range><end><character> - $_<range><start><character>)
    }).Seq;
}

method find-exact(Str $name --> Seq) {
    my @results;
    $!lock.protect: {
        return () unless $!dbh.defined;
        my $sth;
        if $name.contains('::') {
            $sth = self!prepare(
                "SELECT * FROM symbols WHERE fqn = ? " ~
                "UNION " ~
                "SELECT * FROM symbols WHERE name = ?"
            );
            $sth.execute($name, $name);
        } else {
            $sth = self!prepare(
                "SELECT * FROM symbols WHERE name = ?"
            );
            $sth.execute($name);
        }
        my @rows = $sth.allrows(:array-of-hash);
        my %seen;
        for @rows -> %r {
            my %sym = self!row-to-symbol(%r);
            my Str $key = (%r<uri> // '').Str ~ "::" ~ %r<name>.Str ~ ":" ~ (%r<start_line> // 0).Str;
            if %seen{$key}:exists {
                if (!%seen{$key}<children> || !%seen{$key}<children>.elems) && (%sym<children> && %sym<children>.elems) {
                    %seen{$key} = %sym;
                }
            } else {
                %seen{$key} = %sym;
            }
        }
        for %seen.values -> %sym {
            if (!%sym<children> || !%sym<children>.elems) {
                my Str $fqn = (%sym<fqn> // %sym<name>).Str;
                my $sth-kids = self!prepare("SELECT * FROM symbols WHERE uri = ? AND (container = ? OR container = ?) AND source = 'shallow' ORDER BY start_line, start_char");
                $sth-kids.execute(%sym<uri>, $fqn, %sym<name>);
                my @k-rows = $sth-kids.allrows(:array-of-hash);
                for @k-rows -> %kr {
                    %sym<children>.push(self!row-to-symbol(%kr));
                }
            }
        }
        @results = %seen.values.Array;
    }
    return @results.Seq;
}

method find-references(Str $name, Bool :$include-declaration = True --> Seq) {
    my @results;
    $!lock.protect: {
        return () unless $!dbh.defined;
        my Str $sql = $include-declaration
        ?? "SELECT uri, start_line, start_char, end_line, end_char, is_decl FROM symbol_references WHERE name = ?"
        !! "SELECT uri, start_line, start_char, end_line, end_char, is_decl FROM symbol_references WHERE name = ? AND is_decl = 0";
        my $sth = self!prepare($sql);
        $sth.execute($name);
        my @rows = $sth.allrows(:array-of-hash);

        for @rows -> %r {
            @results.push(hash(
                    uri => %r<uri>.Str,
                    range => hash(
                        start => hash( line => %r<start_line>.Int, character => %r<start_char>.Int ),
                        end   => hash( line => %r<end_line>.Int, character => %r<end_char>.Int )
                    ),
                    is_decl => %r<is_decl>.Int == 1
            ));
        }
    }
    return @results.Seq;
}

method get-symbol-uris(Str $name --> Array) {
    my @uris;
    $!lock.protect: {
        return [] unless $!dbh.defined;
        my $sth = self!prepare(
            "SELECT uri FROM symbols WHERE name = ? " ~
            "UNION " ~
            "SELECT uri FROM symbols WHERE fqn = ?"
        );
        $sth.execute($name, $name);
        my @rows = $sth.allrows(:array-of-hash);
        for @rows -> %r {
            @uris.push(%r<uri>.Str);
        }
    }
    return @uris.Array;
}

method query-symbols(Str $query, Bool :$prefix-only = False --> Seq) {
    my @results;
    my Bool $has-ns = $query.contains('::');
    my Str $escaped = $query.subst('\\', '\\\\', :g).subst('%', '\\%', :g).subst('_', '\\_', :g);
    my Str $pattern = $prefix-only ?? "$escaped%" !! "%$escaped%";

    $!lock.protect: {
        return () unless $!dbh.defined;

        # Query workspace symbols
        my Str $sym-sql = $has-ns
        ?? "SELECT name, kind, container, uri, start_line, start_char, end_line, end_char FROM symbols WHERE fqn LIKE ? ESCAPE '\\' LIMIT 100"
        !! "SELECT name, kind, container, uri, start_line, start_char, end_line, end_char FROM symbols WHERE name LIKE ? ESCAPE '\\' LIMIT 100";
        my $sth-sym = self!prepare($sym-sql);
        $sth-sym.execute($pattern);
        my @sym-rows = $sth-sym.allrows(:array-of-hash);

        my %seen;
        for @sym-rows -> %r {
            my Str $key = %r<uri>.Str ~ "::" ~ %r<name>.Str ~ ":" ~ %r<start_line>.Str;
            next if %seen{$key};
            %seen{$key} = True;

            my %res = (
                name => %r<name>.Str,
                kind => %r<kind>.Int,
                location => {
                    uri => %r<uri>.Str,
                    range => {
                        start => { line => %r<start_line>.Int, character => %r<start_char>.Int },
                        end   => { line => %r<end_line>.Int, character => %r<end_char>.Int }
                    }
                }
            );
            %res<containerName> = %r<container>.Str if %r<container>;
            @results.push(%res);
        }

        # Query vendor symbols
        my Str $vendor-sql = $has-ns
        ?? "SELECT name, kind, container, data FROM vendor_symbols WHERE fqn LIKE ? ESCAPE '\\' AND kind > 0 LIMIT 100"
        !! "SELECT name, kind, container, data FROM vendor_symbols WHERE name LIKE ? ESCAPE '\\' AND kind > 0 LIMIT 100";
        my $sth-v = self!prepare($vendor-sql);
        $sth-v.execute($pattern);
        my @v-rows = $sth-v.allrows(:array-of-hash);

        for @v-rows -> %r {
            my %res = (
                name => %r<name>.Str,
                kind => (%r<kind> // 1).Int
            );
            %res<containerName> = %r<container>.Str if %r<container>;
            if %r<data> {
                my $v-data = try { from-json(%r<data>) };
                if $v-data ~~ Hash && $v-data<location> {
                    %res<location> = $v-data<location>;
                }
            }
            if %res<location> {
                @results.push(%res);
            }
        }
    }
    return @results.Seq;
}

method set-vendor-symbols(Str() $module, Str() $version, Str() $auth, @symbols --> Nil) {
    my @flat-vendor;
    sub flatten-vendor(@syms, Str $parent-fqn = "") {
        for @syms -> $s {
            my Str $name = ($s<name> // "").Str;
            next if $name eq "";
            my Str $container = ($s<containerName> // $s<container> // $parent-fqn).Str;
            my Str $fqn = ($s<fqn> // ($container ?? "$container\::$name" !! $name)).Str;
            my Str $data-json = try { to-json($s) } // "";

            @flat-vendor.push({
                    module => $module,
                    version => $version,
                    auth => $auth,
                    name => $name,
                    fqn => $fqn,
                    kind => ($s<kind> // 1).Int,
                    detail => ($s<detail> // "").Str,
                    container => $container,
                    data => $data-json
            });

            if $s<children> {
                flatten-vendor($s<children>, $fqn);
            }
        }
    }
    flatten-vendor(@symbols);

    $!lock.protect: {
        return unless $!dbh.defined;
        self!exec("BEGIN IMMEDIATE");
        try {
            my $sth-del = $!dbh.prepare("DELETE FROM main.vendor_symbols WHERE module = ?");
            $sth-del.execute($module);
            $sth-del.dispose;

            if @flat-vendor {
                my $sth-ins = $!dbh.prepare(
                    "INSERT INTO main.vendor_symbols (module, version, auth, name, fqn, kind, detail, container, data) " ~
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                for @flat-vendor -> $v {
                    $sth-ins.execute(
                        $v<module>,
                        $v<version>,
                        $v<auth>,
                        $v<name>,
                        $v<fqn>,
                        $v<kind>,
                        $v<detail>,
                        $v<container>,
                        $v<data>
                    );
                }
                $sth-ins.dispose;
            } else {
                my $sth-neg = $!dbh.prepare(
                    "INSERT INTO main.vendor_symbols (module, version, auth, name, fqn, kind, detail, container, data) " ~
                    "VALUES (?, ?, ?, '', '', 0, 'negative_cache', '', '')"
                );
                $sth-neg.execute($module, $version, $auth);
                $sth-neg.dispose;
            }

            self!exec("COMMIT");
            CATCH {
                default {
                    try { self!exec("ROLLBACK"); }
                        .rethrow;
                }
            }
        }
    }
}

method get-vendor-symbols(--> Seq) {
    my @results;
    $!lock.protect: {
        return () unless $!dbh.defined;
        my $sth = self!prepare("SELECT * FROM vendor_symbols");
        $sth.execute();
        my @rows = $sth.allrows(:array-of-hash);
        for @rows -> %r {
            next if (%r<detail> // "") eq 'negative_cache' || (%r<kind> // 0) == 0;
            if %r<data> {
                my $decoded = try { from-json(%r<data>) };
                if $decoded ~~ Hash {
                    @results.push($decoded);
                    next;
                }
            }
            my %sym = (
                name => %r<name>.Str,
                kind => %r<kind>.Int,
                containerName => (%r<container> // "").Str,
                detail => (%r<detail> // "").Str
            );
            @results.push(%sym);
        }
    }
    return @results.Seq;
}

method get-vendor-symbols-for(Str() $module --> Array) {
    my @results;
    $!lock.protect: {
        return [] unless $!dbh.defined;
        my $sth = self!prepare("SELECT * FROM vendor_symbols WHERE module = ?");
        $sth.execute($module);
        my @rows = $sth.allrows(:array-of-hash);
        for @rows -> %r {
            next if (%r<detail> // "") eq 'negative_cache' || (%r<kind> // 0) == 0;
            if %r<data> {
                my $decoded = try { from-json(%r<data>) };
                if $decoded ~~ Hash {
                    @results.push($decoded);
                    next;
                }
            }
            my %sym = (
                name => %r<name>.Str,
                kind => %r<kind>.Int,
                containerName => (%r<container> // "").Str,
                detail => (%r<detail> // "").Str
            );
            @results.push(%sym);
        }
    }
    return @results.Array;
}

method get-vendor-module-info(Str() $module --> Hash) {
    $!lock.protect: {
        return {} unless $!dbh.defined;
        my $sth = self!prepare("SELECT version, auth, detail, kind FROM vendor_symbols WHERE module = ? LIMIT 1");
        $sth.execute($module);
        my @rows = $sth.allrows(:array-of-hash);
        return {} unless @rows;
        return %(
            version => (@rows[0]<version> // "").Str,
            auth    => (@rows[0]<auth> // "").Str,
            is-negative => ((@rows[0]<detail> // "") eq 'negative_cache' || (@rows[0]<kind> // 0) == 0)
        );
    }
}

method get-role-consumers(Str $role --> Array) {
    my @results;
    $!lock.protect: {
        return [] unless $!dbh.defined;
        my $sth = self!prepare("SELECT consumer_name FROM role_consumers WHERE role_name = ?");
        $sth.execute($role);
        my @rows = $sth.allrows(:array-of-hash);
        for @rows -> %r {
            @results.push(%r<consumer_name>.Str);
        }
    }
    return @results.Array;
}

method get-role-consumer-records(Str $role --> Array) {
    my @results;
    $!lock.protect: {
        return [] unless $!dbh.defined;
        my $sth = self!prepare("SELECT consumer_name, uri FROM role_consumers WHERE role_name = ?");
        $sth.execute($role);
        my @rows = $sth.allrows(:array-of-hash);
        for @rows -> %r {
            @results.push(%( consumer => %r<consumer_name>.Str, uri => %r<uri>.Str ));
        }
    }
    return @results.Array;
}

#| Return (uri, symbol) pairs for classes/roles consuming or inheriting from $role-name
method get-subtypes(Str $role-name --> Positional) {
    my @results;
    $!lock.protect: {
        return [] unless $!dbh.defined;
        my $sth = self!prepare(
            "SELECT DISTINCT s.* FROM role_consumers r " ~
            "JOIN symbols s ON s.uri = r.uri AND s.name = r.consumer_name " ~
            "WHERE r.role_name = ? AND s.kind IN (5, 11) " ~
            "ORDER BY s.uri, s.start_line, s.start_char"
        );
        $sth.execute($role-name);
        my @rows = $sth.allrows(:array-of-hash);
        my %seen;
        my @ordered-keys;
        for @rows -> %r {
            my Str $key = (%r<uri> // '').Str ~ "::" ~ %r<name>.Str ~ ":" ~ (%r<start_line> // 0).Str;
            unless %seen{$key}:exists {
                @ordered-keys.push($key);
                %seen{$key} = self!row-to-symbol(%r);
            }
        }
        for @ordered-keys -> $k {
            my %sym = %seen{$k};
            if (!%sym<children> || !%sym<children>.elems) {
                my Str $fqn = (%sym<fqn> // %sym<name>).Str;
                my $sth-kids = self!prepare(
                    "SELECT * FROM symbols WHERE uri = ? AND (container = ? OR container = ?) AND source = 'shallow' ORDER BY start_line, start_char"
                );
                $sth-kids.execute(%sym<uri>, $fqn, %sym<name>);
                my @k-rows = $sth-kids.allrows(:array-of-hash);
                for @k-rows -> %kr {
                    %sym<children>.push(self!row-to-symbol(%kr));
                }
            }
            @results.push: (%sym<uri>.Str, %sym);
        }
    }
    return @results;
}

method find-exact-in-file(Str $uri, Str $name --> Seq) {
    my @results;
    $!lock.protect: {
        return () unless $!dbh.defined;
        my $sth = self!prepare("SELECT * FROM symbols WHERE uri = ? AND (name = ? OR fqn = ?) AND source = 'shallow'");
        $sth.execute($uri, $name, $name);
        my @rows = $sth.allrows(:array-of-hash);
        for @rows -> %r {
            @results.push(self!row-to-symbol(%r));
        }
    }
    return @results.Seq;
}

#| Checks whether a file's mtime and size in the database match the given values
method is-file-unchanged(Str $uri, Int $mtime, Int $size --> Bool) {
    $!lock.protect: {
        return False unless $!dbh.defined;
        my $sth = self!prepare("SELECT mtime, size FROM files WHERE uri = ?");
        $sth.execute($uri);
        my @rows = $sth.allrows(:array-of-hash);
        return False unless @rows.elems > 0;
        my %row = @rows[0];
        my Int $db-mtime = (%row<mtime> // 0).Int;
        my Int $db-size  = (%row<size> // 0).Int;
        return $db-mtime > 0 && $db-mtime == $mtime && $db-size == $size;
    }
}

#| Returns all distinct URIs present in the symbols view
method get-all-symbol-uris(--> Array) {
    my @uris;
    $!lock.protect: {
        return [] unless $!dbh.defined;
        my $sth = self!prepare("SELECT DISTINCT uri FROM symbols");
        $sth.execute();
        my @rows = $sth.allrows;
        @uris = @rows.map(*[0].Str).Array;
    }
    return @uris;
}

#| Retrieves top-level symbols for a file, reconstructed into a symbol tree
method get-file-symbols(Str $uri --> Positional) {
    my @results;
    $!lock.protect: {
        return [] unless $!dbh.defined;
        my $sth = self!prepare(
            "SELECT * FROM symbols WHERE uri = ? AND source = 'shallow' ORDER BY start_line, start_char"
        );
        $sth.execute($uri);
        my @rows = $sth.allrows(:array-of-hash);

        my %by-key;
        my %containers;
        my @top;
        for @rows -> %r {
            my %sym = self!row-to-symbol(%r);
            my Str $fqn = (%sym<fqn> // %sym<name>).Str;
            my Str $key = $fqn ~ ":" ~ %r<start_line> ~ ":" ~ %r<start_char>;
            %by-key{$key} = %sym;
            my Str $container = (%sym<containerName> // "").Str;
            if $container eq "" {
                @top.push(%sym);
                %containers{$fqn} = %sym;
                %containers{%sym<name>} = %sym;
            } else {
                if %sym<kind> == 2 || %sym<kind> == 5 || %sym<kind> == 10 || %sym<kind> == 11 {
                    %containers{$fqn} = %sym;
                    %containers{%sym<name>} = %sym;
                }
            }
        }
        for @rows -> %r {
            my Str $container = (%r<container> // "").Str;
            if $container ne "" && (%containers{$container}:exists) {
                my Str $fqn = (%r<fqn> // %r<name>).Str;
                my Str $key = $fqn ~ ":" ~ %r<start_line> ~ ":" ~ %r<start_char>;
                my %child = %by-key{$key};
                %containers{$container}<children>.push(%child);
            }
        }
        @results = @top;
    }
    return @results;
}

method validate-index(IO::Path $workspace-root --> Promise) {
    return start {
        # Without a database there is nothing to validate (`return` here would break the promise, M-12)
        if $!dbh.defined {
            my @known-uris;
            my Str $ws-prefix = path-to-uri($workspace-root);
            # Trailing slash, so that a sibling folder sharing the name prefix (`proj2` for `proj`) is not pruned
            $ws-prefix ~= '/' unless $ws-prefix.ends-with('/');
            $!lock.protect: {
                if $!dbh.defined {
                    my $sth = $!dbh.prepare("SELECT uri FROM files");
                    $sth.execute();
                    my @rows = $sth.allrows(:array-of-hash);
                    $sth.dispose;
                    for @rows -> %r {
                        my Str $u = %r<uri>.Str;
                        @known-uris.push($u) if $u.starts-with($ws-prefix);
                    }
                }
            }

            my SetHash $found-uris .= new;
            my @files = find-raku-files($workspace-root);
            for @files -> IO::Path $child {
                $found-uris.set(path-to-uri($child));
            }

            for @known-uris -> $uri {
                unless $found-uris{$uri} {
                    self.remove-file($uri);
                }
            }
        }
    }
}
