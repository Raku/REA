unit module Nimala::Raku-LSP::Analysis::Completion;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::CoreDocs;
use Nimala::Raku-LSP::Analysis::Cursor;
use Nimala::Raku-LSP::Analysis::TypeInference;
use Nimala::Raku-LSP::Analysis::Symbols;

#| Static Method Resolution Order mapping for standard Raku core types
our constant %CORE-MRO is export = %(
    'Str'       => <Str Cool Any Mu>,
    'Int'       => <Int Cool Any Mu>,
    'Num'       => <Num Cool Any Mu>,
    'Rat'       => <Rat Cool Any Mu>,
    'FatRat'    => <FatRat Rational Real Numeric Cool Any Mu>,
    'Complex'   => <Complex Numeric Cool Any Mu>,
    'Bool'      => <Bool Int Cool Any Mu>,
    'Array'     => <Array List Cool Any Mu>,
    'Hash'      => <Hash Map Cool Any Mu>,
    'List'      => <List Cool Any Mu>,
    'Seq'       => <Seq Cool Any Mu>,
    'Map'       => <Map Cool Any Mu>,
    'Set'       => <Set Any Mu>,
    'Bag'       => <Bag Any Mu>,
    'Mix'       => <Mix Any Mu>,
    'Any'       => <Any Mu>,
    'Mu'        => <Mu>,
    'Cool'      => <Cool Any Mu>,
    'Nil'       => <Nil Cool Any Mu>,
    'Date'      => <Date Any Mu>,
    'DateTime'  => <DateTime Any Mu>,
    'Range'     => <Range Cool Any Mu>,
    'Match'     => <Match Capture Cool Any Mu>,
    'Regex'     => <Regex Method Routine Block Code Any Mu>,
    'IO::Path'  => <IO::Path Cool Any Mu>,
    'Promise'   => <Promise Any Mu>,
    'Supply'    => <Supply Any Mu>,
    'Channel'   => <Channel Any Mu>,
    'Pair'      => <Pair Any Mu>,
    'Exception' => <Exception Any Mu>,
    'Failure'   => <Failure Nil Cool Any Mu>,
    'Proc'      => <Proc Any Mu>,
    'Capture'   => <Capture Any Mu>,
    'Signature' => <Signature Any Mu>,
    'Thread'    => <Thread Any Mu>,
);

#| Directly composed Roles per Raku core type
our constant %CORE-ROLES is export = %(
    'Str'   => <Stringy>,
    'Int'   => <Real Numeric>,
    'Rat'   => <Rational Real Numeric>,
    'Array' => <Positional Iterable>,
    'Hash'  => <Associative Iterable>,
    'List'  => <Positional Iterable>,
    'Map'   => <Associative Iterable>,
    'Set'   => <QuantHash>,
    'Bag'   => <QuantHash>,
    'Mix'   => <QuantHash>,
);

#| Standard Raku language keywords
our constant @KEYWORDS is export = <
if else elsif unless with without for while until loop repeat given when default
my our has state constant sub method submethod multi proto class role grammar module package
use need import require return return-rw is does as keep undo NEXT LAST FIRST QUIT
say print put note
>;

#| Context descriptor produced by Phase 1
class CompletionContext is export {
    has Bool $.is-method-call = False;
    has Bool $.is-meta-call   = False;
    has Bool $.is-named-arg   = False;
    has Bool $.is-keyword-pos = False;
    has Bool $.is-use-stmt    = False;
    has Str  $.receiver       = "";
    has Str  $.prefix         = "";
    has Str  $.trigger-char   = "";
}

#| Static Metaclass (HOW) methods available on standard Raku objects
our constant %CORE-META-METHODS is export = %(
    'name'            => 'Returns the name of the type/class',
    'methods'         => 'Returns a list of methods defined on the class',
    'attributes'      => 'Returns a list of attributes defined on the class',
    'mro'             => 'Returns the Method Resolution Order list',
    'roles'           => 'Returns a list of composed roles',
    'parents'         => 'Returns a list of parent classes',
    'can'             => 'Checks if the type object can perform a method',
    'lookup'          => 'Looks up a method by name',
    'find_method'     => 'Finds a method in the class or hierarchy',
    'declares_method' => 'Checks if a method is declared directly on the class',
    'add_method'      => 'Adds a method to the metamodel class',
);

#| Mapping from LSP SymbolKind to LSP CompletionItemKind
my constant %COMPLETION-KIND = %(
    2  => 9,   # Module
    5  => 7,   # Class
    6  => 2,   # Method
    7  => 10,  # Property
    8  => 5,   # Field
    10 => 13,  # Enum
    11 => 8,   # Interface
    12 => 3,   # Function
    13 => 6,   # Variable
    14 => 21,  # Constant
    22 => 20,  # EnumMember
);

sub matches-prefix(Str $label, Str $prefix --> Bool) {
    return True if $prefix eq "";
    my Str $p-fc = $prefix.fc;
    my Str $p-bare = $prefix.subst(/^ <[\$\@\%\&]> /, '').fc;
    my Str $l-fc = $label.fc;
    my Str $l-bare = $label.subst(/^ <[\$\@\%\&]> /, '').fc;

    return True if $l-fc.starts-with($p-fc)
    || $l-fc.starts-with($p-bare)
    || $l-bare.starts-with($p-bare);

    return False;
}

#| Phase 1: Context Analysis
our proto sub analyze-context(|) is export {*}
multi sub analyze-context(Document $doc, Int $line, Int $character --> CompletionContext) {
    return CompletionContext.new if $line < 0 || $line >= $doc.lines-count;
    my Str $line-text = $doc.line-text($line);
    my Int $grapheme-idx = max(0, min($doc.position-to-offset($line, $character) - $doc.line-offsets[$line], $line-text.chars));
    my Str $before = $line-text.substr(0, $grapheme-idx);

    # Check use statement context
    if $before ~~ / [ ^ | ';' ] \s* ('use' | 'need' | 'require') \s+ ( <[\w\:\-]>* ) $/ {
        return CompletionContext.new(
            is-use-stmt => True,
            prefix      => ~$1
        );
    }

    # Check method call context
    my Str $receiver = get-method-call-context($doc, $line, $character);
    if $receiver {
        my Bool $is-meta = False;
        my Str $pref = "";
        if $before ~~ / \. \s* \^ \s* ( <[\w\-]>* ) $/ {
            $is-meta = True;
            $pref = ~$0;
        } elsif $before ~~ / \. \s* ( <[\w\-]>* ) $/ {
            $pref = ~$0;
        }
        return CompletionContext.new(
            is-method-call => True,
            is-meta-call   => $is-meta,
            receiver       => $receiver,
            prefix         => $pref
        );
    }

    # Check named arg context
    if $before ~~ / <!after ':'> ':' ( <[\w\-]>* ) $/ {
        return CompletionContext.new(
            is-named-arg => True,
            prefix       => ~$0
        );
    }

    # Check keyword position
    my Bool $is-kw = False;
    if $before ~~ / [ ^ | <[\;\s\{\}\(\)]> ] \s* ( <[\w\-]>* ) $/ {
        $is-kw = True;
    }
    my Str $pref = "";
    if $before ~~ / ( <[\$\@\%\&\:\w\-]>+ ) $/ {
        $pref = ~$0;
    }
    return CompletionContext.new(
        is-keyword-pos => $is-kw,
        prefix         => $pref
    );
}
multi sub analyze-context(Str $text, Int $line, Int $character --> CompletionContext) {
    my Document $doc .= new(uri => "file:///anon.raku", version => 1, languageId => "raku", :$text);
    return analyze-context($doc, $line, $character);
}

#| Phase 2: Type Resolution
our proto sub resolve-type(|) is export {*}
multi sub resolve-type(Str $receiver, Any $doc, Int $line, Int $character, Any $workspace = Nil --> Str) {
    return "" unless $receiver;

    # Direct class name receiver (e.g. Str.new or Foo.bar)
    if $receiver ~~ /^ <[A..Z]> <[a..zA..Z0..9_\:\-]>* $/ {
        return $receiver;
    }

    if $doc {
        my Str $inferred = find-variable-type($doc, $receiver, $line, $character, $workspace);
        return $inferred if $inferred;
    }

    return "";
}

our sub resolve-members(Str $type-name, Any $workspace = Nil, Any $doc = Nil --> Positional) is export {
    my Hash $info = parse-type-structure($type-name);
    my Str $target = ($info<kind> eq 'generic' || $info<kind> eq 'generic-map')
    ?? $info<container>
    !! ($type-name ne "" ?? $type-name !! "Any");
    my @types-to-visit;
    my Bool %seen-type;

    sub add-type(Str $t, Int $depth) {
        return if %seen-type{$t};
        %seen-type{$t} = True;
        @types-to-visit.push({ name => $t, depth => $depth });

        if %CORE-MRO{$t}:exists {
            for %CORE-MRO{$t}.list -> $sup {
                next if $sup eq $t;
                add-type($sup, $depth + 1);
            }
        }
        if %CORE-ROLES{$t}:exists {
            for %CORE-ROLES{$t}.list -> $role {
                add-type($role, $depth + 1);
            }
        }

        if $workspace && $workspace.can('find-symbol') {
            try {
                my @syms = $workspace.find-symbol($t);
                if @syms {
                    my $s = @syms[0];
                    if $s<supertypes> {
                        for @($s<supertypes>) -> $sup {
                            add-type($sup, $depth + 1);
                        }
                    }
                }
            }
        }
    }

    if $target ne "" {
        add-type($target, 0);
    }
    add-type('Any', 100) unless %seen-type<Any>;
    add-type('Mu', 101)  unless %seen-type<Mu>;

    my @members;
    my %seen;

    for @types-to-visit -> $tv {
        my Str $t = $tv<name>;
        my Int $current-depth = $tv<depth>;
        # 1. Direct class methods from CoreDocs
        my @core-methods = get-core-methods($t);
        for @core-methods -> $m {
            my Str $m-name = $m<name> // "";
            next unless $m-name;
            unless %seen{$m-name} {
                %seen{$m-name} = True;
                @members.push: %(
                    name   => $m-name,
                    detail => $m<detail> // "$t method",
                    type   => $t,
                    depth  => $current-depth
                );
            }
        }

        # 2. Document symbols if available
        if $doc {
            try {
                my @doc-syms = extract-symbols($doc);
                sub find-doc-members(@syms) {
                    for @syms -> $s {
                        if ($s<name> // "") eq $t && $s<children> {
                            for $s<children>.Array -> $c {
                                my Str $c-name = $c<name> // "";
                                next unless $c-name;
                                my Int $c-kind = ($c<kind> // 6).Int;

                                # Exclude private methods, private attributes, and lexical variables
                                next if $c-name.starts-with('!');
                                next if $c-kind == 8; # Field ($!attr)
                                next if $c-kind == 13; # Variable ($lexical)
                                next if $c-name ~~ /^ <[\$\@\%\&]> \! /;
                                next if $c-name ~~ /^ <[\$\@\%\&]> [^.]/ && $c-kind != 7;

                                # Public attribute accessor (kind == 7): strip sigil + twigil dot
                                if $c-kind == 7 || $c-name ~~ /^ <[\$\@\%\&]> \. / {
                                    $c-name ~~ s/ ^ <[\$\@\%\&]> \. //;
                                }

                                unless %seen{$c-name} {
                                    %seen{$c-name} = True;
                                    @members.push: %(
                                        name   => $c-name,
                                        detail => $c<detail> // "$t method",
                                        type   => $t,
                                        depth  => $current-depth
                                    );
                                }
                            }
                        }
                        find-doc-members($s<children>) if $s<children>;
                    }
                }
                find-doc-members(@doc-syms);
            }
        }

        # 3. Workspace symbol children if available
        if $workspace && $workspace.can('find-symbol') {
            try {
                my @syms = $workspace.find-symbol($t);
                for @syms -> $s {
                    if $s<children> {
                        for $s<children>.Array -> $c {
                            my Str $c-name = $c<name> // "";
                            next unless $c-name;
                            my Int $c-kind = ($c<kind> // 6).Int;

                            # Exclude private methods, private attributes, and lexical variables
                            next if $c-name.starts-with('!');
                            next if $c-kind == 8; # Field ($!attr)
                            next if $c-kind == 13; # Variable ($lexical)
                            next if $c-name ~~ /^ <[\$\@\%\&]> \! /;
                            next if $c-name ~~ /^ <[\$\@\%\&]> [^.]/ && $c-kind != 7;

                            # Public attribute accessor (kind == 7): strip sigil + twigil dot
                            if $c-kind == 7 || $c-name ~~ /^ <[\$\@\%\&]> \. / {
                                $c-name ~~ s/ ^ <[\$\@\%\&]> \. //;
                            }

                            unless %seen{$c-name} {
                                %seen{$c-name} = True;
                                @members.push: %(
                                    name   => $c-name,
                                    detail => $c<detail> // "$t method",
                                    type   => $t,
                                    depth  => $current-depth
                                );
                            }
                        }
                    }
                }
            }
        }
    }

    return @members;
}

#| Phase 4: Item Assembly
our proto sub assemble-items(|) is export {*}
multi sub assemble-items(CompletionContext $ctx, Str $type-name, Positional $members, Any $workspace = Nil --> Positional) {
    assemble-items(Nil, $ctx, $type-name, $members, $workspace, -1, -1)
}
multi sub assemble-items(Any $doc, CompletionContext $ctx, Str $type-name, Positional $members, Any $workspace = Nil, Int $line = -1, Int $character = -1 --> Positional) {
    my @items;
    my Str $prefix = $ctx.prefix;
    my %seen;

    my Int $general-start-char = ($line >= 0 && $character >= 0) ?? max(0, $character - utf16-length($prefix)) !! -1;
    my Int $general-end-char = $character;
    if $doc && $line >= 0 && $character >= 0 {
        if $line < $doc.lines-count {
            my Str $line-text = $doc.line-text($line);
            my Int $grapheme-idx = max(0, min($doc.position-to-offset($line, $character) - $doc.line-offsets[$line], $line-text.chars));
            if $grapheme-idx < $line-text.chars {
                my Str $rest = $line-text.substr($grapheme-idx);
                if $rest ~~ /^ (<[\w\:\-]>+)/ {
                    $general-end-char += utf16-length($0.Str);
                }
            }
        }
    }

    if $ctx.is-use-stmt {
        if $workspace && $workspace.can('get-module-completions') {
            my @mods = $workspace.get-module-completions($prefix);
            my Int $start-char = $character;

            for @mods -> $mod {
                my Str $full-name = $mod<name> // "";
                my Str $rel-name = $full-name.starts-with($prefix)
                ?? $full-name.substr($prefix.chars)
                !! $full-name;

                my %item = %(
                    label      => $rel-name ne "" ?? $rel-name !! $full-name,
                    insertText => $rel-name,
                    filterText => $rel-name,
                    kind       => 9, # LSP CompletionItemKind.Module
                    detail     => "module ($full-name)",
                    sortText   => "0_" ~ $full-name
                );
                if $start-char >= 0 {
                    %item<textEdit> = %(
                        range => %(
                            start => %( line => $line, character => $start-char ),
                            end   => %( line => $line, character => $general-end-char )
                        ),
                        newText => $rel-name
                    );
                }
                @items.push: %item;
            }
        }
    } elsif $ctx.is-named-arg {
        my ($invocant, $func-name, $active-param) = get-signature-context($doc // "", $line, $character);
        if $func-name {
            my Str $sig-detail = "";
            if $doc {
                my @doc-syms = extract-symbols($doc);
                sub find-func-sym(@list) {
                    for @list -> $s {
                        if ($s<name> // "") eq $func-name && $s<detail> {
                            $sig-detail = $s<detail>;
                            return;
                        }
                        find-func-sym($s<children>) if $s<children>;
                    }
                }
                find-func-sym(@doc-syms);
            }
            if !$sig-detail && $workspace && $workspace.can('find-symbol') {
                try {
                    my @globals = $workspace.find-symbol($func-name);
                    my $target = @globals.first({ ($_<kind> // 0) == 6 || ($_<kind> // 0) == 12 });
                    $sig-detail = $target<detail> // "" if $target;
                }
            }
            if $sig-detail {
                my @named-params;
                if $sig-detail ~~ / '(' (.*) ')' / {
                    my $sig-args = $0.Str;
                    for $sig-args.split(',') -> $p {
                        my $p-trim = $p.trim;
                        if $p-trim ~~ / ^ \: \s* <[\$\@\%\&]>? ( <[a..zA..Z0..9_\-]>+ ) / {
                            @named-params.push(~$0);
                        }
                    }
                }
                for @named-params -> $name {
                    if matches-prefix($name, $prefix) {
                        @items.push: %(
                            label    => $name,
                            kind     => 6, # Variable / Parameter
                            detail   => "Named parameter",
                            sortText => "0_$name",
                            documentation => "Named parameter `$name` of `$func-name`."
                        );
                    }
                }
            }
        }
    } elsif $ctx.is-method-call {
        if $ctx.is-meta-call {
            # 1. Standard core HOW metaclass methods
            for %CORE-META-METHODS.kv -> Str $m-name, Str $doc-text {
                if matches-prefix($m-name, $prefix) && !%seen{$m-name} {
                    %seen{$m-name} = True;
                    @items.push: %(
                        label         => $m-name,
                        kind          => 2, # LSP CompletionItemKind.Method
                        detail        => "metaclass method",
                        documentation => $doc-text,
                        sortText      => "00_$m-name"
                    );
                }
            }

            # 2. User-defined metaclass methods (starting with '^')
            for $members.Array -> $m {
                my Str $m-name = $m<name>;
                if $m-name.starts-with('^') {
                    my Str $clean-name = $m-name.substr(1);
                    if matches-prefix($clean-name, $prefix) && !%seen{$clean-name} {
                        %seen{$clean-name} = True;
                        @items.push: %(
                            label    => $clean-name,
                            kind     => 2, # LSP CompletionItemKind.Method
                            detail   => "user-defined metaclass method",
                            sortText => "01_$clean-name"
                        );
                    }
                }
            }
        } else {
            # Regular method call (.)
            for $members.Array -> $m {
                my Str $m-name = $m<name>;
                next if $m-name.starts-with('^'); # Skip metaclass methods on regular call
                if matches-prefix($m-name, $prefix) {
                    my Str $sort = sprintf("%02d_%s", $m<depth>, $m-name);
                    unless %seen{$m-name} {
                        %seen{$m-name} = True;
                        my %item = %(
                            label    => $m-name,
                            kind     => 2, # LSP CompletionItemKind.Method
                            detail   => $m<detail>,
                            sortText => $sort
                        );
                        %item<data> = %( type => $m<type> ) if $m<type>;
                        @items.push: %item;
                    }
                }
            }
        }
    } else {
        # Document symbols
        if $doc {
            my @doc-syms = extract-symbols($doc);
            sub add-doc-symbols(@list, Str $parent-name = "", Bool $in-routine = False, Hash $routine-range = hash()) {
                for @list -> $s {
                    my Str $s-name = $s<name> // "";
                    next unless $s-name;
                    my Int $kind = ($s<kind> // 1).Int;

                    if $in-routine && ($kind == 13 || $kind == 8 || $kind == 7) {
                        # Only include routine-local variables when cursor is inside routine
                        if $routine-range && $routine-range<start> && $routine-range<end> {
                            my Int $sl = +$routine-range<start><line>;
                            my Int $sc = +$routine-range<start><character>;
                            my Int $el = +$routine-range<end><line>;
                            my Int $ec = +$routine-range<end><character>;
                            unless ($sl < $line || ($sl == $line && $sc <= $character))
                            && ($line < $el || ($line == $el && $character < $ec)) {
                                next;
                            }
                        }
                    }

                    my Bool $is-pkg = $kind == 5 || $kind == 2 || $kind == 11;
                    my Str $full-name;
                    if $parent-name ne "" && ($is-pkg || $kind == 6 || $kind == 12) {
                        $full-name = "$parent-name\::$s-name";
                    } else {
                        $full-name = $s-name;
                    }

                    my Bool $match = False;
                    if $prefix.contains('::') {
                        $match = matches-prefix($full-name, $prefix);
                    } else {
                        $match = matches-prefix($s-name, $prefix) || matches-prefix($full-name, $prefix);
                    }
                    if $match && !%seen{$full-name} {
                        %seen{$full-name} = True;
                        my Int $lsp-kind = %COMPLETION-KIND{$kind} // 1;
                        my %item = %(
                            label    => $s-name,
                            kind     => $lsp-kind,
                            detail   => $s<detail> // "Document symbol",
                            sortText => "2_$s-name"
                        );
                        if $prefix.contains('::') || ($parent-name ne "" && $is-pkg) {
                            %item<filterText> = $full-name;
                            %item<insertText> = $full-name;
                        }
                        @items.push: %item;
                    }
                    if $s<children> {
                        my Str $next-parent = $is-pkg ?? ($parent-name eq "" ?? $s-name !! "$parent-name\::$s-name") !! $parent-name;
                        my Bool $next-in-routine = $in-routine || $kind == 6 || $kind == 12;
                        my Hash $next-range = ($kind == 6 || $kind == 12) ?? ($s<range> // hash()) !! $routine-range;
                        add-doc-symbols($s<children>, $next-parent, $next-in-routine, $next-range);
                    }
                }
            }
            add-doc-symbols(@doc-syms, "");
        }

        # Keywords if in keyword position
        if $ctx.is-keyword-pos {
            for @KEYWORDS -> Str $kw {
                if matches-prefix($kw, $prefix) && !%seen{$kw} {
                    %seen{$kw} = True;
                    @items.push: %(
                        label    => $kw,
                        kind     => 14, # LSP CompletionItemKind.Keyword
                        detail   => "keyword",
                        sortText => "4_$kw"
                    );
                }
            }
        }

        # Workspace symbols
        if $workspace {
            if $prefix.chars >= 1 && $workspace.can('query-symbols') {
                try {
                    my @qs = $workspace.query-symbols($prefix, :prefix-only);
                    for @qs -> $gs {
                        my Str $gs-name = $gs<name> // "";
                        next unless $gs-name;
                        my Str $container = $gs<containerName> // "";
                        my Str $full-name = $container ne "" ?? "$container\::$gs-name" !! $gs-name;
                        my Bool $match = False;
                        if $prefix.contains('::') {
                            $match = matches-prefix($full-name, $prefix);
                        } else {
                            $match = matches-prefix($gs-name, $prefix) || matches-prefix($full-name, $prefix);
                        }
                        if $match && !%seen{$full-name} {
                            %seen{$full-name} = True;
                            my %item = %(
                                label    => $gs-name,
                                kind     => %COMPLETION-KIND{$gs<kind> // 0} // 1,
                                detail   => $gs<detail> // "Global symbol",
                                sortText => "6_$gs-name"
                            );
                            if $prefix.contains('::') || $container ne "" {
                                %item<filterText> = $full-name;
                                %item<insertText> = $full-name;
                            }
                            @items.push: %item;
                        }
                    }
                }
            }
        }
    }

    if $general-start-char >= 0 {
        for @items <-> $item {
            unless $item<textEdit>:exists {
                my Str $insert = $item<insertText> // $item<label>;
                $item<textEdit> = %(
                    range => %(
                        start => %( line => $line, character => $general-start-char ),
                        end   => %( line => $line, character => $general-end-char )
                    ),
                    newText => $insert
                );
            }
        }
    }

    return @items;
}

#| Main orchestrator entry point
our sub get-type-aware-completions(Any $doc, Int $line, Int $character, Any $workspace = Nil --> Positional) is export {
    my CompletionContext $ctx = $doc ~~ Document
    ?? analyze-context($doc, $line, $character)
    !! analyze-context($doc.text // "", $line, $character);
    my Str $type-name = "";
    my @members;

    if $ctx.is-method-call {
        $type-name = resolve-type($ctx.receiver, $doc, $line, $character, $workspace);
        @members = resolve-members($type-name, $workspace, $doc);
    }

    return assemble-items($doc, $ctx, $type-name, @members, $workspace, $line, $character);
}
