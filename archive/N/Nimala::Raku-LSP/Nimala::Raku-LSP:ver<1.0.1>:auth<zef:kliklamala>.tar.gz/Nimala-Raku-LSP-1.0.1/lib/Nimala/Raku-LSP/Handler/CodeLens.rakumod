use v6.d;
unit role Nimala::Raku-LSP::Handler::CodeLens;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Workspace;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Handler::Types;
#| Handle textDocument/codeLens request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_codeLens>
method textDocument-codeLens(:%textDocument, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Any @lenses;

    # 1. File-level test suite lens for .rakutest, .t and .t6 files
    if $uri.ends-with('.rakutest') || $uri.ends-with('.t') || $uri.ends-with('.t6') {
        @lenses.push: hash(
            range => hash(
                start => hash( line => 0, character => 0 ),
                end   => hash( line => 0, character => 0 )
            ),
            data => hash(
                uri      => $uri,
                kind     => 'test',
                title    => '▶ Run All Tests',
                testName => 'all',
                line     => 0
            )
        );
        @lenses.push: hash(
            range => hash(
                start => hash( line => 0, character => 0 ),
                end   => hash( line => 0, character => 0 )
            ),
            data => hash(
                uri      => $uri,
                kind     => 'debug-test',
                title    => '▶ Debug All Tests',
                testName => 'all',
                line     => 0
            )
        );
    }

    # 2. Extract AST and collect symbol declaration lenses
    my $ast = parse-document($doc);
    if $ast {
        self!collect-lenses-from-ast($ast, $uri, @lenses, :$doc);
    }

    # 3. Collect subtest block lenses from document text
    self!collect-subtest-lenses($doc, $uri, @lenses);

    return @lenses.map({ %$_ }).Array;
}

#| Handle codeLens/resolve request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeLens_resolve>
method codeLens-resolve(:$_id, :$_token, *%lens --> Hash) {
    my %codeLens = (%lens<codeLens>:exists && %lens<codeLens>) ?? %lens<codeLens> !! %lens;
    %codeLens<_token>:delete;
    %codeLens<_id>:delete;
    my %data = %codeLens<data> // %();
    my Str $kind = %data<kind> // '';

    given $kind {
        when 'reference' {
            self!resolve-reference-lens(%codeLens, %data);
        }
        when 'implementation' {
            self!resolve-implementation-lens(%codeLens, %data);
        }
        when 'test' {
            self!resolve-test-lens(%codeLens, %data);
        }
        when 'debug-test' {
            self!resolve-debug-test-lens(%codeLens, %data);
        }
        default {
            # Unknown kind, leave command unchanged
        }
    }

    return %codeLens;
}

# Helper to recursively traverse AST and generate CodeLens items
method !collect-lenses-from-ast(
    $node,
    Str $uri,
    @lenses,
    Str $enclosing-type = "",
    Str $enclosing-kind = "",
    Int $parent-decl-line?,
    Document :$doc
    --> Nil) {
    return unless $node && $node.children;

    for $node.children -> $c {
        next unless $c.defined && $c.type ne 'Error' && $c.type ne 'Usage' && $c.type ne 'Expression';

        my $name = $c.name // "";
        my $type = $c.type // "";
        my Hash $range = $c.range // hash(
            start => hash( line => 0, character => 0 ),
            end   => hash( line => 0, character => 0 )
        );
        my Int $node-line = +$range<start><line>;

        my Int $ident-col = +$range<start><character>;
        if $doc.defined && $node-line < $doc.lines-count {
            my Str $lt = $doc.line-text($node-line);
            my $m-idx = $lt.index($name, +$range<start><character>);
            $m-idx //= $lt.index($name);
            if $m-idx.defined {
                $ident-col = $doc.utf16-column($node-line, $m-idx);
            }
        }

        if $type eq 'class' || $type eq 'role' || $type eq 'package' || $type eq 'grammar' || $type eq 'module' {
            if $name && $name ne "<unnamed>" {
                # Reference lens
                @lenses.push: hash(
                    range => $range,
                    data  => hash(
                        uri        => $uri,
                        kind       => 'reference',
                        symbol     => $name,
                        symbolKind => $type,
                        line       => $node-line,
                        character  => $ident-col
                    )
                );

                # Implementation lens for roles and classes
                if $type eq 'role' || $type eq 'class' {
                    @lenses.push: hash(
                        range => $range,
                        data  => hash(
                            uri        => $uri,
                            kind       => 'implementation',
                            symbol     => $name,
                            symbolKind => $type,
                            line       => $node-line,
                            character  => $ident-col
                        )
                    );
                }
            }

            # Recurse with current class/role context
            self!collect-lenses-from-ast($c, $uri, @lenses, $name, $type, $node-line, :$doc);
        }
        elsif $type ~~ / 'method' | 'submethod' | 'sub' | 'rule' | 'token' | 'regex' / {
            if $name && $name ne "<unnamed>" {
                # Reference lens
                @lenses.push: hash(
                    range => $range,
                    data  => hash(
                        uri           => $uri,
                        kind          => 'reference',
                        symbol        => $name,
                        symbolKind    => $type,
                        enclosingType => $enclosing-type,
                        line          => $node-line,
                        character     => $ident-col
                    )
                );

                # Method implementation lens if inside a role
                if $enclosing-kind eq 'role' && ($type eq 'method' || $type eq 'submethod') {
                    @lenses.push: hash(
                        range => $range,
                        data  => hash(
                            uri           => $uri,
                            kind          => 'implementation',
                            symbol        => $name,
                            symbolKind    => 'Method',
                            enclosingType => $enclosing-type,
                            line          => $node-line,
                            character     => $ident-col
                        )
                    );
                }
            }

            # Recurse into subroutine/method block for local variable declarations
            self!collect-lenses-from-ast($c, $uri, @lenses, $enclosing-type, $enclosing-kind, $node-line, :$doc);
        }
        elsif $type eq 'Field' || $type eq 'Property' {
            if $name && $name ne "<unnamed>" {
                @lenses.push: hash(
                    range => $range,
                    data  => hash(
                        uri           => $uri,
                        kind          => 'reference',
                        symbol        => $name,
                        symbolKind    => 'Field',
                        enclosingType => $enclosing-type,
                        line          => $node-line,
                        character     => $ident-col
                    )
                );
            }
        }
        elsif $type eq 'Variable' {
            # Skip signature parameters declared on the routine's declaration header line
            if $parent-decl-line.defined && $parent-decl-line >= 0 && $node-line == $parent-decl-line {
                next;
            }

            if $name && $name ne "<unnamed>" && $name ~~ /^ <[\$\@\%\&]> / {
                @lenses.push: hash(
                    range => $range,
                    data  => hash(
                        uri        => $uri,
                        kind       => 'reference',
                        symbol     => $name,
                        symbolKind => 'Variable',
                        line       => $node-line,
                        character  => $ident-col
                    )
                );
            }
        }
        elsif $type eq 'Block' || $type eq 'StatementList' {
            self!collect-lenses-from-ast($c, $uri, @lenses, $enclosing-type, $enclosing-kind, $parent-decl-line, :$doc);
        }
    }
}

# Helper to scan for subtest calls in document text
method !collect-subtest-lenses(Document $doc, Str $uri, @lenses --> Nil) {
    return unless $doc.text;

    my Int $line-count = $doc.lines-count;
    for 0..^$line-count -> Int $i {
        my Str $line = $doc.line-text($i);
        if $line ~~ / ^ \s* subtest \s+ [ '(' \s* ]? [ \' (<-[\'\n]>+) \' | \" (<-[\"\n]>+) \" ] / {
            my Str $test-name = ($0 // $1).Str.trim;
            @lenses.push: hash(
                range => hash(
                    start => hash( line => $i, character => 0 ),
                    end   => hash( line => $i, character => 0 )
                ),
                data => hash(
                    uri      => $uri,
                    kind     => 'test',
                    title    => "▶ Run Subtest",
                    testName => $test-name,
                    line     => $i
                )
            );
            @lenses.push: hash(
                range => hash(
                    start => hash( line => $i, character => 0 ),
                    end   => hash( line => $i, character => 0 )
                ),
                data => hash(
                    uri      => $uri,
                    kind     => 'debug-test',
                    title    => "▶ Debug Subtest",
                    testName => $test-name,
                    line     => $i
                )
            );
        }
    }
}

# Resolver for reference-type CodeLens items
method !resolve-reference-lens(%codeLens, %data --> Nil) {
    my Str $name = %data<symbol> // '';
    return unless $name;
    my Str $uri = %data<uri> // '';
    my Str $sym-kind = %data<symbolKind> // '';

    my Int $line = +(%data<line> // %codeLens<range><start><line> // -1);
    my Int $character = +(%data<character> // %codeLens<range><start><character> // -1);

    my Bool $lexical-only = ($sym-kind eq 'Variable');
    my Any @locations = self.index
    ?? self.index.find-references-everywhere(
        $name,
        doc-store => self.doc-store,
        :!include-declaration,
        :$lexical-only,
        doc-uri => $uri,
        :$line,
        :$character
    ).Array
    !! [].Array;

    my Int $count = @locations.elems;
    my Str $title = do {
        if $sym-kind eq 'Variable' || $sym-kind eq 'Field' {
            $count == 1 ?? "$name: 1 reference" !! "$name: $count references";
        } else {
            $count == 1 ?? "1 reference" !! "$count references";
        }
    };

    my Hash $pos = hash(
        line      => +(%data<line> // %codeLens<range><start><line> // 0),
        character => +(%data<character> // %codeLens<range><start><character> // 0)
    );

    if $count > 0 {
        %codeLens<command> = hash(
            title     => $title,
            command   => 'nimala.showReferences',
            arguments => [ $uri, $pos, @locations.Array ]
        );
    } else {
        %codeLens<command> = hash(
            title     => $title,
            command   => '',
            arguments => [].Array
        );
    }
}

# Resolver for implementation-type CodeLens items
method !resolve-implementation-lens(%codeLens, %data --> Nil) {
    my Str $name = %data<symbol> // '';
    return unless $name;
    my Str $uri = %data<uri> // '';
    my Str $sym-kind = %data<symbolKind> // '';
    my Str $enclosing-type = %data<enclosingType> // '';

    my Any @locations;

    if ($sym-kind eq 'role' || $sym-kind eq 'class') {
        my %seen-locs;
        if self.index {
            for self.index.subtypes-of($name) -> ($u, $s) {
                my Int $sl = +($s<range><start><line> // 0);
                my Int $sc = +($s<range><start><character> // 0);
                my Int $el = +($s<range><end><line> // $sl);
                my Int $ec = +($s<range><end><character> // $sc);
                my Str $key = "$u:$sl:$sc";
                next if %seen-locs{$key}++;
                @locations.push: hash(
                    uri   => $u,
                    range => hash(
                        start => hash( line => $sl, character => $sc ),
                        end   => hash( line => $el, character => $ec )
                    )
                );
            }
        }
    }
    elsif ($sym-kind eq 'Method' || $sym-kind eq 'method') && $enclosing-type {
        my %seen-locs;
        if self.index {
            for self.index.subtypes-of($enclosing-type) -> ($u, $s) {
                if $s<children> {
                    for @($s<children>) -> Any $c {
                        if $c<kind> == 6 && $c<name> eq $name {
                            my Int $sl = +($c<range><start><line> // 0);
                            my Int $sc = +($c<range><start><character> // 0);
                            my Int $el = +($c<range><end><line> // $sl);
                            my Int $ec = +($c<range><end><character> // $sc);
                            my Str $key = "$u:$sl:$sc";
                            next if %seen-locs{$key}++;
                            @locations.push: hash(
                                uri   => $u,
                                range => hash(
                                    start => hash( line => $sl, character => $sc ),
                                    end   => hash( line => $el, character => $ec )
                                )
                            );
                        }
                    }
                }
            }
        }
    }

    my Int $count = @locations.elems;
    my Str $title = do {
        if $sym-kind eq 'class' {
            $count == 1 ?? "1 subclass" !! "$count subclasses";
        } else {
            $count == 1 ?? "1 implementation" !! "$count implementations";
        }
    };

    my Hash $pos = hash(
        line      => +(%data<line> // %codeLens<range><start><line> // 0),
        character => +(%data<character> // %codeLens<range><start><character> // 0)
    );

    if $count > 0 {
        %codeLens<command> = hash(
            title     => $title,
            command   => 'nimala.showReferences',
            arguments => [ $uri, $pos, @locations.Array ]
        );
    } else {
        %codeLens<command> = hash(
            title     => $title,
            command   => '',
            arguments => [].Array
        );
    }
}

# Resolver for test-type CodeLens items
method !resolve-test-lens(%codeLens, %data --> Nil) {
    my Str $uri = %data<uri> // '';
    my Str $title = %data<title> // '▶ Run Test';
    my Str $test-name = %data<testName> // '';
    my Int $line = +(%data<line> // %codeLens<range><start><line> // 0);

    %codeLens<command> = hash(
        title     => $title,
        command   => 'nimala.runTest',
        arguments => [ {
                uri      => $uri,
                line     => $line,
                testName => $test-name
            }, ]
    );
}

# Resolver for debug-test-type CodeLens items
method !resolve-debug-test-lens(%codeLens, %data --> Nil) {
    my Str $uri = %data<uri> // '';
    my Str $title = %data<title> // '▶ Debug Test';
    my Str $test-name = %data<testName> // '';
    my Int $line = +(%data<line> // %codeLens<range><start><line> // 0);

    %codeLens<command> = hash(
        title     => $title,
        command   => 'nimala.debugTest',
        arguments => [ {
                uri      => $uri,
                line     => $line,
                testName => $test-name
            }, ]
    );
}
