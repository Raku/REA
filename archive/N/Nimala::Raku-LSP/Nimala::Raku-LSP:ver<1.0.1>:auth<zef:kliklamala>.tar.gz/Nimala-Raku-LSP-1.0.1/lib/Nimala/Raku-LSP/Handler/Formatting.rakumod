use v6.d;
unit role Nimala::Raku-LSP::Handler::Formatting;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Handler::Types;

#| Helper to compute minimal line formatting edits.
method !compute-formatting-edits(
    Document $doc,
    :%options,
    Int :$range-start = 0,
    Int :$range-end   = Int
    --> Array
) {
    return [].Array unless $doc && $doc.text.chars > 0;

    my Int  $tab-size        = %options<tabSize>        // 4;
    my Bool $insert-spaces   = %options<insertSpaces>   // True;
    my Str  $indent-str      = $insert-spaces ?? (" " x $tab-size) !! "\t";

    my Int $total-lines = $doc.lines-count;
    my Bool $has-trailing-nl = $doc.text.ends-with("\n") || $doc.text.ends-with("\r");
    my Int $lines-to-process = ($has-trailing-nl && $total-lines > 1 && $doc.line-text($total-lines - 1) eq "")
    ?? ($total-lines - 1)
    !! $total-lines;

    return [].Array unless $lines-to-process > 0;

    my Int $effective-range-end = $range-end.defined ?? min($range-end, $lines-to-process - 1) !! ($lines-to-process - 1);
    my Int $effective-range-start = max(0, $range-start // 0);

    my Int $current-depth = 0;
    my Str $heredoc-delim = "";
    my Str $pod-block = "";
    my Bool $in-single = False;
    my Bool $in-double = False;
    my @edits;

    for 0 ..^ $lines-to-process -> Int $i {
        my Str $line = $doc.line-text($i);
        my Str $formatted-line;

        # 1. Heredoc body handling: preserve verbatim
        if $heredoc-delim ne "" {
            my Str $trimmed = $line.trim;
            if $trimmed eq $heredoc-delim {
                $formatted-line = $line;
                $heredoc-delim = "";
            } else {
                $formatted-line = $line;
            }
        }
        # 2. Pod block handling: preserve verbatim
        elsif $pod-block ne "" {
            my Str $trimmed = $line.trim;
            if $trimmed ~~ /^ '=end' \s+ $pod-block / {
                $formatted-line = $line;
                $pod-block = "";
            } else {
                $formatted-line = $line;
            }
        } else {
            # 3. If line started inside a multi-line string, preserve indentation verbatim
            my Bool $started-in-string = $in-single || $in-double;
            my Str $trimmed = $line.trim;

            # Check for Pod block start
            if !$started-in-string && $trimmed ~~ /^ '=begin' \s+ (\w+) / {
                $pod-block = ~$0;
                $formatted-line = $line;
            }
            # Check for top-level Pod directives (e.g. =head1, =item, =para, =for, =comment)
            elsif !$started-in-string && $trimmed ~~ /^ '=' \w/ {
                $formatted-line = $line;
            }
            # Check for Heredoc start in line
            else {
                my %scan = scan-line-lexical($line, :$in-single, :$in-double);

                my Str $code-part = %scan<comment-from> >= 0
                ?? $line.substr(0, %scan<comment-from>).trim
                !! $trimmed;

                if !$started-in-string && $code-part ~~ / ':to' [ ':' \w+ ]* \s* <[ / ' " [ ( < \\ | ]>? (\w+) / {
                    $heredoc-delim = ~$0;
                }

                my Int $opens = %scan<opens>;
                my Int $closes = %scan<closes>;

                $in-single = %scan<in-single>;
                $in-double = %scan<in-double>;

                if $started-in-string {
                    $formatted-line = $line;
                } else {
                    my Int $line-depth = $current-depth;
                    if $trimmed ~~ /^ (<[ \} \] \) ]>+) / {
                        my Int $lead-closes = $0.chars;
                        $line-depth = max(0, $line-depth - $lead-closes);
                    } elsif $trimmed ~~ /^ \. \w / {
                        $line-depth++;
                    }

                    if $trimmed eq "" {
                        $formatted-line = "";
                    } else {
                        $formatted-line = ($indent-str x $line-depth) ~ $trimmed;
                    }
                }

                $current-depth += ($opens - $closes);
                $current-depth = 0 if $current-depth < 0;
            }
        }

        # Check if line should produce a minimal TextEdit
        if $i >= $effective-range-start && $i <= $effective-range-end {
            if $line ne $formatted-line {
                @edits.push: hash(
                    range => hash(
                        start => hash( line => $i, character => 0 ),
                        end   => hash( line => $i, character => utf16-length($line) )
                    ),
                    newText => $formatted-line
                );
            }
        }
    }

    return @edits.Array;
}

#| Handle textDocument/formatting request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_formatting>
method textDocument-formatting(:%textDocument, :%options, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get-or-load($uri);
    return [].Array unless $doc;

    return self!compute-formatting-edits($doc, :%options);
}

#| Handle textDocument/rangeFormatting request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_rangeFormatting>
method textDocument-rangeFormatting(:%textDocument, :%range, :%options, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get-or-load($uri);
    return [].Array unless $doc;

    my Int $range-start = %range<start><line> // 0;
    my Int $range-end   = %range<end><line>   // 0;

    return self!compute-formatting-edits($doc, :%options, :$range-start, :$range-end);
}

#| Handle textDocument/onTypeFormatting request: re-indent the affected line only (`}`/`;`: the line at
#| `position`, newline: the completed line before it), touching nothing but its leading whitespace.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_onTypeFormatting>
method textDocument-onTypeFormatting(:%textDocument, :%position, Str :$ch, :%options, *%other --> Array) {
    my Str $uri = %textDocument<uri> // '';
    my Document $doc = self.doc-store.get-or-load($uri);
    return [].Array unless $doc;

    my Int $line = (%position<line> // 0).Int;
    $line-- if ($ch // '') eq "\n" | "\r\n";
    return [].Array if $line < 0 || $line >= $doc.lines-count;

    my @edits = self!compute-formatting-edits($doc, :%options, range-start => $line, range-end => $line);
    return [].Array unless @edits;

    my Str $formatted = @edits[0]<newText>;
    return [].Array if $formatted.trim eq '';  # blank lines keep their whitespace

    my Str $old-lead = ($doc.line-text($line) ~~ /^ \h* /).Str;
    my Str $new-lead = ($formatted ~~ /^ \h* /).Str;
    return [].Array if $old-lead eq $new-lead;

    return [ hash(
            range => hash(
                start => hash( line => $line, character => 0 ),
                end   => hash( line => $line, character => $old-lead.chars )
            ),
            newText => $new-lead
        ), ].Array;
}
