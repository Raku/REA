#| Base role for LSP Handlers providing explicit core dependencies and cancellation token registries.
unit role Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Workspace;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::SymbolDB;

#| The current LSP state of the server
method state(--> LSPState) is rw { ... }

#| Global document store for open files
method doc-store(--> DocumentStore) { ... }

#| The LSP client to send notifications/requests
method client(--> Nimala::Raku-LSP::Client) { ... }

#| The project symbol index
method index(--> ProjectIndex) { ... }

#| The latest document version hash
method latest-version(--> Hash) is rw { ... }

#| Active workspace folders
method workspace-folders(--> Array) is rw { ... }

#| The persistent project symbol database
method db(--> Nimala::Raku-LSP::SymbolDB) is rw { ... }
method cache(--> Nimala::Raku-LSP::SymbolDB) is rw { ... }

#| Client capabilities advertised during initialize
method client-capabilities(--> Hash) is rw { ... }

#| Registers a cancellation token for a request ID
method register-request-token($id, CancellationToken $token --> Nil) { ... }

#| Cancels a request token by ID
method cancel-request-token($id --> Bool) { ... }

#| Unregisters a request token
method unregister-request-token($id --> Nil) { ... }

#| Gets a request token by ID
method get-request-token($id --> CancellationToken) { ... }

#| Registers a progress cancellation token for a progress token
method register-progress-token($token-id, CancellationToken $token --> Nil) { ... }

#| Cancels a progress token by ID
method cancel-progress-token($token-id --> Bool) { ... }

#| Unregisters a progress token
method unregister-progress-token($token-id --> Nil) { ... }

#| Gets a progress token by ID
method get-progress-token($token-id --> CancellationToken) { ... }
