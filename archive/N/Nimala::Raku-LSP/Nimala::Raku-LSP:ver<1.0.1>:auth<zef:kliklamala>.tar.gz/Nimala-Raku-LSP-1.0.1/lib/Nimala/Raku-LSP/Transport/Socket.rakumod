use v6.d;
#| Asynchronous TCP Socket transport for Language Server Protocol (LSP).
unit module Nimala::Raku-LSP::Transport::Socket;

use Nimala::Raku-LSP::Dispatcher;
use Nimala::Raku-LSP::Transport::Framing;
use Nimala::Raku-LSP::Handler;
use Nimala::Raku-LSP::Handler::Types;

#| Thread-safe output handle wrapper around an IO::Socket::Async connection.
class SocketOutputHandle is IO::Handle {
    has IO::Socket::Async $.socket is required;
    has Lock $!lock = Lock.new;

    method write(Blob $b --> Nil) {
        $!lock.protect: {
            try {
                await $!socket.write($b);
                CATCH { default { } }
            }
        }
    }

    method flush(--> Nil) { }
}

#| Process a single LSP TCP client connection until termination or disconnection.
our sub handle-tcp-connection(
    IO::Socket::Async $conn,
    Nimala::Raku-LSP::Handler :$handler
    --> Promise) is export {
    my $socket-out = SocketOutputHandle.new(socket => $conn);
    my $lsp-handler = $handler // Nimala::Raku-LSP::Handler.new(out => $socket-out);
    my $completed = Promise.new;

    my sub write-response(Str $json --> Nil) {
        $socket-out.write(lsp-frame-message($json));
    }

    my Nimala::Raku-LSP::Dispatcher $dispatcher .= new(
        handler => $lsp-handler,
        :&write-response,
        on-exit => -> Int $code {
            try { $conn.close; CATCH { default { } } }
            $completed.keep(True) if $completed.status == Planned;
        }
    );

    my $supply = lsp-parse-stream($conn.Supply(:bin));

    $supply.tap(
        -> Str $json-request {
            $dispatcher.dispatch($json-request);
        },
        done => {
            $dispatcher.await-in-flight();
            try { $lsp-handler.shutdown() if $lsp-handler.state != ShuttingDown };
            $dispatcher.stop;
            $completed.keep(True) if $completed.status == Planned;
        },
        quit => -> $err {
            try { $lsp-handler.shutdown() if $lsp-handler.state != ShuttingDown };
            $dispatcher.stop;
            $completed.break($err) if $completed.status == Planned;
        }
    );

    return $completed;
}

#| Starts the TCP LSP listener loop on the specified host and port.
our sub run-tcp-server(
    Str :$host = '127.0.0.1',
    Int :$port = 5007,
    Bool :$single-session = False,
    Promise :$stop-promise = Promise.new
    --> Nil) is export {
    note "[Nimala LSP] Starting TCP server listening on $host:$port";

    react {
        whenever IO::Socket::Async.listen($host, $port) -> $conn {
            note "[Nimala LSP] Client connected from {$conn.peer-host}:{$conn.peer-port}";

            my $conn-promise = handle-tcp-connection($conn);

            whenever $conn-promise {
                note "[Nimala LSP] Client disconnected";
                if $single-session {
                    done;
                }
            }
        }

        whenever $stop-promise {
            done;
        }
    }
}
