use v6.d;
#| Role handling semanticTokens requests (full, range, full/delta).
#| LSP 3.18 compliant with UTF-16 code units and non-overlapping token normalization.
unit role Nimala::Raku-LSP::Handler::SemanticTokens;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Handler::Types;

has %!semantic-cache;
has Int $!semantic-id-counter = 0;
has Lock $!cache-lock = Lock.new;

method evict-semantic-cache(Str $uri --> Nil) {
    $!cache-lock.protect: {
        %!semantic-cache{$uri}:delete;
    }
}

method clear-semantic-cache(--> Nil) {
    $!cache-lock.protect: {
        %!semantic-cache = %();
    }
}

method !get-rakuast-tokens(Document $doc) {
    my ($has-toks, $failed);
    $doc.protect-parse: {
        $has-toks = $doc.raw-tokens.defined;
        $failed = $doc.is-native-failed;
    };
    if $has-toks {
        my @toks;
        $doc.protect-parse: { @toks = @($doc.raw-tokens // []) };
        return @toks;
    }
    if $failed {
        return [];
    }

    my %res = run-native-worker($doc, :extract(['tokens']));
    if %res<tokens>.defined && %res<tokens>.elems > 0 {
        return @(%res<tokens>);
    }
    my @fallback;
    $doc.protect-parse: { @fallback = @($doc.raw-tokens // []) };
    return @fallback;
}

method !supports-multiline(--> Bool) {
    my $td = self.client-capabilities<textDocument>;
    return False unless $td.defined && $td ~~ Associative;
    my $st = $td<semanticTokens>;
    return False unless $st.defined && $st ~~ Associative;
    return ($st<multilineTokenSupport> // False).Bool;
}

method !add-token(@tokens, Document $doc, %pos, %pos-to, $type, $mod --> Nil) {
    my Int $start-line = %pos<line>.Int;
    my Int $end-line   = %pos-to<line>.Int;
    my Int $start-char = %pos<character>.Int;
    my Int $end-char   = %pos-to<character>.Int;

    if $start-line == $end-line {
        my Int $len = max(0, $end-char - $start-char);
        if $len > 0 {
            @tokens.push: {
                line   => $start-line,
                char   => $start-char,
                length => $len,
                type   => $type,
                mod    => $mod
            };
        }
    } elsif ($type == 16 || $type == 17 || $type == 19) {
        if self!supports-multiline {
            my Int $len = utf16-length($doc.text.substr($doc.position-to-offset($start-line, $start-char),
                    $doc.position-to-offset($end-line, $end-char) - $doc.position-to-offset($start-line, $start-char)));
            @tokens.push: {
                line   => $start-line,
                char   => $start-char,
                length => $len,
                type   => $type,
                mod    => $mod
            };
        } else {
            for $start-line .. $end-line -> $l {
                next if $l < 0 || $l >= $doc.lines-count;
                my Str $line-text = $doc.line-text($l);
                my Int $line-len = utf16-length($line-text);
                my Int $c = $l == $start-line ?? $start-char !! 0;
                my Int $len;
                if $l == $end-line {
                    $len = max(0, $end-char - $c);
                } else {
                    $len = max(0, $line-len - $c);
                }
                if $len > 0 {
                    @tokens.push: {
                        line   => $l,
                        char   => $c,
                        length => $len,
                        type   => $type,
                        mod    => $mod
                    };
                }
            }
        }
    }
}

method !get-semantic-tokens-raw(Document $doc) {
    my @tokens;
    my @rakuast-tokens = self!get-rakuast-tokens($doc);
    if @rakuast-tokens.elems > 0 {
        for @rakuast-tokens -> $s {
            my $pos = $doc.position-at($s<from>);
            my $pos-to = $doc.position-at($s<to>);
            self!add-token(@tokens, $doc, $pos, $pos-to, $s<type>, $s<mod>);
        }
    } else {
        # Fallback: native (Tier 2) symbols, else Tier 1 grammar symbols
        require Nimala::Raku-LSP::Analysis::Symbols;
        my @syms = Nimala::Raku-LSP::Analysis::Symbols::flatten-native-tree(extract-native-symbols($doc));
        if !@syms {
            my @basic = extract-symbols($doc);
            sub convert-basic(@list) {
                for @list -> $s {
                    my $kind = do given $s<kind> {
                        when 5 | 2 { 'package_decl' }
                        when 12 | 6 { 'routine_decl' }
                        when 13 | 7 | 8 { 'variable_decl' }
                        default { 'type_decl' }
                    };
                    my $sr = $s<selectionRange> // $s<range>;
                    my $from = $doc.position-to-offset($sr<start><line>, $sr<start><character>);
                    my $to = $doc.position-to-offset($sr<end><line>, $sr<end><character>);
                    if $to > $from {
                        @syms.push: { name => $s<name>, kind => $kind, from => $from, to => $to };
                    }
                    convert-basic($s<children>) if $s<children>;
                }
            }
            convert-basic(@basic);
        }

        my %defs;
        for @syms -> $s {
            if $s<kind> ~~ /_decl$/ {
                %defs{$s<name>} = $s<kind>;
            }
        }

        # Built-in types
        %defs<Int> = 'type_decl';
        %defs<Str> = 'type_decl';
        %defs<Num> = 'type_decl';
        %defs<Bool> = 'type_decl';
        %defs<Array> = 'type_decl';
        %defs<Hash> = 'type_decl';
        %defs<Mu> = 'type_decl';
        %defs<Any> = 'type_decl';

        for @syms -> $s {
            my $type = -1;
            my $mod = 0;

            if $s<kind> eq 'package_decl' { $type = 1; $mod = 1; }
            elsif $s<kind> eq 'type_decl' { $type = 0; $mod = 1; }
            elsif $s<kind> eq 'routine_decl' { $type = 11; $mod = 1; }
            elsif $s<kind> eq 'variable_decl' { $type = 7; $mod = 1; }
            elsif $s<kind> eq 'variable_usage' { $type = 7; }
            elsif $s<kind> eq 'name_usage' {
                my $target-kind = %defs{$s<name>} // "";
                if $target-kind eq 'package_decl' { $type = 1; }
                elsif $target-kind eq 'routine_decl' { $type = 11; }
                elsif $target-kind eq 'type_decl' { $type = 0; }
                elsif $target-kind eq 'variable_decl' { $type = 7; }
            }

            my $from = $s<name-from> // $s<from>;
            my $to   = $s<name-to> // $s<to>;

            if $type != -1 && $from.defined && $to.defined && $from != $to {
                my $pos = $doc.position-at($from);
                my $pos-to = $doc.position-at($to);
                self!add-token(@tokens, $doc, $pos, $pos-to, $type, $mod);
            }
        }
    }

    # Sort and normalize non-overlapping tokens (K-13)
    my @sorted = @tokens.sort({
            $^a<line> <=> $^b<line>
            || $^a<char> <=> $^b<char>
            || $^b<length> <=> $^a<length>
    });

    my @filtered-tokens;
    my Int $curr-line = -1;
    my Int $curr-end = 0;

    for @sorted -> $t {
        if $t<line> != $curr-line {
            $curr-line = $t<line>;
            $curr-end = 0;
        }
        if $t<char> < $curr-end {
            my Int $overlap = $curr-end - $t<char>;
            if $t<length> <= $overlap {
                next;
            }
            $t<char> = $curr-end;
            $t<length> -= $overlap;
        }
        next if $t<length> <= 0;
        @filtered-tokens.push($t);
        $curr-end = $t<char> + $t<length>;
    }

    return @filtered-tokens;
}

method !encode-tokens(@tokens) {
    my @data;
    my $prev-line = 0;
    my $prev-char = 0;
    for @tokens -> $t {
        my $delta-line = $t<line> - $prev-line;
        my $delta-char = $delta-line == 0 ?? $t<char> - $prev-char !! $t<char>;
        @data.push($delta-line, $delta-char, $t<length>, $t<type>, $t<mod>);
        $prev-line = $t<line>;
        $prev-char = $t<char>;
    }
    return @data;
}

#| Handle textDocument/semanticTokens/full request.
method textDocument-semanticTokens-full(:%textDocument, :$_id, :$_token, *%other --> Hash) {
    my $token = $_token // ($_id.defined ?? self.get-request-token($_id) !! (%other<id>:exists ?? self.get-request-token(%other<id>) !! CancellationToken));
    if $token && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return %( data => [] ) unless $doc;

    my Document $current-doc = self.doc-store.get($uri);
    if $current-doc && $current-doc.version > $doc.version {
        X::LSP::ContentModified.new.throw;
    }

    my @data;
    my Bool $has-cached = False;
    $doc.protect-parse: {
        if $doc.semantic-tokens.defined && $doc.semantic-tokens-version == $doc.version {
            @data = @($doc.semantic-tokens);
            $has-cached = True;
        }
    };
    if !$has-cached {
        my @tokens = self!get-semantic-tokens-raw($doc);
        if $token && $token.is-cancelled {
            X::LSP::Cancelled.new.throw;
        }
        $current-doc = self.doc-store.get($uri);
        if $current-doc && $current-doc.version > $doc.version {
            X::LSP::ContentModified.new.throw;
        }
        @data = self!encode-tokens(@tokens);
        $doc.protect-parse: {
            $doc.semantic-tokens = @data.Array;
            $doc.semantic-tokens-raw = @tokens.Array;
            $doc.semantic-tokens-version = $doc.version;
        };
    }

    my Str $result-id;
    $!cache-lock.protect: {
        $!semantic-id-counter++;
        $result-id = $!semantic-id-counter.Str;
        %!semantic-cache{$uri} = { id => $result-id, data => @data };
    }

    return %( resultId => $result-id, data => @data );
}

#| Handle textDocument/semanticTokens/range request.
method textDocument-semanticTokens-range(:%textDocument, :%range, :$_id, :$_token, *%other --> Hash) {
    my $token = $_token // ($_id.defined ?? self.get-request-token($_id) !! (%other<id>:exists ?? self.get-request-token(%other<id>) !! CancellationToken));
    if $token && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return %( data => [] ) unless $doc;

    my Document $current-doc = self.doc-store.get($uri);
    if $current-doc && $current-doc.version > $doc.version {
        X::LSP::ContentModified.new.throw;
    }

    my @tokens;
    my Bool $has-cached = False;
    $doc.protect-parse: {
        if $doc.semantic-tokens-raw.defined && $doc.semantic-tokens-version == $doc.version {
            @tokens = @($doc.semantic-tokens-raw);
            $has-cached = True;
        }
    };
    if !$has-cached {
        @tokens = self!get-semantic-tokens-raw($doc);
        if $token && $token.is-cancelled {
            X::LSP::Cancelled.new.throw;
        }
        $current-doc = self.doc-store.get($uri);
        if $current-doc && $current-doc.version > $doc.version {
            X::LSP::ContentModified.new.throw;
        }
        my @full-data = self!encode-tokens(@tokens);
        $doc.protect-parse: {
            $doc.semantic-tokens = @full-data.Array;
            $doc.semantic-tokens-raw = @tokens.Array;
            $doc.semantic-tokens-version = $doc.version;
        };
    }

    my Int $s-line = (%range<start><line> // 0).Int;
    my Int $e-line = (%range<end><line> // 0).Int;

    my @filtered = @tokens.grep({ $_<line>.Int >= $s-line && $_<line>.Int <= $e-line });
    my @data = self!encode-tokens(@filtered);

    return %( data => @data );
}

#| Handle textDocument/semanticTokens/full/delta request.
method textDocument-semanticTokens-full-delta(:%textDocument, :$previousResultId, :$_id, :$_token, *%other --> Hash) {
    my $token = $_token // ($_id.defined ?? self.get-request-token($_id) !! (%other<id>:exists ?? self.get-request-token(%other<id>) !! CancellationToken));
    if $token && $token.is-cancelled {
        X::LSP::Cancelled.new.throw;
    }
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return %( data => [] ) unless $doc;

    my Document $current-doc = self.doc-store.get($uri);
    if $current-doc && $current-doc.version > $doc.version {
        X::LSP::ContentModified.new.throw;
    }

    my @new-data;
    my Bool $has-cached = False;
    $doc.protect-parse: {
        if $doc.semantic-tokens.defined && $doc.semantic-tokens-version == $doc.version {
            @new-data = @($doc.semantic-tokens);
            $has-cached = True;
        }
    };
    if !$has-cached {
        my @tokens = self!get-semantic-tokens-raw($doc);
        if $token && $token.is-cancelled {
            X::LSP::Cancelled.new.throw;
        }
        $current-doc = self.doc-store.get($uri);
        if $current-doc && $current-doc.version > $doc.version {
            X::LSP::ContentModified.new.throw;
        }
        @new-data = self!encode-tokens(@tokens);
        $doc.protect-parse: {
            $doc.semantic-tokens = @new-data.Array;
            $doc.semantic-tokens-raw = @tokens.Array;
            $doc.semantic-tokens-version = $doc.version;
        };
    }

    my $cached;
    $!cache-lock.protect: {
        $cached = %!semantic-cache{$uri};
    }

    if $cached && $previousResultId ~~ Str:D && $cached<id> eq $previousResultId {
        my @old-data = @($cached<data>);

        my $prefix-len = 0;
        while $prefix-len < @old-data.elems && $prefix-len < @new-data.elems && @old-data[$prefix-len] == @new-data[$prefix-len] {
            $prefix-len++;
        }
        my $suffix-len = 0;
        while $suffix-len < (@old-data.elems - $prefix-len) && $suffix-len < (@new-data.elems - $prefix-len) && @old-data[@old-data.elems - 1 - $suffix-len] == @new-data[@new-data.elems - 1 - $suffix-len] {
            $suffix-len++;
        }
        my $delete-count = @old-data.elems - $prefix-len - $suffix-len;
        my @insert-data = @new-data[$prefix-len ..^ (@new-data.elems - $suffix-len)];

        my Str $new-id;
        $!cache-lock.protect: {
            $!semantic-id-counter++;
            $new-id = $!semantic-id-counter.Str;
            %!semantic-cache{$uri} = { id => $new-id, data => @new-data };
        }

        if $delete-count == 0 && @insert-data.elems == 0 {
            return %(
                resultId => $new-id,
                edits    => []
            );
        }

        return %(
            resultId => $new-id,
            edits => [
                {
                    start => $prefix-len,
                    deleteCount => $delete-count,
                    data => @insert-data
                },
            ]
        );
    }

    # Fallback to full if cache missing or previousResultId is stale
    my Str $new-id;
    $!cache-lock.protect: {
        $!semantic-id-counter++;
        $new-id = $!semantic-id-counter.Str;
        %!semantic-cache{$uri} = { id => $new-id, data => @new-data };
    }
    return %( resultId => $new-id, data => @new-data );
}
