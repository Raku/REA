use v6.d;
unit role Nimala::Raku-LSP::Handler::Refactoring;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::URI;
use Nimala::Raku-LSP::Handler::CodeActionProviders;
my constant %RENAME-KEYWORDS = Set.new(
    <my our state has constant sub method submethod rule token regex
    class role module package grammar enum if else elsif unless while until
    for loop given when default say print put note return return-rw fail die
    warn take gather try CATCH CONTROL BEGIN CHECK INIT END use need import
    require is does where returns of as True False Nil Bool Int Num Str Any Mu>
);


#| Handle textDocument/prepareRename request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_prepareRename>
method textDocument-prepareRename(:%textDocument, :%position, *%other --> Any) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return Nil unless $doc;

    my Int $line = %position<line>;
    my Int $character = %position<character>;
    return Nil if is-comment-context($doc, $line, $character);

    my $res = get-word-range($doc, $line, $character);
    if $res {
        my Str $word = $res<word>;
        return Nil if %RENAME-KEYWORDS{$word};
        return Nil if $word ~~ /^ \d+ $/;
        return Nil if $word ~~ /^ <[!@#$%^&*()_+\-=\[\]{};':",<.\>/?\\|]>+ $/;
        if $word !~~ /^ <[$@%&]>/ && is-in-comment-or-string($doc, $line, $character) {
            return Nil;
        }
        return {
            range       => $res<range>,
            placeholder => $word
        };
    }
    return Nil;
}

#| Handle textDocument/rename request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_rename>
method textDocument-rename(:%textDocument, :%position, :$newName, *%other --> Hash) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return {} unless $doc;

    my Int $line = %position<line>;
    my Int $character = %position<character>;
    return {} if is-comment-context($doc, $line, $character);

    my $res = get-word-range($doc, $line, $character);
    return {} unless $res;

    my Str $oldName = $res<word>;
    return {} unless $oldName;
    return {} if %RENAME-KEYWORDS{$oldName};
    return {} if $oldName ~~ /^ \d+ $/;
    return {} if $oldName ~~ /^ <[!@#$%^&*()_+\-=\[\]{};':",<.\>/?\\|]>+ $/;
    if $oldName !~~ /^ <[$@%&]>/ && is-in-comment-or-string($doc, $line, $character) {
        return {};
    }

    # Validate newName syntax
    if $oldName ~~ /^ <[$@%&]>/ {
        # Lexical variable rename requires valid sigil and identifier
        return {} unless $newName ~~ /^ <[$@%&]> <[!.*^]>? <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* $/;
    } else {
        # Routine, method, or type rename requires valid identifier
        return {} unless $newName ~~ /^ <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* [ '::' <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ]* $/;
        return {} if %RENAME-KEYWORDS{$newName};
    }

    my %changes;
    if $oldName ~~ /^ <[$@%&]>/ {
        # Lexical variable rename in current document
        my @refs = find-scoped-references($doc, %position<line>, %position<character>);
        my @edits;
        for @refs -> $ref {
            @edits.push: {
                range   => $ref<range>,
                newText => $newName
            };
        }
        %changes{$uri} = @edits if @edits;
    } else {
        # Routine, method, class, role rename across workspace
        my @refs = self.index
        ?? self.index.find-references-everywhere($oldName, doc-store => self.doc-store, :include-declaration).Array
        !! find-references($doc, $oldName, :include-declaration).Array;
        for @refs -> $ref {
            my $ref-uri = $ref<uri>;
            %changes{$ref-uri} //= [];
            %changes{$ref-uri}.push: {
                range   => $ref<range>,
                newText => $newName
            };
        }
    }

    # Deduplicate and reverse-sort edits per URI
    for %changes.keys -> $u {
        my @raw = %changes{$u}.flat;
        my @unique;
        my SetHash $seen = SetHash.new;
        for @raw -> $edit {
            my $r = $edit<range>;
            my Str $key = "{$r<start><line>}:{$r<start><character>}-{$r<end><line>}:{$r<end><character>}";
            unless $seen{$key} {
                $seen{$key} = True;
                @unique.push($edit);
            }
        }
        @unique = @unique.sort({
                $^b<range><start><line> <=> $^a<range><start><line>
                || $^b<range><start><character> <=> $^a<range><start><character>
        });
        %changes{$u} = @unique;
    }

    return { :%changes };
}

sub filter-actions-by-only(@actions, %context --> Array) {
    my $only-param = %context<only>;
    return @actions.map({ %$_ }).Array unless $only-param && $only-param.defined;

    my Str @only = @($only-param).map({ .Str });
    return @actions.map({ %$_ }).Array unless @only.elems > 0;

    my @filtered = @actions.grep(-> $act {
            my Str $kind = ($act<kind> // "").Str;
            so @only.first(-> Str $req {
                    $kind eq $req || $kind.starts-with($req ~ ".")
            })
    });
    return @filtered.map({ %$_ }).Array;
}

sub allows-refactor(%context --> Bool) {
    my $only-param = %context<only>;
    return True unless $only-param && $only-param.defined && @($only-param).elems > 0;
    for @($only-param) -> $req-raw {
        my Str $req = $req-raw.Str;
        return True if $req eq "refactor" || $req.starts-with("refactor.") || "refactor".starts-with($req ~ ".");
    }
    return False;
}

#| Handle textDocument/codeAction request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_codeAction>
method textDocument-codeAction(:%textDocument, :%range, :%context, *%other --> Array) {
    my @actions;
    @actions.push: {
        title   => "Trim trailing whitespace",
        kind    => "quickfix",
        command => {
            title     => "Trim whitespace",
            command   => "nimala.trimWhitespace", arguments => [ %textDocument<uri> ]
        }
    };

    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return filter-actions-by-only(@actions, %context) unless $doc;

    # Quick fixes for diagnostics
    if %context<diagnostics> {
        @actions.append: quickfix-diagnostics($uri, @(%context<diagnostics>));
    }

    # Add use v6.d if not present
    unless $doc.text.contains("use v6") {
        @actions.push: organize-imports-v6d($uri);
    }
    # Refactorings
    if allows-refactor(%context) {
        @actions.append: refactor-extract-actions($uri, $doc, %range);
        @actions.append: refactor-rewrite-actions(self, $uri, $doc, %range);
    }

    return filter-actions-by-only(@actions, %context);
}

#| Handle codeAction/resolve request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeAction_resolve>
method codeAction-resolve(:$_id, :$_token, *%action --> Hash) {
    my %codeAction = (%action<codeAction>:exists && %action<codeAction>) ?? %action<codeAction> !! %action;
    %codeAction<_token>:delete;
    %codeAction<_id>:delete;
    # If edit already populated or no data payload, return as-is (idempotent passthrough)
    return %codeAction if %codeAction<edit>:exists && %codeAction<edit>;

    my %data = %codeAction<data> // %();
    resolve-action(%codeAction, %data);
    return %codeAction;
}

#| Handle workspace/executeCommand request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_executeCommand>
method workspace-executeCommand(:$command, :@arguments, *%other --> Any) {
    if $command eq "nimala.trimWhitespace" {
        my Str $uri = @arguments[0];
        my Document $doc = self.doc-store.get($uri);
        if $doc {
            my @edits;
            for 0 ..^ $doc.lines-count -> Int $i {
                my Str $clean = $doc.line-text($i);
                if $clean ~~ / (\h+) $ / {
                    my Match $m = $0;
                    my Int $ws-start = $doc.utf16-column($i, $m.from);
                    my Int $ws-end = $doc.utf16-column($i, $m.to);
                    @edits.push: {
                        range => {
                            start => { line => $i, character => $ws-start },
                            end   => { line => $i, character => $ws-end }
                        },
                        newText => ""
                    };
                }
            }
            if @edits {
                if ?(self.client-capabilities andthen .<workspace> andthen .<applyEdit>) {
                    self.client.request-async("workspace/applyEdit", {
                            label => "Trim Whitespace",
                            edit => {
                                changes => { $uri => @edits }
                            }
                    });
                }
            }
        }
    } elsif $command eq "nimala.moveSymbol" {
        my Str $uri = @arguments[0];
        my Any $range = @arguments[1];
        my Str $target = @arguments[2] // "auto";
        my Document $doc = self.doc-store.get($uri);

        if $doc {
            my Int $start-line = $range<start><line>;
            my Any @symbols = extract-symbols($doc);
            my Any $type-decl = find-type-decl(@symbols, $start-line);

            if $type-decl {
                my Str $type-name = $type-decl<name>;
                my Str $kind-name = $type-decl<kind> == 5 ?? "class" !! "role";

                my Str $new-uri;
                if $target eq "auto" {
                    if self.root-path {
                        my Str $rel-path = $type-name.subst("::", "/", :g) ~ ".rakumod";
                        my IO::Path $lib-path = self.root-path.IO.child("lib").child($rel-path);
                        $new-uri = path-to-uri($lib-path);
                    } else {
                        # Fallback if no root-path
                        $new-uri = $uri.subst(/ \/ [^ \/]* $ /, "/" ~ $type-name.subst("::", "-", :g) ~ ".rakumod");
                    }
                } else {
                    $new-uri = $target; # From client prompt
                }

                # Extract text
                my Int $start-char = $type-decl<range><start><character>;
                my Int $end-line = $type-decl<range><end><line>;
                my Int $end-char = $type-decl<range><end><character>;
                my Int $start-off = $doc.position-to-offset($start-line, $start-char);
                my Int $end-off = $doc.position-to-offset($end-line, $end-char);
                my Str $extracted = $doc.text.substr($start-off, $end-off - $start-off);

                my Str $traits = "";
                if $extracted ~~ /^ \s* $kind-name \s+ $type-name \s* (<-[\{]>*) \{ / {
                    $traits = $0.Str.trim;
                    $traits = $traits.lines.map(*.trim).join(" ");
                }
                my Str $trait-clause = $traits ne "" ?? " $traits" !! "";
                my Str $extracted-body = $extracted.subst(/^ \s* $kind-name \s+ $type-name <-[\{]>* \{ /, "").subst(/ \} \s* $/, "");

                my Any @documentChanges = [];
                my $res-ops = try { self.client-capabilities<workspace><workspaceEdit><resourceOperations> };
                my Bool $can-create = ($res-ops.defined && $res-ops ~~ Positional && $res-ops.grep("create").elems > 0).Bool;
                if $can-create {
                    @documentChanges.push: {
                        kind => "create",
                        uri => $new-uri,
                        options => { ignoreIfExists => True }
                    };
                }

                # Reference Update
                my Int $name-line = ($type-decl<selectionRange> // $type-decl<range>)<start><line>;
                my Int $name-char = ($type-decl<selectionRange> // $type-decl<range>)<start><character>;
                my Any @refs = self.textDocument-references(:textDocument({:$uri}), :position({line => $name-line, character => $name-char}));
                my Bool %seen-files{Str};
                my Bool $has-source-refs = False;
                my Int $decl-sl = $type-decl<range><start><line>;
                my Int $decl-el = $type-decl<range><end><line>;

                my Str $source-outside = $doc.text.substr(0, $start-off) ~ $doc.text.substr($end-off);
                if $source-outside ~~ / << "$type-name" >> / {
                    $has-source-refs = True;
                }

                for @refs -> Any $r {
                    my Str $ref-uri = $r<uri>;
                    if $ref-uri eq $uri {
                        my Int $rl = $r<range><start><line>;
                        if $rl < $decl-sl || $rl > $decl-el {
                            $has-source-refs = True;
                        }
                        next;
                    }
                    next if $ref-uri eq $new-uri;

                    if !%seen-files{$ref-uri} {
                        my Document $ref-doc = self.doc-store.get($ref-uri);
                        if $ref-doc && $ref-doc.text.contains("use $type-name;") {
                            %seen-files{$ref-uri} = True;
                            next;
                        }
                        @documentChanges.push: hash(
                            textDocument => hash( uri => $ref-uri, version => Any ),
                            edits => [
                                hash(
                                    range => hash( start => hash( line => 0, character => 0 ), end => hash( line => 0, character => 0 ) ),
                                    newText => "use $type-name;\n"
                                ),
                            ]
                        );
                        %seen-files{$ref-uri} = True;
                    }
                }

                # Edits for source file $uri
                my @source-edits;
                if $has-source-refs && !$doc.text.contains("use $type-name;") {
                    if $decl-sl == 0 {
                        @source-edits.push: hash(
                            range => $type-decl<range>,
                            newText => "use $type-name;\n"
                        );
                    } else {
                        @source-edits.push: hash(
                            range => hash( start => hash( line => 0, character => 0 ), end => hash( line => 0, character => 0 ) ),
                            newText => "use $type-name;\n"
                        );
                        @source-edits.push: hash(
                            range => $type-decl<range>,
                            newText => ""
                        );
                    }
                } else {
                    @source-edits.push: hash(
                        range => $type-decl<range>,
                        newText => ""
                    );
                }

                @documentChanges.push: hash(
                    textDocument => hash( uri => $uri, version => $doc.version ),
                    edits => @source-edits
                );

                @documentChanges.push: hash(
                    textDocument => hash( uri => $new-uri, version => Any ),
                    edits => [
                        hash(
                            range => hash( start => hash( line => 0, character => 0 ), end => hash( line => 0, character => 0 ) ),
                            newText => "unit $kind-name $type-name$trait-clause;\n\n" ~ $extracted-body ~ "\n"
                        ),
                    ]
                );
                if ?(try { self.client-capabilities<workspace><applyEdit> }) {
                    my $has-doc-changes = try { self.client-capabilities<workspace><workspaceEdit><documentChanges> };
                    my Bool $supports-doc-changes = $has-doc-changes.defined ?? ?$has-doc-changes !! True;
                    if $supports-doc-changes {
                        self.client.request-async("workspace/applyEdit", {
                                label => "Move $kind-name $type-name",
                                edit => {
                                    documentChanges => @documentChanges
                                }
                        });
                    } else {
                        my %changes;
                        for @documentChanges -> $item {
                            if $item<textDocument>:exists {
                                my Str $doc-uri = $item<textDocument><uri>;
                                %changes{$doc-uri} //= [];
                                %changes{$doc-uri}.append: @($item<edits>);
                            }
                        }
                        self.client.request-async("workspace/applyEdit", {
                                label => "Move $kind-name $type-name",
                                edit => {
                                    changes => %changes
                                }
                        });
                    }
                }
            }
        }
    } else {
        X::LSP::InvalidParams.new(message => "Unknown command: {$command // ''}").throw;
    }
    return Nil;
}


#| Handle workspace/willRenameFiles request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_willRenameFiles>
method workspace-willRenameFiles(:@files, *%other --> Hash) {
    my @documentChanges;
    my %file-edits; # uri -> Array of edits

    for @files -> $f {
        my $oldUri = $f<oldUri> // "";
        my $newUri = $f<newUri> // "";

        next unless $oldUri && $newUri;

        my Str $oldPath = uri-to-path($oldUri).Str;
        my Str $newPath = uri-to-path($newUri).Str;

        sub get-module-name(Str $path --> Str) {
            my Str $norm = $path.subst('\\', '/', :g);
            if self.root-path {
                my Str $root-norm = self.root-path.subst('\\', '/', :g);
                if $norm.starts-with($root-norm ~ "/") {
                    $norm = $norm.substr($root-norm.chars + 1);
                }
            }
            my Str $rel;
            if $norm.rindex('/lib/') -> $idx {
                $rel = $norm.substr($idx + 5);
            } elsif $norm.starts-with('lib/') {
                $rel = $norm.substr(4);
            }
            if $rel.defined {
                $rel ~~ s/ \. [ raku | rakumod | pm6 | p6 ] $ //;
                return $rel.subst('/', '::', :g);
            }
            my $base = $path.IO.basename;
            $base ~~ s/ \. [ raku | rakumod | pm6 | p6 ] $ //;
            return $base;
        }

        my $oldName = get-module-name($oldPath);
        my $newName = get-module-name($newPath);

        if $oldName && $newName && $oldName ne $newName {
            my Document $doc = self.doc-store.get-or-load($oldUri);
            my Str $text = $doc.defined ?? $doc.text !! "";

            if $text {
                # 1. Edit the renamed file to change `unit class Old;` -> `unit class New;`
                my @symbols = extract-symbols($doc);
                my $type-decl;
                for @symbols -> $s {
                    if $s<kind> == 5 || $s<kind> == 11 || $s<kind> == 2 {
                        if ($s<name> // "") eq $oldName {
                            $type-decl = $s;
                            last;
                        }
                    }
                }

                my Bool $decl-edited = False;
                if $type-decl {
                    my $start-line = $type-decl<range><start><line>;
                    my $line-text = $doc.line-text($start-line);
                    if $line-text ~~ / (<< [unit\s+]? [class|role|module|package|grammar] \s+) ($oldName) >> / {
                        my $m-from = $/.from + $0.Str.chars;
                        my $m-to   = $m-from + $oldName.chars;

                        %file-edits{$oldUri} //= [];
                        %file-edits{$oldUri}.push: {
                            range => {
                                start => { line => $start-line, character => $doc.utf16-column($start-line, $m-from) },
                                end   => { line => $start-line, character => $doc.utf16-column($start-line, $m-to) }
                            },
                            newText => $newName
                        };
                        $decl-edited = True;
                    }
                }

                if !$decl-edited {
                    for 0 .. $doc.lines-count - 1 -> $ln {
                        my $lt = $doc.line-text($ln);
                        if $lt ~~ / (<< [unit\s+]? [class|role|module|package|grammar] \s+) ($oldName) >> / {
                            my $m-from = $/.from + $0.Str.chars;
                            my $m-to   = $m-from + $oldName.chars;

                            %file-edits{$oldUri} //= [];
                            %file-edits{$oldUri}.push: {
                                range => {
                                    start => { line => $ln, character => $doc.utf16-column($ln, $m-from) },
                                    end   => { line => $ln, character => $doc.utf16-column($ln, $m-to) }
                                },
                                newText => $newName
                            };
                            last;
                        }
                    }
                }

                # 2. Find references to OldName across workspace (excluding declarations)
                my @r = self.index
                ?? self.index.find-references-everywhere($oldName, doc-store => self.doc-store, :!include-declaration).Array
                !! [].Array;
                for @r -> $ref {
                    my $ref-uri = $ref<uri>;
                    my $sl = $ref<range><start><line>;
                    my $el = $ref<range><end><line>;
                    next if $sl != $el;

                    %file-edits{$ref-uri} //= [];
                    %file-edits{$ref-uri}.push: {
                        range => $ref<range>,
                        newText => $newName
                    };
                }
            }
        }
    }

    for %file-edits.keys.sort -> $uri {
        my @raw-edits = %file-edits{$uri}.flat;
        my @unique-edits;
        my SetHash $seen-ranges = SetHash.new;

        for @raw-edits -> $edit {
            my $r = $edit<range>;
            my Str $key = "{$r<start><line>}:{$r<start><character>}-{$r<end><line>}:{$r<end><character>}";
            unless $seen-ranges{$key} {
                $seen-ranges{$key} = True;
                @unique-edits.push($edit);
            }
        }

        # Sort edits in reverse document order (bottom-to-top, right-to-left)
        @unique-edits = @unique-edits.sort({
                $^b<range><start><line> <=> $^a<range><start><line>
                || $^b<range><start><character> <=> $^a<range><start><character>
        });

        @documentChanges.push: {
            textDocument => { uri => $uri, version => Any },
            edits => @unique-edits
        };
    }

    my $has-doc-changes = try { self.client-capabilities<workspace><workspaceEdit><documentChanges> };
    my Bool $supports-document-changes = $has-doc-changes.defined ?? ?$has-doc-changes !! True;
    if $supports-document-changes {
        return {
            documentChanges => @documentChanges
        };
    } else {
        my %changes;
        for @documentChanges -> $dc {
            %changes{$dc<textDocument><uri>} = $dc<edits>;
        }
        return {
            changes => %changes
        };
    }
}
