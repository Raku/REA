#| Role handling the LSP server lifecycle:
#| initialize, initialized, shutdown, exit, workspace indexing,
#| diagnostics, progress and cancel notifications.
unit role Nimala::Raku-LSP::Handler::Lifecycle;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Workspace;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::VendorIndex;
use Nimala::Raku-LSP::URI;
use Nimala::Raku-LSP::Cache;
has Lock $!refresh-lock = Lock.new;
has Int $!refresh-counter = 0;
has Bool $!indexing-in-progress = False;
has Lock $!indexing-lock = Lock.new;
has Int $!active-indexing-count = 0;
has Int $!progress-seq = 0;
has @!indexing-scopes;
has @!indexing-promises;

#| Fire each of the 6 workspace refresh requests whose refreshSupport the client declares.
method !fire-refreshes(--> Nil) {
    my $ws = self.client-capabilities<workspace>;
    return unless $ws.defined && $ws ~~ Associative;

    if ($ws<codeLens><refreshSupport> // False) {
        self.client.refresh-code-lens();
    }
    if ($ws<inlayHint><refreshSupport> // False) {
        self.client.refresh-inlay-hints();
    }
    if ($ws<semanticTokens><refreshSupport> // False) {
        self.client.refresh-semantic-tokens();
    }
    if ($ws<foldingRange><refreshSupport> // False) {
        self.client.refresh-folding-ranges();
    }
    if ($ws<diagnostics>:exists && $ws<diagnostics><refreshSupport>) || ($ws<diagnostic>:exists && $ws<diagnostic><refreshSupport>) {
        self.?clear-diagnostic-cache();
        self.client.refresh-diagnostics();
    }
    if ($ws<inlineValue><refreshSupport> // False) {
        self.client.refresh-inline-values();
    }
}

#| Public trigger for debounced workspace refresh requests (500ms).
method trigger-refreshes(--> Nil) {
    self!trigger-refreshes();
}

#| Debounce workspace refresh requests (500ms).
method !trigger-refreshes(--> Nil) {
    return if $!indexing-in-progress;
    $!refresh-lock.protect: {
        my Int $c = ++$!refresh-counter;
        Promise.in(0.5).then({
                if $!refresh-lock.protect({ $c == $!refresh-counter }) {
                    self!fire-refreshes();
                }
        });
    }
}



#| Implementation of the 'initialize' request.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#initialize>
method initialize(Any :$processId?, :%capabilities?, :$initializationOptions?, Any :$rootUri?, Any :$rootPath?, :$workspaceFolders?, *%other --> Hash) {
    if %capabilities {
        self.client-capabilities = %capabilities;
    } elsif %other<capabilities>.defined && (%other<capabilities> ~~ Hash) {
        self.client-capabilities = %other<capabilities>;
    }

    if $initializationOptions.defined && ($initializationOptions ~~ Hash) {
        self.configuration = $initializationOptions;
    }

    my $wf = $workspaceFolders;
    if $wf.defined && $wf ~~ Hash {
        $wf = [ $wf ];
    }
    if $wf.defined && ($wf ~~ Positional) && $wf.elems > 0 {
        my Hash @folders;
        my @items = @($wf);
        for @items -> $f {
            my Str $uri = ($f ~~ Hash ?? ($f<uri> // "") !! (try { $f.uri } // "")) // "";
            next unless $uri;
            my Str $name = ($f ~~ Hash ?? ($f<name> // "") !! (try { $f.name } // "")) || (try { uri-to-path($uri).IO.basename }) || "workspace";
            @folders.push: %( uri => $uri, name => $name );
        }
        self.workspace-folders = @folders.Array;
        if @folders.elems > 0 {
            my Str $first-uri = @folders[0]<uri>;
            self.root-path = uri-to-path($first-uri).Str;
        }
    } elsif $rootUri.defined && $rootUri ~~ Str && $rootUri.chars > 0 {
        self.root-path = uri-to-path($rootUri).Str;
        self.workspace-folders = [ $%(:uri($rootUri), :name(self.root-path.IO.basename)) ].Array;
    } elsif $rootPath.defined && $rootPath ~~ Str && $rootPath.chars > 0 {
        self.root-path = $rootPath;
        self.workspace-folders = [ $%(:uri(path-to-uri(self.root-path)), :name(self.root-path.IO.basename)) ].Array;
    } else {
        self.root-path = Nil;
        self.workspace-folders = [].Array;
    }
    self.state = Initializing unless self.state == ShuttingDown;

    return {
        capabilities => {
            positionEncoding => 'utf-16',
            textDocumentSync => {
                openClose => True,
                change => 2, # Incremental
                willSave => True,
                save => { includeText => True }
            },
            completionProvider => {
                resolveProvider    => True,
                triggerCharacters  => [ '.', ':' ],
            },
            hoverProvider => True,
            definitionProvider => True,
            declarationProvider => True,
            typeDefinitionProvider => True,
            implementationProvider => True,
            signatureHelpProvider => {
                triggerCharacters => [ '(', ',' ]
            },
            workspaceSymbolProvider => True,
            documentSymbolProvider => True,
            documentHighlightProvider => True,
            foldingRangeProvider => True,
            selectionRangeProvider => True,
            renameProvider => {
                prepareProvider => True
            },
            referencesProvider => True,
            documentFormattingProvider => True,
            documentRangeFormattingProvider => True,
            documentOnTypeFormattingProvider => {
                firstTriggerCharacter => '}',
                moreTriggerCharacter  => [ ';', "\n" ]
            },
            codeActionProvider => {
                codeActionKinds => [
                    "quickfix",
                    "refactor",
                    "refactor.extract",
                    "refactor.inline",
                    "refactor.rewrite"
                ],
                resolveProvider => True
            },
            executeCommandProvider => {
                commands => [ "nimala.trimWhitespace", "nimala.moveSymbol" ]
            },
            typeHierarchyProvider => True,
            callHierarchyProvider => True,
            codeLensProvider => {
                resolveProvider => True
            },
            inlayHintProvider => {
                resolveProvider => True
            },
            inlineValueProvider => True,
            inlineCompletionProvider => True,
            linkedEditingRangeProvider => True,
            diagnosticProvider => {
                interFileDependencies => True,
                workspaceDiagnostics  => True
            },
            documentLinkProvider => {
                resolveProvider => False
            },
            semanticTokensProvider => {
                legend => {
                    tokenTypes => [
                        "type", "class", "enum", "interface", "struct", "typeParameter", "parameter", "variable", "property", "enumMember", "event", "function", "method", "macro", "keyword", "modifier", "comment", "string", "number", "regexp", "operator"
                    ],
                    tokenModifiers => [
                        "declaration", "definition", "readonly", "static", "deprecated", "abstract", "async", "modification", "documentation", "defaultLibrary"
                    ]
                },
                range => True,
                full => { delta => True }
            },
            workspace => {
                workspaceFolders => {
                    supported => True,
                    changeNotifications => True
                },
                fileOperations => {
                    willRename => {
                        filters => [
                            { pattern => { glob => '**/*.{raku,rakumod,rakutest,rakudoc,nqp,p6,pm6,pod6,t,t6}' } },
                        ]
                    }
                }
            }
        },
        serverInfo => {
            name => 'Nimala Raku LSP',
            version => (try { self.^ver.Str.subst(/^v/, '') })
            // (try { ::("Nimala::Raku-LSP").^ver.Str.subst(/^v/, '') })
            // 'unknown'
        }
    };
}

#| Ensure SQLite symbol database is open for the current workspace root
method ensure-db-open(--> Nil) {
    if !self.db.is-open {
        if self.root-path {
            self.db.open(self.root-path.IO);
            # Every workspace folder is indexed into the root database, so each one is validated
            my IO::Path @folders = self.workspace-folders.map({
                    uri-to-path(($_ ~~ Hash ?? $_<uri> !! (try { $_.uri } // "")) // "")
            }).grep({ $_ && .d });
            @folders = self.root-path.IO unless @folders;
            self.db.validate-index($_) for @folders;
            self.index.db = self.db;
            self.index.root-path = self.root-path;
        } else {
            self.db.open-memory();
            self.index.db = self.db;
        }
    }
}

#| Notification sent after initialize.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#initialized>
method initialized(*%other --> Nil) {
    if self.state == Initializing {
        self.state = Initialized;
        self.client.log-message(Info, "Nimala Raku LSP initialized.");

        self.ensure-db-open();

        # Dynamically register workspace/didChangeWatchedFiles only if client explicitly supports it
        my $dyn-watchers = self.client-capabilities<workspace><didChangeWatchedFiles><dynamicRegistration>;
        if $dyn-watchers.defined && $dyn-watchers.Bool {
            self.client.request("client/registerCapability", %(
                    registrations => [
                        $%(
                            id => "nimala-file-watcher-1",
                            method => "workspace/didChangeWatchedFiles",
                            registerOptions => %(
                                watchers => [
                                    $%( globPattern => '**/*.{raku,rakumod,rakutest,rakudoc,nqp,p6,pm6,pod6,t,t6}' )
                                ]
                            )
                        )
                    ]
            ));
        }

        my $p = start {
            self!index-workspace();
        };
        $!indexing-lock.protect: {
            @!indexing-promises.push: $p;
        }
    }
}

#| Notification sent when the client's configuration or settings have changed.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeConfiguration>
method workspace-didChangeConfiguration(:$settings?, Numeric :$timeout?, *%other --> Nil) {
    if $settings.defined && ($settings ~~ Associative) && $settings.elems > 0 {
        self.configuration = $settings.Hash;
        self.client.log-message(Info, "Server configuration updated.");
        self!trigger-refreshes();
        return;
    }

    my $ws = self.client-capabilities<workspace>;
    my Bool $pull-supported = ($ws.defined && $ws ~~ Associative && ($ws<configuration> // False)).Bool;

    if $pull-supported {
        my Numeric $eff-timeout = ($timeout // self.get-config('workspace.configuration.timeout') // self.get-config('requestTimeout') // 15).Numeric;
        my Promise $p = self.client.request-async("workspace/configuration", %(
                items => [ %( section => 'raku' ), ]
            ), :timeout($eff-timeout));

        $p.then(-> $ans-prom {
                if $ans-prom.status == Kept {
                    my $ans = $ans-prom.result;
                    if $ans ~~ Positional && $ans.elems > 0 && ($ans[0] ~~ Associative) {
                        self.configuration = %( raku => $ans[0].Hash );
                    }
                }
                self.client.log-message(Info, "Server configuration updated.");
                self!trigger-refreshes();
        });
    } else {
        self.client.log-message(Info, "Server configuration updated.");
        self!trigger-refreshes();
    }
}

#| Notification sent when workspace folders are added or removed dynamically (LSP 3.6+).
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeWorkspaceFolders>
method workspace-didChangeWorkspaceFolders(:$event?, *%other --> Nil) {
    my $ev = $event // %other<event>;
    return unless $ev;
    my @added = ($ev<added> // []).Array;
    my @removed = ($ev<removed> // []).Array;

    # 1. Process removed folders
    for @removed -> $rem {
        my Str $rem-uri = ($rem ~~ Associative ?? ($rem<uri> // "") !! (try { $rem.uri } // "")) // "";
        next unless $rem-uri;

        self.workspace-folders = self.workspace-folders.grep({
                my Str $u = ($_ ~~ Hash ?? $_<uri> !! (try { $_.uri } // "")) // "";
                $u ne $rem-uri
        }).Array;

        self.index.remove-folder($rem-uri);
        self.client.log-message(Info, "Removed workspace folder: $rem-uri");
    }

    # 2. Process added folders
    for @added -> $add {
        my Str $add-uri = ($add ~~ Associative ?? ($add<uri> // "") !! (try { $add.uri } // "")) // "";
        next unless $add-uri;
        my Str $name = ($add ~~ Associative ?? ($add<name> // "") !! (try { $add.name } // "")) || (try { $add-uri.IO.basename } // "folder");

        my $existing = self.workspace-folders.first({
                my Str $u = ($_ ~~ Associative ?? ($_<uri> // "") !! (try { $_.uri } // "")) // "";
                $u eq $add-uri
        });

        unless $existing {
            self.workspace-folders.push: $%(:uri($add-uri), :name($name));
        }

        my IO::Path $path = uri-to-path($add-uri);
        if $path.d {
            my $p = start {
                self!index-folder($path, :title("Indexing added workspace folder: $name"));
            };
            $!indexing-lock.protect: {
                @!indexing-promises = @!indexing-promises.grep({ .status == Planned }).Array;
                @!indexing-promises.push: $p;
            }
        }

        self.client.log-message(Info, "Added workspace folder: $add-uri");
    }

    # 3. Trigger debounced refreshes across clients
    self!trigger-refreshes();
}

#| Scan a single folder for Raku files and index them with progress reporting.
method !index-folder(IO::Path $folder-path, Str :$title = "Indexing Raku workspace" --> Nil) {
    return unless $folder-path && $folder-path.d;

    my IO::Path @files = find-raku-files($folder-path);
    my Int $total = @files.elems;

    my Str $token;
    $!indexing-lock.protect: {
        $!active-indexing-count++;
        $!indexing-in-progress = True;
        $token = "indexing-" ~ $*PID ~ "-" ~ (++$!progress-seq) ~ "-" ~ $folder-path.basename;
    };

    my $scope = self.start-progress(
        $title,
        :$token,
        :$total,
        :cancellable
    );
    $!indexing-lock.protect: {
        @!indexing-scopes.push: $scope;
    }

    LEAVE {
        my Bool $should-fire = False;
        $!indexing-lock.protect: {
            $!active-indexing-count--;
            if $!active-indexing-count <= 0 {
                $!active-indexing-count = 0;
                $!indexing-in-progress = False;
                $should-fire = True;
            }
            @!indexing-scopes = @!indexing-scopes.grep({ $_ !=== $scope }).Array;
        };
        $scope.finish("Indexed $total files.") if $scope && self.state != ShuttingDown;
        self!fire-refreshes() if $should-fire && self.state != ShuttingDown;
    }

    my Int $indexed = 0;
    for @files -> IO::Path $file {
        if self.state == ShuttingDown || ($scope && $scope.is-cancelled) {
            $scope.finish("$title cancelled") if $scope && self.state != ShuttingDown;
            self.client.log-message(Info, "$title cancelled after indexing $indexed of $total files.");
            return;
        }

        try {
            self.index.refresh-from-disk($file);
            CATCH {
                default {
                    self.client.log-message(Warning, "Failed to index {$file.Str}: {.message}");
                }
            }
        }
        $indexed++;
        if $total > 0 && ($indexed % 10 == 0 || $indexed == $total) {
            my Int $pct = ($indexed * 100) div $total;
            $scope.report(:percentage($pct), :message("$indexed / $total files"));
        }
    }

    self.client.log-message(Info, "Indexed " ~ @files.elems ~ " files.");
    self.client.log-message(Info, "$title completed: " ~ @files.elems ~ " files.");
}

#| Scan all configured workspace folders (or root-path) for Raku files.
method !index-workspace(--> Nil) {
    if self.workspace-folders && self.workspace-folders.elems > 0 {
        for @(self.workspace-folders) -> $f {
            my Str $uri = ($f ~~ Hash ?? $f<uri> !! (try { $f.uri } // "")) // "";
            my IO::Path $path = uri-to-path($uri);
            if $path && $path.d {
                self!index-folder($path, :title("Indexing workspace folder: " ~ $path.basename));
            }
        }
    } elsif self.root-path && self.root-path.IO.d {
        self!index-folder(self.root-path.IO, :title("Indexing Raku workspace"));
    }
}

#| Cancel any active syntax checking process for the given URI.
method cancel-syntax-check(Str $uri --> Nil) {
    cancel-syntax-check($uri);
}

#| Cancel all active syntax checking processes.
method cancel-all-syntax-checks(--> Nil) {
    cancel-all-syntax-checks();
}

#| Cancel all active background indexing tasks.
method cancel-indexing(--> Nil) {
    $!indexing-lock.protect: {
        for @!indexing-scopes -> $s {
            if $s && $s.cancel-token {
                try { $s.cancel-token.cancel; CATCH { default { } } }
            }
        }
    }
}

#| Await active background indexing tasks up to timeout.
method await-indexing(Numeric :$timeout = 3.0 --> Nil) {
    my @proms;
    $!indexing-lock.protect: {
        @!indexing-promises = @!indexing-promises.grep({ .status == Planned }).Array;
        @proms = @!indexing-promises;
    }
    if @proms {
        try {
            await Promise.anyof(Promise.allof(@proms), Promise.in($timeout));
            CATCH { default { } }
        }
    }
}

#| Helper to run analysis and notify the client.
method !trigger-diagnostics(Document $doc --> Nil) {
    return unless $doc;
    my Str $uri = $doc.uri;
    my Int $version = $doc.version // 0;

    # If client declared pull diagnostic capability, suppress automated push diagnostics
    my $td = self.client-capabilities<textDocument>;
    my Bool $pull-supported = ($td.defined && $td ~~ Associative && ($td<diagnostic>:exists)).Bool;
    return if $pull-supported;

    my Bool $enabled = (self.get-config('syntaxCheck.enable', True)).Bool;
    if !$enabled {
        self.client.notify("textDocument/publishDiagnostics", {
                uri         => $uri,
                version     => $version,
                diagnostics => []
        });
        return;
    }

    # Cancel any previous in-flight syntax check for this document URI
    self.cancel-syntax-check($uri);

    my Str $executable = (self.get-config('executablePath') // self.get-config('rakuPath') // 'raku').Str;
    my Numeric $timeout = (self.get-config('syntaxCheck.timeout', 5)).Numeric;
    my @include-paths = (self.get-config('includePaths') // []).List;
    my Str $workspace-root = self.root-path.defined && self.root-path.chars ?? self.root-path !! Str;

    try {
        my $prom = check-syntax(
            $doc,
            :$executable,
            :$timeout,
            :$enabled,
            :@include-paths,
            cwd => $workspace-root
        );
        if $prom.defined && $prom ~~ Promise {
            $prom.then(-> Promise $p {
                    # Discard results if document was closed
                    my Document $current-doc = self.doc-store.get($uri);
                    return unless $current-doc;

                    # Discard results if document version has advanced
                    my Int $current-ver = $current-doc.version // 0;
                    return unless $current-ver == $version;

                    my Any $res = try { $p.result };
                    my Hash @diagnostics = ($res.defined && $res ~~ Positional) ?? @$res !! [];
                    self.client.notify("textDocument/publishDiagnostics", {
                            uri         => $uri,
                            version     => $version,
                            diagnostics => @diagnostics.map({ %$_ }).Array
                    });
            });
        }
        CATCH { default { } }
    }
}

#| Request for shutting down the server.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#shutdown>
method shutdown(:$_id, *%other --> Any) {
    if self.state == ShuttingDown {
        return Nil;
    }
    self.state = ShuttingDown;

    # 1. Cancel pending debounces and active syntax checks
    self.?cancel-all-debounces();
    self.cancel-all-syntax-checks();

    # 2. Cancel active indexing tasks
    self.cancel-indexing();

    # 3. Await in-flight requests from dispatcher
    if self.dispatcher {
        self.dispatcher.await-in-flight(:exclude-id($_id));
    }

    # 4. Await indexing tasks (bounded timeout)
    self.await-indexing(:timeout(3.0));

    # 5. Safely close SymbolDB
    if self.db && self.db.is-open {
        self.db.close();
    }
    return Nil;
}

#| Notification for exiting the server process.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#exit>
method exit(*%other --> Nil) {
    my Int $code = self.state == ShuttingDown ?? 0 !! 1;
    if self.^can('exit-code') {
        self.exit-code = $code;
    }
    if self.^can('exit-handler') && self.exit-handler.defined {
        my $cb = self.exit-handler;
        self.exit-handler = Nil;
        $cb.($code);
    }
    return;
}


#| Handle $/progress notification.
method lsp-progress(Any :$token, Any :$value, *%other --> Any) {
    return Nil unless $token.defined;
    my Str $tok = $token.Str;
    my $val = $value // %other<value>;
    my Str $kind = ($val ~~ Hash ?? ($val<kind> // "") !! (try { $val.kind } // "")).Str;
    my Str $title = ($val ~~ Hash ?? ($val<title> // "") !! (try { $val.title } // "")).Str;
    my Str $message = ($val ~~ Hash ?? ($val<message> // "") !! (try { $val.message } // "")).Str;
    my $percentage = $val ~~ Hash ?? $val<percentage> !! (try { $val.percentage });
    my $cancellable = $val ~~ Hash ?? $val<cancellable> !! (try { $val.cancellable });

    my Hash $event = %(
        token => $tok,
        kind => $kind,
        title => $title,
        message => $message,
        percentage => $percentage,
        cancellable => $cancellable
    );

    self.progress-lock.protect: {
        if $kind eq "begin" {
            self.active-progress-raw{$tok} = $event;
        } elsif $kind eq "report" {
            if self.active-progress-raw{$tok}:exists {
                my $existing = self.active-progress-raw{$tok}.clone;
                $existing<message> = $message if $message;
                $existing<percentage> = $percentage if $percentage.defined;
                $existing<cancellable> = $cancellable if $cancellable.defined;
                self.active-progress-raw{$tok} = $existing;
            } else {
                self.active-progress-raw{$tok} = $event;
            }
        } elsif $kind eq "end" {
            self.active-progress-raw{$tok}:delete;
        }
    };

    try {
        self.progress-supplier.emit($event);
        CATCH { default { } }
    }

    self.client.log-message(Info, "Received progress update for token: $tok (kind: $kind)");
    return Nil;
}

#| Handle window/workDoneProgress/cancel notification.
method window-workDoneProgress-cancel(Any :$token, *%other --> Any) {
    if $token.defined {
        self.cancel-progress-token($token);
        self.client.log-message(Info, "Client canceled workDoneProgress token: $token");
    }
    return Nil;
}
