unit module Nimala::Raku-LSP::Analysis::TypeInference;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::AST;
use Nimala::Raku-LSP::Analysis::Symbols;

#| Parse a type string into structured metadata (generic container, inner type, map key/value)
our proto sub parse-type-structure(|) is export {*}
multi sub parse-type-structure(Str $type-str --> Hash) {
    my Str $t = $type-str.trim;
    return %{ kind => 'unknown', name => '' } if $t eq '';

    if $t ~~ /^ ( <[a..zA..Z0..9_\:\-]>+ ) \s* '[' \s* (.*) \s* ']' $/ {
        my Str $container = $0.Str.trim;
        my Str $inner = $1.Str.trim;
        if $container eq 'Hash' || $container eq 'Map' {
            if $inner.contains(',') {
                my ($k, $v) = $inner.split(',', 2)».trim;
                return %{
                    kind => 'generic-map',
                    container => $container,
                    key => $k,
                    value => $v,
                    name => "$container\[$inner\]"
                };
            } else {
                return %{
                    kind => 'generic-map',
                    container => $container,
                    key => 'Any',
                    value => $inner,
                    name => "$container\[$inner\]"
                };
            }
        }
        return %{
            kind => 'generic',
            container => $container,
            inner => $inner,
            name => "$container\[$inner\]"
        };
    }

    return %{ kind => 'simple', name => $t };
}
our proto sub split-chain(|) is export {*}
multi sub split-chain(Str $expr --> Array[Str]) {
    my Str @parts;
    my Str $current = "";
    my Int $paren-depth = 0;
    my Int $bracket-depth = 0;
    my Int $brace-depth = 0;
    my Int $angle-depth = 0;
    my Bool $in-single-quote = False;
    my Bool $in-double-quote = False;

    for $expr.comb -> $ch {
        if $ch eq "'" && !$in-double-quote {
            $in-single-quote = !$in-single-quote;
            $current ~= $ch;
        } elsif $ch eq '"' && !$in-single-quote {
            $in-double-quote = !$in-double-quote;
            $current ~= $ch;
        } elsif $in-single-quote || $in-double-quote {
            $current ~= $ch;
        } elsif $ch eq '(' {
            $paren-depth++;
            $current ~= $ch;
        } elsif $ch eq ')' {
            $paren-depth-- if $paren-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '[' {
            $bracket-depth++;
            $current ~= $ch;
        } elsif $ch eq ']' {
            $bracket-depth-- if $bracket-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '{' {
            $brace-depth++;
            $current ~= $ch;
        } elsif $ch eq '}' {
            $brace-depth-- if $brace-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '<' {
            $angle-depth++;
            $current ~= $ch;
        } elsif $ch eq '>' {
            $angle-depth-- if $angle-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '.' && !($current.chars == 1 && $current ~~ /<[$@%&]>/) && $paren-depth == 0 && $bracket-depth == 0 && $brace-depth == 0 && $angle-depth == 0 {
            @parts.push($current.trim) if $current.trim ne "";
            $current = "";
        } else {
            $current ~= $ch;
        }
    }
    @parts.push($current.trim) if $current.trim ne "";
    return @parts;
}

#| Search the AST for a variable declaration and return its type
our proto sub find-variable-type(|) is export {*}
multi sub find-variable-type(Document $doc, Str $var-name, Int $line is copy = -1, Int $character is copy = -1, Any $workspace = Nil --> Str) {
    my @parts = split-chain($var-name);
    if @parts.elems > 1 {
        my $base-type = find-variable-type($doc, @parts[0].trim, $line, $character, $workspace);

        for 1..^@parts.elems -> $i {
            return "" unless $base-type;
            my $raw-part = @parts[$i].trim;
            next if $raw-part eq "";

            my $clean-part = $raw-part;
            while $clean-part ~~ s:g/ \( <-[\)]>* \) // { }
            my Bool $is-indexed = $clean-part.contains('[') || $clean-part.contains('{') || $clean-part.contains('<');
            my $meth = $clean-part;
            $meth ~~ s:g/ \[ <-[\]]>* \] //; # remove array indexing
            $meth ~~ s:g/ \{ <-[\}]>* \} //; # remove hash indexing
            $meth ~~ s:g/ \< <-[\>]>* \> //; # remove hash indexing
            $meth = $meth.trim;

            if $meth eq 'new' || $meth eq 'bless' {
                # Implicitly returns the class itself
                next;
            }

            my Hash $type-info = parse-type-structure($base-type);

            # Check Core Chaining / Unwrapping rules
            if $type-info<kind> eq 'generic' {
                # Container-preserving operations
                if $meth eq 'grep' || $meth eq 'sort' || $meth eq 'reverse' || $meth eq 'unique' || $meth eq 'squish' || $meth eq 'rotor' || $meth eq 'batch' || $meth eq 'flat' {
                    if $is-indexed {
                        $base-type = $type-info<inner>;
                    }
                    next;
                }
                # Element-extracting operations
                if $meth eq 'first' || $meth eq 'head' || $meth eq 'tail' || $meth eq 'min' || $meth eq 'max' || $meth eq 'pick' || $meth eq 'roll' || $meth eq 'pop' || $meth eq 'shift' || $meth eq '' {
                    $base-type = $type-info<inner>;
                    next;
                }
                # Asynchronous resolution
                if $type-info<container> eq 'Promise' && ($meth eq 'result' || $meth eq 'await') {
                    $base-type = $type-info<inner>;
                    next;
                }
                if $type-info<container> eq 'Supply' {
                    if $meth eq 'tap' {
                        $base-type = 'Tap';
                        next;
                    }
                    if $meth eq 'wait' {
                        $base-type = $type-info<inner>;
                        next;
                    }
                }
            } elsif $type-info<kind> eq 'generic-map' {
                if $meth eq 'keys' {
                    $base-type = "Seq\[{$type-info<key>}\]";
                    next;
                }
                if $meth eq 'values' {
                    $base-type = "Seq\[{$type-info<value>}\]";
                    next;
                }
                if $meth eq 'kv' {
                    $base-type = "Seq";
                    next;
                }
                if $is-indexed {
                    $base-type = $type-info<value>;
                    next;
                }
            } else {
                # Simple non-parameterized Array/Hash core operations
                if $base-type eq 'Array' || $base-type eq 'List' || $base-type eq 'Seq' {
                    if $meth eq 'grep' || $meth eq 'sort' || $meth eq 'reverse' || $meth eq 'unique' || $meth eq 'flat' {
                        next;
                    }
                    if $meth eq 'first' || $meth eq 'head' || $meth eq 'tail' || $is-indexed {
                        $base-type = "Any";
                        next;
                    }
                }
                if $base-type eq 'Supply' && $meth eq 'tap' {
                    $base-type = 'Tap';
                    next;
                }
                if $base-type eq 'Hash' || $base-type eq 'Map' {
                    if $meth eq 'keys' { $base-type = "Seq[Str]"; next; }
                    if $meth eq 'values' { $base-type = "Seq[Any]"; next; }
                    if $meth eq 'kv' { $base-type = "Seq"; next; }
                }
            }

            # Custom method / MRO resolution
            my $found-type = "";
            my $search-class = ($type-info<kind> eq 'generic' || $type-info<kind> eq 'generic-map')
            ?? $type-info<container>
            !! $base-type;

            if $workspace && $workspace.can('find-method-return-type') {
                $found-type = $workspace.find-method-return-type($search-class, $meth);
            }
            if !$found-type && $doc {
                my @doc-syms = extract-symbols($doc);
                sub find-in-doc-tree(@list) {
                    for @list -> $s {
                        if ($s<name> // "") eq $search-class && $s<children> {
                            for @($s<children>) -> $c {
                                if ($c<name> // "") eq $meth {
                                    my Str $det = $c<detail> // "";
                                    if $det ~~ / ( 'returns' | '-->' ) \s* ( <[a..zA..Z0..9_\:\-\[\]\s,]>+ ) / {
                                        return $1.Str.trim.subst(/ \s* '(' \w+ ')' \s* $/, '').trim;
                                    }
                                }
                            }
                        }
                        my $res = find-in-doc-tree($s<children>) if $s<children>;
                        return $res if $res;
                    }
                    return "";
                }
                $found-type = find-in-doc-tree(@doc-syms);
            }

            if $found-type && $is-indexed {
                my Hash $found-info = parse-type-structure($found-type);
                if $found-info<kind> eq 'generic' {
                    $found-type = $found-info<inner>;
                } elsif $found-info<kind> eq 'generic-map' {
                    $found-type = $found-info<value>;
                }
            }

            $base-type = $found-type;
        }
        return $base-type;
    }

    # Strip indexing from the base variable name
    my $clean-var = $var-name;
    my Bool $is-base-indexed = $var-name.contains('[') || $var-name.contains('{') || $var-name.contains('<');
    $clean-var ~~ s/ \[ .* \] $//;
    $clean-var ~~ s/ \{ .* \} $//;
    $clean-var ~~ s/ \< .* \> $//;

    if $clean-var ~~ /^ <[A..Z]> <[a..zA..Z0..9_\-]>* $/ {
        return $clean-var;
    }

    if $clean-var eq 'self' && $line.defined {
        if $workspace && $character.defined {
            my @enclosing = $workspace.find-enclosing-symbols($doc.uri, $line, $character);
            for @enclosing.reverse -> $s {
                if $s<kind> == 5 || $s<kind> == 11 {
                    return $s<name>;
                }
            }
        }
        my @syms = extract-symbols($doc);
        my $enclosing-class = "";
        sub search(@list) {
            for @list -> $s {
                if $s<kind> == 5 || $s<kind> == 11 { # Class/Role
                    if $s<range><start><line> <= $line <= $s<range><end><line> {
                        $enclosing-class = $s<name>;
                    }
                }
                search($s<children>) if $s<children>;
            }
        }
        search(@syms);
        return $enclosing-class if $enclosing-class;
    }

    if $line == -1 {
        $line = $doc.lines-count - 1;
        $line = 0 if $line < 0;
    }

    my $offset = ($character == -1)
    ?? $doc.text.chars
    !! $doc.position-to-offset($line, $character);

    my $best-type = "";
    my $best-offset = -1;

    my Str $alt-var = "";
    if $clean-var ~~ /^ ( <[$@%&]> ) '!' ( \w+ ) $/ {
        $alt-var = "$0.$1";
    } elsif $clean-var ~~ /^ ( <[$@%&]> ) '.' ( \w+ ) $/ {
        $alt-var = "$0!$1";
    }

    # 1. Native Symbols candidate (only from cache - never synchronous parse on keystroke path)
    if $doc.native-symbols.defined && $doc.native-symbols-version == $doc.version {
        my @syms = flatten-native-tree(@($doc.native-symbols));
        for @syms -> $s {
            if ($s<kind> // '') eq 'variable_decl'
            && (($s<name> // '') eq $clean-var || ($alt-var ne "" && ($s<name> // '') eq $alt-var))
            && $s<type> {
                my $s-off = $s<from> // 0;
                if $s-off <= $offset && $s-off > $best-offset {
                    $best-offset = $s-off;
                    $best-type = $s<type>;
                }
            }
        }
    }

    # 2. Regex Fallback candidate (only if not found by native symbols)
    if $best-offset == -1 {
        my $regex = / [ 'my' | 'our' | 'has' | 'state' | ',' | '(' | '->' ] \s* ( <[\w\-]>+ [ '::' <[\w\-]>+ ]* [ '[' \s* <[\w\:\-\s,]>+ \s* ']' ]? [ ':' <[a..zA..Z]>+ ]? ) \s+ [ $clean-var | <?{ $alt-var ne "" }> $alt-var ] /;
        for $doc.text.match($regex, :g) -> $m {
            if $m.to <= $offset && $m.to > $best-offset {
                my $t = $m[0].Str;
                if $t ne 'my' && $t ne 'our' && $t ne 'has' && $t ne 'state' && $t ne 'sub' && $t ne 'method' {
                    $best-offset = $m.to;
                    $best-type = $t.subst(/ <!after ":"> ":" <!before ":"> <[a..zA..Z]>+ $/, '');
                }
            }
        }
    }

    # 3. Custom AST candidate (fallback if nothing found yet)
    if $best-offset == -1 {
        my $ast = parse-document($doc);
        if $ast {
            my $t = find-variable-type($ast, $clean-var);
            if !$t && $alt-var {
                $t = find-variable-type($ast, $alt-var);
            }
            if $t {
                $best-type = $t;
                $best-offset = 0; # arbitrary, just to mark it found
            }
        }
    }

    # 4. Advanced Assignment candidate
    # Scan backward line by line
    my $assign-regex = / [ $clean-var | <?{ $alt-var ne "" }> $alt-var ] \s* [ '=' | '.=' ] \s* ( .* ) /;
    for (0..$line).reverse -> $l {
        my $line-text = $doc.line-text($l);
        if $line-text ~~ $assign-regex {
            # Assignment found! Calculate its approximate offset
            my $assign-offset = $doc.position-to-offset($l, $doc.utf16-column($l, $/.to));
            if $assign-offset <= $offset && $assign-offset > $best-offset {
                my $rhs = $/.list[0].Str;
                $rhs ~~ s/ ';' \s* $ //;

                if $rhs ~~ / ( <[A..Z]> <[a..zA..Z0..9_\:\-]>* ) \s* \. \s* [ 'new' | 'bless' ] / {
                    $best-offset = $assign-offset;
                    $best-type = $/.list[0].Str;
                } elsif $rhs ~~ / ( <[\$\@\%\&]> <[a..zA..Z0..9_\-]>+ ) \s* \. \s* ( <[a..zA..Z0..9_\-]>+ ) / {
                    my $var-base = $/.list[0].Str;
                    my $meth = $/.list[1].Str;
                    my $base-type = find-variable-type($doc, $var-base, $l, 0, $workspace);
                    if $base-type && $workspace && $workspace.can('find-method-return-type') {
                        my $meth-type = $workspace.find-method-return-type($base-type, $meth);
                        if $meth-type {
                            $best-offset = $assign-offset;
                            $best-type = $meth-type;
                        }
                    }
                }
            }
            # We only look at the most recent assignment, so break the loop
            last;
        }
    }

    if $best-type {
        if $is-base-indexed {
            my Hash $info = parse-type-structure($best-type);
            if $info<kind> eq 'generic' {
                return $info<inner>;
            } elsif $info<kind> eq 'generic-map' {
                return $info<value>;
            } else {
                if $clean-var.starts-with('@') || $clean-var.starts-with('%') {
                    if $best-type ne 'Array' && $best-type ne 'List' && $best-type ne 'Hash' && $best-type ne 'Map' {
                        return $best-type;
                    }
                }
                return "Any";
            }
        }
        return $best-type;
    }

    if $is-base-indexed { return "Any"; }
    if $clean-var.starts-with('@') { return "Array"; }
    if $clean-var.starts-with('%') { return "Hash"; }
    if $clean-var.starts-with('&') { return "Callable"; }
    if $clean-var.starts-with('$') { return "Any"; }

    return "";
}

multi sub find-variable-type(Node $node, Str $var-name --> Str) {
    my Str $alt-var = "";
    if $var-name ~~ /^ ( <[$@%&]> ) '!' ( \w+ ) $/ {
        $alt-var = "$0.$1";
    } elsif $var-name ~~ /^ ( <[$@%&]> ) '.' ( \w+ ) $/ {
        $alt-var = "$0!$1";
    }
    if ($node.type eq 'Variable' || $node.type eq 'Parameter' || $node.type eq 'Field') {
        if $node.name eq $var-name || ($alt-var ne "" && $node.name eq $alt-var) {
            return $node.detail // "";
        }
    }
    if $node.children {
        for $node.children -> $c {
            my $type = find-variable-type($c, $var-name);
            return $type if $type;
        }
    }
    return "";
}
