unit role Nimala::Raku-LSP::Handler::Hierarchy;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::AST;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::URI;
method !get-doc-from-uri(Str $uri --> Document) {
    return self.doc-store.get-or-load($uri);
}

#| Handle textDocument/prepareTypeHierarchy request.
method textDocument-prepareTypeHierarchy(:%textDocument, :%position, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Str $name = get-word-at($doc, %position<line>, %position<character>);
    return [].Array unless $name;

    my @symbols = extract-symbols($doc);
    my Any $target;
    sub find-class(@list --> Nil) {
        for @list -> Any $s {
            if ($s<kind> == 5 || $s<kind> == 11) && $s<name> eq $name { # Class or Role
                $target = $s;
                return;
            }
            find-class($s<children>) if $s<children> && !$target;
        }
    }
    find-class(@symbols);

    if !$target && self.can('index') && self.index {
        my @globals = self.index.find-symbol($name);
        my $match = @globals.first({ ($_<kind> == 5 || $_<kind> == 11) && $_<name> eq $name });
        if $match {
            $target = $match;
        }
    }

    return [].Array unless $target;

    my Str $target-uri = $target<uri> // $uri;
    my Any @res = [ $({
                name           => $target<name>,
                kind           => $target<kind>,
                uri            => $target-uri,
                range          => $target<range>,
                selectionRange => $target<range>,
                data           => $target<supertypes>
        }) ];
    return @res;
}

method typeHierarchy-supertypes(:%item, *%other --> Array) {
    my @supertypes = @(%item<data> // []);
    if !@supertypes && self.db.defined && self.db.is-open && %item<name> {
        my @matches = self.db.find-exact(%item<name>).grep({ $_<kind> == 5 || $_<kind> == 11 });
        if @matches && @matches[0]<supertypes> {
            @supertypes = @(@matches[0]<supertypes>);
        }
    }
    my Any @res;

    for @supertypes -> Str $super-name {
        my Any $found;
        my Str $found-uri;

        if self.db.defined && self.db.is-open {
            my @matches = self.db.find-exact($super-name).grep({ $_<kind> == 5 || $_<kind> == 11 });
            if @matches {
                $found = @matches[0];
                $found-uri = $found<uri>;
            }
        }

        if $found {
            @res.push: {
                name           => $found<name>,
                kind           => $found<kind>,
                uri            => $found-uri,
                range          => $found<range>,
                selectionRange => $found<range>,
                data           => $found<supertypes>
            };
        }
    }

    return @res;
}

method typeHierarchy-subtypes(:%item, *%other --> Array) {
    my Str $target-name = (%item<name> // "").Str;
    return [].Array unless $target-name;

    my Any @res;
    my %seen;

    if self.index {
        for self.index.subtypes-of($target-name) -> ($u, $s) {
            my Str $key = "$u:{$s<name>}";
            unless %seen{$key}++ {
                @res.push: {
                    name           => $s<name>,
                    kind           => $s<kind>,
                    uri            => $u,
                    range          => $s<range>,
                    selectionRange => $s<range>,
                    data           => $s<supertypes>
                };
            }
        }
    }

    return @res;
}

#| Handle textDocument/prepareCallHierarchy request.
method textDocument-prepareCallHierarchy(:%textDocument, :%position, *%other --> Array) {
    my Str $uri = %textDocument<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Str $name = get-word-at($doc, %position<line>, %position<character>);
    return [].Array unless $name;

    my @symbols = extract-symbols($doc);
    my Any $target;
    sub find-func(@list --> Nil) {
        for @list -> Any $s {
            if ($s<kind> == 12 || $s<kind> == 6) && $s<name> eq $name { # Function or Method
                $target = $s;
                return;
            }
            find-func($s<children>) if $s<children> && !$target;
        }
    }
    find-func(@symbols);

    return [].Array unless $target;

    my Any @res = [ $({
                name           => $target<name>,
                kind           => $target<kind>,
                uri            => $uri,
                range          => $target<range>,
                selectionRange => $target<range>
        }) ];
    return @res;
}

method callHierarchy-incomingCalls(:%item, *%other --> Array) {
    my Str $target-name = %item<name>;
    my Any @res;

    my @all-refs = self.index
    ?? self.index.find-references-everywhere($target-name, doc-store => self.doc-store, :!include-declaration).Array
    !! [].Array;

    my %refs-by-uri;
    for @all-refs -> %ref {
        my Str $u = %ref<uri>.Str;
        %refs-by-uri{$u} //= [];
        %refs-by-uri{$u}.push(%ref);
    }

    for %refs-by-uri.kv -> Str $u, @file-refs {
        my @symbols = (self.db.defined && self.db.is-open ?? self.db.get-file-symbols($u).Array !! []);
        if !@symbols.elems {
            my Document $d = self!get-doc-from-uri($u);
            @symbols = extract-symbols($d) if $d;
        }

        for @file-refs -> %ref {
            my Int $ref-line = +(%ref<range><start><line> // 0);
            my Int $ref-char = +(%ref<range><start><character> // 0);

            my Any $caller;
            sub find-caller(@list --> Nil) {
                for @list -> Any $s {
                    my Int $sl = +($s<range><start><line> // 0);
                    my Int $sc = +($s<range><start><character> // 0);
                    my Int $el = +($s<range><end><line> // $sl);
                    my Int $ec = +($s<range><end><character> // $sc);

                    my Bool $in-range = False;
                    if $ref-line > $sl && $ref-line < $el { $in-range = True }
                    elsif $ref-line == $sl && $ref-line == $el { $in-range = ($ref-char >= $sc && $ref-char <= $ec) }
                    elsif $ref-line == $sl { $in-range = $ref-char >= $sc }
                    elsif $ref-line == $el { $in-range = $ref-char <= $ec }

                    if $in-range {
                        if $s<kind> == 12 || $s<kind> == 6 {
                            $caller = $s;
                        }
                        find-caller($s<children>) if $s<children>;
                    }
                }
            }
            find-caller(@symbols);

            if $caller {
                @res.push: {
                    from => {
                        name           => $caller<name>,
                        kind           => $caller<kind>,
                        uri            => $u,
                        range          => $caller<range>,
                        selectionRange => $caller<range>
                    },
                    fromRanges => [ %ref<range> ]
                };
            }
        }
    }

    return @res;
}

method callHierarchy-outgoingCalls(:%item, *%other --> Array) {
    my Str $uri = %item<uri>;
    my Document $doc = self.doc-store.get($uri);
    return [].Array unless $doc;

    my Str $target-name = %item<name>;
    my @symbols = extract-symbols($doc);

    my Any $target-func;
    sub find-func(@list --> Nil) {
        for @list -> Any $s {
            if ($s<kind> == 12 || $s<kind> == 6) && $s<name> eq $target-name {
                $target-func = $s;
                return;
            }
            find-func($s<children>) if $s<children> && !$target-func;
        }
    }
    find-func(@symbols);

    return [].Array unless $target-func;

    my Any $ast = parse-document($doc);
    my Any @usages;

    sub find-usages-in-range(Node $n --> Nil) {
        my Int $sl = $n.range<start><line>;
        my Int $sc = $n.range<start><character>;
        my Int $el = $n.range<end><line>;
        my Int $ec = $n.range<end><character>;

        my Int $tsl = $target-func<range><start><line>;
        my Int $tsc = $target-func<range><start><character>;
        my Int $tel = $target-func<range><end><line>;
        my Int $tec = $target-func<range><end><character>;

        my Bool $in-target = False;
        if $sl > $tsl && $el < $tel { $in-target = True }
        elsif $sl == $tsl && $el == $tel { $in-target = ($sc >= $tsc && $ec <= $tec) }
        elsif $sl == $tsl && $el < $tel { $in-target = $sc >= $tsc }
        elsif $sl > $tsl && $el == $tel { $in-target = $ec <= $tec }

        if $in-target && $n.type eq 'Usage' && $n.name {
            # Only include if it is a method or function call (no $, @, % sigils)
            unless $n.name ~~ /^ <[\$ \@ \%]> / {
                @usages.push($n);
            }
        }

        if $n.children {
            find-usages-in-range($_) for @($n.children);
        }
    }
    find-usages-in-range($ast);

    my Any @res;
    for @usages -> Node $u {
        my Str $target-uri = $uri;
        my Any $target-range = $u.range;
        my Int $target-kind = 12; # Default: Function

        # Search all documents for the definition of the called function
        if self.db.defined && self.db.is-open {
            my @matches = self.db.find-exact($u.name).grep({ $_<kind> == 12 || $_<kind> == 6 });
            if @matches {
                $target-uri = @matches[0]<uri>;
                $target-range = @matches[0]<range>;
                $target-kind = @matches[0]<kind>;
            }
        }

        @res.push: {
            to => {
                name           => $u.name,
                kind           => $target-kind,
                uri            => $target-uri,
                range          => $target-range,
                selectionRange => $target-range
            },
            fromRanges => [ $u.range ]
        };
    }

    return @res;
}
