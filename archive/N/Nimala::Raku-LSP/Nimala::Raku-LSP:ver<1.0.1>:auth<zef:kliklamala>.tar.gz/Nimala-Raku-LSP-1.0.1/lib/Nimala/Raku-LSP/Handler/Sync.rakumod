#| Role handling document synchronization notifications:
#| didOpen, didChange, didClose, willSave, didSave and
#| workspace/didChangeWatchedFiles.
unit role Nimala::Raku-LSP::Handler::Sync;

use Nimala::Raku-LSP::Handler::Base;
also does Nimala::Raku-LSP::Handler::Base;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Analysis;
use Nimala::Raku-LSP::Client;
use Nimala::Raku-LSP::Workspace;
use Nimala::Raku-LSP::Handler::Types;
use Nimala::Raku-LSP::Cache;
use Nimala::Raku-LSP::URI;
has Hash $!pending-debounces .= new;
has Lock $!debounce-lock = Lock.new;

method pending-debounces() {
    $!debounce-lock.protect: {
        $!pending-debounces.clone;
    }
}

method cancel-debounce(Str $uri --> Nil) {
    my Str $canon-uri = canonicalize-uri($uri);
    $!debounce-lock.protect: {
        $!pending-debounces{$canon-uri}:delete if $!pending-debounces{$canon-uri}:exists;
    }
}

method cancel-all-debounces(--> Nil) {
    $!debounce-lock.protect: {
        $!pending-debounces = Hash.new;
    }
}


#| Handle textDocument/didOpen notification.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didOpen>
method textDocument-didOpen(:%textDocument, *%other --> Nil) {
    self.ensure-db-open() if self.can('ensure-db-open');
    my Str $raw-uri = %textDocument<uri> // '';
    my Str $uri = $raw-uri.chars ?? canonicalize-uri($raw-uri) !! '';
    my Int $version = %textDocument<version> // 0;
    self.doc-store.open(
        uri        => $uri,
        languageId => %textDocument<languageId>,
        version    => $version,
        text       => %textDocument<text>
    );
    my Document $doc = self.doc-store.get($uri);
    self.index.update-buffer($uri);
    self!trigger-diagnostics($doc);
}

#| Handle textDocument/didChange notification.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didChange>
method textDocument-didChange(:%textDocument, :@contentChanges, *%other --> Nil) {
    my Str $raw-uri = %textDocument<uri> // '';
    my Str $uri = $raw-uri.chars ?? canonicalize-uri($raw-uri) !! '';
    if @contentChanges.elems > 0 {
        my Int $version = %textDocument<version> // 0;
        self.doc-store.update(
            uri     => $uri,
            version => $version,
            changes => @contentChanges
        );

        self.?cancel-syntax-check($uri);

        my Promise $cur-promise;
        $!debounce-lock.protect: {
            self.latest-version{$uri} = $version;
            $cur-promise = Promise.in(0.3).then({
                    my Bool $should-run = False;
                    $!debounce-lock.protect: {
                        if ($!pending-debounces{$uri} === $cur-promise) && ((self.latest-version{$uri} // -1) == $version) {
                            $should-run = True;
                        }
                        if $!pending-debounces{$uri} === $cur-promise {
                            $!pending-debounces{$uri}:delete;
                        }
                    }
                    if $should-run {
                        my Document $doc = self.doc-store.get($uri);
                        if $doc && $doc.is-open {
                            self.index.update-buffer($uri);
                            self!trigger-diagnostics($doc);
                        }
                    }
            });
            $!pending-debounces{$uri} = $cur-promise;
        }
    }
}

#| Handle textDocument/didClose notification.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didClose>
method textDocument-didClose(:%textDocument, *%other --> Nil) {
    my Str $raw-uri = %textDocument<uri> // '';
    my Str $uri = $raw-uri.chars ?? canonicalize-uri($raw-uri) !! '';
    self.?cancel-syntax-check($uri);
    $!debounce-lock.protect: {
        $!pending-debounces{$uri}:delete if $!pending-debounces{$uri}:exists;
        self.latest-version{$uri}:delete;
    }
    self.doc-store.close(uri => $uri);
    self.index.drop-buffer($uri);
    self.?evict-semantic-cache($uri);
    self.?clear-diagnostic-cache($uri);
    self.client.notify("textDocument/publishDiagnostics", {
            uri => $uri,
            diagnostics => []
    });
}

#| Handle textDocument/willSave notification.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_willSave>
method textDocument-willSave(:%textDocument, Int :$reason = 1, *%other --> Nil) {
    my Str $raw-uri = %textDocument<uri> // "";
    my Str $uri = $raw-uri.chars ?? canonicalize-uri($raw-uri) !! "";
    self.client.log-message(Log, "Will save: $uri (reason: $reason)");
}

#| Handle textDocument/didSave notification.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didSave>
method textDocument-didSave(:%textDocument, Str :$text?, *%other --> Nil) {
    my Str $raw-uri = %textDocument<uri> // '';
    my Str $uri = $raw-uri.chars ?? canonicalize-uri($raw-uri) !! '';
    self.cancel-debounce($uri);
    if $text.defined {
        my Document $doc = self.doc-store.get($uri);
        my Int $ver = $doc.defined ?? ($doc.version // 0) !! 0;
        self.doc-store.update(uri => $uri, version => $ver, :$text);
    }

    self.index.update-buffer($uri);
    my IO::Path $path = uri-to-path($uri);
    self.index.chain-refresh-from-disk($path);

    self.?clear-diagnostic-cache($uri);
    my Document $doc = self.doc-store.get($uri);
    self!trigger-diagnostics($doc) if $doc;
}

#| Handle workspace/didChangeWatchedFiles notification.
#| See L<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeWatchedFiles>
method workspace-didChangeWatchedFiles(:@changes, *%other --> Nil) {
    for @changes -> %change {
        my Str $raw-uri = %change<uri> // '';
        my Str $uri     = $raw-uri.chars ?? canonicalize-uri($raw-uri) !! '';
        my Int $type = +(%change<type> // 0);
        if $type == 3 {
            # File deleted
            self.index.chain-remove-file($uri);
            self.client.log-message(Info, "Removed $uri from index.");
        } elsif $uri && $type > 0 {
            # File created or changed
            my IO::Path $path = uri-to-path($uri);
            if (try { $path.f }) {
                self.index.chain-refresh-from-disk($path);
                self.client.log-message(Info, "Re-indexed $uri due to external change.");
            }
        }
    }
    self.?trigger-refreshes();
}
