=begin pod

<p align="center">
  <img src="https://gitlab.com/nimala/raku/raku-lsp/-/raw/main/Raku-LSP-192.jpeg" alt="Nimala Logo" width="128" />
</p>

=head1 NAME

Nimala::Raku-LSP - Complete Raku Language Server Protocol (LSP 3.18) & Debug Adapter Protocol (DAP)

=head1 DESCRIPTION

Nimala is a full-featured Language Server Protocol (LSP 3.18) and Debug Adapter Protocol (DAP) implementation for the Raku programming language, written entirely in Raku. It provides advanced IDE intelligence, refactoring capabilities, and integrated debugging to any LSP-compatible editor (such as VS Code, Neovim, Helix, or Emacs).

=head2 Key Highlights

=item B<Broad LSP 3.18 & DAP Coverage>: 71 of 95 LSP 3.18 methods fully implemented and 2 partially (the rest are niche or low-utility), plus 22 DAP requests.
=item B<Multi-Tiered AST & Deep Type Inference>: Combines native RakuAST parsing in an isolated worker process,
resilient fallback grammars, and dynamic MRO / generic type tracking.
=item B<Multi-Root Workspace & Reactive Progress Engine>: Dynamic folder indexing, pruning, and bidirectional C<$/progress> reporting with RAII scopes.
=item B<High Performance & Low Latency>: Persistent SQLite index caching (C<.nimala/symbols.db>), prefix (completion)
and substring (workspace symbols) search, and non-blocking asynchronous event streams (C<Supply>, C<Proc::Async>,
C<Lock>).

=head2 LSP 3.18 Implementation Matrix

Of the 95 requests and notifications in the LSP 3.18 meta model, 71 are fully implemented and 2 partially; the
remaining 22 are niche or low-utility roadmap items. Each method links to its section in the
L<LSP 3.18 specification|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/>.
Full audit: L<docs/lsp-coverage.md|https://gitlab.com/nimala/raku/raku-lsp/-/blob/main/docs/lsp-coverage.md>.

=head3 1. Lifecycle & General

=item L<C<initialize>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#initialize>
=item L<C<initialized>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#initialized>
=item L<C<shutdown>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#shutdown>
=item L<C<exit>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#exit>
=item L<C<$/cancelRequest>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#cancelRequest>
=item L<C<$/progress>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#progress>

=head3 2. Document Synchronization

=item L<C<textDocument/didOpen>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didOpen>
=item L<C<textDocument/didChange>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didChange>
=item L<C<textDocument/didClose>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didClose>
=item L<C<textDocument/didSave>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_didSave>
=item L<C<textDocument/willSave>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_willSave>

=head3 3. Code Intelligence, Navigation & Editing

=item L<C<textDocument/hover>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_hover>
=item L<C<textDocument/completion>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_completion>
=item L<C<completionItem/resolve>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#completionItem_resolve>
=item L<C<textDocument/signatureHelp>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_signatureHelp>
=item L<C<textDocument/declaration>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_declaration>
=item L<C<textDocument/definition>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_definition>
=item L<C<textDocument/typeDefinition>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_typeDefinition>
=item L<C<textDocument/implementation>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_implementation>
=item L<C<textDocument/references>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_references>
=item L<C<textDocument/documentHighlight>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_documentHighlight>
=item L<C<textDocument/documentSymbol>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_documentSymbol>
=item L<C<textDocument/codeAction>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_codeAction>
=item L<C<codeAction/resolve>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeAction_resolve>
=item L<C<textDocument/codeLens>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_codeLens>
=item L<C<codeLens/resolve>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeLens_resolve>
=item L<C<textDocument/documentLink>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_documentLink>
=item L<C<textDocument/formatting>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_formatting>
=item L<C<textDocument/rangeFormatting>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_rangeFormatting>
=item L<C<textDocument/onTypeFormatting>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_onTypeFormatting>
=item L<C<textDocument/rename>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_rename>
=item L<C<textDocument/prepareRename>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_prepareRename>
=item L<C<textDocument/foldingRange>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_foldingRange>
=item L<C<textDocument/selectionRange>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_selectionRange>
=item L<C<textDocument/semanticTokens/full>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_fullRequest>
=item L<C<textDocument/semanticTokens/range>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_rangeRequest>
=item L<C<textDocument/semanticTokens/full/delta>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_deltaRequest>
=item L<C<textDocument/inlayHint>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlayHint>
=item L<C<inlayHint/resolve>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#inlayHint_resolve>
=item L<C<textDocument/inlineCompletion>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineCompletion>
=item L<C<textDocument/inlineValue>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_inlineValue>
=item L<C<textDocument/linkedEditingRange>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_linkedEditingRange>

=head3 4. Hierarchies

=item L<C<textDocument/prepareTypeHierarchy>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_prepareTypeHierarchy>
=item L<C<typeHierarchy/supertypes>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#typeHierarchy_supertypes>
=item L<C<typeHierarchy/subtypes>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#typeHierarchy_subtypes>
=item L<C<textDocument/prepareCallHierarchy>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_prepareCallHierarchy>
=item L<C<callHierarchy/incomingCalls>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#callHierarchy_incomingCalls>
=item L<C<callHierarchy/outgoingCalls>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#callHierarchy_outgoingCalls>

=head3 5. Diagnostics (Push & Pull)

=item L<C<textDocument/publishDiagnostics>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_publishDiagnostics>
=item L<C<textDocument/diagnostic>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#textDocument_diagnostic>
=item L<C<workspace/diagnostic>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_diagnostic>

=head3 6. Workspace & Server-Initiated Refreshes

=item L<C<workspace/symbol>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_symbol>
=item L<C<workspace/executeCommand>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_executeCommand>
=item L<C<workspace/didChangeWatchedFiles>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeWatchedFiles>
=item L<C<workspace/workspaceFolders>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_workspaceFolders> (partial: folders come from C<initialize> and C<workspace/didChangeWorkspaceFolders>; the server never sends this request)
=item L<C<workspace/willRenameFiles>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_willRenameFiles>
=item L<C<workspace/applyEdit>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_applyEdit>
=item L<C<workspace/codeLens/refresh>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#codeLens_refresh>
=item L<C<workspace/inlayHint/refresh>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_inlayHint_refresh>
=item L<C<workspace/semanticTokens/refresh>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#semanticTokens_refreshRequest>
=item L<C<workspace/foldingRange/refresh>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_foldingRange_refresh>
=item L<C<workspace/diagnostic/refresh>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#diagnostic_refresh>
=item L<C<workspace/inlineValue/refresh>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_inlineValue_refresh>
=item L<C<workspace/didChangeConfiguration>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeConfiguration>
=item L<C<workspace/configuration>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_configuration>
=item L<C<workspace/didChangeWorkspaceFolders>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#workspace_didChangeWorkspaceFolders>

=head3 7. Window & Client Interaction

=item L<C<window/logMessage>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_logMessage>
=item L<C<window/showMessage>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_showMessage>
=item L<C<window/showMessageRequest>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_showMessageRequest> (partial: client helper exists, no feature sends it yet)
=item L<C<window/showDocument>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_showDocument>
=item L<C<window/workDoneProgress/create>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_workDoneProgress_create>
=item L<C<window/workDoneProgress/cancel>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#window_workDoneProgress_cancel>
=item L<C<client/registerCapability>|https://microsoft.github.io/language-server-protocol/specifications/lsp/3.18/specification/#client_registerCapability>

=head2 Programmatic Usage

The server binary dispatches JSON-RPC through its own C<Nimala::Raku-LSP::Dispatcher> (method whitelist, cancellation, concurrent requests). For embedding, the handler can also be driven by C<JSON::RPC::Server>, as the test suite does, to analyze Raku code or build custom clients:


=begin code :lang<raku>
use Nimala::Raku-LSP::Handler;
use JSON::RPC::Server;

# Initialize the LSP Handler
my $handler = Nimala::Raku-LSP::Handler.new;

# Wrap it in a JSON-RPC Server
my $server = JSON::RPC::Server.new(application => $handler);

# Simulate a JSON-RPC Request (e.g., from a client)
# Handler methods use '-' for the LSP '/' (send "textDocument-hover", not "textDocument/hover")
my $request = q:to/END/;
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "processId": null,
    "rootUri": null,
    "capabilities": {}
  }
}
END

# Process the request and get the JSON-RPC response
my $response = $server.handler(json => $request);
say $response;
=end code

=head2 Debug Adapter Protocol (DAP) Architecture

Nimala includes a Debug Adapter Protocol (DAP) server (C<bin/nimala-raku-dap>). The debugger is built directly on MoarVM's native remote debugging protocol, communicating with the debuggee over loopback TCP using MessagePack framing.

=item B<Native VM-Level Execution>: The debuggee runs as standard C<raku --debug-port=<port> --debug-suspend <program>>, executing standard precompiled bytecode. This eliminates the precompilation slot mismatches, slow first launches, and compiler C<when> statement crashes of earlier statement-hook implementations.
=item B<Pure-Raku MessagePack Framing>: Communication uses a fast, dependency-free MessagePack codec and protocol client with monotonic request/response correlation and event dispatch.
=item B<Monotonic Handle Management>: Context and object handles allocated during stops are tracked in a lifecycle registry, released in batches upon resume and dropped locally on disconnect.
=item B<Bounded Expressions & Safe Inspection>: Expression evaluation, conditional breakpoints, and logpoints use a bounded expression grammar (variables, attribute/key/index access, comparisons against literals). Arbitrary method calls and mutations are refused; only the whitelisted helpers C<.gist>, C<.Str>, C<.raku> and C<.elems> run in the debuggee, at most one per stop.
=item B<Smart Stepping>: Configurable smart stepping (C<into>, C<over>, C<disable>) automatically filters out internal compiler, runtime, and NQP frames so stepping stays focused on user code.

For full architectural details, see F<docs/DEBUG.md> and F<docs/DEBUG-MOARVM.md>.

=head2 Installation & Dependencies

Nimala requires a working Raku installation (Rakudo 2026.09 recommended) and the C<sqlite3> shared library for index
persistence. Only Rakudo 2026.09 is tested. Rakudo 2024.07 runs with limitations: the debugger can abort with a MoarVM
panic, and the RakuAST-based analysis ignores signature parameters and fails on files with C<BEGIN> blocks, so the
built-in parser fills in.

=head3 Dependencies

=item B<DBIish> & B<DBDish::SQLite>: Database independent interface and SQLite driver for persistent, transactional symbol indexing (C<.nimala/symbols.db>).
=item B<JSON::Fast>: High-performance JSON parser and serializer.

=head3 Install via Zef

=begin code :lang<sh>
# Install all dependencies and Nimala LSP/DAP binaries
zef install Nimala::Raku-LSP
=end code

C<zef> puts the C<nimala-raku-lsp> and C<nimala-raku-dap> scripts into the C<bin/> directory of the repository it
installs to. Without root rights that is usually C<~/.raku/bin>, which must be in C<PATH> (for example
C<export PATH="$HOME/.raku/bin:$PATH"> in C<~/.bashrc>). Otherwise editors cannot find the server.

=head2 Security Considerations

Like standard Raku tooling, the language server executes compile-time code when inspecting documents:

=item B<Compile-Time Execution>: Background syntax checking (C<raku -c>) and native AST parsing execute C<BEGIN>, C<CHECK>, and C<INIT> blocks as well as compile-time side effects of imported modules (C<use>).
=item B<Doc Preview Evaluation>: Rendering RakuDoc to HTML (C<raku --doc=HTML>) also evaluates compile-time blocks in opened files.
=item B<Untrusted Code>: Never open untrusted Raku files or untrusted workspaces without inspecting them first. Always use isolated environments (containers or sandboxes) when reviewing unknown code.

=head2 License
Artistic-2.0

=end pod

unit module Nimala::Raku-LSP:ver<1.0.1>;

use Nimala::Raku-LSP::Dispatcher;
use Nimala::Raku-LSP::Transport::Framing;
use Nimala::Raku-LSP::Transport::Stdio;
use Nimala::Raku-LSP::Transport::Socket ();
use Nimala::Raku-LSP::Handler;
use Nimala::Raku-LSP::Handler::Types;

use JSON::Fast;

#| Re-export run-tcp-server from Transport::Socket
sub run-tcp-server(
    Str :$host = '127.0.0.1',
    Int :$port = 5007,
    Bool :$single-session = False,
    Promise :$stop-promise = Promise.new
    --> Nil) is export {
    Nimala::Raku-LSP::Transport::Socket::run-tcp-server(:$host, :$port, :$single-session, :$stop-promise);
}

#| Start the LSP server loop.
sub run-server(
    IO::Handle :$in = $*IN,
    IO::Handle :$out = $*OUT,
    Nimala::Raku-LSP::Handler :$handler = Nimala::Raku-LSP::Handler.new(:$out),
    Any :$supply = lsp-read-supply($in)
    --> Int) is export {
    my Promise $done-promise .= new;
    my Int $exit-code = 0;

    my sub write-response(Str $json --> Nil) {
        try {
            lsp-write($json, $out);
            CATCH { default { } }
        }
    }

    my Nimala::Raku-LSP::Dispatcher $dispatcher .= new(
        :$handler,
        :&write-response,
        on-exit => -> Int $code {
            $exit-code = $code;
            $done-promise.keep(True) if $done-promise.status == Planned;
            if $handler.^can('exit-handler') && $handler.exit-handler.defined {
                my $cb = $handler.exit-handler;
                $handler.exit-handler = Nil;
                $cb.($code);
            }
        }
    );

    # Process incoming messages using the provided Supply
    react {
        whenever $supply -> Str $json-request {
            $dispatcher.dispatch($json-request);
            LAST {
                done;
            }
            QUIT {
                default {
                    done;
                }
            }
        }
        whenever $done-promise {
            done;
        }
    }

    $dispatcher.await-in-flight();
    $dispatcher.stop;

    if $done-promise.status != Kept {
        # Supply ended (EOF) without exit notification
        my Int $code = $handler.state == ShuttingDown ?? 0 !! 1;
        $exit-code = $code;
        try { $handler.shutdown() if $handler.state != ShuttingDown };
        $handler.exit-code = $code if $handler.^can('exit-code');
        if $handler.^can('exit-handler') && $handler.exit-handler.defined {
            my $cb = $handler.exit-handler;
            $handler.exit-handler = Nil;
            $cb.($code);
        }
    }

    return $exit-code;
}
