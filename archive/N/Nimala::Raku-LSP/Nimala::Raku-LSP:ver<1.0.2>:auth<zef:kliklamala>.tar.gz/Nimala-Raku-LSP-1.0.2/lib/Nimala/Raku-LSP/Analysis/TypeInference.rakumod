unit module Nimala::Raku-LSP::Analysis::TypeInference;

use Nimala::Raku-LSP::Document;
use Nimala::Raku-LSP::Parser;
use Nimala::Raku-LSP::AST;
use Nimala::Raku-LSP::Analysis::Symbols;
use Nimala::Raku-LSP::Analysis::Cursor;

#| Strips Raku type smileys (:D, :U, :_) from a type name.
sub strip-type-smiley(Str $t --> Str) {
    return $t.trim.subst(/ <!after ':'> ':' <!before ':'> <[a..zA..Z_]>+ $ /, '').trim;
}

#| Unwraps an iterable/container/async type to the topic element type yielded
#| in `for`, `whenever`, `.map`, `.grep`, `.tap`, etc.
our sub unwrap-iterable-element-type(Str $expr-type, Str $raw-expr = "" --> Str) is export {
    my Str $clean = strip-type-smiley($expr-type);
    return 'Any' if !$clean || $clean eq 'Any' || $clean eq 'Mu';

    my Hash $info = parse-type-structure($clean);
    if $info<kind> eq 'generic-map' {
        return 'Pair';
    }
    if $info<kind> eq 'generic' {
        my Str $cont = $info<container>;
        if $cont eq any(<Array List Seq Positional Iterable Supply Channel Set Bag Mix Range>) {
            return strip-type-smiley($info<inner>) || 'Any';
        }
    }

    return 'Pair' if $clean eq 'Hash' || $clean eq 'Map';
    if $clean eq 'Range' {
        return ($raw-expr ~~ / <['"]> \s* '..' /) ?? 'Str' !! 'Int';
    }
    return 'Any' if $clean eq any(<Array List Seq Supply Channel Positional Iterable>);
    return $clean;
}

#| Resolves the type of an arbitrary topicalizer expression (variables, literals, constructors, chained/topic exprs).
our sub resolve-expr-type(
    Document $doc,
    Str $raw-expr,
    Int $line,
    Int $character,
    Any $workspace = Nil,
    Int :$depth = 0
    --> Str
) is export {
    return "" if $depth >= 8;
    my Str $expr = $raw-expr.trim.subst(/ \s* ';' \s* $ /, '').trim;
    return "" if $expr eq "";

    # Unwrap only outer balanced parentheses
    while $expr.starts-with('(') && $expr.ends-with(')') {
        my Int $pd = 0;
        my Bool $wraps-all = True;
        my @chars = $expr.comb;
        for @chars.kv -> Int $idx, Str $ch {
            $pd++ if $ch eq '(';
            $pd-- if $ch eq ')';
            if $pd == 0 && $idx < @chars.elems - 1 {
                $wraps-all = False;
                last;
            }
        }
        last unless $wraps-all && $pd == 0;
        $expr = $expr.substr(1, $expr.chars - 2).trim;
    }
    return "" if $expr eq "";

    # Literals before chained expression parsing
    if $expr ~~ /^ [ \' <-[\']>* \' | \" <-[\"]>* \" ] $/ {
        return 'Str';
    }
    if $expr ~~ /^ '<' ( <-[\<\>]>+ ) '>' $/ {
        return $0.Str.trim.contains(/\s/) ?? 'List' !! 'Str';
    }
    if $expr ~~ /^ ( 'qw' | 'qq' | 'q' ) \W / {
        return $0.Str eq 'qw' ?? 'List' !! 'Str';
    }
    if $expr.starts-with('[') && $expr.ends-with(']') {
        return 'Array';
    }
    if $expr.starts-with('%(') || ($expr.starts-with('{') && $expr.contains('=>')) {
        return 'Hash';
    }
    if $expr ~~ /^ '^' \s* \d+ $ / || $expr ~~ /^ <-[\"\'\(\[\{]>+ [ '..^' | '^..' | '..' ] / {
        return 'Range';
    }
    if $expr ~~ /^ <[+-]>? \d+ [ '_' \d+ ]* $ / {
        return 'Int';
    }
    if $expr ~~ /^ <[+-]>? \d+ [ '_' \d+ ]* '.' \d+ [ <[eE]> <[+-]>? \d+ ]? $ / {
        return ($expr.contains('e') || $expr.contains('E')) ?? 'Num' !! 'Rat';
    }

    # Implicit-topic-rooted expressions (e.g. `given $order { for .items { .price } }`)
    if $expr ~~ /^ \. <[\[\{\<]> / {
        my Str $rewritten = '$_' ~ $expr.substr(1);
        my Str $t = find-variable-type($doc, $rewritten, $line, $character, $workspace, :depth($depth + 1));
        return strip-type-smiley($t);
    }
    if $expr.starts-with('.') {
        my Str $rewritten = '$_' ~ $expr;
        my Str $t = find-variable-type($doc, $rewritten, $line, $character, $workspace, :depth($depth + 1));
        return strip-type-smiley($t);
    }

    # Explicit typed @-array or %-hash (preserve element vs container semantics)
    if $expr ~~ /^ ( '@' <[\!\.\*\^\?]>? <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ) ( \. .* )? $ / {
        my Str $base-var = $0.Str;
        my Str $tail = $1 ?? $1.Str !! "";
        my Str $decl-t = strip-type-smiley(
            find-variable-type($doc, $base-var, $line, $character, $workspace, :depth($depth + 1))
        );
        my Str $wrapped = ($decl-t && !$decl-t.contains('[')
            && $decl-t ne any(<Array List Seq Positional Iterable Any Mu>))
        ?? "Array[$decl-t]"
        !! ($decl-t || 'Array');
        if $tail eq "" {
            return $wrapped;
        }
        my @parts = split-chain("_" ~ $tail);
        my Str $cur = $wrapped;
        for 1 ..^ @parts.elems -> Int $idx {
            my Str $m = @parts[$idx].trim;
            $m ~~ s:g/ \( <-[\)]>* \) //;
            my Bool $is-idx = $m.contains('[') || $m.contains('{') || $m.contains('<');
            $m ~~ s:g/ \[ <-[\]]>* \] //;
            $m ~~ s:g/ \{ <-[\}]>* \} //;
            $m ~~ s:g/ \< <-[\>]>* \> //;
            $m ~~ s/^ <[\?\*\+\!\=]> \s* //;
            $m .= trim;
            my Hash $pi = parse-type-structure($cur);
            if $pi<kind> eq 'generic' && $m eq any(<grep sort reverse unique squish rotor batch flat>) {
                $cur = $is-idx ?? $pi<inner> !! $cur;
            } elsif $pi<kind> eq 'generic' && ($m eq any(<first head tail min max pick roll pop shift>) || $m eq '') {
                $cur = $pi<inner>;
            } else {
                $cur = find-variable-type($doc, $expr, $line, $character, $workspace, :depth($depth + 1));
                last;
            }
        }
        return strip-type-smiley($cur);
    }

    if $expr ~~ /
    ^ ( '%' <[\!\.\*\^\?]>? <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* )
    [ \s* \. \s* <[\?\*\+]>? ( <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ) [ \s* \( <-[\)]>* \) ]? ]? $
    / {
        my Str $base-var = $0.Str;
        my Str $meth = $1 ?? $1.Str !! "";
        my Str $decl-t = strip-type-smiley(
            find-variable-type($doc, $base-var, $line, $character, $workspace, :depth($depth + 1))
        );
        my Str $map-t;
        if $decl-t && ($decl-t.starts-with('Hash[') || $decl-t.starts-with('Map[')) {
            $map-t = $decl-t;
        } elsif $decl-t && $decl-t ne any(<Hash Map Associative Any Mu>) {
            $map-t = "Hash[Str, $decl-t]";
        } else {
            $map-t = $decl-t || 'Hash';
        }
        if $meth eq "" {
            return $map-t;
        }
        my Hash $mi = parse-type-structure($map-t);
        if $meth eq 'keys' {
            return $mi<kind> eq 'generic-map' ?? "Seq[{$mi<key>}]" !! 'Seq[Str]';
        } elsif $meth eq 'values' {
            return $mi<kind> eq 'generic-map' ?? "Seq[{$mi<value>}]" !! 'Seq[Any]';
        } elsif $meth eq 'kv' {
            return 'Seq';
        }
    }

    my Str $resolved = find-variable-type($doc, $expr, $line, $character, $workspace, :depth($depth + 1));
    return strip-type-smiley($resolved);
}

sub extract-trailing-receiver(Str $s --> Str) {
    my Int $i = $s.chars - 1;
    while $i >= 0 && $s.substr($i, 1) ~~ /\s/ { $i--; }
    return "" if $i < 0;
    my Int $end = $i;

    my $stmt-kw-open = rx/
    [ ^ | <-[\w\-]> ]
    ( 'say' | 'put' | 'print' | 'note' | 'return' | 'if' | 'unless' | 'with' | 'given' | 'for' ) $
    /;
    my $stmt-kw-ws = rx/
    [ ^ | <-[\w\-]> ]
    ( 'say' | 'put' | 'print' | 'note' | 'return' | 'if' | 'unless' | 'with' | 'given' | 'for' ) \s* $
    /;

    my sub match-open-back(Int $close-idx, Str $open, Str $close --> Int) {
        my Int $d = 1;
        my Int $j = $close-idx - 1;
        while $j >= 0 && $d > 0 {
            my Str $c = $s.substr($j, 1);
            $d++ if $c eq $close;
            $d-- if $c eq $open;
            return $j if $d == 0;
            $j--;
        }
        return -1;
    }

    loop {
        while $i >= 0 && $s.substr($i, 1) ~~ /\s/ { $i--; }
        last if $i < 0;
        my Str $ch = $s.substr($i, 1);

        if $ch eq ')' | ']' | '}' | '>' {
            my Str $open = $ch eq ')' ?? '(' !! $ch eq ']' ?? '[' !! $ch eq '}' ?? '{' !! '<';
            my Int $m = match-open-back($i, $open, $ch);
            last if $m < 0;
            my Int $k = $m - 1;
            while $k >= 0 && $s.substr($k, 1) ~~ /\s/ { $k--; }
            if $k < 0 {
                $i = $m - 1;
                last;
            }
            my Str $pk = $s.substr($k, 1);
            if $pk ~~ / <[a..zA..Z0..9_\-\x27\]\}\>\)]> / {
                my Str $before-open = $s.substr(0, $k + 1);
                if $ch eq ')' && $before-open ~~ $stmt-kw-open {
                    $i = $m - 1;
                    last;
                }
                $i = $k;
                next;
            } else {
                $i = $m - 1;
                last;
            }
        }

        if $ch ~~ / <[\w\-\x27]> / {
            while $i >= 0 && $s.substr($i, 1) ~~ / <[\w\-\x27\:]> / { $i--; }
            if $i >= 0 && $s.substr($i, 1) ~~ / <[\!\.\*\^\?\~\=]> /
            && $i > 0 && $s.substr($i - 1, 1) ~~ / <[\$\@\%\&]> / {
                $i -= 2;
                last;
            } elsif $i >= 0 && $s.substr($i, 1) ~~ / <[\$\@\%\&]> / {
                $i--;
                last;
            }
            my Int $k = $i;
            while $k >= 0 && $s.substr($k, 1) ~~ /\s/ { $k--; }
            if $k >= 0 && $s.substr($k, 1) ~~ / <[\?\*\+]> / && $k > 0 && $s.substr($k - 1, 1) eq '.' {
                $k--;
            }
            if $k >= 0 && $s.substr($k, 1) eq '.' && !($k > 0 && $s.substr($k - 1, 1) eq '.') {
                my Str $before-dot = $s.substr(0, $k);
                my Int $bk = $k - 1;
                while $bk >= 0 && $before-dot.substr($bk, 1) ~~ /\s/ { $bk--; }
                if $bk >= 0 && $before-dot.substr($bk, 1) ~~ / <[\w\)\]\}\>\"\'\x27]> /
                && $before-dot !~~ $stmt-kw-ws {
                    $i = $bk;
                    next;
                } else {
                    $i = $k - 1;
                    last;
                }
            }
            last;
        }

        last;
    }

    return $s.substr($i + 1, $end - $i).trim;
}

#| Searches enclosing block and statement-modifier topicalizers for `$_`.
our sub find-topic-type(
    Document $doc,
    Int $line is copy,
    Int $character is copy,
    Any $workspace = Nil,
    Int :$depth = 0
    --> Str
) is export {
    return 'Any' if $doc.lines-count == 0;
    return "" if $depth >= 8;

    if $line < 0 || $line >= $doc.lines-count {
        $line = max(0, $doc.lines-count - 1);
    }
    my Str $cur-line-text = $doc.line-text($line);
    if $character < 0 {
        $character = utf16-length($cur-line-text);
    }
    my Int $cursor-offset = $doc.position-to-offset($line, $character);
    $cursor-offset = max(0, min($cursor-offset, $doc.text.chars));

    # Build code mask across lines 0..$line (excluding strings, comments, Pod blocks)
    my Int $scan-line-end = ($line + 1 < $doc.line-offsets.elems)
    ?? $doc.line-offsets[$line + 1]
    !! $doc.text.chars;
    my Bool @is-code = False xx $scan-line-end;
    my Bool @is-comment = False xx $scan-line-end;
    my Bool $in-single = False;
    my Bool $in-double = False;
    my Bool $in-pod = False;
    my Str $pod-tag = "";

    for 0 .. $line -> Int $l {
        my Int $ls = $doc.line-offsets[$l];
        my Int $le = ($l + 1 < $doc.line-offsets.elems) ?? $doc.line-offsets[$l + 1] !! $doc.text.chars;
        my Str $ltext = $doc.line-text($l);
        my Int $lchars = $ltext.chars;

        my Bool $pod-line = False;
        if $in-pod {
            $pod-line = True;
            if $ltext ~~ /^ \h* '=end' \h+ $pod-tag >> / {
                $in-pod = False;
                $pod-tag = "";
            }
        } elsif $ltext ~~ /^ \h* '=begin' \h+ (\S+) / {
            $in-pod = True;
            $pod-tag = ~$0;
            $pod-line = True;
        } elsif $ltext ~~ /^ \h* '=' <[a..zA..Z]> / {
            $pod-line = True;
        }

        if $pod-line {
            $in-single = False;
            $in-double = False;
            for $ls ..^ ($ls + $lchars) -> Int $p {
                @is-comment[$p] = True;
            }
            for ($ls + $lchars) ..^ $le -> Int $p {
                @is-code[$p] = True;
            }
            next;
        }

        my %scan = scan-line-lexical($ltext, :$in-single, :$in-double);
        $in-single = ?%scan<in-single>;
        $in-double = ?%scan<in-double>;
        my @str-arr = @(%scan<is-string>);
        my @com-arr = @(%scan<is-comment>);
        for 0 ..^ $lchars -> Int $k {
            my Bool $is-com = ?(@com-arr[$k] // False);
            my Bool $is-str = ?(@str-arr[$k] // False);
            @is-comment[$ls + $k] = $is-com;
            @is-code[$ls + $k] = !$is-com && !$is-str;
        }
        for ($ls + $lchars) ..^ $le -> Int $p {
            @is-code[$p] = True;
        }
    }

    # Helper to find explicit `$_` declaration/assignment at depth 0 of a range [$from ..^ $to]
    my sub find-local-topic-binding(Int $from, Int $to --> Str) {
        return "" if $to <= $from;
        my Str $flat = "";
        my Int @offsets;
        my Int $bd = 0;
        for $from ..^ $to -> Int $p {
            if @is-code[$p] {
                my Str $ch = $doc.text.substr($p, 1);
                if $ch eq '{' {
                    $bd++;
                } elsif $ch eq '}' {
                    $bd-- if $bd > 0;
                } elsif $bd == 0 {
                    $flat ~= $ch;
                    @offsets.push($p);
                }
            } elsif $bd == 0 {
                my Str $ch = $doc.text.substr($p, 1);
                if $ch eq "\n" {
                    $flat ~= "\n";
                    @offsets.push($p);
                }
            }
        }
        return "" if $flat eq "";

        my Str $best = "";
        my Int $best-to = -1;

        my $decl-rx = rx/
        [ ^ | <-[\w\-]> ] [ 'my' | 'our' | 'state' ] \s+
        ( <[\w\-]>+ [ '::' <[\w\-]>+ ]* [ '[' <-[\]]>* ']' ]? [ ':' <[a..zA..Z_]>+ ]? )
        \s+ '$_' <!before \w>
        /;
        for $flat.match($decl-rx, :g) -> $m {
            if $m.to > $best-to {
                $best-to = $m.to;
                $best = strip-type-smiley($m[0].Str);
            }
        }

        my $assign-rx = rx/ <!after <[\w\$\@\%\&]>> '$_' \s* [ '=' <!before '='> | ':=' ] \s* ( <-[;\n]>+ ) /;
        for $flat.match($assign-rx, :g) -> $m {
            if $m.to > $best-to {
                my Int $rhs-off = @offsets[min($m.from, @offsets.elems - 1)] // $from;
                my %rhs-pos = $doc.position-at($rhs-off);
                my Str $rhs = $m[0].Str.trim;
                if $rhs ne '$_' {
                    my Str $t = resolve-expr-type(
                        $doc, $rhs, %rhs-pos<line>, %rhs-pos<character>, $workspace, :depth($depth + 1)
                    );
                    if $t {
                        $best-to = $m.to;
                        $best = $t;
                    }
                }
            }
        }
        return $best;
    }

    # Step A: Statement modifier on current statement (.meth given/with/without/for EXPR)
    {
        my Int $cur-ls = $doc.line-offsets[$line];
        my Int $stmt-start = $cur-ls;
        my Int $b = $cursor-offset - 1;
        while $b >= $cur-ls {
            if @is-code[$b] {
                my Str $ch = $doc.text.substr($b, 1);
                if $ch eq ';' | '{' | '}' {
                    $stmt-start = $b + 1;
                    last;
                }
            }
            $b--;
        }

        my Str $after-code = "";
        my Int $pd = 0;
        my Int $kd = 0;
        my Int $bd = 0;
        for $cursor-offset ..^ $scan-line-end -> Int $p {
            next if @is-comment[$p];
            my Str $ch = $doc.text.substr($p, 1);
            if @is-code[$p] {
                if $ch eq '(' { $pd++; }
                elsif $ch eq ')' {
                    last if $pd == 0;
                    $pd--;
                } elsif $ch eq '[' { $kd++; }
                elsif $ch eq ']' {
                    last if $kd == 0;
                    $kd--;
                } elsif $ch eq '{' {
                    $bd++;
                } elsif $ch eq '}' {
                    last if $bd == 0;
                    $bd--;
                } elsif $ch eq ';' && $pd == 0 && $kd == 0 && $bd == 0 {
                    last;
                }
            }
            $after-code ~= $ch if $pd == 0 && $kd == 0 && $bd == 0;
        }
        if $after-code ~~ / <|w> ( 'given' | 'with' | 'without' | 'for' ) \s+ ( <-[;\n\{]>+ ) $ / {
            my Str $mod-kw = $0.Str;
            my Str $mod-expr = $1.Str.trim;
            if $mod-expr && $mod-expr ne '$_' && !$mod-expr.contains('->') {
                my %st-pos = $doc.position-at($stmt-start);
                my Str $raw-t = resolve-expr-type(
                    $doc, $mod-expr, %st-pos<line>, %st-pos<character>, $workspace, :depth($depth + 1)
                );
                if $raw-t {
                    return $mod-kw eq 'for'
                    ?? unwrap-iterable-element-type($raw-t, $mod-expr)
                    !! $raw-t;
                }
            }
        }
    }

    # Step B: Collect enclosing `{` offsets from innermost to outermost
    my Int @enclosing-braces;
    my Int $close-braces = 0;
    my Int $p = $cursor-offset - 1;
    while $p >= 0 {
        if @is-code[$p] {
            my Str $ch = $doc.text.substr($p, 1);
            if $ch eq '}' {
                $close-braces++;
            } elsif $ch eq '{' {
                if $close-braces > 0 {
                    $close-braces--;
                } else {
                    @enclosing-braces.push($p);
                }
            }
        }
        $p--;
    }

    # Step C: Walk enclosing blocks from innermost to outermost
    my Int $upper-off = $cursor-offset;
    for @enclosing-braces.kv -> Int $bi, Int $brace-off {
        # 1. Explicit local `$_` binding inside this block before the nested boundary/cursor
        my Str $local-t = find-local-topic-binding($brace-off + 1, $upper-off);
        return $local-t if $local-t;

        # 2. Extract block header before `$brace-off`
        my Int $outer-bound = ($bi + 1 < @enclosing-braces.elems) ?? @enclosing-braces[$bi + 1] + 1 !! 0;
        my Int $min-off = max($outer-bound, $brace-off - 600);
        my Int $h = $brace-off - 1;
        my Int $pd = 0;
        my Int $kd = 0;
        my Int $bd = 0;
        my Str $rev-hdr = "";
        my Int $hdr-start = $brace-off;

        while $h >= $min-off {
            my Str $ch = $doc.text.substr($h, 1);
            if @is-code[$h] {
                if $ch eq ')' { $pd++; }
                elsif $ch eq '(' { $pd-- if $pd > 0; }
                elsif $ch eq ']' { $kd++; }
                elsif $ch eq '[' { $kd-- if $kd > 0; }
                elsif $ch eq '}' {
                    last if $pd == 0 && $kd == 0 && $bd == 0;
                    $bd++;
                } elsif $ch eq '{' {
                    last if $pd == 0 && $kd == 0 && $bd == 0;
                    $bd-- if $bd > 0;
                } elsif $ch eq ';' && $pd == 0 && $kd == 0 && $bd == 0 {
                    last;
                }
                $rev-hdr ~= $ch;
                $hdr-start = $h;
            } elsif !@is-comment[$h] {
                $rev-hdr ~= $ch;
                $hdr-start = $h;
            } else {
                $rev-hdr ~= ($ch eq "\n" ?? "\n" !! " ");
                $hdr-start = $h;
            }
            $h--;
        }

        my Str $header = $rev-hdr.flip.trim;
        my %hdr-pos = $doc.position-at($hdr-start);
        my Int $hl = %hdr-pos<line>;
        my Int $hc = %hdr-pos<character>;

        # 3. Routine / package boundary (resets `$_` unless explicitly typed or `method m($_:)`)
        if $header ~~ /
        [ ^ | <[=(\,\;\s]> ] <!after '.'>
        [ [ 'my' | 'our' | 'state' | 'has' ] \s+ ]?
        [ [ 'multi' | 'proto' | 'only' ] \s+ ]?
        ( 'submethod' | 'method' | 'sub' | 'class' | 'role' | 'grammar' | 'module' | 'package' ) >>
        / {
            my Str $decl = $0.Str;
            if ($decl eq 'submethod' | 'method' | 'sub')
            && $header ~~ / '(' ( <-[\(\)]>* [ '(' <-[\)]>* ')' <-[\(\)]>* ]* ) ')' / {
                my Str $sig = $0.Str;
                if $sig ~~ / ( <[A..Z]> <[a..zA..Z0..9_\:\-\[\]]>* [ ':' <[a..zA..Z_]>+ ]? ) \s+ '$_' <!before \w> / {
                    return strip-type-smiley($0.Str);
                }
                if $decl ne 'sub' && $sig ~~ / [ ^ | ',' ] \s* '$_' \s* ':' / {
                    return find-variable-type($doc, 'self', $hl, $hc, $workspace, :depth($depth + 1)) || 'Any';
                }
            }
            return 'Any';
        }

        # 4. Pointy block (`->` / `<->`, excluding `-->`)
        if $header ~~ / ^ (.*?) <!after '-'> [ '->' | '<->' ] \s* ( <-[\{\};]>+ ) $ / {
            my Str $pre-arrow = $0.Str.trim;
            my Str $param-str = $1.Str.trim;
            $param-str ~~ s/^ '(' \s* (.*) \s* ')' $/$0/;
            my Str $p0 = ($param-str.split(',')[0] // "").trim;
            if $p0 ~~ / ( <[A..Z]> <[a..zA..Z0..9_\:\-\[\]]>* [ ':' <[a..zA..Z_]>+ ]? ) \s+ '$_' <!before \w> / {
                return strip-type-smiley($0.Str);
            } elsif $p0 ~~ /^ '$_' [ \s* ':' | \s* $ ] / {
                $header = $pre-arrow;
            } else {
                # Non-$_ pointy parameter binds its own variable; keep outer $_
                $upper-off = $brace-off;
                next;
            }
        }

        # 5. CATCH block
        if $header ~~ / [ ^ | <-[\w\-]> ] 'CATCH' \s* $ / {
            return 'Exception';
        }

        # 6. `when Type` type narrowing
        if $header ~~ /
        [ ^ | <-[\w\-]> ] 'when' \s+
        ( <[A..Z]> <[a..zA..Z0..9_\-]>* [ '::' <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ]* [ '[' <-[\]]>* ']' ]? )
        [ ':' <[a..zA..Z_]>+ ]? \s* $
        / {
            return $0.Str;
        }

        # 7. Block-taking methods (EXPR.map({ }), .grep({ }), .first({ }), .tap({ }), .then({ }), etc.)
        if $header ~~ /
        ^ (.*?) \s* \. \s* <[\?\*\+]>?
        ( 'map' | 'grep' | 'first' | 'sort' | 'classify' | 'categorize' | 'unique' | 'squish' | 'tap' | 'then' )
        \s* [ '(' | ':' ] \s* $
        / {
            my Str $raw-pre = $0.Str;
            my Str $meth-op = $1.Str;
            my Str $recv = extract-trailing-receiver($raw-pre);
            if $recv {
                my Str $recv-type = resolve-expr-type($doc, $recv, $hl, $hc, $workspace, :depth($depth + 1));
                if $meth-op eq 'then' {
                    return $recv-type || 'Promise';
                }
                if $recv-type {
                    return unwrap-iterable-element-type($recv-type, $recv);
                }
            }
        }

        # 8. `given` / `with` / `orwith` / `without`
        if $header ~~ / [ ^ | <-[\w\-]> ] ( 'given' | 'with' | 'orwith' | 'without' ) \s+ ( .+ ) $ / {
            my Str $expr = $1.Str.trim;
            if $expr eq '$_' {
                $upper-off = $brace-off;
                next;
            }
            my Str $resolved = resolve-expr-type($doc, $expr, $hl, $hc, $workspace, :depth($depth + 1));
            return $resolved if $resolved;
            return 'Any';
        }

        # 9. `for` / `whenever`
        if $header ~~ / [ ^ | <-[\w\-]> ] ( 'for' | 'whenever' ) \s+ ( .+ ) $ / {
            my Str $expr = $1.Str.trim;
            my Str $raw-t = resolve-expr-type($doc, $expr, $hl, $hc, $workspace, :depth($depth + 1));
            return unwrap-iterable-element-type($raw-t, $expr) if $raw-t;
            return 'Any';
        }

        $upper-off = $brace-off;
    }

    # Step D: Top-level explicit `$_` binding at file scope (brace-depth 0)
    my Str $top-t = find-local-topic-binding(0, $upper-off);
    return $top-t if $top-t;

    return 'Any';
}

#| Parse a type string into structured metadata (generic container, inner type, map key/value)
our proto sub parse-type-structure(|) is export {*}
multi sub parse-type-structure(Str $type-str --> Hash) {
    my Str $t = $type-str.trim;
    return %{ kind => 'unknown', name => '' } if $t eq '';

    if $t ~~ /^ ( <[a..zA..Z0..9_\:\-]>+ ) \s* '[' \s* (.*) \s* ']' $/ {
        my Str $container = $0.Str.trim;
        my Str $inner = $1.Str.trim;
        if $container eq 'Hash' || $container eq 'Map' {
            if $inner.contains(',') {
                my ($k, $v) = $inner.split(',', 2)».trim;
                return %{
                    kind => 'generic-map',
                    container => $container,
                    key => $k,
                    value => $v,
                    name => "$container\[$inner\]"
                };
            } else {
                return %{
                    kind => 'generic-map',
                    container => $container,
                    key => 'Any',
                    value => $inner,
                    name => "$container\[$inner\]"
                };
            }
        }
        return %{
            kind => 'generic',
            container => $container,
            inner => $inner,
            name => "$container\[$inner\]"
        };
    }

    return %{ kind => 'simple', name => $t };
}
our proto sub split-chain(|) is export {*}
multi sub split-chain(Str $expr --> Array[Str]) {
    my Str @parts;
    my Str $current = "";
    my Int $paren-depth = 0;
    my Int $bracket-depth = 0;
    my Int $brace-depth = 0;
    my Int $angle-depth = 0;
    my Bool $in-single-quote = False;
    my Bool $in-double-quote = False;

    for $expr.comb -> $ch {
        if $ch eq "'" && !$in-double-quote {
            $in-single-quote = !$in-single-quote;
            $current ~= $ch;
        } elsif $ch eq '"' && !$in-single-quote {
            $in-double-quote = !$in-double-quote;
            $current ~= $ch;
        } elsif $in-single-quote || $in-double-quote {
            $current ~= $ch;
        } elsif $ch eq '(' {
            $paren-depth++;
            $current ~= $ch;
        } elsif $ch eq ')' {
            $paren-depth-- if $paren-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '[' {
            $bracket-depth++;
            $current ~= $ch;
        } elsif $ch eq ']' {
            $bracket-depth-- if $bracket-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '{' {
            $brace-depth++;
            $current ~= $ch;
        } elsif $ch eq '}' {
            $brace-depth-- if $brace-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '<' {
            $angle-depth++;
            $current ~= $ch;
        } elsif $ch eq '>' {
            $angle-depth-- if $angle-depth > 0;
            $current ~= $ch;
        } elsif $ch eq '.' && !($current.chars == 1 && $current ~~ /<[$@%&]>/) && $paren-depth == 0 && $bracket-depth == 0 && $brace-depth == 0 && $angle-depth == 0 {
            @parts.push($current.trim) if $current.trim ne "";
            $current = "";
        } else {
            $current ~= $ch;
        }
    }
    @parts.push($current.trim) if $current.trim ne "";
    return @parts;
}

#| Search the AST for a variable declaration and return its type
our proto sub find-variable-type(|) is export {*}
multi sub find-variable-type(
    Document $doc,
    Str $var-name,
    Int $line is copy = -1,
    Int $character is copy = -1,
    Any $workspace = Nil,
    Int :$depth = 0
    --> Str
) {
    return "" if $depth > 8;
    my @parts = split-chain($var-name);
    if @parts.elems > 1 {
        my $base-type = find-variable-type($doc, @parts[0].trim, $line, $character, $workspace, :$depth);

        for 1..^@parts.elems -> $i {
            return "" unless $base-type;
            my $raw-part = @parts[$i].trim;
            next if $raw-part eq "";

            my $clean-part = $raw-part;
            while $clean-part ~~ s:g/ \( <-[\)]>* \) // { }
            my Bool $is-indexed = $clean-part.contains('[') || $clean-part.contains('{') || $clean-part.contains('<');
            my $meth = $clean-part;
            $meth ~~ s:g/ \[ <-[\]]>* \] //; # remove array indexing
            $meth ~~ s:g/ \{ <-[\}]>* \} //; # remove hash indexing
            $meth ~~ s:g/ \< <-[\>]>* \> //; # remove hash indexing
            $meth ~~ s/^ <[\?\*\+\!\=]> \s* //; # strip dotty modifier
            $meth = $meth.trim;

            if $meth eq 'new' || $meth eq 'bless' {
                # Implicitly returns the class itself
                next;
            }

            my Hash $type-info = parse-type-structure($base-type);

            # Check Core Chaining / Unwrapping rules
            if $type-info<kind> eq 'generic' {
                # Container-preserving operations
                if $meth eq 'grep' || $meth eq 'sort' || $meth eq 'reverse' || $meth eq 'unique' || $meth eq 'squish' || $meth eq 'rotor' || $meth eq 'batch' || $meth eq 'flat' {
                    if $is-indexed {
                        $base-type = $type-info<inner>;
                    }
                    next;
                }
                # Element-extracting operations
                if $meth eq 'first' || $meth eq 'head' || $meth eq 'tail' || $meth eq 'min' || $meth eq 'max' || $meth eq 'pick' || $meth eq 'roll' || $meth eq 'pop' || $meth eq 'shift' || $meth eq '' {
                    $base-type = $type-info<inner>;
                    next;
                }
                # Asynchronous resolution
                if $type-info<container> eq 'Promise' && ($meth eq 'result' || $meth eq 'await') {
                    $base-type = $type-info<inner>;
                    next;
                }
                if $type-info<container> eq 'Supply' {
                    if $meth eq 'tap' {
                        $base-type = 'Tap';
                        next;
                    }
                    if $meth eq 'wait' {
                        $base-type = $type-info<inner>;
                        next;
                    }
                }
            } elsif $type-info<kind> eq 'generic-map' {
                if $meth eq 'keys' {
                    $base-type = "Seq\[{$type-info<key>}\]";
                    next;
                }
                if $meth eq 'values' {
                    $base-type = "Seq\[{$type-info<value>}\]";
                    next;
                }
                if $meth eq 'kv' {
                    $base-type = "Seq";
                    next;
                }
                if $is-indexed {
                    $base-type = $type-info<value>;
                    next;
                }
            } else {
                # Simple non-parameterized Array/Hash core operations
                if $base-type eq 'Array' || $base-type eq 'List' || $base-type eq 'Seq' {
                    if $meth eq 'grep' || $meth eq 'sort' || $meth eq 'reverse' || $meth eq 'unique' || $meth eq 'flat' {
                        next;
                    }
                    if $meth eq 'first' || $meth eq 'head' || $meth eq 'tail' || $is-indexed {
                        $base-type = "Any";
                        next;
                    }
                }
                if $base-type eq 'Supply' && $meth eq 'tap' {
                    $base-type = 'Tap';
                    next;
                }
                if $base-type eq 'Hash' || $base-type eq 'Map' {
                    if $meth eq 'keys' { $base-type = "Seq[Str]"; next; }
                    if $meth eq 'values' { $base-type = "Seq[Any]"; next; }
                    if $meth eq 'kv' { $base-type = "Seq"; next; }
                }
            }

            # Custom method / MRO resolution
            my $found-type = "";
            my $search-class = ($type-info<kind> eq 'generic' || $type-info<kind> eq 'generic-map')
            ?? $type-info<container>
            !! $base-type;

            if $workspace && $workspace.can('find-method-return-type') {
                $found-type = $workspace.find-method-return-type($search-class, $meth);
            }
            if !$found-type && $doc {
                my @doc-syms = extract-symbols($doc);
                sub find-in-doc-tree(@list) {
                    for @list -> $s {
                        if ($s<name> // "") eq $search-class && $s<children> {
                            for @($s<children>) -> $c {
                                if ($c<name> // "") eq $meth {
                                    my Str $det = $c<detail> // "";
                                    if $det ~~ / ( 'returns' | '-->' ) \s* ( <[a..zA..Z0..9_\:\-\[\]\s,]>+ ) / {
                                        return $1.Str.trim.subst(/ \s* '(' \w+ ')' \s* $/, '').trim;
                                    }
                                }
                            }
                        }
                        my $res = find-in-doc-tree($s<children>) if $s<children>;
                        return $res if $res;
                    }
                    return "";
                }
                $found-type = find-in-doc-tree(@doc-syms);
            }

            if $found-type && $is-indexed {
                my Hash $found-info = parse-type-structure($found-type);
                if $found-info<kind> eq 'generic' {
                    $found-type = $found-info<inner>;
                } elsif $found-info<kind> eq 'generic-map' {
                    $found-type = $found-info<value>;
                }
            }

            $base-type = $found-type;
        }
        return $base-type;
    }

    # Strip indexing from the base variable name
    my $clean-var = $var-name;
    my Bool $is-base-indexed = $var-name.contains('[') || $var-name.contains('{') || $var-name.contains('<');
    $clean-var ~~ s/ \[ .* \] $//;
    $clean-var ~~ s/ \{ .* \} $//;
    $clean-var ~~ s/ \< .* \> $//;

    if $clean-var ~~ /
    ^ <[A..Z]> <[a..zA..Z0..9_\-]>*
    [ '::' <[a..zA..Z_]> <[a..zA..Z0..9_\-]>* ]*
    [ '[' <-[\]]>* ']' ]?
    [ ':' <[a..zA..Z_]>+ ]? $
    / {
        return $clean-var;
    }

    if $line == -1 {
        $line = $doc.lines-count - 1;
        $line = 0 if $line < 0;
    }

    my $offset = ($character == -1)
    ?? $doc.text.chars
    !! $doc.position-to-offset($line, $character);

    if $clean-var eq 'self' && $line.defined {
        if $workspace && $character.defined {
            my @enclosing = $workspace.find-enclosing-symbols($doc.uri, $line, $character);
            for @enclosing.reverse -> $s {
                if $s<kind> == 5 || $s<kind> == 11 {
                    return $s<name>;
                }
            }
        }
        my @syms = extract-symbols($doc);
        my $enclosing-class = "";
        sub search(@list) {
            for @list -> $s {
                if $s<kind> == 5 || $s<kind> == 11 { # Class/Role
                    if $s<range><start><line> <= $line <= $s<range><end><line> {
                        $enclosing-class = $s<name>;
                    }
                }
                search($s<children>) if $s<children>;
            }
        }
        search(@syms);
        return $enclosing-class if $enclosing-class;
    }

    if $clean-var eq '$_' {
        my Str $topic-type = find-topic-type($doc, $line, $character, $workspace, :$depth);
        if $topic-type {
            if $is-base-indexed {
                my Hash $info = parse-type-structure($topic-type);
                if $info<kind> eq 'generic' {
                    return $info<inner>;
                } elsif $info<kind> eq 'generic-map' {
                    return $info<value>;
                } else {
                    return 'Any';
                }
            }
            return $topic-type;
        }
        return 'Any';
    }

    my $best-type = "";
    my $best-offset = -1;

    my Str $alt-var = "";
    if $clean-var ~~ /^ ( <[$@%&]> ) '!' ( \w+ ) $/ {
        $alt-var = "$0.$1";
    } elsif $clean-var ~~ /^ ( <[$@%&]> ) '.' ( \w+ ) $/ {
        $alt-var = "$0!$1";
    }

    # 1. Native Symbols candidate (only from cache - never synchronous parse on keystroke path)
    if $doc.native-symbols.defined && $doc.native-symbols-version == $doc.version {
        my @syms = flatten-native-tree(@($doc.native-symbols));
        for @syms -> $s {
            if ($s<kind> // '') eq 'variable_decl'
            && (($s<name> // '') eq $clean-var || ($alt-var ne "" && ($s<name> // '') eq $alt-var))
            && $s<type> {
                my $s-off = $s<from> // 0;
                if $s-off <= $offset && $s-off > $best-offset {
                    $best-offset = $s-off;
                    $best-type = $s<type>;
                }
            }
        }
    }

    # 2. Regex Fallback candidate (only if not found by native symbols)
    if $best-offset == -1 {
        my $regex = / [ 'my' | 'our' | 'has' | 'state' | ',' | '(' | '->' ] \s* ( <[\w\-]>+ [ '::' <[\w\-]>+ ]* [ '[' \s* <[\w\:\-\s,]>+ \s* ']' ]? [ ':' <[a..zA..Z]>+ ]? ) \s+ [ $clean-var | <?{ $alt-var ne "" }> $alt-var ] /;
        for $doc.text.match($regex, :g) -> $m {
            if $m.to <= $offset && $m.to > $best-offset {
                my $t = $m[0].Str;
                if $t ne 'my' && $t ne 'our' && $t ne 'has' && $t ne 'state' && $t ne 'sub' && $t ne 'method' {
                    $best-offset = $m.to;
                    $best-type = $t.subst(/ <!after ":"> ":" <!before ":"> <[a..zA..Z]>+ $/, '');
                }
            }
        }
    }

    # 3. Custom AST candidate (fallback if nothing found yet)
    if $best-offset == -1 {
        my $ast = parse-document($doc);
        if $ast {
            my $t = find-variable-type($ast, $clean-var);
            if !$t && $alt-var {
                $t = find-variable-type($ast, $alt-var);
            }
            if $t {
                $best-type = $t;
                $best-offset = 0; # arbitrary, just to mark it found
            }
        }
    }

    # 4. Advanced Assignment candidate
    # Scan backward line by line
    my $assign-regex = / [ $clean-var | <?{ $alt-var ne "" }> $alt-var ] \s* [ '=' | '.=' ] \s* ( .* ) /;
    for (0..$line).reverse -> $l {
        my $line-text = $doc.line-text($l);
        if $line-text ~~ $assign-regex {
            # Assignment found! Calculate its approximate offset
            my $assign-offset = $doc.position-to-offset($l, $doc.utf16-column($l, $/.to));
            if $assign-offset <= $offset && $assign-offset > $best-offset {
                my $rhs = $/.list[0].Str;
                $rhs ~~ s/ ';' \s* $ //;

                if $rhs ~~ / ( <[A..Z]> <[a..zA..Z0..9_\:\-]>* ) \s* \. \s* [ 'new' | 'bless' ] / {
                    $best-offset = $assign-offset;
                    $best-type = $/.list[0].Str;
                } elsif $rhs ~~ / ( <[\$\@\%\&]> <[a..zA..Z0..9_\-]>+ ) \s* \. \s* ( <[a..zA..Z0..9_\-]>+ ) / {
                    my $var-base = $/.list[0].Str;
                    my $meth = $/.list[1].Str;
                    my $base-type = find-variable-type($doc, $var-base, $l, 0, $workspace);
                    if $base-type && $workspace && $workspace.can('find-method-return-type') {
                        my $meth-type = $workspace.find-method-return-type($base-type, $meth);
                        if $meth-type {
                            $best-offset = $assign-offset;
                            $best-type = $meth-type;
                        }
                    }
                }
            }
            # We only look at the most recent assignment, so break the loop
            last;
        }
    }

    if $best-type {
        if $is-base-indexed {
            my Hash $info = parse-type-structure($best-type);
            if $info<kind> eq 'generic' {
                return $info<inner>;
            } elsif $info<kind> eq 'generic-map' {
                return $info<value>;
            } else {
                if $clean-var.starts-with('@') || $clean-var.starts-with('%') {
                    if $best-type ne 'Array' && $best-type ne 'List' && $best-type ne 'Hash' && $best-type ne 'Map' {
                        return $best-type;
                    }
                }
                return "Any";
            }
        }
        return $best-type;
    }

    if $is-base-indexed { return "Any"; }
    if $clean-var.starts-with('@') { return "Array"; }
    if $clean-var.starts-with('%') { return "Hash"; }
    if $clean-var.starts-with('&') { return "Callable"; }
    if $clean-var.starts-with('$') { return "Any"; }

    return "";
}

multi sub find-variable-type(Node $node, Str $var-name --> Str) {
    my Str $alt-var = "";
    if $var-name ~~ /^ ( <[$@%&]> ) '!' ( \w+ ) $/ {
        $alt-var = "$0.$1";
    } elsif $var-name ~~ /^ ( <[$@%&]> ) '.' ( \w+ ) $/ {
        $alt-var = "$0!$1";
    }
    if ($node.type eq 'Variable' || $node.type eq 'Parameter' || $node.type eq 'Field') {
        if $node.name eq $var-name || ($alt-var ne "" && $node.name eq $alt-var) {
            return $node.detail // "";
        }
    }
    if $node.children {
        for $node.children -> $c {
            my $type = find-variable-type($c, $var-name);
            return $type if $type;
        }
    }
    return "";
}
