class Red::AST::Comment
-----------------------

Represents a comment

