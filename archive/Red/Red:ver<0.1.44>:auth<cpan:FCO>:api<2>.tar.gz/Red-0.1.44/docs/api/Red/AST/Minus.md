class Red::AST::Minus
---------------------

Represents a select minus other select

