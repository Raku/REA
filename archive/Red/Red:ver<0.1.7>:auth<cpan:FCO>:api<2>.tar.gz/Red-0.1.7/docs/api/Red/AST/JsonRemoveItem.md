class Red::AST::JsonRemoveItem
------------------------------

Represents the operation to remove a json item

