class Red::AST::Sum
-------------------

Represents a sum operation

class Red::AST::Sub
-------------------

Represents a subtraction operation

class Red::AST::Eq
------------------

Represents a equality operation

class Red::AST::Ne
------------------

Represents a not equality operation

class Red::AST::Lt
------------------

Represents a less than operation

class Red::AST::Gt
------------------

Represents a greater than operation

class Red::AST::Le
------------------

Represents a less than equal operation

class Red::AST::Ge
------------------

Represents a greater then equal operation

class Red::AST::AND
-------------------

Represents a AND operation

class Red::AST::OR
------------------

Represents a OR operation

class Red::AST::Mul
-------------------

Represents a multiplication operation

class Red::AST::Div
-------------------

Represents a division operation

class Red::AST::Mod
-------------------

Represents a module operation

class Red::AST::Concat
----------------------

Represents a concatenation operation

class Red::AST::Like
--------------------

Represents a like operation

class Red::AST::NotIn
---------------------

Represents a not in operation

class Red::AST::In
------------------

Represents a in operation

