# Contributing

Your pull requests to [Red](https://github.com/FCO/Red) are very welcome.

Your contributions here will be credited in the Red README.md file. Your name from the commit log will be used. If you'd like to be credited under a different name, please add it to the local CREDITS file (or ask someone to do it for you until you have commit privileges).

If you have any questions regarding contributing to this project, please ask in the #perl6 IRC channel.

## Squashathon

The list of issues for the squashathon can be found here: https://github.com/FCO/Red/labels/Documentation
