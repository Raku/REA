Red::AST
--------

### method not

```perl6
method not() returns Mu
```

Returns the nagation of the AST.

### method Bool

```perl6
method Bool() returns Bool(Any)
```

If inside of a block for ResultSeq mothods throws a control exception and populates all possibilities

### method transpose

```perl6
method transpose(
    &func
) returns Mu
```

Transposes the AST tree running the function.

### method tables

```perl6
method tables() returns Mu
```

Returns a list with all the tables used on the AST

