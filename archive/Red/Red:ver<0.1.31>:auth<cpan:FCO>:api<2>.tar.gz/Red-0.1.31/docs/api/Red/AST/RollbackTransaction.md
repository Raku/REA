class Red::AST::RollbackTransaction
-----------------------------------

AST to run a rollback

