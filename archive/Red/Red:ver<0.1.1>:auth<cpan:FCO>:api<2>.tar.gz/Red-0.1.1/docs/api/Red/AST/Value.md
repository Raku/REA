class Red::AST::Value
---------------------

Represents a value

