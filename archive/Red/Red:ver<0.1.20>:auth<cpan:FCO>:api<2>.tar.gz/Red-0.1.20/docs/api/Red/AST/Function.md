class Red::AST::Function
------------------------

Represents a function call

