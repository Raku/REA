class Red::AST::DropColumn
--------------------------

Represents an alter table drop column

