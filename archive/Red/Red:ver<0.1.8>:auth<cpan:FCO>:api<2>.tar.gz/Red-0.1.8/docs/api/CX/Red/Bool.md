CX::Red::Bool
-------------

class CX::Red::Bool
-------------------

Control Exception to help to understand what's happening inside of blocks. Throwed on Red::AST.Bool

