# Special Vars

## `$*RED-FALLBACK`

`Bool`, defined if Red should fallback to original methods if the Red one has failed.
