Red::ResultSeqSeq
-----------------

### method elems

```perl6
method elems() returns Mu
```

run SQL query to get how many elements

### method AT-POS

```perl6
method AT-POS(
    $key
) returns Mu
```

return a ResultSeq for that index

