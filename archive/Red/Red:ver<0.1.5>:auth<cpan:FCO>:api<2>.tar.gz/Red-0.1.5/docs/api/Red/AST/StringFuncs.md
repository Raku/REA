

Base role for string functions

class Red::AST::Substring
-------------------------

Represents a substring call

