class Red::AST::IsDefined
-------------------------

Represents "is defined" operation usualy defined as: type IS NULL

