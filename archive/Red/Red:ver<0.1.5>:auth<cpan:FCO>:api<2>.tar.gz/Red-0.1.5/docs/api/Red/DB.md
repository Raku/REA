Red::DB
-------

### sub get-RED-DB

```perl6
sub get-RED-DB() returns Mu
```

Returns the database connection

