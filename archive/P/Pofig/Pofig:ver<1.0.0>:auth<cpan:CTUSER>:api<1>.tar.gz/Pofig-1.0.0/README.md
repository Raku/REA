# About

Pofig is a Perl6 module and command line tool to detect system parameters and features. Currently it can detect OS name, version, kernel version, Linux distro name and version, architecture name.


