# P6TK
A library that lets you use Tk in Perl 6

## using this
At the moment, you need the Tcl app "wish" installed and in your PATH for this to work. I'll fix this at some point
