# Things to do

* [ ] File should probably be a distinct object. Right now it's a key and a config, and lots of things are done on it, but it's not clear how to add a new file, for instance. It would be much easier if cached files could be created, compiled and handled in an independent way; that way, it would be easier to add secondary files to the cache.

* [ ] Once file handling is done, it would be easier to add (or eliminate) files from the cache.
