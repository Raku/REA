# Examples for Pod::Load

This directory contains a "sanitized" version of the module itself,
devoid of all executable code. Print it with:

     perl6 -I../../lib -e 'use Pod::Load; .perl.say for load("pod-load-clean.pod6")'


You can skip the `-I` part if it's already installed.
