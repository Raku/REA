use v6;


module P6TCI;



=begin pod

Don't need to actually do anything.

=end pod
