[![Actions Status](https://github.com/lizmat/P5lcfirst/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/P5lcfirst/actions) [![Actions Status](https://github.com/lizmat/P5lcfirst/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/P5lcfirst/actions) [![Actions Status](https://github.com/lizmat/P5lcfirst/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/P5lcfirst/actions)

NAME
====

Raku port of Perl's lcfirst() / ucfirst() built-ins

SYNOPSIS
========

```raku
use P5lcfirst;

say lcfirst "FOOBAR"; # fOOBAR
with "ZIPPO" {
    say .lcfirst;  # zIPPO
}

say ucfirst "foobar"; # Foobar
with "zippo" {
    say .ucfirst;  # Zippo
}
```

DESCRIPTION
===========

This module tries to mimic the behaviour of Perl's `lcfirst` and `ucfirst` built-ins as closely as possible in the Raku Programming Language.

ORIGINAL PERL 5 DOCUMENTATION
=============================

    lcfirst EXPR
    lcfirst Returns the value of EXPR with the first character lowercased.
            This is the internal function implementing the "\l" escape in
            double-quoted strings.

            If EXPR is omitted, uses $_.

            This function behaves the same way under various pragmata, such as
            in a locale, as "lc" does.

    ucfirst EXPR
    ucfirst Returns the value of EXPR with the first character in uppercase
            (titlecase in Unicode). This is the internal function implementing
            the "\u" escape in double-quoted strings.

            If EXPR is omitted, uses $_.

            This function behaves the same way under various pragma, such as
            in a locale, as "lc" does.

PORTING CAVEATS
===============

With the arrival of RakuAST, it has become impossible to access the topic variable (`$_`) of the caller's scope. So Perl's idiom of calling `lcfirst` or `ucfirst` without arguments has become impossible. Code such as:

```raku
say lcfirst;
```

should be changed to either:

```raku
say lcfirst($_);
```

or, using the subroutine as a method syntax, with the prefix `.` shortcut to use that scope's `$_` as the invocant:

```raku
say .&lcfirst;
```

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://github.com/lizmat/P5lcfirst . Comments and Pull Requests are welcome.

If you like this module, or what I’m doing more generally, committing to a [small sponsorship](https://github.com/sponsors/lizmat/) would mean a great deal to me!

COPYRIGHT AND LICENSE
=====================

Copyright 2018, 2019, 2020, 2021, 2023, 2026 Elizabeth Mattijsen

Re-imagined from Perl as part of the CPAN Butterfly Plan.

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

