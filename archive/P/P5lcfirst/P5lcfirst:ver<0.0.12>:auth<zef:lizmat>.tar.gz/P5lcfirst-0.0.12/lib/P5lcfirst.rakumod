proto sub lcfirst(|) is export {*}
multi sub lcfirst(--> Str:D) {
    die "Calling 'lcfirst' on caller's topic variable is no longer
         possible, please use '.&lcfirst' syntax instead"
      .naive-word-wrapper;
}
multi sub lcfirst(Str() $string --> Str:D) {
    $string
      ?? $string.substr(0,1).lc ~ $string.substr(1)
      !! $string
}

proto sub ucfirst(|) is export {*}
multi sub ucfirst(--> Str:D) {
    die "Calling 'ucfirst' on caller's topic variable is no longer
         possible, please use '.&ucfirst' syntax instead"
      .naive-word-wrapper;
}
multi sub ucfirst(Str() $string --> Str:D) {
    $string
      ?? $string.substr(0,1).uc ~ $string.substr(1)
      !! $string
}

# vim: expandtab shiftwidth=4
