#!/usr/bin/bash

combine-pdfs
gbumc-nametags-info.rakudoc
