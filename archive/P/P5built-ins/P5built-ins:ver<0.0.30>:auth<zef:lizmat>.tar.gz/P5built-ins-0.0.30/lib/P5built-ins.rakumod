my %export;
module P5built-ins:ver<0.0.30>:auth<zef:lizmat> {
    use P5-X:ver<0.0.10+>:auth<zef:lizmat>;
    use P5__FILE__:ver<0.0.6+>:auth<zef:lizmat>;
    use P5caller:ver<0.0.13+>:auth<zef:lizmat>;
    use P5chdir:ver<0.0.9+>:auth<zef:lizmat>;
    use P5chomp:ver<0.0.10+>:auth<zef:lizmat>;
    use P5chr:ver<0.0.9+>:auth<zef:lizmat>;
    use P5defined:ver<0.0.7+>:auth<zef:lizmat>;
    use P5each:ver<0.0.8+>:auth<zef:lizmat>;
    use P5fc:ver<0.0.9+>:auth<zef:lizmat>;
    use P5fileno:ver<0.0.6+>:auth<zef:lizmat>;
    use P5getgrnam:ver<0.0.9+>:auth<zef:lizmat>;
    use P5getnetbyname:ver<0.0.9+>:auth<zef:lizmat>;
    use P5getpriority:ver<0.0.8+>:auth<zef:lizmat>;
    use P5getprotobyname:ver<0.0.7+>:auth<zef:lizmat>;
    use P5getpwnam:ver<0.0.10+>:auth<zef:lizmat>;
    use P5getservbyname:ver<0.0.8+>:auth<zef:lizmat>;
    use P5hex:ver<0.0.9+>:auth<zef:lizmat>;
    use P5index:ver<0.0.7+>:auth<zef:lizmat>;
    use P5lc:ver<0.0.10+>:auth<zef:lizmat>;
    use P5lcfirst:ver<0.0.11+>:auth<zef:lizmat>;
    use P5length:ver<0.0.8+>:auth<zef:lizmat>;
    use P5localtime:ver<0.0.11+>:auth<zef:lizmat>;
    use P5math:ver<0.0.6+>:auth<zef:lizmat>;
    use P5opendir:ver<0.0.9+>:auth<zef:lizmat>;
    use P5pack:ver<0.0.15+>:auth<zef:lizmat>;
    use P5print:ver<0.0.7+>:auth<zef:lizmat>;  # causes DEPR warning
    use P5push:ver<0.0.8+>:auth<zef:lizmat>;
    use P5quotemeta:ver<0.0.7+>:auth<zef:lizmat>;
    use P5readlink:ver<0.0.10+>:auth<zef:lizmat>;
    use P5ref:ver<0.0.8+>:auth<zef:lizmat>;
    use P5reset:ver<0.0.7+>:auth<zef:lizmat>;
    use P5reverse:ver<0.0.9+>:auth<zef:lizmat>;
    use P5seek:ver<0.0.5+>:auth<zef:lizmat>;  # causes DEPR warning
    use P5shift:ver<0.0.8+>:auth<zef:lizmat>;
    use P5sleep:ver<0.0.10+>:auth<zef:lizmat>;
    use P5study:ver<0.0.6+>:auth<zef:lizmat>;
    use P5substr:ver<0.0.7+>:auth<zef:lizmat>;
    use P5tie:ver<0.0.15+>:auth<zef:lizmat>;
    use P5times:ver<0.0.10+>:auth<zef:lizmat>;

    # there must be a better way to do this, but this will work for now
    %export = MY::.keys.grep( *.starts-with('&') ).map: { $_ => ::($_) };
}

multi sub EXPORT() { %export }
multi sub EXPORT(*@args) {
    my $imports := Map.new( |(%export{ @args.map: '&' ~ * }:p) );
    if $imports != @args {
        die "P5built-ins doesn't know how to export: "
          ~ @args.grep( { !$imports{$_} } ).join(', ')
    }
    $imports
}

# vim: expandtab shiftwidth=4
