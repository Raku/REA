proto sub abs(|) is export {*}
multi sub abs() {
    die "Calling 'abs' on caller's topic variable is no longer possible,
         please use '.abs' syntax instead".naive-word-wrapper;
}
multi sub abs(\value) { value.abs }

proto sub cos(|) is export {*}
multi sub cos() {
    die "Calling 'cos' on caller's topic variable is no longer possible,
         please use '.cos' syntax instead".naive-word-wrapper;
}
multi sub cos(\value) { value.cos }

proto sub exp(|) is export {*}
multi sub exp() {
    die "Calling 'exp' on caller's topic variable is no longer possible,
         please use '.exp' syntax instead".naive-word-wrapper;
}
multi sub exp(\value) { value.exp }

proto sub log(|) is export {*}
multi sub log() {
    die "Calling 'log' on caller's topic variable is no longer possible,
         please use '.log' syntax instead".naive-word-wrapper;
}
multi sub log(\value) { value.log }

proto sub rand(|) is export {*}
multi sub rand(            --> Num:D) { 1.rand    }
multi sub rand(Cool:D $num --> Num:D) { $num.rand }

proto sub sin(|) is export {*}
multi sub sin() {
    die "Calling 'sin' on caller's topic variable is no longer possible,
         please use '.sin' syntax instead".naive-word-wrapper;
}
multi sub sin(\value) { value.sin }

proto sub sqrt(|) is export {*}
multi sub sqrt() {
    die "Calling 'sqrt' on caller's topic variable is no longer possible,
         please use '.sqrt' syntax instead".naive-word-wrapper;
}
multi sub sqrt(\value) { value.sqrt         }

sub crypt(Str() $plaintext, Str() $salt --> Str:D) is export {
    use NativeCall;
    sub _crypt(Str is rw, Str is rw --> Str) is native is symbol<crypt> {*}  # UNCOVERABLE

    # need try, because some systems don't have 'crypt' anymore
    try _crypt($plaintext, $salt)
}

# vim: expandtab shiftwidth=4
