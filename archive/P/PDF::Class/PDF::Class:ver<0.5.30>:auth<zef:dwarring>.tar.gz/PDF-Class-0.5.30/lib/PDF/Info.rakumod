use v6;
unit role PDF::Info;

## use ISO_32000::Table_317-Entries_in_the_document_information_dictionary;
## also does ISO_32000::Table_317-Entries_in_the_document_information_dictionary;

## use ISO_32000_2::Table_349-Entries_in_the_document_information_dictionary;
## also does ISO_32000_2::Table_349-Entries_in_the_document_information_dictionary;

use PDF::COS::Type::Info;
also does PDF::COS::Type::Info;

