#| subclassed Pages class
use PDF::Pages;
class TestDoc::Pages is  PDF::Pages {
}
