# see t/doc_extensibility.t
use v6;
use PDF::Page;
class TestDoc::Page is PDF::Page {
}
