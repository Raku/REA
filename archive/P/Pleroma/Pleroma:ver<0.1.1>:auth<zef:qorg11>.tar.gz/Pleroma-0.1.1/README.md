[![Actions Status](https://github.com/dimethyltriptamine/pleroma-raku/workflows/test/badge.svg)](https://github.com/dimethyltriptamine/pleroma-raku/actions)



