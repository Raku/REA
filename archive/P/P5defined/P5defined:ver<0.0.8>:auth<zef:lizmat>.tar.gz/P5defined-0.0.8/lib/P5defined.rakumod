proto sub defined(|) is export {*}
multi sub defined(       --> Bool:D) {
    die "Calling 'defined' on caller's topic variable is no longer possible,
         please use '.defined' syntax instead".naive-word-wrapper;
}
multi sub defined(@array --> Bool:D) { @array.Bool  }
multi sub defined(%hash  --> Bool:D) { %hash.Bool   }
multi sub defined(\item  --> Bool:D) { item.defined }

proto sub undef(|) is export {*}
multi sub undef(       --> Nil) {                }
multi sub undef(@array --> Nil) { @array = Empty }
multi sub undef(%hash  --> Nil) { %hash  = Empty }
multi sub undef(\item  --> Nil) { item   = Nil   }

# vim: expandtab shiftwidth=4
