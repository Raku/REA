#!/usr/bin/env perl6
use v6;
note "rebootstrap is obsolete. You can upgrade your rakudo while keeping all installed distributions including panda.";
note "Please run bootstrap.pl instead."
