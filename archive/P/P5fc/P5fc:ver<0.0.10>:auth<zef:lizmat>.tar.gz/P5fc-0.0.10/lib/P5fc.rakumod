BEGIN {
    note "The P5fc distribution no longer provides any functionality that
          Raku itself doesn't provide.  Please install version 0.0.9 of
          this distribution if you still want to use it."
      .naive-word-wrapper;
    exit 1;
}

# vim: expandtab shiftwidth=4
