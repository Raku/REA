[![Actions Status](https://github.com/lizmat/P5fc/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/P5fc/actions) [![Actions Status](https://github.com/lizmat/P5fc/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/P5fc/actions) [![Actions Status](https://github.com/lizmat/P5fc/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/P5fc/actions)

NAME
====

Raku port of Perl's fc() built-in

SYNOPSIS
========

THIS DISTRIBUTION ONLY PROVIDED A VERSION OF `fc` THAT WOULD ASSUME THE CALLER'S TOPIC VARIABLE (`$_`) IF CALLED WITHOUT ARGUMENTS. SINCE THIS IS NO LONGER POSSIBLE WITH RAKUAST, THE REASON FOR EXISTENCE OF THIS DISTRIBUTION IS GONE.

If you are running on older pre-6.e Rakudo's, then please install version [`0.0.9`](https://raku.land/zef:lizmat/P5fc?v=0.0.9) of this distribution.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://github.com/lizmat/P5fc . Comments and Pull Requests are welcome.

COPYRIGHT AND LICENSE
=====================

Copyright 2018, 2019, 2020, 2021, 2026 Elizabeth Mattijsen

Re-imagined from Perl as part of the CPAN Butterfly Plan.

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

