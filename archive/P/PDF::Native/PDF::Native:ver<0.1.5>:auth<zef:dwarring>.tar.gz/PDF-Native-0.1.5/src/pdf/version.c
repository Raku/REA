#include "pdf.h"
#include "pdf/version.h"

DLLEXPORT char* pdf_version() {
  return PDF_VERSION;
}
