#ifndef PDF_H_
#define PDF_H_

#ifdef _WIN32
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT extern
#endif

#define PDF_VERSION "0.0.4"

#endif
