#ifndef PDF_VERSION_H_
#define PDF_VERSION_H_

DLLEXPORT char* pdf_version();
#endif
