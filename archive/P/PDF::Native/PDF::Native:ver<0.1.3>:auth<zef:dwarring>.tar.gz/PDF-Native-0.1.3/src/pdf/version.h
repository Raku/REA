#ifndef PDF_VERSION_H_
#define PDF_VERSION_H_

#define PDF_VERSION "0.1.3"

DLLEXPORT char* pdf_version();
#endif
