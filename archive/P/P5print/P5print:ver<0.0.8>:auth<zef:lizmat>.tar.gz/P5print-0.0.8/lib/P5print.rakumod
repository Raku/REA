# role to distinguish normal Perl handles from normal IO::Handles
my role P5Handle { }

# create standard Perl handles and export them
my sub term:<<STDIN>>()  is export { $*IN  but P5Handle }  # UNCOVERABLE
my sub term:<<STDOUT>>() is export { $*OUT but P5Handle }
my sub term:<<STDERR>>() is export { $*ERR but P5Handle }

# add candidates to handle P5Handle
multi sub print(P5Handle $handle, *@_) is export {
    $handle.print(@_)
}
multi sub print() is default is export {
    die "Calling 'print' on caller's topic variable is no longer possible,
         please use '.print' syntax instead".naive-word-wrapper;
}
multi sub printf(P5Handle $handle, Cool:D $format, *@_) is export {
    $handle.printf($format, @_)
}
multi sub say(P5Handle $handle, *@_) is export {
    $handle.say(@_)
}
multi sub say() is default is export {
    die "Calling 'say' on caller's topic variable is no longer possible,
         please use '.say' syntax instead".naive-word-wrapper;
}

# vim: expandtab shiftwidth=4
