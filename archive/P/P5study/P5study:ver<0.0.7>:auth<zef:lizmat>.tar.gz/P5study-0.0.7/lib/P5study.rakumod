BEGIN {
    note "The P5study distribution is no longer functional.  Please install
          version 0.0.6 of this distribution if you still want to use it."
      .naive-word-wrapper;
    exit 1;
}
