[![Actions Status](https://github.com/lizmat/P5study/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/P5study/actions) [![Actions Status](https://github.com/lizmat/P5study/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/P5study/actions) [![Actions Status](https://github.com/lizmat/P5study/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/P5study/actions)

NAME
====

Raku port of Perl's study() built-in

SYNOPSIS
========

THIS FUNCTIONALITY WAS NON-FUNCTIONAL IN RAKU TO BEGIN WITH.

If you still want to use this distribution, please install version [`0.0.6`](https://raku.land/zef:lizmat/P5study?v=0.0.6) of this module.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://github.com/lizmat/P5study . Comments and Pull Requests are welcome.

COPYRIGHT AND LICENSE
=====================

Copyright 2018, 2019, 2020, 2021, 2025, 2026 Elizabeth Mattijsen

Originally re-imagined from Perl as part of the CPAN Butterfly Plan.

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

