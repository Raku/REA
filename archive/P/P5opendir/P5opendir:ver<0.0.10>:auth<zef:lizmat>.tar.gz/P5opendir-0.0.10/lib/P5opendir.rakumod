my class DIRHANDLE {
    has str $.path;
    has str @.items handles <elems>;
    has int $.index;

    # This class heavily depends on nqp:: ops, so enable it for the whole class
    use nqp;

    # Since the nqp:: ops don't have any support for 'telldir', 'seekdir' or
    # 'rewinddir' functionality, we're going to slurp the whole directory
    # immediately and fake that functionality (as a first approximation).
    method SET-SELF($!path) {
        my $handle := nqp::opendir($!path); # throws if it didn't work
        my str @items;
        nqp::while(
          nqp::chars(my str $next = nqp::nextfiledir($handle)),
          nqp::push_s(@items,$next)
        );
        nqp::closedir($handle);

        # Different versions of NQP either produce "." and "..", or they
        # do not.  Perl's opendir() assumes they will be, so put them
        # there if they're not there yet.
        if nqp::atpos_s(@items,0) eq "." | ".." {
            # no action, we're good
        }

        # Some OSes now put "." and ".." at the end ???
        elsif nqp::atpos_s(@items,nqp::elems(@items) - 1) eq "." | ".." {
            nqp::unshift_s(@items,nqp::pop(@items));  # ".."
            nqp::unshift_s(@items,nqp::pop(@items));  # "."
        }

        # Should start with ".", ".." for consistency
        else {
            nqp::unshift_s(@items,"..");
            nqp::unshift_s(@items,".");
        }

        @!items := @items;
        self
    }
    method new(\path) { DIRHANDLE.CREATE.SET-SELF(path) }

    method next() {
        $!index < nqp::elems(@!items)
          ?? nqp::atpos_s(@!items,$!index++)
          !! Nil
    }
    method left() {
        if $!index < nqp::elems(@!items) {
            my int $index = nqp::elems(@!items);
            my $result := @!items.splice($!index);
            $!index = $index;  # UNCOVERABLE
            $result
        }
        else {
            ()  # UNCOVERABLE
        }
    }
    method set(\index --> True) {
        $!index = (index max 0) min nqp::elems(@!items)
    }

    method Str(--> Str:D) { $!path }
}

sub opendir(\handle, Str() $path) is export {
    my $success = True;
    CATCH { default { $success = False } }
    handle = DIRHANDLE.new($path);
    $success
}

proto sub readdir(|) is export {*}
multi sub readdir(Mu:U, DIRHANDLE:D \handle) {
    die "Calling 'readdir(Mu,...)' to set caller's topic variable is
         no longer possible, please use '\$_ = readdir(...)' syntax
         instead".naive-word-wrapper;
}
multi sub readdir(DIRHANDLE:D \handle, :$void!)
  is DEPRECATED('Mu as first positional')  # UNCOVERABLE
{
    die "Calling 'readdir(..., :void)' to set caller's topic variable
         is no longer possible, please use '\$_ = readdir(...)' syntax
         instead".naive-word-wrapper;
}
multi sub readdir(Scalar:U, DIRHANDLE:D \handle) { handle.next }
multi sub readdir(DIRHANDLE:D \handle, :$scalar!)
  is DEPRECATED('Scalar as first positional')  # UNCOVERABLE
{
    handle.next
}
multi sub readdir(DIRHANDLE:D \handle) { handle.left }

sub telldir(DIRHANDLE:D \handle) is export { handle.index }
sub rewinddir(DIRHANDLE:D \handle) is export { handle.set(0) }
sub seekdir(DIRHANDLE:D \handle, Int() $pos) is export { handle.set($pos) }
sub closedir(DIRHANDLE:D \handle) is export { True }

# vim: expandtab shiftwidth=4
