proto sub chomp(|) is export {*}
multi sub chomp() {
    die "Chomp on caller's topic variable is no longer possible, please
        use '.&chomp' syntax instead".naive-word-wrapper;
}
multi sub chomp(*@a is raw) { chomp(@a) }
multi sub chomp(%h) { chomp(%h.values) }
multi sub chomp(@a) {
    my $chars = 0;
    $chars += chomp($_) for @a;
    $chars
}
multi sub chomp(\s) {
    my $chars = s.chars;
    s .= chomp;
    $chars - s.chars
}

proto sub chop(|) is export {*}
multi sub chop() {
    die "Chop on caller's topic variable is no longer possible, please
        use '.&chomp' syntax instead".naive-word-wrapper;
}
multi sub chop(*@a is raw) { chop(@a) }
multi sub chop(%h) { chop(%h.values) }
multi sub chop(@a) {
    if @a {
        my $char = @a[*-1].substr(*-1);
        $_ .= chop for @a;
        $char
    }
    else {
        Nil
    }
}
multi sub chop(\s) {
    my $char = s.substr(*-1);
    s .= chop;
    $char
}

# vim: expandtab shiftwidth=4
