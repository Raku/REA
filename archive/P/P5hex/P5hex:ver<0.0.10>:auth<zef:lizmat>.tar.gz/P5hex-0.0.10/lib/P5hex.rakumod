proto sub hex(|) is export {*}
multi sub hex() {
    die "Calling 'hex' on caller's topic variable is no longer possible,
         please use '.&hex' syntax instead".naive-word-wrapper;
}
multi sub hex(Str() $s) {
    $s ~~ / ^ <[a..f A..F 0..9]>* $ /
      ?? ($s ?? $s.parse-base(16) !! 0)
      !! +$s  # let numerification handle parse errors
}

proto sub oct(|) is export {*}
multi sub oct() {
    die "Calling 'oct' on caller's topic variable is no longer possible,
         please use '.&oct' syntax instead".naive-word-wrapper;
}
multi sub oct(Str() $s is copy) {
    $s .= trim-leading;
    if $s ~~ / \D / {                            # something non-numeric there
        with $s ~~ / ^0 <[xob]> \d+ $/ {           # standard 0x string
            +$_
        }
        else {                                     # not a standard 0x string
            with $s ~~ /^ \d+ / {                    # numeric with trailing
                .Str.parse-base(8)
            }
            else {                                   # garbage
                +$s                                   # throw numification error
            }
        }
    }
    else {                                       # just digits
        $s.parse-base(8)
    }
}

# vim: expandtab shiftwidth=4
