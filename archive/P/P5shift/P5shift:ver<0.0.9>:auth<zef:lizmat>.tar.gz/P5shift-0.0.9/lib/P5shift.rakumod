BEGIN {
    note "The P5shift distribution is no longer functional.  Please install
          version 0.0.8 of this distribution if you still want to use it."
      .naive-word-wrapper;
    exit 1;
}
