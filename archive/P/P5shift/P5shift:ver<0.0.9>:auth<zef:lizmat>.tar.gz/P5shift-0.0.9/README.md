[![Actions Status](https://github.com/lizmat/P5shift/actions/workflows/linux.yml/badge.svg)](https://github.com/lizmat/P5shift/actions) [![Actions Status](https://github.com/lizmat/P5shift/actions/workflows/macos.yml/badge.svg)](https://github.com/lizmat/P5shift/actions) [![Actions Status](https://github.com/lizmat/P5shift/actions/workflows/windows.yml/badge.svg)](https://github.com/lizmat/P5shift/actions)

NAME
====

Raku port of Perl's shift() / unshift() built-ins

SYNOPSIS
========

SOME OF THE FUNCTIONALITY DEPENDED ON RAKUDO INTERNAL FEATURES THAT WILL NOT BE AVAILABLE IN THE 6.E LANGUAGE VERSION. SINCE THE REMAINING FUNCTIONALITY IS ALREADY AVAILABLE IN RAKU, THIS MODULE HAS BEEN DEACTIVATED. SO ANY ATTEMPT TO INSTALL THIS MODULE WILL FAIL.

If you are running on older pre-6.e Rakudo's, then please install version [`0.0.7`](https://raku.land/zef:lizmat/P5shift?v=0.0.7) of this module.

AUTHOR
======

Elizabeth Mattijsen <liz@raku.rocks>

Source can be located at: https://github.com/lizmat/P5shift . Comments and Pull Requests are welcome.

COPYRIGHT AND LICENSE
=====================

Copyright 2018, 2019, 2020, 2021, 2026 Elizabeth Mattijsen

Originally re-imagined from Perl as part of the CPAN Butterfly Plan.

This library is free software; you can redistribute it and/or modify it under the Artistic License 2.0.

