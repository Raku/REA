[![Actions Status](https://github.com/tbrowder/PB-Lottery/actions/workflows/linux.yml/badge.svg)](https://github.com/tbrowder/PB-Lottery/actions) [![Actions Status](https://github.com/tbrowder/PB-Lottery/actions/workflows/macos.yml/badge.svg)](https://github.com/tbrowder/PB-Lottery/actions) [![Actions Status](https://github.com/tbrowder/PB-Lottery/actions/workflows/windows.yml/badge.svg)](https://github.com/tbrowder/PB-Lottery/actions)

NAME
====

**PB-Lottery** - Provides routines for handling play of US Power Ball lottery games

SYNOPSIS
========

```raku
# execute the installed bin file
$ pb-lottery status
# OUTPUT
...reports results of your
valid lottery tickets for each of
the recorded draw results...
```

DESCRIPTION
===========

**PB-Lottery** is intended to help the user manage his or her play in the US Power Ball Lottery with draws every Monday, Wednesday, and Saturday. 

The package includes an installed binary file, `pb-lottery`, to enbable checking various aspects of the user's lottery data including a listing of winnings for each ticket for its valid time period. Execute the program without arguments to see its help text.

The package uses two separate data records, in defined formats (see below), for your tickets and the Power Ball drawings.

The drawing records must be in a file named `draws.txt` and your ticket records must be in a file named `my-tickets.txt`.

This program expects your two data files to be in a directory pointed to by the environment variable **PB_LOTTERY_PRIVATE_DIR**. That directory **must** exist in order for the program to run, and the `draws.txt` and `my-tickets.txt` files must exist in order to check your results. (It is recommended to keep your data files under *Git* management.)

Ticket file format
------------------

Your lottery ticket records must be in a text file in the following format:

    # Lottery number choices (picks)

    # The first five numbers are picks for the lottery, and the sixth and
    # last number is the Power Ball.

    # The seventh entry is the date the ticket is valid through and must
    # be in yyyy-mm-dd format.

    # The remainder of the ticket line must contain at least one
    # and up to several additional tokens:

    #   pp  (for the 'Power Play' add-on option)
    #   dp  (for the 'Double Play' add-on option)
    #   pb  (only needed if your ticket doesn't have the 'pp' or 'dp' options)
    #   qp  (for your records if you used the 'quick pick' method)
    #   paid (use this token to prevent the ticket from being tallied in
    #         the 'status' routine)

    # Any hash mark ('#') on a line starts a comment and
    # it and the remainder of that line are ignored.
    # Blank lines are ignored.

    # Valid examples:

     02 20 32 45 47 06 2025-09-22 pb # <== no add-ons
     02 20 32 45 47 06 2025-09-22 pp dp qp
     02 20 32 45 47 06 2025-09-22 pp dp qp paid # <== see note above

Draw file format
----------------

Note the Power Ball lottery's **draw** record is slightly different from the user's ticket entry. First, it has **two** lines per draw date. The **first** line is the actual 'Power Ball' draw plus the multiplier factor for the Power Play. The **second** line is the 'Double Play' draw. The two lines for each draw data **must** be in a text file in the following format (note two draw dates are shown):

    # Powerball lottery draws

    # draw on 2025-09-01
    08 23 25 40 53 05 2025-09-01 3x # <= the Power Ball draw & multiplier
    10 15 26 48 67 19 2025-09-01 dp # <= the Double Play draw

    # next draw
    # draw on 2025-09-03
    03 16 29 61 69 22 2025-09-03 2x # <= the Power Ball draw & multiplier
    07 32 39 50 61 04 2025-09-03 dp # <= the Double Play draw

If desired, you can also enter the jackpot value as a string **after** the mutiplier on the first line. For example:

    # draw on 2025-09-03
    03 16 29 61 69 22 2025-09-03 2x $1.4B  # <= the Power Ball jackpot
    07 32 39 50 61 04 2025-09-03 dp        # <= the Double Play draw

NOTE: Depending on the data line's string context, you may have to use single quotes on the entire string or escape the US dollar sign. The data lines in the examples are not enclosed by any type of quote so they can be used as is.

The jackpot token is stripped of all characters to yield an integer value of dollars. Note the entered value must have no spaces, and it may be in varying formats. All the following formats represent the same value:

  * $1.4b

  * 1,400m

  * 1,400,000t

  * 1,400,000,000.00

Account data (not yet implemented)
----------------------------------

A third file is created to show results of the user's play. Its name is **my-financials.txt** and it shows total costs and other data for the period of play.

Ticket costs
------------

As of this writing, the basic cost of a Power Ball lottery ticket is $2. The Florida Lottery offers optional add-ons to increase potential winnings (other states may offer similar options, but the author has not attempted to handle any other state's programs).

It costs $1 to add the Power Play option, and it costs $1 to add the Double Play option. Neither option depends upon the other.

**Table 1. Add-on options**

<table class="pod-table">
<thead><tr>
<th>Add-on</th> <th>Cost</th> <th>Function</th>
</tr></thead>
<tbody>
<tr> <td>Power Play</td> <td>+1$ per play</td> <td>Multiplies non-jackpot prizes 2, 3, 4, 5, or even 10 times, depending upon on the multiplier drawn. A Match 5 prize with Power Play is automatically increased to $2 million.</td> </tr> <tr> <td>Double Play</td> <td>+1$ per play</td> <td>Gives you a second chance to win with your same numbers in a separate drawing that occurs right after the main Powerball drawing. This feature has a top prize of $10 million.</td> </tr>
</tbody>
</table>

Finding results
---------------

In the author's state of Florida, Power Ball lottery results may be found at [https://floridalottery.com](https://floridalottery.com). Other states will have their own lottery sites, but the results for any Power Ball lottery should be the same on each states' lottery site for the same date.

AUTHOR
======

Tom Browder <tbrowder@acm.org>

COPYRIGHT AND LICENSE
=====================

© 2025 Tom Browder

This library is free software; you may redistribute it or modify it under the Artistic License 2.0.

