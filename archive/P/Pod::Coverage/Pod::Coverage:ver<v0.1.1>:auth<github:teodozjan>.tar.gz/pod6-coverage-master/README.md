# pod6-coverage
pod coverage for perl6

##WARNING

This is experimental software. Use it, compare to what p6doc offers. Raise issues.
