# To do some issues

* [ ] In multi-class files, can we add metadata to `=begin pod` in the same way we did before? 

* [ ] Are generated elements cached? Can you add stuff to the cache?

