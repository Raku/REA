proto sub ref(|) is export {*}
multi sub ref() {
    die "Calling 'ref' on caller's topic variable is no longer possible,
         please use '.&ref' syntax instead".naive-word-wrapper;
}

multi sub ref(\this) {
    my \what = this<>.WHAT;         # decontainerize
    what =:= Array
      ?? 'ARRAY'
      !! what =:= Hash
        ?? 'HASH'
        !! what =:= Regex
          ?? 'Regexp'
          !! what ~~ Callable       # don't expect to be subclassing Callable
            ?? 'CODE'
            !! what =:= Version
              ?? 'VSTRING'
              !! this.VAR.^name eq 'Proxy'
                ?? 'SCALAR'
                !! this.^name         # whatever else
}

# vim: expandtab shiftwidth=4
