# We need nqp ops everywhere here, so make it global
use nqp;

proto sub print(|) is export {*}
multi sub print(str $s)   { nqp::print($s)      }
multi sub print(Str:D $s) { nqp::print($s)      }
multi sub print($s)       { nqp::print($s.Str)  }
multi sub print(*@s)      { nqp::print(@s.join) }

proto sub say(|) is export {*}
multi sub say(str $s)   { nqp::say($s)             }
multi sub say(Str:D $s) { nqp::say($s)             }
multi sub say($s)       { nqp::say($s.gist)        }
multi sub say(*@s)      { nqp::say(@s>>.gist.join) }

proto sub put(|) is export {*}
multi sub put(str $s)   { nqp::say($s)     }
multi sub put(Str:D $s) { nqp::say($s)     }
multi sub put($s)       { nqp::say($s.Str) }
multi sub put(*@s)      { nqp::say(@s.join) }

# vim: expandtab shiftwidth=4
