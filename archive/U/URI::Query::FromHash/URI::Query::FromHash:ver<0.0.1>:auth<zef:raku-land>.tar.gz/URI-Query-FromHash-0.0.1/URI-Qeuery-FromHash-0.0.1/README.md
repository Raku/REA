# NAME

URI::Query::FromHash - Construct a query string from a hash

# SYNOPSIS

```raku
use URI::Query::FromHash;

say hash2query {
   foo  => 'bar',
   baz  => < qux quux >,
   utf8 => '🦋',
}
# OUTPUT:
# baz=qux&baz=quux&foo=bar&utf8=%F0%9F%A6%8B
```

# DESCRIPTION

URI::Query::FromHash aims to be a fast, light query string constructor.

Inspired by [the Perl module of the same name][perl] and Ruby on Rails'
[to_query][ruby] hash method.

# SUBROUTINES

## hash2query

```raku
sub hash2query ( Hash() $hash --> Str )
```

Accepts anything that can be coerced to a Hash of query parameters and returns
a Str suitable to be used as the query parameters of a URI. Values will be
coerced to List and iterated over, with every element being coerced to Str
before processing. Every one of these elements will then be URL-encoded and
will appear in the generated string once preceded by the corresponding
URL-encoded key and an equal sign (`=`).

Pairs in the input Hash will be processed alphabetically by key.

When this function encounters input it cannot handle, it returns the empty
string, meaning it should always be safe to use.

This function is exported by default.

# COPYRIGHT AND LICENSE

Copyright © 2022 by Raku Land authors

This library is free software; you can redistribute it and/or modify it under
the Artistic License 2.0.

[perl]: https://metacpan.org/pod/URI::Query::FromHash
[ruby]: http://api.rubyonrails.org/classes/Hash.html#method-i-to_query
