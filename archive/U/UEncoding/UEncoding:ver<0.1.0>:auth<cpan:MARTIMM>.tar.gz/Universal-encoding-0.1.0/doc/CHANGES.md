## Release notes

* 0.1.0
  * Engine for encoding written
  * Mapping and submapping of encoding patterns
  * Encoding classes
  * Benchmarking
  * Encoding routines from package as well as user provided
* 0.0.1
  * Creation date. Lots of thinking.
