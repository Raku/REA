# Bugs and Todo

## Todo
* Decoding
* Add basic types
* Concurrency

## Bugs
