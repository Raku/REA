# SYNOPSIS

Simple Sparrowdo installer for Prometheus.


# USAGE

    $ zef install Sparrowdo::Prometheus
    $ sparrowdo --module_run=Prometheus --host=$remote_host

# Platforms supported

Any Linux Box with systemd.

# TODO

* Make prometheus configuration file customizable
* Make distribution version customizable

# Author

Alexey Melezhik


