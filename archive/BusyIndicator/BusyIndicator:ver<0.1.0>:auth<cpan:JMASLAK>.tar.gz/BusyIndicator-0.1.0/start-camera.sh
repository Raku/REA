#!/bin/bash

#
# Copyright (C) 2020-2021 Joelle Maslak
# All Rights Reserved - See License
#

PATH="/opt/rakudo-pkg/bin:/opt/rakudo-pkg/share/perl6/site/bin/:$PATH"

raku /home/jmaslak/git/antelope/Raku-BusyIndicator/bin/camera.raku busy.antelope.net
