NAME
====

Grammar::TodoTxt

AUTHOR
======

Patrick Spek <p.spek@tyil.work>

VERSION
=======

0.1.0

Description
===========

A grammar to parse todo.txt

Installation
============

Install this module through [zef](https://github.com/ugexe/zef):

```sh
zef install Grammar::TodoTxt
```

License
=======

This module is distributed under the terms of the AGPL-3.0.

