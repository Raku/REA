NAME
====

OO::Plugin::Manager

SYNOPSIS
========

...

### has Callable[<anon>] &.validator

Callback to validate plugin module before trying to load it.

### has Bool $.strict

In strict mode non-pluggable classes/methods cannot be overriden.

