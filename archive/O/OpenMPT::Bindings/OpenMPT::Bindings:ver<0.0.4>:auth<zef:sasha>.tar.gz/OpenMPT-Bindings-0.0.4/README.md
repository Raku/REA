NAME
====

OpenMPT::Bindings — Raku bindings for libopenmpt (module music rendering)

SYNOPSIS
========

```raku
use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::Types;

my $mod = OpenMPT::Bindings::Module.from-file('song.xm');

# Metadata
say $mod.title;
say $mod.duration;

# Render S16_LE interleaved stereo (ready-to-write bytes)
my ($frames, $blob) = $mod.read-interleaved-stereo(48000, 1024);

# Float stereo (separate Blob channels)
my ($count, $left, $right) = $mod.read-float-stereo(44100, 512);

# Seek
$mod.set-position(10.5);

# Library class methods
say OpenMPT::Bindings::Module.library-version;
say OpenMPT::Bindings::Module.is-extension-supported('xm');
```

DESCRIPTION
===========

OpenMPT::Bindings provides low-level and high-level Raku bindings for
[libopenmpt](https://lib.openmpt.org/), a library for decoding tracked music
files (MOD, XM, S3M, IT, and many more).

The bindings wrap the C API — all ~90 exported functions are available. The
`OpenMPT::Bindings::Module` class wraps the opaque `openmpt_module*` handle
and provides idiomatic Raku access to audio rendering, metadata, playback
control, CTL parameters, and file probing. `OpenMPT::Bindings::ModuleExt`
adds the libopenmpt extension API (interactive playback, pattern
visualization).

REQUIREMENTS
============

- libopenmpt (shared library, version 0.7+)
- Raku (6.d or later)

Some features (`current-sequence`) require libopenmpt 0.9+ and gracefully
return -1 on older versions.

The library is **not** bundled — you must install `libopenmpt` via your
system package manager:

```
# Debian/Ubuntu
apt install libopenmpt0t64

# Fedora
dnf install libopenmpt

# Arch
pacman -S libopenmpt

# macOS (Homebrew)
brew install libopenmpt

# Windows
Download the libopenmpt DLL bundle from
https://lib.openmpt.org/libopenmpt/download/ and place these files in
a directory on your PATH (e.g. C:\Windows\System32):

- libopenmpt.dll
- openmpt-mpg123.dll
- openmpt-ogg.dll
- openmpt-vorbis.dll
- openmpt-zlib.dll

If you place the DLLs in a custom directory, set the LIBOPENMPT_DIR
environment variable to that path before loading any bindings. This
also works on Linux/macOS for AppImage, .app bundles, etc.
```

INSTALLATION
============

```
zef install OpenMPT::Bindings
```

USAGE
=====

Loading modules
---------------

```raku
# From file
my $xm = OpenMPT::Bindings::Module.from-file('track.xm');

# From memory (Blob)
my $data = 'track.it'.IO.slurp(:bin);
my $it  = OpenMPT::Bindings::Module.from-blob($data);
```

Construction with initial CTL parameters
-----------------------------------------

```raku
my $mod = OpenMPT::Bindings::Module.from-file('track.xm',
    ctls => { 'play.tempo_factor' => 2.0 });
```

Metadata
--------

```raku
say $xm.title;
say $xm.artist;
say $xm.type;       # "xm", "mod", "s3m", "it"
say $xm.type-long;  # "FastTracker 2 v1.04"
say $xm.module-message;    # song message / comments
say $xm.tracker;    # tracker that created the file
say $xm.date;       # creation date
say $xm.originaltype;

# All available metadata keys
.say for $xm.metadata-keys;
```

A key that the file does not carry reads as `Nil`, not as an empty string, so
`//` is the way to give it a display value:

```raku
say $xm.title // '(no title)';
```

Most modules do not set `artist` or `date`, and before this was `Nil` you got a
defined `""` back, which meant `//` never fired and you printed a blank line.

Audio rendering
---------------

All render methods return `Blob` buffers of raw bytes. Every call returns
`($frames-returned, $buf...)`.

```raku
# Float stereo (separate buffers)
my ($frames, $left, $right) = $xm.read-float-stereo(44100, 1024);

# Float interleaved stereo
my ($frames, $buf) = $xm.read-interleaved-float-stereo(48000, 512);

# Float mono
my ($frames, $buf) = $xm.read-float-mono(44100, 256);

# Float quad (4-channel surround)
my ($frames, $fl, $fr, $rl, $rr) = $xm.read-float-quad(44100, 512);

# Float interleaved quad
my ($frames, $buf) = $xm.read-interleaved-float-quad(44100, 512);

# Int16 stereo
my ($frames, $left, $right) = $xm.read-stereo(44100, 1024);

# Int16 interleaved stereo
my ($frames, $buf) = $xm.read-interleaved-stereo(44100, 512);

# Int16 mono
my ($frames, $buf) = $xm.read-mono(44100, 256);

# Low-overhead rendering skips the Blob copy; the buffer-lifetime rule is below
my ($frames, $p, $bytes) = $xm.read-interleaved-stereo-raw(48000, 1024);

# Int16 quad
my ($frames, $fl, $fr, $rl, $rr) = $xm.read-quad(44100, 512);

# Int16 interleaved quad
my ($frames, $buf) = $xm.read-interleaved-quad(44100, 512);
```

Buffer ownership: the default is safe
-------------------------------------

Every `read-*` method above except the two `-raw` ones returns a fresh
`Blob` that you own. Nothing else in the library can reach it, so it
stays valid for as long as you hold it, and there is nothing to keep
straight. **This is the form to reach for unless you have measured a
reason not to.**

The `-raw` variants return a `Pointer[void]` into a buffer the module
instance reuses on every call, which is where the speed comes from: no
allocation and no `memcpy` per call. The cost is a lifetime contract,
and it is easy to miss because nothing fails when you get it wrong —
the buffer is simply overwritten with the next block of audio, and you
write stale or torn samples to your output device.

```raku
my ($frames, $p, $bytes) = $xm.read-interleaved-stereo-raw(48000, 1024);
```

The pointer is valid only until the next render call **on the same
module instance**. Consume it before then — write it straight to a file
descriptor or audio API with no intermediate `Blob`:

```raku
snd_pcm_writei($pcm, nativecast(Pointer[void], $p), $got);
```

Holding the pointer across another call and using it afterwards is the
bug this section exists to prevent. If you need the data to outlive the
call, you want the non-raw form, not a copy of the pointer.

| Method | Returns | Buffer lifetime |
|---|---|---|
| `read-interleaved-stereo` | `($count, Blob)` | Yours; nothing else can touch it |
| `read-interleaved-float-stereo` | `($count, Blob)` | Yours; nothing else can touch it |
| `read-interleaved-stereo-raw` | `($count, Pointer[void], $bytes)` | Until next render on this module |
| `read-interleaved-float-stereo-raw` | `($count, Pointer[void], $bytes)` | Until next render on this module |

Thread safety: one instance per thread
--------------------------------------

**A `Module` instance is not safe to use from more than one thread.**
Concurrent `read-*` or `write-*` calls on a single instance race on the
internal render buffers described above and produce undefined output —
garbled audio at best, a read of a half-written buffer at worst.

```raku
# Wrong: two threads, one instance.
my $shared = OpenMPT::Bindings::Module.from-file('track.xm');
await (for 1, 2 { start render($shared, ~$_ ~ '.wav') });

# Right: one instance per thread.
await (for 1, 2 { start render(OpenMPT::Bindings::Module.from-file('track.xm'), ~$_ ~ '.wav') });
```

Opening the same file twice is cheap, and it is the fix. Keep one
instance per thread and share nothing mutable. Note that `from-file`
slurps the whole module into memory, so the cost of a second instance is
a second read of the file, not a second open file descriptor held for
the lifetime of the object.

Metadata reads (`title`, `artist`, `metadata-keys`) and the CTL
accessors do not go through those render buffers, so they are not what
this is about. libopenmpt does not document a `Module` handle as safe
for concurrent use of any kind, though, so the useful rule is the blunt
one: don't share a `Module` across threads, and you never have to work
out which methods happen to be on the safe side of the line.

Playback control
----------------

```raku
$xm.select-subsong(0);
$xm.set-repeat-count(-1);   # -1 = forever, 0 = once, 1 = twice
$xm.set-position(15.5);     # seek to 15.5 seconds (Numeric)
$xm.set-position-order-row(3, 0);  # seek to order 3, row 0
```

Position and duration
---------------------

```raku
say $xm.duration;
say $xm.position;
say $xm.time-at-position(0, 0);
```

Render parameters
-----------------

```raku
$xm.set-mastergain(0);              # millibel
$xm.set-stereo-separation(100);     # percent
say $xm.interpolation-filter-length;
say $xm.volume-ramping-strength;
```

Playback status
---------------

```raku
say $xm.current-bpm;
say $xm.current-speed;
say $xm.current-tempo;
say $xm.current-order;
say $xm.current-pattern;
say $xm.current-row;
say $xm.current-playing-channels;
say $xm.current-sequence;           # 0.9+; returns -1 on older libopenmpt

# Per-channel VU meters
say $xm.current-channel-vu-mono(0);
say $xm.current-channel-vu-left(0);
say $xm.current-channel-vu-right(0);
say $xm.current-channel-vu-rear-left(2);
say $xm.current-channel-vu-rear-right(2);
```

Module information
------------------

```raku
say $xm.num-subsongs;
say $xm.num-channels;
say $xm.num-orders;
say $xm.num-patterns;
say $xm.num-instruments;
say $xm.num-samples;
say $xm.restart-order(0);
say $xm.restart-row(0);

# Names
say $xm.subsong-name(0);
say $xm.channel-name(0);
say $xm.order-name(0);
say $xm.pattern-name(0);
say $xm.instrument-name(0);
say $xm.sample-name(0);
```

Pattern / order access
----------------------

```raku
say $xm.order-pattern(2);              # pattern index at order 2
say $xm.is-order-skip(3);              # Bool — skip entry?
say $xm.is-order-stop(3);              # Bool — stop entry?
say $xm.is-pattern-skip(1);            # Bool — skip item?
say $xm.is-pattern-stop(1);            # Bool — stop item?
say $xm.pattern-num-rows(0);           # row count
say $xm.pattern-rows-per-beat(0);
say $xm.pattern-rows-per-measure(0);
say $xm.get-pattern-cell(0, 0, 0, OPENMPT_MODULE_COMMAND_NOTE);
say $xm.format-pattern-cell(0, 0, 0, OPENMPT_MODULE_COMMAND_NOTE);
say $xm.highlight-pattern-cell(0, 0, 0, OPENMPT_MODULE_COMMAND_NOTE);
```

CTL parameters
--------------

```raku
# Get (type dispatch via :type parameter)
say $xm.get-ctl('dither');                              # Str (text)
say $xm.get-ctl('play.tempo_factor', :type(Numeric));   # Num
say $xm.get-ctl('dither', :type(Int));                  # Int
say $xm.get-ctl('dither', :type(Bool));                 # Bool

# Set (auto-dispatch via Raku type)
$xm.set-ctl('play.tempo_factor', 2.0);   # Numeric → set_floatingpoint
$xm.set-ctl('dither', 0);                # Int → set_integer
$xm.set-ctl('dither', False);            # Bool → set_boolean
$xm.set-ctl('load.skip_plugin', '1');    # Str → set_text

# List all supported CTL keys
.say for $xm.ctl-keys;
```

Library class methods
---------------------

```raku
say OpenMPT::Bindings::Module.library-version;        # uint32
say OpenMPT::Bindings::Module.core-version;            # uint32
say OpenMPT::Bindings::Module.library-string('url');   # Str

my @exts = OpenMPT::Bindings::Module.supported-extensions;
say OpenMPT::Bindings::Module.is-extension-supported('xm');  # Bool
```

File probing
------------

```raku
my $data = 'unknown.bin'.IO.slurp(:bin);
my $result = OpenMPT::Bindings::Module.probe-file-header($data, $data.bytes);

# Compare with enum constants
if $result == OPENMPT_PROBE_FILE_HEADER_RESULT_SUCCESS {
    say "Recognised!";
}

# Probe without knowing the file size
my $partial = OpenMPT::Bindings::Module.probe-file-header-without-filesize(
    $data.subbuf(0, 64));
```

Extension API (ModuleExt)
-------------------------

The `ModuleExt` class wraps `openmpt_module_ext*` and provides interactive
playback and pattern visualization interfaces.

```raku
use OpenMPT::Bindings::ModuleExt;

my $ext = OpenMPT::Bindings::ModuleExt.from-file('track.xm');
say $ext.module.title;   # access the underlying Module

# Interactive interface
$ext.set-current-speed(2);           # 2x speed
$ext.set-tempo-factor(1.5);
$ext.set-pitch-factor(0.8);
$ext.set-global-volume(0.75);
$ext.set-channel-volume(0, 0.5);
$ext.set-channel-mute(1, True);
$ext.play-note(0, 60, 0.8, 0.5);    # instrument, note, volume, panning
$ext.stop-note(0);

# Interactive2 interface
$ext.note-off(0);
$ext.note-fade(0);
$ext.set-channel-panning(0, 0.3);
$ext.get-channel-panning(0);
$ext.set-note-finetune(0, 0.05);

# Interactive3 interface
$ext.set-current-tempo2(180);

# Pattern visualization
$ext.get-pattern-row-channel-volume-effect-type(0, 0, 0);
$ext.get-pattern-row-channel-effect-type(0, 0, 0);
```

`$ext.module` is safe to keep. The `Module` it returns holds a reference back
to the extension, so this works and does not need the `$ext` to stay in scope:

```raku
my $mod = OpenMPT::Bindings::ModuleExt.from-file('track.xm').module;
$mod.read-stereo(44100, 512);
```

Error handling
--------------

```raku
use X::OpenMPT::Bindings;

try {
    OpenMPT::Bindings::Module.from-blob(Buf.new(0xFF, 0xFE).Blob);
    CATCH {
        when X::OpenMPT::Bindings {
            say .function;  # "openmpt_module_create_from_memory2"
            say .code;      # error code (int32)
            say .message;   # human-readable error string
        }
    }
}
```

EXAMPLES
========

Two example scripts are included. Both take their options and file names in any
order on one command line, so `--quiet track.xm --format=mp3` means the same as
`--format=mp3 --quiet track.xm`, and `--` ends option parsing for a file whose
name starts with a dash. Both print their complete option list with `--help`,
and both list the module types the installed libopenmpt can read with
`--list-extensions`.

Real-time playback
------------------

```
raku -I lib examples/play-module.raku track.xm
```

Two modes take no audio device and no ffmpeg, which is what makes them useful
over SSH, in a container, or on a machine where playback has already failed:

```
# Print the module's metadata and exit
raku -I lib examples/play-module.raku --info track.xm

# Render to track.wav instead of playing it
raku -I lib examples/play-module.raku --render-wav --seconds=10 track.xm
```

`--render-wav` writes a 16-bit stereo WAV next to the module, or wherever
`--output` says, and honours the same `--rate`, `--subsong`, `--seek`,
`--repeat`, `--seconds`, `--gain` and `--tempo` that conversion does.
`--quiet` silences the per-file metadata and the "Wrote ..." line; a failed
backend, an unknown `--backend` and a refused overwrite are still reported.
First Ctrl-C stops playback and exits 130; a second one kills the process.

Audio backends (select via `--backend`):

- `pulse` — Linux (default) — libpulse-simple FFI (low-latency)
- `alsa` — Linux — native ALSA FFI via `snd_pcm_writei`
- `waveout` — Windows — winmm FFI

`pulse` uses `pa_simple_write`, which blocks at the server buffer boundary,
providing jitter-free playback without timing hacks.

If the default backend fails during setup it falls back along
`pulse` → `alsa`. Naming a backend with `--backend` turns the
fallback off: a user who wrote `--backend=alsa` hears the error rather than
getting a silent retry on something else.

File conversion
---------------

```
raku -I lib examples/convert-module.raku track.xm
```

Outputs a 16-bit stereo WAV file named `track.wav` by default.
Supported formats (select via `--format`):

- `wav` — native (RIFF header + raw PCM)
- `mp3` — pipes to `ffmpeg` (libmp3lame)
- `flac` — pipes to `ffmpeg` (flac)
- `ogg` — pipes to `ffmpeg` (libvorbis)
- `opus` — pipes to `ffmpeg` (libopus)

Common options:

```
# Cap duration and pick sample rate
raku -I lib examples/convert-module.raku --seconds=30 --rate=44100 track.it

# Batch-convert with quiet progress
raku -I lib examples/convert-module.raku --format=flac --output-dir=/tmp *.xm --quiet

# Explicit output path, subsong selection, gain/tempo
# --gain takes decibels (e.g. -2.0 = -2 dB, internally converted to millibel)
raku -I lib examples/convert-module.raku --subsong=1 --gain=-2 --tempo=1.5 --output=out.wav track.xm

# Start 40 seconds in, render 20 seconds of it
raku -I lib examples/convert-module.raku --seek=40 --seconds=20 track.xm
```

The `--force` flag applies to all output formats: without it, the tool
refuses to overwrite an existing file. ffmpeg-based formats would silently
overwrite on their own; the check here catches them early instead.

Compressed formats (mp3, flac, ogg, opus) require `ffmpeg` on `PATH`.

SEE ALSO
========

- [libopenmpt](https://lib.openmpt.org/)
- [OpenMPT](https://openmpt.org/)
- [openmpt-d (D)](https://git.disroot.org/sasha/openmpt-d)

# AUTHOR

Sasha Abbott <sashaa@disroot.org>

COPYRIGHT AND LICENSE
=====================

This software is dedicated to the public domain under the
CC0 1.0 Universal (CC0 1.0) Public Domain Dedication.

To the extent possible under law, the author has waived all copyright
and related or neighboring rights to this work.
