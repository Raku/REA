#!/usr/bin/env raku
# Regenerate t/header-api.txt, the pinned list of libopenmpt entry points that
# t/03-header-coverage.rakutest checks the hand-written prototypes against.
#
# The prototypes in lib/OpenMPT/Bindings/Native.rakumod are typed by hand.
# NativeCall validates arity at compile time, so a wrong parameter count fails
# loudly -- but a wrong argument width or return type compiles cleanly and then
# misreads memory. This script is the input side of the check that catches the
# *other* direction of the same problem: a function in the header that nothing
# declares.
#
# The header path is an argument, not a hardcoded location, because the pinned
# tree is not vendored here. Point it at libopenmpt.h from an OpenMPT checkout at
# the commit below; the ext header is found beside it, or passed as a second
# argument.
#
#   f83cedb0cd5446e4dfaa83ac97e3087107e26767
#
# That pin is the part of this check that can go stale silently, because nothing
# in the repository can tell when the header you regenerate from has moved on.
# Regenerating without also updating EXPECTED-PIN in
# t/03-header-coverage.rakutest fails the suite, and that failure is deliberate:
# "the header gained a function" is precisely the direction this exists to catch,
# so a regeneration that does not also update the test should not pass quietly.
#
# Usage:
#   tools/refresh-header-api.raku [options] <path/to/libopenmpt.h> [ext-header]
#
# Options:
#   --commit SHA     upstream commit to record. Auto-detected with git when the
#                    header's tree is a checkout; required otherwise.
#   --describe STR   `git describe` output to record. Auto-detected likewise.
#   --version STR    OPENMPT_API_VERSION to record, e.g. 0.9.0-pre.13.
#                    Auto-detected from libopenmpt_version.h when that file
#                    sits beside the header.
#   --output PATH    destination. Default: t/header-api.txt beside this script.

use Shell::Command;

my constant PROG = 'refresh-header-api.raku';

sub die($msg) {
    $*ERR.printf("%s: %s\n", PROG, $msg);
    exit 1;
}

sub note($msg) {
    $*ERR.printf("%s: %s\n", PROG, $msg);
}

sub usage {
    # Echo the comment block at the top of this file, without the leading '#'.
    my @lines = (IO::Path.new($*PROGRAM-NAME).slurp).lines;
    my @block;
    for @lines[1..*] -> $line {
        last if $line.chop ~~ /^ $/;
        @block.push: $line.subst(/^ '#' ' '?/, '');
    }
    $*ERR.print(@block.join("\n"), "\n");
    exit 2;
}

# ---------------------------------------------------------------------------

# Extract the LIBOPENMPT_API-declared function names from a header.
#
# Key off the name immediately before the argument list rather than trying to
# parse the return type. libopenmpt returns `const char *` from about twenty
# entry points, so any "one token, then an optional star" pattern silently drops
# those twenty -- and drops them silently, which is the failure mode that would
# let this file claim to pin a surface it is missing a fifth of. Anchoring on the
# name before `(` cannot go wrong that way, and `[^;]*` keeps the match from
# running past the end of one declaration into the next.
#
# The count is cross-checked against the number of LIBOPENMPT_API lines, so a
# future edit that quietly undercounts is caught at generation time.
sub extract-names(Str $text) {
    my @names;
    for $text.lines -> $line {
        next unless $line.contains('LIBOPENMPT_API');
        # '[^;]*' then a non-word char then the name then optional space then '('.
        # The name is captured right before the argument list; requiring a
        # non-word char before it keeps us from matching the tail of a longer
        # identifier, and the .* prefix lets the match start anywhere on the line.
        #
        # '<' is a metacharacter in this Raku (Rakudo 2026.08), so the classes
        # are written in Raku form: '<?[;]>' is the POSIX "[^;]" and '<[()]>' is
        # the literal '(' we anchor on. The name is parenthesised so the capture
        # takes the whole identifier rather than just the "openmpt_" prefix.
        #
        # The '*%' is atomic, and it is load-bearing rather than an optimisation.
        # A line that carries LIBOPENMPT_API but no name before '(' -- exactly
        # what a truncated or half-edited header looks like -- makes the greedy
        # '<?[;]>*' backtrack through every split of the line looking for
        # another way in. On a 1600-line header that is minutes of CPU instead of
        # an error message, and it is the one input this script most needs to
        # diagnose quickly. Atomic means it either matches or moves on.
        my $m = $line.match(/ <?[;]>*% <?[\w]> $<name>=( [openmpt_] \w+ ) \s* <[()]> /);
        next unless $m;
        @names.push($m<name>);
    }
    # Note: '@names.sort.Str' would collapse the list to one string, because
    # .Str stringifies the *result* of the sort rather than being a comparator.
    # 'sort(*.Str)' is the form that actually sorts by string and stays a list.
    @names.sort(*.Str);
}

# Every LIBOPENMPT_API line should yield a name. A mismatch means the extractor
# missed something, and publishing a short list is the one outcome worse than
# publishing none.
sub verify-extraction(Str $text, $label) {
    my $n_lines  = $text.lines.grep(*.contains('LIBOPENMPT_API')).elems;
    my $n_names  = extract-names($text).elems;
    if $n_lines != $n_names {
        die "$label: $n_lines LIBOPENMPT_API lines but $n_names names extracted; "
          ~ "the extractor is wrong, refusing to write a short list";
    }
    $n_names;
}

# OPENMPT_API_VERSION is assembled by build/update_libopenmpt_version.sh from
# four macros, and it is the only version statement in the pinned tree. It is
# absent from a tree that was fetched as raw files rather than checked out, so
# this is best-effort with the override as the documented path.
# The value is taken by splitting on whitespace and indexing rather than by a
# capture group. A regex that captures here silently yields the whole matched
# line under .first, because grep/filter over a list of lines returns Strs, and
# the version line then reads "#define OPENMPT_API_VERSION_MAJOR 0" where a
# number belongs. That is a plausible-looking wrong answer, which is worse than
# the 'unknown' this is meant to fall back to.
sub header-macro-value(Str $text, Str $name) {
    for $text.lines -> $line {
        my @t = $line.words;
        next unless @t.elems >= 3 && @t[0] eq '#define' && @t[1] eq $name;
        return @t[2];
    }
    Nil
}

sub detect-version($dir) {
    my $vf = $dir.add('libopenmpt_version.h');
    return Nil unless $vf.e;
    my $text  = $vf.slurp;
    my $major = header-macro-value($text, 'OPENMPT_API_VERSION_MAJOR');
    my $minor = header-macro-value($text, 'OPENMPT_API_VERSION_MINOR');
    my $patch = header-macro-value($text, 'OPENMPT_API_VERSION_PATCH');
    my $pre   = header-macro-value($text, 'OPENMPT_API_VERSION_PRERELEASE') // '""';
    return Nil unless defined $major && defined $minor && defined $patch;
    $pre = $pre.subst(/^ '"' | '"' $/, '', :g);   # the prerelease is a C string literal
    "$major.$minor.$patch$pre";
}

# ---------------------------------------------------------------------------

if not @*ARGS { usage }

# '.absolute' hands back a Str; '.IO' keeps it an IO::Path so '.parent' and
# '.add' still work on it.
my $here       = IO::Path.new($*PROGRAM-NAME).parent.absolute.IO;
my $root       = $here.parent;
my Str $default_out = $root.add('t/header-api.txt').Str;

my Str $commit   = '';
my Str $describe = '';
my Str $version  = '';
my Str $output   = $default_out.Str;

my @args = @*ARGS;
while @args {
    my $a = @args.shift;
    if    $a eq '--commit'    { die '--commit needs a value'   unless @args; $commit   = @args.shift }
    elsif $a eq '--describe'  { die '--describe needs a value' unless @args; $describe = @args.shift }
    elsif $a eq '--version'   { die '--version needs a value'  unless @args; $version  = @args.shift }
    elsif $a eq '--output'    { die '--output needs a value'   unless @args; $output   = @args.shift }
    elsif $a eq '-h' || $a eq '--help' { usage }
    elsif $a eq '--' { last }
    elsif $a.starts-with('-') { die "unknown option: $a" }
    else { @args.unshift($a); last }
}

die 'no header path given (try --help)' unless @args;
my $header  = IO::Path.new(@args.shift.Str);
my $hdr_dir = $header.parent;
my $ext     = @args ?? IO::Path.new(@args.shift.Str) !! Nil;

die "no such header: $header" unless $header.e;

# The ext header is a sibling in the upstream tree; fall back to it so the
# caller does not have to know that.
if !$ext && $hdr_dir.add('libopenmpt_ext.h').e {
    $ext = $hdr_dir.add('libopenmpt_ext.h');
}

# A pinned list whose commit is unknown is worse than no list: it would let a
# reader believe the surface is pinned when nothing records what to. Refuse.
#
# Auto-detection requires the header's own directory to be the top of a git
# tree, which is the only case where HEAD is the upstream commit. The usual
# layout is the opposite: the header sits in an untracked openmpt/ directory
# inside some unrelated checkout, so a plain `git rev-parse` there resolves to
# that checkout's HEAD and would pin the API surface to an unrelated commit
# while looking entirely plausible. Insisting on --commit in that case is the
# point, not an inconvenience.
if !$commit {
    my $toplevel = qx{git -C {$hdr_dir} rev-parse --show-toplevel 2>/dev/null}.trim;
    if $toplevel && IO::Path.new($toplevel).absolute.path.Str eq $hdr_dir.absolute.path.Str {
        $commit   = qx{git -C {$toplevel} rev-parse HEAD 2>/dev/null}.trim;
        $describe = qx{git -C {$toplevel} describe --always --dirty 2>/dev/null}.trim unless $describe;
    } else {
        note 'the header is not the top of a git tree, so HEAD is not the upstream commit';
        note 'refusing to guess; pass --commit SHA';
    }
}
die 'cannot determine the upstream commit; pass --commit SHA' unless $commit;

$describe = 'unknown' unless $describe;
if !$version {
    my $detected = detect-version($hdr_dir);
    if $detected {
        $version = $detected;
    } else {
        note 'no libopenmpt_version.h beside the header; pass --version STR';
        note "recording 'unknown' -- t/03 will accept it, so set it by hand";
        $version = 'unknown';
    }
}

my $header_text = $header.IO.slurp;
verify-extraction($header_text, $header);
my @core  = extract-names($header_text);
my $n_core = @core.elems;
die "extracted no names from $header; is LIBOPENMPT_API spelled as expected?" unless $n_core;

my @extnames;
my $n_ext = 0;
if $ext && $ext.e {
    my $ext_text = $ext.IO.slurp;
    verify-extraction($ext_text, $ext);
    @extnames = extract-names($ext_text);
    $n_ext = @extnames.elems;
    die "extracted no names from $ext" unless $n_ext;
} else {
    note 'no ext header found; the ext section will be empty';
}

my $out_path = IO::Path.new($output);
$out_path.parent.mkdir;

my $doc = "# libopenmpt C API surface, pinned.\n"
        ~ "#\n"
        ~ "# Generated by tools/refresh-header-api.raku. Do not edit by hand:\n"
        ~ "# add an allowlist entry with a reason, or bind the function.\n"
        ~ "#\n"
        ~ "#   commit   $commit\n"
        ~ "#   describe $describe\n"
        ~ "#   version  $version\n"
        ~ "#\n"
        ~ "# Blank lines and lines starting with # are ignored. Names are sorted.\n"
        ~ "#\n"
        ~ "# --- libopenmpt.h ($n_core functions) ---\n"
        ~ @core.join("\n") ~ "\n"
        ~ "\n"
        ~ "# --- libopenmpt_ext.h ($n_ext functions) ---\n"
        ~ ( @extnames ?? @extnames.join("\n") ~ "\n" !! "# (none)\n" );

$out_path.spurt($doc);

say "{PROG}: wrote $output";
say "{PROG}: commit   $commit";
say "{PROG}: describe $describe";
say "{PROG}: version  $version";
say "{PROG}: libopenmpt.h $n_core functions, libopenmpt_ext.h $n_ext functions";

# Announce the pin, not just the path: a regeneration that silently changed the
# surface would otherwise look identical to one that did not.
note "if the commit line above changed, update EXPECTED-PIN in t/03-header-coverage.rakutest";
