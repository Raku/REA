# The helper modules sit next to this script, so add the script's own directory
# rather than a literal 'examples', which would be relative to the current
# working directory and break when the script is run from elsewhere.
use lib $?FILE.IO.parent;
use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::Util;
use Examples::Common;
use Examples::ConvertHelpers;

constant BUF-FRAMES = 4096;

# ============================================================================
# Entry point
# ============================================================================

# A plain program body, not a `sub MAIN`, and that is not a style preference.
#
# The dispatcher splits @ARGV into options and positionals itself, and it
# splits on the *first* element that looks like an option. With the signature
# this script used to have -- a slurpy for the files plus named parameters for
# the options -- that produced four different wrong answers depending on the
# order of the command line:
#
#   convert track.it --format=mp3   every option lands in the slurpy, the named
#                                   parameters keep their defaults, and an MP3
#                                   request quietly writes a full-length WAV
#   convert --format=mp3 track.it   --format takes the *file* as its value, so
#                                   files is empty and nothing is converted
#   convert --format=mp3 track.it --quiet
#                                   the same, with --quiet absorbed as well
#   convert --quiet --format=mp3 track.it
#                                   no candidate matches, so it prints usage
#                                   and exits 1
#
# The README's own examples put options before the files, so the documented
# invocation converted nothing. Declaring no named parameters does not fix it
# either: the dispatcher still refuses a leading --option for any candidate it
# cannot bind, including a bare slurpy, a nullary sub, and a slurpy preceded by
# a positional. A program body reading @*ARGS gets the command line verbatim in
# any order, so parse-args in Examples::Common does the splitting instead.
#
# Returns the process exit status, so a conversion that failed is not reported
# as a success.
sub convert-main(@argv --> Int) {
    my %opts = parse-args(@argv, CONVERT-VALUED, CONVERT-SWITCHES);
    my @files = %opts<files>.List;

    if %opts<list-extensions> {
        .say for OpenMPT::Bindings::Module.supported-extensions.sort;
        return 0;
    }
    if %opts<help> {
        say convert-usage;
        return 0;
    }

    my $format     = %opts<format>     // 'wav';
    my $rate       = rate-arg    %opts<rate>;
    my $subsong    = int-arg     %opts<subsong>,  'subsong',  0;
    my $repeat     = int-arg     %opts<repeat>,   'repeat',   0;
    my $seconds    = numeric-arg %opts<seconds>,  'seconds',  0;
    my $seek       = numeric-arg %opts<seek>,     'seek',     0;
    my $gain       = numeric-arg %opts<gain>,     'gain',     0;
    my $tempo      = numeric-arg %opts<tempo>,    'tempo',    1.0;
    my $output     = %opts<output>;
    my $output-dir = %opts<output-dir>;
    my $quiet      = %opts<quiet> // False;
    my $force      = %opts<force> // False;

    # `--format mp3 track.it`, with the value as a separate word, consumes the
    # file as the value and leaves nothing to convert, so the run reports only
    # that there were no input files. When options were given at all, name the
    # likely cause rather than making the user work it out.
    unless @files {
        my $any-option = %opts.keys.grep: { $_ ne 'files' };
        die $any-option
            ?? "No input files; an option's value goes after '=', e.g. --format=mp3, not --format mp3"
            !! "No input files";
    }
    die "Unsupported format: $format" unless is-supported-format($format);
    die "ffmpeg required for $format format; install it or use --format=wav"
        if needs-ffmpeg($format) && !has-ffmpeg();
    die "Cannot use both --output and --output-dir" if $output.defined && $output-dir.defined;

    # Worst outcome across the files, as in play-module: converting three tracks
    # where one fails should not report success.
    my $exit-code = 0;

    for @files -> $path {
        # Skipping a path that does not exist used to be silent, so
        # `convert typo.xm` exited 0 having written nothing. A failed render
        # below already reports 1, so a missing input reports the same.
        unless $path.IO.e {
            note "Skipping $path: no such file";
            $exit-code = 1;
            next;
        }

        my $mod = try OpenMPT::Bindings::Module.from-file($path);
        if $! {
            note "Skipping $path: { $!.message }";
            next;
        }

        my $outpath = resolve-output($path, $format, $output, $output-dir, :multi(@files > 1));
        die "Output $outpath already exists. Use --force to overwrite"
            if $outpath.IO.e && !$force;
        note "--- { $path.IO.basename } → { $outpath.IO.basename } ---" unless $quiet;

        $mod.select-subsong($subsong);
        $mod.set-repeat-count($repeat);
        $mod.set-position($seek) if $seek > 0;
        $mod.set-mastergain(db-to-millibel($gain)) if $gain != 0;
        $mod.set-ctl('play.tempo_factor', $tempo.Num) if $tempo != 1.0;

        my $max-frames = $seconds > 0 ?? ($rate * $seconds).Int !! 0;
        my $total = render-wrapper($mod, $rate, $max-frames, $outpath, $format, $quiet);
        if $total < 0 {
            $exit-code = 1;
            next;
        }

        unless $quiet {
            my $dur = fmt-time($total / $rate);
            note "Wrote {$outpath.IO.basename}: {$dur}, {$total} frames";
        }
    }

    $exit-code;
}

# ============================================================================
# Render dispatcher
# ============================================================================

sub render-wrapper(
    OpenMPT::Bindings::Module $mod, int32 $rate, Int $max-frames,
    Str $outpath, Str $format, Bool $quiet
    --> Int
) {
    my $t0 = now;
    if $format eq 'wav' {
        render-wav($mod, $rate, $outpath, $max-frames, $quiet, $t0)
    } else {
        render-ffmpeg($mod, $rate, $outpath, $max-frames, $format, $quiet, $t0)
    }
}

# ============================================================================
# WAV rendering (native)
# ============================================================================

sub render-wav(
    OpenMPT::Bindings::Module $mod, int32 $rate, Str $outpath,
    Int $max-frames, Bool $quiet, Numeric $t0
    --> Int
) {
    $outpath.IO.parent.mkdir unless $outpath.IO.parent.d;
    my $progress-last = 0;
    my $rendered = 0;
    my $fh = $outpath.IO.open(:w, :bin);
    LEAVE .close with $fh;

    $fh.write: wav-header($rate, 0);

    while True {
        my $remain = $max-frames > 0 ?? $max-frames - $rendered !! BUF-FRAMES;
        last if $remain <= 0;
        my $count = min(BUF-FRAMES, $remain);
        my $got = $mod.write-interleaved-stereo-s16-to-handle($fh, $rate, $count);
        last unless $got;
        $rendered += $got;
        $progress-last = show-progress($outpath.IO.basename, $rendered, $max-frames, $rate, $t0, $progress-last)
            unless $quiet;
    }

    my $data-size = $rendered * 4;
    $fh.seek(0, SeekFromBeginning);
    $fh.write(wav-header($rate, $data-size));
    $rendered
}

# ============================================================================
# ffmpeg pipe rendering
# ============================================================================
# resolve-output is in Examples::ConvertHelpers, where a test can reach it.

# ffmpeg-args and the other decision-making live in Examples::ConvertHelpers so
# a test can reach them; see t/05-examples.rakutest.
sub render-ffmpeg(
    OpenMPT::Bindings::Module $mod, int32 $rate, Str $outpath,
    Int $max-frames, Str $format, Bool $quiet, Numeric $t0
    --> Int
) {
    $outpath.IO.parent.mkdir unless $outpath.IO.parent.d;
    my $progress-last = 0;
    my $rendered = 0;
    my @args = ffmpeg-args($outpath, $rate, $format);
    my $proc = run 'ffmpeg', |@args, :in, :err($*ERR);

    while True {
        my $remain = $max-frames > 0 ?? $max-frames - $rendered !! BUF-FRAMES;
        last if $remain <= 0;
        my $count = min(BUF-FRAMES, $remain);
        my $got = $mod.write-interleaved-stereo-s16-to-handle($proc.in, $rate, $count);
        last unless $got;
        $rendered += $got;
        $progress-last = show-progress($outpath.IO.basename, $rendered, $max-frames, $rate, $t0, $progress-last)
            unless $quiet;
    }

    $proc.in.close;
    my $ec = $proc.exitcode;
    if $ec != 0 {
        note "\nffmpeg exited with code $ec" unless $quiet;
        $outpath.IO.unlink;
        -1
    } else {
        $rendered
    }
}

# ============================================================================
# Progress display
# ============================================================================

sub show-progress(Str $name, Int $rendered, Int $max-frames, int32 $rate, Numeric $t0, Int $progress-last --> Int) {
    return $progress-last unless $rendered - $progress-last >= $rate div 4;

    my $elapsed = now - $t0;
    my $elapsed-str = fmt-time($elapsed);

    if $max-frames > 0 {
        my $pct = 100 * $rendered / $max-frames;
        my $bar-width = 24;
        my $filled = ($pct * $bar-width / 100).Int;
        my $bar = '#' x $filled ~ '-' x ($bar-width - $filled);
        my $total-str = fmt-time($max-frames / $rate);

        $*ERR.print("\r$name  {$pct.fmt('%3.0f')}% [$bar] {$elapsed-str} / $total-str  ");
    } else {
        my $len = fmt-time($rendered / $rate);
        $*ERR.print("\r$name  $len  elapsed {$elapsed-str}  ");
    }
    $*ERR.flush;
    $rendered
}

# ============================================================================
# Run
# ============================================================================

# The body of the program, kept to one line at the end of the file; see the note
# on convert-main for why this is not a `sub MAIN`. The sub definitions above are
# hoisted at compile time, so calling them from here is not order-sensitive.
exit convert-main(@*ARGS);
