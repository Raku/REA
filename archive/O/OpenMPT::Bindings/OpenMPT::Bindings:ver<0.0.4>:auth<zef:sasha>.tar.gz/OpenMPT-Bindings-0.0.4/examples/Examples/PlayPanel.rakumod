use NativeCall;
use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::Util;
use Examples::Common;
use Examples::PlayHelpers;
use Examples::PlayNative;

unit module Examples::PlayPanel;

# Every eighth stereo pair is enough for a responsive meter and still catches
# short clips; t/05-examples pins that choice.
constant METER-STRIDE = 8;

class DisplayState is export {
    has Bool    $.vu-first         is rw = True;
    has Int     $.vu-last-redraw   is rw;
    has Numeric $.vu-hold-l        is rw = 0e0;
    has Numeric $.vu-hold-r        is rw = 0e0;
    has Int     $.vu-last-rendered is rw;
    has Str     $.gain-cache       is rw;
    has Str     $.stereo-cache     is rw;
    has Str     $.filter-cache     is rw;
    has Str     $.ramping-cache    is rw;
    has Numeric $.duration-cache   is rw;
    # A clip lasts a few samples, so latch it for the track rather than let the
    # next repaint erase it.
    has Bool    $.clipped          is rw = False;
    # Whole panel lines, composed once and reused for the length of a track.
    # Each backend owns its state, so a new file starts from empty strings.
    has Str     $.settings-line-cache is rw = '';
    has Str     $.player-line-cache   is rw = '';
    has Str     $.player-key-cache    is rw = '';
    has Str     $.duration-str-cache  is rw = '';
}

class ModuleState is export {
    has $.gain; has $.stereo; has $.filter; has $.ramping;
    has $.chans; has $.order; has $.norders; has $.pattern;
    has $.row; has $.speed; has $.tempo; has $.duration; has $.pos;
}

# libopenmpt getters are not safe next to a render call, so they are read on
# the audio thread. The slow half -- formatting and writing -- runs on the
# painter thread.
sub module-state(DisplayState $ds, $m --> ModuleState) is export {
    $ds.gain-cache     //= try { ($m.mastergain / 100).fmt('%.1f') } // '?';
    $ds.stereo-cache   //= try { $m.stereo-separation.Str }          // '?';
    $ds.filter-cache   //= try { $m.interpolation-filter-length.Str } // '?';
    $ds.ramping-cache  //= try { ($m.volume-ramping-strength == -1 ?? 'default'
                                 !! $m.volume-ramping-strength.Str) } // '?';
    $ds.duration-cache //= try { $m.duration } // 0;

    ModuleState.new(
        gain     => $ds.gain-cache,
        stereo   => $ds.stereo-cache,
        filter   => $ds.filter-cache,
        ramping  => $ds.ramping-cache,
        duration => $ds.duration-cache,
        chans    => try { $m.current-playing-channels }        // '?',
        order    => try { $m.current-order }                  // '?',
        norders  => try { $m.num-orders }                     // '?',
        pattern  => try { $m.current-pattern }                // '?',
        row      => try { $m.current-row }                    // '?',
        speed    => try { $m.current-speed }                  // '?',
        tempo    => try { sprintf('%.2f', $m.current-tempo) } // '?',
        pos      => try { $m.position },
    )
}

sub paint-status(
    DisplayState $ds, ModuleState $s, Int $rendered, int32 $r,
    Numeric $cpu-pct, Numeric $peakL = 0, Numeric $peakR = 0
) is export {
    my $gain    = $ds.gain-cache;
    my $stereo  = $ds.stereo-cache;
    my $filter  = $ds.filter-cache;
    my $ramping = $ds.ramping-cache;
    my $chans   = $s.chans;
    my $order   = $s.order;
    my $pattern = $s.pattern;
    my $row     = $s.row;
    my $speed   = $s.speed;
    my $tempo   = $s.tempo;
    my $norders = $s.norders;

    # Exponential peak-hold decay; the ':' marker keeps a short peak visible.
    {
        my $df = $rendered - ($ds.vu-last-rendered // $rendered);
        if $df > 0 {
            my $falloff = 10 ** (-$df / (1.7 * $r));
            $ds.vu-hold-l *= $falloff;
            $ds.vu-hold-r *= $falloff;
        }
        $ds.vu-hold-l = $peakL if $peakL > $ds.vu-hold-l;
        $ds.vu-hold-r = $peakR if $peakR > $ds.vu-hold-r;
        $ds.vu-last-rendered = $rendered;
    }

    my $rendered-sec = $rendered / $r;
    my $pos          = $s.pos // $rendered-sec;
    $pos = min($pos, $ds.duration-cache) if $ds.duration-cache > 0;

    my $cpu-str = pad(sprintf('%.2f%%', $cpu-pct), 6);
    # Channels climb as the track starts, so they are read on every repaint.
    my $chn-str = pad($chans, 3);

    unless $ds.settings-line-cache.chars {
        $ds.settings-line-cache = sprintf(
            "Settings...: Gain: %s dB   Stereo: %s %%   Filter: %s taps   Ramping: %s   \e[0K\n",
            $gain, $stereo, $filter, $ramping);
    }

    my $player-key = "$order/$norders $pattern $row $speed $tempo";
    if $player-key ne $ds.player-key-cache {
        $ds.player-key-cache = $player-key;
        $ds.player-line-cache = sprintf(
            "Player.....: Ord:%s/%s Pat:%s Row:%s   Spd:%s Tmp:%s\e[0K\n",
            pad($order, 3), pad($norders, 3), pad($pattern, 3), pad($row, 3),
            pad($speed, 2), $tempo);
    }
    $ds.duration-str-cache ||= fmt-time($ds.duration-cache);

    my $esc = $ds.vu-first ?? '' !! "\e[6A";
    $ds.vu-first = False;

    my $panel = $esc
        ~ vu-line(' L', $peakL, $ds.vu-hold-l) ~ "\e[0K\n"
        ~ vu-line(' R', $peakR, $ds.vu-hold-r) ~ "\e[0K\n"
        ~ $ds.settings-line-cache
        ~ sprintf("Mixer......: CPU:%s   Chn:%s   %s\e[0K\n", $cpu-str, $chn-str,
            $ds.clipped ?? 'CLIP' !! '')
        ~ $ds.player-line-cache
        ~ sprintf("Position...: %s / %s\e[0K\n", fmt-time($pos), $ds.duration-str-cache);
    $*ERR.print($panel);
    $*ERR.flush;
}

# The audio thread does the throttling, peak scan and module getters; the
# painter thread only formats and writes. One snapshot in flight means a slow
# terminal drops meter frames instead of growing a queue.
class StatusPainter is export {
    has $.ch        = Channel.new;
    has $.thread   is rw;
    # Three int32 -- peakL, peakR, clipped -- so publishing a peak allocates
    # nothing on the audio thread.
    has $.peak = CArray[int32].allocate(3);
    has Int $.last-sent is rw = -1;
    has Bool $.pending is rw = False;

    method enqueue(
        DisplayState $ds, OpenMPT::Bindings::Module $m, Int $rendered,
        int32 $r, Numeric $cpu-pct, Pointer[void] $block, Int $frames
    ) {
        return if $.last-sent >= 0 && ($rendered - $.last-sent) * 1000 / $r < 20;
        return if $.pending;
        $.last-sent = $rendered;

        my ($bl, $br, $bc) = meter-from-int16($block, $frames, METER-STRIDE);
        $.peak[0] = peak-pack($bl);
        $.peak[1] = peak-pack($br);
        $.peak[2] = $bc ?? 1 !! 0;

        my $ms = module-state($ds, $m);
        $.pending = True;
        $.ch.send([$ds, $ms, $rendered, $r, $cpu-pct]);
    }

    # A closure keeps the render loop's six positional arguments; handing it
    # the bound method would pass the invocant as well.
    method callback(--> Code) {
        my $self = self;
        sub (DisplayState $ds, OpenMPT::Bindings::Module $m, Int $rendered,
             int32 $r, Numeric $cpu-pct, Pointer[void] $block, Int $frames) {
            $self.enqueue($ds, $m, $rendered, $r, $cpu-pct, $block, $frames);
        }
    }

    method close() {
        return unless $.thread;
        $.ch.close;
        my $err = Nil;
        try {
            $.thread.result;
            CATCH { default { $err = $_ } }
        }
        note "status painter stopped: { $err.message // $err }" if $err.defined;
        $.thread = Nil;
    }
}

sub status-painter($watch --> StatusPainter) is export {
    my $stop = sub ( --> Bool) { $watch.stopped };
    my $p = StatusPainter.new;
    $p.thread = start {
        set-thread-sched(SCHED-IDLE, 0);
        loop {
            my $snap = try $p.ch.receive;
            last unless $snap.defined;
            $p.pending = False;
            # The signal handler restores the terminal; do not paint over it.
            last if $stop();
            my ($ds, $s, $rendered, $r, $cpu-pct) = $snap;
            my $peakL = peak-unpack($p.peak[0]);
            my $peakR = peak-unpack($p.peak[1]);
            $ds.clipped = True if $p.peak[2];
            paint-status($ds, $s, $rendered, $r, $cpu-pct, $peakL, $peakR);
        }
        Nil
    };
    $p
}
