use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::Util;
use Examples::Common;

unit module Examples::PlayInfo;

sub print-line(Str $label, $value) {
    my $padded = ($label ~ '.' x max(0, 11 - $label.chars) ~ ':');
    printf "%-13s %s\n", $padded, $value // '';
}

sub show-info(OpenMPT::Bindings::Module $mod, Str $path, Bool :$header = False) is export {
    print-line('Filename', $path.IO.basename);
    print-line('Size', humansize($path.IO.s));
    print-line('Type', sprintf('%s (%s)', $mod.type, $mod.type-long // ''));
    print-line('Tracker', $mod.tracker // '(none)');
    print-line('Title', $mod.title // '(none)');
    print-line('Duration', fmt-time($mod.duration));
    print-line('Subsongs', $mod.num-subsongs);
    print-line('Channels', $mod.num-channels);
    print-line('Orders', $mod.num-orders);
    print-line('Patterns', $mod.num-patterns);
    print-line('Instruments', $mod.num-instruments);
    print-line('Samples', $mod.num-samples);

    unless $header {
        my $warn = $mod.warnings-str;
        print-line('Warnings', $warn) if $warn.defined && $warn.chars;
        my $msg = $mod.module-message;
        note "\nMessage:\n$msg" if $msg.defined && $msg.chars;
    }
    note '' if $header;
}

sub show-header(OpenMPT::Bindings::Module $mod, Str $path) is export {
    show-info($mod, $path, :header);
}
