
# Testable decisions from convert-module.raku: option schema, output paths,
# ffmpeg discovery and argv. File and process work stays in the script.

unit module Examples::ConvertHelpers;

# ============================================================================
# Command line
# ============================================================================

# Option schema; parse-args rejects unknown options. The usage text repeats the
# numeric defaults, and t/05 checks the two agree.
constant CONVERT-VALUED is export = <
    format rate subsong repeat seconds seek gain tempo output output-dir
>;
constant CONVERT-SWITCHES is export = <list-extensions help quiet force>;

# Long enough to be useful, short enough to read in a terminal. Options may
# also be written --name value, and may be interleaved with the file names.
sub convert-usage(--> Str) is export {
    # Joined lines, not a heredoc: on this Rakudo a heredoc in a sub swallows
    # the closing brace and yields a phantom signature error.
    [
        'Usage: raku -I lib examples/convert-module.raku [options] <file>...',
        '',
        '  --format=<wav|mp3|flac|ogg|opus>  encoder to use (default: wav)',
        '  --rate=<Hz>                       sample rate (default: 48000)',
        '  --subsong=<n>                     which subsong to render (default: 0)',
        '  --repeat=<n>                      repeat count (default: 0)',
        '  --seconds=<n>                     stop after this many seconds (default: all)',
        '  --seek=<seconds>                  start this far into the track',
        '  --gain=<dB>                       master gain in decibels, e.g. -2.0',
        '  --tempo=<factor>                  tempo factor (default: 1.0)',
        '  --output=<path>                   output path, for a single input file',
        '  --output-dir=<dir>                write each render into this directory',
        '  --quiet                           no progress output',
        '  --force                           overwrite an existing output file',
        '  --list-extensions                 list the supported input extensions',
        '  --help                            print this text',
    ].join("\n")
}

# ============================================================================
# Format support
# ============================================================================

constant WAV-FORMAT is export = 'wav';
constant FFMPEG-FORMATS is export = <mp3 flac ogg opus>;
constant ALL-FORMATS is export = (WAV-FORMAT, |FFMPEG-FORMATS);

# One list drives both the check and its error message; `so` keeps the Junction
# from failing the Bool return type check.
sub is-supported-format(Str $format --> Bool) is export {
    so $format eq any(ALL-FORMATS)
}

# Formats that need an external encoder rather than the native WAV writer.
sub needs-ffmpeg(Str $format --> Bool) is export {
    $format ne WAV-FORMAT
}

# ============================================================================
# ffmpeg discovery
# ============================================================================

# Find ffmpeg up front so a missing encoder is not reported as an opaque spawn
# failure after rendering. The scan is separate so :cached(False) really rescans.
sub scan-ffmpeg-path(--> Str) is export {
    my $sep = $*DISTRO.is-win ?? ';' !! ':';
    my $ext = $*DISTRO.is-win ?? '.exe' !! '';
    my $hit = %*ENV<PATH>.split($sep).first(-> $dir { "$dir/ffmpeg$ext".IO.x });
    $hit ?? $hit.Str !! ''
}

# Memoised per process; :cached(False) forces a rescan after PATH changes.
sub find-ffmpeg(Bool :$cached = True --> Str) is export {
    state $found //= scan-ffmpeg-path();
    $cached ?? $found !! scan-ffmpeg-path()
}

sub has-ffmpeg(Bool :$cached = True --> Bool) is export {
    find-ffmpeg(:$cached) ne ''
}

# ============================================================================
# ffmpeg argv
# ============================================================================

# A List of Str, not a lazy Seq: a Seq once failed at spawn rather than at
# construction. The Str map also avoids handing IntStr quote-word values to run.
sub ffmpeg-args(Str $outpath, int32 $rate, Str $format --> List) is export {
    my @base = < -y -f s16le -ar>;
    my @codec = do given $format {
        when 'mp3'  { < -codec:a libmp3lame -b:a 320k > }
        when 'flac' { < -codec:a flac > }
        when 'ogg'  { < -codec:a libvorbis -q:a 5 > }
        when 'opus' { < -codec:a libopus -b:a 128k > }
        default     { die "unsupported format for ffmpeg: $format" }
    }
    flat(@base, $rate.Str, < -ac 2 -i pipe:0 >, @codec, $outpath).List.map(*.Str).List
}

# ============================================================================
# Output path resolution
# ============================================================================

# --output with several inputs would silently overwrite renders, so it is
# refused. Paths are untyped because "absent" arrives as Nil, Str:U or ''.
sub resolve-output(
    Str $path, Str $format, $output, $output-dir, Bool :$multi
    --> Str
) is export {
    my $out = $output    // Nil;
    my $dir = $output-dir // Nil;

    if $out.defined or $dir.defined {
        if $out.defined {
            die "Multiple input files with --output will overwrite each other; use --output-dir instead" if $multi;
            return $out.Str;
        }
    }
    my $stem = $path.IO.extension('').basename;
    $dir.defined ?? $dir.IO.add("$stem.$format").Str !! "$stem.$format"
}
