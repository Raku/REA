use NativeCall;

# Testable decisions from play-module.raku: backend choice, fallback, metering,
# WAV header patch. Device work stays in the script.

unit module Examples::PlayHelpers;

# ============================================================================
# Command line
# ============================================================================

# The option schema; parse-args rejects unknown options. The usage text repeats
# the defaults passed to the numeric helpers, and t/05 checks they agree.
constant PLAY-VALUED is export = <subsong repeat seek seconds gain tempo rate output backend>;
constant PLAY-SWITCHES is export = <list-extensions help info render-wav quiet>;

sub play-usage(--> Str) is export {
    # Joined lines, not a heredoc: on this Rakudo a heredoc in a sub swallows
    # the closing brace and yields a phantom signature error.
    [
        'Usage: raku -I lib examples/play-module.raku [options] <file>...',
        '',
        '  --backend=<pulse|alsa|waveout>  audio backend (default: pulse, else waveout)',
        '  --rate=<Hz>                     sample rate (default: 48000)',
        '  --subsong=<n>                   which subsong to play (default: 0)',
        '  --repeat=<n>                    repeat count (default: 0)',
        '  --seconds=<n>                   stop after this many seconds (default: all)',
        '  --seek=<seconds>                start this far into the track',
        '  --gain=<dB>                     master gain in decibels, e.g. -2.0',
        '  --tempo=<factor>                tempo factor (default: 1.0)',
        '  --output=<path>                 where --render-wav writes the WAV (default: next to the input)',
        '  --info                          print module information and exit',
        '  --render-wav                    write a WAV file instead of playing',
        '  --quiet                         suppress informational output',
        '  --list-extensions               list the supported input extensions',
        '  --help                          print this text',
        '',
        'Ctrl-C stops playback, restores the terminal, and exits 130.',
    ].join("\n")
}

# ============================================================================
# Backend selection
# ============================================================================

# Platform preference order; the default is first unless excluded.
constant BACKEND-NAMES is export = <pulse alsa waveout>;

# `so` keeps the Junction from failing the Bool return type check.
sub is-known-backend(Str $name --> Bool) is export {
    so $name eq any(BACKEND-NAMES)
}

# Unknown-backend hint, derived from the same list as the check.
sub backend-hint(--> Str) is export {
    BACKEND-NAMES.join(', ')
}

# Automatic fallback chain; a missing entry ends the retry.
constant BACKEND-FALLBACKS is export = %{
    pulse    => 'alsa',
};

# Next backend after a failure, or ''. An explicit --backend is never retried;
# that policy lives in the caller.
sub fallback-backend(Str $failed --> Str) is export {
    BACKEND-FALLBACKS{$failed} // ''
}

# Whole chain after a backend, for tests that assert the sequence.
sub fallback-chain(Str $backend --> List) is export {
    my @chain;
    my $next = fallback-backend($backend);
    while $next.chars {
        @chain.push($next);
        $next = fallback-backend($next);
    }
    @chain
}

# Platform default: waveout on Windows, pulse elsewhere.
sub default-backend(Bool :$is-win = $*DISTRO.is-win --> Str) is export {
    $is-win ?? 'waveout' !! 'pulse'
}

# ============================================================================
# VU metering
# ============================================================================

# RAIL16 is the clipping threshold; FS16 is one higher so -32768 normalises to 1.0.
constant RAIL16 is export = 32767;
constant FS16 is export = 32768e0;

# Peak per channel and a clip flag, scanned in place. Stride 8 still finds short
# clips in a 1024-frame block; tracking both extrema avoids a sign test per sample.
sub meter-from-int16(Pointer[void] $cbuf, Int $frames, Int $stride = 1 --> List) is export {
    # Zero is the identity for max of absolute values.
    my int $maxL = 0;
    my int $minL = 0;
    my int $maxR = 0;
    my int $minR = 0;
    my int $n = $frames * 2;
    my Pointer[int16] $p = nativecast(Pointer[int16], $cbuf);
    my int $i = 0;
    # A stride below 1 would read nothing.
    $stride = 1 if $stride < 1;
    my int $step = 2 * $stride;
    while $i < $n {
        my int $l = $p[$i];
        my int $r = $p[$i+1];
        $maxL = $l if $l > $maxL;
        $minL = $l if $l < $minL;
        $maxR = $r if $r > $maxR;
        $minR = $r if $r < $minR;
        $i += $step;
    }
    # The extreme further from zero; -32768 becomes 32768, not quiet.
    my int $peakL = $maxL > -$minL ?? $maxL !! -$minL;
    my int $peakR = $maxR > -$minR ?? $maxR !! -$minR;
    # A single flag: no caller needs a per-frame count.
    my int $clipped = ($peakL >= RAIL16 || $peakR >= RAIL16) ?? 1 !! 0;
    ($peakL / FS16, $peakR / FS16, $clipped);
}

# Peaks cross threads as int32 to avoid allocation; keep the scale in one place.
sub peak-pack(Numeric $peak --> Int) is export { ($peak * FS16).Int }
sub peak-unpack(Int $raw --> Numeric) is export { $raw / FS16 }

# One meter bar: 48 dB columns, 0 dB at the right, ':' marking the recent peak.
sub vu-line(Str $tag, Numeric $peak, Numeric $hold --> Str) is export {
    constant COLS = 48;
    my int $val = $peak > 0 ?? (20 * log($peak, 10) + 48).Int !! 0;
    $val = 0 if $val < 0;
    $val = COLS if $val > COLS;
    my $bar = '>' x $val ~ ' ' x (COLS - $val);
    if $hold > 0 {
        my int $h = (20 * log($hold, 10) + 48).Int;
        $h = 0 if $h < 0;
        # Column 47: the rightmost is the peak indicator.
        $h = COLS - 1 if $h > COLS - 1;
        $bar.substr-rw($h, 1) = ':';
    }
    sprintf("        %s : %s%s", $tag, $bar, $peak >= 1.0 ?? '#' !! ':')
}

# ============================================================================
# Interrupts
# ============================================================================

# signal().tap runs off-thread and SIGINT's default action kills without
# unwinding. The first Ctrl-C sets a flag and restores the terminal itself; the
# second exits.
constant INTERRUPT-EXIT-CODE is export = 130;

# Grace for a marked device call before one Ctrl-C counts as a wedge. Built
# positionally: Duration.new(seconds => 0.5) silently returns 0.
constant BLOCKING-CALL-GRACE is export = Duration.new(0.5);

# One press is a request; two means stop waiting. A wedged driver is detected
# earlier by blocking-call-wedged.
sub interrupts-until-forced(Int $count --> Bool) is export {
    $count >= 2
}

# True only when a marked call has overrun its grace. The parentheses matter:
# `>` binds tighter than `&&`, and the unparenthesised form compares a Bool to a
# Duration.
sub blocking-call-wedged(
    Bool :$blocking,
    Duration :$elapsed,
    Duration :$grace = BLOCKING-CALL-GRACE
    --> Bool
) is export {
    $blocking && (($elapsed // Duration.new) > $grace)
}

# Interrupt, failure and success stay distinct so a wrapper can tell them apart.
sub playback-exit-code(Bool :$interrupted, Bool :$failed --> Int) is export {
    return INTERRUPT-EXIT-CODE if $interrupted;
    return 1 if $failed;
    0
}

# Clean renders drain the tail; interrupts and failures drop it.
sub should-play-out-tail(Bool :$interrupted, Bool :$failed --> Bool) is export {
    !$interrupted && !$failed
}

# Stop predicate for device-free renders; a sub so it can be called by name.
sub never-stop(--> Bool) is export { False }

# Per-session signal state. Plain Bool/Int stores are enough: a stale read costs
# at most one buffer. Raku method names cannot contain '?' or '!'.
class Interrupt-Watch is export {
    has Bool $!stop = False;
    has Bool $!force = False;
    has Int  $!presses = 0;
    has Mu   $!tap;
    has Bool $!blocking = False;
    has Instant $!entered = now;

    method stopped( --> Bool) { $!stop }
    method forced( --> Bool)  { $!force }
    method presses(--> Int)   { $!presses }

    # Bracket an uninterruptible device call so the handler can tell a wedge
    # from a loop that simply has not polled yet.
    method blocking()  { $!blocking = True; $!entered = now }
    method returned()  { $!blocking = False }

    # Grace is a parameter so tests need not sleep.
    method wedged(Duration $grace = BLOCKING-CALL-GRACE --> Bool) {
        blocking-call-wedged(:blocking($!blocking), :elapsed(now - $!entered), :grace($grace))
    }

    # Handler-thread press: raise the flag the render loop polls.
    method note() {
        $!presses += 1;
        $!force = True if interrupts-until-forced($!presses);
        $!stop = True;
    }

    # Named set-tap rather than tap: the assignment form of tap does not call
    # a one-argument method.
    method set-tap($t) { $!tap = $t }

    # Detach per-file handlers; a stale tap would restore an old terminal mode.
    # Tap does not do Tappable, so guard with can('close').
    method close() {
        if $!tap.defined && $!tap.can('close') {
            $!tap.close;
        }
        $!tap = Nil;
    }
}

# Arm Ctrl-C for one session. Restore on every press: LEAVE cannot run while a
# device write blocks, and a cooked terminal is worse than a noisy exit.
# Restoring twice is harmless.
sub watch-interrupts(&restore, Interrupt-Watch :$watch = Interrupt-Watch.new --> Interrupt-Watch) is export {
    my $w = $watch;
    # Hold the Tap on the watch; only closing it unregisters the signal. The
    # handler is named first because the inline tap form does not parse.
    my $handler = -> $sig {
        $w.note;
        &restore();
        # Either the user pressed twice or a wedged driver is detected;
        # libpulse and alsa-lib retry EINTR internally, so one press can suffice.
        if interrupts-until-forced($w.presses) || $w.wedged {
            # LEAVE cannot run here, so exit from the handler after restoring.
            exit INTERRUPT-EXIT-CODE;
        }
    };
    $w.set-tap(signal(SIGINT).tap: $handler);
    $w
}

