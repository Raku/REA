
# Shared example logic, testable without running the scripts. Script-specific
# decisions live in their own helper modules; `use lib` keeps these local.

unit module Examples::Common;

# ============================================================================
# Gain
# ============================================================================

# User-facing dB to libopenmpt millibel (1 dB = 100); shared so the two scripts
# cannot silently diverge.
sub db-to-millibel(Numeric $db --> Int) is export {
    ($db * 100).Int
}

# ============================================================================
# Formatting
# ============================================================================

sub humansize(Int $bytes --> Str) is export {
    constant KiB = 1024;
    constant MiB = 1024 * KiB;
    constant GiB = 1024 * MiB;
    my $b = $bytes;
    given $b {
        when * < KiB   { sprintf '%.0f B', $b }
        when * < MiB   { sprintf '%.0f KiB', $b / KiB }
        when * < GiB   { sprintf '%.1f MiB', $b / MiB }
        default        { sprintf '%.1f GiB', $b / GiB }
    }
}

# Right-align with ':' fill, e.g. pad(3, 4) → ":::3"
sub pad($s, Int $w --> Str) is export {
    my $str = $s.Str;
    $str.chars >= $w ?? $str !! ':' x ($w - $str.chars) ~ $str
}

# ============================================================================
# Command line
# ============================================================================

# Split @ARGV ourselves: a MAIN candidate with a slurpy gets raw @ARGV, so a
# documented `--format=mp3` was once silently ignored. Options and files may be
# interleaved; @valued and @switches define the whole schema.
sub parse-args(
    @argv, @valued, @switches
    --> Hash
) is export {
    # Hash lookups rather than `in`, which does not parse in a statement modifier.
    my %valued   = @valued.map:   { $_ => True };
    my %switches = @switches.map: { $_ => True };
    my %opts;
    my @files;
    my $literal = False;
    my $i = 0;

    while $i < @argv.elems {
        my $arg = @argv[$i++];

        # A bare `--` ends option parsing; it must be checked before the option
        # pattern below.
        if $arg eq '--' {
            $literal = True;
            next;
        }

        # Single-dash names are files (including negative values); the anchored
        # match keeps paths containing `--` as paths.
        if $literal or $arg !~~ /^ '--' <[a..z]> / {
            @files.push: $arg;
            next;
        }

        # Split `=` before the name lookup; `split` rather than a substitution,
        # which operates on a copy of the topic.
        my $name = $arg.substr(2);
        my ($bare, $inline-value) = $name.split: '=', 2;
        my $inline = $inline-value.defined;
        $name = $bare;
        my $value = $inline-value;

        die "Unknown option --{$name}" unless %valued{$name} || %switches{$name};

        if $inline {
            # Refuse values on switches: --quiet=false would mean the opposite.
            die "Option --{$name} does not take a value" if %switches{$name};
        }
        elsif %switches{$name} {
            $value = True;
        }
        else {
            # Negative values are one dash; a following --option is refused.
            my $next = @argv[$i] // '';
            die "Option --{$name} needs a value, but { $next || 'nothing' } follows it"
                if $next eq '' || $next ~~ /^ '--' <[a..z]> /;
            $value = @argv[$i++];
        }

        # Empty values coerce to 0, so refuse them explicitly.
        die "Option --{$name} was given an empty value" if $value eq '';
        die "Option --{$name} was given twice" if %opts{$name}:exists;

        %opts{$name} = $value;
    }

    %opts<files> = @files;
    %opts;
}

# Explicit conversion: Raku rejects Str for Int, and .Int would truncate 3.9.
# Errors name the option so a generic conversion message is not ambiguous.
sub int-arg($raw, Str $name, Int $default --> Int) is export {
    return $default unless $raw.defined;
    my $str = $raw.Str;
    # Allow a sign here as numeric-arg does; range checking belongs to the caller.
    $str ~~ / ^ \s* [ \+ | \- ]? \d+ \s* $/
        or die "Option --{$name} wants a whole number, not '{ $raw }'";
    $str.Int;
}

sub numeric-arg($raw, Str $name, Numeric $default --> Numeric) is export {
    return $default unless $raw.defined;
    my $str = $raw.Str;
    # <[eE]>, not `[eE]`: the latter is an enumeration, not a character class.
    $str ~~ / ^ \s* \-? \d+ ( \. \d+ )? ( <[eE]> \-? \d+ )? \s* $/
        or die "Option --{$name} wants a number, not '{ $raw }'";
    $str.Numeric;
}

# Rate must be positive: bad values otherwise fail deep in libopenmpt with
# messages that look like a corrupt module, not a mistyped option.
sub rate-arg($raw, Int $default = 48000 --> Int) is export {
    my $rate = int-arg($raw, 'rate', $default);
    die "Option --rate must be a positive number of samples per second, not $rate"
        if $rate <= 0;
    $rate;
}
