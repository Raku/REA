use NativeCall;
use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::Util;
use Examples::PlayHelpers;
use Examples::PlayPanel;

unit module Examples::PlayRender;

constant BUF-FRAMES is export = 1024;

# Shared render loop for live playback and WAV export. write-frames returns
# False to abort; pre-filling warms the device and the NativeCall trampolines
# before the timing loop starts.
sub render-core(
    OpenMPT::Bindings::Module $mod, Int $rate, Int $max-frames,
    &write-frames:(Int $got, Pointer[void] $cbuf, Int $bytes --> Bool),
    &update-status,
    &should-stop,
    DisplayState $ds = DisplayState.new,
    Bool :$prewarm = True,
    Int  :$prefill-buffers = 0,
    --> Int
) is export {
    my $cpu-smooth = 0e0;
    my $rendered = 0;
    my $first = $prewarm;

    # A negative write can mean "stop" or "device gone"; ask the watch which.
    # Otherwise Ctrl-C looks like a failed backend and the fallback restarts
    # the track the user just stopped.
    my sub write-aborted(--> Int) { &should-stop() ?? 0 !! -1 }

    my $prefill = $prefill-buffers;
    while $prefill > 0 {
        my $remaining = $max-frames > 0 ?? $max-frames - $rendered !! BUF-FRAMES;
        last if $remaining <= 0 || &should-stop();
        my $count = min(BUF-FRAMES, $remaining);
        my ($got, $p, $bytes) = $mod.read-interleaved-stereo-raw($rate, $count);
        last unless $got;
        return write-aborted() unless write-frames($got, $p, $bytes);
        $rendered += $got;
        $prefill--;
    }
    $first = False if $prefill-buffers;

    while True {
        my $count = $max-frames > 0 ?? min(BUF-FRAMES, $max-frames - $rendered) !! BUF-FRAMES;
        last if $count <= 0;
        # A Ctrl-C during the write has already restored the terminal; do not
        # paint the panel back over it.
        last if &should-stop();
        my $read-start = $first ?? 0 !! now;
        my ($got, $p, $bytes) = $mod.read-interleaved-stereo-raw($rate, $count);
        my $read-time = $first ?? 0 !! now - $read-start;
        $first = False;
        last unless $got;
        # $p is valid only until the next render call, so enqueue() scans it
        # here while the samples are still hot.
        return write-aborted() unless write-frames($got, $p, $bytes);
        $rendered += $got;
        if $read-time {
            my Num $mix = ($got / $rate).Num;
            my Num $inst = $read-time / $mix;
            $cpu-smooth = (1 - $mix) * $cpu-smooth + $mix * $inst;
        }
        next if &should-stop();
        &update-status($ds, $mod, $rendered, $rate, $cpu-smooth * 100, $p, $got);
    }
    $rendered
}

sub render-wav(
    OpenMPT::Bindings::Module $mod, int32 $rate, Str $path,
    Numeric $max-seconds = 0, Bool $quiet = False, $output = Nil
) is export {
    my $ds = DisplayState.new;
    my $outpath = $output ~~ Str ?? $output !! $path.IO.extension('wav').absolute.Str;
    note "Overwriting: $outpath" if $outpath.IO.e;
    my $fh = $outpath.IO.open(:w, :bin);
    LEAVE .close with $fh;

    $fh.write(wav-header($rate, 0));

    my $max-frames = $max-seconds > 0 ?? ($rate * $max-seconds).Int !! 0;
    my sub write-frames(Int $got, Pointer[void] $p, Int $bytes --> Bool) {
        $fh.write(pointer-to-blob($p, $bytes)) or return False;
        True
    }
    my sub silent-status($ds, $, $, $, $, $, $ --> Nil) { }
    my $rendered = render-core($mod, $rate, $max-frames, &write-frames, &silent-status,
        &never-stop, $ds);
    if $rendered < 0 {
        note "WAV rendering failed";
        return;
    }

    $*ERR.print("\n");
    $*ERR.flush;

    my $data-size = $rendered * 4;
    $fh.seek(0, SeekFromBeginning);
    $fh.write(wav-header($rate, $data-size));
    note "Wrote {$outpath.IO.basename}: {($data-size / 1024 / 1024).fmt('%.1f')} MiB, {$rendered} frames"
        unless $quiet;
}
