use NativeCall;

unit module Examples::PlayNative;

# Native declarations and terminal/scheduling helpers for the play example.
# The backend code stays in play-module.raku; only the FFI surface lives here.

constant IS-WIN is export = $*DISTRO.is-win;

# Win32 terminal API (kernel32)
sub GetStdHandle(int32) returns Pointer[void] is native('kernel32') { * }
sub GetConsoleMode(Pointer[void], Pointer[uint32]) returns int32 is native('kernel32') { * }
sub SetConsoleMode(Pointer[void], uint32) returns int32 is native('kernel32') { * }

constant STD_ERROR_HANDLE = -12;
constant ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004;
constant ENABLE_PROCESSED_OUTPUT            = 0x0001;

sub setup-terminal(--> Any) is export {
    if IS-WIN {
        my $errh = GetStdHandle(STD_ERROR_HANDLE);
        return Nil unless $errh.defined && +$errh != 0;
        my $err-mode = CArray[uint32].allocate(1);
        return Nil unless GetConsoleMode($errh, nativecast(Pointer[uint32], $err-mode));

        my $saved = $err-mode[0];
        SetConsoleMode($errh, $saved +| ENABLE_VIRTUAL_TERMINAL_PROCESSING +| ENABLE_PROCESSED_OUTPUT)
            or return Nil;
        return ($errh, $saved);
    }

    my $stty-result = run('stty', '-g', :out, :err($*SPEC.devnull));
    return '' unless $stty-result.exitcode == 0;
    my $saved = $stty-result.out.slurp(:close).trim;
    return '' unless $saved.chars;
    run('stty', '-icanon', '-echo', '-echoe', '-echok', :err($*SPEC.devnull));
    $saved
}

sub restore-terminal(Any $saved) is export {
    return unless $saved.defined;
    if IS-WIN {
        my ($errh, $mode) = $saved ~~ List ?? flat($saved) !! ();
        SetConsoleMode($errh, $mode) if $errh.defined && $mode.defined;
    } else {
        run('stty', $saved, :err($*SPEC.devnull)) if $saved.chars;
    }
}

# Win32 audio API (winmm)
class WAVEFORMATEX is repr('CStruct') is export {
    has uint16 $.wFormatTag;
    has uint16 $.nChannels;
    has uint32 $.nSamplesPerSec;
    has uint32 $.nAvgBytesPerSec;
    has uint16 $.nBlockAlign;
    has uint16 $.wBitsPerSample;
    has uint16 $.cbSize;
}

class WAVEHDR is repr('CStruct') is export {
    has Pointer[void] $.lpData is rw;
    has uint32 $.dwBufferLength is rw;
    has uint32 $.dwBytesRecorded is rw;
    has Pointer[void] $.dwUser is rw;
    has uint32 $.dwFlags is rw;
    has uint32 $.dwLoops is rw;
    has Pointer[void] $.lpNext is rw;
    has Pointer[void] $.reserved is rw;
}

sub waveOutOpen(Pointer[Pointer[void]] $phwo, uint32 $uDeviceID, Pointer[void] $pwfx,
    Pointer[void] $dwCallback, Pointer[void] $dwInstance, uint32 $fdwOpen)
    returns uint32 is native('winmm') is export { * }
sub waveOutPrepareHeader(Pointer[void], Pointer[void], uint32)
    returns uint32 is native('winmm') is export { * }
sub waveOutWrite(Pointer[void], Pointer[void], uint32)
    returns uint32 is native('winmm') is export { * }
sub waveOutUnprepareHeader(Pointer[void], Pointer[void], uint32)
    returns uint32 is native('winmm') is export { * }
sub waveOutClose(Pointer[void]) returns uint32 is native('winmm') is export { * }
sub waveOutReset(Pointer[void]) returns uint32 is native('winmm') is export { * }

sub CreateEventW(Pointer[void], int32, int32, Pointer[void])
    returns Pointer[void] is native('kernel32') is export { * }
sub WaitForSingleObject(Pointer[void], uint32)
    returns uint32 is native('kernel32') is export { * }
sub CloseHandle(Pointer[void]) returns int32 is native('kernel32') is export { * }

constant WAVE_FORMAT_PCM is export = 1;
constant WAVE_MAPPER is export = 0xFFFFFFFF;
constant CALLBACK_EVENT is export = 0x00050000;
constant WHDR_DONE is export = 0x00000001;

# PulseAudio Simple API
class pa_sample_spec is repr('CStruct') is export {
    has int32  $.format;
    has uint32 $.rate;
    has uint8  $.channels;
}

constant PA_STREAM_PLAYBACK is export = 1;
constant PA_SAMPLE_S16LE is export = 3;

sub pa_simple_new(Pointer[void], Str, int32, Pointer[void], Str,
    Pointer[pa_sample_spec], Pointer[void], Pointer[void], CArray[int32])
    returns Pointer[void] is native('pulse-simple') is export { * }
sub pa_simple_write(Pointer[void], Pointer[void], size_t, CArray[int32])
    returns int32 is native('pulse-simple') is export { * }
sub pa_simple_drain(Pointer[void], CArray[int32])
    returns int32 is native('pulse-simple') is export { * }
sub pa_simple_free(Pointer[void]) is native('pulse-simple') is export { * }

# ALSA libasound
class SndPcmT is repr('CPointer') is export { }

constant SND_PCM_STREAM_PLAYBACK is export = 0;
constant SND_PCM_FORMAT_S16_LE is export = 2;
constant SND_PCM_ACCESS_RW_INTERLEAVED is export = 3;

sub snd_pcm_open(CArray[SndPcmT] $pcm, Str $name, int32 $stream, int32 $mode)
    returns int32 is native('asound') is export { * }
sub snd_pcm_set_params(SndPcmT $pcm, int32 $format, int32 $access,
    uint32 $channels, uint32 $rate, int32 $soft_resample, uint32 $latency)
    returns int32 is native('asound') is export { * }
sub snd_pcm_writei(SndPcmT $pcm, Pointer[void] $buf, size_t $frames)
    returns int64 is native('asound') is export { * }
sub snd_pcm_recover(SndPcmT $pcm, int32 $err, int32 $silent)
    returns int32 is native('asound') is export { * }
sub snd_pcm_drain(SndPcmT $pcm) returns int32 is native('asound') is export { * }
sub snd_pcm_drop(SndPcmT $pcm) returns int32 is native('asound') is export { * }
sub snd_pcm_close(SndPcmT $pcm) returns int32 is native('asound') is export { * }
sub snd_strerror(int32 $err) returns Str is native('asound') is export { * }

# Thread scheduling
constant SCHED-OTHER is export = 0;
constant SCHED-FIFO is export = 1;
constant SCHED-IDLE is export = 5;

class SchedParam is repr('CStruct') {
    has int32 $.sched-priority is rw;
}

sub sched_setscheduler(int32, int32, Pointer[void])
    returns int32 is native('libc.so.6') { * }

# pid 0 means the calling thread. A failed call leaves the thread at its
# current priority; callers decide whether to proceed or report it.
sub set-thread-sched(int32 $policy, int32 $priority --> Bool) is export {
    my $param = SchedParam.new;
    $param.sched-priority = $priority;
    sched_setscheduler(0, $policy, nativecast(Pointer[void], $param)) == 0
}
