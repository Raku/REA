use NativeCall;
# Helpers sit beside the script so it works from any directory.
use lib $?FILE.IO.parent;
use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::Util;
use Examples::Common;
use Examples::PlayHelpers;
use Examples::PlayNative;
use Examples::PlayPanel;
use Examples::PlayRender;
use Examples::PlayInfo;

# ALSA's device buffer, in microseconds. A round 100 ms absorbs scheduling
# jitter without making a stopped playback take long to notice.
constant ALSA-LATENCY-US = 100_000;
# A peer of the desktop's other real-time audio threads. A failed call leaves
# the thread at normal priority and is reported at startup.
constant AUDIO-RT-PRIORITY = 10;

# ============================================================================
# Audio backends
# ============================================================================
# Each backend takes (module, rate, max-frames, &status, &stop, $watch) and
# returns 0 on success or -1 on failure. $max-frames 0 means unlimited.

sub play-waveout(OpenMPT::Bindings::Module $mod, Int $rate, Int $max-frames, $update-status, &should-stop, Interrupt-Watch $watch = Interrupt-Watch.new --> Int) {
    my $ds = DisplayState.new;
    my $h-wave-int = CArray[uint64].allocate(1);
    my $wfx = WAVEFORMATEX.new(
        :wFormatTag(WAVE_FORMAT_PCM), :nChannels(2),
        :nSamplesPerSec($rate), :wBitsPerSample(16),
        :nBlockAlign(4), :nAvgBytesPerSec($rate * 4),
    );
    my $phwo = nativecast(Pointer[Pointer[void]], $h-wave-int);
    my $hEvent = CreateEventW(Pointer[void], 0, 0, Pointer[void]);
    return -1 unless $hEvent.defined && +$hEvent != 0;
    my $rc = waveOutOpen($phwo, WAVE_MAPPER, nativecast(Pointer[void], $wfx),
        nativecast(Pointer[void], $hEvent), Pointer[void], CALLBACK_EVENT);
    return -1 if $rc != 0;
    my $hwo-addr = $h-wave-int[0];
    return -1 if $hwo-addr == 0;
    my $hwo = Pointer[void].new($hwo-addr);
    LEAVE { CloseHandle($hEvent); waveOutClose($hwo) }

    constant WAVEOUT-BUF = IS-WIN ?? 8 !! 3;
    my @buf = (^WAVEOUT-BUF).map: { CArray[int16].allocate(BUF-FRAMES * 2) }
    my @wh  = (^WAVEOUT-BUF).map: -> $i {
        WAVEHDR.new(
            :lpData(nativecast(Pointer[void], @buf[$i])),
            :dwBufferLength(BUF-FRAMES * 4),
        )
    }
    my @inflight = False xx WAVEOUT-BUF;
    my $slot = 0;

    my sub write(Int $got, Pointer[void] $cbuf --> Int) {
        if @inflight[$slot] {
            until @wh[$slot].dwFlags +& WHDR_DONE {
                WaitForSingleObject($hEvent, 0xFFFFFFFF)
            }
            waveOutUnprepareHeader($hwo, nativecast(Pointer[void], @wh[$slot]), nativesizeof(WAVEHDR));
            @inflight[$slot] = False;
        }

        my $bytes = $got * 4;
        memcpy(nativecast(Pointer[void], @buf[$slot]), $cbuf, $bytes);

        @wh[$slot].dwBufferLength = $bytes;
        @wh[$slot].dwFlags = 0;
        @wh[$slot].dwBytesRecorded = 0;
        @inflight[$slot] = True;
        waveOutPrepareHeader($hwo, nativecast(Pointer[void], @wh[$slot]), nativesizeof(WAVEHDR));
        waveOutWrite($hwo, nativecast(Pointer[void], @wh[$slot]), nativesizeof(WAVEHDR));

        $slot = ($slot + 1) % WAVEOUT-BUF;
        0;
    }

    LEAVE {
        if should-play-out-tail(:interrupted(&should-stop()), :failed(False)) {
            # Wait for queued buffers so the last note is heard; sleep(0) burned
            # a core and still could not notice Ctrl-C.
            for ^WAVEOUT-BUF -> $i {
                next unless @inflight[$i];
                until @wh[$i].dwFlags +& WHDR_DONE {
                    WaitForSingleObject($hEvent, 0xFFFFFFFF)
                }
            }
        }
        else {
            # Reset marks pending buffers done instead of waiting on a device
            # that may be the reason we are stopping.
            waveOutReset($hwo);
        }
        for ^WAVEOUT-BUF -> $i {
            next unless @inflight[$i];
            waveOutUnprepareHeader($hwo, nativecast(Pointer[void], @wh[$i]), nativesizeof(WAVEHDR));
            @inflight[$i] = False;
        }
    }

    play-loop($mod, $rate, $max-frames, $ds, &write, $update-status, &should-stop);
}

sub play-pulse(OpenMPT::Bindings::Module $mod, Int $rate, Int $max-frames, &update-status, &should-stop, Interrupt-Watch $watch = Interrupt-Watch.new --> Int) {
    my $ds = DisplayState.new;
    my $ss = pa_sample_spec.new(:format(PA_SAMPLE_S16LE), :rate($rate), :channels(2));
    my $err = CArray[int32].allocate(1);
    my $pa = pa_simple_new(Pointer[void], 'OpenMPT', PA_STREAM_PLAYBACK, Pointer[void], 'Audio',
        nativecast(Pointer[pa_sample_spec], $ss),
        Pointer[void], Pointer[void], $err);
    return -1 unless $pa;
    LEAVE { pa_simple_free($pa) if $pa }

    my sub write(Int $got, Pointer[void] $cbuf --> Int) {
        # Mark the one blocking call so a single Ctrl-C can tell a wedged sink
        # from the render loop not having polled yet; libpulse retries EINTR.
        $watch.blocking;
        my $wrote = pa_simple_write($pa, $cbuf, $got * 4, $err);
        $watch.returned;
        $wrote == 0 ?? 0 !! -1
    }
    my $rc = play-loop($mod, $rate, $max-frames, $ds, &write, &update-status, &should-stop);
    # Drain only on a clean stop: after Ctrl-C the server may be gone, and
    # drain can block for the length of the queue. Not marked as wedged for
    # that reason; a slow-but-fine drain is legitimate.
    if $rc == 0 && should-play-out-tail(:interrupted(&should-stop()), :failed(False)) {
        pa_simple_drain($pa, $err);
    }
    $rc
}

sub play-alsa(OpenMPT::Bindings::Module $mod, Int $rate, Int $max-frames, &update-status, &should-stop, Interrupt-Watch $watch = Interrupt-Watch.new --> Int) {
    my $ds = DisplayState.new;
    my $pcm-arr = CArray[SndPcmT].allocate(1);
    my $rc = snd_pcm_open($pcm-arr, 'default', SND_PCM_STREAM_PLAYBACK, 0);
    if $rc < 0 {
        note "ALSA open failed: { snd_strerror($rc) }";
        return -1;
    }
    my $pcm = $pcm-arr[0];
    # Drain and drop are safe before set_params, so arm cleanup early.
    my $configured = False;
    LEAVE {
        # Drain on a clean stop; drop immediately on interrupt or failure.
        if $configured && should-play-out-tail(:interrupted(&should-stop()), :failed(False)) {
            snd_pcm_drain($pcm);
        }
        else {
            snd_pcm_drop($pcm);
        }
        snd_pcm_close($pcm);
    }

    $rc = snd_pcm_set_params($pcm, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED,
        2, $rate, 1, ALSA-LATENCY-US);
    if $rc < 0 {
        note "ALSA set_params failed: { snd_strerror($rc) }";
        return -1;
    }
    $configured = True;

    my sub write(Int $got, Pointer[void] $cbuf --> Int) {
        alsa-write-all($pcm, nativecast(Pointer[int16], $cbuf), $got, &should-stop, $watch)
    }
    play-loop($mod, $rate, $max-frames, $ds, &write, &update-status, &should-stop);
}

# Adapt backend write callbacks to render-core's Bool-returning write.
sub play-loop(
    OpenMPT::Bindings::Module $mod, Int $rate, Int $max-frames,
    DisplayState $ds,
    &write-chunk:(Int $got, Pointer[void] $cbuf --> Int),
    $update-status,
    &should-stop,
    --> Int
) {
    # Real time only while feeding the device; restore priority on exit.
    my $rt = set-thread-sched(SCHED-FIFO, AUDIO-RT-PRIORITY);
    unless $rt {
        set-thread-sched(SCHED-OTHER, 0);
        note "audio thread stays at normal priority: no real-time privilege; "
            ~ "timing will be less reliable";
    }

    my sub write(Int $got, Pointer[void] $p, Int $bytes --> Bool) {
        write-chunk($got, $p) >= 0
    }
    # Argument order must match render-core's signature.
    my $rc = render-core($mod, $rate, $max-frames, &write, $update-status,
        &should-stop, $ds, :prefill-buffers(3));
    set-thread-sched(SCHED-OTHER, 0);
    $rc >= 0 ?? 0 !! -1
}

my %BACKENDS =
    pulse    => &play-pulse,
    alsa     => &play-alsa,
    waveout  => &play-waveout,
;

# Retry partial ALSA writes, checking for stop each time. A stopped device can
# turn the write into a long wait, so the loop must remain cancellable.
sub alsa-write-all(SndPcmT $pcm, Pointer[int16] $buf, Int $frames, &should-stop, Interrupt-Watch $watch = Interrupt-Watch.new --> Int) {
    my $offset = 0;
    while $offset < $frames {
        return -1 if &should-stop();
        # Mark the blocking device call so one Ctrl-C can identify a wedged
        # interface instead of requiring a second press.
        $watch.blocking;
        my $got = snd_pcm_writei($pcm, nativecast(Pointer[void], $buf.add($offset)), $frames - $offset);
        $watch.returned;
        if $got < 0 {
            $got = snd_pcm_recover($pcm, $got.Int, 1);
            if $got < 0 {
                return -1;  # unrecoverable error
            }
            if $got == 0 {
                sleep(0.001);  # recovery succeeded but wrote 0 — device may need time
                next;
            }
        }
        next if $got == 0;  # snd_pcm_writei returned 0 with no error — retry same offset
        $offset += $got;
    }
    0;
}

# ============================================================================
# Entry point
# ============================================================================

# A plain program body, not sub MAIN: Raku's dispatcher splits options before
# a slurpy and binds them wrongly when they precede file names. Returns 0 clean,
# 1 failed, 130 interrupted.
sub play-main(@argv --> Int) {
    my %opts = parse-args(@argv, PLAY-VALUED, PLAY-SWITCHES);
    my @files = %opts<files>.List;
    # --quiet only suppresses informational output; errors are always reported.
    my $quiet = %opts<quiet> // False;

    if %opts<list-extensions> {
        .say for OpenMPT::Bindings::Module.supported-extensions.sort;
        return 0;
    }
    if %opts<help> {
        say play-usage;
        return 0;
    }

    my $info      = %opts<info>      // False;
    my $render-wav = %opts<render-wav> // False;
    my $output = %opts<output> // Nil;
    # One --output per input, or renders would overwrite each other.
    if $output.defined and @files > 1 {
        die "Multiple input files with --output will overwrite each other; --render-wav one at a time";
    }
    my $subsong   = int-arg     %opts<subsong>, 'subsong', 0;
    my $repeat    = int-arg     %opts<repeat>,  'repeat',  0;
    my $seek      = numeric-arg %opts<seek>,    'seek',    0;
    my $seconds   = numeric-arg %opts<seconds>, 'seconds', 0;
    my $gain      = numeric-arg %opts<gain>,    'gain',    0;
    my $tempo     = numeric-arg %opts<tempo>,   'tempo',   1.0;
    my $rate      = rate-arg    %opts<rate>;
    my $backend   = %opts<backend>;

    die "No input files" unless @files;

    # Worst outcome across files wins.
    my $exit-code = 0;

    for @files -> $path {
        # Missing files and unknown backends are user errors, not silent skips.
        unless $path.IO.e {
            note "Skipping $path: no such file";
            $exit-code = 1;
            next;
        }

        my $mod = try OpenMPT::Bindings::Module.from-file($path);
        if $! {
            note "Skipping $path: { $!.message }";
            next;
        }

        note "\n--- { $path.IO.basename } ---" if @files > 1 && !$quiet;

        if $info {
            show-info($mod, $path);
            next;
        }

        $mod.select-subsong($subsong);
        $mod.set-repeat-count($repeat);
        $mod.set-position($seek) if $seek > 0;
        $mod.set-mastergain(db-to-millibel($gain)) if $gain != 0;
        $mod.set-ctl('play.tempo_factor', $tempo.Num) if $tempo != 1.0;

        show-header($mod, $path) unless $quiet;

        # --render-wav renders a WAV file without playback
        if $render-wav {
            render-wav($mod, $rate, $path, $seconds, $quiet, $output);
            next;
        }

        # Only cap playback length when --seconds is explicitly given
        my $max-frames = $seconds > 0 ?? ($rate * $seconds).Int !! 0;

        # Select audio backend: user-specified or platform default
        my $bname = $backend.defined ?? $backend !! default-backend(:is-win(IS-WIN));
        my $cb = %BACKENDS{$bname};
        unless is-known-backend($bname) && $cb.defined {
            note "Unknown backend '$bname'; try { backend-hint }";
            $exit-code = 1;
            next;
        }
        note "Audio backend: $bname" unless $quiet;

        # Keep playback in its own block: LEAVE is block-scoped, so the --info
        # and --render-wav paths above must not run the terminal restore with an
        # uninitialised watch.
        do {
            my $saved-terminal = setup-terminal;
            my $orig-err-buf = $*ERR.out-buffer;
            $*ERR.out-buffer = 0;  # zero-byte buffer size disables output buffering
            $*ERR.flush;

            # One handler per file, since the restore callback captures this
            # session's terminal state. Capture a block, not the result of
            # calling restore-terminal.
            my $watch = watch-interrupts({ restore-terminal($saved-terminal) });
            my &should-stop = sub (--> Bool) { $watch.stopped };

            # On scope exit: keep status visible, restore terminal
            LEAVE {
                # Close first so no stale handler can restore the terminal later.
                $watch.close;
                $*ERR.print("\n");
                $*ERR.flush;
                $*ERR.out-buffer = $orig-err-buf;
                restore-terminal($saved-terminal);
            }

            # --quiet suppresses messages, not the panel.
            my $painter = status-painter($watch);
            my &update = $painter.callback;
            # The watch lets a backend mark uninterruptible device calls.
            my $rc = $cb($mod, $rate, $max-frames, &update, &should-stop, $watch);
            # Retry the default chain from the start; setup failures write no
            # frames. A backend named with --backend is never retried.
            unless $backend.defined {
                my $failed = $bname;
                my $next = fallback-backend($failed);
                while $rc < 0 && $next.chars {
                    note "{ $failed } unavailable, falling back to $next";
                    $mod.set-position($seek > 0 ?? $seek !! 0);
                    $rc = %BACKENDS{$next}($mod, $rate, $max-frames, &update, &should-stop, $watch);
                    $failed = $next;
                    $next = fallback-backend($failed);
                }
            }
            # Drain the painter before restoring the terminal, or a late repaint
            # leaves escape codes on a cooked terminal.
            $painter.close;
            if $rc < 0 {
                note "Playback failed — try --render-wav to render to WAV instead";
            }
            # Exits used to be 0 even on failure or interrupt. Worst code wins,
            # with interrupt ranked above failure.
            my $code = playback-exit-code(:interrupted($watch.stopped), :failed($rc < 0));
            $exit-code = $code if $code > $exit-code;
        }
    }
    $exit-code;
}

# ============================================================================
# Run
# ============================================================================

# Program body; see the note on play-main.
exit play-main(@*ARGS);
