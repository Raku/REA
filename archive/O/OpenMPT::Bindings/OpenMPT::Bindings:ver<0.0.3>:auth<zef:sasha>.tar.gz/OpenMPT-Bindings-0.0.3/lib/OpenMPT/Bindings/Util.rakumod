use NativeCall;
use OpenMPT::Bindings::NativeLib;

unit module OpenMPT::Bindings::Util;

# ============================================================================
# Binary helpers
# ============================================================================

sub le16(Int $v --> Blob) is export {
    die "Value $v exceeds 16-bit unsigned range" if $v > 0xFFFF || $v < 0;
    Buf.new($v +& 0xFF, ($v +> 8) +& 0xFF);
}

sub le32(Int $v --> Blob) is export {
    die "Value $v exceeds 32-bit unsigned range" if $v > 0xFFFF_FFFF || $v < 0;
    Buf.new($v +& 0xFF, ($v +> 8) +& 0xFF, ($v +> 16) +& 0xFF, ($v +> 24) +& 0xFF);
}

# ============================================================================
# Time formatting
# ============================================================================

sub fmt-time(Numeric $sec --> Str) is export {
    my $t = max(0, $sec // 0);
    my $total = $t.Int;
    my $h = $total div 3600;
    my $m = $total % 3600 div 60;
    my $s = $total % 60;
    my $ms = (($t - $total) * 1000).Int;
    if $h > 0 {
        sprintf '%d:%02d:%02d.%03d', $h, $m, $s, $ms;
    } else {
        sprintf '%02d:%02d.%03d', $m, $s, $ms;
    }
}

# ============================================================================
# Pointer → Blob copy
# ============================================================================

sub memcpy(Pointer[void] $dst, Pointer[void] $src, size_t $n --> Pointer[void]) is native(&LIBC) is symbol('memcpy') is export { * }

sub pointer-to-blob(Pointer[void] $src, Int $bytes --> Blob) is export {
    my $buf = Buf.allocate($bytes);
    memcpy(nativecast(Pointer[void], $buf), $src, $bytes);
    $buf
}

sub posix-write(int32 $fd, Pointer[void] $buf, size_t $n --> long) is native(&LIBC) is symbol('write') is export { * }

# ============================================================================
# WAV header
# ============================================================================

sub wav-header(int32 $rate, Int $data-size, Int $channels = 2, Int :$bits = 16 --> Blob) is export {
    die "Unsupported bits per sample: $bits (only 16 and 32 supported)" if $bits != 16 && $bits != 32;
    die "data-size must be >= 0, got $data-size" if $data-size < 0;
    my $file-size = 36 + $data-size;
    die "WAV file too large: $file-size bytes exceeds 4 GiB limit" if $file-size > 0xFFFF_FFFF;
    my $format-tag = $bits == 16 ?? 1 !! 3;  # PCM or IEEE float
    my $bytes-per-sample = $bits div 8;
    Blob.new(
        0x52, 0x49, 0x46, 0x46,       # RIFF
        |le32($file-size),             # file size
        0x57, 0x41, 0x56, 0x45,       # WAVE
        0x66, 0x6D, 0x74, 0x20,       # fmt
        |le32(16),                     # chunk size
        |le16($format-tag),            # format tag
        |le16($channels),              # channels
        |le32($rate),                  # sample rate
        |le32($rate * $channels * $bytes-per-sample),  # byte rate
        |le16($channels * $bytes-per-sample),          # block align
        |le16($bits),                  # bits per sample
        0x64, 0x61, 0x74, 0x61,       # data
        |le32($data-size),             # data size
    );
}
