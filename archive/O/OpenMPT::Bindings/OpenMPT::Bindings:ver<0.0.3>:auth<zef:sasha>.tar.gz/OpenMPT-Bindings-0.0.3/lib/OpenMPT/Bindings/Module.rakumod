use NativeCall;
use OpenMPT::Bindings::Native;
use OpenMPT::Bindings::Exception;
use OpenMPT::Bindings::Types;
use OpenMPT::Bindings::Util;

unit class OpenMPT::Bindings::Module;

constant LIBOPENMPT_SEQUENCE_API = 0x00090000;  # openmpt_module_get_current_sequence added in libopenmpt 0.9.0
constant EMPTY-BUF = Blob.new;

has Pointer[void] $.handle;
has Blob          $.data;
has Bool          $!skip-destroy;
has Bool          $!destroyed = False;

submethod BUILD(:$!handle = Pointer[void], :$!data, Bool :$!skip-destroy = False, |) { }
# BUILD is used by ModuleExt.from-blob which calls Module.new(:handle(...), :skip-destroy).
# The primary constructor is from-blob/from-file.

method !set-handle(Pointer[void] $h) { $!handle = $h }
method detach-handle(--> Nil) { $!destroyed = True }

has CArray[int16] $!s16-buf;     # Shared across read-stereo, read-mono, read-interleaved-stereo, read-quad, and write-interleaved-stereo-s16-to-handle
has size_t        $!s16-buf-size;
has CArray[num32]  $!f32-buf;    # Shared across all read-*-float variants
has size_t         $!f32-buf-size;
has CArray[int32]  $!render-param-buf;
has Pointer[int32] $!render-param-cast;
has Int            $!c-channels;
has Int            $!c-patterns;
has Int            $!c-instruments;
has Int            $!c-samples;
has Int            $!c-subsongs;
has Int            $!c-orders;
has Bool           $!sequence-available;
has Buf            $!write-blob;
has List           $!metadata-keys-cache;
has List           $!ctl-keys-cache;

# ============================================================================
# Library info (class methods)
# ============================================================================

# Library info — these are class-level methods (ignore $!handle, safe on type object)
method library-version(--> uint32) { openmpt_get_library_version() }
method core-version(--> uint32)    { openmpt_get_core_version() }

method library-string(Str $key --> Str) {
    state %cache;
    return %cache{$key} if %cache{$key}:exists;
    my $p = openmpt_get_string($key);
    with $p {
        my $s = nativecast(Str, $p);
        openmpt_free_string($p);
        %cache{$key} = $s;
    }
}

method supported-extensions(--> List) {
    state $extensions = do {
        my $p = openmpt_get_supported_extensions;
        with $p {
            my $s = nativecast(Str, $p);
            openmpt_free_string($p);
            $s.split(';').grep(*.chars).List
        } else {
            List.new
        }
    }
}

method is-extension-supported(Str $extension --> Bool) {
    ?openmpt_is_extension_supported($extension)
}

method probe-file-header-get-recommended-size(--> Int) {
    openmpt_probe_file_header_get_recommended_size
}

my sub check-probe-error($error, $msg-p, $function) {
    my $msg = $msg-p[0] ?? nativecast(Str, $msg-p[0]) !! Str;
    openmpt_free_string($msg-p[0]) if $msg-p[0];
    if $error[0] {
        die build-error($error[0], $function, $msg);
    }
}

method probe-file-header(
    Blob $data, uint64 $filesize, uint64 $flags = OPENMPT_PROBE_FILE_HEADER_FLAGS_DEFAULT,
    --> OpenMPTProbeResult
) {
    my $error = CArray[int32].allocate(1);
    my $msg-p = CArray[Pointer[uint8]].allocate(1);
    my $result = openmpt_probe_file_header(
        $flags,
        nativecast(Pointer[void], $data), $data.bytes, $filesize,
        &cb-log-silent, NULL,
        &cb-error-store, NULL,
        nativecast(Pointer[int32], $error),
        nativecast(Pointer[Pointer[uint8]], $msg-p),
    );
    check-probe-error($error, $msg-p, 'openmpt_probe_file_header');
    OpenMPTProbeResult($result)
}

method probe-file-header-without-filesize(
    Blob $data, uint64 $flags = OPENMPT_PROBE_FILE_HEADER_FLAGS_DEFAULT,
    --> OpenMPTProbeResult
) {
    my $error = CArray[int32].allocate(1);
    my $msg-p = CArray[Pointer[uint8]].allocate(1);
    my $result = openmpt_probe_file_header_without_filesize(
        $flags,
        nativecast(Pointer[void], $data), $data.bytes,
        &cb-log-silent, NULL,
        &cb-error-store, NULL,
        nativecast(Pointer[int32], $error),
        nativecast(Pointer[Pointer[uint8]], $msg-p),
    );
    check-probe-error($error, $msg-p, 'openmpt_probe_file_header_without_filesize');
    OpenMPTProbeResult($result)
}

# ============================================================================
# Construction
# ============================================================================

method from-blob(Blob $data, :%ctls --> ::?CLASS) {
    my $error = CArray[int32].allocate(1);
    my $msg-p = CArray[Pointer[uint8]].allocate(1);

    # Real log/error callbacks are passed so libopenmpt captures the error
    # code and message in the out-params; caller dies on non-zero $error[0].
    my $raw = openmpt_module_create_from_memory2(
        nativecast(Pointer[void], $data),
        $data.bytes,
        &cb-log-silent, NULL,
        &cb-error-store, NULL,
        nativecast(Pointer[int32], $error),
        nativecast(Pointer[Pointer[uint8]], $msg-p),
        NULL,   # CTL array — set individually below instead
    );

    my $blessed = False;
    LEAVE {
        openmpt_module_destroy($raw) if $raw && !$blessed;
    }
    # Guard pattern: $blessed starts False. If bless or !set-handle or any
    # intermediate processing throws, LEAVE destroys $raw (no object owns
    # it). After $blessed = True, the object owns the handle via DESTROY;
    # LEAVE is a no-op.

    my $msg = $msg-p[0] ?? nativecast(Str, $msg-p[0]) !! Str;
    openmpt_free_string($msg-p[0]) if $msg-p[0];
    unless $raw {
        die build-error($error[0] || OPENMPT_ERROR_UNKNOWN, 'openmpt_module_create_from_memory2', $msg);
    }

    my $self = self.bless(:data($data));

    $self!set-handle($raw);
    $blessed = True;
    openmpt_module_error_clear($raw);

    for %ctls.kv -> $k, $v {
        next unless $v.defined;
        unless apply-ctl($raw, $k, $v) {
            my $msg = openmpt_module_error_get_last_message($raw);
            warn "OpenMPT CTL '$k' rejected at load time: { $msg ?? nativecast(Str, $msg) !! 'unknown error' }";
            openmpt_free_string($msg) if $msg;
        }
    }

    $self
}

method from-file(Str $path, :%ctls --> ::?CLASS) {
    my $data = $path.IO.slurp(:bin);
    self.from-blob($data, :%ctls);
}

# ============================================================================
# Destruction
# ============================================================================

submethod DESTROY {
    return if $!destroyed || !$!handle || $!skip-destroy;
    $!destroyed = True;
    openmpt_module_destroy($!handle);
}

# ============================================================================
# Error helpers
# ============================================================================

method !check-error(Str $func) {
    self!guard;
    my $code = openmpt_module_error_get_last($!handle);
    return unless $code;
    my $msg-p = openmpt_module_error_get_last_message($!handle);
    my $msg = $msg-p ?? nativecast(Str, $msg-p) !! "Unknown error";
    openmpt_free_string($msg-p) if $msg-p;
    openmpt_module_error_clear($!handle);
    die X::OpenMPT::Bindings.new(:function($func), :code($code), :message($msg));
}

method error-get-last(--> Int) {
    self!guard;
    openmpt_module_error_get_last($!handle)
}

method error-get-last-message(--> Str) {
    self!guard;
    my $p = openmpt_module_error_get_last_message($!handle);
    self!free-str($p)
}

method error-clear(--> Nil) {
    self!guard;
    openmpt_module_error_clear($!handle)
}

# ============================================================================
# Blob copy helper — copies CArray data to a Blob using fast pointer access
# instead of element-by-element CArray iteration.
# ============================================================================

method !rp-buf(--> Pointer[int32]) {
    $!render-param-buf  //= CArray[int32].allocate(1);        # CArray.allocate never reallocates,
    $!render-param-cast //= nativecast(Pointer[int32], $!render-param-buf);  # so the cached cast is stable.
    $!render-param-cast
}

method !guard(--> Nil) {
    if $!destroyed || !$!handle {
        die X::OpenMPT::Bindings.new(
            :function('<use-after-free>'),
            :code(OPENMPT_ERROR_INVALID_MODULE_POINTER),
            :message("Module handle has been destroyed or not initialized"),
        )
    }
}

# Resize CArray buffers on demand: !ensure-s16 for int16, !ensure-f32 for num32.
# $needed is in frames (multiplied by channels inside the caller).

method !ensure-s16($buf is rw, $size is rw, $needed) {
    return if $buf.defined && $size >= $needed;
    $buf = CArray[int16].allocate($needed);
    $size = $needed;
}

method !ensure-f32($buf is rw, $size is rw, $needed) {
    return if $buf.defined && $size >= $needed;
    $buf = CArray[num32].allocate($needed);
    $size = $needed;
}

# ============================================================================
# Audio output
# ============================================================================

method !write-buf-to-fh(IO::Handle $fh, CArray[int16] $buf, Int $bytes --> Bool) {
    # Windows: skip raw posix-write (symbol is _write not write) and use IO::Handle.write.
    my $fd = try $fh.native-descriptor;
    if defined $fd && $fd > 0 && !$*DISTRO.is-win {
        my $p = nativecast(Pointer[uint8], nativecast(Pointer[void], $buf));
        my $off = 0;
        while $off < $bytes {
            my $n = posix-write($fd, nativecast(Pointer[void], $p.add($off)), $bytes - $off);
            return False if $n <= 0;   # $n == 0 = EOF (pipe closed by reader); $n == -1 = error
            $off += $n;
        }
        return True;
    }
    unless $!write-blob && $!write-blob.bytes >= $bytes {
        $!write-blob = Buf.allocate($bytes);
    }
    memcpy(nativecast(Pointer[void], $!write-blob), nativecast(Pointer[void], $buf), $bytes);
    $fh.write($!write-blob.subbuf(0, $bytes))
        or return False;
    True
}

# ============================================================================
# Audio rendering — float stereo (primary use case)
# ============================================================================

constant STEREO-S16-BPF = 4;  # bytes per stereo int16 frame

method !read-float-stereo-impl(int32 $rate, size_t $frames --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    self!ensure-f32($!f32-buf, $!f32-buf-size, $frames * 2);
    my $p = nativecast(Pointer[num32], $!f32-buf);
    my $left  = nativecast(CArray[num32], $p);
    my $right = nativecast(CArray[num32], $p.add($frames));
    my $count = openmpt_module_read_float_stereo($!handle, $rate, $frames, $left, $right);
    self!check-error('openmpt_module_read_float_stereo');
    $count > 0 or return (0, EMPTY-BUF, EMPTY-BUF);
    return ($count,
        pointer-to-blob(nativecast(Pointer[void], $left),  $count * 4),
        pointer-to-blob(nativecast(Pointer[void], $right), $count * 4));
}

method read-float-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!read-float-stereo-impl($rate, $frames)
}

method read-interleaved-float-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $needed = $frames * 2;
    self!ensure-f32($!f32-buf, $!f32-buf-size, $needed);
    my $count = openmpt_module_read_interleaved_float_stereo($!handle, $rate, $frames, $!f32-buf);
    self!check-error('openmpt_module_read_interleaved_float_stereo');
    $count > 0 or return (0, EMPTY-BUF);
    return ($count, pointer-to-blob(nativecast(Pointer[void], $!f32-buf), $count * 8));
}

method read-interleaved-float-stereo-raw(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $needed = $frames * 2;
    self!ensure-f32($!f32-buf, $!f32-buf-size, $needed);
    my $count = openmpt_module_read_interleaved_float_stereo($!handle, $rate, $frames, $!f32-buf);
    self!check-error('openmpt_module_read_interleaved_float_stereo');
    $count > 0 or return (0, Pointer[void], 0);
    return ($count, nativecast(Pointer[void], $!f32-buf), $count * 8);
}

method !read-float-mono-impl(int32 $rate, size_t $frames --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    self!ensure-f32($!f32-buf, $!f32-buf-size, $frames);
    my $count = openmpt_module_read_float_mono($!handle, $rate, $frames, $!f32-buf);
    self!check-error('openmpt_module_read_float_mono');
    $count > 0 or return (0, EMPTY-BUF);
    return ($count, pointer-to-blob(nativecast(Pointer[void], $!f32-buf), $count * 4));
}

method read-float-mono(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!read-float-mono-impl($rate, $frames)
}

method read-interleaved-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $needed = $frames * 2;
    self!ensure-s16($!s16-buf, $!s16-buf-size, $needed);
    my $count = openmpt_module_read_interleaved_stereo($!handle, $rate, $frames, $!s16-buf);
    self!check-error('openmpt_module_read_interleaved_stereo');
    $count > 0 or return (0, EMPTY-BUF);
    return ($count, pointer-to-blob(nativecast(Pointer[void], $!s16-buf), $count * STEREO-S16-BPF));
}

method read-interleaved-stereo-raw(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $needed = $frames * 2;
    self!ensure-s16($!s16-buf, $!s16-buf-size, $needed);
    my $count = openmpt_module_read_interleaved_stereo($!handle, $rate, $frames, $!s16-buf);
    self!check-error('openmpt_module_read_interleaved_stereo');
    $count > 0 or return (0, Pointer[void], 0);
    return ($count, nativecast(Pointer[void], $!s16-buf), $count * STEREO-S16-BPF);
}

method write-interleaved-stereo-s16-to-handle(IO::Handle $fh, int32 $rate = 48000, size_t $frames = 1024 --> Int) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $needed = $frames * 2;
    self!ensure-s16($!s16-buf, $!s16-buf-size, $needed);
    my $count = openmpt_module_read_interleaved_stereo($!handle, $rate, $frames, $!s16-buf);
    self!check-error('openmpt_module_read_interleaved_stereo');
    if $count {
        die 'write-interleaved-stereo-s16-to-handle: write failed'
            unless self!write-buf-to-fh($fh, $!s16-buf, $count * STEREO-S16-BPF);
    }
    $count
}

method !read-stereo-impl(int32 $rate, size_t $frames --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    self!ensure-s16($!s16-buf, $!s16-buf-size, $frames * 2);
    my $p = nativecast(Pointer[int16], $!s16-buf);
    my $left  = nativecast(CArray[int16], $p);
    my $right = nativecast(CArray[int16], $p.add($frames));
    my $count = openmpt_module_read_stereo($!handle, $rate, $frames, $left, $right);
    self!check-error('openmpt_module_read_stereo');
    $count > 0 or return (0, EMPTY-BUF, EMPTY-BUF);
    return ($count,
        pointer-to-blob(nativecast(Pointer[void], $left),  $count * 2),
        pointer-to-blob(nativecast(Pointer[void], $right), $count * 2));
}

method read-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!read-stereo-impl($rate, $frames)
}

# ============================================================================
# Audio rendering — int16 mono
# ============================================================================

method !read-mono-impl(int32 $rate, size_t $frames --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    self!ensure-s16($!s16-buf, $!s16-buf-size, $frames);
    my $count = openmpt_module_read_mono($!handle, $rate, $frames, $!s16-buf);
    self!check-error('openmpt_module_read_mono');
    $count > 0 or return (0, EMPTY-BUF);
    return ($count, pointer-to-blob(nativecast(Pointer[void], $!s16-buf), $count * 2));
}

method read-mono(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!read-mono-impl($rate, $frames)
}

# ============================================================================
# Audio rendering — float quad
# ============================================================================

method !read-float-quad-impl(int32 $rate, size_t $frames --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    self!ensure-f32($!f32-buf, $!f32-buf-size, $frames * 4);
    my $p = nativecast(Pointer[num32], $!f32-buf);
    my $fl = nativecast(CArray[num32], $p);
    my $fr = nativecast(CArray[num32], $p.add($frames));
    my $rl = nativecast(CArray[num32], $p.add($frames * 2));
    my $rr = nativecast(CArray[num32], $p.add($frames * 3));
    my $count = openmpt_module_read_float_quad($!handle, $rate, $frames, $fl, $fr, $rl, $rr);
    self!check-error('openmpt_module_read_float_quad');
    $count > 0 or return (0, EMPTY-BUF, EMPTY-BUF, EMPTY-BUF, EMPTY-BUF);
    return ($count,
        pointer-to-blob(nativecast(Pointer[void], $fl), $count * 4),
        pointer-to-blob(nativecast(Pointer[void], $fr), $count * 4),
        pointer-to-blob(nativecast(Pointer[void], $rl), $count * 4),
        pointer-to-blob(nativecast(Pointer[void], $rr), $count * 4));
}

method read-float-quad(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!read-float-quad-impl($rate, $frames)
}

method read-interleaved-float-quad(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $needed = $frames * 4;
    self!ensure-f32($!f32-buf, $!f32-buf-size, $needed);
    my $count = openmpt_module_read_interleaved_float_quad($!handle, $rate, $frames, $!f32-buf);
    self!check-error('openmpt_module_read_interleaved_float_quad');
    $count > 0 or return (0, EMPTY-BUF);
    return ($count, pointer-to-blob(nativecast(Pointer[void], $!f32-buf), $count * 16));
}

# ============================================================================
# Audio rendering — int16 quad
# ============================================================================

method !read-quad-impl(int32 $rate, size_t $frames --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    self!ensure-s16($!s16-buf, $!s16-buf-size, $frames * 4);
    my $p = nativecast(Pointer[int16], $!s16-buf);
    my $fl = nativecast(CArray[int16], $p);
    my $fr = nativecast(CArray[int16], $p.add($frames));
    my $rl = nativecast(CArray[int16], $p.add($frames * 2));
    my $rr = nativecast(CArray[int16], $p.add($frames * 3));
    my $count = openmpt_module_read_quad($!handle, $rate, $frames, $fl, $fr, $rl, $rr);
    self!check-error('openmpt_module_read_quad');
    $count > 0 or return (0, EMPTY-BUF, EMPTY-BUF, EMPTY-BUF, EMPTY-BUF);
    return ($count,
        pointer-to-blob(nativecast(Pointer[void], $fl), $count * 2),
        pointer-to-blob(nativecast(Pointer[void], $fr), $count * 2),
        pointer-to-blob(nativecast(Pointer[void], $rl), $count * 2),
        pointer-to-blob(nativecast(Pointer[void], $rr), $count * 2));
}

method read-quad(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!read-quad-impl($rate, $frames)
}

method read-interleaved-quad(int32 $rate = 48000, size_t $frames = 1024 --> List) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $needed = $frames * 4;
    self!ensure-s16($!s16-buf, $!s16-buf-size, $needed);
    my $count = openmpt_module_read_interleaved_quad($!handle, $rate, $frames, $!s16-buf);
    self!check-error('openmpt_module_read_interleaved_quad');
    $count > 0 or return (0, EMPTY-BUF);
    return ($count, pointer-to-blob(nativecast(Pointer[void], $!s16-buf), $count * 8));
}

# ============================================================================
# Metadata
# ============================================================================

method !free-str(Pointer[uint8] $p --> Str) {
    return Str unless $p;
    my $str = nativecast(Str, $p);  # Assumes libopenmpt returns UTF-8 (its documented convention)
    openmpt_free_string($p);
    return $str;
}

method get-metadata(Str $key --> Str) {
    self!guard;
    self!free-str(openmpt_module_get_metadata($!handle, $key));
}

method title(   --> Str) { self.get-metadata('title') }
method artist(  --> Str) { self.get-metadata('artist') }
method type(    --> Str) { self.get-metadata('type') }
method module-message( --> Str) { self.get-metadata('message') }
method tracker( --> Str) { self.get-metadata('tracker') }
method date(    --> Str) { self.get-metadata('date') }
method warnings-str(--> Str) { self.get-metadata('warnings') }
method type-long(    --> Str) { self.get-metadata('type_long') }
method originaltype( --> Str) { self.get-metadata('originaltype') }

method metadata-keys(--> List) {
    self!guard;
    $!metadata-keys-cache //= (self!free-str(openmpt_module_get_metadata_keys($!handle)) // '').split(';').grep(*.chars).List
}

# ============================================================================
# Module info — counts
# ============================================================================

method num-subsongs(    --> Int) { self!guard; $!c-subsongs    //= openmpt_module_get_num_subsongs($!handle) }
method num-channels(    --> Int) { self!guard; $!c-channels    //= openmpt_module_get_num_channels($!handle) }
method num-orders(      --> Int) { self!guard; $!c-orders      //= openmpt_module_get_num_orders($!handle) }
method num-patterns(    --> Int) { self!guard; $!c-patterns    //= openmpt_module_get_num_patterns($!handle) }
method num-instruments( --> Int) { self!guard; $!c-instruments //= openmpt_module_get_num_instruments($!handle) }
method num-samples(     --> Int) { self!guard; $!c-samples     //= openmpt_module_get_num_samples($!handle) }
method restart-order(Int $subsong --> Int) { self!guard; openmpt_module_get_restart_order($!handle, $subsong) }
method restart-row(Int $subsong   --> Int) { self!guard; openmpt_module_get_restart_row($!handle, $subsong) }

# ============================================================================
# Module info — patterns / orders
# ============================================================================

method order-pattern(Int $order --> Int) { self!guard; openmpt_module_get_order_pattern($!handle, $order) }
method is-order-skip(Int $order --> Bool) { self!guard; ?openmpt_module_is_order_skip_entry($!handle, $order) }
method is-order-stop(Int $order --> Bool) { self!guard; ?openmpt_module_is_order_stop_entry($!handle, $order) }
method is-pattern-skip(Int $pat --> Bool) { self!guard; ?openmpt_module_is_pattern_skip_item($!handle, $pat) }
method is-pattern-stop(Int $pat --> Bool) { self!guard; ?openmpt_module_is_pattern_stop_item($!handle, $pat) }
method pattern-num-rows(Int $pat --> Int) { self!guard; openmpt_module_get_pattern_num_rows($!handle, $pat) }
method pattern-rows-per-beat(Int $pat --> Int) { self!guard; openmpt_module_get_pattern_rows_per_beat($!handle, $pat) }
method pattern-rows-per-measure(Int $pat --> Int) { self!guard; openmpt_module_get_pattern_rows_per_measure($!handle, $pat) }

method get-pattern-cell(Int $pat, Int $row, Int $ch, Int $cmd --> Int) {
    self!guard;
    openmpt_module_get_pattern_row_channel_command($!handle, $pat, $row, $ch, $cmd)
}

method format-pattern-cell(Int $pat, Int $row, Int $ch, Int $cmd --> Str) {
    self!guard;
    self!free-str(openmpt_module_format_pattern_row_channel_command($!handle, $pat, $row, $ch, $cmd))
}

method highlight-pattern-cell(Int $pat, Int $row, Int $ch, Int $cmd --> Str) {
    self!guard;
    self!free-str(openmpt_module_highlight_pattern_row_channel_command($!handle, $pat, $row, $ch, $cmd))
}

method format-pattern-row(Int $pat, Int $row, Int $ch, size_t $width, Int $pad --> Str) {
    self!guard;
    self!free-str(openmpt_module_format_pattern_row_channel($!handle, $pat, $row, $ch, $width, $pad))
}

method highlight-pattern-row(Int $pat, Int $row, Int $ch, size_t $width, Int $pad --> Str) {
    self!guard;
    self!free-str(openmpt_module_highlight_pattern_row_channel($!handle, $pat, $row, $ch, $width, $pad))
}

# ============================================================================
# Module info — names
# ============================================================================

method subsong-name(Int $idx    --> Str) { self!guard; self!free-str(openmpt_module_get_subsong_name($!handle, $idx)) }
method channel-name(Int $idx   --> Str) { self!guard; self!free-str(openmpt_module_get_channel_name($!handle, $idx)) }
method order-name(Int $idx     --> Str) { self!guard; self!free-str(openmpt_module_get_order_name($!handle, $idx)) }
method pattern-name(Int $idx   --> Str) { self!guard; self!free-str(openmpt_module_get_pattern_name($!handle, $idx)) }
method instrument-name(Int $idx --> Str) { self!guard; self!free-str(openmpt_module_get_instrument_name($!handle, $idx)) }
method sample-name(Int $idx    --> Str) { self!guard; self!free-str(openmpt_module_get_sample_name($!handle, $idx)) }

# ============================================================================
# Playback control
# ============================================================================

method select-subsong(Int $idx --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    return True if $idx == openmpt_module_get_selected_subsong($!handle);
    # Invalidate cached per-subsong counts (orders, patterns, instruments,
    # samples, subsongs). Channel count ($!c-channels) is module-wide and
    # unchanged by subsong selection, so it is deliberately not reset.
    # CAUTION: caches can only be stale if openmpt_module_select_subsong is
    # called directly on $!handle rather than through this method.
    $!c-orders = $!c-patterns = $!c-instruments = $!c-samples = $!c-subsongs = Nil;
    $!metadata-keys-cache = $!ctl-keys-cache = Nil;
    openmpt_module_select_subsong($!handle, $idx)
        ?? True
        !! do { self!check-error('openmpt_module_select_subsong'); False }
}
method subsong(--> Int) { self!guard; openmpt_module_get_selected_subsong($!handle) }

method set-repeat-count(Int $n --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    openmpt_module_set_repeat_count($!handle, $n)
        ?? True
        !! do { self!check-error('openmpt_module_set_repeat_count'); False }
}
method repeat-count(--> Int) { self!guard; openmpt_module_get_repeat_count($!handle) }

# ============================================================================
# Position / duration
# ============================================================================

method duration(--> Num) { self!guard; openmpt_module_get_duration_seconds($!handle) }
method position(--> Num) { self!guard; openmpt_module_get_position_seconds($!handle) }
method set-position(Numeric $sec --> Num) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $result = openmpt_module_set_position_seconds($!handle, $sec.Num);
    if $result < 0 {
        self!check-error('openmpt_module_set_position_seconds');
        die X::OpenMPT::Bindings.new(:function('openmpt_module_set_position_seconds'), :code($result), :message("returned $result without setting an error"));
    }
    $result
}
method set-position-order-row(Int $order, Int $row --> Num) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $result = openmpt_module_set_position_order_row($!handle, $order, $row);
    if $result < 0 {
        self!check-error('openmpt_module_set_position_order_row');
        die X::OpenMPT::Bindings.new(:function('openmpt_module_set_position_order_row'), :code($result), :message("returned $result without setting an error"));
    }
    $result
}

method time-at-position(Int $order, Int $row --> Num) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $result = openmpt_module_get_time_at_position($!handle, $order, $row);
    if $result < 0 {
        self!check-error('openmpt_module_get_time_at_position');
        die X::OpenMPT::Bindings.new(:function('openmpt_module_get_time_at_position'), :code($result), :message("returned $result without setting an error"));
    }
    $result
}

# ============================================================================
# Render parameters
# ============================================================================

method !render-param(int32 $param --> Int) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $rc = openmpt_module_get_render_param($!handle, $param, self!rp-buf);
    self!check-error('openmpt_module_get_render_param');
    die "openmpt_module_get_render_param returned $rc without setting an error"
        unless $rc;
    $!render-param-buf[0]
}
method !set-render-param(int32 $param, Int $val --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    unless openmpt_module_set_render_param($!handle, $param, $val) {
        self!check-error('openmpt_module_set_render_param');
        die "openmpt_module_set_render_param returned 0 without setting an error";
    }
    True
}

method mastergain(--> Int)
    { self!render-param(OPENMPT_MODULE_RENDER_MASTERGAIN_MILLIBEL) }
method set-mastergain(Int $val --> Bool)
    { self!set-render-param(OPENMPT_MODULE_RENDER_MASTERGAIN_MILLIBEL, $val) }

method stereo-separation(--> Int)
    { self!render-param(OPENMPT_MODULE_RENDER_STEREOSEPARATION_PERCENT) }
method set-stereo-separation(Int $val --> Bool)
    { self!set-render-param(OPENMPT_MODULE_RENDER_STEREOSEPARATION_PERCENT, $val) }

method interpolation-filter-length(--> Int)
    { self!render-param(OPENMPT_MODULE_RENDER_INTERPOLATIONFILTER_LENGTH) }
method set-interpolation-filter-length(Int $val --> Bool)
    { self!set-render-param(OPENMPT_MODULE_RENDER_INTERPOLATIONFILTER_LENGTH, $val) }

method volume-ramping-strength(--> Int)
    { self!render-param(OPENMPT_MODULE_RENDER_VOLUMERAMPING_STRENGTH) }
method set-volume-ramping-strength(Int $val --> Bool)
    { self!set-render-param(OPENMPT_MODULE_RENDER_VOLUMERAMPING_STRENGTH, $val) }

# ============================================================================
# Playback status
# ============================================================================

method current-bpm(               --> Num) { self!guard; openmpt_module_get_current_estimated_bpm($!handle) }
method current-speed(             --> Int) { self!guard; openmpt_module_get_current_speed($!handle) }
method current-tempo(             --> Num) { self!guard; openmpt_module_get_current_tempo2($!handle) }  # tempo2 returns float; the deprecated tempo returned int
method current-order(             --> Int)    { self!guard; openmpt_module_get_current_order($!handle) }
method current-pattern(           --> Int)    { self!guard; openmpt_module_get_current_pattern($!handle) }
method current-row(               --> Int)    { self!guard; openmpt_module_get_current_row($!handle) }
method current-playing-channels(  --> Int) { self!guard; openmpt_module_get_current_playing_channels($!handle) }
method current-sequence(          --> Int) {
    self!guard;
    $!sequence-available //= ::?CLASS.library-version >= LIBOPENMPT_SEQUENCE_API;
    return -1 unless $!sequence-available;
    openmpt_module_get_current_sequence($!handle)
}
method current-channel-vu-mono(Int $ch       --> Numeric) { self!guard; openmpt_module_get_current_channel_vu_mono($!handle, $ch) }
method current-channel-vu-left(Int $ch       --> Numeric) { self!guard; openmpt_module_get_current_channel_vu_left($!handle, $ch) }
method current-channel-vu-right(Int $ch      --> Numeric) { self!guard; openmpt_module_get_current_channel_vu_right($!handle, $ch) }
method current-channel-vu-rear-left(Int $ch  --> Numeric) { self!guard; openmpt_module_get_current_channel_vu_rear_left($!handle, $ch) }
method current-channel-vu-rear-right(Int $ch --> Numeric) { self!guard; openmpt_module_get_current_channel_vu_rear_right($!handle, $ch) }

# ============================================================================
# CTL interface
# ============================================================================

method get-ctl(Str $key, :$type = Str --> Any) {
    self!guard;
    openmpt_module_error_clear($!handle);
    given $type {
        when Bool    { my $v = ?openmpt_module_ctl_get_boolean($!handle, $key);  self!check-error('openmpt_module_ctl_get_boolean');  $v }
        when Int     { my $v =  openmpt_module_ctl_get_integer($!handle, $key);  self!check-error('openmpt_module_ctl_get_integer');  $v }
        when Numeric { my $v = openmpt_module_ctl_get_floatingpoint($!handle, $key);  self!check-error('openmpt_module_ctl_get_floatingpoint');  $v }
        when Str     { my $p = openmpt_module_ctl_get_text($!handle, $key);  self!check-error('openmpt_module_ctl_get_text');  self!free-str($p) }
        default      { die "Unsupported CTL value type: {$type.^name}" }
    }
}

method set-ctl(Str $key, $value --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $rc = ?apply-ctl($!handle, $key, $value);
    self!check-error('apply-ctl') unless $rc;
    $rc
}

method ctl-keys(--> List) {
    self!guard;
    $!ctl-keys-cache //= (self!free-str(openmpt_module_get_ctls($!handle)) // '').split(';').grep(*.chars).List
}

method ctl-get-boolean(Str $key --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $v = openmpt_module_ctl_get_boolean($!handle, $key);
    self!check-error('openmpt_module_ctl_get_boolean');
    ?$v
}
method ctl-get-integer(Str $key --> Int) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $v = openmpt_module_ctl_get_integer($!handle, $key);
    self!check-error('openmpt_module_ctl_get_integer');
    $v
}
method ctl-get-floatingpoint(Str $key --> Num) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $v = openmpt_module_ctl_get_floatingpoint($!handle, $key);
    self!check-error('openmpt_module_ctl_get_floatingpoint');
    $v
}
method ctl-get-text(Str $key --> Str) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $p = openmpt_module_ctl_get_text($!handle, $key);
    self!check-error('openmpt_module_ctl_get_text');
    self!free-str($p)
}

method ctl-set-boolean(Str $key, Bool $value --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $rc = openmpt_module_ctl_set_boolean($!handle, $key, $value.Int);
    self!check-error('openmpt_module_ctl_set_boolean');
    ?$rc
}
method ctl-set-integer(Str $key, Int $value --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $rc = openmpt_module_ctl_set_integer($!handle, $key, $value);
    self!check-error('openmpt_module_ctl_set_integer');
    ?$rc
}
method ctl-set-floatingpoint(Str $key, Num $value --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $rc = openmpt_module_ctl_set_floatingpoint($!handle, $key, $value);
    self!check-error('openmpt_module_ctl_set_floatingpoint');
    ?$rc
}
method ctl-set-text(Str $key, Str $value --> Bool) {
    self!guard;
    openmpt_module_error_clear($!handle);
    my $rc = openmpt_module_ctl_set_text($!handle, $key, $value);
    self!check-error('openmpt_module_ctl_set_text');
    ?$rc
}

=begin pod

=head1 NAME

OpenMPT::Bindings::Module - OOP wrapper around libopenmpt module handles

=head1 SYNOPSIS

=begin code :lang<raku>

use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::Types;

my $mod = OpenMPT::Bindings::Module.from-file('track.xm');
say $mod.title;
say $mod.duration;

# Get 16-bit signed interleaved stereo — pipe straight to aplay
my ($frames, $blob) = $mod.read-interleaved-stereo(48000, 1024);

# Or get separate left/right float blobs
my ($count, $left, $right) = $mod.read-float-stereo(48000, 512);

$mod.set-position(30);

# Use CTL type dispatch
say $mod.get-ctl('play.tempo_factor', :type(Numeric));

# Library class methods
say OpenMPT::Bindings::Module.library-version;
my $result = OpenMPT::Bindings::Module.probe-file-header($data, $data.bytes);

=end code

=head1 DESCRIPTION

Wraps the opaque C<openmpt_module*> handle from libopenmpt. Provides
methods for loading tracker modules, rendering PCM audio (stereo, mono,
quad, interleaved, CArray and Blob variants), querying metadata,
controlling playback, managing CTL parameters, and probing file headers.
Library-level class methods give access to version info and supported
extensions.

=head1 ATTRIBUTES

=head2 handle

    has Pointer[void] $.handle;

The raw C<openmpt_module*> pointer.

=head2 data

    has Blob $.data;

The original file data loaded from disk or passed to C<from-blob>.
Libopenmpt copies the data internally; this is kept for convenience.

=head1 CONSTRUCTION

=head2 from-blob

    method from-blob(Blob $data, :%ctls --> ::?CLASS)

Create a module from an in-memory C<Blob> of module data.
Optional C<%ctls> hash of initial CTL parameters.

=head2 from-file

    method from-file(Str $path, :%ctls --> ::?CLASS)

Read a file from disk and create a module from its contents.

=head1 LIBRARY CLASS METHODS

These are called on the class, not on an instance:

    method library-version(--> uint32)
    method core-version(--> uint32)
    method library-string(Str $key --> Str)
    method supported-extensions(--> List)
    method is-extension-supported(Str $extension --> Bool)
    method probe-file-header-get-recommended-size(--> Int)
    method probe-file-header(Blob $data, uint64 $filesize, uint64 $flags = OPENMPT_PROBE_FILE_HEADER_FLAGS_DEFAULT --> OpenMPTProbeResult)
    method probe-file-header-without-filesize(Blob $data, uint64 $flags = OPENMPT_PROBE_FILE_HEADER_FLAGS_DEFAULT --> OpenMPTProbeResult)

C<library-version> and C<core-version> return the libopenmpt version as a
packed C<uint32> (major << 24 | minor << 16 | patch). C<library-string>
returns e.g. the URL or version string. C<supported-extensions> returns a
list of file extensions libopenmpt can handle. C<probe-file-header> checks
whether raw bytes look like a supported module format — returns an
C<OpenMPTProbeResult> enum value.

=head1 DESTRUCTION

The module handle is freed automatically when the object is garbage-collected
via C<DESTROY>.

=head1 AUDIO RENDERING

All render methods return a C<List> where the first element is the count of
frames actually produced, followed by the buffer(s). The caller is
responsible for checking that the returned count matches the requested
frame count (the buffer may contain silent padding at end of song).

B<Note:> Standard render methods allocate a new C<Blob> on every call
(alloc + memcpy). For performance-sensitive hot paths, use the raw pointer
variants (L</Low-overhead rendering (raw pointer variants)>) instead to
avoid allocation entirely.

B<Note:> Module instances share internal render buffers between method
calls. Concurrent C<read-*> or C<write-*> calls from multiple threads on
the same instance will race on these buffers and produce undefined output.
Use separate Module instances per thread for concurrent rendering.

=head2 read-float-stereo

    method read-float-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List)

Returns C<($count, $left, $right)> as C<Blob> of F32_LE bytes
(C<$count × 4> bytes each channel).

=head2 read-interleaved-float-stereo

    method read-interleaved-float-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List)

Returns C<($count, $buf)> where C<$buf> is a C<Blob> of interleaved
F32_LE L/R samples (C<$count × 8> bytes).

=head2 read-float-mono

    method read-float-mono(int32 $rate = 48000, size_t $frames = 1024 --> List)

Returns C<($count, $buf)> of float mono samples as C<Blob> (F32_LE,
C<$count × 4> bytes).

=head2 read-stereo

    method read-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List)

Returns C<($count, $left, $right)> as C<Blob> of S16_LE bytes
(C<$count × 2> bytes each channel).

=head2 read-interleaved-stereo

    method read-interleaved-stereo(int32 $rate = 48000, size_t $frames = 1024 --> List)

Returns C<($count, $buf)> where C<$buf> is a C<Blob> of interleaved
S16_LE L/R samples (C<$count × 4> bytes). This is the most convenient
format for piping to L<aplay(1)> or writing WAV data.

=head2 read-mono

    method read-mono(int32 $rate = 48000, size_t $frames = 1024 --> List)

Returns C<($count, $buf)> of C<int16> mono samples as C<Blob> (S16_LE,
C<$count × 2> bytes).

=head2 write-interleaved-stereo-s16-to-handle

    method write-interleaved-stereo-s16-to-handle(IO::Handle $fh, int32 $rate = 48000, size_t $frames = 1024 --> Int)

Writes interleaved stereo S16_LE frames directly to C<$fh> and returns the
frame count. Avoids an intermediate Blob allocation; prefer this over
C<read-interleaved-stereo> + C<$fh.write> in hot paths.

=head2 Low-overhead rendering (raw pointer variants)

    method read-interleaved-stereo-raw(int32 $rate = 48000, size_t $frames = 1024 --> List)
    method read-interleaved-float-stereo-raw(int32 $rate = 48000, size_t $frames = 1024 --> List)

These return a C<Pointer[void]> into an internal pre-allocated buffer instead of
allocating a new C<Blob> on every call. Returns C<($count, Pointer[void], $bytes)>.
The pointer is valid only until the next render call on the same module.

=head2 Quad rendering — float

    method read-float-quad(int32 $rate = 48000, size_t $frames = 1024 --> List)
    method read-interleaved-float-quad(int32 $rate = 48000, size_t $frames = 1024 --> List)

C<read-float-quad> returns C<($count, $fl, $fr, $rl, $rr)> as C<Blob> of
F32_LE bytes (C<$count × 4> bytes each channel).

=head2 Quad rendering — int16

    method read-quad(int32 $rate = 48000, size_t $frames = 1024 --> List)
    method read-interleaved-quad(int32 $rate = 48000, size_t $frames = 1024 --> List)

Same layout as the float quad variants but with S16_LE C<Blob> bytes
(C<$count × 2> bytes each channel).

=head1 METADATA

=head2 get-metadata

    method get-metadata(Str $key --> Str)

Returns the metadata value for C<$key>, or C<Str> (type object / undef) if
the key is not present. Common keys: C<title>, C<artist>, C<type>,
C<type_long>, C<message>, C<tracker>, C<date>, C<warnings>,
C<originaltype>, C<originaltype_long>, C<container>, C<container_long>.

=head2 title, artist, type, module-message, tracker, date, warnings, type-long, originaltype

Shorthand accessors for common metadata keys.

    method title(   --> Str)
    method artist(  --> Str)
    method type(    --> Str)
    method module-message( --> Str)
    method tracker( --> Str)
    method date(    --> Str)
    method warnings-str(--> Str)
    method type-long(    --> Str)
    method originaltype( --> Str)

=head2 metadata-keys

    method metadata-keys(--> List)

Returns a list of all available metadata key strings for this module.

=head1 MODULE INFORMATION

=head2 Counts

    method num-subsongs(    --> Int)
    method num-channels(    --> Int)
    method num-orders(      --> Int)
    method num-patterns(    --> Int)
    method num-instruments( --> Int)
    method num-samples(     --> Int)
    method restart-order(Int $subsong --> Int)
    method restart-row(Int $subsong   --> Int)

=head2 Names

    method subsong-name(Int $idx    --> Str)
    method channel-name(Int $idx   --> Str)
    method order-name(Int $idx     --> Str)
    method pattern-name(Int $idx   --> Str)
    method instrument-name(Int $idx --> Str)
    method sample-name(Int $idx    --> Str)

=head2 Pattern / Order Access

    method order-pattern(Int $order --> Int)
    method is-order-skip(Int $order --> Bool)
    method is-order-stop(Int $order --> Bool)
    method is-pattern-skip(Int $pat --> Bool)
    method is-pattern-stop(Int $pat --> Bool)
    method pattern-num-rows(Int $pat --> Int)
    method pattern-rows-per-beat(Int $pat --> Int)
    method pattern-rows-per-measure(Int $pat --> Int)
    method get-pattern-cell(Int $pat, Int $row, Int $ch, Int $cmd --> Int)
    method format-pattern-cell(Int $pat, Int $row, Int $ch, Int $cmd --> Str)
    method highlight-pattern-cell(Int $pat, Int $row, Int $ch, Int $cmd --> Str)
    method format-pattern-row(Int $pat, Int $row, Int $ch, size_t $width, Int $pad --> Str)
    method highlight-pattern-row(Int $pat, Int $row, Int $ch, size_t $width, Int $pad --> Str)

Use C<OpenMPTCommandIndex> enum values for C<$cmd>:
C<OPENMPT_MODULE_COMMAND_NOTE>, C<OPENMPT_MODULE_COMMAND_INSTRUMENT>,
C<OPENMPT_MODULE_COMMAND_VOLUMEEFFECT>, C<OPENMPT_MODULE_COMMAND_EFFECT>,
C<OPENMPT_MODULE_COMMAND_VOLUME>, C<OPENMPT_MODULE_COMMAND_PARAMETER>.

=head1 PLAYBACK CONTROL

=head2 select-subsong

    method select-subsong(Int $idx --> Bool)

Select a subsong by index. Dies with C<X::OpenMPT::Bindings> on failure.

=head2 subsong

    method subsong(--> Int)

Returns the currently selected subsong index.

=head2 set-repeat-count

    method set-repeat-count(Int $n --> Bool)

Set repeat count. C<-1> loops forever, C<0> plays once, C<1> plays twice, etc.
Dies with C<X::OpenMPT::Bindings> on failure.

=head2 repeat-count

    method repeat-count(--> Int)

Returns the current repeat count.

=head1 POSITION / DURATION

=head2 duration

    method duration(--> Num)

Total duration in seconds.

=head2 position

    method position(--> Num)

Current playback position in seconds.

=head2 set-position

    method set-position(Numeric $sec --> Num)

Seek to a given time in seconds. Returns the new actual position.

=head2 set-position-order-row

    method set-position-order-row(Int $order, Int $row --> Num)

Seek to a specific pattern order and row. Returns the new position in seconds.

=head2 time-at-position

    method time-at-position(Int $order, Int $row --> Num)

Returns the time in seconds at the given pattern order and row.

=head1 RENDER PARAMETERS

=head2 mastergain

    method mastergain(--> Int)

Returns the master gain in millibel.

=head2 set-mastergain

    method set-mastergain(Int $val --> Bool)

Set master gain in millibel. Dies with C<X::OpenMPT::Bindings> on failure.

=head2 stereo-separation

    method stereo-separation(--> Int)

Returns stereo separation as a percentage.

=head2 set-stereo-separation

    method set-stereo-separation(Int $val --> Bool)

Set stereo separation percentage. Dies with C<X::OpenMPT::Bindings> on failure.

=head2 interpolation-filter-length

    method interpolation-filter-length(--> Int)

Returns the interpolation filter length.

=head2 set-interpolation-filter-length

    method set-interpolation-filter-length(Int $val --> Bool)

=head2 volume-ramping-strength

    method volume-ramping-strength(--> Int)

Returns the volume ramping strength.
A value of C<-1> means the libopenmpt default.

=head2 set-volume-ramping-strength

    method set-volume-ramping-strength(Int $val --> Bool)

=head1 PLAYBACK STATUS

    method current-bpm(               --> Num)
    method current-speed(             --> Int)
    method current-tempo(             --> Num)
    method current-order(             --> Int)
    method current-pattern(           --> Int)
    method current-row(               --> Int)
    method current-playing-channels(  --> Int)
    method current-sequence(          --> Int)   # requires libopenmpt 0.9+
    method current-channel-vu-mono(Int $ch        --> Numeric)
    method current-channel-vu-left(Int $ch        --> Numeric)
    method current-channel-vu-right(Int $ch       --> Numeric)
    method current-channel-vu-rear-left(Int $ch   --> Numeric)
    method current-channel-vu-rear-right(Int $ch  --> Numeric)

=head1 CTL INTERFACE

=head2 get-ctl

    method get-ctl(Str $key, :$type = Str --> Any)

Get a CTL value. C<$type> controls the return type:

=item C<Bool> — returns C<Bool>
=item C<Int> — returns C<Int>
=item C<Numeric> — returns C<Numeric> (floating-point)
=item C<Str> (default) — returns C<Str> (text)

=head2 set-ctl

    method set-ctl(Str $key, $value --> Bool)

Set a CTL value. C<$value> is dispatched by its Raku type:

=item C<Bool> — calls C<ctl_set_boolean>
=item C<Int> — calls C<ctl_set_integer>
=item C<Numeric> — calls C<ctl_set_floatingpoint>
=item C<Str> — calls C<ctl_set_text>

=head2 ctl-keys

    method ctl-keys(--> List)

Returns a list of all supported CTL key strings for this module.


=head1 SEE ALSO

=item L<OpenMPT::Bindings::Native> — raw NativeCall subroutines
=item L<OpenMPT::Bindings::ModuleExt> — libopenmpt extension API
=item L<X::OpenMPT::Bindings> — exception class
=item L<https://lib.openmpt.org/> — libopenmpt documentation

=end pod
