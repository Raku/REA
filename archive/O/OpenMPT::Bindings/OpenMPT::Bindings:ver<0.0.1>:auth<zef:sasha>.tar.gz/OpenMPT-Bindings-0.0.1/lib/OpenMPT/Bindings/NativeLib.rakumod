unit module OpenMPT::Bindings::NativeLib;

sub library(--> Str) is export {
    state $lib = do {
        my $fname = do given $*KERNEL.name {
            when 'win32'  { 'libopenmpt.dll'   }
            when 'darwin' { 'libopenmpt.dylib'  }
            default       { 'libopenmpt.so.0'   }
        }
        if %*ENV<LIBOPENMPT_DIR> -> $dir {
            my $path = $dir.IO.add($fname);
            return ~$path if $path.e;
        }
        $fname
    }
}

sub LIBC(--> Str) is export {
    given $*KERNEL.name {
        when 'win32'   { 'msvcrt.dll'      }
        when 'darwin'  { 'libSystem.dylib' }
        when 'dragonfly' { 'libc.so.8'      }
        when 'freebsd'   { 'libc.so.7'       }
        when 'openbsd' { 'libc.so'        }
        when 'netbsd'  { 'libc.so.12'     }
        default {
            state $libc = do {
                my $l = 'libc.so.6';
                # Probe /proc/self/maps for a musl libc entry
                # (libc.musl-*.so.1). On glibc, maps show the resolved
                # symlink path (e.g. libc-2.42.so) so we only use this
                # to differentiate musl — glibc always uses libc.so.6
                # as the dlopen-friendly SONAME.
                # Silently falls back to 'libc.so.6' if /proc/self/maps is
                # unavailable (sandbox, non-Linux, etc.).
                try {
                    for '/proc/self/maps'.IO.lines -> $line {
                        if $line ~~ /'libc' ('.musl' \S+? '.so.' \S+) / {
                            $l = "libc$0";
                            last;
                        }
                    }
                }
                $l
            }
        }
    }
}

=begin pod

=head1 NAME

OpenMPT::Bindings::NativeLib - Platform library path resolution for libopenmpt

=head1 DESCRIPTION

Resolves the native shared library filename for the current platform:

=item Linux: libopenmpt.so.0 (SONAME); libopenmpt.so requires -dev package
=item macOS: libopenmpt.dylib
=item Windows: libopenmpt.dll

The C<library> function returns a C<Str> suitable for use with
C<is native(&library)> in NativeCall declarations.

=head1 FUNCTIONS

=head2 library

    sub library(--> Str) is export

Returns the platform-specific libopenmpt shared library name.

Set C<%*ENV<LIBOPENMPT_DIR>> to a directory containing the library to
override the system library search path. Useful for bundling the DLLs
alongside an application without installing them system-wide.

=head2 LIBC

    sub LIBC(--> Str) is export

Returns the platform-specific C runtime library SONAME suitable for
C<is native(&LIBC)> in NativeCall declarations for standard C functions
like C<memcpy> and C<write>.

=over

=item Linux: libc.so.6 (glibc) or libc.musl-*.so.1 (musl, auto-detected)
=item macOS: libSystem.dylib
=item Windows: msvcrt.dll
=item FreeBSD: libc.so.7
=item DragonFly BSD: libc.so.8
=item OpenBSD: libc.so
=item NetBSD: libc.so.12

=back

=end pod
