use OpenMPT::Bindings::Module;
use OpenMPT::Bindings::ModuleExt;
use OpenMPT::Bindings::Types;
use OpenMPT::Bindings::Exception;

unit class OpenMPT::Bindings;

=begin pod

=head1 NAME

OpenMPT::Bindings - Raku bindings for libopenmpt (module music rendering)

=head1 SYNOPSIS

=begin code :lang<raku>

use OpenMPT::Bindings::Module;

my $mod = OpenMPT::Bindings::Module.from-file('song.mod');
say "Title: { $mod.title }";
say "Artist: { $mod.artist }";
say "Duration: { $mod.duration } seconds";

my ($count, $left, $right) = $mod.read-float-stereo(48000, 1024);
say "Rendered $count frames";

=end code

=head1 DESCRIPTION

OpenMPT::Bindings provides Raku NativeCall bindings for libopenmpt,
a library for rendering tracker music (MOD, XM, S3M, IT, MPTM, etc.)
to PCM audio.

B<Note:> C<use OpenMPT::Bindings> does not import sub-module symbols.
Import the module you need directly, e.g. C<use OpenMPT::Bindings::Module>.

=head1 SUB-MODULES

=item OpenMPT::Bindings::Module — OOP wrapper around C<openmpt_module>
=item OpenMPT::Bindings::ModuleExt — Extension API (interactive playback, patterns)
=item OpenMPT::Bindings::Types — Enums and constants
=item OpenMPT::Bindings::Native — Raw NativeCall subroutine declarations
=item OpenMPT::Bindings::NativeLib — Platform library path resolution
=item OpenMPT::Bindings::Util — Utility functions (pointer-to-blob, wav-header, fmt-time)
=item X::OpenMPT::Bindings — Exception class

=head1 AUTHOR

Sasha Abbott <sashaa@disroot.org>

=head1 COPYRIGHT AND LICENSE

This software is dedicated to the public domain under the
CC0 1.0 Universal (CC0 1.0) Public Domain Dedication.

=end pod
