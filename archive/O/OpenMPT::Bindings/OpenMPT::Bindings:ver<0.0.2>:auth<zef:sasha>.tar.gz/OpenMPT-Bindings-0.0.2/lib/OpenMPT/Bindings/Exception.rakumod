unit class X::OpenMPT::Bindings is Exception;

has Str $.function;
has Int $.code;
has Str $!message is built;  # private: $.message is the Exception role protocol method

method message() {
    "libopenmpt error in {$!function}(): $!message (code $!code)"
}

=begin pod

=head1 NAME

X::OpenMPT::Bindings - Exception class for libopenmpt errors

=head1 DESCRIPTION

Thrown when a libopenmpt C API function returns an error. Captures the
C<$function> name, numeric error C<$code>, and human-readable C<$message>.

=head1 ATTRIBUTES

=head2 function

    method function(--> Str)

The name of the C API function that failed (e.g. C<openmpt_module_create_from_memory2>).

=head2 code

    method code(--> Int)

The libopenmpt error code (one of the C<OpenMPTError> enum values).

=head2 message

    method message(--> Str)

Human-readable error description returned by libopenmpt. Note: C<message>
is declared as C<$!message is built> — the constructor accepts
C<:message(...)> as a named argument, and the C<message()> method returns
the formatted string (not the raw argument).

=head1 USAGE

    try {
        OpenMPT::Bindings::Module.from-blob($bad-data);
        CATCH {
            when X::OpenMPT::Bindings {
                say .function;
                say .code;
                say .message;
            }
        }
    }

=end pod
