use NativeCall;
use OpenMPT::Bindings::Native;
use OpenMPT::Bindings::Exception;
use OpenMPT::Bindings::Types;
use OpenMPT::Bindings::Module;

unit class OpenMPT::Bindings::ModuleExt;

# ============================================================================
# !call signature type aliases
# ============================================================================

my \SIG-IDX1 = :(Pointer[void], int32 --> int32);
my \SIG-FLT1 = :(Pointer[void], num64 --> int32);
my \SIG-RET-FLT = :(Pointer[void] --> num64);
my \SIG-IDX-FLT = :(Pointer[void], int32, num64 --> int32);
my \SIG-IDX-RET-FLT = :(Pointer[void], int32 --> num64);
my \SIG-IDX2 = :(Pointer[void], int32, int32 --> int32);
my \SIG-IDX3      = :(Pointer[void], int32, int32, int32 --> int32);
my \SIG-IDX2-FLT2 = :(Pointer[void], int32, int32, num64, num64 --> int32);

has Pointer[void]       $!ext-handle;
has OpenMPT::Bindings::Module $!module;  # NOTE: $!module.select-subsong invalidates caches internally.
                                         # If ModuleExt ever calls it directly, cache propagation is fragile.
has Bool                $!destroyed;
has ExtInterfaceInteractive  $!interactive;
has ExtInterfaceInteractive2 $!interactive2;
has ExtInterfaceInteractive3 $!interactive3;
has ExtInterfacePatternVis   $!pattern-vis;
has %!call-cache;

# ============================================================================
# Construction
# ============================================================================

method from-blob(Blob $data, :%ctls --> ::?CLASS) {
    my $error = CArray[int32].allocate(1);
    my $msg-p = CArray[Pointer[uint8]].allocate(1);

    my $raw = openmpt_module_ext_create_from_memory(
        nativecast(Pointer[void], $data),
        $data.bytes,
        &cb-log-silent, NULL,
        &cb-error-store, NULL,
        nativecast(Pointer[int32], $error),
        nativecast(Pointer[Pointer[uint8]], $msg-p),
        NULL,   # CTL array — set individually below instead
    );

    my $blessed = False;
    LEAVE {
        openmpt_module_ext_destroy($raw) if $raw && !$blessed;
    }
    # Guard pattern: $blessed starts False. If bless or !set-ext-handle or
    # any intermediate processing throws, LEAVE destroys $raw (no object
    # owns it). After $blessed = True, the object owns the handle via
    # DESTROY; LEAVE is a no-op.

    my $msg = $msg-p[0] ?? nativecast(Str, $msg-p[0]) !! Str;
    openmpt_free_string($msg-p[0]) if $msg-p[0];
    unless $raw {
        die build-error($error[0] || OPENMPT_ERROR_UNKNOWN, 'openmpt_module_ext_create_from_memory', $msg);
    }

    my $mod = openmpt_module_ext_get_module($raw);
    unless $mod {
        die X::OpenMPT::Bindings.new(
            :function('openmpt_module_ext_get_module'),
            :code(OPENMPT_ERROR_UNKNOWN),
            :message("openmpt_module_ext_get_module returned NULL"),
        );
    }
    my $inner = OpenMPT::Bindings::Module.new(:handle($mod), :data($data), :skip-destroy);
    my $self = self.bless(:module($inner));

    $self!set-ext-handle($raw);
    $blessed = True;

    for %ctls.kv -> $k, $v {
        next unless $v.defined;
        unless apply-ctl($mod, $k, $v) {
            my $msg = openmpt_module_error_get_last_message($mod);
            warn "OpenMPT CTL '$k' rejected at load time: { $msg ?? nativecast(Str, $msg) !! 'unknown error' }";
            openmpt_free_string($msg) if $msg;
        }
    }

    $self
}

method from-file(Str $path, :%ctls --> ::?CLASS) {
    my $data = $path.IO.slurp(:bin);
    self.from-blob($data, :%ctls);
}

submethod BUILD(:$!ext-handle = Pointer[void], :$!module) { }

method !set-ext-handle(Pointer[void] $h) { $!ext-handle = $h }

# ============================================================================
# Destruction
# ============================================================================

submethod DESTROY {
    return if $!destroyed || !$!ext-handle;
    $!destroyed = True;
    openmpt_module_ext_destroy($!ext-handle);
    $!module.detach-handle;
}

method module() {
    $!destroyed ?? Nil !! $!module
}

method !guard(--> Nil) {
    die X::OpenMPT::Bindings.new(
        :function('<use-after-free>'),
        :code(OPENMPT_ERROR_INVALID_MODULE_POINTER),
        :message("ModuleExt handle has been destroyed"),
    ) if $!destroyed
}

# ============================================================================
# Low-level interface resolve
# ============================================================================

method !resolve-iface(Str $id, $struct-type) {
    self!guard;
    my $struct = $struct-type.new;
    my $rc = openmpt_module_ext_get_interface(
        $!ext-handle, $id,
        nativecast(Pointer[void], $struct),
        nativesizeof($struct-type),
    );
    die X::OpenMPT::Bindings.new(
        :function('openmpt_module_ext_get_interface'),
        :code(OPENMPT_ERROR_UNKNOWN),
        :message("$id interface not available"),
    ) unless $rc;
    $struct
}

method !call(Pointer[void] $fptr, $sig, +@args) {
    self!guard;
    # BEWARE: clears any prior module error before each extension call.
    # After a ModuleExt call, error-get-last reflects the extension call,
    # not any previous module-level error. If you need the prior error,
    # read it before making another ModuleExt call.
    openmpt_module_error_clear($!module.handle);
    # Intentionally no check-error after the call: extension functions signal
    # failure through return values (0/-1), and calling check-error here would
    # throw on every expected failure return. The module-level error is stored
    # and accessible via error-get-last if callers need details.
    my &f := %!call-cache{$fptr} //= nativecast($sig, $fptr);
    f($!ext-handle, |@args)
}

# ============================================================================
# Interactive interface
# ============================================================================

method !interactive(--> ExtInterfaceInteractive) {
    $!interactive //= self!resolve-iface('interactive', ExtInterfaceInteractive)
}

method set-current-speed(int32 $speed --> Bool) {
    ?self!call(self!interactive.set_current_speed, SIG-IDX1, $speed)
}

method set-current-tempo(int32 $tempo --> Bool) is DEPRECATED('use set-current-tempo2 instead') {
    ?self!call(self!interactive.set_current_tempo, SIG-IDX1, $tempo)
}

method set-tempo-factor(num64 $factor --> Bool) {
    ?self!call(self!interactive.set_tempo_factor, SIG-FLT1, $factor)
}

method get-tempo-factor(--> Num) {
    self!call(self!interactive.get_tempo_factor, SIG-RET-FLT)
}

method set-pitch-factor(num64 $factor --> Bool) {
    ?self!call(self!interactive.set_pitch_factor, SIG-FLT1, $factor)
}

method get-pitch-factor(--> Num) {
    self!call(self!interactive.get_pitch_factor, SIG-RET-FLT)
}

method set-global-volume(num64 $volume --> Bool) {
    ?self!call(self!interactive.set_global_volume, SIG-FLT1, $volume)
}

method get-global-volume(--> Num) {
    self!call(self!interactive.get_global_volume, SIG-RET-FLT)
}

method set-channel-volume(int32 $channel, num64 $volume --> Bool) {
    ?self!call(self!interactive.set_channel_volume, SIG-IDX-FLT, $channel, $volume)
}

method get-channel-volume(int32 $channel --> Num) {
    self!call(self!interactive.get_channel_volume, SIG-IDX-RET-FLT, $channel)
}

method set-channel-mute(int32 $channel, Bool $mute --> Bool) {
    ?self!call(self!interactive.set_channel_mute_status, SIG-IDX2, $channel, $mute.Int)
}

method get-channel-mute(int32 $channel --> Bool) {
    ?self!call(self!interactive.get_channel_mute_status, SIG-IDX1, $channel)
}

method set-instrument-mute(int32 $instrument, Bool $mute --> Bool) {
    ?self!call(self!interactive.set_instrument_mute_status, SIG-IDX2, $instrument, $mute.Int)
}

method get-instrument-mute(int32 $instrument --> Bool) {
    ?self!call(self!interactive.get_instrument_mute_status, SIG-IDX1, $instrument)
}

method play-note(int32 $instrument, int32 $note, num64 $volume, num64 $panning --> Int) {
    self!call(self!interactive.play_note, SIG-IDX2-FLT2, $instrument, $note, $volume, $panning)
}

method stop-note(int32 $channel --> Bool) {
    ?self!call(self!interactive.stop_note, SIG-IDX1, $channel)
}

# ============================================================================
# Interactive2 interface
# ============================================================================

method !interactive2(--> ExtInterfaceInteractive2) {
    $!interactive2 //= self!resolve-iface('interactive2', ExtInterfaceInteractive2)
}

method note-off(int32 $channel --> Bool) {
    ?self!call(self!interactive2.note_off, SIG-IDX1, $channel)
}

method note-fade(int32 $channel --> Bool) {
    ?self!call(self!interactive2.note_fade, SIG-IDX1, $channel)
}

method set-channel-panning(int32 $channel, num64 $panning --> Bool) {
    ?self!call(self!interactive2.set_channel_panning, SIG-IDX-FLT, $channel, $panning)
}

method get-channel-panning(int32 $channel --> Num) {
    self!call(self!interactive2.get_channel_panning, SIG-IDX-RET-FLT, $channel)
}

method set-note-finetune(int32 $channel, num64 $finetune --> Bool) {
    ?self!call(self!interactive2.set_note_finetune, SIG-IDX-FLT, $channel, $finetune)
}

method get-note-finetune(int32 $channel --> Num) {
    self!call(self!interactive2.get_note_finetune, SIG-IDX-RET-FLT, $channel)
}

# ============================================================================
# Interactive3 interface
# ============================================================================

method !interactive3(--> ExtInterfaceInteractive3) {
    $!interactive3 //= self!resolve-iface('interactive3', ExtInterfaceInteractive3)
}

method set-current-tempo2(num64 $tempo --> Bool) {
    ?self!call(self!interactive3.set_current_tempo2, SIG-FLT1, $tempo)
}

# ============================================================================
# Pattern visualisation interface
# ============================================================================

method !pattern-vis(--> ExtInterfacePatternVis) {
    $!pattern-vis //= self!resolve-iface('pattern_vis', ExtInterfacePatternVis)
}

method get-pattern-row-channel-volume-effect-type(int32 $pattern, int32 $row, int32 $channel --> Int) {
    self!call(self!pattern-vis.get_pattern_row_channel_volume_effect_type, SIG-IDX3, $pattern, $row, $channel)
}

method get-pattern-row-channel-effect-type(int32 $pattern, int32 $row, int32 $channel --> Int) {
    self!call(self!pattern-vis.get_pattern_row_channel_effect_type, SIG-IDX3, $pattern, $row, $channel)
}

=begin pod

=head1 NAME

OpenMPT::Bindings::ModuleExt - libopenmpt extension API wrapper

=head1 SYNOPSIS

=begin code :lang<raku>

use OpenMPT::Bindings::ModuleExt;

my $ext = OpenMPT::Bindings::ModuleExt.from-file('track.xm');
say $ext.module.title;

# Interactive interface
$ext.set-current-speed(2);
$ext.set-tempo-factor(1.5);
$ext.play-note(0, 60, 0.8, 0.5);

# Pattern visualization
say $ext.get-pattern-row-channel-volume-effect-type(0, 0, 0);

=end code

=head1 DESCRIPTION

Wraps the opaque C<openmpt_module_ext*> handle from libopenmpt and
provides access to the extension interfaces:

=item L</Interactive> — speed, tempo, pitch, volume, mute, note on/off
=item L</Interactive2> — note off/fade, panning, finetune
=item L</Interactive3> — C<set-current-tempo2>
=item L</Pattern Visualization> — pattern cell volume/effect type queries

=head1 CONSTRUCTION

=head2 from-blob

    method from-blob(Blob $data, :%ctls --> ::?CLASS)

Create a ModuleExt from in-memory C<Blob> data. Optional C<%ctls> for
initial CTL parameters. The underlying C<Module> object is accessible via
C<.module>.

=head2 from-file

    method from-file(Str $path, :%ctls --> ::?CLASS)

Read a file from disk and create a ModuleExt from its contents.

=head1 ATTRIBUTES

=head2 module

    method module(--> OpenMPT::Bindings::Module)

The underlying C<Module> instance. All standard Module methods (metadata,
rendering, etc.) are available through this method.

B<Caveat:> returns C<Nil> after the C<ModuleExt> has been destroyed.

=head1 INTERFACES

=head2 Interactive

Requires libopenmpt 0.3+. Methods die with C<X::OpenMPT::Bindings> if the
interface is not available.

=item C<set-current-speed(Int $speed) returns Bool>
=item C<set-current-tempo(Int $tempo) returns Bool> (DEPRECATED — use C<set-current-tempo2> instead)
=item C<set-tempo-factor(Num $factor) returns Bool>
=item C<get-tempo-factor() returns Num>
=item C<set-pitch-factor(Num $factor) returns Bool>
=item C<get-pitch-factor() returns Num>
=item C<set-global-volume(Num $volume) returns Bool>
=item C<get-global-volume() returns Num>
=item C<set-channel-volume(Int $channel, Num $volume) returns Bool>
=item C<get-channel-volume(Int $channel) returns Num>
=item C<set-channel-mute(Int $channel, Bool $mute) returns Bool>
=item C<get-channel-mute(Int $channel) returns Bool>
=item C<set-instrument-mute(Int $instrument, Bool $mute) returns Bool>
=item C<get-instrument-mute(Int $instrument) returns Bool>
=item C<play-note(Int $instrument, Int $note, Num $volume, Num $panning) returns Int>
=item C<stop-note(Int $channel) returns Bool>

=head2 Interactive2

Requires libopenmpt 0.6+.

=item C<note-off(Int $channel) returns Bool>
=item C<note-fade(Int $channel) returns Bool>
=item C<set-channel-panning(Int $channel, Num $panning) returns Bool>
=item C<get-channel-panning(Int $channel) returns Num>
=item C<set-note-finetune(Int $channel, Num $finetune) returns Bool>
=item C<get-note-finetune(Int $channel) returns Num>

=head2 Interactive3

Requires libopenmpt 0.7+.

=item C<set-current-tempo2(Num $tempo) returns Bool>

=head2 Pattern Visualization

Requires libopenmpt 0.3+.

=item C<get-pattern-row-channel-volume-effect-type(Int $pattern, Int $row, Int $channel) returns Int>
=item C<get-pattern-row-channel-effect-type(Int $pattern, Int $row, Int $channel) returns Int>

=head1 SEE ALSO

=item L<OpenMPT::Bindings::Module> — standard module API
=item L<OpenMPT::Bindings::Types> — enums and CStruct types
=item L<https://lib.openmpt.org/> — libopenmpt documentation

=end pod
