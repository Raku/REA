use NativeCall;
use OpenMPT::Bindings::NativeLib;
use OpenMPT::Bindings::Types;
use OpenMPT::Bindings::Exception;

unit module OpenMPT::Bindings::Native;

# ============================================================================
# Library info
# ============================================================================

sub openmpt_get_library_version() returns uint32 is native(&library) is export { * }
sub openmpt_get_core_version()    returns uint32 is native(&library) is export { * }
sub openmpt_get_string(Str $key)  returns Pointer[uint8] is native(&library) is export { * }
sub openmpt_get_supported_extensions() returns Pointer[uint8] is native(&library) is export { * }
sub openmpt_is_extension_supported(Str $extension) returns int32 is native(&library) is export { * }
sub openmpt_free_string(Pointer[uint8] $str) is native(&library) is export { * }

# ============================================================================
# Error utilities
# ============================================================================

sub openmpt_error_is_transient(int32 $error)  returns int32 is native(&library) is export { * }
sub openmpt_error_string(int32 $error) returns Pointer[uint8] is native(&library) is export { * }

# ============================================================================
# File probing (direct buffer — no stream callbacks)
# ============================================================================

sub openmpt_probe_file_header_get_recommended_size() returns size_t is native(&library) is export { * }
sub openmpt_probe_file_header(
    uint64 $flags,
    Pointer[void] $data, size_t $size, uint64 $filesize,
    &logfunc (Str, Pointer[void]),
    Pointer[void] $loguser,
    &errfunc (int32, Pointer[void] --> int32),
    Pointer[void] $erruser,
    Pointer[int32] $error,
    Pointer[Pointer[uint8]] $error_message
) returns int32 is native(&library) is export { * }
sub openmpt_probe_file_header_without_filesize(
    uint64 $flags,
    Pointer[void] $data, size_t $size,
    &logfunc (Str, Pointer[void]),
    Pointer[void] $loguser,
    &errfunc (int32, Pointer[void] --> int32),
    Pointer[void] $erruser,
    Pointer[int32] $error,
    Pointer[Pointer[uint8]] $error_message
) returns int32 is native(&library) is export { * }

# ============================================================================
# Module creation / destruction
# ============================================================================

sub openmpt_module_create_from_memory2(
    Pointer[void] $filedata, size_t $filesize,
    &logfunc (Str, Pointer[void]),
    Pointer[void] $loguser,
    &errfunc (int32, Pointer[void] --> int32),
    Pointer[void] $erruser,
    Pointer[int32] $error,
    Pointer[Pointer[uint8]] $error_message,
    Pointer[void] $ctls
) returns Pointer[void] is native(&library) is export { * }

sub openmpt_module_destroy(Pointer[void] $mod) is native(&library) is export { * }

# ============================================================================
# Extension API (libopenmpt_ext)
# ============================================================================

sub openmpt_module_ext_create_from_memory(
    Pointer[void] $filedata, size_t $filesize,
    &logfunc (Str, Pointer[void]),
    Pointer[void] $loguser,
    &errfunc (int32, Pointer[void] --> int32),
    Pointer[void] $erruser,
    Pointer[int32] $error,
    Pointer[Pointer[uint8]] $error_message,
    Pointer[void] $ctls
) returns Pointer[void] is native(&library) is export { * }

sub openmpt_module_ext_destroy(Pointer[void] $mod_ext) is native(&library) is export { * }

sub openmpt_module_ext_get_module(Pointer[void] $mod_ext) returns Pointer[void] is native(&library) is export { * }

sub openmpt_module_ext_get_interface(
    Pointer[void] $mod_ext, Str $interface_id,
    Pointer[void] $interface, size_t $interface_size
) returns int32 is native(&library) is export { * }

# ============================================================================
# Log / error function management (per-module)
# ============================================================================

sub openmpt_module_set_log_func(Pointer[void] $mod, &logfunc (Str, Pointer[void]), Pointer[void] $loguser)
    is native(&library) is export { * }
sub openmpt_module_set_error_func(Pointer[void] $mod, &errfunc (int32, Pointer[void] --> int32), Pointer[void] $erruser)
    is native(&library) is export { * }

sub openmpt_module_error_get_last(Pointer[void] $mod)                    returns int32              is native(&library) is export { * }
sub openmpt_module_error_get_last_message(Pointer[void] $mod)            returns Pointer[uint8]    is native(&library) is export { * }
sub openmpt_module_error_set_last(Pointer[void] $mod, int32 $error)                                   is native(&library) is export { * }
sub openmpt_module_error_clear(Pointer[void] $mod)                                                    is native(&library) is export { * }

# ============================================================================
# Playback control
# ============================================================================

sub openmpt_module_select_subsong(Pointer[void] $mod, int32 $subsong)              returns int32  is native(&library) is export { * }
sub openmpt_module_get_selected_subsong(Pointer[void] $mod)                        returns int32  is native(&library) is export { * }
sub openmpt_module_set_repeat_count(Pointer[void] $mod, int32 $repeat_count)       returns int32  is native(&library) is export { * }
sub openmpt_module_get_repeat_count(Pointer[void] $mod)                            returns int32  is native(&library) is export { * }

# ============================================================================
# Position / duration
# ============================================================================

sub openmpt_module_get_duration_seconds(Pointer[void] $mod)                       returns num64  is native(&library) is export { * }
sub openmpt_module_set_position_seconds(Pointer[void] $mod, num64 $seconds)       returns num64  is native(&library) is export { * }
sub openmpt_module_get_position_seconds(Pointer[void] $mod)                       returns num64  is native(&library) is export { * }
sub openmpt_module_set_position_order_row(Pointer[void] $mod, int32 $order, int32 $row) returns num64  is native(&library) is export { * }
sub openmpt_module_get_time_at_position(Pointer[void] $mod, int32 $order, int32 $row) returns num64  is native(&library) is export { * }

# ============================================================================
# Render parameters
# ============================================================================

sub openmpt_module_get_render_param(Pointer[void] $mod, int32 $param, Pointer[int32] $value) returns int32  is native(&library) is export { * }
sub openmpt_module_set_render_param(Pointer[void] $mod, int32 $param, int32 $value)         returns int32  is native(&library) is export { * }

# ============================================================================
# Audio rendering — float
# ============================================================================

sub openmpt_module_read_float_mono(
    Pointer[void] $mod, int32 $samplerate, size_t $count, CArray[num32] $mono
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_float_stereo(
    Pointer[void] $mod, int32 $samplerate, size_t $count,
    CArray[num32] $left, CArray[num32] $right
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_float_quad(
    Pointer[void] $mod, int32 $samplerate, size_t $count,
    CArray[num32] $left, CArray[num32] $right,
    CArray[num32] $rear_left, CArray[num32] $rear_right
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_interleaved_float_stereo(
    Pointer[void] $mod, int32 $samplerate, size_t $count, CArray[num32] $interleaved_stereo
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_interleaved_float_quad(
    Pointer[void] $mod, int32 $samplerate, size_t $count, CArray[num32] $interleaved_quad
) returns size_t is native(&library) is export { * }

# ============================================================================
# Audio rendering — int16
# ============================================================================

sub openmpt_module_read_mono(
    Pointer[void] $mod, int32 $samplerate, size_t $count, CArray[int16] $mono
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_stereo(
    Pointer[void] $mod, int32 $samplerate, size_t $count,
    CArray[int16] $left, CArray[int16] $right
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_quad(
    Pointer[void] $mod, int32 $samplerate, size_t $count,
    CArray[int16] $left, CArray[int16] $right,
    CArray[int16] $rear_left, CArray[int16] $rear_right
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_interleaved_stereo(
    Pointer[void] $mod, int32 $samplerate, size_t $count, CArray[int16] $interleaved_stereo
) returns size_t is native(&library) is export { * }

sub openmpt_module_read_interleaved_quad(
    Pointer[void] $mod, int32 $samplerate, size_t $count, CArray[int16] $interleaved_quad
) returns size_t is native(&library) is export { * }

# ============================================================================
# Metadata
# ============================================================================

sub openmpt_module_get_metadata_keys(Pointer[void] $mod) returns Pointer[uint8]  is native(&library) is export { * }
sub openmpt_module_get_metadata(Pointer[void] $mod, Str $key) returns Pointer[uint8]  is native(&library) is export { * }

# ============================================================================
# Module info — counts
# ============================================================================

sub openmpt_module_get_num_subsongs(Pointer[void] $mod)    returns int32  is native(&library) is export { * }
sub openmpt_module_get_num_channels(Pointer[void] $mod)    returns int32  is native(&library) is export { * }
sub openmpt_module_get_num_orders(Pointer[void] $mod)      returns int32  is native(&library) is export { * }
sub openmpt_module_get_num_patterns(Pointer[void] $mod)    returns int32  is native(&library) is export { * }
sub openmpt_module_get_num_instruments(Pointer[void] $mod) returns int32  is native(&library) is export { * }
sub openmpt_module_get_num_samples(Pointer[void] $mod)     returns int32  is native(&library) is export { * }
sub openmpt_module_get_restart_order(Pointer[void] $mod, int32 $subsong) returns int32  is native(&library) is export { * }
sub openmpt_module_get_restart_row(Pointer[void] $mod, int32 $subsong)   returns int32  is native(&library) is export { * }

# ============================================================================
# Module info — names (must free)
# ============================================================================

sub openmpt_module_get_subsong_name(Pointer[void] $mod, int32 $index)    returns Pointer[uint8]  is native(&library) is export { * }
sub openmpt_module_get_channel_name(Pointer[void] $mod, int32 $index)   returns Pointer[uint8]  is native(&library) is export { * }
sub openmpt_module_get_order_name(Pointer[void] $mod, int32 $index)     returns Pointer[uint8]  is native(&library) is export { * }
sub openmpt_module_get_pattern_name(Pointer[void] $mod, int32 $index)   returns Pointer[uint8]  is native(&library) is export { * }
sub openmpt_module_get_instrument_name(Pointer[void] $mod, int32 $index) returns Pointer[uint8]  is native(&library) is export { * }
sub openmpt_module_get_sample_name(Pointer[void] $mod, int32 $index)    returns Pointer[uint8]  is native(&library) is export { * }

# ============================================================================
# Playback status
# ============================================================================

sub openmpt_module_get_current_estimated_bpm(Pointer[void] $mod)               returns num64  is native(&library) is export { * }
sub openmpt_module_get_current_speed(Pointer[void] $mod)                       returns int32  is native(&library) is export { * }
sub openmpt_module_get_current_tempo(Pointer[void] $mod)                       returns int32  is native(&library) is export { * }
sub openmpt_module_get_current_tempo2(Pointer[void] $mod)                      returns num64  is native(&library) is export { * }
sub openmpt_module_get_current_order(Pointer[void] $mod)                       returns int32  is native(&library) is export { * }
sub openmpt_module_get_current_pattern(Pointer[void] $mod)                     returns int32  is native(&library) is export { * }
sub openmpt_module_get_current_row(Pointer[void] $mod)                         returns int32  is native(&library) is export { * }
sub openmpt_module_get_current_playing_channels(Pointer[void] $mod)            returns int32  is native(&library) is export { * }
sub openmpt_module_get_current_sequence(Pointer[void] $mod)                    returns int32  is native(&library) is export { * }
sub openmpt_module_get_current_channel_vu_mono(Pointer[void] $mod, int32 $channel)    returns num32  is native(&library) is export { * }
sub openmpt_module_get_current_channel_vu_left(Pointer[void] $mod, int32 $channel)    returns num32  is native(&library) is export { * }
sub openmpt_module_get_current_channel_vu_right(Pointer[void] $mod, int32 $channel)   returns num32  is native(&library) is export { * }
sub openmpt_module_get_current_channel_vu_rear_left(Pointer[void] $mod, int32 $channel)  returns num32  is native(&library) is export { * }
sub openmpt_module_get_current_channel_vu_rear_right(Pointer[void] $mod, int32 $channel) returns num32  is native(&library) is export { * }

# ============================================================================
# Pattern / order access
# ============================================================================

sub openmpt_module_get_order_pattern(Pointer[void] $mod, int32 $order)            returns int32  is native(&library) is export { * }
sub openmpt_module_is_order_skip_entry(Pointer[void] $mod, int32 $order)          returns int32  is native(&library) is export { * }
sub openmpt_module_is_order_stop_entry(Pointer[void] $mod, int32 $order)          returns int32  is native(&library) is export { * }
sub openmpt_module_is_pattern_skip_item(Pointer[void] $mod, int32 $pattern)       returns int32  is native(&library) is export { * }
sub openmpt_module_is_pattern_stop_item(Pointer[void] $mod, int32 $pattern)       returns int32  is native(&library) is export { * }
sub openmpt_module_get_pattern_num_rows(Pointer[void] $mod, int32 $pattern)          returns int32  is native(&library) is export { * }
sub openmpt_module_get_pattern_rows_per_beat(Pointer[void] $mod, int32 $pattern)     returns int32  is native(&library) is export { * }
sub openmpt_module_get_pattern_rows_per_measure(Pointer[void] $mod, int32 $pattern)  returns int32  is native(&library) is export { * }

sub openmpt_module_get_pattern_row_channel_command(
    Pointer[void] $mod, int32 $pattern, int32 $row, int32 $channel, int32 $command
) returns uint8 is native(&library) is export { * }

sub openmpt_module_format_pattern_row_channel_command(
    Pointer[void] $mod, int32 $pattern, int32 $row, int32 $channel, int32 $command
) returns Pointer[uint8] is native(&library) is export { * }

sub openmpt_module_highlight_pattern_row_channel_command(
    Pointer[void] $mod, int32 $pattern, int32 $row, int32 $channel, int32 $command
) returns Pointer[uint8] is native(&library) is export { * }

sub openmpt_module_format_pattern_row_channel(
    Pointer[void] $mod, int32 $pattern, int32 $row, int32 $channel, size_t $width, int32 $pad
) returns Pointer[uint8] is native(&library) is export { * }

sub openmpt_module_highlight_pattern_row_channel(
    Pointer[void] $mod, int32 $pattern, int32 $row, int32 $channel, size_t $width, int32 $pad
) returns Pointer[uint8] is native(&library) is export { * }

# ============================================================================
# CTL interface
# ============================================================================

sub openmpt_module_get_ctls(Pointer[void] $mod) returns Pointer[uint8] is native(&library) is export { * }

sub openmpt_module_ctl_get_boolean(Pointer[void] $mod, Str $ctl)       returns int32  is native(&library) is export { * }
sub openmpt_module_ctl_get_integer(Pointer[void] $mod, Str $ctl)       returns int64  is native(&library) is export { * }
sub openmpt_module_ctl_get_floatingpoint(Pointer[void] $mod, Str $ctl) returns num64  is native(&library) is export { * }
sub openmpt_module_ctl_get_text(Pointer[void] $mod, Str $ctl)          returns Pointer[uint8]  is native(&library) is export { * }

sub openmpt_module_ctl_set_boolean(Pointer[void] $mod, Str $ctl, int32 $value)       returns int32  is native(&library) is export { * }
sub openmpt_module_ctl_set_integer(Pointer[void] $mod, Str $ctl, int64 $value)       returns int32  is native(&library) is export { * }
sub openmpt_module_ctl_set_floatingpoint(Pointer[void] $mod, Str $ctl, num64 $value) returns int32  is native(&library) is export { * }
sub openmpt_module_ctl_set_text(Pointer[void] $mod, Str $ctl, Str $value)            returns int32  is native(&library) is export { * }

# Convenience null pointer constant for native callback arguments
constant NULL is export = Pointer[void].new(0);

# Shared error formatting: build an X::OpenMPT::Bindings from an error code
# and optional error_message pointer. Falls back to openmpt_error_string
# (which returns a const char* that must NOT be freed).
# $msg, if given, must be an allocated string from a libopenmpt function
# (e.g. openmpt_module_error_get_last_message) — it will be freed. Do NOT
# pass an openmpt_error_string() result here (const char*, must not free).
sub build-error(int32 $code, Str $function, Str $msg? --> X::OpenMPT::Bindings) is export {
    my $msg-str = $msg
        // ($code
            ?? (nativecast(Str, openmpt_error_string($code)) // "Unknown error (code $code)")
            !! "No error (code 0)");
    X::OpenMPT::Bindings.new(:$function, :$code, :message($msg-str));
}

# Type-dispatch helper: apply a CTL setting with automatic type dispatch
sub apply-ctl(Pointer[void] $mod, Str $ctl, $value --> int32) is export {
    given $value {
        # Bool must precede Int: Bool is a subtype of Int, and given/when
        # smartmatch checks types in declared order.
        when Bool    { openmpt_module_ctl_set_boolean($mod, $ctl, $value.Int) }
        when Int     { openmpt_module_ctl_set_integer($mod, $ctl, $value) }
        when Numeric { openmpt_module_ctl_set_floatingpoint($mod, $ctl, $value.Num) }
        when Str     { openmpt_module_ctl_set_text($mod, $ctl, $value) }
        default      { die "Unsupported CTL value type: {$value.^name}" }
    }
}

# Inline Raku callbacks for module creation/probing.
# Replaces &openmpt_log_func_silent / &openmpt_error_func_store references,
# which hit a broken NativeCall trampoline.
sub cb-log-silent(Str $msg, Pointer[void] $user --> Nil) is export { }
sub cb-error-store(int32 $code, Pointer[void] $user --> int32) is export { OPENMPT_ERROR_FUNC_RESULT_STORE }

CHECK {
    try {
        my $v = openmpt_get_library_version();
        CATCH {
            default {
                die X::OpenMPT::Bindings.new(
                    :function('<library-load>'),
                    :code(OPENMPT_ERROR_UNKNOWN),
                    :message("Cannot load libopenmpt: { .message }"),
                );
            }
        }
    }
}


=begin pod

=head1 NAME

OpenMPT::Bindings::Native - Raw NativeCall declarations for libopenmpt

=head1 DESCRIPTION

Provides C<is export> subroutines for every function exported by
C<libopenmpt.so>. These are thin FFI wrappers — most users will want
the OOP interface in C<OpenMPT::Bindings::Module> instead.

=head1 FUNCTION GROUPS

=head2 Library info

    openmpt_get_library_version()            returns uint32
    openmpt_get_core_version()               returns uint32
    openmpt_get_string(Str $key)             returns Pointer[uint8]  (free)
    openmpt_get_supported_extensions()       returns Pointer[uint8]  (free)
    openmpt_is_extension_supported(Str)      returns int32
    openmpt_free_string(Pointer[uint8])

=head2 Error utilities

    openmpt_error_is_transient(int32 $error)          returns int32
    openmpt_error_string(int32 $error)                returns Pointer[uint8]  (const, do not free)

=head2 File probing

    openmpt_probe_file_header_get_recommended_size()  returns size_t
    openmpt_probe_file_header(...)                     returns int32
    openmpt_probe_file_header_without_filesize(...)    returns int32

=head2 Module creation/destruction

    openmpt_module_create_from_memory2(...)   returns Pointer[void]
    openmpt_module_destroy(Pointer[void])

=head2 Per-module log/error

    openmpt_module_set_log_func(Pointer[void], &, Pointer[void])
    openmpt_module_set_error_func(Pointer[void], &, Pointer[void])
    openmpt_module_error_get_last(Pointer[void])          returns int32
    openmpt_module_error_get_last_message(Pointer[void])  returns Pointer[uint8]  (free)
    openmpt_module_error_set_last(Pointer[void], int32)
    openmpt_module_error_clear(Pointer[void])

=head2 Playback control

    openmpt_module_select_subsong(Pointer[void], int32)      returns int32
    openmpt_module_get_selected_subsong(Pointer[void])       returns int32
    openmpt_module_set_repeat_count(Pointer[void], int32)    returns int32
    openmpt_module_get_repeat_count(Pointer[void])           returns int32

=head2 Position / duration

    openmpt_module_get_duration_seconds(Pointer[void])       returns num64
    openmpt_module_set_position_seconds(Pointer[void], num64) returns num64
    openmpt_module_get_position_seconds(Pointer[void])       returns num64
    openmpt_module_set_position_order_row(Pointer[void], int32, int32) returns num64
    openmpt_module_get_time_at_position(Pointer[void], int32, int32)  returns num64

=head2 Render parameters

    openmpt_module_get_render_param(Pointer[void], int32, Pointer[int32]) returns int32
    openmpt_module_set_render_param(Pointer[void], int32, int32)          returns int32

=head2 Audio rendering — float

    openmpt_module_read_float_mono(Pointer[void], int32, size_t, CArray[num32])          returns size_t
    openmpt_module_read_float_stereo(Pointer[void], int32, size_t, CArray[num32], CArray[num32])  returns size_t
    openmpt_module_read_float_quad(Pointer[void], int32, size_t, CArray[num32], CArray[num32], CArray[num32], CArray[num32])  returns size_t
    openmpt_module_read_interleaved_float_stereo(Pointer[void], int32, size_t, CArray[num32])  returns size_t
    openmpt_module_read_interleaved_float_quad(Pointer[void], int32, size_t, CArray[num32])    returns size_t

=head2 Audio rendering — int16

    openmpt_module_read_mono(Pointer[void], int32, size_t, CArray[int16])             returns size_t
    openmpt_module_read_stereo(Pointer[void], int32, size_t, CArray[int16], CArray[int16])  returns size_t
    openmpt_module_read_quad(Pointer[void], int32, size_t, CArray[int16], CArray[int16], CArray[int16], CArray[int16])  returns size_t
    openmpt_module_read_interleaved_stereo(Pointer[void], int32, size_t, CArray[int16])  returns size_t
    openmpt_module_read_interleaved_quad(Pointer[void], int32, size_t, CArray[int16])    returns size_t

=head2 Metadata

    openmpt_module_get_metadata(Pointer[void], Str $key)       returns Pointer[uint8]  (free)
    openmpt_module_get_metadata_keys(Pointer[void])            returns Pointer[uint8]  (free)

=head2 Module info — counts

    openmpt_module_get_num_subsongs(Pointer[void])    returns int32
    openmpt_module_get_num_channels(Pointer[void])    returns int32
    openmpt_module_get_num_orders(Pointer[void])      returns int32
    openmpt_module_get_num_patterns(Pointer[void])    returns int32
    openmpt_module_get_num_instruments(Pointer[void]) returns int32
    openmpt_module_get_num_samples(Pointer[void])     returns int32
    openmpt_module_get_restart_order(Pointer[void], int32) returns int32
    openmpt_module_get_restart_row(Pointer[void], int32)   returns int32

=head2 Module info — names (must free)

    openmpt_module_get_subsong_name(Pointer[void], int32)    returns Pointer[uint8]  (free)
    openmpt_module_get_channel_name(Pointer[void], int32)   returns Pointer[uint8]  (free)
    openmpt_module_get_order_name(Pointer[void], int32)     returns Pointer[uint8]  (free)
    openmpt_module_get_pattern_name(Pointer[void], int32)   returns Pointer[uint8]  (free)
    openmpt_module_get_instrument_name(Pointer[void], int32) returns Pointer[uint8]  (free)
    openmpt_module_get_sample_name(Pointer[void], int32)    returns Pointer[uint8]  (free)

=head2 Playback status

    openmpt_module_get_current_estimated_bpm(Pointer[void])   returns num64
    openmpt_module_get_current_speed(Pointer[void])            returns int32
    openmpt_module_get_current_tempo(Pointer[void])            returns int32  (deprecated)
    openmpt_module_get_current_tempo2(Pointer[void])           returns num64
    openmpt_module_get_current_order(Pointer[void])            returns int32
    openmpt_module_get_current_pattern(Pointer[void])          returns int32
    openmpt_module_get_current_row(Pointer[void])              returns int32
    openmpt_module_get_current_playing_channels(Pointer[void]) returns int32
    openmpt_module_get_current_channel_vu_mono(Pointer[void], int32)     returns num32
    openmpt_module_get_current_channel_vu_left(Pointer[void], int32)     returns num32
    openmpt_module_get_current_channel_vu_right(Pointer[void], int32)    returns num32
    openmpt_module_get_current_channel_vu_rear_left(Pointer[void], int32)  returns num32
    openmpt_module_get_current_channel_vu_rear_right(Pointer[void], int32) returns num32

=head2 Pattern / order access

    openmpt_module_get_order_pattern(Pointer[void], int32)            returns int32
    openmpt_module_is_order_skip_entry(Pointer[void], int32)          returns int32
    openmpt_module_is_order_stop_entry(Pointer[void], int32)          returns int32
    openmpt_module_is_pattern_skip_item(Pointer[void], int32)         returns int32
    openmpt_module_is_pattern_stop_item(Pointer[void], int32)         returns int32
    openmpt_module_get_pattern_num_rows(Pointer[void], int32)         returns int32
    openmpt_module_get_pattern_rows_per_beat(Pointer[void], int32)    returns int32
    openmpt_module_get_pattern_rows_per_measure(Pointer[void], int32) returns int32
    openmpt_module_get_pattern_row_channel_command(Pointer[void], int32, int32, int32, int32) returns uint8
    openmpt_module_format_pattern_row_channel_command(Pointer[void], int32, int32, int32, int32) returns Pointer[uint8]  (free)
    openmpt_module_highlight_pattern_row_channel_command(Pointer[void], int32, int32, int32, int32) returns Pointer[uint8]  (free)
    openmpt_module_format_pattern_row_channel(Pointer[void], int32, int32, int32, size_t, int32) returns Pointer[uint8]  (free)
    openmpt_module_highlight_pattern_row_channel(Pointer[void], int32, int32, int32, size_t, int32) returns Pointer[uint8]  (free)

=head2 CTL interface

    openmpt_module_get_ctls(Pointer[void])                       returns Pointer[uint8]  (free)
    openmpt_module_ctl_get_boolean(Pointer[void], Str)           returns int32
    openmpt_module_ctl_get_integer(Pointer[void], Str)           returns int64
    openmpt_module_ctl_get_floatingpoint(Pointer[void], Str)     returns num64
    openmpt_module_ctl_get_text(Pointer[void], Str)              returns Pointer[uint8]  (free)
    openmpt_module_ctl_set_boolean(Pointer[void], Str, int32)    returns int32
    openmpt_module_ctl_set_integer(Pointer[void], Str, int64)    returns int32
    openmpt_module_ctl_set_floatingpoint(Pointer[void], Str, num64) returns int32
    openmpt_module_ctl_set_text(Pointer[void], Str, Str)         returns int32

=head1 NOTES

Functions marked C<(free)> return allocated strings that must be freed
with C<openmpt_free_string>. The exception is C<openmpt_error_string>
which returns a C<const char*> — do I<not> free its result.

=head1 SEE ALSO

=item L<OpenMPT::Bindings::Module> — OOP wrapper around these subroutines
=item L<https://lib.openmpt.org/> — libopenmpt project

=end pod
